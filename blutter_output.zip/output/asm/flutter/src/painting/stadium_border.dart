// lib: , url: package:flutter/src/painting/stadium_border.dart

// class id: 1049380, size: 0x8
class :: {
}

// class id: 2175, size: 0x18, field offset: 0xc
//   const constructor, 
class _StadiumToRoundedRectangleBorder extends OutlinedBorder {

  _ lerpTo(/* No info */) {
    // ** addr: 0x70f518, size: 0x338
    // 0x70f518: EnterFrame
    //     0x70f518: stp             fp, lr, [SP, #-0x10]!
    //     0x70f51c: mov             fp, SP
    // 0x70f520: AllocStack(0x20)
    //     0x70f520: sub             SP, SP, #0x20
    // 0x70f524: CheckStackOverflow
    //     0x70f524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70f528: cmp             SP, x16
    //     0x70f52c: b.ls            #0x70f7dc
    // 0x70f530: ldr             x0, [fp, #0x18]
    // 0x70f534: r1 = LoadClassIdInstr(r0)
    //     0x70f534: ldur            x1, [x0, #-1]
    //     0x70f538: ubfx            x1, x1, #0xc, #0x14
    // 0x70f53c: lsl             x1, x1, #1
    // 0x70f540: r17 = 4354
    //     0x70f540: mov             x17, #0x1102
    // 0x70f544: cmp             w1, w17
    // 0x70f548: b.ne            #0x70f5d0
    // 0x70f54c: ldr             x1, [fp, #0x20]
    // 0x70f550: ldr             d0, [fp, #0x10]
    // 0x70f554: LoadField: r2 = r1->field_7
    //     0x70f554: ldur            w2, [x1, #7]
    // 0x70f558: DecompressPointer r2
    //     0x70f558: add             x2, x2, HEAP, lsl #32
    // 0x70f55c: LoadField: r3 = r0->field_7
    //     0x70f55c: ldur            w3, [x0, #7]
    // 0x70f560: DecompressPointer r3
    //     0x70f560: add             x3, x3, HEAP, lsl #32
    // 0x70f564: stp             x3, x2, [SP, #-0x10]!
    // 0x70f568: SaveReg d0
    //     0x70f568: str             d0, [SP, #-8]!
    // 0x70f56c: r0 = lerp()
    //     0x70f56c: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70f570: add             SP, SP, #0x18
    // 0x70f574: ldr             x2, [fp, #0x20]
    // 0x70f578: stur            x0, [fp, #-0x10]
    // 0x70f57c: LoadField: r1 = r2->field_b
    //     0x70f57c: ldur            w1, [x2, #0xb]
    // 0x70f580: DecompressPointer r1
    //     0x70f580: add             x1, x1, HEAP, lsl #32
    // 0x70f584: stur            x1, [fp, #-8]
    // 0x70f588: LoadField: d0 = r2->field_f
    //     0x70f588: ldur            d0, [x2, #0xf]
    // 0x70f58c: ldr             d2, [fp, #0x10]
    // 0x70f590: d1 = 1.000000
    //     0x70f590: fmov            d1, #1.00000000
    // 0x70f594: fsub            d3, d1, d2
    // 0x70f598: fmul            d1, d0, d3
    // 0x70f59c: stur            d1, [fp, #-0x20]
    // 0x70f5a0: r0 = _StadiumToRoundedRectangleBorder()
    //     0x70f5a0: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x70f5a4: mov             x1, x0
    // 0x70f5a8: ldur            x0, [fp, #-8]
    // 0x70f5ac: StoreField: r1->field_b = r0
    //     0x70f5ac: stur            w0, [x1, #0xb]
    // 0x70f5b0: ldur            d0, [fp, #-0x20]
    // 0x70f5b4: StoreField: r1->field_f = d0
    //     0x70f5b4: stur            d0, [x1, #0xf]
    // 0x70f5b8: ldur            x0, [fp, #-0x10]
    // 0x70f5bc: StoreField: r1->field_7 = r0
    //     0x70f5bc: stur            w0, [x1, #7]
    // 0x70f5c0: mov             x0, x1
    // 0x70f5c4: LeaveFrame
    //     0x70f5c4: mov             SP, fp
    //     0x70f5c8: ldp             fp, lr, [SP], #0x10
    // 0x70f5cc: ret
    //     0x70f5cc: ret             
    // 0x70f5d0: ldr             x2, [fp, #0x20]
    // 0x70f5d4: ldr             d2, [fp, #0x10]
    // 0x70f5d8: d1 = 1.000000
    //     0x70f5d8: fmov            d1, #1.00000000
    // 0x70f5dc: r17 = 4358
    //     0x70f5dc: mov             x17, #0x1106
    // 0x70f5e0: cmp             w1, w17
    // 0x70f5e4: b.ne            #0x70f668
    // 0x70f5e8: LoadField: r1 = r2->field_7
    //     0x70f5e8: ldur            w1, [x2, #7]
    // 0x70f5ec: DecompressPointer r1
    //     0x70f5ec: add             x1, x1, HEAP, lsl #32
    // 0x70f5f0: LoadField: r3 = r0->field_7
    //     0x70f5f0: ldur            w3, [x0, #7]
    // 0x70f5f4: DecompressPointer r3
    //     0x70f5f4: add             x3, x3, HEAP, lsl #32
    // 0x70f5f8: stp             x3, x1, [SP, #-0x10]!
    // 0x70f5fc: SaveReg d2
    //     0x70f5fc: str             d2, [SP, #-8]!
    // 0x70f600: r0 = lerp()
    //     0x70f600: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70f604: add             SP, SP, #0x18
    // 0x70f608: ldr             x2, [fp, #0x20]
    // 0x70f60c: stur            x0, [fp, #-0x10]
    // 0x70f610: LoadField: r1 = r2->field_b
    //     0x70f610: ldur            w1, [x2, #0xb]
    // 0x70f614: DecompressPointer r1
    //     0x70f614: add             x1, x1, HEAP, lsl #32
    // 0x70f618: stur            x1, [fp, #-8]
    // 0x70f61c: LoadField: d0 = r2->field_f
    //     0x70f61c: ldur            d0, [x2, #0xf]
    // 0x70f620: d1 = 1.000000
    //     0x70f620: fmov            d1, #1.00000000
    // 0x70f624: fsub            d2, d1, d0
    // 0x70f628: ldr             d1, [fp, #0x10]
    // 0x70f62c: fmul            d3, d2, d1
    // 0x70f630: fadd            d1, d0, d3
    // 0x70f634: stur            d1, [fp, #-0x20]
    // 0x70f638: r0 = _StadiumToRoundedRectangleBorder()
    //     0x70f638: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x70f63c: mov             x1, x0
    // 0x70f640: ldur            x0, [fp, #-8]
    // 0x70f644: StoreField: r1->field_b = r0
    //     0x70f644: stur            w0, [x1, #0xb]
    // 0x70f648: ldur            d0, [fp, #-0x20]
    // 0x70f64c: StoreField: r1->field_f = d0
    //     0x70f64c: stur            d0, [x1, #0xf]
    // 0x70f650: ldur            x0, [fp, #-0x10]
    // 0x70f654: StoreField: r1->field_7 = r0
    //     0x70f654: stur            w0, [x1, #7]
    // 0x70f658: mov             x0, x1
    // 0x70f65c: LeaveFrame
    //     0x70f65c: mov             SP, fp
    //     0x70f660: ldp             fp, lr, [SP], #0x10
    // 0x70f664: ret
    //     0x70f664: ret             
    // 0x70f668: mov             v1.16b, v2.16b
    // 0x70f66c: r17 = 4350
    //     0x70f66c: mov             x17, #0x10fe
    // 0x70f670: cmp             w1, w17
    // 0x70f674: b.ne            #0x70f7b4
    // 0x70f678: LoadField: r1 = r2->field_7
    //     0x70f678: ldur            w1, [x2, #7]
    // 0x70f67c: DecompressPointer r1
    //     0x70f67c: add             x1, x1, HEAP, lsl #32
    // 0x70f680: LoadField: r3 = r0->field_7
    //     0x70f680: ldur            w3, [x0, #7]
    // 0x70f684: DecompressPointer r3
    //     0x70f684: add             x3, x3, HEAP, lsl #32
    // 0x70f688: stp             x3, x1, [SP, #-0x10]!
    // 0x70f68c: SaveReg d1
    //     0x70f68c: str             d1, [SP, #-8]!
    // 0x70f690: r0 = lerp()
    //     0x70f690: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70f694: add             SP, SP, #0x18
    // 0x70f698: mov             x1, x0
    // 0x70f69c: ldr             x0, [fp, #0x20]
    // 0x70f6a0: stur            x1, [fp, #-8]
    // 0x70f6a4: LoadField: r2 = r0->field_b
    //     0x70f6a4: ldur            w2, [x0, #0xb]
    // 0x70f6a8: DecompressPointer r2
    //     0x70f6a8: add             x2, x2, HEAP, lsl #32
    // 0x70f6ac: ldr             x3, [fp, #0x18]
    // 0x70f6b0: LoadField: r4 = r3->field_b
    //     0x70f6b0: ldur            w4, [x3, #0xb]
    // 0x70f6b4: DecompressPointer r4
    //     0x70f6b4: add             x4, x4, HEAP, lsl #32
    // 0x70f6b8: stp             x4, x2, [SP, #-0x10]!
    // 0x70f6bc: ldr             d0, [fp, #0x10]
    // 0x70f6c0: SaveReg d0
    //     0x70f6c0: str             d0, [SP, #-8]!
    // 0x70f6c4: r0 = lerp()
    //     0x70f6c4: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x70f6c8: add             SP, SP, #0x18
    // 0x70f6cc: stur            x0, [fp, #-0x10]
    // 0x70f6d0: cmp             w0, NULL
    // 0x70f6d4: b.eq            #0x70f7e4
    // 0x70f6d8: ldr             x1, [fp, #0x20]
    // 0x70f6dc: LoadField: d0 = r1->field_f
    //     0x70f6dc: ldur            d0, [x1, #0xf]
    // 0x70f6e0: ldr             x2, [fp, #0x18]
    // 0x70f6e4: LoadField: d1 = r2->field_f
    //     0x70f6e4: ldur            d1, [x2, #0xf]
    // 0x70f6e8: ldr             d2, [fp, #0x10]
    // 0x70f6ec: r1 = inline_Allocate_Double()
    //     0x70f6ec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x70f6f0: add             x1, x1, #0x10
    //     0x70f6f4: cmp             x2, x1
    //     0x70f6f8: b.ls            #0x70f7e8
    //     0x70f6fc: str             x1, [THR, #0x60]  ; THR::top
    //     0x70f700: sub             x1, x1, #0xf
    //     0x70f704: mov             x2, #0xd108
    //     0x70f708: movk            x2, #3, lsl #16
    //     0x70f70c: stur            x2, [x1, #-1]
    // 0x70f710: StoreField: r1->field_7 = d2
    //     0x70f710: stur            d2, [x1, #7]
    // 0x70f714: r2 = inline_Allocate_Double()
    //     0x70f714: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x70f718: add             x2, x2, #0x10
    //     0x70f71c: cmp             x3, x2
    //     0x70f720: b.ls            #0x70f80c
    //     0x70f724: str             x2, [THR, #0x60]  ; THR::top
    //     0x70f728: sub             x2, x2, #0xf
    //     0x70f72c: mov             x3, #0xd108
    //     0x70f730: movk            x3, #3, lsl #16
    //     0x70f734: stur            x3, [x2, #-1]
    // 0x70f738: StoreField: r2->field_7 = d0
    //     0x70f738: stur            d0, [x2, #7]
    // 0x70f73c: r3 = inline_Allocate_Double()
    //     0x70f73c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x70f740: add             x3, x3, #0x10
    //     0x70f744: cmp             x4, x3
    //     0x70f748: b.ls            #0x70f828
    //     0x70f74c: str             x3, [THR, #0x60]  ; THR::top
    //     0x70f750: sub             x3, x3, #0xf
    //     0x70f754: mov             x4, #0xd108
    //     0x70f758: movk            x4, #3, lsl #16
    //     0x70f75c: stur            x4, [x3, #-1]
    // 0x70f760: StoreField: r3->field_7 = d1
    //     0x70f760: stur            d1, [x3, #7]
    // 0x70f764: stp             x3, x2, [SP, #-0x10]!
    // 0x70f768: SaveReg r1
    //     0x70f768: str             x1, [SP, #-8]!
    // 0x70f76c: r0 = lerpDouble()
    //     0x70f76c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x70f770: add             SP, SP, #0x18
    // 0x70f774: stur            x0, [fp, #-0x18]
    // 0x70f778: cmp             w0, NULL
    // 0x70f77c: b.eq            #0x70f84c
    // 0x70f780: r0 = _StadiumToRoundedRectangleBorder()
    //     0x70f780: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x70f784: mov             x1, x0
    // 0x70f788: ldur            x0, [fp, #-0x10]
    // 0x70f78c: StoreField: r1->field_b = r0
    //     0x70f78c: stur            w0, [x1, #0xb]
    // 0x70f790: ldur            x0, [fp, #-0x18]
    // 0x70f794: LoadField: d0 = r0->field_7
    //     0x70f794: ldur            d0, [x0, #7]
    // 0x70f798: StoreField: r1->field_f = d0
    //     0x70f798: stur            d0, [x1, #0xf]
    // 0x70f79c: ldur            x0, [fp, #-8]
    // 0x70f7a0: StoreField: r1->field_7 = r0
    //     0x70f7a0: stur            w0, [x1, #7]
    // 0x70f7a4: mov             x0, x1
    // 0x70f7a8: LeaveFrame
    //     0x70f7a8: mov             SP, fp
    //     0x70f7ac: ldp             fp, lr, [SP], #0x10
    // 0x70f7b0: ret
    //     0x70f7b0: ret             
    // 0x70f7b4: mov             x1, x2
    // 0x70f7b8: mov             x2, x0
    // 0x70f7bc: mov             v2.16b, v1.16b
    // 0x70f7c0: stp             x2, x1, [SP, #-0x10]!
    // 0x70f7c4: SaveReg d2
    //     0x70f7c4: str             d2, [SP, #-8]!
    // 0x70f7c8: r0 = lerpTo()
    //     0x70f7c8: bl              #0x70f880  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x70f7cc: add             SP, SP, #0x18
    // 0x70f7d0: LeaveFrame
    //     0x70f7d0: mov             SP, fp
    //     0x70f7d4: ldp             fp, lr, [SP], #0x10
    // 0x70f7d8: ret
    //     0x70f7d8: ret             
    // 0x70f7dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70f7dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70f7e0: b               #0x70f530
    // 0x70f7e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70f7e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70f7e8: stp             q1, q2, [SP, #-0x20]!
    // 0x70f7ec: SaveReg d0
    //     0x70f7ec: str             q0, [SP, #-0x10]!
    // 0x70f7f0: SaveReg r0
    //     0x70f7f0: str             x0, [SP, #-8]!
    // 0x70f7f4: r0 = AllocateDouble()
    //     0x70f7f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70f7f8: mov             x1, x0
    // 0x70f7fc: RestoreReg r0
    //     0x70f7fc: ldr             x0, [SP], #8
    // 0x70f800: RestoreReg d0
    //     0x70f800: ldr             q0, [SP], #0x10
    // 0x70f804: ldp             q1, q2, [SP], #0x20
    // 0x70f808: b               #0x70f710
    // 0x70f80c: stp             q0, q1, [SP, #-0x20]!
    // 0x70f810: stp             x0, x1, [SP, #-0x10]!
    // 0x70f814: r0 = AllocateDouble()
    //     0x70f814: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70f818: mov             x2, x0
    // 0x70f81c: ldp             x0, x1, [SP], #0x10
    // 0x70f820: ldp             q0, q1, [SP], #0x20
    // 0x70f824: b               #0x70f738
    // 0x70f828: SaveReg d1
    //     0x70f828: str             q1, [SP, #-0x10]!
    // 0x70f82c: stp             x1, x2, [SP, #-0x10]!
    // 0x70f830: SaveReg r0
    //     0x70f830: str             x0, [SP, #-8]!
    // 0x70f834: r0 = AllocateDouble()
    //     0x70f834: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70f838: mov             x3, x0
    // 0x70f83c: RestoreReg r0
    //     0x70f83c: ldr             x0, [SP], #8
    // 0x70f840: ldp             x1, x2, [SP], #0x10
    // 0x70f844: RestoreReg d1
    //     0x70f844: ldr             q1, [SP], #0x10
    // 0x70f848: b               #0x70f760
    // 0x70f84c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70f84c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x710b78, size: 0x33c
    // 0x710b78: EnterFrame
    //     0x710b78: stp             fp, lr, [SP, #-0x10]!
    //     0x710b7c: mov             fp, SP
    // 0x710b80: AllocStack(0x20)
    //     0x710b80: sub             SP, SP, #0x20
    // 0x710b84: CheckStackOverflow
    //     0x710b84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x710b88: cmp             SP, x16
    //     0x710b8c: b.ls            #0x710e40
    // 0x710b90: ldr             x0, [fp, #0x18]
    // 0x710b94: r1 = LoadClassIdInstr(r0)
    //     0x710b94: ldur            x1, [x0, #-1]
    //     0x710b98: ubfx            x1, x1, #0xc, #0x14
    // 0x710b9c: lsl             x1, x1, #1
    // 0x710ba0: r17 = 4354
    //     0x710ba0: mov             x17, #0x1102
    // 0x710ba4: cmp             w1, w17
    // 0x710ba8: b.ne            #0x710c28
    // 0x710bac: ldr             x1, [fp, #0x20]
    // 0x710bb0: ldr             d0, [fp, #0x10]
    // 0x710bb4: LoadField: r2 = r0->field_7
    //     0x710bb4: ldur            w2, [x0, #7]
    // 0x710bb8: DecompressPointer r2
    //     0x710bb8: add             x2, x2, HEAP, lsl #32
    // 0x710bbc: LoadField: r0 = r1->field_7
    //     0x710bbc: ldur            w0, [x1, #7]
    // 0x710bc0: DecompressPointer r0
    //     0x710bc0: add             x0, x0, HEAP, lsl #32
    // 0x710bc4: stp             x0, x2, [SP, #-0x10]!
    // 0x710bc8: SaveReg d0
    //     0x710bc8: str             d0, [SP, #-8]!
    // 0x710bcc: r0 = lerp()
    //     0x710bcc: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x710bd0: add             SP, SP, #0x18
    // 0x710bd4: ldr             x2, [fp, #0x20]
    // 0x710bd8: stur            x0, [fp, #-0x10]
    // 0x710bdc: LoadField: r1 = r2->field_b
    //     0x710bdc: ldur            w1, [x2, #0xb]
    // 0x710be0: DecompressPointer r1
    //     0x710be0: add             x1, x1, HEAP, lsl #32
    // 0x710be4: stur            x1, [fp, #-8]
    // 0x710be8: LoadField: d0 = r2->field_f
    //     0x710be8: ldur            d0, [x2, #0xf]
    // 0x710bec: ldr             d1, [fp, #0x10]
    // 0x710bf0: fmul            d2, d0, d1
    // 0x710bf4: stur            d2, [fp, #-0x20]
    // 0x710bf8: r0 = _StadiumToRoundedRectangleBorder()
    //     0x710bf8: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x710bfc: mov             x1, x0
    // 0x710c00: ldur            x0, [fp, #-8]
    // 0x710c04: StoreField: r1->field_b = r0
    //     0x710c04: stur            w0, [x1, #0xb]
    // 0x710c08: ldur            d0, [fp, #-0x20]
    // 0x710c0c: StoreField: r1->field_f = d0
    //     0x710c0c: stur            d0, [x1, #0xf]
    // 0x710c10: ldur            x0, [fp, #-0x10]
    // 0x710c14: StoreField: r1->field_7 = r0
    //     0x710c14: stur            w0, [x1, #7]
    // 0x710c18: mov             x0, x1
    // 0x710c1c: LeaveFrame
    //     0x710c1c: mov             SP, fp
    //     0x710c20: ldp             fp, lr, [SP], #0x10
    // 0x710c24: ret
    //     0x710c24: ret             
    // 0x710c28: ldr             x2, [fp, #0x20]
    // 0x710c2c: ldr             d1, [fp, #0x10]
    // 0x710c30: r17 = 4358
    //     0x710c30: mov             x17, #0x1106
    // 0x710c34: cmp             w1, w17
    // 0x710c38: b.ne            #0x710cc0
    // 0x710c3c: LoadField: r1 = r0->field_7
    //     0x710c3c: ldur            w1, [x0, #7]
    // 0x710c40: DecompressPointer r1
    //     0x710c40: add             x1, x1, HEAP, lsl #32
    // 0x710c44: LoadField: r0 = r2->field_7
    //     0x710c44: ldur            w0, [x2, #7]
    // 0x710c48: DecompressPointer r0
    //     0x710c48: add             x0, x0, HEAP, lsl #32
    // 0x710c4c: stp             x0, x1, [SP, #-0x10]!
    // 0x710c50: SaveReg d1
    //     0x710c50: str             d1, [SP, #-8]!
    // 0x710c54: r0 = lerp()
    //     0x710c54: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x710c58: add             SP, SP, #0x18
    // 0x710c5c: ldr             x2, [fp, #0x20]
    // 0x710c60: stur            x0, [fp, #-0x10]
    // 0x710c64: LoadField: r1 = r2->field_b
    //     0x710c64: ldur            w1, [x2, #0xb]
    // 0x710c68: DecompressPointer r1
    //     0x710c68: add             x1, x1, HEAP, lsl #32
    // 0x710c6c: stur            x1, [fp, #-8]
    // 0x710c70: LoadField: d0 = r2->field_f
    //     0x710c70: ldur            d0, [x2, #0xf]
    // 0x710c74: d1 = 1.000000
    //     0x710c74: fmov            d1, #1.00000000
    // 0x710c78: fsub            d2, d1, d0
    // 0x710c7c: ldr             d3, [fp, #0x10]
    // 0x710c80: fsub            d4, d1, d3
    // 0x710c84: fmul            d1, d2, d4
    // 0x710c88: fadd            d2, d0, d1
    // 0x710c8c: stur            d2, [fp, #-0x20]
    // 0x710c90: r0 = _StadiumToRoundedRectangleBorder()
    //     0x710c90: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x710c94: mov             x1, x0
    // 0x710c98: ldur            x0, [fp, #-8]
    // 0x710c9c: StoreField: r1->field_b = r0
    //     0x710c9c: stur            w0, [x1, #0xb]
    // 0x710ca0: ldur            d0, [fp, #-0x20]
    // 0x710ca4: StoreField: r1->field_f = d0
    //     0x710ca4: stur            d0, [x1, #0xf]
    // 0x710ca8: ldur            x0, [fp, #-0x10]
    // 0x710cac: StoreField: r1->field_7 = r0
    //     0x710cac: stur            w0, [x1, #7]
    // 0x710cb0: mov             x0, x1
    // 0x710cb4: LeaveFrame
    //     0x710cb4: mov             SP, fp
    //     0x710cb8: ldp             fp, lr, [SP], #0x10
    // 0x710cbc: ret
    //     0x710cbc: ret             
    // 0x710cc0: mov             v3.16b, v1.16b
    // 0x710cc4: r17 = 4350
    //     0x710cc4: mov             x17, #0x10fe
    // 0x710cc8: cmp             w1, w17
    // 0x710ccc: b.ne            #0x710e0c
    // 0x710cd0: LoadField: r1 = r0->field_7
    //     0x710cd0: ldur            w1, [x0, #7]
    // 0x710cd4: DecompressPointer r1
    //     0x710cd4: add             x1, x1, HEAP, lsl #32
    // 0x710cd8: LoadField: r3 = r2->field_7
    //     0x710cd8: ldur            w3, [x2, #7]
    // 0x710cdc: DecompressPointer r3
    //     0x710cdc: add             x3, x3, HEAP, lsl #32
    // 0x710ce0: stp             x3, x1, [SP, #-0x10]!
    // 0x710ce4: SaveReg d3
    //     0x710ce4: str             d3, [SP, #-8]!
    // 0x710ce8: r0 = lerp()
    //     0x710ce8: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x710cec: add             SP, SP, #0x18
    // 0x710cf0: mov             x1, x0
    // 0x710cf4: ldr             x0, [fp, #0x18]
    // 0x710cf8: stur            x1, [fp, #-8]
    // 0x710cfc: LoadField: r2 = r0->field_b
    //     0x710cfc: ldur            w2, [x0, #0xb]
    // 0x710d00: DecompressPointer r2
    //     0x710d00: add             x2, x2, HEAP, lsl #32
    // 0x710d04: ldr             x3, [fp, #0x20]
    // 0x710d08: LoadField: r4 = r3->field_b
    //     0x710d08: ldur            w4, [x3, #0xb]
    // 0x710d0c: DecompressPointer r4
    //     0x710d0c: add             x4, x4, HEAP, lsl #32
    // 0x710d10: stp             x4, x2, [SP, #-0x10]!
    // 0x710d14: ldr             d0, [fp, #0x10]
    // 0x710d18: SaveReg d0
    //     0x710d18: str             d0, [SP, #-8]!
    // 0x710d1c: r0 = lerp()
    //     0x710d1c: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x710d20: add             SP, SP, #0x18
    // 0x710d24: stur            x0, [fp, #-0x10]
    // 0x710d28: cmp             w0, NULL
    // 0x710d2c: b.eq            #0x710e48
    // 0x710d30: ldr             x1, [fp, #0x18]
    // 0x710d34: LoadField: d0 = r1->field_f
    //     0x710d34: ldur            d0, [x1, #0xf]
    // 0x710d38: ldr             x2, [fp, #0x20]
    // 0x710d3c: LoadField: d1 = r2->field_f
    //     0x710d3c: ldur            d1, [x2, #0xf]
    // 0x710d40: ldr             d2, [fp, #0x10]
    // 0x710d44: r1 = inline_Allocate_Double()
    //     0x710d44: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x710d48: add             x1, x1, #0x10
    //     0x710d4c: cmp             x2, x1
    //     0x710d50: b.ls            #0x710e4c
    //     0x710d54: str             x1, [THR, #0x60]  ; THR::top
    //     0x710d58: sub             x1, x1, #0xf
    //     0x710d5c: mov             x2, #0xd108
    //     0x710d60: movk            x2, #3, lsl #16
    //     0x710d64: stur            x2, [x1, #-1]
    // 0x710d68: StoreField: r1->field_7 = d2
    //     0x710d68: stur            d2, [x1, #7]
    // 0x710d6c: r2 = inline_Allocate_Double()
    //     0x710d6c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x710d70: add             x2, x2, #0x10
    //     0x710d74: cmp             x3, x2
    //     0x710d78: b.ls            #0x710e70
    //     0x710d7c: str             x2, [THR, #0x60]  ; THR::top
    //     0x710d80: sub             x2, x2, #0xf
    //     0x710d84: mov             x3, #0xd108
    //     0x710d88: movk            x3, #3, lsl #16
    //     0x710d8c: stur            x3, [x2, #-1]
    // 0x710d90: StoreField: r2->field_7 = d0
    //     0x710d90: stur            d0, [x2, #7]
    // 0x710d94: r3 = inline_Allocate_Double()
    //     0x710d94: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x710d98: add             x3, x3, #0x10
    //     0x710d9c: cmp             x4, x3
    //     0x710da0: b.ls            #0x710e8c
    //     0x710da4: str             x3, [THR, #0x60]  ; THR::top
    //     0x710da8: sub             x3, x3, #0xf
    //     0x710dac: mov             x4, #0xd108
    //     0x710db0: movk            x4, #3, lsl #16
    //     0x710db4: stur            x4, [x3, #-1]
    // 0x710db8: StoreField: r3->field_7 = d1
    //     0x710db8: stur            d1, [x3, #7]
    // 0x710dbc: stp             x3, x2, [SP, #-0x10]!
    // 0x710dc0: SaveReg r1
    //     0x710dc0: str             x1, [SP, #-8]!
    // 0x710dc4: r0 = lerpDouble()
    //     0x710dc4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x710dc8: add             SP, SP, #0x18
    // 0x710dcc: stur            x0, [fp, #-0x18]
    // 0x710dd0: cmp             w0, NULL
    // 0x710dd4: b.eq            #0x710eb0
    // 0x710dd8: r0 = _StadiumToRoundedRectangleBorder()
    //     0x710dd8: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x710ddc: mov             x1, x0
    // 0x710de0: ldur            x0, [fp, #-0x10]
    // 0x710de4: StoreField: r1->field_b = r0
    //     0x710de4: stur            w0, [x1, #0xb]
    // 0x710de8: ldur            x0, [fp, #-0x18]
    // 0x710dec: LoadField: d0 = r0->field_7
    //     0x710dec: ldur            d0, [x0, #7]
    // 0x710df0: StoreField: r1->field_f = d0
    //     0x710df0: stur            d0, [x1, #0xf]
    // 0x710df4: ldur            x0, [fp, #-8]
    // 0x710df8: StoreField: r1->field_7 = r0
    //     0x710df8: stur            w0, [x1, #7]
    // 0x710dfc: mov             x0, x1
    // 0x710e00: LeaveFrame
    //     0x710e00: mov             SP, fp
    //     0x710e04: ldp             fp, lr, [SP], #0x10
    // 0x710e08: ret
    //     0x710e08: ret             
    // 0x710e0c: mov             x1, x0
    // 0x710e10: mov             v2.16b, v3.16b
    // 0x710e14: cmp             w1, NULL
    // 0x710e18: b.ne            #0x710e30
    // 0x710e1c: SaveReg r2
    //     0x710e1c: str             x2, [SP, #-8]!
    // 0x710e20: SaveReg d2
    //     0x710e20: str             d2, [SP, #-8]!
    // 0x710e24: r0 = scale()
    //     0x710e24: bl              #0xcf8aac  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::scale
    // 0x710e28: add             SP, SP, #0x10
    // 0x710e2c: b               #0x710e34
    // 0x710e30: r0 = Null
    //     0x710e30: mov             x0, NULL
    // 0x710e34: LeaveFrame
    //     0x710e34: mov             SP, fp
    //     0x710e38: ldp             fp, lr, [SP], #0x10
    // 0x710e3c: ret
    //     0x710e3c: ret             
    // 0x710e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x710e40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x710e44: b               #0x710b90
    // 0x710e48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x710e48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x710e4c: stp             q1, q2, [SP, #-0x20]!
    // 0x710e50: SaveReg d0
    //     0x710e50: str             q0, [SP, #-0x10]!
    // 0x710e54: SaveReg r0
    //     0x710e54: str             x0, [SP, #-8]!
    // 0x710e58: r0 = AllocateDouble()
    //     0x710e58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710e5c: mov             x1, x0
    // 0x710e60: RestoreReg r0
    //     0x710e60: ldr             x0, [SP], #8
    // 0x710e64: RestoreReg d0
    //     0x710e64: ldr             q0, [SP], #0x10
    // 0x710e68: ldp             q1, q2, [SP], #0x20
    // 0x710e6c: b               #0x710d68
    // 0x710e70: stp             q0, q1, [SP, #-0x20]!
    // 0x710e74: stp             x0, x1, [SP, #-0x10]!
    // 0x710e78: r0 = AllocateDouble()
    //     0x710e78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710e7c: mov             x2, x0
    // 0x710e80: ldp             x0, x1, [SP], #0x10
    // 0x710e84: ldp             q0, q1, [SP], #0x20
    // 0x710e88: b               #0x710d90
    // 0x710e8c: SaveReg d1
    //     0x710e8c: str             q1, [SP, #-0x10]!
    // 0x710e90: stp             x1, x2, [SP, #-0x10]!
    // 0x710e94: SaveReg r0
    //     0x710e94: str             x0, [SP, #-8]!
    // 0x710e98: r0 = AllocateDouble()
    //     0x710e98: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710e9c: mov             x3, x0
    // 0x710ea0: RestoreReg r0
    //     0x710ea0: ldr             x0, [SP], #8
    // 0x710ea4: ldp             x1, x2, [SP], #0x10
    // 0x710ea8: RestoreReg d1
    //     0x710ea8: ldr             q1, [SP], #0x10
    // 0x710eac: b               #0x710db8
    // 0x710eb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x710eb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x718998, size: 0xf4
    // 0x718998: EnterFrame
    //     0x718998: stp             fp, lr, [SP, #-0x10]!
    //     0x71899c: mov             fp, SP
    // 0x7189a0: AllocStack(0x8)
    //     0x7189a0: sub             SP, SP, #8
    // 0x7189a4: CheckStackOverflow
    //     0x7189a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7189a8: cmp             SP, x16
    //     0x7189ac: b.ls            #0x718a80
    // 0x7189b0: ldr             x16, [fp, #0x30]
    // 0x7189b4: ldr             lr, [fp, #0x20]
    // 0x7189b8: stp             lr, x16, [SP, #-0x10]!
    // 0x7189bc: r0 = _adjustBorderRadius()
    //     0x7189bc: bl              #0x718a8c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::_adjustBorderRadius
    // 0x7189c0: add             SP, SP, #0x10
    // 0x7189c4: stur            x0, [fp, #-8]
    // 0x7189c8: r16 = Instance_BorderRadius
    //     0x7189c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x7189cc: ldr             x16, [x16, #0x2c0]
    // 0x7189d0: stp             x16, x0, [SP, #-0x10]!
    // 0x7189d4: r0 = ==()
    //     0x7189d4: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x7189d8: add             SP, SP, #0x10
    // 0x7189dc: tbnz            w0, #4, #0x718a00
    // 0x7189e0: ldr             x16, [fp, #0x28]
    // 0x7189e4: ldr             lr, [fp, #0x20]
    // 0x7189e8: stp             lr, x16, [SP, #-0x10]!
    // 0x7189ec: ldr             x16, [fp, #0x18]
    // 0x7189f0: SaveReg r16
    //     0x7189f0: str             x16, [SP, #-8]!
    // 0x7189f4: r0 = drawRect()
    //     0x7189f4: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0x7189f8: add             SP, SP, #0x18
    // 0x7189fc: b               #0x718a70
    // 0x718a00: ldur            x0, [fp, #-8]
    // 0x718a04: r1 = LoadClassIdInstr(r0)
    //     0x718a04: ldur            x1, [x0, #-1]
    //     0x718a08: ubfx            x1, x1, #0xc, #0x14
    // 0x718a0c: lsl             x1, x1, #1
    // 0x718a10: r17 = 4224
    //     0x718a10: mov             x17, #0x1080
    // 0x718a14: cmp             w1, w17
    // 0x718a18: b.eq            #0x718a40
    // 0x718a1c: r1 = LoadClassIdInstr(r0)
    //     0x718a1c: ldur            x1, [x0, #-1]
    //     0x718a20: ubfx            x1, x1, #0xc, #0x14
    // 0x718a24: ldr             x16, [fp, #0x10]
    // 0x718a28: stp             x16, x0, [SP, #-0x10]!
    // 0x718a2c: mov             x0, x1
    // 0x718a30: r0 = GDT[cid_x0 + -0x1000]()
    //     0x718a30: sub             lr, x0, #1, lsl #12
    //     0x718a34: ldr             lr, [x21, lr, lsl #3]
    //     0x718a38: blr             lr
    // 0x718a3c: add             SP, SP, #0x10
    // 0x718a40: cmp             w0, NULL
    // 0x718a44: b.eq            #0x718a88
    // 0x718a48: ldr             x16, [fp, #0x20]
    // 0x718a4c: stp             x16, x0, [SP, #-0x10]!
    // 0x718a50: r0 = toRRect()
    //     0x718a50: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x718a54: add             SP, SP, #0x10
    // 0x718a58: ldr             x16, [fp, #0x28]
    // 0x718a5c: stp             x0, x16, [SP, #-0x10]!
    // 0x718a60: ldr             x16, [fp, #0x18]
    // 0x718a64: SaveReg r16
    //     0x718a64: str             x16, [SP, #-8]!
    // 0x718a68: r0 = drawRRect()
    //     0x718a68: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x718a6c: add             SP, SP, #0x18
    // 0x718a70: r0 = Null
    //     0x718a70: mov             x0, NULL
    // 0x718a74: LeaveFrame
    //     0x718a74: mov             SP, fp
    //     0x718a78: ldp             fp, lr, [SP], #0x10
    // 0x718a7c: ret
    //     0x718a7c: ret             
    // 0x718a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x718a80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x718a84: b               #0x7189b0
    // 0x718a88: r0 = NullErrorSharedWithoutFPURegs()
    //     0x718a88: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _adjustBorderRadius(/* No info */) {
    // ** addr: 0x718a8c, size: 0xbc
    // 0x718a8c: EnterFrame
    //     0x718a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x718a90: mov             fp, SP
    // 0x718a94: AllocStack(0x18)
    //     0x718a94: sub             SP, SP, #0x18
    // 0x718a98: CheckStackOverflow
    //     0x718a98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x718a9c: cmp             SP, x16
    //     0x718aa0: b.ls            #0x718b3c
    // 0x718aa4: ldr             x0, [fp, #0x18]
    // 0x718aa8: LoadField: r1 = r0->field_b
    //     0x718aa8: ldur            w1, [x0, #0xb]
    // 0x718aac: DecompressPointer r1
    //     0x718aac: add             x1, x1, HEAP, lsl #32
    // 0x718ab0: stur            x1, [fp, #-8]
    // 0x718ab4: ldr             x16, [fp, #0x10]
    // 0x718ab8: SaveReg r16
    //     0x718ab8: str             x16, [SP, #-8]!
    // 0x718abc: r0 = shortestSide()
    //     0x718abc: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0x718ac0: add             SP, SP, #8
    // 0x718ac4: mov             v1.16b, v0.16b
    // 0x718ac8: d0 = 2.000000
    //     0x718ac8: fmov            d0, #2.00000000
    // 0x718acc: fdiv            d2, d1, d0
    // 0x718ad0: stur            d2, [fp, #-0x18]
    // 0x718ad4: r0 = Radius()
    //     0x718ad4: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x718ad8: ldur            d0, [fp, #-0x18]
    // 0x718adc: stur            x0, [fp, #-0x10]
    // 0x718ae0: StoreField: r0->field_7 = d0
    //     0x718ae0: stur            d0, [x0, #7]
    // 0x718ae4: StoreField: r0->field_f = d0
    //     0x718ae4: stur            d0, [x0, #0xf]
    // 0x718ae8: r0 = BorderRadius()
    //     0x718ae8: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x718aec: mov             x1, x0
    // 0x718af0: ldur            x0, [fp, #-0x10]
    // 0x718af4: StoreField: r1->field_7 = r0
    //     0x718af4: stur            w0, [x1, #7]
    // 0x718af8: StoreField: r1->field_b = r0
    //     0x718af8: stur            w0, [x1, #0xb]
    // 0x718afc: StoreField: r1->field_f = r0
    //     0x718afc: stur            w0, [x1, #0xf]
    // 0x718b00: StoreField: r1->field_13 = r0
    //     0x718b00: stur            w0, [x1, #0x13]
    // 0x718b04: ldr             x0, [fp, #0x18]
    // 0x718b08: LoadField: d0 = r0->field_f
    //     0x718b08: ldur            d0, [x0, #0xf]
    // 0x718b0c: d1 = 1.000000
    //     0x718b0c: fmov            d1, #1.00000000
    // 0x718b10: fsub            d2, d1, d0
    // 0x718b14: ldur            x16, [fp, #-8]
    // 0x718b18: stp             x1, x16, [SP, #-0x10]!
    // 0x718b1c: SaveReg d2
    //     0x718b1c: str             d2, [SP, #-8]!
    // 0x718b20: r0 = lerp()
    //     0x718b20: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x718b24: add             SP, SP, #0x18
    // 0x718b28: cmp             w0, NULL
    // 0x718b2c: b.eq            #0x718b44
    // 0x718b30: LeaveFrame
    //     0x718b30: mov             SP, fp
    //     0x718b34: ldp             fp, lr, [SP], #0x10
    // 0x718b38: ret
    //     0x718b38: ret             
    // 0x718b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x718b3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x718b40: b               #0x718aa4
    // 0x718b44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x718b44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getInnerPath(/* No info */) {
    // ** addr: 0x71b210, size: 0x208
    // 0x71b210: EnterFrame
    //     0x71b210: stp             fp, lr, [SP, #-0x10]!
    //     0x71b214: mov             fp, SP
    // 0x71b218: AllocStack(0x18)
    //     0x71b218: sub             SP, SP, #0x18
    // 0x71b21c: SetupParameters(_StadiumToRoundedRectangleBorder this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic textDirection = Null /* r0, fp-0x8 */})
    //     0x71b21c: mov             x0, x4
    //     0x71b220: ldur            w1, [x0, #0x13]
    //     0x71b224: add             x1, x1, HEAP, lsl #32
    //     0x71b228: sub             x2, x1, #4
    //     0x71b22c: add             x3, fp, w2, sxtw #2
    //     0x71b230: ldr             x3, [x3, #0x18]
    //     0x71b234: stur            x3, [fp, #-0x18]
    //     0x71b238: add             x4, fp, w2, sxtw #2
    //     0x71b23c: ldr             x4, [x4, #0x10]
    //     0x71b240: stur            x4, [fp, #-0x10]
    //     0x71b244: ldur            w2, [x0, #0x1f]
    //     0x71b248: add             x2, x2, HEAP, lsl #32
    //     0x71b24c: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0x71b250: ldr             x16, [x16, #0xf10]
    //     0x71b254: cmp             w2, w16
    //     0x71b258: b.ne            #0x71b278
    //     0x71b25c: ldur            w2, [x0, #0x23]
    //     0x71b260: add             x2, x2, HEAP, lsl #32
    //     0x71b264: sub             w0, w1, w2
    //     0x71b268: add             x1, fp, w0, sxtw #2
    //     0x71b26c: ldr             x1, [x1, #8]
    //     0x71b270: mov             x0, x1
    //     0x71b274: b               #0x71b27c
    //     0x71b278: mov             x0, NULL
    //     0x71b27c: stur            x0, [fp, #-8]
    // 0x71b280: CheckStackOverflow
    //     0x71b280: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71b284: cmp             SP, x16
    //     0x71b288: b.ls            #0x71b3d4
    // 0x71b28c: stp             x4, x3, [SP, #-0x10]!
    // 0x71b290: r0 = _adjustBorderRadius()
    //     0x71b290: bl              #0x718a8c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::_adjustBorderRadius
    // 0x71b294: add             SP, SP, #0x10
    // 0x71b298: r1 = LoadClassIdInstr(r0)
    //     0x71b298: ldur            x1, [x0, #-1]
    //     0x71b29c: ubfx            x1, x1, #0xc, #0x14
    // 0x71b2a0: lsl             x1, x1, #1
    // 0x71b2a4: r17 = 4224
    //     0x71b2a4: mov             x17, #0x1080
    // 0x71b2a8: cmp             w1, w17
    // 0x71b2ac: b.ne            #0x71b2b8
    // 0x71b2b0: mov             x1, x0
    // 0x71b2b4: b               #0x71b2e0
    // 0x71b2b8: r1 = LoadClassIdInstr(r0)
    //     0x71b2b8: ldur            x1, [x0, #-1]
    //     0x71b2bc: ubfx            x1, x1, #0xc, #0x14
    // 0x71b2c0: ldur            x16, [fp, #-8]
    // 0x71b2c4: stp             x16, x0, [SP, #-0x10]!
    // 0x71b2c8: mov             x0, x1
    // 0x71b2cc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x71b2cc: sub             lr, x0, #1, lsl #12
    //     0x71b2d0: ldr             lr, [x21, lr, lsl #3]
    //     0x71b2d4: blr             lr
    // 0x71b2d8: add             SP, SP, #0x10
    // 0x71b2dc: mov             x1, x0
    // 0x71b2e0: ldur            x0, [fp, #-0x18]
    // 0x71b2e4: cmp             w1, NULL
    // 0x71b2e8: b.eq            #0x71b3dc
    // 0x71b2ec: ldur            x16, [fp, #-0x10]
    // 0x71b2f0: stp             x16, x1, [SP, #-0x10]!
    // 0x71b2f4: r0 = toRRect()
    //     0x71b2f4: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x71b2f8: add             SP, SP, #0x10
    // 0x71b2fc: mov             x1, x0
    // 0x71b300: ldur            x0, [fp, #-0x18]
    // 0x71b304: stur            x1, [fp, #-8]
    // 0x71b308: LoadField: r2 = r0->field_7
    //     0x71b308: ldur            w2, [x0, #7]
    // 0x71b30c: DecompressPointer r2
    //     0x71b30c: add             x2, x2, HEAP, lsl #32
    // 0x71b310: LoadField: d0 = r2->field_b
    //     0x71b310: ldur            d0, [x2, #0xb]
    // 0x71b314: LoadField: d1 = r2->field_17
    //     0x71b314: ldur            d1, [x2, #0x17]
    // 0x71b318: r0 = inline_Allocate_Double()
    //     0x71b318: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71b31c: add             x0, x0, #0x10
    //     0x71b320: cmp             x2, x0
    //     0x71b324: b.ls            #0x71b3e0
    //     0x71b328: str             x0, [THR, #0x60]  ; THR::top
    //     0x71b32c: sub             x0, x0, #0xf
    //     0x71b330: mov             x2, #0xd108
    //     0x71b334: movk            x2, #3, lsl #16
    //     0x71b338: stur            x2, [x0, #-1]
    // 0x71b33c: StoreField: r0->field_7 = d0
    //     0x71b33c: stur            d0, [x0, #7]
    // 0x71b340: r2 = inline_Allocate_Double()
    //     0x71b340: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x71b344: add             x2, x2, #0x10
    //     0x71b348: cmp             x3, x2
    //     0x71b34c: b.ls            #0x71b3f8
    //     0x71b350: str             x2, [THR, #0x60]  ; THR::top
    //     0x71b354: sub             x2, x2, #0xf
    //     0x71b358: mov             x3, #0xd108
    //     0x71b35c: movk            x3, #3, lsl #16
    //     0x71b360: stur            x3, [x2, #-1]
    // 0x71b364: StoreField: r2->field_7 = d1
    //     0x71b364: stur            d1, [x2, #7]
    // 0x71b368: stp             xzr, x0, [SP, #-0x10]!
    // 0x71b36c: SaveReg r2
    //     0x71b36c: str             x2, [SP, #-8]!
    // 0x71b370: r0 = lerpDouble()
    //     0x71b370: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x71b374: add             SP, SP, #0x18
    // 0x71b378: cmp             w0, NULL
    // 0x71b37c: b.eq            #0x71b414
    // 0x71b380: LoadField: d0 = r0->field_7
    //     0x71b380: ldur            d0, [x0, #7]
    // 0x71b384: ldur            x16, [fp, #-8]
    // 0x71b388: SaveReg r16
    //     0x71b388: str             x16, [SP, #-8]!
    // 0x71b38c: SaveReg d0
    //     0x71b38c: str             d0, [SP, #-8]!
    // 0x71b390: r0 = deflate()
    //     0x71b390: bl              #0x6705bc  ; [dart:ui] RRect::deflate
    // 0x71b394: add             SP, SP, #0x10
    // 0x71b398: stur            x0, [fp, #-8]
    // 0x71b39c: r0 = Path()
    //     0x71b39c: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x71b3a0: stur            x0, [fp, #-0x10]
    // 0x71b3a4: SaveReg r0
    //     0x71b3a4: str             x0, [SP, #-8]!
    // 0x71b3a8: r0 = _constructor()
    //     0x71b3a8: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x71b3ac: add             SP, SP, #8
    // 0x71b3b0: ldur            x16, [fp, #-0x10]
    // 0x71b3b4: ldur            lr, [fp, #-8]
    // 0x71b3b8: stp             lr, x16, [SP, #-0x10]!
    // 0x71b3bc: r0 = addRRect()
    //     0x71b3bc: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0x71b3c0: add             SP, SP, #0x10
    // 0x71b3c4: ldur            x0, [fp, #-0x10]
    // 0x71b3c8: LeaveFrame
    //     0x71b3c8: mov             SP, fp
    //     0x71b3cc: ldp             fp, lr, [SP], #0x10
    // 0x71b3d0: ret
    //     0x71b3d0: ret             
    // 0x71b3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71b3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71b3d8: b               #0x71b28c
    // 0x71b3dc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x71b3dc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x71b3e0: stp             q0, q1, [SP, #-0x20]!
    // 0x71b3e4: SaveReg r1
    //     0x71b3e4: str             x1, [SP, #-8]!
    // 0x71b3e8: r0 = AllocateDouble()
    //     0x71b3e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x71b3ec: RestoreReg r1
    //     0x71b3ec: ldr             x1, [SP], #8
    // 0x71b3f0: ldp             q0, q1, [SP], #0x20
    // 0x71b3f4: b               #0x71b33c
    // 0x71b3f8: SaveReg d1
    //     0x71b3f8: str             q1, [SP, #-0x10]!
    // 0x71b3fc: stp             x0, x1, [SP, #-0x10]!
    // 0x71b400: r0 = AllocateDouble()
    //     0x71b400: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x71b404: mov             x2, x0
    // 0x71b408: ldp             x0, x1, [SP], #0x10
    // 0x71b40c: RestoreReg d1
    //     0x71b40c: ldr             q1, [SP], #0x10
    // 0x71b410: b               #0x71b364
    // 0x71b414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71b414: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xadb870, size: 0x120
    // 0xadb870: EnterFrame
    //     0xadb870: stp             fp, lr, [SP, #-0x10]!
    //     0xadb874: mov             fp, SP
    // 0xadb878: AllocStack(0x8)
    //     0xadb878: sub             SP, SP, #8
    // 0xadb87c: CheckStackOverflow
    //     0xadb87c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadb880: cmp             SP, x16
    //     0xadb884: b.ls            #0xadb96c
    // 0xadb888: r1 = Null
    //     0xadb888: mov             x1, NULL
    // 0xadb88c: r2 = 14
    //     0xadb88c: mov             x2, #0xe
    // 0xadb890: r0 = AllocateArray()
    //     0xadb890: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb894: stur            x0, [fp, #-8]
    // 0xadb898: r17 = "StadiumBorder("
    //     0xadb898: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe00] "StadiumBorder("
    //     0xadb89c: ldr             x17, [x17, #0xe00]
    // 0xadb8a0: StoreField: r0->field_f = r17
    //     0xadb8a0: stur            w17, [x0, #0xf]
    // 0xadb8a4: ldr             x1, [fp, #0x10]
    // 0xadb8a8: LoadField: r2 = r1->field_7
    //     0xadb8a8: ldur            w2, [x1, #7]
    // 0xadb8ac: DecompressPointer r2
    //     0xadb8ac: add             x2, x2, HEAP, lsl #32
    // 0xadb8b0: StoreField: r0->field_13 = r2
    //     0xadb8b0: stur            w2, [x0, #0x13]
    // 0xadb8b4: r17 = ", "
    //     0xadb8b4: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb8b8: StoreField: r0->field_17 = r17
    //     0xadb8b8: stur            w17, [x0, #0x17]
    // 0xadb8bc: LoadField: r2 = r1->field_b
    //     0xadb8bc: ldur            w2, [x1, #0xb]
    // 0xadb8c0: DecompressPointer r2
    //     0xadb8c0: add             x2, x2, HEAP, lsl #32
    // 0xadb8c4: StoreField: r0->field_1b = r2
    //     0xadb8c4: stur            w2, [x0, #0x1b]
    // 0xadb8c8: r17 = ", "
    //     0xadb8c8: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb8cc: StoreField: r0->field_1f = r17
    //     0xadb8cc: stur            w17, [x0, #0x1f]
    // 0xadb8d0: LoadField: d0 = r1->field_f
    //     0xadb8d0: ldur            d0, [x1, #0xf]
    // 0xadb8d4: d1 = 100.000000
    //     0xadb8d4: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb8d8: ldr             d1, [x17, #0x308]
    // 0xadb8dc: fmul            d2, d0, d1
    // 0xadb8e0: r1 = inline_Allocate_Double()
    //     0xadb8e0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xadb8e4: add             x1, x1, #0x10
    //     0xadb8e8: cmp             x2, x1
    //     0xadb8ec: b.ls            #0xadb974
    //     0xadb8f0: str             x1, [THR, #0x60]  ; THR::top
    //     0xadb8f4: sub             x1, x1, #0xf
    //     0xadb8f8: mov             x2, #0xd108
    //     0xadb8fc: movk            x2, #3, lsl #16
    //     0xadb900: stur            x2, [x1, #-1]
    // 0xadb904: StoreField: r1->field_7 = d2
    //     0xadb904: stur            d2, [x1, #7]
    // 0xadb908: SaveReg r1
    //     0xadb908: str             x1, [SP, #-8]!
    // 0xadb90c: r1 = 1
    //     0xadb90c: mov             x1, #1
    // 0xadb910: SaveReg r1
    //     0xadb910: str             x1, [SP, #-8]!
    // 0xadb914: r0 = toStringAsFixed()
    //     0xadb914: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadb918: add             SP, SP, #0x10
    // 0xadb91c: ldur            x1, [fp, #-8]
    // 0xadb920: ArrayStore: r1[5] = r0  ; List_4
    //     0xadb920: add             x25, x1, #0x23
    //     0xadb924: str             w0, [x25]
    //     0xadb928: tbz             w0, #0, #0xadb944
    //     0xadb92c: ldurb           w16, [x1, #-1]
    //     0xadb930: ldurb           w17, [x0, #-1]
    //     0xadb934: and             x16, x17, x16, lsr #2
    //     0xadb938: tst             x16, HEAP, lsr #32
    //     0xadb93c: b.eq            #0xadb944
    //     0xadb940: bl              #0xd67e5c
    // 0xadb944: ldur            x0, [fp, #-8]
    // 0xadb948: r17 = "% of the way to being a RoundedRectangleBorder)"
    //     0xadb948: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe28] "% of the way to being a RoundedRectangleBorder)"
    //     0xadb94c: ldr             x17, [x17, #0xe28]
    // 0xadb950: StoreField: r0->field_27 = r17
    //     0xadb950: stur            w17, [x0, #0x27]
    // 0xadb954: SaveReg r0
    //     0xadb954: str             x0, [SP, #-8]!
    // 0xadb958: r0 = _interpolate()
    //     0xadb958: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb95c: add             SP, SP, #8
    // 0xadb960: LeaveFrame
    //     0xadb960: mov             SP, fp
    //     0xadb964: ldp             fp, lr, [SP], #0x10
    // 0xadb968: ret
    //     0xadb968: ret             
    // 0xadb96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadb96c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadb970: b               #0xadb888
    // 0xadb974: SaveReg d2
    //     0xadb974: str             q2, [SP, #-0x10]!
    // 0xadb978: SaveReg r0
    //     0xadb978: str             x0, [SP, #-8]!
    // 0xadb97c: r0 = AllocateDouble()
    //     0xadb97c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadb980: mov             x1, x0
    // 0xadb984: RestoreReg r0
    //     0xadb984: ldr             x0, [SP], #8
    // 0xadb988: RestoreReg d2
    //     0xadb988: ldr             q2, [SP], #0x10
    // 0xadb98c: b               #0xadb904
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd4578, size: 0x188
    // 0xbd4578: EnterFrame
    //     0xbd4578: stp             fp, lr, [SP, #-0x10]!
    //     0xbd457c: mov             fp, SP
    // 0xbd4580: AllocStack(0x20)
    //     0xbd4580: sub             SP, SP, #0x20
    // 0xbd4584: SetupParameters(_StadiumToRoundedRectangleBorder this /* r3 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* r5, fp-0x18 */, {dynamic textDirection = Null /* r0, fp-0x10 */})
    //     0xbd4584: mov             x0, x4
    //     0xbd4588: ldur            w1, [x0, #0x13]
    //     0xbd458c: add             x1, x1, HEAP, lsl #32
    //     0xbd4590: sub             x2, x1, #6
    //     0xbd4594: add             x3, fp, w2, sxtw #2
    //     0xbd4598: ldr             x3, [x3, #0x20]
    //     0xbd459c: add             x4, fp, w2, sxtw #2
    //     0xbd45a0: ldr             x4, [x4, #0x18]
    //     0xbd45a4: stur            x4, [fp, #-0x20]
    //     0xbd45a8: add             x5, fp, w2, sxtw #2
    //     0xbd45ac: ldr             x5, [x5, #0x10]
    //     0xbd45b0: stur            x5, [fp, #-0x18]
    //     0xbd45b4: ldur            w2, [x0, #0x1f]
    //     0xbd45b8: add             x2, x2, HEAP, lsl #32
    //     0xbd45bc: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0xbd45c0: ldr             x16, [x16, #0xf10]
    //     0xbd45c4: cmp             w2, w16
    //     0xbd45c8: b.ne            #0xbd45e8
    //     0xbd45cc: ldur            w2, [x0, #0x23]
    //     0xbd45d0: add             x2, x2, HEAP, lsl #32
    //     0xbd45d4: sub             w0, w1, w2
    //     0xbd45d8: add             x1, fp, w0, sxtw #2
    //     0xbd45dc: ldr             x1, [x1, #8]
    //     0xbd45e0: mov             x0, x1
    //     0xbd45e4: b               #0xbd45ec
    //     0xbd45e8: mov             x0, NULL
    //     0xbd45ec: stur            x0, [fp, #-0x10]
    // 0xbd45f0: CheckStackOverflow
    //     0xbd45f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd45f4: cmp             SP, x16
    //     0xbd45f8: b.ls            #0xbd46f4
    // 0xbd45fc: LoadField: r1 = r3->field_7
    //     0xbd45fc: ldur            w1, [x3, #7]
    // 0xbd4600: DecompressPointer r1
    //     0xbd4600: add             x1, x1, HEAP, lsl #32
    // 0xbd4604: stur            x1, [fp, #-8]
    // 0xbd4608: LoadField: r2 = r1->field_13
    //     0xbd4608: ldur            w2, [x1, #0x13]
    // 0xbd460c: DecompressPointer r2
    //     0xbd460c: add             x2, x2, HEAP, lsl #32
    // 0xbd4610: LoadField: r6 = r2->field_7
    //     0xbd4610: ldur            x6, [x2, #7]
    // 0xbd4614: cmp             x6, #0
    // 0xbd4618: b.le            #0xbd46e4
    // 0xbd461c: stp             x5, x3, [SP, #-0x10]!
    // 0xbd4620: r0 = _adjustBorderRadius()
    //     0xbd4620: bl              #0x718a8c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::_adjustBorderRadius
    // 0xbd4624: add             SP, SP, #0x10
    // 0xbd4628: r1 = LoadClassIdInstr(r0)
    //     0xbd4628: ldur            x1, [x0, #-1]
    //     0xbd462c: ubfx            x1, x1, #0xc, #0x14
    // 0xbd4630: lsl             x1, x1, #1
    // 0xbd4634: r17 = 4224
    //     0xbd4634: mov             x17, #0x1080
    // 0xbd4638: cmp             w1, w17
    // 0xbd463c: b.ne            #0xbd4648
    // 0xbd4640: mov             x1, x0
    // 0xbd4644: b               #0xbd4670
    // 0xbd4648: r1 = LoadClassIdInstr(r0)
    //     0xbd4648: ldur            x1, [x0, #-1]
    //     0xbd464c: ubfx            x1, x1, #0xc, #0x14
    // 0xbd4650: ldur            x16, [fp, #-0x10]
    // 0xbd4654: stp             x16, x0, [SP, #-0x10]!
    // 0xbd4658: mov             x0, x1
    // 0xbd465c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbd465c: sub             lr, x0, #1, lsl #12
    //     0xbd4660: ldr             lr, [x21, lr, lsl #3]
    //     0xbd4664: blr             lr
    // 0xbd4668: add             SP, SP, #0x10
    // 0xbd466c: mov             x1, x0
    // 0xbd4670: ldur            x0, [fp, #-8]
    // 0xbd4674: cmp             w1, NULL
    // 0xbd4678: b.eq            #0xbd46fc
    // 0xbd467c: ldur            x16, [fp, #-0x18]
    // 0xbd4680: stp             x16, x1, [SP, #-0x10]!
    // 0xbd4684: r0 = toRRect()
    //     0xbd4684: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbd4688: add             SP, SP, #0x10
    // 0xbd468c: mov             x1, x0
    // 0xbd4690: ldur            x0, [fp, #-8]
    // 0xbd4694: LoadField: d0 = r0->field_b
    //     0xbd4694: ldur            d0, [x0, #0xb]
    // 0xbd4698: LoadField: d1 = r0->field_17
    //     0xbd4698: ldur            d1, [x0, #0x17]
    // 0xbd469c: fmul            d2, d0, d1
    // 0xbd46a0: d0 = 2.000000
    //     0xbd46a0: fmov            d0, #2.00000000
    // 0xbd46a4: fdiv            d1, d2, d0
    // 0xbd46a8: SaveReg r1
    //     0xbd46a8: str             x1, [SP, #-8]!
    // 0xbd46ac: SaveReg d1
    //     0xbd46ac: str             d1, [SP, #-8]!
    // 0xbd46b0: r0 = inflate()
    //     0xbd46b0: bl              #0x65ffe4  ; [dart:ui] RRect::inflate
    // 0xbd46b4: add             SP, SP, #0x10
    // 0xbd46b8: stur            x0, [fp, #-0x10]
    // 0xbd46bc: ldur            x16, [fp, #-8]
    // 0xbd46c0: SaveReg r16
    //     0xbd46c0: str             x16, [SP, #-8]!
    // 0xbd46c4: r0 = toPaint()
    //     0xbd46c4: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd46c8: add             SP, SP, #8
    // 0xbd46cc: ldur            x16, [fp, #-0x20]
    // 0xbd46d0: ldur            lr, [fp, #-0x10]
    // 0xbd46d4: stp             lr, x16, [SP, #-0x10]!
    // 0xbd46d8: SaveReg r0
    //     0xbd46d8: str             x0, [SP, #-8]!
    // 0xbd46dc: r0 = drawRRect()
    //     0xbd46dc: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xbd46e0: add             SP, SP, #0x18
    // 0xbd46e4: r0 = Null
    //     0xbd46e4: mov             x0, NULL
    // 0xbd46e8: LeaveFrame
    //     0xbd46e8: mov             SP, fp
    //     0xbd46ec: ldp             fp, lr, [SP], #0x10
    // 0xbd46f0: ret
    //     0xbd46f0: ret             
    // 0xbd46f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd46f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd46f8: b               #0xbd45fc
    // 0xbd46fc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbd46fc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc99ec0, size: 0x14c
    // 0xc99ec0: EnterFrame
    //     0xc99ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xc99ec4: mov             fp, SP
    // 0xc99ec8: CheckStackOverflow
    //     0xc99ec8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc99ecc: cmp             SP, x16
    //     0xc99ed0: b.ls            #0xc9a004
    // 0xc99ed4: ldr             x1, [fp, #0x10]
    // 0xc99ed8: cmp             w1, NULL
    // 0xc99edc: b.ne            #0xc99ef0
    // 0xc99ee0: r0 = false
    //     0xc99ee0: add             x0, NULL, #0x30  ; false
    // 0xc99ee4: LeaveFrame
    //     0xc99ee4: mov             SP, fp
    //     0xc99ee8: ldp             fp, lr, [SP], #0x10
    // 0xc99eec: ret
    //     0xc99eec: ret             
    // 0xc99ef0: r0 = 59
    //     0xc99ef0: mov             x0, #0x3b
    // 0xc99ef4: branchIfSmi(r1, 0xc99f00)
    //     0xc99ef4: tbz             w1, #0, #0xc99f00
    // 0xc99ef8: r0 = LoadClassIdInstr(r1)
    //     0xc99ef8: ldur            x0, [x1, #-1]
    //     0xc99efc: ubfx            x0, x0, #0xc, #0x14
    // 0xc99f00: SaveReg r1
    //     0xc99f00: str             x1, [SP, #-8]!
    // 0xc99f04: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc99f04: mov             x17, #0x57c5
    //     0xc99f08: add             lr, x0, x17
    //     0xc99f0c: ldr             lr, [x21, lr, lsl #3]
    //     0xc99f10: blr             lr
    // 0xc99f14: add             SP, SP, #8
    // 0xc99f18: r1 = LoadClassIdInstr(r0)
    //     0xc99f18: ldur            x1, [x0, #-1]
    //     0xc99f1c: ubfx            x1, x1, #0xc, #0x14
    // 0xc99f20: r16 = _StadiumToRoundedRectangleBorder
    //     0xc99f20: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3fe30] Type: _StadiumToRoundedRectangleBorder
    //     0xc99f24: ldr             x16, [x16, #0xe30]
    // 0xc99f28: stp             x16, x0, [SP, #-0x10]!
    // 0xc99f2c: mov             x0, x1
    // 0xc99f30: mov             lr, x0
    // 0xc99f34: ldr             lr, [x21, lr, lsl #3]
    // 0xc99f38: blr             lr
    // 0xc99f3c: add             SP, SP, #0x10
    // 0xc99f40: tbz             w0, #4, #0xc99f54
    // 0xc99f44: r0 = false
    //     0xc99f44: add             x0, NULL, #0x30  ; false
    // 0xc99f48: LeaveFrame
    //     0xc99f48: mov             SP, fp
    //     0xc99f4c: ldp             fp, lr, [SP], #0x10
    // 0xc99f50: ret
    //     0xc99f50: ret             
    // 0xc99f54: ldr             x0, [fp, #0x10]
    // 0xc99f58: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc99f58: mov             x1, #0x76
    //     0xc99f5c: tbz             w0, #0, #0xc99f6c
    //     0xc99f60: ldur            x1, [x0, #-1]
    //     0xc99f64: ubfx            x1, x1, #0xc, #0x14
    //     0xc99f68: lsl             x1, x1, #1
    // 0xc99f6c: r17 = 4350
    //     0xc99f6c: mov             x17, #0x10fe
    // 0xc99f70: cmp             w1, w17
    // 0xc99f74: b.ne            #0xc99ff4
    // 0xc99f78: ldr             x1, [fp, #0x18]
    // 0xc99f7c: LoadField: r2 = r0->field_7
    //     0xc99f7c: ldur            w2, [x0, #7]
    // 0xc99f80: DecompressPointer r2
    //     0xc99f80: add             x2, x2, HEAP, lsl #32
    // 0xc99f84: LoadField: r3 = r1->field_7
    //     0xc99f84: ldur            w3, [x1, #7]
    // 0xc99f88: DecompressPointer r3
    //     0xc99f88: add             x3, x3, HEAP, lsl #32
    // 0xc99f8c: stp             x3, x2, [SP, #-0x10]!
    // 0xc99f90: r0 = ==()
    //     0xc99f90: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc99f94: add             SP, SP, #0x10
    // 0xc99f98: tbnz            w0, #4, #0xc99ff4
    // 0xc99f9c: ldr             x1, [fp, #0x18]
    // 0xc99fa0: ldr             x0, [fp, #0x10]
    // 0xc99fa4: LoadField: r2 = r0->field_b
    //     0xc99fa4: ldur            w2, [x0, #0xb]
    // 0xc99fa8: DecompressPointer r2
    //     0xc99fa8: add             x2, x2, HEAP, lsl #32
    // 0xc99fac: LoadField: r3 = r1->field_b
    //     0xc99fac: ldur            w3, [x1, #0xb]
    // 0xc99fb0: DecompressPointer r3
    //     0xc99fb0: add             x3, x3, HEAP, lsl #32
    // 0xc99fb4: stp             x3, x2, [SP, #-0x10]!
    // 0xc99fb8: r0 = ==()
    //     0xc99fb8: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xc99fbc: add             SP, SP, #0x10
    // 0xc99fc0: tbnz            w0, #4, #0xc99ff4
    // 0xc99fc4: ldr             x2, [fp, #0x18]
    // 0xc99fc8: ldr             x1, [fp, #0x10]
    // 0xc99fcc: LoadField: d0 = r1->field_f
    //     0xc99fcc: ldur            d0, [x1, #0xf]
    // 0xc99fd0: LoadField: d1 = r2->field_f
    //     0xc99fd0: ldur            d1, [x2, #0xf]
    // 0xc99fd4: fcmp            d0, d1
    // 0xc99fd8: b.vs            #0xc99fe0
    // 0xc99fdc: b.eq            #0xc99fe8
    // 0xc99fe0: r1 = false
    //     0xc99fe0: add             x1, NULL, #0x30  ; false
    // 0xc99fe4: b               #0xc99fec
    // 0xc99fe8: r1 = true
    //     0xc99fe8: add             x1, NULL, #0x20  ; true
    // 0xc99fec: mov             x0, x1
    // 0xc99ff0: b               #0xc99ff8
    // 0xc99ff4: r0 = false
    //     0xc99ff4: add             x0, NULL, #0x30  ; false
    // 0xc99ff8: LeaveFrame
    //     0xc99ff8: mov             SP, fp
    //     0xc99ffc: ldp             fp, lr, [SP], #0x10
    // 0xc9a000: ret
    //     0xc9a000: ret             
    // 0xc9a004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9a004: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9a008: b               #0xc99ed4
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf8aac, size: 0x218
    // 0xcf8aac: EnterFrame
    //     0xcf8aac: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8ab0: mov             fp, SP
    // 0xcf8ab4: AllocStack(0x30)
    //     0xcf8ab4: sub             SP, SP, #0x30
    // 0xcf8ab8: CheckStackOverflow
    //     0xcf8ab8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf8abc: cmp             SP, x16
    //     0xcf8ac0: b.ls            #0xcf8c7c
    // 0xcf8ac4: ldr             x0, [fp, #0x18]
    // 0xcf8ac8: LoadField: r1 = r0->field_7
    //     0xcf8ac8: ldur            w1, [x0, #7]
    // 0xcf8acc: DecompressPointer r1
    //     0xcf8acc: add             x1, x1, HEAP, lsl #32
    // 0xcf8ad0: SaveReg r1
    //     0xcf8ad0: str             x1, [SP, #-8]!
    // 0xcf8ad4: ldr             d0, [fp, #0x10]
    // 0xcf8ad8: SaveReg d0
    //     0xcf8ad8: str             d0, [SP, #-8]!
    // 0xcf8adc: r0 = scale()
    //     0xcf8adc: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf8ae0: add             SP, SP, #0x10
    // 0xcf8ae4: mov             x1, x0
    // 0xcf8ae8: ldr             x0, [fp, #0x18]
    // 0xcf8aec: stur            x1, [fp, #-0x18]
    // 0xcf8af0: LoadField: r2 = r0->field_b
    //     0xcf8af0: ldur            w2, [x0, #0xb]
    // 0xcf8af4: DecompressPointer r2
    //     0xcf8af4: add             x2, x2, HEAP, lsl #32
    // 0xcf8af8: stur            x2, [fp, #-0x10]
    // 0xcf8afc: r0 = LoadClassIdInstr(r2)
    //     0xcf8afc: ldur            x0, [x2, #-1]
    //     0xcf8b00: ubfx            x0, x0, #0xc, #0x14
    // 0xcf8b04: lsl             x0, x0, #1
    // 0xcf8b08: r17 = 4224
    //     0xcf8b08: mov             x17, #0x1080
    // 0xcf8b0c: cmp             w0, w17
    // 0xcf8b10: b.ne            #0xcf8bf4
    // 0xcf8b14: ldr             d0, [fp, #0x10]
    // 0xcf8b18: LoadField: r0 = r2->field_7
    //     0xcf8b18: ldur            w0, [x2, #7]
    // 0xcf8b1c: DecompressPointer r0
    //     0xcf8b1c: add             x0, x0, HEAP, lsl #32
    // 0xcf8b20: r3 = inline_Allocate_Double()
    //     0xcf8b20: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xcf8b24: add             x3, x3, #0x10
    //     0xcf8b28: cmp             x4, x3
    //     0xcf8b2c: b.ls            #0xcf8c84
    //     0xcf8b30: str             x3, [THR, #0x60]  ; THR::top
    //     0xcf8b34: sub             x3, x3, #0xf
    //     0xcf8b38: mov             x4, #0xd108
    //     0xcf8b3c: movk            x4, #3, lsl #16
    //     0xcf8b40: stur            x4, [x3, #-1]
    // 0xcf8b44: StoreField: r3->field_7 = d0
    //     0xcf8b44: stur            d0, [x3, #7]
    // 0xcf8b48: stur            x3, [fp, #-8]
    // 0xcf8b4c: stp             x3, x0, [SP, #-0x10]!
    // 0xcf8b50: r0 = *()
    //     0xcf8b50: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8b54: add             SP, SP, #0x10
    // 0xcf8b58: mov             x1, x0
    // 0xcf8b5c: ldur            x0, [fp, #-0x10]
    // 0xcf8b60: stur            x1, [fp, #-0x20]
    // 0xcf8b64: LoadField: r2 = r0->field_b
    //     0xcf8b64: ldur            w2, [x0, #0xb]
    // 0xcf8b68: DecompressPointer r2
    //     0xcf8b68: add             x2, x2, HEAP, lsl #32
    // 0xcf8b6c: ldur            x16, [fp, #-8]
    // 0xcf8b70: stp             x16, x2, [SP, #-0x10]!
    // 0xcf8b74: r0 = *()
    //     0xcf8b74: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8b78: add             SP, SP, #0x10
    // 0xcf8b7c: mov             x1, x0
    // 0xcf8b80: ldur            x0, [fp, #-0x10]
    // 0xcf8b84: stur            x1, [fp, #-0x28]
    // 0xcf8b88: LoadField: r2 = r0->field_f
    //     0xcf8b88: ldur            w2, [x0, #0xf]
    // 0xcf8b8c: DecompressPointer r2
    //     0xcf8b8c: add             x2, x2, HEAP, lsl #32
    // 0xcf8b90: ldur            x16, [fp, #-8]
    // 0xcf8b94: stp             x16, x2, [SP, #-0x10]!
    // 0xcf8b98: r0 = *()
    //     0xcf8b98: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8b9c: add             SP, SP, #0x10
    // 0xcf8ba0: mov             x1, x0
    // 0xcf8ba4: ldur            x0, [fp, #-0x10]
    // 0xcf8ba8: stur            x1, [fp, #-0x30]
    // 0xcf8bac: LoadField: r2 = r0->field_13
    //     0xcf8bac: ldur            w2, [x0, #0x13]
    // 0xcf8bb0: DecompressPointer r2
    //     0xcf8bb0: add             x2, x2, HEAP, lsl #32
    // 0xcf8bb4: ldur            x16, [fp, #-8]
    // 0xcf8bb8: stp             x16, x2, [SP, #-0x10]!
    // 0xcf8bbc: r0 = *()
    //     0xcf8bbc: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8bc0: add             SP, SP, #0x10
    // 0xcf8bc4: stur            x0, [fp, #-8]
    // 0xcf8bc8: r0 = BorderRadius()
    //     0xcf8bc8: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xcf8bcc: mov             x1, x0
    // 0xcf8bd0: ldur            x0, [fp, #-0x20]
    // 0xcf8bd4: StoreField: r1->field_7 = r0
    //     0xcf8bd4: stur            w0, [x1, #7]
    // 0xcf8bd8: ldur            x0, [fp, #-0x28]
    // 0xcf8bdc: StoreField: r1->field_b = r0
    //     0xcf8bdc: stur            w0, [x1, #0xb]
    // 0xcf8be0: ldur            x0, [fp, #-0x30]
    // 0xcf8be4: StoreField: r1->field_f = r0
    //     0xcf8be4: stur            w0, [x1, #0xf]
    // 0xcf8be8: ldur            x0, [fp, #-8]
    // 0xcf8bec: StoreField: r1->field_13 = r0
    //     0xcf8bec: stur            w0, [x1, #0x13]
    // 0xcf8bf0: b               #0xcf8c48
    // 0xcf8bf4: ldr             d0, [fp, #0x10]
    // 0xcf8bf8: mov             x0, x2
    // 0xcf8bfc: r1 = inline_Allocate_Double()
    //     0xcf8bfc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcf8c00: add             x1, x1, #0x10
    //     0xcf8c04: cmp             x2, x1
    //     0xcf8c08: b.ls            #0xcf8ca8
    //     0xcf8c0c: str             x1, [THR, #0x60]  ; THR::top
    //     0xcf8c10: sub             x1, x1, #0xf
    //     0xcf8c14: mov             x2, #0xd108
    //     0xcf8c18: movk            x2, #3, lsl #16
    //     0xcf8c1c: stur            x2, [x1, #-1]
    // 0xcf8c20: StoreField: r1->field_7 = d0
    //     0xcf8c20: stur            d0, [x1, #7]
    // 0xcf8c24: r2 = LoadClassIdInstr(r0)
    //     0xcf8c24: ldur            x2, [x0, #-1]
    //     0xcf8c28: ubfx            x2, x2, #0xc, #0x14
    // 0xcf8c2c: stp             x1, x0, [SP, #-0x10]!
    // 0xcf8c30: mov             x0, x2
    // 0xcf8c34: r0 = GDT[cid_x0 + -0xfd3]()
    //     0xcf8c34: sub             lr, x0, #0xfd3
    //     0xcf8c38: ldr             lr, [x21, lr, lsl #3]
    //     0xcf8c3c: blr             lr
    // 0xcf8c40: add             SP, SP, #0x10
    // 0xcf8c44: mov             x1, x0
    // 0xcf8c48: ldr             d0, [fp, #0x10]
    // 0xcf8c4c: ldur            x0, [fp, #-0x18]
    // 0xcf8c50: stur            x1, [fp, #-8]
    // 0xcf8c54: r0 = _StadiumToRoundedRectangleBorder()
    //     0xcf8c54: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0xcf8c58: ldur            x1, [fp, #-8]
    // 0xcf8c5c: StoreField: r0->field_b = r1
    //     0xcf8c5c: stur            w1, [x0, #0xb]
    // 0xcf8c60: ldr             d0, [fp, #0x10]
    // 0xcf8c64: StoreField: r0->field_f = d0
    //     0xcf8c64: stur            d0, [x0, #0xf]
    // 0xcf8c68: ldur            x1, [fp, #-0x18]
    // 0xcf8c6c: StoreField: r0->field_7 = r1
    //     0xcf8c6c: stur            w1, [x0, #7]
    // 0xcf8c70: LeaveFrame
    //     0xcf8c70: mov             SP, fp
    //     0xcf8c74: ldp             fp, lr, [SP], #0x10
    // 0xcf8c78: ret
    //     0xcf8c78: ret             
    // 0xcf8c7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8c7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8c80: b               #0xcf8ac4
    // 0xcf8c84: SaveReg d0
    //     0xcf8c84: str             q0, [SP, #-0x10]!
    // 0xcf8c88: stp             x1, x2, [SP, #-0x10]!
    // 0xcf8c8c: SaveReg r0
    //     0xcf8c8c: str             x0, [SP, #-8]!
    // 0xcf8c90: r0 = AllocateDouble()
    //     0xcf8c90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf8c94: mov             x3, x0
    // 0xcf8c98: RestoreReg r0
    //     0xcf8c98: ldr             x0, [SP], #8
    // 0xcf8c9c: ldp             x1, x2, [SP], #0x10
    // 0xcf8ca0: RestoreReg d0
    //     0xcf8ca0: ldr             q0, [SP], #0x10
    // 0xcf8ca4: b               #0xcf8b44
    // 0xcf8ca8: SaveReg d0
    //     0xcf8ca8: str             q0, [SP, #-0x10]!
    // 0xcf8cac: SaveReg r0
    //     0xcf8cac: str             x0, [SP, #-8]!
    // 0xcf8cb0: r0 = AllocateDouble()
    //     0xcf8cb0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf8cb4: mov             x1, x0
    // 0xcf8cb8: RestoreReg r0
    //     0xcf8cb8: ldr             x0, [SP], #8
    // 0xcf8cbc: RestoreReg d0
    //     0xcf8cbc: ldr             q0, [SP], #0x10
    // 0xcf8cc0: b               #0xcf8c20
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xcf8ea0, size: 0x6c
    // 0xcf8ea0: EnterFrame
    //     0xcf8ea0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8ea4: mov             fp, SP
    // 0xcf8ea8: AllocStack(0x18)
    //     0xcf8ea8: sub             SP, SP, #0x18
    // 0xcf8eac: ldr             x0, [fp, #0x10]
    // 0xcf8eb0: cmp             w0, NULL
    // 0xcf8eb4: b.ne            #0xcf8ec8
    // 0xcf8eb8: ldr             x1, [fp, #0x18]
    // 0xcf8ebc: LoadField: r0 = r1->field_7
    //     0xcf8ebc: ldur            w0, [x1, #7]
    // 0xcf8ec0: DecompressPointer r0
    //     0xcf8ec0: add             x0, x0, HEAP, lsl #32
    // 0xcf8ec4: b               #0xcf8ecc
    // 0xcf8ec8: ldr             x1, [fp, #0x18]
    // 0xcf8ecc: stur            x0, [fp, #-0x10]
    // 0xcf8ed0: LoadField: r2 = r1->field_b
    //     0xcf8ed0: ldur            w2, [x1, #0xb]
    // 0xcf8ed4: DecompressPointer r2
    //     0xcf8ed4: add             x2, x2, HEAP, lsl #32
    // 0xcf8ed8: stur            x2, [fp, #-8]
    // 0xcf8edc: LoadField: d0 = r1->field_f
    //     0xcf8edc: ldur            d0, [x1, #0xf]
    // 0xcf8ee0: stur            d0, [fp, #-0x18]
    // 0xcf8ee4: r0 = _StadiumToRoundedRectangleBorder()
    //     0xcf8ee4: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0xcf8ee8: ldur            x1, [fp, #-8]
    // 0xcf8eec: StoreField: r0->field_b = r1
    //     0xcf8eec: stur            w1, [x0, #0xb]
    // 0xcf8ef0: ldur            d0, [fp, #-0x18]
    // 0xcf8ef4: StoreField: r0->field_f = d0
    //     0xcf8ef4: stur            d0, [x0, #0xf]
    // 0xcf8ef8: ldur            x1, [fp, #-0x10]
    // 0xcf8efc: StoreField: r0->field_7 = r1
    //     0xcf8efc: stur            w1, [x0, #7]
    // 0xcf8f00: LeaveFrame
    //     0xcf8f00: mov             SP, fp
    //     0xcf8f04: ldp             fp, lr, [SP], #0x10
    // 0xcf8f08: ret
    //     0xcf8f08: ret             
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0xcfa728, size: 0x124
    // 0xcfa728: EnterFrame
    //     0xcfa728: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa72c: mov             fp, SP
    // 0xcfa730: AllocStack(0x20)
    //     0xcfa730: sub             SP, SP, #0x20
    // 0xcfa734: SetupParameters(_StadiumToRoundedRectangleBorder this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic textDirection = Null /* r0, fp-0x8 */})
    //     0xcfa734: mov             x0, x4
    //     0xcfa738: ldur            w1, [x0, #0x13]
    //     0xcfa73c: add             x1, x1, HEAP, lsl #32
    //     0xcfa740: sub             x2, x1, #4
    //     0xcfa744: add             x3, fp, w2, sxtw #2
    //     0xcfa748: ldr             x3, [x3, #0x18]
    //     0xcfa74c: stur            x3, [fp, #-0x18]
    //     0xcfa750: add             x4, fp, w2, sxtw #2
    //     0xcfa754: ldr             x4, [x4, #0x10]
    //     0xcfa758: stur            x4, [fp, #-0x10]
    //     0xcfa75c: ldur            w2, [x0, #0x1f]
    //     0xcfa760: add             x2, x2, HEAP, lsl #32
    //     0xcfa764: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0xcfa768: ldr             x16, [x16, #0xf10]
    //     0xcfa76c: cmp             w2, w16
    //     0xcfa770: b.ne            #0xcfa790
    //     0xcfa774: ldur            w2, [x0, #0x23]
    //     0xcfa778: add             x2, x2, HEAP, lsl #32
    //     0xcfa77c: sub             w0, w1, w2
    //     0xcfa780: add             x1, fp, w0, sxtw #2
    //     0xcfa784: ldr             x1, [x1, #8]
    //     0xcfa788: mov             x0, x1
    //     0xcfa78c: b               #0xcfa794
    //     0xcfa790: mov             x0, NULL
    //     0xcfa794: stur            x0, [fp, #-8]
    // 0xcfa798: CheckStackOverflow
    //     0xcfa798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa79c: cmp             SP, x16
    //     0xcfa7a0: b.ls            #0xcfa840
    // 0xcfa7a4: r0 = Path()
    //     0xcfa7a4: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcfa7a8: stur            x0, [fp, #-0x20]
    // 0xcfa7ac: SaveReg r0
    //     0xcfa7ac: str             x0, [SP, #-8]!
    // 0xcfa7b0: r0 = _constructor()
    //     0xcfa7b0: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcfa7b4: add             SP, SP, #8
    // 0xcfa7b8: ldur            x16, [fp, #-0x18]
    // 0xcfa7bc: ldur            lr, [fp, #-0x10]
    // 0xcfa7c0: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa7c4: r0 = _adjustBorderRadius()
    //     0xcfa7c4: bl              #0x718a8c  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToRoundedRectangleBorder::_adjustBorderRadius
    // 0xcfa7c8: add             SP, SP, #0x10
    // 0xcfa7cc: r1 = LoadClassIdInstr(r0)
    //     0xcfa7cc: ldur            x1, [x0, #-1]
    //     0xcfa7d0: ubfx            x1, x1, #0xc, #0x14
    // 0xcfa7d4: lsl             x1, x1, #1
    // 0xcfa7d8: r17 = 4224
    //     0xcfa7d8: mov             x17, #0x1080
    // 0xcfa7dc: cmp             w1, w17
    // 0xcfa7e0: b.eq            #0xcfa808
    // 0xcfa7e4: r1 = LoadClassIdInstr(r0)
    //     0xcfa7e4: ldur            x1, [x0, #-1]
    //     0xcfa7e8: ubfx            x1, x1, #0xc, #0x14
    // 0xcfa7ec: ldur            x16, [fp, #-8]
    // 0xcfa7f0: stp             x16, x0, [SP, #-0x10]!
    // 0xcfa7f4: mov             x0, x1
    // 0xcfa7f8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xcfa7f8: sub             lr, x0, #1, lsl #12
    //     0xcfa7fc: ldr             lr, [x21, lr, lsl #3]
    //     0xcfa800: blr             lr
    // 0xcfa804: add             SP, SP, #0x10
    // 0xcfa808: cmp             w0, NULL
    // 0xcfa80c: b.eq            #0xcfa848
    // 0xcfa810: ldur            x16, [fp, #-0x10]
    // 0xcfa814: stp             x16, x0, [SP, #-0x10]!
    // 0xcfa818: r0 = toRRect()
    //     0xcfa818: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xcfa81c: add             SP, SP, #0x10
    // 0xcfa820: ldur            x16, [fp, #-0x20]
    // 0xcfa824: stp             x0, x16, [SP, #-0x10]!
    // 0xcfa828: r0 = addRRect()
    //     0xcfa828: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0xcfa82c: add             SP, SP, #0x10
    // 0xcfa830: ldur            x0, [fp, #-0x20]
    // 0xcfa834: LeaveFrame
    //     0xcfa834: mov             SP, fp
    //     0xcfa838: ldp             fp, lr, [SP], #0x10
    // 0xcfa83c: ret
    //     0xcfa83c: ret             
    // 0xcfa840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa840: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa844: b               #0xcfa7a4
    // 0xcfa848: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcfa848: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2176, size: 0x1c, field offset: 0xc
//   const constructor, 
class _StadiumToCircleBorder extends OutlinedBorder {

  _ lerpTo(/* No info */) {
    // ** addr: 0x70f148, size: 0x3d0
    // 0x70f148: EnterFrame
    //     0x70f148: stp             fp, lr, [SP, #-0x10]!
    //     0x70f14c: mov             fp, SP
    // 0x70f150: AllocStack(0x28)
    //     0x70f150: sub             SP, SP, #0x28
    // 0x70f154: CheckStackOverflow
    //     0x70f154: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70f158: cmp             SP, x16
    //     0x70f15c: b.ls            #0x70f454
    // 0x70f160: ldr             x0, [fp, #0x18]
    // 0x70f164: r1 = LoadClassIdInstr(r0)
    //     0x70f164: ldur            x1, [x0, #-1]
    //     0x70f168: ubfx            x1, x1, #0xc, #0x14
    // 0x70f16c: lsl             x1, x1, #1
    // 0x70f170: r17 = 4354
    //     0x70f170: mov             x17, #0x1102
    // 0x70f174: cmp             w1, w17
    // 0x70f178: b.ne            #0x70f1f4
    // 0x70f17c: ldr             x1, [fp, #0x20]
    // 0x70f180: ldr             d0, [fp, #0x10]
    // 0x70f184: LoadField: r2 = r1->field_7
    //     0x70f184: ldur            w2, [x1, #7]
    // 0x70f188: DecompressPointer r2
    //     0x70f188: add             x2, x2, HEAP, lsl #32
    // 0x70f18c: LoadField: r3 = r0->field_7
    //     0x70f18c: ldur            w3, [x0, #7]
    // 0x70f190: DecompressPointer r3
    //     0x70f190: add             x3, x3, HEAP, lsl #32
    // 0x70f194: stp             x3, x2, [SP, #-0x10]!
    // 0x70f198: SaveReg d0
    //     0x70f198: str             d0, [SP, #-8]!
    // 0x70f19c: r0 = lerp()
    //     0x70f19c: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70f1a0: add             SP, SP, #0x18
    // 0x70f1a4: ldr             x2, [fp, #0x20]
    // 0x70f1a8: stur            x0, [fp, #-8]
    // 0x70f1ac: LoadField: d0 = r2->field_b
    //     0x70f1ac: ldur            d0, [x2, #0xb]
    // 0x70f1b0: ldr             d2, [fp, #0x10]
    // 0x70f1b4: d1 = 1.000000
    //     0x70f1b4: fmov            d1, #1.00000000
    // 0x70f1b8: fsub            d3, d1, d2
    // 0x70f1bc: fmul            d1, d0, d3
    // 0x70f1c0: stur            d1, [fp, #-0x28]
    // 0x70f1c4: LoadField: d0 = r2->field_13
    //     0x70f1c4: ldur            d0, [x2, #0x13]
    // 0x70f1c8: stur            d0, [fp, #-0x20]
    // 0x70f1cc: r0 = _StadiumToCircleBorder()
    //     0x70f1cc: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x70f1d0: ldur            d0, [fp, #-0x28]
    // 0x70f1d4: StoreField: r0->field_b = d0
    //     0x70f1d4: stur            d0, [x0, #0xb]
    // 0x70f1d8: ldur            d0, [fp, #-0x20]
    // 0x70f1dc: StoreField: r0->field_13 = d0
    //     0x70f1dc: stur            d0, [x0, #0x13]
    // 0x70f1e0: ldur            x1, [fp, #-8]
    // 0x70f1e4: StoreField: r0->field_7 = r1
    //     0x70f1e4: stur            w1, [x0, #7]
    // 0x70f1e8: LeaveFrame
    //     0x70f1e8: mov             SP, fp
    //     0x70f1ec: ldp             fp, lr, [SP], #0x10
    // 0x70f1f0: ret
    //     0x70f1f0: ret             
    // 0x70f1f4: ldr             x2, [fp, #0x20]
    // 0x70f1f8: ldr             d2, [fp, #0x10]
    // 0x70f1fc: d1 = 1.000000
    //     0x70f1fc: fmov            d1, #1.00000000
    // 0x70f200: r17 = 4360
    //     0x70f200: mov             x17, #0x1108
    // 0x70f204: cmp             w1, w17
    // 0x70f208: b.ne            #0x70f288
    // 0x70f20c: LoadField: r1 = r2->field_7
    //     0x70f20c: ldur            w1, [x2, #7]
    // 0x70f210: DecompressPointer r1
    //     0x70f210: add             x1, x1, HEAP, lsl #32
    // 0x70f214: LoadField: r3 = r0->field_7
    //     0x70f214: ldur            w3, [x0, #7]
    // 0x70f218: DecompressPointer r3
    //     0x70f218: add             x3, x3, HEAP, lsl #32
    // 0x70f21c: stp             x3, x1, [SP, #-0x10]!
    // 0x70f220: SaveReg d2
    //     0x70f220: str             d2, [SP, #-8]!
    // 0x70f224: r0 = lerp()
    //     0x70f224: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70f228: add             SP, SP, #0x18
    // 0x70f22c: mov             x1, x0
    // 0x70f230: ldr             x0, [fp, #0x20]
    // 0x70f234: stur            x1, [fp, #-8]
    // 0x70f238: LoadField: d0 = r0->field_b
    //     0x70f238: ldur            d0, [x0, #0xb]
    // 0x70f23c: d1 = 1.000000
    //     0x70f23c: fmov            d1, #1.00000000
    // 0x70f240: fsub            d2, d1, d0
    // 0x70f244: ldr             d1, [fp, #0x10]
    // 0x70f248: fmul            d3, d2, d1
    // 0x70f24c: fadd            d1, d0, d3
    // 0x70f250: ldr             x2, [fp, #0x18]
    // 0x70f254: stur            d1, [fp, #-0x28]
    // 0x70f258: LoadField: d0 = r2->field_b
    //     0x70f258: ldur            d0, [x2, #0xb]
    // 0x70f25c: stur            d0, [fp, #-0x20]
    // 0x70f260: r0 = _StadiumToCircleBorder()
    //     0x70f260: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x70f264: ldur            d0, [fp, #-0x28]
    // 0x70f268: StoreField: r0->field_b = d0
    //     0x70f268: stur            d0, [x0, #0xb]
    // 0x70f26c: ldur            d0, [fp, #-0x20]
    // 0x70f270: StoreField: r0->field_13 = d0
    //     0x70f270: stur            d0, [x0, #0x13]
    // 0x70f274: ldur            x1, [fp, #-8]
    // 0x70f278: StoreField: r0->field_7 = r1
    //     0x70f278: stur            w1, [x0, #7]
    // 0x70f27c: LeaveFrame
    //     0x70f27c: mov             SP, fp
    //     0x70f280: ldp             fp, lr, [SP], #0x10
    // 0x70f284: ret
    //     0x70f284: ret             
    // 0x70f288: mov             x16, x0
    // 0x70f28c: mov             x0, x2
    // 0x70f290: mov             x2, x16
    // 0x70f294: mov             v1.16b, v2.16b
    // 0x70f298: r17 = 4352
    //     0x70f298: mov             x17, #0x1100
    // 0x70f29c: cmp             w1, w17
    // 0x70f2a0: b.ne            #0x70f430
    // 0x70f2a4: LoadField: r1 = r0->field_7
    //     0x70f2a4: ldur            w1, [x0, #7]
    // 0x70f2a8: DecompressPointer r1
    //     0x70f2a8: add             x1, x1, HEAP, lsl #32
    // 0x70f2ac: LoadField: r3 = r2->field_7
    //     0x70f2ac: ldur            w3, [x2, #7]
    // 0x70f2b0: DecompressPointer r3
    //     0x70f2b0: add             x3, x3, HEAP, lsl #32
    // 0x70f2b4: stp             x3, x1, [SP, #-0x10]!
    // 0x70f2b8: SaveReg d1
    //     0x70f2b8: str             d1, [SP, #-8]!
    // 0x70f2bc: r0 = lerp()
    //     0x70f2bc: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70f2c0: add             SP, SP, #0x18
    // 0x70f2c4: mov             x1, x0
    // 0x70f2c8: ldr             x0, [fp, #0x20]
    // 0x70f2cc: stur            x1, [fp, #-0x10]
    // 0x70f2d0: LoadField: d0 = r0->field_b
    //     0x70f2d0: ldur            d0, [x0, #0xb]
    // 0x70f2d4: ldr             x2, [fp, #0x18]
    // 0x70f2d8: LoadField: d1 = r2->field_b
    //     0x70f2d8: ldur            d1, [x2, #0xb]
    // 0x70f2dc: ldr             d2, [fp, #0x10]
    // 0x70f2e0: r3 = inline_Allocate_Double()
    //     0x70f2e0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x70f2e4: add             x3, x3, #0x10
    //     0x70f2e8: cmp             x4, x3
    //     0x70f2ec: b.ls            #0x70f45c
    //     0x70f2f0: str             x3, [THR, #0x60]  ; THR::top
    //     0x70f2f4: sub             x3, x3, #0xf
    //     0x70f2f8: mov             x4, #0xd108
    //     0x70f2fc: movk            x4, #3, lsl #16
    //     0x70f300: stur            x4, [x3, #-1]
    // 0x70f304: StoreField: r3->field_7 = d2
    //     0x70f304: stur            d2, [x3, #7]
    // 0x70f308: stur            x3, [fp, #-8]
    // 0x70f30c: r4 = inline_Allocate_Double()
    //     0x70f30c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x70f310: add             x4, x4, #0x10
    //     0x70f314: cmp             x5, x4
    //     0x70f318: b.ls            #0x70f488
    //     0x70f31c: str             x4, [THR, #0x60]  ; THR::top
    //     0x70f320: sub             x4, x4, #0xf
    //     0x70f324: mov             x5, #0xd108
    //     0x70f328: movk            x5, #3, lsl #16
    //     0x70f32c: stur            x5, [x4, #-1]
    // 0x70f330: StoreField: r4->field_7 = d0
    //     0x70f330: stur            d0, [x4, #7]
    // 0x70f334: r5 = inline_Allocate_Double()
    //     0x70f334: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x70f338: add             x5, x5, #0x10
    //     0x70f33c: cmp             x6, x5
    //     0x70f340: b.ls            #0x70f4ac
    //     0x70f344: str             x5, [THR, #0x60]  ; THR::top
    //     0x70f348: sub             x5, x5, #0xf
    //     0x70f34c: mov             x6, #0xd108
    //     0x70f350: movk            x6, #3, lsl #16
    //     0x70f354: stur            x6, [x5, #-1]
    // 0x70f358: StoreField: r5->field_7 = d1
    //     0x70f358: stur            d1, [x5, #7]
    // 0x70f35c: stp             x5, x4, [SP, #-0x10]!
    // 0x70f360: SaveReg r3
    //     0x70f360: str             x3, [SP, #-8]!
    // 0x70f364: r0 = lerpDouble()
    //     0x70f364: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x70f368: add             SP, SP, #0x18
    // 0x70f36c: stur            x0, [fp, #-0x18]
    // 0x70f370: cmp             w0, NULL
    // 0x70f374: b.eq            #0x70f4d8
    // 0x70f378: ldr             x1, [fp, #0x20]
    // 0x70f37c: LoadField: d0 = r1->field_13
    //     0x70f37c: ldur            d0, [x1, #0x13]
    // 0x70f380: ldr             x2, [fp, #0x18]
    // 0x70f384: LoadField: d1 = r2->field_13
    //     0x70f384: ldur            d1, [x2, #0x13]
    // 0x70f388: r1 = inline_Allocate_Double()
    //     0x70f388: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x70f38c: add             x1, x1, #0x10
    //     0x70f390: cmp             x2, x1
    //     0x70f394: b.ls            #0x70f4dc
    //     0x70f398: str             x1, [THR, #0x60]  ; THR::top
    //     0x70f39c: sub             x1, x1, #0xf
    //     0x70f3a0: mov             x2, #0xd108
    //     0x70f3a4: movk            x2, #3, lsl #16
    //     0x70f3a8: stur            x2, [x1, #-1]
    // 0x70f3ac: StoreField: r1->field_7 = d0
    //     0x70f3ac: stur            d0, [x1, #7]
    // 0x70f3b0: r2 = inline_Allocate_Double()
    //     0x70f3b0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x70f3b4: add             x2, x2, #0x10
    //     0x70f3b8: cmp             x3, x2
    //     0x70f3bc: b.ls            #0x70f4f8
    //     0x70f3c0: str             x2, [THR, #0x60]  ; THR::top
    //     0x70f3c4: sub             x2, x2, #0xf
    //     0x70f3c8: mov             x3, #0xd108
    //     0x70f3cc: movk            x3, #3, lsl #16
    //     0x70f3d0: stur            x3, [x2, #-1]
    // 0x70f3d4: StoreField: r2->field_7 = d1
    //     0x70f3d4: stur            d1, [x2, #7]
    // 0x70f3d8: stp             x2, x1, [SP, #-0x10]!
    // 0x70f3dc: ldur            x16, [fp, #-8]
    // 0x70f3e0: SaveReg r16
    //     0x70f3e0: str             x16, [SP, #-8]!
    // 0x70f3e4: r0 = lerpDouble()
    //     0x70f3e4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x70f3e8: add             SP, SP, #0x18
    // 0x70f3ec: stur            x0, [fp, #-8]
    // 0x70f3f0: cmp             w0, NULL
    // 0x70f3f4: b.eq            #0x70f514
    // 0x70f3f8: ldur            x1, [fp, #-0x18]
    // 0x70f3fc: LoadField: d0 = r1->field_7
    //     0x70f3fc: ldur            d0, [x1, #7]
    // 0x70f400: stur            d0, [fp, #-0x20]
    // 0x70f404: r0 = _StadiumToCircleBorder()
    //     0x70f404: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x70f408: ldur            d0, [fp, #-0x20]
    // 0x70f40c: StoreField: r0->field_b = d0
    //     0x70f40c: stur            d0, [x0, #0xb]
    // 0x70f410: ldur            x1, [fp, #-8]
    // 0x70f414: LoadField: d0 = r1->field_7
    //     0x70f414: ldur            d0, [x1, #7]
    // 0x70f418: StoreField: r0->field_13 = d0
    //     0x70f418: stur            d0, [x0, #0x13]
    // 0x70f41c: ldur            x1, [fp, #-0x10]
    // 0x70f420: StoreField: r0->field_7 = r1
    //     0x70f420: stur            w1, [x0, #7]
    // 0x70f424: LeaveFrame
    //     0x70f424: mov             SP, fp
    //     0x70f428: ldp             fp, lr, [SP], #0x10
    // 0x70f42c: ret
    //     0x70f42c: ret             
    // 0x70f430: mov             x1, x0
    // 0x70f434: mov             v2.16b, v1.16b
    // 0x70f438: stp             x2, x1, [SP, #-0x10]!
    // 0x70f43c: SaveReg d2
    //     0x70f43c: str             d2, [SP, #-8]!
    // 0x70f440: r0 = lerpTo()
    //     0x70f440: bl              #0x70f880  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x70f444: add             SP, SP, #0x18
    // 0x70f448: LeaveFrame
    //     0x70f448: mov             SP, fp
    //     0x70f44c: ldp             fp, lr, [SP], #0x10
    // 0x70f450: ret
    //     0x70f450: ret             
    // 0x70f454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70f454: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70f458: b               #0x70f160
    // 0x70f45c: stp             q1, q2, [SP, #-0x20]!
    // 0x70f460: SaveReg d0
    //     0x70f460: str             q0, [SP, #-0x10]!
    // 0x70f464: stp             x1, x2, [SP, #-0x10]!
    // 0x70f468: SaveReg r0
    //     0x70f468: str             x0, [SP, #-8]!
    // 0x70f46c: r0 = AllocateDouble()
    //     0x70f46c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70f470: mov             x3, x0
    // 0x70f474: RestoreReg r0
    //     0x70f474: ldr             x0, [SP], #8
    // 0x70f478: ldp             x1, x2, [SP], #0x10
    // 0x70f47c: RestoreReg d0
    //     0x70f47c: ldr             q0, [SP], #0x10
    // 0x70f480: ldp             q1, q2, [SP], #0x20
    // 0x70f484: b               #0x70f304
    // 0x70f488: stp             q0, q1, [SP, #-0x20]!
    // 0x70f48c: stp             x2, x3, [SP, #-0x10]!
    // 0x70f490: stp             x0, x1, [SP, #-0x10]!
    // 0x70f494: r0 = AllocateDouble()
    //     0x70f494: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70f498: mov             x4, x0
    // 0x70f49c: ldp             x0, x1, [SP], #0x10
    // 0x70f4a0: ldp             x2, x3, [SP], #0x10
    // 0x70f4a4: ldp             q0, q1, [SP], #0x20
    // 0x70f4a8: b               #0x70f330
    // 0x70f4ac: SaveReg d1
    //     0x70f4ac: str             q1, [SP, #-0x10]!
    // 0x70f4b0: stp             x3, x4, [SP, #-0x10]!
    // 0x70f4b4: stp             x1, x2, [SP, #-0x10]!
    // 0x70f4b8: SaveReg r0
    //     0x70f4b8: str             x0, [SP, #-8]!
    // 0x70f4bc: r0 = AllocateDouble()
    //     0x70f4bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70f4c0: mov             x5, x0
    // 0x70f4c4: RestoreReg r0
    //     0x70f4c4: ldr             x0, [SP], #8
    // 0x70f4c8: ldp             x1, x2, [SP], #0x10
    // 0x70f4cc: ldp             x3, x4, [SP], #0x10
    // 0x70f4d0: RestoreReg d1
    //     0x70f4d0: ldr             q1, [SP], #0x10
    // 0x70f4d4: b               #0x70f358
    // 0x70f4d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70f4d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70f4dc: stp             q0, q1, [SP, #-0x20]!
    // 0x70f4e0: SaveReg r0
    //     0x70f4e0: str             x0, [SP, #-8]!
    // 0x70f4e4: r0 = AllocateDouble()
    //     0x70f4e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70f4e8: mov             x1, x0
    // 0x70f4ec: RestoreReg r0
    //     0x70f4ec: ldr             x0, [SP], #8
    // 0x70f4f0: ldp             q0, q1, [SP], #0x20
    // 0x70f4f4: b               #0x70f3ac
    // 0x70f4f8: SaveReg d1
    //     0x70f4f8: str             q1, [SP, #-0x10]!
    // 0x70f4fc: stp             x0, x1, [SP, #-0x10]!
    // 0x70f500: r0 = AllocateDouble()
    //     0x70f500: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70f504: mov             x2, x0
    // 0x70f508: ldp             x0, x1, [SP], #0x10
    // 0x70f50c: RestoreReg d1
    //     0x70f50c: ldr             q1, [SP], #0x10
    // 0x70f510: b               #0x70f3d4
    // 0x70f514: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70f514: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x71079c, size: 0x3dc
    // 0x71079c: EnterFrame
    //     0x71079c: stp             fp, lr, [SP, #-0x10]!
    //     0x7107a0: mov             fp, SP
    // 0x7107a4: AllocStack(0x28)
    //     0x7107a4: sub             SP, SP, #0x28
    // 0x7107a8: CheckStackOverflow
    //     0x7107a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7107ac: cmp             SP, x16
    //     0x7107b0: b.ls            #0x710ab4
    // 0x7107b4: ldr             x0, [fp, #0x18]
    // 0x7107b8: r1 = LoadClassIdInstr(r0)
    //     0x7107b8: ldur            x1, [x0, #-1]
    //     0x7107bc: ubfx            x1, x1, #0xc, #0x14
    // 0x7107c0: lsl             x1, x1, #1
    // 0x7107c4: r17 = 4354
    //     0x7107c4: mov             x17, #0x1102
    // 0x7107c8: cmp             w1, w17
    // 0x7107cc: b.ne            #0x710840
    // 0x7107d0: ldr             x1, [fp, #0x20]
    // 0x7107d4: ldr             d0, [fp, #0x10]
    // 0x7107d8: LoadField: r2 = r0->field_7
    //     0x7107d8: ldur            w2, [x0, #7]
    // 0x7107dc: DecompressPointer r2
    //     0x7107dc: add             x2, x2, HEAP, lsl #32
    // 0x7107e0: LoadField: r0 = r1->field_7
    //     0x7107e0: ldur            w0, [x1, #7]
    // 0x7107e4: DecompressPointer r0
    //     0x7107e4: add             x0, x0, HEAP, lsl #32
    // 0x7107e8: stp             x0, x2, [SP, #-0x10]!
    // 0x7107ec: SaveReg d0
    //     0x7107ec: str             d0, [SP, #-8]!
    // 0x7107f0: r0 = lerp()
    //     0x7107f0: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x7107f4: add             SP, SP, #0x18
    // 0x7107f8: ldr             x2, [fp, #0x20]
    // 0x7107fc: stur            x0, [fp, #-8]
    // 0x710800: LoadField: d0 = r2->field_b
    //     0x710800: ldur            d0, [x2, #0xb]
    // 0x710804: ldr             d1, [fp, #0x10]
    // 0x710808: fmul            d2, d0, d1
    // 0x71080c: stur            d2, [fp, #-0x28]
    // 0x710810: LoadField: d0 = r2->field_13
    //     0x710810: ldur            d0, [x2, #0x13]
    // 0x710814: stur            d0, [fp, #-0x20]
    // 0x710818: r0 = _StadiumToCircleBorder()
    //     0x710818: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x71081c: ldur            d0, [fp, #-0x28]
    // 0x710820: StoreField: r0->field_b = d0
    //     0x710820: stur            d0, [x0, #0xb]
    // 0x710824: ldur            d0, [fp, #-0x20]
    // 0x710828: StoreField: r0->field_13 = d0
    //     0x710828: stur            d0, [x0, #0x13]
    // 0x71082c: ldur            x1, [fp, #-8]
    // 0x710830: StoreField: r0->field_7 = r1
    //     0x710830: stur            w1, [x0, #7]
    // 0x710834: LeaveFrame
    //     0x710834: mov             SP, fp
    //     0x710838: ldp             fp, lr, [SP], #0x10
    // 0x71083c: ret
    //     0x71083c: ret             
    // 0x710840: ldr             x2, [fp, #0x20]
    // 0x710844: ldr             d1, [fp, #0x10]
    // 0x710848: r17 = 4360
    //     0x710848: mov             x17, #0x1108
    // 0x71084c: cmp             w1, w17
    // 0x710850: b.ne            #0x7108d4
    // 0x710854: LoadField: r1 = r0->field_7
    //     0x710854: ldur            w1, [x0, #7]
    // 0x710858: DecompressPointer r1
    //     0x710858: add             x1, x1, HEAP, lsl #32
    // 0x71085c: LoadField: r3 = r2->field_7
    //     0x71085c: ldur            w3, [x2, #7]
    // 0x710860: DecompressPointer r3
    //     0x710860: add             x3, x3, HEAP, lsl #32
    // 0x710864: stp             x3, x1, [SP, #-0x10]!
    // 0x710868: SaveReg d1
    //     0x710868: str             d1, [SP, #-8]!
    // 0x71086c: r0 = lerp()
    //     0x71086c: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x710870: add             SP, SP, #0x18
    // 0x710874: mov             x1, x0
    // 0x710878: ldr             x0, [fp, #0x20]
    // 0x71087c: stur            x1, [fp, #-8]
    // 0x710880: LoadField: d0 = r0->field_b
    //     0x710880: ldur            d0, [x0, #0xb]
    // 0x710884: d1 = 1.000000
    //     0x710884: fmov            d1, #1.00000000
    // 0x710888: fsub            d2, d1, d0
    // 0x71088c: ldr             d3, [fp, #0x10]
    // 0x710890: fsub            d4, d1, d3
    // 0x710894: fmul            d1, d2, d4
    // 0x710898: fadd            d2, d0, d1
    // 0x71089c: ldr             x2, [fp, #0x18]
    // 0x7108a0: stur            d2, [fp, #-0x28]
    // 0x7108a4: LoadField: d0 = r2->field_b
    //     0x7108a4: ldur            d0, [x2, #0xb]
    // 0x7108a8: stur            d0, [fp, #-0x20]
    // 0x7108ac: r0 = _StadiumToCircleBorder()
    //     0x7108ac: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x7108b0: ldur            d0, [fp, #-0x28]
    // 0x7108b4: StoreField: r0->field_b = d0
    //     0x7108b4: stur            d0, [x0, #0xb]
    // 0x7108b8: ldur            d0, [fp, #-0x20]
    // 0x7108bc: StoreField: r0->field_13 = d0
    //     0x7108bc: stur            d0, [x0, #0x13]
    // 0x7108c0: ldur            x1, [fp, #-8]
    // 0x7108c4: StoreField: r0->field_7 = r1
    //     0x7108c4: stur            w1, [x0, #7]
    // 0x7108c8: LeaveFrame
    //     0x7108c8: mov             SP, fp
    //     0x7108cc: ldp             fp, lr, [SP], #0x10
    // 0x7108d0: ret
    //     0x7108d0: ret             
    // 0x7108d4: mov             x16, x0
    // 0x7108d8: mov             x0, x2
    // 0x7108dc: mov             x2, x16
    // 0x7108e0: mov             v3.16b, v1.16b
    // 0x7108e4: r17 = 4352
    //     0x7108e4: mov             x17, #0x1100
    // 0x7108e8: cmp             w1, w17
    // 0x7108ec: b.ne            #0x710a7c
    // 0x7108f0: LoadField: r1 = r2->field_7
    //     0x7108f0: ldur            w1, [x2, #7]
    // 0x7108f4: DecompressPointer r1
    //     0x7108f4: add             x1, x1, HEAP, lsl #32
    // 0x7108f8: LoadField: r3 = r0->field_7
    //     0x7108f8: ldur            w3, [x0, #7]
    // 0x7108fc: DecompressPointer r3
    //     0x7108fc: add             x3, x3, HEAP, lsl #32
    // 0x710900: stp             x3, x1, [SP, #-0x10]!
    // 0x710904: SaveReg d3
    //     0x710904: str             d3, [SP, #-8]!
    // 0x710908: r0 = lerp()
    //     0x710908: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x71090c: add             SP, SP, #0x18
    // 0x710910: mov             x1, x0
    // 0x710914: ldr             x0, [fp, #0x18]
    // 0x710918: stur            x1, [fp, #-0x10]
    // 0x71091c: LoadField: d0 = r0->field_b
    //     0x71091c: ldur            d0, [x0, #0xb]
    // 0x710920: ldr             x2, [fp, #0x20]
    // 0x710924: LoadField: d1 = r2->field_b
    //     0x710924: ldur            d1, [x2, #0xb]
    // 0x710928: ldr             d2, [fp, #0x10]
    // 0x71092c: r3 = inline_Allocate_Double()
    //     0x71092c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x710930: add             x3, x3, #0x10
    //     0x710934: cmp             x4, x3
    //     0x710938: b.ls            #0x710abc
    //     0x71093c: str             x3, [THR, #0x60]  ; THR::top
    //     0x710940: sub             x3, x3, #0xf
    //     0x710944: mov             x4, #0xd108
    //     0x710948: movk            x4, #3, lsl #16
    //     0x71094c: stur            x4, [x3, #-1]
    // 0x710950: StoreField: r3->field_7 = d2
    //     0x710950: stur            d2, [x3, #7]
    // 0x710954: stur            x3, [fp, #-8]
    // 0x710958: r4 = inline_Allocate_Double()
    //     0x710958: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x71095c: add             x4, x4, #0x10
    //     0x710960: cmp             x5, x4
    //     0x710964: b.ls            #0x710ae8
    //     0x710968: str             x4, [THR, #0x60]  ; THR::top
    //     0x71096c: sub             x4, x4, #0xf
    //     0x710970: mov             x5, #0xd108
    //     0x710974: movk            x5, #3, lsl #16
    //     0x710978: stur            x5, [x4, #-1]
    // 0x71097c: StoreField: r4->field_7 = d0
    //     0x71097c: stur            d0, [x4, #7]
    // 0x710980: r5 = inline_Allocate_Double()
    //     0x710980: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x710984: add             x5, x5, #0x10
    //     0x710988: cmp             x6, x5
    //     0x71098c: b.ls            #0x710b0c
    //     0x710990: str             x5, [THR, #0x60]  ; THR::top
    //     0x710994: sub             x5, x5, #0xf
    //     0x710998: mov             x6, #0xd108
    //     0x71099c: movk            x6, #3, lsl #16
    //     0x7109a0: stur            x6, [x5, #-1]
    // 0x7109a4: StoreField: r5->field_7 = d1
    //     0x7109a4: stur            d1, [x5, #7]
    // 0x7109a8: stp             x5, x4, [SP, #-0x10]!
    // 0x7109ac: SaveReg r3
    //     0x7109ac: str             x3, [SP, #-8]!
    // 0x7109b0: r0 = lerpDouble()
    //     0x7109b0: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x7109b4: add             SP, SP, #0x18
    // 0x7109b8: stur            x0, [fp, #-0x18]
    // 0x7109bc: cmp             w0, NULL
    // 0x7109c0: b.eq            #0x710b38
    // 0x7109c4: ldr             x1, [fp, #0x18]
    // 0x7109c8: LoadField: d0 = r1->field_13
    //     0x7109c8: ldur            d0, [x1, #0x13]
    // 0x7109cc: ldr             x2, [fp, #0x20]
    // 0x7109d0: LoadField: d1 = r2->field_13
    //     0x7109d0: ldur            d1, [x2, #0x13]
    // 0x7109d4: r1 = inline_Allocate_Double()
    //     0x7109d4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x7109d8: add             x1, x1, #0x10
    //     0x7109dc: cmp             x2, x1
    //     0x7109e0: b.ls            #0x710b3c
    //     0x7109e4: str             x1, [THR, #0x60]  ; THR::top
    //     0x7109e8: sub             x1, x1, #0xf
    //     0x7109ec: mov             x2, #0xd108
    //     0x7109f0: movk            x2, #3, lsl #16
    //     0x7109f4: stur            x2, [x1, #-1]
    // 0x7109f8: StoreField: r1->field_7 = d0
    //     0x7109f8: stur            d0, [x1, #7]
    // 0x7109fc: r2 = inline_Allocate_Double()
    //     0x7109fc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x710a00: add             x2, x2, #0x10
    //     0x710a04: cmp             x3, x2
    //     0x710a08: b.ls            #0x710b58
    //     0x710a0c: str             x2, [THR, #0x60]  ; THR::top
    //     0x710a10: sub             x2, x2, #0xf
    //     0x710a14: mov             x3, #0xd108
    //     0x710a18: movk            x3, #3, lsl #16
    //     0x710a1c: stur            x3, [x2, #-1]
    // 0x710a20: StoreField: r2->field_7 = d1
    //     0x710a20: stur            d1, [x2, #7]
    // 0x710a24: stp             x2, x1, [SP, #-0x10]!
    // 0x710a28: ldur            x16, [fp, #-8]
    // 0x710a2c: SaveReg r16
    //     0x710a2c: str             x16, [SP, #-8]!
    // 0x710a30: r0 = lerpDouble()
    //     0x710a30: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x710a34: add             SP, SP, #0x18
    // 0x710a38: stur            x0, [fp, #-8]
    // 0x710a3c: cmp             w0, NULL
    // 0x710a40: b.eq            #0x710b74
    // 0x710a44: ldur            x1, [fp, #-0x18]
    // 0x710a48: LoadField: d0 = r1->field_7
    //     0x710a48: ldur            d0, [x1, #7]
    // 0x710a4c: stur            d0, [fp, #-0x20]
    // 0x710a50: r0 = _StadiumToCircleBorder()
    //     0x710a50: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x710a54: ldur            d0, [fp, #-0x20]
    // 0x710a58: StoreField: r0->field_b = d0
    //     0x710a58: stur            d0, [x0, #0xb]
    // 0x710a5c: ldur            x1, [fp, #-8]
    // 0x710a60: LoadField: d0 = r1->field_7
    //     0x710a60: ldur            d0, [x1, #7]
    // 0x710a64: StoreField: r0->field_13 = d0
    //     0x710a64: stur            d0, [x0, #0x13]
    // 0x710a68: ldur            x1, [fp, #-0x10]
    // 0x710a6c: StoreField: r0->field_7 = r1
    //     0x710a6c: stur            w1, [x0, #7]
    // 0x710a70: LeaveFrame
    //     0x710a70: mov             SP, fp
    //     0x710a74: ldp             fp, lr, [SP], #0x10
    // 0x710a78: ret
    //     0x710a78: ret             
    // 0x710a7c: mov             x1, x2
    // 0x710a80: mov             x2, x0
    // 0x710a84: mov             v2.16b, v3.16b
    // 0x710a88: cmp             w1, NULL
    // 0x710a8c: b.ne            #0x710aa4
    // 0x710a90: SaveReg r2
    //     0x710a90: str             x2, [SP, #-8]!
    // 0x710a94: SaveReg d2
    //     0x710a94: str             d2, [SP, #-8]!
    // 0x710a98: r0 = scale()
    //     0x710a98: bl              #0xcf8a30  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::scale
    // 0x710a9c: add             SP, SP, #0x10
    // 0x710aa0: b               #0x710aa8
    // 0x710aa4: r0 = Null
    //     0x710aa4: mov             x0, NULL
    // 0x710aa8: LeaveFrame
    //     0x710aa8: mov             SP, fp
    //     0x710aac: ldp             fp, lr, [SP], #0x10
    // 0x710ab0: ret
    //     0x710ab0: ret             
    // 0x710ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x710ab4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x710ab8: b               #0x7107b4
    // 0x710abc: stp             q1, q2, [SP, #-0x20]!
    // 0x710ac0: SaveReg d0
    //     0x710ac0: str             q0, [SP, #-0x10]!
    // 0x710ac4: stp             x1, x2, [SP, #-0x10]!
    // 0x710ac8: SaveReg r0
    //     0x710ac8: str             x0, [SP, #-8]!
    // 0x710acc: r0 = AllocateDouble()
    //     0x710acc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710ad0: mov             x3, x0
    // 0x710ad4: RestoreReg r0
    //     0x710ad4: ldr             x0, [SP], #8
    // 0x710ad8: ldp             x1, x2, [SP], #0x10
    // 0x710adc: RestoreReg d0
    //     0x710adc: ldr             q0, [SP], #0x10
    // 0x710ae0: ldp             q1, q2, [SP], #0x20
    // 0x710ae4: b               #0x710950
    // 0x710ae8: stp             q0, q1, [SP, #-0x20]!
    // 0x710aec: stp             x2, x3, [SP, #-0x10]!
    // 0x710af0: stp             x0, x1, [SP, #-0x10]!
    // 0x710af4: r0 = AllocateDouble()
    //     0x710af4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710af8: mov             x4, x0
    // 0x710afc: ldp             x0, x1, [SP], #0x10
    // 0x710b00: ldp             x2, x3, [SP], #0x10
    // 0x710b04: ldp             q0, q1, [SP], #0x20
    // 0x710b08: b               #0x71097c
    // 0x710b0c: SaveReg d1
    //     0x710b0c: str             q1, [SP, #-0x10]!
    // 0x710b10: stp             x3, x4, [SP, #-0x10]!
    // 0x710b14: stp             x1, x2, [SP, #-0x10]!
    // 0x710b18: SaveReg r0
    //     0x710b18: str             x0, [SP, #-8]!
    // 0x710b1c: r0 = AllocateDouble()
    //     0x710b1c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710b20: mov             x5, x0
    // 0x710b24: RestoreReg r0
    //     0x710b24: ldr             x0, [SP], #8
    // 0x710b28: ldp             x1, x2, [SP], #0x10
    // 0x710b2c: ldp             x3, x4, [SP], #0x10
    // 0x710b30: RestoreReg d1
    //     0x710b30: ldr             q1, [SP], #0x10
    // 0x710b34: b               #0x7109a4
    // 0x710b38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x710b38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x710b3c: stp             q0, q1, [SP, #-0x20]!
    // 0x710b40: SaveReg r0
    //     0x710b40: str             x0, [SP, #-8]!
    // 0x710b44: r0 = AllocateDouble()
    //     0x710b44: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710b48: mov             x1, x0
    // 0x710b4c: RestoreReg r0
    //     0x710b4c: ldr             x0, [SP], #8
    // 0x710b50: ldp             q0, q1, [SP], #0x20
    // 0x710b54: b               #0x7109f8
    // 0x710b58: SaveReg d1
    //     0x710b58: str             q1, [SP, #-0x10]!
    // 0x710b5c: stp             x0, x1, [SP, #-0x10]!
    // 0x710b60: r0 = AllocateDouble()
    //     0x710b60: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710b64: mov             x2, x0
    // 0x710b68: ldp             x0, x1, [SP], #0x10
    // 0x710b6c: RestoreReg d1
    //     0x710b6c: ldr             q1, [SP], #0x10
    // 0x710b70: b               #0x710a20
    // 0x710b74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x710b74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x7185f0, size: 0x84
    // 0x7185f0: EnterFrame
    //     0x7185f0: stp             fp, lr, [SP, #-0x10]!
    //     0x7185f4: mov             fp, SP
    // 0x7185f8: AllocStack(0x8)
    //     0x7185f8: sub             SP, SP, #8
    // 0x7185fc: CheckStackOverflow
    //     0x7185fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x718600: cmp             SP, x16
    //     0x718604: b.ls            #0x71866c
    // 0x718608: ldr             x16, [fp, #0x30]
    // 0x71860c: ldr             lr, [fp, #0x20]
    // 0x718610: stp             lr, x16, [SP, #-0x10]!
    // 0x718614: r0 = _adjustBorderRadius()
    //     0x718614: bl              #0x7187c0  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustBorderRadius
    // 0x718618: add             SP, SP, #0x10
    // 0x71861c: stur            x0, [fp, #-8]
    // 0x718620: ldr             x16, [fp, #0x30]
    // 0x718624: ldr             lr, [fp, #0x20]
    // 0x718628: stp             lr, x16, [SP, #-0x10]!
    // 0x71862c: r0 = _adjustRect()
    //     0x71862c: bl              #0x718674  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustRect
    // 0x718630: add             SP, SP, #0x10
    // 0x718634: ldur            x16, [fp, #-8]
    // 0x718638: stp             x0, x16, [SP, #-0x10]!
    // 0x71863c: r0 = toRRect()
    //     0x71863c: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x718640: add             SP, SP, #0x10
    // 0x718644: ldr             x16, [fp, #0x28]
    // 0x718648: stp             x0, x16, [SP, #-0x10]!
    // 0x71864c: ldr             x16, [fp, #0x18]
    // 0x718650: SaveReg r16
    //     0x718650: str             x16, [SP, #-8]!
    // 0x718654: r0 = drawRRect()
    //     0x718654: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x718658: add             SP, SP, #0x18
    // 0x71865c: r0 = Null
    //     0x71865c: mov             x0, NULL
    // 0x718660: LeaveFrame
    //     0x718660: mov             SP, fp
    //     0x718664: ldp             fp, lr, [SP], #0x10
    // 0x718668: ret
    //     0x718668: ret             
    // 0x71866c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71866c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x718670: b               #0x718608
  }
  _ _adjustRect(/* No info */) {
    // ** addr: 0x718674, size: 0x14c
    // 0x718674: EnterFrame
    //     0x718674: stp             fp, lr, [SP, #-0x10]!
    //     0x718678: mov             fp, SP
    // 0x71867c: AllocStack(0x30)
    //     0x71867c: sub             SP, SP, #0x30
    // 0x718680: d0 = 0.000000
    //     0x718680: eor             v0.16b, v0.16b, v0.16b
    // 0x718684: ldr             x0, [fp, #0x18]
    // 0x718688: LoadField: d1 = r0->field_b
    //     0x718688: ldur            d1, [x0, #0xb]
    // 0x71868c: fcmp            d1, d0
    // 0x718690: b.vs            #0x7186a0
    // 0x718694: b.ne            #0x7186a0
    // 0x718698: ldr             x1, [fp, #0x10]
    // 0x71869c: b               #0x7186d8
    // 0x7186a0: ldr             x1, [fp, #0x10]
    // 0x7186a4: LoadField: d0 = r1->field_17
    //     0x7186a4: ldur            d0, [x1, #0x17]
    // 0x7186a8: stur            d0, [fp, #-0x20]
    // 0x7186ac: LoadField: d2 = r1->field_7
    //     0x7186ac: ldur            d2, [x1, #7]
    // 0x7186b0: stur            d2, [fp, #-0x18]
    // 0x7186b4: fsub            d3, d0, d2
    // 0x7186b8: LoadField: d4 = r1->field_1f
    //     0x7186b8: ldur            d4, [x1, #0x1f]
    // 0x7186bc: stur            d4, [fp, #-0x30]
    // 0x7186c0: LoadField: d5 = r1->field_f
    //     0x7186c0: ldur            d5, [x1, #0xf]
    // 0x7186c4: stur            d5, [fp, #-0x28]
    // 0x7186c8: fsub            d6, d4, d5
    // 0x7186cc: fcmp            d3, d6
    // 0x7186d0: b.vs            #0x7186e8
    // 0x7186d4: b.ne            #0x7186e8
    // 0x7186d8: mov             x0, x1
    // 0x7186dc: LeaveFrame
    //     0x7186dc: mov             SP, fp
    //     0x7186e0: ldp             fp, lr, [SP], #0x10
    // 0x7186e4: ret
    //     0x7186e4: ret             
    // 0x7186e8: fcmp            d3, d6
    // 0x7186ec: b.vs            #0x718754
    // 0x7186f0: b.ge            #0x718754
    // 0x7186f4: d8 = 2.000000
    //     0x7186f4: fmov            d8, #2.00000000
    // 0x7186f8: d7 = 1.000000
    //     0x7186f8: fmov            d7, #1.00000000
    // 0x7186fc: fsub            d9, d6, d3
    // 0x718700: fdiv            d3, d9, d8
    // 0x718704: fmul            d6, d1, d3
    // 0x718708: LoadField: d1 = r0->field_13
    //     0x718708: ldur            d1, [x0, #0x13]
    // 0x71870c: fsub            d3, d7, d1
    // 0x718710: fmul            d1, d6, d3
    // 0x718714: fadd            d3, d5, d1
    // 0x718718: stur            d3, [fp, #-0x10]
    // 0x71871c: fsub            d5, d4, d1
    // 0x718720: stur            d5, [fp, #-8]
    // 0x718724: r0 = Rect()
    //     0x718724: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x718728: ldur            d0, [fp, #-0x18]
    // 0x71872c: StoreField: r0->field_7 = d0
    //     0x71872c: stur            d0, [x0, #7]
    // 0x718730: ldur            d0, [fp, #-0x10]
    // 0x718734: StoreField: r0->field_f = d0
    //     0x718734: stur            d0, [x0, #0xf]
    // 0x718738: ldur            d2, [fp, #-0x20]
    // 0x71873c: StoreField: r0->field_17 = d2
    //     0x71873c: stur            d2, [x0, #0x17]
    // 0x718740: ldur            d0, [fp, #-8]
    // 0x718744: StoreField: r0->field_1f = d0
    //     0x718744: stur            d0, [x0, #0x1f]
    // 0x718748: LeaveFrame
    //     0x718748: mov             SP, fp
    //     0x71874c: ldp             fp, lr, [SP], #0x10
    // 0x718750: ret
    //     0x718750: ret             
    // 0x718754: mov             v31.16b, v2.16b
    // 0x718758: mov             v2.16b, v0.16b
    // 0x71875c: mov             v0.16b, v31.16b
    // 0x718760: d8 = 2.000000
    //     0x718760: fmov            d8, #2.00000000
    // 0x718764: d7 = 1.000000
    //     0x718764: fmov            d7, #1.00000000
    // 0x718768: fsub            d9, d3, d6
    // 0x71876c: fdiv            d3, d9, d8
    // 0x718770: fmul            d6, d1, d3
    // 0x718774: LoadField: d1 = r0->field_13
    //     0x718774: ldur            d1, [x0, #0x13]
    // 0x718778: fsub            d3, d7, d1
    // 0x71877c: fmul            d1, d6, d3
    // 0x718780: fadd            d3, d0, d1
    // 0x718784: stur            d3, [fp, #-0x10]
    // 0x718788: fsub            d0, d2, d1
    // 0x71878c: stur            d0, [fp, #-8]
    // 0x718790: r0 = Rect()
    //     0x718790: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x718794: ldur            d0, [fp, #-0x10]
    // 0x718798: StoreField: r0->field_7 = d0
    //     0x718798: stur            d0, [x0, #7]
    // 0x71879c: ldur            d0, [fp, #-0x28]
    // 0x7187a0: StoreField: r0->field_f = d0
    //     0x7187a0: stur            d0, [x0, #0xf]
    // 0x7187a4: ldur            d0, [fp, #-8]
    // 0x7187a8: StoreField: r0->field_17 = d0
    //     0x7187a8: stur            d0, [x0, #0x17]
    // 0x7187ac: ldur            d0, [fp, #-0x30]
    // 0x7187b0: StoreField: r0->field_1f = d0
    //     0x7187b0: stur            d0, [x0, #0x1f]
    // 0x7187b4: LeaveFrame
    //     0x7187b4: mov             SP, fp
    //     0x7187b8: ldp             fp, lr, [SP], #0x10
    // 0x7187bc: ret
    //     0x7187bc: ret             
  }
  _ _adjustBorderRadius(/* No info */) {
    // ** addr: 0x7187c0, size: 0x1d8
    // 0x7187c0: EnterFrame
    //     0x7187c0: stp             fp, lr, [SP, #-0x10]!
    //     0x7187c4: mov             fp, SP
    // 0x7187c8: AllocStack(0x20)
    //     0x7187c8: sub             SP, SP, #0x20
    // 0x7187cc: CheckStackOverflow
    //     0x7187cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7187d0: cmp             SP, x16
    //     0x7187d4: b.ls            #0x718988
    // 0x7187d8: ldr             x16, [fp, #0x10]
    // 0x7187dc: SaveReg r16
    //     0x7187dc: str             x16, [SP, #-8]!
    // 0x7187e0: r0 = shortestSide()
    //     0x7187e0: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0x7187e4: add             SP, SP, #8
    // 0x7187e8: mov             v1.16b, v0.16b
    // 0x7187ec: d0 = 2.000000
    //     0x7187ec: fmov            d0, #2.00000000
    // 0x7187f0: fdiv            d2, d1, d0
    // 0x7187f4: stur            d2, [fp, #-0x18]
    // 0x7187f8: r0 = Radius()
    //     0x7187f8: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7187fc: ldur            d0, [fp, #-0x18]
    // 0x718800: stur            x0, [fp, #-8]
    // 0x718804: StoreField: r0->field_7 = d0
    //     0x718804: stur            d0, [x0, #7]
    // 0x718808: StoreField: r0->field_f = d0
    //     0x718808: stur            d0, [x0, #0xf]
    // 0x71880c: r0 = BorderRadius()
    //     0x71880c: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x718810: mov             x1, x0
    // 0x718814: ldur            x0, [fp, #-8]
    // 0x718818: stur            x1, [fp, #-0x10]
    // 0x71881c: StoreField: r1->field_7 = r0
    //     0x71881c: stur            w0, [x1, #7]
    // 0x718820: StoreField: r1->field_b = r0
    //     0x718820: stur            w0, [x1, #0xb]
    // 0x718824: StoreField: r1->field_f = r0
    //     0x718824: stur            w0, [x1, #0xf]
    // 0x718828: StoreField: r1->field_13 = r0
    //     0x718828: stur            w0, [x1, #0x13]
    // 0x71882c: ldr             x0, [fp, #0x18]
    // 0x718830: LoadField: d0 = r0->field_13
    //     0x718830: ldur            d0, [x0, #0x13]
    // 0x718834: d1 = 0.000000
    //     0x718834: eor             v1.16b, v1.16b, v1.16b
    // 0x718838: fcmp            d0, d1
    // 0x71883c: b.eq            #0x718978
    // 0x718840: ldr             x2, [fp, #0x10]
    // 0x718844: LoadField: d1 = r2->field_17
    //     0x718844: ldur            d1, [x2, #0x17]
    // 0x718848: LoadField: d2 = r2->field_7
    //     0x718848: ldur            d2, [x2, #7]
    // 0x71884c: fsub            d3, d1, d2
    // 0x718850: LoadField: d1 = r2->field_1f
    //     0x718850: ldur            d1, [x2, #0x1f]
    // 0x718854: LoadField: d2 = r2->field_f
    //     0x718854: ldur            d2, [x2, #0xf]
    // 0x718858: fsub            d4, d1, d2
    // 0x71885c: fcmp            d3, d4
    // 0x718860: b.vs            #0x7188f0
    // 0x718864: b.ge            #0x7188f0
    // 0x718868: d1 = 2.000000
    //     0x718868: fmov            d1, #2.00000000
    // 0x71886c: d2 = 0.500000
    //     0x71886c: fmov            d2, #0.50000000
    // 0x718870: fdiv            d5, d3, d1
    // 0x718874: stur            d5, [fp, #-0x20]
    // 0x718878: fdiv            d3, d0, d1
    // 0x71887c: fadd            d0, d2, d3
    // 0x718880: fmul            d2, d0, d4
    // 0x718884: fdiv            d0, d2, d1
    // 0x718888: stur            d0, [fp, #-0x18]
    // 0x71888c: r0 = Radius()
    //     0x71888c: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x718890: ldur            d0, [fp, #-0x20]
    // 0x718894: stur            x0, [fp, #-8]
    // 0x718898: StoreField: r0->field_7 = d0
    //     0x718898: stur            d0, [x0, #7]
    // 0x71889c: ldur            d0, [fp, #-0x18]
    // 0x7188a0: StoreField: r0->field_f = d0
    //     0x7188a0: stur            d0, [x0, #0xf]
    // 0x7188a4: r0 = BorderRadius()
    //     0x7188a4: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7188a8: mov             x1, x0
    // 0x7188ac: ldur            x0, [fp, #-8]
    // 0x7188b0: StoreField: r1->field_7 = r0
    //     0x7188b0: stur            w0, [x1, #7]
    // 0x7188b4: StoreField: r1->field_b = r0
    //     0x7188b4: stur            w0, [x1, #0xb]
    // 0x7188b8: StoreField: r1->field_f = r0
    //     0x7188b8: stur            w0, [x1, #0xf]
    // 0x7188bc: StoreField: r1->field_13 = r0
    //     0x7188bc: stur            w0, [x1, #0x13]
    // 0x7188c0: ldr             x0, [fp, #0x18]
    // 0x7188c4: LoadField: d0 = r0->field_b
    //     0x7188c4: ldur            d0, [x0, #0xb]
    // 0x7188c8: ldur            x16, [fp, #-0x10]
    // 0x7188cc: stp             x1, x16, [SP, #-0x10]!
    // 0x7188d0: SaveReg d0
    //     0x7188d0: str             d0, [SP, #-8]!
    // 0x7188d4: r0 = lerp()
    //     0x7188d4: bl              #0x70e1fc  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x7188d8: add             SP, SP, #0x18
    // 0x7188dc: cmp             w0, NULL
    // 0x7188e0: b.eq            #0x718990
    // 0x7188e4: LeaveFrame
    //     0x7188e4: mov             SP, fp
    //     0x7188e8: ldp             fp, lr, [SP], #0x10
    // 0x7188ec: ret
    //     0x7188ec: ret             
    // 0x7188f0: d1 = 2.000000
    //     0x7188f0: fmov            d1, #2.00000000
    // 0x7188f4: d2 = 0.500000
    //     0x7188f4: fmov            d2, #0.50000000
    // 0x7188f8: fdiv            d5, d0, d1
    // 0x7188fc: fadd            d0, d2, d5
    // 0x718900: fmul            d2, d0, d3
    // 0x718904: fdiv            d0, d2, d1
    // 0x718908: stur            d0, [fp, #-0x20]
    // 0x71890c: fdiv            d2, d4, d1
    // 0x718910: stur            d2, [fp, #-0x18]
    // 0x718914: r0 = Radius()
    //     0x718914: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x718918: ldur            d0, [fp, #-0x20]
    // 0x71891c: stur            x0, [fp, #-8]
    // 0x718920: StoreField: r0->field_7 = d0
    //     0x718920: stur            d0, [x0, #7]
    // 0x718924: ldur            d0, [fp, #-0x18]
    // 0x718928: StoreField: r0->field_f = d0
    //     0x718928: stur            d0, [x0, #0xf]
    // 0x71892c: r0 = BorderRadius()
    //     0x71892c: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x718930: mov             x1, x0
    // 0x718934: ldur            x0, [fp, #-8]
    // 0x718938: StoreField: r1->field_7 = r0
    //     0x718938: stur            w0, [x1, #7]
    // 0x71893c: StoreField: r1->field_b = r0
    //     0x71893c: stur            w0, [x1, #0xb]
    // 0x718940: StoreField: r1->field_f = r0
    //     0x718940: stur            w0, [x1, #0xf]
    // 0x718944: StoreField: r1->field_13 = r0
    //     0x718944: stur            w0, [x1, #0x13]
    // 0x718948: ldr             x0, [fp, #0x18]
    // 0x71894c: LoadField: d0 = r0->field_b
    //     0x71894c: ldur            d0, [x0, #0xb]
    // 0x718950: ldur            x16, [fp, #-0x10]
    // 0x718954: stp             x1, x16, [SP, #-0x10]!
    // 0x718958: SaveReg d0
    //     0x718958: str             d0, [SP, #-8]!
    // 0x71895c: r0 = lerp()
    //     0x71895c: bl              #0x70e1fc  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x718960: add             SP, SP, #0x18
    // 0x718964: cmp             w0, NULL
    // 0x718968: b.eq            #0x718994
    // 0x71896c: LeaveFrame
    //     0x71896c: mov             SP, fp
    //     0x718970: ldp             fp, lr, [SP], #0x10
    // 0x718974: ret
    //     0x718974: ret             
    // 0x718978: ldur            x0, [fp, #-0x10]
    // 0x71897c: LeaveFrame
    //     0x71897c: mov             SP, fp
    //     0x718980: ldp             fp, lr, [SP], #0x10
    // 0x718984: ret
    //     0x718984: ret             
    // 0x718988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x718988: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71898c: b               #0x7187d8
    // 0x718990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x718990: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x718994: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x718994: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getInnerPath(/* No info */) {
    // ** addr: 0x71b118, size: 0xf8
    // 0x71b118: EnterFrame
    //     0x71b118: stp             fp, lr, [SP, #-0x10]!
    //     0x71b11c: mov             fp, SP
    // 0x71b120: AllocStack(0x20)
    //     0x71b120: sub             SP, SP, #0x20
    // 0x71b124: SetupParameters(_StadiumToCircleBorder this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0x71b124: mov             x0, x4
    //     0x71b128: ldur            w1, [x0, #0x13]
    //     0x71b12c: add             x1, x1, HEAP, lsl #32
    //     0x71b130: sub             x0, x1, #4
    //     0x71b134: add             x1, fp, w0, sxtw #2
    //     0x71b138: ldr             x1, [x1, #0x18]
    //     0x71b13c: stur            x1, [fp, #-0x10]
    //     0x71b140: add             x2, fp, w0, sxtw #2
    //     0x71b144: ldr             x2, [x2, #0x10]
    //     0x71b148: stur            x2, [fp, #-8]
    // 0x71b14c: CheckStackOverflow
    //     0x71b14c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71b150: cmp             SP, x16
    //     0x71b154: b.ls            #0x71b208
    // 0x71b158: r0 = Path()
    //     0x71b158: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x71b15c: stur            x0, [fp, #-0x18]
    // 0x71b160: SaveReg r0
    //     0x71b160: str             x0, [SP, #-8]!
    // 0x71b164: r0 = _constructor()
    //     0x71b164: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x71b168: add             SP, SP, #8
    // 0x71b16c: ldur            x16, [fp, #-0x10]
    // 0x71b170: ldur            lr, [fp, #-8]
    // 0x71b174: stp             lr, x16, [SP, #-0x10]!
    // 0x71b178: r0 = _adjustBorderRadius()
    //     0x71b178: bl              #0x7187c0  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustBorderRadius
    // 0x71b17c: add             SP, SP, #0x10
    // 0x71b180: stur            x0, [fp, #-0x20]
    // 0x71b184: ldur            x16, [fp, #-0x10]
    // 0x71b188: ldur            lr, [fp, #-8]
    // 0x71b18c: stp             lr, x16, [SP, #-0x10]!
    // 0x71b190: r0 = _adjustRect()
    //     0x71b190: bl              #0x718674  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustRect
    // 0x71b194: add             SP, SP, #0x10
    // 0x71b198: ldur            x16, [fp, #-0x20]
    // 0x71b19c: stp             x0, x16, [SP, #-0x10]!
    // 0x71b1a0: r0 = toRRect()
    //     0x71b1a0: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x71b1a4: add             SP, SP, #0x10
    // 0x71b1a8: mov             x1, x0
    // 0x71b1ac: ldur            x0, [fp, #-0x10]
    // 0x71b1b0: LoadField: r2 = r0->field_7
    //     0x71b1b0: ldur            w2, [x0, #7]
    // 0x71b1b4: DecompressPointer r2
    //     0x71b1b4: add             x2, x2, HEAP, lsl #32
    // 0x71b1b8: LoadField: d0 = r2->field_b
    //     0x71b1b8: ldur            d0, [x2, #0xb]
    // 0x71b1bc: LoadField: d1 = r2->field_17
    //     0x71b1bc: ldur            d1, [x2, #0x17]
    // 0x71b1c0: d2 = 1.000000
    //     0x71b1c0: fmov            d2, #1.00000000
    // 0x71b1c4: fadd            d3, d2, d1
    // 0x71b1c8: d1 = 2.000000
    //     0x71b1c8: fmov            d1, #2.00000000
    // 0x71b1cc: fdiv            d4, d3, d1
    // 0x71b1d0: fsub            d1, d2, d4
    // 0x71b1d4: fmul            d2, d0, d1
    // 0x71b1d8: SaveReg r1
    //     0x71b1d8: str             x1, [SP, #-8]!
    // 0x71b1dc: SaveReg d2
    //     0x71b1dc: str             d2, [SP, #-8]!
    // 0x71b1e0: r0 = deflate()
    //     0x71b1e0: bl              #0x6705bc  ; [dart:ui] RRect::deflate
    // 0x71b1e4: add             SP, SP, #0x10
    // 0x71b1e8: ldur            x16, [fp, #-0x18]
    // 0x71b1ec: stp             x0, x16, [SP, #-0x10]!
    // 0x71b1f0: r0 = addRRect()
    //     0x71b1f0: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0x71b1f4: add             SP, SP, #0x10
    // 0x71b1f8: ldur            x0, [fp, #-0x18]
    // 0x71b1fc: LeaveFrame
    //     0x71b1fc: mov             SP, fp
    //     0x71b200: ldp             fp, lr, [SP], #0x10
    // 0x71b204: ret
    //     0x71b204: ret             
    // 0x71b208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71b208: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71b20c: b               #0x71b158
  }
  _ toString(/* No info */) {
    // ** addr: 0xadb5b4, size: 0x2bc
    // 0xadb5b4: EnterFrame
    //     0xadb5b4: stp             fp, lr, [SP, #-0x10]!
    //     0xadb5b8: mov             fp, SP
    // 0xadb5bc: AllocStack(0x10)
    //     0xadb5bc: sub             SP, SP, #0x10
    // 0xadb5c0: d0 = 0.000000
    //     0xadb5c0: eor             v0.16b, v0.16b, v0.16b
    // 0xadb5c4: CheckStackOverflow
    //     0xadb5c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadb5c8: cmp             SP, x16
    //     0xadb5cc: b.ls            #0xadb818
    // 0xadb5d0: ldr             x0, [fp, #0x10]
    // 0xadb5d4: LoadField: d1 = r0->field_13
    //     0xadb5d4: ldur            d1, [x0, #0x13]
    // 0xadb5d8: stur            d1, [fp, #-0x10]
    // 0xadb5dc: fcmp            d1, d0
    // 0xadb5e0: b.eq            #0xadb738
    // 0xadb5e4: r1 = Null
    //     0xadb5e4: mov             x1, NULL
    // 0xadb5e8: r2 = 14
    //     0xadb5e8: mov             x2, #0xe
    // 0xadb5ec: r0 = AllocateArray()
    //     0xadb5ec: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb5f0: stur            x0, [fp, #-8]
    // 0xadb5f4: r17 = "StadiumBorder("
    //     0xadb5f4: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe00] "StadiumBorder("
    //     0xadb5f8: ldr             x17, [x17, #0xe00]
    // 0xadb5fc: StoreField: r0->field_f = r17
    //     0xadb5fc: stur            w17, [x0, #0xf]
    // 0xadb600: ldr             x3, [fp, #0x10]
    // 0xadb604: LoadField: r1 = r3->field_7
    //     0xadb604: ldur            w1, [x3, #7]
    // 0xadb608: DecompressPointer r1
    //     0xadb608: add             x1, x1, HEAP, lsl #32
    // 0xadb60c: StoreField: r0->field_13 = r1
    //     0xadb60c: stur            w1, [x0, #0x13]
    // 0xadb610: r17 = ", "
    //     0xadb610: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb614: StoreField: r0->field_17 = r17
    //     0xadb614: stur            w17, [x0, #0x17]
    // 0xadb618: LoadField: d0 = r3->field_b
    //     0xadb618: ldur            d0, [x3, #0xb]
    // 0xadb61c: d1 = 100.000000
    //     0xadb61c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb620: ldr             d1, [x17, #0x308]
    // 0xadb624: fmul            d2, d0, d1
    // 0xadb628: r1 = inline_Allocate_Double()
    //     0xadb628: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xadb62c: add             x1, x1, #0x10
    //     0xadb630: cmp             x2, x1
    //     0xadb634: b.ls            #0xadb820
    //     0xadb638: str             x1, [THR, #0x60]  ; THR::top
    //     0xadb63c: sub             x1, x1, #0xf
    //     0xadb640: mov             x2, #0xd108
    //     0xadb644: movk            x2, #3, lsl #16
    //     0xadb648: stur            x2, [x1, #-1]
    // 0xadb64c: StoreField: r1->field_7 = d2
    //     0xadb64c: stur            d2, [x1, #7]
    // 0xadb650: SaveReg r1
    //     0xadb650: str             x1, [SP, #-8]!
    // 0xadb654: r1 = 1
    //     0xadb654: mov             x1, #1
    // 0xadb658: SaveReg r1
    //     0xadb658: str             x1, [SP, #-8]!
    // 0xadb65c: r0 = toStringAsFixed()
    //     0xadb65c: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadb660: add             SP, SP, #0x10
    // 0xadb664: ldur            x1, [fp, #-8]
    // 0xadb668: ArrayStore: r1[3] = r0  ; List_4
    //     0xadb668: add             x25, x1, #0x1b
    //     0xadb66c: str             w0, [x25]
    //     0xadb670: tbz             w0, #0, #0xadb68c
    //     0xadb674: ldurb           w16, [x1, #-1]
    //     0xadb678: ldurb           w17, [x0, #-1]
    //     0xadb67c: and             x16, x17, x16, lsr #2
    //     0xadb680: tst             x16, HEAP, lsr #32
    //     0xadb684: b.eq            #0xadb68c
    //     0xadb688: bl              #0xd67e5c
    // 0xadb68c: ldur            x1, [fp, #-8]
    // 0xadb690: r17 = "% of the way to being a CircleBorder that is "
    //     0xadb690: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe08] "% of the way to being a CircleBorder that is "
    //     0xadb694: ldr             x17, [x17, #0xe08]
    // 0xadb698: StoreField: r1->field_1f = r17
    //     0xadb698: stur            w17, [x1, #0x1f]
    // 0xadb69c: ldur            d1, [fp, #-0x10]
    // 0xadb6a0: d0 = 100.000000
    //     0xadb6a0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb6a4: ldr             d0, [x17, #0x308]
    // 0xadb6a8: fmul            d2, d1, d0
    // 0xadb6ac: r0 = inline_Allocate_Double()
    //     0xadb6ac: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xadb6b0: add             x0, x0, #0x10
    //     0xadb6b4: cmp             x2, x0
    //     0xadb6b8: b.ls            #0xadb83c
    //     0xadb6bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xadb6c0: sub             x0, x0, #0xf
    //     0xadb6c4: mov             x2, #0xd108
    //     0xadb6c8: movk            x2, #3, lsl #16
    //     0xadb6cc: stur            x2, [x0, #-1]
    // 0xadb6d0: StoreField: r0->field_7 = d2
    //     0xadb6d0: stur            d2, [x0, #7]
    // 0xadb6d4: SaveReg r0
    //     0xadb6d4: str             x0, [SP, #-8]!
    // 0xadb6d8: r0 = 1
    //     0xadb6d8: mov             x0, #1
    // 0xadb6dc: SaveReg r0
    //     0xadb6dc: str             x0, [SP, #-8]!
    // 0xadb6e0: r0 = toStringAsFixed()
    //     0xadb6e0: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadb6e4: add             SP, SP, #0x10
    // 0xadb6e8: ldur            x1, [fp, #-8]
    // 0xadb6ec: ArrayStore: r1[5] = r0  ; List_4
    //     0xadb6ec: add             x25, x1, #0x23
    //     0xadb6f0: str             w0, [x25]
    //     0xadb6f4: tbz             w0, #0, #0xadb710
    //     0xadb6f8: ldurb           w16, [x1, #-1]
    //     0xadb6fc: ldurb           w17, [x0, #-1]
    //     0xadb700: and             x16, x17, x16, lsr #2
    //     0xadb704: tst             x16, HEAP, lsr #32
    //     0xadb708: b.eq            #0xadb710
    //     0xadb70c: bl              #0xd67e5c
    // 0xadb710: ldur            x0, [fp, #-8]
    // 0xadb714: r17 = "% oval)"
    //     0xadb714: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe10] "% oval)"
    //     0xadb718: ldr             x17, [x17, #0xe10]
    // 0xadb71c: StoreField: r0->field_27 = r17
    //     0xadb71c: stur            w17, [x0, #0x27]
    // 0xadb720: SaveReg r0
    //     0xadb720: str             x0, [SP, #-8]!
    // 0xadb724: r0 = _interpolate()
    //     0xadb724: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb728: add             SP, SP, #8
    // 0xadb72c: LeaveFrame
    //     0xadb72c: mov             SP, fp
    //     0xadb730: ldp             fp, lr, [SP], #0x10
    // 0xadb734: ret
    //     0xadb734: ret             
    // 0xadb738: mov             x3, x0
    // 0xadb73c: d0 = 100.000000
    //     0xadb73c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb740: ldr             d0, [x17, #0x308]
    // 0xadb744: r0 = 1
    //     0xadb744: mov             x0, #1
    // 0xadb748: r1 = Null
    //     0xadb748: mov             x1, NULL
    // 0xadb74c: r2 = 10
    //     0xadb74c: mov             x2, #0xa
    // 0xadb750: r0 = AllocateArray()
    //     0xadb750: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb754: stur            x0, [fp, #-8]
    // 0xadb758: r17 = "StadiumBorder("
    //     0xadb758: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe00] "StadiumBorder("
    //     0xadb75c: ldr             x17, [x17, #0xe00]
    // 0xadb760: StoreField: r0->field_f = r17
    //     0xadb760: stur            w17, [x0, #0xf]
    // 0xadb764: ldr             x1, [fp, #0x10]
    // 0xadb768: LoadField: r2 = r1->field_7
    //     0xadb768: ldur            w2, [x1, #7]
    // 0xadb76c: DecompressPointer r2
    //     0xadb76c: add             x2, x2, HEAP, lsl #32
    // 0xadb770: StoreField: r0->field_13 = r2
    //     0xadb770: stur            w2, [x0, #0x13]
    // 0xadb774: r17 = ", "
    //     0xadb774: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb778: StoreField: r0->field_17 = r17
    //     0xadb778: stur            w17, [x0, #0x17]
    // 0xadb77c: LoadField: d0 = r1->field_b
    //     0xadb77c: ldur            d0, [x1, #0xb]
    // 0xadb780: d1 = 100.000000
    //     0xadb780: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb784: ldr             d1, [x17, #0x308]
    // 0xadb788: fmul            d2, d0, d1
    // 0xadb78c: r1 = inline_Allocate_Double()
    //     0xadb78c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xadb790: add             x1, x1, #0x10
    //     0xadb794: cmp             x2, x1
    //     0xadb798: b.ls            #0xadb854
    //     0xadb79c: str             x1, [THR, #0x60]  ; THR::top
    //     0xadb7a0: sub             x1, x1, #0xf
    //     0xadb7a4: mov             x2, #0xd108
    //     0xadb7a8: movk            x2, #3, lsl #16
    //     0xadb7ac: stur            x2, [x1, #-1]
    // 0xadb7b0: StoreField: r1->field_7 = d2
    //     0xadb7b0: stur            d2, [x1, #7]
    // 0xadb7b4: SaveReg r1
    //     0xadb7b4: str             x1, [SP, #-8]!
    // 0xadb7b8: r1 = 1
    //     0xadb7b8: mov             x1, #1
    // 0xadb7bc: SaveReg r1
    //     0xadb7bc: str             x1, [SP, #-8]!
    // 0xadb7c0: r0 = toStringAsFixed()
    //     0xadb7c0: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadb7c4: add             SP, SP, #0x10
    // 0xadb7c8: ldur            x1, [fp, #-8]
    // 0xadb7cc: ArrayStore: r1[3] = r0  ; List_4
    //     0xadb7cc: add             x25, x1, #0x1b
    //     0xadb7d0: str             w0, [x25]
    //     0xadb7d4: tbz             w0, #0, #0xadb7f0
    //     0xadb7d8: ldurb           w16, [x1, #-1]
    //     0xadb7dc: ldurb           w17, [x0, #-1]
    //     0xadb7e0: and             x16, x17, x16, lsr #2
    //     0xadb7e4: tst             x16, HEAP, lsr #32
    //     0xadb7e8: b.eq            #0xadb7f0
    //     0xadb7ec: bl              #0xd67e5c
    // 0xadb7f0: ldur            x0, [fp, #-8]
    // 0xadb7f4: r17 = "% of the way to being a CircleBorder)"
    //     0xadb7f4: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe18] "% of the way to being a CircleBorder)"
    //     0xadb7f8: ldr             x17, [x17, #0xe18]
    // 0xadb7fc: StoreField: r0->field_1f = r17
    //     0xadb7fc: stur            w17, [x0, #0x1f]
    // 0xadb800: SaveReg r0
    //     0xadb800: str             x0, [SP, #-8]!
    // 0xadb804: r0 = _interpolate()
    //     0xadb804: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb808: add             SP, SP, #8
    // 0xadb80c: LeaveFrame
    //     0xadb80c: mov             SP, fp
    //     0xadb810: ldp             fp, lr, [SP], #0x10
    // 0xadb814: ret
    //     0xadb814: ret             
    // 0xadb818: r0 = StackOverflowSharedWithFPURegs()
    //     0xadb818: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xadb81c: b               #0xadb5d0
    // 0xadb820: stp             q1, q2, [SP, #-0x20]!
    // 0xadb824: SaveReg r0
    //     0xadb824: str             x0, [SP, #-8]!
    // 0xadb828: r0 = AllocateDouble()
    //     0xadb828: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadb82c: mov             x1, x0
    // 0xadb830: RestoreReg r0
    //     0xadb830: ldr             x0, [SP], #8
    // 0xadb834: ldp             q1, q2, [SP], #0x20
    // 0xadb838: b               #0xadb64c
    // 0xadb83c: SaveReg d2
    //     0xadb83c: str             q2, [SP, #-0x10]!
    // 0xadb840: SaveReg r1
    //     0xadb840: str             x1, [SP, #-8]!
    // 0xadb844: r0 = AllocateDouble()
    //     0xadb844: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadb848: RestoreReg r1
    //     0xadb848: ldr             x1, [SP], #8
    // 0xadb84c: RestoreReg d2
    //     0xadb84c: ldr             q2, [SP], #0x10
    // 0xadb850: b               #0xadb6d0
    // 0xadb854: SaveReg d2
    //     0xadb854: str             q2, [SP, #-0x10]!
    // 0xadb858: SaveReg r0
    //     0xadb858: str             x0, [SP, #-8]!
    // 0xadb85c: r0 = AllocateDouble()
    //     0xadb85c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadb860: mov             x1, x0
    // 0xadb864: RestoreReg r0
    //     0xadb864: ldr             x0, [SP], #8
    // 0xadb868: RestoreReg d2
    //     0xadb868: ldr             q2, [SP], #0x10
    // 0xadb86c: b               #0xadb7b0
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd4468, size: 0x110
    // 0xbd4468: EnterFrame
    //     0xbd4468: stp             fp, lr, [SP, #-0x10]!
    //     0xbd446c: mov             fp, SP
    // 0xbd4470: AllocStack(0x28)
    //     0xbd4470: sub             SP, SP, #0x28
    // 0xbd4474: SetupParameters(_StadiumToCircleBorder this /* r1, fp-0x20 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xbd4474: mov             x0, x4
    //     0xbd4478: ldur            w1, [x0, #0x13]
    //     0xbd447c: add             x1, x1, HEAP, lsl #32
    //     0xbd4480: sub             x0, x1, #6
    //     0xbd4484: add             x1, fp, w0, sxtw #2
    //     0xbd4488: ldr             x1, [x1, #0x20]
    //     0xbd448c: stur            x1, [fp, #-0x20]
    //     0xbd4490: add             x2, fp, w0, sxtw #2
    //     0xbd4494: ldr             x2, [x2, #0x18]
    //     0xbd4498: stur            x2, [fp, #-0x18]
    //     0xbd449c: add             x3, fp, w0, sxtw #2
    //     0xbd44a0: ldr             x3, [x3, #0x10]
    //     0xbd44a4: stur            x3, [fp, #-0x10]
    // 0xbd44a8: CheckStackOverflow
    //     0xbd44a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd44ac: cmp             SP, x16
    //     0xbd44b0: b.ls            #0xbd4570
    // 0xbd44b4: LoadField: r0 = r1->field_7
    //     0xbd44b4: ldur            w0, [x1, #7]
    // 0xbd44b8: DecompressPointer r0
    //     0xbd44b8: add             x0, x0, HEAP, lsl #32
    // 0xbd44bc: stur            x0, [fp, #-8]
    // 0xbd44c0: LoadField: r4 = r0->field_13
    //     0xbd44c0: ldur            w4, [x0, #0x13]
    // 0xbd44c4: DecompressPointer r4
    //     0xbd44c4: add             x4, x4, HEAP, lsl #32
    // 0xbd44c8: LoadField: r5 = r4->field_7
    //     0xbd44c8: ldur            x5, [x4, #7]
    // 0xbd44cc: cmp             x5, #0
    // 0xbd44d0: b.le            #0xbd4560
    // 0xbd44d4: stp             x3, x1, [SP, #-0x10]!
    // 0xbd44d8: r0 = _adjustBorderRadius()
    //     0xbd44d8: bl              #0x7187c0  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustBorderRadius
    // 0xbd44dc: add             SP, SP, #0x10
    // 0xbd44e0: stur            x0, [fp, #-0x28]
    // 0xbd44e4: ldur            x16, [fp, #-0x20]
    // 0xbd44e8: ldur            lr, [fp, #-0x10]
    // 0xbd44ec: stp             lr, x16, [SP, #-0x10]!
    // 0xbd44f0: r0 = _adjustRect()
    //     0xbd44f0: bl              #0x718674  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustRect
    // 0xbd44f4: add             SP, SP, #0x10
    // 0xbd44f8: ldur            x16, [fp, #-0x28]
    // 0xbd44fc: stp             x0, x16, [SP, #-0x10]!
    // 0xbd4500: r0 = toRRect()
    //     0xbd4500: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbd4504: add             SP, SP, #0x10
    // 0xbd4508: mov             x1, x0
    // 0xbd450c: ldur            x0, [fp, #-8]
    // 0xbd4510: LoadField: d0 = r0->field_b
    //     0xbd4510: ldur            d0, [x0, #0xb]
    // 0xbd4514: LoadField: d1 = r0->field_17
    //     0xbd4514: ldur            d1, [x0, #0x17]
    // 0xbd4518: fmul            d2, d0, d1
    // 0xbd451c: d0 = 2.000000
    //     0xbd451c: fmov            d0, #2.00000000
    // 0xbd4520: fdiv            d1, d2, d0
    // 0xbd4524: SaveReg r1
    //     0xbd4524: str             x1, [SP, #-8]!
    // 0xbd4528: SaveReg d1
    //     0xbd4528: str             d1, [SP, #-8]!
    // 0xbd452c: r0 = inflate()
    //     0xbd452c: bl              #0x65ffe4  ; [dart:ui] RRect::inflate
    // 0xbd4530: add             SP, SP, #0x10
    // 0xbd4534: stur            x0, [fp, #-0x10]
    // 0xbd4538: ldur            x16, [fp, #-8]
    // 0xbd453c: SaveReg r16
    //     0xbd453c: str             x16, [SP, #-8]!
    // 0xbd4540: r0 = toPaint()
    //     0xbd4540: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd4544: add             SP, SP, #8
    // 0xbd4548: ldur            x16, [fp, #-0x18]
    // 0xbd454c: ldur            lr, [fp, #-0x10]
    // 0xbd4550: stp             lr, x16, [SP, #-0x10]!
    // 0xbd4554: SaveReg r0
    //     0xbd4554: str             x0, [SP, #-8]!
    // 0xbd4558: r0 = drawRRect()
    //     0xbd4558: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xbd455c: add             SP, SP, #0x18
    // 0xbd4560: r0 = Null
    //     0xbd4560: mov             x0, NULL
    // 0xbd4564: LeaveFrame
    //     0xbd4564: mov             SP, fp
    //     0xbd4568: ldp             fp, lr, [SP], #0x10
    // 0xbd456c: ret
    //     0xbd456c: ret             
    // 0xbd4570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd4570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd4574: b               #0xbd44b4
  }
  _ ==(/* No info */) {
    // ** addr: 0xc99d9c, size: 0x124
    // 0xc99d9c: EnterFrame
    //     0xc99d9c: stp             fp, lr, [SP, #-0x10]!
    //     0xc99da0: mov             fp, SP
    // 0xc99da4: CheckStackOverflow
    //     0xc99da4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc99da8: cmp             SP, x16
    //     0xc99dac: b.ls            #0xc99eb8
    // 0xc99db0: ldr             x1, [fp, #0x10]
    // 0xc99db4: cmp             w1, NULL
    // 0xc99db8: b.ne            #0xc99dcc
    // 0xc99dbc: r0 = false
    //     0xc99dbc: add             x0, NULL, #0x30  ; false
    // 0xc99dc0: LeaveFrame
    //     0xc99dc0: mov             SP, fp
    //     0xc99dc4: ldp             fp, lr, [SP], #0x10
    // 0xc99dc8: ret
    //     0xc99dc8: ret             
    // 0xc99dcc: r0 = 59
    //     0xc99dcc: mov             x0, #0x3b
    // 0xc99dd0: branchIfSmi(r1, 0xc99ddc)
    //     0xc99dd0: tbz             w1, #0, #0xc99ddc
    // 0xc99dd4: r0 = LoadClassIdInstr(r1)
    //     0xc99dd4: ldur            x0, [x1, #-1]
    //     0xc99dd8: ubfx            x0, x0, #0xc, #0x14
    // 0xc99ddc: SaveReg r1
    //     0xc99ddc: str             x1, [SP, #-8]!
    // 0xc99de0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc99de0: mov             x17, #0x57c5
    //     0xc99de4: add             lr, x0, x17
    //     0xc99de8: ldr             lr, [x21, lr, lsl #3]
    //     0xc99dec: blr             lr
    // 0xc99df0: add             SP, SP, #8
    // 0xc99df4: r1 = LoadClassIdInstr(r0)
    //     0xc99df4: ldur            x1, [x0, #-1]
    //     0xc99df8: ubfx            x1, x1, #0xc, #0x14
    // 0xc99dfc: r16 = _StadiumToCircleBorder
    //     0xc99dfc: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3fe20] Type: _StadiumToCircleBorder
    //     0xc99e00: ldr             x16, [x16, #0xe20]
    // 0xc99e04: stp             x16, x0, [SP, #-0x10]!
    // 0xc99e08: mov             x0, x1
    // 0xc99e0c: mov             lr, x0
    // 0xc99e10: ldr             lr, [x21, lr, lsl #3]
    // 0xc99e14: blr             lr
    // 0xc99e18: add             SP, SP, #0x10
    // 0xc99e1c: tbz             w0, #4, #0xc99e30
    // 0xc99e20: r0 = false
    //     0xc99e20: add             x0, NULL, #0x30  ; false
    // 0xc99e24: LeaveFrame
    //     0xc99e24: mov             SP, fp
    //     0xc99e28: ldp             fp, lr, [SP], #0x10
    // 0xc99e2c: ret
    //     0xc99e2c: ret             
    // 0xc99e30: ldr             x0, [fp, #0x10]
    // 0xc99e34: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc99e34: mov             x1, #0x76
    //     0xc99e38: tbz             w0, #0, #0xc99e48
    //     0xc99e3c: ldur            x1, [x0, #-1]
    //     0xc99e40: ubfx            x1, x1, #0xc, #0x14
    //     0xc99e44: lsl             x1, x1, #1
    // 0xc99e48: r17 = 4352
    //     0xc99e48: mov             x17, #0x1100
    // 0xc99e4c: cmp             w1, w17
    // 0xc99e50: b.ne            #0xc99ea8
    // 0xc99e54: ldr             x1, [fp, #0x18]
    // 0xc99e58: LoadField: r2 = r0->field_7
    //     0xc99e58: ldur            w2, [x0, #7]
    // 0xc99e5c: DecompressPointer r2
    //     0xc99e5c: add             x2, x2, HEAP, lsl #32
    // 0xc99e60: LoadField: r3 = r1->field_7
    //     0xc99e60: ldur            w3, [x1, #7]
    // 0xc99e64: DecompressPointer r3
    //     0xc99e64: add             x3, x3, HEAP, lsl #32
    // 0xc99e68: stp             x3, x2, [SP, #-0x10]!
    // 0xc99e6c: r0 = ==()
    //     0xc99e6c: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc99e70: add             SP, SP, #0x10
    // 0xc99e74: tbnz            w0, #4, #0xc99ea8
    // 0xc99e78: ldr             x2, [fp, #0x18]
    // 0xc99e7c: ldr             x1, [fp, #0x10]
    // 0xc99e80: LoadField: d0 = r1->field_b
    //     0xc99e80: ldur            d0, [x1, #0xb]
    // 0xc99e84: LoadField: d1 = r2->field_b
    //     0xc99e84: ldur            d1, [x2, #0xb]
    // 0xc99e88: fcmp            d0, d1
    // 0xc99e8c: b.vs            #0xc99e94
    // 0xc99e90: b.eq            #0xc99e9c
    // 0xc99e94: r1 = false
    //     0xc99e94: add             x1, NULL, #0x30  ; false
    // 0xc99e98: b               #0xc99ea0
    // 0xc99e9c: r1 = true
    //     0xc99e9c: add             x1, NULL, #0x20  ; true
    // 0xc99ea0: mov             x0, x1
    // 0xc99ea4: b               #0xc99eac
    // 0xc99ea8: r0 = false
    //     0xc99ea8: add             x0, NULL, #0x30  ; false
    // 0xc99eac: LeaveFrame
    //     0xc99eac: mov             SP, fp
    //     0xc99eb0: ldp             fp, lr, [SP], #0x10
    // 0xc99eb4: ret
    //     0xc99eb4: ret             
    // 0xc99eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc99eb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc99ebc: b               #0xc99db0
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf8a30, size: 0x7c
    // 0xcf8a30: EnterFrame
    //     0xcf8a30: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8a34: mov             fp, SP
    // 0xcf8a38: AllocStack(0x10)
    //     0xcf8a38: sub             SP, SP, #0x10
    // 0xcf8a3c: CheckStackOverflow
    //     0xcf8a3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf8a40: cmp             SP, x16
    //     0xcf8a44: b.ls            #0xcf8aa4
    // 0xcf8a48: ldr             x0, [fp, #0x18]
    // 0xcf8a4c: LoadField: r1 = r0->field_7
    //     0xcf8a4c: ldur            w1, [x0, #7]
    // 0xcf8a50: DecompressPointer r1
    //     0xcf8a50: add             x1, x1, HEAP, lsl #32
    // 0xcf8a54: SaveReg r1
    //     0xcf8a54: str             x1, [SP, #-8]!
    // 0xcf8a58: ldr             d0, [fp, #0x10]
    // 0xcf8a5c: SaveReg d0
    //     0xcf8a5c: str             d0, [SP, #-8]!
    // 0xcf8a60: r0 = scale()
    //     0xcf8a60: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf8a64: add             SP, SP, #0x10
    // 0xcf8a68: mov             x1, x0
    // 0xcf8a6c: ldr             x0, [fp, #0x18]
    // 0xcf8a70: stur            x1, [fp, #-8]
    // 0xcf8a74: LoadField: d0 = r0->field_13
    //     0xcf8a74: ldur            d0, [x0, #0x13]
    // 0xcf8a78: stur            d0, [fp, #-0x10]
    // 0xcf8a7c: r0 = _StadiumToCircleBorder()
    //     0xcf8a7c: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0xcf8a80: ldr             d0, [fp, #0x10]
    // 0xcf8a84: StoreField: r0->field_b = d0
    //     0xcf8a84: stur            d0, [x0, #0xb]
    // 0xcf8a88: ldur            d0, [fp, #-0x10]
    // 0xcf8a8c: StoreField: r0->field_13 = d0
    //     0xcf8a8c: stur            d0, [x0, #0x13]
    // 0xcf8a90: ldur            x1, [fp, #-8]
    // 0xcf8a94: StoreField: r0->field_7 = r1
    //     0xcf8a94: stur            w1, [x0, #7]
    // 0xcf8a98: LeaveFrame
    //     0xcf8a98: mov             SP, fp
    //     0xcf8a9c: ldp             fp, lr, [SP], #0x10
    // 0xcf8aa0: ret
    //     0xcf8aa0: ret             
    // 0xcf8aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8aa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8aa8: b               #0xcf8a48
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xcf8e38, size: 0x68
    // 0xcf8e38: EnterFrame
    //     0xcf8e38: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8e3c: mov             fp, SP
    // 0xcf8e40: AllocStack(0x18)
    //     0xcf8e40: sub             SP, SP, #0x18
    // 0xcf8e44: ldr             x0, [fp, #0x10]
    // 0xcf8e48: cmp             w0, NULL
    // 0xcf8e4c: b.ne            #0xcf8e60
    // 0xcf8e50: ldr             x1, [fp, #0x18]
    // 0xcf8e54: LoadField: r0 = r1->field_7
    //     0xcf8e54: ldur            w0, [x1, #7]
    // 0xcf8e58: DecompressPointer r0
    //     0xcf8e58: add             x0, x0, HEAP, lsl #32
    // 0xcf8e5c: b               #0xcf8e64
    // 0xcf8e60: ldr             x1, [fp, #0x18]
    // 0xcf8e64: stur            x0, [fp, #-8]
    // 0xcf8e68: LoadField: d0 = r1->field_b
    //     0xcf8e68: ldur            d0, [x1, #0xb]
    // 0xcf8e6c: stur            d0, [fp, #-0x18]
    // 0xcf8e70: LoadField: d1 = r1->field_13
    //     0xcf8e70: ldur            d1, [x1, #0x13]
    // 0xcf8e74: stur            d1, [fp, #-0x10]
    // 0xcf8e78: r0 = _StadiumToCircleBorder()
    //     0xcf8e78: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0xcf8e7c: ldur            d0, [fp, #-0x18]
    // 0xcf8e80: StoreField: r0->field_b = d0
    //     0xcf8e80: stur            d0, [x0, #0xb]
    // 0xcf8e84: ldur            d0, [fp, #-0x10]
    // 0xcf8e88: StoreField: r0->field_13 = d0
    //     0xcf8e88: stur            d0, [x0, #0x13]
    // 0xcf8e8c: ldur            x1, [fp, #-8]
    // 0xcf8e90: StoreField: r0->field_7 = r1
    //     0xcf8e90: stur            w1, [x0, #7]
    // 0xcf8e94: LeaveFrame
    //     0xcf8e94: mov             SP, fp
    //     0xcf8e98: ldp             fp, lr, [SP], #0x10
    // 0xcf8e9c: ret
    //     0xcf8e9c: ret             
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0xcfa670, size: 0xb8
    // 0xcfa670: EnterFrame
    //     0xcfa670: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa674: mov             fp, SP
    // 0xcfa678: AllocStack(0x20)
    //     0xcfa678: sub             SP, SP, #0x20
    // 0xcfa67c: SetupParameters(_StadiumToCircleBorder this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0xcfa67c: mov             x0, x4
    //     0xcfa680: ldur            w1, [x0, #0x13]
    //     0xcfa684: add             x1, x1, HEAP, lsl #32
    //     0xcfa688: sub             x0, x1, #4
    //     0xcfa68c: add             x1, fp, w0, sxtw #2
    //     0xcfa690: ldr             x1, [x1, #0x18]
    //     0xcfa694: stur            x1, [fp, #-0x10]
    //     0xcfa698: add             x2, fp, w0, sxtw #2
    //     0xcfa69c: ldr             x2, [x2, #0x10]
    //     0xcfa6a0: stur            x2, [fp, #-8]
    // 0xcfa6a4: CheckStackOverflow
    //     0xcfa6a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa6a8: cmp             SP, x16
    //     0xcfa6ac: b.ls            #0xcfa720
    // 0xcfa6b0: r0 = Path()
    //     0xcfa6b0: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcfa6b4: stur            x0, [fp, #-0x18]
    // 0xcfa6b8: SaveReg r0
    //     0xcfa6b8: str             x0, [SP, #-8]!
    // 0xcfa6bc: r0 = _constructor()
    //     0xcfa6bc: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcfa6c0: add             SP, SP, #8
    // 0xcfa6c4: ldur            x16, [fp, #-0x10]
    // 0xcfa6c8: ldur            lr, [fp, #-8]
    // 0xcfa6cc: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa6d0: r0 = _adjustBorderRadius()
    //     0xcfa6d0: bl              #0x7187c0  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustBorderRadius
    // 0xcfa6d4: add             SP, SP, #0x10
    // 0xcfa6d8: stur            x0, [fp, #-0x20]
    // 0xcfa6dc: ldur            x16, [fp, #-0x10]
    // 0xcfa6e0: ldur            lr, [fp, #-8]
    // 0xcfa6e4: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa6e8: r0 = _adjustRect()
    //     0xcfa6e8: bl              #0x718674  ; [package:flutter/src/painting/stadium_border.dart] _StadiumToCircleBorder::_adjustRect
    // 0xcfa6ec: add             SP, SP, #0x10
    // 0xcfa6f0: ldur            x16, [fp, #-0x20]
    // 0xcfa6f4: stp             x0, x16, [SP, #-0x10]!
    // 0xcfa6f8: r0 = toRRect()
    //     0xcfa6f8: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xcfa6fc: add             SP, SP, #0x10
    // 0xcfa700: ldur            x16, [fp, #-0x18]
    // 0xcfa704: stp             x0, x16, [SP, #-0x10]!
    // 0xcfa708: r0 = addRRect()
    //     0xcfa708: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0xcfa70c: add             SP, SP, #0x10
    // 0xcfa710: ldur            x0, [fp, #-0x18]
    // 0xcfa714: LeaveFrame
    //     0xcfa714: mov             SP, fp
    //     0xcfa718: ldp             fp, lr, [SP], #0x10
    // 0xcfa71c: ret
    //     0xcfa71c: ret             
    // 0xcfa720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa720: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa724: b               #0xcfa6b0
  }
}

// class id: 2177, size: 0xc, field offset: 0xc
//   const constructor, 
class StadiumBorder extends OutlinedBorder {

  BorderSide field_8;

  _ lerpTo(/* No info */) {
    // ** addr: 0x70ef9c, size: 0x188
    // 0x70ef9c: EnterFrame
    //     0x70ef9c: stp             fp, lr, [SP, #-0x10]!
    //     0x70efa0: mov             fp, SP
    // 0x70efa4: AllocStack(0x18)
    //     0x70efa4: sub             SP, SP, #0x18
    // 0x70efa8: CheckStackOverflow
    //     0x70efa8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70efac: cmp             SP, x16
    //     0x70efb0: b.ls            #0x70f11c
    // 0x70efb4: ldr             x0, [fp, #0x18]
    // 0x70efb8: r1 = LoadClassIdInstr(r0)
    //     0x70efb8: ldur            x1, [x0, #-1]
    //     0x70efbc: ubfx            x1, x1, #0xc, #0x14
    // 0x70efc0: lsl             x1, x1, #1
    // 0x70efc4: r17 = 4354
    //     0x70efc4: mov             x17, #0x1102
    // 0x70efc8: cmp             w1, w17
    // 0x70efcc: b.ne            #0x70f01c
    // 0x70efd0: ldr             x2, [fp, #0x20]
    // 0x70efd4: ldr             d0, [fp, #0x10]
    // 0x70efd8: LoadField: r1 = r2->field_7
    //     0x70efd8: ldur            w1, [x2, #7]
    // 0x70efdc: DecompressPointer r1
    //     0x70efdc: add             x1, x1, HEAP, lsl #32
    // 0x70efe0: LoadField: r2 = r0->field_7
    //     0x70efe0: ldur            w2, [x0, #7]
    // 0x70efe4: DecompressPointer r2
    //     0x70efe4: add             x2, x2, HEAP, lsl #32
    // 0x70efe8: stp             x2, x1, [SP, #-0x10]!
    // 0x70efec: SaveReg d0
    //     0x70efec: str             d0, [SP, #-8]!
    // 0x70eff0: r0 = lerp()
    //     0x70eff0: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70eff4: add             SP, SP, #0x18
    // 0x70eff8: stur            x0, [fp, #-8]
    // 0x70effc: r0 = StadiumBorder()
    //     0x70effc: bl              #0x70f13c  ; AllocateStadiumBorderStub -> StadiumBorder (size=0xc)
    // 0x70f000: mov             x1, x0
    // 0x70f004: ldur            x0, [fp, #-8]
    // 0x70f008: StoreField: r1->field_7 = r0
    //     0x70f008: stur            w0, [x1, #7]
    // 0x70f00c: mov             x0, x1
    // 0x70f010: LeaveFrame
    //     0x70f010: mov             SP, fp
    //     0x70f014: ldp             fp, lr, [SP], #0x10
    // 0x70f018: ret
    //     0x70f018: ret             
    // 0x70f01c: ldr             x2, [fp, #0x20]
    // 0x70f020: ldr             d0, [fp, #0x10]
    // 0x70f024: r17 = 4360
    //     0x70f024: mov             x17, #0x1108
    // 0x70f028: cmp             w1, w17
    // 0x70f02c: b.ne            #0x70f08c
    // 0x70f030: LoadField: r1 = r2->field_7
    //     0x70f030: ldur            w1, [x2, #7]
    // 0x70f034: DecompressPointer r1
    //     0x70f034: add             x1, x1, HEAP, lsl #32
    // 0x70f038: LoadField: r2 = r0->field_7
    //     0x70f038: ldur            w2, [x0, #7]
    // 0x70f03c: DecompressPointer r2
    //     0x70f03c: add             x2, x2, HEAP, lsl #32
    // 0x70f040: stp             x2, x1, [SP, #-0x10]!
    // 0x70f044: SaveReg d0
    //     0x70f044: str             d0, [SP, #-8]!
    // 0x70f048: r0 = lerp()
    //     0x70f048: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70f04c: add             SP, SP, #0x18
    // 0x70f050: mov             x1, x0
    // 0x70f054: ldr             x0, [fp, #0x18]
    // 0x70f058: stur            x1, [fp, #-8]
    // 0x70f05c: LoadField: d0 = r0->field_b
    //     0x70f05c: ldur            d0, [x0, #0xb]
    // 0x70f060: stur            d0, [fp, #-0x18]
    // 0x70f064: r0 = _StadiumToCircleBorder()
    //     0x70f064: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x70f068: ldr             d0, [fp, #0x10]
    // 0x70f06c: StoreField: r0->field_b = d0
    //     0x70f06c: stur            d0, [x0, #0xb]
    // 0x70f070: ldur            d0, [fp, #-0x18]
    // 0x70f074: StoreField: r0->field_13 = d0
    //     0x70f074: stur            d0, [x0, #0x13]
    // 0x70f078: ldur            x1, [fp, #-8]
    // 0x70f07c: StoreField: r0->field_7 = r1
    //     0x70f07c: stur            w1, [x0, #7]
    // 0x70f080: LeaveFrame
    //     0x70f080: mov             SP, fp
    //     0x70f084: ldp             fp, lr, [SP], #0x10
    // 0x70f088: ret
    //     0x70f088: ret             
    // 0x70f08c: r17 = 4358
    //     0x70f08c: mov             x17, #0x1106
    // 0x70f090: cmp             w1, w17
    // 0x70f094: b.ne            #0x70f100
    // 0x70f098: LoadField: r1 = r2->field_7
    //     0x70f098: ldur            w1, [x2, #7]
    // 0x70f09c: DecompressPointer r1
    //     0x70f09c: add             x1, x1, HEAP, lsl #32
    // 0x70f0a0: LoadField: r2 = r0->field_7
    //     0x70f0a0: ldur            w2, [x0, #7]
    // 0x70f0a4: DecompressPointer r2
    //     0x70f0a4: add             x2, x2, HEAP, lsl #32
    // 0x70f0a8: stp             x2, x1, [SP, #-0x10]!
    // 0x70f0ac: SaveReg d0
    //     0x70f0ac: str             d0, [SP, #-8]!
    // 0x70f0b0: r0 = lerp()
    //     0x70f0b0: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70f0b4: add             SP, SP, #0x18
    // 0x70f0b8: mov             x1, x0
    // 0x70f0bc: ldr             x0, [fp, #0x18]
    // 0x70f0c0: stur            x1, [fp, #-0x10]
    // 0x70f0c4: LoadField: r2 = r0->field_b
    //     0x70f0c4: ldur            w2, [x0, #0xb]
    // 0x70f0c8: DecompressPointer r2
    //     0x70f0c8: add             x2, x2, HEAP, lsl #32
    // 0x70f0cc: stur            x2, [fp, #-8]
    // 0x70f0d0: r0 = _StadiumToRoundedRectangleBorder()
    //     0x70f0d0: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x70f0d4: mov             x1, x0
    // 0x70f0d8: ldur            x0, [fp, #-8]
    // 0x70f0dc: StoreField: r1->field_b = r0
    //     0x70f0dc: stur            w0, [x1, #0xb]
    // 0x70f0e0: ldr             d0, [fp, #0x10]
    // 0x70f0e4: StoreField: r1->field_f = d0
    //     0x70f0e4: stur            d0, [x1, #0xf]
    // 0x70f0e8: ldur            x0, [fp, #-0x10]
    // 0x70f0ec: StoreField: r1->field_7 = r0
    //     0x70f0ec: stur            w0, [x1, #7]
    // 0x70f0f0: mov             x0, x1
    // 0x70f0f4: LeaveFrame
    //     0x70f0f4: mov             SP, fp
    //     0x70f0f8: ldp             fp, lr, [SP], #0x10
    // 0x70f0fc: ret
    //     0x70f0fc: ret             
    // 0x70f100: stp             x0, x2, [SP, #-0x10]!
    // 0x70f104: SaveReg d0
    //     0x70f104: str             d0, [SP, #-8]!
    // 0x70f108: r0 = lerpTo()
    //     0x70f108: bl              #0x70f880  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x70f10c: add             SP, SP, #0x18
    // 0x70f110: LeaveFrame
    //     0x70f110: mov             SP, fp
    //     0x70f114: ldp             fp, lr, [SP], #0x10
    // 0x70f118: ret
    //     0x70f118: ret             
    // 0x70f11c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70f11c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70f120: b               #0x70efb4
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x7105dc, size: 0x1c0
    // 0x7105dc: EnterFrame
    //     0x7105dc: stp             fp, lr, [SP, #-0x10]!
    //     0x7105e0: mov             fp, SP
    // 0x7105e4: AllocStack(0x20)
    //     0x7105e4: sub             SP, SP, #0x20
    // 0x7105e8: CheckStackOverflow
    //     0x7105e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7105ec: cmp             SP, x16
    //     0x7105f0: b.ls            #0x710794
    // 0x7105f4: ldr             x0, [fp, #0x18]
    // 0x7105f8: r1 = LoadClassIdInstr(r0)
    //     0x7105f8: ldur            x1, [x0, #-1]
    //     0x7105fc: ubfx            x1, x1, #0xc, #0x14
    // 0x710600: lsl             x1, x1, #1
    // 0x710604: r17 = 4354
    //     0x710604: mov             x17, #0x1102
    // 0x710608: cmp             w1, w17
    // 0x71060c: b.ne            #0x71065c
    // 0x710610: ldr             x2, [fp, #0x20]
    // 0x710614: ldr             d0, [fp, #0x10]
    // 0x710618: LoadField: r1 = r0->field_7
    //     0x710618: ldur            w1, [x0, #7]
    // 0x71061c: DecompressPointer r1
    //     0x71061c: add             x1, x1, HEAP, lsl #32
    // 0x710620: LoadField: r0 = r2->field_7
    //     0x710620: ldur            w0, [x2, #7]
    // 0x710624: DecompressPointer r0
    //     0x710624: add             x0, x0, HEAP, lsl #32
    // 0x710628: stp             x0, x1, [SP, #-0x10]!
    // 0x71062c: SaveReg d0
    //     0x71062c: str             d0, [SP, #-8]!
    // 0x710630: r0 = lerp()
    //     0x710630: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x710634: add             SP, SP, #0x18
    // 0x710638: stur            x0, [fp, #-8]
    // 0x71063c: r0 = StadiumBorder()
    //     0x71063c: bl              #0x70f13c  ; AllocateStadiumBorderStub -> StadiumBorder (size=0xc)
    // 0x710640: mov             x1, x0
    // 0x710644: ldur            x0, [fp, #-8]
    // 0x710648: StoreField: r1->field_7 = r0
    //     0x710648: stur            w0, [x1, #7]
    // 0x71064c: mov             x0, x1
    // 0x710650: LeaveFrame
    //     0x710650: mov             SP, fp
    //     0x710654: ldp             fp, lr, [SP], #0x10
    // 0x710658: ret
    //     0x710658: ret             
    // 0x71065c: ldr             x2, [fp, #0x20]
    // 0x710660: ldr             d0, [fp, #0x10]
    // 0x710664: r17 = 4360
    //     0x710664: mov             x17, #0x1108
    // 0x710668: cmp             w1, w17
    // 0x71066c: b.ne            #0x7106d8
    // 0x710670: LoadField: r1 = r0->field_7
    //     0x710670: ldur            w1, [x0, #7]
    // 0x710674: DecompressPointer r1
    //     0x710674: add             x1, x1, HEAP, lsl #32
    // 0x710678: LoadField: r3 = r2->field_7
    //     0x710678: ldur            w3, [x2, #7]
    // 0x71067c: DecompressPointer r3
    //     0x71067c: add             x3, x3, HEAP, lsl #32
    // 0x710680: stp             x3, x1, [SP, #-0x10]!
    // 0x710684: SaveReg d0
    //     0x710684: str             d0, [SP, #-8]!
    // 0x710688: r0 = lerp()
    //     0x710688: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x71068c: add             SP, SP, #0x18
    // 0x710690: ldr             d0, [fp, #0x10]
    // 0x710694: d1 = 1.000000
    //     0x710694: fmov            d1, #1.00000000
    // 0x710698: stur            x0, [fp, #-8]
    // 0x71069c: fsub            d2, d1, d0
    // 0x7106a0: ldr             x3, [fp, #0x18]
    // 0x7106a4: stur            d2, [fp, #-0x20]
    // 0x7106a8: LoadField: d0 = r3->field_b
    //     0x7106a8: ldur            d0, [x3, #0xb]
    // 0x7106ac: stur            d0, [fp, #-0x18]
    // 0x7106b0: r0 = _StadiumToCircleBorder()
    //     0x7106b0: bl              #0x70f130  ; Allocate_StadiumToCircleBorderStub -> _StadiumToCircleBorder (size=0x1c)
    // 0x7106b4: ldur            d0, [fp, #-0x20]
    // 0x7106b8: StoreField: r0->field_b = d0
    //     0x7106b8: stur            d0, [x0, #0xb]
    // 0x7106bc: ldur            d0, [fp, #-0x18]
    // 0x7106c0: StoreField: r0->field_13 = d0
    //     0x7106c0: stur            d0, [x0, #0x13]
    // 0x7106c4: ldur            x1, [fp, #-8]
    // 0x7106c8: StoreField: r0->field_7 = r1
    //     0x7106c8: stur            w1, [x0, #7]
    // 0x7106cc: LeaveFrame
    //     0x7106cc: mov             SP, fp
    //     0x7106d0: ldp             fp, lr, [SP], #0x10
    // 0x7106d4: ret
    //     0x7106d4: ret             
    // 0x7106d8: mov             x3, x0
    // 0x7106dc: d1 = 1.000000
    //     0x7106dc: fmov            d1, #1.00000000
    // 0x7106e0: r17 = 4358
    //     0x7106e0: mov             x17, #0x1106
    // 0x7106e4: cmp             w1, w17
    // 0x7106e8: b.ne            #0x710764
    // 0x7106ec: LoadField: r0 = r3->field_7
    //     0x7106ec: ldur            w0, [x3, #7]
    // 0x7106f0: DecompressPointer r0
    //     0x7106f0: add             x0, x0, HEAP, lsl #32
    // 0x7106f4: LoadField: r1 = r2->field_7
    //     0x7106f4: ldur            w1, [x2, #7]
    // 0x7106f8: DecompressPointer r1
    //     0x7106f8: add             x1, x1, HEAP, lsl #32
    // 0x7106fc: stp             x1, x0, [SP, #-0x10]!
    // 0x710700: SaveReg d0
    //     0x710700: str             d0, [SP, #-8]!
    // 0x710704: r0 = lerp()
    //     0x710704: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x710708: add             SP, SP, #0x18
    // 0x71070c: mov             x1, x0
    // 0x710710: ldr             x0, [fp, #0x18]
    // 0x710714: stur            x1, [fp, #-0x10]
    // 0x710718: LoadField: r2 = r0->field_b
    //     0x710718: ldur            w2, [x0, #0xb]
    // 0x71071c: DecompressPointer r2
    //     0x71071c: add             x2, x2, HEAP, lsl #32
    // 0x710720: ldr             d0, [fp, #0x10]
    // 0x710724: stur            x2, [fp, #-8]
    // 0x710728: d1 = 1.000000
    //     0x710728: fmov            d1, #1.00000000
    // 0x71072c: fsub            d2, d1, d0
    // 0x710730: stur            d2, [fp, #-0x18]
    // 0x710734: r0 = _StadiumToRoundedRectangleBorder()
    //     0x710734: bl              #0x70f124  ; Allocate_StadiumToRoundedRectangleBorderStub -> _StadiumToRoundedRectangleBorder (size=0x18)
    // 0x710738: mov             x1, x0
    // 0x71073c: ldur            x0, [fp, #-8]
    // 0x710740: StoreField: r1->field_b = r0
    //     0x710740: stur            w0, [x1, #0xb]
    // 0x710744: ldur            d0, [fp, #-0x18]
    // 0x710748: StoreField: r1->field_f = d0
    //     0x710748: stur            d0, [x1, #0xf]
    // 0x71074c: ldur            x0, [fp, #-0x10]
    // 0x710750: StoreField: r1->field_7 = r0
    //     0x710750: stur            w0, [x1, #7]
    // 0x710754: mov             x0, x1
    // 0x710758: LeaveFrame
    //     0x710758: mov             SP, fp
    //     0x71075c: ldp             fp, lr, [SP], #0x10
    // 0x710760: ret
    //     0x710760: ret             
    // 0x710764: mov             x0, x3
    // 0x710768: cmp             w0, NULL
    // 0x71076c: b.ne            #0x710784
    // 0x710770: SaveReg r2
    //     0x710770: str             x2, [SP, #-8]!
    // 0x710774: SaveReg d0
    //     0x710774: str             d0, [SP, #-8]!
    // 0x710778: r0 = scale()
    //     0x710778: bl              #0xcf89d4  ; [package:flutter/src/painting/stadium_border.dart] StadiumBorder::scale
    // 0x71077c: add             SP, SP, #0x10
    // 0x710780: b               #0x710788
    // 0x710784: r0 = Null
    //     0x710784: mov             x0, NULL
    // 0x710788: LeaveFrame
    //     0x710788: mov             SP, fp
    //     0x71078c: ldp             fp, lr, [SP], #0x10
    // 0x710790: ret
    //     0x710790: ret             
    // 0x710794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x710794: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x710798: b               #0x7105f4
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x718550, size: 0xa0
    // 0x718550: EnterFrame
    //     0x718550: stp             fp, lr, [SP, #-0x10]!
    //     0x718554: mov             fp, SP
    // 0x718558: AllocStack(0x18)
    //     0x718558: sub             SP, SP, #0x18
    // 0x71855c: CheckStackOverflow
    //     0x71855c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x718560: cmp             SP, x16
    //     0x718564: b.ls            #0x7185e8
    // 0x718568: ldr             x16, [fp, #0x20]
    // 0x71856c: SaveReg r16
    //     0x71856c: str             x16, [SP, #-8]!
    // 0x718570: r0 = shortestSide()
    //     0x718570: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0x718574: add             SP, SP, #8
    // 0x718578: mov             v1.16b, v0.16b
    // 0x71857c: d0 = 2.000000
    //     0x71857c: fmov            d0, #2.00000000
    // 0x718580: fdiv            d2, d1, d0
    // 0x718584: stur            d2, [fp, #-0x18]
    // 0x718588: r0 = Radius()
    //     0x718588: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x71858c: ldur            d0, [fp, #-0x18]
    // 0x718590: stur            x0, [fp, #-8]
    // 0x718594: StoreField: r0->field_7 = d0
    //     0x718594: stur            d0, [x0, #7]
    // 0x718598: StoreField: r0->field_f = d0
    //     0x718598: stur            d0, [x0, #0xf]
    // 0x71859c: r0 = RRect()
    //     0x71859c: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x7185a0: stur            x0, [fp, #-0x10]
    // 0x7185a4: ldr             x16, [fp, #0x20]
    // 0x7185a8: stp             x16, x0, [SP, #-0x10]!
    // 0x7185ac: ldur            x16, [fp, #-8]
    // 0x7185b0: SaveReg r16
    //     0x7185b0: str             x16, [SP, #-8]!
    // 0x7185b4: r0 = RRect.fromRectAndRadius()
    //     0x7185b4: bl              #0x660380  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x7185b8: add             SP, SP, #0x18
    // 0x7185bc: ldr             x16, [fp, #0x28]
    // 0x7185c0: ldur            lr, [fp, #-0x10]
    // 0x7185c4: stp             lr, x16, [SP, #-0x10]!
    // 0x7185c8: ldr             x16, [fp, #0x18]
    // 0x7185cc: SaveReg r16
    //     0x7185cc: str             x16, [SP, #-8]!
    // 0x7185d0: r0 = drawRRect()
    //     0x7185d0: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x7185d4: add             SP, SP, #0x18
    // 0x7185d8: r0 = Null
    //     0x7185d8: mov             x0, NULL
    // 0x7185dc: LeaveFrame
    //     0x7185dc: mov             SP, fp
    //     0x7185e0: ldp             fp, lr, [SP], #0x10
    // 0x7185e4: ret
    //     0x7185e4: ret             
    // 0x7185e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7185e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7185ec: b               #0x718568
  }
  _ getInnerPath(/* No info */) {
    // ** addr: 0x71b004, size: 0x114
    // 0x71b004: EnterFrame
    //     0x71b004: stp             fp, lr, [SP, #-0x10]!
    //     0x71b008: mov             fp, SP
    // 0x71b00c: AllocStack(0x28)
    //     0x71b00c: sub             SP, SP, #0x28
    // 0x71b010: SetupParameters(StadiumBorder this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0x71b010: mov             x0, x4
    //     0x71b014: ldur            w1, [x0, #0x13]
    //     0x71b018: add             x1, x1, HEAP, lsl #32
    //     0x71b01c: sub             x0, x1, #4
    //     0x71b020: add             x1, fp, w0, sxtw #2
    //     0x71b024: ldr             x1, [x1, #0x18]
    //     0x71b028: stur            x1, [fp, #-0x10]
    //     0x71b02c: add             x2, fp, w0, sxtw #2
    //     0x71b030: ldr             x2, [x2, #0x10]
    //     0x71b034: stur            x2, [fp, #-8]
    // 0x71b038: CheckStackOverflow
    //     0x71b038: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71b03c: cmp             SP, x16
    //     0x71b040: b.ls            #0x71b110
    // 0x71b044: SaveReg r2
    //     0x71b044: str             x2, [SP, #-8]!
    // 0x71b048: r0 = shortestSide()
    //     0x71b048: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0x71b04c: add             SP, SP, #8
    // 0x71b050: mov             v1.16b, v0.16b
    // 0x71b054: d0 = 2.000000
    //     0x71b054: fmov            d0, #2.00000000
    // 0x71b058: fdiv            d2, d1, d0
    // 0x71b05c: stur            d2, [fp, #-0x28]
    // 0x71b060: r0 = Radius()
    //     0x71b060: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x71b064: ldur            d0, [fp, #-0x28]
    // 0x71b068: stur            x0, [fp, #-0x18]
    // 0x71b06c: StoreField: r0->field_7 = d0
    //     0x71b06c: stur            d0, [x0, #7]
    // 0x71b070: StoreField: r0->field_f = d0
    //     0x71b070: stur            d0, [x0, #0xf]
    // 0x71b074: r0 = RRect()
    //     0x71b074: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x71b078: stur            x0, [fp, #-0x20]
    // 0x71b07c: ldur            x16, [fp, #-8]
    // 0x71b080: stp             x16, x0, [SP, #-0x10]!
    // 0x71b084: ldur            x16, [fp, #-0x18]
    // 0x71b088: SaveReg r16
    //     0x71b088: str             x16, [SP, #-8]!
    // 0x71b08c: r0 = RRect.fromRectAndRadius()
    //     0x71b08c: bl              #0x660380  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x71b090: add             SP, SP, #0x18
    // 0x71b094: ldur            x0, [fp, #-0x10]
    // 0x71b098: LoadField: r1 = r0->field_7
    //     0x71b098: ldur            w1, [x0, #7]
    // 0x71b09c: DecompressPointer r1
    //     0x71b09c: add             x1, x1, HEAP, lsl #32
    // 0x71b0a0: LoadField: d0 = r1->field_b
    //     0x71b0a0: ldur            d0, [x1, #0xb]
    // 0x71b0a4: LoadField: d1 = r1->field_17
    //     0x71b0a4: ldur            d1, [x1, #0x17]
    // 0x71b0a8: d2 = 1.000000
    //     0x71b0a8: fmov            d2, #1.00000000
    // 0x71b0ac: fadd            d3, d2, d1
    // 0x71b0b0: d1 = 2.000000
    //     0x71b0b0: fmov            d1, #2.00000000
    // 0x71b0b4: fdiv            d4, d3, d1
    // 0x71b0b8: fsub            d1, d2, d4
    // 0x71b0bc: fmul            d2, d0, d1
    // 0x71b0c0: ldur            x16, [fp, #-0x20]
    // 0x71b0c4: SaveReg r16
    //     0x71b0c4: str             x16, [SP, #-8]!
    // 0x71b0c8: SaveReg d2
    //     0x71b0c8: str             d2, [SP, #-8]!
    // 0x71b0cc: r0 = deflate()
    //     0x71b0cc: bl              #0x6705bc  ; [dart:ui] RRect::deflate
    // 0x71b0d0: add             SP, SP, #0x10
    // 0x71b0d4: stur            x0, [fp, #-8]
    // 0x71b0d8: r0 = Path()
    //     0x71b0d8: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x71b0dc: stur            x0, [fp, #-0x10]
    // 0x71b0e0: SaveReg r0
    //     0x71b0e0: str             x0, [SP, #-8]!
    // 0x71b0e4: r0 = _constructor()
    //     0x71b0e4: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x71b0e8: add             SP, SP, #8
    // 0x71b0ec: ldur            x16, [fp, #-0x10]
    // 0x71b0f0: ldur            lr, [fp, #-8]
    // 0x71b0f4: stp             lr, x16, [SP, #-0x10]!
    // 0x71b0f8: r0 = addRRect()
    //     0x71b0f8: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0x71b0fc: add             SP, SP, #0x10
    // 0x71b100: ldur            x0, [fp, #-0x10]
    // 0x71b104: LeaveFrame
    //     0x71b104: mov             SP, fp
    //     0x71b108: ldp             fp, lr, [SP], #0x10
    // 0x71b10c: ret
    //     0x71b10c: ret             
    // 0x71b110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71b110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71b114: b               #0x71b044
  }
  _ toString(/* No info */) {
    // ** addr: 0xadb548, size: 0x6c
    // 0xadb548: EnterFrame
    //     0xadb548: stp             fp, lr, [SP, #-0x10]!
    //     0xadb54c: mov             fp, SP
    // 0xadb550: CheckStackOverflow
    //     0xadb550: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadb554: cmp             SP, x16
    //     0xadb558: b.ls            #0xadb5ac
    // 0xadb55c: r1 = Null
    //     0xadb55c: mov             x1, NULL
    // 0xadb560: r2 = 8
    //     0xadb560: mov             x2, #8
    // 0xadb564: r0 = AllocateArray()
    //     0xadb564: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb568: r17 = "StadiumBorder"
    //     0xadb568: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7b8] "StadiumBorder"
    //     0xadb56c: ldr             x17, [x17, #0x7b8]
    // 0xadb570: StoreField: r0->field_f = r17
    //     0xadb570: stur            w17, [x0, #0xf]
    // 0xadb574: r17 = "("
    //     0xadb574: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xadb578: StoreField: r0->field_13 = r17
    //     0xadb578: stur            w17, [x0, #0x13]
    // 0xadb57c: ldr             x1, [fp, #0x10]
    // 0xadb580: LoadField: r2 = r1->field_7
    //     0xadb580: ldur            w2, [x1, #7]
    // 0xadb584: DecompressPointer r2
    //     0xadb584: add             x2, x2, HEAP, lsl #32
    // 0xadb588: StoreField: r0->field_17 = r2
    //     0xadb588: stur            w2, [x0, #0x17]
    // 0xadb58c: r17 = ")"
    //     0xadb58c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadb590: StoreField: r0->field_1b = r17
    //     0xadb590: stur            w17, [x0, #0x1b]
    // 0xadb594: SaveReg r0
    //     0xadb594: str             x0, [SP, #-8]!
    // 0xadb598: r0 = _interpolate()
    //     0xadb598: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb59c: add             SP, SP, #8
    // 0xadb5a0: LeaveFrame
    //     0xadb5a0: mov             SP, fp
    //     0xadb5a4: ldp             fp, lr, [SP], #0x10
    // 0xadb5a8: ret
    //     0xadb5a8: ret             
    // 0xadb5ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadb5ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadb5b0: b               #0xadb55c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0d774, size: 0x40
    // 0xb0d774: EnterFrame
    //     0xb0d774: stp             fp, lr, [SP, #-0x10]!
    //     0xb0d778: mov             fp, SP
    // 0xb0d77c: CheckStackOverflow
    //     0xb0d77c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0d780: cmp             SP, x16
    //     0xb0d784: b.ls            #0xb0d7ac
    // 0xb0d788: ldr             x0, [fp, #0x10]
    // 0xb0d78c: LoadField: r1 = r0->field_7
    //     0xb0d78c: ldur            w1, [x0, #7]
    // 0xb0d790: DecompressPointer r1
    //     0xb0d790: add             x1, x1, HEAP, lsl #32
    // 0xb0d794: SaveReg r1
    //     0xb0d794: str             x1, [SP, #-8]!
    // 0xb0d798: r0 = hashCode()
    //     0xb0d798: bl              #0xb0055c  ; [package:flutter/src/painting/borders.dart] BorderSide::hashCode
    // 0xb0d79c: add             SP, SP, #8
    // 0xb0d7a0: LeaveFrame
    //     0xb0d7a0: mov             SP, fp
    //     0xb0d7a4: ldp             fp, lr, [SP], #0x10
    // 0xb0d7a8: ret
    //     0xb0d7a8: ret             
    // 0xb0d7ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0d7ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0d7b0: b               #0xb0d788
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd4340, size: 0x128
    // 0xbd4340: EnterFrame
    //     0xbd4340: stp             fp, lr, [SP, #-0x10]!
    //     0xbd4344: mov             fp, SP
    // 0xbd4348: AllocStack(0x30)
    //     0xbd4348: sub             SP, SP, #0x30
    // 0xbd434c: SetupParameters(StadiumBorder this /* r1 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xbd434c: mov             x0, x4
    //     0xbd4350: ldur            w1, [x0, #0x13]
    //     0xbd4354: add             x1, x1, HEAP, lsl #32
    //     0xbd4358: sub             x0, x1, #6
    //     0xbd435c: add             x1, fp, w0, sxtw #2
    //     0xbd4360: ldr             x1, [x1, #0x20]
    //     0xbd4364: add             x2, fp, w0, sxtw #2
    //     0xbd4368: ldr             x2, [x2, #0x18]
    //     0xbd436c: stur            x2, [fp, #-0x18]
    //     0xbd4370: add             x3, fp, w0, sxtw #2
    //     0xbd4374: ldr             x3, [x3, #0x10]
    //     0xbd4378: stur            x3, [fp, #-0x10]
    // 0xbd437c: CheckStackOverflow
    //     0xbd437c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd4380: cmp             SP, x16
    //     0xbd4384: b.ls            #0xbd4460
    // 0xbd4388: LoadField: r0 = r1->field_7
    //     0xbd4388: ldur            w0, [x1, #7]
    // 0xbd438c: DecompressPointer r0
    //     0xbd438c: add             x0, x0, HEAP, lsl #32
    // 0xbd4390: stur            x0, [fp, #-8]
    // 0xbd4394: LoadField: r1 = r0->field_13
    //     0xbd4394: ldur            w1, [x0, #0x13]
    // 0xbd4398: DecompressPointer r1
    //     0xbd4398: add             x1, x1, HEAP, lsl #32
    // 0xbd439c: LoadField: r4 = r1->field_7
    //     0xbd439c: ldur            x4, [x1, #7]
    // 0xbd43a0: cmp             x4, #0
    // 0xbd43a4: b.le            #0xbd4450
    // 0xbd43a8: SaveReg r3
    //     0xbd43a8: str             x3, [SP, #-8]!
    // 0xbd43ac: r0 = shortestSide()
    //     0xbd43ac: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0xbd43b0: add             SP, SP, #8
    // 0xbd43b4: mov             v1.16b, v0.16b
    // 0xbd43b8: d0 = 2.000000
    //     0xbd43b8: fmov            d0, #2.00000000
    // 0xbd43bc: fdiv            d2, d1, d0
    // 0xbd43c0: stur            d2, [fp, #-0x30]
    // 0xbd43c4: r0 = Radius()
    //     0xbd43c4: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xbd43c8: ldur            d0, [fp, #-0x30]
    // 0xbd43cc: stur            x0, [fp, #-0x20]
    // 0xbd43d0: StoreField: r0->field_7 = d0
    //     0xbd43d0: stur            d0, [x0, #7]
    // 0xbd43d4: StoreField: r0->field_f = d0
    //     0xbd43d4: stur            d0, [x0, #0xf]
    // 0xbd43d8: r0 = RRect()
    //     0xbd43d8: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xbd43dc: stur            x0, [fp, #-0x28]
    // 0xbd43e0: ldur            x16, [fp, #-0x10]
    // 0xbd43e4: stp             x16, x0, [SP, #-0x10]!
    // 0xbd43e8: ldur            x16, [fp, #-0x20]
    // 0xbd43ec: SaveReg r16
    //     0xbd43ec: str             x16, [SP, #-8]!
    // 0xbd43f0: r0 = RRect.fromRectAndRadius()
    //     0xbd43f0: bl              #0x660380  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xbd43f4: add             SP, SP, #0x18
    // 0xbd43f8: ldur            x0, [fp, #-8]
    // 0xbd43fc: LoadField: d0 = r0->field_b
    //     0xbd43fc: ldur            d0, [x0, #0xb]
    // 0xbd4400: LoadField: d1 = r0->field_17
    //     0xbd4400: ldur            d1, [x0, #0x17]
    // 0xbd4404: fmul            d2, d0, d1
    // 0xbd4408: d0 = 2.000000
    //     0xbd4408: fmov            d0, #2.00000000
    // 0xbd440c: fdiv            d1, d2, d0
    // 0xbd4410: ldur            x16, [fp, #-0x28]
    // 0xbd4414: SaveReg r16
    //     0xbd4414: str             x16, [SP, #-8]!
    // 0xbd4418: SaveReg d1
    //     0xbd4418: str             d1, [SP, #-8]!
    // 0xbd441c: r0 = inflate()
    //     0xbd441c: bl              #0x65ffe4  ; [dart:ui] RRect::inflate
    // 0xbd4420: add             SP, SP, #0x10
    // 0xbd4424: stur            x0, [fp, #-0x10]
    // 0xbd4428: ldur            x16, [fp, #-8]
    // 0xbd442c: SaveReg r16
    //     0xbd442c: str             x16, [SP, #-8]!
    // 0xbd4430: r0 = toPaint()
    //     0xbd4430: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd4434: add             SP, SP, #8
    // 0xbd4438: ldur            x16, [fp, #-0x18]
    // 0xbd443c: ldur            lr, [fp, #-0x10]
    // 0xbd4440: stp             lr, x16, [SP, #-0x10]!
    // 0xbd4444: SaveReg r0
    //     0xbd4444: str             x0, [SP, #-8]!
    // 0xbd4448: r0 = drawRRect()
    //     0xbd4448: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xbd444c: add             SP, SP, #0x18
    // 0xbd4450: r0 = Null
    //     0xbd4450: mov             x0, NULL
    // 0xbd4454: LeaveFrame
    //     0xbd4454: mov             SP, fp
    //     0xbd4458: ldp             fp, lr, [SP], #0x10
    // 0xbd445c: ret
    //     0xbd445c: ret             
    // 0xbd4460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd4460: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd4464: b               #0xbd4388
  }
  _ ==(/* No info */) {
    // ** addr: 0xc99ca8, size: 0xf4
    // 0xc99ca8: EnterFrame
    //     0xc99ca8: stp             fp, lr, [SP, #-0x10]!
    //     0xc99cac: mov             fp, SP
    // 0xc99cb0: CheckStackOverflow
    //     0xc99cb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc99cb4: cmp             SP, x16
    //     0xc99cb8: b.ls            #0xc99d94
    // 0xc99cbc: ldr             x1, [fp, #0x10]
    // 0xc99cc0: cmp             w1, NULL
    // 0xc99cc4: b.ne            #0xc99cd8
    // 0xc99cc8: r0 = false
    //     0xc99cc8: add             x0, NULL, #0x30  ; false
    // 0xc99ccc: LeaveFrame
    //     0xc99ccc: mov             SP, fp
    //     0xc99cd0: ldp             fp, lr, [SP], #0x10
    // 0xc99cd4: ret
    //     0xc99cd4: ret             
    // 0xc99cd8: r0 = 59
    //     0xc99cd8: mov             x0, #0x3b
    // 0xc99cdc: branchIfSmi(r1, 0xc99ce8)
    //     0xc99cdc: tbz             w1, #0, #0xc99ce8
    // 0xc99ce0: r0 = LoadClassIdInstr(r1)
    //     0xc99ce0: ldur            x0, [x1, #-1]
    //     0xc99ce4: ubfx            x0, x0, #0xc, #0x14
    // 0xc99ce8: SaveReg r1
    //     0xc99ce8: str             x1, [SP, #-8]!
    // 0xc99cec: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc99cec: mov             x17, #0x57c5
    //     0xc99cf0: add             lr, x0, x17
    //     0xc99cf4: ldr             lr, [x21, lr, lsl #3]
    //     0xc99cf8: blr             lr
    // 0xc99cfc: add             SP, SP, #8
    // 0xc99d00: r1 = LoadClassIdInstr(r0)
    //     0xc99d00: ldur            x1, [x0, #-1]
    //     0xc99d04: ubfx            x1, x1, #0xc, #0x14
    // 0xc99d08: r16 = StadiumBorder
    //     0xc99d08: add             x16, PP, #0xe, lsl #12  ; [pp+0xe7c0] Type: StadiumBorder
    //     0xc99d0c: ldr             x16, [x16, #0x7c0]
    // 0xc99d10: stp             x16, x0, [SP, #-0x10]!
    // 0xc99d14: mov             x0, x1
    // 0xc99d18: mov             lr, x0
    // 0xc99d1c: ldr             lr, [x21, lr, lsl #3]
    // 0xc99d20: blr             lr
    // 0xc99d24: add             SP, SP, #0x10
    // 0xc99d28: tbz             w0, #4, #0xc99d3c
    // 0xc99d2c: r0 = false
    //     0xc99d2c: add             x0, NULL, #0x30  ; false
    // 0xc99d30: LeaveFrame
    //     0xc99d30: mov             SP, fp
    //     0xc99d34: ldp             fp, lr, [SP], #0x10
    // 0xc99d38: ret
    //     0xc99d38: ret             
    // 0xc99d3c: ldr             x0, [fp, #0x10]
    // 0xc99d40: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc99d40: mov             x1, #0x76
    //     0xc99d44: tbz             w0, #0, #0xc99d54
    //     0xc99d48: ldur            x1, [x0, #-1]
    //     0xc99d4c: ubfx            x1, x1, #0xc, #0x14
    //     0xc99d50: lsl             x1, x1, #1
    // 0xc99d54: r17 = 4354
    //     0xc99d54: mov             x17, #0x1102
    // 0xc99d58: cmp             w1, w17
    // 0xc99d5c: b.ne            #0xc99d84
    // 0xc99d60: ldr             x1, [fp, #0x18]
    // 0xc99d64: LoadField: r2 = r0->field_7
    //     0xc99d64: ldur            w2, [x0, #7]
    // 0xc99d68: DecompressPointer r2
    //     0xc99d68: add             x2, x2, HEAP, lsl #32
    // 0xc99d6c: LoadField: r0 = r1->field_7
    //     0xc99d6c: ldur            w0, [x1, #7]
    // 0xc99d70: DecompressPointer r0
    //     0xc99d70: add             x0, x0, HEAP, lsl #32
    // 0xc99d74: stp             x0, x2, [SP, #-0x10]!
    // 0xc99d78: r0 = ==()
    //     0xc99d78: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc99d7c: add             SP, SP, #0x10
    // 0xc99d80: b               #0xc99d88
    // 0xc99d84: r0 = false
    //     0xc99d84: add             x0, NULL, #0x30  ; false
    // 0xc99d88: LeaveFrame
    //     0xc99d88: mov             SP, fp
    //     0xc99d8c: ldp             fp, lr, [SP], #0x10
    // 0xc99d90: ret
    //     0xc99d90: ret             
    // 0xc99d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc99d94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc99d98: b               #0xc99cbc
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf89d4, size: 0x5c
    // 0xcf89d4: EnterFrame
    //     0xcf89d4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf89d8: mov             fp, SP
    // 0xcf89dc: AllocStack(0x8)
    //     0xcf89dc: sub             SP, SP, #8
    // 0xcf89e0: CheckStackOverflow
    //     0xcf89e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf89e4: cmp             SP, x16
    //     0xcf89e8: b.ls            #0xcf8a28
    // 0xcf89ec: ldr             x0, [fp, #0x18]
    // 0xcf89f0: LoadField: r1 = r0->field_7
    //     0xcf89f0: ldur            w1, [x0, #7]
    // 0xcf89f4: DecompressPointer r1
    //     0xcf89f4: add             x1, x1, HEAP, lsl #32
    // 0xcf89f8: SaveReg r1
    //     0xcf89f8: str             x1, [SP, #-8]!
    // 0xcf89fc: ldr             d0, [fp, #0x10]
    // 0xcf8a00: SaveReg d0
    //     0xcf8a00: str             d0, [SP, #-8]!
    // 0xcf8a04: r0 = scale()
    //     0xcf8a04: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf8a08: add             SP, SP, #0x10
    // 0xcf8a0c: stur            x0, [fp, #-8]
    // 0xcf8a10: r0 = StadiumBorder()
    //     0xcf8a10: bl              #0x70f13c  ; AllocateStadiumBorderStub -> StadiumBorder (size=0xc)
    // 0xcf8a14: ldur            x1, [fp, #-8]
    // 0xcf8a18: StoreField: r0->field_7 = r1
    //     0xcf8a18: stur            w1, [x0, #7]
    // 0xcf8a1c: LeaveFrame
    //     0xcf8a1c: mov             SP, fp
    //     0xcf8a20: ldp             fp, lr, [SP], #0x10
    // 0xcf8a24: ret
    //     0xcf8a24: ret             
    // 0xcf8a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8a28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8a2c: b               #0xcf89ec
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xcf8df4, size: 0x44
    // 0xcf8df4: EnterFrame
    //     0xcf8df4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8df8: mov             fp, SP
    // 0xcf8dfc: AllocStack(0x8)
    //     0xcf8dfc: sub             SP, SP, #8
    // 0xcf8e00: ldr             x0, [fp, #0x10]
    // 0xcf8e04: cmp             w0, NULL
    // 0xcf8e08: b.ne            #0xcf8e1c
    // 0xcf8e0c: ldr             x0, [fp, #0x18]
    // 0xcf8e10: LoadField: r1 = r0->field_7
    //     0xcf8e10: ldur            w1, [x0, #7]
    // 0xcf8e14: DecompressPointer r1
    //     0xcf8e14: add             x1, x1, HEAP, lsl #32
    // 0xcf8e18: mov             x0, x1
    // 0xcf8e1c: stur            x0, [fp, #-8]
    // 0xcf8e20: r0 = StadiumBorder()
    //     0xcf8e20: bl              #0x70f13c  ; AllocateStadiumBorderStub -> StadiumBorder (size=0xc)
    // 0xcf8e24: ldur            x1, [fp, #-8]
    // 0xcf8e28: StoreField: r0->field_7 = r1
    //     0xcf8e28: stur            w1, [x0, #7]
    // 0xcf8e2c: LeaveFrame
    //     0xcf8e2c: mov             SP, fp
    //     0xcf8e30: ldp             fp, lr, [SP], #0x10
    // 0xcf8e34: ret
    //     0xcf8e34: ret             
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0xcfa5ac, size: 0xc4
    // 0xcfa5ac: EnterFrame
    //     0xcfa5ac: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa5b0: mov             fp, SP
    // 0xcfa5b4: AllocStack(0x28)
    //     0xcfa5b4: sub             SP, SP, #0x28
    // 0xcfa5b8: SetupParameters(StadiumBorder this /* r1, fp-0x8 */)
    //     0xcfa5b8: mov             x0, x4
    //     0xcfa5bc: ldur            w1, [x0, #0x13]
    //     0xcfa5c0: add             x1, x1, HEAP, lsl #32
    //     0xcfa5c4: sub             x0, x1, #4
    //     0xcfa5c8: add             x1, fp, w0, sxtw #2
    //     0xcfa5cc: ldr             x1, [x1, #0x10]
    //     0xcfa5d0: stur            x1, [fp, #-8]
    // 0xcfa5d4: CheckStackOverflow
    //     0xcfa5d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa5d8: cmp             SP, x16
    //     0xcfa5dc: b.ls            #0xcfa668
    // 0xcfa5e0: SaveReg r1
    //     0xcfa5e0: str             x1, [SP, #-8]!
    // 0xcfa5e4: r0 = shortestSide()
    //     0xcfa5e4: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0xcfa5e8: add             SP, SP, #8
    // 0xcfa5ec: mov             v1.16b, v0.16b
    // 0xcfa5f0: d0 = 2.000000
    //     0xcfa5f0: fmov            d0, #2.00000000
    // 0xcfa5f4: fdiv            d2, d1, d0
    // 0xcfa5f8: stur            d2, [fp, #-0x28]
    // 0xcfa5fc: r0 = Radius()
    //     0xcfa5fc: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xcfa600: ldur            d0, [fp, #-0x28]
    // 0xcfa604: stur            x0, [fp, #-0x10]
    // 0xcfa608: StoreField: r0->field_7 = d0
    //     0xcfa608: stur            d0, [x0, #7]
    // 0xcfa60c: StoreField: r0->field_f = d0
    //     0xcfa60c: stur            d0, [x0, #0xf]
    // 0xcfa610: r0 = Path()
    //     0xcfa610: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcfa614: stur            x0, [fp, #-0x18]
    // 0xcfa618: SaveReg r0
    //     0xcfa618: str             x0, [SP, #-8]!
    // 0xcfa61c: r0 = _constructor()
    //     0xcfa61c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcfa620: add             SP, SP, #8
    // 0xcfa624: r0 = RRect()
    //     0xcfa624: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xcfa628: stur            x0, [fp, #-0x20]
    // 0xcfa62c: ldur            x16, [fp, #-8]
    // 0xcfa630: stp             x16, x0, [SP, #-0x10]!
    // 0xcfa634: ldur            x16, [fp, #-0x10]
    // 0xcfa638: SaveReg r16
    //     0xcfa638: str             x16, [SP, #-8]!
    // 0xcfa63c: r0 = RRect.fromRectAndRadius()
    //     0xcfa63c: bl              #0x660380  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xcfa640: add             SP, SP, #0x18
    // 0xcfa644: ldur            x16, [fp, #-0x18]
    // 0xcfa648: ldur            lr, [fp, #-0x20]
    // 0xcfa64c: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa650: r0 = addRRect()
    //     0xcfa650: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0xcfa654: add             SP, SP, #0x10
    // 0xcfa658: ldur            x0, [fp, #-0x18]
    // 0xcfa65c: LeaveFrame
    //     0xcfa65c: mov             SP, fp
    //     0xcfa660: ldp             fp, lr, [SP], #0x10
    // 0xcfa664: ret
    //     0xcfa664: ret             
    // 0xcfa668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa66c: b               #0xcfa5e0
  }
}

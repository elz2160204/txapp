// lib: , url: package:flutter/src/painting/box_fit.dart

// class id: 1049352, size: 0x8
class :: {

  static _ applyBoxFit(/* No info */) {
    // ** addr: 0x626a14, size: 0x4f0
    // 0x626a14: EnterFrame
    //     0x626a14: stp             fp, lr, [SP, #-0x10]!
    //     0x626a18: mov             fp, SP
    // 0x626a1c: AllocStack(0x40)
    //     0x626a1c: sub             SP, SP, #0x40
    // 0x626a20: d0 = 0.000000
    //     0x626a20: eor             v0.16b, v0.16b, v0.16b
    // 0x626a24: CheckStackOverflow
    //     0x626a24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x626a28: cmp             SP, x16
    //     0x626a2c: b.ls            #0x626ec4
    // 0x626a30: ldr             x0, [fp, #0x18]
    // 0x626a34: LoadField: d1 = r0->field_f
    //     0x626a34: ldur            d1, [x0, #0xf]
    // 0x626a38: stur            d1, [fp, #-0x38]
    // 0x626a3c: fcmp            d1, d0
    // 0x626a40: b.vs            #0x626a48
    // 0x626a44: b.le            #0x626a88
    // 0x626a48: LoadField: d2 = r0->field_7
    //     0x626a48: ldur            d2, [x0, #7]
    // 0x626a4c: stur            d2, [fp, #-0x30]
    // 0x626a50: fcmp            d2, d0
    // 0x626a54: b.vs            #0x626a5c
    // 0x626a58: b.le            #0x626a88
    // 0x626a5c: ldr             x1, [fp, #0x10]
    // 0x626a60: LoadField: d3 = r1->field_f
    //     0x626a60: ldur            d3, [x1, #0xf]
    // 0x626a64: stur            d3, [fp, #-0x20]
    // 0x626a68: fcmp            d3, d0
    // 0x626a6c: b.vs            #0x626a74
    // 0x626a70: b.le            #0x626a88
    // 0x626a74: LoadField: d4 = r1->field_7
    //     0x626a74: ldur            d4, [x1, #7]
    // 0x626a78: stur            d4, [fp, #-0x28]
    // 0x626a7c: fcmp            d4, d0
    // 0x626a80: b.vs            #0x626a9c
    // 0x626a84: b.gt            #0x626a9c
    // 0x626a88: r0 = Instance_FittedSizes
    //     0x626a88: add             x0, PP, #0x28, lsl #12  ; [pp+0x28878] Obj!FittedSizes@b37461
    //     0x626a8c: ldr             x0, [x0, #0x878]
    // 0x626a90: LeaveFrame
    //     0x626a90: mov             SP, fp
    //     0x626a94: ldp             fp, lr, [SP], #0x10
    // 0x626a98: ret
    //     0x626a98: ret             
    // 0x626a9c: ldr             x2, [fp, #0x20]
    // 0x626aa0: LoadField: r3 = r2->field_7
    //     0x626aa0: ldur            x3, [x2, #7]
    // 0x626aa4: cmp             x3, #3
    // 0x626aa8: b.gt            #0x626bf0
    // 0x626aac: cmp             x3, #1
    // 0x626ab0: b.gt            #0x626b2c
    // 0x626ab4: cmp             x3, #0
    // 0x626ab8: b.gt            #0x626acc
    // 0x626abc: mov             x16, x1
    // 0x626ac0: mov             x1, x0
    // 0x626ac4: mov             x0, x16
    // 0x626ac8: b               #0x626e9c
    // 0x626acc: fdiv            d0, d4, d3
    // 0x626ad0: fdiv            d5, d2, d1
    // 0x626ad4: fcmp            d0, d5
    // 0x626ad8: b.vs            #0x626b04
    // 0x626adc: b.le            #0x626b04
    // 0x626ae0: fmul            d0, d2, d3
    // 0x626ae4: fdiv            d2, d0, d1
    // 0x626ae8: stur            d2, [fp, #-0x18]
    // 0x626aec: r0 = Size()
    //     0x626aec: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626af0: ldur            d0, [fp, #-0x18]
    // 0x626af4: StoreField: r0->field_7 = d0
    //     0x626af4: stur            d0, [x0, #7]
    // 0x626af8: ldur            d3, [fp, #-0x20]
    // 0x626afc: StoreField: r0->field_f = d3
    //     0x626afc: stur            d3, [x0, #0xf]
    // 0x626b00: b               #0x626b24
    // 0x626b04: fmul            d0, d1, d4
    // 0x626b08: fdiv            d1, d0, d2
    // 0x626b0c: stur            d1, [fp, #-0x18]
    // 0x626b10: r0 = Size()
    //     0x626b10: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626b14: ldur            d0, [fp, #-0x28]
    // 0x626b18: StoreField: r0->field_7 = d0
    //     0x626b18: stur            d0, [x0, #7]
    // 0x626b1c: ldur            d0, [fp, #-0x18]
    // 0x626b20: StoreField: r0->field_f = d0
    //     0x626b20: stur            d0, [x0, #0xf]
    // 0x626b24: ldr             x1, [fp, #0x18]
    // 0x626b28: b               #0x626e9c
    // 0x626b2c: mov             v0.16b, v4.16b
    // 0x626b30: cmp             x3, #2
    // 0x626b34: b.gt            #0x626b9c
    // 0x626b38: fdiv            d4, d0, d3
    // 0x626b3c: fdiv            d5, d2, d1
    // 0x626b40: fcmp            d4, d5
    // 0x626b44: b.vs            #0x626b70
    // 0x626b48: b.le            #0x626b70
    // 0x626b4c: fmul            d1, d2, d3
    // 0x626b50: fdiv            d3, d1, d0
    // 0x626b54: stur            d3, [fp, #-0x18]
    // 0x626b58: r0 = Size()
    //     0x626b58: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626b5c: ldur            d1, [fp, #-0x30]
    // 0x626b60: StoreField: r0->field_7 = d1
    //     0x626b60: stur            d1, [x0, #7]
    // 0x626b64: ldur            d0, [fp, #-0x18]
    // 0x626b68: StoreField: r0->field_f = d0
    //     0x626b68: stur            d0, [x0, #0xf]
    // 0x626b6c: b               #0x626b90
    // 0x626b70: fmul            d2, d1, d0
    // 0x626b74: fdiv            d0, d2, d3
    // 0x626b78: stur            d0, [fp, #-0x18]
    // 0x626b7c: r0 = Size()
    //     0x626b7c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626b80: ldur            d0, [fp, #-0x18]
    // 0x626b84: StoreField: r0->field_7 = d0
    //     0x626b84: stur            d0, [x0, #7]
    // 0x626b88: ldur            d1, [fp, #-0x38]
    // 0x626b8c: StoreField: r0->field_f = d1
    //     0x626b8c: stur            d1, [x0, #0xf]
    // 0x626b90: mov             x1, x0
    // 0x626b94: ldr             x0, [fp, #0x10]
    // 0x626b98: b               #0x626e9c
    // 0x626b9c: mov             v1.16b, v2.16b
    // 0x626ba0: fmul            d2, d1, d3
    // 0x626ba4: fdiv            d3, d2, d0
    // 0x626ba8: stur            d3, [fp, #-0x18]
    // 0x626bac: r0 = Size()
    //     0x626bac: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626bb0: ldur            d2, [fp, #-0x30]
    // 0x626bb4: stur            x0, [fp, #-8]
    // 0x626bb8: StoreField: r0->field_7 = d2
    //     0x626bb8: stur            d2, [x0, #7]
    // 0x626bbc: ldur            d0, [fp, #-0x18]
    // 0x626bc0: StoreField: r0->field_f = d0
    //     0x626bc0: stur            d0, [x0, #0xf]
    // 0x626bc4: ldur            d1, [fp, #-0x28]
    // 0x626bc8: fmul            d3, d0, d1
    // 0x626bcc: fdiv            d0, d3, d2
    // 0x626bd0: stur            d0, [fp, #-0x18]
    // 0x626bd4: r0 = Size()
    //     0x626bd4: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626bd8: ldur            d4, [fp, #-0x28]
    // 0x626bdc: StoreField: r0->field_7 = d4
    //     0x626bdc: stur            d4, [x0, #7]
    // 0x626be0: ldur            d0, [fp, #-0x18]
    // 0x626be4: StoreField: r0->field_f = d0
    //     0x626be4: stur            d0, [x0, #0xf]
    // 0x626be8: ldur            x1, [fp, #-8]
    // 0x626bec: b               #0x626e9c
    // 0x626bf0: cmp             x3, #5
    // 0x626bf4: b.gt            #0x626e0c
    // 0x626bf8: cmp             x3, #4
    // 0x626bfc: b.gt            #0x626c50
    // 0x626c00: fmul            d0, d1, d4
    // 0x626c04: fdiv            d2, d0, d3
    // 0x626c08: stur            d2, [fp, #-0x18]
    // 0x626c0c: r0 = Size()
    //     0x626c0c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626c10: ldur            d0, [fp, #-0x18]
    // 0x626c14: stur            x0, [fp, #-8]
    // 0x626c18: StoreField: r0->field_7 = d0
    //     0x626c18: stur            d0, [x0, #7]
    // 0x626c1c: ldur            d1, [fp, #-0x38]
    // 0x626c20: StoreField: r0->field_f = d1
    //     0x626c20: stur            d1, [x0, #0xf]
    // 0x626c24: ldur            d2, [fp, #-0x20]
    // 0x626c28: fmul            d3, d0, d2
    // 0x626c2c: fdiv            d0, d3, d1
    // 0x626c30: stur            d0, [fp, #-0x18]
    // 0x626c34: r0 = Size()
    //     0x626c34: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626c38: ldur            d0, [fp, #-0x18]
    // 0x626c3c: StoreField: r0->field_7 = d0
    //     0x626c3c: stur            d0, [x0, #7]
    // 0x626c40: ldur            d3, [fp, #-0x20]
    // 0x626c44: StoreField: r0->field_f = d3
    //     0x626c44: stur            d3, [x0, #0xf]
    // 0x626c48: ldur            x1, [fp, #-8]
    // 0x626c4c: b               #0x626e9c
    // 0x626c50: fcmp            d2, d4
    // 0x626c54: b.vs            #0x626c6c
    // 0x626c58: b.le            #0x626c6c
    // 0x626c5c: mov             v2.16b, v4.16b
    // 0x626c60: mov             v0.16b, v1.16b
    // 0x626c64: mov             v1.16b, v3.16b
    // 0x626c68: b               #0x626d24
    // 0x626c6c: fcmp            d2, d4
    // 0x626c70: b.vs            #0x626c84
    // 0x626c74: b.ge            #0x626c84
    // 0x626c78: mov             v0.16b, v1.16b
    // 0x626c7c: mov             v1.16b, v3.16b
    // 0x626c80: b               #0x626d24
    // 0x626c84: fcmp            d2, d0
    // 0x626c88: b.vs            #0x626c90
    // 0x626c8c: b.eq            #0x626c98
    // 0x626c90: r0 = false
    //     0x626c90: add             x0, NULL, #0x30  ; false
    // 0x626c94: b               #0x626c9c
    // 0x626c98: r0 = true
    //     0x626c98: add             x0, NULL, #0x20  ; true
    // 0x626c9c: tbnz            w0, #4, #0x626cb8
    // 0x626ca0: fadd            d5, d2, d4
    // 0x626ca4: fmul            d6, d5, d2
    // 0x626ca8: fmul            d2, d6, d4
    // 0x626cac: mov             v0.16b, v1.16b
    // 0x626cb0: mov             v1.16b, v3.16b
    // 0x626cb4: b               #0x626d24
    // 0x626cb8: tbnz            w0, #4, #0x626cfc
    // 0x626cbc: r0 = inline_Allocate_Double()
    //     0x626cbc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x626cc0: add             x0, x0, #0x10
    //     0x626cc4: cmp             x1, x0
    //     0x626cc8: b.ls            #0x626ecc
    //     0x626ccc: str             x0, [THR, #0x60]  ; THR::top
    //     0x626cd0: sub             x0, x0, #0xf
    //     0x626cd4: mov             x1, #0xd108
    //     0x626cd8: movk            x1, #3, lsl #16
    //     0x626cdc: stur            x1, [x0, #-1]
    // 0x626ce0: StoreField: r0->field_7 = d4
    //     0x626ce0: stur            d4, [x0, #7]
    // 0x626ce4: SaveReg r0
    //     0x626ce4: str             x0, [SP, #-8]!
    // 0x626ce8: r0 = isNegative()
    //     0x626ce8: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x626cec: add             SP, SP, #8
    // 0x626cf0: tbnz            w0, #4, #0x626cfc
    // 0x626cf4: ldur            d0, [fp, #-0x28]
    // 0x626cf8: b               #0x626d08
    // 0x626cfc: ldur            d0, [fp, #-0x28]
    // 0x626d00: fcmp            d0, d0
    // 0x626d04: b.vc            #0x626d18
    // 0x626d08: mov             v2.16b, v0.16b
    // 0x626d0c: ldur            d1, [fp, #-0x20]
    // 0x626d10: ldur            d0, [fp, #-0x38]
    // 0x626d14: b               #0x626d24
    // 0x626d18: ldur            d2, [fp, #-0x30]
    // 0x626d1c: ldur            d1, [fp, #-0x20]
    // 0x626d20: ldur            d0, [fp, #-0x38]
    // 0x626d24: stur            d2, [fp, #-0x18]
    // 0x626d28: fcmp            d0, d1
    // 0x626d2c: b.vs            #0x626d3c
    // 0x626d30: b.le            #0x626d3c
    // 0x626d34: mov             v0.16b, v2.16b
    // 0x626d38: b               #0x626dec
    // 0x626d3c: fcmp            d0, d1
    // 0x626d40: b.vs            #0x626d54
    // 0x626d44: b.ge            #0x626d54
    // 0x626d48: mov             v1.16b, v0.16b
    // 0x626d4c: mov             v0.16b, v2.16b
    // 0x626d50: b               #0x626dec
    // 0x626d54: d3 = 0.000000
    //     0x626d54: eor             v3.16b, v3.16b, v3.16b
    // 0x626d58: fcmp            d0, d3
    // 0x626d5c: b.vs            #0x626d64
    // 0x626d60: b.eq            #0x626d6c
    // 0x626d64: r0 = false
    //     0x626d64: add             x0, NULL, #0x30  ; false
    // 0x626d68: b               #0x626d70
    // 0x626d6c: r0 = true
    //     0x626d6c: add             x0, NULL, #0x20  ; true
    // 0x626d70: tbnz            w0, #4, #0x626d8c
    // 0x626d74: fadd            d3, d0, d1
    // 0x626d78: fmul            d4, d3, d0
    // 0x626d7c: fmul            d0, d4, d1
    // 0x626d80: mov             v1.16b, v0.16b
    // 0x626d84: mov             v0.16b, v2.16b
    // 0x626d88: b               #0x626dec
    // 0x626d8c: tbnz            w0, #4, #0x626dd0
    // 0x626d90: r0 = inline_Allocate_Double()
    //     0x626d90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x626d94: add             x0, x0, #0x10
    //     0x626d98: cmp             x1, x0
    //     0x626d9c: b.ls            #0x626eec
    //     0x626da0: str             x0, [THR, #0x60]  ; THR::top
    //     0x626da4: sub             x0, x0, #0xf
    //     0x626da8: mov             x1, #0xd108
    //     0x626dac: movk            x1, #3, lsl #16
    //     0x626db0: stur            x1, [x0, #-1]
    // 0x626db4: StoreField: r0->field_7 = d1
    //     0x626db4: stur            d1, [x0, #7]
    // 0x626db8: SaveReg r0
    //     0x626db8: str             x0, [SP, #-8]!
    // 0x626dbc: r0 = isNegative()
    //     0x626dbc: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x626dc0: add             SP, SP, #8
    // 0x626dc4: tbnz            w0, #4, #0x626dd0
    // 0x626dc8: ldur            d1, [fp, #-0x20]
    // 0x626dcc: b               #0x626ddc
    // 0x626dd0: ldur            d1, [fp, #-0x20]
    // 0x626dd4: fcmp            d1, d1
    // 0x626dd8: b.vc            #0x626de4
    // 0x626ddc: ldur            d0, [fp, #-0x18]
    // 0x626de0: b               #0x626dec
    // 0x626de4: ldur            d1, [fp, #-0x38]
    // 0x626de8: ldur            d0, [fp, #-0x18]
    // 0x626dec: stur            d1, [fp, #-0x40]
    // 0x626df0: r0 = Size()
    //     0x626df0: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626df4: ldur            d0, [fp, #-0x18]
    // 0x626df8: StoreField: r0->field_7 = d0
    //     0x626df8: stur            d0, [x0, #7]
    // 0x626dfc: ldur            d0, [fp, #-0x40]
    // 0x626e00: StoreField: r0->field_f = d0
    //     0x626e00: stur            d0, [x0, #0xf]
    // 0x626e04: mov             x1, x0
    // 0x626e08: b               #0x626e9c
    // 0x626e0c: mov             v0.16b, v4.16b
    // 0x626e10: mov             v31.16b, v2.16b
    // 0x626e14: mov             v2.16b, v3.16b
    // 0x626e18: mov             v3.16b, v31.16b
    // 0x626e1c: mov             v31.16b, v1.16b
    // 0x626e20: mov             v1.16b, v2.16b
    // 0x626e24: mov             v2.16b, v31.16b
    // 0x626e28: fdiv            d4, d3, d2
    // 0x626e2c: stur            d4, [fp, #-0x40]
    // 0x626e30: fcmp            d2, d1
    // 0x626e34: b.vs            #0x626e60
    // 0x626e38: b.le            #0x626e60
    // 0x626e3c: fmul            d2, d1, d4
    // 0x626e40: stur            d2, [fp, #-0x18]
    // 0x626e44: r0 = Size()
    //     0x626e44: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626e48: ldur            d0, [fp, #-0x18]
    // 0x626e4c: StoreField: r0->field_7 = d0
    //     0x626e4c: stur            d0, [x0, #7]
    // 0x626e50: ldur            d1, [fp, #-0x20]
    // 0x626e54: StoreField: r0->field_f = d1
    //     0x626e54: stur            d1, [x0, #0xf]
    // 0x626e58: mov             v1.16b, v0.16b
    // 0x626e5c: b               #0x626e68
    // 0x626e60: ldr             x0, [fp, #0x18]
    // 0x626e64: mov             v1.16b, v3.16b
    // 0x626e68: ldur            d0, [fp, #-0x28]
    // 0x626e6c: fcmp            d1, d0
    // 0x626e70: b.vs            #0x626e98
    // 0x626e74: b.le            #0x626e98
    // 0x626e78: ldur            d1, [fp, #-0x40]
    // 0x626e7c: fdiv            d2, d0, d1
    // 0x626e80: stur            d2, [fp, #-0x18]
    // 0x626e84: r0 = Size()
    //     0x626e84: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x626e88: ldur            d0, [fp, #-0x28]
    // 0x626e8c: StoreField: r0->field_7 = d0
    //     0x626e8c: stur            d0, [x0, #7]
    // 0x626e90: ldur            d0, [fp, #-0x18]
    // 0x626e94: StoreField: r0->field_f = d0
    //     0x626e94: stur            d0, [x0, #0xf]
    // 0x626e98: ldr             x1, [fp, #0x18]
    // 0x626e9c: stur            x1, [fp, #-8]
    // 0x626ea0: stur            x0, [fp, #-0x10]
    // 0x626ea4: r0 = FittedSizes()
    //     0x626ea4: bl              #0x626f04  ; AllocateFittedSizesStub -> FittedSizes (size=0x10)
    // 0x626ea8: ldur            x1, [fp, #-8]
    // 0x626eac: StoreField: r0->field_7 = r1
    //     0x626eac: stur            w1, [x0, #7]
    // 0x626eb0: ldur            x1, [fp, #-0x10]
    // 0x626eb4: StoreField: r0->field_b = r1
    //     0x626eb4: stur            w1, [x0, #0xb]
    // 0x626eb8: LeaveFrame
    //     0x626eb8: mov             SP, fp
    //     0x626ebc: ldp             fp, lr, [SP], #0x10
    // 0x626ec0: ret
    //     0x626ec0: ret             
    // 0x626ec4: r0 = StackOverflowSharedWithFPURegs()
    //     0x626ec4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x626ec8: b               #0x626a30
    // 0x626ecc: stp             q3, q4, [SP, #-0x20]!
    // 0x626ed0: stp             q1, q2, [SP, #-0x20]!
    // 0x626ed4: SaveReg d0
    //     0x626ed4: str             q0, [SP, #-0x10]!
    // 0x626ed8: r0 = AllocateDouble()
    //     0x626ed8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x626edc: RestoreReg d0
    //     0x626edc: ldr             q0, [SP], #0x10
    // 0x626ee0: ldp             q1, q2, [SP], #0x20
    // 0x626ee4: ldp             q3, q4, [SP], #0x20
    // 0x626ee8: b               #0x626ce0
    // 0x626eec: stp             q1, q2, [SP, #-0x20]!
    // 0x626ef0: SaveReg d0
    //     0x626ef0: str             q0, [SP, #-0x10]!
    // 0x626ef4: r0 = AllocateDouble()
    //     0x626ef4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x626ef8: RestoreReg d0
    //     0x626ef8: ldr             q0, [SP], #0x10
    // 0x626efc: ldp             q1, q2, [SP], #0x20
    // 0x626f00: b               #0x626db4
  }
}

// class id: 2109, size: 0x10, field offset: 0x8
//   const constructor, 
class FittedSizes extends Object {

  Size field_8;
  Size field_c;
}

// class id: 5934, size: 0x14, field offset: 0x14
enum BoxFit extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb1697c, size: 0x5c
    // 0xb1697c: EnterFrame
    //     0xb1697c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16980: mov             fp, SP
    // 0xb16984: CheckStackOverflow
    //     0xb16984: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16988: cmp             SP, x16
    //     0xb1698c: b.ls            #0xb169d0
    // 0xb16990: r1 = Null
    //     0xb16990: mov             x1, NULL
    // 0xb16994: r2 = 4
    //     0xb16994: mov             x2, #4
    // 0xb16998: r0 = AllocateArray()
    //     0xb16998: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1699c: r17 = "BoxFit."
    //     0xb1699c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21cf0] "BoxFit."
    //     0xb169a0: ldr             x17, [x17, #0xcf0]
    // 0xb169a4: StoreField: r0->field_f = r17
    //     0xb169a4: stur            w17, [x0, #0xf]
    // 0xb169a8: ldr             x1, [fp, #0x10]
    // 0xb169ac: LoadField: r2 = r1->field_f
    //     0xb169ac: ldur            w2, [x1, #0xf]
    // 0xb169b0: DecompressPointer r2
    //     0xb169b0: add             x2, x2, HEAP, lsl #32
    // 0xb169b4: StoreField: r0->field_13 = r2
    //     0xb169b4: stur            w2, [x0, #0x13]
    // 0xb169b8: SaveReg r0
    //     0xb169b8: str             x0, [SP, #-8]!
    // 0xb169bc: r0 = _interpolate()
    //     0xb169bc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb169c0: add             SP, SP, #8
    // 0xb169c4: LeaveFrame
    //     0xb169c4: mov             SP, fp
    //     0xb169c8: ldp             fp, lr, [SP], #0x10
    // 0xb169cc: ret
    //     0xb169cc: ret             
    // 0xb169d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb169d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb169d4: b               #0xb16990
  }
}

// lib: , url: package:flutter/src/painting/strut_style.dart

// class id: 1049382, size: 0x8
class :: {
}

// class id: 2707, size: 0x34, field offset: 0x8
//   const constructor, 
class StrutStyle extends _DiagnosticableTree&Object&Diagnosticable {

  _Double field_28;
  bool field_2c;
  _Double field_18;

  RenderComparison compareTo(StrutStyle, StrutStyle) {
    // ** addr: 0x631cd4, size: 0x8c
    // 0x631cd4: EnterFrame
    //     0x631cd4: stp             fp, lr, [SP, #-0x10]!
    //     0x631cd8: mov             fp, SP
    // 0x631cdc: CheckStackOverflow
    //     0x631cdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x631ce0: cmp             SP, x16
    //     0x631ce4: b.ls            #0x631d40
    // 0x631ce8: ldr             x0, [fp, #0x10]
    // 0x631cec: r2 = Null
    //     0x631cec: mov             x2, NULL
    // 0x631cf0: r1 = Null
    //     0x631cf0: mov             x1, NULL
    // 0x631cf4: r4 = 59
    //     0x631cf4: mov             x4, #0x3b
    // 0x631cf8: branchIfSmi(r0, 0x631d04)
    //     0x631cf8: tbz             w0, #0, #0x631d04
    // 0x631cfc: r4 = LoadClassIdInstr(r0)
    //     0x631cfc: ldur            x4, [x0, #-1]
    //     0x631d00: ubfx            x4, x4, #0xc, #0x14
    // 0x631d04: cmp             x4, #0xa93
    // 0x631d08: b.eq            #0x631d20
    // 0x631d0c: r8 = StrutStyle
    //     0x631d0c: add             x8, PP, #0x1f, lsl #12  ; [pp+0x1f940] Type: StrutStyle
    //     0x631d10: ldr             x8, [x8, #0x940]
    // 0x631d14: r3 = Null
    //     0x631d14: add             x3, PP, #0x28, lsl #12  ; [pp+0x28678] Null
    //     0x631d18: ldr             x3, [x3, #0x678]
    // 0x631d1c: r0 = DefaultTypeTest()
    //     0x631d1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x631d20: ldr             x16, [fp, #0x18]
    // 0x631d24: ldr             lr, [fp, #0x10]
    // 0x631d28: stp             lr, x16, [SP, #-0x10]!
    // 0x631d2c: r0 = compareTo()
    //     0x631d2c: bl              #0x631d48  ; [package:flutter/src/painting/strut_style.dart] StrutStyle::compareTo
    // 0x631d30: add             SP, SP, #0x10
    // 0x631d34: LeaveFrame
    //     0x631d34: mov             SP, fp
    //     0x631d38: ldp             fp, lr, [SP], #0x10
    // 0x631d3c: ret
    //     0x631d3c: ret             
    // 0x631d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x631d40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x631d44: b               #0x631ce8
  }
  RenderComparison compareTo(StrutStyle, StrutStyle) {
    // ** addr: 0x631d48, size: 0x1cc
    // 0x631d48: EnterFrame
    //     0x631d48: stp             fp, lr, [SP, #-0x10]!
    //     0x631d4c: mov             fp, SP
    // 0x631d50: CheckStackOverflow
    //     0x631d50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x631d54: cmp             SP, x16
    //     0x631d58: b.ls            #0x631f0c
    // 0x631d5c: ldr             x2, [fp, #0x18]
    // 0x631d60: ldr             x1, [fp, #0x10]
    // 0x631d64: cmp             w2, w1
    // 0x631d68: b.ne            #0x631d80
    // 0x631d6c: r0 = Instance_RenderComparison
    //     0x631d6c: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0x631d70: ldr             x0, [x0, #0x438]
    // 0x631d74: LeaveFrame
    //     0x631d74: mov             SP, fp
    //     0x631d78: ldp             fp, lr, [SP], #0x10
    // 0x631d7c: ret
    //     0x631d7c: ret             
    // 0x631d80: LoadField: r0 = r2->field_7
    //     0x631d80: ldur            w0, [x2, #7]
    // 0x631d84: DecompressPointer r0
    //     0x631d84: add             x0, x0, HEAP, lsl #32
    // 0x631d88: LoadField: r3 = r1->field_7
    //     0x631d88: ldur            w3, [x1, #7]
    // 0x631d8c: DecompressPointer r3
    //     0x631d8c: add             x3, x3, HEAP, lsl #32
    // 0x631d90: r4 = LoadClassIdInstr(r0)
    //     0x631d90: ldur            x4, [x0, #-1]
    //     0x631d94: ubfx            x4, x4, #0xc, #0x14
    // 0x631d98: stp             x3, x0, [SP, #-0x10]!
    // 0x631d9c: mov             x0, x4
    // 0x631da0: mov             lr, x0
    // 0x631da4: ldr             lr, [x21, lr, lsl #3]
    // 0x631da8: blr             lr
    // 0x631dac: add             SP, SP, #0x10
    // 0x631db0: tbnz            w0, #4, #0x631ee4
    // 0x631db4: ldr             x2, [fp, #0x18]
    // 0x631db8: ldr             x1, [fp, #0x10]
    // 0x631dbc: LoadField: r0 = r2->field_13
    //     0x631dbc: ldur            w0, [x2, #0x13]
    // 0x631dc0: DecompressPointer r0
    //     0x631dc0: add             x0, x0, HEAP, lsl #32
    // 0x631dc4: LoadField: r3 = r1->field_13
    //     0x631dc4: ldur            w3, [x1, #0x13]
    // 0x631dc8: DecompressPointer r3
    //     0x631dc8: add             x3, x3, HEAP, lsl #32
    // 0x631dcc: r4 = LoadClassIdInstr(r0)
    //     0x631dcc: ldur            x4, [x0, #-1]
    //     0x631dd0: ubfx            x4, x4, #0xc, #0x14
    // 0x631dd4: stp             x3, x0, [SP, #-0x10]!
    // 0x631dd8: mov             x0, x4
    // 0x631ddc: mov             lr, x0
    // 0x631de0: ldr             lr, [x21, lr, lsl #3]
    // 0x631de4: blr             lr
    // 0x631de8: add             SP, SP, #0x10
    // 0x631dec: tbnz            w0, #4, #0x631ee4
    // 0x631df0: ldr             x2, [fp, #0x18]
    // 0x631df4: ldr             x1, [fp, #0x10]
    // 0x631df8: LoadField: r0 = r2->field_1f
    //     0x631df8: ldur            w0, [x2, #0x1f]
    // 0x631dfc: DecompressPointer r0
    //     0x631dfc: add             x0, x0, HEAP, lsl #32
    // 0x631e00: LoadField: r3 = r1->field_1f
    //     0x631e00: ldur            w3, [x1, #0x1f]
    // 0x631e04: DecompressPointer r3
    //     0x631e04: add             x3, x3, HEAP, lsl #32
    // 0x631e08: cmp             w0, w3
    // 0x631e0c: b.ne            #0x631ee4
    // 0x631e10: LoadField: r0 = r2->field_23
    //     0x631e10: ldur            w0, [x2, #0x23]
    // 0x631e14: DecompressPointer r0
    //     0x631e14: add             x0, x0, HEAP, lsl #32
    // 0x631e18: LoadField: r3 = r1->field_23
    //     0x631e18: ldur            w3, [x1, #0x23]
    // 0x631e1c: DecompressPointer r3
    //     0x631e1c: add             x3, x3, HEAP, lsl #32
    // 0x631e20: cmp             w0, w3
    // 0x631e24: b.ne            #0x631ee4
    // 0x631e28: LoadField: r0 = r2->field_17
    //     0x631e28: ldur            w0, [x2, #0x17]
    // 0x631e2c: DecompressPointer r0
    //     0x631e2c: add             x0, x0, HEAP, lsl #32
    // 0x631e30: LoadField: r3 = r1->field_17
    //     0x631e30: ldur            w3, [x1, #0x17]
    // 0x631e34: DecompressPointer r3
    //     0x631e34: add             x3, x3, HEAP, lsl #32
    // 0x631e38: r4 = LoadClassIdInstr(r0)
    //     0x631e38: ldur            x4, [x0, #-1]
    //     0x631e3c: ubfx            x4, x4, #0xc, #0x14
    // 0x631e40: stp             x3, x0, [SP, #-0x10]!
    // 0x631e44: mov             x0, x4
    // 0x631e48: mov             lr, x0
    // 0x631e4c: ldr             lr, [x21, lr, lsl #3]
    // 0x631e50: blr             lr
    // 0x631e54: add             SP, SP, #0x10
    // 0x631e58: tbnz            w0, #4, #0x631ee4
    // 0x631e5c: ldr             x2, [fp, #0x18]
    // 0x631e60: ldr             x1, [fp, #0x10]
    // 0x631e64: LoadField: r0 = r2->field_27
    //     0x631e64: ldur            w0, [x2, #0x27]
    // 0x631e68: DecompressPointer r0
    //     0x631e68: add             x0, x0, HEAP, lsl #32
    // 0x631e6c: LoadField: r3 = r1->field_27
    //     0x631e6c: ldur            w3, [x1, #0x27]
    // 0x631e70: DecompressPointer r3
    //     0x631e70: add             x3, x3, HEAP, lsl #32
    // 0x631e74: r4 = LoadClassIdInstr(r0)
    //     0x631e74: ldur            x4, [x0, #-1]
    //     0x631e78: ubfx            x4, x4, #0xc, #0x14
    // 0x631e7c: stp             x3, x0, [SP, #-0x10]!
    // 0x631e80: mov             x0, x4
    // 0x631e84: mov             lr, x0
    // 0x631e88: ldr             lr, [x21, lr, lsl #3]
    // 0x631e8c: blr             lr
    // 0x631e90: add             SP, SP, #0x10
    // 0x631e94: tbnz            w0, #4, #0x631ee4
    // 0x631e98: ldr             x1, [fp, #0x18]
    // 0x631e9c: ldr             x0, [fp, #0x10]
    // 0x631ea0: LoadField: r2 = r1->field_2b
    //     0x631ea0: ldur            w2, [x1, #0x2b]
    // 0x631ea4: DecompressPointer r2
    //     0x631ea4: add             x2, x2, HEAP, lsl #32
    // 0x631ea8: LoadField: r3 = r0->field_2b
    //     0x631ea8: ldur            w3, [x0, #0x2b]
    // 0x631eac: DecompressPointer r3
    //     0x631eac: add             x3, x3, HEAP, lsl #32
    // 0x631eb0: cmp             w2, w3
    // 0x631eb4: b.ne            #0x631ee4
    // 0x631eb8: LoadField: r2 = r1->field_b
    //     0x631eb8: ldur            w2, [x1, #0xb]
    // 0x631ebc: DecompressPointer r2
    //     0x631ebc: add             x2, x2, HEAP, lsl #32
    // 0x631ec0: LoadField: r1 = r0->field_b
    //     0x631ec0: ldur            w1, [x0, #0xb]
    // 0x631ec4: DecompressPointer r1
    //     0x631ec4: add             x1, x1, HEAP, lsl #32
    // 0x631ec8: r16 = <String>
    //     0x631ec8: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x631ecc: stp             x2, x16, [SP, #-0x10]!
    // 0x631ed0: SaveReg r1
    //     0x631ed0: str             x1, [SP, #-8]!
    // 0x631ed4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x631ed4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x631ed8: r0 = listEquals()
    //     0x631ed8: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x631edc: add             SP, SP, #0x18
    // 0x631ee0: tbz             w0, #4, #0x631ef8
    // 0x631ee4: r0 = Instance_RenderComparison
    //     0x631ee4: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0x631ee8: ldr             x0, [x0, #0x470]
    // 0x631eec: LeaveFrame
    //     0x631eec: mov             SP, fp
    //     0x631ef0: ldp             fp, lr, [SP], #0x10
    // 0x631ef4: ret
    //     0x631ef4: ret             
    // 0x631ef8: r0 = Instance_RenderComparison
    //     0x631ef8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0x631efc: ldr             x0, [x0, #0x438]
    // 0x631f00: LeaveFrame
    //     0x631f00: mov             SP, fp
    //     0x631f04: ldp             fp, lr, [SP], #0x10
    // 0x631f08: ret
    //     0x631f08: ret             
    // 0x631f0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x631f0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x631f10: b               #0x631d5c
  }
  _ inheritFromTextStyle(/* No info */) {
    // ** addr: 0x7c60fc, size: 0x158
    // 0x7c60fc: EnterFrame
    //     0x7c60fc: stp             fp, lr, [SP, #-0x10]!
    //     0x7c6100: mov             fp, SP
    // 0x7c6104: AllocStack(0x48)
    //     0x7c6104: sub             SP, SP, #0x48
    // 0x7c6108: ldr             x0, [fp, #0x18]
    // 0x7c610c: LoadField: r1 = r0->field_7
    //     0x7c610c: ldur            w1, [x0, #7]
    // 0x7c6110: DecompressPointer r1
    //     0x7c6110: add             x1, x1, HEAP, lsl #32
    // 0x7c6114: cmp             w1, NULL
    // 0x7c6118: b.ne            #0x7c612c
    // 0x7c611c: ldr             x2, [fp, #0x10]
    // 0x7c6120: LoadField: r1 = r2->field_13
    //     0x7c6120: ldur            w1, [x2, #0x13]
    // 0x7c6124: DecompressPointer r1
    //     0x7c6124: add             x1, x1, HEAP, lsl #32
    // 0x7c6128: b               #0x7c6130
    // 0x7c612c: ldr             x2, [fp, #0x10]
    // 0x7c6130: stur            x1, [fp, #-0x48]
    // 0x7c6134: LoadField: r3 = r0->field_b
    //     0x7c6134: ldur            w3, [x0, #0xb]
    // 0x7c6138: DecompressPointer r3
    //     0x7c6138: add             x3, x3, HEAP, lsl #32
    // 0x7c613c: cmp             w3, NULL
    // 0x7c6140: b.ne            #0x7c614c
    // 0x7c6144: LoadField: r3 = r2->field_17
    //     0x7c6144: ldur            w3, [x2, #0x17]
    // 0x7c6148: DecompressPointer r3
    //     0x7c6148: add             x3, x3, HEAP, lsl #32
    // 0x7c614c: stur            x3, [fp, #-0x40]
    // 0x7c6150: LoadField: r4 = r0->field_13
    //     0x7c6150: ldur            w4, [x0, #0x13]
    // 0x7c6154: DecompressPointer r4
    //     0x7c6154: add             x4, x4, HEAP, lsl #32
    // 0x7c6158: cmp             w4, NULL
    // 0x7c615c: b.ne            #0x7c6168
    // 0x7c6160: LoadField: r4 = r2->field_1f
    //     0x7c6160: ldur            w4, [x2, #0x1f]
    // 0x7c6164: DecompressPointer r4
    //     0x7c6164: add             x4, x4, HEAP, lsl #32
    // 0x7c6168: stur            x4, [fp, #-0x38]
    // 0x7c616c: LoadField: r5 = r0->field_17
    //     0x7c616c: ldur            w5, [x0, #0x17]
    // 0x7c6170: DecompressPointer r5
    //     0x7c6170: add             x5, x5, HEAP, lsl #32
    // 0x7c6174: cmp             w5, NULL
    // 0x7c6178: b.ne            #0x7c6184
    // 0x7c617c: LoadField: r5 = r2->field_37
    //     0x7c617c: ldur            w5, [x2, #0x37]
    // 0x7c6180: DecompressPointer r5
    //     0x7c6180: add             x5, x5, HEAP, lsl #32
    // 0x7c6184: stur            x5, [fp, #-0x30]
    // 0x7c6188: LoadField: r6 = r0->field_27
    //     0x7c6188: ldur            w6, [x0, #0x27]
    // 0x7c618c: DecompressPointer r6
    //     0x7c618c: add             x6, x6, HEAP, lsl #32
    // 0x7c6190: stur            x6, [fp, #-0x28]
    // 0x7c6194: LoadField: r7 = r0->field_1f
    //     0x7c6194: ldur            w7, [x0, #0x1f]
    // 0x7c6198: DecompressPointer r7
    //     0x7c6198: add             x7, x7, HEAP, lsl #32
    // 0x7c619c: cmp             w7, NULL
    // 0x7c61a0: b.ne            #0x7c61ac
    // 0x7c61a4: LoadField: r7 = r2->field_23
    //     0x7c61a4: ldur            w7, [x2, #0x23]
    // 0x7c61a8: DecompressPointer r7
    //     0x7c61a8: add             x7, x7, HEAP, lsl #32
    // 0x7c61ac: stur            x7, [fp, #-0x20]
    // 0x7c61b0: LoadField: r8 = r0->field_23
    //     0x7c61b0: ldur            w8, [x0, #0x23]
    // 0x7c61b4: DecompressPointer r8
    //     0x7c61b4: add             x8, x8, HEAP, lsl #32
    // 0x7c61b8: cmp             w8, NULL
    // 0x7c61bc: b.ne            #0x7c61c8
    // 0x7c61c0: LoadField: r8 = r2->field_27
    //     0x7c61c0: ldur            w8, [x2, #0x27]
    // 0x7c61c4: DecompressPointer r8
    //     0x7c61c4: add             x8, x8, HEAP, lsl #32
    // 0x7c61c8: stur            x8, [fp, #-0x18]
    // 0x7c61cc: LoadField: r9 = r0->field_2b
    //     0x7c61cc: ldur            w9, [x0, #0x2b]
    // 0x7c61d0: DecompressPointer r9
    //     0x7c61d0: add             x9, x9, HEAP, lsl #32
    // 0x7c61d4: stur            x9, [fp, #-0x10]
    // 0x7c61d8: LoadField: r10 = r0->field_2f
    //     0x7c61d8: ldur            w10, [x0, #0x2f]
    // 0x7c61dc: DecompressPointer r10
    //     0x7c61dc: add             x10, x10, HEAP, lsl #32
    // 0x7c61e0: cmp             w10, NULL
    // 0x7c61e4: b.ne            #0x7c61f4
    // 0x7c61e8: LoadField: r0 = r2->field_5b
    //     0x7c61e8: ldur            w0, [x2, #0x5b]
    // 0x7c61ec: DecompressPointer r0
    //     0x7c61ec: add             x0, x0, HEAP, lsl #32
    // 0x7c61f0: b               #0x7c61f8
    // 0x7c61f4: mov             x0, x10
    // 0x7c61f8: stur            x0, [fp, #-8]
    // 0x7c61fc: r0 = StrutStyle()
    //     0x7c61fc: bl              #0x7c639c  ; AllocateStrutStyleStub -> StrutStyle (size=0x34)
    // 0x7c6200: ldur            x1, [fp, #-0x38]
    // 0x7c6204: StoreField: r0->field_13 = r1
    //     0x7c6204: stur            w1, [x0, #0x13]
    // 0x7c6208: ldur            x1, [fp, #-0x30]
    // 0x7c620c: StoreField: r0->field_17 = r1
    //     0x7c620c: stur            w1, [x0, #0x17]
    // 0x7c6210: ldur            x1, [fp, #-0x28]
    // 0x7c6214: StoreField: r0->field_27 = r1
    //     0x7c6214: stur            w1, [x0, #0x27]
    // 0x7c6218: ldur            x1, [fp, #-0x20]
    // 0x7c621c: StoreField: r0->field_1f = r1
    //     0x7c621c: stur            w1, [x0, #0x1f]
    // 0x7c6220: ldur            x1, [fp, #-0x18]
    // 0x7c6224: StoreField: r0->field_23 = r1
    //     0x7c6224: stur            w1, [x0, #0x23]
    // 0x7c6228: ldur            x1, [fp, #-0x10]
    // 0x7c622c: StoreField: r0->field_2b = r1
    //     0x7c622c: stur            w1, [x0, #0x2b]
    // 0x7c6230: ldur            x1, [fp, #-8]
    // 0x7c6234: StoreField: r0->field_2f = r1
    //     0x7c6234: stur            w1, [x0, #0x2f]
    // 0x7c6238: ldur            x1, [fp, #-0x48]
    // 0x7c623c: StoreField: r0->field_7 = r1
    //     0x7c623c: stur            w1, [x0, #7]
    // 0x7c6240: ldur            x1, [fp, #-0x40]
    // 0x7c6244: StoreField: r0->field_b = r1
    //     0x7c6244: stur            w1, [x0, #0xb]
    // 0x7c6248: LeaveFrame
    //     0x7c6248: mov             SP, fp
    //     0x7c624c: ldp             fp, lr, [SP], #0x10
    // 0x7c6250: ret
    //     0x7c6250: ret             
  }
  _ StrutStyle.fromTextStyle(/* No info */) {
    // ** addr: 0x7c6254, size: 0x148
    // 0x7c6254: EnterFrame
    //     0x7c6254: stp             fp, lr, [SP, #-0x10]!
    //     0x7c6258: mov             fp, SP
    // 0x7c625c: r1 = true
    //     0x7c625c: add             x1, NULL, #0x20  ; true
    // 0x7c6260: ldr             x2, [fp, #0x18]
    // 0x7c6264: StoreField: r2->field_2b = r1
    //     0x7c6264: stur            w1, [x2, #0x2b]
    // 0x7c6268: ldr             x1, [fp, #0x10]
    // 0x7c626c: LoadField: r0 = r1->field_13
    //     0x7c626c: ldur            w0, [x1, #0x13]
    // 0x7c6270: DecompressPointer r0
    //     0x7c6270: add             x0, x0, HEAP, lsl #32
    // 0x7c6274: StoreField: r2->field_7 = r0
    //     0x7c6274: stur            w0, [x2, #7]
    //     0x7c6278: ldurb           w16, [x2, #-1]
    //     0x7c627c: ldurb           w17, [x0, #-1]
    //     0x7c6280: and             x16, x17, x16, lsr #2
    //     0x7c6284: tst             x16, HEAP, lsr #32
    //     0x7c6288: b.eq            #0x7c6290
    //     0x7c628c: bl              #0xd6828c
    // 0x7c6290: LoadField: r0 = r1->field_17
    //     0x7c6290: ldur            w0, [x1, #0x17]
    // 0x7c6294: DecompressPointer r0
    //     0x7c6294: add             x0, x0, HEAP, lsl #32
    // 0x7c6298: StoreField: r2->field_b = r0
    //     0x7c6298: stur            w0, [x2, #0xb]
    //     0x7c629c: ldurb           w16, [x2, #-1]
    //     0x7c62a0: ldurb           w17, [x0, #-1]
    //     0x7c62a4: and             x16, x17, x16, lsr #2
    //     0x7c62a8: tst             x16, HEAP, lsr #32
    //     0x7c62ac: b.eq            #0x7c62b4
    //     0x7c62b0: bl              #0xd6828c
    // 0x7c62b4: LoadField: r0 = r1->field_37
    //     0x7c62b4: ldur            w0, [x1, #0x37]
    // 0x7c62b8: DecompressPointer r0
    //     0x7c62b8: add             x0, x0, HEAP, lsl #32
    // 0x7c62bc: StoreField: r2->field_17 = r0
    //     0x7c62bc: stur            w0, [x2, #0x17]
    //     0x7c62c0: ldurb           w16, [x2, #-1]
    //     0x7c62c4: ldurb           w17, [x0, #-1]
    //     0x7c62c8: and             x16, x17, x16, lsr #2
    //     0x7c62cc: tst             x16, HEAP, lsr #32
    //     0x7c62d0: b.eq            #0x7c62d8
    //     0x7c62d4: bl              #0xd6828c
    // 0x7c62d8: LoadField: r0 = r1->field_3b
    //     0x7c62d8: ldur            w0, [x1, #0x3b]
    // 0x7c62dc: DecompressPointer r0
    //     0x7c62dc: add             x0, x0, HEAP, lsl #32
    // 0x7c62e0: StoreField: r2->field_1b = r0
    //     0x7c62e0: stur            w0, [x2, #0x1b]
    //     0x7c62e4: ldurb           w16, [x2, #-1]
    //     0x7c62e8: ldurb           w17, [x0, #-1]
    //     0x7c62ec: and             x16, x17, x16, lsr #2
    //     0x7c62f0: tst             x16, HEAP, lsr #32
    //     0x7c62f4: b.eq            #0x7c62fc
    //     0x7c62f8: bl              #0xd6828c
    // 0x7c62fc: LoadField: r0 = r1->field_1f
    //     0x7c62fc: ldur            w0, [x1, #0x1f]
    // 0x7c6300: DecompressPointer r0
    //     0x7c6300: add             x0, x0, HEAP, lsl #32
    // 0x7c6304: StoreField: r2->field_13 = r0
    //     0x7c6304: stur            w0, [x2, #0x13]
    //     0x7c6308: ldurb           w16, [x2, #-1]
    //     0x7c630c: ldurb           w17, [x0, #-1]
    //     0x7c6310: and             x16, x17, x16, lsr #2
    //     0x7c6314: tst             x16, HEAP, lsr #32
    //     0x7c6318: b.eq            #0x7c6320
    //     0x7c631c: bl              #0xd6828c
    // 0x7c6320: LoadField: r0 = r1->field_23
    //     0x7c6320: ldur            w0, [x1, #0x23]
    // 0x7c6324: DecompressPointer r0
    //     0x7c6324: add             x0, x0, HEAP, lsl #32
    // 0x7c6328: StoreField: r2->field_1f = r0
    //     0x7c6328: stur            w0, [x2, #0x1f]
    //     0x7c632c: ldurb           w16, [x2, #-1]
    //     0x7c6330: ldurb           w17, [x0, #-1]
    //     0x7c6334: and             x16, x17, x16, lsr #2
    //     0x7c6338: tst             x16, HEAP, lsr #32
    //     0x7c633c: b.eq            #0x7c6344
    //     0x7c6340: bl              #0xd6828c
    // 0x7c6344: LoadField: r0 = r1->field_27
    //     0x7c6344: ldur            w0, [x1, #0x27]
    // 0x7c6348: DecompressPointer r0
    //     0x7c6348: add             x0, x0, HEAP, lsl #32
    // 0x7c634c: StoreField: r2->field_23 = r0
    //     0x7c634c: stur            w0, [x2, #0x23]
    //     0x7c6350: ldurb           w16, [x2, #-1]
    //     0x7c6354: ldurb           w17, [x0, #-1]
    //     0x7c6358: and             x16, x17, x16, lsr #2
    //     0x7c635c: tst             x16, HEAP, lsr #32
    //     0x7c6360: b.eq            #0x7c6368
    //     0x7c6364: bl              #0xd6828c
    // 0x7c6368: LoadField: r0 = r1->field_5b
    //     0x7c6368: ldur            w0, [x1, #0x5b]
    // 0x7c636c: DecompressPointer r0
    //     0x7c636c: add             x0, x0, HEAP, lsl #32
    // 0x7c6370: StoreField: r2->field_2f = r0
    //     0x7c6370: stur            w0, [x2, #0x2f]
    //     0x7c6374: ldurb           w16, [x2, #-1]
    //     0x7c6378: ldurb           w17, [x0, #-1]
    //     0x7c637c: and             x16, x17, x16, lsr #2
    //     0x7c6380: tst             x16, HEAP, lsr #32
    //     0x7c6384: b.eq            #0x7c638c
    //     0x7c6388: bl              #0xd6828c
    // 0x7c638c: r0 = Null
    //     0x7c638c: mov             x0, NULL
    // 0x7c6390: LeaveFrame
    //     0x7c6390: mov             SP, fp
    //     0x7c6394: ldp             fp, lr, [SP], #0x10
    // 0x7c6398: ret
    //     0x7c6398: ret             
  }
  _ toStringShort(/* No info */) {
    // ** addr: 0xa78008, size: 0xc
    // 0xa78008: r0 = "StrutStyle"
    //     0xa78008: add             x0, PP, #0x28, lsl #12  ; [pp+0x28670] "StrutStyle"
    //     0xa7800c: ldr             x0, [x0, #0x670]
    // 0xa78010: ret
    //     0xa78010: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb05a3c, size: 0x98
    // 0xb05a3c: EnterFrame
    //     0xb05a3c: stp             fp, lr, [SP, #-0x10]!
    //     0xb05a40: mov             fp, SP
    // 0xb05a44: CheckStackOverflow
    //     0xb05a44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb05a48: cmp             SP, x16
    //     0xb05a4c: b.ls            #0xb05acc
    // 0xb05a50: ldr             x0, [fp, #0x10]
    // 0xb05a54: LoadField: r1 = r0->field_7
    //     0xb05a54: ldur            w1, [x0, #7]
    // 0xb05a58: DecompressPointer r1
    //     0xb05a58: add             x1, x1, HEAP, lsl #32
    // 0xb05a5c: LoadField: r2 = r0->field_13
    //     0xb05a5c: ldur            w2, [x0, #0x13]
    // 0xb05a60: DecompressPointer r2
    //     0xb05a60: add             x2, x2, HEAP, lsl #32
    // 0xb05a64: LoadField: r3 = r0->field_1f
    //     0xb05a64: ldur            w3, [x0, #0x1f]
    // 0xb05a68: DecompressPointer r3
    //     0xb05a68: add             x3, x3, HEAP, lsl #32
    // 0xb05a6c: LoadField: r4 = r0->field_23
    //     0xb05a6c: ldur            w4, [x0, #0x23]
    // 0xb05a70: DecompressPointer r4
    //     0xb05a70: add             x4, x4, HEAP, lsl #32
    // 0xb05a74: LoadField: r5 = r0->field_17
    //     0xb05a74: ldur            w5, [x0, #0x17]
    // 0xb05a78: DecompressPointer r5
    //     0xb05a78: add             x5, x5, HEAP, lsl #32
    // 0xb05a7c: LoadField: r6 = r0->field_27
    //     0xb05a7c: ldur            w6, [x0, #0x27]
    // 0xb05a80: DecompressPointer r6
    //     0xb05a80: add             x6, x6, HEAP, lsl #32
    // 0xb05a84: LoadField: r7 = r0->field_2b
    //     0xb05a84: ldur            w7, [x0, #0x2b]
    // 0xb05a88: DecompressPointer r7
    //     0xb05a88: add             x7, x7, HEAP, lsl #32
    // 0xb05a8c: stp             x2, x1, [SP, #-0x10]!
    // 0xb05a90: stp             x4, x3, [SP, #-0x10]!
    // 0xb05a94: stp             x6, x5, [SP, #-0x10]!
    // 0xb05a98: SaveReg r7
    //     0xb05a98: str             x7, [SP, #-8]!
    // 0xb05a9c: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0xb05a9c: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0xb05aa0: r0 = hash()
    //     0xb05aa0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb05aa4: add             SP, SP, #0x38
    // 0xb05aa8: mov             x2, x0
    // 0xb05aac: r0 = BoxInt64Instr(r2)
    //     0xb05aac: sbfiz           x0, x2, #1, #0x1f
    //     0xb05ab0: cmp             x2, x0, asr #1
    //     0xb05ab4: b.eq            #0xb05ac0
    //     0xb05ab8: bl              #0xd69bb8
    //     0xb05abc: stur            x2, [x0, #7]
    // 0xb05ac0: LeaveFrame
    //     0xb05ac0: mov             SP, fp
    //     0xb05ac4: ldp             fp, lr, [SP], #0x10
    // 0xb05ac8: ret
    //     0xb05ac8: ret             
    // 0xb05acc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb05acc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb05ad0: b               #0xb05a50
  }
  _ ==(/* No info */) {
    // ** addr: 0xc92f50, size: 0x238
    // 0xc92f50: EnterFrame
    //     0xc92f50: stp             fp, lr, [SP, #-0x10]!
    //     0xc92f54: mov             fp, SP
    // 0xc92f58: CheckStackOverflow
    //     0xc92f58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc92f5c: cmp             SP, x16
    //     0xc92f60: b.ls            #0xc93180
    // 0xc92f64: ldr             x1, [fp, #0x10]
    // 0xc92f68: cmp             w1, NULL
    // 0xc92f6c: b.ne            #0xc92f80
    // 0xc92f70: r0 = false
    //     0xc92f70: add             x0, NULL, #0x30  ; false
    // 0xc92f74: LeaveFrame
    //     0xc92f74: mov             SP, fp
    //     0xc92f78: ldp             fp, lr, [SP], #0x10
    // 0xc92f7c: ret
    //     0xc92f7c: ret             
    // 0xc92f80: ldr             x2, [fp, #0x18]
    // 0xc92f84: cmp             w2, w1
    // 0xc92f88: b.ne            #0xc92f9c
    // 0xc92f8c: r0 = true
    //     0xc92f8c: add             x0, NULL, #0x20  ; true
    // 0xc92f90: LeaveFrame
    //     0xc92f90: mov             SP, fp
    //     0xc92f94: ldp             fp, lr, [SP], #0x10
    // 0xc92f98: ret
    //     0xc92f98: ret             
    // 0xc92f9c: r0 = 59
    //     0xc92f9c: mov             x0, #0x3b
    // 0xc92fa0: branchIfSmi(r1, 0xc92fac)
    //     0xc92fa0: tbz             w1, #0, #0xc92fac
    // 0xc92fa4: r0 = LoadClassIdInstr(r1)
    //     0xc92fa4: ldur            x0, [x1, #-1]
    //     0xc92fa8: ubfx            x0, x0, #0xc, #0x14
    // 0xc92fac: SaveReg r1
    //     0xc92fac: str             x1, [SP, #-8]!
    // 0xc92fb0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc92fb0: mov             x17, #0x57c5
    //     0xc92fb4: add             lr, x0, x17
    //     0xc92fb8: ldr             lr, [x21, lr, lsl #3]
    //     0xc92fbc: blr             lr
    // 0xc92fc0: add             SP, SP, #8
    // 0xc92fc4: r1 = LoadClassIdInstr(r0)
    //     0xc92fc4: ldur            x1, [x0, #-1]
    //     0xc92fc8: ubfx            x1, x1, #0xc, #0x14
    // 0xc92fcc: r16 = StrutStyle
    //     0xc92fcc: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f940] Type: StrutStyle
    //     0xc92fd0: ldr             x16, [x16, #0x940]
    // 0xc92fd4: stp             x16, x0, [SP, #-0x10]!
    // 0xc92fd8: mov             x0, x1
    // 0xc92fdc: mov             lr, x0
    // 0xc92fe0: ldr             lr, [x21, lr, lsl #3]
    // 0xc92fe4: blr             lr
    // 0xc92fe8: add             SP, SP, #0x10
    // 0xc92fec: tbz             w0, #4, #0xc93000
    // 0xc92ff0: r0 = false
    //     0xc92ff0: add             x0, NULL, #0x30  ; false
    // 0xc92ff4: LeaveFrame
    //     0xc92ff4: mov             SP, fp
    //     0xc92ff8: ldp             fp, lr, [SP], #0x10
    // 0xc92ffc: ret
    //     0xc92ffc: ret             
    // 0xc93000: ldr             x1, [fp, #0x10]
    // 0xc93004: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc93004: mov             x0, #0x76
    //     0xc93008: tbz             w1, #0, #0xc93018
    //     0xc9300c: ldur            x0, [x1, #-1]
    //     0xc93010: ubfx            x0, x0, #0xc, #0x14
    //     0xc93014: lsl             x0, x0, #1
    // 0xc93018: r17 = 5414
    //     0xc93018: mov             x17, #0x1526
    // 0xc9301c: cmp             w0, w17
    // 0xc93020: b.ne            #0xc93170
    // 0xc93024: ldr             x2, [fp, #0x18]
    // 0xc93028: LoadField: r0 = r1->field_7
    //     0xc93028: ldur            w0, [x1, #7]
    // 0xc9302c: DecompressPointer r0
    //     0xc9302c: add             x0, x0, HEAP, lsl #32
    // 0xc93030: LoadField: r3 = r2->field_7
    //     0xc93030: ldur            w3, [x2, #7]
    // 0xc93034: DecompressPointer r3
    //     0xc93034: add             x3, x3, HEAP, lsl #32
    // 0xc93038: r4 = LoadClassIdInstr(r0)
    //     0xc93038: ldur            x4, [x0, #-1]
    //     0xc9303c: ubfx            x4, x4, #0xc, #0x14
    // 0xc93040: stp             x3, x0, [SP, #-0x10]!
    // 0xc93044: mov             x0, x4
    // 0xc93048: mov             lr, x0
    // 0xc9304c: ldr             lr, [x21, lr, lsl #3]
    // 0xc93050: blr             lr
    // 0xc93054: add             SP, SP, #0x10
    // 0xc93058: tbnz            w0, #4, #0xc93170
    // 0xc9305c: ldr             x2, [fp, #0x18]
    // 0xc93060: ldr             x1, [fp, #0x10]
    // 0xc93064: LoadField: r0 = r1->field_13
    //     0xc93064: ldur            w0, [x1, #0x13]
    // 0xc93068: DecompressPointer r0
    //     0xc93068: add             x0, x0, HEAP, lsl #32
    // 0xc9306c: LoadField: r3 = r2->field_13
    //     0xc9306c: ldur            w3, [x2, #0x13]
    // 0xc93070: DecompressPointer r3
    //     0xc93070: add             x3, x3, HEAP, lsl #32
    // 0xc93074: r4 = LoadClassIdInstr(r0)
    //     0xc93074: ldur            x4, [x0, #-1]
    //     0xc93078: ubfx            x4, x4, #0xc, #0x14
    // 0xc9307c: stp             x3, x0, [SP, #-0x10]!
    // 0xc93080: mov             x0, x4
    // 0xc93084: mov             lr, x0
    // 0xc93088: ldr             lr, [x21, lr, lsl #3]
    // 0xc9308c: blr             lr
    // 0xc93090: add             SP, SP, #0x10
    // 0xc93094: tbnz            w0, #4, #0xc93170
    // 0xc93098: ldr             x2, [fp, #0x18]
    // 0xc9309c: ldr             x1, [fp, #0x10]
    // 0xc930a0: LoadField: r0 = r1->field_1f
    //     0xc930a0: ldur            w0, [x1, #0x1f]
    // 0xc930a4: DecompressPointer r0
    //     0xc930a4: add             x0, x0, HEAP, lsl #32
    // 0xc930a8: LoadField: r3 = r2->field_1f
    //     0xc930a8: ldur            w3, [x2, #0x1f]
    // 0xc930ac: DecompressPointer r3
    //     0xc930ac: add             x3, x3, HEAP, lsl #32
    // 0xc930b0: cmp             w0, w3
    // 0xc930b4: b.ne            #0xc93170
    // 0xc930b8: LoadField: r0 = r1->field_23
    //     0xc930b8: ldur            w0, [x1, #0x23]
    // 0xc930bc: DecompressPointer r0
    //     0xc930bc: add             x0, x0, HEAP, lsl #32
    // 0xc930c0: LoadField: r3 = r2->field_23
    //     0xc930c0: ldur            w3, [x2, #0x23]
    // 0xc930c4: DecompressPointer r3
    //     0xc930c4: add             x3, x3, HEAP, lsl #32
    // 0xc930c8: cmp             w0, w3
    // 0xc930cc: b.ne            #0xc93170
    // 0xc930d0: LoadField: r0 = r1->field_17
    //     0xc930d0: ldur            w0, [x1, #0x17]
    // 0xc930d4: DecompressPointer r0
    //     0xc930d4: add             x0, x0, HEAP, lsl #32
    // 0xc930d8: LoadField: r3 = r2->field_17
    //     0xc930d8: ldur            w3, [x2, #0x17]
    // 0xc930dc: DecompressPointer r3
    //     0xc930dc: add             x3, x3, HEAP, lsl #32
    // 0xc930e0: r4 = LoadClassIdInstr(r0)
    //     0xc930e0: ldur            x4, [x0, #-1]
    //     0xc930e4: ubfx            x4, x4, #0xc, #0x14
    // 0xc930e8: stp             x3, x0, [SP, #-0x10]!
    // 0xc930ec: mov             x0, x4
    // 0xc930f0: mov             lr, x0
    // 0xc930f4: ldr             lr, [x21, lr, lsl #3]
    // 0xc930f8: blr             lr
    // 0xc930fc: add             SP, SP, #0x10
    // 0xc93100: tbnz            w0, #4, #0xc93170
    // 0xc93104: ldr             x2, [fp, #0x18]
    // 0xc93108: ldr             x1, [fp, #0x10]
    // 0xc9310c: LoadField: r0 = r1->field_27
    //     0xc9310c: ldur            w0, [x1, #0x27]
    // 0xc93110: DecompressPointer r0
    //     0xc93110: add             x0, x0, HEAP, lsl #32
    // 0xc93114: LoadField: r3 = r2->field_27
    //     0xc93114: ldur            w3, [x2, #0x27]
    // 0xc93118: DecompressPointer r3
    //     0xc93118: add             x3, x3, HEAP, lsl #32
    // 0xc9311c: r4 = LoadClassIdInstr(r0)
    //     0xc9311c: ldur            x4, [x0, #-1]
    //     0xc93120: ubfx            x4, x4, #0xc, #0x14
    // 0xc93124: stp             x3, x0, [SP, #-0x10]!
    // 0xc93128: mov             x0, x4
    // 0xc9312c: mov             lr, x0
    // 0xc93130: ldr             lr, [x21, lr, lsl #3]
    // 0xc93134: blr             lr
    // 0xc93138: add             SP, SP, #0x10
    // 0xc9313c: tbnz            w0, #4, #0xc93170
    // 0xc93140: ldr             x2, [fp, #0x18]
    // 0xc93144: ldr             x1, [fp, #0x10]
    // 0xc93148: LoadField: r3 = r1->field_2b
    //     0xc93148: ldur            w3, [x1, #0x2b]
    // 0xc9314c: DecompressPointer r3
    //     0xc9314c: add             x3, x3, HEAP, lsl #32
    // 0xc93150: LoadField: r1 = r2->field_2b
    //     0xc93150: ldur            w1, [x2, #0x2b]
    // 0xc93154: DecompressPointer r1
    //     0xc93154: add             x1, x1, HEAP, lsl #32
    // 0xc93158: cmp             w3, w1
    // 0xc9315c: r16 = true
    //     0xc9315c: add             x16, NULL, #0x20  ; true
    // 0xc93160: r17 = false
    //     0xc93160: add             x17, NULL, #0x30  ; false
    // 0xc93164: csel            x2, x16, x17, eq
    // 0xc93168: mov             x0, x2
    // 0xc9316c: b               #0xc93174
    // 0xc93170: r0 = false
    //     0xc93170: add             x0, NULL, #0x30  ; false
    // 0xc93174: LeaveFrame
    //     0xc93174: mov             SP, fp
    //     0xc93178: ldp             fp, lr, [SP], #0x10
    // 0xc9317c: ret
    //     0xc9317c: ret             
    // 0xc93180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc93180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc93184: b               #0xc92f64
  }
}

// lib: , url: package:flutter/src/painting/gradient.dart

// class id: 1049365, size: 0x8
class :: {

  static _ _interpolateColorsAndStops(/* No info */) {
    // ** addr: 0xcd5970, size: 0x174
    // 0xcd5970: EnterFrame
    //     0xcd5970: stp             fp, lr, [SP, #-0x10]!
    //     0xcd5974: mov             fp, SP
    // 0xcd5978: AllocStack(0x10)
    //     0xcd5978: sub             SP, SP, #0x10
    // 0xcd597c: CheckStackOverflow
    //     0xcd597c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd5980: cmp             SP, x16
    //     0xcd5984: b.ls            #0xcd5ac4
    // 0xcd5988: r1 = 5
    //     0xcd5988: mov             x1, #5
    // 0xcd598c: r0 = AllocateContext()
    //     0xcd598c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd5990: mov             x2, x0
    // 0xcd5994: ldr             x0, [fp, #0x30]
    // 0xcd5998: stur            x2, [fp, #-8]
    // 0xcd599c: StoreField: r2->field_f = r0
    //     0xcd599c: stur            w0, [x2, #0xf]
    // 0xcd59a0: ldr             x0, [fp, #0x28]
    // 0xcd59a4: StoreField: r2->field_13 = r0
    //     0xcd59a4: stur            w0, [x2, #0x13]
    // 0xcd59a8: ldr             x0, [fp, #0x20]
    // 0xcd59ac: StoreField: r2->field_17 = r0
    //     0xcd59ac: stur            w0, [x2, #0x17]
    // 0xcd59b0: ldr             x0, [fp, #0x18]
    // 0xcd59b4: StoreField: r2->field_1b = r0
    //     0xcd59b4: stur            w0, [x2, #0x1b]
    // 0xcd59b8: ldr             d0, [fp, #0x10]
    // 0xcd59bc: r0 = inline_Allocate_Double()
    //     0xcd59bc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd59c0: add             x0, x0, #0x10
    //     0xcd59c4: cmp             x1, x0
    //     0xcd59c8: b.ls            #0xcd5acc
    //     0xcd59cc: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd59d0: sub             x0, x0, #0xf
    //     0xcd59d4: mov             x1, #0xd108
    //     0xcd59d8: movk            x1, #3, lsl #16
    //     0xcd59dc: stur            x1, [x0, #-1]
    // 0xcd59e0: StoreField: r0->field_7 = d0
    //     0xcd59e0: stur            d0, [x0, #7]
    // 0xcd59e4: StoreField: r2->field_1f = r0
    //     0xcd59e4: stur            w0, [x2, #0x1f]
    // 0xcd59e8: r1 = <double, _SplayTreeSetNode, double>
    //     0xcd59e8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37210] TypeArguments: <double, _SplayTreeSetNode, double>
    //     0xcd59ec: ldr             x1, [x1, #0x210]
    // 0xcd59f0: r0 = SplayTreeSet()
    //     0xcd59f0: bl              #0x6ab25c  ; AllocateSplayTreeSetStub -> SplayTreeSet<C2X0> (size=0x30)
    // 0xcd59f4: stur            x0, [fp, #-0x10]
    // 0xcd59f8: SaveReg r0
    //     0xcd59f8: str             x0, [SP, #-8]!
    // 0xcd59fc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcd59fc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcd5a00: r0 = SplayTreeSet()
    //     0xcd5a00: bl              #0x6aaf04  ; [dart:collection] SplayTreeSet::SplayTreeSet
    // 0xcd5a04: add             SP, SP, #8
    // 0xcd5a08: ldur            x2, [fp, #-8]
    // 0xcd5a0c: LoadField: r0 = r2->field_13
    //     0xcd5a0c: ldur            w0, [x2, #0x13]
    // 0xcd5a10: DecompressPointer r0
    //     0xcd5a10: add             x0, x0, HEAP, lsl #32
    // 0xcd5a14: ldur            x16, [fp, #-0x10]
    // 0xcd5a18: stp             x0, x16, [SP, #-0x10]!
    // 0xcd5a1c: r0 = addAll()
    //     0xcd5a1c: bl              #0xbd9c88  ; [dart:collection] SplayTreeSet::addAll
    // 0xcd5a20: add             SP, SP, #0x10
    // 0xcd5a24: ldur            x2, [fp, #-8]
    // 0xcd5a28: LoadField: r0 = r2->field_1b
    //     0xcd5a28: ldur            w0, [x2, #0x1b]
    // 0xcd5a2c: DecompressPointer r0
    //     0xcd5a2c: add             x0, x0, HEAP, lsl #32
    // 0xcd5a30: ldur            x16, [fp, #-0x10]
    // 0xcd5a34: stp             x0, x16, [SP, #-0x10]!
    // 0xcd5a38: r0 = addAll()
    //     0xcd5a38: bl              #0xbd9c88  ; [dart:collection] SplayTreeSet::addAll
    // 0xcd5a3c: add             SP, SP, #0x10
    // 0xcd5a40: ldur            x16, [fp, #-0x10]
    // 0xcd5a44: r30 = false
    //     0xcd5a44: add             lr, NULL, #0x30  ; false
    // 0xcd5a48: stp             lr, x16, [SP, #-0x10]!
    // 0xcd5a4c: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0xcd5a4c: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0xcd5a50: r0 = toList()
    //     0xcd5a50: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xcd5a54: add             SP, SP, #0x10
    // 0xcd5a58: ldur            x2, [fp, #-8]
    // 0xcd5a5c: r1 = Function '<anonymous closure>': static.
    //     0xcd5a5c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37218] AnonymousClosure: static (0xcd5af0), in [package:flutter/src/painting/gradient.dart] ::_interpolateColorsAndStops (0xcd5970)
    //     0xcd5a60: ldr             x1, [x1, #0x218]
    // 0xcd5a64: stur            x0, [fp, #-8]
    // 0xcd5a68: r0 = AllocateClosure()
    //     0xcd5a68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd5a6c: r16 = <Color>
    //     0xcd5a6c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xcd5a70: ldr             x16, [x16, #0x3f8]
    // 0xcd5a74: ldur            lr, [fp, #-8]
    // 0xcd5a78: stp             lr, x16, [SP, #-0x10]!
    // 0xcd5a7c: SaveReg r0
    //     0xcd5a7c: str             x0, [SP, #-8]!
    // 0xcd5a80: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcd5a80: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcd5a84: r0 = map()
    //     0xcd5a84: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xcd5a88: add             SP, SP, #0x18
    // 0xcd5a8c: r16 = false
    //     0xcd5a8c: add             x16, NULL, #0x30  ; false
    // 0xcd5a90: stp             x16, x0, [SP, #-0x10]!
    // 0xcd5a94: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0xcd5a94: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0xcd5a98: r0 = toList()
    //     0xcd5a98: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xcd5a9c: add             SP, SP, #0x10
    // 0xcd5aa0: stur            x0, [fp, #-0x10]
    // 0xcd5aa4: r0 = _ColorsAndStops()
    //     0xcd5aa4: bl              #0xcd5ae4  ; Allocate_ColorsAndStopsStub -> _ColorsAndStops (size=0x10)
    // 0xcd5aa8: ldur            x1, [fp, #-0x10]
    // 0xcd5aac: StoreField: r0->field_7 = r1
    //     0xcd5aac: stur            w1, [x0, #7]
    // 0xcd5ab0: ldur            x1, [fp, #-8]
    // 0xcd5ab4: StoreField: r0->field_b = r1
    //     0xcd5ab4: stur            w1, [x0, #0xb]
    // 0xcd5ab8: LeaveFrame
    //     0xcd5ab8: mov             SP, fp
    //     0xcd5abc: ldp             fp, lr, [SP], #0x10
    // 0xcd5ac0: ret
    //     0xcd5ac0: ret             
    // 0xcd5ac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd5ac4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd5ac8: b               #0xcd5988
    // 0xcd5acc: SaveReg d0
    //     0xcd5acc: str             q0, [SP, #-0x10]!
    // 0xcd5ad0: SaveReg r2
    //     0xcd5ad0: str             x2, [SP, #-8]!
    // 0xcd5ad4: r0 = AllocateDouble()
    //     0xcd5ad4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd5ad8: RestoreReg r2
    //     0xcd5ad8: ldr             x2, [SP], #8
    // 0xcd5adc: RestoreReg d0
    //     0xcd5adc: ldr             q0, [SP], #0x10
    // 0xcd5ae0: b               #0xcd59e0
  }
  [closure] static Color <anonymous closure>(dynamic, double) {
    // ** addr: 0xcd5af0, size: 0xc8
    // 0xcd5af0: EnterFrame
    //     0xcd5af0: stp             fp, lr, [SP, #-0x10]!
    //     0xcd5af4: mov             fp, SP
    // 0xcd5af8: AllocStack(0x18)
    //     0xcd5af8: sub             SP, SP, #0x18
    // 0xcd5afc: SetupParameters()
    //     0xcd5afc: ldr             x0, [fp, #0x18]
    //     0xcd5b00: ldur            w1, [x0, #0x17]
    //     0xcd5b04: add             x1, x1, HEAP, lsl #32
    //     0xcd5b08: stur            x1, [fp, #-8]
    // 0xcd5b0c: CheckStackOverflow
    //     0xcd5b0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd5b10: cmp             SP, x16
    //     0xcd5b14: b.ls            #0xcd5bac
    // 0xcd5b18: LoadField: r0 = r1->field_f
    //     0xcd5b18: ldur            w0, [x1, #0xf]
    // 0xcd5b1c: DecompressPointer r0
    //     0xcd5b1c: add             x0, x0, HEAP, lsl #32
    // 0xcd5b20: LoadField: r2 = r1->field_13
    //     0xcd5b20: ldur            w2, [x1, #0x13]
    // 0xcd5b24: DecompressPointer r2
    //     0xcd5b24: add             x2, x2, HEAP, lsl #32
    // 0xcd5b28: ldr             x3, [fp, #0x10]
    // 0xcd5b2c: LoadField: d0 = r3->field_7
    //     0xcd5b2c: ldur            d0, [x3, #7]
    // 0xcd5b30: stur            d0, [fp, #-0x18]
    // 0xcd5b34: stp             x2, x0, [SP, #-0x10]!
    // 0xcd5b38: SaveReg d0
    //     0xcd5b38: str             d0, [SP, #-8]!
    // 0xcd5b3c: r0 = _sample()
    //     0xcd5b3c: bl              #0xcd5bb8  ; [package:flutter/src/painting/gradient.dart] ::_sample
    // 0xcd5b40: add             SP, SP, #0x18
    // 0xcd5b44: mov             x1, x0
    // 0xcd5b48: ldur            x0, [fp, #-8]
    // 0xcd5b4c: stur            x1, [fp, #-0x10]
    // 0xcd5b50: LoadField: r2 = r0->field_17
    //     0xcd5b50: ldur            w2, [x0, #0x17]
    // 0xcd5b54: DecompressPointer r2
    //     0xcd5b54: add             x2, x2, HEAP, lsl #32
    // 0xcd5b58: LoadField: r3 = r0->field_1b
    //     0xcd5b58: ldur            w3, [x0, #0x1b]
    // 0xcd5b5c: DecompressPointer r3
    //     0xcd5b5c: add             x3, x3, HEAP, lsl #32
    // 0xcd5b60: stp             x3, x2, [SP, #-0x10]!
    // 0xcd5b64: ldur            d0, [fp, #-0x18]
    // 0xcd5b68: SaveReg d0
    //     0xcd5b68: str             d0, [SP, #-8]!
    // 0xcd5b6c: r0 = _sample()
    //     0xcd5b6c: bl              #0xcd5bb8  ; [package:flutter/src/painting/gradient.dart] ::_sample
    // 0xcd5b70: add             SP, SP, #0x18
    // 0xcd5b74: mov             x1, x0
    // 0xcd5b78: ldur            x0, [fp, #-8]
    // 0xcd5b7c: LoadField: r2 = r0->field_1f
    //     0xcd5b7c: ldur            w2, [x0, #0x1f]
    // 0xcd5b80: DecompressPointer r2
    //     0xcd5b80: add             x2, x2, HEAP, lsl #32
    // 0xcd5b84: ldur            x16, [fp, #-0x10]
    // 0xcd5b88: stp             x1, x16, [SP, #-0x10]!
    // 0xcd5b8c: SaveReg r2
    //     0xcd5b8c: str             x2, [SP, #-8]!
    // 0xcd5b90: r0 = lerp()
    //     0xcd5b90: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd5b94: add             SP, SP, #0x18
    // 0xcd5b98: cmp             w0, NULL
    // 0xcd5b9c: b.eq            #0xcd5bb4
    // 0xcd5ba0: LeaveFrame
    //     0xcd5ba0: mov             SP, fp
    //     0xcd5ba4: ldp             fp, lr, [SP], #0x10
    // 0xcd5ba8: ret
    //     0xcd5ba8: ret             
    // 0xcd5bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd5bac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd5bb0: b               #0xcd5b18
    // 0xcd5bb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd5bb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _sample(/* No info */) {
    // ** addr: 0xcd5bb8, size: 0x370
    // 0xcd5bb8: EnterFrame
    //     0xcd5bb8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd5bbc: mov             fp, SP
    // 0xcd5bc0: AllocStack(0x40)
    //     0xcd5bc0: sub             SP, SP, #0x40
    // 0xcd5bc4: CheckStackOverflow
    //     0xcd5bc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd5bc8: cmp             SP, x16
    //     0xcd5bcc: b.ls            #0xcd5ef4
    // 0xcd5bd0: ldr             d0, [fp, #0x10]
    // 0xcd5bd4: r0 = inline_Allocate_Double()
    //     0xcd5bd4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd5bd8: add             x0, x0, #0x10
    //     0xcd5bdc: cmp             x1, x0
    //     0xcd5be0: b.ls            #0xcd5efc
    //     0xcd5be4: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd5be8: sub             x0, x0, #0xf
    //     0xcd5bec: mov             x1, #0xd108
    //     0xcd5bf0: movk            x1, #3, lsl #16
    //     0xcd5bf4: stur            x1, [x0, #-1]
    // 0xcd5bf8: StoreField: r0->field_7 = d0
    //     0xcd5bf8: stur            d0, [x0, #7]
    // 0xcd5bfc: stur            x0, [fp, #-8]
    // 0xcd5c00: r1 = 1
    //     0xcd5c00: mov             x1, #1
    // 0xcd5c04: r0 = AllocateContext()
    //     0xcd5c04: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd5c08: mov             x1, x0
    // 0xcd5c0c: ldur            x0, [fp, #-8]
    // 0xcd5c10: stur            x1, [fp, #-0x10]
    // 0xcd5c14: StoreField: r1->field_f = r0
    //     0xcd5c14: stur            w0, [x1, #0xf]
    // 0xcd5c18: ldr             x2, [fp, #0x18]
    // 0xcd5c1c: r0 = LoadClassIdInstr(r2)
    //     0xcd5c1c: ldur            x0, [x2, #-1]
    //     0xcd5c20: ubfx            x0, x0, #0xc, #0x14
    // 0xcd5c24: SaveReg r2
    //     0xcd5c24: str             x2, [SP, #-8]!
    // 0xcd5c28: r0 = GDT[cid_x0 + 0xcaae]()
    //     0xcd5c28: mov             x17, #0xcaae
    //     0xcd5c2c: add             lr, x0, x17
    //     0xcd5c30: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5c34: blr             lr
    // 0xcd5c38: add             SP, SP, #8
    // 0xcd5c3c: LoadField: d0 = r0->field_7
    //     0xcd5c3c: ldur            d0, [x0, #7]
    // 0xcd5c40: ldr             d1, [fp, #0x10]
    // 0xcd5c44: fcmp            d1, d0
    // 0xcd5c48: b.vs            #0xcd5c80
    // 0xcd5c4c: b.gt            #0xcd5c80
    // 0xcd5c50: ldr             x1, [fp, #0x20]
    // 0xcd5c54: r0 = LoadClassIdInstr(r1)
    //     0xcd5c54: ldur            x0, [x1, #-1]
    //     0xcd5c58: ubfx            x0, x0, #0xc, #0x14
    // 0xcd5c5c: SaveReg r1
    //     0xcd5c5c: str             x1, [SP, #-8]!
    // 0xcd5c60: r0 = GDT[cid_x0 + 0xcaae]()
    //     0xcd5c60: mov             x17, #0xcaae
    //     0xcd5c64: add             lr, x0, x17
    //     0xcd5c68: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5c6c: blr             lr
    // 0xcd5c70: add             SP, SP, #8
    // 0xcd5c74: LeaveFrame
    //     0xcd5c74: mov             SP, fp
    //     0xcd5c78: ldp             fp, lr, [SP], #0x10
    // 0xcd5c7c: ret
    //     0xcd5c7c: ret             
    // 0xcd5c80: ldr             x1, [fp, #0x20]
    // 0xcd5c84: ldr             x3, [fp, #0x18]
    // 0xcd5c88: ldur            x2, [fp, #-0x10]
    // 0xcd5c8c: LoadField: r4 = r2->field_f
    //     0xcd5c8c: ldur            w4, [x2, #0xf]
    // 0xcd5c90: DecompressPointer r4
    //     0xcd5c90: add             x4, x4, HEAP, lsl #32
    // 0xcd5c94: stur            x4, [fp, #-8]
    // 0xcd5c98: r0 = LoadClassIdInstr(r3)
    //     0xcd5c98: ldur            x0, [x3, #-1]
    //     0xcd5c9c: ubfx            x0, x0, #0xc, #0x14
    // 0xcd5ca0: SaveReg r3
    //     0xcd5ca0: str             x3, [SP, #-8]!
    // 0xcd5ca4: r0 = GDT[cid_x0 + 0xfe03]()
    //     0xcd5ca4: mov             x17, #0xfe03
    //     0xcd5ca8: add             lr, x0, x17
    //     0xcd5cac: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5cb0: blr             lr
    // 0xcd5cb4: add             SP, SP, #8
    // 0xcd5cb8: mov             x1, x0
    // 0xcd5cbc: ldur            x0, [fp, #-8]
    // 0xcd5cc0: cmp             w0, NULL
    // 0xcd5cc4: b.eq            #0xcd5f0c
    // 0xcd5cc8: LoadField: d0 = r1->field_7
    //     0xcd5cc8: ldur            d0, [x1, #7]
    // 0xcd5ccc: LoadField: d1 = r0->field_7
    //     0xcd5ccc: ldur            d1, [x0, #7]
    // 0xcd5cd0: fcmp            d1, d0
    // 0xcd5cd4: b.vs            #0xcd5d10
    // 0xcd5cd8: b.lt            #0xcd5d10
    // 0xcd5cdc: ldr             x0, [fp, #0x20]
    // 0xcd5ce0: r1 = LoadClassIdInstr(r0)
    //     0xcd5ce0: ldur            x1, [x0, #-1]
    //     0xcd5ce4: ubfx            x1, x1, #0xc, #0x14
    // 0xcd5ce8: SaveReg r0
    //     0xcd5ce8: str             x0, [SP, #-8]!
    // 0xcd5cec: mov             x0, x1
    // 0xcd5cf0: r0 = GDT[cid_x0 + 0xfe03]()
    //     0xcd5cf0: mov             x17, #0xfe03
    //     0xcd5cf4: add             lr, x0, x17
    //     0xcd5cf8: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5cfc: blr             lr
    // 0xcd5d00: add             SP, SP, #8
    // 0xcd5d04: LeaveFrame
    //     0xcd5d04: mov             SP, fp
    //     0xcd5d08: ldp             fp, lr, [SP], #0x10
    // 0xcd5d0c: ret
    //     0xcd5d0c: ret             
    // 0xcd5d10: ldr             x0, [fp, #0x20]
    // 0xcd5d14: ldr             x4, [fp, #0x18]
    // 0xcd5d18: ldur            x3, [fp, #-0x10]
    // 0xcd5d1c: mov             x2, x3
    // 0xcd5d20: r1 = Function '<anonymous closure>': static.
    //     0xcd5d20: add             x1, PP, #0x37, lsl #12  ; [pp+0x37220] AnonymousClosure: static (0xcd6050), in [package:flutter/src/painting/gradient.dart] ::_sample (0xcd5bb8)
    //     0xcd5d24: ldr             x1, [x1, #0x220]
    // 0xcd5d28: r0 = AllocateClosure()
    //     0xcd5d28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd5d2c: ldr             x16, [fp, #0x18]
    // 0xcd5d30: stp             x0, x16, [SP, #-0x10]!
    // 0xcd5d34: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xcd5d34: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xcd5d38: r0 = lastIndexWhere()
    //     0xcd5d38: bl              #0xcd5f28  ; [dart:collection] _ListBase&Object&ListMixin::lastIndexWhere
    // 0xcd5d3c: add             SP, SP, #0x10
    // 0xcd5d40: mov             x2, x0
    // 0xcd5d44: stur            x2, [fp, #-0x18]
    // 0xcd5d48: r0 = BoxInt64Instr(r2)
    //     0xcd5d48: sbfiz           x0, x2, #1, #0x1f
    //     0xcd5d4c: cmp             x2, x0, asr #1
    //     0xcd5d50: b.eq            #0xcd5d5c
    //     0xcd5d54: bl              #0xd69bb8
    //     0xcd5d58: stur            x2, [x0, #7]
    // 0xcd5d5c: mov             x3, x0
    // 0xcd5d60: ldr             x1, [fp, #0x20]
    // 0xcd5d64: stur            x3, [fp, #-8]
    // 0xcd5d68: r0 = LoadClassIdInstr(r1)
    //     0xcd5d68: ldur            x0, [x1, #-1]
    //     0xcd5d6c: ubfx            x0, x0, #0xc, #0x14
    // 0xcd5d70: stp             x3, x1, [SP, #-0x10]!
    // 0xcd5d74: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd5d74: sub             lr, x0, #0xd83
    //     0xcd5d78: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5d7c: blr             lr
    // 0xcd5d80: add             SP, SP, #0x10
    // 0xcd5d84: mov             x2, x0
    // 0xcd5d88: ldur            x0, [fp, #-0x18]
    // 0xcd5d8c: stur            x2, [fp, #-0x28]
    // 0xcd5d90: add             x3, x0, #1
    // 0xcd5d94: r0 = BoxInt64Instr(r3)
    //     0xcd5d94: sbfiz           x0, x3, #1, #0x1f
    //     0xcd5d98: cmp             x3, x0, asr #1
    //     0xcd5d9c: b.eq            #0xcd5da8
    //     0xcd5da0: bl              #0xd69bb8
    //     0xcd5da4: stur            x3, [x0, #7]
    // 0xcd5da8: mov             x1, x0
    // 0xcd5dac: ldr             x0, [fp, #0x20]
    // 0xcd5db0: stur            x1, [fp, #-0x20]
    // 0xcd5db4: r3 = LoadClassIdInstr(r0)
    //     0xcd5db4: ldur            x3, [x0, #-1]
    //     0xcd5db8: ubfx            x3, x3, #0xc, #0x14
    // 0xcd5dbc: stp             x1, x0, [SP, #-0x10]!
    // 0xcd5dc0: mov             x0, x3
    // 0xcd5dc4: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd5dc4: sub             lr, x0, #0xd83
    //     0xcd5dc8: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5dcc: blr             lr
    // 0xcd5dd0: add             SP, SP, #0x10
    // 0xcd5dd4: mov             x1, x0
    // 0xcd5dd8: ldur            x0, [fp, #-0x10]
    // 0xcd5ddc: stur            x1, [fp, #-0x38]
    // 0xcd5de0: LoadField: r2 = r0->field_f
    //     0xcd5de0: ldur            w2, [x0, #0xf]
    // 0xcd5de4: DecompressPointer r2
    //     0xcd5de4: add             x2, x2, HEAP, lsl #32
    // 0xcd5de8: ldr             x3, [fp, #0x18]
    // 0xcd5dec: stur            x2, [fp, #-0x30]
    // 0xcd5df0: r0 = LoadClassIdInstr(r3)
    //     0xcd5df0: ldur            x0, [x3, #-1]
    //     0xcd5df4: ubfx            x0, x0, #0xc, #0x14
    // 0xcd5df8: ldur            x16, [fp, #-8]
    // 0xcd5dfc: stp             x16, x3, [SP, #-0x10]!
    // 0xcd5e00: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd5e00: sub             lr, x0, #0xd83
    //     0xcd5e04: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5e08: blr             lr
    // 0xcd5e0c: add             SP, SP, #0x10
    // 0xcd5e10: mov             x1, x0
    // 0xcd5e14: ldur            x0, [fp, #-0x30]
    // 0xcd5e18: cmp             w0, NULL
    // 0xcd5e1c: b.eq            #0xcd5f10
    // 0xcd5e20: LoadField: d0 = r1->field_7
    //     0xcd5e20: ldur            d0, [x1, #7]
    // 0xcd5e24: LoadField: d1 = r0->field_7
    //     0xcd5e24: ldur            d1, [x0, #7]
    // 0xcd5e28: fsub            d2, d1, d0
    // 0xcd5e2c: ldr             x1, [fp, #0x18]
    // 0xcd5e30: stur            d2, [fp, #-0x40]
    // 0xcd5e34: r0 = LoadClassIdInstr(r1)
    //     0xcd5e34: ldur            x0, [x1, #-1]
    //     0xcd5e38: ubfx            x0, x0, #0xc, #0x14
    // 0xcd5e3c: ldur            x16, [fp, #-0x20]
    // 0xcd5e40: stp             x16, x1, [SP, #-0x10]!
    // 0xcd5e44: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd5e44: sub             lr, x0, #0xd83
    //     0xcd5e48: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5e4c: blr             lr
    // 0xcd5e50: add             SP, SP, #0x10
    // 0xcd5e54: mov             x1, x0
    // 0xcd5e58: ldr             x0, [fp, #0x18]
    // 0xcd5e5c: stur            x1, [fp, #-0x10]
    // 0xcd5e60: r2 = LoadClassIdInstr(r0)
    //     0xcd5e60: ldur            x2, [x0, #-1]
    //     0xcd5e64: ubfx            x2, x2, #0xc, #0x14
    // 0xcd5e68: ldur            x16, [fp, #-8]
    // 0xcd5e6c: stp             x16, x0, [SP, #-0x10]!
    // 0xcd5e70: mov             x0, x2
    // 0xcd5e74: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd5e74: sub             lr, x0, #0xd83
    //     0xcd5e78: ldr             lr, [x21, lr, lsl #3]
    //     0xcd5e7c: blr             lr
    // 0xcd5e80: add             SP, SP, #0x10
    // 0xcd5e84: mov             x1, x0
    // 0xcd5e88: ldur            x0, [fp, #-0x10]
    // 0xcd5e8c: LoadField: d0 = r0->field_7
    //     0xcd5e8c: ldur            d0, [x0, #7]
    // 0xcd5e90: LoadField: d1 = r1->field_7
    //     0xcd5e90: ldur            d1, [x1, #7]
    // 0xcd5e94: fsub            d2, d0, d1
    // 0xcd5e98: ldur            d0, [fp, #-0x40]
    // 0xcd5e9c: fdiv            d1, d0, d2
    // 0xcd5ea0: r0 = inline_Allocate_Double()
    //     0xcd5ea0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd5ea4: add             x0, x0, #0x10
    //     0xcd5ea8: cmp             x1, x0
    //     0xcd5eac: b.ls            #0xcd5f14
    //     0xcd5eb0: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd5eb4: sub             x0, x0, #0xf
    //     0xcd5eb8: mov             x1, #0xd108
    //     0xcd5ebc: movk            x1, #3, lsl #16
    //     0xcd5ec0: stur            x1, [x0, #-1]
    // 0xcd5ec4: StoreField: r0->field_7 = d1
    //     0xcd5ec4: stur            d1, [x0, #7]
    // 0xcd5ec8: ldur            x16, [fp, #-0x28]
    // 0xcd5ecc: ldur            lr, [fp, #-0x38]
    // 0xcd5ed0: stp             lr, x16, [SP, #-0x10]!
    // 0xcd5ed4: SaveReg r0
    //     0xcd5ed4: str             x0, [SP, #-8]!
    // 0xcd5ed8: r0 = lerp()
    //     0xcd5ed8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd5edc: add             SP, SP, #0x18
    // 0xcd5ee0: cmp             w0, NULL
    // 0xcd5ee4: b.eq            #0xcd5f24
    // 0xcd5ee8: LeaveFrame
    //     0xcd5ee8: mov             SP, fp
    //     0xcd5eec: ldp             fp, lr, [SP], #0x10
    // 0xcd5ef0: ret
    //     0xcd5ef0: ret             
    // 0xcd5ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd5ef4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd5ef8: b               #0xcd5bd0
    // 0xcd5efc: SaveReg d0
    //     0xcd5efc: str             q0, [SP, #-0x10]!
    // 0xcd5f00: r0 = AllocateDouble()
    //     0xcd5f00: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd5f04: RestoreReg d0
    //     0xcd5f04: ldr             q0, [SP], #0x10
    // 0xcd5f08: b               #0xcd5bf8
    // 0xcd5f0c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcd5f0c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xcd5f10: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcd5f10: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xcd5f14: SaveReg d1
    //     0xcd5f14: str             q1, [SP, #-0x10]!
    // 0xcd5f18: r0 = AllocateDouble()
    //     0xcd5f18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd5f1c: RestoreReg d1
    //     0xcd5f1c: ldr             q1, [SP], #0x10
    // 0xcd5f20: b               #0xcd5ec4
    // 0xcd5f24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd5f24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static bool <anonymous closure>(dynamic, double) {
    // ** addr: 0xcd6050, size: 0x58
    // 0xcd6050: EnterFrame
    //     0xcd6050: stp             fp, lr, [SP, #-0x10]!
    //     0xcd6054: mov             fp, SP
    // 0xcd6058: ldr             x1, [fp, #0x18]
    // 0xcd605c: LoadField: r2 = r1->field_17
    //     0xcd605c: ldur            w2, [x1, #0x17]
    // 0xcd6060: DecompressPointer r2
    //     0xcd6060: add             x2, x2, HEAP, lsl #32
    // 0xcd6064: LoadField: r1 = r2->field_f
    //     0xcd6064: ldur            w1, [x2, #0xf]
    // 0xcd6068: DecompressPointer r1
    //     0xcd6068: add             x1, x1, HEAP, lsl #32
    // 0xcd606c: cmp             w1, NULL
    // 0xcd6070: b.eq            #0xcd60a4
    // 0xcd6074: ldr             x2, [fp, #0x10]
    // 0xcd6078: LoadField: d0 = r2->field_7
    //     0xcd6078: ldur            d0, [x2, #7]
    // 0xcd607c: LoadField: d1 = r1->field_7
    //     0xcd607c: ldur            d1, [x1, #7]
    // 0xcd6080: fcmp            d0, d1
    // 0xcd6084: b.vs            #0xcd608c
    // 0xcd6088: b.le            #0xcd6094
    // 0xcd608c: r0 = false
    //     0xcd608c: add             x0, NULL, #0x30  ; false
    // 0xcd6090: b               #0xcd6098
    // 0xcd6094: r0 = true
    //     0xcd6094: add             x0, NULL, #0x20  ; true
    // 0xcd6098: LeaveFrame
    //     0xcd6098: mov             SP, fp
    //     0xcd609c: ldp             fp, lr, [SP], #0x10
    // 0xcd60a0: ret
    //     0xcd60a0: ret             
    // 0xcd60a4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcd60a4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2095, size: 0x14, field offset: 0x8
//   const constructor, 
abstract class Gradient extends Object {

  _ _impliedStops(/* No info */) {
    // ** addr: 0xa752a8, size: 0x188
    // 0xa752a8: EnterFrame
    //     0xa752a8: stp             fp, lr, [SP, #-0x10]!
    //     0xa752ac: mov             fp, SP
    // 0xa752b0: AllocStack(0x10)
    //     0xa752b0: sub             SP, SP, #0x10
    // 0xa752b4: CheckStackOverflow
    //     0xa752b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa752b8: cmp             SP, x16
    //     0xa752bc: b.ls            #0xa75400
    // 0xa752c0: ldr             x0, [fp, #0x10]
    // 0xa752c4: LoadField: r1 = r0->field_b
    //     0xa752c4: ldur            w1, [x0, #0xb]
    // 0xa752c8: DecompressPointer r1
    //     0xa752c8: add             x1, x1, HEAP, lsl #32
    // 0xa752cc: cmp             w1, NULL
    // 0xa752d0: b.eq            #0xa752e4
    // 0xa752d4: mov             x0, x1
    // 0xa752d8: LeaveFrame
    //     0xa752d8: mov             SP, fp
    //     0xa752dc: ldp             fp, lr, [SP], #0x10
    // 0xa752e0: ret
    //     0xa752e0: ret             
    // 0xa752e4: LoadField: r1 = r0->field_7
    //     0xa752e4: ldur            w1, [x0, #7]
    // 0xa752e8: DecompressPointer r1
    //     0xa752e8: add             x1, x1, HEAP, lsl #32
    // 0xa752ec: stur            x1, [fp, #-8]
    // 0xa752f0: r0 = LoadClassIdInstr(r1)
    //     0xa752f0: ldur            x0, [x1, #-1]
    //     0xa752f4: ubfx            x0, x0, #0xc, #0x14
    // 0xa752f8: SaveReg r1
    //     0xa752f8: str             x1, [SP, #-8]!
    // 0xa752fc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa752fc: mov             x17, #0xb8ea
    //     0xa75300: add             lr, x0, x17
    //     0xa75304: ldr             lr, [x21, lr, lsl #3]
    //     0xa75308: blr             lr
    // 0xa7530c: add             SP, SP, #8
    // 0xa75310: r1 = LoadInt32Instr(r0)
    //     0xa75310: sbfx            x1, x0, #1, #0x1f
    // 0xa75314: sub             x0, x1, #1
    // 0xa75318: scvtf           d0, x0
    // 0xa7531c: d1 = 1.000000
    //     0xa7531c: fmov            d1, #1.00000000
    // 0xa75320: fdiv            d2, d1, d0
    // 0xa75324: ldur            x0, [fp, #-8]
    // 0xa75328: stur            d2, [fp, #-0x10]
    // 0xa7532c: r1 = LoadClassIdInstr(r0)
    //     0xa7532c: ldur            x1, [x0, #-1]
    //     0xa75330: ubfx            x1, x1, #0xc, #0x14
    // 0xa75334: SaveReg r0
    //     0xa75334: str             x0, [SP, #-8]!
    // 0xa75338: mov             x0, x1
    // 0xa7533c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa7533c: mov             x17, #0xb8ea
    //     0xa75340: add             lr, x0, x17
    //     0xa75344: ldr             lr, [x21, lr, lsl #3]
    //     0xa75348: blr             lr
    // 0xa7534c: add             SP, SP, #8
    // 0xa75350: mov             x2, x0
    // 0xa75354: r1 = <double>
    //     0xa75354: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa75358: stur            x0, [fp, #-8]
    // 0xa7535c: r0 = AllocateArray()
    //     0xa7535c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa75360: mov             x3, x0
    // 0xa75364: ldur            x2, [fp, #-8]
    // 0xa75368: r4 = LoadInt32Instr(r2)
    //     0xa75368: sbfx            x4, x2, #1, #0x1f
    // 0xa7536c: ldur            d0, [fp, #-0x10]
    // 0xa75370: r2 = 0
    //     0xa75370: mov             x2, #0
    // 0xa75374: CheckStackOverflow
    //     0xa75374: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa75378: cmp             SP, x16
    //     0xa7537c: b.ls            #0xa75408
    // 0xa75380: cmp             x2, x4
    // 0xa75384: b.ge            #0xa753f0
    // 0xa75388: scvtf           d1, x2
    // 0xa7538c: fmul            d2, d1, d0
    // 0xa75390: r0 = inline_Allocate_Double()
    //     0xa75390: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0xa75394: add             x0, x0, #0x10
    //     0xa75398: cmp             x5, x0
    //     0xa7539c: b.ls            #0xa75410
    //     0xa753a0: str             x0, [THR, #0x60]  ; THR::top
    //     0xa753a4: sub             x0, x0, #0xf
    //     0xa753a8: mov             x5, #0xd108
    //     0xa753ac: movk            x5, #3, lsl #16
    //     0xa753b0: stur            x5, [x0, #-1]
    // 0xa753b4: StoreField: r0->field_7 = d2
    //     0xa753b4: stur            d2, [x0, #7]
    // 0xa753b8: mov             x1, x3
    // 0xa753bc: ArrayStore: r1[r2] = r0  ; List_4
    //     0xa753bc: add             x25, x1, x2, lsl #2
    //     0xa753c0: add             x25, x25, #0xf
    //     0xa753c4: str             w0, [x25]
    //     0xa753c8: tbz             w0, #0, #0xa753e4
    //     0xa753cc: ldurb           w16, [x1, #-1]
    //     0xa753d0: ldurb           w17, [x0, #-1]
    //     0xa753d4: and             x16, x17, x16, lsr #2
    //     0xa753d8: tst             x16, HEAP, lsr #32
    //     0xa753dc: b.eq            #0xa753e4
    //     0xa753e0: bl              #0xd67e5c
    // 0xa753e4: add             x0, x2, #1
    // 0xa753e8: mov             x2, x0
    // 0xa753ec: b               #0xa75374
    // 0xa753f0: mov             x0, x3
    // 0xa753f4: LeaveFrame
    //     0xa753f4: mov             SP, fp
    //     0xa753f8: ldp             fp, lr, [SP], #0x10
    // 0xa753fc: ret
    //     0xa753fc: ret             
    // 0xa75400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa75400: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa75404: b               #0xa752c0
    // 0xa75408: r0 = StackOverflowSharedWithFPURegs()
    //     0xa75408: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa7540c: b               #0xa75380
    // 0xa75410: stp             q0, q2, [SP, #-0x20]!
    // 0xa75414: stp             x3, x4, [SP, #-0x10]!
    // 0xa75418: SaveReg r2
    //     0xa75418: str             x2, [SP, #-8]!
    // 0xa7541c: r0 = AllocateDouble()
    //     0xa7541c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa75420: RestoreReg r2
    //     0xa75420: ldr             x2, [SP], #8
    // 0xa75424: ldp             x3, x4, [SP], #0x10
    // 0xa75428: ldp             q0, q2, [SP], #0x20
    // 0xa7542c: b               #0xa753b4
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xcd5618, size: 0x12c
    // 0xcd5618: EnterFrame
    //     0xcd5618: stp             fp, lr, [SP, #-0x10]!
    //     0xcd561c: mov             fp, SP
    // 0xcd5620: CheckStackOverflow
    //     0xcd5620: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd5624: cmp             SP, x16
    //     0xcd5628: b.ls            #0xcd5734
    // 0xcd562c: ldr             x0, [fp, #0x18]
    // 0xcd5630: cmp             w0, NULL
    // 0xcd5634: b.eq            #0xcd5654
    // 0xcd5638: ldr             d0, [fp, #0x10]
    // 0xcd563c: ldr             x16, [fp, #0x20]
    // 0xcd5640: stp             x16, x0, [SP, #-0x10]!
    // 0xcd5644: SaveReg d0
    //     0xcd5644: str             d0, [SP, #-8]!
    // 0xcd5648: r0 = lerpFrom()
    //     0xcd5648: bl              #0xcd60a8  ; [package:flutter/src/painting/gradient.dart] LinearGradient::lerpFrom
    // 0xcd564c: add             SP, SP, #0x18
    // 0xcd5650: b               #0xcd5658
    // 0xcd5654: r0 = Null
    //     0xcd5654: mov             x0, NULL
    // 0xcd5658: cmp             w0, NULL
    // 0xcd565c: b.ne            #0xcd5684
    // 0xcd5660: ldr             x1, [fp, #0x20]
    // 0xcd5664: cmp             w1, NULL
    // 0xcd5668: b.eq            #0xcd5684
    // 0xcd566c: ldr             d0, [fp, #0x10]
    // 0xcd5670: ldr             x16, [fp, #0x18]
    // 0xcd5674: stp             x16, x1, [SP, #-0x10]!
    // 0xcd5678: SaveReg d0
    //     0xcd5678: str             d0, [SP, #-8]!
    // 0xcd567c: r0 = lerpTo()
    //     0xcd567c: bl              #0xcd5744  ; [package:flutter/src/painting/gradient.dart] LinearGradient::lerpTo
    // 0xcd5680: add             SP, SP, #0x18
    // 0xcd5684: cmp             w0, NULL
    // 0xcd5688: b.eq            #0xcd5698
    // 0xcd568c: LeaveFrame
    //     0xcd568c: mov             SP, fp
    //     0xcd5690: ldp             fp, lr, [SP], #0x10
    // 0xcd5694: ret
    //     0xcd5694: ret             
    // 0xcd5698: ldr             x0, [fp, #0x20]
    // 0xcd569c: cmp             w0, NULL
    // 0xcd56a0: b.ne            #0xcd56c0
    // 0xcd56a4: ldr             x1, [fp, #0x18]
    // 0xcd56a8: cmp             w1, NULL
    // 0xcd56ac: b.ne            #0xcd56c4
    // 0xcd56b0: r0 = Null
    //     0xcd56b0: mov             x0, NULL
    // 0xcd56b4: LeaveFrame
    //     0xcd56b4: mov             SP, fp
    //     0xcd56b8: ldp             fp, lr, [SP], #0x10
    // 0xcd56bc: ret
    //     0xcd56bc: ret             
    // 0xcd56c0: ldr             x1, [fp, #0x18]
    // 0xcd56c4: ldr             d0, [fp, #0x10]
    // 0xcd56c8: d1 = 0.500000
    //     0xcd56c8: fmov            d1, #0.50000000
    // 0xcd56cc: fcmp            d0, d1
    // 0xcd56d0: b.vs            #0xcd5704
    // 0xcd56d4: b.ge            #0xcd5704
    // 0xcd56d8: d2 = 2.000000
    //     0xcd56d8: fmov            d2, #2.00000000
    // 0xcd56dc: d1 = 1.000000
    //     0xcd56dc: fmov            d1, #1.00000000
    // 0xcd56e0: cmp             w0, NULL
    // 0xcd56e4: b.eq            #0xcd573c
    // 0xcd56e8: fmul            d3, d0, d2
    // 0xcd56ec: fsub            d0, d1, d3
    // 0xcd56f0: SaveReg r0
    //     0xcd56f0: str             x0, [SP, #-8]!
    // 0xcd56f4: SaveReg d0
    //     0xcd56f4: str             d0, [SP, #-8]!
    // 0xcd56f8: r0 = scale()
    //     0xcd56f8: bl              #0xcd50a8  ; [package:flutter/src/painting/gradient.dart] LinearGradient::scale
    // 0xcd56fc: add             SP, SP, #0x10
    // 0xcd5700: b               #0xcd5728
    // 0xcd5704: d2 = 2.000000
    //     0xcd5704: fmov            d2, #2.00000000
    // 0xcd5708: cmp             w1, NULL
    // 0xcd570c: b.eq            #0xcd5740
    // 0xcd5710: fsub            d3, d0, d1
    // 0xcd5714: fmul            d0, d3, d2
    // 0xcd5718: SaveReg r1
    //     0xcd5718: str             x1, [SP, #-8]!
    // 0xcd571c: SaveReg d0
    //     0xcd571c: str             d0, [SP, #-8]!
    // 0xcd5720: r0 = scale()
    //     0xcd5720: bl              #0xcd50a8  ; [package:flutter/src/painting/gradient.dart] LinearGradient::scale
    // 0xcd5724: add             SP, SP, #0x10
    // 0xcd5728: LeaveFrame
    //     0xcd5728: mov             SP, fp
    //     0xcd572c: ldp             fp, lr, [SP], #0x10
    // 0xcd5730: ret
    //     0xcd5730: ret             
    // 0xcd5734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd5734: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd5738: b               #0xcd562c
    // 0xcd573c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd573c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd5740: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd5740: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 2096, size: 0x2c, field offset: 0x14
//   const constructor, 
class SweepGradient extends Gradient {

  _ createShader(/* No info */) {
    // ** addr: 0xa74ccc, size: 0xb4
    // 0xa74ccc: EnterFrame
    //     0xa74ccc: stp             fp, lr, [SP, #-0x10]!
    //     0xa74cd0: mov             fp, SP
    // 0xa74cd4: AllocStack(0x20)
    //     0xa74cd4: sub             SP, SP, #0x20
    // 0xa74cd8: SetupParameters(SweepGradient this /* r1, fp-0x8 */, dynamic _ /* r2 */)
    //     0xa74cd8: mov             x0, x4
    //     0xa74cdc: ldur            w1, [x0, #0x13]
    //     0xa74ce0: add             x1, x1, HEAP, lsl #32
    //     0xa74ce4: sub             x0, x1, #4
    //     0xa74ce8: add             x1, fp, w0, sxtw #2
    //     0xa74cec: ldr             x1, [x1, #0x18]
    //     0xa74cf0: stur            x1, [fp, #-8]
    //     0xa74cf4: add             x2, fp, w0, sxtw #2
    //     0xa74cf8: ldr             x2, [x2, #0x10]
    // 0xa74cfc: CheckStackOverflow
    //     0xa74cfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa74d00: cmp             SP, x16
    //     0xa74d04: b.ls            #0xa74d78
    // 0xa74d08: r16 = Instance_Alignment
    //     0xa74d08: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xa74d0c: ldr             x16, [x16, #0xc70]
    // 0xa74d10: stp             x2, x16, [SP, #-0x10]!
    // 0xa74d14: r0 = withinRect()
    //     0xa74d14: bl              #0xa75430  ; [package:flutter/src/painting/alignment.dart] Alignment::withinRect
    // 0xa74d18: add             SP, SP, #0x10
    // 0xa74d1c: mov             x1, x0
    // 0xa74d20: ldur            x0, [fp, #-8]
    // 0xa74d24: stur            x1, [fp, #-0x18]
    // 0xa74d28: LoadField: r2 = r0->field_7
    //     0xa74d28: ldur            w2, [x0, #7]
    // 0xa74d2c: DecompressPointer r2
    //     0xa74d2c: add             x2, x2, HEAP, lsl #32
    // 0xa74d30: stur            x2, [fp, #-0x10]
    // 0xa74d34: SaveReg r0
    //     0xa74d34: str             x0, [SP, #-8]!
    // 0xa74d38: r0 = _impliedStops()
    //     0xa74d38: bl              #0xa752a8  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0xa74d3c: add             SP, SP, #8
    // 0xa74d40: stur            x0, [fp, #-8]
    // 0xa74d44: r0 = Gradient()
    //     0xa74d44: bl              #0x68dbb8  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0xa74d48: stur            x0, [fp, #-0x20]
    // 0xa74d4c: ldur            x16, [fp, #-0x18]
    // 0xa74d50: stp             x16, x0, [SP, #-0x10]!
    // 0xa74d54: ldur            x16, [fp, #-0x10]
    // 0xa74d58: ldur            lr, [fp, #-8]
    // 0xa74d5c: stp             lr, x16, [SP, #-0x10]!
    // 0xa74d60: r0 = Gradient.sweep()
    //     0xa74d60: bl              #0xa74d80  ; [dart:ui] Gradient::Gradient.sweep
    // 0xa74d64: add             SP, SP, #0x20
    // 0xa74d68: ldur            x0, [fp, #-0x20]
    // 0xa74d6c: LeaveFrame
    //     0xa74d6c: mov             SP, fp
    //     0xa74d70: ldp             fp, lr, [SP], #0x10
    // 0xa74d74: ret
    //     0xa74d74: ret             
    // 0xa74d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa74d78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa74d7c: b               #0xa74d08
  }
  _ toString(/* No info */) {
    // ** addr: 0xae25c4, size: 0x3ec
    // 0xae25c4: EnterFrame
    //     0xae25c4: stp             fp, lr, [SP, #-0x10]!
    //     0xae25c8: mov             fp, SP
    // 0xae25cc: AllocStack(0x28)
    //     0xae25cc: sub             SP, SP, #0x28
    // 0xae25d0: CheckStackOverflow
    //     0xae25d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae25d4: cmp             SP, x16
    //     0xae25d8: b.ls            #0xae29a0
    // 0xae25dc: r1 = Null
    //     0xae25dc: mov             x1, NULL
    // 0xae25e0: r2 = 4
    //     0xae25e0: mov             x2, #4
    // 0xae25e4: r0 = AllocateArray()
    //     0xae25e4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae25e8: r17 = "center: "
    //     0xae25e8: add             x17, PP, #0x57, lsl #12  ; [pp+0x574e0] "center: "
    //     0xae25ec: ldr             x17, [x17, #0x4e0]
    // 0xae25f0: StoreField: r0->field_f = r17
    //     0xae25f0: stur            w17, [x0, #0xf]
    // 0xae25f4: ldr             x1, [fp, #0x10]
    // 0xae25f8: LoadField: r2 = r1->field_13
    //     0xae25f8: ldur            w2, [x1, #0x13]
    // 0xae25fc: DecompressPointer r2
    //     0xae25fc: add             x2, x2, HEAP, lsl #32
    // 0xae2600: StoreField: r0->field_13 = r2
    //     0xae2600: stur            w2, [x0, #0x13]
    // 0xae2604: SaveReg r0
    //     0xae2604: str             x0, [SP, #-8]!
    // 0xae2608: r0 = _interpolate()
    //     0xae2608: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae260c: add             SP, SP, #8
    // 0xae2610: r1 = Null
    //     0xae2610: mov             x1, NULL
    // 0xae2614: r2 = 4
    //     0xae2614: mov             x2, #4
    // 0xae2618: stur            x0, [fp, #-8]
    // 0xae261c: r0 = AllocateArray()
    //     0xae261c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2620: stur            x0, [fp, #-0x10]
    // 0xae2624: r17 = "startAngle: "
    //     0xae2624: add             x17, PP, #0x57, lsl #12  ; [pp+0x574e8] "startAngle: "
    //     0xae2628: ldr             x17, [x17, #0x4e8]
    // 0xae262c: StoreField: r0->field_f = r17
    //     0xae262c: stur            w17, [x0, #0xf]
    // 0xae2630: r16 = 0.000000
    //     0xae2630: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xae2634: SaveReg r16
    //     0xae2634: str             x16, [SP, #-8]!
    // 0xae2638: r0 = debugFormatDouble()
    //     0xae2638: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae263c: add             SP, SP, #8
    // 0xae2640: ldur            x1, [fp, #-0x10]
    // 0xae2644: ArrayStore: r1[1] = r0  ; List_4
    //     0xae2644: add             x25, x1, #0x13
    //     0xae2648: str             w0, [x25]
    //     0xae264c: tbz             w0, #0, #0xae2668
    //     0xae2650: ldurb           w16, [x1, #-1]
    //     0xae2654: ldurb           w17, [x0, #-1]
    //     0xae2658: and             x16, x17, x16, lsr #2
    //     0xae265c: tst             x16, HEAP, lsr #32
    //     0xae2660: b.eq            #0xae2668
    //     0xae2664: bl              #0xd67e5c
    // 0xae2668: ldur            x16, [fp, #-0x10]
    // 0xae266c: SaveReg r16
    //     0xae266c: str             x16, [SP, #-8]!
    // 0xae2670: r0 = _interpolate()
    //     0xae2670: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2674: add             SP, SP, #8
    // 0xae2678: r1 = Null
    //     0xae2678: mov             x1, NULL
    // 0xae267c: r2 = 4
    //     0xae267c: mov             x2, #4
    // 0xae2680: stur            x0, [fp, #-0x10]
    // 0xae2684: r0 = AllocateArray()
    //     0xae2684: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2688: stur            x0, [fp, #-0x18]
    // 0xae268c: r17 = "endAngle: "
    //     0xae268c: add             x17, PP, #0x57, lsl #12  ; [pp+0x574f0] "endAngle: "
    //     0xae2690: ldr             x17, [x17, #0x4f0]
    // 0xae2694: StoreField: r0->field_f = r17
    //     0xae2694: stur            w17, [x0, #0xf]
    // 0xae2698: r16 = 6.283185
    //     0xae2698: add             x16, PP, #0x52, lsl #12  ; [pp+0x52090] 6.283185307179586
    //     0xae269c: ldr             x16, [x16, #0x90]
    // 0xae26a0: SaveReg r16
    //     0xae26a0: str             x16, [SP, #-8]!
    // 0xae26a4: r0 = debugFormatDouble()
    //     0xae26a4: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae26a8: add             SP, SP, #8
    // 0xae26ac: ldur            x1, [fp, #-0x18]
    // 0xae26b0: ArrayStore: r1[1] = r0  ; List_4
    //     0xae26b0: add             x25, x1, #0x13
    //     0xae26b4: str             w0, [x25]
    //     0xae26b8: tbz             w0, #0, #0xae26d4
    //     0xae26bc: ldurb           w16, [x1, #-1]
    //     0xae26c0: ldurb           w17, [x0, #-1]
    //     0xae26c4: and             x16, x17, x16, lsr #2
    //     0xae26c8: tst             x16, HEAP, lsr #32
    //     0xae26cc: b.eq            #0xae26d4
    //     0xae26d0: bl              #0xd67e5c
    // 0xae26d4: ldur            x16, [fp, #-0x18]
    // 0xae26d8: SaveReg r16
    //     0xae26d8: str             x16, [SP, #-8]!
    // 0xae26dc: r0 = _interpolate()
    //     0xae26dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae26e0: add             SP, SP, #8
    // 0xae26e4: r1 = Null
    //     0xae26e4: mov             x1, NULL
    // 0xae26e8: r2 = 4
    //     0xae26e8: mov             x2, #4
    // 0xae26ec: stur            x0, [fp, #-0x18]
    // 0xae26f0: r0 = AllocateArray()
    //     0xae26f0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae26f4: r17 = "colors: "
    //     0xae26f4: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da70] "colors: "
    //     0xae26f8: ldr             x17, [x17, #0xa70]
    // 0xae26fc: StoreField: r0->field_f = r17
    //     0xae26fc: stur            w17, [x0, #0xf]
    // 0xae2700: ldr             x1, [fp, #0x10]
    // 0xae2704: LoadField: r2 = r1->field_7
    //     0xae2704: ldur            w2, [x1, #7]
    // 0xae2708: DecompressPointer r2
    //     0xae2708: add             x2, x2, HEAP, lsl #32
    // 0xae270c: StoreField: r0->field_13 = r2
    //     0xae270c: stur            w2, [x0, #0x13]
    // 0xae2710: SaveReg r0
    //     0xae2710: str             x0, [SP, #-8]!
    // 0xae2714: r0 = _interpolate()
    //     0xae2714: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2718: add             SP, SP, #8
    // 0xae271c: r1 = Null
    //     0xae271c: mov             x1, NULL
    // 0xae2720: r2 = 8
    //     0xae2720: mov             x2, #8
    // 0xae2724: stur            x0, [fp, #-0x20]
    // 0xae2728: r0 = AllocateArray()
    //     0xae2728: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae272c: mov             x2, x0
    // 0xae2730: ldur            x0, [fp, #-8]
    // 0xae2734: stur            x2, [fp, #-0x28]
    // 0xae2738: StoreField: r2->field_f = r0
    //     0xae2738: stur            w0, [x2, #0xf]
    // 0xae273c: ldur            x0, [fp, #-0x10]
    // 0xae2740: StoreField: r2->field_13 = r0
    //     0xae2740: stur            w0, [x2, #0x13]
    // 0xae2744: ldur            x0, [fp, #-0x18]
    // 0xae2748: StoreField: r2->field_17 = r0
    //     0xae2748: stur            w0, [x2, #0x17]
    // 0xae274c: ldur            x0, [fp, #-0x20]
    // 0xae2750: StoreField: r2->field_1b = r0
    //     0xae2750: stur            w0, [x2, #0x1b]
    // 0xae2754: r1 = <String>
    //     0xae2754: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xae2758: r0 = AllocateGrowableArray()
    //     0xae2758: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xae275c: mov             x3, x0
    // 0xae2760: ldur            x0, [fp, #-0x28]
    // 0xae2764: stur            x3, [fp, #-0x10]
    // 0xae2768: StoreField: r3->field_f = r0
    //     0xae2768: stur            w0, [x3, #0xf]
    // 0xae276c: r0 = 8
    //     0xae276c: mov             x0, #8
    // 0xae2770: StoreField: r3->field_b = r0
    //     0xae2770: stur            w0, [x3, #0xb]
    // 0xae2774: ldr             x4, [fp, #0x10]
    // 0xae2778: LoadField: r5 = r4->field_b
    //     0xae2778: ldur            w5, [x4, #0xb]
    // 0xae277c: DecompressPointer r5
    //     0xae277c: add             x5, x5, HEAP, lsl #32
    // 0xae2780: stur            x5, [fp, #-8]
    // 0xae2784: cmp             w5, NULL
    // 0xae2788: b.eq            #0xae284c
    // 0xae278c: r1 = Null
    //     0xae278c: mov             x1, NULL
    // 0xae2790: r2 = 4
    //     0xae2790: mov             x2, #4
    // 0xae2794: r0 = AllocateArray()
    //     0xae2794: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2798: r17 = "stops: "
    //     0xae2798: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da78] "stops: "
    //     0xae279c: ldr             x17, [x17, #0xa78]
    // 0xae27a0: StoreField: r0->field_f = r17
    //     0xae27a0: stur            w17, [x0, #0xf]
    // 0xae27a4: ldur            x1, [fp, #-8]
    // 0xae27a8: StoreField: r0->field_13 = r1
    //     0xae27a8: stur            w1, [x0, #0x13]
    // 0xae27ac: SaveReg r0
    //     0xae27ac: str             x0, [SP, #-8]!
    // 0xae27b0: r0 = _interpolate()
    //     0xae27b0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae27b4: add             SP, SP, #8
    // 0xae27b8: mov             x1, x0
    // 0xae27bc: ldur            x0, [fp, #-0x10]
    // 0xae27c0: stur            x1, [fp, #-0x18]
    // 0xae27c4: LoadField: r2 = r0->field_b
    //     0xae27c4: ldur            w2, [x0, #0xb]
    // 0xae27c8: DecompressPointer r2
    //     0xae27c8: add             x2, x2, HEAP, lsl #32
    // 0xae27cc: stur            x2, [fp, #-8]
    // 0xae27d0: LoadField: r3 = r0->field_f
    //     0xae27d0: ldur            w3, [x0, #0xf]
    // 0xae27d4: DecompressPointer r3
    //     0xae27d4: add             x3, x3, HEAP, lsl #32
    // 0xae27d8: LoadField: r4 = r3->field_b
    //     0xae27d8: ldur            w4, [x3, #0xb]
    // 0xae27dc: DecompressPointer r4
    //     0xae27dc: add             x4, x4, HEAP, lsl #32
    // 0xae27e0: cmp             w2, w4
    // 0xae27e4: b.ne            #0xae27f4
    // 0xae27e8: SaveReg r0
    //     0xae27e8: str             x0, [SP, #-8]!
    // 0xae27ec: r0 = _growToNextCapacity()
    //     0xae27ec: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae27f0: add             SP, SP, #8
    // 0xae27f4: ldur            x0, [fp, #-8]
    // 0xae27f8: ldur            x3, [fp, #-0x10]
    // 0xae27fc: r2 = LoadInt32Instr(r0)
    //     0xae27fc: sbfx            x2, x0, #1, #0x1f
    // 0xae2800: add             x0, x2, #1
    // 0xae2804: lsl             x1, x0, #1
    // 0xae2808: StoreField: r3->field_b = r1
    //     0xae2808: stur            w1, [x3, #0xb]
    // 0xae280c: mov             x1, x2
    // 0xae2810: cmp             x1, x0
    // 0xae2814: b.hs            #0xae29a8
    // 0xae2818: LoadField: r1 = r3->field_f
    //     0xae2818: ldur            w1, [x3, #0xf]
    // 0xae281c: DecompressPointer r1
    //     0xae281c: add             x1, x1, HEAP, lsl #32
    // 0xae2820: ldur            x0, [fp, #-0x18]
    // 0xae2824: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae2824: add             x25, x1, x2, lsl #2
    //     0xae2828: add             x25, x25, #0xf
    //     0xae282c: str             w0, [x25]
    //     0xae2830: tbz             w0, #0, #0xae284c
    //     0xae2834: ldurb           w16, [x1, #-1]
    //     0xae2838: ldurb           w17, [x0, #-1]
    //     0xae283c: and             x16, x17, x16, lsr #2
    //     0xae2840: tst             x16, HEAP, lsr #32
    //     0xae2844: b.eq            #0xae284c
    //     0xae2848: bl              #0xd67e5c
    // 0xae284c: ldr             x0, [fp, #0x10]
    // 0xae2850: r1 = Null
    //     0xae2850: mov             x1, NULL
    // 0xae2854: r2 = 4
    //     0xae2854: mov             x2, #4
    // 0xae2858: r0 = AllocateArray()
    //     0xae2858: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae285c: r17 = "tileMode: "
    //     0xae285c: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da80] "tileMode: "
    //     0xae2860: ldr             x17, [x17, #0xa80]
    // 0xae2864: StoreField: r0->field_f = r17
    //     0xae2864: stur            w17, [x0, #0xf]
    // 0xae2868: ldr             x1, [fp, #0x10]
    // 0xae286c: LoadField: r2 = r1->field_27
    //     0xae286c: ldur            w2, [x1, #0x27]
    // 0xae2870: DecompressPointer r2
    //     0xae2870: add             x2, x2, HEAP, lsl #32
    // 0xae2874: StoreField: r0->field_13 = r2
    //     0xae2874: stur            w2, [x0, #0x13]
    // 0xae2878: SaveReg r0
    //     0xae2878: str             x0, [SP, #-8]!
    // 0xae287c: r0 = _interpolate()
    //     0xae287c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2880: add             SP, SP, #8
    // 0xae2884: mov             x1, x0
    // 0xae2888: ldur            x0, [fp, #-0x10]
    // 0xae288c: stur            x1, [fp, #-0x18]
    // 0xae2890: LoadField: r2 = r0->field_b
    //     0xae2890: ldur            w2, [x0, #0xb]
    // 0xae2894: DecompressPointer r2
    //     0xae2894: add             x2, x2, HEAP, lsl #32
    // 0xae2898: stur            x2, [fp, #-8]
    // 0xae289c: LoadField: r3 = r0->field_f
    //     0xae289c: ldur            w3, [x0, #0xf]
    // 0xae28a0: DecompressPointer r3
    //     0xae28a0: add             x3, x3, HEAP, lsl #32
    // 0xae28a4: LoadField: r4 = r3->field_b
    //     0xae28a4: ldur            w4, [x3, #0xb]
    // 0xae28a8: DecompressPointer r4
    //     0xae28a8: add             x4, x4, HEAP, lsl #32
    // 0xae28ac: cmp             w2, w4
    // 0xae28b0: b.ne            #0xae28c0
    // 0xae28b4: SaveReg r0
    //     0xae28b4: str             x0, [SP, #-8]!
    // 0xae28b8: r0 = _growToNextCapacity()
    //     0xae28b8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae28bc: add             SP, SP, #8
    // 0xae28c0: ldur            x0, [fp, #-8]
    // 0xae28c4: ldur            x3, [fp, #-0x10]
    // 0xae28c8: r2 = LoadInt32Instr(r0)
    //     0xae28c8: sbfx            x2, x0, #1, #0x1f
    // 0xae28cc: add             x0, x2, #1
    // 0xae28d0: lsl             x1, x0, #1
    // 0xae28d4: StoreField: r3->field_b = r1
    //     0xae28d4: stur            w1, [x3, #0xb]
    // 0xae28d8: mov             x1, x2
    // 0xae28dc: cmp             x1, x0
    // 0xae28e0: b.hs            #0xae29ac
    // 0xae28e4: LoadField: r1 = r3->field_f
    //     0xae28e4: ldur            w1, [x3, #0xf]
    // 0xae28e8: DecompressPointer r1
    //     0xae28e8: add             x1, x1, HEAP, lsl #32
    // 0xae28ec: ldur            x0, [fp, #-0x18]
    // 0xae28f0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae28f0: add             x25, x1, x2, lsl #2
    //     0xae28f4: add             x25, x25, #0xf
    //     0xae28f8: str             w0, [x25]
    //     0xae28fc: tbz             w0, #0, #0xae2918
    //     0xae2900: ldurb           w16, [x1, #-1]
    //     0xae2904: ldurb           w17, [x0, #-1]
    //     0xae2908: and             x16, x17, x16, lsr #2
    //     0xae290c: tst             x16, HEAP, lsr #32
    //     0xae2910: b.eq            #0xae2918
    //     0xae2914: bl              #0xd67e5c
    // 0xae2918: r1 = Null
    //     0xae2918: mov             x1, NULL
    // 0xae291c: r2 = 8
    //     0xae291c: mov             x2, #8
    // 0xae2920: r0 = AllocateArray()
    //     0xae2920: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2924: stur            x0, [fp, #-8]
    // 0xae2928: r17 = "SweepGradient"
    //     0xae2928: add             x17, PP, #0x57, lsl #12  ; [pp+0x574f8] "SweepGradient"
    //     0xae292c: ldr             x17, [x17, #0x4f8]
    // 0xae2930: StoreField: r0->field_f = r17
    //     0xae2930: stur            w17, [x0, #0xf]
    // 0xae2934: r17 = "("
    //     0xae2934: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xae2938: StoreField: r0->field_13 = r17
    //     0xae2938: stur            w17, [x0, #0x13]
    // 0xae293c: ldur            x16, [fp, #-0x10]
    // 0xae2940: r30 = ", "
    //     0xae2940: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae2944: stp             lr, x16, [SP, #-0x10]!
    // 0xae2948: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xae2948: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xae294c: r0 = join()
    //     0xae294c: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xae2950: add             SP, SP, #0x10
    // 0xae2954: ldur            x1, [fp, #-8]
    // 0xae2958: ArrayStore: r1[2] = r0  ; List_4
    //     0xae2958: add             x25, x1, #0x17
    //     0xae295c: str             w0, [x25]
    //     0xae2960: tbz             w0, #0, #0xae297c
    //     0xae2964: ldurb           w16, [x1, #-1]
    //     0xae2968: ldurb           w17, [x0, #-1]
    //     0xae296c: and             x16, x17, x16, lsr #2
    //     0xae2970: tst             x16, HEAP, lsr #32
    //     0xae2974: b.eq            #0xae297c
    //     0xae2978: bl              #0xd67e5c
    // 0xae297c: ldur            x0, [fp, #-8]
    // 0xae2980: r17 = ")"
    //     0xae2980: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae2984: StoreField: r0->field_1b = r17
    //     0xae2984: stur            w17, [x0, #0x1b]
    // 0xae2988: SaveReg r0
    //     0xae2988: str             x0, [SP, #-8]!
    // 0xae298c: r0 = _interpolate()
    //     0xae298c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2990: add             SP, SP, #8
    // 0xae2994: LeaveFrame
    //     0xae2994: mov             SP, fp
    //     0xae2998: ldp             fp, lr, [SP], #0x10
    // 0xae299c: ret
    //     0xae299c: ret             
    // 0xae29a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae29a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae29a4: b               #0xae25dc
    // 0xae29a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae29a8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae29ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae29ac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0e8a8, size: 0xfc
    // 0xb0e8a8: EnterFrame
    //     0xb0e8a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb0e8ac: mov             fp, SP
    // 0xb0e8b0: AllocStack(0x8)
    //     0xb0e8b0: sub             SP, SP, #8
    // 0xb0e8b4: CheckStackOverflow
    //     0xb0e8b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0e8b8: cmp             SP, x16
    //     0xb0e8bc: b.ls            #0xb0e99c
    // 0xb0e8c0: ldr             x0, [fp, #0x10]
    // 0xb0e8c4: LoadField: r1 = r0->field_7
    //     0xb0e8c4: ldur            w1, [x0, #7]
    // 0xb0e8c8: DecompressPointer r1
    //     0xb0e8c8: add             x1, x1, HEAP, lsl #32
    // 0xb0e8cc: SaveReg r1
    //     0xb0e8cc: str             x1, [SP, #-8]!
    // 0xb0e8d0: r0 = hashAll()
    //     0xb0e8d0: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb0e8d4: add             SP, SP, #8
    // 0xb0e8d8: mov             x1, x0
    // 0xb0e8dc: ldr             x0, [fp, #0x10]
    // 0xb0e8e0: stur            x1, [fp, #-8]
    // 0xb0e8e4: LoadField: r2 = r0->field_b
    //     0xb0e8e4: ldur            w2, [x0, #0xb]
    // 0xb0e8e8: DecompressPointer r2
    //     0xb0e8e8: add             x2, x2, HEAP, lsl #32
    // 0xb0e8ec: cmp             w2, NULL
    // 0xb0e8f0: b.ne            #0xb0e900
    // 0xb0e8f4: mov             x2, x1
    // 0xb0e8f8: r3 = Null
    //     0xb0e8f8: mov             x3, NULL
    // 0xb0e8fc: b               #0xb0e92c
    // 0xb0e900: SaveReg r2
    //     0xb0e900: str             x2, [SP, #-8]!
    // 0xb0e904: r0 = hashAll()
    //     0xb0e904: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb0e908: add             SP, SP, #8
    // 0xb0e90c: mov             x2, x0
    // 0xb0e910: r0 = BoxInt64Instr(r2)
    //     0xb0e910: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e914: cmp             x2, x0, asr #1
    //     0xb0e918: b.eq            #0xb0e924
    //     0xb0e91c: bl              #0xd69bb8
    //     0xb0e920: stur            x2, [x0, #7]
    // 0xb0e924: mov             x3, x0
    // 0xb0e928: ldur            x2, [fp, #-8]
    // 0xb0e92c: r0 = BoxInt64Instr(r2)
    //     0xb0e92c: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e930: cmp             x2, x0, asr #1
    //     0xb0e934: b.eq            #0xb0e940
    //     0xb0e938: bl              #0xd69bb8
    //     0xb0e93c: stur            x2, [x0, #7]
    // 0xb0e940: r16 = Instance_Alignment
    //     0xb0e940: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb0e944: ldr             x16, [x16, #0xc70]
    // 0xb0e948: r30 = 0.000000
    //     0xb0e948: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xb0e94c: stp             lr, x16, [SP, #-0x10]!
    // 0xb0e950: r16 = 6.283185
    //     0xb0e950: add             x16, PP, #0x52, lsl #12  ; [pp+0x52090] 6.283185307179586
    //     0xb0e954: ldr             x16, [x16, #0x90]
    // 0xb0e958: r30 = Instance_TileMode
    //     0xb0e958: add             lr, PP, #0x27, lsl #12  ; [pp+0x271d8] Obj!TileMode@b675b1
    //     0xb0e95c: ldr             lr, [lr, #0x1d8]
    // 0xb0e960: stp             lr, x16, [SP, #-0x10]!
    // 0xb0e964: stp             x0, NULL, [SP, #-0x10]!
    // 0xb0e968: SaveReg r3
    //     0xb0e968: str             x3, [SP, #-8]!
    // 0xb0e96c: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0xb0e96c: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0xb0e970: r0 = hash()
    //     0xb0e970: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0e974: add             SP, SP, #0x38
    // 0xb0e978: mov             x2, x0
    // 0xb0e97c: r0 = BoxInt64Instr(r2)
    //     0xb0e97c: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e980: cmp             x2, x0, asr #1
    //     0xb0e984: b.eq            #0xb0e990
    //     0xb0e988: bl              #0xd69bb8
    //     0xb0e98c: stur            x2, [x0, #7]
    // 0xb0e990: LeaveFrame
    //     0xb0e990: mov             SP, fp
    //     0xb0e994: ldp             fp, lr, [SP], #0x10
    // 0xb0e998: ret
    //     0xb0e998: ret             
    // 0xb0e99c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0e99c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0e9a0: b               #0xb0e8c0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9d758, size: 0x19c
    // 0xc9d758: EnterFrame
    //     0xc9d758: stp             fp, lr, [SP, #-0x10]!
    //     0xc9d75c: mov             fp, SP
    // 0xc9d760: CheckStackOverflow
    //     0xc9d760: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9d764: cmp             SP, x16
    //     0xc9d768: b.ls            #0xc9d8ec
    // 0xc9d76c: ldr             x1, [fp, #0x10]
    // 0xc9d770: cmp             w1, NULL
    // 0xc9d774: b.ne            #0xc9d788
    // 0xc9d778: r0 = false
    //     0xc9d778: add             x0, NULL, #0x30  ; false
    // 0xc9d77c: LeaveFrame
    //     0xc9d77c: mov             SP, fp
    //     0xc9d780: ldp             fp, lr, [SP], #0x10
    // 0xc9d784: ret
    //     0xc9d784: ret             
    // 0xc9d788: ldr             x2, [fp, #0x18]
    // 0xc9d78c: cmp             w2, w1
    // 0xc9d790: b.ne            #0xc9d7a4
    // 0xc9d794: r0 = true
    //     0xc9d794: add             x0, NULL, #0x20  ; true
    // 0xc9d798: LeaveFrame
    //     0xc9d798: mov             SP, fp
    //     0xc9d79c: ldp             fp, lr, [SP], #0x10
    // 0xc9d7a0: ret
    //     0xc9d7a0: ret             
    // 0xc9d7a4: r0 = 59
    //     0xc9d7a4: mov             x0, #0x3b
    // 0xc9d7a8: branchIfSmi(r1, 0xc9d7b4)
    //     0xc9d7a8: tbz             w1, #0, #0xc9d7b4
    // 0xc9d7ac: r0 = LoadClassIdInstr(r1)
    //     0xc9d7ac: ldur            x0, [x1, #-1]
    //     0xc9d7b0: ubfx            x0, x0, #0xc, #0x14
    // 0xc9d7b4: SaveReg r1
    //     0xc9d7b4: str             x1, [SP, #-8]!
    // 0xc9d7b8: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9d7b8: mov             x17, #0x57c5
    //     0xc9d7bc: add             lr, x0, x17
    //     0xc9d7c0: ldr             lr, [x21, lr, lsl #3]
    //     0xc9d7c4: blr             lr
    // 0xc9d7c8: add             SP, SP, #8
    // 0xc9d7cc: r1 = LoadClassIdInstr(r0)
    //     0xc9d7cc: ldur            x1, [x0, #-1]
    //     0xc9d7d0: ubfx            x1, x1, #0xc, #0x14
    // 0xc9d7d4: r16 = SweepGradient
    //     0xc9d7d4: add             x16, PP, #0x57, lsl #12  ; [pp+0x57500] Type: SweepGradient
    //     0xc9d7d8: ldr             x16, [x16, #0x500]
    // 0xc9d7dc: stp             x16, x0, [SP, #-0x10]!
    // 0xc9d7e0: mov             x0, x1
    // 0xc9d7e4: mov             lr, x0
    // 0xc9d7e8: ldr             lr, [x21, lr, lsl #3]
    // 0xc9d7ec: blr             lr
    // 0xc9d7f0: add             SP, SP, #0x10
    // 0xc9d7f4: tbz             w0, #4, #0xc9d808
    // 0xc9d7f8: r0 = false
    //     0xc9d7f8: add             x0, NULL, #0x30  ; false
    // 0xc9d7fc: LeaveFrame
    //     0xc9d7fc: mov             SP, fp
    //     0xc9d800: ldp             fp, lr, [SP], #0x10
    // 0xc9d804: ret
    //     0xc9d804: ret             
    // 0xc9d808: ldr             x0, [fp, #0x10]
    // 0xc9d80c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc9d80c: mov             x1, #0x76
    //     0xc9d810: tbz             w0, #0, #0xc9d820
    //     0xc9d814: ldur            x1, [x0, #-1]
    //     0xc9d818: ubfx            x1, x1, #0xc, #0x14
    //     0xc9d81c: lsl             x1, x1, #1
    // 0xc9d820: r17 = 4192
    //     0xc9d820: mov             x17, #0x1060
    // 0xc9d824: cmp             w1, w17
    // 0xc9d828: b.ne            #0xc9d8dc
    // 0xc9d82c: r16 = Instance_Alignment
    //     0xc9d82c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc9d830: ldr             x16, [x16, #0xc70]
    // 0xc9d834: r30 = Instance_Alignment
    //     0xc9d834: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc9d838: ldr             lr, [lr, #0xc70]
    // 0xc9d83c: stp             lr, x16, [SP, #-0x10]!
    // 0xc9d840: r0 = ==()
    //     0xc9d840: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xc9d844: add             SP, SP, #0x10
    // 0xc9d848: tbnz            w0, #4, #0xc9d8dc
    // 0xc9d84c: d0 = 0.000000
    //     0xc9d84c: eor             v0.16b, v0.16b, v0.16b
    // 0xc9d850: fcmp            d0, d0
    // 0xc9d854: b.vs            #0xc9d8dc
    // 0xc9d858: b.ne            #0xc9d8dc
    // 0xc9d85c: d0 = 6.283185
    //     0xc9d85c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37848] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0xc9d860: ldr             d0, [x17, #0x848]
    // 0xc9d864: fcmp            d0, d0
    // 0xc9d868: b.vs            #0xc9d8dc
    // 0xc9d86c: b.ne            #0xc9d8dc
    // 0xc9d870: ldr             x1, [fp, #0x18]
    // 0xc9d874: ldr             x0, [fp, #0x10]
    // 0xc9d878: LoadField: r2 = r0->field_7
    //     0xc9d878: ldur            w2, [x0, #7]
    // 0xc9d87c: DecompressPointer r2
    //     0xc9d87c: add             x2, x2, HEAP, lsl #32
    // 0xc9d880: LoadField: r3 = r1->field_7
    //     0xc9d880: ldur            w3, [x1, #7]
    // 0xc9d884: DecompressPointer r3
    //     0xc9d884: add             x3, x3, HEAP, lsl #32
    // 0xc9d888: r16 = <Color>
    //     0xc9d888: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc9d88c: ldr             x16, [x16, #0x3f8]
    // 0xc9d890: stp             x2, x16, [SP, #-0x10]!
    // 0xc9d894: SaveReg r3
    //     0xc9d894: str             x3, [SP, #-8]!
    // 0xc9d898: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc9d898: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc9d89c: r0 = listEquals()
    //     0xc9d89c: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc9d8a0: add             SP, SP, #0x18
    // 0xc9d8a4: tbnz            w0, #4, #0xc9d8dc
    // 0xc9d8a8: ldr             x1, [fp, #0x18]
    // 0xc9d8ac: ldr             x0, [fp, #0x10]
    // 0xc9d8b0: LoadField: r2 = r0->field_b
    //     0xc9d8b0: ldur            w2, [x0, #0xb]
    // 0xc9d8b4: DecompressPointer r2
    //     0xc9d8b4: add             x2, x2, HEAP, lsl #32
    // 0xc9d8b8: LoadField: r0 = r1->field_b
    //     0xc9d8b8: ldur            w0, [x1, #0xb]
    // 0xc9d8bc: DecompressPointer r0
    //     0xc9d8bc: add             x0, x0, HEAP, lsl #32
    // 0xc9d8c0: r16 = <double>
    //     0xc9d8c0: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc9d8c4: stp             x2, x16, [SP, #-0x10]!
    // 0xc9d8c8: SaveReg r0
    //     0xc9d8c8: str             x0, [SP, #-8]!
    // 0xc9d8cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc9d8cc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc9d8d0: r0 = listEquals()
    //     0xc9d8d0: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc9d8d4: add             SP, SP, #0x18
    // 0xc9d8d8: b               #0xc9d8e0
    // 0xc9d8dc: r0 = false
    //     0xc9d8dc: add             x0, NULL, #0x30  ; false
    // 0xc9d8e0: LeaveFrame
    //     0xc9d8e0: mov             SP, fp
    //     0xc9d8e4: ldp             fp, lr, [SP], #0x10
    // 0xc9d8e8: ret
    //     0xc9d8e8: ret             
    // 0xc9d8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9d8ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9d8f0: b               #0xc9d76c
  }
}

// class id: 2097, size: 0x20, field offset: 0x14
//   const constructor, 
class LinearGradient extends Gradient {

  _ImmutableList<Color> field_8;
  Alignment field_14;
  Alignment field_18;
  TileMode field_1c;

  _ toString(/* No info */) {
    // ** addr: 0xae227c, size: 0x348
    // 0xae227c: EnterFrame
    //     0xae227c: stp             fp, lr, [SP, #-0x10]!
    //     0xae2280: mov             fp, SP
    // 0xae2284: AllocStack(0x20)
    //     0xae2284: sub             SP, SP, #0x20
    // 0xae2288: CheckStackOverflow
    //     0xae2288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae228c: cmp             SP, x16
    //     0xae2290: b.ls            #0xae25b4
    // 0xae2294: r1 = Null
    //     0xae2294: mov             x1, NULL
    // 0xae2298: r2 = 4
    //     0xae2298: mov             x2, #4
    // 0xae229c: r0 = AllocateArray()
    //     0xae229c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae22a0: r17 = "begin: "
    //     0xae22a0: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da60] "begin: "
    //     0xae22a4: ldr             x17, [x17, #0xa60]
    // 0xae22a8: StoreField: r0->field_f = r17
    //     0xae22a8: stur            w17, [x0, #0xf]
    // 0xae22ac: ldr             x1, [fp, #0x10]
    // 0xae22b0: LoadField: r2 = r1->field_13
    //     0xae22b0: ldur            w2, [x1, #0x13]
    // 0xae22b4: DecompressPointer r2
    //     0xae22b4: add             x2, x2, HEAP, lsl #32
    // 0xae22b8: StoreField: r0->field_13 = r2
    //     0xae22b8: stur            w2, [x0, #0x13]
    // 0xae22bc: SaveReg r0
    //     0xae22bc: str             x0, [SP, #-8]!
    // 0xae22c0: r0 = _interpolate()
    //     0xae22c0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae22c4: add             SP, SP, #8
    // 0xae22c8: r1 = Null
    //     0xae22c8: mov             x1, NULL
    // 0xae22cc: r2 = 4
    //     0xae22cc: mov             x2, #4
    // 0xae22d0: stur            x0, [fp, #-8]
    // 0xae22d4: r0 = AllocateArray()
    //     0xae22d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae22d8: r17 = "end: "
    //     0xae22d8: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da68] "end: "
    //     0xae22dc: ldr             x17, [x17, #0xa68]
    // 0xae22e0: StoreField: r0->field_f = r17
    //     0xae22e0: stur            w17, [x0, #0xf]
    // 0xae22e4: ldr             x1, [fp, #0x10]
    // 0xae22e8: LoadField: r2 = r1->field_17
    //     0xae22e8: ldur            w2, [x1, #0x17]
    // 0xae22ec: DecompressPointer r2
    //     0xae22ec: add             x2, x2, HEAP, lsl #32
    // 0xae22f0: StoreField: r0->field_13 = r2
    //     0xae22f0: stur            w2, [x0, #0x13]
    // 0xae22f4: SaveReg r0
    //     0xae22f4: str             x0, [SP, #-8]!
    // 0xae22f8: r0 = _interpolate()
    //     0xae22f8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae22fc: add             SP, SP, #8
    // 0xae2300: r1 = Null
    //     0xae2300: mov             x1, NULL
    // 0xae2304: r2 = 4
    //     0xae2304: mov             x2, #4
    // 0xae2308: stur            x0, [fp, #-0x10]
    // 0xae230c: r0 = AllocateArray()
    //     0xae230c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2310: r17 = "colors: "
    //     0xae2310: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da70] "colors: "
    //     0xae2314: ldr             x17, [x17, #0xa70]
    // 0xae2318: StoreField: r0->field_f = r17
    //     0xae2318: stur            w17, [x0, #0xf]
    // 0xae231c: ldr             x1, [fp, #0x10]
    // 0xae2320: LoadField: r2 = r1->field_7
    //     0xae2320: ldur            w2, [x1, #7]
    // 0xae2324: DecompressPointer r2
    //     0xae2324: add             x2, x2, HEAP, lsl #32
    // 0xae2328: StoreField: r0->field_13 = r2
    //     0xae2328: stur            w2, [x0, #0x13]
    // 0xae232c: SaveReg r0
    //     0xae232c: str             x0, [SP, #-8]!
    // 0xae2330: r0 = _interpolate()
    //     0xae2330: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2334: add             SP, SP, #8
    // 0xae2338: r1 = Null
    //     0xae2338: mov             x1, NULL
    // 0xae233c: r2 = 6
    //     0xae233c: mov             x2, #6
    // 0xae2340: stur            x0, [fp, #-0x18]
    // 0xae2344: r0 = AllocateArray()
    //     0xae2344: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2348: mov             x2, x0
    // 0xae234c: ldur            x0, [fp, #-8]
    // 0xae2350: stur            x2, [fp, #-0x20]
    // 0xae2354: StoreField: r2->field_f = r0
    //     0xae2354: stur            w0, [x2, #0xf]
    // 0xae2358: ldur            x0, [fp, #-0x10]
    // 0xae235c: StoreField: r2->field_13 = r0
    //     0xae235c: stur            w0, [x2, #0x13]
    // 0xae2360: ldur            x0, [fp, #-0x18]
    // 0xae2364: StoreField: r2->field_17 = r0
    //     0xae2364: stur            w0, [x2, #0x17]
    // 0xae2368: r1 = <String>
    //     0xae2368: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xae236c: r0 = AllocateGrowableArray()
    //     0xae236c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xae2370: mov             x3, x0
    // 0xae2374: ldur            x0, [fp, #-0x20]
    // 0xae2378: stur            x3, [fp, #-0x10]
    // 0xae237c: StoreField: r3->field_f = r0
    //     0xae237c: stur            w0, [x3, #0xf]
    // 0xae2380: r0 = 6
    //     0xae2380: mov             x0, #6
    // 0xae2384: StoreField: r3->field_b = r0
    //     0xae2384: stur            w0, [x3, #0xb]
    // 0xae2388: ldr             x0, [fp, #0x10]
    // 0xae238c: LoadField: r4 = r0->field_b
    //     0xae238c: ldur            w4, [x0, #0xb]
    // 0xae2390: DecompressPointer r4
    //     0xae2390: add             x4, x4, HEAP, lsl #32
    // 0xae2394: stur            x4, [fp, #-8]
    // 0xae2398: cmp             w4, NULL
    // 0xae239c: b.eq            #0xae2460
    // 0xae23a0: r1 = Null
    //     0xae23a0: mov             x1, NULL
    // 0xae23a4: r2 = 4
    //     0xae23a4: mov             x2, #4
    // 0xae23a8: r0 = AllocateArray()
    //     0xae23a8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae23ac: r17 = "stops: "
    //     0xae23ac: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da78] "stops: "
    //     0xae23b0: ldr             x17, [x17, #0xa78]
    // 0xae23b4: StoreField: r0->field_f = r17
    //     0xae23b4: stur            w17, [x0, #0xf]
    // 0xae23b8: ldur            x1, [fp, #-8]
    // 0xae23bc: StoreField: r0->field_13 = r1
    //     0xae23bc: stur            w1, [x0, #0x13]
    // 0xae23c0: SaveReg r0
    //     0xae23c0: str             x0, [SP, #-8]!
    // 0xae23c4: r0 = _interpolate()
    //     0xae23c4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae23c8: add             SP, SP, #8
    // 0xae23cc: mov             x1, x0
    // 0xae23d0: ldur            x0, [fp, #-0x10]
    // 0xae23d4: stur            x1, [fp, #-0x18]
    // 0xae23d8: LoadField: r2 = r0->field_b
    //     0xae23d8: ldur            w2, [x0, #0xb]
    // 0xae23dc: DecompressPointer r2
    //     0xae23dc: add             x2, x2, HEAP, lsl #32
    // 0xae23e0: stur            x2, [fp, #-8]
    // 0xae23e4: LoadField: r3 = r0->field_f
    //     0xae23e4: ldur            w3, [x0, #0xf]
    // 0xae23e8: DecompressPointer r3
    //     0xae23e8: add             x3, x3, HEAP, lsl #32
    // 0xae23ec: LoadField: r4 = r3->field_b
    //     0xae23ec: ldur            w4, [x3, #0xb]
    // 0xae23f0: DecompressPointer r4
    //     0xae23f0: add             x4, x4, HEAP, lsl #32
    // 0xae23f4: cmp             w2, w4
    // 0xae23f8: b.ne            #0xae2408
    // 0xae23fc: SaveReg r0
    //     0xae23fc: str             x0, [SP, #-8]!
    // 0xae2400: r0 = _growToNextCapacity()
    //     0xae2400: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae2404: add             SP, SP, #8
    // 0xae2408: ldur            x0, [fp, #-8]
    // 0xae240c: ldur            x3, [fp, #-0x10]
    // 0xae2410: r2 = LoadInt32Instr(r0)
    //     0xae2410: sbfx            x2, x0, #1, #0x1f
    // 0xae2414: add             x0, x2, #1
    // 0xae2418: lsl             x1, x0, #1
    // 0xae241c: StoreField: r3->field_b = r1
    //     0xae241c: stur            w1, [x3, #0xb]
    // 0xae2420: mov             x1, x2
    // 0xae2424: cmp             x1, x0
    // 0xae2428: b.hs            #0xae25bc
    // 0xae242c: LoadField: r1 = r3->field_f
    //     0xae242c: ldur            w1, [x3, #0xf]
    // 0xae2430: DecompressPointer r1
    //     0xae2430: add             x1, x1, HEAP, lsl #32
    // 0xae2434: ldur            x0, [fp, #-0x18]
    // 0xae2438: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae2438: add             x25, x1, x2, lsl #2
    //     0xae243c: add             x25, x25, #0xf
    //     0xae2440: str             w0, [x25]
    //     0xae2444: tbz             w0, #0, #0xae2460
    //     0xae2448: ldurb           w16, [x1, #-1]
    //     0xae244c: ldurb           w17, [x0, #-1]
    //     0xae2450: and             x16, x17, x16, lsr #2
    //     0xae2454: tst             x16, HEAP, lsr #32
    //     0xae2458: b.eq            #0xae2460
    //     0xae245c: bl              #0xd67e5c
    // 0xae2460: ldr             x0, [fp, #0x10]
    // 0xae2464: r1 = Null
    //     0xae2464: mov             x1, NULL
    // 0xae2468: r2 = 4
    //     0xae2468: mov             x2, #4
    // 0xae246c: r0 = AllocateArray()
    //     0xae246c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2470: r17 = "tileMode: "
    //     0xae2470: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da80] "tileMode: "
    //     0xae2474: ldr             x17, [x17, #0xa80]
    // 0xae2478: StoreField: r0->field_f = r17
    //     0xae2478: stur            w17, [x0, #0xf]
    // 0xae247c: ldr             x1, [fp, #0x10]
    // 0xae2480: LoadField: r2 = r1->field_1b
    //     0xae2480: ldur            w2, [x1, #0x1b]
    // 0xae2484: DecompressPointer r2
    //     0xae2484: add             x2, x2, HEAP, lsl #32
    // 0xae2488: StoreField: r0->field_13 = r2
    //     0xae2488: stur            w2, [x0, #0x13]
    // 0xae248c: SaveReg r0
    //     0xae248c: str             x0, [SP, #-8]!
    // 0xae2490: r0 = _interpolate()
    //     0xae2490: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2494: add             SP, SP, #8
    // 0xae2498: mov             x1, x0
    // 0xae249c: ldur            x0, [fp, #-0x10]
    // 0xae24a0: stur            x1, [fp, #-0x18]
    // 0xae24a4: LoadField: r2 = r0->field_b
    //     0xae24a4: ldur            w2, [x0, #0xb]
    // 0xae24a8: DecompressPointer r2
    //     0xae24a8: add             x2, x2, HEAP, lsl #32
    // 0xae24ac: stur            x2, [fp, #-8]
    // 0xae24b0: LoadField: r3 = r0->field_f
    //     0xae24b0: ldur            w3, [x0, #0xf]
    // 0xae24b4: DecompressPointer r3
    //     0xae24b4: add             x3, x3, HEAP, lsl #32
    // 0xae24b8: LoadField: r4 = r3->field_b
    //     0xae24b8: ldur            w4, [x3, #0xb]
    // 0xae24bc: DecompressPointer r4
    //     0xae24bc: add             x4, x4, HEAP, lsl #32
    // 0xae24c0: cmp             w2, w4
    // 0xae24c4: b.ne            #0xae24d4
    // 0xae24c8: SaveReg r0
    //     0xae24c8: str             x0, [SP, #-8]!
    // 0xae24cc: r0 = _growToNextCapacity()
    //     0xae24cc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae24d0: add             SP, SP, #8
    // 0xae24d4: ldur            x0, [fp, #-8]
    // 0xae24d8: ldur            x3, [fp, #-0x10]
    // 0xae24dc: r2 = LoadInt32Instr(r0)
    //     0xae24dc: sbfx            x2, x0, #1, #0x1f
    // 0xae24e0: add             x0, x2, #1
    // 0xae24e4: lsl             x1, x0, #1
    // 0xae24e8: StoreField: r3->field_b = r1
    //     0xae24e8: stur            w1, [x3, #0xb]
    // 0xae24ec: mov             x1, x2
    // 0xae24f0: cmp             x1, x0
    // 0xae24f4: b.hs            #0xae25c0
    // 0xae24f8: LoadField: r1 = r3->field_f
    //     0xae24f8: ldur            w1, [x3, #0xf]
    // 0xae24fc: DecompressPointer r1
    //     0xae24fc: add             x1, x1, HEAP, lsl #32
    // 0xae2500: ldur            x0, [fp, #-0x18]
    // 0xae2504: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae2504: add             x25, x1, x2, lsl #2
    //     0xae2508: add             x25, x25, #0xf
    //     0xae250c: str             w0, [x25]
    //     0xae2510: tbz             w0, #0, #0xae252c
    //     0xae2514: ldurb           w16, [x1, #-1]
    //     0xae2518: ldurb           w17, [x0, #-1]
    //     0xae251c: and             x16, x17, x16, lsr #2
    //     0xae2520: tst             x16, HEAP, lsr #32
    //     0xae2524: b.eq            #0xae252c
    //     0xae2528: bl              #0xd67e5c
    // 0xae252c: r1 = Null
    //     0xae252c: mov             x1, NULL
    // 0xae2530: r2 = 8
    //     0xae2530: mov             x2, #8
    // 0xae2534: r0 = AllocateArray()
    //     0xae2534: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2538: stur            x0, [fp, #-8]
    // 0xae253c: r17 = "LinearGradient"
    //     0xae253c: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2da88] "LinearGradient"
    //     0xae2540: ldr             x17, [x17, #0xa88]
    // 0xae2544: StoreField: r0->field_f = r17
    //     0xae2544: stur            w17, [x0, #0xf]
    // 0xae2548: r17 = "("
    //     0xae2548: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xae254c: StoreField: r0->field_13 = r17
    //     0xae254c: stur            w17, [x0, #0x13]
    // 0xae2550: ldur            x16, [fp, #-0x10]
    // 0xae2554: r30 = ", "
    //     0xae2554: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae2558: stp             lr, x16, [SP, #-0x10]!
    // 0xae255c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xae255c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xae2560: r0 = join()
    //     0xae2560: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xae2564: add             SP, SP, #0x10
    // 0xae2568: ldur            x1, [fp, #-8]
    // 0xae256c: ArrayStore: r1[2] = r0  ; List_4
    //     0xae256c: add             x25, x1, #0x17
    //     0xae2570: str             w0, [x25]
    //     0xae2574: tbz             w0, #0, #0xae2590
    //     0xae2578: ldurb           w16, [x1, #-1]
    //     0xae257c: ldurb           w17, [x0, #-1]
    //     0xae2580: and             x16, x17, x16, lsr #2
    //     0xae2584: tst             x16, HEAP, lsr #32
    //     0xae2588: b.eq            #0xae2590
    //     0xae258c: bl              #0xd67e5c
    // 0xae2590: ldur            x0, [fp, #-8]
    // 0xae2594: r17 = ")"
    //     0xae2594: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae2598: StoreField: r0->field_1b = r17
    //     0xae2598: stur            w17, [x0, #0x1b]
    // 0xae259c: SaveReg r0
    //     0xae259c: str             x0, [SP, #-8]!
    // 0xae25a0: r0 = _interpolate()
    //     0xae25a0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae25a4: add             SP, SP, #8
    // 0xae25a8: LeaveFrame
    //     0xae25a8: mov             SP, fp
    //     0xae25ac: ldp             fp, lr, [SP], #0x10
    // 0xae25b0: ret
    //     0xae25b0: ret             
    // 0xae25b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae25b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae25b8: b               #0xae2294
    // 0xae25bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae25bc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae25c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae25c0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0e7a4, size: 0x104
    // 0xb0e7a4: EnterFrame
    //     0xb0e7a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb0e7a8: mov             fp, SP
    // 0xb0e7ac: AllocStack(0x18)
    //     0xb0e7ac: sub             SP, SP, #0x18
    // 0xb0e7b0: CheckStackOverflow
    //     0xb0e7b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0e7b4: cmp             SP, x16
    //     0xb0e7b8: b.ls            #0xb0e8a0
    // 0xb0e7bc: ldr             x0, [fp, #0x10]
    // 0xb0e7c0: LoadField: r1 = r0->field_13
    //     0xb0e7c0: ldur            w1, [x0, #0x13]
    // 0xb0e7c4: DecompressPointer r1
    //     0xb0e7c4: add             x1, x1, HEAP, lsl #32
    // 0xb0e7c8: stur            x1, [fp, #-0x10]
    // 0xb0e7cc: LoadField: r2 = r0->field_17
    //     0xb0e7cc: ldur            w2, [x0, #0x17]
    // 0xb0e7d0: DecompressPointer r2
    //     0xb0e7d0: add             x2, x2, HEAP, lsl #32
    // 0xb0e7d4: stur            x2, [fp, #-8]
    // 0xb0e7d8: LoadField: r3 = r0->field_7
    //     0xb0e7d8: ldur            w3, [x0, #7]
    // 0xb0e7dc: DecompressPointer r3
    //     0xb0e7dc: add             x3, x3, HEAP, lsl #32
    // 0xb0e7e0: SaveReg r3
    //     0xb0e7e0: str             x3, [SP, #-8]!
    // 0xb0e7e4: r0 = hashAll()
    //     0xb0e7e4: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb0e7e8: add             SP, SP, #8
    // 0xb0e7ec: mov             x1, x0
    // 0xb0e7f0: ldr             x0, [fp, #0x10]
    // 0xb0e7f4: stur            x1, [fp, #-0x18]
    // 0xb0e7f8: LoadField: r2 = r0->field_b
    //     0xb0e7f8: ldur            w2, [x0, #0xb]
    // 0xb0e7fc: DecompressPointer r2
    //     0xb0e7fc: add             x2, x2, HEAP, lsl #32
    // 0xb0e800: cmp             w2, NULL
    // 0xb0e804: b.ne            #0xb0e814
    // 0xb0e808: mov             x2, x1
    // 0xb0e80c: r3 = Null
    //     0xb0e80c: mov             x3, NULL
    // 0xb0e810: b               #0xb0e840
    // 0xb0e814: SaveReg r2
    //     0xb0e814: str             x2, [SP, #-8]!
    // 0xb0e818: r0 = hashAll()
    //     0xb0e818: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb0e81c: add             SP, SP, #8
    // 0xb0e820: mov             x2, x0
    // 0xb0e824: r0 = BoxInt64Instr(r2)
    //     0xb0e824: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e828: cmp             x2, x0, asr #1
    //     0xb0e82c: b.eq            #0xb0e838
    //     0xb0e830: bl              #0xd69bb8
    //     0xb0e834: stur            x2, [x0, #7]
    // 0xb0e838: mov             x3, x0
    // 0xb0e83c: ldur            x2, [fp, #-0x18]
    // 0xb0e840: r0 = BoxInt64Instr(r2)
    //     0xb0e840: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e844: cmp             x2, x0, asr #1
    //     0xb0e848: b.eq            #0xb0e854
    //     0xb0e84c: bl              #0xd69bb8
    //     0xb0e850: stur            x2, [x0, #7]
    // 0xb0e854: ldur            x16, [fp, #-0x10]
    // 0xb0e858: ldur            lr, [fp, #-8]
    // 0xb0e85c: stp             lr, x16, [SP, #-0x10]!
    // 0xb0e860: r16 = Instance_TileMode
    //     0xb0e860: add             x16, PP, #0x27, lsl #12  ; [pp+0x271d8] Obj!TileMode@b675b1
    //     0xb0e864: ldr             x16, [x16, #0x1d8]
    // 0xb0e868: stp             NULL, x16, [SP, #-0x10]!
    // 0xb0e86c: stp             x3, x0, [SP, #-0x10]!
    // 0xb0e870: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0xb0e870: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0xb0e874: r0 = hash()
    //     0xb0e874: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0e878: add             SP, SP, #0x30
    // 0xb0e87c: mov             x2, x0
    // 0xb0e880: r0 = BoxInt64Instr(r2)
    //     0xb0e880: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e884: cmp             x2, x0, asr #1
    //     0xb0e888: b.eq            #0xb0e894
    //     0xb0e88c: bl              #0xd69bb8
    //     0xb0e890: stur            x2, [x0, #7]
    // 0xb0e894: LeaveFrame
    //     0xb0e894: mov             SP, fp
    //     0xb0e898: ldp             fp, lr, [SP], #0x10
    // 0xb0e89c: ret
    //     0xb0e89c: ret             
    // 0xb0e8a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0e8a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0e8a4: b               #0xb0e7bc
  }
  _ createShader(/* No info */) {
    // ** addr: 0xc71978, size: 0x3a0
    // 0xc71978: EnterFrame
    //     0xc71978: stp             fp, lr, [SP, #-0x10]!
    //     0xc7197c: mov             fp, SP
    // 0xc71980: AllocStack(0x38)
    //     0xc71980: sub             SP, SP, #0x38
    // 0xc71984: SetupParameters(LinearGradient this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic textDirection = Null /* r0, fp-0x8 */})
    //     0xc71984: mov             x0, x4
    //     0xc71988: ldur            w1, [x0, #0x13]
    //     0xc7198c: add             x1, x1, HEAP, lsl #32
    //     0xc71990: sub             x2, x1, #4
    //     0xc71994: add             x3, fp, w2, sxtw #2
    //     0xc71998: ldr             x3, [x3, #0x18]
    //     0xc7199c: stur            x3, [fp, #-0x18]
    //     0xc719a0: add             x4, fp, w2, sxtw #2
    //     0xc719a4: ldr             x4, [x4, #0x10]
    //     0xc719a8: stur            x4, [fp, #-0x10]
    //     0xc719ac: ldur            w2, [x0, #0x1f]
    //     0xc719b0: add             x2, x2, HEAP, lsl #32
    //     0xc719b4: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0xc719b8: ldr             x16, [x16, #0xf10]
    //     0xc719bc: cmp             w2, w16
    //     0xc719c0: b.ne            #0xc719e0
    //     0xc719c4: ldur            w2, [x0, #0x23]
    //     0xc719c8: add             x2, x2, HEAP, lsl #32
    //     0xc719cc: sub             w0, w1, w2
    //     0xc719d0: add             x1, fp, w0, sxtw #2
    //     0xc719d4: ldr             x1, [x1, #8]
    //     0xc719d8: mov             x0, x1
    //     0xc719dc: b               #0xc719e4
    //     0xc719e0: mov             x0, NULL
    //     0xc719e4: stur            x0, [fp, #-8]
    // 0xc719e8: CheckStackOverflow
    //     0xc719e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc719ec: cmp             SP, x16
    //     0xc719f0: b.ls            #0xc71d00
    // 0xc719f4: LoadField: r1 = r3->field_13
    //     0xc719f4: ldur            w1, [x3, #0x13]
    // 0xc719f8: DecompressPointer r1
    //     0xc719f8: add             x1, x1, HEAP, lsl #32
    // 0xc719fc: r2 = LoadClassIdInstr(r1)
    //     0xc719fc: ldur            x2, [x1, #-1]
    //     0xc71a00: ubfx            x2, x2, #0xc, #0x14
    // 0xc71a04: lsl             x2, x2, #1
    // 0xc71a08: r17 = 4240
    //     0xc71a08: mov             x17, #0x1090
    // 0xc71a0c: cmp             w2, w17
    // 0xc71a10: b.gt            #0xc71a28
    // 0xc71a14: r17 = 4238
    //     0xc71a14: mov             x17, #0x108e
    // 0xc71a18: cmp             w2, w17
    // 0xc71a1c: b.lt            #0xc71a28
    // 0xc71a20: mov             x0, x3
    // 0xc71a24: b               #0xc71b2c
    // 0xc71a28: r17 = 4234
    //     0xc71a28: mov             x17, #0x108a
    // 0xc71a2c: cmp             w2, w17
    // 0xc71a30: b.ne            #0xc71ab8
    // 0xc71a34: cmp             w0, NULL
    // 0xc71a38: b.eq            #0xc71d08
    // 0xc71a3c: LoadField: r2 = r0->field_7
    //     0xc71a3c: ldur            x2, [x0, #7]
    // 0xc71a40: cmp             x2, #0
    // 0xc71a44: b.gt            #0xc71a80
    // 0xc71a48: LoadField: d0 = r1->field_7
    //     0xc71a48: ldur            d0, [x1, #7]
    // 0xc71a4c: LoadField: d1 = r1->field_f
    //     0xc71a4c: ldur            d1, [x1, #0xf]
    // 0xc71a50: fsub            d2, d0, d1
    // 0xc71a54: stur            d2, [fp, #-0x38]
    // 0xc71a58: LoadField: d0 = r1->field_17
    //     0xc71a58: ldur            d0, [x1, #0x17]
    // 0xc71a5c: stur            d0, [fp, #-0x30]
    // 0xc71a60: r0 = Alignment()
    //     0xc71a60: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xc71a64: ldur            d0, [fp, #-0x38]
    // 0xc71a68: StoreField: r0->field_7 = d0
    //     0xc71a68: stur            d0, [x0, #7]
    // 0xc71a6c: ldur            d0, [fp, #-0x30]
    // 0xc71a70: StoreField: r0->field_f = d0
    //     0xc71a70: stur            d0, [x0, #0xf]
    // 0xc71a74: mov             x1, x0
    // 0xc71a78: ldur            x0, [fp, #-0x18]
    // 0xc71a7c: b               #0xc71b2c
    // 0xc71a80: LoadField: d0 = r1->field_7
    //     0xc71a80: ldur            d0, [x1, #7]
    // 0xc71a84: LoadField: d1 = r1->field_f
    //     0xc71a84: ldur            d1, [x1, #0xf]
    // 0xc71a88: fadd            d2, d0, d1
    // 0xc71a8c: stur            d2, [fp, #-0x38]
    // 0xc71a90: LoadField: d0 = r1->field_17
    //     0xc71a90: ldur            d0, [x1, #0x17]
    // 0xc71a94: stur            d0, [fp, #-0x30]
    // 0xc71a98: r0 = Alignment()
    //     0xc71a98: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xc71a9c: ldur            d0, [fp, #-0x38]
    // 0xc71aa0: StoreField: r0->field_7 = d0
    //     0xc71aa0: stur            d0, [x0, #7]
    // 0xc71aa4: ldur            d0, [fp, #-0x30]
    // 0xc71aa8: StoreField: r0->field_f = d0
    //     0xc71aa8: stur            d0, [x0, #0xf]
    // 0xc71aac: mov             x1, x0
    // 0xc71ab0: ldur            x0, [fp, #-0x18]
    // 0xc71ab4: b               #0xc71b2c
    // 0xc71ab8: cmp             w0, NULL
    // 0xc71abc: b.eq            #0xc71d0c
    // 0xc71ac0: LoadField: r2 = r0->field_7
    //     0xc71ac0: ldur            x2, [x0, #7]
    // 0xc71ac4: cmp             x2, #0
    // 0xc71ac8: b.gt            #0xc71b00
    // 0xc71acc: LoadField: d0 = r1->field_7
    //     0xc71acc: ldur            d0, [x1, #7]
    // 0xc71ad0: fneg            d1, d0
    // 0xc71ad4: stur            d1, [fp, #-0x38]
    // 0xc71ad8: LoadField: d0 = r1->field_f
    //     0xc71ad8: ldur            d0, [x1, #0xf]
    // 0xc71adc: stur            d0, [fp, #-0x30]
    // 0xc71ae0: r0 = Alignment()
    //     0xc71ae0: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xc71ae4: ldur            d0, [fp, #-0x38]
    // 0xc71ae8: StoreField: r0->field_7 = d0
    //     0xc71ae8: stur            d0, [x0, #7]
    // 0xc71aec: ldur            d0, [fp, #-0x30]
    // 0xc71af0: StoreField: r0->field_f = d0
    //     0xc71af0: stur            d0, [x0, #0xf]
    // 0xc71af4: mov             x1, x0
    // 0xc71af8: ldur            x0, [fp, #-0x18]
    // 0xc71afc: b               #0xc71b2c
    // 0xc71b00: LoadField: d0 = r1->field_7
    //     0xc71b00: ldur            d0, [x1, #7]
    // 0xc71b04: stur            d0, [fp, #-0x38]
    // 0xc71b08: LoadField: d1 = r1->field_f
    //     0xc71b08: ldur            d1, [x1, #0xf]
    // 0xc71b0c: stur            d1, [fp, #-0x30]
    // 0xc71b10: r0 = Alignment()
    //     0xc71b10: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xc71b14: ldur            d0, [fp, #-0x38]
    // 0xc71b18: StoreField: r0->field_7 = d0
    //     0xc71b18: stur            d0, [x0, #7]
    // 0xc71b1c: ldur            d0, [fp, #-0x30]
    // 0xc71b20: StoreField: r0->field_f = d0
    //     0xc71b20: stur            d0, [x0, #0xf]
    // 0xc71b24: mov             x1, x0
    // 0xc71b28: ldur            x0, [fp, #-0x18]
    // 0xc71b2c: ldur            x16, [fp, #-0x10]
    // 0xc71b30: stp             x16, x1, [SP, #-0x10]!
    // 0xc71b34: r0 = withinRect()
    //     0xc71b34: bl              #0xa75430  ; [package:flutter/src/painting/alignment.dart] Alignment::withinRect
    // 0xc71b38: add             SP, SP, #0x10
    // 0xc71b3c: mov             x1, x0
    // 0xc71b40: ldur            x0, [fp, #-0x18]
    // 0xc71b44: stur            x1, [fp, #-0x20]
    // 0xc71b48: LoadField: r2 = r0->field_17
    //     0xc71b48: ldur            w2, [x0, #0x17]
    // 0xc71b4c: DecompressPointer r2
    //     0xc71b4c: add             x2, x2, HEAP, lsl #32
    // 0xc71b50: r3 = LoadClassIdInstr(r2)
    //     0xc71b50: ldur            x3, [x2, #-1]
    //     0xc71b54: ubfx            x3, x3, #0xc, #0x14
    // 0xc71b58: lsl             x3, x3, #1
    // 0xc71b5c: r17 = 4240
    //     0xc71b5c: mov             x17, #0x1090
    // 0xc71b60: cmp             w3, w17
    // 0xc71b64: b.gt            #0xc71b7c
    // 0xc71b68: r17 = 4238
    //     0xc71b68: mov             x17, #0x108e
    // 0xc71b6c: cmp             w3, w17
    // 0xc71b70: b.lt            #0xc71b7c
    // 0xc71b74: mov             x1, x2
    // 0xc71b78: b               #0xc71c88
    // 0xc71b7c: r17 = 4234
    //     0xc71b7c: mov             x17, #0x108a
    // 0xc71b80: cmp             w3, w17
    // 0xc71b84: b.ne            #0xc71c10
    // 0xc71b88: ldur            x3, [fp, #-8]
    // 0xc71b8c: cmp             w3, NULL
    // 0xc71b90: b.eq            #0xc71d10
    // 0xc71b94: LoadField: r4 = r3->field_7
    //     0xc71b94: ldur            x4, [x3, #7]
    // 0xc71b98: cmp             x4, #0
    // 0xc71b9c: b.gt            #0xc71bd8
    // 0xc71ba0: LoadField: d0 = r2->field_7
    //     0xc71ba0: ldur            d0, [x2, #7]
    // 0xc71ba4: LoadField: d1 = r2->field_f
    //     0xc71ba4: ldur            d1, [x2, #0xf]
    // 0xc71ba8: fsub            d2, d0, d1
    // 0xc71bac: stur            d2, [fp, #-0x38]
    // 0xc71bb0: LoadField: d0 = r2->field_17
    //     0xc71bb0: ldur            d0, [x2, #0x17]
    // 0xc71bb4: stur            d0, [fp, #-0x30]
    // 0xc71bb8: r0 = Alignment()
    //     0xc71bb8: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xc71bbc: ldur            d0, [fp, #-0x38]
    // 0xc71bc0: StoreField: r0->field_7 = d0
    //     0xc71bc0: stur            d0, [x0, #7]
    // 0xc71bc4: ldur            d0, [fp, #-0x30]
    // 0xc71bc8: StoreField: r0->field_f = d0
    //     0xc71bc8: stur            d0, [x0, #0xf]
    // 0xc71bcc: mov             x1, x0
    // 0xc71bd0: ldur            x0, [fp, #-0x18]
    // 0xc71bd4: b               #0xc71c88
    // 0xc71bd8: LoadField: d0 = r2->field_7
    //     0xc71bd8: ldur            d0, [x2, #7]
    // 0xc71bdc: LoadField: d1 = r2->field_f
    //     0xc71bdc: ldur            d1, [x2, #0xf]
    // 0xc71be0: fadd            d2, d0, d1
    // 0xc71be4: stur            d2, [fp, #-0x38]
    // 0xc71be8: LoadField: d0 = r2->field_17
    //     0xc71be8: ldur            d0, [x2, #0x17]
    // 0xc71bec: stur            d0, [fp, #-0x30]
    // 0xc71bf0: r0 = Alignment()
    //     0xc71bf0: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xc71bf4: ldur            d0, [fp, #-0x38]
    // 0xc71bf8: StoreField: r0->field_7 = d0
    //     0xc71bf8: stur            d0, [x0, #7]
    // 0xc71bfc: ldur            d0, [fp, #-0x30]
    // 0xc71c00: StoreField: r0->field_f = d0
    //     0xc71c00: stur            d0, [x0, #0xf]
    // 0xc71c04: mov             x1, x0
    // 0xc71c08: ldur            x0, [fp, #-0x18]
    // 0xc71c0c: b               #0xc71c88
    // 0xc71c10: ldur            x3, [fp, #-8]
    // 0xc71c14: cmp             w3, NULL
    // 0xc71c18: b.eq            #0xc71d14
    // 0xc71c1c: LoadField: r0 = r3->field_7
    //     0xc71c1c: ldur            x0, [x3, #7]
    // 0xc71c20: cmp             x0, #0
    // 0xc71c24: b.gt            #0xc71c5c
    // 0xc71c28: LoadField: d0 = r2->field_7
    //     0xc71c28: ldur            d0, [x2, #7]
    // 0xc71c2c: fneg            d1, d0
    // 0xc71c30: stur            d1, [fp, #-0x38]
    // 0xc71c34: LoadField: d0 = r2->field_f
    //     0xc71c34: ldur            d0, [x2, #0xf]
    // 0xc71c38: stur            d0, [fp, #-0x30]
    // 0xc71c3c: r0 = Alignment()
    //     0xc71c3c: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xc71c40: ldur            d0, [fp, #-0x38]
    // 0xc71c44: StoreField: r0->field_7 = d0
    //     0xc71c44: stur            d0, [x0, #7]
    // 0xc71c48: ldur            d0, [fp, #-0x30]
    // 0xc71c4c: StoreField: r0->field_f = d0
    //     0xc71c4c: stur            d0, [x0, #0xf]
    // 0xc71c50: mov             x1, x0
    // 0xc71c54: ldur            x0, [fp, #-0x18]
    // 0xc71c58: b               #0xc71c88
    // 0xc71c5c: LoadField: d0 = r2->field_7
    //     0xc71c5c: ldur            d0, [x2, #7]
    // 0xc71c60: stur            d0, [fp, #-0x38]
    // 0xc71c64: LoadField: d1 = r2->field_f
    //     0xc71c64: ldur            d1, [x2, #0xf]
    // 0xc71c68: stur            d1, [fp, #-0x30]
    // 0xc71c6c: r0 = Alignment()
    //     0xc71c6c: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xc71c70: ldur            d0, [fp, #-0x38]
    // 0xc71c74: StoreField: r0->field_7 = d0
    //     0xc71c74: stur            d0, [x0, #7]
    // 0xc71c78: ldur            d0, [fp, #-0x30]
    // 0xc71c7c: StoreField: r0->field_f = d0
    //     0xc71c7c: stur            d0, [x0, #0xf]
    // 0xc71c80: mov             x1, x0
    // 0xc71c84: ldur            x0, [fp, #-0x18]
    // 0xc71c88: ldur            x16, [fp, #-0x10]
    // 0xc71c8c: stp             x16, x1, [SP, #-0x10]!
    // 0xc71c90: r0 = withinRect()
    //     0xc71c90: bl              #0xa75430  ; [package:flutter/src/painting/alignment.dart] Alignment::withinRect
    // 0xc71c94: add             SP, SP, #0x10
    // 0xc71c98: mov             x1, x0
    // 0xc71c9c: ldur            x0, [fp, #-0x18]
    // 0xc71ca0: stur            x1, [fp, #-0x10]
    // 0xc71ca4: LoadField: r2 = r0->field_7
    //     0xc71ca4: ldur            w2, [x0, #7]
    // 0xc71ca8: DecompressPointer r2
    //     0xc71ca8: add             x2, x2, HEAP, lsl #32
    // 0xc71cac: stur            x2, [fp, #-8]
    // 0xc71cb0: SaveReg r0
    //     0xc71cb0: str             x0, [SP, #-8]!
    // 0xc71cb4: r0 = _impliedStops()
    //     0xc71cb4: bl              #0xa752a8  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0xc71cb8: add             SP, SP, #8
    // 0xc71cbc: stur            x0, [fp, #-0x18]
    // 0xc71cc0: r0 = Gradient()
    //     0xc71cc0: bl              #0x68dbb8  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0xc71cc4: stur            x0, [fp, #-0x28]
    // 0xc71cc8: ldur            x16, [fp, #-0x20]
    // 0xc71ccc: stp             x16, x0, [SP, #-0x10]!
    // 0xc71cd0: ldur            x16, [fp, #-0x10]
    // 0xc71cd4: ldur            lr, [fp, #-8]
    // 0xc71cd8: stp             lr, x16, [SP, #-0x10]!
    // 0xc71cdc: ldur            x16, [fp, #-0x18]
    // 0xc71ce0: stp             NULL, x16, [SP, #-0x10]!
    // 0xc71ce4: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0xc71ce4: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0xc71ce8: r0 = Gradient.linear()
    //     0xc71ce8: bl              #0x68d0cc  ; [dart:ui] Gradient::Gradient.linear
    // 0xc71cec: add             SP, SP, #0x30
    // 0xc71cf0: ldur            x0, [fp, #-0x28]
    // 0xc71cf4: LeaveFrame
    //     0xc71cf4: mov             SP, fp
    //     0xc71cf8: ldp             fp, lr, [SP], #0x10
    // 0xc71cfc: ret
    //     0xc71cfc: ret             
    // 0xc71d00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc71d00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc71d04: b               #0xc719f4
    // 0xc71d08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc71d08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc71d0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc71d0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc71d10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc71d10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc71d14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc71d14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9d5b4, size: 0x1a4
    // 0xc9d5b4: EnterFrame
    //     0xc9d5b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc9d5b8: mov             fp, SP
    // 0xc9d5bc: CheckStackOverflow
    //     0xc9d5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9d5c0: cmp             SP, x16
    //     0xc9d5c4: b.ls            #0xc9d750
    // 0xc9d5c8: ldr             x1, [fp, #0x10]
    // 0xc9d5cc: cmp             w1, NULL
    // 0xc9d5d0: b.ne            #0xc9d5e4
    // 0xc9d5d4: r0 = false
    //     0xc9d5d4: add             x0, NULL, #0x30  ; false
    // 0xc9d5d8: LeaveFrame
    //     0xc9d5d8: mov             SP, fp
    //     0xc9d5dc: ldp             fp, lr, [SP], #0x10
    // 0xc9d5e0: ret
    //     0xc9d5e0: ret             
    // 0xc9d5e4: ldr             x2, [fp, #0x18]
    // 0xc9d5e8: cmp             w2, w1
    // 0xc9d5ec: b.ne            #0xc9d600
    // 0xc9d5f0: r0 = true
    //     0xc9d5f0: add             x0, NULL, #0x20  ; true
    // 0xc9d5f4: LeaveFrame
    //     0xc9d5f4: mov             SP, fp
    //     0xc9d5f8: ldp             fp, lr, [SP], #0x10
    // 0xc9d5fc: ret
    //     0xc9d5fc: ret             
    // 0xc9d600: r0 = 59
    //     0xc9d600: mov             x0, #0x3b
    // 0xc9d604: branchIfSmi(r1, 0xc9d610)
    //     0xc9d604: tbz             w1, #0, #0xc9d610
    // 0xc9d608: r0 = LoadClassIdInstr(r1)
    //     0xc9d608: ldur            x0, [x1, #-1]
    //     0xc9d60c: ubfx            x0, x0, #0xc, #0x14
    // 0xc9d610: SaveReg r1
    //     0xc9d610: str             x1, [SP, #-8]!
    // 0xc9d614: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9d614: mov             x17, #0x57c5
    //     0xc9d618: add             lr, x0, x17
    //     0xc9d61c: ldr             lr, [x21, lr, lsl #3]
    //     0xc9d620: blr             lr
    // 0xc9d624: add             SP, SP, #8
    // 0xc9d628: r1 = LoadClassIdInstr(r0)
    //     0xc9d628: ldur            x1, [x0, #-1]
    //     0xc9d62c: ubfx            x1, x1, #0xc, #0x14
    // 0xc9d630: r16 = LinearGradient
    //     0xc9d630: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2da90] Type: LinearGradient
    //     0xc9d634: ldr             x16, [x16, #0xa90]
    // 0xc9d638: stp             x16, x0, [SP, #-0x10]!
    // 0xc9d63c: mov             x0, x1
    // 0xc9d640: mov             lr, x0
    // 0xc9d644: ldr             lr, [x21, lr, lsl #3]
    // 0xc9d648: blr             lr
    // 0xc9d64c: add             SP, SP, #0x10
    // 0xc9d650: tbz             w0, #4, #0xc9d664
    // 0xc9d654: r0 = false
    //     0xc9d654: add             x0, NULL, #0x30  ; false
    // 0xc9d658: LeaveFrame
    //     0xc9d658: mov             SP, fp
    //     0xc9d65c: ldp             fp, lr, [SP], #0x10
    // 0xc9d660: ret
    //     0xc9d660: ret             
    // 0xc9d664: ldr             x0, [fp, #0x10]
    // 0xc9d668: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc9d668: mov             x1, #0x76
    //     0xc9d66c: tbz             w0, #0, #0xc9d67c
    //     0xc9d670: ldur            x1, [x0, #-1]
    //     0xc9d674: ubfx            x1, x1, #0xc, #0x14
    //     0xc9d678: lsl             x1, x1, #1
    // 0xc9d67c: r17 = 4194
    //     0xc9d67c: mov             x17, #0x1062
    // 0xc9d680: cmp             w1, w17
    // 0xc9d684: b.ne            #0xc9d740
    // 0xc9d688: ldr             x1, [fp, #0x18]
    // 0xc9d68c: LoadField: r2 = r0->field_13
    //     0xc9d68c: ldur            w2, [x0, #0x13]
    // 0xc9d690: DecompressPointer r2
    //     0xc9d690: add             x2, x2, HEAP, lsl #32
    // 0xc9d694: LoadField: r3 = r1->field_13
    //     0xc9d694: ldur            w3, [x1, #0x13]
    // 0xc9d698: DecompressPointer r3
    //     0xc9d698: add             x3, x3, HEAP, lsl #32
    // 0xc9d69c: stp             x3, x2, [SP, #-0x10]!
    // 0xc9d6a0: r0 = ==()
    //     0xc9d6a0: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xc9d6a4: add             SP, SP, #0x10
    // 0xc9d6a8: tbnz            w0, #4, #0xc9d740
    // 0xc9d6ac: ldr             x1, [fp, #0x18]
    // 0xc9d6b0: ldr             x0, [fp, #0x10]
    // 0xc9d6b4: LoadField: r2 = r0->field_17
    //     0xc9d6b4: ldur            w2, [x0, #0x17]
    // 0xc9d6b8: DecompressPointer r2
    //     0xc9d6b8: add             x2, x2, HEAP, lsl #32
    // 0xc9d6bc: LoadField: r3 = r1->field_17
    //     0xc9d6bc: ldur            w3, [x1, #0x17]
    // 0xc9d6c0: DecompressPointer r3
    //     0xc9d6c0: add             x3, x3, HEAP, lsl #32
    // 0xc9d6c4: stp             x3, x2, [SP, #-0x10]!
    // 0xc9d6c8: r0 = ==()
    //     0xc9d6c8: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xc9d6cc: add             SP, SP, #0x10
    // 0xc9d6d0: tbnz            w0, #4, #0xc9d740
    // 0xc9d6d4: ldr             x1, [fp, #0x18]
    // 0xc9d6d8: ldr             x0, [fp, #0x10]
    // 0xc9d6dc: LoadField: r2 = r0->field_7
    //     0xc9d6dc: ldur            w2, [x0, #7]
    // 0xc9d6e0: DecompressPointer r2
    //     0xc9d6e0: add             x2, x2, HEAP, lsl #32
    // 0xc9d6e4: LoadField: r3 = r1->field_7
    //     0xc9d6e4: ldur            w3, [x1, #7]
    // 0xc9d6e8: DecompressPointer r3
    //     0xc9d6e8: add             x3, x3, HEAP, lsl #32
    // 0xc9d6ec: r16 = <Color>
    //     0xc9d6ec: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc9d6f0: ldr             x16, [x16, #0x3f8]
    // 0xc9d6f4: stp             x2, x16, [SP, #-0x10]!
    // 0xc9d6f8: SaveReg r3
    //     0xc9d6f8: str             x3, [SP, #-8]!
    // 0xc9d6fc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc9d6fc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc9d700: r0 = listEquals()
    //     0xc9d700: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc9d704: add             SP, SP, #0x18
    // 0xc9d708: tbnz            w0, #4, #0xc9d740
    // 0xc9d70c: ldr             x1, [fp, #0x18]
    // 0xc9d710: ldr             x0, [fp, #0x10]
    // 0xc9d714: LoadField: r2 = r0->field_b
    //     0xc9d714: ldur            w2, [x0, #0xb]
    // 0xc9d718: DecompressPointer r2
    //     0xc9d718: add             x2, x2, HEAP, lsl #32
    // 0xc9d71c: LoadField: r0 = r1->field_b
    //     0xc9d71c: ldur            w0, [x1, #0xb]
    // 0xc9d720: DecompressPointer r0
    //     0xc9d720: add             x0, x0, HEAP, lsl #32
    // 0xc9d724: r16 = <double>
    //     0xc9d724: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc9d728: stp             x2, x16, [SP, #-0x10]!
    // 0xc9d72c: SaveReg r0
    //     0xc9d72c: str             x0, [SP, #-8]!
    // 0xc9d730: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc9d730: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc9d734: r0 = listEquals()
    //     0xc9d734: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc9d738: add             SP, SP, #0x18
    // 0xc9d73c: b               #0xc9d744
    // 0xc9d740: r0 = false
    //     0xc9d740: add             x0, NULL, #0x30  ; false
    // 0xc9d744: LeaveFrame
    //     0xc9d744: mov             SP, fp
    //     0xc9d748: ldp             fp, lr, [SP], #0x10
    // 0xc9d74c: ret
    //     0xc9d74c: ret             
    // 0xc9d750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9d750: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9d754: b               #0xc9d5c8
  }
  [closure] Color <anonymous closure>(dynamic, Color) {
    // ** addr: 0xcd504c, size: 0x5c
    // 0xcd504c: EnterFrame
    //     0xcd504c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd5050: mov             fp, SP
    // 0xcd5054: ldr             x0, [fp, #0x18]
    // 0xcd5058: LoadField: r1 = r0->field_17
    //     0xcd5058: ldur            w1, [x0, #0x17]
    // 0xcd505c: DecompressPointer r1
    //     0xcd505c: add             x1, x1, HEAP, lsl #32
    // 0xcd5060: CheckStackOverflow
    //     0xcd5060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd5064: cmp             SP, x16
    //     0xcd5068: b.ls            #0xcd509c
    // 0xcd506c: LoadField: r0 = r1->field_f
    //     0xcd506c: ldur            w0, [x1, #0xf]
    // 0xcd5070: DecompressPointer r0
    //     0xcd5070: add             x0, x0, HEAP, lsl #32
    // 0xcd5074: ldr             x16, [fp, #0x10]
    // 0xcd5078: stp             x16, NULL, [SP, #-0x10]!
    // 0xcd507c: SaveReg r0
    //     0xcd507c: str             x0, [SP, #-8]!
    // 0xcd5080: r0 = lerp()
    //     0xcd5080: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd5084: add             SP, SP, #0x18
    // 0xcd5088: cmp             w0, NULL
    // 0xcd508c: b.eq            #0xcd50a4
    // 0xcd5090: LeaveFrame
    //     0xcd5090: mov             SP, fp
    //     0xcd5094: ldp             fp, lr, [SP], #0x10
    // 0xcd5098: ret
    //     0xcd5098: ret             
    // 0xcd509c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd509c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd50a0: b               #0xcd506c
    // 0xcd50a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd50a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scale(/* No info */) {
    // ** addr: 0xcd50a8, size: 0x130
    // 0xcd50a8: EnterFrame
    //     0xcd50a8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd50ac: mov             fp, SP
    // 0xcd50b0: AllocStack(0x20)
    //     0xcd50b0: sub             SP, SP, #0x20
    // 0xcd50b4: CheckStackOverflow
    //     0xcd50b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd50b8: cmp             SP, x16
    //     0xcd50bc: b.ls            #0xcd51c0
    // 0xcd50c0: ldr             d0, [fp, #0x10]
    // 0xcd50c4: r0 = inline_Allocate_Double()
    //     0xcd50c4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd50c8: add             x0, x0, #0x10
    //     0xcd50cc: cmp             x1, x0
    //     0xcd50d0: b.ls            #0xcd51c8
    //     0xcd50d4: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd50d8: sub             x0, x0, #0xf
    //     0xcd50dc: mov             x1, #0xd108
    //     0xcd50e0: movk            x1, #3, lsl #16
    //     0xcd50e4: stur            x1, [x0, #-1]
    // 0xcd50e8: StoreField: r0->field_7 = d0
    //     0xcd50e8: stur            d0, [x0, #7]
    // 0xcd50ec: stur            x0, [fp, #-8]
    // 0xcd50f0: r1 = 1
    //     0xcd50f0: mov             x1, #1
    // 0xcd50f4: r0 = AllocateContext()
    //     0xcd50f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd50f8: mov             x1, x0
    // 0xcd50fc: ldur            x0, [fp, #-8]
    // 0xcd5100: StoreField: r1->field_f = r0
    //     0xcd5100: stur            w0, [x1, #0xf]
    // 0xcd5104: ldr             x0, [fp, #0x18]
    // 0xcd5108: LoadField: r3 = r0->field_13
    //     0xcd5108: ldur            w3, [x0, #0x13]
    // 0xcd510c: DecompressPointer r3
    //     0xcd510c: add             x3, x3, HEAP, lsl #32
    // 0xcd5110: stur            x3, [fp, #-0x18]
    // 0xcd5114: LoadField: r4 = r0->field_17
    //     0xcd5114: ldur            w4, [x0, #0x17]
    // 0xcd5118: DecompressPointer r4
    //     0xcd5118: add             x4, x4, HEAP, lsl #32
    // 0xcd511c: stur            x4, [fp, #-0x10]
    // 0xcd5120: LoadField: r5 = r0->field_7
    //     0xcd5120: ldur            w5, [x0, #7]
    // 0xcd5124: DecompressPointer r5
    //     0xcd5124: add             x5, x5, HEAP, lsl #32
    // 0xcd5128: mov             x2, x1
    // 0xcd512c: stur            x5, [fp, #-8]
    // 0xcd5130: r1 = Function '<anonymous closure>':.
    //     0xcd5130: add             x1, PP, #0x37, lsl #12  ; [pp+0x37208] AnonymousClosure: (0xcd504c), in [package:flutter/src/painting/gradient.dart] LinearGradient::scale (0xcd50a8)
    //     0xcd5134: ldr             x1, [x1, #0x208]
    // 0xcd5138: r0 = AllocateClosure()
    //     0xcd5138: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd513c: r16 = <Color>
    //     0xcd513c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xcd5140: ldr             x16, [x16, #0x3f8]
    // 0xcd5144: ldur            lr, [fp, #-8]
    // 0xcd5148: stp             lr, x16, [SP, #-0x10]!
    // 0xcd514c: SaveReg r0
    //     0xcd514c: str             x0, [SP, #-8]!
    // 0xcd5150: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcd5150: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcd5154: r0 = map()
    //     0xcd5154: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xcd5158: add             SP, SP, #0x18
    // 0xcd515c: SaveReg r0
    //     0xcd515c: str             x0, [SP, #-8]!
    // 0xcd5160: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcd5160: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcd5164: r0 = toList()
    //     0xcd5164: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xcd5168: add             SP, SP, #8
    // 0xcd516c: mov             x1, x0
    // 0xcd5170: ldr             x0, [fp, #0x18]
    // 0xcd5174: stur            x1, [fp, #-0x20]
    // 0xcd5178: LoadField: r2 = r0->field_b
    //     0xcd5178: ldur            w2, [x0, #0xb]
    // 0xcd517c: DecompressPointer r2
    //     0xcd517c: add             x2, x2, HEAP, lsl #32
    // 0xcd5180: stur            x2, [fp, #-8]
    // 0xcd5184: r0 = LinearGradient()
    //     0xcd5184: bl              #0x9a5fc0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0xcd5188: ldur            x1, [fp, #-0x18]
    // 0xcd518c: StoreField: r0->field_13 = r1
    //     0xcd518c: stur            w1, [x0, #0x13]
    // 0xcd5190: ldur            x1, [fp, #-0x10]
    // 0xcd5194: StoreField: r0->field_17 = r1
    //     0xcd5194: stur            w1, [x0, #0x17]
    // 0xcd5198: r1 = Instance_TileMode
    //     0xcd5198: add             x1, PP, #0x27, lsl #12  ; [pp+0x271d8] Obj!TileMode@b675b1
    //     0xcd519c: ldr             x1, [x1, #0x1d8]
    // 0xcd51a0: StoreField: r0->field_1b = r1
    //     0xcd51a0: stur            w1, [x0, #0x1b]
    // 0xcd51a4: ldur            x1, [fp, #-0x20]
    // 0xcd51a8: StoreField: r0->field_7 = r1
    //     0xcd51a8: stur            w1, [x0, #7]
    // 0xcd51ac: ldur            x1, [fp, #-8]
    // 0xcd51b0: StoreField: r0->field_b = r1
    //     0xcd51b0: stur            w1, [x0, #0xb]
    // 0xcd51b4: LeaveFrame
    //     0xcd51b4: mov             SP, fp
    //     0xcd51b8: ldp             fp, lr, [SP], #0x10
    // 0xcd51bc: ret
    //     0xcd51bc: ret             
    // 0xcd51c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd51c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd51c4: b               #0xcd50c0
    // 0xcd51c8: SaveReg d0
    //     0xcd51c8: str             q0, [SP, #-0x10]!
    // 0xcd51cc: r0 = AllocateDouble()
    //     0xcd51cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd51d0: RestoreReg d0
    //     0xcd51d0: ldr             q0, [SP], #0x10
    // 0xcd51d4: b               #0xcd50e8
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0xcd5744, size: 0x44
    // 0xcd5744: EnterFrame
    //     0xcd5744: stp             fp, lr, [SP, #-0x10]!
    //     0xcd5748: mov             fp, SP
    // 0xcd574c: CheckStackOverflow
    //     0xcd574c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd5750: cmp             SP, x16
    //     0xcd5754: b.ls            #0xcd5780
    // 0xcd5758: ldr             x16, [fp, #0x20]
    // 0xcd575c: ldr             lr, [fp, #0x18]
    // 0xcd5760: stp             lr, x16, [SP, #-0x10]!
    // 0xcd5764: ldr             d0, [fp, #0x10]
    // 0xcd5768: SaveReg d0
    //     0xcd5768: str             d0, [SP, #-8]!
    // 0xcd576c: r0 = lerp()
    //     0xcd576c: bl              #0xcd5788  ; [package:flutter/src/painting/gradient.dart] LinearGradient::lerp
    // 0xcd5770: add             SP, SP, #0x18
    // 0xcd5774: LeaveFrame
    //     0xcd5774: mov             SP, fp
    //     0xcd5778: ldp             fp, lr, [SP], #0x10
    // 0xcd577c: ret
    //     0xcd577c: ret             
    // 0xcd5780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd5780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd5784: b               #0xcd5758
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xcd5788, size: 0x1e8
    // 0xcd5788: EnterFrame
    //     0xcd5788: stp             fp, lr, [SP, #-0x10]!
    //     0xcd578c: mov             fp, SP
    // 0xcd5790: AllocStack(0x28)
    //     0xcd5790: sub             SP, SP, #0x28
    // 0xcd5794: CheckStackOverflow
    //     0xcd5794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd5798: cmp             SP, x16
    //     0xcd579c: b.ls            #0xcd595c
    // 0xcd57a0: ldr             x0, [fp, #0x20]
    // 0xcd57a4: cmp             w0, NULL
    // 0xcd57a8: b.ne            #0xcd57c8
    // 0xcd57ac: ldr             x1, [fp, #0x18]
    // 0xcd57b0: cmp             w1, NULL
    // 0xcd57b4: b.ne            #0xcd57cc
    // 0xcd57b8: r0 = Null
    //     0xcd57b8: mov             x0, NULL
    // 0xcd57bc: LeaveFrame
    //     0xcd57bc: mov             SP, fp
    //     0xcd57c0: ldp             fp, lr, [SP], #0x10
    // 0xcd57c4: ret
    //     0xcd57c4: ret             
    // 0xcd57c8: ldr             x1, [fp, #0x18]
    // 0xcd57cc: cmp             w0, NULL
    // 0xcd57d0: b.ne            #0xcd57fc
    // 0xcd57d4: ldr             d0, [fp, #0x10]
    // 0xcd57d8: cmp             w1, NULL
    // 0xcd57dc: b.eq            #0xcd5964
    // 0xcd57e0: SaveReg r1
    //     0xcd57e0: str             x1, [SP, #-8]!
    // 0xcd57e4: SaveReg d0
    //     0xcd57e4: str             d0, [SP, #-8]!
    // 0xcd57e8: r0 = scale()
    //     0xcd57e8: bl              #0xcd50a8  ; [package:flutter/src/painting/gradient.dart] LinearGradient::scale
    // 0xcd57ec: add             SP, SP, #0x10
    // 0xcd57f0: LeaveFrame
    //     0xcd57f0: mov             SP, fp
    //     0xcd57f4: ldp             fp, lr, [SP], #0x10
    // 0xcd57f8: ret
    //     0xcd57f8: ret             
    // 0xcd57fc: ldr             d0, [fp, #0x10]
    // 0xcd5800: cmp             w1, NULL
    // 0xcd5804: b.ne            #0xcd582c
    // 0xcd5808: d1 = 1.000000
    //     0xcd5808: fmov            d1, #1.00000000
    // 0xcd580c: fsub            d2, d1, d0
    // 0xcd5810: SaveReg r0
    //     0xcd5810: str             x0, [SP, #-8]!
    // 0xcd5814: SaveReg d2
    //     0xcd5814: str             d2, [SP, #-8]!
    // 0xcd5818: r0 = scale()
    //     0xcd5818: bl              #0xcd50a8  ; [package:flutter/src/painting/gradient.dart] LinearGradient::scale
    // 0xcd581c: add             SP, SP, #0x10
    // 0xcd5820: LeaveFrame
    //     0xcd5820: mov             SP, fp
    //     0xcd5824: ldp             fp, lr, [SP], #0x10
    // 0xcd5828: ret
    //     0xcd5828: ret             
    // 0xcd582c: LoadField: r2 = r0->field_7
    //     0xcd582c: ldur            w2, [x0, #7]
    // 0xcd5830: DecompressPointer r2
    //     0xcd5830: add             x2, x2, HEAP, lsl #32
    // 0xcd5834: stur            x2, [fp, #-8]
    // 0xcd5838: SaveReg r0
    //     0xcd5838: str             x0, [SP, #-8]!
    // 0xcd583c: r0 = _impliedStops()
    //     0xcd583c: bl              #0xa752a8  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0xcd5840: add             SP, SP, #8
    // 0xcd5844: mov             x1, x0
    // 0xcd5848: ldr             x0, [fp, #0x18]
    // 0xcd584c: stur            x1, [fp, #-0x18]
    // 0xcd5850: LoadField: r2 = r0->field_7
    //     0xcd5850: ldur            w2, [x0, #7]
    // 0xcd5854: DecompressPointer r2
    //     0xcd5854: add             x2, x2, HEAP, lsl #32
    // 0xcd5858: stur            x2, [fp, #-0x10]
    // 0xcd585c: SaveReg r0
    //     0xcd585c: str             x0, [SP, #-8]!
    // 0xcd5860: r0 = _impliedStops()
    //     0xcd5860: bl              #0xa752a8  ; [package:flutter/src/painting/gradient.dart] Gradient::_impliedStops
    // 0xcd5864: add             SP, SP, #8
    // 0xcd5868: ldur            x16, [fp, #-8]
    // 0xcd586c: ldur            lr, [fp, #-0x18]
    // 0xcd5870: stp             lr, x16, [SP, #-0x10]!
    // 0xcd5874: ldur            x16, [fp, #-0x10]
    // 0xcd5878: stp             x0, x16, [SP, #-0x10]!
    // 0xcd587c: ldr             d0, [fp, #0x10]
    // 0xcd5880: SaveReg d0
    //     0xcd5880: str             d0, [SP, #-8]!
    // 0xcd5884: r0 = _interpolateColorsAndStops()
    //     0xcd5884: bl              #0xcd5970  ; [package:flutter/src/painting/gradient.dart] ::_interpolateColorsAndStops
    // 0xcd5888: add             SP, SP, #0x28
    // 0xcd588c: mov             x1, x0
    // 0xcd5890: ldr             x0, [fp, #0x20]
    // 0xcd5894: stur            x1, [fp, #-8]
    // 0xcd5898: LoadField: r2 = r0->field_13
    //     0xcd5898: ldur            w2, [x0, #0x13]
    // 0xcd589c: DecompressPointer r2
    //     0xcd589c: add             x2, x2, HEAP, lsl #32
    // 0xcd58a0: ldr             x3, [fp, #0x18]
    // 0xcd58a4: LoadField: r4 = r3->field_13
    //     0xcd58a4: ldur            w4, [x3, #0x13]
    // 0xcd58a8: DecompressPointer r4
    //     0xcd58a8: add             x4, x4, HEAP, lsl #32
    // 0xcd58ac: stp             x4, x2, [SP, #-0x10]!
    // 0xcd58b0: ldr             d0, [fp, #0x10]
    // 0xcd58b4: SaveReg d0
    //     0xcd58b4: str             d0, [SP, #-8]!
    // 0xcd58b8: r0 = lerp()
    //     0xcd58b8: bl              #0xbefd44  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0xcd58bc: add             SP, SP, #0x18
    // 0xcd58c0: stur            x0, [fp, #-0x10]
    // 0xcd58c4: cmp             w0, NULL
    // 0xcd58c8: b.eq            #0xcd5968
    // 0xcd58cc: ldr             x1, [fp, #0x20]
    // 0xcd58d0: LoadField: r2 = r1->field_17
    //     0xcd58d0: ldur            w2, [x1, #0x17]
    // 0xcd58d4: DecompressPointer r2
    //     0xcd58d4: add             x2, x2, HEAP, lsl #32
    // 0xcd58d8: ldr             x1, [fp, #0x18]
    // 0xcd58dc: LoadField: r3 = r1->field_17
    //     0xcd58dc: ldur            w3, [x1, #0x17]
    // 0xcd58e0: DecompressPointer r3
    //     0xcd58e0: add             x3, x3, HEAP, lsl #32
    // 0xcd58e4: stp             x3, x2, [SP, #-0x10]!
    // 0xcd58e8: ldr             d0, [fp, #0x10]
    // 0xcd58ec: SaveReg d0
    //     0xcd58ec: str             d0, [SP, #-8]!
    // 0xcd58f0: r0 = lerp()
    //     0xcd58f0: bl              #0xbefd44  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0xcd58f4: add             SP, SP, #0x18
    // 0xcd58f8: stur            x0, [fp, #-0x28]
    // 0xcd58fc: cmp             w0, NULL
    // 0xcd5900: b.eq            #0xcd596c
    // 0xcd5904: ldur            x1, [fp, #-8]
    // 0xcd5908: LoadField: r2 = r1->field_7
    //     0xcd5908: ldur            w2, [x1, #7]
    // 0xcd590c: DecompressPointer r2
    //     0xcd590c: add             x2, x2, HEAP, lsl #32
    // 0xcd5910: stur            x2, [fp, #-0x20]
    // 0xcd5914: LoadField: r3 = r1->field_b
    //     0xcd5914: ldur            w3, [x1, #0xb]
    // 0xcd5918: DecompressPointer r3
    //     0xcd5918: add             x3, x3, HEAP, lsl #32
    // 0xcd591c: stur            x3, [fp, #-0x18]
    // 0xcd5920: r0 = LinearGradient()
    //     0xcd5920: bl              #0x9a5fc0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0xcd5924: ldur            x1, [fp, #-0x10]
    // 0xcd5928: StoreField: r0->field_13 = r1
    //     0xcd5928: stur            w1, [x0, #0x13]
    // 0xcd592c: ldur            x1, [fp, #-0x28]
    // 0xcd5930: StoreField: r0->field_17 = r1
    //     0xcd5930: stur            w1, [x0, #0x17]
    // 0xcd5934: r1 = Instance_TileMode
    //     0xcd5934: add             x1, PP, #0x27, lsl #12  ; [pp+0x271d8] Obj!TileMode@b675b1
    //     0xcd5938: ldr             x1, [x1, #0x1d8]
    // 0xcd593c: StoreField: r0->field_1b = r1
    //     0xcd593c: stur            w1, [x0, #0x1b]
    // 0xcd5940: ldur            x1, [fp, #-0x20]
    // 0xcd5944: StoreField: r0->field_7 = r1
    //     0xcd5944: stur            w1, [x0, #7]
    // 0xcd5948: ldur            x1, [fp, #-0x18]
    // 0xcd594c: StoreField: r0->field_b = r1
    //     0xcd594c: stur            w1, [x0, #0xb]
    // 0xcd5950: LeaveFrame
    //     0xcd5950: mov             SP, fp
    //     0xcd5954: ldp             fp, lr, [SP], #0x10
    // 0xcd5958: ret
    //     0xcd5958: ret             
    // 0xcd595c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd595c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd5960: b               #0xcd57a0
    // 0xcd5964: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd5964: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd5968: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd5968: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd596c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd596c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0xcd60a8, size: 0x44
    // 0xcd60a8: EnterFrame
    //     0xcd60a8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd60ac: mov             fp, SP
    // 0xcd60b0: CheckStackOverflow
    //     0xcd60b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd60b4: cmp             SP, x16
    //     0xcd60b8: b.ls            #0xcd60e4
    // 0xcd60bc: ldr             x16, [fp, #0x18]
    // 0xcd60c0: ldr             lr, [fp, #0x20]
    // 0xcd60c4: stp             lr, x16, [SP, #-0x10]!
    // 0xcd60c8: ldr             d0, [fp, #0x10]
    // 0xcd60cc: SaveReg d0
    //     0xcd60cc: str             d0, [SP, #-8]!
    // 0xcd60d0: r0 = lerp()
    //     0xcd60d0: bl              #0xcd5788  ; [package:flutter/src/painting/gradient.dart] LinearGradient::lerp
    // 0xcd60d4: add             SP, SP, #0x18
    // 0xcd60d8: LeaveFrame
    //     0xcd60d8: mov             SP, fp
    //     0xcd60dc: ldp             fp, lr, [SP], #0x10
    // 0xcd60e0: ret
    //     0xcd60e0: ret             
    // 0xcd60e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd60e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd60e8: b               #0xcd60bc
  }
}

// class id: 2099, size: 0x10, field offset: 0x8
class _ColorsAndStops extends Object {
}

// lib: , url: package:flutter/src/painting/box_border.dart

// class id: 1049350, size: 0x8
class :: {
}

// class id: 2185, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class BoxBorder extends ShapeBorder {

  _ getInnerPath(/* No info */) {
    // ** addr: 0x71a700, size: 0xb0
    // 0x71a700: EnterFrame
    //     0x71a700: stp             fp, lr, [SP, #-0x10]!
    //     0x71a704: mov             fp, SP
    // 0x71a708: AllocStack(0x18)
    //     0x71a708: sub             SP, SP, #0x18
    // 0x71a70c: SetupParameters(BoxBorder this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0x71a70c: mov             x0, x4
    //     0x71a710: ldur            w1, [x0, #0x13]
    //     0x71a714: add             x1, x1, HEAP, lsl #32
    //     0x71a718: sub             x0, x1, #4
    //     0x71a71c: add             x1, fp, w0, sxtw #2
    //     0x71a720: ldr             x1, [x1, #0x18]
    //     0x71a724: stur            x1, [fp, #-0x10]
    //     0x71a728: add             x2, fp, w0, sxtw #2
    //     0x71a72c: ldr             x2, [x2, #0x10]
    //     0x71a730: stur            x2, [fp, #-8]
    // 0x71a734: CheckStackOverflow
    //     0x71a734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71a738: cmp             SP, x16
    //     0x71a73c: b.ls            #0x71a7a8
    // 0x71a740: r0 = Path()
    //     0x71a740: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x71a744: stur            x0, [fp, #-0x18]
    // 0x71a748: SaveReg r0
    //     0x71a748: str             x0, [SP, #-8]!
    // 0x71a74c: r0 = _constructor()
    //     0x71a74c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x71a750: add             SP, SP, #8
    // 0x71a754: ldur            x0, [fp, #-0x10]
    // 0x71a758: r1 = LoadClassIdInstr(r0)
    //     0x71a758: ldur            x1, [x0, #-1]
    //     0x71a75c: ubfx            x1, x1, #0xc, #0x14
    // 0x71a760: SaveReg r0
    //     0x71a760: str             x0, [SP, #-8]!
    // 0x71a764: mov             x0, x1
    // 0x71a768: r0 = GDT[cid_x0 + -0xe39]()
    //     0x71a768: sub             lr, x0, #0xe39
    //     0x71a76c: ldr             lr, [x21, lr, lsl #3]
    //     0x71a770: blr             lr
    // 0x71a774: add             SP, SP, #8
    // 0x71a778: ldur            x16, [fp, #-8]
    // 0x71a77c: stp             x16, x0, [SP, #-0x10]!
    // 0x71a780: r0 = deflateRect()
    //     0x71a780: bl              #0x65ae60  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0x71a784: add             SP, SP, #0x10
    // 0x71a788: ldur            x16, [fp, #-0x18]
    // 0x71a78c: stp             x0, x16, [SP, #-0x10]!
    // 0x71a790: r0 = addRect()
    //     0x71a790: bl              #0x71a7b0  ; [dart:ui] Path::addRect
    // 0x71a794: add             SP, SP, #0x10
    // 0x71a798: ldur            x0, [fp, #-0x18]
    // 0x71a79c: LeaveFrame
    //     0x71a79c: mov             SP, fp
    //     0x71a7a0: ldp             fp, lr, [SP], #0x10
    // 0x71a7a4: ret
    //     0x71a7a4: ret             
    // 0x71a7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a7a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a7ac: b               #0x71a740
  }
  static _ _paintUniformBorderWithCircle(/* No info */) {
    // ** addr: 0xbd2e94, size: 0xa4
    // 0xbd2e94: EnterFrame
    //     0xbd2e94: stp             fp, lr, [SP, #-0x10]!
    //     0xbd2e98: mov             fp, SP
    // 0xbd2e9c: AllocStack(0x10)
    //     0xbd2e9c: sub             SP, SP, #0x10
    // 0xbd2ea0: CheckStackOverflow
    //     0xbd2ea0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd2ea4: cmp             SP, x16
    //     0xbd2ea8: b.ls            #0xbd2f30
    // 0xbd2eac: ldr             x16, [fp, #0x18]
    // 0xbd2eb0: SaveReg r16
    //     0xbd2eb0: str             x16, [SP, #-8]!
    // 0xbd2eb4: r0 = shortestSide()
    //     0xbd2eb4: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0xbd2eb8: add             SP, SP, #8
    // 0xbd2ebc: ldr             x0, [fp, #0x10]
    // 0xbd2ec0: LoadField: d1 = r0->field_b
    //     0xbd2ec0: ldur            d1, [x0, #0xb]
    // 0xbd2ec4: LoadField: d2 = r0->field_17
    //     0xbd2ec4: ldur            d2, [x0, #0x17]
    // 0xbd2ec8: fmul            d3, d1, d2
    // 0xbd2ecc: fadd            d1, d0, d3
    // 0xbd2ed0: d0 = 2.000000
    //     0xbd2ed0: fmov            d0, #2.00000000
    // 0xbd2ed4: fdiv            d2, d1, d0
    // 0xbd2ed8: stur            d2, [fp, #-0x10]
    // 0xbd2edc: ldr             x16, [fp, #0x18]
    // 0xbd2ee0: SaveReg r16
    //     0xbd2ee0: str             x16, [SP, #-8]!
    // 0xbd2ee4: r0 = center()
    //     0xbd2ee4: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xbd2ee8: add             SP, SP, #8
    // 0xbd2eec: stur            x0, [fp, #-8]
    // 0xbd2ef0: ldr             x16, [fp, #0x10]
    // 0xbd2ef4: SaveReg r16
    //     0xbd2ef4: str             x16, [SP, #-8]!
    // 0xbd2ef8: r0 = toPaint()
    //     0xbd2ef8: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd2efc: add             SP, SP, #8
    // 0xbd2f00: ldr             x16, [fp, #0x20]
    // 0xbd2f04: ldur            lr, [fp, #-8]
    // 0xbd2f08: stp             lr, x16, [SP, #-0x10]!
    // 0xbd2f0c: ldur            d0, [fp, #-0x10]
    // 0xbd2f10: SaveReg d0
    //     0xbd2f10: str             d0, [SP, #-8]!
    // 0xbd2f14: SaveReg r0
    //     0xbd2f14: str             x0, [SP, #-8]!
    // 0xbd2f18: r0 = drawCircle()
    //     0xbd2f18: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0xbd2f1c: add             SP, SP, #0x20
    // 0xbd2f20: r0 = Null
    //     0xbd2f20: mov             x0, NULL
    // 0xbd2f24: LeaveFrame
    //     0xbd2f24: mov             SP, fp
    //     0xbd2f28: ldp             fp, lr, [SP], #0x10
    // 0xbd2f2c: ret
    //     0xbd2f2c: ret             
    // 0xbd2f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd2f30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd2f34: b               #0xbd2eac
  }
  static _ _paintUniformBorderWithRectangle(/* No info */) {
    // ** addr: 0xbd314c, size: 0x88
    // 0xbd314c: EnterFrame
    //     0xbd314c: stp             fp, lr, [SP, #-0x10]!
    //     0xbd3150: mov             fp, SP
    // 0xbd3154: AllocStack(0x8)
    //     0xbd3154: sub             SP, SP, #8
    // 0xbd3158: d0 = 2.000000
    //     0xbd3158: fmov            d0, #2.00000000
    // 0xbd315c: CheckStackOverflow
    //     0xbd315c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd3160: cmp             SP, x16
    //     0xbd3164: b.ls            #0xbd31cc
    // 0xbd3168: ldr             x0, [fp, #0x10]
    // 0xbd316c: LoadField: d1 = r0->field_b
    //     0xbd316c: ldur            d1, [x0, #0xb]
    // 0xbd3170: LoadField: d2 = r0->field_17
    //     0xbd3170: ldur            d2, [x0, #0x17]
    // 0xbd3174: fmul            d3, d1, d2
    // 0xbd3178: fdiv            d1, d3, d0
    // 0xbd317c: ldr             x16, [fp, #0x18]
    // 0xbd3180: SaveReg r16
    //     0xbd3180: str             x16, [SP, #-8]!
    // 0xbd3184: SaveReg d1
    //     0xbd3184: str             d1, [SP, #-8]!
    // 0xbd3188: r0 = inflate()
    //     0xbd3188: bl              #0x5d1480  ; [dart:ui] Rect::inflate
    // 0xbd318c: add             SP, SP, #0x10
    // 0xbd3190: stur            x0, [fp, #-8]
    // 0xbd3194: ldr             x16, [fp, #0x10]
    // 0xbd3198: SaveReg r16
    //     0xbd3198: str             x16, [SP, #-8]!
    // 0xbd319c: r0 = toPaint()
    //     0xbd319c: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd31a0: add             SP, SP, #8
    // 0xbd31a4: ldr             x16, [fp, #0x20]
    // 0xbd31a8: ldur            lr, [fp, #-8]
    // 0xbd31ac: stp             lr, x16, [SP, #-0x10]!
    // 0xbd31b0: SaveReg r0
    //     0xbd31b0: str             x0, [SP, #-8]!
    // 0xbd31b4: r0 = drawRect()
    //     0xbd31b4: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xbd31b8: add             SP, SP, #0x18
    // 0xbd31bc: r0 = Null
    //     0xbd31bc: mov             x0, NULL
    // 0xbd31c0: LeaveFrame
    //     0xbd31c0: mov             SP, fp
    //     0xbd31c4: ldp             fp, lr, [SP], #0x10
    // 0xbd31c8: ret
    //     0xbd31c8: ret             
    // 0xbd31cc: r0 = StackOverflowSharedWithFPURegs()
    //     0xbd31cc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbd31d0: b               #0xbd3168
  }
  static _ _paintUniformBorderWithRadius(/* No info */) {
    // ** addr: 0xbd31d4, size: 0x1cc
    // 0xbd31d4: EnterFrame
    //     0xbd31d4: stp             fp, lr, [SP, #-0x10]!
    //     0xbd31d8: mov             fp, SP
    // 0xbd31dc: AllocStack(0x28)
    //     0xbd31dc: sub             SP, SP, #0x28
    // 0xbd31e0: CheckStackOverflow
    //     0xbd31e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd31e4: cmp             SP, x16
    //     0xbd31e8: b.ls            #0xbd3398
    // 0xbd31ec: r16 = 112
    //     0xbd31ec: mov             x16, #0x70
    // 0xbd31f0: stp             x16, NULL, [SP, #-0x10]!
    // 0xbd31f4: r0 = ByteData()
    //     0xbd31f4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xbd31f8: add             SP, SP, #0x10
    // 0xbd31fc: stur            x0, [fp, #-8]
    // 0xbd3200: r0 = Paint()
    //     0xbd3200: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xbd3204: mov             x1, x0
    // 0xbd3208: ldur            x0, [fp, #-8]
    // 0xbd320c: stur            x1, [fp, #-0x10]
    // 0xbd3210: StoreField: r1->field_7 = r0
    //     0xbd3210: stur            w0, [x1, #7]
    // 0xbd3214: ldr             x2, [fp, #0x18]
    // 0xbd3218: LoadField: r3 = r2->field_7
    //     0xbd3218: ldur            w3, [x2, #7]
    // 0xbd321c: DecompressPointer r3
    //     0xbd321c: add             x3, x3, HEAP, lsl #32
    // 0xbd3220: r4 = LoadClassIdInstr(r3)
    //     0xbd3220: ldur            x4, [x3, #-1]
    //     0xbd3224: ubfx            x4, x4, #0xc, #0x14
    // 0xbd3228: lsl             x4, x4, #1
    // 0xbd322c: r17 = 10124
    //     0xbd322c: mov             x17, #0x278c
    // 0xbd3230: cmp             w4, w17
    // 0xbd3234: b.gt            #0xbd3244
    // 0xbd3238: r17 = 10122
    //     0xbd3238: mov             x17, #0x278a
    // 0xbd323c: cmp             w4, w17
    // 0xbd3240: b.ge            #0xbd325c
    // 0xbd3244: r17 = 10114
    //     0xbd3244: mov             x17, #0x2782
    // 0xbd3248: cmp             w4, w17
    // 0xbd324c: b.eq            #0xbd325c
    // 0xbd3250: r17 = 10118
    //     0xbd3250: mov             x17, #0x2786
    // 0xbd3254: cmp             w4, w17
    // 0xbd3258: b.ne            #0xbd3268
    // 0xbd325c: LoadField: r4 = r3->field_7
    //     0xbd325c: ldur            x4, [x3, #7]
    // 0xbd3260: mov             x3, x4
    // 0xbd3264: b               #0xbd3274
    // 0xbd3268: LoadField: r4 = r3->field_f
    //     0xbd3268: ldur            w4, [x3, #0xf]
    // 0xbd326c: DecompressPointer r4
    //     0xbd326c: add             x4, x4, HEAP, lsl #32
    // 0xbd3270: LoadField: r3 = r4->field_7
    //     0xbd3270: ldur            x3, [x4, #7]
    // 0xbd3274: d0 = 0.000000
    //     0xbd3274: eor             v0.16b, v0.16b, v0.16b
    // 0xbd3278: eor             x4, x3, #0xff000000
    // 0xbd327c: LoadField: r3 = r0->field_17
    //     0xbd327c: ldur            w3, [x0, #0x17]
    // 0xbd3280: DecompressPointer r3
    //     0xbd3280: add             x3, x3, HEAP, lsl #32
    // 0xbd3284: sxtw            x4, w4
    // 0xbd3288: LoadField: r0 = r3->field_7
    //     0xbd3288: ldur            x0, [x3, #7]
    // 0xbd328c: str             w4, [x0, #4]
    // 0xbd3290: LoadField: d1 = r2->field_b
    //     0xbd3290: ldur            d1, [x2, #0xb]
    // 0xbd3294: stur            d1, [fp, #-0x20]
    // 0xbd3298: fcmp            d1, d0
    // 0xbd329c: b.vs            #0xbd32ec
    // 0xbd32a0: b.ne            #0xbd32ec
    // 0xbd32a4: r0 = 1
    //     0xbd32a4: mov             x0, #1
    // 0xbd32a8: LoadField: r2 = r3->field_7
    //     0xbd32a8: ldur            x2, [x3, #7]
    // 0xbd32ac: str             w0, [x2, #0xc]
    // 0xbd32b0: fcvt            s1, d0
    // 0xbd32b4: LoadField: r0 = r3->field_7
    //     0xbd32b4: ldur            x0, [x3, #7]
    // 0xbd32b8: str             s1, [x0, #0x10]
    // 0xbd32bc: ldr             x16, [fp, #0x10]
    // 0xbd32c0: ldr             lr, [fp, #0x20]
    // 0xbd32c4: stp             lr, x16, [SP, #-0x10]!
    // 0xbd32c8: r0 = toRRect()
    //     0xbd32c8: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbd32cc: add             SP, SP, #0x10
    // 0xbd32d0: ldr             x16, [fp, #0x28]
    // 0xbd32d4: stp             x0, x16, [SP, #-0x10]!
    // 0xbd32d8: ldur            x16, [fp, #-0x10]
    // 0xbd32dc: SaveReg r16
    //     0xbd32dc: str             x16, [SP, #-8]!
    // 0xbd32e0: r0 = drawRRect()
    //     0xbd32e0: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xbd32e4: add             SP, SP, #0x18
    // 0xbd32e8: b               #0xbd3388
    // 0xbd32ec: ldr             x16, [fp, #0x10]
    // 0xbd32f0: ldr             lr, [fp, #0x20]
    // 0xbd32f4: stp             lr, x16, [SP, #-0x10]!
    // 0xbd32f8: r0 = toRRect()
    //     0xbd32f8: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbd32fc: add             SP, SP, #0x10
    // 0xbd3300: mov             x1, x0
    // 0xbd3304: ldr             x0, [fp, #0x18]
    // 0xbd3308: stur            x1, [fp, #-8]
    // 0xbd330c: LoadField: d0 = r0->field_17
    //     0xbd330c: ldur            d0, [x0, #0x17]
    // 0xbd3310: d1 = 1.000000
    //     0xbd3310: fmov            d1, #1.00000000
    // 0xbd3314: fadd            d2, d1, d0
    // 0xbd3318: stur            d2, [fp, #-0x28]
    // 0xbd331c: d0 = 2.000000
    //     0xbd331c: fmov            d0, #2.00000000
    // 0xbd3320: fdiv            d3, d2, d0
    // 0xbd3324: fsub            d4, d1, d3
    // 0xbd3328: ldur            d1, [fp, #-0x20]
    // 0xbd332c: fmul            d3, d1, d4
    // 0xbd3330: SaveReg r1
    //     0xbd3330: str             x1, [SP, #-8]!
    // 0xbd3334: SaveReg d3
    //     0xbd3334: str             d3, [SP, #-8]!
    // 0xbd3338: r0 = deflate()
    //     0xbd3338: bl              #0x6705bc  ; [dart:ui] RRect::deflate
    // 0xbd333c: add             SP, SP, #0x10
    // 0xbd3340: ldur            d1, [fp, #-0x20]
    // 0xbd3344: ldur            d0, [fp, #-0x28]
    // 0xbd3348: stur            x0, [fp, #-0x18]
    // 0xbd334c: fmul            d2, d1, d0
    // 0xbd3350: d0 = 2.000000
    //     0xbd3350: fmov            d0, #2.00000000
    // 0xbd3354: fdiv            d1, d2, d0
    // 0xbd3358: ldur            x16, [fp, #-8]
    // 0xbd335c: SaveReg r16
    //     0xbd335c: str             x16, [SP, #-8]!
    // 0xbd3360: SaveReg d1
    //     0xbd3360: str             d1, [SP, #-8]!
    // 0xbd3364: r0 = inflate()
    //     0xbd3364: bl              #0x65ffe4  ; [dart:ui] RRect::inflate
    // 0xbd3368: add             SP, SP, #0x10
    // 0xbd336c: ldr             x16, [fp, #0x28]
    // 0xbd3370: stp             x0, x16, [SP, #-0x10]!
    // 0xbd3374: ldur            x16, [fp, #-0x18]
    // 0xbd3378: ldur            lr, [fp, #-0x10]
    // 0xbd337c: stp             lr, x16, [SP, #-0x10]!
    // 0xbd3380: r0 = drawDRRect()
    //     0xbd3380: bl              #0x6701ec  ; [dart:ui] Canvas::drawDRRect
    // 0xbd3384: add             SP, SP, #0x20
    // 0xbd3388: r0 = Null
    //     0xbd3388: mov             x0, NULL
    // 0xbd338c: LeaveFrame
    //     0xbd338c: mov             SP, fp
    //     0xbd3390: ldp             fp, lr, [SP], #0x10
    // 0xbd3394: ret
    //     0xbd3394: ret             
    // 0xbd3398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd3398: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd339c: b               #0xbd31ec
  }
}

// class id: 2187, size: 0x18, field offset: 0x8
//   const constructor, 
class Border extends BoxBorder {

  BorderSide field_8;
  BorderSide field_c;
  BorderSide field_10;
  BorderSide field_14;

  _ lerpTo(/* No info */) {
    // ** addr: 0x70de40, size: 0x80
    // 0x70de40: EnterFrame
    //     0x70de40: stp             fp, lr, [SP, #-0x10]!
    //     0x70de44: mov             fp, SP
    // 0x70de48: CheckStackOverflow
    //     0x70de48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70de4c: cmp             SP, x16
    //     0x70de50: b.ls            #0x70deb8
    // 0x70de54: ldr             x0, [fp, #0x18]
    // 0x70de58: r1 = LoadClassIdInstr(r0)
    //     0x70de58: ldur            x1, [x0, #-1]
    //     0x70de5c: ubfx            x1, x1, #0xc, #0x14
    // 0x70de60: lsl             x1, x1, #1
    // 0x70de64: r17 = 4374
    //     0x70de64: mov             x17, #0x1116
    // 0x70de68: cmp             w1, w17
    // 0x70de6c: b.ne            #0x70de94
    // 0x70de70: ldr             d0, [fp, #0x10]
    // 0x70de74: ldr             x16, [fp, #0x20]
    // 0x70de78: stp             x0, x16, [SP, #-0x10]!
    // 0x70de7c: SaveReg d0
    //     0x70de7c: str             d0, [SP, #-8]!
    // 0x70de80: r0 = lerp()
    //     0x70de80: bl              #0x70df28  ; [package:flutter/src/painting/box_border.dart] Border::lerp
    // 0x70de84: add             SP, SP, #0x18
    // 0x70de88: LeaveFrame
    //     0x70de88: mov             SP, fp
    //     0x70de8c: ldp             fp, lr, [SP], #0x10
    // 0x70de90: ret
    //     0x70de90: ret             
    // 0x70de94: ldr             d0, [fp, #0x10]
    // 0x70de98: ldr             x16, [fp, #0x20]
    // 0x70de9c: stp             x0, x16, [SP, #-0x10]!
    // 0x70dea0: SaveReg d0
    //     0x70dea0: str             d0, [SP, #-8]!
    // 0x70dea4: r0 = lerpTo()
    //     0x70dea4: bl              #0x70f880  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x70dea8: add             SP, SP, #0x18
    // 0x70deac: LeaveFrame
    //     0x70deac: mov             SP, fp
    //     0x70deb0: ldp             fp, lr, [SP], #0x10
    // 0x70deb4: ret
    //     0x70deb4: ret             
    // 0x70deb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70deb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70debc: b               #0x70de54
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x70df28, size: 0x1a0
    // 0x70df28: EnterFrame
    //     0x70df28: stp             fp, lr, [SP, #-0x10]!
    //     0x70df2c: mov             fp, SP
    // 0x70df30: AllocStack(0x20)
    //     0x70df30: sub             SP, SP, #0x20
    // 0x70df34: CheckStackOverflow
    //     0x70df34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70df38: cmp             SP, x16
    //     0x70df3c: b.ls            #0x70e0bc
    // 0x70df40: ldr             x0, [fp, #0x20]
    // 0x70df44: cmp             w0, NULL
    // 0x70df48: b.ne            #0x70df68
    // 0x70df4c: ldr             x1, [fp, #0x18]
    // 0x70df50: cmp             w1, NULL
    // 0x70df54: b.ne            #0x70df6c
    // 0x70df58: r0 = Null
    //     0x70df58: mov             x0, NULL
    // 0x70df5c: LeaveFrame
    //     0x70df5c: mov             SP, fp
    //     0x70df60: ldp             fp, lr, [SP], #0x10
    // 0x70df64: ret
    //     0x70df64: ret             
    // 0x70df68: ldr             x1, [fp, #0x18]
    // 0x70df6c: cmp             w0, NULL
    // 0x70df70: b.ne            #0x70df9c
    // 0x70df74: ldr             d0, [fp, #0x10]
    // 0x70df78: cmp             w1, NULL
    // 0x70df7c: b.eq            #0x70e0c4
    // 0x70df80: SaveReg r1
    //     0x70df80: str             x1, [SP, #-8]!
    // 0x70df84: SaveReg d0
    //     0x70df84: str             d0, [SP, #-8]!
    // 0x70df88: r0 = scale()
    //     0x70df88: bl              #0xcf82f8  ; [package:flutter/src/painting/box_border.dart] Border::scale
    // 0x70df8c: add             SP, SP, #0x10
    // 0x70df90: LeaveFrame
    //     0x70df90: mov             SP, fp
    //     0x70df94: ldp             fp, lr, [SP], #0x10
    // 0x70df98: ret
    //     0x70df98: ret             
    // 0x70df9c: ldr             d0, [fp, #0x10]
    // 0x70dfa0: cmp             w1, NULL
    // 0x70dfa4: b.ne            #0x70dfcc
    // 0x70dfa8: d1 = 1.000000
    //     0x70dfa8: fmov            d1, #1.00000000
    // 0x70dfac: fsub            d2, d1, d0
    // 0x70dfb0: SaveReg r0
    //     0x70dfb0: str             x0, [SP, #-8]!
    // 0x70dfb4: SaveReg d2
    //     0x70dfb4: str             d2, [SP, #-8]!
    // 0x70dfb8: r0 = scale()
    //     0x70dfb8: bl              #0xcf82f8  ; [package:flutter/src/painting/box_border.dart] Border::scale
    // 0x70dfbc: add             SP, SP, #0x10
    // 0x70dfc0: LeaveFrame
    //     0x70dfc0: mov             SP, fp
    //     0x70dfc4: ldp             fp, lr, [SP], #0x10
    // 0x70dfc8: ret
    //     0x70dfc8: ret             
    // 0x70dfcc: LoadField: r2 = r0->field_7
    //     0x70dfcc: ldur            w2, [x0, #7]
    // 0x70dfd0: DecompressPointer r2
    //     0x70dfd0: add             x2, x2, HEAP, lsl #32
    // 0x70dfd4: LoadField: r3 = r1->field_7
    //     0x70dfd4: ldur            w3, [x1, #7]
    // 0x70dfd8: DecompressPointer r3
    //     0x70dfd8: add             x3, x3, HEAP, lsl #32
    // 0x70dfdc: stp             x3, x2, [SP, #-0x10]!
    // 0x70dfe0: SaveReg d0
    //     0x70dfe0: str             d0, [SP, #-8]!
    // 0x70dfe4: r0 = lerp()
    //     0x70dfe4: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70dfe8: add             SP, SP, #0x18
    // 0x70dfec: mov             x1, x0
    // 0x70dff0: ldr             x0, [fp, #0x20]
    // 0x70dff4: stur            x1, [fp, #-8]
    // 0x70dff8: LoadField: r2 = r0->field_b
    //     0x70dff8: ldur            w2, [x0, #0xb]
    // 0x70dffc: DecompressPointer r2
    //     0x70dffc: add             x2, x2, HEAP, lsl #32
    // 0x70e000: ldr             x3, [fp, #0x18]
    // 0x70e004: LoadField: r4 = r3->field_b
    //     0x70e004: ldur            w4, [x3, #0xb]
    // 0x70e008: DecompressPointer r4
    //     0x70e008: add             x4, x4, HEAP, lsl #32
    // 0x70e00c: stp             x4, x2, [SP, #-0x10]!
    // 0x70e010: ldr             d0, [fp, #0x10]
    // 0x70e014: SaveReg d0
    //     0x70e014: str             d0, [SP, #-8]!
    // 0x70e018: r0 = lerp()
    //     0x70e018: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70e01c: add             SP, SP, #0x18
    // 0x70e020: mov             x1, x0
    // 0x70e024: ldr             x0, [fp, #0x20]
    // 0x70e028: stur            x1, [fp, #-0x10]
    // 0x70e02c: LoadField: r2 = r0->field_f
    //     0x70e02c: ldur            w2, [x0, #0xf]
    // 0x70e030: DecompressPointer r2
    //     0x70e030: add             x2, x2, HEAP, lsl #32
    // 0x70e034: ldr             x3, [fp, #0x18]
    // 0x70e038: LoadField: r4 = r3->field_f
    //     0x70e038: ldur            w4, [x3, #0xf]
    // 0x70e03c: DecompressPointer r4
    //     0x70e03c: add             x4, x4, HEAP, lsl #32
    // 0x70e040: stp             x4, x2, [SP, #-0x10]!
    // 0x70e044: ldr             d0, [fp, #0x10]
    // 0x70e048: SaveReg d0
    //     0x70e048: str             d0, [SP, #-8]!
    // 0x70e04c: r0 = lerp()
    //     0x70e04c: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70e050: add             SP, SP, #0x18
    // 0x70e054: mov             x1, x0
    // 0x70e058: ldr             x0, [fp, #0x20]
    // 0x70e05c: stur            x1, [fp, #-0x18]
    // 0x70e060: LoadField: r2 = r0->field_13
    //     0x70e060: ldur            w2, [x0, #0x13]
    // 0x70e064: DecompressPointer r2
    //     0x70e064: add             x2, x2, HEAP, lsl #32
    // 0x70e068: ldr             x0, [fp, #0x18]
    // 0x70e06c: LoadField: r3 = r0->field_13
    //     0x70e06c: ldur            w3, [x0, #0x13]
    // 0x70e070: DecompressPointer r3
    //     0x70e070: add             x3, x3, HEAP, lsl #32
    // 0x70e074: stp             x3, x2, [SP, #-0x10]!
    // 0x70e078: ldr             d0, [fp, #0x10]
    // 0x70e07c: SaveReg d0
    //     0x70e07c: str             d0, [SP, #-8]!
    // 0x70e080: r0 = lerp()
    //     0x70e080: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70e084: add             SP, SP, #0x18
    // 0x70e088: stur            x0, [fp, #-0x20]
    // 0x70e08c: r0 = Border()
    //     0x70e08c: bl              #0x70e0c8  ; AllocateBorderStub -> Border (size=0x18)
    // 0x70e090: ldur            x1, [fp, #-8]
    // 0x70e094: StoreField: r0->field_7 = r1
    //     0x70e094: stur            w1, [x0, #7]
    // 0x70e098: ldur            x1, [fp, #-0x10]
    // 0x70e09c: StoreField: r0->field_b = r1
    //     0x70e09c: stur            w1, [x0, #0xb]
    // 0x70e0a0: ldur            x1, [fp, #-0x18]
    // 0x70e0a4: StoreField: r0->field_f = r1
    //     0x70e0a4: stur            w1, [x0, #0xf]
    // 0x70e0a8: ldur            x1, [fp, #-0x20]
    // 0x70e0ac: StoreField: r0->field_13 = r1
    //     0x70e0ac: stur            w1, [x0, #0x13]
    // 0x70e0b0: LeaveFrame
    //     0x70e0b0: mov             SP, fp
    //     0x70e0b4: ldp             fp, lr, [SP], #0x10
    // 0x70e0b8: ret
    //     0x70e0b8: ret             
    // 0x70e0bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70e0bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70e0c0: b               #0x70df40
    // 0x70e0c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x70e0c4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x70fa90, size: 0x90
    // 0x70fa90: EnterFrame
    //     0x70fa90: stp             fp, lr, [SP, #-0x10]!
    //     0x70fa94: mov             fp, SP
    // 0x70fa98: CheckStackOverflow
    //     0x70fa98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70fa9c: cmp             SP, x16
    //     0x70faa0: b.ls            #0x70fb18
    // 0x70faa4: ldr             x0, [fp, #0x18]
    // 0x70faa8: r1 = LoadClassIdInstr(r0)
    //     0x70faa8: ldur            x1, [x0, #-1]
    //     0x70faac: ubfx            x1, x1, #0xc, #0x14
    // 0x70fab0: lsl             x1, x1, #1
    // 0x70fab4: r17 = 4374
    //     0x70fab4: mov             x17, #0x1116
    // 0x70fab8: cmp             w1, w17
    // 0x70fabc: b.ne            #0x70fae4
    // 0x70fac0: ldr             d0, [fp, #0x10]
    // 0x70fac4: ldr             x16, [fp, #0x20]
    // 0x70fac8: stp             x16, x0, [SP, #-0x10]!
    // 0x70facc: SaveReg d0
    //     0x70facc: str             d0, [SP, #-8]!
    // 0x70fad0: r0 = lerp()
    //     0x70fad0: bl              #0x70df28  ; [package:flutter/src/painting/box_border.dart] Border::lerp
    // 0x70fad4: add             SP, SP, #0x18
    // 0x70fad8: LeaveFrame
    //     0x70fad8: mov             SP, fp
    //     0x70fadc: ldp             fp, lr, [SP], #0x10
    // 0x70fae0: ret
    //     0x70fae0: ret             
    // 0x70fae4: ldr             d0, [fp, #0x10]
    // 0x70fae8: cmp             w0, NULL
    // 0x70faec: b.ne            #0x70fb08
    // 0x70faf0: ldr             x16, [fp, #0x20]
    // 0x70faf4: SaveReg r16
    //     0x70faf4: str             x16, [SP, #-8]!
    // 0x70faf8: SaveReg d0
    //     0x70faf8: str             d0, [SP, #-8]!
    // 0x70fafc: r0 = scale()
    //     0x70fafc: bl              #0xcf82f8  ; [package:flutter/src/painting/box_border.dart] Border::scale
    // 0x70fb00: add             SP, SP, #0x10
    // 0x70fb04: b               #0x70fb0c
    // 0x70fb08: r0 = Null
    //     0x70fb08: mov             x0, NULL
    // 0x70fb0c: LeaveFrame
    //     0x70fb0c: mov             SP, fp
    //     0x70fb10: ldp             fp, lr, [SP], #0x10
    // 0x70fb14: ret
    //     0x70fb14: ret             
    // 0x70fb18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70fb18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70fb1c: b               #0x70faa4
  }
  factory _ Border.all(/* No info */) {
    // ** addr: 0x898df8, size: 0x108
    // 0x898df8: EnterFrame
    //     0x898df8: stp             fp, lr, [SP, #-0x10]!
    //     0x898dfc: mov             fp, SP
    // 0x898e00: AllocStack(0x18)
    //     0x898e00: sub             SP, SP, #0x18
    // 0x898e04: SetupParameters({dynamic color = Instance_Color /* r3, fp-0x8 */, _Double width = 1.000000 /* d0, fp-0x18 */})
    //     0x898e04: mov             x0, x4
    //     0x898e08: ldur            w1, [x0, #0x13]
    //     0x898e0c: add             x1, x1, HEAP, lsl #32
    //     0x898e10: ldur            w2, [x0, #0x1f]
    //     0x898e14: add             x2, x2, HEAP, lsl #32
    //     0x898e18: add             x16, PP, #0xd, lsl #12  ; [pp+0xdae8] "color"
    //     0x898e1c: ldr             x16, [x16, #0xae8]
    //     0x898e20: cmp             w2, w16
    //     0x898e24: b.ne            #0x898e48
    //     0x898e28: ldur            w2, [x0, #0x23]
    //     0x898e2c: add             x2, x2, HEAP, lsl #32
    //     0x898e30: sub             w3, w1, w2
    //     0x898e34: add             x2, fp, w3, sxtw #2
    //     0x898e38: ldr             x2, [x2, #8]
    //     0x898e3c: mov             x3, x2
    //     0x898e40: mov             x2, #1
    //     0x898e44: b               #0x898e54
    //     0x898e48: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x898e4c: ldr             x3, [x3, #0xf38]
    //     0x898e50: mov             x2, #0
    //     0x898e54: stur            x3, [fp, #-8]
    //     0x898e58: lsl             x4, x2, #1
    //     0x898e5c: lsl             w2, w4, #1
    //     0x898e60: add             w4, w2, #8
    //     0x898e64: add             x16, x0, w4, sxtw #1
    //     0x898e68: ldur            w5, [x16, #0xf]
    //     0x898e6c: add             x5, x5, HEAP, lsl #32
    //     0x898e70: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb30] "width"
    //     0x898e74: ldr             x16, [x16, #0xb30]
    //     0x898e78: cmp             w5, w16
    //     0x898e7c: b.ne            #0x898ea4
    //     0x898e80: add             w4, w2, #0xa
    //     0x898e84: add             x16, x0, w4, sxtw #1
    //     0x898e88: ldur            w2, [x16, #0xf]
    //     0x898e8c: add             x2, x2, HEAP, lsl #32
    //     0x898e90: sub             w0, w1, w2
    //     0x898e94: add             x1, fp, w0, sxtw #2
    //     0x898e98: ldr             x1, [x1, #8]
    //     0x898e9c: ldur            d0, [x1, #7]
    //     0x898ea0: b               #0x898ea8
    //     0x898ea4: fmov            d0, #1.00000000
    //     0x898ea8: stur            d0, [fp, #-0x18]
    // 0x898eac: r0 = BorderSide()
    //     0x898eac: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x898eb0: mov             x1, x0
    // 0x898eb4: ldur            x0, [fp, #-8]
    // 0x898eb8: stur            x1, [fp, #-0x10]
    // 0x898ebc: StoreField: r1->field_7 = r0
    //     0x898ebc: stur            w0, [x1, #7]
    // 0x898ec0: ldur            d0, [fp, #-0x18]
    // 0x898ec4: StoreField: r1->field_b = d0
    //     0x898ec4: stur            d0, [x1, #0xb]
    // 0x898ec8: r0 = Instance_BorderStyle
    //     0x898ec8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x898ecc: ldr             x0, [x0, #0xbd0]
    // 0x898ed0: StoreField: r1->field_13 = r0
    //     0x898ed0: stur            w0, [x1, #0x13]
    // 0x898ed4: d0 = -1.000000
    //     0x898ed4: fmov            d0, #-1.00000000
    // 0x898ed8: StoreField: r1->field_17 = d0
    //     0x898ed8: stur            d0, [x1, #0x17]
    // 0x898edc: r0 = Border()
    //     0x898edc: bl              #0x70e0c8  ; AllocateBorderStub -> Border (size=0x18)
    // 0x898ee0: ldur            x1, [fp, #-0x10]
    // 0x898ee4: StoreField: r0->field_7 = r1
    //     0x898ee4: stur            w1, [x0, #7]
    // 0x898ee8: StoreField: r0->field_b = r1
    //     0x898ee8: stur            w1, [x0, #0xb]
    // 0x898eec: StoreField: r0->field_f = r1
    //     0x898eec: stur            w1, [x0, #0xf]
    // 0x898ef0: StoreField: r0->field_13 = r1
    //     0x898ef0: stur            w1, [x0, #0x13]
    // 0x898ef4: LeaveFrame
    //     0x898ef4: mov             SP, fp
    //     0x898ef8: ldp             fp, lr, [SP], #0x10
    // 0x898efc: ret
    //     0x898efc: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xada644, size: 0x520
    // 0xada644: EnterFrame
    //     0xada644: stp             fp, lr, [SP, #-0x10]!
    //     0xada648: mov             fp, SP
    // 0xada64c: AllocStack(0x18)
    //     0xada64c: sub             SP, SP, #0x18
    // 0xada650: CheckStackOverflow
    //     0xada650: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xada654: cmp             SP, x16
    //     0xada658: b.ls            #0xadab4c
    // 0xada65c: ldr             x16, [fp, #0x10]
    // 0xada660: SaveReg r16
    //     0xada660: str             x16, [SP, #-8]!
    // 0xada664: r0 = isUniform()
    //     0xada664: bl              #0xadab64  ; [package:flutter/src/painting/box_border.dart] Border::isUniform
    // 0xada668: add             SP, SP, #8
    // 0xada66c: tbnz            w0, #4, #0xada6c8
    // 0xada670: ldr             x0, [fp, #0x10]
    // 0xada674: r1 = Null
    //     0xada674: mov             x1, NULL
    // 0xada678: r2 = 8
    //     0xada678: mov             x2, #8
    // 0xada67c: r0 = AllocateArray()
    //     0xada67c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada680: r17 = "Border"
    //     0xada680: add             x17, PP, #0x29, lsl #12  ; [pp+0x29430] "Border"
    //     0xada684: ldr             x17, [x17, #0x430]
    // 0xada688: StoreField: r0->field_f = r17
    //     0xada688: stur            w17, [x0, #0xf]
    // 0xada68c: r17 = ".all("
    //     0xada68c: add             x17, PP, #0x29, lsl #12  ; [pp+0x29438] ".all("
    //     0xada690: ldr             x17, [x17, #0x438]
    // 0xada694: StoreField: r0->field_13 = r17
    //     0xada694: stur            w17, [x0, #0x13]
    // 0xada698: ldr             x1, [fp, #0x10]
    // 0xada69c: LoadField: r2 = r1->field_7
    //     0xada69c: ldur            w2, [x1, #7]
    // 0xada6a0: DecompressPointer r2
    //     0xada6a0: add             x2, x2, HEAP, lsl #32
    // 0xada6a4: StoreField: r0->field_17 = r2
    //     0xada6a4: stur            w2, [x0, #0x17]
    // 0xada6a8: r17 = ")"
    //     0xada6a8: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xada6ac: StoreField: r0->field_1b = r17
    //     0xada6ac: stur            w17, [x0, #0x1b]
    // 0xada6b0: SaveReg r0
    //     0xada6b0: str             x0, [SP, #-8]!
    // 0xada6b4: r0 = _interpolate()
    //     0xada6b4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada6b8: add             SP, SP, #8
    // 0xada6bc: LeaveFrame
    //     0xada6bc: mov             SP, fp
    //     0xada6c0: ldp             fp, lr, [SP], #0x10
    // 0xada6c4: ret
    //     0xada6c4: ret             
    // 0xada6c8: ldr             x1, [fp, #0x10]
    // 0xada6cc: r16 = <String>
    //     0xada6cc: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xada6d0: stp             xzr, x16, [SP, #-0x10]!
    // 0xada6d4: r0 = _GrowableList()
    //     0xada6d4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xada6d8: add             SP, SP, #0x10
    // 0xada6dc: mov             x1, x0
    // 0xada6e0: ldr             x0, [fp, #0x10]
    // 0xada6e4: stur            x1, [fp, #-0x10]
    // 0xada6e8: LoadField: r2 = r0->field_7
    //     0xada6e8: ldur            w2, [x0, #7]
    // 0xada6ec: DecompressPointer r2
    //     0xada6ec: add             x2, x2, HEAP, lsl #32
    // 0xada6f0: stur            x2, [fp, #-8]
    // 0xada6f4: r16 = Instance_BorderSide
    //     0xada6f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xada6f8: ldr             x16, [x16, #0x2f0]
    // 0xada6fc: stp             x16, x2, [SP, #-0x10]!
    // 0xada700: r0 = ==()
    //     0xada700: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xada704: add             SP, SP, #0x10
    // 0xada708: tbz             w0, #4, #0xada7d8
    // 0xada70c: ldur            x0, [fp, #-0x10]
    // 0xada710: ldur            x3, [fp, #-8]
    // 0xada714: r1 = Null
    //     0xada714: mov             x1, NULL
    // 0xada718: r2 = 4
    //     0xada718: mov             x2, #4
    // 0xada71c: r0 = AllocateArray()
    //     0xada71c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada720: r17 = "top: "
    //     0xada720: add             x17, PP, #0x29, lsl #12  ; [pp+0x29440] "top: "
    //     0xada724: ldr             x17, [x17, #0x440]
    // 0xada728: StoreField: r0->field_f = r17
    //     0xada728: stur            w17, [x0, #0xf]
    // 0xada72c: ldur            x1, [fp, #-8]
    // 0xada730: StoreField: r0->field_13 = r1
    //     0xada730: stur            w1, [x0, #0x13]
    // 0xada734: SaveReg r0
    //     0xada734: str             x0, [SP, #-8]!
    // 0xada738: r0 = _interpolate()
    //     0xada738: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada73c: add             SP, SP, #8
    // 0xada740: mov             x1, x0
    // 0xada744: ldur            x0, [fp, #-0x10]
    // 0xada748: stur            x1, [fp, #-0x18]
    // 0xada74c: LoadField: r2 = r0->field_b
    //     0xada74c: ldur            w2, [x0, #0xb]
    // 0xada750: DecompressPointer r2
    //     0xada750: add             x2, x2, HEAP, lsl #32
    // 0xada754: stur            x2, [fp, #-8]
    // 0xada758: LoadField: r3 = r0->field_f
    //     0xada758: ldur            w3, [x0, #0xf]
    // 0xada75c: DecompressPointer r3
    //     0xada75c: add             x3, x3, HEAP, lsl #32
    // 0xada760: LoadField: r4 = r3->field_b
    //     0xada760: ldur            w4, [x3, #0xb]
    // 0xada764: DecompressPointer r4
    //     0xada764: add             x4, x4, HEAP, lsl #32
    // 0xada768: cmp             w2, w4
    // 0xada76c: b.ne            #0xada77c
    // 0xada770: SaveReg r0
    //     0xada770: str             x0, [SP, #-8]!
    // 0xada774: r0 = _growToNextCapacity()
    //     0xada774: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xada778: add             SP, SP, #8
    // 0xada77c: ldur            x2, [fp, #-0x10]
    // 0xada780: ldur            x0, [fp, #-8]
    // 0xada784: r3 = LoadInt32Instr(r0)
    //     0xada784: sbfx            x3, x0, #1, #0x1f
    // 0xada788: add             x0, x3, #1
    // 0xada78c: lsl             x1, x0, #1
    // 0xada790: StoreField: r2->field_b = r1
    //     0xada790: stur            w1, [x2, #0xb]
    // 0xada794: mov             x1, x3
    // 0xada798: cmp             x1, x0
    // 0xada79c: b.hs            #0xadab54
    // 0xada7a0: LoadField: r1 = r2->field_f
    //     0xada7a0: ldur            w1, [x2, #0xf]
    // 0xada7a4: DecompressPointer r1
    //     0xada7a4: add             x1, x1, HEAP, lsl #32
    // 0xada7a8: ldur            x0, [fp, #-0x18]
    // 0xada7ac: ArrayStore: r1[r3] = r0  ; List_4
    //     0xada7ac: add             x25, x1, x3, lsl #2
    //     0xada7b0: add             x25, x25, #0xf
    //     0xada7b4: str             w0, [x25]
    //     0xada7b8: tbz             w0, #0, #0xada7d4
    //     0xada7bc: ldurb           w16, [x1, #-1]
    //     0xada7c0: ldurb           w17, [x0, #-1]
    //     0xada7c4: and             x16, x17, x16, lsr #2
    //     0xada7c8: tst             x16, HEAP, lsr #32
    //     0xada7cc: b.eq            #0xada7d4
    //     0xada7d0: bl              #0xd67e5c
    // 0xada7d4: b               #0xada7dc
    // 0xada7d8: ldur            x2, [fp, #-0x10]
    // 0xada7dc: ldr             x0, [fp, #0x10]
    // 0xada7e0: LoadField: r1 = r0->field_b
    //     0xada7e0: ldur            w1, [x0, #0xb]
    // 0xada7e4: DecompressPointer r1
    //     0xada7e4: add             x1, x1, HEAP, lsl #32
    // 0xada7e8: stur            x1, [fp, #-8]
    // 0xada7ec: r16 = Instance_BorderSide
    //     0xada7ec: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xada7f0: ldr             x16, [x16, #0x2f0]
    // 0xada7f4: stp             x16, x1, [SP, #-0x10]!
    // 0xada7f8: r0 = ==()
    //     0xada7f8: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xada7fc: add             SP, SP, #0x10
    // 0xada800: tbz             w0, #4, #0xada8d0
    // 0xada804: ldur            x0, [fp, #-0x10]
    // 0xada808: ldur            x3, [fp, #-8]
    // 0xada80c: r1 = Null
    //     0xada80c: mov             x1, NULL
    // 0xada810: r2 = 4
    //     0xada810: mov             x2, #4
    // 0xada814: r0 = AllocateArray()
    //     0xada814: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada818: r17 = "right: "
    //     0xada818: add             x17, PP, #0x29, lsl #12  ; [pp+0x29448] "right: "
    //     0xada81c: ldr             x17, [x17, #0x448]
    // 0xada820: StoreField: r0->field_f = r17
    //     0xada820: stur            w17, [x0, #0xf]
    // 0xada824: ldur            x1, [fp, #-8]
    // 0xada828: StoreField: r0->field_13 = r1
    //     0xada828: stur            w1, [x0, #0x13]
    // 0xada82c: SaveReg r0
    //     0xada82c: str             x0, [SP, #-8]!
    // 0xada830: r0 = _interpolate()
    //     0xada830: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada834: add             SP, SP, #8
    // 0xada838: mov             x1, x0
    // 0xada83c: ldur            x0, [fp, #-0x10]
    // 0xada840: stur            x1, [fp, #-0x18]
    // 0xada844: LoadField: r2 = r0->field_b
    //     0xada844: ldur            w2, [x0, #0xb]
    // 0xada848: DecompressPointer r2
    //     0xada848: add             x2, x2, HEAP, lsl #32
    // 0xada84c: stur            x2, [fp, #-8]
    // 0xada850: LoadField: r3 = r0->field_f
    //     0xada850: ldur            w3, [x0, #0xf]
    // 0xada854: DecompressPointer r3
    //     0xada854: add             x3, x3, HEAP, lsl #32
    // 0xada858: LoadField: r4 = r3->field_b
    //     0xada858: ldur            w4, [x3, #0xb]
    // 0xada85c: DecompressPointer r4
    //     0xada85c: add             x4, x4, HEAP, lsl #32
    // 0xada860: cmp             w2, w4
    // 0xada864: b.ne            #0xada874
    // 0xada868: SaveReg r0
    //     0xada868: str             x0, [SP, #-8]!
    // 0xada86c: r0 = _growToNextCapacity()
    //     0xada86c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xada870: add             SP, SP, #8
    // 0xada874: ldur            x2, [fp, #-0x10]
    // 0xada878: ldur            x0, [fp, #-8]
    // 0xada87c: r3 = LoadInt32Instr(r0)
    //     0xada87c: sbfx            x3, x0, #1, #0x1f
    // 0xada880: add             x0, x3, #1
    // 0xada884: lsl             x1, x0, #1
    // 0xada888: StoreField: r2->field_b = r1
    //     0xada888: stur            w1, [x2, #0xb]
    // 0xada88c: mov             x1, x3
    // 0xada890: cmp             x1, x0
    // 0xada894: b.hs            #0xadab58
    // 0xada898: LoadField: r1 = r2->field_f
    //     0xada898: ldur            w1, [x2, #0xf]
    // 0xada89c: DecompressPointer r1
    //     0xada89c: add             x1, x1, HEAP, lsl #32
    // 0xada8a0: ldur            x0, [fp, #-0x18]
    // 0xada8a4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xada8a4: add             x25, x1, x3, lsl #2
    //     0xada8a8: add             x25, x25, #0xf
    //     0xada8ac: str             w0, [x25]
    //     0xada8b0: tbz             w0, #0, #0xada8cc
    //     0xada8b4: ldurb           w16, [x1, #-1]
    //     0xada8b8: ldurb           w17, [x0, #-1]
    //     0xada8bc: and             x16, x17, x16, lsr #2
    //     0xada8c0: tst             x16, HEAP, lsr #32
    //     0xada8c4: b.eq            #0xada8cc
    //     0xada8c8: bl              #0xd67e5c
    // 0xada8cc: b               #0xada8d4
    // 0xada8d0: ldur            x2, [fp, #-0x10]
    // 0xada8d4: ldr             x0, [fp, #0x10]
    // 0xada8d8: LoadField: r1 = r0->field_f
    //     0xada8d8: ldur            w1, [x0, #0xf]
    // 0xada8dc: DecompressPointer r1
    //     0xada8dc: add             x1, x1, HEAP, lsl #32
    // 0xada8e0: stur            x1, [fp, #-8]
    // 0xada8e4: r16 = Instance_BorderSide
    //     0xada8e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xada8e8: ldr             x16, [x16, #0x2f0]
    // 0xada8ec: stp             x16, x1, [SP, #-0x10]!
    // 0xada8f0: r0 = ==()
    //     0xada8f0: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xada8f4: add             SP, SP, #0x10
    // 0xada8f8: tbz             w0, #4, #0xada9c8
    // 0xada8fc: ldur            x0, [fp, #-0x10]
    // 0xada900: ldur            x3, [fp, #-8]
    // 0xada904: r1 = Null
    //     0xada904: mov             x1, NULL
    // 0xada908: r2 = 4
    //     0xada908: mov             x2, #4
    // 0xada90c: r0 = AllocateArray()
    //     0xada90c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada910: r17 = "bottom: "
    //     0xada910: add             x17, PP, #0x29, lsl #12  ; [pp+0x29450] "bottom: "
    //     0xada914: ldr             x17, [x17, #0x450]
    // 0xada918: StoreField: r0->field_f = r17
    //     0xada918: stur            w17, [x0, #0xf]
    // 0xada91c: ldur            x1, [fp, #-8]
    // 0xada920: StoreField: r0->field_13 = r1
    //     0xada920: stur            w1, [x0, #0x13]
    // 0xada924: SaveReg r0
    //     0xada924: str             x0, [SP, #-8]!
    // 0xada928: r0 = _interpolate()
    //     0xada928: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada92c: add             SP, SP, #8
    // 0xada930: mov             x1, x0
    // 0xada934: ldur            x0, [fp, #-0x10]
    // 0xada938: stur            x1, [fp, #-0x18]
    // 0xada93c: LoadField: r2 = r0->field_b
    //     0xada93c: ldur            w2, [x0, #0xb]
    // 0xada940: DecompressPointer r2
    //     0xada940: add             x2, x2, HEAP, lsl #32
    // 0xada944: stur            x2, [fp, #-8]
    // 0xada948: LoadField: r3 = r0->field_f
    //     0xada948: ldur            w3, [x0, #0xf]
    // 0xada94c: DecompressPointer r3
    //     0xada94c: add             x3, x3, HEAP, lsl #32
    // 0xada950: LoadField: r4 = r3->field_b
    //     0xada950: ldur            w4, [x3, #0xb]
    // 0xada954: DecompressPointer r4
    //     0xada954: add             x4, x4, HEAP, lsl #32
    // 0xada958: cmp             w2, w4
    // 0xada95c: b.ne            #0xada96c
    // 0xada960: SaveReg r0
    //     0xada960: str             x0, [SP, #-8]!
    // 0xada964: r0 = _growToNextCapacity()
    //     0xada964: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xada968: add             SP, SP, #8
    // 0xada96c: ldur            x2, [fp, #-0x10]
    // 0xada970: ldur            x0, [fp, #-8]
    // 0xada974: r3 = LoadInt32Instr(r0)
    //     0xada974: sbfx            x3, x0, #1, #0x1f
    // 0xada978: add             x0, x3, #1
    // 0xada97c: lsl             x1, x0, #1
    // 0xada980: StoreField: r2->field_b = r1
    //     0xada980: stur            w1, [x2, #0xb]
    // 0xada984: mov             x1, x3
    // 0xada988: cmp             x1, x0
    // 0xada98c: b.hs            #0xadab5c
    // 0xada990: LoadField: r1 = r2->field_f
    //     0xada990: ldur            w1, [x2, #0xf]
    // 0xada994: DecompressPointer r1
    //     0xada994: add             x1, x1, HEAP, lsl #32
    // 0xada998: ldur            x0, [fp, #-0x18]
    // 0xada99c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xada99c: add             x25, x1, x3, lsl #2
    //     0xada9a0: add             x25, x25, #0xf
    //     0xada9a4: str             w0, [x25]
    //     0xada9a8: tbz             w0, #0, #0xada9c4
    //     0xada9ac: ldurb           w16, [x1, #-1]
    //     0xada9b0: ldurb           w17, [x0, #-1]
    //     0xada9b4: and             x16, x17, x16, lsr #2
    //     0xada9b8: tst             x16, HEAP, lsr #32
    //     0xada9bc: b.eq            #0xada9c4
    //     0xada9c0: bl              #0xd67e5c
    // 0xada9c4: b               #0xada9cc
    // 0xada9c8: ldur            x2, [fp, #-0x10]
    // 0xada9cc: ldr             x0, [fp, #0x10]
    // 0xada9d0: LoadField: r1 = r0->field_13
    //     0xada9d0: ldur            w1, [x0, #0x13]
    // 0xada9d4: DecompressPointer r1
    //     0xada9d4: add             x1, x1, HEAP, lsl #32
    // 0xada9d8: stur            x1, [fp, #-8]
    // 0xada9dc: r16 = Instance_BorderSide
    //     0xada9dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xada9e0: ldr             x16, [x16, #0x2f0]
    // 0xada9e4: stp             x16, x1, [SP, #-0x10]!
    // 0xada9e8: r0 = ==()
    //     0xada9e8: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xada9ec: add             SP, SP, #0x10
    // 0xada9f0: tbz             w0, #4, #0xadaac0
    // 0xada9f4: ldur            x0, [fp, #-0x10]
    // 0xada9f8: ldur            x3, [fp, #-8]
    // 0xada9fc: r1 = Null
    //     0xada9fc: mov             x1, NULL
    // 0xadaa00: r2 = 4
    //     0xadaa00: mov             x2, #4
    // 0xadaa04: r0 = AllocateArray()
    //     0xadaa04: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadaa08: r17 = "left: "
    //     0xadaa08: add             x17, PP, #0x29, lsl #12  ; [pp+0x29458] "left: "
    //     0xadaa0c: ldr             x17, [x17, #0x458]
    // 0xadaa10: StoreField: r0->field_f = r17
    //     0xadaa10: stur            w17, [x0, #0xf]
    // 0xadaa14: ldur            x1, [fp, #-8]
    // 0xadaa18: StoreField: r0->field_13 = r1
    //     0xadaa18: stur            w1, [x0, #0x13]
    // 0xadaa1c: SaveReg r0
    //     0xadaa1c: str             x0, [SP, #-8]!
    // 0xadaa20: r0 = _interpolate()
    //     0xadaa20: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadaa24: add             SP, SP, #8
    // 0xadaa28: mov             x1, x0
    // 0xadaa2c: ldur            x0, [fp, #-0x10]
    // 0xadaa30: stur            x1, [fp, #-0x18]
    // 0xadaa34: LoadField: r2 = r0->field_b
    //     0xadaa34: ldur            w2, [x0, #0xb]
    // 0xadaa38: DecompressPointer r2
    //     0xadaa38: add             x2, x2, HEAP, lsl #32
    // 0xadaa3c: stur            x2, [fp, #-8]
    // 0xadaa40: LoadField: r3 = r0->field_f
    //     0xadaa40: ldur            w3, [x0, #0xf]
    // 0xadaa44: DecompressPointer r3
    //     0xadaa44: add             x3, x3, HEAP, lsl #32
    // 0xadaa48: LoadField: r4 = r3->field_b
    //     0xadaa48: ldur            w4, [x3, #0xb]
    // 0xadaa4c: DecompressPointer r4
    //     0xadaa4c: add             x4, x4, HEAP, lsl #32
    // 0xadaa50: cmp             w2, w4
    // 0xadaa54: b.ne            #0xadaa64
    // 0xadaa58: SaveReg r0
    //     0xadaa58: str             x0, [SP, #-8]!
    // 0xadaa5c: r0 = _growToNextCapacity()
    //     0xadaa5c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xadaa60: add             SP, SP, #8
    // 0xadaa64: ldur            x3, [fp, #-0x10]
    // 0xadaa68: ldur            x0, [fp, #-8]
    // 0xadaa6c: r2 = LoadInt32Instr(r0)
    //     0xadaa6c: sbfx            x2, x0, #1, #0x1f
    // 0xadaa70: add             x0, x2, #1
    // 0xadaa74: lsl             x1, x0, #1
    // 0xadaa78: StoreField: r3->field_b = r1
    //     0xadaa78: stur            w1, [x3, #0xb]
    // 0xadaa7c: mov             x1, x2
    // 0xadaa80: cmp             x1, x0
    // 0xadaa84: b.hs            #0xadab60
    // 0xadaa88: LoadField: r1 = r3->field_f
    //     0xadaa88: ldur            w1, [x3, #0xf]
    // 0xadaa8c: DecompressPointer r1
    //     0xadaa8c: add             x1, x1, HEAP, lsl #32
    // 0xadaa90: ldur            x0, [fp, #-0x18]
    // 0xadaa94: ArrayStore: r1[r2] = r0  ; List_4
    //     0xadaa94: add             x25, x1, x2, lsl #2
    //     0xadaa98: add             x25, x25, #0xf
    //     0xadaa9c: str             w0, [x25]
    //     0xadaaa0: tbz             w0, #0, #0xadaabc
    //     0xadaaa4: ldurb           w16, [x1, #-1]
    //     0xadaaa8: ldurb           w17, [x0, #-1]
    //     0xadaaac: and             x16, x17, x16, lsr #2
    //     0xadaab0: tst             x16, HEAP, lsr #32
    //     0xadaab4: b.eq            #0xadaabc
    //     0xadaab8: bl              #0xd67e5c
    // 0xadaabc: b               #0xadaac4
    // 0xadaac0: ldur            x3, [fp, #-0x10]
    // 0xadaac4: r1 = Null
    //     0xadaac4: mov             x1, NULL
    // 0xadaac8: r2 = 8
    //     0xadaac8: mov             x2, #8
    // 0xadaacc: r0 = AllocateArray()
    //     0xadaacc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadaad0: stur            x0, [fp, #-8]
    // 0xadaad4: r17 = "Border"
    //     0xadaad4: add             x17, PP, #0x29, lsl #12  ; [pp+0x29430] "Border"
    //     0xadaad8: ldr             x17, [x17, #0x430]
    // 0xadaadc: StoreField: r0->field_f = r17
    //     0xadaadc: stur            w17, [x0, #0xf]
    // 0xadaae0: r17 = "("
    //     0xadaae0: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xadaae4: StoreField: r0->field_13 = r17
    //     0xadaae4: stur            w17, [x0, #0x13]
    // 0xadaae8: ldur            x16, [fp, #-0x10]
    // 0xadaaec: r30 = ", "
    //     0xadaaec: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadaaf0: stp             lr, x16, [SP, #-0x10]!
    // 0xadaaf4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xadaaf4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xadaaf8: r0 = join()
    //     0xadaaf8: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xadaafc: add             SP, SP, #0x10
    // 0xadab00: ldur            x1, [fp, #-8]
    // 0xadab04: ArrayStore: r1[2] = r0  ; List_4
    //     0xadab04: add             x25, x1, #0x17
    //     0xadab08: str             w0, [x25]
    //     0xadab0c: tbz             w0, #0, #0xadab28
    //     0xadab10: ldurb           w16, [x1, #-1]
    //     0xadab14: ldurb           w17, [x0, #-1]
    //     0xadab18: and             x16, x17, x16, lsr #2
    //     0xadab1c: tst             x16, HEAP, lsr #32
    //     0xadab20: b.eq            #0xadab28
    //     0xadab24: bl              #0xd67e5c
    // 0xadab28: ldur            x0, [fp, #-8]
    // 0xadab2c: r17 = ")"
    //     0xadab2c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadab30: StoreField: r0->field_1b = r17
    //     0xadab30: stur            w17, [x0, #0x1b]
    // 0xadab34: SaveReg r0
    //     0xadab34: str             x0, [SP, #-8]!
    // 0xadab38: r0 = _interpolate()
    //     0xadab38: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadab3c: add             SP, SP, #8
    // 0xadab40: LeaveFrame
    //     0xadab40: mov             SP, fp
    //     0xadab44: ldp             fp, lr, [SP], #0x10
    // 0xadab48: ret
    //     0xadab48: ret             
    // 0xadab4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadab4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadab50: b               #0xada65c
    // 0xadab54: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xadab54: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xadab58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xadab58: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xadab5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xadab5c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xadab60: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xadab60: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ isUniform(/* No info */) {
    // ** addr: 0xadab64, size: 0x120
    // 0xadab64: EnterFrame
    //     0xadab64: stp             fp, lr, [SP, #-0x10]!
    //     0xadab68: mov             fp, SP
    // 0xadab6c: CheckStackOverflow
    //     0xadab6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadab70: cmp             SP, x16
    //     0xadab74: b.ls            #0xadac7c
    // 0xadab78: ldr             x16, [fp, #0x10]
    // 0xadab7c: SaveReg r16
    //     0xadab7c: str             x16, [SP, #-8]!
    // 0xadab80: r0 = _colorIsUniform()
    //     0xadab80: bl              #0xadac84  ; [package:flutter/src/painting/box_border.dart] Border::_colorIsUniform
    // 0xadab84: add             SP, SP, #8
    // 0xadab88: tbnz            w0, #4, #0xadac6c
    // 0xadab8c: ldr             x1, [fp, #0x10]
    // 0xadab90: LoadField: r2 = r1->field_7
    //     0xadab90: ldur            w2, [x1, #7]
    // 0xadab94: DecompressPointer r2
    //     0xadab94: add             x2, x2, HEAP, lsl #32
    // 0xadab98: LoadField: d0 = r2->field_b
    //     0xadab98: ldur            d0, [x2, #0xb]
    // 0xadab9c: LoadField: r3 = r1->field_b
    //     0xadab9c: ldur            w3, [x1, #0xb]
    // 0xadaba0: DecompressPointer r3
    //     0xadaba0: add             x3, x3, HEAP, lsl #32
    // 0xadaba4: LoadField: d1 = r3->field_b
    //     0xadaba4: ldur            d1, [x3, #0xb]
    // 0xadaba8: fcmp            d1, d0
    // 0xadabac: b.vs            #0xadac6c
    // 0xadabb0: b.ne            #0xadac6c
    // 0xadabb4: LoadField: r4 = r1->field_f
    //     0xadabb4: ldur            w4, [x1, #0xf]
    // 0xadabb8: DecompressPointer r4
    //     0xadabb8: add             x4, x4, HEAP, lsl #32
    // 0xadabbc: LoadField: d1 = r4->field_b
    //     0xadabbc: ldur            d1, [x4, #0xb]
    // 0xadabc0: fcmp            d1, d0
    // 0xadabc4: b.vs            #0xadac6c
    // 0xadabc8: b.ne            #0xadac6c
    // 0xadabcc: LoadField: r5 = r1->field_13
    //     0xadabcc: ldur            w5, [x1, #0x13]
    // 0xadabd0: DecompressPointer r5
    //     0xadabd0: add             x5, x5, HEAP, lsl #32
    // 0xadabd4: LoadField: d1 = r5->field_b
    //     0xadabd4: ldur            d1, [x5, #0xb]
    // 0xadabd8: fcmp            d1, d0
    // 0xadabdc: b.vs            #0xadac6c
    // 0xadabe0: b.ne            #0xadac6c
    // 0xadabe4: LoadField: r1 = r2->field_13
    //     0xadabe4: ldur            w1, [x2, #0x13]
    // 0xadabe8: DecompressPointer r1
    //     0xadabe8: add             x1, x1, HEAP, lsl #32
    // 0xadabec: LoadField: r6 = r3->field_13
    //     0xadabec: ldur            w6, [x3, #0x13]
    // 0xadabf0: DecompressPointer r6
    //     0xadabf0: add             x6, x6, HEAP, lsl #32
    // 0xadabf4: cmp             w6, w1
    // 0xadabf8: b.ne            #0xadac6c
    // 0xadabfc: LoadField: r6 = r4->field_13
    //     0xadabfc: ldur            w6, [x4, #0x13]
    // 0xadac00: DecompressPointer r6
    //     0xadac00: add             x6, x6, HEAP, lsl #32
    // 0xadac04: cmp             w6, w1
    // 0xadac08: b.ne            #0xadac6c
    // 0xadac0c: LoadField: r6 = r5->field_13
    //     0xadac0c: ldur            w6, [x5, #0x13]
    // 0xadac10: DecompressPointer r6
    //     0xadac10: add             x6, x6, HEAP, lsl #32
    // 0xadac14: cmp             w6, w1
    // 0xadac18: b.ne            #0xadac6c
    // 0xadac1c: LoadField: d0 = r2->field_17
    //     0xadac1c: ldur            d0, [x2, #0x17]
    // 0xadac20: LoadField: d1 = r3->field_17
    //     0xadac20: ldur            d1, [x3, #0x17]
    // 0xadac24: fcmp            d1, d0
    // 0xadac28: b.vs            #0xadac60
    // 0xadac2c: b.ne            #0xadac60
    // 0xadac30: LoadField: d1 = r4->field_17
    //     0xadac30: ldur            d1, [x4, #0x17]
    // 0xadac34: fcmp            d1, d0
    // 0xadac38: b.vs            #0xadac60
    // 0xadac3c: b.ne            #0xadac60
    // 0xadac40: LoadField: d1 = r5->field_17
    //     0xadac40: ldur            d1, [x5, #0x17]
    // 0xadac44: fcmp            d1, d0
    // 0xadac48: b.vs            #0xadac50
    // 0xadac4c: b.eq            #0xadac58
    // 0xadac50: r1 = false
    //     0xadac50: add             x1, NULL, #0x30  ; false
    // 0xadac54: b               #0xadac5c
    // 0xadac58: r1 = true
    //     0xadac58: add             x1, NULL, #0x20  ; true
    // 0xadac5c: b               #0xadac64
    // 0xadac60: r1 = false
    //     0xadac60: add             x1, NULL, #0x30  ; false
    // 0xadac64: mov             x0, x1
    // 0xadac68: b               #0xadac70
    // 0xadac6c: r0 = false
    //     0xadac6c: add             x0, NULL, #0x30  ; false
    // 0xadac70: LeaveFrame
    //     0xadac70: mov             SP, fp
    //     0xadac74: ldp             fp, lr, [SP], #0x10
    // 0xadac78: ret
    //     0xadac78: ret             
    // 0xadac7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadac7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadac80: b               #0xadab78
  }
  get _ _colorIsUniform(/* No info */) {
    // ** addr: 0xadac84, size: 0x42c
    // 0xadac84: EnterFrame
    //     0xadac84: stp             fp, lr, [SP, #-0x10]!
    //     0xadac88: mov             fp, SP
    // 0xadac8c: AllocStack(0x18)
    //     0xadac8c: sub             SP, SP, #0x18
    // 0xadac90: CheckStackOverflow
    //     0xadac90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadac94: cmp             SP, x16
    //     0xadac98: b.ls            #0xadb0a8
    // 0xadac9c: ldr             x0, [fp, #0x10]
    // 0xadaca0: LoadField: r1 = r0->field_7
    //     0xadaca0: ldur            w1, [x0, #7]
    // 0xadaca4: DecompressPointer r1
    //     0xadaca4: add             x1, x1, HEAP, lsl #32
    // 0xadaca8: LoadField: r2 = r1->field_7
    //     0xadaca8: ldur            w2, [x1, #7]
    // 0xadacac: DecompressPointer r2
    //     0xadacac: add             x2, x2, HEAP, lsl #32
    // 0xadacb0: stur            x2, [fp, #-0x18]
    // 0xadacb4: LoadField: r1 = r0->field_b
    //     0xadacb4: ldur            w1, [x0, #0xb]
    // 0xadacb8: DecompressPointer r1
    //     0xadacb8: add             x1, x1, HEAP, lsl #32
    // 0xadacbc: LoadField: r3 = r1->field_7
    //     0xadacbc: ldur            w3, [x1, #7]
    // 0xadacc0: DecompressPointer r3
    //     0xadacc0: add             x3, x3, HEAP, lsl #32
    // 0xadacc4: stur            x3, [fp, #-0x10]
    // 0xadacc8: r1 = LoadClassIdInstr(r3)
    //     0xadacc8: ldur            x1, [x3, #-1]
    //     0xadaccc: ubfx            x1, x1, #0xc, #0x14
    // 0xadacd0: lsl             x1, x1, #1
    // 0xadacd4: stur            x1, [fp, #-8]
    // 0xadacd8: r17 = 10114
    //     0xadacd8: mov             x17, #0x2782
    // 0xadacdc: cmp             w1, w17
    // 0xadace0: b.eq            #0xadacf0
    // 0xadace4: r17 = 10118
    //     0xadace4: mov             x17, #0x2786
    // 0xadace8: cmp             w1, w17
    // 0xadacec: b.ne            #0xadadc4
    // 0xadacf0: cmp             w3, w2
    // 0xadacf4: b.eq            #0xadadf4
    // 0xadacf8: stp             x3, x2, [SP, #-0x10]!
    // 0xadacfc: r0 = _haveSameRuntimeType()
    //     0xadacfc: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xadad00: add             SP, SP, #0x10
    // 0xadad04: tbnz            w0, #4, #0xadb098
    // 0xadad08: ldur            x1, [fp, #-0x18]
    // 0xadad0c: r0 = LoadClassIdInstr(r1)
    //     0xadad0c: ldur            x0, [x1, #-1]
    //     0xadad10: ubfx            x0, x0, #0xc, #0x14
    // 0xadad14: lsl             x0, x0, #1
    // 0xadad18: r17 = 10124
    //     0xadad18: mov             x17, #0x278c
    // 0xadad1c: cmp             w0, w17
    // 0xadad20: b.gt            #0xadad30
    // 0xadad24: r17 = 10122
    //     0xadad24: mov             x17, #0x278a
    // 0xadad28: cmp             w0, w17
    // 0xadad2c: b.ge            #0xadad48
    // 0xadad30: r17 = 10114
    //     0xadad30: mov             x17, #0x2782
    // 0xadad34: cmp             w0, w17
    // 0xadad38: b.eq            #0xadad48
    // 0xadad3c: r17 = 10118
    //     0xadad3c: mov             x17, #0x2786
    // 0xadad40: cmp             w0, w17
    // 0xadad44: b.ne            #0xadad54
    // 0xadad48: LoadField: r0 = r1->field_7
    //     0xadad48: ldur            x0, [x1, #7]
    // 0xadad4c: mov             x2, x0
    // 0xadad50: b               #0xadad60
    // 0xadad54: LoadField: r0 = r1->field_f
    //     0xadad54: ldur            w0, [x1, #0xf]
    // 0xadad58: DecompressPointer r0
    //     0xadad58: add             x0, x0, HEAP, lsl #32
    // 0xadad5c: LoadField: r2 = r0->field_7
    //     0xadad5c: ldur            x2, [x0, #7]
    // 0xadad60: ldur            x0, [fp, #-8]
    // 0xadad64: r17 = 10124
    //     0xadad64: mov             x17, #0x278c
    // 0xadad68: cmp             w0, w17
    // 0xadad6c: b.gt            #0xadad7c
    // 0xadad70: r17 = 10122
    //     0xadad70: mov             x17, #0x278a
    // 0xadad74: cmp             w0, w17
    // 0xadad78: b.ge            #0xadad94
    // 0xadad7c: r17 = 10114
    //     0xadad7c: mov             x17, #0x2782
    // 0xadad80: cmp             w0, w17
    // 0xadad84: b.eq            #0xadad94
    // 0xadad88: r17 = 10118
    //     0xadad88: mov             x17, #0x2786
    // 0xadad8c: cmp             w0, w17
    // 0xadad90: b.ne            #0xadada4
    // 0xadad94: ldur            x0, [fp, #-0x10]
    // 0xadad98: LoadField: r3 = r0->field_7
    //     0xadad98: ldur            x3, [x0, #7]
    // 0xadad9c: mov             x0, x3
    // 0xadada0: b               #0xadadb4
    // 0xadada4: ldur            x0, [fp, #-0x10]
    // 0xadada8: LoadField: r3 = r0->field_f
    //     0xadada8: ldur            w3, [x0, #0xf]
    // 0xadadac: DecompressPointer r3
    //     0xadadac: add             x3, x3, HEAP, lsl #32
    // 0xadadb0: LoadField: r0 = r3->field_7
    //     0xadadb0: ldur            x0, [x3, #7]
    // 0xadadb4: cmp             x2, x0
    // 0xadadb8: b.ne            #0xadb098
    // 0xadadbc: ldr             x0, [fp, #0x10]
    // 0xadadc0: b               #0xadadf4
    // 0xadadc4: mov             x1, x2
    // 0xadadc8: mov             x0, x3
    // 0xadadcc: r2 = LoadClassIdInstr(r0)
    //     0xadadcc: ldur            x2, [x0, #-1]
    //     0xadadd0: ubfx            x2, x2, #0xc, #0x14
    // 0xadadd4: stp             x1, x0, [SP, #-0x10]!
    // 0xadadd8: mov             x0, x2
    // 0xadaddc: mov             lr, x0
    // 0xadade0: ldr             lr, [x21, lr, lsl #3]
    // 0xadade4: blr             lr
    // 0xadade8: add             SP, SP, #0x10
    // 0xadadec: tbnz            w0, #4, #0xadb098
    // 0xadadf0: ldr             x0, [fp, #0x10]
    // 0xadadf4: LoadField: r1 = r0->field_f
    //     0xadadf4: ldur            w1, [x0, #0xf]
    // 0xadadf8: DecompressPointer r1
    //     0xadadf8: add             x1, x1, HEAP, lsl #32
    // 0xadadfc: LoadField: r2 = r1->field_7
    //     0xadadfc: ldur            w2, [x1, #7]
    // 0xadae00: DecompressPointer r2
    //     0xadae00: add             x2, x2, HEAP, lsl #32
    // 0xadae04: stur            x2, [fp, #-0x10]
    // 0xadae08: r1 = LoadClassIdInstr(r2)
    //     0xadae08: ldur            x1, [x2, #-1]
    //     0xadae0c: ubfx            x1, x1, #0xc, #0x14
    // 0xadae10: lsl             x1, x1, #1
    // 0xadae14: stur            x1, [fp, #-8]
    // 0xadae18: r17 = 10114
    //     0xadae18: mov             x17, #0x2782
    // 0xadae1c: cmp             w1, w17
    // 0xadae20: b.eq            #0xadae30
    // 0xadae24: r17 = 10118
    //     0xadae24: mov             x17, #0x2786
    // 0xadae28: cmp             w1, w17
    // 0xadae2c: b.ne            #0xadaf08
    // 0xadae30: ldur            x3, [fp, #-0x18]
    // 0xadae34: cmp             w2, w3
    // 0xadae38: b.eq            #0xadaf38
    // 0xadae3c: stp             x2, x3, [SP, #-0x10]!
    // 0xadae40: r0 = _haveSameRuntimeType()
    //     0xadae40: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xadae44: add             SP, SP, #0x10
    // 0xadae48: tbnz            w0, #4, #0xadb098
    // 0xadae4c: ldur            x1, [fp, #-0x18]
    // 0xadae50: r0 = LoadClassIdInstr(r1)
    //     0xadae50: ldur            x0, [x1, #-1]
    //     0xadae54: ubfx            x0, x0, #0xc, #0x14
    // 0xadae58: lsl             x0, x0, #1
    // 0xadae5c: r17 = 10124
    //     0xadae5c: mov             x17, #0x278c
    // 0xadae60: cmp             w0, w17
    // 0xadae64: b.gt            #0xadae74
    // 0xadae68: r17 = 10122
    //     0xadae68: mov             x17, #0x278a
    // 0xadae6c: cmp             w0, w17
    // 0xadae70: b.ge            #0xadae8c
    // 0xadae74: r17 = 10114
    //     0xadae74: mov             x17, #0x2782
    // 0xadae78: cmp             w0, w17
    // 0xadae7c: b.eq            #0xadae8c
    // 0xadae80: r17 = 10118
    //     0xadae80: mov             x17, #0x2786
    // 0xadae84: cmp             w0, w17
    // 0xadae88: b.ne            #0xadae98
    // 0xadae8c: LoadField: r0 = r1->field_7
    //     0xadae8c: ldur            x0, [x1, #7]
    // 0xadae90: mov             x2, x0
    // 0xadae94: b               #0xadaea4
    // 0xadae98: LoadField: r0 = r1->field_f
    //     0xadae98: ldur            w0, [x1, #0xf]
    // 0xadae9c: DecompressPointer r0
    //     0xadae9c: add             x0, x0, HEAP, lsl #32
    // 0xadaea0: LoadField: r2 = r0->field_7
    //     0xadaea0: ldur            x2, [x0, #7]
    // 0xadaea4: ldur            x0, [fp, #-8]
    // 0xadaea8: r17 = 10124
    //     0xadaea8: mov             x17, #0x278c
    // 0xadaeac: cmp             w0, w17
    // 0xadaeb0: b.gt            #0xadaec0
    // 0xadaeb4: r17 = 10122
    //     0xadaeb4: mov             x17, #0x278a
    // 0xadaeb8: cmp             w0, w17
    // 0xadaebc: b.ge            #0xadaed8
    // 0xadaec0: r17 = 10114
    //     0xadaec0: mov             x17, #0x2782
    // 0xadaec4: cmp             w0, w17
    // 0xadaec8: b.eq            #0xadaed8
    // 0xadaecc: r17 = 10118
    //     0xadaecc: mov             x17, #0x2786
    // 0xadaed0: cmp             w0, w17
    // 0xadaed4: b.ne            #0xadaee8
    // 0xadaed8: ldur            x0, [fp, #-0x10]
    // 0xadaedc: LoadField: r3 = r0->field_7
    //     0xadaedc: ldur            x3, [x0, #7]
    // 0xadaee0: mov             x0, x3
    // 0xadaee4: b               #0xadaef8
    // 0xadaee8: ldur            x0, [fp, #-0x10]
    // 0xadaeec: LoadField: r3 = r0->field_f
    //     0xadaeec: ldur            w3, [x0, #0xf]
    // 0xadaef0: DecompressPointer r3
    //     0xadaef0: add             x3, x3, HEAP, lsl #32
    // 0xadaef4: LoadField: r0 = r3->field_7
    //     0xadaef4: ldur            x0, [x3, #7]
    // 0xadaef8: cmp             x2, x0
    // 0xadaefc: b.ne            #0xadb098
    // 0xadaf00: ldr             x0, [fp, #0x10]
    // 0xadaf04: b               #0xadaf38
    // 0xadaf08: ldur            x1, [fp, #-0x18]
    // 0xadaf0c: mov             x0, x2
    // 0xadaf10: r2 = LoadClassIdInstr(r0)
    //     0xadaf10: ldur            x2, [x0, #-1]
    //     0xadaf14: ubfx            x2, x2, #0xc, #0x14
    // 0xadaf18: stp             x1, x0, [SP, #-0x10]!
    // 0xadaf1c: mov             x0, x2
    // 0xadaf20: mov             lr, x0
    // 0xadaf24: ldr             lr, [x21, lr, lsl #3]
    // 0xadaf28: blr             lr
    // 0xadaf2c: add             SP, SP, #0x10
    // 0xadaf30: tbnz            w0, #4, #0xadb098
    // 0xadaf34: ldr             x0, [fp, #0x10]
    // 0xadaf38: LoadField: r1 = r0->field_13
    //     0xadaf38: ldur            w1, [x0, #0x13]
    // 0xadaf3c: DecompressPointer r1
    //     0xadaf3c: add             x1, x1, HEAP, lsl #32
    // 0xadaf40: LoadField: r0 = r1->field_7
    //     0xadaf40: ldur            w0, [x1, #7]
    // 0xadaf44: DecompressPointer r0
    //     0xadaf44: add             x0, x0, HEAP, lsl #32
    // 0xadaf48: stur            x0, [fp, #-0x10]
    // 0xadaf4c: r1 = LoadClassIdInstr(r0)
    //     0xadaf4c: ldur            x1, [x0, #-1]
    //     0xadaf50: ubfx            x1, x1, #0xc, #0x14
    // 0xadaf54: lsl             x1, x1, #1
    // 0xadaf58: stur            x1, [fp, #-8]
    // 0xadaf5c: r17 = 10114
    //     0xadaf5c: mov             x17, #0x2782
    // 0xadaf60: cmp             w1, w17
    // 0xadaf64: b.eq            #0xadaf74
    // 0xadaf68: r17 = 10118
    //     0xadaf68: mov             x17, #0x2786
    // 0xadaf6c: cmp             w1, w17
    // 0xadaf70: b.ne            #0xadb064
    // 0xadaf74: ldur            x2, [fp, #-0x18]
    // 0xadaf78: cmp             w0, w2
    // 0xadaf7c: b.ne            #0xadaf88
    // 0xadaf80: r1 = true
    //     0xadaf80: add             x1, NULL, #0x20  ; true
    // 0xadaf84: b               #0xadb090
    // 0xadaf88: stp             x0, x2, [SP, #-0x10]!
    // 0xadaf8c: r0 = _haveSameRuntimeType()
    //     0xadaf8c: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xadaf90: add             SP, SP, #0x10
    // 0xadaf94: tbz             w0, #4, #0xadafa0
    // 0xadaf98: r1 = false
    //     0xadaf98: add             x1, NULL, #0x30  ; false
    // 0xadaf9c: b               #0xadb090
    // 0xadafa0: ldur            x0, [fp, #-0x18]
    // 0xadafa4: r1 = LoadClassIdInstr(r0)
    //     0xadafa4: ldur            x1, [x0, #-1]
    //     0xadafa8: ubfx            x1, x1, #0xc, #0x14
    // 0xadafac: lsl             x1, x1, #1
    // 0xadafb0: r17 = 10124
    //     0xadafb0: mov             x17, #0x278c
    // 0xadafb4: cmp             w1, w17
    // 0xadafb8: b.gt            #0xadafc8
    // 0xadafbc: r17 = 10122
    //     0xadafbc: mov             x17, #0x278a
    // 0xadafc0: cmp             w1, w17
    // 0xadafc4: b.ge            #0xadafe0
    // 0xadafc8: r17 = 10114
    //     0xadafc8: mov             x17, #0x2782
    // 0xadafcc: cmp             w1, w17
    // 0xadafd0: b.eq            #0xadafe0
    // 0xadafd4: r17 = 10118
    //     0xadafd4: mov             x17, #0x2786
    // 0xadafd8: cmp             w1, w17
    // 0xadafdc: b.ne            #0xadafe8
    // 0xadafe0: LoadField: r1 = r0->field_7
    //     0xadafe0: ldur            x1, [x0, #7]
    // 0xadafe4: b               #0xadaff8
    // 0xadafe8: LoadField: r1 = r0->field_f
    //     0xadafe8: ldur            w1, [x0, #0xf]
    // 0xadafec: DecompressPointer r1
    //     0xadafec: add             x1, x1, HEAP, lsl #32
    // 0xadaff0: LoadField: r0 = r1->field_7
    //     0xadaff0: ldur            x0, [x1, #7]
    // 0xadaff4: mov             x1, x0
    // 0xadaff8: ldur            x0, [fp, #-8]
    // 0xadaffc: r17 = 10124
    //     0xadaffc: mov             x17, #0x278c
    // 0xadb000: cmp             w0, w17
    // 0xadb004: b.gt            #0xadb014
    // 0xadb008: r17 = 10122
    //     0xadb008: mov             x17, #0x278a
    // 0xadb00c: cmp             w0, w17
    // 0xadb010: b.ge            #0xadb02c
    // 0xadb014: r17 = 10114
    //     0xadb014: mov             x17, #0x2782
    // 0xadb018: cmp             w0, w17
    // 0xadb01c: b.eq            #0xadb02c
    // 0xadb020: r17 = 10118
    //     0xadb020: mov             x17, #0x2786
    // 0xadb024: cmp             w0, w17
    // 0xadb028: b.ne            #0xadb038
    // 0xadb02c: ldur            x2, [fp, #-0x10]
    // 0xadb030: LoadField: r0 = r2->field_7
    //     0xadb030: ldur            x0, [x2, #7]
    // 0xadb034: b               #0xadb04c
    // 0xadb038: ldur            x2, [fp, #-0x10]
    // 0xadb03c: LoadField: r0 = r2->field_f
    //     0xadb03c: ldur            w0, [x2, #0xf]
    // 0xadb040: DecompressPointer r0
    //     0xadb040: add             x0, x0, HEAP, lsl #32
    // 0xadb044: LoadField: r2 = r0->field_7
    //     0xadb044: ldur            x2, [x0, #7]
    // 0xadb048: mov             x0, x2
    // 0xadb04c: cmp             x1, x0
    // 0xadb050: r16 = true
    //     0xadb050: add             x16, NULL, #0x20  ; true
    // 0xadb054: r17 = false
    //     0xadb054: add             x17, NULL, #0x30  ; false
    // 0xadb058: csel            x2, x16, x17, eq
    // 0xadb05c: mov             x1, x2
    // 0xadb060: b               #0xadb090
    // 0xadb064: mov             x2, x0
    // 0xadb068: ldur            x0, [fp, #-0x18]
    // 0xadb06c: r1 = LoadClassIdInstr(r2)
    //     0xadb06c: ldur            x1, [x2, #-1]
    //     0xadb070: ubfx            x1, x1, #0xc, #0x14
    // 0xadb074: stp             x0, x2, [SP, #-0x10]!
    // 0xadb078: mov             x0, x1
    // 0xadb07c: mov             lr, x0
    // 0xadb080: ldr             lr, [x21, lr, lsl #3]
    // 0xadb084: blr             lr
    // 0xadb088: add             SP, SP, #0x10
    // 0xadb08c: mov             x1, x0
    // 0xadb090: mov             x0, x1
    // 0xadb094: b               #0xadb09c
    // 0xadb098: r0 = false
    //     0xadb098: add             x0, NULL, #0x30  ; false
    // 0xadb09c: LeaveFrame
    //     0xadb09c: mov             SP, fp
    //     0xadb0a0: ldp             fp, lr, [SP], #0x10
    // 0xadb0a4: ret
    //     0xadb0a4: ret             
    // 0xadb0a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadb0a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadb0ac: b               #0xadac9c
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd2c60, size: 0x234
    // 0xbd2c60: EnterFrame
    //     0xbd2c60: stp             fp, lr, [SP, #-0x10]!
    //     0xbd2c64: mov             fp, SP
    // 0xbd2c68: AllocStack(0x30)
    //     0xbd2c68: sub             SP, SP, #0x30
    // 0xbd2c6c: SetupParameters(Border this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* r5, fp-0x18 */, {dynamic borderRadius = Null /* r6, fp-0x10 */, dynamic shape = Instance_BoxShape /* r0, fp-0x8 */})
    //     0xbd2c6c: mov             x0, x4
    //     0xbd2c70: ldur            w1, [x0, #0x13]
    //     0xbd2c74: add             x1, x1, HEAP, lsl #32
    //     0xbd2c78: sub             x2, x1, #6
    //     0xbd2c7c: add             x3, fp, w2, sxtw #2
    //     0xbd2c80: ldr             x3, [x3, #0x20]
    //     0xbd2c84: stur            x3, [fp, #-0x28]
    //     0xbd2c88: add             x4, fp, w2, sxtw #2
    //     0xbd2c8c: ldr             x4, [x4, #0x18]
    //     0xbd2c90: stur            x4, [fp, #-0x20]
    //     0xbd2c94: add             x5, fp, w2, sxtw #2
    //     0xbd2c98: ldr             x5, [x5, #0x10]
    //     0xbd2c9c: stur            x5, [fp, #-0x18]
    //     0xbd2ca0: ldur            w2, [x0, #0x1f]
    //     0xbd2ca4: add             x2, x2, HEAP, lsl #32
    //     0xbd2ca8: add             x16, PP, #0x28, lsl #12  ; [pp+0x286e8] "borderRadius"
    //     0xbd2cac: ldr             x16, [x16, #0x6e8]
    //     0xbd2cb0: cmp             w2, w16
    //     0xbd2cb4: b.ne            #0xbd2cd8
    //     0xbd2cb8: ldur            w2, [x0, #0x23]
    //     0xbd2cbc: add             x2, x2, HEAP, lsl #32
    //     0xbd2cc0: sub             w6, w1, w2
    //     0xbd2cc4: add             x2, fp, w6, sxtw #2
    //     0xbd2cc8: ldr             x2, [x2, #8]
    //     0xbd2ccc: mov             x6, x2
    //     0xbd2cd0: mov             x2, #1
    //     0xbd2cd4: b               #0xbd2ce0
    //     0xbd2cd8: mov             x6, NULL
    //     0xbd2cdc: mov             x2, #0
    //     0xbd2ce0: stur            x6, [fp, #-0x10]
    //     0xbd2ce4: lsl             x7, x2, #1
    //     0xbd2ce8: lsl             w2, w7, #1
    //     0xbd2cec: add             w7, w2, #8
    //     0xbd2cf0: add             x16, x0, w7, sxtw #1
    //     0xbd2cf4: ldur            w8, [x16, #0xf]
    //     0xbd2cf8: add             x8, x8, HEAP, lsl #32
    //     0xbd2cfc: add             x16, PP, #0x28, lsl #12  ; [pp+0x286f0] "shape"
    //     0xbd2d00: ldr             x16, [x16, #0x6f0]
    //     0xbd2d04: cmp             w8, w16
    //     0xbd2d08: b.ne            #0xbd2d30
    //     0xbd2d0c: add             w7, w2, #0xa
    //     0xbd2d10: add             x16, x0, w7, sxtw #1
    //     0xbd2d14: ldur            w2, [x16, #0xf]
    //     0xbd2d18: add             x2, x2, HEAP, lsl #32
    //     0xbd2d1c: sub             w0, w1, w2
    //     0xbd2d20: add             x1, fp, w0, sxtw #2
    //     0xbd2d24: ldr             x1, [x1, #8]
    //     0xbd2d28: mov             x0, x1
    //     0xbd2d2c: b               #0xbd2d38
    //     0xbd2d30: add             x0, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0xbd2d34: ldr             x0, [x0, #0xe68]
    //     0xbd2d38: stur            x0, [fp, #-8]
    // 0xbd2d3c: CheckStackOverflow
    //     0xbd2d3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd2d40: cmp             SP, x16
    //     0xbd2d44: b.ls            #0xbd2e8c
    // 0xbd2d48: SaveReg r3
    //     0xbd2d48: str             x3, [SP, #-8]!
    // 0xbd2d4c: r0 = isUniform()
    //     0xbd2d4c: bl              #0xadab64  ; [package:flutter/src/painting/box_border.dart] Border::isUniform
    // 0xbd2d50: add             SP, SP, #8
    // 0xbd2d54: tbnz            w0, #4, #0xbd2e3c
    // 0xbd2d58: ldur            x0, [fp, #-0x28]
    // 0xbd2d5c: LoadField: r1 = r0->field_7
    //     0xbd2d5c: ldur            w1, [x0, #7]
    // 0xbd2d60: DecompressPointer r1
    //     0xbd2d60: add             x1, x1, HEAP, lsl #32
    // 0xbd2d64: stur            x1, [fp, #-0x30]
    // 0xbd2d68: LoadField: r0 = r1->field_13
    //     0xbd2d68: ldur            w0, [x1, #0x13]
    // 0xbd2d6c: DecompressPointer r0
    //     0xbd2d6c: add             x0, x0, HEAP, lsl #32
    // 0xbd2d70: LoadField: r2 = r0->field_7
    //     0xbd2d70: ldur            x2, [x0, #7]
    // 0xbd2d74: cmp             x2, #0
    // 0xbd2d78: b.gt            #0xbd2d8c
    // 0xbd2d7c: r0 = Null
    //     0xbd2d7c: mov             x0, NULL
    // 0xbd2d80: LeaveFrame
    //     0xbd2d80: mov             SP, fp
    //     0xbd2d84: ldp             fp, lr, [SP], #0x10
    // 0xbd2d88: ret
    //     0xbd2d88: ret             
    // 0xbd2d8c: ldur            x0, [fp, #-8]
    // 0xbd2d90: LoadField: r2 = r0->field_7
    //     0xbd2d90: ldur            x2, [x0, #7]
    // 0xbd2d94: cmp             x2, #0
    // 0xbd2d98: b.gt            #0xbd2e10
    // 0xbd2d9c: ldur            x0, [fp, #-0x10]
    // 0xbd2da0: cmp             w0, NULL
    // 0xbd2da4: b.eq            #0xbd2df0
    // 0xbd2da8: r16 = Instance_BorderRadius
    //     0xbd2da8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xbd2dac: ldr             x16, [x16, #0x2c0]
    // 0xbd2db0: stp             x16, x0, [SP, #-0x10]!
    // 0xbd2db4: r0 = ==()
    //     0xbd2db4: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xbd2db8: add             SP, SP, #0x10
    // 0xbd2dbc: tbz             w0, #4, #0xbd2df0
    // 0xbd2dc0: ldur            x16, [fp, #-0x20]
    // 0xbd2dc4: ldur            lr, [fp, #-0x18]
    // 0xbd2dc8: stp             lr, x16, [SP, #-0x10]!
    // 0xbd2dcc: ldur            x16, [fp, #-0x30]
    // 0xbd2dd0: ldur            lr, [fp, #-0x10]
    // 0xbd2dd4: stp             lr, x16, [SP, #-0x10]!
    // 0xbd2dd8: r0 = _paintUniformBorderWithRadius()
    //     0xbd2dd8: bl              #0xbd31d4  ; [package:flutter/src/painting/box_border.dart] BoxBorder::_paintUniformBorderWithRadius
    // 0xbd2ddc: add             SP, SP, #0x20
    // 0xbd2de0: r0 = Null
    //     0xbd2de0: mov             x0, NULL
    // 0xbd2de4: LeaveFrame
    //     0xbd2de4: mov             SP, fp
    //     0xbd2de8: ldp             fp, lr, [SP], #0x10
    // 0xbd2dec: ret
    //     0xbd2dec: ret             
    // 0xbd2df0: ldur            x16, [fp, #-0x20]
    // 0xbd2df4: ldur            lr, [fp, #-0x18]
    // 0xbd2df8: stp             lr, x16, [SP, #-0x10]!
    // 0xbd2dfc: ldur            x16, [fp, #-0x30]
    // 0xbd2e00: SaveReg r16
    //     0xbd2e00: str             x16, [SP, #-8]!
    // 0xbd2e04: r0 = _paintUniformBorderWithRectangle()
    //     0xbd2e04: bl              #0xbd314c  ; [package:flutter/src/painting/box_border.dart] BoxBorder::_paintUniformBorderWithRectangle
    // 0xbd2e08: add             SP, SP, #0x18
    // 0xbd2e0c: b               #0xbd2e2c
    // 0xbd2e10: ldur            x16, [fp, #-0x20]
    // 0xbd2e14: ldur            lr, [fp, #-0x18]
    // 0xbd2e18: stp             lr, x16, [SP, #-0x10]!
    // 0xbd2e1c: ldur            x16, [fp, #-0x30]
    // 0xbd2e20: SaveReg r16
    //     0xbd2e20: str             x16, [SP, #-8]!
    // 0xbd2e24: r0 = _paintUniformBorderWithCircle()
    //     0xbd2e24: bl              #0xbd2e94  ; [package:flutter/src/painting/box_border.dart] BoxBorder::_paintUniformBorderWithCircle
    // 0xbd2e28: add             SP, SP, #0x18
    // 0xbd2e2c: r0 = Null
    //     0xbd2e2c: mov             x0, NULL
    // 0xbd2e30: LeaveFrame
    //     0xbd2e30: mov             SP, fp
    //     0xbd2e34: ldp             fp, lr, [SP], #0x10
    // 0xbd2e38: ret
    //     0xbd2e38: ret             
    // 0xbd2e3c: ldur            x0, [fp, #-0x28]
    // 0xbd2e40: LoadField: r1 = r0->field_7
    //     0xbd2e40: ldur            w1, [x0, #7]
    // 0xbd2e44: DecompressPointer r1
    //     0xbd2e44: add             x1, x1, HEAP, lsl #32
    // 0xbd2e48: LoadField: r2 = r0->field_b
    //     0xbd2e48: ldur            w2, [x0, #0xb]
    // 0xbd2e4c: DecompressPointer r2
    //     0xbd2e4c: add             x2, x2, HEAP, lsl #32
    // 0xbd2e50: LoadField: r3 = r0->field_f
    //     0xbd2e50: ldur            w3, [x0, #0xf]
    // 0xbd2e54: DecompressPointer r3
    //     0xbd2e54: add             x3, x3, HEAP, lsl #32
    // 0xbd2e58: LoadField: r4 = r0->field_13
    //     0xbd2e58: ldur            w4, [x0, #0x13]
    // 0xbd2e5c: DecompressPointer r4
    //     0xbd2e5c: add             x4, x4, HEAP, lsl #32
    // 0xbd2e60: ldur            x16, [fp, #-0x20]
    // 0xbd2e64: ldur            lr, [fp, #-0x18]
    // 0xbd2e68: stp             lr, x16, [SP, #-0x10]!
    // 0xbd2e6c: stp             x4, x3, [SP, #-0x10]!
    // 0xbd2e70: stp             x1, x2, [SP, #-0x10]!
    // 0xbd2e74: r0 = paintBorder()
    //     0xbd2e74: bl              #0x6709c0  ; [package:flutter/src/painting/borders.dart] ::paintBorder
    // 0xbd2e78: add             SP, SP, #0x30
    // 0xbd2e7c: r0 = Null
    //     0xbd2e7c: mov             x0, NULL
    // 0xbd2e80: LeaveFrame
    //     0xbd2e80: mov             SP, fp
    //     0xbd2e84: ldp             fp, lr, [SP], #0x10
    // 0xbd2e88: ret
    //     0xbd2e88: ret             
    // 0xbd2e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd2e8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd2e90: b               #0xbd2d48
  }
  _ ==(/* No info */) {
    // ** addr: 0xc99514, size: 0x188
    // 0xc99514: EnterFrame
    //     0xc99514: stp             fp, lr, [SP, #-0x10]!
    //     0xc99518: mov             fp, SP
    // 0xc9951c: CheckStackOverflow
    //     0xc9951c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc99520: cmp             SP, x16
    //     0xc99524: b.ls            #0xc99694
    // 0xc99528: ldr             x1, [fp, #0x10]
    // 0xc9952c: cmp             w1, NULL
    // 0xc99530: b.ne            #0xc99544
    // 0xc99534: r0 = false
    //     0xc99534: add             x0, NULL, #0x30  ; false
    // 0xc99538: LeaveFrame
    //     0xc99538: mov             SP, fp
    //     0xc9953c: ldp             fp, lr, [SP], #0x10
    // 0xc99540: ret
    //     0xc99540: ret             
    // 0xc99544: ldr             x2, [fp, #0x18]
    // 0xc99548: cmp             w2, w1
    // 0xc9954c: b.ne            #0xc99560
    // 0xc99550: r0 = true
    //     0xc99550: add             x0, NULL, #0x20  ; true
    // 0xc99554: LeaveFrame
    //     0xc99554: mov             SP, fp
    //     0xc99558: ldp             fp, lr, [SP], #0x10
    // 0xc9955c: ret
    //     0xc9955c: ret             
    // 0xc99560: r0 = 59
    //     0xc99560: mov             x0, #0x3b
    // 0xc99564: branchIfSmi(r1, 0xc99570)
    //     0xc99564: tbz             w1, #0, #0xc99570
    // 0xc99568: r0 = LoadClassIdInstr(r1)
    //     0xc99568: ldur            x0, [x1, #-1]
    //     0xc9956c: ubfx            x0, x0, #0xc, #0x14
    // 0xc99570: SaveReg r1
    //     0xc99570: str             x1, [SP, #-8]!
    // 0xc99574: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc99574: mov             x17, #0x57c5
    //     0xc99578: add             lr, x0, x17
    //     0xc9957c: ldr             lr, [x21, lr, lsl #3]
    //     0xc99580: blr             lr
    // 0xc99584: add             SP, SP, #8
    // 0xc99588: r1 = LoadClassIdInstr(r0)
    //     0xc99588: ldur            x1, [x0, #-1]
    //     0xc9958c: ubfx            x1, x1, #0xc, #0x14
    // 0xc99590: r16 = Border
    //     0xc99590: add             x16, PP, #0x29, lsl #12  ; [pp+0x29460] Type: Border
    //     0xc99594: ldr             x16, [x16, #0x460]
    // 0xc99598: stp             x16, x0, [SP, #-0x10]!
    // 0xc9959c: mov             x0, x1
    // 0xc995a0: mov             lr, x0
    // 0xc995a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc995a8: blr             lr
    // 0xc995ac: add             SP, SP, #0x10
    // 0xc995b0: tbz             w0, #4, #0xc995c4
    // 0xc995b4: r0 = false
    //     0xc995b4: add             x0, NULL, #0x30  ; false
    // 0xc995b8: LeaveFrame
    //     0xc995b8: mov             SP, fp
    //     0xc995bc: ldp             fp, lr, [SP], #0x10
    // 0xc995c0: ret
    //     0xc995c0: ret             
    // 0xc995c4: ldr             x0, [fp, #0x10]
    // 0xc995c8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc995c8: mov             x1, #0x76
    //     0xc995cc: tbz             w0, #0, #0xc995dc
    //     0xc995d0: ldur            x1, [x0, #-1]
    //     0xc995d4: ubfx            x1, x1, #0xc, #0x14
    //     0xc995d8: lsl             x1, x1, #1
    // 0xc995dc: r17 = 4374
    //     0xc995dc: mov             x17, #0x1116
    // 0xc995e0: cmp             w1, w17
    // 0xc995e4: b.ne            #0xc99684
    // 0xc995e8: ldr             x1, [fp, #0x18]
    // 0xc995ec: LoadField: r2 = r0->field_7
    //     0xc995ec: ldur            w2, [x0, #7]
    // 0xc995f0: DecompressPointer r2
    //     0xc995f0: add             x2, x2, HEAP, lsl #32
    // 0xc995f4: LoadField: r3 = r1->field_7
    //     0xc995f4: ldur            w3, [x1, #7]
    // 0xc995f8: DecompressPointer r3
    //     0xc995f8: add             x3, x3, HEAP, lsl #32
    // 0xc995fc: stp             x3, x2, [SP, #-0x10]!
    // 0xc99600: r0 = ==()
    //     0xc99600: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc99604: add             SP, SP, #0x10
    // 0xc99608: tbnz            w0, #4, #0xc99684
    // 0xc9960c: ldr             x1, [fp, #0x18]
    // 0xc99610: ldr             x0, [fp, #0x10]
    // 0xc99614: LoadField: r2 = r0->field_b
    //     0xc99614: ldur            w2, [x0, #0xb]
    // 0xc99618: DecompressPointer r2
    //     0xc99618: add             x2, x2, HEAP, lsl #32
    // 0xc9961c: LoadField: r3 = r1->field_b
    //     0xc9961c: ldur            w3, [x1, #0xb]
    // 0xc99620: DecompressPointer r3
    //     0xc99620: add             x3, x3, HEAP, lsl #32
    // 0xc99624: stp             x3, x2, [SP, #-0x10]!
    // 0xc99628: r0 = ==()
    //     0xc99628: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc9962c: add             SP, SP, #0x10
    // 0xc99630: tbnz            w0, #4, #0xc99684
    // 0xc99634: ldr             x1, [fp, #0x18]
    // 0xc99638: ldr             x0, [fp, #0x10]
    // 0xc9963c: LoadField: r2 = r0->field_f
    //     0xc9963c: ldur            w2, [x0, #0xf]
    // 0xc99640: DecompressPointer r2
    //     0xc99640: add             x2, x2, HEAP, lsl #32
    // 0xc99644: LoadField: r3 = r1->field_f
    //     0xc99644: ldur            w3, [x1, #0xf]
    // 0xc99648: DecompressPointer r3
    //     0xc99648: add             x3, x3, HEAP, lsl #32
    // 0xc9964c: stp             x3, x2, [SP, #-0x10]!
    // 0xc99650: r0 = ==()
    //     0xc99650: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc99654: add             SP, SP, #0x10
    // 0xc99658: tbnz            w0, #4, #0xc99684
    // 0xc9965c: ldr             x1, [fp, #0x18]
    // 0xc99660: ldr             x0, [fp, #0x10]
    // 0xc99664: LoadField: r2 = r0->field_13
    //     0xc99664: ldur            w2, [x0, #0x13]
    // 0xc99668: DecompressPointer r2
    //     0xc99668: add             x2, x2, HEAP, lsl #32
    // 0xc9966c: LoadField: r0 = r1->field_13
    //     0xc9966c: ldur            w0, [x1, #0x13]
    // 0xc99670: DecompressPointer r0
    //     0xc99670: add             x0, x0, HEAP, lsl #32
    // 0xc99674: stp             x0, x2, [SP, #-0x10]!
    // 0xc99678: r0 = ==()
    //     0xc99678: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc9967c: add             SP, SP, #0x10
    // 0xc99680: b               #0xc99688
    // 0xc99684: r0 = false
    //     0xc99684: add             x0, NULL, #0x30  ; false
    // 0xc99688: LeaveFrame
    //     0xc99688: mov             SP, fp
    //     0xc9968c: ldp             fp, lr, [SP], #0x10
    // 0xc99690: ret
    //     0xc99690: ret             
    // 0xc99694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc99694: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc99698: b               #0xc99528
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0xceec00, size: 0x170
    // 0xceec00: EnterFrame
    //     0xceec00: stp             fp, lr, [SP, #-0x10]!
    //     0xceec04: mov             fp, SP
    // 0xceec08: AllocStack(0x20)
    //     0xceec08: sub             SP, SP, #0x20
    // 0xceec0c: ldr             x0, [fp, #0x10]
    // 0xceec10: LoadField: r1 = r0->field_7
    //     0xceec10: ldur            w1, [x0, #7]
    // 0xceec14: DecompressPointer r1
    //     0xceec14: add             x1, x1, HEAP, lsl #32
    // 0xceec18: LoadField: d0 = r1->field_b
    //     0xceec18: ldur            d0, [x1, #0xb]
    // 0xceec1c: LoadField: r2 = r0->field_b
    //     0xceec1c: ldur            w2, [x0, #0xb]
    // 0xceec20: DecompressPointer r2
    //     0xceec20: add             x2, x2, HEAP, lsl #32
    // 0xceec24: LoadField: d1 = r2->field_b
    //     0xceec24: ldur            d1, [x2, #0xb]
    // 0xceec28: fcmp            d1, d0
    // 0xceec2c: b.vs            #0xceecc0
    // 0xceec30: b.ne            #0xceecc0
    // 0xceec34: LoadField: r3 = r0->field_f
    //     0xceec34: ldur            w3, [x0, #0xf]
    // 0xceec38: DecompressPointer r3
    //     0xceec38: add             x3, x3, HEAP, lsl #32
    // 0xceec3c: LoadField: d2 = r3->field_b
    //     0xceec3c: ldur            d2, [x3, #0xb]
    // 0xceec40: fcmp            d2, d0
    // 0xceec44: b.vs            #0xceecb4
    // 0xceec48: b.ne            #0xceecb4
    // 0xceec4c: LoadField: r3 = r0->field_13
    //     0xceec4c: ldur            w3, [x0, #0x13]
    // 0xceec50: DecompressPointer r3
    //     0xceec50: add             x3, x3, HEAP, lsl #32
    // 0xceec54: LoadField: d2 = r3->field_b
    //     0xceec54: ldur            d2, [x3, #0xb]
    // 0xceec58: fcmp            d2, d0
    // 0xceec5c: b.vs            #0xceeca8
    // 0xceec60: b.ne            #0xceeca8
    // 0xceec64: d3 = 1.000000
    //     0xceec64: fmov            d3, #1.00000000
    // 0xceec68: d2 = 2.000000
    //     0xceec68: fmov            d2, #2.00000000
    // 0xceec6c: LoadField: d1 = r1->field_17
    //     0xceec6c: ldur            d1, [x1, #0x17]
    // 0xceec70: fadd            d4, d3, d1
    // 0xceec74: fdiv            d1, d4, d2
    // 0xceec78: fsub            d2, d3, d1
    // 0xceec7c: fmul            d1, d0, d2
    // 0xceec80: stur            d1, [fp, #-8]
    // 0xceec84: r0 = EdgeInsets()
    //     0xceec84: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xceec88: ldur            d0, [fp, #-8]
    // 0xceec8c: StoreField: r0->field_7 = d0
    //     0xceec8c: stur            d0, [x0, #7]
    // 0xceec90: StoreField: r0->field_f = d0
    //     0xceec90: stur            d0, [x0, #0xf]
    // 0xceec94: StoreField: r0->field_17 = d0
    //     0xceec94: stur            d0, [x0, #0x17]
    // 0xceec98: StoreField: r0->field_1f = d0
    //     0xceec98: stur            d0, [x0, #0x1f]
    // 0xceec9c: LeaveFrame
    //     0xceec9c: mov             SP, fp
    //     0xceeca0: ldp             fp, lr, [SP], #0x10
    // 0xceeca4: ret
    //     0xceeca4: ret             
    // 0xceeca8: d3 = 1.000000
    //     0xceeca8: fmov            d3, #1.00000000
    // 0xceecac: d2 = 2.000000
    //     0xceecac: fmov            d2, #2.00000000
    // 0xceecb0: b               #0xceecc8
    // 0xceecb4: d3 = 1.000000
    //     0xceecb4: fmov            d3, #1.00000000
    // 0xceecb8: d2 = 2.000000
    //     0xceecb8: fmov            d2, #2.00000000
    // 0xceecbc: b               #0xceecc8
    // 0xceecc0: d3 = 1.000000
    //     0xceecc0: fmov            d3, #1.00000000
    // 0xceecc4: d2 = 2.000000
    //     0xceecc4: fmov            d2, #2.00000000
    // 0xceecc8: LoadField: r3 = r0->field_13
    //     0xceecc8: ldur            w3, [x0, #0x13]
    // 0xceeccc: DecompressPointer r3
    //     0xceeccc: add             x3, x3, HEAP, lsl #32
    // 0xceecd0: LoadField: d4 = r3->field_b
    //     0xceecd0: ldur            d4, [x3, #0xb]
    // 0xceecd4: LoadField: d5 = r3->field_17
    //     0xceecd4: ldur            d5, [x3, #0x17]
    // 0xceecd8: fadd            d6, d3, d5
    // 0xceecdc: fdiv            d5, d6, d2
    // 0xceece0: fsub            d6, d3, d5
    // 0xceece4: fmul            d5, d4, d6
    // 0xceece8: stur            d5, [fp, #-0x20]
    // 0xceecec: LoadField: d4 = r1->field_17
    //     0xceecec: ldur            d4, [x1, #0x17]
    // 0xceecf0: fadd            d6, d3, d4
    // 0xceecf4: fdiv            d4, d6, d2
    // 0xceecf8: fsub            d6, d3, d4
    // 0xceecfc: fmul            d4, d0, d6
    // 0xceed00: stur            d4, [fp, #-0x18]
    // 0xceed04: LoadField: d0 = r2->field_17
    //     0xceed04: ldur            d0, [x2, #0x17]
    // 0xceed08: fadd            d6, d3, d0
    // 0xceed0c: fdiv            d0, d6, d2
    // 0xceed10: fsub            d6, d3, d0
    // 0xceed14: fmul            d0, d1, d6
    // 0xceed18: stur            d0, [fp, #-0x10]
    // 0xceed1c: LoadField: r1 = r0->field_f
    //     0xceed1c: ldur            w1, [x0, #0xf]
    // 0xceed20: DecompressPointer r1
    //     0xceed20: add             x1, x1, HEAP, lsl #32
    // 0xceed24: LoadField: d1 = r1->field_b
    //     0xceed24: ldur            d1, [x1, #0xb]
    // 0xceed28: LoadField: d6 = r1->field_17
    //     0xceed28: ldur            d6, [x1, #0x17]
    // 0xceed2c: fadd            d7, d3, d6
    // 0xceed30: fdiv            d6, d7, d2
    // 0xceed34: fsub            d2, d3, d6
    // 0xceed38: fmul            d3, d1, d2
    // 0xceed3c: stur            d3, [fp, #-8]
    // 0xceed40: r0 = EdgeInsets()
    //     0xceed40: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xceed44: ldur            d0, [fp, #-0x20]
    // 0xceed48: StoreField: r0->field_7 = d0
    //     0xceed48: stur            d0, [x0, #7]
    // 0xceed4c: ldur            d0, [fp, #-0x18]
    // 0xceed50: StoreField: r0->field_f = d0
    //     0xceed50: stur            d0, [x0, #0xf]
    // 0xceed54: ldur            d0, [fp, #-0x10]
    // 0xceed58: StoreField: r0->field_17 = d0
    //     0xceed58: stur            d0, [x0, #0x17]
    // 0xceed5c: ldur            d0, [fp, #-8]
    // 0xceed60: StoreField: r0->field_1f = d0
    //     0xceed60: stur            d0, [x0, #0x1f]
    // 0xceed64: LeaveFrame
    //     0xceed64: mov             SP, fp
    //     0xceed68: ldp             fp, lr, [SP], #0x10
    // 0xceed6c: ret
    //     0xceed6c: ret             
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf82f8, size: 0xec
    // 0xcf82f8: EnterFrame
    //     0xcf82f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf82fc: mov             fp, SP
    // 0xcf8300: AllocStack(0x20)
    //     0xcf8300: sub             SP, SP, #0x20
    // 0xcf8304: CheckStackOverflow
    //     0xcf8304: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf8308: cmp             SP, x16
    //     0xcf830c: b.ls            #0xcf83dc
    // 0xcf8310: ldr             x0, [fp, #0x18]
    // 0xcf8314: LoadField: r1 = r0->field_7
    //     0xcf8314: ldur            w1, [x0, #7]
    // 0xcf8318: DecompressPointer r1
    //     0xcf8318: add             x1, x1, HEAP, lsl #32
    // 0xcf831c: SaveReg r1
    //     0xcf831c: str             x1, [SP, #-8]!
    // 0xcf8320: ldr             d0, [fp, #0x10]
    // 0xcf8324: SaveReg d0
    //     0xcf8324: str             d0, [SP, #-8]!
    // 0xcf8328: r0 = scale()
    //     0xcf8328: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf832c: add             SP, SP, #0x10
    // 0xcf8330: mov             x1, x0
    // 0xcf8334: ldr             x0, [fp, #0x18]
    // 0xcf8338: stur            x1, [fp, #-8]
    // 0xcf833c: LoadField: r2 = r0->field_b
    //     0xcf833c: ldur            w2, [x0, #0xb]
    // 0xcf8340: DecompressPointer r2
    //     0xcf8340: add             x2, x2, HEAP, lsl #32
    // 0xcf8344: SaveReg r2
    //     0xcf8344: str             x2, [SP, #-8]!
    // 0xcf8348: ldr             d0, [fp, #0x10]
    // 0xcf834c: SaveReg d0
    //     0xcf834c: str             d0, [SP, #-8]!
    // 0xcf8350: r0 = scale()
    //     0xcf8350: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf8354: add             SP, SP, #0x10
    // 0xcf8358: mov             x1, x0
    // 0xcf835c: ldr             x0, [fp, #0x18]
    // 0xcf8360: stur            x1, [fp, #-0x10]
    // 0xcf8364: LoadField: r2 = r0->field_f
    //     0xcf8364: ldur            w2, [x0, #0xf]
    // 0xcf8368: DecompressPointer r2
    //     0xcf8368: add             x2, x2, HEAP, lsl #32
    // 0xcf836c: SaveReg r2
    //     0xcf836c: str             x2, [SP, #-8]!
    // 0xcf8370: ldr             d0, [fp, #0x10]
    // 0xcf8374: SaveReg d0
    //     0xcf8374: str             d0, [SP, #-8]!
    // 0xcf8378: r0 = scale()
    //     0xcf8378: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf837c: add             SP, SP, #0x10
    // 0xcf8380: mov             x1, x0
    // 0xcf8384: ldr             x0, [fp, #0x18]
    // 0xcf8388: stur            x1, [fp, #-0x18]
    // 0xcf838c: LoadField: r2 = r0->field_13
    //     0xcf838c: ldur            w2, [x0, #0x13]
    // 0xcf8390: DecompressPointer r2
    //     0xcf8390: add             x2, x2, HEAP, lsl #32
    // 0xcf8394: SaveReg r2
    //     0xcf8394: str             x2, [SP, #-8]!
    // 0xcf8398: ldr             d0, [fp, #0x10]
    // 0xcf839c: SaveReg d0
    //     0xcf839c: str             d0, [SP, #-8]!
    // 0xcf83a0: r0 = scale()
    //     0xcf83a0: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf83a4: add             SP, SP, #0x10
    // 0xcf83a8: stur            x0, [fp, #-0x20]
    // 0xcf83ac: r0 = Border()
    //     0xcf83ac: bl              #0x70e0c8  ; AllocateBorderStub -> Border (size=0x18)
    // 0xcf83b0: ldur            x1, [fp, #-8]
    // 0xcf83b4: StoreField: r0->field_7 = r1
    //     0xcf83b4: stur            w1, [x0, #7]
    // 0xcf83b8: ldur            x1, [fp, #-0x10]
    // 0xcf83bc: StoreField: r0->field_b = r1
    //     0xcf83bc: stur            w1, [x0, #0xb]
    // 0xcf83c0: ldur            x1, [fp, #-0x18]
    // 0xcf83c4: StoreField: r0->field_f = r1
    //     0xcf83c4: stur            w1, [x0, #0xf]
    // 0xcf83c8: ldur            x1, [fp, #-0x20]
    // 0xcf83cc: StoreField: r0->field_13 = r1
    //     0xcf83cc: stur            w1, [x0, #0x13]
    // 0xcf83d0: LeaveFrame
    //     0xcf83d0: mov             SP, fp
    //     0xcf83d4: ldp             fp, lr, [SP], #0x10
    // 0xcf83d8: ret
    //     0xcf83d8: ret             
    // 0xcf83dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf83dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf83e0: b               #0xcf8310
  }
}

// class id: 5935, size: 0x14, field offset: 0x14
enum BoxShape extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16920, size: 0x5c
    // 0xb16920: EnterFrame
    //     0xb16920: stp             fp, lr, [SP, #-0x10]!
    //     0xb16924: mov             fp, SP
    // 0xb16928: CheckStackOverflow
    //     0xb16928: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1692c: cmp             SP, x16
    //     0xb16930: b.ls            #0xb16974
    // 0xb16934: r1 = Null
    //     0xb16934: mov             x1, NULL
    // 0xb16938: r2 = 4
    //     0xb16938: mov             x2, #4
    // 0xb1693c: r0 = AllocateArray()
    //     0xb1693c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16940: r17 = "BoxShape."
    //     0xb16940: add             x17, PP, #0x15, lsl #12  ; [pp+0x154b0] "BoxShape."
    //     0xb16944: ldr             x17, [x17, #0x4b0]
    // 0xb16948: StoreField: r0->field_f = r17
    //     0xb16948: stur            w17, [x0, #0xf]
    // 0xb1694c: ldr             x1, [fp, #0x10]
    // 0xb16950: LoadField: r2 = r1->field_f
    //     0xb16950: ldur            w2, [x1, #0xf]
    // 0xb16954: DecompressPointer r2
    //     0xb16954: add             x2, x2, HEAP, lsl #32
    // 0xb16958: StoreField: r0->field_13 = r2
    //     0xb16958: stur            w2, [x0, #0x13]
    // 0xb1695c: SaveReg r0
    //     0xb1695c: str             x0, [SP, #-8]!
    // 0xb16960: r0 = _interpolate()
    //     0xb16960: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16964: add             SP, SP, #8
    // 0xb16968: LeaveFrame
    //     0xb16968: mov             SP, fp
    //     0xb1696c: ldp             fp, lr, [SP], #0x10
    // 0xb16970: ret
    //     0xb16970: ret             
    // 0xb16974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16974: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16978: b               #0xb16934
  }
}

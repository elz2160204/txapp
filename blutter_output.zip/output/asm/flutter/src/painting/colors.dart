// lib: , url: package:flutter/src/painting/colors.dart

// class id: 1049356, size: 0x8
class :: {

  static _ _colorFromHue(/* No info */) {
    // ** addr: 0xb64fdc, size: 0x3d0
    // 0xb64fdc: EnterFrame
    //     0xb64fdc: stp             fp, lr, [SP, #-0x10]!
    //     0xb64fe0: mov             fp, SP
    // 0xb64fe4: AllocStack(0x38)
    //     0xb64fe4: sub             SP, SP, #0x38
    // 0xb64fe8: d0 = 60.000000
    //     0xb64fe8: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0xb64fec: ldr             d0, [x17, #0x8c8]
    // 0xb64ff0: ldr             x0, [fp, #0x28]
    // 0xb64ff4: LoadField: d1 = r0->field_7
    //     0xb64ff4: ldur            d1, [x0, #7]
    // 0xb64ff8: fcmp            d1, d0
    // 0xb64ffc: b.vs            #0xb65024
    // 0xb65000: b.ge            #0xb65024
    // 0xb65004: ldr             x1, [fp, #0x20]
    // 0xb65008: ldr             x0, [fp, #0x18]
    // 0xb6500c: LoadField: d0 = r1->field_7
    //     0xb6500c: ldur            d0, [x1, #7]
    // 0xb65010: LoadField: d1 = r0->field_7
    //     0xb65010: ldur            d1, [x0, #7]
    // 0xb65014: mov             v5.16b, v0.16b
    // 0xb65018: mov             v4.16b, v1.16b
    // 0xb6501c: d3 = 0.000000
    //     0xb6501c: eor             v3.16b, v3.16b, v3.16b
    // 0xb65020: b               #0xb650f4
    // 0xb65024: ldr             x1, [fp, #0x20]
    // 0xb65028: ldr             x0, [fp, #0x18]
    // 0xb6502c: d0 = 120.000000
    //     0xb6502c: add             x17, PP, #0x31, lsl #12  ; [pp+0x311c0] IMM: double(120) from 0x405e000000000000
    //     0xb65030: ldr             d0, [x17, #0x1c0]
    // 0xb65034: fcmp            d1, d0
    // 0xb65038: b.vs            #0xb65058
    // 0xb6503c: b.ge            #0xb65058
    // 0xb65040: LoadField: d0 = r1->field_7
    //     0xb65040: ldur            d0, [x1, #7]
    // 0xb65044: LoadField: d1 = r0->field_7
    //     0xb65044: ldur            d1, [x0, #7]
    // 0xb65048: mov             v2.16b, v1.16b
    // 0xb6504c: mov             v1.16b, v0.16b
    // 0xb65050: d0 = 0.000000
    //     0xb65050: eor             v0.16b, v0.16b, v0.16b
    // 0xb65054: b               #0xb650e8
    // 0xb65058: d0 = 180.000000
    //     0xb65058: add             x17, PP, #0x34, lsl #12  ; [pp+0x34c60] IMM: double(180) from 0x4066800000000000
    //     0xb6505c: ldr             d0, [x17, #0xc60]
    // 0xb65060: fcmp            d1, d0
    // 0xb65064: b.vs            #0xb65088
    // 0xb65068: b.ge            #0xb65088
    // 0xb6506c: LoadField: d0 = r1->field_7
    //     0xb6506c: ldur            d0, [x1, #7]
    // 0xb65070: LoadField: d1 = r0->field_7
    //     0xb65070: ldur            d1, [x0, #7]
    // 0xb65074: mov             v31.16b, v1.16b
    // 0xb65078: mov             v1.16b, v0.16b
    // 0xb6507c: mov             v0.16b, v31.16b
    // 0xb65080: d2 = 0.000000
    //     0xb65080: eor             v2.16b, v2.16b, v2.16b
    // 0xb65084: b               #0xb650e8
    // 0xb65088: d0 = 240.000000
    //     0xb65088: add             x17, PP, #0x3c, lsl #12  ; [pp+0x3cb38] IMM: double(240) from 0x406e000000000000
    //     0xb6508c: ldr             d0, [x17, #0xb38]
    // 0xb65090: fcmp            d1, d0
    // 0xb65094: b.vs            #0xb650ac
    // 0xb65098: b.ge            #0xb650ac
    // 0xb6509c: LoadField: d0 = r1->field_7
    //     0xb6509c: ldur            d0, [x1, #7]
    // 0xb650a0: LoadField: d1 = r0->field_7
    //     0xb650a0: ldur            d1, [x0, #7]
    // 0xb650a4: d2 = 0.000000
    //     0xb650a4: eor             v2.16b, v2.16b, v2.16b
    // 0xb650a8: b               #0xb650e8
    // 0xb650ac: d0 = 300.000000
    //     0xb650ac: add             x17, PP, #0x34, lsl #12  ; [pp+0x34948] IMM: double(300) from 0x4072c00000000000
    //     0xb650b0: ldr             d0, [x17, #0x948]
    // 0xb650b4: fcmp            d1, d0
    // 0xb650b8: b.vs            #0xb650cc
    // 0xb650bc: b.ge            #0xb650cc
    // 0xb650c0: LoadField: d0 = r1->field_7
    //     0xb650c0: ldur            d0, [x1, #7]
    // 0xb650c4: LoadField: d1 = r0->field_7
    //     0xb650c4: ldur            d1, [x0, #7]
    // 0xb650c8: b               #0xb650e0
    // 0xb650cc: LoadField: d0 = r1->field_7
    //     0xb650cc: ldur            d0, [x1, #7]
    // 0xb650d0: LoadField: d1 = r0->field_7
    //     0xb650d0: ldur            d1, [x0, #7]
    // 0xb650d4: mov             v31.16b, v1.16b
    // 0xb650d8: mov             v1.16b, v0.16b
    // 0xb650dc: mov             v0.16b, v31.16b
    // 0xb650e0: mov             v2.16b, v1.16b
    // 0xb650e4: d1 = 0.000000
    //     0xb650e4: eor             v1.16b, v1.16b, v1.16b
    // 0xb650e8: mov             v5.16b, v2.16b
    // 0xb650ec: mov             v4.16b, v1.16b
    // 0xb650f0: mov             v3.16b, v0.16b
    // 0xb650f4: ldr             x0, [fp, #0x30]
    // 0xb650f8: ldr             d2, [fp, #0x10]
    // 0xb650fc: d1 = 255.000000
    //     0xb650fc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xb65100: ldr             d1, [x17, #0x200]
    // 0xb65104: stur            d5, [fp, #-0x28]
    // 0xb65108: stur            d4, [fp, #-0x30]
    // 0xb6510c: stur            d3, [fp, #-0x38]
    // 0xb65110: LoadField: d0 = r0->field_7
    //     0xb65110: ldur            d0, [x0, #7]
    // 0xb65114: fmul            d6, d0, d1
    // 0xb65118: mov             v0.16b, v6.16b
    // 0xb6511c: stp             fp, lr, [SP, #-0x10]!
    // 0xb65120: mov             fp, SP
    // 0xb65124: CallRuntime_LibcRound(double) -> double
    //     0xb65124: and             SP, SP, #0xfffffffffffffff0
    //     0xb65128: mov             sp, SP
    //     0xb6512c: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xb65130: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb65134: blr             x16
    //     0xb65138: mov             x16, #8
    //     0xb6513c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb65140: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xb65144: sub             sp, x16, #1, lsl #12
    //     0xb65148: mov             SP, fp
    //     0xb6514c: ldp             fp, lr, [SP], #0x10
    // 0xb65150: fcmp            d0, d0
    // 0xb65154: b.vs            #0xb6533c
    // 0xb65158: fcvtzs          x0, d0
    // 0xb6515c: asr             x16, x0, #0x1e
    // 0xb65160: cmp             x16, x0, asr #63
    // 0xb65164: b.ne            #0xb6533c
    // 0xb65168: lsl             x0, x0, #1
    // 0xb6516c: ldr             d1, [fp, #0x10]
    // 0xb65170: ldur            d0, [fp, #-0x28]
    // 0xb65174: stur            x0, [fp, #-8]
    // 0xb65178: fadd            d2, d0, d1
    // 0xb6517c: d3 = 255.000000
    //     0xb6517c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xb65180: ldr             d3, [x17, #0x200]
    // 0xb65184: fmul            d0, d2, d3
    // 0xb65188: stp             fp, lr, [SP, #-0x10]!
    // 0xb6518c: mov             fp, SP
    // 0xb65190: CallRuntime_LibcRound(double) -> double
    //     0xb65190: and             SP, SP, #0xfffffffffffffff0
    //     0xb65194: mov             sp, SP
    //     0xb65198: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xb6519c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb651a0: blr             x16
    //     0xb651a4: mov             x16, #8
    //     0xb651a8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb651ac: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xb651b0: sub             sp, x16, #1, lsl #12
    //     0xb651b4: mov             SP, fp
    //     0xb651b8: ldp             fp, lr, [SP], #0x10
    // 0xb651bc: fcmp            d0, d0
    // 0xb651c0: b.vs            #0xb65358
    // 0xb651c4: fcvtzs          x0, d0
    // 0xb651c8: asr             x16, x0, #0x1e
    // 0xb651cc: cmp             x16, x0, asr #63
    // 0xb651d0: b.ne            #0xb65358
    // 0xb651d4: lsl             x0, x0, #1
    // 0xb651d8: ldr             d1, [fp, #0x10]
    // 0xb651dc: ldur            d0, [fp, #-0x30]
    // 0xb651e0: stur            x0, [fp, #-0x10]
    // 0xb651e4: fadd            d2, d0, d1
    // 0xb651e8: d3 = 255.000000
    //     0xb651e8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xb651ec: ldr             d3, [x17, #0x200]
    // 0xb651f0: fmul            d0, d2, d3
    // 0xb651f4: stp             fp, lr, [SP, #-0x10]!
    // 0xb651f8: mov             fp, SP
    // 0xb651fc: CallRuntime_LibcRound(double) -> double
    //     0xb651fc: and             SP, SP, #0xfffffffffffffff0
    //     0xb65200: mov             sp, SP
    //     0xb65204: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xb65208: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb6520c: blr             x16
    //     0xb65210: mov             x16, #8
    //     0xb65214: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb65218: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xb6521c: sub             sp, x16, #1, lsl #12
    //     0xb65220: mov             SP, fp
    //     0xb65224: ldp             fp, lr, [SP], #0x10
    // 0xb65228: fcmp            d0, d0
    // 0xb6522c: b.vs            #0xb65374
    // 0xb65230: fcvtzs          x0, d0
    // 0xb65234: asr             x16, x0, #0x1e
    // 0xb65238: cmp             x16, x0, asr #63
    // 0xb6523c: b.ne            #0xb65374
    // 0xb65240: lsl             x0, x0, #1
    // 0xb65244: ldr             d0, [fp, #0x10]
    // 0xb65248: ldur            d1, [fp, #-0x38]
    // 0xb6524c: stur            x0, [fp, #-0x18]
    // 0xb65250: fadd            d2, d1, d0
    // 0xb65254: d0 = 255.000000
    //     0xb65254: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xb65258: ldr             d0, [x17, #0x200]
    // 0xb6525c: fmul            d1, d2, d0
    // 0xb65260: mov             v0.16b, v1.16b
    // 0xb65264: stp             fp, lr, [SP, #-0x10]!
    // 0xb65268: mov             fp, SP
    // 0xb6526c: CallRuntime_LibcRound(double) -> double
    //     0xb6526c: and             SP, SP, #0xfffffffffffffff0
    //     0xb65270: mov             sp, SP
    //     0xb65274: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xb65278: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb6527c: blr             x16
    //     0xb65280: mov             x16, #8
    //     0xb65284: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb65288: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xb6528c: sub             sp, x16, #1, lsl #12
    //     0xb65290: mov             SP, fp
    //     0xb65294: ldp             fp, lr, [SP], #0x10
    // 0xb65298: fcmp            d0, d0
    // 0xb6529c: b.vs            #0xb65390
    // 0xb652a0: fcvtzs          x0, d0
    // 0xb652a4: asr             x16, x0, #0x1e
    // 0xb652a8: cmp             x16, x0, asr #63
    // 0xb652ac: b.ne            #0xb65390
    // 0xb652b0: lsl             x0, x0, #1
    // 0xb652b4: ldur            x1, [fp, #-8]
    // 0xb652b8: r2 = LoadInt32Instr(r1)
    //     0xb652b8: sbfx            x2, x1, #1, #0x1f
    //     0xb652bc: tbz             w1, #0, #0xb652c4
    //     0xb652c0: ldur            x2, [x1, #7]
    // 0xb652c4: r1 = 255
    //     0xb652c4: mov             x1, #0xff
    // 0xb652c8: and             x3, x2, x1
    // 0xb652cc: lsl             w2, w3, #0x18
    // 0xb652d0: ldur            x3, [fp, #-0x10]
    // 0xb652d4: r4 = LoadInt32Instr(r3)
    //     0xb652d4: sbfx            x4, x3, #1, #0x1f
    //     0xb652d8: tbz             w3, #0, #0xb652e0
    //     0xb652dc: ldur            x4, [x3, #7]
    // 0xb652e0: and             x3, x4, x1
    // 0xb652e4: lsl             w4, w3, #0x10
    // 0xb652e8: orr             x3, x2, x4
    // 0xb652ec: ldur            x2, [fp, #-0x18]
    // 0xb652f0: r4 = LoadInt32Instr(r2)
    //     0xb652f0: sbfx            x4, x2, #1, #0x1f
    //     0xb652f4: tbz             w2, #0, #0xb652fc
    //     0xb652f8: ldur            x4, [x2, #7]
    // 0xb652fc: and             x2, x4, x1
    // 0xb65300: lsl             w4, w2, #8
    // 0xb65304: orr             x2, x3, x4
    // 0xb65308: r3 = LoadInt32Instr(r0)
    //     0xb65308: sbfx            x3, x0, #1, #0x1f
    //     0xb6530c: tbz             w0, #0, #0xb65314
    //     0xb65310: ldur            x3, [x0, #7]
    // 0xb65314: and             x0, x3, x1
    // 0xb65318: orr             x1, x2, x0
    // 0xb6531c: stur            x1, [fp, #-0x20]
    // 0xb65320: r0 = Color()
    //     0xb65320: bl              #0x595588  ; AllocateColorStub -> Color (size=0x10)
    // 0xb65324: ldur            x1, [fp, #-0x20]
    // 0xb65328: ubfx            x1, x1, #0, #0x20
    // 0xb6532c: StoreField: r0->field_7 = r1
    //     0xb6532c: stur            x1, [x0, #7]
    // 0xb65330: LeaveFrame
    //     0xb65330: mov             SP, fp
    //     0xb65334: ldp             fp, lr, [SP], #0x10
    // 0xb65338: ret
    //     0xb65338: ret             
    // 0xb6533c: SaveReg d0
    //     0xb6533c: str             q0, [SP, #-0x10]!
    // 0xb65340: r0 = 218
    //     0xb65340: mov             x0, #0xda
    // 0xb65344: r24 = DoubleToIntegerStub
    //     0xb65344: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xb65348: LoadField: r30 = r24->field_7
    //     0xb65348: ldur            lr, [x24, #7]
    // 0xb6534c: blr             lr
    // 0xb65350: RestoreReg d0
    //     0xb65350: ldr             q0, [SP], #0x10
    // 0xb65354: b               #0xb6516c
    // 0xb65358: SaveReg d0
    //     0xb65358: str             q0, [SP, #-0x10]!
    // 0xb6535c: r0 = 218
    //     0xb6535c: mov             x0, #0xda
    // 0xb65360: r24 = DoubleToIntegerStub
    //     0xb65360: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xb65364: LoadField: r30 = r24->field_7
    //     0xb65364: ldur            lr, [x24, #7]
    // 0xb65368: blr             lr
    // 0xb6536c: RestoreReg d0
    //     0xb6536c: ldr             q0, [SP], #0x10
    // 0xb65370: b               #0xb651d8
    // 0xb65374: SaveReg d0
    //     0xb65374: str             q0, [SP, #-0x10]!
    // 0xb65378: r0 = 218
    //     0xb65378: mov             x0, #0xda
    // 0xb6537c: r24 = DoubleToIntegerStub
    //     0xb6537c: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xb65380: LoadField: r30 = r24->field_7
    //     0xb65380: ldur            lr, [x24, #7]
    // 0xb65384: blr             lr
    // 0xb65388: RestoreReg d0
    //     0xb65388: ldr             q0, [SP], #0x10
    // 0xb6538c: b               #0xb65244
    // 0xb65390: SaveReg d0
    //     0xb65390: str             q0, [SP, #-0x10]!
    // 0xb65394: r0 = 218
    //     0xb65394: mov             x0, #0xda
    // 0xb65398: r24 = DoubleToIntegerStub
    //     0xb65398: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xb6539c: LoadField: r30 = r24->field_7
    //     0xb6539c: ldur            lr, [x24, #7]
    // 0xb653a0: blr             lr
    // 0xb653a4: RestoreReg d0
    //     0xb653a4: ldr             q0, [SP], #0x10
    // 0xb653a8: b               #0xb652b4
  }
}

// class id: 2106, size: 0x28, field offset: 0x8
//   const constructor, 
class HSLColor extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xae0a80, size: 0x22c
    // 0xae0a80: EnterFrame
    //     0xae0a80: stp             fp, lr, [SP, #-0x10]!
    //     0xae0a84: mov             fp, SP
    // 0xae0a88: CheckStackOverflow
    //     0xae0a88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae0a8c: cmp             SP, x16
    //     0xae0a90: b.ls            #0xae0c44
    // 0xae0a94: r1 = Null
    //     0xae0a94: mov             x1, NULL
    // 0xae0a98: r2 = 20
    //     0xae0a98: mov             x2, #0x14
    // 0xae0a9c: r0 = AllocateArray()
    //     0xae0a9c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae0aa0: mov             x2, x0
    // 0xae0aa4: r17 = "HSLColor"
    //     0xae0aa4: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b450] "HSLColor"
    //     0xae0aa8: ldr             x17, [x17, #0x450]
    // 0xae0aac: StoreField: r2->field_f = r17
    //     0xae0aac: stur            w17, [x2, #0xf]
    // 0xae0ab0: r17 = "("
    //     0xae0ab0: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xae0ab4: StoreField: r2->field_13 = r17
    //     0xae0ab4: stur            w17, [x2, #0x13]
    // 0xae0ab8: ldr             x3, [fp, #0x10]
    // 0xae0abc: LoadField: d0 = r3->field_7
    //     0xae0abc: ldur            d0, [x3, #7]
    // 0xae0ac0: r0 = inline_Allocate_Double()
    //     0xae0ac0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae0ac4: add             x0, x0, #0x10
    //     0xae0ac8: cmp             x1, x0
    //     0xae0acc: b.ls            #0xae0c4c
    //     0xae0ad0: str             x0, [THR, #0x60]  ; THR::top
    //     0xae0ad4: sub             x0, x0, #0xf
    //     0xae0ad8: mov             x1, #0xd108
    //     0xae0adc: movk            x1, #3, lsl #16
    //     0xae0ae0: stur            x1, [x0, #-1]
    // 0xae0ae4: StoreField: r0->field_7 = d0
    //     0xae0ae4: stur            d0, [x0, #7]
    // 0xae0ae8: mov             x1, x2
    // 0xae0aec: ArrayStore: r1[2] = r0  ; List_4
    //     0xae0aec: add             x25, x1, #0x17
    //     0xae0af0: str             w0, [x25]
    //     0xae0af4: tbz             w0, #0, #0xae0b10
    //     0xae0af8: ldurb           w16, [x1, #-1]
    //     0xae0afc: ldurb           w17, [x0, #-1]
    //     0xae0b00: and             x16, x17, x16, lsr #2
    //     0xae0b04: tst             x16, HEAP, lsr #32
    //     0xae0b08: b.eq            #0xae0b10
    //     0xae0b0c: bl              #0xd67e5c
    // 0xae0b10: r17 = ", "
    //     0xae0b10: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae0b14: StoreField: r2->field_1b = r17
    //     0xae0b14: stur            w17, [x2, #0x1b]
    // 0xae0b18: LoadField: d0 = r3->field_f
    //     0xae0b18: ldur            d0, [x3, #0xf]
    // 0xae0b1c: r0 = inline_Allocate_Double()
    //     0xae0b1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae0b20: add             x0, x0, #0x10
    //     0xae0b24: cmp             x1, x0
    //     0xae0b28: b.ls            #0xae0c64
    //     0xae0b2c: str             x0, [THR, #0x60]  ; THR::top
    //     0xae0b30: sub             x0, x0, #0xf
    //     0xae0b34: mov             x1, #0xd108
    //     0xae0b38: movk            x1, #3, lsl #16
    //     0xae0b3c: stur            x1, [x0, #-1]
    // 0xae0b40: StoreField: r0->field_7 = d0
    //     0xae0b40: stur            d0, [x0, #7]
    // 0xae0b44: mov             x1, x2
    // 0xae0b48: ArrayStore: r1[4] = r0  ; List_4
    //     0xae0b48: add             x25, x1, #0x1f
    //     0xae0b4c: str             w0, [x25]
    //     0xae0b50: tbz             w0, #0, #0xae0b6c
    //     0xae0b54: ldurb           w16, [x1, #-1]
    //     0xae0b58: ldurb           w17, [x0, #-1]
    //     0xae0b5c: and             x16, x17, x16, lsr #2
    //     0xae0b60: tst             x16, HEAP, lsr #32
    //     0xae0b64: b.eq            #0xae0b6c
    //     0xae0b68: bl              #0xd67e5c
    // 0xae0b6c: r17 = ", "
    //     0xae0b6c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae0b70: StoreField: r2->field_23 = r17
    //     0xae0b70: stur            w17, [x2, #0x23]
    // 0xae0b74: LoadField: d0 = r3->field_17
    //     0xae0b74: ldur            d0, [x3, #0x17]
    // 0xae0b78: r0 = inline_Allocate_Double()
    //     0xae0b78: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae0b7c: add             x0, x0, #0x10
    //     0xae0b80: cmp             x1, x0
    //     0xae0b84: b.ls            #0xae0c7c
    //     0xae0b88: str             x0, [THR, #0x60]  ; THR::top
    //     0xae0b8c: sub             x0, x0, #0xf
    //     0xae0b90: mov             x1, #0xd108
    //     0xae0b94: movk            x1, #3, lsl #16
    //     0xae0b98: stur            x1, [x0, #-1]
    // 0xae0b9c: StoreField: r0->field_7 = d0
    //     0xae0b9c: stur            d0, [x0, #7]
    // 0xae0ba0: mov             x1, x2
    // 0xae0ba4: ArrayStore: r1[6] = r0  ; List_4
    //     0xae0ba4: add             x25, x1, #0x27
    //     0xae0ba8: str             w0, [x25]
    //     0xae0bac: tbz             w0, #0, #0xae0bc8
    //     0xae0bb0: ldurb           w16, [x1, #-1]
    //     0xae0bb4: ldurb           w17, [x0, #-1]
    //     0xae0bb8: and             x16, x17, x16, lsr #2
    //     0xae0bbc: tst             x16, HEAP, lsr #32
    //     0xae0bc0: b.eq            #0xae0bc8
    //     0xae0bc4: bl              #0xd67e5c
    // 0xae0bc8: r17 = ", "
    //     0xae0bc8: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae0bcc: StoreField: r2->field_2b = r17
    //     0xae0bcc: stur            w17, [x2, #0x2b]
    // 0xae0bd0: LoadField: d0 = r3->field_1f
    //     0xae0bd0: ldur            d0, [x3, #0x1f]
    // 0xae0bd4: r0 = inline_Allocate_Double()
    //     0xae0bd4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae0bd8: add             x0, x0, #0x10
    //     0xae0bdc: cmp             x1, x0
    //     0xae0be0: b.ls            #0xae0c94
    //     0xae0be4: str             x0, [THR, #0x60]  ; THR::top
    //     0xae0be8: sub             x0, x0, #0xf
    //     0xae0bec: mov             x1, #0xd108
    //     0xae0bf0: movk            x1, #3, lsl #16
    //     0xae0bf4: stur            x1, [x0, #-1]
    // 0xae0bf8: StoreField: r0->field_7 = d0
    //     0xae0bf8: stur            d0, [x0, #7]
    // 0xae0bfc: mov             x1, x2
    // 0xae0c00: ArrayStore: r1[8] = r0  ; List_4
    //     0xae0c00: add             x25, x1, #0x2f
    //     0xae0c04: str             w0, [x25]
    //     0xae0c08: tbz             w0, #0, #0xae0c24
    //     0xae0c0c: ldurb           w16, [x1, #-1]
    //     0xae0c10: ldurb           w17, [x0, #-1]
    //     0xae0c14: and             x16, x17, x16, lsr #2
    //     0xae0c18: tst             x16, HEAP, lsr #32
    //     0xae0c1c: b.eq            #0xae0c24
    //     0xae0c20: bl              #0xd67e5c
    // 0xae0c24: r17 = ")"
    //     0xae0c24: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae0c28: StoreField: r2->field_33 = r17
    //     0xae0c28: stur            w17, [x2, #0x33]
    // 0xae0c2c: SaveReg r2
    //     0xae0c2c: str             x2, [SP, #-8]!
    // 0xae0c30: r0 = _interpolate()
    //     0xae0c30: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae0c34: add             SP, SP, #8
    // 0xae0c38: LeaveFrame
    //     0xae0c38: mov             SP, fp
    //     0xae0c3c: ldp             fp, lr, [SP], #0x10
    // 0xae0c40: ret
    //     0xae0c40: ret             
    // 0xae0c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae0c44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae0c48: b               #0xae0a94
    // 0xae0c4c: SaveReg d0
    //     0xae0c4c: str             q0, [SP, #-0x10]!
    // 0xae0c50: stp             x2, x3, [SP, #-0x10]!
    // 0xae0c54: r0 = AllocateDouble()
    //     0xae0c54: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae0c58: ldp             x2, x3, [SP], #0x10
    // 0xae0c5c: RestoreReg d0
    //     0xae0c5c: ldr             q0, [SP], #0x10
    // 0xae0c60: b               #0xae0ae4
    // 0xae0c64: SaveReg d0
    //     0xae0c64: str             q0, [SP, #-0x10]!
    // 0xae0c68: stp             x2, x3, [SP, #-0x10]!
    // 0xae0c6c: r0 = AllocateDouble()
    //     0xae0c6c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae0c70: ldp             x2, x3, [SP], #0x10
    // 0xae0c74: RestoreReg d0
    //     0xae0c74: ldr             q0, [SP], #0x10
    // 0xae0c78: b               #0xae0b40
    // 0xae0c7c: SaveReg d0
    //     0xae0c7c: str             q0, [SP, #-0x10]!
    // 0xae0c80: stp             x2, x3, [SP, #-0x10]!
    // 0xae0c84: r0 = AllocateDouble()
    //     0xae0c84: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae0c88: ldp             x2, x3, [SP], #0x10
    // 0xae0c8c: RestoreReg d0
    //     0xae0c8c: ldr             q0, [SP], #0x10
    // 0xae0c90: b               #0xae0b9c
    // 0xae0c94: SaveReg d0
    //     0xae0c94: str             q0, [SP, #-0x10]!
    // 0xae0c98: SaveReg r2
    //     0xae0c98: str             x2, [SP, #-8]!
    // 0xae0c9c: r0 = AllocateDouble()
    //     0xae0c9c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae0ca0: RestoreReg r2
    //     0xae0ca0: ldr             x2, [SP], #8
    // 0xae0ca4: RestoreReg d0
    //     0xae0ca4: ldr             q0, [SP], #0x10
    // 0xae0ca8: b               #0xae0bf8
  }
  _ toColor(/* No info */) {
    // ** addr: 0xb64d58, size: 0x284
    // 0xb64d58: EnterFrame
    //     0xb64d58: stp             fp, lr, [SP, #-0x10]!
    //     0xb64d5c: mov             fp, SP
    // 0xb64d60: AllocStack(0x18)
    //     0xb64d60: sub             SP, SP, #0x18
    // 0xb64d64: d4 = 2.000000
    //     0xb64d64: fmov            d4, #2.00000000
    // 0xb64d68: d3 = 1.000000
    //     0xb64d68: fmov            d3, #1.00000000
    // 0xb64d6c: d2 = 0.000000
    //     0xb64d6c: eor             v2.16b, v2.16b, v2.16b
    // 0xb64d70: CheckStackOverflow
    //     0xb64d70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb64d74: cmp             SP, x16
    //     0xb64d78: b.ls            #0xb64f48
    // 0xb64d7c: ldr             x0, [fp, #0x10]
    // 0xb64d80: LoadField: d5 = r0->field_1f
    //     0xb64d80: ldur            d5, [x0, #0x1f]
    // 0xb64d84: stur            d5, [fp, #-0x18]
    // 0xb64d88: fmul            d0, d4, d5
    // 0xb64d8c: fsub            d1, d0, d3
    // 0xb64d90: fcmp            d1, d2
    // 0xb64d94: b.vs            #0xb64da4
    // 0xb64d98: b.ne            #0xb64da4
    // 0xb64d9c: d1 = 0.000000
    //     0xb64d9c: eor             v1.16b, v1.16b, v1.16b
    // 0xb64da0: b               #0xb64dc0
    // 0xb64da4: fcmp            d1, d2
    // 0xb64da8: b.vs            #0xb64db8
    // 0xb64dac: b.ge            #0xb64db8
    // 0xb64db0: fneg            d0, d1
    // 0xb64db4: b               #0xb64dbc
    // 0xb64db8: mov             v0.16b, v1.16b
    // 0xb64dbc: mov             v1.16b, v0.16b
    // 0xb64dc0: d0 = 60.000000
    //     0xb64dc0: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0xb64dc4: ldr             d0, [x17, #0x8c8]
    // 0xb64dc8: fsub            d6, d3, d1
    // 0xb64dcc: LoadField: d1 = r0->field_17
    //     0xb64dcc: ldur            d1, [x0, #0x17]
    // 0xb64dd0: fmul            d7, d6, d1
    // 0xb64dd4: stur            d7, [fp, #-0x10]
    // 0xb64dd8: LoadField: d6 = r0->field_f
    //     0xb64dd8: ldur            d6, [x0, #0xf]
    // 0xb64ddc: stur            d6, [fp, #-8]
    // 0xb64de0: fdiv            d1, d6, d0
    // 0xb64de4: mov             v0.16b, v1.16b
    // 0xb64de8: mov             v1.16b, v4.16b
    // 0xb64dec: stp             fp, lr, [SP, #-0x10]!
    // 0xb64df0: mov             fp, SP
    // 0xb64df4: CallRuntime_DartModulo(double, double) -> double
    //     0xb64df4: and             SP, SP, #0xfffffffffffffff0
    //     0xb64df8: mov             sp, SP
    //     0xb64dfc: ldr             x16, [THR, #0x558]  ; THR::DartModulo
    //     0xb64e00: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb64e04: blr             x16
    //     0xb64e08: mov             x16, #8
    //     0xb64e0c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xb64e10: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xb64e14: sub             sp, x16, #1, lsl #12
    //     0xb64e18: mov             SP, fp
    //     0xb64e1c: ldp             fp, lr, [SP], #0x10
    // 0xb64e20: mov             v1.16b, v0.16b
    // 0xb64e24: d0 = 1.000000
    //     0xb64e24: fmov            d0, #1.00000000
    // 0xb64e28: fsub            d2, d1, d0
    // 0xb64e2c: d1 = 0.000000
    //     0xb64e2c: eor             v1.16b, v1.16b, v1.16b
    // 0xb64e30: fcmp            d2, d1
    // 0xb64e34: b.vs            #0xb64e44
    // 0xb64e38: b.ne            #0xb64e44
    // 0xb64e3c: d5 = 0.000000
    //     0xb64e3c: eor             v5.16b, v5.16b, v5.16b
    // 0xb64e40: b               #0xb64e60
    // 0xb64e44: fcmp            d2, d1
    // 0xb64e48: b.vs            #0xb64e58
    // 0xb64e4c: b.ge            #0xb64e58
    // 0xb64e50: fneg            d1, d2
    // 0xb64e54: b               #0xb64e5c
    // 0xb64e58: mov             v1.16b, v2.16b
    // 0xb64e5c: mov             v5.16b, v1.16b
    // 0xb64e60: ldr             x0, [fp, #0x10]
    // 0xb64e64: ldur            d2, [fp, #-0x18]
    // 0xb64e68: ldur            d3, [fp, #-0x10]
    // 0xb64e6c: ldur            d4, [fp, #-8]
    // 0xb64e70: d1 = 2.000000
    //     0xb64e70: fmov            d1, #2.00000000
    // 0xb64e74: fsub            d6, d0, d5
    // 0xb64e78: fmul            d0, d3, d6
    // 0xb64e7c: fdiv            d5, d3, d1
    // 0xb64e80: fsub            d1, d2, d5
    // 0xb64e84: LoadField: d2 = r0->field_7
    //     0xb64e84: ldur            d2, [x0, #7]
    // 0xb64e88: r0 = inline_Allocate_Double()
    //     0xb64e88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb64e8c: add             x0, x0, #0x10
    //     0xb64e90: cmp             x1, x0
    //     0xb64e94: b.ls            #0xb64f50
    //     0xb64e98: str             x0, [THR, #0x60]  ; THR::top
    //     0xb64e9c: sub             x0, x0, #0xf
    //     0xb64ea0: mov             x1, #0xd108
    //     0xb64ea4: movk            x1, #3, lsl #16
    //     0xb64ea8: stur            x1, [x0, #-1]
    // 0xb64eac: StoreField: r0->field_7 = d3
    //     0xb64eac: stur            d3, [x0, #7]
    // 0xb64eb0: r1 = inline_Allocate_Double()
    //     0xb64eb0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb64eb4: add             x1, x1, #0x10
    //     0xb64eb8: cmp             x2, x1
    //     0xb64ebc: b.ls            #0xb64f70
    //     0xb64ec0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb64ec4: sub             x1, x1, #0xf
    //     0xb64ec8: mov             x2, #0xd108
    //     0xb64ecc: movk            x2, #3, lsl #16
    //     0xb64ed0: stur            x2, [x1, #-1]
    // 0xb64ed4: StoreField: r1->field_7 = d0
    //     0xb64ed4: stur            d0, [x1, #7]
    // 0xb64ed8: r2 = inline_Allocate_Double()
    //     0xb64ed8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb64edc: add             x2, x2, #0x10
    //     0xb64ee0: cmp             x3, x2
    //     0xb64ee4: b.ls            #0xb64f94
    //     0xb64ee8: str             x2, [THR, #0x60]  ; THR::top
    //     0xb64eec: sub             x2, x2, #0xf
    //     0xb64ef0: mov             x3, #0xd108
    //     0xb64ef4: movk            x3, #3, lsl #16
    //     0xb64ef8: stur            x3, [x2, #-1]
    // 0xb64efc: StoreField: r2->field_7 = d2
    //     0xb64efc: stur            d2, [x2, #7]
    // 0xb64f00: r3 = inline_Allocate_Double()
    //     0xb64f00: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb64f04: add             x3, x3, #0x10
    //     0xb64f08: cmp             x4, x3
    //     0xb64f0c: b.ls            #0xb64fb8
    //     0xb64f10: str             x3, [THR, #0x60]  ; THR::top
    //     0xb64f14: sub             x3, x3, #0xf
    //     0xb64f18: mov             x4, #0xd108
    //     0xb64f1c: movk            x4, #3, lsl #16
    //     0xb64f20: stur            x4, [x3, #-1]
    // 0xb64f24: StoreField: r3->field_7 = d4
    //     0xb64f24: stur            d4, [x3, #7]
    // 0xb64f28: stp             x3, x2, [SP, #-0x10]!
    // 0xb64f2c: stp             x1, x0, [SP, #-0x10]!
    // 0xb64f30: SaveReg d1
    //     0xb64f30: str             d1, [SP, #-8]!
    // 0xb64f34: r0 = _colorFromHue()
    //     0xb64f34: bl              #0xb64fdc  ; [package:flutter/src/painting/colors.dart] ::_colorFromHue
    // 0xb64f38: add             SP, SP, #0x28
    // 0xb64f3c: LeaveFrame
    //     0xb64f3c: mov             SP, fp
    //     0xb64f40: ldp             fp, lr, [SP], #0x10
    // 0xb64f44: ret
    //     0xb64f44: ret             
    // 0xb64f48: r0 = StackOverflowSharedWithFPURegs()
    //     0xb64f48: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xb64f4c: b               #0xb64d7c
    // 0xb64f50: stp             q3, q4, [SP, #-0x20]!
    // 0xb64f54: stp             q1, q2, [SP, #-0x20]!
    // 0xb64f58: SaveReg d0
    //     0xb64f58: str             q0, [SP, #-0x10]!
    // 0xb64f5c: r0 = AllocateDouble()
    //     0xb64f5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb64f60: RestoreReg d0
    //     0xb64f60: ldr             q0, [SP], #0x10
    // 0xb64f64: ldp             q1, q2, [SP], #0x20
    // 0xb64f68: ldp             q3, q4, [SP], #0x20
    // 0xb64f6c: b               #0xb64eac
    // 0xb64f70: stp             q2, q4, [SP, #-0x20]!
    // 0xb64f74: stp             q0, q1, [SP, #-0x20]!
    // 0xb64f78: SaveReg r0
    //     0xb64f78: str             x0, [SP, #-8]!
    // 0xb64f7c: r0 = AllocateDouble()
    //     0xb64f7c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb64f80: mov             x1, x0
    // 0xb64f84: RestoreReg r0
    //     0xb64f84: ldr             x0, [SP], #8
    // 0xb64f88: ldp             q0, q1, [SP], #0x20
    // 0xb64f8c: ldp             q2, q4, [SP], #0x20
    // 0xb64f90: b               #0xb64ed4
    // 0xb64f94: stp             q2, q4, [SP, #-0x20]!
    // 0xb64f98: SaveReg d1
    //     0xb64f98: str             q1, [SP, #-0x10]!
    // 0xb64f9c: stp             x0, x1, [SP, #-0x10]!
    // 0xb64fa0: r0 = AllocateDouble()
    //     0xb64fa0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb64fa4: mov             x2, x0
    // 0xb64fa8: ldp             x0, x1, [SP], #0x10
    // 0xb64fac: RestoreReg d1
    //     0xb64fac: ldr             q1, [SP], #0x10
    // 0xb64fb0: ldp             q2, q4, [SP], #0x20
    // 0xb64fb4: b               #0xb64efc
    // 0xb64fb8: stp             q1, q4, [SP, #-0x20]!
    // 0xb64fbc: stp             x1, x2, [SP, #-0x10]!
    // 0xb64fc0: SaveReg r0
    //     0xb64fc0: str             x0, [SP, #-8]!
    // 0xb64fc4: r0 = AllocateDouble()
    //     0xb64fc4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb64fc8: mov             x3, x0
    // 0xb64fcc: RestoreReg r0
    //     0xb64fcc: ldr             x0, [SP], #8
    // 0xb64fd0: ldp             x1, x2, [SP], #0x10
    // 0xb64fd4: ldp             q1, q4, [SP], #0x20
    // 0xb64fd8: b               #0xb64f24
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9d0b0, size: 0xb4
    // 0xc9d0b0: ldr             x1, [SP]
    // 0xc9d0b4: cmp             w1, NULL
    // 0xc9d0b8: b.ne            #0xc9d0c4
    // 0xc9d0bc: r0 = false
    //     0xc9d0bc: add             x0, NULL, #0x30  ; false
    // 0xc9d0c0: ret
    //     0xc9d0c0: ret             
    // 0xc9d0c4: ldr             x2, [SP, #8]
    // 0xc9d0c8: cmp             w2, w1
    // 0xc9d0cc: b.ne            #0xc9d0d8
    // 0xc9d0d0: r0 = true
    //     0xc9d0d0: add             x0, NULL, #0x20  ; true
    // 0xc9d0d4: ret
    //     0xc9d0d4: ret             
    // 0xc9d0d8: r3 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9d0d8: mov             x3, #0x76
    //     0xc9d0dc: tbz             w1, #0, #0xc9d0ec
    //     0xc9d0e0: ldur            x3, [x1, #-1]
    //     0xc9d0e4: ubfx            x3, x3, #0xc, #0x14
    //     0xc9d0e8: lsl             x3, x3, #1
    // 0xc9d0ec: r17 = 4212
    //     0xc9d0ec: mov             x17, #0x1074
    // 0xc9d0f0: cmp             w3, w17
    // 0xc9d0f4: b.ne            #0xc9d15c
    // 0xc9d0f8: LoadField: d0 = r1->field_7
    //     0xc9d0f8: ldur            d0, [x1, #7]
    // 0xc9d0fc: LoadField: d1 = r2->field_7
    //     0xc9d0fc: ldur            d1, [x2, #7]
    // 0xc9d100: fcmp            d0, d1
    // 0xc9d104: b.vs            #0xc9d15c
    // 0xc9d108: b.ne            #0xc9d15c
    // 0xc9d10c: LoadField: d0 = r1->field_f
    //     0xc9d10c: ldur            d0, [x1, #0xf]
    // 0xc9d110: LoadField: d1 = r2->field_f
    //     0xc9d110: ldur            d1, [x2, #0xf]
    // 0xc9d114: fcmp            d0, d1
    // 0xc9d118: b.vs            #0xc9d15c
    // 0xc9d11c: b.ne            #0xc9d15c
    // 0xc9d120: LoadField: d0 = r1->field_17
    //     0xc9d120: ldur            d0, [x1, #0x17]
    // 0xc9d124: LoadField: d1 = r2->field_17
    //     0xc9d124: ldur            d1, [x2, #0x17]
    // 0xc9d128: fcmp            d0, d1
    // 0xc9d12c: b.vs            #0xc9d15c
    // 0xc9d130: b.ne            #0xc9d15c
    // 0xc9d134: LoadField: d0 = r1->field_1f
    //     0xc9d134: ldur            d0, [x1, #0x1f]
    // 0xc9d138: LoadField: d1 = r2->field_1f
    //     0xc9d138: ldur            d1, [x2, #0x1f]
    // 0xc9d13c: fcmp            d0, d1
    // 0xc9d140: b.vs            #0xc9d148
    // 0xc9d144: b.eq            #0xc9d150
    // 0xc9d148: r1 = false
    //     0xc9d148: add             x1, NULL, #0x30  ; false
    // 0xc9d14c: b               #0xc9d154
    // 0xc9d150: r1 = true
    //     0xc9d150: add             x1, NULL, #0x20  ; true
    // 0xc9d154: mov             x0, x1
    // 0xc9d158: b               #0xc9d160
    // 0xc9d15c: r0 = false
    //     0xc9d15c: add             x0, NULL, #0x30  ; false
    // 0xc9d160: ret
    //     0xc9d160: ret             
  }
}

// class id: 5060, size: 0x18, field offset: 0x10
//   const constructor, 
abstract class ColorSwatch<X0> extends Color {

  Color? [](ColorSwatch<X0>, X0) {
    // ** addr: 0x673b3c, size: 0x94
    // 0x673b3c: EnterFrame
    //     0x673b3c: stp             fp, lr, [SP, #-0x10]!
    //     0x673b40: mov             fp, SP
    // 0x673b44: CheckStackOverflow
    //     0x673b44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x673b48: cmp             SP, x16
    //     0x673b4c: b.ls            #0x673bb0
    // 0x673b50: ldr             x3, [fp, #0x18]
    // 0x673b54: LoadField: r2 = r3->field_f
    //     0x673b54: ldur            w2, [x3, #0xf]
    // 0x673b58: DecompressPointer r2
    //     0x673b58: add             x2, x2, HEAP, lsl #32
    // 0x673b5c: ldr             x0, [fp, #0x10]
    // 0x673b60: r1 = Null
    //     0x673b60: mov             x1, NULL
    // 0x673b64: cmp             w2, NULL
    // 0x673b68: b.eq            #0x673b88
    // 0x673b6c: LoadField: r4 = r2->field_17
    //     0x673b6c: ldur            w4, [x2, #0x17]
    // 0x673b70: DecompressPointer r4
    //     0x673b70: add             x4, x4, HEAP, lsl #32
    // 0x673b74: r8 = X0
    //     0x673b74: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x673b78: LoadField: r9 = r4->field_7
    //     0x673b78: ldur            x9, [x4, #7]
    // 0x673b7c: r3 = Null
    //     0x673b7c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd270] Null
    //     0x673b80: ldr             x3, [x3, #0x270]
    // 0x673b84: blr             x9
    // 0x673b88: ldr             x0, [fp, #0x18]
    // 0x673b8c: LoadField: r1 = r0->field_13
    //     0x673b8c: ldur            w1, [x0, #0x13]
    // 0x673b90: DecompressPointer r1
    //     0x673b90: add             x1, x1, HEAP, lsl #32
    // 0x673b94: ldr             x16, [fp, #0x10]
    // 0x673b98: stp             x16, x1, [SP, #-0x10]!
    // 0x673b9c: r0 = []()
    //     0x673b9c: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x673ba0: add             SP, SP, #0x10
    // 0x673ba4: LeaveFrame
    //     0x673ba4: mov             SP, fp
    //     0x673ba8: ldp             fp, lr, [SP], #0x10
    // 0x673bac: ret
    //     0x673bac: ret             
    // 0x673bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x673bb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x673bb4: b               #0x673b50
  }
  _ toString(/* No info */) {
    // ** addr: 0xabfbac, size: 0xa4
    // 0xabfbac: EnterFrame
    //     0xabfbac: stp             fp, lr, [SP, #-0x10]!
    //     0xabfbb0: mov             fp, SP
    // 0xabfbb4: AllocStack(0x8)
    //     0xabfbb4: sub             SP, SP, #8
    // 0xabfbb8: CheckStackOverflow
    //     0xabfbb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xabfbbc: cmp             SP, x16
    //     0xabfbc0: b.ls            #0xabfc48
    // 0xabfbc4: r1 = Null
    //     0xabfbc4: mov             x1, NULL
    // 0xabfbc8: r2 = 8
    //     0xabfbc8: mov             x2, #8
    // 0xabfbcc: r0 = AllocateArray()
    //     0xabfbcc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabfbd0: stur            x0, [fp, #-8]
    // 0xabfbd4: r17 = "ColorSwatch"
    //     0xabfbd4: add             x17, PP, #0xd, lsl #12  ; [pp+0xde88] "ColorSwatch"
    //     0xabfbd8: ldr             x17, [x17, #0xe88]
    // 0xabfbdc: StoreField: r0->field_f = r17
    //     0xabfbdc: stur            w17, [x0, #0xf]
    // 0xabfbe0: r17 = "(primary value: "
    //     0xabfbe0: add             x17, PP, #0xd, lsl #12  ; [pp+0xde90] "(primary value: "
    //     0xabfbe4: ldr             x17, [x17, #0xe90]
    // 0xabfbe8: StoreField: r0->field_13 = r17
    //     0xabfbe8: stur            w17, [x0, #0x13]
    // 0xabfbec: ldr             x16, [fp, #0x10]
    // 0xabfbf0: SaveReg r16
    //     0xabfbf0: str             x16, [SP, #-8]!
    // 0xabfbf4: r0 = toString()
    //     0xabfbf4: bl              #0xabfc50  ; [dart:ui] Color::toString
    // 0xabfbf8: add             SP, SP, #8
    // 0xabfbfc: ldur            x1, [fp, #-8]
    // 0xabfc00: ArrayStore: r1[2] = r0  ; List_4
    //     0xabfc00: add             x25, x1, #0x17
    //     0xabfc04: str             w0, [x25]
    //     0xabfc08: tbz             w0, #0, #0xabfc24
    //     0xabfc0c: ldurb           w16, [x1, #-1]
    //     0xabfc10: ldurb           w17, [x0, #-1]
    //     0xabfc14: and             x16, x17, x16, lsr #2
    //     0xabfc18: tst             x16, HEAP, lsr #32
    //     0xabfc1c: b.eq            #0xabfc24
    //     0xabfc20: bl              #0xd67e5c
    // 0xabfc24: ldur            x0, [fp, #-8]
    // 0xabfc28: r17 = ")"
    //     0xabfc28: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xabfc2c: StoreField: r0->field_1b = r17
    //     0xabfc2c: stur            w17, [x0, #0x1b]
    // 0xabfc30: SaveReg r0
    //     0xabfc30: str             x0, [SP, #-8]!
    // 0xabfc34: r0 = _interpolate()
    //     0xabfc34: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabfc38: add             SP, SP, #8
    // 0xabfc3c: LeaveFrame
    //     0xabfc3c: mov             SP, fp
    //     0xabfc40: ldp             fp, lr, [SP], #0x10
    // 0xabfc44: ret
    //     0xabfc44: ret             
    // 0xabfc48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xabfc48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xabfc4c: b               #0xabfbc4
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xaf8c9c, size: 0x8c
    // 0xaf8c9c: EnterFrame
    //     0xaf8c9c: stp             fp, lr, [SP, #-0x10]!
    //     0xaf8ca0: mov             fp, SP
    // 0xaf8ca4: CheckStackOverflow
    //     0xaf8ca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaf8ca8: cmp             SP, x16
    //     0xaf8cac: b.ls            #0xaf8d20
    // 0xaf8cb0: ldr             x16, [fp, #0x10]
    // 0xaf8cb4: SaveReg r16
    //     0xaf8cb4: str             x16, [SP, #-8]!
    // 0xaf8cb8: r0 = runtimeType()
    //     0xaf8cb8: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xaf8cbc: add             SP, SP, #8
    // 0xaf8cc0: mov             x2, x0
    // 0xaf8cc4: ldr             x0, [fp, #0x10]
    // 0xaf8cc8: LoadField: r3 = r0->field_7
    //     0xaf8cc8: ldur            x3, [x0, #7]
    // 0xaf8ccc: LoadField: r4 = r0->field_13
    //     0xaf8ccc: ldur            w4, [x0, #0x13]
    // 0xaf8cd0: DecompressPointer r4
    //     0xaf8cd0: add             x4, x4, HEAP, lsl #32
    // 0xaf8cd4: r0 = BoxInt64Instr(r3)
    //     0xaf8cd4: sbfiz           x0, x3, #1, #0x1f
    //     0xaf8cd8: cmp             x3, x0, asr #1
    //     0xaf8cdc: b.eq            #0xaf8ce8
    //     0xaf8ce0: bl              #0xd69bb8
    //     0xaf8ce4: stur            x3, [x0, #7]
    // 0xaf8ce8: stp             x0, x2, [SP, #-0x10]!
    // 0xaf8cec: SaveReg r4
    //     0xaf8cec: str             x4, [SP, #-8]!
    // 0xaf8cf0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xaf8cf0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xaf8cf4: r0 = hash()
    //     0xaf8cf4: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaf8cf8: add             SP, SP, #0x18
    // 0xaf8cfc: mov             x2, x0
    // 0xaf8d00: r0 = BoxInt64Instr(r2)
    //     0xaf8d00: sbfiz           x0, x2, #1, #0x1f
    //     0xaf8d04: cmp             x2, x0, asr #1
    //     0xaf8d08: b.eq            #0xaf8d14
    //     0xaf8d0c: bl              #0xd69bb8
    //     0xaf8d10: stur            x2, [x0, #7]
    // 0xaf8d14: LeaveFrame
    //     0xaf8d14: mov             SP, fp
    //     0xaf8d18: ldp             fp, lr, [SP], #0x10
    // 0xaf8d1c: ret
    //     0xaf8d1c: ret             
    // 0xaf8d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf8d20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf8d24: b               #0xaf8cb0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc668f8, size: 0x1d8
    // 0xc668f8: EnterFrame
    //     0xc668f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc668fc: mov             fp, SP
    // 0xc66900: AllocStack(0x8)
    //     0xc66900: sub             SP, SP, #8
    // 0xc66904: CheckStackOverflow
    //     0xc66904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc66908: cmp             SP, x16
    //     0xc6690c: b.ls            #0xc66ac8
    // 0xc66910: ldr             x1, [fp, #0x10]
    // 0xc66914: cmp             w1, NULL
    // 0xc66918: b.ne            #0xc6692c
    // 0xc6691c: r0 = false
    //     0xc6691c: add             x0, NULL, #0x30  ; false
    // 0xc66920: LeaveFrame
    //     0xc66920: mov             SP, fp
    //     0xc66924: ldp             fp, lr, [SP], #0x10
    // 0xc66928: ret
    //     0xc66928: ret             
    // 0xc6692c: ldr             x2, [fp, #0x18]
    // 0xc66930: cmp             w2, w1
    // 0xc66934: b.ne            #0xc66948
    // 0xc66938: r0 = true
    //     0xc66938: add             x0, NULL, #0x20  ; true
    // 0xc6693c: LeaveFrame
    //     0xc6693c: mov             SP, fp
    //     0xc66940: ldp             fp, lr, [SP], #0x10
    // 0xc66944: ret
    //     0xc66944: ret             
    // 0xc66948: r0 = 59
    //     0xc66948: mov             x0, #0x3b
    // 0xc6694c: branchIfSmi(r1, 0xc66958)
    //     0xc6694c: tbz             w1, #0, #0xc66958
    // 0xc66950: r0 = LoadClassIdInstr(r1)
    //     0xc66950: ldur            x0, [x1, #-1]
    //     0xc66954: ubfx            x0, x0, #0xc, #0x14
    // 0xc66958: SaveReg r1
    //     0xc66958: str             x1, [SP, #-8]!
    // 0xc6695c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc6695c: mov             x17, #0x57c5
    //     0xc66960: add             lr, x0, x17
    //     0xc66964: ldr             lr, [x21, lr, lsl #3]
    //     0xc66968: blr             lr
    // 0xc6696c: add             SP, SP, #8
    // 0xc66970: stur            x0, [fp, #-8]
    // 0xc66974: ldr             x16, [fp, #0x18]
    // 0xc66978: SaveReg r16
    //     0xc66978: str             x16, [SP, #-8]!
    // 0xc6697c: r0 = runtimeType()
    //     0xc6697c: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc66980: add             SP, SP, #8
    // 0xc66984: mov             x1, x0
    // 0xc66988: ldur            x0, [fp, #-8]
    // 0xc6698c: r2 = LoadClassIdInstr(r0)
    //     0xc6698c: ldur            x2, [x0, #-1]
    //     0xc66990: ubfx            x2, x2, #0xc, #0x14
    // 0xc66994: stp             x1, x0, [SP, #-0x10]!
    // 0xc66998: mov             x0, x2
    // 0xc6699c: mov             lr, x0
    // 0xc669a0: ldr             lr, [x21, lr, lsl #3]
    // 0xc669a4: blr             lr
    // 0xc669a8: add             SP, SP, #0x10
    // 0xc669ac: tbz             w0, #4, #0xc669c0
    // 0xc669b0: r0 = false
    //     0xc669b0: add             x0, NULL, #0x30  ; false
    // 0xc669b4: LeaveFrame
    //     0xc669b4: mov             SP, fp
    //     0xc669b8: ldp             fp, lr, [SP], #0x10
    // 0xc669bc: ret
    //     0xc669bc: ret             
    // 0xc669c0: ldr             x16, [fp, #0x18]
    // 0xc669c4: ldr             lr, [fp, #0x10]
    // 0xc669c8: stp             lr, x16, [SP, #-0x10]!
    // 0xc669cc: r0 = ==()
    //     0xc669cc: bl              #0xc66ad0  ; [dart:ui] Color::==
    // 0xc669d0: add             SP, SP, #0x10
    // 0xc669d4: tbnz            w0, #4, #0xc66ab8
    // 0xc669d8: ldr             x3, [fp, #0x18]
    // 0xc669dc: LoadField: r4 = r3->field_f
    //     0xc669dc: ldur            w4, [x3, #0xf]
    // 0xc669e0: DecompressPointer r4
    //     0xc669e0: add             x4, x4, HEAP, lsl #32
    // 0xc669e4: ldr             x0, [fp, #0x10]
    // 0xc669e8: mov             x2, x4
    // 0xc669ec: stur            x4, [fp, #-8]
    // 0xc669f0: r1 = Null
    //     0xc669f0: mov             x1, NULL
    // 0xc669f4: cmp             w0, NULL
    // 0xc669f8: b.eq            #0xc66a4c
    // 0xc669fc: branchIfSmi(r0, 0xc66a4c)
    //     0xc669fc: tbz             w0, #0, #0xc66a4c
    // 0xc66a00: r8 = ColorSwatch<X0>
    //     0xc66a00: add             x8, PP, #0xd, lsl #12  ; [pp+0xde98] Type: ColorSwatch<X0>
    //     0xc66a04: ldr             x8, [x8, #0xe98]
    // 0xc66a08: r3 = SubtypeTestCache
    //     0xc66a08: add             x3, PP, #0xd, lsl #12  ; [pp+0xdea0] SubtypeTestCache
    //     0xc66a0c: ldr             x3, [x3, #0xea0]
    // 0xc66a10: r24 = Subtype5TestCacheStub
    //     0xc66a10: ldr             x24, [PP, #0xc78]  ; [pp+0xc78] Stub: Subtype5TestCache (0x4ae1bc)
    // 0xc66a14: LoadField: r30 = r24->field_7
    //     0xc66a14: ldur            lr, [x24, #7]
    // 0xc66a18: blr             lr
    // 0xc66a1c: cmp             w7, NULL
    // 0xc66a20: b.eq            #0xc66a2c
    // 0xc66a24: tbnz            w7, #4, #0xc66a4c
    // 0xc66a28: b               #0xc66a54
    // 0xc66a2c: r8 = ColorSwatch<X0>
    //     0xc66a2c: add             x8, PP, #0xd, lsl #12  ; [pp+0xdea8] Type: ColorSwatch<X0>
    //     0xc66a30: ldr             x8, [x8, #0xea8]
    // 0xc66a34: r3 = SubtypeTestCache
    //     0xc66a34: add             x3, PP, #0xd, lsl #12  ; [pp+0xdeb0] SubtypeTestCache
    //     0xc66a38: ldr             x3, [x3, #0xeb0]
    // 0xc66a3c: r24 = InstanceOfStub
    //     0xc66a3c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc66a40: LoadField: r30 = r24->field_7
    //     0xc66a40: ldur            lr, [x24, #7]
    // 0xc66a44: blr             lr
    // 0xc66a48: b               #0xc66a58
    // 0xc66a4c: r0 = false
    //     0xc66a4c: add             x0, NULL, #0x30  ; false
    // 0xc66a50: b               #0xc66a58
    // 0xc66a54: r0 = true
    //     0xc66a54: add             x0, NULL, #0x20  ; true
    // 0xc66a58: tbnz            w0, #4, #0xc66ab8
    // 0xc66a5c: ldr             x0, [fp, #0x18]
    // 0xc66a60: ldr             x4, [fp, #0x10]
    // 0xc66a64: ldur            x2, [fp, #-8]
    // 0xc66a68: r1 = Null
    //     0xc66a68: mov             x1, NULL
    // 0xc66a6c: r3 = <X0, Color>
    //     0xc66a6c: add             x3, PP, #0xd, lsl #12  ; [pp+0xdeb8] TypeArguments: <X0, Color>
    //     0xc66a70: ldr             x3, [x3, #0xeb8]
    // 0xc66a74: r24 = InstantiateTypeArgumentsStub
    //     0xc66a74: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xc66a78: LoadField: r30 = r24->field_7
    //     0xc66a78: ldur            lr, [x24, #7]
    // 0xc66a7c: blr             lr
    // 0xc66a80: mov             x1, x0
    // 0xc66a84: ldr             x0, [fp, #0x10]
    // 0xc66a88: LoadField: r2 = r0->field_13
    //     0xc66a88: ldur            w2, [x0, #0x13]
    // 0xc66a8c: DecompressPointer r2
    //     0xc66a8c: add             x2, x2, HEAP, lsl #32
    // 0xc66a90: ldr             x0, [fp, #0x18]
    // 0xc66a94: LoadField: r3 = r0->field_13
    //     0xc66a94: ldur            w3, [x0, #0x13]
    // 0xc66a98: DecompressPointer r3
    //     0xc66a98: add             x3, x3, HEAP, lsl #32
    // 0xc66a9c: stp             x2, x1, [SP, #-0x10]!
    // 0xc66aa0: SaveReg r3
    //     0xc66aa0: str             x3, [SP, #-8]!
    // 0xc66aa4: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xc66aa4: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xc66aa8: ldr             x4, [x4, #0x4d8]
    // 0xc66aac: r0 = mapEquals()
    //     0xc66aac: bl              #0x7d6da4  ; [package:flutter/src/foundation/collections.dart] ::mapEquals
    // 0xc66ab0: add             SP, SP, #0x18
    // 0xc66ab4: b               #0xc66abc
    // 0xc66ab8: r0 = false
    //     0xc66ab8: add             x0, NULL, #0x30  ; false
    // 0xc66abc: LeaveFrame
    //     0xc66abc: mov             SP, fp
    //     0xc66ac0: ldp             fp, lr, [SP], #0x10
    // 0xc66ac4: ret
    //     0xc66ac4: ret             
    // 0xc66ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc66ac8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc66acc: b               #0xc66910
  }
}

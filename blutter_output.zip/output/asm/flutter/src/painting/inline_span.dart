// lib: , url: package:flutter/src/painting/inline_span.dart

// class id: 1049371, size: 0x8
class :: {

  static _ combineSemanticsInfo(/* No info */) {
    // ** addr: 0x64778c, size: 0x6b8
    // 0x64778c: EnterFrame
    //     0x64778c: stp             fp, lr, [SP, #-0x10]!
    //     0x647790: mov             fp, SP
    // 0x647794: AllocStack(0x78)
    //     0x647794: sub             SP, SP, #0x78
    // 0x647798: CheckStackOverflow
    //     0x647798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64779c: cmp             SP, x16
    //     0x6477a0: b.ls            #0x647e1c
    // 0x6477a4: r16 = <InlineSpanSemanticsInformation>
    //     0x6477a4: add             x16, PP, #0x22, lsl #12  ; [pp+0x22328] TypeArguments: <InlineSpanSemanticsInformation>
    //     0x6477a8: ldr             x16, [x16, #0x328]
    // 0x6477ac: stp             xzr, x16, [SP, #-0x10]!
    // 0x6477b0: r0 = _GrowableList()
    //     0x6477b0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6477b4: add             SP, SP, #0x10
    // 0x6477b8: stur            x0, [fp, #-8]
    // 0x6477bc: r16 = <StringAttribute>
    //     0x6477bc: ldr             x16, [PP, #0x48a0]  ; [pp+0x48a0] TypeArguments: <StringAttribute>
    // 0x6477c0: stp             xzr, x16, [SP, #-0x10]!
    // 0x6477c4: r0 = _GrowableList()
    //     0x6477c4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6477c8: add             SP, SP, #0x10
    // 0x6477cc: ldr             x1, [fp, #0x10]
    // 0x6477d0: LoadField: r2 = r1->field_7
    //     0x6477d0: ldur            w2, [x1, #7]
    // 0x6477d4: DecompressPointer r2
    //     0x6477d4: add             x2, x2, HEAP, lsl #32
    // 0x6477d8: stur            x2, [fp, #-0x38]
    // 0x6477dc: LoadField: r3 = r1->field_b
    //     0x6477dc: ldur            w3, [x1, #0xb]
    // 0x6477e0: DecompressPointer r3
    //     0x6477e0: add             x3, x3, HEAP, lsl #32
    // 0x6477e4: r4 = LoadInt32Instr(r3)
    //     0x6477e4: sbfx            x4, x3, #1, #0x1f
    // 0x6477e8: stur            x4, [fp, #-0x30]
    // 0x6477ec: mov             x6, x0
    // 0x6477f0: r8 = ""
    //     0x6477f0: ldr             x8, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x6477f4: r7 = ""
    //     0x6477f4: ldr             x7, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x6477f8: r5 = 0
    //     0x6477f8: mov             x5, #0
    // 0x6477fc: ldur            x3, [fp, #-8]
    // 0x647800: stur            x8, [fp, #-0x10]
    // 0x647804: stur            x7, [fp, #-0x18]
    // 0x647808: stur            x6, [fp, #-0x20]
    // 0x64780c: stur            x5, [fp, #-0x28]
    // 0x647810: CheckStackOverflow
    //     0x647810: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x647814: cmp             SP, x16
    //     0x647818: b.ls            #0x647e24
    // 0x64781c: r0 = LoadClassIdInstr(r1)
    //     0x64781c: ldur            x0, [x1, #-1]
    //     0x647820: ubfx            x0, x0, #0xc, #0x14
    // 0x647824: SaveReg r1
    //     0x647824: str             x1, [SP, #-8]!
    // 0x647828: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x647828: mov             x17, #0xb8ea
    //     0x64782c: add             lr, x0, x17
    //     0x647830: ldr             lr, [x21, lr, lsl #3]
    //     0x647834: blr             lr
    // 0x647838: add             SP, SP, #8
    // 0x64783c: r1 = LoadInt32Instr(r0)
    //     0x64783c: sbfx            x1, x0, #1, #0x1f
    //     0x647840: tbz             w0, #0, #0x647848
    //     0x647844: ldur            x1, [x0, #7]
    // 0x647848: ldur            x2, [fp, #-0x30]
    // 0x64784c: cmp             x2, x1
    // 0x647850: b.ne            #0x647e04
    // 0x647854: ldr             x3, [fp, #0x10]
    // 0x647858: ldur            x4, [fp, #-0x28]
    // 0x64785c: cmp             x4, x1
    // 0x647860: b.lt            #0x64793c
    // 0x647864: ldur            x0, [fp, #-8]
    // 0x647868: ldur            x3, [fp, #-0x10]
    // 0x64786c: ldur            x2, [fp, #-0x18]
    // 0x647870: ldur            x1, [fp, #-0x20]
    // 0x647874: r0 = InlineSpanSemanticsInformation()
    //     0x647874: bl              #0x647e44  ; AllocateInlineSpanSemanticsInformationStub -> InlineSpanSemanticsInformation (size=0x20)
    // 0x647878: ldur            x5, [fp, #-0x10]
    // 0x64787c: stur            x0, [fp, #-0x48]
    // 0x647880: StoreField: r0->field_7 = r5
    //     0x647880: stur            w5, [x0, #7]
    // 0x647884: r6 = false
    //     0x647884: add             x6, NULL, #0x30  ; false
    // 0x647888: StoreField: r0->field_13 = r6
    //     0x647888: stur            w6, [x0, #0x13]
    // 0x64788c: ldur            x7, [fp, #-0x18]
    // 0x647890: StoreField: r0->field_b = r7
    //     0x647890: stur            w7, [x0, #0xb]
    // 0x647894: ldur            x8, [fp, #-0x20]
    // 0x647898: StoreField: r0->field_1b = r8
    //     0x647898: stur            w8, [x0, #0x1b]
    // 0x64789c: StoreField: r0->field_17 = r6
    //     0x64789c: stur            w6, [x0, #0x17]
    // 0x6478a0: ldur            x1, [fp, #-8]
    // 0x6478a4: LoadField: r2 = r1->field_b
    //     0x6478a4: ldur            w2, [x1, #0xb]
    // 0x6478a8: DecompressPointer r2
    //     0x6478a8: add             x2, x2, HEAP, lsl #32
    // 0x6478ac: stur            x2, [fp, #-0x40]
    // 0x6478b0: LoadField: r3 = r1->field_f
    //     0x6478b0: ldur            w3, [x1, #0xf]
    // 0x6478b4: DecompressPointer r3
    //     0x6478b4: add             x3, x3, HEAP, lsl #32
    // 0x6478b8: LoadField: r4 = r3->field_b
    //     0x6478b8: ldur            w4, [x3, #0xb]
    // 0x6478bc: DecompressPointer r4
    //     0x6478bc: add             x4, x4, HEAP, lsl #32
    // 0x6478c0: cmp             w2, w4
    // 0x6478c4: b.ne            #0x6478d4
    // 0x6478c8: SaveReg r1
    //     0x6478c8: str             x1, [SP, #-8]!
    // 0x6478cc: r0 = _growToNextCapacity()
    //     0x6478cc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6478d0: add             SP, SP, #8
    // 0x6478d4: ldur            x9, [fp, #-8]
    // 0x6478d8: ldur            x0, [fp, #-0x40]
    // 0x6478dc: r2 = LoadInt32Instr(r0)
    //     0x6478dc: sbfx            x2, x0, #1, #0x1f
    // 0x6478e0: add             x0, x2, #1
    // 0x6478e4: lsl             x1, x0, #1
    // 0x6478e8: StoreField: r9->field_b = r1
    //     0x6478e8: stur            w1, [x9, #0xb]
    // 0x6478ec: mov             x1, x2
    // 0x6478f0: cmp             x1, x0
    // 0x6478f4: b.hs            #0x647e2c
    // 0x6478f8: LoadField: r1 = r9->field_f
    //     0x6478f8: ldur            w1, [x9, #0xf]
    // 0x6478fc: DecompressPointer r1
    //     0x6478fc: add             x1, x1, HEAP, lsl #32
    // 0x647900: ldur            x0, [fp, #-0x48]
    // 0x647904: ArrayStore: r1[r2] = r0  ; List_4
    //     0x647904: add             x25, x1, x2, lsl #2
    //     0x647908: add             x25, x25, #0xf
    //     0x64790c: str             w0, [x25]
    //     0x647910: tbz             w0, #0, #0x64792c
    //     0x647914: ldurb           w16, [x1, #-1]
    //     0x647918: ldurb           w17, [x0, #-1]
    //     0x64791c: and             x16, x17, x16, lsr #2
    //     0x647920: tst             x16, HEAP, lsr #32
    //     0x647924: b.eq            #0x64792c
    //     0x647928: bl              #0xd67e5c
    // 0x64792c: mov             x0, x9
    // 0x647930: LeaveFrame
    //     0x647930: mov             SP, fp
    //     0x647934: ldp             fp, lr, [SP], #0x10
    // 0x647938: ret
    //     0x647938: ret             
    // 0x64793c: ldur            x9, [fp, #-8]
    // 0x647940: ldur            x5, [fp, #-0x10]
    // 0x647944: ldur            x7, [fp, #-0x18]
    // 0x647948: ldur            x8, [fp, #-0x20]
    // 0x64794c: r6 = false
    //     0x64794c: add             x6, NULL, #0x30  ; false
    // 0x647950: r0 = BoxInt64Instr(r4)
    //     0x647950: sbfiz           x0, x4, #1, #0x1f
    //     0x647954: cmp             x4, x0, asr #1
    //     0x647958: b.eq            #0x647964
    //     0x64795c: bl              #0xd69bb8
    //     0x647960: stur            x4, [x0, #7]
    // 0x647964: r1 = LoadClassIdInstr(r3)
    //     0x647964: ldur            x1, [x3, #-1]
    //     0x647968: ubfx            x1, x1, #0xc, #0x14
    // 0x64796c: stp             x0, x3, [SP, #-0x10]!
    // 0x647970: mov             x0, x1
    // 0x647974: r0 = GDT[cid_x0 + 0xd175]()
    //     0x647974: mov             x17, #0xd175
    //     0x647978: add             lr, x0, x17
    //     0x64797c: ldr             lr, [x21, lr, lsl #3]
    //     0x647980: blr             lr
    // 0x647984: add             SP, SP, #0x10
    // 0x647988: mov             x3, x0
    // 0x64798c: ldur            x0, [fp, #-0x28]
    // 0x647990: stur            x3, [fp, #-0x40]
    // 0x647994: add             x5, x0, #1
    // 0x647998: stur            x5, [fp, #-0x50]
    // 0x64799c: cmp             w3, NULL
    // 0x6479a0: b.ne            #0x6479d4
    // 0x6479a4: mov             x0, x3
    // 0x6479a8: ldur            x2, [fp, #-0x38]
    // 0x6479ac: r1 = Null
    //     0x6479ac: mov             x1, NULL
    // 0x6479b0: cmp             w2, NULL
    // 0x6479b4: b.eq            #0x6479d4
    // 0x6479b8: LoadField: r4 = r2->field_17
    //     0x6479b8: ldur            w4, [x2, #0x17]
    // 0x6479bc: DecompressPointer r4
    //     0x6479bc: add             x4, x4, HEAP, lsl #32
    // 0x6479c0: r8 = X0
    //     0x6479c0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6479c4: LoadField: r9 = r4->field_7
    //     0x6479c4: ldur            x9, [x4, #7]
    // 0x6479c8: r3 = Null
    //     0x6479c8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22330] Null
    //     0x6479cc: ldr             x3, [x3, #0x330]
    // 0x6479d0: blr             x9
    // 0x6479d4: ldur            x0, [fp, #-0x40]
    // 0x6479d8: LoadField: r1 = r0->field_17
    //     0x6479d8: ldur            w1, [x0, #0x17]
    // 0x6479dc: DecompressPointer r1
    //     0x6479dc: add             x1, x1, HEAP, lsl #32
    // 0x6479e0: tbnz            w1, #4, #0x647b88
    // 0x6479e4: ldur            x4, [fp, #-8]
    // 0x6479e8: ldur            x1, [fp, #-0x10]
    // 0x6479ec: ldur            x2, [fp, #-0x18]
    // 0x6479f0: ldur            x3, [fp, #-0x20]
    // 0x6479f4: r0 = InlineSpanSemanticsInformation()
    //     0x6479f4: bl              #0x647e44  ; AllocateInlineSpanSemanticsInformationStub -> InlineSpanSemanticsInformation (size=0x20)
    // 0x6479f8: mov             x1, x0
    // 0x6479fc: ldur            x0, [fp, #-0x10]
    // 0x647a00: stur            x1, [fp, #-0x58]
    // 0x647a04: StoreField: r1->field_7 = r0
    //     0x647a04: stur            w0, [x1, #7]
    // 0x647a08: r0 = false
    //     0x647a08: add             x0, NULL, #0x30  ; false
    // 0x647a0c: StoreField: r1->field_13 = r0
    //     0x647a0c: stur            w0, [x1, #0x13]
    // 0x647a10: ldur            x2, [fp, #-0x18]
    // 0x647a14: StoreField: r1->field_b = r2
    //     0x647a14: stur            w2, [x1, #0xb]
    // 0x647a18: ldur            x3, [fp, #-0x20]
    // 0x647a1c: StoreField: r1->field_1b = r3
    //     0x647a1c: stur            w3, [x1, #0x1b]
    // 0x647a20: StoreField: r1->field_17 = r0
    //     0x647a20: stur            w0, [x1, #0x17]
    // 0x647a24: ldur            x2, [fp, #-8]
    // 0x647a28: LoadField: r3 = r2->field_b
    //     0x647a28: ldur            w3, [x2, #0xb]
    // 0x647a2c: DecompressPointer r3
    //     0x647a2c: add             x3, x3, HEAP, lsl #32
    // 0x647a30: stur            x3, [fp, #-0x48]
    // 0x647a34: LoadField: r4 = r2->field_f
    //     0x647a34: ldur            w4, [x2, #0xf]
    // 0x647a38: DecompressPointer r4
    //     0x647a38: add             x4, x4, HEAP, lsl #32
    // 0x647a3c: LoadField: r5 = r4->field_b
    //     0x647a3c: ldur            w5, [x4, #0xb]
    // 0x647a40: DecompressPointer r5
    //     0x647a40: add             x5, x5, HEAP, lsl #32
    // 0x647a44: cmp             w3, w5
    // 0x647a48: b.ne            #0x647a58
    // 0x647a4c: SaveReg r2
    //     0x647a4c: str             x2, [SP, #-8]!
    // 0x647a50: r0 = _growToNextCapacity()
    //     0x647a50: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x647a54: add             SP, SP, #8
    // 0x647a58: ldur            x2, [fp, #-8]
    // 0x647a5c: ldur            x0, [fp, #-0x48]
    // 0x647a60: r3 = LoadInt32Instr(r0)
    //     0x647a60: sbfx            x3, x0, #1, #0x1f
    // 0x647a64: add             x0, x3, #1
    // 0x647a68: lsl             x1, x0, #1
    // 0x647a6c: StoreField: r2->field_b = r1
    //     0x647a6c: stur            w1, [x2, #0xb]
    // 0x647a70: mov             x1, x3
    // 0x647a74: cmp             x1, x0
    // 0x647a78: b.hs            #0x647e30
    // 0x647a7c: LoadField: r1 = r2->field_f
    //     0x647a7c: ldur            w1, [x2, #0xf]
    // 0x647a80: DecompressPointer r1
    //     0x647a80: add             x1, x1, HEAP, lsl #32
    // 0x647a84: ldur            x0, [fp, #-0x58]
    // 0x647a88: ArrayStore: r1[r3] = r0  ; List_4
    //     0x647a88: add             x25, x1, x3, lsl #2
    //     0x647a8c: add             x25, x25, #0xf
    //     0x647a90: str             w0, [x25]
    //     0x647a94: tbz             w0, #0, #0x647ab0
    //     0x647a98: ldurb           w16, [x1, #-1]
    //     0x647a9c: ldurb           w17, [x0, #-1]
    //     0x647aa0: and             x16, x17, x16, lsr #2
    //     0x647aa4: tst             x16, HEAP, lsr #32
    //     0x647aa8: b.eq            #0x647ab0
    //     0x647aac: bl              #0xd67e5c
    // 0x647ab0: r0 = InitLateStaticField(0x0) // [dart:core] _GrowableList<X0>::_emptyList
    //     0x647ab0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x647ab4: ldr             x0, [x0]
    //     0x647ab8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x647abc: cmp             w0, w16
    //     0x647ac0: b.ne            #0x647acc
    //     0x647ac4: ldr             x2, [PP, #0x7c8]  ; [pp+0x7c8] Field <_GrowableList@0150898._emptyList@0150898>: static late final (offset: 0x0)
    //     0x647ac8: bl              #0xd67cdc
    // 0x647acc: r1 = <StringAttribute>
    //     0x647acc: ldr             x1, [PP, #0x48a0]  ; [pp+0x48a0] TypeArguments: <StringAttribute>
    // 0x647ad0: stur            x0, [fp, #-0x48]
    // 0x647ad4: r0 = AllocateGrowableArray()
    //     0x647ad4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x647ad8: mov             x1, x0
    // 0x647adc: ldur            x0, [fp, #-0x48]
    // 0x647ae0: stur            x1, [fp, #-0x58]
    // 0x647ae4: StoreField: r1->field_f = r0
    //     0x647ae4: stur            w0, [x1, #0xf]
    // 0x647ae8: StoreField: r1->field_b = rZR
    //     0x647ae8: stur            wzr, [x1, #0xb]
    // 0x647aec: ldur            x0, [fp, #-8]
    // 0x647af0: LoadField: r2 = r0->field_b
    //     0x647af0: ldur            w2, [x0, #0xb]
    // 0x647af4: DecompressPointer r2
    //     0x647af4: add             x2, x2, HEAP, lsl #32
    // 0x647af8: stur            x2, [fp, #-0x48]
    // 0x647afc: LoadField: r3 = r0->field_f
    //     0x647afc: ldur            w3, [x0, #0xf]
    // 0x647b00: DecompressPointer r3
    //     0x647b00: add             x3, x3, HEAP, lsl #32
    // 0x647b04: LoadField: r4 = r3->field_b
    //     0x647b04: ldur            w4, [x3, #0xb]
    // 0x647b08: DecompressPointer r4
    //     0x647b08: add             x4, x4, HEAP, lsl #32
    // 0x647b0c: cmp             w2, w4
    // 0x647b10: b.ne            #0x647b20
    // 0x647b14: SaveReg r0
    //     0x647b14: str             x0, [SP, #-8]!
    // 0x647b18: r0 = _growToNextCapacity()
    //     0x647b18: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x647b1c: add             SP, SP, #8
    // 0x647b20: ldur            x4, [fp, #-8]
    // 0x647b24: ldur            x0, [fp, #-0x48]
    // 0x647b28: r2 = LoadInt32Instr(r0)
    //     0x647b28: sbfx            x2, x0, #1, #0x1f
    // 0x647b2c: add             x0, x2, #1
    // 0x647b30: lsl             x1, x0, #1
    // 0x647b34: StoreField: r4->field_b = r1
    //     0x647b34: stur            w1, [x4, #0xb]
    // 0x647b38: mov             x1, x2
    // 0x647b3c: cmp             x1, x0
    // 0x647b40: b.hs            #0x647e34
    // 0x647b44: LoadField: r1 = r4->field_f
    //     0x647b44: ldur            w1, [x4, #0xf]
    // 0x647b48: DecompressPointer r1
    //     0x647b48: add             x1, x1, HEAP, lsl #32
    // 0x647b4c: ldur            x0, [fp, #-0x40]
    // 0x647b50: ArrayStore: r1[r2] = r0  ; List_4
    //     0x647b50: add             x25, x1, x2, lsl #2
    //     0x647b54: add             x25, x25, #0xf
    //     0x647b58: str             w0, [x25]
    //     0x647b5c: tbz             w0, #0, #0x647b78
    //     0x647b60: ldurb           w16, [x1, #-1]
    //     0x647b64: ldurb           w17, [x0, #-1]
    //     0x647b68: and             x16, x17, x16, lsr #2
    //     0x647b6c: tst             x16, HEAP, lsr #32
    //     0x647b70: b.eq            #0x647b78
    //     0x647b74: bl              #0xd67e5c
    // 0x647b78: ldur            x6, [fp, #-0x58]
    // 0x647b7c: r8 = ""
    //     0x647b7c: ldr             x8, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x647b80: r7 = ""
    //     0x647b80: ldr             x7, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x647b84: b               #0x647df0
    // 0x647b88: ldur            x4, [fp, #-8]
    // 0x647b8c: mov             x1, x0
    // 0x647b90: ldur            x0, [fp, #-0x10]
    // 0x647b94: ldur            x2, [fp, #-0x18]
    // 0x647b98: ldur            x3, [fp, #-0x20]
    // 0x647b9c: LoadField: r5 = r1->field_7
    //     0x647b9c: ldur            w5, [x1, #7]
    // 0x647ba0: DecompressPointer r5
    //     0x647ba0: add             x5, x5, HEAP, lsl #32
    // 0x647ba4: stur            x5, [fp, #-0x48]
    // 0x647ba8: stp             x5, x0, [SP, #-0x10]!
    // 0x647bac: r0 = +()
    //     0x647bac: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x647bb0: add             SP, SP, #0x10
    // 0x647bb4: mov             x1, x0
    // 0x647bb8: ldur            x0, [fp, #-0x40]
    // 0x647bbc: stur            x1, [fp, #-0x58]
    // 0x647bc0: LoadField: r2 = r0->field_b
    //     0x647bc0: ldur            w2, [x0, #0xb]
    // 0x647bc4: DecompressPointer r2
    //     0x647bc4: add             x2, x2, HEAP, lsl #32
    // 0x647bc8: cmp             w2, NULL
    // 0x647bcc: b.ne            #0x647bd8
    // 0x647bd0: ldur            x4, [fp, #-0x48]
    // 0x647bd4: b               #0x647bdc
    // 0x647bd8: mov             x4, x2
    // 0x647bdc: ldur            x2, [fp, #-0x18]
    // 0x647be0: ldur            x3, [fp, #-0x20]
    // 0x647be4: stur            x4, [fp, #-0x10]
    // 0x647be8: LoadField: r5 = r0->field_1b
    //     0x647be8: ldur            w5, [x0, #0x1b]
    // 0x647bec: DecompressPointer r5
    //     0x647bec: add             x5, x5, HEAP, lsl #32
    // 0x647bf0: r0 = LoadClassIdInstr(r5)
    //     0x647bf0: ldur            x0, [x5, #-1]
    //     0x647bf4: ubfx            x0, x0, #0xc, #0x14
    // 0x647bf8: SaveReg r5
    //     0x647bf8: str             x5, [SP, #-8]!
    // 0x647bfc: r0 = GDT[cid_x0 + 0xb940]()
    //     0x647bfc: mov             x17, #0xb940
    //     0x647c00: add             lr, x0, x17
    //     0x647c04: ldr             lr, [x21, lr, lsl #3]
    //     0x647c08: blr             lr
    // 0x647c0c: add             SP, SP, #8
    // 0x647c10: mov             x2, x0
    // 0x647c14: ldur            x1, [fp, #-0x18]
    // 0x647c18: stur            x2, [fp, #-0x48]
    // 0x647c1c: LoadField: r0 = r1->field_7
    //     0x647c1c: ldur            w0, [x1, #7]
    // 0x647c20: DecompressPointer r0
    //     0x647c20: add             x0, x0, HEAP, lsl #32
    // 0x647c24: r3 = LoadInt32Instr(r0)
    //     0x647c24: sbfx            x3, x0, #1, #0x1f
    // 0x647c28: ldur            x4, [fp, #-0x20]
    // 0x647c2c: stur            x3, [fp, #-0x28]
    // 0x647c30: LoadField: r5 = r4->field_7
    //     0x647c30: ldur            w5, [x4, #7]
    // 0x647c34: DecompressPointer r5
    //     0x647c34: add             x5, x5, HEAP, lsl #32
    // 0x647c38: stur            x5, [fp, #-0x40]
    // 0x647c3c: CheckStackOverflow
    //     0x647c3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x647c40: cmp             SP, x16
    //     0x647c44: b.ls            #0x647e38
    // 0x647c48: r0 = LoadClassIdInstr(r2)
    //     0x647c48: ldur            x0, [x2, #-1]
    //     0x647c4c: ubfx            x0, x0, #0xc, #0x14
    // 0x647c50: SaveReg r2
    //     0x647c50: str             x2, [SP, #-8]!
    // 0x647c54: r0 = GDT[cid_x0 + 0x541]()
    //     0x647c54: add             lr, x0, #0x541
    //     0x647c58: ldr             lr, [x21, lr, lsl #3]
    //     0x647c5c: blr             lr
    // 0x647c60: add             SP, SP, #8
    // 0x647c64: tbnz            w0, #4, #0x647dcc
    // 0x647c68: ldur            x3, [fp, #-0x20]
    // 0x647c6c: ldur            x1, [fp, #-0x48]
    // 0x647c70: ldur            x2, [fp, #-0x28]
    // 0x647c74: r0 = LoadClassIdInstr(r1)
    //     0x647c74: ldur            x0, [x1, #-1]
    //     0x647c78: ubfx            x0, x0, #0xc, #0x14
    // 0x647c7c: SaveReg r1
    //     0x647c7c: str             x1, [SP, #-8]!
    // 0x647c80: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x647c80: add             lr, x0, #0x5ca
    //     0x647c84: ldr             lr, [x21, lr, lsl #3]
    //     0x647c88: blr             lr
    // 0x647c8c: add             SP, SP, #8
    // 0x647c90: stur            x0, [fp, #-0x70]
    // 0x647c94: LoadField: r1 = r0->field_b
    //     0x647c94: ldur            w1, [x0, #0xb]
    // 0x647c98: DecompressPointer r1
    //     0x647c98: add             x1, x1, HEAP, lsl #32
    // 0x647c9c: LoadField: r2 = r1->field_7
    //     0x647c9c: ldur            x2, [x1, #7]
    // 0x647ca0: ldur            x3, [fp, #-0x28]
    // 0x647ca4: add             x4, x2, x3
    // 0x647ca8: stur            x4, [fp, #-0x68]
    // 0x647cac: LoadField: r2 = r1->field_f
    //     0x647cac: ldur            x2, [x1, #0xf]
    // 0x647cb0: add             x1, x2, x3
    // 0x647cb4: stur            x1, [fp, #-0x60]
    // 0x647cb8: r0 = TextRange()
    //     0x647cb8: bl              #0x51026c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x647cbc: mov             x1, x0
    // 0x647cc0: ldur            x0, [fp, #-0x68]
    // 0x647cc4: StoreField: r1->field_7 = r0
    //     0x647cc4: stur            x0, [x1, #7]
    // 0x647cc8: ldur            x0, [fp, #-0x60]
    // 0x647ccc: StoreField: r1->field_f = r0
    //     0x647ccc: stur            x0, [x1, #0xf]
    // 0x647cd0: ldur            x0, [fp, #-0x70]
    // 0x647cd4: r2 = LoadClassIdInstr(r0)
    //     0x647cd4: ldur            x2, [x0, #-1]
    //     0x647cd8: ubfx            x2, x2, #0xc, #0x14
    // 0x647cdc: stp             x1, x0, [SP, #-0x10]!
    // 0x647ce0: mov             x0, x2
    // 0x647ce4: r0 = GDT[cid_x0 + -0xff3]()
    //     0x647ce4: sub             lr, x0, #0xff3
    //     0x647ce8: ldr             lr, [x21, lr, lsl #3]
    //     0x647cec: blr             lr
    // 0x647cf0: add             SP, SP, #0x10
    // 0x647cf4: ldur            x2, [fp, #-0x40]
    // 0x647cf8: mov             x3, x0
    // 0x647cfc: r1 = Null
    //     0x647cfc: mov             x1, NULL
    // 0x647d00: stur            x3, [fp, #-0x70]
    // 0x647d04: cmp             w2, NULL
    // 0x647d08: b.eq            #0x647d28
    // 0x647d0c: LoadField: r4 = r2->field_17
    //     0x647d0c: ldur            w4, [x2, #0x17]
    // 0x647d10: DecompressPointer r4
    //     0x647d10: add             x4, x4, HEAP, lsl #32
    // 0x647d14: r8 = X0
    //     0x647d14: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x647d18: LoadField: r9 = r4->field_7
    //     0x647d18: ldur            x9, [x4, #7]
    // 0x647d1c: r3 = Null
    //     0x647d1c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22340] Null
    //     0x647d20: ldr             x3, [x3, #0x340]
    // 0x647d24: blr             x9
    // 0x647d28: ldur            x0, [fp, #-0x20]
    // 0x647d2c: LoadField: r1 = r0->field_b
    //     0x647d2c: ldur            w1, [x0, #0xb]
    // 0x647d30: DecompressPointer r1
    //     0x647d30: add             x1, x1, HEAP, lsl #32
    // 0x647d34: stur            x1, [fp, #-0x78]
    // 0x647d38: LoadField: r2 = r0->field_f
    //     0x647d38: ldur            w2, [x0, #0xf]
    // 0x647d3c: DecompressPointer r2
    //     0x647d3c: add             x2, x2, HEAP, lsl #32
    // 0x647d40: LoadField: r3 = r2->field_b
    //     0x647d40: ldur            w3, [x2, #0xb]
    // 0x647d44: DecompressPointer r3
    //     0x647d44: add             x3, x3, HEAP, lsl #32
    // 0x647d48: cmp             w1, w3
    // 0x647d4c: b.ne            #0x647d5c
    // 0x647d50: SaveReg r0
    //     0x647d50: str             x0, [SP, #-8]!
    // 0x647d54: r0 = _growToNextCapacity()
    //     0x647d54: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x647d58: add             SP, SP, #8
    // 0x647d5c: ldur            x2, [fp, #-0x20]
    // 0x647d60: ldur            x0, [fp, #-0x78]
    // 0x647d64: r3 = LoadInt32Instr(r0)
    //     0x647d64: sbfx            x3, x0, #1, #0x1f
    // 0x647d68: add             x0, x3, #1
    // 0x647d6c: lsl             x1, x0, #1
    // 0x647d70: StoreField: r2->field_b = r1
    //     0x647d70: stur            w1, [x2, #0xb]
    // 0x647d74: mov             x1, x3
    // 0x647d78: cmp             x1, x0
    // 0x647d7c: b.hs            #0x647e40
    // 0x647d80: LoadField: r1 = r2->field_f
    //     0x647d80: ldur            w1, [x2, #0xf]
    // 0x647d84: DecompressPointer r1
    //     0x647d84: add             x1, x1, HEAP, lsl #32
    // 0x647d88: ldur            x0, [fp, #-0x70]
    // 0x647d8c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x647d8c: add             x25, x1, x3, lsl #2
    //     0x647d90: add             x25, x25, #0xf
    //     0x647d94: str             w0, [x25]
    //     0x647d98: tbz             w0, #0, #0x647db4
    //     0x647d9c: ldurb           w16, [x1, #-1]
    //     0x647da0: ldurb           w17, [x0, #-1]
    //     0x647da4: and             x16, x17, x16, lsr #2
    //     0x647da8: tst             x16, HEAP, lsr #32
    //     0x647dac: b.eq            #0x647db4
    //     0x647db0: bl              #0xd67e5c
    // 0x647db4: ldur            x1, [fp, #-0x18]
    // 0x647db8: mov             x4, x2
    // 0x647dbc: ldur            x2, [fp, #-0x48]
    // 0x647dc0: ldur            x5, [fp, #-0x40]
    // 0x647dc4: ldur            x3, [fp, #-0x28]
    // 0x647dc8: b               #0x647c3c
    // 0x647dcc: ldur            x2, [fp, #-0x20]
    // 0x647dd0: ldur            x16, [fp, #-0x18]
    // 0x647dd4: ldur            lr, [fp, #-0x10]
    // 0x647dd8: stp             lr, x16, [SP, #-0x10]!
    // 0x647ddc: r0 = +()
    //     0x647ddc: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x647de0: add             SP, SP, #0x10
    // 0x647de4: ldur            x8, [fp, #-0x58]
    // 0x647de8: mov             x7, x0
    // 0x647dec: ldur            x6, [fp, #-0x20]
    // 0x647df0: ldur            x5, [fp, #-0x50]
    // 0x647df4: ldr             x1, [fp, #0x10]
    // 0x647df8: ldur            x2, [fp, #-0x38]
    // 0x647dfc: ldur            x4, [fp, #-0x30]
    // 0x647e00: b               #0x6477fc
    // 0x647e04: ldr             x0, [fp, #0x10]
    // 0x647e08: r0 = ConcurrentModificationError()
    //     0x647e08: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x647e0c: ldr             x3, [fp, #0x10]
    // 0x647e10: StoreField: r0->field_b = r3
    //     0x647e10: stur            w3, [x0, #0xb]
    // 0x647e14: r0 = Throw()
    //     0x647e14: bl              #0xd67e38  ; ThrowStub
    // 0x647e18: brk             #0
    // 0x647e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x647e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x647e20: b               #0x6477a4
    // 0x647e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x647e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x647e28: b               #0x64781c
    // 0x647e2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x647e2c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x647e30: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x647e30: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x647e34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x647e34: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x647e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x647e38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x647e3c: b               #0x647c48
    // 0x647e40: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x647e40: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2080, size: 0x20, field offset: 0x8
//   const constructor, 
class InlineSpanSemanticsInformation extends Object {

  _TwoByteString field_8;
  bool field_14;
  bool field_18;
  _ImmutableList<StringAttribute> field_1c;

  _ toString(/* No info */) {
    // ** addr: 0xae2f40, size: 0xa0
    // 0xae2f40: EnterFrame
    //     0xae2f40: stp             fp, lr, [SP, #-0x10]!
    //     0xae2f44: mov             fp, SP
    // 0xae2f48: CheckStackOverflow
    //     0xae2f48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae2f4c: cmp             SP, x16
    //     0xae2f50: b.ls            #0xae2fd8
    // 0xae2f54: r1 = Null
    //     0xae2f54: mov             x1, NULL
    // 0xae2f58: r2 = 16
    //     0xae2f58: mov             x2, #0x10
    // 0xae2f5c: r0 = AllocateArray()
    //     0xae2f5c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2f60: r17 = "InlineSpanSemanticsInformation"
    //     0xae2f60: add             x17, PP, #0x28, lsl #12  ; [pp+0x28688] "InlineSpanSemanticsInformation"
    //     0xae2f64: ldr             x17, [x17, #0x688]
    // 0xae2f68: StoreField: r0->field_f = r17
    //     0xae2f68: stur            w17, [x0, #0xf]
    // 0xae2f6c: r17 = "{text: "
    //     0xae2f6c: add             x17, PP, #0x28, lsl #12  ; [pp+0x28690] "{text: "
    //     0xae2f70: ldr             x17, [x17, #0x690]
    // 0xae2f74: StoreField: r0->field_13 = r17
    //     0xae2f74: stur            w17, [x0, #0x13]
    // 0xae2f78: ldr             x1, [fp, #0x10]
    // 0xae2f7c: LoadField: r2 = r1->field_7
    //     0xae2f7c: ldur            w2, [x1, #7]
    // 0xae2f80: DecompressPointer r2
    //     0xae2f80: add             x2, x2, HEAP, lsl #32
    // 0xae2f84: StoreField: r0->field_17 = r2
    //     0xae2f84: stur            w2, [x0, #0x17]
    // 0xae2f88: r17 = ", semanticsLabel: "
    //     0xae2f88: add             x17, PP, #0x28, lsl #12  ; [pp+0x28698] ", semanticsLabel: "
    //     0xae2f8c: ldr             x17, [x17, #0x698]
    // 0xae2f90: StoreField: r0->field_1b = r17
    //     0xae2f90: stur            w17, [x0, #0x1b]
    // 0xae2f94: LoadField: r2 = r1->field_b
    //     0xae2f94: ldur            w2, [x1, #0xb]
    // 0xae2f98: DecompressPointer r2
    //     0xae2f98: add             x2, x2, HEAP, lsl #32
    // 0xae2f9c: StoreField: r0->field_1f = r2
    //     0xae2f9c: stur            w2, [x0, #0x1f]
    // 0xae2fa0: r17 = ", recognizer: "
    //     0xae2fa0: add             x17, PP, #0x28, lsl #12  ; [pp+0x286a0] ", recognizer: "
    //     0xae2fa4: ldr             x17, [x17, #0x6a0]
    // 0xae2fa8: StoreField: r0->field_23 = r17
    //     0xae2fa8: stur            w17, [x0, #0x23]
    // 0xae2fac: LoadField: r2 = r1->field_f
    //     0xae2fac: ldur            w2, [x1, #0xf]
    // 0xae2fb0: DecompressPointer r2
    //     0xae2fb0: add             x2, x2, HEAP, lsl #32
    // 0xae2fb4: StoreField: r0->field_27 = r2
    //     0xae2fb4: stur            w2, [x0, #0x27]
    // 0xae2fb8: r17 = "}"
    //     0xae2fb8: ldr             x17, [PP, #0x438]  ; [pp+0x438] "}"
    // 0xae2fbc: StoreField: r0->field_2b = r17
    //     0xae2fbc: stur            w17, [x0, #0x2b]
    // 0xae2fc0: SaveReg r0
    //     0xae2fc0: str             x0, [SP, #-8]!
    // 0xae2fc4: r0 = _interpolate()
    //     0xae2fc4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2fc8: add             SP, SP, #8
    // 0xae2fcc: LeaveFrame
    //     0xae2fcc: mov             SP, fp
    //     0xae2fd0: ldp             fp, lr, [SP], #0x10
    // 0xae2fd4: ret
    //     0xae2fd4: ret             
    // 0xae2fd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae2fd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae2fdc: b               #0xae2f54
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0ebf0, size: 0x78
    // 0xb0ebf0: EnterFrame
    //     0xb0ebf0: stp             fp, lr, [SP, #-0x10]!
    //     0xb0ebf4: mov             fp, SP
    // 0xb0ebf8: CheckStackOverflow
    //     0xb0ebf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0ebfc: cmp             SP, x16
    //     0xb0ec00: b.ls            #0xb0ec60
    // 0xb0ec04: ldr             x0, [fp, #0x10]
    // 0xb0ec08: LoadField: r1 = r0->field_7
    //     0xb0ec08: ldur            w1, [x0, #7]
    // 0xb0ec0c: DecompressPointer r1
    //     0xb0ec0c: add             x1, x1, HEAP, lsl #32
    // 0xb0ec10: LoadField: r2 = r0->field_b
    //     0xb0ec10: ldur            w2, [x0, #0xb]
    // 0xb0ec14: DecompressPointer r2
    //     0xb0ec14: add             x2, x2, HEAP, lsl #32
    // 0xb0ec18: LoadField: r3 = r0->field_f
    //     0xb0ec18: ldur            w3, [x0, #0xf]
    // 0xb0ec1c: DecompressPointer r3
    //     0xb0ec1c: add             x3, x3, HEAP, lsl #32
    // 0xb0ec20: LoadField: r4 = r0->field_13
    //     0xb0ec20: ldur            w4, [x0, #0x13]
    // 0xb0ec24: DecompressPointer r4
    //     0xb0ec24: add             x4, x4, HEAP, lsl #32
    // 0xb0ec28: stp             x2, x1, [SP, #-0x10]!
    // 0xb0ec2c: stp             x4, x3, [SP, #-0x10]!
    // 0xb0ec30: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xb0ec30: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xb0ec34: r0 = hash()
    //     0xb0ec34: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0ec38: add             SP, SP, #0x20
    // 0xb0ec3c: mov             x2, x0
    // 0xb0ec40: r0 = BoxInt64Instr(r2)
    //     0xb0ec40: sbfiz           x0, x2, #1, #0x1f
    //     0xb0ec44: cmp             x2, x0, asr #1
    //     0xb0ec48: b.eq            #0xb0ec54
    //     0xb0ec4c: bl              #0xd69bb8
    //     0xb0ec50: stur            x2, [x0, #7]
    // 0xb0ec54: LeaveFrame
    //     0xb0ec54: mov             SP, fp
    //     0xb0ec58: ldp             fp, lr, [SP], #0x10
    // 0xb0ec5c: ret
    //     0xb0ec5c: ret             
    // 0xb0ec60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0ec60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0ec64: b               #0xb0ec04
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9ded4, size: 0x140
    // 0xc9ded4: EnterFrame
    //     0xc9ded4: stp             fp, lr, [SP, #-0x10]!
    //     0xc9ded8: mov             fp, SP
    // 0xc9dedc: CheckStackOverflow
    //     0xc9dedc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9dee0: cmp             SP, x16
    //     0xc9dee4: b.ls            #0xc9e00c
    // 0xc9dee8: ldr             x1, [fp, #0x10]
    // 0xc9deec: cmp             w1, NULL
    // 0xc9def0: b.ne            #0xc9df04
    // 0xc9def4: r0 = false
    //     0xc9def4: add             x0, NULL, #0x30  ; false
    // 0xc9def8: LeaveFrame
    //     0xc9def8: mov             SP, fp
    //     0xc9defc: ldp             fp, lr, [SP], #0x10
    // 0xc9df00: ret
    //     0xc9df00: ret             
    // 0xc9df04: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9df04: mov             x0, #0x76
    //     0xc9df08: tbz             w1, #0, #0xc9df18
    //     0xc9df0c: ldur            x0, [x1, #-1]
    //     0xc9df10: ubfx            x0, x0, #0xc, #0x14
    //     0xc9df14: lsl             x0, x0, #1
    // 0xc9df18: r17 = 4160
    //     0xc9df18: mov             x17, #0x1040
    // 0xc9df1c: cmp             w0, w17
    // 0xc9df20: b.ne            #0xc9dffc
    // 0xc9df24: ldr             x2, [fp, #0x18]
    // 0xc9df28: LoadField: r0 = r1->field_7
    //     0xc9df28: ldur            w0, [x1, #7]
    // 0xc9df2c: DecompressPointer r0
    //     0xc9df2c: add             x0, x0, HEAP, lsl #32
    // 0xc9df30: LoadField: r3 = r2->field_7
    //     0xc9df30: ldur            w3, [x2, #7]
    // 0xc9df34: DecompressPointer r3
    //     0xc9df34: add             x3, x3, HEAP, lsl #32
    // 0xc9df38: r4 = LoadClassIdInstr(r0)
    //     0xc9df38: ldur            x4, [x0, #-1]
    //     0xc9df3c: ubfx            x4, x4, #0xc, #0x14
    // 0xc9df40: stp             x3, x0, [SP, #-0x10]!
    // 0xc9df44: mov             x0, x4
    // 0xc9df48: mov             lr, x0
    // 0xc9df4c: ldr             lr, [x21, lr, lsl #3]
    // 0xc9df50: blr             lr
    // 0xc9df54: add             SP, SP, #0x10
    // 0xc9df58: tbnz            w0, #4, #0xc9dffc
    // 0xc9df5c: ldr             x2, [fp, #0x18]
    // 0xc9df60: ldr             x1, [fp, #0x10]
    // 0xc9df64: LoadField: r0 = r1->field_b
    //     0xc9df64: ldur            w0, [x1, #0xb]
    // 0xc9df68: DecompressPointer r0
    //     0xc9df68: add             x0, x0, HEAP, lsl #32
    // 0xc9df6c: LoadField: r3 = r2->field_b
    //     0xc9df6c: ldur            w3, [x2, #0xb]
    // 0xc9df70: DecompressPointer r3
    //     0xc9df70: add             x3, x3, HEAP, lsl #32
    // 0xc9df74: r4 = LoadClassIdInstr(r0)
    //     0xc9df74: ldur            x4, [x0, #-1]
    //     0xc9df78: ubfx            x4, x4, #0xc, #0x14
    // 0xc9df7c: stp             x3, x0, [SP, #-0x10]!
    // 0xc9df80: mov             x0, x4
    // 0xc9df84: mov             lr, x0
    // 0xc9df88: ldr             lr, [x21, lr, lsl #3]
    // 0xc9df8c: blr             lr
    // 0xc9df90: add             SP, SP, #0x10
    // 0xc9df94: tbnz            w0, #4, #0xc9dffc
    // 0xc9df98: ldr             x1, [fp, #0x18]
    // 0xc9df9c: ldr             x0, [fp, #0x10]
    // 0xc9dfa0: LoadField: r2 = r0->field_f
    //     0xc9dfa0: ldur            w2, [x0, #0xf]
    // 0xc9dfa4: DecompressPointer r2
    //     0xc9dfa4: add             x2, x2, HEAP, lsl #32
    // 0xc9dfa8: LoadField: r3 = r1->field_f
    //     0xc9dfa8: ldur            w3, [x1, #0xf]
    // 0xc9dfac: DecompressPointer r3
    //     0xc9dfac: add             x3, x3, HEAP, lsl #32
    // 0xc9dfb0: cmp             w2, w3
    // 0xc9dfb4: b.ne            #0xc9dffc
    // 0xc9dfb8: LoadField: r2 = r0->field_13
    //     0xc9dfb8: ldur            w2, [x0, #0x13]
    // 0xc9dfbc: DecompressPointer r2
    //     0xc9dfbc: add             x2, x2, HEAP, lsl #32
    // 0xc9dfc0: LoadField: r3 = r1->field_13
    //     0xc9dfc0: ldur            w3, [x1, #0x13]
    // 0xc9dfc4: DecompressPointer r3
    //     0xc9dfc4: add             x3, x3, HEAP, lsl #32
    // 0xc9dfc8: cmp             w2, w3
    // 0xc9dfcc: b.ne            #0xc9dffc
    // 0xc9dfd0: LoadField: r2 = r0->field_1b
    //     0xc9dfd0: ldur            w2, [x0, #0x1b]
    // 0xc9dfd4: DecompressPointer r2
    //     0xc9dfd4: add             x2, x2, HEAP, lsl #32
    // 0xc9dfd8: LoadField: r0 = r1->field_1b
    //     0xc9dfd8: ldur            w0, [x1, #0x1b]
    // 0xc9dfdc: DecompressPointer r0
    //     0xc9dfdc: add             x0, x0, HEAP, lsl #32
    // 0xc9dfe0: r16 = <StringAttribute>
    //     0xc9dfe0: ldr             x16, [PP, #0x48a0]  ; [pp+0x48a0] TypeArguments: <StringAttribute>
    // 0xc9dfe4: stp             x2, x16, [SP, #-0x10]!
    // 0xc9dfe8: SaveReg r0
    //     0xc9dfe8: str             x0, [SP, #-8]!
    // 0xc9dfec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc9dfec: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc9dff0: r0 = listEquals()
    //     0xc9dff0: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc9dff4: add             SP, SP, #0x18
    // 0xc9dff8: b               #0xc9e000
    // 0xc9dffc: r0 = false
    //     0xc9dffc: add             x0, NULL, #0x30  ; false
    // 0xc9e000: LeaveFrame
    //     0xc9e000: mov             SP, fp
    //     0xc9e004: ldp             fp, lr, [SP], #0x10
    // 0xc9e008: ret
    //     0xc9e008: ret             
    // 0xc9e00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9e00c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9e010: b               #0xc9dee8
  }
}

// class id: 2081, size: 0x10, field offset: 0x8
class Accumulator extends Object {

  _ increment(/* No info */) {
    // ** addr: 0x5221fc, size: 0x1c
    // 0x5221fc: ldr             x1, [SP, #8]
    // 0x522200: LoadField: r2 = r1->field_7
    //     0x522200: ldur            x2, [x1, #7]
    // 0x522204: ldr             x3, [SP]
    // 0x522208: add             x4, x2, x3
    // 0x52220c: StoreField: r1->field_7 = r4
    //     0x52220c: stur            x4, [x1, #7]
    // 0x522210: r0 = Null
    //     0x522210: mov             x0, NULL
    // 0x522214: ret
    //     0x522214: ret             
  }
}

// class id: 3472, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class InlineSpan extends DiagnosticableTree {

  _ toPlainText(/* No info */) {
    // ** addr: 0x521774, size: 0xc8
    // 0x521774: EnterFrame
    //     0x521774: stp             fp, lr, [SP, #-0x10]!
    //     0x521778: mov             fp, SP
    // 0x52177c: AllocStack(0x8)
    //     0x52177c: sub             SP, SP, #8
    // 0x521780: CheckStackOverflow
    //     0x521780: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x521784: cmp             SP, x16
    //     0x521788: b.ls            #0x521834
    // 0x52178c: r0 = StringBuffer()
    //     0x52178c: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x521790: stur            x0, [fp, #-8]
    // 0x521794: SaveReg r0
    //     0x521794: str             x0, [SP, #-8]!
    // 0x521798: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x521798: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x52179c: r0 = StringBuffer()
    //     0x52179c: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x5217a0: add             SP, SP, #8
    // 0x5217a4: ldr             x0, [fp, #0x10]
    // 0x5217a8: r1 = LoadClassIdInstr(r0)
    //     0x5217a8: ldur            x1, [x0, #-1]
    //     0x5217ac: ubfx            x1, x1, #0xc, #0x14
    // 0x5217b0: lsl             x1, x1, #1
    // 0x5217b4: r17 = 6958
    //     0x5217b4: mov             x17, #0x1b2e
    // 0x5217b8: cmp             w1, w17
    // 0x5217bc: b.gt            #0x5217e4
    // 0x5217c0: r17 = 6954
    //     0x5217c0: mov             x17, #0x1b2a
    // 0x5217c4: cmp             w1, w17
    // 0x5217c8: b.lt            #0x5217e4
    // 0x5217cc: ldur            x16, [fp, #-8]
    // 0x5217d0: r30 = 131064
    //     0x5217d0: mov             lr, #0x1fff8
    // 0x5217d4: stp             lr, x16, [SP, #-0x10]!
    // 0x5217d8: r0 = writeCharCode()
    //     0x5217d8: bl              #0x4d3a84  ; [dart:core] StringBuffer::writeCharCode
    // 0x5217dc: add             SP, SP, #0x10
    // 0x5217e0: b               #0x521818
    // 0x5217e4: r1 = LoadClassIdInstr(r0)
    //     0x5217e4: ldur            x1, [x0, #-1]
    //     0x5217e8: ubfx            x1, x1, #0xc, #0x14
    // 0x5217ec: ldur            x16, [fp, #-8]
    // 0x5217f0: stp             x16, x0, [SP, #-0x10]!
    // 0x5217f4: r16 = true
    //     0x5217f4: add             x16, NULL, #0x20  ; true
    // 0x5217f8: SaveReg r16
    //     0x5217f8: str             x16, [SP, #-8]!
    // 0x5217fc: mov             x0, x1
    // 0x521800: r4 = const [0, 0x3, 0x3, 0x2, includePlaceholders, 0x2, null]
    //     0x521800: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d410] List(7) [0, 0x3, 0x3, 0x2, "includePlaceholders", 0x2, Null]
    //     0x521804: ldr             x4, [x4, #0x410]
    // 0x521808: r0 = GDT[cid_x0 + -0xec2]()
    //     0x521808: sub             lr, x0, #0xec2
    //     0x52180c: ldr             lr, [x21, lr, lsl #3]
    //     0x521810: blr             lr
    // 0x521814: add             SP, SP, #0x18
    // 0x521818: ldur            x16, [fp, #-8]
    // 0x52181c: SaveReg r16
    //     0x52181c: str             x16, [SP, #-8]!
    // 0x521820: r0 = toString()
    //     0x521820: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x521824: add             SP, SP, #8
    // 0x521828: LeaveFrame
    //     0x521828: mov             SP, fp
    //     0x52182c: ldp             fp, lr, [SP], #0x10
    // 0x521830: ret
    //     0x521830: ret             
    // 0x521834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x521834: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x521838: b               #0x52178c
  }
  _ codeUnitAt(/* No info */) {
    // ** addr: 0x522038, size: 0x134
    // 0x522038: EnterFrame
    //     0x522038: stp             fp, lr, [SP, #-0x10]!
    //     0x52203c: mov             fp, SP
    // 0x522040: AllocStack(0x10)
    //     0x522040: sub             SP, SP, #0x10
    // 0x522044: CheckStackOverflow
    //     0x522044: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x522048: cmp             SP, x16
    //     0x52204c: b.ls            #0x522164
    // 0x522050: ldr             x2, [fp, #0x10]
    // 0x522054: r0 = BoxInt64Instr(r2)
    //     0x522054: sbfiz           x0, x2, #1, #0x1f
    //     0x522058: cmp             x2, x0, asr #1
    //     0x52205c: b.eq            #0x522068
    //     0x522060: bl              #0xd69bb8
    //     0x522064: stur            x2, [x0, #7]
    // 0x522068: stur            x0, [fp, #-8]
    // 0x52206c: r1 = 3
    //     0x52206c: mov             x1, #3
    // 0x522070: r0 = AllocateContext()
    //     0x522070: bl              #0xd68aa4  ; AllocateContextStub
    // 0x522074: mov             x1, x0
    // 0x522078: ldur            x0, [fp, #-8]
    // 0x52207c: stur            x1, [fp, #-0x10]
    // 0x522080: StoreField: r1->field_f = r0
    //     0x522080: stur            w0, [x1, #0xf]
    // 0x522084: ldr             x0, [fp, #0x10]
    // 0x522088: tbz             x0, #0x3f, #0x52209c
    // 0x52208c: r0 = Null
    //     0x52208c: mov             x0, NULL
    // 0x522090: LeaveFrame
    //     0x522090: mov             SP, fp
    //     0x522094: ldp             fp, lr, [SP], #0x10
    // 0x522098: ret
    //     0x522098: ret             
    // 0x52209c: ldr             x0, [fp, #0x18]
    // 0x5220a0: r0 = Accumulator()
    //     0x5220a0: bl              #0x522218  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0x5220a4: mov             x1, x0
    // 0x5220a8: r0 = 0
    //     0x5220a8: mov             x0, #0
    // 0x5220ac: StoreField: r1->field_7 = r0
    //     0x5220ac: stur            x0, [x1, #7]
    // 0x5220b0: ldur            x2, [fp, #-0x10]
    // 0x5220b4: StoreField: r2->field_13 = r1
    //     0x5220b4: stur            w1, [x2, #0x13]
    // 0x5220b8: StoreField: r2->field_17 = rNULL
    //     0x5220b8: stur            NULL, [x2, #0x17]
    // 0x5220bc: ldr             x0, [fp, #0x18]
    // 0x5220c0: r3 = LoadClassIdInstr(r0)
    //     0x5220c0: ldur            x3, [x0, #-1]
    //     0x5220c4: ubfx            x3, x3, #0xc, #0x14
    // 0x5220c8: lsl             x3, x3, #1
    // 0x5220cc: r17 = 6958
    //     0x5220cc: mov             x17, #0x1b2e
    // 0x5220d0: cmp             w3, w17
    // 0x5220d4: b.gt            #0x522110
    // 0x5220d8: r17 = 6954
    //     0x5220d8: mov             x17, #0x1b2a
    // 0x5220dc: cmp             w3, w17
    // 0x5220e0: b.lt            #0x522108
    // 0x5220e4: r0 = 1
    //     0x5220e4: mov             x0, #1
    // 0x5220e8: stp             x0, x1, [SP, #-0x10]!
    // 0x5220ec: r0 = increment()
    //     0x5220ec: bl              #0x5221fc  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0x5220f0: add             SP, SP, #0x10
    // 0x5220f4: ldur            x3, [fp, #-0x10]
    // 0x5220f8: r0 = 131064
    //     0x5220f8: mov             x0, #0x1fff8
    // 0x5220fc: StoreField: r3->field_17 = r0
    //     0x5220fc: stur            w0, [x3, #0x17]
    // 0x522100: mov             x1, x3
    // 0x522104: b               #0x522150
    // 0x522108: mov             x3, x2
    // 0x52210c: b               #0x522114
    // 0x522110: mov             x3, x2
    // 0x522114: mov             x2, x3
    // 0x522118: r1 = Function '<anonymous closure>':.
    //     0x522118: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f570] AnonymousClosure: (0x522224), in [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt (0x522038)
    //     0x52211c: ldr             x1, [x1, #0x570]
    // 0x522120: r0 = AllocateClosure()
    //     0x522120: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x522124: mov             x1, x0
    // 0x522128: ldr             x0, [fp, #0x18]
    // 0x52212c: r2 = LoadClassIdInstr(r0)
    //     0x52212c: ldur            x2, [x0, #-1]
    //     0x522130: ubfx            x2, x2, #0xc, #0x14
    // 0x522134: stp             x1, x0, [SP, #-0x10]!
    // 0x522138: mov             x0, x2
    // 0x52213c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x52213c: sub             lr, x0, #1, lsl #12
    //     0x522140: ldr             lr, [x21, lr, lsl #3]
    //     0x522144: blr             lr
    // 0x522148: add             SP, SP, #0x10
    // 0x52214c: ldur            x1, [fp, #-0x10]
    // 0x522150: LoadField: r0 = r1->field_17
    //     0x522150: ldur            w0, [x1, #0x17]
    // 0x522154: DecompressPointer r0
    //     0x522154: add             x0, x0, HEAP, lsl #32
    // 0x522158: LeaveFrame
    //     0x522158: mov             SP, fp
    //     0x52215c: ldp             fp, lr, [SP], #0x10
    // 0x522160: ret
    //     0x522160: ret             
    // 0x522164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x522164: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x522168: b               #0x522050
  }
  [closure] bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x522224, size: 0xd4
    // 0x522224: EnterFrame
    //     0x522224: stp             fp, lr, [SP, #-0x10]!
    //     0x522228: mov             fp, SP
    // 0x52222c: AllocStack(0x8)
    //     0x52222c: sub             SP, SP, #8
    // 0x522230: SetupParameters()
    //     0x522230: ldr             x0, [fp, #0x18]
    //     0x522234: ldur            w1, [x0, #0x17]
    //     0x522238: add             x1, x1, HEAP, lsl #32
    //     0x52223c: stur            x1, [fp, #-8]
    // 0x522240: CheckStackOverflow
    //     0x522240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x522244: cmp             SP, x16
    //     0x522248: b.ls            #0x5222f0
    // 0x52224c: LoadField: r0 = r1->field_f
    //     0x52224c: ldur            w0, [x1, #0xf]
    // 0x522250: DecompressPointer r0
    //     0x522250: add             x0, x0, HEAP, lsl #32
    // 0x522254: LoadField: r2 = r1->field_13
    //     0x522254: ldur            w2, [x1, #0x13]
    // 0x522258: DecompressPointer r2
    //     0x522258: add             x2, x2, HEAP, lsl #32
    // 0x52225c: ldr             x3, [fp, #0x10]
    // 0x522260: r4 = LoadClassIdInstr(r3)
    //     0x522260: ldur            x4, [x3, #-1]
    //     0x522264: ubfx            x4, x4, #0xc, #0x14
    // 0x522268: lsl             x4, x4, #1
    // 0x52226c: r17 = 6958
    //     0x52226c: mov             x17, #0x1b2e
    // 0x522270: cmp             w4, w17
    // 0x522274: b.gt            #0x52229c
    // 0x522278: r17 = 6954
    //     0x522278: mov             x17, #0x1b2a
    // 0x52227c: cmp             w4, w17
    // 0x522280: b.lt            #0x52229c
    // 0x522284: r0 = 1
    //     0x522284: mov             x0, #1
    // 0x522288: stp             x0, x2, [SP, #-0x10]!
    // 0x52228c: r0 = increment()
    //     0x52228c: bl              #0x5221fc  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0x522290: add             SP, SP, #0x10
    // 0x522294: r2 = 131064
    //     0x522294: mov             x2, #0x1fff8
    // 0x522298: b               #0x5222cc
    // 0x52229c: r1 = LoadInt32Instr(r0)
    //     0x52229c: sbfx            x1, x0, #1, #0x1f
    //     0x5222a0: tbz             w0, #0, #0x5222a8
    //     0x5222a4: ldur            x1, [x0, #7]
    // 0x5222a8: r0 = LoadClassIdInstr(r3)
    //     0x5222a8: ldur            x0, [x3, #-1]
    //     0x5222ac: ubfx            x0, x0, #0xc, #0x14
    // 0x5222b0: stp             x1, x3, [SP, #-0x10]!
    // 0x5222b4: SaveReg r2
    //     0x5222b4: str             x2, [SP, #-8]!
    // 0x5222b8: r0 = GDT[cid_x0 + 0xfc4]()
    //     0x5222b8: add             lr, x0, #0xfc4
    //     0x5222bc: ldr             lr, [x21, lr, lsl #3]
    //     0x5222c0: blr             lr
    // 0x5222c4: add             SP, SP, #0x18
    // 0x5222c8: mov             x2, x0
    // 0x5222cc: ldur            x1, [fp, #-8]
    // 0x5222d0: StoreField: r1->field_17 = r2
    //     0x5222d0: stur            w2, [x1, #0x17]
    // 0x5222d4: cmp             w2, NULL
    // 0x5222d8: r16 = true
    //     0x5222d8: add             x16, NULL, #0x20  ; true
    // 0x5222dc: r17 = false
    //     0x5222dc: add             x17, NULL, #0x30  ; false
    // 0x5222e0: csel            x0, x16, x17, eq
    // 0x5222e4: LeaveFrame
    //     0x5222e4: mov             SP, fp
    //     0x5222e8: ldp             fp, lr, [SP], #0x10
    // 0x5222ec: ret
    //     0x5222ec: ret             
    // 0x5222f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5222f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5222f4: b               #0x52224c
  }
  [closure] bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x624c1c, size: 0x104
    // 0x624c1c: EnterFrame
    //     0x624c1c: stp             fp, lr, [SP, #-0x10]!
    //     0x624c20: mov             fp, SP
    // 0x624c24: AllocStack(0x8)
    //     0x624c24: sub             SP, SP, #8
    // 0x624c28: SetupParameters()
    //     0x624c28: ldr             x0, [fp, #0x18]
    //     0x624c2c: ldur            w1, [x0, #0x17]
    //     0x624c30: add             x1, x1, HEAP, lsl #32
    //     0x624c34: stur            x1, [fp, #-8]
    // 0x624c38: CheckStackOverflow
    //     0x624c38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x624c3c: cmp             SP, x16
    //     0x624c40: b.ls            #0x624d18
    // 0x624c44: LoadField: r0 = r1->field_f
    //     0x624c44: ldur            w0, [x1, #0xf]
    // 0x624c48: DecompressPointer r0
    //     0x624c48: add             x0, x0, HEAP, lsl #32
    // 0x624c4c: LoadField: r2 = r1->field_13
    //     0x624c4c: ldur            w2, [x1, #0x13]
    // 0x624c50: DecompressPointer r2
    //     0x624c50: add             x2, x2, HEAP, lsl #32
    // 0x624c54: ldr             x3, [fp, #0x10]
    // 0x624c58: r4 = LoadClassIdInstr(r3)
    //     0x624c58: ldur            x4, [x3, #-1]
    //     0x624c5c: ubfx            x4, x4, #0xc, #0x14
    // 0x624c60: lsl             x4, x4, #1
    // 0x624c64: r17 = 6958
    //     0x624c64: mov             x17, #0x1b2e
    // 0x624c68: cmp             w4, w17
    // 0x624c6c: b.gt            #0x624cb0
    // 0x624c70: r17 = 6954
    //     0x624c70: mov             x17, #0x1b2a
    // 0x624c74: cmp             w4, w17
    // 0x624c78: b.lt            #0x624cb0
    // 0x624c7c: LoadField: r4 = r0->field_7
    //     0x624c7c: ldur            x4, [x0, #7]
    // 0x624c80: LoadField: r0 = r2->field_7
    //     0x624c80: ldur            x0, [x2, #7]
    // 0x624c84: cmp             x4, x0
    // 0x624c88: b.ne            #0x624c94
    // 0x624c8c: mov             x2, x3
    // 0x624c90: b               #0x624cdc
    // 0x624c94: r0 = 1
    //     0x624c94: mov             x0, #1
    // 0x624c98: stp             x0, x2, [SP, #-0x10]!
    // 0x624c9c: r0 = increment()
    //     0x624c9c: bl              #0x5221fc  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0x624ca0: add             SP, SP, #0x10
    // 0x624ca4: ldur            x1, [fp, #-8]
    // 0x624ca8: r2 = Null
    //     0x624ca8: mov             x2, NULL
    // 0x624cac: b               #0x624cdc
    // 0x624cb0: r1 = LoadClassIdInstr(r3)
    //     0x624cb0: ldur            x1, [x3, #-1]
    //     0x624cb4: ubfx            x1, x1, #0xc, #0x14
    // 0x624cb8: stp             x0, x3, [SP, #-0x10]!
    // 0x624cbc: SaveReg r2
    //     0x624cbc: str             x2, [SP, #-8]!
    // 0x624cc0: mov             x0, x1
    // 0x624cc4: r0 = GDT[cid_x0 + 0xe83]()
    //     0x624cc4: add             lr, x0, #0xe83
    //     0x624cc8: ldr             lr, [x21, lr, lsl #3]
    //     0x624ccc: blr             lr
    // 0x624cd0: add             SP, SP, #0x18
    // 0x624cd4: mov             x2, x0
    // 0x624cd8: ldur            x1, [fp, #-8]
    // 0x624cdc: mov             x0, x2
    // 0x624ce0: StoreField: r1->field_17 = r0
    //     0x624ce0: stur            w0, [x1, #0x17]
    //     0x624ce4: ldurb           w16, [x1, #-1]
    //     0x624ce8: ldurb           w17, [x0, #-1]
    //     0x624cec: and             x16, x17, x16, lsr #2
    //     0x624cf0: tst             x16, HEAP, lsr #32
    //     0x624cf4: b.eq            #0x624cfc
    //     0x624cf8: bl              #0xd6826c
    // 0x624cfc: cmp             w2, NULL
    // 0x624d00: r16 = true
    //     0x624d00: add             x16, NULL, #0x20  ; true
    // 0x624d04: r17 = false
    //     0x624d04: add             x17, NULL, #0x30  ; false
    // 0x624d08: csel            x0, x16, x17, eq
    // 0x624d0c: LeaveFrame
    //     0x624d0c: mov             SP, fp
    //     0x624d10: ldp             fp, lr, [SP], #0x10
    // 0x624d14: ret
    //     0x624d14: ret             
    // 0x624d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x624d18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x624d1c: b               #0x624c44
  }
  _ getSemanticsInformation(/* No info */) {
    // ** addr: 0x64ce54, size: 0x118
    // 0x64ce54: EnterFrame
    //     0x64ce54: stp             fp, lr, [SP, #-0x10]!
    //     0x64ce58: mov             fp, SP
    // 0x64ce5c: AllocStack(0x10)
    //     0x64ce5c: sub             SP, SP, #0x10
    // 0x64ce60: CheckStackOverflow
    //     0x64ce60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ce64: cmp             SP, x16
    //     0x64ce68: b.ls            #0x64cf60
    // 0x64ce6c: r16 = <InlineSpanSemanticsInformation>
    //     0x64ce6c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22328] TypeArguments: <InlineSpanSemanticsInformation>
    //     0x64ce70: ldr             x16, [x16, #0x328]
    // 0x64ce74: stp             xzr, x16, [SP, #-0x10]!
    // 0x64ce78: r0 = _GrowableList()
    //     0x64ce78: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x64ce7c: add             SP, SP, #0x10
    // 0x64ce80: mov             x1, x0
    // 0x64ce84: ldr             x0, [fp, #0x10]
    // 0x64ce88: stur            x1, [fp, #-0x10]
    // 0x64ce8c: r2 = LoadClassIdInstr(r0)
    //     0x64ce8c: ldur            x2, [x0, #-1]
    //     0x64ce90: ubfx            x2, x2, #0xc, #0x14
    // 0x64ce94: lsl             x2, x2, #1
    // 0x64ce98: r17 = 6958
    //     0x64ce98: mov             x17, #0x1b2e
    // 0x64ce9c: cmp             w2, w17
    // 0x64cea0: b.gt            #0x64cf28
    // 0x64cea4: r17 = 6954
    //     0x64cea4: mov             x17, #0x1b2a
    // 0x64cea8: cmp             w2, w17
    // 0x64ceac: b.lt            #0x64cf20
    // 0x64ceb0: LoadField: r0 = r1->field_b
    //     0x64ceb0: ldur            w0, [x1, #0xb]
    // 0x64ceb4: DecompressPointer r0
    //     0x64ceb4: add             x0, x0, HEAP, lsl #32
    // 0x64ceb8: stur            x0, [fp, #-8]
    // 0x64cebc: LoadField: r2 = r1->field_f
    //     0x64cebc: ldur            w2, [x1, #0xf]
    // 0x64cec0: DecompressPointer r2
    //     0x64cec0: add             x2, x2, HEAP, lsl #32
    // 0x64cec4: LoadField: r3 = r2->field_b
    //     0x64cec4: ldur            w3, [x2, #0xb]
    // 0x64cec8: DecompressPointer r3
    //     0x64cec8: add             x3, x3, HEAP, lsl #32
    // 0x64cecc: cmp             w0, w3
    // 0x64ced0: b.ne            #0x64cee0
    // 0x64ced4: SaveReg r1
    //     0x64ced4: str             x1, [SP, #-8]!
    // 0x64ced8: r0 = _growToNextCapacity()
    //     0x64ced8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x64cedc: add             SP, SP, #8
    // 0x64cee0: ldur            x2, [fp, #-0x10]
    // 0x64cee4: ldur            x0, [fp, #-8]
    // 0x64cee8: r3 = LoadInt32Instr(r0)
    //     0x64cee8: sbfx            x3, x0, #1, #0x1f
    // 0x64ceec: add             x0, x3, #1
    // 0x64cef0: lsl             x1, x0, #1
    // 0x64cef4: StoreField: r2->field_b = r1
    //     0x64cef4: stur            w1, [x2, #0xb]
    // 0x64cef8: mov             x1, x3
    // 0x64cefc: cmp             x1, x0
    // 0x64cf00: b.hs            #0x64cf68
    // 0x64cf04: LoadField: r0 = r2->field_f
    //     0x64cf04: ldur            w0, [x2, #0xf]
    // 0x64cf08: DecompressPointer r0
    //     0x64cf08: add             x0, x0, HEAP, lsl #32
    // 0x64cf0c: add             x1, x0, x3, lsl #2
    // 0x64cf10: r17 = Instance_InlineSpanSemanticsInformation
    //     0x64cf10: add             x17, PP, #0x22, lsl #12  ; [pp+0x22368] Obj!InlineSpanSemanticsInformation@b356d1
    //     0x64cf14: ldr             x17, [x17, #0x368]
    // 0x64cf18: StoreField: r1->field_f = r17
    //     0x64cf18: stur            w17, [x1, #0xf]
    // 0x64cf1c: b               #0x64cf50
    // 0x64cf20: mov             x2, x1
    // 0x64cf24: b               #0x64cf2c
    // 0x64cf28: mov             x2, x1
    // 0x64cf2c: r1 = LoadClassIdInstr(r0)
    //     0x64cf2c: ldur            x1, [x0, #-1]
    //     0x64cf30: ubfx            x1, x1, #0xc, #0x14
    // 0x64cf34: stp             x2, x0, [SP, #-0x10]!
    // 0x64cf38: mov             x0, x1
    // 0x64cf3c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x64cf3c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x64cf40: r0 = GDT[cid_x0 + -0xe63]()
    //     0x64cf40: sub             lr, x0, #0xe63
    //     0x64cf44: ldr             lr, [x21, lr, lsl #3]
    //     0x64cf48: blr             lr
    // 0x64cf4c: add             SP, SP, #0x10
    // 0x64cf50: ldur            x0, [fp, #-0x10]
    // 0x64cf54: LeaveFrame
    //     0x64cf54: mov             SP, fp
    //     0x64cf58: ldp             fp, lr, [SP], #0x10
    // 0x64cf5c: ret
    //     0x64cf5c: ret             
    // 0x64cf60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64cf60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64cf64: b               #0x64ce6c
    // 0x64cf68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x64cf68: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc75b44, size: 0x12c
    // 0xc75b44: EnterFrame
    //     0xc75b44: stp             fp, lr, [SP, #-0x10]!
    //     0xc75b48: mov             fp, SP
    // 0xc75b4c: AllocStack(0x8)
    //     0xc75b4c: sub             SP, SP, #8
    // 0xc75b50: CheckStackOverflow
    //     0xc75b50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc75b54: cmp             SP, x16
    //     0xc75b58: b.ls            #0xc75c68
    // 0xc75b5c: ldr             x2, [fp, #0x18]
    // 0xc75b60: ldr             x1, [fp, #0x10]
    // 0xc75b64: cmp             w2, w1
    // 0xc75b68: b.ne            #0xc75b7c
    // 0xc75b6c: r0 = true
    //     0xc75b6c: add             x0, NULL, #0x20  ; true
    // 0xc75b70: LeaveFrame
    //     0xc75b70: mov             SP, fp
    //     0xc75b74: ldp             fp, lr, [SP], #0x10
    // 0xc75b78: ret
    //     0xc75b78: ret             
    // 0xc75b7c: r0 = 59
    //     0xc75b7c: mov             x0, #0x3b
    // 0xc75b80: branchIfSmi(r1, 0xc75b8c)
    //     0xc75b80: tbz             w1, #0, #0xc75b8c
    // 0xc75b84: r0 = LoadClassIdInstr(r1)
    //     0xc75b84: ldur            x0, [x1, #-1]
    //     0xc75b88: ubfx            x0, x0, #0xc, #0x14
    // 0xc75b8c: SaveReg r1
    //     0xc75b8c: str             x1, [SP, #-8]!
    // 0xc75b90: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc75b90: mov             x17, #0x57c5
    //     0xc75b94: add             lr, x0, x17
    //     0xc75b98: ldr             lr, [x21, lr, lsl #3]
    //     0xc75b9c: blr             lr
    // 0xc75ba0: add             SP, SP, #8
    // 0xc75ba4: stur            x0, [fp, #-8]
    // 0xc75ba8: ldr             x16, [fp, #0x18]
    // 0xc75bac: SaveReg r16
    //     0xc75bac: str             x16, [SP, #-8]!
    // 0xc75bb0: r0 = runtimeType()
    //     0xc75bb0: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc75bb4: add             SP, SP, #8
    // 0xc75bb8: mov             x1, x0
    // 0xc75bbc: ldur            x0, [fp, #-8]
    // 0xc75bc0: r2 = LoadClassIdInstr(r0)
    //     0xc75bc0: ldur            x2, [x0, #-1]
    //     0xc75bc4: ubfx            x2, x2, #0xc, #0x14
    // 0xc75bc8: stp             x1, x0, [SP, #-0x10]!
    // 0xc75bcc: mov             x0, x2
    // 0xc75bd0: mov             lr, x0
    // 0xc75bd4: ldr             lr, [x21, lr, lsl #3]
    // 0xc75bd8: blr             lr
    // 0xc75bdc: add             SP, SP, #0x10
    // 0xc75be0: tbz             w0, #4, #0xc75bf4
    // 0xc75be4: r0 = false
    //     0xc75be4: add             x0, NULL, #0x30  ; false
    // 0xc75be8: LeaveFrame
    //     0xc75be8: mov             SP, fp
    //     0xc75bec: ldp             fp, lr, [SP], #0x10
    // 0xc75bf0: ret
    //     0xc75bf0: ret             
    // 0xc75bf4: ldr             x0, [fp, #0x10]
    // 0xc75bf8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc75bf8: mov             x1, #0x76
    //     0xc75bfc: tbz             w0, #0, #0xc75c0c
    //     0xc75c00: ldur            x1, [x0, #-1]
    //     0xc75c04: ubfx            x1, x1, #0xc, #0x14
    //     0xc75c08: lsl             x1, x1, #1
    // 0xc75c0c: r2 = LoadInt32Instr(r1)
    //     0xc75c0c: sbfx            x2, x1, #1, #0x1f
    // 0xc75c10: cmp             x2, #0xd91
    // 0xc75c14: b.lt            #0xc75c58
    // 0xc75c18: cmp             x2, #0xd97
    // 0xc75c1c: b.gt            #0xc75c58
    // 0xc75c20: ldr             x1, [fp, #0x18]
    // 0xc75c24: LoadField: r2 = r0->field_7
    //     0xc75c24: ldur            w2, [x0, #7]
    // 0xc75c28: DecompressPointer r2
    //     0xc75c28: add             x2, x2, HEAP, lsl #32
    // 0xc75c2c: LoadField: r0 = r1->field_7
    //     0xc75c2c: ldur            w0, [x1, #7]
    // 0xc75c30: DecompressPointer r0
    //     0xc75c30: add             x0, x0, HEAP, lsl #32
    // 0xc75c34: r1 = LoadClassIdInstr(r2)
    //     0xc75c34: ldur            x1, [x2, #-1]
    //     0xc75c38: ubfx            x1, x1, #0xc, #0x14
    // 0xc75c3c: stp             x0, x2, [SP, #-0x10]!
    // 0xc75c40: mov             x0, x1
    // 0xc75c44: mov             lr, x0
    // 0xc75c48: ldr             lr, [x21, lr, lsl #3]
    // 0xc75c4c: blr             lr
    // 0xc75c50: add             SP, SP, #0x10
    // 0xc75c54: b               #0xc75c5c
    // 0xc75c58: r0 = false
    //     0xc75c58: add             x0, NULL, #0x30  ; false
    // 0xc75c5c: LeaveFrame
    //     0xc75c5c: mov             SP, fp
    //     0xc75c60: ldp             fp, lr, [SP], #0x10
    // 0xc75c64: ret
    //     0xc75c64: ret             
    // 0xc75c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc75c68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc75c6c: b               #0xc75b5c
  }
}

// lib: , url: package:flutter/src/painting/geometry.dart

// class id: 1049364, size: 0x8
class :: {

  static _ positionDependentBox(/* No info */) {
    // ** addr: 0xb10dfc, size: 0x288
    // 0xb10dfc: EnterFrame
    //     0xb10dfc: stp             fp, lr, [SP, #-0x10]!
    //     0xb10e00: mov             fp, SP
    // 0xb10e04: AllocStack(0x10)
    //     0xb10e04: sub             SP, SP, #0x10
    // 0xb10e08: d0 = 10.000000
    //     0xb10e08: fmov            d0, #10.00000000
    // 0xb10e0c: CheckStackOverflow
    //     0xb10e0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb10e10: cmp             SP, x16
    //     0xb10e14: b.ls            #0xb11050
    // 0xb10e18: ldr             x0, [fp, #0x18]
    // 0xb10e1c: LoadField: d1 = r0->field_f
    //     0xb10e1c: ldur            d1, [x0, #0xf]
    // 0xb10e20: ldr             d2, [fp, #0x10]
    // 0xb10e24: fadd            d3, d1, d2
    // 0xb10e28: ldr             x1, [fp, #0x28]
    // 0xb10e2c: stur            d3, [fp, #-0x10]
    // 0xb10e30: LoadField: d4 = r1->field_f
    //     0xb10e30: ldur            d4, [x1, #0xf]
    // 0xb10e34: fadd            d5, d3, d4
    // 0xb10e38: ldr             x2, [fp, #0x20]
    // 0xb10e3c: LoadField: d6 = r2->field_f
    //     0xb10e3c: ldur            d6, [x2, #0xf]
    // 0xb10e40: fsub            d7, d6, d0
    // 0xb10e44: stur            d7, [fp, #-8]
    // 0xb10e48: fsub            d6, d1, d2
    // 0xb10e4c: fsub            d1, d6, d4
    // 0xb10e50: fcmp            d1, d0
    // 0xb10e54: b.vs            #0xb10e5c
    // 0xb10e58: b.ge            #0xb10e64
    // 0xb10e5c: r3 = false
    //     0xb10e5c: add             x3, NULL, #0x30  ; false
    // 0xb10e60: b               #0xb10e68
    // 0xb10e64: r3 = true
    //     0xb10e64: add             x3, NULL, #0x20  ; true
    // 0xb10e68: fcmp            d5, d7
    // 0xb10e6c: b.vs            #0xb10e74
    // 0xb10e70: b.le            #0xb10e7c
    // 0xb10e74: eor             x4, x3, #0x10
    // 0xb10e78: tbnz            w4, #4, #0xb10f38
    // 0xb10e7c: fcmp            d3, d7
    // 0xb10e80: b.vs            #0xb10e90
    // 0xb10e84: b.le            #0xb10e90
    // 0xb10e88: mov             v0.16b, v7.16b
    // 0xb10e8c: b               #0xb10f2c
    // 0xb10e90: fcmp            d3, d7
    // 0xb10e94: b.vs            #0xb10ea4
    // 0xb10e98: b.ge            #0xb10ea4
    // 0xb10e9c: mov             v0.16b, v3.16b
    // 0xb10ea0: b               #0xb10f2c
    // 0xb10ea4: d2 = 0.000000
    //     0xb10ea4: eor             v2.16b, v2.16b, v2.16b
    // 0xb10ea8: fcmp            d3, d2
    // 0xb10eac: b.vs            #0xb10eb4
    // 0xb10eb0: b.eq            #0xb10ebc
    // 0xb10eb4: r3 = false
    //     0xb10eb4: add             x3, NULL, #0x30  ; false
    // 0xb10eb8: b               #0xb10ec0
    // 0xb10ebc: r3 = true
    //     0xb10ebc: add             x3, NULL, #0x20  ; true
    // 0xb10ec0: tbnz            w3, #4, #0xb10ed8
    // 0xb10ec4: fadd            d1, d3, d7
    // 0xb10ec8: fmul            d2, d1, d3
    // 0xb10ecc: fmul            d1, d2, d7
    // 0xb10ed0: mov             v0.16b, v1.16b
    // 0xb10ed4: b               #0xb10f2c
    // 0xb10ed8: tbnz            w3, #4, #0xb10f1c
    // 0xb10edc: r3 = inline_Allocate_Double()
    //     0xb10edc: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb10ee0: add             x3, x3, #0x10
    //     0xb10ee4: cmp             x4, x3
    //     0xb10ee8: b.ls            #0xb11058
    //     0xb10eec: str             x3, [THR, #0x60]  ; THR::top
    //     0xb10ef0: sub             x3, x3, #0xf
    //     0xb10ef4: mov             x4, #0xd108
    //     0xb10ef8: movk            x4, #3, lsl #16
    //     0xb10efc: stur            x4, [x3, #-1]
    // 0xb10f00: StoreField: r3->field_7 = d7
    //     0xb10f00: stur            d7, [x3, #7]
    // 0xb10f04: SaveReg r3
    //     0xb10f04: str             x3, [SP, #-8]!
    // 0xb10f08: r0 = isNegative()
    //     0xb10f08: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xb10f0c: add             SP, SP, #8
    // 0xb10f10: tbnz            w0, #4, #0xb10f1c
    // 0xb10f14: ldur            d0, [fp, #-8]
    // 0xb10f18: b               #0xb10f2c
    // 0xb10f1c: ldur            d0, [fp, #-8]
    // 0xb10f20: fcmp            d0, d0
    // 0xb10f24: b.vs            #0xb10f2c
    // 0xb10f28: ldur            d0, [fp, #-0x10]
    // 0xb10f2c: mov             v2.16b, v0.16b
    // 0xb10f30: d0 = 10.000000
    //     0xb10f30: fmov            d0, #10.00000000
    // 0xb10f34: b               #0xb10f74
    // 0xb10f38: d2 = 0.000000
    //     0xb10f38: eor             v2.16b, v2.16b, v2.16b
    // 0xb10f3c: fcmp            d1, d0
    // 0xb10f40: b.vs            #0xb10f48
    // 0xb10f44: b.gt            #0xb10f70
    // 0xb10f48: fcmp            d1, d0
    // 0xb10f4c: b.vs            #0xb10f5c
    // 0xb10f50: b.ge            #0xb10f5c
    // 0xb10f54: d1 = 10.000000
    //     0xb10f54: fmov            d1, #10.00000000
    // 0xb10f58: b               #0xb10f70
    // 0xb10f5c: fcmp            d1, d2
    // 0xb10f60: b.vs            #0xb10f70
    // 0xb10f64: b.ne            #0xb10f70
    // 0xb10f68: fadd            d2, d1, d0
    // 0xb10f6c: mov             v1.16b, v2.16b
    // 0xb10f70: mov             v2.16b, v1.16b
    // 0xb10f74: ldr             x0, [fp, #0x28]
    // 0xb10f78: ldr             x1, [fp, #0x20]
    // 0xb10f7c: d1 = 20.000000
    //     0xb10f7c: fmov            d1, #20.00000000
    // 0xb10f80: stur            d2, [fp, #-0x10]
    // 0xb10f84: LoadField: d3 = r1->field_7
    //     0xb10f84: ldur            d3, [x1, #7]
    // 0xb10f88: fsub            d4, d3, d1
    // 0xb10f8c: LoadField: d1 = r0->field_7
    //     0xb10f8c: ldur            d1, [x0, #7]
    // 0xb10f90: fcmp            d4, d1
    // 0xb10f94: b.vs            #0xb10fb0
    // 0xb10f98: b.ge            #0xb10fb0
    // 0xb10f9c: d4 = 2.000000
    //     0xb10f9c: fmov            d4, #2.00000000
    // 0xb10fa0: fsub            d0, d3, d1
    // 0xb10fa4: fdiv            d1, d0, d4
    // 0xb10fa8: mov             v0.16b, v1.16b
    // 0xb10fac: b               #0xb1102c
    // 0xb10fb0: ldr             x0, [fp, #0x18]
    // 0xb10fb4: d4 = 2.000000
    //     0xb10fb4: fmov            d4, #2.00000000
    // 0xb10fb8: LoadField: d5 = r0->field_7
    //     0xb10fb8: ldur            d5, [x0, #7]
    // 0xb10fbc: fsub            d6, d3, d0
    // 0xb10fc0: fcmp            d5, d0
    // 0xb10fc4: b.vs            #0xb10fd4
    // 0xb10fc8: b.ge            #0xb10fd4
    // 0xb10fcc: d5 = 10.000000
    //     0xb10fcc: fmov            d5, #10.00000000
    // 0xb10fd0: b               #0xb10ff4
    // 0xb10fd4: fcmp            d5, d6
    // 0xb10fd8: b.vs            #0xb10fe8
    // 0xb10fdc: b.le            #0xb10fe8
    // 0xb10fe0: mov             v5.16b, v6.16b
    // 0xb10fe4: b               #0xb10ff4
    // 0xb10fe8: fcmp            d5, d5
    // 0xb10fec: b.vc            #0xb10ff4
    // 0xb10ff0: mov             v5.16b, v6.16b
    // 0xb10ff4: fdiv            d7, d1, d4
    // 0xb10ff8: fadd            d4, d0, d7
    // 0xb10ffc: fcmp            d5, d4
    // 0xb11000: b.vs            #0xb11010
    // 0xb11004: b.ge            #0xb11010
    // 0xb11008: d0 = 10.000000
    //     0xb11008: fmov            d0, #10.00000000
    // 0xb1100c: b               #0xb1102c
    // 0xb11010: fsub            d0, d3, d4
    // 0xb11014: fcmp            d5, d0
    // 0xb11018: b.vs            #0xb11028
    // 0xb1101c: b.le            #0xb11028
    // 0xb11020: fsub            d0, d6, d1
    // 0xb11024: b               #0xb1102c
    // 0xb11028: fsub            d0, d5, d7
    // 0xb1102c: stur            d0, [fp, #-8]
    // 0xb11030: r0 = Offset()
    //     0xb11030: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb11034: ldur            d0, [fp, #-8]
    // 0xb11038: StoreField: r0->field_7 = d0
    //     0xb11038: stur            d0, [x0, #7]
    // 0xb1103c: ldur            d0, [fp, #-0x10]
    // 0xb11040: StoreField: r0->field_f = d0
    //     0xb11040: stur            d0, [x0, #0xf]
    // 0xb11044: LeaveFrame
    //     0xb11044: mov             SP, fp
    //     0xb11048: ldp             fp, lr, [SP], #0x10
    // 0xb1104c: ret
    //     0xb1104c: ret             
    // 0xb11050: r0 = StackOverflowSharedWithFPURegs()
    //     0xb11050: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xb11054: b               #0xb10e18
    // 0xb11058: stp             q3, q7, [SP, #-0x20]!
    // 0xb1105c: SaveReg d0
    //     0xb1105c: str             q0, [SP, #-0x10]!
    // 0xb11060: stp             x1, x2, [SP, #-0x10]!
    // 0xb11064: SaveReg r0
    //     0xb11064: str             x0, [SP, #-8]!
    // 0xb11068: r0 = AllocateDouble()
    //     0xb11068: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb1106c: mov             x3, x0
    // 0xb11070: RestoreReg r0
    //     0xb11070: ldr             x0, [SP], #8
    // 0xb11074: ldp             x1, x2, [SP], #0x10
    // 0xb11078: RestoreReg d0
    //     0xb11078: ldr             q0, [SP], #0x10
    // 0xb1107c: ldp             q3, q7, [SP], #0x20
    // 0xb11080: b               #0xb10f00
  }
}

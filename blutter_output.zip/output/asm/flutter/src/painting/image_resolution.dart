// lib: , url: package:flutter/src/painting/image_resolution.dart

// class id: 1049369, size: 0x8
class :: {
}

// class id: 4465, size: 0x18, field offset: 0xc
//   const constructor, 
class AssetImage extends AssetBundleImageProvider {

  static late final RegExp _extractRatioRegExp; // offset: 0xe80

  _ toString(/* No info */) {
    // ** addr: 0xad3c9c, size: 0x8c
    // 0xad3c9c: EnterFrame
    //     0xad3c9c: stp             fp, lr, [SP, #-0x10]!
    //     0xad3ca0: mov             fp, SP
    // 0xad3ca4: CheckStackOverflow
    //     0xad3ca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3ca8: cmp             SP, x16
    //     0xad3cac: b.ls            #0xad3d20
    // 0xad3cb0: r1 = Null
    //     0xad3cb0: mov             x1, NULL
    // 0xad3cb4: r2 = 12
    //     0xad3cb4: mov             x2, #0xc
    // 0xad3cb8: r0 = AllocateArray()
    //     0xad3cb8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad3cbc: r17 = "AssetImage"
    //     0xad3cbc: add             x17, PP, #0x21, lsl #12  ; [pp+0x21ca0] "AssetImage"
    //     0xad3cc0: ldr             x17, [x17, #0xca0]
    // 0xad3cc4: StoreField: r0->field_f = r17
    //     0xad3cc4: stur            w17, [x0, #0xf]
    // 0xad3cc8: r17 = "(bundle: "
    //     0xad3cc8: add             x17, PP, #0x21, lsl #12  ; [pp+0x21ca8] "(bundle: "
    //     0xad3ccc: ldr             x17, [x17, #0xca8]
    // 0xad3cd0: StoreField: r0->field_13 = r17
    //     0xad3cd0: stur            w17, [x0, #0x13]
    // 0xad3cd4: ldr             x1, [fp, #0x10]
    // 0xad3cd8: LoadField: r2 = r1->field_f
    //     0xad3cd8: ldur            w2, [x1, #0xf]
    // 0xad3cdc: DecompressPointer r2
    //     0xad3cdc: add             x2, x2, HEAP, lsl #32
    // 0xad3ce0: StoreField: r0->field_17 = r2
    //     0xad3ce0: stur            w2, [x0, #0x17]
    // 0xad3ce4: r17 = ", name: \""
    //     0xad3ce4: add             x17, PP, #0x21, lsl #12  ; [pp+0x21cb0] ", name: \""
    //     0xad3ce8: ldr             x17, [x17, #0xcb0]
    // 0xad3cec: StoreField: r0->field_1b = r17
    //     0xad3cec: stur            w17, [x0, #0x1b]
    // 0xad3cf0: LoadField: r2 = r1->field_b
    //     0xad3cf0: ldur            w2, [x1, #0xb]
    // 0xad3cf4: DecompressPointer r2
    //     0xad3cf4: add             x2, x2, HEAP, lsl #32
    // 0xad3cf8: StoreField: r0->field_1f = r2
    //     0xad3cf8: stur            w2, [x0, #0x1f]
    // 0xad3cfc: r17 = "\")"
    //     0xad3cfc: add             x17, PP, #9, lsl #12  ; [pp+0x91a0] "\")"
    //     0xad3d00: ldr             x17, [x17, #0x1a0]
    // 0xad3d04: StoreField: r0->field_23 = r17
    //     0xad3d04: stur            w17, [x0, #0x23]
    // 0xad3d08: SaveReg r0
    //     0xad3d08: str             x0, [SP, #-8]!
    // 0xad3d0c: r0 = _interpolate()
    //     0xad3d0c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3d10: add             SP, SP, #8
    // 0xad3d14: LeaveFrame
    //     0xad3d14: mov             SP, fp
    //     0xad3d18: ldp             fp, lr, [SP], #0x10
    // 0xad3d1c: ret
    //     0xad3d1c: ret             
    // 0xad3d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3d20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3d24: b               #0xad3cb0
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0xc4b7a8, size: 0x1e4
    // 0xc4b7a8: EnterFrame
    //     0xc4b7a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc4b7ac: mov             fp, SP
    // 0xc4b7b0: AllocStack(0x10)
    //     0xc4b7b0: sub             SP, SP, #0x10
    // 0xc4b7b4: CheckStackOverflow
    //     0xc4b7b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4b7b8: cmp             SP, x16
    //     0xc4b7bc: b.ls            #0xc4b984
    // 0xc4b7c0: r1 = 5
    //     0xc4b7c0: mov             x1, #5
    // 0xc4b7c4: r0 = AllocateContext()
    //     0xc4b7c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc4b7c8: mov             x1, x0
    // 0xc4b7cc: ldr             x0, [fp, #0x18]
    // 0xc4b7d0: stur            x1, [fp, #-8]
    // 0xc4b7d4: StoreField: r1->field_f = r0
    //     0xc4b7d4: stur            w0, [x1, #0xf]
    // 0xc4b7d8: ldr             x0, [fp, #0x10]
    // 0xc4b7dc: StoreField: r1->field_13 = r0
    //     0xc4b7dc: stur            w0, [x1, #0x13]
    // 0xc4b7e0: LoadField: r2 = r0->field_7
    //     0xc4b7e0: ldur            w2, [x0, #7]
    // 0xc4b7e4: DecompressPointer r2
    //     0xc4b7e4: add             x2, x2, HEAP, lsl #32
    // 0xc4b7e8: cmp             w2, NULL
    // 0xc4b7ec: b.ne            #0xc4b810
    // 0xc4b7f0: r0 = InitLateStaticField(0xf44) // [package:flutter/src/services/asset_bundle.dart] ::rootBundle
    //     0xc4b7f0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc4b7f4: ldr             x0, [x0, #0x1e88]
    //     0xc4b7f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc4b7fc: cmp             w0, w16
    //     0xc4b800: b.ne            #0xc4b80c
    //     0xc4b804: ldr             x2, [PP, #0x4fb8]  ; [pp+0x4fb8] Field <::.rootBundle>: static late final (offset: 0xf44)
    //     0xc4b808: bl              #0xd67cdc
    // 0xc4b80c: b               #0xc4b814
    // 0xc4b810: mov             x0, x2
    // 0xc4b814: ldur            x2, [fp, #-8]
    // 0xc4b818: StoreField: r2->field_17 = r0
    //     0xc4b818: stur            w0, [x2, #0x17]
    // 0xc4b81c: StoreField: r2->field_1b = rNULL
    //     0xc4b81c: stur            NULL, [x2, #0x1b]
    // 0xc4b820: StoreField: r2->field_1f = rNULL
    //     0xc4b820: stur            NULL, [x2, #0x1f]
    // 0xc4b824: r16 = <Map<String, List<String>>?>
    //     0xc4b824: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d7c8] TypeArguments: <Map<String, List<String>>?>
    //     0xc4b828: ldr             x16, [x16, #0x7c8]
    // 0xc4b82c: stp             x0, x16, [SP, #-0x10]!
    // 0xc4b830: r16 = "AssetManifest.json"
    //     0xc4b830: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d7d0] "AssetManifest.json"
    //     0xc4b834: ldr             x16, [x16, #0x7d0]
    // 0xc4b838: r30 = Closure: (String?) => Future<Map<String, List<String>>?> from Function 'manifestParser': static.
    //     0xc4b838: add             lr, PP, #0x2d, lsl #12  ; [pp+0x2d7d8] Closure: (String?) => Future<Map<String, List<String>>?> from Function 'manifestParser': static. (0x7fe6e244c938)
    //     0xc4b83c: ldr             lr, [lr, #0x7d8]
    // 0xc4b840: stp             lr, x16, [SP, #-0x10]!
    // 0xc4b844: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc4b844: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc4b848: r0 = loadStructuredData()
    //     0xc4b848: bl              #0xc4b98c  ; [package:flutter/src/services/asset_bundle.dart] CachingAssetBundle::loadStructuredData
    // 0xc4b84c: add             SP, SP, #0x20
    // 0xc4b850: ldur            x2, [fp, #-8]
    // 0xc4b854: r1 = Function '<anonymous closure>':.
    //     0xc4b854: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d7e0] AnonymousClosure: (0xc4bf64), in [package:flutter/src/painting/image_resolution.dart] AssetImage::obtainKey (0xc4b7a8)
    //     0xc4b858: ldr             x1, [x1, #0x7e0]
    // 0xc4b85c: stur            x0, [fp, #-0x10]
    // 0xc4b860: r0 = AllocateClosure()
    //     0xc4b860: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc4b864: mov             x1, x0
    // 0xc4b868: ldur            x0, [fp, #-0x10]
    // 0xc4b86c: r2 = LoadClassIdInstr(r0)
    //     0xc4b86c: ldur            x2, [x0, #-1]
    //     0xc4b870: ubfx            x2, x2, #0xc, #0x14
    // 0xc4b874: r16 = <void?>
    //     0xc4b874: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc4b878: stp             x0, x16, [SP, #-0x10]!
    // 0xc4b87c: SaveReg r1
    //     0xc4b87c: str             x1, [SP, #-8]!
    // 0xc4b880: mov             x0, x2
    // 0xc4b884: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc4b884: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc4b888: r0 = GDT[cid_x0 + -0xffe]()
    //     0xc4b888: sub             lr, x0, #0xffe
    //     0xc4b88c: ldr             lr, [x21, lr, lsl #3]
    //     0xc4b890: blr             lr
    // 0xc4b894: add             SP, SP, #0x18
    // 0xc4b898: ldur            x2, [fp, #-8]
    // 0xc4b89c: r1 = Function '<anonymous closure>':.
    //     0xc4b89c: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d7e8] AnonymousClosure: (0xc4befc), in [package:flutter/src/painting/image_resolution.dart] AssetImage::obtainKey (0xc4b7a8)
    //     0xc4b8a0: ldr             x1, [x1, #0x7e8]
    // 0xc4b8a4: stur            x0, [fp, #-0x10]
    // 0xc4b8a8: r0 = AllocateClosure()
    //     0xc4b8a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc4b8ac: mov             x1, x0
    // 0xc4b8b0: ldur            x0, [fp, #-0x10]
    // 0xc4b8b4: r2 = LoadClassIdInstr(r0)
    //     0xc4b8b4: ldur            x2, [x0, #-1]
    //     0xc4b8b8: ubfx            x2, x2, #0xc, #0x14
    // 0xc4b8bc: stp             x1, x0, [SP, #-0x10]!
    // 0xc4b8c0: mov             x0, x2
    // 0xc4b8c4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc4b8c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc4b8c8: r0 = GDT[cid_x0 + -0xffb]()
    //     0xc4b8c8: sub             lr, x0, #0xffb
    //     0xc4b8cc: ldr             lr, [x21, lr, lsl #3]
    //     0xc4b8d0: blr             lr
    // 0xc4b8d4: add             SP, SP, #0x10
    // 0xc4b8d8: ldur            x0, [fp, #-8]
    // 0xc4b8dc: LoadField: r1 = r0->field_1f
    //     0xc4b8dc: ldur            w1, [x0, #0x1f]
    // 0xc4b8e0: DecompressPointer r1
    //     0xc4b8e0: add             x1, x1, HEAP, lsl #32
    // 0xc4b8e4: cmp             w1, NULL
    // 0xc4b8e8: b.eq            #0xc4b8fc
    // 0xc4b8ec: mov             x0, x1
    // 0xc4b8f0: LeaveFrame
    //     0xc4b8f0: mov             SP, fp
    //     0xc4b8f4: ldp             fp, lr, [SP], #0x10
    // 0xc4b8f8: ret
    //     0xc4b8f8: ret             
    // 0xc4b8fc: r1 = <AssetBundleImageKey>
    //     0xc4b8fc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c528] TypeArguments: <AssetBundleImageKey>
    //     0xc4b900: ldr             x1, [x1, #0x528]
    // 0xc4b904: r0 = _Future()
    //     0xc4b904: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xc4b908: mov             x1, x0
    // 0xc4b90c: r0 = 0
    //     0xc4b90c: mov             x0, #0
    // 0xc4b910: stur            x1, [fp, #-0x10]
    // 0xc4b914: StoreField: r1->field_b = r0
    //     0xc4b914: stur            x0, [x1, #0xb]
    // 0xc4b918: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc4b918: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc4b91c: ldr             x0, [x0, #0xb58]
    //     0xc4b920: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc4b924: cmp             w0, w16
    //     0xc4b928: b.ne            #0xc4b934
    //     0xc4b92c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc4b930: bl              #0xd67d44
    // 0xc4b934: mov             x1, x0
    // 0xc4b938: ldur            x0, [fp, #-0x10]
    // 0xc4b93c: StoreField: r0->field_13 = r1
    //     0xc4b93c: stur            w1, [x0, #0x13]
    // 0xc4b940: r1 = <AssetBundleImageKey>
    //     0xc4b940: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c528] TypeArguments: <AssetBundleImageKey>
    //     0xc4b944: ldr             x1, [x1, #0x528]
    // 0xc4b948: r0 = _AsyncCompleter()
    //     0xc4b948: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xc4b94c: ldur            x1, [fp, #-0x10]
    // 0xc4b950: StoreField: r0->field_b = r1
    //     0xc4b950: stur            w1, [x0, #0xb]
    // 0xc4b954: ldur            x2, [fp, #-8]
    // 0xc4b958: StoreField: r2->field_1b = r0
    //     0xc4b958: stur            w0, [x2, #0x1b]
    //     0xc4b95c: ldurb           w16, [x2, #-1]
    //     0xc4b960: ldurb           w17, [x0, #-1]
    //     0xc4b964: and             x16, x17, x16, lsr #2
    //     0xc4b968: tst             x16, HEAP, lsr #32
    //     0xc4b96c: b.eq            #0xc4b974
    //     0xc4b970: bl              #0xd6828c
    // 0xc4b974: mov             x0, x1
    // 0xc4b978: LeaveFrame
    //     0xc4b978: mov             SP, fp
    //     0xc4b97c: ldp             fp, lr, [SP], #0x10
    // 0xc4b980: ret
    //     0xc4b980: ret             
    // 0xc4b984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4b984: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4b988: b               #0xc4b7c0
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xc4befc, size: 0x68
    // 0xc4befc: EnterFrame
    //     0xc4befc: stp             fp, lr, [SP, #-0x10]!
    //     0xc4bf00: mov             fp, SP
    // 0xc4bf04: ldr             x0, [fp, #0x20]
    // 0xc4bf08: LoadField: r1 = r0->field_17
    //     0xc4bf08: ldur            w1, [x0, #0x17]
    // 0xc4bf0c: DecompressPointer r1
    //     0xc4bf0c: add             x1, x1, HEAP, lsl #32
    // 0xc4bf10: CheckStackOverflow
    //     0xc4bf10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4bf14: cmp             SP, x16
    //     0xc4bf18: b.ls            #0xc4bf58
    // 0xc4bf1c: LoadField: r0 = r1->field_1b
    //     0xc4bf1c: ldur            w0, [x1, #0x1b]
    // 0xc4bf20: DecompressPointer r0
    //     0xc4bf20: add             x0, x0, HEAP, lsl #32
    // 0xc4bf24: cmp             w0, NULL
    // 0xc4bf28: b.eq            #0xc4bf60
    // 0xc4bf2c: ldr             x16, [fp, #0x18]
    // 0xc4bf30: stp             x16, x0, [SP, #-0x10]!
    // 0xc4bf34: ldr             x16, [fp, #0x10]
    // 0xc4bf38: SaveReg r16
    //     0xc4bf38: str             x16, [SP, #-8]!
    // 0xc4bf3c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xc4bf3c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xc4bf40: r0 = completeError()
    //     0xc4bf40: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0xc4bf44: add             SP, SP, #0x18
    // 0xc4bf48: r0 = Null
    //     0xc4bf48: mov             x0, NULL
    // 0xc4bf4c: LeaveFrame
    //     0xc4bf4c: mov             SP, fp
    //     0xc4bf50: ldp             fp, lr, [SP], #0x10
    // 0xc4bf54: ret
    //     0xc4bf54: ret             
    // 0xc4bf58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4bf58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4bf5c: b               #0xc4bf1c
    // 0xc4bf60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc4bf60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, Map<String, List<String>>?) {
    // ** addr: 0xc4bf64, size: 0x17c
    // 0xc4bf64: EnterFrame
    //     0xc4bf64: stp             fp, lr, [SP, #-0x10]!
    //     0xc4bf68: mov             fp, SP
    // 0xc4bf6c: AllocStack(0x28)
    //     0xc4bf6c: sub             SP, SP, #0x28
    // 0xc4bf70: SetupParameters()
    //     0xc4bf70: ldr             x0, [fp, #0x18]
    //     0xc4bf74: ldur            w1, [x0, #0x17]
    //     0xc4bf78: add             x1, x1, HEAP, lsl #32
    //     0xc4bf7c: stur            x1, [fp, #-0x20]
    // 0xc4bf80: CheckStackOverflow
    //     0xc4bf80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4bf84: cmp             SP, x16
    //     0xc4bf88: b.ls            #0xc4c0d4
    // 0xc4bf8c: LoadField: r2 = r1->field_f
    //     0xc4bf8c: ldur            w2, [x1, #0xf]
    // 0xc4bf90: DecompressPointer r2
    //     0xc4bf90: add             x2, x2, HEAP, lsl #32
    // 0xc4bf94: stur            x2, [fp, #-0x18]
    // 0xc4bf98: LoadField: r3 = r2->field_b
    //     0xc4bf98: ldur            w3, [x2, #0xb]
    // 0xc4bf9c: DecompressPointer r3
    //     0xc4bf9c: add             x3, x3, HEAP, lsl #32
    // 0xc4bfa0: stur            x3, [fp, #-0x10]
    // 0xc4bfa4: LoadField: r4 = r1->field_13
    //     0xc4bfa4: ldur            w4, [x1, #0x13]
    // 0xc4bfa8: DecompressPointer r4
    //     0xc4bfa8: add             x4, x4, HEAP, lsl #32
    // 0xc4bfac: ldr             x0, [fp, #0x10]
    // 0xc4bfb0: stur            x4, [fp, #-8]
    // 0xc4bfb4: cmp             w0, NULL
    // 0xc4bfb8: b.ne            #0xc4bfc8
    // 0xc4bfbc: mov             x0, x1
    // 0xc4bfc0: r1 = Null
    //     0xc4bfc0: mov             x1, NULL
    // 0xc4bfc4: b               #0xc4bff0
    // 0xc4bfc8: r5 = LoadClassIdInstr(r0)
    //     0xc4bfc8: ldur            x5, [x0, #-1]
    //     0xc4bfcc: ubfx            x5, x5, #0xc, #0x14
    // 0xc4bfd0: stp             x3, x0, [SP, #-0x10]!
    // 0xc4bfd4: mov             x0, x5
    // 0xc4bfd8: r0 = GDT[cid_x0 + -0xef]()
    //     0xc4bfd8: sub             lr, x0, #0xef
    //     0xc4bfdc: ldr             lr, [x21, lr, lsl #3]
    //     0xc4bfe0: blr             lr
    // 0xc4bfe4: add             SP, SP, #0x10
    // 0xc4bfe8: mov             x1, x0
    // 0xc4bfec: ldur            x0, [fp, #-0x20]
    // 0xc4bff0: ldur            x16, [fp, #-0x18]
    // 0xc4bff4: ldur            lr, [fp, #-0x10]
    // 0xc4bff8: stp             lr, x16, [SP, #-0x10]!
    // 0xc4bffc: ldur            x16, [fp, #-8]
    // 0xc4c000: stp             x1, x16, [SP, #-0x10]!
    // 0xc4c004: r0 = _chooseVariant()
    //     0xc4c004: bl              #0xc4c31c  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::_chooseVariant
    // 0xc4c008: add             SP, SP, #0x20
    // 0xc4c00c: stur            x0, [fp, #-8]
    // 0xc4c010: cmp             w0, NULL
    // 0xc4c014: b.eq            #0xc4c0dc
    // 0xc4c018: ldur            x1, [fp, #-0x20]
    // 0xc4c01c: LoadField: r2 = r1->field_f
    //     0xc4c01c: ldur            w2, [x1, #0xf]
    // 0xc4c020: DecompressPointer r2
    //     0xc4c020: add             x2, x2, HEAP, lsl #32
    // 0xc4c024: stp             x0, x2, [SP, #-0x10]!
    // 0xc4c028: r0 = _parseScale()
    //     0xc4c028: bl              #0xc4c0ec  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::_parseScale
    // 0xc4c02c: add             SP, SP, #0x10
    // 0xc4c030: ldur            x0, [fp, #-0x20]
    // 0xc4c034: stur            d0, [fp, #-0x28]
    // 0xc4c038: LoadField: r1 = r0->field_17
    //     0xc4c038: ldur            w1, [x0, #0x17]
    // 0xc4c03c: DecompressPointer r1
    //     0xc4c03c: add             x1, x1, HEAP, lsl #32
    // 0xc4c040: stur            x1, [fp, #-0x10]
    // 0xc4c044: r0 = AssetBundleImageKey()
    //     0xc4c044: bl              #0xc4c0e0  ; AllocateAssetBundleImageKeyStub -> AssetBundleImageKey (size=0x18)
    // 0xc4c048: mov             x2, x0
    // 0xc4c04c: ldur            x0, [fp, #-0x10]
    // 0xc4c050: stur            x2, [fp, #-0x18]
    // 0xc4c054: StoreField: r2->field_7 = r0
    //     0xc4c054: stur            w0, [x2, #7]
    // 0xc4c058: ldur            x0, [fp, #-8]
    // 0xc4c05c: StoreField: r2->field_b = r0
    //     0xc4c05c: stur            w0, [x2, #0xb]
    // 0xc4c060: ldur            d0, [fp, #-0x28]
    // 0xc4c064: StoreField: r2->field_f = d0
    //     0xc4c064: stur            d0, [x2, #0xf]
    // 0xc4c068: ldur            x0, [fp, #-0x20]
    // 0xc4c06c: LoadField: r1 = r0->field_1b
    //     0xc4c06c: ldur            w1, [x0, #0x1b]
    // 0xc4c070: DecompressPointer r1
    //     0xc4c070: add             x1, x1, HEAP, lsl #32
    // 0xc4c074: cmp             w1, NULL
    // 0xc4c078: b.eq            #0xc4c090
    // 0xc4c07c: stp             x2, x1, [SP, #-0x10]!
    // 0xc4c080: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc4c080: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc4c084: r0 = complete()
    //     0xc4c084: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0xc4c088: add             SP, SP, #0x10
    // 0xc4c08c: b               #0xc4c0c4
    // 0xc4c090: r1 = <AssetBundleImageKey>
    //     0xc4c090: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c528] TypeArguments: <AssetBundleImageKey>
    //     0xc4c094: ldr             x1, [x1, #0x528]
    // 0xc4c098: r0 = SynchronousFuture()
    //     0xc4c098: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xc4c09c: ldur            x1, [fp, #-0x18]
    // 0xc4c0a0: StoreField: r0->field_b = r1
    //     0xc4c0a0: stur            w1, [x0, #0xb]
    // 0xc4c0a4: ldur            x1, [fp, #-0x20]
    // 0xc4c0a8: StoreField: r1->field_1f = r0
    //     0xc4c0a8: stur            w0, [x1, #0x1f]
    //     0xc4c0ac: ldurb           w16, [x1, #-1]
    //     0xc4c0b0: ldurb           w17, [x0, #-1]
    //     0xc4c0b4: and             x16, x17, x16, lsr #2
    //     0xc4c0b8: tst             x16, HEAP, lsr #32
    //     0xc4c0bc: b.eq            #0xc4c0c4
    //     0xc4c0c0: bl              #0xd6826c
    // 0xc4c0c4: r0 = Null
    //     0xc4c0c4: mov             x0, NULL
    // 0xc4c0c8: LeaveFrame
    //     0xc4c0c8: mov             SP, fp
    //     0xc4c0cc: ldp             fp, lr, [SP], #0x10
    // 0xc4c0d0: ret
    //     0xc4c0d0: ret             
    // 0xc4c0d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4c0d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4c0d8: b               #0xc4bf8c
    // 0xc4c0dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc4c0dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _parseScale(/* No info */) {
    // ** addr: 0xc4c0ec, size: 0x1f0
    // 0xc4c0ec: EnterFrame
    //     0xc4c0ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc4c0f0: mov             fp, SP
    // 0xc4c0f4: AllocStack(0x10)
    //     0xc4c0f4: sub             SP, SP, #0x10
    // 0xc4c0f8: CheckStackOverflow
    //     0xc4c0f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4c0fc: cmp             SP, x16
    //     0xc4c100: b.ls            #0xc4c2cc
    // 0xc4c104: ldr             x0, [fp, #0x18]
    // 0xc4c108: LoadField: r1 = r0->field_b
    //     0xc4c108: ldur            w1, [x0, #0xb]
    // 0xc4c10c: DecompressPointer r1
    //     0xc4c10c: add             x1, x1, HEAP, lsl #32
    // 0xc4c110: ldr             x2, [fp, #0x10]
    // 0xc4c114: r0 = LoadClassIdInstr(r2)
    //     0xc4c114: ldur            x0, [x2, #-1]
    //     0xc4c118: ubfx            x0, x0, #0xc, #0x14
    // 0xc4c11c: stp             x1, x2, [SP, #-0x10]!
    // 0xc4c120: mov             lr, x0
    // 0xc4c124: ldr             lr, [x21, lr, lsl #3]
    // 0xc4c128: blr             lr
    // 0xc4c12c: add             SP, SP, #0x10
    // 0xc4c130: tbnz            w0, #4, #0xc4c144
    // 0xc4c134: d0 = 1.000000
    //     0xc4c134: fmov            d0, #1.00000000
    // 0xc4c138: LeaveFrame
    //     0xc4c138: mov             SP, fp
    //     0xc4c13c: ldp             fp, lr, [SP], #0x10
    // 0xc4c140: ret
    //     0xc4c140: ret             
    // 0xc4c144: ldr             x16, [fp, #0x10]
    // 0xc4c148: SaveReg r16
    //     0xc4c148: str             x16, [SP, #-8]!
    // 0xc4c14c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc4c14c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc4c150: r0 = parse()
    //     0xc4c150: bl              #0x4da468  ; [dart:core] Uri::parse
    // 0xc4c154: add             SP, SP, #8
    // 0xc4c158: mov             x1, x0
    // 0xc4c15c: stur            x1, [fp, #-8]
    // 0xc4c160: r0 = LoadClassIdInstr(r1)
    //     0xc4c160: ldur            x0, [x1, #-1]
    //     0xc4c164: ubfx            x0, x0, #0xc, #0x14
    // 0xc4c168: SaveReg r1
    //     0xc4c168: str             x1, [SP, #-8]!
    // 0xc4c16c: r0 = GDT[cid_x0 + -0xf54]()
    //     0xc4c16c: sub             lr, x0, #0xf54
    //     0xc4c170: ldr             lr, [x21, lr, lsl #3]
    //     0xc4c174: blr             lr
    // 0xc4c178: add             SP, SP, #8
    // 0xc4c17c: LoadField: r1 = r0->field_b
    //     0xc4c17c: ldur            w1, [x0, #0xb]
    // 0xc4c180: DecompressPointer r1
    //     0xc4c180: add             x1, x1, HEAP, lsl #32
    // 0xc4c184: r0 = LoadInt32Instr(r1)
    //     0xc4c184: sbfx            x0, x1, #1, #0x1f
    // 0xc4c188: cmp             x0, #1
    // 0xc4c18c: b.le            #0xc4c21c
    // 0xc4c190: ldur            x1, [fp, #-8]
    // 0xc4c194: r0 = LoadClassIdInstr(r1)
    //     0xc4c194: ldur            x0, [x1, #-1]
    //     0xc4c198: ubfx            x0, x0, #0xc, #0x14
    // 0xc4c19c: SaveReg r1
    //     0xc4c19c: str             x1, [SP, #-8]!
    // 0xc4c1a0: r0 = GDT[cid_x0 + -0xf54]()
    //     0xc4c1a0: sub             lr, x0, #0xf54
    //     0xc4c1a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc4c1a8: blr             lr
    // 0xc4c1ac: add             SP, SP, #8
    // 0xc4c1b0: mov             x1, x0
    // 0xc4c1b4: ldur            x0, [fp, #-8]
    // 0xc4c1b8: stur            x1, [fp, #-0x10]
    // 0xc4c1bc: r2 = LoadClassIdInstr(r0)
    //     0xc4c1bc: ldur            x2, [x0, #-1]
    //     0xc4c1c0: ubfx            x2, x2, #0xc, #0x14
    // 0xc4c1c4: SaveReg r0
    //     0xc4c1c4: str             x0, [SP, #-8]!
    // 0xc4c1c8: mov             x0, x2
    // 0xc4c1cc: r0 = GDT[cid_x0 + -0xf54]()
    //     0xc4c1cc: sub             lr, x0, #0xf54
    //     0xc4c1d0: ldr             lr, [x21, lr, lsl #3]
    //     0xc4c1d4: blr             lr
    // 0xc4c1d8: add             SP, SP, #8
    // 0xc4c1dc: LoadField: r1 = r0->field_b
    //     0xc4c1dc: ldur            w1, [x0, #0xb]
    // 0xc4c1e0: DecompressPointer r1
    //     0xc4c1e0: add             x1, x1, HEAP, lsl #32
    // 0xc4c1e4: r0 = LoadInt32Instr(r1)
    //     0xc4c1e4: sbfx            x0, x1, #1, #0x1f
    // 0xc4c1e8: sub             x2, x0, #2
    // 0xc4c1ec: ldur            x3, [fp, #-0x10]
    // 0xc4c1f0: LoadField: r0 = r3->field_b
    //     0xc4c1f0: ldur            w0, [x3, #0xb]
    // 0xc4c1f4: DecompressPointer r0
    //     0xc4c1f4: add             x0, x0, HEAP, lsl #32
    // 0xc4c1f8: r1 = LoadInt32Instr(r0)
    //     0xc4c1f8: sbfx            x1, x0, #1, #0x1f
    // 0xc4c1fc: mov             x0, x1
    // 0xc4c200: mov             x1, x2
    // 0xc4c204: cmp             x1, x0
    // 0xc4c208: b.hs            #0xc4c2d4
    // 0xc4c20c: ArrayLoad: r0 = r3[r2]  ; Unknown_4
    //     0xc4c20c: add             x16, x3, x2, lsl #2
    //     0xc4c210: ldur            w0, [x16, #0xf]
    // 0xc4c214: DecompressPointer r0
    //     0xc4c214: add             x0, x0, HEAP, lsl #32
    // 0xc4c218: b               #0xc4c220
    // 0xc4c21c: r0 = ""
    //     0xc4c21c: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xc4c220: stur            x0, [fp, #-8]
    // 0xc4c224: r0 = InitLateStaticField(0xe80) // [package:flutter/src/painting/image_resolution.dart] AssetImage::_extractRatioRegExp
    //     0xc4c224: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc4c228: ldr             x0, [x0, #0x1d00]
    //     0xc4c22c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc4c230: cmp             w0, w16
    //     0xc4c234: b.ne            #0xc4c244
    //     0xc4c238: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2d7f0] Field <AssetImage._extractRatioRegExp@865097849>: static late final (offset: 0xe80)
    //     0xc4c23c: ldr             x2, [x2, #0x7f0]
    //     0xc4c240: bl              #0xd67cdc
    // 0xc4c244: ldur            x16, [fp, #-8]
    // 0xc4c248: stp             x16, x0, [SP, #-0x10]!
    // 0xc4c24c: r0 = firstMatch()
    //     0xc4c24c: bl              #0x4fef70  ; [dart:core] _RegExp::firstMatch
    // 0xc4c250: add             SP, SP, #0x10
    // 0xc4c254: stur            x0, [fp, #-8]
    // 0xc4c258: cmp             w0, NULL
    // 0xc4c25c: b.eq            #0xc4c2bc
    // 0xc4c260: LoadField: r1 = r0->field_7
    //     0xc4c260: ldur            w1, [x0, #7]
    // 0xc4c264: DecompressPointer r1
    //     0xc4c264: add             x1, x1, HEAP, lsl #32
    // 0xc4c268: SaveReg r1
    //     0xc4c268: str             x1, [SP, #-8]!
    // 0xc4c26c: r0 = _groupCount()
    //     0xc4c26c: bl              #0xb31cc8  ; [dart:core] _RegExp::_groupCount
    // 0xc4c270: add             SP, SP, #8
    // 0xc4c274: r1 = LoadInt32Instr(r0)
    //     0xc4c274: sbfx            x1, x0, #1, #0x1f
    //     0xc4c278: tbz             w0, #0, #0xc4c280
    //     0xc4c27c: ldur            x1, [x0, #7]
    // 0xc4c280: cmp             x1, #0
    // 0xc4c284: b.le            #0xc4c2bc
    // 0xc4c288: r0 = 1
    //     0xc4c288: mov             x0, #1
    // 0xc4c28c: ldur            x16, [fp, #-8]
    // 0xc4c290: stp             x0, x16, [SP, #-0x10]!
    // 0xc4c294: r0 = group()
    //     0xc4c294: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0xc4c298: add             SP, SP, #0x10
    // 0xc4c29c: cmp             w0, NULL
    // 0xc4c2a0: b.eq            #0xc4c2d8
    // 0xc4c2a4: SaveReg r0
    //     0xc4c2a4: str             x0, [SP, #-8]!
    // 0xc4c2a8: r0 = parse()
    //     0xc4c2a8: bl              #0x4efe14  ; [dart:core] double::parse
    // 0xc4c2ac: add             SP, SP, #8
    // 0xc4c2b0: LeaveFrame
    //     0xc4c2b0: mov             SP, fp
    //     0xc4c2b4: ldp             fp, lr, [SP], #0x10
    // 0xc4c2b8: ret
    //     0xc4c2b8: ret             
    // 0xc4c2bc: d0 = 1.000000
    //     0xc4c2bc: fmov            d0, #1.00000000
    // 0xc4c2c0: LeaveFrame
    //     0xc4c2c0: mov             SP, fp
    //     0xc4c2c4: ldp             fp, lr, [SP], #0x10
    // 0xc4c2c8: ret
    //     0xc4c2c8: ret             
    // 0xc4c2cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4c2cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4c2d0: b               #0xc4c104
    // 0xc4c2d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc4c2d4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc4c2d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc4c2d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static RegExp _extractRatioRegExp() {
    // ** addr: 0xc4c2dc, size: 0x40
    // 0xc4c2dc: EnterFrame
    //     0xc4c2dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc4c2e0: mov             fp, SP
    // 0xc4c2e4: CheckStackOverflow
    //     0xc4c2e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4c2e8: cmp             SP, x16
    //     0xc4c2ec: b.ls            #0xc4c314
    // 0xc4c2f0: r16 = "/\?(\\d+(\\.\\d*)\?)x$"
    //     0xc4c2f0: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d7f8] "/\?(\\d+(\\.\\d*)\?)x$"
    //     0xc4c2f4: ldr             x16, [x16, #0x7f8]
    // 0xc4c2f8: stp             x16, NULL, [SP, #-0x10]!
    // 0xc4c2fc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc4c2fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc4c300: r0 = RegExp()
    //     0xc4c300: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0xc4c304: add             SP, SP, #0x10
    // 0xc4c308: LeaveFrame
    //     0xc4c308: mov             SP, fp
    //     0xc4c30c: ldp             fp, lr, [SP], #0x10
    // 0xc4c310: ret
    //     0xc4c310: ret             
    // 0xc4c314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4c314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4c318: b               #0xc4c2f0
  }
  _ _chooseVariant(/* No info */) {
    // ** addr: 0xc4c31c, size: 0x1b4
    // 0xc4c31c: EnterFrame
    //     0xc4c31c: stp             fp, lr, [SP, #-0x10]!
    //     0xc4c320: mov             fp, SP
    // 0xc4c324: AllocStack(0x20)
    //     0xc4c324: sub             SP, SP, #0x20
    // 0xc4c328: CheckStackOverflow
    //     0xc4c328: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4c32c: cmp             SP, x16
    //     0xc4c330: b.ls            #0xc4c4b0
    // 0xc4c334: ldr             x0, [fp, #0x18]
    // 0xc4c338: LoadField: r1 = r0->field_b
    //     0xc4c338: ldur            w1, [x0, #0xb]
    // 0xc4c33c: DecompressPointer r1
    //     0xc4c33c: add             x1, x1, HEAP, lsl #32
    // 0xc4c340: stur            x1, [fp, #-8]
    // 0xc4c344: cmp             w1, NULL
    // 0xc4c348: b.eq            #0xc4c37c
    // 0xc4c34c: ldr             x2, [fp, #0x10]
    // 0xc4c350: cmp             w2, NULL
    // 0xc4c354: b.eq            #0xc4c37c
    // 0xc4c358: r0 = LoadClassIdInstr(r2)
    //     0xc4c358: ldur            x0, [x2, #-1]
    //     0xc4c35c: ubfx            x0, x0, #0xc, #0x14
    // 0xc4c360: SaveReg r2
    //     0xc4c360: str             x2, [SP, #-8]!
    // 0xc4c364: r0 = GDT[cid_x0 + 0xccd1]()
    //     0xc4c364: mov             x17, #0xccd1
    //     0xc4c368: add             lr, x0, x17
    //     0xc4c36c: ldr             lr, [x21, lr, lsl #3]
    //     0xc4c370: blr             lr
    // 0xc4c374: add             SP, SP, #8
    // 0xc4c378: tbnz            w0, #4, #0xc4c38c
    // 0xc4c37c: ldr             x0, [fp, #0x20]
    // 0xc4c380: LeaveFrame
    //     0xc4c380: mov             SP, fp
    //     0xc4c384: ldp             fp, lr, [SP], #0x10
    // 0xc4c388: ret
    //     0xc4c388: ret             
    // 0xc4c38c: ldr             x0, [fp, #0x10]
    // 0xc4c390: r1 = <double, _SplayTreeMapNode, double, String>
    //     0xc4c390: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d800] TypeArguments: <double, _SplayTreeMapNode, double, String>
    //     0xc4c394: ldr             x1, [x1, #0x800]
    // 0xc4c398: r0 = SplayTreeMap()
    //     0xc4c398: bl              #0x6b055c  ; AllocateSplayTreeMapStub -> SplayTreeMap<C2X0, _SplayTreeMapNode> (size=0x30)
    // 0xc4c39c: stur            x0, [fp, #-0x10]
    // 0xc4c3a0: SaveReg r0
    //     0xc4c3a0: str             x0, [SP, #-8]!
    // 0xc4c3a4: r0 = SplayTreeMap()
    //     0xc4c3a4: bl              #0x6b0354  ; [dart:collection] SplayTreeMap::SplayTreeMap
    // 0xc4c3a8: add             SP, SP, #8
    // 0xc4c3ac: ldr             x0, [fp, #0x10]
    // 0xc4c3b0: r1 = LoadClassIdInstr(r0)
    //     0xc4c3b0: ldur            x1, [x0, #-1]
    //     0xc4c3b4: ubfx            x1, x1, #0xc, #0x14
    // 0xc4c3b8: SaveReg r0
    //     0xc4c3b8: str             x0, [SP, #-8]!
    // 0xc4c3bc: mov             x0, x1
    // 0xc4c3c0: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc4c3c0: mov             x17, #0xb940
    //     0xc4c3c4: add             lr, x0, x17
    //     0xc4c3c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc4c3cc: blr             lr
    // 0xc4c3d0: add             SP, SP, #8
    // 0xc4c3d4: mov             x1, x0
    // 0xc4c3d8: stur            x1, [fp, #-0x18]
    // 0xc4c3dc: CheckStackOverflow
    //     0xc4c3dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4c3e0: cmp             SP, x16
    //     0xc4c3e4: b.ls            #0xc4c4b8
    // 0xc4c3e8: r0 = LoadClassIdInstr(r1)
    //     0xc4c3e8: ldur            x0, [x1, #-1]
    //     0xc4c3ec: ubfx            x0, x0, #0xc, #0x14
    // 0xc4c3f0: SaveReg r1
    //     0xc4c3f0: str             x1, [SP, #-8]!
    // 0xc4c3f4: r0 = GDT[cid_x0 + 0x541]()
    //     0xc4c3f4: add             lr, x0, #0x541
    //     0xc4c3f8: ldr             lr, [x21, lr, lsl #3]
    //     0xc4c3fc: blr             lr
    // 0xc4c400: add             SP, SP, #8
    // 0xc4c404: tbnz            w0, #4, #0xc4c484
    // 0xc4c408: ldur            x1, [fp, #-0x18]
    // 0xc4c40c: r0 = LoadClassIdInstr(r1)
    //     0xc4c40c: ldur            x0, [x1, #-1]
    //     0xc4c410: ubfx            x0, x0, #0xc, #0x14
    // 0xc4c414: SaveReg r1
    //     0xc4c414: str             x1, [SP, #-8]!
    // 0xc4c418: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc4c418: add             lr, x0, #0x5ca
    //     0xc4c41c: ldr             lr, [x21, lr, lsl #3]
    //     0xc4c420: blr             lr
    // 0xc4c424: add             SP, SP, #8
    // 0xc4c428: stur            x0, [fp, #-0x20]
    // 0xc4c42c: ldr             x16, [fp, #0x28]
    // 0xc4c430: stp             x0, x16, [SP, #-0x10]!
    // 0xc4c434: r0 = _parseScale()
    //     0xc4c434: bl              #0xc4c0ec  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::_parseScale
    // 0xc4c438: add             SP, SP, #0x10
    // 0xc4c43c: r0 = inline_Allocate_Double()
    //     0xc4c43c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc4c440: add             x0, x0, #0x10
    //     0xc4c444: cmp             x1, x0
    //     0xc4c448: b.ls            #0xc4c4c0
    //     0xc4c44c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc4c450: sub             x0, x0, #0xf
    //     0xc4c454: mov             x1, #0xd108
    //     0xc4c458: movk            x1, #3, lsl #16
    //     0xc4c45c: stur            x1, [x0, #-1]
    // 0xc4c460: StoreField: r0->field_7 = d0
    //     0xc4c460: stur            d0, [x0, #7]
    // 0xc4c464: ldur            x16, [fp, #-0x10]
    // 0xc4c468: stp             x0, x16, [SP, #-0x10]!
    // 0xc4c46c: ldur            x16, [fp, #-0x20]
    // 0xc4c470: SaveReg r16
    //     0xc4c470: str             x16, [SP, #-8]!
    // 0xc4c474: r0 = []=()
    //     0xc4c474: bl              #0xc589e4  ; [dart:collection] SplayTreeMap::[]=
    // 0xc4c478: add             SP, SP, #0x18
    // 0xc4c47c: ldur            x1, [fp, #-0x18]
    // 0xc4c480: b               #0xc4c3dc
    // 0xc4c484: ldur            x0, [fp, #-8]
    // 0xc4c488: LoadField: d0 = r0->field_7
    //     0xc4c488: ldur            d0, [x0, #7]
    // 0xc4c48c: ldr             x16, [fp, #0x28]
    // 0xc4c490: ldur            lr, [fp, #-0x10]
    // 0xc4c494: stp             lr, x16, [SP, #-0x10]!
    // 0xc4c498: SaveReg d0
    //     0xc4c498: str             d0, [SP, #-8]!
    // 0xc4c49c: r0 = _findBestVariant()
    //     0xc4c49c: bl              #0xc4c4d0  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::_findBestVariant
    // 0xc4c4a0: add             SP, SP, #0x18
    // 0xc4c4a4: LeaveFrame
    //     0xc4c4a4: mov             SP, fp
    //     0xc4c4a8: ldp             fp, lr, [SP], #0x10
    // 0xc4c4ac: ret
    //     0xc4c4ac: ret             
    // 0xc4c4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4c4b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4c4b4: b               #0xc4c334
    // 0xc4c4b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4c4b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4c4bc: b               #0xc4c3e8
    // 0xc4c4c0: SaveReg d0
    //     0xc4c4c0: str             q0, [SP, #-0x10]!
    // 0xc4c4c4: r0 = AllocateDouble()
    //     0xc4c4c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc4c4c8: RestoreReg d0
    //     0xc4c4c8: ldr             q0, [SP], #0x10
    // 0xc4c4cc: b               #0xc4c460
  }
  _ _findBestVariant(/* No info */) {
    // ** addr: 0xc4c4d0, size: 0x18c
    // 0xc4c4d0: EnterFrame
    //     0xc4c4d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc4c4d4: mov             fp, SP
    // 0xc4c4d8: AllocStack(0x8)
    //     0xc4c4d8: sub             SP, SP, #8
    // 0xc4c4dc: CheckStackOverflow
    //     0xc4c4dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4c4e0: cmp             SP, x16
    //     0xc4c4e4: b.ls            #0xc4c640
    // 0xc4c4e8: ldr             d0, [fp, #0x10]
    // 0xc4c4ec: r0 = inline_Allocate_Double()
    //     0xc4c4ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc4c4f0: add             x0, x0, #0x10
    //     0xc4c4f4: cmp             x1, x0
    //     0xc4c4f8: b.ls            #0xc4c648
    //     0xc4c4fc: str             x0, [THR, #0x60]  ; THR::top
    //     0xc4c500: sub             x0, x0, #0xf
    //     0xc4c504: mov             x1, #0xd108
    //     0xc4c508: movk            x1, #3, lsl #16
    //     0xc4c50c: stur            x1, [x0, #-1]
    // 0xc4c510: StoreField: r0->field_7 = d0
    //     0xc4c510: stur            d0, [x0, #7]
    // 0xc4c514: stur            x0, [fp, #-8]
    // 0xc4c518: ldr             x16, [fp, #0x18]
    // 0xc4c51c: stp             x0, x16, [SP, #-0x10]!
    // 0xc4c520: r0 = _containsKey()
    //     0xc4c520: bl              #0x6b8c3c  ; [dart:collection] _SplayTree::_containsKey
    // 0xc4c524: add             SP, SP, #0x10
    // 0xc4c528: tbnz            w0, #4, #0xc4c554
    // 0xc4c52c: ldr             x16, [fp, #0x18]
    // 0xc4c530: ldur            lr, [fp, #-8]
    // 0xc4c534: stp             lr, x16, [SP, #-0x10]!
    // 0xc4c538: r0 = []()
    //     0xc4c538: bl              #0xc64a4c  ; [dart:collection] SplayTreeMap::[]
    // 0xc4c53c: add             SP, SP, #0x10
    // 0xc4c540: cmp             w0, NULL
    // 0xc4c544: b.eq            #0xc4c658
    // 0xc4c548: LeaveFrame
    //     0xc4c548: mov             SP, fp
    //     0xc4c54c: ldp             fp, lr, [SP], #0x10
    // 0xc4c550: ret
    //     0xc4c550: ret             
    // 0xc4c554: ldr             d0, [fp, #0x10]
    // 0xc4c558: ldr             x16, [fp, #0x18]
    // 0xc4c55c: SaveReg r16
    //     0xc4c55c: str             x16, [SP, #-8]!
    // 0xc4c560: SaveReg d0
    //     0xc4c560: str             d0, [SP, #-8]!
    // 0xc4c564: r0 = lastKeyBefore()
    //     0xc4c564: bl              #0xc4c7cc  ; [dart:collection] SplayTreeMap::lastKeyBefore
    // 0xc4c568: add             SP, SP, #0x10
    // 0xc4c56c: stur            x0, [fp, #-8]
    // 0xc4c570: ldr             x16, [fp, #0x18]
    // 0xc4c574: SaveReg r16
    //     0xc4c574: str             x16, [SP, #-8]!
    // 0xc4c578: ldr             d0, [fp, #0x10]
    // 0xc4c57c: SaveReg d0
    //     0xc4c57c: str             d0, [SP, #-8]!
    // 0xc4c580: r0 = firstKeyAfter()
    //     0xc4c580: bl              #0xc4c65c  ; [dart:collection] SplayTreeMap::firstKeyAfter
    // 0xc4c584: add             SP, SP, #0x10
    // 0xc4c588: mov             x1, x0
    // 0xc4c58c: ldur            x0, [fp, #-8]
    // 0xc4c590: cmp             w0, NULL
    // 0xc4c594: b.ne            #0xc4c5b4
    // 0xc4c598: ldr             x16, [fp, #0x18]
    // 0xc4c59c: stp             x1, x16, [SP, #-0x10]!
    // 0xc4c5a0: r0 = []()
    //     0xc4c5a0: bl              #0xc64a4c  ; [dart:collection] SplayTreeMap::[]
    // 0xc4c5a4: add             SP, SP, #0x10
    // 0xc4c5a8: LeaveFrame
    //     0xc4c5a8: mov             SP, fp
    //     0xc4c5ac: ldp             fp, lr, [SP], #0x10
    // 0xc4c5b0: ret
    //     0xc4c5b0: ret             
    // 0xc4c5b4: cmp             w1, NULL
    // 0xc4c5b8: b.ne            #0xc4c5d8
    // 0xc4c5bc: ldr             x16, [fp, #0x18]
    // 0xc4c5c0: stp             x0, x16, [SP, #-0x10]!
    // 0xc4c5c4: r0 = []()
    //     0xc4c5c4: bl              #0xc64a4c  ; [dart:collection] SplayTreeMap::[]
    // 0xc4c5c8: add             SP, SP, #0x10
    // 0xc4c5cc: LeaveFrame
    //     0xc4c5cc: mov             SP, fp
    //     0xc4c5d0: ldp             fp, lr, [SP], #0x10
    // 0xc4c5d4: ret
    //     0xc4c5d4: ret             
    // 0xc4c5d8: ldr             d0, [fp, #0x10]
    // 0xc4c5dc: d1 = 2.000000
    //     0xc4c5dc: fmov            d1, #2.00000000
    // 0xc4c5e0: fcmp            d0, d1
    // 0xc4c5e4: b.vs            #0xc4c5ec
    // 0xc4c5e8: b.lt            #0xc4c608
    // 0xc4c5ec: LoadField: d2 = r0->field_7
    //     0xc4c5ec: ldur            d2, [x0, #7]
    // 0xc4c5f0: LoadField: d3 = r1->field_7
    //     0xc4c5f0: ldur            d3, [x1, #7]
    // 0xc4c5f4: fadd            d4, d2, d3
    // 0xc4c5f8: fdiv            d2, d4, d1
    // 0xc4c5fc: fcmp            d0, d2
    // 0xc4c600: b.vs            #0xc4c624
    // 0xc4c604: b.le            #0xc4c624
    // 0xc4c608: ldr             x16, [fp, #0x18]
    // 0xc4c60c: stp             x1, x16, [SP, #-0x10]!
    // 0xc4c610: r0 = []()
    //     0xc4c610: bl              #0xc64a4c  ; [dart:collection] SplayTreeMap::[]
    // 0xc4c614: add             SP, SP, #0x10
    // 0xc4c618: LeaveFrame
    //     0xc4c618: mov             SP, fp
    //     0xc4c61c: ldp             fp, lr, [SP], #0x10
    // 0xc4c620: ret
    //     0xc4c620: ret             
    // 0xc4c624: ldr             x16, [fp, #0x18]
    // 0xc4c628: stp             x0, x16, [SP, #-0x10]!
    // 0xc4c62c: r0 = []()
    //     0xc4c62c: bl              #0xc64a4c  ; [dart:collection] SplayTreeMap::[]
    // 0xc4c630: add             SP, SP, #0x10
    // 0xc4c634: LeaveFrame
    //     0xc4c634: mov             SP, fp
    //     0xc4c638: ldp             fp, lr, [SP], #0x10
    // 0xc4c63c: ret
    //     0xc4c63c: ret             
    // 0xc4c640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4c640: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4c644: b               #0xc4c4e8
    // 0xc4c648: SaveReg d0
    //     0xc4c648: str             q0, [SP, #-0x10]!
    // 0xc4c64c: r0 = AllocateDouble()
    //     0xc4c64c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc4c650: RestoreReg d0
    //     0xc4c650: ldr             q0, [SP], #0x10
    // 0xc4c654: b               #0xc4c510
    // 0xc4c658: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc4c658: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<Map<String, List<String>>?> manifestParser(dynamic, String?) {
    // ** addr: 0xc4c938, size: 0x38
    // 0xc4c938: EnterFrame
    //     0xc4c938: stp             fp, lr, [SP, #-0x10]!
    //     0xc4c93c: mov             fp, SP
    // 0xc4c940: CheckStackOverflow
    //     0xc4c940: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4c944: cmp             SP, x16
    //     0xc4c948: b.ls            #0xc4c968
    // 0xc4c94c: ldr             x16, [fp, #0x10]
    // 0xc4c950: SaveReg r16
    //     0xc4c950: str             x16, [SP, #-8]!
    // 0xc4c954: r0 = manifestParser()
    //     0xc4c954: bl              #0xc4c970  ; [package:flutter/src/painting/image_resolution.dart] AssetImage::manifestParser
    // 0xc4c958: add             SP, SP, #8
    // 0xc4c95c: LeaveFrame
    //     0xc4c95c: mov             SP, fp
    //     0xc4c960: ldp             fp, lr, [SP], #0x10
    // 0xc4c964: ret
    //     0xc4c964: ret             
    // 0xc4c968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4c968: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4c96c: b               #0xc4c94c
  }
  static _ manifestParser(/* No info */) {
    // ** addr: 0xc4c970, size: 0x224
    // 0xc4c970: EnterFrame
    //     0xc4c970: stp             fp, lr, [SP, #-0x10]!
    //     0xc4c974: mov             fp, SP
    // 0xc4c978: AllocStack(0x28)
    //     0xc4c978: sub             SP, SP, #0x28
    // 0xc4c97c: CheckStackOverflow
    //     0xc4c97c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4c980: cmp             SP, x16
    //     0xc4c984: b.ls            #0xc4cb84
    // 0xc4c988: ldr             x0, [fp, #0x10]
    // 0xc4c98c: cmp             w0, NULL
    // 0xc4c990: b.ne            #0xc4c9ac
    // 0xc4c994: r1 = <Map<String, List<String>>?>
    //     0xc4c994: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d7c8] TypeArguments: <Map<String, List<String>>?>
    //     0xc4c998: ldr             x1, [x1, #0x7c8]
    // 0xc4c99c: r0 = SynchronousFuture()
    //     0xc4c99c: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xc4c9a0: LeaveFrame
    //     0xc4c9a0: mov             SP, fp
    //     0xc4c9a4: ldp             fp, lr, [SP], #0x10
    // 0xc4c9a8: ret
    //     0xc4c9a8: ret             
    // 0xc4c9ac: r16 = Instance_JsonCodec
    //     0xc4c9ac: ldr             x16, [PP, #0x20a8]  ; [pp+0x20a8] Obj!JsonCodec<Object?, String>@b5f661
    // 0xc4c9b0: stp             x0, x16, [SP, #-0x10]!
    // 0xc4c9b4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc4c9b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc4c9b8: r0 = decode()
    //     0xc4c9b8: bl              #0x4ef6c8  ; [dart:convert] JsonCodec::decode
    // 0xc4c9bc: add             SP, SP, #0x10
    // 0xc4c9c0: mov             x3, x0
    // 0xc4c9c4: r2 = Null
    //     0xc4c9c4: mov             x2, NULL
    // 0xc4c9c8: r1 = Null
    //     0xc4c9c8: mov             x1, NULL
    // 0xc4c9cc: stur            x3, [fp, #-8]
    // 0xc4c9d0: r8 = Map<String, dynamic>
    //     0xc4c9d0: ldr             x8, [PP, #0x3da0]  ; [pp+0x3da0] Type: Map<String, dynamic>
    // 0xc4c9d4: r3 = Null
    //     0xc4c9d4: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2da00] Null
    //     0xc4c9d8: ldr             x3, [x3, #0xa00]
    // 0xc4c9dc: r0 = Map<String, dynamic>()
    //     0xc4c9dc: bl              #0x4e3b2c  ; IsType_Map<String, dynamic>_Stub
    // 0xc4c9e0: ldur            x1, [fp, #-8]
    // 0xc4c9e4: r0 = LoadClassIdInstr(r1)
    //     0xc4c9e4: ldur            x0, [x1, #-1]
    //     0xc4c9e8: ubfx            x0, x0, #0xc, #0x14
    // 0xc4c9ec: SaveReg r1
    //     0xc4c9ec: str             x1, [SP, #-8]!
    // 0xc4c9f0: r0 = GDT[cid_x0 + 0x6d7]()
    //     0xc4c9f0: add             lr, x0, #0x6d7
    //     0xc4c9f4: ldr             lr, [x21, lr, lsl #3]
    //     0xc4c9f8: blr             lr
    // 0xc4c9fc: add             SP, SP, #8
    // 0xc4ca00: stur            x0, [fp, #-0x10]
    // 0xc4ca04: r16 = <String, List<String>>
    //     0xc4ca04: add             x16, PP, #0x13, lsl #12  ; [pp+0x13010] TypeArguments: <String, List<String>>
    //     0xc4ca08: ldr             x16, [x16, #0x10]
    // 0xc4ca0c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xc4ca10: stp             lr, x16, [SP, #-0x10]!
    // 0xc4ca14: r0 = Map._fromLiteral()
    //     0xc4ca14: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc4ca18: add             SP, SP, #0x10
    // 0xc4ca1c: mov             x1, x0
    // 0xc4ca20: ldur            x0, [fp, #-0x10]
    // 0xc4ca24: stur            x1, [fp, #-0x18]
    // 0xc4ca28: r2 = LoadClassIdInstr(r0)
    //     0xc4ca28: ldur            x2, [x0, #-1]
    //     0xc4ca2c: ubfx            x2, x2, #0xc, #0x14
    // 0xc4ca30: SaveReg r0
    //     0xc4ca30: str             x0, [SP, #-8]!
    // 0xc4ca34: mov             x0, x2
    // 0xc4ca38: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc4ca38: mov             x17, #0xb940
    //     0xc4ca3c: add             lr, x0, x17
    //     0xc4ca40: ldr             lr, [x21, lr, lsl #3]
    //     0xc4ca44: blr             lr
    // 0xc4ca48: add             SP, SP, #8
    // 0xc4ca4c: mov             x1, x0
    // 0xc4ca50: stur            x1, [fp, #-0x10]
    // 0xc4ca54: ldur            x2, [fp, #-8]
    // 0xc4ca58: CheckStackOverflow
    //     0xc4ca58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4ca5c: cmp             SP, x16
    //     0xc4ca60: b.ls            #0xc4cb8c
    // 0xc4ca64: r0 = LoadClassIdInstr(r1)
    //     0xc4ca64: ldur            x0, [x1, #-1]
    //     0xc4ca68: ubfx            x0, x0, #0xc, #0x14
    // 0xc4ca6c: SaveReg r1
    //     0xc4ca6c: str             x1, [SP, #-8]!
    // 0xc4ca70: r0 = GDT[cid_x0 + 0x541]()
    //     0xc4ca70: add             lr, x0, #0x541
    //     0xc4ca74: ldr             lr, [x21, lr, lsl #3]
    //     0xc4ca78: blr             lr
    // 0xc4ca7c: add             SP, SP, #8
    // 0xc4ca80: tbnz            w0, #4, #0xc4cb60
    // 0xc4ca84: ldur            x2, [fp, #-8]
    // 0xc4ca88: ldur            x1, [fp, #-0x10]
    // 0xc4ca8c: r0 = LoadClassIdInstr(r1)
    //     0xc4ca8c: ldur            x0, [x1, #-1]
    //     0xc4ca90: ubfx            x0, x0, #0xc, #0x14
    // 0xc4ca94: SaveReg r1
    //     0xc4ca94: str             x1, [SP, #-8]!
    // 0xc4ca98: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc4ca98: add             lr, x0, #0x5ca
    //     0xc4ca9c: ldr             lr, [x21, lr, lsl #3]
    //     0xc4caa0: blr             lr
    // 0xc4caa4: add             SP, SP, #8
    // 0xc4caa8: mov             x2, x0
    // 0xc4caac: ldur            x1, [fp, #-8]
    // 0xc4cab0: stur            x2, [fp, #-0x20]
    // 0xc4cab4: r0 = LoadClassIdInstr(r1)
    //     0xc4cab4: ldur            x0, [x1, #-1]
    //     0xc4cab8: ubfx            x0, x0, #0xc, #0x14
    // 0xc4cabc: stp             x2, x1, [SP, #-0x10]!
    // 0xc4cac0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc4cac0: sub             lr, x0, #0xef
    //     0xc4cac4: ldr             lr, [x21, lr, lsl #3]
    //     0xc4cac8: blr             lr
    // 0xc4cacc: add             SP, SP, #0x10
    // 0xc4cad0: mov             x3, x0
    // 0xc4cad4: r2 = Null
    //     0xc4cad4: mov             x2, NULL
    // 0xc4cad8: r1 = Null
    //     0xc4cad8: mov             x1, NULL
    // 0xc4cadc: stur            x3, [fp, #-0x28]
    // 0xc4cae0: r4 = 59
    //     0xc4cae0: mov             x4, #0x3b
    // 0xc4cae4: branchIfSmi(r0, 0xc4caf0)
    //     0xc4cae4: tbz             w0, #0, #0xc4caf0
    // 0xc4cae8: r4 = LoadClassIdInstr(r0)
    //     0xc4cae8: ldur            x4, [x0, #-1]
    //     0xc4caec: ubfx            x4, x4, #0xc, #0x14
    // 0xc4caf0: sub             x4, x4, #0x59
    // 0xc4caf4: cmp             x4, #2
    // 0xc4caf8: b.ls            #0xc4cb0c
    // 0xc4cafc: r8 = List
    //     0xc4cafc: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0xc4cb00: r3 = Null
    //     0xc4cb00: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2da10] Null
    //     0xc4cb04: ldr             x3, [x3, #0xa10]
    // 0xc4cb08: r0 = List()
    //     0xc4cb08: bl              #0xd74840  ; IsType_List_Stub
    // 0xc4cb0c: r16 = <String>
    //     0xc4cb0c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc4cb10: ldur            lr, [fp, #-0x28]
    // 0xc4cb14: stp             lr, x16, [SP, #-0x10]!
    // 0xc4cb18: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc4cb18: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc4cb1c: r0 = List.from()
    //     0xc4cb1c: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0xc4cb20: add             SP, SP, #0x10
    // 0xc4cb24: stur            x0, [fp, #-0x28]
    // 0xc4cb28: ldur            x16, [fp, #-0x18]
    // 0xc4cb2c: ldur            lr, [fp, #-0x20]
    // 0xc4cb30: stp             lr, x16, [SP, #-0x10]!
    // 0xc4cb34: r0 = hash()
    //     0xc4cb34: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0xc4cb38: add             SP, SP, #0x10
    // 0xc4cb3c: ldur            x16, [fp, #-0x18]
    // 0xc4cb40: ldur            lr, [fp, #-0x20]
    // 0xc4cb44: stp             lr, x16, [SP, #-0x10]!
    // 0xc4cb48: ldur            x16, [fp, #-0x28]
    // 0xc4cb4c: stp             x0, x16, [SP, #-0x10]!
    // 0xc4cb50: r0 = _set()
    //     0xc4cb50: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc4cb54: add             SP, SP, #0x20
    // 0xc4cb58: ldur            x1, [fp, #-0x10]
    // 0xc4cb5c: b               #0xc4ca54
    // 0xc4cb60: ldur            x0, [fp, #-0x18]
    // 0xc4cb64: r1 = <Map<String, List<String>>?>
    //     0xc4cb64: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d7c8] TypeArguments: <Map<String, List<String>>?>
    //     0xc4cb68: ldr             x1, [x1, #0x7c8]
    // 0xc4cb6c: r0 = SynchronousFuture()
    //     0xc4cb6c: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xc4cb70: ldur            x1, [fp, #-0x18]
    // 0xc4cb74: StoreField: r0->field_b = r1
    //     0xc4cb74: stur            w1, [x0, #0xb]
    // 0xc4cb78: LeaveFrame
    //     0xc4cb78: mov             SP, fp
    //     0xc4cb7c: ldp             fp, lr, [SP], #0x10
    // 0xc4cb80: ret
    //     0xc4cb80: ret             
    // 0xc4cb84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4cb84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4cb88: b               #0xc4c988
    // 0xc4cb8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4cb8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4cb90: b               #0xc4ca64
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6fb2c, size: 0x110
    // 0xc6fb2c: EnterFrame
    //     0xc6fb2c: stp             fp, lr, [SP, #-0x10]!
    //     0xc6fb30: mov             fp, SP
    // 0xc6fb34: CheckStackOverflow
    //     0xc6fb34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6fb38: cmp             SP, x16
    //     0xc6fb3c: b.ls            #0xc6fc34
    // 0xc6fb40: ldr             x1, [fp, #0x10]
    // 0xc6fb44: cmp             w1, NULL
    // 0xc6fb48: b.ne            #0xc6fb5c
    // 0xc6fb4c: r0 = false
    //     0xc6fb4c: add             x0, NULL, #0x30  ; false
    // 0xc6fb50: LeaveFrame
    //     0xc6fb50: mov             SP, fp
    //     0xc6fb54: ldp             fp, lr, [SP], #0x10
    // 0xc6fb58: ret
    //     0xc6fb58: ret             
    // 0xc6fb5c: r0 = 59
    //     0xc6fb5c: mov             x0, #0x3b
    // 0xc6fb60: branchIfSmi(r1, 0xc6fb6c)
    //     0xc6fb60: tbz             w1, #0, #0xc6fb6c
    // 0xc6fb64: r0 = LoadClassIdInstr(r1)
    //     0xc6fb64: ldur            x0, [x1, #-1]
    //     0xc6fb68: ubfx            x0, x0, #0xc, #0x14
    // 0xc6fb6c: SaveReg r1
    //     0xc6fb6c: str             x1, [SP, #-8]!
    // 0xc6fb70: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc6fb70: mov             x17, #0x57c5
    //     0xc6fb74: add             lr, x0, x17
    //     0xc6fb78: ldr             lr, [x21, lr, lsl #3]
    //     0xc6fb7c: blr             lr
    // 0xc6fb80: add             SP, SP, #8
    // 0xc6fb84: r1 = LoadClassIdInstr(r0)
    //     0xc6fb84: ldur            x1, [x0, #-1]
    //     0xc6fb88: ubfx            x1, x1, #0xc, #0x14
    // 0xc6fb8c: r16 = AssetImage<AssetBundleImageKey>
    //     0xc6fb8c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21cb8] Type: AssetImage<AssetBundleImageKey>
    //     0xc6fb90: ldr             x16, [x16, #0xcb8]
    // 0xc6fb94: stp             x16, x0, [SP, #-0x10]!
    // 0xc6fb98: mov             x0, x1
    // 0xc6fb9c: mov             lr, x0
    // 0xc6fba0: ldr             lr, [x21, lr, lsl #3]
    // 0xc6fba4: blr             lr
    // 0xc6fba8: add             SP, SP, #0x10
    // 0xc6fbac: tbz             w0, #4, #0xc6fbc0
    // 0xc6fbb0: r0 = false
    //     0xc6fbb0: add             x0, NULL, #0x30  ; false
    // 0xc6fbb4: LeaveFrame
    //     0xc6fbb4: mov             SP, fp
    //     0xc6fbb8: ldp             fp, lr, [SP], #0x10
    // 0xc6fbbc: ret
    //     0xc6fbbc: ret             
    // 0xc6fbc0: ldr             x0, [fp, #0x10]
    // 0xc6fbc4: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6fbc4: mov             x1, #0x76
    //     0xc6fbc8: tbz             w0, #0, #0xc6fbd8
    //     0xc6fbcc: ldur            x1, [x0, #-1]
    //     0xc6fbd0: ubfx            x1, x1, #0xc, #0x14
    //     0xc6fbd4: lsl             x1, x1, #1
    // 0xc6fbd8: r17 = 8930
    //     0xc6fbd8: mov             x17, #0x22e2
    // 0xc6fbdc: cmp             w1, w17
    // 0xc6fbe0: b.ne            #0xc6fc24
    // 0xc6fbe4: ldr             x1, [fp, #0x18]
    // 0xc6fbe8: LoadField: r2 = r0->field_b
    //     0xc6fbe8: ldur            w2, [x0, #0xb]
    // 0xc6fbec: DecompressPointer r2
    //     0xc6fbec: add             x2, x2, HEAP, lsl #32
    // 0xc6fbf0: LoadField: r0 = r1->field_b
    //     0xc6fbf0: ldur            w0, [x1, #0xb]
    // 0xc6fbf4: DecompressPointer r0
    //     0xc6fbf4: add             x0, x0, HEAP, lsl #32
    // 0xc6fbf8: r1 = LoadClassIdInstr(r2)
    //     0xc6fbf8: ldur            x1, [x2, #-1]
    //     0xc6fbfc: ubfx            x1, x1, #0xc, #0x14
    // 0xc6fc00: stp             x0, x2, [SP, #-0x10]!
    // 0xc6fc04: mov             x0, x1
    // 0xc6fc08: mov             lr, x0
    // 0xc6fc0c: ldr             lr, [x21, lr, lsl #3]
    // 0xc6fc10: blr             lr
    // 0xc6fc14: add             SP, SP, #0x10
    // 0xc6fc18: tbnz            w0, #4, #0xc6fc24
    // 0xc6fc1c: r0 = true
    //     0xc6fc1c: add             x0, NULL, #0x20  ; true
    // 0xc6fc20: b               #0xc6fc28
    // 0xc6fc24: r0 = false
    //     0xc6fc24: add             x0, NULL, #0x30  ; false
    // 0xc6fc28: LeaveFrame
    //     0xc6fc28: mov             SP, fp
    //     0xc6fc2c: ldp             fp, lr, [SP], #0x10
    // 0xc6fc30: ret
    //     0xc6fc30: ret             
    // 0xc6fc34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6fc34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6fc38: b               #0xc6fb40
  }
}

// lib: , url: package:flutter/src/painting/alignment.dart

// class id: 1049344, size: 0x8
class :: {
}

// class id: 2115, size: 0x10, field offset: 0x8
//   const constructor, 
class TextAlignVertical extends Object {

  _Mint field_8;

  _ toString(/* No info */) {
    // ** addr: 0xadf480, size: 0xb0
    // 0xadf480: EnterFrame
    //     0xadf480: stp             fp, lr, [SP, #-0x10]!
    //     0xadf484: mov             fp, SP
    // 0xadf488: CheckStackOverflow
    //     0xadf488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadf48c: cmp             SP, x16
    //     0xadf490: b.ls            #0xadf50c
    // 0xadf494: r1 = Null
    //     0xadf494: mov             x1, NULL
    // 0xadf498: r2 = 8
    //     0xadf498: mov             x2, #8
    // 0xadf49c: r0 = AllocateArray()
    //     0xadf49c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadf4a0: r17 = "TextAlignVertical"
    //     0xadf4a0: add             x17, PP, #0x50, lsl #12  ; [pp+0x503a8] "TextAlignVertical"
    //     0xadf4a4: ldr             x17, [x17, #0x3a8]
    // 0xadf4a8: StoreField: r0->field_f = r17
    //     0xadf4a8: stur            w17, [x0, #0xf]
    // 0xadf4ac: r17 = "(y: "
    //     0xadf4ac: add             x17, PP, #0x50, lsl #12  ; [pp+0x503b0] "(y: "
    //     0xadf4b0: ldr             x17, [x17, #0x3b0]
    // 0xadf4b4: StoreField: r0->field_13 = r17
    //     0xadf4b4: stur            w17, [x0, #0x13]
    // 0xadf4b8: ldr             x1, [fp, #0x10]
    // 0xadf4bc: LoadField: d0 = r1->field_7
    //     0xadf4bc: ldur            d0, [x1, #7]
    // 0xadf4c0: r1 = inline_Allocate_Double()
    //     0xadf4c0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xadf4c4: add             x1, x1, #0x10
    //     0xadf4c8: cmp             x2, x1
    //     0xadf4cc: b.ls            #0xadf514
    //     0xadf4d0: str             x1, [THR, #0x60]  ; THR::top
    //     0xadf4d4: sub             x1, x1, #0xf
    //     0xadf4d8: mov             x2, #0xd108
    //     0xadf4dc: movk            x2, #3, lsl #16
    //     0xadf4e0: stur            x2, [x1, #-1]
    // 0xadf4e4: StoreField: r1->field_7 = d0
    //     0xadf4e4: stur            d0, [x1, #7]
    // 0xadf4e8: StoreField: r0->field_17 = r1
    //     0xadf4e8: stur            w1, [x0, #0x17]
    // 0xadf4ec: r17 = ")"
    //     0xadf4ec: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadf4f0: StoreField: r0->field_1b = r17
    //     0xadf4f0: stur            w17, [x0, #0x1b]
    // 0xadf4f4: SaveReg r0
    //     0xadf4f4: str             x0, [SP, #-8]!
    // 0xadf4f8: r0 = _interpolate()
    //     0xadf4f8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadf4fc: add             SP, SP, #8
    // 0xadf500: LeaveFrame
    //     0xadf500: mov             SP, fp
    //     0xadf504: ldp             fp, lr, [SP], #0x10
    // 0xadf508: ret
    //     0xadf508: ret             
    // 0xadf50c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadf50c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadf510: b               #0xadf494
    // 0xadf514: SaveReg d0
    //     0xadf514: str             q0, [SP, #-0x10]!
    // 0xadf518: SaveReg r0
    //     0xadf518: str             x0, [SP, #-8]!
    // 0xadf51c: r0 = AllocateDouble()
    //     0xadf51c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadf520: mov             x1, x0
    // 0xadf524: RestoreReg r0
    //     0xadf524: ldr             x0, [SP], #8
    // 0xadf528: RestoreReg d0
    //     0xadf528: ldr             q0, [SP], #0x10
    // 0xadf52c: b               #0xadf4e4
  }
}

// class id: 2116, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class AlignmentGeometry extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xadf06c, size: 0x414
    // 0xadf06c: EnterFrame
    //     0xadf06c: stp             fp, lr, [SP, #-0x10]!
    //     0xadf070: mov             fp, SP
    // 0xadf074: AllocStack(0x18)
    //     0xadf074: sub             SP, SP, #0x18
    // 0xadf078: CheckStackOverflow
    //     0xadf078: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadf07c: cmp             SP, x16
    //     0xadf080: b.ls            #0xadf424
    // 0xadf084: ldr             x0, [fp, #0x10]
    // 0xadf088: r1 = LoadClassIdInstr(r0)
    //     0xadf088: ldur            x1, [x0, #-1]
    //     0xadf08c: ubfx            x1, x1, #0xc, #0x14
    // 0xadf090: lsl             x1, x1, #1
    // 0xadf094: stur            x1, [fp, #-8]
    // 0xadf098: r17 = 4240
    //     0xadf098: mov             x17, #0x1090
    // 0xadf09c: cmp             w1, w17
    // 0xadf0a0: b.gt            #0xadf0b8
    // 0xadf0a4: r17 = 4238
    //     0xadf0a4: mov             x17, #0x108e
    // 0xadf0a8: cmp             w1, w17
    // 0xadf0ac: b.lt            #0xadf0b8
    // 0xadf0b0: d1 = 0.000000
    //     0xadf0b0: eor             v1.16b, v1.16b, v1.16b
    // 0xadf0b4: b               #0xadf0d8
    // 0xadf0b8: r17 = 4234
    //     0xadf0b8: mov             x17, #0x108a
    // 0xadf0bc: cmp             w1, w17
    // 0xadf0c0: b.ne            #0xadf0d0
    // 0xadf0c4: LoadField: d0 = r0->field_f
    //     0xadf0c4: ldur            d0, [x0, #0xf]
    // 0xadf0c8: mov             v1.16b, v0.16b
    // 0xadf0cc: b               #0xadf0d8
    // 0xadf0d0: LoadField: d0 = r0->field_7
    //     0xadf0d0: ldur            d0, [x0, #7]
    // 0xadf0d4: mov             v1.16b, v0.16b
    // 0xadf0d8: d0 = 0.000000
    //     0xadf0d8: eor             v0.16b, v0.16b, v0.16b
    // 0xadf0dc: fcmp            d1, d0
    // 0xadf0e0: b.vs            #0xadf19c
    // 0xadf0e4: b.ne            #0xadf19c
    // 0xadf0e8: r17 = 4240
    //     0xadf0e8: mov             x17, #0x1090
    // 0xadf0ec: cmp             w1, w17
    // 0xadf0f0: b.gt            #0xadf108
    // 0xadf0f4: r17 = 4238
    //     0xadf0f4: mov             x17, #0x108e
    // 0xadf0f8: cmp             w1, w17
    // 0xadf0fc: b.lt            #0xadf108
    // 0xadf100: LoadField: d0 = r0->field_7
    //     0xadf100: ldur            d0, [x0, #7]
    // 0xadf104: b               #0xadf120
    // 0xadf108: r17 = 4234
    //     0xadf108: mov             x17, #0x108a
    // 0xadf10c: cmp             w1, w17
    // 0xadf110: b.ne            #0xadf11c
    // 0xadf114: LoadField: d0 = r0->field_7
    //     0xadf114: ldur            d0, [x0, #7]
    // 0xadf118: b               #0xadf120
    // 0xadf11c: d0 = 0.000000
    //     0xadf11c: eor             v0.16b, v0.16b, v0.16b
    // 0xadf120: r17 = 4240
    //     0xadf120: mov             x17, #0x1090
    // 0xadf124: cmp             w1, w17
    // 0xadf128: b.gt            #0xadf140
    // 0xadf12c: r17 = 4238
    //     0xadf12c: mov             x17, #0x108e
    // 0xadf130: cmp             w1, w17
    // 0xadf134: b.lt            #0xadf140
    // 0xadf138: LoadField: d1 = r0->field_f
    //     0xadf138: ldur            d1, [x0, #0xf]
    // 0xadf13c: b               #0xadf158
    // 0xadf140: r17 = 4234
    //     0xadf140: mov             x17, #0x108a
    // 0xadf144: cmp             w1, w17
    // 0xadf148: b.ne            #0xadf154
    // 0xadf14c: LoadField: d1 = r0->field_17
    //     0xadf14c: ldur            d1, [x0, #0x17]
    // 0xadf150: b               #0xadf158
    // 0xadf154: LoadField: d1 = r0->field_f
    //     0xadf154: ldur            d1, [x0, #0xf]
    // 0xadf158: r0 = inline_Allocate_Double()
    //     0xadf158: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xadf15c: add             x0, x0, #0x10
    //     0xadf160: cmp             x1, x0
    //     0xadf164: b.ls            #0xadf42c
    //     0xadf168: str             x0, [THR, #0x60]  ; THR::top
    //     0xadf16c: sub             x0, x0, #0xf
    //     0xadf170: mov             x1, #0xd108
    //     0xadf174: movk            x1, #3, lsl #16
    //     0xadf178: stur            x1, [x0, #-1]
    // 0xadf17c: StoreField: r0->field_7 = d0
    //     0xadf17c: stur            d0, [x0, #7]
    // 0xadf180: SaveReg r0
    //     0xadf180: str             x0, [SP, #-8]!
    // 0xadf184: SaveReg d1
    //     0xadf184: str             d1, [SP, #-8]!
    // 0xadf188: r0 = _stringify()
    //     0xadf188: bl              #0xadea48  ; [package:flutter/src/painting/alignment.dart] Alignment::_stringify
    // 0xadf18c: add             SP, SP, #0x10
    // 0xadf190: LeaveFrame
    //     0xadf190: mov             SP, fp
    //     0xadf194: ldp             fp, lr, [SP], #0x10
    // 0xadf198: ret
    //     0xadf198: ret             
    // 0xadf19c: r17 = 4240
    //     0xadf19c: mov             x17, #0x1090
    // 0xadf1a0: cmp             w1, w17
    // 0xadf1a4: b.gt            #0xadf1bc
    // 0xadf1a8: r17 = 4238
    //     0xadf1a8: mov             x17, #0x108e
    // 0xadf1ac: cmp             w1, w17
    // 0xadf1b0: b.lt            #0xadf1bc
    // 0xadf1b4: LoadField: d1 = r0->field_7
    //     0xadf1b4: ldur            d1, [x0, #7]
    // 0xadf1b8: b               #0xadf1d4
    // 0xadf1bc: r17 = 4234
    //     0xadf1bc: mov             x17, #0x108a
    // 0xadf1c0: cmp             w1, w17
    // 0xadf1c4: b.ne            #0xadf1d0
    // 0xadf1c8: LoadField: d1 = r0->field_7
    //     0xadf1c8: ldur            d1, [x0, #7]
    // 0xadf1cc: b               #0xadf1d4
    // 0xadf1d0: d1 = 0.000000
    //     0xadf1d0: eor             v1.16b, v1.16b, v1.16b
    // 0xadf1d4: fcmp            d1, d0
    // 0xadf1d8: b.vs            #0xadf294
    // 0xadf1dc: b.ne            #0xadf294
    // 0xadf1e0: r17 = 4240
    //     0xadf1e0: mov             x17, #0x1090
    // 0xadf1e4: cmp             w1, w17
    // 0xadf1e8: b.gt            #0xadf200
    // 0xadf1ec: r17 = 4238
    //     0xadf1ec: mov             x17, #0x108e
    // 0xadf1f0: cmp             w1, w17
    // 0xadf1f4: b.lt            #0xadf200
    // 0xadf1f8: d0 = 0.000000
    //     0xadf1f8: eor             v0.16b, v0.16b, v0.16b
    // 0xadf1fc: b               #0xadf218
    // 0xadf200: r17 = 4234
    //     0xadf200: mov             x17, #0x108a
    // 0xadf204: cmp             w1, w17
    // 0xadf208: b.ne            #0xadf214
    // 0xadf20c: LoadField: d0 = r0->field_f
    //     0xadf20c: ldur            d0, [x0, #0xf]
    // 0xadf210: b               #0xadf218
    // 0xadf214: LoadField: d0 = r0->field_7
    //     0xadf214: ldur            d0, [x0, #7]
    // 0xadf218: r17 = 4240
    //     0xadf218: mov             x17, #0x1090
    // 0xadf21c: cmp             w1, w17
    // 0xadf220: b.gt            #0xadf238
    // 0xadf224: r17 = 4238
    //     0xadf224: mov             x17, #0x108e
    // 0xadf228: cmp             w1, w17
    // 0xadf22c: b.lt            #0xadf238
    // 0xadf230: LoadField: d1 = r0->field_f
    //     0xadf230: ldur            d1, [x0, #0xf]
    // 0xadf234: b               #0xadf250
    // 0xadf238: r17 = 4234
    //     0xadf238: mov             x17, #0x108a
    // 0xadf23c: cmp             w1, w17
    // 0xadf240: b.ne            #0xadf24c
    // 0xadf244: LoadField: d1 = r0->field_17
    //     0xadf244: ldur            d1, [x0, #0x17]
    // 0xadf248: b               #0xadf250
    // 0xadf24c: LoadField: d1 = r0->field_f
    //     0xadf24c: ldur            d1, [x0, #0xf]
    // 0xadf250: r0 = inline_Allocate_Double()
    //     0xadf250: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xadf254: add             x0, x0, #0x10
    //     0xadf258: cmp             x1, x0
    //     0xadf25c: b.ls            #0xadf43c
    //     0xadf260: str             x0, [THR, #0x60]  ; THR::top
    //     0xadf264: sub             x0, x0, #0xf
    //     0xadf268: mov             x1, #0xd108
    //     0xadf26c: movk            x1, #3, lsl #16
    //     0xadf270: stur            x1, [x0, #-1]
    // 0xadf274: StoreField: r0->field_7 = d0
    //     0xadf274: stur            d0, [x0, #7]
    // 0xadf278: SaveReg r0
    //     0xadf278: str             x0, [SP, #-8]!
    // 0xadf27c: SaveReg d1
    //     0xadf27c: str             d1, [SP, #-8]!
    // 0xadf280: r0 = _stringify()
    //     0xadf280: bl              #0xaded98  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::_stringify
    // 0xadf284: add             SP, SP, #0x10
    // 0xadf288: LeaveFrame
    //     0xadf288: mov             SP, fp
    //     0xadf28c: ldp             fp, lr, [SP], #0x10
    // 0xadf290: ret
    //     0xadf290: ret             
    // 0xadf294: r17 = 4240
    //     0xadf294: mov             x17, #0x1090
    // 0xadf298: cmp             w1, w17
    // 0xadf29c: b.gt            #0xadf2b4
    // 0xadf2a0: r17 = 4238
    //     0xadf2a0: mov             x17, #0x108e
    // 0xadf2a4: cmp             w1, w17
    // 0xadf2a8: b.lt            #0xadf2b4
    // 0xadf2ac: LoadField: d0 = r0->field_7
    //     0xadf2ac: ldur            d0, [x0, #7]
    // 0xadf2b0: b               #0xadf2cc
    // 0xadf2b4: r17 = 4234
    //     0xadf2b4: mov             x17, #0x108a
    // 0xadf2b8: cmp             w1, w17
    // 0xadf2bc: b.ne            #0xadf2c8
    // 0xadf2c0: LoadField: d0 = r0->field_7
    //     0xadf2c0: ldur            d0, [x0, #7]
    // 0xadf2c4: b               #0xadf2cc
    // 0xadf2c8: d0 = 0.000000
    //     0xadf2c8: eor             v0.16b, v0.16b, v0.16b
    // 0xadf2cc: r17 = 4240
    //     0xadf2cc: mov             x17, #0x1090
    // 0xadf2d0: cmp             w1, w17
    // 0xadf2d4: b.gt            #0xadf2ec
    // 0xadf2d8: r17 = 4238
    //     0xadf2d8: mov             x17, #0x108e
    // 0xadf2dc: cmp             w1, w17
    // 0xadf2e0: b.lt            #0xadf2ec
    // 0xadf2e4: LoadField: d1 = r0->field_f
    //     0xadf2e4: ldur            d1, [x0, #0xf]
    // 0xadf2e8: b               #0xadf304
    // 0xadf2ec: r17 = 4234
    //     0xadf2ec: mov             x17, #0x108a
    // 0xadf2f0: cmp             w1, w17
    // 0xadf2f4: b.ne            #0xadf300
    // 0xadf2f8: LoadField: d1 = r0->field_17
    //     0xadf2f8: ldur            d1, [x0, #0x17]
    // 0xadf2fc: b               #0xadf304
    // 0xadf300: LoadField: d1 = r0->field_f
    //     0xadf300: ldur            d1, [x0, #0xf]
    // 0xadf304: r2 = inline_Allocate_Double()
    //     0xadf304: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xadf308: add             x2, x2, #0x10
    //     0xadf30c: cmp             x3, x2
    //     0xadf310: b.ls            #0xadf44c
    //     0xadf314: str             x2, [THR, #0x60]  ; THR::top
    //     0xadf318: sub             x2, x2, #0xf
    //     0xadf31c: mov             x3, #0xd108
    //     0xadf320: movk            x3, #3, lsl #16
    //     0xadf324: stur            x3, [x2, #-1]
    // 0xadf328: StoreField: r2->field_7 = d0
    //     0xadf328: stur            d0, [x2, #7]
    // 0xadf32c: SaveReg r2
    //     0xadf32c: str             x2, [SP, #-8]!
    // 0xadf330: SaveReg d1
    //     0xadf330: str             d1, [SP, #-8]!
    // 0xadf334: r0 = _stringify()
    //     0xadf334: bl              #0xadea48  ; [package:flutter/src/painting/alignment.dart] Alignment::_stringify
    // 0xadf338: add             SP, SP, #0x10
    // 0xadf33c: r1 = Null
    //     0xadf33c: mov             x1, NULL
    // 0xadf340: r2 = 6
    //     0xadf340: mov             x2, #6
    // 0xadf344: stur            x0, [fp, #-0x10]
    // 0xadf348: r0 = AllocateArray()
    //     0xadf348: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadf34c: mov             x1, x0
    // 0xadf350: ldur            x0, [fp, #-0x10]
    // 0xadf354: stur            x1, [fp, #-0x18]
    // 0xadf358: StoreField: r1->field_f = r0
    //     0xadf358: stur            w0, [x1, #0xf]
    // 0xadf35c: r17 = " + "
    //     0xadf35c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe860] " + "
    //     0xadf360: ldr             x17, [x17, #0x860]
    // 0xadf364: StoreField: r1->field_13 = r17
    //     0xadf364: stur            w17, [x1, #0x13]
    // 0xadf368: ldur            x0, [fp, #-8]
    // 0xadf36c: r17 = 4240
    //     0xadf36c: mov             x17, #0x1090
    // 0xadf370: cmp             w0, w17
    // 0xadf374: b.gt            #0xadf38c
    // 0xadf378: r17 = 4238
    //     0xadf378: mov             x17, #0x108e
    // 0xadf37c: cmp             w0, w17
    // 0xadf380: b.lt            #0xadf38c
    // 0xadf384: d0 = 0.000000
    //     0xadf384: eor             v0.16b, v0.16b, v0.16b
    // 0xadf388: b               #0xadf3ac
    // 0xadf38c: r17 = 4234
    //     0xadf38c: mov             x17, #0x108a
    // 0xadf390: cmp             w0, w17
    // 0xadf394: b.ne            #0xadf3a4
    // 0xadf398: ldr             x0, [fp, #0x10]
    // 0xadf39c: LoadField: d0 = r0->field_f
    //     0xadf39c: ldur            d0, [x0, #0xf]
    // 0xadf3a0: b               #0xadf3ac
    // 0xadf3a4: ldr             x0, [fp, #0x10]
    // 0xadf3a8: LoadField: d0 = r0->field_7
    //     0xadf3a8: ldur            d0, [x0, #7]
    // 0xadf3ac: r0 = inline_Allocate_Double()
    //     0xadf3ac: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xadf3b0: add             x0, x0, #0x10
    //     0xadf3b4: cmp             x2, x0
    //     0xadf3b8: b.ls            #0xadf468
    //     0xadf3bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xadf3c0: sub             x0, x0, #0xf
    //     0xadf3c4: mov             x2, #0xd108
    //     0xadf3c8: movk            x2, #3, lsl #16
    //     0xadf3cc: stur            x2, [x0, #-1]
    // 0xadf3d0: StoreField: r0->field_7 = d0
    //     0xadf3d0: stur            d0, [x0, #7]
    // 0xadf3d4: stp             xzr, x0, [SP, #-0x10]!
    // 0xadf3d8: r0 = _stringify()
    //     0xadf3d8: bl              #0xaded98  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::_stringify
    // 0xadf3dc: add             SP, SP, #0x10
    // 0xadf3e0: ldur            x1, [fp, #-0x18]
    // 0xadf3e4: ArrayStore: r1[2] = r0  ; List_4
    //     0xadf3e4: add             x25, x1, #0x17
    //     0xadf3e8: str             w0, [x25]
    //     0xadf3ec: tbz             w0, #0, #0xadf408
    //     0xadf3f0: ldurb           w16, [x1, #-1]
    //     0xadf3f4: ldurb           w17, [x0, #-1]
    //     0xadf3f8: and             x16, x17, x16, lsr #2
    //     0xadf3fc: tst             x16, HEAP, lsr #32
    //     0xadf400: b.eq            #0xadf408
    //     0xadf404: bl              #0xd67e5c
    // 0xadf408: ldur            x16, [fp, #-0x18]
    // 0xadf40c: SaveReg r16
    //     0xadf40c: str             x16, [SP, #-8]!
    // 0xadf410: r0 = _interpolate()
    //     0xadf410: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadf414: add             SP, SP, #8
    // 0xadf418: LeaveFrame
    //     0xadf418: mov             SP, fp
    //     0xadf41c: ldp             fp, lr, [SP], #0x10
    // 0xadf420: ret
    //     0xadf420: ret             
    // 0xadf424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadf424: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadf428: b               #0xadf084
    // 0xadf42c: stp             q0, q1, [SP, #-0x20]!
    // 0xadf430: r0 = AllocateDouble()
    //     0xadf430: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadf434: ldp             q0, q1, [SP], #0x20
    // 0xadf438: b               #0xadf17c
    // 0xadf43c: stp             q0, q1, [SP, #-0x20]!
    // 0xadf440: r0 = AllocateDouble()
    //     0xadf440: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadf444: ldp             q0, q1, [SP], #0x20
    // 0xadf448: b               #0xadf274
    // 0xadf44c: stp             q0, q1, [SP, #-0x20]!
    // 0xadf450: stp             x0, x1, [SP, #-0x10]!
    // 0xadf454: r0 = AllocateDouble()
    //     0xadf454: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadf458: mov             x2, x0
    // 0xadf45c: ldp             x0, x1, [SP], #0x10
    // 0xadf460: ldp             q0, q1, [SP], #0x20
    // 0xadf464: b               #0xadf328
    // 0xadf468: SaveReg d0
    //     0xadf468: str             q0, [SP, #-0x10]!
    // 0xadf46c: SaveReg r1
    //     0xadf46c: str             x1, [SP, #-8]!
    // 0xadf470: r0 = AllocateDouble()
    //     0xadf470: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadf474: RestoreReg r1
    //     0xadf474: ldr             x1, [SP], #8
    // 0xadf478: RestoreReg d0
    //     0xadf478: ldr             q0, [SP], #0x10
    // 0xadf47c: b               #0xadf3d0
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0e06c, size: 0x1d4
    // 0xb0e06c: EnterFrame
    //     0xb0e06c: stp             fp, lr, [SP, #-0x10]!
    //     0xb0e070: mov             fp, SP
    // 0xb0e074: CheckStackOverflow
    //     0xb0e074: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0e078: cmp             SP, x16
    //     0xb0e07c: b.ls            #0xb0e1e8
    // 0xb0e080: ldr             x0, [fp, #0x10]
    // 0xb0e084: r1 = LoadClassIdInstr(r0)
    //     0xb0e084: ldur            x1, [x0, #-1]
    //     0xb0e088: ubfx            x1, x1, #0xc, #0x14
    // 0xb0e08c: lsl             x1, x1, #1
    // 0xb0e090: r17 = 4240
    //     0xb0e090: mov             x17, #0x1090
    // 0xb0e094: cmp             w1, w17
    // 0xb0e098: b.gt            #0xb0e0b0
    // 0xb0e09c: r17 = 4238
    //     0xb0e09c: mov             x17, #0x108e
    // 0xb0e0a0: cmp             w1, w17
    // 0xb0e0a4: b.lt            #0xb0e0b0
    // 0xb0e0a8: LoadField: d0 = r0->field_7
    //     0xb0e0a8: ldur            d0, [x0, #7]
    // 0xb0e0ac: b               #0xb0e0c8
    // 0xb0e0b0: r17 = 4234
    //     0xb0e0b0: mov             x17, #0x108a
    // 0xb0e0b4: cmp             w1, w17
    // 0xb0e0b8: b.ne            #0xb0e0c4
    // 0xb0e0bc: LoadField: d0 = r0->field_7
    //     0xb0e0bc: ldur            d0, [x0, #7]
    // 0xb0e0c0: b               #0xb0e0c8
    // 0xb0e0c4: d0 = 0.000000
    //     0xb0e0c4: eor             v0.16b, v0.16b, v0.16b
    // 0xb0e0c8: r17 = 4240
    //     0xb0e0c8: mov             x17, #0x1090
    // 0xb0e0cc: cmp             w1, w17
    // 0xb0e0d0: b.gt            #0xb0e0e8
    // 0xb0e0d4: r17 = 4238
    //     0xb0e0d4: mov             x17, #0x108e
    // 0xb0e0d8: cmp             w1, w17
    // 0xb0e0dc: b.lt            #0xb0e0e8
    // 0xb0e0e0: d1 = 0.000000
    //     0xb0e0e0: eor             v1.16b, v1.16b, v1.16b
    // 0xb0e0e4: b               #0xb0e100
    // 0xb0e0e8: r17 = 4234
    //     0xb0e0e8: mov             x17, #0x108a
    // 0xb0e0ec: cmp             w1, w17
    // 0xb0e0f0: b.ne            #0xb0e0fc
    // 0xb0e0f4: LoadField: d1 = r0->field_f
    //     0xb0e0f4: ldur            d1, [x0, #0xf]
    // 0xb0e0f8: b               #0xb0e100
    // 0xb0e0fc: LoadField: d1 = r0->field_7
    //     0xb0e0fc: ldur            d1, [x0, #7]
    // 0xb0e100: r17 = 4240
    //     0xb0e100: mov             x17, #0x1090
    // 0xb0e104: cmp             w1, w17
    // 0xb0e108: b.gt            #0xb0e120
    // 0xb0e10c: r17 = 4238
    //     0xb0e10c: mov             x17, #0x108e
    // 0xb0e110: cmp             w1, w17
    // 0xb0e114: b.lt            #0xb0e120
    // 0xb0e118: LoadField: d2 = r0->field_f
    //     0xb0e118: ldur            d2, [x0, #0xf]
    // 0xb0e11c: b               #0xb0e138
    // 0xb0e120: r17 = 4234
    //     0xb0e120: mov             x17, #0x108a
    // 0xb0e124: cmp             w1, w17
    // 0xb0e128: b.ne            #0xb0e134
    // 0xb0e12c: LoadField: d2 = r0->field_17
    //     0xb0e12c: ldur            d2, [x0, #0x17]
    // 0xb0e130: b               #0xb0e138
    // 0xb0e134: LoadField: d2 = r0->field_f
    //     0xb0e134: ldur            d2, [x0, #0xf]
    // 0xb0e138: r0 = inline_Allocate_Double()
    //     0xb0e138: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb0e13c: add             x0, x0, #0x10
    //     0xb0e140: cmp             x1, x0
    //     0xb0e144: b.ls            #0xb0e1f0
    //     0xb0e148: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0e14c: sub             x0, x0, #0xf
    //     0xb0e150: mov             x1, #0xd108
    //     0xb0e154: movk            x1, #3, lsl #16
    //     0xb0e158: stur            x1, [x0, #-1]
    // 0xb0e15c: StoreField: r0->field_7 = d0
    //     0xb0e15c: stur            d0, [x0, #7]
    // 0xb0e160: r1 = inline_Allocate_Double()
    //     0xb0e160: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb0e164: add             x1, x1, #0x10
    //     0xb0e168: cmp             x2, x1
    //     0xb0e16c: b.ls            #0xb0e208
    //     0xb0e170: str             x1, [THR, #0x60]  ; THR::top
    //     0xb0e174: sub             x1, x1, #0xf
    //     0xb0e178: mov             x2, #0xd108
    //     0xb0e17c: movk            x2, #3, lsl #16
    //     0xb0e180: stur            x2, [x1, #-1]
    // 0xb0e184: StoreField: r1->field_7 = d1
    //     0xb0e184: stur            d1, [x1, #7]
    // 0xb0e188: r2 = inline_Allocate_Double()
    //     0xb0e188: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb0e18c: add             x2, x2, #0x10
    //     0xb0e190: cmp             x3, x2
    //     0xb0e194: b.ls            #0xb0e224
    //     0xb0e198: str             x2, [THR, #0x60]  ; THR::top
    //     0xb0e19c: sub             x2, x2, #0xf
    //     0xb0e1a0: mov             x3, #0xd108
    //     0xb0e1a4: movk            x3, #3, lsl #16
    //     0xb0e1a8: stur            x3, [x2, #-1]
    // 0xb0e1ac: StoreField: r2->field_7 = d2
    //     0xb0e1ac: stur            d2, [x2, #7]
    // 0xb0e1b0: stp             x1, x0, [SP, #-0x10]!
    // 0xb0e1b4: SaveReg r2
    //     0xb0e1b4: str             x2, [SP, #-8]!
    // 0xb0e1b8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xb0e1b8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xb0e1bc: r0 = hash()
    //     0xb0e1bc: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0e1c0: add             SP, SP, #0x18
    // 0xb0e1c4: mov             x2, x0
    // 0xb0e1c8: r0 = BoxInt64Instr(r2)
    //     0xb0e1c8: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e1cc: cmp             x2, x0, asr #1
    //     0xb0e1d0: b.eq            #0xb0e1dc
    //     0xb0e1d4: bl              #0xd69bb8
    //     0xb0e1d8: stur            x2, [x0, #7]
    // 0xb0e1dc: LeaveFrame
    //     0xb0e1dc: mov             SP, fp
    //     0xb0e1e0: ldp             fp, lr, [SP], #0x10
    // 0xb0e1e4: ret
    //     0xb0e1e4: ret             
    // 0xb0e1e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0e1e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0e1ec: b               #0xb0e080
    // 0xb0e1f0: stp             q1, q2, [SP, #-0x20]!
    // 0xb0e1f4: SaveReg d0
    //     0xb0e1f4: str             q0, [SP, #-0x10]!
    // 0xb0e1f8: r0 = AllocateDouble()
    //     0xb0e1f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e1fc: RestoreReg d0
    //     0xb0e1fc: ldr             q0, [SP], #0x10
    // 0xb0e200: ldp             q1, q2, [SP], #0x20
    // 0xb0e204: b               #0xb0e15c
    // 0xb0e208: stp             q1, q2, [SP, #-0x20]!
    // 0xb0e20c: SaveReg r0
    //     0xb0e20c: str             x0, [SP, #-8]!
    // 0xb0e210: r0 = AllocateDouble()
    //     0xb0e210: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e214: mov             x1, x0
    // 0xb0e218: RestoreReg r0
    //     0xb0e218: ldr             x0, [SP], #8
    // 0xb0e21c: ldp             q1, q2, [SP], #0x20
    // 0xb0e220: b               #0xb0e184
    // 0xb0e224: SaveReg d2
    //     0xb0e224: str             q2, [SP, #-0x10]!
    // 0xb0e228: stp             x0, x1, [SP, #-0x10]!
    // 0xb0e22c: r0 = AllocateDouble()
    //     0xb0e22c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0e230: mov             x2, x0
    // 0xb0e234: ldp             x0, x1, [SP], #0x10
    // 0xb0e238: RestoreReg d2
    //     0xb0e238: ldr             q2, [SP], #0x10
    // 0xb0e23c: b               #0xb0e1ac
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbefd44, size: 0x808
    // 0xbefd44: EnterFrame
    //     0xbefd44: stp             fp, lr, [SP, #-0x10]!
    //     0xbefd48: mov             fp, SP
    // 0xbefd4c: AllocStack(0x40)
    //     0xbefd4c: sub             SP, SP, #0x40
    // 0xbefd50: CheckStackOverflow
    //     0xbefd50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbefd54: cmp             SP, x16
    //     0xbefd58: b.ls            #0xbf0418
    // 0xbefd5c: ldr             x0, [fp, #0x20]
    // 0xbefd60: cmp             w0, NULL
    // 0xbefd64: b.ne            #0xbefd84
    // 0xbefd68: ldr             x1, [fp, #0x18]
    // 0xbefd6c: cmp             w1, NULL
    // 0xbefd70: b.ne            #0xbefd88
    // 0xbefd74: r0 = Null
    //     0xbefd74: mov             x0, NULL
    // 0xbefd78: LeaveFrame
    //     0xbefd78: mov             SP, fp
    //     0xbefd7c: ldp             fp, lr, [SP], #0x10
    // 0xbefd80: ret
    //     0xbefd80: ret             
    // 0xbefd84: ldr             x1, [fp, #0x18]
    // 0xbefd88: cmp             w0, NULL
    // 0xbefd8c: b.ne            #0xbefed4
    // 0xbefd90: cmp             w1, NULL
    // 0xbefd94: b.eq            #0xbf0420
    // 0xbefd98: r0 = LoadClassIdInstr(r1)
    //     0xbefd98: ldur            x0, [x1, #-1]
    //     0xbefd9c: ubfx            x0, x0, #0xc, #0x14
    // 0xbefda0: lsl             x0, x0, #1
    // 0xbefda4: r17 = 4234
    //     0xbefda4: mov             x17, #0x108a
    // 0xbefda8: cmp             w0, w17
    // 0xbefdac: b.ne            #0xbefdf8
    // 0xbefdb0: ldr             d0, [fp, #0x10]
    // 0xbefdb4: LoadField: d1 = r1->field_7
    //     0xbefdb4: ldur            d1, [x1, #7]
    // 0xbefdb8: fmul            d2, d1, d0
    // 0xbefdbc: stur            d2, [fp, #-0x40]
    // 0xbefdc0: LoadField: d1 = r1->field_f
    //     0xbefdc0: ldur            d1, [x1, #0xf]
    // 0xbefdc4: fmul            d3, d1, d0
    // 0xbefdc8: stur            d3, [fp, #-0x38]
    // 0xbefdcc: LoadField: d1 = r1->field_17
    //     0xbefdcc: ldur            d1, [x1, #0x17]
    // 0xbefdd0: fmul            d4, d1, d0
    // 0xbefdd4: stur            d4, [fp, #-0x30]
    // 0xbefdd8: r0 = _MixedAlignment()
    //     0xbefdd8: bl              #0x625c88  ; Allocate_MixedAlignmentStub -> _MixedAlignment (size=0x20)
    // 0xbefddc: ldur            d0, [fp, #-0x40]
    // 0xbefde0: StoreField: r0->field_7 = d0
    //     0xbefde0: stur            d0, [x0, #7]
    // 0xbefde4: ldur            d0, [fp, #-0x38]
    // 0xbefde8: StoreField: r0->field_f = d0
    //     0xbefde8: stur            d0, [x0, #0xf]
    // 0xbefdec: ldur            d0, [fp, #-0x30]
    // 0xbefdf0: StoreField: r0->field_17 = d0
    //     0xbefdf0: stur            d0, [x0, #0x17]
    // 0xbefdf4: b               #0xbefec8
    // 0xbefdf8: ldr             d0, [fp, #0x10]
    // 0xbefdfc: r17 = 4236
    //     0xbefdfc: mov             x17, #0x108c
    // 0xbefe00: cmp             w0, w17
    // 0xbefe04: b.ne            #0xbefe38
    // 0xbefe08: LoadField: d1 = r1->field_7
    //     0xbefe08: ldur            d1, [x1, #7]
    // 0xbefe0c: fmul            d2, d1, d0
    // 0xbefe10: stur            d2, [fp, #-0x38]
    // 0xbefe14: LoadField: d1 = r1->field_f
    //     0xbefe14: ldur            d1, [x1, #0xf]
    // 0xbefe18: fmul            d3, d1, d0
    // 0xbefe1c: stur            d3, [fp, #-0x30]
    // 0xbefe20: r0 = AlignmentDirectional()
    //     0xbefe20: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xbefe24: ldur            d0, [fp, #-0x38]
    // 0xbefe28: StoreField: r0->field_7 = d0
    //     0xbefe28: stur            d0, [x0, #7]
    // 0xbefe2c: ldur            d0, [fp, #-0x30]
    // 0xbefe30: StoreField: r0->field_f = d0
    //     0xbefe30: stur            d0, [x0, #0xf]
    // 0xbefe34: b               #0xbefec8
    // 0xbefe38: r17 = 4238
    //     0xbefe38: mov             x17, #0x108e
    // 0xbefe3c: cmp             w0, w17
    // 0xbefe40: b.ne            #0xbefe74
    // 0xbefe44: LoadField: d1 = r1->field_7
    //     0xbefe44: ldur            d1, [x1, #7]
    // 0xbefe48: fmul            d2, d1, d0
    // 0xbefe4c: stur            d2, [fp, #-0x38]
    // 0xbefe50: LoadField: d1 = r1->field_f
    //     0xbefe50: ldur            d1, [x1, #0xf]
    // 0xbefe54: fmul            d3, d1, d0
    // 0xbefe58: stur            d3, [fp, #-0x30]
    // 0xbefe5c: r0 = Alignment()
    //     0xbefe5c: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xbefe60: ldur            d0, [fp, #-0x38]
    // 0xbefe64: StoreField: r0->field_7 = d0
    //     0xbefe64: stur            d0, [x0, #7]
    // 0xbefe68: ldur            d0, [fp, #-0x30]
    // 0xbefe6c: StoreField: r0->field_f = d0
    //     0xbefe6c: stur            d0, [x0, #0xf]
    // 0xbefe70: b               #0xbefec8
    // 0xbefe74: d2 = 1.000000
    //     0xbefe74: fmov            d2, #1.00000000
    // 0xbefe78: d1 = 2.000000
    //     0xbefe78: fmov            d1, #2.00000000
    // 0xbefe7c: LoadField: d3 = r1->field_7
    //     0xbefe7c: ldur            d3, [x1, #7]
    // 0xbefe80: fadd            d4, d3, d2
    // 0xbefe84: fdiv            d3, d4, d1
    // 0xbefe88: fmul            d4, d3, d0
    // 0xbefe8c: LoadField: d3 = r1->field_f
    //     0xbefe8c: ldur            d3, [x1, #0xf]
    // 0xbefe90: fadd            d5, d3, d2
    // 0xbefe94: fdiv            d3, d5, d1
    // 0xbefe98: fmul            d5, d3, d0
    // 0xbefe9c: fmul            d0, d4, d1
    // 0xbefea0: fsub            d3, d0, d2
    // 0xbefea4: stur            d3, [fp, #-0x38]
    // 0xbefea8: fmul            d0, d5, d1
    // 0xbefeac: fsub            d1, d0, d2
    // 0xbefeb0: stur            d1, [fp, #-0x30]
    // 0xbefeb4: r0 = FractionalOffset()
    //     0xbefeb4: bl              #0xade670  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0xbefeb8: ldur            d0, [fp, #-0x38]
    // 0xbefebc: StoreField: r0->field_7 = d0
    //     0xbefebc: stur            d0, [x0, #7]
    // 0xbefec0: ldur            d0, [fp, #-0x30]
    // 0xbefec4: StoreField: r0->field_f = d0
    //     0xbefec4: stur            d0, [x0, #0xf]
    // 0xbefec8: LeaveFrame
    //     0xbefec8: mov             SP, fp
    //     0xbefecc: ldp             fp, lr, [SP], #0x10
    // 0xbefed0: ret
    //     0xbefed0: ret             
    // 0xbefed4: ldr             d0, [fp, #0x10]
    // 0xbefed8: d2 = 1.000000
    //     0xbefed8: fmov            d2, #1.00000000
    // 0xbefedc: d1 = 2.000000
    //     0xbefedc: fmov            d1, #2.00000000
    // 0xbefee0: cmp             w1, NULL
    // 0xbefee4: b.ne            #0xbf0018
    // 0xbefee8: fsub            d3, d2, d0
    // 0xbefeec: r1 = LoadClassIdInstr(r0)
    //     0xbefeec: ldur            x1, [x0, #-1]
    //     0xbefef0: ubfx            x1, x1, #0xc, #0x14
    // 0xbefef4: lsl             x1, x1, #1
    // 0xbefef8: r17 = 4234
    //     0xbefef8: mov             x17, #0x108a
    // 0xbefefc: cmp             w1, w17
    // 0xbeff00: b.ne            #0xbeff48
    // 0xbeff04: LoadField: d0 = r0->field_7
    //     0xbeff04: ldur            d0, [x0, #7]
    // 0xbeff08: fmul            d1, d0, d3
    // 0xbeff0c: stur            d1, [fp, #-0x40]
    // 0xbeff10: LoadField: d0 = r0->field_f
    //     0xbeff10: ldur            d0, [x0, #0xf]
    // 0xbeff14: fmul            d2, d0, d3
    // 0xbeff18: stur            d2, [fp, #-0x38]
    // 0xbeff1c: LoadField: d0 = r0->field_17
    //     0xbeff1c: ldur            d0, [x0, #0x17]
    // 0xbeff20: fmul            d4, d0, d3
    // 0xbeff24: stur            d4, [fp, #-0x30]
    // 0xbeff28: r0 = _MixedAlignment()
    //     0xbeff28: bl              #0x625c88  ; Allocate_MixedAlignmentStub -> _MixedAlignment (size=0x20)
    // 0xbeff2c: ldur            d0, [fp, #-0x40]
    // 0xbeff30: StoreField: r0->field_7 = d0
    //     0xbeff30: stur            d0, [x0, #7]
    // 0xbeff34: ldur            d0, [fp, #-0x38]
    // 0xbeff38: StoreField: r0->field_f = d0
    //     0xbeff38: stur            d0, [x0, #0xf]
    // 0xbeff3c: ldur            d0, [fp, #-0x30]
    // 0xbeff40: StoreField: r0->field_17 = d0
    //     0xbeff40: stur            d0, [x0, #0x17]
    // 0xbeff44: b               #0xbf000c
    // 0xbeff48: r17 = 4236
    //     0xbeff48: mov             x17, #0x108c
    // 0xbeff4c: cmp             w1, w17
    // 0xbeff50: b.ne            #0xbeff84
    // 0xbeff54: LoadField: d0 = r0->field_7
    //     0xbeff54: ldur            d0, [x0, #7]
    // 0xbeff58: fmul            d1, d0, d3
    // 0xbeff5c: stur            d1, [fp, #-0x38]
    // 0xbeff60: LoadField: d0 = r0->field_f
    //     0xbeff60: ldur            d0, [x0, #0xf]
    // 0xbeff64: fmul            d2, d0, d3
    // 0xbeff68: stur            d2, [fp, #-0x30]
    // 0xbeff6c: r0 = AlignmentDirectional()
    //     0xbeff6c: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xbeff70: ldur            d0, [fp, #-0x38]
    // 0xbeff74: StoreField: r0->field_7 = d0
    //     0xbeff74: stur            d0, [x0, #7]
    // 0xbeff78: ldur            d0, [fp, #-0x30]
    // 0xbeff7c: StoreField: r0->field_f = d0
    //     0xbeff7c: stur            d0, [x0, #0xf]
    // 0xbeff80: b               #0xbf000c
    // 0xbeff84: r17 = 4238
    //     0xbeff84: mov             x17, #0x108e
    // 0xbeff88: cmp             w1, w17
    // 0xbeff8c: b.ne            #0xbeffc0
    // 0xbeff90: LoadField: d0 = r0->field_7
    //     0xbeff90: ldur            d0, [x0, #7]
    // 0xbeff94: fmul            d1, d0, d3
    // 0xbeff98: stur            d1, [fp, #-0x38]
    // 0xbeff9c: LoadField: d0 = r0->field_f
    //     0xbeff9c: ldur            d0, [x0, #0xf]
    // 0xbeffa0: fmul            d2, d0, d3
    // 0xbeffa4: stur            d2, [fp, #-0x30]
    // 0xbeffa8: r0 = Alignment()
    //     0xbeffa8: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xbeffac: ldur            d0, [fp, #-0x38]
    // 0xbeffb0: StoreField: r0->field_7 = d0
    //     0xbeffb0: stur            d0, [x0, #7]
    // 0xbeffb4: ldur            d0, [fp, #-0x30]
    // 0xbeffb8: StoreField: r0->field_f = d0
    //     0xbeffb8: stur            d0, [x0, #0xf]
    // 0xbeffbc: b               #0xbf000c
    // 0xbeffc0: LoadField: d0 = r0->field_7
    //     0xbeffc0: ldur            d0, [x0, #7]
    // 0xbeffc4: fadd            d4, d0, d2
    // 0xbeffc8: fdiv            d0, d4, d1
    // 0xbeffcc: fmul            d4, d0, d3
    // 0xbeffd0: LoadField: d0 = r0->field_f
    //     0xbeffd0: ldur            d0, [x0, #0xf]
    // 0xbeffd4: fadd            d5, d0, d2
    // 0xbeffd8: fdiv            d0, d5, d1
    // 0xbeffdc: fmul            d5, d0, d3
    // 0xbeffe0: fmul            d0, d4, d1
    // 0xbeffe4: fsub            d3, d0, d2
    // 0xbeffe8: stur            d3, [fp, #-0x38]
    // 0xbeffec: fmul            d0, d5, d1
    // 0xbefff0: fsub            d1, d0, d2
    // 0xbefff4: stur            d1, [fp, #-0x30]
    // 0xbefff8: r0 = FractionalOffset()
    //     0xbefff8: bl              #0xade670  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0xbefffc: ldur            d0, [fp, #-0x38]
    // 0xbf0000: StoreField: r0->field_7 = d0
    //     0xbf0000: stur            d0, [x0, #7]
    // 0xbf0004: ldur            d0, [fp, #-0x30]
    // 0xbf0008: StoreField: r0->field_f = d0
    //     0xbf0008: stur            d0, [x0, #0xf]
    // 0xbf000c: LeaveFrame
    //     0xbf000c: mov             SP, fp
    //     0xbf0010: ldp             fp, lr, [SP], #0x10
    // 0xbf0014: ret
    //     0xbf0014: ret             
    // 0xbf0018: r2 = LoadClassIdInstr(r0)
    //     0xbf0018: ldur            x2, [x0, #-1]
    //     0xbf001c: ubfx            x2, x2, #0xc, #0x14
    // 0xbf0020: lsl             x2, x2, #1
    // 0xbf0024: stur            x2, [fp, #-0x18]
    // 0xbf0028: r3 = LoadInt32Instr(r2)
    //     0xbf0028: sbfx            x3, x2, #1, #0x1f
    // 0xbf002c: cmp             x3, #0x847
    // 0xbf0030: b.lt            #0xbf0078
    // 0xbf0034: cmp             x3, #0x848
    // 0xbf0038: b.gt            #0xbf0078
    // 0xbf003c: r3 = LoadClassIdInstr(r1)
    //     0xbf003c: ldur            x3, [x1, #-1]
    //     0xbf0040: ubfx            x3, x3, #0xc, #0x14
    // 0xbf0044: lsl             x3, x3, #1
    // 0xbf0048: r4 = LoadInt32Instr(r3)
    //     0xbf0048: sbfx            x4, x3, #1, #0x1f
    // 0xbf004c: cmp             x4, #0x847
    // 0xbf0050: b.lt            #0xbf0078
    // 0xbf0054: cmp             x4, #0x848
    // 0xbf0058: b.gt            #0xbf0078
    // 0xbf005c: stp             x1, x0, [SP, #-0x10]!
    // 0xbf0060: SaveReg d0
    //     0xbf0060: str             d0, [SP, #-8]!
    // 0xbf0064: r0 = lerp()
    //     0xbf0064: bl              #0xbf0a64  ; [package:flutter/src/painting/alignment.dart] Alignment::lerp
    // 0xbf0068: add             SP, SP, #0x18
    // 0xbf006c: LeaveFrame
    //     0xbf006c: mov             SP, fp
    //     0xbf0070: ldp             fp, lr, [SP], #0x10
    // 0xbf0074: ret
    //     0xbf0074: ret             
    // 0xbf0078: r17 = 4236
    //     0xbf0078: mov             x17, #0x108c
    // 0xbf007c: cmp             w2, w17
    // 0xbf0080: b.ne            #0xbf00b8
    // 0xbf0084: r3 = LoadClassIdInstr(r1)
    //     0xbf0084: ldur            x3, [x1, #-1]
    //     0xbf0088: ubfx            x3, x3, #0xc, #0x14
    // 0xbf008c: lsl             x3, x3, #1
    // 0xbf0090: r17 = 4236
    //     0xbf0090: mov             x17, #0x108c
    // 0xbf0094: cmp             w3, w17
    // 0xbf0098: b.ne            #0xbf00b8
    // 0xbf009c: stp             x1, x0, [SP, #-0x10]!
    // 0xbf00a0: SaveReg d0
    //     0xbf00a0: str             d0, [SP, #-8]!
    // 0xbf00a4: r0 = lerp()
    //     0xbf00a4: bl              #0xbf054c  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::lerp
    // 0xbf00a8: add             SP, SP, #0x18
    // 0xbf00ac: LeaveFrame
    //     0xbf00ac: mov             SP, fp
    //     0xbf00b0: ldp             fp, lr, [SP], #0x10
    // 0xbf00b4: ret
    //     0xbf00b4: ret             
    // 0xbf00b8: r17 = 4240
    //     0xbf00b8: mov             x17, #0x1090
    // 0xbf00bc: cmp             w2, w17
    // 0xbf00c0: b.gt            #0xbf00d8
    // 0xbf00c4: r17 = 4238
    //     0xbf00c4: mov             x17, #0x108e
    // 0xbf00c8: cmp             w2, w17
    // 0xbf00cc: b.lt            #0xbf00d8
    // 0xbf00d0: LoadField: d1 = r0->field_7
    //     0xbf00d0: ldur            d1, [x0, #7]
    // 0xbf00d4: b               #0xbf00f0
    // 0xbf00d8: r17 = 4234
    //     0xbf00d8: mov             x17, #0x108a
    // 0xbf00dc: cmp             w2, w17
    // 0xbf00e0: b.ne            #0xbf00ec
    // 0xbf00e4: LoadField: d1 = r0->field_7
    //     0xbf00e4: ldur            d1, [x0, #7]
    // 0xbf00e8: b               #0xbf00f0
    // 0xbf00ec: d1 = 0.000000
    //     0xbf00ec: eor             v1.16b, v1.16b, v1.16b
    // 0xbf00f0: r3 = LoadClassIdInstr(r1)
    //     0xbf00f0: ldur            x3, [x1, #-1]
    //     0xbf00f4: ubfx            x3, x3, #0xc, #0x14
    // 0xbf00f8: lsl             x3, x3, #1
    // 0xbf00fc: stur            x3, [fp, #-0x10]
    // 0xbf0100: r17 = 4240
    //     0xbf0100: mov             x17, #0x1090
    // 0xbf0104: cmp             w3, w17
    // 0xbf0108: b.gt            #0xbf0120
    // 0xbf010c: r17 = 4238
    //     0xbf010c: mov             x17, #0x108e
    // 0xbf0110: cmp             w3, w17
    // 0xbf0114: b.lt            #0xbf0120
    // 0xbf0118: LoadField: d2 = r1->field_7
    //     0xbf0118: ldur            d2, [x1, #7]
    // 0xbf011c: b               #0xbf0138
    // 0xbf0120: r17 = 4234
    //     0xbf0120: mov             x17, #0x108a
    // 0xbf0124: cmp             w3, w17
    // 0xbf0128: b.ne            #0xbf0134
    // 0xbf012c: LoadField: d2 = r1->field_7
    //     0xbf012c: ldur            d2, [x1, #7]
    // 0xbf0130: b               #0xbf0138
    // 0xbf0134: d2 = 0.000000
    //     0xbf0134: eor             v2.16b, v2.16b, v2.16b
    // 0xbf0138: r4 = inline_Allocate_Double()
    //     0xbf0138: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf013c: add             x4, x4, #0x10
    //     0xbf0140: cmp             x5, x4
    //     0xbf0144: b.ls            #0xbf0424
    //     0xbf0148: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf014c: sub             x4, x4, #0xf
    //     0xbf0150: mov             x5, #0xd108
    //     0xbf0154: movk            x5, #3, lsl #16
    //     0xbf0158: stur            x5, [x4, #-1]
    // 0xbf015c: StoreField: r4->field_7 = d0
    //     0xbf015c: stur            d0, [x4, #7]
    // 0xbf0160: stur            x4, [fp, #-8]
    // 0xbf0164: r5 = inline_Allocate_Double()
    //     0xbf0164: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf0168: add             x5, x5, #0x10
    //     0xbf016c: cmp             x6, x5
    //     0xbf0170: b.ls            #0xbf0450
    //     0xbf0174: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf0178: sub             x5, x5, #0xf
    //     0xbf017c: mov             x6, #0xd108
    //     0xbf0180: movk            x6, #3, lsl #16
    //     0xbf0184: stur            x6, [x5, #-1]
    // 0xbf0188: StoreField: r5->field_7 = d1
    //     0xbf0188: stur            d1, [x5, #7]
    // 0xbf018c: r6 = inline_Allocate_Double()
    //     0xbf018c: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xbf0190: add             x6, x6, #0x10
    //     0xbf0194: cmp             x7, x6
    //     0xbf0198: b.ls            #0xbf047c
    //     0xbf019c: str             x6, [THR, #0x60]  ; THR::top
    //     0xbf01a0: sub             x6, x6, #0xf
    //     0xbf01a4: mov             x7, #0xd108
    //     0xbf01a8: movk            x7, #3, lsl #16
    //     0xbf01ac: stur            x7, [x6, #-1]
    // 0xbf01b0: StoreField: r6->field_7 = d2
    //     0xbf01b0: stur            d2, [x6, #7]
    // 0xbf01b4: stp             x6, x5, [SP, #-0x10]!
    // 0xbf01b8: SaveReg r4
    //     0xbf01b8: str             x4, [SP, #-8]!
    // 0xbf01bc: r0 = lerpDouble()
    //     0xbf01bc: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf01c0: add             SP, SP, #0x18
    // 0xbf01c4: stur            x0, [fp, #-0x20]
    // 0xbf01c8: cmp             w0, NULL
    // 0xbf01cc: b.eq            #0xbf04a8
    // 0xbf01d0: ldur            x1, [fp, #-0x18]
    // 0xbf01d4: r17 = 4240
    //     0xbf01d4: mov             x17, #0x1090
    // 0xbf01d8: cmp             w1, w17
    // 0xbf01dc: b.gt            #0xbf01f8
    // 0xbf01e0: r17 = 4238
    //     0xbf01e0: mov             x17, #0x108e
    // 0xbf01e4: cmp             w1, w17
    // 0xbf01e8: b.lt            #0xbf01f8
    // 0xbf01ec: ldr             x2, [fp, #0x20]
    // 0xbf01f0: d0 = 0.000000
    //     0xbf01f0: eor             v0.16b, v0.16b, v0.16b
    // 0xbf01f4: b               #0xbf0218
    // 0xbf01f8: r17 = 4234
    //     0xbf01f8: mov             x17, #0x108a
    // 0xbf01fc: cmp             w1, w17
    // 0xbf0200: b.ne            #0xbf0210
    // 0xbf0204: ldr             x2, [fp, #0x20]
    // 0xbf0208: LoadField: d0 = r2->field_f
    //     0xbf0208: ldur            d0, [x2, #0xf]
    // 0xbf020c: b               #0xbf0218
    // 0xbf0210: ldr             x2, [fp, #0x20]
    // 0xbf0214: LoadField: d0 = r2->field_7
    //     0xbf0214: ldur            d0, [x2, #7]
    // 0xbf0218: ldur            x3, [fp, #-0x10]
    // 0xbf021c: r17 = 4240
    //     0xbf021c: mov             x17, #0x1090
    // 0xbf0220: cmp             w3, w17
    // 0xbf0224: b.gt            #0xbf0240
    // 0xbf0228: r17 = 4238
    //     0xbf0228: mov             x17, #0x108e
    // 0xbf022c: cmp             w3, w17
    // 0xbf0230: b.lt            #0xbf0240
    // 0xbf0234: ldr             x4, [fp, #0x18]
    // 0xbf0238: d1 = 0.000000
    //     0xbf0238: eor             v1.16b, v1.16b, v1.16b
    // 0xbf023c: b               #0xbf0260
    // 0xbf0240: r17 = 4234
    //     0xbf0240: mov             x17, #0x108a
    // 0xbf0244: cmp             w3, w17
    // 0xbf0248: b.ne            #0xbf0258
    // 0xbf024c: ldr             x4, [fp, #0x18]
    // 0xbf0250: LoadField: d1 = r4->field_f
    //     0xbf0250: ldur            d1, [x4, #0xf]
    // 0xbf0254: b               #0xbf0260
    // 0xbf0258: ldr             x4, [fp, #0x18]
    // 0xbf025c: LoadField: d1 = r4->field_7
    //     0xbf025c: ldur            d1, [x4, #7]
    // 0xbf0260: r5 = inline_Allocate_Double()
    //     0xbf0260: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf0264: add             x5, x5, #0x10
    //     0xbf0268: cmp             x6, x5
    //     0xbf026c: b.ls            #0xbf04ac
    //     0xbf0270: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf0274: sub             x5, x5, #0xf
    //     0xbf0278: mov             x6, #0xd108
    //     0xbf027c: movk            x6, #3, lsl #16
    //     0xbf0280: stur            x6, [x5, #-1]
    // 0xbf0284: StoreField: r5->field_7 = d0
    //     0xbf0284: stur            d0, [x5, #7]
    // 0xbf0288: r6 = inline_Allocate_Double()
    //     0xbf0288: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xbf028c: add             x6, x6, #0x10
    //     0xbf0290: cmp             x7, x6
    //     0xbf0294: b.ls            #0xbf04d8
    //     0xbf0298: str             x6, [THR, #0x60]  ; THR::top
    //     0xbf029c: sub             x6, x6, #0xf
    //     0xbf02a0: mov             x7, #0xd108
    //     0xbf02a4: movk            x7, #3, lsl #16
    //     0xbf02a8: stur            x7, [x6, #-1]
    // 0xbf02ac: StoreField: r6->field_7 = d1
    //     0xbf02ac: stur            d1, [x6, #7]
    // 0xbf02b0: stp             x6, x5, [SP, #-0x10]!
    // 0xbf02b4: ldur            x16, [fp, #-8]
    // 0xbf02b8: SaveReg r16
    //     0xbf02b8: str             x16, [SP, #-8]!
    // 0xbf02bc: r0 = lerpDouble()
    //     0xbf02bc: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf02c0: add             SP, SP, #0x18
    // 0xbf02c4: stur            x0, [fp, #-0x28]
    // 0xbf02c8: cmp             w0, NULL
    // 0xbf02cc: b.eq            #0xbf0504
    // 0xbf02d0: ldur            x1, [fp, #-0x18]
    // 0xbf02d4: r17 = 4240
    //     0xbf02d4: mov             x17, #0x1090
    // 0xbf02d8: cmp             w1, w17
    // 0xbf02dc: b.gt            #0xbf0300
    // 0xbf02e0: r17 = 4238
    //     0xbf02e0: mov             x17, #0x108e
    // 0xbf02e4: cmp             w1, w17
    // 0xbf02e8: b.lt            #0xbf02f8
    // 0xbf02ec: ldr             x2, [fp, #0x20]
    // 0xbf02f0: LoadField: d0 = r2->field_f
    //     0xbf02f0: ldur            d0, [x2, #0xf]
    // 0xbf02f4: b               #0xbf031c
    // 0xbf02f8: ldr             x2, [fp, #0x20]
    // 0xbf02fc: b               #0xbf0304
    // 0xbf0300: ldr             x2, [fp, #0x20]
    // 0xbf0304: r17 = 4234
    //     0xbf0304: mov             x17, #0x108a
    // 0xbf0308: cmp             w1, w17
    // 0xbf030c: b.ne            #0xbf0318
    // 0xbf0310: LoadField: d0 = r2->field_17
    //     0xbf0310: ldur            d0, [x2, #0x17]
    // 0xbf0314: b               #0xbf031c
    // 0xbf0318: LoadField: d0 = r2->field_f
    //     0xbf0318: ldur            d0, [x2, #0xf]
    // 0xbf031c: ldur            x1, [fp, #-0x10]
    // 0xbf0320: r17 = 4240
    //     0xbf0320: mov             x17, #0x1090
    // 0xbf0324: cmp             w1, w17
    // 0xbf0328: b.gt            #0xbf034c
    // 0xbf032c: r17 = 4238
    //     0xbf032c: mov             x17, #0x108e
    // 0xbf0330: cmp             w1, w17
    // 0xbf0334: b.lt            #0xbf0344
    // 0xbf0338: ldr             x2, [fp, #0x18]
    // 0xbf033c: LoadField: d1 = r2->field_f
    //     0xbf033c: ldur            d1, [x2, #0xf]
    // 0xbf0340: b               #0xbf0368
    // 0xbf0344: ldr             x2, [fp, #0x18]
    // 0xbf0348: b               #0xbf0350
    // 0xbf034c: ldr             x2, [fp, #0x18]
    // 0xbf0350: r17 = 4234
    //     0xbf0350: mov             x17, #0x108a
    // 0xbf0354: cmp             w1, w17
    // 0xbf0358: b.ne            #0xbf0364
    // 0xbf035c: LoadField: d1 = r2->field_17
    //     0xbf035c: ldur            d1, [x2, #0x17]
    // 0xbf0360: b               #0xbf0368
    // 0xbf0364: LoadField: d1 = r2->field_f
    //     0xbf0364: ldur            d1, [x2, #0xf]
    // 0xbf0368: ldur            x1, [fp, #-0x20]
    // 0xbf036c: r2 = inline_Allocate_Double()
    //     0xbf036c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf0370: add             x2, x2, #0x10
    //     0xbf0374: cmp             x3, x2
    //     0xbf0378: b.ls            #0xbf0508
    //     0xbf037c: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf0380: sub             x2, x2, #0xf
    //     0xbf0384: mov             x3, #0xd108
    //     0xbf0388: movk            x3, #3, lsl #16
    //     0xbf038c: stur            x3, [x2, #-1]
    // 0xbf0390: StoreField: r2->field_7 = d0
    //     0xbf0390: stur            d0, [x2, #7]
    // 0xbf0394: r3 = inline_Allocate_Double()
    //     0xbf0394: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf0398: add             x3, x3, #0x10
    //     0xbf039c: cmp             x4, x3
    //     0xbf03a0: b.ls            #0xbf0524
    //     0xbf03a4: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf03a8: sub             x3, x3, #0xf
    //     0xbf03ac: mov             x4, #0xd108
    //     0xbf03b0: movk            x4, #3, lsl #16
    //     0xbf03b4: stur            x4, [x3, #-1]
    // 0xbf03b8: StoreField: r3->field_7 = d1
    //     0xbf03b8: stur            d1, [x3, #7]
    // 0xbf03bc: stp             x3, x2, [SP, #-0x10]!
    // 0xbf03c0: ldur            x16, [fp, #-8]
    // 0xbf03c4: SaveReg r16
    //     0xbf03c4: str             x16, [SP, #-8]!
    // 0xbf03c8: r0 = lerpDouble()
    //     0xbf03c8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf03cc: add             SP, SP, #0x18
    // 0xbf03d0: stur            x0, [fp, #-8]
    // 0xbf03d4: cmp             w0, NULL
    // 0xbf03d8: b.eq            #0xbf0548
    // 0xbf03dc: ldur            x1, [fp, #-0x20]
    // 0xbf03e0: LoadField: d0 = r1->field_7
    //     0xbf03e0: ldur            d0, [x1, #7]
    // 0xbf03e4: stur            d0, [fp, #-0x30]
    // 0xbf03e8: r0 = _MixedAlignment()
    //     0xbf03e8: bl              #0x625c88  ; Allocate_MixedAlignmentStub -> _MixedAlignment (size=0x20)
    // 0xbf03ec: ldur            d0, [fp, #-0x30]
    // 0xbf03f0: StoreField: r0->field_7 = d0
    //     0xbf03f0: stur            d0, [x0, #7]
    // 0xbf03f4: ldur            x1, [fp, #-0x28]
    // 0xbf03f8: LoadField: d0 = r1->field_7
    //     0xbf03f8: ldur            d0, [x1, #7]
    // 0xbf03fc: StoreField: r0->field_f = d0
    //     0xbf03fc: stur            d0, [x0, #0xf]
    // 0xbf0400: ldur            x1, [fp, #-8]
    // 0xbf0404: LoadField: d0 = r1->field_7
    //     0xbf0404: ldur            d0, [x1, #7]
    // 0xbf0408: StoreField: r0->field_17 = d0
    //     0xbf0408: stur            d0, [x0, #0x17]
    // 0xbf040c: LeaveFrame
    //     0xbf040c: mov             SP, fp
    //     0xbf0410: ldp             fp, lr, [SP], #0x10
    // 0xbf0414: ret
    //     0xbf0414: ret             
    // 0xbf0418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf041c: b               #0xbefd5c
    // 0xbf0420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0420: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0424: stp             q1, q2, [SP, #-0x20]!
    // 0xbf0428: SaveReg d0
    //     0xbf0428: str             q0, [SP, #-0x10]!
    // 0xbf042c: stp             x2, x3, [SP, #-0x10]!
    // 0xbf0430: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0434: r0 = AllocateDouble()
    //     0xbf0434: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0438: mov             x4, x0
    // 0xbf043c: ldp             x0, x1, [SP], #0x10
    // 0xbf0440: ldp             x2, x3, [SP], #0x10
    // 0xbf0444: RestoreReg d0
    //     0xbf0444: ldr             q0, [SP], #0x10
    // 0xbf0448: ldp             q1, q2, [SP], #0x20
    // 0xbf044c: b               #0xbf015c
    // 0xbf0450: stp             q1, q2, [SP, #-0x20]!
    // 0xbf0454: stp             x3, x4, [SP, #-0x10]!
    // 0xbf0458: stp             x1, x2, [SP, #-0x10]!
    // 0xbf045c: SaveReg r0
    //     0xbf045c: str             x0, [SP, #-8]!
    // 0xbf0460: r0 = AllocateDouble()
    //     0xbf0460: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0464: mov             x5, x0
    // 0xbf0468: RestoreReg r0
    //     0xbf0468: ldr             x0, [SP], #8
    // 0xbf046c: ldp             x1, x2, [SP], #0x10
    // 0xbf0470: ldp             x3, x4, [SP], #0x10
    // 0xbf0474: ldp             q1, q2, [SP], #0x20
    // 0xbf0478: b               #0xbf0188
    // 0xbf047c: SaveReg d2
    //     0xbf047c: str             q2, [SP, #-0x10]!
    // 0xbf0480: stp             x4, x5, [SP, #-0x10]!
    // 0xbf0484: stp             x2, x3, [SP, #-0x10]!
    // 0xbf0488: stp             x0, x1, [SP, #-0x10]!
    // 0xbf048c: r0 = AllocateDouble()
    //     0xbf048c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0490: mov             x6, x0
    // 0xbf0494: ldp             x0, x1, [SP], #0x10
    // 0xbf0498: ldp             x2, x3, [SP], #0x10
    // 0xbf049c: ldp             x4, x5, [SP], #0x10
    // 0xbf04a0: RestoreReg d2
    //     0xbf04a0: ldr             q2, [SP], #0x10
    // 0xbf04a4: b               #0xbf01b0
    // 0xbf04a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf04a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf04ac: stp             q0, q1, [SP, #-0x20]!
    // 0xbf04b0: stp             x3, x4, [SP, #-0x10]!
    // 0xbf04b4: stp             x1, x2, [SP, #-0x10]!
    // 0xbf04b8: SaveReg r0
    //     0xbf04b8: str             x0, [SP, #-8]!
    // 0xbf04bc: r0 = AllocateDouble()
    //     0xbf04bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf04c0: mov             x5, x0
    // 0xbf04c4: RestoreReg r0
    //     0xbf04c4: ldr             x0, [SP], #8
    // 0xbf04c8: ldp             x1, x2, [SP], #0x10
    // 0xbf04cc: ldp             x3, x4, [SP], #0x10
    // 0xbf04d0: ldp             q0, q1, [SP], #0x20
    // 0xbf04d4: b               #0xbf0284
    // 0xbf04d8: SaveReg d1
    //     0xbf04d8: str             q1, [SP, #-0x10]!
    // 0xbf04dc: stp             x4, x5, [SP, #-0x10]!
    // 0xbf04e0: stp             x2, x3, [SP, #-0x10]!
    // 0xbf04e4: stp             x0, x1, [SP, #-0x10]!
    // 0xbf04e8: r0 = AllocateDouble()
    //     0xbf04e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf04ec: mov             x6, x0
    // 0xbf04f0: ldp             x0, x1, [SP], #0x10
    // 0xbf04f4: ldp             x2, x3, [SP], #0x10
    // 0xbf04f8: ldp             x4, x5, [SP], #0x10
    // 0xbf04fc: RestoreReg d1
    //     0xbf04fc: ldr             q1, [SP], #0x10
    // 0xbf0500: b               #0xbf02ac
    // 0xbf0504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0504: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0508: stp             q0, q1, [SP, #-0x20]!
    // 0xbf050c: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0510: r0 = AllocateDouble()
    //     0xbf0510: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0514: mov             x2, x0
    // 0xbf0518: ldp             x0, x1, [SP], #0x10
    // 0xbf051c: ldp             q0, q1, [SP], #0x20
    // 0xbf0520: b               #0xbf0390
    // 0xbf0524: SaveReg d1
    //     0xbf0524: str             q1, [SP, #-0x10]!
    // 0xbf0528: stp             x1, x2, [SP, #-0x10]!
    // 0xbf052c: SaveReg r0
    //     0xbf052c: str             x0, [SP, #-8]!
    // 0xbf0530: r0 = AllocateDouble()
    //     0xbf0530: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0534: mov             x3, x0
    // 0xbf0538: RestoreReg r0
    //     0xbf0538: ldr             x0, [SP], #8
    // 0xbf053c: ldp             x1, x2, [SP], #0x10
    // 0xbf0540: RestoreReg d1
    //     0xbf0540: ldr             q1, [SP], #0x10
    // 0xbf0544: b               #0xbf03b8
    // 0xbf0548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0548: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9c720, size: 0x1dc
    // 0xc9c720: ldr             x1, [SP]
    // 0xc9c724: cmp             w1, NULL
    // 0xc9c728: b.ne            #0xc9c734
    // 0xc9c72c: r0 = false
    //     0xc9c72c: add             x0, NULL, #0x30  ; false
    // 0xc9c730: ret
    //     0xc9c730: ret             
    // 0xc9c734: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9c734: mov             x2, #0x76
    //     0xc9c738: tbz             w1, #0, #0xc9c748
    //     0xc9c73c: ldur            x2, [x1, #-1]
    //     0xc9c740: ubfx            x2, x2, #0xc, #0x14
    //     0xc9c744: lsl             x2, x2, #1
    // 0xc9c748: r3 = LoadInt32Instr(r2)
    //     0xc9c748: sbfx            x3, x2, #1, #0x1f
    // 0xc9c74c: cmp             x3, #0x845
    // 0xc9c750: b.lt            #0xc9c8f4
    // 0xc9c754: cmp             x3, #0x848
    // 0xc9c758: b.gt            #0xc9c8f4
    // 0xc9c75c: r17 = 4240
    //     0xc9c75c: mov             x17, #0x1090
    // 0xc9c760: cmp             w2, w17
    // 0xc9c764: b.gt            #0xc9c77c
    // 0xc9c768: r17 = 4238
    //     0xc9c768: mov             x17, #0x108e
    // 0xc9c76c: cmp             w2, w17
    // 0xc9c770: b.lt            #0xc9c77c
    // 0xc9c774: LoadField: d0 = r1->field_7
    //     0xc9c774: ldur            d0, [x1, #7]
    // 0xc9c778: b               #0xc9c794
    // 0xc9c77c: r17 = 4234
    //     0xc9c77c: mov             x17, #0x108a
    // 0xc9c780: cmp             w2, w17
    // 0xc9c784: b.ne            #0xc9c790
    // 0xc9c788: LoadField: d0 = r1->field_7
    //     0xc9c788: ldur            d0, [x1, #7]
    // 0xc9c78c: b               #0xc9c794
    // 0xc9c790: d0 = 0.000000
    //     0xc9c790: eor             v0.16b, v0.16b, v0.16b
    // 0xc9c794: ldr             x3, [SP, #8]
    // 0xc9c798: r4 = LoadClassIdInstr(r3)
    //     0xc9c798: ldur            x4, [x3, #-1]
    //     0xc9c79c: ubfx            x4, x4, #0xc, #0x14
    // 0xc9c7a0: lsl             x4, x4, #1
    // 0xc9c7a4: r17 = 4240
    //     0xc9c7a4: mov             x17, #0x1090
    // 0xc9c7a8: cmp             w4, w17
    // 0xc9c7ac: b.gt            #0xc9c7c4
    // 0xc9c7b0: r17 = 4238
    //     0xc9c7b0: mov             x17, #0x108e
    // 0xc9c7b4: cmp             w4, w17
    // 0xc9c7b8: b.lt            #0xc9c7c4
    // 0xc9c7bc: LoadField: d1 = r3->field_7
    //     0xc9c7bc: ldur            d1, [x3, #7]
    // 0xc9c7c0: b               #0xc9c7dc
    // 0xc9c7c4: r17 = 4234
    //     0xc9c7c4: mov             x17, #0x108a
    // 0xc9c7c8: cmp             w4, w17
    // 0xc9c7cc: b.ne            #0xc9c7d8
    // 0xc9c7d0: LoadField: d1 = r3->field_7
    //     0xc9c7d0: ldur            d1, [x3, #7]
    // 0xc9c7d4: b               #0xc9c7dc
    // 0xc9c7d8: d1 = 0.000000
    //     0xc9c7d8: eor             v1.16b, v1.16b, v1.16b
    // 0xc9c7dc: fcmp            d0, d1
    // 0xc9c7e0: b.vs            #0xc9c8f4
    // 0xc9c7e4: b.ne            #0xc9c8f4
    // 0xc9c7e8: r17 = 4240
    //     0xc9c7e8: mov             x17, #0x1090
    // 0xc9c7ec: cmp             w2, w17
    // 0xc9c7f0: b.gt            #0xc9c808
    // 0xc9c7f4: r17 = 4238
    //     0xc9c7f4: mov             x17, #0x108e
    // 0xc9c7f8: cmp             w2, w17
    // 0xc9c7fc: b.lt            #0xc9c808
    // 0xc9c800: d0 = 0.000000
    //     0xc9c800: eor             v0.16b, v0.16b, v0.16b
    // 0xc9c804: b               #0xc9c820
    // 0xc9c808: r17 = 4234
    //     0xc9c808: mov             x17, #0x108a
    // 0xc9c80c: cmp             w2, w17
    // 0xc9c810: b.ne            #0xc9c81c
    // 0xc9c814: LoadField: d0 = r1->field_f
    //     0xc9c814: ldur            d0, [x1, #0xf]
    // 0xc9c818: b               #0xc9c820
    // 0xc9c81c: LoadField: d0 = r1->field_7
    //     0xc9c81c: ldur            d0, [x1, #7]
    // 0xc9c820: r17 = 4240
    //     0xc9c820: mov             x17, #0x1090
    // 0xc9c824: cmp             w4, w17
    // 0xc9c828: b.gt            #0xc9c840
    // 0xc9c82c: r17 = 4238
    //     0xc9c82c: mov             x17, #0x108e
    // 0xc9c830: cmp             w4, w17
    // 0xc9c834: b.lt            #0xc9c840
    // 0xc9c838: d1 = 0.000000
    //     0xc9c838: eor             v1.16b, v1.16b, v1.16b
    // 0xc9c83c: b               #0xc9c858
    // 0xc9c840: r17 = 4234
    //     0xc9c840: mov             x17, #0x108a
    // 0xc9c844: cmp             w4, w17
    // 0xc9c848: b.ne            #0xc9c854
    // 0xc9c84c: LoadField: d1 = r3->field_f
    //     0xc9c84c: ldur            d1, [x3, #0xf]
    // 0xc9c850: b               #0xc9c858
    // 0xc9c854: LoadField: d1 = r3->field_7
    //     0xc9c854: ldur            d1, [x3, #7]
    // 0xc9c858: fcmp            d0, d1
    // 0xc9c85c: b.vs            #0xc9c8f4
    // 0xc9c860: b.ne            #0xc9c8f4
    // 0xc9c864: r17 = 4240
    //     0xc9c864: mov             x17, #0x1090
    // 0xc9c868: cmp             w2, w17
    // 0xc9c86c: b.gt            #0xc9c884
    // 0xc9c870: r17 = 4238
    //     0xc9c870: mov             x17, #0x108e
    // 0xc9c874: cmp             w2, w17
    // 0xc9c878: b.lt            #0xc9c884
    // 0xc9c87c: LoadField: d0 = r1->field_f
    //     0xc9c87c: ldur            d0, [x1, #0xf]
    // 0xc9c880: b               #0xc9c89c
    // 0xc9c884: r17 = 4234
    //     0xc9c884: mov             x17, #0x108a
    // 0xc9c888: cmp             w2, w17
    // 0xc9c88c: b.ne            #0xc9c898
    // 0xc9c890: LoadField: d0 = r1->field_17
    //     0xc9c890: ldur            d0, [x1, #0x17]
    // 0xc9c894: b               #0xc9c89c
    // 0xc9c898: LoadField: d0 = r1->field_f
    //     0xc9c898: ldur            d0, [x1, #0xf]
    // 0xc9c89c: r17 = 4240
    //     0xc9c89c: mov             x17, #0x1090
    // 0xc9c8a0: cmp             w4, w17
    // 0xc9c8a4: b.gt            #0xc9c8bc
    // 0xc9c8a8: r17 = 4238
    //     0xc9c8a8: mov             x17, #0x108e
    // 0xc9c8ac: cmp             w4, w17
    // 0xc9c8b0: b.lt            #0xc9c8bc
    // 0xc9c8b4: LoadField: d1 = r3->field_f
    //     0xc9c8b4: ldur            d1, [x3, #0xf]
    // 0xc9c8b8: b               #0xc9c8d4
    // 0xc9c8bc: r17 = 4234
    //     0xc9c8bc: mov             x17, #0x108a
    // 0xc9c8c0: cmp             w4, w17
    // 0xc9c8c4: b.ne            #0xc9c8d0
    // 0xc9c8c8: LoadField: d1 = r3->field_17
    //     0xc9c8c8: ldur            d1, [x3, #0x17]
    // 0xc9c8cc: b               #0xc9c8d4
    // 0xc9c8d0: LoadField: d1 = r3->field_f
    //     0xc9c8d0: ldur            d1, [x3, #0xf]
    // 0xc9c8d4: fcmp            d0, d1
    // 0xc9c8d8: b.vs            #0xc9c8e0
    // 0xc9c8dc: b.eq            #0xc9c8e8
    // 0xc9c8e0: r1 = false
    //     0xc9c8e0: add             x1, NULL, #0x30  ; false
    // 0xc9c8e4: b               #0xc9c8ec
    // 0xc9c8e8: r1 = true
    //     0xc9c8e8: add             x1, NULL, #0x20  ; true
    // 0xc9c8ec: mov             x0, x1
    // 0xc9c8f0: b               #0xc9c8f8
    // 0xc9c8f4: r0 = false
    //     0xc9c8f4: add             x0, NULL, #0x30  ; false
    // 0xc9c8f8: ret
    //     0xc9c8f8: ret             
  }
}

// class id: 2117, size: 0x20, field offset: 0x8
//   const constructor, 
class _MixedAlignment extends AlignmentGeometry {

  _MixedAlignment /(_MixedAlignment, double) {
    // ** addr: 0x625bb4, size: 0x88
    // 0x625bb4: EnterFrame
    //     0x625bb4: stp             fp, lr, [SP, #-0x10]!
    //     0x625bb8: mov             fp, SP
    // 0x625bbc: CheckStackOverflow
    //     0x625bbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625bc0: cmp             SP, x16
    //     0x625bc4: b.ls            #0x625c1c
    // 0x625bc8: ldr             x0, [fp, #0x10]
    // 0x625bcc: r2 = Null
    //     0x625bcc: mov             x2, NULL
    // 0x625bd0: r1 = Null
    //     0x625bd0: mov             x1, NULL
    // 0x625bd4: r4 = 59
    //     0x625bd4: mov             x4, #0x3b
    // 0x625bd8: branchIfSmi(r0, 0x625be4)
    //     0x625bd8: tbz             w0, #0, #0x625be4
    // 0x625bdc: r4 = LoadClassIdInstr(r0)
    //     0x625bdc: ldur            x4, [x0, #-1]
    //     0x625be0: ubfx            x4, x4, #0xc, #0x14
    // 0x625be4: cmp             x4, #0x3d
    // 0x625be8: b.eq            #0x625bfc
    // 0x625bec: r8 = double
    //     0x625bec: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x625bf0: r3 = Null
    //     0x625bf0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b478] Null
    //     0x625bf4: ldr             x3, [x3, #0x478]
    // 0x625bf8: r0 = double()
    //     0x625bf8: bl              #0xd72bac  ; IsType_double_Stub
    // 0x625bfc: ldr             x16, [fp, #0x18]
    // 0x625c00: ldr             lr, [fp, #0x10]
    // 0x625c04: stp             lr, x16, [SP, #-0x10]!
    // 0x625c08: r0 = /()
    //     0x625c08: bl              #0x625c24  ; [package:flutter/src/painting/alignment.dart] _MixedAlignment::/
    // 0x625c0c: add             SP, SP, #0x10
    // 0x625c10: LeaveFrame
    //     0x625c10: mov             SP, fp
    //     0x625c14: ldp             fp, lr, [SP], #0x10
    // 0x625c18: ret
    //     0x625c18: ret             
    // 0x625c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625c1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x625c20: b               #0x625bc8
  }
  _MixedAlignment /(_MixedAlignment, double) {
    // ** addr: 0x625c24, size: 0x64
    // 0x625c24: EnterFrame
    //     0x625c24: stp             fp, lr, [SP, #-0x10]!
    //     0x625c28: mov             fp, SP
    // 0x625c2c: AllocStack(0x18)
    //     0x625c2c: sub             SP, SP, #0x18
    // 0x625c30: ldr             x0, [fp, #0x18]
    // 0x625c34: LoadField: d0 = r0->field_7
    //     0x625c34: ldur            d0, [x0, #7]
    // 0x625c38: ldr             x1, [fp, #0x10]
    // 0x625c3c: LoadField: d1 = r1->field_7
    //     0x625c3c: ldur            d1, [x1, #7]
    // 0x625c40: fdiv            d2, d0, d1
    // 0x625c44: stur            d2, [fp, #-0x18]
    // 0x625c48: LoadField: d0 = r0->field_f
    //     0x625c48: ldur            d0, [x0, #0xf]
    // 0x625c4c: fdiv            d3, d0, d1
    // 0x625c50: stur            d3, [fp, #-0x10]
    // 0x625c54: LoadField: d0 = r0->field_17
    //     0x625c54: ldur            d0, [x0, #0x17]
    // 0x625c58: fdiv            d4, d0, d1
    // 0x625c5c: stur            d4, [fp, #-8]
    // 0x625c60: r0 = _MixedAlignment()
    //     0x625c60: bl              #0x625c88  ; Allocate_MixedAlignmentStub -> _MixedAlignment (size=0x20)
    // 0x625c64: ldur            d0, [fp, #-0x18]
    // 0x625c68: StoreField: r0->field_7 = d0
    //     0x625c68: stur            d0, [x0, #7]
    // 0x625c6c: ldur            d0, [fp, #-0x10]
    // 0x625c70: StoreField: r0->field_f = d0
    //     0x625c70: stur            d0, [x0, #0xf]
    // 0x625c74: ldur            d0, [fp, #-8]
    // 0x625c78: StoreField: r0->field_17 = d0
    //     0x625c78: stur            d0, [x0, #0x17]
    // 0x625c7c: LeaveFrame
    //     0x625c7c: mov             SP, fp
    //     0x625c80: ldp             fp, lr, [SP], #0x10
    // 0x625c84: ret
    //     0x625c84: ret             
  }
  _MixedAlignment *(_MixedAlignment, double) {
    // ** addr: 0x625cac, size: 0x88
    // 0x625cac: EnterFrame
    //     0x625cac: stp             fp, lr, [SP, #-0x10]!
    //     0x625cb0: mov             fp, SP
    // 0x625cb4: CheckStackOverflow
    //     0x625cb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625cb8: cmp             SP, x16
    //     0x625cbc: b.ls            #0x625d14
    // 0x625cc0: ldr             x0, [fp, #0x10]
    // 0x625cc4: r2 = Null
    //     0x625cc4: mov             x2, NULL
    // 0x625cc8: r1 = Null
    //     0x625cc8: mov             x1, NULL
    // 0x625ccc: r4 = 59
    //     0x625ccc: mov             x4, #0x3b
    // 0x625cd0: branchIfSmi(r0, 0x625cdc)
    //     0x625cd0: tbz             w0, #0, #0x625cdc
    // 0x625cd4: r4 = LoadClassIdInstr(r0)
    //     0x625cd4: ldur            x4, [x0, #-1]
    //     0x625cd8: ubfx            x4, x4, #0xc, #0x14
    // 0x625cdc: cmp             x4, #0x3d
    // 0x625ce0: b.eq            #0x625cf4
    // 0x625ce4: r8 = double
    //     0x625ce4: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x625ce8: r3 = Null
    //     0x625ce8: add             x3, PP, #0x37, lsl #12  ; [pp+0x37288] Null
    //     0x625cec: ldr             x3, [x3, #0x288]
    // 0x625cf0: r0 = double()
    //     0x625cf0: bl              #0xd72bac  ; IsType_double_Stub
    // 0x625cf4: ldr             x16, [fp, #0x18]
    // 0x625cf8: ldr             lr, [fp, #0x10]
    // 0x625cfc: stp             lr, x16, [SP, #-0x10]!
    // 0x625d00: r0 = *()
    //     0x625d00: bl              #0xcfae60  ; [package:flutter/src/painting/alignment.dart] _MixedAlignment::*
    // 0x625d04: add             SP, SP, #0x10
    // 0x625d08: LeaveFrame
    //     0x625d08: mov             SP, fp
    //     0x625d0c: ldp             fp, lr, [SP], #0x10
    // 0x625d10: ret
    //     0x625d10: ret             
    // 0x625d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625d14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x625d18: b               #0x625cc0
  }
  _MixedAlignment *(_MixedAlignment, double) {
    // ** addr: 0xcfae60, size: 0x64
    // 0xcfae60: EnterFrame
    //     0xcfae60: stp             fp, lr, [SP, #-0x10]!
    //     0xcfae64: mov             fp, SP
    // 0xcfae68: AllocStack(0x18)
    //     0xcfae68: sub             SP, SP, #0x18
    // 0xcfae6c: ldr             x0, [fp, #0x18]
    // 0xcfae70: LoadField: d0 = r0->field_7
    //     0xcfae70: ldur            d0, [x0, #7]
    // 0xcfae74: ldr             x1, [fp, #0x10]
    // 0xcfae78: LoadField: d1 = r1->field_7
    //     0xcfae78: ldur            d1, [x1, #7]
    // 0xcfae7c: fmul            d2, d0, d1
    // 0xcfae80: stur            d2, [fp, #-0x18]
    // 0xcfae84: LoadField: d0 = r0->field_f
    //     0xcfae84: ldur            d0, [x0, #0xf]
    // 0xcfae88: fmul            d3, d0, d1
    // 0xcfae8c: stur            d3, [fp, #-0x10]
    // 0xcfae90: LoadField: d0 = r0->field_17
    //     0xcfae90: ldur            d0, [x0, #0x17]
    // 0xcfae94: fmul            d4, d0, d1
    // 0xcfae98: stur            d4, [fp, #-8]
    // 0xcfae9c: r0 = _MixedAlignment()
    //     0xcfae9c: bl              #0x625c88  ; Allocate_MixedAlignmentStub -> _MixedAlignment (size=0x20)
    // 0xcfaea0: ldur            d0, [fp, #-0x18]
    // 0xcfaea4: StoreField: r0->field_7 = d0
    //     0xcfaea4: stur            d0, [x0, #7]
    // 0xcfaea8: ldur            d0, [fp, #-0x10]
    // 0xcfaeac: StoreField: r0->field_f = d0
    //     0xcfaeac: stur            d0, [x0, #0xf]
    // 0xcfaeb0: ldur            d0, [fp, #-8]
    // 0xcfaeb4: StoreField: r0->field_17 = d0
    //     0xcfaeb4: stur            d0, [x0, #0x17]
    // 0xcfaeb8: LeaveFrame
    //     0xcfaeb8: mov             SP, fp
    //     0xcfaebc: ldp             fp, lr, [SP], #0x10
    // 0xcfaec0: ret
    //     0xcfaec0: ret             
  }
}

// class id: 2118, size: 0x18, field offset: 0x8
//   const constructor, 
class AlignmentDirectional extends AlignmentGeometry {

  _Double field_8;
  _Double field_10;

  AlignmentDirectional /(AlignmentDirectional, double) {
    // ** addr: 0x625888, size: 0x88
    // 0x625888: EnterFrame
    //     0x625888: stp             fp, lr, [SP, #-0x10]!
    //     0x62588c: mov             fp, SP
    // 0x625890: CheckStackOverflow
    //     0x625890: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625894: cmp             SP, x16
    //     0x625898: b.ls            #0x6258f0
    // 0x62589c: ldr             x0, [fp, #0x10]
    // 0x6258a0: r2 = Null
    //     0x6258a0: mov             x2, NULL
    // 0x6258a4: r1 = Null
    //     0x6258a4: mov             x1, NULL
    // 0x6258a8: r4 = 59
    //     0x6258a8: mov             x4, #0x3b
    // 0x6258ac: branchIfSmi(r0, 0x6258b8)
    //     0x6258ac: tbz             w0, #0, #0x6258b8
    // 0x6258b0: r4 = LoadClassIdInstr(r0)
    //     0x6258b0: ldur            x4, [x0, #-1]
    //     0x6258b4: ubfx            x4, x4, #0xc, #0x14
    // 0x6258b8: cmp             x4, #0x3d
    // 0x6258bc: b.eq            #0x6258d0
    // 0x6258c0: r8 = double
    //     0x6258c0: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x6258c4: r3 = Null
    //     0x6258c4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b498] Null
    //     0x6258c8: ldr             x3, [x3, #0x498]
    // 0x6258cc: r0 = double()
    //     0x6258cc: bl              #0xd72bac  ; IsType_double_Stub
    // 0x6258d0: ldr             x16, [fp, #0x18]
    // 0x6258d4: ldr             lr, [fp, #0x10]
    // 0x6258d8: stp             lr, x16, [SP, #-0x10]!
    // 0x6258dc: r0 = /()
    //     0x6258dc: bl              #0x6258f8  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::/
    // 0x6258e0: add             SP, SP, #0x10
    // 0x6258e4: LeaveFrame
    //     0x6258e4: mov             SP, fp
    //     0x6258e8: ldp             fp, lr, [SP], #0x10
    // 0x6258ec: ret
    //     0x6258ec: ret             
    // 0x6258f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6258f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6258f4: b               #0x62589c
  }
  AlignmentDirectional /(AlignmentDirectional, double) {
    // ** addr: 0x6258f8, size: 0x50
    // 0x6258f8: EnterFrame
    //     0x6258f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6258fc: mov             fp, SP
    // 0x625900: AllocStack(0x10)
    //     0x625900: sub             SP, SP, #0x10
    // 0x625904: ldr             x0, [fp, #0x18]
    // 0x625908: LoadField: d0 = r0->field_7
    //     0x625908: ldur            d0, [x0, #7]
    // 0x62590c: ldr             x1, [fp, #0x10]
    // 0x625910: LoadField: d1 = r1->field_7
    //     0x625910: ldur            d1, [x1, #7]
    // 0x625914: fdiv            d2, d0, d1
    // 0x625918: stur            d2, [fp, #-0x10]
    // 0x62591c: LoadField: d0 = r0->field_f
    //     0x62591c: ldur            d0, [x0, #0xf]
    // 0x625920: fdiv            d3, d0, d1
    // 0x625924: stur            d3, [fp, #-8]
    // 0x625928: r0 = AlignmentDirectional()
    //     0x625928: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0x62592c: ldur            d0, [fp, #-0x10]
    // 0x625930: StoreField: r0->field_7 = d0
    //     0x625930: stur            d0, [x0, #7]
    // 0x625934: ldur            d0, [fp, #-8]
    // 0x625938: StoreField: r0->field_f = d0
    //     0x625938: stur            d0, [x0, #0xf]
    // 0x62593c: LeaveFrame
    //     0x62593c: mov             SP, fp
    //     0x625940: ldp             fp, lr, [SP], #0x10
    // 0x625944: ret
    //     0x625944: ret             
  }
  AlignmentDirectional *(AlignmentDirectional, double) {
    // ** addr: 0x62596c, size: 0x88
    // 0x62596c: EnterFrame
    //     0x62596c: stp             fp, lr, [SP, #-0x10]!
    //     0x625970: mov             fp, SP
    // 0x625974: CheckStackOverflow
    //     0x625974: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625978: cmp             SP, x16
    //     0x62597c: b.ls            #0x6259d4
    // 0x625980: ldr             x0, [fp, #0x10]
    // 0x625984: r2 = Null
    //     0x625984: mov             x2, NULL
    // 0x625988: r1 = Null
    //     0x625988: mov             x1, NULL
    // 0x62598c: r4 = 59
    //     0x62598c: mov             x4, #0x3b
    // 0x625990: branchIfSmi(r0, 0x62599c)
    //     0x625990: tbz             w0, #0, #0x62599c
    // 0x625994: r4 = LoadClassIdInstr(r0)
    //     0x625994: ldur            x4, [x0, #-1]
    //     0x625998: ubfx            x4, x4, #0xc, #0x14
    // 0x62599c: cmp             x4, #0x3d
    // 0x6259a0: b.eq            #0x6259b4
    // 0x6259a4: r8 = double
    //     0x6259a4: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x6259a8: r3 = Null
    //     0x6259a8: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2db48] Null
    //     0x6259ac: ldr             x3, [x3, #0xb48]
    // 0x6259b0: r0 = double()
    //     0x6259b0: bl              #0xd72bac  ; IsType_double_Stub
    // 0x6259b4: ldr             x16, [fp, #0x18]
    // 0x6259b8: ldr             lr, [fp, #0x10]
    // 0x6259bc: stp             lr, x16, [SP, #-0x10]!
    // 0x6259c0: r0 = *()
    //     0x6259c0: bl              #0xcfae10  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::*
    // 0x6259c4: add             SP, SP, #0x10
    // 0x6259c8: LeaveFrame
    //     0x6259c8: mov             SP, fp
    //     0x6259cc: ldp             fp, lr, [SP], #0x10
    // 0x6259d0: ret
    //     0x6259d0: ret             
    // 0x6259d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6259d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6259d8: b               #0x625980
  }
  AlignmentDirectional +(AlignmentDirectional, AlignmentDirectional) {
    // ** addr: 0x6259f4, size: 0x8c
    // 0x6259f4: EnterFrame
    //     0x6259f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6259f8: mov             fp, SP
    // 0x6259fc: CheckStackOverflow
    //     0x6259fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625a00: cmp             SP, x16
    //     0x625a04: b.ls            #0x625a60
    // 0x625a08: ldr             x0, [fp, #0x10]
    // 0x625a0c: r2 = Null
    //     0x625a0c: mov             x2, NULL
    // 0x625a10: r1 = Null
    //     0x625a10: mov             x1, NULL
    // 0x625a14: r4 = 59
    //     0x625a14: mov             x4, #0x3b
    // 0x625a18: branchIfSmi(r0, 0x625a24)
    //     0x625a18: tbz             w0, #0, #0x625a24
    // 0x625a1c: r4 = LoadClassIdInstr(r0)
    //     0x625a1c: ldur            x4, [x0, #-1]
    //     0x625a20: ubfx            x4, x4, #0xc, #0x14
    // 0x625a24: cmp             x4, #0x846
    // 0x625a28: b.eq            #0x625a40
    // 0x625a2c: r8 = AlignmentDirectional
    //     0x625a2c: add             x8, PP, #0x28, lsl #12  ; [pp+0x288f0] Type: AlignmentDirectional
    //     0x625a30: ldr             x8, [x8, #0x8f0]
    // 0x625a34: r3 = Null
    //     0x625a34: add             x3, PP, #0x28, lsl #12  ; [pp+0x288f8] Null
    //     0x625a38: ldr             x3, [x3, #0x8f8]
    // 0x625a3c: r0 = DefaultTypeTest()
    //     0x625a3c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x625a40: ldr             x16, [fp, #0x18]
    // 0x625a44: ldr             lr, [fp, #0x10]
    // 0x625a48: stp             lr, x16, [SP, #-0x10]!
    // 0x625a4c: r0 = +()
    //     0x625a4c: bl              #0x625a68  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::+
    // 0x625a50: add             SP, SP, #0x10
    // 0x625a54: LeaveFrame
    //     0x625a54: mov             SP, fp
    //     0x625a58: ldp             fp, lr, [SP], #0x10
    // 0x625a5c: ret
    //     0x625a5c: ret             
    // 0x625a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625a60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x625a64: b               #0x625a08
  }
  AlignmentDirectional +(AlignmentDirectional, AlignmentDirectional) {
    // ** addr: 0x625a68, size: 0x54
    // 0x625a68: EnterFrame
    //     0x625a68: stp             fp, lr, [SP, #-0x10]!
    //     0x625a6c: mov             fp, SP
    // 0x625a70: AllocStack(0x10)
    //     0x625a70: sub             SP, SP, #0x10
    // 0x625a74: ldr             x0, [fp, #0x18]
    // 0x625a78: LoadField: d0 = r0->field_7
    //     0x625a78: ldur            d0, [x0, #7]
    // 0x625a7c: ldr             x1, [fp, #0x10]
    // 0x625a80: LoadField: d1 = r1->field_7
    //     0x625a80: ldur            d1, [x1, #7]
    // 0x625a84: fadd            d2, d0, d1
    // 0x625a88: stur            d2, [fp, #-0x10]
    // 0x625a8c: LoadField: d0 = r0->field_f
    //     0x625a8c: ldur            d0, [x0, #0xf]
    // 0x625a90: LoadField: d1 = r1->field_f
    //     0x625a90: ldur            d1, [x1, #0xf]
    // 0x625a94: fadd            d3, d0, d1
    // 0x625a98: stur            d3, [fp, #-8]
    // 0x625a9c: r0 = AlignmentDirectional()
    //     0x625a9c: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0x625aa0: ldur            d0, [fp, #-0x10]
    // 0x625aa4: StoreField: r0->field_7 = d0
    //     0x625aa4: stur            d0, [x0, #7]
    // 0x625aa8: ldur            d0, [fp, #-8]
    // 0x625aac: StoreField: r0->field_f = d0
    //     0x625aac: stur            d0, [x0, #0xf]
    // 0x625ab0: LeaveFrame
    //     0x625ab0: mov             SP, fp
    //     0x625ab4: ldp             fp, lr, [SP], #0x10
    // 0x625ab8: ret
    //     0x625ab8: ret             
  }
  AlignmentDirectional -(AlignmentDirectional, AlignmentDirectional) {
    // ** addr: 0x625ad4, size: 0x8c
    // 0x625ad4: EnterFrame
    //     0x625ad4: stp             fp, lr, [SP, #-0x10]!
    //     0x625ad8: mov             fp, SP
    // 0x625adc: CheckStackOverflow
    //     0x625adc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625ae0: cmp             SP, x16
    //     0x625ae4: b.ls            #0x625b40
    // 0x625ae8: ldr             x0, [fp, #0x10]
    // 0x625aec: r2 = Null
    //     0x625aec: mov             x2, NULL
    // 0x625af0: r1 = Null
    //     0x625af0: mov             x1, NULL
    // 0x625af4: r4 = 59
    //     0x625af4: mov             x4, #0x3b
    // 0x625af8: branchIfSmi(r0, 0x625b04)
    //     0x625af8: tbz             w0, #0, #0x625b04
    // 0x625afc: r4 = LoadClassIdInstr(r0)
    //     0x625afc: ldur            x4, [x0, #-1]
    //     0x625b00: ubfx            x4, x4, #0xc, #0x14
    // 0x625b04: cmp             x4, #0x846
    // 0x625b08: b.eq            #0x625b20
    // 0x625b0c: r8 = AlignmentDirectional
    //     0x625b0c: add             x8, PP, #0x28, lsl #12  ; [pp+0x288f0] Type: AlignmentDirectional
    //     0x625b10: ldr             x8, [x8, #0x8f0]
    // 0x625b14: r3 = Null
    //     0x625b14: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2db58] Null
    //     0x625b18: ldr             x3, [x3, #0xb58]
    // 0x625b1c: r0 = DefaultTypeTest()
    //     0x625b1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x625b20: ldr             x16, [fp, #0x18]
    // 0x625b24: ldr             lr, [fp, #0x10]
    // 0x625b28: stp             lr, x16, [SP, #-0x10]!
    // 0x625b2c: r0 = -()
    //     0x625b2c: bl              #0x625b48  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::-
    // 0x625b30: add             SP, SP, #0x10
    // 0x625b34: LeaveFrame
    //     0x625b34: mov             SP, fp
    //     0x625b38: ldp             fp, lr, [SP], #0x10
    // 0x625b3c: ret
    //     0x625b3c: ret             
    // 0x625b40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625b40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x625b44: b               #0x625ae8
  }
  AlignmentDirectional -(AlignmentDirectional, AlignmentDirectional) {
    // ** addr: 0x625b48, size: 0x54
    // 0x625b48: EnterFrame
    //     0x625b48: stp             fp, lr, [SP, #-0x10]!
    //     0x625b4c: mov             fp, SP
    // 0x625b50: AllocStack(0x10)
    //     0x625b50: sub             SP, SP, #0x10
    // 0x625b54: ldr             x0, [fp, #0x18]
    // 0x625b58: LoadField: d0 = r0->field_7
    //     0x625b58: ldur            d0, [x0, #7]
    // 0x625b5c: ldr             x1, [fp, #0x10]
    // 0x625b60: LoadField: d1 = r1->field_7
    //     0x625b60: ldur            d1, [x1, #7]
    // 0x625b64: fsub            d2, d0, d1
    // 0x625b68: stur            d2, [fp, #-0x10]
    // 0x625b6c: LoadField: d0 = r0->field_f
    //     0x625b6c: ldur            d0, [x0, #0xf]
    // 0x625b70: LoadField: d1 = r1->field_f
    //     0x625b70: ldur            d1, [x1, #0xf]
    // 0x625b74: fsub            d3, d0, d1
    // 0x625b78: stur            d3, [fp, #-8]
    // 0x625b7c: r0 = AlignmentDirectional()
    //     0x625b7c: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0x625b80: ldur            d0, [fp, #-0x10]
    // 0x625b84: StoreField: r0->field_7 = d0
    //     0x625b84: stur            d0, [x0, #7]
    // 0x625b88: ldur            d0, [fp, #-8]
    // 0x625b8c: StoreField: r0->field_f = d0
    //     0x625b8c: stur            d0, [x0, #0xf]
    // 0x625b90: LeaveFrame
    //     0x625b90: mov             SP, fp
    //     0x625b94: ldp             fp, lr, [SP], #0x10
    // 0x625b98: ret
    //     0x625b98: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xaded1c, size: 0x7c
    // 0xaded1c: EnterFrame
    //     0xaded1c: stp             fp, lr, [SP, #-0x10]!
    //     0xaded20: mov             fp, SP
    // 0xaded24: CheckStackOverflow
    //     0xaded24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaded28: cmp             SP, x16
    //     0xaded2c: b.ls            #0xaded80
    // 0xaded30: ldr             x0, [fp, #0x10]
    // 0xaded34: LoadField: d0 = r0->field_7
    //     0xaded34: ldur            d0, [x0, #7]
    // 0xaded38: LoadField: d1 = r0->field_f
    //     0xaded38: ldur            d1, [x0, #0xf]
    // 0xaded3c: r0 = inline_Allocate_Double()
    //     0xaded3c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xaded40: add             x0, x0, #0x10
    //     0xaded44: cmp             x1, x0
    //     0xaded48: b.ls            #0xaded88
    //     0xaded4c: str             x0, [THR, #0x60]  ; THR::top
    //     0xaded50: sub             x0, x0, #0xf
    //     0xaded54: mov             x1, #0xd108
    //     0xaded58: movk            x1, #3, lsl #16
    //     0xaded5c: stur            x1, [x0, #-1]
    // 0xaded60: StoreField: r0->field_7 = d0
    //     0xaded60: stur            d0, [x0, #7]
    // 0xaded64: SaveReg r0
    //     0xaded64: str             x0, [SP, #-8]!
    // 0xaded68: SaveReg d1
    //     0xaded68: str             d1, [SP, #-8]!
    // 0xaded6c: r0 = _stringify()
    //     0xaded6c: bl              #0xaded98  ; [package:flutter/src/painting/alignment.dart] AlignmentDirectional::_stringify
    // 0xaded70: add             SP, SP, #0x10
    // 0xaded74: LeaveFrame
    //     0xaded74: mov             SP, fp
    //     0xaded78: ldp             fp, lr, [SP], #0x10
    // 0xaded7c: ret
    //     0xaded7c: ret             
    // 0xaded80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaded80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaded84: b               #0xaded30
    // 0xaded88: stp             q0, q1, [SP, #-0x20]!
    // 0xaded8c: r0 = AllocateDouble()
    //     0xaded8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaded90: ldp             q0, q1, [SP], #0x20
    // 0xaded94: b               #0xaded60
  }
  static _ _stringify(/* No info */) {
    // ** addr: 0xaded98, size: 0x2d4
    // 0xaded98: EnterFrame
    //     0xaded98: stp             fp, lr, [SP, #-0x10]!
    //     0xaded9c: mov             fp, SP
    // 0xadeda0: AllocStack(0x8)
    //     0xadeda0: sub             SP, SP, #8
    // 0xadeda4: d0 = 1.000000
    //     0xadeda4: fmov            d0, #1.00000000
    // 0xadeda8: CheckStackOverflow
    //     0xadeda8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadedac: cmp             SP, x16
    //     0xadedb0: b.ls            #0xadf04c
    // 0xadedb4: fneg            d1, d0
    // 0xadedb8: ldr             x0, [fp, #0x18]
    // 0xadedbc: LoadField: d2 = r0->field_7
    //     0xadedbc: ldur            d2, [x0, #7]
    // 0xadedc0: fcmp            d2, d1
    // 0xadedc4: b.vs            #0xadedcc
    // 0xadedc8: b.eq            #0xadedd4
    // 0xadedcc: r1 = false
    //     0xadedcc: add             x1, NULL, #0x30  ; false
    // 0xadedd0: b               #0xadedd8
    // 0xadedd4: r1 = true
    //     0xadedd4: add             x1, NULL, #0x20  ; true
    // 0xadedd8: tbnz            w1, #4, #0xadee00
    // 0xadeddc: ldr             d3, [fp, #0x10]
    // 0xadede0: fcmp            d3, d1
    // 0xadede4: b.vs            #0xadee04
    // 0xadede8: b.ne            #0xadee04
    // 0xadedec: r0 = "AlignmentDirectional.topStart"
    //     0xadedec: add             x0, PP, #0xe, lsl #12  ; [pp+0xe870] "AlignmentDirectional.topStart"
    //     0xadedf0: ldr             x0, [x0, #0x870]
    // 0xadedf4: LeaveFrame
    //     0xadedf4: mov             SP, fp
    //     0xadedf8: ldp             fp, lr, [SP], #0x10
    // 0xadedfc: ret
    //     0xadedfc: ret             
    // 0xadee00: ldr             d3, [fp, #0x10]
    // 0xadee04: d4 = 0.000000
    //     0xadee04: eor             v4.16b, v4.16b, v4.16b
    // 0xadee08: fcmp            d2, d4
    // 0xadee0c: b.vs            #0xadee14
    // 0xadee10: b.eq            #0xadee1c
    // 0xadee14: r2 = false
    //     0xadee14: add             x2, NULL, #0x30  ; false
    // 0xadee18: b               #0xadee20
    // 0xadee1c: r2 = true
    //     0xadee1c: add             x2, NULL, #0x20  ; true
    // 0xadee20: tbnz            w2, #4, #0xadee44
    // 0xadee24: fcmp            d3, d1
    // 0xadee28: b.vs            #0xadee44
    // 0xadee2c: b.ne            #0xadee44
    // 0xadee30: r0 = "AlignmentDirectional.topCenter"
    //     0xadee30: add             x0, PP, #0xe, lsl #12  ; [pp+0xe878] "AlignmentDirectional.topCenter"
    //     0xadee34: ldr             x0, [x0, #0x878]
    // 0xadee38: LeaveFrame
    //     0xadee38: mov             SP, fp
    //     0xadee3c: ldp             fp, lr, [SP], #0x10
    // 0xadee40: ret
    //     0xadee40: ret             
    // 0xadee44: fcmp            d2, d0
    // 0xadee48: b.vs            #0xadee50
    // 0xadee4c: b.eq            #0xadee58
    // 0xadee50: r3 = false
    //     0xadee50: add             x3, NULL, #0x30  ; false
    // 0xadee54: b               #0xadee5c
    // 0xadee58: r3 = true
    //     0xadee58: add             x3, NULL, #0x20  ; true
    // 0xadee5c: tbnz            w3, #4, #0xadee80
    // 0xadee60: fcmp            d3, d1
    // 0xadee64: b.vs            #0xadee80
    // 0xadee68: b.ne            #0xadee80
    // 0xadee6c: r0 = "AlignmentDirectional.topEnd"
    //     0xadee6c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe880] "AlignmentDirectional.topEnd"
    //     0xadee70: ldr             x0, [x0, #0x880]
    // 0xadee74: LeaveFrame
    //     0xadee74: mov             SP, fp
    //     0xadee78: ldp             fp, lr, [SP], #0x10
    // 0xadee7c: ret
    //     0xadee7c: ret             
    // 0xadee80: tbnz            w1, #4, #0xadeea4
    // 0xadee84: fcmp            d3, d4
    // 0xadee88: b.vs            #0xadeea4
    // 0xadee8c: b.ne            #0xadeea4
    // 0xadee90: r0 = "AlignmentDirectional.centerStart"
    //     0xadee90: add             x0, PP, #0xe, lsl #12  ; [pp+0xe888] "AlignmentDirectional.centerStart"
    //     0xadee94: ldr             x0, [x0, #0x888]
    // 0xadee98: LeaveFrame
    //     0xadee98: mov             SP, fp
    //     0xadee9c: ldp             fp, lr, [SP], #0x10
    // 0xadeea0: ret
    //     0xadeea0: ret             
    // 0xadeea4: tbnz            w2, #4, #0xadeec8
    // 0xadeea8: fcmp            d3, d4
    // 0xadeeac: b.vs            #0xadeec8
    // 0xadeeb0: b.ne            #0xadeec8
    // 0xadeeb4: r0 = "AlignmentDirectional.center"
    //     0xadeeb4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe890] "AlignmentDirectional.center"
    //     0xadeeb8: ldr             x0, [x0, #0x890]
    // 0xadeebc: LeaveFrame
    //     0xadeebc: mov             SP, fp
    //     0xadeec0: ldp             fp, lr, [SP], #0x10
    // 0xadeec4: ret
    //     0xadeec4: ret             
    // 0xadeec8: tbnz            w3, #4, #0xadeeec
    // 0xadeecc: fcmp            d3, d4
    // 0xadeed0: b.vs            #0xadeeec
    // 0xadeed4: b.ne            #0xadeeec
    // 0xadeed8: r0 = "AlignmentDirectional.centerEnd"
    //     0xadeed8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe898] "AlignmentDirectional.centerEnd"
    //     0xadeedc: ldr             x0, [x0, #0x898]
    // 0xadeee0: LeaveFrame
    //     0xadeee0: mov             SP, fp
    //     0xadeee4: ldp             fp, lr, [SP], #0x10
    // 0xadeee8: ret
    //     0xadeee8: ret             
    // 0xadeeec: tbnz            w1, #4, #0xadef10
    // 0xadeef0: fcmp            d3, d0
    // 0xadeef4: b.vs            #0xadef10
    // 0xadeef8: b.ne            #0xadef10
    // 0xadeefc: r0 = "AlignmentDirectional.bottomStart"
    //     0xadeefc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8a0] "AlignmentDirectional.bottomStart"
    //     0xadef00: ldr             x0, [x0, #0x8a0]
    // 0xadef04: LeaveFrame
    //     0xadef04: mov             SP, fp
    //     0xadef08: ldp             fp, lr, [SP], #0x10
    // 0xadef0c: ret
    //     0xadef0c: ret             
    // 0xadef10: tbnz            w2, #4, #0xadef34
    // 0xadef14: fcmp            d3, d0
    // 0xadef18: b.vs            #0xadef34
    // 0xadef1c: b.ne            #0xadef34
    // 0xadef20: r0 = "AlignmentDirectional.bottomCenter"
    //     0xadef20: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8a8] "AlignmentDirectional.bottomCenter"
    //     0xadef24: ldr             x0, [x0, #0x8a8]
    // 0xadef28: LeaveFrame
    //     0xadef28: mov             SP, fp
    //     0xadef2c: ldp             fp, lr, [SP], #0x10
    // 0xadef30: ret
    //     0xadef30: ret             
    // 0xadef34: tbnz            w3, #4, #0xadef58
    // 0xadef38: fcmp            d3, d0
    // 0xadef3c: b.vs            #0xadef58
    // 0xadef40: b.ne            #0xadef58
    // 0xadef44: r0 = "AlignmentDirectional.bottomEnd"
    //     0xadef44: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8b0] "AlignmentDirectional.bottomEnd"
    //     0xadef48: ldr             x0, [x0, #0x8b0]
    // 0xadef4c: LeaveFrame
    //     0xadef4c: mov             SP, fp
    //     0xadef50: ldp             fp, lr, [SP], #0x10
    // 0xadef54: ret
    //     0xadef54: ret             
    // 0xadef58: r1 = Null
    //     0xadef58: mov             x1, NULL
    // 0xadef5c: r2 = 10
    //     0xadef5c: mov             x2, #0xa
    // 0xadef60: r0 = AllocateArray()
    //     0xadef60: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadef64: stur            x0, [fp, #-8]
    // 0xadef68: r17 = "AlignmentDirectional("
    //     0xadef68: add             x17, PP, #0xe, lsl #12  ; [pp+0xe8b8] "AlignmentDirectional("
    //     0xadef6c: ldr             x17, [x17, #0x8b8]
    // 0xadef70: StoreField: r0->field_f = r17
    //     0xadef70: stur            w17, [x0, #0xf]
    // 0xadef74: ldr             x16, [fp, #0x18]
    // 0xadef78: SaveReg r16
    //     0xadef78: str             x16, [SP, #-8]!
    // 0xadef7c: r1 = 1
    //     0xadef7c: mov             x1, #1
    // 0xadef80: SaveReg r1
    //     0xadef80: str             x1, [SP, #-8]!
    // 0xadef84: r0 = toStringAsFixed()
    //     0xadef84: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadef88: add             SP, SP, #0x10
    // 0xadef8c: ldur            x1, [fp, #-8]
    // 0xadef90: ArrayStore: r1[1] = r0  ; List_4
    //     0xadef90: add             x25, x1, #0x13
    //     0xadef94: str             w0, [x25]
    //     0xadef98: tbz             w0, #0, #0xadefb4
    //     0xadef9c: ldurb           w16, [x1, #-1]
    //     0xadefa0: ldurb           w17, [x0, #-1]
    //     0xadefa4: and             x16, x17, x16, lsr #2
    //     0xadefa8: tst             x16, HEAP, lsr #32
    //     0xadefac: b.eq            #0xadefb4
    //     0xadefb0: bl              #0xd67e5c
    // 0xadefb4: ldur            x1, [fp, #-8]
    // 0xadefb8: r17 = ", "
    //     0xadefb8: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadefbc: StoreField: r1->field_17 = r17
    //     0xadefbc: stur            w17, [x1, #0x17]
    // 0xadefc0: ldr             d0, [fp, #0x10]
    // 0xadefc4: r0 = inline_Allocate_Double()
    //     0xadefc4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xadefc8: add             x0, x0, #0x10
    //     0xadefcc: cmp             x2, x0
    //     0xadefd0: b.ls            #0xadf054
    //     0xadefd4: str             x0, [THR, #0x60]  ; THR::top
    //     0xadefd8: sub             x0, x0, #0xf
    //     0xadefdc: mov             x2, #0xd108
    //     0xadefe0: movk            x2, #3, lsl #16
    //     0xadefe4: stur            x2, [x0, #-1]
    // 0xadefe8: StoreField: r0->field_7 = d0
    //     0xadefe8: stur            d0, [x0, #7]
    // 0xadefec: SaveReg r0
    //     0xadefec: str             x0, [SP, #-8]!
    // 0xadeff0: r0 = 1
    //     0xadeff0: mov             x0, #1
    // 0xadeff4: SaveReg r0
    //     0xadeff4: str             x0, [SP, #-8]!
    // 0xadeff8: r0 = toStringAsFixed()
    //     0xadeff8: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadeffc: add             SP, SP, #0x10
    // 0xadf000: ldur            x1, [fp, #-8]
    // 0xadf004: ArrayStore: r1[3] = r0  ; List_4
    //     0xadf004: add             x25, x1, #0x1b
    //     0xadf008: str             w0, [x25]
    //     0xadf00c: tbz             w0, #0, #0xadf028
    //     0xadf010: ldurb           w16, [x1, #-1]
    //     0xadf014: ldurb           w17, [x0, #-1]
    //     0xadf018: and             x16, x17, x16, lsr #2
    //     0xadf01c: tst             x16, HEAP, lsr #32
    //     0xadf020: b.eq            #0xadf028
    //     0xadf024: bl              #0xd67e5c
    // 0xadf028: ldur            x0, [fp, #-8]
    // 0xadf02c: r17 = ")"
    //     0xadf02c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadf030: StoreField: r0->field_1f = r17
    //     0xadf030: stur            w17, [x0, #0x1f]
    // 0xadf034: SaveReg r0
    //     0xadf034: str             x0, [SP, #-8]!
    // 0xadf038: r0 = _interpolate()
    //     0xadf038: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadf03c: add             SP, SP, #8
    // 0xadf040: LeaveFrame
    //     0xadf040: mov             SP, fp
    //     0xadf044: ldp             fp, lr, [SP], #0x10
    // 0xadf048: ret
    //     0xadf048: ret             
    // 0xadf04c: r0 = StackOverflowSharedWithFPURegs()
    //     0xadf04c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xadf050: b               #0xadedb4
    // 0xadf054: SaveReg d0
    //     0xadf054: str             q0, [SP, #-0x10]!
    // 0xadf058: SaveReg r1
    //     0xadf058: str             x1, [SP, #-8]!
    // 0xadf05c: r0 = AllocateDouble()
    //     0xadf05c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadf060: RestoreReg r1
    //     0xadf060: ldr             x1, [SP], #8
    // 0xadf064: RestoreReg d0
    //     0xadf064: ldr             q0, [SP], #0x10
    // 0xadf068: b               #0xadefe8
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf054c, size: 0x518
    // 0xbf054c: EnterFrame
    //     0xbf054c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0550: mov             fp, SP
    // 0xbf0554: AllocStack(0x18)
    //     0xbf0554: sub             SP, SP, #0x18
    // 0xbf0558: CheckStackOverflow
    //     0xbf0558: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf055c: cmp             SP, x16
    //     0xbf0560: b.ls            #0xbf08fc
    // 0xbf0564: ldr             x0, [fp, #0x20]
    // 0xbf0568: cmp             w0, NULL
    // 0xbf056c: b.ne            #0xbf058c
    // 0xbf0570: ldr             x1, [fp, #0x18]
    // 0xbf0574: cmp             w1, NULL
    // 0xbf0578: b.ne            #0xbf0590
    // 0xbf057c: r0 = Null
    //     0xbf057c: mov             x0, NULL
    // 0xbf0580: LeaveFrame
    //     0xbf0580: mov             SP, fp
    //     0xbf0584: ldp             fp, lr, [SP], #0x10
    // 0xbf0588: ret
    //     0xbf0588: ret             
    // 0xbf058c: ldr             x1, [fp, #0x18]
    // 0xbf0590: cmp             w0, NULL
    // 0xbf0594: b.ne            #0xbf06a0
    // 0xbf0598: ldr             d0, [fp, #0x10]
    // 0xbf059c: cmp             w1, NULL
    // 0xbf05a0: b.eq            #0xbf0904
    // 0xbf05a4: LoadField: d1 = r1->field_7
    //     0xbf05a4: ldur            d1, [x1, #7]
    // 0xbf05a8: r0 = inline_Allocate_Double()
    //     0xbf05a8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbf05ac: add             x0, x0, #0x10
    //     0xbf05b0: cmp             x2, x0
    //     0xbf05b4: b.ls            #0xbf0908
    //     0xbf05b8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf05bc: sub             x0, x0, #0xf
    //     0xbf05c0: mov             x2, #0xd108
    //     0xbf05c4: movk            x2, #3, lsl #16
    //     0xbf05c8: stur            x2, [x0, #-1]
    // 0xbf05cc: StoreField: r0->field_7 = d0
    //     0xbf05cc: stur            d0, [x0, #7]
    // 0xbf05d0: stur            x0, [fp, #-8]
    // 0xbf05d4: r2 = inline_Allocate_Double()
    //     0xbf05d4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf05d8: add             x2, x2, #0x10
    //     0xbf05dc: cmp             x3, x2
    //     0xbf05e0: b.ls            #0xbf0920
    //     0xbf05e4: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf05e8: sub             x2, x2, #0xf
    //     0xbf05ec: mov             x3, #0xd108
    //     0xbf05f0: movk            x3, #3, lsl #16
    //     0xbf05f4: stur            x3, [x2, #-1]
    // 0xbf05f8: StoreField: r2->field_7 = d1
    //     0xbf05f8: stur            d1, [x2, #7]
    // 0xbf05fc: r16 = 0.000000
    //     0xbf05fc: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xbf0600: stp             x2, x16, [SP, #-0x10]!
    // 0xbf0604: SaveReg r0
    //     0xbf0604: str             x0, [SP, #-8]!
    // 0xbf0608: r0 = lerpDouble()
    //     0xbf0608: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf060c: add             SP, SP, #0x18
    // 0xbf0610: stur            x0, [fp, #-0x10]
    // 0xbf0614: cmp             w0, NULL
    // 0xbf0618: b.eq            #0xbf093c
    // 0xbf061c: ldr             x1, [fp, #0x18]
    // 0xbf0620: LoadField: d0 = r1->field_f
    //     0xbf0620: ldur            d0, [x1, #0xf]
    // 0xbf0624: r1 = inline_Allocate_Double()
    //     0xbf0624: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf0628: add             x1, x1, #0x10
    //     0xbf062c: cmp             x2, x1
    //     0xbf0630: b.ls            #0xbf0940
    //     0xbf0634: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf0638: sub             x1, x1, #0xf
    //     0xbf063c: mov             x2, #0xd108
    //     0xbf0640: movk            x2, #3, lsl #16
    //     0xbf0644: stur            x2, [x1, #-1]
    // 0xbf0648: StoreField: r1->field_7 = d0
    //     0xbf0648: stur            d0, [x1, #7]
    // 0xbf064c: r16 = 0.000000
    //     0xbf064c: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xbf0650: stp             x1, x16, [SP, #-0x10]!
    // 0xbf0654: ldur            x16, [fp, #-8]
    // 0xbf0658: SaveReg r16
    //     0xbf0658: str             x16, [SP, #-8]!
    // 0xbf065c: r0 = lerpDouble()
    //     0xbf065c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf0660: add             SP, SP, #0x18
    // 0xbf0664: stur            x0, [fp, #-8]
    // 0xbf0668: cmp             w0, NULL
    // 0xbf066c: b.eq            #0xbf095c
    // 0xbf0670: ldur            x1, [fp, #-0x10]
    // 0xbf0674: LoadField: d0 = r1->field_7
    //     0xbf0674: ldur            d0, [x1, #7]
    // 0xbf0678: stur            d0, [fp, #-0x18]
    // 0xbf067c: r0 = AlignmentDirectional()
    //     0xbf067c: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xbf0680: ldur            d0, [fp, #-0x18]
    // 0xbf0684: StoreField: r0->field_7 = d0
    //     0xbf0684: stur            d0, [x0, #7]
    // 0xbf0688: ldur            x1, [fp, #-8]
    // 0xbf068c: LoadField: d0 = r1->field_7
    //     0xbf068c: ldur            d0, [x1, #7]
    // 0xbf0690: StoreField: r0->field_f = d0
    //     0xbf0690: stur            d0, [x0, #0xf]
    // 0xbf0694: LeaveFrame
    //     0xbf0694: mov             SP, fp
    //     0xbf0698: ldp             fp, lr, [SP], #0x10
    // 0xbf069c: ret
    //     0xbf069c: ret             
    // 0xbf06a0: ldr             d0, [fp, #0x10]
    // 0xbf06a4: cmp             w1, NULL
    // 0xbf06a8: b.ne            #0xbf07a8
    // 0xbf06ac: LoadField: d1 = r0->field_7
    //     0xbf06ac: ldur            d1, [x0, #7]
    // 0xbf06b0: r1 = inline_Allocate_Double()
    //     0xbf06b0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf06b4: add             x1, x1, #0x10
    //     0xbf06b8: cmp             x2, x1
    //     0xbf06bc: b.ls            #0xbf0960
    //     0xbf06c0: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf06c4: sub             x1, x1, #0xf
    //     0xbf06c8: mov             x2, #0xd108
    //     0xbf06cc: movk            x2, #3, lsl #16
    //     0xbf06d0: stur            x2, [x1, #-1]
    // 0xbf06d4: StoreField: r1->field_7 = d0
    //     0xbf06d4: stur            d0, [x1, #7]
    // 0xbf06d8: stur            x1, [fp, #-8]
    // 0xbf06dc: r2 = inline_Allocate_Double()
    //     0xbf06dc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf06e0: add             x2, x2, #0x10
    //     0xbf06e4: cmp             x3, x2
    //     0xbf06e8: b.ls            #0xbf097c
    //     0xbf06ec: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf06f0: sub             x2, x2, #0xf
    //     0xbf06f4: mov             x3, #0xd108
    //     0xbf06f8: movk            x3, #3, lsl #16
    //     0xbf06fc: stur            x3, [x2, #-1]
    // 0xbf0700: StoreField: r2->field_7 = d1
    //     0xbf0700: stur            d1, [x2, #7]
    // 0xbf0704: r16 = 0.000000
    //     0xbf0704: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xbf0708: stp             x16, x2, [SP, #-0x10]!
    // 0xbf070c: SaveReg r1
    //     0xbf070c: str             x1, [SP, #-8]!
    // 0xbf0710: r0 = lerpDouble()
    //     0xbf0710: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf0714: add             SP, SP, #0x18
    // 0xbf0718: stur            x0, [fp, #-0x10]
    // 0xbf071c: cmp             w0, NULL
    // 0xbf0720: b.eq            #0xbf0998
    // 0xbf0724: ldr             x2, [fp, #0x20]
    // 0xbf0728: LoadField: d0 = r2->field_f
    //     0xbf0728: ldur            d0, [x2, #0xf]
    // 0xbf072c: r1 = inline_Allocate_Double()
    //     0xbf072c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf0730: add             x1, x1, #0x10
    //     0xbf0734: cmp             x2, x1
    //     0xbf0738: b.ls            #0xbf099c
    //     0xbf073c: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf0740: sub             x1, x1, #0xf
    //     0xbf0744: mov             x2, #0xd108
    //     0xbf0748: movk            x2, #3, lsl #16
    //     0xbf074c: stur            x2, [x1, #-1]
    // 0xbf0750: StoreField: r1->field_7 = d0
    //     0xbf0750: stur            d0, [x1, #7]
    // 0xbf0754: r16 = 0.000000
    //     0xbf0754: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xbf0758: stp             x16, x1, [SP, #-0x10]!
    // 0xbf075c: ldur            x16, [fp, #-8]
    // 0xbf0760: SaveReg r16
    //     0xbf0760: str             x16, [SP, #-8]!
    // 0xbf0764: r0 = lerpDouble()
    //     0xbf0764: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf0768: add             SP, SP, #0x18
    // 0xbf076c: stur            x0, [fp, #-8]
    // 0xbf0770: cmp             w0, NULL
    // 0xbf0774: b.eq            #0xbf09b8
    // 0xbf0778: ldur            x1, [fp, #-0x10]
    // 0xbf077c: LoadField: d0 = r1->field_7
    //     0xbf077c: ldur            d0, [x1, #7]
    // 0xbf0780: stur            d0, [fp, #-0x18]
    // 0xbf0784: r0 = AlignmentDirectional()
    //     0xbf0784: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xbf0788: ldur            d0, [fp, #-0x18]
    // 0xbf078c: StoreField: r0->field_7 = d0
    //     0xbf078c: stur            d0, [x0, #7]
    // 0xbf0790: ldur            x1, [fp, #-8]
    // 0xbf0794: LoadField: d0 = r1->field_7
    //     0xbf0794: ldur            d0, [x1, #7]
    // 0xbf0798: StoreField: r0->field_f = d0
    //     0xbf0798: stur            d0, [x0, #0xf]
    // 0xbf079c: LeaveFrame
    //     0xbf079c: mov             SP, fp
    //     0xbf07a0: ldp             fp, lr, [SP], #0x10
    // 0xbf07a4: ret
    //     0xbf07a4: ret             
    // 0xbf07a8: mov             x2, x0
    // 0xbf07ac: LoadField: d1 = r2->field_7
    //     0xbf07ac: ldur            d1, [x2, #7]
    // 0xbf07b0: LoadField: d2 = r1->field_7
    //     0xbf07b0: ldur            d2, [x1, #7]
    // 0xbf07b4: r0 = inline_Allocate_Double()
    //     0xbf07b4: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xbf07b8: add             x0, x0, #0x10
    //     0xbf07bc: cmp             x3, x0
    //     0xbf07c0: b.ls            #0xbf09bc
    //     0xbf07c4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf07c8: sub             x0, x0, #0xf
    //     0xbf07cc: mov             x3, #0xd108
    //     0xbf07d0: movk            x3, #3, lsl #16
    //     0xbf07d4: stur            x3, [x0, #-1]
    // 0xbf07d8: StoreField: r0->field_7 = d0
    //     0xbf07d8: stur            d0, [x0, #7]
    // 0xbf07dc: stur            x0, [fp, #-8]
    // 0xbf07e0: r3 = inline_Allocate_Double()
    //     0xbf07e0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf07e4: add             x3, x3, #0x10
    //     0xbf07e8: cmp             x4, x3
    //     0xbf07ec: b.ls            #0xbf09dc
    //     0xbf07f0: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf07f4: sub             x3, x3, #0xf
    //     0xbf07f8: mov             x4, #0xd108
    //     0xbf07fc: movk            x4, #3, lsl #16
    //     0xbf0800: stur            x4, [x3, #-1]
    // 0xbf0804: StoreField: r3->field_7 = d1
    //     0xbf0804: stur            d1, [x3, #7]
    // 0xbf0808: r4 = inline_Allocate_Double()
    //     0xbf0808: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf080c: add             x4, x4, #0x10
    //     0xbf0810: cmp             x5, x4
    //     0xbf0814: b.ls            #0xbf0a00
    //     0xbf0818: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf081c: sub             x4, x4, #0xf
    //     0xbf0820: mov             x5, #0xd108
    //     0xbf0824: movk            x5, #3, lsl #16
    //     0xbf0828: stur            x5, [x4, #-1]
    // 0xbf082c: StoreField: r4->field_7 = d2
    //     0xbf082c: stur            d2, [x4, #7]
    // 0xbf0830: stp             x4, x3, [SP, #-0x10]!
    // 0xbf0834: SaveReg r0
    //     0xbf0834: str             x0, [SP, #-8]!
    // 0xbf0838: r0 = lerpDouble()
    //     0xbf0838: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf083c: add             SP, SP, #0x18
    // 0xbf0840: stur            x0, [fp, #-0x10]
    // 0xbf0844: cmp             w0, NULL
    // 0xbf0848: b.eq            #0xbf0a24
    // 0xbf084c: ldr             x1, [fp, #0x20]
    // 0xbf0850: LoadField: d0 = r1->field_f
    //     0xbf0850: ldur            d0, [x1, #0xf]
    // 0xbf0854: ldr             x1, [fp, #0x18]
    // 0xbf0858: LoadField: d1 = r1->field_f
    //     0xbf0858: ldur            d1, [x1, #0xf]
    // 0xbf085c: r1 = inline_Allocate_Double()
    //     0xbf085c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf0860: add             x1, x1, #0x10
    //     0xbf0864: cmp             x2, x1
    //     0xbf0868: b.ls            #0xbf0a28
    //     0xbf086c: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf0870: sub             x1, x1, #0xf
    //     0xbf0874: mov             x2, #0xd108
    //     0xbf0878: movk            x2, #3, lsl #16
    //     0xbf087c: stur            x2, [x1, #-1]
    // 0xbf0880: StoreField: r1->field_7 = d0
    //     0xbf0880: stur            d0, [x1, #7]
    // 0xbf0884: r2 = inline_Allocate_Double()
    //     0xbf0884: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf0888: add             x2, x2, #0x10
    //     0xbf088c: cmp             x3, x2
    //     0xbf0890: b.ls            #0xbf0a44
    //     0xbf0894: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf0898: sub             x2, x2, #0xf
    //     0xbf089c: mov             x3, #0xd108
    //     0xbf08a0: movk            x3, #3, lsl #16
    //     0xbf08a4: stur            x3, [x2, #-1]
    // 0xbf08a8: StoreField: r2->field_7 = d1
    //     0xbf08a8: stur            d1, [x2, #7]
    // 0xbf08ac: stp             x2, x1, [SP, #-0x10]!
    // 0xbf08b0: ldur            x16, [fp, #-8]
    // 0xbf08b4: SaveReg r16
    //     0xbf08b4: str             x16, [SP, #-8]!
    // 0xbf08b8: r0 = lerpDouble()
    //     0xbf08b8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf08bc: add             SP, SP, #0x18
    // 0xbf08c0: stur            x0, [fp, #-8]
    // 0xbf08c4: cmp             w0, NULL
    // 0xbf08c8: b.eq            #0xbf0a60
    // 0xbf08cc: ldur            x1, [fp, #-0x10]
    // 0xbf08d0: LoadField: d0 = r1->field_7
    //     0xbf08d0: ldur            d0, [x1, #7]
    // 0xbf08d4: stur            d0, [fp, #-0x18]
    // 0xbf08d8: r0 = AlignmentDirectional()
    //     0xbf08d8: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xbf08dc: ldur            d0, [fp, #-0x18]
    // 0xbf08e0: StoreField: r0->field_7 = d0
    //     0xbf08e0: stur            d0, [x0, #7]
    // 0xbf08e4: ldur            x1, [fp, #-8]
    // 0xbf08e8: LoadField: d0 = r1->field_7
    //     0xbf08e8: ldur            d0, [x1, #7]
    // 0xbf08ec: StoreField: r0->field_f = d0
    //     0xbf08ec: stur            d0, [x0, #0xf]
    // 0xbf08f0: LeaveFrame
    //     0xbf08f0: mov             SP, fp
    //     0xbf08f4: ldp             fp, lr, [SP], #0x10
    // 0xbf08f8: ret
    //     0xbf08f8: ret             
    // 0xbf08fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf08fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0900: b               #0xbf0564
    // 0xbf0904: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf0904: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbf0908: stp             q0, q1, [SP, #-0x20]!
    // 0xbf090c: SaveReg r1
    //     0xbf090c: str             x1, [SP, #-8]!
    // 0xbf0910: r0 = AllocateDouble()
    //     0xbf0910: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0914: RestoreReg r1
    //     0xbf0914: ldr             x1, [SP], #8
    // 0xbf0918: ldp             q0, q1, [SP], #0x20
    // 0xbf091c: b               #0xbf05cc
    // 0xbf0920: SaveReg d1
    //     0xbf0920: str             q1, [SP, #-0x10]!
    // 0xbf0924: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0928: r0 = AllocateDouble()
    //     0xbf0928: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf092c: mov             x2, x0
    // 0xbf0930: ldp             x0, x1, [SP], #0x10
    // 0xbf0934: RestoreReg d1
    //     0xbf0934: ldr             q1, [SP], #0x10
    // 0xbf0938: b               #0xbf05f8
    // 0xbf093c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf093c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0940: SaveReg d0
    //     0xbf0940: str             q0, [SP, #-0x10]!
    // 0xbf0944: SaveReg r0
    //     0xbf0944: str             x0, [SP, #-8]!
    // 0xbf0948: r0 = AllocateDouble()
    //     0xbf0948: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf094c: mov             x1, x0
    // 0xbf0950: RestoreReg r0
    //     0xbf0950: ldr             x0, [SP], #8
    // 0xbf0954: RestoreReg d0
    //     0xbf0954: ldr             q0, [SP], #0x10
    // 0xbf0958: b               #0xbf0648
    // 0xbf095c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf095c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0960: stp             q0, q1, [SP, #-0x20]!
    // 0xbf0964: SaveReg r0
    //     0xbf0964: str             x0, [SP, #-8]!
    // 0xbf0968: r0 = AllocateDouble()
    //     0xbf0968: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf096c: mov             x1, x0
    // 0xbf0970: RestoreReg r0
    //     0xbf0970: ldr             x0, [SP], #8
    // 0xbf0974: ldp             q0, q1, [SP], #0x20
    // 0xbf0978: b               #0xbf06d4
    // 0xbf097c: SaveReg d1
    //     0xbf097c: str             q1, [SP, #-0x10]!
    // 0xbf0980: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0984: r0 = AllocateDouble()
    //     0xbf0984: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0988: mov             x2, x0
    // 0xbf098c: ldp             x0, x1, [SP], #0x10
    // 0xbf0990: RestoreReg d1
    //     0xbf0990: ldr             q1, [SP], #0x10
    // 0xbf0994: b               #0xbf0700
    // 0xbf0998: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0998: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf099c: SaveReg d0
    //     0xbf099c: str             q0, [SP, #-0x10]!
    // 0xbf09a0: SaveReg r0
    //     0xbf09a0: str             x0, [SP, #-8]!
    // 0xbf09a4: r0 = AllocateDouble()
    //     0xbf09a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf09a8: mov             x1, x0
    // 0xbf09ac: RestoreReg r0
    //     0xbf09ac: ldr             x0, [SP], #8
    // 0xbf09b0: RestoreReg d0
    //     0xbf09b0: ldr             q0, [SP], #0x10
    // 0xbf09b4: b               #0xbf0750
    // 0xbf09b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf09b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf09bc: stp             q1, q2, [SP, #-0x20]!
    // 0xbf09c0: SaveReg d0
    //     0xbf09c0: str             q0, [SP, #-0x10]!
    // 0xbf09c4: stp             x1, x2, [SP, #-0x10]!
    // 0xbf09c8: r0 = AllocateDouble()
    //     0xbf09c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf09cc: ldp             x1, x2, [SP], #0x10
    // 0xbf09d0: RestoreReg d0
    //     0xbf09d0: ldr             q0, [SP], #0x10
    // 0xbf09d4: ldp             q1, q2, [SP], #0x20
    // 0xbf09d8: b               #0xbf07d8
    // 0xbf09dc: stp             q1, q2, [SP, #-0x20]!
    // 0xbf09e0: stp             x1, x2, [SP, #-0x10]!
    // 0xbf09e4: SaveReg r0
    //     0xbf09e4: str             x0, [SP, #-8]!
    // 0xbf09e8: r0 = AllocateDouble()
    //     0xbf09e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf09ec: mov             x3, x0
    // 0xbf09f0: RestoreReg r0
    //     0xbf09f0: ldr             x0, [SP], #8
    // 0xbf09f4: ldp             x1, x2, [SP], #0x10
    // 0xbf09f8: ldp             q1, q2, [SP], #0x20
    // 0xbf09fc: b               #0xbf0804
    // 0xbf0a00: SaveReg d2
    //     0xbf0a00: str             q2, [SP, #-0x10]!
    // 0xbf0a04: stp             x2, x3, [SP, #-0x10]!
    // 0xbf0a08: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0a0c: r0 = AllocateDouble()
    //     0xbf0a0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0a10: mov             x4, x0
    // 0xbf0a14: ldp             x0, x1, [SP], #0x10
    // 0xbf0a18: ldp             x2, x3, [SP], #0x10
    // 0xbf0a1c: RestoreReg d2
    //     0xbf0a1c: ldr             q2, [SP], #0x10
    // 0xbf0a20: b               #0xbf082c
    // 0xbf0a24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0a24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0a28: stp             q0, q1, [SP, #-0x20]!
    // 0xbf0a2c: SaveReg r0
    //     0xbf0a2c: str             x0, [SP, #-8]!
    // 0xbf0a30: r0 = AllocateDouble()
    //     0xbf0a30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0a34: mov             x1, x0
    // 0xbf0a38: RestoreReg r0
    //     0xbf0a38: ldr             x0, [SP], #8
    // 0xbf0a3c: ldp             q0, q1, [SP], #0x20
    // 0xbf0a40: b               #0xbf0880
    // 0xbf0a44: SaveReg d1
    //     0xbf0a44: str             q1, [SP, #-0x10]!
    // 0xbf0a48: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0a4c: r0 = AllocateDouble()
    //     0xbf0a4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0a50: mov             x2, x0
    // 0xbf0a54: ldp             x0, x1, [SP], #0x10
    // 0xbf0a58: RestoreReg d1
    //     0xbf0a58: ldr             q1, [SP], #0x10
    // 0xbf0a5c: b               #0xbf08a8
    // 0xbf0a60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0a60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  AlignmentDirectional *(AlignmentDirectional, double) {
    // ** addr: 0xcfae10, size: 0x50
    // 0xcfae10: EnterFrame
    //     0xcfae10: stp             fp, lr, [SP, #-0x10]!
    //     0xcfae14: mov             fp, SP
    // 0xcfae18: AllocStack(0x10)
    //     0xcfae18: sub             SP, SP, #0x10
    // 0xcfae1c: ldr             x0, [fp, #0x18]
    // 0xcfae20: LoadField: d0 = r0->field_7
    //     0xcfae20: ldur            d0, [x0, #7]
    // 0xcfae24: ldr             x1, [fp, #0x10]
    // 0xcfae28: LoadField: d1 = r1->field_7
    //     0xcfae28: ldur            d1, [x1, #7]
    // 0xcfae2c: fmul            d2, d0, d1
    // 0xcfae30: stur            d2, [fp, #-0x10]
    // 0xcfae34: LoadField: d0 = r0->field_f
    //     0xcfae34: ldur            d0, [x0, #0xf]
    // 0xcfae38: fmul            d3, d0, d1
    // 0xcfae3c: stur            d3, [fp, #-8]
    // 0xcfae40: r0 = AlignmentDirectional()
    //     0xcfae40: bl              #0x625948  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xcfae44: ldur            d0, [fp, #-0x10]
    // 0xcfae48: StoreField: r0->field_7 = d0
    //     0xcfae48: stur            d0, [x0, #7]
    // 0xcfae4c: ldur            d0, [fp, #-8]
    // 0xcfae50: StoreField: r0->field_f = d0
    //     0xcfae50: stur            d0, [x0, #0xf]
    // 0xcfae54: LeaveFrame
    //     0xcfae54: mov             SP, fp
    //     0xcfae58: ldp             fp, lr, [SP], #0x10
    // 0xcfae5c: ret
    //     0xcfae5c: ret             
  }
  _ resolve(/* No info */) {
    // ** addr: 0xcfb55c, size: 0x94
    // 0xcfb55c: EnterFrame
    //     0xcfb55c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfb560: mov             fp, SP
    // 0xcfb564: AllocStack(0x10)
    //     0xcfb564: sub             SP, SP, #0x10
    // 0xcfb568: ldr             x0, [fp, #0x10]
    // 0xcfb56c: cmp             w0, NULL
    // 0xcfb570: b.eq            #0xcfb5ec
    // 0xcfb574: LoadField: r1 = r0->field_7
    //     0xcfb574: ldur            x1, [x0, #7]
    // 0xcfb578: cmp             x1, #0
    // 0xcfb57c: b.gt            #0xcfb5b8
    // 0xcfb580: ldr             x0, [fp, #0x18]
    // 0xcfb584: LoadField: d0 = r0->field_7
    //     0xcfb584: ldur            d0, [x0, #7]
    // 0xcfb588: fneg            d1, d0
    // 0xcfb58c: stur            d1, [fp, #-0x10]
    // 0xcfb590: LoadField: d0 = r0->field_f
    //     0xcfb590: ldur            d0, [x0, #0xf]
    // 0xcfb594: stur            d0, [fp, #-8]
    // 0xcfb598: r0 = Alignment()
    //     0xcfb598: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xcfb59c: ldur            d0, [fp, #-0x10]
    // 0xcfb5a0: StoreField: r0->field_7 = d0
    //     0xcfb5a0: stur            d0, [x0, #7]
    // 0xcfb5a4: ldur            d0, [fp, #-8]
    // 0xcfb5a8: StoreField: r0->field_f = d0
    //     0xcfb5a8: stur            d0, [x0, #0xf]
    // 0xcfb5ac: LeaveFrame
    //     0xcfb5ac: mov             SP, fp
    //     0xcfb5b0: ldp             fp, lr, [SP], #0x10
    // 0xcfb5b4: ret
    //     0xcfb5b4: ret             
    // 0xcfb5b8: ldr             x0, [fp, #0x18]
    // 0xcfb5bc: LoadField: d0 = r0->field_7
    //     0xcfb5bc: ldur            d0, [x0, #7]
    // 0xcfb5c0: stur            d0, [fp, #-0x10]
    // 0xcfb5c4: LoadField: d1 = r0->field_f
    //     0xcfb5c4: ldur            d1, [x0, #0xf]
    // 0xcfb5c8: stur            d1, [fp, #-8]
    // 0xcfb5cc: r0 = Alignment()
    //     0xcfb5cc: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xcfb5d0: ldur            d0, [fp, #-0x10]
    // 0xcfb5d4: StoreField: r0->field_7 = d0
    //     0xcfb5d4: stur            d0, [x0, #7]
    // 0xcfb5d8: ldur            d0, [fp, #-8]
    // 0xcfb5dc: StoreField: r0->field_f = d0
    //     0xcfb5dc: stur            d0, [x0, #0xf]
    // 0xcfb5e0: LeaveFrame
    //     0xcfb5e0: mov             SP, fp
    //     0xcfb5e4: ldp             fp, lr, [SP], #0x10
    // 0xcfb5e8: ret
    //     0xcfb5e8: ret             
    // 0xcfb5ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcfb5ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2119, size: 0x18, field offset: 0x8
//   const constructor, 
class Alignment extends AlignmentGeometry {

  _Mint field_8;
  _Mint field_10;

  Alignment /(Alignment, double) {
    // ** addr: 0x594870, size: 0x88
    // 0x594870: EnterFrame
    //     0x594870: stp             fp, lr, [SP, #-0x10]!
    //     0x594874: mov             fp, SP
    // 0x594878: CheckStackOverflow
    //     0x594878: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59487c: cmp             SP, x16
    //     0x594880: b.ls            #0x5948d8
    // 0x594884: ldr             x0, [fp, #0x10]
    // 0x594888: r2 = Null
    //     0x594888: mov             x2, NULL
    // 0x59488c: r1 = Null
    //     0x59488c: mov             x1, NULL
    // 0x594890: r4 = 59
    //     0x594890: mov             x4, #0x3b
    // 0x594894: branchIfSmi(r0, 0x5948a0)
    //     0x594894: tbz             w0, #0, #0x5948a0
    // 0x594898: r4 = LoadClassIdInstr(r0)
    //     0x594898: ldur            x4, [x0, #-1]
    //     0x59489c: ubfx            x4, x4, #0xc, #0x14
    // 0x5948a0: cmp             x4, #0x3d
    // 0x5948a4: b.eq            #0x5948b8
    // 0x5948a8: r8 = double
    //     0x5948a8: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x5948ac: r3 = Null
    //     0x5948ac: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b488] Null
    //     0x5948b0: ldr             x3, [x3, #0x488]
    // 0x5948b4: r0 = double()
    //     0x5948b4: bl              #0xd72bac  ; IsType_double_Stub
    // 0x5948b8: ldr             x16, [fp, #0x18]
    // 0x5948bc: ldr             lr, [fp, #0x10]
    // 0x5948c0: stp             lr, x16, [SP, #-0x10]!
    // 0x5948c4: r0 = /()
    //     0x5948c4: bl              #0x5948e0  ; [package:flutter/src/painting/alignment.dart] Alignment::/
    // 0x5948c8: add             SP, SP, #0x10
    // 0x5948cc: LeaveFrame
    //     0x5948cc: mov             SP, fp
    //     0x5948d0: ldp             fp, lr, [SP], #0x10
    // 0x5948d4: ret
    //     0x5948d4: ret             
    // 0x5948d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5948d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5948dc: b               #0x594884
  }
  Alignment /(Alignment, double) {
    // ** addr: 0x5948e0, size: 0x50
    // 0x5948e0: EnterFrame
    //     0x5948e0: stp             fp, lr, [SP, #-0x10]!
    //     0x5948e4: mov             fp, SP
    // 0x5948e8: AllocStack(0x10)
    //     0x5948e8: sub             SP, SP, #0x10
    // 0x5948ec: ldr             x0, [fp, #0x18]
    // 0x5948f0: LoadField: d0 = r0->field_7
    //     0x5948f0: ldur            d0, [x0, #7]
    // 0x5948f4: ldr             x1, [fp, #0x10]
    // 0x5948f8: LoadField: d1 = r1->field_7
    //     0x5948f8: ldur            d1, [x1, #7]
    // 0x5948fc: fdiv            d2, d0, d1
    // 0x594900: stur            d2, [fp, #-0x10]
    // 0x594904: LoadField: d0 = r0->field_f
    //     0x594904: ldur            d0, [x0, #0xf]
    // 0x594908: fdiv            d3, d0, d1
    // 0x59490c: stur            d3, [fp, #-8]
    // 0x594910: r0 = Alignment()
    //     0x594910: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x594914: ldur            d0, [fp, #-0x10]
    // 0x594918: StoreField: r0->field_7 = d0
    //     0x594918: stur            d0, [x0, #7]
    // 0x59491c: ldur            d0, [fp, #-8]
    // 0x594920: StoreField: r0->field_f = d0
    //     0x594920: stur            d0, [x0, #0xf]
    // 0x594924: LeaveFrame
    //     0x594924: mov             SP, fp
    //     0x594928: ldp             fp, lr, [SP], #0x10
    // 0x59492c: ret
    //     0x59492c: ret             
  }
  Alignment *(Alignment, double) {
    // ** addr: 0x594954, size: 0x88
    // 0x594954: EnterFrame
    //     0x594954: stp             fp, lr, [SP, #-0x10]!
    //     0x594958: mov             fp, SP
    // 0x59495c: CheckStackOverflow
    //     0x59495c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x594960: cmp             SP, x16
    //     0x594964: b.ls            #0x5949bc
    // 0x594968: ldr             x0, [fp, #0x10]
    // 0x59496c: r2 = Null
    //     0x59496c: mov             x2, NULL
    // 0x594970: r1 = Null
    //     0x594970: mov             x1, NULL
    // 0x594974: r4 = 59
    //     0x594974: mov             x4, #0x3b
    // 0x594978: branchIfSmi(r0, 0x594984)
    //     0x594978: tbz             w0, #0, #0x594984
    // 0x59497c: r4 = LoadClassIdInstr(r0)
    //     0x59497c: ldur            x4, [x0, #-1]
    //     0x594980: ubfx            x4, x4, #0xc, #0x14
    // 0x594984: cmp             x4, #0x3d
    // 0x594988: b.eq            #0x59499c
    // 0x59498c: r8 = double
    //     0x59498c: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0x594990: r3 = Null
    //     0x594990: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2db28] Null
    //     0x594994: ldr             x3, [x3, #0xb28]
    // 0x594998: r0 = double()
    //     0x594998: bl              #0xd72bac  ; IsType_double_Stub
    // 0x59499c: ldr             x16, [fp, #0x18]
    // 0x5949a0: ldr             lr, [fp, #0x10]
    // 0x5949a4: stp             lr, x16, [SP, #-0x10]!
    // 0x5949a8: r0 = *()
    //     0x5949a8: bl              #0xcfadc0  ; [package:flutter/src/painting/alignment.dart] Alignment::*
    // 0x5949ac: add             SP, SP, #0x10
    // 0x5949b0: LeaveFrame
    //     0x5949b0: mov             SP, fp
    //     0x5949b4: ldp             fp, lr, [SP], #0x10
    // 0x5949b8: ret
    //     0x5949b8: ret             
    // 0x5949bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5949bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5949c0: b               #0x594968
  }
  Alignment +(Alignment, Alignment) {
    // ** addr: 0x5949dc, size: 0x90
    // 0x5949dc: EnterFrame
    //     0x5949dc: stp             fp, lr, [SP, #-0x10]!
    //     0x5949e0: mov             fp, SP
    // 0x5949e4: CheckStackOverflow
    //     0x5949e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5949e8: cmp             SP, x16
    //     0x5949ec: b.ls            #0x594a4c
    // 0x5949f0: ldr             x0, [fp, #0x10]
    // 0x5949f4: r2 = Null
    //     0x5949f4: mov             x2, NULL
    // 0x5949f8: r1 = Null
    //     0x5949f8: mov             x1, NULL
    // 0x5949fc: r4 = 59
    //     0x5949fc: mov             x4, #0x3b
    // 0x594a00: branchIfSmi(r0, 0x594a0c)
    //     0x594a00: tbz             w0, #0, #0x594a0c
    // 0x594a04: r4 = LoadClassIdInstr(r0)
    //     0x594a04: ldur            x4, [x0, #-1]
    //     0x594a08: ubfx            x4, x4, #0xc, #0x14
    // 0x594a0c: sub             x4, x4, #0x847
    // 0x594a10: cmp             x4, #1
    // 0x594a14: b.ls            #0x594a2c
    // 0x594a18: r8 = Alignment
    //     0x594a18: add             x8, PP, #0x28, lsl #12  ; [pp+0x288d8] Type: Alignment
    //     0x594a1c: ldr             x8, [x8, #0x8d8]
    // 0x594a20: r3 = Null
    //     0x594a20: add             x3, PP, #0x28, lsl #12  ; [pp+0x288e0] Null
    //     0x594a24: ldr             x3, [x3, #0x8e0]
    // 0x594a28: r0 = DefaultTypeTest()
    //     0x594a28: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x594a2c: ldr             x16, [fp, #0x18]
    // 0x594a30: ldr             lr, [fp, #0x10]
    // 0x594a34: stp             lr, x16, [SP, #-0x10]!
    // 0x594a38: r0 = +()
    //     0x594a38: bl              #0x594a54  ; [package:flutter/src/painting/alignment.dart] Alignment::+
    // 0x594a3c: add             SP, SP, #0x10
    // 0x594a40: LeaveFrame
    //     0x594a40: mov             SP, fp
    //     0x594a44: ldp             fp, lr, [SP], #0x10
    // 0x594a48: ret
    //     0x594a48: ret             
    // 0x594a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x594a4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x594a50: b               #0x5949f0
  }
  Alignment +(Alignment, Alignment) {
    // ** addr: 0x594a54, size: 0x54
    // 0x594a54: EnterFrame
    //     0x594a54: stp             fp, lr, [SP, #-0x10]!
    //     0x594a58: mov             fp, SP
    // 0x594a5c: AllocStack(0x10)
    //     0x594a5c: sub             SP, SP, #0x10
    // 0x594a60: ldr             x0, [fp, #0x18]
    // 0x594a64: LoadField: d0 = r0->field_7
    //     0x594a64: ldur            d0, [x0, #7]
    // 0x594a68: ldr             x1, [fp, #0x10]
    // 0x594a6c: LoadField: d1 = r1->field_7
    //     0x594a6c: ldur            d1, [x1, #7]
    // 0x594a70: fadd            d2, d0, d1
    // 0x594a74: stur            d2, [fp, #-0x10]
    // 0x594a78: LoadField: d0 = r0->field_f
    //     0x594a78: ldur            d0, [x0, #0xf]
    // 0x594a7c: LoadField: d1 = r1->field_f
    //     0x594a7c: ldur            d1, [x1, #0xf]
    // 0x594a80: fadd            d3, d0, d1
    // 0x594a84: stur            d3, [fp, #-8]
    // 0x594a88: r0 = Alignment()
    //     0x594a88: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x594a8c: ldur            d0, [fp, #-0x10]
    // 0x594a90: StoreField: r0->field_7 = d0
    //     0x594a90: stur            d0, [x0, #7]
    // 0x594a94: ldur            d0, [fp, #-8]
    // 0x594a98: StoreField: r0->field_f = d0
    //     0x594a98: stur            d0, [x0, #0xf]
    // 0x594a9c: LeaveFrame
    //     0x594a9c: mov             SP, fp
    //     0x594aa0: ldp             fp, lr, [SP], #0x10
    // 0x594aa4: ret
    //     0x594aa4: ret             
  }
  Alignment -(Alignment, Alignment) {
    // ** addr: 0x594ac0, size: 0x90
    // 0x594ac0: EnterFrame
    //     0x594ac0: stp             fp, lr, [SP, #-0x10]!
    //     0x594ac4: mov             fp, SP
    // 0x594ac8: CheckStackOverflow
    //     0x594ac8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x594acc: cmp             SP, x16
    //     0x594ad0: b.ls            #0x594b30
    // 0x594ad4: ldr             x0, [fp, #0x10]
    // 0x594ad8: r2 = Null
    //     0x594ad8: mov             x2, NULL
    // 0x594adc: r1 = Null
    //     0x594adc: mov             x1, NULL
    // 0x594ae0: r4 = 59
    //     0x594ae0: mov             x4, #0x3b
    // 0x594ae4: branchIfSmi(r0, 0x594af0)
    //     0x594ae4: tbz             w0, #0, #0x594af0
    // 0x594ae8: r4 = LoadClassIdInstr(r0)
    //     0x594ae8: ldur            x4, [x0, #-1]
    //     0x594aec: ubfx            x4, x4, #0xc, #0x14
    // 0x594af0: sub             x4, x4, #0x847
    // 0x594af4: cmp             x4, #1
    // 0x594af8: b.ls            #0x594b10
    // 0x594afc: r8 = Alignment
    //     0x594afc: add             x8, PP, #0x28, lsl #12  ; [pp+0x288d8] Type: Alignment
    //     0x594b00: ldr             x8, [x8, #0x8d8]
    // 0x594b04: r3 = Null
    //     0x594b04: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2db38] Null
    //     0x594b08: ldr             x3, [x3, #0xb38]
    // 0x594b0c: r0 = DefaultTypeTest()
    //     0x594b0c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x594b10: ldr             x16, [fp, #0x18]
    // 0x594b14: ldr             lr, [fp, #0x10]
    // 0x594b18: stp             lr, x16, [SP, #-0x10]!
    // 0x594b1c: r0 = -()
    //     0x594b1c: bl              #0x594b38  ; [package:flutter/src/painting/alignment.dart] Alignment::-
    // 0x594b20: add             SP, SP, #0x10
    // 0x594b24: LeaveFrame
    //     0x594b24: mov             SP, fp
    //     0x594b28: ldp             fp, lr, [SP], #0x10
    // 0x594b2c: ret
    //     0x594b2c: ret             
    // 0x594b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x594b30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x594b34: b               #0x594ad4
  }
  Alignment -(Alignment, Alignment) {
    // ** addr: 0x594b38, size: 0x54
    // 0x594b38: EnterFrame
    //     0x594b38: stp             fp, lr, [SP, #-0x10]!
    //     0x594b3c: mov             fp, SP
    // 0x594b40: AllocStack(0x10)
    //     0x594b40: sub             SP, SP, #0x10
    // 0x594b44: ldr             x0, [fp, #0x18]
    // 0x594b48: LoadField: d0 = r0->field_7
    //     0x594b48: ldur            d0, [x0, #7]
    // 0x594b4c: ldr             x1, [fp, #0x10]
    // 0x594b50: LoadField: d1 = r1->field_7
    //     0x594b50: ldur            d1, [x1, #7]
    // 0x594b54: fsub            d2, d0, d1
    // 0x594b58: stur            d2, [fp, #-0x10]
    // 0x594b5c: LoadField: d0 = r0->field_f
    //     0x594b5c: ldur            d0, [x0, #0xf]
    // 0x594b60: LoadField: d1 = r1->field_f
    //     0x594b60: ldur            d1, [x1, #0xf]
    // 0x594b64: fsub            d3, d0, d1
    // 0x594b68: stur            d3, [fp, #-8]
    // 0x594b6c: r0 = Alignment()
    //     0x594b6c: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0x594b70: ldur            d0, [fp, #-0x10]
    // 0x594b74: StoreField: r0->field_7 = d0
    //     0x594b74: stur            d0, [x0, #7]
    // 0x594b78: ldur            d0, [fp, #-8]
    // 0x594b7c: StoreField: r0->field_f = d0
    //     0x594b7c: stur            d0, [x0, #0xf]
    // 0x594b80: LeaveFrame
    //     0x594b80: mov             SP, fp
    //     0x594b84: ldp             fp, lr, [SP], #0x10
    // 0x594b88: ret
    //     0x594b88: ret             
  }
  _ alongOffset(/* No info */) {
    // ** addr: 0x626350, size: 0x68
    // 0x626350: EnterFrame
    //     0x626350: stp             fp, lr, [SP, #-0x10]!
    //     0x626354: mov             fp, SP
    // 0x626358: AllocStack(0x10)
    //     0x626358: sub             SP, SP, #0x10
    // 0x62635c: d0 = 2.000000
    //     0x62635c: fmov            d0, #2.00000000
    // 0x626360: ldr             x0, [fp, #0x10]
    // 0x626364: LoadField: d1 = r0->field_7
    //     0x626364: ldur            d1, [x0, #7]
    // 0x626368: fdiv            d2, d1, d0
    // 0x62636c: LoadField: d1 = r0->field_f
    //     0x62636c: ldur            d1, [x0, #0xf]
    // 0x626370: fdiv            d3, d1, d0
    // 0x626374: ldr             x0, [fp, #0x18]
    // 0x626378: LoadField: d0 = r0->field_7
    //     0x626378: ldur            d0, [x0, #7]
    // 0x62637c: fmul            d1, d0, d2
    // 0x626380: fadd            d0, d2, d1
    // 0x626384: stur            d0, [fp, #-0x10]
    // 0x626388: LoadField: d1 = r0->field_f
    //     0x626388: ldur            d1, [x0, #0xf]
    // 0x62638c: fmul            d2, d1, d3
    // 0x626390: fadd            d1, d3, d2
    // 0x626394: stur            d1, [fp, #-8]
    // 0x626398: r0 = Offset()
    //     0x626398: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x62639c: ldur            d0, [fp, #-0x10]
    // 0x6263a0: StoreField: r0->field_7 = d0
    //     0x6263a0: stur            d0, [x0, #7]
    // 0x6263a4: ldur            d0, [fp, #-8]
    // 0x6263a8: StoreField: r0->field_f = d0
    //     0x6263a8: stur            d0, [x0, #0xf]
    // 0x6263ac: LeaveFrame
    //     0x6263ac: mov             SP, fp
    //     0x6263b0: ldp             fp, lr, [SP], #0x10
    // 0x6263b4: ret
    //     0x6263b4: ret             
  }
  _ inscribe(/* No info */) {
    // ** addr: 0x626960, size: 0xb4
    // 0x626960: EnterFrame
    //     0x626960: stp             fp, lr, [SP, #-0x10]!
    //     0x626964: mov             fp, SP
    // 0x626968: AllocStack(0x20)
    //     0x626968: sub             SP, SP, #0x20
    // 0x62696c: d0 = 2.000000
    //     0x62696c: fmov            d0, #2.00000000
    // 0x626970: ldr             x0, [fp, #0x10]
    // 0x626974: LoadField: d1 = r0->field_17
    //     0x626974: ldur            d1, [x0, #0x17]
    // 0x626978: LoadField: d2 = r0->field_7
    //     0x626978: ldur            d2, [x0, #7]
    // 0x62697c: fsub            d3, d1, d2
    // 0x626980: ldr             x1, [fp, #0x18]
    // 0x626984: LoadField: d1 = r1->field_7
    //     0x626984: ldur            d1, [x1, #7]
    // 0x626988: fsub            d4, d3, d1
    // 0x62698c: fdiv            d3, d4, d0
    // 0x626990: LoadField: d4 = r0->field_1f
    //     0x626990: ldur            d4, [x0, #0x1f]
    // 0x626994: LoadField: d5 = r0->field_f
    //     0x626994: ldur            d5, [x0, #0xf]
    // 0x626998: fsub            d6, d4, d5
    // 0x62699c: LoadField: d4 = r1->field_f
    //     0x62699c: ldur            d4, [x1, #0xf]
    // 0x6269a0: fsub            d7, d6, d4
    // 0x6269a4: fdiv            d6, d7, d0
    // 0x6269a8: fadd            d0, d2, d3
    // 0x6269ac: ldr             x0, [fp, #0x20]
    // 0x6269b0: LoadField: d2 = r0->field_7
    //     0x6269b0: ldur            d2, [x0, #7]
    // 0x6269b4: fmul            d7, d2, d3
    // 0x6269b8: fadd            d2, d0, d7
    // 0x6269bc: stur            d2, [fp, #-0x20]
    // 0x6269c0: fadd            d0, d5, d6
    // 0x6269c4: LoadField: d3 = r0->field_f
    //     0x6269c4: ldur            d3, [x0, #0xf]
    // 0x6269c8: fmul            d5, d3, d6
    // 0x6269cc: fadd            d3, d0, d5
    // 0x6269d0: stur            d3, [fp, #-0x18]
    // 0x6269d4: fadd            d0, d2, d1
    // 0x6269d8: stur            d0, [fp, #-0x10]
    // 0x6269dc: fadd            d1, d3, d4
    // 0x6269e0: stur            d1, [fp, #-8]
    // 0x6269e4: r0 = Rect()
    //     0x6269e4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x6269e8: ldur            d0, [fp, #-0x20]
    // 0x6269ec: StoreField: r0->field_7 = d0
    //     0x6269ec: stur            d0, [x0, #7]
    // 0x6269f0: ldur            d0, [fp, #-0x18]
    // 0x6269f4: StoreField: r0->field_f = d0
    //     0x6269f4: stur            d0, [x0, #0xf]
    // 0x6269f8: ldur            d0, [fp, #-0x10]
    // 0x6269fc: StoreField: r0->field_17 = d0
    //     0x6269fc: stur            d0, [x0, #0x17]
    // 0x626a00: ldur            d0, [fp, #-8]
    // 0x626a04: StoreField: r0->field_1f = d0
    //     0x626a04: stur            d0, [x0, #0x1f]
    // 0x626a08: LeaveFrame
    //     0x626a08: mov             SP, fp
    //     0x626a0c: ldp             fp, lr, [SP], #0x10
    // 0x626a10: ret
    //     0x626a10: ret             
  }
  _ withinRect(/* No info */) {
    // ** addr: 0xa75430, size: 0x80
    // 0xa75430: EnterFrame
    //     0xa75430: stp             fp, lr, [SP, #-0x10]!
    //     0xa75434: mov             fp, SP
    // 0xa75438: AllocStack(0x10)
    //     0xa75438: sub             SP, SP, #0x10
    // 0xa7543c: d0 = 2.000000
    //     0xa7543c: fmov            d0, #2.00000000
    // 0xa75440: ldr             x0, [fp, #0x10]
    // 0xa75444: LoadField: d1 = r0->field_17
    //     0xa75444: ldur            d1, [x0, #0x17]
    // 0xa75448: LoadField: d2 = r0->field_7
    //     0xa75448: ldur            d2, [x0, #7]
    // 0xa7544c: fsub            d3, d1, d2
    // 0xa75450: fdiv            d1, d3, d0
    // 0xa75454: LoadField: d3 = r0->field_1f
    //     0xa75454: ldur            d3, [x0, #0x1f]
    // 0xa75458: LoadField: d4 = r0->field_f
    //     0xa75458: ldur            d4, [x0, #0xf]
    // 0xa7545c: fsub            d5, d3, d4
    // 0xa75460: fdiv            d3, d5, d0
    // 0xa75464: fadd            d0, d2, d1
    // 0xa75468: ldr             x0, [fp, #0x18]
    // 0xa7546c: LoadField: d2 = r0->field_7
    //     0xa7546c: ldur            d2, [x0, #7]
    // 0xa75470: fmul            d5, d2, d1
    // 0xa75474: fadd            d1, d0, d5
    // 0xa75478: stur            d1, [fp, #-0x10]
    // 0xa7547c: fadd            d0, d4, d3
    // 0xa75480: LoadField: d2 = r0->field_f
    //     0xa75480: ldur            d2, [x0, #0xf]
    // 0xa75484: fmul            d4, d2, d3
    // 0xa75488: fadd            d2, d0, d4
    // 0xa7548c: stur            d2, [fp, #-8]
    // 0xa75490: r0 = Offset()
    //     0xa75490: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa75494: ldur            d0, [fp, #-0x10]
    // 0xa75498: StoreField: r0->field_7 = d0
    //     0xa75498: stur            d0, [x0, #7]
    // 0xa7549c: ldur            d0, [fp, #-8]
    // 0xa754a0: StoreField: r0->field_f = d0
    //     0xa754a0: stur            d0, [x0, #0xf]
    // 0xa754a4: LeaveFrame
    //     0xa754a4: mov             SP, fp
    //     0xa754a8: ldp             fp, lr, [SP], #0x10
    // 0xa754ac: ret
    //     0xa754ac: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xade9cc, size: 0x7c
    // 0xade9cc: EnterFrame
    //     0xade9cc: stp             fp, lr, [SP, #-0x10]!
    //     0xade9d0: mov             fp, SP
    // 0xade9d4: CheckStackOverflow
    //     0xade9d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade9d8: cmp             SP, x16
    //     0xade9dc: b.ls            #0xadea30
    // 0xade9e0: ldr             x0, [fp, #0x10]
    // 0xade9e4: LoadField: d0 = r0->field_7
    //     0xade9e4: ldur            d0, [x0, #7]
    // 0xade9e8: LoadField: d1 = r0->field_f
    //     0xade9e8: ldur            d1, [x0, #0xf]
    // 0xade9ec: r0 = inline_Allocate_Double()
    //     0xade9ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xade9f0: add             x0, x0, #0x10
    //     0xade9f4: cmp             x1, x0
    //     0xade9f8: b.ls            #0xadea38
    //     0xade9fc: str             x0, [THR, #0x60]  ; THR::top
    //     0xadea00: sub             x0, x0, #0xf
    //     0xadea04: mov             x1, #0xd108
    //     0xadea08: movk            x1, #3, lsl #16
    //     0xadea0c: stur            x1, [x0, #-1]
    // 0xadea10: StoreField: r0->field_7 = d0
    //     0xadea10: stur            d0, [x0, #7]
    // 0xadea14: SaveReg r0
    //     0xadea14: str             x0, [SP, #-8]!
    // 0xadea18: SaveReg d1
    //     0xadea18: str             d1, [SP, #-8]!
    // 0xadea1c: r0 = _stringify()
    //     0xadea1c: bl              #0xadea48  ; [package:flutter/src/painting/alignment.dart] Alignment::_stringify
    // 0xadea20: add             SP, SP, #0x10
    // 0xadea24: LeaveFrame
    //     0xadea24: mov             SP, fp
    //     0xadea28: ldp             fp, lr, [SP], #0x10
    // 0xadea2c: ret
    //     0xadea2c: ret             
    // 0xadea30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadea30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadea34: b               #0xade9e0
    // 0xadea38: stp             q0, q1, [SP, #-0x20]!
    // 0xadea3c: r0 = AllocateDouble()
    //     0xadea3c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadea40: ldp             q0, q1, [SP], #0x20
    // 0xadea44: b               #0xadea10
  }
  static _ _stringify(/* No info */) {
    // ** addr: 0xadea48, size: 0x2d4
    // 0xadea48: EnterFrame
    //     0xadea48: stp             fp, lr, [SP, #-0x10]!
    //     0xadea4c: mov             fp, SP
    // 0xadea50: AllocStack(0x8)
    //     0xadea50: sub             SP, SP, #8
    // 0xadea54: d0 = 1.000000
    //     0xadea54: fmov            d0, #1.00000000
    // 0xadea58: CheckStackOverflow
    //     0xadea58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadea5c: cmp             SP, x16
    //     0xadea60: b.ls            #0xadecfc
    // 0xadea64: fneg            d1, d0
    // 0xadea68: ldr             x0, [fp, #0x18]
    // 0xadea6c: LoadField: d2 = r0->field_7
    //     0xadea6c: ldur            d2, [x0, #7]
    // 0xadea70: fcmp            d2, d1
    // 0xadea74: b.vs            #0xadea7c
    // 0xadea78: b.eq            #0xadea84
    // 0xadea7c: r1 = false
    //     0xadea7c: add             x1, NULL, #0x30  ; false
    // 0xadea80: b               #0xadea88
    // 0xadea84: r1 = true
    //     0xadea84: add             x1, NULL, #0x20  ; true
    // 0xadea88: tbnz            w1, #4, #0xadeab0
    // 0xadea8c: ldr             d3, [fp, #0x10]
    // 0xadea90: fcmp            d3, d1
    // 0xadea94: b.vs            #0xadeab4
    // 0xadea98: b.ne            #0xadeab4
    // 0xadea9c: r0 = "Alignment.topLeft"
    //     0xadea9c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8c0] "Alignment.topLeft"
    //     0xadeaa0: ldr             x0, [x0, #0x8c0]
    // 0xadeaa4: LeaveFrame
    //     0xadeaa4: mov             SP, fp
    //     0xadeaa8: ldp             fp, lr, [SP], #0x10
    // 0xadeaac: ret
    //     0xadeaac: ret             
    // 0xadeab0: ldr             d3, [fp, #0x10]
    // 0xadeab4: d4 = 0.000000
    //     0xadeab4: eor             v4.16b, v4.16b, v4.16b
    // 0xadeab8: fcmp            d2, d4
    // 0xadeabc: b.vs            #0xadeac4
    // 0xadeac0: b.eq            #0xadeacc
    // 0xadeac4: r2 = false
    //     0xadeac4: add             x2, NULL, #0x30  ; false
    // 0xadeac8: b               #0xadead0
    // 0xadeacc: r2 = true
    //     0xadeacc: add             x2, NULL, #0x20  ; true
    // 0xadead0: tbnz            w2, #4, #0xadeaf4
    // 0xadead4: fcmp            d3, d1
    // 0xadead8: b.vs            #0xadeaf4
    // 0xadeadc: b.ne            #0xadeaf4
    // 0xadeae0: r0 = "Alignment.topCenter"
    //     0xadeae0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8c8] "Alignment.topCenter"
    //     0xadeae4: ldr             x0, [x0, #0x8c8]
    // 0xadeae8: LeaveFrame
    //     0xadeae8: mov             SP, fp
    //     0xadeaec: ldp             fp, lr, [SP], #0x10
    // 0xadeaf0: ret
    //     0xadeaf0: ret             
    // 0xadeaf4: fcmp            d2, d0
    // 0xadeaf8: b.vs            #0xadeb00
    // 0xadeafc: b.eq            #0xadeb08
    // 0xadeb00: r3 = false
    //     0xadeb00: add             x3, NULL, #0x30  ; false
    // 0xadeb04: b               #0xadeb0c
    // 0xadeb08: r3 = true
    //     0xadeb08: add             x3, NULL, #0x20  ; true
    // 0xadeb0c: tbnz            w3, #4, #0xadeb30
    // 0xadeb10: fcmp            d3, d1
    // 0xadeb14: b.vs            #0xadeb30
    // 0xadeb18: b.ne            #0xadeb30
    // 0xadeb1c: r0 = "Alignment.topRight"
    //     0xadeb1c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8d0] "Alignment.topRight"
    //     0xadeb20: ldr             x0, [x0, #0x8d0]
    // 0xadeb24: LeaveFrame
    //     0xadeb24: mov             SP, fp
    //     0xadeb28: ldp             fp, lr, [SP], #0x10
    // 0xadeb2c: ret
    //     0xadeb2c: ret             
    // 0xadeb30: tbnz            w1, #4, #0xadeb54
    // 0xadeb34: fcmp            d3, d4
    // 0xadeb38: b.vs            #0xadeb54
    // 0xadeb3c: b.ne            #0xadeb54
    // 0xadeb40: r0 = "Alignment.centerLeft"
    //     0xadeb40: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8d8] "Alignment.centerLeft"
    //     0xadeb44: ldr             x0, [x0, #0x8d8]
    // 0xadeb48: LeaveFrame
    //     0xadeb48: mov             SP, fp
    //     0xadeb4c: ldp             fp, lr, [SP], #0x10
    // 0xadeb50: ret
    //     0xadeb50: ret             
    // 0xadeb54: tbnz            w2, #4, #0xadeb78
    // 0xadeb58: fcmp            d3, d4
    // 0xadeb5c: b.vs            #0xadeb78
    // 0xadeb60: b.ne            #0xadeb78
    // 0xadeb64: r0 = "Alignment.center"
    //     0xadeb64: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8e0] "Alignment.center"
    //     0xadeb68: ldr             x0, [x0, #0x8e0]
    // 0xadeb6c: LeaveFrame
    //     0xadeb6c: mov             SP, fp
    //     0xadeb70: ldp             fp, lr, [SP], #0x10
    // 0xadeb74: ret
    //     0xadeb74: ret             
    // 0xadeb78: tbnz            w3, #4, #0xadeb9c
    // 0xadeb7c: fcmp            d3, d4
    // 0xadeb80: b.vs            #0xadeb9c
    // 0xadeb84: b.ne            #0xadeb9c
    // 0xadeb88: r0 = "Alignment.centerRight"
    //     0xadeb88: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8e8] "Alignment.centerRight"
    //     0xadeb8c: ldr             x0, [x0, #0x8e8]
    // 0xadeb90: LeaveFrame
    //     0xadeb90: mov             SP, fp
    //     0xadeb94: ldp             fp, lr, [SP], #0x10
    // 0xadeb98: ret
    //     0xadeb98: ret             
    // 0xadeb9c: tbnz            w1, #4, #0xadebc0
    // 0xadeba0: fcmp            d3, d0
    // 0xadeba4: b.vs            #0xadebc0
    // 0xadeba8: b.ne            #0xadebc0
    // 0xadebac: r0 = "Alignment.bottomLeft"
    //     0xadebac: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8f0] "Alignment.bottomLeft"
    //     0xadebb0: ldr             x0, [x0, #0x8f0]
    // 0xadebb4: LeaveFrame
    //     0xadebb4: mov             SP, fp
    //     0xadebb8: ldp             fp, lr, [SP], #0x10
    // 0xadebbc: ret
    //     0xadebbc: ret             
    // 0xadebc0: tbnz            w2, #4, #0xadebe4
    // 0xadebc4: fcmp            d3, d0
    // 0xadebc8: b.vs            #0xadebe4
    // 0xadebcc: b.ne            #0xadebe4
    // 0xadebd0: r0 = "Alignment.bottomCenter"
    //     0xadebd0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe8f8] "Alignment.bottomCenter"
    //     0xadebd4: ldr             x0, [x0, #0x8f8]
    // 0xadebd8: LeaveFrame
    //     0xadebd8: mov             SP, fp
    //     0xadebdc: ldp             fp, lr, [SP], #0x10
    // 0xadebe0: ret
    //     0xadebe0: ret             
    // 0xadebe4: tbnz            w3, #4, #0xadec08
    // 0xadebe8: fcmp            d3, d0
    // 0xadebec: b.vs            #0xadec08
    // 0xadebf0: b.ne            #0xadec08
    // 0xadebf4: r0 = "Alignment.bottomRight"
    //     0xadebf4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe900] "Alignment.bottomRight"
    //     0xadebf8: ldr             x0, [x0, #0x900]
    // 0xadebfc: LeaveFrame
    //     0xadebfc: mov             SP, fp
    //     0xadec00: ldp             fp, lr, [SP], #0x10
    // 0xadec04: ret
    //     0xadec04: ret             
    // 0xadec08: r1 = Null
    //     0xadec08: mov             x1, NULL
    // 0xadec0c: r2 = 10
    //     0xadec0c: mov             x2, #0xa
    // 0xadec10: r0 = AllocateArray()
    //     0xadec10: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadec14: stur            x0, [fp, #-8]
    // 0xadec18: r17 = "Alignment("
    //     0xadec18: add             x17, PP, #0xe, lsl #12  ; [pp+0xe908] "Alignment("
    //     0xadec1c: ldr             x17, [x17, #0x908]
    // 0xadec20: StoreField: r0->field_f = r17
    //     0xadec20: stur            w17, [x0, #0xf]
    // 0xadec24: ldr             x16, [fp, #0x18]
    // 0xadec28: SaveReg r16
    //     0xadec28: str             x16, [SP, #-8]!
    // 0xadec2c: r1 = 1
    //     0xadec2c: mov             x1, #1
    // 0xadec30: SaveReg r1
    //     0xadec30: str             x1, [SP, #-8]!
    // 0xadec34: r0 = toStringAsFixed()
    //     0xadec34: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadec38: add             SP, SP, #0x10
    // 0xadec3c: ldur            x1, [fp, #-8]
    // 0xadec40: ArrayStore: r1[1] = r0  ; List_4
    //     0xadec40: add             x25, x1, #0x13
    //     0xadec44: str             w0, [x25]
    //     0xadec48: tbz             w0, #0, #0xadec64
    //     0xadec4c: ldurb           w16, [x1, #-1]
    //     0xadec50: ldurb           w17, [x0, #-1]
    //     0xadec54: and             x16, x17, x16, lsr #2
    //     0xadec58: tst             x16, HEAP, lsr #32
    //     0xadec5c: b.eq            #0xadec64
    //     0xadec60: bl              #0xd67e5c
    // 0xadec64: ldur            x1, [fp, #-8]
    // 0xadec68: r17 = ", "
    //     0xadec68: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadec6c: StoreField: r1->field_17 = r17
    //     0xadec6c: stur            w17, [x1, #0x17]
    // 0xadec70: ldr             d0, [fp, #0x10]
    // 0xadec74: r0 = inline_Allocate_Double()
    //     0xadec74: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xadec78: add             x0, x0, #0x10
    //     0xadec7c: cmp             x2, x0
    //     0xadec80: b.ls            #0xaded04
    //     0xadec84: str             x0, [THR, #0x60]  ; THR::top
    //     0xadec88: sub             x0, x0, #0xf
    //     0xadec8c: mov             x2, #0xd108
    //     0xadec90: movk            x2, #3, lsl #16
    //     0xadec94: stur            x2, [x0, #-1]
    // 0xadec98: StoreField: r0->field_7 = d0
    //     0xadec98: stur            d0, [x0, #7]
    // 0xadec9c: SaveReg r0
    //     0xadec9c: str             x0, [SP, #-8]!
    // 0xadeca0: r0 = 1
    //     0xadeca0: mov             x0, #1
    // 0xadeca4: SaveReg r0
    //     0xadeca4: str             x0, [SP, #-8]!
    // 0xadeca8: r0 = toStringAsFixed()
    //     0xadeca8: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadecac: add             SP, SP, #0x10
    // 0xadecb0: ldur            x1, [fp, #-8]
    // 0xadecb4: ArrayStore: r1[3] = r0  ; List_4
    //     0xadecb4: add             x25, x1, #0x1b
    //     0xadecb8: str             w0, [x25]
    //     0xadecbc: tbz             w0, #0, #0xadecd8
    //     0xadecc0: ldurb           w16, [x1, #-1]
    //     0xadecc4: ldurb           w17, [x0, #-1]
    //     0xadecc8: and             x16, x17, x16, lsr #2
    //     0xadeccc: tst             x16, HEAP, lsr #32
    //     0xadecd0: b.eq            #0xadecd8
    //     0xadecd4: bl              #0xd67e5c
    // 0xadecd8: ldur            x0, [fp, #-8]
    // 0xadecdc: r17 = ")"
    //     0xadecdc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadece0: StoreField: r0->field_1f = r17
    //     0xadece0: stur            w17, [x0, #0x1f]
    // 0xadece4: SaveReg r0
    //     0xadece4: str             x0, [SP, #-8]!
    // 0xadece8: r0 = _interpolate()
    //     0xadece8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadecec: add             SP, SP, #8
    // 0xadecf0: LeaveFrame
    //     0xadecf0: mov             SP, fp
    //     0xadecf4: ldp             fp, lr, [SP], #0x10
    // 0xadecf8: ret
    //     0xadecf8: ret             
    // 0xadecfc: r0 = StackOverflowSharedWithFPURegs()
    //     0xadecfc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xaded00: b               #0xadea64
    // 0xaded04: SaveReg d0
    //     0xaded04: str             q0, [SP, #-0x10]!
    // 0xaded08: SaveReg r1
    //     0xaded08: str             x1, [SP, #-8]!
    // 0xaded0c: r0 = AllocateDouble()
    //     0xaded0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaded10: RestoreReg r1
    //     0xaded10: ldr             x1, [SP], #8
    // 0xaded14: RestoreReg d0
    //     0xaded14: ldr             q0, [SP], #0x10
    // 0xaded18: b               #0xadec98
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf0a64, size: 0x228
    // 0xbf0a64: EnterFrame
    //     0xbf0a64: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0a68: mov             fp, SP
    // 0xbf0a6c: AllocStack(0x18)
    //     0xbf0a6c: sub             SP, SP, #0x18
    // 0xbf0a70: CheckStackOverflow
    //     0xbf0a70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf0a74: cmp             SP, x16
    //     0xbf0a78: b.ls            #0xbf0bd8
    // 0xbf0a7c: ldr             x0, [fp, #0x20]
    // 0xbf0a80: LoadField: d0 = r0->field_7
    //     0xbf0a80: ldur            d0, [x0, #7]
    // 0xbf0a84: ldr             x1, [fp, #0x18]
    // 0xbf0a88: LoadField: d1 = r1->field_7
    //     0xbf0a88: ldur            d1, [x1, #7]
    // 0xbf0a8c: ldr             d2, [fp, #0x10]
    // 0xbf0a90: r2 = inline_Allocate_Double()
    //     0xbf0a90: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf0a94: add             x2, x2, #0x10
    //     0xbf0a98: cmp             x3, x2
    //     0xbf0a9c: b.ls            #0xbf0be0
    //     0xbf0aa0: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf0aa4: sub             x2, x2, #0xf
    //     0xbf0aa8: mov             x3, #0xd108
    //     0xbf0aac: movk            x3, #3, lsl #16
    //     0xbf0ab0: stur            x3, [x2, #-1]
    // 0xbf0ab4: StoreField: r2->field_7 = d2
    //     0xbf0ab4: stur            d2, [x2, #7]
    // 0xbf0ab8: stur            x2, [fp, #-8]
    // 0xbf0abc: r3 = inline_Allocate_Double()
    //     0xbf0abc: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf0ac0: add             x3, x3, #0x10
    //     0xbf0ac4: cmp             x4, x3
    //     0xbf0ac8: b.ls            #0xbf0c04
    //     0xbf0acc: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf0ad0: sub             x3, x3, #0xf
    //     0xbf0ad4: mov             x4, #0xd108
    //     0xbf0ad8: movk            x4, #3, lsl #16
    //     0xbf0adc: stur            x4, [x3, #-1]
    // 0xbf0ae0: StoreField: r3->field_7 = d0
    //     0xbf0ae0: stur            d0, [x3, #7]
    // 0xbf0ae4: r4 = inline_Allocate_Double()
    //     0xbf0ae4: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf0ae8: add             x4, x4, #0x10
    //     0xbf0aec: cmp             x5, x4
    //     0xbf0af0: b.ls            #0xbf0c28
    //     0xbf0af4: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf0af8: sub             x4, x4, #0xf
    //     0xbf0afc: mov             x5, #0xd108
    //     0xbf0b00: movk            x5, #3, lsl #16
    //     0xbf0b04: stur            x5, [x4, #-1]
    // 0xbf0b08: StoreField: r4->field_7 = d1
    //     0xbf0b08: stur            d1, [x4, #7]
    // 0xbf0b0c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf0b10: SaveReg r2
    //     0xbf0b10: str             x2, [SP, #-8]!
    // 0xbf0b14: r0 = lerpDouble()
    //     0xbf0b14: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf0b18: add             SP, SP, #0x18
    // 0xbf0b1c: stur            x0, [fp, #-0x10]
    // 0xbf0b20: cmp             w0, NULL
    // 0xbf0b24: b.eq            #0xbf0c4c
    // 0xbf0b28: ldr             x1, [fp, #0x20]
    // 0xbf0b2c: LoadField: d0 = r1->field_f
    //     0xbf0b2c: ldur            d0, [x1, #0xf]
    // 0xbf0b30: ldr             x1, [fp, #0x18]
    // 0xbf0b34: LoadField: d1 = r1->field_f
    //     0xbf0b34: ldur            d1, [x1, #0xf]
    // 0xbf0b38: r1 = inline_Allocate_Double()
    //     0xbf0b38: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf0b3c: add             x1, x1, #0x10
    //     0xbf0b40: cmp             x2, x1
    //     0xbf0b44: b.ls            #0xbf0c50
    //     0xbf0b48: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf0b4c: sub             x1, x1, #0xf
    //     0xbf0b50: mov             x2, #0xd108
    //     0xbf0b54: movk            x2, #3, lsl #16
    //     0xbf0b58: stur            x2, [x1, #-1]
    // 0xbf0b5c: StoreField: r1->field_7 = d0
    //     0xbf0b5c: stur            d0, [x1, #7]
    // 0xbf0b60: r2 = inline_Allocate_Double()
    //     0xbf0b60: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf0b64: add             x2, x2, #0x10
    //     0xbf0b68: cmp             x3, x2
    //     0xbf0b6c: b.ls            #0xbf0c6c
    //     0xbf0b70: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf0b74: sub             x2, x2, #0xf
    //     0xbf0b78: mov             x3, #0xd108
    //     0xbf0b7c: movk            x3, #3, lsl #16
    //     0xbf0b80: stur            x3, [x2, #-1]
    // 0xbf0b84: StoreField: r2->field_7 = d1
    //     0xbf0b84: stur            d1, [x2, #7]
    // 0xbf0b88: stp             x2, x1, [SP, #-0x10]!
    // 0xbf0b8c: ldur            x16, [fp, #-8]
    // 0xbf0b90: SaveReg r16
    //     0xbf0b90: str             x16, [SP, #-8]!
    // 0xbf0b94: r0 = lerpDouble()
    //     0xbf0b94: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf0b98: add             SP, SP, #0x18
    // 0xbf0b9c: stur            x0, [fp, #-8]
    // 0xbf0ba0: cmp             w0, NULL
    // 0xbf0ba4: b.eq            #0xbf0c88
    // 0xbf0ba8: ldur            x1, [fp, #-0x10]
    // 0xbf0bac: LoadField: d0 = r1->field_7
    //     0xbf0bac: ldur            d0, [x1, #7]
    // 0xbf0bb0: stur            d0, [fp, #-0x18]
    // 0xbf0bb4: r0 = Alignment()
    //     0xbf0bb4: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xbf0bb8: ldur            d0, [fp, #-0x18]
    // 0xbf0bbc: StoreField: r0->field_7 = d0
    //     0xbf0bbc: stur            d0, [x0, #7]
    // 0xbf0bc0: ldur            x1, [fp, #-8]
    // 0xbf0bc4: LoadField: d0 = r1->field_7
    //     0xbf0bc4: ldur            d0, [x1, #7]
    // 0xbf0bc8: StoreField: r0->field_f = d0
    //     0xbf0bc8: stur            d0, [x0, #0xf]
    // 0xbf0bcc: LeaveFrame
    //     0xbf0bcc: mov             SP, fp
    //     0xbf0bd0: ldp             fp, lr, [SP], #0x10
    // 0xbf0bd4: ret
    //     0xbf0bd4: ret             
    // 0xbf0bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0bd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0bdc: b               #0xbf0a7c
    // 0xbf0be0: stp             q1, q2, [SP, #-0x20]!
    // 0xbf0be4: SaveReg d0
    //     0xbf0be4: str             q0, [SP, #-0x10]!
    // 0xbf0be8: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0bec: r0 = AllocateDouble()
    //     0xbf0bec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0bf0: mov             x2, x0
    // 0xbf0bf4: ldp             x0, x1, [SP], #0x10
    // 0xbf0bf8: RestoreReg d0
    //     0xbf0bf8: ldr             q0, [SP], #0x10
    // 0xbf0bfc: ldp             q1, q2, [SP], #0x20
    // 0xbf0c00: b               #0xbf0ab4
    // 0xbf0c04: stp             q0, q1, [SP, #-0x20]!
    // 0xbf0c08: stp             x1, x2, [SP, #-0x10]!
    // 0xbf0c0c: SaveReg r0
    //     0xbf0c0c: str             x0, [SP, #-8]!
    // 0xbf0c10: r0 = AllocateDouble()
    //     0xbf0c10: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0c14: mov             x3, x0
    // 0xbf0c18: RestoreReg r0
    //     0xbf0c18: ldr             x0, [SP], #8
    // 0xbf0c1c: ldp             x1, x2, [SP], #0x10
    // 0xbf0c20: ldp             q0, q1, [SP], #0x20
    // 0xbf0c24: b               #0xbf0ae0
    // 0xbf0c28: SaveReg d1
    //     0xbf0c28: str             q1, [SP, #-0x10]!
    // 0xbf0c2c: stp             x2, x3, [SP, #-0x10]!
    // 0xbf0c30: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0c34: r0 = AllocateDouble()
    //     0xbf0c34: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0c38: mov             x4, x0
    // 0xbf0c3c: ldp             x0, x1, [SP], #0x10
    // 0xbf0c40: ldp             x2, x3, [SP], #0x10
    // 0xbf0c44: RestoreReg d1
    //     0xbf0c44: ldr             q1, [SP], #0x10
    // 0xbf0c48: b               #0xbf0b08
    // 0xbf0c4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0c4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0c50: stp             q0, q1, [SP, #-0x20]!
    // 0xbf0c54: SaveReg r0
    //     0xbf0c54: str             x0, [SP, #-8]!
    // 0xbf0c58: r0 = AllocateDouble()
    //     0xbf0c58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0c5c: mov             x1, x0
    // 0xbf0c60: RestoreReg r0
    //     0xbf0c60: ldr             x0, [SP], #8
    // 0xbf0c64: ldp             q0, q1, [SP], #0x20
    // 0xbf0c68: b               #0xbf0b5c
    // 0xbf0c6c: SaveReg d1
    //     0xbf0c6c: str             q1, [SP, #-0x10]!
    // 0xbf0c70: stp             x0, x1, [SP, #-0x10]!
    // 0xbf0c74: r0 = AllocateDouble()
    //     0xbf0c74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf0c78: mov             x2, x0
    // 0xbf0c7c: ldp             x0, x1, [SP], #0x10
    // 0xbf0c80: RestoreReg d1
    //     0xbf0c80: ldr             q1, [SP], #0x10
    // 0xbf0c84: b               #0xbf0b84
    // 0xbf0c88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0c88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  Alignment *(Alignment, double) {
    // ** addr: 0xcfadc0, size: 0x50
    // 0xcfadc0: EnterFrame
    //     0xcfadc0: stp             fp, lr, [SP, #-0x10]!
    //     0xcfadc4: mov             fp, SP
    // 0xcfadc8: AllocStack(0x10)
    //     0xcfadc8: sub             SP, SP, #0x10
    // 0xcfadcc: ldr             x0, [fp, #0x18]
    // 0xcfadd0: LoadField: d0 = r0->field_7
    //     0xcfadd0: ldur            d0, [x0, #7]
    // 0xcfadd4: ldr             x1, [fp, #0x10]
    // 0xcfadd8: LoadField: d1 = r1->field_7
    //     0xcfadd8: ldur            d1, [x1, #7]
    // 0xcfaddc: fmul            d2, d0, d1
    // 0xcfade0: stur            d2, [fp, #-0x10]
    // 0xcfade4: LoadField: d0 = r0->field_f
    //     0xcfade4: ldur            d0, [x0, #0xf]
    // 0xcfade8: fmul            d3, d0, d1
    // 0xcfadec: stur            d3, [fp, #-8]
    // 0xcfadf0: r0 = Alignment()
    //     0xcfadf0: bl              #0x594930  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xcfadf4: ldur            d0, [fp, #-0x10]
    // 0xcfadf8: StoreField: r0->field_7 = d0
    //     0xcfadf8: stur            d0, [x0, #7]
    // 0xcfadfc: ldur            d0, [fp, #-8]
    // 0xcfae00: StoreField: r0->field_f = d0
    //     0xcfae00: stur            d0, [x0, #0xf]
    // 0xcfae04: LeaveFrame
    //     0xcfae04: mov             SP, fp
    //     0xcfae08: ldp             fp, lr, [SP], #0x10
    // 0xcfae0c: ret
    //     0xcfae0c: ret             
  }
}

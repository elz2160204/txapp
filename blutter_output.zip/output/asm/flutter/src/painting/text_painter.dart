// lib: , url: package:flutter/src/painting/text_painter.dart

// class id: 1049383, size: 0x8
class :: {
}

// class id: 2073, size: 0x68, field offset: 0x8
class TextPainter extends Object {

  late _CaretMetrics _caretMetrics; // offset: 0x58

  get _ preferredLineHeight(/* No info */) {
    // ** addr: 0x51a438, size: 0x84
    // 0x51a438: EnterFrame
    //     0x51a438: stp             fp, lr, [SP, #-0x10]!
    //     0x51a43c: mov             fp, SP
    // 0x51a440: CheckStackOverflow
    //     0x51a440: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51a444: cmp             SP, x16
    //     0x51a448: b.ls            #0x51a4b4
    // 0x51a44c: ldr             x0, [fp, #0x10]
    // 0x51a450: LoadField: r1 = r0->field_4b
    //     0x51a450: ldur            w1, [x0, #0x4b]
    // 0x51a454: DecompressPointer r1
    //     0x51a454: add             x1, x1, HEAP, lsl #32
    // 0x51a458: cmp             w1, NULL
    // 0x51a45c: b.ne            #0x51a498
    // 0x51a460: SaveReg r0
    //     0x51a460: str             x0, [SP, #-8]!
    // 0x51a464: r0 = _createLayoutTemplate()
    //     0x51a464: bl              #0x51a718  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createLayoutTemplate
    // 0x51a468: add             SP, SP, #8
    // 0x51a46c: mov             x2, x0
    // 0x51a470: ldr             x1, [fp, #0x10]
    // 0x51a474: StoreField: r1->field_4b = r0
    //     0x51a474: stur            w0, [x1, #0x4b]
    //     0x51a478: ldurb           w16, [x1, #-1]
    //     0x51a47c: ldurb           w17, [x0, #-1]
    //     0x51a480: and             x16, x17, x16, lsr #2
    //     0x51a484: tst             x16, HEAP, lsr #32
    //     0x51a488: b.eq            #0x51a490
    //     0x51a48c: bl              #0xd6826c
    // 0x51a490: mov             x0, x2
    // 0x51a494: b               #0x51a49c
    // 0x51a498: mov             x0, x1
    // 0x51a49c: SaveReg r0
    //     0x51a49c: str             x0, [SP, #-8]!
    // 0x51a4a0: r0 = height()
    //     0x51a4a0: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x51a4a4: add             SP, SP, #8
    // 0x51a4a8: LeaveFrame
    //     0x51a4a8: mov             SP, fp
    //     0x51a4ac: ldp             fp, lr, [SP], #0x10
    // 0x51a4b0: ret
    //     0x51a4b0: ret             
    // 0x51a4b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51a4b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51a4b8: b               #0x51a44c
  }
  _ _createLayoutTemplate(/* No info */) {
    // ** addr: 0x51a718, size: 0x100
    // 0x51a718: EnterFrame
    //     0x51a718: stp             fp, lr, [SP, #-0x10]!
    //     0x51a71c: mov             fp, SP
    // 0x51a720: AllocStack(0x10)
    //     0x51a720: sub             SP, SP, #0x10
    // 0x51a724: CheckStackOverflow
    //     0x51a724: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51a728: cmp             SP, x16
    //     0x51a72c: b.ls            #0x51a810
    // 0x51a730: ldr             x16, [fp, #0x10]
    // 0x51a734: r30 = Instance_TextDirection
    //     0x51a734: ldr             lr, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x51a738: stp             lr, x16, [SP, #-0x10]!
    // 0x51a73c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x51a73c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x51a740: r0 = _createParagraphStyle()
    //     0x51a740: bl              #0x51dba0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createParagraphStyle
    // 0x51a744: add             SP, SP, #0x10
    // 0x51a748: stur            x0, [fp, #-8]
    // 0x51a74c: r0 = ParagraphBuilder()
    //     0x51a74c: bl              #0x51db94  ; AllocateParagraphBuilderStub -> ParagraphBuilder (size=0x1c)
    // 0x51a750: stur            x0, [fp, #-0x10]
    // 0x51a754: ldur            x16, [fp, #-8]
    // 0x51a758: stp             x16, x0, [SP, #-0x10]!
    // 0x51a75c: r0 = ParagraphBuilder()
    //     0x51a75c: bl              #0x4f5280  ; [dart:ui] ParagraphBuilder::ParagraphBuilder
    // 0x51a760: add             SP, SP, #0x10
    // 0x51a764: ldr             x0, [fp, #0x10]
    // 0x51a768: LoadField: r1 = r0->field_f
    //     0x51a768: ldur            w1, [x0, #0xf]
    // 0x51a76c: DecompressPointer r1
    //     0x51a76c: add             x1, x1, HEAP, lsl #32
    // 0x51a770: cmp             w1, NULL
    // 0x51a774: b.ne            #0x51a780
    // 0x51a778: r0 = Null
    //     0x51a778: mov             x0, NULL
    // 0x51a77c: b               #0x51a7ac
    // 0x51a780: LoadField: r2 = r1->field_7
    //     0x51a780: ldur            w2, [x1, #7]
    // 0x51a784: DecompressPointer r2
    //     0x51a784: add             x2, x2, HEAP, lsl #32
    // 0x51a788: cmp             w2, NULL
    // 0x51a78c: b.ne            #0x51a798
    // 0x51a790: r0 = Null
    //     0x51a790: mov             x0, NULL
    // 0x51a794: b               #0x51a7ac
    // 0x51a798: LoadField: d0 = r0->field_1f
    //     0x51a798: ldur            d0, [x0, #0x1f]
    // 0x51a79c: SaveReg r2
    //     0x51a79c: str             x2, [SP, #-8]!
    // 0x51a7a0: SaveReg d0
    //     0x51a7a0: str             d0, [SP, #-8]!
    // 0x51a7a4: r0 = getTextStyle()
    //     0x51a7a4: bl              #0x51c6f8  ; [package:flutter/src/painting/text_style.dart] TextStyle::getTextStyle
    // 0x51a7a8: add             SP, SP, #0x10
    // 0x51a7ac: cmp             w0, NULL
    // 0x51a7b0: b.eq            #0x51a7c4
    // 0x51a7b4: ldur            x16, [fp, #-0x10]
    // 0x51a7b8: stp             x0, x16, [SP, #-0x10]!
    // 0x51a7bc: r0 = pushStyle()
    //     0x51a7bc: bl              #0x51b214  ; [dart:ui] ParagraphBuilder::pushStyle
    // 0x51a7c0: add             SP, SP, #0x10
    // 0x51a7c4: ldur            x16, [fp, #-0x10]
    // 0x51a7c8: r30 = " "
    //     0x51a7c8: ldr             lr, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x51a7cc: stp             lr, x16, [SP, #-0x10]!
    // 0x51a7d0: r0 = addText()
    //     0x51a7d0: bl              #0x51ae44  ; [dart:ui] ParagraphBuilder::addText
    // 0x51a7d4: add             SP, SP, #0x10
    // 0x51a7d8: ldur            x16, [fp, #-0x10]
    // 0x51a7dc: SaveReg r16
    //     0x51a7dc: str             x16, [SP, #-8]!
    // 0x51a7e0: r0 = build()
    //     0x51a7e0: bl              #0x51aac4  ; [dart:ui] ParagraphBuilder::build
    // 0x51a7e4: add             SP, SP, #8
    // 0x51a7e8: stur            x0, [fp, #-8]
    // 0x51a7ec: r16 = Instance_ParagraphConstraints
    //     0x51a7ec: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f490] Obj!ParagraphConstraints@b5c911
    //     0x51a7f0: ldr             x16, [x16, #0x490]
    // 0x51a7f4: stp             x16, x0, [SP, #-0x10]!
    // 0x51a7f8: r0 = layout()
    //     0x51a7f8: bl              #0x51a818  ; [dart:ui] Paragraph::layout
    // 0x51a7fc: add             SP, SP, #0x10
    // 0x51a800: ldur            x0, [fp, #-8]
    // 0x51a804: LeaveFrame
    //     0x51a804: mov             SP, fp
    //     0x51a808: ldp             fp, lr, [SP], #0x10
    // 0x51a80c: ret
    //     0x51a80c: ret             
    // 0x51a810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51a810: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51a814: b               #0x51a730
  }
  _ _createParagraphStyle(/* No info */) {
    // ** addr: 0x51dba0, size: 0x1e8
    // 0x51dba0: EnterFrame
    //     0x51dba0: stp             fp, lr, [SP, #-0x10]!
    //     0x51dba4: mov             fp, SP
    // 0x51dba8: AllocStack(0x38)
    //     0x51dba8: sub             SP, SP, #0x38
    // 0x51dbac: SetupParameters(TextPainter this /* r1, fp-0x10 */, [dynamic _ = Null /* r0, fp-0x8 */])
    //     0x51dbac: mov             x0, x4
    //     0x51dbb0: ldur            w1, [x0, #0x13]
    //     0x51dbb4: add             x1, x1, HEAP, lsl #32
    //     0x51dbb8: sub             x0, x1, #2
    //     0x51dbbc: add             x1, fp, w0, sxtw #2
    //     0x51dbc0: ldr             x1, [x1, #0x10]
    //     0x51dbc4: stur            x1, [fp, #-0x10]
    //     0x51dbc8: cmp             w0, #2
    //     0x51dbcc: b.lt            #0x51dbe0
    //     0x51dbd0: add             x2, fp, w0, sxtw #2
    //     0x51dbd4: ldr             x2, [x2, #8]
    //     0x51dbd8: mov             x0, x2
    //     0x51dbdc: b               #0x51dbe4
    //     0x51dbe0: mov             x0, NULL
    //     0x51dbe4: stur            x0, [fp, #-8]
    // 0x51dbe8: CheckStackOverflow
    //     0x51dbe8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51dbec: cmp             SP, x16
    //     0x51dbf0: b.ls            #0x51dd54
    // 0x51dbf4: LoadField: r2 = r1->field_f
    //     0x51dbf4: ldur            w2, [x1, #0xf]
    // 0x51dbf8: DecompressPointer r2
    //     0x51dbf8: add             x2, x2, HEAP, lsl #32
    // 0x51dbfc: cmp             w2, NULL
    // 0x51dc00: b.eq            #0x51dd5c
    // 0x51dc04: LoadField: r3 = r2->field_7
    //     0x51dc04: ldur            w3, [x2, #7]
    // 0x51dc08: DecompressPointer r3
    //     0x51dc08: add             x3, x3, HEAP, lsl #32
    // 0x51dc0c: cmp             w3, NULL
    // 0x51dc10: b.ne            #0x51dc1c
    // 0x51dc14: r0 = Null
    //     0x51dc14: mov             x0, NULL
    // 0x51dc18: b               #0x51dc78
    // 0x51dc1c: LoadField: r2 = r1->field_17
    //     0x51dc1c: ldur            w2, [x1, #0x17]
    // 0x51dc20: DecompressPointer r2
    //     0x51dc20: add             x2, x2, HEAP, lsl #32
    // 0x51dc24: LoadField: r4 = r1->field_1b
    //     0x51dc24: ldur            w4, [x1, #0x1b]
    // 0x51dc28: DecompressPointer r4
    //     0x51dc28: add             x4, x4, HEAP, lsl #32
    // 0x51dc2c: cmp             w4, NULL
    // 0x51dc30: b.ne            #0x51dc38
    // 0x51dc34: mov             x4, x0
    // 0x51dc38: LoadField: d0 = r1->field_1f
    //     0x51dc38: ldur            d0, [x1, #0x1f]
    // 0x51dc3c: LoadField: r5 = r1->field_2f
    //     0x51dc3c: ldur            w5, [x1, #0x2f]
    // 0x51dc40: DecompressPointer r5
    //     0x51dc40: add             x5, x5, HEAP, lsl #32
    // 0x51dc44: LoadField: r6 = r1->field_27
    //     0x51dc44: ldur            w6, [x1, #0x27]
    // 0x51dc48: DecompressPointer r6
    //     0x51dc48: add             x6, x6, HEAP, lsl #32
    // 0x51dc4c: LoadField: r7 = r1->field_2b
    //     0x51dc4c: ldur            w7, [x1, #0x2b]
    // 0x51dc50: DecompressPointer r7
    //     0x51dc50: add             x7, x7, HEAP, lsl #32
    // 0x51dc54: LoadField: r8 = r1->field_33
    //     0x51dc54: ldur            w8, [x1, #0x33]
    // 0x51dc58: DecompressPointer r8
    //     0x51dc58: add             x8, x8, HEAP, lsl #32
    // 0x51dc5c: stp             x6, x3, [SP, #-0x10]!
    // 0x51dc60: stp             x5, x7, [SP, #-0x10]!
    // 0x51dc64: stp             x2, x8, [SP, #-0x10]!
    // 0x51dc68: SaveReg r4
    //     0x51dc68: str             x4, [SP, #-8]!
    // 0x51dc6c: SaveReg d0
    //     0x51dc6c: str             d0, [SP, #-8]!
    // 0x51dc70: r0 = getParagraphStyle()
    //     0x51dc70: bl              #0x51e550  ; [package:flutter/src/painting/text_style.dart] TextStyle::getParagraphStyle
    // 0x51dc74: add             SP, SP, #0x40
    // 0x51dc78: cmp             w0, NULL
    // 0x51dc7c: b.ne            #0x51dd48
    // 0x51dc80: ldur            x0, [fp, #-0x10]
    // 0x51dc84: LoadField: r1 = r0->field_17
    //     0x51dc84: ldur            w1, [x0, #0x17]
    // 0x51dc88: DecompressPointer r1
    //     0x51dc88: add             x1, x1, HEAP, lsl #32
    // 0x51dc8c: stur            x1, [fp, #-0x38]
    // 0x51dc90: LoadField: r2 = r0->field_1b
    //     0x51dc90: ldur            w2, [x0, #0x1b]
    // 0x51dc94: DecompressPointer r2
    //     0x51dc94: add             x2, x2, HEAP, lsl #32
    // 0x51dc98: cmp             w2, NULL
    // 0x51dc9c: b.ne            #0x51dca4
    // 0x51dca0: ldur            x2, [fp, #-8]
    // 0x51dca4: d0 = 14.000000
    //     0x51dca4: fmov            d0, #14.00000000
    // 0x51dca8: stur            x2, [fp, #-0x30]
    // 0x51dcac: LoadField: d1 = r0->field_1f
    //     0x51dcac: ldur            d1, [x0, #0x1f]
    // 0x51dcb0: fmul            d2, d0, d1
    // 0x51dcb4: LoadField: r3 = r0->field_2f
    //     0x51dcb4: ldur            w3, [x0, #0x2f]
    // 0x51dcb8: DecompressPointer r3
    //     0x51dcb8: add             x3, x3, HEAP, lsl #32
    // 0x51dcbc: stur            x3, [fp, #-0x28]
    // 0x51dcc0: LoadField: r4 = r0->field_27
    //     0x51dcc0: ldur            w4, [x0, #0x27]
    // 0x51dcc4: DecompressPointer r4
    //     0x51dcc4: add             x4, x4, HEAP, lsl #32
    // 0x51dcc8: stur            x4, [fp, #-0x20]
    // 0x51dccc: LoadField: r5 = r0->field_2b
    //     0x51dccc: ldur            w5, [x0, #0x2b]
    // 0x51dcd0: DecompressPointer r5
    //     0x51dcd0: add             x5, x5, HEAP, lsl #32
    // 0x51dcd4: stur            x5, [fp, #-0x18]
    // 0x51dcd8: r0 = inline_Allocate_Double()
    //     0x51dcd8: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0x51dcdc: add             x0, x0, #0x10
    //     0x51dce0: cmp             x6, x0
    //     0x51dce4: b.ls            #0x51dd60
    //     0x51dce8: str             x0, [THR, #0x60]  ; THR::top
    //     0x51dcec: sub             x0, x0, #0xf
    //     0x51dcf0: mov             x6, #0xd108
    //     0x51dcf4: movk            x6, #3, lsl #16
    //     0x51dcf8: stur            x6, [x0, #-1]
    // 0x51dcfc: StoreField: r0->field_7 = d2
    //     0x51dcfc: stur            d2, [x0, #7]
    // 0x51dd00: stur            x0, [fp, #-8]
    // 0x51dd04: r0 = ParagraphStyle()
    //     0x51dd04: bl              #0x51e544  ; AllocateParagraphStyleStub -> ParagraphStyle (size=0x28)
    // 0x51dd08: stur            x0, [fp, #-0x10]
    // 0x51dd0c: ldur            x16, [fp, #-0x38]
    // 0x51dd10: stp             x16, x0, [SP, #-0x10]!
    // 0x51dd14: ldur            x16, [fp, #-0x30]
    // 0x51dd18: ldur            lr, [fp, #-8]
    // 0x51dd1c: stp             lr, x16, [SP, #-0x10]!
    // 0x51dd20: ldur            x16, [fp, #-0x28]
    // 0x51dd24: stp             NULL, x16, [SP, #-0x10]!
    // 0x51dd28: ldur            x16, [fp, #-0x20]
    // 0x51dd2c: ldur            lr, [fp, #-0x18]
    // 0x51dd30: stp             lr, x16, [SP, #-0x10]!
    // 0x51dd34: r4 = const [0, 0x8, 0x8, 0x3, ellipsis, 0x6, fontSize, 0x3, locale, 0x7, maxLines, 0x4, textHeightBehavior, 0x5, null]
    //     0x51dd34: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f500] List(15) [0, 0x8, 0x8, 0x3, "ellipsis", 0x6, "fontSize", 0x3, "locale", 0x7, "maxLines", 0x4, "textHeightBehavior", 0x5, Null]
    //     0x51dd38: ldr             x4, [x4, #0x500]
    // 0x51dd3c: r0 = ParagraphStyle()
    //     0x51dd3c: bl              #0x51dd88  ; [dart:ui] ParagraphStyle::ParagraphStyle
    // 0x51dd40: add             SP, SP, #0x40
    // 0x51dd44: ldur            x0, [fp, #-0x10]
    // 0x51dd48: LeaveFrame
    //     0x51dd48: mov             SP, fp
    //     0x51dd4c: ldp             fp, lr, [SP], #0x10
    // 0x51dd50: ret
    //     0x51dd50: ret             
    // 0x51dd54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51dd54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51dd58: b               #0x51dbf4
    // 0x51dd5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x51dd5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x51dd60: SaveReg d2
    //     0x51dd60: str             q2, [SP, #-0x10]!
    // 0x51dd64: stp             x4, x5, [SP, #-0x10]!
    // 0x51dd68: stp             x2, x3, [SP, #-0x10]!
    // 0x51dd6c: SaveReg r1
    //     0x51dd6c: str             x1, [SP, #-8]!
    // 0x51dd70: r0 = AllocateDouble()
    //     0x51dd70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x51dd74: RestoreReg r1
    //     0x51dd74: ldr             x1, [SP], #8
    // 0x51dd78: ldp             x2, x3, [SP], #0x10
    // 0x51dd7c: ldp             x4, x5, [SP], #0x10
    // 0x51dd80: RestoreReg d2
    //     0x51dd80: ldr             q2, [SP], #0x10
    // 0x51dd84: b               #0x51dcfc
  }
  _ getBoxesForSelection(/* No info */) {
    // ** addr: 0x51fabc, size: 0x78
    // 0x51fabc: EnterFrame
    //     0x51fabc: stp             fp, lr, [SP, #-0x10]!
    //     0x51fac0: mov             fp, SP
    // 0x51fac4: CheckStackOverflow
    //     0x51fac4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51fac8: cmp             SP, x16
    //     0x51facc: b.ls            #0x51fb28
    // 0x51fad0: ldr             x0, [fp, #0x18]
    // 0x51fad4: LoadField: r2 = r0->field_7
    //     0x51fad4: ldur            w2, [x0, #7]
    // 0x51fad8: DecompressPointer r2
    //     0x51fad8: add             x2, x2, HEAP, lsl #32
    // 0x51fadc: cmp             w2, NULL
    // 0x51fae0: b.eq            #0x51fb30
    // 0x51fae4: ldr             x0, [fp, #0x10]
    // 0x51fae8: LoadField: r3 = r0->field_7
    //     0x51fae8: ldur            x3, [x0, #7]
    // 0x51faec: LoadField: r4 = r0->field_f
    //     0x51faec: ldur            x4, [x0, #0xf]
    // 0x51faf0: r0 = BoxInt64Instr(r3)
    //     0x51faf0: sbfiz           x0, x3, #1, #0x1f
    //     0x51faf4: cmp             x3, x0, asr #1
    //     0x51faf8: b.eq            #0x51fb04
    //     0x51fafc: bl              #0xd69bb8
    //     0x51fb00: stur            x3, [x0, #7]
    // 0x51fb04: stp             x0, x2, [SP, #-0x10]!
    // 0x51fb08: r16 = Instance_BoxHeightStyle
    //     0x51fb08: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f280] Obj!BoxHeightStyle@b66db1
    //     0x51fb0c: ldr             x16, [x16, #0x280]
    // 0x51fb10: stp             x16, x4, [SP, #-0x10]!
    // 0x51fb14: r0 = getBoxesForRange()
    //     0x51fb14: bl              #0x51fb34  ; [dart:ui] Paragraph::getBoxesForRange
    // 0x51fb18: add             SP, SP, #0x20
    // 0x51fb1c: LeaveFrame
    //     0x51fb1c: mov             SP, fp
    //     0x51fb20: ldp             fp, lr, [SP], #0x10
    // 0x51fb24: ret
    //     0x51fb24: ret             
    // 0x51fb28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51fb28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51fb2c: b               #0x51fad0
    // 0x51fb30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x51fb30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getOffsetForCaret(/* No info */) {
    // ** addr: 0x520800, size: 0x70
    // 0x520800: EnterFrame
    //     0x520800: stp             fp, lr, [SP, #-0x10]!
    //     0x520804: mov             fp, SP
    // 0x520808: CheckStackOverflow
    //     0x520808: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52080c: cmp             SP, x16
    //     0x520810: b.ls            #0x52085c
    // 0x520814: ldr             x16, [fp, #0x20]
    // 0x520818: ldr             lr, [fp, #0x18]
    // 0x52081c: stp             lr, x16, [SP, #-0x10]!
    // 0x520820: ldr             x16, [fp, #0x10]
    // 0x520824: SaveReg r16
    //     0x520824: str             x16, [SP, #-8]!
    // 0x520828: r0 = _computeCaretMetrics()
    //     0x520828: bl              #0x520870  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_computeCaretMetrics
    // 0x52082c: add             SP, SP, #0x18
    // 0x520830: ldr             x1, [fp, #0x20]
    // 0x520834: LoadField: r2 = r1->field_57
    //     0x520834: ldur            w2, [x1, #0x57]
    // 0x520838: DecompressPointer r2
    //     0x520838: add             x2, x2, HEAP, lsl #32
    // 0x52083c: r16 = Sentinel
    //     0x52083c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x520840: cmp             w2, w16
    // 0x520844: b.eq            #0x520864
    // 0x520848: LoadField: r0 = r2->field_7
    //     0x520848: ldur            w0, [x2, #7]
    // 0x52084c: DecompressPointer r0
    //     0x52084c: add             x0, x0, HEAP, lsl #32
    // 0x520850: LeaveFrame
    //     0x520850: mov             SP, fp
    //     0x520854: ldp             fp, lr, [SP], #0x10
    // 0x520858: ret
    //     0x520858: ret             
    // 0x52085c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52085c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x520860: b               #0x520814
    // 0x520864: r9 = _caretMetrics
    //     0x520864: add             x9, PP, #0x1f, lsl #12  ; [pp+0x1f538] Field <TextPainter._caretMetrics@879105366>: late (offset: 0x58)
    //     0x520868: ldr             x9, [x9, #0x538]
    // 0x52086c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52086c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _computeCaretMetrics(/* No info */) {
    // ** addr: 0x520870, size: 0x334
    // 0x520870: EnterFrame
    //     0x520870: stp             fp, lr, [SP, #-0x10]!
    //     0x520874: mov             fp, SP
    // 0x520878: AllocStack(0x28)
    //     0x520878: sub             SP, SP, #0x28
    // 0x52087c: CheckStackOverflow
    //     0x52087c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x520880: cmp             SP, x16
    //     0x520884: b.ls            #0x520b84
    // 0x520888: ldr             x0, [fp, #0x20]
    // 0x52088c: LoadField: r1 = r0->field_5b
    //     0x52088c: ldur            w1, [x0, #0x5b]
    // 0x520890: DecompressPointer r1
    //     0x520890: add             x1, x1, HEAP, lsl #32
    // 0x520894: stur            x1, [fp, #-8]
    // 0x520898: cmp             w1, NULL
    // 0x52089c: b.ne            #0x5208a8
    // 0x5208a0: ldr             x1, [fp, #0x10]
    // 0x5208a4: b               #0x5209c0
    // 0x5208a8: r16 = TextPosition
    //     0x5208a8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x5208ac: ldr             x16, [x16, #0x540]
    // 0x5208b0: r30 = TextPosition
    //     0x5208b0: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x5208b4: ldr             lr, [lr, #0x540]
    // 0x5208b8: stp             lr, x16, [SP, #-0x10]!
    // 0x5208bc: r0 = ==()
    //     0x5208bc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x5208c0: add             SP, SP, #0x10
    // 0x5208c4: tbz             w0, #4, #0x5208d0
    // 0x5208c8: ldr             x1, [fp, #0x10]
    // 0x5208cc: b               #0x5209c0
    // 0x5208d0: ldr             x1, [fp, #0x18]
    // 0x5208d4: ldur            x0, [fp, #-8]
    // 0x5208d8: LoadField: r2 = r0->field_7
    //     0x5208d8: ldur            x2, [x0, #7]
    // 0x5208dc: LoadField: r3 = r1->field_7
    //     0x5208dc: ldur            x3, [x1, #7]
    // 0x5208e0: cmp             x2, x3
    // 0x5208e4: b.ne            #0x5209bc
    // 0x5208e8: LoadField: r2 = r0->field_f
    //     0x5208e8: ldur            w2, [x0, #0xf]
    // 0x5208ec: DecompressPointer r2
    //     0x5208ec: add             x2, x2, HEAP, lsl #32
    // 0x5208f0: LoadField: r0 = r1->field_f
    //     0x5208f0: ldur            w0, [x1, #0xf]
    // 0x5208f4: DecompressPointer r0
    //     0x5208f4: add             x0, x0, HEAP, lsl #32
    // 0x5208f8: cmp             w2, w0
    // 0x5208fc: b.ne            #0x5209b4
    // 0x520900: ldr             x0, [fp, #0x20]
    // 0x520904: LoadField: r2 = r0->field_5f
    //     0x520904: ldur            w2, [x0, #0x5f]
    // 0x520908: DecompressPointer r2
    //     0x520908: add             x2, x2, HEAP, lsl #32
    // 0x52090c: stur            x2, [fp, #-8]
    // 0x520910: cmp             w2, NULL
    // 0x520914: b.ne            #0x520920
    // 0x520918: ldr             x1, [fp, #0x10]
    // 0x52091c: b               #0x5209c0
    // 0x520920: ldr             x3, [fp, #0x10]
    // 0x520924: cmp             w3, w2
    // 0x520928: b.eq            #0x5209a4
    // 0x52092c: r16 = Rect
    //     0x52092c: ldr             x16, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0x520930: r30 = Rect
    //     0x520930: ldr             lr, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0x520934: stp             lr, x16, [SP, #-0x10]!
    // 0x520938: r0 = ==()
    //     0x520938: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x52093c: add             SP, SP, #0x10
    // 0x520940: tbz             w0, #4, #0x52094c
    // 0x520944: ldr             x1, [fp, #0x10]
    // 0x520948: b               #0x5209c0
    // 0x52094c: ldr             x1, [fp, #0x10]
    // 0x520950: ldur            x0, [fp, #-8]
    // 0x520954: LoadField: d0 = r0->field_7
    //     0x520954: ldur            d0, [x0, #7]
    // 0x520958: LoadField: d1 = r1->field_7
    //     0x520958: ldur            d1, [x1, #7]
    // 0x52095c: fcmp            d0, d1
    // 0x520960: b.vs            #0x5209c0
    // 0x520964: b.ne            #0x5209c0
    // 0x520968: LoadField: d0 = r0->field_f
    //     0x520968: ldur            d0, [x0, #0xf]
    // 0x52096c: LoadField: d1 = r1->field_f
    //     0x52096c: ldur            d1, [x1, #0xf]
    // 0x520970: fcmp            d0, d1
    // 0x520974: b.vs            #0x5209c0
    // 0x520978: b.ne            #0x5209c0
    // 0x52097c: LoadField: d0 = r0->field_17
    //     0x52097c: ldur            d0, [x0, #0x17]
    // 0x520980: LoadField: d1 = r1->field_17
    //     0x520980: ldur            d1, [x1, #0x17]
    // 0x520984: fcmp            d0, d1
    // 0x520988: b.vs            #0x5209c0
    // 0x52098c: b.ne            #0x5209c0
    // 0x520990: LoadField: d0 = r0->field_1f
    //     0x520990: ldur            d0, [x0, #0x1f]
    // 0x520994: LoadField: d1 = r1->field_1f
    //     0x520994: ldur            d1, [x1, #0x1f]
    // 0x520998: fcmp            d0, d1
    // 0x52099c: b.vs            #0x5209c0
    // 0x5209a0: b.ne            #0x5209c0
    // 0x5209a4: r0 = Null
    //     0x5209a4: mov             x0, NULL
    // 0x5209a8: LeaveFrame
    //     0x5209a8: mov             SP, fp
    //     0x5209ac: ldp             fp, lr, [SP], #0x10
    // 0x5209b0: ret
    //     0x5209b0: ret             
    // 0x5209b4: ldr             x1, [fp, #0x10]
    // 0x5209b8: b               #0x5209c0
    // 0x5209bc: ldr             x1, [fp, #0x10]
    // 0x5209c0: ldr             x0, [fp, #0x18]
    // 0x5209c4: LoadField: r2 = r0->field_7
    //     0x5209c4: ldur            x2, [x0, #7]
    // 0x5209c8: stur            x2, [fp, #-0x10]
    // 0x5209cc: LoadField: r3 = r0->field_f
    //     0x5209cc: ldur            w3, [x0, #0xf]
    // 0x5209d0: DecompressPointer r3
    //     0x5209d0: add             x3, x3, HEAP, lsl #32
    // 0x5209d4: LoadField: r4 = r3->field_7
    //     0x5209d4: ldur            x4, [x3, #7]
    // 0x5209d8: cmp             x4, #0
    // 0x5209dc: b.gt            #0x520a1c
    // 0x5209e0: ldr             x16, [fp, #0x20]
    // 0x5209e4: stp             x2, x16, [SP, #-0x10]!
    // 0x5209e8: SaveReg r1
    //     0x5209e8: str             x1, [SP, #-8]!
    // 0x5209ec: r0 = _getRectFromUpstream()
    //     0x5209ec: bl              #0x521884  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_getRectFromUpstream
    // 0x5209f0: add             SP, SP, #0x18
    // 0x5209f4: cmp             w0, NULL
    // 0x5209f8: b.ne            #0x520a5c
    // 0x5209fc: ldur            x0, [fp, #-0x10]
    // 0x520a00: ldr             x16, [fp, #0x20]
    // 0x520a04: stp             x0, x16, [SP, #-0x10]!
    // 0x520a08: ldr             x16, [fp, #0x10]
    // 0x520a0c: SaveReg r16
    //     0x520a0c: str             x16, [SP, #-8]!
    // 0x520a10: r0 = _getRectFromDownstream()
    //     0x520a10: bl              #0x52106c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_getRectFromDownstream
    // 0x520a14: add             SP, SP, #0x18
    // 0x520a18: b               #0x520a5c
    // 0x520a1c: mov             x0, x2
    // 0x520a20: ldr             x16, [fp, #0x20]
    // 0x520a24: stp             x0, x16, [SP, #-0x10]!
    // 0x520a28: ldr             x16, [fp, #0x10]
    // 0x520a2c: SaveReg r16
    //     0x520a2c: str             x16, [SP, #-8]!
    // 0x520a30: r0 = _getRectFromDownstream()
    //     0x520a30: bl              #0x52106c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_getRectFromDownstream
    // 0x520a34: add             SP, SP, #0x18
    // 0x520a38: cmp             w0, NULL
    // 0x520a3c: b.ne            #0x520a5c
    // 0x520a40: ldur            x0, [fp, #-0x10]
    // 0x520a44: ldr             x16, [fp, #0x20]
    // 0x520a48: stp             x0, x16, [SP, #-0x10]!
    // 0x520a4c: ldr             x16, [fp, #0x10]
    // 0x520a50: SaveReg r16
    //     0x520a50: str             x16, [SP, #-8]!
    // 0x520a54: r0 = _getRectFromUpstream()
    //     0x520a54: bl              #0x521884  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_getRectFromUpstream
    // 0x520a58: add             SP, SP, #0x18
    // 0x520a5c: stur            x0, [fp, #-8]
    // 0x520a60: cmp             w0, NULL
    // 0x520a64: b.eq            #0x520a94
    // 0x520a68: LoadField: d0 = r0->field_7
    //     0x520a68: ldur            d0, [x0, #7]
    // 0x520a6c: stur            d0, [fp, #-0x28]
    // 0x520a70: LoadField: d1 = r0->field_f
    //     0x520a70: ldur            d1, [x0, #0xf]
    // 0x520a74: stur            d1, [fp, #-0x20]
    // 0x520a78: r0 = Offset()
    //     0x520a78: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x520a7c: ldur            d0, [fp, #-0x28]
    // 0x520a80: StoreField: r0->field_7 = d0
    //     0x520a80: stur            d0, [x0, #7]
    // 0x520a84: ldur            d0, [fp, #-0x20]
    // 0x520a88: StoreField: r0->field_f = d0
    //     0x520a88: stur            d0, [x0, #0xf]
    // 0x520a8c: mov             x1, x0
    // 0x520a90: b               #0x520aa8
    // 0x520a94: ldr             x16, [fp, #0x20]
    // 0x520a98: SaveReg r16
    //     0x520a98: str             x16, [SP, #-8]!
    // 0x520a9c: r0 = _emptyOffset()
    //     0x520a9c: bl              #0x520bb0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_emptyOffset
    // 0x520aa0: add             SP, SP, #8
    // 0x520aa4: mov             x1, x0
    // 0x520aa8: ldur            x0, [fp, #-8]
    // 0x520aac: stur            x1, [fp, #-0x18]
    // 0x520ab0: cmp             w0, NULL
    // 0x520ab4: b.eq            #0x520af4
    // 0x520ab8: LoadField: d0 = r0->field_1f
    //     0x520ab8: ldur            d0, [x0, #0x1f]
    // 0x520abc: LoadField: d1 = r0->field_f
    //     0x520abc: ldur            d1, [x0, #0xf]
    // 0x520ac0: fsub            d2, d0, d1
    // 0x520ac4: r0 = inline_Allocate_Double()
    //     0x520ac4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x520ac8: add             x0, x0, #0x10
    //     0x520acc: cmp             x2, x0
    //     0x520ad0: b.ls            #0x520b8c
    //     0x520ad4: str             x0, [THR, #0x60]  ; THR::top
    //     0x520ad8: sub             x0, x0, #0xf
    //     0x520adc: mov             x2, #0xd108
    //     0x520ae0: movk            x2, #3, lsl #16
    //     0x520ae4: stur            x2, [x0, #-1]
    // 0x520ae8: StoreField: r0->field_7 = d2
    //     0x520ae8: stur            d2, [x0, #7]
    // 0x520aec: mov             x2, x0
    // 0x520af0: b               #0x520af8
    // 0x520af4: r2 = Null
    //     0x520af4: mov             x2, NULL
    // 0x520af8: ldr             x0, [fp, #0x20]
    // 0x520afc: stur            x2, [fp, #-8]
    // 0x520b00: r0 = _CaretMetrics()
    //     0x520b00: bl              #0x520ba4  ; Allocate_CaretMetricsStub -> _CaretMetrics (size=0x10)
    // 0x520b04: ldur            x1, [fp, #-0x18]
    // 0x520b08: StoreField: r0->field_7 = r1
    //     0x520b08: stur            w1, [x0, #7]
    // 0x520b0c: ldur            x1, [fp, #-8]
    // 0x520b10: StoreField: r0->field_b = r1
    //     0x520b10: stur            w1, [x0, #0xb]
    // 0x520b14: ldr             x1, [fp, #0x20]
    // 0x520b18: StoreField: r1->field_57 = r0
    //     0x520b18: stur            w0, [x1, #0x57]
    //     0x520b1c: ldurb           w16, [x1, #-1]
    //     0x520b20: ldurb           w17, [x0, #-1]
    //     0x520b24: and             x16, x17, x16, lsr #2
    //     0x520b28: tst             x16, HEAP, lsr #32
    //     0x520b2c: b.eq            #0x520b34
    //     0x520b30: bl              #0xd6826c
    // 0x520b34: ldr             x0, [fp, #0x18]
    // 0x520b38: StoreField: r1->field_5b = r0
    //     0x520b38: stur            w0, [x1, #0x5b]
    //     0x520b3c: ldurb           w16, [x1, #-1]
    //     0x520b40: ldurb           w17, [x0, #-1]
    //     0x520b44: and             x16, x17, x16, lsr #2
    //     0x520b48: tst             x16, HEAP, lsr #32
    //     0x520b4c: b.eq            #0x520b54
    //     0x520b50: bl              #0xd6826c
    // 0x520b54: ldr             x0, [fp, #0x10]
    // 0x520b58: StoreField: r1->field_5f = r0
    //     0x520b58: stur            w0, [x1, #0x5f]
    //     0x520b5c: ldurb           w16, [x1, #-1]
    //     0x520b60: ldurb           w17, [x0, #-1]
    //     0x520b64: and             x16, x17, x16, lsr #2
    //     0x520b68: tst             x16, HEAP, lsr #32
    //     0x520b6c: b.eq            #0x520b74
    //     0x520b70: bl              #0xd6826c
    // 0x520b74: r0 = Null
    //     0x520b74: mov             x0, NULL
    // 0x520b78: LeaveFrame
    //     0x520b78: mov             SP, fp
    //     0x520b7c: ldp             fp, lr, [SP], #0x10
    // 0x520b80: ret
    //     0x520b80: ret             
    // 0x520b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x520b84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x520b88: b               #0x520888
    // 0x520b8c: SaveReg d2
    //     0x520b8c: str             q2, [SP, #-0x10]!
    // 0x520b90: SaveReg r1
    //     0x520b90: str             x1, [SP, #-8]!
    // 0x520b94: r0 = AllocateDouble()
    //     0x520b94: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x520b98: RestoreReg r1
    //     0x520b98: ldr             x1, [SP], #8
    // 0x520b9c: RestoreReg d2
    //     0x520b9c: ldr             q2, [SP], #0x10
    // 0x520ba0: b               #0x520ae8
  }
  get _ _emptyOffset(/* No info */) {
    // ** addr: 0x520bb0, size: 0x2b4
    // 0x520bb0: EnterFrame
    //     0x520bb0: stp             fp, lr, [SP, #-0x10]!
    //     0x520bb4: mov             fp, SP
    // 0x520bb8: AllocStack(0x8)
    //     0x520bb8: sub             SP, SP, #8
    // 0x520bbc: CheckStackOverflow
    //     0x520bbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x520bc0: cmp             SP, x16
    //     0x520bc4: b.ls            #0x520e44
    // 0x520bc8: ldr             x0, [fp, #0x10]
    // 0x520bcc: LoadField: r1 = r0->field_17
    //     0x520bcc: ldur            w1, [x0, #0x17]
    // 0x520bd0: DecompressPointer r1
    //     0x520bd0: add             x1, x1, HEAP, lsl #32
    // 0x520bd4: LoadField: r2 = r1->field_7
    //     0x520bd4: ldur            x2, [x1, #7]
    // 0x520bd8: cmp             x2, #2
    // 0x520bdc: b.gt            #0x520cf8
    // 0x520be0: cmp             x2, #1
    // 0x520be4: b.gt            #0x520c74
    // 0x520be8: cmp             x2, #0
    // 0x520bec: b.gt            #0x520c00
    // 0x520bf0: r0 = Instance_Offset
    //     0x520bf0: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x520bf4: LeaveFrame
    //     0x520bf4: mov             SP, fp
    //     0x520bf8: ldp             fp, lr, [SP], #0x10
    // 0x520bfc: ret
    //     0x520bfc: ret             
    // 0x520c00: LoadField: r1 = r0->field_7
    //     0x520c00: ldur            w1, [x0, #7]
    // 0x520c04: DecompressPointer r1
    //     0x520c04: add             x1, x1, HEAP, lsl #32
    // 0x520c08: cmp             w1, NULL
    // 0x520c0c: b.eq            #0x520e4c
    // 0x520c10: SaveReg r1
    //     0x520c10: str             x1, [SP, #-8]!
    // 0x520c14: r0 = width()
    //     0x520c14: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x520c18: add             SP, SP, #8
    // 0x520c1c: stp             fp, lr, [SP, #-0x10]!
    // 0x520c20: mov             fp, SP
    // 0x520c24: CallRuntime_LibcCeil(double) -> double
    //     0x520c24: and             SP, SP, #0xfffffffffffffff0
    //     0x520c28: mov             sp, SP
    //     0x520c2c: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x520c30: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520c34: blr             x16
    //     0x520c38: mov             x16, #8
    //     0x520c3c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520c40: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x520c44: sub             sp, x16, #1, lsl #12
    //     0x520c48: mov             SP, fp
    //     0x520c4c: ldp             fp, lr, [SP], #0x10
    // 0x520c50: stur            d0, [fp, #-8]
    // 0x520c54: r0 = Offset()
    //     0x520c54: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x520c58: ldur            d0, [fp, #-8]
    // 0x520c5c: StoreField: r0->field_7 = d0
    //     0x520c5c: stur            d0, [x0, #7]
    // 0x520c60: d0 = 0.000000
    //     0x520c60: eor             v0.16b, v0.16b, v0.16b
    // 0x520c64: StoreField: r0->field_f = d0
    //     0x520c64: stur            d0, [x0, #0xf]
    // 0x520c68: LeaveFrame
    //     0x520c68: mov             SP, fp
    //     0x520c6c: ldp             fp, lr, [SP], #0x10
    // 0x520c70: ret
    //     0x520c70: ret             
    // 0x520c74: d0 = 0.000000
    //     0x520c74: eor             v0.16b, v0.16b, v0.16b
    // 0x520c78: LoadField: r1 = r0->field_7
    //     0x520c78: ldur            w1, [x0, #7]
    // 0x520c7c: DecompressPointer r1
    //     0x520c7c: add             x1, x1, HEAP, lsl #32
    // 0x520c80: cmp             w1, NULL
    // 0x520c84: b.eq            #0x520e50
    // 0x520c88: SaveReg r1
    //     0x520c88: str             x1, [SP, #-8]!
    // 0x520c8c: r0 = width()
    //     0x520c8c: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x520c90: add             SP, SP, #8
    // 0x520c94: stp             fp, lr, [SP, #-0x10]!
    // 0x520c98: mov             fp, SP
    // 0x520c9c: CallRuntime_LibcCeil(double) -> double
    //     0x520c9c: and             SP, SP, #0xfffffffffffffff0
    //     0x520ca0: mov             sp, SP
    //     0x520ca4: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x520ca8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520cac: blr             x16
    //     0x520cb0: mov             x16, #8
    //     0x520cb4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520cb8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x520cbc: sub             sp, x16, #1, lsl #12
    //     0x520cc0: mov             SP, fp
    //     0x520cc4: ldp             fp, lr, [SP], #0x10
    // 0x520cc8: mov             v1.16b, v0.16b
    // 0x520ccc: d0 = 2.000000
    //     0x520ccc: fmov            d0, #2.00000000
    // 0x520cd0: fdiv            d2, d1, d0
    // 0x520cd4: stur            d2, [fp, #-8]
    // 0x520cd8: r0 = Offset()
    //     0x520cd8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x520cdc: ldur            d0, [fp, #-8]
    // 0x520ce0: StoreField: r0->field_7 = d0
    //     0x520ce0: stur            d0, [x0, #7]
    // 0x520ce4: d0 = 0.000000
    //     0x520ce4: eor             v0.16b, v0.16b, v0.16b
    // 0x520ce8: StoreField: r0->field_f = d0
    //     0x520ce8: stur            d0, [x0, #0xf]
    // 0x520cec: LeaveFrame
    //     0x520cec: mov             SP, fp
    //     0x520cf0: ldp             fp, lr, [SP], #0x10
    // 0x520cf4: ret
    //     0x520cf4: ret             
    // 0x520cf8: d0 = 0.000000
    //     0x520cf8: eor             v0.16b, v0.16b, v0.16b
    // 0x520cfc: cmp             x2, #4
    // 0x520d00: b.gt            #0x520da4
    // 0x520d04: LoadField: r1 = r0->field_1b
    //     0x520d04: ldur            w1, [x0, #0x1b]
    // 0x520d08: DecompressPointer r1
    //     0x520d08: add             x1, x1, HEAP, lsl #32
    // 0x520d0c: cmp             w1, NULL
    // 0x520d10: b.eq            #0x520e54
    // 0x520d14: LoadField: r2 = r1->field_7
    //     0x520d14: ldur            x2, [x1, #7]
    // 0x520d18: cmp             x2, #0
    // 0x520d1c: b.gt            #0x520d94
    // 0x520d20: LoadField: r1 = r0->field_7
    //     0x520d20: ldur            w1, [x0, #7]
    // 0x520d24: DecompressPointer r1
    //     0x520d24: add             x1, x1, HEAP, lsl #32
    // 0x520d28: cmp             w1, NULL
    // 0x520d2c: b.eq            #0x520e58
    // 0x520d30: SaveReg r1
    //     0x520d30: str             x1, [SP, #-8]!
    // 0x520d34: r0 = width()
    //     0x520d34: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x520d38: add             SP, SP, #8
    // 0x520d3c: stp             fp, lr, [SP, #-0x10]!
    // 0x520d40: mov             fp, SP
    // 0x520d44: CallRuntime_LibcCeil(double) -> double
    //     0x520d44: and             SP, SP, #0xfffffffffffffff0
    //     0x520d48: mov             sp, SP
    //     0x520d4c: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x520d50: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520d54: blr             x16
    //     0x520d58: mov             x16, #8
    //     0x520d5c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520d60: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x520d64: sub             sp, x16, #1, lsl #12
    //     0x520d68: mov             SP, fp
    //     0x520d6c: ldp             fp, lr, [SP], #0x10
    // 0x520d70: stur            d0, [fp, #-8]
    // 0x520d74: r0 = Offset()
    //     0x520d74: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x520d78: ldur            d0, [fp, #-8]
    // 0x520d7c: StoreField: r0->field_7 = d0
    //     0x520d7c: stur            d0, [x0, #7]
    // 0x520d80: d0 = 0.000000
    //     0x520d80: eor             v0.16b, v0.16b, v0.16b
    // 0x520d84: StoreField: r0->field_f = d0
    //     0x520d84: stur            d0, [x0, #0xf]
    // 0x520d88: LeaveFrame
    //     0x520d88: mov             SP, fp
    //     0x520d8c: ldp             fp, lr, [SP], #0x10
    // 0x520d90: ret
    //     0x520d90: ret             
    // 0x520d94: r0 = Instance_Offset
    //     0x520d94: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x520d98: LeaveFrame
    //     0x520d98: mov             SP, fp
    //     0x520d9c: ldp             fp, lr, [SP], #0x10
    // 0x520da0: ret
    //     0x520da0: ret             
    // 0x520da4: LoadField: r1 = r0->field_1b
    //     0x520da4: ldur            w1, [x0, #0x1b]
    // 0x520da8: DecompressPointer r1
    //     0x520da8: add             x1, x1, HEAP, lsl #32
    // 0x520dac: cmp             w1, NULL
    // 0x520db0: b.eq            #0x520e5c
    // 0x520db4: LoadField: r2 = r1->field_7
    //     0x520db4: ldur            x2, [x1, #7]
    // 0x520db8: cmp             x2, #0
    // 0x520dbc: b.gt            #0x520dd0
    // 0x520dc0: r0 = Instance_Offset
    //     0x520dc0: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x520dc4: LeaveFrame
    //     0x520dc4: mov             SP, fp
    //     0x520dc8: ldp             fp, lr, [SP], #0x10
    // 0x520dcc: ret
    //     0x520dcc: ret             
    // 0x520dd0: LoadField: r1 = r0->field_7
    //     0x520dd0: ldur            w1, [x0, #7]
    // 0x520dd4: DecompressPointer r1
    //     0x520dd4: add             x1, x1, HEAP, lsl #32
    // 0x520dd8: cmp             w1, NULL
    // 0x520ddc: b.eq            #0x520e60
    // 0x520de0: SaveReg r1
    //     0x520de0: str             x1, [SP, #-8]!
    // 0x520de4: r0 = width()
    //     0x520de4: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x520de8: add             SP, SP, #8
    // 0x520dec: stp             fp, lr, [SP, #-0x10]!
    // 0x520df0: mov             fp, SP
    // 0x520df4: CallRuntime_LibcCeil(double) -> double
    //     0x520df4: and             SP, SP, #0xfffffffffffffff0
    //     0x520df8: mov             sp, SP
    //     0x520dfc: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x520e00: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520e04: blr             x16
    //     0x520e08: mov             x16, #8
    //     0x520e0c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520e10: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x520e14: sub             sp, x16, #1, lsl #12
    //     0x520e18: mov             SP, fp
    //     0x520e1c: ldp             fp, lr, [SP], #0x10
    // 0x520e20: stur            d0, [fp, #-8]
    // 0x520e24: r0 = Offset()
    //     0x520e24: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x520e28: ldur            d0, [fp, #-8]
    // 0x520e2c: StoreField: r0->field_7 = d0
    //     0x520e2c: stur            d0, [x0, #7]
    // 0x520e30: d0 = 0.000000
    //     0x520e30: eor             v0.16b, v0.16b, v0.16b
    // 0x520e34: StoreField: r0->field_f = d0
    //     0x520e34: stur            d0, [x0, #0xf]
    // 0x520e38: LeaveFrame
    //     0x520e38: mov             SP, fp
    //     0x520e3c: ldp             fp, lr, [SP], #0x10
    // 0x520e40: ret
    //     0x520e40: ret             
    // 0x520e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x520e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x520e48: b               #0x520bc8
    // 0x520e4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x520e4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x520e50: r0 = NullCastErrorSharedWithFPURegs()
    //     0x520e50: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x520e54: r0 = NullCastErrorSharedWithFPURegs()
    //     0x520e54: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x520e58: r0 = NullCastErrorSharedWithFPURegs()
    //     0x520e58: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x520e5c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x520e5c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x520e60: r0 = NullCastErrorSharedWithFPURegs()
    //     0x520e60: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ width(/* No info */) {
    // ** addr: 0x520e64, size: 0x80
    // 0x520e64: EnterFrame
    //     0x520e64: stp             fp, lr, [SP, #-0x10]!
    //     0x520e68: mov             fp, SP
    // 0x520e6c: CheckStackOverflow
    //     0x520e6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x520e70: cmp             SP, x16
    //     0x520e74: b.ls            #0x520ed8
    // 0x520e78: ldr             x0, [fp, #0x10]
    // 0x520e7c: LoadField: r1 = r0->field_7
    //     0x520e7c: ldur            w1, [x0, #7]
    // 0x520e80: DecompressPointer r1
    //     0x520e80: add             x1, x1, HEAP, lsl #32
    // 0x520e84: cmp             w1, NULL
    // 0x520e88: b.eq            #0x520ee0
    // 0x520e8c: SaveReg r1
    //     0x520e8c: str             x1, [SP, #-8]!
    // 0x520e90: r0 = width()
    //     0x520e90: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x520e94: add             SP, SP, #8
    // 0x520e98: stp             fp, lr, [SP, #-0x10]!
    // 0x520e9c: mov             fp, SP
    // 0x520ea0: CallRuntime_LibcCeil(double) -> double
    //     0x520ea0: and             SP, SP, #0xfffffffffffffff0
    //     0x520ea4: mov             sp, SP
    //     0x520ea8: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x520eac: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520eb0: blr             x16
    //     0x520eb4: mov             x16, #8
    //     0x520eb8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x520ebc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x520ec0: sub             sp, x16, #1, lsl #12
    //     0x520ec4: mov             SP, fp
    //     0x520ec8: ldp             fp, lr, [SP], #0x10
    // 0x520ecc: LeaveFrame
    //     0x520ecc: mov             SP, fp
    //     0x520ed0: ldp             fp, lr, [SP], #0x10
    // 0x520ed4: ret
    //     0x520ed4: ret             
    // 0x520ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x520ed8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x520edc: b               #0x520e78
    // 0x520ee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x520ee0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getRectFromDownstream(/* No info */) {
    // ** addr: 0x52106c, size: 0x410
    // 0x52106c: EnterFrame
    //     0x52106c: stp             fp, lr, [SP, #-0x10]!
    //     0x521070: mov             fp, SP
    // 0x521074: AllocStack(0x50)
    //     0x521074: sub             SP, SP, #0x50
    // 0x521078: CheckStackOverflow
    //     0x521078: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52107c: cmp             SP, x16
    //     0x521080: b.ls            #0x521460
    // 0x521084: ldr             x16, [fp, #0x20]
    // 0x521088: SaveReg r16
    //     0x521088: str             x16, [SP, #-8]!
    // 0x52108c: r0 = plainText()
    //     0x52108c: bl              #0x5216d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x521090: add             SP, SP, #8
    // 0x521094: LoadField: r1 = r0->field_7
    //     0x521094: ldur            w1, [x0, #7]
    // 0x521098: DecompressPointer r1
    //     0x521098: add             x1, x1, HEAP, lsl #32
    // 0x52109c: stur            x1, [fp, #-8]
    // 0x5210a0: cbz             w1, #0x5210ac
    // 0x5210a4: ldr             x0, [fp, #0x18]
    // 0x5210a8: tbz             x0, #0x3f, #0x5210bc
    // 0x5210ac: r0 = Null
    //     0x5210ac: mov             x0, NULL
    // 0x5210b0: LeaveFrame
    //     0x5210b0: mov             SP, fp
    //     0x5210b4: ldp             fp, lr, [SP], #0x10
    // 0x5210b8: ret
    //     0x5210b8: ret             
    // 0x5210bc: ldr             x16, [fp, #0x20]
    // 0x5210c0: SaveReg r16
    //     0x5210c0: str             x16, [SP, #-8]!
    // 0x5210c4: r0 = plainText()
    //     0x5210c4: bl              #0x5216d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x5210c8: add             SP, SP, #8
    // 0x5210cc: mov             x2, x0
    // 0x5210d0: ldur            x0, [fp, #-8]
    // 0x5210d4: r3 = LoadInt32Instr(r0)
    //     0x5210d4: sbfx            x3, x0, #1, #0x1f
    // 0x5210d8: stur            x3, [fp, #-0x10]
    // 0x5210dc: sub             x0, x3, #1
    // 0x5210e0: ldr             x4, [fp, #0x18]
    // 0x5210e4: cmp             x4, x0
    // 0x5210e8: b.le            #0x5210f4
    // 0x5210ec: mov             x5, x0
    // 0x5210f0: b               #0x521108
    // 0x5210f4: cmp             x4, x0
    // 0x5210f8: b.ge            #0x521104
    // 0x5210fc: mov             x5, x4
    // 0x521100: b               #0x521108
    // 0x521104: mov             x5, x4
    // 0x521108: r0 = BoxInt64Instr(r5)
    //     0x521108: sbfiz           x0, x5, #1, #0x1f
    //     0x52110c: cmp             x5, x0, asr #1
    //     0x521110: b.eq            #0x52111c
    //     0x521114: bl              #0xd69bb8
    //     0x521118: stur            x5, [x0, #7]
    // 0x52111c: r1 = LoadClassIdInstr(r2)
    //     0x52111c: ldur            x1, [x2, #-1]
    //     0x521120: ubfx            x1, x1, #0xc, #0x14
    // 0x521124: stp             x0, x2, [SP, #-0x10]!
    // 0x521128: mov             x0, x1
    // 0x52112c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x52112c: sub             lr, x0, #1, lsl #12
    //     0x521130: ldr             lr, [x21, lr, lsl #3]
    //     0x521134: blr             lr
    // 0x521138: add             SP, SP, #0x10
    // 0x52113c: r1 = LoadInt32Instr(r0)
    //     0x52113c: sbfx            x1, x0, #1, #0x1f
    // 0x521140: r2 = 63488
    //     0x521140: mov             x2, #0xf800
    // 0x521144: and             x3, x1, x2
    // 0x521148: ubfx            x3, x3, #0, #0x20
    // 0x52114c: r17 = 55296
    //     0x52114c: mov             x17, #0xd800
    // 0x521150: cmp             x3, x17
    // 0x521154: b.eq            #0x521164
    // 0x521158: r17 = 16410
    //     0x521158: mov             x17, #0x401a
    // 0x52115c: cmp             w0, w17
    // 0x521160: b.ne            #0x52116c
    // 0x521164: r1 = true
    //     0x521164: add             x1, NULL, #0x20  ; true
    // 0x521168: b               #0x52119c
    // 0x52116c: r17 = 16414
    //     0x52116c: mov             x17, #0x401e
    // 0x521170: cmp             w0, w17
    // 0x521174: b.ne            #0x521180
    // 0x521178: r0 = true
    //     0x521178: add             x0, NULL, #0x20  ; true
    // 0x52117c: b               #0x521198
    // 0x521180: r17 = 16412
    //     0x521180: mov             x17, #0x401c
    // 0x521184: cmp             w0, w17
    // 0x521188: r16 = true
    //     0x521188: add             x16, NULL, #0x20  ; true
    // 0x52118c: r17 = false
    //     0x52118c: add             x17, NULL, #0x30  ; false
    // 0x521190: csel            x1, x16, x17, eq
    // 0x521194: mov             x0, x1
    // 0x521198: mov             x1, x0
    // 0x52119c: ldr             x0, [fp, #0x18]
    // 0x5211a0: stur            x1, [fp, #-0x18]
    // 0x5211a4: tst             x1, #0x10
    // 0x5211a8: cset            x2, ne
    // 0x5211ac: sub             x2, x2, #1
    // 0x5211b0: and             x2, x2, #2
    // 0x5211b4: add             x2, x2, #2
    // 0x5211b8: stur            x2, [fp, #-8]
    // 0x5211bc: r16 = <TextBox>
    //     0x5211bc: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f460] TypeArguments: <TextBox>
    //     0x5211c0: ldr             x16, [x16, #0x460]
    // 0x5211c4: stp             xzr, x16, [SP, #-0x10]!
    // 0x5211c8: r0 = _GrowableList()
    //     0x5211c8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5211cc: add             SP, SP, #0x10
    // 0x5211d0: mov             x2, x0
    // 0x5211d4: ldur            x0, [fp, #-8]
    // 0x5211d8: r3 = LoadInt32Instr(r0)
    //     0x5211d8: sbfx            x3, x0, #1, #0x1f
    // 0x5211dc: ldr             x4, [fp, #0x18]
    // 0x5211e0: r0 = BoxInt64Instr(r4)
    //     0x5211e0: sbfiz           x0, x4, #1, #0x1f
    //     0x5211e4: cmp             x4, x0, asr #1
    //     0x5211e8: b.eq            #0x5211f4
    //     0x5211ec: bl              #0xd69bb8
    //     0x5211f0: stur            x4, [x0, #7]
    // 0x5211f4: mov             x5, x0
    // 0x5211f8: stur            x5, [fp, #-0x30]
    // 0x5211fc: mov             x7, x3
    // 0x521200: mov             x0, x2
    // 0x521204: ldur            x2, [fp, #-0x18]
    // 0x521208: ldur            x3, [fp, #-0x10]
    // 0x52120c: ldr             x6, [fp, #0x20]
    // 0x521210: stur            x7, [fp, #-0x28]
    // 0x521214: CheckStackOverflow
    //     0x521214: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x521218: cmp             SP, x16
    //     0x52121c: b.ls            #0x521468
    // 0x521220: LoadField: r1 = r0->field_b
    //     0x521220: ldur            w1, [x0, #0xb]
    // 0x521224: DecompressPointer r1
    //     0x521224: add             x1, x1, HEAP, lsl #32
    // 0x521228: cbnz            w1, #0x521450
    // 0x52122c: add             x8, x4, x7
    // 0x521230: stur            x8, [fp, #-0x20]
    // 0x521234: LoadField: r9 = r6->field_7
    //     0x521234: ldur            w9, [x6, #7]
    // 0x521238: DecompressPointer r9
    //     0x521238: add             x9, x9, HEAP, lsl #32
    // 0x52123c: stur            x9, [fp, #-8]
    // 0x521240: cmp             w9, NULL
    // 0x521244: b.eq            #0x521470
    // 0x521248: r0 = BoxInt64Instr(r8)
    //     0x521248: sbfiz           x0, x8, #1, #0x1f
    //     0x52124c: cmp             x8, x0, asr #1
    //     0x521250: b.eq            #0x52125c
    //     0x521254: bl              #0xd69bb8
    //     0x521258: stur            x8, [x0, #7]
    // 0x52125c: stp             x5, x9, [SP, #-0x10]!
    // 0x521260: r16 = 10
    //     0x521260: mov             x16, #0xa
    // 0x521264: stp             x16, x0, [SP, #-0x10]!
    // 0x521268: SaveReg rZR
    //     0x521268: str             xzr, [SP, #-8]!
    // 0x52126c: r0 = _getBoxesForRange()
    //     0x52126c: bl              #0x51fe9c  ; [dart:ui] Paragraph::_getBoxesForRange
    // 0x521270: add             SP, SP, #0x28
    // 0x521274: ldur            x16, [fp, #-8]
    // 0x521278: stp             x0, x16, [SP, #-0x10]!
    // 0x52127c: r0 = _decodeTextBoxes()
    //     0x52127c: bl              #0x51fbac  ; [dart:ui] Paragraph::_decodeTextBoxes
    // 0x521280: add             SP, SP, #0x10
    // 0x521284: LoadField: r1 = r0->field_b
    //     0x521284: ldur            w1, [x0, #0xb]
    // 0x521288: DecompressPointer r1
    //     0x521288: add             x1, x1, HEAP, lsl #32
    // 0x52128c: cbnz            w1, #0x5212c8
    // 0x521290: ldur            x1, [fp, #-0x18]
    // 0x521294: tbnz            w1, #4, #0x521450
    // 0x521298: ldur            x3, [fp, #-0x20]
    // 0x52129c: ldur            x2, [fp, #-0x10]
    // 0x5212a0: lsl             x4, x2, #1
    // 0x5212a4: cmp             x3, x4
    // 0x5212a8: b.ge            #0x521450
    // 0x5212ac: ldur            x3, [fp, #-0x28]
    // 0x5212b0: lsl             x7, x3, #1
    // 0x5212b4: ldr             x4, [fp, #0x18]
    // 0x5212b8: mov             x3, x2
    // 0x5212bc: mov             x2, x1
    // 0x5212c0: ldur            x5, [fp, #-0x30]
    // 0x5212c4: b               #0x52120c
    // 0x5212c8: SaveReg r0
    //     0x5212c8: str             x0, [SP, #-8]!
    // 0x5212cc: r0 = last()
    //     0x5212cc: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x5212d0: add             SP, SP, #8
    // 0x5212d4: stur            x0, [fp, #-8]
    // 0x5212d8: LoadField: r1 = r0->field_27
    //     0x5212d8: ldur            w1, [x0, #0x27]
    // 0x5212dc: DecompressPointer r1
    //     0x5212dc: add             x1, x1, HEAP, lsl #32
    // 0x5212e0: r16 = Instance_TextDirection
    //     0x5212e0: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x5212e4: cmp             w1, w16
    // 0x5212e8: b.ne            #0x5212f4
    // 0x5212ec: LoadField: d0 = r0->field_7
    //     0x5212ec: ldur            d0, [x0, #7]
    // 0x5212f0: b               #0x5212f8
    // 0x5212f4: LoadField: d0 = r0->field_17
    //     0x5212f4: ldur            d0, [x0, #0x17]
    // 0x5212f8: r16 = Instance_TextDirection
    //     0x5212f8: ldr             x16, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x5212fc: cmp             w1, w16
    // 0x521300: b.ne            #0x52131c
    // 0x521304: ldr             x1, [fp, #0x10]
    // 0x521308: LoadField: d1 = r1->field_17
    //     0x521308: ldur            d1, [x1, #0x17]
    // 0x52130c: LoadField: d2 = r1->field_7
    //     0x52130c: ldur            d2, [x1, #7]
    // 0x521310: fsub            d3, d1, d2
    // 0x521314: fsub            d1, d0, d3
    // 0x521318: mov             v0.16b, v1.16b
    // 0x52131c: ldr             x1, [fp, #0x20]
    // 0x521320: stur            d0, [fp, #-0x38]
    // 0x521324: LoadField: r2 = r1->field_7
    //     0x521324: ldur            w2, [x1, #7]
    // 0x521328: DecompressPointer r2
    //     0x521328: add             x2, x2, HEAP, lsl #32
    // 0x52132c: cmp             w2, NULL
    // 0x521330: b.eq            #0x521474
    // 0x521334: SaveReg r2
    //     0x521334: str             x2, [SP, #-8]!
    // 0x521338: r0 = width()
    //     0x521338: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x52133c: add             SP, SP, #8
    // 0x521340: mov             v2.16b, v0.16b
    // 0x521344: ldur            d1, [fp, #-0x38]
    // 0x521348: d0 = 0.000000
    //     0x521348: eor             v0.16b, v0.16b, v0.16b
    // 0x52134c: fcmp            d1, d0
    // 0x521350: b.vs            #0x521358
    // 0x521354: b.lt            #0x521360
    // 0x521358: r0 = false
    //     0x521358: add             x0, NULL, #0x30  ; false
    // 0x52135c: b               #0x521364
    // 0x521360: r0 = true
    //     0x521360: add             x0, NULL, #0x20  ; true
    // 0x521364: stur            x0, [fp, #-0x18]
    // 0x521368: tbnz            w0, #4, #0x521374
    // 0x52136c: d0 = 0.000000
    //     0x52136c: eor             v0.16b, v0.16b, v0.16b
    // 0x521370: b               #0x52139c
    // 0x521374: fcmp            d1, d2
    // 0x521378: b.vs            #0x521388
    // 0x52137c: b.le            #0x521388
    // 0x521380: mov             v0.16b, v2.16b
    // 0x521384: b               #0x52139c
    // 0x521388: fcmp            d1, d1
    // 0x52138c: b.vc            #0x521398
    // 0x521390: mov             v0.16b, v2.16b
    // 0x521394: b               #0x52139c
    // 0x521398: mov             v0.16b, v1.16b
    // 0x52139c: ldr             x2, [fp, #0x20]
    // 0x5213a0: ldur            x1, [fp, #-8]
    // 0x5213a4: stur            d0, [fp, #-0x48]
    // 0x5213a8: LoadField: d2 = r1->field_f
    //     0x5213a8: ldur            d2, [x1, #0xf]
    // 0x5213ac: stur            d2, [fp, #-0x40]
    // 0x5213b0: LoadField: r3 = r2->field_7
    //     0x5213b0: ldur            w3, [x2, #7]
    // 0x5213b4: DecompressPointer r3
    //     0x5213b4: add             x3, x3, HEAP, lsl #32
    // 0x5213b8: cmp             w3, NULL
    // 0x5213bc: b.eq            #0x521478
    // 0x5213c0: SaveReg r3
    //     0x5213c0: str             x3, [SP, #-8]!
    // 0x5213c4: r0 = width()
    //     0x5213c4: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x5213c8: add             SP, SP, #8
    // 0x5213cc: ldur            x0, [fp, #-0x18]
    // 0x5213d0: tbnz            w0, #4, #0x5213dc
    // 0x5213d4: d2 = 0.000000
    //     0x5213d4: eor             v2.16b, v2.16b, v2.16b
    // 0x5213d8: b               #0x521408
    // 0x5213dc: ldur            d1, [fp, #-0x38]
    // 0x5213e0: fcmp            d1, d0
    // 0x5213e4: b.vs            #0x5213f4
    // 0x5213e8: b.le            #0x5213f4
    // 0x5213ec: mov             v2.16b, v0.16b
    // 0x5213f0: b               #0x521408
    // 0x5213f4: fcmp            d1, d1
    // 0x5213f8: b.vc            #0x521404
    // 0x5213fc: mov             v2.16b, v0.16b
    // 0x521400: b               #0x521408
    // 0x521404: mov             v2.16b, v1.16b
    // 0x521408: ldur            x0, [fp, #-8]
    // 0x52140c: ldur            d1, [fp, #-0x40]
    // 0x521410: ldur            d0, [fp, #-0x48]
    // 0x521414: stur            d2, [fp, #-0x50]
    // 0x521418: LoadField: d3 = r0->field_1f
    //     0x521418: ldur            d3, [x0, #0x1f]
    // 0x52141c: stur            d3, [fp, #-0x38]
    // 0x521420: r0 = Rect()
    //     0x521420: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x521424: ldur            d0, [fp, #-0x48]
    // 0x521428: StoreField: r0->field_7 = d0
    //     0x521428: stur            d0, [x0, #7]
    // 0x52142c: ldur            d0, [fp, #-0x40]
    // 0x521430: StoreField: r0->field_f = d0
    //     0x521430: stur            d0, [x0, #0xf]
    // 0x521434: ldur            d0, [fp, #-0x50]
    // 0x521438: StoreField: r0->field_17 = d0
    //     0x521438: stur            d0, [x0, #0x17]
    // 0x52143c: ldur            d0, [fp, #-0x38]
    // 0x521440: StoreField: r0->field_1f = d0
    //     0x521440: stur            d0, [x0, #0x1f]
    // 0x521444: LeaveFrame
    //     0x521444: mov             SP, fp
    //     0x521448: ldp             fp, lr, [SP], #0x10
    // 0x52144c: ret
    //     0x52144c: ret             
    // 0x521450: r0 = Null
    //     0x521450: mov             x0, NULL
    // 0x521454: LeaveFrame
    //     0x521454: mov             SP, fp
    //     0x521458: ldp             fp, lr, [SP], #0x10
    // 0x52145c: ret
    //     0x52145c: ret             
    // 0x521460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x521460: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x521464: b               #0x521084
    // 0x521468: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x521468: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52146c: b               #0x521220
    // 0x521470: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x521470: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x521474: r0 = NullCastErrorSharedWithFPURegs()
    //     0x521474: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x521478: r0 = NullCastErrorSharedWithFPURegs()
    //     0x521478: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ plainText(/* No info */) {
    // ** addr: 0x5216d4, size: 0xa0
    // 0x5216d4: EnterFrame
    //     0x5216d4: stp             fp, lr, [SP, #-0x10]!
    //     0x5216d8: mov             fp, SP
    // 0x5216dc: CheckStackOverflow
    //     0x5216dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5216e0: cmp             SP, x16
    //     0x5216e4: b.ls            #0x52176c
    // 0x5216e8: ldr             x0, [fp, #0x10]
    // 0x5216ec: LoadField: r1 = r0->field_13
    //     0x5216ec: ldur            w1, [x0, #0x13]
    // 0x5216f0: DecompressPointer r1
    //     0x5216f0: add             x1, x1, HEAP, lsl #32
    // 0x5216f4: cmp             w1, NULL
    // 0x5216f8: b.ne            #0x52174c
    // 0x5216fc: LoadField: r1 = r0->field_f
    //     0x5216fc: ldur            w1, [x0, #0xf]
    // 0x521700: DecompressPointer r1
    //     0x521700: add             x1, x1, HEAP, lsl #32
    // 0x521704: cmp             w1, NULL
    // 0x521708: b.ne            #0x521718
    // 0x52170c: mov             x2, x0
    // 0x521710: r1 = Null
    //     0x521710: mov             x1, NULL
    // 0x521714: b               #0x52172c
    // 0x521718: SaveReg r1
    //     0x521718: str             x1, [SP, #-8]!
    // 0x52171c: r0 = toPlainText()
    //     0x52171c: bl              #0x521774  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::toPlainText
    // 0x521720: add             SP, SP, #8
    // 0x521724: mov             x1, x0
    // 0x521728: ldr             x2, [fp, #0x10]
    // 0x52172c: mov             x0, x1
    // 0x521730: StoreField: r2->field_13 = r0
    //     0x521730: stur            w0, [x2, #0x13]
    //     0x521734: ldurb           w16, [x2, #-1]
    //     0x521738: ldurb           w17, [x0, #-1]
    //     0x52173c: and             x16, x17, x16, lsr #2
    //     0x521740: tst             x16, HEAP, lsr #32
    //     0x521744: b.eq            #0x52174c
    //     0x521748: bl              #0xd6828c
    // 0x52174c: cmp             w1, NULL
    // 0x521750: b.ne            #0x52175c
    // 0x521754: r0 = ""
    //     0x521754: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x521758: b               #0x521760
    // 0x52175c: mov             x0, x1
    // 0x521760: LeaveFrame
    //     0x521760: mov             SP, fp
    //     0x521764: ldp             fp, lr, [SP], #0x10
    // 0x521768: ret
    //     0x521768: ret             
    // 0x52176c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52176c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x521770: b               #0x5216e8
  }
  _ _getRectFromUpstream(/* No info */) {
    // ** addr: 0x521884, size: 0x54c
    // 0x521884: EnterFrame
    //     0x521884: stp             fp, lr, [SP, #-0x10]!
    //     0x521888: mov             fp, SP
    // 0x52188c: AllocStack(0x58)
    //     0x52188c: sub             SP, SP, #0x58
    // 0x521890: CheckStackOverflow
    //     0x521890: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x521894: cmp             SP, x16
    //     0x521898: b.ls            #0x521da8
    // 0x52189c: ldr             x16, [fp, #0x20]
    // 0x5218a0: SaveReg r16
    //     0x5218a0: str             x16, [SP, #-8]!
    // 0x5218a4: r0 = plainText()
    //     0x5218a4: bl              #0x5216d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x5218a8: add             SP, SP, #8
    // 0x5218ac: LoadField: r1 = r0->field_7
    //     0x5218ac: ldur            w1, [x0, #7]
    // 0x5218b0: DecompressPointer r1
    //     0x5218b0: add             x1, x1, HEAP, lsl #32
    // 0x5218b4: cbz             w1, #0x5218cc
    // 0x5218b8: ldr             x0, [fp, #0x18]
    // 0x5218bc: r2 = LoadInt32Instr(r1)
    //     0x5218bc: sbfx            x2, x1, #1, #0x1f
    // 0x5218c0: stur            x2, [fp, #-8]
    // 0x5218c4: cmp             x0, x2
    // 0x5218c8: b.le            #0x5218dc
    // 0x5218cc: r0 = Null
    //     0x5218cc: mov             x0, NULL
    // 0x5218d0: LeaveFrame
    //     0x5218d0: mov             SP, fp
    //     0x5218d4: ldp             fp, lr, [SP], #0x10
    // 0x5218d8: ret
    //     0x5218d8: ret             
    // 0x5218dc: ldr             x16, [fp, #0x20]
    // 0x5218e0: SaveReg r16
    //     0x5218e0: str             x16, [SP, #-8]!
    // 0x5218e4: r0 = plainText()
    //     0x5218e4: bl              #0x5216d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x5218e8: add             SP, SP, #8
    // 0x5218ec: mov             x3, x0
    // 0x5218f0: ldr             x2, [fp, #0x18]
    // 0x5218f4: sub             x4, x2, #1
    // 0x5218f8: tbz             x4, #0x3f, #0x521904
    // 0x5218fc: r0 = 0
    //     0x5218fc: mov             x0, #0
    // 0x521900: b               #0x52196c
    // 0x521904: cmp             x4, #0
    // 0x521908: b.le            #0x521924
    // 0x52190c: r0 = BoxInt64Instr(r4)
    //     0x52190c: sbfiz           x0, x4, #1, #0x1f
    //     0x521910: cmp             x4, x0, asr #1
    //     0x521914: b.eq            #0x521920
    //     0x521918: bl              #0xd69bb8
    //     0x52191c: stur            x4, [x0, #7]
    // 0x521920: b               #0x52196c
    // 0x521924: r0 = BoxInt64Instr(r4)
    //     0x521924: sbfiz           x0, x4, #1, #0x1f
    //     0x521928: cmp             x4, x0, asr #1
    //     0x52192c: b.eq            #0x521938
    //     0x521930: bl              #0xd69bb8
    //     0x521934: stur            x4, [x0, #7]
    // 0x521938: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x521938: mov             x1, #0x76
    //     0x52193c: tbz             w0, #0, #0x52194c
    //     0x521940: ldur            x1, [x0, #-1]
    //     0x521944: ubfx            x1, x1, #0xc, #0x14
    //     0x521948: lsl             x1, x1, #1
    // 0x52194c: cmp             w1, #0x7a
    // 0x521950: b.ne            #0x521968
    // 0x521954: LoadField: d0 = r0->field_7
    //     0x521954: ldur            d0, [x0, #7]
    // 0x521958: fcmp            d0, d0
    // 0x52195c: b.vs            #0x52196c
    // 0x521960: r0 = 0
    //     0x521960: mov             x0, #0
    // 0x521964: b               #0x52196c
    // 0x521968: r0 = 0
    //     0x521968: mov             x0, #0
    // 0x52196c: r1 = LoadClassIdInstr(r3)
    //     0x52196c: ldur            x1, [x3, #-1]
    //     0x521970: ubfx            x1, x1, #0xc, #0x14
    // 0x521974: stp             x0, x3, [SP, #-0x10]!
    // 0x521978: mov             x0, x1
    // 0x52197c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x52197c: sub             lr, x0, #1, lsl #12
    //     0x521980: ldr             lr, [x21, lr, lsl #3]
    //     0x521984: blr             lr
    // 0x521988: add             SP, SP, #0x10
    // 0x52198c: stur            x0, [fp, #-0x10]
    // 0x521990: r1 = LoadInt32Instr(r0)
    //     0x521990: sbfx            x1, x0, #1, #0x1f
    // 0x521994: r2 = 63488
    //     0x521994: mov             x2, #0xf800
    // 0x521998: and             x3, x1, x2
    // 0x52199c: ubfx            x3, x3, #0, #0x20
    // 0x5219a0: r17 = 55296
    //     0x5219a0: mov             x17, #0xd800
    // 0x5219a4: cmp             x3, x17
    // 0x5219a8: b.eq            #0x5219dc
    // 0x5219ac: ldr             x2, [fp, #0x20]
    // 0x5219b0: ldr             x1, [fp, #0x18]
    // 0x5219b4: LoadField: r3 = r2->field_f
    //     0x5219b4: ldur            w3, [x2, #0xf]
    // 0x5219b8: DecompressPointer r3
    //     0x5219b8: add             x3, x3, HEAP, lsl #32
    // 0x5219bc: cmp             w3, NULL
    // 0x5219c0: b.eq            #0x521db0
    // 0x5219c4: stp             x1, x3, [SP, #-0x10]!
    // 0x5219c8: r0 = codeUnitAt()
    //     0x5219c8: bl              #0x522038  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0x5219cc: add             SP, SP, #0x10
    // 0x5219d0: r17 = 16410
    //     0x5219d0: mov             x17, #0x401a
    // 0x5219d4: cmp             w0, w17
    // 0x5219d8: b.ne            #0x5219e8
    // 0x5219dc: ldur            x0, [fp, #-0x10]
    // 0x5219e0: r3 = true
    //     0x5219e0: add             x3, NULL, #0x20  ; true
    // 0x5219e4: b               #0x521a18
    // 0x5219e8: ldur            x0, [fp, #-0x10]
    // 0x5219ec: r17 = 16414
    //     0x5219ec: mov             x17, #0x401e
    // 0x5219f0: cmp             w0, w17
    // 0x5219f4: b.ne            #0x521a00
    // 0x5219f8: r1 = true
    //     0x5219f8: add             x1, NULL, #0x20  ; true
    // 0x5219fc: b               #0x521a14
    // 0x521a00: r17 = 16412
    //     0x521a00: mov             x17, #0x401c
    // 0x521a04: cmp             w0, w17
    // 0x521a08: r16 = true
    //     0x521a08: add             x16, NULL, #0x20  ; true
    // 0x521a0c: r17 = false
    //     0x521a0c: add             x17, NULL, #0x30  ; false
    // 0x521a10: csel            x1, x16, x17, eq
    // 0x521a14: mov             x3, x1
    // 0x521a18: ldr             x1, [fp, #0x18]
    // 0x521a1c: ldur            x2, [fp, #-8]
    // 0x521a20: stur            x3, [fp, #-0x20]
    // 0x521a24: tst             x3, #0x10
    // 0x521a28: cset            x4, ne
    // 0x521a2c: sub             x4, x4, #1
    // 0x521a30: and             x4, x4, #2
    // 0x521a34: add             x4, x4, #2
    // 0x521a38: stur            x4, [fp, #-0x18]
    // 0x521a3c: r16 = <TextBox>
    //     0x521a3c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f460] TypeArguments: <TextBox>
    //     0x521a40: ldr             x16, [x16, #0x460]
    // 0x521a44: stp             xzr, x16, [SP, #-0x10]!
    // 0x521a48: r0 = _GrowableList()
    //     0x521a48: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x521a4c: add             SP, SP, #0x10
    // 0x521a50: mov             x2, x0
    // 0x521a54: ldur            x0, [fp, #-0x18]
    // 0x521a58: r3 = LoadInt32Instr(r0)
    //     0x521a58: sbfx            x3, x0, #1, #0x1f
    // 0x521a5c: ldr             x4, [fp, #0x18]
    // 0x521a60: r0 = BoxInt64Instr(r4)
    //     0x521a60: sbfiz           x0, x4, #1, #0x1f
    //     0x521a64: cmp             x4, x0, asr #1
    //     0x521a68: b.eq            #0x521a74
    //     0x521a6c: bl              #0xd69bb8
    //     0x521a70: stur            x4, [x0, #7]
    // 0x521a74: mov             x5, x0
    // 0x521a78: ldur            x0, [fp, #-8]
    // 0x521a7c: stur            x5, [fp, #-0x38]
    // 0x521a80: neg             x6, x0
    // 0x521a84: stur            x6, [fp, #-0x30]
    // 0x521a88: mov             x8, x3
    // 0x521a8c: mov             x0, x2
    // 0x521a90: ldur            x2, [fp, #-0x10]
    // 0x521a94: ldur            x3, [fp, #-0x20]
    // 0x521a98: ldr             x7, [fp, #0x20]
    // 0x521a9c: stur            x8, [fp, #-0x28]
    // 0x521aa0: CheckStackOverflow
    //     0x521aa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x521aa4: cmp             SP, x16
    //     0x521aa8: b.ls            #0x521db4
    // 0x521aac: LoadField: r1 = r0->field_b
    //     0x521aac: ldur            w1, [x0, #0xb]
    // 0x521ab0: DecompressPointer r1
    //     0x521ab0: add             x1, x1, HEAP, lsl #32
    // 0x521ab4: cbnz            w1, #0x521d98
    // 0x521ab8: sub             x9, x4, x8
    // 0x521abc: stur            x9, [fp, #-8]
    // 0x521ac0: LoadField: r10 = r7->field_7
    //     0x521ac0: ldur            w10, [x7, #7]
    // 0x521ac4: DecompressPointer r10
    //     0x521ac4: add             x10, x10, HEAP, lsl #32
    // 0x521ac8: stur            x10, [fp, #-0x18]
    // 0x521acc: cmp             w10, NULL
    // 0x521ad0: b.eq            #0x521dbc
    // 0x521ad4: r0 = BoxInt64Instr(r9)
    //     0x521ad4: sbfiz           x0, x9, #1, #0x1f
    //     0x521ad8: cmp             x9, x0, asr #1
    //     0x521adc: b.eq            #0x521ae8
    //     0x521ae0: bl              #0xd69bb8
    //     0x521ae4: stur            x9, [x0, #7]
    // 0x521ae8: stp             x0, x10, [SP, #-0x10]!
    // 0x521aec: r16 = 10
    //     0x521aec: mov             x16, #0xa
    // 0x521af0: stp             x16, x5, [SP, #-0x10]!
    // 0x521af4: SaveReg rZR
    //     0x521af4: str             xzr, [SP, #-8]!
    // 0x521af8: r0 = _getBoxesForRange()
    //     0x521af8: bl              #0x51fe9c  ; [dart:ui] Paragraph::_getBoxesForRange
    // 0x521afc: add             SP, SP, #0x28
    // 0x521b00: ldur            x16, [fp, #-0x18]
    // 0x521b04: stp             x0, x16, [SP, #-0x10]!
    // 0x521b08: r0 = _decodeTextBoxes()
    //     0x521b08: bl              #0x51fbac  ; [dart:ui] Paragraph::_decodeTextBoxes
    // 0x521b0c: add             SP, SP, #0x10
    // 0x521b10: LoadField: r1 = r0->field_b
    //     0x521b10: ldur            w1, [x0, #0xb]
    // 0x521b14: DecompressPointer r1
    //     0x521b14: add             x1, x1, HEAP, lsl #32
    // 0x521b18: cbnz            w1, #0x521b64
    // 0x521b1c: ldur            x1, [fp, #-0x20]
    // 0x521b20: tbz             w1, #4, #0x521b34
    // 0x521b24: ldur            x2, [fp, #-0x10]
    // 0x521b28: cmp             w2, #0x14
    // 0x521b2c: b.ne            #0x521b38
    // 0x521b30: b               #0x521d98
    // 0x521b34: ldur            x2, [fp, #-0x10]
    // 0x521b38: ldur            x4, [fp, #-8]
    // 0x521b3c: ldur            x3, [fp, #-0x30]
    // 0x521b40: cmp             x4, x3
    // 0x521b44: b.lt            #0x521d98
    // 0x521b48: ldur            x4, [fp, #-0x28]
    // 0x521b4c: lsl             x8, x4, #1
    // 0x521b50: ldr             x4, [fp, #0x18]
    // 0x521b54: mov             x6, x3
    // 0x521b58: mov             x3, x1
    // 0x521b5c: ldur            x5, [fp, #-0x38]
    // 0x521b60: b               #0x521a98
    // 0x521b64: ldur            x2, [fp, #-0x10]
    // 0x521b68: SaveReg r0
    //     0x521b68: str             x0, [SP, #-8]!
    // 0x521b6c: r0 = first()
    //     0x521b6c: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x521b70: add             SP, SP, #8
    // 0x521b74: mov             x1, x0
    // 0x521b78: ldur            x0, [fp, #-0x10]
    // 0x521b7c: stur            x1, [fp, #-0x18]
    // 0x521b80: cmp             w0, #0x14
    // 0x521b84: b.ne            #0x521c1c
    // 0x521b88: ldr             x16, [fp, #0x20]
    // 0x521b8c: SaveReg r16
    //     0x521b8c: str             x16, [SP, #-8]!
    // 0x521b90: r0 = _emptyOffset()
    //     0x521b90: bl              #0x520bb0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_emptyOffset
    // 0x521b94: add             SP, SP, #8
    // 0x521b98: cmp             w0, NULL
    // 0x521b9c: b.eq            #0x521dc0
    // 0x521ba0: LoadField: d0 = r0->field_7
    //     0x521ba0: ldur            d0, [x0, #7]
    // 0x521ba4: ldur            x0, [fp, #-0x18]
    // 0x521ba8: stur            d0, [fp, #-0x48]
    // 0x521bac: LoadField: d1 = r0->field_1f
    //     0x521bac: ldur            d1, [x0, #0x1f]
    // 0x521bb0: stur            d1, [fp, #-0x40]
    // 0x521bb4: ldr             x16, [fp, #0x20]
    // 0x521bb8: SaveReg r16
    //     0x521bb8: str             x16, [SP, #-8]!
    // 0x521bbc: r0 = _emptyOffset()
    //     0x521bbc: bl              #0x520bb0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_emptyOffset
    // 0x521bc0: add             SP, SP, #8
    // 0x521bc4: cmp             w0, NULL
    // 0x521bc8: b.eq            #0x521dc4
    // 0x521bcc: LoadField: d0 = r0->field_7
    //     0x521bcc: ldur            d0, [x0, #7]
    // 0x521bd0: ldur            d1, [fp, #-0x40]
    // 0x521bd4: stur            d0, [fp, #-0x58]
    // 0x521bd8: fadd            d2, d1, d1
    // 0x521bdc: ldur            x0, [fp, #-0x18]
    // 0x521be0: LoadField: d3 = r0->field_f
    //     0x521be0: ldur            d3, [x0, #0xf]
    // 0x521be4: fsub            d4, d2, d3
    // 0x521be8: stur            d4, [fp, #-0x50]
    // 0x521bec: r0 = Rect()
    //     0x521bec: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x521bf0: ldur            d0, [fp, #-0x48]
    // 0x521bf4: StoreField: r0->field_7 = d0
    //     0x521bf4: stur            d0, [x0, #7]
    // 0x521bf8: ldur            d0, [fp, #-0x40]
    // 0x521bfc: StoreField: r0->field_f = d0
    //     0x521bfc: stur            d0, [x0, #0xf]
    // 0x521c00: ldur            d0, [fp, #-0x58]
    // 0x521c04: StoreField: r0->field_17 = d0
    //     0x521c04: stur            d0, [x0, #0x17]
    // 0x521c08: ldur            d0, [fp, #-0x50]
    // 0x521c0c: StoreField: r0->field_1f = d0
    //     0x521c0c: stur            d0, [x0, #0x1f]
    // 0x521c10: LeaveFrame
    //     0x521c10: mov             SP, fp
    //     0x521c14: ldp             fp, lr, [SP], #0x10
    // 0x521c18: ret
    //     0x521c18: ret             
    // 0x521c1c: mov             x0, x1
    // 0x521c20: LoadField: r1 = r0->field_27
    //     0x521c20: ldur            w1, [x0, #0x27]
    // 0x521c24: DecompressPointer r1
    //     0x521c24: add             x1, x1, HEAP, lsl #32
    // 0x521c28: r16 = Instance_TextDirection
    //     0x521c28: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x521c2c: cmp             w1, w16
    // 0x521c30: b.ne            #0x521c3c
    // 0x521c34: LoadField: d0 = r0->field_17
    //     0x521c34: ldur            d0, [x0, #0x17]
    // 0x521c38: b               #0x521c40
    // 0x521c3c: LoadField: d0 = r0->field_7
    //     0x521c3c: ldur            d0, [x0, #7]
    // 0x521c40: r16 = Instance_TextDirection
    //     0x521c40: ldr             x16, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x521c44: cmp             w1, w16
    // 0x521c48: b.ne            #0x521c64
    // 0x521c4c: ldr             x1, [fp, #0x10]
    // 0x521c50: LoadField: d1 = r1->field_17
    //     0x521c50: ldur            d1, [x1, #0x17]
    // 0x521c54: LoadField: d2 = r1->field_7
    //     0x521c54: ldur            d2, [x1, #7]
    // 0x521c58: fsub            d3, d1, d2
    // 0x521c5c: fsub            d1, d0, d3
    // 0x521c60: mov             v0.16b, v1.16b
    // 0x521c64: ldr             x1, [fp, #0x20]
    // 0x521c68: stur            d0, [fp, #-0x40]
    // 0x521c6c: LoadField: r2 = r1->field_7
    //     0x521c6c: ldur            w2, [x1, #7]
    // 0x521c70: DecompressPointer r2
    //     0x521c70: add             x2, x2, HEAP, lsl #32
    // 0x521c74: cmp             w2, NULL
    // 0x521c78: b.eq            #0x521dc8
    // 0x521c7c: SaveReg r2
    //     0x521c7c: str             x2, [SP, #-8]!
    // 0x521c80: r0 = width()
    //     0x521c80: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x521c84: add             SP, SP, #8
    // 0x521c88: mov             v2.16b, v0.16b
    // 0x521c8c: ldur            d1, [fp, #-0x40]
    // 0x521c90: d0 = 0.000000
    //     0x521c90: eor             v0.16b, v0.16b, v0.16b
    // 0x521c94: fcmp            d1, d0
    // 0x521c98: b.vs            #0x521ca0
    // 0x521c9c: b.lt            #0x521ca8
    // 0x521ca0: r0 = false
    //     0x521ca0: add             x0, NULL, #0x30  ; false
    // 0x521ca4: b               #0x521cac
    // 0x521ca8: r0 = true
    //     0x521ca8: add             x0, NULL, #0x20  ; true
    // 0x521cac: stur            x0, [fp, #-0x10]
    // 0x521cb0: tbnz            w0, #4, #0x521cbc
    // 0x521cb4: d0 = 0.000000
    //     0x521cb4: eor             v0.16b, v0.16b, v0.16b
    // 0x521cb8: b               #0x521ce4
    // 0x521cbc: fcmp            d1, d2
    // 0x521cc0: b.vs            #0x521cd0
    // 0x521cc4: b.le            #0x521cd0
    // 0x521cc8: mov             v0.16b, v2.16b
    // 0x521ccc: b               #0x521ce4
    // 0x521cd0: fcmp            d1, d1
    // 0x521cd4: b.vc            #0x521ce0
    // 0x521cd8: mov             v0.16b, v2.16b
    // 0x521cdc: b               #0x521ce4
    // 0x521ce0: mov             v0.16b, v1.16b
    // 0x521ce4: ldr             x2, [fp, #0x20]
    // 0x521ce8: ldur            x1, [fp, #-0x18]
    // 0x521cec: stur            d0, [fp, #-0x50]
    // 0x521cf0: LoadField: d2 = r1->field_f
    //     0x521cf0: ldur            d2, [x1, #0xf]
    // 0x521cf4: stur            d2, [fp, #-0x48]
    // 0x521cf8: LoadField: r3 = r2->field_7
    //     0x521cf8: ldur            w3, [x2, #7]
    // 0x521cfc: DecompressPointer r3
    //     0x521cfc: add             x3, x3, HEAP, lsl #32
    // 0x521d00: cmp             w3, NULL
    // 0x521d04: b.eq            #0x521dcc
    // 0x521d08: SaveReg r3
    //     0x521d08: str             x3, [SP, #-8]!
    // 0x521d0c: r0 = width()
    //     0x521d0c: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x521d10: add             SP, SP, #8
    // 0x521d14: ldur            x0, [fp, #-0x10]
    // 0x521d18: tbnz            w0, #4, #0x521d24
    // 0x521d1c: d2 = 0.000000
    //     0x521d1c: eor             v2.16b, v2.16b, v2.16b
    // 0x521d20: b               #0x521d50
    // 0x521d24: ldur            d1, [fp, #-0x40]
    // 0x521d28: fcmp            d1, d0
    // 0x521d2c: b.vs            #0x521d3c
    // 0x521d30: b.le            #0x521d3c
    // 0x521d34: mov             v2.16b, v0.16b
    // 0x521d38: b               #0x521d50
    // 0x521d3c: fcmp            d1, d1
    // 0x521d40: b.vc            #0x521d4c
    // 0x521d44: mov             v2.16b, v0.16b
    // 0x521d48: b               #0x521d50
    // 0x521d4c: mov             v2.16b, v1.16b
    // 0x521d50: ldur            x0, [fp, #-0x18]
    // 0x521d54: ldur            d1, [fp, #-0x48]
    // 0x521d58: ldur            d0, [fp, #-0x50]
    // 0x521d5c: stur            d2, [fp, #-0x58]
    // 0x521d60: LoadField: d3 = r0->field_1f
    //     0x521d60: ldur            d3, [x0, #0x1f]
    // 0x521d64: stur            d3, [fp, #-0x40]
    // 0x521d68: r0 = Rect()
    //     0x521d68: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x521d6c: ldur            d0, [fp, #-0x50]
    // 0x521d70: StoreField: r0->field_7 = d0
    //     0x521d70: stur            d0, [x0, #7]
    // 0x521d74: ldur            d0, [fp, #-0x48]
    // 0x521d78: StoreField: r0->field_f = d0
    //     0x521d78: stur            d0, [x0, #0xf]
    // 0x521d7c: ldur            d0, [fp, #-0x58]
    // 0x521d80: StoreField: r0->field_17 = d0
    //     0x521d80: stur            d0, [x0, #0x17]
    // 0x521d84: ldur            d0, [fp, #-0x40]
    // 0x521d88: StoreField: r0->field_1f = d0
    //     0x521d88: stur            d0, [x0, #0x1f]
    // 0x521d8c: LeaveFrame
    //     0x521d8c: mov             SP, fp
    //     0x521d90: ldp             fp, lr, [SP], #0x10
    // 0x521d94: ret
    //     0x521d94: ret             
    // 0x521d98: r0 = Null
    //     0x521d98: mov             x0, NULL
    // 0x521d9c: LeaveFrame
    //     0x521d9c: mov             SP, fp
    //     0x521da0: ldp             fp, lr, [SP], #0x10
    // 0x521da4: ret
    //     0x521da4: ret             
    // 0x521da8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x521da8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x521dac: b               #0x52189c
    // 0x521db0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x521db0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x521db4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x521db4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x521db8: b               #0x521aac
    // 0x521dbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x521dbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x521dc0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x521dc0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x521dc4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x521dc4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x521dc8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x521dc8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x521dcc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x521dcc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ layout(/* No info */) {
    // ** addr: 0x52362c, size: 0x31c
    // 0x52362c: EnterFrame
    //     0x52362c: stp             fp, lr, [SP, #-0x10]!
    //     0x523630: mov             fp, SP
    // 0x523634: AllocStack(0x18)
    //     0x523634: sub             SP, SP, #0x18
    // 0x523638: SetupParameters(TextPainter this /* r3, fp-0x8 */, {_Double maxWidth = inf /* d0, fp-0x18 */, _Double minWidth = 0.000000 /* d1, fp-0x10 */})
    //     0x523638: mov             x0, x4
    //     0x52363c: ldur            w1, [x0, #0x13]
    //     0x523640: add             x1, x1, HEAP, lsl #32
    //     0x523644: sub             x2, x1, #2
    //     0x523648: add             x3, fp, w2, sxtw #2
    //     0x52364c: ldr             x3, [x3, #0x10]
    //     0x523650: stur            x3, [fp, #-8]
    //     0x523654: ldur            w2, [x0, #0x1f]
    //     0x523658: add             x2, x2, HEAP, lsl #32
    //     0x52365c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f590] "maxWidth"
    //     0x523660: ldr             x16, [x16, #0x590]
    //     0x523664: cmp             w2, w16
    //     0x523668: b.ne            #0x52368c
    //     0x52366c: ldur            w2, [x0, #0x23]
    //     0x523670: add             x2, x2, HEAP, lsl #32
    //     0x523674: sub             w4, w1, w2
    //     0x523678: add             x2, fp, w4, sxtw #2
    //     0x52367c: ldr             x2, [x2, #8]
    //     0x523680: ldur            d0, [x2, #7]
    //     0x523684: mov             x2, #1
    //     0x523688: b               #0x523694
    //     0x52368c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    //     0x523690: mov             x2, #0
    //     0x523694: stur            d0, [fp, #-0x18]
    //     0x523698: lsl             x4, x2, #1
    //     0x52369c: lsl             w2, w4, #1
    //     0x5236a0: add             w4, w2, #8
    //     0x5236a4: add             x16, x0, w4, sxtw #1
    //     0x5236a8: ldur            w5, [x16, #0xf]
    //     0x5236ac: add             x5, x5, HEAP, lsl #32
    //     0x5236b0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f598] "minWidth"
    //     0x5236b4: ldr             x16, [x16, #0x598]
    //     0x5236b8: cmp             w5, w16
    //     0x5236bc: b.ne            #0x5236e4
    //     0x5236c0: add             w4, w2, #0xa
    //     0x5236c4: add             x16, x0, w4, sxtw #1
    //     0x5236c8: ldur            w2, [x16, #0xf]
    //     0x5236cc: add             x2, x2, HEAP, lsl #32
    //     0x5236d0: sub             w0, w1, w2
    //     0x5236d4: add             x1, fp, w0, sxtw #2
    //     0x5236d8: ldr             x1, [x1, #8]
    //     0x5236dc: ldur            d1, [x1, #7]
    //     0x5236e0: b               #0x5236e8
    //     0x5236e4: eor             v1.16b, v1.16b, v1.16b
    //     0x5236e8: stur            d1, [fp, #-0x10]
    // 0x5236ec: CheckStackOverflow
    //     0x5236ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5236f0: cmp             SP, x16
    //     0x5236f4: b.ls            #0x5238d0
    // 0x5236f8: LoadField: r0 = r3->field_7
    //     0x5236f8: ldur            w0, [x3, #7]
    // 0x5236fc: DecompressPointer r0
    //     0x5236fc: add             x0, x0, HEAP, lsl #32
    // 0x523700: cmp             w0, NULL
    // 0x523704: b.eq            #0x5237a0
    // 0x523708: LoadField: r0 = r3->field_4f
    //     0x523708: ldur            w0, [x3, #0x4f]
    // 0x52370c: DecompressPointer r0
    //     0x52370c: add             x0, x0, HEAP, lsl #32
    // 0x523710: r1 = inline_Allocate_Double()
    //     0x523710: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x523714: add             x1, x1, #0x10
    //     0x523718: cmp             x2, x1
    //     0x52371c: b.ls            #0x5238d8
    //     0x523720: str             x1, [THR, #0x60]  ; THR::top
    //     0x523724: sub             x1, x1, #0xf
    //     0x523728: mov             x2, #0xd108
    //     0x52372c: movk            x2, #3, lsl #16
    //     0x523730: stur            x2, [x1, #-1]
    // 0x523734: StoreField: r1->field_7 = d1
    //     0x523734: stur            d1, [x1, #7]
    // 0x523738: stp             x0, x1, [SP, #-0x10]!
    // 0x52373c: r0 = ==()
    //     0x52373c: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0x523740: add             SP, SP, #0x10
    // 0x523744: tbnz            w0, #4, #0x5237a0
    // 0x523748: ldur            x0, [fp, #-8]
    // 0x52374c: ldur            d0, [fp, #-0x18]
    // 0x523750: LoadField: r1 = r0->field_53
    //     0x523750: ldur            w1, [x0, #0x53]
    // 0x523754: DecompressPointer r1
    //     0x523754: add             x1, x1, HEAP, lsl #32
    // 0x523758: r2 = inline_Allocate_Double()
    //     0x523758: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x52375c: add             x2, x2, #0x10
    //     0x523760: cmp             x3, x2
    //     0x523764: b.ls            #0x5238f4
    //     0x523768: str             x2, [THR, #0x60]  ; THR::top
    //     0x52376c: sub             x2, x2, #0xf
    //     0x523770: mov             x3, #0xd108
    //     0x523774: movk            x3, #3, lsl #16
    //     0x523778: stur            x3, [x2, #-1]
    // 0x52377c: StoreField: r2->field_7 = d0
    //     0x52377c: stur            d0, [x2, #7]
    // 0x523780: stp             x1, x2, [SP, #-0x10]!
    // 0x523784: r0 = ==()
    //     0x523784: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0x523788: add             SP, SP, #0x10
    // 0x52378c: tbnz            w0, #4, #0x5237a0
    // 0x523790: r0 = Null
    //     0x523790: mov             x0, NULL
    // 0x523794: LeaveFrame
    //     0x523794: mov             SP, fp
    //     0x523798: ldp             fp, lr, [SP], #0x10
    // 0x52379c: ret
    //     0x52379c: ret             
    // 0x5237a0: ldur            x0, [fp, #-8]
    // 0x5237a4: LoadField: r1 = r0->field_b
    //     0x5237a4: ldur            w1, [x0, #0xb]
    // 0x5237a8: DecompressPointer r1
    //     0x5237a8: add             x1, x1, HEAP, lsl #32
    // 0x5237ac: tbz             w1, #4, #0x5237c0
    // 0x5237b0: LoadField: r1 = r0->field_7
    //     0x5237b0: ldur            w1, [x0, #7]
    // 0x5237b4: DecompressPointer r1
    //     0x5237b4: add             x1, x1, HEAP, lsl #32
    // 0x5237b8: cmp             w1, NULL
    // 0x5237bc: b.ne            #0x5237cc
    // 0x5237c0: SaveReg r0
    //     0x5237c0: str             x0, [SP, #-8]!
    // 0x5237c4: r0 = _createParagraph()
    //     0x5237c4: bl              #0x524058  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createParagraph
    // 0x5237c8: add             SP, SP, #8
    // 0x5237cc: ldur            x1, [fp, #-8]
    // 0x5237d0: ldur            d0, [fp, #-0x18]
    // 0x5237d4: ldur            d1, [fp, #-0x10]
    // 0x5237d8: r2 = inline_Allocate_Double()
    //     0x5237d8: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x5237dc: add             x2, x2, #0x10
    //     0x5237e0: cmp             x0, x2
    //     0x5237e4: b.ls            #0x523910
    //     0x5237e8: str             x2, [THR, #0x60]  ; THR::top
    //     0x5237ec: sub             x2, x2, #0xf
    //     0x5237f0: mov             x0, #0xd108
    //     0x5237f4: movk            x0, #3, lsl #16
    //     0x5237f8: stur            x0, [x2, #-1]
    // 0x5237fc: StoreField: r2->field_7 = d1
    //     0x5237fc: stur            d1, [x2, #7]
    // 0x523800: mov             x0, x2
    // 0x523804: StoreField: r1->field_4f = r0
    //     0x523804: stur            w0, [x1, #0x4f]
    //     0x523808: ldurb           w16, [x1, #-1]
    //     0x52380c: ldurb           w17, [x0, #-1]
    //     0x523810: and             x16, x17, x16, lsr #2
    //     0x523814: tst             x16, HEAP, lsr #32
    //     0x523818: b.eq            #0x523820
    //     0x52381c: bl              #0xd6826c
    // 0x523820: r0 = inline_Allocate_Double()
    //     0x523820: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x523824: add             x0, x0, #0x10
    //     0x523828: cmp             x3, x0
    //     0x52382c: b.ls            #0x52392c
    //     0x523830: str             x0, [THR, #0x60]  ; THR::top
    //     0x523834: sub             x0, x0, #0xf
    //     0x523838: mov             x3, #0xd108
    //     0x52383c: movk            x3, #3, lsl #16
    //     0x523840: stur            x3, [x0, #-1]
    // 0x523844: StoreField: r0->field_7 = d0
    //     0x523844: stur            d0, [x0, #7]
    // 0x523848: StoreField: r1->field_53 = r0
    //     0x523848: stur            w0, [x1, #0x53]
    //     0x52384c: ldurb           w16, [x1, #-1]
    //     0x523850: ldurb           w17, [x0, #-1]
    //     0x523854: and             x16, x17, x16, lsr #2
    //     0x523858: tst             x16, HEAP, lsr #32
    //     0x52385c: b.eq            #0x523864
    //     0x523860: bl              #0xd6826c
    // 0x523864: StoreField: r1->field_63 = rNULL
    //     0x523864: stur            NULL, [x1, #0x63]
    // 0x523868: StoreField: r1->field_5b = rNULL
    //     0x523868: stur            NULL, [x1, #0x5b]
    // 0x52386c: StoreField: r1->field_5f = rNULL
    //     0x52386c: stur            NULL, [x1, #0x5f]
    // 0x523870: stp             x2, x1, [SP, #-0x10]!
    // 0x523874: SaveReg d0
    //     0x523874: str             d0, [SP, #-8]!
    // 0x523878: r0 = _layoutParagraph()
    //     0x523878: bl              #0x523ce0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_layoutParagraph
    // 0x52387c: add             SP, SP, #0x18
    // 0x523880: ldur            x0, [fp, #-8]
    // 0x523884: LoadField: r1 = r0->field_7
    //     0x523884: ldur            w1, [x0, #7]
    // 0x523888: DecompressPointer r1
    //     0x523888: add             x1, x1, HEAP, lsl #32
    // 0x52388c: cmp             w1, NULL
    // 0x523890: b.eq            #0x523944
    // 0x523894: SaveReg r1
    //     0x523894: str             x1, [SP, #-8]!
    // 0x523898: r0 = getBoxesForPlaceholders()
    //     0x523898: bl              #0x523948  ; [dart:ui] Paragraph::getBoxesForPlaceholders
    // 0x52389c: add             SP, SP, #8
    // 0x5238a0: ldur            x1, [fp, #-8]
    // 0x5238a4: StoreField: r1->field_3f = r0
    //     0x5238a4: stur            w0, [x1, #0x3f]
    //     0x5238a8: ldurb           w16, [x1, #-1]
    //     0x5238ac: ldurb           w17, [x0, #-1]
    //     0x5238b0: and             x16, x17, x16, lsr #2
    //     0x5238b4: tst             x16, HEAP, lsr #32
    //     0x5238b8: b.eq            #0x5238c0
    //     0x5238bc: bl              #0xd6826c
    // 0x5238c0: r0 = Null
    //     0x5238c0: mov             x0, NULL
    // 0x5238c4: LeaveFrame
    //     0x5238c4: mov             SP, fp
    //     0x5238c8: ldp             fp, lr, [SP], #0x10
    // 0x5238cc: ret
    //     0x5238cc: ret             
    // 0x5238d0: r0 = StackOverflowSharedWithFPURegs()
    //     0x5238d0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x5238d4: b               #0x5236f8
    // 0x5238d8: stp             q0, q1, [SP, #-0x20]!
    // 0x5238dc: stp             x0, x3, [SP, #-0x10]!
    // 0x5238e0: r0 = AllocateDouble()
    //     0x5238e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5238e4: mov             x1, x0
    // 0x5238e8: ldp             x0, x3, [SP], #0x10
    // 0x5238ec: ldp             q0, q1, [SP], #0x20
    // 0x5238f0: b               #0x523734
    // 0x5238f4: SaveReg d0
    //     0x5238f4: str             q0, [SP, #-0x10]!
    // 0x5238f8: stp             x0, x1, [SP, #-0x10]!
    // 0x5238fc: r0 = AllocateDouble()
    //     0x5238fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x523900: mov             x2, x0
    // 0x523904: ldp             x0, x1, [SP], #0x10
    // 0x523908: RestoreReg d0
    //     0x523908: ldr             q0, [SP], #0x10
    // 0x52390c: b               #0x52377c
    // 0x523910: stp             q0, q1, [SP, #-0x20]!
    // 0x523914: SaveReg r1
    //     0x523914: str             x1, [SP, #-8]!
    // 0x523918: r0 = AllocateDouble()
    //     0x523918: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x52391c: mov             x2, x0
    // 0x523920: RestoreReg r1
    //     0x523920: ldr             x1, [SP], #8
    // 0x523924: ldp             q0, q1, [SP], #0x20
    // 0x523928: b               #0x5237fc
    // 0x52392c: SaveReg d0
    //     0x52392c: str             q0, [SP, #-0x10]!
    // 0x523930: stp             x1, x2, [SP, #-0x10]!
    // 0x523934: r0 = AllocateDouble()
    //     0x523934: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x523938: ldp             x1, x2, [SP], #0x10
    // 0x52393c: RestoreReg d0
    //     0x52393c: ldr             q0, [SP], #0x10
    // 0x523940: b               #0x523844
    // 0x523944: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x523944: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _layoutParagraph(/* No info */) {
    // ** addr: 0x523ce0, size: 0x164
    // 0x523ce0: EnterFrame
    //     0x523ce0: stp             fp, lr, [SP, #-0x10]!
    //     0x523ce4: mov             fp, SP
    // 0x523ce8: AllocStack(0x10)
    //     0x523ce8: sub             SP, SP, #0x10
    // 0x523cec: CheckStackOverflow
    //     0x523cec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x523cf0: cmp             SP, x16
    //     0x523cf4: b.ls            #0x523e30
    // 0x523cf8: ldr             x0, [fp, #0x20]
    // 0x523cfc: LoadField: r1 = r0->field_7
    //     0x523cfc: ldur            w1, [x0, #7]
    // 0x523d00: DecompressPointer r1
    //     0x523d00: add             x1, x1, HEAP, lsl #32
    // 0x523d04: stur            x1, [fp, #-8]
    // 0x523d08: cmp             w1, NULL
    // 0x523d0c: b.eq            #0x523e38
    // 0x523d10: r0 = ParagraphConstraints()
    //     0x523d10: bl              #0x52404c  ; AllocateParagraphConstraintsStub -> ParagraphConstraints (size=0x10)
    // 0x523d14: ldr             d0, [fp, #0x10]
    // 0x523d18: StoreField: r0->field_7 = d0
    //     0x523d18: stur            d0, [x0, #7]
    // 0x523d1c: ldur            x16, [fp, #-8]
    // 0x523d20: stp             x0, x16, [SP, #-0x10]!
    // 0x523d24: r0 = layout()
    //     0x523d24: bl              #0x51a818  ; [dart:ui] Paragraph::layout
    // 0x523d28: add             SP, SP, #0x10
    // 0x523d2c: ldr             x0, [fp, #0x18]
    // 0x523d30: LoadField: d0 = r0->field_7
    //     0x523d30: ldur            d0, [x0, #7]
    // 0x523d34: ldr             d1, [fp, #0x10]
    // 0x523d38: stur            d0, [fp, #-0x10]
    // 0x523d3c: fcmp            d0, d1
    // 0x523d40: b.eq            #0x523e20
    // 0x523d44: ldr             x16, [fp, #0x20]
    // 0x523d48: SaveReg r16
    //     0x523d48: str             x16, [SP, #-8]!
    // 0x523d4c: r0 = maxIntrinsicWidth()
    //     0x523d4c: bl              #0x523e44  ; [package:flutter/src/painting/text_painter.dart] TextPainter::maxIntrinsicWidth
    // 0x523d50: add             SP, SP, #8
    // 0x523d54: mov             v1.16b, v0.16b
    // 0x523d58: ldur            d0, [fp, #-0x10]
    // 0x523d5c: fcmp            d1, d0
    // 0x523d60: b.vs            #0x523d68
    // 0x523d64: b.lt            #0x523d84
    // 0x523d68: ldr             d0, [fp, #0x10]
    // 0x523d6c: fcmp            d1, d0
    // 0x523d70: b.vs            #0x523d78
    // 0x523d74: b.gt            #0x523d84
    // 0x523d78: fcmp            d1, d1
    // 0x523d7c: b.vs            #0x523d84
    // 0x523d80: mov             v0.16b, v1.16b
    // 0x523d84: ldr             x0, [fp, #0x20]
    // 0x523d88: stur            d0, [fp, #-0x10]
    // 0x523d8c: LoadField: r1 = r0->field_7
    //     0x523d8c: ldur            w1, [x0, #7]
    // 0x523d90: DecompressPointer r1
    //     0x523d90: add             x1, x1, HEAP, lsl #32
    // 0x523d94: cmp             w1, NULL
    // 0x523d98: b.eq            #0x523e3c
    // 0x523d9c: SaveReg r1
    //     0x523d9c: str             x1, [SP, #-8]!
    // 0x523da0: r0 = width()
    //     0x523da0: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0x523da4: add             SP, SP, #8
    // 0x523da8: stp             fp, lr, [SP, #-0x10]!
    // 0x523dac: mov             fp, SP
    // 0x523db0: CallRuntime_LibcCeil(double) -> double
    //     0x523db0: and             SP, SP, #0xfffffffffffffff0
    //     0x523db4: mov             sp, SP
    //     0x523db8: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x523dbc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x523dc0: blr             x16
    //     0x523dc4: mov             x16, #8
    //     0x523dc8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x523dcc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x523dd0: sub             sp, x16, #1, lsl #12
    //     0x523dd4: mov             SP, fp
    //     0x523dd8: ldp             fp, lr, [SP], #0x10
    // 0x523ddc: mov             v1.16b, v0.16b
    // 0x523de0: ldur            d0, [fp, #-0x10]
    // 0x523de4: fcmp            d0, d1
    // 0x523de8: b.eq            #0x523e20
    // 0x523dec: ldr             x0, [fp, #0x20]
    // 0x523df0: LoadField: r1 = r0->field_7
    //     0x523df0: ldur            w1, [x0, #7]
    // 0x523df4: DecompressPointer r1
    //     0x523df4: add             x1, x1, HEAP, lsl #32
    // 0x523df8: stur            x1, [fp, #-8]
    // 0x523dfc: cmp             w1, NULL
    // 0x523e00: b.eq            #0x523e40
    // 0x523e04: r0 = ParagraphConstraints()
    //     0x523e04: bl              #0x52404c  ; AllocateParagraphConstraintsStub -> ParagraphConstraints (size=0x10)
    // 0x523e08: ldur            d0, [fp, #-0x10]
    // 0x523e0c: StoreField: r0->field_7 = d0
    //     0x523e0c: stur            d0, [x0, #7]
    // 0x523e10: ldur            x16, [fp, #-8]
    // 0x523e14: stp             x0, x16, [SP, #-0x10]!
    // 0x523e18: r0 = layout()
    //     0x523e18: bl              #0x51a818  ; [dart:ui] Paragraph::layout
    // 0x523e1c: add             SP, SP, #0x10
    // 0x523e20: r0 = Null
    //     0x523e20: mov             x0, NULL
    // 0x523e24: LeaveFrame
    //     0x523e24: mov             SP, fp
    //     0x523e28: ldp             fp, lr, [SP], #0x10
    // 0x523e2c: ret
    //     0x523e2c: ret             
    // 0x523e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x523e30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x523e34: b               #0x523cf8
    // 0x523e38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x523e38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x523e3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x523e3c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x523e40: r0 = NullCastErrorSharedWithFPURegs()
    //     0x523e40: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ maxIntrinsicWidth(/* No info */) {
    // ** addr: 0x523e44, size: 0x80
    // 0x523e44: EnterFrame
    //     0x523e44: stp             fp, lr, [SP, #-0x10]!
    //     0x523e48: mov             fp, SP
    // 0x523e4c: CheckStackOverflow
    //     0x523e4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x523e50: cmp             SP, x16
    //     0x523e54: b.ls            #0x523eb8
    // 0x523e58: ldr             x0, [fp, #0x10]
    // 0x523e5c: LoadField: r1 = r0->field_7
    //     0x523e5c: ldur            w1, [x0, #7]
    // 0x523e60: DecompressPointer r1
    //     0x523e60: add             x1, x1, HEAP, lsl #32
    // 0x523e64: cmp             w1, NULL
    // 0x523e68: b.eq            #0x523ec0
    // 0x523e6c: SaveReg r1
    //     0x523e6c: str             x1, [SP, #-8]!
    // 0x523e70: r0 = maxIntrinsicWidth()
    //     0x523e70: bl              #0x523ec4  ; [dart:ui] Paragraph::maxIntrinsicWidth
    // 0x523e74: add             SP, SP, #8
    // 0x523e78: stp             fp, lr, [SP, #-0x10]!
    // 0x523e7c: mov             fp, SP
    // 0x523e80: CallRuntime_LibcCeil(double) -> double
    //     0x523e80: and             SP, SP, #0xfffffffffffffff0
    //     0x523e84: mov             sp, SP
    //     0x523e88: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x523e8c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x523e90: blr             x16
    //     0x523e94: mov             x16, #8
    //     0x523e98: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x523e9c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x523ea0: sub             sp, x16, #1, lsl #12
    //     0x523ea4: mov             SP, fp
    //     0x523ea8: ldp             fp, lr, [SP], #0x10
    // 0x523eac: LeaveFrame
    //     0x523eac: mov             SP, fp
    //     0x523eb0: ldp             fp, lr, [SP], #0x10
    // 0x523eb4: ret
    //     0x523eb4: ret             
    // 0x523eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x523eb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x523ebc: b               #0x523e58
    // 0x523ec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x523ec0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createParagraph(/* No info */) {
    // ** addr: 0x524058, size: 0x134
    // 0x524058: EnterFrame
    //     0x524058: stp             fp, lr, [SP, #-0x10]!
    //     0x52405c: mov             fp, SP
    // 0x524060: AllocStack(0x18)
    //     0x524060: sub             SP, SP, #0x18
    // 0x524064: CheckStackOverflow
    //     0x524064: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x524068: cmp             SP, x16
    //     0x52406c: b.ls            #0x524184
    // 0x524070: ldr             x0, [fp, #0x10]
    // 0x524074: LoadField: r1 = r0->field_f
    //     0x524074: ldur            w1, [x0, #0xf]
    // 0x524078: DecompressPointer r1
    //     0x524078: add             x1, x1, HEAP, lsl #32
    // 0x52407c: stur            x1, [fp, #-8]
    // 0x524080: cmp             w1, NULL
    // 0x524084: b.eq            #0x524164
    // 0x524088: SaveReg r0
    //     0x524088: str             x0, [SP, #-8]!
    // 0x52408c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x52408c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x524090: r0 = _createParagraphStyle()
    //     0x524090: bl              #0x51dba0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createParagraphStyle
    // 0x524094: add             SP, SP, #8
    // 0x524098: stur            x0, [fp, #-0x10]
    // 0x52409c: r0 = ParagraphBuilder()
    //     0x52409c: bl              #0x51db94  ; AllocateParagraphBuilderStub -> ParagraphBuilder (size=0x1c)
    // 0x5240a0: stur            x0, [fp, #-0x18]
    // 0x5240a4: ldur            x16, [fp, #-0x10]
    // 0x5240a8: stp             x16, x0, [SP, #-0x10]!
    // 0x5240ac: r0 = ParagraphBuilder()
    //     0x5240ac: bl              #0x4f5280  ; [dart:ui] ParagraphBuilder::ParagraphBuilder
    // 0x5240b0: add             SP, SP, #0x10
    // 0x5240b4: ldr             x1, [fp, #0x10]
    // 0x5240b8: LoadField: d0 = r1->field_1f
    //     0x5240b8: ldur            d0, [x1, #0x1f]
    // 0x5240bc: LoadField: r0 = r1->field_47
    //     0x5240bc: ldur            w0, [x1, #0x47]
    // 0x5240c0: DecompressPointer r0
    //     0x5240c0: add             x0, x0, HEAP, lsl #32
    // 0x5240c4: ldur            x2, [fp, #-8]
    // 0x5240c8: r3 = LoadClassIdInstr(r2)
    //     0x5240c8: ldur            x3, [x2, #-1]
    //     0x5240cc: ubfx            x3, x3, #0xc, #0x14
    // 0x5240d0: ldur            x16, [fp, #-0x18]
    // 0x5240d4: stp             x16, x2, [SP, #-0x10]!
    // 0x5240d8: SaveReg r0
    //     0x5240d8: str             x0, [SP, #-8]!
    // 0x5240dc: SaveReg d0
    //     0x5240dc: str             d0, [SP, #-8]!
    // 0x5240e0: mov             x0, x3
    // 0x5240e4: r0 = GDT[cid_x0 + -0xe79]()
    //     0x5240e4: sub             lr, x0, #0xe79
    //     0x5240e8: ldr             lr, [x21, lr, lsl #3]
    //     0x5240ec: blr             lr
    // 0x5240f0: add             SP, SP, #0x20
    // 0x5240f4: ldur            x1, [fp, #-0x18]
    // 0x5240f8: LoadField: r0 = r1->field_13
    //     0x5240f8: ldur            w0, [x1, #0x13]
    // 0x5240fc: DecompressPointer r0
    //     0x5240fc: add             x0, x0, HEAP, lsl #32
    // 0x524100: ldr             x2, [fp, #0x10]
    // 0x524104: StoreField: r2->field_43 = r0
    //     0x524104: stur            w0, [x2, #0x43]
    //     0x524108: ldurb           w16, [x2, #-1]
    //     0x52410c: ldurb           w17, [x0, #-1]
    //     0x524110: and             x16, x17, x16, lsr #2
    //     0x524114: tst             x16, HEAP, lsr #32
    //     0x524118: b.eq            #0x524120
    //     0x52411c: bl              #0xd6828c
    // 0x524120: SaveReg r1
    //     0x524120: str             x1, [SP, #-8]!
    // 0x524124: r0 = build()
    //     0x524124: bl              #0x51aac4  ; [dart:ui] ParagraphBuilder::build
    // 0x524128: add             SP, SP, #8
    // 0x52412c: ldr             x1, [fp, #0x10]
    // 0x524130: StoreField: r1->field_7 = r0
    //     0x524130: stur            w0, [x1, #7]
    //     0x524134: ldurb           w16, [x1, #-1]
    //     0x524138: ldurb           w17, [x0, #-1]
    //     0x52413c: and             x16, x17, x16, lsr #2
    //     0x524140: tst             x16, HEAP, lsr #32
    //     0x524144: b.eq            #0x52414c
    //     0x524148: bl              #0xd6826c
    // 0x52414c: r2 = false
    //     0x52414c: add             x2, NULL, #0x30  ; false
    // 0x524150: StoreField: r1->field_b = r2
    //     0x524150: stur            w2, [x1, #0xb]
    // 0x524154: r0 = Null
    //     0x524154: mov             x0, NULL
    // 0x524158: LeaveFrame
    //     0x524158: mov             SP, fp
    //     0x52415c: ldp             fp, lr, [SP], #0x10
    // 0x524160: ret
    //     0x524160: ret             
    // 0x524164: r0 = StateError()
    //     0x524164: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x524168: mov             x1, x0
    // 0x52416c: r0 = "TextPainter.text must be set to a non-null value before using the TextPainter."
    //     0x52416c: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f5d0] "TextPainter.text must be set to a non-null value before using the TextPainter."
    //     0x524170: ldr             x0, [x0, #0x5d0]
    // 0x524174: StoreField: r1->field_b = r0
    //     0x524174: stur            w0, [x1, #0xb]
    // 0x524178: mov             x0, x1
    // 0x52417c: r0 = Throw()
    //     0x52417c: bl              #0xd67e38  ; ThrowStub
    // 0x524180: brk             #0
    // 0x524184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x524184: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x524188: b               #0x524070
  }
  get _ size(/* No info */) {
    // ** addr: 0x59f534, size: 0x68
    // 0x59f534: EnterFrame
    //     0x59f534: stp             fp, lr, [SP, #-0x10]!
    //     0x59f538: mov             fp, SP
    // 0x59f53c: AllocStack(0x10)
    //     0x59f53c: sub             SP, SP, #0x10
    // 0x59f540: CheckStackOverflow
    //     0x59f540: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59f544: cmp             SP, x16
    //     0x59f548: b.ls            #0x59f594
    // 0x59f54c: ldr             x16, [fp, #0x10]
    // 0x59f550: SaveReg r16
    //     0x59f550: str             x16, [SP, #-8]!
    // 0x59f554: r0 = width()
    //     0x59f554: bl              #0x520e64  ; [package:flutter/src/painting/text_painter.dart] TextPainter::width
    // 0x59f558: add             SP, SP, #8
    // 0x59f55c: stur            d0, [fp, #-8]
    // 0x59f560: ldr             x16, [fp, #0x10]
    // 0x59f564: SaveReg r16
    //     0x59f564: str             x16, [SP, #-8]!
    // 0x59f568: r0 = height()
    //     0x59f568: bl              #0x59f59c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0x59f56c: add             SP, SP, #8
    // 0x59f570: stur            d0, [fp, #-0x10]
    // 0x59f574: r0 = Size()
    //     0x59f574: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x59f578: ldur            d0, [fp, #-8]
    // 0x59f57c: StoreField: r0->field_7 = d0
    //     0x59f57c: stur            d0, [x0, #7]
    // 0x59f580: ldur            d0, [fp, #-0x10]
    // 0x59f584: StoreField: r0->field_f = d0
    //     0x59f584: stur            d0, [x0, #0xf]
    // 0x59f588: LeaveFrame
    //     0x59f588: mov             SP, fp
    //     0x59f58c: ldp             fp, lr, [SP], #0x10
    // 0x59f590: ret
    //     0x59f590: ret             
    // 0x59f594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59f594: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59f598: b               #0x59f54c
  }
  get _ height(/* No info */) {
    // ** addr: 0x59f59c, size: 0x80
    // 0x59f59c: EnterFrame
    //     0x59f59c: stp             fp, lr, [SP, #-0x10]!
    //     0x59f5a0: mov             fp, SP
    // 0x59f5a4: CheckStackOverflow
    //     0x59f5a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59f5a8: cmp             SP, x16
    //     0x59f5ac: b.ls            #0x59f610
    // 0x59f5b0: ldr             x0, [fp, #0x10]
    // 0x59f5b4: LoadField: r1 = r0->field_7
    //     0x59f5b4: ldur            w1, [x0, #7]
    // 0x59f5b8: DecompressPointer r1
    //     0x59f5b8: add             x1, x1, HEAP, lsl #32
    // 0x59f5bc: cmp             w1, NULL
    // 0x59f5c0: b.eq            #0x59f618
    // 0x59f5c4: SaveReg r1
    //     0x59f5c4: str             x1, [SP, #-8]!
    // 0x59f5c8: r0 = height()
    //     0x59f5c8: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x59f5cc: add             SP, SP, #8
    // 0x59f5d0: stp             fp, lr, [SP, #-0x10]!
    // 0x59f5d4: mov             fp, SP
    // 0x59f5d8: CallRuntime_LibcCeil(double) -> double
    //     0x59f5d8: and             SP, SP, #0xfffffffffffffff0
    //     0x59f5dc: mov             sp, SP
    //     0x59f5e0: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x59f5e4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x59f5e8: blr             x16
    //     0x59f5ec: mov             x16, #8
    //     0x59f5f0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x59f5f4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x59f5f8: sub             sp, x16, #1, lsl #12
    //     0x59f5fc: mov             SP, fp
    //     0x59f600: ldp             fp, lr, [SP], #0x10
    // 0x59f604: LeaveFrame
    //     0x59f604: mov             SP, fp
    //     0x59f608: ldp             fp, lr, [SP], #0x10
    // 0x59f60c: ret
    //     0x59f60c: ret             
    // 0x59f610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59f610: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59f614: b               #0x59f5b0
    // 0x59f618: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x59f618: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getPositionForOffset(/* No info */) {
    // ** addr: 0x6246bc, size: 0x50
    // 0x6246bc: EnterFrame
    //     0x6246bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6246c0: mov             fp, SP
    // 0x6246c4: CheckStackOverflow
    //     0x6246c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6246c8: cmp             SP, x16
    //     0x6246cc: b.ls            #0x624700
    // 0x6246d0: ldr             x0, [fp, #0x18]
    // 0x6246d4: LoadField: r1 = r0->field_7
    //     0x6246d4: ldur            w1, [x0, #7]
    // 0x6246d8: DecompressPointer r1
    //     0x6246d8: add             x1, x1, HEAP, lsl #32
    // 0x6246dc: cmp             w1, NULL
    // 0x6246e0: b.eq            #0x624708
    // 0x6246e4: ldr             x16, [fp, #0x10]
    // 0x6246e8: stp             x16, x1, [SP, #-0x10]!
    // 0x6246ec: r0 = getPositionForOffset()
    //     0x6246ec: bl              #0x62470c  ; [dart:ui] Paragraph::getPositionForOffset
    // 0x6246f0: add             SP, SP, #0x10
    // 0x6246f4: LeaveFrame
    //     0x6246f4: mov             SP, fp
    //     0x6246f8: ldp             fp, lr, [SP], #0x10
    // 0x6246fc: ret
    //     0x6246fc: ret             
    // 0x624700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x624700: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x624704: b               #0x6246d0
    // 0x624708: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x624708: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setPlaceholderDimensions(/* No info */) {
    // ** addr: 0x62d480, size: 0xcc
    // 0x62d480: EnterFrame
    //     0x62d480: stp             fp, lr, [SP, #-0x10]!
    //     0x62d484: mov             fp, SP
    // 0x62d488: CheckStackOverflow
    //     0x62d488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d48c: cmp             SP, x16
    //     0x62d490: b.ls            #0x62d544
    // 0x62d494: ldr             x1, [fp, #0x10]
    // 0x62d498: cmp             w1, NULL
    // 0x62d49c: b.eq            #0x62d4f4
    // 0x62d4a0: r0 = LoadClassIdInstr(r1)
    //     0x62d4a0: ldur            x0, [x1, #-1]
    //     0x62d4a4: ubfx            x0, x0, #0xc, #0x14
    // 0x62d4a8: SaveReg r1
    //     0x62d4a8: str             x1, [SP, #-8]!
    // 0x62d4ac: r0 = GDT[cid_x0 + 0xccd1]()
    //     0x62d4ac: mov             x17, #0xccd1
    //     0x62d4b0: add             lr, x0, x17
    //     0x62d4b4: ldr             lr, [x21, lr, lsl #3]
    //     0x62d4b8: blr             lr
    // 0x62d4bc: add             SP, SP, #8
    // 0x62d4c0: tbz             w0, #4, #0x62d4f4
    // 0x62d4c4: ldr             x0, [fp, #0x18]
    // 0x62d4c8: LoadField: r1 = r0->field_47
    //     0x62d4c8: ldur            w1, [x0, #0x47]
    // 0x62d4cc: DecompressPointer r1
    //     0x62d4cc: add             x1, x1, HEAP, lsl #32
    // 0x62d4d0: r16 = <PlaceholderDimensions>
    //     0x62d4d0: add             x16, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x62d4d4: ldr             x16, [x16, #0x320]
    // 0x62d4d8: ldr             lr, [fp, #0x10]
    // 0x62d4dc: stp             lr, x16, [SP, #-0x10]!
    // 0x62d4e0: SaveReg r1
    //     0x62d4e0: str             x1, [SP, #-8]!
    // 0x62d4e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x62d4e4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x62d4e8: r0 = listEquals()
    //     0x62d4e8: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x62d4ec: add             SP, SP, #0x18
    // 0x62d4f0: tbnz            w0, #4, #0x62d504
    // 0x62d4f4: r0 = Null
    //     0x62d4f4: mov             x0, NULL
    // 0x62d4f8: LeaveFrame
    //     0x62d4f8: mov             SP, fp
    //     0x62d4fc: ldp             fp, lr, [SP], #0x10
    // 0x62d500: ret
    //     0x62d500: ret             
    // 0x62d504: ldr             x1, [fp, #0x18]
    // 0x62d508: ldr             x0, [fp, #0x10]
    // 0x62d50c: StoreField: r1->field_47 = r0
    //     0x62d50c: stur            w0, [x1, #0x47]
    //     0x62d510: ldurb           w16, [x1, #-1]
    //     0x62d514: ldurb           w17, [x0, #-1]
    //     0x62d518: and             x16, x17, x16, lsr #2
    //     0x62d51c: tst             x16, HEAP, lsr #32
    //     0x62d520: b.eq            #0x62d528
    //     0x62d524: bl              #0xd6826c
    // 0x62d528: SaveReg r1
    //     0x62d528: str             x1, [SP, #-8]!
    // 0x62d52c: r0 = markNeedsLayout()
    //     0x62d52c: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x62d530: add             SP, SP, #8
    // 0x62d534: r0 = Null
    //     0x62d534: mov             x0, NULL
    // 0x62d538: LeaveFrame
    //     0x62d538: mov             SP, fp
    //     0x62d53c: ldp             fp, lr, [SP], #0x10
    // 0x62d540: ret
    //     0x62d540: ret             
    // 0x62d544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d544: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d548: b               #0x62d494
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0x62d54c, size: 0x68
    // 0x62d54c: EnterFrame
    //     0x62d54c: stp             fp, lr, [SP, #-0x10]!
    //     0x62d550: mov             fp, SP
    // 0x62d554: CheckStackOverflow
    //     0x62d554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d558: cmp             SP, x16
    //     0x62d55c: b.ls            #0x62d5ac
    // 0x62d560: ldr             x0, [fp, #0x10]
    // 0x62d564: LoadField: r1 = r0->field_7
    //     0x62d564: ldur            w1, [x0, #7]
    // 0x62d568: DecompressPointer r1
    //     0x62d568: add             x1, x1, HEAP, lsl #32
    // 0x62d56c: cmp             w1, NULL
    // 0x62d570: b.ne            #0x62d57c
    // 0x62d574: mov             x1, x0
    // 0x62d578: b               #0x62d58c
    // 0x62d57c: SaveReg r1
    //     0x62d57c: str             x1, [SP, #-8]!
    // 0x62d580: r0 = _dispose()
    //     0x62d580: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x62d584: add             SP, SP, #8
    // 0x62d588: ldr             x1, [fp, #0x10]
    // 0x62d58c: StoreField: r1->field_7 = rNULL
    //     0x62d58c: stur            NULL, [x1, #7]
    // 0x62d590: StoreField: r1->field_63 = rNULL
    //     0x62d590: stur            NULL, [x1, #0x63]
    // 0x62d594: StoreField: r1->field_5b = rNULL
    //     0x62d594: stur            NULL, [x1, #0x5b]
    // 0x62d598: StoreField: r1->field_5f = rNULL
    //     0x62d598: stur            NULL, [x1, #0x5f]
    // 0x62d59c: r0 = Null
    //     0x62d59c: mov             x0, NULL
    // 0x62d5a0: LeaveFrame
    //     0x62d5a0: mov             SP, fp
    //     0x62d5a4: ldp             fp, lr, [SP], #0x10
    // 0x62d5a8: ret
    //     0x62d5a8: ret             
    // 0x62d5ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d5ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d5b0: b               #0x62d560
  }
  get _ minIntrinsicWidth(/* No info */) {
    // ** addr: 0x63a8dc, size: 0x80
    // 0x63a8dc: EnterFrame
    //     0x63a8dc: stp             fp, lr, [SP, #-0x10]!
    //     0x63a8e0: mov             fp, SP
    // 0x63a8e4: CheckStackOverflow
    //     0x63a8e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63a8e8: cmp             SP, x16
    //     0x63a8ec: b.ls            #0x63a950
    // 0x63a8f0: ldr             x0, [fp, #0x10]
    // 0x63a8f4: LoadField: r1 = r0->field_7
    //     0x63a8f4: ldur            w1, [x0, #7]
    // 0x63a8f8: DecompressPointer r1
    //     0x63a8f8: add             x1, x1, HEAP, lsl #32
    // 0x63a8fc: cmp             w1, NULL
    // 0x63a900: b.eq            #0x63a958
    // 0x63a904: SaveReg r1
    //     0x63a904: str             x1, [SP, #-8]!
    // 0x63a908: r0 = minIntrinsicWidth()
    //     0x63a908: bl              #0x63a95c  ; [dart:ui] Paragraph::minIntrinsicWidth
    // 0x63a90c: add             SP, SP, #8
    // 0x63a910: stp             fp, lr, [SP, #-0x10]!
    // 0x63a914: mov             fp, SP
    // 0x63a918: CallRuntime_LibcCeil(double) -> double
    //     0x63a918: and             SP, SP, #0xfffffffffffffff0
    //     0x63a91c: mov             sp, SP
    //     0x63a920: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x63a924: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x63a928: blr             x16
    //     0x63a92c: mov             x16, #8
    //     0x63a930: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x63a934: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x63a938: sub             sp, x16, #1, lsl #12
    //     0x63a93c: mov             SP, fp
    //     0x63a940: ldp             fp, lr, [SP], #0x10
    // 0x63a944: LeaveFrame
    //     0x63a944: mov             SP, fp
    //     0x63a948: ldp             fp, lr, [SP], #0x10
    // 0x63a94c: ret
    //     0x63a94c: ret             
    // 0x63a950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63a950: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63a954: b               #0x63a8f0
    // 0x63a958: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63a958: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63da90, size: 0xfc
    // 0x63da90: EnterFrame
    //     0x63da90: stp             fp, lr, [SP, #-0x10]!
    //     0x63da94: mov             fp, SP
    // 0x63da98: CheckStackOverflow
    //     0x63da98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63da9c: cmp             SP, x16
    //     0x63daa0: b.ls            #0x63db5c
    // 0x63daa4: ldr             x0, [fp, #0x10]
    // 0x63daa8: LoadField: r1 = r0->field_7
    //     0x63daa8: ldur            x1, [x0, #7]
    // 0x63daac: cmp             x1, #0
    // 0x63dab0: b.gt            #0x63db08
    // 0x63dab4: ldr             x0, [fp, #0x18]
    // 0x63dab8: LoadField: r1 = r0->field_7
    //     0x63dab8: ldur            w1, [x0, #7]
    // 0x63dabc: DecompressPointer r1
    //     0x63dabc: add             x1, x1, HEAP, lsl #32
    // 0x63dac0: cmp             w1, NULL
    // 0x63dac4: b.eq            #0x63db64
    // 0x63dac8: SaveReg r1
    //     0x63dac8: str             x1, [SP, #-8]!
    // 0x63dacc: r0 = alphabeticBaseline()
    //     0x63dacc: bl              #0x63dd14  ; [dart:ui] Paragraph::alphabeticBaseline
    // 0x63dad0: add             SP, SP, #8
    // 0x63dad4: r0 = inline_Allocate_Double()
    //     0x63dad4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63dad8: add             x0, x0, #0x10
    //     0x63dadc: cmp             x1, x0
    //     0x63dae0: b.ls            #0x63db68
    //     0x63dae4: str             x0, [THR, #0x60]  ; THR::top
    //     0x63dae8: sub             x0, x0, #0xf
    //     0x63daec: mov             x1, #0xd108
    //     0x63daf0: movk            x1, #3, lsl #16
    //     0x63daf4: stur            x1, [x0, #-1]
    // 0x63daf8: StoreField: r0->field_7 = d0
    //     0x63daf8: stur            d0, [x0, #7]
    // 0x63dafc: LeaveFrame
    //     0x63dafc: mov             SP, fp
    //     0x63db00: ldp             fp, lr, [SP], #0x10
    // 0x63db04: ret
    //     0x63db04: ret             
    // 0x63db08: ldr             x0, [fp, #0x18]
    // 0x63db0c: LoadField: r1 = r0->field_7
    //     0x63db0c: ldur            w1, [x0, #7]
    // 0x63db10: DecompressPointer r1
    //     0x63db10: add             x1, x1, HEAP, lsl #32
    // 0x63db14: cmp             w1, NULL
    // 0x63db18: b.eq            #0x63db78
    // 0x63db1c: SaveReg r1
    //     0x63db1c: str             x1, [SP, #-8]!
    // 0x63db20: r0 = ideographicBaseline()
    //     0x63db20: bl              #0x63db8c  ; [dart:ui] Paragraph::ideographicBaseline
    // 0x63db24: add             SP, SP, #8
    // 0x63db28: r0 = inline_Allocate_Double()
    //     0x63db28: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63db2c: add             x0, x0, #0x10
    //     0x63db30: cmp             x1, x0
    //     0x63db34: b.ls            #0x63db7c
    //     0x63db38: str             x0, [THR, #0x60]  ; THR::top
    //     0x63db3c: sub             x0, x0, #0xf
    //     0x63db40: mov             x1, #0xd108
    //     0x63db44: movk            x1, #3, lsl #16
    //     0x63db48: stur            x1, [x0, #-1]
    // 0x63db4c: StoreField: r0->field_7 = d0
    //     0x63db4c: stur            d0, [x0, #7]
    // 0x63db50: LeaveFrame
    //     0x63db50: mov             SP, fp
    //     0x63db54: ldp             fp, lr, [SP], #0x10
    // 0x63db58: ret
    //     0x63db58: ret             
    // 0x63db5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63db5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63db60: b               #0x63daa4
    // 0x63db64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63db64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63db68: SaveReg d0
    //     0x63db68: str             q0, [SP, #-0x10]!
    // 0x63db6c: r0 = AllocateDouble()
    //     0x63db6c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63db70: RestoreReg d0
    //     0x63db70: ldr             q0, [SP], #0x10
    // 0x63db74: b               #0x63daf8
    // 0x63db78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63db78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63db7c: SaveReg d0
    //     0x63db7c: str             q0, [SP, #-0x10]!
    // 0x63db80: r0 = AllocateDouble()
    //     0x63db80: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63db84: RestoreReg d0
    //     0x63db84: ldr             q0, [SP], #0x10
    // 0x63db88: b               #0x63db4c
  }
  _ getOffsetAfter(/* No info */) {
    // ** addr: 0x64ccd0, size: 0xb8
    // 0x64ccd0: EnterFrame
    //     0x64ccd0: stp             fp, lr, [SP, #-0x10]!
    //     0x64ccd4: mov             fp, SP
    // 0x64ccd8: CheckStackOverflow
    //     0x64ccd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64ccdc: cmp             SP, x16
    //     0x64cce0: b.ls            #0x64cd7c
    // 0x64cce4: ldr             x0, [fp, #0x18]
    // 0x64cce8: LoadField: r1 = r0->field_f
    //     0x64cce8: ldur            w1, [x0, #0xf]
    // 0x64ccec: DecompressPointer r1
    //     0x64ccec: add             x1, x1, HEAP, lsl #32
    // 0x64ccf0: cmp             w1, NULL
    // 0x64ccf4: b.eq            #0x64cd84
    // 0x64ccf8: SaveReg r1
    //     0x64ccf8: str             x1, [SP, #-8]!
    // 0x64ccfc: ldr             x0, [fp, #0x10]
    // 0x64cd00: SaveReg r0
    //     0x64cd00: str             x0, [SP, #-8]!
    // 0x64cd04: r0 = codeUnitAt()
    //     0x64cd04: bl              #0x522038  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0x64cd08: add             SP, SP, #0x10
    // 0x64cd0c: cmp             w0, NULL
    // 0x64cd10: b.ne            #0x64cd24
    // 0x64cd14: r0 = Null
    //     0x64cd14: mov             x0, NULL
    // 0x64cd18: LeaveFrame
    //     0x64cd18: mov             SP, fp
    //     0x64cd1c: ldp             fp, lr, [SP], #0x10
    // 0x64cd20: ret
    //     0x64cd20: ret             
    // 0x64cd24: r2 = 63488
    //     0x64cd24: mov             x2, #0xf800
    // 0x64cd28: r3 = LoadInt32Instr(r0)
    //     0x64cd28: sbfx            x3, x0, #1, #0x1f
    // 0x64cd2c: and             x4, x3, x2
    // 0x64cd30: ubfx            x4, x4, #0, #0x20
    // 0x64cd34: r17 = 55296
    //     0x64cd34: mov             x17, #0xd800
    // 0x64cd38: cmp             x4, x17
    // 0x64cd3c: b.ne            #0x64cd50
    // 0x64cd40: ldr             x2, [fp, #0x10]
    // 0x64cd44: add             x3, x2, #2
    // 0x64cd48: mov             x2, x3
    // 0x64cd4c: b               #0x64cd5c
    // 0x64cd50: ldr             x2, [fp, #0x10]
    // 0x64cd54: add             x3, x2, #1
    // 0x64cd58: mov             x2, x3
    // 0x64cd5c: r0 = BoxInt64Instr(r2)
    //     0x64cd5c: sbfiz           x0, x2, #1, #0x1f
    //     0x64cd60: cmp             x2, x0, asr #1
    //     0x64cd64: b.eq            #0x64cd70
    //     0x64cd68: bl              #0xd69bb8
    //     0x64cd6c: stur            x2, [x0, #7]
    // 0x64cd70: LeaveFrame
    //     0x64cd70: mov             SP, fp
    //     0x64cd74: ldp             fp, lr, [SP], #0x10
    // 0x64cd78: ret
    //     0x64cd78: ret             
    // 0x64cd7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64cd7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64cd80: b               #0x64cce4
    // 0x64cd84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64cd84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getOffsetBefore(/* No info */) {
    // ** addr: 0x64cd88, size: 0xb8
    // 0x64cd88: EnterFrame
    //     0x64cd88: stp             fp, lr, [SP, #-0x10]!
    //     0x64cd8c: mov             fp, SP
    // 0x64cd90: AllocStack(0x8)
    //     0x64cd90: sub             SP, SP, #8
    // 0x64cd94: CheckStackOverflow
    //     0x64cd94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64cd98: cmp             SP, x16
    //     0x64cd9c: b.ls            #0x64ce34
    // 0x64cda0: ldr             x0, [fp, #0x18]
    // 0x64cda4: LoadField: r1 = r0->field_f
    //     0x64cda4: ldur            w1, [x0, #0xf]
    // 0x64cda8: DecompressPointer r1
    //     0x64cda8: add             x1, x1, HEAP, lsl #32
    // 0x64cdac: cmp             w1, NULL
    // 0x64cdb0: b.eq            #0x64ce3c
    // 0x64cdb4: ldr             x0, [fp, #0x10]
    // 0x64cdb8: sub             x2, x0, #1
    // 0x64cdbc: stur            x2, [fp, #-8]
    // 0x64cdc0: stp             x2, x1, [SP, #-0x10]!
    // 0x64cdc4: r0 = codeUnitAt()
    //     0x64cdc4: bl              #0x522038  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt
    // 0x64cdc8: add             SP, SP, #0x10
    // 0x64cdcc: cmp             w0, NULL
    // 0x64cdd0: b.ne            #0x64cde4
    // 0x64cdd4: r0 = Null
    //     0x64cdd4: mov             x0, NULL
    // 0x64cdd8: LeaveFrame
    //     0x64cdd8: mov             SP, fp
    //     0x64cddc: ldp             fp, lr, [SP], #0x10
    // 0x64cde0: ret
    //     0x64cde0: ret             
    // 0x64cde4: r2 = 63488
    //     0x64cde4: mov             x2, #0xf800
    // 0x64cde8: r3 = LoadInt32Instr(r0)
    //     0x64cde8: sbfx            x3, x0, #1, #0x1f
    // 0x64cdec: and             x4, x3, x2
    // 0x64cdf0: ubfx            x4, x4, #0, #0x20
    // 0x64cdf4: r17 = 55296
    //     0x64cdf4: mov             x17, #0xd800
    // 0x64cdf8: cmp             x4, x17
    // 0x64cdfc: b.ne            #0x64ce10
    // 0x64ce00: ldr             x2, [fp, #0x10]
    // 0x64ce04: sub             x3, x2, #2
    // 0x64ce08: mov             x2, x3
    // 0x64ce0c: b               #0x64ce14
    // 0x64ce10: ldur            x2, [fp, #-8]
    // 0x64ce14: r0 = BoxInt64Instr(r2)
    //     0x64ce14: sbfiz           x0, x2, #1, #0x1f
    //     0x64ce18: cmp             x2, x0, asr #1
    //     0x64ce1c: b.eq            #0x64ce28
    //     0x64ce20: bl              #0xd69bb8
    //     0x64ce24: stur            x2, [x0, #7]
    // 0x64ce28: LeaveFrame
    //     0x64ce28: mov             SP, fp
    //     0x64ce2c: ldp             fp, lr, [SP], #0x10
    // 0x64ce30: ret
    //     0x64ce30: ret             
    // 0x64ce34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64ce34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64ce38: b               #0x64cda0
    // 0x64ce3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64ce3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x652680, size: 0x84
    // 0x652680: EnterFrame
    //     0x652680: stp             fp, lr, [SP, #-0x10]!
    //     0x652684: mov             fp, SP
    // 0x652688: CheckStackOverflow
    //     0x652688: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65268c: cmp             SP, x16
    //     0x652690: b.ls            #0x6526fc
    // 0x652694: ldr             x0, [fp, #0x10]
    // 0x652698: LoadField: r1 = r0->field_4b
    //     0x652698: ldur            w1, [x0, #0x4b]
    // 0x65269c: DecompressPointer r1
    //     0x65269c: add             x1, x1, HEAP, lsl #32
    // 0x6526a0: cmp             w1, NULL
    // 0x6526a4: b.eq            #0x6526b8
    // 0x6526a8: SaveReg r1
    //     0x6526a8: str             x1, [SP, #-8]!
    // 0x6526ac: r0 = _dispose()
    //     0x6526ac: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x6526b0: add             SP, SP, #8
    // 0x6526b4: ldr             x0, [fp, #0x10]
    // 0x6526b8: StoreField: r0->field_4b = rNULL
    //     0x6526b8: stur            NULL, [x0, #0x4b]
    // 0x6526bc: LoadField: r1 = r0->field_7
    //     0x6526bc: ldur            w1, [x0, #7]
    // 0x6526c0: DecompressPointer r1
    //     0x6526c0: add             x1, x1, HEAP, lsl #32
    // 0x6526c4: cmp             w1, NULL
    // 0x6526c8: b.ne            #0x6526d4
    // 0x6526cc: mov             x1, x0
    // 0x6526d0: b               #0x6526e4
    // 0x6526d4: SaveReg r1
    //     0x6526d4: str             x1, [SP, #-8]!
    // 0x6526d8: r0 = _dispose()
    //     0x6526d8: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x6526dc: add             SP, SP, #8
    // 0x6526e0: ldr             x1, [fp, #0x10]
    // 0x6526e4: StoreField: r1->field_7 = rNULL
    //     0x6526e4: stur            NULL, [x1, #7]
    // 0x6526e8: StoreField: r1->field_f = rNULL
    //     0x6526e8: stur            NULL, [x1, #0xf]
    // 0x6526ec: r0 = Null
    //     0x6526ec: mov             x0, NULL
    // 0x6526f0: LeaveFrame
    //     0x6526f0: mov             SP, fp
    //     0x6526f4: ldp             fp, lr, [SP], #0x10
    // 0x6526f8: ret
    //     0x6526f8: ret             
    // 0x6526fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6526fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x652700: b               #0x652694
  }
  _ paint(/* No info */) {
    // ** addr: 0x65d820, size: 0xf4
    // 0x65d820: EnterFrame
    //     0x65d820: stp             fp, lr, [SP, #-0x10]!
    //     0x65d824: mov             fp, SP
    // 0x65d828: AllocStack(0x10)
    //     0x65d828: sub             SP, SP, #0x10
    // 0x65d82c: CheckStackOverflow
    //     0x65d82c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65d830: cmp             SP, x16
    //     0x65d834: b.ls            #0x65d908
    // 0x65d838: ldr             x0, [fp, #0x20]
    // 0x65d83c: LoadField: r1 = r0->field_4f
    //     0x65d83c: ldur            w1, [x0, #0x4f]
    // 0x65d840: DecompressPointer r1
    //     0x65d840: add             x1, x1, HEAP, lsl #32
    // 0x65d844: stur            x1, [fp, #-0x10]
    // 0x65d848: LoadField: r2 = r0->field_53
    //     0x65d848: ldur            w2, [x0, #0x53]
    // 0x65d84c: DecompressPointer r2
    //     0x65d84c: add             x2, x2, HEAP, lsl #32
    // 0x65d850: stur            x2, [fp, #-8]
    // 0x65d854: LoadField: r3 = r0->field_7
    //     0x65d854: ldur            w3, [x0, #7]
    // 0x65d858: DecompressPointer r3
    //     0x65d858: add             x3, x3, HEAP, lsl #32
    // 0x65d85c: cmp             w3, NULL
    // 0x65d860: b.eq            #0x65d8e8
    // 0x65d864: cmp             w1, NULL
    // 0x65d868: b.eq            #0x65d8e8
    // 0x65d86c: cmp             w2, NULL
    // 0x65d870: b.eq            #0x65d8e8
    // 0x65d874: LoadField: r3 = r0->field_b
    //     0x65d874: ldur            w3, [x0, #0xb]
    // 0x65d878: DecompressPointer r3
    //     0x65d878: add             x3, x3, HEAP, lsl #32
    // 0x65d87c: tbnz            w3, #4, #0x65d8ac
    // 0x65d880: SaveReg r0
    //     0x65d880: str             x0, [SP, #-8]!
    // 0x65d884: r0 = _createParagraph()
    //     0x65d884: bl              #0x524058  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_createParagraph
    // 0x65d888: add             SP, SP, #8
    // 0x65d88c: ldur            x0, [fp, #-8]
    // 0x65d890: LoadField: d0 = r0->field_7
    //     0x65d890: ldur            d0, [x0, #7]
    // 0x65d894: ldr             x16, [fp, #0x20]
    // 0x65d898: ldur            lr, [fp, #-0x10]
    // 0x65d89c: stp             lr, x16, [SP, #-0x10]!
    // 0x65d8a0: SaveReg d0
    //     0x65d8a0: str             d0, [SP, #-8]!
    // 0x65d8a4: r0 = _layoutParagraph()
    //     0x65d8a4: bl              #0x523ce0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_layoutParagraph
    // 0x65d8a8: add             SP, SP, #0x18
    // 0x65d8ac: ldr             x0, [fp, #0x20]
    // 0x65d8b0: LoadField: r1 = r0->field_7
    //     0x65d8b0: ldur            w1, [x0, #7]
    // 0x65d8b4: DecompressPointer r1
    //     0x65d8b4: add             x1, x1, HEAP, lsl #32
    // 0x65d8b8: cmp             w1, NULL
    // 0x65d8bc: b.eq            #0x65d910
    // 0x65d8c0: ldr             x16, [fp, #0x18]
    // 0x65d8c4: stp             x1, x16, [SP, #-0x10]!
    // 0x65d8c8: ldr             x16, [fp, #0x10]
    // 0x65d8cc: SaveReg r16
    //     0x65d8cc: str             x16, [SP, #-8]!
    // 0x65d8d0: r0 = drawParagraph()
    //     0x65d8d0: bl              #0x65d914  ; [dart:ui] Canvas::drawParagraph
    // 0x65d8d4: add             SP, SP, #0x18
    // 0x65d8d8: r0 = Null
    //     0x65d8d8: mov             x0, NULL
    // 0x65d8dc: LeaveFrame
    //     0x65d8dc: mov             SP, fp
    //     0x65d8e0: ldp             fp, lr, [SP], #0x10
    // 0x65d8e4: ret
    //     0x65d8e4: ret             
    // 0x65d8e8: r0 = StateError()
    //     0x65d8e8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x65d8ec: mov             x1, x0
    // 0x65d8f0: r0 = "TextPainter.paint called when text geometry was not yet calculated.\nPlease call layout() before paint() to position the text before painting it."
    //     0x65d8f0: add             x0, PP, #0x22, lsl #12  ; [pp+0x223c8] "TextPainter.paint called when text geometry was not yet calculated.\nPlease call layout() before paint() to position the text before painting it."
    //     0x65d8f4: ldr             x0, [x0, #0x3c8]
    // 0x65d8f8: StoreField: r1->field_b = r0
    //     0x65d8f8: stur            w0, [x1, #0xb]
    // 0x65d8fc: mov             x0, x1
    // 0x65d900: r0 = Throw()
    //     0x65d900: bl              #0xd67e38  ; ThrowStub
    // 0x65d904: brk             #0
    // 0x65d908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65d908: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65d90c: b               #0x65d838
    // 0x65d910: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65d910: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x673280, size: 0xb0
    // 0x673280: EnterFrame
    //     0x673280: stp             fp, lr, [SP, #-0x10]!
    //     0x673284: mov             fp, SP
    // 0x673288: CheckStackOverflow
    //     0x673288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x67328c: cmp             SP, x16
    //     0x673290: b.ls            #0x673328
    // 0x673294: ldr             x1, [fp, #0x18]
    // 0x673298: LoadField: r0 = r1->field_1b
    //     0x673298: ldur            w0, [x1, #0x1b]
    // 0x67329c: DecompressPointer r0
    //     0x67329c: add             x0, x0, HEAP, lsl #32
    // 0x6732a0: ldr             x2, [fp, #0x10]
    // 0x6732a4: cmp             w0, w2
    // 0x6732a8: b.ne            #0x6732bc
    // 0x6732ac: r0 = Null
    //     0x6732ac: mov             x0, NULL
    // 0x6732b0: LeaveFrame
    //     0x6732b0: mov             SP, fp
    //     0x6732b4: ldp             fp, lr, [SP], #0x10
    // 0x6732b8: ret
    //     0x6732b8: ret             
    // 0x6732bc: mov             x0, x2
    // 0x6732c0: StoreField: r1->field_1b = r0
    //     0x6732c0: stur            w0, [x1, #0x1b]
    //     0x6732c4: ldurb           w16, [x1, #-1]
    //     0x6732c8: ldurb           w17, [x0, #-1]
    //     0x6732cc: and             x16, x17, x16, lsr #2
    //     0x6732d0: tst             x16, HEAP, lsr #32
    //     0x6732d4: b.eq            #0x6732dc
    //     0x6732d8: bl              #0xd6826c
    // 0x6732dc: SaveReg r1
    //     0x6732dc: str             x1, [SP, #-8]!
    // 0x6732e0: r0 = markNeedsLayout()
    //     0x6732e0: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x6732e4: add             SP, SP, #8
    // 0x6732e8: ldr             x0, [fp, #0x18]
    // 0x6732ec: LoadField: r1 = r0->field_4b
    //     0x6732ec: ldur            w1, [x0, #0x4b]
    // 0x6732f0: DecompressPointer r1
    //     0x6732f0: add             x1, x1, HEAP, lsl #32
    // 0x6732f4: cmp             w1, NULL
    // 0x6732f8: b.ne            #0x673304
    // 0x6732fc: mov             x1, x0
    // 0x673300: b               #0x673314
    // 0x673304: SaveReg r1
    //     0x673304: str             x1, [SP, #-8]!
    // 0x673308: r0 = _dispose()
    //     0x673308: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x67330c: add             SP, SP, #8
    // 0x673310: ldr             x1, [fp, #0x18]
    // 0x673314: StoreField: r1->field_4b = rNULL
    //     0x673314: stur            NULL, [x1, #0x4b]
    // 0x673318: r0 = Null
    //     0x673318: mov             x0, NULL
    // 0x67331c: LeaveFrame
    //     0x67331c: mov             SP, fp
    //     0x673320: ldp             fp, lr, [SP], #0x10
    // 0x673324: ret
    //     0x673324: ret             
    // 0x673328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x673328: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67332c: b               #0x673294
  }
  set _ text=(/* No info */) {
    // ** addr: 0x673330, size: 0x250
    // 0x673330: EnterFrame
    //     0x673330: stp             fp, lr, [SP, #-0x10]!
    //     0x673334: mov             fp, SP
    // 0x673338: AllocStack(0x8)
    //     0x673338: sub             SP, SP, #8
    // 0x67333c: CheckStackOverflow
    //     0x67333c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x673340: cmp             SP, x16
    //     0x673344: b.ls            #0x673578
    // 0x673348: ldr             x1, [fp, #0x18]
    // 0x67334c: LoadField: r0 = r1->field_f
    //     0x67334c: ldur            w0, [x1, #0xf]
    // 0x673350: DecompressPointer r0
    //     0x673350: add             x0, x0, HEAP, lsl #32
    // 0x673354: r2 = LoadClassIdInstr(r0)
    //     0x673354: ldur            x2, [x0, #-1]
    //     0x673358: ubfx            x2, x2, #0xc, #0x14
    // 0x67335c: ldr             x16, [fp, #0x10]
    // 0x673360: stp             x16, x0, [SP, #-0x10]!
    // 0x673364: mov             x0, x2
    // 0x673368: mov             lr, x0
    // 0x67336c: ldr             lr, [x21, lr, lsl #3]
    // 0x673370: blr             lr
    // 0x673374: add             SP, SP, #0x10
    // 0x673378: tbnz            w0, #4, #0x67338c
    // 0x67337c: r0 = Null
    //     0x67337c: mov             x0, NULL
    // 0x673380: LeaveFrame
    //     0x673380: mov             SP, fp
    //     0x673384: ldp             fp, lr, [SP], #0x10
    // 0x673388: ret
    //     0x673388: ret             
    // 0x67338c: ldr             x1, [fp, #0x18]
    // 0x673390: LoadField: r0 = r1->field_f
    //     0x673390: ldur            w0, [x1, #0xf]
    // 0x673394: DecompressPointer r0
    //     0x673394: add             x0, x0, HEAP, lsl #32
    // 0x673398: cmp             w0, NULL
    // 0x67339c: b.ne            #0x6733a8
    // 0x6733a0: r0 = Null
    //     0x6733a0: mov             x0, NULL
    // 0x6733a4: b               #0x6733b4
    // 0x6733a8: LoadField: r2 = r0->field_7
    //     0x6733a8: ldur            w2, [x0, #7]
    // 0x6733ac: DecompressPointer r2
    //     0x6733ac: add             x2, x2, HEAP, lsl #32
    // 0x6733b0: mov             x0, x2
    // 0x6733b4: ldr             x2, [fp, #0x10]
    // 0x6733b8: cmp             w2, NULL
    // 0x6733bc: b.ne            #0x6733c8
    // 0x6733c0: r3 = Null
    //     0x6733c0: mov             x3, NULL
    // 0x6733c4: b               #0x6733d0
    // 0x6733c8: LoadField: r3 = r2->field_7
    //     0x6733c8: ldur            w3, [x2, #7]
    // 0x6733cc: DecompressPointer r3
    //     0x6733cc: add             x3, x3, HEAP, lsl #32
    // 0x6733d0: r4 = LoadClassIdInstr(r0)
    //     0x6733d0: ldur            x4, [x0, #-1]
    //     0x6733d4: ubfx            x4, x4, #0xc, #0x14
    // 0x6733d8: stp             x3, x0, [SP, #-0x10]!
    // 0x6733dc: mov             x0, x4
    // 0x6733e0: mov             lr, x0
    // 0x6733e4: ldr             lr, [x21, lr, lsl #3]
    // 0x6733e8: blr             lr
    // 0x6733ec: add             SP, SP, #0x10
    // 0x6733f0: tbz             w0, #4, #0x673420
    // 0x6733f4: ldr             x0, [fp, #0x18]
    // 0x6733f8: LoadField: r1 = r0->field_4b
    //     0x6733f8: ldur            w1, [x0, #0x4b]
    // 0x6733fc: DecompressPointer r1
    //     0x6733fc: add             x1, x1, HEAP, lsl #32
    // 0x673400: cmp             w1, NULL
    // 0x673404: b.eq            #0x673418
    // 0x673408: SaveReg r1
    //     0x673408: str             x1, [SP, #-8]!
    // 0x67340c: r0 = _dispose()
    //     0x67340c: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x673410: add             SP, SP, #8
    // 0x673414: ldr             x0, [fp, #0x18]
    // 0x673418: StoreField: r0->field_4b = rNULL
    //     0x673418: stur            NULL, [x0, #0x4b]
    // 0x67341c: b               #0x673424
    // 0x673420: ldr             x0, [fp, #0x18]
    // 0x673424: ldr             x1, [fp, #0x10]
    // 0x673428: cmp             w1, NULL
    // 0x67342c: b.ne            #0x673440
    // 0x673430: mov             x1, x0
    // 0x673434: r2 = Instance_RenderComparison
    //     0x673434: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0x673438: ldr             x2, [x2, #0x470]
    // 0x67343c: b               #0x673518
    // 0x673440: LoadField: r2 = r0->field_f
    //     0x673440: ldur            w2, [x0, #0xf]
    // 0x673444: DecompressPointer r2
    //     0x673444: add             x2, x2, HEAP, lsl #32
    // 0x673448: stur            x2, [fp, #-8]
    // 0x67344c: cmp             w2, NULL
    // 0x673450: b.ne            #0x67345c
    // 0x673454: r0 = Null
    //     0x673454: mov             x0, NULL
    // 0x673458: b               #0x673500
    // 0x67345c: r3 = LoadClassIdInstr(r2)
    //     0x67345c: ldur            x3, [x2, #-1]
    //     0x673460: ubfx            x3, x3, #0xc, #0x14
    // 0x673464: lsl             x3, x3, #1
    // 0x673468: r17 = 6950
    //     0x673468: mov             x17, #0x1b26
    // 0x67346c: cmp             w3, w17
    // 0x673470: b.ne            #0x6734d8
    // 0x673474: stp             x1, x2, [SP, #-0x10]!
    // 0x673478: r0 = compareTo()
    //     0x673478: bl              #0xcdc8cc  ; [package:flutter/src/painting/text_span.dart] TextSpan::compareTo
    // 0x67347c: add             SP, SP, #0x10
    // 0x673480: r16 = Instance_RenderComparison
    //     0x673480: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0x673484: ldr             x16, [x16, #0x438]
    // 0x673488: cmp             w0, w16
    // 0x67348c: b.ne            #0x673500
    // 0x673490: ldr             x0, [fp, #0x10]
    // 0x673494: r2 = Null
    //     0x673494: mov             x2, NULL
    // 0x673498: r1 = Null
    //     0x673498: mov             x1, NULL
    // 0x67349c: r4 = LoadClassIdInstr(r0)
    //     0x67349c: ldur            x4, [x0, #-1]
    //     0x6734a0: ubfx            x4, x4, #0xc, #0x14
    // 0x6734a4: cmp             x4, #0xd93
    // 0x6734a8: b.eq            #0x6734c0
    // 0x6734ac: r8 = SpecialInlineSpanBase
    //     0x6734ac: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d440] Type: SpecialInlineSpanBase
    //     0x6734b0: ldr             x8, [x8, #0x440]
    // 0x6734b4: r3 = Null
    //     0x6734b4: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d478] Null
    //     0x6734b8: ldr             x3, [x3, #0x478]
    // 0x6734bc: r0 = DefaultTypeTest()
    //     0x6734bc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6734c0: ldur            x16, [fp, #-8]
    // 0x6734c4: ldr             lr, [fp, #0x10]
    // 0x6734c8: stp             lr, x16, [SP, #-0x10]!
    // 0x6734cc: r0 = baseCompareTo()
    //     0x6734cc: bl              #0x6736c4  ; [package:extended_text_library/src/special_text_span.dart] _SpecialTextSpan&TextSpan&SpecialInlineSpanBase::baseCompareTo
    // 0x6734d0: add             SP, SP, #0x10
    // 0x6734d4: b               #0x673500
    // 0x6734d8: mov             x0, x2
    // 0x6734dc: r1 = LoadClassIdInstr(r0)
    //     0x6734dc: ldur            x1, [x0, #-1]
    //     0x6734e0: ubfx            x1, x1, #0xc, #0x14
    // 0x6734e4: ldr             x16, [fp, #0x10]
    // 0x6734e8: stp             x16, x0, [SP, #-0x10]!
    // 0x6734ec: mov             x0, x1
    // 0x6734f0: r0 = GDT[cid_x0 + -0xf24]()
    //     0x6734f0: sub             lr, x0, #0xf24
    //     0x6734f4: ldr             lr, [x21, lr, lsl #3]
    //     0x6734f8: blr             lr
    // 0x6734fc: add             SP, SP, #0x10
    // 0x673500: cmp             w0, NULL
    // 0x673504: b.ne            #0x673510
    // 0x673508: r0 = Instance_RenderComparison
    //     0x673508: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0x67350c: ldr             x0, [x0, #0x470]
    // 0x673510: mov             x2, x0
    // 0x673514: ldr             x1, [fp, #0x18]
    // 0x673518: ldr             x0, [fp, #0x10]
    // 0x67351c: StoreField: r1->field_f = r0
    //     0x67351c: stur            w0, [x1, #0xf]
    //     0x673520: ldurb           w16, [x1, #-1]
    //     0x673524: ldurb           w17, [x0, #-1]
    //     0x673528: and             x16, x17, x16, lsr #2
    //     0x67352c: tst             x16, HEAP, lsr #32
    //     0x673530: b.eq            #0x673538
    //     0x673534: bl              #0xd6826c
    // 0x673538: StoreField: r1->field_13 = rNULL
    //     0x673538: stur            NULL, [x1, #0x13]
    // 0x67353c: LoadField: r0 = r2->field_7
    //     0x67353c: ldur            x0, [x2, #7]
    // 0x673540: cmp             x0, #3
    // 0x673544: b.lt            #0x673558
    // 0x673548: SaveReg r1
    //     0x673548: str             x1, [SP, #-8]!
    // 0x67354c: r0 = markNeedsLayout()
    //     0x67354c: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x673550: add             SP, SP, #8
    // 0x673554: b               #0x673568
    // 0x673558: cmp             x0, #2
    // 0x67355c: b.lt            #0x673568
    // 0x673560: r2 = true
    //     0x673560: add             x2, NULL, #0x20  ; true
    // 0x673564: StoreField: r1->field_b = r2
    //     0x673564: stur            w2, [x1, #0xb]
    // 0x673568: r0 = Null
    //     0x673568: mov             x0, NULL
    // 0x67356c: LeaveFrame
    //     0x67356c: mov             SP, fp
    //     0x673570: ldp             fp, lr, [SP], #0x10
    // 0x673574: ret
    //     0x673574: ret             
    // 0x673578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x673578: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67357c: b               #0x673348
  }
  get _ didExceedMaxLines(/* No info */) {
    // ** addr: 0x68dbfc, size: 0x4c
    // 0x68dbfc: EnterFrame
    //     0x68dbfc: stp             fp, lr, [SP, #-0x10]!
    //     0x68dc00: mov             fp, SP
    // 0x68dc04: CheckStackOverflow
    //     0x68dc04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68dc08: cmp             SP, x16
    //     0x68dc0c: b.ls            #0x68dc3c
    // 0x68dc10: ldr             x0, [fp, #0x10]
    // 0x68dc14: LoadField: r1 = r0->field_7
    //     0x68dc14: ldur            w1, [x0, #7]
    // 0x68dc18: DecompressPointer r1
    //     0x68dc18: add             x1, x1, HEAP, lsl #32
    // 0x68dc1c: cmp             w1, NULL
    // 0x68dc20: b.eq            #0x68dc44
    // 0x68dc24: SaveReg r1
    //     0x68dc24: str             x1, [SP, #-8]!
    // 0x68dc28: r0 = didExceedMaxLines()
    //     0x68dc28: bl              #0x68dc48  ; [dart:ui] Paragraph::didExceedMaxLines
    // 0x68dc2c: add             SP, SP, #8
    // 0x68dc30: LeaveFrame
    //     0x68dc30: mov             SP, fp
    //     0x68dc34: ldp             fp, lr, [SP], #0x10
    // 0x68dc38: ret
    //     0x68dc38: ret             
    // 0x68dc3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68dc3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68dc40: b               #0x68dc10
    // 0x68dc44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68dc44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ locale=(/* No info */) {
    // ** addr: 0x6df43c, size: 0xa0
    // 0x6df43c: EnterFrame
    //     0x6df43c: stp             fp, lr, [SP, #-0x10]!
    //     0x6df440: mov             fp, SP
    // 0x6df444: CheckStackOverflow
    //     0x6df444: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df448: cmp             SP, x16
    //     0x6df44c: b.ls            #0x6df4d4
    // 0x6df450: ldr             x1, [fp, #0x18]
    // 0x6df454: LoadField: r0 = r1->field_2b
    //     0x6df454: ldur            w0, [x1, #0x2b]
    // 0x6df458: DecompressPointer r0
    //     0x6df458: add             x0, x0, HEAP, lsl #32
    // 0x6df45c: r2 = LoadClassIdInstr(r0)
    //     0x6df45c: ldur            x2, [x0, #-1]
    //     0x6df460: ubfx            x2, x2, #0xc, #0x14
    // 0x6df464: ldr             x16, [fp, #0x10]
    // 0x6df468: stp             x16, x0, [SP, #-0x10]!
    // 0x6df46c: mov             x0, x2
    // 0x6df470: mov             lr, x0
    // 0x6df474: ldr             lr, [x21, lr, lsl #3]
    // 0x6df478: blr             lr
    // 0x6df47c: add             SP, SP, #0x10
    // 0x6df480: tbnz            w0, #4, #0x6df494
    // 0x6df484: r0 = Null
    //     0x6df484: mov             x0, NULL
    // 0x6df488: LeaveFrame
    //     0x6df488: mov             SP, fp
    //     0x6df48c: ldp             fp, lr, [SP], #0x10
    // 0x6df490: ret
    //     0x6df490: ret             
    // 0x6df494: ldr             x1, [fp, #0x18]
    // 0x6df498: ldr             x0, [fp, #0x10]
    // 0x6df49c: StoreField: r1->field_2b = r0
    //     0x6df49c: stur            w0, [x1, #0x2b]
    //     0x6df4a0: ldurb           w16, [x1, #-1]
    //     0x6df4a4: ldurb           w17, [x0, #-1]
    //     0x6df4a8: and             x16, x17, x16, lsr #2
    //     0x6df4ac: tst             x16, HEAP, lsr #32
    //     0x6df4b0: b.eq            #0x6df4b8
    //     0x6df4b4: bl              #0xd6826c
    // 0x6df4b8: SaveReg r1
    //     0x6df4b8: str             x1, [SP, #-8]!
    // 0x6df4bc: r0 = markNeedsLayout()
    //     0x6df4bc: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x6df4c0: add             SP, SP, #8
    // 0x6df4c4: r0 = Null
    //     0x6df4c4: mov             x0, NULL
    // 0x6df4c8: LeaveFrame
    //     0x6df4c8: mov             SP, fp
    //     0x6df4cc: ldp             fp, lr, [SP], #0x10
    // 0x6df4d0: ret
    //     0x6df4d0: ret             
    // 0x6df4d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df4d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df4d8: b               #0x6df450
  }
  set _ textAlign=(/* No info */) {
    // ** addr: 0x6df5fc, size: 0x80
    // 0x6df5fc: EnterFrame
    //     0x6df5fc: stp             fp, lr, [SP, #-0x10]!
    //     0x6df600: mov             fp, SP
    // 0x6df604: CheckStackOverflow
    //     0x6df604: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df608: cmp             SP, x16
    //     0x6df60c: b.ls            #0x6df674
    // 0x6df610: ldr             x1, [fp, #0x18]
    // 0x6df614: LoadField: r0 = r1->field_17
    //     0x6df614: ldur            w0, [x1, #0x17]
    // 0x6df618: DecompressPointer r0
    //     0x6df618: add             x0, x0, HEAP, lsl #32
    // 0x6df61c: ldr             x2, [fp, #0x10]
    // 0x6df620: cmp             w0, w2
    // 0x6df624: b.ne            #0x6df638
    // 0x6df628: r0 = Null
    //     0x6df628: mov             x0, NULL
    // 0x6df62c: LeaveFrame
    //     0x6df62c: mov             SP, fp
    //     0x6df630: ldp             fp, lr, [SP], #0x10
    // 0x6df634: ret
    //     0x6df634: ret             
    // 0x6df638: mov             x0, x2
    // 0x6df63c: StoreField: r1->field_17 = r0
    //     0x6df63c: stur            w0, [x1, #0x17]
    //     0x6df640: ldurb           w16, [x1, #-1]
    //     0x6df644: ldurb           w17, [x0, #-1]
    //     0x6df648: and             x16, x17, x16, lsr #2
    //     0x6df64c: tst             x16, HEAP, lsr #32
    //     0x6df650: b.eq            #0x6df658
    //     0x6df654: bl              #0xd6826c
    // 0x6df658: SaveReg r1
    //     0x6df658: str             x1, [SP, #-8]!
    // 0x6df65c: r0 = markNeedsLayout()
    //     0x6df65c: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x6df660: add             SP, SP, #8
    // 0x6df664: r0 = Null
    //     0x6df664: mov             x0, NULL
    // 0x6df668: LeaveFrame
    //     0x6df668: mov             SP, fp
    //     0x6df66c: ldp             fp, lr, [SP], #0x10
    // 0x6df670: ret
    //     0x6df670: ret             
    // 0x6df674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df678: b               #0x6df610
  }
  set _ textScaleFactor=(/* No info */) {
    // ** addr: 0x6df6f8, size: 0x94
    // 0x6df6f8: EnterFrame
    //     0x6df6f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6df6fc: mov             fp, SP
    // 0x6df700: CheckStackOverflow
    //     0x6df700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df704: cmp             SP, x16
    //     0x6df708: b.ls            #0x6df784
    // 0x6df70c: ldr             x0, [fp, #0x18]
    // 0x6df710: LoadField: d0 = r0->field_1f
    //     0x6df710: ldur            d0, [x0, #0x1f]
    // 0x6df714: ldr             d1, [fp, #0x10]
    // 0x6df718: fcmp            d0, d1
    // 0x6df71c: b.vs            #0x6df734
    // 0x6df720: b.ne            #0x6df734
    // 0x6df724: r0 = Null
    //     0x6df724: mov             x0, NULL
    // 0x6df728: LeaveFrame
    //     0x6df728: mov             SP, fp
    //     0x6df72c: ldp             fp, lr, [SP], #0x10
    // 0x6df730: ret
    //     0x6df730: ret             
    // 0x6df734: StoreField: r0->field_1f = d1
    //     0x6df734: stur            d1, [x0, #0x1f]
    // 0x6df738: SaveReg r0
    //     0x6df738: str             x0, [SP, #-8]!
    // 0x6df73c: r0 = markNeedsLayout()
    //     0x6df73c: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x6df740: add             SP, SP, #8
    // 0x6df744: ldr             x0, [fp, #0x18]
    // 0x6df748: LoadField: r1 = r0->field_4b
    //     0x6df748: ldur            w1, [x0, #0x4b]
    // 0x6df74c: DecompressPointer r1
    //     0x6df74c: add             x1, x1, HEAP, lsl #32
    // 0x6df750: cmp             w1, NULL
    // 0x6df754: b.ne            #0x6df760
    // 0x6df758: mov             x1, x0
    // 0x6df75c: b               #0x6df770
    // 0x6df760: SaveReg r1
    //     0x6df760: str             x1, [SP, #-8]!
    // 0x6df764: r0 = _dispose()
    //     0x6df764: bl              #0x62d5b4  ; [dart:ui] Paragraph::_dispose
    // 0x6df768: add             SP, SP, #8
    // 0x6df76c: ldr             x1, [fp, #0x18]
    // 0x6df770: StoreField: r1->field_4b = rNULL
    //     0x6df770: stur            NULL, [x1, #0x4b]
    // 0x6df774: r0 = Null
    //     0x6df774: mov             x0, NULL
    // 0x6df778: LeaveFrame
    //     0x6df778: mov             SP, fp
    //     0x6df77c: ldp             fp, lr, [SP], #0x10
    // 0x6df780: ret
    //     0x6df780: ret             
    // 0x6df784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df784: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df788: b               #0x6df70c
  }
  set _ strutStyle=(/* No info */) {
    // ** addr: 0x6df878, size: 0xa0
    // 0x6df878: EnterFrame
    //     0x6df878: stp             fp, lr, [SP, #-0x10]!
    //     0x6df87c: mov             fp, SP
    // 0x6df880: CheckStackOverflow
    //     0x6df880: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df884: cmp             SP, x16
    //     0x6df888: b.ls            #0x6df910
    // 0x6df88c: ldr             x1, [fp, #0x18]
    // 0x6df890: LoadField: r0 = r1->field_33
    //     0x6df890: ldur            w0, [x1, #0x33]
    // 0x6df894: DecompressPointer r0
    //     0x6df894: add             x0, x0, HEAP, lsl #32
    // 0x6df898: r2 = LoadClassIdInstr(r0)
    //     0x6df898: ldur            x2, [x0, #-1]
    //     0x6df89c: ubfx            x2, x2, #0xc, #0x14
    // 0x6df8a0: ldr             x16, [fp, #0x10]
    // 0x6df8a4: stp             x16, x0, [SP, #-0x10]!
    // 0x6df8a8: mov             x0, x2
    // 0x6df8ac: mov             lr, x0
    // 0x6df8b0: ldr             lr, [x21, lr, lsl #3]
    // 0x6df8b4: blr             lr
    // 0x6df8b8: add             SP, SP, #0x10
    // 0x6df8bc: tbnz            w0, #4, #0x6df8d0
    // 0x6df8c0: r0 = Null
    //     0x6df8c0: mov             x0, NULL
    // 0x6df8c4: LeaveFrame
    //     0x6df8c4: mov             SP, fp
    //     0x6df8c8: ldp             fp, lr, [SP], #0x10
    // 0x6df8cc: ret
    //     0x6df8cc: ret             
    // 0x6df8d0: ldr             x1, [fp, #0x18]
    // 0x6df8d4: ldr             x0, [fp, #0x10]
    // 0x6df8d8: StoreField: r1->field_33 = r0
    //     0x6df8d8: stur            w0, [x1, #0x33]
    //     0x6df8dc: ldurb           w16, [x1, #-1]
    //     0x6df8e0: ldurb           w17, [x0, #-1]
    //     0x6df8e4: and             x16, x17, x16, lsr #2
    //     0x6df8e8: tst             x16, HEAP, lsr #32
    //     0x6df8ec: b.eq            #0x6df8f4
    //     0x6df8f0: bl              #0xd6826c
    // 0x6df8f4: SaveReg r1
    //     0x6df8f4: str             x1, [SP, #-8]!
    // 0x6df8f8: r0 = markNeedsLayout()
    //     0x6df8f8: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x6df8fc: add             SP, SP, #8
    // 0x6df900: r0 = Null
    //     0x6df900: mov             x0, NULL
    // 0x6df904: LeaveFrame
    //     0x6df904: mov             SP, fp
    //     0x6df908: ldp             fp, lr, [SP], #0x10
    // 0x6df90c: ret
    //     0x6df90c: ret             
    // 0x6df910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df910: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df914: b               #0x6df88c
  }
  set _ maxLines=(/* No info */) {
    // ** addr: 0x6e1ad8, size: 0xbc
    // 0x6e1ad8: EnterFrame
    //     0x6e1ad8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1adc: mov             fp, SP
    // 0x6e1ae0: CheckStackOverflow
    //     0x6e1ae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1ae4: cmp             SP, x16
    //     0x6e1ae8: b.ls            #0x6e1b8c
    // 0x6e1aec: ldr             x1, [fp, #0x18]
    // 0x6e1af0: LoadField: r0 = r1->field_2f
    //     0x6e1af0: ldur            w0, [x1, #0x2f]
    // 0x6e1af4: DecompressPointer r0
    //     0x6e1af4: add             x0, x0, HEAP, lsl #32
    // 0x6e1af8: ldr             x2, [fp, #0x10]
    // 0x6e1afc: cmp             w0, w2
    // 0x6e1b00: b.eq            #0x6e1b3c
    // 0x6e1b04: and             w16, w0, w2
    // 0x6e1b08: branchIfSmi(r16, 0x6e1b4c)
    //     0x6e1b08: tbz             w16, #0, #0x6e1b4c
    // 0x6e1b0c: r16 = LoadClassIdInstr(r0)
    //     0x6e1b0c: ldur            x16, [x0, #-1]
    //     0x6e1b10: ubfx            x16, x16, #0xc, #0x14
    // 0x6e1b14: cmp             x16, #0x3c
    // 0x6e1b18: b.ne            #0x6e1b4c
    // 0x6e1b1c: r16 = LoadClassIdInstr(r2)
    //     0x6e1b1c: ldur            x16, [x2, #-1]
    //     0x6e1b20: ubfx            x16, x16, #0xc, #0x14
    // 0x6e1b24: cmp             x16, #0x3c
    // 0x6e1b28: b.ne            #0x6e1b4c
    // 0x6e1b2c: LoadField: r16 = r0->field_7
    //     0x6e1b2c: ldur            x16, [x0, #7]
    // 0x6e1b30: LoadField: r17 = r2->field_7
    //     0x6e1b30: ldur            x17, [x2, #7]
    // 0x6e1b34: cmp             x16, x17
    // 0x6e1b38: b.ne            #0x6e1b4c
    // 0x6e1b3c: r0 = Null
    //     0x6e1b3c: mov             x0, NULL
    // 0x6e1b40: LeaveFrame
    //     0x6e1b40: mov             SP, fp
    //     0x6e1b44: ldp             fp, lr, [SP], #0x10
    // 0x6e1b48: ret
    //     0x6e1b48: ret             
    // 0x6e1b4c: mov             x0, x2
    // 0x6e1b50: StoreField: r1->field_2f = r0
    //     0x6e1b50: stur            w0, [x1, #0x2f]
    //     0x6e1b54: tbz             w0, #0, #0x6e1b70
    //     0x6e1b58: ldurb           w16, [x1, #-1]
    //     0x6e1b5c: ldurb           w17, [x0, #-1]
    //     0x6e1b60: and             x16, x17, x16, lsr #2
    //     0x6e1b64: tst             x16, HEAP, lsr #32
    //     0x6e1b68: b.eq            #0x6e1b70
    //     0x6e1b6c: bl              #0xd6826c
    // 0x6e1b70: SaveReg r1
    //     0x6e1b70: str             x1, [SP, #-8]!
    // 0x6e1b74: r0 = markNeedsLayout()
    //     0x6e1b74: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x6e1b78: add             SP, SP, #8
    // 0x6e1b7c: r0 = Null
    //     0x6e1b7c: mov             x0, NULL
    // 0x6e1b80: LeaveFrame
    //     0x6e1b80: mov             SP, fp
    //     0x6e1b84: ldp             fp, lr, [SP], #0x10
    // 0x6e1b88: ret
    //     0x6e1b88: ret             
    // 0x6e1b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1b8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1b90: b               #0x6e1aec
  }
  set _ ellipsis=(/* No info */) {
    // ** addr: 0x6e1ccc, size: 0xa0
    // 0x6e1ccc: EnterFrame
    //     0x6e1ccc: stp             fp, lr, [SP, #-0x10]!
    //     0x6e1cd0: mov             fp, SP
    // 0x6e1cd4: CheckStackOverflow
    //     0x6e1cd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e1cd8: cmp             SP, x16
    //     0x6e1cdc: b.ls            #0x6e1d64
    // 0x6e1ce0: ldr             x1, [fp, #0x18]
    // 0x6e1ce4: LoadField: r0 = r1->field_27
    //     0x6e1ce4: ldur            w0, [x1, #0x27]
    // 0x6e1ce8: DecompressPointer r0
    //     0x6e1ce8: add             x0, x0, HEAP, lsl #32
    // 0x6e1cec: r2 = LoadClassIdInstr(r0)
    //     0x6e1cec: ldur            x2, [x0, #-1]
    //     0x6e1cf0: ubfx            x2, x2, #0xc, #0x14
    // 0x6e1cf4: ldr             x16, [fp, #0x10]
    // 0x6e1cf8: stp             x16, x0, [SP, #-0x10]!
    // 0x6e1cfc: mov             x0, x2
    // 0x6e1d00: mov             lr, x0
    // 0x6e1d04: ldr             lr, [x21, lr, lsl #3]
    // 0x6e1d08: blr             lr
    // 0x6e1d0c: add             SP, SP, #0x10
    // 0x6e1d10: tbnz            w0, #4, #0x6e1d24
    // 0x6e1d14: r0 = Null
    //     0x6e1d14: mov             x0, NULL
    // 0x6e1d18: LeaveFrame
    //     0x6e1d18: mov             SP, fp
    //     0x6e1d1c: ldp             fp, lr, [SP], #0x10
    // 0x6e1d20: ret
    //     0x6e1d20: ret             
    // 0x6e1d24: ldr             x1, [fp, #0x18]
    // 0x6e1d28: ldr             x0, [fp, #0x10]
    // 0x6e1d2c: StoreField: r1->field_27 = r0
    //     0x6e1d2c: stur            w0, [x1, #0x27]
    //     0x6e1d30: ldurb           w16, [x1, #-1]
    //     0x6e1d34: ldurb           w17, [x0, #-1]
    //     0x6e1d38: and             x16, x17, x16, lsr #2
    //     0x6e1d3c: tst             x16, HEAP, lsr #32
    //     0x6e1d40: b.eq            #0x6e1d48
    //     0x6e1d44: bl              #0xd6826c
    // 0x6e1d48: SaveReg r1
    //     0x6e1d48: str             x1, [SP, #-8]!
    // 0x6e1d4c: r0 = markNeedsLayout()
    //     0x6e1d4c: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x6e1d50: add             SP, SP, #8
    // 0x6e1d54: r0 = Null
    //     0x6e1d54: mov             x0, NULL
    // 0x6e1d58: LeaveFrame
    //     0x6e1d58: mov             SP, fp
    //     0x6e1d5c: ldp             fp, lr, [SP], #0x10
    // 0x6e1d60: ret
    //     0x6e1d60: ret             
    // 0x6e1d64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e1d64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e1d68: b               #0x6e1ce0
  }
  _ getLineBoundary(/* No info */) {
    // ** addr: 0x7cb748, size: 0x50
    // 0x7cb748: EnterFrame
    //     0x7cb748: stp             fp, lr, [SP, #-0x10]!
    //     0x7cb74c: mov             fp, SP
    // 0x7cb750: CheckStackOverflow
    //     0x7cb750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7cb754: cmp             SP, x16
    //     0x7cb758: b.ls            #0x7cb78c
    // 0x7cb75c: ldr             x0, [fp, #0x18]
    // 0x7cb760: LoadField: r1 = r0->field_7
    //     0x7cb760: ldur            w1, [x0, #7]
    // 0x7cb764: DecompressPointer r1
    //     0x7cb764: add             x1, x1, HEAP, lsl #32
    // 0x7cb768: cmp             w1, NULL
    // 0x7cb76c: b.eq            #0x7cb794
    // 0x7cb770: ldr             x16, [fp, #0x10]
    // 0x7cb774: stp             x16, x1, [SP, #-0x10]!
    // 0x7cb778: r0 = getLineBoundary()
    //     0x7cb778: bl              #0x7cb798  ; [dart:ui] Paragraph::getLineBoundary
    // 0x7cb77c: add             SP, SP, #0x10
    // 0x7cb780: LeaveFrame
    //     0x7cb780: mov             SP, fp
    //     0x7cb784: ldp             fp, lr, [SP], #0x10
    // 0x7cb788: ret
    //     0x7cb788: ret             
    // 0x7cb78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7cb78c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7cb790: b               #0x7cb75c
    // 0x7cb794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7cb794: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getWordBoundary(/* No info */) {
    // ** addr: 0x83bafc, size: 0x50
    // 0x83bafc: EnterFrame
    //     0x83bafc: stp             fp, lr, [SP, #-0x10]!
    //     0x83bb00: mov             fp, SP
    // 0x83bb04: CheckStackOverflow
    //     0x83bb04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83bb08: cmp             SP, x16
    //     0x83bb0c: b.ls            #0x83bb40
    // 0x83bb10: ldr             x0, [fp, #0x18]
    // 0x83bb14: LoadField: r1 = r0->field_7
    //     0x83bb14: ldur            w1, [x0, #7]
    // 0x83bb18: DecompressPointer r1
    //     0x83bb18: add             x1, x1, HEAP, lsl #32
    // 0x83bb1c: cmp             w1, NULL
    // 0x83bb20: b.eq            #0x83bb48
    // 0x83bb24: ldr             x16, [fp, #0x10]
    // 0x83bb28: stp             x16, x1, [SP, #-0x10]!
    // 0x83bb2c: r0 = getWordBoundary()
    //     0x83bb2c: bl              #0x83b1e4  ; [dart:ui] Paragraph::getWordBoundary
    // 0x83bb30: add             SP, SP, #0x10
    // 0x83bb34: LeaveFrame
    //     0x83bb34: mov             SP, fp
    //     0x83bb38: ldp             fp, lr, [SP], #0x10
    // 0x83bb3c: ret
    //     0x83bb3c: ret             
    // 0x83bb40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bb40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83bb44: b               #0x83bb10
    // 0x83bb48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83bb48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getFullHeightForCaret(/* No info */) {
    // ** addr: 0xc4f354, size: 0x70
    // 0xc4f354: EnterFrame
    //     0xc4f354: stp             fp, lr, [SP, #-0x10]!
    //     0xc4f358: mov             fp, SP
    // 0xc4f35c: CheckStackOverflow
    //     0xc4f35c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4f360: cmp             SP, x16
    //     0xc4f364: b.ls            #0xc4f3b0
    // 0xc4f368: ldr             x16, [fp, #0x20]
    // 0xc4f36c: ldr             lr, [fp, #0x18]
    // 0xc4f370: stp             lr, x16, [SP, #-0x10]!
    // 0xc4f374: ldr             x16, [fp, #0x10]
    // 0xc4f378: SaveReg r16
    //     0xc4f378: str             x16, [SP, #-8]!
    // 0xc4f37c: r0 = _computeCaretMetrics()
    //     0xc4f37c: bl              #0x520870  ; [package:flutter/src/painting/text_painter.dart] TextPainter::_computeCaretMetrics
    // 0xc4f380: add             SP, SP, #0x18
    // 0xc4f384: ldr             x1, [fp, #0x20]
    // 0xc4f388: LoadField: r2 = r1->field_57
    //     0xc4f388: ldur            w2, [x1, #0x57]
    // 0xc4f38c: DecompressPointer r2
    //     0xc4f38c: add             x2, x2, HEAP, lsl #32
    // 0xc4f390: r16 = Sentinel
    //     0xc4f390: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc4f394: cmp             w2, w16
    // 0xc4f398: b.eq            #0xc4f3b8
    // 0xc4f39c: LoadField: r0 = r2->field_b
    //     0xc4f39c: ldur            w0, [x2, #0xb]
    // 0xc4f3a0: DecompressPointer r0
    //     0xc4f3a0: add             x0, x0, HEAP, lsl #32
    // 0xc4f3a4: LeaveFrame
    //     0xc4f3a4: mov             SP, fp
    //     0xc4f3a8: ldp             fp, lr, [SP], #0x10
    // 0xc4f3ac: ret
    //     0xc4f3ac: ret             
    // 0xc4f3b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4f3b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4f3b4: b               #0xc4f368
    // 0xc4f3b8: r9 = _caretMetrics
    //     0xc4f3b8: add             x9, PP, #0x1f, lsl #12  ; [pp+0x1f538] Field <TextPainter._caretMetrics@879105366>: late (offset: 0x58)
    //     0xc4f3bc: ldr             x9, [x9, #0x538]
    // 0xc4f3c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc4f3c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ computeLineMetrics(/* No info */) {
    // ** addr: 0xcc0a2c, size: 0x8c
    // 0xcc0a2c: EnterFrame
    //     0xcc0a2c: stp             fp, lr, [SP, #-0x10]!
    //     0xcc0a30: mov             fp, SP
    // 0xcc0a34: CheckStackOverflow
    //     0xcc0a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc0a38: cmp             SP, x16
    //     0xcc0a3c: b.ls            #0xcc0aac
    // 0xcc0a40: ldr             x0, [fp, #0x10]
    // 0xcc0a44: LoadField: r1 = r0->field_63
    //     0xcc0a44: ldur            w1, [x0, #0x63]
    // 0xcc0a48: DecompressPointer r1
    //     0xcc0a48: add             x1, x1, HEAP, lsl #32
    // 0xcc0a4c: cmp             w1, NULL
    // 0xcc0a50: b.ne            #0xcc0a9c
    // 0xcc0a54: LoadField: r1 = r0->field_7
    //     0xcc0a54: ldur            w1, [x0, #7]
    // 0xcc0a58: DecompressPointer r1
    //     0xcc0a58: add             x1, x1, HEAP, lsl #32
    // 0xcc0a5c: cmp             w1, NULL
    // 0xcc0a60: b.eq            #0xcc0ab4
    // 0xcc0a64: SaveReg r1
    //     0xcc0a64: str             x1, [SP, #-8]!
    // 0xcc0a68: r0 = computeLineMetrics()
    //     0xcc0a68: bl              #0xcc0ab8  ; [dart:ui] Paragraph::computeLineMetrics
    // 0xcc0a6c: add             SP, SP, #8
    // 0xcc0a70: mov             x1, x0
    // 0xcc0a74: ldr             x2, [fp, #0x10]
    // 0xcc0a78: StoreField: r2->field_63 = r0
    //     0xcc0a78: stur            w0, [x2, #0x63]
    //     0xcc0a7c: ldurb           w16, [x2, #-1]
    //     0xcc0a80: ldurb           w17, [x0, #-1]
    //     0xcc0a84: and             x16, x17, x16, lsr #2
    //     0xcc0a88: tst             x16, HEAP, lsr #32
    //     0xcc0a8c: b.eq            #0xcc0a94
    //     0xcc0a90: bl              #0xd6828c
    // 0xcc0a94: mov             x0, x1
    // 0xcc0a98: b               #0xcc0aa0
    // 0xcc0a9c: mov             x0, x1
    // 0xcc0aa0: LeaveFrame
    //     0xcc0aa0: mov             SP, fp
    //     0xcc0aa4: ldp             fp, lr, [SP], #0x10
    // 0xcc0aa8: ret
    //     0xcc0aa8: ret             
    // 0xcc0aac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc0aac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc0ab0: b               #0xcc0a40
    // 0xcc0ab4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcc0ab4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2074, size: 0x10, field offset: 0x8
//   const constructor, 
class _CaretMetrics extends Object {
}

// class id: 2075, size: 0x18, field offset: 0x8
//   const constructor, 
class PlaceholderDimensions extends Object {

  Size field_8;
  PlaceholderAlignment field_c;

  _ toString(/* No info */) {
    // ** addr: 0xae3238, size: 0x78
    // 0xae3238: EnterFrame
    //     0xae3238: stp             fp, lr, [SP, #-0x10]!
    //     0xae323c: mov             fp, SP
    // 0xae3240: CheckStackOverflow
    //     0xae3240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae3244: cmp             SP, x16
    //     0xae3248: b.ls            #0xae32a8
    // 0xae324c: r1 = Null
    //     0xae324c: mov             x1, NULL
    // 0xae3250: r2 = 10
    //     0xae3250: mov             x2, #0xa
    // 0xae3254: r0 = AllocateArray()
    //     0xae3254: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae3258: r17 = "PlaceholderDimensions("
    //     0xae3258: add             x17, PP, #0x28, lsl #12  ; [pp+0x28668] "PlaceholderDimensions("
    //     0xae325c: ldr             x17, [x17, #0x668]
    // 0xae3260: StoreField: r0->field_f = r17
    //     0xae3260: stur            w17, [x0, #0xf]
    // 0xae3264: ldr             x1, [fp, #0x10]
    // 0xae3268: LoadField: r2 = r1->field_7
    //     0xae3268: ldur            w2, [x1, #7]
    // 0xae326c: DecompressPointer r2
    //     0xae326c: add             x2, x2, HEAP, lsl #32
    // 0xae3270: StoreField: r0->field_13 = r2
    //     0xae3270: stur            w2, [x0, #0x13]
    // 0xae3274: r17 = ", "
    //     0xae3274: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae3278: StoreField: r0->field_17 = r17
    //     0xae3278: stur            w17, [x0, #0x17]
    // 0xae327c: LoadField: r2 = r1->field_13
    //     0xae327c: ldur            w2, [x1, #0x13]
    // 0xae3280: DecompressPointer r2
    //     0xae3280: add             x2, x2, HEAP, lsl #32
    // 0xae3284: StoreField: r0->field_1b = r2
    //     0xae3284: stur            w2, [x0, #0x1b]
    // 0xae3288: r17 = ")"
    //     0xae3288: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae328c: StoreField: r0->field_1f = r17
    //     0xae328c: stur            w17, [x0, #0x1f]
    // 0xae3290: SaveReg r0
    //     0xae3290: str             x0, [SP, #-8]!
    // 0xae3294: r0 = _interpolate()
    //     0xae3294: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3298: add             SP, SP, #8
    // 0xae329c: LeaveFrame
    //     0xae329c: mov             SP, fp
    //     0xae32a0: ldp             fp, lr, [SP], #0x10
    // 0xae32a4: ret
    //     0xae32a4: ret             
    // 0xae32a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae32a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae32ac: b               #0xae324c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0ec68, size: 0x78
    // 0xb0ec68: EnterFrame
    //     0xb0ec68: stp             fp, lr, [SP, #-0x10]!
    //     0xb0ec6c: mov             fp, SP
    // 0xb0ec70: CheckStackOverflow
    //     0xb0ec70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0ec74: cmp             SP, x16
    //     0xb0ec78: b.ls            #0xb0ecd8
    // 0xb0ec7c: ldr             x0, [fp, #0x10]
    // 0xb0ec80: LoadField: r1 = r0->field_7
    //     0xb0ec80: ldur            w1, [x0, #7]
    // 0xb0ec84: DecompressPointer r1
    //     0xb0ec84: add             x1, x1, HEAP, lsl #32
    // 0xb0ec88: LoadField: r2 = r0->field_b
    //     0xb0ec88: ldur            w2, [x0, #0xb]
    // 0xb0ec8c: DecompressPointer r2
    //     0xb0ec8c: add             x2, x2, HEAP, lsl #32
    // 0xb0ec90: LoadField: r3 = r0->field_13
    //     0xb0ec90: ldur            w3, [x0, #0x13]
    // 0xb0ec94: DecompressPointer r3
    //     0xb0ec94: add             x3, x3, HEAP, lsl #32
    // 0xb0ec98: LoadField: r4 = r0->field_f
    //     0xb0ec98: ldur            w4, [x0, #0xf]
    // 0xb0ec9c: DecompressPointer r4
    //     0xb0ec9c: add             x4, x4, HEAP, lsl #32
    // 0xb0eca0: stp             x2, x1, [SP, #-0x10]!
    // 0xb0eca4: stp             x4, x3, [SP, #-0x10]!
    // 0xb0eca8: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xb0eca8: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xb0ecac: r0 = hash()
    //     0xb0ecac: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0ecb0: add             SP, SP, #0x20
    // 0xb0ecb4: mov             x2, x0
    // 0xb0ecb8: r0 = BoxInt64Instr(r2)
    //     0xb0ecb8: sbfiz           x0, x2, #1, #0x1f
    //     0xb0ecbc: cmp             x2, x0, asr #1
    //     0xb0ecc0: b.eq            #0xb0eccc
    //     0xb0ecc4: bl              #0xd69bb8
    //     0xb0ecc8: stur            x2, [x0, #7]
    // 0xb0eccc: LeaveFrame
    //     0xb0eccc: mov             SP, fp
    //     0xb0ecd0: ldp             fp, lr, [SP], #0x10
    // 0xb0ecd4: ret
    //     0xb0ecd4: ret             
    // 0xb0ecd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0ecd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0ecdc: b               #0xb0ec7c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9e518, size: 0x120
    // 0xc9e518: EnterFrame
    //     0xc9e518: stp             fp, lr, [SP, #-0x10]!
    //     0xc9e51c: mov             fp, SP
    // 0xc9e520: CheckStackOverflow
    //     0xc9e520: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9e524: cmp             SP, x16
    //     0xc9e528: b.ls            #0xc9e630
    // 0xc9e52c: ldr             x0, [fp, #0x10]
    // 0xc9e530: cmp             w0, NULL
    // 0xc9e534: b.ne            #0xc9e548
    // 0xc9e538: r0 = false
    //     0xc9e538: add             x0, NULL, #0x30  ; false
    // 0xc9e53c: LeaveFrame
    //     0xc9e53c: mov             SP, fp
    //     0xc9e540: ldp             fp, lr, [SP], #0x10
    // 0xc9e544: ret
    //     0xc9e544: ret             
    // 0xc9e548: ldr             x1, [fp, #0x18]
    // 0xc9e54c: cmp             w1, w0
    // 0xc9e550: b.ne            #0xc9e564
    // 0xc9e554: r0 = true
    //     0xc9e554: add             x0, NULL, #0x20  ; true
    // 0xc9e558: LeaveFrame
    //     0xc9e558: mov             SP, fp
    //     0xc9e55c: ldp             fp, lr, [SP], #0x10
    // 0xc9e560: ret
    //     0xc9e560: ret             
    // 0xc9e564: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc9e564: mov             x2, #0x76
    //     0xc9e568: tbz             w0, #0, #0xc9e578
    //     0xc9e56c: ldur            x2, [x0, #-1]
    //     0xc9e570: ubfx            x2, x2, #0xc, #0x14
    //     0xc9e574: lsl             x2, x2, #1
    // 0xc9e578: r17 = 4150
    //     0xc9e578: mov             x17, #0x1036
    // 0xc9e57c: cmp             w2, w17
    // 0xc9e580: b.ne            #0xc9e620
    // 0xc9e584: LoadField: r2 = r0->field_7
    //     0xc9e584: ldur            w2, [x0, #7]
    // 0xc9e588: DecompressPointer r2
    //     0xc9e588: add             x2, x2, HEAP, lsl #32
    // 0xc9e58c: LoadField: r3 = r1->field_7
    //     0xc9e58c: ldur            w3, [x1, #7]
    // 0xc9e590: DecompressPointer r3
    //     0xc9e590: add             x3, x3, HEAP, lsl #32
    // 0xc9e594: LoadField: d0 = r3->field_7
    //     0xc9e594: ldur            d0, [x3, #7]
    // 0xc9e598: LoadField: d1 = r2->field_7
    //     0xc9e598: ldur            d1, [x2, #7]
    // 0xc9e59c: fcmp            d0, d1
    // 0xc9e5a0: b.vs            #0xc9e620
    // 0xc9e5a4: b.ne            #0xc9e620
    // 0xc9e5a8: LoadField: d0 = r3->field_f
    //     0xc9e5a8: ldur            d0, [x3, #0xf]
    // 0xc9e5ac: LoadField: d1 = r2->field_f
    //     0xc9e5ac: ldur            d1, [x2, #0xf]
    // 0xc9e5b0: fcmp            d0, d1
    // 0xc9e5b4: b.vs            #0xc9e620
    // 0xc9e5b8: b.ne            #0xc9e620
    // 0xc9e5bc: LoadField: r2 = r0->field_b
    //     0xc9e5bc: ldur            w2, [x0, #0xb]
    // 0xc9e5c0: DecompressPointer r2
    //     0xc9e5c0: add             x2, x2, HEAP, lsl #32
    // 0xc9e5c4: LoadField: r3 = r1->field_b
    //     0xc9e5c4: ldur            w3, [x1, #0xb]
    // 0xc9e5c8: DecompressPointer r3
    //     0xc9e5c8: add             x3, x3, HEAP, lsl #32
    // 0xc9e5cc: cmp             w2, w3
    // 0xc9e5d0: b.ne            #0xc9e620
    // 0xc9e5d4: LoadField: r2 = r0->field_13
    //     0xc9e5d4: ldur            w2, [x0, #0x13]
    // 0xc9e5d8: DecompressPointer r2
    //     0xc9e5d8: add             x2, x2, HEAP, lsl #32
    // 0xc9e5dc: LoadField: r3 = r1->field_13
    //     0xc9e5dc: ldur            w3, [x1, #0x13]
    // 0xc9e5e0: DecompressPointer r3
    //     0xc9e5e0: add             x3, x3, HEAP, lsl #32
    // 0xc9e5e4: cmp             w2, w3
    // 0xc9e5e8: b.ne            #0xc9e620
    // 0xc9e5ec: LoadField: r2 = r0->field_f
    //     0xc9e5ec: ldur            w2, [x0, #0xf]
    // 0xc9e5f0: DecompressPointer r2
    //     0xc9e5f0: add             x2, x2, HEAP, lsl #32
    // 0xc9e5f4: LoadField: r0 = r1->field_f
    //     0xc9e5f4: ldur            w0, [x1, #0xf]
    // 0xc9e5f8: DecompressPointer r0
    //     0xc9e5f8: add             x0, x0, HEAP, lsl #32
    // 0xc9e5fc: r1 = LoadClassIdInstr(r2)
    //     0xc9e5fc: ldur            x1, [x2, #-1]
    //     0xc9e600: ubfx            x1, x1, #0xc, #0x14
    // 0xc9e604: stp             x0, x2, [SP, #-0x10]!
    // 0xc9e608: mov             x0, x1
    // 0xc9e60c: mov             lr, x0
    // 0xc9e610: ldr             lr, [x21, lr, lsl #3]
    // 0xc9e614: blr             lr
    // 0xc9e618: add             SP, SP, #0x10
    // 0xc9e61c: b               #0xc9e624
    // 0xc9e620: r0 = false
    //     0xc9e620: add             x0, NULL, #0x30  ; false
    // 0xc9e624: LeaveFrame
    //     0xc9e624: mov             SP, fp
    //     0xc9e628: ldp             fp, lr, [SP], #0x10
    // 0xc9e62c: ret
    //     0xc9e62c: ret             
    // 0xc9e630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9e630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9e634: b               #0xc9e52c
  }
}

// class id: 5931, size: 0x14, field offset: 0x14
enum TextWidthBasis extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16a90, size: 0x5c
    // 0xb16a90: EnterFrame
    //     0xb16a90: stp             fp, lr, [SP, #-0x10]!
    //     0xb16a94: mov             fp, SP
    // 0xb16a98: CheckStackOverflow
    //     0xb16a98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16a9c: cmp             SP, x16
    //     0xb16aa0: b.ls            #0xb16ae4
    // 0xb16aa4: r1 = Null
    //     0xb16aa4: mov             x1, NULL
    // 0xb16aa8: r2 = 4
    //     0xb16aa8: mov             x2, #4
    // 0xb16aac: r0 = AllocateArray()
    //     0xb16aac: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16ab0: r17 = "TextWidthBasis."
    //     0xb16ab0: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1cf90] "TextWidthBasis."
    //     0xb16ab4: ldr             x17, [x17, #0xf90]
    // 0xb16ab8: StoreField: r0->field_f = r17
    //     0xb16ab8: stur            w17, [x0, #0xf]
    // 0xb16abc: ldr             x1, [fp, #0x10]
    // 0xb16ac0: LoadField: r2 = r1->field_f
    //     0xb16ac0: ldur            w2, [x1, #0xf]
    // 0xb16ac4: DecompressPointer r2
    //     0xb16ac4: add             x2, x2, HEAP, lsl #32
    // 0xb16ac8: StoreField: r0->field_13 = r2
    //     0xb16ac8: stur            w2, [x0, #0x13]
    // 0xb16acc: SaveReg r0
    //     0xb16acc: str             x0, [SP, #-8]!
    // 0xb16ad0: r0 = _interpolate()
    //     0xb16ad0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16ad4: add             SP, SP, #8
    // 0xb16ad8: LeaveFrame
    //     0xb16ad8: mov             SP, fp
    //     0xb16adc: ldp             fp, lr, [SP], #0x10
    // 0xb16ae0: ret
    //     0xb16ae0: ret             
    // 0xb16ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16ae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16ae8: b               #0xb16aa4
  }
}

// class id: 5932, size: 0x14, field offset: 0x14
enum TextOverflow extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16a34, size: 0x5c
    // 0xb16a34: EnterFrame
    //     0xb16a34: stp             fp, lr, [SP, #-0x10]!
    //     0xb16a38: mov             fp, SP
    // 0xb16a3c: CheckStackOverflow
    //     0xb16a3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16a40: cmp             SP, x16
    //     0xb16a44: b.ls            #0xb16a88
    // 0xb16a48: r1 = Null
    //     0xb16a48: mov             x1, NULL
    // 0xb16a4c: r2 = 4
    //     0xb16a4c: mov             x2, #4
    // 0xb16a50: r0 = AllocateArray()
    //     0xb16a50: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16a54: r17 = "TextOverflow."
    //     0xb16a54: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1cf98] "TextOverflow."
    //     0xb16a58: ldr             x17, [x17, #0xf98]
    // 0xb16a5c: StoreField: r0->field_f = r17
    //     0xb16a5c: stur            w17, [x0, #0xf]
    // 0xb16a60: ldr             x1, [fp, #0x10]
    // 0xb16a64: LoadField: r2 = r1->field_f
    //     0xb16a64: ldur            w2, [x1, #0xf]
    // 0xb16a68: DecompressPointer r2
    //     0xb16a68: add             x2, x2, HEAP, lsl #32
    // 0xb16a6c: StoreField: r0->field_13 = r2
    //     0xb16a6c: stur            w2, [x0, #0x13]
    // 0xb16a70: SaveReg r0
    //     0xb16a70: str             x0, [SP, #-8]!
    // 0xb16a74: r0 = _interpolate()
    //     0xb16a74: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16a78: add             SP, SP, #8
    // 0xb16a7c: LeaveFrame
    //     0xb16a7c: mov             SP, fp
    //     0xb16a80: ldp             fp, lr, [SP], #0x10
    // 0xb16a84: ret
    //     0xb16a84: ret             
    // 0xb16a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16a88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16a8c: b               #0xb16a48
  }
}

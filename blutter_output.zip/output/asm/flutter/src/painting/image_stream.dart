// lib: , url: package:flutter/src/painting/image_stream.dart

// class id: 1049370, size: 0x8
class :: {
}

// class id: 2082, size: 0xc, field offset: 0x8
class ImageStreamCompleterHandle extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0x5cd4f4, size: 0x130
    // 0x5cd4f4: EnterFrame
    //     0x5cd4f4: stp             fp, lr, [SP, #-0x10]!
    //     0x5cd4f8: mov             fp, SP
    // 0x5cd4fc: AllocStack(0x8)
    //     0x5cd4fc: sub             SP, SP, #8
    // 0x5cd500: CheckStackOverflow
    //     0x5cd500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cd504: cmp             SP, x16
    //     0x5cd508: b.ls            #0x5cd618
    // 0x5cd50c: ldr             x0, [fp, #0x10]
    // 0x5cd510: LoadField: r1 = r0->field_7
    //     0x5cd510: ldur            w1, [x0, #7]
    // 0x5cd514: DecompressPointer r1
    //     0x5cd514: add             x1, x1, HEAP, lsl #32
    // 0x5cd518: stur            x1, [fp, #-8]
    // 0x5cd51c: cmp             w1, NULL
    // 0x5cd520: b.eq            #0x5cd620
    // 0x5cd524: LoadField: r2 = r1->field_1f
    //     0x5cd524: ldur            x2, [x1, #0x1f]
    // 0x5cd528: sub             x3, x2, #1
    // 0x5cd52c: StoreField: r1->field_1f = r3
    //     0x5cd52c: stur            x3, [x1, #0x1f]
    // 0x5cd530: r2 = LoadClassIdInstr(r1)
    //     0x5cd530: ldur            x2, [x1, #-1]
    //     0x5cd534: ubfx            x2, x2, #0xc, #0x14
    // 0x5cd538: lsl             x2, x2, #1
    // 0x5cd53c: r17 = 5422
    //     0x5cd53c: mov             x17, #0x152e
    // 0x5cd540: cmp             w2, w17
    // 0x5cd544: b.ne            #0x5cd5dc
    // 0x5cd548: SaveReg r1
    //     0x5cd548: str             x1, [SP, #-8]!
    // 0x5cd54c: r0 = _maybeDispose()
    //     0x5cd54c: bl              #0xceddb0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_maybeDispose
    // 0x5cd550: add             SP, SP, #8
    // 0x5cd554: ldur            x1, [fp, #-8]
    // 0x5cd558: LoadField: r0 = r1->field_27
    //     0x5cd558: ldur            w0, [x1, #0x27]
    // 0x5cd55c: DecompressPointer r0
    //     0x5cd55c: add             x0, x0, HEAP, lsl #32
    // 0x5cd560: tbnz            w0, #4, #0x5cd600
    // 0x5cd564: LoadField: r0 = r1->field_2f
    //     0x5cd564: ldur            w0, [x1, #0x2f]
    // 0x5cd568: DecompressPointer r0
    //     0x5cd568: add             x0, x0, HEAP, lsl #32
    // 0x5cd56c: cmp             w0, NULL
    // 0x5cd570: b.eq            #0x5cd598
    // 0x5cd574: r2 = LoadClassIdInstr(r0)
    //     0x5cd574: ldur            x2, [x0, #-1]
    //     0x5cd578: ubfx            x2, x2, #0xc, #0x14
    // 0x5cd57c: stp             NULL, x0, [SP, #-0x10]!
    // 0x5cd580: mov             x0, x2
    // 0x5cd584: r0 = GDT[cid_x0 + 0x396]()
    //     0x5cd584: add             lr, x0, #0x396
    //     0x5cd588: ldr             lr, [x21, lr, lsl #3]
    //     0x5cd58c: blr             lr
    // 0x5cd590: add             SP, SP, #0x10
    // 0x5cd594: ldur            x1, [fp, #-8]
    // 0x5cd598: LoadField: r0 = r1->field_2f
    //     0x5cd598: ldur            w0, [x1, #0x2f]
    // 0x5cd59c: DecompressPointer r0
    //     0x5cd59c: add             x0, x0, HEAP, lsl #32
    // 0x5cd5a0: cmp             w0, NULL
    // 0x5cd5a4: b.ne            #0x5cd5b0
    // 0x5cd5a8: mov             x0, x1
    // 0x5cd5ac: b               #0x5cd5d4
    // 0x5cd5b0: r2 = LoadClassIdInstr(r0)
    //     0x5cd5b0: ldur            x2, [x0, #-1]
    //     0x5cd5b4: ubfx            x2, x2, #0xc, #0x14
    // 0x5cd5b8: SaveReg r0
    //     0x5cd5b8: str             x0, [SP, #-8]!
    // 0x5cd5bc: mov             x0, x2
    // 0x5cd5c0: r0 = GDT[cid_x0 + 0x307]()
    //     0x5cd5c0: add             lr, x0, #0x307
    //     0x5cd5c4: ldr             lr, [x21, lr, lsl #3]
    //     0x5cd5c8: blr             lr
    // 0x5cd5cc: add             SP, SP, #8
    // 0x5cd5d0: ldur            x0, [fp, #-8]
    // 0x5cd5d4: StoreField: r0->field_2f = rNULL
    //     0x5cd5d4: stur            NULL, [x0, #0x2f]
    // 0x5cd5d8: b               #0x5cd600
    // 0x5cd5dc: mov             x0, x1
    // 0x5cd5e0: r1 = LoadClassIdInstr(r0)
    //     0x5cd5e0: ldur            x1, [x0, #-1]
    //     0x5cd5e4: ubfx            x1, x1, #0xc, #0x14
    // 0x5cd5e8: SaveReg r0
    //     0x5cd5e8: str             x0, [SP, #-8]!
    // 0x5cd5ec: mov             x0, x1
    // 0x5cd5f0: r0 = GDT[cid_x0 + -0xffe]()
    //     0x5cd5f0: sub             lr, x0, #0xffe
    //     0x5cd5f4: ldr             lr, [x21, lr, lsl #3]
    //     0x5cd5f8: blr             lr
    // 0x5cd5fc: add             SP, SP, #8
    // 0x5cd600: ldr             x1, [fp, #0x10]
    // 0x5cd604: StoreField: r1->field_7 = rNULL
    //     0x5cd604: stur            NULL, [x1, #7]
    // 0x5cd608: r0 = Null
    //     0x5cd608: mov             x0, NULL
    // 0x5cd60c: LeaveFrame
    //     0x5cd60c: mov             SP, fp
    //     0x5cd610: ldp             fp, lr, [SP], #0x10
    // 0x5cd614: ret
    //     0x5cd614: ret             
    // 0x5cd618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cd618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cd61c: b               #0x5cd50c
    // 0x5cd620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5cd620: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2083, size: 0x14, field offset: 0x8
//   const constructor, 
class ImageStreamListener extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb0eb80, size: 0x70
    // 0xb0eb80: EnterFrame
    //     0xb0eb80: stp             fp, lr, [SP, #-0x10]!
    //     0xb0eb84: mov             fp, SP
    // 0xb0eb88: CheckStackOverflow
    //     0xb0eb88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0eb8c: cmp             SP, x16
    //     0xb0eb90: b.ls            #0xb0ebe8
    // 0xb0eb94: ldr             x0, [fp, #0x10]
    // 0xb0eb98: LoadField: r1 = r0->field_7
    //     0xb0eb98: ldur            w1, [x0, #7]
    // 0xb0eb9c: DecompressPointer r1
    //     0xb0eb9c: add             x1, x1, HEAP, lsl #32
    // 0xb0eba0: LoadField: r2 = r0->field_b
    //     0xb0eba0: ldur            w2, [x0, #0xb]
    // 0xb0eba4: DecompressPointer r2
    //     0xb0eba4: add             x2, x2, HEAP, lsl #32
    // 0xb0eba8: LoadField: r3 = r0->field_f
    //     0xb0eba8: ldur            w3, [x0, #0xf]
    // 0xb0ebac: DecompressPointer r3
    //     0xb0ebac: add             x3, x3, HEAP, lsl #32
    // 0xb0ebb0: stp             x2, x1, [SP, #-0x10]!
    // 0xb0ebb4: SaveReg r3
    //     0xb0ebb4: str             x3, [SP, #-8]!
    // 0xb0ebb8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xb0ebb8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xb0ebbc: r0 = hash()
    //     0xb0ebbc: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0ebc0: add             SP, SP, #0x18
    // 0xb0ebc4: mov             x2, x0
    // 0xb0ebc8: r0 = BoxInt64Instr(r2)
    //     0xb0ebc8: sbfiz           x0, x2, #1, #0x1f
    //     0xb0ebcc: cmp             x2, x0, asr #1
    //     0xb0ebd0: b.eq            #0xb0ebdc
    //     0xb0ebd4: bl              #0xd69bb8
    //     0xb0ebd8: stur            x2, [x0, #7]
    // 0xb0ebdc: LeaveFrame
    //     0xb0ebdc: mov             SP, fp
    //     0xb0ebe0: ldp             fp, lr, [SP], #0x10
    // 0xb0ebe4: ret
    //     0xb0ebe4: ret             
    // 0xb0ebe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0ebe8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0ebec: b               #0xb0eb94
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9dd58, size: 0x17c
    // 0xc9dd58: EnterFrame
    //     0xc9dd58: stp             fp, lr, [SP, #-0x10]!
    //     0xc9dd5c: mov             fp, SP
    // 0xc9dd60: CheckStackOverflow
    //     0xc9dd60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9dd64: cmp             SP, x16
    //     0xc9dd68: b.ls            #0xc9decc
    // 0xc9dd6c: ldr             x1, [fp, #0x10]
    // 0xc9dd70: cmp             w1, NULL
    // 0xc9dd74: b.ne            #0xc9dd88
    // 0xc9dd78: r0 = false
    //     0xc9dd78: add             x0, NULL, #0x30  ; false
    // 0xc9dd7c: LeaveFrame
    //     0xc9dd7c: mov             SP, fp
    //     0xc9dd80: ldp             fp, lr, [SP], #0x10
    // 0xc9dd84: ret
    //     0xc9dd84: ret             
    // 0xc9dd88: r0 = 59
    //     0xc9dd88: mov             x0, #0x3b
    // 0xc9dd8c: branchIfSmi(r1, 0xc9dd98)
    //     0xc9dd8c: tbz             w1, #0, #0xc9dd98
    // 0xc9dd90: r0 = LoadClassIdInstr(r1)
    //     0xc9dd90: ldur            x0, [x1, #-1]
    //     0xc9dd94: ubfx            x0, x0, #0xc, #0x14
    // 0xc9dd98: SaveReg r1
    //     0xc9dd98: str             x1, [SP, #-8]!
    // 0xc9dd9c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9dd9c: mov             x17, #0x57c5
    //     0xc9dda0: add             lr, x0, x17
    //     0xc9dda4: ldr             lr, [x21, lr, lsl #3]
    //     0xc9dda8: blr             lr
    // 0xc9ddac: add             SP, SP, #8
    // 0xc9ddb0: r1 = LoadClassIdInstr(r0)
    //     0xc9ddb0: ldur            x1, [x0, #-1]
    //     0xc9ddb4: ubfx            x1, x1, #0xc, #0x14
    // 0xc9ddb8: r16 = ImageStreamListener
    //     0xc9ddb8: ldr             x16, [PP, #0x4fa8]  ; [pp+0x4fa8] Type: ImageStreamListener
    // 0xc9ddbc: stp             x16, x0, [SP, #-0x10]!
    // 0xc9ddc0: mov             x0, x1
    // 0xc9ddc4: mov             lr, x0
    // 0xc9ddc8: ldr             lr, [x21, lr, lsl #3]
    // 0xc9ddcc: blr             lr
    // 0xc9ddd0: add             SP, SP, #0x10
    // 0xc9ddd4: tbz             w0, #4, #0xc9dde8
    // 0xc9ddd8: r0 = false
    //     0xc9ddd8: add             x0, NULL, #0x30  ; false
    // 0xc9dddc: LeaveFrame
    //     0xc9dddc: mov             SP, fp
    //     0xc9dde0: ldp             fp, lr, [SP], #0x10
    // 0xc9dde4: ret
    //     0xc9dde4: ret             
    // 0xc9dde8: ldr             x1, [fp, #0x10]
    // 0xc9ddec: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9ddec: mov             x0, #0x76
    //     0xc9ddf0: tbz             w1, #0, #0xc9de00
    //     0xc9ddf4: ldur            x0, [x1, #-1]
    //     0xc9ddf8: ubfx            x0, x0, #0xc, #0x14
    //     0xc9ddfc: lsl             x0, x0, #1
    // 0xc9de00: r17 = 4166
    //     0xc9de00: mov             x17, #0x1046
    // 0xc9de04: cmp             w0, w17
    // 0xc9de08: b.ne            #0xc9debc
    // 0xc9de0c: ldr             x2, [fp, #0x18]
    // 0xc9de10: LoadField: r0 = r1->field_7
    //     0xc9de10: ldur            w0, [x1, #7]
    // 0xc9de14: DecompressPointer r0
    //     0xc9de14: add             x0, x0, HEAP, lsl #32
    // 0xc9de18: LoadField: r3 = r2->field_7
    //     0xc9de18: ldur            w3, [x2, #7]
    // 0xc9de1c: DecompressPointer r3
    //     0xc9de1c: add             x3, x3, HEAP, lsl #32
    // 0xc9de20: r4 = LoadClassIdInstr(r0)
    //     0xc9de20: ldur            x4, [x0, #-1]
    //     0xc9de24: ubfx            x4, x4, #0xc, #0x14
    // 0xc9de28: stp             x3, x0, [SP, #-0x10]!
    // 0xc9de2c: mov             x0, x4
    // 0xc9de30: mov             lr, x0
    // 0xc9de34: ldr             lr, [x21, lr, lsl #3]
    // 0xc9de38: blr             lr
    // 0xc9de3c: add             SP, SP, #0x10
    // 0xc9de40: tbnz            w0, #4, #0xc9debc
    // 0xc9de44: ldr             x2, [fp, #0x18]
    // 0xc9de48: ldr             x1, [fp, #0x10]
    // 0xc9de4c: LoadField: r0 = r1->field_b
    //     0xc9de4c: ldur            w0, [x1, #0xb]
    // 0xc9de50: DecompressPointer r0
    //     0xc9de50: add             x0, x0, HEAP, lsl #32
    // 0xc9de54: LoadField: r3 = r2->field_b
    //     0xc9de54: ldur            w3, [x2, #0xb]
    // 0xc9de58: DecompressPointer r3
    //     0xc9de58: add             x3, x3, HEAP, lsl #32
    // 0xc9de5c: r4 = LoadClassIdInstr(r0)
    //     0xc9de5c: ldur            x4, [x0, #-1]
    //     0xc9de60: ubfx            x4, x4, #0xc, #0x14
    // 0xc9de64: stp             x3, x0, [SP, #-0x10]!
    // 0xc9de68: mov             x0, x4
    // 0xc9de6c: mov             lr, x0
    // 0xc9de70: ldr             lr, [x21, lr, lsl #3]
    // 0xc9de74: blr             lr
    // 0xc9de78: add             SP, SP, #0x10
    // 0xc9de7c: tbnz            w0, #4, #0xc9debc
    // 0xc9de80: ldr             x1, [fp, #0x18]
    // 0xc9de84: ldr             x0, [fp, #0x10]
    // 0xc9de88: LoadField: r2 = r0->field_f
    //     0xc9de88: ldur            w2, [x0, #0xf]
    // 0xc9de8c: DecompressPointer r2
    //     0xc9de8c: add             x2, x2, HEAP, lsl #32
    // 0xc9de90: LoadField: r0 = r1->field_f
    //     0xc9de90: ldur            w0, [x1, #0xf]
    // 0xc9de94: DecompressPointer r0
    //     0xc9de94: add             x0, x0, HEAP, lsl #32
    // 0xc9de98: r1 = LoadClassIdInstr(r2)
    //     0xc9de98: ldur            x1, [x2, #-1]
    //     0xc9de9c: ubfx            x1, x1, #0xc, #0x14
    // 0xc9dea0: stp             x0, x2, [SP, #-0x10]!
    // 0xc9dea4: mov             x0, x1
    // 0xc9dea8: mov             lr, x0
    // 0xc9deac: ldr             lr, [x21, lr, lsl #3]
    // 0xc9deb0: blr             lr
    // 0xc9deb4: add             SP, SP, #0x10
    // 0xc9deb8: b               #0xc9dec0
    // 0xc9debc: r0 = false
    //     0xc9debc: add             x0, NULL, #0x30  ; false
    // 0xc9dec0: LeaveFrame
    //     0xc9dec0: mov             SP, fp
    //     0xc9dec4: ldp             fp, lr, [SP], #0x10
    // 0xc9dec8: ret
    //     0xc9dec8: ret             
    // 0xc9decc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9decc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9ded0: b               #0xc9dd6c
  }
}

// class id: 2084, size: 0x18, field offset: 0x8
//   const constructor, 
class ImageInfo extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0x794180, size: 0x44
    // 0x794180: EnterFrame
    //     0x794180: stp             fp, lr, [SP, #-0x10]!
    //     0x794184: mov             fp, SP
    // 0x794188: CheckStackOverflow
    //     0x794188: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79418c: cmp             SP, x16
    //     0x794190: b.ls            #0x7941bc
    // 0x794194: ldr             x0, [fp, #0x10]
    // 0x794198: LoadField: r1 = r0->field_7
    //     0x794198: ldur            w1, [x0, #7]
    // 0x79419c: DecompressPointer r1
    //     0x79419c: add             x1, x1, HEAP, lsl #32
    // 0x7941a0: SaveReg r1
    //     0x7941a0: str             x1, [SP, #-8]!
    // 0x7941a4: r0 = dispose()
    //     0x7941a4: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0x7941a8: add             SP, SP, #8
    // 0x7941ac: r0 = Null
    //     0x7941ac: mov             x0, NULL
    // 0x7941b0: LeaveFrame
    //     0x7941b0: mov             SP, fp
    //     0x7941b4: ldp             fp, lr, [SP], #0x10
    // 0x7941b8: ret
    //     0x7941b8: ret             
    // 0x7941bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7941bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7941c0: b               #0x794194
  }
  _ toString(/* No info */) {
    // ** addr: 0xae2df4, size: 0x14c
    // 0xae2df4: EnterFrame
    //     0xae2df4: stp             fp, lr, [SP, #-0x10]!
    //     0xae2df8: mov             fp, SP
    // 0xae2dfc: AllocStack(0x10)
    //     0xae2dfc: sub             SP, SP, #0x10
    // 0xae2e00: CheckStackOverflow
    //     0xae2e00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae2e04: cmp             SP, x16
    //     0xae2e08: b.ls            #0xae2f20
    // 0xae2e0c: ldr             x0, [fp, #0x10]
    // 0xae2e10: LoadField: r3 = r0->field_13
    //     0xae2e10: ldur            w3, [x0, #0x13]
    // 0xae2e14: DecompressPointer r3
    //     0xae2e14: add             x3, x3, HEAP, lsl #32
    // 0xae2e18: stur            x3, [fp, #-8]
    // 0xae2e1c: cmp             w3, NULL
    // 0xae2e20: b.eq            #0xae2e58
    // 0xae2e24: r1 = Null
    //     0xae2e24: mov             x1, NULL
    // 0xae2e28: r2 = 4
    //     0xae2e28: mov             x2, #4
    // 0xae2e2c: r0 = AllocateArray()
    //     0xae2e2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2e30: mov             x1, x0
    // 0xae2e34: ldur            x0, [fp, #-8]
    // 0xae2e38: StoreField: r1->field_f = r0
    //     0xae2e38: stur            w0, [x1, #0xf]
    // 0xae2e3c: r17 = " "
    //     0xae2e3c: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xae2e40: StoreField: r1->field_13 = r17
    //     0xae2e40: stur            w17, [x1, #0x13]
    // 0xae2e44: SaveReg r1
    //     0xae2e44: str             x1, [SP, #-8]!
    // 0xae2e48: r0 = _interpolate()
    //     0xae2e48: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2e4c: add             SP, SP, #8
    // 0xae2e50: mov             x3, x0
    // 0xae2e54: b               #0xae2e5c
    // 0xae2e58: r3 = ""
    //     0xae2e58: ldr             x3, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xae2e5c: ldr             x0, [fp, #0x10]
    // 0xae2e60: stur            x3, [fp, #-8]
    // 0xae2e64: r1 = Null
    //     0xae2e64: mov             x1, NULL
    // 0xae2e68: r2 = 10
    //     0xae2e68: mov             x2, #0xa
    // 0xae2e6c: r0 = AllocateArray()
    //     0xae2e6c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2e70: mov             x1, x0
    // 0xae2e74: ldur            x0, [fp, #-8]
    // 0xae2e78: stur            x1, [fp, #-0x10]
    // 0xae2e7c: StoreField: r1->field_f = r0
    //     0xae2e7c: stur            w0, [x1, #0xf]
    // 0xae2e80: ldr             x0, [fp, #0x10]
    // 0xae2e84: LoadField: r2 = r0->field_7
    //     0xae2e84: ldur            w2, [x0, #7]
    // 0xae2e88: DecompressPointer r2
    //     0xae2e88: add             x2, x2, HEAP, lsl #32
    // 0xae2e8c: StoreField: r1->field_13 = r2
    //     0xae2e8c: stur            w2, [x1, #0x13]
    // 0xae2e90: r17 = " @ "
    //     0xae2e90: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2d7c0] " @ "
    //     0xae2e94: ldr             x17, [x17, #0x7c0]
    // 0xae2e98: StoreField: r1->field_17 = r17
    //     0xae2e98: stur            w17, [x1, #0x17]
    // 0xae2e9c: LoadField: d0 = r0->field_b
    //     0xae2e9c: ldur            d0, [x0, #0xb]
    // 0xae2ea0: r0 = inline_Allocate_Double()
    //     0xae2ea0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xae2ea4: add             x0, x0, #0x10
    //     0xae2ea8: cmp             x2, x0
    //     0xae2eac: b.ls            #0xae2f28
    //     0xae2eb0: str             x0, [THR, #0x60]  ; THR::top
    //     0xae2eb4: sub             x0, x0, #0xf
    //     0xae2eb8: mov             x2, #0xd108
    //     0xae2ebc: movk            x2, #3, lsl #16
    //     0xae2ec0: stur            x2, [x0, #-1]
    // 0xae2ec4: StoreField: r0->field_7 = d0
    //     0xae2ec4: stur            d0, [x0, #7]
    // 0xae2ec8: SaveReg r0
    //     0xae2ec8: str             x0, [SP, #-8]!
    // 0xae2ecc: r0 = debugFormatDouble()
    //     0xae2ecc: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xae2ed0: add             SP, SP, #8
    // 0xae2ed4: ldur            x1, [fp, #-0x10]
    // 0xae2ed8: ArrayStore: r1[3] = r0  ; List_4
    //     0xae2ed8: add             x25, x1, #0x1b
    //     0xae2edc: str             w0, [x25]
    //     0xae2ee0: tbz             w0, #0, #0xae2efc
    //     0xae2ee4: ldurb           w16, [x1, #-1]
    //     0xae2ee8: ldurb           w17, [x0, #-1]
    //     0xae2eec: and             x16, x17, x16, lsr #2
    //     0xae2ef0: tst             x16, HEAP, lsr #32
    //     0xae2ef4: b.eq            #0xae2efc
    //     0xae2ef8: bl              #0xd67e5c
    // 0xae2efc: ldur            x0, [fp, #-0x10]
    // 0xae2f00: r17 = "x"
    //     0xae2f00: ldr             x17, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xae2f04: StoreField: r0->field_1f = r17
    //     0xae2f04: stur            w17, [x0, #0x1f]
    // 0xae2f08: SaveReg r0
    //     0xae2f08: str             x0, [SP, #-8]!
    // 0xae2f0c: r0 = _interpolate()
    //     0xae2f0c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2f10: add             SP, SP, #8
    // 0xae2f14: LeaveFrame
    //     0xae2f14: mov             SP, fp
    //     0xae2f18: ldp             fp, lr, [SP], #0x10
    // 0xae2f1c: ret
    //     0xae2f1c: ret             
    // 0xae2f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae2f20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae2f24: b               #0xae2e0c
    // 0xae2f28: SaveReg d0
    //     0xae2f28: str             q0, [SP, #-0x10]!
    // 0xae2f2c: SaveReg r1
    //     0xae2f2c: str             x1, [SP, #-8]!
    // 0xae2f30: r0 = AllocateDouble()
    //     0xae2f30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae2f34: RestoreReg r1
    //     0xae2f34: ldr             x1, [SP], #8
    // 0xae2f38: RestoreReg d0
    //     0xae2f38: ldr             q0, [SP], #0x10
    // 0xae2f3c: b               #0xae2ec4
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0ead4, size: 0xac
    // 0xb0ead4: EnterFrame
    //     0xb0ead4: stp             fp, lr, [SP, #-0x10]!
    //     0xb0ead8: mov             fp, SP
    // 0xb0eadc: CheckStackOverflow
    //     0xb0eadc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0eae0: cmp             SP, x16
    //     0xb0eae4: b.ls            #0xb0eb60
    // 0xb0eae8: ldr             x0, [fp, #0x10]
    // 0xb0eaec: LoadField: r1 = r0->field_7
    //     0xb0eaec: ldur            w1, [x0, #7]
    // 0xb0eaf0: DecompressPointer r1
    //     0xb0eaf0: add             x1, x1, HEAP, lsl #32
    // 0xb0eaf4: LoadField: d0 = r0->field_b
    //     0xb0eaf4: ldur            d0, [x0, #0xb]
    // 0xb0eaf8: LoadField: r2 = r0->field_13
    //     0xb0eaf8: ldur            w2, [x0, #0x13]
    // 0xb0eafc: DecompressPointer r2
    //     0xb0eafc: add             x2, x2, HEAP, lsl #32
    // 0xb0eb00: r0 = inline_Allocate_Double()
    //     0xb0eb00: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xb0eb04: add             x0, x0, #0x10
    //     0xb0eb08: cmp             x3, x0
    //     0xb0eb0c: b.ls            #0xb0eb68
    //     0xb0eb10: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0eb14: sub             x0, x0, #0xf
    //     0xb0eb18: mov             x3, #0xd108
    //     0xb0eb1c: movk            x3, #3, lsl #16
    //     0xb0eb20: stur            x3, [x0, #-1]
    // 0xb0eb24: StoreField: r0->field_7 = d0
    //     0xb0eb24: stur            d0, [x0, #7]
    // 0xb0eb28: stp             x0, x1, [SP, #-0x10]!
    // 0xb0eb2c: SaveReg r2
    //     0xb0eb2c: str             x2, [SP, #-8]!
    // 0xb0eb30: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xb0eb30: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xb0eb34: r0 = hash()
    //     0xb0eb34: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0eb38: add             SP, SP, #0x18
    // 0xb0eb3c: mov             x2, x0
    // 0xb0eb40: r0 = BoxInt64Instr(r2)
    //     0xb0eb40: sbfiz           x0, x2, #1, #0x1f
    //     0xb0eb44: cmp             x2, x0, asr #1
    //     0xb0eb48: b.eq            #0xb0eb54
    //     0xb0eb4c: bl              #0xd69bb8
    //     0xb0eb50: stur            x2, [x0, #7]
    // 0xb0eb54: LeaveFrame
    //     0xb0eb54: mov             SP, fp
    //     0xb0eb58: ldp             fp, lr, [SP], #0x10
    // 0xb0eb5c: ret
    //     0xb0eb5c: ret             
    // 0xb0eb60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0eb60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0eb64: b               #0xb0eae8
    // 0xb0eb68: SaveReg d0
    //     0xb0eb68: str             q0, [SP, #-0x10]!
    // 0xb0eb6c: stp             x1, x2, [SP, #-0x10]!
    // 0xb0eb70: r0 = AllocateDouble()
    //     0xb0eb70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0eb74: ldp             x1, x2, [SP], #0x10
    // 0xb0eb78: RestoreReg d0
    //     0xb0eb78: ldr             q0, [SP], #0x10
    // 0xb0eb7c: b               #0xb0eb24
  }
  _ isCloneOf(/* No info */) {
    // ** addr: 0xc7147c, size: 0xa0
    // 0xc7147c: EnterFrame
    //     0xc7147c: stp             fp, lr, [SP, #-0x10]!
    //     0xc71480: mov             fp, SP
    // 0xc71484: CheckStackOverflow
    //     0xc71484: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc71488: cmp             SP, x16
    //     0xc7148c: b.ls            #0xc71514
    // 0xc71490: ldr             x0, [fp, #0x10]
    // 0xc71494: LoadField: r1 = r0->field_7
    //     0xc71494: ldur            w1, [x0, #7]
    // 0xc71498: DecompressPointer r1
    //     0xc71498: add             x1, x1, HEAP, lsl #32
    // 0xc7149c: ldr             x2, [fp, #0x18]
    // 0xc714a0: LoadField: r3 = r2->field_7
    //     0xc714a0: ldur            w3, [x2, #7]
    // 0xc714a4: DecompressPointer r3
    //     0xc714a4: add             x3, x3, HEAP, lsl #32
    // 0xc714a8: LoadField: r4 = r3->field_7
    //     0xc714a8: ldur            w4, [x3, #7]
    // 0xc714ac: DecompressPointer r4
    //     0xc714ac: add             x4, x4, HEAP, lsl #32
    // 0xc714b0: LoadField: r3 = r1->field_7
    //     0xc714b0: ldur            w3, [x1, #7]
    // 0xc714b4: DecompressPointer r3
    //     0xc714b4: add             x3, x3, HEAP, lsl #32
    // 0xc714b8: cmp             w4, w3
    // 0xc714bc: b.ne            #0xc71504
    // 0xc714c0: LoadField: d0 = r2->field_b
    //     0xc714c0: ldur            d0, [x2, #0xb]
    // 0xc714c4: fcmp            d0, d0
    // 0xc714c8: b.vs            #0xc71504
    // 0xc714cc: b.ne            #0xc71504
    // 0xc714d0: LoadField: r1 = r0->field_13
    //     0xc714d0: ldur            w1, [x0, #0x13]
    // 0xc714d4: DecompressPointer r1
    //     0xc714d4: add             x1, x1, HEAP, lsl #32
    // 0xc714d8: LoadField: r0 = r2->field_13
    //     0xc714d8: ldur            w0, [x2, #0x13]
    // 0xc714dc: DecompressPointer r0
    //     0xc714dc: add             x0, x0, HEAP, lsl #32
    // 0xc714e0: r2 = LoadClassIdInstr(r1)
    //     0xc714e0: ldur            x2, [x1, #-1]
    //     0xc714e4: ubfx            x2, x2, #0xc, #0x14
    // 0xc714e8: stp             x0, x1, [SP, #-0x10]!
    // 0xc714ec: mov             x0, x2
    // 0xc714f0: mov             lr, x0
    // 0xc714f4: ldr             lr, [x21, lr, lsl #3]
    // 0xc714f8: blr             lr
    // 0xc714fc: add             SP, SP, #0x10
    // 0xc71500: b               #0xc71508
    // 0xc71504: r0 = false
    //     0xc71504: add             x0, NULL, #0x30  ; false
    // 0xc71508: LeaveFrame
    //     0xc71508: mov             SP, fp
    //     0xc7150c: ldp             fp, lr, [SP], #0x10
    // 0xc71510: ret
    //     0xc71510: ret             
    // 0xc71514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc71514: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc71518: b               #0xc71490
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9dc24, size: 0x134
    // 0xc9dc24: EnterFrame
    //     0xc9dc24: stp             fp, lr, [SP, #-0x10]!
    //     0xc9dc28: mov             fp, SP
    // 0xc9dc2c: CheckStackOverflow
    //     0xc9dc2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9dc30: cmp             SP, x16
    //     0xc9dc34: b.ls            #0xc9dd50
    // 0xc9dc38: ldr             x1, [fp, #0x10]
    // 0xc9dc3c: cmp             w1, NULL
    // 0xc9dc40: b.ne            #0xc9dc54
    // 0xc9dc44: r0 = false
    //     0xc9dc44: add             x0, NULL, #0x30  ; false
    // 0xc9dc48: LeaveFrame
    //     0xc9dc48: mov             SP, fp
    //     0xc9dc4c: ldp             fp, lr, [SP], #0x10
    // 0xc9dc50: ret
    //     0xc9dc50: ret             
    // 0xc9dc54: r0 = 59
    //     0xc9dc54: mov             x0, #0x3b
    // 0xc9dc58: branchIfSmi(r1, 0xc9dc64)
    //     0xc9dc58: tbz             w1, #0, #0xc9dc64
    // 0xc9dc5c: r0 = LoadClassIdInstr(r1)
    //     0xc9dc5c: ldur            x0, [x1, #-1]
    //     0xc9dc60: ubfx            x0, x0, #0xc, #0x14
    // 0xc9dc64: SaveReg r1
    //     0xc9dc64: str             x1, [SP, #-8]!
    // 0xc9dc68: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9dc68: mov             x17, #0x57c5
    //     0xc9dc6c: add             lr, x0, x17
    //     0xc9dc70: ldr             lr, [x21, lr, lsl #3]
    //     0xc9dc74: blr             lr
    // 0xc9dc78: add             SP, SP, #8
    // 0xc9dc7c: r1 = LoadClassIdInstr(r0)
    //     0xc9dc7c: ldur            x1, [x0, #-1]
    //     0xc9dc80: ubfx            x1, x1, #0xc, #0x14
    // 0xc9dc84: r16 = ImageInfo
    //     0xc9dc84: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d7b8] Type: ImageInfo
    //     0xc9dc88: ldr             x16, [x16, #0x7b8]
    // 0xc9dc8c: stp             x16, x0, [SP, #-0x10]!
    // 0xc9dc90: mov             x0, x1
    // 0xc9dc94: mov             lr, x0
    // 0xc9dc98: ldr             lr, [x21, lr, lsl #3]
    // 0xc9dc9c: blr             lr
    // 0xc9dca0: add             SP, SP, #0x10
    // 0xc9dca4: tbz             w0, #4, #0xc9dcb8
    // 0xc9dca8: r0 = false
    //     0xc9dca8: add             x0, NULL, #0x30  ; false
    // 0xc9dcac: LeaveFrame
    //     0xc9dcac: mov             SP, fp
    //     0xc9dcb0: ldp             fp, lr, [SP], #0x10
    // 0xc9dcb4: ret
    //     0xc9dcb4: ret             
    // 0xc9dcb8: ldr             x0, [fp, #0x10]
    // 0xc9dcbc: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc9dcbc: mov             x1, #0x76
    //     0xc9dcc0: tbz             w0, #0, #0xc9dcd0
    //     0xc9dcc4: ldur            x1, [x0, #-1]
    //     0xc9dcc8: ubfx            x1, x1, #0xc, #0x14
    //     0xc9dccc: lsl             x1, x1, #1
    // 0xc9dcd0: r17 = 4168
    //     0xc9dcd0: mov             x17, #0x1048
    // 0xc9dcd4: cmp             w1, w17
    // 0xc9dcd8: b.ne            #0xc9dd40
    // 0xc9dcdc: ldr             x1, [fp, #0x18]
    // 0xc9dce0: LoadField: r2 = r0->field_7
    //     0xc9dce0: ldur            w2, [x0, #7]
    // 0xc9dce4: DecompressPointer r2
    //     0xc9dce4: add             x2, x2, HEAP, lsl #32
    // 0xc9dce8: LoadField: r3 = r1->field_7
    //     0xc9dce8: ldur            w3, [x1, #7]
    // 0xc9dcec: DecompressPointer r3
    //     0xc9dcec: add             x3, x3, HEAP, lsl #32
    // 0xc9dcf0: cmp             w2, w3
    // 0xc9dcf4: b.ne            #0xc9dd40
    // 0xc9dcf8: LoadField: d0 = r0->field_b
    //     0xc9dcf8: ldur            d0, [x0, #0xb]
    // 0xc9dcfc: LoadField: d1 = r1->field_b
    //     0xc9dcfc: ldur            d1, [x1, #0xb]
    // 0xc9dd00: fcmp            d0, d1
    // 0xc9dd04: b.vs            #0xc9dd40
    // 0xc9dd08: b.ne            #0xc9dd40
    // 0xc9dd0c: LoadField: r2 = r0->field_13
    //     0xc9dd0c: ldur            w2, [x0, #0x13]
    // 0xc9dd10: DecompressPointer r2
    //     0xc9dd10: add             x2, x2, HEAP, lsl #32
    // 0xc9dd14: LoadField: r0 = r1->field_13
    //     0xc9dd14: ldur            w0, [x1, #0x13]
    // 0xc9dd18: DecompressPointer r0
    //     0xc9dd18: add             x0, x0, HEAP, lsl #32
    // 0xc9dd1c: r1 = LoadClassIdInstr(r2)
    //     0xc9dd1c: ldur            x1, [x2, #-1]
    //     0xc9dd20: ubfx            x1, x1, #0xc, #0x14
    // 0xc9dd24: stp             x0, x2, [SP, #-0x10]!
    // 0xc9dd28: mov             x0, x1
    // 0xc9dd2c: mov             lr, x0
    // 0xc9dd30: ldr             lr, [x21, lr, lsl #3]
    // 0xc9dd34: blr             lr
    // 0xc9dd38: add             SP, SP, #0x10
    // 0xc9dd3c: b               #0xc9dd44
    // 0xc9dd40: r0 = false
    //     0xc9dd40: add             x0, NULL, #0x30  ; false
    // 0xc9dd44: LeaveFrame
    //     0xc9dd44: mov             SP, fp
    //     0xc9dd48: ldp             fp, lr, [SP], #0x10
    // 0xc9dd4c: ret
    //     0xc9dd4c: ret             
    // 0xc9dd50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9dd50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9dd54: b               #0xc9dc38
  }
  _ clone(/* No info */) {
    // ** addr: 0xcec66c, size: 0x80
    // 0xcec66c: EnterFrame
    //     0xcec66c: stp             fp, lr, [SP, #-0x10]!
    //     0xcec670: mov             fp, SP
    // 0xcec674: AllocStack(0x18)
    //     0xcec674: sub             SP, SP, #0x18
    // 0xcec678: CheckStackOverflow
    //     0xcec678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec67c: cmp             SP, x16
    //     0xcec680: b.ls            #0xcec6e4
    // 0xcec684: ldr             x0, [fp, #0x10]
    // 0xcec688: LoadField: r1 = r0->field_7
    //     0xcec688: ldur            w1, [x0, #7]
    // 0xcec68c: DecompressPointer r1
    //     0xcec68c: add             x1, x1, HEAP, lsl #32
    // 0xcec690: SaveReg r1
    //     0xcec690: str             x1, [SP, #-8]!
    // 0xcec694: r0 = clone()
    //     0xcec694: bl              #0x6ca4f0  ; [dart:ui] Image::clone
    // 0xcec698: add             SP, SP, #8
    // 0xcec69c: mov             x1, x0
    // 0xcec6a0: ldr             x0, [fp, #0x10]
    // 0xcec6a4: stur            x1, [fp, #-0x10]
    // 0xcec6a8: LoadField: d0 = r0->field_b
    //     0xcec6a8: ldur            d0, [x0, #0xb]
    // 0xcec6ac: stur            d0, [fp, #-0x18]
    // 0xcec6b0: LoadField: r2 = r0->field_13
    //     0xcec6b0: ldur            w2, [x0, #0x13]
    // 0xcec6b4: DecompressPointer r2
    //     0xcec6b4: add             x2, x2, HEAP, lsl #32
    // 0xcec6b8: stur            x2, [fp, #-8]
    // 0xcec6bc: r0 = ImageInfo()
    //     0xcec6bc: bl              #0xcec6ec  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xcec6c0: ldur            x1, [fp, #-0x10]
    // 0xcec6c4: StoreField: r0->field_7 = r1
    //     0xcec6c4: stur            w1, [x0, #7]
    // 0xcec6c8: ldur            d0, [fp, #-0x18]
    // 0xcec6cc: StoreField: r0->field_b = d0
    //     0xcec6cc: stur            d0, [x0, #0xb]
    // 0xcec6d0: ldur            x1, [fp, #-8]
    // 0xcec6d4: StoreField: r0->field_13 = r1
    //     0xcec6d4: stur            w1, [x0, #0x13]
    // 0xcec6d8: LeaveFrame
    //     0xcec6d8: mov             SP, fp
    //     0xcec6dc: ldp             fp, lr, [SP], #0x10
    // 0xcec6e0: ret
    //     0xcec6e0: ret             
    // 0xcec6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcec6e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcec6e8: b               #0xcec684
  }
}

// class id: 2708, size: 0x10, field offset: 0x8
class ImageStream extends _DiagnosticableTree&Object&Diagnosticable {

  _ addListener(/* No info */) {
    // ** addr: 0x793c04, size: 0x158
    // 0x793c04: EnterFrame
    //     0x793c04: stp             fp, lr, [SP, #-0x10]!
    //     0x793c08: mov             fp, SP
    // 0x793c0c: AllocStack(0x10)
    //     0x793c0c: sub             SP, SP, #0x10
    // 0x793c10: CheckStackOverflow
    //     0x793c10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x793c14: cmp             SP, x16
    //     0x793c18: b.ls            #0x793d50
    // 0x793c1c: ldr             x0, [fp, #0x18]
    // 0x793c20: LoadField: r1 = r0->field_7
    //     0x793c20: ldur            w1, [x0, #7]
    // 0x793c24: DecompressPointer r1
    //     0x793c24: add             x1, x1, HEAP, lsl #32
    // 0x793c28: cmp             w1, NULL
    // 0x793c2c: b.eq            #0x793c60
    // 0x793c30: r0 = LoadClassIdInstr(r1)
    //     0x793c30: ldur            x0, [x1, #-1]
    //     0x793c34: ubfx            x0, x0, #0xc, #0x14
    // 0x793c38: ldr             x16, [fp, #0x10]
    // 0x793c3c: stp             x16, x1, [SP, #-0x10]!
    // 0x793c40: r0 = GDT[cid_x0 + -0xff2]()
    //     0x793c40: sub             lr, x0, #0xff2
    //     0x793c44: ldr             lr, [x21, lr, lsl #3]
    //     0x793c48: blr             lr
    // 0x793c4c: add             SP, SP, #0x10
    // 0x793c50: r0 = Null
    //     0x793c50: mov             x0, NULL
    // 0x793c54: LeaveFrame
    //     0x793c54: mov             SP, fp
    //     0x793c58: ldp             fp, lr, [SP], #0x10
    // 0x793c5c: ret
    //     0x793c5c: ret             
    // 0x793c60: LoadField: r1 = r0->field_b
    //     0x793c60: ldur            w1, [x0, #0xb]
    // 0x793c64: DecompressPointer r1
    //     0x793c64: add             x1, x1, HEAP, lsl #32
    // 0x793c68: cmp             w1, NULL
    // 0x793c6c: b.ne            #0x793cb0
    // 0x793c70: r16 = <ImageStreamListener>
    //     0x793c70: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e58] TypeArguments: <ImageStreamListener>
    //     0x793c74: ldr             x16, [x16, #0xe58]
    // 0x793c78: stp             xzr, x16, [SP, #-0x10]!
    // 0x793c7c: r0 = _GrowableList()
    //     0x793c7c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x793c80: add             SP, SP, #0x10
    // 0x793c84: mov             x2, x0
    // 0x793c88: ldr             x1, [fp, #0x18]
    // 0x793c8c: StoreField: r1->field_b = r0
    //     0x793c8c: stur            w0, [x1, #0xb]
    //     0x793c90: ldurb           w16, [x1, #-1]
    //     0x793c94: ldurb           w17, [x0, #-1]
    //     0x793c98: and             x16, x17, x16, lsr #2
    //     0x793c9c: tst             x16, HEAP, lsr #32
    //     0x793ca0: b.eq            #0x793ca8
    //     0x793ca4: bl              #0xd6826c
    // 0x793ca8: mov             x0, x2
    // 0x793cac: b               #0x793cb4
    // 0x793cb0: mov             x0, x1
    // 0x793cb4: stur            x0, [fp, #-0x10]
    // 0x793cb8: LoadField: r1 = r0->field_b
    //     0x793cb8: ldur            w1, [x0, #0xb]
    // 0x793cbc: DecompressPointer r1
    //     0x793cbc: add             x1, x1, HEAP, lsl #32
    // 0x793cc0: stur            x1, [fp, #-8]
    // 0x793cc4: LoadField: r2 = r0->field_f
    //     0x793cc4: ldur            w2, [x0, #0xf]
    // 0x793cc8: DecompressPointer r2
    //     0x793cc8: add             x2, x2, HEAP, lsl #32
    // 0x793ccc: LoadField: r3 = r2->field_b
    //     0x793ccc: ldur            w3, [x2, #0xb]
    // 0x793cd0: DecompressPointer r3
    //     0x793cd0: add             x3, x3, HEAP, lsl #32
    // 0x793cd4: cmp             w1, w3
    // 0x793cd8: b.ne            #0x793ce8
    // 0x793cdc: SaveReg r0
    //     0x793cdc: str             x0, [SP, #-8]!
    // 0x793ce0: r0 = _growToNextCapacity()
    //     0x793ce0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x793ce4: add             SP, SP, #8
    // 0x793ce8: ldur            x3, [fp, #-8]
    // 0x793cec: ldur            x2, [fp, #-0x10]
    // 0x793cf0: r4 = LoadInt32Instr(r3)
    //     0x793cf0: sbfx            x4, x3, #1, #0x1f
    // 0x793cf4: add             x0, x4, #1
    // 0x793cf8: lsl             x3, x0, #1
    // 0x793cfc: StoreField: r2->field_b = r3
    //     0x793cfc: stur            w3, [x2, #0xb]
    // 0x793d00: mov             x1, x4
    // 0x793d04: cmp             x1, x0
    // 0x793d08: b.hs            #0x793d58
    // 0x793d0c: LoadField: r1 = r2->field_f
    //     0x793d0c: ldur            w1, [x2, #0xf]
    // 0x793d10: DecompressPointer r1
    //     0x793d10: add             x1, x1, HEAP, lsl #32
    // 0x793d14: ldr             x0, [fp, #0x10]
    // 0x793d18: ArrayStore: r1[r4] = r0  ; List_4
    //     0x793d18: add             x25, x1, x4, lsl #2
    //     0x793d1c: add             x25, x25, #0xf
    //     0x793d20: str             w0, [x25]
    //     0x793d24: tbz             w0, #0, #0x793d40
    //     0x793d28: ldurb           w16, [x1, #-1]
    //     0x793d2c: ldurb           w17, [x0, #-1]
    //     0x793d30: and             x16, x17, x16, lsr #2
    //     0x793d34: tst             x16, HEAP, lsr #32
    //     0x793d38: b.eq            #0x793d40
    //     0x793d3c: bl              #0xd67e5c
    // 0x793d40: r0 = Null
    //     0x793d40: mov             x0, NULL
    // 0x793d44: LeaveFrame
    //     0x793d44: mov             SP, fp
    //     0x793d48: ldp             fp, lr, [SP], #0x10
    // 0x793d4c: ret
    //     0x793d4c: ret             
    // 0x793d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x793d50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x793d54: b               #0x793c1c
    // 0x793d58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x793d58: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x793d7c, size: 0x1a4
    // 0x793d7c: EnterFrame
    //     0x793d7c: stp             fp, lr, [SP, #-0x10]!
    //     0x793d80: mov             fp, SP
    // 0x793d84: AllocStack(0x10)
    //     0x793d84: sub             SP, SP, #0x10
    // 0x793d88: CheckStackOverflow
    //     0x793d88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x793d8c: cmp             SP, x16
    //     0x793d90: b.ls            #0x793f04
    // 0x793d94: ldr             x2, [fp, #0x18]
    // 0x793d98: LoadField: r0 = r2->field_7
    //     0x793d98: ldur            w0, [x2, #7]
    // 0x793d9c: DecompressPointer r0
    //     0x793d9c: add             x0, x0, HEAP, lsl #32
    // 0x793da0: stur            x0, [fp, #-8]
    // 0x793da4: cmp             w0, NULL
    // 0x793da8: b.eq            #0x793e48
    // 0x793dac: r1 = LoadClassIdInstr(r0)
    //     0x793dac: ldur            x1, [x0, #-1]
    //     0x793db0: ubfx            x1, x1, #0xc, #0x14
    // 0x793db4: lsl             x1, x1, #1
    // 0x793db8: r17 = 5422
    //     0x793db8: mov             x17, #0x152e
    // 0x793dbc: cmp             w1, w17
    // 0x793dc0: b.ne            #0x793e14
    // 0x793dc4: ldr             x16, [fp, #0x10]
    // 0x793dc8: stp             x16, x0, [SP, #-0x10]!
    // 0x793dcc: r0 = removeListener()
    //     0x793dcc: bl              #0xcedf10  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x793dd0: add             SP, SP, #0x10
    // 0x793dd4: ldur            x0, [fp, #-8]
    // 0x793dd8: LoadField: r1 = r0->field_7
    //     0x793dd8: ldur            w1, [x0, #7]
    // 0x793ddc: DecompressPointer r1
    //     0x793ddc: add             x1, x1, HEAP, lsl #32
    // 0x793de0: LoadField: r2 = r1->field_b
    //     0x793de0: ldur            w2, [x1, #0xb]
    // 0x793de4: DecompressPointer r2
    //     0x793de4: add             x2, x2, HEAP, lsl #32
    // 0x793de8: cbnz            w2, #0x793e38
    // 0x793dec: LoadField: r1 = r0->field_57
    //     0x793dec: ldur            w1, [x0, #0x57]
    // 0x793df0: DecompressPointer r1
    //     0x793df0: add             x1, x1, HEAP, lsl #32
    // 0x793df4: cmp             w1, NULL
    // 0x793df8: b.eq            #0x793e0c
    // 0x793dfc: SaveReg r1
    //     0x793dfc: str             x1, [SP, #-8]!
    // 0x793e00: r0 = cancel()
    //     0x793e00: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x793e04: add             SP, SP, #8
    // 0x793e08: ldur            x0, [fp, #-8]
    // 0x793e0c: StoreField: r0->field_57 = rNULL
    //     0x793e0c: stur            NULL, [x0, #0x57]
    // 0x793e10: b               #0x793e38
    // 0x793e14: r1 = LoadClassIdInstr(r0)
    //     0x793e14: ldur            x1, [x0, #-1]
    //     0x793e18: ubfx            x1, x1, #0xc, #0x14
    // 0x793e1c: ldr             x16, [fp, #0x10]
    // 0x793e20: stp             x16, x0, [SP, #-0x10]!
    // 0x793e24: mov             x0, x1
    // 0x793e28: r0 = GDT[cid_x0 + -0x1000]()
    //     0x793e28: sub             lr, x0, #1, lsl #12
    //     0x793e2c: ldr             lr, [x21, lr, lsl #3]
    //     0x793e30: blr             lr
    // 0x793e34: add             SP, SP, #0x10
    // 0x793e38: r0 = Null
    //     0x793e38: mov             x0, NULL
    // 0x793e3c: LeaveFrame
    //     0x793e3c: mov             SP, fp
    //     0x793e40: ldp             fp, lr, [SP], #0x10
    // 0x793e44: ret
    //     0x793e44: ret             
    // 0x793e48: r3 = 0
    //     0x793e48: mov             x3, #0
    // 0x793e4c: stur            x3, [fp, #-0x10]
    // 0x793e50: CheckStackOverflow
    //     0x793e50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x793e54: cmp             SP, x16
    //     0x793e58: b.ls            #0x793f0c
    // 0x793e5c: LoadField: r4 = r2->field_b
    //     0x793e5c: ldur            w4, [x2, #0xb]
    // 0x793e60: DecompressPointer r4
    //     0x793e60: add             x4, x4, HEAP, lsl #32
    // 0x793e64: cmp             w4, NULL
    // 0x793e68: b.eq            #0x793f14
    // 0x793e6c: LoadField: r0 = r4->field_b
    //     0x793e6c: ldur            w0, [x4, #0xb]
    // 0x793e70: DecompressPointer r0
    //     0x793e70: add             x0, x0, HEAP, lsl #32
    // 0x793e74: r1 = LoadInt32Instr(r0)
    //     0x793e74: sbfx            x1, x0, #1, #0x1f
    // 0x793e78: cmp             x3, x1
    // 0x793e7c: b.ge            #0x793ef4
    // 0x793e80: mov             x0, x1
    // 0x793e84: mov             x1, x3
    // 0x793e88: cmp             x1, x0
    // 0x793e8c: b.hs            #0x793f18
    // 0x793e90: LoadField: r0 = r4->field_f
    //     0x793e90: ldur            w0, [x4, #0xf]
    // 0x793e94: DecompressPointer r0
    //     0x793e94: add             x0, x0, HEAP, lsl #32
    // 0x793e98: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0x793e98: add             x16, x0, x3, lsl #2
    //     0x793e9c: ldur            w1, [x16, #0xf]
    // 0x793ea0: DecompressPointer r1
    //     0x793ea0: add             x1, x1, HEAP, lsl #32
    // 0x793ea4: ldr             x16, [fp, #0x10]
    // 0x793ea8: stp             x16, x1, [SP, #-0x10]!
    // 0x793eac: r0 = ==()
    //     0x793eac: bl              #0xc9dd58  ; [package:flutter/src/painting/image_stream.dart] ImageStreamListener::==
    // 0x793eb0: add             SP, SP, #0x10
    // 0x793eb4: tbnz            w0, #4, #0x793ee0
    // 0x793eb8: ldr             x0, [fp, #0x18]
    // 0x793ebc: ldur            x1, [fp, #-0x10]
    // 0x793ec0: LoadField: r2 = r0->field_b
    //     0x793ec0: ldur            w2, [x0, #0xb]
    // 0x793ec4: DecompressPointer r2
    //     0x793ec4: add             x2, x2, HEAP, lsl #32
    // 0x793ec8: cmp             w2, NULL
    // 0x793ecc: b.eq            #0x793f1c
    // 0x793ed0: stp             x1, x2, [SP, #-0x10]!
    // 0x793ed4: r0 = removeAt()
    //     0x793ed4: bl              #0x608dbc  ; [dart:core] _GrowableList::removeAt
    // 0x793ed8: add             SP, SP, #0x10
    // 0x793edc: b               #0x793ef4
    // 0x793ee0: ldr             x0, [fp, #0x18]
    // 0x793ee4: ldur            x1, [fp, #-0x10]
    // 0x793ee8: add             x3, x1, #1
    // 0x793eec: mov             x2, x0
    // 0x793ef0: b               #0x793e4c
    // 0x793ef4: r0 = Null
    //     0x793ef4: mov             x0, NULL
    // 0x793ef8: LeaveFrame
    //     0x793ef8: mov             SP, fp
    //     0x793efc: ldp             fp, lr, [SP], #0x10
    // 0x793f00: ret
    //     0x793f00: ret             
    // 0x793f04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x793f04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x793f08: b               #0x793d94
    // 0x793f0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x793f0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x793f10: b               #0x793e5c
    // 0x793f14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x793f14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x793f18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x793f18: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x793f1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x793f1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setCompleter(/* No info */) {
    // ** addr: 0x794af4, size: 0x1d4
    // 0x794af4: EnterFrame
    //     0x794af4: stp             fp, lr, [SP, #-0x10]!
    //     0x794af8: mov             fp, SP
    // 0x794afc: AllocStack(0x20)
    //     0x794afc: sub             SP, SP, #0x20
    // 0x794b00: CheckStackOverflow
    //     0x794b00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794b04: cmp             SP, x16
    //     0x794b08: b.ls            #0x794cb0
    // 0x794b0c: ldr             x0, [fp, #0x10]
    // 0x794b10: ldr             x1, [fp, #0x18]
    // 0x794b14: StoreField: r1->field_7 = r0
    //     0x794b14: stur            w0, [x1, #7]
    //     0x794b18: ldurb           w16, [x1, #-1]
    //     0x794b1c: ldurb           w17, [x0, #-1]
    //     0x794b20: and             x16, x17, x16, lsr #2
    //     0x794b24: tst             x16, HEAP, lsr #32
    //     0x794b28: b.eq            #0x794b30
    //     0x794b2c: bl              #0xd6826c
    // 0x794b30: LoadField: r0 = r1->field_b
    //     0x794b30: ldur            w0, [x1, #0xb]
    // 0x794b34: DecompressPointer r0
    //     0x794b34: add             x0, x0, HEAP, lsl #32
    // 0x794b38: stur            x0, [fp, #-8]
    // 0x794b3c: cmp             w0, NULL
    // 0x794b40: b.eq            #0x794c84
    // 0x794b44: ldr             x3, [fp, #0x10]
    // 0x794b48: r2 = true
    //     0x794b48: add             x2, NULL, #0x20  ; true
    // 0x794b4c: StoreField: r1->field_b = rNULL
    //     0x794b4c: stur            NULL, [x1, #0xb]
    // 0x794b50: StoreField: r3->field_1b = r2
    //     0x794b50: stur            w2, [x3, #0x1b]
    // 0x794b54: r2 = LoadClassIdInstr(r3)
    //     0x794b54: ldur            x2, [x3, #-1]
    //     0x794b58: ubfx            x2, x2, #0xc, #0x14
    // 0x794b5c: lsl             x2, x2, #1
    // 0x794b60: r17 = 5422
    //     0x794b60: mov             x17, #0x152e
    // 0x794b64: cmp             w2, w17
    // 0x794b68: b.ne            #0x794b98
    // 0x794b6c: r1 = 1
    //     0x794b6c: mov             x1, #1
    // 0x794b70: r0 = AllocateContext()
    //     0x794b70: bl              #0xd68aa4  ; AllocateContextStub
    // 0x794b74: mov             x1, x0
    // 0x794b78: ldr             x0, [fp, #0x10]
    // 0x794b7c: StoreField: r1->field_f = r0
    //     0x794b7c: stur            w0, [x1, #0xf]
    // 0x794b80: mov             x2, x1
    // 0x794b84: r1 = Function 'addListener':.
    //     0x794b84: add             x1, PP, #0x27, lsl #12  ; [pp+0x27eb8] AnonymousClosure: (0x794d14), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::addListener (0xcec6f8)
    //     0x794b88: ldr             x1, [x1, #0xeb8]
    // 0x794b8c: r0 = AllocateClosure()
    //     0x794b8c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x794b90: mov             x3, x0
    // 0x794b94: b               #0x794bc4
    // 0x794b98: mov             x0, x3
    // 0x794b9c: r1 = 1
    //     0x794b9c: mov             x1, #1
    // 0x794ba0: r0 = AllocateContext()
    //     0x794ba0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x794ba4: mov             x1, x0
    // 0x794ba8: ldr             x0, [fp, #0x10]
    // 0x794bac: StoreField: r1->field_f = r0
    //     0x794bac: stur            w0, [x1, #0xf]
    // 0x794bb0: mov             x2, x1
    // 0x794bb4: r1 = Function 'addListener':.
    //     0x794bb4: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ec0] AnonymousClosure: (0x794cc8), in [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener (0xcec384)
    //     0x794bb8: ldr             x1, [x1, #0xec0]
    // 0x794bbc: r0 = AllocateClosure()
    //     0x794bbc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x794bc0: mov             x3, x0
    // 0x794bc4: ldur            x2, [fp, #-8]
    // 0x794bc8: stur            x3, [fp, #-0x20]
    // 0x794bcc: LoadField: r4 = r2->field_b
    //     0x794bcc: ldur            w4, [x2, #0xb]
    // 0x794bd0: DecompressPointer r4
    //     0x794bd0: add             x4, x4, HEAP, lsl #32
    // 0x794bd4: stur            x4, [fp, #-0x18]
    // 0x794bd8: r0 = LoadInt32Instr(r4)
    //     0x794bd8: sbfx            x0, x4, #1, #0x1f
    // 0x794bdc: r5 = 0
    //     0x794bdc: mov             x5, #0
    // 0x794be0: stur            x5, [fp, #-0x10]
    // 0x794be4: CheckStackOverflow
    //     0x794be4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794be8: cmp             SP, x16
    //     0x794bec: b.ls            #0x794cb8
    // 0x794bf0: cmp             x5, x0
    // 0x794bf4: b.ge            #0x794c68
    // 0x794bf8: mov             x1, x5
    // 0x794bfc: cmp             x1, x0
    // 0x794c00: b.hs            #0x794cc0
    // 0x794c04: LoadField: r0 = r2->field_f
    //     0x794c04: ldur            w0, [x2, #0xf]
    // 0x794c08: DecompressPointer r0
    //     0x794c08: add             x0, x0, HEAP, lsl #32
    // 0x794c0c: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0x794c0c: add             x16, x0, x5, lsl #2
    //     0x794c10: ldur            w1, [x16, #0xf]
    // 0x794c14: DecompressPointer r1
    //     0x794c14: add             x1, x1, HEAP, lsl #32
    // 0x794c18: stp             x1, x3, [SP, #-0x10]!
    // 0x794c1c: mov             x0, x3
    // 0x794c20: ClosureCall
    //     0x794c20: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x794c24: ldur            x2, [x0, #0x1f]
    //     0x794c28: blr             x2
    // 0x794c2c: add             SP, SP, #0x10
    // 0x794c30: ldur            x0, [fp, #-8]
    // 0x794c34: LoadField: r1 = r0->field_b
    //     0x794c34: ldur            w1, [x0, #0xb]
    // 0x794c38: DecompressPointer r1
    //     0x794c38: add             x1, x1, HEAP, lsl #32
    // 0x794c3c: ldur            x2, [fp, #-0x18]
    // 0x794c40: cmp             w1, w2
    // 0x794c44: b.ne            #0x794c94
    // 0x794c48: ldur            x3, [fp, #-0x10]
    // 0x794c4c: add             x5, x3, #1
    // 0x794c50: r3 = LoadInt32Instr(r1)
    //     0x794c50: sbfx            x3, x1, #1, #0x1f
    // 0x794c54: mov             x4, x2
    // 0x794c58: mov             x2, x0
    // 0x794c5c: mov             x0, x3
    // 0x794c60: ldur            x3, [fp, #-0x20]
    // 0x794c64: b               #0x794be0
    // 0x794c68: ldr             x1, [fp, #0x18]
    // 0x794c6c: r2 = false
    //     0x794c6c: add             x2, NULL, #0x30  ; false
    // 0x794c70: LoadField: r3 = r1->field_7
    //     0x794c70: ldur            w3, [x1, #7]
    // 0x794c74: DecompressPointer r3
    //     0x794c74: add             x3, x3, HEAP, lsl #32
    // 0x794c78: cmp             w3, NULL
    // 0x794c7c: b.eq            #0x794cc4
    // 0x794c80: StoreField: r3->field_1b = r2
    //     0x794c80: stur            w2, [x3, #0x1b]
    // 0x794c84: r0 = Null
    //     0x794c84: mov             x0, NULL
    // 0x794c88: LeaveFrame
    //     0x794c88: mov             SP, fp
    //     0x794c8c: ldp             fp, lr, [SP], #0x10
    // 0x794c90: ret
    //     0x794c90: ret             
    // 0x794c94: r0 = ConcurrentModificationError()
    //     0x794c94: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x794c98: mov             x1, x0
    // 0x794c9c: ldur            x0, [fp, #-8]
    // 0x794ca0: StoreField: r1->field_b = r0
    //     0x794ca0: stur            w0, [x1, #0xb]
    // 0x794ca4: mov             x0, x1
    // 0x794ca8: r0 = Throw()
    //     0x794ca8: bl              #0xd67e38  ; ThrowStub
    // 0x794cac: brk             #0
    // 0x794cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794cb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794cb4: b               #0x794b0c
    // 0x794cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794cb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794cbc: b               #0x794bf0
    // 0x794cc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x794cc0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x794cc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x794cc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2709, size: 0x8, field offset: 0x8
//   const constructor, 
class ImageChunkEvent extends _DiagnosticableTree&Object&Diagnosticable {
}

// class id: 2710, size: 0x30, field offset: 0x8
abstract class ImageStreamCompleter extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hasListeners(/* No info */) {
    // ** addr: 0x5cd458, size: 0x28
    // 0x5cd458: ldr             x1, [SP]
    // 0x5cd45c: LoadField: r2 = r1->field_7
    //     0x5cd45c: ldur            w2, [x1, #7]
    // 0x5cd460: DecompressPointer r2
    //     0x5cd460: add             x2, x2, HEAP, lsl #32
    // 0x5cd464: LoadField: r1 = r2->field_b
    //     0x5cd464: ldur            w1, [x2, #0xb]
    // 0x5cd468: DecompressPointer r1
    //     0x5cd468: add             x1, x1, HEAP, lsl #32
    // 0x5cd46c: cbnz            w1, #0x5cd478
    // 0x5cd470: r0 = false
    //     0x5cd470: add             x0, NULL, #0x30  ; false
    // 0x5cd474: b               #0x5cd47c
    // 0x5cd478: r0 = true
    //     0x5cd478: add             x0, NULL, #0x20  ; true
    // 0x5cd47c: ret
    //     0x5cd47c: ret             
  }
  _ reportError(/* No info */) {
    // ** addr: 0x794728, size: 0x3cc
    // 0x794728: EnterFrame
    //     0x794728: stp             fp, lr, [SP, #-0x10]!
    //     0x79472c: mov             fp, SP
    // 0x794730: AllocStack(0xd0)
    //     0x794730: sub             SP, SP, #0xd0
    // 0x794734: SetupParameters(ImageStreamCompleter this /* r3, fp-0xd0 */, dynamic _ /* r4, fp-0xc8 */, dynamic _ /* r5, fp-0xc0 */, dynamic _ /* r6, fp-0xb8 */, {dynamic informationCollector = Null /* r7, fp-0xb0 */, dynamic silent = false /* r0, fp-0xa8 */})
    //     0x794734: mov             x0, x4
    //     0x794738: ldur            w1, [x0, #0x13]
    //     0x79473c: add             x1, x1, HEAP, lsl #32
    //     0x794740: sub             x2, x1, #8
    //     0x794744: add             x3, fp, w2, sxtw #2
    //     0x794748: ldr             x3, [x3, #0x28]
    //     0x79474c: stur            x3, [fp, #-0xd0]
    //     0x794750: add             x4, fp, w2, sxtw #2
    //     0x794754: ldr             x4, [x4, #0x20]
    //     0x794758: stur            x4, [fp, #-0xc8]
    //     0x79475c: add             x5, fp, w2, sxtw #2
    //     0x794760: ldr             x5, [x5, #0x18]
    //     0x794764: stur            x5, [fp, #-0xc0]
    //     0x794768: add             x6, fp, w2, sxtw #2
    //     0x79476c: ldr             x6, [x6, #0x10]
    //     0x794770: stur            x6, [fp, #-0xb8]
    //     0x794774: ldur            w2, [x0, #0x1f]
    //     0x794778: add             x2, x2, HEAP, lsl #32
    //     0x79477c: ldr             x16, [PP, #0x3d48]  ; [pp+0x3d48] "informationCollector"
    //     0x794780: cmp             w2, w16
    //     0x794784: b.ne            #0x7947a8
    //     0x794788: ldur            w2, [x0, #0x23]
    //     0x79478c: add             x2, x2, HEAP, lsl #32
    //     0x794790: sub             w7, w1, w2
    //     0x794794: add             x2, fp, w7, sxtw #2
    //     0x794798: ldr             x2, [x2, #8]
    //     0x79479c: mov             x7, x2
    //     0x7947a0: mov             x2, #1
    //     0x7947a4: b               #0x7947b0
    //     0x7947a8: mov             x7, NULL
    //     0x7947ac: mov             x2, #0
    //     0x7947b0: stur            x7, [fp, #-0xb0]
    //     0x7947b4: lsl             x8, x2, #1
    //     0x7947b8: lsl             w2, w8, #1
    //     0x7947bc: add             w8, w2, #8
    //     0x7947c0: add             x16, x0, w8, sxtw #1
    //     0x7947c4: ldur            w9, [x16, #0xf]
    //     0x7947c8: add             x9, x9, HEAP, lsl #32
    //     0x7947cc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e88] "silent"
    //     0x7947d0: ldr             x16, [x16, #0xe88]
    //     0x7947d4: cmp             w9, w16
    //     0x7947d8: b.ne            #0x794800
    //     0x7947dc: add             w8, w2, #0xa
    //     0x7947e0: add             x16, x0, w8, sxtw #1
    //     0x7947e4: ldur            w2, [x16, #0xf]
    //     0x7947e8: add             x2, x2, HEAP, lsl #32
    //     0x7947ec: sub             w0, w1, w2
    //     0x7947f0: add             x1, fp, w0, sxtw #2
    //     0x7947f4: ldr             x1, [x1, #8]
    //     0x7947f8: mov             x0, x1
    //     0x7947fc: b               #0x794804
    //     0x794800: add             x0, NULL, #0x30  ; false
    //     0x794804: stur            x0, [fp, #-0xa8]
    // 0x794808: CheckStackOverflow
    //     0x794808: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79480c: cmp             SP, x16
    //     0x794810: b.ls            #0x794adc
    // 0x794814: r0 = FlutterErrorDetails()
    //     0x794814: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x794818: ldur            x3, [fp, #-0xc0]
    // 0x79481c: StoreField: r0->field_7 = r3
    //     0x79481c: stur            w3, [x0, #7]
    // 0x794820: ldur            x4, [fp, #-0xb8]
    // 0x794824: StoreField: r0->field_b = r4
    //     0x794824: stur            w4, [x0, #0xb]
    // 0x794828: r2 = "image resource service"
    //     0x794828: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e90] "image resource service"
    //     0x79482c: ldr             x2, [x2, #0xe90]
    // 0x794830: StoreField: r0->field_f = r2
    //     0x794830: stur            w2, [x0, #0xf]
    // 0x794834: ldur            x1, [fp, #-0xc8]
    // 0x794838: StoreField: r0->field_13 = r1
    //     0x794838: stur            w1, [x0, #0x13]
    // 0x79483c: ldur            x1, [fp, #-0xb0]
    // 0x794840: StoreField: r0->field_1b = r1
    //     0x794840: stur            w1, [x0, #0x1b]
    // 0x794844: ldur            x1, [fp, #-0xa8]
    // 0x794848: StoreField: r0->field_1f = r1
    //     0x794848: stur            w1, [x0, #0x1f]
    // 0x79484c: ldur            x5, [fp, #-0xd0]
    // 0x794850: StoreField: r5->field_f = r0
    //     0x794850: stur            w0, [x5, #0xf]
    //     0x794854: ldurb           w16, [x5, #-1]
    //     0x794858: ldurb           w17, [x0, #-1]
    //     0x79485c: and             x16, x17, x16, lsr #2
    //     0x794860: tst             x16, HEAP, lsr #32
    //     0x794864: b.eq            #0x79486c
    //     0x794868: bl              #0xd682ec
    // 0x79486c: LoadField: r0 = r5->field_7
    //     0x79486c: ldur            w0, [x5, #7]
    // 0x794870: DecompressPointer r0
    //     0x794870: add             x0, x0, HEAP, lsl #32
    // 0x794874: stur            x0, [fp, #-0xa8]
    // 0x794878: r1 = Function '<anonymous closure>':.
    //     0x794878: add             x1, PP, #0x27, lsl #12  ; [pp+0x27e98] Function: [dart:io] _SecureFilterImpl::buffers (0xd635d8)
    //     0x79487c: ldr             x1, [x1, #0xe98]
    // 0x794880: r2 = Null
    //     0x794880: mov             x2, NULL
    // 0x794884: r0 = AllocateClosure()
    //     0x794884: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x794888: r16 = <((dynamic this, Object, StackTrace?) => void?)?>
    //     0x794888: add             x16, PP, #0x27, lsl #12  ; [pp+0x27ea0] TypeArguments: <((dynamic this, Object, StackTrace?) => void?)?>
    //     0x79488c: ldr             x16, [x16, #0xea0]
    // 0x794890: ldur            lr, [fp, #-0xa8]
    // 0x794894: stp             lr, x16, [SP, #-0x10]!
    // 0x794898: SaveReg r0
    //     0x794898: str             x0, [SP, #-8]!
    // 0x79489c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x79489c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7948a0: r0 = map()
    //     0x7948a0: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x7948a4: add             SP, SP, #0x18
    // 0x7948a8: r16 = <(dynamic this, Object, StackTrace?) => void?>
    //     0x7948a8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27ea8] TypeArguments: <(dynamic this, Object, StackTrace?) => void?>
    //     0x7948ac: ldr             x16, [x16, #0xea8]
    // 0x7948b0: stp             x0, x16, [SP, #-0x10]!
    // 0x7948b4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x7948b4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x7948b8: r0 = whereType()
    //     0x7948b8: bl              #0x6a7924  ; [dart:collection] _ListBase&Object&ListMixin::whereType
    // 0x7948bc: add             SP, SP, #0x10
    // 0x7948c0: SaveReg r0
    //     0x7948c0: str             x0, [SP, #-8]!
    // 0x7948c4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7948c4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7948c8: r0 = toList()
    //     0x7948c8: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x7948cc: add             SP, SP, #8
    // 0x7948d0: r1 = LoadClassIdInstr(r0)
    //     0x7948d0: ldur            x1, [x0, #-1]
    //     0x7948d4: ubfx            x1, x1, #0xc, #0x14
    // 0x7948d8: SaveReg r0
    //     0x7948d8: str             x0, [SP, #-8]!
    // 0x7948dc: mov             x0, x1
    // 0x7948e0: r0 = GDT[cid_x0 + 0xb940]()
    //     0x7948e0: mov             x17, #0xb940
    //     0x7948e4: add             lr, x0, x17
    //     0x7948e8: ldr             lr, [x21, lr, lsl #3]
    //     0x7948ec: blr             lr
    // 0x7948f0: add             SP, SP, #8
    // 0x7948f4: ldur            x5, [fp, #-0xd0]
    // 0x7948f8: ldur            x4, [fp, #-0xc0]
    // 0x7948fc: ldur            x3, [fp, #-0xb8]
    // 0x794900: mov             x1, x0
    // 0x794904: r2 = false
    //     0x794904: add             x2, NULL, #0x30  ; false
    // 0x794908: b               #0x7949e8
    // 0x79490c: r2 = "image resource service"
    //     0x79490c: add             x2, PP, #0x27, lsl #12  ; [pp+0x27e90] "image resource service"
    //     0x794910: ldr             x2, [x2, #0xe90]
    // 0x794914: sub             SP, fp, #0xd0
    // 0x794918: mov             x3, x0
    // 0x79491c: stur            x0, [fp, #-0xa8]
    // 0x794920: stur            x1, [fp, #-0xb0]
    // 0x794924: r0 = 59
    //     0x794924: mov             x0, #0x3b
    // 0x794928: branchIfSmi(r3, 0x794934)
    //     0x794928: tbz             w3, #0, #0x794934
    // 0x79492c: r0 = LoadClassIdInstr(r3)
    //     0x79492c: ldur            x0, [x3, #-1]
    //     0x794930: ubfx            x0, x0, #0xc, #0x14
    // 0x794934: ldur            x16, [fp, #-0x18]
    // 0x794938: stp             x16, x3, [SP, #-0x10]!
    // 0x79493c: mov             lr, x0
    // 0x794940: ldr             lr, [x21, lr, lsl #3]
    // 0x794944: blr             lr
    // 0x794948: add             SP, SP, #0x10
    // 0x79494c: tbz             w0, #4, #0x7949c0
    // 0x794950: ldur            x2, [fp, #-0xa8]
    // 0x794954: ldur            x0, [fp, #-0xb0]
    // 0x794958: r1 = <List<Object>>
    //     0x794958: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x79495c: r0 = ErrorDescription()
    //     0x79495c: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x794960: stur            x0, [fp, #-0xb8]
    // 0x794964: r16 = "when reporting an error to an image listener"
    //     0x794964: add             x16, PP, #0x27, lsl #12  ; [pp+0x27eb0] "when reporting an error to an image listener"
    //     0x794968: ldr             x16, [x16, #0xeb0]
    // 0x79496c: stp             x16, x0, [SP, #-0x10]!
    // 0x794970: r16 = Instance_DiagnosticLevel
    //     0x794970: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x794974: SaveReg r16
    //     0x794974: str             x16, [SP, #-8]!
    // 0x794978: r0 = _ErrorDiagnostic()
    //     0x794978: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x79497c: add             SP, SP, #0x18
    // 0x794980: r0 = FlutterErrorDetails()
    //     0x794980: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x794984: mov             x1, x0
    // 0x794988: ldur            x0, [fp, #-0xa8]
    // 0x79498c: StoreField: r1->field_7 = r0
    //     0x79498c: stur            w0, [x1, #7]
    // 0x794990: ldur            x0, [fp, #-0xb0]
    // 0x794994: StoreField: r1->field_b = r0
    //     0x794994: stur            w0, [x1, #0xb]
    // 0x794998: r0 = "image resource service"
    //     0x794998: add             x0, PP, #0x27, lsl #12  ; [pp+0x27e90] "image resource service"
    //     0x79499c: ldr             x0, [x0, #0xe90]
    // 0x7949a0: StoreField: r1->field_f = r0
    //     0x7949a0: stur            w0, [x1, #0xf]
    // 0x7949a4: ldur            x0, [fp, #-0xb8]
    // 0x7949a8: StoreField: r1->field_13 = r0
    //     0x7949a8: stur            w0, [x1, #0x13]
    // 0x7949ac: r0 = false
    //     0x7949ac: add             x0, NULL, #0x30  ; false
    // 0x7949b0: StoreField: r1->field_1f = r0
    //     0x7949b0: stur            w0, [x1, #0x1f]
    // 0x7949b4: SaveReg r1
    //     0x7949b4: str             x1, [SP, #-8]!
    // 0x7949b8: r0 = reportError()
    //     0x7949b8: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x7949bc: add             SP, SP, #8
    // 0x7949c0: ldur            x4, [fp, #-8]
    // 0x7949c4: ldur            x3, [fp, #-0x18]
    // 0x7949c8: ldur            x2, [fp, #-0x20]
    // 0x7949cc: ldur            x1, [fp, #-0x78]
    // 0x7949d0: ldur            x0, [fp, #-0x80]
    // 0x7949d4: mov             x5, x4
    // 0x7949d8: mov             x4, x3
    // 0x7949dc: mov             x3, x2
    // 0x7949e0: mov             x2, x1
    // 0x7949e4: mov             x1, x0
    // 0x7949e8: stur            x5, [fp, #-0xa8]
    // 0x7949ec: stur            x4, [fp, #-0xb0]
    // 0x7949f0: stur            x3, [fp, #-0xb8]
    // 0x7949f4: stur            x2, [fp, #-0xc0]
    // 0x7949f8: stur            x1, [fp, #-0xc8]
    // 0x7949fc: CheckStackOverflow
    //     0x7949fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794a00: cmp             SP, x16
    //     0x794a04: b.ls            #0x794ae4
    // 0x794a08: r0 = LoadClassIdInstr(r1)
    //     0x794a08: ldur            x0, [x1, #-1]
    //     0x794a0c: ubfx            x0, x0, #0xc, #0x14
    // 0x794a10: SaveReg r1
    //     0x794a10: str             x1, [SP, #-8]!
    // 0x794a14: r0 = GDT[cid_x0 + 0x541]()
    //     0x794a14: add             lr, x0, #0x541
    //     0x794a18: ldr             lr, [x21, lr, lsl #3]
    //     0x794a1c: blr             lr
    // 0x794a20: add             SP, SP, #8
    // 0x794a24: tbnz            w0, #4, #0x794a94
    // 0x794a28: ldur            x1, [fp, #-0xc8]
    // 0x794a2c: r0 = LoadClassIdInstr(r1)
    //     0x794a2c: ldur            x0, [x1, #-1]
    //     0x794a30: ubfx            x0, x0, #0xc, #0x14
    // 0x794a34: SaveReg r1
    //     0x794a34: str             x1, [SP, #-8]!
    // 0x794a38: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x794a38: add             lr, x0, #0x5ca
    //     0x794a3c: ldr             lr, [x21, lr, lsl #3]
    //     0x794a40: blr             lr
    // 0x794a44: add             SP, SP, #8
    // 0x794a48: mov             x1, x0
    // 0x794a4c: stur            x1, [fp, #-0xd0]
    // 0x794a50: cmp             w1, NULL
    // 0x794a54: b.eq            #0x794aec
    // 0x794a58: ldur            x16, [fp, #-0xb0]
    // 0x794a5c: stp             x16, x1, [SP, #-0x10]!
    // 0x794a60: ldur            x16, [fp, #-0xb8]
    // 0x794a64: SaveReg r16
    //     0x794a64: str             x16, [SP, #-8]!
    // 0x794a68: mov             x0, x1
    // 0x794a6c: ClosureCall
    //     0x794a6c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x794a70: ldur            x2, [x0, #0x1f]
    //     0x794a74: blr             x2
    // 0x794a78: add             SP, SP, #0x18
    // 0x794a7c: ldur            x4, [fp, #-0xa8]
    // 0x794a80: ldur            x3, [fp, #-0xb0]
    // 0x794a84: ldur            x2, [fp, #-0xb8]
    // 0x794a88: ldur            x0, [fp, #-0xc8]
    // 0x794a8c: r1 = true
    //     0x794a8c: add             x1, NULL, #0x20  ; true
    // 0x794a90: b               #0x7949d4
    // 0x794a94: ldur            x1, [fp, #-0xc0]
    // 0x794a98: mov             x0, x1
    // 0x794a9c: tbnz            w0, #5, #0x794aa4
    // 0x794aa0: r0 = AssertBoolean()
    //     0x794aa0: bl              #0xd67df0  ; AssertBooleanStub
    // 0x794aa4: ldur            x0, [fp, #-0xc0]
    // 0x794aa8: tbz             w0, #4, #0x794acc
    // 0x794aac: ldur            x0, [fp, #-0xa8]
    // 0x794ab0: LoadField: r1 = r0->field_f
    //     0x794ab0: ldur            w1, [x0, #0xf]
    // 0x794ab4: DecompressPointer r1
    //     0x794ab4: add             x1, x1, HEAP, lsl #32
    // 0x794ab8: cmp             w1, NULL
    // 0x794abc: b.eq            #0x794af0
    // 0x794ac0: SaveReg r1
    //     0x794ac0: str             x1, [SP, #-8]!
    // 0x794ac4: r0 = reportError()
    //     0x794ac4: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x794ac8: add             SP, SP, #8
    // 0x794acc: r0 = Null
    //     0x794acc: mov             x0, NULL
    // 0x794ad0: LeaveFrame
    //     0x794ad0: mov             SP, fp
    //     0x794ad4: ldp             fp, lr, [SP], #0x10
    // 0x794ad8: ret
    //     0x794ad8: ret             
    // 0x794adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794adc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794ae0: b               #0x794814
    // 0x794ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794ae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794ae8: b               #0x794a08
    // 0x794aec: r0 = NullErrorSharedWithoutFPURegs()
    //     0x794aec: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x794af0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x794af0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void addListener(dynamic, ImageStreamListener) {
    // ** addr: 0x794cc8, size: 0x4c
    // 0x794cc8: EnterFrame
    //     0x794cc8: stp             fp, lr, [SP, #-0x10]!
    //     0x794ccc: mov             fp, SP
    // 0x794cd0: ldr             x0, [fp, #0x18]
    // 0x794cd4: LoadField: r1 = r0->field_17
    //     0x794cd4: ldur            w1, [x0, #0x17]
    // 0x794cd8: DecompressPointer r1
    //     0x794cd8: add             x1, x1, HEAP, lsl #32
    // 0x794cdc: CheckStackOverflow
    //     0x794cdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794ce0: cmp             SP, x16
    //     0x794ce4: b.ls            #0x794d0c
    // 0x794ce8: LoadField: r0 = r1->field_f
    //     0x794ce8: ldur            w0, [x1, #0xf]
    // 0x794cec: DecompressPointer r0
    //     0x794cec: add             x0, x0, HEAP, lsl #32
    // 0x794cf0: ldr             x16, [fp, #0x10]
    // 0x794cf4: stp             x16, x0, [SP, #-0x10]!
    // 0x794cf8: r0 = addListener()
    //     0x794cf8: bl              #0xcec384  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener
    // 0x794cfc: add             SP, SP, #0x10
    // 0x794d00: LeaveFrame
    //     0x794d00: mov             SP, fp
    //     0x794d04: ldp             fp, lr, [SP], #0x10
    // 0x794d08: ret
    //     0x794d08: ret             
    // 0x794d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794d0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794d10: b               #0x794ce8
  }
  _ ImageStreamCompleter(/* No info */) {
    // ** addr: 0x794d60, size: 0xac
    // 0x794d60: EnterFrame
    //     0x794d60: stp             fp, lr, [SP, #-0x10]!
    //     0x794d64: mov             fp, SP
    // 0x794d68: r1 = false
    //     0x794d68: add             x1, NULL, #0x30  ; false
    // 0x794d6c: r0 = 0
    //     0x794d6c: mov             x0, #0
    // 0x794d70: CheckStackOverflow
    //     0x794d70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794d74: cmp             SP, x16
    //     0x794d78: b.ls            #0x794e04
    // 0x794d7c: ldr             x2, [fp, #0x10]
    // 0x794d80: StoreField: r2->field_17 = r1
    //     0x794d80: stur            w1, [x2, #0x17]
    // 0x794d84: StoreField: r2->field_1b = r1
    //     0x794d84: stur            w1, [x2, #0x1b]
    // 0x794d88: StoreField: r2->field_1f = r0
    //     0x794d88: stur            x0, [x2, #0x1f]
    // 0x794d8c: StoreField: r2->field_27 = r1
    //     0x794d8c: stur            w1, [x2, #0x27]
    // 0x794d90: r16 = <ImageStreamListener>
    //     0x794d90: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e58] TypeArguments: <ImageStreamListener>
    //     0x794d94: ldr             x16, [x16, #0xe58]
    // 0x794d98: stp             xzr, x16, [SP, #-0x10]!
    // 0x794d9c: r0 = _GrowableList()
    //     0x794d9c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x794da0: add             SP, SP, #0x10
    // 0x794da4: ldr             x1, [fp, #0x10]
    // 0x794da8: StoreField: r1->field_7 = r0
    //     0x794da8: stur            w0, [x1, #7]
    //     0x794dac: ldurb           w16, [x1, #-1]
    //     0x794db0: ldurb           w17, [x0, #-1]
    //     0x794db4: and             x16, x17, x16, lsr #2
    //     0x794db8: tst             x16, HEAP, lsr #32
    //     0x794dbc: b.eq            #0x794dc4
    //     0x794dc0: bl              #0xd6826c
    // 0x794dc4: r16 = <(dynamic this) => void?>
    //     0x794dc4: ldr             x16, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0x794dc8: stp             xzr, x16, [SP, #-0x10]!
    // 0x794dcc: r0 = _GrowableList()
    //     0x794dcc: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x794dd0: add             SP, SP, #0x10
    // 0x794dd4: ldr             x1, [fp, #0x10]
    // 0x794dd8: StoreField: r1->field_2b = r0
    //     0x794dd8: stur            w0, [x1, #0x2b]
    //     0x794ddc: ldurb           w16, [x1, #-1]
    //     0x794de0: ldurb           w17, [x0, #-1]
    //     0x794de4: and             x16, x17, x16, lsr #2
    //     0x794de8: tst             x16, HEAP, lsr #32
    //     0x794dec: b.eq            #0x794df4
    //     0x794df0: bl              #0xd6826c
    // 0x794df4: r0 = Null
    //     0x794df4: mov             x0, NULL
    // 0x794df8: LeaveFrame
    //     0x794df8: mov             SP, fp
    //     0x794dfc: ldp             fp, lr, [SP], #0x10
    // 0x794e00: ret
    //     0x794e00: ret             
    // 0x794e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794e04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794e08: b               #0x794d7c
  }
  _ keepAlive(/* No info */) {
    // ** addr: 0xa4ede0, size: 0x50
    // 0xa4ede0: EnterFrame
    //     0xa4ede0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ede4: mov             fp, SP
    // 0xa4ede8: CheckStackOverflow
    //     0xa4ede8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4edec: cmp             SP, x16
    //     0xa4edf0: b.ls            #0xa4ee28
    // 0xa4edf4: ldr             x16, [fp, #0x10]
    // 0xa4edf8: SaveReg r16
    //     0xa4edf8: str             x16, [SP, #-8]!
    // 0xa4edfc: r0 = _checkDisposed()
    //     0xa4edfc: bl              #0xa4ee3c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xa4ee00: add             SP, SP, #8
    // 0xa4ee04: r0 = ImageStreamCompleterHandle()
    //     0xa4ee04: bl              #0xa4ee30  ; AllocateImageStreamCompleterHandleStub -> ImageStreamCompleterHandle (size=0xc)
    // 0xa4ee08: ldr             x1, [fp, #0x10]
    // 0xa4ee0c: StoreField: r0->field_7 = r1
    //     0xa4ee0c: stur            w1, [x0, #7]
    // 0xa4ee10: LoadField: r2 = r1->field_1f
    //     0xa4ee10: ldur            x2, [x1, #0x1f]
    // 0xa4ee14: add             x3, x2, #1
    // 0xa4ee18: StoreField: r1->field_1f = r3
    //     0xa4ee18: stur            x3, [x1, #0x1f]
    // 0xa4ee1c: LeaveFrame
    //     0xa4ee1c: mov             SP, fp
    //     0xa4ee20: ldp             fp, lr, [SP], #0x10
    // 0xa4ee24: ret
    //     0xa4ee24: ret             
    // 0xa4ee28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ee28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ee2c: b               #0xa4edf4
  }
  _ _checkDisposed(/* No info */) {
    // ** addr: 0xa4ee3c, size: 0x44
    // 0xa4ee3c: EnterFrame
    //     0xa4ee3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ee40: mov             fp, SP
    // 0xa4ee44: ldr             x0, [fp, #0x10]
    // 0xa4ee48: LoadField: r1 = r0->field_27
    //     0xa4ee48: ldur            w1, [x0, #0x27]
    // 0xa4ee4c: DecompressPointer r1
    //     0xa4ee4c: add             x1, x1, HEAP, lsl #32
    // 0xa4ee50: tbz             w1, #4, #0xa4ee64
    // 0xa4ee54: r0 = Null
    //     0xa4ee54: mov             x0, NULL
    // 0xa4ee58: LeaveFrame
    //     0xa4ee58: mov             SP, fp
    //     0xa4ee5c: ldp             fp, lr, [SP], #0x10
    // 0xa4ee60: ret
    //     0xa4ee60: ret             
    // 0xa4ee64: r0 = StateError()
    //     0xa4ee64: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xa4ee68: mov             x1, x0
    // 0xa4ee6c: r0 = "Stream has been disposed.\nAn ImageStream is considered disposed once at least one listener has been added and subsequently all listeners have been removed and no handles are outstanding from the keepAlive method.\nTo resolve this error, maintain at least one listener on the stream, or create an ImageStreamCompleterHandle from the keepAlive method, or create a new stream for the image."
    //     0xa4ee6c: ldr             x0, [PP, #0x4fb0]  ; [pp+0x4fb0] "Stream has been disposed.\nAn ImageStream is considered disposed once at least one listener has been added and subsequently all listeners have been removed and no handles are outstanding from the keepAlive method.\nTo resolve this error, maintain at least one listener on the stream, or create an ImageStreamCompleterHandle from the keepAlive method, or create a new stream for the image."
    // 0xa4ee70: StoreField: r1->field_b = r0
    //     0xa4ee70: stur            w0, [x1, #0xb]
    // 0xa4ee74: mov             x0, x1
    // 0xa4ee78: r0 = Throw()
    //     0xa4ee78: bl              #0xd67e38  ; ThrowStub
    // 0xa4ee7c: brk             #0
  }
  _ removeOnLastListenerRemovedCallback(/* No info */) {
    // ** addr: 0xc31834, size: 0x58
    // 0xc31834: EnterFrame
    //     0xc31834: stp             fp, lr, [SP, #-0x10]!
    //     0xc31838: mov             fp, SP
    // 0xc3183c: CheckStackOverflow
    //     0xc3183c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc31840: cmp             SP, x16
    //     0xc31844: b.ls            #0xc31884
    // 0xc31848: ldr             x16, [fp, #0x18]
    // 0xc3184c: SaveReg r16
    //     0xc3184c: str             x16, [SP, #-8]!
    // 0xc31850: r0 = _checkDisposed()
    //     0xc31850: bl              #0xa4ee3c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xc31854: add             SP, SP, #8
    // 0xc31858: ldr             x0, [fp, #0x18]
    // 0xc3185c: LoadField: r1 = r0->field_2b
    //     0xc3185c: ldur            w1, [x0, #0x2b]
    // 0xc31860: DecompressPointer r1
    //     0xc31860: add             x1, x1, HEAP, lsl #32
    // 0xc31864: ldr             x16, [fp, #0x10]
    // 0xc31868: stp             x16, x1, [SP, #-0x10]!
    // 0xc3186c: r0 = remove()
    //     0xc3186c: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0xc31870: add             SP, SP, #0x10
    // 0xc31874: r0 = Null
    //     0xc31874: mov             x0, NULL
    // 0xc31878: LeaveFrame
    //     0xc31878: mov             SP, fp
    //     0xc3187c: ldp             fp, lr, [SP], #0x10
    // 0xc31880: ret
    //     0xc31880: ret             
    // 0xc31884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc31884: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc31888: b               #0xc31848
  }
  _ addOnLastListenerRemovedCallback(/* No info */) {
    // ** addr: 0xc40730, size: 0x114
    // 0xc40730: EnterFrame
    //     0xc40730: stp             fp, lr, [SP, #-0x10]!
    //     0xc40734: mov             fp, SP
    // 0xc40738: AllocStack(0x10)
    //     0xc40738: sub             SP, SP, #0x10
    // 0xc4073c: CheckStackOverflow
    //     0xc4073c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc40740: cmp             SP, x16
    //     0xc40744: b.ls            #0xc40838
    // 0xc40748: ldr             x16, [fp, #0x18]
    // 0xc4074c: SaveReg r16
    //     0xc4074c: str             x16, [SP, #-8]!
    // 0xc40750: r0 = _checkDisposed()
    //     0xc40750: bl              #0xa4ee3c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xc40754: add             SP, SP, #8
    // 0xc40758: ldr             x0, [fp, #0x18]
    // 0xc4075c: LoadField: r3 = r0->field_2b
    //     0xc4075c: ldur            w3, [x0, #0x2b]
    // 0xc40760: DecompressPointer r3
    //     0xc40760: add             x3, x3, HEAP, lsl #32
    // 0xc40764: stur            x3, [fp, #-8]
    // 0xc40768: LoadField: r2 = r3->field_7
    //     0xc40768: ldur            w2, [x3, #7]
    // 0xc4076c: DecompressPointer r2
    //     0xc4076c: add             x2, x2, HEAP, lsl #32
    // 0xc40770: ldr             x0, [fp, #0x10]
    // 0xc40774: r1 = Null
    //     0xc40774: mov             x1, NULL
    // 0xc40778: cmp             w2, NULL
    // 0xc4077c: b.eq            #0xc4079c
    // 0xc40780: LoadField: r4 = r2->field_17
    //     0xc40780: ldur            w4, [x2, #0x17]
    // 0xc40784: DecompressPointer r4
    //     0xc40784: add             x4, x4, HEAP, lsl #32
    // 0xc40788: r8 = X0
    //     0xc40788: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc4078c: LoadField: r9 = r4->field_7
    //     0xc4078c: ldur            x9, [x4, #7]
    // 0xc40790: r3 = Null
    //     0xc40790: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cba8] Null
    //     0xc40794: ldr             x3, [x3, #0xba8]
    // 0xc40798: blr             x9
    // 0xc4079c: ldur            x0, [fp, #-8]
    // 0xc407a0: LoadField: r1 = r0->field_b
    //     0xc407a0: ldur            w1, [x0, #0xb]
    // 0xc407a4: DecompressPointer r1
    //     0xc407a4: add             x1, x1, HEAP, lsl #32
    // 0xc407a8: stur            x1, [fp, #-0x10]
    // 0xc407ac: LoadField: r2 = r0->field_f
    //     0xc407ac: ldur            w2, [x0, #0xf]
    // 0xc407b0: DecompressPointer r2
    //     0xc407b0: add             x2, x2, HEAP, lsl #32
    // 0xc407b4: LoadField: r3 = r2->field_b
    //     0xc407b4: ldur            w3, [x2, #0xb]
    // 0xc407b8: DecompressPointer r3
    //     0xc407b8: add             x3, x3, HEAP, lsl #32
    // 0xc407bc: cmp             w1, w3
    // 0xc407c0: b.ne            #0xc407d0
    // 0xc407c4: SaveReg r0
    //     0xc407c4: str             x0, [SP, #-8]!
    // 0xc407c8: r0 = _growToNextCapacity()
    //     0xc407c8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc407cc: add             SP, SP, #8
    // 0xc407d0: ldur            x2, [fp, #-8]
    // 0xc407d4: ldur            x3, [fp, #-0x10]
    // 0xc407d8: r4 = LoadInt32Instr(r3)
    //     0xc407d8: sbfx            x4, x3, #1, #0x1f
    // 0xc407dc: add             x0, x4, #1
    // 0xc407e0: lsl             x3, x0, #1
    // 0xc407e4: StoreField: r2->field_b = r3
    //     0xc407e4: stur            w3, [x2, #0xb]
    // 0xc407e8: mov             x1, x4
    // 0xc407ec: cmp             x1, x0
    // 0xc407f0: b.hs            #0xc40840
    // 0xc407f4: LoadField: r1 = r2->field_f
    //     0xc407f4: ldur            w1, [x2, #0xf]
    // 0xc407f8: DecompressPointer r1
    //     0xc407f8: add             x1, x1, HEAP, lsl #32
    // 0xc407fc: ldr             x0, [fp, #0x10]
    // 0xc40800: ArrayStore: r1[r4] = r0  ; List_4
    //     0xc40800: add             x25, x1, x4, lsl #2
    //     0xc40804: add             x25, x25, #0xf
    //     0xc40808: str             w0, [x25]
    //     0xc4080c: tbz             w0, #0, #0xc40828
    //     0xc40810: ldurb           w16, [x1, #-1]
    //     0xc40814: ldurb           w17, [x0, #-1]
    //     0xc40818: and             x16, x17, x16, lsr #2
    //     0xc4081c: tst             x16, HEAP, lsr #32
    //     0xc40820: b.eq            #0xc40828
    //     0xc40824: bl              #0xd67e5c
    // 0xc40828: r0 = Null
    //     0xc40828: mov             x0, NULL
    // 0xc4082c: LeaveFrame
    //     0xc4082c: mov             SP, fp
    //     0xc40830: ldp             fp, lr, [SP], #0x10
    // 0xc40834: ret
    //     0xc40834: ret             
    // 0xc40838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc40838: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4083c: b               #0xc40748
    // 0xc40840: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc40840: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ addListener(/* No info */) {
    // ** addr: 0xcec384, size: 0x2e8
    // 0xcec384: EnterFrame
    //     0xcec384: stp             fp, lr, [SP, #-0x10]!
    //     0xcec388: mov             fp, SP
    // 0xcec38c: AllocStack(0x60)
    //     0xcec38c: sub             SP, SP, #0x60
    // 0xcec390: CheckStackOverflow
    //     0xcec390: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec394: cmp             SP, x16
    //     0xcec398: b.ls            #0xcec65c
    // 0xcec39c: ldr             x16, [fp, #0x18]
    // 0xcec3a0: SaveReg r16
    //     0xcec3a0: str             x16, [SP, #-8]!
    // 0xcec3a4: r0 = _checkDisposed()
    //     0xcec3a4: bl              #0xa4ee3c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xcec3a8: add             SP, SP, #8
    // 0xcec3ac: ldr             x1, [fp, #0x18]
    // 0xcec3b0: r0 = true
    //     0xcec3b0: add             x0, NULL, #0x20  ; true
    // 0xcec3b4: StoreField: r1->field_17 = r0
    //     0xcec3b4: stur            w0, [x1, #0x17]
    // 0xcec3b8: LoadField: r0 = r1->field_7
    //     0xcec3b8: ldur            w0, [x1, #7]
    // 0xcec3bc: DecompressPointer r0
    //     0xcec3bc: add             x0, x0, HEAP, lsl #32
    // 0xcec3c0: stur            x0, [fp, #-0x58]
    // 0xcec3c4: LoadField: r2 = r0->field_b
    //     0xcec3c4: ldur            w2, [x0, #0xb]
    // 0xcec3c8: DecompressPointer r2
    //     0xcec3c8: add             x2, x2, HEAP, lsl #32
    // 0xcec3cc: stur            x2, [fp, #-0x50]
    // 0xcec3d0: LoadField: r3 = r0->field_f
    //     0xcec3d0: ldur            w3, [x0, #0xf]
    // 0xcec3d4: DecompressPointer r3
    //     0xcec3d4: add             x3, x3, HEAP, lsl #32
    // 0xcec3d8: LoadField: r4 = r3->field_b
    //     0xcec3d8: ldur            w4, [x3, #0xb]
    // 0xcec3dc: DecompressPointer r4
    //     0xcec3dc: add             x4, x4, HEAP, lsl #32
    // 0xcec3e0: cmp             w2, w4
    // 0xcec3e4: b.ne            #0xcec3f4
    // 0xcec3e8: SaveReg r0
    //     0xcec3e8: str             x0, [SP, #-8]!
    // 0xcec3ec: r0 = _growToNextCapacity()
    //     0xcec3ec: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcec3f0: add             SP, SP, #8
    // 0xcec3f4: ldr             x2, [fp, #0x18]
    // 0xcec3f8: ldur            x3, [fp, #-0x58]
    // 0xcec3fc: ldur            x0, [fp, #-0x50]
    // 0xcec400: r4 = LoadInt32Instr(r0)
    //     0xcec400: sbfx            x4, x0, #1, #0x1f
    // 0xcec404: add             x0, x4, #1
    // 0xcec408: lsl             x1, x0, #1
    // 0xcec40c: StoreField: r3->field_b = r1
    //     0xcec40c: stur            w1, [x3, #0xb]
    // 0xcec410: mov             x1, x4
    // 0xcec414: cmp             x1, x0
    // 0xcec418: b.hs            #0xcec664
    // 0xcec41c: LoadField: r1 = r3->field_f
    //     0xcec41c: ldur            w1, [x3, #0xf]
    // 0xcec420: DecompressPointer r1
    //     0xcec420: add             x1, x1, HEAP, lsl #32
    // 0xcec424: ldr             x0, [fp, #0x10]
    // 0xcec428: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcec428: add             x25, x1, x4, lsl #2
    //     0xcec42c: add             x25, x25, #0xf
    //     0xcec430: str             w0, [x25]
    //     0xcec434: tbz             w0, #0, #0xcec450
    //     0xcec438: ldurb           w16, [x1, #-1]
    //     0xcec43c: ldurb           w17, [x0, #-1]
    //     0xcec440: and             x16, x17, x16, lsr #2
    //     0xcec444: tst             x16, HEAP, lsr #32
    //     0xcec448: b.eq            #0xcec450
    //     0xcec44c: bl              #0xd67e5c
    // 0xcec450: LoadField: r0 = r2->field_b
    //     0xcec450: ldur            w0, [x2, #0xb]
    // 0xcec454: DecompressPointer r0
    //     0xcec454: add             x0, x0, HEAP, lsl #32
    // 0xcec458: cmp             w0, NULL
    // 0xcec45c: b.eq            #0xcec4b8
    // 0xcec460: ldr             x1, [fp, #0x10]
    // 0xcec464: SaveReg r0
    //     0xcec464: str             x0, [SP, #-8]!
    // 0xcec468: r0 = clone()
    //     0xcec468: bl              #0xcec66c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::clone
    // 0xcec46c: add             SP, SP, #8
    // 0xcec470: ldr             x1, [fp, #0x18]
    // 0xcec474: LoadField: r2 = r1->field_1b
    //     0xcec474: ldur            w2, [x1, #0x1b]
    // 0xcec478: DecompressPointer r2
    //     0xcec478: add             x2, x2, HEAP, lsl #32
    // 0xcec47c: eor             x3, x2, #0x10
    // 0xcec480: ldr             x2, [fp, #0x10]
    // 0xcec484: LoadField: r4 = r2->field_7
    //     0xcec484: ldur            w4, [x2, #7]
    // 0xcec488: DecompressPointer r4
    //     0xcec488: add             x4, x4, HEAP, lsl #32
    // 0xcec48c: stur            x4, [fp, #-0x50]
    // 0xcec490: stp             x0, x4, [SP, #-0x10]!
    // 0xcec494: SaveReg r3
    //     0xcec494: str             x3, [SP, #-8]!
    // 0xcec498: mov             x0, x4
    // 0xcec49c: ClosureCall
    //     0xcec49c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xcec4a0: ldur            x2, [x0, #0x1f]
    //     0xcec4a4: blr             x2
    // 0xcec4a8: add             SP, SP, #0x18
    // 0xcec4ac: ldr             x1, [fp, #0x18]
    // 0xcec4b0: ldr             x0, [fp, #0x10]
    // 0xcec4b4: b               #0xcec52c
    // 0xcec4b8: ldr             x1, [fp, #0x18]
    // 0xcec4bc: ldr             x0, [fp, #0x10]
    // 0xcec4c0: b               #0xcec52c
    // 0xcec4c4: sub             SP, fp, #0x60
    // 0xcec4c8: mov             x2, x0
    // 0xcec4cc: stur            x0, [fp, #-0x50]
    // 0xcec4d0: mov             x0, x1
    // 0xcec4d4: stur            x1, [fp, #-0x58]
    // 0xcec4d8: r1 = <List<Object>>
    //     0xcec4d8: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xcec4dc: r0 = ErrorDescription()
    //     0xcec4dc: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xcec4e0: stur            x0, [fp, #-0x60]
    // 0xcec4e4: r16 = "by a synchronously-called image listener"
    //     0xcec4e4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27ec8] "by a synchronously-called image listener"
    //     0xcec4e8: ldr             x16, [x16, #0xec8]
    // 0xcec4ec: stp             x16, x0, [SP, #-0x10]!
    // 0xcec4f0: r16 = Instance_DiagnosticLevel
    //     0xcec4f0: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xcec4f4: SaveReg r16
    //     0xcec4f4: str             x16, [SP, #-8]!
    // 0xcec4f8: r0 = _ErrorDiagnostic()
    //     0xcec4f8: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xcec4fc: add             SP, SP, #0x18
    // 0xcec500: ldr             x16, [fp, #0x18]
    // 0xcec504: ldur            lr, [fp, #-0x60]
    // 0xcec508: stp             lr, x16, [SP, #-0x10]!
    // 0xcec50c: ldur            x16, [fp, #-0x50]
    // 0xcec510: ldur            lr, [fp, #-0x58]
    // 0xcec514: stp             lr, x16, [SP, #-0x10]!
    // 0xcec518: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xcec518: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xcec51c: r0 = reportError()
    //     0xcec51c: bl              #0x794728  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xcec520: add             SP, SP, #0x20
    // 0xcec524: ldr             x1, [fp, #0x18]
    // 0xcec528: ldr             x0, [fp, #0x10]
    // 0xcec52c: stur            x1, [fp, #-0x58]
    // 0xcec530: LoadField: r2 = r1->field_f
    //     0xcec530: ldur            w2, [x1, #0xf]
    // 0xcec534: DecompressPointer r2
    //     0xcec534: add             x2, x2, HEAP, lsl #32
    // 0xcec538: cmp             w2, NULL
    // 0xcec53c: b.eq            #0xcec64c
    // 0xcec540: LoadField: r3 = r0->field_f
    //     0xcec540: ldur            w3, [x0, #0xf]
    // 0xcec544: DecompressPointer r3
    //     0xcec544: add             x3, x3, HEAP, lsl #32
    // 0xcec548: stur            x3, [fp, #-0x50]
    // 0xcec54c: cmp             w3, NULL
    // 0xcec550: b.eq            #0xcec64c
    // 0xcec554: LoadField: r0 = r2->field_7
    //     0xcec554: ldur            w0, [x2, #7]
    // 0xcec558: DecompressPointer r0
    //     0xcec558: add             x0, x0, HEAP, lsl #32
    // 0xcec55c: LoadField: r4 = r2->field_b
    //     0xcec55c: ldur            w4, [x2, #0xb]
    // 0xcec560: DecompressPointer r4
    //     0xcec560: add             x4, x4, HEAP, lsl #32
    // 0xcec564: stp             x0, x3, [SP, #-0x10]!
    // 0xcec568: SaveReg r4
    //     0xcec568: str             x4, [SP, #-8]!
    // 0xcec56c: mov             x0, x3
    // 0xcec570: ClosureCall
    //     0xcec570: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xcec574: ldur            x2, [x0, #0x1f]
    //     0xcec578: blr             x2
    // 0xcec57c: add             SP, SP, #0x18
    // 0xcec580: b               #0xcec64c
    // 0xcec584: sub             SP, fp, #0x60
    // 0xcec588: mov             x2, x0
    // 0xcec58c: stur            x0, [fp, #-0x50]
    // 0xcec590: ldr             x0, [fp, #0x18]
    // 0xcec594: stur            x1, [fp, #-0x58]
    // 0xcec598: LoadField: r3 = r0->field_f
    //     0xcec598: ldur            w3, [x0, #0xf]
    // 0xcec59c: DecompressPointer r3
    //     0xcec59c: add             x3, x3, HEAP, lsl #32
    // 0xcec5a0: cmp             w3, NULL
    // 0xcec5a4: b.eq            #0xcec668
    // 0xcec5a8: LoadField: r0 = r3->field_7
    //     0xcec5a8: ldur            w0, [x3, #7]
    // 0xcec5ac: DecompressPointer r0
    //     0xcec5ac: add             x0, x0, HEAP, lsl #32
    // 0xcec5b0: r3 = 59
    //     0xcec5b0: mov             x3, #0x3b
    // 0xcec5b4: branchIfSmi(r2, 0xcec5c0)
    //     0xcec5b4: tbz             w2, #0, #0xcec5c0
    // 0xcec5b8: r3 = LoadClassIdInstr(r2)
    //     0xcec5b8: ldur            x3, [x2, #-1]
    //     0xcec5bc: ubfx            x3, x3, #0xc, #0x14
    // 0xcec5c0: stp             x0, x2, [SP, #-0x10]!
    // 0xcec5c4: mov             x0, x3
    // 0xcec5c8: mov             lr, x0
    // 0xcec5cc: ldr             lr, [x21, lr, lsl #3]
    // 0xcec5d0: blr             lr
    // 0xcec5d4: add             SP, SP, #0x10
    // 0xcec5d8: tbz             w0, #4, #0xcec64c
    // 0xcec5dc: ldur            x2, [fp, #-0x50]
    // 0xcec5e0: ldur            x0, [fp, #-0x58]
    // 0xcec5e4: r1 = <List<Object>>
    //     0xcec5e4: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xcec5e8: r0 = ErrorDescription()
    //     0xcec5e8: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xcec5ec: stur            x0, [fp, #-0x60]
    // 0xcec5f0: r16 = "by a synchronously-called image error listener"
    //     0xcec5f0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27ed0] "by a synchronously-called image error listener"
    //     0xcec5f4: ldr             x16, [x16, #0xed0]
    // 0xcec5f8: stp             x16, x0, [SP, #-0x10]!
    // 0xcec5fc: r16 = Instance_DiagnosticLevel
    //     0xcec5fc: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xcec600: SaveReg r16
    //     0xcec600: str             x16, [SP, #-8]!
    // 0xcec604: r0 = _ErrorDiagnostic()
    //     0xcec604: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xcec608: add             SP, SP, #0x18
    // 0xcec60c: r0 = FlutterErrorDetails()
    //     0xcec60c: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0xcec610: mov             x1, x0
    // 0xcec614: ldur            x0, [fp, #-0x50]
    // 0xcec618: StoreField: r1->field_7 = r0
    //     0xcec618: stur            w0, [x1, #7]
    // 0xcec61c: ldur            x0, [fp, #-0x58]
    // 0xcec620: StoreField: r1->field_b = r0
    //     0xcec620: stur            w0, [x1, #0xb]
    // 0xcec624: r0 = "image resource service"
    //     0xcec624: add             x0, PP, #0x27, lsl #12  ; [pp+0x27e90] "image resource service"
    //     0xcec628: ldr             x0, [x0, #0xe90]
    // 0xcec62c: StoreField: r1->field_f = r0
    //     0xcec62c: stur            w0, [x1, #0xf]
    // 0xcec630: ldur            x0, [fp, #-0x60]
    // 0xcec634: StoreField: r1->field_13 = r0
    //     0xcec634: stur            w0, [x1, #0x13]
    // 0xcec638: r0 = false
    //     0xcec638: add             x0, NULL, #0x30  ; false
    // 0xcec63c: StoreField: r1->field_1f = r0
    //     0xcec63c: stur            w0, [x1, #0x1f]
    // 0xcec640: SaveReg r1
    //     0xcec640: str             x1, [SP, #-8]!
    // 0xcec644: r0 = reportError()
    //     0xcec644: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xcec648: add             SP, SP, #8
    // 0xcec64c: r0 = Null
    //     0xcec64c: mov             x0, NULL
    // 0xcec650: LeaveFrame
    //     0xcec650: mov             SP, fp
    //     0xcec654: ldp             fp, lr, [SP], #0x10
    // 0xcec658: ret
    //     0xcec658: ret             
    // 0xcec65c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcec65c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcec660: b               #0xcec39c
    // 0xcec664: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcec664: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcec668: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcec668: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setImage(/* No info */) {
    // ** addr: 0xced12c, size: 0x214
    // 0xced12c: EnterFrame
    //     0xced12c: stp             fp, lr, [SP, #-0x10]!
    //     0xced130: mov             fp, SP
    // 0xced134: AllocStack(0x88)
    //     0xced134: sub             SP, SP, #0x88
    // 0xced138: CheckStackOverflow
    //     0xced138: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xced13c: cmp             SP, x16
    //     0xced140: b.ls            #0xced330
    // 0xced144: ldr             x16, [fp, #0x18]
    // 0xced148: SaveReg r16
    //     0xced148: str             x16, [SP, #-8]!
    // 0xced14c: r0 = _checkDisposed()
    //     0xced14c: bl              #0xa4ee3c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xced150: add             SP, SP, #8
    // 0xced154: ldr             x0, [fp, #0x18]
    // 0xced158: LoadField: r1 = r0->field_b
    //     0xced158: ldur            w1, [x0, #0xb]
    // 0xced15c: DecompressPointer r1
    //     0xced15c: add             x1, x1, HEAP, lsl #32
    // 0xced160: cmp             w1, NULL
    // 0xced164: b.ne            #0xced170
    // 0xced168: mov             x1, x0
    // 0xced16c: b               #0xced180
    // 0xced170: SaveReg r1
    //     0xced170: str             x1, [SP, #-8]!
    // 0xced174: r0 = dispose()
    //     0xced174: bl              #0x794180  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0xced178: add             SP, SP, #8
    // 0xced17c: ldr             x1, [fp, #0x18]
    // 0xced180: ldr             x0, [fp, #0x10]
    // 0xced184: StoreField: r1->field_b = r0
    //     0xced184: stur            w0, [x1, #0xb]
    //     0xced188: ldurb           w16, [x1, #-1]
    //     0xced18c: ldurb           w17, [x0, #-1]
    //     0xced190: and             x16, x17, x16, lsr #2
    //     0xced194: tst             x16, HEAP, lsr #32
    //     0xced198: b.eq            #0xced1a0
    //     0xced19c: bl              #0xd6826c
    // 0xced1a0: LoadField: r0 = r1->field_7
    //     0xced1a0: ldur            w0, [x1, #7]
    // 0xced1a4: DecompressPointer r0
    //     0xced1a4: add             x0, x0, HEAP, lsl #32
    // 0xced1a8: LoadField: r2 = r0->field_b
    //     0xced1a8: ldur            w2, [x0, #0xb]
    // 0xced1ac: DecompressPointer r2
    //     0xced1ac: add             x2, x2, HEAP, lsl #32
    // 0xced1b0: cbnz            w2, #0xced1c4
    // 0xced1b4: r0 = Null
    //     0xced1b4: mov             x0, NULL
    // 0xced1b8: LeaveFrame
    //     0xced1b8: mov             SP, fp
    //     0xced1bc: ldp             fp, lr, [SP], #0x10
    // 0xced1c0: ret
    //     0xced1c0: ret             
    // 0xced1c4: ldr             x2, [fp, #0x10]
    // 0xced1c8: r16 = <ImageStreamListener>
    //     0xced1c8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e58] TypeArguments: <ImageStreamListener>
    //     0xced1cc: ldr             x16, [x16, #0xe58]
    // 0xced1d0: stp             x0, x16, [SP, #-0x10]!
    // 0xced1d4: r0 = _GrowableList.of()
    //     0xced1d4: bl              #0x4bfaf0  ; [dart:core] _GrowableList::_GrowableList.of
    // 0xced1d8: add             SP, SP, #0x10
    // 0xced1dc: SaveReg r0
    //     0xced1dc: str             x0, [SP, #-8]!
    // 0xced1e0: r0 = iterator()
    //     0xced1e0: bl              #0x9bb07c  ; [dart:core] _GrowableList::iterator
    // 0xced1e4: add             SP, SP, #8
    // 0xced1e8: ldr             x3, [fp, #0x18]
    // 0xced1ec: ldr             x2, [fp, #0x10]
    // 0xced1f0: mov             x1, x0
    // 0xced1f4: b               #0xced270
    // 0xced1f8: sub             SP, fp, #0x88
    // 0xced1fc: mov             x2, x0
    // 0xced200: stur            x0, [fp, #-0x68]
    // 0xced204: mov             x0, x1
    // 0xced208: stur            x1, [fp, #-0x70]
    // 0xced20c: r1 = <List<Object>>
    //     0xced20c: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xced210: r0 = ErrorDescription()
    //     0xced210: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xced214: stur            x0, [fp, #-0x78]
    // 0xced218: r16 = "by an image listener"
    //     0xced218: add             x16, PP, #0x27, lsl #12  ; [pp+0x27f20] "by an image listener"
    //     0xced21c: ldr             x16, [x16, #0xf20]
    // 0xced220: stp             x16, x0, [SP, #-0x10]!
    // 0xced224: r16 = Instance_DiagnosticLevel
    //     0xced224: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xced228: SaveReg r16
    //     0xced228: str             x16, [SP, #-8]!
    // 0xced22c: r0 = _ErrorDiagnostic()
    //     0xced22c: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xced230: add             SP, SP, #0x18
    // 0xced234: ldr             x16, [fp, #0x18]
    // 0xced238: ldur            lr, [fp, #-0x78]
    // 0xced23c: stp             lr, x16, [SP, #-0x10]!
    // 0xced240: ldur            x16, [fp, #-0x68]
    // 0xced244: ldur            lr, [fp, #-0x70]
    // 0xced248: stp             lr, x16, [SP, #-0x10]!
    // 0xced24c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xced24c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xced250: r0 = reportError()
    //     0xced250: bl              #0x794728  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xced254: add             SP, SP, #0x20
    // 0xced258: ldr             x2, [fp, #0x18]
    // 0xced25c: ldr             x1, [fp, #0x10]
    // 0xced260: ldur            x0, [fp, #-0x40]
    // 0xced264: mov             x3, x2
    // 0xced268: mov             x2, x1
    // 0xced26c: mov             x1, x0
    // 0xced270: stur            x3, [fp, #-0x68]
    // 0xced274: stur            x2, [fp, #-0x70]
    // 0xced278: stur            x1, [fp, #-0x78]
    // 0xced27c: CheckStackOverflow
    //     0xced27c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xced280: cmp             SP, x16
    //     0xced284: b.ls            #0xced338
    // 0xced288: r0 = LoadClassIdInstr(r1)
    //     0xced288: ldur            x0, [x1, #-1]
    //     0xced28c: ubfx            x0, x0, #0xc, #0x14
    // 0xced290: SaveReg r1
    //     0xced290: str             x1, [SP, #-8]!
    // 0xced294: r0 = GDT[cid_x0 + 0x541]()
    //     0xced294: add             lr, x0, #0x541
    //     0xced298: ldr             lr, [x21, lr, lsl #3]
    //     0xced29c: blr             lr
    // 0xced2a0: add             SP, SP, #8
    // 0xced2a4: tbnz            w0, #4, #0xced320
    // 0xced2a8: ldur            x1, [fp, #-0x78]
    // 0xced2ac: r0 = LoadClassIdInstr(r1)
    //     0xced2ac: ldur            x0, [x1, #-1]
    //     0xced2b0: ubfx            x0, x0, #0xc, #0x14
    // 0xced2b4: SaveReg r1
    //     0xced2b4: str             x1, [SP, #-8]!
    // 0xced2b8: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xced2b8: add             lr, x0, #0x5ca
    //     0xced2bc: ldr             lr, [x21, lr, lsl #3]
    //     0xced2c0: blr             lr
    // 0xced2c4: add             SP, SP, #8
    // 0xced2c8: stur            x0, [fp, #-0x80]
    // 0xced2cc: ldur            x16, [fp, #-0x70]
    // 0xced2d0: SaveReg r16
    //     0xced2d0: str             x16, [SP, #-8]!
    // 0xced2d4: r0 = clone()
    //     0xced2d4: bl              #0xcec66c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::clone
    // 0xced2d8: add             SP, SP, #8
    // 0xced2dc: mov             x1, x0
    // 0xced2e0: ldur            x0, [fp, #-0x80]
    // 0xced2e4: LoadField: r2 = r0->field_7
    //     0xced2e4: ldur            w2, [x0, #7]
    // 0xced2e8: DecompressPointer r2
    //     0xced2e8: add             x2, x2, HEAP, lsl #32
    // 0xced2ec: stur            x2, [fp, #-0x88]
    // 0xced2f0: stp             x1, x2, [SP, #-0x10]!
    // 0xced2f4: r16 = false
    //     0xced2f4: add             x16, NULL, #0x30  ; false
    // 0xced2f8: SaveReg r16
    //     0xced2f8: str             x16, [SP, #-8]!
    // 0xced2fc: mov             x0, x2
    // 0xced300: ClosureCall
    //     0xced300: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xced304: ldur            x2, [x0, #0x1f]
    //     0xced308: blr             x2
    // 0xced30c: add             SP, SP, #0x18
    // 0xced310: ldur            x2, [fp, #-0x68]
    // 0xced314: ldur            x1, [fp, #-0x70]
    // 0xced318: ldur            x0, [fp, #-0x78]
    // 0xced31c: b               #0xced264
    // 0xced320: r0 = Null
    //     0xced320: mov             x0, NULL
    // 0xced324: LeaveFrame
    //     0xced324: mov             SP, fp
    //     0xced328: ldp             fp, lr, [SP], #0x10
    // 0xced32c: ret
    //     0xced32c: ret             
    // 0xced330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xced330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xced334: b               #0xced144
    // 0xced338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xced338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xced33c: b               #0xced288
  }
  dynamic reportImageChunkEvent(dynamic) {
    // ** addr: 0xcedb18, size: 0x18
    // 0xcedb18: r4 = 0
    //     0xcedb18: mov             x4, #0
    // 0xcedb1c: r1 = Function 'reportImageChunkEvent':.
    //     0xcedb1c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37198] AnonymousClosure: (0xcedb30), in [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportImageChunkEvent (0xcedb7c)
    //     0xcedb20: ldr             x1, [x17, #0x198]
    // 0xcedb24: r24 = BuildNonGenericMethodExtractorStub
    //     0xcedb24: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcedb28: LoadField: r0 = r24->field_17
    //     0xcedb28: ldur            x0, [x24, #0x17]
    // 0xcedb2c: br              x0
  }
  [closure] void reportImageChunkEvent(dynamic, ImageChunkEvent) {
    // ** addr: 0xcedb30, size: 0x4c
    // 0xcedb30: EnterFrame
    //     0xcedb30: stp             fp, lr, [SP, #-0x10]!
    //     0xcedb34: mov             fp, SP
    // 0xcedb38: ldr             x0, [fp, #0x18]
    // 0xcedb3c: LoadField: r1 = r0->field_17
    //     0xcedb3c: ldur            w1, [x0, #0x17]
    // 0xcedb40: DecompressPointer r1
    //     0xcedb40: add             x1, x1, HEAP, lsl #32
    // 0xcedb44: CheckStackOverflow
    //     0xcedb44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcedb48: cmp             SP, x16
    //     0xcedb4c: b.ls            #0xcedb74
    // 0xcedb50: LoadField: r0 = r1->field_f
    //     0xcedb50: ldur            w0, [x1, #0xf]
    // 0xcedb54: DecompressPointer r0
    //     0xcedb54: add             x0, x0, HEAP, lsl #32
    // 0xcedb58: ldr             x16, [fp, #0x10]
    // 0xcedb5c: stp             x16, x0, [SP, #-0x10]!
    // 0xcedb60: r0 = reportImageChunkEvent()
    //     0xcedb60: bl              #0xcedb7c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportImageChunkEvent
    // 0xcedb64: add             SP, SP, #0x10
    // 0xcedb68: LeaveFrame
    //     0xcedb68: mov             SP, fp
    //     0xcedb6c: ldp             fp, lr, [SP], #0x10
    // 0xcedb70: ret
    //     0xcedb70: ret             
    // 0xcedb74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcedb74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcedb78: b               #0xcedb50
  }
  _ reportImageChunkEvent(/* No info */) {
    // ** addr: 0xcedb7c, size: 0x160
    // 0xcedb7c: EnterFrame
    //     0xcedb7c: stp             fp, lr, [SP, #-0x10]!
    //     0xcedb80: mov             fp, SP
    // 0xcedb84: AllocStack(0x8)
    //     0xcedb84: sub             SP, SP, #8
    // 0xcedb88: CheckStackOverflow
    //     0xcedb88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcedb8c: cmp             SP, x16
    //     0xcedb90: b.ls            #0xcedcc8
    // 0xcedb94: ldr             x16, [fp, #0x18]
    // 0xcedb98: SaveReg r16
    //     0xcedb98: str             x16, [SP, #-8]!
    // 0xcedb9c: r0 = _checkDisposed()
    //     0xcedb9c: bl              #0xa4ee3c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xcedba0: add             SP, SP, #8
    // 0xcedba4: ldr             x0, [fp, #0x18]
    // 0xcedba8: LoadField: r3 = r0->field_7
    //     0xcedba8: ldur            w3, [x0, #7]
    // 0xcedbac: DecompressPointer r3
    //     0xcedbac: add             x3, x3, HEAP, lsl #32
    // 0xcedbb0: stur            x3, [fp, #-8]
    // 0xcedbb4: LoadField: r0 = r3->field_b
    //     0xcedbb4: ldur            w0, [x3, #0xb]
    // 0xcedbb8: DecompressPointer r0
    //     0xcedbb8: add             x0, x0, HEAP, lsl #32
    // 0xcedbbc: cbz             w0, #0xcedcb8
    // 0xcedbc0: r1 = Function '<anonymous closure>':.
    //     0xcedbc0: add             x1, PP, #0x37, lsl #12  ; [pp+0x371a0] Function: [dart:ui] Paint::_objects (0xd614f0)
    //     0xcedbc4: ldr             x1, [x1, #0x1a0]
    // 0xcedbc8: r2 = Null
    //     0xcedbc8: mov             x2, NULL
    // 0xcedbcc: r0 = AllocateClosure()
    //     0xcedbcc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcedbd0: r16 = <((dynamic this, ImageChunkEvent) => void?)?>
    //     0xcedbd0: add             x16, PP, #0x37, lsl #12  ; [pp+0x371a8] TypeArguments: <((dynamic this, ImageChunkEvent) => void?)?>
    //     0xcedbd4: ldr             x16, [x16, #0x1a8]
    // 0xcedbd8: ldur            lr, [fp, #-8]
    // 0xcedbdc: stp             lr, x16, [SP, #-0x10]!
    // 0xcedbe0: SaveReg r0
    //     0xcedbe0: str             x0, [SP, #-8]!
    // 0xcedbe4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcedbe4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcedbe8: r0 = map()
    //     0xcedbe8: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xcedbec: add             SP, SP, #0x18
    // 0xcedbf0: r16 = <(dynamic this, ImageChunkEvent) => void?>
    //     0xcedbf0: add             x16, PP, #0x37, lsl #12  ; [pp+0x371b0] TypeArguments: <(dynamic this, ImageChunkEvent) => void?>
    //     0xcedbf4: ldr             x16, [x16, #0x1b0]
    // 0xcedbf8: stp             x0, x16, [SP, #-0x10]!
    // 0xcedbfc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcedbfc: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcedc00: r0 = whereType()
    //     0xcedc00: bl              #0x6a7924  ; [dart:collection] _ListBase&Object&ListMixin::whereType
    // 0xcedc04: add             SP, SP, #0x10
    // 0xcedc08: SaveReg r0
    //     0xcedc08: str             x0, [SP, #-8]!
    // 0xcedc0c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcedc0c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcedc10: r0 = toList()
    //     0xcedc10: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xcedc14: add             SP, SP, #8
    // 0xcedc18: r1 = LoadClassIdInstr(r0)
    //     0xcedc18: ldur            x1, [x0, #-1]
    //     0xcedc1c: ubfx            x1, x1, #0xc, #0x14
    // 0xcedc20: SaveReg r0
    //     0xcedc20: str             x0, [SP, #-8]!
    // 0xcedc24: mov             x0, x1
    // 0xcedc28: r0 = GDT[cid_x0 + 0xb940]()
    //     0xcedc28: mov             x17, #0xb940
    //     0xcedc2c: add             lr, x0, x17
    //     0xcedc30: ldr             lr, [x21, lr, lsl #3]
    //     0xcedc34: blr             lr
    // 0xcedc38: add             SP, SP, #8
    // 0xcedc3c: mov             x1, x0
    // 0xcedc40: stur            x1, [fp, #-8]
    // 0xcedc44: CheckStackOverflow
    //     0xcedc44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcedc48: cmp             SP, x16
    //     0xcedc4c: b.ls            #0xcedcd0
    // 0xcedc50: r0 = LoadClassIdInstr(r1)
    //     0xcedc50: ldur            x0, [x1, #-1]
    //     0xcedc54: ubfx            x0, x0, #0xc, #0x14
    // 0xcedc58: SaveReg r1
    //     0xcedc58: str             x1, [SP, #-8]!
    // 0xcedc5c: r0 = GDT[cid_x0 + 0x541]()
    //     0xcedc5c: add             lr, x0, #0x541
    //     0xcedc60: ldr             lr, [x21, lr, lsl #3]
    //     0xcedc64: blr             lr
    // 0xcedc68: add             SP, SP, #8
    // 0xcedc6c: tbnz            w0, #4, #0xcedcb8
    // 0xcedc70: ldur            x1, [fp, #-8]
    // 0xcedc74: r0 = LoadClassIdInstr(r1)
    //     0xcedc74: ldur            x0, [x1, #-1]
    //     0xcedc78: ubfx            x0, x0, #0xc, #0x14
    // 0xcedc7c: SaveReg r1
    //     0xcedc7c: str             x1, [SP, #-8]!
    // 0xcedc80: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xcedc80: add             lr, x0, #0x5ca
    //     0xcedc84: ldr             lr, [x21, lr, lsl #3]
    //     0xcedc88: blr             lr
    // 0xcedc8c: add             SP, SP, #8
    // 0xcedc90: cmp             w0, NULL
    // 0xcedc94: b.eq            #0xcedcd8
    // 0xcedc98: ldr             x16, [fp, #0x10]
    // 0xcedc9c: stp             x16, x0, [SP, #-0x10]!
    // 0xcedca0: ClosureCall
    //     0xcedca0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcedca4: ldur            x2, [x0, #0x1f]
    //     0xcedca8: blr             x2
    // 0xcedcac: add             SP, SP, #0x10
    // 0xcedcb0: ldur            x1, [fp, #-8]
    // 0xcedcb4: b               #0xcedc44
    // 0xcedcb8: r0 = Null
    //     0xcedcb8: mov             x0, NULL
    // 0xcedcbc: LeaveFrame
    //     0xcedcbc: mov             SP, fp
    //     0xcedcc0: ldp             fp, lr, [SP], #0x10
    // 0xcedcc4: ret
    //     0xcedcc4: ret             
    // 0xcedcc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcedcc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcedccc: b               #0xcedb94
    // 0xcedcd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcedcd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcedcd4: b               #0xcedc50
    // 0xcedcd8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcedcd8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _maybeDispose(/* No info */) {
    // ** addr: 0xceddb0, size: 0xa8
    // 0xceddb0: EnterFrame
    //     0xceddb0: stp             fp, lr, [SP, #-0x10]!
    //     0xceddb4: mov             fp, SP
    // 0xceddb8: CheckStackOverflow
    //     0xceddb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xceddbc: cmp             SP, x16
    //     0xceddc0: b.ls            #0xcede50
    // 0xceddc4: ldr             x0, [fp, #0x10]
    // 0xceddc8: LoadField: r1 = r0->field_17
    //     0xceddc8: ldur            w1, [x0, #0x17]
    // 0xceddcc: DecompressPointer r1
    //     0xceddcc: add             x1, x1, HEAP, lsl #32
    // 0xceddd0: tbnz            w1, #4, #0xceddfc
    // 0xceddd4: LoadField: r1 = r0->field_27
    //     0xceddd4: ldur            w1, [x0, #0x27]
    // 0xceddd8: DecompressPointer r1
    //     0xceddd8: add             x1, x1, HEAP, lsl #32
    // 0xcedddc: tbz             w1, #4, #0xceddfc
    // 0xcedde0: LoadField: r1 = r0->field_7
    //     0xcedde0: ldur            w1, [x0, #7]
    // 0xcedde4: DecompressPointer r1
    //     0xcedde4: add             x1, x1, HEAP, lsl #32
    // 0xcedde8: LoadField: r2 = r1->field_b
    //     0xcedde8: ldur            w2, [x1, #0xb]
    // 0xceddec: DecompressPointer r2
    //     0xceddec: add             x2, x2, HEAP, lsl #32
    // 0xceddf0: cbnz            w2, #0xceddfc
    // 0xceddf4: LoadField: r1 = r0->field_1f
    //     0xceddf4: ldur            x1, [x0, #0x1f]
    // 0xceddf8: cbz             x1, #0xcede0c
    // 0xceddfc: r0 = Null
    //     0xceddfc: mov             x0, NULL
    // 0xcede00: LeaveFrame
    //     0xcede00: mov             SP, fp
    //     0xcede04: ldp             fp, lr, [SP], #0x10
    // 0xcede08: ret
    //     0xcede08: ret             
    // 0xcede0c: LoadField: r1 = r0->field_b
    //     0xcede0c: ldur            w1, [x0, #0xb]
    // 0xcede10: DecompressPointer r1
    //     0xcede10: add             x1, x1, HEAP, lsl #32
    // 0xcede14: cmp             w1, NULL
    // 0xcede18: b.ne            #0xcede24
    // 0xcede1c: mov             x1, x0
    // 0xcede20: b               #0xcede34
    // 0xcede24: SaveReg r1
    //     0xcede24: str             x1, [SP, #-8]!
    // 0xcede28: r0 = dispose()
    //     0xcede28: bl              #0x794180  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0xcede2c: add             SP, SP, #8
    // 0xcede30: ldr             x1, [fp, #0x10]
    // 0xcede34: r2 = true
    //     0xcede34: add             x2, NULL, #0x20  ; true
    // 0xcede38: StoreField: r1->field_b = rNULL
    //     0xcede38: stur            NULL, [x1, #0xb]
    // 0xcede3c: StoreField: r1->field_27 = r2
    //     0xcede3c: stur            w2, [x1, #0x27]
    // 0xcede40: r0 = Null
    //     0xcede40: mov             x0, NULL
    // 0xcede44: LeaveFrame
    //     0xcede44: mov             SP, fp
    //     0xcede48: ldp             fp, lr, [SP], #0x10
    // 0xcede4c: ret
    //     0xcede4c: ret             
    // 0xcede50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcede50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcede54: b               #0xceddc4
  }
  _ removeListener(/* No info */) {
    // ** addr: 0xcedf10, size: 0x2a4
    // 0xcedf10: EnterFrame
    //     0xcedf10: stp             fp, lr, [SP, #-0x10]!
    //     0xcedf14: mov             fp, SP
    // 0xcedf18: AllocStack(0x18)
    //     0xcedf18: sub             SP, SP, #0x18
    // 0xcedf1c: CheckStackOverflow
    //     0xcedf1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcedf20: cmp             SP, x16
    //     0xcedf24: b.ls            #0xcee194
    // 0xcedf28: ldr             x16, [fp, #0x18]
    // 0xcedf2c: SaveReg r16
    //     0xcedf2c: str             x16, [SP, #-8]!
    // 0xcedf30: r0 = _checkDisposed()
    //     0xcedf30: bl              #0xa4ee3c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_checkDisposed
    // 0xcedf34: add             SP, SP, #8
    // 0xcedf38: ldr             x2, [fp, #0x18]
    // 0xcedf3c: LoadField: r3 = r2->field_7
    //     0xcedf3c: ldur            w3, [x2, #7]
    // 0xcedf40: DecompressPointer r3
    //     0xcedf40: add             x3, x3, HEAP, lsl #32
    // 0xcedf44: stur            x3, [fp, #-0x10]
    // 0xcedf48: r4 = 0
    //     0xcedf48: mov             x4, #0
    // 0xcedf4c: stur            x4, [fp, #-8]
    // 0xcedf50: CheckStackOverflow
    //     0xcedf50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcedf54: cmp             SP, x16
    //     0xcedf58: b.ls            #0xcee19c
    // 0xcedf5c: LoadField: r0 = r3->field_b
    //     0xcedf5c: ldur            w0, [x3, #0xb]
    // 0xcedf60: DecompressPointer r0
    //     0xcedf60: add             x0, x0, HEAP, lsl #32
    // 0xcedf64: r1 = LoadInt32Instr(r0)
    //     0xcedf64: sbfx            x1, x0, #1, #0x1f
    // 0xcedf68: cmp             x4, x1
    // 0xcedf6c: b.ge            #0xcedfd4
    // 0xcedf70: mov             x0, x1
    // 0xcedf74: mov             x1, x4
    // 0xcedf78: cmp             x1, x0
    // 0xcedf7c: b.hs            #0xcee1a4
    // 0xcedf80: LoadField: r0 = r3->field_f
    //     0xcedf80: ldur            w0, [x3, #0xf]
    // 0xcedf84: DecompressPointer r0
    //     0xcedf84: add             x0, x0, HEAP, lsl #32
    // 0xcedf88: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xcedf88: add             x16, x0, x4, lsl #2
    //     0xcedf8c: ldur            w1, [x16, #0xf]
    // 0xcedf90: DecompressPointer r1
    //     0xcedf90: add             x1, x1, HEAP, lsl #32
    // 0xcedf94: ldr             x16, [fp, #0x10]
    // 0xcedf98: stp             x16, x1, [SP, #-0x10]!
    // 0xcedf9c: r0 = ==()
    //     0xcedf9c: bl              #0xc9dd58  ; [package:flutter/src/painting/image_stream.dart] ImageStreamListener::==
    // 0xcedfa0: add             SP, SP, #0x10
    // 0xcedfa4: tbnz            w0, #4, #0xcedfc0
    // 0xcedfa8: ldur            x0, [fp, #-8]
    // 0xcedfac: ldur            x16, [fp, #-0x10]
    // 0xcedfb0: stp             x0, x16, [SP, #-0x10]!
    // 0xcedfb4: r0 = removeAt()
    //     0xcedfb4: bl              #0x608dbc  ; [dart:core] _GrowableList::removeAt
    // 0xcedfb8: add             SP, SP, #0x10
    // 0xcedfbc: b               #0xcedfd4
    // 0xcedfc0: ldur            x0, [fp, #-8]
    // 0xcedfc4: add             x4, x0, #1
    // 0xcedfc8: ldr             x2, [fp, #0x18]
    // 0xcedfcc: ldur            x3, [fp, #-0x10]
    // 0xcedfd0: b               #0xcedf4c
    // 0xcedfd4: ldur            x0, [fp, #-0x10]
    // 0xcedfd8: LoadField: r1 = r0->field_b
    //     0xcedfd8: ldur            w1, [x0, #0xb]
    // 0xcedfdc: DecompressPointer r1
    //     0xcedfdc: add             x1, x1, HEAP, lsl #32
    // 0xcedfe0: cbnz            w1, #0xcee184
    // 0xcedfe4: ldr             x0, [fp, #0x18]
    // 0xcedfe8: LoadField: r1 = r0->field_2b
    //     0xcedfe8: ldur            w1, [x0, #0x2b]
    // 0xcedfec: DecompressPointer r1
    //     0xcedfec: add             x1, x1, HEAP, lsl #32
    // 0xcedff0: stur            x1, [fp, #-0x10]
    // 0xcedff4: SaveReg r1
    //     0xcedff4: str             x1, [SP, #-8]!
    // 0xcedff8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcedff8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcedffc: r0 = toList()
    //     0xcedffc: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0xcee000: add             SP, SP, #8
    // 0xcee004: r1 = LoadClassIdInstr(r0)
    //     0xcee004: ldur            x1, [x0, #-1]
    //     0xcee008: ubfx            x1, x1, #0xc, #0x14
    // 0xcee00c: SaveReg r0
    //     0xcee00c: str             x0, [SP, #-8]!
    // 0xcee010: mov             x0, x1
    // 0xcee014: r0 = GDT[cid_x0 + 0xb940]()
    //     0xcee014: mov             x17, #0xb940
    //     0xcee018: add             lr, x0, x17
    //     0xcee01c: ldr             lr, [x21, lr, lsl #3]
    //     0xcee020: blr             lr
    // 0xcee024: add             SP, SP, #8
    // 0xcee028: mov             x1, x0
    // 0xcee02c: stur            x1, [fp, #-0x18]
    // 0xcee030: CheckStackOverflow
    //     0xcee030: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee034: cmp             SP, x16
    //     0xcee038: b.ls            #0xcee1a8
    // 0xcee03c: r0 = LoadClassIdInstr(r1)
    //     0xcee03c: ldur            x0, [x1, #-1]
    //     0xcee040: ubfx            x0, x0, #0xc, #0x14
    // 0xcee044: SaveReg r1
    //     0xcee044: str             x1, [SP, #-8]!
    // 0xcee048: r0 = GDT[cid_x0 + 0x541]()
    //     0xcee048: add             lr, x0, #0x541
    //     0xcee04c: ldr             lr, [x21, lr, lsl #3]
    //     0xcee050: blr             lr
    // 0xcee054: add             SP, SP, #8
    // 0xcee058: tbnz            w0, #4, #0xcee0a0
    // 0xcee05c: ldur            x1, [fp, #-0x18]
    // 0xcee060: r0 = LoadClassIdInstr(r1)
    //     0xcee060: ldur            x0, [x1, #-1]
    //     0xcee064: ubfx            x0, x0, #0xc, #0x14
    // 0xcee068: SaveReg r1
    //     0xcee068: str             x1, [SP, #-8]!
    // 0xcee06c: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xcee06c: add             lr, x0, #0x5ca
    //     0xcee070: ldr             lr, [x21, lr, lsl #3]
    //     0xcee074: blr             lr
    // 0xcee078: add             SP, SP, #8
    // 0xcee07c: cmp             w0, NULL
    // 0xcee080: b.eq            #0xcee1b0
    // 0xcee084: SaveReg r0
    //     0xcee084: str             x0, [SP, #-8]!
    // 0xcee088: ClosureCall
    //     0xcee088: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xcee08c: ldur            x2, [x0, #0x1f]
    //     0xcee090: blr             x2
    // 0xcee094: add             SP, SP, #8
    // 0xcee098: ldur            x1, [fp, #-0x18]
    // 0xcee09c: b               #0xcee030
    // 0xcee0a0: ldr             x0, [fp, #0x18]
    // 0xcee0a4: ldur            x16, [fp, #-0x10]
    // 0xcee0a8: SaveReg r16
    //     0xcee0a8: str             x16, [SP, #-8]!
    // 0xcee0ac: r0 = clear()
    //     0xcee0ac: bl              #0xd281bc  ; [dart:core] _GrowableList::clear
    // 0xcee0b0: add             SP, SP, #8
    // 0xcee0b4: ldr             x0, [fp, #0x18]
    // 0xcee0b8: r1 = LoadClassIdInstr(r0)
    //     0xcee0b8: ldur            x1, [x0, #-1]
    //     0xcee0bc: ubfx            x1, x1, #0xc, #0x14
    // 0xcee0c0: lsl             x1, x1, #1
    // 0xcee0c4: r17 = 5422
    //     0xcee0c4: mov             x17, #0x152e
    // 0xcee0c8: cmp             w1, w17
    // 0xcee0cc: b.ne            #0xcee164
    // 0xcee0d0: SaveReg r0
    //     0xcee0d0: str             x0, [SP, #-8]!
    // 0xcee0d4: r0 = _maybeDispose()
    //     0xcee0d4: bl              #0xceddb0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_maybeDispose
    // 0xcee0d8: add             SP, SP, #8
    // 0xcee0dc: ldr             x1, [fp, #0x18]
    // 0xcee0e0: LoadField: r0 = r1->field_27
    //     0xcee0e0: ldur            w0, [x1, #0x27]
    // 0xcee0e4: DecompressPointer r0
    //     0xcee0e4: add             x0, x0, HEAP, lsl #32
    // 0xcee0e8: tbnz            w0, #4, #0xcee184
    // 0xcee0ec: LoadField: r0 = r1->field_2f
    //     0xcee0ec: ldur            w0, [x1, #0x2f]
    // 0xcee0f0: DecompressPointer r0
    //     0xcee0f0: add             x0, x0, HEAP, lsl #32
    // 0xcee0f4: cmp             w0, NULL
    // 0xcee0f8: b.eq            #0xcee120
    // 0xcee0fc: r2 = LoadClassIdInstr(r0)
    //     0xcee0fc: ldur            x2, [x0, #-1]
    //     0xcee100: ubfx            x2, x2, #0xc, #0x14
    // 0xcee104: stp             NULL, x0, [SP, #-0x10]!
    // 0xcee108: mov             x0, x2
    // 0xcee10c: r0 = GDT[cid_x0 + 0x396]()
    //     0xcee10c: add             lr, x0, #0x396
    //     0xcee110: ldr             lr, [x21, lr, lsl #3]
    //     0xcee114: blr             lr
    // 0xcee118: add             SP, SP, #0x10
    // 0xcee11c: ldr             x1, [fp, #0x18]
    // 0xcee120: LoadField: r0 = r1->field_2f
    //     0xcee120: ldur            w0, [x1, #0x2f]
    // 0xcee124: DecompressPointer r0
    //     0xcee124: add             x0, x0, HEAP, lsl #32
    // 0xcee128: cmp             w0, NULL
    // 0xcee12c: b.ne            #0xcee138
    // 0xcee130: mov             x0, x1
    // 0xcee134: b               #0xcee15c
    // 0xcee138: r2 = LoadClassIdInstr(r0)
    //     0xcee138: ldur            x2, [x0, #-1]
    //     0xcee13c: ubfx            x2, x2, #0xc, #0x14
    // 0xcee140: SaveReg r0
    //     0xcee140: str             x0, [SP, #-8]!
    // 0xcee144: mov             x0, x2
    // 0xcee148: r0 = GDT[cid_x0 + 0x307]()
    //     0xcee148: add             lr, x0, #0x307
    //     0xcee14c: ldr             lr, [x21, lr, lsl #3]
    //     0xcee150: blr             lr
    // 0xcee154: add             SP, SP, #8
    // 0xcee158: ldr             x0, [fp, #0x18]
    // 0xcee15c: StoreField: r0->field_2f = rNULL
    //     0xcee15c: stur            NULL, [x0, #0x2f]
    // 0xcee160: b               #0xcee184
    // 0xcee164: r1 = LoadClassIdInstr(r0)
    //     0xcee164: ldur            x1, [x0, #-1]
    //     0xcee168: ubfx            x1, x1, #0xc, #0x14
    // 0xcee16c: SaveReg r0
    //     0xcee16c: str             x0, [SP, #-8]!
    // 0xcee170: mov             x0, x1
    // 0xcee174: r0 = GDT[cid_x0 + -0xffe]()
    //     0xcee174: sub             lr, x0, #0xffe
    //     0xcee178: ldr             lr, [x21, lr, lsl #3]
    //     0xcee17c: blr             lr
    // 0xcee180: add             SP, SP, #8
    // 0xcee184: r0 = Null
    //     0xcee184: mov             x0, NULL
    // 0xcee188: LeaveFrame
    //     0xcee188: mov             SP, fp
    //     0xcee18c: ldp             fp, lr, [SP], #0x10
    // 0xcee190: ret
    //     0xcee190: ret             
    // 0xcee194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee194: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee198: b               #0xcedf28
    // 0xcee19c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee19c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee1a0: b               #0xcedf5c
    // 0xcee1a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcee1a4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcee1a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee1a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee1ac: b               #0xcee03c
    // 0xcee1b0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcee1b0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2711, size: 0x60, field offset: 0x30
class MultiFrameImageStreamCompleter extends ImageStreamCompleter {

  late Duration _shownTimestamp; // offset: 0x48

  [closure] void addListener(dynamic, ImageStreamListener) {
    // ** addr: 0x794d14, size: 0x4c
    // 0x794d14: EnterFrame
    //     0x794d14: stp             fp, lr, [SP, #-0x10]!
    //     0x794d18: mov             fp, SP
    // 0x794d1c: ldr             x0, [fp, #0x18]
    // 0x794d20: LoadField: r1 = r0->field_17
    //     0x794d20: ldur            w1, [x0, #0x17]
    // 0x794d24: DecompressPointer r1
    //     0x794d24: add             x1, x1, HEAP, lsl #32
    // 0x794d28: CheckStackOverflow
    //     0x794d28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794d2c: cmp             SP, x16
    //     0x794d30: b.ls            #0x794d58
    // 0x794d34: LoadField: r0 = r1->field_f
    //     0x794d34: ldur            w0, [x1, #0xf]
    // 0x794d38: DecompressPointer r0
    //     0x794d38: add             x0, x0, HEAP, lsl #32
    // 0x794d3c: ldr             x16, [fp, #0x10]
    // 0x794d40: stp             x16, x0, [SP, #-0x10]!
    // 0x794d44: r0 = addListener()
    //     0x794d44: bl              #0xcec6f8  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::addListener
    // 0x794d48: add             SP, SP, #0x10
    // 0x794d4c: LeaveFrame
    //     0x794d4c: mov             SP, fp
    //     0x794d50: ldp             fp, lr, [SP], #0x10
    // 0x794d54: ret
    //     0x794d54: ret             
    // 0x794d58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794d58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794d5c: b               #0x794d34
  }
  _ MultiFrameImageStreamCompleter(/* No info */) {
    // ** addr: 0xc30420, size: 0x2c0
    // 0xc30420: EnterFrame
    //     0xc30420: stp             fp, lr, [SP, #-0x10]!
    //     0xc30424: mov             fp, SP
    // 0xc30428: AllocStack(0x38)
    //     0xc30428: sub             SP, SP, #0x38
    // 0xc3042c: SetupParameters(MultiFrameImageStreamCompleter this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* d0, fp-0x38 */, {dynamic chunkEvents = Null /* r5, fp-0x18 */, dynamic debugLabel = Null /* r6, fp-0x10 */, dynamic informationCollector = Null /* r0, fp-0x8 */})
    //     0xc3042c: mov             x0, x4
    //     0xc30430: ldur            w1, [x0, #0x13]
    //     0xc30434: add             x1, x1, HEAP, lsl #32
    //     0xc30438: sub             x2, x1, #6
    //     0xc3043c: add             x3, fp, w2, sxtw #2
    //     0xc30440: ldr             x3, [x3, #0x20]
    //     0xc30444: stur            x3, [fp, #-0x28]
    //     0xc30448: add             x4, fp, w2, sxtw #2
    //     0xc3044c: ldr             x4, [x4, #0x18]
    //     0xc30450: stur            x4, [fp, #-0x20]
    //     0xc30454: add             x5, fp, w2, sxtw #2
    //     0xc30458: ldr             d0, [x5, #0x10]
    //     0xc3045c: stur            d0, [fp, #-0x38]
    //     0xc30460: ldur            w2, [x0, #0x1f]
    //     0xc30464: add             x2, x2, HEAP, lsl #32
    //     0xc30468: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2ca50] "chunkEvents"
    //     0xc3046c: ldr             x16, [x16, #0xa50]
    //     0xc30470: cmp             w2, w16
    //     0xc30474: b.ne            #0xc30498
    //     0xc30478: ldur            w2, [x0, #0x23]
    //     0xc3047c: add             x2, x2, HEAP, lsl #32
    //     0xc30480: sub             w5, w1, w2
    //     0xc30484: add             x2, fp, w5, sxtw #2
    //     0xc30488: ldr             x2, [x2, #8]
    //     0xc3048c: mov             x5, x2
    //     0xc30490: mov             x2, #1
    //     0xc30494: b               #0xc304a0
    //     0xc30498: mov             x5, NULL
    //     0xc3049c: mov             x2, #0
    //     0xc304a0: stur            x5, [fp, #-0x18]
    //     0xc304a4: lsl             x6, x2, #1
    //     0xc304a8: lsl             w7, w6, #1
    //     0xc304ac: add             w8, w7, #8
    //     0xc304b0: add             x16, x0, w8, sxtw #1
    //     0xc304b4: ldur            w9, [x16, #0xf]
    //     0xc304b8: add             x9, x9, HEAP, lsl #32
    //     0xc304bc: ldr             x16, [PP, #0x44b0]  ; [pp+0x44b0] "debugLabel"
    //     0xc304c0: cmp             w9, w16
    //     0xc304c4: b.ne            #0xc304f8
    //     0xc304c8: add             w2, w7, #0xa
    //     0xc304cc: add             x16, x0, w2, sxtw #1
    //     0xc304d0: ldur            w7, [x16, #0xf]
    //     0xc304d4: add             x7, x7, HEAP, lsl #32
    //     0xc304d8: sub             w2, w1, w7
    //     0xc304dc: add             x7, fp, w2, sxtw #2
    //     0xc304e0: ldr             x7, [x7, #8]
    //     0xc304e4: add             w2, w6, #2
    //     0xc304e8: sbfx            x6, x2, #1, #0x1f
    //     0xc304ec: mov             x2, x6
    //     0xc304f0: mov             x6, x7
    //     0xc304f4: b               #0xc304fc
    //     0xc304f8: mov             x6, NULL
    //     0xc304fc: stur            x6, [fp, #-0x10]
    //     0xc30500: lsl             x7, x2, #1
    //     0xc30504: lsl             w2, w7, #1
    //     0xc30508: add             w7, w2, #8
    //     0xc3050c: add             x16, x0, w7, sxtw #1
    //     0xc30510: ldur            w8, [x16, #0xf]
    //     0xc30514: add             x8, x8, HEAP, lsl #32
    //     0xc30518: ldr             x16, [PP, #0x3d48]  ; [pp+0x3d48] "informationCollector"
    //     0xc3051c: cmp             w8, w16
    //     0xc30520: b.ne            #0xc30548
    //     0xc30524: add             w7, w2, #0xa
    //     0xc30528: add             x16, x0, w7, sxtw #1
    //     0xc3052c: ldur            w2, [x16, #0xf]
    //     0xc30530: add             x2, x2, HEAP, lsl #32
    //     0xc30534: sub             w0, w1, w2
    //     0xc30538: add             x1, fp, w0, sxtw #2
    //     0xc3053c: ldr             x1, [x1, #8]
    //     0xc30540: mov             x0, x1
    //     0xc30544: b               #0xc3054c
    //     0xc30548: mov             x0, NULL
    //     0xc3054c: stur            x0, [fp, #-8]
    // 0xc30550: CheckStackOverflow
    //     0xc30550: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc30554: cmp             SP, x16
    //     0xc30558: b.ls            #0xc306d8
    // 0xc3055c: r1 = 2
    //     0xc3055c: mov             x1, #2
    // 0xc30560: r0 = AllocateContext()
    //     0xc30560: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc30564: mov             x2, x0
    // 0xc30568: ldur            x1, [fp, #-0x28]
    // 0xc3056c: stur            x2, [fp, #-0x30]
    // 0xc30570: StoreField: r2->field_f = r1
    //     0xc30570: stur            w1, [x2, #0xf]
    // 0xc30574: ldur            x0, [fp, #-8]
    // 0xc30578: StoreField: r2->field_13 = r0
    //     0xc30578: stur            w0, [x2, #0x13]
    // 0xc3057c: r3 = Sentinel
    //     0xc3057c: ldr             x3, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc30580: StoreField: r1->field_47 = r3
    //     0xc30580: stur            w3, [x1, #0x47]
    // 0xc30584: r3 = 0
    //     0xc30584: mov             x3, #0
    // 0xc30588: StoreField: r1->field_4f = r3
    //     0xc30588: stur            x3, [x1, #0x4f]
    // 0xc3058c: r3 = false
    //     0xc3058c: add             x3, NULL, #0x30  ; false
    // 0xc30590: StoreField: r1->field_5b = r3
    //     0xc30590: stur            w3, [x1, #0x5b]
    // 0xc30594: StoreField: r1->field_3f = r0
    //     0xc30594: stur            w0, [x1, #0x3f]
    //     0xc30598: ldurb           w16, [x1, #-1]
    //     0xc3059c: ldurb           w17, [x0, #-1]
    //     0xc305a0: and             x16, x17, x16, lsr #2
    //     0xc305a4: tst             x16, HEAP, lsr #32
    //     0xc305a8: b.eq            #0xc305b0
    //     0xc305ac: bl              #0xd6826c
    // 0xc305b0: ldur            d0, [fp, #-0x38]
    // 0xc305b4: StoreField: r1->field_37 = d0
    //     0xc305b4: stur            d0, [x1, #0x37]
    // 0xc305b8: SaveReg r1
    //     0xc305b8: str             x1, [SP, #-8]!
    // 0xc305bc: r0 = ImageStreamCompleter()
    //     0xc305bc: bl              #0x794d60  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::ImageStreamCompleter
    // 0xc305c0: add             SP, SP, #8
    // 0xc305c4: ldur            x0, [fp, #-0x10]
    // 0xc305c8: ldur            x1, [fp, #-0x28]
    // 0xc305cc: StoreField: r1->field_13 = r0
    //     0xc305cc: stur            w0, [x1, #0x13]
    //     0xc305d0: ldurb           w16, [x1, #-1]
    //     0xc305d4: ldurb           w17, [x0, #-1]
    //     0xc305d8: and             x16, x17, x16, lsr #2
    //     0xc305dc: tst             x16, HEAP, lsr #32
    //     0xc305e0: b.eq            #0xc305e8
    //     0xc305e4: bl              #0xd6826c
    // 0xc305e8: r0 = 59
    //     0xc305e8: mov             x0, #0x3b
    // 0xc305ec: branchIfSmi(r1, 0xc305f8)
    //     0xc305ec: tbz             w1, #0, #0xc305f8
    // 0xc305f0: r0 = LoadClassIdInstr(r1)
    //     0xc305f0: ldur            x0, [x1, #-1]
    //     0xc305f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc305f8: SaveReg r1
    //     0xc305f8: str             x1, [SP, #-8]!
    // 0xc305fc: r0 = GDT[cid_x0 + -0xffc]()
    //     0xc305fc: sub             lr, x0, #0xffc
    //     0xc30600: ldr             lr, [x21, lr, lsl #3]
    //     0xc30604: blr             lr
    // 0xc30608: add             SP, SP, #8
    // 0xc3060c: ldur            x2, [fp, #-0x30]
    // 0xc30610: r1 = Function '<anonymous closure>':.
    //     0xc30610: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2ca58] AnonymousClosure: (0xc30788), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter (0xc30420)
    //     0xc30614: ldr             x1, [x1, #0xa58]
    // 0xc30618: stur            x0, [fp, #-8]
    // 0xc3061c: r0 = AllocateClosure()
    //     0xc3061c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc30620: r16 = <void?>
    //     0xc30620: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc30624: ldur            lr, [fp, #-0x20]
    // 0xc30628: stp             lr, x16, [SP, #-0x10]!
    // 0xc3062c: ldur            x16, [fp, #-8]
    // 0xc30630: stp             x0, x16, [SP, #-0x10]!
    // 0xc30634: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xc30634: ldr             x4, [PP, #0x1a30]  ; [pp+0x1a30] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xc30638: r0 = then()
    //     0xc30638: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xc3063c: add             SP, SP, #0x20
    // 0xc30640: ldur            x1, [fp, #-0x18]
    // 0xc30644: cmp             w1, NULL
    // 0xc30648: b.eq            #0xc306c8
    // 0xc3064c: ldur            x2, [fp, #-0x28]
    // 0xc30650: r0 = 59
    //     0xc30650: mov             x0, #0x3b
    // 0xc30654: branchIfSmi(r2, 0xc30660)
    //     0xc30654: tbz             w2, #0, #0xc30660
    // 0xc30658: r0 = LoadClassIdInstr(r2)
    //     0xc30658: ldur            x0, [x2, #-1]
    //     0xc3065c: ubfx            x0, x0, #0xc, #0x14
    // 0xc30660: SaveReg r2
    //     0xc30660: str             x2, [SP, #-8]!
    // 0xc30664: r0 = GDT[cid_x0 + -0xff8]()
    //     0xc30664: sub             lr, x0, #0xff8
    //     0xc30668: ldr             lr, [x21, lr, lsl #3]
    //     0xc3066c: blr             lr
    // 0xc30670: add             SP, SP, #8
    // 0xc30674: ldur            x2, [fp, #-0x30]
    // 0xc30678: r1 = Function '<anonymous closure>':.
    //     0xc30678: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2ca60] AnonymousClosure: (0xc306e0), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter (0xc30420)
    //     0xc3067c: ldr             x1, [x1, #0xa60]
    // 0xc30680: stur            x0, [fp, #-8]
    // 0xc30684: r0 = AllocateClosure()
    //     0xc30684: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc30688: ldur            x16, [fp, #-0x18]
    // 0xc3068c: ldur            lr, [fp, #-8]
    // 0xc30690: stp             lr, x16, [SP, #-0x10]!
    // 0xc30694: SaveReg r0
    //     0xc30694: str             x0, [SP, #-8]!
    // 0xc30698: r4 = const [0, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xc30698: ldr             x4, [PP, #0x7bb0]  ; [pp+0x7bb0] List(7) [0, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xc3069c: r0 = listen()
    //     0xc3069c: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc306a0: add             SP, SP, #0x18
    // 0xc306a4: ldur            x1, [fp, #-0x28]
    // 0xc306a8: StoreField: r1->field_2f = r0
    //     0xc306a8: stur            w0, [x1, #0x2f]
    //     0xc306ac: tbz             w0, #0, #0xc306c8
    //     0xc306b0: ldurb           w16, [x1, #-1]
    //     0xc306b4: ldurb           w17, [x0, #-1]
    //     0xc306b8: and             x16, x17, x16, lsr #2
    //     0xc306bc: tst             x16, HEAP, lsr #32
    //     0xc306c0: b.eq            #0xc306c8
    //     0xc306c4: bl              #0xd6826c
    // 0xc306c8: r0 = Null
    //     0xc306c8: mov             x0, NULL
    // 0xc306cc: LeaveFrame
    //     0xc306cc: mov             SP, fp
    //     0xc306d0: ldp             fp, lr, [SP], #0x10
    // 0xc306d4: ret
    //     0xc306d4: ret             
    // 0xc306d8: r0 = StackOverflowSharedWithFPURegs()
    //     0xc306d8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc306dc: b               #0xc3055c
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xc306e0, size: 0xa8
    // 0xc306e0: EnterFrame
    //     0xc306e0: stp             fp, lr, [SP, #-0x10]!
    //     0xc306e4: mov             fp, SP
    // 0xc306e8: AllocStack(0x10)
    //     0xc306e8: sub             SP, SP, #0x10
    // 0xc306ec: SetupParameters()
    //     0xc306ec: ldr             x0, [fp, #0x20]
    //     0xc306f0: ldur            w2, [x0, #0x17]
    //     0xc306f4: add             x2, x2, HEAP, lsl #32
    //     0xc306f8: stur            x2, [fp, #-8]
    // 0xc306fc: CheckStackOverflow
    //     0xc306fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc30700: cmp             SP, x16
    //     0xc30704: b.ls            #0xc30780
    // 0xc30708: r1 = <List<Object>>
    //     0xc30708: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xc3070c: r0 = ErrorDescription()
    //     0xc3070c: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xc30710: stur            x0, [fp, #-0x10]
    // 0xc30714: r16 = "loading an image"
    //     0xc30714: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2ca68] "loading an image"
    //     0xc30718: ldr             x16, [x16, #0xa68]
    // 0xc3071c: stp             x16, x0, [SP, #-0x10]!
    // 0xc30720: r16 = Instance_DiagnosticLevel
    //     0xc30720: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xc30724: SaveReg r16
    //     0xc30724: str             x16, [SP, #-8]!
    // 0xc30728: r0 = _ErrorDiagnostic()
    //     0xc30728: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xc3072c: add             SP, SP, #0x18
    // 0xc30730: ldur            x0, [fp, #-8]
    // 0xc30734: LoadField: r1 = r0->field_13
    //     0xc30734: ldur            w1, [x0, #0x13]
    // 0xc30738: DecompressPointer r1
    //     0xc30738: add             x1, x1, HEAP, lsl #32
    // 0xc3073c: LoadField: r2 = r0->field_f
    //     0xc3073c: ldur            w2, [x0, #0xf]
    // 0xc30740: DecompressPointer r2
    //     0xc30740: add             x2, x2, HEAP, lsl #32
    // 0xc30744: ldur            x16, [fp, #-0x10]
    // 0xc30748: stp             x16, x2, [SP, #-0x10]!
    // 0xc3074c: ldr             x16, [fp, #0x18]
    // 0xc30750: ldr             lr, [fp, #0x10]
    // 0xc30754: stp             lr, x16, [SP, #-0x10]!
    // 0xc30758: r16 = true
    //     0xc30758: add             x16, NULL, #0x20  ; true
    // 0xc3075c: stp             x16, x1, [SP, #-0x10]!
    // 0xc30760: r4 = const [0, 0x6, 0x6, 0x4, informationCollector, 0x4, silent, 0x5, null]
    //     0xc30760: add             x4, PP, #0x27, lsl #12  ; [pp+0x27ee8] List(9) [0, 0x6, 0x6, 0x4, "informationCollector", 0x4, "silent", 0x5, Null]
    //     0xc30764: ldr             x4, [x4, #0xee8]
    // 0xc30768: r0 = reportError()
    //     0xc30768: bl              #0x794728  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xc3076c: add             SP, SP, #0x30
    // 0xc30770: r0 = Null
    //     0xc30770: mov             x0, NULL
    // 0xc30774: LeaveFrame
    //     0xc30774: mov             SP, fp
    //     0xc30778: ldp             fp, lr, [SP], #0x10
    // 0xc3077c: ret
    //     0xc3077c: ret             
    // 0xc30780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc30780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc30784: b               #0xc30708
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xc30788, size: 0xa8
    // 0xc30788: EnterFrame
    //     0xc30788: stp             fp, lr, [SP, #-0x10]!
    //     0xc3078c: mov             fp, SP
    // 0xc30790: AllocStack(0x10)
    //     0xc30790: sub             SP, SP, #0x10
    // 0xc30794: SetupParameters()
    //     0xc30794: ldr             x0, [fp, #0x20]
    //     0xc30798: ldur            w2, [x0, #0x17]
    //     0xc3079c: add             x2, x2, HEAP, lsl #32
    //     0xc307a0: stur            x2, [fp, #-8]
    // 0xc307a4: CheckStackOverflow
    //     0xc307a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc307a8: cmp             SP, x16
    //     0xc307ac: b.ls            #0xc30828
    // 0xc307b0: r1 = <List<Object>>
    //     0xc307b0: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xc307b4: r0 = ErrorDescription()
    //     0xc307b4: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xc307b8: stur            x0, [fp, #-0x10]
    // 0xc307bc: r16 = "resolving an image codec"
    //     0xc307bc: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2ca70] "resolving an image codec"
    //     0xc307c0: ldr             x16, [x16, #0xa70]
    // 0xc307c4: stp             x16, x0, [SP, #-0x10]!
    // 0xc307c8: r16 = Instance_DiagnosticLevel
    //     0xc307c8: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xc307cc: SaveReg r16
    //     0xc307cc: str             x16, [SP, #-8]!
    // 0xc307d0: r0 = _ErrorDiagnostic()
    //     0xc307d0: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xc307d4: add             SP, SP, #0x18
    // 0xc307d8: ldur            x0, [fp, #-8]
    // 0xc307dc: LoadField: r1 = r0->field_13
    //     0xc307dc: ldur            w1, [x0, #0x13]
    // 0xc307e0: DecompressPointer r1
    //     0xc307e0: add             x1, x1, HEAP, lsl #32
    // 0xc307e4: LoadField: r2 = r0->field_f
    //     0xc307e4: ldur            w2, [x0, #0xf]
    // 0xc307e8: DecompressPointer r2
    //     0xc307e8: add             x2, x2, HEAP, lsl #32
    // 0xc307ec: ldur            x16, [fp, #-0x10]
    // 0xc307f0: stp             x16, x2, [SP, #-0x10]!
    // 0xc307f4: ldr             x16, [fp, #0x18]
    // 0xc307f8: ldr             lr, [fp, #0x10]
    // 0xc307fc: stp             lr, x16, [SP, #-0x10]!
    // 0xc30800: r16 = true
    //     0xc30800: add             x16, NULL, #0x20  ; true
    // 0xc30804: stp             x16, x1, [SP, #-0x10]!
    // 0xc30808: r4 = const [0, 0x6, 0x6, 0x4, informationCollector, 0x4, silent, 0x5, null]
    //     0xc30808: add             x4, PP, #0x27, lsl #12  ; [pp+0x27ee8] List(9) [0, 0x6, 0x6, 0x4, "informationCollector", 0x4, "silent", 0x5, Null]
    //     0xc3080c: ldr             x4, [x4, #0xee8]
    // 0xc30810: r0 = reportError()
    //     0xc30810: bl              #0x794728  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xc30814: add             SP, SP, #0x30
    // 0xc30818: r0 = Null
    //     0xc30818: mov             x0, NULL
    // 0xc3081c: LeaveFrame
    //     0xc3081c: mov             SP, fp
    //     0xc30820: ldp             fp, lr, [SP], #0x10
    // 0xc30824: ret
    //     0xc30824: ret             
    // 0xc30828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc30828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3082c: b               #0xc307b0
  }
  _ addListener(/* No info */) {
    // ** addr: 0xcec6f8, size: 0x9c
    // 0xcec6f8: EnterFrame
    //     0xcec6f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcec6fc: mov             fp, SP
    // 0xcec700: CheckStackOverflow
    //     0xcec700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec704: cmp             SP, x16
    //     0xcec708: b.ls            #0xcec78c
    // 0xcec70c: ldr             x0, [fp, #0x18]
    // 0xcec710: LoadField: r1 = r0->field_7
    //     0xcec710: ldur            w1, [x0, #7]
    // 0xcec714: DecompressPointer r1
    //     0xcec714: add             x1, x1, HEAP, lsl #32
    // 0xcec718: LoadField: r2 = r1->field_b
    //     0xcec718: ldur            w2, [x1, #0xb]
    // 0xcec71c: DecompressPointer r2
    //     0xcec71c: add             x2, x2, HEAP, lsl #32
    // 0xcec720: cbnz            w2, #0xcec768
    // 0xcec724: LoadField: r1 = r0->field_33
    //     0xcec724: ldur            w1, [x0, #0x33]
    // 0xcec728: DecompressPointer r1
    //     0xcec728: add             x1, x1, HEAP, lsl #32
    // 0xcec72c: cmp             w1, NULL
    // 0xcec730: b.eq            #0xcec768
    // 0xcec734: LoadField: r2 = r0->field_b
    //     0xcec734: ldur            w2, [x0, #0xb]
    // 0xcec738: DecompressPointer r2
    //     0xcec738: add             x2, x2, HEAP, lsl #32
    // 0xcec73c: cmp             w2, NULL
    // 0xcec740: b.eq            #0xcec758
    // 0xcec744: SaveReg r1
    //     0xcec744: str             x1, [SP, #-8]!
    // 0xcec748: r0 = frameCount()
    //     0xcec748: bl              #0xced8e8  ; [dart:ui] Codec::frameCount
    // 0xcec74c: add             SP, SP, #8
    // 0xcec750: cmp             x0, #1
    // 0xcec754: b.le            #0xcec768
    // 0xcec758: ldr             x16, [fp, #0x18]
    // 0xcec75c: SaveReg r16
    //     0xcec75c: str             x16, [SP, #-8]!
    // 0xcec760: r0 = _decodeNextFrameAndSchedule()
    //     0xcec760: bl              #0xcec794  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0xcec764: add             SP, SP, #8
    // 0xcec768: ldr             x16, [fp, #0x18]
    // 0xcec76c: ldr             lr, [fp, #0x10]
    // 0xcec770: stp             lr, x16, [SP, #-0x10]!
    // 0xcec774: r0 = addListener()
    //     0xcec774: bl              #0xcec384  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener
    // 0xcec778: add             SP, SP, #0x10
    // 0xcec77c: r0 = Null
    //     0xcec77c: mov             x0, NULL
    // 0xcec780: LeaveFrame
    //     0xcec780: mov             SP, fp
    //     0xcec784: ldp             fp, lr, [SP], #0x10
    // 0xcec788: ret
    //     0xcec788: ret             
    // 0xcec78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcec78c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcec790: b               #0xcec70c
  }
  _ _decodeNextFrameAndSchedule(/* No info */) async {
    // ** addr: 0xcec794, size: 0x24c
    // 0xcec794: EnterFrame
    //     0xcec794: stp             fp, lr, [SP, #-0x10]!
    //     0xcec798: mov             fp, SP
    // 0xcec79c: AllocStack(0x80)
    //     0xcec79c: sub             SP, SP, #0x80
    // 0xcec7a0: SetupParameters(MultiFrameImageStreamCompleter this /* r1, fp-0x68 */)
    //     0xcec7a0: stur            NULL, [fp, #-8]
    //     0xcec7a4: mov             x0, #0
    //     0xcec7a8: add             x1, fp, w0, sxtw #2
    //     0xcec7ac: ldr             x1, [x1, #0x10]
    //     0xcec7b0: stur            x1, [fp, #-0x68]
    // 0xcec7b4: CheckStackOverflow
    //     0xcec7b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec7b8: cmp             SP, x16
    //     0xcec7bc: b.ls            #0xcec9c8
    // 0xcec7c0: InitAsync() -> Future<void?>
    //     0xcec7c0: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xcec7c4: bl              #0x4b92e4
    // 0xcec7c8: ldur            x0, [fp, #-0x68]
    // 0xcec7cc: LoadField: r1 = r0->field_43
    //     0xcec7cc: ldur            w1, [x0, #0x43]
    // 0xcec7d0: DecompressPointer r1
    //     0xcec7d0: add             x1, x1, HEAP, lsl #32
    // 0xcec7d4: cmp             w1, NULL
    // 0xcec7d8: b.eq            #0xcec7f4
    // 0xcec7dc: LoadField: r2 = r1->field_b
    //     0xcec7dc: ldur            w2, [x1, #0xb]
    // 0xcec7e0: DecompressPointer r2
    //     0xcec7e0: add             x2, x2, HEAP, lsl #32
    // 0xcec7e4: SaveReg r2
    //     0xcec7e4: str             x2, [SP, #-8]!
    // 0xcec7e8: r0 = dispose()
    //     0xcec7e8: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0xcec7ec: add             SP, SP, #8
    // 0xcec7f0: ldur            x0, [fp, #-0x68]
    // 0xcec7f4: StoreField: r0->field_43 = rNULL
    //     0xcec7f4: stur            NULL, [x0, #0x43]
    // 0xcec7f8: LoadField: r1 = r0->field_33
    //     0xcec7f8: ldur            w1, [x0, #0x33]
    // 0xcec7fc: DecompressPointer r1
    //     0xcec7fc: add             x1, x1, HEAP, lsl #32
    // 0xcec800: cmp             w1, NULL
    // 0xcec804: b.eq            #0xcec9d0
    // 0xcec808: SaveReg r1
    //     0xcec808: str             x1, [SP, #-8]!
    // 0xcec80c: r0 = getNextFrame()
    //     0xcec80c: bl              #0xced340  ; [dart:ui] Codec::getNextFrame
    // 0xcec810: add             SP, SP, #8
    // 0xcec814: mov             x1, x0
    // 0xcec818: stur            x1, [fp, #-0x70]
    // 0xcec81c: r0 = Await()
    //     0xcec81c: bl              #0x4b8e6c  ; AwaitStub
    // 0xcec820: ldur            x1, [fp, #-0x68]
    // 0xcec824: StoreField: r1->field_43 = r0
    //     0xcec824: stur            w0, [x1, #0x43]
    //     0xcec828: tbz             w0, #0, #0xcec844
    //     0xcec82c: ldurb           w16, [x1, #-1]
    //     0xcec830: ldurb           w17, [x0, #-1]
    //     0xcec834: and             x16, x17, x16, lsr #2
    //     0xcec838: tst             x16, HEAP, lsr #32
    //     0xcec83c: b.eq            #0xcec844
    //     0xcec840: bl              #0xd6826c
    // 0xcec844: LoadField: r0 = r1->field_33
    //     0xcec844: ldur            w0, [x1, #0x33]
    // 0xcec848: DecompressPointer r0
    //     0xcec848: add             x0, x0, HEAP, lsl #32
    // 0xcec84c: cmp             w0, NULL
    // 0xcec850: b.eq            #0xcec9d4
    // 0xcec854: SaveReg r0
    //     0xcec854: str             x0, [SP, #-8]!
    // 0xcec858: r0 = frameCount()
    //     0xcec858: bl              #0xced8e8  ; [dart:ui] Codec::frameCount
    // 0xcec85c: add             SP, SP, #8
    // 0xcec860: cmp             x0, #1
    // 0xcec864: b.ne            #0xcec934
    // 0xcec868: ldur            x0, [fp, #-0x68]
    // 0xcec86c: LoadField: r1 = r0->field_7
    //     0xcec86c: ldur            w1, [x0, #7]
    // 0xcec870: DecompressPointer r1
    //     0xcec870: add             x1, x1, HEAP, lsl #32
    // 0xcec874: LoadField: r2 = r1->field_b
    //     0xcec874: ldur            w2, [x1, #0xb]
    // 0xcec878: DecompressPointer r2
    //     0xcec878: add             x2, x2, HEAP, lsl #32
    // 0xcec87c: cbnz            w2, #0xcec888
    // 0xcec880: r0 = Null
    //     0xcec880: mov             x0, NULL
    // 0xcec884: r0 = ReturnAsyncNotFuture()
    //     0xcec884: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xcec888: LoadField: r1 = r0->field_43
    //     0xcec888: ldur            w1, [x0, #0x43]
    // 0xcec88c: DecompressPointer r1
    //     0xcec88c: add             x1, x1, HEAP, lsl #32
    // 0xcec890: cmp             w1, NULL
    // 0xcec894: b.eq            #0xcec9d8
    // 0xcec898: LoadField: r2 = r1->field_b
    //     0xcec898: ldur            w2, [x1, #0xb]
    // 0xcec89c: DecompressPointer r2
    //     0xcec89c: add             x2, x2, HEAP, lsl #32
    // 0xcec8a0: SaveReg r2
    //     0xcec8a0: str             x2, [SP, #-8]!
    // 0xcec8a4: r0 = clone()
    //     0xcec8a4: bl              #0x6ca4f0  ; [dart:ui] Image::clone
    // 0xcec8a8: add             SP, SP, #8
    // 0xcec8ac: mov             x1, x0
    // 0xcec8b0: ldur            x0, [fp, #-0x68]
    // 0xcec8b4: stur            x1, [fp, #-0x78]
    // 0xcec8b8: LoadField: d0 = r0->field_37
    //     0xcec8b8: ldur            d0, [x0, #0x37]
    // 0xcec8bc: stur            d0, [fp, #-0x80]
    // 0xcec8c0: LoadField: r2 = r0->field_13
    //     0xcec8c0: ldur            w2, [x0, #0x13]
    // 0xcec8c4: DecompressPointer r2
    //     0xcec8c4: add             x2, x2, HEAP, lsl #32
    // 0xcec8c8: stur            x2, [fp, #-0x70]
    // 0xcec8cc: r0 = ImageInfo()
    //     0xcec8cc: bl              #0xcec6ec  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xcec8d0: mov             x1, x0
    // 0xcec8d4: ldur            x0, [fp, #-0x78]
    // 0xcec8d8: StoreField: r1->field_7 = r0
    //     0xcec8d8: stur            w0, [x1, #7]
    // 0xcec8dc: ldur            d0, [fp, #-0x80]
    // 0xcec8e0: StoreField: r1->field_b = d0
    //     0xcec8e0: stur            d0, [x1, #0xb]
    // 0xcec8e4: ldur            x0, [fp, #-0x70]
    // 0xcec8e8: StoreField: r1->field_13 = r0
    //     0xcec8e8: stur            w0, [x1, #0x13]
    // 0xcec8ec: ldur            x16, [fp, #-0x68]
    // 0xcec8f0: stp             x1, x16, [SP, #-0x10]!
    // 0xcec8f4: r0 = _emitFrame()
    //     0xcec8f4: bl              #0xced0dc  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_emitFrame
    // 0xcec8f8: add             SP, SP, #0x10
    // 0xcec8fc: ldur            x0, [fp, #-0x68]
    // 0xcec900: LoadField: r1 = r0->field_43
    //     0xcec900: ldur            w1, [x0, #0x43]
    // 0xcec904: DecompressPointer r1
    //     0xcec904: add             x1, x1, HEAP, lsl #32
    // 0xcec908: cmp             w1, NULL
    // 0xcec90c: b.eq            #0xcec9dc
    // 0xcec910: LoadField: r2 = r1->field_b
    //     0xcec910: ldur            w2, [x1, #0xb]
    // 0xcec914: DecompressPointer r2
    //     0xcec914: add             x2, x2, HEAP, lsl #32
    // 0xcec918: SaveReg r2
    //     0xcec918: str             x2, [SP, #-8]!
    // 0xcec91c: r0 = dispose()
    //     0xcec91c: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0xcec920: add             SP, SP, #8
    // 0xcec924: ldur            x0, [fp, #-0x68]
    // 0xcec928: StoreField: r0->field_43 = rNULL
    //     0xcec928: stur            NULL, [x0, #0x43]
    // 0xcec92c: r0 = Null
    //     0xcec92c: mov             x0, NULL
    // 0xcec930: r0 = ReturnAsyncNotFuture()
    //     0xcec930: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xcec934: ldur            x0, [fp, #-0x68]
    // 0xcec938: SaveReg r0
    //     0xcec938: str             x0, [SP, #-8]!
    // 0xcec93c: r0 = _scheduleAppFrame()
    //     0xcec93c: bl              #0xcec9e0  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_scheduleAppFrame
    // 0xcec940: add             SP, SP, #8
    // 0xcec944: r0 = Null
    //     0xcec944: mov             x0, NULL
    // 0xcec948: r0 = ReturnAsyncNotFuture()
    //     0xcec948: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xcec94c: sub             SP, fp, #0x80
    // 0xcec950: mov             x2, x0
    // 0xcec954: stur            x0, [fp, #-0x68]
    // 0xcec958: mov             x0, x1
    // 0xcec95c: stur            x1, [fp, #-0x70]
    // 0xcec960: r1 = <List<Object>>
    //     0xcec960: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xcec964: r0 = ErrorDescription()
    //     0xcec964: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xcec968: stur            x0, [fp, #-0x78]
    // 0xcec96c: r16 = "resolving an image frame"
    //     0xcec96c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27ee0] "resolving an image frame"
    //     0xcec970: ldr             x16, [x16, #0xee0]
    // 0xcec974: stp             x16, x0, [SP, #-0x10]!
    // 0xcec978: r16 = Instance_DiagnosticLevel
    //     0xcec978: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xcec97c: SaveReg r16
    //     0xcec97c: str             x16, [SP, #-8]!
    // 0xcec980: r0 = _ErrorDiagnostic()
    //     0xcec980: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xcec984: add             SP, SP, #0x18
    // 0xcec988: ldur            x0, [fp, #-0x10]
    // 0xcec98c: LoadField: r1 = r0->field_3f
    //     0xcec98c: ldur            w1, [x0, #0x3f]
    // 0xcec990: DecompressPointer r1
    //     0xcec990: add             x1, x1, HEAP, lsl #32
    // 0xcec994: ldur            x16, [fp, #-0x78]
    // 0xcec998: stp             x16, x0, [SP, #-0x10]!
    // 0xcec99c: ldur            x16, [fp, #-0x68]
    // 0xcec9a0: ldur            lr, [fp, #-0x70]
    // 0xcec9a4: stp             lr, x16, [SP, #-0x10]!
    // 0xcec9a8: r16 = true
    //     0xcec9a8: add             x16, NULL, #0x20  ; true
    // 0xcec9ac: stp             x16, x1, [SP, #-0x10]!
    // 0xcec9b0: r4 = const [0, 0x6, 0x6, 0x4, informationCollector, 0x4, silent, 0x5, null]
    //     0xcec9b0: add             x4, PP, #0x27, lsl #12  ; [pp+0x27ee8] List(9) [0, 0x6, 0x6, 0x4, "informationCollector", 0x4, "silent", 0x5, Null]
    //     0xcec9b4: ldr             x4, [x4, #0xee8]
    // 0xcec9b8: r0 = reportError()
    //     0xcec9b8: bl              #0x794728  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xcec9bc: add             SP, SP, #0x30
    // 0xcec9c0: r0 = Null
    //     0xcec9c0: mov             x0, NULL
    // 0xcec9c4: r0 = ReturnAsyncNotFuture()
    //     0xcec9c4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xcec9c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcec9c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcec9cc: b               #0xcec7c0
    // 0xcec9d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcec9d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcec9d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcec9d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcec9d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcec9d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcec9dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcec9dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _scheduleAppFrame(/* No info */) {
    // ** addr: 0xcec9e0, size: 0xa4
    // 0xcec9e0: EnterFrame
    //     0xcec9e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcec9e4: mov             fp, SP
    // 0xcec9e8: AllocStack(0x8)
    //     0xcec9e8: sub             SP, SP, #8
    // 0xcec9ec: CheckStackOverflow
    //     0xcec9ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec9f0: cmp             SP, x16
    //     0xcec9f4: b.ls            #0xceca78
    // 0xcec9f8: ldr             x0, [fp, #0x10]
    // 0xcec9fc: LoadField: r1 = r0->field_5b
    //     0xcec9fc: ldur            w1, [x0, #0x5b]
    // 0xceca00: DecompressPointer r1
    //     0xceca00: add             x1, x1, HEAP, lsl #32
    // 0xceca04: tbnz            w1, #4, #0xceca18
    // 0xceca08: r0 = Null
    //     0xceca08: mov             x0, NULL
    // 0xceca0c: LeaveFrame
    //     0xceca0c: mov             SP, fp
    //     0xceca10: ldp             fp, lr, [SP], #0x10
    // 0xceca14: ret
    //     0xceca14: ret             
    // 0xceca18: r1 = true
    //     0xceca18: add             x1, NULL, #0x20  ; true
    // 0xceca1c: StoreField: r0->field_5b = r1
    //     0xceca1c: stur            w1, [x0, #0x5b]
    // 0xceca20: r1 = LoadStaticField(0xf10)
    //     0xceca20: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xceca24: ldr             x1, [x1, #0x1e20]
    // 0xceca28: stur            x1, [fp, #-8]
    // 0xceca2c: cmp             w1, NULL
    // 0xceca30: b.eq            #0xceca80
    // 0xceca34: r1 = 1
    //     0xceca34: mov             x1, #1
    // 0xceca38: r0 = AllocateContext()
    //     0xceca38: bl              #0xd68aa4  ; AllocateContextStub
    // 0xceca3c: mov             x1, x0
    // 0xceca40: ldr             x0, [fp, #0x10]
    // 0xceca44: StoreField: r1->field_f = r0
    //     0xceca44: stur            w0, [x1, #0xf]
    // 0xceca48: mov             x2, x1
    // 0xceca4c: r1 = Function '_handleAppFrame@866483930':.
    //     0xceca4c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ef0] AnonymousClosure: (0xceca84), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleAppFrame (0xcecad0)
    //     0xceca50: ldr             x1, [x1, #0xef0]
    // 0xceca54: r0 = AllocateClosure()
    //     0xceca54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xceca58: ldur            x16, [fp, #-8]
    // 0xceca5c: stp             x0, x16, [SP, #-0x10]!
    // 0xceca60: r0 = scheduleFrameCallback()
    //     0xceca60: bl              #0x591c08  ; [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding::scheduleFrameCallback
    // 0xceca64: add             SP, SP, #0x10
    // 0xceca68: r0 = Null
    //     0xceca68: mov             x0, NULL
    // 0xceca6c: LeaveFrame
    //     0xceca6c: mov             SP, fp
    //     0xceca70: ldp             fp, lr, [SP], #0x10
    // 0xceca74: ret
    //     0xceca74: ret             
    // 0xceca78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceca78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceca7c: b               #0xcec9f8
    // 0xceca80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xceca80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleAppFrame(dynamic, Duration) {
    // ** addr: 0xceca84, size: 0x4c
    // 0xceca84: EnterFrame
    //     0xceca84: stp             fp, lr, [SP, #-0x10]!
    //     0xceca88: mov             fp, SP
    // 0xceca8c: ldr             x0, [fp, #0x18]
    // 0xceca90: LoadField: r1 = r0->field_17
    //     0xceca90: ldur            w1, [x0, #0x17]
    // 0xceca94: DecompressPointer r1
    //     0xceca94: add             x1, x1, HEAP, lsl #32
    // 0xceca98: CheckStackOverflow
    //     0xceca98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xceca9c: cmp             SP, x16
    //     0xcecaa0: b.ls            #0xcecac8
    // 0xcecaa4: LoadField: r0 = r1->field_f
    //     0xcecaa4: ldur            w0, [x1, #0xf]
    // 0xcecaa8: DecompressPointer r0
    //     0xcecaa8: add             x0, x0, HEAP, lsl #32
    // 0xcecaac: ldr             x16, [fp, #0x10]
    // 0xcecab0: stp             x16, x0, [SP, #-0x10]!
    // 0xcecab4: r0 = _handleAppFrame()
    //     0xcecab4: bl              #0xcecad0  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleAppFrame
    // 0xcecab8: add             SP, SP, #0x10
    // 0xcecabc: LeaveFrame
    //     0xcecabc: mov             SP, fp
    //     0xcecac0: ldp             fp, lr, [SP], #0x10
    // 0xcecac4: ret
    //     0xcecac4: ret             
    // 0xcecac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcecac8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcecacc: b               #0xcecaa4
  }
  _ _handleAppFrame(/* No info */) {
    // ** addr: 0xcecad0, size: 0x320
    // 0xcecad0: EnterFrame
    //     0xcecad0: stp             fp, lr, [SP, #-0x10]!
    //     0xcecad4: mov             fp, SP
    // 0xcecad8: AllocStack(0x30)
    //     0xcecad8: sub             SP, SP, #0x30
    // 0xcecadc: CheckStackOverflow
    //     0xcecadc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcecae0: cmp             SP, x16
    //     0xcecae4: b.ls            #0xcecdac
    // 0xcecae8: r1 = 1
    //     0xcecae8: mov             x1, #1
    // 0xcecaec: r0 = AllocateContext()
    //     0xcecaec: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcecaf0: mov             x1, x0
    // 0xcecaf4: ldr             x0, [fp, #0x18]
    // 0xcecaf8: stur            x1, [fp, #-8]
    // 0xcecafc: StoreField: r1->field_f = r0
    //     0xcecafc: stur            w0, [x1, #0xf]
    // 0xcecb00: r2 = false
    //     0xcecb00: add             x2, NULL, #0x30  ; false
    // 0xcecb04: StoreField: r0->field_5b = r2
    //     0xcecb04: stur            w2, [x0, #0x5b]
    // 0xcecb08: LoadField: r2 = r0->field_7
    //     0xcecb08: ldur            w2, [x0, #7]
    // 0xcecb0c: DecompressPointer r2
    //     0xcecb0c: add             x2, x2, HEAP, lsl #32
    // 0xcecb10: LoadField: r3 = r2->field_b
    //     0xcecb10: ldur            w3, [x2, #0xb]
    // 0xcecb14: DecompressPointer r3
    //     0xcecb14: add             x3, x3, HEAP, lsl #32
    // 0xcecb18: cbnz            w3, #0xcecb2c
    // 0xcecb1c: r0 = Null
    //     0xcecb1c: mov             x0, NULL
    // 0xcecb20: LeaveFrame
    //     0xcecb20: mov             SP, fp
    //     0xcecb24: ldp             fp, lr, [SP], #0x10
    // 0xcecb28: ret
    //     0xcecb28: ret             
    // 0xcecb2c: LoadField: r2 = r0->field_4b
    //     0xcecb2c: ldur            w2, [x0, #0x4b]
    // 0xcecb30: DecompressPointer r2
    //     0xcecb30: add             x2, x2, HEAP, lsl #32
    // 0xcecb34: cmp             w2, NULL
    // 0xcecb38: b.eq            #0xcecb54
    // 0xcecb3c: ldr             x16, [fp, #0x10]
    // 0xcecb40: stp             x16, x0, [SP, #-0x10]!
    // 0xcecb44: r0 = _hasFrameDurationPassed()
    //     0xcecb44: bl              #0xced020  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_hasFrameDurationPassed
    // 0xcecb48: add             SP, SP, #0x10
    // 0xcecb4c: tbnz            w0, #4, #0xceccf0
    // 0xcecb50: ldr             x0, [fp, #0x18]
    // 0xcecb54: LoadField: r1 = r0->field_43
    //     0xcecb54: ldur            w1, [x0, #0x43]
    // 0xcecb58: DecompressPointer r1
    //     0xcecb58: add             x1, x1, HEAP, lsl #32
    // 0xcecb5c: cmp             w1, NULL
    // 0xcecb60: b.eq            #0xcecdb4
    // 0xcecb64: LoadField: r2 = r1->field_b
    //     0xcecb64: ldur            w2, [x1, #0xb]
    // 0xcecb68: DecompressPointer r2
    //     0xcecb68: add             x2, x2, HEAP, lsl #32
    // 0xcecb6c: SaveReg r2
    //     0xcecb6c: str             x2, [SP, #-8]!
    // 0xcecb70: r0 = clone()
    //     0xcecb70: bl              #0x6ca4f0  ; [dart:ui] Image::clone
    // 0xcecb74: add             SP, SP, #8
    // 0xcecb78: mov             x1, x0
    // 0xcecb7c: ldr             x0, [fp, #0x18]
    // 0xcecb80: stur            x1, [fp, #-0x18]
    // 0xcecb84: LoadField: d0 = r0->field_37
    //     0xcecb84: ldur            d0, [x0, #0x37]
    // 0xcecb88: stur            d0, [fp, #-0x30]
    // 0xcecb8c: LoadField: r2 = r0->field_13
    //     0xcecb8c: ldur            w2, [x0, #0x13]
    // 0xcecb90: DecompressPointer r2
    //     0xcecb90: add             x2, x2, HEAP, lsl #32
    // 0xcecb94: stur            x2, [fp, #-0x10]
    // 0xcecb98: r0 = ImageInfo()
    //     0xcecb98: bl              #0xcec6ec  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xcecb9c: mov             x1, x0
    // 0xcecba0: ldur            x0, [fp, #-0x18]
    // 0xcecba4: StoreField: r1->field_7 = r0
    //     0xcecba4: stur            w0, [x1, #7]
    // 0xcecba8: ldur            d0, [fp, #-0x30]
    // 0xcecbac: StoreField: r1->field_b = d0
    //     0xcecbac: stur            d0, [x1, #0xb]
    // 0xcecbb0: ldur            x0, [fp, #-0x10]
    // 0xcecbb4: StoreField: r1->field_13 = r0
    //     0xcecbb4: stur            w0, [x1, #0x13]
    // 0xcecbb8: ldr             x16, [fp, #0x18]
    // 0xcecbbc: stp             x1, x16, [SP, #-0x10]!
    // 0xcecbc0: r0 = _emitFrame()
    //     0xcecbc0: bl              #0xced0dc  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_emitFrame
    // 0xcecbc4: add             SP, SP, #0x10
    // 0xcecbc8: ldr             x0, [fp, #0x10]
    // 0xcecbcc: ldr             x1, [fp, #0x18]
    // 0xcecbd0: StoreField: r1->field_47 = r0
    //     0xcecbd0: stur            w0, [x1, #0x47]
    //     0xcecbd4: ldurb           w16, [x1, #-1]
    //     0xcecbd8: ldurb           w17, [x0, #-1]
    //     0xcecbdc: and             x16, x17, x16, lsr #2
    //     0xcecbe0: tst             x16, HEAP, lsr #32
    //     0xcecbe4: b.eq            #0xcecbec
    //     0xcecbe8: bl              #0xd6826c
    // 0xcecbec: LoadField: r2 = r1->field_43
    //     0xcecbec: ldur            w2, [x1, #0x43]
    // 0xcecbf0: DecompressPointer r2
    //     0xcecbf0: add             x2, x2, HEAP, lsl #32
    // 0xcecbf4: cmp             w2, NULL
    // 0xcecbf8: b.eq            #0xcecdb8
    // 0xcecbfc: LoadField: r0 = r2->field_7
    //     0xcecbfc: ldur            w0, [x2, #7]
    // 0xcecc00: DecompressPointer r0
    //     0xcecc00: add             x0, x0, HEAP, lsl #32
    // 0xcecc04: StoreField: r1->field_4b = r0
    //     0xcecc04: stur            w0, [x1, #0x4b]
    //     0xcecc08: ldurb           w16, [x1, #-1]
    //     0xcecc0c: ldurb           w17, [x0, #-1]
    //     0xcecc10: and             x16, x17, x16, lsr #2
    //     0xcecc14: tst             x16, HEAP, lsr #32
    //     0xcecc18: b.eq            #0xcecc20
    //     0xcecc1c: bl              #0xd6826c
    // 0xcecc20: LoadField: r0 = r2->field_b
    //     0xcecc20: ldur            w0, [x2, #0xb]
    // 0xcecc24: DecompressPointer r0
    //     0xcecc24: add             x0, x0, HEAP, lsl #32
    // 0xcecc28: SaveReg r0
    //     0xcecc28: str             x0, [SP, #-8]!
    // 0xcecc2c: r0 = dispose()
    //     0xcecc2c: bl              #0x6522a4  ; [dart:ui] Image::dispose
    // 0xcecc30: add             SP, SP, #8
    // 0xcecc34: ldr             x0, [fp, #0x18]
    // 0xcecc38: StoreField: r0->field_43 = rNULL
    //     0xcecc38: stur            NULL, [x0, #0x43]
    // 0xcecc3c: LoadField: r1 = r0->field_4f
    //     0xcecc3c: ldur            x1, [x0, #0x4f]
    // 0xcecc40: stur            x1, [fp, #-0x20]
    // 0xcecc44: LoadField: r2 = r0->field_33
    //     0xcecc44: ldur            w2, [x0, #0x33]
    // 0xcecc48: DecompressPointer r2
    //     0xcecc48: add             x2, x2, HEAP, lsl #32
    // 0xcecc4c: cmp             w2, NULL
    // 0xcecc50: b.eq            #0xcecdbc
    // 0xcecc54: SaveReg r2
    //     0xcecc54: str             x2, [SP, #-8]!
    // 0xcecc58: r0 = frameCount()
    //     0xcecc58: bl              #0xced8e8  ; [dart:ui] Codec::frameCount
    // 0xcecc5c: add             SP, SP, #8
    // 0xcecc60: mov             x1, x0
    // 0xcecc64: ldur            x0, [fp, #-0x20]
    // 0xcecc68: cbz             x1, #0xcecdc0
    // 0xcecc6c: sdiv            x2, x0, x1
    // 0xcecc70: ldr             x0, [fp, #0x18]
    // 0xcecc74: stur            x2, [fp, #-0x28]
    // 0xcecc78: LoadField: r1 = r0->field_33
    //     0xcecc78: ldur            w1, [x0, #0x33]
    // 0xcecc7c: DecompressPointer r1
    //     0xcecc7c: add             x1, x1, HEAP, lsl #32
    // 0xcecc80: cmp             w1, NULL
    // 0xcecc84: b.eq            #0xcecdd8
    // 0xcecc88: SaveReg r1
    //     0xcecc88: str             x1, [SP, #-8]!
    // 0xcecc8c: r0 = repetitionCount()
    //     0xcecc8c: bl              #0xcecdf0  ; [dart:ui] Codec::repetitionCount
    // 0xcecc90: add             SP, SP, #8
    // 0xcecc94: cmn             x0, #1
    // 0xcecc98: b.eq            #0xceccd0
    // 0xcecc9c: ldr             x1, [fp, #0x18]
    // 0xcecca0: ldur            x0, [fp, #-0x28]
    // 0xcecca4: LoadField: r2 = r1->field_33
    //     0xcecca4: ldur            w2, [x1, #0x33]
    // 0xcecca8: DecompressPointer r2
    //     0xcecca8: add             x2, x2, HEAP, lsl #32
    // 0xceccac: cmp             w2, NULL
    // 0xceccb0: b.eq            #0xcecddc
    // 0xceccb4: SaveReg r2
    //     0xceccb4: str             x2, [SP, #-8]!
    // 0xceccb8: r0 = repetitionCount()
    //     0xceccb8: bl              #0xcecdf0  ; [dart:ui] Codec::repetitionCount
    // 0xceccbc: add             SP, SP, #8
    // 0xceccc0: mov             x1, x0
    // 0xceccc4: ldur            x0, [fp, #-0x28]
    // 0xceccc8: cmp             x0, x1
    // 0xcecccc: b.gt            #0xcecce0
    // 0xceccd0: ldr             x16, [fp, #0x18]
    // 0xceccd4: SaveReg r16
    //     0xceccd4: str             x16, [SP, #-8]!
    // 0xceccd8: r0 = _decodeNextFrameAndSchedule()
    //     0xceccd8: bl              #0xcec794  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0xceccdc: add             SP, SP, #8
    // 0xcecce0: r0 = Null
    //     0xcecce0: mov             x0, NULL
    // 0xcecce4: LeaveFrame
    //     0xcecce4: mov             SP, fp
    //     0xcecce8: ldp             fp, lr, [SP], #0x10
    // 0xceccec: ret
    //     0xceccec: ret             
    // 0xceccf0: ldr             x0, [fp, #0x18]
    // 0xceccf4: ldr             x1, [fp, #0x10]
    // 0xceccf8: LoadField: r2 = r0->field_4b
    //     0xceccf8: ldur            w2, [x0, #0x4b]
    // 0xceccfc: DecompressPointer r2
    //     0xceccfc: add             x2, x2, HEAP, lsl #32
    // 0xcecd00: cmp             w2, NULL
    // 0xcecd04: b.eq            #0xcecde0
    // 0xcecd08: LoadField: r3 = r0->field_47
    //     0xcecd08: ldur            w3, [x0, #0x47]
    // 0xcecd0c: DecompressPointer r3
    //     0xcecd0c: add             x3, x3, HEAP, lsl #32
    // 0xcecd10: r16 = Sentinel
    //     0xcecd10: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcecd14: cmp             w3, w16
    // 0xcecd18: b.eq            #0xcecde4
    // 0xcecd1c: LoadField: r4 = r1->field_7
    //     0xcecd1c: ldur            x4, [x1, #7]
    // 0xcecd20: LoadField: r1 = r3->field_7
    //     0xcecd20: ldur            x1, [x3, #7]
    // 0xcecd24: sub             x3, x4, x1
    // 0xcecd28: LoadField: r1 = r2->field_7
    //     0xcecd28: ldur            x1, [x2, #7]
    // 0xcecd2c: sub             x2, x1, x3
    // 0xcecd30: stur            x2, [fp, #-0x20]
    // 0xcecd34: r0 = Duration()
    //     0xcecd34: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xcecd38: mov             x1, x0
    // 0xcecd3c: ldur            x0, [fp, #-0x20]
    // 0xcecd40: StoreField: r1->field_7 = r0
    //     0xcecd40: stur            x0, [x1, #7]
    // 0xcecd44: r16 = 1.000000
    //     0xcecd44: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xcecd48: stp             x16, x1, [SP, #-0x10]!
    // 0xcecd4c: r0 = *()
    //     0xcecd4c: bl              #0x4b52d4  ; [dart:core] Duration::*
    // 0xcecd50: add             SP, SP, #0x10
    // 0xcecd54: ldur            x2, [fp, #-8]
    // 0xcecd58: r1 = Function '<anonymous closure>':.
    //     0xcecd58: add             x1, PP, #0x27, lsl #12  ; [pp+0x27ef8] AnonymousClosure: (0xced090), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleAppFrame (0xcecad0)
    //     0xcecd5c: ldr             x1, [x1, #0xef8]
    // 0xcecd60: stur            x0, [fp, #-8]
    // 0xcecd64: r0 = AllocateClosure()
    //     0xcecd64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcecd68: ldur            x16, [fp, #-8]
    // 0xcecd6c: stp             x16, NULL, [SP, #-0x10]!
    // 0xcecd70: SaveReg r0
    //     0xcecd70: str             x0, [SP, #-8]!
    // 0xcecd74: r0 = Timer()
    //     0xcecd74: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0xcecd78: add             SP, SP, #0x18
    // 0xcecd7c: ldr             x1, [fp, #0x18]
    // 0xcecd80: StoreField: r1->field_57 = r0
    //     0xcecd80: stur            w0, [x1, #0x57]
    //     0xcecd84: ldurb           w16, [x1, #-1]
    //     0xcecd88: ldurb           w17, [x0, #-1]
    //     0xcecd8c: and             x16, x17, x16, lsr #2
    //     0xcecd90: tst             x16, HEAP, lsr #32
    //     0xcecd94: b.eq            #0xcecd9c
    //     0xcecd98: bl              #0xd6826c
    // 0xcecd9c: r0 = Null
    //     0xcecd9c: mov             x0, NULL
    // 0xcecda0: LeaveFrame
    //     0xcecda0: mov             SP, fp
    //     0xcecda4: ldp             fp, lr, [SP], #0x10
    // 0xcecda8: ret
    //     0xcecda8: ret             
    // 0xcecdac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcecdac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcecdb0: b               #0xcecae8
    // 0xcecdb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcecdb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcecdb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcecdb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcecdbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcecdbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcecdc0: stp             x0, x1, [SP, #-0x10]!
    // 0xcecdc4: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0xcecdc8: r4 = 0
    //     0xcecdc8: mov             x4, #0
    // 0xcecdcc: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcecdd0: blr             lr
    // 0xcecdd4: brk             #0
    // 0xcecdd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcecdd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcecddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcecddc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcecde0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcecde0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcecde4: r9 = _shownTimestamp
    //     0xcecde4: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f00] Field <MultiFrameImageStreamCompleter._shownTimestamp@866483930>: late (offset: 0x48)
    //     0xcecde8: ldr             x9, [x9, #0xf00]
    // 0xcecdec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcecdec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _hasFrameDurationPassed(/* No info */) {
    // ** addr: 0xced020, size: 0x70
    // 0xced020: EnterFrame
    //     0xced020: stp             fp, lr, [SP, #-0x10]!
    //     0xced024: mov             fp, SP
    // 0xced028: ldr             x1, [fp, #0x18]
    // 0xced02c: LoadField: r2 = r1->field_47
    //     0xced02c: ldur            w2, [x1, #0x47]
    // 0xced030: DecompressPointer r2
    //     0xced030: add             x2, x2, HEAP, lsl #32
    // 0xced034: r16 = Sentinel
    //     0xced034: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xced038: cmp             w2, w16
    // 0xced03c: b.eq            #0xced080
    // 0xced040: ldr             x3, [fp, #0x10]
    // 0xced044: LoadField: r4 = r3->field_7
    //     0xced044: ldur            x4, [x3, #7]
    // 0xced048: LoadField: r3 = r2->field_7
    //     0xced048: ldur            x3, [x2, #7]
    // 0xced04c: sub             x2, x4, x3
    // 0xced050: LoadField: r3 = r1->field_4b
    //     0xced050: ldur            w3, [x1, #0x4b]
    // 0xced054: DecompressPointer r3
    //     0xced054: add             x3, x3, HEAP, lsl #32
    // 0xced058: cmp             w3, NULL
    // 0xced05c: b.eq            #0xced08c
    // 0xced060: LoadField: r1 = r3->field_7
    //     0xced060: ldur            x1, [x3, #7]
    // 0xced064: cmp             x2, x1
    // 0xced068: r16 = true
    //     0xced068: add             x16, NULL, #0x20  ; true
    // 0xced06c: r17 = false
    //     0xced06c: add             x17, NULL, #0x30  ; false
    // 0xced070: csel            x0, x16, x17, ge
    // 0xced074: LeaveFrame
    //     0xced074: mov             SP, fp
    //     0xced078: ldp             fp, lr, [SP], #0x10
    // 0xced07c: ret
    //     0xced07c: ret             
    // 0xced080: r9 = _shownTimestamp
    //     0xced080: add             x9, PP, #0x27, lsl #12  ; [pp+0x27f00] Field <MultiFrameImageStreamCompleter._shownTimestamp@866483930>: late (offset: 0x48)
    //     0xced084: ldr             x9, [x9, #0xf00]
    // 0xced088: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xced088: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xced08c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xced08c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xced090, size: 0x4c
    // 0xced090: EnterFrame
    //     0xced090: stp             fp, lr, [SP, #-0x10]!
    //     0xced094: mov             fp, SP
    // 0xced098: ldr             x0, [fp, #0x10]
    // 0xced09c: LoadField: r1 = r0->field_17
    //     0xced09c: ldur            w1, [x0, #0x17]
    // 0xced0a0: DecompressPointer r1
    //     0xced0a0: add             x1, x1, HEAP, lsl #32
    // 0xced0a4: CheckStackOverflow
    //     0xced0a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xced0a8: cmp             SP, x16
    //     0xced0ac: b.ls            #0xced0d4
    // 0xced0b0: LoadField: r0 = r1->field_f
    //     0xced0b0: ldur            w0, [x1, #0xf]
    // 0xced0b4: DecompressPointer r0
    //     0xced0b4: add             x0, x0, HEAP, lsl #32
    // 0xced0b8: SaveReg r0
    //     0xced0b8: str             x0, [SP, #-8]!
    // 0xced0bc: r0 = _scheduleAppFrame()
    //     0xced0bc: bl              #0xcec9e0  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_scheduleAppFrame
    // 0xced0c0: add             SP, SP, #8
    // 0xced0c4: r0 = Null
    //     0xced0c4: mov             x0, NULL
    // 0xced0c8: LeaveFrame
    //     0xced0c8: mov             SP, fp
    //     0xced0cc: ldp             fp, lr, [SP], #0x10
    // 0xced0d0: ret
    //     0xced0d0: ret             
    // 0xced0d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xced0d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xced0d8: b               #0xced0b0
  }
  _ _emitFrame(/* No info */) {
    // ** addr: 0xced0dc, size: 0x50
    // 0xced0dc: EnterFrame
    //     0xced0dc: stp             fp, lr, [SP, #-0x10]!
    //     0xced0e0: mov             fp, SP
    // 0xced0e4: CheckStackOverflow
    //     0xced0e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xced0e8: cmp             SP, x16
    //     0xced0ec: b.ls            #0xced124
    // 0xced0f0: ldr             x16, [fp, #0x18]
    // 0xced0f4: ldr             lr, [fp, #0x10]
    // 0xced0f8: stp             lr, x16, [SP, #-0x10]!
    // 0xced0fc: r0 = setImage()
    //     0xced0fc: bl              #0xced12c  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::setImage
    // 0xced100: add             SP, SP, #0x10
    // 0xced104: ldr             x1, [fp, #0x18]
    // 0xced108: LoadField: r2 = r1->field_4f
    //     0xced108: ldur            x2, [x1, #0x4f]
    // 0xced10c: add             x3, x2, #1
    // 0xced110: StoreField: r1->field_4f = r3
    //     0xced110: stur            x3, [x1, #0x4f]
    // 0xced114: r0 = Null
    //     0xced114: mov             x0, NULL
    // 0xced118: LeaveFrame
    //     0xced118: mov             SP, fp
    //     0xced11c: ldp             fp, lr, [SP], #0x10
    // 0xced120: ret
    //     0xced120: ret             
    // 0xced124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xced124: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xced128: b               #0xced0f0
  }
  dynamic _handleCodecReady(dynamic) {
    // ** addr: 0xcedcdc, size: 0x18
    // 0xcedcdc: r4 = 0
    //     0xcedcdc: mov             x4, #0
    // 0xcedce0: r1 = Function '_handleCodecReady@866483930':.
    //     0xcedce0: add             x17, PP, #0x37, lsl #12  ; [pp+0x37190] AnonymousClosure: (0xcedcf4), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleCodecReady (0xcedd40)
    //     0xcedce4: ldr             x1, [x17, #0x190]
    // 0xcedce8: r24 = BuildNonGenericMethodExtractorStub
    //     0xcedce8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcedcec: LoadField: r0 = r24->field_17
    //     0xcedcec: ldur            x0, [x24, #0x17]
    // 0xcedcf0: br              x0
  }
  [closure] void _handleCodecReady(dynamic, Codec) {
    // ** addr: 0xcedcf4, size: 0x4c
    // 0xcedcf4: EnterFrame
    //     0xcedcf4: stp             fp, lr, [SP, #-0x10]!
    //     0xcedcf8: mov             fp, SP
    // 0xcedcfc: ldr             x0, [fp, #0x18]
    // 0xcedd00: LoadField: r1 = r0->field_17
    //     0xcedd00: ldur            w1, [x0, #0x17]
    // 0xcedd04: DecompressPointer r1
    //     0xcedd04: add             x1, x1, HEAP, lsl #32
    // 0xcedd08: CheckStackOverflow
    //     0xcedd08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcedd0c: cmp             SP, x16
    //     0xcedd10: b.ls            #0xcedd38
    // 0xcedd14: LoadField: r0 = r1->field_f
    //     0xcedd14: ldur            w0, [x1, #0xf]
    // 0xcedd18: DecompressPointer r0
    //     0xcedd18: add             x0, x0, HEAP, lsl #32
    // 0xcedd1c: ldr             x16, [fp, #0x10]
    // 0xcedd20: stp             x16, x0, [SP, #-0x10]!
    // 0xcedd24: r0 = _handleCodecReady()
    //     0xcedd24: bl              #0xcedd40  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_handleCodecReady
    // 0xcedd28: add             SP, SP, #0x10
    // 0xcedd2c: LeaveFrame
    //     0xcedd2c: mov             SP, fp
    //     0xcedd30: ldp             fp, lr, [SP], #0x10
    // 0xcedd34: ret
    //     0xcedd34: ret             
    // 0xcedd38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcedd38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcedd3c: b               #0xcedd14
  }
  _ _handleCodecReady(/* No info */) {
    // ** addr: 0xcedd40, size: 0x70
    // 0xcedd40: EnterFrame
    //     0xcedd40: stp             fp, lr, [SP, #-0x10]!
    //     0xcedd44: mov             fp, SP
    // 0xcedd48: CheckStackOverflow
    //     0xcedd48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcedd4c: cmp             SP, x16
    //     0xcedd50: b.ls            #0xcedda8
    // 0xcedd54: ldr             x0, [fp, #0x10]
    // 0xcedd58: ldr             x1, [fp, #0x18]
    // 0xcedd5c: StoreField: r1->field_33 = r0
    //     0xcedd5c: stur            w0, [x1, #0x33]
    //     0xcedd60: ldurb           w16, [x1, #-1]
    //     0xcedd64: ldurb           w17, [x0, #-1]
    //     0xcedd68: and             x16, x17, x16, lsr #2
    //     0xcedd6c: tst             x16, HEAP, lsr #32
    //     0xcedd70: b.eq            #0xcedd78
    //     0xcedd74: bl              #0xd6826c
    // 0xcedd78: LoadField: r0 = r1->field_7
    //     0xcedd78: ldur            w0, [x1, #7]
    // 0xcedd7c: DecompressPointer r0
    //     0xcedd7c: add             x0, x0, HEAP, lsl #32
    // 0xcedd80: LoadField: r2 = r0->field_b
    //     0xcedd80: ldur            w2, [x0, #0xb]
    // 0xcedd84: DecompressPointer r2
    //     0xcedd84: add             x2, x2, HEAP, lsl #32
    // 0xcedd88: cbz             w2, #0xcedd98
    // 0xcedd8c: SaveReg r1
    //     0xcedd8c: str             x1, [SP, #-8]!
    // 0xcedd90: r0 = _decodeNextFrameAndSchedule()
    //     0xcedd90: bl              #0xcec794  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0xcedd94: add             SP, SP, #8
    // 0xcedd98: r0 = Null
    //     0xcedd98: mov             x0, NULL
    // 0xcedd9c: LeaveFrame
    //     0xcedd9c: mov             SP, fp
    //     0xcedda0: ldp             fp, lr, [SP], #0x10
    // 0xcedda4: ret
    //     0xcedda4: ret             
    // 0xcedda8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcedda8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceddac: b               #0xcedd54
  }
  _ _maybeDispose(/* No info */) {
    // ** addr: 0xcede58, size: 0xb8
    // 0xcede58: EnterFrame
    //     0xcede58: stp             fp, lr, [SP, #-0x10]!
    //     0xcede5c: mov             fp, SP
    // 0xcede60: CheckStackOverflow
    //     0xcede60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcede64: cmp             SP, x16
    //     0xcede68: b.ls            #0xcedf08
    // 0xcede6c: ldr             x16, [fp, #0x10]
    // 0xcede70: SaveReg r16
    //     0xcede70: str             x16, [SP, #-8]!
    // 0xcede74: r0 = _maybeDispose()
    //     0xcede74: bl              #0xceddb0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::_maybeDispose
    // 0xcede78: add             SP, SP, #8
    // 0xcede7c: ldr             x1, [fp, #0x10]
    // 0xcede80: LoadField: r0 = r1->field_27
    //     0xcede80: ldur            w0, [x1, #0x27]
    // 0xcede84: DecompressPointer r0
    //     0xcede84: add             x0, x0, HEAP, lsl #32
    // 0xcede88: tbnz            w0, #4, #0xcedef8
    // 0xcede8c: LoadField: r0 = r1->field_2f
    //     0xcede8c: ldur            w0, [x1, #0x2f]
    // 0xcede90: DecompressPointer r0
    //     0xcede90: add             x0, x0, HEAP, lsl #32
    // 0xcede94: cmp             w0, NULL
    // 0xcede98: b.eq            #0xcedec0
    // 0xcede9c: r2 = LoadClassIdInstr(r0)
    //     0xcede9c: ldur            x2, [x0, #-1]
    //     0xcedea0: ubfx            x2, x2, #0xc, #0x14
    // 0xcedea4: stp             NULL, x0, [SP, #-0x10]!
    // 0xcedea8: mov             x0, x2
    // 0xcedeac: r0 = GDT[cid_x0 + 0x396]()
    //     0xcedeac: add             lr, x0, #0x396
    //     0xcedeb0: ldr             lr, [x21, lr, lsl #3]
    //     0xcedeb4: blr             lr
    // 0xcedeb8: add             SP, SP, #0x10
    // 0xcedebc: ldr             x1, [fp, #0x10]
    // 0xcedec0: LoadField: r0 = r1->field_2f
    //     0xcedec0: ldur            w0, [x1, #0x2f]
    // 0xcedec4: DecompressPointer r0
    //     0xcedec4: add             x0, x0, HEAP, lsl #32
    // 0xcedec8: cmp             w0, NULL
    // 0xcedecc: b.eq            #0xcedef4
    // 0xceded0: r2 = LoadClassIdInstr(r0)
    //     0xceded0: ldur            x2, [x0, #-1]
    //     0xceded4: ubfx            x2, x2, #0xc, #0x14
    // 0xceded8: SaveReg r0
    //     0xceded8: str             x0, [SP, #-8]!
    // 0xcededc: mov             x0, x2
    // 0xcedee0: r0 = GDT[cid_x0 + 0x307]()
    //     0xcedee0: add             lr, x0, #0x307
    //     0xcedee4: ldr             lr, [x21, lr, lsl #3]
    //     0xcedee8: blr             lr
    // 0xcedeec: add             SP, SP, #8
    // 0xcedef0: ldr             x1, [fp, #0x10]
    // 0xcedef4: StoreField: r1->field_2f = rNULL
    //     0xcedef4: stur            NULL, [x1, #0x2f]
    // 0xcedef8: r0 = Null
    //     0xcedef8: mov             x0, NULL
    // 0xcedefc: LeaveFrame
    //     0xcedefc: mov             SP, fp
    //     0xcedf00: ldp             fp, lr, [SP], #0x10
    // 0xcedf04: ret
    //     0xcedf04: ret             
    // 0xcedf08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcedf08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcedf0c: b               #0xcede6c
  }
  _ removeListener(/* No info */) {
    // ** addr: 0xcee1b4, size: 0x84
    // 0xcee1b4: EnterFrame
    //     0xcee1b4: stp             fp, lr, [SP, #-0x10]!
    //     0xcee1b8: mov             fp, SP
    // 0xcee1bc: CheckStackOverflow
    //     0xcee1bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee1c0: cmp             SP, x16
    //     0xcee1c4: b.ls            #0xcee230
    // 0xcee1c8: ldr             x16, [fp, #0x18]
    // 0xcee1cc: ldr             lr, [fp, #0x10]
    // 0xcee1d0: stp             lr, x16, [SP, #-0x10]!
    // 0xcee1d4: r0 = removeListener()
    //     0xcee1d4: bl              #0xcedf10  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0xcee1d8: add             SP, SP, #0x10
    // 0xcee1dc: ldr             x0, [fp, #0x18]
    // 0xcee1e0: LoadField: r1 = r0->field_7
    //     0xcee1e0: ldur            w1, [x0, #7]
    // 0xcee1e4: DecompressPointer r1
    //     0xcee1e4: add             x1, x1, HEAP, lsl #32
    // 0xcee1e8: LoadField: r2 = r1->field_b
    //     0xcee1e8: ldur            w2, [x1, #0xb]
    // 0xcee1ec: DecompressPointer r2
    //     0xcee1ec: add             x2, x2, HEAP, lsl #32
    // 0xcee1f0: cbnz            w2, #0xcee220
    // 0xcee1f4: LoadField: r1 = r0->field_57
    //     0xcee1f4: ldur            w1, [x0, #0x57]
    // 0xcee1f8: DecompressPointer r1
    //     0xcee1f8: add             x1, x1, HEAP, lsl #32
    // 0xcee1fc: cmp             w1, NULL
    // 0xcee200: b.ne            #0xcee20c
    // 0xcee204: mov             x1, x0
    // 0xcee208: b               #0xcee21c
    // 0xcee20c: SaveReg r1
    //     0xcee20c: str             x1, [SP, #-8]!
    // 0xcee210: r0 = cancel()
    //     0xcee210: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0xcee214: add             SP, SP, #8
    // 0xcee218: ldr             x1, [fp, #0x18]
    // 0xcee21c: StoreField: r1->field_57 = rNULL
    //     0xcee21c: stur            NULL, [x1, #0x57]
    // 0xcee220: r0 = Null
    //     0xcee220: mov             x0, NULL
    // 0xcee224: LeaveFrame
    //     0xcee224: mov             SP, fp
    //     0xcee228: ldp             fp, lr, [SP], #0x10
    // 0xcee22c: ret
    //     0xcee22c: ret             
    // 0xcee230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee230: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee234: b               #0xcee1c8
  }
}

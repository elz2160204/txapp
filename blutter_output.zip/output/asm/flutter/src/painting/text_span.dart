// lib: , url: package:flutter/src/painting/text_span.dart

// class id: 1049384, size: 0x8
class :: {
}

// class id: 3473, size: 0x30, field offset: 0xc
//   const constructor, 
class TextSpan extends InlineSpan
    implements HitTestTarget, MouseTrackerAnnotation {

  _OneByteString field_c;
  _DeferringMouseCursor field_18;
  TextStyle field_8;

  RenderComparison compareTo(TextSpan, InlineSpan) {
    // ** addr: 0x673628, size: 0x90
    // 0x673628: EnterFrame
    //     0x673628: stp             fp, lr, [SP, #-0x10]!
    //     0x67362c: mov             fp, SP
    // 0x673630: CheckStackOverflow
    //     0x673630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x673634: cmp             SP, x16
    //     0x673638: b.ls            #0x673698
    // 0x67363c: ldr             x0, [fp, #0x10]
    // 0x673640: r2 = Null
    //     0x673640: mov             x2, NULL
    // 0x673644: r1 = Null
    //     0x673644: mov             x1, NULL
    // 0x673648: r4 = 59
    //     0x673648: mov             x4, #0x3b
    // 0x67364c: branchIfSmi(r0, 0x673658)
    //     0x67364c: tbz             w0, #0, #0x673658
    // 0x673650: r4 = LoadClassIdInstr(r0)
    //     0x673650: ldur            x4, [x0, #-1]
    //     0x673654: ubfx            x4, x4, #0xc, #0x14
    // 0x673658: sub             x4, x4, #0xd91
    // 0x67365c: cmp             x4, #6
    // 0x673660: b.ls            #0x673678
    // 0x673664: r8 = InlineSpan
    //     0x673664: add             x8, PP, #0x29, lsl #12  ; [pp+0x29028] Type: InlineSpan
    //     0x673668: ldr             x8, [x8, #0x28]
    // 0x67366c: r3 = Null
    //     0x67366c: add             x3, PP, #0x29, lsl #12  ; [pp+0x29030] Null
    //     0x673670: ldr             x3, [x3, #0x30]
    // 0x673674: r0 = InlineSpan()
    //     0x673674: bl              #0x521860  ; IsType_InlineSpan_Stub
    // 0x673678: ldr             x16, [fp, #0x18]
    // 0x67367c: ldr             lr, [fp, #0x10]
    // 0x673680: stp             lr, x16, [SP, #-0x10]!
    // 0x673684: r0 = compareTo()
    //     0x673684: bl              #0xcdc8cc  ; [package:flutter/src/painting/text_span.dart] TextSpan::compareTo
    // 0x673688: add             SP, SP, #0x10
    // 0x67368c: LeaveFrame
    //     0x67368c: mov             SP, fp
    //     0x673690: ldp             fp, lr, [SP], #0x10
    // 0x673694: ret
    //     0x673694: ret             
    // 0x673698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x673698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67369c: b               #0x67363c
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x6fd93c, size: 0x90
    // 0x6fd93c: EnterFrame
    //     0x6fd93c: stp             fp, lr, [SP, #-0x10]!
    //     0x6fd940: mov             fp, SP
    // 0x6fd944: CheckStackOverflow
    //     0x6fd944: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6fd948: cmp             SP, x16
    //     0x6fd94c: b.ls            #0x6fd9c4
    // 0x6fd950: ldr             x0, [fp, #0x18]
    // 0x6fd954: r2 = Null
    //     0x6fd954: mov             x2, NULL
    // 0x6fd958: r1 = Null
    //     0x6fd958: mov             x1, NULL
    // 0x6fd95c: cmp             w0, NULL
    // 0x6fd960: b.eq            #0x6fd980
    // 0x6fd964: branchIfSmi(r0, 0x6fd980)
    //     0x6fd964: tbz             w0, #0, #0x6fd980
    // 0x6fd968: r3 = LoadClassIdInstr(r0)
    //     0x6fd968: ldur            x3, [x0, #-1]
    //     0x6fd96c: ubfx            x3, x3, #0xc, #0x14
    // 0x6fd970: cmp             x3, #0x90a
    // 0x6fd974: b.eq            #0x6fd988
    // 0x6fd978: cmp             x3, #0xb41
    // 0x6fd97c: b.eq            #0x6fd988
    // 0x6fd980: r0 = false
    //     0x6fd980: add             x0, NULL, #0x30  ; false
    // 0x6fd984: b               #0x6fd98c
    // 0x6fd988: r0 = true
    //     0x6fd988: add             x0, NULL, #0x20  ; true
    // 0x6fd98c: tbnz            w0, #4, #0x6fd9b4
    // 0x6fd990: ldr             x0, [fp, #0x20]
    // 0x6fd994: LoadField: r1 = r0->field_13
    //     0x6fd994: ldur            w1, [x0, #0x13]
    // 0x6fd998: DecompressPointer r1
    //     0x6fd998: add             x1, x1, HEAP, lsl #32
    // 0x6fd99c: cmp             w1, NULL
    // 0x6fd9a0: b.eq            #0x6fd9b4
    // 0x6fd9a4: ldr             x16, [fp, #0x18]
    // 0x6fd9a8: stp             x16, x1, [SP, #-0x10]!
    // 0x6fd9ac: r0 = addPointer()
    //     0x6fd9ac: bl              #0x6fd9cc  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0x6fd9b0: add             SP, SP, #0x10
    // 0x6fd9b4: r0 = Null
    //     0x6fd9b4: mov             x0, NULL
    // 0x6fd9b8: LeaveFrame
    //     0x6fd9b8: mov             SP, fp
    //     0x6fd9bc: ldp             fp, lr, [SP], #0x10
    // 0x6fd9c0: ret
    //     0x6fd9c0: ret             
    // 0x6fd9c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6fd9c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6fd9c8: b               #0x6fd950
  }
  _ toStringShort(/* No info */) {
    // ** addr: 0xa77ba8, size: 0xc
    // 0xa77ba8: r0 = "TextSpan"
    //     0xa77ba8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d1d0] "TextSpan"
    //     0xa77bac: ldr             x0, [x0, #0x1d0]
    // 0xa77bb0: ret
    //     0xa77bb0: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafb9f8, size: 0x10c
    // 0xafb9f8: EnterFrame
    //     0xafb9f8: stp             fp, lr, [SP, #-0x10]!
    //     0xafb9fc: mov             fp, SP
    // 0xafba00: AllocStack(0x20)
    //     0xafba00: sub             SP, SP, #0x20
    // 0xafba04: CheckStackOverflow
    //     0xafba04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafba08: cmp             SP, x16
    //     0xafba0c: b.ls            #0xafbafc
    // 0xafba10: ldr             x1, [fp, #0x10]
    // 0xafba14: LoadField: r0 = r1->field_7
    //     0xafba14: ldur            w0, [x1, #7]
    // 0xafba18: DecompressPointer r0
    //     0xafba18: add             x0, x0, HEAP, lsl #32
    // 0xafba1c: r2 = LoadClassIdInstr(r0)
    //     0xafba1c: ldur            x2, [x0, #-1]
    //     0xafba20: ubfx            x2, x2, #0xc, #0x14
    // 0xafba24: SaveReg r0
    //     0xafba24: str             x0, [SP, #-8]!
    // 0xafba28: mov             x0, x2
    // 0xafba2c: r0 = GDT[cid_x0 + 0x2721]()
    //     0xafba2c: mov             x17, #0x2721
    //     0xafba30: add             lr, x0, x17
    //     0xafba34: ldr             lr, [x21, lr, lsl #3]
    //     0xafba38: blr             lr
    // 0xafba3c: add             SP, SP, #8
    // 0xafba40: mov             x1, x0
    // 0xafba44: ldr             x0, [fp, #0x10]
    // 0xafba48: stur            x1, [fp, #-0x20]
    // 0xafba4c: LoadField: r2 = r0->field_b
    //     0xafba4c: ldur            w2, [x0, #0xb]
    // 0xafba50: DecompressPointer r2
    //     0xafba50: add             x2, x2, HEAP, lsl #32
    // 0xafba54: stur            x2, [fp, #-0x18]
    // 0xafba58: LoadField: r3 = r0->field_13
    //     0xafba58: ldur            w3, [x0, #0x13]
    // 0xafba5c: DecompressPointer r3
    //     0xafba5c: add             x3, x3, HEAP, lsl #32
    // 0xafba60: stur            x3, [fp, #-0x10]
    // 0xafba64: LoadField: r4 = r0->field_17
    //     0xafba64: ldur            w4, [x0, #0x17]
    // 0xafba68: DecompressPointer r4
    //     0xafba68: add             x4, x4, HEAP, lsl #32
    // 0xafba6c: stur            x4, [fp, #-8]
    // 0xafba70: LoadField: r5 = r0->field_f
    //     0xafba70: ldur            w5, [x0, #0xf]
    // 0xafba74: DecompressPointer r5
    //     0xafba74: add             x5, x5, HEAP, lsl #32
    // 0xafba78: cmp             w5, NULL
    // 0xafba7c: b.ne            #0xafba88
    // 0xafba80: r0 = Null
    //     0xafba80: mov             x0, NULL
    // 0xafba84: b               #0xafbaac
    // 0xafba88: SaveReg r5
    //     0xafba88: str             x5, [SP, #-8]!
    // 0xafba8c: r0 = hashAll()
    //     0xafba8c: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xafba90: add             SP, SP, #8
    // 0xafba94: mov             x2, x0
    // 0xafba98: r0 = BoxInt64Instr(r2)
    //     0xafba98: sbfiz           x0, x2, #1, #0x1f
    //     0xafba9c: cmp             x2, x0, asr #1
    //     0xafbaa0: b.eq            #0xafbaac
    //     0xafbaa4: bl              #0xd69bb8
    //     0xafbaa8: stur            x2, [x0, #7]
    // 0xafbaac: ldur            x16, [fp, #-0x20]
    // 0xafbab0: ldur            lr, [fp, #-0x18]
    // 0xafbab4: stp             lr, x16, [SP, #-0x10]!
    // 0xafbab8: ldur            x16, [fp, #-0x10]
    // 0xafbabc: stp             NULL, x16, [SP, #-0x10]!
    // 0xafbac0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafbac4: ldur            x16, [fp, #-8]
    // 0xafbac8: stp             x0, x16, [SP, #-0x10]!
    // 0xafbacc: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0xafbacc: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0xafbad0: r0 = hash()
    //     0xafbad0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafbad4: add             SP, SP, #0x40
    // 0xafbad8: mov             x2, x0
    // 0xafbadc: r0 = BoxInt64Instr(r2)
    //     0xafbadc: sbfiz           x0, x2, #1, #0x1f
    //     0xafbae0: cmp             x2, x0, asr #1
    //     0xafbae4: b.eq            #0xafbaf0
    //     0xafbae8: bl              #0xd69bb8
    //     0xafbaec: stur            x2, [x0, #7]
    // 0xafbaf0: LeaveFrame
    //     0xafbaf0: mov             SP, fp
    //     0xafbaf4: ldp             fp, lr, [SP], #0x10
    // 0xafbaf8: ret
    //     0xafbaf8: ret             
    // 0xafbafc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafbafc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafbb00: b               #0xafba10
  }
  _ codeUnitAtVisitor(/* No info */) {
    // ** addr: 0xc0f4cc, size: 0xc0
    // 0xc0f4cc: EnterFrame
    //     0xc0f4cc: stp             fp, lr, [SP, #-0x10]!
    //     0xc0f4d0: mov             fp, SP
    // 0xc0f4d4: CheckStackOverflow
    //     0xc0f4d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0f4d8: cmp             SP, x16
    //     0xc0f4dc: b.ls            #0xc0f584
    // 0xc0f4e0: ldr             x0, [fp, #0x20]
    // 0xc0f4e4: LoadField: r2 = r0->field_b
    //     0xc0f4e4: ldur            w2, [x0, #0xb]
    // 0xc0f4e8: DecompressPointer r2
    //     0xc0f4e8: add             x2, x2, HEAP, lsl #32
    // 0xc0f4ec: cmp             w2, NULL
    // 0xc0f4f0: b.ne            #0xc0f504
    // 0xc0f4f4: r0 = Null
    //     0xc0f4f4: mov             x0, NULL
    // 0xc0f4f8: LeaveFrame
    //     0xc0f4f8: mov             SP, fp
    //     0xc0f4fc: ldp             fp, lr, [SP], #0x10
    // 0xc0f500: ret
    //     0xc0f500: ret             
    // 0xc0f504: ldr             x1, [fp, #0x18]
    // 0xc0f508: ldr             x0, [fp, #0x10]
    // 0xc0f50c: LoadField: r3 = r0->field_7
    //     0xc0f50c: ldur            x3, [x0, #7]
    // 0xc0f510: sub             x4, x1, x3
    // 0xc0f514: LoadField: r1 = r2->field_7
    //     0xc0f514: ldur            w1, [x2, #7]
    // 0xc0f518: DecompressPointer r1
    //     0xc0f518: add             x1, x1, HEAP, lsl #32
    // 0xc0f51c: r3 = LoadInt32Instr(r1)
    //     0xc0f51c: sbfx            x3, x1, #1, #0x1f
    // 0xc0f520: cmp             x4, x3
    // 0xc0f524: b.ge            #0xc0f568
    // 0xc0f528: r0 = BoxInt64Instr(r4)
    //     0xc0f528: sbfiz           x0, x4, #1, #0x1f
    //     0xc0f52c: cmp             x4, x0, asr #1
    //     0xc0f530: b.eq            #0xc0f53c
    //     0xc0f534: bl              #0xd69bb8
    //     0xc0f538: stur            x4, [x0, #7]
    // 0xc0f53c: r1 = LoadClassIdInstr(r2)
    //     0xc0f53c: ldur            x1, [x2, #-1]
    //     0xc0f540: ubfx            x1, x1, #0xc, #0x14
    // 0xc0f544: stp             x0, x2, [SP, #-0x10]!
    // 0xc0f548: mov             x0, x1
    // 0xc0f54c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc0f54c: sub             lr, x0, #1, lsl #12
    //     0xc0f550: ldr             lr, [x21, lr, lsl #3]
    //     0xc0f554: blr             lr
    // 0xc0f558: add             SP, SP, #0x10
    // 0xc0f55c: LeaveFrame
    //     0xc0f55c: mov             SP, fp
    //     0xc0f560: ldp             fp, lr, [SP], #0x10
    // 0xc0f564: ret
    //     0xc0f564: ret             
    // 0xc0f568: stp             x3, x0, [SP, #-0x10]!
    // 0xc0f56c: r0 = increment()
    //     0xc0f56c: bl              #0x5221fc  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0xc0f570: add             SP, SP, #0x10
    // 0xc0f574: r0 = Null
    //     0xc0f574: mov             x0, NULL
    // 0xc0f578: LeaveFrame
    //     0xc0f578: mov             SP, fp
    //     0xc0f57c: ldp             fp, lr, [SP], #0x10
    // 0xc0f580: ret
    //     0xc0f580: ret             
    // 0xc0f584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0f584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0f588: b               #0xc0f4e0
  }
  _ getSpanForPositionVisitor(/* No info */) {
    // ** addr: 0xc2edd0, size: 0xc8
    // 0xc2edd0: EnterFrame
    //     0xc2edd0: stp             fp, lr, [SP, #-0x10]!
    //     0xc2edd4: mov             fp, SP
    // 0xc2edd8: CheckStackOverflow
    //     0xc2edd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2eddc: cmp             SP, x16
    //     0xc2ede0: b.ls            #0xc2ee90
    // 0xc2ede4: ldr             x0, [fp, #0x20]
    // 0xc2ede8: LoadField: r1 = r0->field_b
    //     0xc2ede8: ldur            w1, [x0, #0xb]
    // 0xc2edec: DecompressPointer r1
    //     0xc2edec: add             x1, x1, HEAP, lsl #32
    // 0xc2edf0: cmp             w1, NULL
    // 0xc2edf4: b.ne            #0xc2ee08
    // 0xc2edf8: r0 = Null
    //     0xc2edf8: mov             x0, NULL
    // 0xc2edfc: LeaveFrame
    //     0xc2edfc: mov             SP, fp
    //     0xc2ee00: ldp             fp, lr, [SP], #0x10
    // 0xc2ee04: ret
    //     0xc2ee04: ret             
    // 0xc2ee08: ldr             x3, [fp, #0x18]
    // 0xc2ee0c: ldr             x2, [fp, #0x10]
    // 0xc2ee10: LoadField: r4 = r3->field_f
    //     0xc2ee10: ldur            w4, [x3, #0xf]
    // 0xc2ee14: DecompressPointer r4
    //     0xc2ee14: add             x4, x4, HEAP, lsl #32
    // 0xc2ee18: LoadField: r5 = r3->field_7
    //     0xc2ee18: ldur            x5, [x3, #7]
    // 0xc2ee1c: LoadField: r3 = r2->field_7
    //     0xc2ee1c: ldur            x3, [x2, #7]
    // 0xc2ee20: LoadField: r6 = r1->field_7
    //     0xc2ee20: ldur            w6, [x1, #7]
    // 0xc2ee24: DecompressPointer r6
    //     0xc2ee24: add             x6, x6, HEAP, lsl #32
    // 0xc2ee28: r1 = LoadInt32Instr(r6)
    //     0xc2ee28: sbfx            x1, x6, #1, #0x1f
    // 0xc2ee2c: add             x6, x3, x1
    // 0xc2ee30: cmp             x3, x5
    // 0xc2ee34: b.ne            #0xc2ee44
    // 0xc2ee38: r16 = Instance_TextAffinity
    //     0xc2ee38: ldr             x16, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xc2ee3c: cmp             w4, w16
    // 0xc2ee40: b.eq            #0xc2ee68
    // 0xc2ee44: cmp             x3, x5
    // 0xc2ee48: b.ge            #0xc2ee54
    // 0xc2ee4c: cmp             x5, x6
    // 0xc2ee50: b.lt            #0xc2ee68
    // 0xc2ee54: cmp             x6, x5
    // 0xc2ee58: b.ne            #0xc2ee74
    // 0xc2ee5c: r16 = Instance_TextAffinity
    //     0xc2ee5c: ldr             x16, [PP, #0x6098]  ; [pp+0x6098] Obj!TextAffinity@b66df1
    // 0xc2ee60: cmp             w4, w16
    // 0xc2ee64: b.ne            #0xc2ee74
    // 0xc2ee68: LeaveFrame
    //     0xc2ee68: mov             SP, fp
    //     0xc2ee6c: ldp             fp, lr, [SP], #0x10
    // 0xc2ee70: ret
    //     0xc2ee70: ret             
    // 0xc2ee74: stp             x1, x2, [SP, #-0x10]!
    // 0xc2ee78: r0 = increment()
    //     0xc2ee78: bl              #0x5221fc  ; [package:flutter/src/painting/inline_span.dart] Accumulator::increment
    // 0xc2ee7c: add             SP, SP, #0x10
    // 0xc2ee80: r0 = Null
    //     0xc2ee80: mov             x0, NULL
    // 0xc2ee84: LeaveFrame
    //     0xc2ee84: mov             SP, fp
    //     0xc2ee88: ldp             fp, lr, [SP], #0x10
    // 0xc2ee8c: ret
    //     0xc2ee8c: ret             
    // 0xc2ee90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2ee90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2ee94: b               #0xc2ede4
  }
  _ ==(/* No info */) {
    // ** addr: 0xc75e20, size: 0x1f8
    // 0xc75e20: EnterFrame
    //     0xc75e20: stp             fp, lr, [SP, #-0x10]!
    //     0xc75e24: mov             fp, SP
    // 0xc75e28: AllocStack(0x8)
    //     0xc75e28: sub             SP, SP, #8
    // 0xc75e2c: CheckStackOverflow
    //     0xc75e2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc75e30: cmp             SP, x16
    //     0xc75e34: b.ls            #0xc76010
    // 0xc75e38: ldr             x1, [fp, #0x10]
    // 0xc75e3c: cmp             w1, NULL
    // 0xc75e40: b.ne            #0xc75e54
    // 0xc75e44: r0 = false
    //     0xc75e44: add             x0, NULL, #0x30  ; false
    // 0xc75e48: LeaveFrame
    //     0xc75e48: mov             SP, fp
    //     0xc75e4c: ldp             fp, lr, [SP], #0x10
    // 0xc75e50: ret
    //     0xc75e50: ret             
    // 0xc75e54: ldr             x2, [fp, #0x18]
    // 0xc75e58: cmp             w2, w1
    // 0xc75e5c: b.ne            #0xc75e70
    // 0xc75e60: r0 = true
    //     0xc75e60: add             x0, NULL, #0x20  ; true
    // 0xc75e64: LeaveFrame
    //     0xc75e64: mov             SP, fp
    //     0xc75e68: ldp             fp, lr, [SP], #0x10
    // 0xc75e6c: ret
    //     0xc75e6c: ret             
    // 0xc75e70: r0 = 59
    //     0xc75e70: mov             x0, #0x3b
    // 0xc75e74: branchIfSmi(r1, 0xc75e80)
    //     0xc75e74: tbz             w1, #0, #0xc75e80
    // 0xc75e78: r0 = LoadClassIdInstr(r1)
    //     0xc75e78: ldur            x0, [x1, #-1]
    //     0xc75e7c: ubfx            x0, x0, #0xc, #0x14
    // 0xc75e80: SaveReg r1
    //     0xc75e80: str             x1, [SP, #-8]!
    // 0xc75e84: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc75e84: mov             x17, #0x57c5
    //     0xc75e88: add             lr, x0, x17
    //     0xc75e8c: ldr             lr, [x21, lr, lsl #3]
    //     0xc75e90: blr             lr
    // 0xc75e94: add             SP, SP, #8
    // 0xc75e98: stur            x0, [fp, #-8]
    // 0xc75e9c: ldr             x16, [fp, #0x18]
    // 0xc75ea0: SaveReg r16
    //     0xc75ea0: str             x16, [SP, #-8]!
    // 0xc75ea4: r0 = runtimeType()
    //     0xc75ea4: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc75ea8: add             SP, SP, #8
    // 0xc75eac: mov             x1, x0
    // 0xc75eb0: ldur            x0, [fp, #-8]
    // 0xc75eb4: r2 = LoadClassIdInstr(r0)
    //     0xc75eb4: ldur            x2, [x0, #-1]
    //     0xc75eb8: ubfx            x2, x2, #0xc, #0x14
    // 0xc75ebc: stp             x1, x0, [SP, #-0x10]!
    // 0xc75ec0: mov             x0, x2
    // 0xc75ec4: mov             lr, x0
    // 0xc75ec8: ldr             lr, [x21, lr, lsl #3]
    // 0xc75ecc: blr             lr
    // 0xc75ed0: add             SP, SP, #0x10
    // 0xc75ed4: tbz             w0, #4, #0xc75ee8
    // 0xc75ed8: r0 = false
    //     0xc75ed8: add             x0, NULL, #0x30  ; false
    // 0xc75edc: LeaveFrame
    //     0xc75edc: mov             SP, fp
    //     0xc75ee0: ldp             fp, lr, [SP], #0x10
    // 0xc75ee4: ret
    //     0xc75ee4: ret             
    // 0xc75ee8: ldr             x16, [fp, #0x18]
    // 0xc75eec: ldr             lr, [fp, #0x10]
    // 0xc75ef0: stp             lr, x16, [SP, #-0x10]!
    // 0xc75ef4: r0 = ==()
    //     0xc75ef4: bl              #0xc75b44  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::==
    // 0xc75ef8: add             SP, SP, #0x10
    // 0xc75efc: tbz             w0, #4, #0xc75f10
    // 0xc75f00: r0 = false
    //     0xc75f00: add             x0, NULL, #0x30  ; false
    // 0xc75f04: LeaveFrame
    //     0xc75f04: mov             SP, fp
    //     0xc75f08: ldp             fp, lr, [SP], #0x10
    // 0xc75f0c: ret
    //     0xc75f0c: ret             
    // 0xc75f10: ldr             x1, [fp, #0x10]
    // 0xc75f14: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc75f14: mov             x0, #0x76
    //     0xc75f18: tbz             w1, #0, #0xc75f28
    //     0xc75f1c: ldur            x0, [x1, #-1]
    //     0xc75f20: ubfx            x0, x0, #0xc, #0x14
    //     0xc75f24: lsl             x0, x0, #1
    // 0xc75f28: r2 = LoadInt32Instr(r0)
    //     0xc75f28: sbfx            x2, x0, #1, #0x1f
    // 0xc75f2c: cmp             x2, #0xd91
    // 0xc75f30: b.lt            #0xc76000
    // 0xc75f34: cmp             x2, #0xd93
    // 0xc75f38: b.gt            #0xc76000
    // 0xc75f3c: ldr             x2, [fp, #0x18]
    // 0xc75f40: LoadField: r0 = r1->field_b
    //     0xc75f40: ldur            w0, [x1, #0xb]
    // 0xc75f44: DecompressPointer r0
    //     0xc75f44: add             x0, x0, HEAP, lsl #32
    // 0xc75f48: LoadField: r3 = r2->field_b
    //     0xc75f48: ldur            w3, [x2, #0xb]
    // 0xc75f4c: DecompressPointer r3
    //     0xc75f4c: add             x3, x3, HEAP, lsl #32
    // 0xc75f50: r4 = LoadClassIdInstr(r0)
    //     0xc75f50: ldur            x4, [x0, #-1]
    //     0xc75f54: ubfx            x4, x4, #0xc, #0x14
    // 0xc75f58: stp             x3, x0, [SP, #-0x10]!
    // 0xc75f5c: mov             x0, x4
    // 0xc75f60: mov             lr, x0
    // 0xc75f64: ldr             lr, [x21, lr, lsl #3]
    // 0xc75f68: blr             lr
    // 0xc75f6c: add             SP, SP, #0x10
    // 0xc75f70: tbnz            w0, #4, #0xc76000
    // 0xc75f74: ldr             x2, [fp, #0x18]
    // 0xc75f78: ldr             x1, [fp, #0x10]
    // 0xc75f7c: LoadField: r0 = r1->field_13
    //     0xc75f7c: ldur            w0, [x1, #0x13]
    // 0xc75f80: DecompressPointer r0
    //     0xc75f80: add             x0, x0, HEAP, lsl #32
    // 0xc75f84: LoadField: r3 = r2->field_13
    //     0xc75f84: ldur            w3, [x2, #0x13]
    // 0xc75f88: DecompressPointer r3
    //     0xc75f88: add             x3, x3, HEAP, lsl #32
    // 0xc75f8c: cmp             w0, w3
    // 0xc75f90: b.ne            #0xc76000
    // 0xc75f94: LoadField: r0 = r2->field_17
    //     0xc75f94: ldur            w0, [x2, #0x17]
    // 0xc75f98: DecompressPointer r0
    //     0xc75f98: add             x0, x0, HEAP, lsl #32
    // 0xc75f9c: LoadField: r3 = r1->field_17
    //     0xc75f9c: ldur            w3, [x1, #0x17]
    // 0xc75fa0: DecompressPointer r3
    //     0xc75fa0: add             x3, x3, HEAP, lsl #32
    // 0xc75fa4: r4 = LoadClassIdInstr(r0)
    //     0xc75fa4: ldur            x4, [x0, #-1]
    //     0xc75fa8: ubfx            x4, x4, #0xc, #0x14
    // 0xc75fac: stp             x3, x0, [SP, #-0x10]!
    // 0xc75fb0: mov             x0, x4
    // 0xc75fb4: mov             lr, x0
    // 0xc75fb8: ldr             lr, [x21, lr, lsl #3]
    // 0xc75fbc: blr             lr
    // 0xc75fc0: add             SP, SP, #0x10
    // 0xc75fc4: tbnz            w0, #4, #0xc76000
    // 0xc75fc8: ldr             x1, [fp, #0x18]
    // 0xc75fcc: ldr             x0, [fp, #0x10]
    // 0xc75fd0: LoadField: r2 = r0->field_f
    //     0xc75fd0: ldur            w2, [x0, #0xf]
    // 0xc75fd4: DecompressPointer r2
    //     0xc75fd4: add             x2, x2, HEAP, lsl #32
    // 0xc75fd8: LoadField: r0 = r1->field_f
    //     0xc75fd8: ldur            w0, [x1, #0xf]
    // 0xc75fdc: DecompressPointer r0
    //     0xc75fdc: add             x0, x0, HEAP, lsl #32
    // 0xc75fe0: r16 = <InlineSpan>
    //     0xc75fe0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ff8] TypeArguments: <InlineSpan>
    //     0xc75fe4: ldr             x16, [x16, #0xff8]
    // 0xc75fe8: stp             x2, x16, [SP, #-0x10]!
    // 0xc75fec: SaveReg r0
    //     0xc75fec: str             x0, [SP, #-8]!
    // 0xc75ff0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc75ff0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc75ff4: r0 = listEquals()
    //     0xc75ff4: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc75ff8: add             SP, SP, #0x18
    // 0xc75ffc: b               #0xc76004
    // 0xc76000: r0 = false
    //     0xc76000: add             x0, NULL, #0x30  ; false
    // 0xc76004: LeaveFrame
    //     0xc76004: mov             SP, fp
    //     0xc76008: ldp             fp, lr, [SP], #0x10
    // 0xc7600c: ret
    //     0xc7600c: ret             
    // 0xc76010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc76010: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc76014: b               #0xc75e38
  }
  _ computeSemanticsInformation(/* No info */) {
    // ** addr: 0xccefd4, size: 0x3b8
    // 0xccefd4: EnterFrame
    //     0xccefd4: stp             fp, lr, [SP, #-0x10]!
    //     0xccefd8: mov             fp, SP
    // 0xccefdc: AllocStack(0x40)
    //     0xccefdc: sub             SP, SP, #0x40
    // 0xccefe0: SetupParameters(TextSpan this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, {dynamic inheritedSpellOut = false /* r0, fp-0x18 */})
    //     0xccefe0: mov             x0, x4
    //     0xccefe4: ldur            w1, [x0, #0x13]
    //     0xccefe8: add             x1, x1, HEAP, lsl #32
    //     0xccefec: sub             x2, x1, #4
    //     0xcceff0: add             x3, fp, w2, sxtw #2
    //     0xcceff4: ldr             x3, [x3, #0x18]
    //     0xcceff8: stur            x3, [fp, #-0x28]
    //     0xcceffc: add             x4, fp, w2, sxtw #2
    //     0xccf000: ldr             x4, [x4, #0x10]
    //     0xccf004: stur            x4, [fp, #-0x20]
    //     0xccf008: ldur            w2, [x0, #0x1f]
    //     0xccf00c: add             x2, x2, HEAP, lsl #32
    //     0xccf010: add             x16, PP, #0x29, lsl #12  ; [pp+0x29040] "inheritedSpellOut"
    //     0xccf014: ldr             x16, [x16, #0x40]
    //     0xccf018: cmp             w2, w16
    //     0xccf01c: b.ne            #0xccf03c
    //     0xccf020: ldur            w2, [x0, #0x23]
    //     0xccf024: add             x2, x2, HEAP, lsl #32
    //     0xccf028: sub             w0, w1, w2
    //     0xccf02c: add             x1, fp, w0, sxtw #2
    //     0xccf030: ldr             x1, [x1, #8]
    //     0xccf034: mov             x0, x1
    //     0xccf038: b               #0xccf040
    //     0xccf03c: add             x0, NULL, #0x30  ; false
    //     0xccf040: stur            x0, [fp, #-0x18]
    // 0xccf044: CheckStackOverflow
    //     0xccf044: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccf048: cmp             SP, x16
    //     0xccf04c: b.ls            #0xccf374
    // 0xccf050: LoadField: r1 = r3->field_b
    //     0xccf050: ldur            w1, [x3, #0xb]
    // 0xccf054: DecompressPointer r1
    //     0xccf054: add             x1, x1, HEAP, lsl #32
    // 0xccf058: stur            x1, [fp, #-0x10]
    // 0xccf05c: cmp             w1, NULL
    // 0xccf060: b.eq            #0xccf25c
    // 0xccf064: LoadField: r2 = r1->field_7
    //     0xccf064: ldur            w2, [x1, #7]
    // 0xccf068: DecompressPointer r2
    //     0xccf068: add             x2, x2, HEAP, lsl #32
    // 0xccf06c: stur            x2, [fp, #-8]
    // 0xccf070: r16 = <StringAttribute>
    //     0xccf070: ldr             x16, [PP, #0x48a0]  ; [pp+0x48a0] TypeArguments: <StringAttribute>
    // 0xccf074: stp             xzr, x16, [SP, #-0x10]!
    // 0xccf078: r0 = _GrowableList()
    //     0xccf078: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xccf07c: add             SP, SP, #0x10
    // 0xccf080: mov             x1, x0
    // 0xccf084: ldur            x0, [fp, #-0x18]
    // 0xccf088: stur            x1, [fp, #-0x38]
    // 0xccf08c: tbnz            w0, #4, #0xccf170
    // 0xccf090: ldur            x2, [fp, #-8]
    // 0xccf094: r3 = LoadInt32Instr(r2)
    //     0xccf094: sbfx            x3, x2, #1, #0x1f
    // 0xccf098: stur            x3, [fp, #-0x30]
    // 0xccf09c: cmp             x3, #0
    // 0xccf0a0: b.le            #0xccf168
    // 0xccf0a4: r0 = TextRange()
    //     0xccf0a4: bl              #0x51026c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0xccf0a8: mov             x1, x0
    // 0xccf0ac: r0 = 0
    //     0xccf0ac: mov             x0, #0
    // 0xccf0b0: stur            x1, [fp, #-8]
    // 0xccf0b4: StoreField: r1->field_7 = r0
    //     0xccf0b4: stur            x0, [x1, #7]
    // 0xccf0b8: ldur            x0, [fp, #-0x30]
    // 0xccf0bc: StoreField: r1->field_f = r0
    //     0xccf0bc: stur            x0, [x1, #0xf]
    // 0xccf0c0: r0 = SpellOutStringAttribute()
    //     0xccf0c0: bl              #0xc9c644  ; AllocateSpellOutStringAttributeStub -> SpellOutStringAttribute (size=0x10)
    // 0xccf0c4: stur            x0, [fp, #-0x40]
    // 0xccf0c8: ldur            x16, [fp, #-8]
    // 0xccf0cc: stp             x16, x0, [SP, #-0x10]!
    // 0xccf0d0: r0 = SpellOutStringAttribute()
    //     0xccf0d0: bl              #0xc9c2b0  ; [dart:ui] SpellOutStringAttribute::SpellOutStringAttribute
    // 0xccf0d4: add             SP, SP, #0x10
    // 0xccf0d8: ldur            x0, [fp, #-0x38]
    // 0xccf0dc: LoadField: r1 = r0->field_b
    //     0xccf0dc: ldur            w1, [x0, #0xb]
    // 0xccf0e0: DecompressPointer r1
    //     0xccf0e0: add             x1, x1, HEAP, lsl #32
    // 0xccf0e4: stur            x1, [fp, #-8]
    // 0xccf0e8: LoadField: r2 = r0->field_f
    //     0xccf0e8: ldur            w2, [x0, #0xf]
    // 0xccf0ec: DecompressPointer r2
    //     0xccf0ec: add             x2, x2, HEAP, lsl #32
    // 0xccf0f0: LoadField: r3 = r2->field_b
    //     0xccf0f0: ldur            w3, [x2, #0xb]
    // 0xccf0f4: DecompressPointer r3
    //     0xccf0f4: add             x3, x3, HEAP, lsl #32
    // 0xccf0f8: cmp             w1, w3
    // 0xccf0fc: b.ne            #0xccf10c
    // 0xccf100: SaveReg r0
    //     0xccf100: str             x0, [SP, #-8]!
    // 0xccf104: r0 = _growToNextCapacity()
    //     0xccf104: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xccf108: add             SP, SP, #8
    // 0xccf10c: ldur            x2, [fp, #-0x38]
    // 0xccf110: ldur            x0, [fp, #-8]
    // 0xccf114: r3 = LoadInt32Instr(r0)
    //     0xccf114: sbfx            x3, x0, #1, #0x1f
    // 0xccf118: add             x0, x3, #1
    // 0xccf11c: lsl             x1, x0, #1
    // 0xccf120: StoreField: r2->field_b = r1
    //     0xccf120: stur            w1, [x2, #0xb]
    // 0xccf124: mov             x1, x3
    // 0xccf128: cmp             x1, x0
    // 0xccf12c: b.hs            #0xccf37c
    // 0xccf130: LoadField: r1 = r2->field_f
    //     0xccf130: ldur            w1, [x2, #0xf]
    // 0xccf134: DecompressPointer r1
    //     0xccf134: add             x1, x1, HEAP, lsl #32
    // 0xccf138: ldur            x0, [fp, #-0x40]
    // 0xccf13c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xccf13c: add             x25, x1, x3, lsl #2
    //     0xccf140: add             x25, x25, #0xf
    //     0xccf144: str             w0, [x25]
    //     0xccf148: tbz             w0, #0, #0xccf164
    //     0xccf14c: ldurb           w16, [x1, #-1]
    //     0xccf150: ldurb           w17, [x0, #-1]
    //     0xccf154: and             x16, x17, x16, lsr #2
    //     0xccf158: tst             x16, HEAP, lsr #32
    //     0xccf15c: b.eq            #0xccf164
    //     0xccf160: bl              #0xd67e5c
    // 0xccf164: b               #0xccf174
    // 0xccf168: mov             x2, x1
    // 0xccf16c: b               #0xccf174
    // 0xccf170: mov             x2, x1
    // 0xccf174: ldur            x0, [fp, #-0x28]
    // 0xccf178: ldur            x1, [fp, #-0x20]
    // 0xccf17c: ldur            x3, [fp, #-0x10]
    // 0xccf180: LoadField: r4 = r0->field_13
    //     0xccf180: ldur            w4, [x0, #0x13]
    // 0xccf184: DecompressPointer r4
    //     0xccf184: add             x4, x4, HEAP, lsl #32
    // 0xccf188: stur            x4, [fp, #-8]
    // 0xccf18c: r0 = InlineSpanSemanticsInformation()
    //     0xccf18c: bl              #0x647e44  ; AllocateInlineSpanSemanticsInformationStub -> InlineSpanSemanticsInformation (size=0x20)
    // 0xccf190: mov             x1, x0
    // 0xccf194: ldur            x0, [fp, #-0x10]
    // 0xccf198: stur            x1, [fp, #-0x40]
    // 0xccf19c: StoreField: r1->field_7 = r0
    //     0xccf19c: stur            w0, [x1, #7]
    // 0xccf1a0: r0 = false
    //     0xccf1a0: add             x0, NULL, #0x30  ; false
    // 0xccf1a4: StoreField: r1->field_13 = r0
    //     0xccf1a4: stur            w0, [x1, #0x13]
    // 0xccf1a8: ldur            x0, [fp, #-0x38]
    // 0xccf1ac: StoreField: r1->field_1b = r0
    //     0xccf1ac: stur            w0, [x1, #0x1b]
    // 0xccf1b0: ldur            x0, [fp, #-8]
    // 0xccf1b4: StoreField: r1->field_f = r0
    //     0xccf1b4: stur            w0, [x1, #0xf]
    // 0xccf1b8: cmp             w0, NULL
    // 0xccf1bc: r16 = true
    //     0xccf1bc: add             x16, NULL, #0x20  ; true
    // 0xccf1c0: r17 = false
    //     0xccf1c0: add             x17, NULL, #0x30  ; false
    // 0xccf1c4: csel            x2, x16, x17, ne
    // 0xccf1c8: StoreField: r1->field_17 = r2
    //     0xccf1c8: stur            w2, [x1, #0x17]
    // 0xccf1cc: ldur            x0, [fp, #-0x20]
    // 0xccf1d0: LoadField: r2 = r0->field_b
    //     0xccf1d0: ldur            w2, [x0, #0xb]
    // 0xccf1d4: DecompressPointer r2
    //     0xccf1d4: add             x2, x2, HEAP, lsl #32
    // 0xccf1d8: stur            x2, [fp, #-8]
    // 0xccf1dc: LoadField: r3 = r0->field_f
    //     0xccf1dc: ldur            w3, [x0, #0xf]
    // 0xccf1e0: DecompressPointer r3
    //     0xccf1e0: add             x3, x3, HEAP, lsl #32
    // 0xccf1e4: LoadField: r4 = r3->field_b
    //     0xccf1e4: ldur            w4, [x3, #0xb]
    // 0xccf1e8: DecompressPointer r4
    //     0xccf1e8: add             x4, x4, HEAP, lsl #32
    // 0xccf1ec: cmp             w2, w4
    // 0xccf1f0: b.ne            #0xccf200
    // 0xccf1f4: SaveReg r0
    //     0xccf1f4: str             x0, [SP, #-8]!
    // 0xccf1f8: r0 = _growToNextCapacity()
    //     0xccf1f8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xccf1fc: add             SP, SP, #8
    // 0xccf200: ldur            x2, [fp, #-0x20]
    // 0xccf204: ldur            x0, [fp, #-8]
    // 0xccf208: r3 = LoadInt32Instr(r0)
    //     0xccf208: sbfx            x3, x0, #1, #0x1f
    // 0xccf20c: add             x0, x3, #1
    // 0xccf210: lsl             x1, x0, #1
    // 0xccf214: StoreField: r2->field_b = r1
    //     0xccf214: stur            w1, [x2, #0xb]
    // 0xccf218: mov             x1, x3
    // 0xccf21c: cmp             x1, x0
    // 0xccf220: b.hs            #0xccf380
    // 0xccf224: LoadField: r1 = r2->field_f
    //     0xccf224: ldur            w1, [x2, #0xf]
    // 0xccf228: DecompressPointer r1
    //     0xccf228: add             x1, x1, HEAP, lsl #32
    // 0xccf22c: ldur            x0, [fp, #-0x40]
    // 0xccf230: ArrayStore: r1[r3] = r0  ; List_4
    //     0xccf230: add             x25, x1, x3, lsl #2
    //     0xccf234: add             x25, x25, #0xf
    //     0xccf238: str             w0, [x25]
    //     0xccf23c: tbz             w0, #0, #0xccf258
    //     0xccf240: ldurb           w16, [x1, #-1]
    //     0xccf244: ldurb           w17, [x0, #-1]
    //     0xccf248: and             x16, x17, x16, lsr #2
    //     0xccf24c: tst             x16, HEAP, lsr #32
    //     0xccf250: b.eq            #0xccf258
    //     0xccf254: bl              #0xd67e5c
    // 0xccf258: b               #0xccf260
    // 0xccf25c: mov             x2, x4
    // 0xccf260: ldur            x0, [fp, #-0x28]
    // 0xccf264: LoadField: r1 = r0->field_f
    //     0xccf264: ldur            w1, [x0, #0xf]
    // 0xccf268: DecompressPointer r1
    //     0xccf268: add             x1, x1, HEAP, lsl #32
    // 0xccf26c: cmp             w1, NULL
    // 0xccf270: b.eq            #0xccf364
    // 0xccf274: r0 = LoadClassIdInstr(r1)
    //     0xccf274: ldur            x0, [x1, #-1]
    //     0xccf278: ubfx            x0, x0, #0xc, #0x14
    // 0xccf27c: SaveReg r1
    //     0xccf27c: str             x1, [SP, #-8]!
    // 0xccf280: r0 = GDT[cid_x0 + 0xb940]()
    //     0xccf280: mov             x17, #0xb940
    //     0xccf284: add             lr, x0, x17
    //     0xccf288: ldr             lr, [x21, lr, lsl #3]
    //     0xccf28c: blr             lr
    // 0xccf290: add             SP, SP, #8
    // 0xccf294: mov             x1, x0
    // 0xccf298: stur            x1, [fp, #-8]
    // 0xccf29c: CheckStackOverflow
    //     0xccf29c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccf2a0: cmp             SP, x16
    //     0xccf2a4: b.ls            #0xccf384
    // 0xccf2a8: r0 = LoadClassIdInstr(r1)
    //     0xccf2a8: ldur            x0, [x1, #-1]
    //     0xccf2ac: ubfx            x0, x0, #0xc, #0x14
    // 0xccf2b0: SaveReg r1
    //     0xccf2b0: str             x1, [SP, #-8]!
    // 0xccf2b4: r0 = GDT[cid_x0 + 0x541]()
    //     0xccf2b4: add             lr, x0, #0x541
    //     0xccf2b8: ldr             lr, [x21, lr, lsl #3]
    //     0xccf2bc: blr             lr
    // 0xccf2c0: add             SP, SP, #8
    // 0xccf2c4: tbnz            w0, #4, #0xccf364
    // 0xccf2c8: ldur            x1, [fp, #-8]
    // 0xccf2cc: r0 = LoadClassIdInstr(r1)
    //     0xccf2cc: ldur            x0, [x1, #-1]
    //     0xccf2d0: ubfx            x0, x0, #0xc, #0x14
    // 0xccf2d4: SaveReg r1
    //     0xccf2d4: str             x1, [SP, #-8]!
    // 0xccf2d8: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xccf2d8: add             lr, x0, #0x5ca
    //     0xccf2dc: ldr             lr, [x21, lr, lsl #3]
    //     0xccf2e0: blr             lr
    // 0xccf2e4: add             SP, SP, #8
    // 0xccf2e8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xccf2e8: mov             x1, #0x76
    //     0xccf2ec: tbz             w0, #0, #0xccf2fc
    //     0xccf2f0: ldur            x1, [x0, #-1]
    //     0xccf2f4: ubfx            x1, x1, #0xc, #0x14
    //     0xccf2f8: lsl             x1, x1, #1
    // 0xccf2fc: r2 = LoadInt32Instr(r1)
    //     0xccf2fc: sbfx            x2, x1, #1, #0x1f
    // 0xccf300: cmp             x2, #0xd91
    // 0xccf304: b.lt            #0xccf334
    // 0xccf308: cmp             x2, #0xd93
    // 0xccf30c: b.gt            #0xccf334
    // 0xccf310: ldur            x16, [fp, #-0x20]
    // 0xccf314: stp             x16, x0, [SP, #-0x10]!
    // 0xccf318: ldur            x16, [fp, #-0x18]
    // 0xccf31c: SaveReg r16
    //     0xccf31c: str             x16, [SP, #-8]!
    // 0xccf320: r4 = const [0, 0x3, 0x3, 0x2, inheritedSpellOut, 0x2, null]
    //     0xccf320: add             x4, PP, #0x29, lsl #12  ; [pp+0x29048] List(7) [0, 0x3, 0x3, 0x2, "inheritedSpellOut", 0x2, Null]
    //     0xccf324: ldr             x4, [x4, #0x48]
    // 0xccf328: r0 = computeSemanticsInformation()
    //     0xccf328: bl              #0xccefd4  ; [package:flutter/src/painting/text_span.dart] TextSpan::computeSemanticsInformation
    // 0xccf32c: add             SP, SP, #0x18
    // 0xccf330: b               #0xccf35c
    // 0xccf334: r1 = LoadClassIdInstr(r0)
    //     0xccf334: ldur            x1, [x0, #-1]
    //     0xccf338: ubfx            x1, x1, #0xc, #0x14
    // 0xccf33c: ldur            x16, [fp, #-0x20]
    // 0xccf340: stp             x16, x0, [SP, #-0x10]!
    // 0xccf344: mov             x0, x1
    // 0xccf348: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xccf348: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xccf34c: r0 = GDT[cid_x0 + -0xe63]()
    //     0xccf34c: sub             lr, x0, #0xe63
    //     0xccf350: ldr             lr, [x21, lr, lsl #3]
    //     0xccf354: blr             lr
    // 0xccf358: add             SP, SP, #0x10
    // 0xccf35c: ldur            x1, [fp, #-8]
    // 0xccf360: b               #0xccf29c
    // 0xccf364: r0 = Null
    //     0xccf364: mov             x0, NULL
    // 0xccf368: LeaveFrame
    //     0xccf368: mov             SP, fp
    //     0xccf36c: ldp             fp, lr, [SP], #0x10
    // 0xccf370: ret
    //     0xccf370: ret             
    // 0xccf374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf378: b               #0xccf050
    // 0xccf37c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xccf37c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xccf380: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xccf380: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xccf384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf384: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf388: b               #0xccf2a8
  }
  _ build(/* No info */) {
    // ** addr: 0xcd238c, size: 0x320
    // 0xcd238c: EnterFrame
    //     0xcd238c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd2390: mov             fp, SP
    // 0xcd2394: AllocStack(0x80)
    //     0xcd2394: sub             SP, SP, #0x80
    // 0xcd2398: CheckStackOverflow
    //     0xcd2398: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd239c: cmp             SP, x16
    //     0xcd23a0: b.ls            #0xcd2698
    // 0xcd23a4: ldr             x0, [fp, #0x28]
    // 0xcd23a8: LoadField: r1 = r0->field_7
    //     0xcd23a8: ldur            w1, [x0, #7]
    // 0xcd23ac: DecompressPointer r1
    //     0xcd23ac: add             x1, x1, HEAP, lsl #32
    // 0xcd23b0: cmp             w1, NULL
    // 0xcd23b4: r16 = true
    //     0xcd23b4: add             x16, NULL, #0x20  ; true
    // 0xcd23b8: r17 = false
    //     0xcd23b8: add             x17, NULL, #0x30  ; false
    // 0xcd23bc: csel            x2, x16, x17, ne
    // 0xcd23c0: stur            x2, [fp, #-0x50]
    // 0xcd23c4: tbnz            w2, #4, #0xcd23f4
    // 0xcd23c8: ldr             d0, [fp, #0x10]
    // 0xcd23cc: cmp             w1, NULL
    // 0xcd23d0: b.eq            #0xcd26a0
    // 0xcd23d4: SaveReg r1
    //     0xcd23d4: str             x1, [SP, #-8]!
    // 0xcd23d8: SaveReg d0
    //     0xcd23d8: str             d0, [SP, #-8]!
    // 0xcd23dc: r0 = getTextStyle()
    //     0xcd23dc: bl              #0x51c6f8  ; [package:flutter/src/painting/text_style.dart] TextStyle::getTextStyle
    // 0xcd23e0: add             SP, SP, #0x10
    // 0xcd23e4: ldr             x16, [fp, #0x20]
    // 0xcd23e8: stp             x0, x16, [SP, #-0x10]!
    // 0xcd23ec: r0 = pushStyle()
    //     0xcd23ec: bl              #0x51b214  ; [dart:ui] ParagraphBuilder::pushStyle
    // 0xcd23f0: add             SP, SP, #0x10
    // 0xcd23f4: ldr             x0, [fp, #0x28]
    // 0xcd23f8: LoadField: r1 = r0->field_b
    //     0xcd23f8: ldur            w1, [x0, #0xb]
    // 0xcd23fc: DecompressPointer r1
    //     0xcd23fc: add             x1, x1, HEAP, lsl #32
    // 0xcd2400: cmp             w1, NULL
    // 0xcd2404: b.eq            #0xcd2434
    // 0xcd2408: ldr             x3, [fp, #0x20]
    // 0xcd240c: ldr             x2, [fp, #0x18]
    // 0xcd2410: stp             x1, x3, [SP, #-0x10]!
    // 0xcd2414: r0 = addText()
    //     0xcd2414: bl              #0x51ae44  ; [dart:ui] ParagraphBuilder::addText
    // 0xcd2418: add             SP, SP, #0x10
    // 0xcd241c: ldr             x3, [fp, #0x28]
    // 0xcd2420: ldr             x2, [fp, #0x20]
    // 0xcd2424: ldr             x1, [fp, #0x18]
    // 0xcd2428: ldr             d0, [fp, #0x10]
    // 0xcd242c: ldur            x0, [fp, #-0x50]
    // 0xcd2430: b               #0xcd253c
    // 0xcd2434: ldr             x0, [fp, #0x28]
    // 0xcd2438: ldr             x3, [fp, #0x20]
    // 0xcd243c: ldr             x2, [fp, #0x18]
    // 0xcd2440: ldr             d0, [fp, #0x10]
    // 0xcd2444: ldur            x1, [fp, #-0x50]
    // 0xcd2448: b               #0xcd2560
    // 0xcd244c: sub             SP, fp, #0x80
    // 0xcd2450: mov             x2, x0
    // 0xcd2454: stur            x0, [fp, #-0x50]
    // 0xcd2458: mov             x0, x1
    // 0xcd245c: stur            x1, [fp, #-0x58]
    // 0xcd2460: r1 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0xcd2460: mov             x1, #0x76
    //     0xcd2464: tbz             w2, #0, #0xcd2474
    //     0xcd2468: ldur            x1, [x2, #-1]
    //     0xcd246c: ubfx            x1, x1, #0xc, #0x14
    //     0xcd2470: lsl             x1, x1, #1
    // 0xcd2474: r3 = LoadInt32Instr(r1)
    //     0xcd2474: sbfx            x3, x1, #1, #0x1f
    // 0xcd2478: r17 = 6172
    //     0xcd2478: mov             x17, #0x181c
    // 0xcd247c: cmp             x3, x17
    // 0xcd2480: b.lt            #0xcd2680
    // 0xcd2484: r17 = 6174
    //     0xcd2484: mov             x17, #0x181e
    // 0xcd2488: cmp             x3, x17
    // 0xcd248c: b.gt            #0xcd2670
    // 0xcd2490: ldr             x7, [fp, #0x28]
    // 0xcd2494: ldr             x6, [fp, #0x20]
    // 0xcd2498: ldr             x5, [fp, #0x18]
    // 0xcd249c: ldr             x4, [fp, #0x10]
    // 0xcd24a0: ldur            x3, [fp, #-0x30]
    // 0xcd24a4: r1 = <List<Object>>
    //     0xcd24a4: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xcd24a8: r0 = ErrorDescription()
    //     0xcd24a8: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xcd24ac: stur            x0, [fp, #-0x60]
    // 0xcd24b0: r16 = "while building a TextSpan"
    //     0xcd24b0: add             x16, PP, #0x29, lsl #12  ; [pp+0x29068] "while building a TextSpan"
    //     0xcd24b4: ldr             x16, [x16, #0x68]
    // 0xcd24b8: stp             x16, x0, [SP, #-0x10]!
    // 0xcd24bc: r16 = Instance_DiagnosticLevel
    //     0xcd24bc: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xcd24c0: SaveReg r16
    //     0xcd24c0: str             x16, [SP, #-8]!
    // 0xcd24c4: r0 = _ErrorDiagnostic()
    //     0xcd24c4: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xcd24c8: add             SP, SP, #0x18
    // 0xcd24cc: r0 = FlutterErrorDetails()
    //     0xcd24cc: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0xcd24d0: mov             x1, x0
    // 0xcd24d4: ldur            x0, [fp, #-0x50]
    // 0xcd24d8: StoreField: r1->field_7 = r0
    //     0xcd24d8: stur            w0, [x1, #7]
    // 0xcd24dc: ldur            x2, [fp, #-0x58]
    // 0xcd24e0: StoreField: r1->field_b = r2
    //     0xcd24e0: stur            w2, [x1, #0xb]
    // 0xcd24e4: r0 = "painting library"
    //     0xcd24e4: add             x0, PP, #0x29, lsl #12  ; [pp+0x29070] "painting library"
    //     0xcd24e8: ldr             x0, [x0, #0x70]
    // 0xcd24ec: StoreField: r1->field_f = r0
    //     0xcd24ec: stur            w0, [x1, #0xf]
    // 0xcd24f0: ldur            x0, [fp, #-0x60]
    // 0xcd24f4: StoreField: r1->field_13 = r0
    //     0xcd24f4: stur            w0, [x1, #0x13]
    // 0xcd24f8: r0 = false
    //     0xcd24f8: add             x0, NULL, #0x30  ; false
    // 0xcd24fc: StoreField: r1->field_1f = r0
    //     0xcd24fc: stur            w0, [x1, #0x1f]
    // 0xcd2500: SaveReg r1
    //     0xcd2500: str             x1, [SP, #-8]!
    // 0xcd2504: r0 = reportError()
    //     0xcd2504: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xcd2508: add             SP, SP, #8
    // 0xcd250c: ldr             x16, [fp, #0x20]
    // 0xcd2510: r30 = "�"
    //     0xcd2510: add             lr, PP, #0x29, lsl #12  ; [pp+0x29078] "�"
    //     0xcd2514: ldr             lr, [lr, #0x78]
    // 0xcd2518: stp             lr, x16, [SP, #-0x10]!
    // 0xcd251c: r0 = addText()
    //     0xcd251c: bl              #0x51ae44  ; [dart:ui] ParagraphBuilder::addText
    // 0xcd2520: add             SP, SP, #0x10
    // 0xcd2524: ldr             x0, [fp, #0x10]
    // 0xcd2528: LoadField: d0 = r0->field_7
    //     0xcd2528: ldur            d0, [x0, #7]
    // 0xcd252c: ldr             x3, [fp, #0x28]
    // 0xcd2530: ldr             x2, [fp, #0x20]
    // 0xcd2534: ldr             x1, [fp, #0x18]
    // 0xcd2538: ldur            x0, [fp, #-0x30]
    // 0xcd253c: mov             x16, x2
    // 0xcd2540: mov             x2, x3
    // 0xcd2544: mov             x3, x16
    // 0xcd2548: mov             x16, x1
    // 0xcd254c: mov             x1, x2
    // 0xcd2550: mov             x2, x16
    // 0xcd2554: mov             x16, x0
    // 0xcd2558: mov             x0, x1
    // 0xcd255c: mov             x1, x16
    // 0xcd2560: stur            x3, [fp, #-0x60]
    // 0xcd2564: stur            x2, [fp, #-0x68]
    // 0xcd2568: stur            x1, [fp, #-0x70]
    // 0xcd256c: stur            d0, [fp, #-0x80]
    // 0xcd2570: LoadField: r4 = r0->field_f
    //     0xcd2570: ldur            w4, [x0, #0xf]
    // 0xcd2574: DecompressPointer r4
    //     0xcd2574: add             x4, x4, HEAP, lsl #32
    // 0xcd2578: cmp             w4, NULL
    // 0xcd257c: b.eq            #0xcd2638
    // 0xcd2580: r0 = LoadClassIdInstr(r4)
    //     0xcd2580: ldur            x0, [x4, #-1]
    //     0xcd2584: ubfx            x0, x0, #0xc, #0x14
    // 0xcd2588: SaveReg r4
    //     0xcd2588: str             x4, [SP, #-8]!
    // 0xcd258c: r0 = GDT[cid_x0 + 0xb940]()
    //     0xcd258c: mov             x17, #0xb940
    //     0xcd2590: add             lr, x0, x17
    //     0xcd2594: ldr             lr, [x21, lr, lsl #3]
    //     0xcd2598: blr             lr
    // 0xcd259c: add             SP, SP, #8
    // 0xcd25a0: mov             x1, x0
    // 0xcd25a4: stur            x1, [fp, #-0x78]
    // 0xcd25a8: ldur            d0, [fp, #-0x80]
    // 0xcd25ac: CheckStackOverflow
    //     0xcd25ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd25b0: cmp             SP, x16
    //     0xcd25b4: b.ls            #0xcd26a4
    // 0xcd25b8: r0 = LoadClassIdInstr(r1)
    //     0xcd25b8: ldur            x0, [x1, #-1]
    //     0xcd25bc: ubfx            x0, x0, #0xc, #0x14
    // 0xcd25c0: SaveReg r1
    //     0xcd25c0: str             x1, [SP, #-8]!
    // 0xcd25c4: r0 = GDT[cid_x0 + 0x541]()
    //     0xcd25c4: add             lr, x0, #0x541
    //     0xcd25c8: ldr             lr, [x21, lr, lsl #3]
    //     0xcd25cc: blr             lr
    // 0xcd25d0: add             SP, SP, #8
    // 0xcd25d4: tbnz            w0, #4, #0xcd2638
    // 0xcd25d8: ldur            d0, [fp, #-0x80]
    // 0xcd25dc: ldur            x1, [fp, #-0x78]
    // 0xcd25e0: r0 = LoadClassIdInstr(r1)
    //     0xcd25e0: ldur            x0, [x1, #-1]
    //     0xcd25e4: ubfx            x0, x0, #0xc, #0x14
    // 0xcd25e8: SaveReg r1
    //     0xcd25e8: str             x1, [SP, #-8]!
    // 0xcd25ec: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xcd25ec: add             lr, x0, #0x5ca
    //     0xcd25f0: ldr             lr, [x21, lr, lsl #3]
    //     0xcd25f4: blr             lr
    // 0xcd25f8: add             SP, SP, #8
    // 0xcd25fc: r1 = LoadClassIdInstr(r0)
    //     0xcd25fc: ldur            x1, [x0, #-1]
    //     0xcd2600: ubfx            x1, x1, #0xc, #0x14
    // 0xcd2604: ldur            x16, [fp, #-0x60]
    // 0xcd2608: stp             x16, x0, [SP, #-0x10]!
    // 0xcd260c: ldur            x16, [fp, #-0x68]
    // 0xcd2610: SaveReg r16
    //     0xcd2610: str             x16, [SP, #-8]!
    // 0xcd2614: ldur            d0, [fp, #-0x80]
    // 0xcd2618: SaveReg d0
    //     0xcd2618: str             d0, [SP, #-8]!
    // 0xcd261c: mov             x0, x1
    // 0xcd2620: r0 = GDT[cid_x0 + -0xe79]()
    //     0xcd2620: sub             lr, x0, #0xe79
    //     0xcd2624: ldr             lr, [x21, lr, lsl #3]
    //     0xcd2628: blr             lr
    // 0xcd262c: add             SP, SP, #0x20
    // 0xcd2630: ldur            x1, [fp, #-0x78]
    // 0xcd2634: b               #0xcd25a8
    // 0xcd2638: ldur            x1, [fp, #-0x70]
    // 0xcd263c: mov             x0, x1
    // 0xcd2640: tbnz            w0, #5, #0xcd2648
    // 0xcd2644: r0 = AssertBoolean()
    //     0xcd2644: bl              #0xd67df0  ; AssertBooleanStub
    // 0xcd2648: ldur            x0, [fp, #-0x70]
    // 0xcd264c: tbnz            w0, #4, #0xcd2660
    // 0xcd2650: ldur            x16, [fp, #-0x60]
    // 0xcd2654: SaveReg r16
    //     0xcd2654: str             x16, [SP, #-8]!
    // 0xcd2658: r0 = pop()
    //     0xcd2658: bl              #0xccfad4  ; [dart:ui] ParagraphBuilder::pop
    // 0xcd265c: add             SP, SP, #8
    // 0xcd2660: r0 = Null
    //     0xcd2660: mov             x0, NULL
    // 0xcd2664: LeaveFrame
    //     0xcd2664: mov             SP, fp
    //     0xcd2668: ldp             fp, lr, [SP], #0x10
    // 0xcd266c: ret
    //     0xcd266c: ret             
    // 0xcd2670: mov             x16, x0
    // 0xcd2674: mov             x0, x2
    // 0xcd2678: mov             x2, x16
    // 0xcd267c: b               #0xcd268c
    // 0xcd2680: mov             x16, x0
    // 0xcd2684: mov             x0, x2
    // 0xcd2688: mov             x2, x16
    // 0xcd268c: mov             x1, x2
    // 0xcd2690: r0 = ReThrow()
    //     0xcd2690: bl              #0xd67e14  ; ReThrowStub
    // 0xcd2694: brk             #0
    // 0xcd2698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd2698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd269c: b               #0xcd23a4
    // 0xcd26a0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd26a0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd26a4: r0 = StackOverflowSharedWithFPURegs()
    //     0xcd26a4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcd26a8: b               #0xcd25b8
  }
  _ computeToPlainText(/* No info */) {
    // ** addr: 0xcd905c, size: 0x140
    // 0xcd905c: EnterFrame
    //     0xcd905c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd9060: mov             fp, SP
    // 0xcd9064: AllocStack(0x10)
    //     0xcd9064: sub             SP, SP, #0x10
    // 0xcd9068: SetupParameters(TextSpan this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0xcd9068: mov             x0, x4
    //     0xcd906c: ldur            w1, [x0, #0x13]
    //     0xcd9070: add             x1, x1, HEAP, lsl #32
    //     0xcd9074: sub             x0, x1, #4
    //     0xcd9078: add             x1, fp, w0, sxtw #2
    //     0xcd907c: ldr             x1, [x1, #0x18]
    //     0xcd9080: stur            x1, [fp, #-0x10]
    //     0xcd9084: add             x2, fp, w0, sxtw #2
    //     0xcd9088: ldr             x2, [x2, #0x10]
    //     0xcd908c: stur            x2, [fp, #-8]
    // 0xcd9090: CheckStackOverflow
    //     0xcd9090: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd9094: cmp             SP, x16
    //     0xcd9098: b.ls            #0xcd918c
    // 0xcd909c: LoadField: r0 = r1->field_b
    //     0xcd909c: ldur            w0, [x1, #0xb]
    // 0xcd90a0: DecompressPointer r0
    //     0xcd90a0: add             x0, x0, HEAP, lsl #32
    // 0xcd90a4: cmp             w0, NULL
    // 0xcd90a8: b.eq            #0xcd90b8
    // 0xcd90ac: stp             x0, x2, [SP, #-0x10]!
    // 0xcd90b0: r0 = write()
    //     0xcd90b0: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xcd90b4: add             SP, SP, #0x10
    // 0xcd90b8: ldur            x0, [fp, #-0x10]
    // 0xcd90bc: LoadField: r1 = r0->field_f
    //     0xcd90bc: ldur            w1, [x0, #0xf]
    // 0xcd90c0: DecompressPointer r1
    //     0xcd90c0: add             x1, x1, HEAP, lsl #32
    // 0xcd90c4: cmp             w1, NULL
    // 0xcd90c8: b.eq            #0xcd917c
    // 0xcd90cc: r0 = LoadClassIdInstr(r1)
    //     0xcd90cc: ldur            x0, [x1, #-1]
    //     0xcd90d0: ubfx            x0, x0, #0xc, #0x14
    // 0xcd90d4: SaveReg r1
    //     0xcd90d4: str             x1, [SP, #-8]!
    // 0xcd90d8: r0 = GDT[cid_x0 + 0xb940]()
    //     0xcd90d8: mov             x17, #0xb940
    //     0xcd90dc: add             lr, x0, x17
    //     0xcd90e0: ldr             lr, [x21, lr, lsl #3]
    //     0xcd90e4: blr             lr
    // 0xcd90e8: add             SP, SP, #8
    // 0xcd90ec: mov             x1, x0
    // 0xcd90f0: stur            x1, [fp, #-0x10]
    // 0xcd90f4: CheckStackOverflow
    //     0xcd90f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd90f8: cmp             SP, x16
    //     0xcd90fc: b.ls            #0xcd9194
    // 0xcd9100: r0 = LoadClassIdInstr(r1)
    //     0xcd9100: ldur            x0, [x1, #-1]
    //     0xcd9104: ubfx            x0, x0, #0xc, #0x14
    // 0xcd9108: SaveReg r1
    //     0xcd9108: str             x1, [SP, #-8]!
    // 0xcd910c: r0 = GDT[cid_x0 + 0x541]()
    //     0xcd910c: add             lr, x0, #0x541
    //     0xcd9110: ldr             lr, [x21, lr, lsl #3]
    //     0xcd9114: blr             lr
    // 0xcd9118: add             SP, SP, #8
    // 0xcd911c: tbnz            w0, #4, #0xcd917c
    // 0xcd9120: ldur            x1, [fp, #-0x10]
    // 0xcd9124: r0 = LoadClassIdInstr(r1)
    //     0xcd9124: ldur            x0, [x1, #-1]
    //     0xcd9128: ubfx            x0, x0, #0xc, #0x14
    // 0xcd912c: SaveReg r1
    //     0xcd912c: str             x1, [SP, #-8]!
    // 0xcd9130: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xcd9130: add             lr, x0, #0x5ca
    //     0xcd9134: ldr             lr, [x21, lr, lsl #3]
    //     0xcd9138: blr             lr
    // 0xcd913c: add             SP, SP, #8
    // 0xcd9140: r1 = LoadClassIdInstr(r0)
    //     0xcd9140: ldur            x1, [x0, #-1]
    //     0xcd9144: ubfx            x1, x1, #0xc, #0x14
    // 0xcd9148: ldur            x16, [fp, #-8]
    // 0xcd914c: stp             x16, x0, [SP, #-0x10]!
    // 0xcd9150: r16 = true
    //     0xcd9150: add             x16, NULL, #0x20  ; true
    // 0xcd9154: SaveReg r16
    //     0xcd9154: str             x16, [SP, #-8]!
    // 0xcd9158: mov             x0, x1
    // 0xcd915c: r4 = const [0, 0x3, 0x3, 0x2, includePlaceholders, 0x2, null]
    //     0xcd915c: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d410] List(7) [0, 0x3, 0x3, 0x2, "includePlaceholders", 0x2, Null]
    //     0xcd9160: ldr             x4, [x4, #0x410]
    // 0xcd9164: r0 = GDT[cid_x0 + -0xec2]()
    //     0xcd9164: sub             lr, x0, #0xec2
    //     0xcd9168: ldr             lr, [x21, lr, lsl #3]
    //     0xcd916c: blr             lr
    // 0xcd9170: add             SP, SP, #0x18
    // 0xcd9174: ldur            x1, [fp, #-0x10]
    // 0xcd9178: b               #0xcd90f4
    // 0xcd917c: r0 = Null
    //     0xcd917c: mov             x0, NULL
    // 0xcd9180: LeaveFrame
    //     0xcd9180: mov             SP, fp
    //     0xcd9184: ldp             fp, lr, [SP], #0x10
    // 0xcd9188: ret
    //     0xcd9188: ret             
    // 0xcd918c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd918c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd9190: b               #0xcd909c
    // 0xcd9194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd9194: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd9198: b               #0xcd9100
  }
  RenderComparison compareTo(TextSpan, InlineSpan) {
    // ** addr: 0xcdc8cc, size: 0x400
    // 0xcdc8cc: EnterFrame
    //     0xcdc8cc: stp             fp, lr, [SP, #-0x10]!
    //     0xcdc8d0: mov             fp, SP
    // 0xcdc8d4: AllocStack(0x30)
    //     0xcdc8d4: sub             SP, SP, #0x30
    // 0xcdc8d8: CheckStackOverflow
    //     0xcdc8d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdc8dc: cmp             SP, x16
    //     0xcdc8e0: b.ls            #0xcdccb4
    // 0xcdc8e4: ldr             x1, [fp, #0x18]
    // 0xcdc8e8: ldr             x0, [fp, #0x10]
    // 0xcdc8ec: cmp             w1, w0
    // 0xcdc8f0: b.ne            #0xcdc908
    // 0xcdc8f4: r0 = Instance_RenderComparison
    //     0xcdc8f4: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0xcdc8f8: ldr             x0, [x0, #0x438]
    // 0xcdc8fc: LeaveFrame
    //     0xcdc8fc: mov             SP, fp
    //     0xcdc900: ldp             fp, lr, [SP], #0x10
    // 0xcdc904: ret
    //     0xcdc904: ret             
    // 0xcdc908: stp             x1, x0, [SP, #-0x10]!
    // 0xcdc90c: r0 = _haveSameRuntimeType()
    //     0xcdc90c: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xcdc910: add             SP, SP, #0x10
    // 0xcdc914: tbz             w0, #4, #0xcdc92c
    // 0xcdc918: r0 = Instance_RenderComparison
    //     0xcdc918: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0xcdc91c: ldr             x0, [x0, #0x470]
    // 0xcdc920: LeaveFrame
    //     0xcdc920: mov             SP, fp
    //     0xcdc924: ldp             fp, lr, [SP], #0x10
    // 0xcdc928: ret
    //     0xcdc928: ret             
    // 0xcdc92c: ldr             x4, [fp, #0x18]
    // 0xcdc930: ldr             x3, [fp, #0x10]
    // 0xcdc934: mov             x0, x3
    // 0xcdc938: r2 = Null
    //     0xcdc938: mov             x2, NULL
    // 0xcdc93c: r1 = Null
    //     0xcdc93c: mov             x1, NULL
    // 0xcdc940: r4 = LoadClassIdInstr(r0)
    //     0xcdc940: ldur            x4, [x0, #-1]
    //     0xcdc944: ubfx            x4, x4, #0xc, #0x14
    // 0xcdc948: sub             x4, x4, #0xd91
    // 0xcdc94c: cmp             x4, #2
    // 0xcdc950: b.ls            #0xcdc968
    // 0xcdc954: r8 = TextSpan
    //     0xcdc954: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d490] Type: TextSpan
    //     0xcdc958: ldr             x8, [x8, #0x490]
    // 0xcdc95c: r3 = Null
    //     0xcdc95c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d498] Null
    //     0xcdc960: ldr             x3, [x3, #0x498]
    // 0xcdc964: r0 = TextSpan()
    //     0xcdc964: bl              #0x6736a0  ; IsType_TextSpan_Stub
    // 0xcdc968: ldr             x1, [fp, #0x10]
    // 0xcdc96c: LoadField: r0 = r1->field_b
    //     0xcdc96c: ldur            w0, [x1, #0xb]
    // 0xcdc970: DecompressPointer r0
    //     0xcdc970: add             x0, x0, HEAP, lsl #32
    // 0xcdc974: ldr             x2, [fp, #0x18]
    // 0xcdc978: LoadField: r3 = r2->field_b
    //     0xcdc978: ldur            w3, [x2, #0xb]
    // 0xcdc97c: DecompressPointer r3
    //     0xcdc97c: add             x3, x3, HEAP, lsl #32
    // 0xcdc980: r4 = LoadClassIdInstr(r0)
    //     0xcdc980: ldur            x4, [x0, #-1]
    //     0xcdc984: ubfx            x4, x4, #0xc, #0x14
    // 0xcdc988: stp             x3, x0, [SP, #-0x10]!
    // 0xcdc98c: mov             x0, x4
    // 0xcdc990: mov             lr, x0
    // 0xcdc994: ldr             lr, [x21, lr, lsl #3]
    // 0xcdc998: blr             lr
    // 0xcdc99c: add             SP, SP, #0x10
    // 0xcdc9a0: tbnz            w0, #4, #0xcdcab8
    // 0xcdc9a4: ldr             x1, [fp, #0x18]
    // 0xcdc9a8: LoadField: r2 = r1->field_f
    //     0xcdc9a8: ldur            w2, [x1, #0xf]
    // 0xcdc9ac: DecompressPointer r2
    //     0xcdc9ac: add             x2, x2, HEAP, lsl #32
    // 0xcdc9b0: stur            x2, [fp, #-8]
    // 0xcdc9b4: cmp             w2, NULL
    // 0xcdc9b8: b.ne            #0xcdc9c4
    // 0xcdc9bc: r2 = Null
    //     0xcdc9bc: mov             x2, NULL
    // 0xcdc9c0: b               #0xcdc9e8
    // 0xcdc9c4: r0 = LoadClassIdInstr(r2)
    //     0xcdc9c4: ldur            x0, [x2, #-1]
    //     0xcdc9c8: ubfx            x0, x0, #0xc, #0x14
    // 0xcdc9cc: SaveReg r2
    //     0xcdc9cc: str             x2, [SP, #-8]!
    // 0xcdc9d0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcdc9d0: mov             x17, #0xb8ea
    //     0xcdc9d4: add             lr, x0, x17
    //     0xcdc9d8: ldr             lr, [x21, lr, lsl #3]
    //     0xcdc9dc: blr             lr
    // 0xcdc9e0: add             SP, SP, #8
    // 0xcdc9e4: mov             x2, x0
    // 0xcdc9e8: ldr             x1, [fp, #0x10]
    // 0xcdc9ec: stur            x2, [fp, #-0x18]
    // 0xcdc9f0: LoadField: r3 = r1->field_f
    //     0xcdc9f0: ldur            w3, [x1, #0xf]
    // 0xcdc9f4: DecompressPointer r3
    //     0xcdc9f4: add             x3, x3, HEAP, lsl #32
    // 0xcdc9f8: stur            x3, [fp, #-0x10]
    // 0xcdc9fc: cmp             w3, NULL
    // 0xcdca00: b.ne            #0xcdca10
    // 0xcdca04: mov             x0, x2
    // 0xcdca08: r1 = Null
    //     0xcdca08: mov             x1, NULL
    // 0xcdca0c: b               #0xcdca38
    // 0xcdca10: r0 = LoadClassIdInstr(r3)
    //     0xcdca10: ldur            x0, [x3, #-1]
    //     0xcdca14: ubfx            x0, x0, #0xc, #0x14
    // 0xcdca18: SaveReg r3
    //     0xcdca18: str             x3, [SP, #-8]!
    // 0xcdca1c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcdca1c: mov             x17, #0xb8ea
    //     0xcdca20: add             lr, x0, x17
    //     0xcdca24: ldr             lr, [x21, lr, lsl #3]
    //     0xcdca28: blr             lr
    // 0xcdca2c: add             SP, SP, #8
    // 0xcdca30: mov             x1, x0
    // 0xcdca34: ldur            x0, [fp, #-0x18]
    // 0xcdca38: cmp             w0, w1
    // 0xcdca3c: b.eq            #0xcdca78
    // 0xcdca40: and             w16, w0, w1
    // 0xcdca44: branchIfSmi(r16, 0xcdcab8)
    //     0xcdca44: tbz             w16, #0, #0xcdcab8
    // 0xcdca48: r16 = LoadClassIdInstr(r0)
    //     0xcdca48: ldur            x16, [x0, #-1]
    //     0xcdca4c: ubfx            x16, x16, #0xc, #0x14
    // 0xcdca50: cmp             x16, #0x3c
    // 0xcdca54: b.ne            #0xcdcab8
    // 0xcdca58: r16 = LoadClassIdInstr(r1)
    //     0xcdca58: ldur            x16, [x1, #-1]
    //     0xcdca5c: ubfx            x16, x16, #0xc, #0x14
    // 0xcdca60: cmp             x16, #0x3c
    // 0xcdca64: b.ne            #0xcdcab8
    // 0xcdca68: LoadField: r16 = r0->field_7
    //     0xcdca68: ldur            x16, [x0, #7]
    // 0xcdca6c: LoadField: r17 = r1->field_7
    //     0xcdca6c: ldur            x17, [x1, #7]
    // 0xcdca70: cmp             x16, x17
    // 0xcdca74: b.ne            #0xcdcab8
    // 0xcdca78: ldr             x1, [fp, #0x18]
    // 0xcdca7c: ldr             x0, [fp, #0x10]
    // 0xcdca80: LoadField: r2 = r1->field_7
    //     0xcdca80: ldur            w2, [x1, #7]
    // 0xcdca84: DecompressPointer r2
    //     0xcdca84: add             x2, x2, HEAP, lsl #32
    // 0xcdca88: cmp             w2, NULL
    // 0xcdca8c: r16 = true
    //     0xcdca8c: add             x16, NULL, #0x20  ; true
    // 0xcdca90: r17 = false
    //     0xcdca90: add             x17, NULL, #0x30  ; false
    // 0xcdca94: csel            x3, x16, x17, eq
    // 0xcdca98: LoadField: r4 = r0->field_7
    //     0xcdca98: ldur            w4, [x0, #7]
    // 0xcdca9c: DecompressPointer r4
    //     0xcdca9c: add             x4, x4, HEAP, lsl #32
    // 0xcdcaa0: cmp             w4, NULL
    // 0xcdcaa4: r16 = true
    //     0xcdcaa4: add             x16, NULL, #0x20  ; true
    // 0xcdcaa8: r17 = false
    //     0xcdcaa8: add             x17, NULL, #0x30  ; false
    // 0xcdcaac: csel            x5, x16, x17, eq
    // 0xcdcab0: cmp             w3, w5
    // 0xcdcab4: b.eq            #0xcdcacc
    // 0xcdcab8: r0 = Instance_RenderComparison
    //     0xcdcab8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0xcdcabc: ldr             x0, [x0, #0x470]
    // 0xcdcac0: LeaveFrame
    //     0xcdcac0: mov             SP, fp
    //     0xcdcac4: ldp             fp, lr, [SP], #0x10
    // 0xcdcac8: ret
    //     0xcdcac8: ret             
    // 0xcdcacc: LoadField: r3 = r1->field_13
    //     0xcdcacc: ldur            w3, [x1, #0x13]
    // 0xcdcad0: DecompressPointer r3
    //     0xcdcad0: add             x3, x3, HEAP, lsl #32
    // 0xcdcad4: LoadField: r1 = r0->field_13
    //     0xcdcad4: ldur            w1, [x0, #0x13]
    // 0xcdcad8: DecompressPointer r1
    //     0xcdcad8: add             x1, x1, HEAP, lsl #32
    // 0xcdcadc: cmp             w3, w1
    // 0xcdcae0: b.ne            #0xcdcaf0
    // 0xcdcae4: r0 = Instance_RenderComparison
    //     0xcdcae4: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0xcdcae8: ldr             x0, [x0, #0x438]
    // 0xcdcaec: b               #0xcdcaf8
    // 0xcdcaf0: r0 = Instance_RenderComparison
    //     0xcdcaf0: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d4a8] Obj!RenderComparison@b65071
    //     0xcdcaf4: ldr             x0, [x0, #0x4a8]
    // 0xcdcaf8: stur            x0, [fp, #-0x18]
    // 0xcdcafc: cmp             w2, NULL
    // 0xcdcb00: b.eq            #0xcdcb4c
    // 0xcdcb04: cmp             w4, NULL
    // 0xcdcb08: b.eq            #0xcdccbc
    // 0xcdcb0c: stp             x4, x2, [SP, #-0x10]!
    // 0xcdcb10: r0 = compareTo()
    //     0xcdcb10: bl              #0x51ca94  ; [package:flutter/src/painting/text_style.dart] TextStyle::compareTo
    // 0xcdcb14: add             SP, SP, #0x10
    // 0xcdcb18: LoadField: r1 = r0->field_7
    //     0xcdcb18: ldur            x1, [x0, #7]
    // 0xcdcb1c: ldur            x2, [fp, #-0x18]
    // 0xcdcb20: LoadField: r3 = r2->field_7
    //     0xcdcb20: ldur            x3, [x2, #7]
    // 0xcdcb24: cmp             x1, x3
    // 0xcdcb28: b.gt            #0xcdcb30
    // 0xcdcb2c: mov             x0, x2
    // 0xcdcb30: r16 = Instance_RenderComparison
    //     0xcdcb30: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0xcdcb34: ldr             x16, [x16, #0x470]
    // 0xcdcb38: cmp             w0, w16
    // 0xcdcb3c: b.ne            #0xcdcb54
    // 0xcdcb40: LeaveFrame
    //     0xcdcb40: mov             SP, fp
    //     0xcdcb44: ldp             fp, lr, [SP], #0x10
    // 0xcdcb48: ret
    //     0xcdcb48: ret             
    // 0xcdcb4c: mov             x2, x0
    // 0xcdcb50: mov             x0, x2
    // 0xcdcb54: ldur            x1, [fp, #-8]
    // 0xcdcb58: cmp             w1, NULL
    // 0xcdcb5c: b.eq            #0xcdcca8
    // 0xcdcb60: mov             x4, x0
    // 0xcdcb64: r3 = 0
    //     0xcdcb64: mov             x3, #0
    // 0xcdcb68: ldur            x2, [fp, #-0x10]
    // 0xcdcb6c: stur            x4, [fp, #-0x18]
    // 0xcdcb70: stur            x3, [fp, #-0x20]
    // 0xcdcb74: CheckStackOverflow
    //     0xcdcb74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdcb78: cmp             SP, x16
    //     0xcdcb7c: b.ls            #0xcdccc0
    // 0xcdcb80: r0 = LoadClassIdInstr(r1)
    //     0xcdcb80: ldur            x0, [x1, #-1]
    //     0xcdcb84: ubfx            x0, x0, #0xc, #0x14
    // 0xcdcb88: SaveReg r1
    //     0xcdcb88: str             x1, [SP, #-8]!
    // 0xcdcb8c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcdcb8c: mov             x17, #0xb8ea
    //     0xcdcb90: add             lr, x0, x17
    //     0xcdcb94: ldr             lr, [x21, lr, lsl #3]
    //     0xcdcb98: blr             lr
    // 0xcdcb9c: add             SP, SP, #8
    // 0xcdcba0: r1 = LoadInt32Instr(r0)
    //     0xcdcba0: sbfx            x1, x0, #1, #0x1f
    //     0xcdcba4: tbz             w0, #0, #0xcdcbac
    //     0xcdcba8: ldur            x1, [x0, #7]
    // 0xcdcbac: ldur            x2, [fp, #-0x20]
    // 0xcdcbb0: cmp             x2, x1
    // 0xcdcbb4: b.ge            #0xcdcca0
    // 0xcdcbb8: ldur            x3, [fp, #-8]
    // 0xcdcbbc: ldur            x4, [fp, #-0x10]
    // 0xcdcbc0: ldur            x5, [fp, #-0x18]
    // 0xcdcbc4: r0 = BoxInt64Instr(r2)
    //     0xcdcbc4: sbfiz           x0, x2, #1, #0x1f
    //     0xcdcbc8: cmp             x2, x0, asr #1
    //     0xcdcbcc: b.eq            #0xcdcbd8
    //     0xcdcbd0: bl              #0xd69bb8
    //     0xcdcbd4: stur            x2, [x0, #7]
    // 0xcdcbd8: mov             x1, x0
    // 0xcdcbdc: stur            x1, [fp, #-0x28]
    // 0xcdcbe0: r0 = LoadClassIdInstr(r3)
    //     0xcdcbe0: ldur            x0, [x3, #-1]
    //     0xcdcbe4: ubfx            x0, x0, #0xc, #0x14
    // 0xcdcbe8: stp             x1, x3, [SP, #-0x10]!
    // 0xcdcbec: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcdcbec: sub             lr, x0, #0xd83
    //     0xcdcbf0: ldr             lr, [x21, lr, lsl #3]
    //     0xcdcbf4: blr             lr
    // 0xcdcbf8: add             SP, SP, #0x10
    // 0xcdcbfc: mov             x2, x0
    // 0xcdcc00: ldur            x1, [fp, #-0x10]
    // 0xcdcc04: stur            x2, [fp, #-0x30]
    // 0xcdcc08: cmp             w1, NULL
    // 0xcdcc0c: b.eq            #0xcdccc8
    // 0xcdcc10: r0 = LoadClassIdInstr(r1)
    //     0xcdcc10: ldur            x0, [x1, #-1]
    //     0xcdcc14: ubfx            x0, x0, #0xc, #0x14
    // 0xcdcc18: ldur            x16, [fp, #-0x28]
    // 0xcdcc1c: stp             x16, x1, [SP, #-0x10]!
    // 0xcdcc20: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcdcc20: sub             lr, x0, #0xd83
    //     0xcdcc24: ldr             lr, [x21, lr, lsl #3]
    //     0xcdcc28: blr             lr
    // 0xcdcc2c: add             SP, SP, #0x10
    // 0xcdcc30: mov             x1, x0
    // 0xcdcc34: ldur            x0, [fp, #-0x30]
    // 0xcdcc38: r2 = LoadClassIdInstr(r0)
    //     0xcdcc38: ldur            x2, [x0, #-1]
    //     0xcdcc3c: ubfx            x2, x2, #0xc, #0x14
    // 0xcdcc40: stp             x1, x0, [SP, #-0x10]!
    // 0xcdcc44: mov             x0, x2
    // 0xcdcc48: r0 = GDT[cid_x0 + -0xf24]()
    //     0xcdcc48: sub             lr, x0, #0xf24
    //     0xcdcc4c: ldr             lr, [x21, lr, lsl #3]
    //     0xcdcc50: blr             lr
    // 0xcdcc54: add             SP, SP, #0x10
    // 0xcdcc58: LoadField: r1 = r0->field_7
    //     0xcdcc58: ldur            x1, [x0, #7]
    // 0xcdcc5c: ldur            x2, [fp, #-0x18]
    // 0xcdcc60: LoadField: r3 = r2->field_7
    //     0xcdcc60: ldur            x3, [x2, #7]
    // 0xcdcc64: cmp             x1, x3
    // 0xcdcc68: b.gt            #0xcdcc70
    // 0xcdcc6c: mov             x0, x2
    // 0xcdcc70: r16 = Instance_RenderComparison
    //     0xcdcc70: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0xcdcc74: ldr             x16, [x16, #0x470]
    // 0xcdcc78: cmp             w0, w16
    // 0xcdcc7c: b.ne            #0xcdcc8c
    // 0xcdcc80: LeaveFrame
    //     0xcdcc80: mov             SP, fp
    //     0xcdcc84: ldp             fp, lr, [SP], #0x10
    // 0xcdcc88: ret
    //     0xcdcc88: ret             
    // 0xcdcc8c: ldur            x1, [fp, #-0x20]
    // 0xcdcc90: add             x3, x1, #1
    // 0xcdcc94: mov             x4, x0
    // 0xcdcc98: ldur            x1, [fp, #-8]
    // 0xcdcc9c: b               #0xcdcb68
    // 0xcdcca0: ldur            x2, [fp, #-0x18]
    // 0xcdcca4: mov             x0, x2
    // 0xcdcca8: LeaveFrame
    //     0xcdcca8: mov             SP, fp
    //     0xcdccac: ldp             fp, lr, [SP], #0x10
    // 0xcdccb0: ret
    //     0xcdccb0: ret             
    // 0xcdccb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdccb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdccb8: b               #0xcdc8e4
    // 0xcdccbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcdccbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcdccc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdccc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdccc4: b               #0xcdcb80
    // 0xcdccc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcdccc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0xcdf548, size: 0x158
    // 0xcdf548: EnterFrame
    //     0xcdf548: stp             fp, lr, [SP, #-0x10]!
    //     0xcdf54c: mov             fp, SP
    // 0xcdf550: AllocStack(0x8)
    //     0xcdf550: sub             SP, SP, #8
    // 0xcdf554: CheckStackOverflow
    //     0xcdf554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdf558: cmp             SP, x16
    //     0xcdf55c: b.ls            #0xcdf690
    // 0xcdf560: ldr             x1, [fp, #0x18]
    // 0xcdf564: LoadField: r0 = r1->field_b
    //     0xcdf564: ldur            w0, [x1, #0xb]
    // 0xcdf568: DecompressPointer r0
    //     0xcdf568: add             x0, x0, HEAP, lsl #32
    // 0xcdf56c: cmp             w0, NULL
    // 0xcdf570: b.eq            #0xcdf5b8
    // 0xcdf574: ldr             x16, [fp, #0x10]
    // 0xcdf578: stp             x1, x16, [SP, #-0x10]!
    // 0xcdf57c: ldr             x0, [fp, #0x10]
    // 0xcdf580: ClosureCall
    //     0xcdf580: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcdf584: ldur            x2, [x0, #0x1f]
    //     0xcdf588: blr             x2
    // 0xcdf58c: add             SP, SP, #0x10
    // 0xcdf590: mov             x1, x0
    // 0xcdf594: stur            x1, [fp, #-8]
    // 0xcdf598: tbnz            w0, #5, #0xcdf5a0
    // 0xcdf59c: r0 = AssertBoolean()
    //     0xcdf59c: bl              #0xd67df0  ; AssertBooleanStub
    // 0xcdf5a0: ldur            x0, [fp, #-8]
    // 0xcdf5a4: tbz             w0, #4, #0xcdf5b8
    // 0xcdf5a8: r0 = false
    //     0xcdf5a8: add             x0, NULL, #0x30  ; false
    // 0xcdf5ac: LeaveFrame
    //     0xcdf5ac: mov             SP, fp
    //     0xcdf5b0: ldp             fp, lr, [SP], #0x10
    // 0xcdf5b4: ret
    //     0xcdf5b4: ret             
    // 0xcdf5b8: ldr             x0, [fp, #0x18]
    // 0xcdf5bc: LoadField: r1 = r0->field_f
    //     0xcdf5bc: ldur            w1, [x0, #0xf]
    // 0xcdf5c0: DecompressPointer r1
    //     0xcdf5c0: add             x1, x1, HEAP, lsl #32
    // 0xcdf5c4: cmp             w1, NULL
    // 0xcdf5c8: b.eq            #0xcdf680
    // 0xcdf5cc: r0 = LoadClassIdInstr(r1)
    //     0xcdf5cc: ldur            x0, [x1, #-1]
    //     0xcdf5d0: ubfx            x0, x0, #0xc, #0x14
    // 0xcdf5d4: SaveReg r1
    //     0xcdf5d4: str             x1, [SP, #-8]!
    // 0xcdf5d8: r0 = GDT[cid_x0 + 0xb940]()
    //     0xcdf5d8: mov             x17, #0xb940
    //     0xcdf5dc: add             lr, x0, x17
    //     0xcdf5e0: ldr             lr, [x21, lr, lsl #3]
    //     0xcdf5e4: blr             lr
    // 0xcdf5e8: add             SP, SP, #8
    // 0xcdf5ec: mov             x1, x0
    // 0xcdf5f0: stur            x1, [fp, #-8]
    // 0xcdf5f4: CheckStackOverflow
    //     0xcdf5f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdf5f8: cmp             SP, x16
    //     0xcdf5fc: b.ls            #0xcdf698
    // 0xcdf600: r0 = LoadClassIdInstr(r1)
    //     0xcdf600: ldur            x0, [x1, #-1]
    //     0xcdf604: ubfx            x0, x0, #0xc, #0x14
    // 0xcdf608: SaveReg r1
    //     0xcdf608: str             x1, [SP, #-8]!
    // 0xcdf60c: r0 = GDT[cid_x0 + 0x541]()
    //     0xcdf60c: add             lr, x0, #0x541
    //     0xcdf610: ldr             lr, [x21, lr, lsl #3]
    //     0xcdf614: blr             lr
    // 0xcdf618: add             SP, SP, #8
    // 0xcdf61c: tbnz            w0, #4, #0xcdf680
    // 0xcdf620: ldur            x1, [fp, #-8]
    // 0xcdf624: r0 = LoadClassIdInstr(r1)
    //     0xcdf624: ldur            x0, [x1, #-1]
    //     0xcdf628: ubfx            x0, x0, #0xc, #0x14
    // 0xcdf62c: SaveReg r1
    //     0xcdf62c: str             x1, [SP, #-8]!
    // 0xcdf630: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xcdf630: add             lr, x0, #0x5ca
    //     0xcdf634: ldr             lr, [x21, lr, lsl #3]
    //     0xcdf638: blr             lr
    // 0xcdf63c: add             SP, SP, #8
    // 0xcdf640: r1 = LoadClassIdInstr(r0)
    //     0xcdf640: ldur            x1, [x0, #-1]
    //     0xcdf644: ubfx            x1, x1, #0xc, #0x14
    // 0xcdf648: ldr             x16, [fp, #0x10]
    // 0xcdf64c: stp             x16, x0, [SP, #-0x10]!
    // 0xcdf650: mov             x0, x1
    // 0xcdf654: r0 = GDT[cid_x0 + -0x1000]()
    //     0xcdf654: sub             lr, x0, #1, lsl #12
    //     0xcdf658: ldr             lr, [x21, lr, lsl #3]
    //     0xcdf65c: blr             lr
    // 0xcdf660: add             SP, SP, #0x10
    // 0xcdf664: tbz             w0, #4, #0xcdf678
    // 0xcdf668: r0 = false
    //     0xcdf668: add             x0, NULL, #0x30  ; false
    // 0xcdf66c: LeaveFrame
    //     0xcdf66c: mov             SP, fp
    //     0xcdf670: ldp             fp, lr, [SP], #0x10
    // 0xcdf674: ret
    //     0xcdf674: ret             
    // 0xcdf678: ldur            x1, [fp, #-8]
    // 0xcdf67c: b               #0xcdf5f4
    // 0xcdf680: r0 = true
    //     0xcdf680: add             x0, NULL, #0x20  ; true
    // 0xcdf684: LeaveFrame
    //     0xcdf684: mov             SP, fp
    //     0xcdf688: ldp             fp, lr, [SP], #0x10
    // 0xcdf68c: ret
    //     0xcdf68c: ret             
    // 0xcdf690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdf690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdf694: b               #0xcdf560
    // 0xcdf698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdf698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdf69c: b               #0xcdf600
  }
}

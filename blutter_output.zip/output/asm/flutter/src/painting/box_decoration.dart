// lib: , url: package:flutter/src/painting/box_decoration.dart

// class id: 1049351, size: 0x8
class :: {
}

// class id: 2937, size: 0x28, field offset: 0x8
//   const constructor, 
class BoxDecoration extends Decoration {

  Color field_8;
  BorderRadius field_14;
  BoxShape field_24;
  LinearGradient field_1c;
  Border field_10;
  _ImmutableList<BoxShadow> field_18;

  get _ hashCode(/* No info */) {
    // ** addr: 0xafd2c0, size: 0xf8
    // 0xafd2c0: EnterFrame
    //     0xafd2c0: stp             fp, lr, [SP, #-0x10]!
    //     0xafd2c4: mov             fp, SP
    // 0xafd2c8: AllocStack(0x20)
    //     0xafd2c8: sub             SP, SP, #0x20
    // 0xafd2cc: CheckStackOverflow
    //     0xafd2cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafd2d0: cmp             SP, x16
    //     0xafd2d4: b.ls            #0xafd3b0
    // 0xafd2d8: ldr             x0, [fp, #0x10]
    // 0xafd2dc: LoadField: r1 = r0->field_7
    //     0xafd2dc: ldur            w1, [x0, #7]
    // 0xafd2e0: DecompressPointer r1
    //     0xafd2e0: add             x1, x1, HEAP, lsl #32
    // 0xafd2e4: stur            x1, [fp, #-0x20]
    // 0xafd2e8: LoadField: r2 = r0->field_b
    //     0xafd2e8: ldur            w2, [x0, #0xb]
    // 0xafd2ec: DecompressPointer r2
    //     0xafd2ec: add             x2, x2, HEAP, lsl #32
    // 0xafd2f0: stur            x2, [fp, #-0x18]
    // 0xafd2f4: LoadField: r3 = r0->field_f
    //     0xafd2f4: ldur            w3, [x0, #0xf]
    // 0xafd2f8: DecompressPointer r3
    //     0xafd2f8: add             x3, x3, HEAP, lsl #32
    // 0xafd2fc: stur            x3, [fp, #-0x10]
    // 0xafd300: LoadField: r4 = r0->field_13
    //     0xafd300: ldur            w4, [x0, #0x13]
    // 0xafd304: DecompressPointer r4
    //     0xafd304: add             x4, x4, HEAP, lsl #32
    // 0xafd308: stur            x4, [fp, #-8]
    // 0xafd30c: LoadField: r5 = r0->field_17
    //     0xafd30c: ldur            w5, [x0, #0x17]
    // 0xafd310: DecompressPointer r5
    //     0xafd310: add             x5, x5, HEAP, lsl #32
    // 0xafd314: cmp             w5, NULL
    // 0xafd318: b.ne            #0xafd324
    // 0xafd31c: r1 = Null
    //     0xafd31c: mov             x1, NULL
    // 0xafd320: b               #0xafd350
    // 0xafd324: SaveReg r5
    //     0xafd324: str             x5, [SP, #-8]!
    // 0xafd328: r0 = hashAll()
    //     0xafd328: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xafd32c: add             SP, SP, #8
    // 0xafd330: mov             x2, x0
    // 0xafd334: r0 = BoxInt64Instr(r2)
    //     0xafd334: sbfiz           x0, x2, #1, #0x1f
    //     0xafd338: cmp             x2, x0, asr #1
    //     0xafd33c: b.eq            #0xafd348
    //     0xafd340: bl              #0xd69bb8
    //     0xafd344: stur            x2, [x0, #7]
    // 0xafd348: mov             x1, x0
    // 0xafd34c: ldr             x0, [fp, #0x10]
    // 0xafd350: LoadField: r2 = r0->field_1b
    //     0xafd350: ldur            w2, [x0, #0x1b]
    // 0xafd354: DecompressPointer r2
    //     0xafd354: add             x2, x2, HEAP, lsl #32
    // 0xafd358: LoadField: r3 = r0->field_23
    //     0xafd358: ldur            w3, [x0, #0x23]
    // 0xafd35c: DecompressPointer r3
    //     0xafd35c: add             x3, x3, HEAP, lsl #32
    // 0xafd360: ldur            x16, [fp, #-0x20]
    // 0xafd364: ldur            lr, [fp, #-0x18]
    // 0xafd368: stp             lr, x16, [SP, #-0x10]!
    // 0xafd36c: ldur            x16, [fp, #-0x10]
    // 0xafd370: ldur            lr, [fp, #-8]
    // 0xafd374: stp             lr, x16, [SP, #-0x10]!
    // 0xafd378: stp             x2, x1, [SP, #-0x10]!
    // 0xafd37c: stp             x3, NULL, [SP, #-0x10]!
    // 0xafd380: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0xafd380: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0xafd384: r0 = hash()
    //     0xafd384: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafd388: add             SP, SP, #0x40
    // 0xafd38c: mov             x2, x0
    // 0xafd390: r0 = BoxInt64Instr(r2)
    //     0xafd390: sbfiz           x0, x2, #1, #0x1f
    //     0xafd394: cmp             x2, x0, asr #1
    //     0xafd398: b.eq            #0xafd3a4
    //     0xafd39c: bl              #0xd69bb8
    //     0xafd3a0: stur            x2, [x0, #7]
    // 0xafd3a4: LeaveFrame
    //     0xafd3a4: mov             SP, fp
    //     0xafd3a8: ldp             fp, lr, [SP], #0x10
    // 0xafd3ac: ret
    //     0xafd3ac: ret             
    // 0xafd3b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafd3b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafd3b4: b               #0xafd2d8
  }
  _ hitTest(/* No info */) {
    // ** addr: 0xb0f1dc, size: 0x22c
    // 0xb0f1dc: EnterFrame
    //     0xb0f1dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb0f1e0: mov             fp, SP
    // 0xb0f1e4: AllocStack(0x20)
    //     0xb0f1e4: sub             SP, SP, #0x20
    // 0xb0f1e8: CheckStackOverflow
    //     0xb0f1e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0f1ec: cmp             SP, x16
    //     0xb0f1f0: b.ls            #0xb0f3e4
    // 0xb0f1f4: ldr             x0, [fp, #0x28]
    // 0xb0f1f8: LoadField: r1 = r0->field_23
    //     0xb0f1f8: ldur            w1, [x0, #0x23]
    // 0xb0f1fc: DecompressPointer r1
    //     0xb0f1fc: add             x1, x1, HEAP, lsl #32
    // 0xb0f200: LoadField: r2 = r1->field_7
    //     0xb0f200: ldur            x2, [x1, #7]
    // 0xb0f204: cmp             x2, #0
    // 0xb0f208: b.gt            #0xb0f2bc
    // 0xb0f20c: LoadField: r1 = r0->field_13
    //     0xb0f20c: ldur            w1, [x0, #0x13]
    // 0xb0f210: DecompressPointer r1
    //     0xb0f210: add             x1, x1, HEAP, lsl #32
    // 0xb0f214: cmp             w1, NULL
    // 0xb0f218: b.eq            #0xb0f2ac
    // 0xb0f21c: r0 = LoadClassIdInstr(r1)
    //     0xb0f21c: ldur            x0, [x1, #-1]
    //     0xb0f220: ubfx            x0, x0, #0xc, #0x14
    // 0xb0f224: lsl             x0, x0, #1
    // 0xb0f228: r17 = 4224
    //     0xb0f228: mov             x17, #0x1080
    // 0xb0f22c: cmp             w0, w17
    // 0xb0f230: b.ne            #0xb0f23c
    // 0xb0f234: mov             x0, x1
    // 0xb0f238: b               #0xb0f25c
    // 0xb0f23c: r0 = LoadClassIdInstr(r1)
    //     0xb0f23c: ldur            x0, [x1, #-1]
    //     0xb0f240: ubfx            x0, x0, #0xc, #0x14
    // 0xb0f244: ldr             x16, [fp, #0x10]
    // 0xb0f248: stp             x16, x1, [SP, #-0x10]!
    // 0xb0f24c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xb0f24c: sub             lr, x0, #1, lsl #12
    //     0xb0f250: ldr             lr, [x21, lr, lsl #3]
    //     0xb0f254: blr             lr
    // 0xb0f258: add             SP, SP, #0x10
    // 0xb0f25c: stur            x0, [fp, #-8]
    // 0xb0f260: r16 = Instance_Offset
    //     0xb0f260: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xb0f264: ldr             lr, [fp, #0x20]
    // 0xb0f268: stp             lr, x16, [SP, #-0x10]!
    // 0xb0f26c: r0 = &()
    //     0xb0f26c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xb0f270: add             SP, SP, #0x10
    // 0xb0f274: mov             x1, x0
    // 0xb0f278: ldur            x0, [fp, #-8]
    // 0xb0f27c: cmp             w0, NULL
    // 0xb0f280: b.eq            #0xb0f3ec
    // 0xb0f284: stp             x1, x0, [SP, #-0x10]!
    // 0xb0f288: r0 = toRRect()
    //     0xb0f288: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xb0f28c: add             SP, SP, #0x10
    // 0xb0f290: ldr             x16, [fp, #0x18]
    // 0xb0f294: stp             x16, x0, [SP, #-0x10]!
    // 0xb0f298: r0 = contains()
    //     0xb0f298: bl              #0x63f7dc  ; [dart:ui] RRect::contains
    // 0xb0f29c: add             SP, SP, #0x10
    // 0xb0f2a0: LeaveFrame
    //     0xb0f2a0: mov             SP, fp
    //     0xb0f2a4: ldp             fp, lr, [SP], #0x10
    // 0xb0f2a8: ret
    //     0xb0f2a8: ret             
    // 0xb0f2ac: r0 = true
    //     0xb0f2ac: add             x0, NULL, #0x20  ; true
    // 0xb0f2b0: LeaveFrame
    //     0xb0f2b0: mov             SP, fp
    //     0xb0f2b4: ldp             fp, lr, [SP], #0x10
    // 0xb0f2b8: ret
    //     0xb0f2b8: ret             
    // 0xb0f2bc: ldr             x0, [fp, #0x20]
    // 0xb0f2c0: SaveReg r0
    //     0xb0f2c0: str             x0, [SP, #-8]!
    // 0xb0f2c4: r0 = center()
    //     0xb0f2c4: bl              #0x64082c  ; [dart:ui] Size::center
    // 0xb0f2c8: add             SP, SP, #8
    // 0xb0f2cc: ldr             x16, [fp, #0x18]
    // 0xb0f2d0: stp             x0, x16, [SP, #-0x10]!
    // 0xb0f2d4: r0 = -()
    //     0xb0f2d4: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xb0f2d8: add             SP, SP, #0x10
    // 0xb0f2dc: SaveReg r0
    //     0xb0f2dc: str             x0, [SP, #-8]!
    // 0xb0f2e0: r0 = distance()
    //     0xb0f2e0: bl              #0xb0f408  ; [dart:ui] Offset::distance
    // 0xb0f2e4: add             SP, SP, #8
    // 0xb0f2e8: ldr             x0, [fp, #0x20]
    // 0xb0f2ec: stur            d0, [fp, #-0x20]
    // 0xb0f2f0: LoadField: d1 = r0->field_7
    //     0xb0f2f0: ldur            d1, [x0, #7]
    // 0xb0f2f4: stur            d1, [fp, #-0x18]
    // 0xb0f2f8: LoadField: d2 = r0->field_f
    //     0xb0f2f8: ldur            d2, [x0, #0xf]
    // 0xb0f2fc: stur            d2, [fp, #-0x10]
    // 0xb0f300: fcmp            d1, d2
    // 0xb0f304: b.vs            #0xb0f30c
    // 0xb0f308: b.gt            #0xb0f3b8
    // 0xb0f30c: fcmp            d1, d2
    // 0xb0f310: b.vs            #0xb0f320
    // 0xb0f314: b.ge            #0xb0f320
    // 0xb0f318: mov             v2.16b, v1.16b
    // 0xb0f31c: b               #0xb0f3b8
    // 0xb0f320: d3 = 0.000000
    //     0xb0f320: eor             v3.16b, v3.16b, v3.16b
    // 0xb0f324: fcmp            d1, d3
    // 0xb0f328: b.vs            #0xb0f330
    // 0xb0f32c: b.eq            #0xb0f338
    // 0xb0f330: r0 = false
    //     0xb0f330: add             x0, NULL, #0x30  ; false
    // 0xb0f334: b               #0xb0f33c
    // 0xb0f338: r0 = true
    //     0xb0f338: add             x0, NULL, #0x20  ; true
    // 0xb0f33c: tbnz            w0, #4, #0xb0f354
    // 0xb0f340: fadd            d3, d1, d2
    // 0xb0f344: fmul            d4, d3, d1
    // 0xb0f348: fmul            d1, d4, d2
    // 0xb0f34c: mov             v2.16b, v1.16b
    // 0xb0f350: b               #0xb0f3b8
    // 0xb0f354: tbnz            w0, #4, #0xb0f398
    // 0xb0f358: r0 = inline_Allocate_Double()
    //     0xb0f358: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb0f35c: add             x0, x0, #0x10
    //     0xb0f360: cmp             x1, x0
    //     0xb0f364: b.ls            #0xb0f3f0
    //     0xb0f368: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0f36c: sub             x0, x0, #0xf
    //     0xb0f370: mov             x1, #0xd108
    //     0xb0f374: movk            x1, #3, lsl #16
    //     0xb0f378: stur            x1, [x0, #-1]
    // 0xb0f37c: StoreField: r0->field_7 = d2
    //     0xb0f37c: stur            d2, [x0, #7]
    // 0xb0f380: SaveReg r0
    //     0xb0f380: str             x0, [SP, #-8]!
    // 0xb0f384: r0 = isNegative()
    //     0xb0f384: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xb0f388: add             SP, SP, #8
    // 0xb0f38c: tbnz            w0, #4, #0xb0f398
    // 0xb0f390: ldur            d0, [fp, #-0x10]
    // 0xb0f394: b               #0xb0f3a4
    // 0xb0f398: ldur            d0, [fp, #-0x10]
    // 0xb0f39c: fcmp            d0, d0
    // 0xb0f3a0: b.vc            #0xb0f3b0
    // 0xb0f3a4: mov             v2.16b, v0.16b
    // 0xb0f3a8: ldur            d0, [fp, #-0x20]
    // 0xb0f3ac: b               #0xb0f3b8
    // 0xb0f3b0: ldur            d2, [fp, #-0x18]
    // 0xb0f3b4: ldur            d0, [fp, #-0x20]
    // 0xb0f3b8: d1 = 2.000000
    //     0xb0f3b8: fmov            d1, #2.00000000
    // 0xb0f3bc: fdiv            d3, d2, d1
    // 0xb0f3c0: fcmp            d0, d3
    // 0xb0f3c4: b.vs            #0xb0f3cc
    // 0xb0f3c8: b.le            #0xb0f3d4
    // 0xb0f3cc: r0 = false
    //     0xb0f3cc: add             x0, NULL, #0x30  ; false
    // 0xb0f3d0: b               #0xb0f3d8
    // 0xb0f3d4: r0 = true
    //     0xb0f3d4: add             x0, NULL, #0x20  ; true
    // 0xb0f3d8: LeaveFrame
    //     0xb0f3d8: mov             SP, fp
    //     0xb0f3dc: ldp             fp, lr, [SP], #0x10
    // 0xb0f3e0: ret
    //     0xb0f3e0: ret             
    // 0xb0f3e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0f3e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0f3e8: b               #0xb0f1f4
    // 0xb0f3ec: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb0f3ec: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xb0f3f0: stp             q1, q2, [SP, #-0x20]!
    // 0xb0f3f4: SaveReg d0
    //     0xb0f3f4: str             q0, [SP, #-0x10]!
    // 0xb0f3f8: r0 = AllocateDouble()
    //     0xb0f3f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0f3fc: RestoreReg d0
    //     0xb0f3fc: ldr             q0, [SP], #0x10
    // 0xb0f400: ldp             q1, q2, [SP], #0x20
    // 0xb0f404: b               #0xb0f37c
  }
  get _ isComplex(/* No info */) {
    // ** addr: 0xc3f28c, size: 0x20
    // 0xc3f28c: ldr             x1, [SP]
    // 0xc3f290: LoadField: r2 = r1->field_17
    //     0xc3f290: ldur            w2, [x1, #0x17]
    // 0xc3f294: DecompressPointer r2
    //     0xc3f294: add             x2, x2, HEAP, lsl #32
    // 0xc3f298: cmp             w2, NULL
    // 0xc3f29c: r16 = true
    //     0xc3f29c: add             x16, NULL, #0x20  ; true
    // 0xc3f2a0: r17 = false
    //     0xc3f2a0: add             x17, NULL, #0x30  ; false
    // 0xc3f2a4: csel            x0, x16, x17, ne
    // 0xc3f2a8: ret
    //     0xc3f2a8: ret             
  }
  get _ padding(/* No info */) {
    // ** addr: 0xc43c64, size: 0x50
    // 0xc43c64: EnterFrame
    //     0xc43c64: stp             fp, lr, [SP, #-0x10]!
    //     0xc43c68: mov             fp, SP
    // 0xc43c6c: CheckStackOverflow
    //     0xc43c6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc43c70: cmp             SP, x16
    //     0xc43c74: b.ls            #0xc43cac
    // 0xc43c78: ldr             x0, [fp, #0x10]
    // 0xc43c7c: LoadField: r1 = r0->field_f
    //     0xc43c7c: ldur            w1, [x0, #0xf]
    // 0xc43c80: DecompressPointer r1
    //     0xc43c80: add             x1, x1, HEAP, lsl #32
    // 0xc43c84: cmp             w1, NULL
    // 0xc43c88: b.ne            #0xc43c94
    // 0xc43c8c: r0 = Null
    //     0xc43c8c: mov             x0, NULL
    // 0xc43c90: b               #0xc43ca0
    // 0xc43c94: SaveReg r1
    //     0xc43c94: str             x1, [SP, #-8]!
    // 0xc43c98: r0 = dimensions()
    //     0xc43c98: bl              #0xceec00  ; [package:flutter/src/painting/box_border.dart] Border::dimensions
    // 0xc43c9c: add             SP, SP, #8
    // 0xc43ca0: LeaveFrame
    //     0xc43ca0: mov             SP, fp
    //     0xc43ca4: ldp             fp, lr, [SP], #0x10
    // 0xc43ca8: ret
    //     0xc43ca8: ret             
    // 0xc43cac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc43cac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc43cb0: b               #0xc43c78
  }
  _ ==(/* No info */) {
    // ** addr: 0xc80a04, size: 0x27c
    // 0xc80a04: EnterFrame
    //     0xc80a04: stp             fp, lr, [SP, #-0x10]!
    //     0xc80a08: mov             fp, SP
    // 0xc80a0c: CheckStackOverflow
    //     0xc80a0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc80a10: cmp             SP, x16
    //     0xc80a14: b.ls            #0xc80c78
    // 0xc80a18: ldr             x1, [fp, #0x10]
    // 0xc80a1c: cmp             w1, NULL
    // 0xc80a20: b.ne            #0xc80a34
    // 0xc80a24: r0 = false
    //     0xc80a24: add             x0, NULL, #0x30  ; false
    // 0xc80a28: LeaveFrame
    //     0xc80a28: mov             SP, fp
    //     0xc80a2c: ldp             fp, lr, [SP], #0x10
    // 0xc80a30: ret
    //     0xc80a30: ret             
    // 0xc80a34: ldr             x2, [fp, #0x18]
    // 0xc80a38: cmp             w2, w1
    // 0xc80a3c: b.ne            #0xc80a50
    // 0xc80a40: r0 = true
    //     0xc80a40: add             x0, NULL, #0x20  ; true
    // 0xc80a44: LeaveFrame
    //     0xc80a44: mov             SP, fp
    //     0xc80a48: ldp             fp, lr, [SP], #0x10
    // 0xc80a4c: ret
    //     0xc80a4c: ret             
    // 0xc80a50: r0 = 59
    //     0xc80a50: mov             x0, #0x3b
    // 0xc80a54: branchIfSmi(r1, 0xc80a60)
    //     0xc80a54: tbz             w1, #0, #0xc80a60
    // 0xc80a58: r0 = LoadClassIdInstr(r1)
    //     0xc80a58: ldur            x0, [x1, #-1]
    //     0xc80a5c: ubfx            x0, x0, #0xc, #0x14
    // 0xc80a60: SaveReg r1
    //     0xc80a60: str             x1, [SP, #-8]!
    // 0xc80a64: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc80a64: mov             x17, #0x57c5
    //     0xc80a68: add             lr, x0, x17
    //     0xc80a6c: ldr             lr, [x21, lr, lsl #3]
    //     0xc80a70: blr             lr
    // 0xc80a74: add             SP, SP, #8
    // 0xc80a78: r1 = LoadClassIdInstr(r0)
    //     0xc80a78: ldur            x1, [x0, #-1]
    //     0xc80a7c: ubfx            x1, x1, #0xc, #0x14
    // 0xc80a80: r16 = BoxDecoration
    //     0xc80a80: add             x16, PP, #0x15, lsl #12  ; [pp+0x15260] Type: BoxDecoration
    //     0xc80a84: ldr             x16, [x16, #0x260]
    // 0xc80a88: stp             x16, x0, [SP, #-0x10]!
    // 0xc80a8c: mov             x0, x1
    // 0xc80a90: mov             lr, x0
    // 0xc80a94: ldr             lr, [x21, lr, lsl #3]
    // 0xc80a98: blr             lr
    // 0xc80a9c: add             SP, SP, #0x10
    // 0xc80aa0: tbz             w0, #4, #0xc80ab4
    // 0xc80aa4: r0 = false
    //     0xc80aa4: add             x0, NULL, #0x30  ; false
    // 0xc80aa8: LeaveFrame
    //     0xc80aa8: mov             SP, fp
    //     0xc80aac: ldp             fp, lr, [SP], #0x10
    // 0xc80ab0: ret
    //     0xc80ab0: ret             
    // 0xc80ab4: ldr             x1, [fp, #0x10]
    // 0xc80ab8: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc80ab8: mov             x0, #0x76
    //     0xc80abc: tbz             w1, #0, #0xc80acc
    //     0xc80ac0: ldur            x0, [x1, #-1]
    //     0xc80ac4: ubfx            x0, x0, #0xc, #0x14
    //     0xc80ac8: lsl             x0, x0, #1
    // 0xc80acc: r17 = 5874
    //     0xc80acc: mov             x17, #0x16f2
    // 0xc80ad0: cmp             w0, w17
    // 0xc80ad4: b.ne            #0xc80c68
    // 0xc80ad8: ldr             x2, [fp, #0x18]
    // 0xc80adc: LoadField: r0 = r1->field_7
    //     0xc80adc: ldur            w0, [x1, #7]
    // 0xc80ae0: DecompressPointer r0
    //     0xc80ae0: add             x0, x0, HEAP, lsl #32
    // 0xc80ae4: LoadField: r3 = r2->field_7
    //     0xc80ae4: ldur            w3, [x2, #7]
    // 0xc80ae8: DecompressPointer r3
    //     0xc80ae8: add             x3, x3, HEAP, lsl #32
    // 0xc80aec: r4 = LoadClassIdInstr(r0)
    //     0xc80aec: ldur            x4, [x0, #-1]
    //     0xc80af0: ubfx            x4, x4, #0xc, #0x14
    // 0xc80af4: stp             x3, x0, [SP, #-0x10]!
    // 0xc80af8: mov             x0, x4
    // 0xc80afc: mov             lr, x0
    // 0xc80b00: ldr             lr, [x21, lr, lsl #3]
    // 0xc80b04: blr             lr
    // 0xc80b08: add             SP, SP, #0x10
    // 0xc80b0c: tbnz            w0, #4, #0xc80c68
    // 0xc80b10: ldr             x2, [fp, #0x18]
    // 0xc80b14: ldr             x1, [fp, #0x10]
    // 0xc80b18: LoadField: r0 = r1->field_b
    //     0xc80b18: ldur            w0, [x1, #0xb]
    // 0xc80b1c: DecompressPointer r0
    //     0xc80b1c: add             x0, x0, HEAP, lsl #32
    // 0xc80b20: LoadField: r3 = r2->field_b
    //     0xc80b20: ldur            w3, [x2, #0xb]
    // 0xc80b24: DecompressPointer r3
    //     0xc80b24: add             x3, x3, HEAP, lsl #32
    // 0xc80b28: r4 = LoadClassIdInstr(r0)
    //     0xc80b28: ldur            x4, [x0, #-1]
    //     0xc80b2c: ubfx            x4, x4, #0xc, #0x14
    // 0xc80b30: stp             x3, x0, [SP, #-0x10]!
    // 0xc80b34: mov             x0, x4
    // 0xc80b38: mov             lr, x0
    // 0xc80b3c: ldr             lr, [x21, lr, lsl #3]
    // 0xc80b40: blr             lr
    // 0xc80b44: add             SP, SP, #0x10
    // 0xc80b48: tbnz            w0, #4, #0xc80c68
    // 0xc80b4c: ldr             x2, [fp, #0x18]
    // 0xc80b50: ldr             x1, [fp, #0x10]
    // 0xc80b54: LoadField: r0 = r1->field_f
    //     0xc80b54: ldur            w0, [x1, #0xf]
    // 0xc80b58: DecompressPointer r0
    //     0xc80b58: add             x0, x0, HEAP, lsl #32
    // 0xc80b5c: LoadField: r3 = r2->field_f
    //     0xc80b5c: ldur            w3, [x2, #0xf]
    // 0xc80b60: DecompressPointer r3
    //     0xc80b60: add             x3, x3, HEAP, lsl #32
    // 0xc80b64: r4 = LoadClassIdInstr(r0)
    //     0xc80b64: ldur            x4, [x0, #-1]
    //     0xc80b68: ubfx            x4, x4, #0xc, #0x14
    // 0xc80b6c: stp             x3, x0, [SP, #-0x10]!
    // 0xc80b70: mov             x0, x4
    // 0xc80b74: mov             lr, x0
    // 0xc80b78: ldr             lr, [x21, lr, lsl #3]
    // 0xc80b7c: blr             lr
    // 0xc80b80: add             SP, SP, #0x10
    // 0xc80b84: tbnz            w0, #4, #0xc80c68
    // 0xc80b88: ldr             x2, [fp, #0x18]
    // 0xc80b8c: ldr             x1, [fp, #0x10]
    // 0xc80b90: LoadField: r0 = r1->field_13
    //     0xc80b90: ldur            w0, [x1, #0x13]
    // 0xc80b94: DecompressPointer r0
    //     0xc80b94: add             x0, x0, HEAP, lsl #32
    // 0xc80b98: LoadField: r3 = r2->field_13
    //     0xc80b98: ldur            w3, [x2, #0x13]
    // 0xc80b9c: DecompressPointer r3
    //     0xc80b9c: add             x3, x3, HEAP, lsl #32
    // 0xc80ba0: r4 = LoadClassIdInstr(r0)
    //     0xc80ba0: ldur            x4, [x0, #-1]
    //     0xc80ba4: ubfx            x4, x4, #0xc, #0x14
    // 0xc80ba8: stp             x3, x0, [SP, #-0x10]!
    // 0xc80bac: mov             x0, x4
    // 0xc80bb0: mov             lr, x0
    // 0xc80bb4: ldr             lr, [x21, lr, lsl #3]
    // 0xc80bb8: blr             lr
    // 0xc80bbc: add             SP, SP, #0x10
    // 0xc80bc0: tbnz            w0, #4, #0xc80c68
    // 0xc80bc4: ldr             x1, [fp, #0x18]
    // 0xc80bc8: ldr             x0, [fp, #0x10]
    // 0xc80bcc: LoadField: r2 = r0->field_17
    //     0xc80bcc: ldur            w2, [x0, #0x17]
    // 0xc80bd0: DecompressPointer r2
    //     0xc80bd0: add             x2, x2, HEAP, lsl #32
    // 0xc80bd4: LoadField: r3 = r1->field_17
    //     0xc80bd4: ldur            w3, [x1, #0x17]
    // 0xc80bd8: DecompressPointer r3
    //     0xc80bd8: add             x3, x3, HEAP, lsl #32
    // 0xc80bdc: r16 = <BoxShadow>
    //     0xc80bdc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15268] TypeArguments: <BoxShadow>
    //     0xc80be0: ldr             x16, [x16, #0x268]
    // 0xc80be4: stp             x2, x16, [SP, #-0x10]!
    // 0xc80be8: SaveReg r3
    //     0xc80be8: str             x3, [SP, #-8]!
    // 0xc80bec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc80bec: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc80bf0: r0 = listEquals()
    //     0xc80bf0: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc80bf4: add             SP, SP, #0x18
    // 0xc80bf8: tbnz            w0, #4, #0xc80c68
    // 0xc80bfc: ldr             x2, [fp, #0x18]
    // 0xc80c00: ldr             x1, [fp, #0x10]
    // 0xc80c04: LoadField: r0 = r1->field_1b
    //     0xc80c04: ldur            w0, [x1, #0x1b]
    // 0xc80c08: DecompressPointer r0
    //     0xc80c08: add             x0, x0, HEAP, lsl #32
    // 0xc80c0c: LoadField: r3 = r2->field_1b
    //     0xc80c0c: ldur            w3, [x2, #0x1b]
    // 0xc80c10: DecompressPointer r3
    //     0xc80c10: add             x3, x3, HEAP, lsl #32
    // 0xc80c14: r4 = LoadClassIdInstr(r0)
    //     0xc80c14: ldur            x4, [x0, #-1]
    //     0xc80c18: ubfx            x4, x4, #0xc, #0x14
    // 0xc80c1c: stp             x3, x0, [SP, #-0x10]!
    // 0xc80c20: mov             x0, x4
    // 0xc80c24: mov             lr, x0
    // 0xc80c28: ldr             lr, [x21, lr, lsl #3]
    // 0xc80c2c: blr             lr
    // 0xc80c30: add             SP, SP, #0x10
    // 0xc80c34: tbnz            w0, #4, #0xc80c68
    // 0xc80c38: ldr             x2, [fp, #0x18]
    // 0xc80c3c: ldr             x1, [fp, #0x10]
    // 0xc80c40: LoadField: r3 = r1->field_23
    //     0xc80c40: ldur            w3, [x1, #0x23]
    // 0xc80c44: DecompressPointer r3
    //     0xc80c44: add             x3, x3, HEAP, lsl #32
    // 0xc80c48: LoadField: r1 = r2->field_23
    //     0xc80c48: ldur            w1, [x2, #0x23]
    // 0xc80c4c: DecompressPointer r1
    //     0xc80c4c: add             x1, x1, HEAP, lsl #32
    // 0xc80c50: cmp             w3, w1
    // 0xc80c54: r16 = true
    //     0xc80c54: add             x16, NULL, #0x20  ; true
    // 0xc80c58: r17 = false
    //     0xc80c58: add             x17, NULL, #0x30  ; false
    // 0xc80c5c: csel            x2, x16, x17, eq
    // 0xc80c60: mov             x0, x2
    // 0xc80c64: b               #0xc80c6c
    // 0xc80c68: r0 = false
    //     0xc80c68: add             x0, NULL, #0x30  ; false
    // 0xc80c6c: LeaveFrame
    //     0xc80c6c: mov             SP, fp
    //     0xc80c70: ldp             fp, lr, [SP], #0x10
    // 0xc80c74: ret
    //     0xc80c74: ret             
    // 0xc80c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc80c78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc80c7c: b               #0xc80a18
  }
  _ createBoxPainter(/* No info */) {
    // ** addr: 0xccf578, size: 0x28
    // 0xccf578: EnterFrame
    //     0xccf578: stp             fp, lr, [SP, #-0x10]!
    //     0xccf57c: mov             fp, SP
    // 0xccf580: r0 = _BoxDecorationPainter()
    //     0xccf580: bl              #0xccf5a0  ; Allocate_BoxDecorationPainterStub -> _BoxDecorationPainter (size=0x1c)
    // 0xccf584: ldr             x1, [fp, #0x18]
    // 0xccf588: StoreField: r0->field_b = r1
    //     0xccf588: stur            w1, [x0, #0xb]
    // 0xccf58c: ldr             x1, [fp, #0x10]
    // 0xccf590: StoreField: r0->field_7 = r1
    //     0xccf590: stur            w1, [x0, #7]
    // 0xccf594: LeaveFrame
    //     0xccf594: mov             SP, fp
    //     0xccf598: ldp             fp, lr, [SP], #0x10
    // 0xccf59c: ret
    //     0xccf59c: ret             
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0xcd52f8, size: 0xa0
    // 0xcd52f8: EnterFrame
    //     0xcd52f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd52fc: mov             fp, SP
    // 0xcd5300: CheckStackOverflow
    //     0xcd5300: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd5304: cmp             SP, x16
    //     0xcd5308: b.ls            #0xcd5390
    // 0xcd530c: ldr             x0, [fp, #0x18]
    // 0xcd5310: cmp             w0, NULL
    // 0xcd5314: b.ne            #0xcd5344
    // 0xcd5318: ldr             d1, [fp, #0x10]
    // 0xcd531c: d0 = 1.000000
    //     0xcd531c: fmov            d0, #1.00000000
    // 0xcd5320: fsub            d2, d0, d1
    // 0xcd5324: ldr             x16, [fp, #0x20]
    // 0xcd5328: SaveReg r16
    //     0xcd5328: str             x16, [SP, #-8]!
    // 0xcd532c: SaveReg d2
    //     0xcd532c: str             d2, [SP, #-8]!
    // 0xcd5330: r0 = scale()
    //     0xcd5330: bl              #0xcd6a70  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::scale
    // 0xcd5334: add             SP, SP, #0x10
    // 0xcd5338: LeaveFrame
    //     0xcd5338: mov             SP, fp
    //     0xcd533c: ldp             fp, lr, [SP], #0x10
    // 0xcd5340: ret
    //     0xcd5340: ret             
    // 0xcd5344: ldr             d1, [fp, #0x10]
    // 0xcd5348: r1 = LoadClassIdInstr(r0)
    //     0xcd5348: ldur            x1, [x0, #-1]
    //     0xcd534c: ubfx            x1, x1, #0xc, #0x14
    // 0xcd5350: lsl             x1, x1, #1
    // 0xcd5354: r17 = 5874
    //     0xcd5354: mov             x17, #0x16f2
    // 0xcd5358: cmp             w1, w17
    // 0xcd535c: b.ne            #0xcd5380
    // 0xcd5360: ldr             x16, [fp, #0x20]
    // 0xcd5364: stp             x0, x16, [SP, #-0x10]!
    // 0xcd5368: SaveReg d1
    //     0xcd5368: str             d1, [SP, #-8]!
    // 0xcd536c: r0 = lerp()
    //     0xcd536c: bl              #0xcd5398  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::lerp
    // 0xcd5370: add             SP, SP, #0x18
    // 0xcd5374: LeaveFrame
    //     0xcd5374: mov             SP, fp
    //     0xcd5378: ldp             fp, lr, [SP], #0x10
    // 0xcd537c: ret
    //     0xcd537c: ret             
    // 0xcd5380: r0 = Null
    //     0xcd5380: mov             x0, NULL
    // 0xcd5384: LeaveFrame
    //     0xcd5384: mov             SP, fp
    //     0xcd5388: ldp             fp, lr, [SP], #0x10
    // 0xcd538c: ret
    //     0xcd538c: ret             
    // 0xcd5390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd5390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd5394: b               #0xcd530c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xcd5398, size: 0x280
    // 0xcd5398: EnterFrame
    //     0xcd5398: stp             fp, lr, [SP, #-0x10]!
    //     0xcd539c: mov             fp, SP
    // 0xcd53a0: AllocStack(0x38)
    //     0xcd53a0: sub             SP, SP, #0x38
    // 0xcd53a4: d0 = 0.000000
    //     0xcd53a4: eor             v0.16b, v0.16b, v0.16b
    // 0xcd53a8: CheckStackOverflow
    //     0xcd53a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd53ac: cmp             SP, x16
    //     0xcd53b0: b.ls            #0xcd55ec
    // 0xcd53b4: ldr             d1, [fp, #0x10]
    // 0xcd53b8: fcmp            d1, d0
    // 0xcd53bc: b.vs            #0xcd53d4
    // 0xcd53c0: b.ne            #0xcd53d4
    // 0xcd53c4: ldr             x0, [fp, #0x20]
    // 0xcd53c8: LeaveFrame
    //     0xcd53c8: mov             SP, fp
    //     0xcd53cc: ldp             fp, lr, [SP], #0x10
    // 0xcd53d0: ret
    //     0xcd53d0: ret             
    // 0xcd53d4: d0 = 1.000000
    //     0xcd53d4: fmov            d0, #1.00000000
    // 0xcd53d8: fcmp            d1, d0
    // 0xcd53dc: b.vs            #0xcd53f4
    // 0xcd53e0: b.ne            #0xcd53f4
    // 0xcd53e4: ldr             x0, [fp, #0x18]
    // 0xcd53e8: LeaveFrame
    //     0xcd53e8: mov             SP, fp
    //     0xcd53ec: ldp             fp, lr, [SP], #0x10
    // 0xcd53f0: ret
    //     0xcd53f0: ret             
    // 0xcd53f4: ldr             x1, [fp, #0x20]
    // 0xcd53f8: ldr             x0, [fp, #0x18]
    // 0xcd53fc: LoadField: r2 = r1->field_7
    //     0xcd53fc: ldur            w2, [x1, #7]
    // 0xcd5400: DecompressPointer r2
    //     0xcd5400: add             x2, x2, HEAP, lsl #32
    // 0xcd5404: LoadField: r3 = r0->field_7
    //     0xcd5404: ldur            w3, [x0, #7]
    // 0xcd5408: DecompressPointer r3
    //     0xcd5408: add             x3, x3, HEAP, lsl #32
    // 0xcd540c: r4 = inline_Allocate_Double()
    //     0xcd540c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xcd5410: add             x4, x4, #0x10
    //     0xcd5414: cmp             x5, x4
    //     0xcd5418: b.ls            #0xcd55f4
    //     0xcd541c: str             x4, [THR, #0x60]  ; THR::top
    //     0xcd5420: sub             x4, x4, #0xf
    //     0xcd5424: mov             x5, #0xd108
    //     0xcd5428: movk            x5, #3, lsl #16
    //     0xcd542c: stur            x5, [x4, #-1]
    // 0xcd5430: StoreField: r4->field_7 = d1
    //     0xcd5430: stur            d1, [x4, #7]
    // 0xcd5434: stp             x3, x2, [SP, #-0x10]!
    // 0xcd5438: SaveReg r4
    //     0xcd5438: str             x4, [SP, #-8]!
    // 0xcd543c: r0 = lerp()
    //     0xcd543c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd5440: add             SP, SP, #0x18
    // 0xcd5444: ldr             d0, [fp, #0x10]
    // 0xcd5448: d1 = 0.500000
    //     0xcd5448: fmov            d1, #0.50000000
    // 0xcd544c: stur            x0, [fp, #-0x18]
    // 0xcd5450: fcmp            d0, d1
    // 0xcd5454: b.vs            #0xcd545c
    // 0xcd5458: b.lt            #0xcd5464
    // 0xcd545c: r1 = false
    //     0xcd545c: add             x1, NULL, #0x30  ; false
    // 0xcd5460: b               #0xcd5468
    // 0xcd5464: r1 = true
    //     0xcd5464: add             x1, NULL, #0x20  ; true
    // 0xcd5468: stur            x1, [fp, #-0x10]
    // 0xcd546c: tbnz            w1, #4, #0xcd5488
    // 0xcd5470: ldr             x2, [fp, #0x20]
    // 0xcd5474: LoadField: r3 = r2->field_b
    //     0xcd5474: ldur            w3, [x2, #0xb]
    // 0xcd5478: DecompressPointer r3
    //     0xcd5478: add             x3, x3, HEAP, lsl #32
    // 0xcd547c: mov             x4, x3
    // 0xcd5480: ldr             x3, [fp, #0x18]
    // 0xcd5484: b               #0xcd5498
    // 0xcd5488: ldr             x2, [fp, #0x20]
    // 0xcd548c: ldr             x3, [fp, #0x18]
    // 0xcd5490: LoadField: r4 = r3->field_b
    //     0xcd5490: ldur            w4, [x3, #0xb]
    // 0xcd5494: DecompressPointer r4
    //     0xcd5494: add             x4, x4, HEAP, lsl #32
    // 0xcd5498: stur            x4, [fp, #-8]
    // 0xcd549c: LoadField: r5 = r2->field_f
    //     0xcd549c: ldur            w5, [x2, #0xf]
    // 0xcd54a0: DecompressPointer r5
    //     0xcd54a0: add             x5, x5, HEAP, lsl #32
    // 0xcd54a4: LoadField: r6 = r3->field_f
    //     0xcd54a4: ldur            w6, [x3, #0xf]
    // 0xcd54a8: DecompressPointer r6
    //     0xcd54a8: add             x6, x6, HEAP, lsl #32
    // 0xcd54ac: stp             x6, x5, [SP, #-0x10]!
    // 0xcd54b0: SaveReg d0
    //     0xcd54b0: str             d0, [SP, #-8]!
    // 0xcd54b4: r0 = lerp()
    //     0xcd54b4: bl              #0x70df28  ; [package:flutter/src/painting/box_border.dart] Border::lerp
    // 0xcd54b8: add             SP, SP, #0x18
    // 0xcd54bc: mov             x1, x0
    // 0xcd54c0: ldr             x0, [fp, #0x20]
    // 0xcd54c4: stur            x1, [fp, #-0x20]
    // 0xcd54c8: LoadField: r2 = r0->field_13
    //     0xcd54c8: ldur            w2, [x0, #0x13]
    // 0xcd54cc: DecompressPointer r2
    //     0xcd54cc: add             x2, x2, HEAP, lsl #32
    // 0xcd54d0: ldr             x3, [fp, #0x18]
    // 0xcd54d4: LoadField: r4 = r3->field_13
    //     0xcd54d4: ldur            w4, [x3, #0x13]
    // 0xcd54d8: DecompressPointer r4
    //     0xcd54d8: add             x4, x4, HEAP, lsl #32
    // 0xcd54dc: stp             x4, x2, [SP, #-0x10]!
    // 0xcd54e0: ldr             d0, [fp, #0x10]
    // 0xcd54e4: SaveReg d0
    //     0xcd54e4: str             d0, [SP, #-8]!
    // 0xcd54e8: r0 = lerp()
    //     0xcd54e8: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0xcd54ec: add             SP, SP, #0x18
    // 0xcd54f0: mov             x1, x0
    // 0xcd54f4: ldr             x0, [fp, #0x20]
    // 0xcd54f8: stur            x1, [fp, #-0x28]
    // 0xcd54fc: LoadField: r2 = r0->field_17
    //     0xcd54fc: ldur            w2, [x0, #0x17]
    // 0xcd5500: DecompressPointer r2
    //     0xcd5500: add             x2, x2, HEAP, lsl #32
    // 0xcd5504: ldr             x3, [fp, #0x18]
    // 0xcd5508: LoadField: r4 = r3->field_17
    //     0xcd5508: ldur            w4, [x3, #0x17]
    // 0xcd550c: DecompressPointer r4
    //     0xcd550c: add             x4, x4, HEAP, lsl #32
    // 0xcd5510: stp             x4, x2, [SP, #-0x10]!
    // 0xcd5514: ldr             d0, [fp, #0x10]
    // 0xcd5518: SaveReg d0
    //     0xcd5518: str             d0, [SP, #-8]!
    // 0xcd551c: r0 = lerpList()
    //     0xcd551c: bl              #0xcd60ec  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::lerpList
    // 0xcd5520: add             SP, SP, #0x18
    // 0xcd5524: mov             x1, x0
    // 0xcd5528: ldr             x0, [fp, #0x20]
    // 0xcd552c: stur            x1, [fp, #-0x30]
    // 0xcd5530: LoadField: r2 = r0->field_1b
    //     0xcd5530: ldur            w2, [x0, #0x1b]
    // 0xcd5534: DecompressPointer r2
    //     0xcd5534: add             x2, x2, HEAP, lsl #32
    // 0xcd5538: ldr             x3, [fp, #0x18]
    // 0xcd553c: LoadField: r4 = r3->field_1b
    //     0xcd553c: ldur            w4, [x3, #0x1b]
    // 0xcd5540: DecompressPointer r4
    //     0xcd5540: add             x4, x4, HEAP, lsl #32
    // 0xcd5544: stp             x4, x2, [SP, #-0x10]!
    // 0xcd5548: ldr             d0, [fp, #0x10]
    // 0xcd554c: SaveReg d0
    //     0xcd554c: str             d0, [SP, #-8]!
    // 0xcd5550: r0 = lerp()
    //     0xcd5550: bl              #0xcd5618  ; [package:flutter/src/painting/gradient.dart] Gradient::lerp
    // 0xcd5554: add             SP, SP, #0x18
    // 0xcd5558: mov             x1, x0
    // 0xcd555c: ldur            x0, [fp, #-0x10]
    // 0xcd5560: stur            x1, [fp, #-0x38]
    // 0xcd5564: tbnz            w0, #4, #0xcd557c
    // 0xcd5568: ldr             x0, [fp, #0x20]
    // 0xcd556c: LoadField: r2 = r0->field_23
    //     0xcd556c: ldur            w2, [x0, #0x23]
    // 0xcd5570: DecompressPointer r2
    //     0xcd5570: add             x2, x2, HEAP, lsl #32
    // 0xcd5574: mov             x6, x2
    // 0xcd5578: b               #0xcd558c
    // 0xcd557c: ldr             x0, [fp, #0x18]
    // 0xcd5580: LoadField: r2 = r0->field_23
    //     0xcd5580: ldur            w2, [x0, #0x23]
    // 0xcd5584: DecompressPointer r2
    //     0xcd5584: add             x2, x2, HEAP, lsl #32
    // 0xcd5588: mov             x6, x2
    // 0xcd558c: ldur            x4, [fp, #-0x18]
    // 0xcd5590: ldur            x5, [fp, #-8]
    // 0xcd5594: ldur            x2, [fp, #-0x28]
    // 0xcd5598: ldur            x0, [fp, #-0x30]
    // 0xcd559c: ldur            x3, [fp, #-0x20]
    // 0xcd55a0: stur            x6, [fp, #-0x10]
    // 0xcd55a4: r0 = BoxDecoration()
    //     0xcd55a4: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xcd55a8: ldur            x1, [fp, #-0x18]
    // 0xcd55ac: StoreField: r0->field_7 = r1
    //     0xcd55ac: stur            w1, [x0, #7]
    // 0xcd55b0: ldur            x1, [fp, #-8]
    // 0xcd55b4: StoreField: r0->field_b = r1
    //     0xcd55b4: stur            w1, [x0, #0xb]
    // 0xcd55b8: ldur            x1, [fp, #-0x20]
    // 0xcd55bc: StoreField: r0->field_f = r1
    //     0xcd55bc: stur            w1, [x0, #0xf]
    // 0xcd55c0: ldur            x1, [fp, #-0x28]
    // 0xcd55c4: StoreField: r0->field_13 = r1
    //     0xcd55c4: stur            w1, [x0, #0x13]
    // 0xcd55c8: ldur            x1, [fp, #-0x30]
    // 0xcd55cc: StoreField: r0->field_17 = r1
    //     0xcd55cc: stur            w1, [x0, #0x17]
    // 0xcd55d0: ldur            x1, [fp, #-0x38]
    // 0xcd55d4: StoreField: r0->field_1b = r1
    //     0xcd55d4: stur            w1, [x0, #0x1b]
    // 0xcd55d8: ldur            x1, [fp, #-0x10]
    // 0xcd55dc: StoreField: r0->field_23 = r1
    //     0xcd55dc: stur            w1, [x0, #0x23]
    // 0xcd55e0: LeaveFrame
    //     0xcd55e0: mov             SP, fp
    //     0xcd55e4: ldp             fp, lr, [SP], #0x10
    // 0xcd55e8: ret
    //     0xcd55e8: ret             
    // 0xcd55ec: r0 = StackOverflowSharedWithFPURegs()
    //     0xcd55ec: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcd55f0: b               #0xcd53b4
    // 0xcd55f4: SaveReg d1
    //     0xcd55f4: str             q1, [SP, #-0x10]!
    // 0xcd55f8: stp             x2, x3, [SP, #-0x10]!
    // 0xcd55fc: stp             x0, x1, [SP, #-0x10]!
    // 0xcd5600: r0 = AllocateDouble()
    //     0xcd5600: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd5604: mov             x4, x0
    // 0xcd5608: ldp             x0, x1, [SP], #0x10
    // 0xcd560c: ldp             x2, x3, [SP], #0x10
    // 0xcd5610: RestoreReg d1
    //     0xcd5610: ldr             q1, [SP], #0x10
    // 0xcd5614: b               #0xcd5430
  }
  _ scale(/* No info */) {
    // ** addr: 0xcd6a70, size: 0x1b4
    // 0xcd6a70: EnterFrame
    //     0xcd6a70: stp             fp, lr, [SP, #-0x10]!
    //     0xcd6a74: mov             fp, SP
    // 0xcd6a78: AllocStack(0x38)
    //     0xcd6a78: sub             SP, SP, #0x38
    // 0xcd6a7c: CheckStackOverflow
    //     0xcd6a7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd6a80: cmp             SP, x16
    //     0xcd6a84: b.ls            #0xcd6c00
    // 0xcd6a88: ldr             x0, [fp, #0x18]
    // 0xcd6a8c: LoadField: r1 = r0->field_7
    //     0xcd6a8c: ldur            w1, [x0, #7]
    // 0xcd6a90: DecompressPointer r1
    //     0xcd6a90: add             x1, x1, HEAP, lsl #32
    // 0xcd6a94: ldr             d0, [fp, #0x10]
    // 0xcd6a98: r2 = inline_Allocate_Double()
    //     0xcd6a98: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xcd6a9c: add             x2, x2, #0x10
    //     0xcd6aa0: cmp             x3, x2
    //     0xcd6aa4: b.ls            #0xcd6c08
    //     0xcd6aa8: str             x2, [THR, #0x60]  ; THR::top
    //     0xcd6aac: sub             x2, x2, #0xf
    //     0xcd6ab0: mov             x3, #0xd108
    //     0xcd6ab4: movk            x3, #3, lsl #16
    //     0xcd6ab8: stur            x3, [x2, #-1]
    // 0xcd6abc: StoreField: r2->field_7 = d0
    //     0xcd6abc: stur            d0, [x2, #7]
    // 0xcd6ac0: stp             x1, NULL, [SP, #-0x10]!
    // 0xcd6ac4: SaveReg r2
    //     0xcd6ac4: str             x2, [SP, #-8]!
    // 0xcd6ac8: r0 = lerp()
    //     0xcd6ac8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd6acc: add             SP, SP, #0x18
    // 0xcd6ad0: mov             x1, x0
    // 0xcd6ad4: ldr             x0, [fp, #0x18]
    // 0xcd6ad8: stur            x1, [fp, #-0x10]
    // 0xcd6adc: LoadField: r2 = r0->field_b
    //     0xcd6adc: ldur            w2, [x0, #0xb]
    // 0xcd6ae0: DecompressPointer r2
    //     0xcd6ae0: add             x2, x2, HEAP, lsl #32
    // 0xcd6ae4: stur            x2, [fp, #-8]
    // 0xcd6ae8: LoadField: r3 = r0->field_f
    //     0xcd6ae8: ldur            w3, [x0, #0xf]
    // 0xcd6aec: DecompressPointer r3
    //     0xcd6aec: add             x3, x3, HEAP, lsl #32
    // 0xcd6af0: stp             x3, NULL, [SP, #-0x10]!
    // 0xcd6af4: ldr             d0, [fp, #0x10]
    // 0xcd6af8: SaveReg d0
    //     0xcd6af8: str             d0, [SP, #-8]!
    // 0xcd6afc: r0 = lerp()
    //     0xcd6afc: bl              #0x70df28  ; [package:flutter/src/painting/box_border.dart] Border::lerp
    // 0xcd6b00: add             SP, SP, #0x18
    // 0xcd6b04: mov             x1, x0
    // 0xcd6b08: ldr             x0, [fp, #0x18]
    // 0xcd6b0c: stur            x1, [fp, #-0x18]
    // 0xcd6b10: LoadField: r2 = r0->field_13
    //     0xcd6b10: ldur            w2, [x0, #0x13]
    // 0xcd6b14: DecompressPointer r2
    //     0xcd6b14: add             x2, x2, HEAP, lsl #32
    // 0xcd6b18: stp             x2, NULL, [SP, #-0x10]!
    // 0xcd6b1c: ldr             d0, [fp, #0x10]
    // 0xcd6b20: SaveReg d0
    //     0xcd6b20: str             d0, [SP, #-8]!
    // 0xcd6b24: r0 = lerp()
    //     0xcd6b24: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0xcd6b28: add             SP, SP, #0x18
    // 0xcd6b2c: mov             x1, x0
    // 0xcd6b30: ldr             x0, [fp, #0x18]
    // 0xcd6b34: stur            x1, [fp, #-0x20]
    // 0xcd6b38: LoadField: r2 = r0->field_17
    //     0xcd6b38: ldur            w2, [x0, #0x17]
    // 0xcd6b3c: DecompressPointer r2
    //     0xcd6b3c: add             x2, x2, HEAP, lsl #32
    // 0xcd6b40: stp             x2, NULL, [SP, #-0x10]!
    // 0xcd6b44: ldr             d0, [fp, #0x10]
    // 0xcd6b48: SaveReg d0
    //     0xcd6b48: str             d0, [SP, #-8]!
    // 0xcd6b4c: r0 = lerpList()
    //     0xcd6b4c: bl              #0xcd60ec  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::lerpList
    // 0xcd6b50: add             SP, SP, #0x18
    // 0xcd6b54: mov             x1, x0
    // 0xcd6b58: ldr             x0, [fp, #0x18]
    // 0xcd6b5c: stur            x1, [fp, #-0x28]
    // 0xcd6b60: LoadField: r2 = r0->field_1b
    //     0xcd6b60: ldur            w2, [x0, #0x1b]
    // 0xcd6b64: DecompressPointer r2
    //     0xcd6b64: add             x2, x2, HEAP, lsl #32
    // 0xcd6b68: cmp             w2, NULL
    // 0xcd6b6c: b.ne            #0xcd6b78
    // 0xcd6b70: r6 = Null
    //     0xcd6b70: mov             x6, NULL
    // 0xcd6b74: b               #0xcd6b98
    // 0xcd6b78: ldr             d0, [fp, #0x10]
    // 0xcd6b7c: SaveReg r2
    //     0xcd6b7c: str             x2, [SP, #-8]!
    // 0xcd6b80: SaveReg d0
    //     0xcd6b80: str             d0, [SP, #-8]!
    // 0xcd6b84: r0 = scale()
    //     0xcd6b84: bl              #0xcd50a8  ; [package:flutter/src/painting/gradient.dart] LinearGradient::scale
    // 0xcd6b88: add             SP, SP, #0x10
    // 0xcd6b8c: mov             x6, x0
    // 0xcd6b90: ldr             x0, [fp, #0x18]
    // 0xcd6b94: ldur            x1, [fp, #-0x28]
    // 0xcd6b98: ldur            x4, [fp, #-0x10]
    // 0xcd6b9c: ldur            x5, [fp, #-8]
    // 0xcd6ba0: ldur            x2, [fp, #-0x20]
    // 0xcd6ba4: ldur            x3, [fp, #-0x18]
    // 0xcd6ba8: stur            x6, [fp, #-0x38]
    // 0xcd6bac: LoadField: r7 = r0->field_23
    //     0xcd6bac: ldur            w7, [x0, #0x23]
    // 0xcd6bb0: DecompressPointer r7
    //     0xcd6bb0: add             x7, x7, HEAP, lsl #32
    // 0xcd6bb4: stur            x7, [fp, #-0x30]
    // 0xcd6bb8: r0 = BoxDecoration()
    //     0xcd6bb8: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xcd6bbc: ldur            x1, [fp, #-0x10]
    // 0xcd6bc0: StoreField: r0->field_7 = r1
    //     0xcd6bc0: stur            w1, [x0, #7]
    // 0xcd6bc4: ldur            x1, [fp, #-8]
    // 0xcd6bc8: StoreField: r0->field_b = r1
    //     0xcd6bc8: stur            w1, [x0, #0xb]
    // 0xcd6bcc: ldur            x1, [fp, #-0x18]
    // 0xcd6bd0: StoreField: r0->field_f = r1
    //     0xcd6bd0: stur            w1, [x0, #0xf]
    // 0xcd6bd4: ldur            x1, [fp, #-0x20]
    // 0xcd6bd8: StoreField: r0->field_13 = r1
    //     0xcd6bd8: stur            w1, [x0, #0x13]
    // 0xcd6bdc: ldur            x1, [fp, #-0x28]
    // 0xcd6be0: StoreField: r0->field_17 = r1
    //     0xcd6be0: stur            w1, [x0, #0x17]
    // 0xcd6be4: ldur            x1, [fp, #-0x38]
    // 0xcd6be8: StoreField: r0->field_1b = r1
    //     0xcd6be8: stur            w1, [x0, #0x1b]
    // 0xcd6bec: ldur            x1, [fp, #-0x30]
    // 0xcd6bf0: StoreField: r0->field_23 = r1
    //     0xcd6bf0: stur            w1, [x0, #0x23]
    // 0xcd6bf4: LeaveFrame
    //     0xcd6bf4: mov             SP, fp
    //     0xcd6bf8: ldp             fp, lr, [SP], #0x10
    // 0xcd6bfc: ret
    //     0xcd6bfc: ret             
    // 0xcd6c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd6c00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd6c04: b               #0xcd6a88
    // 0xcd6c08: SaveReg d0
    //     0xcd6c08: str             q0, [SP, #-0x10]!
    // 0xcd6c0c: stp             x0, x1, [SP, #-0x10]!
    // 0xcd6c10: r0 = AllocateDouble()
    //     0xcd6c10: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd6c14: mov             x2, x0
    // 0xcd6c18: ldp             x0, x1, [SP], #0x10
    // 0xcd6c1c: RestoreReg d0
    //     0xcd6c1c: ldr             q0, [SP], #0x10
    // 0xcd6c20: b               #0xcd6abc
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0xcd72c8, size: 0x98
    // 0xcd72c8: EnterFrame
    //     0xcd72c8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd72cc: mov             fp, SP
    // 0xcd72d0: CheckStackOverflow
    //     0xcd72d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd72d4: cmp             SP, x16
    //     0xcd72d8: b.ls            #0xcd7358
    // 0xcd72dc: ldr             x0, [fp, #0x18]
    // 0xcd72e0: cmp             w0, NULL
    // 0xcd72e4: b.ne            #0xcd730c
    // 0xcd72e8: ldr             d0, [fp, #0x10]
    // 0xcd72ec: ldr             x16, [fp, #0x20]
    // 0xcd72f0: SaveReg r16
    //     0xcd72f0: str             x16, [SP, #-8]!
    // 0xcd72f4: SaveReg d0
    //     0xcd72f4: str             d0, [SP, #-8]!
    // 0xcd72f8: r0 = scale()
    //     0xcd72f8: bl              #0xcd6a70  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::scale
    // 0xcd72fc: add             SP, SP, #0x10
    // 0xcd7300: LeaveFrame
    //     0xcd7300: mov             SP, fp
    //     0xcd7304: ldp             fp, lr, [SP], #0x10
    // 0xcd7308: ret
    //     0xcd7308: ret             
    // 0xcd730c: ldr             d0, [fp, #0x10]
    // 0xcd7310: r1 = LoadClassIdInstr(r0)
    //     0xcd7310: ldur            x1, [x0, #-1]
    //     0xcd7314: ubfx            x1, x1, #0xc, #0x14
    // 0xcd7318: lsl             x1, x1, #1
    // 0xcd731c: r17 = 5874
    //     0xcd731c: mov             x17, #0x16f2
    // 0xcd7320: cmp             w1, w17
    // 0xcd7324: b.ne            #0xcd7348
    // 0xcd7328: ldr             x16, [fp, #0x20]
    // 0xcd732c: stp             x16, x0, [SP, #-0x10]!
    // 0xcd7330: SaveReg d0
    //     0xcd7330: str             d0, [SP, #-8]!
    // 0xcd7334: r0 = lerp()
    //     0xcd7334: bl              #0xcd5398  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::lerp
    // 0xcd7338: add             SP, SP, #0x18
    // 0xcd733c: LeaveFrame
    //     0xcd733c: mov             SP, fp
    //     0xcd7340: ldp             fp, lr, [SP], #0x10
    // 0xcd7344: ret
    //     0xcd7344: ret             
    // 0xcd7348: r0 = Null
    //     0xcd7348: mov             x0, NULL
    // 0xcd734c: LeaveFrame
    //     0xcd734c: mov             SP, fp
    //     0xcd7350: ldp             fp, lr, [SP], #0x10
    // 0xcd7354: ret
    //     0xcd7354: ret             
    // 0xcd7358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd7358: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd735c: b               #0xcd72dc
  }
}

// class id: 4510, size: 0x1c, field offset: 0xc
class _BoxDecorationPainter extends BoxPainter {

  _ toString(/* No info */) {
    // ** addr: 0xad3a44, size: 0x5c
    // 0xad3a44: EnterFrame
    //     0xad3a44: stp             fp, lr, [SP, #-0x10]!
    //     0xad3a48: mov             fp, SP
    // 0xad3a4c: CheckStackOverflow
    //     0xad3a4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3a50: cmp             SP, x16
    //     0xad3a54: b.ls            #0xad3a98
    // 0xad3a58: r1 = Null
    //     0xad3a58: mov             x1, NULL
    // 0xad3a5c: r2 = 4
    //     0xad3a5c: mov             x2, #4
    // 0xad3a60: r0 = AllocateArray()
    //     0xad3a60: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad3a64: r17 = "BoxPainter for "
    //     0xad3a64: add             x17, PP, #0x28, lsl #12  ; [pp+0x286d8] "BoxPainter for "
    //     0xad3a68: ldr             x17, [x17, #0x6d8]
    // 0xad3a6c: StoreField: r0->field_f = r17
    //     0xad3a6c: stur            w17, [x0, #0xf]
    // 0xad3a70: ldr             x1, [fp, #0x10]
    // 0xad3a74: LoadField: r2 = r1->field_b
    //     0xad3a74: ldur            w2, [x1, #0xb]
    // 0xad3a78: DecompressPointer r2
    //     0xad3a78: add             x2, x2, HEAP, lsl #32
    // 0xad3a7c: StoreField: r0->field_13 = r2
    //     0xad3a7c: stur            w2, [x0, #0x13]
    // 0xad3a80: SaveReg r0
    //     0xad3a80: str             x0, [SP, #-8]!
    // 0xad3a84: r0 = _interpolate()
    //     0xad3a84: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3a88: add             SP, SP, #8
    // 0xad3a8c: LeaveFrame
    //     0xad3a8c: mov             SP, fp
    //     0xad3a90: ldp             fp, lr, [SP], #0x10
    // 0xad3a94: ret
    //     0xad3a94: ret             
    // 0xad3a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3a98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3a9c: b               #0xad3a58
  }
  _ paint(/* No info */) {
    // ** addr: 0xc70cb0, size: 0x178
    // 0xc70cb0: EnterFrame
    //     0xc70cb0: stp             fp, lr, [SP, #-0x10]!
    //     0xc70cb4: mov             fp, SP
    // 0xc70cb8: AllocStack(0x20)
    //     0xc70cb8: sub             SP, SP, #0x20
    // 0xc70cbc: CheckStackOverflow
    //     0xc70cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc70cc0: cmp             SP, x16
    //     0xc70cc4: b.ls            #0xc70e1c
    // 0xc70cc8: ldr             x0, [fp, #0x10]
    // 0xc70ccc: LoadField: r1 = r0->field_17
    //     0xc70ccc: ldur            w1, [x0, #0x17]
    // 0xc70cd0: DecompressPointer r1
    //     0xc70cd0: add             x1, x1, HEAP, lsl #32
    // 0xc70cd4: cmp             w1, NULL
    // 0xc70cd8: b.eq            #0xc70e24
    // 0xc70cdc: ldr             x16, [fp, #0x18]
    // 0xc70ce0: stp             x1, x16, [SP, #-0x10]!
    // 0xc70ce4: r0 = &()
    //     0xc70ce4: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xc70ce8: add             SP, SP, #0x10
    // 0xc70cec: mov             x1, x0
    // 0xc70cf0: ldr             x0, [fp, #0x10]
    // 0xc70cf4: stur            x1, [fp, #-0x10]
    // 0xc70cf8: LoadField: r2 = r0->field_13
    //     0xc70cf8: ldur            w2, [x0, #0x13]
    // 0xc70cfc: DecompressPointer r2
    //     0xc70cfc: add             x2, x2, HEAP, lsl #32
    // 0xc70d00: stur            x2, [fp, #-8]
    // 0xc70d04: ldr             x16, [fp, #0x28]
    // 0xc70d08: ldr             lr, [fp, #0x20]
    // 0xc70d0c: stp             lr, x16, [SP, #-0x10]!
    // 0xc70d10: stp             x2, x1, [SP, #-0x10]!
    // 0xc70d14: r0 = _paintShadows()
    //     0xc70d14: bl              #0xc71d18  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintShadows
    // 0xc70d18: add             SP, SP, #0x20
    // 0xc70d1c: ldr             x16, [fp, #0x28]
    // 0xc70d20: ldr             lr, [fp, #0x20]
    // 0xc70d24: stp             lr, x16, [SP, #-0x10]!
    // 0xc70d28: ldur            x16, [fp, #-0x10]
    // 0xc70d2c: ldur            lr, [fp, #-8]
    // 0xc70d30: stp             lr, x16, [SP, #-0x10]!
    // 0xc70d34: r0 = _paintBackgroundColor()
    //     0xc70d34: bl              #0xc71550  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintBackgroundColor
    // 0xc70d38: add             SP, SP, #0x20
    // 0xc70d3c: ldr             x16, [fp, #0x28]
    // 0xc70d40: ldr             lr, [fp, #0x20]
    // 0xc70d44: stp             lr, x16, [SP, #-0x10]!
    // 0xc70d48: ldur            x16, [fp, #-0x10]
    // 0xc70d4c: ldr             lr, [fp, #0x10]
    // 0xc70d50: stp             lr, x16, [SP, #-0x10]!
    // 0xc70d54: r0 = _paintBackgroundImage()
    //     0xc70d54: bl              #0xc70e28  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintBackgroundImage
    // 0xc70d58: add             SP, SP, #0x20
    // 0xc70d5c: ldr             x0, [fp, #0x28]
    // 0xc70d60: LoadField: r1 = r0->field_b
    //     0xc70d60: ldur            w1, [x0, #0xb]
    // 0xc70d64: DecompressPointer r1
    //     0xc70d64: add             x1, x1, HEAP, lsl #32
    // 0xc70d68: LoadField: r2 = r1->field_f
    //     0xc70d68: ldur            w2, [x1, #0xf]
    // 0xc70d6c: DecompressPointer r2
    //     0xc70d6c: add             x2, x2, HEAP, lsl #32
    // 0xc70d70: stur            x2, [fp, #-0x20]
    // 0xc70d74: cmp             w2, NULL
    // 0xc70d78: b.eq            #0xc70e0c
    // 0xc70d7c: LoadField: r3 = r1->field_23
    //     0xc70d7c: ldur            w3, [x1, #0x23]
    // 0xc70d80: DecompressPointer r3
    //     0xc70d80: add             x3, x3, HEAP, lsl #32
    // 0xc70d84: stur            x3, [fp, #-0x18]
    // 0xc70d88: LoadField: r0 = r1->field_13
    //     0xc70d88: ldur            w0, [x1, #0x13]
    // 0xc70d8c: DecompressPointer r0
    //     0xc70d8c: add             x0, x0, HEAP, lsl #32
    // 0xc70d90: cmp             w0, NULL
    // 0xc70d94: b.ne            #0xc70da0
    // 0xc70d98: r0 = Null
    //     0xc70d98: mov             x0, NULL
    // 0xc70d9c: b               #0xc70ddc
    // 0xc70da0: r1 = LoadClassIdInstr(r0)
    //     0xc70da0: ldur            x1, [x0, #-1]
    //     0xc70da4: ubfx            x1, x1, #0xc, #0x14
    // 0xc70da8: lsl             x1, x1, #1
    // 0xc70dac: r17 = 4224
    //     0xc70dac: mov             x17, #0x1080
    // 0xc70db0: cmp             w1, w17
    // 0xc70db4: b.eq            #0xc70ddc
    // 0xc70db8: r1 = LoadClassIdInstr(r0)
    //     0xc70db8: ldur            x1, [x0, #-1]
    //     0xc70dbc: ubfx            x1, x1, #0xc, #0x14
    // 0xc70dc0: ldur            x16, [fp, #-8]
    // 0xc70dc4: stp             x16, x0, [SP, #-0x10]!
    // 0xc70dc8: mov             x0, x1
    // 0xc70dcc: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc70dcc: sub             lr, x0, #1, lsl #12
    //     0xc70dd0: ldr             lr, [x21, lr, lsl #3]
    //     0xc70dd4: blr             lr
    // 0xc70dd8: add             SP, SP, #0x10
    // 0xc70ddc: ldur            x16, [fp, #-0x20]
    // 0xc70de0: ldr             lr, [fp, #0x20]
    // 0xc70de4: stp             lr, x16, [SP, #-0x10]!
    // 0xc70de8: ldur            x16, [fp, #-0x10]
    // 0xc70dec: ldur            lr, [fp, #-0x18]
    // 0xc70df0: stp             lr, x16, [SP, #-0x10]!
    // 0xc70df4: ldur            x16, [fp, #-8]
    // 0xc70df8: stp             x16, x0, [SP, #-0x10]!
    // 0xc70dfc: r4 = const [0, 0x6, 0x6, 0x3, borderRadius, 0x4, shape, 0x3, textDirection, 0x5, null]
    //     0xc70dfc: add             x4, PP, #0x28, lsl #12  ; [pp+0x286e0] List(11) [0, 0x6, 0x6, 0x3, "borderRadius", 0x4, "shape", 0x3, "textDirection", 0x5, Null]
    //     0xc70e00: ldr             x4, [x4, #0x6e0]
    // 0xc70e04: r0 = paint()
    //     0xc70e04: bl              #0xbd2c60  ; [package:flutter/src/painting/box_border.dart] Border::paint
    // 0xc70e08: add             SP, SP, #0x30
    // 0xc70e0c: r0 = Null
    //     0xc70e0c: mov             x0, NULL
    // 0xc70e10: LeaveFrame
    //     0xc70e10: mov             SP, fp
    //     0xc70e14: ldp             fp, lr, [SP], #0x10
    // 0xc70e18: ret
    //     0xc70e18: ret             
    // 0xc70e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc70e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc70e20: b               #0xc70cc8
    // 0xc70e24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc70e24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintBackgroundImage(/* No info */) {
    // ** addr: 0xc70e28, size: 0x28c
    // 0xc70e28: EnterFrame
    //     0xc70e28: stp             fp, lr, [SP, #-0x10]!
    //     0xc70e2c: mov             fp, SP
    // 0xc70e30: AllocStack(0x20)
    //     0xc70e30: sub             SP, SP, #0x20
    // 0xc70e34: CheckStackOverflow
    //     0xc70e34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc70e38: cmp             SP, x16
    //     0xc70e3c: b.ls            #0xc71090
    // 0xc70e40: ldr             x0, [fp, #0x28]
    // 0xc70e44: LoadField: r1 = r0->field_b
    //     0xc70e44: ldur            w1, [x0, #0xb]
    // 0xc70e48: DecompressPointer r1
    //     0xc70e48: add             x1, x1, HEAP, lsl #32
    // 0xc70e4c: stur            x1, [fp, #-8]
    // 0xc70e50: LoadField: r2 = r1->field_b
    //     0xc70e50: ldur            w2, [x1, #0xb]
    // 0xc70e54: DecompressPointer r2
    //     0xc70e54: add             x2, x2, HEAP, lsl #32
    // 0xc70e58: cmp             w2, NULL
    // 0xc70e5c: b.ne            #0xc70e70
    // 0xc70e60: r0 = Null
    //     0xc70e60: mov             x0, NULL
    // 0xc70e64: LeaveFrame
    //     0xc70e64: mov             SP, fp
    //     0xc70e68: ldp             fp, lr, [SP], #0x10
    // 0xc70e6c: ret
    //     0xc70e6c: ret             
    // 0xc70e70: LoadField: r3 = r0->field_17
    //     0xc70e70: ldur            w3, [x0, #0x17]
    // 0xc70e74: DecompressPointer r3
    //     0xc70e74: add             x3, x3, HEAP, lsl #32
    // 0xc70e78: cmp             w3, NULL
    // 0xc70e7c: b.ne            #0xc70ec0
    // 0xc70e80: LoadField: r3 = r0->field_7
    //     0xc70e80: ldur            w3, [x0, #7]
    // 0xc70e84: DecompressPointer r3
    //     0xc70e84: add             x3, x3, HEAP, lsl #32
    // 0xc70e88: cmp             w3, NULL
    // 0xc70e8c: b.eq            #0xc71098
    // 0xc70e90: stp             x3, x2, [SP, #-0x10]!
    // 0xc70e94: r0 = createPainter()
    //     0xc70e94: bl              #0xc7151c  ; [package:flutter/src/painting/decoration_image.dart] DecorationImage::createPainter
    // 0xc70e98: add             SP, SP, #0x10
    // 0xc70e9c: ldr             x1, [fp, #0x28]
    // 0xc70ea0: StoreField: r1->field_17 = r0
    //     0xc70ea0: stur            w0, [x1, #0x17]
    //     0xc70ea4: ldurb           w16, [x1, #-1]
    //     0xc70ea8: ldurb           w17, [x0, #-1]
    //     0xc70eac: and             x16, x17, x16, lsr #2
    //     0xc70eb0: tst             x16, HEAP, lsr #32
    //     0xc70eb4: b.eq            #0xc70ebc
    //     0xc70eb8: bl              #0xd6826c
    // 0xc70ebc: b               #0xc70ec4
    // 0xc70ec0: mov             x1, x0
    // 0xc70ec4: ldur            x0, [fp, #-8]
    // 0xc70ec8: LoadField: r2 = r0->field_23
    //     0xc70ec8: ldur            w2, [x0, #0x23]
    // 0xc70ecc: DecompressPointer r2
    //     0xc70ecc: add             x2, x2, HEAP, lsl #32
    // 0xc70ed0: LoadField: r3 = r2->field_7
    //     0xc70ed0: ldur            x3, [x2, #7]
    // 0xc70ed4: cmp             x3, #0
    // 0xc70ed8: b.gt            #0xc70f94
    // 0xc70edc: LoadField: r2 = r0->field_13
    //     0xc70edc: ldur            w2, [x0, #0x13]
    // 0xc70ee0: DecompressPointer r2
    //     0xc70ee0: add             x2, x2, HEAP, lsl #32
    // 0xc70ee4: stur            x2, [fp, #-0x10]
    // 0xc70ee8: cmp             w2, NULL
    // 0xc70eec: b.eq            #0xc70f88
    // 0xc70ef0: ldr             x0, [fp, #0x10]
    // 0xc70ef4: r0 = Path()
    //     0xc70ef4: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xc70ef8: stur            x0, [fp, #-8]
    // 0xc70efc: SaveReg r0
    //     0xc70efc: str             x0, [SP, #-8]!
    // 0xc70f00: r0 = _constructor()
    //     0xc70f00: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xc70f04: add             SP, SP, #8
    // 0xc70f08: ldr             x1, [fp, #0x10]
    // 0xc70f0c: LoadField: r0 = r1->field_13
    //     0xc70f0c: ldur            w0, [x1, #0x13]
    // 0xc70f10: DecompressPointer r0
    //     0xc70f10: add             x0, x0, HEAP, lsl #32
    // 0xc70f14: ldur            x2, [fp, #-0x10]
    // 0xc70f18: r3 = LoadClassIdInstr(r2)
    //     0xc70f18: ldur            x3, [x2, #-1]
    //     0xc70f1c: ubfx            x3, x3, #0xc, #0x14
    // 0xc70f20: lsl             x3, x3, #1
    // 0xc70f24: r17 = 4224
    //     0xc70f24: mov             x17, #0x1080
    // 0xc70f28: cmp             w3, w17
    // 0xc70f2c: b.ne            #0xc70f38
    // 0xc70f30: mov             x0, x2
    // 0xc70f34: b               #0xc70f58
    // 0xc70f38: r3 = LoadClassIdInstr(r2)
    //     0xc70f38: ldur            x3, [x2, #-1]
    //     0xc70f3c: ubfx            x3, x3, #0xc, #0x14
    // 0xc70f40: stp             x0, x2, [SP, #-0x10]!
    // 0xc70f44: mov             x0, x3
    // 0xc70f48: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc70f48: sub             lr, x0, #1, lsl #12
    //     0xc70f4c: ldr             lr, [x21, lr, lsl #3]
    //     0xc70f50: blr             lr
    // 0xc70f54: add             SP, SP, #0x10
    // 0xc70f58: cmp             w0, NULL
    // 0xc70f5c: b.eq            #0xc7109c
    // 0xc70f60: ldr             x16, [fp, #0x18]
    // 0xc70f64: stp             x16, x0, [SP, #-0x10]!
    // 0xc70f68: r0 = toRRect()
    //     0xc70f68: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xc70f6c: add             SP, SP, #0x10
    // 0xc70f70: ldur            x16, [fp, #-8]
    // 0xc70f74: stp             x0, x16, [SP, #-0x10]!
    // 0xc70f78: r0 = addRRect()
    //     0xc70f78: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0xc70f7c: add             SP, SP, #0x10
    // 0xc70f80: ldur            x0, [fp, #-8]
    // 0xc70f84: b               #0xc70f8c
    // 0xc70f88: r0 = Null
    //     0xc70f88: mov             x0, NULL
    // 0xc70f8c: mov             x1, x0
    // 0xc70f90: b               #0xc7104c
    // 0xc70f94: ldr             x16, [fp, #0x18]
    // 0xc70f98: SaveReg r16
    //     0xc70f98: str             x16, [SP, #-8]!
    // 0xc70f9c: r0 = center()
    //     0xc70f9c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xc70fa0: add             SP, SP, #8
    // 0xc70fa4: stur            x0, [fp, #-8]
    // 0xc70fa8: ldr             x16, [fp, #0x18]
    // 0xc70fac: SaveReg r16
    //     0xc70fac: str             x16, [SP, #-8]!
    // 0xc70fb0: r0 = shortestSide()
    //     0xc70fb0: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0xc70fb4: add             SP, SP, #8
    // 0xc70fb8: mov             v1.16b, v0.16b
    // 0xc70fbc: d0 = 2.000000
    //     0xc70fbc: fmov            d0, #2.00000000
    // 0xc70fc0: fdiv            d2, d1, d0
    // 0xc70fc4: fmul            d1, d2, d0
    // 0xc70fc8: stur            d1, [fp, #-0x20]
    // 0xc70fcc: r0 = inline_Allocate_Double()
    //     0xc70fcc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc70fd0: add             x0, x0, #0x10
    //     0xc70fd4: cmp             x1, x0
    //     0xc70fd8: b.ls            #0xc710a0
    //     0xc70fdc: str             x0, [THR, #0x60]  ; THR::top
    //     0xc70fe0: sub             x0, x0, #0xf
    //     0xc70fe4: mov             x1, #0xd108
    //     0xc70fe8: movk            x1, #3, lsl #16
    //     0xc70fec: stur            x1, [x0, #-1]
    // 0xc70ff0: StoreField: r0->field_7 = d1
    //     0xc70ff0: stur            d1, [x0, #7]
    // 0xc70ff4: stur            x0, [fp, #-0x10]
    // 0xc70ff8: r0 = Rect()
    //     0xc70ff8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc70ffc: stur            x0, [fp, #-0x18]
    // 0xc71000: ldur            x16, [fp, #-8]
    // 0xc71004: stp             x16, x0, [SP, #-0x10]!
    // 0xc71008: ldur            x16, [fp, #-0x10]
    // 0xc7100c: SaveReg r16
    //     0xc7100c: str             x16, [SP, #-8]!
    // 0xc71010: ldur            d0, [fp, #-0x20]
    // 0xc71014: SaveReg d0
    //     0xc71014: str             d0, [SP, #-8]!
    // 0xc71018: r0 = Rect.fromCenter()
    //     0xc71018: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0xc7101c: add             SP, SP, #0x20
    // 0xc71020: r0 = Path()
    //     0xc71020: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xc71024: stur            x0, [fp, #-8]
    // 0xc71028: SaveReg r0
    //     0xc71028: str             x0, [SP, #-8]!
    // 0xc7102c: r0 = _constructor()
    //     0xc7102c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xc71030: add             SP, SP, #8
    // 0xc71034: ldur            x16, [fp, #-8]
    // 0xc71038: ldur            lr, [fp, #-0x18]
    // 0xc7103c: stp             lr, x16, [SP, #-0x10]!
    // 0xc71040: r0 = addOval()
    //     0xc71040: bl              #0x6633ac  ; [dart:ui] Path::addOval
    // 0xc71044: add             SP, SP, #0x10
    // 0xc71048: ldur            x1, [fp, #-8]
    // 0xc7104c: ldr             x0, [fp, #0x28]
    // 0xc71050: LoadField: r2 = r0->field_17
    //     0xc71050: ldur            w2, [x0, #0x17]
    // 0xc71054: DecompressPointer r2
    //     0xc71054: add             x2, x2, HEAP, lsl #32
    // 0xc71058: cmp             w2, NULL
    // 0xc7105c: b.eq            #0xc710b0
    // 0xc71060: ldr             x16, [fp, #0x20]
    // 0xc71064: stp             x16, x2, [SP, #-0x10]!
    // 0xc71068: ldr             x16, [fp, #0x18]
    // 0xc7106c: stp             x1, x16, [SP, #-0x10]!
    // 0xc71070: ldr             x16, [fp, #0x10]
    // 0xc71074: SaveReg r16
    //     0xc71074: str             x16, [SP, #-8]!
    // 0xc71078: r0 = paint()
    //     0xc71078: bl              #0xc710b4  ; [package:flutter/src/painting/decoration_image.dart] DecorationImagePainter::paint
    // 0xc7107c: add             SP, SP, #0x28
    // 0xc71080: r0 = Null
    //     0xc71080: mov             x0, NULL
    // 0xc71084: LeaveFrame
    //     0xc71084: mov             SP, fp
    //     0xc71088: ldp             fp, lr, [SP], #0x10
    // 0xc7108c: ret
    //     0xc7108c: ret             
    // 0xc71090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc71090: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc71094: b               #0xc70e40
    // 0xc71098: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc71098: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7109c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc7109c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xc710a0: SaveReg d1
    //     0xc710a0: str             q1, [SP, #-0x10]!
    // 0xc710a4: r0 = AllocateDouble()
    //     0xc710a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc710a8: RestoreReg d1
    //     0xc710a8: ldr             q1, [SP], #0x10
    // 0xc710ac: b               #0xc70ff0
    // 0xc710b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc710b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintBackgroundColor(/* No info */) {
    // ** addr: 0xc71550, size: 0x94
    // 0xc71550: EnterFrame
    //     0xc71550: stp             fp, lr, [SP, #-0x10]!
    //     0xc71554: mov             fp, SP
    // 0xc71558: CheckStackOverflow
    //     0xc71558: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7155c: cmp             SP, x16
    //     0xc71560: b.ls            #0xc715dc
    // 0xc71564: ldr             x0, [fp, #0x28]
    // 0xc71568: LoadField: r1 = r0->field_b
    //     0xc71568: ldur            w1, [x0, #0xb]
    // 0xc7156c: DecompressPointer r1
    //     0xc7156c: add             x1, x1, HEAP, lsl #32
    // 0xc71570: LoadField: r2 = r1->field_7
    //     0xc71570: ldur            w2, [x1, #7]
    // 0xc71574: DecompressPointer r2
    //     0xc71574: add             x2, x2, HEAP, lsl #32
    // 0xc71578: cmp             w2, NULL
    // 0xc7157c: b.ne            #0xc71590
    // 0xc71580: LoadField: r2 = r1->field_1b
    //     0xc71580: ldur            w2, [x1, #0x1b]
    // 0xc71584: DecompressPointer r2
    //     0xc71584: add             x2, x2, HEAP, lsl #32
    // 0xc71588: cmp             w2, NULL
    // 0xc7158c: b.eq            #0xc715cc
    // 0xc71590: ldr             x16, [fp, #0x18]
    // 0xc71594: stp             x16, x0, [SP, #-0x10]!
    // 0xc71598: ldr             x16, [fp, #0x10]
    // 0xc7159c: SaveReg r16
    //     0xc7159c: str             x16, [SP, #-8]!
    // 0xc715a0: r0 = _getBackgroundPaint()
    //     0xc715a0: bl              #0xc71758  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_getBackgroundPaint
    // 0xc715a4: add             SP, SP, #0x18
    // 0xc715a8: ldr             x16, [fp, #0x28]
    // 0xc715ac: ldr             lr, [fp, #0x20]
    // 0xc715b0: stp             lr, x16, [SP, #-0x10]!
    // 0xc715b4: ldr             x16, [fp, #0x18]
    // 0xc715b8: stp             x0, x16, [SP, #-0x10]!
    // 0xc715bc: ldr             x16, [fp, #0x10]
    // 0xc715c0: SaveReg r16
    //     0xc715c0: str             x16, [SP, #-8]!
    // 0xc715c4: r0 = _paintBox()
    //     0xc715c4: bl              #0xc715e4  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintBox
    // 0xc715c8: add             SP, SP, #0x28
    // 0xc715cc: r0 = Null
    //     0xc715cc: mov             x0, NULL
    // 0xc715d0: LeaveFrame
    //     0xc715d0: mov             SP, fp
    //     0xc715d4: ldp             fp, lr, [SP], #0x10
    // 0xc715d8: ret
    //     0xc715d8: ret             
    // 0xc715dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc715dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc715e0: b               #0xc71564
  }
  _ _paintBox(/* No info */) {
    // ** addr: 0xc715e4, size: 0x174
    // 0xc715e4: EnterFrame
    //     0xc715e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc715e8: mov             fp, SP
    // 0xc715ec: AllocStack(0x8)
    //     0xc715ec: sub             SP, SP, #8
    // 0xc715f0: CheckStackOverflow
    //     0xc715f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc715f4: cmp             SP, x16
    //     0xc715f8: b.ls            #0xc7174c
    // 0xc715fc: ldr             x0, [fp, #0x30]
    // 0xc71600: LoadField: r1 = r0->field_b
    //     0xc71600: ldur            w1, [x0, #0xb]
    // 0xc71604: DecompressPointer r1
    //     0xc71604: add             x1, x1, HEAP, lsl #32
    // 0xc71608: LoadField: r0 = r1->field_23
    //     0xc71608: ldur            w0, [x1, #0x23]
    // 0xc7160c: DecompressPointer r0
    //     0xc7160c: add             x0, x0, HEAP, lsl #32
    // 0xc71610: LoadField: r2 = r0->field_7
    //     0xc71610: ldur            x2, [x0, #7]
    // 0xc71614: cmp             x2, #0
    // 0xc71618: b.gt            #0xc716ec
    // 0xc7161c: LoadField: r2 = r1->field_13
    //     0xc7161c: ldur            w2, [x1, #0x13]
    // 0xc71620: DecompressPointer r2
    //     0xc71620: add             x2, x2, HEAP, lsl #32
    // 0xc71624: stur            x2, [fp, #-8]
    // 0xc71628: cmp             w2, NULL
    // 0xc7162c: b.eq            #0xc71658
    // 0xc71630: r0 = LoadClassIdInstr(r2)
    //     0xc71630: ldur            x0, [x2, #-1]
    //     0xc71634: ubfx            x0, x0, #0xc, #0x14
    // 0xc71638: r16 = Instance_BorderRadius
    //     0xc71638: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xc7163c: ldr             x16, [x16, #0x2c0]
    // 0xc71640: stp             x16, x2, [SP, #-0x10]!
    // 0xc71644: mov             lr, x0
    // 0xc71648: ldr             lr, [x21, lr, lsl #3]
    // 0xc7164c: blr             lr
    // 0xc71650: add             SP, SP, #0x10
    // 0xc71654: tbnz            w0, #4, #0xc71678
    // 0xc71658: ldr             x16, [fp, #0x28]
    // 0xc7165c: ldr             lr, [fp, #0x20]
    // 0xc71660: stp             lr, x16, [SP, #-0x10]!
    // 0xc71664: ldr             x16, [fp, #0x18]
    // 0xc71668: SaveReg r16
    //     0xc71668: str             x16, [SP, #-8]!
    // 0xc7166c: r0 = drawRect()
    //     0xc7166c: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xc71670: add             SP, SP, #0x18
    // 0xc71674: b               #0xc7173c
    // 0xc71678: ldur            x0, [fp, #-8]
    // 0xc7167c: r1 = LoadClassIdInstr(r0)
    //     0xc7167c: ldur            x1, [x0, #-1]
    //     0xc71680: ubfx            x1, x1, #0xc, #0x14
    // 0xc71684: lsl             x1, x1, #1
    // 0xc71688: r17 = 4224
    //     0xc71688: mov             x17, #0x1080
    // 0xc7168c: cmp             w1, w17
    // 0xc71690: b.eq            #0xc716b8
    // 0xc71694: r1 = LoadClassIdInstr(r0)
    //     0xc71694: ldur            x1, [x0, #-1]
    //     0xc71698: ubfx            x1, x1, #0xc, #0x14
    // 0xc7169c: ldr             x16, [fp, #0x10]
    // 0xc716a0: stp             x16, x0, [SP, #-0x10]!
    // 0xc716a4: mov             x0, x1
    // 0xc716a8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc716a8: sub             lr, x0, #1, lsl #12
    //     0xc716ac: ldr             lr, [x21, lr, lsl #3]
    //     0xc716b0: blr             lr
    // 0xc716b4: add             SP, SP, #0x10
    // 0xc716b8: cmp             w0, NULL
    // 0xc716bc: b.eq            #0xc71754
    // 0xc716c0: ldr             x16, [fp, #0x20]
    // 0xc716c4: stp             x16, x0, [SP, #-0x10]!
    // 0xc716c8: r0 = toRRect()
    //     0xc716c8: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xc716cc: add             SP, SP, #0x10
    // 0xc716d0: ldr             x16, [fp, #0x28]
    // 0xc716d4: stp             x0, x16, [SP, #-0x10]!
    // 0xc716d8: ldr             x16, [fp, #0x18]
    // 0xc716dc: SaveReg r16
    //     0xc716dc: str             x16, [SP, #-8]!
    // 0xc716e0: r0 = drawRRect()
    //     0xc716e0: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xc716e4: add             SP, SP, #0x18
    // 0xc716e8: b               #0xc7173c
    // 0xc716ec: ldr             x16, [fp, #0x20]
    // 0xc716f0: SaveReg r16
    //     0xc716f0: str             x16, [SP, #-8]!
    // 0xc716f4: r0 = center()
    //     0xc716f4: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xc716f8: add             SP, SP, #8
    // 0xc716fc: stur            x0, [fp, #-8]
    // 0xc71700: ldr             x16, [fp, #0x20]
    // 0xc71704: SaveReg r16
    //     0xc71704: str             x16, [SP, #-8]!
    // 0xc71708: r0 = shortestSide()
    //     0xc71708: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0xc7170c: add             SP, SP, #8
    // 0xc71710: mov             v1.16b, v0.16b
    // 0xc71714: d0 = 2.000000
    //     0xc71714: fmov            d0, #2.00000000
    // 0xc71718: fdiv            d2, d1, d0
    // 0xc7171c: ldr             x16, [fp, #0x28]
    // 0xc71720: ldur            lr, [fp, #-8]
    // 0xc71724: stp             lr, x16, [SP, #-0x10]!
    // 0xc71728: SaveReg d2
    //     0xc71728: str             d2, [SP, #-8]!
    // 0xc7172c: ldr             x16, [fp, #0x18]
    // 0xc71730: SaveReg r16
    //     0xc71730: str             x16, [SP, #-8]!
    // 0xc71734: r0 = drawCircle()
    //     0xc71734: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0xc71738: add             SP, SP, #0x20
    // 0xc7173c: r0 = Null
    //     0xc7173c: mov             x0, NULL
    // 0xc71740: LeaveFrame
    //     0xc71740: mov             SP, fp
    //     0xc71744: ldp             fp, lr, [SP], #0x10
    // 0xc71748: ret
    //     0xc71748: ret             
    // 0xc7174c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7174c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc71750: b               #0xc715fc
    // 0xc71754: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc71754: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _getBackgroundPaint(/* No info */) {
    // ** addr: 0xc71758, size: 0x220
    // 0xc71758: EnterFrame
    //     0xc71758: stp             fp, lr, [SP, #-0x10]!
    //     0xc7175c: mov             fp, SP
    // 0xc71760: AllocStack(0x10)
    //     0xc71760: sub             SP, SP, #0x10
    // 0xc71764: CheckStackOverflow
    //     0xc71764: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc71768: cmp             SP, x16
    //     0xc7176c: b.ls            #0xc7196c
    // 0xc71770: ldr             x1, [fp, #0x20]
    // 0xc71774: LoadField: r0 = r1->field_f
    //     0xc71774: ldur            w0, [x1, #0xf]
    // 0xc71778: DecompressPointer r0
    //     0xc71778: add             x0, x0, HEAP, lsl #32
    // 0xc7177c: cmp             w0, NULL
    // 0xc71780: b.ne            #0xc7178c
    // 0xc71784: mov             x0, x1
    // 0xc71788: b               #0xc717d8
    // 0xc7178c: LoadField: r0 = r1->field_b
    //     0xc7178c: ldur            w0, [x1, #0xb]
    // 0xc71790: DecompressPointer r0
    //     0xc71790: add             x0, x0, HEAP, lsl #32
    // 0xc71794: LoadField: r2 = r0->field_1b
    //     0xc71794: ldur            w2, [x0, #0x1b]
    // 0xc71798: DecompressPointer r2
    //     0xc71798: add             x2, x2, HEAP, lsl #32
    // 0xc7179c: cmp             w2, NULL
    // 0xc717a0: b.eq            #0xc71950
    // 0xc717a4: LoadField: r0 = r1->field_13
    //     0xc717a4: ldur            w0, [x1, #0x13]
    // 0xc717a8: DecompressPointer r0
    //     0xc717a8: add             x0, x0, HEAP, lsl #32
    // 0xc717ac: r2 = LoadClassIdInstr(r0)
    //     0xc717ac: ldur            x2, [x0, #-1]
    //     0xc717b0: ubfx            x2, x2, #0xc, #0x14
    // 0xc717b4: ldr             x16, [fp, #0x18]
    // 0xc717b8: stp             x16, x0, [SP, #-0x10]!
    // 0xc717bc: mov             x0, x2
    // 0xc717c0: mov             lr, x0
    // 0xc717c4: ldr             lr, [x21, lr, lsl #3]
    // 0xc717c8: blr             lr
    // 0xc717cc: add             SP, SP, #0x10
    // 0xc717d0: tbz             w0, #4, #0xc7194c
    // 0xc717d4: ldr             x0, [fp, #0x20]
    // 0xc717d8: r16 = 112
    //     0xc717d8: mov             x16, #0x70
    // 0xc717dc: stp             x16, NULL, [SP, #-0x10]!
    // 0xc717e0: r0 = ByteData()
    //     0xc717e0: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xc717e4: add             SP, SP, #0x10
    // 0xc717e8: stur            x0, [fp, #-8]
    // 0xc717ec: r0 = Paint()
    //     0xc717ec: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc717f0: mov             x1, x0
    // 0xc717f4: ldur            x0, [fp, #-8]
    // 0xc717f8: stur            x1, [fp, #-0x10]
    // 0xc717fc: StoreField: r1->field_7 = r0
    //     0xc717fc: stur            w0, [x1, #7]
    // 0xc71800: ldr             x2, [fp, #0x20]
    // 0xc71804: LoadField: r3 = r2->field_b
    //     0xc71804: ldur            w3, [x2, #0xb]
    // 0xc71808: DecompressPointer r3
    //     0xc71808: add             x3, x3, HEAP, lsl #32
    // 0xc7180c: LoadField: r4 = r3->field_7
    //     0xc7180c: ldur            w4, [x3, #7]
    // 0xc71810: DecompressPointer r4
    //     0xc71810: add             x4, x4, HEAP, lsl #32
    // 0xc71814: cmp             w4, NULL
    // 0xc71818: b.eq            #0xc71888
    // 0xc7181c: r5 = LoadClassIdInstr(r4)
    //     0xc7181c: ldur            x5, [x4, #-1]
    //     0xc71820: ubfx            x5, x5, #0xc, #0x14
    // 0xc71824: lsl             x5, x5, #1
    // 0xc71828: r17 = 10124
    //     0xc71828: mov             x17, #0x278c
    // 0xc7182c: cmp             w5, w17
    // 0xc71830: b.gt            #0xc71840
    // 0xc71834: r17 = 10122
    //     0xc71834: mov             x17, #0x278a
    // 0xc71838: cmp             w5, w17
    // 0xc7183c: b.ge            #0xc71858
    // 0xc71840: r17 = 10114
    //     0xc71840: mov             x17, #0x2782
    // 0xc71844: cmp             w5, w17
    // 0xc71848: b.eq            #0xc71858
    // 0xc7184c: r17 = 10118
    //     0xc7184c: mov             x17, #0x2786
    // 0xc71850: cmp             w5, w17
    // 0xc71854: b.ne            #0xc71864
    // 0xc71858: LoadField: r5 = r4->field_7
    //     0xc71858: ldur            x5, [x4, #7]
    // 0xc7185c: mov             x4, x5
    // 0xc71860: b               #0xc71870
    // 0xc71864: LoadField: r5 = r4->field_f
    //     0xc71864: ldur            w5, [x4, #0xf]
    // 0xc71868: DecompressPointer r5
    //     0xc71868: add             x5, x5, HEAP, lsl #32
    // 0xc7186c: LoadField: r4 = r5->field_7
    //     0xc7186c: ldur            x4, [x5, #7]
    // 0xc71870: eor             x5, x4, #0xff000000
    // 0xc71874: LoadField: r4 = r0->field_17
    //     0xc71874: ldur            w4, [x0, #0x17]
    // 0xc71878: DecompressPointer r4
    //     0xc71878: add             x4, x4, HEAP, lsl #32
    // 0xc7187c: sxtw            x5, w5
    // 0xc71880: LoadField: r0 = r4->field_7
    //     0xc71880: ldur            x0, [x4, #7]
    // 0xc71884: str             w5, [x0, #4]
    // 0xc71888: LoadField: r0 = r3->field_1b
    //     0xc71888: ldur            w0, [x3, #0x1b]
    // 0xc7188c: DecompressPointer r0
    //     0xc7188c: add             x0, x0, HEAP, lsl #32
    // 0xc71890: cmp             w0, NULL
    // 0xc71894: b.eq            #0xc71924
    // 0xc71898: ldr             x16, [fp, #0x18]
    // 0xc7189c: stp             x16, x0, [SP, #-0x10]!
    // 0xc718a0: ldr             x16, [fp, #0x10]
    // 0xc718a4: SaveReg r16
    //     0xc718a4: str             x16, [SP, #-8]!
    // 0xc718a8: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xc718a8: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xc718ac: ldr             x4, [x4, #0x5b8]
    // 0xc718b0: r0 = createShader()
    //     0xc718b0: bl              #0xc71978  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0xc718b4: add             SP, SP, #0x18
    // 0xc718b8: stur            x0, [fp, #-8]
    // 0xc718bc: ldur            x16, [fp, #-0x10]
    // 0xc718c0: SaveReg r16
    //     0xc718c0: str             x16, [SP, #-8]!
    // 0xc718c4: r0 = _ensureObjectsInitialized()
    //     0xc718c4: bl              #0x65ebd8  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0xc718c8: add             SP, SP, #8
    // 0xc718cc: r1 = LoadClassIdInstr(r0)
    //     0xc718cc: ldur            x1, [x0, #-1]
    //     0xc718d0: ubfx            x1, x1, #0xc, #0x14
    // 0xc718d4: stp             xzr, x0, [SP, #-0x10]!
    // 0xc718d8: ldur            x16, [fp, #-8]
    // 0xc718dc: SaveReg r16
    //     0xc718dc: str             x16, [SP, #-8]!
    // 0xc718e0: mov             x0, x1
    // 0xc718e4: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xc718e4: mov             x17, #0x15e
    //     0xc718e8: movk            x17, #1, lsl #16
    //     0xc718ec: add             lr, x0, x17
    //     0xc718f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc718f4: blr             lr
    // 0xc718f8: add             SP, SP, #0x18
    // 0xc718fc: ldr             x0, [fp, #0x18]
    // 0xc71900: ldr             x1, [fp, #0x20]
    // 0xc71904: StoreField: r1->field_13 = r0
    //     0xc71904: stur            w0, [x1, #0x13]
    //     0xc71908: ldurb           w16, [x1, #-1]
    //     0xc7190c: ldurb           w17, [x0, #-1]
    //     0xc71910: and             x16, x17, x16, lsr #2
    //     0xc71914: tst             x16, HEAP, lsr #32
    //     0xc71918: b.eq            #0xc71920
    //     0xc7191c: bl              #0xd6826c
    // 0xc71920: b               #0xc71928
    // 0xc71924: mov             x1, x2
    // 0xc71928: ldur            x0, [fp, #-0x10]
    // 0xc7192c: StoreField: r1->field_f = r0
    //     0xc7192c: stur            w0, [x1, #0xf]
    //     0xc71930: ldurb           w16, [x1, #-1]
    //     0xc71934: ldurb           w17, [x0, #-1]
    //     0xc71938: and             x16, x17, x16, lsr #2
    //     0xc7193c: tst             x16, HEAP, lsr #32
    //     0xc71940: b.eq            #0xc71948
    //     0xc71944: bl              #0xd6826c
    // 0xc71948: b               #0xc71950
    // 0xc7194c: ldr             x1, [fp, #0x20]
    // 0xc71950: LoadField: r0 = r1->field_f
    //     0xc71950: ldur            w0, [x1, #0xf]
    // 0xc71954: DecompressPointer r0
    //     0xc71954: add             x0, x0, HEAP, lsl #32
    // 0xc71958: cmp             w0, NULL
    // 0xc7195c: b.eq            #0xc71974
    // 0xc71960: LeaveFrame
    //     0xc71960: mov             SP, fp
    //     0xc71964: ldp             fp, lr, [SP], #0x10
    // 0xc71968: ret
    //     0xc71968: ret             
    // 0xc7196c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7196c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc71970: b               #0xc71770
    // 0xc71974: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc71974: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintShadows(/* No info */) {
    // ** addr: 0xc71d18, size: 0x250
    // 0xc71d18: EnterFrame
    //     0xc71d18: stp             fp, lr, [SP, #-0x10]!
    //     0xc71d1c: mov             fp, SP
    // 0xc71d20: AllocStack(0x68)
    //     0xc71d20: sub             SP, SP, #0x68
    // 0xc71d24: CheckStackOverflow
    //     0xc71d24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc71d28: cmp             SP, x16
    //     0xc71d2c: b.ls            #0xc71f58
    // 0xc71d30: ldr             x1, [fp, #0x28]
    // 0xc71d34: LoadField: r0 = r1->field_b
    //     0xc71d34: ldur            w0, [x1, #0xb]
    // 0xc71d38: DecompressPointer r0
    //     0xc71d38: add             x0, x0, HEAP, lsl #32
    // 0xc71d3c: LoadField: r2 = r0->field_17
    //     0xc71d3c: ldur            w2, [x0, #0x17]
    // 0xc71d40: DecompressPointer r2
    //     0xc71d40: add             x2, x2, HEAP, lsl #32
    // 0xc71d44: cmp             w2, NULL
    // 0xc71d48: b.ne            #0xc71d5c
    // 0xc71d4c: r0 = Null
    //     0xc71d4c: mov             x0, NULL
    // 0xc71d50: LeaveFrame
    //     0xc71d50: mov             SP, fp
    //     0xc71d54: ldp             fp, lr, [SP], #0x10
    // 0xc71d58: ret
    //     0xc71d58: ret             
    // 0xc71d5c: ldr             x3, [fp, #0x18]
    // 0xc71d60: r0 = LoadClassIdInstr(r2)
    //     0xc71d60: ldur            x0, [x2, #-1]
    //     0xc71d64: ubfx            x0, x0, #0xc, #0x14
    // 0xc71d68: SaveReg r2
    //     0xc71d68: str             x2, [SP, #-8]!
    // 0xc71d6c: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc71d6c: mov             x17, #0xb940
    //     0xc71d70: add             lr, x0, x17
    //     0xc71d74: ldr             lr, [x21, lr, lsl #3]
    //     0xc71d78: blr             lr
    // 0xc71d7c: add             SP, SP, #8
    // 0xc71d80: mov             x1, x0
    // 0xc71d84: ldr             x0, [fp, #0x18]
    // 0xc71d88: stur            x1, [fp, #-8]
    // 0xc71d8c: LoadField: d0 = r0->field_7
    //     0xc71d8c: ldur            d0, [x0, #7]
    // 0xc71d90: stur            d0, [fp, #-0x48]
    // 0xc71d94: LoadField: d1 = r0->field_f
    //     0xc71d94: ldur            d1, [x0, #0xf]
    // 0xc71d98: stur            d1, [fp, #-0x40]
    // 0xc71d9c: LoadField: d2 = r0->field_17
    //     0xc71d9c: ldur            d2, [x0, #0x17]
    // 0xc71da0: stur            d2, [fp, #-0x38]
    // 0xc71da4: LoadField: d3 = r0->field_1f
    //     0xc71da4: ldur            d3, [x0, #0x1f]
    // 0xc71da8: stur            d3, [fp, #-0x30]
    // 0xc71dac: CheckStackOverflow
    //     0xc71dac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc71db0: cmp             SP, x16
    //     0xc71db4: b.ls            #0xc71f60
    // 0xc71db8: r0 = LoadClassIdInstr(r1)
    //     0xc71db8: ldur            x0, [x1, #-1]
    //     0xc71dbc: ubfx            x0, x0, #0xc, #0x14
    // 0xc71dc0: SaveReg r1
    //     0xc71dc0: str             x1, [SP, #-8]!
    // 0xc71dc4: r0 = GDT[cid_x0 + 0x541]()
    //     0xc71dc4: add             lr, x0, #0x541
    //     0xc71dc8: ldr             lr, [x21, lr, lsl #3]
    //     0xc71dcc: blr             lr
    // 0xc71dd0: add             SP, SP, #8
    // 0xc71dd4: tbnz            w0, #4, #0xc71f48
    // 0xc71dd8: ldur            x1, [fp, #-8]
    // 0xc71ddc: ldur            d0, [fp, #-0x48]
    // 0xc71de0: ldur            d1, [fp, #-0x40]
    // 0xc71de4: ldur            d2, [fp, #-0x38]
    // 0xc71de8: ldur            d3, [fp, #-0x30]
    // 0xc71dec: r0 = LoadClassIdInstr(r1)
    //     0xc71dec: ldur            x0, [x1, #-1]
    //     0xc71df0: ubfx            x0, x0, #0xc, #0x14
    // 0xc71df4: SaveReg r1
    //     0xc71df4: str             x1, [SP, #-8]!
    // 0xc71df8: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc71df8: add             lr, x0, #0x5ca
    //     0xc71dfc: ldr             lr, [x21, lr, lsl #3]
    //     0xc71e00: blr             lr
    // 0xc71e04: add             SP, SP, #8
    // 0xc71e08: stur            x0, [fp, #-0x10]
    // 0xc71e0c: r16 = 112
    //     0xc71e0c: mov             x16, #0x70
    // 0xc71e10: stp             x16, NULL, [SP, #-0x10]!
    // 0xc71e14: r0 = ByteData()
    //     0xc71e14: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xc71e18: add             SP, SP, #0x10
    // 0xc71e1c: stur            x0, [fp, #-0x18]
    // 0xc71e20: r0 = Paint()
    //     0xc71e20: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc71e24: mov             x1, x0
    // 0xc71e28: ldur            x0, [fp, #-0x18]
    // 0xc71e2c: stur            x1, [fp, #-0x28]
    // 0xc71e30: StoreField: r1->field_7 = r0
    //     0xc71e30: stur            w0, [x1, #7]
    // 0xc71e34: ldur            x2, [fp, #-0x10]
    // 0xc71e38: LoadField: r3 = r2->field_7
    //     0xc71e38: ldur            w3, [x2, #7]
    // 0xc71e3c: DecompressPointer r3
    //     0xc71e3c: add             x3, x3, HEAP, lsl #32
    // 0xc71e40: LoadField: r4 = r3->field_7
    //     0xc71e40: ldur            x4, [x3, #7]
    // 0xc71e44: eor             x3, x4, #0xff000000
    // 0xc71e48: LoadField: r4 = r0->field_17
    //     0xc71e48: ldur            w4, [x0, #0x17]
    // 0xc71e4c: DecompressPointer r4
    //     0xc71e4c: add             x4, x4, HEAP, lsl #32
    // 0xc71e50: stur            x4, [fp, #-0x20]
    // 0xc71e54: sxtw            x3, w3
    // 0xc71e58: LoadField: r0 = r4->field_7
    //     0xc71e58: ldur            x0, [x4, #7]
    // 0xc71e5c: str             w3, [x0, #4]
    // 0xc71e60: SaveReg r2
    //     0xc71e60: str             x2, [SP, #-8]!
    // 0xc71e64: r0 = blurSigma()
    //     0xc71e64: bl              #0xc71f68  ; [dart:ui] Shadow::blurSigma
    // 0xc71e68: add             SP, SP, #8
    // 0xc71e6c: ldur            x0, [fp, #-0x20]
    // 0xc71e70: LoadField: r1 = r0->field_7
    //     0xc71e70: ldur            x1, [x0, #7]
    // 0xc71e74: r2 = 1
    //     0xc71e74: mov             x2, #1
    // 0xc71e78: str             w2, [x1, #0x24]
    // 0xc71e7c: LoadField: r1 = r0->field_7
    //     0xc71e7c: ldur            x1, [x0, #7]
    // 0xc71e80: str             wzr, [x1, #0x28]
    // 0xc71e84: fcvt            s1, d0
    // 0xc71e88: LoadField: r1 = r0->field_7
    //     0xc71e88: ldur            x1, [x0, #7]
    // 0xc71e8c: str             s1, [x1, #0x2c]
    // 0xc71e90: ldur            x0, [fp, #-0x10]
    // 0xc71e94: LoadField: r1 = r0->field_b
    //     0xc71e94: ldur            w1, [x0, #0xb]
    // 0xc71e98: DecompressPointer r1
    //     0xc71e98: add             x1, x1, HEAP, lsl #32
    // 0xc71e9c: LoadField: d0 = r1->field_7
    //     0xc71e9c: ldur            d0, [x1, #7]
    // 0xc71ea0: ldur            d1, [fp, #-0x48]
    // 0xc71ea4: fadd            d2, d1, d0
    // 0xc71ea8: LoadField: d3 = r1->field_f
    //     0xc71ea8: ldur            d3, [x1, #0xf]
    // 0xc71eac: ldur            d4, [fp, #-0x40]
    // 0xc71eb0: fadd            d5, d4, d3
    // 0xc71eb4: ldur            d6, [fp, #-0x38]
    // 0xc71eb8: fadd            d7, d6, d0
    // 0xc71ebc: ldur            d0, [fp, #-0x30]
    // 0xc71ec0: fadd            d8, d0, d3
    // 0xc71ec4: LoadField: d3 = r0->field_17
    //     0xc71ec4: ldur            d3, [x0, #0x17]
    // 0xc71ec8: fsub            d9, d2, d3
    // 0xc71ecc: stur            d9, [fp, #-0x68]
    // 0xc71ed0: fsub            d2, d5, d3
    // 0xc71ed4: stur            d2, [fp, #-0x60]
    // 0xc71ed8: fadd            d5, d7, d3
    // 0xc71edc: stur            d5, [fp, #-0x58]
    // 0xc71ee0: fadd            d7, d8, d3
    // 0xc71ee4: stur            d7, [fp, #-0x50]
    // 0xc71ee8: r0 = Rect()
    //     0xc71ee8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc71eec: ldur            d0, [fp, #-0x68]
    // 0xc71ef0: StoreField: r0->field_7 = d0
    //     0xc71ef0: stur            d0, [x0, #7]
    // 0xc71ef4: ldur            d0, [fp, #-0x60]
    // 0xc71ef8: StoreField: r0->field_f = d0
    //     0xc71ef8: stur            d0, [x0, #0xf]
    // 0xc71efc: ldur            d0, [fp, #-0x58]
    // 0xc71f00: StoreField: r0->field_17 = d0
    //     0xc71f00: stur            d0, [x0, #0x17]
    // 0xc71f04: ldur            d0, [fp, #-0x50]
    // 0xc71f08: StoreField: r0->field_1f = d0
    //     0xc71f08: stur            d0, [x0, #0x1f]
    // 0xc71f0c: ldr             x16, [fp, #0x28]
    // 0xc71f10: ldr             lr, [fp, #0x20]
    // 0xc71f14: stp             lr, x16, [SP, #-0x10]!
    // 0xc71f18: ldur            x16, [fp, #-0x28]
    // 0xc71f1c: stp             x16, x0, [SP, #-0x10]!
    // 0xc71f20: ldr             x16, [fp, #0x10]
    // 0xc71f24: SaveReg r16
    //     0xc71f24: str             x16, [SP, #-8]!
    // 0xc71f28: r0 = _paintBox()
    //     0xc71f28: bl              #0xc715e4  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::_paintBox
    // 0xc71f2c: add             SP, SP, #0x28
    // 0xc71f30: ldur            x1, [fp, #-8]
    // 0xc71f34: ldur            d0, [fp, #-0x48]
    // 0xc71f38: ldur            d1, [fp, #-0x40]
    // 0xc71f3c: ldur            d2, [fp, #-0x38]
    // 0xc71f40: ldur            d3, [fp, #-0x30]
    // 0xc71f44: b               #0xc71dac
    // 0xc71f48: r0 = Null
    //     0xc71f48: mov             x0, NULL
    // 0xc71f4c: LeaveFrame
    //     0xc71f4c: mov             SP, fp
    //     0xc71f50: ldp             fp, lr, [SP], #0x10
    // 0xc71f54: ret
    //     0xc71f54: ret             
    // 0xc71f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc71f58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc71f5c: b               #0xc71d30
    // 0xc71f60: r0 = StackOverflowSharedWithFPURegs()
    //     0xc71f60: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc71f64: b               #0xc71db8
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc75720, size: 0x4c
    // 0xc75720: EnterFrame
    //     0xc75720: stp             fp, lr, [SP, #-0x10]!
    //     0xc75724: mov             fp, SP
    // 0xc75728: CheckStackOverflow
    //     0xc75728: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7572c: cmp             SP, x16
    //     0xc75730: b.ls            #0xc75764
    // 0xc75734: ldr             x0, [fp, #0x10]
    // 0xc75738: LoadField: r1 = r0->field_17
    //     0xc75738: ldur            w1, [x0, #0x17]
    // 0xc7573c: DecompressPointer r1
    //     0xc7573c: add             x1, x1, HEAP, lsl #32
    // 0xc75740: cmp             w1, NULL
    // 0xc75744: b.eq            #0xc75754
    // 0xc75748: SaveReg r1
    //     0xc75748: str             x1, [SP, #-8]!
    // 0xc7574c: r0 = dispose()
    //     0xc7574c: bl              #0xc7576c  ; [package:flutter/src/painting/decoration_image.dart] DecorationImagePainter::dispose
    // 0xc75750: add             SP, SP, #8
    // 0xc75754: r0 = Null
    //     0xc75754: mov             x0, NULL
    // 0xc75758: LeaveFrame
    //     0xc75758: mov             SP, fp
    //     0xc7575c: ldp             fp, lr, [SP], #0x10
    // 0xc75760: ret
    //     0xc75760: ret             
    // 0xc75764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc75764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc75768: b               #0xc75734
  }
}

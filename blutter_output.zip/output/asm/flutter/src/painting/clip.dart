// lib: , url: package:flutter/src/painting/clip.dart

// class id: 1049355, size: 0x8
class :: {
}

// class id: 2107, size: 0x8, field offset: 0x8
abstract class ClipContext extends Object {

  _ clipRectAndPaint(/* No info */) {
    // ** addr: 0x65b3dc, size: 0x7c
    // 0x65b3dc: EnterFrame
    //     0x65b3dc: stp             fp, lr, [SP, #-0x10]!
    //     0x65b3e0: mov             fp, SP
    // 0x65b3e4: CheckStackOverflow
    //     0x65b3e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65b3e8: cmp             SP, x16
    //     0x65b3ec: b.ls            #0x65b450
    // 0x65b3f0: r1 = 2
    //     0x65b3f0: mov             x1, #2
    // 0x65b3f4: r0 = AllocateContext()
    //     0x65b3f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x65b3f8: mov             x1, x0
    // 0x65b3fc: ldr             x0, [fp, #0x30]
    // 0x65b400: StoreField: r1->field_f = r0
    //     0x65b400: stur            w0, [x1, #0xf]
    // 0x65b404: ldr             x2, [fp, #0x28]
    // 0x65b408: StoreField: r1->field_13 = r2
    //     0x65b408: stur            w2, [x1, #0x13]
    // 0x65b40c: mov             x2, x1
    // 0x65b410: r1 = Function '<anonymous closure>':.
    //     0x65b410: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d1f8] AnonymousClosure: (0x65bb4c), in [package:flutter/src/painting/clip.dart] ClipContext::clipRectAndPaint (0x65b3dc)
    //     0x65b414: ldr             x1, [x1, #0x1f8]
    // 0x65b418: r0 = AllocateClosure()
    //     0x65b418: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x65b41c: ldr             x16, [fp, #0x30]
    // 0x65b420: stp             x0, x16, [SP, #-0x10]!
    // 0x65b424: ldr             x16, [fp, #0x20]
    // 0x65b428: ldr             lr, [fp, #0x18]
    // 0x65b42c: stp             lr, x16, [SP, #-0x10]!
    // 0x65b430: ldr             x16, [fp, #0x10]
    // 0x65b434: SaveReg r16
    //     0x65b434: str             x16, [SP, #-8]!
    // 0x65b438: r0 = _clipAndPaint()
    //     0x65b438: bl              #0x65b458  ; [package:flutter/src/painting/clip.dart] ClipContext::_clipAndPaint
    // 0x65b43c: add             SP, SP, #0x28
    // 0x65b440: r0 = Null
    //     0x65b440: mov             x0, NULL
    // 0x65b444: LeaveFrame
    //     0x65b444: mov             SP, fp
    //     0x65b448: ldp             fp, lr, [SP], #0x10
    // 0x65b44c: ret
    //     0x65b44c: ret             
    // 0x65b450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65b450: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65b454: b               #0x65b3f0
  }
  _ _clipAndPaint(/* No info */) {
    // ** addr: 0x65b458, size: 0x198
    // 0x65b458: EnterFrame
    //     0x65b458: stp             fp, lr, [SP, #-0x10]!
    //     0x65b45c: mov             fp, SP
    // 0x65b460: AllocStack(0x10)
    //     0x65b460: sub             SP, SP, #0x10
    // 0x65b464: CheckStackOverflow
    //     0x65b464: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65b468: cmp             SP, x16
    //     0x65b46c: b.ls            #0x65b5e8
    // 0x65b470: ldr             x16, [fp, #0x30]
    // 0x65b474: SaveReg r16
    //     0x65b474: str             x16, [SP, #-8]!
    // 0x65b478: r0 = canvas()
    //     0x65b478: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65b47c: add             SP, SP, #8
    // 0x65b480: SaveReg r0
    //     0x65b480: str             x0, [SP, #-8]!
    // 0x65b484: r0 = save()
    //     0x65b484: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x65b488: add             SP, SP, #8
    // 0x65b48c: ldr             x1, [fp, #0x20]
    // 0x65b490: LoadField: r0 = r1->field_7
    //     0x65b490: ldur            x0, [x1, #7]
    // 0x65b494: cmp             x0, #1
    // 0x65b498: b.gt            #0x65b4cc
    // 0x65b49c: cmp             x0, #0
    // 0x65b4a0: b.le            #0x65b570
    // 0x65b4a4: ldr             x16, [fp, #0x28]
    // 0x65b4a8: r30 = false
    //     0x65b4a8: add             lr, NULL, #0x30  ; false
    // 0x65b4ac: stp             lr, x16, [SP, #-0x10]!
    // 0x65b4b0: ldr             x0, [fp, #0x28]
    // 0x65b4b4: ClosureCall
    //     0x65b4b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x65b4b8: ldur            x2, [x0, #0x1f]
    //     0x65b4bc: blr             x2
    // 0x65b4c0: add             SP, SP, #0x10
    // 0x65b4c4: ldr             x1, [fp, #0x20]
    // 0x65b4c8: b               #0x65b570
    // 0x65b4cc: cmp             x0, #2
    // 0x65b4d0: b.gt            #0x65b4fc
    // 0x65b4d4: ldr             x16, [fp, #0x28]
    // 0x65b4d8: r30 = true
    //     0x65b4d8: add             lr, NULL, #0x20  ; true
    // 0x65b4dc: stp             lr, x16, [SP, #-0x10]!
    // 0x65b4e0: ldr             x0, [fp, #0x28]
    // 0x65b4e4: ClosureCall
    //     0x65b4e4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x65b4e8: ldur            x2, [x0, #0x1f]
    //     0x65b4ec: blr             x2
    // 0x65b4f0: add             SP, SP, #0x10
    // 0x65b4f4: ldr             x1, [fp, #0x20]
    // 0x65b4f8: b               #0x65b570
    // 0x65b4fc: ldr             x16, [fp, #0x28]
    // 0x65b500: r30 = true
    //     0x65b500: add             lr, NULL, #0x20  ; true
    // 0x65b504: stp             lr, x16, [SP, #-0x10]!
    // 0x65b508: ldr             x0, [fp, #0x28]
    // 0x65b50c: ClosureCall
    //     0x65b50c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x65b510: ldur            x2, [x0, #0x1f]
    //     0x65b514: blr             x2
    // 0x65b518: add             SP, SP, #0x10
    // 0x65b51c: ldr             x16, [fp, #0x30]
    // 0x65b520: SaveReg r16
    //     0x65b520: str             x16, [SP, #-8]!
    // 0x65b524: r0 = canvas()
    //     0x65b524: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65b528: add             SP, SP, #8
    // 0x65b52c: stur            x0, [fp, #-8]
    // 0x65b530: r16 = 112
    //     0x65b530: mov             x16, #0x70
    // 0x65b534: stp             x16, NULL, [SP, #-0x10]!
    // 0x65b538: r0 = ByteData()
    //     0x65b538: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65b53c: add             SP, SP, #0x10
    // 0x65b540: stur            x0, [fp, #-0x10]
    // 0x65b544: r0 = Paint()
    //     0x65b544: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65b548: mov             x1, x0
    // 0x65b54c: ldur            x0, [fp, #-0x10]
    // 0x65b550: StoreField: r1->field_7 = r0
    //     0x65b550: stur            w0, [x1, #7]
    // 0x65b554: ldur            x16, [fp, #-8]
    // 0x65b558: ldr             lr, [fp, #0x18]
    // 0x65b55c: stp             lr, x16, [SP, #-0x10]!
    // 0x65b560: SaveReg r1
    //     0x65b560: str             x1, [SP, #-8]!
    // 0x65b564: r0 = saveLayer()
    //     0x65b564: bl              #0x65b5f0  ; [dart:ui] Canvas::saveLayer
    // 0x65b568: add             SP, SP, #0x18
    // 0x65b56c: ldr             x1, [fp, #0x20]
    // 0x65b570: ldr             x16, [fp, #0x10]
    // 0x65b574: SaveReg r16
    //     0x65b574: str             x16, [SP, #-8]!
    // 0x65b578: ldr             x0, [fp, #0x10]
    // 0x65b57c: ClosureCall
    //     0x65b57c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x65b580: ldur            x2, [x0, #0x1f]
    //     0x65b584: blr             x2
    // 0x65b588: add             SP, SP, #8
    // 0x65b58c: ldr             x0, [fp, #0x20]
    // 0x65b590: r16 = Instance_Clip
    //     0x65b590: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d228] Obj!Clip@b67671
    //     0x65b594: ldr             x16, [x16, #0x228]
    // 0x65b598: cmp             w0, w16
    // 0x65b59c: b.ne            #0x65b5bc
    // 0x65b5a0: ldr             x16, [fp, #0x30]
    // 0x65b5a4: SaveReg r16
    //     0x65b5a4: str             x16, [SP, #-8]!
    // 0x65b5a8: r0 = canvas()
    //     0x65b5a8: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65b5ac: add             SP, SP, #8
    // 0x65b5b0: SaveReg r0
    //     0x65b5b0: str             x0, [SP, #-8]!
    // 0x65b5b4: r0 = restore()
    //     0x65b5b4: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x65b5b8: add             SP, SP, #8
    // 0x65b5bc: ldr             x16, [fp, #0x30]
    // 0x65b5c0: SaveReg r16
    //     0x65b5c0: str             x16, [SP, #-8]!
    // 0x65b5c4: r0 = canvas()
    //     0x65b5c4: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65b5c8: add             SP, SP, #8
    // 0x65b5cc: SaveReg r0
    //     0x65b5cc: str             x0, [SP, #-8]!
    // 0x65b5d0: r0 = restore()
    //     0x65b5d0: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x65b5d4: add             SP, SP, #8
    // 0x65b5d8: r0 = Null
    //     0x65b5d8: mov             x0, NULL
    // 0x65b5dc: LeaveFrame
    //     0x65b5dc: mov             SP, fp
    //     0x65b5e0: ldp             fp, lr, [SP], #0x10
    // 0x65b5e4: ret
    //     0x65b5e4: ret             
    // 0x65b5e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65b5e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65b5ec: b               #0x65b470
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x65bb4c, size: 0x7c
    // 0x65bb4c: EnterFrame
    //     0x65bb4c: stp             fp, lr, [SP, #-0x10]!
    //     0x65bb50: mov             fp, SP
    // 0x65bb54: AllocStack(0x8)
    //     0x65bb54: sub             SP, SP, #8
    // 0x65bb58: SetupParameters()
    //     0x65bb58: ldr             x0, [fp, #0x18]
    //     0x65bb5c: ldur            w1, [x0, #0x17]
    //     0x65bb60: add             x1, x1, HEAP, lsl #32
    //     0x65bb64: stur            x1, [fp, #-8]
    // 0x65bb68: CheckStackOverflow
    //     0x65bb68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65bb6c: cmp             SP, x16
    //     0x65bb70: b.ls            #0x65bbc0
    // 0x65bb74: LoadField: r0 = r1->field_f
    //     0x65bb74: ldur            w0, [x1, #0xf]
    // 0x65bb78: DecompressPointer r0
    //     0x65bb78: add             x0, x0, HEAP, lsl #32
    // 0x65bb7c: SaveReg r0
    //     0x65bb7c: str             x0, [SP, #-8]!
    // 0x65bb80: r0 = canvas()
    //     0x65bb80: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65bb84: add             SP, SP, #8
    // 0x65bb88: mov             x1, x0
    // 0x65bb8c: ldur            x0, [fp, #-8]
    // 0x65bb90: LoadField: r2 = r0->field_13
    //     0x65bb90: ldur            w2, [x0, #0x13]
    // 0x65bb94: DecompressPointer r2
    //     0x65bb94: add             x2, x2, HEAP, lsl #32
    // 0x65bb98: stp             x2, x1, [SP, #-0x10]!
    // 0x65bb9c: ldr             x16, [fp, #0x10]
    // 0x65bba0: SaveReg r16
    //     0x65bba0: str             x16, [SP, #-8]!
    // 0x65bba4: r4 = const [0, 0x3, 0x3, 0x2, doAntiAlias, 0x2, null]
    //     0x65bba4: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d200] List(7) [0, 0x3, 0x3, 0x2, "doAntiAlias", 0x2, Null]
    //     0x65bba8: ldr             x4, [x4, #0x200]
    // 0x65bbac: r0 = clipRect()
    //     0x65bbac: bl              #0x6590f4  ; [dart:ui] Canvas::clipRect
    // 0x65bbb0: add             SP, SP, #0x18
    // 0x65bbb4: LeaveFrame
    //     0x65bbb4: mov             SP, fp
    //     0x65bbb8: ldp             fp, lr, [SP], #0x10
    // 0x65bbbc: ret
    //     0x65bbbc: ret             
    // 0x65bbc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65bbc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65bbc4: b               #0x65bb74
  }
  _ clipRRectAndPaint(/* No info */) {
    // ** addr: 0x661f48, size: 0x7c
    // 0x661f48: EnterFrame
    //     0x661f48: stp             fp, lr, [SP, #-0x10]!
    //     0x661f4c: mov             fp, SP
    // 0x661f50: CheckStackOverflow
    //     0x661f50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661f54: cmp             SP, x16
    //     0x661f58: b.ls            #0x661fbc
    // 0x661f5c: r1 = 2
    //     0x661f5c: mov             x1, #2
    // 0x661f60: r0 = AllocateContext()
    //     0x661f60: bl              #0xd68aa4  ; AllocateContextStub
    // 0x661f64: mov             x1, x0
    // 0x661f68: ldr             x0, [fp, #0x30]
    // 0x661f6c: StoreField: r1->field_f = r0
    //     0x661f6c: stur            w0, [x1, #0xf]
    // 0x661f70: ldr             x2, [fp, #0x28]
    // 0x661f74: StoreField: r1->field_13 = r2
    //     0x661f74: stur            w2, [x1, #0x13]
    // 0x661f78: mov             x2, x1
    // 0x661f7c: r1 = Function '<anonymous closure>':.
    //     0x661f7c: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d6b0] AnonymousClosure: (0x661fc4), in [package:flutter/src/painting/clip.dart] ClipContext::clipRRectAndPaint (0x661f48)
    //     0x661f80: ldr             x1, [x1, #0x6b0]
    // 0x661f84: r0 = AllocateClosure()
    //     0x661f84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x661f88: ldr             x16, [fp, #0x30]
    // 0x661f8c: stp             x0, x16, [SP, #-0x10]!
    // 0x661f90: ldr             x16, [fp, #0x20]
    // 0x661f94: ldr             lr, [fp, #0x18]
    // 0x661f98: stp             lr, x16, [SP, #-0x10]!
    // 0x661f9c: ldr             x16, [fp, #0x10]
    // 0x661fa0: SaveReg r16
    //     0x661fa0: str             x16, [SP, #-8]!
    // 0x661fa4: r0 = _clipAndPaint()
    //     0x661fa4: bl              #0x65b458  ; [package:flutter/src/painting/clip.dart] ClipContext::_clipAndPaint
    // 0x661fa8: add             SP, SP, #0x28
    // 0x661fac: r0 = Null
    //     0x661fac: mov             x0, NULL
    // 0x661fb0: LeaveFrame
    //     0x661fb0: mov             SP, fp
    //     0x661fb4: ldp             fp, lr, [SP], #0x10
    // 0x661fb8: ret
    //     0x661fb8: ret             
    // 0x661fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x661fbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x661fc0: b               #0x661f5c
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x661fc4, size: 0x7c
    // 0x661fc4: EnterFrame
    //     0x661fc4: stp             fp, lr, [SP, #-0x10]!
    //     0x661fc8: mov             fp, SP
    // 0x661fcc: AllocStack(0x8)
    //     0x661fcc: sub             SP, SP, #8
    // 0x661fd0: SetupParameters()
    //     0x661fd0: ldr             x0, [fp, #0x18]
    //     0x661fd4: ldur            w1, [x0, #0x17]
    //     0x661fd8: add             x1, x1, HEAP, lsl #32
    //     0x661fdc: stur            x1, [fp, #-8]
    // 0x661fe0: CheckStackOverflow
    //     0x661fe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x661fe4: cmp             SP, x16
    //     0x661fe8: b.ls            #0x662038
    // 0x661fec: LoadField: r0 = r1->field_f
    //     0x661fec: ldur            w0, [x1, #0xf]
    // 0x661ff0: DecompressPointer r0
    //     0x661ff0: add             x0, x0, HEAP, lsl #32
    // 0x661ff4: SaveReg r0
    //     0x661ff4: str             x0, [SP, #-8]!
    // 0x661ff8: r0 = canvas()
    //     0x661ff8: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x661ffc: add             SP, SP, #8
    // 0x662000: mov             x1, x0
    // 0x662004: ldur            x0, [fp, #-8]
    // 0x662008: LoadField: r2 = r0->field_13
    //     0x662008: ldur            w2, [x0, #0x13]
    // 0x66200c: DecompressPointer r2
    //     0x66200c: add             x2, x2, HEAP, lsl #32
    // 0x662010: stp             x2, x1, [SP, #-0x10]!
    // 0x662014: ldr             x16, [fp, #0x10]
    // 0x662018: SaveReg r16
    //     0x662018: str             x16, [SP, #-8]!
    // 0x66201c: r4 = const [0, 0x3, 0x3, 0x2, doAntiAlias, 0x2, null]
    //     0x66201c: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d200] List(7) [0, 0x3, 0x3, 0x2, "doAntiAlias", 0x2, Null]
    //     0x662020: ldr             x4, [x4, #0x200]
    // 0x662024: r0 = clipRRect()
    //     0x662024: bl              #0x662040  ; [dart:ui] Canvas::clipRRect
    // 0x662028: add             SP, SP, #0x18
    // 0x66202c: LeaveFrame
    //     0x66202c: mov             SP, fp
    //     0x662030: ldp             fp, lr, [SP], #0x10
    // 0x662034: ret
    //     0x662034: ret             
    // 0x662038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x662038: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66203c: b               #0x661fec
  }
  _ clipPathAndPaint(/* No info */) {
    // ** addr: 0x662900, size: 0x7c
    // 0x662900: EnterFrame
    //     0x662900: stp             fp, lr, [SP, #-0x10]!
    //     0x662904: mov             fp, SP
    // 0x662908: CheckStackOverflow
    //     0x662908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66290c: cmp             SP, x16
    //     0x662910: b.ls            #0x662974
    // 0x662914: r1 = 2
    //     0x662914: mov             x1, #2
    // 0x662918: r0 = AllocateContext()
    //     0x662918: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66291c: mov             x1, x0
    // 0x662920: ldr             x0, [fp, #0x30]
    // 0x662924: StoreField: r1->field_f = r0
    //     0x662924: stur            w0, [x1, #0xf]
    // 0x662928: ldr             x2, [fp, #0x28]
    // 0x66292c: StoreField: r1->field_13 = r2
    //     0x66292c: stur            w2, [x1, #0x13]
    // 0x662930: mov             x2, x1
    // 0x662934: r1 = Function '<anonymous closure>':.
    //     0x662934: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ae0] AnonymousClosure: (0x66297c), in [package:flutter/src/painting/clip.dart] ClipContext::clipPathAndPaint (0x662900)
    //     0x662938: ldr             x1, [x1, #0xae0]
    // 0x66293c: r0 = AllocateClosure()
    //     0x66293c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x662940: ldr             x16, [fp, #0x30]
    // 0x662944: stp             x0, x16, [SP, #-0x10]!
    // 0x662948: ldr             x16, [fp, #0x20]
    // 0x66294c: ldr             lr, [fp, #0x18]
    // 0x662950: stp             lr, x16, [SP, #-0x10]!
    // 0x662954: ldr             x16, [fp, #0x10]
    // 0x662958: SaveReg r16
    //     0x662958: str             x16, [SP, #-8]!
    // 0x66295c: r0 = _clipAndPaint()
    //     0x66295c: bl              #0x65b458  ; [package:flutter/src/painting/clip.dart] ClipContext::_clipAndPaint
    // 0x662960: add             SP, SP, #0x28
    // 0x662964: r0 = Null
    //     0x662964: mov             x0, NULL
    // 0x662968: LeaveFrame
    //     0x662968: mov             SP, fp
    //     0x66296c: ldp             fp, lr, [SP], #0x10
    // 0x662970: ret
    //     0x662970: ret             
    // 0x662974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x662974: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x662978: b               #0x662914
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x66297c, size: 0x78
    // 0x66297c: EnterFrame
    //     0x66297c: stp             fp, lr, [SP, #-0x10]!
    //     0x662980: mov             fp, SP
    // 0x662984: AllocStack(0x8)
    //     0x662984: sub             SP, SP, #8
    // 0x662988: SetupParameters()
    //     0x662988: ldr             x0, [fp, #0x18]
    //     0x66298c: ldur            w1, [x0, #0x17]
    //     0x662990: add             x1, x1, HEAP, lsl #32
    //     0x662994: stur            x1, [fp, #-8]
    // 0x662998: CheckStackOverflow
    //     0x662998: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66299c: cmp             SP, x16
    //     0x6629a0: b.ls            #0x6629ec
    // 0x6629a4: LoadField: r0 = r1->field_f
    //     0x6629a4: ldur            w0, [x1, #0xf]
    // 0x6629a8: DecompressPointer r0
    //     0x6629a8: add             x0, x0, HEAP, lsl #32
    // 0x6629ac: SaveReg r0
    //     0x6629ac: str             x0, [SP, #-8]!
    // 0x6629b0: r0 = canvas()
    //     0x6629b0: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x6629b4: add             SP, SP, #8
    // 0x6629b8: mov             x1, x0
    // 0x6629bc: ldur            x0, [fp, #-8]
    // 0x6629c0: LoadField: r2 = r0->field_13
    //     0x6629c0: ldur            w2, [x0, #0x13]
    // 0x6629c4: DecompressPointer r2
    //     0x6629c4: add             x2, x2, HEAP, lsl #32
    // 0x6629c8: stp             x2, x1, [SP, #-0x10]!
    // 0x6629cc: ldr             x16, [fp, #0x10]
    // 0x6629d0: SaveReg r16
    //     0x6629d0: str             x16, [SP, #-8]!
    // 0x6629d4: r0 = _clipPath()
    //     0x6629d4: bl              #0x662a88  ; [dart:ui] Canvas::_clipPath
    // 0x6629d8: add             SP, SP, #0x18
    // 0x6629dc: r0 = Null
    //     0x6629dc: mov             x0, NULL
    // 0x6629e0: LeaveFrame
    //     0x6629e0: mov             SP, fp
    //     0x6629e4: ldp             fp, lr, [SP], #0x10
    // 0x6629e8: ret
    //     0x6629e8: ret             
    // 0x6629ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6629ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6629f0: b               #0x6629a4
  }
}

// lib: , url: package:flutter/src/painting/placeholder_span.dart

// class id: 1049376, size: 0x8
class :: {
}

// class id: 3476, size: 0x14, field offset: 0xc
//   const constructor, 
abstract class PlaceholderSpan extends InlineSpan {

  _ computeSemanticsInformation(/* No info */) {
    // ** addr: 0xccef30, size: 0xa4
    // 0xccef30: EnterFrame
    //     0xccef30: stp             fp, lr, [SP, #-0x10]!
    //     0xccef34: mov             fp, SP
    // 0xccef38: AllocStack(0x8)
    //     0xccef38: sub             SP, SP, #8
    // 0xccef3c: CheckStackOverflow
    //     0xccef3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccef40: cmp             SP, x16
    //     0xccef44: b.ls            #0xccefc8
    // 0xccef48: ldr             x0, [fp, #0x10]
    // 0xccef4c: LoadField: r1 = r0->field_b
    //     0xccef4c: ldur            w1, [x0, #0xb]
    // 0xccef50: DecompressPointer r1
    //     0xccef50: add             x1, x1, HEAP, lsl #32
    // 0xccef54: stur            x1, [fp, #-8]
    // 0xccef58: LoadField: r2 = r0->field_f
    //     0xccef58: ldur            w2, [x0, #0xf]
    // 0xccef5c: DecompressPointer r2
    //     0xccef5c: add             x2, x2, HEAP, lsl #32
    // 0xccef60: LoadField: r3 = r2->field_b
    //     0xccef60: ldur            w3, [x2, #0xb]
    // 0xccef64: DecompressPointer r3
    //     0xccef64: add             x3, x3, HEAP, lsl #32
    // 0xccef68: cmp             w1, w3
    // 0xccef6c: b.ne            #0xccef7c
    // 0xccef70: SaveReg r0
    //     0xccef70: str             x0, [SP, #-8]!
    // 0xccef74: r0 = _growToNextCapacity()
    //     0xccef74: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xccef78: add             SP, SP, #8
    // 0xccef7c: ldr             x2, [fp, #0x10]
    // 0xccef80: ldur            x3, [fp, #-8]
    // 0xccef84: r4 = LoadInt32Instr(r3)
    //     0xccef84: sbfx            x4, x3, #1, #0x1f
    // 0xccef88: add             x0, x4, #1
    // 0xccef8c: lsl             x3, x0, #1
    // 0xccef90: StoreField: r2->field_b = r3
    //     0xccef90: stur            w3, [x2, #0xb]
    // 0xccef94: mov             x1, x4
    // 0xccef98: cmp             x1, x0
    // 0xccef9c: b.hs            #0xccefd0
    // 0xccefa0: LoadField: r1 = r2->field_f
    //     0xccefa0: ldur            w1, [x2, #0xf]
    // 0xccefa4: DecompressPointer r1
    //     0xccefa4: add             x1, x1, HEAP, lsl #32
    // 0xccefa8: add             x2, x1, x4, lsl #2
    // 0xccefac: r17 = Instance_InlineSpanSemanticsInformation
    //     0xccefac: add             x17, PP, #0x22, lsl #12  ; [pp+0x22368] Obj!InlineSpanSemanticsInformation@b356d1
    //     0xccefb0: ldr             x17, [x17, #0x368]
    // 0xccefb4: StoreField: r2->field_f = r17
    //     0xccefb4: stur            w17, [x2, #0xf]
    // 0xccefb8: r0 = Null
    //     0xccefb8: mov             x0, NULL
    // 0xccefbc: LeaveFrame
    //     0xccefbc: mov             SP, fp
    //     0xccefc0: ldp             fp, lr, [SP], #0x10
    // 0xccefc4: ret
    //     0xccefc4: ret             
    // 0xccefc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccefc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccefcc: b               #0xccef48
    // 0xccefd0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xccefd0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ computeToPlainText(/* No info */) {
    // ** addr: 0xcd8f0c, size: 0x54
    // 0xcd8f0c: EnterFrame
    //     0xcd8f0c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd8f10: mov             fp, SP
    // 0xcd8f14: mov             x0, x4
    // 0xcd8f18: LoadField: r1 = r0->field_13
    //     0xcd8f18: ldur            w1, [x0, #0x13]
    // 0xcd8f1c: DecompressPointer r1
    //     0xcd8f1c: add             x1, x1, HEAP, lsl #32
    // 0xcd8f20: sub             x0, x1, #4
    // 0xcd8f24: add             x1, fp, w0, sxtw #2
    // 0xcd8f28: ldr             x1, [x1, #0x10]
    // 0xcd8f2c: CheckStackOverflow
    //     0xcd8f2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd8f30: cmp             SP, x16
    //     0xcd8f34: b.ls            #0xcd8f58
    // 0xcd8f38: r16 = 131064
    //     0xcd8f38: mov             x16, #0x1fff8
    // 0xcd8f3c: stp             x16, x1, [SP, #-0x10]!
    // 0xcd8f40: r0 = writeCharCode()
    //     0xcd8f40: bl              #0x4d3a84  ; [dart:core] StringBuffer::writeCharCode
    // 0xcd8f44: add             SP, SP, #0x10
    // 0xcd8f48: r0 = Null
    //     0xcd8f48: mov             x0, NULL
    // 0xcd8f4c: LeaveFrame
    //     0xcd8f4c: mov             SP, fp
    //     0xcd8f50: ldp             fp, lr, [SP], #0x10
    // 0xcd8f54: ret
    //     0xcd8f54: ret             
    // 0xcd8f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd8f58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd8f5c: b               #0xcd8f38
  }
}

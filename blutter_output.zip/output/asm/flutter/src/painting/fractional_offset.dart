// lib: , url: package:flutter/src/painting/fractional_offset.dart

// class id: 1049363, size: 0x8
class :: {
}

// class id: 2120, size: 0x18, field offset: 0x18
//   const constructor, 
class FractionalOffset extends Alignment {

  _Mint field_8;
  _Mint field_10;

  _ toString(/* No info */) {
    // ** addr: 0xade3d0, size: 0x1a0
    // 0xade3d0: EnterFrame
    //     0xade3d0: stp             fp, lr, [SP, #-0x10]!
    //     0xade3d4: mov             fp, SP
    // 0xade3d8: AllocStack(0x8)
    //     0xade3d8: sub             SP, SP, #8
    // 0xade3dc: CheckStackOverflow
    //     0xade3dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade3e0: cmp             SP, x16
    //     0xade3e4: b.ls            #0xade52c
    // 0xade3e8: r1 = Null
    //     0xade3e8: mov             x1, NULL
    // 0xade3ec: r2 = 10
    //     0xade3ec: mov             x2, #0xa
    // 0xade3f0: r0 = AllocateArray()
    //     0xade3f0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xade3f4: stur            x0, [fp, #-8]
    // 0xade3f8: r17 = "FractionalOffset("
    //     0xade3f8: add             x17, PP, #0x37, lsl #12  ; [pp+0x371b8] "FractionalOffset("
    //     0xade3fc: ldr             x17, [x17, #0x1b8]
    // 0xade400: StoreField: r0->field_f = r17
    //     0xade400: stur            w17, [x0, #0xf]
    // 0xade404: ldr             x1, [fp, #0x10]
    // 0xade408: LoadField: d0 = r1->field_7
    //     0xade408: ldur            d0, [x1, #7]
    // 0xade40c: d1 = 1.000000
    //     0xade40c: fmov            d1, #1.00000000
    // 0xade410: fadd            d2, d0, d1
    // 0xade414: d0 = 2.000000
    //     0xade414: fmov            d0, #2.00000000
    // 0xade418: fdiv            d3, d2, d0
    // 0xade41c: r2 = inline_Allocate_Double()
    //     0xade41c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xade420: add             x2, x2, #0x10
    //     0xade424: cmp             x3, x2
    //     0xade428: b.ls            #0xade534
    //     0xade42c: str             x2, [THR, #0x60]  ; THR::top
    //     0xade430: sub             x2, x2, #0xf
    //     0xade434: mov             x3, #0xd108
    //     0xade438: movk            x3, #3, lsl #16
    //     0xade43c: stur            x3, [x2, #-1]
    // 0xade440: StoreField: r2->field_7 = d3
    //     0xade440: stur            d3, [x2, #7]
    // 0xade444: SaveReg r2
    //     0xade444: str             x2, [SP, #-8]!
    // 0xade448: r2 = 1
    //     0xade448: mov             x2, #1
    // 0xade44c: SaveReg r2
    //     0xade44c: str             x2, [SP, #-8]!
    // 0xade450: r0 = toStringAsFixed()
    //     0xade450: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xade454: add             SP, SP, #0x10
    // 0xade458: ldur            x1, [fp, #-8]
    // 0xade45c: ArrayStore: r1[1] = r0  ; List_4
    //     0xade45c: add             x25, x1, #0x13
    //     0xade460: str             w0, [x25]
    //     0xade464: tbz             w0, #0, #0xade480
    //     0xade468: ldurb           w16, [x1, #-1]
    //     0xade46c: ldurb           w17, [x0, #-1]
    //     0xade470: and             x16, x17, x16, lsr #2
    //     0xade474: tst             x16, HEAP, lsr #32
    //     0xade478: b.eq            #0xade480
    //     0xade47c: bl              #0xd67e5c
    // 0xade480: ldur            x1, [fp, #-8]
    // 0xade484: r17 = ", "
    //     0xade484: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xade488: StoreField: r1->field_17 = r17
    //     0xade488: stur            w17, [x1, #0x17]
    // 0xade48c: ldr             x0, [fp, #0x10]
    // 0xade490: LoadField: d0 = r0->field_f
    //     0xade490: ldur            d0, [x0, #0xf]
    // 0xade494: d1 = 1.000000
    //     0xade494: fmov            d1, #1.00000000
    // 0xade498: fadd            d2, d0, d1
    // 0xade49c: d0 = 2.000000
    //     0xade49c: fmov            d0, #2.00000000
    // 0xade4a0: fdiv            d1, d2, d0
    // 0xade4a4: r0 = inline_Allocate_Double()
    //     0xade4a4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xade4a8: add             x0, x0, #0x10
    //     0xade4ac: cmp             x2, x0
    //     0xade4b0: b.ls            #0xade558
    //     0xade4b4: str             x0, [THR, #0x60]  ; THR::top
    //     0xade4b8: sub             x0, x0, #0xf
    //     0xade4bc: mov             x2, #0xd108
    //     0xade4c0: movk            x2, #3, lsl #16
    //     0xade4c4: stur            x2, [x0, #-1]
    // 0xade4c8: StoreField: r0->field_7 = d1
    //     0xade4c8: stur            d1, [x0, #7]
    // 0xade4cc: SaveReg r0
    //     0xade4cc: str             x0, [SP, #-8]!
    // 0xade4d0: r0 = 1
    //     0xade4d0: mov             x0, #1
    // 0xade4d4: SaveReg r0
    //     0xade4d4: str             x0, [SP, #-8]!
    // 0xade4d8: r0 = toStringAsFixed()
    //     0xade4d8: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xade4dc: add             SP, SP, #0x10
    // 0xade4e0: ldur            x1, [fp, #-8]
    // 0xade4e4: ArrayStore: r1[3] = r0  ; List_4
    //     0xade4e4: add             x25, x1, #0x1b
    //     0xade4e8: str             w0, [x25]
    //     0xade4ec: tbz             w0, #0, #0xade508
    //     0xade4f0: ldurb           w16, [x1, #-1]
    //     0xade4f4: ldurb           w17, [x0, #-1]
    //     0xade4f8: and             x16, x17, x16, lsr #2
    //     0xade4fc: tst             x16, HEAP, lsr #32
    //     0xade500: b.eq            #0xade508
    //     0xade504: bl              #0xd67e5c
    // 0xade508: ldur            x0, [fp, #-8]
    // 0xade50c: r17 = ")"
    //     0xade50c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xade510: StoreField: r0->field_1f = r17
    //     0xade510: stur            w17, [x0, #0x1f]
    // 0xade514: SaveReg r0
    //     0xade514: str             x0, [SP, #-8]!
    // 0xade518: r0 = _interpolate()
    //     0xade518: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xade51c: add             SP, SP, #8
    // 0xade520: LeaveFrame
    //     0xade520: mov             SP, fp
    //     0xade524: ldp             fp, lr, [SP], #0x10
    // 0xade528: ret
    //     0xade528: ret             
    // 0xade52c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xade52c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xade530: b               #0xade3e8
    // 0xade534: stp             q1, q3, [SP, #-0x20]!
    // 0xade538: SaveReg d0
    //     0xade538: str             q0, [SP, #-0x10]!
    // 0xade53c: stp             x0, x1, [SP, #-0x10]!
    // 0xade540: r0 = AllocateDouble()
    //     0xade540: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xade544: mov             x2, x0
    // 0xade548: ldp             x0, x1, [SP], #0x10
    // 0xade54c: RestoreReg d0
    //     0xade54c: ldr             q0, [SP], #0x10
    // 0xade550: ldp             q1, q3, [SP], #0x20
    // 0xade554: b               #0xade440
    // 0xade558: SaveReg d1
    //     0xade558: str             q1, [SP, #-0x10]!
    // 0xade55c: SaveReg r1
    //     0xade55c: str             x1, [SP, #-8]!
    // 0xade560: r0 = AllocateDouble()
    //     0xade560: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xade564: RestoreReg r1
    //     0xade564: ldr             x1, [SP], #8
    // 0xade568: RestoreReg d1
    //     0xade568: ldr             q1, [SP], #0x10
    // 0xade56c: b               #0xade4c8
  }
  FractionalOffset /(FractionalOffset, double) {
    // ** addr: 0xade588, size: 0x88
    // 0xade588: EnterFrame
    //     0xade588: stp             fp, lr, [SP, #-0x10]!
    //     0xade58c: mov             fp, SP
    // 0xade590: CheckStackOverflow
    //     0xade590: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade594: cmp             SP, x16
    //     0xade598: b.ls            #0xade5f0
    // 0xade59c: ldr             x0, [fp, #0x10]
    // 0xade5a0: r2 = Null
    //     0xade5a0: mov             x2, NULL
    // 0xade5a4: r1 = Null
    //     0xade5a4: mov             x1, NULL
    // 0xade5a8: r4 = 59
    //     0xade5a8: mov             x4, #0x3b
    // 0xade5ac: branchIfSmi(r0, 0xade5b8)
    //     0xade5ac: tbz             w0, #0, #0xade5b8
    // 0xade5b0: r4 = LoadClassIdInstr(r0)
    //     0xade5b0: ldur            x4, [x0, #-1]
    //     0xade5b4: ubfx            x4, x4, #0xc, #0x14
    // 0xade5b8: cmp             x4, #0x3d
    // 0xade5bc: b.eq            #0xade5d0
    // 0xade5c0: r8 = double
    //     0xade5c0: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xade5c4: r3 = Null
    //     0xade5c4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b410] Null
    //     0xade5c8: ldr             x3, [x3, #0x410]
    // 0xade5cc: r0 = double()
    //     0xade5cc: bl              #0xd72bac  ; IsType_double_Stub
    // 0xade5d0: ldr             x16, [fp, #0x18]
    // 0xade5d4: ldr             lr, [fp, #0x10]
    // 0xade5d8: stp             lr, x16, [SP, #-0x10]!
    // 0xade5dc: r0 = /()
    //     0xade5dc: bl              #0xade5f8  ; [package:flutter/src/painting/fractional_offset.dart] FractionalOffset::/
    // 0xade5e0: add             SP, SP, #0x10
    // 0xade5e4: LeaveFrame
    //     0xade5e4: mov             SP, fp
    //     0xade5e8: ldp             fp, lr, [SP], #0x10
    // 0xade5ec: ret
    //     0xade5ec: ret             
    // 0xade5f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xade5f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xade5f4: b               #0xade59c
  }
  FractionalOffset /(FractionalOffset, double) {
    // ** addr: 0xade5f8, size: 0x78
    // 0xade5f8: EnterFrame
    //     0xade5f8: stp             fp, lr, [SP, #-0x10]!
    //     0xade5fc: mov             fp, SP
    // 0xade600: AllocStack(0x10)
    //     0xade600: sub             SP, SP, #0x10
    // 0xade604: d1 = 1.000000
    //     0xade604: fmov            d1, #1.00000000
    // 0xade608: d0 = 2.000000
    //     0xade608: fmov            d0, #2.00000000
    // 0xade60c: ldr             x0, [fp, #0x18]
    // 0xade610: LoadField: d2 = r0->field_7
    //     0xade610: ldur            d2, [x0, #7]
    // 0xade614: fadd            d3, d2, d1
    // 0xade618: fdiv            d2, d3, d0
    // 0xade61c: ldr             x1, [fp, #0x10]
    // 0xade620: LoadField: d3 = r1->field_7
    //     0xade620: ldur            d3, [x1, #7]
    // 0xade624: fdiv            d4, d2, d3
    // 0xade628: LoadField: d2 = r0->field_f
    //     0xade628: ldur            d2, [x0, #0xf]
    // 0xade62c: fadd            d5, d2, d1
    // 0xade630: fdiv            d2, d5, d0
    // 0xade634: fdiv            d5, d2, d3
    // 0xade638: fmul            d2, d4, d0
    // 0xade63c: fsub            d3, d2, d1
    // 0xade640: stur            d3, [fp, #-0x10]
    // 0xade644: fmul            d2, d5, d0
    // 0xade648: fsub            d0, d2, d1
    // 0xade64c: stur            d0, [fp, #-8]
    // 0xade650: r0 = FractionalOffset()
    //     0xade650: bl              #0xade670  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0xade654: ldur            d0, [fp, #-0x10]
    // 0xade658: StoreField: r0->field_7 = d0
    //     0xade658: stur            d0, [x0, #7]
    // 0xade65c: ldur            d0, [fp, #-8]
    // 0xade660: StoreField: r0->field_f = d0
    //     0xade660: stur            d0, [x0, #0xf]
    // 0xade664: LeaveFrame
    //     0xade664: mov             SP, fp
    //     0xade668: ldp             fp, lr, [SP], #0x10
    // 0xade66c: ret
    //     0xade66c: ret             
  }
  FractionalOffset *(FractionalOffset, double) {
    // ** addr: 0xade694, size: 0x88
    // 0xade694: EnterFrame
    //     0xade694: stp             fp, lr, [SP, #-0x10]!
    //     0xade698: mov             fp, SP
    // 0xade69c: CheckStackOverflow
    //     0xade69c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade6a0: cmp             SP, x16
    //     0xade6a4: b.ls            #0xade6fc
    // 0xade6a8: ldr             x0, [fp, #0x10]
    // 0xade6ac: r2 = Null
    //     0xade6ac: mov             x2, NULL
    // 0xade6b0: r1 = Null
    //     0xade6b0: mov             x1, NULL
    // 0xade6b4: r4 = 59
    //     0xade6b4: mov             x4, #0x3b
    // 0xade6b8: branchIfSmi(r0, 0xade6c4)
    //     0xade6b8: tbz             w0, #0, #0xade6c4
    // 0xade6bc: r4 = LoadClassIdInstr(r0)
    //     0xade6bc: ldur            x4, [x0, #-1]
    //     0xade6c0: ubfx            x4, x4, #0xc, #0x14
    // 0xade6c4: cmp             x4, #0x3d
    // 0xade6c8: b.eq            #0xade6dc
    // 0xade6cc: r8 = double
    //     0xade6cc: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xade6d0: r3 = Null
    //     0xade6d0: add             x3, PP, #0x37, lsl #12  ; [pp+0x371c0] Null
    //     0xade6d4: ldr             x3, [x3, #0x1c0]
    // 0xade6d8: r0 = double()
    //     0xade6d8: bl              #0xd72bac  ; IsType_double_Stub
    // 0xade6dc: ldr             x16, [fp, #0x18]
    // 0xade6e0: ldr             lr, [fp, #0x10]
    // 0xade6e4: stp             lr, x16, [SP, #-0x10]!
    // 0xade6e8: r0 = *()
    //     0xade6e8: bl              #0xcfad48  ; [package:flutter/src/painting/fractional_offset.dart] FractionalOffset::*
    // 0xade6ec: add             SP, SP, #0x10
    // 0xade6f0: LeaveFrame
    //     0xade6f0: mov             SP, fp
    //     0xade6f4: ldp             fp, lr, [SP], #0x10
    // 0xade6f8: ret
    //     0xade6f8: ret             
    // 0xade6fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xade6fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xade700: b               #0xade6a8
  }
  Alignment +(FractionalOffset, Alignment) {
    // ** addr: 0xade71c, size: 0x90
    // 0xade71c: EnterFrame
    //     0xade71c: stp             fp, lr, [SP, #-0x10]!
    //     0xade720: mov             fp, SP
    // 0xade724: CheckStackOverflow
    //     0xade724: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade728: cmp             SP, x16
    //     0xade72c: b.ls            #0xade78c
    // 0xade730: ldr             x0, [fp, #0x10]
    // 0xade734: r2 = Null
    //     0xade734: mov             x2, NULL
    // 0xade738: r1 = Null
    //     0xade738: mov             x1, NULL
    // 0xade73c: r4 = 59
    //     0xade73c: mov             x4, #0x3b
    // 0xade740: branchIfSmi(r0, 0xade74c)
    //     0xade740: tbz             w0, #0, #0xade74c
    // 0xade744: r4 = LoadClassIdInstr(r0)
    //     0xade744: ldur            x4, [x0, #-1]
    //     0xade748: ubfx            x4, x4, #0xc, #0x14
    // 0xade74c: sub             x4, x4, #0x847
    // 0xade750: cmp             x4, #1
    // 0xade754: b.ls            #0xade76c
    // 0xade758: r8 = Alignment
    //     0xade758: add             x8, PP, #0x28, lsl #12  ; [pp+0x288d8] Type: Alignment
    //     0xade75c: ldr             x8, [x8, #0x8d8]
    // 0xade760: r3 = Null
    //     0xade760: add             x3, PP, #0x37, lsl #12  ; [pp+0x371d0] Null
    //     0xade764: ldr             x3, [x3, #0x1d0]
    // 0xade768: r0 = DefaultTypeTest()
    //     0xade768: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xade76c: ldr             x16, [fp, #0x18]
    // 0xade770: ldr             lr, [fp, #0x10]
    // 0xade774: stp             lr, x16, [SP, #-0x10]!
    // 0xade778: r0 = +()
    //     0xade778: bl              #0xade794  ; [package:flutter/src/painting/fractional_offset.dart] FractionalOffset::+
    // 0xade77c: add             SP, SP, #0x10
    // 0xade780: LeaveFrame
    //     0xade780: mov             SP, fp
    //     0xade784: ldp             fp, lr, [SP], #0x10
    // 0xade788: ret
    //     0xade788: ret             
    // 0xade78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xade78c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xade790: b               #0xade730
  }
  Alignment +(FractionalOffset, Alignment) {
    // ** addr: 0xade794, size: 0xd4
    // 0xade794: EnterFrame
    //     0xade794: stp             fp, lr, [SP, #-0x10]!
    //     0xade798: mov             fp, SP
    // 0xade79c: AllocStack(0x10)
    //     0xade79c: sub             SP, SP, #0x10
    // 0xade7a0: CheckStackOverflow
    //     0xade7a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade7a4: cmp             SP, x16
    //     0xade7a8: b.ls            #0xade860
    // 0xade7ac: ldr             x0, [fp, #0x10]
    // 0xade7b0: r1 = LoadClassIdInstr(r0)
    //     0xade7b0: ldur            x1, [x0, #-1]
    //     0xade7b4: ubfx            x1, x1, #0xc, #0x14
    // 0xade7b8: lsl             x1, x1, #1
    // 0xade7bc: r17 = 4240
    //     0xade7bc: mov             x17, #0x1090
    // 0xade7c0: cmp             w1, w17
    // 0xade7c4: b.eq            #0xade7e4
    // 0xade7c8: ldr             x16, [fp, #0x18]
    // 0xade7cc: stp             x0, x16, [SP, #-0x10]!
    // 0xade7d0: r0 = +()
    //     0xade7d0: bl              #0x594a54  ; [package:flutter/src/painting/alignment.dart] Alignment::+
    // 0xade7d4: add             SP, SP, #0x10
    // 0xade7d8: LeaveFrame
    //     0xade7d8: mov             SP, fp
    //     0xade7dc: ldp             fp, lr, [SP], #0x10
    // 0xade7e0: ret
    //     0xade7e0: ret             
    // 0xade7e4: ldr             x1, [fp, #0x18]
    // 0xade7e8: d1 = 1.000000
    //     0xade7e8: fmov            d1, #1.00000000
    // 0xade7ec: d0 = 2.000000
    //     0xade7ec: fmov            d0, #2.00000000
    // 0xade7f0: LoadField: d2 = r1->field_7
    //     0xade7f0: ldur            d2, [x1, #7]
    // 0xade7f4: fadd            d3, d2, d1
    // 0xade7f8: fdiv            d2, d3, d0
    // 0xade7fc: LoadField: d3 = r0->field_7
    //     0xade7fc: ldur            d3, [x0, #7]
    // 0xade800: fadd            d4, d3, d1
    // 0xade804: fdiv            d3, d4, d0
    // 0xade808: fadd            d4, d2, d3
    // 0xade80c: LoadField: d2 = r1->field_f
    //     0xade80c: ldur            d2, [x1, #0xf]
    // 0xade810: fadd            d3, d2, d1
    // 0xade814: fdiv            d2, d3, d0
    // 0xade818: LoadField: d3 = r0->field_f
    //     0xade818: ldur            d3, [x0, #0xf]
    // 0xade81c: fadd            d5, d3, d1
    // 0xade820: fdiv            d3, d5, d0
    // 0xade824: fadd            d5, d2, d3
    // 0xade828: fmul            d2, d4, d0
    // 0xade82c: fsub            d3, d2, d1
    // 0xade830: stur            d3, [fp, #-0x10]
    // 0xade834: fmul            d2, d5, d0
    // 0xade838: fsub            d0, d2, d1
    // 0xade83c: stur            d0, [fp, #-8]
    // 0xade840: r0 = FractionalOffset()
    //     0xade840: bl              #0xade670  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0xade844: ldur            d0, [fp, #-0x10]
    // 0xade848: StoreField: r0->field_7 = d0
    //     0xade848: stur            d0, [x0, #7]
    // 0xade84c: ldur            d0, [fp, #-8]
    // 0xade850: StoreField: r0->field_f = d0
    //     0xade850: stur            d0, [x0, #0xf]
    // 0xade854: LeaveFrame
    //     0xade854: mov             SP, fp
    //     0xade858: ldp             fp, lr, [SP], #0x10
    // 0xade85c: ret
    //     0xade85c: ret             
    // 0xade860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xade860: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xade864: b               #0xade7ac
  }
  Alignment -(FractionalOffset, Alignment) {
    // ** addr: 0xade880, size: 0x90
    // 0xade880: EnterFrame
    //     0xade880: stp             fp, lr, [SP, #-0x10]!
    //     0xade884: mov             fp, SP
    // 0xade888: CheckStackOverflow
    //     0xade888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade88c: cmp             SP, x16
    //     0xade890: b.ls            #0xade8f0
    // 0xade894: ldr             x0, [fp, #0x10]
    // 0xade898: r2 = Null
    //     0xade898: mov             x2, NULL
    // 0xade89c: r1 = Null
    //     0xade89c: mov             x1, NULL
    // 0xade8a0: r4 = 59
    //     0xade8a0: mov             x4, #0x3b
    // 0xade8a4: branchIfSmi(r0, 0xade8b0)
    //     0xade8a4: tbz             w0, #0, #0xade8b0
    // 0xade8a8: r4 = LoadClassIdInstr(r0)
    //     0xade8a8: ldur            x4, [x0, #-1]
    //     0xade8ac: ubfx            x4, x4, #0xc, #0x14
    // 0xade8b0: sub             x4, x4, #0x847
    // 0xade8b4: cmp             x4, #1
    // 0xade8b8: b.ls            #0xade8d0
    // 0xade8bc: r8 = Alignment
    //     0xade8bc: add             x8, PP, #0x28, lsl #12  ; [pp+0x288d8] Type: Alignment
    //     0xade8c0: ldr             x8, [x8, #0x8d8]
    // 0xade8c4: r3 = Null
    //     0xade8c4: add             x3, PP, #0x37, lsl #12  ; [pp+0x371e0] Null
    //     0xade8c8: ldr             x3, [x3, #0x1e0]
    // 0xade8cc: r0 = DefaultTypeTest()
    //     0xade8cc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xade8d0: ldr             x16, [fp, #0x18]
    // 0xade8d4: ldr             lr, [fp, #0x10]
    // 0xade8d8: stp             lr, x16, [SP, #-0x10]!
    // 0xade8dc: r0 = -()
    //     0xade8dc: bl              #0xade8f8  ; [package:flutter/src/painting/fractional_offset.dart] FractionalOffset::-
    // 0xade8e0: add             SP, SP, #0x10
    // 0xade8e4: LeaveFrame
    //     0xade8e4: mov             SP, fp
    //     0xade8e8: ldp             fp, lr, [SP], #0x10
    // 0xade8ec: ret
    //     0xade8ec: ret             
    // 0xade8f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xade8f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xade8f4: b               #0xade894
  }
  Alignment -(FractionalOffset, Alignment) {
    // ** addr: 0xade8f8, size: 0xd4
    // 0xade8f8: EnterFrame
    //     0xade8f8: stp             fp, lr, [SP, #-0x10]!
    //     0xade8fc: mov             fp, SP
    // 0xade900: AllocStack(0x10)
    //     0xade900: sub             SP, SP, #0x10
    // 0xade904: CheckStackOverflow
    //     0xade904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade908: cmp             SP, x16
    //     0xade90c: b.ls            #0xade9c4
    // 0xade910: ldr             x0, [fp, #0x10]
    // 0xade914: r1 = LoadClassIdInstr(r0)
    //     0xade914: ldur            x1, [x0, #-1]
    //     0xade918: ubfx            x1, x1, #0xc, #0x14
    // 0xade91c: lsl             x1, x1, #1
    // 0xade920: r17 = 4240
    //     0xade920: mov             x17, #0x1090
    // 0xade924: cmp             w1, w17
    // 0xade928: b.eq            #0xade948
    // 0xade92c: ldr             x16, [fp, #0x18]
    // 0xade930: stp             x0, x16, [SP, #-0x10]!
    // 0xade934: r0 = -()
    //     0xade934: bl              #0x594b38  ; [package:flutter/src/painting/alignment.dart] Alignment::-
    // 0xade938: add             SP, SP, #0x10
    // 0xade93c: LeaveFrame
    //     0xade93c: mov             SP, fp
    //     0xade940: ldp             fp, lr, [SP], #0x10
    // 0xade944: ret
    //     0xade944: ret             
    // 0xade948: ldr             x1, [fp, #0x18]
    // 0xade94c: d1 = 1.000000
    //     0xade94c: fmov            d1, #1.00000000
    // 0xade950: d0 = 2.000000
    //     0xade950: fmov            d0, #2.00000000
    // 0xade954: LoadField: d2 = r1->field_7
    //     0xade954: ldur            d2, [x1, #7]
    // 0xade958: fadd            d3, d2, d1
    // 0xade95c: fdiv            d2, d3, d0
    // 0xade960: LoadField: d3 = r0->field_7
    //     0xade960: ldur            d3, [x0, #7]
    // 0xade964: fadd            d4, d3, d1
    // 0xade968: fdiv            d3, d4, d0
    // 0xade96c: fsub            d4, d2, d3
    // 0xade970: LoadField: d2 = r1->field_f
    //     0xade970: ldur            d2, [x1, #0xf]
    // 0xade974: fadd            d3, d2, d1
    // 0xade978: fdiv            d2, d3, d0
    // 0xade97c: LoadField: d3 = r0->field_f
    //     0xade97c: ldur            d3, [x0, #0xf]
    // 0xade980: fadd            d5, d3, d1
    // 0xade984: fdiv            d3, d5, d0
    // 0xade988: fsub            d5, d2, d3
    // 0xade98c: fmul            d2, d4, d0
    // 0xade990: fsub            d3, d2, d1
    // 0xade994: stur            d3, [fp, #-0x10]
    // 0xade998: fmul            d2, d5, d0
    // 0xade99c: fsub            d0, d2, d1
    // 0xade9a0: stur            d0, [fp, #-8]
    // 0xade9a4: r0 = FractionalOffset()
    //     0xade9a4: bl              #0xade670  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0xade9a8: ldur            d0, [fp, #-0x10]
    // 0xade9ac: StoreField: r0->field_7 = d0
    //     0xade9ac: stur            d0, [x0, #7]
    // 0xade9b0: ldur            d0, [fp, #-8]
    // 0xade9b4: StoreField: r0->field_f = d0
    //     0xade9b4: stur            d0, [x0, #0xf]
    // 0xade9b8: LeaveFrame
    //     0xade9b8: mov             SP, fp
    //     0xade9bc: ldp             fp, lr, [SP], #0x10
    // 0xade9c0: ret
    //     0xade9c0: ret             
    // 0xade9c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xade9c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xade9c8: b               #0xade910
  }
  FractionalOffset *(FractionalOffset, double) {
    // ** addr: 0xcfad48, size: 0x78
    // 0xcfad48: EnterFrame
    //     0xcfad48: stp             fp, lr, [SP, #-0x10]!
    //     0xcfad4c: mov             fp, SP
    // 0xcfad50: AllocStack(0x10)
    //     0xcfad50: sub             SP, SP, #0x10
    // 0xcfad54: d1 = 1.000000
    //     0xcfad54: fmov            d1, #1.00000000
    // 0xcfad58: d0 = 2.000000
    //     0xcfad58: fmov            d0, #2.00000000
    // 0xcfad5c: ldr             x0, [fp, #0x18]
    // 0xcfad60: LoadField: d2 = r0->field_7
    //     0xcfad60: ldur            d2, [x0, #7]
    // 0xcfad64: fadd            d3, d2, d1
    // 0xcfad68: fdiv            d2, d3, d0
    // 0xcfad6c: ldr             x1, [fp, #0x10]
    // 0xcfad70: LoadField: d3 = r1->field_7
    //     0xcfad70: ldur            d3, [x1, #7]
    // 0xcfad74: fmul            d4, d2, d3
    // 0xcfad78: LoadField: d2 = r0->field_f
    //     0xcfad78: ldur            d2, [x0, #0xf]
    // 0xcfad7c: fadd            d5, d2, d1
    // 0xcfad80: fdiv            d2, d5, d0
    // 0xcfad84: fmul            d5, d2, d3
    // 0xcfad88: fmul            d2, d4, d0
    // 0xcfad8c: fsub            d3, d2, d1
    // 0xcfad90: stur            d3, [fp, #-0x10]
    // 0xcfad94: fmul            d2, d5, d0
    // 0xcfad98: fsub            d0, d2, d1
    // 0xcfad9c: stur            d0, [fp, #-8]
    // 0xcfada0: r0 = FractionalOffset()
    //     0xcfada0: bl              #0xade670  ; AllocateFractionalOffsetStub -> FractionalOffset (size=0x18)
    // 0xcfada4: ldur            d0, [fp, #-0x10]
    // 0xcfada8: StoreField: r0->field_7 = d0
    //     0xcfada8: stur            d0, [x0, #7]
    // 0xcfadac: ldur            d0, [fp, #-8]
    // 0xcfadb0: StoreField: r0->field_f = d0
    //     0xcfadb0: stur            d0, [x0, #0xf]
    // 0xcfadb4: LeaveFrame
    //     0xcfadb4: mov             SP, fp
    //     0xcfadb8: ldp             fp, lr, [SP], #0x10
    // 0xcfadbc: ret
    //     0xcfadbc: ret             
  }
}

// lib: , url: package:flutter/src/painting/binding.dart

// class id: 1049347, size: 0x8
class :: {

  get _ imageCache(/* No info */) {
    // ** addr: 0xc3e248, size: 0x44
    // 0xc3e248: EnterFrame
    //     0xc3e248: stp             fp, lr, [SP, #-0x10]!
    //     0xc3e24c: mov             fp, SP
    // 0xc3e250: r1 = LoadStaticField(0xe6c)
    //     0xc3e250: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xc3e254: ldr             x1, [x1, #0x1cd8]
    // 0xc3e258: cmp             w1, NULL
    // 0xc3e25c: b.eq            #0xc3e280
    // 0xc3e260: LoadField: r0 = r1->field_a7
    //     0xc3e260: ldur            w0, [x1, #0xa7]
    // 0xc3e264: DecompressPointer r0
    //     0xc3e264: add             x0, x0, HEAP, lsl #32
    // 0xc3e268: r16 = Sentinel
    //     0xc3e268: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc3e26c: cmp             w0, w16
    // 0xc3e270: b.eq            #0xc3e284
    // 0xc3e274: LeaveFrame
    //     0xc3e274: mov             SP, fp
    //     0xc3e278: ldp             fp, lr, [SP], #0x10
    // 0xc3e27c: ret
    //     0xc3e27c: ret             
    // 0xc3e280: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc3e280: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc3e284: r9 = _imageCache
    //     0xc3e284: ldr             x9, [PP, #0x4f50]  ; [pp+0x4f50] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@423399801._imageCache@846047248>: late (offset: 0xa8)
    // 0xc3e288: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc3e288: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 2114, size: 0x8, field offset: 0x8
abstract class PaintingBinding extends _WidgetsBinding&BindingBase&ServicesBinding {

  get _ instance(/* No info */) {
    // ** addr: 0x9bca9c, size: 0x28
    // 0x9bca9c: EnterFrame
    //     0x9bca9c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcaa0: mov             fp, SP
    // 0x9bcaa4: r0 = LoadStaticField(0xe6c)
    //     0x9bcaa4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9bcaa8: ldr             x0, [x0, #0x1cd8]
    // 0x9bcaac: cmp             w0, NULL
    // 0x9bcab0: b.eq            #0x9bcac0
    // 0x9bcab4: LeaveFrame
    //     0x9bcab4: mov             SP, fp
    //     0x9bcab8: ldp             fp, lr, [SP], #0x10
    // 0x9bcabc: ret
    //     0x9bcabc: ret             
    // 0x9bcac0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bcac0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4325, size: 0xc, field offset: 0x8
class _SystemFontsNotifier extends Listenable {

  _ notifyListeners(/* No info */) {
    // ** addr: 0x5ccaec, size: 0xf0
    // 0x5ccaec: EnterFrame
    //     0x5ccaec: stp             fp, lr, [SP, #-0x10]!
    //     0x5ccaf0: mov             fp, SP
    // 0x5ccaf4: AllocStack(0x18)
    //     0x5ccaf4: sub             SP, SP, #0x18
    // 0x5ccaf8: CheckStackOverflow
    //     0x5ccaf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ccafc: cmp             SP, x16
    //     0x5ccb00: b.ls            #0x5ccbc8
    // 0x5ccb04: ldr             x0, [fp, #0x10]
    // 0x5ccb08: LoadField: r1 = r0->field_7
    //     0x5ccb08: ldur            w1, [x0, #7]
    // 0x5ccb0c: DecompressPointer r1
    //     0x5ccb0c: add             x1, x1, HEAP, lsl #32
    // 0x5ccb10: SaveReg r1
    //     0x5ccb10: str             x1, [SP, #-8]!
    // 0x5ccb14: r0 = iterator()
    //     0x5ccb14: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x5ccb18: add             SP, SP, #8
    // 0x5ccb1c: stur            x0, [fp, #-0x10]
    // 0x5ccb20: LoadField: r2 = r0->field_7
    //     0x5ccb20: ldur            w2, [x0, #7]
    // 0x5ccb24: DecompressPointer r2
    //     0x5ccb24: add             x2, x2, HEAP, lsl #32
    // 0x5ccb28: stur            x2, [fp, #-8]
    // 0x5ccb2c: CheckStackOverflow
    //     0x5ccb2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ccb30: cmp             SP, x16
    //     0x5ccb34: b.ls            #0x5ccbd0
    // 0x5ccb38: SaveReg r0
    //     0x5ccb38: str             x0, [SP, #-8]!
    // 0x5ccb3c: r0 = moveNext()
    //     0x5ccb3c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x5ccb40: add             SP, SP, #8
    // 0x5ccb44: tbnz            w0, #4, #0x5ccbb8
    // 0x5ccb48: ldur            x3, [fp, #-0x10]
    // 0x5ccb4c: LoadField: r4 = r3->field_33
    //     0x5ccb4c: ldur            w4, [x3, #0x33]
    // 0x5ccb50: DecompressPointer r4
    //     0x5ccb50: add             x4, x4, HEAP, lsl #32
    // 0x5ccb54: stur            x4, [fp, #-0x18]
    // 0x5ccb58: cmp             w4, NULL
    // 0x5ccb5c: b.ne            #0x5ccb8c
    // 0x5ccb60: mov             x0, x4
    // 0x5ccb64: ldur            x2, [fp, #-8]
    // 0x5ccb68: r1 = Null
    //     0x5ccb68: mov             x1, NULL
    // 0x5ccb6c: cmp             w2, NULL
    // 0x5ccb70: b.eq            #0x5ccb8c
    // 0x5ccb74: LoadField: r4 = r2->field_17
    //     0x5ccb74: ldur            w4, [x2, #0x17]
    // 0x5ccb78: DecompressPointer r4
    //     0x5ccb78: add             x4, x4, HEAP, lsl #32
    // 0x5ccb7c: r8 = X0
    //     0x5ccb7c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5ccb80: LoadField: r9 = r4->field_7
    //     0x5ccb80: ldur            x9, [x4, #7]
    // 0x5ccb84: r3 = Null
    //     0x5ccb84: ldr             x3, [PP, #0x4f08]  ; [pp+0x4f08] Null
    // 0x5ccb88: blr             x9
    // 0x5ccb8c: ldur            x0, [fp, #-0x18]
    // 0x5ccb90: cmp             w0, NULL
    // 0x5ccb94: b.eq            #0x5ccbd8
    // 0x5ccb98: SaveReg r0
    //     0x5ccb98: str             x0, [SP, #-8]!
    // 0x5ccb9c: ClosureCall
    //     0x5ccb9c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5ccba0: ldur            x2, [x0, #0x1f]
    //     0x5ccba4: blr             x2
    // 0x5ccba8: add             SP, SP, #8
    // 0x5ccbac: ldur            x0, [fp, #-0x10]
    // 0x5ccbb0: ldur            x2, [fp, #-8]
    // 0x5ccbb4: b               #0x5ccb2c
    // 0x5ccbb8: r0 = Null
    //     0x5ccbb8: mov             x0, NULL
    // 0x5ccbbc: LeaveFrame
    //     0x5ccbbc: mov             SP, fp
    //     0x5ccbc0: ldp             fp, lr, [SP], #0x10
    // 0x5ccbc4: ret
    //     0x5ccbc4: ret             
    // 0x5ccbc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ccbc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ccbcc: b               #0x5ccb04
    // 0x5ccbd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ccbd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ccbd4: b               #0x5ccb38
    // 0x5ccbd8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5ccbd8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _SystemFontsNotifier(/* No info */) {
    // ** addr: 0x5e311c, size: 0xbc
    // 0x5e311c: EnterFrame
    //     0x5e311c: stp             fp, lr, [SP, #-0x10]!
    //     0x5e3120: mov             fp, SP
    // 0x5e3124: AllocStack(0x10)
    //     0x5e3124: sub             SP, SP, #0x10
    // 0x5e3128: CheckStackOverflow
    //     0x5e3128: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e312c: cmp             SP, x16
    //     0x5e3130: b.ls            #0x5e31d0
    // 0x5e3134: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x5e3134: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5e3138: ldr             x0, [x0, #0x598]
    //     0x5e313c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5e3140: cmp             w0, w16
    //     0x5e3144: b.ne            #0x5e3150
    //     0x5e3148: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x5e314c: bl              #0xd67cdc
    // 0x5e3150: r1 = <(dynamic this) => void?>
    //     0x5e3150: ldr             x1, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0x5e3154: stur            x0, [fp, #-8]
    // 0x5e3158: r0 = _Set()
    //     0x5e3158: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x5e315c: mov             x1, x0
    // 0x5e3160: ldur            x0, [fp, #-8]
    // 0x5e3164: stur            x1, [fp, #-0x10]
    // 0x5e3168: StoreField: r1->field_1b = r0
    //     0x5e3168: stur            w0, [x1, #0x1b]
    // 0x5e316c: StoreField: r1->field_b = rZR
    //     0x5e316c: stur            wzr, [x1, #0xb]
    // 0x5e3170: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x5e3170: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5e3174: ldr             x0, [x0, #0x5a0]
    //     0x5e3178: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5e317c: cmp             w0, w16
    //     0x5e3180: b.ne            #0x5e318c
    //     0x5e3184: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x5e3188: bl              #0xd67cdc
    // 0x5e318c: mov             x1, x0
    // 0x5e3190: ldur            x0, [fp, #-0x10]
    // 0x5e3194: StoreField: r0->field_f = r1
    //     0x5e3194: stur            w1, [x0, #0xf]
    // 0x5e3198: StoreField: r0->field_13 = rZR
    //     0x5e3198: stur            wzr, [x0, #0x13]
    // 0x5e319c: StoreField: r0->field_17 = rZR
    //     0x5e319c: stur            wzr, [x0, #0x17]
    // 0x5e31a0: ldr             x1, [fp, #0x10]
    // 0x5e31a4: StoreField: r1->field_7 = r0
    //     0x5e31a4: stur            w0, [x1, #7]
    //     0x5e31a8: ldurb           w16, [x1, #-1]
    //     0x5e31ac: ldurb           w17, [x0, #-1]
    //     0x5e31b0: and             x16, x17, x16, lsr #2
    //     0x5e31b4: tst             x16, HEAP, lsr #32
    //     0x5e31b8: b.eq            #0x5e31c0
    //     0x5e31bc: bl              #0xd6826c
    // 0x5e31c0: r0 = Null
    //     0x5e31c0: mov             x0, NULL
    // 0x5e31c4: LeaveFrame
    //     0x5e31c4: mov             SP, fp
    //     0x5e31c8: ldp             fp, lr, [SP], #0x10
    // 0x5e31cc: ret
    //     0x5e31cc: ret             
    // 0x5e31d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e31d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e31d4: b               #0x5e3134
  }
  _ addListener(/* No info */) {
    // ** addr: 0x6e9740, size: 0x48
    // 0x6e9740: EnterFrame
    //     0x6e9740: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9744: mov             fp, SP
    // 0x6e9748: CheckStackOverflow
    //     0x6e9748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e974c: cmp             SP, x16
    //     0x6e9750: b.ls            #0x6e9780
    // 0x6e9754: ldr             x0, [fp, #0x18]
    // 0x6e9758: LoadField: r1 = r0->field_7
    //     0x6e9758: ldur            w1, [x0, #7]
    // 0x6e975c: DecompressPointer r1
    //     0x6e975c: add             x1, x1, HEAP, lsl #32
    // 0x6e9760: ldr             x16, [fp, #0x10]
    // 0x6e9764: stp             x16, x1, [SP, #-0x10]!
    // 0x6e9768: r0 = add()
    //     0x6e9768: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x6e976c: add             SP, SP, #0x10
    // 0x6e9770: r0 = Null
    //     0x6e9770: mov             x0, NULL
    // 0x6e9774: LeaveFrame
    //     0x6e9774: mov             SP, fp
    //     0x6e9778: ldp             fp, lr, [SP], #0x10
    // 0x6e977c: ret
    //     0x6e977c: ret             
    // 0x6e9780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9784: b               #0x6e9754
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6f63c0, size: 0x48
    // 0x6f63c0: EnterFrame
    //     0x6f63c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6f63c4: mov             fp, SP
    // 0x6f63c8: CheckStackOverflow
    //     0x6f63c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f63cc: cmp             SP, x16
    //     0x6f63d0: b.ls            #0x6f6400
    // 0x6f63d4: ldr             x0, [fp, #0x18]
    // 0x6f63d8: LoadField: r1 = r0->field_7
    //     0x6f63d8: ldur            w1, [x0, #7]
    // 0x6f63dc: DecompressPointer r1
    //     0x6f63dc: add             x1, x1, HEAP, lsl #32
    // 0x6f63e0: ldr             x16, [fp, #0x10]
    // 0x6f63e4: stp             x16, x1, [SP, #-0x10]!
    // 0x6f63e8: r0 = remove()
    //     0x6f63e8: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x6f63ec: add             SP, SP, #0x10
    // 0x6f63f0: r0 = Null
    //     0x6f63f0: mov             x0, NULL
    // 0x6f63f4: LeaveFrame
    //     0x6f63f4: mov             SP, fp
    //     0x6f63f8: ldp             fp, lr, [SP], #0x10
    // 0x6f63fc: ret
    //     0x6f63fc: ret             
    // 0x6f6400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f6400: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f6404: b               #0x6f63d4
  }
}

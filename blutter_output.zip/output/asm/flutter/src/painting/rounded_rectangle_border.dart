// lib: , url: package:flutter/src/painting/rounded_rectangle_border.dart

// class id: 1049377, size: 0x8
class :: {
}

// class id: 2178, size: 0x20, field offset: 0xc
//   const constructor, 
class _RoundedRectangleToCircleBorder extends OutlinedBorder {

  _ lerpTo(/* No info */) {
    // ** addr: 0x70ebe8, size: 0x3b4
    // 0x70ebe8: EnterFrame
    //     0x70ebe8: stp             fp, lr, [SP, #-0x10]!
    //     0x70ebec: mov             fp, SP
    // 0x70ebf0: AllocStack(0x28)
    //     0x70ebf0: sub             SP, SP, #0x28
    // 0x70ebf4: CheckStackOverflow
    //     0x70ebf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70ebf8: cmp             SP, x16
    //     0x70ebfc: b.ls            #0x70ef1c
    // 0x70ec00: ldr             x0, [fp, #0x18]
    // 0x70ec04: r1 = LoadClassIdInstr(r0)
    //     0x70ec04: ldur            x1, [x0, #-1]
    //     0x70ec08: ubfx            x1, x1, #0xc, #0x14
    // 0x70ec0c: lsl             x1, x1, #1
    // 0x70ec10: r17 = 4358
    //     0x70ec10: mov             x17, #0x1106
    // 0x70ec14: cmp             w1, w17
    // 0x70ec18: b.ne            #0x70ece0
    // 0x70ec1c: ldr             x1, [fp, #0x20]
    // 0x70ec20: ldr             d0, [fp, #0x10]
    // 0x70ec24: LoadField: r2 = r1->field_7
    //     0x70ec24: ldur            w2, [x1, #7]
    // 0x70ec28: DecompressPointer r2
    //     0x70ec28: add             x2, x2, HEAP, lsl #32
    // 0x70ec2c: LoadField: r3 = r0->field_7
    //     0x70ec2c: ldur            w3, [x0, #7]
    // 0x70ec30: DecompressPointer r3
    //     0x70ec30: add             x3, x3, HEAP, lsl #32
    // 0x70ec34: stp             x3, x2, [SP, #-0x10]!
    // 0x70ec38: SaveReg d0
    //     0x70ec38: str             d0, [SP, #-8]!
    // 0x70ec3c: r0 = lerp()
    //     0x70ec3c: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70ec40: add             SP, SP, #0x18
    // 0x70ec44: mov             x1, x0
    // 0x70ec48: ldr             x0, [fp, #0x20]
    // 0x70ec4c: stur            x1, [fp, #-8]
    // 0x70ec50: LoadField: r2 = r0->field_b
    //     0x70ec50: ldur            w2, [x0, #0xb]
    // 0x70ec54: DecompressPointer r2
    //     0x70ec54: add             x2, x2, HEAP, lsl #32
    // 0x70ec58: ldr             x3, [fp, #0x18]
    // 0x70ec5c: LoadField: r4 = r3->field_b
    //     0x70ec5c: ldur            w4, [x3, #0xb]
    // 0x70ec60: DecompressPointer r4
    //     0x70ec60: add             x4, x4, HEAP, lsl #32
    // 0x70ec64: stp             x4, x2, [SP, #-0x10]!
    // 0x70ec68: ldr             d0, [fp, #0x10]
    // 0x70ec6c: SaveReg d0
    //     0x70ec6c: str             d0, [SP, #-8]!
    // 0x70ec70: r0 = lerp()
    //     0x70ec70: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x70ec74: add             SP, SP, #0x18
    // 0x70ec78: stur            x0, [fp, #-0x10]
    // 0x70ec7c: cmp             w0, NULL
    // 0x70ec80: b.eq            #0x70ef24
    // 0x70ec84: ldr             x2, [fp, #0x20]
    // 0x70ec88: LoadField: d0 = r2->field_f
    //     0x70ec88: ldur            d0, [x2, #0xf]
    // 0x70ec8c: ldr             d1, [fp, #0x10]
    // 0x70ec90: d2 = 1.000000
    //     0x70ec90: fmov            d2, #1.00000000
    // 0x70ec94: fsub            d3, d2, d1
    // 0x70ec98: fmul            d1, d0, d3
    // 0x70ec9c: stur            d1, [fp, #-0x28]
    // 0x70eca0: LoadField: d0 = r2->field_17
    //     0x70eca0: ldur            d0, [x2, #0x17]
    // 0x70eca4: stur            d0, [fp, #-0x20]
    // 0x70eca8: r0 = _RoundedRectangleToCircleBorder()
    //     0x70eca8: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0x70ecac: mov             x1, x0
    // 0x70ecb0: ldur            x0, [fp, #-0x10]
    // 0x70ecb4: StoreField: r1->field_b = r0
    //     0x70ecb4: stur            w0, [x1, #0xb]
    // 0x70ecb8: ldur            d0, [fp, #-0x28]
    // 0x70ecbc: StoreField: r1->field_f = d0
    //     0x70ecbc: stur            d0, [x1, #0xf]
    // 0x70ecc0: ldur            d0, [fp, #-0x20]
    // 0x70ecc4: StoreField: r1->field_17 = d0
    //     0x70ecc4: stur            d0, [x1, #0x17]
    // 0x70ecc8: ldur            x0, [fp, #-8]
    // 0x70eccc: StoreField: r1->field_7 = r0
    //     0x70eccc: stur            w0, [x1, #7]
    // 0x70ecd0: mov             x0, x1
    // 0x70ecd4: LeaveFrame
    //     0x70ecd4: mov             SP, fp
    //     0x70ecd8: ldp             fp, lr, [SP], #0x10
    // 0x70ecdc: ret
    //     0x70ecdc: ret             
    // 0x70ece0: ldr             x2, [fp, #0x20]
    // 0x70ece4: mov             x3, x0
    // 0x70ece8: ldr             d1, [fp, #0x10]
    // 0x70ecec: d2 = 1.000000
    //     0x70ecec: fmov            d2, #1.00000000
    // 0x70ecf0: r17 = 4360
    //     0x70ecf0: mov             x17, #0x1108
    // 0x70ecf4: cmp             w1, w17
    // 0x70ecf8: b.ne            #0x70ed94
    // 0x70ecfc: LoadField: r0 = r2->field_7
    //     0x70ecfc: ldur            w0, [x2, #7]
    // 0x70ed00: DecompressPointer r0
    //     0x70ed00: add             x0, x0, HEAP, lsl #32
    // 0x70ed04: LoadField: r1 = r3->field_7
    //     0x70ed04: ldur            w1, [x3, #7]
    // 0x70ed08: DecompressPointer r1
    //     0x70ed08: add             x1, x1, HEAP, lsl #32
    // 0x70ed0c: stp             x1, x0, [SP, #-0x10]!
    // 0x70ed10: SaveReg d1
    //     0x70ed10: str             d1, [SP, #-8]!
    // 0x70ed14: r0 = lerp()
    //     0x70ed14: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70ed18: add             SP, SP, #0x18
    // 0x70ed1c: mov             x1, x0
    // 0x70ed20: ldr             x0, [fp, #0x20]
    // 0x70ed24: stur            x1, [fp, #-0x10]
    // 0x70ed28: LoadField: r2 = r0->field_b
    //     0x70ed28: ldur            w2, [x0, #0xb]
    // 0x70ed2c: DecompressPointer r2
    //     0x70ed2c: add             x2, x2, HEAP, lsl #32
    // 0x70ed30: stur            x2, [fp, #-8]
    // 0x70ed34: LoadField: d0 = r0->field_f
    //     0x70ed34: ldur            d0, [x0, #0xf]
    // 0x70ed38: d1 = 1.000000
    //     0x70ed38: fmov            d1, #1.00000000
    // 0x70ed3c: fsub            d2, d1, d0
    // 0x70ed40: ldr             d1, [fp, #0x10]
    // 0x70ed44: fmul            d3, d2, d1
    // 0x70ed48: fadd            d1, d0, d3
    // 0x70ed4c: ldr             x3, [fp, #0x18]
    // 0x70ed50: stur            d1, [fp, #-0x28]
    // 0x70ed54: LoadField: d0 = r3->field_b
    //     0x70ed54: ldur            d0, [x3, #0xb]
    // 0x70ed58: stur            d0, [fp, #-0x20]
    // 0x70ed5c: r0 = _RoundedRectangleToCircleBorder()
    //     0x70ed5c: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0x70ed60: mov             x1, x0
    // 0x70ed64: ldur            x0, [fp, #-8]
    // 0x70ed68: StoreField: r1->field_b = r0
    //     0x70ed68: stur            w0, [x1, #0xb]
    // 0x70ed6c: ldur            d0, [fp, #-0x28]
    // 0x70ed70: StoreField: r1->field_f = d0
    //     0x70ed70: stur            d0, [x1, #0xf]
    // 0x70ed74: ldur            d0, [fp, #-0x20]
    // 0x70ed78: StoreField: r1->field_17 = d0
    //     0x70ed78: stur            d0, [x1, #0x17]
    // 0x70ed7c: ldur            x0, [fp, #-0x10]
    // 0x70ed80: StoreField: r1->field_7 = r0
    //     0x70ed80: stur            w0, [x1, #7]
    // 0x70ed84: mov             x0, x1
    // 0x70ed88: LeaveFrame
    //     0x70ed88: mov             SP, fp
    //     0x70ed8c: ldp             fp, lr, [SP], #0x10
    // 0x70ed90: ret
    //     0x70ed90: ret             
    // 0x70ed94: mov             x0, x2
    // 0x70ed98: r17 = 4356
    //     0x70ed98: mov             x17, #0x1104
    // 0x70ed9c: cmp             w1, w17
    // 0x70eda0: b.ne            #0x70eef4
    // 0x70eda4: LoadField: r1 = r0->field_7
    //     0x70eda4: ldur            w1, [x0, #7]
    // 0x70eda8: DecompressPointer r1
    //     0x70eda8: add             x1, x1, HEAP, lsl #32
    // 0x70edac: LoadField: r2 = r3->field_7
    //     0x70edac: ldur            w2, [x3, #7]
    // 0x70edb0: DecompressPointer r2
    //     0x70edb0: add             x2, x2, HEAP, lsl #32
    // 0x70edb4: stp             x2, x1, [SP, #-0x10]!
    // 0x70edb8: SaveReg d1
    //     0x70edb8: str             d1, [SP, #-8]!
    // 0x70edbc: r0 = lerp()
    //     0x70edbc: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70edc0: add             SP, SP, #0x18
    // 0x70edc4: mov             x1, x0
    // 0x70edc8: ldr             x0, [fp, #0x20]
    // 0x70edcc: stur            x1, [fp, #-8]
    // 0x70edd0: LoadField: r2 = r0->field_b
    //     0x70edd0: ldur            w2, [x0, #0xb]
    // 0x70edd4: DecompressPointer r2
    //     0x70edd4: add             x2, x2, HEAP, lsl #32
    // 0x70edd8: ldr             x3, [fp, #0x18]
    // 0x70eddc: LoadField: r4 = r3->field_b
    //     0x70eddc: ldur            w4, [x3, #0xb]
    // 0x70ede0: DecompressPointer r4
    //     0x70ede0: add             x4, x4, HEAP, lsl #32
    // 0x70ede4: stp             x4, x2, [SP, #-0x10]!
    // 0x70ede8: ldr             d0, [fp, #0x10]
    // 0x70edec: SaveReg d0
    //     0x70edec: str             d0, [SP, #-8]!
    // 0x70edf0: r0 = lerp()
    //     0x70edf0: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x70edf4: add             SP, SP, #0x18
    // 0x70edf8: stur            x0, [fp, #-0x10]
    // 0x70edfc: cmp             w0, NULL
    // 0x70ee00: b.eq            #0x70ef28
    // 0x70ee04: ldr             x1, [fp, #0x20]
    // 0x70ee08: LoadField: d0 = r1->field_f
    //     0x70ee08: ldur            d0, [x1, #0xf]
    // 0x70ee0c: ldr             x2, [fp, #0x18]
    // 0x70ee10: LoadField: d1 = r2->field_f
    //     0x70ee10: ldur            d1, [x2, #0xf]
    // 0x70ee14: ldr             d2, [fp, #0x10]
    // 0x70ee18: r2 = inline_Allocate_Double()
    //     0x70ee18: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x70ee1c: add             x2, x2, #0x10
    //     0x70ee20: cmp             x3, x2
    //     0x70ee24: b.ls            #0x70ef2c
    //     0x70ee28: str             x2, [THR, #0x60]  ; THR::top
    //     0x70ee2c: sub             x2, x2, #0xf
    //     0x70ee30: mov             x3, #0xd108
    //     0x70ee34: movk            x3, #3, lsl #16
    //     0x70ee38: stur            x3, [x2, #-1]
    // 0x70ee3c: StoreField: r2->field_7 = d2
    //     0x70ee3c: stur            d2, [x2, #7]
    // 0x70ee40: r3 = inline_Allocate_Double()
    //     0x70ee40: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x70ee44: add             x3, x3, #0x10
    //     0x70ee48: cmp             x4, x3
    //     0x70ee4c: b.ls            #0x70ef50
    //     0x70ee50: str             x3, [THR, #0x60]  ; THR::top
    //     0x70ee54: sub             x3, x3, #0xf
    //     0x70ee58: mov             x4, #0xd108
    //     0x70ee5c: movk            x4, #3, lsl #16
    //     0x70ee60: stur            x4, [x3, #-1]
    // 0x70ee64: StoreField: r3->field_7 = d0
    //     0x70ee64: stur            d0, [x3, #7]
    // 0x70ee68: r4 = inline_Allocate_Double()
    //     0x70ee68: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x70ee6c: add             x4, x4, #0x10
    //     0x70ee70: cmp             x5, x4
    //     0x70ee74: b.ls            #0x70ef74
    //     0x70ee78: str             x4, [THR, #0x60]  ; THR::top
    //     0x70ee7c: sub             x4, x4, #0xf
    //     0x70ee80: mov             x5, #0xd108
    //     0x70ee84: movk            x5, #3, lsl #16
    //     0x70ee88: stur            x5, [x4, #-1]
    // 0x70ee8c: StoreField: r4->field_7 = d1
    //     0x70ee8c: stur            d1, [x4, #7]
    // 0x70ee90: stp             x4, x3, [SP, #-0x10]!
    // 0x70ee94: SaveReg r2
    //     0x70ee94: str             x2, [SP, #-8]!
    // 0x70ee98: r0 = lerpDouble()
    //     0x70ee98: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x70ee9c: add             SP, SP, #0x18
    // 0x70eea0: stur            x0, [fp, #-0x18]
    // 0x70eea4: cmp             w0, NULL
    // 0x70eea8: b.eq            #0x70ef98
    // 0x70eeac: ldr             x1, [fp, #0x20]
    // 0x70eeb0: LoadField: d0 = r1->field_17
    //     0x70eeb0: ldur            d0, [x1, #0x17]
    // 0x70eeb4: stur            d0, [fp, #-0x20]
    // 0x70eeb8: r0 = _RoundedRectangleToCircleBorder()
    //     0x70eeb8: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0x70eebc: mov             x1, x0
    // 0x70eec0: ldur            x0, [fp, #-0x10]
    // 0x70eec4: StoreField: r1->field_b = r0
    //     0x70eec4: stur            w0, [x1, #0xb]
    // 0x70eec8: ldur            x0, [fp, #-0x18]
    // 0x70eecc: LoadField: d0 = r0->field_7
    //     0x70eecc: ldur            d0, [x0, #7]
    // 0x70eed0: StoreField: r1->field_f = d0
    //     0x70eed0: stur            d0, [x1, #0xf]
    // 0x70eed4: ldur            d0, [fp, #-0x20]
    // 0x70eed8: StoreField: r1->field_17 = d0
    //     0x70eed8: stur            d0, [x1, #0x17]
    // 0x70eedc: ldur            x0, [fp, #-8]
    // 0x70eee0: StoreField: r1->field_7 = r0
    //     0x70eee0: stur            w0, [x1, #7]
    // 0x70eee4: mov             x0, x1
    // 0x70eee8: LeaveFrame
    //     0x70eee8: mov             SP, fp
    //     0x70eeec: ldp             fp, lr, [SP], #0x10
    // 0x70eef0: ret
    //     0x70eef0: ret             
    // 0x70eef4: mov             x1, x0
    // 0x70eef8: mov             x2, x3
    // 0x70eefc: mov             v2.16b, v1.16b
    // 0x70ef00: stp             x2, x1, [SP, #-0x10]!
    // 0x70ef04: SaveReg d2
    //     0x70ef04: str             d2, [SP, #-8]!
    // 0x70ef08: r0 = lerpTo()
    //     0x70ef08: bl              #0x70f880  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x70ef0c: add             SP, SP, #0x18
    // 0x70ef10: LeaveFrame
    //     0x70ef10: mov             SP, fp
    //     0x70ef14: ldp             fp, lr, [SP], #0x10
    // 0x70ef18: ret
    //     0x70ef18: ret             
    // 0x70ef1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70ef1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70ef20: b               #0x70ec00
    // 0x70ef24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70ef24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70ef28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70ef28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x70ef2c: stp             q1, q2, [SP, #-0x20]!
    // 0x70ef30: SaveReg d0
    //     0x70ef30: str             q0, [SP, #-0x10]!
    // 0x70ef34: stp             x0, x1, [SP, #-0x10]!
    // 0x70ef38: r0 = AllocateDouble()
    //     0x70ef38: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70ef3c: mov             x2, x0
    // 0x70ef40: ldp             x0, x1, [SP], #0x10
    // 0x70ef44: RestoreReg d0
    //     0x70ef44: ldr             q0, [SP], #0x10
    // 0x70ef48: ldp             q1, q2, [SP], #0x20
    // 0x70ef4c: b               #0x70ee3c
    // 0x70ef50: stp             q0, q1, [SP, #-0x20]!
    // 0x70ef54: stp             x1, x2, [SP, #-0x10]!
    // 0x70ef58: SaveReg r0
    //     0x70ef58: str             x0, [SP, #-8]!
    // 0x70ef5c: r0 = AllocateDouble()
    //     0x70ef5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70ef60: mov             x3, x0
    // 0x70ef64: RestoreReg r0
    //     0x70ef64: ldr             x0, [SP], #8
    // 0x70ef68: ldp             x1, x2, [SP], #0x10
    // 0x70ef6c: ldp             q0, q1, [SP], #0x20
    // 0x70ef70: b               #0x70ee64
    // 0x70ef74: SaveReg d1
    //     0x70ef74: str             q1, [SP, #-0x10]!
    // 0x70ef78: stp             x2, x3, [SP, #-0x10]!
    // 0x70ef7c: stp             x0, x1, [SP, #-0x10]!
    // 0x70ef80: r0 = AllocateDouble()
    //     0x70ef80: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70ef84: mov             x4, x0
    // 0x70ef88: ldp             x0, x1, [SP], #0x10
    // 0x70ef8c: ldp             x2, x3, [SP], #0x10
    // 0x70ef90: RestoreReg d1
    //     0x70ef90: ldr             q1, [SP], #0x10
    // 0x70ef94: b               #0x70ee8c
    // 0x70ef98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70ef98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x71021c, size: 0x3c0
    // 0x71021c: EnterFrame
    //     0x71021c: stp             fp, lr, [SP, #-0x10]!
    //     0x710220: mov             fp, SP
    // 0x710224: AllocStack(0x28)
    //     0x710224: sub             SP, SP, #0x28
    // 0x710228: CheckStackOverflow
    //     0x710228: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71022c: cmp             SP, x16
    //     0x710230: b.ls            #0x71055c
    // 0x710234: ldr             x0, [fp, #0x18]
    // 0x710238: r1 = LoadClassIdInstr(r0)
    //     0x710238: ldur            x1, [x0, #-1]
    //     0x71023c: ubfx            x1, x1, #0xc, #0x14
    // 0x710240: lsl             x1, x1, #1
    // 0x710244: r17 = 4358
    //     0x710244: mov             x17, #0x1106
    // 0x710248: cmp             w1, w17
    // 0x71024c: b.ne            #0x71030c
    // 0x710250: ldr             x1, [fp, #0x20]
    // 0x710254: ldr             d0, [fp, #0x10]
    // 0x710258: LoadField: r2 = r0->field_7
    //     0x710258: ldur            w2, [x0, #7]
    // 0x71025c: DecompressPointer r2
    //     0x71025c: add             x2, x2, HEAP, lsl #32
    // 0x710260: LoadField: r3 = r1->field_7
    //     0x710260: ldur            w3, [x1, #7]
    // 0x710264: DecompressPointer r3
    //     0x710264: add             x3, x3, HEAP, lsl #32
    // 0x710268: stp             x3, x2, [SP, #-0x10]!
    // 0x71026c: SaveReg d0
    //     0x71026c: str             d0, [SP, #-8]!
    // 0x710270: r0 = lerp()
    //     0x710270: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x710274: add             SP, SP, #0x18
    // 0x710278: mov             x1, x0
    // 0x71027c: ldr             x0, [fp, #0x18]
    // 0x710280: stur            x1, [fp, #-8]
    // 0x710284: LoadField: r2 = r0->field_b
    //     0x710284: ldur            w2, [x0, #0xb]
    // 0x710288: DecompressPointer r2
    //     0x710288: add             x2, x2, HEAP, lsl #32
    // 0x71028c: ldr             x0, [fp, #0x20]
    // 0x710290: LoadField: r3 = r0->field_b
    //     0x710290: ldur            w3, [x0, #0xb]
    // 0x710294: DecompressPointer r3
    //     0x710294: add             x3, x3, HEAP, lsl #32
    // 0x710298: stp             x3, x2, [SP, #-0x10]!
    // 0x71029c: ldr             d0, [fp, #0x10]
    // 0x7102a0: SaveReg d0
    //     0x7102a0: str             d0, [SP, #-8]!
    // 0x7102a4: r0 = lerp()
    //     0x7102a4: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x7102a8: add             SP, SP, #0x18
    // 0x7102ac: stur            x0, [fp, #-0x10]
    // 0x7102b0: cmp             w0, NULL
    // 0x7102b4: b.eq            #0x710564
    // 0x7102b8: ldr             x2, [fp, #0x20]
    // 0x7102bc: LoadField: d0 = r2->field_f
    //     0x7102bc: ldur            d0, [x2, #0xf]
    // 0x7102c0: ldr             d1, [fp, #0x10]
    // 0x7102c4: fmul            d2, d0, d1
    // 0x7102c8: stur            d2, [fp, #-0x28]
    // 0x7102cc: LoadField: d0 = r2->field_17
    //     0x7102cc: ldur            d0, [x2, #0x17]
    // 0x7102d0: stur            d0, [fp, #-0x20]
    // 0x7102d4: r0 = _RoundedRectangleToCircleBorder()
    //     0x7102d4: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0x7102d8: mov             x1, x0
    // 0x7102dc: ldur            x0, [fp, #-0x10]
    // 0x7102e0: StoreField: r1->field_b = r0
    //     0x7102e0: stur            w0, [x1, #0xb]
    // 0x7102e4: ldur            d0, [fp, #-0x28]
    // 0x7102e8: StoreField: r1->field_f = d0
    //     0x7102e8: stur            d0, [x1, #0xf]
    // 0x7102ec: ldur            d0, [fp, #-0x20]
    // 0x7102f0: StoreField: r1->field_17 = d0
    //     0x7102f0: stur            d0, [x1, #0x17]
    // 0x7102f4: ldur            x0, [fp, #-8]
    // 0x7102f8: StoreField: r1->field_7 = r0
    //     0x7102f8: stur            w0, [x1, #7]
    // 0x7102fc: mov             x0, x1
    // 0x710300: LeaveFrame
    //     0x710300: mov             SP, fp
    //     0x710304: ldp             fp, lr, [SP], #0x10
    // 0x710308: ret
    //     0x710308: ret             
    // 0x71030c: ldr             x2, [fp, #0x20]
    // 0x710310: ldr             d1, [fp, #0x10]
    // 0x710314: r17 = 4360
    //     0x710314: mov             x17, #0x1108
    // 0x710318: cmp             w1, w17
    // 0x71031c: b.ne            #0x7103bc
    // 0x710320: LoadField: r1 = r0->field_7
    //     0x710320: ldur            w1, [x0, #7]
    // 0x710324: DecompressPointer r1
    //     0x710324: add             x1, x1, HEAP, lsl #32
    // 0x710328: LoadField: r3 = r2->field_7
    //     0x710328: ldur            w3, [x2, #7]
    // 0x71032c: DecompressPointer r3
    //     0x71032c: add             x3, x3, HEAP, lsl #32
    // 0x710330: stp             x3, x1, [SP, #-0x10]!
    // 0x710334: SaveReg d1
    //     0x710334: str             d1, [SP, #-8]!
    // 0x710338: r0 = lerp()
    //     0x710338: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x71033c: add             SP, SP, #0x18
    // 0x710340: mov             x1, x0
    // 0x710344: ldr             x0, [fp, #0x20]
    // 0x710348: stur            x1, [fp, #-0x10]
    // 0x71034c: LoadField: r2 = r0->field_b
    //     0x71034c: ldur            w2, [x0, #0xb]
    // 0x710350: DecompressPointer r2
    //     0x710350: add             x2, x2, HEAP, lsl #32
    // 0x710354: stur            x2, [fp, #-8]
    // 0x710358: LoadField: d0 = r0->field_f
    //     0x710358: ldur            d0, [x0, #0xf]
    // 0x71035c: d1 = 1.000000
    //     0x71035c: fmov            d1, #1.00000000
    // 0x710360: fsub            d2, d1, d0
    // 0x710364: ldr             d3, [fp, #0x10]
    // 0x710368: fsub            d4, d1, d3
    // 0x71036c: fmul            d1, d2, d4
    // 0x710370: fadd            d2, d0, d1
    // 0x710374: ldr             x3, [fp, #0x18]
    // 0x710378: stur            d2, [fp, #-0x28]
    // 0x71037c: LoadField: d0 = r3->field_b
    //     0x71037c: ldur            d0, [x3, #0xb]
    // 0x710380: stur            d0, [fp, #-0x20]
    // 0x710384: r0 = _RoundedRectangleToCircleBorder()
    //     0x710384: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0x710388: mov             x1, x0
    // 0x71038c: ldur            x0, [fp, #-8]
    // 0x710390: StoreField: r1->field_b = r0
    //     0x710390: stur            w0, [x1, #0xb]
    // 0x710394: ldur            d0, [fp, #-0x28]
    // 0x710398: StoreField: r1->field_f = d0
    //     0x710398: stur            d0, [x1, #0xf]
    // 0x71039c: ldur            d0, [fp, #-0x20]
    // 0x7103a0: StoreField: r1->field_17 = d0
    //     0x7103a0: stur            d0, [x1, #0x17]
    // 0x7103a4: ldur            x0, [fp, #-0x10]
    // 0x7103a8: StoreField: r1->field_7 = r0
    //     0x7103a8: stur            w0, [x1, #7]
    // 0x7103ac: mov             x0, x1
    // 0x7103b0: LeaveFrame
    //     0x7103b0: mov             SP, fp
    //     0x7103b4: ldp             fp, lr, [SP], #0x10
    // 0x7103b8: ret
    //     0x7103b8: ret             
    // 0x7103bc: mov             x3, x0
    // 0x7103c0: mov             x0, x2
    // 0x7103c4: mov             v3.16b, v1.16b
    // 0x7103c8: r17 = 4356
    //     0x7103c8: mov             x17, #0x1104
    // 0x7103cc: cmp             w1, w17
    // 0x7103d0: b.ne            #0x710524
    // 0x7103d4: LoadField: r1 = r3->field_7
    //     0x7103d4: ldur            w1, [x3, #7]
    // 0x7103d8: DecompressPointer r1
    //     0x7103d8: add             x1, x1, HEAP, lsl #32
    // 0x7103dc: LoadField: r2 = r0->field_7
    //     0x7103dc: ldur            w2, [x0, #7]
    // 0x7103e0: DecompressPointer r2
    //     0x7103e0: add             x2, x2, HEAP, lsl #32
    // 0x7103e4: stp             x2, x1, [SP, #-0x10]!
    // 0x7103e8: SaveReg d3
    //     0x7103e8: str             d3, [SP, #-8]!
    // 0x7103ec: r0 = lerp()
    //     0x7103ec: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x7103f0: add             SP, SP, #0x18
    // 0x7103f4: mov             x1, x0
    // 0x7103f8: ldr             x0, [fp, #0x18]
    // 0x7103fc: stur            x1, [fp, #-8]
    // 0x710400: LoadField: r2 = r0->field_b
    //     0x710400: ldur            w2, [x0, #0xb]
    // 0x710404: DecompressPointer r2
    //     0x710404: add             x2, x2, HEAP, lsl #32
    // 0x710408: ldr             x3, [fp, #0x20]
    // 0x71040c: LoadField: r4 = r3->field_b
    //     0x71040c: ldur            w4, [x3, #0xb]
    // 0x710410: DecompressPointer r4
    //     0x710410: add             x4, x4, HEAP, lsl #32
    // 0x710414: stp             x4, x2, [SP, #-0x10]!
    // 0x710418: ldr             d0, [fp, #0x10]
    // 0x71041c: SaveReg d0
    //     0x71041c: str             d0, [SP, #-8]!
    // 0x710420: r0 = lerp()
    //     0x710420: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x710424: add             SP, SP, #0x18
    // 0x710428: stur            x0, [fp, #-0x10]
    // 0x71042c: cmp             w0, NULL
    // 0x710430: b.eq            #0x710568
    // 0x710434: ldr             x1, [fp, #0x18]
    // 0x710438: LoadField: d0 = r1->field_f
    //     0x710438: ldur            d0, [x1, #0xf]
    // 0x71043c: ldr             x1, [fp, #0x20]
    // 0x710440: LoadField: d1 = r1->field_f
    //     0x710440: ldur            d1, [x1, #0xf]
    // 0x710444: ldr             d2, [fp, #0x10]
    // 0x710448: r2 = inline_Allocate_Double()
    //     0x710448: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x71044c: add             x2, x2, #0x10
    //     0x710450: cmp             x3, x2
    //     0x710454: b.ls            #0x71056c
    //     0x710458: str             x2, [THR, #0x60]  ; THR::top
    //     0x71045c: sub             x2, x2, #0xf
    //     0x710460: mov             x3, #0xd108
    //     0x710464: movk            x3, #3, lsl #16
    //     0x710468: stur            x3, [x2, #-1]
    // 0x71046c: StoreField: r2->field_7 = d2
    //     0x71046c: stur            d2, [x2, #7]
    // 0x710470: r3 = inline_Allocate_Double()
    //     0x710470: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x710474: add             x3, x3, #0x10
    //     0x710478: cmp             x4, x3
    //     0x71047c: b.ls            #0x710590
    //     0x710480: str             x3, [THR, #0x60]  ; THR::top
    //     0x710484: sub             x3, x3, #0xf
    //     0x710488: mov             x4, #0xd108
    //     0x71048c: movk            x4, #3, lsl #16
    //     0x710490: stur            x4, [x3, #-1]
    // 0x710494: StoreField: r3->field_7 = d0
    //     0x710494: stur            d0, [x3, #7]
    // 0x710498: r4 = inline_Allocate_Double()
    //     0x710498: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x71049c: add             x4, x4, #0x10
    //     0x7104a0: cmp             x5, x4
    //     0x7104a4: b.ls            #0x7105b4
    //     0x7104a8: str             x4, [THR, #0x60]  ; THR::top
    //     0x7104ac: sub             x4, x4, #0xf
    //     0x7104b0: mov             x5, #0xd108
    //     0x7104b4: movk            x5, #3, lsl #16
    //     0x7104b8: stur            x5, [x4, #-1]
    // 0x7104bc: StoreField: r4->field_7 = d1
    //     0x7104bc: stur            d1, [x4, #7]
    // 0x7104c0: stp             x4, x3, [SP, #-0x10]!
    // 0x7104c4: SaveReg r2
    //     0x7104c4: str             x2, [SP, #-8]!
    // 0x7104c8: r0 = lerpDouble()
    //     0x7104c8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x7104cc: add             SP, SP, #0x18
    // 0x7104d0: stur            x0, [fp, #-0x18]
    // 0x7104d4: cmp             w0, NULL
    // 0x7104d8: b.eq            #0x7105d8
    // 0x7104dc: ldr             x2, [fp, #0x20]
    // 0x7104e0: LoadField: d0 = r2->field_17
    //     0x7104e0: ldur            d0, [x2, #0x17]
    // 0x7104e4: stur            d0, [fp, #-0x20]
    // 0x7104e8: r0 = _RoundedRectangleToCircleBorder()
    //     0x7104e8: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0x7104ec: mov             x1, x0
    // 0x7104f0: ldur            x0, [fp, #-0x10]
    // 0x7104f4: StoreField: r1->field_b = r0
    //     0x7104f4: stur            w0, [x1, #0xb]
    // 0x7104f8: ldur            x0, [fp, #-0x18]
    // 0x7104fc: LoadField: d0 = r0->field_7
    //     0x7104fc: ldur            d0, [x0, #7]
    // 0x710500: StoreField: r1->field_f = d0
    //     0x710500: stur            d0, [x1, #0xf]
    // 0x710504: ldur            d0, [fp, #-0x20]
    // 0x710508: StoreField: r1->field_17 = d0
    //     0x710508: stur            d0, [x1, #0x17]
    // 0x71050c: ldur            x0, [fp, #-8]
    // 0x710510: StoreField: r1->field_7 = r0
    //     0x710510: stur            w0, [x1, #7]
    // 0x710514: mov             x0, x1
    // 0x710518: LeaveFrame
    //     0x710518: mov             SP, fp
    //     0x71051c: ldp             fp, lr, [SP], #0x10
    // 0x710520: ret
    //     0x710520: ret             
    // 0x710524: mov             x2, x0
    // 0x710528: mov             x1, x3
    // 0x71052c: mov             v2.16b, v3.16b
    // 0x710530: cmp             w1, NULL
    // 0x710534: b.ne            #0x71054c
    // 0x710538: SaveReg r2
    //     0x710538: str             x2, [SP, #-8]!
    // 0x71053c: SaveReg d2
    //     0x71053c: str             d2, [SP, #-8]!
    // 0x710540: r0 = scale()
    //     0x710540: bl              #0xcf87a4  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::scale
    // 0x710544: add             SP, SP, #0x10
    // 0x710548: b               #0x710550
    // 0x71054c: r0 = Null
    //     0x71054c: mov             x0, NULL
    // 0x710550: LeaveFrame
    //     0x710550: mov             SP, fp
    //     0x710554: ldp             fp, lr, [SP], #0x10
    // 0x710558: ret
    //     0x710558: ret             
    // 0x71055c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71055c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x710560: b               #0x710234
    // 0x710564: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x710564: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x710568: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x710568: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x71056c: stp             q1, q2, [SP, #-0x20]!
    // 0x710570: SaveReg d0
    //     0x710570: str             q0, [SP, #-0x10]!
    // 0x710574: stp             x0, x1, [SP, #-0x10]!
    // 0x710578: r0 = AllocateDouble()
    //     0x710578: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x71057c: mov             x2, x0
    // 0x710580: ldp             x0, x1, [SP], #0x10
    // 0x710584: RestoreReg d0
    //     0x710584: ldr             q0, [SP], #0x10
    // 0x710588: ldp             q1, q2, [SP], #0x20
    // 0x71058c: b               #0x71046c
    // 0x710590: stp             q0, q1, [SP, #-0x20]!
    // 0x710594: stp             x1, x2, [SP, #-0x10]!
    // 0x710598: SaveReg r0
    //     0x710598: str             x0, [SP, #-8]!
    // 0x71059c: r0 = AllocateDouble()
    //     0x71059c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7105a0: mov             x3, x0
    // 0x7105a4: RestoreReg r0
    //     0x7105a4: ldr             x0, [SP], #8
    // 0x7105a8: ldp             x1, x2, [SP], #0x10
    // 0x7105ac: ldp             q0, q1, [SP], #0x20
    // 0x7105b0: b               #0x710494
    // 0x7105b4: SaveReg d1
    //     0x7105b4: str             q1, [SP, #-0x10]!
    // 0x7105b8: stp             x2, x3, [SP, #-0x10]!
    // 0x7105bc: stp             x0, x1, [SP, #-0x10]!
    // 0x7105c0: r0 = AllocateDouble()
    //     0x7105c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7105c4: mov             x4, x0
    // 0x7105c8: ldp             x0, x1, [SP], #0x10
    // 0x7105cc: ldp             x2, x3, [SP], #0x10
    // 0x7105d0: RestoreReg d1
    //     0x7105d0: ldr             q1, [SP], #0x10
    // 0x7105d4: b               #0x7104bc
    // 0x7105d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7105d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x7180b8, size: 0xe0
    // 0x7180b8: EnterFrame
    //     0x7180b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7180bc: mov             fp, SP
    // 0x7180c0: AllocStack(0x8)
    //     0x7180c0: sub             SP, SP, #8
    // 0x7180c4: CheckStackOverflow
    //     0x7180c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7180c8: cmp             SP, x16
    //     0x7180cc: b.ls            #0x71818c
    // 0x7180d0: ldr             x16, [fp, #0x30]
    // 0x7180d4: ldr             lr, [fp, #0x20]
    // 0x7180d8: stp             lr, x16, [SP, #-0x10]!
    // 0x7180dc: ldr             x16, [fp, #0x10]
    // 0x7180e0: SaveReg r16
    //     0x7180e0: str             x16, [SP, #-8]!
    // 0x7180e4: r0 = _adjustBorderRadius()
    //     0x7180e4: bl              #0x7182e4  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustBorderRadius
    // 0x7180e8: add             SP, SP, #0x18
    // 0x7180ec: stur            x0, [fp, #-8]
    // 0x7180f0: cmp             w0, NULL
    // 0x7180f4: b.eq            #0x718194
    // 0x7180f8: r16 = Instance_BorderRadius
    //     0x7180f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x7180fc: ldr             x16, [x16, #0x2c0]
    // 0x718100: stp             x16, x0, [SP, #-0x10]!
    // 0x718104: r0 = ==()
    //     0x718104: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x718108: add             SP, SP, #0x10
    // 0x71810c: tbnz            w0, #4, #0x718140
    // 0x718110: ldr             x16, [fp, #0x30]
    // 0x718114: ldr             lr, [fp, #0x20]
    // 0x718118: stp             lr, x16, [SP, #-0x10]!
    // 0x71811c: r0 = _adjustRect()
    //     0x71811c: bl              #0x718198  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustRect
    // 0x718120: add             SP, SP, #0x10
    // 0x718124: ldr             x16, [fp, #0x28]
    // 0x718128: stp             x0, x16, [SP, #-0x10]!
    // 0x71812c: ldr             x16, [fp, #0x18]
    // 0x718130: SaveReg r16
    //     0x718130: str             x16, [SP, #-8]!
    // 0x718134: r0 = drawRect()
    //     0x718134: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0x718138: add             SP, SP, #0x18
    // 0x71813c: b               #0x71817c
    // 0x718140: ldr             x16, [fp, #0x30]
    // 0x718144: ldr             lr, [fp, #0x20]
    // 0x718148: stp             lr, x16, [SP, #-0x10]!
    // 0x71814c: r0 = _adjustRect()
    //     0x71814c: bl              #0x718198  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustRect
    // 0x718150: add             SP, SP, #0x10
    // 0x718154: ldur            x16, [fp, #-8]
    // 0x718158: stp             x0, x16, [SP, #-0x10]!
    // 0x71815c: r0 = toRRect()
    //     0x71815c: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x718160: add             SP, SP, #0x10
    // 0x718164: ldr             x16, [fp, #0x28]
    // 0x718168: stp             x0, x16, [SP, #-0x10]!
    // 0x71816c: ldr             x16, [fp, #0x18]
    // 0x718170: SaveReg r16
    //     0x718170: str             x16, [SP, #-8]!
    // 0x718174: r0 = drawRRect()
    //     0x718174: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x718178: add             SP, SP, #0x18
    // 0x71817c: r0 = Null
    //     0x71817c: mov             x0, NULL
    // 0x718180: LeaveFrame
    //     0x718180: mov             SP, fp
    //     0x718184: ldp             fp, lr, [SP], #0x10
    // 0x718188: ret
    //     0x718188: ret             
    // 0x71818c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71818c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x718190: b               #0x7180d0
    // 0x718194: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x718194: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _adjustRect(/* No info */) {
    // ** addr: 0x718198, size: 0x14c
    // 0x718198: EnterFrame
    //     0x718198: stp             fp, lr, [SP, #-0x10]!
    //     0x71819c: mov             fp, SP
    // 0x7181a0: AllocStack(0x30)
    //     0x7181a0: sub             SP, SP, #0x30
    // 0x7181a4: d0 = 0.000000
    //     0x7181a4: eor             v0.16b, v0.16b, v0.16b
    // 0x7181a8: ldr             x0, [fp, #0x18]
    // 0x7181ac: LoadField: d1 = r0->field_f
    //     0x7181ac: ldur            d1, [x0, #0xf]
    // 0x7181b0: fcmp            d1, d0
    // 0x7181b4: b.vs            #0x7181c4
    // 0x7181b8: b.ne            #0x7181c4
    // 0x7181bc: ldr             x1, [fp, #0x10]
    // 0x7181c0: b               #0x7181fc
    // 0x7181c4: ldr             x1, [fp, #0x10]
    // 0x7181c8: LoadField: d0 = r1->field_17
    //     0x7181c8: ldur            d0, [x1, #0x17]
    // 0x7181cc: stur            d0, [fp, #-0x20]
    // 0x7181d0: LoadField: d2 = r1->field_7
    //     0x7181d0: ldur            d2, [x1, #7]
    // 0x7181d4: stur            d2, [fp, #-0x18]
    // 0x7181d8: fsub            d3, d0, d2
    // 0x7181dc: LoadField: d4 = r1->field_1f
    //     0x7181dc: ldur            d4, [x1, #0x1f]
    // 0x7181e0: stur            d4, [fp, #-0x30]
    // 0x7181e4: LoadField: d5 = r1->field_f
    //     0x7181e4: ldur            d5, [x1, #0xf]
    // 0x7181e8: stur            d5, [fp, #-0x28]
    // 0x7181ec: fsub            d6, d4, d5
    // 0x7181f0: fcmp            d3, d6
    // 0x7181f4: b.vs            #0x71820c
    // 0x7181f8: b.ne            #0x71820c
    // 0x7181fc: mov             x0, x1
    // 0x718200: LeaveFrame
    //     0x718200: mov             SP, fp
    //     0x718204: ldp             fp, lr, [SP], #0x10
    // 0x718208: ret
    //     0x718208: ret             
    // 0x71820c: fcmp            d3, d6
    // 0x718210: b.vs            #0x718278
    // 0x718214: b.ge            #0x718278
    // 0x718218: d8 = 2.000000
    //     0x718218: fmov            d8, #2.00000000
    // 0x71821c: d7 = 1.000000
    //     0x71821c: fmov            d7, #1.00000000
    // 0x718220: fsub            d9, d6, d3
    // 0x718224: fdiv            d3, d9, d8
    // 0x718228: fmul            d6, d1, d3
    // 0x71822c: LoadField: d1 = r0->field_17
    //     0x71822c: ldur            d1, [x0, #0x17]
    // 0x718230: fsub            d3, d7, d1
    // 0x718234: fmul            d1, d6, d3
    // 0x718238: fadd            d3, d5, d1
    // 0x71823c: stur            d3, [fp, #-0x10]
    // 0x718240: fsub            d5, d4, d1
    // 0x718244: stur            d5, [fp, #-8]
    // 0x718248: r0 = Rect()
    //     0x718248: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x71824c: ldur            d0, [fp, #-0x18]
    // 0x718250: StoreField: r0->field_7 = d0
    //     0x718250: stur            d0, [x0, #7]
    // 0x718254: ldur            d0, [fp, #-0x10]
    // 0x718258: StoreField: r0->field_f = d0
    //     0x718258: stur            d0, [x0, #0xf]
    // 0x71825c: ldur            d2, [fp, #-0x20]
    // 0x718260: StoreField: r0->field_17 = d2
    //     0x718260: stur            d2, [x0, #0x17]
    // 0x718264: ldur            d0, [fp, #-8]
    // 0x718268: StoreField: r0->field_1f = d0
    //     0x718268: stur            d0, [x0, #0x1f]
    // 0x71826c: LeaveFrame
    //     0x71826c: mov             SP, fp
    //     0x718270: ldp             fp, lr, [SP], #0x10
    // 0x718274: ret
    //     0x718274: ret             
    // 0x718278: mov             v31.16b, v2.16b
    // 0x71827c: mov             v2.16b, v0.16b
    // 0x718280: mov             v0.16b, v31.16b
    // 0x718284: d8 = 2.000000
    //     0x718284: fmov            d8, #2.00000000
    // 0x718288: d7 = 1.000000
    //     0x718288: fmov            d7, #1.00000000
    // 0x71828c: fsub            d9, d3, d6
    // 0x718290: fdiv            d3, d9, d8
    // 0x718294: fmul            d6, d1, d3
    // 0x718298: LoadField: d1 = r0->field_17
    //     0x718298: ldur            d1, [x0, #0x17]
    // 0x71829c: fsub            d3, d7, d1
    // 0x7182a0: fmul            d1, d6, d3
    // 0x7182a4: fadd            d3, d0, d1
    // 0x7182a8: stur            d3, [fp, #-0x10]
    // 0x7182ac: fsub            d0, d2, d1
    // 0x7182b0: stur            d0, [fp, #-8]
    // 0x7182b4: r0 = Rect()
    //     0x7182b4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x7182b8: ldur            d0, [fp, #-0x10]
    // 0x7182bc: StoreField: r0->field_7 = d0
    //     0x7182bc: stur            d0, [x0, #7]
    // 0x7182c0: ldur            d0, [fp, #-0x28]
    // 0x7182c4: StoreField: r0->field_f = d0
    //     0x7182c4: stur            d0, [x0, #0xf]
    // 0x7182c8: ldur            d0, [fp, #-8]
    // 0x7182cc: StoreField: r0->field_17 = d0
    //     0x7182cc: stur            d0, [x0, #0x17]
    // 0x7182d0: ldur            d0, [fp, #-0x30]
    // 0x7182d4: StoreField: r0->field_1f = d0
    //     0x7182d4: stur            d0, [x0, #0x1f]
    // 0x7182d8: LeaveFrame
    //     0x7182d8: mov             SP, fp
    //     0x7182dc: ldp             fp, lr, [SP], #0x10
    // 0x7182e0: ret
    //     0x7182e0: ret             
  }
  _ _adjustBorderRadius(/* No info */) {
    // ** addr: 0x7182e4, size: 0x26c
    // 0x7182e4: EnterFrame
    //     0x7182e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7182e8: mov             fp, SP
    // 0x7182ec: AllocStack(0x28)
    //     0x7182ec: sub             SP, SP, #0x28
    // 0x7182f0: CheckStackOverflow
    //     0x7182f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7182f4: cmp             SP, x16
    //     0x7182f8: b.ls            #0x718540
    // 0x7182fc: ldr             x1, [fp, #0x20]
    // 0x718300: LoadField: r0 = r1->field_b
    //     0x718300: ldur            w0, [x1, #0xb]
    // 0x718304: DecompressPointer r0
    //     0x718304: add             x0, x0, HEAP, lsl #32
    // 0x718308: r2 = LoadClassIdInstr(r0)
    //     0x718308: ldur            x2, [x0, #-1]
    //     0x71830c: ubfx            x2, x2, #0xc, #0x14
    // 0x718310: lsl             x2, x2, #1
    // 0x718314: r17 = 4224
    //     0x718314: mov             x17, #0x1080
    // 0x718318: cmp             w2, w17
    // 0x71831c: b.ne            #0x718330
    // 0x718320: mov             x16, x1
    // 0x718324: mov             x1, x0
    // 0x718328: mov             x0, x16
    // 0x71832c: b               #0x71835c
    // 0x718330: r2 = LoadClassIdInstr(r0)
    //     0x718330: ldur            x2, [x0, #-1]
    //     0x718334: ubfx            x2, x2, #0xc, #0x14
    // 0x718338: ldr             x16, [fp, #0x10]
    // 0x71833c: stp             x16, x0, [SP, #-0x10]!
    // 0x718340: mov             x0, x2
    // 0x718344: r0 = GDT[cid_x0 + -0x1000]()
    //     0x718344: sub             lr, x0, #1, lsl #12
    //     0x718348: ldr             lr, [x21, lr, lsl #3]
    //     0x71834c: blr             lr
    // 0x718350: add             SP, SP, #0x10
    // 0x718354: mov             x1, x0
    // 0x718358: ldr             x0, [fp, #0x20]
    // 0x71835c: d0 = 0.000000
    //     0x71835c: eor             v0.16b, v0.16b, v0.16b
    // 0x718360: stur            x1, [fp, #-8]
    // 0x718364: LoadField: d1 = r0->field_f
    //     0x718364: ldur            d1, [x0, #0xf]
    // 0x718368: stur            d1, [fp, #-0x28]
    // 0x71836c: fcmp            d1, d0
    // 0x718370: b.vs            #0x718388
    // 0x718374: b.ne            #0x718388
    // 0x718378: mov             x0, x1
    // 0x71837c: LeaveFrame
    //     0x71837c: mov             SP, fp
    //     0x718380: ldp             fp, lr, [SP], #0x10
    // 0x718384: ret
    //     0x718384: ret             
    // 0x718388: LoadField: d2 = r0->field_17
    //     0x718388: ldur            d2, [x0, #0x17]
    // 0x71838c: fcmp            d2, d0
    // 0x718390: b.eq            #0x7184c4
    // 0x718394: ldr             x0, [fp, #0x18]
    // 0x718398: LoadField: d0 = r0->field_17
    //     0x718398: ldur            d0, [x0, #0x17]
    // 0x71839c: LoadField: d3 = r0->field_7
    //     0x71839c: ldur            d3, [x0, #7]
    // 0x7183a0: fsub            d4, d0, d3
    // 0x7183a4: LoadField: d0 = r0->field_1f
    //     0x7183a4: ldur            d0, [x0, #0x1f]
    // 0x7183a8: LoadField: d3 = r0->field_f
    //     0x7183a8: ldur            d3, [x0, #0xf]
    // 0x7183ac: fsub            d5, d0, d3
    // 0x7183b0: fcmp            d4, d5
    // 0x7183b4: b.vs            #0x718440
    // 0x7183b8: b.ge            #0x718440
    // 0x7183bc: d3 = 2.000000
    //     0x7183bc: fmov            d3, #2.00000000
    // 0x7183c0: d0 = 0.500000
    //     0x7183c0: fmov            d0, #0.50000000
    // 0x7183c4: fdiv            d6, d4, d3
    // 0x7183c8: stur            d6, [fp, #-0x20]
    // 0x7183cc: fdiv            d4, d2, d3
    // 0x7183d0: fadd            d2, d0, d4
    // 0x7183d4: fmul            d0, d2, d5
    // 0x7183d8: fdiv            d2, d0, d3
    // 0x7183dc: stur            d2, [fp, #-0x18]
    // 0x7183e0: r0 = Radius()
    //     0x7183e0: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7183e4: ldur            d0, [fp, #-0x20]
    // 0x7183e8: stur            x0, [fp, #-0x10]
    // 0x7183ec: StoreField: r0->field_7 = d0
    //     0x7183ec: stur            d0, [x0, #7]
    // 0x7183f0: ldur            d0, [fp, #-0x18]
    // 0x7183f4: StoreField: r0->field_f = d0
    //     0x7183f4: stur            d0, [x0, #0xf]
    // 0x7183f8: r0 = BorderRadius()
    //     0x7183f8: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x7183fc: mov             x1, x0
    // 0x718400: ldur            x0, [fp, #-0x10]
    // 0x718404: StoreField: r1->field_7 = r0
    //     0x718404: stur            w0, [x1, #7]
    // 0x718408: StoreField: r1->field_b = r0
    //     0x718408: stur            w0, [x1, #0xb]
    // 0x71840c: StoreField: r1->field_f = r0
    //     0x71840c: stur            w0, [x1, #0xf]
    // 0x718410: StoreField: r1->field_13 = r0
    //     0x718410: stur            w0, [x1, #0x13]
    // 0x718414: ldur            x16, [fp, #-8]
    // 0x718418: stp             x1, x16, [SP, #-0x10]!
    // 0x71841c: ldur            d1, [fp, #-0x28]
    // 0x718420: SaveReg d1
    //     0x718420: str             d1, [SP, #-8]!
    // 0x718424: r0 = lerp()
    //     0x718424: bl              #0x70e1fc  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x718428: add             SP, SP, #0x18
    // 0x71842c: cmp             w0, NULL
    // 0x718430: b.eq            #0x718548
    // 0x718434: LeaveFrame
    //     0x718434: mov             SP, fp
    //     0x718438: ldp             fp, lr, [SP], #0x10
    // 0x71843c: ret
    //     0x71843c: ret             
    // 0x718440: d3 = 2.000000
    //     0x718440: fmov            d3, #2.00000000
    // 0x718444: d0 = 0.500000
    //     0x718444: fmov            d0, #0.50000000
    // 0x718448: fdiv            d6, d2, d3
    // 0x71844c: fadd            d2, d0, d6
    // 0x718450: fmul            d0, d2, d4
    // 0x718454: fdiv            d2, d0, d3
    // 0x718458: stur            d2, [fp, #-0x20]
    // 0x71845c: fdiv            d0, d5, d3
    // 0x718460: stur            d0, [fp, #-0x18]
    // 0x718464: r0 = Radius()
    //     0x718464: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x718468: ldur            d0, [fp, #-0x20]
    // 0x71846c: stur            x0, [fp, #-0x10]
    // 0x718470: StoreField: r0->field_7 = d0
    //     0x718470: stur            d0, [x0, #7]
    // 0x718474: ldur            d0, [fp, #-0x18]
    // 0x718478: StoreField: r0->field_f = d0
    //     0x718478: stur            d0, [x0, #0xf]
    // 0x71847c: r0 = BorderRadius()
    //     0x71847c: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x718480: mov             x1, x0
    // 0x718484: ldur            x0, [fp, #-0x10]
    // 0x718488: StoreField: r1->field_7 = r0
    //     0x718488: stur            w0, [x1, #7]
    // 0x71848c: StoreField: r1->field_b = r0
    //     0x71848c: stur            w0, [x1, #0xb]
    // 0x718490: StoreField: r1->field_f = r0
    //     0x718490: stur            w0, [x1, #0xf]
    // 0x718494: StoreField: r1->field_13 = r0
    //     0x718494: stur            w0, [x1, #0x13]
    // 0x718498: ldur            x16, [fp, #-8]
    // 0x71849c: stp             x1, x16, [SP, #-0x10]!
    // 0x7184a0: ldur            d0, [fp, #-0x28]
    // 0x7184a4: SaveReg d0
    //     0x7184a4: str             d0, [SP, #-8]!
    // 0x7184a8: r0 = lerp()
    //     0x7184a8: bl              #0x70e1fc  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x7184ac: add             SP, SP, #0x18
    // 0x7184b0: cmp             w0, NULL
    // 0x7184b4: b.eq            #0x71854c
    // 0x7184b8: LeaveFrame
    //     0x7184b8: mov             SP, fp
    //     0x7184bc: ldp             fp, lr, [SP], #0x10
    // 0x7184c0: ret
    //     0x7184c0: ret             
    // 0x7184c4: ldr             x0, [fp, #0x18]
    // 0x7184c8: mov             v0.16b, v1.16b
    // 0x7184cc: d3 = 2.000000
    //     0x7184cc: fmov            d3, #2.00000000
    // 0x7184d0: SaveReg r0
    //     0x7184d0: str             x0, [SP, #-8]!
    // 0x7184d4: r0 = shortestSide()
    //     0x7184d4: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0x7184d8: add             SP, SP, #8
    // 0x7184dc: mov             v1.16b, v0.16b
    // 0x7184e0: d0 = 2.000000
    //     0x7184e0: fmov            d0, #2.00000000
    // 0x7184e4: fdiv            d2, d1, d0
    // 0x7184e8: stur            d2, [fp, #-0x18]
    // 0x7184ec: r0 = Radius()
    //     0x7184ec: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x7184f0: ldur            d0, [fp, #-0x18]
    // 0x7184f4: stur            x0, [fp, #-0x10]
    // 0x7184f8: StoreField: r0->field_7 = d0
    //     0x7184f8: stur            d0, [x0, #7]
    // 0x7184fc: StoreField: r0->field_f = d0
    //     0x7184fc: stur            d0, [x0, #0xf]
    // 0x718500: r0 = BorderRadius()
    //     0x718500: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0x718504: mov             x1, x0
    // 0x718508: ldur            x0, [fp, #-0x10]
    // 0x71850c: StoreField: r1->field_7 = r0
    //     0x71850c: stur            w0, [x1, #7]
    // 0x718510: StoreField: r1->field_b = r0
    //     0x718510: stur            w0, [x1, #0xb]
    // 0x718514: StoreField: r1->field_f = r0
    //     0x718514: stur            w0, [x1, #0xf]
    // 0x718518: StoreField: r1->field_13 = r0
    //     0x718518: stur            w0, [x1, #0x13]
    // 0x71851c: ldur            x16, [fp, #-8]
    // 0x718520: stp             x1, x16, [SP, #-0x10]!
    // 0x718524: ldur            d0, [fp, #-0x28]
    // 0x718528: SaveReg d0
    //     0x718528: str             d0, [SP, #-8]!
    // 0x71852c: r0 = lerp()
    //     0x71852c: bl              #0x70e1fc  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x718530: add             SP, SP, #0x18
    // 0x718534: LeaveFrame
    //     0x718534: mov             SP, fp
    //     0x718538: ldp             fp, lr, [SP], #0x10
    // 0x71853c: ret
    //     0x71853c: ret             
    // 0x718540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x718540: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x718544: b               #0x7182fc
    // 0x718548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x718548: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x71854c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71854c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getInnerPath(/* No info */) {
    // ** addr: 0x71ae30, size: 0x1d4
    // 0x71ae30: EnterFrame
    //     0x71ae30: stp             fp, lr, [SP, #-0x10]!
    //     0x71ae34: mov             fp, SP
    // 0x71ae38: AllocStack(0x18)
    //     0x71ae38: sub             SP, SP, #0x18
    // 0x71ae3c: SetupParameters(_RoundedRectangleToCircleBorder this /* r3, fp-0x10 */, dynamic _ /* r4, fp-0x8 */, {dynamic textDirection = Null /* r0 */})
    //     0x71ae3c: mov             x0, x4
    //     0x71ae40: ldur            w1, [x0, #0x13]
    //     0x71ae44: add             x1, x1, HEAP, lsl #32
    //     0x71ae48: sub             x2, x1, #4
    //     0x71ae4c: add             x3, fp, w2, sxtw #2
    //     0x71ae50: ldr             x3, [x3, #0x18]
    //     0x71ae54: stur            x3, [fp, #-0x10]
    //     0x71ae58: add             x4, fp, w2, sxtw #2
    //     0x71ae5c: ldr             x4, [x4, #0x10]
    //     0x71ae60: stur            x4, [fp, #-8]
    //     0x71ae64: ldur            w2, [x0, #0x1f]
    //     0x71ae68: add             x2, x2, HEAP, lsl #32
    //     0x71ae6c: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0x71ae70: ldr             x16, [x16, #0xf10]
    //     0x71ae74: cmp             w2, w16
    //     0x71ae78: b.ne            #0x71ae98
    //     0x71ae7c: ldur            w2, [x0, #0x23]
    //     0x71ae80: add             x2, x2, HEAP, lsl #32
    //     0x71ae84: sub             w0, w1, w2
    //     0x71ae88: add             x1, fp, w0, sxtw #2
    //     0x71ae8c: ldr             x1, [x1, #8]
    //     0x71ae90: mov             x0, x1
    //     0x71ae94: b               #0x71ae9c
    //     0x71ae98: mov             x0, NULL
    // 0x71ae9c: CheckStackOverflow
    //     0x71ae9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71aea0: cmp             SP, x16
    //     0x71aea4: b.ls            #0x71afc0
    // 0x71aea8: stp             x4, x3, [SP, #-0x10]!
    // 0x71aeac: SaveReg r0
    //     0x71aeac: str             x0, [SP, #-8]!
    // 0x71aeb0: r0 = _adjustBorderRadius()
    //     0x71aeb0: bl              #0x7182e4  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustBorderRadius
    // 0x71aeb4: add             SP, SP, #0x18
    // 0x71aeb8: stur            x0, [fp, #-0x18]
    // 0x71aebc: cmp             w0, NULL
    // 0x71aec0: b.eq            #0x71afc8
    // 0x71aec4: ldur            x16, [fp, #-0x10]
    // 0x71aec8: ldur            lr, [fp, #-8]
    // 0x71aecc: stp             lr, x16, [SP, #-0x10]!
    // 0x71aed0: r0 = _adjustRect()
    //     0x71aed0: bl              #0x718198  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustRect
    // 0x71aed4: add             SP, SP, #0x10
    // 0x71aed8: ldur            x16, [fp, #-0x18]
    // 0x71aedc: stp             x0, x16, [SP, #-0x10]!
    // 0x71aee0: r0 = toRRect()
    //     0x71aee0: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x71aee4: add             SP, SP, #0x10
    // 0x71aee8: mov             x1, x0
    // 0x71aeec: ldur            x0, [fp, #-0x10]
    // 0x71aef0: stur            x1, [fp, #-8]
    // 0x71aef4: LoadField: r2 = r0->field_7
    //     0x71aef4: ldur            w2, [x0, #7]
    // 0x71aef8: DecompressPointer r2
    //     0x71aef8: add             x2, x2, HEAP, lsl #32
    // 0x71aefc: LoadField: d0 = r2->field_b
    //     0x71aefc: ldur            d0, [x2, #0xb]
    // 0x71af00: LoadField: d1 = r2->field_17
    //     0x71af00: ldur            d1, [x2, #0x17]
    // 0x71af04: r0 = inline_Allocate_Double()
    //     0x71af04: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x71af08: add             x0, x0, #0x10
    //     0x71af0c: cmp             x2, x0
    //     0x71af10: b.ls            #0x71afcc
    //     0x71af14: str             x0, [THR, #0x60]  ; THR::top
    //     0x71af18: sub             x0, x0, #0xf
    //     0x71af1c: mov             x2, #0xd108
    //     0x71af20: movk            x2, #3, lsl #16
    //     0x71af24: stur            x2, [x0, #-1]
    // 0x71af28: StoreField: r0->field_7 = d0
    //     0x71af28: stur            d0, [x0, #7]
    // 0x71af2c: r2 = inline_Allocate_Double()
    //     0x71af2c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x71af30: add             x2, x2, #0x10
    //     0x71af34: cmp             x3, x2
    //     0x71af38: b.ls            #0x71afe4
    //     0x71af3c: str             x2, [THR, #0x60]  ; THR::top
    //     0x71af40: sub             x2, x2, #0xf
    //     0x71af44: mov             x3, #0xd108
    //     0x71af48: movk            x3, #3, lsl #16
    //     0x71af4c: stur            x3, [x2, #-1]
    // 0x71af50: StoreField: r2->field_7 = d1
    //     0x71af50: stur            d1, [x2, #7]
    // 0x71af54: stp             xzr, x0, [SP, #-0x10]!
    // 0x71af58: SaveReg r2
    //     0x71af58: str             x2, [SP, #-8]!
    // 0x71af5c: r0 = lerpDouble()
    //     0x71af5c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x71af60: add             SP, SP, #0x18
    // 0x71af64: cmp             w0, NULL
    // 0x71af68: b.eq            #0x71b000
    // 0x71af6c: LoadField: d0 = r0->field_7
    //     0x71af6c: ldur            d0, [x0, #7]
    // 0x71af70: ldur            x16, [fp, #-8]
    // 0x71af74: SaveReg r16
    //     0x71af74: str             x16, [SP, #-8]!
    // 0x71af78: SaveReg d0
    //     0x71af78: str             d0, [SP, #-8]!
    // 0x71af7c: r0 = deflate()
    //     0x71af7c: bl              #0x6705bc  ; [dart:ui] RRect::deflate
    // 0x71af80: add             SP, SP, #0x10
    // 0x71af84: stur            x0, [fp, #-8]
    // 0x71af88: r0 = Path()
    //     0x71af88: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x71af8c: stur            x0, [fp, #-0x10]
    // 0x71af90: SaveReg r0
    //     0x71af90: str             x0, [SP, #-8]!
    // 0x71af94: r0 = _constructor()
    //     0x71af94: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x71af98: add             SP, SP, #8
    // 0x71af9c: ldur            x16, [fp, #-0x10]
    // 0x71afa0: ldur            lr, [fp, #-8]
    // 0x71afa4: stp             lr, x16, [SP, #-0x10]!
    // 0x71afa8: r0 = addRRect()
    //     0x71afa8: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0x71afac: add             SP, SP, #0x10
    // 0x71afb0: ldur            x0, [fp, #-0x10]
    // 0x71afb4: LeaveFrame
    //     0x71afb4: mov             SP, fp
    //     0x71afb8: ldp             fp, lr, [SP], #0x10
    // 0x71afbc: ret
    //     0x71afbc: ret             
    // 0x71afc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71afc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71afc4: b               #0x71aea8
    // 0x71afc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71afc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x71afcc: stp             q0, q1, [SP, #-0x20]!
    // 0x71afd0: SaveReg r1
    //     0x71afd0: str             x1, [SP, #-8]!
    // 0x71afd4: r0 = AllocateDouble()
    //     0x71afd4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x71afd8: RestoreReg r1
    //     0x71afd8: ldr             x1, [SP], #8
    // 0x71afdc: ldp             q0, q1, [SP], #0x20
    // 0x71afe0: b               #0x71af28
    // 0x71afe4: SaveReg d1
    //     0x71afe4: str             q1, [SP, #-0x10]!
    // 0x71afe8: stp             x0, x1, [SP, #-0x10]!
    // 0x71afec: r0 = AllocateDouble()
    //     0x71afec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x71aff0: mov             x2, x0
    // 0x71aff4: ldp             x0, x1, [SP], #0x10
    // 0x71aff8: RestoreReg d1
    //     0x71aff8: ldr             q1, [SP], #0x10
    // 0x71affc: b               #0x71af50
    // 0x71b000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71b000: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xadb264, size: 0x2e4
    // 0xadb264: EnterFrame
    //     0xadb264: stp             fp, lr, [SP, #-0x10]!
    //     0xadb268: mov             fp, SP
    // 0xadb26c: AllocStack(0x10)
    //     0xadb26c: sub             SP, SP, #0x10
    // 0xadb270: d0 = 0.000000
    //     0xadb270: eor             v0.16b, v0.16b, v0.16b
    // 0xadb274: CheckStackOverflow
    //     0xadb274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadb278: cmp             SP, x16
    //     0xadb27c: b.ls            #0xadb4f0
    // 0xadb280: ldr             x0, [fp, #0x10]
    // 0xadb284: LoadField: d1 = r0->field_17
    //     0xadb284: ldur            d1, [x0, #0x17]
    // 0xadb288: stur            d1, [fp, #-0x10]
    // 0xadb28c: fcmp            d1, d0
    // 0xadb290: b.eq            #0xadb3fc
    // 0xadb294: r1 = Null
    //     0xadb294: mov             x1, NULL
    // 0xadb298: r2 = 18
    //     0xadb298: mov             x2, #0x12
    // 0xadb29c: r0 = AllocateArray()
    //     0xadb29c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb2a0: stur            x0, [fp, #-8]
    // 0xadb2a4: r17 = "RoundedRectangleBorder("
    //     0xadb2a4: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe38] "RoundedRectangleBorder("
    //     0xadb2a8: ldr             x17, [x17, #0xe38]
    // 0xadb2ac: StoreField: r0->field_f = r17
    //     0xadb2ac: stur            w17, [x0, #0xf]
    // 0xadb2b0: ldr             x3, [fp, #0x10]
    // 0xadb2b4: LoadField: r1 = r3->field_7
    //     0xadb2b4: ldur            w1, [x3, #7]
    // 0xadb2b8: DecompressPointer r1
    //     0xadb2b8: add             x1, x1, HEAP, lsl #32
    // 0xadb2bc: StoreField: r0->field_13 = r1
    //     0xadb2bc: stur            w1, [x0, #0x13]
    // 0xadb2c0: r17 = ", "
    //     0xadb2c0: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb2c4: StoreField: r0->field_17 = r17
    //     0xadb2c4: stur            w17, [x0, #0x17]
    // 0xadb2c8: LoadField: r1 = r3->field_b
    //     0xadb2c8: ldur            w1, [x3, #0xb]
    // 0xadb2cc: DecompressPointer r1
    //     0xadb2cc: add             x1, x1, HEAP, lsl #32
    // 0xadb2d0: StoreField: r0->field_1b = r1
    //     0xadb2d0: stur            w1, [x0, #0x1b]
    // 0xadb2d4: r17 = ", "
    //     0xadb2d4: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb2d8: StoreField: r0->field_1f = r17
    //     0xadb2d8: stur            w17, [x0, #0x1f]
    // 0xadb2dc: LoadField: d0 = r3->field_f
    //     0xadb2dc: ldur            d0, [x3, #0xf]
    // 0xadb2e0: d1 = 100.000000
    //     0xadb2e0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb2e4: ldr             d1, [x17, #0x308]
    // 0xadb2e8: fmul            d2, d0, d1
    // 0xadb2ec: r1 = inline_Allocate_Double()
    //     0xadb2ec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xadb2f0: add             x1, x1, #0x10
    //     0xadb2f4: cmp             x2, x1
    //     0xadb2f8: b.ls            #0xadb4f8
    //     0xadb2fc: str             x1, [THR, #0x60]  ; THR::top
    //     0xadb300: sub             x1, x1, #0xf
    //     0xadb304: mov             x2, #0xd108
    //     0xadb308: movk            x2, #3, lsl #16
    //     0xadb30c: stur            x2, [x1, #-1]
    // 0xadb310: StoreField: r1->field_7 = d2
    //     0xadb310: stur            d2, [x1, #7]
    // 0xadb314: SaveReg r1
    //     0xadb314: str             x1, [SP, #-8]!
    // 0xadb318: r1 = 1
    //     0xadb318: mov             x1, #1
    // 0xadb31c: SaveReg r1
    //     0xadb31c: str             x1, [SP, #-8]!
    // 0xadb320: r0 = toStringAsFixed()
    //     0xadb320: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadb324: add             SP, SP, #0x10
    // 0xadb328: ldur            x1, [fp, #-8]
    // 0xadb32c: ArrayStore: r1[5] = r0  ; List_4
    //     0xadb32c: add             x25, x1, #0x23
    //     0xadb330: str             w0, [x25]
    //     0xadb334: tbz             w0, #0, #0xadb350
    //     0xadb338: ldurb           w16, [x1, #-1]
    //     0xadb33c: ldurb           w17, [x0, #-1]
    //     0xadb340: and             x16, x17, x16, lsr #2
    //     0xadb344: tst             x16, HEAP, lsr #32
    //     0xadb348: b.eq            #0xadb350
    //     0xadb34c: bl              #0xd67e5c
    // 0xadb350: ldur            x1, [fp, #-8]
    // 0xadb354: r17 = "% of the way to being a CircleBorder that is "
    //     0xadb354: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe08] "% of the way to being a CircleBorder that is "
    //     0xadb358: ldr             x17, [x17, #0xe08]
    // 0xadb35c: StoreField: r1->field_27 = r17
    //     0xadb35c: stur            w17, [x1, #0x27]
    // 0xadb360: ldur            d1, [fp, #-0x10]
    // 0xadb364: d0 = 100.000000
    //     0xadb364: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb368: ldr             d0, [x17, #0x308]
    // 0xadb36c: fmul            d2, d1, d0
    // 0xadb370: r0 = inline_Allocate_Double()
    //     0xadb370: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xadb374: add             x0, x0, #0x10
    //     0xadb378: cmp             x2, x0
    //     0xadb37c: b.ls            #0xadb514
    //     0xadb380: str             x0, [THR, #0x60]  ; THR::top
    //     0xadb384: sub             x0, x0, #0xf
    //     0xadb388: mov             x2, #0xd108
    //     0xadb38c: movk            x2, #3, lsl #16
    //     0xadb390: stur            x2, [x0, #-1]
    // 0xadb394: StoreField: r0->field_7 = d2
    //     0xadb394: stur            d2, [x0, #7]
    // 0xadb398: SaveReg r0
    //     0xadb398: str             x0, [SP, #-8]!
    // 0xadb39c: r0 = 1
    //     0xadb39c: mov             x0, #1
    // 0xadb3a0: SaveReg r0
    //     0xadb3a0: str             x0, [SP, #-8]!
    // 0xadb3a4: r0 = toStringAsFixed()
    //     0xadb3a4: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadb3a8: add             SP, SP, #0x10
    // 0xadb3ac: ldur            x1, [fp, #-8]
    // 0xadb3b0: ArrayStore: r1[7] = r0  ; List_4
    //     0xadb3b0: add             x25, x1, #0x2b
    //     0xadb3b4: str             w0, [x25]
    //     0xadb3b8: tbz             w0, #0, #0xadb3d4
    //     0xadb3bc: ldurb           w16, [x1, #-1]
    //     0xadb3c0: ldurb           w17, [x0, #-1]
    //     0xadb3c4: and             x16, x17, x16, lsr #2
    //     0xadb3c8: tst             x16, HEAP, lsr #32
    //     0xadb3cc: b.eq            #0xadb3d4
    //     0xadb3d0: bl              #0xd67e5c
    // 0xadb3d4: ldur            x0, [fp, #-8]
    // 0xadb3d8: r17 = "% oval)"
    //     0xadb3d8: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe10] "% oval)"
    //     0xadb3dc: ldr             x17, [x17, #0xe10]
    // 0xadb3e0: StoreField: r0->field_2f = r17
    //     0xadb3e0: stur            w17, [x0, #0x2f]
    // 0xadb3e4: SaveReg r0
    //     0xadb3e4: str             x0, [SP, #-8]!
    // 0xadb3e8: r0 = _interpolate()
    //     0xadb3e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb3ec: add             SP, SP, #8
    // 0xadb3f0: LeaveFrame
    //     0xadb3f0: mov             SP, fp
    //     0xadb3f4: ldp             fp, lr, [SP], #0x10
    // 0xadb3f8: ret
    //     0xadb3f8: ret             
    // 0xadb3fc: mov             x3, x0
    // 0xadb400: d0 = 100.000000
    //     0xadb400: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb404: ldr             d0, [x17, #0x308]
    // 0xadb408: r0 = 1
    //     0xadb408: mov             x0, #1
    // 0xadb40c: r1 = Null
    //     0xadb40c: mov             x1, NULL
    // 0xadb410: r2 = 14
    //     0xadb410: mov             x2, #0xe
    // 0xadb414: r0 = AllocateArray()
    //     0xadb414: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb418: stur            x0, [fp, #-8]
    // 0xadb41c: r17 = "RoundedRectangleBorder("
    //     0xadb41c: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe38] "RoundedRectangleBorder("
    //     0xadb420: ldr             x17, [x17, #0xe38]
    // 0xadb424: StoreField: r0->field_f = r17
    //     0xadb424: stur            w17, [x0, #0xf]
    // 0xadb428: ldr             x1, [fp, #0x10]
    // 0xadb42c: LoadField: r2 = r1->field_7
    //     0xadb42c: ldur            w2, [x1, #7]
    // 0xadb430: DecompressPointer r2
    //     0xadb430: add             x2, x2, HEAP, lsl #32
    // 0xadb434: StoreField: r0->field_13 = r2
    //     0xadb434: stur            w2, [x0, #0x13]
    // 0xadb438: r17 = ", "
    //     0xadb438: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb43c: StoreField: r0->field_17 = r17
    //     0xadb43c: stur            w17, [x0, #0x17]
    // 0xadb440: LoadField: r2 = r1->field_b
    //     0xadb440: ldur            w2, [x1, #0xb]
    // 0xadb444: DecompressPointer r2
    //     0xadb444: add             x2, x2, HEAP, lsl #32
    // 0xadb448: StoreField: r0->field_1b = r2
    //     0xadb448: stur            w2, [x0, #0x1b]
    // 0xadb44c: r17 = ", "
    //     0xadb44c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb450: StoreField: r0->field_1f = r17
    //     0xadb450: stur            w17, [x0, #0x1f]
    // 0xadb454: LoadField: d0 = r1->field_f
    //     0xadb454: ldur            d0, [x1, #0xf]
    // 0xadb458: d1 = 100.000000
    //     0xadb458: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xadb45c: ldr             d1, [x17, #0x308]
    // 0xadb460: fmul            d2, d0, d1
    // 0xadb464: r1 = inline_Allocate_Double()
    //     0xadb464: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xadb468: add             x1, x1, #0x10
    //     0xadb46c: cmp             x2, x1
    //     0xadb470: b.ls            #0xadb52c
    //     0xadb474: str             x1, [THR, #0x60]  ; THR::top
    //     0xadb478: sub             x1, x1, #0xf
    //     0xadb47c: mov             x2, #0xd108
    //     0xadb480: movk            x2, #3, lsl #16
    //     0xadb484: stur            x2, [x1, #-1]
    // 0xadb488: StoreField: r1->field_7 = d2
    //     0xadb488: stur            d2, [x1, #7]
    // 0xadb48c: SaveReg r1
    //     0xadb48c: str             x1, [SP, #-8]!
    // 0xadb490: r1 = 1
    //     0xadb490: mov             x1, #1
    // 0xadb494: SaveReg r1
    //     0xadb494: str             x1, [SP, #-8]!
    // 0xadb498: r0 = toStringAsFixed()
    //     0xadb498: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xadb49c: add             SP, SP, #0x10
    // 0xadb4a0: ldur            x1, [fp, #-8]
    // 0xadb4a4: ArrayStore: r1[5] = r0  ; List_4
    //     0xadb4a4: add             x25, x1, #0x23
    //     0xadb4a8: str             w0, [x25]
    //     0xadb4ac: tbz             w0, #0, #0xadb4c8
    //     0xadb4b0: ldurb           w16, [x1, #-1]
    //     0xadb4b4: ldurb           w17, [x0, #-1]
    //     0xadb4b8: and             x16, x17, x16, lsr #2
    //     0xadb4bc: tst             x16, HEAP, lsr #32
    //     0xadb4c0: b.eq            #0xadb4c8
    //     0xadb4c4: bl              #0xd67e5c
    // 0xadb4c8: ldur            x0, [fp, #-8]
    // 0xadb4cc: r17 = "% of the way to being a CircleBorder)"
    //     0xadb4cc: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fe18] "% of the way to being a CircleBorder)"
    //     0xadb4d0: ldr             x17, [x17, #0xe18]
    // 0xadb4d4: StoreField: r0->field_27 = r17
    //     0xadb4d4: stur            w17, [x0, #0x27]
    // 0xadb4d8: SaveReg r0
    //     0xadb4d8: str             x0, [SP, #-8]!
    // 0xadb4dc: r0 = _interpolate()
    //     0xadb4dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb4e0: add             SP, SP, #8
    // 0xadb4e4: LeaveFrame
    //     0xadb4e4: mov             SP, fp
    //     0xadb4e8: ldp             fp, lr, [SP], #0x10
    // 0xadb4ec: ret
    //     0xadb4ec: ret             
    // 0xadb4f0: r0 = StackOverflowSharedWithFPURegs()
    //     0xadb4f0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xadb4f4: b               #0xadb280
    // 0xadb4f8: stp             q1, q2, [SP, #-0x20]!
    // 0xadb4fc: SaveReg r0
    //     0xadb4fc: str             x0, [SP, #-8]!
    // 0xadb500: r0 = AllocateDouble()
    //     0xadb500: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadb504: mov             x1, x0
    // 0xadb508: RestoreReg r0
    //     0xadb508: ldr             x0, [SP], #8
    // 0xadb50c: ldp             q1, q2, [SP], #0x20
    // 0xadb510: b               #0xadb310
    // 0xadb514: SaveReg d2
    //     0xadb514: str             q2, [SP, #-0x10]!
    // 0xadb518: SaveReg r1
    //     0xadb518: str             x1, [SP, #-8]!
    // 0xadb51c: r0 = AllocateDouble()
    //     0xadb51c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadb520: RestoreReg r1
    //     0xadb520: ldr             x1, [SP], #8
    // 0xadb524: RestoreReg d2
    //     0xadb524: ldr             q2, [SP], #0x10
    // 0xadb528: b               #0xadb394
    // 0xadb52c: SaveReg d2
    //     0xadb52c: str             q2, [SP, #-0x10]!
    // 0xadb530: SaveReg r0
    //     0xadb530: str             x0, [SP, #-8]!
    // 0xadb534: r0 = AllocateDouble()
    //     0xadb534: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadb538: mov             x1, x0
    // 0xadb53c: RestoreReg r0
    //     0xadb53c: ldr             x0, [SP], #8
    // 0xadb540: RestoreReg d2
    //     0xadb540: ldr             q2, [SP], #0x10
    // 0xadb544: b               #0xadb488
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd41e8, size: 0x158
    // 0xbd41e8: EnterFrame
    //     0xbd41e8: stp             fp, lr, [SP, #-0x10]!
    //     0xbd41ec: mov             fp, SP
    // 0xbd41f0: AllocStack(0x28)
    //     0xbd41f0: sub             SP, SP, #0x28
    // 0xbd41f4: SetupParameters(_RoundedRectangleToCircleBorder this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, dynamic _ /* r5, fp-0x10 */, {dynamic textDirection = Null /* r0 */})
    //     0xbd41f4: mov             x0, x4
    //     0xbd41f8: ldur            w1, [x0, #0x13]
    //     0xbd41fc: add             x1, x1, HEAP, lsl #32
    //     0xbd4200: sub             x2, x1, #6
    //     0xbd4204: add             x3, fp, w2, sxtw #2
    //     0xbd4208: ldr             x3, [x3, #0x20]
    //     0xbd420c: stur            x3, [fp, #-0x20]
    //     0xbd4210: add             x4, fp, w2, sxtw #2
    //     0xbd4214: ldr             x4, [x4, #0x18]
    //     0xbd4218: stur            x4, [fp, #-0x18]
    //     0xbd421c: add             x5, fp, w2, sxtw #2
    //     0xbd4220: ldr             x5, [x5, #0x10]
    //     0xbd4224: stur            x5, [fp, #-0x10]
    //     0xbd4228: ldur            w2, [x0, #0x1f]
    //     0xbd422c: add             x2, x2, HEAP, lsl #32
    //     0xbd4230: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0xbd4234: ldr             x16, [x16, #0xf10]
    //     0xbd4238: cmp             w2, w16
    //     0xbd423c: b.ne            #0xbd425c
    //     0xbd4240: ldur            w2, [x0, #0x23]
    //     0xbd4244: add             x2, x2, HEAP, lsl #32
    //     0xbd4248: sub             w0, w1, w2
    //     0xbd424c: add             x1, fp, w0, sxtw #2
    //     0xbd4250: ldr             x1, [x1, #8]
    //     0xbd4254: mov             x0, x1
    //     0xbd4258: b               #0xbd4260
    //     0xbd425c: mov             x0, NULL
    // 0xbd4260: CheckStackOverflow
    //     0xbd4260: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd4264: cmp             SP, x16
    //     0xbd4268: b.ls            #0xbd4334
    // 0xbd426c: LoadField: r1 = r3->field_7
    //     0xbd426c: ldur            w1, [x3, #7]
    // 0xbd4270: DecompressPointer r1
    //     0xbd4270: add             x1, x1, HEAP, lsl #32
    // 0xbd4274: stur            x1, [fp, #-8]
    // 0xbd4278: LoadField: r2 = r1->field_13
    //     0xbd4278: ldur            w2, [x1, #0x13]
    // 0xbd427c: DecompressPointer r2
    //     0xbd427c: add             x2, x2, HEAP, lsl #32
    // 0xbd4280: LoadField: r6 = r2->field_7
    //     0xbd4280: ldur            x6, [x2, #7]
    // 0xbd4284: cmp             x6, #0
    // 0xbd4288: b.le            #0xbd4324
    // 0xbd428c: stp             x5, x3, [SP, #-0x10]!
    // 0xbd4290: SaveReg r0
    //     0xbd4290: str             x0, [SP, #-8]!
    // 0xbd4294: r0 = _adjustBorderRadius()
    //     0xbd4294: bl              #0x7182e4  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustBorderRadius
    // 0xbd4298: add             SP, SP, #0x18
    // 0xbd429c: stur            x0, [fp, #-0x28]
    // 0xbd42a0: cmp             w0, NULL
    // 0xbd42a4: b.eq            #0xbd433c
    // 0xbd42a8: ldur            x16, [fp, #-0x20]
    // 0xbd42ac: ldur            lr, [fp, #-0x10]
    // 0xbd42b0: stp             lr, x16, [SP, #-0x10]!
    // 0xbd42b4: r0 = _adjustRect()
    //     0xbd42b4: bl              #0x718198  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustRect
    // 0xbd42b8: add             SP, SP, #0x10
    // 0xbd42bc: ldur            x16, [fp, #-0x28]
    // 0xbd42c0: stp             x0, x16, [SP, #-0x10]!
    // 0xbd42c4: r0 = toRRect()
    //     0xbd42c4: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbd42c8: add             SP, SP, #0x10
    // 0xbd42cc: mov             x1, x0
    // 0xbd42d0: ldur            x0, [fp, #-8]
    // 0xbd42d4: LoadField: d0 = r0->field_b
    //     0xbd42d4: ldur            d0, [x0, #0xb]
    // 0xbd42d8: LoadField: d1 = r0->field_17
    //     0xbd42d8: ldur            d1, [x0, #0x17]
    // 0xbd42dc: fmul            d2, d0, d1
    // 0xbd42e0: d0 = 2.000000
    //     0xbd42e0: fmov            d0, #2.00000000
    // 0xbd42e4: fdiv            d1, d2, d0
    // 0xbd42e8: SaveReg r1
    //     0xbd42e8: str             x1, [SP, #-8]!
    // 0xbd42ec: SaveReg d1
    //     0xbd42ec: str             d1, [SP, #-8]!
    // 0xbd42f0: r0 = inflate()
    //     0xbd42f0: bl              #0x65ffe4  ; [dart:ui] RRect::inflate
    // 0xbd42f4: add             SP, SP, #0x10
    // 0xbd42f8: stur            x0, [fp, #-0x10]
    // 0xbd42fc: ldur            x16, [fp, #-8]
    // 0xbd4300: SaveReg r16
    //     0xbd4300: str             x16, [SP, #-8]!
    // 0xbd4304: r0 = toPaint()
    //     0xbd4304: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd4308: add             SP, SP, #8
    // 0xbd430c: ldur            x16, [fp, #-0x18]
    // 0xbd4310: ldur            lr, [fp, #-0x10]
    // 0xbd4314: stp             lr, x16, [SP, #-0x10]!
    // 0xbd4318: SaveReg r0
    //     0xbd4318: str             x0, [SP, #-8]!
    // 0xbd431c: r0 = drawRRect()
    //     0xbd431c: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xbd4320: add             SP, SP, #0x18
    // 0xbd4324: r0 = Null
    //     0xbd4324: mov             x0, NULL
    // 0xbd4328: LeaveFrame
    //     0xbd4328: mov             SP, fp
    //     0xbd432c: ldp             fp, lr, [SP], #0x10
    // 0xbd4330: ret
    //     0xbd4330: ret             
    // 0xbd4334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd4334: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd4338: b               #0xbd426c
    // 0xbd433c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd433c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc99b5c, size: 0x14c
    // 0xc99b5c: EnterFrame
    //     0xc99b5c: stp             fp, lr, [SP, #-0x10]!
    //     0xc99b60: mov             fp, SP
    // 0xc99b64: CheckStackOverflow
    //     0xc99b64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc99b68: cmp             SP, x16
    //     0xc99b6c: b.ls            #0xc99ca0
    // 0xc99b70: ldr             x1, [fp, #0x10]
    // 0xc99b74: cmp             w1, NULL
    // 0xc99b78: b.ne            #0xc99b8c
    // 0xc99b7c: r0 = false
    //     0xc99b7c: add             x0, NULL, #0x30  ; false
    // 0xc99b80: LeaveFrame
    //     0xc99b80: mov             SP, fp
    //     0xc99b84: ldp             fp, lr, [SP], #0x10
    // 0xc99b88: ret
    //     0xc99b88: ret             
    // 0xc99b8c: r0 = 59
    //     0xc99b8c: mov             x0, #0x3b
    // 0xc99b90: branchIfSmi(r1, 0xc99b9c)
    //     0xc99b90: tbz             w1, #0, #0xc99b9c
    // 0xc99b94: r0 = LoadClassIdInstr(r1)
    //     0xc99b94: ldur            x0, [x1, #-1]
    //     0xc99b98: ubfx            x0, x0, #0xc, #0x14
    // 0xc99b9c: SaveReg r1
    //     0xc99b9c: str             x1, [SP, #-8]!
    // 0xc99ba0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc99ba0: mov             x17, #0x57c5
    //     0xc99ba4: add             lr, x0, x17
    //     0xc99ba8: ldr             lr, [x21, lr, lsl #3]
    //     0xc99bac: blr             lr
    // 0xc99bb0: add             SP, SP, #8
    // 0xc99bb4: r1 = LoadClassIdInstr(r0)
    //     0xc99bb4: ldur            x1, [x0, #-1]
    //     0xc99bb8: ubfx            x1, x1, #0xc, #0x14
    // 0xc99bbc: r16 = _RoundedRectangleToCircleBorder
    //     0xc99bbc: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3fe40] Type: _RoundedRectangleToCircleBorder
    //     0xc99bc0: ldr             x16, [x16, #0xe40]
    // 0xc99bc4: stp             x16, x0, [SP, #-0x10]!
    // 0xc99bc8: mov             x0, x1
    // 0xc99bcc: mov             lr, x0
    // 0xc99bd0: ldr             lr, [x21, lr, lsl #3]
    // 0xc99bd4: blr             lr
    // 0xc99bd8: add             SP, SP, #0x10
    // 0xc99bdc: tbz             w0, #4, #0xc99bf0
    // 0xc99be0: r0 = false
    //     0xc99be0: add             x0, NULL, #0x30  ; false
    // 0xc99be4: LeaveFrame
    //     0xc99be4: mov             SP, fp
    //     0xc99be8: ldp             fp, lr, [SP], #0x10
    // 0xc99bec: ret
    //     0xc99bec: ret             
    // 0xc99bf0: ldr             x0, [fp, #0x10]
    // 0xc99bf4: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc99bf4: mov             x1, #0x76
    //     0xc99bf8: tbz             w0, #0, #0xc99c08
    //     0xc99bfc: ldur            x1, [x0, #-1]
    //     0xc99c00: ubfx            x1, x1, #0xc, #0x14
    //     0xc99c04: lsl             x1, x1, #1
    // 0xc99c08: r17 = 4356
    //     0xc99c08: mov             x17, #0x1104
    // 0xc99c0c: cmp             w1, w17
    // 0xc99c10: b.ne            #0xc99c90
    // 0xc99c14: ldr             x1, [fp, #0x18]
    // 0xc99c18: LoadField: r2 = r0->field_7
    //     0xc99c18: ldur            w2, [x0, #7]
    // 0xc99c1c: DecompressPointer r2
    //     0xc99c1c: add             x2, x2, HEAP, lsl #32
    // 0xc99c20: LoadField: r3 = r1->field_7
    //     0xc99c20: ldur            w3, [x1, #7]
    // 0xc99c24: DecompressPointer r3
    //     0xc99c24: add             x3, x3, HEAP, lsl #32
    // 0xc99c28: stp             x3, x2, [SP, #-0x10]!
    // 0xc99c2c: r0 = ==()
    //     0xc99c2c: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc99c30: add             SP, SP, #0x10
    // 0xc99c34: tbnz            w0, #4, #0xc99c90
    // 0xc99c38: ldr             x1, [fp, #0x18]
    // 0xc99c3c: ldr             x0, [fp, #0x10]
    // 0xc99c40: LoadField: r2 = r0->field_b
    //     0xc99c40: ldur            w2, [x0, #0xb]
    // 0xc99c44: DecompressPointer r2
    //     0xc99c44: add             x2, x2, HEAP, lsl #32
    // 0xc99c48: LoadField: r3 = r1->field_b
    //     0xc99c48: ldur            w3, [x1, #0xb]
    // 0xc99c4c: DecompressPointer r3
    //     0xc99c4c: add             x3, x3, HEAP, lsl #32
    // 0xc99c50: stp             x3, x2, [SP, #-0x10]!
    // 0xc99c54: r0 = ==()
    //     0xc99c54: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xc99c58: add             SP, SP, #0x10
    // 0xc99c5c: tbnz            w0, #4, #0xc99c90
    // 0xc99c60: ldr             x2, [fp, #0x18]
    // 0xc99c64: ldr             x1, [fp, #0x10]
    // 0xc99c68: LoadField: d0 = r1->field_f
    //     0xc99c68: ldur            d0, [x1, #0xf]
    // 0xc99c6c: LoadField: d1 = r2->field_f
    //     0xc99c6c: ldur            d1, [x2, #0xf]
    // 0xc99c70: fcmp            d0, d1
    // 0xc99c74: b.vs            #0xc99c7c
    // 0xc99c78: b.eq            #0xc99c84
    // 0xc99c7c: r1 = false
    //     0xc99c7c: add             x1, NULL, #0x30  ; false
    // 0xc99c80: b               #0xc99c88
    // 0xc99c84: r1 = true
    //     0xc99c84: add             x1, NULL, #0x20  ; true
    // 0xc99c88: mov             x0, x1
    // 0xc99c8c: b               #0xc99c94
    // 0xc99c90: r0 = false
    //     0xc99c90: add             x0, NULL, #0x30  ; false
    // 0xc99c94: LeaveFrame
    //     0xc99c94: mov             SP, fp
    //     0xc99c98: ldp             fp, lr, [SP], #0x10
    // 0xc99c9c: ret
    //     0xc99c9c: ret             
    // 0xc99ca0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc99ca0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc99ca4: b               #0xc99b70
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf87a4, size: 0x230
    // 0xcf87a4: EnterFrame
    //     0xcf87a4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf87a8: mov             fp, SP
    // 0xcf87ac: AllocStack(0x38)
    //     0xcf87ac: sub             SP, SP, #0x38
    // 0xcf87b0: CheckStackOverflow
    //     0xcf87b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf87b4: cmp             SP, x16
    //     0xcf87b8: b.ls            #0xcf898c
    // 0xcf87bc: ldr             x0, [fp, #0x18]
    // 0xcf87c0: LoadField: r1 = r0->field_7
    //     0xcf87c0: ldur            w1, [x0, #7]
    // 0xcf87c4: DecompressPointer r1
    //     0xcf87c4: add             x1, x1, HEAP, lsl #32
    // 0xcf87c8: SaveReg r1
    //     0xcf87c8: str             x1, [SP, #-8]!
    // 0xcf87cc: ldr             d0, [fp, #0x10]
    // 0xcf87d0: SaveReg d0
    //     0xcf87d0: str             d0, [SP, #-8]!
    // 0xcf87d4: r0 = scale()
    //     0xcf87d4: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf87d8: add             SP, SP, #0x10
    // 0xcf87dc: mov             x1, x0
    // 0xcf87e0: ldr             x0, [fp, #0x18]
    // 0xcf87e4: stur            x1, [fp, #-0x18]
    // 0xcf87e8: LoadField: r2 = r0->field_b
    //     0xcf87e8: ldur            w2, [x0, #0xb]
    // 0xcf87ec: DecompressPointer r2
    //     0xcf87ec: add             x2, x2, HEAP, lsl #32
    // 0xcf87f0: stur            x2, [fp, #-0x10]
    // 0xcf87f4: r3 = LoadClassIdInstr(r2)
    //     0xcf87f4: ldur            x3, [x2, #-1]
    //     0xcf87f8: ubfx            x3, x3, #0xc, #0x14
    // 0xcf87fc: lsl             x3, x3, #1
    // 0xcf8800: r17 = 4224
    //     0xcf8800: mov             x17, #0x1080
    // 0xcf8804: cmp             w3, w17
    // 0xcf8808: b.ne            #0xcf88f0
    // 0xcf880c: ldr             d0, [fp, #0x10]
    // 0xcf8810: LoadField: r3 = r2->field_7
    //     0xcf8810: ldur            w3, [x2, #7]
    // 0xcf8814: DecompressPointer r3
    //     0xcf8814: add             x3, x3, HEAP, lsl #32
    // 0xcf8818: r4 = inline_Allocate_Double()
    //     0xcf8818: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xcf881c: add             x4, x4, #0x10
    //     0xcf8820: cmp             x5, x4
    //     0xcf8824: b.ls            #0xcf8994
    //     0xcf8828: str             x4, [THR, #0x60]  ; THR::top
    //     0xcf882c: sub             x4, x4, #0xf
    //     0xcf8830: mov             x5, #0xd108
    //     0xcf8834: movk            x5, #3, lsl #16
    //     0xcf8838: stur            x5, [x4, #-1]
    // 0xcf883c: StoreField: r4->field_7 = d0
    //     0xcf883c: stur            d0, [x4, #7]
    // 0xcf8840: stur            x4, [fp, #-8]
    // 0xcf8844: stp             x4, x3, [SP, #-0x10]!
    // 0xcf8848: r0 = *()
    //     0xcf8848: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf884c: add             SP, SP, #0x10
    // 0xcf8850: mov             x1, x0
    // 0xcf8854: ldur            x0, [fp, #-0x10]
    // 0xcf8858: stur            x1, [fp, #-0x20]
    // 0xcf885c: LoadField: r2 = r0->field_b
    //     0xcf885c: ldur            w2, [x0, #0xb]
    // 0xcf8860: DecompressPointer r2
    //     0xcf8860: add             x2, x2, HEAP, lsl #32
    // 0xcf8864: ldur            x16, [fp, #-8]
    // 0xcf8868: stp             x16, x2, [SP, #-0x10]!
    // 0xcf886c: r0 = *()
    //     0xcf886c: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8870: add             SP, SP, #0x10
    // 0xcf8874: mov             x1, x0
    // 0xcf8878: ldur            x0, [fp, #-0x10]
    // 0xcf887c: stur            x1, [fp, #-0x28]
    // 0xcf8880: LoadField: r2 = r0->field_f
    //     0xcf8880: ldur            w2, [x0, #0xf]
    // 0xcf8884: DecompressPointer r2
    //     0xcf8884: add             x2, x2, HEAP, lsl #32
    // 0xcf8888: ldur            x16, [fp, #-8]
    // 0xcf888c: stp             x16, x2, [SP, #-0x10]!
    // 0xcf8890: r0 = *()
    //     0xcf8890: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8894: add             SP, SP, #0x10
    // 0xcf8898: mov             x1, x0
    // 0xcf889c: ldur            x0, [fp, #-0x10]
    // 0xcf88a0: stur            x1, [fp, #-0x30]
    // 0xcf88a4: LoadField: r2 = r0->field_13
    //     0xcf88a4: ldur            w2, [x0, #0x13]
    // 0xcf88a8: DecompressPointer r2
    //     0xcf88a8: add             x2, x2, HEAP, lsl #32
    // 0xcf88ac: ldur            x16, [fp, #-8]
    // 0xcf88b0: stp             x16, x2, [SP, #-0x10]!
    // 0xcf88b4: r0 = *()
    //     0xcf88b4: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf88b8: add             SP, SP, #0x10
    // 0xcf88bc: stur            x0, [fp, #-8]
    // 0xcf88c0: r0 = BorderRadius()
    //     0xcf88c0: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xcf88c4: mov             x1, x0
    // 0xcf88c8: ldur            x0, [fp, #-0x20]
    // 0xcf88cc: StoreField: r1->field_7 = r0
    //     0xcf88cc: stur            w0, [x1, #7]
    // 0xcf88d0: ldur            x0, [fp, #-0x28]
    // 0xcf88d4: StoreField: r1->field_b = r0
    //     0xcf88d4: stur            w0, [x1, #0xb]
    // 0xcf88d8: ldur            x0, [fp, #-0x30]
    // 0xcf88dc: StoreField: r1->field_f = r0
    //     0xcf88dc: stur            w0, [x1, #0xf]
    // 0xcf88e0: ldur            x0, [fp, #-8]
    // 0xcf88e4: StoreField: r1->field_13 = r0
    //     0xcf88e4: stur            w0, [x1, #0x13]
    // 0xcf88e8: mov             x2, x1
    // 0xcf88ec: b               #0xcf8944
    // 0xcf88f0: ldr             d0, [fp, #0x10]
    // 0xcf88f4: mov             x0, x2
    // 0xcf88f8: r1 = inline_Allocate_Double()
    //     0xcf88f8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcf88fc: add             x1, x1, #0x10
    //     0xcf8900: cmp             x2, x1
    //     0xcf8904: b.ls            #0xcf89b8
    //     0xcf8908: str             x1, [THR, #0x60]  ; THR::top
    //     0xcf890c: sub             x1, x1, #0xf
    //     0xcf8910: mov             x2, #0xd108
    //     0xcf8914: movk            x2, #3, lsl #16
    //     0xcf8918: stur            x2, [x1, #-1]
    // 0xcf891c: StoreField: r1->field_7 = d0
    //     0xcf891c: stur            d0, [x1, #7]
    // 0xcf8920: r2 = LoadClassIdInstr(r0)
    //     0xcf8920: ldur            x2, [x0, #-1]
    //     0xcf8924: ubfx            x2, x2, #0xc, #0x14
    // 0xcf8928: stp             x1, x0, [SP, #-0x10]!
    // 0xcf892c: mov             x0, x2
    // 0xcf8930: r0 = GDT[cid_x0 + -0xfd3]()
    //     0xcf8930: sub             lr, x0, #0xfd3
    //     0xcf8934: ldr             lr, [x21, lr, lsl #3]
    //     0xcf8938: blr             lr
    // 0xcf893c: add             SP, SP, #0x10
    // 0xcf8940: mov             x2, x0
    // 0xcf8944: ldr             x0, [fp, #0x18]
    // 0xcf8948: ldr             d0, [fp, #0x10]
    // 0xcf894c: ldur            x1, [fp, #-0x18]
    // 0xcf8950: stur            x2, [fp, #-8]
    // 0xcf8954: LoadField: d1 = r0->field_17
    //     0xcf8954: ldur            d1, [x0, #0x17]
    // 0xcf8958: stur            d1, [fp, #-0x38]
    // 0xcf895c: r0 = _RoundedRectangleToCircleBorder()
    //     0xcf895c: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0xcf8960: ldur            x1, [fp, #-8]
    // 0xcf8964: StoreField: r0->field_b = r1
    //     0xcf8964: stur            w1, [x0, #0xb]
    // 0xcf8968: ldr             d0, [fp, #0x10]
    // 0xcf896c: StoreField: r0->field_f = d0
    //     0xcf896c: stur            d0, [x0, #0xf]
    // 0xcf8970: ldur            d0, [fp, #-0x38]
    // 0xcf8974: StoreField: r0->field_17 = d0
    //     0xcf8974: stur            d0, [x0, #0x17]
    // 0xcf8978: ldur            x1, [fp, #-0x18]
    // 0xcf897c: StoreField: r0->field_7 = r1
    //     0xcf897c: stur            w1, [x0, #7]
    // 0xcf8980: LeaveFrame
    //     0xcf8980: mov             SP, fp
    //     0xcf8984: ldp             fp, lr, [SP], #0x10
    // 0xcf8988: ret
    //     0xcf8988: ret             
    // 0xcf898c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf898c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8990: b               #0xcf87bc
    // 0xcf8994: SaveReg d0
    //     0xcf8994: str             q0, [SP, #-0x10]!
    // 0xcf8998: stp             x2, x3, [SP, #-0x10]!
    // 0xcf899c: stp             x0, x1, [SP, #-0x10]!
    // 0xcf89a0: r0 = AllocateDouble()
    //     0xcf89a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf89a4: mov             x4, x0
    // 0xcf89a8: ldp             x0, x1, [SP], #0x10
    // 0xcf89ac: ldp             x2, x3, [SP], #0x10
    // 0xcf89b0: RestoreReg d0
    //     0xcf89b0: ldr             q0, [SP], #0x10
    // 0xcf89b4: b               #0xcf883c
    // 0xcf89b8: SaveReg d0
    //     0xcf89b8: str             q0, [SP, #-0x10]!
    // 0xcf89bc: SaveReg r0
    //     0xcf89bc: str             x0, [SP, #-8]!
    // 0xcf89c0: r0 = AllocateDouble()
    //     0xcf89c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf89c4: mov             x1, x0
    // 0xcf89c8: RestoreReg r0
    //     0xcf89c8: ldr             x0, [SP], #8
    // 0xcf89cc: RestoreReg d0
    //     0xcf89cc: ldr             q0, [SP], #0x10
    // 0xcf89d0: b               #0xcf891c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xcf8d78, size: 0x7c
    // 0xcf8d78: EnterFrame
    //     0xcf8d78: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8d7c: mov             fp, SP
    // 0xcf8d80: AllocStack(0x20)
    //     0xcf8d80: sub             SP, SP, #0x20
    // 0xcf8d84: ldr             x0, [fp, #0x10]
    // 0xcf8d88: cmp             w0, NULL
    // 0xcf8d8c: b.ne            #0xcf8da0
    // 0xcf8d90: ldr             x1, [fp, #0x18]
    // 0xcf8d94: LoadField: r0 = r1->field_7
    //     0xcf8d94: ldur            w0, [x1, #7]
    // 0xcf8d98: DecompressPointer r0
    //     0xcf8d98: add             x0, x0, HEAP, lsl #32
    // 0xcf8d9c: b               #0xcf8da4
    // 0xcf8da0: ldr             x1, [fp, #0x18]
    // 0xcf8da4: stur            x0, [fp, #-0x10]
    // 0xcf8da8: LoadField: r2 = r1->field_b
    //     0xcf8da8: ldur            w2, [x1, #0xb]
    // 0xcf8dac: DecompressPointer r2
    //     0xcf8dac: add             x2, x2, HEAP, lsl #32
    // 0xcf8db0: stur            x2, [fp, #-8]
    // 0xcf8db4: LoadField: d0 = r1->field_f
    //     0xcf8db4: ldur            d0, [x1, #0xf]
    // 0xcf8db8: stur            d0, [fp, #-0x20]
    // 0xcf8dbc: LoadField: d1 = r1->field_17
    //     0xcf8dbc: ldur            d1, [x1, #0x17]
    // 0xcf8dc0: stur            d1, [fp, #-0x18]
    // 0xcf8dc4: r0 = _RoundedRectangleToCircleBorder()
    //     0xcf8dc4: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0xcf8dc8: ldur            x1, [fp, #-8]
    // 0xcf8dcc: StoreField: r0->field_b = r1
    //     0xcf8dcc: stur            w1, [x0, #0xb]
    // 0xcf8dd0: ldur            d0, [fp, #-0x20]
    // 0xcf8dd4: StoreField: r0->field_f = d0
    //     0xcf8dd4: stur            d0, [x0, #0xf]
    // 0xcf8dd8: ldur            d0, [fp, #-0x18]
    // 0xcf8ddc: StoreField: r0->field_17 = d0
    //     0xcf8ddc: stur            d0, [x0, #0x17]
    // 0xcf8de0: ldur            x1, [fp, #-0x10]
    // 0xcf8de4: StoreField: r0->field_7 = r1
    //     0xcf8de4: stur            w1, [x0, #7]
    // 0xcf8de8: LeaveFrame
    //     0xcf8de8: mov             SP, fp
    //     0xcf8dec: ldp             fp, lr, [SP], #0x10
    // 0xcf8df0: ret
    //     0xcf8df0: ret             
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0xcfa4a4, size: 0x108
    // 0xcfa4a4: EnterFrame
    //     0xcfa4a4: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa4a8: mov             fp, SP
    // 0xcfa4ac: AllocStack(0x20)
    //     0xcfa4ac: sub             SP, SP, #0x20
    // 0xcfa4b0: SetupParameters(_RoundedRectangleToCircleBorder this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic textDirection = Null /* r0, fp-0x8 */})
    //     0xcfa4b0: mov             x0, x4
    //     0xcfa4b4: ldur            w1, [x0, #0x13]
    //     0xcfa4b8: add             x1, x1, HEAP, lsl #32
    //     0xcfa4bc: sub             x2, x1, #4
    //     0xcfa4c0: add             x3, fp, w2, sxtw #2
    //     0xcfa4c4: ldr             x3, [x3, #0x18]
    //     0xcfa4c8: stur            x3, [fp, #-0x18]
    //     0xcfa4cc: add             x4, fp, w2, sxtw #2
    //     0xcfa4d0: ldr             x4, [x4, #0x10]
    //     0xcfa4d4: stur            x4, [fp, #-0x10]
    //     0xcfa4d8: ldur            w2, [x0, #0x1f]
    //     0xcfa4dc: add             x2, x2, HEAP, lsl #32
    //     0xcfa4e0: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0xcfa4e4: ldr             x16, [x16, #0xf10]
    //     0xcfa4e8: cmp             w2, w16
    //     0xcfa4ec: b.ne            #0xcfa50c
    //     0xcfa4f0: ldur            w2, [x0, #0x23]
    //     0xcfa4f4: add             x2, x2, HEAP, lsl #32
    //     0xcfa4f8: sub             w0, w1, w2
    //     0xcfa4fc: add             x1, fp, w0, sxtw #2
    //     0xcfa500: ldr             x1, [x1, #8]
    //     0xcfa504: mov             x0, x1
    //     0xcfa508: b               #0xcfa510
    //     0xcfa50c: mov             x0, NULL
    //     0xcfa510: stur            x0, [fp, #-8]
    // 0xcfa514: CheckStackOverflow
    //     0xcfa514: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa518: cmp             SP, x16
    //     0xcfa51c: b.ls            #0xcfa5a0
    // 0xcfa520: r0 = Path()
    //     0xcfa520: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcfa524: stur            x0, [fp, #-0x20]
    // 0xcfa528: SaveReg r0
    //     0xcfa528: str             x0, [SP, #-8]!
    // 0xcfa52c: r0 = _constructor()
    //     0xcfa52c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcfa530: add             SP, SP, #8
    // 0xcfa534: ldur            x16, [fp, #-0x18]
    // 0xcfa538: ldur            lr, [fp, #-0x10]
    // 0xcfa53c: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa540: ldur            x16, [fp, #-8]
    // 0xcfa544: SaveReg r16
    //     0xcfa544: str             x16, [SP, #-8]!
    // 0xcfa548: r0 = _adjustBorderRadius()
    //     0xcfa548: bl              #0x7182e4  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustBorderRadius
    // 0xcfa54c: add             SP, SP, #0x18
    // 0xcfa550: stur            x0, [fp, #-8]
    // 0xcfa554: cmp             w0, NULL
    // 0xcfa558: b.eq            #0xcfa5a8
    // 0xcfa55c: ldur            x16, [fp, #-0x18]
    // 0xcfa560: ldur            lr, [fp, #-0x10]
    // 0xcfa564: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa568: r0 = _adjustRect()
    //     0xcfa568: bl              #0x718198  ; [package:flutter/src/painting/rounded_rectangle_border.dart] _RoundedRectangleToCircleBorder::_adjustRect
    // 0xcfa56c: add             SP, SP, #0x10
    // 0xcfa570: ldur            x16, [fp, #-8]
    // 0xcfa574: stp             x0, x16, [SP, #-0x10]!
    // 0xcfa578: r0 = toRRect()
    //     0xcfa578: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xcfa57c: add             SP, SP, #0x10
    // 0xcfa580: ldur            x16, [fp, #-0x20]
    // 0xcfa584: stp             x0, x16, [SP, #-0x10]!
    // 0xcfa588: r0 = addRRect()
    //     0xcfa588: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0xcfa58c: add             SP, SP, #0x10
    // 0xcfa590: ldur            x0, [fp, #-0x20]
    // 0xcfa594: LeaveFrame
    //     0xcfa594: mov             SP, fp
    //     0xcfa598: ldp             fp, lr, [SP], #0x10
    // 0xcfa59c: ret
    //     0xcfa59c: ret             
    // 0xcfa5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa5a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa5a4: b               #0xcfa520
    // 0xcfa5a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcfa5a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2179, size: 0x10, field offset: 0xc
//   const constructor, 
class RoundedRectangleBorder extends OutlinedBorder {

  BorderSide field_8;
  BorderRadius field_c;

  _ lerpTo(/* No info */) {
    // ** addr: 0x70e768, size: 0x180
    // 0x70e768: EnterFrame
    //     0x70e768: stp             fp, lr, [SP, #-0x10]!
    //     0x70e76c: mov             fp, SP
    // 0x70e770: AllocStack(0x18)
    //     0x70e770: sub             SP, SP, #0x18
    // 0x70e774: CheckStackOverflow
    //     0x70e774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70e778: cmp             SP, x16
    //     0x70e77c: b.ls            #0x70e8dc
    // 0x70e780: ldr             x0, [fp, #0x18]
    // 0x70e784: r1 = LoadClassIdInstr(r0)
    //     0x70e784: ldur            x1, [x0, #-1]
    //     0x70e788: ubfx            x1, x1, #0xc, #0x14
    // 0x70e78c: lsl             x1, x1, #1
    // 0x70e790: r17 = 4358
    //     0x70e790: mov             x17, #0x1106
    // 0x70e794: cmp             w1, w17
    // 0x70e798: b.ne            #0x70e82c
    // 0x70e79c: ldr             x1, [fp, #0x20]
    // 0x70e7a0: ldr             d0, [fp, #0x10]
    // 0x70e7a4: LoadField: r2 = r1->field_7
    //     0x70e7a4: ldur            w2, [x1, #7]
    // 0x70e7a8: DecompressPointer r2
    //     0x70e7a8: add             x2, x2, HEAP, lsl #32
    // 0x70e7ac: LoadField: r3 = r0->field_7
    //     0x70e7ac: ldur            w3, [x0, #7]
    // 0x70e7b0: DecompressPointer r3
    //     0x70e7b0: add             x3, x3, HEAP, lsl #32
    // 0x70e7b4: stp             x3, x2, [SP, #-0x10]!
    // 0x70e7b8: SaveReg d0
    //     0x70e7b8: str             d0, [SP, #-8]!
    // 0x70e7bc: r0 = lerp()
    //     0x70e7bc: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70e7c0: add             SP, SP, #0x18
    // 0x70e7c4: mov             x1, x0
    // 0x70e7c8: ldr             x0, [fp, #0x20]
    // 0x70e7cc: stur            x1, [fp, #-8]
    // 0x70e7d0: LoadField: r2 = r0->field_b
    //     0x70e7d0: ldur            w2, [x0, #0xb]
    // 0x70e7d4: DecompressPointer r2
    //     0x70e7d4: add             x2, x2, HEAP, lsl #32
    // 0x70e7d8: ldr             x3, [fp, #0x18]
    // 0x70e7dc: LoadField: r0 = r3->field_b
    //     0x70e7dc: ldur            w0, [x3, #0xb]
    // 0x70e7e0: DecompressPointer r0
    //     0x70e7e0: add             x0, x0, HEAP, lsl #32
    // 0x70e7e4: stp             x0, x2, [SP, #-0x10]!
    // 0x70e7e8: ldr             d0, [fp, #0x10]
    // 0x70e7ec: SaveReg d0
    //     0x70e7ec: str             d0, [SP, #-8]!
    // 0x70e7f0: r0 = lerp()
    //     0x70e7f0: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x70e7f4: add             SP, SP, #0x18
    // 0x70e7f8: stur            x0, [fp, #-0x10]
    // 0x70e7fc: cmp             w0, NULL
    // 0x70e800: b.eq            #0x70e8e4
    // 0x70e804: r0 = RoundedRectangleBorder()
    //     0x70e804: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x70e808: mov             x1, x0
    // 0x70e80c: ldur            x0, [fp, #-0x10]
    // 0x70e810: StoreField: r1->field_b = r0
    //     0x70e810: stur            w0, [x1, #0xb]
    // 0x70e814: ldur            x0, [fp, #-8]
    // 0x70e818: StoreField: r1->field_7 = r0
    //     0x70e818: stur            w0, [x1, #7]
    // 0x70e81c: mov             x0, x1
    // 0x70e820: LeaveFrame
    //     0x70e820: mov             SP, fp
    //     0x70e824: ldp             fp, lr, [SP], #0x10
    // 0x70e828: ret
    //     0x70e828: ret             
    // 0x70e82c: mov             x3, x0
    // 0x70e830: ldr             x0, [fp, #0x20]
    // 0x70e834: ldr             d0, [fp, #0x10]
    // 0x70e838: r17 = 4360
    //     0x70e838: mov             x17, #0x1108
    // 0x70e83c: cmp             w1, w17
    // 0x70e840: b.ne            #0x70e8c0
    // 0x70e844: LoadField: r1 = r0->field_7
    //     0x70e844: ldur            w1, [x0, #7]
    // 0x70e848: DecompressPointer r1
    //     0x70e848: add             x1, x1, HEAP, lsl #32
    // 0x70e84c: LoadField: r2 = r3->field_7
    //     0x70e84c: ldur            w2, [x3, #7]
    // 0x70e850: DecompressPointer r2
    //     0x70e850: add             x2, x2, HEAP, lsl #32
    // 0x70e854: stp             x2, x1, [SP, #-0x10]!
    // 0x70e858: SaveReg d0
    //     0x70e858: str             d0, [SP, #-8]!
    // 0x70e85c: r0 = lerp()
    //     0x70e85c: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70e860: add             SP, SP, #0x18
    // 0x70e864: mov             x1, x0
    // 0x70e868: ldr             x0, [fp, #0x20]
    // 0x70e86c: stur            x1, [fp, #-0x10]
    // 0x70e870: LoadField: r2 = r0->field_b
    //     0x70e870: ldur            w2, [x0, #0xb]
    // 0x70e874: DecompressPointer r2
    //     0x70e874: add             x2, x2, HEAP, lsl #32
    // 0x70e878: ldr             x3, [fp, #0x18]
    // 0x70e87c: stur            x2, [fp, #-8]
    // 0x70e880: LoadField: d0 = r3->field_b
    //     0x70e880: ldur            d0, [x3, #0xb]
    // 0x70e884: stur            d0, [fp, #-0x18]
    // 0x70e888: r0 = _RoundedRectangleToCircleBorder()
    //     0x70e888: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0x70e88c: mov             x1, x0
    // 0x70e890: ldur            x0, [fp, #-8]
    // 0x70e894: StoreField: r1->field_b = r0
    //     0x70e894: stur            w0, [x1, #0xb]
    // 0x70e898: ldr             d0, [fp, #0x10]
    // 0x70e89c: StoreField: r1->field_f = d0
    //     0x70e89c: stur            d0, [x1, #0xf]
    // 0x70e8a0: ldur            d0, [fp, #-0x18]
    // 0x70e8a4: StoreField: r1->field_17 = d0
    //     0x70e8a4: stur            d0, [x1, #0x17]
    // 0x70e8a8: ldur            x0, [fp, #-0x10]
    // 0x70e8ac: StoreField: r1->field_7 = r0
    //     0x70e8ac: stur            w0, [x1, #7]
    // 0x70e8b0: mov             x0, x1
    // 0x70e8b4: LeaveFrame
    //     0x70e8b4: mov             SP, fp
    //     0x70e8b8: ldp             fp, lr, [SP], #0x10
    // 0x70e8bc: ret
    //     0x70e8bc: ret             
    // 0x70e8c0: stp             x3, x0, [SP, #-0x10]!
    // 0x70e8c4: SaveReg d0
    //     0x70e8c4: str             d0, [SP, #-8]!
    // 0x70e8c8: r0 = lerpTo()
    //     0x70e8c8: bl              #0x70f880  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x70e8cc: add             SP, SP, #0x18
    // 0x70e8d0: LeaveFrame
    //     0x70e8d0: mov             SP, fp
    //     0x70e8d4: ldp             fp, lr, [SP], #0x10
    // 0x70e8d8: ret
    //     0x70e8d8: ret             
    // 0x70e8dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70e8dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70e8e0: b               #0x70e780
    // 0x70e8e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70e8e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x710074, size: 0x1a8
    // 0x710074: EnterFrame
    //     0x710074: stp             fp, lr, [SP, #-0x10]!
    //     0x710078: mov             fp, SP
    // 0x71007c: AllocStack(0x20)
    //     0x71007c: sub             SP, SP, #0x20
    // 0x710080: CheckStackOverflow
    //     0x710080: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x710084: cmp             SP, x16
    //     0x710088: b.ls            #0x710210
    // 0x71008c: ldr             x0, [fp, #0x18]
    // 0x710090: r1 = LoadClassIdInstr(r0)
    //     0x710090: ldur            x1, [x0, #-1]
    //     0x710094: ubfx            x1, x1, #0xc, #0x14
    // 0x710098: lsl             x1, x1, #1
    // 0x71009c: r17 = 4358
    //     0x71009c: mov             x17, #0x1106
    // 0x7100a0: cmp             w1, w17
    // 0x7100a4: b.ne            #0x710138
    // 0x7100a8: ldr             x1, [fp, #0x20]
    // 0x7100ac: ldr             d0, [fp, #0x10]
    // 0x7100b0: LoadField: r2 = r0->field_7
    //     0x7100b0: ldur            w2, [x0, #7]
    // 0x7100b4: DecompressPointer r2
    //     0x7100b4: add             x2, x2, HEAP, lsl #32
    // 0x7100b8: LoadField: r3 = r1->field_7
    //     0x7100b8: ldur            w3, [x1, #7]
    // 0x7100bc: DecompressPointer r3
    //     0x7100bc: add             x3, x3, HEAP, lsl #32
    // 0x7100c0: stp             x3, x2, [SP, #-0x10]!
    // 0x7100c4: SaveReg d0
    //     0x7100c4: str             d0, [SP, #-8]!
    // 0x7100c8: r0 = lerp()
    //     0x7100c8: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x7100cc: add             SP, SP, #0x18
    // 0x7100d0: mov             x1, x0
    // 0x7100d4: ldr             x0, [fp, #0x18]
    // 0x7100d8: stur            x1, [fp, #-8]
    // 0x7100dc: LoadField: r2 = r0->field_b
    //     0x7100dc: ldur            w2, [x0, #0xb]
    // 0x7100e0: DecompressPointer r2
    //     0x7100e0: add             x2, x2, HEAP, lsl #32
    // 0x7100e4: ldr             x3, [fp, #0x20]
    // 0x7100e8: LoadField: r0 = r3->field_b
    //     0x7100e8: ldur            w0, [x3, #0xb]
    // 0x7100ec: DecompressPointer r0
    //     0x7100ec: add             x0, x0, HEAP, lsl #32
    // 0x7100f0: stp             x0, x2, [SP, #-0x10]!
    // 0x7100f4: ldr             d0, [fp, #0x10]
    // 0x7100f8: SaveReg d0
    //     0x7100f8: str             d0, [SP, #-8]!
    // 0x7100fc: r0 = lerp()
    //     0x7100fc: bl              #0x70e900  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x710100: add             SP, SP, #0x18
    // 0x710104: stur            x0, [fp, #-0x10]
    // 0x710108: cmp             w0, NULL
    // 0x71010c: b.eq            #0x710218
    // 0x710110: r0 = RoundedRectangleBorder()
    //     0x710110: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x710114: mov             x1, x0
    // 0x710118: ldur            x0, [fp, #-0x10]
    // 0x71011c: StoreField: r1->field_b = r0
    //     0x71011c: stur            w0, [x1, #0xb]
    // 0x710120: ldur            x0, [fp, #-8]
    // 0x710124: StoreField: r1->field_7 = r0
    //     0x710124: stur            w0, [x1, #7]
    // 0x710128: mov             x0, x1
    // 0x71012c: LeaveFrame
    //     0x71012c: mov             SP, fp
    //     0x710130: ldp             fp, lr, [SP], #0x10
    // 0x710134: ret
    //     0x710134: ret             
    // 0x710138: ldr             x3, [fp, #0x20]
    // 0x71013c: ldr             d0, [fp, #0x10]
    // 0x710140: r17 = 4360
    //     0x710140: mov             x17, #0x1108
    // 0x710144: cmp             w1, w17
    // 0x710148: b.ne            #0x7101d8
    // 0x71014c: LoadField: r1 = r0->field_7
    //     0x71014c: ldur            w1, [x0, #7]
    // 0x710150: DecompressPointer r1
    //     0x710150: add             x1, x1, HEAP, lsl #32
    // 0x710154: LoadField: r2 = r3->field_7
    //     0x710154: ldur            w2, [x3, #7]
    // 0x710158: DecompressPointer r2
    //     0x710158: add             x2, x2, HEAP, lsl #32
    // 0x71015c: stp             x2, x1, [SP, #-0x10]!
    // 0x710160: SaveReg d0
    //     0x710160: str             d0, [SP, #-8]!
    // 0x710164: r0 = lerp()
    //     0x710164: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x710168: add             SP, SP, #0x18
    // 0x71016c: mov             x1, x0
    // 0x710170: ldr             x0, [fp, #0x20]
    // 0x710174: stur            x1, [fp, #-0x10]
    // 0x710178: LoadField: r2 = r0->field_b
    //     0x710178: ldur            w2, [x0, #0xb]
    // 0x71017c: DecompressPointer r2
    //     0x71017c: add             x2, x2, HEAP, lsl #32
    // 0x710180: ldr             d0, [fp, #0x10]
    // 0x710184: stur            x2, [fp, #-8]
    // 0x710188: d1 = 1.000000
    //     0x710188: fmov            d1, #1.00000000
    // 0x71018c: fsub            d2, d1, d0
    // 0x710190: ldr             x3, [fp, #0x18]
    // 0x710194: stur            d2, [fp, #-0x20]
    // 0x710198: LoadField: d0 = r3->field_b
    //     0x710198: ldur            d0, [x3, #0xb]
    // 0x71019c: stur            d0, [fp, #-0x18]
    // 0x7101a0: r0 = _RoundedRectangleToCircleBorder()
    //     0x7101a0: bl              #0x70e8e8  ; Allocate_RoundedRectangleToCircleBorderStub -> _RoundedRectangleToCircleBorder (size=0x20)
    // 0x7101a4: mov             x1, x0
    // 0x7101a8: ldur            x0, [fp, #-8]
    // 0x7101ac: StoreField: r1->field_b = r0
    //     0x7101ac: stur            w0, [x1, #0xb]
    // 0x7101b0: ldur            d0, [fp, #-0x20]
    // 0x7101b4: StoreField: r1->field_f = d0
    //     0x7101b4: stur            d0, [x1, #0xf]
    // 0x7101b8: ldur            d0, [fp, #-0x18]
    // 0x7101bc: StoreField: r1->field_17 = d0
    //     0x7101bc: stur            d0, [x1, #0x17]
    // 0x7101c0: ldur            x0, [fp, #-0x10]
    // 0x7101c4: StoreField: r1->field_7 = r0
    //     0x7101c4: stur            w0, [x1, #7]
    // 0x7101c8: mov             x0, x1
    // 0x7101cc: LeaveFrame
    //     0x7101cc: mov             SP, fp
    //     0x7101d0: ldp             fp, lr, [SP], #0x10
    // 0x7101d4: ret
    //     0x7101d4: ret             
    // 0x7101d8: mov             x16, x0
    // 0x7101dc: mov             x0, x3
    // 0x7101e0: mov             x3, x16
    // 0x7101e4: cmp             w3, NULL
    // 0x7101e8: b.ne            #0x710200
    // 0x7101ec: SaveReg r0
    //     0x7101ec: str             x0, [SP, #-8]!
    // 0x7101f0: SaveReg d0
    //     0x7101f0: str             d0, [SP, #-8]!
    // 0x7101f4: r0 = scale()
    //     0x7101f4: bl              #0xcf8598  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::scale
    // 0x7101f8: add             SP, SP, #0x10
    // 0x7101fc: b               #0x710204
    // 0x710200: r0 = Null
    //     0x710200: mov             x0, NULL
    // 0x710204: LeaveFrame
    //     0x710204: mov             SP, fp
    //     0x710208: ldp             fp, lr, [SP], #0x10
    // 0x71020c: ret
    //     0x71020c: ret             
    // 0x710210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x710210: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x710214: b               #0x71008c
    // 0x710218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x710218: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x717fcc, size: 0xec
    // 0x717fcc: EnterFrame
    //     0x717fcc: stp             fp, lr, [SP, #-0x10]!
    //     0x717fd0: mov             fp, SP
    // 0x717fd4: AllocStack(0x8)
    //     0x717fd4: sub             SP, SP, #8
    // 0x717fd8: CheckStackOverflow
    //     0x717fd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x717fdc: cmp             SP, x16
    //     0x717fe0: b.ls            #0x7180ac
    // 0x717fe4: ldr             x0, [fp, #0x30]
    // 0x717fe8: LoadField: r1 = r0->field_b
    //     0x717fe8: ldur            w1, [x0, #0xb]
    // 0x717fec: DecompressPointer r1
    //     0x717fec: add             x1, x1, HEAP, lsl #32
    // 0x717ff0: stur            x1, [fp, #-8]
    // 0x717ff4: r16 = Instance_BorderRadius
    //     0x717ff4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x717ff8: ldr             x16, [x16, #0x2c0]
    // 0x717ffc: stp             x16, x1, [SP, #-0x10]!
    // 0x718000: r0 = ==()
    //     0x718000: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0x718004: add             SP, SP, #0x10
    // 0x718008: tbnz            w0, #4, #0x71802c
    // 0x71800c: ldr             x16, [fp, #0x28]
    // 0x718010: ldr             lr, [fp, #0x20]
    // 0x718014: stp             lr, x16, [SP, #-0x10]!
    // 0x718018: ldr             x16, [fp, #0x18]
    // 0x71801c: SaveReg r16
    //     0x71801c: str             x16, [SP, #-8]!
    // 0x718020: r0 = drawRect()
    //     0x718020: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0x718024: add             SP, SP, #0x18
    // 0x718028: b               #0x71809c
    // 0x71802c: ldur            x0, [fp, #-8]
    // 0x718030: r1 = LoadClassIdInstr(r0)
    //     0x718030: ldur            x1, [x0, #-1]
    //     0x718034: ubfx            x1, x1, #0xc, #0x14
    // 0x718038: lsl             x1, x1, #1
    // 0x71803c: r17 = 4224
    //     0x71803c: mov             x17, #0x1080
    // 0x718040: cmp             w1, w17
    // 0x718044: b.eq            #0x71806c
    // 0x718048: r1 = LoadClassIdInstr(r0)
    //     0x718048: ldur            x1, [x0, #-1]
    //     0x71804c: ubfx            x1, x1, #0xc, #0x14
    // 0x718050: ldr             x16, [fp, #0x10]
    // 0x718054: stp             x16, x0, [SP, #-0x10]!
    // 0x718058: mov             x0, x1
    // 0x71805c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x71805c: sub             lr, x0, #1, lsl #12
    //     0x718060: ldr             lr, [x21, lr, lsl #3]
    //     0x718064: blr             lr
    // 0x718068: add             SP, SP, #0x10
    // 0x71806c: cmp             w0, NULL
    // 0x718070: b.eq            #0x7180b4
    // 0x718074: ldr             x16, [fp, #0x20]
    // 0x718078: stp             x16, x0, [SP, #-0x10]!
    // 0x71807c: r0 = toRRect()
    //     0x71807c: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x718080: add             SP, SP, #0x10
    // 0x718084: ldr             x16, [fp, #0x28]
    // 0x718088: stp             x0, x16, [SP, #-0x10]!
    // 0x71808c: ldr             x16, [fp, #0x18]
    // 0x718090: SaveReg r16
    //     0x718090: str             x16, [SP, #-8]!
    // 0x718094: r0 = drawRRect()
    //     0x718094: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x718098: add             SP, SP, #0x18
    // 0x71809c: r0 = Null
    //     0x71809c: mov             x0, NULL
    // 0x7180a0: LeaveFrame
    //     0x7180a0: mov             SP, fp
    //     0x7180a4: ldp             fp, lr, [SP], #0x10
    // 0x7180a8: ret
    //     0x7180a8: ret             
    // 0x7180ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7180ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7180b0: b               #0x717fe4
    // 0x7180b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7180b4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getInnerPath(/* No info */) {
    // ** addr: 0x71acc8, size: 0x168
    // 0x71acc8: EnterFrame
    //     0x71acc8: stp             fp, lr, [SP, #-0x10]!
    //     0x71accc: mov             fp, SP
    // 0x71acd0: AllocStack(0x10)
    //     0x71acd0: sub             SP, SP, #0x10
    // 0x71acd4: SetupParameters(RoundedRectangleBorder this /* r3, fp-0x10 */, dynamic _ /* r4, fp-0x8 */, {dynamic textDirection = Null /* r0 */})
    //     0x71acd4: mov             x0, x4
    //     0x71acd8: ldur            w1, [x0, #0x13]
    //     0x71acdc: add             x1, x1, HEAP, lsl #32
    //     0x71ace0: sub             x2, x1, #4
    //     0x71ace4: add             x3, fp, w2, sxtw #2
    //     0x71ace8: ldr             x3, [x3, #0x18]
    //     0x71acec: stur            x3, [fp, #-0x10]
    //     0x71acf0: add             x4, fp, w2, sxtw #2
    //     0x71acf4: ldr             x4, [x4, #0x10]
    //     0x71acf8: stur            x4, [fp, #-8]
    //     0x71acfc: ldur            w2, [x0, #0x1f]
    //     0x71ad00: add             x2, x2, HEAP, lsl #32
    //     0x71ad04: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0x71ad08: ldr             x16, [x16, #0xf10]
    //     0x71ad0c: cmp             w2, w16
    //     0x71ad10: b.ne            #0x71ad30
    //     0x71ad14: ldur            w2, [x0, #0x23]
    //     0x71ad18: add             x2, x2, HEAP, lsl #32
    //     0x71ad1c: sub             w0, w1, w2
    //     0x71ad20: add             x1, fp, w0, sxtw #2
    //     0x71ad24: ldr             x1, [x1, #8]
    //     0x71ad28: mov             x0, x1
    //     0x71ad2c: b               #0x71ad34
    //     0x71ad30: mov             x0, NULL
    // 0x71ad34: CheckStackOverflow
    //     0x71ad34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71ad38: cmp             SP, x16
    //     0x71ad3c: b.ls            #0x71ae24
    // 0x71ad40: LoadField: r1 = r3->field_b
    //     0x71ad40: ldur            w1, [x3, #0xb]
    // 0x71ad44: DecompressPointer r1
    //     0x71ad44: add             x1, x1, HEAP, lsl #32
    // 0x71ad48: r2 = LoadClassIdInstr(r1)
    //     0x71ad48: ldur            x2, [x1, #-1]
    //     0x71ad4c: ubfx            x2, x2, #0xc, #0x14
    // 0x71ad50: lsl             x2, x2, #1
    // 0x71ad54: r17 = 4224
    //     0x71ad54: mov             x17, #0x1080
    // 0x71ad58: cmp             w2, w17
    // 0x71ad5c: b.ne            #0x71ad68
    // 0x71ad60: mov             x0, x3
    // 0x71ad64: b               #0x71ad90
    // 0x71ad68: r2 = LoadClassIdInstr(r1)
    //     0x71ad68: ldur            x2, [x1, #-1]
    //     0x71ad6c: ubfx            x2, x2, #0xc, #0x14
    // 0x71ad70: stp             x0, x1, [SP, #-0x10]!
    // 0x71ad74: mov             x0, x2
    // 0x71ad78: r0 = GDT[cid_x0 + -0x1000]()
    //     0x71ad78: sub             lr, x0, #1, lsl #12
    //     0x71ad7c: ldr             lr, [x21, lr, lsl #3]
    //     0x71ad80: blr             lr
    // 0x71ad84: add             SP, SP, #0x10
    // 0x71ad88: mov             x1, x0
    // 0x71ad8c: ldur            x0, [fp, #-0x10]
    // 0x71ad90: cmp             w1, NULL
    // 0x71ad94: b.eq            #0x71ae2c
    // 0x71ad98: ldur            x16, [fp, #-8]
    // 0x71ad9c: stp             x16, x1, [SP, #-0x10]!
    // 0x71ada0: r0 = toRRect()
    //     0x71ada0: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x71ada4: add             SP, SP, #0x10
    // 0x71ada8: mov             x1, x0
    // 0x71adac: ldur            x0, [fp, #-0x10]
    // 0x71adb0: LoadField: r2 = r0->field_7
    //     0x71adb0: ldur            w2, [x0, #7]
    // 0x71adb4: DecompressPointer r2
    //     0x71adb4: add             x2, x2, HEAP, lsl #32
    // 0x71adb8: LoadField: d0 = r2->field_b
    //     0x71adb8: ldur            d0, [x2, #0xb]
    // 0x71adbc: LoadField: d1 = r2->field_17
    //     0x71adbc: ldur            d1, [x2, #0x17]
    // 0x71adc0: d2 = 1.000000
    //     0x71adc0: fmov            d2, #1.00000000
    // 0x71adc4: fadd            d3, d2, d1
    // 0x71adc8: d1 = 2.000000
    //     0x71adc8: fmov            d1, #2.00000000
    // 0x71adcc: fdiv            d4, d3, d1
    // 0x71add0: fsub            d1, d2, d4
    // 0x71add4: fmul            d2, d0, d1
    // 0x71add8: SaveReg r1
    //     0x71add8: str             x1, [SP, #-8]!
    // 0x71addc: SaveReg d2
    //     0x71addc: str             d2, [SP, #-8]!
    // 0x71ade0: r0 = deflate()
    //     0x71ade0: bl              #0x6705bc  ; [dart:ui] RRect::deflate
    // 0x71ade4: add             SP, SP, #0x10
    // 0x71ade8: stur            x0, [fp, #-8]
    // 0x71adec: r0 = Path()
    //     0x71adec: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x71adf0: stur            x0, [fp, #-0x10]
    // 0x71adf4: SaveReg r0
    //     0x71adf4: str             x0, [SP, #-8]!
    // 0x71adf8: r0 = _constructor()
    //     0x71adf8: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x71adfc: add             SP, SP, #8
    // 0x71ae00: ldur            x16, [fp, #-0x10]
    // 0x71ae04: ldur            lr, [fp, #-8]
    // 0x71ae08: stp             lr, x16, [SP, #-0x10]!
    // 0x71ae0c: r0 = addRRect()
    //     0x71ae0c: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0x71ae10: add             SP, SP, #0x10
    // 0x71ae14: ldur            x0, [fp, #-0x10]
    // 0x71ae18: LeaveFrame
    //     0x71ae18: mov             SP, fp
    //     0x71ae1c: ldp             fp, lr, [SP], #0x10
    // 0x71ae20: ret
    //     0x71ae20: ret             
    // 0x71ae24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71ae24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71ae28: b               #0x71ad40
    // 0x71ae2c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x71ae2c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xadb1e4, size: 0x80
    // 0xadb1e4: EnterFrame
    //     0xadb1e4: stp             fp, lr, [SP, #-0x10]!
    //     0xadb1e8: mov             fp, SP
    // 0xadb1ec: CheckStackOverflow
    //     0xadb1ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadb1f0: cmp             SP, x16
    //     0xadb1f4: b.ls            #0xadb25c
    // 0xadb1f8: r1 = Null
    //     0xadb1f8: mov             x1, NULL
    // 0xadb1fc: r2 = 12
    //     0xadb1fc: mov             x2, #0xc
    // 0xadb200: r0 = AllocateArray()
    //     0xadb200: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb204: r17 = "RoundedRectangleBorder"
    //     0xadb204: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7c8] "RoundedRectangleBorder"
    //     0xadb208: ldr             x17, [x17, #0x7c8]
    // 0xadb20c: StoreField: r0->field_f = r17
    //     0xadb20c: stur            w17, [x0, #0xf]
    // 0xadb210: r17 = "("
    //     0xadb210: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xadb214: StoreField: r0->field_13 = r17
    //     0xadb214: stur            w17, [x0, #0x13]
    // 0xadb218: ldr             x1, [fp, #0x10]
    // 0xadb21c: LoadField: r2 = r1->field_7
    //     0xadb21c: ldur            w2, [x1, #7]
    // 0xadb220: DecompressPointer r2
    //     0xadb220: add             x2, x2, HEAP, lsl #32
    // 0xadb224: StoreField: r0->field_17 = r2
    //     0xadb224: stur            w2, [x0, #0x17]
    // 0xadb228: r17 = ", "
    //     0xadb228: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xadb22c: StoreField: r0->field_1b = r17
    //     0xadb22c: stur            w17, [x0, #0x1b]
    // 0xadb230: LoadField: r2 = r1->field_b
    //     0xadb230: ldur            w2, [x1, #0xb]
    // 0xadb234: DecompressPointer r2
    //     0xadb234: add             x2, x2, HEAP, lsl #32
    // 0xadb238: StoreField: r0->field_1f = r2
    //     0xadb238: stur            w2, [x0, #0x1f]
    // 0xadb23c: r17 = ")"
    //     0xadb23c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadb240: StoreField: r0->field_23 = r17
    //     0xadb240: stur            w17, [x0, #0x23]
    // 0xadb244: SaveReg r0
    //     0xadb244: str             x0, [SP, #-8]!
    // 0xadb248: r0 = _interpolate()
    //     0xadb248: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb24c: add             SP, SP, #8
    // 0xadb250: LeaveFrame
    //     0xadb250: mov             SP, fp
    //     0xadb254: ldp             fp, lr, [SP], #0x10
    // 0xadb258: ret
    //     0xadb258: ret             
    // 0xadb25c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xadb25c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xadb260: b               #0xadb1f8
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd3ed8, size: 0x310
    // 0xbd3ed8: EnterFrame
    //     0xbd3ed8: stp             fp, lr, [SP, #-0x10]!
    //     0xbd3edc: mov             fp, SP
    // 0xbd3ee0: AllocStack(0x48)
    //     0xbd3ee0: sub             SP, SP, #0x48
    // 0xbd3ee4: SetupParameters(RoundedRectangleBorder this /* r3, fp-0x30 */, dynamic _ /* r4, fp-0x18 */, dynamic _ /* r5, fp-0x10 */, {dynamic textDirection = Null /* r0, fp-0x28 */})
    //     0xbd3ee4: mov             x0, x4
    //     0xbd3ee8: ldur            w1, [x0, #0x13]
    //     0xbd3eec: add             x1, x1, HEAP, lsl #32
    //     0xbd3ef0: sub             x2, x1, #6
    //     0xbd3ef4: add             x3, fp, w2, sxtw #2
    //     0xbd3ef8: ldr             x3, [x3, #0x20]
    //     0xbd3efc: stur            x3, [fp, #-0x30]
    //     0xbd3f00: add             x4, fp, w2, sxtw #2
    //     0xbd3f04: ldr             x4, [x4, #0x18]
    //     0xbd3f08: stur            x4, [fp, #-0x18]
    //     0xbd3f0c: add             x5, fp, w2, sxtw #2
    //     0xbd3f10: ldr             x5, [x5, #0x10]
    //     0xbd3f14: stur            x5, [fp, #-0x10]
    //     0xbd3f18: ldur            w2, [x0, #0x1f]
    //     0xbd3f1c: add             x2, x2, HEAP, lsl #32
    //     0xbd3f20: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0xbd3f24: ldr             x16, [x16, #0xf10]
    //     0xbd3f28: cmp             w2, w16
    //     0xbd3f2c: b.ne            #0xbd3f4c
    //     0xbd3f30: ldur            w2, [x0, #0x23]
    //     0xbd3f34: add             x2, x2, HEAP, lsl #32
    //     0xbd3f38: sub             w0, w1, w2
    //     0xbd3f3c: add             x1, fp, w0, sxtw #2
    //     0xbd3f40: ldr             x1, [x1, #8]
    //     0xbd3f44: mov             x0, x1
    //     0xbd3f48: b               #0xbd3f50
    //     0xbd3f4c: mov             x0, NULL
    //     0xbd3f50: stur            x0, [fp, #-0x28]
    // 0xbd3f54: CheckStackOverflow
    //     0xbd3f54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd3f58: cmp             SP, x16
    //     0xbd3f5c: b.ls            #0xbd41d8
    // 0xbd3f60: LoadField: r1 = r3->field_7
    //     0xbd3f60: ldur            w1, [x3, #7]
    // 0xbd3f64: DecompressPointer r1
    //     0xbd3f64: add             x1, x1, HEAP, lsl #32
    // 0xbd3f68: stur            x1, [fp, #-8]
    // 0xbd3f6c: LoadField: r2 = r1->field_13
    //     0xbd3f6c: ldur            w2, [x1, #0x13]
    // 0xbd3f70: DecompressPointer r2
    //     0xbd3f70: add             x2, x2, HEAP, lsl #32
    // 0xbd3f74: LoadField: r6 = r2->field_7
    //     0xbd3f74: ldur            x6, [x2, #7]
    // 0xbd3f78: cmp             x6, #0
    // 0xbd3f7c: b.le            #0xbd41c8
    // 0xbd3f80: d0 = 0.000000
    //     0xbd3f80: eor             v0.16b, v0.16b, v0.16b
    // 0xbd3f84: LoadField: d1 = r1->field_b
    //     0xbd3f84: ldur            d1, [x1, #0xb]
    // 0xbd3f88: stur            d1, [fp, #-0x40]
    // 0xbd3f8c: fcmp            d1, d0
    // 0xbd3f90: b.vs            #0xbd4028
    // 0xbd3f94: b.ne            #0xbd4028
    // 0xbd3f98: LoadField: r2 = r3->field_b
    //     0xbd3f98: ldur            w2, [x3, #0xb]
    // 0xbd3f9c: DecompressPointer r2
    //     0xbd3f9c: add             x2, x2, HEAP, lsl #32
    // 0xbd3fa0: r3 = LoadClassIdInstr(r2)
    //     0xbd3fa0: ldur            x3, [x2, #-1]
    //     0xbd3fa4: ubfx            x3, x3, #0xc, #0x14
    // 0xbd3fa8: lsl             x3, x3, #1
    // 0xbd3fac: r17 = 4224
    //     0xbd3fac: mov             x17, #0x1080
    // 0xbd3fb0: cmp             w3, w17
    // 0xbd3fb4: b.ne            #0xbd3fc0
    // 0xbd3fb8: mov             x0, x2
    // 0xbd3fbc: b               #0xbd3fe0
    // 0xbd3fc0: r3 = LoadClassIdInstr(r2)
    //     0xbd3fc0: ldur            x3, [x2, #-1]
    //     0xbd3fc4: ubfx            x3, x3, #0xc, #0x14
    // 0xbd3fc8: stp             x0, x2, [SP, #-0x10]!
    // 0xbd3fcc: mov             x0, x3
    // 0xbd3fd0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbd3fd0: sub             lr, x0, #1, lsl #12
    //     0xbd3fd4: ldr             lr, [x21, lr, lsl #3]
    //     0xbd3fd8: blr             lr
    // 0xbd3fdc: add             SP, SP, #0x10
    // 0xbd3fe0: cmp             w0, NULL
    // 0xbd3fe4: b.eq            #0xbd41e0
    // 0xbd3fe8: ldur            x16, [fp, #-0x10]
    // 0xbd3fec: stp             x16, x0, [SP, #-0x10]!
    // 0xbd3ff0: r0 = toRRect()
    //     0xbd3ff0: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbd3ff4: add             SP, SP, #0x10
    // 0xbd3ff8: stur            x0, [fp, #-0x20]
    // 0xbd3ffc: ldur            x16, [fp, #-8]
    // 0xbd4000: SaveReg r16
    //     0xbd4000: str             x16, [SP, #-8]!
    // 0xbd4004: r0 = toPaint()
    //     0xbd4004: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd4008: add             SP, SP, #8
    // 0xbd400c: ldur            x16, [fp, #-0x18]
    // 0xbd4010: ldur            lr, [fp, #-0x20]
    // 0xbd4014: stp             lr, x16, [SP, #-0x10]!
    // 0xbd4018: SaveReg r0
    //     0xbd4018: str             x0, [SP, #-8]!
    // 0xbd401c: r0 = drawRRect()
    //     0xbd401c: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xbd4020: add             SP, SP, #0x18
    // 0xbd4024: b               #0xbd41c8
    // 0xbd4028: r16 = 112
    //     0xbd4028: mov             x16, #0x70
    // 0xbd402c: stp             x16, NULL, [SP, #-0x10]!
    // 0xbd4030: r0 = ByteData()
    //     0xbd4030: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xbd4034: add             SP, SP, #0x10
    // 0xbd4038: stur            x0, [fp, #-0x20]
    // 0xbd403c: r0 = Paint()
    //     0xbd403c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xbd4040: mov             x1, x0
    // 0xbd4044: ldur            x0, [fp, #-0x20]
    // 0xbd4048: stur            x1, [fp, #-0x38]
    // 0xbd404c: StoreField: r1->field_7 = r0
    //     0xbd404c: stur            w0, [x1, #7]
    // 0xbd4050: ldur            x2, [fp, #-8]
    // 0xbd4054: LoadField: r3 = r2->field_7
    //     0xbd4054: ldur            w3, [x2, #7]
    // 0xbd4058: DecompressPointer r3
    //     0xbd4058: add             x3, x3, HEAP, lsl #32
    // 0xbd405c: r4 = LoadClassIdInstr(r3)
    //     0xbd405c: ldur            x4, [x3, #-1]
    //     0xbd4060: ubfx            x4, x4, #0xc, #0x14
    // 0xbd4064: lsl             x4, x4, #1
    // 0xbd4068: r17 = 10124
    //     0xbd4068: mov             x17, #0x278c
    // 0xbd406c: cmp             w4, w17
    // 0xbd4070: b.gt            #0xbd4080
    // 0xbd4074: r17 = 10122
    //     0xbd4074: mov             x17, #0x278a
    // 0xbd4078: cmp             w4, w17
    // 0xbd407c: b.ge            #0xbd4098
    // 0xbd4080: r17 = 10114
    //     0xbd4080: mov             x17, #0x2782
    // 0xbd4084: cmp             w4, w17
    // 0xbd4088: b.eq            #0xbd4098
    // 0xbd408c: r17 = 10118
    //     0xbd408c: mov             x17, #0x2786
    // 0xbd4090: cmp             w4, w17
    // 0xbd4094: b.ne            #0xbd40a0
    // 0xbd4098: LoadField: r4 = r3->field_7
    //     0xbd4098: ldur            x4, [x3, #7]
    // 0xbd409c: b               #0xbd40b0
    // 0xbd40a0: LoadField: r4 = r3->field_f
    //     0xbd40a0: ldur            w4, [x3, #0xf]
    // 0xbd40a4: DecompressPointer r4
    //     0xbd40a4: add             x4, x4, HEAP, lsl #32
    // 0xbd40a8: LoadField: r3 = r4->field_7
    //     0xbd40a8: ldur            x3, [x4, #7]
    // 0xbd40ac: mov             x4, x3
    // 0xbd40b0: ldur            x3, [fp, #-0x30]
    // 0xbd40b4: eor             x5, x4, #0xff000000
    // 0xbd40b8: LoadField: r4 = r0->field_17
    //     0xbd40b8: ldur            w4, [x0, #0x17]
    // 0xbd40bc: DecompressPointer r4
    //     0xbd40bc: add             x4, x4, HEAP, lsl #32
    // 0xbd40c0: sxtw            x5, w5
    // 0xbd40c4: LoadField: r0 = r4->field_7
    //     0xbd40c4: ldur            x0, [x4, #7]
    // 0xbd40c8: str             w5, [x0, #4]
    // 0xbd40cc: LoadField: r0 = r3->field_b
    //     0xbd40cc: ldur            w0, [x3, #0xb]
    // 0xbd40d0: DecompressPointer r0
    //     0xbd40d0: add             x0, x0, HEAP, lsl #32
    // 0xbd40d4: r3 = LoadClassIdInstr(r0)
    //     0xbd40d4: ldur            x3, [x0, #-1]
    //     0xbd40d8: ubfx            x3, x3, #0xc, #0x14
    // 0xbd40dc: lsl             x3, x3, #1
    // 0xbd40e0: r17 = 4224
    //     0xbd40e0: mov             x17, #0x1080
    // 0xbd40e4: cmp             w3, w17
    // 0xbd40e8: b.ne            #0xbd40f8
    // 0xbd40ec: mov             x1, x0
    // 0xbd40f0: mov             x0, x2
    // 0xbd40f4: b               #0xbd4124
    // 0xbd40f8: r3 = LoadClassIdInstr(r0)
    //     0xbd40f8: ldur            x3, [x0, #-1]
    //     0xbd40fc: ubfx            x3, x3, #0xc, #0x14
    // 0xbd4100: ldur            x16, [fp, #-0x28]
    // 0xbd4104: stp             x16, x0, [SP, #-0x10]!
    // 0xbd4108: mov             x0, x3
    // 0xbd410c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbd410c: sub             lr, x0, #1, lsl #12
    //     0xbd4110: ldr             lr, [x21, lr, lsl #3]
    //     0xbd4114: blr             lr
    // 0xbd4118: add             SP, SP, #0x10
    // 0xbd411c: mov             x1, x0
    // 0xbd4120: ldur            x0, [fp, #-8]
    // 0xbd4124: ldur            d0, [fp, #-0x40]
    // 0xbd4128: cmp             w1, NULL
    // 0xbd412c: b.eq            #0xbd41e4
    // 0xbd4130: ldur            x16, [fp, #-0x10]
    // 0xbd4134: stp             x16, x1, [SP, #-0x10]!
    // 0xbd4138: r0 = toRRect()
    //     0xbd4138: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xbd413c: add             SP, SP, #0x10
    // 0xbd4140: mov             x1, x0
    // 0xbd4144: ldur            x0, [fp, #-8]
    // 0xbd4148: stur            x1, [fp, #-0x10]
    // 0xbd414c: LoadField: d0 = r0->field_17
    //     0xbd414c: ldur            d0, [x0, #0x17]
    // 0xbd4150: d1 = 1.000000
    //     0xbd4150: fmov            d1, #1.00000000
    // 0xbd4154: fadd            d2, d1, d0
    // 0xbd4158: stur            d2, [fp, #-0x48]
    // 0xbd415c: d0 = 2.000000
    //     0xbd415c: fmov            d0, #2.00000000
    // 0xbd4160: fdiv            d3, d2, d0
    // 0xbd4164: fsub            d4, d1, d3
    // 0xbd4168: ldur            d1, [fp, #-0x40]
    // 0xbd416c: fmul            d3, d1, d4
    // 0xbd4170: SaveReg r1
    //     0xbd4170: str             x1, [SP, #-8]!
    // 0xbd4174: SaveReg d3
    //     0xbd4174: str             d3, [SP, #-8]!
    // 0xbd4178: r0 = deflate()
    //     0xbd4178: bl              #0x6705bc  ; [dart:ui] RRect::deflate
    // 0xbd417c: add             SP, SP, #0x10
    // 0xbd4180: ldur            d1, [fp, #-0x40]
    // 0xbd4184: ldur            d0, [fp, #-0x48]
    // 0xbd4188: stur            x0, [fp, #-8]
    // 0xbd418c: fmul            d2, d1, d0
    // 0xbd4190: d0 = 2.000000
    //     0xbd4190: fmov            d0, #2.00000000
    // 0xbd4194: fdiv            d1, d2, d0
    // 0xbd4198: ldur            x16, [fp, #-0x10]
    // 0xbd419c: SaveReg r16
    //     0xbd419c: str             x16, [SP, #-8]!
    // 0xbd41a0: SaveReg d1
    //     0xbd41a0: str             d1, [SP, #-8]!
    // 0xbd41a4: r0 = inflate()
    //     0xbd41a4: bl              #0x65ffe4  ; [dart:ui] RRect::inflate
    // 0xbd41a8: add             SP, SP, #0x10
    // 0xbd41ac: ldur            x16, [fp, #-0x18]
    // 0xbd41b0: stp             x0, x16, [SP, #-0x10]!
    // 0xbd41b4: ldur            x16, [fp, #-8]
    // 0xbd41b8: ldur            lr, [fp, #-0x38]
    // 0xbd41bc: stp             lr, x16, [SP, #-0x10]!
    // 0xbd41c0: r0 = drawDRRect()
    //     0xbd41c0: bl              #0x6701ec  ; [dart:ui] Canvas::drawDRRect
    // 0xbd41c4: add             SP, SP, #0x20
    // 0xbd41c8: r0 = Null
    //     0xbd41c8: mov             x0, NULL
    // 0xbd41cc: LeaveFrame
    //     0xbd41cc: mov             SP, fp
    //     0xbd41d0: ldp             fp, lr, [SP], #0x10
    // 0xbd41d4: ret
    //     0xbd41d4: ret             
    // 0xbd41d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd41d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd41dc: b               #0xbd3f60
    // 0xbd41e0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbd41e0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xbd41e4: r0 = NullErrorSharedWithFPURegs()
    //     0xbd41e4: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc99a40, size: 0x11c
    // 0xc99a40: EnterFrame
    //     0xc99a40: stp             fp, lr, [SP, #-0x10]!
    //     0xc99a44: mov             fp, SP
    // 0xc99a48: CheckStackOverflow
    //     0xc99a48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc99a4c: cmp             SP, x16
    //     0xc99a50: b.ls            #0xc99b54
    // 0xc99a54: ldr             x1, [fp, #0x10]
    // 0xc99a58: cmp             w1, NULL
    // 0xc99a5c: b.ne            #0xc99a70
    // 0xc99a60: r0 = false
    //     0xc99a60: add             x0, NULL, #0x30  ; false
    // 0xc99a64: LeaveFrame
    //     0xc99a64: mov             SP, fp
    //     0xc99a68: ldp             fp, lr, [SP], #0x10
    // 0xc99a6c: ret
    //     0xc99a6c: ret             
    // 0xc99a70: r0 = 59
    //     0xc99a70: mov             x0, #0x3b
    // 0xc99a74: branchIfSmi(r1, 0xc99a80)
    //     0xc99a74: tbz             w1, #0, #0xc99a80
    // 0xc99a78: r0 = LoadClassIdInstr(r1)
    //     0xc99a78: ldur            x0, [x1, #-1]
    //     0xc99a7c: ubfx            x0, x0, #0xc, #0x14
    // 0xc99a80: SaveReg r1
    //     0xc99a80: str             x1, [SP, #-8]!
    // 0xc99a84: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc99a84: mov             x17, #0x57c5
    //     0xc99a88: add             lr, x0, x17
    //     0xc99a8c: ldr             lr, [x21, lr, lsl #3]
    //     0xc99a90: blr             lr
    // 0xc99a94: add             SP, SP, #8
    // 0xc99a98: r1 = LoadClassIdInstr(r0)
    //     0xc99a98: ldur            x1, [x0, #-1]
    //     0xc99a9c: ubfx            x1, x1, #0xc, #0x14
    // 0xc99aa0: r16 = RoundedRectangleBorder
    //     0xc99aa0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe468] Type: RoundedRectangleBorder
    //     0xc99aa4: ldr             x16, [x16, #0x468]
    // 0xc99aa8: stp             x16, x0, [SP, #-0x10]!
    // 0xc99aac: mov             x0, x1
    // 0xc99ab0: mov             lr, x0
    // 0xc99ab4: ldr             lr, [x21, lr, lsl #3]
    // 0xc99ab8: blr             lr
    // 0xc99abc: add             SP, SP, #0x10
    // 0xc99ac0: tbz             w0, #4, #0xc99ad4
    // 0xc99ac4: r0 = false
    //     0xc99ac4: add             x0, NULL, #0x30  ; false
    // 0xc99ac8: LeaveFrame
    //     0xc99ac8: mov             SP, fp
    //     0xc99acc: ldp             fp, lr, [SP], #0x10
    // 0xc99ad0: ret
    //     0xc99ad0: ret             
    // 0xc99ad4: ldr             x0, [fp, #0x10]
    // 0xc99ad8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc99ad8: mov             x1, #0x76
    //     0xc99adc: tbz             w0, #0, #0xc99aec
    //     0xc99ae0: ldur            x1, [x0, #-1]
    //     0xc99ae4: ubfx            x1, x1, #0xc, #0x14
    //     0xc99ae8: lsl             x1, x1, #1
    // 0xc99aec: r17 = 4358
    //     0xc99aec: mov             x17, #0x1106
    // 0xc99af0: cmp             w1, w17
    // 0xc99af4: b.ne            #0xc99b44
    // 0xc99af8: ldr             x1, [fp, #0x18]
    // 0xc99afc: LoadField: r2 = r0->field_7
    //     0xc99afc: ldur            w2, [x0, #7]
    // 0xc99b00: DecompressPointer r2
    //     0xc99b00: add             x2, x2, HEAP, lsl #32
    // 0xc99b04: LoadField: r3 = r1->field_7
    //     0xc99b04: ldur            w3, [x1, #7]
    // 0xc99b08: DecompressPointer r3
    //     0xc99b08: add             x3, x3, HEAP, lsl #32
    // 0xc99b0c: stp             x3, x2, [SP, #-0x10]!
    // 0xc99b10: r0 = ==()
    //     0xc99b10: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc99b14: add             SP, SP, #0x10
    // 0xc99b18: tbnz            w0, #4, #0xc99b44
    // 0xc99b1c: ldr             x1, [fp, #0x18]
    // 0xc99b20: ldr             x0, [fp, #0x10]
    // 0xc99b24: LoadField: r2 = r0->field_b
    //     0xc99b24: ldur            w2, [x0, #0xb]
    // 0xc99b28: DecompressPointer r2
    //     0xc99b28: add             x2, x2, HEAP, lsl #32
    // 0xc99b2c: LoadField: r0 = r1->field_b
    //     0xc99b2c: ldur            w0, [x1, #0xb]
    // 0xc99b30: DecompressPointer r0
    //     0xc99b30: add             x0, x0, HEAP, lsl #32
    // 0xc99b34: stp             x0, x2, [SP, #-0x10]!
    // 0xc99b38: r0 = ==()
    //     0xc99b38: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xc99b3c: add             SP, SP, #0x10
    // 0xc99b40: b               #0xc99b48
    // 0xc99b44: r0 = false
    //     0xc99b44: add             x0, NULL, #0x30  ; false
    // 0xc99b48: LeaveFrame
    //     0xc99b48: mov             SP, fp
    //     0xc99b4c: ldp             fp, lr, [SP], #0x10
    // 0xc99b50: ret
    //     0xc99b50: ret             
    // 0xc99b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc99b54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc99b58: b               #0xc99a54
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf8598, size: 0x20c
    // 0xcf8598: EnterFrame
    //     0xcf8598: stp             fp, lr, [SP, #-0x10]!
    //     0xcf859c: mov             fp, SP
    // 0xcf85a0: AllocStack(0x30)
    //     0xcf85a0: sub             SP, SP, #0x30
    // 0xcf85a4: CheckStackOverflow
    //     0xcf85a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf85a8: cmp             SP, x16
    //     0xcf85ac: b.ls            #0xcf875c
    // 0xcf85b0: ldr             x0, [fp, #0x18]
    // 0xcf85b4: LoadField: r1 = r0->field_7
    //     0xcf85b4: ldur            w1, [x0, #7]
    // 0xcf85b8: DecompressPointer r1
    //     0xcf85b8: add             x1, x1, HEAP, lsl #32
    // 0xcf85bc: SaveReg r1
    //     0xcf85bc: str             x1, [SP, #-8]!
    // 0xcf85c0: ldr             d0, [fp, #0x10]
    // 0xcf85c4: SaveReg d0
    //     0xcf85c4: str             d0, [SP, #-8]!
    // 0xcf85c8: r0 = scale()
    //     0xcf85c8: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf85cc: add             SP, SP, #0x10
    // 0xcf85d0: mov             x1, x0
    // 0xcf85d4: ldr             x0, [fp, #0x18]
    // 0xcf85d8: stur            x1, [fp, #-0x18]
    // 0xcf85dc: LoadField: r2 = r0->field_b
    //     0xcf85dc: ldur            w2, [x0, #0xb]
    // 0xcf85e0: DecompressPointer r2
    //     0xcf85e0: add             x2, x2, HEAP, lsl #32
    // 0xcf85e4: stur            x2, [fp, #-0x10]
    // 0xcf85e8: r0 = LoadClassIdInstr(r2)
    //     0xcf85e8: ldur            x0, [x2, #-1]
    //     0xcf85ec: ubfx            x0, x0, #0xc, #0x14
    // 0xcf85f0: lsl             x0, x0, #1
    // 0xcf85f4: r17 = 4224
    //     0xcf85f4: mov             x17, #0x1080
    // 0xcf85f8: cmp             w0, w17
    // 0xcf85fc: b.ne            #0xcf86e0
    // 0xcf8600: ldr             d0, [fp, #0x10]
    // 0xcf8604: LoadField: r0 = r2->field_7
    //     0xcf8604: ldur            w0, [x2, #7]
    // 0xcf8608: DecompressPointer r0
    //     0xcf8608: add             x0, x0, HEAP, lsl #32
    // 0xcf860c: r3 = inline_Allocate_Double()
    //     0xcf860c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xcf8610: add             x3, x3, #0x10
    //     0xcf8614: cmp             x4, x3
    //     0xcf8618: b.ls            #0xcf8764
    //     0xcf861c: str             x3, [THR, #0x60]  ; THR::top
    //     0xcf8620: sub             x3, x3, #0xf
    //     0xcf8624: mov             x4, #0xd108
    //     0xcf8628: movk            x4, #3, lsl #16
    //     0xcf862c: stur            x4, [x3, #-1]
    // 0xcf8630: StoreField: r3->field_7 = d0
    //     0xcf8630: stur            d0, [x3, #7]
    // 0xcf8634: stur            x3, [fp, #-8]
    // 0xcf8638: stp             x3, x0, [SP, #-0x10]!
    // 0xcf863c: r0 = *()
    //     0xcf863c: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8640: add             SP, SP, #0x10
    // 0xcf8644: mov             x1, x0
    // 0xcf8648: ldur            x0, [fp, #-0x10]
    // 0xcf864c: stur            x1, [fp, #-0x20]
    // 0xcf8650: LoadField: r2 = r0->field_b
    //     0xcf8650: ldur            w2, [x0, #0xb]
    // 0xcf8654: DecompressPointer r2
    //     0xcf8654: add             x2, x2, HEAP, lsl #32
    // 0xcf8658: ldur            x16, [fp, #-8]
    // 0xcf865c: stp             x16, x2, [SP, #-0x10]!
    // 0xcf8660: r0 = *()
    //     0xcf8660: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8664: add             SP, SP, #0x10
    // 0xcf8668: mov             x1, x0
    // 0xcf866c: ldur            x0, [fp, #-0x10]
    // 0xcf8670: stur            x1, [fp, #-0x28]
    // 0xcf8674: LoadField: r2 = r0->field_f
    //     0xcf8674: ldur            w2, [x0, #0xf]
    // 0xcf8678: DecompressPointer r2
    //     0xcf8678: add             x2, x2, HEAP, lsl #32
    // 0xcf867c: ldur            x16, [fp, #-8]
    // 0xcf8680: stp             x16, x2, [SP, #-0x10]!
    // 0xcf8684: r0 = *()
    //     0xcf8684: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf8688: add             SP, SP, #0x10
    // 0xcf868c: mov             x1, x0
    // 0xcf8690: ldur            x0, [fp, #-0x10]
    // 0xcf8694: stur            x1, [fp, #-0x30]
    // 0xcf8698: LoadField: r2 = r0->field_13
    //     0xcf8698: ldur            w2, [x0, #0x13]
    // 0xcf869c: DecompressPointer r2
    //     0xcf869c: add             x2, x2, HEAP, lsl #32
    // 0xcf86a0: ldur            x16, [fp, #-8]
    // 0xcf86a4: stp             x16, x2, [SP, #-0x10]!
    // 0xcf86a8: r0 = *()
    //     0xcf86a8: bl              #0x595c64  ; [dart:ui] Radius::*
    // 0xcf86ac: add             SP, SP, #0x10
    // 0xcf86b0: stur            x0, [fp, #-8]
    // 0xcf86b4: r0 = BorderRadius()
    //     0xcf86b4: bl              #0x596250  ; AllocateBorderRadiusStub -> BorderRadius (size=0x18)
    // 0xcf86b8: mov             x1, x0
    // 0xcf86bc: ldur            x0, [fp, #-0x20]
    // 0xcf86c0: StoreField: r1->field_7 = r0
    //     0xcf86c0: stur            w0, [x1, #7]
    // 0xcf86c4: ldur            x0, [fp, #-0x28]
    // 0xcf86c8: StoreField: r1->field_b = r0
    //     0xcf86c8: stur            w0, [x1, #0xb]
    // 0xcf86cc: ldur            x0, [fp, #-0x30]
    // 0xcf86d0: StoreField: r1->field_f = r0
    //     0xcf86d0: stur            w0, [x1, #0xf]
    // 0xcf86d4: ldur            x0, [fp, #-8]
    // 0xcf86d8: StoreField: r1->field_13 = r0
    //     0xcf86d8: stur            w0, [x1, #0x13]
    // 0xcf86dc: b               #0xcf8734
    // 0xcf86e0: ldr             d0, [fp, #0x10]
    // 0xcf86e4: mov             x0, x2
    // 0xcf86e8: r1 = inline_Allocate_Double()
    //     0xcf86e8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcf86ec: add             x1, x1, #0x10
    //     0xcf86f0: cmp             x2, x1
    //     0xcf86f4: b.ls            #0xcf8788
    //     0xcf86f8: str             x1, [THR, #0x60]  ; THR::top
    //     0xcf86fc: sub             x1, x1, #0xf
    //     0xcf8700: mov             x2, #0xd108
    //     0xcf8704: movk            x2, #3, lsl #16
    //     0xcf8708: stur            x2, [x1, #-1]
    // 0xcf870c: StoreField: r1->field_7 = d0
    //     0xcf870c: stur            d0, [x1, #7]
    // 0xcf8710: r2 = LoadClassIdInstr(r0)
    //     0xcf8710: ldur            x2, [x0, #-1]
    //     0xcf8714: ubfx            x2, x2, #0xc, #0x14
    // 0xcf8718: stp             x1, x0, [SP, #-0x10]!
    // 0xcf871c: mov             x0, x2
    // 0xcf8720: r0 = GDT[cid_x0 + -0xfd3]()
    //     0xcf8720: sub             lr, x0, #0xfd3
    //     0xcf8724: ldr             lr, [x21, lr, lsl #3]
    //     0xcf8728: blr             lr
    // 0xcf872c: add             SP, SP, #0x10
    // 0xcf8730: mov             x1, x0
    // 0xcf8734: ldur            x0, [fp, #-0x18]
    // 0xcf8738: stur            x1, [fp, #-8]
    // 0xcf873c: r0 = RoundedRectangleBorder()
    //     0xcf873c: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xcf8740: ldur            x1, [fp, #-8]
    // 0xcf8744: StoreField: r0->field_b = r1
    //     0xcf8744: stur            w1, [x0, #0xb]
    // 0xcf8748: ldur            x1, [fp, #-0x18]
    // 0xcf874c: StoreField: r0->field_7 = r1
    //     0xcf874c: stur            w1, [x0, #7]
    // 0xcf8750: LeaveFrame
    //     0xcf8750: mov             SP, fp
    //     0xcf8754: ldp             fp, lr, [SP], #0x10
    // 0xcf8758: ret
    //     0xcf8758: ret             
    // 0xcf875c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf875c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8760: b               #0xcf85b0
    // 0xcf8764: SaveReg d0
    //     0xcf8764: str             q0, [SP, #-0x10]!
    // 0xcf8768: stp             x1, x2, [SP, #-0x10]!
    // 0xcf876c: SaveReg r0
    //     0xcf876c: str             x0, [SP, #-8]!
    // 0xcf8770: r0 = AllocateDouble()
    //     0xcf8770: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf8774: mov             x3, x0
    // 0xcf8778: RestoreReg r0
    //     0xcf8778: ldr             x0, [SP], #8
    // 0xcf877c: ldp             x1, x2, [SP], #0x10
    // 0xcf8780: RestoreReg d0
    //     0xcf8780: ldr             q0, [SP], #0x10
    // 0xcf8784: b               #0xcf8630
    // 0xcf8788: SaveReg d0
    //     0xcf8788: str             q0, [SP, #-0x10]!
    // 0xcf878c: SaveReg r0
    //     0xcf878c: str             x0, [SP, #-8]!
    // 0xcf8790: r0 = AllocateDouble()
    //     0xcf8790: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf8794: mov             x1, x0
    // 0xcf8798: RestoreReg r0
    //     0xcf8798: ldr             x0, [SP], #8
    // 0xcf879c: RestoreReg d0
    //     0xcf879c: ldr             q0, [SP], #0x10
    // 0xcf87a0: b               #0xcf870c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xcf8d1c, size: 0x5c
    // 0xcf8d1c: EnterFrame
    //     0xcf8d1c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8d20: mov             fp, SP
    // 0xcf8d24: AllocStack(0x10)
    //     0xcf8d24: sub             SP, SP, #0x10
    // 0xcf8d28: ldr             x0, [fp, #0x10]
    // 0xcf8d2c: cmp             w0, NULL
    // 0xcf8d30: b.ne            #0xcf8d44
    // 0xcf8d34: ldr             x1, [fp, #0x18]
    // 0xcf8d38: LoadField: r0 = r1->field_7
    //     0xcf8d38: ldur            w0, [x1, #7]
    // 0xcf8d3c: DecompressPointer r0
    //     0xcf8d3c: add             x0, x0, HEAP, lsl #32
    // 0xcf8d40: b               #0xcf8d48
    // 0xcf8d44: ldr             x1, [fp, #0x18]
    // 0xcf8d48: stur            x0, [fp, #-0x10]
    // 0xcf8d4c: LoadField: r2 = r1->field_b
    //     0xcf8d4c: ldur            w2, [x1, #0xb]
    // 0xcf8d50: DecompressPointer r2
    //     0xcf8d50: add             x2, x2, HEAP, lsl #32
    // 0xcf8d54: stur            x2, [fp, #-8]
    // 0xcf8d58: r0 = RoundedRectangleBorder()
    //     0xcf8d58: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xcf8d5c: ldur            x1, [fp, #-8]
    // 0xcf8d60: StoreField: r0->field_b = r1
    //     0xcf8d60: stur            w1, [x0, #0xb]
    // 0xcf8d64: ldur            x1, [fp, #-0x10]
    // 0xcf8d68: StoreField: r0->field_7 = r1
    //     0xcf8d68: stur            w1, [x0, #7]
    // 0xcf8d6c: LeaveFrame
    //     0xcf8d6c: mov             SP, fp
    //     0xcf8d70: ldp             fp, lr, [SP], #0x10
    // 0xcf8d74: ret
    //     0xcf8d74: ret             
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0xcfa384, size: 0x120
    // 0xcfa384: EnterFrame
    //     0xcfa384: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa388: mov             fp, SP
    // 0xcfa38c: AllocStack(0x20)
    //     0xcfa38c: sub             SP, SP, #0x20
    // 0xcfa390: SetupParameters(RoundedRectangleBorder this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic textDirection = Null /* r0, fp-0x8 */})
    //     0xcfa390: mov             x0, x4
    //     0xcfa394: ldur            w1, [x0, #0x13]
    //     0xcfa398: add             x1, x1, HEAP, lsl #32
    //     0xcfa39c: sub             x2, x1, #4
    //     0xcfa3a0: add             x3, fp, w2, sxtw #2
    //     0xcfa3a4: ldr             x3, [x3, #0x18]
    //     0xcfa3a8: stur            x3, [fp, #-0x18]
    //     0xcfa3ac: add             x4, fp, w2, sxtw #2
    //     0xcfa3b0: ldr             x4, [x4, #0x10]
    //     0xcfa3b4: stur            x4, [fp, #-0x10]
    //     0xcfa3b8: ldur            w2, [x0, #0x1f]
    //     0xcfa3bc: add             x2, x2, HEAP, lsl #32
    //     0xcfa3c0: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0xcfa3c4: ldr             x16, [x16, #0xf10]
    //     0xcfa3c8: cmp             w2, w16
    //     0xcfa3cc: b.ne            #0xcfa3ec
    //     0xcfa3d0: ldur            w2, [x0, #0x23]
    //     0xcfa3d4: add             x2, x2, HEAP, lsl #32
    //     0xcfa3d8: sub             w0, w1, w2
    //     0xcfa3dc: add             x1, fp, w0, sxtw #2
    //     0xcfa3e0: ldr             x1, [x1, #8]
    //     0xcfa3e4: mov             x0, x1
    //     0xcfa3e8: b               #0xcfa3f0
    //     0xcfa3ec: mov             x0, NULL
    //     0xcfa3f0: stur            x0, [fp, #-8]
    // 0xcfa3f4: CheckStackOverflow
    //     0xcfa3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa3f8: cmp             SP, x16
    //     0xcfa3fc: b.ls            #0xcfa498
    // 0xcfa400: r0 = Path()
    //     0xcfa400: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcfa404: stur            x0, [fp, #-0x20]
    // 0xcfa408: SaveReg r0
    //     0xcfa408: str             x0, [SP, #-8]!
    // 0xcfa40c: r0 = _constructor()
    //     0xcfa40c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcfa410: add             SP, SP, #8
    // 0xcfa414: ldur            x0, [fp, #-0x18]
    // 0xcfa418: LoadField: r1 = r0->field_b
    //     0xcfa418: ldur            w1, [x0, #0xb]
    // 0xcfa41c: DecompressPointer r1
    //     0xcfa41c: add             x1, x1, HEAP, lsl #32
    // 0xcfa420: r0 = LoadClassIdInstr(r1)
    //     0xcfa420: ldur            x0, [x1, #-1]
    //     0xcfa424: ubfx            x0, x0, #0xc, #0x14
    // 0xcfa428: lsl             x0, x0, #1
    // 0xcfa42c: r17 = 4224
    //     0xcfa42c: mov             x17, #0x1080
    // 0xcfa430: cmp             w0, w17
    // 0xcfa434: b.ne            #0xcfa440
    // 0xcfa438: mov             x0, x1
    // 0xcfa43c: b               #0xcfa460
    // 0xcfa440: r0 = LoadClassIdInstr(r1)
    //     0xcfa440: ldur            x0, [x1, #-1]
    //     0xcfa444: ubfx            x0, x0, #0xc, #0x14
    // 0xcfa448: ldur            x16, [fp, #-8]
    // 0xcfa44c: stp             x16, x1, [SP, #-0x10]!
    // 0xcfa450: r0 = GDT[cid_x0 + -0x1000]()
    //     0xcfa450: sub             lr, x0, #1, lsl #12
    //     0xcfa454: ldr             lr, [x21, lr, lsl #3]
    //     0xcfa458: blr             lr
    // 0xcfa45c: add             SP, SP, #0x10
    // 0xcfa460: cmp             w0, NULL
    // 0xcfa464: b.eq            #0xcfa4a0
    // 0xcfa468: ldur            x16, [fp, #-0x10]
    // 0xcfa46c: stp             x16, x0, [SP, #-0x10]!
    // 0xcfa470: r0 = toRRect()
    //     0xcfa470: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xcfa474: add             SP, SP, #0x10
    // 0xcfa478: ldur            x16, [fp, #-0x20]
    // 0xcfa47c: stp             x0, x16, [SP, #-0x10]!
    // 0xcfa480: r0 = addRRect()
    //     0xcfa480: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0xcfa484: add             SP, SP, #0x10
    // 0xcfa488: ldur            x0, [fp, #-0x20]
    // 0xcfa48c: LeaveFrame
    //     0xcfa48c: mov             SP, fp
    //     0xcfa490: ldp             fp, lr, [SP], #0x10
    // 0xcfa494: ret
    //     0xcfa494: ret             
    // 0xcfa498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa498: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa49c: b               #0xcfa400
    // 0xcfa4a0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcfa4a0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

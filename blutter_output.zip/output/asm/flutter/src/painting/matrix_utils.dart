// lib: , url: package:flutter/src/painting/matrix_utils.dart

// class id: 1049372, size: 0x8
class :: {
}

// class id: 2079, size: 0x8, field offset: 0x8
abstract class MatrixUtils extends Object {

  static late final Float64List _minMax; // offset: 0xe84

  static _ transformPoint(/* No info */) {
    // ** addr: 0x62313c, size: 0x158
    // 0x62313c: EnterFrame
    //     0x62313c: stp             fp, lr, [SP, #-0x10]!
    //     0x623140: mov             fp, SP
    // 0x623144: AllocStack(0x18)
    //     0x623144: sub             SP, SP, #0x18
    // 0x623148: d0 = 1.000000
    //     0x623148: fmov            d0, #1.00000000
    // 0x62314c: ldr             x0, [fp, #0x18]
    // 0x623150: LoadField: r2 = r0->field_7
    //     0x623150: ldur            w2, [x0, #7]
    // 0x623154: DecompressPointer r2
    //     0x623154: add             x2, x2, HEAP, lsl #32
    // 0x623158: ldr             x0, [fp, #0x10]
    // 0x62315c: LoadField: d1 = r0->field_7
    //     0x62315c: ldur            d1, [x0, #7]
    // 0x623160: LoadField: d2 = r0->field_f
    //     0x623160: ldur            d2, [x0, #0xf]
    // 0x623164: LoadField: r0 = r2->field_13
    //     0x623164: ldur            w0, [x2, #0x13]
    // 0x623168: DecompressPointer r0
    //     0x623168: add             x0, x0, HEAP, lsl #32
    // 0x62316c: r3 = LoadInt32Instr(r0)
    //     0x62316c: sbfx            x3, x0, #1, #0x1f
    // 0x623170: mov             x0, x3
    // 0x623174: r1 = 0
    //     0x623174: mov             x1, #0
    // 0x623178: cmp             x1, x0
    // 0x62317c: b.hs            #0x623280
    // 0x623180: LoadField: d3 = r2->field_17
    //     0x623180: ldur            d3, [x2, #0x17]
    // 0x623184: fmul            d4, d3, d1
    // 0x623188: mov             x0, x3
    // 0x62318c: r1 = 4
    //     0x62318c: mov             x1, #4
    // 0x623190: cmp             x1, x0
    // 0x623194: b.hs            #0x623284
    // 0x623198: LoadField: d3 = r2->field_37
    //     0x623198: ldur            d3, [x2, #0x37]
    // 0x62319c: fmul            d5, d3, d2
    // 0x6231a0: fadd            d3, d4, d5
    // 0x6231a4: mov             x0, x3
    // 0x6231a8: r1 = 12
    //     0x6231a8: mov             x1, #0xc
    // 0x6231ac: cmp             x1, x0
    // 0x6231b0: b.hs            #0x623288
    // 0x6231b4: LoadField: d4 = r2->field_77
    //     0x6231b4: ldur            d4, [x2, #0x77]
    // 0x6231b8: fadd            d5, d3, d4
    // 0x6231bc: stur            d5, [fp, #-0x10]
    // 0x6231c0: LoadField: d3 = r2->field_1f
    //     0x6231c0: ldur            d3, [x2, #0x1f]
    // 0x6231c4: fmul            d4, d3, d1
    // 0x6231c8: LoadField: d3 = r2->field_3f
    //     0x6231c8: ldur            d3, [x2, #0x3f]
    // 0x6231cc: fmul            d6, d3, d2
    // 0x6231d0: fadd            d3, d4, d6
    // 0x6231d4: mov             x0, x3
    // 0x6231d8: r1 = 13
    //     0x6231d8: mov             x1, #0xd
    // 0x6231dc: cmp             x1, x0
    // 0x6231e0: b.hs            #0x62328c
    // 0x6231e4: LoadField: d4 = r2->field_7f
    //     0x6231e4: ldur            d4, [x2, #0x7f]
    // 0x6231e8: fadd            d6, d3, d4
    // 0x6231ec: stur            d6, [fp, #-8]
    // 0x6231f0: LoadField: d3 = r2->field_2f
    //     0x6231f0: ldur            d3, [x2, #0x2f]
    // 0x6231f4: fmul            d4, d3, d1
    // 0x6231f8: LoadField: d1 = r2->field_4f
    //     0x6231f8: ldur            d1, [x2, #0x4f]
    // 0x6231fc: fmul            d3, d1, d2
    // 0x623200: fadd            d1, d4, d3
    // 0x623204: mov             x0, x3
    // 0x623208: r1 = 15
    //     0x623208: mov             x1, #0xf
    // 0x62320c: cmp             x1, x0
    // 0x623210: b.hs            #0x623290
    // 0x623214: LoadField: d2 = r2->field_8f
    //     0x623214: ldur            d2, [x2, #0x8f]
    // 0x623218: fadd            d3, d1, d2
    // 0x62321c: fcmp            d3, d0
    // 0x623220: b.vs            #0x623248
    // 0x623224: b.ne            #0x623248
    // 0x623228: r0 = Offset()
    //     0x623228: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x62322c: ldur            d0, [fp, #-0x10]
    // 0x623230: StoreField: r0->field_7 = d0
    //     0x623230: stur            d0, [x0, #7]
    // 0x623234: ldur            d1, [fp, #-8]
    // 0x623238: StoreField: r0->field_f = d1
    //     0x623238: stur            d1, [x0, #0xf]
    // 0x62323c: LeaveFrame
    //     0x62323c: mov             SP, fp
    //     0x623240: ldp             fp, lr, [SP], #0x10
    // 0x623244: ret
    //     0x623244: ret             
    // 0x623248: mov             v0.16b, v5.16b
    // 0x62324c: mov             v1.16b, v6.16b
    // 0x623250: fdiv            d2, d0, d3
    // 0x623254: stur            d2, [fp, #-0x18]
    // 0x623258: fdiv            d0, d1, d3
    // 0x62325c: stur            d0, [fp, #-0x10]
    // 0x623260: r0 = Offset()
    //     0x623260: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x623264: ldur            d0, [fp, #-0x18]
    // 0x623268: StoreField: r0->field_7 = d0
    //     0x623268: stur            d0, [x0, #7]
    // 0x62326c: ldur            d0, [fp, #-0x10]
    // 0x623270: StoreField: r0->field_f = d0
    //     0x623270: stur            d0, [x0, #0xf]
    // 0x623274: LeaveFrame
    //     0x623274: mov             SP, fp
    //     0x623278: ldp             fp, lr, [SP], #0x10
    // 0x62327c: ret
    //     0x62327c: ret             
    // 0x623280: r0 = RangeErrorSharedWithFPURegs()
    //     0x623280: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x623284: r0 = RangeErrorSharedWithFPURegs()
    //     0x623284: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x623288: r0 = RangeErrorSharedWithFPURegs()
    //     0x623288: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x62328c: r0 = RangeErrorSharedWithFPURegs()
    //     0x62328c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x623290: r0 = RangeErrorSharedWithFPURegs()
    //     0x623290: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  static _ forceToPoint(/* No info */) {
    // ** addr: 0x640758, size: 0xd4
    // 0x640758: EnterFrame
    //     0x640758: stp             fp, lr, [SP, #-0x10]!
    //     0x64075c: mov             fp, SP
    // 0x640760: AllocStack(0x8)
    //     0x640760: sub             SP, SP, #8
    // 0x640764: CheckStackOverflow
    //     0x640764: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640768: cmp             SP, x16
    //     0x64076c: b.ls            #0x640824
    // 0x640770: r0 = Matrix4()
    //     0x640770: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x640774: r4 = 32
    //     0x640774: mov             x4, #0x20
    // 0x640778: stur            x0, [fp, #-8]
    // 0x64077c: r0 = AllocateFloat64Array()
    //     0x64077c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x640780: mov             x1, x0
    // 0x640784: ldur            x0, [fp, #-8]
    // 0x640788: StoreField: r0->field_7 = r1
    //     0x640788: stur            w1, [x0, #7]
    // 0x64078c: SaveReg r0
    //     0x64078c: str             x0, [SP, #-8]!
    // 0x640790: r0 = setIdentity()
    //     0x640790: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x640794: add             SP, SP, #8
    // 0x640798: ldr             x0, [fp, #0x10]
    // 0x64079c: LoadField: d0 = r0->field_7
    //     0x64079c: ldur            d0, [x0, #7]
    // 0x6407a0: r16 = 0.000000
    //     0x6407a0: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6407a4: stp             x16, NULL, [SP, #-0x10]!
    // 0x6407a8: r16 = 0.000000
    //     0x6407a8: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6407ac: r30 = 0.000000
    //     0x6407ac: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6407b0: stp             lr, x16, [SP, #-0x10]!
    // 0x6407b4: SaveReg d0
    //     0x6407b4: str             d0, [SP, #-8]!
    // 0x6407b8: r0 = Vector4()
    //     0x6407b8: bl              #0x623b34  ; [package:vector_math/vector_math_64.dart] Vector4::Vector4
    // 0x6407bc: add             SP, SP, #0x28
    // 0x6407c0: ldur            x16, [fp, #-8]
    // 0x6407c4: stp             xzr, x16, [SP, #-0x10]!
    // 0x6407c8: SaveReg r0
    //     0x6407c8: str             x0, [SP, #-8]!
    // 0x6407cc: r0 = setRow()
    //     0x6407cc: bl              #0x623a0c  ; [package:vector_math/vector_math_64.dart] Matrix4::setRow
    // 0x6407d0: add             SP, SP, #0x18
    // 0x6407d4: ldr             x0, [fp, #0x10]
    // 0x6407d8: LoadField: d0 = r0->field_f
    //     0x6407d8: ldur            d0, [x0, #0xf]
    // 0x6407dc: r16 = 0.000000
    //     0x6407dc: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6407e0: stp             x16, NULL, [SP, #-0x10]!
    // 0x6407e4: r16 = 0.000000
    //     0x6407e4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6407e8: r30 = 0.000000
    //     0x6407e8: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6407ec: stp             lr, x16, [SP, #-0x10]!
    // 0x6407f0: SaveReg d0
    //     0x6407f0: str             d0, [SP, #-8]!
    // 0x6407f4: r0 = Vector4()
    //     0x6407f4: bl              #0x623b34  ; [package:vector_math/vector_math_64.dart] Vector4::Vector4
    // 0x6407f8: add             SP, SP, #0x28
    // 0x6407fc: ldur            x16, [fp, #-8]
    // 0x640800: SaveReg r16
    //     0x640800: str             x16, [SP, #-8]!
    // 0x640804: r1 = 1
    //     0x640804: mov             x1, #1
    // 0x640808: stp             x0, x1, [SP, #-0x10]!
    // 0x64080c: r0 = setRow()
    //     0x64080c: bl              #0x623a0c  ; [package:vector_math/vector_math_64.dart] Matrix4::setRow
    // 0x640810: add             SP, SP, #0x18
    // 0x640814: ldur            x0, [fp, #-8]
    // 0x640818: LeaveFrame
    //     0x640818: mov             SP, fp
    //     0x64081c: ldp             fp, lr, [SP], #0x10
    // 0x640820: ret
    //     0x640820: ret             
    // 0x640824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640824: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640828: b               #0x640770
  }
  static _ transformRect(/* No info */) {
    // ** addr: 0x6431fc, size: 0x400
    // 0x6431fc: EnterFrame
    //     0x6431fc: stp             fp, lr, [SP, #-0x10]!
    //     0x643200: mov             fp, SP
    // 0x643204: AllocStack(0x20)
    //     0x643204: sub             SP, SP, #0x20
    // 0x643208: CheckStackOverflow
    //     0x643208: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64320c: cmp             SP, x16
    //     0x643210: b.ls            #0x6435dc
    // 0x643214: ldr             x0, [fp, #0x18]
    // 0x643218: LoadField: r2 = r0->field_7
    //     0x643218: ldur            w2, [x0, #7]
    // 0x64321c: DecompressPointer r2
    //     0x64321c: add             x2, x2, HEAP, lsl #32
    // 0x643220: ldr             x1, [fp, #0x10]
    // 0x643224: LoadField: d0 = r1->field_7
    //     0x643224: ldur            d0, [x1, #7]
    // 0x643228: LoadField: d1 = r1->field_f
    //     0x643228: ldur            d1, [x1, #0xf]
    // 0x64322c: LoadField: d2 = r1->field_17
    //     0x64322c: ldur            d2, [x1, #0x17]
    // 0x643230: fsub            d3, d2, d0
    // 0x643234: LoadField: d2 = r1->field_1f
    //     0x643234: ldur            d2, [x1, #0x1f]
    // 0x643238: fsub            d4, d2, d1
    // 0x64323c: mov             x3, v3.d[0]
    // 0x643240: and             x3, x3, #0x7fffffffffffffff
    // 0x643244: r17 = 9218868437227405312
    //     0x643244: mov             x17, #0x7ff0000000000000
    // 0x643248: cmp             x3, x17
    // 0x64324c: b.eq            #0x6435c4
    // 0x643250: fcmp            d3, d3
    // 0x643254: b.vs            #0x6435c4
    // 0x643258: mov             x3, v4.d[0]
    // 0x64325c: and             x3, x3, #0x7fffffffffffffff
    // 0x643260: r17 = 9218868437227405312
    //     0x643260: mov             x17, #0x7ff0000000000000
    // 0x643264: cmp             x3, x17
    // 0x643268: b.eq            #0x6435c4
    // 0x64326c: fcmp            d4, d4
    // 0x643270: b.vs            #0x6435c4
    // 0x643274: d2 = 0.000000
    //     0x643274: eor             v2.16b, v2.16b, v2.16b
    // 0x643278: LoadField: r0 = r2->field_13
    //     0x643278: ldur            w0, [x2, #0x13]
    // 0x64327c: DecompressPointer r0
    //     0x64327c: add             x0, x0, HEAP, lsl #32
    // 0x643280: r3 = LoadInt32Instr(r0)
    //     0x643280: sbfx            x3, x0, #1, #0x1f
    // 0x643284: mov             x0, x3
    // 0x643288: r1 = 0
    //     0x643288: mov             x1, #0
    // 0x64328c: cmp             x1, x0
    // 0x643290: b.hs            #0x6435e4
    // 0x643294: LoadField: d5 = r2->field_17
    //     0x643294: ldur            d5, [x2, #0x17]
    // 0x643298: fmul            d6, d5, d3
    // 0x64329c: mov             x0, x3
    // 0x6432a0: r1 = 4
    //     0x6432a0: mov             x1, #4
    // 0x6432a4: cmp             x1, x0
    // 0x6432a8: b.hs            #0x6435e8
    // 0x6432ac: LoadField: d7 = r2->field_37
    //     0x6432ac: ldur            d7, [x2, #0x37]
    // 0x6432b0: fmul            d8, d7, d4
    // 0x6432b4: fmul            d9, d5, d0
    // 0x6432b8: fmul            d5, d7, d1
    // 0x6432bc: fadd            d7, d9, d5
    // 0x6432c0: mov             x0, x3
    // 0x6432c4: r1 = 12
    //     0x6432c4: mov             x1, #0xc
    // 0x6432c8: cmp             x1, x0
    // 0x6432cc: b.hs            #0x6435ec
    // 0x6432d0: LoadField: d5 = r2->field_77
    //     0x6432d0: ldur            d5, [x2, #0x77]
    // 0x6432d4: fadd            d9, d7, d5
    // 0x6432d8: LoadField: d5 = r2->field_1f
    //     0x6432d8: ldur            d5, [x2, #0x1f]
    // 0x6432dc: fmul            d7, d5, d3
    // 0x6432e0: LoadField: d10 = r2->field_3f
    //     0x6432e0: ldur            d10, [x2, #0x3f]
    // 0x6432e4: fmul            d11, d10, d4
    // 0x6432e8: fmul            d12, d5, d0
    // 0x6432ec: fmul            d5, d10, d1
    // 0x6432f0: fadd            d10, d12, d5
    // 0x6432f4: mov             x0, x3
    // 0x6432f8: r1 = 13
    //     0x6432f8: mov             x1, #0xd
    // 0x6432fc: cmp             x1, x0
    // 0x643300: b.hs            #0x6435f0
    // 0x643304: LoadField: d5 = r2->field_7f
    //     0x643304: ldur            d5, [x2, #0x7f]
    // 0x643308: fadd            d12, d10, d5
    // 0x64330c: LoadField: d5 = r2->field_2f
    //     0x64330c: ldur            d5, [x2, #0x2f]
    // 0x643310: fcmp            d5, d2
    // 0x643314: b.vs            #0x643420
    // 0x643318: b.ne            #0x643420
    // 0x64331c: LoadField: d10 = r2->field_4f
    //     0x64331c: ldur            d10, [x2, #0x4f]
    // 0x643320: fcmp            d10, d2
    // 0x643324: b.vs            #0x643420
    // 0x643328: b.ne            #0x643420
    // 0x64332c: d10 = 1.000000
    //     0x64332c: fmov            d10, #1.00000000
    // 0x643330: mov             x0, x3
    // 0x643334: r1 = 15
    //     0x643334: mov             x1, #0xf
    // 0x643338: cmp             x1, x0
    // 0x64333c: b.hs            #0x6435f4
    // 0x643340: LoadField: d13 = r2->field_8f
    //     0x643340: ldur            d13, [x2, #0x8f]
    // 0x643344: fcmp            d13, d10
    // 0x643348: b.vs            #0x643420
    // 0x64334c: b.ne            #0x643420
    // 0x643350: fcmp            d6, d2
    // 0x643354: b.vs            #0x64336c
    // 0x643358: b.ge            #0x64336c
    // 0x64335c: fadd            d0, d9, d6
    // 0x643360: mov             v1.16b, v0.16b
    // 0x643364: mov             v0.16b, v9.16b
    // 0x643368: b               #0x643374
    // 0x64336c: fadd            d0, d9, d6
    // 0x643370: mov             v1.16b, v9.16b
    // 0x643374: fcmp            d8, d2
    // 0x643378: b.vs            #0x64338c
    // 0x64337c: b.ge            #0x64338c
    // 0x643380: fadd            d3, d1, d8
    // 0x643384: mov             v1.16b, v3.16b
    // 0x643388: b               #0x643394
    // 0x64338c: fadd            d3, d0, d8
    // 0x643390: mov             v0.16b, v3.16b
    // 0x643394: stur            d1, [fp, #-0x18]
    // 0x643398: stur            d0, [fp, #-0x20]
    // 0x64339c: fcmp            d7, d2
    // 0x6433a0: b.vs            #0x6433b8
    // 0x6433a4: b.ge            #0x6433b8
    // 0x6433a8: fadd            d3, d12, d7
    // 0x6433ac: mov             v4.16b, v3.16b
    // 0x6433b0: mov             v3.16b, v12.16b
    // 0x6433b4: b               #0x6433c0
    // 0x6433b8: fadd            d3, d12, d7
    // 0x6433bc: mov             v4.16b, v12.16b
    // 0x6433c0: fcmp            d11, d2
    // 0x6433c4: b.vs            #0x6433e0
    // 0x6433c8: b.ge            #0x6433e0
    // 0x6433cc: fadd            d2, d4, d11
    // 0x6433d0: mov             v31.16b, v3.16b
    // 0x6433d4: mov             v3.16b, v2.16b
    // 0x6433d8: mov             v2.16b, v31.16b
    // 0x6433dc: b               #0x6433e8
    // 0x6433e0: fadd            d2, d3, d11
    // 0x6433e4: mov             v3.16b, v4.16b
    // 0x6433e8: stur            d3, [fp, #-8]
    // 0x6433ec: stur            d2, [fp, #-0x10]
    // 0x6433f0: r0 = Rect()
    //     0x6433f0: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x6433f4: ldur            d0, [fp, #-0x18]
    // 0x6433f8: StoreField: r0->field_7 = d0
    //     0x6433f8: stur            d0, [x0, #7]
    // 0x6433fc: ldur            d0, [fp, #-8]
    // 0x643400: StoreField: r0->field_f = d0
    //     0x643400: stur            d0, [x0, #0xf]
    // 0x643404: ldur            d0, [fp, #-0x20]
    // 0x643408: StoreField: r0->field_17 = d0
    //     0x643408: stur            d0, [x0, #0x17]
    // 0x64340c: ldur            d0, [fp, #-0x10]
    // 0x643410: StoreField: r0->field_1f = d0
    //     0x643410: stur            d0, [x0, #0x1f]
    // 0x643414: LeaveFrame
    //     0x643414: mov             SP, fp
    //     0x643418: ldp             fp, lr, [SP], #0x10
    // 0x64341c: ret
    //     0x64341c: ret             
    // 0x643420: fmul            d2, d5, d3
    // 0x643424: LoadField: d3 = r2->field_4f
    //     0x643424: ldur            d3, [x2, #0x4f]
    // 0x643428: fmul            d10, d3, d4
    // 0x64342c: fmul            d4, d5, d0
    // 0x643430: fmul            d0, d3, d1
    // 0x643434: fadd            d1, d4, d0
    // 0x643438: mov             x0, x3
    // 0x64343c: r1 = 15
    //     0x64343c: mov             x1, #0xf
    // 0x643440: cmp             x1, x0
    // 0x643444: b.hs            #0x6435f8
    // 0x643448: LoadField: d0 = r2->field_8f
    //     0x643448: ldur            d0, [x2, #0x8f]
    // 0x64344c: fadd            d3, d1, d0
    // 0x643450: fdiv            d0, d9, d3
    // 0x643454: fdiv            d1, d12, d3
    // 0x643458: fadd            d4, d9, d6
    // 0x64345c: fadd            d5, d3, d2
    // 0x643460: fdiv            d2, d4, d5
    // 0x643464: fadd            d6, d12, d7
    // 0x643468: fdiv            d7, d6, d5
    // 0x64346c: fadd            d13, d9, d8
    // 0x643470: fadd            d9, d3, d10
    // 0x643474: fdiv            d3, d13, d9
    // 0x643478: fadd            d13, d12, d11
    // 0x64347c: fdiv            d12, d13, d9
    // 0x643480: fadd            d9, d4, d8
    // 0x643484: fadd            d4, d5, d10
    // 0x643488: fdiv            d5, d9, d4
    // 0x64348c: fadd            d8, d6, d11
    // 0x643490: fdiv            d6, d8, d4
    // 0x643494: fcmp            d0, d2
    // 0x643498: b.vs            #0x6434a8
    // 0x64349c: b.ge            #0x6434a8
    // 0x6434a0: mov             v4.16b, v0.16b
    // 0x6434a4: b               #0x6434ac
    // 0x6434a8: mov             v4.16b, v2.16b
    // 0x6434ac: fcmp            d3, d5
    // 0x6434b0: b.vs            #0x6434c0
    // 0x6434b4: b.ge            #0x6434c0
    // 0x6434b8: mov             v8.16b, v3.16b
    // 0x6434bc: b               #0x6434c4
    // 0x6434c0: mov             v8.16b, v5.16b
    // 0x6434c4: fcmp            d4, d8
    // 0x6434c8: b.vs            #0x6434d0
    // 0x6434cc: b.lt            #0x6434d4
    // 0x6434d0: mov             v4.16b, v8.16b
    // 0x6434d4: stur            d4, [fp, #-0x20]
    // 0x6434d8: fcmp            d1, d7
    // 0x6434dc: b.vs            #0x6434ec
    // 0x6434e0: b.ge            #0x6434ec
    // 0x6434e4: mov             v8.16b, v1.16b
    // 0x6434e8: b               #0x6434f0
    // 0x6434ec: mov             v8.16b, v7.16b
    // 0x6434f0: fcmp            d12, d6
    // 0x6434f4: b.vs            #0x643504
    // 0x6434f8: b.ge            #0x643504
    // 0x6434fc: mov             v9.16b, v12.16b
    // 0x643500: b               #0x643508
    // 0x643504: mov             v9.16b, v6.16b
    // 0x643508: fcmp            d8, d9
    // 0x64350c: b.vs            #0x643514
    // 0x643510: b.lt            #0x643518
    // 0x643514: mov             v8.16b, v9.16b
    // 0x643518: stur            d8, [fp, #-0x18]
    // 0x64351c: fcmp            d0, d2
    // 0x643520: b.vs            #0x643528
    // 0x643524: b.gt            #0x64352c
    // 0x643528: mov             v0.16b, v2.16b
    // 0x64352c: fcmp            d3, d5
    // 0x643530: b.vs            #0x643540
    // 0x643534: b.le            #0x643540
    // 0x643538: mov             v2.16b, v3.16b
    // 0x64353c: b               #0x643544
    // 0x643540: mov             v2.16b, v5.16b
    // 0x643544: fcmp            d0, d2
    // 0x643548: b.vs            #0x643550
    // 0x64354c: b.gt            #0x643554
    // 0x643550: mov             v0.16b, v2.16b
    // 0x643554: stur            d0, [fp, #-0x10]
    // 0x643558: fcmp            d1, d7
    // 0x64355c: b.vs            #0x643564
    // 0x643560: b.gt            #0x643568
    // 0x643564: mov             v1.16b, v7.16b
    // 0x643568: fcmp            d12, d6
    // 0x64356c: b.vs            #0x64357c
    // 0x643570: b.le            #0x64357c
    // 0x643574: mov             v2.16b, v12.16b
    // 0x643578: b               #0x643580
    // 0x64357c: mov             v2.16b, v6.16b
    // 0x643580: fcmp            d1, d2
    // 0x643584: b.vs            #0x64358c
    // 0x643588: b.gt            #0x643590
    // 0x64358c: mov             v1.16b, v2.16b
    // 0x643590: stur            d1, [fp, #-8]
    // 0x643594: r0 = Rect()
    //     0x643594: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x643598: ldur            d0, [fp, #-0x20]
    // 0x64359c: StoreField: r0->field_7 = d0
    //     0x64359c: stur            d0, [x0, #7]
    // 0x6435a0: ldur            d0, [fp, #-0x18]
    // 0x6435a4: StoreField: r0->field_f = d0
    //     0x6435a4: stur            d0, [x0, #0xf]
    // 0x6435a8: ldur            d0, [fp, #-0x10]
    // 0x6435ac: StoreField: r0->field_17 = d0
    //     0x6435ac: stur            d0, [x0, #0x17]
    // 0x6435b0: ldur            d0, [fp, #-8]
    // 0x6435b4: StoreField: r0->field_1f = d0
    //     0x6435b4: stur            d0, [x0, #0x1f]
    // 0x6435b8: LeaveFrame
    //     0x6435b8: mov             SP, fp
    //     0x6435bc: ldp             fp, lr, [SP], #0x10
    // 0x6435c0: ret
    //     0x6435c0: ret             
    // 0x6435c4: stp             x1, x0, [SP, #-0x10]!
    // 0x6435c8: r0 = _safeTransformRect()
    //     0x6435c8: bl              #0x6435fc  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_safeTransformRect
    // 0x6435cc: add             SP, SP, #0x10
    // 0x6435d0: LeaveFrame
    //     0x6435d0: mov             SP, fp
    //     0x6435d4: ldp             fp, lr, [SP], #0x10
    // 0x6435d8: ret
    //     0x6435d8: ret             
    // 0x6435dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6435dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6435e0: b               #0x643214
    // 0x6435e4: r0 = RangeErrorSharedWithFPURegs()
    //     0x6435e4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6435e8: r0 = RangeErrorSharedWithFPURegs()
    //     0x6435e8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6435ec: r0 = RangeErrorSharedWithFPURegs()
    //     0x6435ec: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6435f0: r0 = RangeErrorSharedWithFPURegs()
    //     0x6435f0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6435f4: r0 = RangeErrorSharedWithFPURegs()
    //     0x6435f4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6435f8: r0 = RangeErrorSharedWithFPURegs()
    //     0x6435f8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  static _ _safeTransformRect(/* No info */) {
    // ** addr: 0x6435fc, size: 0x2dc
    // 0x6435fc: EnterFrame
    //     0x6435fc: stp             fp, lr, [SP, #-0x10]!
    //     0x643600: mov             fp, SP
    // 0x643604: AllocStack(0x40)
    //     0x643604: sub             SP, SP, #0x40
    // 0x643608: d0 = 0.000000
    //     0x643608: eor             v0.16b, v0.16b, v0.16b
    // 0x64360c: CheckStackOverflow
    //     0x64360c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x643610: cmp             SP, x16
    //     0x643614: b.ls            #0x643874
    // 0x643618: ldr             x0, [fp, #0x18]
    // 0x64361c: LoadField: r2 = r0->field_7
    //     0x64361c: ldur            w2, [x0, #7]
    // 0x643620: DecompressPointer r2
    //     0x643620: add             x2, x2, HEAP, lsl #32
    // 0x643624: stur            x2, [fp, #-0x18]
    // 0x643628: LoadField: r0 = r2->field_13
    //     0x643628: ldur            w0, [x2, #0x13]
    // 0x64362c: DecompressPointer r0
    //     0x64362c: add             x0, x0, HEAP, lsl #32
    // 0x643630: r3 = LoadInt32Instr(r0)
    //     0x643630: sbfx            x3, x0, #1, #0x1f
    // 0x643634: mov             x0, x3
    // 0x643638: r1 = 3
    //     0x643638: mov             x1, #3
    // 0x64363c: cmp             x1, x0
    // 0x643640: b.hs            #0x64387c
    // 0x643644: LoadField: d1 = r2->field_2f
    //     0x643644: ldur            d1, [x2, #0x2f]
    // 0x643648: fcmp            d1, d0
    // 0x64364c: b.vs            #0x6436ac
    // 0x643650: b.ne            #0x6436ac
    // 0x643654: mov             x0, x3
    // 0x643658: r1 = 7
    //     0x643658: mov             x1, #7
    // 0x64365c: cmp             x1, x0
    // 0x643660: b.hs            #0x643880
    // 0x643664: LoadField: d1 = r2->field_4f
    //     0x643664: ldur            d1, [x2, #0x4f]
    // 0x643668: fcmp            d1, d0
    // 0x64366c: b.vs            #0x6436ac
    // 0x643670: b.ne            #0x6436ac
    // 0x643674: d0 = 1.000000
    //     0x643674: fmov            d0, #1.00000000
    // 0x643678: mov             x0, x3
    // 0x64367c: r1 = 15
    //     0x64367c: mov             x1, #0xf
    // 0x643680: cmp             x1, x0
    // 0x643684: b.hs            #0x643884
    // 0x643688: LoadField: d1 = r2->field_8f
    //     0x643688: ldur            d1, [x2, #0x8f]
    // 0x64368c: fcmp            d1, d0
    // 0x643690: b.vs            #0x643698
    // 0x643694: b.eq            #0x6436a0
    // 0x643698: r0 = false
    //     0x643698: add             x0, NULL, #0x30  ; false
    // 0x64369c: b               #0x6436a4
    // 0x6436a0: r0 = true
    //     0x6436a0: add             x0, NULL, #0x20  ; true
    // 0x6436a4: mov             x1, x0
    // 0x6436a8: b               #0x6436b0
    // 0x6436ac: r1 = false
    //     0x6436ac: add             x1, NULL, #0x30  ; false
    // 0x6436b0: ldr             x0, [fp, #0x10]
    // 0x6436b4: stur            x1, [fp, #-0x10]
    // 0x6436b8: LoadField: d0 = r0->field_7
    //     0x6436b8: ldur            d0, [x0, #7]
    // 0x6436bc: LoadField: d1 = r0->field_f
    //     0x6436bc: ldur            d1, [x0, #0xf]
    // 0x6436c0: stur            d1, [fp, #-0x28]
    // 0x6436c4: r3 = inline_Allocate_Double()
    //     0x6436c4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x6436c8: add             x3, x3, #0x10
    //     0x6436cc: cmp             x4, x3
    //     0x6436d0: b.ls            #0x643888
    //     0x6436d4: str             x3, [THR, #0x60]  ; THR::top
    //     0x6436d8: sub             x3, x3, #0xf
    //     0x6436dc: mov             x4, #0xd108
    //     0x6436e0: movk            x4, #3, lsl #16
    //     0x6436e4: stur            x4, [x3, #-1]
    // 0x6436e8: StoreField: r3->field_7 = d0
    //     0x6436e8: stur            d0, [x3, #7]
    // 0x6436ec: stur            x3, [fp, #-8]
    // 0x6436f0: stp             x3, x2, [SP, #-0x10]!
    // 0x6436f4: SaveReg d1
    //     0x6436f4: str             d1, [SP, #-8]!
    // 0x6436f8: r16 = true
    //     0x6436f8: add             x16, NULL, #0x20  ; true
    // 0x6436fc: stp             x1, x16, [SP, #-0x10]!
    // 0x643700: r0 = _accumulate()
    //     0x643700: bl              #0x6438d8  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_accumulate
    // 0x643704: add             SP, SP, #0x28
    // 0x643708: ldr             x0, [fp, #0x10]
    // 0x64370c: LoadField: d0 = r0->field_17
    //     0x64370c: ldur            d0, [x0, #0x17]
    // 0x643710: r1 = inline_Allocate_Double()
    //     0x643710: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x643714: add             x1, x1, #0x10
    //     0x643718: cmp             x2, x1
    //     0x64371c: b.ls            #0x6438ac
    //     0x643720: str             x1, [THR, #0x60]  ; THR::top
    //     0x643724: sub             x1, x1, #0xf
    //     0x643728: mov             x2, #0xd108
    //     0x64372c: movk            x2, #3, lsl #16
    //     0x643730: stur            x2, [x1, #-1]
    // 0x643734: StoreField: r1->field_7 = d0
    //     0x643734: stur            d0, [x1, #7]
    // 0x643738: stur            x1, [fp, #-0x20]
    // 0x64373c: ldur            x16, [fp, #-0x18]
    // 0x643740: stp             x1, x16, [SP, #-0x10]!
    // 0x643744: ldur            d0, [fp, #-0x28]
    // 0x643748: SaveReg d0
    //     0x643748: str             d0, [SP, #-8]!
    // 0x64374c: r16 = false
    //     0x64374c: add             x16, NULL, #0x30  ; false
    // 0x643750: ldur            lr, [fp, #-0x10]
    // 0x643754: stp             lr, x16, [SP, #-0x10]!
    // 0x643758: r0 = _accumulate()
    //     0x643758: bl              #0x6438d8  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_accumulate
    // 0x64375c: add             SP, SP, #0x28
    // 0x643760: ldr             x0, [fp, #0x10]
    // 0x643764: LoadField: d0 = r0->field_1f
    //     0x643764: ldur            d0, [x0, #0x1f]
    // 0x643768: stur            d0, [fp, #-0x28]
    // 0x64376c: ldur            x16, [fp, #-0x18]
    // 0x643770: ldur            lr, [fp, #-8]
    // 0x643774: stp             lr, x16, [SP, #-0x10]!
    // 0x643778: SaveReg d0
    //     0x643778: str             d0, [SP, #-8]!
    // 0x64377c: r16 = false
    //     0x64377c: add             x16, NULL, #0x30  ; false
    // 0x643780: ldur            lr, [fp, #-0x10]
    // 0x643784: stp             lr, x16, [SP, #-0x10]!
    // 0x643788: r0 = _accumulate()
    //     0x643788: bl              #0x6438d8  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_accumulate
    // 0x64378c: add             SP, SP, #0x28
    // 0x643790: ldur            x16, [fp, #-0x18]
    // 0x643794: ldur            lr, [fp, #-0x20]
    // 0x643798: stp             lr, x16, [SP, #-0x10]!
    // 0x64379c: ldur            d0, [fp, #-0x28]
    // 0x6437a0: SaveReg d0
    //     0x6437a0: str             d0, [SP, #-8]!
    // 0x6437a4: r16 = false
    //     0x6437a4: add             x16, NULL, #0x30  ; false
    // 0x6437a8: ldur            lr, [fp, #-0x10]
    // 0x6437ac: stp             lr, x16, [SP, #-0x10]!
    // 0x6437b0: r0 = _accumulate()
    //     0x6437b0: bl              #0x6438d8  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_accumulate
    // 0x6437b4: add             SP, SP, #0x28
    // 0x6437b8: r0 = InitLateStaticField(0xe84) // [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_minMax
    //     0x6437b8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6437bc: ldr             x0, [x0, #0x1d08]
    //     0x6437c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6437c4: cmp             w0, w16
    //     0x6437c8: b.ne            #0x6437d4
    //     0x6437cc: ldr             x2, [PP, #0x7348]  ; [pp+0x7348] Field <MatrixUtils._minMax@868374251>: static late final (offset: 0xe84)
    //     0x6437d0: bl              #0xd67cdc
    // 0x6437d4: mov             x2, x0
    // 0x6437d8: LoadField: r0 = r2->field_13
    //     0x6437d8: ldur            w0, [x2, #0x13]
    // 0x6437dc: DecompressPointer r0
    //     0x6437dc: add             x0, x0, HEAP, lsl #32
    // 0x6437e0: r3 = LoadInt32Instr(r0)
    //     0x6437e0: sbfx            x3, x0, #1, #0x1f
    // 0x6437e4: mov             x0, x3
    // 0x6437e8: r1 = 0
    //     0x6437e8: mov             x1, #0
    // 0x6437ec: cmp             x1, x0
    // 0x6437f0: b.hs            #0x6438c8
    // 0x6437f4: LoadField: d0 = r2->field_17
    //     0x6437f4: ldur            d0, [x2, #0x17]
    // 0x6437f8: mov             x0, x3
    // 0x6437fc: stur            d0, [fp, #-0x40]
    // 0x643800: r1 = 1
    //     0x643800: mov             x1, #1
    // 0x643804: cmp             x1, x0
    // 0x643808: b.hs            #0x6438cc
    // 0x64380c: LoadField: d1 = r2->field_1f
    //     0x64380c: ldur            d1, [x2, #0x1f]
    // 0x643810: mov             x0, x3
    // 0x643814: stur            d1, [fp, #-0x38]
    // 0x643818: r1 = 2
    //     0x643818: mov             x1, #2
    // 0x64381c: cmp             x1, x0
    // 0x643820: b.hs            #0x6438d0
    // 0x643824: LoadField: d2 = r2->field_27
    //     0x643824: ldur            d2, [x2, #0x27]
    // 0x643828: mov             x0, x3
    // 0x64382c: stur            d2, [fp, #-0x30]
    // 0x643830: r1 = 3
    //     0x643830: mov             x1, #3
    // 0x643834: cmp             x1, x0
    // 0x643838: b.hs            #0x6438d4
    // 0x64383c: LoadField: d3 = r2->field_2f
    //     0x64383c: ldur            d3, [x2, #0x2f]
    // 0x643840: stur            d3, [fp, #-0x28]
    // 0x643844: r0 = Rect()
    //     0x643844: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x643848: ldur            d0, [fp, #-0x40]
    // 0x64384c: StoreField: r0->field_7 = d0
    //     0x64384c: stur            d0, [x0, #7]
    // 0x643850: ldur            d0, [fp, #-0x38]
    // 0x643854: StoreField: r0->field_f = d0
    //     0x643854: stur            d0, [x0, #0xf]
    // 0x643858: ldur            d0, [fp, #-0x30]
    // 0x64385c: StoreField: r0->field_17 = d0
    //     0x64385c: stur            d0, [x0, #0x17]
    // 0x643860: ldur            d0, [fp, #-0x28]
    // 0x643864: StoreField: r0->field_1f = d0
    //     0x643864: stur            d0, [x0, #0x1f]
    // 0x643868: LeaveFrame
    //     0x643868: mov             SP, fp
    //     0x64386c: ldp             fp, lr, [SP], #0x10
    // 0x643870: ret
    //     0x643870: ret             
    // 0x643874: r0 = StackOverflowSharedWithFPURegs()
    //     0x643874: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x643878: b               #0x643618
    // 0x64387c: r0 = RangeErrorSharedWithFPURegs()
    //     0x64387c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643880: r0 = RangeErrorSharedWithFPURegs()
    //     0x643880: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643884: r0 = RangeErrorSharedWithFPURegs()
    //     0x643884: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643888: stp             q0, q1, [SP, #-0x20]!
    // 0x64388c: stp             x1, x2, [SP, #-0x10]!
    // 0x643890: SaveReg r0
    //     0x643890: str             x0, [SP, #-8]!
    // 0x643894: r0 = AllocateDouble()
    //     0x643894: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x643898: mov             x3, x0
    // 0x64389c: RestoreReg r0
    //     0x64389c: ldr             x0, [SP], #8
    // 0x6438a0: ldp             x1, x2, [SP], #0x10
    // 0x6438a4: ldp             q0, q1, [SP], #0x20
    // 0x6438a8: b               #0x6436e8
    // 0x6438ac: SaveReg d0
    //     0x6438ac: str             q0, [SP, #-0x10]!
    // 0x6438b0: SaveReg r0
    //     0x6438b0: str             x0, [SP, #-8]!
    // 0x6438b4: r0 = AllocateDouble()
    //     0x6438b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6438b8: mov             x1, x0
    // 0x6438bc: RestoreReg r0
    //     0x6438bc: ldr             x0, [SP], #8
    // 0x6438c0: RestoreReg d0
    //     0x6438c0: ldr             q0, [SP], #0x10
    // 0x6438c4: b               #0x643734
    // 0x6438c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6438c8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6438cc: r0 = RangeErrorSharedWithFPURegs()
    //     0x6438cc: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6438d0: r0 = RangeErrorSharedWithFPURegs()
    //     0x6438d0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x6438d4: r0 = RangeErrorSharedWithFPURegs()
    //     0x6438d4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  static _ _accumulate(/* No info */) {
    // ** addr: 0x6438d8, size: 0x2d8
    // 0x6438d8: EnterFrame
    //     0x6438d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6438dc: mov             fp, SP
    // 0x6438e0: AllocStack(0x10)
    //     0x6438e0: sub             SP, SP, #0x10
    // 0x6438e4: CheckStackOverflow
    //     0x6438e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6438e8: cmp             SP, x16
    //     0x6438ec: b.ls            #0x643b70
    // 0x6438f0: ldr             x0, [fp, #0x10]
    // 0x6438f4: tbnz            w0, #4, #0x64390c
    // 0x6438f8: ldr             x3, [fp, #0x30]
    // 0x6438fc: ldr             x2, [fp, #0x28]
    // 0x643900: ldr             d1, [fp, #0x20]
    // 0x643904: d0 = 1.000000
    //     0x643904: fmov            d0, #1.00000000
    // 0x643908: b               #0x643980
    // 0x64390c: ldr             x3, [fp, #0x30]
    // 0x643910: ldr             x2, [fp, #0x28]
    // 0x643914: ldr             d1, [fp, #0x20]
    // 0x643918: d0 = 1.000000
    //     0x643918: fmov            d0, #1.00000000
    // 0x64391c: LoadField: r0 = r3->field_13
    //     0x64391c: ldur            w0, [x3, #0x13]
    // 0x643920: DecompressPointer r0
    //     0x643920: add             x0, x0, HEAP, lsl #32
    // 0x643924: r4 = LoadInt32Instr(r0)
    //     0x643924: sbfx            x4, x0, #1, #0x1f
    // 0x643928: mov             x0, x4
    // 0x64392c: r1 = 3
    //     0x64392c: mov             x1, #3
    // 0x643930: cmp             x1, x0
    // 0x643934: b.hs            #0x643b78
    // 0x643938: LoadField: d2 = r3->field_2f
    //     0x643938: ldur            d2, [x3, #0x2f]
    // 0x64393c: LoadField: d3 = r2->field_7
    //     0x64393c: ldur            d3, [x2, #7]
    // 0x643940: fmul            d4, d2, d3
    // 0x643944: mov             x0, x4
    // 0x643948: r1 = 7
    //     0x643948: mov             x1, #7
    // 0x64394c: cmp             x1, x0
    // 0x643950: b.hs            #0x643b7c
    // 0x643954: LoadField: d2 = r3->field_4f
    //     0x643954: ldur            d2, [x3, #0x4f]
    // 0x643958: fmul            d3, d2, d1
    // 0x64395c: fadd            d2, d4, d3
    // 0x643960: mov             x0, x4
    // 0x643964: r1 = 15
    //     0x643964: mov             x1, #0xf
    // 0x643968: cmp             x1, x0
    // 0x64396c: b.hs            #0x643b80
    // 0x643970: LoadField: d3 = r3->field_8f
    //     0x643970: ldur            d3, [x3, #0x8f]
    // 0x643974: fadd            d4, d2, d3
    // 0x643978: fdiv            d2, d0, d4
    // 0x64397c: mov             v0.16b, v2.16b
    // 0x643980: ldr             x4, [fp, #0x18]
    // 0x643984: LoadField: r0 = r3->field_13
    //     0x643984: ldur            w0, [x3, #0x13]
    // 0x643988: DecompressPointer r0
    //     0x643988: add             x0, x0, HEAP, lsl #32
    // 0x64398c: r5 = LoadInt32Instr(r0)
    //     0x64398c: sbfx            x5, x0, #1, #0x1f
    // 0x643990: mov             x0, x5
    // 0x643994: r1 = 0
    //     0x643994: mov             x1, #0
    // 0x643998: cmp             x1, x0
    // 0x64399c: b.hs            #0x643b84
    // 0x6439a0: LoadField: d2 = r3->field_17
    //     0x6439a0: ldur            d2, [x3, #0x17]
    // 0x6439a4: LoadField: d3 = r2->field_7
    //     0x6439a4: ldur            d3, [x2, #7]
    // 0x6439a8: fmul            d4, d2, d3
    // 0x6439ac: mov             x0, x5
    // 0x6439b0: r1 = 4
    //     0x6439b0: mov             x1, #4
    // 0x6439b4: cmp             x1, x0
    // 0x6439b8: b.hs            #0x643b88
    // 0x6439bc: LoadField: d2 = r3->field_37
    //     0x6439bc: ldur            d2, [x3, #0x37]
    // 0x6439c0: fmul            d5, d2, d1
    // 0x6439c4: fadd            d2, d4, d5
    // 0x6439c8: mov             x0, x5
    // 0x6439cc: r1 = 12
    //     0x6439cc: mov             x1, #0xc
    // 0x6439d0: cmp             x1, x0
    // 0x6439d4: b.hs            #0x643b8c
    // 0x6439d8: LoadField: d4 = r3->field_77
    //     0x6439d8: ldur            d4, [x3, #0x77]
    // 0x6439dc: fadd            d5, d2, d4
    // 0x6439e0: fmul            d2, d5, d0
    // 0x6439e4: stur            d2, [fp, #-0x10]
    // 0x6439e8: LoadField: d4 = r3->field_1f
    //     0x6439e8: ldur            d4, [x3, #0x1f]
    // 0x6439ec: fmul            d5, d4, d3
    // 0x6439f0: LoadField: d3 = r3->field_3f
    //     0x6439f0: ldur            d3, [x3, #0x3f]
    // 0x6439f4: fmul            d4, d3, d1
    // 0x6439f8: fadd            d1, d5, d4
    // 0x6439fc: mov             x0, x5
    // 0x643a00: r1 = 13
    //     0x643a00: mov             x1, #0xd
    // 0x643a04: cmp             x1, x0
    // 0x643a08: b.hs            #0x643b90
    // 0x643a0c: LoadField: d3 = r3->field_7f
    //     0x643a0c: ldur            d3, [x3, #0x7f]
    // 0x643a10: fadd            d4, d1, d3
    // 0x643a14: fmul            d1, d4, d0
    // 0x643a18: stur            d1, [fp, #-8]
    // 0x643a1c: tbnz            w4, #4, #0x643a98
    // 0x643a20: r0 = InitLateStaticField(0xe84) // [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_minMax
    //     0x643a20: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x643a24: ldr             x0, [x0, #0x1d08]
    //     0x643a28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x643a2c: cmp             w0, w16
    //     0x643a30: b.ne            #0x643a3c
    //     0x643a34: ldr             x2, [PP, #0x7348]  ; [pp+0x7348] Field <MatrixUtils._minMax@868374251>: static late final (offset: 0xe84)
    //     0x643a38: bl              #0xd67cdc
    // 0x643a3c: mov             x2, x0
    // 0x643a40: LoadField: r0 = r2->field_13
    //     0x643a40: ldur            w0, [x2, #0x13]
    // 0x643a44: DecompressPointer r0
    //     0x643a44: add             x0, x0, HEAP, lsl #32
    // 0x643a48: r3 = LoadInt32Instr(r0)
    //     0x643a48: sbfx            x3, x0, #1, #0x1f
    // 0x643a4c: mov             x0, x3
    // 0x643a50: r1 = 2
    //     0x643a50: mov             x1, #2
    // 0x643a54: cmp             x1, x0
    // 0x643a58: b.hs            #0x643b94
    // 0x643a5c: ldur            d0, [fp, #-0x10]
    // 0x643a60: StoreField: r2->field_27 = d0
    //     0x643a60: stur            d0, [x2, #0x27]
    // 0x643a64: mov             x0, x3
    // 0x643a68: r1 = 0
    //     0x643a68: mov             x1, #0
    // 0x643a6c: cmp             x1, x0
    // 0x643a70: b.hs            #0x643b98
    // 0x643a74: StoreField: r2->field_17 = d0
    //     0x643a74: stur            d0, [x2, #0x17]
    // 0x643a78: mov             x0, x3
    // 0x643a7c: r1 = 3
    //     0x643a7c: mov             x1, #3
    // 0x643a80: cmp             x1, x0
    // 0x643a84: b.hs            #0x643b9c
    // 0x643a88: ldur            d1, [fp, #-8]
    // 0x643a8c: StoreField: r2->field_2f = d1
    //     0x643a8c: stur            d1, [x2, #0x2f]
    // 0x643a90: StoreField: r2->field_1f = d1
    //     0x643a90: stur            d1, [x2, #0x1f]
    // 0x643a94: b               #0x643b60
    // 0x643a98: mov             v0.16b, v2.16b
    // 0x643a9c: r0 = InitLateStaticField(0xe84) // [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::_minMax
    //     0x643a9c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x643aa0: ldr             x0, [x0, #0x1d08]
    //     0x643aa4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x643aa8: cmp             w0, w16
    //     0x643aac: b.ne            #0x643ab8
    //     0x643ab0: ldr             x2, [PP, #0x7348]  ; [pp+0x7348] Field <MatrixUtils._minMax@868374251>: static late final (offset: 0xe84)
    //     0x643ab4: bl              #0xd67cdc
    // 0x643ab8: mov             x2, x0
    // 0x643abc: LoadField: r3 = r2->field_13
    //     0x643abc: ldur            w3, [x2, #0x13]
    // 0x643ac0: DecompressPointer r3
    //     0x643ac0: add             x3, x3, HEAP, lsl #32
    // 0x643ac4: r4 = LoadInt32Instr(r3)
    //     0x643ac4: sbfx            x4, x3, #1, #0x1f
    // 0x643ac8: mov             x0, x4
    // 0x643acc: r1 = 0
    //     0x643acc: mov             x1, #0
    // 0x643ad0: cmp             x1, x0
    // 0x643ad4: b.hs            #0x643ba0
    // 0x643ad8: LoadField: d0 = r2->field_17
    //     0x643ad8: ldur            d0, [x2, #0x17]
    // 0x643adc: ldur            d1, [fp, #-0x10]
    // 0x643ae0: fcmp            d1, d0
    // 0x643ae4: b.vs            #0x643af0
    // 0x643ae8: b.ge            #0x643af0
    // 0x643aec: StoreField: r2->field_17 = d1
    //     0x643aec: stur            d1, [x2, #0x17]
    // 0x643af0: ldur            d0, [fp, #-8]
    // 0x643af4: mov             x0, x4
    // 0x643af8: r1 = 1
    //     0x643af8: mov             x1, #1
    // 0x643afc: cmp             x1, x0
    // 0x643b00: b.hs            #0x643ba4
    // 0x643b04: LoadField: d2 = r2->field_1f
    //     0x643b04: ldur            d2, [x2, #0x1f]
    // 0x643b08: fcmp            d0, d2
    // 0x643b0c: b.vs            #0x643b18
    // 0x643b10: b.ge            #0x643b18
    // 0x643b14: StoreField: r2->field_1f = d0
    //     0x643b14: stur            d0, [x2, #0x1f]
    // 0x643b18: mov             x0, x4
    // 0x643b1c: r1 = 2
    //     0x643b1c: mov             x1, #2
    // 0x643b20: cmp             x1, x0
    // 0x643b24: b.hs            #0x643ba8
    // 0x643b28: LoadField: d2 = r2->field_27
    //     0x643b28: ldur            d2, [x2, #0x27]
    // 0x643b2c: fcmp            d1, d2
    // 0x643b30: b.vs            #0x643b3c
    // 0x643b34: b.le            #0x643b3c
    // 0x643b38: StoreField: r2->field_27 = d1
    //     0x643b38: stur            d1, [x2, #0x27]
    // 0x643b3c: mov             x0, x4
    // 0x643b40: r1 = 3
    //     0x643b40: mov             x1, #3
    // 0x643b44: cmp             x1, x0
    // 0x643b48: b.hs            #0x643bac
    // 0x643b4c: LoadField: d1 = r2->field_2f
    //     0x643b4c: ldur            d1, [x2, #0x2f]
    // 0x643b50: fcmp            d0, d1
    // 0x643b54: b.vs            #0x643b60
    // 0x643b58: b.le            #0x643b60
    // 0x643b5c: StoreField: r2->field_2f = d0
    //     0x643b5c: stur            d0, [x2, #0x2f]
    // 0x643b60: r0 = Null
    //     0x643b60: mov             x0, NULL
    // 0x643b64: LeaveFrame
    //     0x643b64: mov             SP, fp
    //     0x643b68: ldp             fp, lr, [SP], #0x10
    // 0x643b6c: ret
    //     0x643b6c: ret             
    // 0x643b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x643b70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x643b74: b               #0x6438f0
    // 0x643b78: r0 = RangeErrorSharedWithFPURegs()
    //     0x643b78: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643b7c: r0 = RangeErrorSharedWithFPURegs()
    //     0x643b7c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643b80: r0 = RangeErrorSharedWithFPURegs()
    //     0x643b80: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643b84: r0 = RangeErrorSharedWithFPURegs()
    //     0x643b84: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643b88: r0 = RangeErrorSharedWithFPURegs()
    //     0x643b88: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643b8c: r0 = RangeErrorSharedWithFPURegs()
    //     0x643b8c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643b90: r0 = RangeErrorSharedWithFPURegs()
    //     0x643b90: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643b94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x643b94: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x643b98: r0 = RangeErrorSharedWithFPURegs()
    //     0x643b98: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643b9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x643b9c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x643ba0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x643ba0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x643ba4: r0 = RangeErrorSharedWithFPURegs()
    //     0x643ba4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643ba8: r0 = RangeErrorSharedWithFPURegs()
    //     0x643ba8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x643bac: r0 = RangeErrorSharedWithFPURegs()
    //     0x643bac: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  static Float64List _minMax() {
    // ** addr: 0x643bb0, size: 0x1c
    // 0x643bb0: EnterFrame
    //     0x643bb0: stp             fp, lr, [SP, #-0x10]!
    //     0x643bb4: mov             fp, SP
    // 0x643bb8: r4 = 8
    //     0x643bb8: mov             x4, #8
    // 0x643bbc: r0 = AllocateFloat64Array()
    //     0x643bbc: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x643bc0: LeaveFrame
    //     0x643bc0: mov             SP, fp
    //     0x643bc4: ldp             fp, lr, [SP], #0x10
    // 0x643bc8: ret
    //     0x643bc8: ret             
  }
  static _ inverseTransformRect(/* No info */) {
    // ** addr: 0x65d3dc, size: 0x84
    // 0x65d3dc: EnterFrame
    //     0x65d3dc: stp             fp, lr, [SP, #-0x10]!
    //     0x65d3e0: mov             fp, SP
    // 0x65d3e4: AllocStack(0x8)
    //     0x65d3e4: sub             SP, SP, #8
    // 0x65d3e8: CheckStackOverflow
    //     0x65d3e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65d3ec: cmp             SP, x16
    //     0x65d3f0: b.ls            #0x65d458
    // 0x65d3f4: ldr             x16, [fp, #0x18]
    // 0x65d3f8: SaveReg r16
    //     0x65d3f8: str             x16, [SP, #-8]!
    // 0x65d3fc: r0 = isIdentity()
    //     0x65d3fc: bl              #0x65d49c  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::isIdentity
    // 0x65d400: add             SP, SP, #8
    // 0x65d404: tbnz            w0, #4, #0x65d418
    // 0x65d408: ldr             x0, [fp, #0x10]
    // 0x65d40c: LeaveFrame
    //     0x65d40c: mov             SP, fp
    //     0x65d410: ldp             fp, lr, [SP], #0x10
    // 0x65d414: ret
    //     0x65d414: ret             
    // 0x65d418: ldr             x16, [fp, #0x18]
    // 0x65d41c: stp             x16, NULL, [SP, #-0x10]!
    // 0x65d420: r0 = Matrix4.copy()
    //     0x65d420: bl              #0x50aa74  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.copy
    // 0x65d424: add             SP, SP, #0x10
    // 0x65d428: stur            x0, [fp, #-8]
    // 0x65d42c: SaveReg r0
    //     0x65d42c: str             x0, [SP, #-8]!
    // 0x65d430: r0 = invert()
    //     0x65d430: bl              #0x65d460  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0x65d434: add             SP, SP, #8
    // 0x65d438: ldur            x16, [fp, #-8]
    // 0x65d43c: ldr             lr, [fp, #0x10]
    // 0x65d440: stp             lr, x16, [SP, #-0x10]!
    // 0x65d444: r0 = transformRect()
    //     0x65d444: bl              #0x6431fc  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x65d448: add             SP, SP, #0x10
    // 0x65d44c: LeaveFrame
    //     0x65d44c: mov             SP, fp
    //     0x65d450: ldp             fp, lr, [SP], #0x10
    // 0x65d454: ret
    //     0x65d454: ret             
    // 0x65d458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65d458: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65d45c: b               #0x65d3f4
  }
  static _ isIdentity(/* No info */) {
    // ** addr: 0x65d49c, size: 0x28c
    // 0x65d49c: EnterFrame
    //     0x65d49c: stp             fp, lr, [SP, #-0x10]!
    //     0x65d4a0: mov             fp, SP
    // 0x65d4a4: d0 = 1.000000
    //     0x65d4a4: fmov            d0, #1.00000000
    // 0x65d4a8: ldr             x2, [fp, #0x10]
    // 0x65d4ac: LoadField: r3 = r2->field_7
    //     0x65d4ac: ldur            w3, [x2, #7]
    // 0x65d4b0: DecompressPointer r3
    //     0x65d4b0: add             x3, x3, HEAP, lsl #32
    // 0x65d4b4: LoadField: r2 = r3->field_13
    //     0x65d4b4: ldur            w2, [x3, #0x13]
    // 0x65d4b8: DecompressPointer r2
    //     0x65d4b8: add             x2, x2, HEAP, lsl #32
    // 0x65d4bc: r4 = LoadInt32Instr(r2)
    //     0x65d4bc: sbfx            x4, x2, #1, #0x1f
    // 0x65d4c0: mov             x0, x4
    // 0x65d4c4: r1 = 0
    //     0x65d4c4: mov             x1, #0
    // 0x65d4c8: cmp             x1, x0
    // 0x65d4cc: b.hs            #0x65d6e8
    // 0x65d4d0: LoadField: d1 = r3->field_17
    //     0x65d4d0: ldur            d1, [x3, #0x17]
    // 0x65d4d4: fcmp            d1, d0
    // 0x65d4d8: b.vs            #0x65d6d8
    // 0x65d4dc: b.ne            #0x65d6d8
    // 0x65d4e0: d1 = 0.000000
    //     0x65d4e0: eor             v1.16b, v1.16b, v1.16b
    // 0x65d4e4: mov             x0, x4
    // 0x65d4e8: r1 = 1
    //     0x65d4e8: mov             x1, #1
    // 0x65d4ec: cmp             x1, x0
    // 0x65d4f0: b.hs            #0x65d6ec
    // 0x65d4f4: LoadField: d2 = r3->field_1f
    //     0x65d4f4: ldur            d2, [x3, #0x1f]
    // 0x65d4f8: fcmp            d2, d1
    // 0x65d4fc: b.vs            #0x65d6d8
    // 0x65d500: b.ne            #0x65d6d8
    // 0x65d504: mov             x0, x4
    // 0x65d508: r1 = 2
    //     0x65d508: mov             x1, #2
    // 0x65d50c: cmp             x1, x0
    // 0x65d510: b.hs            #0x65d6f0
    // 0x65d514: LoadField: d2 = r3->field_27
    //     0x65d514: ldur            d2, [x3, #0x27]
    // 0x65d518: fcmp            d2, d1
    // 0x65d51c: b.vs            #0x65d6d8
    // 0x65d520: b.ne            #0x65d6d8
    // 0x65d524: mov             x0, x4
    // 0x65d528: r1 = 3
    //     0x65d528: mov             x1, #3
    // 0x65d52c: cmp             x1, x0
    // 0x65d530: b.hs            #0x65d6f4
    // 0x65d534: LoadField: d2 = r3->field_2f
    //     0x65d534: ldur            d2, [x3, #0x2f]
    // 0x65d538: fcmp            d2, d1
    // 0x65d53c: b.vs            #0x65d6d8
    // 0x65d540: b.ne            #0x65d6d8
    // 0x65d544: mov             x0, x4
    // 0x65d548: r1 = 4
    //     0x65d548: mov             x1, #4
    // 0x65d54c: cmp             x1, x0
    // 0x65d550: b.hs            #0x65d6f8
    // 0x65d554: LoadField: d2 = r3->field_37
    //     0x65d554: ldur            d2, [x3, #0x37]
    // 0x65d558: fcmp            d2, d1
    // 0x65d55c: b.vs            #0x65d6d8
    // 0x65d560: b.ne            #0x65d6d8
    // 0x65d564: mov             x0, x4
    // 0x65d568: r1 = 5
    //     0x65d568: mov             x1, #5
    // 0x65d56c: cmp             x1, x0
    // 0x65d570: b.hs            #0x65d6fc
    // 0x65d574: LoadField: d2 = r3->field_3f
    //     0x65d574: ldur            d2, [x3, #0x3f]
    // 0x65d578: fcmp            d2, d0
    // 0x65d57c: b.vs            #0x65d6d8
    // 0x65d580: b.ne            #0x65d6d8
    // 0x65d584: mov             x0, x4
    // 0x65d588: r1 = 6
    //     0x65d588: mov             x1, #6
    // 0x65d58c: cmp             x1, x0
    // 0x65d590: b.hs            #0x65d700
    // 0x65d594: LoadField: d2 = r3->field_47
    //     0x65d594: ldur            d2, [x3, #0x47]
    // 0x65d598: fcmp            d2, d1
    // 0x65d59c: b.vs            #0x65d6d8
    // 0x65d5a0: b.ne            #0x65d6d8
    // 0x65d5a4: mov             x0, x4
    // 0x65d5a8: r1 = 7
    //     0x65d5a8: mov             x1, #7
    // 0x65d5ac: cmp             x1, x0
    // 0x65d5b0: b.hs            #0x65d704
    // 0x65d5b4: LoadField: d2 = r3->field_4f
    //     0x65d5b4: ldur            d2, [x3, #0x4f]
    // 0x65d5b8: fcmp            d2, d1
    // 0x65d5bc: b.vs            #0x65d6d8
    // 0x65d5c0: b.ne            #0x65d6d8
    // 0x65d5c4: mov             x0, x4
    // 0x65d5c8: r1 = 8
    //     0x65d5c8: mov             x1, #8
    // 0x65d5cc: cmp             x1, x0
    // 0x65d5d0: b.hs            #0x65d708
    // 0x65d5d4: LoadField: d2 = r3->field_57
    //     0x65d5d4: ldur            d2, [x3, #0x57]
    // 0x65d5d8: fcmp            d2, d1
    // 0x65d5dc: b.vs            #0x65d6d8
    // 0x65d5e0: b.ne            #0x65d6d8
    // 0x65d5e4: mov             x0, x4
    // 0x65d5e8: r1 = 9
    //     0x65d5e8: mov             x1, #9
    // 0x65d5ec: cmp             x1, x0
    // 0x65d5f0: b.hs            #0x65d70c
    // 0x65d5f4: LoadField: d2 = r3->field_5f
    //     0x65d5f4: ldur            d2, [x3, #0x5f]
    // 0x65d5f8: fcmp            d2, d1
    // 0x65d5fc: b.vs            #0x65d6d8
    // 0x65d600: b.ne            #0x65d6d8
    // 0x65d604: mov             x0, x4
    // 0x65d608: r1 = 10
    //     0x65d608: mov             x1, #0xa
    // 0x65d60c: cmp             x1, x0
    // 0x65d610: b.hs            #0x65d710
    // 0x65d614: LoadField: d2 = r3->field_67
    //     0x65d614: ldur            d2, [x3, #0x67]
    // 0x65d618: fcmp            d2, d0
    // 0x65d61c: b.vs            #0x65d6d8
    // 0x65d620: b.ne            #0x65d6d8
    // 0x65d624: mov             x0, x4
    // 0x65d628: r1 = 11
    //     0x65d628: mov             x1, #0xb
    // 0x65d62c: cmp             x1, x0
    // 0x65d630: b.hs            #0x65d714
    // 0x65d634: LoadField: d2 = r3->field_6f
    //     0x65d634: ldur            d2, [x3, #0x6f]
    // 0x65d638: fcmp            d2, d1
    // 0x65d63c: b.vs            #0x65d6d8
    // 0x65d640: b.ne            #0x65d6d8
    // 0x65d644: mov             x0, x4
    // 0x65d648: r1 = 12
    //     0x65d648: mov             x1, #0xc
    // 0x65d64c: cmp             x1, x0
    // 0x65d650: b.hs            #0x65d718
    // 0x65d654: LoadField: d2 = r3->field_77
    //     0x65d654: ldur            d2, [x3, #0x77]
    // 0x65d658: fcmp            d2, d1
    // 0x65d65c: b.vs            #0x65d6d8
    // 0x65d660: b.ne            #0x65d6d8
    // 0x65d664: mov             x0, x4
    // 0x65d668: r1 = 13
    //     0x65d668: mov             x1, #0xd
    // 0x65d66c: cmp             x1, x0
    // 0x65d670: b.hs            #0x65d71c
    // 0x65d674: LoadField: d2 = r3->field_7f
    //     0x65d674: ldur            d2, [x3, #0x7f]
    // 0x65d678: fcmp            d2, d1
    // 0x65d67c: b.vs            #0x65d6d8
    // 0x65d680: b.ne            #0x65d6d8
    // 0x65d684: mov             x0, x4
    // 0x65d688: r1 = 14
    //     0x65d688: mov             x1, #0xe
    // 0x65d68c: cmp             x1, x0
    // 0x65d690: b.hs            #0x65d720
    // 0x65d694: LoadField: d2 = r3->field_87
    //     0x65d694: ldur            d2, [x3, #0x87]
    // 0x65d698: fcmp            d2, d1
    // 0x65d69c: b.vs            #0x65d6d8
    // 0x65d6a0: b.ne            #0x65d6d8
    // 0x65d6a4: mov             x0, x4
    // 0x65d6a8: r1 = 15
    //     0x65d6a8: mov             x1, #0xf
    // 0x65d6ac: cmp             x1, x0
    // 0x65d6b0: b.hs            #0x65d724
    // 0x65d6b4: LoadField: d1 = r3->field_8f
    //     0x65d6b4: ldur            d1, [x3, #0x8f]
    // 0x65d6b8: fcmp            d1, d0
    // 0x65d6bc: b.vs            #0x65d6c4
    // 0x65d6c0: b.eq            #0x65d6cc
    // 0x65d6c4: r1 = false
    //     0x65d6c4: add             x1, NULL, #0x30  ; false
    // 0x65d6c8: b               #0x65d6d0
    // 0x65d6cc: r1 = true
    //     0x65d6cc: add             x1, NULL, #0x20  ; true
    // 0x65d6d0: mov             x0, x1
    // 0x65d6d4: b               #0x65d6dc
    // 0x65d6d8: r0 = false
    //     0x65d6d8: add             x0, NULL, #0x30  ; false
    // 0x65d6dc: LeaveFrame
    //     0x65d6dc: mov             SP, fp
    //     0x65d6e0: ldp             fp, lr, [SP], #0x10
    // 0x65d6e4: ret
    //     0x65d6e4: ret             
    // 0x65d6e8: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d6e8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d6ec: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d6ec: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d6f0: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d6f0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d6f4: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d6f4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d6f8: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d6f8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d6fc: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d6fc: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d700: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d700: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d704: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d704: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d708: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d708: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d70c: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d70c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d710: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d710: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d714: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d714: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d718: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d718: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d71c: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d71c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d720: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d720: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x65d724: r0 = RangeErrorSharedWithFPURegs()
    //     0x65d724: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  static _ getAsTranslation(/* No info */) {
    // ** addr: 0x665a04, size: 0x264
    // 0x665a04: EnterFrame
    //     0x665a04: stp             fp, lr, [SP, #-0x10]!
    //     0x665a08: mov             fp, SP
    // 0x665a0c: AllocStack(0x10)
    //     0x665a0c: sub             SP, SP, #0x10
    // 0x665a10: d0 = 1.000000
    //     0x665a10: fmov            d0, #1.00000000
    // 0x665a14: ldr             x0, [fp, #0x10]
    // 0x665a18: LoadField: r2 = r0->field_7
    //     0x665a18: ldur            w2, [x0, #7]
    // 0x665a1c: DecompressPointer r2
    //     0x665a1c: add             x2, x2, HEAP, lsl #32
    // 0x665a20: LoadField: r0 = r2->field_13
    //     0x665a20: ldur            w0, [x2, #0x13]
    // 0x665a24: DecompressPointer r0
    //     0x665a24: add             x0, x0, HEAP, lsl #32
    // 0x665a28: r3 = LoadInt32Instr(r0)
    //     0x665a28: sbfx            x3, x0, #1, #0x1f
    // 0x665a2c: mov             x0, x3
    // 0x665a30: r1 = 0
    //     0x665a30: mov             x1, #0
    // 0x665a34: cmp             x1, x0
    // 0x665a38: b.hs            #0x665c30
    // 0x665a3c: LoadField: d1 = r2->field_17
    //     0x665a3c: ldur            d1, [x2, #0x17]
    // 0x665a40: fcmp            d1, d0
    // 0x665a44: b.vs            #0x665c20
    // 0x665a48: b.ne            #0x665c20
    // 0x665a4c: d1 = 0.000000
    //     0x665a4c: eor             v1.16b, v1.16b, v1.16b
    // 0x665a50: mov             x0, x3
    // 0x665a54: r1 = 1
    //     0x665a54: mov             x1, #1
    // 0x665a58: cmp             x1, x0
    // 0x665a5c: b.hs            #0x665c34
    // 0x665a60: LoadField: d2 = r2->field_1f
    //     0x665a60: ldur            d2, [x2, #0x1f]
    // 0x665a64: fcmp            d2, d1
    // 0x665a68: b.vs            #0x665c20
    // 0x665a6c: b.ne            #0x665c20
    // 0x665a70: mov             x0, x3
    // 0x665a74: r1 = 2
    //     0x665a74: mov             x1, #2
    // 0x665a78: cmp             x1, x0
    // 0x665a7c: b.hs            #0x665c38
    // 0x665a80: LoadField: d2 = r2->field_27
    //     0x665a80: ldur            d2, [x2, #0x27]
    // 0x665a84: fcmp            d2, d1
    // 0x665a88: b.vs            #0x665c20
    // 0x665a8c: b.ne            #0x665c20
    // 0x665a90: mov             x0, x3
    // 0x665a94: r1 = 3
    //     0x665a94: mov             x1, #3
    // 0x665a98: cmp             x1, x0
    // 0x665a9c: b.hs            #0x665c3c
    // 0x665aa0: LoadField: d2 = r2->field_2f
    //     0x665aa0: ldur            d2, [x2, #0x2f]
    // 0x665aa4: fcmp            d2, d1
    // 0x665aa8: b.vs            #0x665c20
    // 0x665aac: b.ne            #0x665c20
    // 0x665ab0: mov             x0, x3
    // 0x665ab4: r1 = 4
    //     0x665ab4: mov             x1, #4
    // 0x665ab8: cmp             x1, x0
    // 0x665abc: b.hs            #0x665c40
    // 0x665ac0: LoadField: d2 = r2->field_37
    //     0x665ac0: ldur            d2, [x2, #0x37]
    // 0x665ac4: fcmp            d2, d1
    // 0x665ac8: b.vs            #0x665c20
    // 0x665acc: b.ne            #0x665c20
    // 0x665ad0: mov             x0, x3
    // 0x665ad4: r1 = 5
    //     0x665ad4: mov             x1, #5
    // 0x665ad8: cmp             x1, x0
    // 0x665adc: b.hs            #0x665c44
    // 0x665ae0: LoadField: d2 = r2->field_3f
    //     0x665ae0: ldur            d2, [x2, #0x3f]
    // 0x665ae4: fcmp            d2, d0
    // 0x665ae8: b.vs            #0x665c20
    // 0x665aec: b.ne            #0x665c20
    // 0x665af0: mov             x0, x3
    // 0x665af4: r1 = 6
    //     0x665af4: mov             x1, #6
    // 0x665af8: cmp             x1, x0
    // 0x665afc: b.hs            #0x665c48
    // 0x665b00: LoadField: d2 = r2->field_47
    //     0x665b00: ldur            d2, [x2, #0x47]
    // 0x665b04: fcmp            d2, d1
    // 0x665b08: b.vs            #0x665c20
    // 0x665b0c: b.ne            #0x665c20
    // 0x665b10: mov             x0, x3
    // 0x665b14: r1 = 7
    //     0x665b14: mov             x1, #7
    // 0x665b18: cmp             x1, x0
    // 0x665b1c: b.hs            #0x665c4c
    // 0x665b20: LoadField: d2 = r2->field_4f
    //     0x665b20: ldur            d2, [x2, #0x4f]
    // 0x665b24: fcmp            d2, d1
    // 0x665b28: b.vs            #0x665c20
    // 0x665b2c: b.ne            #0x665c20
    // 0x665b30: mov             x0, x3
    // 0x665b34: r1 = 8
    //     0x665b34: mov             x1, #8
    // 0x665b38: cmp             x1, x0
    // 0x665b3c: b.hs            #0x665c50
    // 0x665b40: LoadField: d2 = r2->field_57
    //     0x665b40: ldur            d2, [x2, #0x57]
    // 0x665b44: fcmp            d2, d1
    // 0x665b48: b.vs            #0x665c20
    // 0x665b4c: b.ne            #0x665c20
    // 0x665b50: mov             x0, x3
    // 0x665b54: r1 = 9
    //     0x665b54: mov             x1, #9
    // 0x665b58: cmp             x1, x0
    // 0x665b5c: b.hs            #0x665c54
    // 0x665b60: LoadField: d2 = r2->field_5f
    //     0x665b60: ldur            d2, [x2, #0x5f]
    // 0x665b64: fcmp            d2, d1
    // 0x665b68: b.vs            #0x665c20
    // 0x665b6c: b.ne            #0x665c20
    // 0x665b70: mov             x0, x3
    // 0x665b74: r1 = 10
    //     0x665b74: mov             x1, #0xa
    // 0x665b78: cmp             x1, x0
    // 0x665b7c: b.hs            #0x665c58
    // 0x665b80: LoadField: d2 = r2->field_67
    //     0x665b80: ldur            d2, [x2, #0x67]
    // 0x665b84: fcmp            d2, d0
    // 0x665b88: b.vs            #0x665c20
    // 0x665b8c: b.ne            #0x665c20
    // 0x665b90: mov             x0, x3
    // 0x665b94: r1 = 11
    //     0x665b94: mov             x1, #0xb
    // 0x665b98: cmp             x1, x0
    // 0x665b9c: b.hs            #0x665c5c
    // 0x665ba0: LoadField: d2 = r2->field_6f
    //     0x665ba0: ldur            d2, [x2, #0x6f]
    // 0x665ba4: fcmp            d2, d1
    // 0x665ba8: b.vs            #0x665c20
    // 0x665bac: b.ne            #0x665c20
    // 0x665bb0: mov             x0, x3
    // 0x665bb4: r1 = 14
    //     0x665bb4: mov             x1, #0xe
    // 0x665bb8: cmp             x1, x0
    // 0x665bbc: b.hs            #0x665c60
    // 0x665bc0: LoadField: d2 = r2->field_87
    //     0x665bc0: ldur            d2, [x2, #0x87]
    // 0x665bc4: fcmp            d2, d1
    // 0x665bc8: b.vs            #0x665c20
    // 0x665bcc: b.ne            #0x665c20
    // 0x665bd0: mov             x0, x3
    // 0x665bd4: r1 = 15
    //     0x665bd4: mov             x1, #0xf
    // 0x665bd8: cmp             x1, x0
    // 0x665bdc: b.hs            #0x665c64
    // 0x665be0: LoadField: d1 = r2->field_8f
    //     0x665be0: ldur            d1, [x2, #0x8f]
    // 0x665be4: fcmp            d1, d0
    // 0x665be8: b.vs            #0x665c20
    // 0x665bec: b.ne            #0x665c20
    // 0x665bf0: LoadField: d0 = r2->field_77
    //     0x665bf0: ldur            d0, [x2, #0x77]
    // 0x665bf4: stur            d0, [fp, #-0x10]
    // 0x665bf8: LoadField: d1 = r2->field_7f
    //     0x665bf8: ldur            d1, [x2, #0x7f]
    // 0x665bfc: stur            d1, [fp, #-8]
    // 0x665c00: r0 = Offset()
    //     0x665c00: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x665c04: ldur            d0, [fp, #-0x10]
    // 0x665c08: StoreField: r0->field_7 = d0
    //     0x665c08: stur            d0, [x0, #7]
    // 0x665c0c: ldur            d0, [fp, #-8]
    // 0x665c10: StoreField: r0->field_f = d0
    //     0x665c10: stur            d0, [x0, #0xf]
    // 0x665c14: LeaveFrame
    //     0x665c14: mov             SP, fp
    //     0x665c18: ldp             fp, lr, [SP], #0x10
    // 0x665c1c: ret
    //     0x665c1c: ret             
    // 0x665c20: r0 = Null
    //     0x665c20: mov             x0, NULL
    // 0x665c24: LeaveFrame
    //     0x665c24: mov             SP, fp
    //     0x665c28: ldp             fp, lr, [SP], #0x10
    // 0x665c2c: ret
    //     0x665c2c: ret             
    // 0x665c30: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c30: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c34: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c34: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c38: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c38: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c3c: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c3c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c40: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c40: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c44: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c44: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c48: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c48: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c4c: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c4c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c50: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c50: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c54: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c54: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c58: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c58: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c5c: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c5c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c60: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c60: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x665c64: r0 = RangeErrorSharedWithFPURegs()
    //     0x665c64: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  static _ matrixEquals(/* No info */) {
    // ** addr: 0xd02614, size: 0x468
    // 0xd02614: EnterFrame
    //     0xd02614: stp             fp, lr, [SP, #-0x10]!
    //     0xd02618: mov             fp, SP
    // 0xd0261c: CheckStackOverflow
    //     0xd0261c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd02620: cmp             SP, x16
    //     0xd02624: b.ls            #0xd029f4
    // 0xd02628: ldr             x0, [fp, #0x18]
    // 0xd0262c: ldr             x2, [fp, #0x10]
    // 0xd02630: cmp             w0, w2
    // 0xd02634: b.ne            #0xd02648
    // 0xd02638: r0 = true
    //     0xd02638: add             x0, NULL, #0x20  ; true
    // 0xd0263c: LeaveFrame
    //     0xd0263c: mov             SP, fp
    //     0xd02640: ldp             fp, lr, [SP], #0x10
    // 0xd02644: ret
    //     0xd02644: ret             
    // 0xd02648: cmp             w0, NULL
    // 0xd0264c: b.ne            #0xd02668
    // 0xd02650: SaveReg r2
    //     0xd02650: str             x2, [SP, #-8]!
    // 0xd02654: r0 = isIdentity()
    //     0xd02654: bl              #0x65d49c  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::isIdentity
    // 0xd02658: add             SP, SP, #8
    // 0xd0265c: LeaveFrame
    //     0xd0265c: mov             SP, fp
    //     0xd02660: ldp             fp, lr, [SP], #0x10
    // 0xd02664: ret
    //     0xd02664: ret             
    // 0xd02668: LoadField: r3 = r0->field_7
    //     0xd02668: ldur            w3, [x0, #7]
    // 0xd0266c: DecompressPointer r3
    //     0xd0266c: add             x3, x3, HEAP, lsl #32
    // 0xd02670: LoadField: r4 = r3->field_13
    //     0xd02670: ldur            w4, [x3, #0x13]
    // 0xd02674: DecompressPointer r4
    //     0xd02674: add             x4, x4, HEAP, lsl #32
    // 0xd02678: r5 = LoadInt32Instr(r4)
    //     0xd02678: sbfx            x5, x4, #1, #0x1f
    // 0xd0267c: mov             x0, x5
    // 0xd02680: r1 = 0
    //     0xd02680: mov             x1, #0
    // 0xd02684: cmp             x1, x0
    // 0xd02688: b.hs            #0xd029fc
    // 0xd0268c: LoadField: d0 = r3->field_17
    //     0xd0268c: ldur            d0, [x3, #0x17]
    // 0xd02690: LoadField: r4 = r2->field_7
    //     0xd02690: ldur            w4, [x2, #7]
    // 0xd02694: DecompressPointer r4
    //     0xd02694: add             x4, x4, HEAP, lsl #32
    // 0xd02698: LoadField: r2 = r4->field_13
    //     0xd02698: ldur            w2, [x4, #0x13]
    // 0xd0269c: DecompressPointer r2
    //     0xd0269c: add             x2, x2, HEAP, lsl #32
    // 0xd026a0: r6 = LoadInt32Instr(r2)
    //     0xd026a0: sbfx            x6, x2, #1, #0x1f
    // 0xd026a4: mov             x0, x6
    // 0xd026a8: r1 = 0
    //     0xd026a8: mov             x1, #0
    // 0xd026ac: cmp             x1, x0
    // 0xd026b0: b.hs            #0xd02a00
    // 0xd026b4: LoadField: d1 = r4->field_17
    //     0xd026b4: ldur            d1, [x4, #0x17]
    // 0xd026b8: fcmp            d0, d1
    // 0xd026bc: b.vs            #0xd029e4
    // 0xd026c0: b.ne            #0xd029e4
    // 0xd026c4: mov             x0, x5
    // 0xd026c8: r1 = 1
    //     0xd026c8: mov             x1, #1
    // 0xd026cc: cmp             x1, x0
    // 0xd026d0: b.hs            #0xd02a04
    // 0xd026d4: LoadField: d0 = r3->field_1f
    //     0xd026d4: ldur            d0, [x3, #0x1f]
    // 0xd026d8: mov             x0, x6
    // 0xd026dc: r1 = 1
    //     0xd026dc: mov             x1, #1
    // 0xd026e0: cmp             x1, x0
    // 0xd026e4: b.hs            #0xd02a08
    // 0xd026e8: LoadField: d1 = r4->field_1f
    //     0xd026e8: ldur            d1, [x4, #0x1f]
    // 0xd026ec: fcmp            d0, d1
    // 0xd026f0: b.vs            #0xd029e4
    // 0xd026f4: b.ne            #0xd029e4
    // 0xd026f8: mov             x0, x5
    // 0xd026fc: r1 = 2
    //     0xd026fc: mov             x1, #2
    // 0xd02700: cmp             x1, x0
    // 0xd02704: b.hs            #0xd02a0c
    // 0xd02708: LoadField: d0 = r3->field_27
    //     0xd02708: ldur            d0, [x3, #0x27]
    // 0xd0270c: mov             x0, x6
    // 0xd02710: r1 = 2
    //     0xd02710: mov             x1, #2
    // 0xd02714: cmp             x1, x0
    // 0xd02718: b.hs            #0xd02a10
    // 0xd0271c: LoadField: d1 = r4->field_27
    //     0xd0271c: ldur            d1, [x4, #0x27]
    // 0xd02720: fcmp            d0, d1
    // 0xd02724: b.vs            #0xd029e4
    // 0xd02728: b.ne            #0xd029e4
    // 0xd0272c: mov             x0, x5
    // 0xd02730: r1 = 3
    //     0xd02730: mov             x1, #3
    // 0xd02734: cmp             x1, x0
    // 0xd02738: b.hs            #0xd02a14
    // 0xd0273c: LoadField: d0 = r3->field_2f
    //     0xd0273c: ldur            d0, [x3, #0x2f]
    // 0xd02740: mov             x0, x6
    // 0xd02744: r1 = 3
    //     0xd02744: mov             x1, #3
    // 0xd02748: cmp             x1, x0
    // 0xd0274c: b.hs            #0xd02a18
    // 0xd02750: LoadField: d1 = r4->field_2f
    //     0xd02750: ldur            d1, [x4, #0x2f]
    // 0xd02754: fcmp            d0, d1
    // 0xd02758: b.vs            #0xd029e4
    // 0xd0275c: b.ne            #0xd029e4
    // 0xd02760: mov             x0, x5
    // 0xd02764: r1 = 4
    //     0xd02764: mov             x1, #4
    // 0xd02768: cmp             x1, x0
    // 0xd0276c: b.hs            #0xd02a1c
    // 0xd02770: LoadField: d0 = r3->field_37
    //     0xd02770: ldur            d0, [x3, #0x37]
    // 0xd02774: mov             x0, x6
    // 0xd02778: r1 = 4
    //     0xd02778: mov             x1, #4
    // 0xd0277c: cmp             x1, x0
    // 0xd02780: b.hs            #0xd02a20
    // 0xd02784: LoadField: d1 = r4->field_37
    //     0xd02784: ldur            d1, [x4, #0x37]
    // 0xd02788: fcmp            d0, d1
    // 0xd0278c: b.vs            #0xd029e4
    // 0xd02790: b.ne            #0xd029e4
    // 0xd02794: mov             x0, x5
    // 0xd02798: r1 = 5
    //     0xd02798: mov             x1, #5
    // 0xd0279c: cmp             x1, x0
    // 0xd027a0: b.hs            #0xd02a24
    // 0xd027a4: LoadField: d0 = r3->field_3f
    //     0xd027a4: ldur            d0, [x3, #0x3f]
    // 0xd027a8: mov             x0, x6
    // 0xd027ac: r1 = 5
    //     0xd027ac: mov             x1, #5
    // 0xd027b0: cmp             x1, x0
    // 0xd027b4: b.hs            #0xd02a28
    // 0xd027b8: LoadField: d1 = r4->field_3f
    //     0xd027b8: ldur            d1, [x4, #0x3f]
    // 0xd027bc: fcmp            d0, d1
    // 0xd027c0: b.vs            #0xd029e4
    // 0xd027c4: b.ne            #0xd029e4
    // 0xd027c8: mov             x0, x5
    // 0xd027cc: r1 = 6
    //     0xd027cc: mov             x1, #6
    // 0xd027d0: cmp             x1, x0
    // 0xd027d4: b.hs            #0xd02a2c
    // 0xd027d8: LoadField: d0 = r3->field_47
    //     0xd027d8: ldur            d0, [x3, #0x47]
    // 0xd027dc: mov             x0, x6
    // 0xd027e0: r1 = 6
    //     0xd027e0: mov             x1, #6
    // 0xd027e4: cmp             x1, x0
    // 0xd027e8: b.hs            #0xd02a30
    // 0xd027ec: LoadField: d1 = r4->field_47
    //     0xd027ec: ldur            d1, [x4, #0x47]
    // 0xd027f0: fcmp            d0, d1
    // 0xd027f4: b.vs            #0xd029e4
    // 0xd027f8: b.ne            #0xd029e4
    // 0xd027fc: mov             x0, x5
    // 0xd02800: r1 = 7
    //     0xd02800: mov             x1, #7
    // 0xd02804: cmp             x1, x0
    // 0xd02808: b.hs            #0xd02a34
    // 0xd0280c: LoadField: d0 = r3->field_4f
    //     0xd0280c: ldur            d0, [x3, #0x4f]
    // 0xd02810: mov             x0, x6
    // 0xd02814: r1 = 7
    //     0xd02814: mov             x1, #7
    // 0xd02818: cmp             x1, x0
    // 0xd0281c: b.hs            #0xd02a38
    // 0xd02820: LoadField: d1 = r4->field_4f
    //     0xd02820: ldur            d1, [x4, #0x4f]
    // 0xd02824: fcmp            d0, d1
    // 0xd02828: b.vs            #0xd029e4
    // 0xd0282c: b.ne            #0xd029e4
    // 0xd02830: mov             x0, x5
    // 0xd02834: r1 = 8
    //     0xd02834: mov             x1, #8
    // 0xd02838: cmp             x1, x0
    // 0xd0283c: b.hs            #0xd02a3c
    // 0xd02840: LoadField: d0 = r3->field_57
    //     0xd02840: ldur            d0, [x3, #0x57]
    // 0xd02844: mov             x0, x6
    // 0xd02848: r1 = 8
    //     0xd02848: mov             x1, #8
    // 0xd0284c: cmp             x1, x0
    // 0xd02850: b.hs            #0xd02a40
    // 0xd02854: LoadField: d1 = r4->field_57
    //     0xd02854: ldur            d1, [x4, #0x57]
    // 0xd02858: fcmp            d0, d1
    // 0xd0285c: b.vs            #0xd029e4
    // 0xd02860: b.ne            #0xd029e4
    // 0xd02864: mov             x0, x5
    // 0xd02868: r1 = 9
    //     0xd02868: mov             x1, #9
    // 0xd0286c: cmp             x1, x0
    // 0xd02870: b.hs            #0xd02a44
    // 0xd02874: LoadField: d0 = r3->field_5f
    //     0xd02874: ldur            d0, [x3, #0x5f]
    // 0xd02878: mov             x0, x6
    // 0xd0287c: r1 = 9
    //     0xd0287c: mov             x1, #9
    // 0xd02880: cmp             x1, x0
    // 0xd02884: b.hs            #0xd02a48
    // 0xd02888: LoadField: d1 = r4->field_5f
    //     0xd02888: ldur            d1, [x4, #0x5f]
    // 0xd0288c: fcmp            d0, d1
    // 0xd02890: b.vs            #0xd029e4
    // 0xd02894: b.ne            #0xd029e4
    // 0xd02898: mov             x0, x5
    // 0xd0289c: r1 = 10
    //     0xd0289c: mov             x1, #0xa
    // 0xd028a0: cmp             x1, x0
    // 0xd028a4: b.hs            #0xd02a4c
    // 0xd028a8: LoadField: d0 = r3->field_67
    //     0xd028a8: ldur            d0, [x3, #0x67]
    // 0xd028ac: mov             x0, x6
    // 0xd028b0: r1 = 10
    //     0xd028b0: mov             x1, #0xa
    // 0xd028b4: cmp             x1, x0
    // 0xd028b8: b.hs            #0xd02a50
    // 0xd028bc: LoadField: d1 = r4->field_67
    //     0xd028bc: ldur            d1, [x4, #0x67]
    // 0xd028c0: fcmp            d0, d1
    // 0xd028c4: b.vs            #0xd029e4
    // 0xd028c8: b.ne            #0xd029e4
    // 0xd028cc: mov             x0, x5
    // 0xd028d0: r1 = 11
    //     0xd028d0: mov             x1, #0xb
    // 0xd028d4: cmp             x1, x0
    // 0xd028d8: b.hs            #0xd02a54
    // 0xd028dc: LoadField: d0 = r3->field_6f
    //     0xd028dc: ldur            d0, [x3, #0x6f]
    // 0xd028e0: mov             x0, x6
    // 0xd028e4: r1 = 11
    //     0xd028e4: mov             x1, #0xb
    // 0xd028e8: cmp             x1, x0
    // 0xd028ec: b.hs            #0xd02a58
    // 0xd028f0: LoadField: d1 = r4->field_6f
    //     0xd028f0: ldur            d1, [x4, #0x6f]
    // 0xd028f4: fcmp            d0, d1
    // 0xd028f8: b.vs            #0xd029e4
    // 0xd028fc: b.ne            #0xd029e4
    // 0xd02900: mov             x0, x5
    // 0xd02904: r1 = 12
    //     0xd02904: mov             x1, #0xc
    // 0xd02908: cmp             x1, x0
    // 0xd0290c: b.hs            #0xd02a5c
    // 0xd02910: LoadField: d0 = r3->field_77
    //     0xd02910: ldur            d0, [x3, #0x77]
    // 0xd02914: mov             x0, x6
    // 0xd02918: r1 = 12
    //     0xd02918: mov             x1, #0xc
    // 0xd0291c: cmp             x1, x0
    // 0xd02920: b.hs            #0xd02a60
    // 0xd02924: LoadField: d1 = r4->field_77
    //     0xd02924: ldur            d1, [x4, #0x77]
    // 0xd02928: fcmp            d0, d1
    // 0xd0292c: b.vs            #0xd029e4
    // 0xd02930: b.ne            #0xd029e4
    // 0xd02934: mov             x0, x5
    // 0xd02938: r1 = 13
    //     0xd02938: mov             x1, #0xd
    // 0xd0293c: cmp             x1, x0
    // 0xd02940: b.hs            #0xd02a64
    // 0xd02944: LoadField: d0 = r3->field_7f
    //     0xd02944: ldur            d0, [x3, #0x7f]
    // 0xd02948: mov             x0, x6
    // 0xd0294c: r1 = 13
    //     0xd0294c: mov             x1, #0xd
    // 0xd02950: cmp             x1, x0
    // 0xd02954: b.hs            #0xd02a68
    // 0xd02958: LoadField: d1 = r4->field_7f
    //     0xd02958: ldur            d1, [x4, #0x7f]
    // 0xd0295c: fcmp            d0, d1
    // 0xd02960: b.vs            #0xd029e4
    // 0xd02964: b.ne            #0xd029e4
    // 0xd02968: mov             x0, x5
    // 0xd0296c: r1 = 14
    //     0xd0296c: mov             x1, #0xe
    // 0xd02970: cmp             x1, x0
    // 0xd02974: b.hs            #0xd02a6c
    // 0xd02978: LoadField: d0 = r3->field_87
    //     0xd02978: ldur            d0, [x3, #0x87]
    // 0xd0297c: mov             x0, x6
    // 0xd02980: r1 = 14
    //     0xd02980: mov             x1, #0xe
    // 0xd02984: cmp             x1, x0
    // 0xd02988: b.hs            #0xd02a70
    // 0xd0298c: LoadField: d1 = r4->field_87
    //     0xd0298c: ldur            d1, [x4, #0x87]
    // 0xd02990: fcmp            d0, d1
    // 0xd02994: b.vs            #0xd029e4
    // 0xd02998: b.ne            #0xd029e4
    // 0xd0299c: mov             x0, x5
    // 0xd029a0: r1 = 15
    //     0xd029a0: mov             x1, #0xf
    // 0xd029a4: cmp             x1, x0
    // 0xd029a8: b.hs            #0xd02a74
    // 0xd029ac: LoadField: d0 = r3->field_8f
    //     0xd029ac: ldur            d0, [x3, #0x8f]
    // 0xd029b0: mov             x0, x6
    // 0xd029b4: r1 = 15
    //     0xd029b4: mov             x1, #0xf
    // 0xd029b8: cmp             x1, x0
    // 0xd029bc: b.hs            #0xd02a78
    // 0xd029c0: LoadField: d1 = r4->field_8f
    //     0xd029c0: ldur            d1, [x4, #0x8f]
    // 0xd029c4: fcmp            d0, d1
    // 0xd029c8: b.vs            #0xd029d0
    // 0xd029cc: b.eq            #0xd029d8
    // 0xd029d0: r1 = false
    //     0xd029d0: add             x1, NULL, #0x30  ; false
    // 0xd029d4: b               #0xd029dc
    // 0xd029d8: r1 = true
    //     0xd029d8: add             x1, NULL, #0x20  ; true
    // 0xd029dc: mov             x0, x1
    // 0xd029e0: b               #0xd029e8
    // 0xd029e4: r0 = false
    //     0xd029e4: add             x0, NULL, #0x30  ; false
    // 0xd029e8: LeaveFrame
    //     0xd029e8: mov             SP, fp
    //     0xd029ec: ldp             fp, lr, [SP], #0x10
    // 0xd029f0: ret
    //     0xd029f0: ret             
    // 0xd029f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd029f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd029f8: b               #0xd02628
    // 0xd029fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd029fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a00: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a00: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a04: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a08: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a08: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a0c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a0c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a10: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a10: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a14: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a18: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a18: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a1c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a1c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a20: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a20: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a24: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a28: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a28: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a2c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a30: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a30: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a34: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a38: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a38: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a3c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a40: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a40: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a44: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a44: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a48: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a48: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a4c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a50: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a50: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a54: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a54: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a58: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a58: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a5c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a60: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a60: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a64: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a64: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a68: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a68: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a6c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a6c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a70: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a70: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xd02a74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd02a74: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd02a78: r0 = RangeErrorSharedWithFPURegs()
    //     0xd02a78: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
}

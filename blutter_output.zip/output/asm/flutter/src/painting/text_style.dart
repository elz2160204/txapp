// lib: , url: package:flutter/src/painting/text_style.dart

// class id: 1049385, size: 0x8
class :: {
}

// class id: 2787, size: 0x70, field offset: 0x8
//   const constructor, 
class TextStyle extends _DiagnosticableTree&Object&Diagnosticable {

  bool field_8;
  _Double field_20;
  FontWeight field_24;
  FontStyle field_28;
  TextBaseline field_34;
  _OneByteString field_5c;
  _Double field_2c;
  Color field_c;
  _OneByteString field_14;
  TextDecoration field_4c;
  _ImmutableList<String> field_18;
  _Double field_38;
  TextLeadingDistribution field_3c;
  Color field_50;
  TextDecorationStyle field_54;
  _Double field_30;
  TextOverflow field_6c;

  _ getTextStyle(/* No info */) {
    // ** addr: 0x51c6f8, size: 0x30c
    // 0x51c6f8: EnterFrame
    //     0x51c6f8: stp             fp, lr, [SP, #-0x10]!
    //     0x51c6fc: mov             fp, SP
    // 0x51c700: AllocStack(0xa8)
    //     0x51c700: sub             SP, SP, #0xa8
    // 0x51c704: CheckStackOverflow
    //     0x51c704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51c708: cmp             SP, x16
    //     0x51c70c: b.ls            #0x51c9b8
    // 0x51c710: ldr             x0, [fp, #0x18]
    // 0x51c714: LoadField: r1 = r0->field_b
    //     0x51c714: ldur            w1, [x0, #0xb]
    // 0x51c718: DecompressPointer r1
    //     0x51c718: add             x1, x1, HEAP, lsl #32
    // 0x51c71c: stur            x1, [fp, #-0x88]
    // 0x51c720: LoadField: r2 = r0->field_4b
    //     0x51c720: ldur            w2, [x0, #0x4b]
    // 0x51c724: DecompressPointer r2
    //     0x51c724: add             x2, x2, HEAP, lsl #32
    // 0x51c728: stur            x2, [fp, #-0x80]
    // 0x51c72c: LoadField: r3 = r0->field_4f
    //     0x51c72c: ldur            w3, [x0, #0x4f]
    // 0x51c730: DecompressPointer r3
    //     0x51c730: add             x3, x3, HEAP, lsl #32
    // 0x51c734: stur            x3, [fp, #-0x78]
    // 0x51c738: LoadField: r4 = r0->field_53
    //     0x51c738: ldur            w4, [x0, #0x53]
    // 0x51c73c: DecompressPointer r4
    //     0x51c73c: add             x4, x4, HEAP, lsl #32
    // 0x51c740: stur            x4, [fp, #-0x70]
    // 0x51c744: LoadField: r5 = r0->field_57
    //     0x51c744: ldur            w5, [x0, #0x57]
    // 0x51c748: DecompressPointer r5
    //     0x51c748: add             x5, x5, HEAP, lsl #32
    // 0x51c74c: stur            x5, [fp, #-0x68]
    // 0x51c750: LoadField: r6 = r0->field_23
    //     0x51c750: ldur            w6, [x0, #0x23]
    // 0x51c754: DecompressPointer r6
    //     0x51c754: add             x6, x6, HEAP, lsl #32
    // 0x51c758: stur            x6, [fp, #-0x60]
    // 0x51c75c: LoadField: r7 = r0->field_27
    //     0x51c75c: ldur            w7, [x0, #0x27]
    // 0x51c760: DecompressPointer r7
    //     0x51c760: add             x7, x7, HEAP, lsl #32
    // 0x51c764: stur            x7, [fp, #-0x58]
    // 0x51c768: LoadField: r8 = r0->field_33
    //     0x51c768: ldur            w8, [x0, #0x33]
    // 0x51c76c: DecompressPointer r8
    //     0x51c76c: add             x8, x8, HEAP, lsl #32
    // 0x51c770: stur            x8, [fp, #-0x50]
    // 0x51c774: LoadField: r9 = r0->field_3b
    //     0x51c774: ldur            w9, [x0, #0x3b]
    // 0x51c778: DecompressPointer r9
    //     0x51c778: add             x9, x9, HEAP, lsl #32
    // 0x51c77c: stur            x9, [fp, #-0x48]
    // 0x51c780: LoadField: r10 = r0->field_13
    //     0x51c780: ldur            w10, [x0, #0x13]
    // 0x51c784: DecompressPointer r10
    //     0x51c784: add             x10, x10, HEAP, lsl #32
    // 0x51c788: stur            x10, [fp, #-0x40]
    // 0x51c78c: LoadField: r11 = r0->field_17
    //     0x51c78c: ldur            w11, [x0, #0x17]
    // 0x51c790: DecompressPointer r11
    //     0x51c790: add             x11, x11, HEAP, lsl #32
    // 0x51c794: stur            x11, [fp, #-0x38]
    // 0x51c798: LoadField: r12 = r0->field_1f
    //     0x51c798: ldur            w12, [x0, #0x1f]
    // 0x51c79c: DecompressPointer r12
    //     0x51c79c: add             x12, x12, HEAP, lsl #32
    // 0x51c7a0: cmp             w12, NULL
    // 0x51c7a4: b.ne            #0x51c7b0
    // 0x51c7a8: r12 = Null
    //     0x51c7a8: mov             x12, NULL
    // 0x51c7ac: b               #0x51c7e4
    // 0x51c7b0: ldr             d0, [fp, #0x10]
    // 0x51c7b4: LoadField: d1 = r12->field_7
    //     0x51c7b4: ldur            d1, [x12, #7]
    // 0x51c7b8: fmul            d2, d1, d0
    // 0x51c7bc: r12 = inline_Allocate_Double()
    //     0x51c7bc: ldp             x12, x13, [THR, #0x60]  ; THR::top
    //     0x51c7c0: add             x12, x12, #0x10
    //     0x51c7c4: cmp             x13, x12
    //     0x51c7c8: b.ls            #0x51c9c0
    //     0x51c7cc: str             x12, [THR, #0x60]  ; THR::top
    //     0x51c7d0: sub             x12, x12, #0xf
    //     0x51c7d4: mov             x13, #0xd108
    //     0x51c7d8: movk            x13, #3, lsl #16
    //     0x51c7dc: stur            x13, [x12, #-1]
    // 0x51c7e0: StoreField: r12->field_7 = d2
    //     0x51c7e0: stur            d2, [x12, #7]
    // 0x51c7e4: stur            x12, [fp, #-0x30]
    // 0x51c7e8: LoadField: r13 = r0->field_2b
    //     0x51c7e8: ldur            w13, [x0, #0x2b]
    // 0x51c7ec: DecompressPointer r13
    //     0x51c7ec: add             x13, x13, HEAP, lsl #32
    // 0x51c7f0: stur            x13, [fp, #-0x28]
    // 0x51c7f4: LoadField: r14 = r0->field_2f
    //     0x51c7f4: ldur            w14, [x0, #0x2f]
    // 0x51c7f8: DecompressPointer r14
    //     0x51c7f8: add             x14, x14, HEAP, lsl #32
    // 0x51c7fc: stur            x14, [fp, #-0x20]
    // 0x51c800: LoadField: r19 = r0->field_37
    //     0x51c800: ldur            w19, [x0, #0x37]
    // 0x51c804: DecompressPointer r19
    //     0x51c804: add             x19, x19, HEAP, lsl #32
    // 0x51c808: stur            x19, [fp, #-0x18]
    // 0x51c80c: LoadField: r20 = r0->field_43
    //     0x51c80c: ldur            w20, [x0, #0x43]
    // 0x51c810: DecompressPointer r20
    //     0x51c810: add             x20, x20, HEAP, lsl #32
    // 0x51c814: stur            x20, [fp, #-0x10]
    // 0x51c818: LoadField: r23 = r0->field_47
    //     0x51c818: ldur            w23, [x0, #0x47]
    // 0x51c81c: DecompressPointer r23
    //     0x51c81c: add             x23, x23, HEAP, lsl #32
    // 0x51c820: cmp             w23, NULL
    // 0x51c824: b.ne            #0x51c8e4
    // 0x51c828: LoadField: r23 = r0->field_f
    //     0x51c828: ldur            w23, [x0, #0xf]
    // 0x51c82c: DecompressPointer r23
    //     0x51c82c: add             x23, x23, HEAP, lsl #32
    // 0x51c830: stur            x23, [fp, #-8]
    // 0x51c834: cmp             w23, NULL
    // 0x51c838: b.eq            #0x51c8d8
    // 0x51c83c: r16 = 112
    //     0x51c83c: mov             x16, #0x70
    // 0x51c840: stp             x16, NULL, [SP, #-0x10]!
    // 0x51c844: r0 = ByteData()
    //     0x51c844: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x51c848: add             SP, SP, #0x10
    // 0x51c84c: stur            x0, [fp, #-0x90]
    // 0x51c850: r0 = Paint()
    //     0x51c850: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x51c854: mov             x1, x0
    // 0x51c858: ldur            x0, [fp, #-0x90]
    // 0x51c85c: StoreField: r1->field_7 = r0
    //     0x51c85c: stur            w0, [x1, #7]
    // 0x51c860: ldur            x2, [fp, #-8]
    // 0x51c864: r3 = LoadClassIdInstr(r2)
    //     0x51c864: ldur            x3, [x2, #-1]
    //     0x51c868: ubfx            x3, x3, #0xc, #0x14
    // 0x51c86c: lsl             x3, x3, #1
    // 0x51c870: r17 = 10124
    //     0x51c870: mov             x17, #0x278c
    // 0x51c874: cmp             w3, w17
    // 0x51c878: b.gt            #0x51c888
    // 0x51c87c: r17 = 10122
    //     0x51c87c: mov             x17, #0x278a
    // 0x51c880: cmp             w3, w17
    // 0x51c884: b.ge            #0x51c8a0
    // 0x51c888: r17 = 10114
    //     0x51c888: mov             x17, #0x2782
    // 0x51c88c: cmp             w3, w17
    // 0x51c890: b.eq            #0x51c8a0
    // 0x51c894: r17 = 10118
    //     0x51c894: mov             x17, #0x2786
    // 0x51c898: cmp             w3, w17
    // 0x51c89c: b.ne            #0x51c8ac
    // 0x51c8a0: LoadField: r3 = r2->field_7
    //     0x51c8a0: ldur            x3, [x2, #7]
    // 0x51c8a4: mov             x2, x3
    // 0x51c8a8: b               #0x51c8b8
    // 0x51c8ac: LoadField: r3 = r2->field_f
    //     0x51c8ac: ldur            w3, [x2, #0xf]
    // 0x51c8b0: DecompressPointer r3
    //     0x51c8b0: add             x3, x3, HEAP, lsl #32
    // 0x51c8b4: LoadField: r2 = r3->field_7
    //     0x51c8b4: ldur            x2, [x3, #7]
    // 0x51c8b8: eor             x3, x2, #0xff000000
    // 0x51c8bc: LoadField: r2 = r0->field_17
    //     0x51c8bc: ldur            w2, [x0, #0x17]
    // 0x51c8c0: DecompressPointer r2
    //     0x51c8c0: add             x2, x2, HEAP, lsl #32
    // 0x51c8c4: sxtw            x3, w3
    // 0x51c8c8: LoadField: r0 = r2->field_7
    //     0x51c8c8: ldur            x0, [x2, #7]
    // 0x51c8cc: str             w3, [x0, #4]
    // 0x51c8d0: mov             x0, x1
    // 0x51c8d4: b               #0x51c8dc
    // 0x51c8d8: r0 = Null
    //     0x51c8d8: mov             x0, NULL
    // 0x51c8dc: mov             x1, x0
    // 0x51c8e0: b               #0x51c8e8
    // 0x51c8e4: mov             x1, x23
    // 0x51c8e8: ldr             x0, [fp, #0x18]
    // 0x51c8ec: stur            x1, [fp, #-0xa0]
    // 0x51c8f0: LoadField: r2 = r0->field_5f
    //     0x51c8f0: ldur            w2, [x0, #0x5f]
    // 0x51c8f4: DecompressPointer r2
    //     0x51c8f4: add             x2, x2, HEAP, lsl #32
    // 0x51c8f8: stur            x2, [fp, #-0x98]
    // 0x51c8fc: LoadField: r3 = r0->field_63
    //     0x51c8fc: ldur            w3, [x0, #0x63]
    // 0x51c900: DecompressPointer r3
    //     0x51c900: add             x3, x3, HEAP, lsl #32
    // 0x51c904: stur            x3, [fp, #-0x90]
    // 0x51c908: LoadField: r4 = r0->field_67
    //     0x51c908: ldur            w4, [x0, #0x67]
    // 0x51c90c: DecompressPointer r4
    //     0x51c90c: add             x4, x4, HEAP, lsl #32
    // 0x51c910: stur            x4, [fp, #-8]
    // 0x51c914: r0 = TextStyle()
    //     0x51c914: bl              #0x51db7c  ; AllocateTextStyleStub -> TextStyle (size=0x44)
    // 0x51c918: stur            x0, [fp, #-0xa8]
    // 0x51c91c: ldur            x16, [fp, #-0x88]
    // 0x51c920: stp             x16, x0, [SP, #-0x10]!
    // 0x51c924: ldur            x16, [fp, #-0x40]
    // 0x51c928: ldur            lr, [fp, #-0x30]
    // 0x51c92c: stp             lr, x16, [SP, #-0x10]!
    // 0x51c930: ldur            x16, [fp, #-0x80]
    // 0x51c934: ldur            lr, [fp, #-0x78]
    // 0x51c938: stp             lr, x16, [SP, #-0x10]!
    // 0x51c93c: ldur            x16, [fp, #-0x70]
    // 0x51c940: ldur            lr, [fp, #-0x68]
    // 0x51c944: stp             lr, x16, [SP, #-0x10]!
    // 0x51c948: ldur            x16, [fp, #-0x60]
    // 0x51c94c: ldur            lr, [fp, #-0x58]
    // 0x51c950: stp             lr, x16, [SP, #-0x10]!
    // 0x51c954: ldur            x16, [fp, #-0x50]
    // 0x51c958: ldur            lr, [fp, #-0x48]
    // 0x51c95c: stp             lr, x16, [SP, #-0x10]!
    // 0x51c960: ldur            x16, [fp, #-0x38]
    // 0x51c964: ldur            lr, [fp, #-0x28]
    // 0x51c968: stp             lr, x16, [SP, #-0x10]!
    // 0x51c96c: ldur            x16, [fp, #-0x20]
    // 0x51c970: ldur            lr, [fp, #-0x18]
    // 0x51c974: stp             lr, x16, [SP, #-0x10]!
    // 0x51c978: ldur            x16, [fp, #-0x10]
    // 0x51c97c: ldur            lr, [fp, #-0xa0]
    // 0x51c980: stp             lr, x16, [SP, #-0x10]!
    // 0x51c984: ldur            x16, [fp, #-0x98]
    // 0x51c988: ldur            lr, [fp, #-0x90]
    // 0x51c98c: stp             lr, x16, [SP, #-0x10]!
    // 0x51c990: ldur            x16, [fp, #-8]
    // 0x51c994: SaveReg r16
    //     0x51c994: str             x16, [SP, #-8]!
    // 0x51c998: r4 = const [0, 0x15, 0x15, 0x4, background, 0x11, decoration, 0x4, decorationColor, 0x5, decorationStyle, 0x6, decorationThickness, 0x7, fontFamilyFallback, 0xc, fontFeatures, 0x13, fontStyle, 0x9, fontVariations, 0x14, fontWeight, 0x8, foreground, 0x10, height, 0xf, leadingDistribution, 0xb, letterSpacing, 0xd, shadows, 0x12, textBaseline, 0xa, wordSpacing, 0xe, null]
    //     0x51c998: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f4f8] List(39) [0, 0x15, 0x15, 0x4, "background", 0x11, "decoration", 0x4, "decorationColor", 0x5, "decorationStyle", 0x6, "decorationThickness", 0x7, "fontFamilyFallback", 0xc, "fontFeatures", 0x13, "fontStyle", 0x9, "fontVariations", 0x14, "fontWeight", 0x8, "foreground", 0x10, "height", 0xf, "leadingDistribution", 0xb, "letterSpacing", 0xd, "shadows", 0x12, "textBaseline", 0xa, "wordSpacing", 0xe, Null]
    //     0x51c99c: ldr             x4, [x4, #0x4f8]
    // 0x51c9a0: r0 = TextStyle()
    //     0x51c9a0: bl              #0x51cf34  ; [dart:ui] TextStyle::TextStyle
    // 0x51c9a4: add             SP, SP, #0xa8
    // 0x51c9a8: ldur            x0, [fp, #-0xa8]
    // 0x51c9ac: LeaveFrame
    //     0x51c9ac: mov             SP, fp
    //     0x51c9b0: ldp             fp, lr, [SP], #0x10
    // 0x51c9b4: ret
    //     0x51c9b4: ret             
    // 0x51c9b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51c9b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51c9bc: b               #0x51c710
    // 0x51c9c0: SaveReg d2
    //     0x51c9c0: str             q2, [SP, #-0x10]!
    // 0x51c9c4: stp             x10, x11, [SP, #-0x10]!
    // 0x51c9c8: stp             x8, x9, [SP, #-0x10]!
    // 0x51c9cc: stp             x6, x7, [SP, #-0x10]!
    // 0x51c9d0: stp             x4, x5, [SP, #-0x10]!
    // 0x51c9d4: stp             x2, x3, [SP, #-0x10]!
    // 0x51c9d8: stp             x0, x1, [SP, #-0x10]!
    // 0x51c9dc: r0 = AllocateDouble()
    //     0x51c9dc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x51c9e0: mov             x12, x0
    // 0x51c9e4: ldp             x0, x1, [SP], #0x10
    // 0x51c9e8: ldp             x2, x3, [SP], #0x10
    // 0x51c9ec: ldp             x4, x5, [SP], #0x10
    // 0x51c9f0: ldp             x6, x7, [SP], #0x10
    // 0x51c9f4: ldp             x8, x9, [SP], #0x10
    // 0x51c9f8: ldp             x10, x11, [SP], #0x10
    // 0x51c9fc: RestoreReg d2
    //     0x51c9fc: ldr             q2, [SP], #0x10
    // 0x51ca00: b               #0x51c7e0
  }
  RenderComparison compareTo(TextStyle, TextStyle) {
    // ** addr: 0x51ca1c, size: 0x90
    // 0x51ca1c: EnterFrame
    //     0x51ca1c: stp             fp, lr, [SP, #-0x10]!
    //     0x51ca20: mov             fp, SP
    // 0x51ca24: CheckStackOverflow
    //     0x51ca24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51ca28: cmp             SP, x16
    //     0x51ca2c: b.ls            #0x51ca8c
    // 0x51ca30: ldr             x0, [fp, #0x10]
    // 0x51ca34: r2 = Null
    //     0x51ca34: mov             x2, NULL
    // 0x51ca38: r1 = Null
    //     0x51ca38: mov             x1, NULL
    // 0x51ca3c: r4 = 59
    //     0x51ca3c: mov             x4, #0x3b
    // 0x51ca40: branchIfSmi(r0, 0x51ca4c)
    //     0x51ca40: tbz             w0, #0, #0x51ca4c
    // 0x51ca44: r4 = LoadClassIdInstr(r0)
    //     0x51ca44: ldur            x4, [x0, #-1]
    //     0x51ca48: ubfx            x4, x4, #0xc, #0x14
    // 0x51ca4c: sub             x4, x4, #0xae3
    // 0x51ca50: cmp             x4, #2
    // 0x51ca54: b.ls            #0x51ca6c
    // 0x51ca58: r8 = TextStyle
    //     0x51ca58: add             x8, PP, #0x28, lsl #12  ; [pp+0x283f8] Type: TextStyle
    //     0x51ca5c: ldr             x8, [x8, #0x3f8]
    // 0x51ca60: r3 = Null
    //     0x51ca60: add             x3, PP, #0x28, lsl #12  ; [pp+0x28658] Null
    //     0x51ca64: ldr             x3, [x3, #0x658]
    // 0x51ca68: r0 = TextStyle()
    //     0x51ca68: bl              #0x51cf10  ; IsType_TextStyle_Stub
    // 0x51ca6c: ldr             x16, [fp, #0x18]
    // 0x51ca70: ldr             lr, [fp, #0x10]
    // 0x51ca74: stp             lr, x16, [SP, #-0x10]!
    // 0x51ca78: r0 = compareTo()
    //     0x51ca78: bl              #0x51ca94  ; [package:flutter/src/painting/text_style.dart] TextStyle::compareTo
    // 0x51ca7c: add             SP, SP, #0x10
    // 0x51ca80: LeaveFrame
    //     0x51ca80: mov             SP, fp
    //     0x51ca84: ldp             fp, lr, [SP], #0x10
    // 0x51ca88: ret
    //     0x51ca88: ret             
    // 0x51ca8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51ca8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51ca90: b               #0x51ca30
  }
  RenderComparison compareTo(TextStyle, TextStyle) {
    // ** addr: 0x51ca94, size: 0x47c
    // 0x51ca94: EnterFrame
    //     0x51ca94: stp             fp, lr, [SP, #-0x10]!
    //     0x51ca98: mov             fp, SP
    // 0x51ca9c: CheckStackOverflow
    //     0x51ca9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51caa0: cmp             SP, x16
    //     0x51caa4: b.ls            #0x51cf08
    // 0x51caa8: ldr             x2, [fp, #0x18]
    // 0x51caac: ldr             x1, [fp, #0x10]
    // 0x51cab0: cmp             w2, w1
    // 0x51cab4: b.ne            #0x51cacc
    // 0x51cab8: r0 = Instance_RenderComparison
    //     0x51cab8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0x51cabc: ldr             x0, [x0, #0x438]
    // 0x51cac0: LeaveFrame
    //     0x51cac0: mov             SP, fp
    //     0x51cac4: ldp             fp, lr, [SP], #0x10
    // 0x51cac8: ret
    //     0x51cac8: ret             
    // 0x51cacc: LoadField: r0 = r2->field_7
    //     0x51cacc: ldur            w0, [x2, #7]
    // 0x51cad0: DecompressPointer r0
    //     0x51cad0: add             x0, x0, HEAP, lsl #32
    // 0x51cad4: LoadField: r3 = r1->field_7
    //     0x51cad4: ldur            w3, [x1, #7]
    // 0x51cad8: DecompressPointer r3
    //     0x51cad8: add             x3, x3, HEAP, lsl #32
    // 0x51cadc: cmp             w0, w3
    // 0x51cae0: b.ne            #0x51cd94
    // 0x51cae4: LoadField: r0 = r2->field_13
    //     0x51cae4: ldur            w0, [x2, #0x13]
    // 0x51cae8: DecompressPointer r0
    //     0x51cae8: add             x0, x0, HEAP, lsl #32
    // 0x51caec: LoadField: r3 = r1->field_13
    //     0x51caec: ldur            w3, [x1, #0x13]
    // 0x51caf0: DecompressPointer r3
    //     0x51caf0: add             x3, x3, HEAP, lsl #32
    // 0x51caf4: r4 = LoadClassIdInstr(r0)
    //     0x51caf4: ldur            x4, [x0, #-1]
    //     0x51caf8: ubfx            x4, x4, #0xc, #0x14
    // 0x51cafc: stp             x3, x0, [SP, #-0x10]!
    // 0x51cb00: mov             x0, x4
    // 0x51cb04: mov             lr, x0
    // 0x51cb08: ldr             lr, [x21, lr, lsl #3]
    // 0x51cb0c: blr             lr
    // 0x51cb10: add             SP, SP, #0x10
    // 0x51cb14: tbnz            w0, #4, #0x51cd94
    // 0x51cb18: ldr             x2, [fp, #0x18]
    // 0x51cb1c: ldr             x1, [fp, #0x10]
    // 0x51cb20: LoadField: r0 = r2->field_1f
    //     0x51cb20: ldur            w0, [x2, #0x1f]
    // 0x51cb24: DecompressPointer r0
    //     0x51cb24: add             x0, x0, HEAP, lsl #32
    // 0x51cb28: LoadField: r3 = r1->field_1f
    //     0x51cb28: ldur            w3, [x1, #0x1f]
    // 0x51cb2c: DecompressPointer r3
    //     0x51cb2c: add             x3, x3, HEAP, lsl #32
    // 0x51cb30: r4 = LoadClassIdInstr(r0)
    //     0x51cb30: ldur            x4, [x0, #-1]
    //     0x51cb34: ubfx            x4, x4, #0xc, #0x14
    // 0x51cb38: stp             x3, x0, [SP, #-0x10]!
    // 0x51cb3c: mov             x0, x4
    // 0x51cb40: mov             lr, x0
    // 0x51cb44: ldr             lr, [x21, lr, lsl #3]
    // 0x51cb48: blr             lr
    // 0x51cb4c: add             SP, SP, #0x10
    // 0x51cb50: tbnz            w0, #4, #0x51cd94
    // 0x51cb54: ldr             x2, [fp, #0x18]
    // 0x51cb58: ldr             x1, [fp, #0x10]
    // 0x51cb5c: LoadField: r0 = r2->field_23
    //     0x51cb5c: ldur            w0, [x2, #0x23]
    // 0x51cb60: DecompressPointer r0
    //     0x51cb60: add             x0, x0, HEAP, lsl #32
    // 0x51cb64: LoadField: r3 = r1->field_23
    //     0x51cb64: ldur            w3, [x1, #0x23]
    // 0x51cb68: DecompressPointer r3
    //     0x51cb68: add             x3, x3, HEAP, lsl #32
    // 0x51cb6c: cmp             w0, w3
    // 0x51cb70: b.ne            #0x51cd94
    // 0x51cb74: LoadField: r0 = r2->field_27
    //     0x51cb74: ldur            w0, [x2, #0x27]
    // 0x51cb78: DecompressPointer r0
    //     0x51cb78: add             x0, x0, HEAP, lsl #32
    // 0x51cb7c: LoadField: r3 = r1->field_27
    //     0x51cb7c: ldur            w3, [x1, #0x27]
    // 0x51cb80: DecompressPointer r3
    //     0x51cb80: add             x3, x3, HEAP, lsl #32
    // 0x51cb84: cmp             w0, w3
    // 0x51cb88: b.ne            #0x51cd94
    // 0x51cb8c: LoadField: r0 = r2->field_2b
    //     0x51cb8c: ldur            w0, [x2, #0x2b]
    // 0x51cb90: DecompressPointer r0
    //     0x51cb90: add             x0, x0, HEAP, lsl #32
    // 0x51cb94: LoadField: r3 = r1->field_2b
    //     0x51cb94: ldur            w3, [x1, #0x2b]
    // 0x51cb98: DecompressPointer r3
    //     0x51cb98: add             x3, x3, HEAP, lsl #32
    // 0x51cb9c: r4 = LoadClassIdInstr(r0)
    //     0x51cb9c: ldur            x4, [x0, #-1]
    //     0x51cba0: ubfx            x4, x4, #0xc, #0x14
    // 0x51cba4: stp             x3, x0, [SP, #-0x10]!
    // 0x51cba8: mov             x0, x4
    // 0x51cbac: mov             lr, x0
    // 0x51cbb0: ldr             lr, [x21, lr, lsl #3]
    // 0x51cbb4: blr             lr
    // 0x51cbb8: add             SP, SP, #0x10
    // 0x51cbbc: tbnz            w0, #4, #0x51cd94
    // 0x51cbc0: ldr             x2, [fp, #0x18]
    // 0x51cbc4: ldr             x1, [fp, #0x10]
    // 0x51cbc8: LoadField: r0 = r2->field_2f
    //     0x51cbc8: ldur            w0, [x2, #0x2f]
    // 0x51cbcc: DecompressPointer r0
    //     0x51cbcc: add             x0, x0, HEAP, lsl #32
    // 0x51cbd0: LoadField: r3 = r1->field_2f
    //     0x51cbd0: ldur            w3, [x1, #0x2f]
    // 0x51cbd4: DecompressPointer r3
    //     0x51cbd4: add             x3, x3, HEAP, lsl #32
    // 0x51cbd8: r4 = LoadClassIdInstr(r0)
    //     0x51cbd8: ldur            x4, [x0, #-1]
    //     0x51cbdc: ubfx            x4, x4, #0xc, #0x14
    // 0x51cbe0: stp             x3, x0, [SP, #-0x10]!
    // 0x51cbe4: mov             x0, x4
    // 0x51cbe8: mov             lr, x0
    // 0x51cbec: ldr             lr, [x21, lr, lsl #3]
    // 0x51cbf0: blr             lr
    // 0x51cbf4: add             SP, SP, #0x10
    // 0x51cbf8: tbnz            w0, #4, #0x51cd94
    // 0x51cbfc: ldr             x2, [fp, #0x18]
    // 0x51cc00: ldr             x1, [fp, #0x10]
    // 0x51cc04: LoadField: r0 = r2->field_33
    //     0x51cc04: ldur            w0, [x2, #0x33]
    // 0x51cc08: DecompressPointer r0
    //     0x51cc08: add             x0, x0, HEAP, lsl #32
    // 0x51cc0c: LoadField: r3 = r1->field_33
    //     0x51cc0c: ldur            w3, [x1, #0x33]
    // 0x51cc10: DecompressPointer r3
    //     0x51cc10: add             x3, x3, HEAP, lsl #32
    // 0x51cc14: cmp             w0, w3
    // 0x51cc18: b.ne            #0x51cd94
    // 0x51cc1c: LoadField: r0 = r2->field_37
    //     0x51cc1c: ldur            w0, [x2, #0x37]
    // 0x51cc20: DecompressPointer r0
    //     0x51cc20: add             x0, x0, HEAP, lsl #32
    // 0x51cc24: LoadField: r3 = r1->field_37
    //     0x51cc24: ldur            w3, [x1, #0x37]
    // 0x51cc28: DecompressPointer r3
    //     0x51cc28: add             x3, x3, HEAP, lsl #32
    // 0x51cc2c: r4 = LoadClassIdInstr(r0)
    //     0x51cc2c: ldur            x4, [x0, #-1]
    //     0x51cc30: ubfx            x4, x4, #0xc, #0x14
    // 0x51cc34: stp             x3, x0, [SP, #-0x10]!
    // 0x51cc38: mov             x0, x4
    // 0x51cc3c: mov             lr, x0
    // 0x51cc40: ldr             lr, [x21, lr, lsl #3]
    // 0x51cc44: blr             lr
    // 0x51cc48: add             SP, SP, #0x10
    // 0x51cc4c: tbnz            w0, #4, #0x51cd94
    // 0x51cc50: ldr             x1, [fp, #0x18]
    // 0x51cc54: ldr             x0, [fp, #0x10]
    // 0x51cc58: LoadField: r2 = r1->field_3b
    //     0x51cc58: ldur            w2, [x1, #0x3b]
    // 0x51cc5c: DecompressPointer r2
    //     0x51cc5c: add             x2, x2, HEAP, lsl #32
    // 0x51cc60: LoadField: r3 = r0->field_3b
    //     0x51cc60: ldur            w3, [x0, #0x3b]
    // 0x51cc64: DecompressPointer r3
    //     0x51cc64: add             x3, x3, HEAP, lsl #32
    // 0x51cc68: cmp             w2, w3
    // 0x51cc6c: b.ne            #0x51cd94
    // 0x51cc70: LoadField: r2 = r1->field_43
    //     0x51cc70: ldur            w2, [x1, #0x43]
    // 0x51cc74: DecompressPointer r2
    //     0x51cc74: add             x2, x2, HEAP, lsl #32
    // 0x51cc78: LoadField: r3 = r0->field_43
    //     0x51cc78: ldur            w3, [x0, #0x43]
    // 0x51cc7c: DecompressPointer r3
    //     0x51cc7c: add             x3, x3, HEAP, lsl #32
    // 0x51cc80: cmp             w2, w3
    // 0x51cc84: b.ne            #0x51cd94
    // 0x51cc88: LoadField: r2 = r1->field_47
    //     0x51cc88: ldur            w2, [x1, #0x47]
    // 0x51cc8c: DecompressPointer r2
    //     0x51cc8c: add             x2, x2, HEAP, lsl #32
    // 0x51cc90: LoadField: r3 = r0->field_47
    //     0x51cc90: ldur            w3, [x0, #0x47]
    // 0x51cc94: DecompressPointer r3
    //     0x51cc94: add             x3, x3, HEAP, lsl #32
    // 0x51cc98: cmp             w2, w3
    // 0x51cc9c: b.ne            #0x51cd94
    // 0x51cca0: LoadField: r2 = r1->field_5f
    //     0x51cca0: ldur            w2, [x1, #0x5f]
    // 0x51cca4: DecompressPointer r2
    //     0x51cca4: add             x2, x2, HEAP, lsl #32
    // 0x51cca8: LoadField: r3 = r0->field_5f
    //     0x51cca8: ldur            w3, [x0, #0x5f]
    // 0x51ccac: DecompressPointer r3
    //     0x51ccac: add             x3, x3, HEAP, lsl #32
    // 0x51ccb0: r16 = <Shadow>
    //     0x51ccb0: add             x16, PP, #0xd, lsl #12  ; [pp+0xde68] TypeArguments: <Shadow>
    //     0x51ccb4: ldr             x16, [x16, #0xe68]
    // 0x51ccb8: stp             x2, x16, [SP, #-0x10]!
    // 0x51ccbc: SaveReg r3
    //     0x51ccbc: str             x3, [SP, #-8]!
    // 0x51ccc0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x51ccc0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x51ccc4: r0 = listEquals()
    //     0x51ccc4: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x51ccc8: add             SP, SP, #0x18
    // 0x51cccc: tbnz            w0, #4, #0x51cd94
    // 0x51ccd0: ldr             x1, [fp, #0x18]
    // 0x51ccd4: ldr             x0, [fp, #0x10]
    // 0x51ccd8: LoadField: r2 = r1->field_63
    //     0x51ccd8: ldur            w2, [x1, #0x63]
    // 0x51ccdc: DecompressPointer r2
    //     0x51ccdc: add             x2, x2, HEAP, lsl #32
    // 0x51cce0: LoadField: r3 = r0->field_63
    //     0x51cce0: ldur            w3, [x0, #0x63]
    // 0x51cce4: DecompressPointer r3
    //     0x51cce4: add             x3, x3, HEAP, lsl #32
    // 0x51cce8: r16 = <FontFeature>
    //     0x51cce8: add             x16, PP, #0xd, lsl #12  ; [pp+0xde78] TypeArguments: <FontFeature>
    //     0x51ccec: ldr             x16, [x16, #0xe78]
    // 0x51ccf0: stp             x2, x16, [SP, #-0x10]!
    // 0x51ccf4: SaveReg r3
    //     0x51ccf4: str             x3, [SP, #-8]!
    // 0x51ccf8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x51ccf8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x51ccfc: r0 = listEquals()
    //     0x51ccfc: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x51cd00: add             SP, SP, #0x18
    // 0x51cd04: tbnz            w0, #4, #0x51cd94
    // 0x51cd08: ldr             x1, [fp, #0x18]
    // 0x51cd0c: ldr             x0, [fp, #0x10]
    // 0x51cd10: LoadField: r2 = r1->field_67
    //     0x51cd10: ldur            w2, [x1, #0x67]
    // 0x51cd14: DecompressPointer r2
    //     0x51cd14: add             x2, x2, HEAP, lsl #32
    // 0x51cd18: LoadField: r3 = r0->field_67
    //     0x51cd18: ldur            w3, [x0, #0x67]
    // 0x51cd1c: DecompressPointer r3
    //     0x51cd1c: add             x3, x3, HEAP, lsl #32
    // 0x51cd20: r16 = <FontVariation>
    //     0x51cd20: add             x16, PP, #0xd, lsl #12  ; [pp+0xde80] TypeArguments: <FontVariation>
    //     0x51cd24: ldr             x16, [x16, #0xe80]
    // 0x51cd28: stp             x2, x16, [SP, #-0x10]!
    // 0x51cd2c: SaveReg r3
    //     0x51cd2c: str             x3, [SP, #-8]!
    // 0x51cd30: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x51cd30: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x51cd34: r0 = listEquals()
    //     0x51cd34: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x51cd38: add             SP, SP, #0x18
    // 0x51cd3c: tbnz            w0, #4, #0x51cd94
    // 0x51cd40: ldr             x1, [fp, #0x18]
    // 0x51cd44: ldr             x0, [fp, #0x10]
    // 0x51cd48: LoadField: r2 = r1->field_17
    //     0x51cd48: ldur            w2, [x1, #0x17]
    // 0x51cd4c: DecompressPointer r2
    //     0x51cd4c: add             x2, x2, HEAP, lsl #32
    // 0x51cd50: LoadField: r3 = r0->field_17
    //     0x51cd50: ldur            w3, [x0, #0x17]
    // 0x51cd54: DecompressPointer r3
    //     0x51cd54: add             x3, x3, HEAP, lsl #32
    // 0x51cd58: r16 = <String>
    //     0x51cd58: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x51cd5c: stp             x2, x16, [SP, #-0x10]!
    // 0x51cd60: SaveReg r3
    //     0x51cd60: str             x3, [SP, #-8]!
    // 0x51cd64: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x51cd64: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x51cd68: r0 = listEquals()
    //     0x51cd68: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x51cd6c: add             SP, SP, #0x18
    // 0x51cd70: tbnz            w0, #4, #0x51cd94
    // 0x51cd74: ldr             x2, [fp, #0x18]
    // 0x51cd78: ldr             x1, [fp, #0x10]
    // 0x51cd7c: LoadField: r0 = r2->field_6b
    //     0x51cd7c: ldur            w0, [x2, #0x6b]
    // 0x51cd80: DecompressPointer r0
    //     0x51cd80: add             x0, x0, HEAP, lsl #32
    // 0x51cd84: LoadField: r3 = r1->field_6b
    //     0x51cd84: ldur            w3, [x1, #0x6b]
    // 0x51cd88: DecompressPointer r3
    //     0x51cd88: add             x3, x3, HEAP, lsl #32
    // 0x51cd8c: cmp             w0, w3
    // 0x51cd90: b.eq            #0x51cda8
    // 0x51cd94: r0 = Instance_RenderComparison
    //     0x51cd94: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0x51cd98: ldr             x0, [x0, #0x470]
    // 0x51cd9c: LeaveFrame
    //     0x51cd9c: mov             SP, fp
    //     0x51cda0: ldp             fp, lr, [SP], #0x10
    // 0x51cda4: ret
    //     0x51cda4: ret             
    // 0x51cda8: LoadField: r0 = r2->field_b
    //     0x51cda8: ldur            w0, [x2, #0xb]
    // 0x51cdac: DecompressPointer r0
    //     0x51cdac: add             x0, x0, HEAP, lsl #32
    // 0x51cdb0: LoadField: r3 = r1->field_b
    //     0x51cdb0: ldur            w3, [x1, #0xb]
    // 0x51cdb4: DecompressPointer r3
    //     0x51cdb4: add             x3, x3, HEAP, lsl #32
    // 0x51cdb8: r4 = LoadClassIdInstr(r0)
    //     0x51cdb8: ldur            x4, [x0, #-1]
    //     0x51cdbc: ubfx            x4, x4, #0xc, #0x14
    // 0x51cdc0: stp             x3, x0, [SP, #-0x10]!
    // 0x51cdc4: mov             x0, x4
    // 0x51cdc8: mov             lr, x0
    // 0x51cdcc: ldr             lr, [x21, lr, lsl #3]
    // 0x51cdd0: blr             lr
    // 0x51cdd4: add             SP, SP, #0x10
    // 0x51cdd8: tbnz            w0, #4, #0x51cee0
    // 0x51cddc: ldr             x2, [fp, #0x18]
    // 0x51cde0: ldr             x1, [fp, #0x10]
    // 0x51cde4: LoadField: r0 = r2->field_f
    //     0x51cde4: ldur            w0, [x2, #0xf]
    // 0x51cde8: DecompressPointer r0
    //     0x51cde8: add             x0, x0, HEAP, lsl #32
    // 0x51cdec: LoadField: r3 = r1->field_f
    //     0x51cdec: ldur            w3, [x1, #0xf]
    // 0x51cdf0: DecompressPointer r3
    //     0x51cdf0: add             x3, x3, HEAP, lsl #32
    // 0x51cdf4: r4 = LoadClassIdInstr(r0)
    //     0x51cdf4: ldur            x4, [x0, #-1]
    //     0x51cdf8: ubfx            x4, x4, #0xc, #0x14
    // 0x51cdfc: stp             x3, x0, [SP, #-0x10]!
    // 0x51ce00: mov             x0, x4
    // 0x51ce04: mov             lr, x0
    // 0x51ce08: ldr             lr, [x21, lr, lsl #3]
    // 0x51ce0c: blr             lr
    // 0x51ce10: add             SP, SP, #0x10
    // 0x51ce14: tbnz            w0, #4, #0x51cee0
    // 0x51ce18: ldr             x2, [fp, #0x18]
    // 0x51ce1c: ldr             x1, [fp, #0x10]
    // 0x51ce20: LoadField: r0 = r2->field_4b
    //     0x51ce20: ldur            w0, [x2, #0x4b]
    // 0x51ce24: DecompressPointer r0
    //     0x51ce24: add             x0, x0, HEAP, lsl #32
    // 0x51ce28: LoadField: r3 = r1->field_4b
    //     0x51ce28: ldur            w3, [x1, #0x4b]
    // 0x51ce2c: DecompressPointer r3
    //     0x51ce2c: add             x3, x3, HEAP, lsl #32
    // 0x51ce30: r4 = LoadClassIdInstr(r0)
    //     0x51ce30: ldur            x4, [x0, #-1]
    //     0x51ce34: ubfx            x4, x4, #0xc, #0x14
    // 0x51ce38: stp             x3, x0, [SP, #-0x10]!
    // 0x51ce3c: mov             x0, x4
    // 0x51ce40: mov             lr, x0
    // 0x51ce44: ldr             lr, [x21, lr, lsl #3]
    // 0x51ce48: blr             lr
    // 0x51ce4c: add             SP, SP, #0x10
    // 0x51ce50: tbnz            w0, #4, #0x51cee0
    // 0x51ce54: ldr             x2, [fp, #0x18]
    // 0x51ce58: ldr             x1, [fp, #0x10]
    // 0x51ce5c: LoadField: r0 = r2->field_4f
    //     0x51ce5c: ldur            w0, [x2, #0x4f]
    // 0x51ce60: DecompressPointer r0
    //     0x51ce60: add             x0, x0, HEAP, lsl #32
    // 0x51ce64: LoadField: r3 = r1->field_4f
    //     0x51ce64: ldur            w3, [x1, #0x4f]
    // 0x51ce68: DecompressPointer r3
    //     0x51ce68: add             x3, x3, HEAP, lsl #32
    // 0x51ce6c: r4 = LoadClassIdInstr(r0)
    //     0x51ce6c: ldur            x4, [x0, #-1]
    //     0x51ce70: ubfx            x4, x4, #0xc, #0x14
    // 0x51ce74: stp             x3, x0, [SP, #-0x10]!
    // 0x51ce78: mov             x0, x4
    // 0x51ce7c: mov             lr, x0
    // 0x51ce80: ldr             lr, [x21, lr, lsl #3]
    // 0x51ce84: blr             lr
    // 0x51ce88: add             SP, SP, #0x10
    // 0x51ce8c: tbnz            w0, #4, #0x51cee0
    // 0x51ce90: ldr             x1, [fp, #0x18]
    // 0x51ce94: ldr             x0, [fp, #0x10]
    // 0x51ce98: LoadField: r2 = r1->field_53
    //     0x51ce98: ldur            w2, [x1, #0x53]
    // 0x51ce9c: DecompressPointer r2
    //     0x51ce9c: add             x2, x2, HEAP, lsl #32
    // 0x51cea0: LoadField: r3 = r0->field_53
    //     0x51cea0: ldur            w3, [x0, #0x53]
    // 0x51cea4: DecompressPointer r3
    //     0x51cea4: add             x3, x3, HEAP, lsl #32
    // 0x51cea8: cmp             w2, w3
    // 0x51ceac: b.ne            #0x51cee0
    // 0x51ceb0: LoadField: r2 = r1->field_57
    //     0x51ceb0: ldur            w2, [x1, #0x57]
    // 0x51ceb4: DecompressPointer r2
    //     0x51ceb4: add             x2, x2, HEAP, lsl #32
    // 0x51ceb8: LoadField: r1 = r0->field_57
    //     0x51ceb8: ldur            w1, [x0, #0x57]
    // 0x51cebc: DecompressPointer r1
    //     0x51cebc: add             x1, x1, HEAP, lsl #32
    // 0x51cec0: r0 = LoadClassIdInstr(r2)
    //     0x51cec0: ldur            x0, [x2, #-1]
    //     0x51cec4: ubfx            x0, x0, #0xc, #0x14
    // 0x51cec8: stp             x1, x2, [SP, #-0x10]!
    // 0x51cecc: mov             lr, x0
    // 0x51ced0: ldr             lr, [x21, lr, lsl #3]
    // 0x51ced4: blr             lr
    // 0x51ced8: add             SP, SP, #0x10
    // 0x51cedc: tbz             w0, #4, #0x51cef4
    // 0x51cee0: r0 = Instance_RenderComparison
    //     0x51cee0: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d488] Obj!RenderComparison@b65011
    //     0x51cee4: ldr             x0, [x0, #0x488]
    // 0x51cee8: LeaveFrame
    //     0x51cee8: mov             SP, fp
    //     0x51ceec: ldp             fp, lr, [SP], #0x10
    // 0x51cef0: ret
    //     0x51cef0: ret             
    // 0x51cef4: r0 = Instance_RenderComparison
    //     0x51cef4: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0x51cef8: ldr             x0, [x0, #0x438]
    // 0x51cefc: LeaveFrame
    //     0x51cefc: mov             SP, fp
    //     0x51cf00: ldp             fp, lr, [SP], #0x10
    // 0x51cf04: ret
    //     0x51cf04: ret             
    // 0x51cf08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51cf08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51cf0c: b               #0x51caa8
  }
  _ getParagraphStyle(/* No info */) {
    // ** addr: 0x51e550, size: 0x2b8
    // 0x51e550: EnterFrame
    //     0x51e550: stp             fp, lr, [SP, #-0x10]!
    //     0x51e554: mov             fp, SP
    // 0x51e558: AllocStack(0x78)
    //     0x51e558: sub             SP, SP, #0x78
    // 0x51e55c: CheckStackOverflow
    //     0x51e55c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51e560: cmp             SP, x16
    //     0x51e564: b.ls            #0x51e7b0
    // 0x51e568: ldr             x0, [fp, #0x48]
    // 0x51e56c: LoadField: r1 = r0->field_3b
    //     0x51e56c: ldur            w1, [x0, #0x3b]
    // 0x51e570: DecompressPointer r1
    //     0x51e570: add             x1, x1, HEAP, lsl #32
    // 0x51e574: cmp             w1, NULL
    // 0x51e578: b.ne            #0x51e584
    // 0x51e57c: r1 = Null
    //     0x51e57c: mov             x1, NULL
    // 0x51e580: b               #0x51e5a8
    // 0x51e584: r0 = TextHeightBehavior()
    //     0x51e584: bl              #0x51ed28  ; AllocateTextHeightBehaviorStub -> TextHeightBehavior (size=0x14)
    // 0x51e588: mov             x1, x0
    // 0x51e58c: r0 = true
    //     0x51e58c: add             x0, NULL, #0x20  ; true
    // 0x51e590: StoreField: r1->field_7 = r0
    //     0x51e590: stur            w0, [x1, #7]
    // 0x51e594: StoreField: r1->field_b = r0
    //     0x51e594: stur            w0, [x1, #0xb]
    // 0x51e598: r0 = Instance_TextLeadingDistribution
    //     0x51e598: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f528] Obj!TextLeadingDistribution@b66e71
    //     0x51e59c: ldr             x0, [x0, #0x528]
    // 0x51e5a0: StoreField: r1->field_f = r0
    //     0x51e5a0: stur            w0, [x1, #0xf]
    // 0x51e5a4: ldr             x0, [fp, #0x48]
    // 0x51e5a8: stur            x1, [fp, #-0x68]
    // 0x51e5ac: LoadField: r2 = r0->field_23
    //     0x51e5ac: ldur            w2, [x0, #0x23]
    // 0x51e5b0: DecompressPointer r2
    //     0x51e5b0: add             x2, x2, HEAP, lsl #32
    // 0x51e5b4: stur            x2, [fp, #-0x60]
    // 0x51e5b8: LoadField: r3 = r0->field_27
    //     0x51e5b8: ldur            w3, [x0, #0x27]
    // 0x51e5bc: DecompressPointer r3
    //     0x51e5bc: add             x3, x3, HEAP, lsl #32
    // 0x51e5c0: stur            x3, [fp, #-0x58]
    // 0x51e5c4: LoadField: r4 = r0->field_13
    //     0x51e5c4: ldur            w4, [x0, #0x13]
    // 0x51e5c8: DecompressPointer r4
    //     0x51e5c8: add             x4, x4, HEAP, lsl #32
    // 0x51e5cc: stur            x4, [fp, #-0x50]
    // 0x51e5d0: LoadField: r5 = r0->field_1f
    //     0x51e5d0: ldur            w5, [x0, #0x1f]
    // 0x51e5d4: DecompressPointer r5
    //     0x51e5d4: add             x5, x5, HEAP, lsl #32
    // 0x51e5d8: cmp             w5, NULL
    // 0x51e5dc: b.ne            #0x51e5e8
    // 0x51e5e0: d1 = 14.000000
    //     0x51e5e0: fmov            d1, #14.00000000
    // 0x51e5e4: b               #0x51e5f0
    // 0x51e5e8: LoadField: d0 = r5->field_7
    //     0x51e5e8: ldur            d0, [x5, #7]
    // 0x51e5ec: mov             v1.16b, v0.16b
    // 0x51e5f0: ldr             x5, [fp, #0x28]
    // 0x51e5f4: ldr             d0, [fp, #0x10]
    // 0x51e5f8: fmul            d2, d1, d0
    // 0x51e5fc: stur            d2, [fp, #-0x78]
    // 0x51e600: LoadField: r6 = r0->field_37
    //     0x51e600: ldur            w6, [x0, #0x37]
    // 0x51e604: DecompressPointer r6
    //     0x51e604: add             x6, x6, HEAP, lsl #32
    // 0x51e608: stur            x6, [fp, #-0x48]
    // 0x51e60c: cmp             w5, NULL
    // 0x51e610: b.ne            #0x51e620
    // 0x51e614: mov             v0.16b, v2.16b
    // 0x51e618: r0 = Null
    //     0x51e618: mov             x0, NULL
    // 0x51e61c: b               #0x51e70c
    // 0x51e620: LoadField: r0 = r5->field_7
    //     0x51e620: ldur            w0, [x5, #7]
    // 0x51e624: DecompressPointer r0
    //     0x51e624: add             x0, x0, HEAP, lsl #32
    // 0x51e628: stur            x0, [fp, #-0x40]
    // 0x51e62c: LoadField: r7 = r5->field_b
    //     0x51e62c: ldur            w7, [x5, #0xb]
    // 0x51e630: DecompressPointer r7
    //     0x51e630: add             x7, x7, HEAP, lsl #32
    // 0x51e634: stur            x7, [fp, #-0x38]
    // 0x51e638: LoadField: r8 = r5->field_13
    //     0x51e638: ldur            w8, [x5, #0x13]
    // 0x51e63c: DecompressPointer r8
    //     0x51e63c: add             x8, x8, HEAP, lsl #32
    // 0x51e640: cmp             w8, NULL
    // 0x51e644: b.ne            #0x51e650
    // 0x51e648: r8 = Null
    //     0x51e648: mov             x8, NULL
    // 0x51e64c: b               #0x51e680
    // 0x51e650: LoadField: d1 = r8->field_7
    //     0x51e650: ldur            d1, [x8, #7]
    // 0x51e654: fmul            d3, d1, d0
    // 0x51e658: r8 = inline_Allocate_Double()
    //     0x51e658: ldp             x8, x9, [THR, #0x60]  ; THR::top
    //     0x51e65c: add             x8, x8, #0x10
    //     0x51e660: cmp             x9, x8
    //     0x51e664: b.ls            #0x51e7b8
    //     0x51e668: str             x8, [THR, #0x60]  ; THR::top
    //     0x51e66c: sub             x8, x8, #0xf
    //     0x51e670: mov             x9, #0xd108
    //     0x51e674: movk            x9, #3, lsl #16
    //     0x51e678: stur            x9, [x8, #-1]
    // 0x51e67c: StoreField: r8->field_7 = d3
    //     0x51e67c: stur            d3, [x8, #7]
    // 0x51e680: stur            x8, [fp, #-0x30]
    // 0x51e684: LoadField: r9 = r5->field_17
    //     0x51e684: ldur            w9, [x5, #0x17]
    // 0x51e688: DecompressPointer r9
    //     0x51e688: add             x9, x9, HEAP, lsl #32
    // 0x51e68c: stur            x9, [fp, #-0x28]
    // 0x51e690: LoadField: r10 = r5->field_27
    //     0x51e690: ldur            w10, [x5, #0x27]
    // 0x51e694: DecompressPointer r10
    //     0x51e694: add             x10, x10, HEAP, lsl #32
    // 0x51e698: stur            x10, [fp, #-0x20]
    // 0x51e69c: LoadField: r11 = r5->field_1f
    //     0x51e69c: ldur            w11, [x5, #0x1f]
    // 0x51e6a0: DecompressPointer r11
    //     0x51e6a0: add             x11, x11, HEAP, lsl #32
    // 0x51e6a4: stur            x11, [fp, #-0x18]
    // 0x51e6a8: LoadField: r12 = r5->field_23
    //     0x51e6a8: ldur            w12, [x5, #0x23]
    // 0x51e6ac: DecompressPointer r12
    //     0x51e6ac: add             x12, x12, HEAP, lsl #32
    // 0x51e6b0: stur            x12, [fp, #-0x10]
    // 0x51e6b4: LoadField: r13 = r5->field_2b
    //     0x51e6b4: ldur            w13, [x5, #0x2b]
    // 0x51e6b8: DecompressPointer r13
    //     0x51e6b8: add             x13, x13, HEAP, lsl #32
    // 0x51e6bc: stur            x13, [fp, #-8]
    // 0x51e6c0: r0 = StrutStyle()
    //     0x51e6c0: bl              #0x51ed1c  ; AllocateStrutStyleStub -> StrutStyle (size=0x18)
    // 0x51e6c4: stur            x0, [fp, #-0x70]
    // 0x51e6c8: ldur            x16, [fp, #-0x40]
    // 0x51e6cc: stp             x16, x0, [SP, #-0x10]!
    // 0x51e6d0: ldur            x16, [fp, #-0x38]
    // 0x51e6d4: ldur            lr, [fp, #-0x30]
    // 0x51e6d8: stp             lr, x16, [SP, #-0x10]!
    // 0x51e6dc: ldur            x16, [fp, #-0x10]
    // 0x51e6e0: ldur            lr, [fp, #-0x18]
    // 0x51e6e4: stp             lr, x16, [SP, #-0x10]!
    // 0x51e6e8: ldur            x16, [fp, #-8]
    // 0x51e6ec: ldur            lr, [fp, #-0x28]
    // 0x51e6f0: stp             lr, x16, [SP, #-0x10]!
    // 0x51e6f4: ldur            x16, [fp, #-0x20]
    // 0x51e6f8: SaveReg r16
    //     0x51e6f8: str             x16, [SP, #-8]!
    // 0x51e6fc: r0 = StrutStyle()
    //     0x51e6fc: bl              #0x51e808  ; [dart:ui] StrutStyle::StrutStyle
    // 0x51e700: add             SP, SP, #0x48
    // 0x51e704: ldur            x0, [fp, #-0x70]
    // 0x51e708: ldur            d0, [fp, #-0x78]
    // 0x51e70c: stur            x0, [fp, #-0x10]
    // 0x51e710: r1 = inline_Allocate_Double()
    //     0x51e710: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x51e714: add             x1, x1, #0x10
    //     0x51e718: cmp             x2, x1
    //     0x51e71c: b.ls            #0x51e7ec
    //     0x51e720: str             x1, [THR, #0x60]  ; THR::top
    //     0x51e724: sub             x1, x1, #0xf
    //     0x51e728: mov             x2, #0xd108
    //     0x51e72c: movk            x2, #3, lsl #16
    //     0x51e730: stur            x2, [x1, #-1]
    // 0x51e734: StoreField: r1->field_7 = d0
    //     0x51e734: stur            d0, [x1, #7]
    // 0x51e738: stur            x1, [fp, #-8]
    // 0x51e73c: r0 = ParagraphStyle()
    //     0x51e73c: bl              #0x51e544  ; AllocateParagraphStyleStub -> ParagraphStyle (size=0x28)
    // 0x51e740: stur            x0, [fp, #-0x18]
    // 0x51e744: ldr             x16, [fp, #0x20]
    // 0x51e748: stp             x16, x0, [SP, #-0x10]!
    // 0x51e74c: ldr             x16, [fp, #0x18]
    // 0x51e750: ldur            lr, [fp, #-0x60]
    // 0x51e754: stp             lr, x16, [SP, #-0x10]!
    // 0x51e758: ldur            x16, [fp, #-0x58]
    // 0x51e75c: ldur            lr, [fp, #-0x50]
    // 0x51e760: stp             lr, x16, [SP, #-0x10]!
    // 0x51e764: ldur            x16, [fp, #-8]
    // 0x51e768: ldur            lr, [fp, #-0x48]
    // 0x51e76c: stp             lr, x16, [SP, #-0x10]!
    // 0x51e770: ldur            x16, [fp, #-0x68]
    // 0x51e774: ldur            lr, [fp, #-0x10]
    // 0x51e778: stp             lr, x16, [SP, #-0x10]!
    // 0x51e77c: ldr             x16, [fp, #0x30]
    // 0x51e780: ldr             lr, [fp, #0x40]
    // 0x51e784: stp             lr, x16, [SP, #-0x10]!
    // 0x51e788: ldr             x16, [fp, #0x38]
    // 0x51e78c: SaveReg r16
    //     0x51e78c: str             x16, [SP, #-8]!
    // 0x51e790: r4 = const [0, 0xd, 0xd, 0x3, ellipsis, 0xb, fontFamily, 0x5, fontSize, 0x6, fontStyle, 0x4, fontWeight, 0x3, height, 0x7, locale, 0xc, maxLines, 0xa, strutStyle, 0x9, textHeightBehavior, 0x8, null]
    //     0x51e790: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f530] List(25) [0, 0xd, 0xd, 0x3, "ellipsis", 0xb, "fontFamily", 0x5, "fontSize", 0x6, "fontStyle", 0x4, "fontWeight", 0x3, "height", 0x7, "locale", 0xc, "maxLines", 0xa, "strutStyle", 0x9, "textHeightBehavior", 0x8, Null]
    //     0x51e794: ldr             x4, [x4, #0x530]
    // 0x51e798: r0 = ParagraphStyle()
    //     0x51e798: bl              #0x51dd88  ; [dart:ui] ParagraphStyle::ParagraphStyle
    // 0x51e79c: add             SP, SP, #0x68
    // 0x51e7a0: ldur            x0, [fp, #-0x18]
    // 0x51e7a4: LeaveFrame
    //     0x51e7a4: mov             SP, fp
    //     0x51e7a8: ldp             fp, lr, [SP], #0x10
    // 0x51e7ac: ret
    //     0x51e7ac: ret             
    // 0x51e7b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51e7b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51e7b4: b               #0x51e568
    // 0x51e7b8: stp             q2, q3, [SP, #-0x20]!
    // 0x51e7bc: stp             x6, x7, [SP, #-0x10]!
    // 0x51e7c0: stp             x4, x5, [SP, #-0x10]!
    // 0x51e7c4: stp             x2, x3, [SP, #-0x10]!
    // 0x51e7c8: stp             x0, x1, [SP, #-0x10]!
    // 0x51e7cc: r0 = AllocateDouble()
    //     0x51e7cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x51e7d0: mov             x8, x0
    // 0x51e7d4: ldp             x0, x1, [SP], #0x10
    // 0x51e7d8: ldp             x2, x3, [SP], #0x10
    // 0x51e7dc: ldp             x4, x5, [SP], #0x10
    // 0x51e7e0: ldp             x6, x7, [SP], #0x10
    // 0x51e7e4: ldp             q2, q3, [SP], #0x20
    // 0x51e7e8: b               #0x51e67c
    // 0x51e7ec: SaveReg d0
    //     0x51e7ec: str             q0, [SP, #-0x10]!
    // 0x51e7f0: SaveReg r0
    //     0x51e7f0: str             x0, [SP, #-8]!
    // 0x51e7f4: r0 = AllocateDouble()
    //     0x51e7f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x51e7f8: mov             x1, x0
    // 0x51e7fc: RestoreReg r0
    //     0x51e7fc: ldr             x0, [SP], #8
    // 0x51e800: RestoreReg d0
    //     0x51e800: ldr             q0, [SP], #0x10
    // 0x51e804: b               #0x51e734
  }
  _ merge(/* No info */) {
    // ** addr: 0x6cdfe0, size: 0x16c
    // 0x6cdfe0: EnterFrame
    //     0x6cdfe0: stp             fp, lr, [SP, #-0x10]!
    //     0x6cdfe4: mov             fp, SP
    // 0x6cdfe8: AllocStack(0x18)
    //     0x6cdfe8: sub             SP, SP, #0x18
    // 0x6cdfec: CheckStackOverflow
    //     0x6cdfec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cdff0: cmp             SP, x16
    //     0x6cdff4: b.ls            #0x6ce144
    // 0x6cdff8: ldr             x0, [fp, #0x10]
    // 0x6cdffc: cmp             w0, NULL
    // 0x6ce000: b.ne            #0x6ce014
    // 0x6ce004: ldr             x0, [fp, #0x18]
    // 0x6ce008: LeaveFrame
    //     0x6ce008: mov             SP, fp
    //     0x6ce00c: ldp             fp, lr, [SP], #0x10
    // 0x6ce010: ret
    //     0x6ce010: ret             
    // 0x6ce014: LoadField: r1 = r0->field_7
    //     0x6ce014: ldur            w1, [x0, #7]
    // 0x6ce018: DecompressPointer r1
    //     0x6ce018: add             x1, x1, HEAP, lsl #32
    // 0x6ce01c: tbz             w1, #4, #0x6ce02c
    // 0x6ce020: LeaveFrame
    //     0x6ce020: mov             SP, fp
    //     0x6ce024: ldp             fp, lr, [SP], #0x10
    // 0x6ce028: ret
    //     0x6ce028: ret             
    // 0x6ce02c: LoadField: r1 = r0->field_b
    //     0x6ce02c: ldur            w1, [x0, #0xb]
    // 0x6ce030: DecompressPointer r1
    //     0x6ce030: add             x1, x1, HEAP, lsl #32
    // 0x6ce034: LoadField: r2 = r0->field_f
    //     0x6ce034: ldur            w2, [x0, #0xf]
    // 0x6ce038: DecompressPointer r2
    //     0x6ce038: add             x2, x2, HEAP, lsl #32
    // 0x6ce03c: LoadField: r3 = r0->field_1f
    //     0x6ce03c: ldur            w3, [x0, #0x1f]
    // 0x6ce040: DecompressPointer r3
    //     0x6ce040: add             x3, x3, HEAP, lsl #32
    // 0x6ce044: LoadField: r4 = r0->field_23
    //     0x6ce044: ldur            w4, [x0, #0x23]
    // 0x6ce048: DecompressPointer r4
    //     0x6ce048: add             x4, x4, HEAP, lsl #32
    // 0x6ce04c: LoadField: r5 = r0->field_27
    //     0x6ce04c: ldur            w5, [x0, #0x27]
    // 0x6ce050: DecompressPointer r5
    //     0x6ce050: add             x5, x5, HEAP, lsl #32
    // 0x6ce054: LoadField: r6 = r0->field_2b
    //     0x6ce054: ldur            w6, [x0, #0x2b]
    // 0x6ce058: DecompressPointer r6
    //     0x6ce058: add             x6, x6, HEAP, lsl #32
    // 0x6ce05c: LoadField: r7 = r0->field_2f
    //     0x6ce05c: ldur            w7, [x0, #0x2f]
    // 0x6ce060: DecompressPointer r7
    //     0x6ce060: add             x7, x7, HEAP, lsl #32
    // 0x6ce064: LoadField: r8 = r0->field_33
    //     0x6ce064: ldur            w8, [x0, #0x33]
    // 0x6ce068: DecompressPointer r8
    //     0x6ce068: add             x8, x8, HEAP, lsl #32
    // 0x6ce06c: LoadField: r9 = r0->field_37
    //     0x6ce06c: ldur            w9, [x0, #0x37]
    // 0x6ce070: DecompressPointer r9
    //     0x6ce070: add             x9, x9, HEAP, lsl #32
    // 0x6ce074: LoadField: r10 = r0->field_3b
    //     0x6ce074: ldur            w10, [x0, #0x3b]
    // 0x6ce078: DecompressPointer r10
    //     0x6ce078: add             x10, x10, HEAP, lsl #32
    // 0x6ce07c: LoadField: r11 = r0->field_43
    //     0x6ce07c: ldur            w11, [x0, #0x43]
    // 0x6ce080: DecompressPointer r11
    //     0x6ce080: add             x11, x11, HEAP, lsl #32
    // 0x6ce084: LoadField: r12 = r0->field_47
    //     0x6ce084: ldur            w12, [x0, #0x47]
    // 0x6ce088: DecompressPointer r12
    //     0x6ce088: add             x12, x12, HEAP, lsl #32
    // 0x6ce08c: LoadField: r13 = r0->field_5f
    //     0x6ce08c: ldur            w13, [x0, #0x5f]
    // 0x6ce090: DecompressPointer r13
    //     0x6ce090: add             x13, x13, HEAP, lsl #32
    // 0x6ce094: LoadField: r14 = r0->field_63
    //     0x6ce094: ldur            w14, [x0, #0x63]
    // 0x6ce098: DecompressPointer r14
    //     0x6ce098: add             x14, x14, HEAP, lsl #32
    // 0x6ce09c: LoadField: r19 = r0->field_67
    //     0x6ce09c: ldur            w19, [x0, #0x67]
    // 0x6ce0a0: DecompressPointer r19
    //     0x6ce0a0: add             x19, x19, HEAP, lsl #32
    // 0x6ce0a4: LoadField: r20 = r0->field_4b
    //     0x6ce0a4: ldur            w20, [x0, #0x4b]
    // 0x6ce0a8: DecompressPointer r20
    //     0x6ce0a8: add             x20, x20, HEAP, lsl #32
    // 0x6ce0ac: LoadField: r23 = r0->field_4f
    //     0x6ce0ac: ldur            w23, [x0, #0x4f]
    // 0x6ce0b0: DecompressPointer r23
    //     0x6ce0b0: add             x23, x23, HEAP, lsl #32
    // 0x6ce0b4: LoadField: r24 = r0->field_53
    //     0x6ce0b4: ldur            w24, [x0, #0x53]
    // 0x6ce0b8: DecompressPointer r24
    //     0x6ce0b8: add             x24, x24, HEAP, lsl #32
    // 0x6ce0bc: LoadField: r25 = r0->field_57
    //     0x6ce0bc: ldur            w25, [x0, #0x57]
    // 0x6ce0c0: DecompressPointer r25
    //     0x6ce0c0: add             x25, x25, HEAP, lsl #32
    // 0x6ce0c4: stur            x25, [fp, #-8]
    // 0x6ce0c8: LoadField: r25 = r0->field_13
    //     0x6ce0c8: ldur            w25, [x0, #0x13]
    // 0x6ce0cc: DecompressPointer r25
    //     0x6ce0cc: add             x25, x25, HEAP, lsl #32
    // 0x6ce0d0: stur            x25, [fp, #-0x10]
    // 0x6ce0d4: LoadField: r25 = r0->field_17
    //     0x6ce0d4: ldur            w25, [x0, #0x17]
    // 0x6ce0d8: DecompressPointer r25
    //     0x6ce0d8: add             x25, x25, HEAP, lsl #32
    // 0x6ce0dc: stur            x25, [fp, #-0x18]
    // 0x6ce0e0: LoadField: r25 = r0->field_6b
    //     0x6ce0e0: ldur            w25, [x0, #0x6b]
    // 0x6ce0e4: DecompressPointer r25
    //     0x6ce0e4: add             x25, x25, HEAP, lsl #32
    // 0x6ce0e8: ldr             x16, [fp, #0x18]
    // 0x6ce0ec: stp             x1, x16, [SP, #-0x10]!
    // 0x6ce0f0: stp             x3, x2, [SP, #-0x10]!
    // 0x6ce0f4: stp             x5, x4, [SP, #-0x10]!
    // 0x6ce0f8: stp             x7, x6, [SP, #-0x10]!
    // 0x6ce0fc: stp             x9, x8, [SP, #-0x10]!
    // 0x6ce100: stp             x11, x10, [SP, #-0x10]!
    // 0x6ce104: stp             x13, x12, [SP, #-0x10]!
    // 0x6ce108: stp             x19, x14, [SP, #-0x10]!
    // 0x6ce10c: stp             x23, x20, [SP, #-0x10]!
    // 0x6ce110: ldur            x16, [fp, #-8]
    // 0x6ce114: stp             x16, x24, [SP, #-0x10]!
    // 0x6ce118: ldur            x16, [fp, #-0x10]
    // 0x6ce11c: ldur            lr, [fp, #-0x18]
    // 0x6ce120: stp             lr, x16, [SP, #-0x10]!
    // 0x6ce124: SaveReg r25
    //     0x6ce124: str             x25, [SP, #-8]!
    // 0x6ce128: r4 = const [0, 0x17, 0x17, 0x1, background, 0xc, backgroundColor, 0x2, color, 0x1, decoration, 0x10, decorationColor, 0x11, decorationStyle, 0x12, decorationThickness, 0x13, fontFamily, 0x14, fontFamilyFallback, 0x15, fontFeatures, 0xe, fontSize, 0x3, fontStyle, 0x5, fontVariations, 0xf, fontWeight, 0x4, foreground, 0xb, height, 0x9, leadingDistribution, 0xa, letterSpacing, 0x6, overflow, 0x16, shadows, 0xd, textBaseline, 0x8, wordSpacing, 0x7, null]
    //     0x6ce128: add             x4, PP, #0xd, lsl #12  ; [pp+0xdfd0] List(49) [0, 0x17, 0x17, 0x1, "background", 0xc, "backgroundColor", 0x2, "color", 0x1, "decoration", 0x10, "decorationColor", 0x11, "decorationStyle", 0x12, "decorationThickness", 0x13, "fontFamily", 0x14, "fontFamilyFallback", 0x15, "fontFeatures", 0xe, "fontSize", 0x3, "fontStyle", 0x5, "fontVariations", 0xf, "fontWeight", 0x4, "foreground", 0xb, "height", 0x9, "leadingDistribution", 0xa, "letterSpacing", 0x6, "overflow", 0x16, "shadows", 0xd, "textBaseline", 0x8, "wordSpacing", 0x7, Null]
    //     0x6ce12c: ldr             x4, [x4, #0xfd0]
    // 0x6ce130: r0 = copyWith()
    //     0x6ce130: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x6ce134: add             SP, SP, #0xb8
    // 0x6ce138: LeaveFrame
    //     0x6ce138: mov             SP, fp
    //     0x6ce13c: ldp             fp, lr, [SP], #0x10
    // 0x6ce140: ret
    //     0x6ce140: ret             
    // 0x6ce144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ce144: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ce148: b               #0x6cdff8
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x6ce14c, size: 0xba0
    // 0x6ce14c: EnterFrame
    //     0x6ce14c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ce150: mov             fp, SP
    // 0x6ce154: AllocStack(0xc0)
    //     0x6ce154: sub             SP, SP, #0xc0
    // 0x6ce158: SetupParameters(TextStyle this /* r3 */, {dynamic background = Null /* r4 */, dynamic backgroundColor = Null /* r5 */, dynamic color = Null /* r6 */, dynamic decoration = Null /* fp-0x30 */, dynamic decorationColor = Null /* fp-0x28 */, dynamic decorationStyle = Null /* fp-0x20 */, dynamic decorationThickness = Null /* fp-0x18 */, dynamic fontFamily = Null /* fp-0x10 */, dynamic fontFamilyFallback = Null /* fp-0x8 */, dynamic fontFeatures = Null /* fp-0x48 */, dynamic fontSize = Null /* r14 */, dynamic fontStyle = Null /* r19 */, dynamic fontVariations = Null /* fp-0x38 */, dynamic fontWeight = Null /* r12 */, dynamic foreground = Null /* r11 */, dynamic height = Null /* r10 */, dynamic inherit = Null /* r9 */, dynamic leadingDistribution = Null /* r8 */, dynamic letterSpacing = Null /* r7 */, dynamic overflow = Null /* fp-0x40 */, dynamic shadows = Null /* r20 */, dynamic textBaseline = Null /* r13 */, dynamic wordSpacing = Null /* r0 */})
    //     0x6ce158: mov             x0, x4
    //     0x6ce15c: ldur            w1, [x0, #0x13]
    //     0x6ce160: add             x1, x1, HEAP, lsl #32
    //     0x6ce164: sub             x2, x1, #2
    //     0x6ce168: add             x3, fp, w2, sxtw #2
    //     0x6ce16c: ldr             x3, [x3, #0x10]
    //     0x6ce170: ldur            w2, [x0, #0x1f]
    //     0x6ce174: add             x2, x2, HEAP, lsl #32
    //     0x6ce178: add             x16, PP, #0xd, lsl #12  ; [pp+0xdfd8] "background"
    //     0x6ce17c: ldr             x16, [x16, #0xfd8]
    //     0x6ce180: cmp             w2, w16
    //     0x6ce184: b.ne            #0x6ce1a8
    //     0x6ce188: ldur            w2, [x0, #0x23]
    //     0x6ce18c: add             x2, x2, HEAP, lsl #32
    //     0x6ce190: sub             w4, w1, w2
    //     0x6ce194: add             x2, fp, w4, sxtw #2
    //     0x6ce198: ldr             x2, [x2, #8]
    //     0x6ce19c: mov             x4, x2
    //     0x6ce1a0: mov             x2, #1
    //     0x6ce1a4: b               #0x6ce1b0
    //     0x6ce1a8: mov             x4, NULL
    //     0x6ce1ac: mov             x2, #0
    //     0x6ce1b0: lsl             x5, x2, #1
    //     0x6ce1b4: lsl             w6, w5, #1
    //     0x6ce1b8: add             w7, w6, #8
    //     0x6ce1bc: add             x16, x0, w7, sxtw #1
    //     0x6ce1c0: ldur            w8, [x16, #0xf]
    //     0x6ce1c4: add             x8, x8, HEAP, lsl #32
    //     0x6ce1c8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc48] "backgroundColor"
    //     0x6ce1cc: ldr             x16, [x16, #0xc48]
    //     0x6ce1d0: cmp             w8, w16
    //     0x6ce1d4: b.ne            #0x6ce208
    //     0x6ce1d8: add             w2, w6, #0xa
    //     0x6ce1dc: add             x16, x0, w2, sxtw #1
    //     0x6ce1e0: ldur            w6, [x16, #0xf]
    //     0x6ce1e4: add             x6, x6, HEAP, lsl #32
    //     0x6ce1e8: sub             w2, w1, w6
    //     0x6ce1ec: add             x6, fp, w2, sxtw #2
    //     0x6ce1f0: ldr             x6, [x6, #8]
    //     0x6ce1f4: add             w2, w5, #2
    //     0x6ce1f8: sbfx            x5, x2, #1, #0x1f
    //     0x6ce1fc: mov             x2, x5
    //     0x6ce200: mov             x5, x6
    //     0x6ce204: b               #0x6ce20c
    //     0x6ce208: mov             x5, NULL
    //     0x6ce20c: lsl             x6, x2, #1
    //     0x6ce210: lsl             w7, w6, #1
    //     0x6ce214: add             w8, w7, #8
    //     0x6ce218: add             x16, x0, w8, sxtw #1
    //     0x6ce21c: ldur            w9, [x16, #0xf]
    //     0x6ce220: add             x9, x9, HEAP, lsl #32
    //     0x6ce224: add             x16, PP, #0xd, lsl #12  ; [pp+0xdae8] "color"
    //     0x6ce228: ldr             x16, [x16, #0xae8]
    //     0x6ce22c: cmp             w9, w16
    //     0x6ce230: b.ne            #0x6ce264
    //     0x6ce234: add             w2, w7, #0xa
    //     0x6ce238: add             x16, x0, w2, sxtw #1
    //     0x6ce23c: ldur            w7, [x16, #0xf]
    //     0x6ce240: add             x7, x7, HEAP, lsl #32
    //     0x6ce244: sub             w2, w1, w7
    //     0x6ce248: add             x7, fp, w2, sxtw #2
    //     0x6ce24c: ldr             x7, [x7, #8]
    //     0x6ce250: add             w2, w6, #2
    //     0x6ce254: sbfx            x6, x2, #1, #0x1f
    //     0x6ce258: mov             x2, x6
    //     0x6ce25c: mov             x6, x7
    //     0x6ce260: b               #0x6ce268
    //     0x6ce264: mov             x6, NULL
    //     0x6ce268: lsl             x7, x2, #1
    //     0x6ce26c: lsl             w8, w7, #1
    //     0x6ce270: add             w9, w8, #8
    //     0x6ce274: add             x16, x0, w9, sxtw #1
    //     0x6ce278: ldur            w10, [x16, #0xf]
    //     0x6ce27c: add             x10, x10, HEAP, lsl #32
    //     0x6ce280: add             x16, PP, #0xd, lsl #12  ; [pp+0xdaf8] "decoration"
    //     0x6ce284: ldr             x16, [x16, #0xaf8]
    //     0x6ce288: cmp             w10, w16
    //     0x6ce28c: b.ne            #0x6ce2c0
    //     0x6ce290: add             w2, w8, #0xa
    //     0x6ce294: add             x16, x0, w2, sxtw #1
    //     0x6ce298: ldur            w8, [x16, #0xf]
    //     0x6ce29c: add             x8, x8, HEAP, lsl #32
    //     0x6ce2a0: sub             w2, w1, w8
    //     0x6ce2a4: add             x8, fp, w2, sxtw #2
    //     0x6ce2a8: ldr             x8, [x8, #8]
    //     0x6ce2ac: add             w2, w7, #2
    //     0x6ce2b0: sbfx            x7, x2, #1, #0x1f
    //     0x6ce2b4: mov             x2, x7
    //     0x6ce2b8: mov             x7, x8
    //     0x6ce2bc: b               #0x6ce2c4
    //     0x6ce2c0: mov             x7, NULL
    //     0x6ce2c4: stur            x7, [fp, #-0x30]
    //     0x6ce2c8: lsl             x8, x2, #1
    //     0x6ce2cc: lsl             w9, w8, #1
    //     0x6ce2d0: add             w10, w9, #8
    //     0x6ce2d4: add             x16, x0, w10, sxtw #1
    //     0x6ce2d8: ldur            w11, [x16, #0xf]
    //     0x6ce2dc: add             x11, x11, HEAP, lsl #32
    //     0x6ce2e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdfe0] "decorationColor"
    //     0x6ce2e4: ldr             x16, [x16, #0xfe0]
    //     0x6ce2e8: cmp             w11, w16
    //     0x6ce2ec: b.ne            #0x6ce320
    //     0x6ce2f0: add             w2, w9, #0xa
    //     0x6ce2f4: add             x16, x0, w2, sxtw #1
    //     0x6ce2f8: ldur            w9, [x16, #0xf]
    //     0x6ce2fc: add             x9, x9, HEAP, lsl #32
    //     0x6ce300: sub             w2, w1, w9
    //     0x6ce304: add             x9, fp, w2, sxtw #2
    //     0x6ce308: ldr             x9, [x9, #8]
    //     0x6ce30c: add             w2, w8, #2
    //     0x6ce310: sbfx            x8, x2, #1, #0x1f
    //     0x6ce314: mov             x2, x8
    //     0x6ce318: mov             x8, x9
    //     0x6ce31c: b               #0x6ce324
    //     0x6ce320: mov             x8, NULL
    //     0x6ce324: stur            x8, [fp, #-0x28]
    //     0x6ce328: lsl             x9, x2, #1
    //     0x6ce32c: lsl             w10, w9, #1
    //     0x6ce330: add             w11, w10, #8
    //     0x6ce334: add             x16, x0, w11, sxtw #1
    //     0x6ce338: ldur            w12, [x16, #0xf]
    //     0x6ce33c: add             x12, x12, HEAP, lsl #32
    //     0x6ce340: add             x16, PP, #0xd, lsl #12  ; [pp+0xdfe8] "decorationStyle"
    //     0x6ce344: ldr             x16, [x16, #0xfe8]
    //     0x6ce348: cmp             w12, w16
    //     0x6ce34c: b.ne            #0x6ce380
    //     0x6ce350: add             w2, w10, #0xa
    //     0x6ce354: add             x16, x0, w2, sxtw #1
    //     0x6ce358: ldur            w10, [x16, #0xf]
    //     0x6ce35c: add             x10, x10, HEAP, lsl #32
    //     0x6ce360: sub             w2, w1, w10
    //     0x6ce364: add             x10, fp, w2, sxtw #2
    //     0x6ce368: ldr             x10, [x10, #8]
    //     0x6ce36c: add             w2, w9, #2
    //     0x6ce370: sbfx            x9, x2, #1, #0x1f
    //     0x6ce374: mov             x2, x9
    //     0x6ce378: mov             x9, x10
    //     0x6ce37c: b               #0x6ce384
    //     0x6ce380: mov             x9, NULL
    //     0x6ce384: stur            x9, [fp, #-0x20]
    //     0x6ce388: lsl             x10, x2, #1
    //     0x6ce38c: lsl             w11, w10, #1
    //     0x6ce390: add             w12, w11, #8
    //     0x6ce394: add             x16, x0, w12, sxtw #1
    //     0x6ce398: ldur            w13, [x16, #0xf]
    //     0x6ce39c: add             x13, x13, HEAP, lsl #32
    //     0x6ce3a0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdff0] "decorationThickness"
    //     0x6ce3a4: ldr             x16, [x16, #0xff0]
    //     0x6ce3a8: cmp             w13, w16
    //     0x6ce3ac: b.ne            #0x6ce3e0
    //     0x6ce3b0: add             w2, w11, #0xa
    //     0x6ce3b4: add             x16, x0, w2, sxtw #1
    //     0x6ce3b8: ldur            w11, [x16, #0xf]
    //     0x6ce3bc: add             x11, x11, HEAP, lsl #32
    //     0x6ce3c0: sub             w2, w1, w11
    //     0x6ce3c4: add             x11, fp, w2, sxtw #2
    //     0x6ce3c8: ldr             x11, [x11, #8]
    //     0x6ce3cc: add             w2, w10, #2
    //     0x6ce3d0: sbfx            x10, x2, #1, #0x1f
    //     0x6ce3d4: mov             x2, x10
    //     0x6ce3d8: mov             x10, x11
    //     0x6ce3dc: b               #0x6ce3e4
    //     0x6ce3e0: mov             x10, NULL
    //     0x6ce3e4: stur            x10, [fp, #-0x18]
    //     0x6ce3e8: lsl             x11, x2, #1
    //     0x6ce3ec: lsl             w12, w11, #1
    //     0x6ce3f0: add             w13, w12, #8
    //     0x6ce3f4: add             x16, x0, w13, sxtw #1
    //     0x6ce3f8: ldur            w14, [x16, #0xf]
    //     0x6ce3fc: add             x14, x14, HEAP, lsl #32
    //     0x6ce400: add             x16, PP, #0xd, lsl #12  ; [pp+0xdff8] "fontFamily"
    //     0x6ce404: ldr             x16, [x16, #0xff8]
    //     0x6ce408: cmp             w14, w16
    //     0x6ce40c: b.ne            #0x6ce440
    //     0x6ce410: add             w2, w12, #0xa
    //     0x6ce414: add             x16, x0, w2, sxtw #1
    //     0x6ce418: ldur            w12, [x16, #0xf]
    //     0x6ce41c: add             x12, x12, HEAP, lsl #32
    //     0x6ce420: sub             w2, w1, w12
    //     0x6ce424: add             x12, fp, w2, sxtw #2
    //     0x6ce428: ldr             x12, [x12, #8]
    //     0x6ce42c: add             w2, w11, #2
    //     0x6ce430: sbfx            x11, x2, #1, #0x1f
    //     0x6ce434: mov             x2, x11
    //     0x6ce438: mov             x11, x12
    //     0x6ce43c: b               #0x6ce444
    //     0x6ce440: mov             x11, NULL
    //     0x6ce444: stur            x11, [fp, #-0x10]
    //     0x6ce448: lsl             x12, x2, #1
    //     0x6ce44c: lsl             w13, w12, #1
    //     0x6ce450: add             w14, w13, #8
    //     0x6ce454: add             x16, x0, w14, sxtw #1
    //     0x6ce458: ldur            w19, [x16, #0xf]
    //     0x6ce45c: add             x19, x19, HEAP, lsl #32
    //     0x6ce460: add             x16, PP, #0xe, lsl #12  ; [pp+0xe000] "fontFamilyFallback"
    //     0x6ce464: ldr             x16, [x16]
    //     0x6ce468: cmp             w19, w16
    //     0x6ce46c: b.ne            #0x6ce4a0
    //     0x6ce470: add             w2, w13, #0xa
    //     0x6ce474: add             x16, x0, w2, sxtw #1
    //     0x6ce478: ldur            w13, [x16, #0xf]
    //     0x6ce47c: add             x13, x13, HEAP, lsl #32
    //     0x6ce480: sub             w2, w1, w13
    //     0x6ce484: add             x13, fp, w2, sxtw #2
    //     0x6ce488: ldr             x13, [x13, #8]
    //     0x6ce48c: add             w2, w12, #2
    //     0x6ce490: sbfx            x12, x2, #1, #0x1f
    //     0x6ce494: mov             x2, x12
    //     0x6ce498: mov             x12, x13
    //     0x6ce49c: b               #0x6ce4a4
    //     0x6ce4a0: mov             x12, NULL
    //     0x6ce4a4: stur            x12, [fp, #-8]
    //     0x6ce4a8: lsl             x13, x2, #1
    //     0x6ce4ac: lsl             w14, w13, #1
    //     0x6ce4b0: add             w19, w14, #8
    //     0x6ce4b4: add             x16, x0, w19, sxtw #1
    //     0x6ce4b8: ldur            w20, [x16, #0xf]
    //     0x6ce4bc: add             x20, x20, HEAP, lsl #32
    //     0x6ce4c0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe008] "fontFeatures"
    //     0x6ce4c4: ldr             x16, [x16, #8]
    //     0x6ce4c8: cmp             w20, w16
    //     0x6ce4cc: b.ne            #0x6ce500
    //     0x6ce4d0: add             w2, w14, #0xa
    //     0x6ce4d4: add             x16, x0, w2, sxtw #1
    //     0x6ce4d8: ldur            w14, [x16, #0xf]
    //     0x6ce4dc: add             x14, x14, HEAP, lsl #32
    //     0x6ce4e0: sub             w2, w1, w14
    //     0x6ce4e4: add             x14, fp, w2, sxtw #2
    //     0x6ce4e8: ldr             x14, [x14, #8]
    //     0x6ce4ec: add             w2, w13, #2
    //     0x6ce4f0: sbfx            x13, x2, #1, #0x1f
    //     0x6ce4f4: mov             x2, x13
    //     0x6ce4f8: mov             x13, x14
    //     0x6ce4fc: b               #0x6ce504
    //     0x6ce500: mov             x13, NULL
    //     0x6ce504: stur            x13, [fp, #-0x48]
    //     0x6ce508: lsl             x14, x2, #1
    //     0x6ce50c: lsl             w19, w14, #1
    //     0x6ce510: add             w20, w19, #8
    //     0x6ce514: add             x16, x0, w20, sxtw #1
    //     0x6ce518: ldur            w23, [x16, #0xf]
    //     0x6ce51c: add             x23, x23, HEAP, lsl #32
    //     0x6ce520: add             x16, PP, #0xe, lsl #12  ; [pp+0xe010] "fontSize"
    //     0x6ce524: ldr             x16, [x16, #0x10]
    //     0x6ce528: cmp             w23, w16
    //     0x6ce52c: b.ne            #0x6ce560
    //     0x6ce530: add             w2, w19, #0xa
    //     0x6ce534: add             x16, x0, w2, sxtw #1
    //     0x6ce538: ldur            w19, [x16, #0xf]
    //     0x6ce53c: add             x19, x19, HEAP, lsl #32
    //     0x6ce540: sub             w2, w1, w19
    //     0x6ce544: add             x19, fp, w2, sxtw #2
    //     0x6ce548: ldr             x19, [x19, #8]
    //     0x6ce54c: add             w2, w14, #2
    //     0x6ce550: sbfx            x14, x2, #1, #0x1f
    //     0x6ce554: mov             x2, x14
    //     0x6ce558: mov             x14, x19
    //     0x6ce55c: b               #0x6ce564
    //     0x6ce560: mov             x14, NULL
    //     0x6ce564: lsl             x19, x2, #1
    //     0x6ce568: lsl             w20, w19, #1
    //     0x6ce56c: add             w23, w20, #8
    //     0x6ce570: add             x16, x0, w23, sxtw #1
    //     0x6ce574: ldur            w24, [x16, #0xf]
    //     0x6ce578: add             x24, x24, HEAP, lsl #32
    //     0x6ce57c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe018] "fontStyle"
    //     0x6ce580: ldr             x16, [x16, #0x18]
    //     0x6ce584: cmp             w24, w16
    //     0x6ce588: b.ne            #0x6ce5bc
    //     0x6ce58c: add             w2, w20, #0xa
    //     0x6ce590: add             x16, x0, w2, sxtw #1
    //     0x6ce594: ldur            w20, [x16, #0xf]
    //     0x6ce598: add             x20, x20, HEAP, lsl #32
    //     0x6ce59c: sub             w2, w1, w20
    //     0x6ce5a0: add             x20, fp, w2, sxtw #2
    //     0x6ce5a4: ldr             x20, [x20, #8]
    //     0x6ce5a8: add             w2, w19, #2
    //     0x6ce5ac: sbfx            x19, x2, #1, #0x1f
    //     0x6ce5b0: mov             x2, x19
    //     0x6ce5b4: mov             x19, x20
    //     0x6ce5b8: b               #0x6ce5c0
    //     0x6ce5bc: mov             x19, NULL
    //     0x6ce5c0: lsl             x20, x2, #1
    //     0x6ce5c4: lsl             w23, w20, #1
    //     0x6ce5c8: add             w24, w23, #8
    //     0x6ce5cc: add             x16, x0, w24, sxtw #1
    //     0x6ce5d0: ldur            w25, [x16, #0xf]
    //     0x6ce5d4: add             x25, x25, HEAP, lsl #32
    //     0x6ce5d8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe020] "fontVariations"
    //     0x6ce5dc: ldr             x16, [x16, #0x20]
    //     0x6ce5e0: cmp             w25, w16
    //     0x6ce5e4: b.ne            #0x6ce618
    //     0x6ce5e8: add             w2, w23, #0xa
    //     0x6ce5ec: add             x16, x0, w2, sxtw #1
    //     0x6ce5f0: ldur            w23, [x16, #0xf]
    //     0x6ce5f4: add             x23, x23, HEAP, lsl #32
    //     0x6ce5f8: sub             w2, w1, w23
    //     0x6ce5fc: add             x23, fp, w2, sxtw #2
    //     0x6ce600: ldr             x23, [x23, #8]
    //     0x6ce604: add             w2, w20, #2
    //     0x6ce608: sbfx            x20, x2, #1, #0x1f
    //     0x6ce60c: mov             x2, x20
    //     0x6ce610: mov             x20, x23
    //     0x6ce614: b               #0x6ce61c
    //     0x6ce618: mov             x20, NULL
    //     0x6ce61c: stur            x20, [fp, #-0x38]
    //     0x6ce620: lsl             x23, x2, #1
    //     0x6ce624: lsl             w24, w23, #1
    //     0x6ce628: add             w25, w24, #8
    //     0x6ce62c: add             x16, x0, w25, sxtw #1
    //     0x6ce630: ldur            w12, [x16, #0xf]
    //     0x6ce634: add             x12, x12, HEAP, lsl #32
    //     0x6ce638: add             x16, PP, #0xe, lsl #12  ; [pp+0xe028] "fontWeight"
    //     0x6ce63c: ldr             x16, [x16, #0x28]
    //     0x6ce640: cmp             w12, w16
    //     0x6ce644: b.ne            #0x6ce674
    //     0x6ce648: add             w2, w24, #0xa
    //     0x6ce64c: add             x16, x0, w2, sxtw #1
    //     0x6ce650: ldur            w12, [x16, #0xf]
    //     0x6ce654: add             x12, x12, HEAP, lsl #32
    //     0x6ce658: sub             w2, w1, w12
    //     0x6ce65c: add             x12, fp, w2, sxtw #2
    //     0x6ce660: ldr             x12, [x12, #8]
    //     0x6ce664: add             w2, w23, #2
    //     0x6ce668: sbfx            x23, x2, #1, #0x1f
    //     0x6ce66c: mov             x2, x23
    //     0x6ce670: b               #0x6ce678
    //     0x6ce674: mov             x12, NULL
    //     0x6ce678: lsl             x23, x2, #1
    //     0x6ce67c: lsl             w24, w23, #1
    //     0x6ce680: add             w25, w24, #8
    //     0x6ce684: add             x16, x0, w25, sxtw #1
    //     0x6ce688: ldur            w11, [x16, #0xf]
    //     0x6ce68c: add             x11, x11, HEAP, lsl #32
    //     0x6ce690: add             x16, PP, #0xe, lsl #12  ; [pp+0xe030] "foreground"
    //     0x6ce694: ldr             x16, [x16, #0x30]
    //     0x6ce698: cmp             w11, w16
    //     0x6ce69c: b.ne            #0x6ce6cc
    //     0x6ce6a0: add             w2, w24, #0xa
    //     0x6ce6a4: add             x16, x0, w2, sxtw #1
    //     0x6ce6a8: ldur            w11, [x16, #0xf]
    //     0x6ce6ac: add             x11, x11, HEAP, lsl #32
    //     0x6ce6b0: sub             w2, w1, w11
    //     0x6ce6b4: add             x11, fp, w2, sxtw #2
    //     0x6ce6b8: ldr             x11, [x11, #8]
    //     0x6ce6bc: add             w2, w23, #2
    //     0x6ce6c0: sbfx            x23, x2, #1, #0x1f
    //     0x6ce6c4: mov             x2, x23
    //     0x6ce6c8: b               #0x6ce6d0
    //     0x6ce6cc: mov             x11, NULL
    //     0x6ce6d0: lsl             x23, x2, #1
    //     0x6ce6d4: lsl             w24, w23, #1
    //     0x6ce6d8: add             w25, w24, #8
    //     0x6ce6dc: add             x16, x0, w25, sxtw #1
    //     0x6ce6e0: ldur            w10, [x16, #0xf]
    //     0x6ce6e4: add             x10, x10, HEAP, lsl #32
    //     0x6ce6e8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb08] "height"
    //     0x6ce6ec: ldr             x16, [x16, #0xb08]
    //     0x6ce6f0: cmp             w10, w16
    //     0x6ce6f4: b.ne            #0x6ce724
    //     0x6ce6f8: add             w2, w24, #0xa
    //     0x6ce6fc: add             x16, x0, w2, sxtw #1
    //     0x6ce700: ldur            w10, [x16, #0xf]
    //     0x6ce704: add             x10, x10, HEAP, lsl #32
    //     0x6ce708: sub             w2, w1, w10
    //     0x6ce70c: add             x10, fp, w2, sxtw #2
    //     0x6ce710: ldr             x10, [x10, #8]
    //     0x6ce714: add             w2, w23, #2
    //     0x6ce718: sbfx            x23, x2, #1, #0x1f
    //     0x6ce71c: mov             x2, x23
    //     0x6ce720: b               #0x6ce728
    //     0x6ce724: mov             x10, NULL
    //     0x6ce728: lsl             x23, x2, #1
    //     0x6ce72c: lsl             w24, w23, #1
    //     0x6ce730: add             w25, w24, #8
    //     0x6ce734: add             x16, x0, w25, sxtw #1
    //     0x6ce738: ldur            w9, [x16, #0xf]
    //     0x6ce73c: add             x9, x9, HEAP, lsl #32
    //     0x6ce740: add             x16, PP, #0xe, lsl #12  ; [pp+0xe038] "inherit"
    //     0x6ce744: ldr             x16, [x16, #0x38]
    //     0x6ce748: cmp             w9, w16
    //     0x6ce74c: b.ne            #0x6ce77c
    //     0x6ce750: add             w2, w24, #0xa
    //     0x6ce754: add             x16, x0, w2, sxtw #1
    //     0x6ce758: ldur            w9, [x16, #0xf]
    //     0x6ce75c: add             x9, x9, HEAP, lsl #32
    //     0x6ce760: sub             w2, w1, w9
    //     0x6ce764: add             x9, fp, w2, sxtw #2
    //     0x6ce768: ldr             x9, [x9, #8]
    //     0x6ce76c: add             w2, w23, #2
    //     0x6ce770: sbfx            x23, x2, #1, #0x1f
    //     0x6ce774: mov             x2, x23
    //     0x6ce778: b               #0x6ce780
    //     0x6ce77c: mov             x9, NULL
    //     0x6ce780: lsl             x23, x2, #1
    //     0x6ce784: lsl             w24, w23, #1
    //     0x6ce788: add             w25, w24, #8
    //     0x6ce78c: add             x16, x0, w25, sxtw #1
    //     0x6ce790: ldur            w8, [x16, #0xf]
    //     0x6ce794: add             x8, x8, HEAP, lsl #32
    //     0x6ce798: add             x16, PP, #0xe, lsl #12  ; [pp+0xe040] "leadingDistribution"
    //     0x6ce79c: ldr             x16, [x16, #0x40]
    //     0x6ce7a0: cmp             w8, w16
    //     0x6ce7a4: b.ne            #0x6ce7d4
    //     0x6ce7a8: add             w2, w24, #0xa
    //     0x6ce7ac: add             x16, x0, w2, sxtw #1
    //     0x6ce7b0: ldur            w8, [x16, #0xf]
    //     0x6ce7b4: add             x8, x8, HEAP, lsl #32
    //     0x6ce7b8: sub             w2, w1, w8
    //     0x6ce7bc: add             x8, fp, w2, sxtw #2
    //     0x6ce7c0: ldr             x8, [x8, #8]
    //     0x6ce7c4: add             w2, w23, #2
    //     0x6ce7c8: sbfx            x23, x2, #1, #0x1f
    //     0x6ce7cc: mov             x2, x23
    //     0x6ce7d0: b               #0x6ce7d8
    //     0x6ce7d4: mov             x8, NULL
    //     0x6ce7d8: lsl             x23, x2, #1
    //     0x6ce7dc: lsl             w24, w23, #1
    //     0x6ce7e0: add             w25, w24, #8
    //     0x6ce7e4: add             x16, x0, w25, sxtw #1
    //     0x6ce7e8: ldur            w7, [x16, #0xf]
    //     0x6ce7ec: add             x7, x7, HEAP, lsl #32
    //     0x6ce7f0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe048] "letterSpacing"
    //     0x6ce7f4: ldr             x16, [x16, #0x48]
    //     0x6ce7f8: cmp             w7, w16
    //     0x6ce7fc: b.ne            #0x6ce82c
    //     0x6ce800: add             w2, w24, #0xa
    //     0x6ce804: add             x16, x0, w2, sxtw #1
    //     0x6ce808: ldur            w7, [x16, #0xf]
    //     0x6ce80c: add             x7, x7, HEAP, lsl #32
    //     0x6ce810: sub             w2, w1, w7
    //     0x6ce814: add             x7, fp, w2, sxtw #2
    //     0x6ce818: ldr             x7, [x7, #8]
    //     0x6ce81c: add             w2, w23, #2
    //     0x6ce820: sbfx            x23, x2, #1, #0x1f
    //     0x6ce824: mov             x2, x23
    //     0x6ce828: b               #0x6ce830
    //     0x6ce82c: mov             x7, NULL
    //     0x6ce830: lsl             x23, x2, #1
    //     0x6ce834: lsl             w24, w23, #1
    //     0x6ce838: add             w25, w24, #8
    //     0x6ce83c: add             x16, x0, w25, sxtw #1
    //     0x6ce840: ldur            w20, [x16, #0xf]
    //     0x6ce844: add             x20, x20, HEAP, lsl #32
    //     0x6ce848: ldr             x16, [PP, #0x1fc0]  ; [pp+0x1fc0] "overflow"
    //     0x6ce84c: cmp             w20, w16
    //     0x6ce850: b.ne            #0x6ce880
    //     0x6ce854: add             w2, w24, #0xa
    //     0x6ce858: add             x16, x0, w2, sxtw #1
    //     0x6ce85c: ldur            w20, [x16, #0xf]
    //     0x6ce860: add             x20, x20, HEAP, lsl #32
    //     0x6ce864: sub             w2, w1, w20
    //     0x6ce868: add             x20, fp, w2, sxtw #2
    //     0x6ce86c: ldr             x20, [x20, #8]
    //     0x6ce870: add             w2, w23, #2
    //     0x6ce874: sbfx            x23, x2, #1, #0x1f
    //     0x6ce878: mov             x2, x23
    //     0x6ce87c: b               #0x6ce884
    //     0x6ce880: mov             x20, NULL
    //     0x6ce884: stur            x20, [fp, #-0x40]
    //     0x6ce888: lsl             x23, x2, #1
    //     0x6ce88c: lsl             w24, w23, #1
    //     0x6ce890: add             w25, w24, #8
    //     0x6ce894: add             x16, x0, w25, sxtw #1
    //     0x6ce898: ldur            w20, [x16, #0xf]
    //     0x6ce89c: add             x20, x20, HEAP, lsl #32
    //     0x6ce8a0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe050] "shadows"
    //     0x6ce8a4: ldr             x16, [x16, #0x50]
    //     0x6ce8a8: cmp             w20, w16
    //     0x6ce8ac: b.ne            #0x6ce8dc
    //     0x6ce8b0: add             w2, w24, #0xa
    //     0x6ce8b4: add             x16, x0, w2, sxtw #1
    //     0x6ce8b8: ldur            w20, [x16, #0xf]
    //     0x6ce8bc: add             x20, x20, HEAP, lsl #32
    //     0x6ce8c0: sub             w2, w1, w20
    //     0x6ce8c4: add             x20, fp, w2, sxtw #2
    //     0x6ce8c8: ldr             x20, [x20, #8]
    //     0x6ce8cc: add             w2, w23, #2
    //     0x6ce8d0: sbfx            x23, x2, #1, #0x1f
    //     0x6ce8d4: mov             x2, x23
    //     0x6ce8d8: b               #0x6ce8e0
    //     0x6ce8dc: mov             x20, NULL
    //     0x6ce8e0: lsl             x23, x2, #1
    //     0x6ce8e4: lsl             w24, w23, #1
    //     0x6ce8e8: add             w25, w24, #8
    //     0x6ce8ec: add             x16, x0, w25, sxtw #1
    //     0x6ce8f0: ldur            w13, [x16, #0xf]
    //     0x6ce8f4: add             x13, x13, HEAP, lsl #32
    //     0x6ce8f8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe058] "textBaseline"
    //     0x6ce8fc: ldr             x16, [x16, #0x58]
    //     0x6ce900: cmp             w13, w16
    //     0x6ce904: b.ne            #0x6ce934
    //     0x6ce908: add             w2, w24, #0xa
    //     0x6ce90c: add             x16, x0, w2, sxtw #1
    //     0x6ce910: ldur            w13, [x16, #0xf]
    //     0x6ce914: add             x13, x13, HEAP, lsl #32
    //     0x6ce918: sub             w2, w1, w13
    //     0x6ce91c: add             x13, fp, w2, sxtw #2
    //     0x6ce920: ldr             x13, [x13, #8]
    //     0x6ce924: add             w2, w23, #2
    //     0x6ce928: sbfx            x23, x2, #1, #0x1f
    //     0x6ce92c: mov             x2, x23
    //     0x6ce930: b               #0x6ce938
    //     0x6ce934: mov             x13, NULL
    //     0x6ce938: lsl             x23, x2, #1
    //     0x6ce93c: lsl             w2, w23, #1
    //     0x6ce940: add             w23, w2, #8
    //     0x6ce944: add             x16, x0, w23, sxtw #1
    //     0x6ce948: ldur            w24, [x16, #0xf]
    //     0x6ce94c: add             x24, x24, HEAP, lsl #32
    //     0x6ce950: add             x16, PP, #0xe, lsl #12  ; [pp+0xe060] "wordSpacing"
    //     0x6ce954: ldr             x16, [x16, #0x60]
    //     0x6ce958: cmp             w24, w16
    //     0x6ce95c: b.ne            #0x6ce984
    //     0x6ce960: add             w23, w2, #0xa
    //     0x6ce964: add             x16, x0, w23, sxtw #1
    //     0x6ce968: ldur            w2, [x16, #0xf]
    //     0x6ce96c: add             x2, x2, HEAP, lsl #32
    //     0x6ce970: sub             w0, w1, w2
    //     0x6ce974: add             x1, fp, w0, sxtw #2
    //     0x6ce978: ldr             x1, [x1, #8]
    //     0x6ce97c: mov             x0, x1
    //     0x6ce980: b               #0x6ce988
    //     0x6ce984: mov             x0, NULL
    // 0x6ce988: cmp             w9, NULL
    // 0x6ce98c: b.ne            #0x6ce99c
    // 0x6ce990: LoadField: r1 = r3->field_7
    //     0x6ce990: ldur            w1, [x3, #7]
    // 0x6ce994: DecompressPointer r1
    //     0x6ce994: add             x1, x1, HEAP, lsl #32
    // 0x6ce998: b               #0x6ce9a0
    // 0x6ce99c: mov             x1, x9
    // 0x6ce9a0: stur            x1, [fp, #-0xc0]
    // 0x6ce9a4: LoadField: r2 = r3->field_43
    //     0x6ce9a4: ldur            w2, [x3, #0x43]
    // 0x6ce9a8: DecompressPointer r2
    //     0x6ce9a8: add             x2, x2, HEAP, lsl #32
    // 0x6ce9ac: cmp             w2, NULL
    // 0x6ce9b0: b.ne            #0x6ce9d0
    // 0x6ce9b4: cmp             w11, NULL
    // 0x6ce9b8: b.ne            #0x6ce9d0
    // 0x6ce9bc: cmp             w6, NULL
    // 0x6ce9c0: b.ne            #0x6ce9d4
    // 0x6ce9c4: LoadField: r6 = r3->field_b
    //     0x6ce9c4: ldur            w6, [x3, #0xb]
    // 0x6ce9c8: DecompressPointer r6
    //     0x6ce9c8: add             x6, x6, HEAP, lsl #32
    // 0x6ce9cc: b               #0x6ce9d4
    // 0x6ce9d0: r6 = Null
    //     0x6ce9d0: mov             x6, NULL
    // 0x6ce9d4: stur            x6, [fp, #-0xb8]
    // 0x6ce9d8: LoadField: r9 = r3->field_47
    //     0x6ce9d8: ldur            w9, [x3, #0x47]
    // 0x6ce9dc: DecompressPointer r9
    //     0x6ce9dc: add             x9, x9, HEAP, lsl #32
    // 0x6ce9e0: cmp             w9, NULL
    // 0x6ce9e4: b.ne            #0x6cea04
    // 0x6ce9e8: cmp             w4, NULL
    // 0x6ce9ec: b.ne            #0x6cea04
    // 0x6ce9f0: cmp             w5, NULL
    // 0x6ce9f4: b.ne            #0x6cea08
    // 0x6ce9f8: LoadField: r5 = r3->field_f
    //     0x6ce9f8: ldur            w5, [x3, #0xf]
    // 0x6ce9fc: DecompressPointer r5
    //     0x6ce9fc: add             x5, x5, HEAP, lsl #32
    // 0x6cea00: b               #0x6cea08
    // 0x6cea04: r5 = Null
    //     0x6cea04: mov             x5, NULL
    // 0x6cea08: stur            x5, [fp, #-0xb0]
    // 0x6cea0c: cmp             w14, NULL
    // 0x6cea10: b.ne            #0x6cea1c
    // 0x6cea14: LoadField: r14 = r3->field_1f
    //     0x6cea14: ldur            w14, [x3, #0x1f]
    // 0x6cea18: DecompressPointer r14
    //     0x6cea18: add             x14, x14, HEAP, lsl #32
    // 0x6cea1c: stur            x14, [fp, #-0xa8]
    // 0x6cea20: cmp             w12, NULL
    // 0x6cea24: b.ne            #0x6cea30
    // 0x6cea28: LoadField: r12 = r3->field_23
    //     0x6cea28: ldur            w12, [x3, #0x23]
    // 0x6cea2c: DecompressPointer r12
    //     0x6cea2c: add             x12, x12, HEAP, lsl #32
    // 0x6cea30: stur            x12, [fp, #-0xa0]
    // 0x6cea34: cmp             w19, NULL
    // 0x6cea38: b.ne            #0x6cea44
    // 0x6cea3c: LoadField: r19 = r3->field_27
    //     0x6cea3c: ldur            w19, [x3, #0x27]
    // 0x6cea40: DecompressPointer r19
    //     0x6cea40: add             x19, x19, HEAP, lsl #32
    // 0x6cea44: stur            x19, [fp, #-0x98]
    // 0x6cea48: cmp             w7, NULL
    // 0x6cea4c: b.ne            #0x6cea58
    // 0x6cea50: LoadField: r7 = r3->field_2b
    //     0x6cea50: ldur            w7, [x3, #0x2b]
    // 0x6cea54: DecompressPointer r7
    //     0x6cea54: add             x7, x7, HEAP, lsl #32
    // 0x6cea58: stur            x7, [fp, #-0x90]
    // 0x6cea5c: cmp             w0, NULL
    // 0x6cea60: b.ne            #0x6cea6c
    // 0x6cea64: LoadField: r0 = r3->field_2f
    //     0x6cea64: ldur            w0, [x3, #0x2f]
    // 0x6cea68: DecompressPointer r0
    //     0x6cea68: add             x0, x0, HEAP, lsl #32
    // 0x6cea6c: stur            x0, [fp, #-0x88]
    // 0x6cea70: cmp             w13, NULL
    // 0x6cea74: b.ne            #0x6cea80
    // 0x6cea78: LoadField: r13 = r3->field_33
    //     0x6cea78: ldur            w13, [x3, #0x33]
    // 0x6cea7c: DecompressPointer r13
    //     0x6cea7c: add             x13, x13, HEAP, lsl #32
    // 0x6cea80: stur            x13, [fp, #-0x80]
    // 0x6cea84: cmp             w10, NULL
    // 0x6cea88: b.ne            #0x6cea94
    // 0x6cea8c: LoadField: r10 = r3->field_37
    //     0x6cea8c: ldur            w10, [x3, #0x37]
    // 0x6cea90: DecompressPointer r10
    //     0x6cea90: add             x10, x10, HEAP, lsl #32
    // 0x6cea94: stur            x10, [fp, #-0x78]
    // 0x6cea98: cmp             w8, NULL
    // 0x6cea9c: b.ne            #0x6ceaa8
    // 0x6ceaa0: LoadField: r8 = r3->field_3b
    //     0x6ceaa0: ldur            w8, [x3, #0x3b]
    // 0x6ceaa4: DecompressPointer r8
    //     0x6ceaa4: add             x8, x8, HEAP, lsl #32
    // 0x6ceaa8: stur            x8, [fp, #-0x70]
    // 0x6ceaac: cmp             w11, NULL
    // 0x6ceab0: b.eq            #0x6ceab8
    // 0x6ceab4: mov             x2, x11
    // 0x6ceab8: stur            x2, [fp, #-0x68]
    // 0x6ceabc: cmp             w4, NULL
    // 0x6ceac0: b.ne            #0x6ceac8
    // 0x6ceac4: mov             x4, x9
    // 0x6ceac8: stur            x4, [fp, #-0x60]
    // 0x6ceacc: cmp             w20, NULL
    // 0x6cead0: b.ne            #0x6ceae4
    // 0x6cead4: LoadField: r9 = r3->field_5f
    //     0x6cead4: ldur            w9, [x3, #0x5f]
    // 0x6cead8: DecompressPointer r9
    //     0x6cead8: add             x9, x9, HEAP, lsl #32
    // 0x6ceadc: mov             x11, x9
    // 0x6ceae0: b               #0x6ceae8
    // 0x6ceae4: mov             x11, x20
    // 0x6ceae8: ldur            x9, [fp, #-0x48]
    // 0x6ceaec: stur            x11, [fp, #-0x58]
    // 0x6ceaf0: cmp             w9, NULL
    // 0x6ceaf4: b.ne            #0x6ceb08
    // 0x6ceaf8: LoadField: r9 = r3->field_63
    //     0x6ceaf8: ldur            w9, [x3, #0x63]
    // 0x6ceafc: DecompressPointer r9
    //     0x6ceafc: add             x9, x9, HEAP, lsl #32
    // 0x6ceb00: mov             x20, x9
    // 0x6ceb04: b               #0x6ceb0c
    // 0x6ceb08: mov             x20, x9
    // 0x6ceb0c: ldur            x9, [fp, #-0x38]
    // 0x6ceb10: stur            x20, [fp, #-0x50]
    // 0x6ceb14: cmp             w9, NULL
    // 0x6ceb18: b.ne            #0x6ceb2c
    // 0x6ceb1c: LoadField: r9 = r3->field_67
    //     0x6ceb1c: ldur            w9, [x3, #0x67]
    // 0x6ceb20: DecompressPointer r9
    //     0x6ceb20: add             x9, x9, HEAP, lsl #32
    // 0x6ceb24: mov             x23, x9
    // 0x6ceb28: b               #0x6ceb30
    // 0x6ceb2c: mov             x23, x9
    // 0x6ceb30: ldur            x9, [fp, #-0x30]
    // 0x6ceb34: stur            x23, [fp, #-0x48]
    // 0x6ceb38: cmp             w9, NULL
    // 0x6ceb3c: b.ne            #0x6ceb50
    // 0x6ceb40: LoadField: r9 = r3->field_4b
    //     0x6ceb40: ldur            w9, [x3, #0x4b]
    // 0x6ceb44: DecompressPointer r9
    //     0x6ceb44: add             x9, x9, HEAP, lsl #32
    // 0x6ceb48: mov             x24, x9
    // 0x6ceb4c: b               #0x6ceb54
    // 0x6ceb50: mov             x24, x9
    // 0x6ceb54: ldur            x9, [fp, #-0x28]
    // 0x6ceb58: stur            x24, [fp, #-0x38]
    // 0x6ceb5c: cmp             w9, NULL
    // 0x6ceb60: b.ne            #0x6ceb74
    // 0x6ceb64: LoadField: r9 = r3->field_4f
    //     0x6ceb64: ldur            w9, [x3, #0x4f]
    // 0x6ceb68: DecompressPointer r9
    //     0x6ceb68: add             x9, x9, HEAP, lsl #32
    // 0x6ceb6c: mov             x25, x9
    // 0x6ceb70: b               #0x6ceb78
    // 0x6ceb74: mov             x25, x9
    // 0x6ceb78: ldur            x9, [fp, #-0x20]
    // 0x6ceb7c: stur            x25, [fp, #-0x30]
    // 0x6ceb80: cmp             w9, NULL
    // 0x6ceb84: b.ne            #0x6ceb98
    // 0x6ceb88: LoadField: r9 = r3->field_53
    //     0x6ceb88: ldur            w9, [x3, #0x53]
    // 0x6ceb8c: DecompressPointer r9
    //     0x6ceb8c: add             x9, x9, HEAP, lsl #32
    // 0x6ceb90: stur            x9, [fp, #-0x20]
    // 0x6ceb94: b               #0x6ceb9c
    // 0x6ceb98: stur            x9, [fp, #-0x20]
    // 0x6ceb9c: ldur            x9, [fp, #-0x18]
    // 0x6ceba0: cmp             w9, NULL
    // 0x6ceba4: b.ne            #0x6cebb8
    // 0x6ceba8: LoadField: r9 = r3->field_57
    //     0x6ceba8: ldur            w9, [x3, #0x57]
    // 0x6cebac: DecompressPointer r9
    //     0x6cebac: add             x9, x9, HEAP, lsl #32
    // 0x6cebb0: stur            x9, [fp, #-0x18]
    // 0x6cebb4: b               #0x6cebbc
    // 0x6cebb8: stur            x9, [fp, #-0x18]
    // 0x6cebbc: ldur            x9, [fp, #-0x10]
    // 0x6cebc0: cmp             w9, NULL
    // 0x6cebc4: b.ne            #0x6cebd8
    // 0x6cebc8: LoadField: r9 = r3->field_13
    //     0x6cebc8: ldur            w9, [x3, #0x13]
    // 0x6cebcc: DecompressPointer r9
    //     0x6cebcc: add             x9, x9, HEAP, lsl #32
    // 0x6cebd0: stur            x9, [fp, #-0x10]
    // 0x6cebd4: b               #0x6cebdc
    // 0x6cebd8: stur            x9, [fp, #-0x10]
    // 0x6cebdc: ldur            x9, [fp, #-8]
    // 0x6cebe0: cmp             w9, NULL
    // 0x6cebe4: b.ne            #0x6cebf8
    // 0x6cebe8: LoadField: r9 = r3->field_17
    //     0x6cebe8: ldur            w9, [x3, #0x17]
    // 0x6cebec: DecompressPointer r9
    //     0x6cebec: add             x9, x9, HEAP, lsl #32
    // 0x6cebf0: stur            x9, [fp, #-8]
    // 0x6cebf4: b               #0x6cebfc
    // 0x6cebf8: stur            x9, [fp, #-8]
    // 0x6cebfc: ldur            x9, [fp, #-0x40]
    // 0x6cec00: cmp             w9, NULL
    // 0x6cec04: b.ne            #0x6cec18
    // 0x6cec08: LoadField: r9 = r3->field_6b
    //     0x6cec08: ldur            w9, [x3, #0x6b]
    // 0x6cec0c: DecompressPointer r9
    //     0x6cec0c: add             x9, x9, HEAP, lsl #32
    // 0x6cec10: stur            x9, [fp, #-0x28]
    // 0x6cec14: b               #0x6cec1c
    // 0x6cec18: stur            x9, [fp, #-0x28]
    // 0x6cec1c: ldur            x9, [fp, #-0x10]
    // 0x6cec20: ldur            x3, [fp, #-8]
    // 0x6cec24: r0 = TextStyle()
    //     0x6cec24: bl              #0x6cecec  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6cec28: ldur            x1, [fp, #-0xc0]
    // 0x6cec2c: StoreField: r0->field_7 = r1
    //     0x6cec2c: stur            w1, [x0, #7]
    // 0x6cec30: ldur            x1, [fp, #-0xb8]
    // 0x6cec34: StoreField: r0->field_b = r1
    //     0x6cec34: stur            w1, [x0, #0xb]
    // 0x6cec38: ldur            x1, [fp, #-0xb0]
    // 0x6cec3c: StoreField: r0->field_f = r1
    //     0x6cec3c: stur            w1, [x0, #0xf]
    // 0x6cec40: ldur            x1, [fp, #-0xa8]
    // 0x6cec44: StoreField: r0->field_1f = r1
    //     0x6cec44: stur            w1, [x0, #0x1f]
    // 0x6cec48: ldur            x1, [fp, #-0xa0]
    // 0x6cec4c: StoreField: r0->field_23 = r1
    //     0x6cec4c: stur            w1, [x0, #0x23]
    // 0x6cec50: ldur            x1, [fp, #-0x98]
    // 0x6cec54: StoreField: r0->field_27 = r1
    //     0x6cec54: stur            w1, [x0, #0x27]
    // 0x6cec58: ldur            x1, [fp, #-0x90]
    // 0x6cec5c: StoreField: r0->field_2b = r1
    //     0x6cec5c: stur            w1, [x0, #0x2b]
    // 0x6cec60: ldur            x1, [fp, #-0x88]
    // 0x6cec64: StoreField: r0->field_2f = r1
    //     0x6cec64: stur            w1, [x0, #0x2f]
    // 0x6cec68: ldur            x1, [fp, #-0x80]
    // 0x6cec6c: StoreField: r0->field_33 = r1
    //     0x6cec6c: stur            w1, [x0, #0x33]
    // 0x6cec70: ldur            x1, [fp, #-0x78]
    // 0x6cec74: StoreField: r0->field_37 = r1
    //     0x6cec74: stur            w1, [x0, #0x37]
    // 0x6cec78: ldur            x1, [fp, #-0x70]
    // 0x6cec7c: StoreField: r0->field_3b = r1
    //     0x6cec7c: stur            w1, [x0, #0x3b]
    // 0x6cec80: ldur            x1, [fp, #-0x68]
    // 0x6cec84: StoreField: r0->field_43 = r1
    //     0x6cec84: stur            w1, [x0, #0x43]
    // 0x6cec88: ldur            x1, [fp, #-0x60]
    // 0x6cec8c: StoreField: r0->field_47 = r1
    //     0x6cec8c: stur            w1, [x0, #0x47]
    // 0x6cec90: ldur            x1, [fp, #-0x58]
    // 0x6cec94: StoreField: r0->field_5f = r1
    //     0x6cec94: stur            w1, [x0, #0x5f]
    // 0x6cec98: ldur            x1, [fp, #-0x50]
    // 0x6cec9c: StoreField: r0->field_63 = r1
    //     0x6cec9c: stur            w1, [x0, #0x63]
    // 0x6ceca0: ldur            x1, [fp, #-0x48]
    // 0x6ceca4: StoreField: r0->field_67 = r1
    //     0x6ceca4: stur            w1, [x0, #0x67]
    // 0x6ceca8: ldur            x1, [fp, #-0x38]
    // 0x6cecac: StoreField: r0->field_4b = r1
    //     0x6cecac: stur            w1, [x0, #0x4b]
    // 0x6cecb0: ldur            x1, [fp, #-0x30]
    // 0x6cecb4: StoreField: r0->field_4f = r1
    //     0x6cecb4: stur            w1, [x0, #0x4f]
    // 0x6cecb8: ldur            x1, [fp, #-0x20]
    // 0x6cecbc: StoreField: r0->field_53 = r1
    //     0x6cecbc: stur            w1, [x0, #0x53]
    // 0x6cecc0: ldur            x1, [fp, #-0x18]
    // 0x6cecc4: StoreField: r0->field_57 = r1
    //     0x6cecc4: stur            w1, [x0, #0x57]
    // 0x6cecc8: ldur            x1, [fp, #-0x28]
    // 0x6ceccc: StoreField: r0->field_6b = r1
    //     0x6ceccc: stur            w1, [x0, #0x6b]
    // 0x6cecd0: ldur            x1, [fp, #-0x10]
    // 0x6cecd4: StoreField: r0->field_13 = r1
    //     0x6cecd4: stur            w1, [x0, #0x13]
    // 0x6cecd8: ldur            x1, [fp, #-8]
    // 0x6cecdc: StoreField: r0->field_17 = r1
    //     0x6cecdc: stur            w1, [x0, #0x17]
    // 0x6cece0: LeaveFrame
    //     0x6cece0: mov             SP, fp
    //     0x6cece4: ldp             fp, lr, [SP], #0x10
    // 0x6cece8: ret
    //     0x6cece8: ret             
  }
  _ apply(/* No info */) {
    // ** addr: 0x6d204c, size: 0x4e0
    // 0x6d204c: EnterFrame
    //     0x6d204c: stp             fp, lr, [SP, #-0x10]!
    //     0x6d2050: mov             fp, SP
    // 0x6d2054: AllocStack(0xb0)
    //     0x6d2054: sub             SP, SP, #0xb0
    // 0x6d2058: CheckStackOverflow
    //     0x6d2058: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d205c: cmp             SP, x16
    //     0x6d2060: b.ls            #0x6d242c
    // 0x6d2064: ldr             x0, [fp, #0x20]
    // 0x6d2068: LoadField: r1 = r0->field_7
    //     0x6d2068: ldur            w1, [x0, #7]
    // 0x6d206c: DecompressPointer r1
    //     0x6d206c: add             x1, x1, HEAP, lsl #32
    // 0x6d2070: stur            x1, [fp, #-0x40]
    // 0x6d2074: LoadField: r2 = r0->field_43
    //     0x6d2074: ldur            w2, [x0, #0x43]
    // 0x6d2078: DecompressPointer r2
    //     0x6d2078: add             x2, x2, HEAP, lsl #32
    // 0x6d207c: stur            x2, [fp, #-0x38]
    // 0x6d2080: cmp             w2, NULL
    // 0x6d2084: b.ne            #0x6d2090
    // 0x6d2088: ldr             x3, [fp, #0x18]
    // 0x6d208c: b               #0x6d2094
    // 0x6d2090: r3 = Null
    //     0x6d2090: mov             x3, NULL
    // 0x6d2094: stur            x3, [fp, #-0x30]
    // 0x6d2098: LoadField: r4 = r0->field_47
    //     0x6d2098: ldur            w4, [x0, #0x47]
    // 0x6d209c: DecompressPointer r4
    //     0x6d209c: add             x4, x4, HEAP, lsl #32
    // 0x6d20a0: stur            x4, [fp, #-0x28]
    // 0x6d20a4: cmp             w4, NULL
    // 0x6d20a8: b.ne            #0x6d20b8
    // 0x6d20ac: LoadField: r5 = r0->field_f
    //     0x6d20ac: ldur            w5, [x0, #0xf]
    // 0x6d20b0: DecompressPointer r5
    //     0x6d20b0: add             x5, x5, HEAP, lsl #32
    // 0x6d20b4: b               #0x6d20bc
    // 0x6d20b8: r5 = Null
    //     0x6d20b8: mov             x5, NULL
    // 0x6d20bc: stur            x5, [fp, #-0x20]
    // 0x6d20c0: LoadField: r6 = r0->field_13
    //     0x6d20c0: ldur            w6, [x0, #0x13]
    // 0x6d20c4: DecompressPointer r6
    //     0x6d20c4: add             x6, x6, HEAP, lsl #32
    // 0x6d20c8: stur            x6, [fp, #-0x18]
    // 0x6d20cc: LoadField: r7 = r0->field_17
    //     0x6d20cc: ldur            w7, [x0, #0x17]
    // 0x6d20d0: DecompressPointer r7
    //     0x6d20d0: add             x7, x7, HEAP, lsl #32
    // 0x6d20d4: stur            x7, [fp, #-0x10]
    // 0x6d20d8: LoadField: r8 = r0->field_1f
    //     0x6d20d8: ldur            w8, [x0, #0x1f]
    // 0x6d20dc: DecompressPointer r8
    //     0x6d20dc: add             x8, x8, HEAP, lsl #32
    // 0x6d20e0: cmp             w8, NULL
    // 0x6d20e4: b.ne            #0x6d20f4
    // 0x6d20e8: r8 = Null
    //     0x6d20e8: mov             x8, NULL
    // 0x6d20ec: d0 = 0.000000
    //     0x6d20ec: eor             v0.16b, v0.16b, v0.16b
    // 0x6d20f0: b               #0x6d2128
    // 0x6d20f4: d0 = 0.000000
    //     0x6d20f4: eor             v0.16b, v0.16b, v0.16b
    // 0x6d20f8: LoadField: d1 = r8->field_7
    //     0x6d20f8: ldur            d1, [x8, #7]
    // 0x6d20fc: fadd            d2, d1, d0
    // 0x6d2100: r8 = inline_Allocate_Double()
    //     0x6d2100: ldp             x8, x9, [THR, #0x60]  ; THR::top
    //     0x6d2104: add             x8, x8, #0x10
    //     0x6d2108: cmp             x9, x8
    //     0x6d210c: b.ls            #0x6d2434
    //     0x6d2110: str             x8, [THR, #0x60]  ; THR::top
    //     0x6d2114: sub             x8, x8, #0xf
    //     0x6d2118: mov             x9, #0xd108
    //     0x6d211c: movk            x9, #3, lsl #16
    //     0x6d2120: stur            x9, [x8, #-1]
    // 0x6d2124: StoreField: r8->field_7 = d2
    //     0x6d2124: stur            d2, [x8, #7]
    // 0x6d2128: stur            x8, [fp, #-8]
    // 0x6d212c: LoadField: r9 = r0->field_23
    //     0x6d212c: ldur            w9, [x0, #0x23]
    // 0x6d2130: DecompressPointer r9
    //     0x6d2130: add             x9, x9, HEAP, lsl #32
    // 0x6d2134: cmp             w9, NULL
    // 0x6d2138: b.ne            #0x6d2144
    // 0x6d213c: r1 = Null
    //     0x6d213c: mov             x1, NULL
    // 0x6d2140: b               #0x6d2194
    // 0x6d2144: LoadField: r10 = r9->field_7
    //     0x6d2144: ldur            x10, [x9, #7]
    // 0x6d2148: lsl             x9, x10, #1
    // 0x6d214c: stp             xzr, x9, [SP, #-0x10]!
    // 0x6d2150: r16 = 16
    //     0x6d2150: mov             x16, #0x10
    // 0x6d2154: SaveReg r16
    //     0x6d2154: str             x16, [SP, #-8]!
    // 0x6d2158: r0 = clamp()
    //     0x6d2158: bl              #0xd66d18  ; [dart:core] _IntegerImplementation::clamp
    // 0x6d215c: add             SP, SP, #0x18
    // 0x6d2160: r2 = LoadInt32Instr(r0)
    //     0x6d2160: sbfx            x2, x0, #1, #0x1f
    //     0x6d2164: tbz             w0, #0, #0x6d216c
    //     0x6d2168: ldur            x2, [x0, #7]
    // 0x6d216c: mov             x1, x2
    // 0x6d2170: r0 = 9
    //     0x6d2170: mov             x0, #9
    // 0x6d2174: cmp             x1, x0
    // 0x6d2178: b.hs            #0x6d2468
    // 0x6d217c: r0 = const [Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight', Instance of 'FontWeight']
    //     0x6d217c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd1f8] List<FontWeight>(9)
    //     0x6d2180: ldr             x0, [x0, #0x1f8]
    // 0x6d2184: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x6d2184: add             x16, x0, x2, lsl #2
    //     0x6d2188: ldur            w1, [x16, #0xf]
    // 0x6d218c: DecompressPointer r1
    //     0x6d218c: add             x1, x1, HEAP, lsl #32
    // 0x6d2190: ldr             x0, [fp, #0x20]
    // 0x6d2194: stur            x1, [fp, #-0x50]
    // 0x6d2198: LoadField: r2 = r0->field_27
    //     0x6d2198: ldur            w2, [x0, #0x27]
    // 0x6d219c: DecompressPointer r2
    //     0x6d219c: add             x2, x2, HEAP, lsl #32
    // 0x6d21a0: stur            x2, [fp, #-0xb0]
    // 0x6d21a4: LoadField: r3 = r0->field_2b
    //     0x6d21a4: ldur            w3, [x0, #0x2b]
    // 0x6d21a8: DecompressPointer r3
    //     0x6d21a8: add             x3, x3, HEAP, lsl #32
    // 0x6d21ac: cmp             w3, NULL
    // 0x6d21b0: b.ne            #0x6d21c0
    // 0x6d21b4: r3 = Null
    //     0x6d21b4: mov             x3, NULL
    // 0x6d21b8: d0 = 0.000000
    //     0x6d21b8: eor             v0.16b, v0.16b, v0.16b
    // 0x6d21bc: b               #0x6d21f4
    // 0x6d21c0: d0 = 0.000000
    //     0x6d21c0: eor             v0.16b, v0.16b, v0.16b
    // 0x6d21c4: LoadField: d1 = r3->field_7
    //     0x6d21c4: ldur            d1, [x3, #7]
    // 0x6d21c8: fadd            d2, d1, d0
    // 0x6d21cc: r3 = inline_Allocate_Double()
    //     0x6d21cc: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x6d21d0: add             x3, x3, #0x10
    //     0x6d21d4: cmp             x4, x3
    //     0x6d21d8: b.ls            #0x6d246c
    //     0x6d21dc: str             x3, [THR, #0x60]  ; THR::top
    //     0x6d21e0: sub             x3, x3, #0xf
    //     0x6d21e4: mov             x4, #0xd108
    //     0x6d21e8: movk            x4, #3, lsl #16
    //     0x6d21ec: stur            x4, [x3, #-1]
    // 0x6d21f0: StoreField: r3->field_7 = d2
    //     0x6d21f0: stur            d2, [x3, #7]
    // 0x6d21f4: stur            x3, [fp, #-0xa8]
    // 0x6d21f8: LoadField: r4 = r0->field_2f
    //     0x6d21f8: ldur            w4, [x0, #0x2f]
    // 0x6d21fc: DecompressPointer r4
    //     0x6d21fc: add             x4, x4, HEAP, lsl #32
    // 0x6d2200: cmp             w4, NULL
    // 0x6d2204: b.ne            #0x6d2210
    // 0x6d2208: r4 = Null
    //     0x6d2208: mov             x4, NULL
    // 0x6d220c: b               #0x6d2240
    // 0x6d2210: LoadField: d1 = r4->field_7
    //     0x6d2210: ldur            d1, [x4, #7]
    // 0x6d2214: fadd            d2, d1, d0
    // 0x6d2218: r4 = inline_Allocate_Double()
    //     0x6d2218: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x6d221c: add             x4, x4, #0x10
    //     0x6d2220: cmp             x5, x4
    //     0x6d2224: b.ls            #0x6d2490
    //     0x6d2228: str             x4, [THR, #0x60]  ; THR::top
    //     0x6d222c: sub             x4, x4, #0xf
    //     0x6d2230: mov             x5, #0xd108
    //     0x6d2234: movk            x5, #3, lsl #16
    //     0x6d2238: stur            x5, [x4, #-1]
    // 0x6d223c: StoreField: r4->field_7 = d2
    //     0x6d223c: stur            d2, [x4, #7]
    // 0x6d2240: stur            x4, [fp, #-0xa0]
    // 0x6d2244: LoadField: r5 = r0->field_33
    //     0x6d2244: ldur            w5, [x0, #0x33]
    // 0x6d2248: DecompressPointer r5
    //     0x6d2248: add             x5, x5, HEAP, lsl #32
    // 0x6d224c: stur            x5, [fp, #-0x98]
    // 0x6d2250: LoadField: r6 = r0->field_37
    //     0x6d2250: ldur            w6, [x0, #0x37]
    // 0x6d2254: DecompressPointer r6
    //     0x6d2254: add             x6, x6, HEAP, lsl #32
    // 0x6d2258: cmp             w6, NULL
    // 0x6d225c: b.ne            #0x6d2268
    // 0x6d2260: r6 = Null
    //     0x6d2260: mov             x6, NULL
    // 0x6d2264: b               #0x6d2298
    // 0x6d2268: LoadField: d1 = r6->field_7
    //     0x6d2268: ldur            d1, [x6, #7]
    // 0x6d226c: fadd            d2, d1, d0
    // 0x6d2270: r6 = inline_Allocate_Double()
    //     0x6d2270: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x6d2274: add             x6, x6, #0x10
    //     0x6d2278: cmp             x7, x6
    //     0x6d227c: b.ls            #0x6d24b4
    //     0x6d2280: str             x6, [THR, #0x60]  ; THR::top
    //     0x6d2284: sub             x6, x6, #0xf
    //     0x6d2288: mov             x7, #0xd108
    //     0x6d228c: movk            x7, #3, lsl #16
    //     0x6d2290: stur            x7, [x6, #-1]
    // 0x6d2294: StoreField: r6->field_7 = d2
    //     0x6d2294: stur            d2, [x6, #7]
    // 0x6d2298: stur            x6, [fp, #-0x90]
    // 0x6d229c: LoadField: r7 = r0->field_3b
    //     0x6d229c: ldur            w7, [x0, #0x3b]
    // 0x6d22a0: DecompressPointer r7
    //     0x6d22a0: add             x7, x7, HEAP, lsl #32
    // 0x6d22a4: stur            x7, [fp, #-0x88]
    // 0x6d22a8: LoadField: r8 = r0->field_5f
    //     0x6d22a8: ldur            w8, [x0, #0x5f]
    // 0x6d22ac: DecompressPointer r8
    //     0x6d22ac: add             x8, x8, HEAP, lsl #32
    // 0x6d22b0: stur            x8, [fp, #-0x80]
    // 0x6d22b4: LoadField: r9 = r0->field_63
    //     0x6d22b4: ldur            w9, [x0, #0x63]
    // 0x6d22b8: DecompressPointer r9
    //     0x6d22b8: add             x9, x9, HEAP, lsl #32
    // 0x6d22bc: stur            x9, [fp, #-0x78]
    // 0x6d22c0: LoadField: r10 = r0->field_67
    //     0x6d22c0: ldur            w10, [x0, #0x67]
    // 0x6d22c4: DecompressPointer r10
    //     0x6d22c4: add             x10, x10, HEAP, lsl #32
    // 0x6d22c8: stur            x10, [fp, #-0x70]
    // 0x6d22cc: LoadField: r11 = r0->field_4b
    //     0x6d22cc: ldur            w11, [x0, #0x4b]
    // 0x6d22d0: DecompressPointer r11
    //     0x6d22d0: add             x11, x11, HEAP, lsl #32
    // 0x6d22d4: stur            x11, [fp, #-0x68]
    // 0x6d22d8: LoadField: r12 = r0->field_53
    //     0x6d22d8: ldur            w12, [x0, #0x53]
    // 0x6d22dc: DecompressPointer r12
    //     0x6d22dc: add             x12, x12, HEAP, lsl #32
    // 0x6d22e0: stur            x12, [fp, #-0x60]
    // 0x6d22e4: LoadField: r13 = r0->field_57
    //     0x6d22e4: ldur            w13, [x0, #0x57]
    // 0x6d22e8: DecompressPointer r13
    //     0x6d22e8: add             x13, x13, HEAP, lsl #32
    // 0x6d22ec: cmp             w13, NULL
    // 0x6d22f0: b.ne            #0x6d2304
    // 0x6d22f4: SaveReg r0
    //     0x6d22f4: str             x0, [SP, #-8]!
    // 0x6d22f8: stur            NULL, [fp, #-0x48]
    // 0x6d22fc: RestoreReg r0
    //     0x6d22fc: ldr             x0, [SP], #8
    // 0x6d2300: b               #0x6d2338
    // 0x6d2304: LoadField: d1 = r13->field_7
    //     0x6d2304: ldur            d1, [x13, #7]
    // 0x6d2308: fadd            d2, d1, d0
    // 0x6d230c: r13 = inline_Allocate_Double()
    //     0x6d230c: ldp             x13, x14, [THR, #0x60]  ; THR::top
    //     0x6d2310: add             x13, x13, #0x10
    //     0x6d2314: cmp             x14, x13
    //     0x6d2318: b.ls            #0x6d24e0
    //     0x6d231c: str             x13, [THR, #0x60]  ; THR::top
    //     0x6d2320: sub             x13, x13, #0xf
    //     0x6d2324: mov             x14, #0xd108
    //     0x6d2328: movk            x14, #3, lsl #16
    //     0x6d232c: stur            x14, [x13, #-1]
    // 0x6d2330: StoreField: r13->field_7 = d2
    //     0x6d2330: stur            d2, [x13, #7]
    // 0x6d2334: stur            x13, [fp, #-0x48]
    // 0x6d2338: ldur            x13, [fp, #-0x40]
    // 0x6d233c: ldur            x14, [fp, #-0x38]
    // 0x6d2340: ldur            x19, [fp, #-0x30]
    // 0x6d2344: ldur            x20, [fp, #-0x28]
    // 0x6d2348: ldur            x23, [fp, #-0x20]
    // 0x6d234c: ldur            x25, [fp, #-0x10]
    // 0x6d2350: ldur            x24, [fp, #-0x18]
    // 0x6d2354: LoadField: r1 = r0->field_6b
    //     0x6d2354: ldur            w1, [x0, #0x6b]
    // 0x6d2358: DecompressPointer r1
    //     0x6d2358: add             x1, x1, HEAP, lsl #32
    // 0x6d235c: mov             x0, x1
    // 0x6d2360: stur            x1, [fp, #-0x58]
    // 0x6d2364: r0 = TextStyle()
    //     0x6d2364: bl              #0x6cecec  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0x6d2368: ldur            x1, [fp, #-0x40]
    // 0x6d236c: StoreField: r0->field_7 = r1
    //     0x6d236c: stur            w1, [x0, #7]
    // 0x6d2370: ldur            x1, [fp, #-0x30]
    // 0x6d2374: StoreField: r0->field_b = r1
    //     0x6d2374: stur            w1, [x0, #0xb]
    // 0x6d2378: ldur            x1, [fp, #-0x20]
    // 0x6d237c: StoreField: r0->field_f = r1
    //     0x6d237c: stur            w1, [x0, #0xf]
    // 0x6d2380: ldur            x1, [fp, #-8]
    // 0x6d2384: StoreField: r0->field_1f = r1
    //     0x6d2384: stur            w1, [x0, #0x1f]
    // 0x6d2388: ldur            x1, [fp, #-0x50]
    // 0x6d238c: StoreField: r0->field_23 = r1
    //     0x6d238c: stur            w1, [x0, #0x23]
    // 0x6d2390: ldur            x1, [fp, #-0xb0]
    // 0x6d2394: StoreField: r0->field_27 = r1
    //     0x6d2394: stur            w1, [x0, #0x27]
    // 0x6d2398: ldur            x1, [fp, #-0xa8]
    // 0x6d239c: StoreField: r0->field_2b = r1
    //     0x6d239c: stur            w1, [x0, #0x2b]
    // 0x6d23a0: ldur            x1, [fp, #-0xa0]
    // 0x6d23a4: StoreField: r0->field_2f = r1
    //     0x6d23a4: stur            w1, [x0, #0x2f]
    // 0x6d23a8: ldur            x1, [fp, #-0x98]
    // 0x6d23ac: StoreField: r0->field_33 = r1
    //     0x6d23ac: stur            w1, [x0, #0x33]
    // 0x6d23b0: ldur            x1, [fp, #-0x90]
    // 0x6d23b4: StoreField: r0->field_37 = r1
    //     0x6d23b4: stur            w1, [x0, #0x37]
    // 0x6d23b8: ldur            x1, [fp, #-0x88]
    // 0x6d23bc: StoreField: r0->field_3b = r1
    //     0x6d23bc: stur            w1, [x0, #0x3b]
    // 0x6d23c0: ldur            x1, [fp, #-0x38]
    // 0x6d23c4: StoreField: r0->field_43 = r1
    //     0x6d23c4: stur            w1, [x0, #0x43]
    // 0x6d23c8: ldur            x1, [fp, #-0x28]
    // 0x6d23cc: StoreField: r0->field_47 = r1
    //     0x6d23cc: stur            w1, [x0, #0x47]
    // 0x6d23d0: ldur            x1, [fp, #-0x80]
    // 0x6d23d4: StoreField: r0->field_5f = r1
    //     0x6d23d4: stur            w1, [x0, #0x5f]
    // 0x6d23d8: ldur            x1, [fp, #-0x78]
    // 0x6d23dc: StoreField: r0->field_63 = r1
    //     0x6d23dc: stur            w1, [x0, #0x63]
    // 0x6d23e0: ldur            x1, [fp, #-0x70]
    // 0x6d23e4: StoreField: r0->field_67 = r1
    //     0x6d23e4: stur            w1, [x0, #0x67]
    // 0x6d23e8: ldur            x1, [fp, #-0x68]
    // 0x6d23ec: StoreField: r0->field_4b = r1
    //     0x6d23ec: stur            w1, [x0, #0x4b]
    // 0x6d23f0: ldr             x1, [fp, #0x10]
    // 0x6d23f4: StoreField: r0->field_4f = r1
    //     0x6d23f4: stur            w1, [x0, #0x4f]
    // 0x6d23f8: ldur            x1, [fp, #-0x60]
    // 0x6d23fc: StoreField: r0->field_53 = r1
    //     0x6d23fc: stur            w1, [x0, #0x53]
    // 0x6d2400: ldur            x1, [fp, #-0x48]
    // 0x6d2404: StoreField: r0->field_57 = r1
    //     0x6d2404: stur            w1, [x0, #0x57]
    // 0x6d2408: ldur            x1, [fp, #-0x58]
    // 0x6d240c: StoreField: r0->field_6b = r1
    //     0x6d240c: stur            w1, [x0, #0x6b]
    // 0x6d2410: ldur            x1, [fp, #-0x18]
    // 0x6d2414: StoreField: r0->field_13 = r1
    //     0x6d2414: stur            w1, [x0, #0x13]
    // 0x6d2418: ldur            x1, [fp, #-0x10]
    // 0x6d241c: StoreField: r0->field_17 = r1
    //     0x6d241c: stur            w1, [x0, #0x17]
    // 0x6d2420: LeaveFrame
    //     0x6d2420: mov             SP, fp
    //     0x6d2424: ldp             fp, lr, [SP], #0x10
    // 0x6d2428: ret
    //     0x6d2428: ret             
    // 0x6d242c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d242c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d2430: b               #0x6d2064
    // 0x6d2434: stp             q0, q2, [SP, #-0x20]!
    // 0x6d2438: stp             x6, x7, [SP, #-0x10]!
    // 0x6d243c: stp             x4, x5, [SP, #-0x10]!
    // 0x6d2440: stp             x2, x3, [SP, #-0x10]!
    // 0x6d2444: stp             x0, x1, [SP, #-0x10]!
    // 0x6d2448: r0 = AllocateDouble()
    //     0x6d2448: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6d244c: mov             x8, x0
    // 0x6d2450: ldp             x0, x1, [SP], #0x10
    // 0x6d2454: ldp             x2, x3, [SP], #0x10
    // 0x6d2458: ldp             x4, x5, [SP], #0x10
    // 0x6d245c: ldp             x6, x7, [SP], #0x10
    // 0x6d2460: ldp             q0, q2, [SP], #0x20
    // 0x6d2464: b               #0x6d2124
    // 0x6d2468: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6d2468: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6d246c: stp             q0, q2, [SP, #-0x20]!
    // 0x6d2470: stp             x1, x2, [SP, #-0x10]!
    // 0x6d2474: SaveReg r0
    //     0x6d2474: str             x0, [SP, #-8]!
    // 0x6d2478: r0 = AllocateDouble()
    //     0x6d2478: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6d247c: mov             x3, x0
    // 0x6d2480: RestoreReg r0
    //     0x6d2480: ldr             x0, [SP], #8
    // 0x6d2484: ldp             x1, x2, [SP], #0x10
    // 0x6d2488: ldp             q0, q2, [SP], #0x20
    // 0x6d248c: b               #0x6d21f0
    // 0x6d2490: stp             q0, q2, [SP, #-0x20]!
    // 0x6d2494: stp             x2, x3, [SP, #-0x10]!
    // 0x6d2498: stp             x0, x1, [SP, #-0x10]!
    // 0x6d249c: r0 = AllocateDouble()
    //     0x6d249c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6d24a0: mov             x4, x0
    // 0x6d24a4: ldp             x0, x1, [SP], #0x10
    // 0x6d24a8: ldp             x2, x3, [SP], #0x10
    // 0x6d24ac: ldp             q0, q2, [SP], #0x20
    // 0x6d24b0: b               #0x6d223c
    // 0x6d24b4: stp             q0, q2, [SP, #-0x20]!
    // 0x6d24b8: stp             x4, x5, [SP, #-0x10]!
    // 0x6d24bc: stp             x2, x3, [SP, #-0x10]!
    // 0x6d24c0: stp             x0, x1, [SP, #-0x10]!
    // 0x6d24c4: r0 = AllocateDouble()
    //     0x6d24c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6d24c8: mov             x6, x0
    // 0x6d24cc: ldp             x0, x1, [SP], #0x10
    // 0x6d24d0: ldp             x2, x3, [SP], #0x10
    // 0x6d24d4: ldp             x4, x5, [SP], #0x10
    // 0x6d24d8: ldp             q0, q2, [SP], #0x20
    // 0x6d24dc: b               #0x6d2294
    // 0x6d24e0: SaveReg d2
    //     0x6d24e0: str             q2, [SP, #-0x10]!
    // 0x6d24e4: stp             x11, x12, [SP, #-0x10]!
    // 0x6d24e8: stp             x9, x10, [SP, #-0x10]!
    // 0x6d24ec: stp             x7, x8, [SP, #-0x10]!
    // 0x6d24f0: stp             x5, x6, [SP, #-0x10]!
    // 0x6d24f4: stp             x3, x4, [SP, #-0x10]!
    // 0x6d24f8: stp             x1, x2, [SP, #-0x10]!
    // 0x6d24fc: SaveReg r0
    //     0x6d24fc: str             x0, [SP, #-8]!
    // 0x6d2500: r0 = AllocateDouble()
    //     0x6d2500: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6d2504: mov             x13, x0
    // 0x6d2508: RestoreReg r0
    //     0x6d2508: ldr             x0, [SP], #8
    // 0x6d250c: ldp             x1, x2, [SP], #0x10
    // 0x6d2510: ldp             x3, x4, [SP], #0x10
    // 0x6d2514: ldp             x5, x6, [SP], #0x10
    // 0x6d2518: ldp             x7, x8, [SP], #0x10
    // 0x6d251c: ldp             x9, x10, [SP], #0x10
    // 0x6d2520: ldp             x11, x12, [SP], #0x10
    // 0x6d2524: RestoreReg d2
    //     0x6d2524: ldr             q2, [SP], #0x10
    // 0x6d2528: b               #0x6d2330
  }
  _ toStringShort(/* No info */) {
    // ** addr: 0xa77e1c, size: 0xc
    // 0xa77e1c: r0 = "TextStyle"
    //     0xa77e1c: add             x0, PP, #0xd, lsl #12  ; [pp+0xde70] "TextStyle"
    //     0xa77e20: ldr             x0, [x0, #0xe70]
    // 0xa77e24: ret
    //     0xa77e24: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xaeb46c, size: 0x112c
    // 0xaeb46c: EnterFrame
    //     0xaeb46c: stp             fp, lr, [SP, #-0x10]!
    //     0xaeb470: mov             fp, SP
    // 0xaeb474: AllocStack(0xc0)
    //     0xaeb474: sub             SP, SP, #0xc0
    // 0xaeb478: CheckStackOverflow
    //     0xaeb478: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaeb47c: cmp             SP, x16
    //     0xaeb480: b.ls            #0xaec57c
    // 0xaeb484: ldr             x0, [fp, #0x20]
    // 0xaeb488: cmp             w0, NULL
    // 0xaeb48c: b.ne            #0xaeb4ac
    // 0xaeb490: ldr             x1, [fp, #0x18]
    // 0xaeb494: cmp             w1, NULL
    // 0xaeb498: b.ne            #0xaeb4b0
    // 0xaeb49c: r0 = Null
    //     0xaeb49c: mov             x0, NULL
    // 0xaeb4a0: LeaveFrame
    //     0xaeb4a0: mov             SP, fp
    //     0xaeb4a4: ldp             fp, lr, [SP], #0x10
    // 0xaeb4a8: ret
    //     0xaeb4a8: ret             
    // 0xaeb4ac: ldr             x1, [fp, #0x18]
    // 0xaeb4b0: cmp             w0, NULL
    // 0xaeb4b4: b.ne            #0xaeb868
    // 0xaeb4b8: ldr             x0, [fp, #0x10]
    // 0xaeb4bc: cmp             w1, NULL
    // 0xaeb4c0: b.eq            #0xaec584
    // 0xaeb4c4: LoadField: r2 = r1->field_7
    //     0xaeb4c4: ldur            w2, [x1, #7]
    // 0xaeb4c8: DecompressPointer r2
    //     0xaeb4c8: add             x2, x2, HEAP, lsl #32
    // 0xaeb4cc: stur            x2, [fp, #-8]
    // 0xaeb4d0: LoadField: r3 = r1->field_b
    //     0xaeb4d0: ldur            w3, [x1, #0xb]
    // 0xaeb4d4: DecompressPointer r3
    //     0xaeb4d4: add             x3, x3, HEAP, lsl #32
    // 0xaeb4d8: stp             x3, NULL, [SP, #-0x10]!
    // 0xaeb4dc: SaveReg r0
    //     0xaeb4dc: str             x0, [SP, #-8]!
    // 0xaeb4e0: r0 = lerp()
    //     0xaeb4e0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaeb4e4: add             SP, SP, #0x18
    // 0xaeb4e8: mov             x1, x0
    // 0xaeb4ec: ldr             x0, [fp, #0x18]
    // 0xaeb4f0: stur            x1, [fp, #-0x10]
    // 0xaeb4f4: LoadField: r2 = r0->field_f
    //     0xaeb4f4: ldur            w2, [x0, #0xf]
    // 0xaeb4f8: DecompressPointer r2
    //     0xaeb4f8: add             x2, x2, HEAP, lsl #32
    // 0xaeb4fc: stp             x2, NULL, [SP, #-0x10]!
    // 0xaeb500: ldr             x16, [fp, #0x10]
    // 0xaeb504: SaveReg r16
    //     0xaeb504: str             x16, [SP, #-8]!
    // 0xaeb508: r0 = lerp()
    //     0xaeb508: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaeb50c: add             SP, SP, #0x18
    // 0xaeb510: mov             x1, x0
    // 0xaeb514: ldr             x0, [fp, #0x10]
    // 0xaeb518: stur            x1, [fp, #-0x28]
    // 0xaeb51c: LoadField: d0 = r0->field_7
    //     0xaeb51c: ldur            d0, [x0, #7]
    // 0xaeb520: d1 = 0.500000
    //     0xaeb520: fmov            d1, #0.50000000
    // 0xaeb524: fcmp            d0, d1
    // 0xaeb528: b.vs            #0xaeb530
    // 0xaeb52c: b.lt            #0xaeb538
    // 0xaeb530: r2 = false
    //     0xaeb530: add             x2, NULL, #0x30  ; false
    // 0xaeb534: b               #0xaeb53c
    // 0xaeb538: r2 = true
    //     0xaeb538: add             x2, NULL, #0x20  ; true
    // 0xaeb53c: stur            x2, [fp, #-0x20]
    // 0xaeb540: tbnz            w2, #4, #0xaeb550
    // 0xaeb544: ldr             x3, [fp, #0x18]
    // 0xaeb548: r4 = Null
    //     0xaeb548: mov             x4, NULL
    // 0xaeb54c: b               #0xaeb55c
    // 0xaeb550: ldr             x3, [fp, #0x18]
    // 0xaeb554: LoadField: r4 = r3->field_1f
    //     0xaeb554: ldur            w4, [x3, #0x1f]
    // 0xaeb558: DecompressPointer r4
    //     0xaeb558: add             x4, x4, HEAP, lsl #32
    // 0xaeb55c: stur            x4, [fp, #-0x18]
    // 0xaeb560: LoadField: r5 = r3->field_23
    //     0xaeb560: ldur            w5, [x3, #0x23]
    // 0xaeb564: DecompressPointer r5
    //     0xaeb564: add             x5, x5, HEAP, lsl #32
    // 0xaeb568: stp             x5, NULL, [SP, #-0x10]!
    // 0xaeb56c: SaveReg d0
    //     0xaeb56c: str             d0, [SP, #-8]!
    // 0xaeb570: r0 = lerp()
    //     0xaeb570: bl              #0xaec5dc  ; [dart:ui] FontWeight::lerp
    // 0xaeb574: add             SP, SP, #0x18
    // 0xaeb578: mov             x1, x0
    // 0xaeb57c: ldur            x0, [fp, #-0x20]
    // 0xaeb580: stur            x1, [fp, #-0x90]
    // 0xaeb584: tbnz            w0, #4, #0xaeb594
    // 0xaeb588: ldr             x2, [fp, #0x18]
    // 0xaeb58c: r3 = Null
    //     0xaeb58c: mov             x3, NULL
    // 0xaeb590: b               #0xaeb5a0
    // 0xaeb594: ldr             x2, [fp, #0x18]
    // 0xaeb598: LoadField: r3 = r2->field_27
    //     0xaeb598: ldur            w3, [x2, #0x27]
    // 0xaeb59c: DecompressPointer r3
    //     0xaeb59c: add             x3, x3, HEAP, lsl #32
    // 0xaeb5a0: stur            x3, [fp, #-0x88]
    // 0xaeb5a4: tbnz            w0, #4, #0xaeb5b0
    // 0xaeb5a8: r4 = Null
    //     0xaeb5a8: mov             x4, NULL
    // 0xaeb5ac: b               #0xaeb5b8
    // 0xaeb5b0: LoadField: r4 = r2->field_2b
    //     0xaeb5b0: ldur            w4, [x2, #0x2b]
    // 0xaeb5b4: DecompressPointer r4
    //     0xaeb5b4: add             x4, x4, HEAP, lsl #32
    // 0xaeb5b8: stur            x4, [fp, #-0x80]
    // 0xaeb5bc: tbnz            w0, #4, #0xaeb5c8
    // 0xaeb5c0: r5 = Null
    //     0xaeb5c0: mov             x5, NULL
    // 0xaeb5c4: b               #0xaeb5d0
    // 0xaeb5c8: LoadField: r5 = r2->field_2f
    //     0xaeb5c8: ldur            w5, [x2, #0x2f]
    // 0xaeb5cc: DecompressPointer r5
    //     0xaeb5cc: add             x5, x5, HEAP, lsl #32
    // 0xaeb5d0: stur            x5, [fp, #-0x78]
    // 0xaeb5d4: tbnz            w0, #4, #0xaeb5e0
    // 0xaeb5d8: r6 = Null
    //     0xaeb5d8: mov             x6, NULL
    // 0xaeb5dc: b               #0xaeb5e8
    // 0xaeb5e0: LoadField: r6 = r2->field_33
    //     0xaeb5e0: ldur            w6, [x2, #0x33]
    // 0xaeb5e4: DecompressPointer r6
    //     0xaeb5e4: add             x6, x6, HEAP, lsl #32
    // 0xaeb5e8: stur            x6, [fp, #-0x70]
    // 0xaeb5ec: tbnz            w0, #4, #0xaeb5f8
    // 0xaeb5f0: r7 = Null
    //     0xaeb5f0: mov             x7, NULL
    // 0xaeb5f4: b               #0xaeb600
    // 0xaeb5f8: LoadField: r7 = r2->field_37
    //     0xaeb5f8: ldur            w7, [x2, #0x37]
    // 0xaeb5fc: DecompressPointer r7
    //     0xaeb5fc: add             x7, x7, HEAP, lsl #32
    // 0xaeb600: stur            x7, [fp, #-0x68]
    // 0xaeb604: tbnz            w0, #4, #0xaeb610
    // 0xaeb608: r8 = Null
    //     0xaeb608: mov             x8, NULL
    // 0xaeb60c: b               #0xaeb618
    // 0xaeb610: LoadField: r8 = r2->field_3b
    //     0xaeb610: ldur            w8, [x2, #0x3b]
    // 0xaeb614: DecompressPointer r8
    //     0xaeb614: add             x8, x8, HEAP, lsl #32
    // 0xaeb618: stur            x8, [fp, #-0x60]
    // 0xaeb61c: tbnz            w0, #4, #0xaeb628
    // 0xaeb620: r9 = Null
    //     0xaeb620: mov             x9, NULL
    // 0xaeb624: b               #0xaeb630
    // 0xaeb628: LoadField: r9 = r2->field_43
    //     0xaeb628: ldur            w9, [x2, #0x43]
    // 0xaeb62c: DecompressPointer r9
    //     0xaeb62c: add             x9, x9, HEAP, lsl #32
    // 0xaeb630: stur            x9, [fp, #-0x58]
    // 0xaeb634: tbnz            w0, #4, #0xaeb640
    // 0xaeb638: r10 = Null
    //     0xaeb638: mov             x10, NULL
    // 0xaeb63c: b               #0xaeb648
    // 0xaeb640: LoadField: r10 = r2->field_47
    //     0xaeb640: ldur            w10, [x2, #0x47]
    // 0xaeb644: DecompressPointer r10
    //     0xaeb644: add             x10, x10, HEAP, lsl #32
    // 0xaeb648: stur            x10, [fp, #-0x50]
    // 0xaeb64c: tbnz            w0, #4, #0xaeb658
    // 0xaeb650: r11 = Null
    //     0xaeb650: mov             x11, NULL
    // 0xaeb654: b               #0xaeb660
    // 0xaeb658: LoadField: r11 = r2->field_5f
    //     0xaeb658: ldur            w11, [x2, #0x5f]
    // 0xaeb65c: DecompressPointer r11
    //     0xaeb65c: add             x11, x11, HEAP, lsl #32
    // 0xaeb660: stur            x11, [fp, #-0x48]
    // 0xaeb664: tbnz            w0, #4, #0xaeb670
    // 0xaeb668: r12 = Null
    //     0xaeb668: mov             x12, NULL
    // 0xaeb66c: b               #0xaeb678
    // 0xaeb670: LoadField: r12 = r2->field_63
    //     0xaeb670: ldur            w12, [x2, #0x63]
    // 0xaeb674: DecompressPointer r12
    //     0xaeb674: add             x12, x12, HEAP, lsl #32
    // 0xaeb678: stur            x12, [fp, #-0x40]
    // 0xaeb67c: tbnz            w0, #4, #0xaeb688
    // 0xaeb680: r13 = Null
    //     0xaeb680: mov             x13, NULL
    // 0xaeb684: b               #0xaeb690
    // 0xaeb688: LoadField: r13 = r2->field_67
    //     0xaeb688: ldur            w13, [x2, #0x67]
    // 0xaeb68c: DecompressPointer r13
    //     0xaeb68c: add             x13, x13, HEAP, lsl #32
    // 0xaeb690: stur            x13, [fp, #-0x38]
    // 0xaeb694: tbnz            w0, #4, #0xaeb6a0
    // 0xaeb698: r14 = Null
    //     0xaeb698: mov             x14, NULL
    // 0xaeb69c: b               #0xaeb6a8
    // 0xaeb6a0: LoadField: r14 = r2->field_4b
    //     0xaeb6a0: ldur            w14, [x2, #0x4b]
    // 0xaeb6a4: DecompressPointer r14
    //     0xaeb6a4: add             x14, x14, HEAP, lsl #32
    // 0xaeb6a8: stur            x14, [fp, #-0x30]
    // 0xaeb6ac: LoadField: r19 = r2->field_4f
    //     0xaeb6ac: ldur            w19, [x2, #0x4f]
    // 0xaeb6b0: DecompressPointer r19
    //     0xaeb6b0: add             x19, x19, HEAP, lsl #32
    // 0xaeb6b4: stp             x19, NULL, [SP, #-0x10]!
    // 0xaeb6b8: ldr             x16, [fp, #0x10]
    // 0xaeb6bc: SaveReg r16
    //     0xaeb6bc: str             x16, [SP, #-8]!
    // 0xaeb6c0: r0 = lerp()
    //     0xaeb6c0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaeb6c4: add             SP, SP, #0x18
    // 0xaeb6c8: mov             x1, x0
    // 0xaeb6cc: ldur            x0, [fp, #-0x20]
    // 0xaeb6d0: stur            x1, [fp, #-0xb8]
    // 0xaeb6d4: tbnz            w0, #4, #0xaeb6e4
    // 0xaeb6d8: ldr             x2, [fp, #0x18]
    // 0xaeb6dc: r3 = Null
    //     0xaeb6dc: mov             x3, NULL
    // 0xaeb6e0: b               #0xaeb6f0
    // 0xaeb6e4: ldr             x2, [fp, #0x18]
    // 0xaeb6e8: LoadField: r3 = r2->field_53
    //     0xaeb6e8: ldur            w3, [x2, #0x53]
    // 0xaeb6ec: DecompressPointer r3
    //     0xaeb6ec: add             x3, x3, HEAP, lsl #32
    // 0xaeb6f0: stur            x3, [fp, #-0xb0]
    // 0xaeb6f4: tbnz            w0, #4, #0xaeb700
    // 0xaeb6f8: r4 = Null
    //     0xaeb6f8: mov             x4, NULL
    // 0xaeb6fc: b               #0xaeb708
    // 0xaeb700: LoadField: r4 = r2->field_57
    //     0xaeb700: ldur            w4, [x2, #0x57]
    // 0xaeb704: DecompressPointer r4
    //     0xaeb704: add             x4, x4, HEAP, lsl #32
    // 0xaeb708: stur            x4, [fp, #-0xa8]
    // 0xaeb70c: tbnz            w0, #4, #0xaeb718
    // 0xaeb710: r5 = Null
    //     0xaeb710: mov             x5, NULL
    // 0xaeb714: b               #0xaeb720
    // 0xaeb718: LoadField: r5 = r2->field_13
    //     0xaeb718: ldur            w5, [x2, #0x13]
    // 0xaeb71c: DecompressPointer r5
    //     0xaeb71c: add             x5, x5, HEAP, lsl #32
    // 0xaeb720: stur            x5, [fp, #-0xa0]
    // 0xaeb724: tbnz            w0, #4, #0xaeb730
    // 0xaeb728: r6 = Null
    //     0xaeb728: mov             x6, NULL
    // 0xaeb72c: b               #0xaeb738
    // 0xaeb730: LoadField: r6 = r2->field_17
    //     0xaeb730: ldur            w6, [x2, #0x17]
    // 0xaeb734: DecompressPointer r6
    //     0xaeb734: add             x6, x6, HEAP, lsl #32
    // 0xaeb738: stur            x6, [fp, #-0x98]
    // 0xaeb73c: tbnz            w0, #4, #0xaeb750
    // 0xaeb740: SaveReg r0
    //     0xaeb740: str             x0, [SP, #-8]!
    // 0xaeb744: stur            NULL, [fp, #-0x20]
    // 0xaeb748: RestoreReg r0
    //     0xaeb748: ldr             x0, [SP], #8
    // 0xaeb74c: b               #0xaeb75c
    // 0xaeb750: LoadField: r0 = r2->field_6b
    //     0xaeb750: ldur            w0, [x2, #0x6b]
    // 0xaeb754: DecompressPointer r0
    //     0xaeb754: add             x0, x0, HEAP, lsl #32
    // 0xaeb758: stur            x0, [fp, #-0x20]
    // 0xaeb75c: ldur            x24, [fp, #-0x28]
    // 0xaeb760: ldur            x25, [fp, #-0x18]
    // 0xaeb764: ldur            x0, [fp, #-0x90]
    // 0xaeb768: ldur            x2, [fp, #-0x88]
    // 0xaeb76c: ldur            x7, [fp, #-0x80]
    // 0xaeb770: ldur            x8, [fp, #-0x78]
    // 0xaeb774: ldur            x9, [fp, #-0x70]
    // 0xaeb778: ldur            x10, [fp, #-0x68]
    // 0xaeb77c: ldur            x11, [fp, #-0x60]
    // 0xaeb780: ldur            x12, [fp, #-0x58]
    // 0xaeb784: ldur            x13, [fp, #-0x50]
    // 0xaeb788: ldur            x14, [fp, #-0x48]
    // 0xaeb78c: ldur            x19, [fp, #-0x40]
    // 0xaeb790: ldur            x20, [fp, #-0x38]
    // 0xaeb794: ldur            x23, [fp, #-0x30]
    // 0xaeb798: r0 = TextStyle()
    //     0xaeb798: bl              #0x6cecec  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xaeb79c: mov             x1, x0
    // 0xaeb7a0: ldur            x0, [fp, #-8]
    // 0xaeb7a4: StoreField: r1->field_7 = r0
    //     0xaeb7a4: stur            w0, [x1, #7]
    // 0xaeb7a8: ldur            x0, [fp, #-0x10]
    // 0xaeb7ac: StoreField: r1->field_b = r0
    //     0xaeb7ac: stur            w0, [x1, #0xb]
    // 0xaeb7b0: ldur            x0, [fp, #-0x28]
    // 0xaeb7b4: StoreField: r1->field_f = r0
    //     0xaeb7b4: stur            w0, [x1, #0xf]
    // 0xaeb7b8: ldur            x0, [fp, #-0x18]
    // 0xaeb7bc: StoreField: r1->field_1f = r0
    //     0xaeb7bc: stur            w0, [x1, #0x1f]
    // 0xaeb7c0: ldur            x0, [fp, #-0x90]
    // 0xaeb7c4: StoreField: r1->field_23 = r0
    //     0xaeb7c4: stur            w0, [x1, #0x23]
    // 0xaeb7c8: ldur            x0, [fp, #-0x88]
    // 0xaeb7cc: StoreField: r1->field_27 = r0
    //     0xaeb7cc: stur            w0, [x1, #0x27]
    // 0xaeb7d0: ldur            x0, [fp, #-0x80]
    // 0xaeb7d4: StoreField: r1->field_2b = r0
    //     0xaeb7d4: stur            w0, [x1, #0x2b]
    // 0xaeb7d8: ldur            x0, [fp, #-0x78]
    // 0xaeb7dc: StoreField: r1->field_2f = r0
    //     0xaeb7dc: stur            w0, [x1, #0x2f]
    // 0xaeb7e0: ldur            x0, [fp, #-0x70]
    // 0xaeb7e4: StoreField: r1->field_33 = r0
    //     0xaeb7e4: stur            w0, [x1, #0x33]
    // 0xaeb7e8: ldur            x0, [fp, #-0x68]
    // 0xaeb7ec: StoreField: r1->field_37 = r0
    //     0xaeb7ec: stur            w0, [x1, #0x37]
    // 0xaeb7f0: ldur            x0, [fp, #-0x60]
    // 0xaeb7f4: StoreField: r1->field_3b = r0
    //     0xaeb7f4: stur            w0, [x1, #0x3b]
    // 0xaeb7f8: ldur            x0, [fp, #-0x58]
    // 0xaeb7fc: StoreField: r1->field_43 = r0
    //     0xaeb7fc: stur            w0, [x1, #0x43]
    // 0xaeb800: ldur            x0, [fp, #-0x50]
    // 0xaeb804: StoreField: r1->field_47 = r0
    //     0xaeb804: stur            w0, [x1, #0x47]
    // 0xaeb808: ldur            x0, [fp, #-0x48]
    // 0xaeb80c: StoreField: r1->field_5f = r0
    //     0xaeb80c: stur            w0, [x1, #0x5f]
    // 0xaeb810: ldur            x0, [fp, #-0x40]
    // 0xaeb814: StoreField: r1->field_63 = r0
    //     0xaeb814: stur            w0, [x1, #0x63]
    // 0xaeb818: ldur            x0, [fp, #-0x38]
    // 0xaeb81c: StoreField: r1->field_67 = r0
    //     0xaeb81c: stur            w0, [x1, #0x67]
    // 0xaeb820: ldur            x0, [fp, #-0x30]
    // 0xaeb824: StoreField: r1->field_4b = r0
    //     0xaeb824: stur            w0, [x1, #0x4b]
    // 0xaeb828: ldur            x0, [fp, #-0xb8]
    // 0xaeb82c: StoreField: r1->field_4f = r0
    //     0xaeb82c: stur            w0, [x1, #0x4f]
    // 0xaeb830: ldur            x0, [fp, #-0xb0]
    // 0xaeb834: StoreField: r1->field_53 = r0
    //     0xaeb834: stur            w0, [x1, #0x53]
    // 0xaeb838: ldur            x0, [fp, #-0xa8]
    // 0xaeb83c: StoreField: r1->field_57 = r0
    //     0xaeb83c: stur            w0, [x1, #0x57]
    // 0xaeb840: ldur            x0, [fp, #-0x20]
    // 0xaeb844: StoreField: r1->field_6b = r0
    //     0xaeb844: stur            w0, [x1, #0x6b]
    // 0xaeb848: ldur            x0, [fp, #-0xa0]
    // 0xaeb84c: StoreField: r1->field_13 = r0
    //     0xaeb84c: stur            w0, [x1, #0x13]
    // 0xaeb850: ldur            x0, [fp, #-0x98]
    // 0xaeb854: StoreField: r1->field_17 = r0
    //     0xaeb854: stur            w0, [x1, #0x17]
    // 0xaeb858: mov             x0, x1
    // 0xaeb85c: LeaveFrame
    //     0xaeb85c: mov             SP, fp
    //     0xaeb860: ldp             fp, lr, [SP], #0x10
    // 0xaeb864: ret
    //     0xaeb864: ret             
    // 0xaeb868: mov             x2, x1
    // 0xaeb86c: d1 = 0.500000
    //     0xaeb86c: fmov            d1, #0.50000000
    // 0xaeb870: cmp             w2, NULL
    // 0xaeb874: b.ne            #0xaebc20
    // 0xaeb878: ldr             x1, [fp, #0x10]
    // 0xaeb87c: LoadField: r2 = r0->field_7
    //     0xaeb87c: ldur            w2, [x0, #7]
    // 0xaeb880: DecompressPointer r2
    //     0xaeb880: add             x2, x2, HEAP, lsl #32
    // 0xaeb884: stur            x2, [fp, #-8]
    // 0xaeb888: LoadField: r3 = r0->field_b
    //     0xaeb888: ldur            w3, [x0, #0xb]
    // 0xaeb88c: DecompressPointer r3
    //     0xaeb88c: add             x3, x3, HEAP, lsl #32
    // 0xaeb890: stp             NULL, x3, [SP, #-0x10]!
    // 0xaeb894: SaveReg r1
    //     0xaeb894: str             x1, [SP, #-8]!
    // 0xaeb898: r0 = lerp()
    //     0xaeb898: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaeb89c: add             SP, SP, #0x18
    // 0xaeb8a0: mov             x1, x0
    // 0xaeb8a4: ldr             x0, [fp, #0x20]
    // 0xaeb8a8: stur            x1, [fp, #-0x10]
    // 0xaeb8ac: LoadField: r2 = r0->field_f
    //     0xaeb8ac: ldur            w2, [x0, #0xf]
    // 0xaeb8b0: DecompressPointer r2
    //     0xaeb8b0: add             x2, x2, HEAP, lsl #32
    // 0xaeb8b4: stp             x2, NULL, [SP, #-0x10]!
    // 0xaeb8b8: ldr             x16, [fp, #0x10]
    // 0xaeb8bc: SaveReg r16
    //     0xaeb8bc: str             x16, [SP, #-8]!
    // 0xaeb8c0: r0 = lerp()
    //     0xaeb8c0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaeb8c4: add             SP, SP, #0x18
    // 0xaeb8c8: mov             x1, x0
    // 0xaeb8cc: ldr             x0, [fp, #0x10]
    // 0xaeb8d0: stur            x1, [fp, #-0x28]
    // 0xaeb8d4: LoadField: d0 = r0->field_7
    //     0xaeb8d4: ldur            d0, [x0, #7]
    // 0xaeb8d8: d1 = 0.500000
    //     0xaeb8d8: fmov            d1, #0.50000000
    // 0xaeb8dc: fcmp            d0, d1
    // 0xaeb8e0: b.vs            #0xaeb8e8
    // 0xaeb8e4: b.lt            #0xaeb8f0
    // 0xaeb8e8: r2 = false
    //     0xaeb8e8: add             x2, NULL, #0x30  ; false
    // 0xaeb8ec: b               #0xaeb8f4
    // 0xaeb8f0: r2 = true
    //     0xaeb8f0: add             x2, NULL, #0x20  ; true
    // 0xaeb8f4: stur            x2, [fp, #-0x20]
    // 0xaeb8f8: tbnz            w2, #4, #0xaeb90c
    // 0xaeb8fc: ldr             x3, [fp, #0x20]
    // 0xaeb900: LoadField: r4 = r3->field_1f
    //     0xaeb900: ldur            w4, [x3, #0x1f]
    // 0xaeb904: DecompressPointer r4
    //     0xaeb904: add             x4, x4, HEAP, lsl #32
    // 0xaeb908: b               #0xaeb914
    // 0xaeb90c: ldr             x3, [fp, #0x20]
    // 0xaeb910: r4 = Null
    //     0xaeb910: mov             x4, NULL
    // 0xaeb914: stur            x4, [fp, #-0x18]
    // 0xaeb918: LoadField: r5 = r3->field_23
    //     0xaeb918: ldur            w5, [x3, #0x23]
    // 0xaeb91c: DecompressPointer r5
    //     0xaeb91c: add             x5, x5, HEAP, lsl #32
    // 0xaeb920: stp             NULL, x5, [SP, #-0x10]!
    // 0xaeb924: SaveReg d0
    //     0xaeb924: str             d0, [SP, #-8]!
    // 0xaeb928: r0 = lerp()
    //     0xaeb928: bl              #0xaec5dc  ; [dart:ui] FontWeight::lerp
    // 0xaeb92c: add             SP, SP, #0x18
    // 0xaeb930: mov             x1, x0
    // 0xaeb934: ldur            x0, [fp, #-0x20]
    // 0xaeb938: stur            x1, [fp, #-0x90]
    // 0xaeb93c: tbnz            w0, #4, #0xaeb950
    // 0xaeb940: ldr             x2, [fp, #0x20]
    // 0xaeb944: LoadField: r3 = r2->field_27
    //     0xaeb944: ldur            w3, [x2, #0x27]
    // 0xaeb948: DecompressPointer r3
    //     0xaeb948: add             x3, x3, HEAP, lsl #32
    // 0xaeb94c: b               #0xaeb958
    // 0xaeb950: ldr             x2, [fp, #0x20]
    // 0xaeb954: r3 = Null
    //     0xaeb954: mov             x3, NULL
    // 0xaeb958: stur            x3, [fp, #-0x88]
    // 0xaeb95c: tbnz            w0, #4, #0xaeb96c
    // 0xaeb960: LoadField: r4 = r2->field_2b
    //     0xaeb960: ldur            w4, [x2, #0x2b]
    // 0xaeb964: DecompressPointer r4
    //     0xaeb964: add             x4, x4, HEAP, lsl #32
    // 0xaeb968: b               #0xaeb970
    // 0xaeb96c: r4 = Null
    //     0xaeb96c: mov             x4, NULL
    // 0xaeb970: stur            x4, [fp, #-0x80]
    // 0xaeb974: tbnz            w0, #4, #0xaeb984
    // 0xaeb978: LoadField: r5 = r2->field_2f
    //     0xaeb978: ldur            w5, [x2, #0x2f]
    // 0xaeb97c: DecompressPointer r5
    //     0xaeb97c: add             x5, x5, HEAP, lsl #32
    // 0xaeb980: b               #0xaeb988
    // 0xaeb984: r5 = Null
    //     0xaeb984: mov             x5, NULL
    // 0xaeb988: stur            x5, [fp, #-0x78]
    // 0xaeb98c: tbnz            w0, #4, #0xaeb99c
    // 0xaeb990: LoadField: r6 = r2->field_33
    //     0xaeb990: ldur            w6, [x2, #0x33]
    // 0xaeb994: DecompressPointer r6
    //     0xaeb994: add             x6, x6, HEAP, lsl #32
    // 0xaeb998: b               #0xaeb9a0
    // 0xaeb99c: r6 = Null
    //     0xaeb99c: mov             x6, NULL
    // 0xaeb9a0: stur            x6, [fp, #-0x70]
    // 0xaeb9a4: tbnz            w0, #4, #0xaeb9b4
    // 0xaeb9a8: LoadField: r7 = r2->field_37
    //     0xaeb9a8: ldur            w7, [x2, #0x37]
    // 0xaeb9ac: DecompressPointer r7
    //     0xaeb9ac: add             x7, x7, HEAP, lsl #32
    // 0xaeb9b0: b               #0xaeb9b8
    // 0xaeb9b4: r7 = Null
    //     0xaeb9b4: mov             x7, NULL
    // 0xaeb9b8: stur            x7, [fp, #-0x68]
    // 0xaeb9bc: tbnz            w0, #4, #0xaeb9cc
    // 0xaeb9c0: LoadField: r8 = r2->field_3b
    //     0xaeb9c0: ldur            w8, [x2, #0x3b]
    // 0xaeb9c4: DecompressPointer r8
    //     0xaeb9c4: add             x8, x8, HEAP, lsl #32
    // 0xaeb9c8: b               #0xaeb9d0
    // 0xaeb9cc: r8 = Null
    //     0xaeb9cc: mov             x8, NULL
    // 0xaeb9d0: stur            x8, [fp, #-0x60]
    // 0xaeb9d4: tbnz            w0, #4, #0xaeb9e4
    // 0xaeb9d8: LoadField: r9 = r2->field_43
    //     0xaeb9d8: ldur            w9, [x2, #0x43]
    // 0xaeb9dc: DecompressPointer r9
    //     0xaeb9dc: add             x9, x9, HEAP, lsl #32
    // 0xaeb9e0: b               #0xaeb9e8
    // 0xaeb9e4: r9 = Null
    //     0xaeb9e4: mov             x9, NULL
    // 0xaeb9e8: stur            x9, [fp, #-0x58]
    // 0xaeb9ec: tbnz            w0, #4, #0xaeb9fc
    // 0xaeb9f0: LoadField: r10 = r2->field_47
    //     0xaeb9f0: ldur            w10, [x2, #0x47]
    // 0xaeb9f4: DecompressPointer r10
    //     0xaeb9f4: add             x10, x10, HEAP, lsl #32
    // 0xaeb9f8: b               #0xaeba00
    // 0xaeb9fc: r10 = Null
    //     0xaeb9fc: mov             x10, NULL
    // 0xaeba00: stur            x10, [fp, #-0x50]
    // 0xaeba04: tbnz            w0, #4, #0xaeba14
    // 0xaeba08: LoadField: r11 = r2->field_5f
    //     0xaeba08: ldur            w11, [x2, #0x5f]
    // 0xaeba0c: DecompressPointer r11
    //     0xaeba0c: add             x11, x11, HEAP, lsl #32
    // 0xaeba10: b               #0xaeba18
    // 0xaeba14: r11 = Null
    //     0xaeba14: mov             x11, NULL
    // 0xaeba18: stur            x11, [fp, #-0x48]
    // 0xaeba1c: tbnz            w0, #4, #0xaeba2c
    // 0xaeba20: LoadField: r12 = r2->field_63
    //     0xaeba20: ldur            w12, [x2, #0x63]
    // 0xaeba24: DecompressPointer r12
    //     0xaeba24: add             x12, x12, HEAP, lsl #32
    // 0xaeba28: b               #0xaeba30
    // 0xaeba2c: r12 = Null
    //     0xaeba2c: mov             x12, NULL
    // 0xaeba30: stur            x12, [fp, #-0x40]
    // 0xaeba34: tbnz            w0, #4, #0xaeba44
    // 0xaeba38: LoadField: r13 = r2->field_67
    //     0xaeba38: ldur            w13, [x2, #0x67]
    // 0xaeba3c: DecompressPointer r13
    //     0xaeba3c: add             x13, x13, HEAP, lsl #32
    // 0xaeba40: b               #0xaeba48
    // 0xaeba44: r13 = Null
    //     0xaeba44: mov             x13, NULL
    // 0xaeba48: stur            x13, [fp, #-0x38]
    // 0xaeba4c: tbnz            w0, #4, #0xaeba5c
    // 0xaeba50: LoadField: r14 = r2->field_4b
    //     0xaeba50: ldur            w14, [x2, #0x4b]
    // 0xaeba54: DecompressPointer r14
    //     0xaeba54: add             x14, x14, HEAP, lsl #32
    // 0xaeba58: b               #0xaeba60
    // 0xaeba5c: r14 = Null
    //     0xaeba5c: mov             x14, NULL
    // 0xaeba60: stur            x14, [fp, #-0x30]
    // 0xaeba64: LoadField: r19 = r2->field_4f
    //     0xaeba64: ldur            w19, [x2, #0x4f]
    // 0xaeba68: DecompressPointer r19
    //     0xaeba68: add             x19, x19, HEAP, lsl #32
    // 0xaeba6c: stp             NULL, x19, [SP, #-0x10]!
    // 0xaeba70: ldr             x16, [fp, #0x10]
    // 0xaeba74: SaveReg r16
    //     0xaeba74: str             x16, [SP, #-8]!
    // 0xaeba78: r0 = lerp()
    //     0xaeba78: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaeba7c: add             SP, SP, #0x18
    // 0xaeba80: mov             x1, x0
    // 0xaeba84: ldur            x0, [fp, #-0x20]
    // 0xaeba88: stur            x1, [fp, #-0xb8]
    // 0xaeba8c: tbnz            w0, #4, #0xaebaa0
    // 0xaeba90: ldr             x3, [fp, #0x20]
    // 0xaeba94: LoadField: r2 = r3->field_53
    //     0xaeba94: ldur            w2, [x3, #0x53]
    // 0xaeba98: DecompressPointer r2
    //     0xaeba98: add             x2, x2, HEAP, lsl #32
    // 0xaeba9c: b               #0xaebaa8
    // 0xaebaa0: ldr             x3, [fp, #0x20]
    // 0xaebaa4: r2 = Null
    //     0xaebaa4: mov             x2, NULL
    // 0xaebaa8: stur            x2, [fp, #-0xb0]
    // 0xaebaac: tbnz            w0, #4, #0xaebabc
    // 0xaebab0: LoadField: r4 = r3->field_57
    //     0xaebab0: ldur            w4, [x3, #0x57]
    // 0xaebab4: DecompressPointer r4
    //     0xaebab4: add             x4, x4, HEAP, lsl #32
    // 0xaebab8: b               #0xaebac0
    // 0xaebabc: r4 = Null
    //     0xaebabc: mov             x4, NULL
    // 0xaebac0: stur            x4, [fp, #-0xa8]
    // 0xaebac4: tbnz            w0, #4, #0xaebad4
    // 0xaebac8: LoadField: r5 = r3->field_13
    //     0xaebac8: ldur            w5, [x3, #0x13]
    // 0xaebacc: DecompressPointer r5
    //     0xaebacc: add             x5, x5, HEAP, lsl #32
    // 0xaebad0: b               #0xaebad8
    // 0xaebad4: r5 = Null
    //     0xaebad4: mov             x5, NULL
    // 0xaebad8: stur            x5, [fp, #-0xa0]
    // 0xaebadc: tbnz            w0, #4, #0xaebaec
    // 0xaebae0: LoadField: r6 = r3->field_17
    //     0xaebae0: ldur            w6, [x3, #0x17]
    // 0xaebae4: DecompressPointer r6
    //     0xaebae4: add             x6, x6, HEAP, lsl #32
    // 0xaebae8: b               #0xaebaf0
    // 0xaebaec: r6 = Null
    //     0xaebaec: mov             x6, NULL
    // 0xaebaf0: stur            x6, [fp, #-0x98]
    // 0xaebaf4: tbnz            w0, #4, #0xaebb08
    // 0xaebaf8: LoadField: r0 = r3->field_6b
    //     0xaebaf8: ldur            w0, [x3, #0x6b]
    // 0xaebafc: DecompressPointer r0
    //     0xaebafc: add             x0, x0, HEAP, lsl #32
    // 0xaebb00: stur            x0, [fp, #-0x20]
    // 0xaebb04: b               #0xaebb14
    // 0xaebb08: SaveReg r0
    //     0xaebb08: str             x0, [SP, #-8]!
    // 0xaebb0c: stur            NULL, [fp, #-0x20]
    // 0xaebb10: RestoreReg r0
    //     0xaebb10: ldr             x0, [SP], #8
    // 0xaebb14: ldur            x24, [fp, #-0x28]
    // 0xaebb18: ldur            x25, [fp, #-0x18]
    // 0xaebb1c: ldur            x0, [fp, #-0x90]
    // 0xaebb20: ldur            x3, [fp, #-0x88]
    // 0xaebb24: ldur            x7, [fp, #-0x80]
    // 0xaebb28: ldur            x8, [fp, #-0x78]
    // 0xaebb2c: ldur            x9, [fp, #-0x70]
    // 0xaebb30: ldur            x10, [fp, #-0x68]
    // 0xaebb34: ldur            x11, [fp, #-0x60]
    // 0xaebb38: ldur            x12, [fp, #-0x58]
    // 0xaebb3c: ldur            x13, [fp, #-0x50]
    // 0xaebb40: ldur            x14, [fp, #-0x48]
    // 0xaebb44: ldur            x19, [fp, #-0x40]
    // 0xaebb48: ldur            x20, [fp, #-0x38]
    // 0xaebb4c: ldur            x23, [fp, #-0x30]
    // 0xaebb50: r0 = TextStyle()
    //     0xaebb50: bl              #0x6cecec  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xaebb54: mov             x1, x0
    // 0xaebb58: ldur            x0, [fp, #-8]
    // 0xaebb5c: StoreField: r1->field_7 = r0
    //     0xaebb5c: stur            w0, [x1, #7]
    // 0xaebb60: ldur            x0, [fp, #-0x10]
    // 0xaebb64: StoreField: r1->field_b = r0
    //     0xaebb64: stur            w0, [x1, #0xb]
    // 0xaebb68: ldur            x0, [fp, #-0x28]
    // 0xaebb6c: StoreField: r1->field_f = r0
    //     0xaebb6c: stur            w0, [x1, #0xf]
    // 0xaebb70: ldur            x0, [fp, #-0x18]
    // 0xaebb74: StoreField: r1->field_1f = r0
    //     0xaebb74: stur            w0, [x1, #0x1f]
    // 0xaebb78: ldur            x0, [fp, #-0x90]
    // 0xaebb7c: StoreField: r1->field_23 = r0
    //     0xaebb7c: stur            w0, [x1, #0x23]
    // 0xaebb80: ldur            x0, [fp, #-0x88]
    // 0xaebb84: StoreField: r1->field_27 = r0
    //     0xaebb84: stur            w0, [x1, #0x27]
    // 0xaebb88: ldur            x0, [fp, #-0x80]
    // 0xaebb8c: StoreField: r1->field_2b = r0
    //     0xaebb8c: stur            w0, [x1, #0x2b]
    // 0xaebb90: ldur            x0, [fp, #-0x78]
    // 0xaebb94: StoreField: r1->field_2f = r0
    //     0xaebb94: stur            w0, [x1, #0x2f]
    // 0xaebb98: ldur            x0, [fp, #-0x70]
    // 0xaebb9c: StoreField: r1->field_33 = r0
    //     0xaebb9c: stur            w0, [x1, #0x33]
    // 0xaebba0: ldur            x0, [fp, #-0x68]
    // 0xaebba4: StoreField: r1->field_37 = r0
    //     0xaebba4: stur            w0, [x1, #0x37]
    // 0xaebba8: ldur            x0, [fp, #-0x60]
    // 0xaebbac: StoreField: r1->field_3b = r0
    //     0xaebbac: stur            w0, [x1, #0x3b]
    // 0xaebbb0: ldur            x0, [fp, #-0x58]
    // 0xaebbb4: StoreField: r1->field_43 = r0
    //     0xaebbb4: stur            w0, [x1, #0x43]
    // 0xaebbb8: ldur            x0, [fp, #-0x50]
    // 0xaebbbc: StoreField: r1->field_47 = r0
    //     0xaebbbc: stur            w0, [x1, #0x47]
    // 0xaebbc0: ldur            x0, [fp, #-0x48]
    // 0xaebbc4: StoreField: r1->field_5f = r0
    //     0xaebbc4: stur            w0, [x1, #0x5f]
    // 0xaebbc8: ldur            x0, [fp, #-0x40]
    // 0xaebbcc: StoreField: r1->field_63 = r0
    //     0xaebbcc: stur            w0, [x1, #0x63]
    // 0xaebbd0: ldur            x0, [fp, #-0x38]
    // 0xaebbd4: StoreField: r1->field_67 = r0
    //     0xaebbd4: stur            w0, [x1, #0x67]
    // 0xaebbd8: ldur            x0, [fp, #-0x30]
    // 0xaebbdc: StoreField: r1->field_4b = r0
    //     0xaebbdc: stur            w0, [x1, #0x4b]
    // 0xaebbe0: ldur            x0, [fp, #-0xb8]
    // 0xaebbe4: StoreField: r1->field_4f = r0
    //     0xaebbe4: stur            w0, [x1, #0x4f]
    // 0xaebbe8: ldur            x0, [fp, #-0xb0]
    // 0xaebbec: StoreField: r1->field_53 = r0
    //     0xaebbec: stur            w0, [x1, #0x53]
    // 0xaebbf0: ldur            x0, [fp, #-0xa8]
    // 0xaebbf4: StoreField: r1->field_57 = r0
    //     0xaebbf4: stur            w0, [x1, #0x57]
    // 0xaebbf8: ldur            x0, [fp, #-0x20]
    // 0xaebbfc: StoreField: r1->field_6b = r0
    //     0xaebbfc: stur            w0, [x1, #0x6b]
    // 0xaebc00: ldur            x0, [fp, #-0xa0]
    // 0xaebc04: StoreField: r1->field_13 = r0
    //     0xaebc04: stur            w0, [x1, #0x13]
    // 0xaebc08: ldur            x0, [fp, #-0x98]
    // 0xaebc0c: StoreField: r1->field_17 = r0
    //     0xaebc0c: stur            w0, [x1, #0x17]
    // 0xaebc10: mov             x0, x1
    // 0xaebc14: LeaveFrame
    //     0xaebc14: mov             SP, fp
    //     0xaebc18: ldp             fp, lr, [SP], #0x10
    // 0xaebc1c: ret
    //     0xaebc1c: ret             
    // 0xaebc20: mov             x3, x0
    // 0xaebc24: ldr             x0, [fp, #0x10]
    // 0xaebc28: LoadField: d0 = r0->field_7
    //     0xaebc28: ldur            d0, [x0, #7]
    // 0xaebc2c: stur            d0, [fp, #-0xc0]
    // 0xaebc30: fcmp            d0, d1
    // 0xaebc34: b.vs            #0xaebc3c
    // 0xaebc38: b.lt            #0xaebc44
    // 0xaebc3c: r1 = false
    //     0xaebc3c: add             x1, NULL, #0x30  ; false
    // 0xaebc40: b               #0xaebc48
    // 0xaebc44: r1 = true
    //     0xaebc44: add             x1, NULL, #0x20  ; true
    // 0xaebc48: stur            x1, [fp, #-0x18]
    // 0xaebc4c: tbnz            w1, #4, #0xaebc5c
    // 0xaebc50: LoadField: r4 = r3->field_7
    //     0xaebc50: ldur            w4, [x3, #7]
    // 0xaebc54: DecompressPointer r4
    //     0xaebc54: add             x4, x4, HEAP, lsl #32
    // 0xaebc58: b               #0xaebc64
    // 0xaebc5c: LoadField: r4 = r2->field_7
    //     0xaebc5c: ldur            w4, [x2, #7]
    // 0xaebc60: DecompressPointer r4
    //     0xaebc60: add             x4, x4, HEAP, lsl #32
    // 0xaebc64: stur            x4, [fp, #-0x10]
    // 0xaebc68: LoadField: r5 = r3->field_43
    //     0xaebc68: ldur            w5, [x3, #0x43]
    // 0xaebc6c: DecompressPointer r5
    //     0xaebc6c: add             x5, x5, HEAP, lsl #32
    // 0xaebc70: stur            x5, [fp, #-8]
    // 0xaebc74: cmp             w5, NULL
    // 0xaebc78: b.ne            #0xaebcb4
    // 0xaebc7c: LoadField: r6 = r2->field_43
    //     0xaebc7c: ldur            w6, [x2, #0x43]
    // 0xaebc80: DecompressPointer r6
    //     0xaebc80: add             x6, x6, HEAP, lsl #32
    // 0xaebc84: cmp             w6, NULL
    // 0xaebc88: b.ne            #0xaebcb4
    // 0xaebc8c: LoadField: r6 = r3->field_b
    //     0xaebc8c: ldur            w6, [x3, #0xb]
    // 0xaebc90: DecompressPointer r6
    //     0xaebc90: add             x6, x6, HEAP, lsl #32
    // 0xaebc94: LoadField: r7 = r2->field_b
    //     0xaebc94: ldur            w7, [x2, #0xb]
    // 0xaebc98: DecompressPointer r7
    //     0xaebc98: add             x7, x7, HEAP, lsl #32
    // 0xaebc9c: stp             x7, x6, [SP, #-0x10]!
    // 0xaebca0: SaveReg r0
    //     0xaebca0: str             x0, [SP, #-8]!
    // 0xaebca4: r0 = lerp()
    //     0xaebca4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaebca8: add             SP, SP, #0x18
    // 0xaebcac: mov             x1, x0
    // 0xaebcb0: b               #0xaebcb8
    // 0xaebcb4: r1 = Null
    //     0xaebcb4: mov             x1, NULL
    // 0xaebcb8: ldr             x0, [fp, #0x20]
    // 0xaebcbc: stur            x1, [fp, #-0x28]
    // 0xaebcc0: LoadField: r2 = r0->field_47
    //     0xaebcc0: ldur            w2, [x0, #0x47]
    // 0xaebcc4: DecompressPointer r2
    //     0xaebcc4: add             x2, x2, HEAP, lsl #32
    // 0xaebcc8: stur            x2, [fp, #-0x20]
    // 0xaebccc: cmp             w2, NULL
    // 0xaebcd0: b.ne            #0xaebd14
    // 0xaebcd4: ldr             x3, [fp, #0x18]
    // 0xaebcd8: LoadField: r4 = r3->field_47
    //     0xaebcd8: ldur            w4, [x3, #0x47]
    // 0xaebcdc: DecompressPointer r4
    //     0xaebcdc: add             x4, x4, HEAP, lsl #32
    // 0xaebce0: cmp             w4, NULL
    // 0xaebce4: b.ne            #0xaebd14
    // 0xaebce8: LoadField: r4 = r0->field_f
    //     0xaebce8: ldur            w4, [x0, #0xf]
    // 0xaebcec: DecompressPointer r4
    //     0xaebcec: add             x4, x4, HEAP, lsl #32
    // 0xaebcf0: LoadField: r5 = r3->field_f
    //     0xaebcf0: ldur            w5, [x3, #0xf]
    // 0xaebcf4: DecompressPointer r5
    //     0xaebcf4: add             x5, x5, HEAP, lsl #32
    // 0xaebcf8: stp             x5, x4, [SP, #-0x10]!
    // 0xaebcfc: ldr             x16, [fp, #0x10]
    // 0xaebd00: SaveReg r16
    //     0xaebd00: str             x16, [SP, #-8]!
    // 0xaebd04: r0 = lerp()
    //     0xaebd04: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaebd08: add             SP, SP, #0x18
    // 0xaebd0c: mov             x1, x0
    // 0xaebd10: b               #0xaebd18
    // 0xaebd14: r1 = Null
    //     0xaebd14: mov             x1, NULL
    // 0xaebd18: ldr             x0, [fp, #0x20]
    // 0xaebd1c: stur            x1, [fp, #-0x30]
    // 0xaebd20: LoadField: r2 = r0->field_1f
    //     0xaebd20: ldur            w2, [x0, #0x1f]
    // 0xaebd24: DecompressPointer r2
    //     0xaebd24: add             x2, x2, HEAP, lsl #32
    // 0xaebd28: cmp             w2, NULL
    // 0xaebd2c: b.ne            #0xaebd40
    // 0xaebd30: ldr             x3, [fp, #0x18]
    // 0xaebd34: LoadField: r4 = r3->field_1f
    //     0xaebd34: ldur            w4, [x3, #0x1f]
    // 0xaebd38: DecompressPointer r4
    //     0xaebd38: add             x4, x4, HEAP, lsl #32
    // 0xaebd3c: b               #0xaebd48
    // 0xaebd40: ldr             x3, [fp, #0x18]
    // 0xaebd44: mov             x4, x2
    // 0xaebd48: LoadField: r5 = r3->field_1f
    //     0xaebd48: ldur            w5, [x3, #0x1f]
    // 0xaebd4c: DecompressPointer r5
    //     0xaebd4c: add             x5, x5, HEAP, lsl #32
    // 0xaebd50: cmp             w5, NULL
    // 0xaebd54: b.ne            #0xaebd5c
    // 0xaebd58: mov             x5, x2
    // 0xaebd5c: ldur            x2, [fp, #-0x18]
    // 0xaebd60: ldur            d0, [fp, #-0xc0]
    // 0xaebd64: stp             x5, x4, [SP, #-0x10]!
    // 0xaebd68: ldr             x16, [fp, #0x10]
    // 0xaebd6c: SaveReg r16
    //     0xaebd6c: str             x16, [SP, #-8]!
    // 0xaebd70: r0 = lerpDouble()
    //     0xaebd70: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xaebd74: add             SP, SP, #0x18
    // 0xaebd78: mov             x1, x0
    // 0xaebd7c: ldr             x0, [fp, #0x20]
    // 0xaebd80: stur            x1, [fp, #-0x38]
    // 0xaebd84: LoadField: r2 = r0->field_23
    //     0xaebd84: ldur            w2, [x0, #0x23]
    // 0xaebd88: DecompressPointer r2
    //     0xaebd88: add             x2, x2, HEAP, lsl #32
    // 0xaebd8c: ldr             x3, [fp, #0x18]
    // 0xaebd90: LoadField: r4 = r3->field_23
    //     0xaebd90: ldur            w4, [x3, #0x23]
    // 0xaebd94: DecompressPointer r4
    //     0xaebd94: add             x4, x4, HEAP, lsl #32
    // 0xaebd98: stp             x4, x2, [SP, #-0x10]!
    // 0xaebd9c: ldur            d0, [fp, #-0xc0]
    // 0xaebda0: SaveReg d0
    //     0xaebda0: str             d0, [SP, #-8]!
    // 0xaebda4: r0 = lerp()
    //     0xaebda4: bl              #0xaec5dc  ; [dart:ui] FontWeight::lerp
    // 0xaebda8: add             SP, SP, #0x18
    // 0xaebdac: mov             x1, x0
    // 0xaebdb0: ldur            x0, [fp, #-0x18]
    // 0xaebdb4: stur            x1, [fp, #-0x48]
    // 0xaebdb8: tbnz            w0, #4, #0xaebdd4
    // 0xaebdbc: ldr             x2, [fp, #0x20]
    // 0xaebdc0: LoadField: r3 = r2->field_27
    //     0xaebdc0: ldur            w3, [x2, #0x27]
    // 0xaebdc4: DecompressPointer r3
    //     0xaebdc4: add             x3, x3, HEAP, lsl #32
    // 0xaebdc8: mov             x4, x3
    // 0xaebdcc: ldr             x3, [fp, #0x18]
    // 0xaebdd0: b               #0xaebde4
    // 0xaebdd4: ldr             x2, [fp, #0x20]
    // 0xaebdd8: ldr             x3, [fp, #0x18]
    // 0xaebddc: LoadField: r4 = r3->field_27
    //     0xaebddc: ldur            w4, [x3, #0x27]
    // 0xaebde0: DecompressPointer r4
    //     0xaebde0: add             x4, x4, HEAP, lsl #32
    // 0xaebde4: stur            x4, [fp, #-0x40]
    // 0xaebde8: LoadField: r5 = r2->field_2b
    //     0xaebde8: ldur            w5, [x2, #0x2b]
    // 0xaebdec: DecompressPointer r5
    //     0xaebdec: add             x5, x5, HEAP, lsl #32
    // 0xaebdf0: cmp             w5, NULL
    // 0xaebdf4: b.ne            #0xaebe04
    // 0xaebdf8: LoadField: r6 = r3->field_2b
    //     0xaebdf8: ldur            w6, [x3, #0x2b]
    // 0xaebdfc: DecompressPointer r6
    //     0xaebdfc: add             x6, x6, HEAP, lsl #32
    // 0xaebe00: b               #0xaebe08
    // 0xaebe04: mov             x6, x5
    // 0xaebe08: LoadField: r7 = r3->field_2b
    //     0xaebe08: ldur            w7, [x3, #0x2b]
    // 0xaebe0c: DecompressPointer r7
    //     0xaebe0c: add             x7, x7, HEAP, lsl #32
    // 0xaebe10: cmp             w7, NULL
    // 0xaebe14: b.eq            #0xaebe1c
    // 0xaebe18: mov             x5, x7
    // 0xaebe1c: stp             x5, x6, [SP, #-0x10]!
    // 0xaebe20: ldr             x16, [fp, #0x10]
    // 0xaebe24: SaveReg r16
    //     0xaebe24: str             x16, [SP, #-8]!
    // 0xaebe28: r0 = lerpDouble()
    //     0xaebe28: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xaebe2c: add             SP, SP, #0x18
    // 0xaebe30: mov             x1, x0
    // 0xaebe34: ldr             x0, [fp, #0x20]
    // 0xaebe38: stur            x1, [fp, #-0x50]
    // 0xaebe3c: LoadField: r2 = r0->field_2f
    //     0xaebe3c: ldur            w2, [x0, #0x2f]
    // 0xaebe40: DecompressPointer r2
    //     0xaebe40: add             x2, x2, HEAP, lsl #32
    // 0xaebe44: cmp             w2, NULL
    // 0xaebe48: b.ne            #0xaebe5c
    // 0xaebe4c: ldr             x3, [fp, #0x18]
    // 0xaebe50: LoadField: r4 = r3->field_2f
    //     0xaebe50: ldur            w4, [x3, #0x2f]
    // 0xaebe54: DecompressPointer r4
    //     0xaebe54: add             x4, x4, HEAP, lsl #32
    // 0xaebe58: b               #0xaebe64
    // 0xaebe5c: ldr             x3, [fp, #0x18]
    // 0xaebe60: mov             x4, x2
    // 0xaebe64: LoadField: r5 = r3->field_2f
    //     0xaebe64: ldur            w5, [x3, #0x2f]
    // 0xaebe68: DecompressPointer r5
    //     0xaebe68: add             x5, x5, HEAP, lsl #32
    // 0xaebe6c: cmp             w5, NULL
    // 0xaebe70: b.ne            #0xaebe78
    // 0xaebe74: mov             x5, x2
    // 0xaebe78: ldur            x2, [fp, #-0x18]
    // 0xaebe7c: stp             x5, x4, [SP, #-0x10]!
    // 0xaebe80: ldr             x16, [fp, #0x10]
    // 0xaebe84: SaveReg r16
    //     0xaebe84: str             x16, [SP, #-8]!
    // 0xaebe88: r0 = lerpDouble()
    //     0xaebe88: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xaebe8c: add             SP, SP, #0x18
    // 0xaebe90: mov             x1, x0
    // 0xaebe94: ldur            x0, [fp, #-0x18]
    // 0xaebe98: stur            x1, [fp, #-0x60]
    // 0xaebe9c: tbnz            w0, #4, #0xaebeb8
    // 0xaebea0: ldr             x2, [fp, #0x20]
    // 0xaebea4: LoadField: r3 = r2->field_33
    //     0xaebea4: ldur            w3, [x2, #0x33]
    // 0xaebea8: DecompressPointer r3
    //     0xaebea8: add             x3, x3, HEAP, lsl #32
    // 0xaebeac: mov             x4, x3
    // 0xaebeb0: ldr             x3, [fp, #0x18]
    // 0xaebeb4: b               #0xaebec8
    // 0xaebeb8: ldr             x2, [fp, #0x20]
    // 0xaebebc: ldr             x3, [fp, #0x18]
    // 0xaebec0: LoadField: r4 = r3->field_33
    //     0xaebec0: ldur            w4, [x3, #0x33]
    // 0xaebec4: DecompressPointer r4
    //     0xaebec4: add             x4, x4, HEAP, lsl #32
    // 0xaebec8: stur            x4, [fp, #-0x58]
    // 0xaebecc: LoadField: r5 = r2->field_37
    //     0xaebecc: ldur            w5, [x2, #0x37]
    // 0xaebed0: DecompressPointer r5
    //     0xaebed0: add             x5, x5, HEAP, lsl #32
    // 0xaebed4: cmp             w5, NULL
    // 0xaebed8: b.ne            #0xaebee8
    // 0xaebedc: LoadField: r6 = r3->field_37
    //     0xaebedc: ldur            w6, [x3, #0x37]
    // 0xaebee0: DecompressPointer r6
    //     0xaebee0: add             x6, x6, HEAP, lsl #32
    // 0xaebee4: b               #0xaebeec
    // 0xaebee8: mov             x6, x5
    // 0xaebeec: LoadField: r7 = r3->field_37
    //     0xaebeec: ldur            w7, [x3, #0x37]
    // 0xaebef0: DecompressPointer r7
    //     0xaebef0: add             x7, x7, HEAP, lsl #32
    // 0xaebef4: cmp             w7, NULL
    // 0xaebef8: b.eq            #0xaebf00
    // 0xaebefc: mov             x5, x7
    // 0xaebf00: stp             x5, x6, [SP, #-0x10]!
    // 0xaebf04: ldr             x16, [fp, #0x10]
    // 0xaebf08: SaveReg r16
    //     0xaebf08: str             x16, [SP, #-8]!
    // 0xaebf0c: r0 = lerpDouble()
    //     0xaebf0c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xaebf10: add             SP, SP, #0x18
    // 0xaebf14: mov             x1, x0
    // 0xaebf18: ldur            x0, [fp, #-0x18]
    // 0xaebf1c: stur            x1, [fp, #-0x70]
    // 0xaebf20: tbnz            w0, #4, #0xaebf3c
    // 0xaebf24: ldr             x2, [fp, #0x20]
    // 0xaebf28: LoadField: r3 = r2->field_3b
    //     0xaebf28: ldur            w3, [x2, #0x3b]
    // 0xaebf2c: DecompressPointer r3
    //     0xaebf2c: add             x3, x3, HEAP, lsl #32
    // 0xaebf30: mov             x5, x3
    // 0xaebf34: ldr             x3, [fp, #0x18]
    // 0xaebf38: b               #0xaebf50
    // 0xaebf3c: ldr             x2, [fp, #0x20]
    // 0xaebf40: ldr             x3, [fp, #0x18]
    // 0xaebf44: LoadField: r4 = r3->field_3b
    //     0xaebf44: ldur            w4, [x3, #0x3b]
    // 0xaebf48: DecompressPointer r4
    //     0xaebf48: add             x4, x4, HEAP, lsl #32
    // 0xaebf4c: mov             x5, x4
    // 0xaebf50: ldur            x4, [fp, #-8]
    // 0xaebf54: stur            x5, [fp, #-0x68]
    // 0xaebf58: cmp             w4, NULL
    // 0xaebf5c: b.ne            #0xaebf70
    // 0xaebf60: LoadField: r6 = r3->field_43
    //     0xaebf60: ldur            w6, [x3, #0x43]
    // 0xaebf64: DecompressPointer r6
    //     0xaebf64: add             x6, x6, HEAP, lsl #32
    // 0xaebf68: cmp             w6, NULL
    // 0xaebf6c: b.eq            #0xaec104
    // 0xaebf70: tbnz            w0, #4, #0xaec034
    // 0xaebf74: cmp             w4, NULL
    // 0xaebf78: b.ne            #0xaec028
    // 0xaebf7c: r16 = 112
    //     0xaebf7c: mov             x16, #0x70
    // 0xaebf80: stp             x16, NULL, [SP, #-0x10]!
    // 0xaebf84: r0 = ByteData()
    //     0xaebf84: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xaebf88: add             SP, SP, #0x10
    // 0xaebf8c: stur            x0, [fp, #-0x78]
    // 0xaebf90: r0 = Paint()
    //     0xaebf90: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xaebf94: mov             x1, x0
    // 0xaebf98: ldur            x0, [fp, #-0x78]
    // 0xaebf9c: StoreField: r1->field_7 = r0
    //     0xaebf9c: stur            w0, [x1, #7]
    // 0xaebfa0: ldr             x2, [fp, #0x20]
    // 0xaebfa4: LoadField: r3 = r2->field_b
    //     0xaebfa4: ldur            w3, [x2, #0xb]
    // 0xaebfa8: DecompressPointer r3
    //     0xaebfa8: add             x3, x3, HEAP, lsl #32
    // 0xaebfac: cmp             w3, NULL
    // 0xaebfb0: b.eq            #0xaec588
    // 0xaebfb4: r4 = LoadClassIdInstr(r3)
    //     0xaebfb4: ldur            x4, [x3, #-1]
    //     0xaebfb8: ubfx            x4, x4, #0xc, #0x14
    // 0xaebfbc: lsl             x4, x4, #1
    // 0xaebfc0: r17 = 10124
    //     0xaebfc0: mov             x17, #0x278c
    // 0xaebfc4: cmp             w4, w17
    // 0xaebfc8: b.gt            #0xaebfd8
    // 0xaebfcc: r17 = 10122
    //     0xaebfcc: mov             x17, #0x278a
    // 0xaebfd0: cmp             w4, w17
    // 0xaebfd4: b.ge            #0xaebff0
    // 0xaebfd8: r17 = 10114
    //     0xaebfd8: mov             x17, #0x2782
    // 0xaebfdc: cmp             w4, w17
    // 0xaebfe0: b.eq            #0xaebff0
    // 0xaebfe4: r17 = 10118
    //     0xaebfe4: mov             x17, #0x2786
    // 0xaebfe8: cmp             w4, w17
    // 0xaebfec: b.ne            #0xaebffc
    // 0xaebff0: LoadField: r4 = r3->field_7
    //     0xaebff0: ldur            x4, [x3, #7]
    // 0xaebff4: mov             x3, x4
    // 0xaebff8: b               #0xaec008
    // 0xaebffc: LoadField: r4 = r3->field_f
    //     0xaebffc: ldur            w4, [x3, #0xf]
    // 0xaec000: DecompressPointer r4
    //     0xaec000: add             x4, x4, HEAP, lsl #32
    // 0xaec004: LoadField: r3 = r4->field_7
    //     0xaec004: ldur            x3, [x4, #7]
    // 0xaec008: eor             x4, x3, #0xff000000
    // 0xaec00c: LoadField: r3 = r0->field_17
    //     0xaec00c: ldur            w3, [x0, #0x17]
    // 0xaec010: DecompressPointer r3
    //     0xaec010: add             x3, x3, HEAP, lsl #32
    // 0xaec014: sxtw            x4, w4
    // 0xaec018: LoadField: r0 = r3->field_7
    //     0xaec018: ldur            x0, [x3, #7]
    // 0xaec01c: str             w4, [x0, #4]
    // 0xaec020: mov             x0, x1
    // 0xaec024: b               #0xaec02c
    // 0xaec028: mov             x0, x4
    // 0xaec02c: ldr             x2, [fp, #0x18]
    // 0xaec030: b               #0xaec0fc
    // 0xaec034: mov             x0, x3
    // 0xaec038: LoadField: r1 = r0->field_43
    //     0xaec038: ldur            w1, [x0, #0x43]
    // 0xaec03c: DecompressPointer r1
    //     0xaec03c: add             x1, x1, HEAP, lsl #32
    // 0xaec040: cmp             w1, NULL
    // 0xaec044: b.ne            #0xaec0f4
    // 0xaec048: r16 = 112
    //     0xaec048: mov             x16, #0x70
    // 0xaec04c: stp             x16, NULL, [SP, #-0x10]!
    // 0xaec050: r0 = ByteData()
    //     0xaec050: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xaec054: add             SP, SP, #0x10
    // 0xaec058: stur            x0, [fp, #-8]
    // 0xaec05c: r0 = Paint()
    //     0xaec05c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xaec060: mov             x1, x0
    // 0xaec064: ldur            x0, [fp, #-8]
    // 0xaec068: StoreField: r1->field_7 = r0
    //     0xaec068: stur            w0, [x1, #7]
    // 0xaec06c: ldr             x2, [fp, #0x18]
    // 0xaec070: LoadField: r3 = r2->field_b
    //     0xaec070: ldur            w3, [x2, #0xb]
    // 0xaec074: DecompressPointer r3
    //     0xaec074: add             x3, x3, HEAP, lsl #32
    // 0xaec078: cmp             w3, NULL
    // 0xaec07c: b.eq            #0xaec58c
    // 0xaec080: r4 = LoadClassIdInstr(r3)
    //     0xaec080: ldur            x4, [x3, #-1]
    //     0xaec084: ubfx            x4, x4, #0xc, #0x14
    // 0xaec088: lsl             x4, x4, #1
    // 0xaec08c: r17 = 10124
    //     0xaec08c: mov             x17, #0x278c
    // 0xaec090: cmp             w4, w17
    // 0xaec094: b.gt            #0xaec0a4
    // 0xaec098: r17 = 10122
    //     0xaec098: mov             x17, #0x278a
    // 0xaec09c: cmp             w4, w17
    // 0xaec0a0: b.ge            #0xaec0bc
    // 0xaec0a4: r17 = 10114
    //     0xaec0a4: mov             x17, #0x2782
    // 0xaec0a8: cmp             w4, w17
    // 0xaec0ac: b.eq            #0xaec0bc
    // 0xaec0b0: r17 = 10118
    //     0xaec0b0: mov             x17, #0x2786
    // 0xaec0b4: cmp             w4, w17
    // 0xaec0b8: b.ne            #0xaec0c8
    // 0xaec0bc: LoadField: r4 = r3->field_7
    //     0xaec0bc: ldur            x4, [x3, #7]
    // 0xaec0c0: mov             x3, x4
    // 0xaec0c4: b               #0xaec0d4
    // 0xaec0c8: LoadField: r4 = r3->field_f
    //     0xaec0c8: ldur            w4, [x3, #0xf]
    // 0xaec0cc: DecompressPointer r4
    //     0xaec0cc: add             x4, x4, HEAP, lsl #32
    // 0xaec0d0: LoadField: r3 = r4->field_7
    //     0xaec0d0: ldur            x3, [x4, #7]
    // 0xaec0d4: eor             x4, x3, #0xff000000
    // 0xaec0d8: LoadField: r3 = r0->field_17
    //     0xaec0d8: ldur            w3, [x0, #0x17]
    // 0xaec0dc: DecompressPointer r3
    //     0xaec0dc: add             x3, x3, HEAP, lsl #32
    // 0xaec0e0: sxtw            x4, w4
    // 0xaec0e4: LoadField: r0 = r3->field_7
    //     0xaec0e4: ldur            x0, [x3, #7]
    // 0xaec0e8: str             w4, [x0, #4]
    // 0xaec0ec: mov             x0, x1
    // 0xaec0f0: b               #0xaec0fc
    // 0xaec0f4: mov             x2, x0
    // 0xaec0f8: mov             x0, x1
    // 0xaec0fc: mov             x1, x0
    // 0xaec100: b               #0xaec10c
    // 0xaec104: mov             x2, x3
    // 0xaec108: r1 = Null
    //     0xaec108: mov             x1, NULL
    // 0xaec10c: ldur            x0, [fp, #-0x20]
    // 0xaec110: stur            x1, [fp, #-8]
    // 0xaec114: cmp             w0, NULL
    // 0xaec118: b.ne            #0xaec12c
    // 0xaec11c: LoadField: r3 = r2->field_47
    //     0xaec11c: ldur            w3, [x2, #0x47]
    // 0xaec120: DecompressPointer r3
    //     0xaec120: add             x3, x3, HEAP, lsl #32
    // 0xaec124: cmp             w3, NULL
    // 0xaec128: b.eq            #0xaec2cc
    // 0xaec12c: ldur            x3, [fp, #-0x18]
    // 0xaec130: tbnz            w3, #4, #0xaec1f8
    // 0xaec134: cmp             w0, NULL
    // 0xaec138: b.ne            #0xaec1ec
    // 0xaec13c: ldr             x0, [fp, #0x20]
    // 0xaec140: r16 = 112
    //     0xaec140: mov             x16, #0x70
    // 0xaec144: stp             x16, NULL, [SP, #-0x10]!
    // 0xaec148: r0 = ByteData()
    //     0xaec148: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xaec14c: add             SP, SP, #0x10
    // 0xaec150: stur            x0, [fp, #-0x78]
    // 0xaec154: r0 = Paint()
    //     0xaec154: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xaec158: mov             x1, x0
    // 0xaec15c: ldur            x0, [fp, #-0x78]
    // 0xaec160: StoreField: r1->field_7 = r0
    //     0xaec160: stur            w0, [x1, #7]
    // 0xaec164: ldr             x2, [fp, #0x20]
    // 0xaec168: LoadField: r3 = r2->field_f
    //     0xaec168: ldur            w3, [x2, #0xf]
    // 0xaec16c: DecompressPointer r3
    //     0xaec16c: add             x3, x3, HEAP, lsl #32
    // 0xaec170: cmp             w3, NULL
    // 0xaec174: b.eq            #0xaec590
    // 0xaec178: r4 = LoadClassIdInstr(r3)
    //     0xaec178: ldur            x4, [x3, #-1]
    //     0xaec17c: ubfx            x4, x4, #0xc, #0x14
    // 0xaec180: lsl             x4, x4, #1
    // 0xaec184: r17 = 10124
    //     0xaec184: mov             x17, #0x278c
    // 0xaec188: cmp             w4, w17
    // 0xaec18c: b.gt            #0xaec19c
    // 0xaec190: r17 = 10122
    //     0xaec190: mov             x17, #0x278a
    // 0xaec194: cmp             w4, w17
    // 0xaec198: b.ge            #0xaec1b4
    // 0xaec19c: r17 = 10114
    //     0xaec19c: mov             x17, #0x2782
    // 0xaec1a0: cmp             w4, w17
    // 0xaec1a4: b.eq            #0xaec1b4
    // 0xaec1a8: r17 = 10118
    //     0xaec1a8: mov             x17, #0x2786
    // 0xaec1ac: cmp             w4, w17
    // 0xaec1b0: b.ne            #0xaec1c0
    // 0xaec1b4: LoadField: r4 = r3->field_7
    //     0xaec1b4: ldur            x4, [x3, #7]
    // 0xaec1b8: mov             x3, x4
    // 0xaec1bc: b               #0xaec1cc
    // 0xaec1c0: LoadField: r4 = r3->field_f
    //     0xaec1c0: ldur            w4, [x3, #0xf]
    // 0xaec1c4: DecompressPointer r4
    //     0xaec1c4: add             x4, x4, HEAP, lsl #32
    // 0xaec1c8: LoadField: r3 = r4->field_7
    //     0xaec1c8: ldur            x3, [x4, #7]
    // 0xaec1cc: eor             x4, x3, #0xff000000
    // 0xaec1d0: LoadField: r3 = r0->field_17
    //     0xaec1d0: ldur            w3, [x0, #0x17]
    // 0xaec1d4: DecompressPointer r3
    //     0xaec1d4: add             x3, x3, HEAP, lsl #32
    // 0xaec1d8: sxtw            x4, w4
    // 0xaec1dc: LoadField: r0 = r3->field_7
    //     0xaec1dc: ldur            x0, [x3, #7]
    // 0xaec1e0: str             w4, [x0, #4]
    // 0xaec1e4: mov             x0, x1
    // 0xaec1e8: b               #0xaec1f0
    // 0xaec1ec: ldr             x2, [fp, #0x20]
    // 0xaec1f0: ldr             x2, [fp, #0x18]
    // 0xaec1f4: b               #0xaec2c4
    // 0xaec1f8: mov             x0, x2
    // 0xaec1fc: ldr             x2, [fp, #0x20]
    // 0xaec200: LoadField: r1 = r0->field_47
    //     0xaec200: ldur            w1, [x0, #0x47]
    // 0xaec204: DecompressPointer r1
    //     0xaec204: add             x1, x1, HEAP, lsl #32
    // 0xaec208: cmp             w1, NULL
    // 0xaec20c: b.ne            #0xaec2bc
    // 0xaec210: r16 = 112
    //     0xaec210: mov             x16, #0x70
    // 0xaec214: stp             x16, NULL, [SP, #-0x10]!
    // 0xaec218: r0 = ByteData()
    //     0xaec218: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xaec21c: add             SP, SP, #0x10
    // 0xaec220: stur            x0, [fp, #-0x20]
    // 0xaec224: r0 = Paint()
    //     0xaec224: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xaec228: mov             x1, x0
    // 0xaec22c: ldur            x0, [fp, #-0x20]
    // 0xaec230: StoreField: r1->field_7 = r0
    //     0xaec230: stur            w0, [x1, #7]
    // 0xaec234: ldr             x2, [fp, #0x18]
    // 0xaec238: LoadField: r3 = r2->field_f
    //     0xaec238: ldur            w3, [x2, #0xf]
    // 0xaec23c: DecompressPointer r3
    //     0xaec23c: add             x3, x3, HEAP, lsl #32
    // 0xaec240: cmp             w3, NULL
    // 0xaec244: b.eq            #0xaec594
    // 0xaec248: r4 = LoadClassIdInstr(r3)
    //     0xaec248: ldur            x4, [x3, #-1]
    //     0xaec24c: ubfx            x4, x4, #0xc, #0x14
    // 0xaec250: lsl             x4, x4, #1
    // 0xaec254: r17 = 10124
    //     0xaec254: mov             x17, #0x278c
    // 0xaec258: cmp             w4, w17
    // 0xaec25c: b.gt            #0xaec26c
    // 0xaec260: r17 = 10122
    //     0xaec260: mov             x17, #0x278a
    // 0xaec264: cmp             w4, w17
    // 0xaec268: b.ge            #0xaec284
    // 0xaec26c: r17 = 10114
    //     0xaec26c: mov             x17, #0x2782
    // 0xaec270: cmp             w4, w17
    // 0xaec274: b.eq            #0xaec284
    // 0xaec278: r17 = 10118
    //     0xaec278: mov             x17, #0x2786
    // 0xaec27c: cmp             w4, w17
    // 0xaec280: b.ne            #0xaec290
    // 0xaec284: LoadField: r4 = r3->field_7
    //     0xaec284: ldur            x4, [x3, #7]
    // 0xaec288: mov             x3, x4
    // 0xaec28c: b               #0xaec29c
    // 0xaec290: LoadField: r4 = r3->field_f
    //     0xaec290: ldur            w4, [x3, #0xf]
    // 0xaec294: DecompressPointer r4
    //     0xaec294: add             x4, x4, HEAP, lsl #32
    // 0xaec298: LoadField: r3 = r4->field_7
    //     0xaec298: ldur            x3, [x4, #7]
    // 0xaec29c: eor             x4, x3, #0xff000000
    // 0xaec2a0: LoadField: r3 = r0->field_17
    //     0xaec2a0: ldur            w3, [x0, #0x17]
    // 0xaec2a4: DecompressPointer r3
    //     0xaec2a4: add             x3, x3, HEAP, lsl #32
    // 0xaec2a8: sxtw            x4, w4
    // 0xaec2ac: LoadField: r0 = r3->field_7
    //     0xaec2ac: ldur            x0, [x3, #7]
    // 0xaec2b0: str             w4, [x0, #4]
    // 0xaec2b4: mov             x0, x1
    // 0xaec2b8: b               #0xaec2c4
    // 0xaec2bc: mov             x2, x0
    // 0xaec2c0: mov             x0, x1
    // 0xaec2c4: mov             x1, x0
    // 0xaec2c8: b               #0xaec2d0
    // 0xaec2cc: r1 = Null
    //     0xaec2cc: mov             x1, NULL
    // 0xaec2d0: ldur            x0, [fp, #-0x18]
    // 0xaec2d4: stur            x1, [fp, #-0x90]
    // 0xaec2d8: tbnz            w0, #4, #0xaec2ec
    // 0xaec2dc: ldr             x3, [fp, #0x20]
    // 0xaec2e0: LoadField: r4 = r3->field_5f
    //     0xaec2e0: ldur            w4, [x3, #0x5f]
    // 0xaec2e4: DecompressPointer r4
    //     0xaec2e4: add             x4, x4, HEAP, lsl #32
    // 0xaec2e8: b               #0xaec2f8
    // 0xaec2ec: ldr             x3, [fp, #0x20]
    // 0xaec2f0: LoadField: r4 = r2->field_5f
    //     0xaec2f0: ldur            w4, [x2, #0x5f]
    // 0xaec2f4: DecompressPointer r4
    //     0xaec2f4: add             x4, x4, HEAP, lsl #32
    // 0xaec2f8: stur            x4, [fp, #-0x88]
    // 0xaec2fc: tbnz            w0, #4, #0xaec30c
    // 0xaec300: LoadField: r5 = r3->field_63
    //     0xaec300: ldur            w5, [x3, #0x63]
    // 0xaec304: DecompressPointer r5
    //     0xaec304: add             x5, x5, HEAP, lsl #32
    // 0xaec308: b               #0xaec314
    // 0xaec30c: LoadField: r5 = r2->field_63
    //     0xaec30c: ldur            w5, [x2, #0x63]
    // 0xaec310: DecompressPointer r5
    //     0xaec310: add             x5, x5, HEAP, lsl #32
    // 0xaec314: stur            x5, [fp, #-0x80]
    // 0xaec318: tbnz            w0, #4, #0xaec328
    // 0xaec31c: LoadField: r6 = r3->field_67
    //     0xaec31c: ldur            w6, [x3, #0x67]
    // 0xaec320: DecompressPointer r6
    //     0xaec320: add             x6, x6, HEAP, lsl #32
    // 0xaec324: b               #0xaec330
    // 0xaec328: LoadField: r6 = r2->field_67
    //     0xaec328: ldur            w6, [x2, #0x67]
    // 0xaec32c: DecompressPointer r6
    //     0xaec32c: add             x6, x6, HEAP, lsl #32
    // 0xaec330: stur            x6, [fp, #-0x78]
    // 0xaec334: tbnz            w0, #4, #0xaec344
    // 0xaec338: LoadField: r7 = r3->field_4b
    //     0xaec338: ldur            w7, [x3, #0x4b]
    // 0xaec33c: DecompressPointer r7
    //     0xaec33c: add             x7, x7, HEAP, lsl #32
    // 0xaec340: b               #0xaec34c
    // 0xaec344: LoadField: r7 = r2->field_4b
    //     0xaec344: ldur            w7, [x2, #0x4b]
    // 0xaec348: DecompressPointer r7
    //     0xaec348: add             x7, x7, HEAP, lsl #32
    // 0xaec34c: stur            x7, [fp, #-0x20]
    // 0xaec350: LoadField: r8 = r3->field_4f
    //     0xaec350: ldur            w8, [x3, #0x4f]
    // 0xaec354: DecompressPointer r8
    //     0xaec354: add             x8, x8, HEAP, lsl #32
    // 0xaec358: LoadField: r9 = r2->field_4f
    //     0xaec358: ldur            w9, [x2, #0x4f]
    // 0xaec35c: DecompressPointer r9
    //     0xaec35c: add             x9, x9, HEAP, lsl #32
    // 0xaec360: stp             x9, x8, [SP, #-0x10]!
    // 0xaec364: ldr             x16, [fp, #0x10]
    // 0xaec368: SaveReg r16
    //     0xaec368: str             x16, [SP, #-8]!
    // 0xaec36c: r0 = lerp()
    //     0xaec36c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaec370: add             SP, SP, #0x18
    // 0xaec374: mov             x1, x0
    // 0xaec378: ldur            x0, [fp, #-0x18]
    // 0xaec37c: stur            x1, [fp, #-0xa0]
    // 0xaec380: tbnz            w0, #4, #0xaec39c
    // 0xaec384: ldr             x2, [fp, #0x20]
    // 0xaec388: LoadField: r3 = r2->field_53
    //     0xaec388: ldur            w3, [x2, #0x53]
    // 0xaec38c: DecompressPointer r3
    //     0xaec38c: add             x3, x3, HEAP, lsl #32
    // 0xaec390: mov             x4, x3
    // 0xaec394: ldr             x3, [fp, #0x18]
    // 0xaec398: b               #0xaec3ac
    // 0xaec39c: ldr             x2, [fp, #0x20]
    // 0xaec3a0: ldr             x3, [fp, #0x18]
    // 0xaec3a4: LoadField: r4 = r3->field_53
    //     0xaec3a4: ldur            w4, [x3, #0x53]
    // 0xaec3a8: DecompressPointer r4
    //     0xaec3a8: add             x4, x4, HEAP, lsl #32
    // 0xaec3ac: stur            x4, [fp, #-0x98]
    // 0xaec3b0: LoadField: r5 = r2->field_57
    //     0xaec3b0: ldur            w5, [x2, #0x57]
    // 0xaec3b4: DecompressPointer r5
    //     0xaec3b4: add             x5, x5, HEAP, lsl #32
    // 0xaec3b8: cmp             w5, NULL
    // 0xaec3bc: b.ne            #0xaec3cc
    // 0xaec3c0: LoadField: r6 = r3->field_57
    //     0xaec3c0: ldur            w6, [x3, #0x57]
    // 0xaec3c4: DecompressPointer r6
    //     0xaec3c4: add             x6, x6, HEAP, lsl #32
    // 0xaec3c8: b               #0xaec3d0
    // 0xaec3cc: mov             x6, x5
    // 0xaec3d0: LoadField: r7 = r3->field_57
    //     0xaec3d0: ldur            w7, [x3, #0x57]
    // 0xaec3d4: DecompressPointer r7
    //     0xaec3d4: add             x7, x7, HEAP, lsl #32
    // 0xaec3d8: cmp             w7, NULL
    // 0xaec3dc: b.eq            #0xaec3e4
    // 0xaec3e0: mov             x5, x7
    // 0xaec3e4: stp             x5, x6, [SP, #-0x10]!
    // 0xaec3e8: ldr             x16, [fp, #0x10]
    // 0xaec3ec: SaveReg r16
    //     0xaec3ec: str             x16, [SP, #-8]!
    // 0xaec3f0: r0 = lerpDouble()
    //     0xaec3f0: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xaec3f4: add             SP, SP, #0x18
    // 0xaec3f8: mov             x1, x0
    // 0xaec3fc: ldur            x0, [fp, #-0x18]
    // 0xaec400: stur            x1, [fp, #-0xb8]
    // 0xaec404: tbnz            w0, #4, #0xaec420
    // 0xaec408: ldr             x2, [fp, #0x20]
    // 0xaec40c: LoadField: r3 = r2->field_13
    //     0xaec40c: ldur            w3, [x2, #0x13]
    // 0xaec410: DecompressPointer r3
    //     0xaec410: add             x3, x3, HEAP, lsl #32
    // 0xaec414: mov             x4, x3
    // 0xaec418: ldr             x3, [fp, #0x18]
    // 0xaec41c: b               #0xaec430
    // 0xaec420: ldr             x2, [fp, #0x20]
    // 0xaec424: ldr             x3, [fp, #0x18]
    // 0xaec428: LoadField: r4 = r3->field_13
    //     0xaec428: ldur            w4, [x3, #0x13]
    // 0xaec42c: DecompressPointer r4
    //     0xaec42c: add             x4, x4, HEAP, lsl #32
    // 0xaec430: stur            x4, [fp, #-0xb0]
    // 0xaec434: tbnz            w0, #4, #0xaec444
    // 0xaec438: LoadField: r5 = r2->field_17
    //     0xaec438: ldur            w5, [x2, #0x17]
    // 0xaec43c: DecompressPointer r5
    //     0xaec43c: add             x5, x5, HEAP, lsl #32
    // 0xaec440: b               #0xaec44c
    // 0xaec444: LoadField: r5 = r3->field_17
    //     0xaec444: ldur            w5, [x3, #0x17]
    // 0xaec448: DecompressPointer r5
    //     0xaec448: add             x5, x5, HEAP, lsl #32
    // 0xaec44c: stur            x5, [fp, #-0xa8]
    // 0xaec450: tbnz            w0, #4, #0xaec464
    // 0xaec454: LoadField: r0 = r2->field_6b
    //     0xaec454: ldur            w0, [x2, #0x6b]
    // 0xaec458: DecompressPointer r0
    //     0xaec458: add             x0, x0, HEAP, lsl #32
    // 0xaec45c: stur            x0, [fp, #-0x18]
    // 0xaec460: b               #0xaec470
    // 0xaec464: LoadField: r0 = r3->field_6b
    //     0xaec464: ldur            w0, [x3, #0x6b]
    // 0xaec468: DecompressPointer r0
    //     0xaec468: add             x0, x0, HEAP, lsl #32
    // 0xaec46c: stur            x0, [fp, #-0x18]
    // 0xaec470: ldur            x25, [fp, #-0x30]
    // 0xaec474: ldur            x24, [fp, #-0x38]
    // 0xaec478: ldur            x20, [fp, #-0x48]
    // 0xaec47c: ldur            x23, [fp, #-0x40]
    // 0xaec480: ldur            x19, [fp, #-0x50]
    // 0xaec484: ldur            x13, [fp, #-0x60]
    // 0xaec488: ldur            x14, [fp, #-0x58]
    // 0xaec48c: ldur            x11, [fp, #-0x70]
    // 0xaec490: ldur            x12, [fp, #-0x68]
    // 0xaec494: ldur            x10, [fp, #-8]
    // 0xaec498: ldur            x3, [fp, #-0x90]
    // 0xaec49c: ldur            x6, [fp, #-0x88]
    // 0xaec4a0: ldur            x7, [fp, #-0x80]
    // 0xaec4a4: ldur            x8, [fp, #-0x78]
    // 0xaec4a8: ldur            x9, [fp, #-0x20]
    // 0xaec4ac: ldur            x0, [fp, #-0xa0]
    // 0xaec4b0: ldur            x2, [fp, #-0x98]
    // 0xaec4b4: r0 = TextStyle()
    //     0xaec4b4: bl              #0x6cecec  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xaec4b8: ldur            x1, [fp, #-0x10]
    // 0xaec4bc: StoreField: r0->field_7 = r1
    //     0xaec4bc: stur            w1, [x0, #7]
    // 0xaec4c0: ldur            x1, [fp, #-0x28]
    // 0xaec4c4: StoreField: r0->field_b = r1
    //     0xaec4c4: stur            w1, [x0, #0xb]
    // 0xaec4c8: ldur            x1, [fp, #-0x30]
    // 0xaec4cc: StoreField: r0->field_f = r1
    //     0xaec4cc: stur            w1, [x0, #0xf]
    // 0xaec4d0: ldur            x1, [fp, #-0x38]
    // 0xaec4d4: StoreField: r0->field_1f = r1
    //     0xaec4d4: stur            w1, [x0, #0x1f]
    // 0xaec4d8: ldur            x1, [fp, #-0x48]
    // 0xaec4dc: StoreField: r0->field_23 = r1
    //     0xaec4dc: stur            w1, [x0, #0x23]
    // 0xaec4e0: ldur            x1, [fp, #-0x40]
    // 0xaec4e4: StoreField: r0->field_27 = r1
    //     0xaec4e4: stur            w1, [x0, #0x27]
    // 0xaec4e8: ldur            x1, [fp, #-0x50]
    // 0xaec4ec: StoreField: r0->field_2b = r1
    //     0xaec4ec: stur            w1, [x0, #0x2b]
    // 0xaec4f0: ldur            x1, [fp, #-0x60]
    // 0xaec4f4: StoreField: r0->field_2f = r1
    //     0xaec4f4: stur            w1, [x0, #0x2f]
    // 0xaec4f8: ldur            x1, [fp, #-0x58]
    // 0xaec4fc: StoreField: r0->field_33 = r1
    //     0xaec4fc: stur            w1, [x0, #0x33]
    // 0xaec500: ldur            x1, [fp, #-0x70]
    // 0xaec504: StoreField: r0->field_37 = r1
    //     0xaec504: stur            w1, [x0, #0x37]
    // 0xaec508: ldur            x1, [fp, #-0x68]
    // 0xaec50c: StoreField: r0->field_3b = r1
    //     0xaec50c: stur            w1, [x0, #0x3b]
    // 0xaec510: ldur            x1, [fp, #-8]
    // 0xaec514: StoreField: r0->field_43 = r1
    //     0xaec514: stur            w1, [x0, #0x43]
    // 0xaec518: ldur            x1, [fp, #-0x90]
    // 0xaec51c: StoreField: r0->field_47 = r1
    //     0xaec51c: stur            w1, [x0, #0x47]
    // 0xaec520: ldur            x1, [fp, #-0x88]
    // 0xaec524: StoreField: r0->field_5f = r1
    //     0xaec524: stur            w1, [x0, #0x5f]
    // 0xaec528: ldur            x1, [fp, #-0x80]
    // 0xaec52c: StoreField: r0->field_63 = r1
    //     0xaec52c: stur            w1, [x0, #0x63]
    // 0xaec530: ldur            x1, [fp, #-0x78]
    // 0xaec534: StoreField: r0->field_67 = r1
    //     0xaec534: stur            w1, [x0, #0x67]
    // 0xaec538: ldur            x1, [fp, #-0x20]
    // 0xaec53c: StoreField: r0->field_4b = r1
    //     0xaec53c: stur            w1, [x0, #0x4b]
    // 0xaec540: ldur            x1, [fp, #-0xa0]
    // 0xaec544: StoreField: r0->field_4f = r1
    //     0xaec544: stur            w1, [x0, #0x4f]
    // 0xaec548: ldur            x1, [fp, #-0x98]
    // 0xaec54c: StoreField: r0->field_53 = r1
    //     0xaec54c: stur            w1, [x0, #0x53]
    // 0xaec550: ldur            x1, [fp, #-0xb8]
    // 0xaec554: StoreField: r0->field_57 = r1
    //     0xaec554: stur            w1, [x0, #0x57]
    // 0xaec558: ldur            x1, [fp, #-0x18]
    // 0xaec55c: StoreField: r0->field_6b = r1
    //     0xaec55c: stur            w1, [x0, #0x6b]
    // 0xaec560: ldur            x1, [fp, #-0xb0]
    // 0xaec564: StoreField: r0->field_13 = r1
    //     0xaec564: stur            w1, [x0, #0x13]
    // 0xaec568: ldur            x1, [fp, #-0xa8]
    // 0xaec56c: StoreField: r0->field_17 = r1
    //     0xaec56c: stur            w1, [x0, #0x17]
    // 0xaec570: LeaveFrame
    //     0xaec570: mov             SP, fp
    //     0xaec574: ldp             fp, lr, [SP], #0x10
    // 0xaec578: ret
    //     0xaec578: ret             
    // 0xaec57c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaec57c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaec580: b               #0xaeb484
    // 0xaec584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaec584: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaec588: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaec588: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaec58c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaec58c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaec590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaec590: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaec594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaec594: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static TextStyle? lerp(dynamic, TextStyle?, TextStyle?, double) {
    // ** addr: 0xaec598, size: 0x44
    // 0xaec598: EnterFrame
    //     0xaec598: stp             fp, lr, [SP, #-0x10]!
    //     0xaec59c: mov             fp, SP
    // 0xaec5a0: CheckStackOverflow
    //     0xaec5a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaec5a4: cmp             SP, x16
    //     0xaec5a8: b.ls            #0xaec5d4
    // 0xaec5ac: ldr             x16, [fp, #0x20]
    // 0xaec5b0: ldr             lr, [fp, #0x18]
    // 0xaec5b4: stp             lr, x16, [SP, #-0x10]!
    // 0xaec5b8: ldr             x16, [fp, #0x10]
    // 0xaec5bc: SaveReg r16
    //     0xaec5bc: str             x16, [SP, #-8]!
    // 0xaec5c0: r0 = lerp()
    //     0xaec5c0: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xaec5c4: add             SP, SP, #0x18
    // 0xaec5c8: LeaveFrame
    //     0xaec5c8: mov             SP, fp
    //     0xaec5cc: ldp             fp, lr, [SP], #0x10
    // 0xaec5d0: ret
    //     0xaec5d0: ret             
    // 0xaec5d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaec5d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaec5d8: b               #0xaec5ac
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb00658, size: 0x2fc
    // 0xb00658: EnterFrame
    //     0xb00658: stp             fp, lr, [SP, #-0x10]!
    //     0xb0065c: mov             fp, SP
    // 0xb00660: AllocStack(0x88)
    //     0xb00660: sub             SP, SP, #0x88
    // 0xb00664: CheckStackOverflow
    //     0xb00664: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00668: cmp             SP, x16
    //     0xb0066c: b.ls            #0xb0094c
    // 0xb00670: ldr             x0, [fp, #0x10]
    // 0xb00674: LoadField: r1 = r0->field_17
    //     0xb00674: ldur            w1, [x0, #0x17]
    // 0xb00678: DecompressPointer r1
    //     0xb00678: add             x1, x1, HEAP, lsl #32
    // 0xb0067c: LoadField: r2 = r0->field_53
    //     0xb0067c: ldur            w2, [x0, #0x53]
    // 0xb00680: DecompressPointer r2
    //     0xb00680: add             x2, x2, HEAP, lsl #32
    // 0xb00684: stur            x2, [fp, #-0x18]
    // 0xb00688: LoadField: r3 = r0->field_57
    //     0xb00688: ldur            w3, [x0, #0x57]
    // 0xb0068c: DecompressPointer r3
    //     0xb0068c: add             x3, x3, HEAP, lsl #32
    // 0xb00690: stur            x3, [fp, #-0x10]
    // 0xb00694: LoadField: r4 = r0->field_13
    //     0xb00694: ldur            w4, [x0, #0x13]
    // 0xb00698: DecompressPointer r4
    //     0xb00698: add             x4, x4, HEAP, lsl #32
    // 0xb0069c: stur            x4, [fp, #-8]
    // 0xb006a0: cmp             w1, NULL
    // 0xb006a4: b.ne            #0xb006b0
    // 0xb006a8: r1 = Null
    //     0xb006a8: mov             x1, NULL
    // 0xb006ac: b               #0xb006dc
    // 0xb006b0: SaveReg r1
    //     0xb006b0: str             x1, [SP, #-8]!
    // 0xb006b4: r0 = hashAll()
    //     0xb006b4: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb006b8: add             SP, SP, #8
    // 0xb006bc: mov             x2, x0
    // 0xb006c0: r0 = BoxInt64Instr(r2)
    //     0xb006c0: sbfiz           x0, x2, #1, #0x1f
    //     0xb006c4: cmp             x2, x0, asr #1
    //     0xb006c8: b.eq            #0xb006d4
    //     0xb006cc: bl              #0xd69bb8
    //     0xb006d0: stur            x2, [x0, #7]
    // 0xb006d4: mov             x1, x0
    // 0xb006d8: ldr             x0, [fp, #0x10]
    // 0xb006dc: LoadField: r2 = r0->field_6b
    //     0xb006dc: ldur            w2, [x0, #0x6b]
    // 0xb006e0: DecompressPointer r2
    //     0xb006e0: add             x2, x2, HEAP, lsl #32
    // 0xb006e4: ldur            x16, [fp, #-0x18]
    // 0xb006e8: ldur            lr, [fp, #-0x10]
    // 0xb006ec: stp             lr, x16, [SP, #-0x10]!
    // 0xb006f0: ldur            x16, [fp, #-8]
    // 0xb006f4: stp             x1, x16, [SP, #-0x10]!
    // 0xb006f8: stp             x2, NULL, [SP, #-0x10]!
    // 0xb006fc: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0xb006fc: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0xb00700: r0 = hash()
    //     0xb00700: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00704: add             SP, SP, #0x30
    // 0xb00708: mov             x1, x0
    // 0xb0070c: ldr             x0, [fp, #0x10]
    // 0xb00710: stur            x1, [fp, #-0x80]
    // 0xb00714: LoadField: r2 = r0->field_5f
    //     0xb00714: ldur            w2, [x0, #0x5f]
    // 0xb00718: DecompressPointer r2
    //     0xb00718: add             x2, x2, HEAP, lsl #32
    // 0xb0071c: LoadField: r3 = r0->field_63
    //     0xb0071c: ldur            w3, [x0, #0x63]
    // 0xb00720: DecompressPointer r3
    //     0xb00720: add             x3, x3, HEAP, lsl #32
    // 0xb00724: stur            x3, [fp, #-0x78]
    // 0xb00728: LoadField: r4 = r0->field_67
    //     0xb00728: ldur            w4, [x0, #0x67]
    // 0xb0072c: DecompressPointer r4
    //     0xb0072c: add             x4, x4, HEAP, lsl #32
    // 0xb00730: stur            x4, [fp, #-0x70]
    // 0xb00734: LoadField: r5 = r0->field_7
    //     0xb00734: ldur            w5, [x0, #7]
    // 0xb00738: DecompressPointer r5
    //     0xb00738: add             x5, x5, HEAP, lsl #32
    // 0xb0073c: stur            x5, [fp, #-0x68]
    // 0xb00740: LoadField: r6 = r0->field_b
    //     0xb00740: ldur            w6, [x0, #0xb]
    // 0xb00744: DecompressPointer r6
    //     0xb00744: add             x6, x6, HEAP, lsl #32
    // 0xb00748: stur            x6, [fp, #-0x60]
    // 0xb0074c: LoadField: r7 = r0->field_f
    //     0xb0074c: ldur            w7, [x0, #0xf]
    // 0xb00750: DecompressPointer r7
    //     0xb00750: add             x7, x7, HEAP, lsl #32
    // 0xb00754: stur            x7, [fp, #-0x58]
    // 0xb00758: LoadField: r8 = r0->field_1f
    //     0xb00758: ldur            w8, [x0, #0x1f]
    // 0xb0075c: DecompressPointer r8
    //     0xb0075c: add             x8, x8, HEAP, lsl #32
    // 0xb00760: stur            x8, [fp, #-0x50]
    // 0xb00764: LoadField: r9 = r0->field_23
    //     0xb00764: ldur            w9, [x0, #0x23]
    // 0xb00768: DecompressPointer r9
    //     0xb00768: add             x9, x9, HEAP, lsl #32
    // 0xb0076c: stur            x9, [fp, #-0x48]
    // 0xb00770: LoadField: r10 = r0->field_27
    //     0xb00770: ldur            w10, [x0, #0x27]
    // 0xb00774: DecompressPointer r10
    //     0xb00774: add             x10, x10, HEAP, lsl #32
    // 0xb00778: stur            x10, [fp, #-0x40]
    // 0xb0077c: LoadField: r11 = r0->field_2b
    //     0xb0077c: ldur            w11, [x0, #0x2b]
    // 0xb00780: DecompressPointer r11
    //     0xb00780: add             x11, x11, HEAP, lsl #32
    // 0xb00784: stur            x11, [fp, #-0x38]
    // 0xb00788: LoadField: r12 = r0->field_2f
    //     0xb00788: ldur            w12, [x0, #0x2f]
    // 0xb0078c: DecompressPointer r12
    //     0xb0078c: add             x12, x12, HEAP, lsl #32
    // 0xb00790: stur            x12, [fp, #-0x30]
    // 0xb00794: LoadField: r13 = r0->field_33
    //     0xb00794: ldur            w13, [x0, #0x33]
    // 0xb00798: DecompressPointer r13
    //     0xb00798: add             x13, x13, HEAP, lsl #32
    // 0xb0079c: stur            x13, [fp, #-0x28]
    // 0xb007a0: LoadField: r14 = r0->field_37
    //     0xb007a0: ldur            w14, [x0, #0x37]
    // 0xb007a4: DecompressPointer r14
    //     0xb007a4: add             x14, x14, HEAP, lsl #32
    // 0xb007a8: stur            x14, [fp, #-0x20]
    // 0xb007ac: LoadField: r19 = r0->field_3b
    //     0xb007ac: ldur            w19, [x0, #0x3b]
    // 0xb007b0: DecompressPointer r19
    //     0xb007b0: add             x19, x19, HEAP, lsl #32
    // 0xb007b4: stur            x19, [fp, #-0x18]
    // 0xb007b8: LoadField: r20 = r0->field_43
    //     0xb007b8: ldur            w20, [x0, #0x43]
    // 0xb007bc: DecompressPointer r20
    //     0xb007bc: add             x20, x20, HEAP, lsl #32
    // 0xb007c0: stur            x20, [fp, #-0x10]
    // 0xb007c4: LoadField: r23 = r0->field_47
    //     0xb007c4: ldur            w23, [x0, #0x47]
    // 0xb007c8: DecompressPointer r23
    //     0xb007c8: add             x23, x23, HEAP, lsl #32
    // 0xb007cc: stur            x23, [fp, #-8]
    // 0xb007d0: cmp             w2, NULL
    // 0xb007d4: b.ne            #0xb007e4
    // 0xb007d8: mov             x0, x3
    // 0xb007dc: r1 = Null
    //     0xb007dc: mov             x1, NULL
    // 0xb007e0: b               #0xb00810
    // 0xb007e4: SaveReg r2
    //     0xb007e4: str             x2, [SP, #-8]!
    // 0xb007e8: r0 = hashAll()
    //     0xb007e8: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb007ec: add             SP, SP, #8
    // 0xb007f0: mov             x2, x0
    // 0xb007f4: r0 = BoxInt64Instr(r2)
    //     0xb007f4: sbfiz           x0, x2, #1, #0x1f
    //     0xb007f8: cmp             x2, x0, asr #1
    //     0xb007fc: b.eq            #0xb00808
    //     0xb00800: bl              #0xd69bb8
    //     0xb00804: stur            x2, [x0, #7]
    // 0xb00808: mov             x1, x0
    // 0xb0080c: ldur            x0, [fp, #-0x78]
    // 0xb00810: stur            x1, [fp, #-0x88]
    // 0xb00814: cmp             w0, NULL
    // 0xb00818: b.ne            #0xb00824
    // 0xb0081c: r1 = Null
    //     0xb0081c: mov             x1, NULL
    // 0xb00820: b               #0xb0084c
    // 0xb00824: SaveReg r0
    //     0xb00824: str             x0, [SP, #-8]!
    // 0xb00828: r0 = hashAll()
    //     0xb00828: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb0082c: add             SP, SP, #8
    // 0xb00830: mov             x2, x0
    // 0xb00834: r0 = BoxInt64Instr(r2)
    //     0xb00834: sbfiz           x0, x2, #1, #0x1f
    //     0xb00838: cmp             x2, x0, asr #1
    //     0xb0083c: b.eq            #0xb00848
    //     0xb00840: bl              #0xd69bb8
    //     0xb00844: stur            x2, [x0, #7]
    // 0xb00848: mov             x1, x0
    // 0xb0084c: ldur            x0, [fp, #-0x70]
    // 0xb00850: stur            x1, [fp, #-0x78]
    // 0xb00854: cmp             w0, NULL
    // 0xb00858: b.ne            #0xb00864
    // 0xb0085c: r3 = Null
    //     0xb0085c: mov             x3, NULL
    // 0xb00860: b               #0xb0088c
    // 0xb00864: SaveReg r0
    //     0xb00864: str             x0, [SP, #-8]!
    // 0xb00868: r0 = hashAll()
    //     0xb00868: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb0086c: add             SP, SP, #8
    // 0xb00870: mov             x2, x0
    // 0xb00874: r0 = BoxInt64Instr(r2)
    //     0xb00874: sbfiz           x0, x2, #1, #0x1f
    //     0xb00878: cmp             x2, x0, asr #1
    //     0xb0087c: b.eq            #0xb00888
    //     0xb00880: bl              #0xd69bb8
    //     0xb00884: stur            x2, [x0, #7]
    // 0xb00888: mov             x3, x0
    // 0xb0088c: ldr             x0, [fp, #0x10]
    // 0xb00890: ldur            x2, [fp, #-0x80]
    // 0xb00894: LoadField: r4 = r0->field_4b
    //     0xb00894: ldur            w4, [x0, #0x4b]
    // 0xb00898: DecompressPointer r4
    //     0xb00898: add             x4, x4, HEAP, lsl #32
    // 0xb0089c: LoadField: r5 = r0->field_4f
    //     0xb0089c: ldur            w5, [x0, #0x4f]
    // 0xb008a0: DecompressPointer r5
    //     0xb008a0: add             x5, x5, HEAP, lsl #32
    // 0xb008a4: r0 = BoxInt64Instr(r2)
    //     0xb008a4: sbfiz           x0, x2, #1, #0x1f
    //     0xb008a8: cmp             x2, x0, asr #1
    //     0xb008ac: b.eq            #0xb008b8
    //     0xb008b0: bl              #0xd69bb8
    //     0xb008b4: stur            x2, [x0, #7]
    // 0xb008b8: ldur            x16, [fp, #-0x68]
    // 0xb008bc: ldur            lr, [fp, #-0x60]
    // 0xb008c0: stp             lr, x16, [SP, #-0x10]!
    // 0xb008c4: ldur            x16, [fp, #-0x58]
    // 0xb008c8: ldur            lr, [fp, #-0x50]
    // 0xb008cc: stp             lr, x16, [SP, #-0x10]!
    // 0xb008d0: ldur            x16, [fp, #-0x48]
    // 0xb008d4: ldur            lr, [fp, #-0x40]
    // 0xb008d8: stp             lr, x16, [SP, #-0x10]!
    // 0xb008dc: ldur            x16, [fp, #-0x38]
    // 0xb008e0: ldur            lr, [fp, #-0x30]
    // 0xb008e4: stp             lr, x16, [SP, #-0x10]!
    // 0xb008e8: ldur            x16, [fp, #-0x28]
    // 0xb008ec: ldur            lr, [fp, #-0x20]
    // 0xb008f0: stp             lr, x16, [SP, #-0x10]!
    // 0xb008f4: ldur            x16, [fp, #-0x18]
    // 0xb008f8: stp             NULL, x16, [SP, #-0x10]!
    // 0xb008fc: ldur            x16, [fp, #-0x10]
    // 0xb00900: ldur            lr, [fp, #-8]
    // 0xb00904: stp             lr, x16, [SP, #-0x10]!
    // 0xb00908: ldur            x16, [fp, #-0x88]
    // 0xb0090c: ldur            lr, [fp, #-0x78]
    // 0xb00910: stp             lr, x16, [SP, #-0x10]!
    // 0xb00914: stp             x4, x3, [SP, #-0x10]!
    // 0xb00918: stp             x0, x5, [SP, #-0x10]!
    // 0xb0091c: r4 = const [0, 0x14, 0x14, 0x14, null]
    //     0xb0091c: ldr             x4, [PP, #0x70d8]  ; [pp+0x70d8] List(5) [0, 0x14, 0x14, 0x14, Null]
    // 0xb00920: r0 = hash()
    //     0xb00920: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00924: add             SP, SP, #0xa0
    // 0xb00928: mov             x2, x0
    // 0xb0092c: r0 = BoxInt64Instr(r2)
    //     0xb0092c: sbfiz           x0, x2, #1, #0x1f
    //     0xb00930: cmp             x2, x0, asr #1
    //     0xb00934: b.eq            #0xb00940
    //     0xb00938: bl              #0xd69bb8
    //     0xb0093c: stur            x2, [x0, #7]
    // 0xb00940: LeaveFrame
    //     0xb00940: mov             SP, fp
    //     0xb00944: ldp             fp, lr, [SP], #0x10
    // 0xb00948: ret
    //     0xb00948: ret             
    // 0xb0094c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0094c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00950: b               #0xb00670
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8b5d0, size: 0x52c
    // 0xc8b5d0: EnterFrame
    //     0xc8b5d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc8b5d4: mov             fp, SP
    // 0xc8b5d8: AllocStack(0x8)
    //     0xc8b5d8: sub             SP, SP, #8
    // 0xc8b5dc: CheckStackOverflow
    //     0xc8b5dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8b5e0: cmp             SP, x16
    //     0xc8b5e4: b.ls            #0xc8baf4
    // 0xc8b5e8: ldr             x1, [fp, #0x10]
    // 0xc8b5ec: cmp             w1, NULL
    // 0xc8b5f0: b.ne            #0xc8b604
    // 0xc8b5f4: r0 = false
    //     0xc8b5f4: add             x0, NULL, #0x30  ; false
    // 0xc8b5f8: LeaveFrame
    //     0xc8b5f8: mov             SP, fp
    //     0xc8b5fc: ldp             fp, lr, [SP], #0x10
    // 0xc8b600: ret
    //     0xc8b600: ret             
    // 0xc8b604: ldr             x2, [fp, #0x18]
    // 0xc8b608: cmp             w2, w1
    // 0xc8b60c: b.ne            #0xc8b620
    // 0xc8b610: r0 = true
    //     0xc8b610: add             x0, NULL, #0x20  ; true
    // 0xc8b614: LeaveFrame
    //     0xc8b614: mov             SP, fp
    //     0xc8b618: ldp             fp, lr, [SP], #0x10
    // 0xc8b61c: ret
    //     0xc8b61c: ret             
    // 0xc8b620: r0 = 59
    //     0xc8b620: mov             x0, #0x3b
    // 0xc8b624: branchIfSmi(r1, 0xc8b630)
    //     0xc8b624: tbz             w1, #0, #0xc8b630
    // 0xc8b628: r0 = LoadClassIdInstr(r1)
    //     0xc8b628: ldur            x0, [x1, #-1]
    //     0xc8b62c: ubfx            x0, x0, #0xc, #0x14
    // 0xc8b630: SaveReg r1
    //     0xc8b630: str             x1, [SP, #-8]!
    // 0xc8b634: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8b634: mov             x17, #0x57c5
    //     0xc8b638: add             lr, x0, x17
    //     0xc8b63c: ldr             lr, [x21, lr, lsl #3]
    //     0xc8b640: blr             lr
    // 0xc8b644: add             SP, SP, #8
    // 0xc8b648: stur            x0, [fp, #-8]
    // 0xc8b64c: ldr             x16, [fp, #0x18]
    // 0xc8b650: SaveReg r16
    //     0xc8b650: str             x16, [SP, #-8]!
    // 0xc8b654: r0 = runtimeType()
    //     0xc8b654: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc8b658: add             SP, SP, #8
    // 0xc8b65c: mov             x1, x0
    // 0xc8b660: ldur            x0, [fp, #-8]
    // 0xc8b664: r2 = LoadClassIdInstr(r0)
    //     0xc8b664: ldur            x2, [x0, #-1]
    //     0xc8b668: ubfx            x2, x2, #0xc, #0x14
    // 0xc8b66c: stp             x1, x0, [SP, #-0x10]!
    // 0xc8b670: mov             x0, x2
    // 0xc8b674: mov             lr, x0
    // 0xc8b678: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b67c: blr             lr
    // 0xc8b680: add             SP, SP, #0x10
    // 0xc8b684: tbz             w0, #4, #0xc8b698
    // 0xc8b688: r0 = false
    //     0xc8b688: add             x0, NULL, #0x30  ; false
    // 0xc8b68c: LeaveFrame
    //     0xc8b68c: mov             SP, fp
    //     0xc8b690: ldp             fp, lr, [SP], #0x10
    // 0xc8b694: ret
    //     0xc8b694: ret             
    // 0xc8b698: ldr             x1, [fp, #0x10]
    // 0xc8b69c: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8b69c: mov             x0, #0x76
    //     0xc8b6a0: tbz             w1, #0, #0xc8b6b0
    //     0xc8b6a4: ldur            x0, [x1, #-1]
    //     0xc8b6a8: ubfx            x0, x0, #0xc, #0x14
    //     0xc8b6ac: lsl             x0, x0, #1
    // 0xc8b6b0: r2 = LoadInt32Instr(r0)
    //     0xc8b6b0: sbfx            x2, x0, #1, #0x1f
    // 0xc8b6b4: cmp             x2, #0xae3
    // 0xc8b6b8: b.lt            #0xc8bae4
    // 0xc8b6bc: cmp             x2, #0xae5
    // 0xc8b6c0: b.gt            #0xc8bae4
    // 0xc8b6c4: ldr             x2, [fp, #0x18]
    // 0xc8b6c8: LoadField: r0 = r1->field_7
    //     0xc8b6c8: ldur            w0, [x1, #7]
    // 0xc8b6cc: DecompressPointer r0
    //     0xc8b6cc: add             x0, x0, HEAP, lsl #32
    // 0xc8b6d0: LoadField: r3 = r2->field_7
    //     0xc8b6d0: ldur            w3, [x2, #7]
    // 0xc8b6d4: DecompressPointer r3
    //     0xc8b6d4: add             x3, x3, HEAP, lsl #32
    // 0xc8b6d8: cmp             w0, w3
    // 0xc8b6dc: b.ne            #0xc8bae4
    // 0xc8b6e0: LoadField: r0 = r1->field_b
    //     0xc8b6e0: ldur            w0, [x1, #0xb]
    // 0xc8b6e4: DecompressPointer r0
    //     0xc8b6e4: add             x0, x0, HEAP, lsl #32
    // 0xc8b6e8: LoadField: r3 = r2->field_b
    //     0xc8b6e8: ldur            w3, [x2, #0xb]
    // 0xc8b6ec: DecompressPointer r3
    //     0xc8b6ec: add             x3, x3, HEAP, lsl #32
    // 0xc8b6f0: r4 = LoadClassIdInstr(r0)
    //     0xc8b6f0: ldur            x4, [x0, #-1]
    //     0xc8b6f4: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b6f8: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b6fc: mov             x0, x4
    // 0xc8b700: mov             lr, x0
    // 0xc8b704: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b708: blr             lr
    // 0xc8b70c: add             SP, SP, #0x10
    // 0xc8b710: tbnz            w0, #4, #0xc8bae4
    // 0xc8b714: ldr             x2, [fp, #0x18]
    // 0xc8b718: ldr             x1, [fp, #0x10]
    // 0xc8b71c: LoadField: r0 = r1->field_f
    //     0xc8b71c: ldur            w0, [x1, #0xf]
    // 0xc8b720: DecompressPointer r0
    //     0xc8b720: add             x0, x0, HEAP, lsl #32
    // 0xc8b724: LoadField: r3 = r2->field_f
    //     0xc8b724: ldur            w3, [x2, #0xf]
    // 0xc8b728: DecompressPointer r3
    //     0xc8b728: add             x3, x3, HEAP, lsl #32
    // 0xc8b72c: r4 = LoadClassIdInstr(r0)
    //     0xc8b72c: ldur            x4, [x0, #-1]
    //     0xc8b730: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b734: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b738: mov             x0, x4
    // 0xc8b73c: mov             lr, x0
    // 0xc8b740: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b744: blr             lr
    // 0xc8b748: add             SP, SP, #0x10
    // 0xc8b74c: tbnz            w0, #4, #0xc8bae4
    // 0xc8b750: ldr             x2, [fp, #0x18]
    // 0xc8b754: ldr             x1, [fp, #0x10]
    // 0xc8b758: LoadField: r0 = r1->field_1f
    //     0xc8b758: ldur            w0, [x1, #0x1f]
    // 0xc8b75c: DecompressPointer r0
    //     0xc8b75c: add             x0, x0, HEAP, lsl #32
    // 0xc8b760: LoadField: r3 = r2->field_1f
    //     0xc8b760: ldur            w3, [x2, #0x1f]
    // 0xc8b764: DecompressPointer r3
    //     0xc8b764: add             x3, x3, HEAP, lsl #32
    // 0xc8b768: r4 = LoadClassIdInstr(r0)
    //     0xc8b768: ldur            x4, [x0, #-1]
    //     0xc8b76c: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b770: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b774: mov             x0, x4
    // 0xc8b778: mov             lr, x0
    // 0xc8b77c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b780: blr             lr
    // 0xc8b784: add             SP, SP, #0x10
    // 0xc8b788: tbnz            w0, #4, #0xc8bae4
    // 0xc8b78c: ldr             x2, [fp, #0x18]
    // 0xc8b790: ldr             x1, [fp, #0x10]
    // 0xc8b794: LoadField: r0 = r1->field_23
    //     0xc8b794: ldur            w0, [x1, #0x23]
    // 0xc8b798: DecompressPointer r0
    //     0xc8b798: add             x0, x0, HEAP, lsl #32
    // 0xc8b79c: LoadField: r3 = r2->field_23
    //     0xc8b79c: ldur            w3, [x2, #0x23]
    // 0xc8b7a0: DecompressPointer r3
    //     0xc8b7a0: add             x3, x3, HEAP, lsl #32
    // 0xc8b7a4: cmp             w0, w3
    // 0xc8b7a8: b.ne            #0xc8bae4
    // 0xc8b7ac: LoadField: r0 = r1->field_27
    //     0xc8b7ac: ldur            w0, [x1, #0x27]
    // 0xc8b7b0: DecompressPointer r0
    //     0xc8b7b0: add             x0, x0, HEAP, lsl #32
    // 0xc8b7b4: LoadField: r3 = r2->field_27
    //     0xc8b7b4: ldur            w3, [x2, #0x27]
    // 0xc8b7b8: DecompressPointer r3
    //     0xc8b7b8: add             x3, x3, HEAP, lsl #32
    // 0xc8b7bc: cmp             w0, w3
    // 0xc8b7c0: b.ne            #0xc8bae4
    // 0xc8b7c4: LoadField: r0 = r1->field_2b
    //     0xc8b7c4: ldur            w0, [x1, #0x2b]
    // 0xc8b7c8: DecompressPointer r0
    //     0xc8b7c8: add             x0, x0, HEAP, lsl #32
    // 0xc8b7cc: LoadField: r3 = r2->field_2b
    //     0xc8b7cc: ldur            w3, [x2, #0x2b]
    // 0xc8b7d0: DecompressPointer r3
    //     0xc8b7d0: add             x3, x3, HEAP, lsl #32
    // 0xc8b7d4: r4 = LoadClassIdInstr(r0)
    //     0xc8b7d4: ldur            x4, [x0, #-1]
    //     0xc8b7d8: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b7dc: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b7e0: mov             x0, x4
    // 0xc8b7e4: mov             lr, x0
    // 0xc8b7e8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b7ec: blr             lr
    // 0xc8b7f0: add             SP, SP, #0x10
    // 0xc8b7f4: tbnz            w0, #4, #0xc8bae4
    // 0xc8b7f8: ldr             x2, [fp, #0x18]
    // 0xc8b7fc: ldr             x1, [fp, #0x10]
    // 0xc8b800: LoadField: r0 = r1->field_2f
    //     0xc8b800: ldur            w0, [x1, #0x2f]
    // 0xc8b804: DecompressPointer r0
    //     0xc8b804: add             x0, x0, HEAP, lsl #32
    // 0xc8b808: LoadField: r3 = r2->field_2f
    //     0xc8b808: ldur            w3, [x2, #0x2f]
    // 0xc8b80c: DecompressPointer r3
    //     0xc8b80c: add             x3, x3, HEAP, lsl #32
    // 0xc8b810: r4 = LoadClassIdInstr(r0)
    //     0xc8b810: ldur            x4, [x0, #-1]
    //     0xc8b814: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b818: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b81c: mov             x0, x4
    // 0xc8b820: mov             lr, x0
    // 0xc8b824: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b828: blr             lr
    // 0xc8b82c: add             SP, SP, #0x10
    // 0xc8b830: tbnz            w0, #4, #0xc8bae4
    // 0xc8b834: ldr             x2, [fp, #0x18]
    // 0xc8b838: ldr             x1, [fp, #0x10]
    // 0xc8b83c: LoadField: r0 = r1->field_33
    //     0xc8b83c: ldur            w0, [x1, #0x33]
    // 0xc8b840: DecompressPointer r0
    //     0xc8b840: add             x0, x0, HEAP, lsl #32
    // 0xc8b844: LoadField: r3 = r2->field_33
    //     0xc8b844: ldur            w3, [x2, #0x33]
    // 0xc8b848: DecompressPointer r3
    //     0xc8b848: add             x3, x3, HEAP, lsl #32
    // 0xc8b84c: cmp             w0, w3
    // 0xc8b850: b.ne            #0xc8bae4
    // 0xc8b854: LoadField: r0 = r1->field_37
    //     0xc8b854: ldur            w0, [x1, #0x37]
    // 0xc8b858: DecompressPointer r0
    //     0xc8b858: add             x0, x0, HEAP, lsl #32
    // 0xc8b85c: LoadField: r3 = r2->field_37
    //     0xc8b85c: ldur            w3, [x2, #0x37]
    // 0xc8b860: DecompressPointer r3
    //     0xc8b860: add             x3, x3, HEAP, lsl #32
    // 0xc8b864: r4 = LoadClassIdInstr(r0)
    //     0xc8b864: ldur            x4, [x0, #-1]
    //     0xc8b868: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b86c: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b870: mov             x0, x4
    // 0xc8b874: mov             lr, x0
    // 0xc8b878: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b87c: blr             lr
    // 0xc8b880: add             SP, SP, #0x10
    // 0xc8b884: tbnz            w0, #4, #0xc8bae4
    // 0xc8b888: ldr             x1, [fp, #0x18]
    // 0xc8b88c: ldr             x0, [fp, #0x10]
    // 0xc8b890: LoadField: r2 = r0->field_3b
    //     0xc8b890: ldur            w2, [x0, #0x3b]
    // 0xc8b894: DecompressPointer r2
    //     0xc8b894: add             x2, x2, HEAP, lsl #32
    // 0xc8b898: LoadField: r3 = r1->field_3b
    //     0xc8b898: ldur            w3, [x1, #0x3b]
    // 0xc8b89c: DecompressPointer r3
    //     0xc8b89c: add             x3, x3, HEAP, lsl #32
    // 0xc8b8a0: cmp             w2, w3
    // 0xc8b8a4: b.ne            #0xc8bae4
    // 0xc8b8a8: LoadField: r2 = r0->field_43
    //     0xc8b8a8: ldur            w2, [x0, #0x43]
    // 0xc8b8ac: DecompressPointer r2
    //     0xc8b8ac: add             x2, x2, HEAP, lsl #32
    // 0xc8b8b0: LoadField: r3 = r1->field_43
    //     0xc8b8b0: ldur            w3, [x1, #0x43]
    // 0xc8b8b4: DecompressPointer r3
    //     0xc8b8b4: add             x3, x3, HEAP, lsl #32
    // 0xc8b8b8: cmp             w2, w3
    // 0xc8b8bc: b.ne            #0xc8bae4
    // 0xc8b8c0: LoadField: r2 = r0->field_47
    //     0xc8b8c0: ldur            w2, [x0, #0x47]
    // 0xc8b8c4: DecompressPointer r2
    //     0xc8b8c4: add             x2, x2, HEAP, lsl #32
    // 0xc8b8c8: LoadField: r3 = r1->field_47
    //     0xc8b8c8: ldur            w3, [x1, #0x47]
    // 0xc8b8cc: DecompressPointer r3
    //     0xc8b8cc: add             x3, x3, HEAP, lsl #32
    // 0xc8b8d0: cmp             w2, w3
    // 0xc8b8d4: b.ne            #0xc8bae4
    // 0xc8b8d8: LoadField: r2 = r0->field_5f
    //     0xc8b8d8: ldur            w2, [x0, #0x5f]
    // 0xc8b8dc: DecompressPointer r2
    //     0xc8b8dc: add             x2, x2, HEAP, lsl #32
    // 0xc8b8e0: LoadField: r3 = r1->field_5f
    //     0xc8b8e0: ldur            w3, [x1, #0x5f]
    // 0xc8b8e4: DecompressPointer r3
    //     0xc8b8e4: add             x3, x3, HEAP, lsl #32
    // 0xc8b8e8: r16 = <Shadow>
    //     0xc8b8e8: add             x16, PP, #0xd, lsl #12  ; [pp+0xde68] TypeArguments: <Shadow>
    //     0xc8b8ec: ldr             x16, [x16, #0xe68]
    // 0xc8b8f0: stp             x2, x16, [SP, #-0x10]!
    // 0xc8b8f4: SaveReg r3
    //     0xc8b8f4: str             x3, [SP, #-8]!
    // 0xc8b8f8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc8b8f8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc8b8fc: r0 = listEquals()
    //     0xc8b8fc: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc8b900: add             SP, SP, #0x18
    // 0xc8b904: tbnz            w0, #4, #0xc8bae4
    // 0xc8b908: ldr             x1, [fp, #0x18]
    // 0xc8b90c: ldr             x0, [fp, #0x10]
    // 0xc8b910: LoadField: r2 = r0->field_63
    //     0xc8b910: ldur            w2, [x0, #0x63]
    // 0xc8b914: DecompressPointer r2
    //     0xc8b914: add             x2, x2, HEAP, lsl #32
    // 0xc8b918: LoadField: r3 = r1->field_63
    //     0xc8b918: ldur            w3, [x1, #0x63]
    // 0xc8b91c: DecompressPointer r3
    //     0xc8b91c: add             x3, x3, HEAP, lsl #32
    // 0xc8b920: r16 = <FontFeature>
    //     0xc8b920: add             x16, PP, #0xd, lsl #12  ; [pp+0xde78] TypeArguments: <FontFeature>
    //     0xc8b924: ldr             x16, [x16, #0xe78]
    // 0xc8b928: stp             x2, x16, [SP, #-0x10]!
    // 0xc8b92c: SaveReg r3
    //     0xc8b92c: str             x3, [SP, #-8]!
    // 0xc8b930: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc8b930: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc8b934: r0 = listEquals()
    //     0xc8b934: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc8b938: add             SP, SP, #0x18
    // 0xc8b93c: tbnz            w0, #4, #0xc8bae4
    // 0xc8b940: ldr             x1, [fp, #0x18]
    // 0xc8b944: ldr             x0, [fp, #0x10]
    // 0xc8b948: LoadField: r2 = r0->field_67
    //     0xc8b948: ldur            w2, [x0, #0x67]
    // 0xc8b94c: DecompressPointer r2
    //     0xc8b94c: add             x2, x2, HEAP, lsl #32
    // 0xc8b950: LoadField: r3 = r1->field_67
    //     0xc8b950: ldur            w3, [x1, #0x67]
    // 0xc8b954: DecompressPointer r3
    //     0xc8b954: add             x3, x3, HEAP, lsl #32
    // 0xc8b958: r16 = <FontVariation>
    //     0xc8b958: add             x16, PP, #0xd, lsl #12  ; [pp+0xde80] TypeArguments: <FontVariation>
    //     0xc8b95c: ldr             x16, [x16, #0xe80]
    // 0xc8b960: stp             x2, x16, [SP, #-0x10]!
    // 0xc8b964: SaveReg r3
    //     0xc8b964: str             x3, [SP, #-8]!
    // 0xc8b968: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc8b968: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc8b96c: r0 = listEquals()
    //     0xc8b96c: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc8b970: add             SP, SP, #0x18
    // 0xc8b974: tbnz            w0, #4, #0xc8bae4
    // 0xc8b978: ldr             x2, [fp, #0x18]
    // 0xc8b97c: ldr             x1, [fp, #0x10]
    // 0xc8b980: LoadField: r0 = r1->field_4b
    //     0xc8b980: ldur            w0, [x1, #0x4b]
    // 0xc8b984: DecompressPointer r0
    //     0xc8b984: add             x0, x0, HEAP, lsl #32
    // 0xc8b988: LoadField: r3 = r2->field_4b
    //     0xc8b988: ldur            w3, [x2, #0x4b]
    // 0xc8b98c: DecompressPointer r3
    //     0xc8b98c: add             x3, x3, HEAP, lsl #32
    // 0xc8b990: r4 = LoadClassIdInstr(r0)
    //     0xc8b990: ldur            x4, [x0, #-1]
    //     0xc8b994: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b998: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b99c: mov             x0, x4
    // 0xc8b9a0: mov             lr, x0
    // 0xc8b9a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b9a8: blr             lr
    // 0xc8b9ac: add             SP, SP, #0x10
    // 0xc8b9b0: tbnz            w0, #4, #0xc8bae4
    // 0xc8b9b4: ldr             x2, [fp, #0x18]
    // 0xc8b9b8: ldr             x1, [fp, #0x10]
    // 0xc8b9bc: LoadField: r0 = r1->field_4f
    //     0xc8b9bc: ldur            w0, [x1, #0x4f]
    // 0xc8b9c0: DecompressPointer r0
    //     0xc8b9c0: add             x0, x0, HEAP, lsl #32
    // 0xc8b9c4: LoadField: r3 = r2->field_4f
    //     0xc8b9c4: ldur            w3, [x2, #0x4f]
    // 0xc8b9c8: DecompressPointer r3
    //     0xc8b9c8: add             x3, x3, HEAP, lsl #32
    // 0xc8b9cc: r4 = LoadClassIdInstr(r0)
    //     0xc8b9cc: ldur            x4, [x0, #-1]
    //     0xc8b9d0: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b9d4: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b9d8: mov             x0, x4
    // 0xc8b9dc: mov             lr, x0
    // 0xc8b9e0: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b9e4: blr             lr
    // 0xc8b9e8: add             SP, SP, #0x10
    // 0xc8b9ec: tbnz            w0, #4, #0xc8bae4
    // 0xc8b9f0: ldr             x2, [fp, #0x18]
    // 0xc8b9f4: ldr             x1, [fp, #0x10]
    // 0xc8b9f8: LoadField: r0 = r1->field_53
    //     0xc8b9f8: ldur            w0, [x1, #0x53]
    // 0xc8b9fc: DecompressPointer r0
    //     0xc8b9fc: add             x0, x0, HEAP, lsl #32
    // 0xc8ba00: LoadField: r3 = r2->field_53
    //     0xc8ba00: ldur            w3, [x2, #0x53]
    // 0xc8ba04: DecompressPointer r3
    //     0xc8ba04: add             x3, x3, HEAP, lsl #32
    // 0xc8ba08: cmp             w0, w3
    // 0xc8ba0c: b.ne            #0xc8bae4
    // 0xc8ba10: LoadField: r0 = r1->field_57
    //     0xc8ba10: ldur            w0, [x1, #0x57]
    // 0xc8ba14: DecompressPointer r0
    //     0xc8ba14: add             x0, x0, HEAP, lsl #32
    // 0xc8ba18: LoadField: r3 = r2->field_57
    //     0xc8ba18: ldur            w3, [x2, #0x57]
    // 0xc8ba1c: DecompressPointer r3
    //     0xc8ba1c: add             x3, x3, HEAP, lsl #32
    // 0xc8ba20: r4 = LoadClassIdInstr(r0)
    //     0xc8ba20: ldur            x4, [x0, #-1]
    //     0xc8ba24: ubfx            x4, x4, #0xc, #0x14
    // 0xc8ba28: stp             x3, x0, [SP, #-0x10]!
    // 0xc8ba2c: mov             x0, x4
    // 0xc8ba30: mov             lr, x0
    // 0xc8ba34: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ba38: blr             lr
    // 0xc8ba3c: add             SP, SP, #0x10
    // 0xc8ba40: tbnz            w0, #4, #0xc8bae4
    // 0xc8ba44: ldr             x2, [fp, #0x18]
    // 0xc8ba48: ldr             x1, [fp, #0x10]
    // 0xc8ba4c: LoadField: r0 = r1->field_13
    //     0xc8ba4c: ldur            w0, [x1, #0x13]
    // 0xc8ba50: DecompressPointer r0
    //     0xc8ba50: add             x0, x0, HEAP, lsl #32
    // 0xc8ba54: LoadField: r3 = r2->field_13
    //     0xc8ba54: ldur            w3, [x2, #0x13]
    // 0xc8ba58: DecompressPointer r3
    //     0xc8ba58: add             x3, x3, HEAP, lsl #32
    // 0xc8ba5c: r4 = LoadClassIdInstr(r0)
    //     0xc8ba5c: ldur            x4, [x0, #-1]
    //     0xc8ba60: ubfx            x4, x4, #0xc, #0x14
    // 0xc8ba64: stp             x3, x0, [SP, #-0x10]!
    // 0xc8ba68: mov             x0, x4
    // 0xc8ba6c: mov             lr, x0
    // 0xc8ba70: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ba74: blr             lr
    // 0xc8ba78: add             SP, SP, #0x10
    // 0xc8ba7c: tbnz            w0, #4, #0xc8bae4
    // 0xc8ba80: ldr             x1, [fp, #0x18]
    // 0xc8ba84: ldr             x0, [fp, #0x10]
    // 0xc8ba88: LoadField: r2 = r0->field_17
    //     0xc8ba88: ldur            w2, [x0, #0x17]
    // 0xc8ba8c: DecompressPointer r2
    //     0xc8ba8c: add             x2, x2, HEAP, lsl #32
    // 0xc8ba90: LoadField: r3 = r1->field_17
    //     0xc8ba90: ldur            w3, [x1, #0x17]
    // 0xc8ba94: DecompressPointer r3
    //     0xc8ba94: add             x3, x3, HEAP, lsl #32
    // 0xc8ba98: r16 = <String>
    //     0xc8ba98: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc8ba9c: stp             x2, x16, [SP, #-0x10]!
    // 0xc8baa0: SaveReg r3
    //     0xc8baa0: str             x3, [SP, #-8]!
    // 0xc8baa4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc8baa4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc8baa8: r0 = listEquals()
    //     0xc8baa8: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc8baac: add             SP, SP, #0x18
    // 0xc8bab0: tbnz            w0, #4, #0xc8bae4
    // 0xc8bab4: ldr             x2, [fp, #0x18]
    // 0xc8bab8: ldr             x1, [fp, #0x10]
    // 0xc8babc: LoadField: r3 = r1->field_6b
    //     0xc8babc: ldur            w3, [x1, #0x6b]
    // 0xc8bac0: DecompressPointer r3
    //     0xc8bac0: add             x3, x3, HEAP, lsl #32
    // 0xc8bac4: LoadField: r1 = r2->field_6b
    //     0xc8bac4: ldur            w1, [x2, #0x6b]
    // 0xc8bac8: DecompressPointer r1
    //     0xc8bac8: add             x1, x1, HEAP, lsl #32
    // 0xc8bacc: cmp             w3, w1
    // 0xc8bad0: r16 = true
    //     0xc8bad0: add             x16, NULL, #0x20  ; true
    // 0xc8bad4: r17 = false
    //     0xc8bad4: add             x17, NULL, #0x30  ; false
    // 0xc8bad8: csel            x2, x16, x17, eq
    // 0xc8badc: mov             x0, x2
    // 0xc8bae0: b               #0xc8bae8
    // 0xc8bae4: r0 = false
    //     0xc8bae4: add             x0, NULL, #0x30  ; false
    // 0xc8bae8: LeaveFrame
    //     0xc8bae8: mov             SP, fp
    //     0xc8baec: ldp             fp, lr, [SP], #0x10
    // 0xc8baf0: ret
    //     0xc8baf0: ret             
    // 0xc8baf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8baf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8baf8: b               #0xc8b5e8
  }
}

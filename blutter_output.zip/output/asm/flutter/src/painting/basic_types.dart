// lib: , url: package:flutter/src/painting/basic_types.dart

// class id: 1049345, size: 0x8
class :: {
}

// class id: 5937, size: 0x14, field offset: 0x14
enum AxisDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16868, size: 0x5c
    // 0xb16868: EnterFrame
    //     0xb16868: stp             fp, lr, [SP, #-0x10]!
    //     0xb1686c: mov             fp, SP
    // 0xb16870: CheckStackOverflow
    //     0xb16870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16874: cmp             SP, x16
    //     0xb16878: b.ls            #0xb168bc
    // 0xb1687c: r1 = Null
    //     0xb1687c: mov             x1, NULL
    // 0xb16880: r2 = 4
    //     0xb16880: mov             x2, #4
    // 0xb16884: r0 = AllocateArray()
    //     0xb16884: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16888: r17 = "AxisDirection."
    //     0xb16888: add             x17, PP, #0x21, lsl #12  ; [pp+0x21d30] "AxisDirection."
    //     0xb1688c: ldr             x17, [x17, #0xd30]
    // 0xb16890: StoreField: r0->field_f = r17
    //     0xb16890: stur            w17, [x0, #0xf]
    // 0xb16894: ldr             x1, [fp, #0x10]
    // 0xb16898: LoadField: r2 = r1->field_f
    //     0xb16898: ldur            w2, [x1, #0xf]
    // 0xb1689c: DecompressPointer r2
    //     0xb1689c: add             x2, x2, HEAP, lsl #32
    // 0xb168a0: StoreField: r0->field_13 = r2
    //     0xb168a0: stur            w2, [x0, #0x13]
    // 0xb168a4: SaveReg r0
    //     0xb168a4: str             x0, [SP, #-8]!
    // 0xb168a8: r0 = _interpolate()
    //     0xb168a8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb168ac: add             SP, SP, #8
    // 0xb168b0: LeaveFrame
    //     0xb168b0: mov             SP, fp
    //     0xb168b4: ldp             fp, lr, [SP], #0x10
    // 0xb168b8: ret
    //     0xb168b8: ret             
    // 0xb168bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb168bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb168c0: b               #0xb1687c
  }
}

// class id: 5938, size: 0x14, field offset: 0x14
enum VerticalDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb1680c, size: 0x5c
    // 0xb1680c: EnterFrame
    //     0xb1680c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16810: mov             fp, SP
    // 0xb16814: CheckStackOverflow
    //     0xb16814: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16818: cmp             SP, x16
    //     0xb1681c: b.ls            #0xb16860
    // 0xb16820: r1 = Null
    //     0xb16820: mov             x1, NULL
    // 0xb16824: r2 = 4
    //     0xb16824: mov             x2, #4
    // 0xb16828: r0 = AllocateArray()
    //     0xb16828: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1682c: r17 = "VerticalDirection."
    //     0xb1682c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15270] "VerticalDirection."
    //     0xb16830: ldr             x17, [x17, #0x270]
    // 0xb16834: StoreField: r0->field_f = r17
    //     0xb16834: stur            w17, [x0, #0xf]
    // 0xb16838: ldr             x1, [fp, #0x10]
    // 0xb1683c: LoadField: r2 = r1->field_f
    //     0xb1683c: ldur            w2, [x1, #0xf]
    // 0xb16840: DecompressPointer r2
    //     0xb16840: add             x2, x2, HEAP, lsl #32
    // 0xb16844: StoreField: r0->field_13 = r2
    //     0xb16844: stur            w2, [x0, #0x13]
    // 0xb16848: SaveReg r0
    //     0xb16848: str             x0, [SP, #-8]!
    // 0xb1684c: r0 = _interpolate()
    //     0xb1684c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16850: add             SP, SP, #8
    // 0xb16854: LeaveFrame
    //     0xb16854: mov             SP, fp
    //     0xb16858: ldp             fp, lr, [SP], #0x10
    // 0xb1685c: ret
    //     0xb1685c: ret             
    // 0xb16860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16860: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16864: b               #0xb16820
  }
}

// class id: 5939, size: 0x14, field offset: 0x14
enum Axis extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb167b0, size: 0x5c
    // 0xb167b0: EnterFrame
    //     0xb167b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb167b4: mov             fp, SP
    // 0xb167b8: CheckStackOverflow
    //     0xb167b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb167bc: cmp             SP, x16
    //     0xb167c0: b.ls            #0xb16804
    // 0xb167c4: r1 = Null
    //     0xb167c4: mov             x1, NULL
    // 0xb167c8: r2 = 4
    //     0xb167c8: mov             x2, #4
    // 0xb167cc: r0 = AllocateArray()
    //     0xb167cc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb167d0: r17 = "Axis."
    //     0xb167d0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15278] "Axis."
    //     0xb167d4: ldr             x17, [x17, #0x278]
    // 0xb167d8: StoreField: r0->field_f = r17
    //     0xb167d8: stur            w17, [x0, #0xf]
    // 0xb167dc: ldr             x1, [fp, #0x10]
    // 0xb167e0: LoadField: r2 = r1->field_f
    //     0xb167e0: ldur            w2, [x1, #0xf]
    // 0xb167e4: DecompressPointer r2
    //     0xb167e4: add             x2, x2, HEAP, lsl #32
    // 0xb167e8: StoreField: r0->field_13 = r2
    //     0xb167e8: stur            w2, [x0, #0x13]
    // 0xb167ec: SaveReg r0
    //     0xb167ec: str             x0, [SP, #-8]!
    // 0xb167f0: r0 = _interpolate()
    //     0xb167f0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb167f4: add             SP, SP, #8
    // 0xb167f8: LeaveFrame
    //     0xb167f8: mov             SP, fp
    //     0xb167fc: ldp             fp, lr, [SP], #0x10
    // 0xb16800: ret
    //     0xb16800: ret             
    // 0xb16804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16808: b               #0xb167c4
  }
}

// class id: 5940, size: 0x14, field offset: 0x14
enum RenderComparison extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16754, size: 0x5c
    // 0xb16754: EnterFrame
    //     0xb16754: stp             fp, lr, [SP, #-0x10]!
    //     0xb16758: mov             fp, SP
    // 0xb1675c: CheckStackOverflow
    //     0xb1675c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16760: cmp             SP, x16
    //     0xb16764: b.ls            #0xb167a8
    // 0xb16768: r1 = Null
    //     0xb16768: mov             x1, NULL
    // 0xb1676c: r2 = 4
    //     0xb1676c: mov             x2, #4
    // 0xb16770: r0 = AllocateArray()
    //     0xb16770: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16774: r17 = "RenderComparison."
    //     0xb16774: add             x17, PP, #0x21, lsl #12  ; [pp+0x21d38] "RenderComparison."
    //     0xb16778: ldr             x17, [x17, #0xd38]
    // 0xb1677c: StoreField: r0->field_f = r17
    //     0xb1677c: stur            w17, [x0, #0xf]
    // 0xb16780: ldr             x1, [fp, #0x10]
    // 0xb16784: LoadField: r2 = r1->field_f
    //     0xb16784: ldur            w2, [x1, #0xf]
    // 0xb16788: DecompressPointer r2
    //     0xb16788: add             x2, x2, HEAP, lsl #32
    // 0xb1678c: StoreField: r0->field_13 = r2
    //     0xb1678c: stur            w2, [x0, #0x13]
    // 0xb16790: SaveReg r0
    //     0xb16790: str             x0, [SP, #-8]!
    // 0xb16794: r0 = _interpolate()
    //     0xb16794: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16798: add             SP, SP, #8
    // 0xb1679c: LeaveFrame
    //     0xb1679c: mov             SP, fp
    //     0xb167a0: ldp             fp, lr, [SP], #0x10
    // 0xb167a4: ret
    //     0xb167a4: ret             
    // 0xb167a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb167a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb167ac: b               #0xb16768
  }
}

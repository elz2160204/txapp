// lib: , url: package:flutter/src/painting/circle_border.dart

// class id: 1049354, size: 0x8
class :: {
}

// class id: 2180, size: 0x14, field offset: 0xc
//   const constructor, 
class CircleBorder extends OutlinedBorder {

  BorderSide field_8;
  _Mint field_c;

  _ lerpTo(/* No info */) {
    // ** addr: 0x70e554, size: 0x208
    // 0x70e554: EnterFrame
    //     0x70e554: stp             fp, lr, [SP, #-0x10]!
    //     0x70e558: mov             fp, SP
    // 0x70e55c: AllocStack(0x10)
    //     0x70e55c: sub             SP, SP, #0x10
    // 0x70e560: CheckStackOverflow
    //     0x70e560: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70e564: cmp             SP, x16
    //     0x70e568: b.ls            #0x70e6f0
    // 0x70e56c: ldr             x0, [fp, #0x18]
    // 0x70e570: r1 = LoadClassIdInstr(r0)
    //     0x70e570: ldur            x1, [x0, #-1]
    //     0x70e574: ubfx            x1, x1, #0xc, #0x14
    // 0x70e578: lsl             x1, x1, #1
    // 0x70e57c: r17 = 4360
    //     0x70e57c: mov             x17, #0x1108
    // 0x70e580: cmp             w1, w17
    // 0x70e584: b.ne            #0x70e6c8
    // 0x70e588: ldr             x1, [fp, #0x20]
    // 0x70e58c: ldr             d0, [fp, #0x10]
    // 0x70e590: LoadField: r2 = r1->field_7
    //     0x70e590: ldur            w2, [x1, #7]
    // 0x70e594: DecompressPointer r2
    //     0x70e594: add             x2, x2, HEAP, lsl #32
    // 0x70e598: LoadField: r3 = r0->field_7
    //     0x70e598: ldur            w3, [x0, #7]
    // 0x70e59c: DecompressPointer r3
    //     0x70e59c: add             x3, x3, HEAP, lsl #32
    // 0x70e5a0: stp             x3, x2, [SP, #-0x10]!
    // 0x70e5a4: SaveReg d0
    //     0x70e5a4: str             d0, [SP, #-8]!
    // 0x70e5a8: r0 = lerp()
    //     0x70e5a8: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70e5ac: add             SP, SP, #0x18
    // 0x70e5b0: mov             x1, x0
    // 0x70e5b4: ldr             x0, [fp, #0x20]
    // 0x70e5b8: stur            x1, [fp, #-8]
    // 0x70e5bc: LoadField: d0 = r0->field_b
    //     0x70e5bc: ldur            d0, [x0, #0xb]
    // 0x70e5c0: ldr             x2, [fp, #0x18]
    // 0x70e5c4: LoadField: d1 = r2->field_b
    //     0x70e5c4: ldur            d1, [x2, #0xb]
    // 0x70e5c8: ldr             d2, [fp, #0x10]
    // 0x70e5cc: r0 = inline_Allocate_Double()
    //     0x70e5cc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x70e5d0: add             x0, x0, #0x10
    //     0x70e5d4: cmp             x2, x0
    //     0x70e5d8: b.ls            #0x70e6f8
    //     0x70e5dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x70e5e0: sub             x0, x0, #0xf
    //     0x70e5e4: mov             x2, #0xd108
    //     0x70e5e8: movk            x2, #3, lsl #16
    //     0x70e5ec: stur            x2, [x0, #-1]
    // 0x70e5f0: StoreField: r0->field_7 = d2
    //     0x70e5f0: stur            d2, [x0, #7]
    // 0x70e5f4: r2 = inline_Allocate_Double()
    //     0x70e5f4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x70e5f8: add             x2, x2, #0x10
    //     0x70e5fc: cmp             x3, x2
    //     0x70e600: b.ls            #0x70e718
    //     0x70e604: str             x2, [THR, #0x60]  ; THR::top
    //     0x70e608: sub             x2, x2, #0xf
    //     0x70e60c: mov             x3, #0xd108
    //     0x70e610: movk            x3, #3, lsl #16
    //     0x70e614: stur            x3, [x2, #-1]
    // 0x70e618: StoreField: r2->field_7 = d0
    //     0x70e618: stur            d0, [x2, #7]
    // 0x70e61c: r3 = inline_Allocate_Double()
    //     0x70e61c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x70e620: add             x3, x3, #0x10
    //     0x70e624: cmp             x4, x3
    //     0x70e628: b.ls            #0x70e734
    //     0x70e62c: str             x3, [THR, #0x60]  ; THR::top
    //     0x70e630: sub             x3, x3, #0xf
    //     0x70e634: mov             x4, #0xd108
    //     0x70e638: movk            x4, #3, lsl #16
    //     0x70e63c: stur            x4, [x3, #-1]
    // 0x70e640: StoreField: r3->field_7 = d1
    //     0x70e640: stur            d1, [x3, #7]
    // 0x70e644: stp             x3, x2, [SP, #-0x10]!
    // 0x70e648: SaveReg r0
    //     0x70e648: str             x0, [SP, #-8]!
    // 0x70e64c: r0 = lerpDouble()
    //     0x70e64c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x70e650: add             SP, SP, #0x18
    // 0x70e654: cmp             w0, NULL
    // 0x70e658: b.eq            #0x70e758
    // 0x70e65c: LoadField: d0 = r0->field_7
    //     0x70e65c: ldur            d0, [x0, #7]
    // 0x70e660: d1 = 0.000000
    //     0x70e660: eor             v1.16b, v1.16b, v1.16b
    // 0x70e664: fcmp            d0, d1
    // 0x70e668: b.vs            #0x70e678
    // 0x70e66c: b.ge            #0x70e678
    // 0x70e670: d0 = 0.000000
    //     0x70e670: eor             v0.16b, v0.16b, v0.16b
    // 0x70e674: b               #0x70e6a0
    // 0x70e678: d1 = 1.000000
    //     0x70e678: fmov            d1, #1.00000000
    // 0x70e67c: fcmp            d0, d1
    // 0x70e680: b.vs            #0x70e690
    // 0x70e684: b.le            #0x70e690
    // 0x70e688: d0 = 1.000000
    //     0x70e688: fmov            d0, #1.00000000
    // 0x70e68c: b               #0x70e6a0
    // 0x70e690: LoadField: d1 = r0->field_7
    //     0x70e690: ldur            d1, [x0, #7]
    // 0x70e694: fcmp            d1, d1
    // 0x70e698: b.vc            #0x70e6a0
    // 0x70e69c: d0 = 1.000000
    //     0x70e69c: fmov            d0, #1.00000000
    // 0x70e6a0: ldur            x0, [fp, #-8]
    // 0x70e6a4: stur            d0, [fp, #-0x10]
    // 0x70e6a8: r0 = CircleBorder()
    //     0x70e6a8: bl              #0x70e75c  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0x70e6ac: ldur            d0, [fp, #-0x10]
    // 0x70e6b0: StoreField: r0->field_b = d0
    //     0x70e6b0: stur            d0, [x0, #0xb]
    // 0x70e6b4: ldur            x1, [fp, #-8]
    // 0x70e6b8: StoreField: r0->field_7 = r1
    //     0x70e6b8: stur            w1, [x0, #7]
    // 0x70e6bc: LeaveFrame
    //     0x70e6bc: mov             SP, fp
    //     0x70e6c0: ldp             fp, lr, [SP], #0x10
    // 0x70e6c4: ret
    //     0x70e6c4: ret             
    // 0x70e6c8: mov             x2, x0
    // 0x70e6cc: ldr             x0, [fp, #0x20]
    // 0x70e6d0: ldr             d2, [fp, #0x10]
    // 0x70e6d4: stp             x2, x0, [SP, #-0x10]!
    // 0x70e6d8: SaveReg d2
    //     0x70e6d8: str             d2, [SP, #-8]!
    // 0x70e6dc: r0 = lerpTo()
    //     0x70e6dc: bl              #0x70f880  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x70e6e0: add             SP, SP, #0x18
    // 0x70e6e4: LeaveFrame
    //     0x70e6e4: mov             SP, fp
    //     0x70e6e8: ldp             fp, lr, [SP], #0x10
    // 0x70e6ec: ret
    //     0x70e6ec: ret             
    // 0x70e6f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70e6f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70e6f4: b               #0x70e56c
    // 0x70e6f8: stp             q1, q2, [SP, #-0x20]!
    // 0x70e6fc: SaveReg d0
    //     0x70e6fc: str             q0, [SP, #-0x10]!
    // 0x70e700: SaveReg r1
    //     0x70e700: str             x1, [SP, #-8]!
    // 0x70e704: r0 = AllocateDouble()
    //     0x70e704: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70e708: RestoreReg r1
    //     0x70e708: ldr             x1, [SP], #8
    // 0x70e70c: RestoreReg d0
    //     0x70e70c: ldr             q0, [SP], #0x10
    // 0x70e710: ldp             q1, q2, [SP], #0x20
    // 0x70e714: b               #0x70e5f0
    // 0x70e718: stp             q0, q1, [SP, #-0x20]!
    // 0x70e71c: stp             x0, x1, [SP, #-0x10]!
    // 0x70e720: r0 = AllocateDouble()
    //     0x70e720: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70e724: mov             x2, x0
    // 0x70e728: ldp             x0, x1, [SP], #0x10
    // 0x70e72c: ldp             q0, q1, [SP], #0x20
    // 0x70e730: b               #0x70e618
    // 0x70e734: SaveReg d1
    //     0x70e734: str             q1, [SP, #-0x10]!
    // 0x70e738: stp             x1, x2, [SP, #-0x10]!
    // 0x70e73c: SaveReg r0
    //     0x70e73c: str             x0, [SP, #-8]!
    // 0x70e740: r0 = AllocateDouble()
    //     0x70e740: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x70e744: mov             x3, x0
    // 0x70e748: RestoreReg r0
    //     0x70e748: ldr             x0, [SP], #8
    // 0x70e74c: ldp             x1, x2, [SP], #0x10
    // 0x70e750: RestoreReg d1
    //     0x70e750: ldr             q1, [SP], #0x10
    // 0x70e754: b               #0x70e640
    // 0x70e758: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70e758: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x70fe60, size: 0x214
    // 0x70fe60: EnterFrame
    //     0x70fe60: stp             fp, lr, [SP, #-0x10]!
    //     0x70fe64: mov             fp, SP
    // 0x70fe68: AllocStack(0x10)
    //     0x70fe68: sub             SP, SP, #0x10
    // 0x70fe6c: CheckStackOverflow
    //     0x70fe6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70fe70: cmp             SP, x16
    //     0x70fe74: b.ls            #0x710008
    // 0x70fe78: ldr             x0, [fp, #0x18]
    // 0x70fe7c: r1 = LoadClassIdInstr(r0)
    //     0x70fe7c: ldur            x1, [x0, #-1]
    //     0x70fe80: ubfx            x1, x1, #0xc, #0x14
    // 0x70fe84: lsl             x1, x1, #1
    // 0x70fe88: r17 = 4360
    //     0x70fe88: mov             x17, #0x1108
    // 0x70fe8c: cmp             w1, w17
    // 0x70fe90: b.ne            #0x70ffd4
    // 0x70fe94: ldr             x1, [fp, #0x20]
    // 0x70fe98: ldr             d0, [fp, #0x10]
    // 0x70fe9c: LoadField: r2 = r0->field_7
    //     0x70fe9c: ldur            w2, [x0, #7]
    // 0x70fea0: DecompressPointer r2
    //     0x70fea0: add             x2, x2, HEAP, lsl #32
    // 0x70fea4: LoadField: r3 = r1->field_7
    //     0x70fea4: ldur            w3, [x1, #7]
    // 0x70fea8: DecompressPointer r3
    //     0x70fea8: add             x3, x3, HEAP, lsl #32
    // 0x70feac: stp             x3, x2, [SP, #-0x10]!
    // 0x70feb0: SaveReg d0
    //     0x70feb0: str             d0, [SP, #-8]!
    // 0x70feb4: r0 = lerp()
    //     0x70feb4: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70feb8: add             SP, SP, #0x18
    // 0x70febc: mov             x1, x0
    // 0x70fec0: ldr             x0, [fp, #0x18]
    // 0x70fec4: stur            x1, [fp, #-8]
    // 0x70fec8: LoadField: d0 = r0->field_b
    //     0x70fec8: ldur            d0, [x0, #0xb]
    // 0x70fecc: ldr             x2, [fp, #0x20]
    // 0x70fed0: LoadField: d1 = r2->field_b
    //     0x70fed0: ldur            d1, [x2, #0xb]
    // 0x70fed4: ldr             d2, [fp, #0x10]
    // 0x70fed8: r0 = inline_Allocate_Double()
    //     0x70fed8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x70fedc: add             x0, x0, #0x10
    //     0x70fee0: cmp             x2, x0
    //     0x70fee4: b.ls            #0x710010
    //     0x70fee8: str             x0, [THR, #0x60]  ; THR::top
    //     0x70feec: sub             x0, x0, #0xf
    //     0x70fef0: mov             x2, #0xd108
    //     0x70fef4: movk            x2, #3, lsl #16
    //     0x70fef8: stur            x2, [x0, #-1]
    // 0x70fefc: StoreField: r0->field_7 = d2
    //     0x70fefc: stur            d2, [x0, #7]
    // 0x70ff00: r2 = inline_Allocate_Double()
    //     0x70ff00: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x70ff04: add             x2, x2, #0x10
    //     0x70ff08: cmp             x3, x2
    //     0x70ff0c: b.ls            #0x710030
    //     0x70ff10: str             x2, [THR, #0x60]  ; THR::top
    //     0x70ff14: sub             x2, x2, #0xf
    //     0x70ff18: mov             x3, #0xd108
    //     0x70ff1c: movk            x3, #3, lsl #16
    //     0x70ff20: stur            x3, [x2, #-1]
    // 0x70ff24: StoreField: r2->field_7 = d0
    //     0x70ff24: stur            d0, [x2, #7]
    // 0x70ff28: r3 = inline_Allocate_Double()
    //     0x70ff28: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x70ff2c: add             x3, x3, #0x10
    //     0x70ff30: cmp             x4, x3
    //     0x70ff34: b.ls            #0x71004c
    //     0x70ff38: str             x3, [THR, #0x60]  ; THR::top
    //     0x70ff3c: sub             x3, x3, #0xf
    //     0x70ff40: mov             x4, #0xd108
    //     0x70ff44: movk            x4, #3, lsl #16
    //     0x70ff48: stur            x4, [x3, #-1]
    // 0x70ff4c: StoreField: r3->field_7 = d1
    //     0x70ff4c: stur            d1, [x3, #7]
    // 0x70ff50: stp             x3, x2, [SP, #-0x10]!
    // 0x70ff54: SaveReg r0
    //     0x70ff54: str             x0, [SP, #-8]!
    // 0x70ff58: r0 = lerpDouble()
    //     0x70ff58: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x70ff5c: add             SP, SP, #0x18
    // 0x70ff60: cmp             w0, NULL
    // 0x70ff64: b.eq            #0x710070
    // 0x70ff68: LoadField: d0 = r0->field_7
    //     0x70ff68: ldur            d0, [x0, #7]
    // 0x70ff6c: d1 = 0.000000
    //     0x70ff6c: eor             v1.16b, v1.16b, v1.16b
    // 0x70ff70: fcmp            d0, d1
    // 0x70ff74: b.vs            #0x70ff84
    // 0x70ff78: b.ge            #0x70ff84
    // 0x70ff7c: d0 = 0.000000
    //     0x70ff7c: eor             v0.16b, v0.16b, v0.16b
    // 0x70ff80: b               #0x70ffac
    // 0x70ff84: d1 = 1.000000
    //     0x70ff84: fmov            d1, #1.00000000
    // 0x70ff88: fcmp            d0, d1
    // 0x70ff8c: b.vs            #0x70ff9c
    // 0x70ff90: b.le            #0x70ff9c
    // 0x70ff94: d0 = 1.000000
    //     0x70ff94: fmov            d0, #1.00000000
    // 0x70ff98: b               #0x70ffac
    // 0x70ff9c: LoadField: d1 = r0->field_7
    //     0x70ff9c: ldur            d1, [x0, #7]
    // 0x70ffa0: fcmp            d1, d1
    // 0x70ffa4: b.vc            #0x70ffac
    // 0x70ffa8: d0 = 1.000000
    //     0x70ffa8: fmov            d0, #1.00000000
    // 0x70ffac: ldur            x0, [fp, #-8]
    // 0x70ffb0: stur            d0, [fp, #-0x10]
    // 0x70ffb4: r0 = CircleBorder()
    //     0x70ffb4: bl              #0x70e75c  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0x70ffb8: ldur            d0, [fp, #-0x10]
    // 0x70ffbc: StoreField: r0->field_b = d0
    //     0x70ffbc: stur            d0, [x0, #0xb]
    // 0x70ffc0: ldur            x1, [fp, #-8]
    // 0x70ffc4: StoreField: r0->field_7 = r1
    //     0x70ffc4: stur            w1, [x0, #7]
    // 0x70ffc8: LeaveFrame
    //     0x70ffc8: mov             SP, fp
    //     0x70ffcc: ldp             fp, lr, [SP], #0x10
    // 0x70ffd0: ret
    //     0x70ffd0: ret             
    // 0x70ffd4: ldr             x2, [fp, #0x20]
    // 0x70ffd8: ldr             d2, [fp, #0x10]
    // 0x70ffdc: cmp             w0, NULL
    // 0x70ffe0: b.ne            #0x70fff8
    // 0x70ffe4: SaveReg r2
    //     0x70ffe4: str             x2, [SP, #-8]!
    // 0x70ffe8: SaveReg d2
    //     0x70ffe8: str             d2, [SP, #-8]!
    // 0x70ffec: r0 = scale()
    //     0x70ffec: bl              #0xcf8524  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::scale
    // 0x70fff0: add             SP, SP, #0x10
    // 0x70fff4: b               #0x70fffc
    // 0x70fff8: r0 = Null
    //     0x70fff8: mov             x0, NULL
    // 0x70fffc: LeaveFrame
    //     0x70fffc: mov             SP, fp
    //     0x710000: ldp             fp, lr, [SP], #0x10
    // 0x710004: ret
    //     0x710004: ret             
    // 0x710008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x710008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71000c: b               #0x70fe78
    // 0x710010: stp             q1, q2, [SP, #-0x20]!
    // 0x710014: SaveReg d0
    //     0x710014: str             q0, [SP, #-0x10]!
    // 0x710018: SaveReg r1
    //     0x710018: str             x1, [SP, #-8]!
    // 0x71001c: r0 = AllocateDouble()
    //     0x71001c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x710020: RestoreReg r1
    //     0x710020: ldr             x1, [SP], #8
    // 0x710024: RestoreReg d0
    //     0x710024: ldr             q0, [SP], #0x10
    // 0x710028: ldp             q1, q2, [SP], #0x20
    // 0x71002c: b               #0x70fefc
    // 0x710030: stp             q0, q1, [SP, #-0x20]!
    // 0x710034: stp             x0, x1, [SP, #-0x10]!
    // 0x710038: r0 = AllocateDouble()
    //     0x710038: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x71003c: mov             x2, x0
    // 0x710040: ldp             x0, x1, [SP], #0x10
    // 0x710044: ldp             q0, q1, [SP], #0x20
    // 0x710048: b               #0x70ff24
    // 0x71004c: SaveReg d1
    //     0x71004c: str             q1, [SP, #-0x10]!
    // 0x710050: stp             x1, x2, [SP, #-0x10]!
    // 0x710054: SaveReg r0
    //     0x710054: str             x0, [SP, #-8]!
    // 0x710058: r0 = AllocateDouble()
    //     0x710058: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x71005c: mov             x3, x0
    // 0x710060: RestoreReg r0
    //     0x710060: ldr             x0, [SP], #8
    // 0x710064: ldp             x1, x2, [SP], #0x10
    // 0x710068: RestoreReg d1
    //     0x710068: ldr             q1, [SP], #0x10
    // 0x71006c: b               #0x70ff4c
    // 0x710070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x710070: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x7177cc, size: 0xc4
    // 0x7177cc: EnterFrame
    //     0x7177cc: stp             fp, lr, [SP, #-0x10]!
    //     0x7177d0: mov             fp, SP
    // 0x7177d4: AllocStack(0x8)
    //     0x7177d4: sub             SP, SP, #8
    // 0x7177d8: d0 = 0.000000
    //     0x7177d8: eor             v0.16b, v0.16b, v0.16b
    // 0x7177dc: CheckStackOverflow
    //     0x7177dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7177e0: cmp             SP, x16
    //     0x7177e4: b.ls            #0x717888
    // 0x7177e8: ldr             x0, [fp, #0x30]
    // 0x7177ec: LoadField: d1 = r0->field_b
    //     0x7177ec: ldur            d1, [x0, #0xb]
    // 0x7177f0: fcmp            d1, d0
    // 0x7177f4: b.vs            #0x717850
    // 0x7177f8: b.ne            #0x717850
    // 0x7177fc: ldr             x16, [fp, #0x20]
    // 0x717800: SaveReg r16
    //     0x717800: str             x16, [SP, #-8]!
    // 0x717804: r0 = center()
    //     0x717804: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x717808: add             SP, SP, #8
    // 0x71780c: stur            x0, [fp, #-8]
    // 0x717810: ldr             x16, [fp, #0x20]
    // 0x717814: SaveReg r16
    //     0x717814: str             x16, [SP, #-8]!
    // 0x717818: r0 = shortestSide()
    //     0x717818: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0x71781c: add             SP, SP, #8
    // 0x717820: mov             v1.16b, v0.16b
    // 0x717824: d0 = 2.000000
    //     0x717824: fmov            d0, #2.00000000
    // 0x717828: fdiv            d2, d1, d0
    // 0x71782c: ldr             x16, [fp, #0x28]
    // 0x717830: ldur            lr, [fp, #-8]
    // 0x717834: stp             lr, x16, [SP, #-0x10]!
    // 0x717838: SaveReg d2
    //     0x717838: str             d2, [SP, #-8]!
    // 0x71783c: ldr             x16, [fp, #0x18]
    // 0x717840: SaveReg r16
    //     0x717840: str             x16, [SP, #-8]!
    // 0x717844: r0 = drawCircle()
    //     0x717844: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0x717848: add             SP, SP, #0x20
    // 0x71784c: b               #0x717878
    // 0x717850: ldr             x16, [fp, #0x20]
    // 0x717854: stp             x16, x0, [SP, #-0x10]!
    // 0x717858: r0 = _adjustRect()
    //     0x717858: bl              #0x717dec  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::_adjustRect
    // 0x71785c: add             SP, SP, #0x10
    // 0x717860: ldr             x16, [fp, #0x28]
    // 0x717864: stp             x0, x16, [SP, #-0x10]!
    // 0x717868: ldr             x16, [fp, #0x18]
    // 0x71786c: SaveReg r16
    //     0x71786c: str             x16, [SP, #-8]!
    // 0x717870: r0 = drawOval()
    //     0x717870: bl              #0x717890  ; [dart:ui] Canvas::drawOval
    // 0x717874: add             SP, SP, #0x18
    // 0x717878: r0 = Null
    //     0x717878: mov             x0, NULL
    // 0x71787c: LeaveFrame
    //     0x71787c: mov             SP, fp
    //     0x717880: ldp             fp, lr, [SP], #0x10
    // 0x717884: ret
    //     0x717884: ret             
    // 0x717888: r0 = StackOverflowSharedWithFPURegs()
    //     0x717888: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x71788c: b               #0x7177e8
  }
  _ _adjustRect(/* No info */) {
    // ** addr: 0x717dec, size: 0x1e0
    // 0x717dec: EnterFrame
    //     0x717dec: stp             fp, lr, [SP, #-0x10]!
    //     0x717df0: mov             fp, SP
    // 0x717df4: AllocStack(0x48)
    //     0x717df4: sub             SP, SP, #0x48
    // 0x717df8: d0 = 0.000000
    //     0x717df8: eor             v0.16b, v0.16b, v0.16b
    // 0x717dfc: CheckStackOverflow
    //     0x717dfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x717e00: cmp             SP, x16
    //     0x717e04: b.ls            #0x717fb4
    // 0x717e08: ldr             x0, [fp, #0x18]
    // 0x717e0c: LoadField: d1 = r0->field_b
    //     0x717e0c: ldur            d1, [x0, #0xb]
    // 0x717e10: fcmp            d1, d0
    // 0x717e14: b.vs            #0x717e24
    // 0x717e18: b.ne            #0x717e24
    // 0x717e1c: ldr             x0, [fp, #0x10]
    // 0x717e20: b               #0x717e5c
    // 0x717e24: ldr             x0, [fp, #0x10]
    // 0x717e28: LoadField: d0 = r0->field_17
    //     0x717e28: ldur            d0, [x0, #0x17]
    // 0x717e2c: stur            d0, [fp, #-0x38]
    // 0x717e30: LoadField: d2 = r0->field_7
    //     0x717e30: ldur            d2, [x0, #7]
    // 0x717e34: stur            d2, [fp, #-0x30]
    // 0x717e38: fsub            d3, d0, d2
    // 0x717e3c: LoadField: d4 = r0->field_1f
    //     0x717e3c: ldur            d4, [x0, #0x1f]
    // 0x717e40: stur            d4, [fp, #-0x48]
    // 0x717e44: LoadField: d5 = r0->field_f
    //     0x717e44: ldur            d5, [x0, #0xf]
    // 0x717e48: stur            d5, [fp, #-0x40]
    // 0x717e4c: fsub            d6, d4, d5
    // 0x717e50: fcmp            d3, d6
    // 0x717e54: b.vs            #0x717ef0
    // 0x717e58: b.ne            #0x717ef0
    // 0x717e5c: SaveReg r0
    //     0x717e5c: str             x0, [SP, #-8]!
    // 0x717e60: r0 = center()
    //     0x717e60: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x717e64: add             SP, SP, #8
    // 0x717e68: stur            x0, [fp, #-8]
    // 0x717e6c: ldr             x16, [fp, #0x10]
    // 0x717e70: SaveReg r16
    //     0x717e70: str             x16, [SP, #-8]!
    // 0x717e74: r0 = shortestSide()
    //     0x717e74: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0x717e78: add             SP, SP, #8
    // 0x717e7c: d7 = 2.000000
    //     0x717e7c: fmov            d7, #2.00000000
    // 0x717e80: fdiv            d1, d0, d7
    // 0x717e84: fmul            d0, d1, d7
    // 0x717e88: stur            d0, [fp, #-0x20]
    // 0x717e8c: r0 = inline_Allocate_Double()
    //     0x717e8c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x717e90: add             x0, x0, #0x10
    //     0x717e94: cmp             x1, x0
    //     0x717e98: b.ls            #0x717fbc
    //     0x717e9c: str             x0, [THR, #0x60]  ; THR::top
    //     0x717ea0: sub             x0, x0, #0xf
    //     0x717ea4: mov             x1, #0xd108
    //     0x717ea8: movk            x1, #3, lsl #16
    //     0x717eac: stur            x1, [x0, #-1]
    // 0x717eb0: StoreField: r0->field_7 = d0
    //     0x717eb0: stur            d0, [x0, #7]
    // 0x717eb4: stur            x0, [fp, #-0x10]
    // 0x717eb8: r0 = Rect()
    //     0x717eb8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x717ebc: stur            x0, [fp, #-0x18]
    // 0x717ec0: ldur            x16, [fp, #-8]
    // 0x717ec4: stp             x16, x0, [SP, #-0x10]!
    // 0x717ec8: ldur            x16, [fp, #-0x10]
    // 0x717ecc: SaveReg r16
    //     0x717ecc: str             x16, [SP, #-8]!
    // 0x717ed0: ldur            d0, [fp, #-0x20]
    // 0x717ed4: SaveReg d0
    //     0x717ed4: str             d0, [SP, #-8]!
    // 0x717ed8: r0 = Rect.fromCenter()
    //     0x717ed8: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0x717edc: add             SP, SP, #0x20
    // 0x717ee0: ldur            x0, [fp, #-0x18]
    // 0x717ee4: LeaveFrame
    //     0x717ee4: mov             SP, fp
    //     0x717ee8: ldp             fp, lr, [SP], #0x10
    // 0x717eec: ret
    //     0x717eec: ret             
    // 0x717ef0: d7 = 2.000000
    //     0x717ef0: fmov            d7, #2.00000000
    // 0x717ef4: fcmp            d3, d6
    // 0x717ef8: b.vs            #0x717f54
    // 0x717efc: b.ge            #0x717f54
    // 0x717f00: d8 = 1.000000
    //     0x717f00: fmov            d8, #1.00000000
    // 0x717f04: fsub            d9, d8, d1
    // 0x717f08: fsub            d1, d6, d3
    // 0x717f0c: fmul            d3, d9, d1
    // 0x717f10: fdiv            d1, d3, d7
    // 0x717f14: fadd            d3, d5, d1
    // 0x717f18: stur            d3, [fp, #-0x28]
    // 0x717f1c: fsub            d5, d4, d1
    // 0x717f20: stur            d5, [fp, #-0x20]
    // 0x717f24: r0 = Rect()
    //     0x717f24: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x717f28: ldur            d0, [fp, #-0x30]
    // 0x717f2c: StoreField: r0->field_7 = d0
    //     0x717f2c: stur            d0, [x0, #7]
    // 0x717f30: ldur            d0, [fp, #-0x28]
    // 0x717f34: StoreField: r0->field_f = d0
    //     0x717f34: stur            d0, [x0, #0xf]
    // 0x717f38: ldur            d2, [fp, #-0x38]
    // 0x717f3c: StoreField: r0->field_17 = d2
    //     0x717f3c: stur            d2, [x0, #0x17]
    // 0x717f40: ldur            d0, [fp, #-0x20]
    // 0x717f44: StoreField: r0->field_1f = d0
    //     0x717f44: stur            d0, [x0, #0x1f]
    // 0x717f48: LeaveFrame
    //     0x717f48: mov             SP, fp
    //     0x717f4c: ldp             fp, lr, [SP], #0x10
    // 0x717f50: ret
    //     0x717f50: ret             
    // 0x717f54: mov             v31.16b, v2.16b
    // 0x717f58: mov             v2.16b, v0.16b
    // 0x717f5c: mov             v0.16b, v31.16b
    // 0x717f60: d8 = 1.000000
    //     0x717f60: fmov            d8, #1.00000000
    // 0x717f64: fsub            d9, d8, d1
    // 0x717f68: fsub            d1, d3, d6
    // 0x717f6c: fmul            d3, d9, d1
    // 0x717f70: fdiv            d1, d3, d7
    // 0x717f74: fadd            d3, d0, d1
    // 0x717f78: stur            d3, [fp, #-0x28]
    // 0x717f7c: fsub            d0, d2, d1
    // 0x717f80: stur            d0, [fp, #-0x20]
    // 0x717f84: r0 = Rect()
    //     0x717f84: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x717f88: ldur            d0, [fp, #-0x28]
    // 0x717f8c: StoreField: r0->field_7 = d0
    //     0x717f8c: stur            d0, [x0, #7]
    // 0x717f90: ldur            d0, [fp, #-0x40]
    // 0x717f94: StoreField: r0->field_f = d0
    //     0x717f94: stur            d0, [x0, #0xf]
    // 0x717f98: ldur            d0, [fp, #-0x20]
    // 0x717f9c: StoreField: r0->field_17 = d0
    //     0x717f9c: stur            d0, [x0, #0x17]
    // 0x717fa0: ldur            d0, [fp, #-0x48]
    // 0x717fa4: StoreField: r0->field_1f = d0
    //     0x717fa4: stur            d0, [x0, #0x1f]
    // 0x717fa8: LeaveFrame
    //     0x717fa8: mov             SP, fp
    //     0x717fac: ldp             fp, lr, [SP], #0x10
    // 0x717fb0: ret
    //     0x717fb0: ret             
    // 0x717fb4: r0 = StackOverflowSharedWithFPURegs()
    //     0x717fb4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x717fb8: b               #0x717e08
    // 0x717fbc: SaveReg d0
    //     0x717fbc: str             q0, [SP, #-0x10]!
    // 0x717fc0: r0 = AllocateDouble()
    //     0x717fc0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x717fc4: RestoreReg d0
    //     0x717fc4: ldr             q0, [SP], #0x10
    // 0x717fc8: b               #0x717eb0
  }
  _ getInnerPath(/* No info */) {
    // ** addr: 0x71abf8, size: 0xd0
    // 0x71abf8: EnterFrame
    //     0x71abf8: stp             fp, lr, [SP, #-0x10]!
    //     0x71abfc: mov             fp, SP
    // 0x71ac00: AllocStack(0x18)
    //     0x71ac00: sub             SP, SP, #0x18
    // 0x71ac04: SetupParameters(CircleBorder this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0x71ac04: mov             x0, x4
    //     0x71ac08: ldur            w1, [x0, #0x13]
    //     0x71ac0c: add             x1, x1, HEAP, lsl #32
    //     0x71ac10: sub             x0, x1, #4
    //     0x71ac14: add             x1, fp, w0, sxtw #2
    //     0x71ac18: ldr             x1, [x1, #0x18]
    //     0x71ac1c: stur            x1, [fp, #-0x10]
    //     0x71ac20: add             x2, fp, w0, sxtw #2
    //     0x71ac24: ldr             x2, [x2, #0x10]
    //     0x71ac28: stur            x2, [fp, #-8]
    // 0x71ac2c: CheckStackOverflow
    //     0x71ac2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71ac30: cmp             SP, x16
    //     0x71ac34: b.ls            #0x71acc0
    // 0x71ac38: r0 = Path()
    //     0x71ac38: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x71ac3c: stur            x0, [fp, #-0x18]
    // 0x71ac40: SaveReg r0
    //     0x71ac40: str             x0, [SP, #-8]!
    // 0x71ac44: r0 = _constructor()
    //     0x71ac44: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x71ac48: add             SP, SP, #8
    // 0x71ac4c: ldur            x16, [fp, #-0x10]
    // 0x71ac50: ldur            lr, [fp, #-8]
    // 0x71ac54: stp             lr, x16, [SP, #-0x10]!
    // 0x71ac58: r0 = _adjustRect()
    //     0x71ac58: bl              #0x717dec  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::_adjustRect
    // 0x71ac5c: add             SP, SP, #0x10
    // 0x71ac60: mov             x1, x0
    // 0x71ac64: ldur            x0, [fp, #-0x10]
    // 0x71ac68: LoadField: r2 = r0->field_7
    //     0x71ac68: ldur            w2, [x0, #7]
    // 0x71ac6c: DecompressPointer r2
    //     0x71ac6c: add             x2, x2, HEAP, lsl #32
    // 0x71ac70: LoadField: d0 = r2->field_b
    //     0x71ac70: ldur            d0, [x2, #0xb]
    // 0x71ac74: LoadField: d1 = r2->field_17
    //     0x71ac74: ldur            d1, [x2, #0x17]
    // 0x71ac78: d2 = 1.000000
    //     0x71ac78: fmov            d2, #1.00000000
    // 0x71ac7c: fadd            d3, d2, d1
    // 0x71ac80: d1 = 2.000000
    //     0x71ac80: fmov            d1, #2.00000000
    // 0x71ac84: fdiv            d4, d3, d1
    // 0x71ac88: fsub            d1, d2, d4
    // 0x71ac8c: fmul            d2, d0, d1
    // 0x71ac90: SaveReg r1
    //     0x71ac90: str             x1, [SP, #-8]!
    // 0x71ac94: SaveReg d2
    //     0x71ac94: str             d2, [SP, #-8]!
    // 0x71ac98: r0 = deflate()
    //     0x71ac98: bl              #0x5d10ec  ; [dart:ui] Rect::deflate
    // 0x71ac9c: add             SP, SP, #0x10
    // 0x71aca0: ldur            x16, [fp, #-0x18]
    // 0x71aca4: stp             x0, x16, [SP, #-0x10]!
    // 0x71aca8: r0 = addOval()
    //     0x71aca8: bl              #0x6633ac  ; [dart:ui] Path::addOval
    // 0x71acac: add             SP, SP, #0x10
    // 0x71acb0: ldur            x0, [fp, #-0x18]
    // 0x71acb4: LeaveFrame
    //     0x71acb4: mov             SP, fp
    //     0x71acb8: ldp             fp, lr, [SP], #0x10
    // 0x71acbc: ret
    //     0x71acbc: ret             
    // 0x71acc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71acc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71acc4: b               #0x71ac38
  }
  _ toString(/* No info */) {
    // ** addr: 0xadb0b0, size: 0x134
    // 0xadb0b0: EnterFrame
    //     0xadb0b0: stp             fp, lr, [SP, #-0x10]!
    //     0xadb0b4: mov             fp, SP
    // 0xadb0b8: AllocStack(0x8)
    //     0xadb0b8: sub             SP, SP, #8
    // 0xadb0bc: d0 = 0.000000
    //     0xadb0bc: eor             v0.16b, v0.16b, v0.16b
    // 0xadb0c0: CheckStackOverflow
    //     0xadb0c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xadb0c4: cmp             SP, x16
    //     0xadb0c8: b.ls            #0xadb1c0
    // 0xadb0cc: ldr             x0, [fp, #0x10]
    // 0xadb0d0: LoadField: d1 = r0->field_b
    //     0xadb0d0: ldur            d1, [x0, #0xb]
    // 0xadb0d4: stur            d1, [fp, #-8]
    // 0xadb0d8: fcmp            d1, d0
    // 0xadb0dc: b.eq            #0xadb16c
    // 0xadb0e0: r1 = Null
    //     0xadb0e0: mov             x1, NULL
    // 0xadb0e4: r2 = 12
    //     0xadb0e4: mov             x2, #0xc
    // 0xadb0e8: r0 = AllocateArray()
    //     0xadb0e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb0ec: r17 = "CircleBorder"
    //     0xadb0ec: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7d0] "CircleBorder"
    //     0xadb0f0: ldr             x17, [x17, #0x7d0]
    // 0xadb0f4: StoreField: r0->field_f = r17
    //     0xadb0f4: stur            w17, [x0, #0xf]
    // 0xadb0f8: r17 = "("
    //     0xadb0f8: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xadb0fc: StoreField: r0->field_13 = r17
    //     0xadb0fc: stur            w17, [x0, #0x13]
    // 0xadb100: ldr             x3, [fp, #0x10]
    // 0xadb104: LoadField: r1 = r3->field_7
    //     0xadb104: ldur            w1, [x3, #7]
    // 0xadb108: DecompressPointer r1
    //     0xadb108: add             x1, x1, HEAP, lsl #32
    // 0xadb10c: StoreField: r0->field_17 = r1
    //     0xadb10c: stur            w1, [x0, #0x17]
    // 0xadb110: r17 = ", eccentricity: "
    //     0xadb110: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7d8] ", eccentricity: "
    //     0xadb114: ldr             x17, [x17, #0x7d8]
    // 0xadb118: StoreField: r0->field_1b = r17
    //     0xadb118: stur            w17, [x0, #0x1b]
    // 0xadb11c: ldur            d0, [fp, #-8]
    // 0xadb120: r1 = inline_Allocate_Double()
    //     0xadb120: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xadb124: add             x1, x1, #0x10
    //     0xadb128: cmp             x2, x1
    //     0xadb12c: b.ls            #0xadb1c8
    //     0xadb130: str             x1, [THR, #0x60]  ; THR::top
    //     0xadb134: sub             x1, x1, #0xf
    //     0xadb138: mov             x2, #0xd108
    //     0xadb13c: movk            x2, #3, lsl #16
    //     0xadb140: stur            x2, [x1, #-1]
    // 0xadb144: StoreField: r1->field_7 = d0
    //     0xadb144: stur            d0, [x1, #7]
    // 0xadb148: StoreField: r0->field_1f = r1
    //     0xadb148: stur            w1, [x0, #0x1f]
    // 0xadb14c: r17 = ")"
    //     0xadb14c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadb150: StoreField: r0->field_23 = r17
    //     0xadb150: stur            w17, [x0, #0x23]
    // 0xadb154: SaveReg r0
    //     0xadb154: str             x0, [SP, #-8]!
    // 0xadb158: r0 = _interpolate()
    //     0xadb158: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb15c: add             SP, SP, #8
    // 0xadb160: LeaveFrame
    //     0xadb160: mov             SP, fp
    //     0xadb164: ldp             fp, lr, [SP], #0x10
    // 0xadb168: ret
    //     0xadb168: ret             
    // 0xadb16c: mov             x3, x0
    // 0xadb170: r1 = Null
    //     0xadb170: mov             x1, NULL
    // 0xadb174: r2 = 8
    //     0xadb174: mov             x2, #8
    // 0xadb178: r0 = AllocateArray()
    //     0xadb178: bl              #0xd6987c  ; AllocateArrayStub
    // 0xadb17c: r17 = "CircleBorder"
    //     0xadb17c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7d0] "CircleBorder"
    //     0xadb180: ldr             x17, [x17, #0x7d0]
    // 0xadb184: StoreField: r0->field_f = r17
    //     0xadb184: stur            w17, [x0, #0xf]
    // 0xadb188: r17 = "("
    //     0xadb188: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xadb18c: StoreField: r0->field_13 = r17
    //     0xadb18c: stur            w17, [x0, #0x13]
    // 0xadb190: ldr             x1, [fp, #0x10]
    // 0xadb194: LoadField: r2 = r1->field_7
    //     0xadb194: ldur            w2, [x1, #7]
    // 0xadb198: DecompressPointer r2
    //     0xadb198: add             x2, x2, HEAP, lsl #32
    // 0xadb19c: StoreField: r0->field_17 = r2
    //     0xadb19c: stur            w2, [x0, #0x17]
    // 0xadb1a0: r17 = ")"
    //     0xadb1a0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xadb1a4: StoreField: r0->field_1b = r17
    //     0xadb1a4: stur            w17, [x0, #0x1b]
    // 0xadb1a8: SaveReg r0
    //     0xadb1a8: str             x0, [SP, #-8]!
    // 0xadb1ac: r0 = _interpolate()
    //     0xadb1ac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xadb1b0: add             SP, SP, #8
    // 0xadb1b4: LeaveFrame
    //     0xadb1b4: mov             SP, fp
    //     0xadb1b8: ldp             fp, lr, [SP], #0x10
    // 0xadb1bc: ret
    //     0xadb1bc: ret             
    // 0xadb1c0: r0 = StackOverflowSharedWithFPURegs()
    //     0xadb1c0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xadb1c4: b               #0xadb0cc
    // 0xadb1c8: SaveReg d0
    //     0xadb1c8: str             q0, [SP, #-0x10]!
    // 0xadb1cc: SaveReg r0
    //     0xadb1cc: str             x0, [SP, #-8]!
    // 0xadb1d0: r0 = AllocateDouble()
    //     0xadb1d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xadb1d4: mov             x1, x0
    // 0xadb1d8: RestoreReg r0
    //     0xadb1d8: ldr             x0, [SP], #8
    // 0xadb1dc: RestoreReg d0
    //     0xadb1dc: ldr             q0, [SP], #0x10
    // 0xadb1e0: b               #0xadb144
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd3d68, size: 0x170
    // 0xbd3d68: EnterFrame
    //     0xbd3d68: stp             fp, lr, [SP, #-0x10]!
    //     0xbd3d6c: mov             fp, SP
    // 0xbd3d70: AllocStack(0x28)
    //     0xbd3d70: sub             SP, SP, #0x28
    // 0xbd3d74: SetupParameters(CircleBorder this /* r1 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xbd3d74: mov             x0, x4
    //     0xbd3d78: ldur            w1, [x0, #0x13]
    //     0xbd3d7c: add             x1, x1, HEAP, lsl #32
    //     0xbd3d80: sub             x0, x1, #6
    //     0xbd3d84: add             x1, fp, w0, sxtw #2
    //     0xbd3d88: ldr             x1, [x1, #0x20]
    //     0xbd3d8c: add             x2, fp, w0, sxtw #2
    //     0xbd3d90: ldr             x2, [x2, #0x18]
    //     0xbd3d94: stur            x2, [fp, #-0x18]
    //     0xbd3d98: add             x3, fp, w0, sxtw #2
    //     0xbd3d9c: ldr             x3, [x3, #0x10]
    //     0xbd3da0: stur            x3, [fp, #-0x10]
    // 0xbd3da4: CheckStackOverflow
    //     0xbd3da4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd3da8: cmp             SP, x16
    //     0xbd3dac: b.ls            #0xbd3ed0
    // 0xbd3db0: LoadField: r0 = r1->field_7
    //     0xbd3db0: ldur            w0, [x1, #7]
    // 0xbd3db4: DecompressPointer r0
    //     0xbd3db4: add             x0, x0, HEAP, lsl #32
    // 0xbd3db8: stur            x0, [fp, #-8]
    // 0xbd3dbc: LoadField: r4 = r0->field_13
    //     0xbd3dbc: ldur            w4, [x0, #0x13]
    // 0xbd3dc0: DecompressPointer r4
    //     0xbd3dc0: add             x4, x4, HEAP, lsl #32
    // 0xbd3dc4: LoadField: r5 = r4->field_7
    //     0xbd3dc4: ldur            x5, [x4, #7]
    // 0xbd3dc8: cmp             x5, #0
    // 0xbd3dcc: b.le            #0xbd3ec0
    // 0xbd3dd0: d0 = 0.000000
    //     0xbd3dd0: eor             v0.16b, v0.16b, v0.16b
    // 0xbd3dd4: LoadField: d1 = r1->field_b
    //     0xbd3dd4: ldur            d1, [x1, #0xb]
    // 0xbd3dd8: fcmp            d1, d0
    // 0xbd3ddc: b.vs            #0xbd3e54
    // 0xbd3de0: b.ne            #0xbd3e54
    // 0xbd3de4: SaveReg r3
    //     0xbd3de4: str             x3, [SP, #-8]!
    // 0xbd3de8: r0 = center()
    //     0xbd3de8: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xbd3dec: add             SP, SP, #8
    // 0xbd3df0: stur            x0, [fp, #-0x20]
    // 0xbd3df4: ldur            x16, [fp, #-0x10]
    // 0xbd3df8: SaveReg r16
    //     0xbd3df8: str             x16, [SP, #-8]!
    // 0xbd3dfc: r0 = shortestSide()
    //     0xbd3dfc: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0xbd3e00: add             SP, SP, #8
    // 0xbd3e04: ldur            x0, [fp, #-8]
    // 0xbd3e08: LoadField: d1 = r0->field_b
    //     0xbd3e08: ldur            d1, [x0, #0xb]
    // 0xbd3e0c: LoadField: d2 = r0->field_17
    //     0xbd3e0c: ldur            d2, [x0, #0x17]
    // 0xbd3e10: fmul            d3, d1, d2
    // 0xbd3e14: fadd            d1, d0, d3
    // 0xbd3e18: d0 = 2.000000
    //     0xbd3e18: fmov            d0, #2.00000000
    // 0xbd3e1c: fdiv            d2, d1, d0
    // 0xbd3e20: stur            d2, [fp, #-0x28]
    // 0xbd3e24: SaveReg r0
    //     0xbd3e24: str             x0, [SP, #-8]!
    // 0xbd3e28: r0 = toPaint()
    //     0xbd3e28: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd3e2c: add             SP, SP, #8
    // 0xbd3e30: ldur            x16, [fp, #-0x18]
    // 0xbd3e34: ldur            lr, [fp, #-0x20]
    // 0xbd3e38: stp             lr, x16, [SP, #-0x10]!
    // 0xbd3e3c: ldur            d0, [fp, #-0x28]
    // 0xbd3e40: SaveReg d0
    //     0xbd3e40: str             d0, [SP, #-8]!
    // 0xbd3e44: SaveReg r0
    //     0xbd3e44: str             x0, [SP, #-8]!
    // 0xbd3e48: r0 = drawCircle()
    //     0xbd3e48: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0xbd3e4c: add             SP, SP, #0x20
    // 0xbd3e50: b               #0xbd3ec0
    // 0xbd3e54: d0 = 2.000000
    //     0xbd3e54: fmov            d0, #2.00000000
    // 0xbd3e58: ldur            x16, [fp, #-0x10]
    // 0xbd3e5c: stp             x16, x1, [SP, #-0x10]!
    // 0xbd3e60: r0 = _adjustRect()
    //     0xbd3e60: bl              #0x717dec  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::_adjustRect
    // 0xbd3e64: add             SP, SP, #0x10
    // 0xbd3e68: mov             x1, x0
    // 0xbd3e6c: ldur            x0, [fp, #-8]
    // 0xbd3e70: LoadField: d0 = r0->field_b
    //     0xbd3e70: ldur            d0, [x0, #0xb]
    // 0xbd3e74: LoadField: d1 = r0->field_17
    //     0xbd3e74: ldur            d1, [x0, #0x17]
    // 0xbd3e78: fmul            d2, d0, d1
    // 0xbd3e7c: d0 = 2.000000
    //     0xbd3e7c: fmov            d0, #2.00000000
    // 0xbd3e80: fdiv            d1, d2, d0
    // 0xbd3e84: SaveReg r1
    //     0xbd3e84: str             x1, [SP, #-8]!
    // 0xbd3e88: SaveReg d1
    //     0xbd3e88: str             d1, [SP, #-8]!
    // 0xbd3e8c: r0 = inflate()
    //     0xbd3e8c: bl              #0x5d1480  ; [dart:ui] Rect::inflate
    // 0xbd3e90: add             SP, SP, #0x10
    // 0xbd3e94: stur            x0, [fp, #-0x10]
    // 0xbd3e98: ldur            x16, [fp, #-8]
    // 0xbd3e9c: SaveReg r16
    //     0xbd3e9c: str             x16, [SP, #-8]!
    // 0xbd3ea0: r0 = toPaint()
    //     0xbd3ea0: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd3ea4: add             SP, SP, #8
    // 0xbd3ea8: ldur            x16, [fp, #-0x18]
    // 0xbd3eac: ldur            lr, [fp, #-0x10]
    // 0xbd3eb0: stp             lr, x16, [SP, #-0x10]!
    // 0xbd3eb4: SaveReg r0
    //     0xbd3eb4: str             x0, [SP, #-8]!
    // 0xbd3eb8: r0 = drawOval()
    //     0xbd3eb8: bl              #0x717890  ; [dart:ui] Canvas::drawOval
    // 0xbd3ebc: add             SP, SP, #0x18
    // 0xbd3ec0: r0 = Null
    //     0xbd3ec0: mov             x0, NULL
    // 0xbd3ec4: LeaveFrame
    //     0xbd3ec4: mov             SP, fp
    //     0xbd3ec8: ldp             fp, lr, [SP], #0x10
    // 0xbd3ecc: ret
    //     0xbd3ecc: ret             
    // 0xbd3ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd3ed0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd3ed4: b               #0xbd3db0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9991c, size: 0x124
    // 0xc9991c: EnterFrame
    //     0xc9991c: stp             fp, lr, [SP, #-0x10]!
    //     0xc99920: mov             fp, SP
    // 0xc99924: CheckStackOverflow
    //     0xc99924: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc99928: cmp             SP, x16
    //     0xc9992c: b.ls            #0xc99a38
    // 0xc99930: ldr             x1, [fp, #0x10]
    // 0xc99934: cmp             w1, NULL
    // 0xc99938: b.ne            #0xc9994c
    // 0xc9993c: r0 = false
    //     0xc9993c: add             x0, NULL, #0x30  ; false
    // 0xc99940: LeaveFrame
    //     0xc99940: mov             SP, fp
    //     0xc99944: ldp             fp, lr, [SP], #0x10
    // 0xc99948: ret
    //     0xc99948: ret             
    // 0xc9994c: r0 = 59
    //     0xc9994c: mov             x0, #0x3b
    // 0xc99950: branchIfSmi(r1, 0xc9995c)
    //     0xc99950: tbz             w1, #0, #0xc9995c
    // 0xc99954: r0 = LoadClassIdInstr(r1)
    //     0xc99954: ldur            x0, [x1, #-1]
    //     0xc99958: ubfx            x0, x0, #0xc, #0x14
    // 0xc9995c: SaveReg r1
    //     0xc9995c: str             x1, [SP, #-8]!
    // 0xc99960: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc99960: mov             x17, #0x57c5
    //     0xc99964: add             lr, x0, x17
    //     0xc99968: ldr             lr, [x21, lr, lsl #3]
    //     0xc9996c: blr             lr
    // 0xc99970: add             SP, SP, #8
    // 0xc99974: r1 = LoadClassIdInstr(r0)
    //     0xc99974: ldur            x1, [x0, #-1]
    //     0xc99978: ubfx            x1, x1, #0xc, #0x14
    // 0xc9997c: r16 = CircleBorder
    //     0xc9997c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe7e0] Type: CircleBorder
    //     0xc99980: ldr             x16, [x16, #0x7e0]
    // 0xc99984: stp             x16, x0, [SP, #-0x10]!
    // 0xc99988: mov             x0, x1
    // 0xc9998c: mov             lr, x0
    // 0xc99990: ldr             lr, [x21, lr, lsl #3]
    // 0xc99994: blr             lr
    // 0xc99998: add             SP, SP, #0x10
    // 0xc9999c: tbz             w0, #4, #0xc999b0
    // 0xc999a0: r0 = false
    //     0xc999a0: add             x0, NULL, #0x30  ; false
    // 0xc999a4: LeaveFrame
    //     0xc999a4: mov             SP, fp
    //     0xc999a8: ldp             fp, lr, [SP], #0x10
    // 0xc999ac: ret
    //     0xc999ac: ret             
    // 0xc999b0: ldr             x0, [fp, #0x10]
    // 0xc999b4: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc999b4: mov             x1, #0x76
    //     0xc999b8: tbz             w0, #0, #0xc999c8
    //     0xc999bc: ldur            x1, [x0, #-1]
    //     0xc999c0: ubfx            x1, x1, #0xc, #0x14
    //     0xc999c4: lsl             x1, x1, #1
    // 0xc999c8: r17 = 4360
    //     0xc999c8: mov             x17, #0x1108
    // 0xc999cc: cmp             w1, w17
    // 0xc999d0: b.ne            #0xc99a28
    // 0xc999d4: ldr             x1, [fp, #0x18]
    // 0xc999d8: LoadField: r2 = r0->field_7
    //     0xc999d8: ldur            w2, [x0, #7]
    // 0xc999dc: DecompressPointer r2
    //     0xc999dc: add             x2, x2, HEAP, lsl #32
    // 0xc999e0: LoadField: r3 = r1->field_7
    //     0xc999e0: ldur            w3, [x1, #7]
    // 0xc999e4: DecompressPointer r3
    //     0xc999e4: add             x3, x3, HEAP, lsl #32
    // 0xc999e8: stp             x3, x2, [SP, #-0x10]!
    // 0xc999ec: r0 = ==()
    //     0xc999ec: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc999f0: add             SP, SP, #0x10
    // 0xc999f4: tbnz            w0, #4, #0xc99a28
    // 0xc999f8: ldr             x2, [fp, #0x18]
    // 0xc999fc: ldr             x1, [fp, #0x10]
    // 0xc99a00: LoadField: d0 = r1->field_b
    //     0xc99a00: ldur            d0, [x1, #0xb]
    // 0xc99a04: LoadField: d1 = r2->field_b
    //     0xc99a04: ldur            d1, [x2, #0xb]
    // 0xc99a08: fcmp            d0, d1
    // 0xc99a0c: b.vs            #0xc99a14
    // 0xc99a10: b.eq            #0xc99a1c
    // 0xc99a14: r1 = false
    //     0xc99a14: add             x1, NULL, #0x30  ; false
    // 0xc99a18: b               #0xc99a20
    // 0xc99a1c: r1 = true
    //     0xc99a1c: add             x1, NULL, #0x20  ; true
    // 0xc99a20: mov             x0, x1
    // 0xc99a24: b               #0xc99a2c
    // 0xc99a28: r0 = false
    //     0xc99a28: add             x0, NULL, #0x30  ; false
    // 0xc99a2c: LeaveFrame
    //     0xc99a2c: mov             SP, fp
    //     0xc99a30: ldp             fp, lr, [SP], #0x10
    // 0xc99a34: ret
    //     0xc99a34: ret             
    // 0xc99a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc99a38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc99a3c: b               #0xc99930
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf8524, size: 0x74
    // 0xcf8524: EnterFrame
    //     0xcf8524: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8528: mov             fp, SP
    // 0xcf852c: AllocStack(0x10)
    //     0xcf852c: sub             SP, SP, #0x10
    // 0xcf8530: CheckStackOverflow
    //     0xcf8530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf8534: cmp             SP, x16
    //     0xcf8538: b.ls            #0xcf8590
    // 0xcf853c: ldr             x0, [fp, #0x18]
    // 0xcf8540: LoadField: r1 = r0->field_7
    //     0xcf8540: ldur            w1, [x0, #7]
    // 0xcf8544: DecompressPointer r1
    //     0xcf8544: add             x1, x1, HEAP, lsl #32
    // 0xcf8548: SaveReg r1
    //     0xcf8548: str             x1, [SP, #-8]!
    // 0xcf854c: ldr             d0, [fp, #0x10]
    // 0xcf8550: SaveReg d0
    //     0xcf8550: str             d0, [SP, #-8]!
    // 0xcf8554: r0 = scale()
    //     0xcf8554: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf8558: add             SP, SP, #0x10
    // 0xcf855c: mov             x1, x0
    // 0xcf8560: ldr             x0, [fp, #0x18]
    // 0xcf8564: stur            x1, [fp, #-8]
    // 0xcf8568: LoadField: d0 = r0->field_b
    //     0xcf8568: ldur            d0, [x0, #0xb]
    // 0xcf856c: stur            d0, [fp, #-0x10]
    // 0xcf8570: r0 = CircleBorder()
    //     0xcf8570: bl              #0x70e75c  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0xcf8574: ldur            d0, [fp, #-0x10]
    // 0xcf8578: StoreField: r0->field_b = d0
    //     0xcf8578: stur            d0, [x0, #0xb]
    // 0xcf857c: ldur            x1, [fp, #-8]
    // 0xcf8580: StoreField: r0->field_7 = r1
    //     0xcf8580: stur            w1, [x0, #7]
    // 0xcf8584: LeaveFrame
    //     0xcf8584: mov             SP, fp
    //     0xcf8588: ldp             fp, lr, [SP], #0x10
    // 0xcf858c: ret
    //     0xcf858c: ret             
    // 0xcf8590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8590: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8594: b               #0xcf853c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xcf8cc4, size: 0x58
    // 0xcf8cc4: EnterFrame
    //     0xcf8cc4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8cc8: mov             fp, SP
    // 0xcf8ccc: AllocStack(0x10)
    //     0xcf8ccc: sub             SP, SP, #0x10
    // 0xcf8cd0: ldr             x0, [fp, #0x10]
    // 0xcf8cd4: cmp             w0, NULL
    // 0xcf8cd8: b.ne            #0xcf8cec
    // 0xcf8cdc: ldr             x1, [fp, #0x18]
    // 0xcf8ce0: LoadField: r0 = r1->field_7
    //     0xcf8ce0: ldur            w0, [x1, #7]
    // 0xcf8ce4: DecompressPointer r0
    //     0xcf8ce4: add             x0, x0, HEAP, lsl #32
    // 0xcf8ce8: b               #0xcf8cf0
    // 0xcf8cec: ldr             x1, [fp, #0x18]
    // 0xcf8cf0: stur            x0, [fp, #-8]
    // 0xcf8cf4: LoadField: d0 = r1->field_b
    //     0xcf8cf4: ldur            d0, [x1, #0xb]
    // 0xcf8cf8: stur            d0, [fp, #-0x10]
    // 0xcf8cfc: r0 = CircleBorder()
    //     0xcf8cfc: bl              #0x70e75c  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0xcf8d00: ldur            d0, [fp, #-0x10]
    // 0xcf8d04: StoreField: r0->field_b = d0
    //     0xcf8d04: stur            d0, [x0, #0xb]
    // 0xcf8d08: ldur            x1, [fp, #-8]
    // 0xcf8d0c: StoreField: r0->field_7 = r1
    //     0xcf8d0c: stur            w1, [x0, #7]
    // 0xcf8d10: LeaveFrame
    //     0xcf8d10: mov             SP, fp
    //     0xcf8d14: ldp             fp, lr, [SP], #0x10
    // 0xcf8d18: ret
    //     0xcf8d18: ret             
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0xcfa2f4, size: 0x90
    // 0xcfa2f4: EnterFrame
    //     0xcfa2f4: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa2f8: mov             fp, SP
    // 0xcfa2fc: AllocStack(0x18)
    //     0xcfa2fc: sub             SP, SP, #0x18
    // 0xcfa300: SetupParameters(CircleBorder this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0xcfa300: mov             x0, x4
    //     0xcfa304: ldur            w1, [x0, #0x13]
    //     0xcfa308: add             x1, x1, HEAP, lsl #32
    //     0xcfa30c: sub             x0, x1, #4
    //     0xcfa310: add             x1, fp, w0, sxtw #2
    //     0xcfa314: ldr             x1, [x1, #0x18]
    //     0xcfa318: stur            x1, [fp, #-0x10]
    //     0xcfa31c: add             x2, fp, w0, sxtw #2
    //     0xcfa320: ldr             x2, [x2, #0x10]
    //     0xcfa324: stur            x2, [fp, #-8]
    // 0xcfa328: CheckStackOverflow
    //     0xcfa328: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa32c: cmp             SP, x16
    //     0xcfa330: b.ls            #0xcfa37c
    // 0xcfa334: r0 = Path()
    //     0xcfa334: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcfa338: stur            x0, [fp, #-0x18]
    // 0xcfa33c: SaveReg r0
    //     0xcfa33c: str             x0, [SP, #-8]!
    // 0xcfa340: r0 = _constructor()
    //     0xcfa340: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcfa344: add             SP, SP, #8
    // 0xcfa348: ldur            x16, [fp, #-0x10]
    // 0xcfa34c: ldur            lr, [fp, #-8]
    // 0xcfa350: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa354: r0 = _adjustRect()
    //     0xcfa354: bl              #0x717dec  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::_adjustRect
    // 0xcfa358: add             SP, SP, #0x10
    // 0xcfa35c: ldur            x16, [fp, #-0x18]
    // 0xcfa360: stp             x0, x16, [SP, #-0x10]!
    // 0xcfa364: r0 = addOval()
    //     0xcfa364: bl              #0x6633ac  ; [dart:ui] Path::addOval
    // 0xcfa368: add             SP, SP, #0x10
    // 0xcfa36c: ldur            x0, [fp, #-0x18]
    // 0xcfa370: LeaveFrame
    //     0xcfa370: mov             SP, fp
    //     0xcfa374: ldp             fp, lr, [SP], #0x10
    // 0xcfa378: ret
    //     0xcfa378: ret             
    // 0xcfa37c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa37c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa380: b               #0xcfa334
  }
}

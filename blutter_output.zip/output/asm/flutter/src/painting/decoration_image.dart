// lib: , url: package:flutter/src/painting/decoration_image.dart

// class id: 1049360, size: 0x8
class :: {

  static _ paintImage(/* No info */) {
    // ** addr: 0x66da70, size: 0x5e0
    // 0x66da70: EnterFrame
    //     0x66da70: stp             fp, lr, [SP, #-0x10]!
    //     0x66da74: mov             fp, SP
    // 0x66da78: AllocStack(0x60)
    //     0x66da78: sub             SP, SP, #0x60
    // 0x66da7c: CheckStackOverflow
    //     0x66da7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66da80: cmp             SP, x16
    //     0x66da84: b.ls            #0x66dfa0
    // 0x66da88: ldr             x0, [fp, #0x20]
    // 0x66da8c: LoadField: d0 = r0->field_7
    //     0x66da8c: ldur            d0, [x0, #7]
    // 0x66da90: stur            d0, [fp, #-0x50]
    // 0x66da94: LoadField: d1 = r0->field_17
    //     0x66da94: ldur            d1, [x0, #0x17]
    // 0x66da98: stur            d1, [fp, #-0x48]
    // 0x66da9c: fcmp            d0, d1
    // 0x66daa0: b.vs            #0x66daa8
    // 0x66daa4: b.ge            #0x66dac0
    // 0x66daa8: LoadField: d2 = r0->field_f
    //     0x66daa8: ldur            d2, [x0, #0xf]
    // 0x66daac: stur            d2, [fp, #-0x40]
    // 0x66dab0: LoadField: d3 = r0->field_1f
    //     0x66dab0: ldur            d3, [x0, #0x1f]
    // 0x66dab4: fcmp            d2, d3
    // 0x66dab8: b.vs            #0x66dad0
    // 0x66dabc: b.lt            #0x66dad0
    // 0x66dac0: r0 = Null
    //     0x66dac0: mov             x0, NULL
    // 0x66dac4: LeaveFrame
    //     0x66dac4: mov             SP, fp
    //     0x66dac8: ldp             fp, lr, [SP], #0x10
    // 0x66dacc: ret
    //     0x66dacc: ret             
    // 0x66dad0: ldr             x2, [fp, #0x48]
    // 0x66dad4: ldr             x1, [fp, #0x38]
    // 0x66dad8: SaveReg r0
    //     0x66dad8: str             x0, [SP, #-8]!
    // 0x66dadc: r0 = size()
    //     0x66dadc: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x66dae0: add             SP, SP, #8
    // 0x66dae4: mov             x3, x0
    // 0x66dae8: ldr             x2, [fp, #0x38]
    // 0x66daec: stur            x3, [fp, #-8]
    // 0x66daf0: LoadField: r4 = r2->field_f
    //     0x66daf0: ldur            x4, [x2, #0xf]
    // 0x66daf4: r0 = BoxInt64Instr(r4)
    //     0x66daf4: sbfiz           x0, x4, #1, #0x1f
    //     0x66daf8: cmp             x4, x0, asr #1
    //     0x66dafc: b.eq            #0x66db08
    //     0x66db00: bl              #0xd69bb8
    //     0x66db04: stur            x4, [x0, #7]
    // 0x66db08: stp             x0, NULL, [SP, #-0x10]!
    // 0x66db0c: r0 = _Double.fromInteger()
    //     0x66db0c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x66db10: add             SP, SP, #0x10
    // 0x66db14: mov             x3, x0
    // 0x66db18: ldr             x2, [fp, #0x38]
    // 0x66db1c: stur            x3, [fp, #-0x10]
    // 0x66db20: LoadField: r4 = r2->field_17
    //     0x66db20: ldur            x4, [x2, #0x17]
    // 0x66db24: r0 = BoxInt64Instr(r4)
    //     0x66db24: sbfiz           x0, x4, #1, #0x1f
    //     0x66db28: cmp             x4, x0, asr #1
    //     0x66db2c: b.eq            #0x66db38
    //     0x66db30: bl              #0xd69bb8
    //     0x66db34: stur            x4, [x0, #7]
    // 0x66db38: stp             x0, NULL, [SP, #-0x10]!
    // 0x66db3c: r0 = _Double.fromInteger()
    //     0x66db3c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x66db40: add             SP, SP, #0x10
    // 0x66db44: mov             x1, x0
    // 0x66db48: ldur            x0, [fp, #-0x10]
    // 0x66db4c: stur            x1, [fp, #-0x18]
    // 0x66db50: LoadField: d0 = r0->field_7
    //     0x66db50: ldur            d0, [x0, #7]
    // 0x66db54: stur            d0, [fp, #-0x58]
    // 0x66db58: r0 = Size()
    //     0x66db58: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x66db5c: ldur            d0, [fp, #-0x58]
    // 0x66db60: stur            x0, [fp, #-0x20]
    // 0x66db64: StoreField: r0->field_7 = d0
    //     0x66db64: stur            d0, [x0, #7]
    // 0x66db68: ldur            x1, [fp, #-0x18]
    // 0x66db6c: LoadField: d0 = r1->field_7
    //     0x66db6c: ldur            d0, [x1, #7]
    // 0x66db70: StoreField: r0->field_f = d0
    //     0x66db70: stur            d0, [x0, #0xf]
    // 0x66db74: ldr             x1, [fp, #0x48]
    // 0x66db78: cmp             w1, NULL
    // 0x66db7c: b.ne            #0x66db8c
    // 0x66db80: r2 = Instance_BoxFit
    //     0x66db80: add             x2, PP, #0x21, lsl #12  ; [pp+0x21cc8] Obj!BoxFit@b64df1
    //     0x66db84: ldr             x2, [x2, #0xcc8]
    // 0x66db88: b               #0x66db90
    // 0x66db8c: mov             x2, x1
    // 0x66db90: ldr             x1, [fp, #0x50]
    // 0x66db94: ldr             d0, [fp, #0x10]
    // 0x66db98: stur            x2, [fp, #-0x18]
    // 0x66db9c: r3 = inline_Allocate_Double()
    //     0x66db9c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x66dba0: add             x3, x3, #0x10
    //     0x66dba4: cmp             x4, x3
    //     0x66dba8: b.ls            #0x66dfa8
    //     0x66dbac: str             x3, [THR, #0x60]  ; THR::top
    //     0x66dbb0: sub             x3, x3, #0xf
    //     0x66dbb4: mov             x4, #0xd108
    //     0x66dbb8: movk            x4, #3, lsl #16
    //     0x66dbbc: stur            x4, [x3, #-1]
    // 0x66dbc0: StoreField: r3->field_7 = d0
    //     0x66dbc0: stur            d0, [x3, #7]
    // 0x66dbc4: stur            x3, [fp, #-0x10]
    // 0x66dbc8: stp             x3, x0, [SP, #-0x10]!
    // 0x66dbcc: r0 = /()
    //     0x66dbcc: bl              #0x50e098  ; [dart:ui] Size::/
    // 0x66dbd0: add             SP, SP, #0x10
    // 0x66dbd4: ldur            x16, [fp, #-0x18]
    // 0x66dbd8: stp             x0, x16, [SP, #-0x10]!
    // 0x66dbdc: ldur            x16, [fp, #-8]
    // 0x66dbe0: SaveReg r16
    //     0x66dbe0: str             x16, [SP, #-8]!
    // 0x66dbe4: r0 = applyBoxFit()
    //     0x66dbe4: bl              #0x626a14  ; [package:flutter/src/painting/box_fit.dart] ::applyBoxFit
    // 0x66dbe8: add             SP, SP, #0x18
    // 0x66dbec: stur            x0, [fp, #-0x18]
    // 0x66dbf0: LoadField: r1 = r0->field_7
    //     0x66dbf0: ldur            w1, [x0, #7]
    // 0x66dbf4: DecompressPointer r1
    //     0x66dbf4: add             x1, x1, HEAP, lsl #32
    // 0x66dbf8: ldur            x16, [fp, #-0x10]
    // 0x66dbfc: stp             x16, x1, [SP, #-0x10]!
    // 0x66dc00: r0 = *()
    //     0x66dc00: bl              #0x50e17c  ; [dart:ui] Size::*
    // 0x66dc04: add             SP, SP, #0x10
    // 0x66dc08: mov             x1, x0
    // 0x66dc0c: ldur            x0, [fp, #-0x18]
    // 0x66dc10: stur            x1, [fp, #-0x28]
    // 0x66dc14: LoadField: r2 = r0->field_b
    //     0x66dc14: ldur            w2, [x0, #0xb]
    // 0x66dc18: DecompressPointer r2
    //     0x66dc18: add             x2, x2, HEAP, lsl #32
    // 0x66dc1c: stur            x2, [fp, #-0x10]
    // 0x66dc20: r16 = 112
    //     0x66dc20: mov             x16, #0x70
    // 0x66dc24: stp             x16, NULL, [SP, #-0x10]!
    // 0x66dc28: r0 = ByteData()
    //     0x66dc28: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x66dc2c: add             SP, SP, #0x10
    // 0x66dc30: stur            x0, [fp, #-0x18]
    // 0x66dc34: r0 = Paint()
    //     0x66dc34: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x66dc38: mov             x1, x0
    // 0x66dc3c: ldur            x0, [fp, #-0x18]
    // 0x66dc40: stur            x1, [fp, #-0x38]
    // 0x66dc44: StoreField: r1->field_7 = r0
    //     0x66dc44: stur            w0, [x1, #7]
    // 0x66dc48: LoadField: r2 = r0->field_17
    //     0x66dc48: ldur            w2, [x0, #0x17]
    // 0x66dc4c: DecompressPointer r2
    //     0x66dc4c: add             x2, x2, HEAP, lsl #32
    // 0x66dc50: stur            x2, [fp, #-0x30]
    // 0x66dc54: LoadField: r0 = r2->field_7
    //     0x66dc54: ldur            x0, [x2, #7]
    // 0x66dc58: r3 = 1
    //     0x66dc58: mov             x3, #1
    // 0x66dc5c: str             w3, [x0]
    // 0x66dc60: ldr             x0, [fp, #0x50]
    // 0x66dc64: cmp             w0, NULL
    // 0x66dc68: b.eq            #0x66dc78
    // 0x66dc6c: stp             x0, x1, [SP, #-0x10]!
    // 0x66dc70: r0 = colorFilter=()
    //     0x66dc70: bl              #0x66e050  ; [dart:ui] Paint::colorFilter=
    // 0x66dc74: add             SP, SP, #0x10
    // 0x66dc78: ldr             x5, [fp, #0x40]
    // 0x66dc7c: ldr             x4, [fp, #0x30]
    // 0x66dc80: ldr             x3, [fp, #0x28]
    // 0x66dc84: ldur            x2, [fp, #-8]
    // 0x66dc88: ldur            x1, [fp, #-0x10]
    // 0x66dc8c: ldur            x0, [fp, #-0x30]
    // 0x66dc90: d0 = 255.000000
    //     0x66dc90: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0x66dc94: ldr             d0, [x17, #0x200]
    // 0x66dc98: LoadField: d1 = r3->field_7
    //     0x66dc98: ldur            d1, [x3, #7]
    // 0x66dc9c: fmul            d2, d1, d0
    // 0x66dca0: r3 = inline_Allocate_Double()
    //     0x66dca0: ldp             x3, x6, [THR, #0x60]  ; THR::top
    //     0x66dca4: add             x3, x3, #0x10
    //     0x66dca8: cmp             x6, x3
    //     0x66dcac: b.ls            #0x66dfcc
    //     0x66dcb0: str             x3, [THR, #0x60]  ; THR::top
    //     0x66dcb4: sub             x3, x3, #0xf
    //     0x66dcb8: mov             x6, #0xd108
    //     0x66dcbc: movk            x6, #3, lsl #16
    //     0x66dcc0: stur            x6, [x3, #-1]
    // 0x66dcc4: StoreField: r3->field_7 = d2
    //     0x66dcc4: stur            d2, [x3, #7]
    // 0x66dcc8: r16 = 2
    //     0x66dcc8: mov             x16, #2
    // 0x66dccc: stp             x16, x3, [SP, #-0x10]!
    // 0x66dcd0: r0 = ~/()
    //     0x66dcd0: bl              #0x65adc0  ; [dart:core] _Double::~/
    // 0x66dcd4: add             SP, SP, #0x10
    // 0x66dcd8: r1 = LoadInt32Instr(r0)
    //     0x66dcd8: sbfx            x1, x0, #1, #0x1f
    //     0x66dcdc: tbz             w0, #0, #0x66dce4
    //     0x66dce0: ldur            x1, [x0, #7]
    // 0x66dce4: r0 = 255
    //     0x66dce4: mov             x0, #0xff
    // 0x66dce8: and             x2, x1, x0
    // 0x66dcec: lsl             w0, w2, #0x18
    // 0x66dcf0: ubfx            x0, x0, #0, #0x20
    // 0x66dcf4: eor             x1, x0, #0xff000000
    // 0x66dcf8: sxtw            x1, w1
    // 0x66dcfc: ldur            x0, [fp, #-0x30]
    // 0x66dd00: LoadField: r2 = r0->field_7
    //     0x66dd00: ldur            x2, [x0, #7]
    // 0x66dd04: str             w1, [x2, #4]
    // 0x66dd08: LoadField: r1 = r0->field_7
    //     0x66dd08: ldur            x1, [x0, #7]
    // 0x66dd0c: r2 = 1
    //     0x66dd0c: mov             x2, #1
    // 0x66dd10: str             w2, [x1, #0x20]
    // 0x66dd14: ldr             x1, [fp, #0x30]
    // 0x66dd18: tst             x1, #0x10
    // 0x66dd1c: cset            x2, eq
    // 0x66dd20: lsl             x2, x2, #1
    // 0x66dd24: r1 = LoadInt32Instr(r2)
    //     0x66dd24: sbfx            x1, x2, #1, #0x1f
    // 0x66dd28: LoadField: r2 = r0->field_7
    //     0x66dd28: ldur            x2, [x0, #7]
    // 0x66dd2c: str             w1, [x2, #0x30]
    // 0x66dd30: ldur            x0, [fp, #-8]
    // 0x66dd34: LoadField: d0 = r0->field_7
    //     0x66dd34: ldur            d0, [x0, #7]
    // 0x66dd38: ldur            x1, [fp, #-0x10]
    // 0x66dd3c: LoadField: d1 = r1->field_7
    //     0x66dd3c: ldur            d1, [x1, #7]
    // 0x66dd40: fsub            d2, d0, d1
    // 0x66dd44: d0 = 2.000000
    //     0x66dd44: fmov            d0, #2.00000000
    // 0x66dd48: fdiv            d1, d2, d0
    // 0x66dd4c: LoadField: d2 = r0->field_f
    //     0x66dd4c: ldur            d2, [x0, #0xf]
    // 0x66dd50: LoadField: d3 = r1->field_f
    //     0x66dd50: ldur            d3, [x1, #0xf]
    // 0x66dd54: fsub            d4, d2, d3
    // 0x66dd58: fdiv            d2, d4, d0
    // 0x66dd5c: ldr             x0, [fp, #0x40]
    // 0x66dd60: tbnz            w0, #4, #0x66dd7c
    // 0x66dd64: r2 = Instance_Alignment
    //     0x66dd64: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x66dd68: ldr             x2, [x2, #0xc70]
    // 0x66dd6c: LoadField: d3 = r2->field_7
    //     0x66dd6c: ldur            d3, [x2, #7]
    // 0x66dd70: fneg            d4, d3
    // 0x66dd74: mov             v5.16b, v4.16b
    // 0x66dd78: b               #0x66dd8c
    // 0x66dd7c: r2 = Instance_Alignment
    //     0x66dd7c: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x66dd80: ldr             x2, [x2, #0xc70]
    // 0x66dd84: LoadField: d3 = r2->field_7
    //     0x66dd84: ldur            d3, [x2, #7]
    // 0x66dd88: mov             v5.16b, v3.16b
    // 0x66dd8c: ldur            d3, [fp, #-0x50]
    // 0x66dd90: ldur            d4, [fp, #-0x40]
    // 0x66dd94: fmul            d6, d5, d1
    // 0x66dd98: fadd            d5, d1, d6
    // 0x66dd9c: stur            d5, [fp, #-0x60]
    // 0x66dda0: LoadField: d1 = r2->field_f
    //     0x66dda0: ldur            d1, [x2, #0xf]
    // 0x66dda4: fmul            d6, d1, d2
    // 0x66dda8: fadd            d1, d2, d6
    // 0x66ddac: stur            d1, [fp, #-0x58]
    // 0x66ddb0: r0 = Offset()
    //     0x66ddb0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x66ddb4: ldur            d0, [fp, #-0x50]
    // 0x66ddb8: StoreField: r0->field_7 = d0
    //     0x66ddb8: stur            d0, [x0, #7]
    // 0x66ddbc: ldur            d1, [fp, #-0x40]
    // 0x66ddc0: StoreField: r0->field_f = d1
    //     0x66ddc0: stur            d1, [x0, #0xf]
    // 0x66ddc4: ldur            d1, [fp, #-0x60]
    // 0x66ddc8: r1 = inline_Allocate_Double()
    //     0x66ddc8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x66ddcc: add             x1, x1, #0x10
    //     0x66ddd0: cmp             x2, x1
    //     0x66ddd4: b.ls            #0x66dff8
    //     0x66ddd8: str             x1, [THR, #0x60]  ; THR::top
    //     0x66dddc: sub             x1, x1, #0xf
    //     0x66dde0: mov             x2, #0xd108
    //     0x66dde4: movk            x2, #3, lsl #16
    //     0x66dde8: stur            x2, [x1, #-1]
    // 0x66ddec: StoreField: r1->field_7 = d1
    //     0x66ddec: stur            d1, [x1, #7]
    // 0x66ddf0: stp             x1, x0, [SP, #-0x10]!
    // 0x66ddf4: ldur            d1, [fp, #-0x58]
    // 0x66ddf8: SaveReg d1
    //     0x66ddf8: str             d1, [SP, #-8]!
    // 0x66ddfc: r0 = translate()
    //     0x66ddfc: bl              #0x65ad6c  ; [dart:ui] Offset::translate
    // 0x66de00: add             SP, SP, #0x18
    // 0x66de04: ldur            x16, [fp, #-0x10]
    // 0x66de08: stp             x16, x0, [SP, #-0x10]!
    // 0x66de0c: r0 = &()
    //     0x66de0c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66de10: add             SP, SP, #0x10
    // 0x66de14: mov             x1, x0
    // 0x66de18: ldr             x0, [fp, #0x40]
    // 0x66de1c: stur            x1, [fp, #-8]
    // 0x66de20: tbnz            w0, #4, #0x66de34
    // 0x66de24: ldr             x16, [fp, #0x58]
    // 0x66de28: SaveReg r16
    //     0x66de28: str             x16, [SP, #-8]!
    // 0x66de2c: r0 = save()
    //     0x66de2c: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x66de30: add             SP, SP, #8
    // 0x66de34: ldr             x0, [fp, #0x40]
    // 0x66de38: tbnz            w0, #4, #0x66df20
    // 0x66de3c: ldur            d0, [fp, #-0x50]
    // 0x66de40: ldur            d2, [fp, #-0x48]
    // 0x66de44: d1 = 2.000000
    //     0x66de44: fmov            d1, #2.00000000
    // 0x66de48: fsub            d3, d2, d0
    // 0x66de4c: fdiv            d2, d3, d1
    // 0x66de50: fadd            d1, d0, d2
    // 0x66de54: fneg            d0, d1
    // 0x66de58: stur            d0, [fp, #-0x40]
    // 0x66de5c: fneg            d1, d0
    // 0x66de60: r1 = inline_Allocate_Double()
    //     0x66de60: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x66de64: add             x1, x1, #0x10
    //     0x66de68: cmp             x2, x1
    //     0x66de6c: b.ls            #0x66e014
    //     0x66de70: str             x1, [THR, #0x60]  ; THR::top
    //     0x66de74: sub             x1, x1, #0xf
    //     0x66de78: mov             x2, #0xd108
    //     0x66de7c: movk            x2, #3, lsl #16
    //     0x66de80: stur            x2, [x1, #-1]
    // 0x66de84: StoreField: r1->field_7 = d1
    //     0x66de84: stur            d1, [x1, #7]
    // 0x66de88: ldr             x16, [fp, #0x58]
    // 0x66de8c: stp             x1, x16, [SP, #-0x10]!
    // 0x66de90: SaveReg rZR
    //     0x66de90: str             xzr, [SP, #-8]!
    // 0x66de94: r0 = translate()
    //     0x66de94: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0x66de98: add             SP, SP, #0x18
    // 0x66de9c: d0 = 1.000000
    //     0x66de9c: fmov            d0, #1.00000000
    // 0x66dea0: fneg            d1, d0
    // 0x66dea4: r0 = inline_Allocate_Double()
    //     0x66dea4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x66dea8: add             x0, x0, #0x10
    //     0x66deac: cmp             x1, x0
    //     0x66deb0: b.ls            #0x66e030
    //     0x66deb4: str             x0, [THR, #0x60]  ; THR::top
    //     0x66deb8: sub             x0, x0, #0xf
    //     0x66debc: mov             x1, #0xd108
    //     0x66dec0: movk            x1, #3, lsl #16
    //     0x66dec4: stur            x1, [x0, #-1]
    // 0x66dec8: StoreField: r0->field_7 = d1
    //     0x66dec8: stur            d1, [x0, #7]
    // 0x66decc: ldr             x16, [fp, #0x58]
    // 0x66ded0: stp             x0, x16, [SP, #-0x10]!
    // 0x66ded4: SaveReg d0
    //     0x66ded4: str             d0, [SP, #-8]!
    // 0x66ded8: r0 = _scale()
    //     0x66ded8: bl              #0x656458  ; [dart:ui] Canvas::_scale
    // 0x66dedc: add             SP, SP, #0x18
    // 0x66dee0: ldur            d0, [fp, #-0x40]
    // 0x66dee4: r0 = inline_Allocate_Double()
    //     0x66dee4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x66dee8: add             x0, x0, #0x10
    //     0x66deec: cmp             x1, x0
    //     0x66def0: b.ls            #0x66e040
    //     0x66def4: str             x0, [THR, #0x60]  ; THR::top
    //     0x66def8: sub             x0, x0, #0xf
    //     0x66defc: mov             x1, #0xd108
    //     0x66df00: movk            x1, #3, lsl #16
    //     0x66df04: stur            x1, [x0, #-1]
    // 0x66df08: StoreField: r0->field_7 = d0
    //     0x66df08: stur            d0, [x0, #7]
    // 0x66df0c: ldr             x16, [fp, #0x58]
    // 0x66df10: stp             x0, x16, [SP, #-0x10]!
    // 0x66df14: SaveReg rZR
    //     0x66df14: str             xzr, [SP, #-8]!
    // 0x66df18: r0 = translate()
    //     0x66df18: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0x66df1c: add             SP, SP, #0x18
    // 0x66df20: ldr             x0, [fp, #0x40]
    // 0x66df24: r16 = Instance_Offset
    //     0x66df24: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x66df28: ldur            lr, [fp, #-0x20]
    // 0x66df2c: stp             lr, x16, [SP, #-0x10]!
    // 0x66df30: r0 = &()
    //     0x66df30: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66df34: add             SP, SP, #0x10
    // 0x66df38: r16 = Instance_Alignment
    //     0x66df38: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x66df3c: ldr             x16, [x16, #0xc70]
    // 0x66df40: ldur            lr, [fp, #-0x28]
    // 0x66df44: stp             lr, x16, [SP, #-0x10]!
    // 0x66df48: SaveReg r0
    //     0x66df48: str             x0, [SP, #-8]!
    // 0x66df4c: r0 = inscribe()
    //     0x66df4c: bl              #0x626960  ; [package:flutter/src/painting/alignment.dart] Alignment::inscribe
    // 0x66df50: add             SP, SP, #0x18
    // 0x66df54: ldr             x16, [fp, #0x58]
    // 0x66df58: ldr             lr, [fp, #0x38]
    // 0x66df5c: stp             lr, x16, [SP, #-0x10]!
    // 0x66df60: ldur            x16, [fp, #-8]
    // 0x66df64: stp             x16, x0, [SP, #-0x10]!
    // 0x66df68: ldur            x16, [fp, #-0x38]
    // 0x66df6c: SaveReg r16
    //     0x66df6c: str             x16, [SP, #-8]!
    // 0x66df70: r0 = drawImageRect()
    //     0x66df70: bl              #0x655a70  ; [dart:ui] Canvas::drawImageRect
    // 0x66df74: add             SP, SP, #0x28
    // 0x66df78: ldr             x0, [fp, #0x40]
    // 0x66df7c: tbnz            w0, #4, #0x66df90
    // 0x66df80: ldr             x16, [fp, #0x58]
    // 0x66df84: SaveReg r16
    //     0x66df84: str             x16, [SP, #-8]!
    // 0x66df88: r0 = restore()
    //     0x66df88: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x66df8c: add             SP, SP, #8
    // 0x66df90: r0 = Null
    //     0x66df90: mov             x0, NULL
    // 0x66df94: LeaveFrame
    //     0x66df94: mov             SP, fp
    //     0x66df98: ldp             fp, lr, [SP], #0x10
    // 0x66df9c: ret
    //     0x66df9c: ret             
    // 0x66dfa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66dfa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66dfa4: b               #0x66da88
    // 0x66dfa8: SaveReg d0
    //     0x66dfa8: str             q0, [SP, #-0x10]!
    // 0x66dfac: stp             x1, x2, [SP, #-0x10]!
    // 0x66dfb0: SaveReg r0
    //     0x66dfb0: str             x0, [SP, #-8]!
    // 0x66dfb4: r0 = AllocateDouble()
    //     0x66dfb4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66dfb8: mov             x3, x0
    // 0x66dfbc: RestoreReg r0
    //     0x66dfbc: ldr             x0, [SP], #8
    // 0x66dfc0: ldp             x1, x2, [SP], #0x10
    // 0x66dfc4: RestoreReg d0
    //     0x66dfc4: ldr             q0, [SP], #0x10
    // 0x66dfc8: b               #0x66dbc0
    // 0x66dfcc: SaveReg d2
    //     0x66dfcc: str             q2, [SP, #-0x10]!
    // 0x66dfd0: stp             x4, x5, [SP, #-0x10]!
    // 0x66dfd4: stp             x1, x2, [SP, #-0x10]!
    // 0x66dfd8: SaveReg r0
    //     0x66dfd8: str             x0, [SP, #-8]!
    // 0x66dfdc: r0 = AllocateDouble()
    //     0x66dfdc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66dfe0: mov             x3, x0
    // 0x66dfe4: RestoreReg r0
    //     0x66dfe4: ldr             x0, [SP], #8
    // 0x66dfe8: ldp             x1, x2, [SP], #0x10
    // 0x66dfec: ldp             x4, x5, [SP], #0x10
    // 0x66dff0: RestoreReg d2
    //     0x66dff0: ldr             q2, [SP], #0x10
    // 0x66dff4: b               #0x66dcc4
    // 0x66dff8: stp             q0, q1, [SP, #-0x20]!
    // 0x66dffc: SaveReg r0
    //     0x66dffc: str             x0, [SP, #-8]!
    // 0x66e000: r0 = AllocateDouble()
    //     0x66e000: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66e004: mov             x1, x0
    // 0x66e008: RestoreReg r0
    //     0x66e008: ldr             x0, [SP], #8
    // 0x66e00c: ldp             q0, q1, [SP], #0x20
    // 0x66e010: b               #0x66ddec
    // 0x66e014: stp             q0, q1, [SP, #-0x20]!
    // 0x66e018: SaveReg r0
    //     0x66e018: str             x0, [SP, #-8]!
    // 0x66e01c: r0 = AllocateDouble()
    //     0x66e01c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66e020: mov             x1, x0
    // 0x66e024: RestoreReg r0
    //     0x66e024: ldr             x0, [SP], #8
    // 0x66e028: ldp             q0, q1, [SP], #0x20
    // 0x66e02c: b               #0x66de84
    // 0x66e030: stp             q0, q1, [SP, #-0x20]!
    // 0x66e034: r0 = AllocateDouble()
    //     0x66e034: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66e038: ldp             q0, q1, [SP], #0x20
    // 0x66e03c: b               #0x66dec8
    // 0x66e040: SaveReg d0
    //     0x66e040: str             q0, [SP, #-0x10]!
    // 0x66e044: r0 = AllocateDouble()
    //     0x66e044: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66e048: RestoreReg d0
    //     0x66e048: ldr             q0, [SP], #0x10
    // 0x66e04c: b               #0x66df08
  }
}

// class id: 2104, size: 0x18, field offset: 0x8
class DecorationImagePainter extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xae11f4, size: 0x98
    // 0xae11f4: EnterFrame
    //     0xae11f4: stp             fp, lr, [SP, #-0x10]!
    //     0xae11f8: mov             fp, SP
    // 0xae11fc: CheckStackOverflow
    //     0xae11fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae1200: cmp             SP, x16
    //     0xae1204: b.ls            #0xae1284
    // 0xae1208: r1 = Null
    //     0xae1208: mov             x1, NULL
    // 0xae120c: r2 = 14
    //     0xae120c: mov             x2, #0xe
    // 0xae1210: r0 = AllocateArray()
    //     0xae1210: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae1214: r17 = "DecorationImagePainter"
    //     0xae1214: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dae8] "DecorationImagePainter"
    //     0xae1218: ldr             x17, [x17, #0xae8]
    // 0xae121c: StoreField: r0->field_f = r17
    //     0xae121c: stur            w17, [x0, #0xf]
    // 0xae1220: r17 = "(stream: "
    //     0xae1220: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2daf0] "(stream: "
    //     0xae1224: ldr             x17, [x17, #0xaf0]
    // 0xae1228: StoreField: r0->field_13 = r17
    //     0xae1228: stur            w17, [x0, #0x13]
    // 0xae122c: ldr             x1, [fp, #0x10]
    // 0xae1230: LoadField: r2 = r1->field_f
    //     0xae1230: ldur            w2, [x1, #0xf]
    // 0xae1234: DecompressPointer r2
    //     0xae1234: add             x2, x2, HEAP, lsl #32
    // 0xae1238: StoreField: r0->field_17 = r2
    //     0xae1238: stur            w2, [x0, #0x17]
    // 0xae123c: r17 = ", image: "
    //     0xae123c: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2daf8] ", image: "
    //     0xae1240: ldr             x17, [x17, #0xaf8]
    // 0xae1244: StoreField: r0->field_1b = r17
    //     0xae1244: stur            w17, [x0, #0x1b]
    // 0xae1248: LoadField: r2 = r1->field_13
    //     0xae1248: ldur            w2, [x1, #0x13]
    // 0xae124c: DecompressPointer r2
    //     0xae124c: add             x2, x2, HEAP, lsl #32
    // 0xae1250: StoreField: r0->field_1f = r2
    //     0xae1250: stur            w2, [x0, #0x1f]
    // 0xae1254: r17 = ") for "
    //     0xae1254: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2db00] ") for "
    //     0xae1258: ldr             x17, [x17, #0xb00]
    // 0xae125c: StoreField: r0->field_23 = r17
    //     0xae125c: stur            w17, [x0, #0x23]
    // 0xae1260: LoadField: r2 = r1->field_7
    //     0xae1260: ldur            w2, [x1, #7]
    // 0xae1264: DecompressPointer r2
    //     0xae1264: add             x2, x2, HEAP, lsl #32
    // 0xae1268: StoreField: r0->field_27 = r2
    //     0xae1268: stur            w2, [x0, #0x27]
    // 0xae126c: SaveReg r0
    //     0xae126c: str             x0, [SP, #-8]!
    // 0xae1270: r0 = _interpolate()
    //     0xae1270: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae1274: add             SP, SP, #8
    // 0xae1278: LeaveFrame
    //     0xae1278: mov             SP, fp
    //     0xae127c: ldp             fp, lr, [SP], #0x10
    // 0xae1280: ret
    //     0xae1280: ret             
    // 0xae1284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae1284: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae1288: b               #0xae1208
  }
  _ paint(/* No info */) {
    // ** addr: 0xc710b4, size: 0x24c
    // 0xc710b4: EnterFrame
    //     0xc710b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc710b8: mov             fp, SP
    // 0xc710bc: AllocStack(0x18)
    //     0xc710bc: sub             SP, SP, #0x18
    // 0xc710c0: CheckStackOverflow
    //     0xc710c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc710c4: cmp             SP, x16
    //     0xc710c8: b.ls            #0xc712f4
    // 0xc710cc: ldr             x0, [fp, #0x30]
    // 0xc710d0: LoadField: r1 = r0->field_7
    //     0xc710d0: ldur            w1, [x0, #7]
    // 0xc710d4: DecompressPointer r1
    //     0xc710d4: add             x1, x1, HEAP, lsl #32
    // 0xc710d8: stur            x1, [fp, #-8]
    // 0xc710dc: LoadField: r2 = r1->field_7
    //     0xc710dc: ldur            w2, [x1, #7]
    // 0xc710e0: DecompressPointer r2
    //     0xc710e0: add             x2, x2, HEAP, lsl #32
    // 0xc710e4: ldr             x16, [fp, #0x10]
    // 0xc710e8: stp             x16, x2, [SP, #-0x10]!
    // 0xc710ec: r0 = resolve()
    //     0xc710ec: bl              #0x7941c4  ; [package:flutter/src/painting/image_provider.dart] ImageProvider::resolve
    // 0xc710f0: add             SP, SP, #0x10
    // 0xc710f4: mov             x1, x0
    // 0xc710f8: stur            x1, [fp, #-0x10]
    // 0xc710fc: LoadField: r0 = r1->field_7
    //     0xc710fc: ldur            w0, [x1, #7]
    // 0xc71100: DecompressPointer r0
    //     0xc71100: add             x0, x0, HEAP, lsl #32
    // 0xc71104: cmp             w0, NULL
    // 0xc71108: b.ne            #0xc71110
    // 0xc7110c: mov             x0, x1
    // 0xc71110: ldr             x2, [fp, #0x30]
    // 0xc71114: LoadField: r3 = r2->field_f
    //     0xc71114: ldur            w3, [x2, #0xf]
    // 0xc71118: DecompressPointer r3
    //     0xc71118: add             x3, x3, HEAP, lsl #32
    // 0xc7111c: cmp             w3, NULL
    // 0xc71120: b.ne            #0xc7112c
    // 0xc71124: r3 = Null
    //     0xc71124: mov             x3, NULL
    // 0xc71128: b               #0xc71140
    // 0xc7112c: LoadField: r4 = r3->field_7
    //     0xc7112c: ldur            w4, [x3, #7]
    // 0xc71130: DecompressPointer r4
    //     0xc71130: add             x4, x4, HEAP, lsl #32
    // 0xc71134: cmp             w4, NULL
    // 0xc71138: b.eq            #0xc71140
    // 0xc7113c: mov             x3, x4
    // 0xc71140: r4 = 59
    //     0xc71140: mov             x4, #0x3b
    // 0xc71144: branchIfSmi(r0, 0xc71150)
    //     0xc71144: tbz             w0, #0, #0xc71150
    // 0xc71148: r4 = LoadClassIdInstr(r0)
    //     0xc71148: ldur            x4, [x0, #-1]
    //     0xc7114c: ubfx            x4, x4, #0xc, #0x14
    // 0xc71150: stp             x3, x0, [SP, #-0x10]!
    // 0xc71154: mov             x0, x4
    // 0xc71158: mov             lr, x0
    // 0xc7115c: ldr             lr, [x21, lr, lsl #3]
    // 0xc71160: blr             lr
    // 0xc71164: add             SP, SP, #0x10
    // 0xc71168: tbz             w0, #4, #0xc71204
    // 0xc7116c: ldr             x0, [fp, #0x30]
    // 0xc71170: r1 = 1
    //     0xc71170: mov             x1, #1
    // 0xc71174: r0 = AllocateContext()
    //     0xc71174: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc71178: mov             x1, x0
    // 0xc7117c: ldr             x0, [fp, #0x30]
    // 0xc71180: stur            x1, [fp, #-0x18]
    // 0xc71184: StoreField: r1->field_f = r0
    //     0xc71184: stur            w0, [x1, #0xf]
    // 0xc71188: r0 = ImageStreamListener()
    //     0xc71188: bl              #0x794068  ; AllocateImageStreamListenerStub -> ImageStreamListener (size=0x14)
    // 0xc7118c: ldur            x2, [fp, #-0x18]
    // 0xc71190: r1 = Function '_handleImage@857297748':.
    //     0xc71190: add             x1, PP, #0x28, lsl #12  ; [pp+0x287c8] AnonymousClosure: (0xc71300), in [package:flutter/src/painting/decoration_image.dart] DecorationImagePainter::_handleImage (0xc71354)
    //     0xc71194: ldr             x1, [x1, #0x7c8]
    // 0xc71198: stur            x0, [fp, #-0x18]
    // 0xc7119c: r0 = AllocateClosure()
    //     0xc7119c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc711a0: mov             x1, x0
    // 0xc711a4: ldur            x0, [fp, #-0x18]
    // 0xc711a8: StoreField: r0->field_7 = r1
    //     0xc711a8: stur            w1, [x0, #7]
    // 0xc711ac: ldr             x1, [fp, #0x30]
    // 0xc711b0: LoadField: r2 = r1->field_f
    //     0xc711b0: ldur            w2, [x1, #0xf]
    // 0xc711b4: DecompressPointer r2
    //     0xc711b4: add             x2, x2, HEAP, lsl #32
    // 0xc711b8: cmp             w2, NULL
    // 0xc711bc: b.eq            #0xc711d0
    // 0xc711c0: stp             x0, x2, [SP, #-0x10]!
    // 0xc711c4: r0 = removeListener()
    //     0xc711c4: bl              #0x793d7c  ; [package:flutter/src/painting/image_stream.dart] ImageStream::removeListener
    // 0xc711c8: add             SP, SP, #0x10
    // 0xc711cc: ldr             x1, [fp, #0x30]
    // 0xc711d0: ldur            x0, [fp, #-0x10]
    // 0xc711d4: StoreField: r1->field_f = r0
    //     0xc711d4: stur            w0, [x1, #0xf]
    //     0xc711d8: ldurb           w16, [x1, #-1]
    //     0xc711dc: ldurb           w17, [x0, #-1]
    //     0xc711e0: and             x16, x17, x16, lsr #2
    //     0xc711e4: tst             x16, HEAP, lsr #32
    //     0xc711e8: b.eq            #0xc711f0
    //     0xc711ec: bl              #0xd6826c
    // 0xc711f0: ldur            x16, [fp, #-0x10]
    // 0xc711f4: ldur            lr, [fp, #-0x18]
    // 0xc711f8: stp             lr, x16, [SP, #-0x10]!
    // 0xc711fc: r0 = addListener()
    //     0xc711fc: bl              #0x793c04  ; [package:flutter/src/painting/image_stream.dart] ImageStream::addListener
    // 0xc71200: add             SP, SP, #0x10
    // 0xc71204: ldr             x0, [fp, #0x30]
    // 0xc71208: LoadField: r1 = r0->field_13
    //     0xc71208: ldur            w1, [x0, #0x13]
    // 0xc7120c: DecompressPointer r1
    //     0xc7120c: add             x1, x1, HEAP, lsl #32
    // 0xc71210: cmp             w1, NULL
    // 0xc71214: b.ne            #0xc71228
    // 0xc71218: r0 = Null
    //     0xc71218: mov             x0, NULL
    // 0xc7121c: LeaveFrame
    //     0xc7121c: mov             SP, fp
    //     0xc71220: ldp             fp, lr, [SP], #0x10
    // 0xc71224: ret
    //     0xc71224: ret             
    // 0xc71228: ldr             x1, [fp, #0x18]
    // 0xc7122c: cmp             w1, NULL
    // 0xc71230: b.eq            #0xc7125c
    // 0xc71234: ldr             x16, [fp, #0x28]
    // 0xc71238: SaveReg r16
    //     0xc71238: str             x16, [SP, #-8]!
    // 0xc7123c: r0 = save()
    //     0xc7123c: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0xc71240: add             SP, SP, #8
    // 0xc71244: ldr             x16, [fp, #0x28]
    // 0xc71248: ldr             lr, [fp, #0x18]
    // 0xc7124c: stp             lr, x16, [SP, #-0x10]!
    // 0xc71250: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc71250: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc71254: r0 = clipPath()
    //     0xc71254: bl              #0x6629f4  ; [dart:ui] Canvas::clipPath
    // 0xc71258: add             SP, SP, #0x10
    // 0xc7125c: ldr             x0, [fp, #0x30]
    // 0xc71260: ldr             x1, [fp, #0x18]
    // 0xc71264: ldur            x2, [fp, #-8]
    // 0xc71268: LoadField: r3 = r0->field_13
    //     0xc71268: ldur            w3, [x0, #0x13]
    // 0xc7126c: DecompressPointer r3
    //     0xc7126c: add             x3, x3, HEAP, lsl #32
    // 0xc71270: cmp             w3, NULL
    // 0xc71274: b.eq            #0xc712fc
    // 0xc71278: LoadField: r0 = r3->field_7
    //     0xc71278: ldur            w0, [x3, #7]
    // 0xc7127c: DecompressPointer r0
    //     0xc7127c: add             x0, x0, HEAP, lsl #32
    // 0xc71280: LoadField: d0 = r3->field_b
    //     0xc71280: ldur            d0, [x3, #0xb]
    // 0xc71284: LoadField: r3 = r2->field_13
    //     0xc71284: ldur            w3, [x2, #0x13]
    // 0xc71288: DecompressPointer r3
    //     0xc71288: add             x3, x3, HEAP, lsl #32
    // 0xc7128c: ldr             x16, [fp, #0x28]
    // 0xc71290: stp             NULL, x16, [SP, #-0x10]!
    // 0xc71294: r16 = false
    //     0xc71294: add             x16, NULL, #0x30  ; false
    // 0xc71298: stp             x16, x3, [SP, #-0x10]!
    // 0xc7129c: r16 = false
    //     0xc7129c: add             x16, NULL, #0x30  ; false
    // 0xc712a0: stp             x16, x0, [SP, #-0x10]!
    // 0xc712a4: r16 = 1.000000
    //     0xc712a4: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xc712a8: ldr             lr, [fp, #0x20]
    // 0xc712ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc712b0: r16 = Instance_ImageRepeat
    //     0xc712b0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0xc712b4: ldr             x16, [x16, #0x540]
    // 0xc712b8: SaveReg r16
    //     0xc712b8: str             x16, [SP, #-8]!
    // 0xc712bc: SaveReg d0
    //     0xc712bc: str             d0, [SP, #-8]!
    // 0xc712c0: r0 = paintImage()
    //     0xc712c0: bl              #0x66da70  ; [package:flutter/src/painting/decoration_image.dart] ::paintImage
    // 0xc712c4: add             SP, SP, #0x50
    // 0xc712c8: ldr             x0, [fp, #0x18]
    // 0xc712cc: cmp             w0, NULL
    // 0xc712d0: b.eq            #0xc712e4
    // 0xc712d4: ldr             x16, [fp, #0x28]
    // 0xc712d8: SaveReg r16
    //     0xc712d8: str             x16, [SP, #-8]!
    // 0xc712dc: r0 = restore()
    //     0xc712dc: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0xc712e0: add             SP, SP, #8
    // 0xc712e4: r0 = Null
    //     0xc712e4: mov             x0, NULL
    // 0xc712e8: LeaveFrame
    //     0xc712e8: mov             SP, fp
    //     0xc712ec: ldp             fp, lr, [SP], #0x10
    // 0xc712f0: ret
    //     0xc712f0: ret             
    // 0xc712f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc712f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc712f8: b               #0xc710cc
    // 0xc712fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc712fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleImage(dynamic, ImageInfo, bool) {
    // ** addr: 0xc71300, size: 0x54
    // 0xc71300: EnterFrame
    //     0xc71300: stp             fp, lr, [SP, #-0x10]!
    //     0xc71304: mov             fp, SP
    // 0xc71308: ldr             x0, [fp, #0x20]
    // 0xc7130c: LoadField: r1 = r0->field_17
    //     0xc7130c: ldur            w1, [x0, #0x17]
    // 0xc71310: DecompressPointer r1
    //     0xc71310: add             x1, x1, HEAP, lsl #32
    // 0xc71314: CheckStackOverflow
    //     0xc71314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc71318: cmp             SP, x16
    //     0xc7131c: b.ls            #0xc7134c
    // 0xc71320: LoadField: r0 = r1->field_f
    //     0xc71320: ldur            w0, [x1, #0xf]
    // 0xc71324: DecompressPointer r0
    //     0xc71324: add             x0, x0, HEAP, lsl #32
    // 0xc71328: ldr             x16, [fp, #0x18]
    // 0xc7132c: stp             x16, x0, [SP, #-0x10]!
    // 0xc71330: ldr             x16, [fp, #0x10]
    // 0xc71334: SaveReg r16
    //     0xc71334: str             x16, [SP, #-8]!
    // 0xc71338: r0 = _handleImage()
    //     0xc71338: bl              #0xc71354  ; [package:flutter/src/painting/decoration_image.dart] DecorationImagePainter::_handleImage
    // 0xc7133c: add             SP, SP, #0x18
    // 0xc71340: LeaveFrame
    //     0xc71340: mov             SP, fp
    //     0xc71344: ldp             fp, lr, [SP], #0x10
    // 0xc71348: ret
    //     0xc71348: ret             
    // 0xc7134c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7134c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc71350: b               #0xc71320
  }
  _ _handleImage(/* No info */) {
    // ** addr: 0xc71354, size: 0x128
    // 0xc71354: EnterFrame
    //     0xc71354: stp             fp, lr, [SP, #-0x10]!
    //     0xc71358: mov             fp, SP
    // 0xc7135c: CheckStackOverflow
    //     0xc7135c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc71360: cmp             SP, x16
    //     0xc71364: b.ls            #0xc71474
    // 0xc71368: ldr             x1, [fp, #0x20]
    // 0xc7136c: LoadField: r0 = r1->field_13
    //     0xc7136c: ldur            w0, [x1, #0x13]
    // 0xc71370: DecompressPointer r0
    //     0xc71370: add             x0, x0, HEAP, lsl #32
    // 0xc71374: r2 = LoadClassIdInstr(r0)
    //     0xc71374: ldur            x2, [x0, #-1]
    //     0xc71378: ubfx            x2, x2, #0xc, #0x14
    // 0xc7137c: ldr             x16, [fp, #0x18]
    // 0xc71380: stp             x16, x0, [SP, #-0x10]!
    // 0xc71384: mov             x0, x2
    // 0xc71388: mov             lr, x0
    // 0xc7138c: ldr             lr, [x21, lr, lsl #3]
    // 0xc71390: blr             lr
    // 0xc71394: add             SP, SP, #0x10
    // 0xc71398: tbnz            w0, #4, #0xc713ac
    // 0xc7139c: r0 = Null
    //     0xc7139c: mov             x0, NULL
    // 0xc713a0: LeaveFrame
    //     0xc713a0: mov             SP, fp
    //     0xc713a4: ldp             fp, lr, [SP], #0x10
    // 0xc713a8: ret
    //     0xc713a8: ret             
    // 0xc713ac: ldr             x0, [fp, #0x20]
    // 0xc713b0: LoadField: r1 = r0->field_13
    //     0xc713b0: ldur            w1, [x0, #0x13]
    // 0xc713b4: DecompressPointer r1
    //     0xc713b4: add             x1, x1, HEAP, lsl #32
    // 0xc713b8: cmp             w1, NULL
    // 0xc713bc: b.eq            #0xc713f4
    // 0xc713c0: ldr             x16, [fp, #0x18]
    // 0xc713c4: stp             x16, x1, [SP, #-0x10]!
    // 0xc713c8: r0 = isCloneOf()
    //     0xc713c8: bl              #0xc7147c  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::isCloneOf
    // 0xc713cc: add             SP, SP, #0x10
    // 0xc713d0: tbnz            w0, #4, #0xc713f4
    // 0xc713d4: ldr             x16, [fp, #0x18]
    // 0xc713d8: SaveReg r16
    //     0xc713d8: str             x16, [SP, #-8]!
    // 0xc713dc: r0 = dispose()
    //     0xc713dc: bl              #0x794180  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0xc713e0: add             SP, SP, #8
    // 0xc713e4: r0 = Null
    //     0xc713e4: mov             x0, NULL
    // 0xc713e8: LeaveFrame
    //     0xc713e8: mov             SP, fp
    //     0xc713ec: ldp             fp, lr, [SP], #0x10
    // 0xc713f0: ret
    //     0xc713f0: ret             
    // 0xc713f4: ldr             x0, [fp, #0x20]
    // 0xc713f8: LoadField: r1 = r0->field_13
    //     0xc713f8: ldur            w1, [x0, #0x13]
    // 0xc713fc: DecompressPointer r1
    //     0xc713fc: add             x1, x1, HEAP, lsl #32
    // 0xc71400: cmp             w1, NULL
    // 0xc71404: b.ne            #0xc71410
    // 0xc71408: mov             x1, x0
    // 0xc7140c: b               #0xc71420
    // 0xc71410: SaveReg r1
    //     0xc71410: str             x1, [SP, #-8]!
    // 0xc71414: r0 = dispose()
    //     0xc71414: bl              #0x794180  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0xc71418: add             SP, SP, #8
    // 0xc7141c: ldr             x1, [fp, #0x20]
    // 0xc71420: ldr             x2, [fp, #0x10]
    // 0xc71424: ldr             x0, [fp, #0x18]
    // 0xc71428: StoreField: r1->field_13 = r0
    //     0xc71428: stur            w0, [x1, #0x13]
    //     0xc7142c: ldurb           w16, [x1, #-1]
    //     0xc71430: ldurb           w17, [x0, #-1]
    //     0xc71434: and             x16, x17, x16, lsr #2
    //     0xc71438: tst             x16, HEAP, lsr #32
    //     0xc7143c: b.eq            #0xc71444
    //     0xc71440: bl              #0xd6826c
    // 0xc71444: tbz             w2, #4, #0xc71464
    // 0xc71448: LoadField: r0 = r1->field_b
    //     0xc71448: ldur            w0, [x1, #0xb]
    // 0xc7144c: DecompressPointer r0
    //     0xc7144c: add             x0, x0, HEAP, lsl #32
    // 0xc71450: SaveReg r0
    //     0xc71450: str             x0, [SP, #-8]!
    // 0xc71454: ClosureCall
    //     0xc71454: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc71458: ldur            x2, [x0, #0x1f]
    //     0xc7145c: blr             x2
    // 0xc71460: add             SP, SP, #8
    // 0xc71464: r0 = Null
    //     0xc71464: mov             x0, NULL
    // 0xc71468: LeaveFrame
    //     0xc71468: mov             SP, fp
    //     0xc7146c: ldp             fp, lr, [SP], #0x10
    // 0xc71470: ret
    //     0xc71470: ret             
    // 0xc71474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc71474: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc71478: b               #0xc71368
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc7576c, size: 0xc4
    // 0xc7576c: EnterFrame
    //     0xc7576c: stp             fp, lr, [SP, #-0x10]!
    //     0xc75770: mov             fp, SP
    // 0xc75774: AllocStack(0x10)
    //     0xc75774: sub             SP, SP, #0x10
    // 0xc75778: CheckStackOverflow
    //     0xc75778: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7577c: cmp             SP, x16
    //     0xc75780: b.ls            #0xc75828
    // 0xc75784: ldr             x0, [fp, #0x10]
    // 0xc75788: LoadField: r1 = r0->field_f
    //     0xc75788: ldur            w1, [x0, #0xf]
    // 0xc7578c: DecompressPointer r1
    //     0xc7578c: add             x1, x1, HEAP, lsl #32
    // 0xc75790: stur            x1, [fp, #-8]
    // 0xc75794: cmp             w1, NULL
    // 0xc75798: b.eq            #0xc757ec
    // 0xc7579c: r1 = 1
    //     0xc7579c: mov             x1, #1
    // 0xc757a0: r0 = AllocateContext()
    //     0xc757a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc757a4: mov             x1, x0
    // 0xc757a8: ldr             x0, [fp, #0x10]
    // 0xc757ac: stur            x1, [fp, #-0x10]
    // 0xc757b0: StoreField: r1->field_f = r0
    //     0xc757b0: stur            w0, [x1, #0xf]
    // 0xc757b4: r0 = ImageStreamListener()
    //     0xc757b4: bl              #0x794068  ; AllocateImageStreamListenerStub -> ImageStreamListener (size=0x14)
    // 0xc757b8: ldur            x2, [fp, #-0x10]
    // 0xc757bc: r1 = Function '_handleImage@857297748':.
    //     0xc757bc: add             x1, PP, #0x28, lsl #12  ; [pp+0x287c8] AnonymousClosure: (0xc71300), in [package:flutter/src/painting/decoration_image.dart] DecorationImagePainter::_handleImage (0xc71354)
    //     0xc757c0: ldr             x1, [x1, #0x7c8]
    // 0xc757c4: stur            x0, [fp, #-0x10]
    // 0xc757c8: r0 = AllocateClosure()
    //     0xc757c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc757cc: mov             x1, x0
    // 0xc757d0: ldur            x0, [fp, #-0x10]
    // 0xc757d4: StoreField: r0->field_7 = r1
    //     0xc757d4: stur            w1, [x0, #7]
    // 0xc757d8: ldur            x16, [fp, #-8]
    // 0xc757dc: stp             x0, x16, [SP, #-0x10]!
    // 0xc757e0: r0 = removeListener()
    //     0xc757e0: bl              #0x793d7c  ; [package:flutter/src/painting/image_stream.dart] ImageStream::removeListener
    // 0xc757e4: add             SP, SP, #0x10
    // 0xc757e8: ldr             x0, [fp, #0x10]
    // 0xc757ec: LoadField: r1 = r0->field_13
    //     0xc757ec: ldur            w1, [x0, #0x13]
    // 0xc757f0: DecompressPointer r1
    //     0xc757f0: add             x1, x1, HEAP, lsl #32
    // 0xc757f4: cmp             w1, NULL
    // 0xc757f8: b.ne            #0xc75804
    // 0xc757fc: mov             x1, x0
    // 0xc75800: b               #0xc75814
    // 0xc75804: SaveReg r1
    //     0xc75804: str             x1, [SP, #-8]!
    // 0xc75808: r0 = dispose()
    //     0xc75808: bl              #0x794180  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0xc7580c: add             SP, SP, #8
    // 0xc75810: ldr             x1, [fp, #0x10]
    // 0xc75814: StoreField: r1->field_13 = rNULL
    //     0xc75814: stur            NULL, [x1, #0x13]
    // 0xc75818: r0 = Null
    //     0xc75818: mov             x0, NULL
    // 0xc7581c: LeaveFrame
    //     0xc7581c: mov             SP, fp
    //     0xc75820: ldp             fp, lr, [SP], #0x10
    // 0xc75824: ret
    //     0xc75824: ret             
    // 0xc75828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc75828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7582c: b               #0xc75784
  }
}

// class id: 2105, size: 0x44, field offset: 0x8
//   const constructor, 
class DecorationImage extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xae0cac, size: 0x548
    // 0xae0cac: EnterFrame
    //     0xae0cac: stp             fp, lr, [SP, #-0x10]!
    //     0xae0cb0: mov             fp, SP
    // 0xae0cb4: AllocStack(0x18)
    //     0xae0cb4: sub             SP, SP, #0x18
    // 0xae0cb8: CheckStackOverflow
    //     0xae0cb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae0cbc: cmp             SP, x16
    //     0xae0cc0: b.ls            #0xae11a0
    // 0xae0cc4: ldr             x0, [fp, #0x10]
    // 0xae0cc8: LoadField: r1 = r0->field_7
    //     0xae0cc8: ldur            w1, [x0, #7]
    // 0xae0ccc: DecompressPointer r1
    //     0xae0ccc: add             x1, x1, HEAP, lsl #32
    // 0xae0cd0: SaveReg r1
    //     0xae0cd0: str             x1, [SP, #-8]!
    // 0xae0cd4: r0 = _interpolateSingle()
    //     0xae0cd4: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xae0cd8: add             SP, SP, #8
    // 0xae0cdc: r1 = Null
    //     0xae0cdc: mov             x1, NULL
    // 0xae0ce0: r2 = 2
    //     0xae0ce0: mov             x2, #2
    // 0xae0ce4: stur            x0, [fp, #-8]
    // 0xae0ce8: r0 = AllocateArray()
    //     0xae0ce8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae0cec: mov             x2, x0
    // 0xae0cf0: ldur            x0, [fp, #-8]
    // 0xae0cf4: stur            x2, [fp, #-0x10]
    // 0xae0cf8: StoreField: r2->field_f = r0
    //     0xae0cf8: stur            w0, [x2, #0xf]
    // 0xae0cfc: r1 = <String>
    //     0xae0cfc: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xae0d00: r0 = AllocateGrowableArray()
    //     0xae0d00: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xae0d04: mov             x1, x0
    // 0xae0d08: ldur            x0, [fp, #-0x10]
    // 0xae0d0c: stur            x1, [fp, #-8]
    // 0xae0d10: StoreField: r1->field_f = r0
    //     0xae0d10: stur            w0, [x1, #0xf]
    // 0xae0d14: r0 = 2
    //     0xae0d14: mov             x0, #2
    // 0xae0d18: StoreField: r1->field_b = r0
    //     0xae0d18: stur            w0, [x1, #0xb]
    // 0xae0d1c: ldr             x0, [fp, #0x10]
    // 0xae0d20: LoadField: r2 = r0->field_13
    //     0xae0d20: ldur            w2, [x0, #0x13]
    // 0xae0d24: DecompressPointer r2
    //     0xae0d24: add             x2, x2, HEAP, lsl #32
    // 0xae0d28: r16 = Instance_BoxFit
    //     0xae0d28: add             x16, PP, #0x21, lsl #12  ; [pp+0x21cc8] Obj!BoxFit@b64df1
    //     0xae0d2c: ldr             x16, [x16, #0xcc8]
    // 0xae0d30: cmp             w2, w16
    // 0xae0d34: b.ne            #0xae0d40
    // 0xae0d38: mov             x2, x1
    // 0xae0d3c: b               #0xae0de4
    // 0xae0d40: SaveReg r2
    //     0xae0d40: str             x2, [SP, #-8]!
    // 0xae0d44: r0 = _interpolateSingle()
    //     0xae0d44: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xae0d48: add             SP, SP, #8
    // 0xae0d4c: mov             x1, x0
    // 0xae0d50: ldur            x0, [fp, #-8]
    // 0xae0d54: stur            x1, [fp, #-0x18]
    // 0xae0d58: LoadField: r2 = r0->field_b
    //     0xae0d58: ldur            w2, [x0, #0xb]
    // 0xae0d5c: DecompressPointer r2
    //     0xae0d5c: add             x2, x2, HEAP, lsl #32
    // 0xae0d60: stur            x2, [fp, #-0x10]
    // 0xae0d64: LoadField: r3 = r0->field_f
    //     0xae0d64: ldur            w3, [x0, #0xf]
    // 0xae0d68: DecompressPointer r3
    //     0xae0d68: add             x3, x3, HEAP, lsl #32
    // 0xae0d6c: LoadField: r4 = r3->field_b
    //     0xae0d6c: ldur            w4, [x3, #0xb]
    // 0xae0d70: DecompressPointer r4
    //     0xae0d70: add             x4, x4, HEAP, lsl #32
    // 0xae0d74: cmp             w2, w4
    // 0xae0d78: b.ne            #0xae0d88
    // 0xae0d7c: SaveReg r0
    //     0xae0d7c: str             x0, [SP, #-8]!
    // 0xae0d80: r0 = _growToNextCapacity()
    //     0xae0d80: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae0d84: add             SP, SP, #8
    // 0xae0d88: ldur            x0, [fp, #-0x10]
    // 0xae0d8c: ldur            x2, [fp, #-8]
    // 0xae0d90: r3 = LoadInt32Instr(r0)
    //     0xae0d90: sbfx            x3, x0, #1, #0x1f
    // 0xae0d94: add             x0, x3, #1
    // 0xae0d98: lsl             x1, x0, #1
    // 0xae0d9c: StoreField: r2->field_b = r1
    //     0xae0d9c: stur            w1, [x2, #0xb]
    // 0xae0da0: mov             x1, x3
    // 0xae0da4: cmp             x1, x0
    // 0xae0da8: b.hs            #0xae11a8
    // 0xae0dac: LoadField: r1 = r2->field_f
    //     0xae0dac: ldur            w1, [x2, #0xf]
    // 0xae0db0: DecompressPointer r1
    //     0xae0db0: add             x1, x1, HEAP, lsl #32
    // 0xae0db4: ldur            x0, [fp, #-0x18]
    // 0xae0db8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xae0db8: add             x25, x1, x3, lsl #2
    //     0xae0dbc: add             x25, x25, #0xf
    //     0xae0dc0: str             w0, [x25]
    //     0xae0dc4: tbz             w0, #0, #0xae0de0
    //     0xae0dc8: ldurb           w16, [x1, #-1]
    //     0xae0dcc: ldurb           w17, [x0, #-1]
    //     0xae0dd0: and             x16, x17, x16, lsr #2
    //     0xae0dd4: tst             x16, HEAP, lsr #32
    //     0xae0dd8: b.eq            #0xae0de0
    //     0xae0ddc: bl              #0xd67e5c
    // 0xae0de0: ldr             x0, [fp, #0x10]
    // 0xae0de4: LoadField: r1 = r0->field_17
    //     0xae0de4: ldur            w1, [x0, #0x17]
    // 0xae0de8: DecompressPointer r1
    //     0xae0de8: add             x1, x1, HEAP, lsl #32
    // 0xae0dec: SaveReg r1
    //     0xae0dec: str             x1, [SP, #-8]!
    // 0xae0df0: r0 = _interpolateSingle()
    //     0xae0df0: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xae0df4: add             SP, SP, #8
    // 0xae0df8: mov             x1, x0
    // 0xae0dfc: ldur            x0, [fp, #-8]
    // 0xae0e00: stur            x1, [fp, #-0x18]
    // 0xae0e04: LoadField: r2 = r0->field_b
    //     0xae0e04: ldur            w2, [x0, #0xb]
    // 0xae0e08: DecompressPointer r2
    //     0xae0e08: add             x2, x2, HEAP, lsl #32
    // 0xae0e0c: stur            x2, [fp, #-0x10]
    // 0xae0e10: LoadField: r3 = r0->field_f
    //     0xae0e10: ldur            w3, [x0, #0xf]
    // 0xae0e14: DecompressPointer r3
    //     0xae0e14: add             x3, x3, HEAP, lsl #32
    // 0xae0e18: LoadField: r4 = r3->field_b
    //     0xae0e18: ldur            w4, [x3, #0xb]
    // 0xae0e1c: DecompressPointer r4
    //     0xae0e1c: add             x4, x4, HEAP, lsl #32
    // 0xae0e20: cmp             w2, w4
    // 0xae0e24: b.ne            #0xae0e34
    // 0xae0e28: SaveReg r0
    //     0xae0e28: str             x0, [SP, #-8]!
    // 0xae0e2c: r0 = _growToNextCapacity()
    //     0xae0e2c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae0e30: add             SP, SP, #8
    // 0xae0e34: ldr             x4, [fp, #0x10]
    // 0xae0e38: ldur            x0, [fp, #-0x10]
    // 0xae0e3c: ldur            x3, [fp, #-8]
    // 0xae0e40: r2 = LoadInt32Instr(r0)
    //     0xae0e40: sbfx            x2, x0, #1, #0x1f
    // 0xae0e44: add             x0, x2, #1
    // 0xae0e48: lsl             x1, x0, #1
    // 0xae0e4c: StoreField: r3->field_b = r1
    //     0xae0e4c: stur            w1, [x3, #0xb]
    // 0xae0e50: mov             x1, x2
    // 0xae0e54: cmp             x1, x0
    // 0xae0e58: b.hs            #0xae11ac
    // 0xae0e5c: LoadField: r1 = r3->field_f
    //     0xae0e5c: ldur            w1, [x3, #0xf]
    // 0xae0e60: DecompressPointer r1
    //     0xae0e60: add             x1, x1, HEAP, lsl #32
    // 0xae0e64: ldur            x0, [fp, #-0x18]
    // 0xae0e68: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae0e68: add             x25, x1, x2, lsl #2
    //     0xae0e6c: add             x25, x25, #0xf
    //     0xae0e70: str             w0, [x25]
    //     0xae0e74: tbz             w0, #0, #0xae0e90
    //     0xae0e78: ldurb           w16, [x1, #-1]
    //     0xae0e7c: ldurb           w17, [x0, #-1]
    //     0xae0e80: and             x16, x17, x16, lsr #2
    //     0xae0e84: tst             x16, HEAP, lsr #32
    //     0xae0e88: b.eq            #0xae0e90
    //     0xae0e8c: bl              #0xd67e5c
    // 0xae0e90: r1 = Null
    //     0xae0e90: mov             x1, NULL
    // 0xae0e94: r2 = 4
    //     0xae0e94: mov             x2, #4
    // 0xae0e98: r0 = AllocateArray()
    //     0xae0e98: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae0e9c: r17 = "scale "
    //     0xae0e9c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21cd0] "scale "
    //     0xae0ea0: ldr             x17, [x17, #0xcd0]
    // 0xae0ea4: StoreField: r0->field_f = r17
    //     0xae0ea4: stur            w17, [x0, #0xf]
    // 0xae0ea8: ldr             x1, [fp, #0x10]
    // 0xae0eac: LoadField: d0 = r1->field_27
    //     0xae0eac: ldur            d0, [x1, #0x27]
    // 0xae0eb0: r2 = inline_Allocate_Double()
    //     0xae0eb0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae0eb4: add             x2, x2, #0x10
    //     0xae0eb8: cmp             x3, x2
    //     0xae0ebc: b.ls            #0xae11b0
    //     0xae0ec0: str             x2, [THR, #0x60]  ; THR::top
    //     0xae0ec4: sub             x2, x2, #0xf
    //     0xae0ec8: mov             x3, #0xd108
    //     0xae0ecc: movk            x3, #3, lsl #16
    //     0xae0ed0: stur            x3, [x2, #-1]
    // 0xae0ed4: StoreField: r2->field_7 = d0
    //     0xae0ed4: stur            d0, [x2, #7]
    // 0xae0ed8: StoreField: r0->field_13 = r2
    //     0xae0ed8: stur            w2, [x0, #0x13]
    // 0xae0edc: SaveReg r0
    //     0xae0edc: str             x0, [SP, #-8]!
    // 0xae0ee0: r0 = _interpolate()
    //     0xae0ee0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae0ee4: add             SP, SP, #8
    // 0xae0ee8: mov             x1, x0
    // 0xae0eec: ldur            x0, [fp, #-8]
    // 0xae0ef0: stur            x1, [fp, #-0x18]
    // 0xae0ef4: LoadField: r2 = r0->field_b
    //     0xae0ef4: ldur            w2, [x0, #0xb]
    // 0xae0ef8: DecompressPointer r2
    //     0xae0ef8: add             x2, x2, HEAP, lsl #32
    // 0xae0efc: stur            x2, [fp, #-0x10]
    // 0xae0f00: LoadField: r3 = r0->field_f
    //     0xae0f00: ldur            w3, [x0, #0xf]
    // 0xae0f04: DecompressPointer r3
    //     0xae0f04: add             x3, x3, HEAP, lsl #32
    // 0xae0f08: LoadField: r4 = r3->field_b
    //     0xae0f08: ldur            w4, [x3, #0xb]
    // 0xae0f0c: DecompressPointer r4
    //     0xae0f0c: add             x4, x4, HEAP, lsl #32
    // 0xae0f10: cmp             w2, w4
    // 0xae0f14: b.ne            #0xae0f24
    // 0xae0f18: SaveReg r0
    //     0xae0f18: str             x0, [SP, #-8]!
    // 0xae0f1c: r0 = _growToNextCapacity()
    //     0xae0f1c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae0f20: add             SP, SP, #8
    // 0xae0f24: ldr             x4, [fp, #0x10]
    // 0xae0f28: ldur            x0, [fp, #-0x10]
    // 0xae0f2c: ldur            x3, [fp, #-8]
    // 0xae0f30: r2 = LoadInt32Instr(r0)
    //     0xae0f30: sbfx            x2, x0, #1, #0x1f
    // 0xae0f34: add             x0, x2, #1
    // 0xae0f38: lsl             x1, x0, #1
    // 0xae0f3c: StoreField: r3->field_b = r1
    //     0xae0f3c: stur            w1, [x3, #0xb]
    // 0xae0f40: mov             x1, x2
    // 0xae0f44: cmp             x1, x0
    // 0xae0f48: b.hs            #0xae11cc
    // 0xae0f4c: LoadField: r1 = r3->field_f
    //     0xae0f4c: ldur            w1, [x3, #0xf]
    // 0xae0f50: DecompressPointer r1
    //     0xae0f50: add             x1, x1, HEAP, lsl #32
    // 0xae0f54: ldur            x0, [fp, #-0x18]
    // 0xae0f58: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae0f58: add             x25, x1, x2, lsl #2
    //     0xae0f5c: add             x25, x25, #0xf
    //     0xae0f60: str             w0, [x25]
    //     0xae0f64: tbz             w0, #0, #0xae0f80
    //     0xae0f68: ldurb           w16, [x1, #-1]
    //     0xae0f6c: ldurb           w17, [x0, #-1]
    //     0xae0f70: and             x16, x17, x16, lsr #2
    //     0xae0f74: tst             x16, HEAP, lsr #32
    //     0xae0f78: b.eq            #0xae0f80
    //     0xae0f7c: bl              #0xd67e5c
    // 0xae0f80: r1 = Null
    //     0xae0f80: mov             x1, NULL
    // 0xae0f84: r2 = 4
    //     0xae0f84: mov             x2, #4
    // 0xae0f88: r0 = AllocateArray()
    //     0xae0f88: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae0f8c: r17 = "opacity "
    //     0xae0f8c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21cd8] "opacity "
    //     0xae0f90: ldr             x17, [x17, #0xcd8]
    // 0xae0f94: StoreField: r0->field_f = r17
    //     0xae0f94: stur            w17, [x0, #0xf]
    // 0xae0f98: ldr             x1, [fp, #0x10]
    // 0xae0f9c: LoadField: d0 = r1->field_2f
    //     0xae0f9c: ldur            d0, [x1, #0x2f]
    // 0xae0fa0: r2 = inline_Allocate_Double()
    //     0xae0fa0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae0fa4: add             x2, x2, #0x10
    //     0xae0fa8: cmp             x3, x2
    //     0xae0fac: b.ls            #0xae11d0
    //     0xae0fb0: str             x2, [THR, #0x60]  ; THR::top
    //     0xae0fb4: sub             x2, x2, #0xf
    //     0xae0fb8: mov             x3, #0xd108
    //     0xae0fbc: movk            x3, #3, lsl #16
    //     0xae0fc0: stur            x3, [x2, #-1]
    // 0xae0fc4: StoreField: r2->field_7 = d0
    //     0xae0fc4: stur            d0, [x2, #7]
    // 0xae0fc8: StoreField: r0->field_13 = r2
    //     0xae0fc8: stur            w2, [x0, #0x13]
    // 0xae0fcc: SaveReg r0
    //     0xae0fcc: str             x0, [SP, #-8]!
    // 0xae0fd0: r0 = _interpolate()
    //     0xae0fd0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae0fd4: add             SP, SP, #8
    // 0xae0fd8: mov             x1, x0
    // 0xae0fdc: ldur            x0, [fp, #-8]
    // 0xae0fe0: stur            x1, [fp, #-0x18]
    // 0xae0fe4: LoadField: r2 = r0->field_b
    //     0xae0fe4: ldur            w2, [x0, #0xb]
    // 0xae0fe8: DecompressPointer r2
    //     0xae0fe8: add             x2, x2, HEAP, lsl #32
    // 0xae0fec: stur            x2, [fp, #-0x10]
    // 0xae0ff0: LoadField: r3 = r0->field_f
    //     0xae0ff0: ldur            w3, [x0, #0xf]
    // 0xae0ff4: DecompressPointer r3
    //     0xae0ff4: add             x3, x3, HEAP, lsl #32
    // 0xae0ff8: LoadField: r4 = r3->field_b
    //     0xae0ff8: ldur            w4, [x3, #0xb]
    // 0xae0ffc: DecompressPointer r4
    //     0xae0ffc: add             x4, x4, HEAP, lsl #32
    // 0xae1000: cmp             w2, w4
    // 0xae1004: b.ne            #0xae1014
    // 0xae1008: SaveReg r0
    //     0xae1008: str             x0, [SP, #-8]!
    // 0xae100c: r0 = _growToNextCapacity()
    //     0xae100c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae1010: add             SP, SP, #8
    // 0xae1014: ldr             x3, [fp, #0x10]
    // 0xae1018: ldur            x0, [fp, #-0x10]
    // 0xae101c: ldur            x2, [fp, #-8]
    // 0xae1020: r4 = LoadInt32Instr(r0)
    //     0xae1020: sbfx            x4, x0, #1, #0x1f
    // 0xae1024: add             x0, x4, #1
    // 0xae1028: lsl             x1, x0, #1
    // 0xae102c: StoreField: r2->field_b = r1
    //     0xae102c: stur            w1, [x2, #0xb]
    // 0xae1030: mov             x1, x4
    // 0xae1034: cmp             x1, x0
    // 0xae1038: b.hs            #0xae11ec
    // 0xae103c: LoadField: r1 = r2->field_f
    //     0xae103c: ldur            w1, [x2, #0xf]
    // 0xae1040: DecompressPointer r1
    //     0xae1040: add             x1, x1, HEAP, lsl #32
    // 0xae1044: ldur            x0, [fp, #-0x18]
    // 0xae1048: ArrayStore: r1[r4] = r0  ; List_4
    //     0xae1048: add             x25, x1, x4, lsl #2
    //     0xae104c: add             x25, x25, #0xf
    //     0xae1050: str             w0, [x25]
    //     0xae1054: tbz             w0, #0, #0xae1070
    //     0xae1058: ldurb           w16, [x1, #-1]
    //     0xae105c: ldurb           w17, [x0, #-1]
    //     0xae1060: and             x16, x17, x16, lsr #2
    //     0xae1064: tst             x16, HEAP, lsr #32
    //     0xae1068: b.eq            #0xae1070
    //     0xae106c: bl              #0xd67e5c
    // 0xae1070: LoadField: r0 = r3->field_37
    //     0xae1070: ldur            w0, [x3, #0x37]
    // 0xae1074: DecompressPointer r0
    //     0xae1074: add             x0, x0, HEAP, lsl #32
    // 0xae1078: SaveReg r0
    //     0xae1078: str             x0, [SP, #-8]!
    // 0xae107c: r0 = _interpolateSingle()
    //     0xae107c: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xae1080: add             SP, SP, #8
    // 0xae1084: mov             x1, x0
    // 0xae1088: ldur            x0, [fp, #-8]
    // 0xae108c: stur            x1, [fp, #-0x18]
    // 0xae1090: LoadField: r2 = r0->field_b
    //     0xae1090: ldur            w2, [x0, #0xb]
    // 0xae1094: DecompressPointer r2
    //     0xae1094: add             x2, x2, HEAP, lsl #32
    // 0xae1098: stur            x2, [fp, #-0x10]
    // 0xae109c: LoadField: r3 = r0->field_f
    //     0xae109c: ldur            w3, [x0, #0xf]
    // 0xae10a0: DecompressPointer r3
    //     0xae10a0: add             x3, x3, HEAP, lsl #32
    // 0xae10a4: LoadField: r4 = r3->field_b
    //     0xae10a4: ldur            w4, [x3, #0xb]
    // 0xae10a8: DecompressPointer r4
    //     0xae10a8: add             x4, x4, HEAP, lsl #32
    // 0xae10ac: cmp             w2, w4
    // 0xae10b0: b.ne            #0xae10c0
    // 0xae10b4: SaveReg r0
    //     0xae10b4: str             x0, [SP, #-8]!
    // 0xae10b8: r0 = _growToNextCapacity()
    //     0xae10b8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xae10bc: add             SP, SP, #8
    // 0xae10c0: ldur            x0, [fp, #-0x10]
    // 0xae10c4: ldur            x3, [fp, #-8]
    // 0xae10c8: r2 = LoadInt32Instr(r0)
    //     0xae10c8: sbfx            x2, x0, #1, #0x1f
    // 0xae10cc: add             x0, x2, #1
    // 0xae10d0: lsl             x1, x0, #1
    // 0xae10d4: StoreField: r3->field_b = r1
    //     0xae10d4: stur            w1, [x3, #0xb]
    // 0xae10d8: mov             x1, x2
    // 0xae10dc: cmp             x1, x0
    // 0xae10e0: b.hs            #0xae11f0
    // 0xae10e4: LoadField: r1 = r3->field_f
    //     0xae10e4: ldur            w1, [x3, #0xf]
    // 0xae10e8: DecompressPointer r1
    //     0xae10e8: add             x1, x1, HEAP, lsl #32
    // 0xae10ec: ldur            x0, [fp, #-0x18]
    // 0xae10f0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xae10f0: add             x25, x1, x2, lsl #2
    //     0xae10f4: add             x25, x25, #0xf
    //     0xae10f8: str             w0, [x25]
    //     0xae10fc: tbz             w0, #0, #0xae1118
    //     0xae1100: ldurb           w16, [x1, #-1]
    //     0xae1104: ldurb           w17, [x0, #-1]
    //     0xae1108: and             x16, x17, x16, lsr #2
    //     0xae110c: tst             x16, HEAP, lsr #32
    //     0xae1110: b.eq            #0xae1118
    //     0xae1114: bl              #0xd67e5c
    // 0xae1118: r1 = Null
    //     0xae1118: mov             x1, NULL
    // 0xae111c: r2 = 8
    //     0xae111c: mov             x2, #8
    // 0xae1120: r0 = AllocateArray()
    //     0xae1120: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae1124: stur            x0, [fp, #-0x10]
    // 0xae1128: r17 = "DecorationImage"
    //     0xae1128: add             x17, PP, #0x21, lsl #12  ; [pp+0x21ce0] "DecorationImage"
    //     0xae112c: ldr             x17, [x17, #0xce0]
    // 0xae1130: StoreField: r0->field_f = r17
    //     0xae1130: stur            w17, [x0, #0xf]
    // 0xae1134: r17 = "("
    //     0xae1134: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xae1138: StoreField: r0->field_13 = r17
    //     0xae1138: stur            w17, [x0, #0x13]
    // 0xae113c: ldur            x16, [fp, #-8]
    // 0xae1140: r30 = ", "
    //     0xae1140: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae1144: stp             lr, x16, [SP, #-0x10]!
    // 0xae1148: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xae1148: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xae114c: r0 = join()
    //     0xae114c: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xae1150: add             SP, SP, #0x10
    // 0xae1154: ldur            x1, [fp, #-0x10]
    // 0xae1158: ArrayStore: r1[2] = r0  ; List_4
    //     0xae1158: add             x25, x1, #0x17
    //     0xae115c: str             w0, [x25]
    //     0xae1160: tbz             w0, #0, #0xae117c
    //     0xae1164: ldurb           w16, [x1, #-1]
    //     0xae1168: ldurb           w17, [x0, #-1]
    //     0xae116c: and             x16, x17, x16, lsr #2
    //     0xae1170: tst             x16, HEAP, lsr #32
    //     0xae1174: b.eq            #0xae117c
    //     0xae1178: bl              #0xd67e5c
    // 0xae117c: ldur            x0, [fp, #-0x10]
    // 0xae1180: r17 = ")"
    //     0xae1180: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae1184: StoreField: r0->field_1b = r17
    //     0xae1184: stur            w17, [x0, #0x1b]
    // 0xae1188: SaveReg r0
    //     0xae1188: str             x0, [SP, #-8]!
    // 0xae118c: r0 = _interpolate()
    //     0xae118c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae1190: add             SP, SP, #8
    // 0xae1194: LeaveFrame
    //     0xae1194: mov             SP, fp
    //     0xae1198: ldp             fp, lr, [SP], #0x10
    // 0xae119c: ret
    //     0xae119c: ret             
    // 0xae11a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae11a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae11a4: b               #0xae0cc4
    // 0xae11a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae11a8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae11ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae11ac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae11b0: SaveReg d0
    //     0xae11b0: str             q0, [SP, #-0x10]!
    // 0xae11b4: stp             x0, x1, [SP, #-0x10]!
    // 0xae11b8: r0 = AllocateDouble()
    //     0xae11b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae11bc: mov             x2, x0
    // 0xae11c0: ldp             x0, x1, [SP], #0x10
    // 0xae11c4: RestoreReg d0
    //     0xae11c4: ldr             q0, [SP], #0x10
    // 0xae11c8: b               #0xae0ed4
    // 0xae11cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae11cc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae11d0: SaveReg d0
    //     0xae11d0: str             q0, [SP, #-0x10]!
    // 0xae11d4: stp             x0, x1, [SP, #-0x10]!
    // 0xae11d8: r0 = AllocateDouble()
    //     0xae11d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae11dc: mov             x2, x0
    // 0xae11e0: ldp             x0, x1, [SP], #0x10
    // 0xae11e4: RestoreReg d0
    //     0xae11e4: ldr             q0, [SP], #0x10
    // 0xae11e8: b               #0xae0fc4
    // 0xae11ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae11ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xae11f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xae11f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0e3b0, size: 0xa8
    // 0xb0e3b0: EnterFrame
    //     0xb0e3b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb0e3b4: mov             fp, SP
    // 0xb0e3b8: CheckStackOverflow
    //     0xb0e3b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0e3bc: cmp             SP, x16
    //     0xb0e3c0: b.ls            #0xb0e450
    // 0xb0e3c4: ldr             x0, [fp, #0x10]
    // 0xb0e3c8: LoadField: r1 = r0->field_7
    //     0xb0e3c8: ldur            w1, [x0, #7]
    // 0xb0e3cc: DecompressPointer r1
    //     0xb0e3cc: add             x1, x1, HEAP, lsl #32
    // 0xb0e3d0: LoadField: r2 = r0->field_13
    //     0xb0e3d0: ldur            w2, [x0, #0x13]
    // 0xb0e3d4: DecompressPointer r2
    //     0xb0e3d4: add             x2, x2, HEAP, lsl #32
    // 0xb0e3d8: stp             NULL, x1, [SP, #-0x10]!
    // 0xb0e3dc: r16 = Instance_Alignment
    //     0xb0e3dc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb0e3e0: ldr             x16, [x16, #0xc70]
    // 0xb0e3e4: stp             x16, x2, [SP, #-0x10]!
    // 0xb0e3e8: r16 = Instance_ImageRepeat
    //     0xb0e3e8: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c540] Obj!ImageRepeat@b64dd1
    //     0xb0e3ec: ldr             x16, [x16, #0x540]
    // 0xb0e3f0: stp             x16, NULL, [SP, #-0x10]!
    // 0xb0e3f4: r16 = false
    //     0xb0e3f4: add             x16, NULL, #0x30  ; false
    // 0xb0e3f8: r30 = 1.000000
    //     0xb0e3f8: ldr             lr, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb0e3fc: stp             lr, x16, [SP, #-0x10]!
    // 0xb0e400: r16 = 1.000000
    //     0xb0e400: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb0e404: r30 = Instance_FilterQuality
    //     0xb0e404: add             lr, PP, #0x1c, lsl #12  ; [pp+0x1c548] Obj!FilterQuality@b67811
    //     0xb0e408: ldr             lr, [lr, #0x548]
    // 0xb0e40c: stp             lr, x16, [SP, #-0x10]!
    // 0xb0e410: r16 = false
    //     0xb0e410: add             x16, NULL, #0x30  ; false
    // 0xb0e414: r30 = false
    //     0xb0e414: add             lr, NULL, #0x30  ; false
    // 0xb0e418: stp             lr, x16, [SP, #-0x10]!
    // 0xb0e41c: r4 = const [0, 0xc, 0xc, 0xc, null]
    //     0xb0e41c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe110] List(5) [0, 0xc, 0xc, 0xc, Null]
    //     0xb0e420: ldr             x4, [x4, #0x110]
    // 0xb0e424: r0 = hash()
    //     0xb0e424: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0e428: add             SP, SP, #0x60
    // 0xb0e42c: mov             x2, x0
    // 0xb0e430: r0 = BoxInt64Instr(r2)
    //     0xb0e430: sbfiz           x0, x2, #1, #0x1f
    //     0xb0e434: cmp             x2, x0, asr #1
    //     0xb0e438: b.eq            #0xb0e444
    //     0xb0e43c: bl              #0xd69bb8
    //     0xb0e440: stur            x2, [x0, #7]
    // 0xb0e444: LeaveFrame
    //     0xb0e444: mov             SP, fp
    //     0xb0e448: ldp             fp, lr, [SP], #0x10
    // 0xb0e44c: ret
    //     0xb0e44c: ret             
    // 0xb0e450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0e450: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0e454: b               #0xb0e3c4
  }
  _ createPainter(/* No info */) {
    // ** addr: 0xc7151c, size: 0x28
    // 0xc7151c: EnterFrame
    //     0xc7151c: stp             fp, lr, [SP, #-0x10]!
    //     0xc71520: mov             fp, SP
    // 0xc71524: r0 = DecorationImagePainter()
    //     0xc71524: bl              #0xc71544  ; AllocateDecorationImagePainterStub -> DecorationImagePainter (size=0x18)
    // 0xc71528: ldr             x1, [fp, #0x18]
    // 0xc7152c: StoreField: r0->field_7 = r1
    //     0xc7152c: stur            w1, [x0, #7]
    // 0xc71530: ldr             x1, [fp, #0x10]
    // 0xc71534: StoreField: r0->field_b = r1
    //     0xc71534: stur            w1, [x0, #0xb]
    // 0xc71538: LeaveFrame
    //     0xc71538: mov             SP, fp
    //     0xc7153c: ldp             fp, lr, [SP], #0x10
    // 0xc71540: ret
    //     0xc71540: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9d164, size: 0x190
    // 0xc9d164: EnterFrame
    //     0xc9d164: stp             fp, lr, [SP, #-0x10]!
    //     0xc9d168: mov             fp, SP
    // 0xc9d16c: CheckStackOverflow
    //     0xc9d16c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9d170: cmp             SP, x16
    //     0xc9d174: b.ls            #0xc9d2ec
    // 0xc9d178: ldr             x1, [fp, #0x10]
    // 0xc9d17c: cmp             w1, NULL
    // 0xc9d180: b.ne            #0xc9d194
    // 0xc9d184: r0 = false
    //     0xc9d184: add             x0, NULL, #0x30  ; false
    // 0xc9d188: LeaveFrame
    //     0xc9d188: mov             SP, fp
    //     0xc9d18c: ldp             fp, lr, [SP], #0x10
    // 0xc9d190: ret
    //     0xc9d190: ret             
    // 0xc9d194: ldr             x2, [fp, #0x18]
    // 0xc9d198: cmp             w2, w1
    // 0xc9d19c: b.ne            #0xc9d1b0
    // 0xc9d1a0: r0 = true
    //     0xc9d1a0: add             x0, NULL, #0x20  ; true
    // 0xc9d1a4: LeaveFrame
    //     0xc9d1a4: mov             SP, fp
    //     0xc9d1a8: ldp             fp, lr, [SP], #0x10
    // 0xc9d1ac: ret
    //     0xc9d1ac: ret             
    // 0xc9d1b0: r0 = 59
    //     0xc9d1b0: mov             x0, #0x3b
    // 0xc9d1b4: branchIfSmi(r1, 0xc9d1c0)
    //     0xc9d1b4: tbz             w1, #0, #0xc9d1c0
    // 0xc9d1b8: r0 = LoadClassIdInstr(r1)
    //     0xc9d1b8: ldur            x0, [x1, #-1]
    //     0xc9d1bc: ubfx            x0, x0, #0xc, #0x14
    // 0xc9d1c0: SaveReg r1
    //     0xc9d1c0: str             x1, [SP, #-8]!
    // 0xc9d1c4: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9d1c4: mov             x17, #0x57c5
    //     0xc9d1c8: add             lr, x0, x17
    //     0xc9d1cc: ldr             lr, [x21, lr, lsl #3]
    //     0xc9d1d0: blr             lr
    // 0xc9d1d4: add             SP, SP, #8
    // 0xc9d1d8: r1 = LoadClassIdInstr(r0)
    //     0xc9d1d8: ldur            x1, [x0, #-1]
    //     0xc9d1dc: ubfx            x1, x1, #0xc, #0x14
    // 0xc9d1e0: r16 = DecorationImage
    //     0xc9d1e0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21ce8] Type: DecorationImage
    //     0xc9d1e4: ldr             x16, [x16, #0xce8]
    // 0xc9d1e8: stp             x16, x0, [SP, #-0x10]!
    // 0xc9d1ec: mov             x0, x1
    // 0xc9d1f0: mov             lr, x0
    // 0xc9d1f4: ldr             lr, [x21, lr, lsl #3]
    // 0xc9d1f8: blr             lr
    // 0xc9d1fc: add             SP, SP, #0x10
    // 0xc9d200: tbz             w0, #4, #0xc9d214
    // 0xc9d204: r0 = false
    //     0xc9d204: add             x0, NULL, #0x30  ; false
    // 0xc9d208: LeaveFrame
    //     0xc9d208: mov             SP, fp
    //     0xc9d20c: ldp             fp, lr, [SP], #0x10
    // 0xc9d210: ret
    //     0xc9d210: ret             
    // 0xc9d214: ldr             x1, [fp, #0x10]
    // 0xc9d218: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9d218: mov             x0, #0x76
    //     0xc9d21c: tbz             w1, #0, #0xc9d22c
    //     0xc9d220: ldur            x0, [x1, #-1]
    //     0xc9d224: ubfx            x0, x0, #0xc, #0x14
    //     0xc9d228: lsl             x0, x0, #1
    // 0xc9d22c: r17 = 4210
    //     0xc9d22c: mov             x17, #0x1072
    // 0xc9d230: cmp             w0, w17
    // 0xc9d234: b.ne            #0xc9d2dc
    // 0xc9d238: ldr             x2, [fp, #0x18]
    // 0xc9d23c: LoadField: r0 = r1->field_7
    //     0xc9d23c: ldur            w0, [x1, #7]
    // 0xc9d240: DecompressPointer r0
    //     0xc9d240: add             x0, x0, HEAP, lsl #32
    // 0xc9d244: LoadField: r3 = r2->field_7
    //     0xc9d244: ldur            w3, [x2, #7]
    // 0xc9d248: DecompressPointer r3
    //     0xc9d248: add             x3, x3, HEAP, lsl #32
    // 0xc9d24c: r4 = LoadClassIdInstr(r0)
    //     0xc9d24c: ldur            x4, [x0, #-1]
    //     0xc9d250: ubfx            x4, x4, #0xc, #0x14
    // 0xc9d254: stp             x3, x0, [SP, #-0x10]!
    // 0xc9d258: mov             x0, x4
    // 0xc9d25c: mov             lr, x0
    // 0xc9d260: ldr             lr, [x21, lr, lsl #3]
    // 0xc9d264: blr             lr
    // 0xc9d268: add             SP, SP, #0x10
    // 0xc9d26c: tbnz            w0, #4, #0xc9d2dc
    // 0xc9d270: ldr             x1, [fp, #0x18]
    // 0xc9d274: ldr             x0, [fp, #0x10]
    // 0xc9d278: LoadField: r2 = r0->field_13
    //     0xc9d278: ldur            w2, [x0, #0x13]
    // 0xc9d27c: DecompressPointer r2
    //     0xc9d27c: add             x2, x2, HEAP, lsl #32
    // 0xc9d280: LoadField: r0 = r1->field_13
    //     0xc9d280: ldur            w0, [x1, #0x13]
    // 0xc9d284: DecompressPointer r0
    //     0xc9d284: add             x0, x0, HEAP, lsl #32
    // 0xc9d288: cmp             w2, w0
    // 0xc9d28c: b.ne            #0xc9d2dc
    // 0xc9d290: r16 = Instance_Alignment
    //     0xc9d290: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc9d294: ldr             x16, [x16, #0xc70]
    // 0xc9d298: r30 = Instance_Alignment
    //     0xc9d298: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc9d29c: ldr             lr, [lr, #0xc70]
    // 0xc9d2a0: stp             lr, x16, [SP, #-0x10]!
    // 0xc9d2a4: r0 = ==()
    //     0xc9d2a4: bl              #0xc9c720  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xc9d2a8: add             SP, SP, #0x10
    // 0xc9d2ac: tbnz            w0, #4, #0xc9d2dc
    // 0xc9d2b0: d0 = 1.000000
    //     0xc9d2b0: fmov            d0, #1.00000000
    // 0xc9d2b4: fcmp            d0, d0
    // 0xc9d2b8: b.vs            #0xc9d2c0
    // 0xc9d2bc: b.eq            #0xc9d2c8
    // 0xc9d2c0: r1 = false
    //     0xc9d2c0: add             x1, NULL, #0x30  ; false
    // 0xc9d2c4: b               #0xc9d2cc
    // 0xc9d2c8: r1 = true
    //     0xc9d2c8: add             x1, NULL, #0x20  ; true
    // 0xc9d2cc: tbnz            w1, #4, #0xc9d2dc
    // 0xc9d2d0: tbnz            w1, #4, #0xc9d2dc
    // 0xc9d2d4: r0 = true
    //     0xc9d2d4: add             x0, NULL, #0x20  ; true
    // 0xc9d2d8: b               #0xc9d2e0
    // 0xc9d2dc: r0 = false
    //     0xc9d2dc: add             x0, NULL, #0x30  ; false
    // 0xc9d2e0: LeaveFrame
    //     0xc9d2e0: mov             SP, fp
    //     0xc9d2e4: ldp             fp, lr, [SP], #0x10
    // 0xc9d2e8: ret
    //     0xc9d2e8: ret             
    // 0xc9d2ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9d2ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9d2f0: b               #0xc9d178
  }
}

// class id: 5933, size: 0x14, field offset: 0x14
enum ImageRepeat extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb169d8, size: 0x5c
    // 0xb169d8: EnterFrame
    //     0xb169d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb169dc: mov             fp, SP
    // 0xb169e0: CheckStackOverflow
    //     0xb169e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb169e4: cmp             SP, x16
    //     0xb169e8: b.ls            #0xb16a2c
    // 0xb169ec: r1 = Null
    //     0xb169ec: mov             x1, NULL
    // 0xb169f0: r2 = 4
    //     0xb169f0: mov             x2, #4
    // 0xb169f4: r0 = AllocateArray()
    //     0xb169f4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb169f8: r17 = "ImageRepeat."
    //     0xb169f8: add             x17, PP, #0x21, lsl #12  ; [pp+0x21cc0] "ImageRepeat."
    //     0xb169fc: ldr             x17, [x17, #0xcc0]
    // 0xb16a00: StoreField: r0->field_f = r17
    //     0xb16a00: stur            w17, [x0, #0xf]
    // 0xb16a04: ldr             x1, [fp, #0x10]
    // 0xb16a08: LoadField: r2 = r1->field_f
    //     0xb16a08: ldur            w2, [x1, #0xf]
    // 0xb16a0c: DecompressPointer r2
    //     0xb16a0c: add             x2, x2, HEAP, lsl #32
    // 0xb16a10: StoreField: r0->field_13 = r2
    //     0xb16a10: stur            w2, [x0, #0x13]
    // 0xb16a14: SaveReg r0
    //     0xb16a14: str             x0, [SP, #-8]!
    // 0xb16a18: r0 = _interpolate()
    //     0xb16a18: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16a1c: add             SP, SP, #8
    // 0xb16a20: LeaveFrame
    //     0xb16a20: mov             SP, fp
    //     0xb16a24: ldp             fp, lr, [SP], #0x10
    // 0xb16a28: ret
    //     0xb16a28: ret             
    // 0xb16a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16a30: b               #0xb169ec
  }
}

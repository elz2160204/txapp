// lib: , url: package:flutter/src/painting/_network_image_io.dart

// class id: 1049343, size: 0x8
class :: {
}

// class id: 4467, size: 0x1c, field offset: 0xc
//   const constructor, 
class NetworkImage extends ImageProvider<NetworkImage>
    implements NetworkImage {

  static late final HttpClient _sharedHttpClient; // offset: 0xfbc

  _ toString(/* No info */) {
    // ** addr: 0xad3bd4, size: 0xc8
    // 0xad3bd4: EnterFrame
    //     0xad3bd4: stp             fp, lr, [SP, #-0x10]!
    //     0xad3bd8: mov             fp, SP
    // 0xad3bdc: CheckStackOverflow
    //     0xad3bdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3be0: cmp             SP, x16
    //     0xad3be4: b.ls            #0xad3c78
    // 0xad3be8: r1 = Null
    //     0xad3be8: mov             x1, NULL
    // 0xad3bec: r2 = 12
    //     0xad3bec: mov             x2, #0xc
    // 0xad3bf0: r0 = AllocateArray()
    //     0xad3bf0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad3bf4: r17 = "NetworkImage"
    //     0xad3bf4: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3f5b0] "NetworkImage"
    //     0xad3bf8: ldr             x17, [x17, #0x5b0]
    // 0xad3bfc: StoreField: r0->field_f = r17
    //     0xad3bfc: stur            w17, [x0, #0xf]
    // 0xad3c00: r17 = "(\""
    //     0xad3c00: add             x17, PP, #0xd, lsl #12  ; [pp+0xde48] "(\""
    //     0xad3c04: ldr             x17, [x17, #0xe48]
    // 0xad3c08: StoreField: r0->field_13 = r17
    //     0xad3c08: stur            w17, [x0, #0x13]
    // 0xad3c0c: ldr             x1, [fp, #0x10]
    // 0xad3c10: LoadField: r2 = r1->field_b
    //     0xad3c10: ldur            w2, [x1, #0xb]
    // 0xad3c14: DecompressPointer r2
    //     0xad3c14: add             x2, x2, HEAP, lsl #32
    // 0xad3c18: StoreField: r0->field_17 = r2
    //     0xad3c18: stur            w2, [x0, #0x17]
    // 0xad3c1c: r17 = "\", scale: "
    //     0xad3c1c: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c940] "\", scale: "
    //     0xad3c20: ldr             x17, [x17, #0x940]
    // 0xad3c24: StoreField: r0->field_1b = r17
    //     0xad3c24: stur            w17, [x0, #0x1b]
    // 0xad3c28: LoadField: d0 = r1->field_f
    //     0xad3c28: ldur            d0, [x1, #0xf]
    // 0xad3c2c: r1 = inline_Allocate_Double()
    //     0xad3c2c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xad3c30: add             x1, x1, #0x10
    //     0xad3c34: cmp             x2, x1
    //     0xad3c38: b.ls            #0xad3c80
    //     0xad3c3c: str             x1, [THR, #0x60]  ; THR::top
    //     0xad3c40: sub             x1, x1, #0xf
    //     0xad3c44: mov             x2, #0xd108
    //     0xad3c48: movk            x2, #3, lsl #16
    //     0xad3c4c: stur            x2, [x1, #-1]
    // 0xad3c50: StoreField: r1->field_7 = d0
    //     0xad3c50: stur            d0, [x1, #7]
    // 0xad3c54: StoreField: r0->field_1f = r1
    //     0xad3c54: stur            w1, [x0, #0x1f]
    // 0xad3c58: r17 = ")"
    //     0xad3c58: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad3c5c: StoreField: r0->field_23 = r17
    //     0xad3c5c: stur            w17, [x0, #0x23]
    // 0xad3c60: SaveReg r0
    //     0xad3c60: str             x0, [SP, #-8]!
    // 0xad3c64: r0 = _interpolate()
    //     0xad3c64: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3c68: add             SP, SP, #8
    // 0xad3c6c: LeaveFrame
    //     0xad3c6c: mov             SP, fp
    //     0xad3c70: ldp             fp, lr, [SP], #0x10
    // 0xad3c74: ret
    //     0xad3c74: ret             
    // 0xad3c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3c78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3c7c: b               #0xad3be8
    // 0xad3c80: SaveReg d0
    //     0xad3c80: str             q0, [SP, #-0x10]!
    // 0xad3c84: SaveReg r0
    //     0xad3c84: str             x0, [SP, #-8]!
    // 0xad3c88: r0 = AllocateDouble()
    //     0xad3c88: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad3c8c: mov             x1, x0
    // 0xad3c90: RestoreReg r0
    //     0xad3c90: ldr             x0, [SP], #8
    // 0xad3c94: RestoreReg d0
    //     0xad3c94: ldr             q0, [SP], #0x10
    // 0xad3c98: b               #0xad3c50
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafaef0, size: 0x60
    // 0xafaef0: EnterFrame
    //     0xafaef0: stp             fp, lr, [SP, #-0x10]!
    //     0xafaef4: mov             fp, SP
    // 0xafaef8: CheckStackOverflow
    //     0xafaef8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafaefc: cmp             SP, x16
    //     0xafaf00: b.ls            #0xafaf48
    // 0xafaf04: ldr             x0, [fp, #0x10]
    // 0xafaf08: LoadField: r1 = r0->field_b
    //     0xafaf08: ldur            w1, [x0, #0xb]
    // 0xafaf0c: DecompressPointer r1
    //     0xafaf0c: add             x1, x1, HEAP, lsl #32
    // 0xafaf10: r16 = 1.000000
    //     0xafaf10: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xafaf14: stp             x16, x1, [SP, #-0x10]!
    // 0xafaf18: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xafaf18: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xafaf1c: r0 = hash()
    //     0xafaf1c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafaf20: add             SP, SP, #0x10
    // 0xafaf24: mov             x2, x0
    // 0xafaf28: r0 = BoxInt64Instr(r2)
    //     0xafaf28: sbfiz           x0, x2, #1, #0x1f
    //     0xafaf2c: cmp             x2, x0, asr #1
    //     0xafaf30: b.eq            #0xafaf3c
    //     0xafaf34: bl              #0xd69bb8
    //     0xafaf38: stur            x2, [x0, #7]
    // 0xafaf3c: LeaveFrame
    //     0xafaf3c: mov             SP, fp
    //     0xafaf40: ldp             fp, lr, [SP], #0x10
    // 0xafaf44: ret
    //     0xafaf44: ret             
    // 0xafaf48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafaf48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafaf4c: b               #0xafaf04
  }
  _ loadBuffer(/* No info */) {
    // ** addr: 0xc302cc, size: 0x154
    // 0xc302cc: EnterFrame
    //     0xc302cc: stp             fp, lr, [SP, #-0x10]!
    //     0xc302d0: mov             fp, SP
    // 0xc302d4: AllocStack(0x28)
    //     0xc302d4: sub             SP, SP, #0x28
    // 0xc302d8: CheckStackOverflow
    //     0xc302d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc302dc: cmp             SP, x16
    //     0xc302e0: b.ls            #0xc30418
    // 0xc302e4: r1 = 2
    //     0xc302e4: mov             x1, #2
    // 0xc302e8: r0 = AllocateContext()
    //     0xc302e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc302ec: mov             x4, x0
    // 0xc302f0: ldr             x3, [fp, #0x20]
    // 0xc302f4: stur            x4, [fp, #-8]
    // 0xc302f8: StoreField: r4->field_f = r3
    //     0xc302f8: stur            w3, [x4, #0xf]
    // 0xc302fc: ldr             x0, [fp, #0x18]
    // 0xc30300: StoreField: r4->field_13 = r0
    //     0xc30300: stur            w0, [x4, #0x13]
    // 0xc30304: r2 = Null
    //     0xc30304: mov             x2, NULL
    // 0xc30308: r1 = Null
    //     0xc30308: mov             x1, NULL
    // 0xc3030c: r4 = 59
    //     0xc3030c: mov             x4, #0x3b
    // 0xc30310: branchIfSmi(r0, 0xc3031c)
    //     0xc30310: tbz             w0, #0, #0xc3031c
    // 0xc30314: r4 = LoadClassIdInstr(r0)
    //     0xc30314: ldur            x4, [x0, #-1]
    //     0xc30318: ubfx            x4, x4, #0xc, #0x14
    // 0xc3031c: r17 = 4467
    //     0xc3031c: mov             x17, #0x1173
    // 0xc30320: cmp             x4, x17
    // 0xc30324: b.eq            #0xc3033c
    // 0xc30328: r8 = NetworkImage<NetworkImage>
    //     0xc30328: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3f5c0] Type: NetworkImage<NetworkImage>
    //     0xc3032c: ldr             x8, [x8, #0x5c0]
    // 0xc30330: r3 = Null
    //     0xc30330: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f5c8] Null
    //     0xc30334: ldr             x3, [x3, #0x5c8]
    // 0xc30338: r0 = DefaultTypeTest()
    //     0xc30338: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xc3033c: r16 = <ImageChunkEvent>
    //     0xc3033c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2ca30] TypeArguments: <ImageChunkEvent>
    //     0xc30340: ldr             x16, [x16, #0xa30]
    // 0xc30344: SaveReg r16
    //     0xc30344: str             x16, [SP, #-8]!
    // 0xc30348: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc30348: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc3034c: r0 = StreamController()
    //     0xc3034c: bl              #0x534f54  ; [dart:async] StreamController::StreamController
    // 0xc30350: add             SP, SP, #8
    // 0xc30354: ldur            x2, [fp, #-8]
    // 0xc30358: stur            x0, [fp, #-0x10]
    // 0xc3035c: LoadField: r1 = r2->field_13
    //     0xc3035c: ldur            w1, [x2, #0x13]
    // 0xc30360: DecompressPointer r1
    //     0xc30360: add             x1, x1, HEAP, lsl #32
    // 0xc30364: ldr             x16, [fp, #0x20]
    // 0xc30368: stp             x1, x16, [SP, #-0x10]!
    // 0xc3036c: ldr             x16, [fp, #0x10]
    // 0xc30370: stp             x16, x0, [SP, #-0x10]!
    // 0xc30374: r0 = _loadAsync()
    //     0xc30374: bl              #0xc3083c  ; [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_loadAsync
    // 0xc30378: add             SP, SP, #0x20
    // 0xc3037c: mov             x2, x0
    // 0xc30380: ldur            x0, [fp, #-0x10]
    // 0xc30384: stur            x2, [fp, #-0x18]
    // 0xc30388: LoadField: r1 = r0->field_7
    //     0xc30388: ldur            w1, [x0, #7]
    // 0xc3038c: DecompressPointer r1
    //     0xc3038c: add             x1, x1, HEAP, lsl #32
    // 0xc30390: r0 = _ControllerStream()
    //     0xc30390: bl              #0x534e34  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x14)
    // 0xc30394: mov             x3, x0
    // 0xc30398: ldur            x0, [fp, #-0x10]
    // 0xc3039c: stur            x3, [fp, #-0x20]
    // 0xc303a0: StoreField: r3->field_f = r0
    //     0xc303a0: stur            w0, [x3, #0xf]
    // 0xc303a4: ldur            x2, [fp, #-8]
    // 0xc303a8: LoadField: r0 = r2->field_13
    //     0xc303a8: ldur            w0, [x2, #0x13]
    // 0xc303ac: DecompressPointer r0
    //     0xc303ac: add             x0, x0, HEAP, lsl #32
    // 0xc303b0: LoadField: r4 = r0->field_b
    //     0xc303b0: ldur            w4, [x0, #0xb]
    // 0xc303b4: DecompressPointer r4
    //     0xc303b4: add             x4, x4, HEAP, lsl #32
    // 0xc303b8: stur            x4, [fp, #-0x10]
    // 0xc303bc: r1 = Function '<anonymous closure>':.
    //     0xc303bc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f5d8] AnonymousClosure: (0xc3199c), in [package:flutter/src/painting/_network_image_io.dart] NetworkImage::loadBuffer (0xc302cc)
    //     0xc303c0: ldr             x1, [x1, #0x5d8]
    // 0xc303c4: r0 = AllocateClosure()
    //     0xc303c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc303c8: stur            x0, [fp, #-8]
    // 0xc303cc: r0 = MultiFrameImageStreamCompleter()
    //     0xc303cc: bl              #0xc30830  ; AllocateMultiFrameImageStreamCompleterStub -> MultiFrameImageStreamCompleter (size=0x60)
    // 0xc303d0: stur            x0, [fp, #-0x28]
    // 0xc303d4: ldur            x16, [fp, #-0x18]
    // 0xc303d8: stp             x16, x0, [SP, #-0x10]!
    // 0xc303dc: d0 = 1.000000
    //     0xc303dc: fmov            d0, #1.00000000
    // 0xc303e0: SaveReg d0
    //     0xc303e0: str             d0, [SP, #-8]!
    // 0xc303e4: ldur            x16, [fp, #-0x20]
    // 0xc303e8: ldur            lr, [fp, #-0x10]
    // 0xc303ec: stp             lr, x16, [SP, #-0x10]!
    // 0xc303f0: ldur            x16, [fp, #-8]
    // 0xc303f4: SaveReg r16
    //     0xc303f4: str             x16, [SP, #-8]!
    // 0xc303f8: r4 = const [0, 0x6, 0x6, 0x3, chunkEvents, 0x3, debugLabel, 0x4, informationCollector, 0x5, null]
    //     0xc303f8: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f5e0] List(11) [0, 0x6, 0x6, 0x3, "chunkEvents", 0x3, "debugLabel", 0x4, "informationCollector", 0x5, Null]
    //     0xc303fc: ldr             x4, [x4, #0x5e0]
    // 0xc30400: r0 = MultiFrameImageStreamCompleter()
    //     0xc30400: bl              #0xc30420  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter
    // 0xc30404: add             SP, SP, #0x30
    // 0xc30408: ldur            x0, [fp, #-0x28]
    // 0xc3040c: LeaveFrame
    //     0xc3040c: mov             SP, fp
    //     0xc30410: ldp             fp, lr, [SP], #0x10
    // 0xc30414: ret
    //     0xc30414: ret             
    // 0xc30418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc30418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3041c: b               #0xc302e4
  }
  _ _loadAsync(/* No info */) async {
    // ** addr: 0xc3083c, size: 0x3a4
    // 0xc3083c: EnterFrame
    //     0xc3083c: stp             fp, lr, [SP, #-0x10]!
    //     0xc30840: mov             fp, SP
    // 0xc30844: AllocStack(0xc8)
    //     0xc30844: sub             SP, SP, #0xc8
    // 0xc30848: SetupParameters(NetworkImage<NetworkImage> this /* r1, fp-0xb8 */, dynamic _ /* r2, fp-0xb0 */, dynamic _ /* r3, fp-0xa8 */, dynamic _ /* r4, fp-0xa0 */)
    //     0xc30848: stur            NULL, [fp, #-8]
    //     0xc3084c: mov             x0, #0
    //     0xc30850: add             x1, fp, w0, sxtw #2
    //     0xc30854: ldr             x1, [x1, #0x28]
    //     0xc30858: stur            x1, [fp, #-0xb8]
    //     0xc3085c: add             x2, fp, w0, sxtw #2
    //     0xc30860: ldr             x2, [x2, #0x20]
    //     0xc30864: stur            x2, [fp, #-0xb0]
    //     0xc30868: add             x3, fp, w0, sxtw #2
    //     0xc3086c: ldr             x3, [x3, #0x18]
    //     0xc30870: stur            x3, [fp, #-0xa8]
    //     0xc30874: add             x4, fp, w0, sxtw #2
    //     0xc30878: ldr             x4, [x4, #0x10]
    //     0xc3087c: stur            x4, [fp, #-0xa0]
    // 0xc30880: CheckStackOverflow
    //     0xc30880: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc30884: cmp             SP, x16
    //     0xc30888: b.ls            #0xc30bcc
    // 0xc3088c: r1 = 2
    //     0xc3088c: mov             x1, #2
    // 0xc30890: r0 = AllocateContext()
    //     0xc30890: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc30894: mov             x1, x0
    // 0xc30898: ldur            x0, [fp, #-0xb0]
    // 0xc3089c: stur            x1, [fp, #-0xc0]
    // 0xc308a0: StoreField: r1->field_f = r0
    //     0xc308a0: stur            w0, [x1, #0xf]
    // 0xc308a4: ldur            x0, [fp, #-0xa8]
    // 0xc308a8: StoreField: r1->field_13 = r0
    //     0xc308a8: stur            w0, [x1, #0x13]
    // 0xc308ac: InitAsync() -> Future<Codec>
    //     0xc308ac: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c998] TypeArguments: <Codec>
    //     0xc308b0: ldr             x0, [x0, #0x998]
    //     0xc308b4: bl              #0x4b92e4
    // 0xc308b8: ldur            x2, [fp, #-0xc0]
    // 0xc308bc: r0 = InitLateStaticField(0x48) // [dart:core] ::_uriBaseClosure
    //     0xc308bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc308c0: ldr             x0, [x0, #0x90]
    //     0xc308c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc308c8: cmp             w0, w16
    //     0xc308cc: b.ne            #0xc308d8
    //     0xc308d0: ldr             x2, [PP, #0x27f8]  ; [pp+0x27f8] Field <::._uriBaseClosure@0150898>: static late (offset: 0x48)
    //     0xc308d4: bl              #0xd67d44
    // 0xc308d8: mov             x1, x0
    // 0xc308dc: stur            x1, [fp, #-0xa8]
    // 0xc308e0: SaveReg r1
    //     0xc308e0: str             x1, [SP, #-8]!
    // 0xc308e4: mov             x0, x1
    // 0xc308e8: ClosureCall
    //     0xc308e8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc308ec: ldur            x2, [x0, #0x1f]
    //     0xc308f0: blr             x2
    // 0xc308f4: add             SP, SP, #8
    // 0xc308f8: ldur            x2, [fp, #-0xc0]
    // 0xc308fc: LoadField: r1 = r2->field_f
    //     0xc308fc: ldur            w1, [x2, #0xf]
    // 0xc30900: DecompressPointer r1
    //     0xc30900: add             x1, x1, HEAP, lsl #32
    // 0xc30904: LoadField: r3 = r1->field_b
    //     0xc30904: ldur            w3, [x1, #0xb]
    // 0xc30908: DecompressPointer r3
    //     0xc30908: add             x3, x3, HEAP, lsl #32
    // 0xc3090c: r1 = LoadClassIdInstr(r0)
    //     0xc3090c: ldur            x1, [x0, #-1]
    //     0xc30910: ubfx            x1, x1, #0xc, #0x14
    // 0xc30914: stp             x3, x0, [SP, #-0x10]!
    // 0xc30918: mov             x0, x1
    // 0xc3091c: r0 = GDT[cid_x0 + -0xcc2]()
    //     0xc3091c: sub             lr, x0, #0xcc2
    //     0xc30920: ldr             lr, [x21, lr, lsl #3]
    //     0xc30924: blr             lr
    // 0xc30928: add             SP, SP, #0x10
    // 0xc3092c: stur            x0, [fp, #-0xa8]
    // 0xc30930: r0 = InitLateStaticField(0xfbc) // [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_sharedHttpClient
    //     0xc30930: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc30934: ldr             x0, [x0, #0x1f78]
    //     0xc30938: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc3093c: cmp             w0, w16
    //     0xc30940: b.ne            #0xc30950
    //     0xc30944: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3f5e8] Field <NetworkImage._sharedHttpClient@993199871>: static late final (offset: 0xfbc)
    //     0xc30948: ldr             x2, [x2, #0x5e8]
    //     0xc3094c: bl              #0xd67cdc
    // 0xc30950: ldur            x16, [fp, #-0xa8]
    // 0xc30954: stp             x16, x0, [SP, #-0x10]!
    // 0xc30958: r0 = getUrl()
    //     0xc30958: bl              #0xc315f0  ; [dart:_http] _HttpClient::getUrl
    // 0xc3095c: add             SP, SP, #0x10
    // 0xc30960: mov             x1, x0
    // 0xc30964: stur            x1, [fp, #-0xb0]
    // 0xc30968: r0 = Await()
    //     0xc30968: bl              #0x4b8e6c  ; AwaitStub
    // 0xc3096c: SaveReg r0
    //     0xc3096c: str             x0, [SP, #-8]!
    // 0xc30970: r0 = close()
    //     0xc30970: bl              #0xc158b0  ; [dart:_http] _HttpClientRequest::close
    // 0xc30974: add             SP, SP, #8
    // 0xc30978: mov             x1, x0
    // 0xc3097c: stur            x1, [fp, #-0xb0]
    // 0xc30980: r0 = Await()
    //     0xc30980: bl              #0x4b8e6c  ; AwaitStub
    // 0xc30984: stur            x0, [fp, #-0xb8]
    // 0xc30988: LoadField: r1 = r0->field_b
    //     0xc30988: ldur            w1, [x0, #0xb]
    // 0xc3098c: DecompressPointer r1
    //     0xc3098c: add             x1, x1, HEAP, lsl #32
    // 0xc30990: stur            x1, [fp, #-0xb0]
    // 0xc30994: LoadField: r2 = r1->field_1b
    //     0xc30994: ldur            w2, [x1, #0x1b]
    // 0xc30998: DecompressPointer r2
    //     0xc30998: add             x2, x2, HEAP, lsl #32
    // 0xc3099c: cmp             w2, NULL
    // 0xc309a0: b.eq            #0xc30bd4
    // 0xc309a4: r3 = LoadInt32Instr(r2)
    //     0xc309a4: sbfx            x3, x2, #1, #0x1f
    //     0xc309a8: tbz             w2, #0, #0xc309b0
    //     0xc309ac: ldur            x3, [x2, #7]
    // 0xc309b0: cmp             x3, #0xc8
    // 0xc309b4: b.ne            #0xc30a78
    // 0xc309b8: ldur            x2, [fp, #-0xc0]
    // 0xc309bc: r1 = Function '<anonymous closure>':.
    //     0xc309bc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f5f0] AnonymousClosure: (0xc3188c), in [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_loadAsync (0xc3083c)
    //     0xc309c0: ldr             x1, [x1, #0x5f0]
    // 0xc309c4: r0 = AllocateClosure()
    //     0xc309c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc309c8: ldur            x16, [fp, #-0xb8]
    // 0xc309cc: stp             x0, x16, [SP, #-0x10]!
    // 0xc309d0: r0 = consolidateHttpClientResponseBytes()
    //     0xc309d0: bl              #0xc31098  ; [package:flutter/src/foundation/consolidate_response.dart] ::consolidateHttpClientResponseBytes
    // 0xc309d4: add             SP, SP, #0x10
    // 0xc309d8: mov             x1, x0
    // 0xc309dc: stur            x1, [fp, #-0xb0]
    // 0xc309e0: r0 = Await()
    //     0xc309e0: bl              #0x4b8e6c  ; AwaitStub
    // 0xc309e4: mov             x1, x0
    // 0xc309e8: stur            x1, [fp, #-0xb0]
    // 0xc309ec: r0 = LoadClassIdInstr(r1)
    //     0xc309ec: ldur            x0, [x1, #-1]
    //     0xc309f0: ubfx            x0, x0, #0xc, #0x14
    // 0xc309f4: SaveReg r1
    //     0xc309f4: str             x1, [SP, #-8]!
    // 0xc309f8: r0 = GDT[cid_x0 + 0x3b2f]()
    //     0xc309f8: mov             x17, #0x3b2f
    //     0xc309fc: add             lr, x0, x17
    //     0xc30a00: ldr             lr, [x21, lr, lsl #3]
    //     0xc30a04: blr             lr
    // 0xc30a08: add             SP, SP, #8
    // 0xc30a0c: cbz             x0, #0xc30b04
    // 0xc30a10: ldur            x0, [fp, #-0xa0]
    // 0xc30a14: ldur            x16, [fp, #-0xb0]
    // 0xc30a18: SaveReg r16
    //     0xc30a18: str             x16, [SP, #-8]!
    // 0xc30a1c: r0 = fromUint8List()
    //     0xc30a1c: bl              #0xc30c8c  ; [dart:ui] ImmutableBuffer::fromUint8List
    // 0xc30a20: add             SP, SP, #8
    // 0xc30a24: mov             x1, x0
    // 0xc30a28: stur            x1, [fp, #-0xa8]
    // 0xc30a2c: r0 = Await()
    //     0xc30a2c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc30a30: ldur            x1, [fp, #-0xa0]
    // 0xc30a34: cmp             w1, NULL
    // 0xc30a38: b.eq            #0xc30bd8
    // 0xc30a3c: stp             x0, x1, [SP, #-0x10]!
    // 0xc30a40: mov             x0, x1
    // 0xc30a44: ClosureCall
    //     0xc30a44: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc30a48: ldur            x2, [x0, #0x1f]
    //     0xc30a4c: blr             x2
    // 0xc30a50: add             SP, SP, #0x10
    // 0xc30a54: stur            x0, [fp, #-0xa0]
    // 0xc30a58: ldur            x1, [fp, #-0xc0]
    // 0xc30a5c: LoadField: r2 = r1->field_13
    //     0xc30a5c: ldur            w2, [x1, #0x13]
    // 0xc30a60: DecompressPointer r2
    //     0xc30a60: add             x2, x2, HEAP, lsl #32
    // 0xc30a64: SaveReg r2
    //     0xc30a64: str             x2, [SP, #-8]!
    // 0xc30a68: r0 = close()
    //     0xc30a68: bl              #0xc069e8  ; [dart:async] _StreamController::close
    // 0xc30a6c: add             SP, SP, #8
    // 0xc30a70: ldur            x0, [fp, #-0xa0]
    // 0xc30a74: r0 = ReturnAsync()
    //     0xc30a74: b               #0x501858  ; ReturnAsyncStub
    // 0xc30a78: r16 = <int>
    //     0xc30a78: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xc30a7c: stp             xzr, x16, [SP, #-0x10]!
    // 0xc30a80: r0 = _GrowableList()
    //     0xc30a80: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xc30a84: add             SP, SP, #0x10
    // 0xc30a88: r16 = <List<int>>
    //     0xc30a88: ldr             x16, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0xc30a8c: ldur            lr, [fp, #-0xb8]
    // 0xc30a90: stp             lr, x16, [SP, #-0x10]!
    // 0xc30a94: SaveReg r0
    //     0xc30a94: str             x0, [SP, #-8]!
    // 0xc30a98: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc30a98: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc30a9c: r0 = drain()
    //     0xc30a9c: bl              #0x54b150  ; [dart:async] Stream::drain
    // 0xc30aa0: add             SP, SP, #0x18
    // 0xc30aa4: mov             x1, x0
    // 0xc30aa8: stur            x1, [fp, #-0xc8]
    // 0xc30aac: r0 = Await()
    //     0xc30aac: bl              #0x4b8e6c  ; AwaitStub
    // 0xc30ab0: ldur            x0, [fp, #-0xb0]
    // 0xc30ab4: LoadField: r1 = r0->field_1b
    //     0xc30ab4: ldur            w1, [x0, #0x1b]
    // 0xc30ab8: DecompressPointer r1
    //     0xc30ab8: add             x1, x1, HEAP, lsl #32
    // 0xc30abc: stur            x1, [fp, #-0xc8]
    // 0xc30ac0: cmp             w1, NULL
    // 0xc30ac4: b.eq            #0xc30bdc
    // 0xc30ac8: r0 = NetworkImageLoadException()
    //     0xc30ac8: bl              #0xc30c80  ; AllocateNetworkImageLoadExceptionStub -> NetworkImageLoadException (size=0xc)
    // 0xc30acc: mov             x1, x0
    // 0xc30ad0: ldur            x0, [fp, #-0xc8]
    // 0xc30ad4: stur            x1, [fp, #-0xb0]
    // 0xc30ad8: r2 = LoadInt32Instr(r0)
    //     0xc30ad8: sbfx            x2, x0, #1, #0x1f
    //     0xc30adc: tbz             w0, #0, #0xc30ae4
    //     0xc30ae0: ldur            x2, [x0, #7]
    // 0xc30ae4: stp             x2, x1, [SP, #-0x10]!
    // 0xc30ae8: ldur            x16, [fp, #-0xa8]
    // 0xc30aec: SaveReg r16
    //     0xc30aec: str             x16, [SP, #-8]!
    // 0xc30af0: r0 = NetworkImageLoadException()
    //     0xc30af0: bl              #0xc30be0  ; [package:flutter/src/painting/image_provider.dart] NetworkImageLoadException::NetworkImageLoadException
    // 0xc30af4: add             SP, SP, #0x18
    // 0xc30af8: ldur            x0, [fp, #-0xb0]
    // 0xc30afc: r0 = Throw()
    //     0xc30afc: bl              #0xd67e38  ; ThrowStub
    // 0xc30b00: brk             #0
    // 0xc30b04: ldur            x0, [fp, #-0xa8]
    // 0xc30b08: r1 = Null
    //     0xc30b08: mov             x1, NULL
    // 0xc30b0c: r2 = 4
    //     0xc30b0c: mov             x2, #4
    // 0xc30b10: r0 = AllocateArray()
    //     0xc30b10: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc30b14: r17 = "NetworkImage is an empty file: "
    //     0xc30b14: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2caa8] "NetworkImage is an empty file: "
    //     0xc30b18: ldr             x17, [x17, #0xaa8]
    // 0xc30b1c: StoreField: r0->field_f = r17
    //     0xc30b1c: stur            w17, [x0, #0xf]
    // 0xc30b20: ldur            x1, [fp, #-0xa8]
    // 0xc30b24: StoreField: r0->field_13 = r1
    //     0xc30b24: stur            w1, [x0, #0x13]
    // 0xc30b28: SaveReg r0
    //     0xc30b28: str             x0, [SP, #-8]!
    // 0xc30b2c: r0 = _interpolate()
    //     0xc30b2c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc30b30: add             SP, SP, #8
    // 0xc30b34: stur            x0, [fp, #-0xa8]
    // 0xc30b38: r0 = _Exception()
    //     0xc30b38: bl              #0x4eda04  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0xc30b3c: mov             x1, x0
    // 0xc30b40: ldur            x0, [fp, #-0xa8]
    // 0xc30b44: stur            x1, [fp, #-0xb8]
    // 0xc30b48: StoreField: r1->field_7 = r0
    //     0xc30b48: stur            w0, [x1, #7]
    // 0xc30b4c: mov             x0, x1
    // 0xc30b50: r0 = Throw()
    //     0xc30b50: bl              #0xd67e38  ; ThrowStub
    // 0xc30b54: brk             #0
    // 0xc30b58: sub             SP, fp, #0xc8
    // 0xc30b5c: ldur            x2, [fp, #-0x40]
    // 0xc30b60: mov             x3, x0
    // 0xc30b64: stur            x0, [fp, #-0xa0]
    // 0xc30b68: mov             x0, x1
    // 0xc30b6c: stur            x1, [fp, #-0xa8]
    // 0xc30b70: r1 = Function '<anonymous closure>':.
    //     0xc30b70: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f5f8] AnonymousClosure: (0xc31638), in [package:flutter/src/painting/_network_image_io.dart] NetworkImage::_loadAsync (0xc3083c)
    //     0xc30b74: ldr             x1, [x1, #0x5f8]
    // 0xc30b78: r0 = AllocateClosure()
    //     0xc30b78: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc30b7c: SaveReg r0
    //     0xc30b7c: str             x0, [SP, #-8]!
    // 0xc30b80: r0 = scheduleMicrotask()
    //     0xc30b80: bl              #0x4b5c38  ; [dart:async] ::scheduleMicrotask
    // 0xc30b84: add             SP, SP, #8
    // 0xc30b88: ldur            x0, [fp, #-0xa0]
    // 0xc30b8c: ldur            x1, [fp, #-0xa8]
    // 0xc30b90: r0 = ReThrow()
    //     0xc30b90: bl              #0xd67e14  ; ReThrowStub
    // 0xc30b94: brk             #0
    // 0xc30b98: sub             SP, fp, #0xc8
    // 0xc30b9c: ldur            x2, [fp, #-0x38]
    // 0xc30ba0: stur            x0, [fp, #-0xa0]
    // 0xc30ba4: stur            x1, [fp, #-0xa8]
    // 0xc30ba8: LoadField: r3 = r2->field_13
    //     0xc30ba8: ldur            w3, [x2, #0x13]
    // 0xc30bac: DecompressPointer r3
    //     0xc30bac: add             x3, x3, HEAP, lsl #32
    // 0xc30bb0: SaveReg r3
    //     0xc30bb0: str             x3, [SP, #-8]!
    // 0xc30bb4: r0 = close()
    //     0xc30bb4: bl              #0xc069e8  ; [dart:async] _StreamController::close
    // 0xc30bb8: add             SP, SP, #8
    // 0xc30bbc: ldur            x0, [fp, #-0xa0]
    // 0xc30bc0: ldur            x1, [fp, #-0xa8]
    // 0xc30bc4: r0 = ReThrow()
    //     0xc30bc4: bl              #0xd67e14  ; ReThrowStub
    // 0xc30bc8: brk             #0
    // 0xc30bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc30bcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc30bd0: b               #0xc3088c
    // 0xc30bd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc30bd4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc30bd8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc30bd8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xc30bdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc30bdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc31638, size: 0x7c
    // 0xc31638: EnterFrame
    //     0xc31638: stp             fp, lr, [SP, #-0x10]!
    //     0xc3163c: mov             fp, SP
    // 0xc31640: ldr             x0, [fp, #0x10]
    // 0xc31644: LoadField: r1 = r0->field_17
    //     0xc31644: ldur            w1, [x0, #0x17]
    // 0xc31648: DecompressPointer r1
    //     0xc31648: add             x1, x1, HEAP, lsl #32
    // 0xc3164c: CheckStackOverflow
    //     0xc3164c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc31650: cmp             SP, x16
    //     0xc31654: b.ls            #0xc316a0
    // 0xc31658: r0 = LoadStaticField(0xe6c)
    //     0xc31658: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc3165c: ldr             x0, [x0, #0x1cd8]
    // 0xc31660: cmp             w0, NULL
    // 0xc31664: b.eq            #0xc316a8
    // 0xc31668: LoadField: r2 = r0->field_a7
    //     0xc31668: ldur            w2, [x0, #0xa7]
    // 0xc3166c: DecompressPointer r2
    //     0xc3166c: add             x2, x2, HEAP, lsl #32
    // 0xc31670: r16 = Sentinel
    //     0xc31670: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc31674: cmp             w2, w16
    // 0xc31678: b.eq            #0xc316ac
    // 0xc3167c: LoadField: r0 = r1->field_f
    //     0xc3167c: ldur            w0, [x1, #0xf]
    // 0xc31680: DecompressPointer r0
    //     0xc31680: add             x0, x0, HEAP, lsl #32
    // 0xc31684: stp             x0, x2, [SP, #-0x10]!
    // 0xc31688: r0 = evict()
    //     0xc31688: bl              #0xc316b4  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0xc3168c: add             SP, SP, #0x10
    // 0xc31690: r0 = Null
    //     0xc31690: mov             x0, NULL
    // 0xc31694: LeaveFrame
    //     0xc31694: mov             SP, fp
    //     0xc31698: ldp             fp, lr, [SP], #0x10
    // 0xc3169c: ret
    //     0xc3169c: ret             
    // 0xc316a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc316a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc316a4: b               #0xc31658
    // 0xc316a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc316a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc316ac: r9 = _imageCache
    //     0xc316ac: ldr             x9, [PP, #0x4f50]  ; [pp+0x4f50] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@423399801._imageCache@846047248>: late (offset: 0xa8)
    // 0xc316b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc316b0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, int, int?) {
    // ** addr: 0xc3188c, size: 0x5c
    // 0xc3188c: EnterFrame
    //     0xc3188c: stp             fp, lr, [SP, #-0x10]!
    //     0xc31890: mov             fp, SP
    // 0xc31894: AllocStack(0x8)
    //     0xc31894: sub             SP, SP, #8
    // 0xc31898: SetupParameters()
    //     0xc31898: ldr             x0, [fp, #0x20]
    //     0xc3189c: ldur            w1, [x0, #0x17]
    //     0xc318a0: add             x1, x1, HEAP, lsl #32
    // 0xc318a4: CheckStackOverflow
    //     0xc318a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc318a8: cmp             SP, x16
    //     0xc318ac: b.ls            #0xc318e0
    // 0xc318b0: LoadField: r0 = r1->field_13
    //     0xc318b0: ldur            w0, [x1, #0x13]
    // 0xc318b4: DecompressPointer r0
    //     0xc318b4: add             x0, x0, HEAP, lsl #32
    // 0xc318b8: stur            x0, [fp, #-8]
    // 0xc318bc: r0 = ImageChunkEvent()
    //     0xc318bc: bl              #0xc318e8  ; AllocateImageChunkEventStub -> ImageChunkEvent (size=0x8)
    // 0xc318c0: ldur            x16, [fp, #-8]
    // 0xc318c4: stp             x0, x16, [SP, #-0x10]!
    // 0xc318c8: r0 = add()
    //     0xc318c8: bl              #0xc23290  ; [dart:async] _StreamController::add
    // 0xc318cc: add             SP, SP, #0x10
    // 0xc318d0: r0 = Null
    //     0xc318d0: mov             x0, NULL
    // 0xc318d4: LeaveFrame
    //     0xc318d4: mov             SP, fp
    //     0xc318d8: ldp             fp, lr, [SP], #0x10
    // 0xc318dc: ret
    //     0xc318dc: ret             
    // 0xc318e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc318e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc318e4: b               #0xc318b0
  }
  static HttpClient _sharedHttpClient() {
    // ** addr: 0xc31914, size: 0x88
    // 0xc31914: EnterFrame
    //     0xc31914: stp             fp, lr, [SP, #-0x10]!
    //     0xc31918: mov             fp, SP
    // 0xc3191c: AllocStack(0x8)
    //     0xc3191c: sub             SP, SP, #8
    // 0xc31920: CheckStackOverflow
    //     0xc31920: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc31924: cmp             SP, x16
    //     0xc31928: b.ls            #0xc31994
    // 0xc3192c: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc3192c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc31930: ldr             x0, [x0, #0xb58]
    //     0xc31934: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc31938: cmp             w0, w16
    //     0xc3193c: b.ne            #0xc31948
    //     0xc31940: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc31944: bl              #0xd67d44
    // 0xc31948: r0 = InitLateStaticField(0x620) // [dart:_http] ::_httpOverridesToken
    //     0xc31948: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc3194c: ldr             x0, [x0, #0xc40]
    //     0xc31950: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc31954: cmp             w0, w16
    //     0xc31958: b.ne            #0xc31968
    //     0xc3195c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14418] Field <::._httpOverridesToken@13463476>: static late final (offset: 0x620)
    //     0xc31960: ldr             x2, [x2, #0x418]
    //     0xc31964: bl              #0xd67cdc
    // 0xc31968: r0 = _HttpClient()
    //     0xc31968: bl              #0x5565b8  ; Allocate_HttpClientStub -> _HttpClient (size=0x4c)
    // 0xc3196c: stur            x0, [fp, #-8]
    // 0xc31970: SaveReg r0
    //     0xc31970: str             x0, [SP, #-8]!
    // 0xc31974: r0 = _HttpClient()
    //     0xc31974: bl              #0x554ed4  ; [dart:_http] _HttpClient::_HttpClient
    // 0xc31978: add             SP, SP, #8
    // 0xc3197c: ldur            x0, [fp, #-8]
    // 0xc31980: r1 = false
    //     0xc31980: add             x1, NULL, #0x30  ; false
    // 0xc31984: StoreField: r0->field_43 = r1
    //     0xc31984: stur            w1, [x0, #0x43]
    // 0xc31988: LeaveFrame
    //     0xc31988: mov             SP, fp
    //     0xc3198c: ldp             fp, lr, [SP], #0x10
    // 0xc31990: ret
    //     0xc31990: ret             
    // 0xc31994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc31994: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc31998: b               #0xc3192c
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0xc3199c, size: 0xf8
    // 0xc3199c: EnterFrame
    //     0xc3199c: stp             fp, lr, [SP, #-0x10]!
    //     0xc319a0: mov             fp, SP
    // 0xc319a4: AllocStack(0x18)
    //     0xc319a4: sub             SP, SP, #0x18
    // 0xc319a8: SetupParameters()
    //     0xc319a8: ldr             x0, [fp, #0x10]
    //     0xc319ac: ldur            w2, [x0, #0x17]
    //     0xc319b0: add             x2, x2, HEAP, lsl #32
    //     0xc319b4: stur            x2, [fp, #-0x10]
    // 0xc319b8: LoadField: r0 = r2->field_f
    //     0xc319b8: ldur            w0, [x2, #0xf]
    // 0xc319bc: DecompressPointer r0
    //     0xc319bc: add             x0, x0, HEAP, lsl #32
    // 0xc319c0: stur            x0, [fp, #-8]
    // 0xc319c4: r1 = <ImageProvider<Object>>
    //     0xc319c4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2ca48] TypeArguments: <ImageProvider<Object>>
    //     0xc319c8: ldr             x1, [x1, #0xa48]
    // 0xc319cc: r0 = DiagnosticsProperty()
    //     0xc319cc: bl              #0x4fc570  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x30)
    // 0xc319d0: mov             x2, x0
    // 0xc319d4: r0 = Instance__NoDefaultValue
    //     0xc319d4: ldr             x0, [PP, #0xf40]  ; [pp+0xf40] Obj!_NoDefaultValue@b387f1
    // 0xc319d8: stur            x2, [fp, #-0x18]
    // 0xc319dc: StoreField: r2->field_23 = r0
    //     0xc319dc: stur            w0, [x2, #0x23]
    // 0xc319e0: r3 = false
    //     0xc319e0: add             x3, NULL, #0x30  ; false
    // 0xc319e4: StoreField: r2->field_13 = r3
    //     0xc319e4: stur            w3, [x2, #0x13]
    // 0xc319e8: r4 = true
    //     0xc319e8: add             x4, NULL, #0x20  ; true
    // 0xc319ec: StoreField: r2->field_1b = r4
    //     0xc319ec: stur            w4, [x2, #0x1b]
    // 0xc319f0: ldur            x1, [fp, #-8]
    // 0xc319f4: StoreField: r2->field_17 = r1
    //     0xc319f4: stur            w1, [x2, #0x17]
    // 0xc319f8: r5 = Instance_DiagnosticLevel
    //     0xc319f8: ldr             x5, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xc319fc: StoreField: r2->field_27 = r5
    //     0xc319fc: stur            w5, [x2, #0x27]
    // 0xc31a00: ldur            x1, [fp, #-0x10]
    // 0xc31a04: LoadField: r6 = r1->field_13
    //     0xc31a04: ldur            w6, [x1, #0x13]
    // 0xc31a08: DecompressPointer r6
    //     0xc31a08: add             x6, x6, HEAP, lsl #32
    // 0xc31a0c: stur            x6, [fp, #-8]
    // 0xc31a10: r1 = <NetworkImage>
    //     0xc31a10: add             x1, PP, #0x31, lsl #12  ; [pp+0x31980] TypeArguments: <NetworkImage>
    //     0xc31a14: ldr             x1, [x1, #0x980]
    // 0xc31a18: r0 = DiagnosticsProperty()
    //     0xc31a18: bl              #0x4fc570  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x30)
    // 0xc31a1c: mov             x3, x0
    // 0xc31a20: r0 = Instance__NoDefaultValue
    //     0xc31a20: ldr             x0, [PP, #0xf40]  ; [pp+0xf40] Obj!_NoDefaultValue@b387f1
    // 0xc31a24: stur            x3, [fp, #-0x10]
    // 0xc31a28: StoreField: r3->field_23 = r0
    //     0xc31a28: stur            w0, [x3, #0x23]
    // 0xc31a2c: r0 = false
    //     0xc31a2c: add             x0, NULL, #0x30  ; false
    // 0xc31a30: StoreField: r3->field_13 = r0
    //     0xc31a30: stur            w0, [x3, #0x13]
    // 0xc31a34: r0 = true
    //     0xc31a34: add             x0, NULL, #0x20  ; true
    // 0xc31a38: StoreField: r3->field_1b = r0
    //     0xc31a38: stur            w0, [x3, #0x1b]
    // 0xc31a3c: ldur            x0, [fp, #-8]
    // 0xc31a40: StoreField: r3->field_17 = r0
    //     0xc31a40: stur            w0, [x3, #0x17]
    // 0xc31a44: r0 = Instance_DiagnosticLevel
    //     0xc31a44: ldr             x0, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xc31a48: StoreField: r3->field_27 = r0
    //     0xc31a48: stur            w0, [x3, #0x27]
    // 0xc31a4c: r1 = Null
    //     0xc31a4c: mov             x1, NULL
    // 0xc31a50: r2 = 4
    //     0xc31a50: mov             x2, #4
    // 0xc31a54: r0 = AllocateArray()
    //     0xc31a54: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc31a58: mov             x2, x0
    // 0xc31a5c: ldur            x0, [fp, #-0x18]
    // 0xc31a60: stur            x2, [fp, #-8]
    // 0xc31a64: StoreField: r2->field_f = r0
    //     0xc31a64: stur            w0, [x2, #0xf]
    // 0xc31a68: ldur            x0, [fp, #-0x10]
    // 0xc31a6c: StoreField: r2->field_13 = r0
    //     0xc31a6c: stur            w0, [x2, #0x13]
    // 0xc31a70: r1 = <DiagnosticsNode>
    //     0xc31a70: ldr             x1, [PP, #0x3930]  ; [pp+0x3930] TypeArguments: <DiagnosticsNode>
    // 0xc31a74: r0 = AllocateGrowableArray()
    //     0xc31a74: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xc31a78: ldur            x1, [fp, #-8]
    // 0xc31a7c: StoreField: r0->field_f = r1
    //     0xc31a7c: stur            w1, [x0, #0xf]
    // 0xc31a80: r1 = 4
    //     0xc31a80: mov             x1, #4
    // 0xc31a84: StoreField: r0->field_b = r1
    //     0xc31a84: stur            w1, [x0, #0xb]
    // 0xc31a88: LeaveFrame
    //     0xc31a88: mov             SP, fp
    //     0xc31a8c: ldp             fp, lr, [SP], #0x10
    // 0xc31a90: ret
    //     0xc31a90: ret             
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0xc4b780, size: 0x28
    // 0xc4b780: EnterFrame
    //     0xc4b780: stp             fp, lr, [SP, #-0x10]!
    //     0xc4b784: mov             fp, SP
    // 0xc4b788: r1 = <NetworkImage<NetworkImage>>
    //     0xc4b788: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3f608] TypeArguments: <NetworkImage<NetworkImage>>
    //     0xc4b78c: ldr             x1, [x1, #0x608]
    // 0xc4b790: r0 = SynchronousFuture()
    //     0xc4b790: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xc4b794: ldr             x1, [fp, #0x18]
    // 0xc4b798: StoreField: r0->field_b = r1
    //     0xc4b798: stur            w1, [x0, #0xb]
    // 0xc4b79c: LeaveFrame
    //     0xc4b79c: mov             SP, fp
    //     0xc4b7a0: ldp             fp, lr, [SP], #0x10
    // 0xc4b7a4: ret
    //     0xc4b7a4: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6fa00, size: 0x12c
    // 0xc6fa00: EnterFrame
    //     0xc6fa00: stp             fp, lr, [SP, #-0x10]!
    //     0xc6fa04: mov             fp, SP
    // 0xc6fa08: CheckStackOverflow
    //     0xc6fa08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6fa0c: cmp             SP, x16
    //     0xc6fa10: b.ls            #0xc6fb24
    // 0xc6fa14: ldr             x1, [fp, #0x10]
    // 0xc6fa18: cmp             w1, NULL
    // 0xc6fa1c: b.ne            #0xc6fa30
    // 0xc6fa20: r0 = false
    //     0xc6fa20: add             x0, NULL, #0x30  ; false
    // 0xc6fa24: LeaveFrame
    //     0xc6fa24: mov             SP, fp
    //     0xc6fa28: ldp             fp, lr, [SP], #0x10
    // 0xc6fa2c: ret
    //     0xc6fa2c: ret             
    // 0xc6fa30: r0 = 59
    //     0xc6fa30: mov             x0, #0x3b
    // 0xc6fa34: branchIfSmi(r1, 0xc6fa40)
    //     0xc6fa34: tbz             w1, #0, #0xc6fa40
    // 0xc6fa38: r0 = LoadClassIdInstr(r1)
    //     0xc6fa38: ldur            x0, [x1, #-1]
    //     0xc6fa3c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6fa40: SaveReg r1
    //     0xc6fa40: str             x1, [SP, #-8]!
    // 0xc6fa44: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc6fa44: mov             x17, #0x57c5
    //     0xc6fa48: add             lr, x0, x17
    //     0xc6fa4c: ldr             lr, [x21, lr, lsl #3]
    //     0xc6fa50: blr             lr
    // 0xc6fa54: add             SP, SP, #8
    // 0xc6fa58: r1 = LoadClassIdInstr(r0)
    //     0xc6fa58: ldur            x1, [x0, #-1]
    //     0xc6fa5c: ubfx            x1, x1, #0xc, #0x14
    // 0xc6fa60: r16 = NetworkImage<NetworkImage>
    //     0xc6fa60: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f5b8] Type: NetworkImage<NetworkImage>
    //     0xc6fa64: ldr             x16, [x16, #0x5b8]
    // 0xc6fa68: stp             x16, x0, [SP, #-0x10]!
    // 0xc6fa6c: mov             x0, x1
    // 0xc6fa70: mov             lr, x0
    // 0xc6fa74: ldr             lr, [x21, lr, lsl #3]
    // 0xc6fa78: blr             lr
    // 0xc6fa7c: add             SP, SP, #0x10
    // 0xc6fa80: tbz             w0, #4, #0xc6fa94
    // 0xc6fa84: r0 = false
    //     0xc6fa84: add             x0, NULL, #0x30  ; false
    // 0xc6fa88: LeaveFrame
    //     0xc6fa88: mov             SP, fp
    //     0xc6fa8c: ldp             fp, lr, [SP], #0x10
    // 0xc6fa90: ret
    //     0xc6fa90: ret             
    // 0xc6fa94: ldr             x0, [fp, #0x10]
    // 0xc6fa98: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6fa98: mov             x1, #0x76
    //     0xc6fa9c: tbz             w0, #0, #0xc6faac
    //     0xc6faa0: ldur            x1, [x0, #-1]
    //     0xc6faa4: ubfx            x1, x1, #0xc, #0x14
    //     0xc6faa8: lsl             x1, x1, #1
    // 0xc6faac: r17 = 8934
    //     0xc6faac: mov             x17, #0x22e6
    // 0xc6fab0: cmp             w1, w17
    // 0xc6fab4: b.ne            #0xc6fb14
    // 0xc6fab8: ldr             x1, [fp, #0x18]
    // 0xc6fabc: LoadField: r2 = r0->field_b
    //     0xc6fabc: ldur            w2, [x0, #0xb]
    // 0xc6fac0: DecompressPointer r2
    //     0xc6fac0: add             x2, x2, HEAP, lsl #32
    // 0xc6fac4: LoadField: r0 = r1->field_b
    //     0xc6fac4: ldur            w0, [x1, #0xb]
    // 0xc6fac8: DecompressPointer r0
    //     0xc6fac8: add             x0, x0, HEAP, lsl #32
    // 0xc6facc: r1 = LoadClassIdInstr(r2)
    //     0xc6facc: ldur            x1, [x2, #-1]
    //     0xc6fad0: ubfx            x1, x1, #0xc, #0x14
    // 0xc6fad4: stp             x0, x2, [SP, #-0x10]!
    // 0xc6fad8: mov             x0, x1
    // 0xc6fadc: mov             lr, x0
    // 0xc6fae0: ldr             lr, [x21, lr, lsl #3]
    // 0xc6fae4: blr             lr
    // 0xc6fae8: add             SP, SP, #0x10
    // 0xc6faec: tbnz            w0, #4, #0xc6fb14
    // 0xc6faf0: d0 = 1.000000
    //     0xc6faf0: fmov            d0, #1.00000000
    // 0xc6faf4: fcmp            d0, d0
    // 0xc6faf8: b.vs            #0xc6fb00
    // 0xc6fafc: b.eq            #0xc6fb08
    // 0xc6fb00: r1 = false
    //     0xc6fb00: add             x1, NULL, #0x30  ; false
    // 0xc6fb04: b               #0xc6fb0c
    // 0xc6fb08: r1 = true
    //     0xc6fb08: add             x1, NULL, #0x20  ; true
    // 0xc6fb0c: mov             x0, x1
    // 0xc6fb10: b               #0xc6fb18
    // 0xc6fb14: r0 = false
    //     0xc6fb14: add             x0, NULL, #0x30  ; false
    // 0xc6fb18: LeaveFrame
    //     0xc6fb18: mov             SP, fp
    //     0xc6fb1c: ldp             fp, lr, [SP], #0x10
    // 0xc6fb20: ret
    //     0xc6fb20: ret             
    // 0xc6fb24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6fb24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6fb28: b               #0xc6fa14
  }
}

// lib: , url: package:flutter/src/painting/image_provider.dart

// class id: 1049368, size: 0x8
class :: {
}

// class id: 2085, size: 0xc, field offset: 0x8
class NetworkImageLoadException extends Object
    implements Exception {

  _ NetworkImageLoadException(/* No info */) {
    // ** addr: 0xc30be0, size: 0xa0
    // 0xc30be0: EnterFrame
    //     0xc30be0: stp             fp, lr, [SP, #-0x10]!
    //     0xc30be4: mov             fp, SP
    // 0xc30be8: CheckStackOverflow
    //     0xc30be8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc30bec: cmp             SP, x16
    //     0xc30bf0: b.ls            #0xc30c78
    // 0xc30bf4: r1 = Null
    //     0xc30bf4: mov             x1, NULL
    // 0xc30bf8: r2 = 8
    //     0xc30bf8: mov             x2, #8
    // 0xc30bfc: r0 = AllocateArray()
    //     0xc30bfc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc30c00: mov             x2, x0
    // 0xc30c04: r17 = "HTTP request failed, statusCode: "
    //     0xc30c04: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3f600] "HTTP request failed, statusCode: "
    //     0xc30c08: ldr             x17, [x17, #0x600]
    // 0xc30c0c: StoreField: r2->field_f = r17
    //     0xc30c0c: stur            w17, [x2, #0xf]
    // 0xc30c10: ldr             x3, [fp, #0x18]
    // 0xc30c14: r0 = BoxInt64Instr(r3)
    //     0xc30c14: sbfiz           x0, x3, #1, #0x1f
    //     0xc30c18: cmp             x3, x0, asr #1
    //     0xc30c1c: b.eq            #0xc30c28
    //     0xc30c20: bl              #0xd69bb8
    //     0xc30c24: stur            x3, [x0, #7]
    // 0xc30c28: StoreField: r2->field_13 = r0
    //     0xc30c28: stur            w0, [x2, #0x13]
    // 0xc30c2c: r17 = ", "
    //     0xc30c2c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xc30c30: StoreField: r2->field_17 = r17
    //     0xc30c30: stur            w17, [x2, #0x17]
    // 0xc30c34: ldr             x0, [fp, #0x10]
    // 0xc30c38: StoreField: r2->field_1b = r0
    //     0xc30c38: stur            w0, [x2, #0x1b]
    // 0xc30c3c: SaveReg r2
    //     0xc30c3c: str             x2, [SP, #-8]!
    // 0xc30c40: r0 = _interpolate()
    //     0xc30c40: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc30c44: add             SP, SP, #8
    // 0xc30c48: ldr             x1, [fp, #0x20]
    // 0xc30c4c: StoreField: r1->field_7 = r0
    //     0xc30c4c: stur            w0, [x1, #7]
    //     0xc30c50: ldurb           w16, [x1, #-1]
    //     0xc30c54: ldurb           w17, [x0, #-1]
    //     0xc30c58: and             x16, x17, x16, lsr #2
    //     0xc30c5c: tst             x16, HEAP, lsr #32
    //     0xc30c60: b.eq            #0xc30c68
    //     0xc30c64: bl              #0xd6826c
    // 0xc30c68: r0 = Null
    //     0xc30c68: mov             x0, NULL
    // 0xc30c6c: LeaveFrame
    //     0xc30c6c: mov             SP, fp
    //     0xc30c70: ldp             fp, lr, [SP], #0x10
    // 0xc30c74: ret
    //     0xc30c74: ret             
    // 0xc30c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc30c78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc30c7c: b               #0xc30bf4
  }
}

// class id: 2087, size: 0x18, field offset: 0x8
//   const constructor, 
class AssetBundleImageKey extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xae2d14, size: 0xe0
    // 0xae2d14: EnterFrame
    //     0xae2d14: stp             fp, lr, [SP, #-0x10]!
    //     0xae2d18: mov             fp, SP
    // 0xae2d1c: CheckStackOverflow
    //     0xae2d1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae2d20: cmp             SP, x16
    //     0xae2d24: b.ls            #0xae2dd0
    // 0xae2d28: r1 = Null
    //     0xae2d28: mov             x1, NULL
    // 0xae2d2c: r2 = 16
    //     0xae2d2c: mov             x2, #0x10
    // 0xae2d30: r0 = AllocateArray()
    //     0xae2d30: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2d34: r17 = "AssetBundleImageKey"
    //     0xae2d34: add             x17, PP, #0x38, lsl #12  ; [pp+0x382b8] "AssetBundleImageKey"
    //     0xae2d38: ldr             x17, [x17, #0x2b8]
    // 0xae2d3c: StoreField: r0->field_f = r17
    //     0xae2d3c: stur            w17, [x0, #0xf]
    // 0xae2d40: r17 = "(bundle: "
    //     0xae2d40: add             x17, PP, #0x21, lsl #12  ; [pp+0x21ca8] "(bundle: "
    //     0xae2d44: ldr             x17, [x17, #0xca8]
    // 0xae2d48: StoreField: r0->field_13 = r17
    //     0xae2d48: stur            w17, [x0, #0x13]
    // 0xae2d4c: ldr             x1, [fp, #0x10]
    // 0xae2d50: LoadField: r2 = r1->field_7
    //     0xae2d50: ldur            w2, [x1, #7]
    // 0xae2d54: DecompressPointer r2
    //     0xae2d54: add             x2, x2, HEAP, lsl #32
    // 0xae2d58: StoreField: r0->field_17 = r2
    //     0xae2d58: stur            w2, [x0, #0x17]
    // 0xae2d5c: r17 = ", name: \""
    //     0xae2d5c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21cb0] ", name: \""
    //     0xae2d60: ldr             x17, [x17, #0xcb0]
    // 0xae2d64: StoreField: r0->field_1b = r17
    //     0xae2d64: stur            w17, [x0, #0x1b]
    // 0xae2d68: LoadField: r2 = r1->field_b
    //     0xae2d68: ldur            w2, [x1, #0xb]
    // 0xae2d6c: DecompressPointer r2
    //     0xae2d6c: add             x2, x2, HEAP, lsl #32
    // 0xae2d70: StoreField: r0->field_1f = r2
    //     0xae2d70: stur            w2, [x0, #0x1f]
    // 0xae2d74: r17 = "\", scale: "
    //     0xae2d74: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c940] "\", scale: "
    //     0xae2d78: ldr             x17, [x17, #0x940]
    // 0xae2d7c: StoreField: r0->field_23 = r17
    //     0xae2d7c: stur            w17, [x0, #0x23]
    // 0xae2d80: LoadField: d0 = r1->field_f
    //     0xae2d80: ldur            d0, [x1, #0xf]
    // 0xae2d84: r1 = inline_Allocate_Double()
    //     0xae2d84: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xae2d88: add             x1, x1, #0x10
    //     0xae2d8c: cmp             x2, x1
    //     0xae2d90: b.ls            #0xae2dd8
    //     0xae2d94: str             x1, [THR, #0x60]  ; THR::top
    //     0xae2d98: sub             x1, x1, #0xf
    //     0xae2d9c: mov             x2, #0xd108
    //     0xae2da0: movk            x2, #3, lsl #16
    //     0xae2da4: stur            x2, [x1, #-1]
    // 0xae2da8: StoreField: r1->field_7 = d0
    //     0xae2da8: stur            d0, [x1, #7]
    // 0xae2dac: StoreField: r0->field_27 = r1
    //     0xae2dac: stur            w1, [x0, #0x27]
    // 0xae2db0: r17 = ")"
    //     0xae2db0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae2db4: StoreField: r0->field_2b = r17
    //     0xae2db4: stur            w17, [x0, #0x2b]
    // 0xae2db8: SaveReg r0
    //     0xae2db8: str             x0, [SP, #-8]!
    // 0xae2dbc: r0 = _interpolate()
    //     0xae2dbc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2dc0: add             SP, SP, #8
    // 0xae2dc4: LeaveFrame
    //     0xae2dc4: mov             SP, fp
    //     0xae2dc8: ldp             fp, lr, [SP], #0x10
    // 0xae2dcc: ret
    //     0xae2dcc: ret             
    // 0xae2dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae2dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae2dd4: b               #0xae2d28
    // 0xae2dd8: SaveReg d0
    //     0xae2dd8: str             q0, [SP, #-0x10]!
    // 0xae2ddc: SaveReg r0
    //     0xae2ddc: str             x0, [SP, #-8]!
    // 0xae2de0: r0 = AllocateDouble()
    //     0xae2de0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae2de4: mov             x1, x0
    // 0xae2de8: RestoreReg r0
    //     0xae2de8: ldr             x0, [SP], #8
    // 0xae2dec: RestoreReg d0
    //     0xae2dec: ldr             q0, [SP], #0x10
    // 0xae2df0: b               #0xae2da8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0ea28, size: 0xac
    // 0xb0ea28: EnterFrame
    //     0xb0ea28: stp             fp, lr, [SP, #-0x10]!
    //     0xb0ea2c: mov             fp, SP
    // 0xb0ea30: CheckStackOverflow
    //     0xb0ea30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0ea34: cmp             SP, x16
    //     0xb0ea38: b.ls            #0xb0eab4
    // 0xb0ea3c: ldr             x0, [fp, #0x10]
    // 0xb0ea40: LoadField: r1 = r0->field_7
    //     0xb0ea40: ldur            w1, [x0, #7]
    // 0xb0ea44: DecompressPointer r1
    //     0xb0ea44: add             x1, x1, HEAP, lsl #32
    // 0xb0ea48: LoadField: r2 = r0->field_b
    //     0xb0ea48: ldur            w2, [x0, #0xb]
    // 0xb0ea4c: DecompressPointer r2
    //     0xb0ea4c: add             x2, x2, HEAP, lsl #32
    // 0xb0ea50: LoadField: d0 = r0->field_f
    //     0xb0ea50: ldur            d0, [x0, #0xf]
    // 0xb0ea54: r0 = inline_Allocate_Double()
    //     0xb0ea54: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xb0ea58: add             x0, x0, #0x10
    //     0xb0ea5c: cmp             x3, x0
    //     0xb0ea60: b.ls            #0xb0eabc
    //     0xb0ea64: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0ea68: sub             x0, x0, #0xf
    //     0xb0ea6c: mov             x3, #0xd108
    //     0xb0ea70: movk            x3, #3, lsl #16
    //     0xb0ea74: stur            x3, [x0, #-1]
    // 0xb0ea78: StoreField: r0->field_7 = d0
    //     0xb0ea78: stur            d0, [x0, #7]
    // 0xb0ea7c: stp             x2, x1, [SP, #-0x10]!
    // 0xb0ea80: SaveReg r0
    //     0xb0ea80: str             x0, [SP, #-8]!
    // 0xb0ea84: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xb0ea84: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xb0ea88: r0 = hash()
    //     0xb0ea88: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0ea8c: add             SP, SP, #0x18
    // 0xb0ea90: mov             x2, x0
    // 0xb0ea94: r0 = BoxInt64Instr(r2)
    //     0xb0ea94: sbfiz           x0, x2, #1, #0x1f
    //     0xb0ea98: cmp             x2, x0, asr #1
    //     0xb0ea9c: b.eq            #0xb0eaa8
    //     0xb0eaa0: bl              #0xd69bb8
    //     0xb0eaa4: stur            x2, [x0, #7]
    // 0xb0eaa8: LeaveFrame
    //     0xb0eaa8: mov             SP, fp
    //     0xb0eaac: ldp             fp, lr, [SP], #0x10
    // 0xb0eab0: ret
    //     0xb0eab0: ret             
    // 0xb0eab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0eab4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0eab8: b               #0xb0ea3c
    // 0xb0eabc: SaveReg d0
    //     0xb0eabc: str             q0, [SP, #-0x10]!
    // 0xb0eac0: stp             x1, x2, [SP, #-0x10]!
    // 0xb0eac4: r0 = AllocateDouble()
    //     0xb0eac4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0eac8: ldp             x1, x2, [SP], #0x10
    // 0xb0eacc: RestoreReg d0
    //     0xb0eacc: ldr             q0, [SP], #0x10
    // 0xb0ead0: b               #0xb0ea78
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9dad4, size: 0x150
    // 0xc9dad4: EnterFrame
    //     0xc9dad4: stp             fp, lr, [SP, #-0x10]!
    //     0xc9dad8: mov             fp, SP
    // 0xc9dadc: CheckStackOverflow
    //     0xc9dadc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9dae0: cmp             SP, x16
    //     0xc9dae4: b.ls            #0xc9dc1c
    // 0xc9dae8: ldr             x1, [fp, #0x10]
    // 0xc9daec: cmp             w1, NULL
    // 0xc9daf0: b.ne            #0xc9db04
    // 0xc9daf4: r0 = false
    //     0xc9daf4: add             x0, NULL, #0x30  ; false
    // 0xc9daf8: LeaveFrame
    //     0xc9daf8: mov             SP, fp
    //     0xc9dafc: ldp             fp, lr, [SP], #0x10
    // 0xc9db00: ret
    //     0xc9db00: ret             
    // 0xc9db04: r0 = 59
    //     0xc9db04: mov             x0, #0x3b
    // 0xc9db08: branchIfSmi(r1, 0xc9db14)
    //     0xc9db08: tbz             w1, #0, #0xc9db14
    // 0xc9db0c: r0 = LoadClassIdInstr(r1)
    //     0xc9db0c: ldur            x0, [x1, #-1]
    //     0xc9db10: ubfx            x0, x0, #0xc, #0x14
    // 0xc9db14: SaveReg r1
    //     0xc9db14: str             x1, [SP, #-8]!
    // 0xc9db18: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9db18: mov             x17, #0x57c5
    //     0xc9db1c: add             lr, x0, x17
    //     0xc9db20: ldr             lr, [x21, lr, lsl #3]
    //     0xc9db24: blr             lr
    // 0xc9db28: add             SP, SP, #8
    // 0xc9db2c: r1 = LoadClassIdInstr(r0)
    //     0xc9db2c: ldur            x1, [x0, #-1]
    //     0xc9db30: ubfx            x1, x1, #0xc, #0x14
    // 0xc9db34: r16 = AssetBundleImageKey
    //     0xc9db34: add             x16, PP, #0x38, lsl #12  ; [pp+0x382c0] Type: AssetBundleImageKey
    //     0xc9db38: ldr             x16, [x16, #0x2c0]
    // 0xc9db3c: stp             x16, x0, [SP, #-0x10]!
    // 0xc9db40: mov             x0, x1
    // 0xc9db44: mov             lr, x0
    // 0xc9db48: ldr             lr, [x21, lr, lsl #3]
    // 0xc9db4c: blr             lr
    // 0xc9db50: add             SP, SP, #0x10
    // 0xc9db54: tbz             w0, #4, #0xc9db68
    // 0xc9db58: r0 = false
    //     0xc9db58: add             x0, NULL, #0x30  ; false
    // 0xc9db5c: LeaveFrame
    //     0xc9db5c: mov             SP, fp
    //     0xc9db60: ldp             fp, lr, [SP], #0x10
    // 0xc9db64: ret
    //     0xc9db64: ret             
    // 0xc9db68: ldr             x1, [fp, #0x10]
    // 0xc9db6c: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9db6c: mov             x0, #0x76
    //     0xc9db70: tbz             w1, #0, #0xc9db80
    //     0xc9db74: ldur            x0, [x1, #-1]
    //     0xc9db78: ubfx            x0, x0, #0xc, #0x14
    //     0xc9db7c: lsl             x0, x0, #1
    // 0xc9db80: r17 = 4174
    //     0xc9db80: mov             x17, #0x104e
    // 0xc9db84: cmp             w0, w17
    // 0xc9db88: b.ne            #0xc9dc0c
    // 0xc9db8c: ldr             x2, [fp, #0x18]
    // 0xc9db90: LoadField: r0 = r1->field_7
    //     0xc9db90: ldur            w0, [x1, #7]
    // 0xc9db94: DecompressPointer r0
    //     0xc9db94: add             x0, x0, HEAP, lsl #32
    // 0xc9db98: LoadField: r3 = r2->field_7
    //     0xc9db98: ldur            w3, [x2, #7]
    // 0xc9db9c: DecompressPointer r3
    //     0xc9db9c: add             x3, x3, HEAP, lsl #32
    // 0xc9dba0: cmp             w0, w3
    // 0xc9dba4: b.ne            #0xc9dc0c
    // 0xc9dba8: LoadField: r0 = r1->field_b
    //     0xc9dba8: ldur            w0, [x1, #0xb]
    // 0xc9dbac: DecompressPointer r0
    //     0xc9dbac: add             x0, x0, HEAP, lsl #32
    // 0xc9dbb0: LoadField: r3 = r2->field_b
    //     0xc9dbb0: ldur            w3, [x2, #0xb]
    // 0xc9dbb4: DecompressPointer r3
    //     0xc9dbb4: add             x3, x3, HEAP, lsl #32
    // 0xc9dbb8: r4 = LoadClassIdInstr(r0)
    //     0xc9dbb8: ldur            x4, [x0, #-1]
    //     0xc9dbbc: ubfx            x4, x4, #0xc, #0x14
    // 0xc9dbc0: stp             x3, x0, [SP, #-0x10]!
    // 0xc9dbc4: mov             x0, x4
    // 0xc9dbc8: mov             lr, x0
    // 0xc9dbcc: ldr             lr, [x21, lr, lsl #3]
    // 0xc9dbd0: blr             lr
    // 0xc9dbd4: add             SP, SP, #0x10
    // 0xc9dbd8: tbnz            w0, #4, #0xc9dc0c
    // 0xc9dbdc: ldr             x2, [fp, #0x18]
    // 0xc9dbe0: ldr             x1, [fp, #0x10]
    // 0xc9dbe4: LoadField: d0 = r1->field_f
    //     0xc9dbe4: ldur            d0, [x1, #0xf]
    // 0xc9dbe8: LoadField: d1 = r2->field_f
    //     0xc9dbe8: ldur            d1, [x2, #0xf]
    // 0xc9dbec: fcmp            d0, d1
    // 0xc9dbf0: b.vs            #0xc9dbf8
    // 0xc9dbf4: b.eq            #0xc9dc00
    // 0xc9dbf8: r1 = false
    //     0xc9dbf8: add             x1, NULL, #0x30  ; false
    // 0xc9dbfc: b               #0xc9dc04
    // 0xc9dc00: r1 = true
    //     0xc9dc00: add             x1, NULL, #0x20  ; true
    // 0xc9dc04: mov             x0, x1
    // 0xc9dc08: b               #0xc9dc10
    // 0xc9dc0c: r0 = false
    //     0xc9dc0c: add             x0, NULL, #0x30  ; false
    // 0xc9dc10: LeaveFrame
    //     0xc9dc10: mov             SP, fp
    //     0xc9dc14: ldp             fp, lr, [SP], #0x10
    // 0xc9dc18: ret
    //     0xc9dc18: ret             
    // 0xc9dc1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9dc1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9dc20: b               #0xc9dae8
  }
}

// class id: 2088, size: 0x20, field offset: 0x8
//   const constructor, 
class ImageConfiguration extends Object {

  _ copyWith(/* No info */) {
    // ** addr: 0x665584, size: 0x8c
    // 0x665584: EnterFrame
    //     0x665584: stp             fp, lr, [SP, #-0x10]!
    //     0x665588: mov             fp, SP
    // 0x66558c: AllocStack(0x28)
    //     0x66558c: sub             SP, SP, #0x28
    // 0x665590: ldr             x0, [fp, #0x18]
    // 0x665594: LoadField: r1 = r0->field_7
    //     0x665594: ldur            w1, [x0, #7]
    // 0x665598: DecompressPointer r1
    //     0x665598: add             x1, x1, HEAP, lsl #32
    // 0x66559c: stur            x1, [fp, #-0x28]
    // 0x6655a0: LoadField: r2 = r0->field_b
    //     0x6655a0: ldur            w2, [x0, #0xb]
    // 0x6655a4: DecompressPointer r2
    //     0x6655a4: add             x2, x2, HEAP, lsl #32
    // 0x6655a8: stur            x2, [fp, #-0x20]
    // 0x6655ac: LoadField: r3 = r0->field_f
    //     0x6655ac: ldur            w3, [x0, #0xf]
    // 0x6655b0: DecompressPointer r3
    //     0x6655b0: add             x3, x3, HEAP, lsl #32
    // 0x6655b4: stur            x3, [fp, #-0x18]
    // 0x6655b8: LoadField: r4 = r0->field_13
    //     0x6655b8: ldur            w4, [x0, #0x13]
    // 0x6655bc: DecompressPointer r4
    //     0x6655bc: add             x4, x4, HEAP, lsl #32
    // 0x6655c0: stur            x4, [fp, #-0x10]
    // 0x6655c4: LoadField: r5 = r0->field_1b
    //     0x6655c4: ldur            w5, [x0, #0x1b]
    // 0x6655c8: DecompressPointer r5
    //     0x6655c8: add             x5, x5, HEAP, lsl #32
    // 0x6655cc: stur            x5, [fp, #-8]
    // 0x6655d0: r0 = ImageConfiguration()
    //     0x6655d0: bl              #0x665610  ; AllocateImageConfigurationStub -> ImageConfiguration (size=0x20)
    // 0x6655d4: ldur            x1, [fp, #-0x28]
    // 0x6655d8: StoreField: r0->field_7 = r1
    //     0x6655d8: stur            w1, [x0, #7]
    // 0x6655dc: ldur            x1, [fp, #-0x20]
    // 0x6655e0: StoreField: r0->field_b = r1
    //     0x6655e0: stur            w1, [x0, #0xb]
    // 0x6655e4: ldur            x1, [fp, #-0x18]
    // 0x6655e8: StoreField: r0->field_f = r1
    //     0x6655e8: stur            w1, [x0, #0xf]
    // 0x6655ec: ldur            x1, [fp, #-0x10]
    // 0x6655f0: StoreField: r0->field_13 = r1
    //     0x6655f0: stur            w1, [x0, #0x13]
    // 0x6655f4: ldr             x1, [fp, #0x10]
    // 0x6655f8: StoreField: r0->field_17 = r1
    //     0x6655f8: stur            w1, [x0, #0x17]
    // 0x6655fc: ldur            x1, [fp, #-8]
    // 0x665600: StoreField: r0->field_1b = r1
    //     0x665600: stur            w1, [x0, #0x1b]
    // 0x665604: LeaveFrame
    //     0x665604: mov             SP, fp
    //     0x665608: ldp             fp, lr, [SP], #0x10
    // 0x66560c: ret
    //     0x66560c: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xae29b0, size: 0x364
    // 0xae29b0: EnterFrame
    //     0xae29b0: stp             fp, lr, [SP, #-0x10]!
    //     0xae29b4: mov             fp, SP
    // 0xae29b8: AllocStack(0x18)
    //     0xae29b8: sub             SP, SP, #0x18
    // 0xae29bc: CheckStackOverflow
    //     0xae29bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae29c0: cmp             SP, x16
    //     0xae29c4: b.ls            #0xae2d0c
    // 0xae29c8: r0 = StringBuffer()
    //     0xae29c8: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xae29cc: stur            x0, [fp, #-8]
    // 0xae29d0: SaveReg r0
    //     0xae29d0: str             x0, [SP, #-8]!
    // 0xae29d4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xae29d4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xae29d8: r0 = StringBuffer()
    //     0xae29d8: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0xae29dc: add             SP, SP, #8
    // 0xae29e0: ldur            x16, [fp, #-8]
    // 0xae29e4: r30 = "ImageConfiguration("
    //     0xae29e4: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d508] "ImageConfiguration("
    //     0xae29e8: ldr             lr, [lr, #0x508]
    // 0xae29ec: stp             lr, x16, [SP, #-0x10]!
    // 0xae29f0: r0 = write()
    //     0xae29f0: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae29f4: add             SP, SP, #0x10
    // 0xae29f8: ldr             x0, [fp, #0x10]
    // 0xae29fc: LoadField: r3 = r0->field_7
    //     0xae29fc: ldur            w3, [x0, #7]
    // 0xae2a00: DecompressPointer r3
    //     0xae2a00: add             x3, x3, HEAP, lsl #32
    // 0xae2a04: stur            x3, [fp, #-0x10]
    // 0xae2a08: cmp             w3, NULL
    // 0xae2a0c: b.eq            #0xae2a54
    // 0xae2a10: r1 = Null
    //     0xae2a10: mov             x1, NULL
    // 0xae2a14: r2 = 4
    //     0xae2a14: mov             x2, #4
    // 0xae2a18: r0 = AllocateArray()
    //     0xae2a18: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2a1c: r17 = "bundle: "
    //     0xae2a1c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d510] "bundle: "
    //     0xae2a20: ldr             x17, [x17, #0x510]
    // 0xae2a24: StoreField: r0->field_f = r17
    //     0xae2a24: stur            w17, [x0, #0xf]
    // 0xae2a28: ldur            x1, [fp, #-0x10]
    // 0xae2a2c: StoreField: r0->field_13 = r1
    //     0xae2a2c: stur            w1, [x0, #0x13]
    // 0xae2a30: SaveReg r0
    //     0xae2a30: str             x0, [SP, #-8]!
    // 0xae2a34: r0 = _interpolate()
    //     0xae2a34: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2a38: add             SP, SP, #8
    // 0xae2a3c: ldur            x16, [fp, #-8]
    // 0xae2a40: stp             x0, x16, [SP, #-0x10]!
    // 0xae2a44: r0 = write()
    //     0xae2a44: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2a48: add             SP, SP, #0x10
    // 0xae2a4c: r1 = true
    //     0xae2a4c: add             x1, NULL, #0x20  ; true
    // 0xae2a50: b               #0xae2a58
    // 0xae2a54: r1 = false
    //     0xae2a54: add             x1, NULL, #0x30  ; false
    // 0xae2a58: ldr             x0, [fp, #0x10]
    // 0xae2a5c: LoadField: r2 = r0->field_b
    //     0xae2a5c: ldur            w2, [x0, #0xb]
    // 0xae2a60: DecompressPointer r2
    //     0xae2a60: add             x2, x2, HEAP, lsl #32
    // 0xae2a64: stur            x2, [fp, #-0x10]
    // 0xae2a68: cmp             w2, NULL
    // 0xae2a6c: b.eq            #0xae2b08
    // 0xae2a70: tbnz            w1, #4, #0xae2a88
    // 0xae2a74: ldur            x16, [fp, #-8]
    // 0xae2a78: r30 = ", "
    //     0xae2a78: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae2a7c: stp             lr, x16, [SP, #-0x10]!
    // 0xae2a80: r0 = write()
    //     0xae2a80: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2a84: add             SP, SP, #0x10
    // 0xae2a88: r1 = Null
    //     0xae2a88: mov             x1, NULL
    // 0xae2a8c: r2 = 4
    //     0xae2a8c: mov             x2, #4
    // 0xae2a90: r0 = AllocateArray()
    //     0xae2a90: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2a94: stur            x0, [fp, #-0x18]
    // 0xae2a98: r17 = "devicePixelRatio: "
    //     0xae2a98: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d518] "devicePixelRatio: "
    //     0xae2a9c: ldr             x17, [x17, #0x518]
    // 0xae2aa0: StoreField: r0->field_f = r17
    //     0xae2aa0: stur            w17, [x0, #0xf]
    // 0xae2aa4: ldur            x16, [fp, #-0x10]
    // 0xae2aa8: SaveReg r16
    //     0xae2aa8: str             x16, [SP, #-8]!
    // 0xae2aac: r1 = 1
    //     0xae2aac: mov             x1, #1
    // 0xae2ab0: SaveReg r1
    //     0xae2ab0: str             x1, [SP, #-8]!
    // 0xae2ab4: r0 = toStringAsFixed()
    //     0xae2ab4: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae2ab8: add             SP, SP, #0x10
    // 0xae2abc: ldur            x1, [fp, #-0x18]
    // 0xae2ac0: ArrayStore: r1[1] = r0  ; List_4
    //     0xae2ac0: add             x25, x1, #0x13
    //     0xae2ac4: str             w0, [x25]
    //     0xae2ac8: tbz             w0, #0, #0xae2ae4
    //     0xae2acc: ldurb           w16, [x1, #-1]
    //     0xae2ad0: ldurb           w17, [x0, #-1]
    //     0xae2ad4: and             x16, x17, x16, lsr #2
    //     0xae2ad8: tst             x16, HEAP, lsr #32
    //     0xae2adc: b.eq            #0xae2ae4
    //     0xae2ae0: bl              #0xd67e5c
    // 0xae2ae4: ldur            x16, [fp, #-0x18]
    // 0xae2ae8: SaveReg r16
    //     0xae2ae8: str             x16, [SP, #-8]!
    // 0xae2aec: r0 = _interpolate()
    //     0xae2aec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2af0: add             SP, SP, #8
    // 0xae2af4: ldur            x16, [fp, #-8]
    // 0xae2af8: stp             x0, x16, [SP, #-0x10]!
    // 0xae2afc: r0 = write()
    //     0xae2afc: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2b00: add             SP, SP, #0x10
    // 0xae2b04: r1 = true
    //     0xae2b04: add             x1, NULL, #0x20  ; true
    // 0xae2b08: ldr             x0, [fp, #0x10]
    // 0xae2b0c: LoadField: r2 = r0->field_f
    //     0xae2b0c: ldur            w2, [x0, #0xf]
    // 0xae2b10: DecompressPointer r2
    //     0xae2b10: add             x2, x2, HEAP, lsl #32
    // 0xae2b14: stur            x2, [fp, #-0x10]
    // 0xae2b18: cmp             w2, NULL
    // 0xae2b1c: b.eq            #0xae2b7c
    // 0xae2b20: tbnz            w1, #4, #0xae2b38
    // 0xae2b24: ldur            x16, [fp, #-8]
    // 0xae2b28: r30 = ", "
    //     0xae2b28: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae2b2c: stp             lr, x16, [SP, #-0x10]!
    // 0xae2b30: r0 = write()
    //     0xae2b30: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2b34: add             SP, SP, #0x10
    // 0xae2b38: ldur            x0, [fp, #-0x10]
    // 0xae2b3c: r1 = Null
    //     0xae2b3c: mov             x1, NULL
    // 0xae2b40: r2 = 4
    //     0xae2b40: mov             x2, #4
    // 0xae2b44: r0 = AllocateArray()
    //     0xae2b44: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2b48: r17 = "locale: "
    //     0xae2b48: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d520] "locale: "
    //     0xae2b4c: ldr             x17, [x17, #0x520]
    // 0xae2b50: StoreField: r0->field_f = r17
    //     0xae2b50: stur            w17, [x0, #0xf]
    // 0xae2b54: ldur            x1, [fp, #-0x10]
    // 0xae2b58: StoreField: r0->field_13 = r1
    //     0xae2b58: stur            w1, [x0, #0x13]
    // 0xae2b5c: SaveReg r0
    //     0xae2b5c: str             x0, [SP, #-8]!
    // 0xae2b60: r0 = _interpolate()
    //     0xae2b60: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2b64: add             SP, SP, #8
    // 0xae2b68: ldur            x16, [fp, #-8]
    // 0xae2b6c: stp             x0, x16, [SP, #-0x10]!
    // 0xae2b70: r0 = write()
    //     0xae2b70: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2b74: add             SP, SP, #0x10
    // 0xae2b78: r1 = true
    //     0xae2b78: add             x1, NULL, #0x20  ; true
    // 0xae2b7c: ldr             x0, [fp, #0x10]
    // 0xae2b80: LoadField: r2 = r0->field_13
    //     0xae2b80: ldur            w2, [x0, #0x13]
    // 0xae2b84: DecompressPointer r2
    //     0xae2b84: add             x2, x2, HEAP, lsl #32
    // 0xae2b88: stur            x2, [fp, #-0x10]
    // 0xae2b8c: cmp             w2, NULL
    // 0xae2b90: b.eq            #0xae2bf0
    // 0xae2b94: tbnz            w1, #4, #0xae2bac
    // 0xae2b98: ldur            x16, [fp, #-8]
    // 0xae2b9c: r30 = ", "
    //     0xae2b9c: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae2ba0: stp             lr, x16, [SP, #-0x10]!
    // 0xae2ba4: r0 = write()
    //     0xae2ba4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2ba8: add             SP, SP, #0x10
    // 0xae2bac: ldur            x0, [fp, #-0x10]
    // 0xae2bb0: r1 = Null
    //     0xae2bb0: mov             x1, NULL
    // 0xae2bb4: r2 = 4
    //     0xae2bb4: mov             x2, #4
    // 0xae2bb8: r0 = AllocateArray()
    //     0xae2bb8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2bbc: r17 = "textDirection: "
    //     0xae2bbc: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d528] "textDirection: "
    //     0xae2bc0: ldr             x17, [x17, #0x528]
    // 0xae2bc4: StoreField: r0->field_f = r17
    //     0xae2bc4: stur            w17, [x0, #0xf]
    // 0xae2bc8: ldur            x1, [fp, #-0x10]
    // 0xae2bcc: StoreField: r0->field_13 = r1
    //     0xae2bcc: stur            w1, [x0, #0x13]
    // 0xae2bd0: SaveReg r0
    //     0xae2bd0: str             x0, [SP, #-8]!
    // 0xae2bd4: r0 = _interpolate()
    //     0xae2bd4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2bd8: add             SP, SP, #8
    // 0xae2bdc: ldur            x16, [fp, #-8]
    // 0xae2be0: stp             x0, x16, [SP, #-0x10]!
    // 0xae2be4: r0 = write()
    //     0xae2be4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2be8: add             SP, SP, #0x10
    // 0xae2bec: r1 = true
    //     0xae2bec: add             x1, NULL, #0x20  ; true
    // 0xae2bf0: ldr             x0, [fp, #0x10]
    // 0xae2bf4: LoadField: r2 = r0->field_17
    //     0xae2bf4: ldur            w2, [x0, #0x17]
    // 0xae2bf8: DecompressPointer r2
    //     0xae2bf8: add             x2, x2, HEAP, lsl #32
    // 0xae2bfc: stur            x2, [fp, #-0x10]
    // 0xae2c00: cmp             w2, NULL
    // 0xae2c04: b.eq            #0xae2c64
    // 0xae2c08: tbnz            w1, #4, #0xae2c20
    // 0xae2c0c: ldur            x16, [fp, #-8]
    // 0xae2c10: r30 = ", "
    //     0xae2c10: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae2c14: stp             lr, x16, [SP, #-0x10]!
    // 0xae2c18: r0 = write()
    //     0xae2c18: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2c1c: add             SP, SP, #0x10
    // 0xae2c20: ldur            x0, [fp, #-0x10]
    // 0xae2c24: r1 = Null
    //     0xae2c24: mov             x1, NULL
    // 0xae2c28: r2 = 4
    //     0xae2c28: mov             x2, #4
    // 0xae2c2c: r0 = AllocateArray()
    //     0xae2c2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2c30: r17 = "size: "
    //     0xae2c30: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d530] "size: "
    //     0xae2c34: ldr             x17, [x17, #0x530]
    // 0xae2c38: StoreField: r0->field_f = r17
    //     0xae2c38: stur            w17, [x0, #0xf]
    // 0xae2c3c: ldur            x1, [fp, #-0x10]
    // 0xae2c40: StoreField: r0->field_13 = r1
    //     0xae2c40: stur            w1, [x0, #0x13]
    // 0xae2c44: SaveReg r0
    //     0xae2c44: str             x0, [SP, #-8]!
    // 0xae2c48: r0 = _interpolate()
    //     0xae2c48: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2c4c: add             SP, SP, #8
    // 0xae2c50: ldur            x16, [fp, #-8]
    // 0xae2c54: stp             x0, x16, [SP, #-0x10]!
    // 0xae2c58: r0 = write()
    //     0xae2c58: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2c5c: add             SP, SP, #0x10
    // 0xae2c60: r1 = true
    //     0xae2c60: add             x1, NULL, #0x20  ; true
    // 0xae2c64: ldr             x0, [fp, #0x10]
    // 0xae2c68: LoadField: r2 = r0->field_1b
    //     0xae2c68: ldur            w2, [x0, #0x1b]
    // 0xae2c6c: DecompressPointer r2
    //     0xae2c6c: add             x2, x2, HEAP, lsl #32
    // 0xae2c70: stur            x2, [fp, #-0x10]
    // 0xae2c74: cmp             w2, NULL
    // 0xae2c78: b.eq            #0xae2cdc
    // 0xae2c7c: tbnz            w1, #4, #0xae2c94
    // 0xae2c80: ldur            x16, [fp, #-8]
    // 0xae2c84: r30 = ", "
    //     0xae2c84: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xae2c88: stp             lr, x16, [SP, #-0x10]!
    // 0xae2c8c: r0 = write()
    //     0xae2c8c: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2c90: add             SP, SP, #0x10
    // 0xae2c94: ldur            x0, [fp, #-0x10]
    // 0xae2c98: r1 = Null
    //     0xae2c98: mov             x1, NULL
    // 0xae2c9c: r2 = 4
    //     0xae2c9c: mov             x2, #4
    // 0xae2ca0: r0 = AllocateArray()
    //     0xae2ca0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae2ca4: r17 = "platform: "
    //     0xae2ca4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d538] "platform: "
    //     0xae2ca8: ldr             x17, [x17, #0x538]
    // 0xae2cac: StoreField: r0->field_f = r17
    //     0xae2cac: stur            w17, [x0, #0xf]
    // 0xae2cb0: ldur            x1, [fp, #-0x10]
    // 0xae2cb4: LoadField: r2 = r1->field_f
    //     0xae2cb4: ldur            w2, [x1, #0xf]
    // 0xae2cb8: DecompressPointer r2
    //     0xae2cb8: add             x2, x2, HEAP, lsl #32
    // 0xae2cbc: StoreField: r0->field_13 = r2
    //     0xae2cbc: stur            w2, [x0, #0x13]
    // 0xae2cc0: SaveReg r0
    //     0xae2cc0: str             x0, [SP, #-8]!
    // 0xae2cc4: r0 = _interpolate()
    //     0xae2cc4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae2cc8: add             SP, SP, #8
    // 0xae2ccc: ldur            x16, [fp, #-8]
    // 0xae2cd0: stp             x0, x16, [SP, #-0x10]!
    // 0xae2cd4: r0 = write()
    //     0xae2cd4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2cd8: add             SP, SP, #0x10
    // 0xae2cdc: ldur            x16, [fp, #-8]
    // 0xae2ce0: r30 = ")"
    //     0xae2ce0: ldr             lr, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae2ce4: stp             lr, x16, [SP, #-0x10]!
    // 0xae2ce8: r0 = write()
    //     0xae2ce8: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xae2cec: add             SP, SP, #0x10
    // 0xae2cf0: ldur            x16, [fp, #-8]
    // 0xae2cf4: SaveReg r16
    //     0xae2cf4: str             x16, [SP, #-8]!
    // 0xae2cf8: r0 = toString()
    //     0xae2cf8: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0xae2cfc: add             SP, SP, #8
    // 0xae2d00: LeaveFrame
    //     0xae2d00: mov             SP, fp
    //     0xae2d04: ldp             fp, lr, [SP], #0x10
    // 0xae2d08: ret
    //     0xae2d08: ret             
    // 0xae2d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae2d0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae2d10: b               #0xae29c8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0e9a4, size: 0x84
    // 0xb0e9a4: EnterFrame
    //     0xb0e9a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb0e9a8: mov             fp, SP
    // 0xb0e9ac: CheckStackOverflow
    //     0xb0e9ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0e9b0: cmp             SP, x16
    //     0xb0e9b4: b.ls            #0xb0ea20
    // 0xb0e9b8: ldr             x0, [fp, #0x10]
    // 0xb0e9bc: LoadField: r1 = r0->field_7
    //     0xb0e9bc: ldur            w1, [x0, #7]
    // 0xb0e9c0: DecompressPointer r1
    //     0xb0e9c0: add             x1, x1, HEAP, lsl #32
    // 0xb0e9c4: LoadField: r2 = r0->field_b
    //     0xb0e9c4: ldur            w2, [x0, #0xb]
    // 0xb0e9c8: DecompressPointer r2
    //     0xb0e9c8: add             x2, x2, HEAP, lsl #32
    // 0xb0e9cc: LoadField: r3 = r0->field_f
    //     0xb0e9cc: ldur            w3, [x0, #0xf]
    // 0xb0e9d0: DecompressPointer r3
    //     0xb0e9d0: add             x3, x3, HEAP, lsl #32
    // 0xb0e9d4: LoadField: r4 = r0->field_17
    //     0xb0e9d4: ldur            w4, [x0, #0x17]
    // 0xb0e9d8: DecompressPointer r4
    //     0xb0e9d8: add             x4, x4, HEAP, lsl #32
    // 0xb0e9dc: LoadField: r5 = r0->field_1b
    //     0xb0e9dc: ldur            w5, [x0, #0x1b]
    // 0xb0e9e0: DecompressPointer r5
    //     0xb0e9e0: add             x5, x5, HEAP, lsl #32
    // 0xb0e9e4: stp             x2, x1, [SP, #-0x10]!
    // 0xb0e9e8: stp             x4, x3, [SP, #-0x10]!
    // 0xb0e9ec: SaveReg r5
    //     0xb0e9ec: str             x5, [SP, #-8]!
    // 0xb0e9f0: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xb0e9f0: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xb0e9f4: r0 = hash()
    //     0xb0e9f4: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0e9f8: add             SP, SP, #0x28
    // 0xb0e9fc: mov             x2, x0
    // 0xb0ea00: r0 = BoxInt64Instr(r2)
    //     0xb0ea00: sbfiz           x0, x2, #1, #0x1f
    //     0xb0ea04: cmp             x2, x0, asr #1
    //     0xb0ea08: b.eq            #0xb0ea14
    //     0xb0ea0c: bl              #0xd69bb8
    //     0xb0ea10: stur            x2, [x0, #7]
    // 0xb0ea14: LeaveFrame
    //     0xb0ea14: mov             SP, fp
    //     0xb0ea18: ldp             fp, lr, [SP], #0x10
    // 0xb0ea1c: ret
    //     0xb0ea1c: ret             
    // 0xb0ea20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0ea20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0ea24: b               #0xb0e9b8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9d8f4, size: 0x1e0
    // 0xc9d8f4: EnterFrame
    //     0xc9d8f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc9d8f8: mov             fp, SP
    // 0xc9d8fc: CheckStackOverflow
    //     0xc9d8fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9d900: cmp             SP, x16
    //     0xc9d904: b.ls            #0xc9dacc
    // 0xc9d908: ldr             x1, [fp, #0x10]
    // 0xc9d90c: cmp             w1, NULL
    // 0xc9d910: b.ne            #0xc9d924
    // 0xc9d914: r0 = false
    //     0xc9d914: add             x0, NULL, #0x30  ; false
    // 0xc9d918: LeaveFrame
    //     0xc9d918: mov             SP, fp
    //     0xc9d91c: ldp             fp, lr, [SP], #0x10
    // 0xc9d920: ret
    //     0xc9d920: ret             
    // 0xc9d924: r0 = 59
    //     0xc9d924: mov             x0, #0x3b
    // 0xc9d928: branchIfSmi(r1, 0xc9d934)
    //     0xc9d928: tbz             w1, #0, #0xc9d934
    // 0xc9d92c: r0 = LoadClassIdInstr(r1)
    //     0xc9d92c: ldur            x0, [x1, #-1]
    //     0xc9d930: ubfx            x0, x0, #0xc, #0x14
    // 0xc9d934: SaveReg r1
    //     0xc9d934: str             x1, [SP, #-8]!
    // 0xc9d938: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9d938: mov             x17, #0x57c5
    //     0xc9d93c: add             lr, x0, x17
    //     0xc9d940: ldr             lr, [x21, lr, lsl #3]
    //     0xc9d944: blr             lr
    // 0xc9d948: add             SP, SP, #8
    // 0xc9d94c: r1 = LoadClassIdInstr(r0)
    //     0xc9d94c: ldur            x1, [x0, #-1]
    //     0xc9d950: ubfx            x1, x1, #0xc, #0x14
    // 0xc9d954: r16 = ImageConfiguration
    //     0xc9d954: add             x16, PP, #0x14, lsl #12  ; [pp+0x14fb8] Type: ImageConfiguration
    //     0xc9d958: ldr             x16, [x16, #0xfb8]
    // 0xc9d95c: stp             x16, x0, [SP, #-0x10]!
    // 0xc9d960: mov             x0, x1
    // 0xc9d964: mov             lr, x0
    // 0xc9d968: ldr             lr, [x21, lr, lsl #3]
    // 0xc9d96c: blr             lr
    // 0xc9d970: add             SP, SP, #0x10
    // 0xc9d974: tbz             w0, #4, #0xc9d988
    // 0xc9d978: r0 = false
    //     0xc9d978: add             x0, NULL, #0x30  ; false
    // 0xc9d97c: LeaveFrame
    //     0xc9d97c: mov             SP, fp
    //     0xc9d980: ldp             fp, lr, [SP], #0x10
    // 0xc9d984: ret
    //     0xc9d984: ret             
    // 0xc9d988: ldr             x1, [fp, #0x10]
    // 0xc9d98c: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9d98c: mov             x0, #0x76
    //     0xc9d990: tbz             w1, #0, #0xc9d9a0
    //     0xc9d994: ldur            x0, [x1, #-1]
    //     0xc9d998: ubfx            x0, x0, #0xc, #0x14
    //     0xc9d99c: lsl             x0, x0, #1
    // 0xc9d9a0: r17 = 4176
    //     0xc9d9a0: mov             x17, #0x1050
    // 0xc9d9a4: cmp             w0, w17
    // 0xc9d9a8: b.ne            #0xc9dabc
    // 0xc9d9ac: ldr             x2, [fp, #0x18]
    // 0xc9d9b0: LoadField: r0 = r1->field_7
    //     0xc9d9b0: ldur            w0, [x1, #7]
    // 0xc9d9b4: DecompressPointer r0
    //     0xc9d9b4: add             x0, x0, HEAP, lsl #32
    // 0xc9d9b8: LoadField: r3 = r2->field_7
    //     0xc9d9b8: ldur            w3, [x2, #7]
    // 0xc9d9bc: DecompressPointer r3
    //     0xc9d9bc: add             x3, x3, HEAP, lsl #32
    // 0xc9d9c0: cmp             w0, w3
    // 0xc9d9c4: b.ne            #0xc9dabc
    // 0xc9d9c8: LoadField: r0 = r1->field_b
    //     0xc9d9c8: ldur            w0, [x1, #0xb]
    // 0xc9d9cc: DecompressPointer r0
    //     0xc9d9cc: add             x0, x0, HEAP, lsl #32
    // 0xc9d9d0: LoadField: r3 = r2->field_b
    //     0xc9d9d0: ldur            w3, [x2, #0xb]
    // 0xc9d9d4: DecompressPointer r3
    //     0xc9d9d4: add             x3, x3, HEAP, lsl #32
    // 0xc9d9d8: r4 = LoadClassIdInstr(r0)
    //     0xc9d9d8: ldur            x4, [x0, #-1]
    //     0xc9d9dc: ubfx            x4, x4, #0xc, #0x14
    // 0xc9d9e0: stp             x3, x0, [SP, #-0x10]!
    // 0xc9d9e4: mov             x0, x4
    // 0xc9d9e8: mov             lr, x0
    // 0xc9d9ec: ldr             lr, [x21, lr, lsl #3]
    // 0xc9d9f0: blr             lr
    // 0xc9d9f4: add             SP, SP, #0x10
    // 0xc9d9f8: tbnz            w0, #4, #0xc9dabc
    // 0xc9d9fc: ldr             x2, [fp, #0x18]
    // 0xc9da00: ldr             x1, [fp, #0x10]
    // 0xc9da04: LoadField: r0 = r1->field_f
    //     0xc9da04: ldur            w0, [x1, #0xf]
    // 0xc9da08: DecompressPointer r0
    //     0xc9da08: add             x0, x0, HEAP, lsl #32
    // 0xc9da0c: LoadField: r3 = r2->field_f
    //     0xc9da0c: ldur            w3, [x2, #0xf]
    // 0xc9da10: DecompressPointer r3
    //     0xc9da10: add             x3, x3, HEAP, lsl #32
    // 0xc9da14: r4 = LoadClassIdInstr(r0)
    //     0xc9da14: ldur            x4, [x0, #-1]
    //     0xc9da18: ubfx            x4, x4, #0xc, #0x14
    // 0xc9da1c: stp             x3, x0, [SP, #-0x10]!
    // 0xc9da20: mov             x0, x4
    // 0xc9da24: mov             lr, x0
    // 0xc9da28: ldr             lr, [x21, lr, lsl #3]
    // 0xc9da2c: blr             lr
    // 0xc9da30: add             SP, SP, #0x10
    // 0xc9da34: tbnz            w0, #4, #0xc9dabc
    // 0xc9da38: ldr             x2, [fp, #0x18]
    // 0xc9da3c: ldr             x1, [fp, #0x10]
    // 0xc9da40: LoadField: r0 = r1->field_13
    //     0xc9da40: ldur            w0, [x1, #0x13]
    // 0xc9da44: DecompressPointer r0
    //     0xc9da44: add             x0, x0, HEAP, lsl #32
    // 0xc9da48: LoadField: r3 = r2->field_13
    //     0xc9da48: ldur            w3, [x2, #0x13]
    // 0xc9da4c: DecompressPointer r3
    //     0xc9da4c: add             x3, x3, HEAP, lsl #32
    // 0xc9da50: cmp             w0, w3
    // 0xc9da54: b.ne            #0xc9dabc
    // 0xc9da58: LoadField: r0 = r1->field_17
    //     0xc9da58: ldur            w0, [x1, #0x17]
    // 0xc9da5c: DecompressPointer r0
    //     0xc9da5c: add             x0, x0, HEAP, lsl #32
    // 0xc9da60: LoadField: r3 = r2->field_17
    //     0xc9da60: ldur            w3, [x2, #0x17]
    // 0xc9da64: DecompressPointer r3
    //     0xc9da64: add             x3, x3, HEAP, lsl #32
    // 0xc9da68: r4 = LoadClassIdInstr(r0)
    //     0xc9da68: ldur            x4, [x0, #-1]
    //     0xc9da6c: ubfx            x4, x4, #0xc, #0x14
    // 0xc9da70: stp             x3, x0, [SP, #-0x10]!
    // 0xc9da74: mov             x0, x4
    // 0xc9da78: mov             lr, x0
    // 0xc9da7c: ldr             lr, [x21, lr, lsl #3]
    // 0xc9da80: blr             lr
    // 0xc9da84: add             SP, SP, #0x10
    // 0xc9da88: tbnz            w0, #4, #0xc9dabc
    // 0xc9da8c: ldr             x2, [fp, #0x18]
    // 0xc9da90: ldr             x1, [fp, #0x10]
    // 0xc9da94: LoadField: r3 = r1->field_1b
    //     0xc9da94: ldur            w3, [x1, #0x1b]
    // 0xc9da98: DecompressPointer r3
    //     0xc9da98: add             x3, x3, HEAP, lsl #32
    // 0xc9da9c: LoadField: r1 = r2->field_1b
    //     0xc9da9c: ldur            w1, [x2, #0x1b]
    // 0xc9daa0: DecompressPointer r1
    //     0xc9daa0: add             x1, x1, HEAP, lsl #32
    // 0xc9daa4: cmp             w3, w1
    // 0xc9daa8: r16 = true
    //     0xc9daa8: add             x16, NULL, #0x20  ; true
    // 0xc9daac: r17 = false
    //     0xc9daac: add             x17, NULL, #0x30  ; false
    // 0xc9dab0: csel            x2, x16, x17, eq
    // 0xc9dab4: mov             x0, x2
    // 0xc9dab8: b               #0xc9dac0
    // 0xc9dabc: r0 = false
    //     0xc9dabc: add             x0, NULL, #0x30  ; false
    // 0xc9dac0: LeaveFrame
    //     0xc9dac0: mov             SP, fp
    //     0xc9dac4: ldp             fp, lr, [SP], #0x10
    // 0xc9dac8: ret
    //     0xc9dac8: ret             
    // 0xc9dacc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9dacc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9dad0: b               #0xc9d908
  }
}

// class id: 2712, size: 0x30, field offset: 0x30
class _ErrorImageCompleter extends ImageStreamCompleter {
}

// class id: 4455, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ImageProvider<X0> extends Object {

  _ resolve(/* No info */) {
    // ** addr: 0x7941c4, size: 0xe4
    // 0x7941c4: EnterFrame
    //     0x7941c4: stp             fp, lr, [SP, #-0x10]!
    //     0x7941c8: mov             fp, SP
    // 0x7941cc: AllocStack(0x20)
    //     0x7941cc: sub             SP, SP, #0x20
    // 0x7941d0: CheckStackOverflow
    //     0x7941d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7941d4: cmp             SP, x16
    //     0x7941d8: b.ls            #0x7942a0
    // 0x7941dc: r1 = 2
    //     0x7941dc: mov             x1, #2
    // 0x7941e0: r0 = AllocateContext()
    //     0x7941e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7941e4: mov             x1, x0
    // 0x7941e8: ldr             x0, [fp, #0x18]
    // 0x7941ec: stur            x1, [fp, #-8]
    // 0x7941f0: StoreField: r1->field_f = r0
    //     0x7941f0: stur            w0, [x1, #0xf]
    // 0x7941f4: SaveReg r0
    //     0x7941f4: str             x0, [SP, #-8]!
    // 0x7941f8: r0 = createStream()
    //     0x7941f8: bl              #0x7945dc  ; [package:flutter/src/painting/image_provider.dart] ImageProvider::createStream
    // 0x7941fc: add             SP, SP, #8
    // 0x794200: mov             x4, x0
    // 0x794204: ldur            x3, [fp, #-8]
    // 0x794208: stur            x4, [fp, #-0x18]
    // 0x79420c: StoreField: r3->field_13 = r0
    //     0x79420c: stur            w0, [x3, #0x13]
    //     0x794210: ldurb           w16, [x3, #-1]
    //     0x794214: ldurb           w17, [x0, #-1]
    //     0x794218: and             x16, x17, x16, lsr #2
    //     0x79421c: tst             x16, HEAP, lsr #32
    //     0x794220: b.eq            #0x794228
    //     0x794224: bl              #0xd682ac
    // 0x794228: ldr             x0, [fp, #0x18]
    // 0x79422c: LoadField: r5 = r0->field_7
    //     0x79422c: ldur            w5, [x0, #7]
    // 0x794230: DecompressPointer r5
    //     0x794230: add             x5, x5, HEAP, lsl #32
    // 0x794234: mov             x2, x3
    // 0x794238: stur            x5, [fp, #-0x10]
    // 0x79423c: r1 = Function '<anonymous closure>':.
    //     0x79423c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27e68] AnonymousClosure: (0x794e18), in [package:flutter/src/painting/image_provider.dart] ImageProvider::resolve (0x7941c4)
    //     0x794240: ldr             x1, [x1, #0xe68]
    // 0x794244: r0 = AllocateClosure()
    //     0x794244: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x794248: mov             x3, x0
    // 0x79424c: ldur            x0, [fp, #-0x10]
    // 0x794250: stur            x3, [fp, #-0x20]
    // 0x794254: StoreField: r3->field_7 = r0
    //     0x794254: stur            w0, [x3, #7]
    // 0x794258: ldur            x2, [fp, #-8]
    // 0x79425c: r1 = Function '<anonymous closure>':.
    //     0x79425c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27e70] AnonymousClosure: (0x794600), in [package:flutter/src/painting/image_provider.dart] ImageProvider::resolve (0x7941c4)
    //     0x794260: ldr             x1, [x1, #0xe70]
    // 0x794264: r0 = AllocateClosure()
    //     0x794264: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x794268: mov             x1, x0
    // 0x79426c: ldur            x0, [fp, #-0x10]
    // 0x794270: StoreField: r1->field_7 = r0
    //     0x794270: stur            w0, [x1, #7]
    // 0x794274: ldr             x16, [fp, #0x18]
    // 0x794278: ldr             lr, [fp, #0x10]
    // 0x79427c: stp             lr, x16, [SP, #-0x10]!
    // 0x794280: ldur            x16, [fp, #-0x20]
    // 0x794284: stp             x1, x16, [SP, #-0x10]!
    // 0x794288: r0 = _createErrorHandlerAndKey()
    //     0x794288: bl              #0x7942a8  ; [package:flutter/src/painting/image_provider.dart] ImageProvider::_createErrorHandlerAndKey
    // 0x79428c: add             SP, SP, #0x20
    // 0x794290: ldur            x0, [fp, #-0x18]
    // 0x794294: LeaveFrame
    //     0x794294: mov             SP, fp
    //     0x794298: ldp             fp, lr, [SP], #0x10
    // 0x79429c: ret
    //     0x79429c: ret             
    // 0x7942a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7942a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7942a4: b               #0x7941dc
  }
  _ _createErrorHandlerAndKey(/* No info */) {
    // ** addr: 0x7942a8, size: 0x174
    // 0x7942a8: EnterFrame
    //     0x7942a8: stp             fp, lr, [SP, #-0x10]!
    //     0x7942ac: mov             fp, SP
    // 0x7942b0: AllocStack(0x60)
    //     0x7942b0: sub             SP, SP, #0x60
    // 0x7942b4: CheckStackOverflow
    //     0x7942b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7942b8: cmp             SP, x16
    //     0x7942bc: b.ls            #0x794414
    // 0x7942c0: r1 = 6
    //     0x7942c0: mov             x1, #6
    // 0x7942c4: r0 = AllocateContext()
    //     0x7942c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7942c8: mov             x3, x0
    // 0x7942cc: ldr             x0, [fp, #0x28]
    // 0x7942d0: stur            x3, [fp, #-0x48]
    // 0x7942d4: StoreField: r3->field_f = r0
    //     0x7942d4: stur            w0, [x3, #0xf]
    // 0x7942d8: ldr             x1, [fp, #0x18]
    // 0x7942dc: StoreField: r3->field_13 = r1
    //     0x7942dc: stur            w1, [x3, #0x13]
    // 0x7942e0: ldr             x1, [fp, #0x10]
    // 0x7942e4: StoreField: r3->field_17 = r1
    //     0x7942e4: stur            w1, [x3, #0x17]
    // 0x7942e8: r1 = false
    //     0x7942e8: add             x1, NULL, #0x30  ; false
    // 0x7942ec: StoreField: r3->field_1f = r1
    //     0x7942ec: stur            w1, [x3, #0x1f]
    // 0x7942f0: mov             x2, x3
    // 0x7942f4: r1 = Function 'handleError':.
    //     0x7942f4: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f70] AnonymousClosure: (0x7944fc), in [package:flutter/src/painting/image_provider.dart] ImageProvider::_createErrorHandlerAndKey (0x7942a8)
    //     0x7942f8: ldr             x1, [x1, #0xf70]
    // 0x7942fc: r0 = AllocateClosure()
    //     0x7942fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x794300: mov             x1, x0
    // 0x794304: ldur            x2, [fp, #-0x48]
    // 0x794308: stur            x1, [fp, #-0x50]
    // 0x79430c: StoreField: r2->field_23 = r1
    //     0x79430c: stur            w1, [x2, #0x23]
    // 0x794310: ldr             x3, [fp, #0x28]
    // 0x794314: r0 = LoadClassIdInstr(r3)
    //     0x794314: ldur            x0, [x3, #-1]
    //     0x794318: ubfx            x0, x0, #0xc, #0x14
    // 0x79431c: ldr             x16, [fp, #0x20]
    // 0x794320: stp             x16, x3, [SP, #-0x10]!
    // 0x794324: r0 = GDT[cid_x0 + 0x829]()
    //     0x794324: add             lr, x0, #0x829
    //     0x794328: ldr             lr, [x21, lr, lsl #3]
    //     0x79432c: blr             lr
    // 0x794330: add             SP, SP, #0x10
    // 0x794334: stur            x0, [fp, #-0x60]
    // 0x794338: ldr             x1, [fp, #0x28]
    // 0x79433c: LoadField: r3 = r1->field_7
    //     0x79433c: ldur            w3, [x1, #7]
    // 0x794340: DecompressPointer r3
    //     0x794340: add             x3, x3, HEAP, lsl #32
    // 0x794344: ldur            x2, [fp, #-0x48]
    // 0x794348: stur            x3, [fp, #-0x58]
    // 0x79434c: r1 = Function '<anonymous closure>':.
    //     0x79434c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27f78] AnonymousClosure: (0x79441c), in [package:flutter/src/painting/image_provider.dart] ImageProvider::_createErrorHandlerAndKey (0x7942a8)
    //     0x794350: ldr             x1, [x1, #0xf78]
    // 0x794354: r0 = AllocateClosure()
    //     0x794354: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x794358: mov             x1, x0
    // 0x79435c: ldur            x0, [fp, #-0x58]
    // 0x794360: StoreField: r1->field_7 = r0
    //     0x794360: stur            w0, [x1, #7]
    // 0x794364: ldur            x0, [fp, #-0x60]
    // 0x794368: r2 = LoadClassIdInstr(r0)
    //     0x794368: ldur            x2, [x0, #-1]
    //     0x79436c: ubfx            x2, x2, #0xc, #0x14
    // 0x794370: r16 = <void?>
    //     0x794370: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x794374: stp             x0, x16, [SP, #-0x10]!
    // 0x794378: SaveReg r1
    //     0x794378: str             x1, [SP, #-8]!
    // 0x79437c: mov             x0, x2
    // 0x794380: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x794380: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x794384: r0 = GDT[cid_x0 + -0xffe]()
    //     0x794384: sub             lr, x0, #0xffe
    //     0x794388: ldr             lr, [x21, lr, lsl #3]
    //     0x79438c: blr             lr
    // 0x794390: add             SP, SP, #0x18
    // 0x794394: r1 = LoadClassIdInstr(r0)
    //     0x794394: ldur            x1, [x0, #-1]
    //     0x794398: ubfx            x1, x1, #0xc, #0x14
    // 0x79439c: ldur            x16, [fp, #-0x50]
    // 0x7943a0: stp             x16, x0, [SP, #-0x10]!
    // 0x7943a4: mov             x0, x1
    // 0x7943a8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7943a8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7943ac: r0 = GDT[cid_x0 + -0xffb]()
    //     0x7943ac: sub             lr, x0, #0xffb
    //     0x7943b0: ldr             lr, [x21, lr, lsl #3]
    //     0x7943b4: blr             lr
    // 0x7943b8: add             SP, SP, #0x10
    // 0x7943bc: r0 = Null
    //     0x7943bc: mov             x0, NULL
    // 0x7943c0: LeaveFrame
    //     0x7943c0: mov             SP, fp
    //     0x7943c4: ldp             fp, lr, [SP], #0x10
    // 0x7943c8: ret
    //     0x7943c8: ret             
    // 0x7943cc: sub             SP, fp, #0x60
    // 0x7943d0: ldur            x2, [fp, #-0x10]
    // 0x7943d4: mov             x16, x1
    // 0x7943d8: mov             x1, x0
    // 0x7943dc: mov             x0, x16
    // 0x7943e0: LoadField: r3 = r2->field_23
    //     0x7943e0: ldur            w3, [x2, #0x23]
    // 0x7943e4: DecompressPointer r3
    //     0x7943e4: add             x3, x3, HEAP, lsl #32
    // 0x7943e8: stp             x1, x3, [SP, #-0x10]!
    // 0x7943ec: SaveReg r0
    //     0x7943ec: str             x0, [SP, #-8]!
    // 0x7943f0: mov             x0, x3
    // 0x7943f4: ClosureCall
    //     0x7943f4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x7943f8: ldur            x2, [x0, #0x1f]
    //     0x7943fc: blr             x2
    // 0x794400: add             SP, SP, #0x18
    // 0x794404: r0 = Null
    //     0x794404: mov             x0, NULL
    // 0x794408: LeaveFrame
    //     0x794408: mov             SP, fp
    //     0x79440c: ldp             fp, lr, [SP], #0x10
    // 0x794410: ret
    //     0x794410: ret             
    // 0x794414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794414: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794418: b               #0x7942c0
  }
  [closure] Null <anonymous closure>(dynamic, X0) {
    // ** addr: 0x79441c, size: 0xe0
    // 0x79441c: EnterFrame
    //     0x79441c: stp             fp, lr, [SP, #-0x10]!
    //     0x794420: mov             fp, SP
    // 0x794424: AllocStack(0x48)
    //     0x794424: sub             SP, SP, #0x48
    // 0x794428: SetupParameters()
    //     0x794428: ldr             x0, [fp, #0x18]
    //     0x79442c: ldur            w1, [x0, #0x17]
    //     0x794430: add             x1, x1, HEAP, lsl #32
    //     0x794434: stur            x1, [fp, #-0x48]
    // 0x794438: CheckStackOverflow
    //     0x794438: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79443c: cmp             SP, x16
    //     0x794440: b.ls            #0x7944f0
    // 0x794444: ldr             x0, [fp, #0x10]
    // 0x794448: StoreField: r1->field_1b = r0
    //     0x794448: stur            w0, [x1, #0x1b]
    //     0x79444c: tbz             w0, #0, #0x794468
    //     0x794450: ldurb           w16, [x1, #-1]
    //     0x794454: ldurb           w17, [x0, #-1]
    //     0x794458: and             x16, x17, x16, lsr #2
    //     0x79445c: tst             x16, HEAP, lsr #32
    //     0x794460: b.eq            #0x794468
    //     0x794464: bl              #0xd6826c
    // 0x794468: LoadField: r2 = r1->field_13
    //     0x794468: ldur            w2, [x1, #0x13]
    // 0x79446c: DecompressPointer r2
    //     0x79446c: add             x2, x2, HEAP, lsl #32
    // 0x794470: stur            x2, [fp, #-0x40]
    // 0x794474: LoadField: r0 = r1->field_23
    //     0x794474: ldur            w0, [x1, #0x23]
    // 0x794478: DecompressPointer r0
    //     0x794478: add             x0, x0, HEAP, lsl #32
    // 0x79447c: cmp             w2, NULL
    // 0x794480: b.eq            #0x7944f8
    // 0x794484: ldr             x16, [fp, #0x10]
    // 0x794488: stp             x16, x2, [SP, #-0x10]!
    // 0x79448c: SaveReg r0
    //     0x79448c: str             x0, [SP, #-8]!
    // 0x794490: mov             x0, x2
    // 0x794494: ClosureCall
    //     0x794494: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x794498: ldur            x2, [x0, #0x1f]
    //     0x79449c: blr             x2
    // 0x7944a0: add             SP, SP, #0x18
    // 0x7944a4: b               #0x7944e0
    // 0x7944a8: sub             SP, fp, #0x48
    // 0x7944ac: ldur            x2, [fp, #-0x10]
    // 0x7944b0: mov             x16, x1
    // 0x7944b4: mov             x1, x0
    // 0x7944b8: mov             x0, x16
    // 0x7944bc: LoadField: r3 = r2->field_23
    //     0x7944bc: ldur            w3, [x2, #0x23]
    // 0x7944c0: DecompressPointer r3
    //     0x7944c0: add             x3, x3, HEAP, lsl #32
    // 0x7944c4: stp             x1, x3, [SP, #-0x10]!
    // 0x7944c8: SaveReg r0
    //     0x7944c8: str             x0, [SP, #-8]!
    // 0x7944cc: mov             x0, x3
    // 0x7944d0: ClosureCall
    //     0x7944d0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x7944d4: ldur            x2, [x0, #0x1f]
    //     0x7944d8: blr             x2
    // 0x7944dc: add             SP, SP, #0x18
    // 0x7944e0: r0 = Null
    //     0x7944e0: mov             x0, NULL
    // 0x7944e4: LeaveFrame
    //     0x7944e4: mov             SP, fp
    //     0x7944e8: ldp             fp, lr, [SP], #0x10
    // 0x7944ec: ret
    //     0x7944ec: ret             
    // 0x7944f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7944f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7944f4: b               #0x794444
    // 0x7944f8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7944f8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> handleError(dynamic, Object, StackTrace?) async {
    // ** addr: 0x7944fc, size: 0xe0
    // 0x7944fc: EnterFrame
    //     0x7944fc: stp             fp, lr, [SP, #-0x10]!
    //     0x794500: mov             fp, SP
    // 0x794504: AllocStack(0x28)
    //     0x794504: sub             SP, SP, #0x28
    // 0x794508: SetupParameters(ImageProvider<X0> this /* r1 */, dynamic _ /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */)
    //     0x794508: stur            NULL, [fp, #-8]
    //     0x79450c: mov             x0, #0
    //     0x794510: add             x1, fp, w0, sxtw #2
    //     0x794514: ldr             x1, [x1, #0x20]
    //     0x794518: add             x2, fp, w0, sxtw #2
    //     0x79451c: ldr             x2, [x2, #0x18]
    //     0x794520: stur            x2, [fp, #-0x20]
    //     0x794524: add             x3, fp, w0, sxtw #2
    //     0x794528: ldr             x3, [x3, #0x10]
    //     0x79452c: stur            x3, [fp, #-0x18]
    //     0x794530: ldur            w4, [x1, #0x17]
    //     0x794534: add             x4, x4, HEAP, lsl #32
    //     0x794538: stur            x4, [fp, #-0x10]
    // 0x79453c: CheckStackOverflow
    //     0x79453c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794540: cmp             SP, x16
    //     0x794544: b.ls            #0x7945d0
    // 0x794548: InitAsync() -> Future<void?>
    //     0x794548: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x79454c: bl              #0x4b92e4
    // 0x794550: ldur            x1, [fp, #-0x10]
    // 0x794554: LoadField: r2 = r1->field_1f
    //     0x794554: ldur            w2, [x1, #0x1f]
    // 0x794558: DecompressPointer r2
    //     0x794558: add             x2, x2, HEAP, lsl #32
    // 0x79455c: mov             x0, x2
    // 0x794560: stur            x2, [fp, #-0x28]
    // 0x794564: tbnz            w0, #5, #0x79456c
    // 0x794568: r0 = AssertBoolean()
    //     0x794568: bl              #0xd67df0  ; AssertBooleanStub
    // 0x79456c: ldur            x0, [fp, #-0x28]
    // 0x794570: tbnz            w0, #4, #0x79457c
    // 0x794574: r0 = Null
    //     0x794574: mov             x0, NULL
    // 0x794578: r0 = ReturnAsyncNotFuture()
    //     0x794578: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x79457c: tbz             w0, #4, #0x7945bc
    // 0x794580: ldur            x1, [fp, #-0x10]
    // 0x794584: LoadField: r0 = r1->field_17
    //     0x794584: ldur            w0, [x1, #0x17]
    // 0x794588: DecompressPointer r0
    //     0x794588: add             x0, x0, HEAP, lsl #32
    // 0x79458c: LoadField: r2 = r1->field_1b
    //     0x79458c: ldur            w2, [x1, #0x1b]
    // 0x794590: DecompressPointer r2
    //     0x794590: add             x2, x2, HEAP, lsl #32
    // 0x794594: cmp             w0, NULL
    // 0x794598: b.eq            #0x7945d8
    // 0x79459c: stp             x2, x0, [SP, #-0x10]!
    // 0x7945a0: ldur            x16, [fp, #-0x20]
    // 0x7945a4: ldur            lr, [fp, #-0x18]
    // 0x7945a8: stp             lr, x16, [SP, #-0x10]!
    // 0x7945ac: ClosureCall
    //     0x7945ac: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x7945b0: ldur            x2, [x0, #0x1f]
    //     0x7945b4: blr             x2
    // 0x7945b8: add             SP, SP, #0x20
    // 0x7945bc: ldur            x1, [fp, #-0x10]
    // 0x7945c0: r2 = true
    //     0x7945c0: add             x2, NULL, #0x20  ; true
    // 0x7945c4: StoreField: r1->field_1f = r2
    //     0x7945c4: stur            w2, [x1, #0x1f]
    // 0x7945c8: r0 = Null
    //     0x7945c8: mov             x0, NULL
    // 0x7945cc: r0 = ReturnAsyncNotFuture()
    //     0x7945cc: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x7945d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7945d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7945d4: b               #0x794548
    // 0x7945d8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7945d8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ createStream(/* No info */) {
    // ** addr: 0x7945dc, size: 0x18
    // 0x7945dc: EnterFrame
    //     0x7945dc: stp             fp, lr, [SP, #-0x10]!
    //     0x7945e0: mov             fp, SP
    // 0x7945e4: r0 = ImageStream()
    //     0x7945e4: bl              #0x7945f4  ; AllocateImageStreamStub -> ImageStream (size=0x10)
    // 0x7945e8: LeaveFrame
    //     0x7945e8: mov             SP, fp
    //     0x7945ec: ldp             fp, lr, [SP], #0x10
    // 0x7945f0: ret
    //     0x7945f0: ret             
  }
  [closure] Future<void> <anonymous closure>(dynamic, X0?, Object, StackTrace?) async {
    // ** addr: 0x794600, size: 0x128
    // 0x794600: EnterFrame
    //     0x794600: stp             fp, lr, [SP, #-0x10]!
    //     0x794604: mov             fp, SP
    // 0x794608: AllocStack(0x28)
    //     0x794608: sub             SP, SP, #0x28
    // 0x79460c: SetupParameters(ImageProvider<X0> this /* r1 */, dynamic _ /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */)
    //     0x79460c: stur            NULL, [fp, #-8]
    //     0x794610: mov             x0, #0
    //     0x794614: add             x1, fp, w0, sxtw #2
    //     0x794618: ldr             x1, [x1, #0x28]
    //     0x79461c: add             x2, fp, w0, sxtw #2
    //     0x794620: ldr             x2, [x2, #0x18]
    //     0x794624: stur            x2, [fp, #-0x20]
    //     0x794628: add             x3, fp, w0, sxtw #2
    //     0x79462c: ldr             x3, [x3, #0x10]
    //     0x794630: stur            x3, [fp, #-0x18]
    //     0x794634: ldur            w4, [x1, #0x17]
    //     0x794638: add             x4, x4, HEAP, lsl #32
    //     0x79463c: stur            x4, [fp, #-0x10]
    // 0x794640: CheckStackOverflow
    //     0x794640: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794644: cmp             SP, x16
    //     0x794648: b.ls            #0x79471c
    // 0x79464c: InitAsync() -> Future<void?>
    //     0x79464c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x794650: bl              #0x4b92e4
    // 0x794654: r0 = Null
    //     0x794654: mov             x0, NULL
    // 0x794658: r0 = Await()
    //     0x794658: bl              #0x4b8e6c  ; AwaitStub
    // 0x79465c: ldur            x0, [fp, #-0x10]
    // 0x794660: LoadField: r1 = r0->field_13
    //     0x794660: ldur            w1, [x0, #0x13]
    // 0x794664: DecompressPointer r1
    //     0x794664: add             x1, x1, HEAP, lsl #32
    // 0x794668: stur            x1, [fp, #-0x28]
    // 0x79466c: LoadField: r0 = r1->field_7
    //     0x79466c: ldur            w0, [x1, #7]
    // 0x794670: DecompressPointer r0
    //     0x794670: add             x0, x0, HEAP, lsl #32
    // 0x794674: cmp             w0, NULL
    // 0x794678: b.ne            #0x7946a4
    // 0x79467c: r0 = _ErrorImageCompleter()
    //     0x79467c: bl              #0x794e0c  ; Allocate_ErrorImageCompleterStub -> _ErrorImageCompleter (size=0x30)
    // 0x794680: stur            x0, [fp, #-0x10]
    // 0x794684: SaveReg r0
    //     0x794684: str             x0, [SP, #-8]!
    // 0x794688: r0 = ImageStreamCompleter()
    //     0x794688: bl              #0x794d60  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::ImageStreamCompleter
    // 0x79468c: add             SP, SP, #8
    // 0x794690: ldur            x16, [fp, #-0x28]
    // 0x794694: ldur            lr, [fp, #-0x10]
    // 0x794698: stp             lr, x16, [SP, #-0x10]!
    // 0x79469c: r0 = setCompleter()
    //     0x79469c: bl              #0x794af4  ; [package:flutter/src/painting/image_stream.dart] ImageStream::setCompleter
    // 0x7946a0: add             SP, SP, #0x10
    // 0x7946a4: ldur            x0, [fp, #-0x28]
    // 0x7946a8: LoadField: r2 = r0->field_7
    //     0x7946a8: ldur            w2, [x0, #7]
    // 0x7946ac: DecompressPointer r2
    //     0x7946ac: add             x2, x2, HEAP, lsl #32
    // 0x7946b0: stur            x2, [fp, #-0x10]
    // 0x7946b4: cmp             w2, NULL
    // 0x7946b8: b.eq            #0x794724
    // 0x7946bc: r1 = <List<Object>>
    //     0x7946bc: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x7946c0: r0 = ErrorDescription()
    //     0x7946c0: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x7946c4: stur            x0, [fp, #-0x28]
    // 0x7946c8: r16 = "while resolving an image"
    //     0x7946c8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27e78] "while resolving an image"
    //     0x7946cc: ldr             x16, [x16, #0xe78]
    // 0x7946d0: stp             x16, x0, [SP, #-0x10]!
    // 0x7946d4: r16 = Instance_DiagnosticLevel
    //     0x7946d4: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x7946d8: SaveReg r16
    //     0x7946d8: str             x16, [SP, #-8]!
    // 0x7946dc: r0 = _ErrorDiagnostic()
    //     0x7946dc: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x7946e0: add             SP, SP, #0x18
    // 0x7946e4: ldur            x16, [fp, #-0x10]
    // 0x7946e8: ldur            lr, [fp, #-0x28]
    // 0x7946ec: stp             lr, x16, [SP, #-0x10]!
    // 0x7946f0: ldur            x16, [fp, #-0x20]
    // 0x7946f4: ldur            lr, [fp, #-0x18]
    // 0x7946f8: stp             lr, x16, [SP, #-0x10]!
    // 0x7946fc: r16 = true
    //     0x7946fc: add             x16, NULL, #0x20  ; true
    // 0x794700: stp             NULL, x16, [SP, #-0x10]!
    // 0x794704: r4 = const [0, 0x6, 0x6, 0x4, informationCollector, 0x5, silent, 0x4, null]
    //     0x794704: add             x4, PP, #0x27, lsl #12  ; [pp+0x27e80] List(9) [0, 0x6, 0x6, 0x4, "informationCollector", 0x5, "silent", 0x4, Null]
    //     0x794708: ldr             x4, [x4, #0xe80]
    // 0x79470c: r0 = reportError()
    //     0x79470c: bl              #0x794728  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0x794710: add             SP, SP, #0x30
    // 0x794714: r0 = Null
    //     0x794714: mov             x0, NULL
    // 0x794718: r0 = ReturnAsyncNotFuture()
    //     0x794718: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x79471c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79471c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794720: b               #0x79464c
    // 0x794724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x794724: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, X0, (dynamic, Object, StackTrace?) => void) {
    // ** addr: 0x794e18, size: 0x74
    // 0x794e18: EnterFrame
    //     0x794e18: stp             fp, lr, [SP, #-0x10]!
    //     0x794e1c: mov             fp, SP
    // 0x794e20: ldr             x0, [fp, #0x20]
    // 0x794e24: LoadField: r1 = r0->field_17
    //     0x794e24: ldur            w1, [x0, #0x17]
    // 0x794e28: DecompressPointer r1
    //     0x794e28: add             x1, x1, HEAP, lsl #32
    // 0x794e2c: CheckStackOverflow
    //     0x794e2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x794e30: cmp             SP, x16
    //     0x794e34: b.ls            #0x794e84
    // 0x794e38: LoadField: r0 = r1->field_f
    //     0x794e38: ldur            w0, [x1, #0xf]
    // 0x794e3c: DecompressPointer r0
    //     0x794e3c: add             x0, x0, HEAP, lsl #32
    // 0x794e40: LoadField: r2 = r1->field_13
    //     0x794e40: ldur            w2, [x1, #0x13]
    // 0x794e44: DecompressPointer r2
    //     0x794e44: add             x2, x2, HEAP, lsl #32
    // 0x794e48: r1 = LoadClassIdInstr(r0)
    //     0x794e48: ldur            x1, [x0, #-1]
    //     0x794e4c: ubfx            x1, x1, #0xc, #0x14
    // 0x794e50: stp             x2, x0, [SP, #-0x10]!
    // 0x794e54: ldr             x16, [fp, #0x18]
    // 0x794e58: ldr             lr, [fp, #0x10]
    // 0x794e5c: stp             lr, x16, [SP, #-0x10]!
    // 0x794e60: mov             x0, x1
    // 0x794e64: r0 = GDT[cid_x0 + 0x90e]()
    //     0x794e64: add             lr, x0, #0x90e
    //     0x794e68: ldr             lr, [x21, lr, lsl #3]
    //     0x794e6c: blr             lr
    // 0x794e70: add             SP, SP, #0x20
    // 0x794e74: r0 = Null
    //     0x794e74: mov             x0, NULL
    // 0x794e78: LeaveFrame
    //     0x794e78: mov             SP, fp
    //     0x794e7c: ldp             fp, lr, [SP], #0x10
    // 0x794e80: ret
    //     0x794e80: ret             
    // 0x794e84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x794e84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x794e88: b               #0x794e38
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4054, size: 0xc
    // 0xad4054: r0 = "ImageConfiguration()"
    //     0xad4054: add             x0, PP, #0x22, lsl #12  ; [pp+0x22940] "ImageConfiguration()"
    //     0xad4058: ldr             x0, [x0, #0x940]
    // 0xad405c: ret
    //     0xad405c: ret             
  }
  _ loadBuffer(/* No info */) {
    // ** addr: 0xc34af0, size: 0x80
    // 0xc34af0: EnterFrame
    //     0xc34af0: stp             fp, lr, [SP, #-0x10]!
    //     0xc34af4: mov             fp, SP
    // 0xc34af8: AllocStack(0x8)
    //     0xc34af8: sub             SP, SP, #8
    // 0xc34afc: CheckStackOverflow
    //     0xc34afc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc34b00: cmp             SP, x16
    //     0xc34b04: b.ls            #0xc34b64
    // 0xc34b08: r0 = LoadStaticField(0xe6c)
    //     0xc34b08: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc34b0c: ldr             x0, [x0, #0x1cd8]
    // 0xc34b10: stur            x0, [fp, #-8]
    // 0xc34b14: cmp             w0, NULL
    // 0xc34b18: b.eq            #0xc34b6c
    // 0xc34b1c: r1 = 1
    //     0xc34b1c: mov             x1, #1
    // 0xc34b20: r0 = AllocateContext()
    //     0xc34b20: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc34b24: mov             x1, x0
    // 0xc34b28: ldur            x0, [fp, #-8]
    // 0xc34b2c: StoreField: r1->field_f = r0
    //     0xc34b2c: stur            w0, [x1, #0xf]
    // 0xc34b30: mov             x2, x1
    // 0xc34b34: r1 = Function 'instantiateImageCodec':.
    //     0xc34b34: add             x1, PP, #0x38, lsl #12  ; [pp+0x38348] AnonymousClosure: (0xc35838), of [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding
    //     0xc34b38: ldr             x1, [x1, #0x348]
    // 0xc34b3c: r0 = AllocateClosure()
    //     0xc34b3c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc34b40: ldr             x16, [fp, #0x20]
    // 0xc34b44: ldr             lr, [fp, #0x18]
    // 0xc34b48: stp             lr, x16, [SP, #-0x10]!
    // 0xc34b4c: SaveReg r0
    //     0xc34b4c: str             x0, [SP, #-8]!
    // 0xc34b50: r0 = load()
    //     0xc34b50: bl              #0xc34b70  ; [package:photo_manager/src/internal/image_provider.dart] AssetEntityImageProvider::load
    // 0xc34b54: add             SP, SP, #0x18
    // 0xc34b58: LeaveFrame
    //     0xc34b58: mov             SP, fp
    //     0xc34b5c: ldp             fp, lr, [SP], #0x10
    // 0xc34b60: ret
    //     0xc34b60: ret             
    // 0xc34b64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc34b64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc34b68: b               #0xc34b08
    // 0xc34b6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc34b6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ evict(/* No info */) async {
    // ** addr: 0xc3e344, size: 0xa0
    // 0xc3e344: EnterFrame
    //     0xc3e344: stp             fp, lr, [SP, #-0x10]!
    //     0xc3e348: mov             fp, SP
    // 0xc3e34c: AllocStack(0x18)
    //     0xc3e34c: sub             SP, SP, #0x18
    // 0xc3e350: SetupParameters(ImageProvider<X0> this /* r1, fp-0x10 */)
    //     0xc3e350: stur            NULL, [fp, #-8]
    //     0xc3e354: mov             x0, x4
    //     0xc3e358: ldur            w1, [x0, #0x13]
    //     0xc3e35c: add             x1, x1, HEAP, lsl #32
    //     0xc3e360: sub             x0, x1, #2
    //     0xc3e364: add             x1, fp, w0, sxtw #2
    //     0xc3e368: ldr             x1, [x1, #0x10]
    //     0xc3e36c: stur            x1, [fp, #-0x10]
    // 0xc3e370: CheckStackOverflow
    //     0xc3e370: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3e374: cmp             SP, x16
    //     0xc3e378: b.ls            #0xc3e3dc
    // 0xc3e37c: InitAsync() -> Future<bool>
    //     0xc3e37c: ldr             x0, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    //     0xc3e380: bl              #0x4b92e4
    // 0xc3e384: r0 = imageCache()
    //     0xc3e384: bl              #0xc3e248  ; [package:flutter/src/painting/binding.dart] ::imageCache
    // 0xc3e388: mov             x1, x0
    // 0xc3e38c: ldur            x0, [fp, #-0x10]
    // 0xc3e390: stur            x1, [fp, #-0x18]
    // 0xc3e394: r2 = LoadClassIdInstr(r0)
    //     0xc3e394: ldur            x2, [x0, #-1]
    //     0xc3e398: ubfx            x2, x2, #0xc, #0x14
    // 0xc3e39c: r16 = Instance_ImageConfiguration
    //     0xc3e39c: add             x16, PP, #0x31, lsl #12  ; [pp+0x318e0] Obj!ImageConfiguration@b356f1
    //     0xc3e3a0: ldr             x16, [x16, #0x8e0]
    // 0xc3e3a4: stp             x16, x0, [SP, #-0x10]!
    // 0xc3e3a8: mov             x0, x2
    // 0xc3e3ac: r0 = GDT[cid_x0 + 0x829]()
    //     0xc3e3ac: add             lr, x0, #0x829
    //     0xc3e3b0: ldr             lr, [x21, lr, lsl #3]
    //     0xc3e3b4: blr             lr
    // 0xc3e3b8: add             SP, SP, #0x10
    // 0xc3e3bc: mov             x1, x0
    // 0xc3e3c0: stur            x1, [fp, #-0x10]
    // 0xc3e3c4: r0 = Await()
    //     0xc3e3c4: bl              #0x4b8e6c  ; AwaitStub
    // 0xc3e3c8: ldur            x16, [fp, #-0x18]
    // 0xc3e3cc: stp             x0, x16, [SP, #-0x10]!
    // 0xc3e3d0: r0 = evict()
    //     0xc3e3d0: bl              #0xc316b4  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0xc3e3d4: add             SP, SP, #0x10
    // 0xc3e3d8: r0 = ReturnAsyncNotFuture()
    //     0xc3e3d8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc3e3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3e3dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3e3e0: b               #0xc3e37c
  }
  _ resolveStreamForKey(/* No info */) {
    // ** addr: 0xc40d80, size: 0x194
    // 0xc40d80: EnterFrame
    //     0xc40d80: stp             fp, lr, [SP, #-0x10]!
    //     0xc40d84: mov             fp, SP
    // 0xc40d88: AllocStack(0x10)
    //     0xc40d88: sub             SP, SP, #0x10
    // 0xc40d8c: CheckStackOverflow
    //     0xc40d8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc40d90: cmp             SP, x16
    //     0xc40d94: b.ls            #0xc40ef4
    // 0xc40d98: r1 = 3
    //     0xc40d98: mov             x1, #3
    // 0xc40d9c: r0 = AllocateContext()
    //     0xc40d9c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc40da0: mov             x3, x0
    // 0xc40da4: ldr             x0, [fp, #0x28]
    // 0xc40da8: stur            x3, [fp, #-8]
    // 0xc40dac: StoreField: r3->field_f = r0
    //     0xc40dac: stur            w0, [x3, #0xf]
    // 0xc40db0: ldr             x4, [fp, #0x20]
    // 0xc40db4: StoreField: r3->field_13 = r4
    //     0xc40db4: stur            w4, [x3, #0x13]
    // 0xc40db8: ldr             x5, [fp, #0x18]
    // 0xc40dbc: StoreField: r3->field_17 = r5
    //     0xc40dbc: stur            w5, [x3, #0x17]
    // 0xc40dc0: LoadField: r2 = r0->field_7
    //     0xc40dc0: ldur            w2, [x0, #7]
    // 0xc40dc4: DecompressPointer r2
    //     0xc40dc4: add             x2, x2, HEAP, lsl #32
    // 0xc40dc8: mov             x0, x5
    // 0xc40dcc: r1 = Null
    //     0xc40dcc: mov             x1, NULL
    // 0xc40dd0: cmp             w2, NULL
    // 0xc40dd4: b.eq            #0xc40df8
    // 0xc40dd8: LoadField: r4 = r2->field_17
    //     0xc40dd8: ldur            w4, [x2, #0x17]
    // 0xc40ddc: DecompressPointer r4
    //     0xc40ddc: add             x4, x4, HEAP, lsl #32
    // 0xc40de0: r8 = X0
    //     0xc40de0: add             x8, PP, #0xe, lsl #12  ; [pp+0xe0c0] TypeParameter: X0
    //     0xc40de4: ldr             x8, [x8, #0xc0]
    // 0xc40de8: LoadField: r9 = r4->field_7
    //     0xc40de8: ldur            x9, [x4, #7]
    // 0xc40dec: r3 = Null
    //     0xc40dec: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f008] Null
    //     0xc40df0: ldr             x3, [x3, #8]
    // 0xc40df4: blr             x9
    // 0xc40df8: ldr             x0, [fp, #0x20]
    // 0xc40dfc: LoadField: r1 = r0->field_7
    //     0xc40dfc: ldur            w1, [x0, #7]
    // 0xc40e00: DecompressPointer r1
    //     0xc40e00: add             x1, x1, HEAP, lsl #32
    // 0xc40e04: cmp             w1, NULL
    // 0xc40e08: b.eq            #0xc40e70
    // 0xc40e0c: r0 = LoadStaticField(0xe6c)
    //     0xc40e0c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc40e10: ldr             x0, [x0, #0x1cd8]
    // 0xc40e14: cmp             w0, NULL
    // 0xc40e18: b.eq            #0xc40efc
    // 0xc40e1c: LoadField: r3 = r0->field_a7
    //     0xc40e1c: ldur            w3, [x0, #0xa7]
    // 0xc40e20: DecompressPointer r3
    //     0xc40e20: add             x3, x3, HEAP, lsl #32
    // 0xc40e24: r16 = Sentinel
    //     0xc40e24: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc40e28: cmp             w3, w16
    // 0xc40e2c: b.eq            #0xc40f00
    // 0xc40e30: ldur            x2, [fp, #-8]
    // 0xc40e34: stur            x3, [fp, #-0x10]
    // 0xc40e38: r1 = Function '<anonymous closure>':.
    //     0xc40e38: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f018] AnonymousClosure: (0xc40d44), in [package:flutter3_frame/core/components/network_image/_network_image_provider_io.dart] _ExtendedNetworkImageProvider&ImageProvider&ExtendedImageProvider::resolveStreamForKey (0xc3fbb0)
    //     0xc40e3c: ldr             x1, [x1, #0x18]
    // 0xc40e40: r0 = AllocateClosure()
    //     0xc40e40: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc40e44: ldur            x16, [fp, #-0x10]
    // 0xc40e48: ldr             lr, [fp, #0x18]
    // 0xc40e4c: stp             lr, x16, [SP, #-0x10]!
    // 0xc40e50: ldr             x16, [fp, #0x10]
    // 0xc40e54: stp             x16, x0, [SP, #-0x10]!
    // 0xc40e58: r0 = putIfAbsent()
    //     0xc40e58: bl              #0xc3fd40  ; [package:flutter/src/painting/image_cache.dart] ImageCache::putIfAbsent
    // 0xc40e5c: add             SP, SP, #0x20
    // 0xc40e60: r0 = Null
    //     0xc40e60: mov             x0, NULL
    // 0xc40e64: LeaveFrame
    //     0xc40e64: mov             SP, fp
    //     0xc40e68: ldp             fp, lr, [SP], #0x10
    // 0xc40e6c: ret
    //     0xc40e6c: ret             
    // 0xc40e70: r0 = LoadStaticField(0xe6c)
    //     0xc40e70: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc40e74: ldr             x0, [x0, #0x1cd8]
    // 0xc40e78: cmp             w0, NULL
    // 0xc40e7c: b.eq            #0xc40f08
    // 0xc40e80: LoadField: r3 = r0->field_a7
    //     0xc40e80: ldur            w3, [x0, #0xa7]
    // 0xc40e84: DecompressPointer r3
    //     0xc40e84: add             x3, x3, HEAP, lsl #32
    // 0xc40e88: r16 = Sentinel
    //     0xc40e88: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc40e8c: cmp             w3, w16
    // 0xc40e90: b.eq            #0xc40f0c
    // 0xc40e94: ldur            x2, [fp, #-8]
    // 0xc40e98: stur            x3, [fp, #-0x10]
    // 0xc40e9c: r1 = Function '<anonymous closure>':.
    //     0xc40e9c: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f020] AnonymousClosure: (0xc40f14), in [package:flutter/src/painting/image_provider.dart] ImageProvider::resolveStreamForKey (0xc40d80)
    //     0xc40ea0: ldr             x1, [x1, #0x20]
    // 0xc40ea4: r0 = AllocateClosure()
    //     0xc40ea4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc40ea8: ldur            x16, [fp, #-0x10]
    // 0xc40eac: ldr             lr, [fp, #0x18]
    // 0xc40eb0: stp             lr, x16, [SP, #-0x10]!
    // 0xc40eb4: ldr             x16, [fp, #0x10]
    // 0xc40eb8: stp             x16, x0, [SP, #-0x10]!
    // 0xc40ebc: r0 = putIfAbsent()
    //     0xc40ebc: bl              #0xc3fd40  ; [package:flutter/src/painting/image_cache.dart] ImageCache::putIfAbsent
    // 0xc40ec0: add             SP, SP, #0x20
    // 0xc40ec4: cmp             w0, NULL
    // 0xc40ec8: b.eq            #0xc40ee4
    // 0xc40ecc: ldur            x1, [fp, #-8]
    // 0xc40ed0: LoadField: r2 = r1->field_13
    //     0xc40ed0: ldur            w2, [x1, #0x13]
    // 0xc40ed4: DecompressPointer r2
    //     0xc40ed4: add             x2, x2, HEAP, lsl #32
    // 0xc40ed8: stp             x0, x2, [SP, #-0x10]!
    // 0xc40edc: r0 = setCompleter()
    //     0xc40edc: bl              #0x794af4  ; [package:flutter/src/painting/image_stream.dart] ImageStream::setCompleter
    // 0xc40ee0: add             SP, SP, #0x10
    // 0xc40ee4: r0 = Null
    //     0xc40ee4: mov             x0, NULL
    // 0xc40ee8: LeaveFrame
    //     0xc40ee8: mov             SP, fp
    //     0xc40eec: ldp             fp, lr, [SP], #0x10
    // 0xc40ef0: ret
    //     0xc40ef0: ret             
    // 0xc40ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc40ef4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc40ef8: b               #0xc40d98
    // 0xc40efc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc40efc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc40f00: r9 = _imageCache
    //     0xc40f00: ldr             x9, [PP, #0x4f50]  ; [pp+0x4f50] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@423399801._imageCache@846047248>: late (offset: 0xa8)
    // 0xc40f04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc40f04: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc40f08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc40f08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc40f0c: r9 = _imageCache
    //     0xc40f0c: ldr             x9, [PP, #0x4f50]  ; [pp+0x4f50] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@423399801._imageCache@846047248>: late (offset: 0xa8)
    // 0xc40f10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc40f10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] ImageStreamCompleter <anonymous closure>(dynamic) {
    // ** addr: 0xc40f14, size: 0xbc
    // 0xc40f14: EnterFrame
    //     0xc40f14: stp             fp, lr, [SP, #-0x10]!
    //     0xc40f18: mov             fp, SP
    // 0xc40f1c: AllocStack(0x18)
    //     0xc40f1c: sub             SP, SP, #0x18
    // 0xc40f20: SetupParameters()
    //     0xc40f20: ldr             x0, [fp, #0x10]
    //     0xc40f24: ldur            w1, [x0, #0x17]
    //     0xc40f28: add             x1, x1, HEAP, lsl #32
    // 0xc40f2c: CheckStackOverflow
    //     0xc40f2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc40f30: cmp             SP, x16
    //     0xc40f34: b.ls            #0xc40fc4
    // 0xc40f38: LoadField: r0 = r1->field_f
    //     0xc40f38: ldur            w0, [x1, #0xf]
    // 0xc40f3c: DecompressPointer r0
    //     0xc40f3c: add             x0, x0, HEAP, lsl #32
    // 0xc40f40: stur            x0, [fp, #-0x18]
    // 0xc40f44: LoadField: r2 = r1->field_17
    //     0xc40f44: ldur            w2, [x1, #0x17]
    // 0xc40f48: DecompressPointer r2
    //     0xc40f48: add             x2, x2, HEAP, lsl #32
    // 0xc40f4c: stur            x2, [fp, #-0x10]
    // 0xc40f50: r1 = LoadStaticField(0xe6c)
    //     0xc40f50: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xc40f54: ldr             x1, [x1, #0x1cd8]
    // 0xc40f58: stur            x1, [fp, #-8]
    // 0xc40f5c: cmp             w1, NULL
    // 0xc40f60: b.eq            #0xc40fcc
    // 0xc40f64: r1 = 1
    //     0xc40f64: mov             x1, #1
    // 0xc40f68: r0 = AllocateContext()
    //     0xc40f68: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc40f6c: mov             x1, x0
    // 0xc40f70: ldur            x0, [fp, #-8]
    // 0xc40f74: StoreField: r1->field_f = r0
    //     0xc40f74: stur            w0, [x1, #0xf]
    // 0xc40f78: mov             x2, x1
    // 0xc40f7c: r1 = Function 'instantiateImageCodecFromBuffer':.
    //     0xc40f7c: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c978] AnonymousClosure: (0xc40c08), of [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding
    //     0xc40f80: ldr             x1, [x1, #0x978]
    // 0xc40f84: r0 = AllocateClosure()
    //     0xc40f84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc40f88: mov             x1, x0
    // 0xc40f8c: ldur            x0, [fp, #-0x18]
    // 0xc40f90: r2 = LoadClassIdInstr(r0)
    //     0xc40f90: ldur            x2, [x0, #-1]
    //     0xc40f94: ubfx            x2, x2, #0xc, #0x14
    // 0xc40f98: ldur            x16, [fp, #-0x10]
    // 0xc40f9c: stp             x16, x0, [SP, #-0x10]!
    // 0xc40fa0: SaveReg r1
    //     0xc40fa0: str             x1, [SP, #-8]!
    // 0xc40fa4: mov             x0, x2
    // 0xc40fa8: r0 = GDT[cid_x0 + 0xa61]()
    //     0xc40fa8: add             lr, x0, #0xa61
    //     0xc40fac: ldr             lr, [x21, lr, lsl #3]
    //     0xc40fb0: blr             lr
    // 0xc40fb4: add             SP, SP, #0x18
    // 0xc40fb8: LeaveFrame
    //     0xc40fb8: mov             SP, fp
    //     0xc40fbc: ldp             fp, lr, [SP], #0x10
    // 0xc40fc0: ret
    //     0xc40fc0: ret             
    // 0xc40fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc40fc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc40fc8: b               #0xc40f38
    // 0xc40fcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc40fcc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4461, size: 0x18, field offset: 0xc
//   const constructor, 
class MemoryImage extends ImageProvider<MemoryImage> {

  _ toString(/* No info */) {
    // ** addr: 0xad3e68, size: 0x124
    // 0xad3e68: EnterFrame
    //     0xad3e68: stp             fp, lr, [SP, #-0x10]!
    //     0xad3e6c: mov             fp, SP
    // 0xad3e70: AllocStack(0x8)
    //     0xad3e70: sub             SP, SP, #8
    // 0xad3e74: CheckStackOverflow
    //     0xad3e74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3e78: cmp             SP, x16
    //     0xad3e7c: b.ls            #0xad3f6c
    // 0xad3e80: r1 = Null
    //     0xad3e80: mov             x1, NULL
    // 0xad3e84: r2 = 12
    //     0xad3e84: mov             x2, #0xc
    // 0xad3e88: r0 = AllocateArray()
    //     0xad3e88: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad3e8c: stur            x0, [fp, #-8]
    // 0xad3e90: r17 = "MemoryImage"
    //     0xad3e90: add             x17, PP, #0x29, lsl #12  ; [pp+0x29228] "MemoryImage"
    //     0xad3e94: ldr             x17, [x17, #0x228]
    // 0xad3e98: StoreField: r0->field_f = r17
    //     0xad3e98: stur            w17, [x0, #0xf]
    // 0xad3e9c: r17 = "("
    //     0xad3e9c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad3ea0: StoreField: r0->field_13 = r17
    //     0xad3ea0: stur            w17, [x0, #0x13]
    // 0xad3ea4: ldr             x1, [fp, #0x10]
    // 0xad3ea8: LoadField: r2 = r1->field_b
    //     0xad3ea8: ldur            w2, [x1, #0xb]
    // 0xad3eac: DecompressPointer r2
    //     0xad3eac: add             x2, x2, HEAP, lsl #32
    // 0xad3eb0: SaveReg r2
    //     0xad3eb0: str             x2, [SP, #-8]!
    // 0xad3eb4: r0 = describeIdentity()
    //     0xad3eb4: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xad3eb8: add             SP, SP, #8
    // 0xad3ebc: ldur            x1, [fp, #-8]
    // 0xad3ec0: ArrayStore: r1[2] = r0  ; List_4
    //     0xad3ec0: add             x25, x1, #0x17
    //     0xad3ec4: str             w0, [x25]
    //     0xad3ec8: tbz             w0, #0, #0xad3ee4
    //     0xad3ecc: ldurb           w16, [x1, #-1]
    //     0xad3ed0: ldurb           w17, [x0, #-1]
    //     0xad3ed4: and             x16, x17, x16, lsr #2
    //     0xad3ed8: tst             x16, HEAP, lsr #32
    //     0xad3edc: b.eq            #0xad3ee4
    //     0xad3ee0: bl              #0xd67e5c
    // 0xad3ee4: ldur            x2, [fp, #-8]
    // 0xad3ee8: r17 = ", scale: "
    //     0xad3ee8: add             x17, PP, #0x29, lsl #12  ; [pp+0x29230] ", scale: "
    //     0xad3eec: ldr             x17, [x17, #0x230]
    // 0xad3ef0: StoreField: r2->field_1b = r17
    //     0xad3ef0: stur            w17, [x2, #0x1b]
    // 0xad3ef4: ldr             x0, [fp, #0x10]
    // 0xad3ef8: LoadField: d0 = r0->field_f
    //     0xad3ef8: ldur            d0, [x0, #0xf]
    // 0xad3efc: r0 = inline_Allocate_Double()
    //     0xad3efc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad3f00: add             x0, x0, #0x10
    //     0xad3f04: cmp             x1, x0
    //     0xad3f08: b.ls            #0xad3f74
    //     0xad3f0c: str             x0, [THR, #0x60]  ; THR::top
    //     0xad3f10: sub             x0, x0, #0xf
    //     0xad3f14: mov             x1, #0xd108
    //     0xad3f18: movk            x1, #3, lsl #16
    //     0xad3f1c: stur            x1, [x0, #-1]
    // 0xad3f20: StoreField: r0->field_7 = d0
    //     0xad3f20: stur            d0, [x0, #7]
    // 0xad3f24: mov             x1, x2
    // 0xad3f28: ArrayStore: r1[4] = r0  ; List_4
    //     0xad3f28: add             x25, x1, #0x1f
    //     0xad3f2c: str             w0, [x25]
    //     0xad3f30: tbz             w0, #0, #0xad3f4c
    //     0xad3f34: ldurb           w16, [x1, #-1]
    //     0xad3f38: ldurb           w17, [x0, #-1]
    //     0xad3f3c: and             x16, x17, x16, lsr #2
    //     0xad3f40: tst             x16, HEAP, lsr #32
    //     0xad3f44: b.eq            #0xad3f4c
    //     0xad3f48: bl              #0xd67e5c
    // 0xad3f4c: r17 = ")"
    //     0xad3f4c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad3f50: StoreField: r2->field_23 = r17
    //     0xad3f50: stur            w17, [x2, #0x23]
    // 0xad3f54: SaveReg r2
    //     0xad3f54: str             x2, [SP, #-8]!
    // 0xad3f58: r0 = _interpolate()
    //     0xad3f58: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3f5c: add             SP, SP, #8
    // 0xad3f60: LeaveFrame
    //     0xad3f60: mov             SP, fp
    //     0xad3f64: ldp             fp, lr, [SP], #0x10
    // 0xad3f68: ret
    //     0xad3f68: ret             
    // 0xad3f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3f6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3f70: b               #0xad3e80
    // 0xad3f74: SaveReg d0
    //     0xad3f74: str             q0, [SP, #-0x10]!
    // 0xad3f78: SaveReg r2
    //     0xad3f78: str             x2, [SP, #-8]!
    // 0xad3f7c: r0 = AllocateDouble()
    //     0xad3f7c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad3f80: RestoreReg r2
    //     0xad3f80: ldr             x2, [SP], #8
    // 0xad3f84: RestoreReg d0
    //     0xad3f84: ldr             q0, [SP], #0x10
    // 0xad3f88: b               #0xad3f20
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafafcc, size: 0x6c
    // 0xafafcc: EnterFrame
    //     0xafafcc: stp             fp, lr, [SP, #-0x10]!
    //     0xafafd0: mov             fp, SP
    // 0xafafd4: CheckStackOverflow
    //     0xafafd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafafd8: cmp             SP, x16
    //     0xafafdc: b.ls            #0xafb030
    // 0xafafe0: ldr             x0, [fp, #0x10]
    // 0xafafe4: LoadField: r1 = r0->field_b
    //     0xafafe4: ldur            w1, [x0, #0xb]
    // 0xafafe8: DecompressPointer r1
    //     0xafafe8: add             x1, x1, HEAP, lsl #32
    // 0xafafec: SaveReg r1
    //     0xafafec: str             x1, [SP, #-8]!
    // 0xafaff0: r0 = _getHash()
    //     0xafaff0: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xafaff4: add             SP, SP, #8
    // 0xafaff8: r16 = 1.000000
    //     0xafaff8: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xafaffc: stp             x16, x0, [SP, #-0x10]!
    // 0xafb000: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xafb000: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xafb004: r0 = hash()
    //     0xafb004: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafb008: add             SP, SP, #0x10
    // 0xafb00c: mov             x2, x0
    // 0xafb010: r0 = BoxInt64Instr(r2)
    //     0xafb010: sbfiz           x0, x2, #1, #0x1f
    //     0xafb014: cmp             x2, x0, asr #1
    //     0xafb018: b.eq            #0xafb024
    //     0xafb01c: bl              #0xd69bb8
    //     0xafb020: stur            x2, [x0, #7]
    // 0xafb024: LeaveFrame
    //     0xafb024: mov             SP, fp
    //     0xafb028: ldp             fp, lr, [SP], #0x10
    // 0xafb02c: ret
    //     0xafb02c: ret             
    // 0xafb030: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafb030: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafb034: b               #0xafafe0
  }
  _ loadBuffer(/* No info */) {
    // ** addr: 0xc32d24, size: 0x12c
    // 0xc32d24: EnterFrame
    //     0xc32d24: stp             fp, lr, [SP, #-0x10]!
    //     0xc32d28: mov             fp, SP
    // 0xc32d2c: AllocStack(0x18)
    //     0xc32d2c: sub             SP, SP, #0x18
    // 0xc32d30: CheckStackOverflow
    //     0xc32d30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc32d34: cmp             SP, x16
    //     0xc32d38: b.ls            #0xc32e48
    // 0xc32d3c: ldr             x0, [fp, #0x18]
    // 0xc32d40: r2 = Null
    //     0xc32d40: mov             x2, NULL
    // 0xc32d44: r1 = Null
    //     0xc32d44: mov             x1, NULL
    // 0xc32d48: r4 = 59
    //     0xc32d48: mov             x4, #0x3b
    // 0xc32d4c: branchIfSmi(r0, 0xc32d58)
    //     0xc32d4c: tbz             w0, #0, #0xc32d58
    // 0xc32d50: r4 = LoadClassIdInstr(r0)
    //     0xc32d50: ldur            x4, [x0, #-1]
    //     0xc32d54: ubfx            x4, x4, #0xc, #0x14
    // 0xc32d58: r17 = 4461
    //     0xc32d58: mov             x17, #0x116d
    // 0xc32d5c: cmp             x4, x17
    // 0xc32d60: b.eq            #0xc32d78
    // 0xc32d64: r8 = MemoryImage<MemoryImage>
    //     0xc32d64: add             x8, PP, #0x29, lsl #12  ; [pp+0x29238] Type: MemoryImage<MemoryImage>
    //     0xc32d68: ldr             x8, [x8, #0x238]
    // 0xc32d6c: r3 = Null
    //     0xc32d6c: add             x3, PP, #0x38, lsl #12  ; [pp+0x382c8] Null
    //     0xc32d70: ldr             x3, [x3, #0x2c8]
    // 0xc32d74: r0 = DefaultTypeTest()
    //     0xc32d74: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xc32d78: ldr             x16, [fp, #0x20]
    // 0xc32d7c: ldr             lr, [fp, #0x10]
    // 0xc32d80: stp             lr, x16, [SP, #-0x10]!
    // 0xc32d84: r0 = _loadAsync()
    //     0xc32d84: bl              #0xc32e50  ; [package:flutter/src/painting/image_provider.dart] MemoryImage::_loadAsync
    // 0xc32d88: add             SP, SP, #0x10
    // 0xc32d8c: r1 = Null
    //     0xc32d8c: mov             x1, NULL
    // 0xc32d90: r2 = 6
    //     0xc32d90: mov             x2, #6
    // 0xc32d94: stur            x0, [fp, #-8]
    // 0xc32d98: r0 = AllocateArray()
    //     0xc32d98: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc32d9c: stur            x0, [fp, #-0x10]
    // 0xc32da0: r17 = "MemoryImage("
    //     0xc32da0: add             x17, PP, #0x38, lsl #12  ; [pp+0x382d8] "MemoryImage("
    //     0xc32da4: ldr             x17, [x17, #0x2d8]
    // 0xc32da8: StoreField: r0->field_f = r17
    //     0xc32da8: stur            w17, [x0, #0xf]
    // 0xc32dac: ldr             x1, [fp, #0x18]
    // 0xc32db0: LoadField: r2 = r1->field_b
    //     0xc32db0: ldur            w2, [x1, #0xb]
    // 0xc32db4: DecompressPointer r2
    //     0xc32db4: add             x2, x2, HEAP, lsl #32
    // 0xc32db8: SaveReg r2
    //     0xc32db8: str             x2, [SP, #-8]!
    // 0xc32dbc: r0 = describeIdentity()
    //     0xc32dbc: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xc32dc0: add             SP, SP, #8
    // 0xc32dc4: ldur            x1, [fp, #-0x10]
    // 0xc32dc8: ArrayStore: r1[1] = r0  ; List_4
    //     0xc32dc8: add             x25, x1, #0x13
    //     0xc32dcc: str             w0, [x25]
    //     0xc32dd0: tbz             w0, #0, #0xc32dec
    //     0xc32dd4: ldurb           w16, [x1, #-1]
    //     0xc32dd8: ldurb           w17, [x0, #-1]
    //     0xc32ddc: and             x16, x17, x16, lsr #2
    //     0xc32de0: tst             x16, HEAP, lsr #32
    //     0xc32de4: b.eq            #0xc32dec
    //     0xc32de8: bl              #0xd67e5c
    // 0xc32dec: ldur            x0, [fp, #-0x10]
    // 0xc32df0: r17 = ")"
    //     0xc32df0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xc32df4: StoreField: r0->field_17 = r17
    //     0xc32df4: stur            w17, [x0, #0x17]
    // 0xc32df8: SaveReg r0
    //     0xc32df8: str             x0, [SP, #-8]!
    // 0xc32dfc: r0 = _interpolate()
    //     0xc32dfc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc32e00: add             SP, SP, #8
    // 0xc32e04: stur            x0, [fp, #-0x10]
    // 0xc32e08: r0 = MultiFrameImageStreamCompleter()
    //     0xc32e08: bl              #0xc30830  ; AllocateMultiFrameImageStreamCompleterStub -> MultiFrameImageStreamCompleter (size=0x60)
    // 0xc32e0c: stur            x0, [fp, #-0x18]
    // 0xc32e10: ldur            x16, [fp, #-8]
    // 0xc32e14: stp             x16, x0, [SP, #-0x10]!
    // 0xc32e18: d0 = 1.000000
    //     0xc32e18: fmov            d0, #1.00000000
    // 0xc32e1c: SaveReg d0
    //     0xc32e1c: str             d0, [SP, #-8]!
    // 0xc32e20: ldur            x16, [fp, #-0x10]
    // 0xc32e24: SaveReg r16
    //     0xc32e24: str             x16, [SP, #-8]!
    // 0xc32e28: r4 = const [0, 0x4, 0x4, 0x3, debugLabel, 0x3, null]
    //     0xc32e28: add             x4, PP, #0x38, lsl #12  ; [pp+0x382e0] List(7) [0, 0x4, 0x4, 0x3, "debugLabel", 0x3, Null]
    //     0xc32e2c: ldr             x4, [x4, #0x2e0]
    // 0xc32e30: r0 = MultiFrameImageStreamCompleter()
    //     0xc32e30: bl              #0xc30420  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter
    // 0xc32e34: add             SP, SP, #0x20
    // 0xc32e38: ldur            x0, [fp, #-0x18]
    // 0xc32e3c: LeaveFrame
    //     0xc32e3c: mov             SP, fp
    //     0xc32e40: ldp             fp, lr, [SP], #0x10
    // 0xc32e44: ret
    //     0xc32e44: ret             
    // 0xc32e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc32e48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc32e4c: b               #0xc32d3c
  }
  _ _loadAsync(/* No info */) async {
    // ** addr: 0xc32e50, size: 0x9c
    // 0xc32e50: EnterFrame
    //     0xc32e50: stp             fp, lr, [SP, #-0x10]!
    //     0xc32e54: mov             fp, SP
    // 0xc32e58: AllocStack(0x18)
    //     0xc32e58: sub             SP, SP, #0x18
    // 0xc32e5c: SetupParameters(MemoryImage<MemoryImage> this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc32e5c: stur            NULL, [fp, #-8]
    //     0xc32e60: mov             x0, #0
    //     0xc32e64: add             x1, fp, w0, sxtw #2
    //     0xc32e68: ldr             x1, [x1, #0x18]
    //     0xc32e6c: stur            x1, [fp, #-0x18]
    //     0xc32e70: add             x2, fp, w0, sxtw #2
    //     0xc32e74: ldr             x2, [x2, #0x10]
    //     0xc32e78: stur            x2, [fp, #-0x10]
    // 0xc32e7c: CheckStackOverflow
    //     0xc32e7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc32e80: cmp             SP, x16
    //     0xc32e84: b.ls            #0xc32ee0
    // 0xc32e88: InitAsync() -> Future<Codec>
    //     0xc32e88: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c998] TypeArguments: <Codec>
    //     0xc32e8c: ldr             x0, [x0, #0x998]
    //     0xc32e90: bl              #0x4b92e4
    // 0xc32e94: ldur            x0, [fp, #-0x18]
    // 0xc32e98: LoadField: r1 = r0->field_b
    //     0xc32e98: ldur            w1, [x0, #0xb]
    // 0xc32e9c: DecompressPointer r1
    //     0xc32e9c: add             x1, x1, HEAP, lsl #32
    // 0xc32ea0: SaveReg r1
    //     0xc32ea0: str             x1, [SP, #-8]!
    // 0xc32ea4: r0 = fromUint8List()
    //     0xc32ea4: bl              #0xc30c8c  ; [dart:ui] ImmutableBuffer::fromUint8List
    // 0xc32ea8: add             SP, SP, #8
    // 0xc32eac: mov             x1, x0
    // 0xc32eb0: stur            x1, [fp, #-0x18]
    // 0xc32eb4: r0 = Await()
    //     0xc32eb4: bl              #0x4b8e6c  ; AwaitStub
    // 0xc32eb8: mov             x1, x0
    // 0xc32ebc: ldur            x0, [fp, #-0x10]
    // 0xc32ec0: cmp             w0, NULL
    // 0xc32ec4: b.eq            #0xc32ee8
    // 0xc32ec8: stp             x1, x0, [SP, #-0x10]!
    // 0xc32ecc: ClosureCall
    //     0xc32ecc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc32ed0: ldur            x2, [x0, #0x1f]
    //     0xc32ed4: blr             x2
    // 0xc32ed8: add             SP, SP, #0x10
    // 0xc32edc: r0 = ReturnAsync()
    //     0xc32edc: b               #0x501858  ; ReturnAsyncStub
    // 0xc32ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc32ee0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc32ee4: b               #0xc32e88
    // 0xc32ee8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc32ee8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0xc4cdc4, size: 0x28
    // 0xc4cdc4: EnterFrame
    //     0xc4cdc4: stp             fp, lr, [SP, #-0x10]!
    //     0xc4cdc8: mov             fp, SP
    // 0xc4cdcc: r1 = <MemoryImage>
    //     0xc4cdcc: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fd18] TypeArguments: <MemoryImage>
    //     0xc4cdd0: ldr             x1, [x1, #0xd18]
    // 0xc4cdd4: r0 = SynchronousFuture()
    //     0xc4cdd4: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xc4cdd8: ldr             x1, [fp, #0x18]
    // 0xc4cddc: StoreField: r0->field_b = r1
    //     0xc4cddc: stur            w1, [x0, #0xb]
    // 0xc4cde0: LeaveFrame
    //     0xc4cde0: mov             SP, fp
    //     0xc4cde4: ldp             fp, lr, [SP], #0x10
    // 0xc4cde8: ret
    //     0xc4cde8: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6fdb8, size: 0x110
    // 0xc6fdb8: EnterFrame
    //     0xc6fdb8: stp             fp, lr, [SP, #-0x10]!
    //     0xc6fdbc: mov             fp, SP
    // 0xc6fdc0: CheckStackOverflow
    //     0xc6fdc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6fdc4: cmp             SP, x16
    //     0xc6fdc8: b.ls            #0xc6fec0
    // 0xc6fdcc: ldr             x1, [fp, #0x10]
    // 0xc6fdd0: cmp             w1, NULL
    // 0xc6fdd4: b.ne            #0xc6fde8
    // 0xc6fdd8: r0 = false
    //     0xc6fdd8: add             x0, NULL, #0x30  ; false
    // 0xc6fddc: LeaveFrame
    //     0xc6fddc: mov             SP, fp
    //     0xc6fde0: ldp             fp, lr, [SP], #0x10
    // 0xc6fde4: ret
    //     0xc6fde4: ret             
    // 0xc6fde8: r0 = 59
    //     0xc6fde8: mov             x0, #0x3b
    // 0xc6fdec: branchIfSmi(r1, 0xc6fdf8)
    //     0xc6fdec: tbz             w1, #0, #0xc6fdf8
    // 0xc6fdf0: r0 = LoadClassIdInstr(r1)
    //     0xc6fdf0: ldur            x0, [x1, #-1]
    //     0xc6fdf4: ubfx            x0, x0, #0xc, #0x14
    // 0xc6fdf8: SaveReg r1
    //     0xc6fdf8: str             x1, [SP, #-8]!
    // 0xc6fdfc: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc6fdfc: mov             x17, #0x57c5
    //     0xc6fe00: add             lr, x0, x17
    //     0xc6fe04: ldr             lr, [x21, lr, lsl #3]
    //     0xc6fe08: blr             lr
    // 0xc6fe0c: add             SP, SP, #8
    // 0xc6fe10: r1 = LoadClassIdInstr(r0)
    //     0xc6fe10: ldur            x1, [x0, #-1]
    //     0xc6fe14: ubfx            x1, x1, #0xc, #0x14
    // 0xc6fe18: r16 = MemoryImage<MemoryImage>
    //     0xc6fe18: add             x16, PP, #0x29, lsl #12  ; [pp+0x29238] Type: MemoryImage<MemoryImage>
    //     0xc6fe1c: ldr             x16, [x16, #0x238]
    // 0xc6fe20: stp             x16, x0, [SP, #-0x10]!
    // 0xc6fe24: mov             x0, x1
    // 0xc6fe28: mov             lr, x0
    // 0xc6fe2c: ldr             lr, [x21, lr, lsl #3]
    // 0xc6fe30: blr             lr
    // 0xc6fe34: add             SP, SP, #0x10
    // 0xc6fe38: tbz             w0, #4, #0xc6fe4c
    // 0xc6fe3c: r0 = false
    //     0xc6fe3c: add             x0, NULL, #0x30  ; false
    // 0xc6fe40: LeaveFrame
    //     0xc6fe40: mov             SP, fp
    //     0xc6fe44: ldp             fp, lr, [SP], #0x10
    // 0xc6fe48: ret
    //     0xc6fe48: ret             
    // 0xc6fe4c: ldr             x1, [fp, #0x10]
    // 0xc6fe50: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc6fe50: mov             x2, #0x76
    //     0xc6fe54: tbz             w1, #0, #0xc6fe64
    //     0xc6fe58: ldur            x2, [x1, #-1]
    //     0xc6fe5c: ubfx            x2, x2, #0xc, #0x14
    //     0xc6fe60: lsl             x2, x2, #1
    // 0xc6fe64: r17 = 8922
    //     0xc6fe64: mov             x17, #0x22da
    // 0xc6fe68: cmp             w2, w17
    // 0xc6fe6c: b.ne            #0xc6feb0
    // 0xc6fe70: ldr             x2, [fp, #0x18]
    // 0xc6fe74: LoadField: r3 = r1->field_b
    //     0xc6fe74: ldur            w3, [x1, #0xb]
    // 0xc6fe78: DecompressPointer r3
    //     0xc6fe78: add             x3, x3, HEAP, lsl #32
    // 0xc6fe7c: LoadField: r1 = r2->field_b
    //     0xc6fe7c: ldur            w1, [x2, #0xb]
    // 0xc6fe80: DecompressPointer r1
    //     0xc6fe80: add             x1, x1, HEAP, lsl #32
    // 0xc6fe84: cmp             w3, w1
    // 0xc6fe88: b.ne            #0xc6feb0
    // 0xc6fe8c: d0 = 1.000000
    //     0xc6fe8c: fmov            d0, #1.00000000
    // 0xc6fe90: fcmp            d0, d0
    // 0xc6fe94: b.vs            #0xc6fe9c
    // 0xc6fe98: b.eq            #0xc6fea4
    // 0xc6fe9c: r1 = false
    //     0xc6fe9c: add             x1, NULL, #0x30  ; false
    // 0xc6fea0: b               #0xc6fea8
    // 0xc6fea4: r1 = true
    //     0xc6fea4: add             x1, NULL, #0x20  ; true
    // 0xc6fea8: mov             x0, x1
    // 0xc6feac: b               #0xc6feb4
    // 0xc6feb0: r0 = false
    //     0xc6feb0: add             x0, NULL, #0x30  ; false
    // 0xc6feb4: LeaveFrame
    //     0xc6feb4: mov             SP, fp
    //     0xc6feb8: ldp             fp, lr, [SP], #0x10
    // 0xc6febc: ret
    //     0xc6febc: ret             
    // 0xc6fec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6fec0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6fec4: b               #0xc6fdcc
  }
}

// class id: 4462, size: 0x18, field offset: 0xc
//   const constructor, 
class FileImage extends ImageProvider<FileImage> {

  _ toString(/* No info */) {
    // ** addr: 0xad3d28, size: 0x140
    // 0xad3d28: EnterFrame
    //     0xad3d28: stp             fp, lr, [SP, #-0x10]!
    //     0xad3d2c: mov             fp, SP
    // 0xad3d30: AllocStack(0x8)
    //     0xad3d30: sub             SP, SP, #8
    // 0xad3d34: CheckStackOverflow
    //     0xad3d34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3d38: cmp             SP, x16
    //     0xad3d3c: b.ls            #0xad3e48
    // 0xad3d40: r1 = Null
    //     0xad3d40: mov             x1, NULL
    // 0xad3d44: r2 = 12
    //     0xad3d44: mov             x2, #0xc
    // 0xad3d48: r0 = AllocateArray()
    //     0xad3d48: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad3d4c: mov             x1, x0
    // 0xad3d50: stur            x1, [fp, #-8]
    // 0xad3d54: r17 = "FileImage"
    //     0xad3d54: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c0c8] "FileImage"
    //     0xad3d58: ldr             x17, [x17, #0xc8]
    // 0xad3d5c: StoreField: r1->field_f = r17
    //     0xad3d5c: stur            w17, [x1, #0xf]
    // 0xad3d60: r17 = "(\""
    //     0xad3d60: add             x17, PP, #0xd, lsl #12  ; [pp+0xde48] "(\""
    //     0xad3d64: ldr             x17, [x17, #0xe48]
    // 0xad3d68: StoreField: r1->field_13 = r17
    //     0xad3d68: stur            w17, [x1, #0x13]
    // 0xad3d6c: ldr             x2, [fp, #0x10]
    // 0xad3d70: LoadField: r0 = r2->field_b
    //     0xad3d70: ldur            w0, [x2, #0xb]
    // 0xad3d74: DecompressPointer r0
    //     0xad3d74: add             x0, x0, HEAP, lsl #32
    // 0xad3d78: r3 = LoadClassIdInstr(r0)
    //     0xad3d78: ldur            x3, [x0, #-1]
    //     0xad3d7c: ubfx            x3, x3, #0xc, #0x14
    // 0xad3d80: SaveReg r0
    //     0xad3d80: str             x0, [SP, #-8]!
    // 0xad3d84: mov             x0, x3
    // 0xad3d88: r0 = GDT[cid_x0 + -0xf40]()
    //     0xad3d88: sub             lr, x0, #0xf40
    //     0xad3d8c: ldr             lr, [x21, lr, lsl #3]
    //     0xad3d90: blr             lr
    // 0xad3d94: add             SP, SP, #8
    // 0xad3d98: ldur            x1, [fp, #-8]
    // 0xad3d9c: ArrayStore: r1[2] = r0  ; List_4
    //     0xad3d9c: add             x25, x1, #0x17
    //     0xad3da0: str             w0, [x25]
    //     0xad3da4: tbz             w0, #0, #0xad3dc0
    //     0xad3da8: ldurb           w16, [x1, #-1]
    //     0xad3dac: ldurb           w17, [x0, #-1]
    //     0xad3db0: and             x16, x17, x16, lsr #2
    //     0xad3db4: tst             x16, HEAP, lsr #32
    //     0xad3db8: b.eq            #0xad3dc0
    //     0xad3dbc: bl              #0xd67e5c
    // 0xad3dc0: ldur            x2, [fp, #-8]
    // 0xad3dc4: r17 = "\", scale: "
    //     0xad3dc4: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c940] "\", scale: "
    //     0xad3dc8: ldr             x17, [x17, #0x940]
    // 0xad3dcc: StoreField: r2->field_1b = r17
    //     0xad3dcc: stur            w17, [x2, #0x1b]
    // 0xad3dd0: ldr             x0, [fp, #0x10]
    // 0xad3dd4: LoadField: d0 = r0->field_f
    //     0xad3dd4: ldur            d0, [x0, #0xf]
    // 0xad3dd8: r0 = inline_Allocate_Double()
    //     0xad3dd8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad3ddc: add             x0, x0, #0x10
    //     0xad3de0: cmp             x1, x0
    //     0xad3de4: b.ls            #0xad3e50
    //     0xad3de8: str             x0, [THR, #0x60]  ; THR::top
    //     0xad3dec: sub             x0, x0, #0xf
    //     0xad3df0: mov             x1, #0xd108
    //     0xad3df4: movk            x1, #3, lsl #16
    //     0xad3df8: stur            x1, [x0, #-1]
    // 0xad3dfc: StoreField: r0->field_7 = d0
    //     0xad3dfc: stur            d0, [x0, #7]
    // 0xad3e00: mov             x1, x2
    // 0xad3e04: ArrayStore: r1[4] = r0  ; List_4
    //     0xad3e04: add             x25, x1, #0x1f
    //     0xad3e08: str             w0, [x25]
    //     0xad3e0c: tbz             w0, #0, #0xad3e28
    //     0xad3e10: ldurb           w16, [x1, #-1]
    //     0xad3e14: ldurb           w17, [x0, #-1]
    //     0xad3e18: and             x16, x17, x16, lsr #2
    //     0xad3e1c: tst             x16, HEAP, lsr #32
    //     0xad3e20: b.eq            #0xad3e28
    //     0xad3e24: bl              #0xd67e5c
    // 0xad3e28: r17 = ")"
    //     0xad3e28: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad3e2c: StoreField: r2->field_23 = r17
    //     0xad3e2c: stur            w17, [x2, #0x23]
    // 0xad3e30: SaveReg r2
    //     0xad3e30: str             x2, [SP, #-8]!
    // 0xad3e34: r0 = _interpolate()
    //     0xad3e34: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3e38: add             SP, SP, #8
    // 0xad3e3c: LeaveFrame
    //     0xad3e3c: mov             SP, fp
    //     0xad3e40: ldp             fp, lr, [SP], #0x10
    // 0xad3e44: ret
    //     0xad3e44: ret             
    // 0xad3e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3e48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3e4c: b               #0xad3d40
    // 0xad3e50: SaveReg d0
    //     0xad3e50: str             q0, [SP, #-0x10]!
    // 0xad3e54: SaveReg r2
    //     0xad3e54: str             x2, [SP, #-8]!
    // 0xad3e58: r0 = AllocateDouble()
    //     0xad3e58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad3e5c: RestoreReg r2
    //     0xad3e5c: ldr             x2, [SP], #8
    // 0xad3e60: RestoreReg d0
    //     0xad3e60: ldr             q0, [SP], #0x10
    // 0xad3e64: b               #0xad3dfc
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafaf50, size: 0x7c
    // 0xafaf50: EnterFrame
    //     0xafaf50: stp             fp, lr, [SP, #-0x10]!
    //     0xafaf54: mov             fp, SP
    // 0xafaf58: CheckStackOverflow
    //     0xafaf58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafaf5c: cmp             SP, x16
    //     0xafaf60: b.ls            #0xafafc4
    // 0xafaf64: ldr             x0, [fp, #0x10]
    // 0xafaf68: LoadField: r1 = r0->field_b
    //     0xafaf68: ldur            w1, [x0, #0xb]
    // 0xafaf6c: DecompressPointer r1
    //     0xafaf6c: add             x1, x1, HEAP, lsl #32
    // 0xafaf70: r0 = LoadClassIdInstr(r1)
    //     0xafaf70: ldur            x0, [x1, #-1]
    //     0xafaf74: ubfx            x0, x0, #0xc, #0x14
    // 0xafaf78: SaveReg r1
    //     0xafaf78: str             x1, [SP, #-8]!
    // 0xafaf7c: r0 = GDT[cid_x0 + -0xf40]()
    //     0xafaf7c: sub             lr, x0, #0xf40
    //     0xafaf80: ldr             lr, [x21, lr, lsl #3]
    //     0xafaf84: blr             lr
    // 0xafaf88: add             SP, SP, #8
    // 0xafaf8c: r16 = 1.000000
    //     0xafaf8c: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xafaf90: stp             x16, x0, [SP, #-0x10]!
    // 0xafaf94: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xafaf94: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xafaf98: r0 = hash()
    //     0xafaf98: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafaf9c: add             SP, SP, #0x10
    // 0xafafa0: mov             x2, x0
    // 0xafafa4: r0 = BoxInt64Instr(r2)
    //     0xafafa4: sbfiz           x0, x2, #1, #0x1f
    //     0xafafa8: cmp             x2, x0, asr #1
    //     0xafafac: b.eq            #0xafafb8
    //     0xafafb0: bl              #0xd69bb8
    //     0xafafb4: stur            x2, [x0, #7]
    // 0xafafb8: LeaveFrame
    //     0xafafb8: mov             SP, fp
    //     0xafafbc: ldp             fp, lr, [SP], #0x10
    // 0xafafc0: ret
    //     0xafafc0: ret             
    // 0xafafc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafafc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafafc8: b               #0xafaf64
  }
  _ loadBuffer(/* No info */) {
    // ** addr: 0xc323ec, size: 0x11c
    // 0xc323ec: EnterFrame
    //     0xc323ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc323f0: mov             fp, SP
    // 0xc323f4: AllocStack(0x20)
    //     0xc323f4: sub             SP, SP, #0x20
    // 0xc323f8: CheckStackOverflow
    //     0xc323f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc323fc: cmp             SP, x16
    //     0xc32400: b.ls            #0xc32500
    // 0xc32404: r1 = 1
    //     0xc32404: mov             x1, #1
    // 0xc32408: r0 = AllocateContext()
    //     0xc32408: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc3240c: mov             x4, x0
    // 0xc32410: ldr             x3, [fp, #0x20]
    // 0xc32414: stur            x4, [fp, #-8]
    // 0xc32418: StoreField: r4->field_f = r3
    //     0xc32418: stur            w3, [x4, #0xf]
    // 0xc3241c: ldr             x0, [fp, #0x18]
    // 0xc32420: r2 = Null
    //     0xc32420: mov             x2, NULL
    // 0xc32424: r1 = Null
    //     0xc32424: mov             x1, NULL
    // 0xc32428: r4 = 59
    //     0xc32428: mov             x4, #0x3b
    // 0xc3242c: branchIfSmi(r0, 0xc32438)
    //     0xc3242c: tbz             w0, #0, #0xc32438
    // 0xc32430: r4 = LoadClassIdInstr(r0)
    //     0xc32430: ldur            x4, [x0, #-1]
    //     0xc32434: ubfx            x4, x4, #0xc, #0x14
    // 0xc32438: r17 = 4462
    //     0xc32438: mov             x17, #0x116e
    // 0xc3243c: cmp             x4, x17
    // 0xc32440: b.eq            #0xc32458
    // 0xc32444: r8 = FileImage<FileImage>
    //     0xc32444: add             x8, PP, #0x4c, lsl #12  ; [pp+0x4c0d0] Type: FileImage<FileImage>
    //     0xc32448: ldr             x8, [x8, #0xd0]
    // 0xc3244c: r3 = Null
    //     0xc3244c: add             x3, PP, #0x4c, lsl #12  ; [pp+0x4c0d8] Null
    //     0xc32450: ldr             x3, [x3, #0xd8]
    // 0xc32454: r0 = DefaultTypeTest()
    //     0xc32454: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xc32458: ldr             x16, [fp, #0x20]
    // 0xc3245c: ldr             lr, [fp, #0x18]
    // 0xc32460: stp             lr, x16, [SP, #-0x10]!
    // 0xc32464: ldr             x16, [fp, #0x10]
    // 0xc32468: SaveReg r16
    //     0xc32468: str             x16, [SP, #-8]!
    // 0xc3246c: r0 = _loadAsync()
    //     0xc3246c: bl              #0xc32508  ; [package:flutter/src/painting/image_provider.dart] FileImage::_loadAsync
    // 0xc32470: add             SP, SP, #0x18
    // 0xc32474: mov             x1, x0
    // 0xc32478: ldr             x0, [fp, #0x18]
    // 0xc3247c: stur            x1, [fp, #-0x10]
    // 0xc32480: LoadField: r2 = r0->field_b
    //     0xc32480: ldur            w2, [x0, #0xb]
    // 0xc32484: DecompressPointer r2
    //     0xc32484: add             x2, x2, HEAP, lsl #32
    // 0xc32488: r0 = LoadClassIdInstr(r2)
    //     0xc32488: ldur            x0, [x2, #-1]
    //     0xc3248c: ubfx            x0, x0, #0xc, #0x14
    // 0xc32490: SaveReg r2
    //     0xc32490: str             x2, [SP, #-8]!
    // 0xc32494: r0 = GDT[cid_x0 + -0xf40]()
    //     0xc32494: sub             lr, x0, #0xf40
    //     0xc32498: ldr             lr, [x21, lr, lsl #3]
    //     0xc3249c: blr             lr
    // 0xc324a0: add             SP, SP, #8
    // 0xc324a4: ldur            x2, [fp, #-8]
    // 0xc324a8: r1 = Function '<anonymous closure>':.
    //     0xc324a8: add             x1, PP, #0x4c, lsl #12  ; [pp+0x4c0e8] AnonymousClosure: (0xc32c00), in [package:flutter/src/painting/image_provider.dart] FileImage::loadBuffer (0xc323ec)
    //     0xc324ac: ldr             x1, [x1, #0xe8]
    // 0xc324b0: stur            x0, [fp, #-8]
    // 0xc324b4: r0 = AllocateClosure()
    //     0xc324b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc324b8: stur            x0, [fp, #-0x18]
    // 0xc324bc: r0 = MultiFrameImageStreamCompleter()
    //     0xc324bc: bl              #0xc30830  ; AllocateMultiFrameImageStreamCompleterStub -> MultiFrameImageStreamCompleter (size=0x60)
    // 0xc324c0: stur            x0, [fp, #-0x20]
    // 0xc324c4: ldur            x16, [fp, #-0x10]
    // 0xc324c8: stp             x16, x0, [SP, #-0x10]!
    // 0xc324cc: d0 = 1.000000
    //     0xc324cc: fmov            d0, #1.00000000
    // 0xc324d0: SaveReg d0
    //     0xc324d0: str             d0, [SP, #-8]!
    // 0xc324d4: ldur            x16, [fp, #-8]
    // 0xc324d8: ldur            lr, [fp, #-0x18]
    // 0xc324dc: stp             lr, x16, [SP, #-0x10]!
    // 0xc324e0: r4 = const [0, 0x5, 0x5, 0x3, debugLabel, 0x3, informationCollector, 0x4, null]
    //     0xc324e0: add             x4, PP, #0x38, lsl #12  ; [pp+0x382f8] List(9) [0, 0x5, 0x5, 0x3, "debugLabel", 0x3, "informationCollector", 0x4, Null]
    //     0xc324e4: ldr             x4, [x4, #0x2f8]
    // 0xc324e8: r0 = MultiFrameImageStreamCompleter()
    //     0xc324e8: bl              #0xc30420  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter
    // 0xc324ec: add             SP, SP, #0x28
    // 0xc324f0: ldur            x0, [fp, #-0x20]
    // 0xc324f4: LeaveFrame
    //     0xc324f4: mov             SP, fp
    //     0xc324f8: ldp             fp, lr, [SP], #0x10
    // 0xc324fc: ret
    //     0xc324fc: ret             
    // 0xc32500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc32500: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc32504: b               #0xc32404
  }
  _ _loadAsync(/* No info */) async {
    // ** addr: 0xc32508, size: 0x248
    // 0xc32508: EnterFrame
    //     0xc32508: stp             fp, lr, [SP, #-0x10]!
    //     0xc3250c: mov             fp, SP
    // 0xc32510: AllocStack(0x30)
    //     0xc32510: sub             SP, SP, #0x30
    // 0xc32514: SetupParameters(FileImage<FileImage> this /* r1, fp-0x20 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xc32514: stur            NULL, [fp, #-8]
    //     0xc32518: mov             x0, #0
    //     0xc3251c: add             x1, fp, w0, sxtw #2
    //     0xc32520: ldr             x1, [x1, #0x20]
    //     0xc32524: stur            x1, [fp, #-0x20]
    //     0xc32528: add             x2, fp, w0, sxtw #2
    //     0xc3252c: ldr             x2, [x2, #0x18]
    //     0xc32530: stur            x2, [fp, #-0x18]
    //     0xc32534: add             x3, fp, w0, sxtw #2
    //     0xc32538: ldr             x3, [x3, #0x10]
    //     0xc3253c: stur            x3, [fp, #-0x10]
    // 0xc32540: CheckStackOverflow
    //     0xc32540: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc32544: cmp             SP, x16
    //     0xc32548: b.ls            #0xc32734
    // 0xc3254c: InitAsync() -> Future<Codec>
    //     0xc3254c: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c998] TypeArguments: <Codec>
    //     0xc32550: ldr             x0, [x0, #0x998]
    //     0xc32554: bl              #0x4b92e4
    // 0xc32558: ldur            x1, [fp, #-0x20]
    // 0xc3255c: LoadField: r2 = r1->field_b
    //     0xc3255c: ldur            w2, [x1, #0xb]
    // 0xc32560: DecompressPointer r2
    //     0xc32560: add             x2, x2, HEAP, lsl #32
    // 0xc32564: stur            x2, [fp, #-0x28]
    // 0xc32568: r0 = LoadClassIdInstr(r2)
    //     0xc32568: ldur            x0, [x2, #-1]
    //     0xc3256c: ubfx            x0, x0, #0xc, #0x14
    // 0xc32570: SaveReg r2
    //     0xc32570: str             x2, [SP, #-8]!
    // 0xc32574: r0 = GDT[cid_x0 + -0xf7a]()
    //     0xc32574: sub             lr, x0, #0xf7a
    //     0xc32578: ldr             lr, [x21, lr, lsl #3]
    //     0xc3257c: blr             lr
    // 0xc32580: add             SP, SP, #8
    // 0xc32584: mov             x1, x0
    // 0xc32588: stur            x1, [fp, #-0x30]
    // 0xc3258c: r0 = Await()
    //     0xc3258c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc32590: cbz             w0, #0xc326ac
    // 0xc32594: ldur            x0, [fp, #-0x28]
    // 0xc32598: SaveReg r0
    //     0xc32598: str             x0, [SP, #-8]!
    // 0xc3259c: r0 = runtimeType()
    //     0xc3259c: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc325a0: add             SP, SP, #8
    // 0xc325a4: r1 = LoadClassIdInstr(r0)
    //     0xc325a4: ldur            x1, [x0, #-1]
    //     0xc325a8: ubfx            x1, x1, #0xc, #0x14
    // 0xc325ac: r16 = File
    //     0xc325ac: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c0f8] Type: File
    //     0xc325b0: ldr             x16, [x16, #0xf8]
    // 0xc325b4: stp             x16, x0, [SP, #-0x10]!
    // 0xc325b8: mov             x0, x1
    // 0xc325bc: mov             lr, x0
    // 0xc325c0: ldr             lr, [x21, lr, lsl #3]
    // 0xc325c4: blr             lr
    // 0xc325c8: add             SP, SP, #0x10
    // 0xc325cc: tbnz            w0, #4, #0xc32638
    // 0xc325d0: ldur            x1, [fp, #-0x10]
    // 0xc325d4: ldur            x0, [fp, #-0x28]
    // 0xc325d8: r2 = LoadClassIdInstr(r0)
    //     0xc325d8: ldur            x2, [x0, #-1]
    //     0xc325dc: ubfx            x2, x2, #0xc, #0x14
    // 0xc325e0: SaveReg r0
    //     0xc325e0: str             x0, [SP, #-8]!
    // 0xc325e4: mov             x0, x2
    // 0xc325e8: r0 = GDT[cid_x0 + -0xf40]()
    //     0xc325e8: sub             lr, x0, #0xf40
    //     0xc325ec: ldr             lr, [x21, lr, lsl #3]
    //     0xc325f0: blr             lr
    // 0xc325f4: add             SP, SP, #8
    // 0xc325f8: SaveReg r0
    //     0xc325f8: str             x0, [SP, #-8]!
    // 0xc325fc: r0 = fromFilePath()
    //     0xc325fc: bl              #0xc32750  ; [dart:ui] ImmutableBuffer::fromFilePath
    // 0xc32600: add             SP, SP, #8
    // 0xc32604: mov             x1, x0
    // 0xc32608: stur            x1, [fp, #-0x18]
    // 0xc3260c: r0 = Await()
    //     0xc3260c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc32610: ldur            x1, [fp, #-0x10]
    // 0xc32614: cmp             w1, NULL
    // 0xc32618: b.eq            #0xc3273c
    // 0xc3261c: stp             x0, x1, [SP, #-0x10]!
    // 0xc32620: mov             x0, x1
    // 0xc32624: ClosureCall
    //     0xc32624: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc32628: ldur            x2, [x0, #0x1f]
    //     0xc3262c: blr             x2
    // 0xc32630: add             SP, SP, #0x10
    // 0xc32634: r0 = ReturnAsync()
    //     0xc32634: b               #0x501858  ; ReturnAsyncStub
    // 0xc32638: ldur            x1, [fp, #-0x10]
    // 0xc3263c: ldur            x0, [fp, #-0x28]
    // 0xc32640: r2 = LoadClassIdInstr(r0)
    //     0xc32640: ldur            x2, [x0, #-1]
    //     0xc32644: ubfx            x2, x2, #0xc, #0x14
    // 0xc32648: SaveReg r0
    //     0xc32648: str             x0, [SP, #-8]!
    // 0xc3264c: mov             x0, x2
    // 0xc32650: r0 = GDT[cid_x0 + -0xfa9]()
    //     0xc32650: sub             lr, x0, #0xfa9
    //     0xc32654: ldr             lr, [x21, lr, lsl #3]
    //     0xc32658: blr             lr
    // 0xc3265c: add             SP, SP, #8
    // 0xc32660: mov             x1, x0
    // 0xc32664: stur            x1, [fp, #-0x18]
    // 0xc32668: r0 = Await()
    //     0xc32668: bl              #0x4b8e6c  ; AwaitStub
    // 0xc3266c: SaveReg r0
    //     0xc3266c: str             x0, [SP, #-8]!
    // 0xc32670: r0 = fromUint8List()
    //     0xc32670: bl              #0xc30c8c  ; [dart:ui] ImmutableBuffer::fromUint8List
    // 0xc32674: add             SP, SP, #8
    // 0xc32678: mov             x1, x0
    // 0xc3267c: stur            x1, [fp, #-0x18]
    // 0xc32680: r0 = Await()
    //     0xc32680: bl              #0x4b8e6c  ; AwaitStub
    // 0xc32684: mov             x1, x0
    // 0xc32688: ldur            x0, [fp, #-0x10]
    // 0xc3268c: cmp             w0, NULL
    // 0xc32690: b.eq            #0xc32740
    // 0xc32694: stp             x1, x0, [SP, #-0x10]!
    // 0xc32698: ClosureCall
    //     0xc32698: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc3269c: ldur            x2, [x0, #0x1f]
    //     0xc326a0: blr             x2
    // 0xc326a4: add             SP, SP, #0x10
    // 0xc326a8: r0 = ReturnAsync()
    //     0xc326a8: b               #0x501858  ; ReturnAsyncStub
    // 0xc326ac: ldur            x0, [fp, #-0x28]
    // 0xc326b0: r1 = LoadStaticField(0xe6c)
    //     0xc326b0: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xc326b4: ldr             x1, [x1, #0x1cd8]
    // 0xc326b8: cmp             w1, NULL
    // 0xc326bc: b.eq            #0xc32744
    // 0xc326c0: LoadField: r2 = r1->field_a7
    //     0xc326c0: ldur            w2, [x1, #0xa7]
    // 0xc326c4: DecompressPointer r2
    //     0xc326c4: add             x2, x2, HEAP, lsl #32
    // 0xc326c8: r16 = Sentinel
    //     0xc326c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc326cc: cmp             w2, w16
    // 0xc326d0: b.eq            #0xc32748
    // 0xc326d4: ldur            x16, [fp, #-0x18]
    // 0xc326d8: stp             x16, x2, [SP, #-0x10]!
    // 0xc326dc: r0 = evict()
    //     0xc326dc: bl              #0xc316b4  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0xc326e0: add             SP, SP, #0x10
    // 0xc326e4: r1 = Null
    //     0xc326e4: mov             x1, NULL
    // 0xc326e8: r2 = 4
    //     0xc326e8: mov             x2, #4
    // 0xc326ec: r0 = AllocateArray()
    //     0xc326ec: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc326f0: mov             x1, x0
    // 0xc326f4: ldur            x0, [fp, #-0x28]
    // 0xc326f8: StoreField: r1->field_f = r0
    //     0xc326f8: stur            w0, [x1, #0xf]
    // 0xc326fc: r17 = " is empty and cannot be loaded as an image."
    //     0xc326fc: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c100] " is empty and cannot be loaded as an image."
    //     0xc32700: ldr             x17, [x17, #0x100]
    // 0xc32704: StoreField: r1->field_13 = r17
    //     0xc32704: stur            w17, [x1, #0x13]
    // 0xc32708: SaveReg r1
    //     0xc32708: str             x1, [SP, #-8]!
    // 0xc3270c: r0 = _interpolate()
    //     0xc3270c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc32710: add             SP, SP, #8
    // 0xc32714: stur            x0, [fp, #-0x18]
    // 0xc32718: r0 = StateError()
    //     0xc32718: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc3271c: mov             x1, x0
    // 0xc32720: ldur            x0, [fp, #-0x18]
    // 0xc32724: StoreField: r1->field_b = r0
    //     0xc32724: stur            w0, [x1, #0xb]
    // 0xc32728: mov             x0, x1
    // 0xc3272c: r0 = Throw()
    //     0xc3272c: bl              #0xd67e38  ; ThrowStub
    // 0xc32730: brk             #0
    // 0xc32734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc32734: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc32738: b               #0xc3254c
    // 0xc3273c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc3273c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xc32740: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc32740: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xc32744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc32744: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc32748: r9 = _imageCache
    //     0xc32748: ldr             x9, [PP, #0x4f50]  ; [pp+0x4f50] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@423399801._imageCache@846047248>: late (offset: 0xa8)
    // 0xc3274c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc3274c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0xc32c00, size: 0x124
    // 0xc32c00: EnterFrame
    //     0xc32c00: stp             fp, lr, [SP, #-0x10]!
    //     0xc32c04: mov             fp, SP
    // 0xc32c08: AllocStack(0x10)
    //     0xc32c08: sub             SP, SP, #0x10
    // 0xc32c0c: SetupParameters()
    //     0xc32c0c: ldr             x0, [fp, #0x10]
    //     0xc32c10: ldur            w3, [x0, #0x17]
    //     0xc32c14: add             x3, x3, HEAP, lsl #32
    //     0xc32c18: stur            x3, [fp, #-8]
    // 0xc32c1c: CheckStackOverflow
    //     0xc32c1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc32c20: cmp             SP, x16
    //     0xc32c24: b.ls            #0xc32d1c
    // 0xc32c28: r1 = Null
    //     0xc32c28: mov             x1, NULL
    // 0xc32c2c: r2 = 4
    //     0xc32c2c: mov             x2, #4
    // 0xc32c30: r0 = AllocateArray()
    //     0xc32c30: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc32c34: mov             x1, x0
    // 0xc32c38: stur            x1, [fp, #-0x10]
    // 0xc32c3c: r17 = "Path: "
    //     0xc32c3c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4c0f0] "Path: "
    //     0xc32c40: ldr             x17, [x17, #0xf0]
    // 0xc32c44: StoreField: r1->field_f = r17
    //     0xc32c44: stur            w17, [x1, #0xf]
    // 0xc32c48: ldur            x0, [fp, #-8]
    // 0xc32c4c: LoadField: r2 = r0->field_f
    //     0xc32c4c: ldur            w2, [x0, #0xf]
    // 0xc32c50: DecompressPointer r2
    //     0xc32c50: add             x2, x2, HEAP, lsl #32
    // 0xc32c54: LoadField: r0 = r2->field_b
    //     0xc32c54: ldur            w0, [x2, #0xb]
    // 0xc32c58: DecompressPointer r0
    //     0xc32c58: add             x0, x0, HEAP, lsl #32
    // 0xc32c5c: r2 = LoadClassIdInstr(r0)
    //     0xc32c5c: ldur            x2, [x0, #-1]
    //     0xc32c60: ubfx            x2, x2, #0xc, #0x14
    // 0xc32c64: SaveReg r0
    //     0xc32c64: str             x0, [SP, #-8]!
    // 0xc32c68: mov             x0, x2
    // 0xc32c6c: r0 = GDT[cid_x0 + -0xf40]()
    //     0xc32c6c: sub             lr, x0, #0xf40
    //     0xc32c70: ldr             lr, [x21, lr, lsl #3]
    //     0xc32c74: blr             lr
    // 0xc32c78: add             SP, SP, #8
    // 0xc32c7c: ldur            x1, [fp, #-0x10]
    // 0xc32c80: ArrayStore: r1[1] = r0  ; List_4
    //     0xc32c80: add             x25, x1, #0x13
    //     0xc32c84: str             w0, [x25]
    //     0xc32c88: tbz             w0, #0, #0xc32ca4
    //     0xc32c8c: ldurb           w16, [x1, #-1]
    //     0xc32c90: ldurb           w17, [x0, #-1]
    //     0xc32c94: and             x16, x17, x16, lsr #2
    //     0xc32c98: tst             x16, HEAP, lsr #32
    //     0xc32c9c: b.eq            #0xc32ca4
    //     0xc32ca0: bl              #0xd67e5c
    // 0xc32ca4: ldur            x16, [fp, #-0x10]
    // 0xc32ca8: SaveReg r16
    //     0xc32ca8: str             x16, [SP, #-8]!
    // 0xc32cac: r0 = _interpolate()
    //     0xc32cac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc32cb0: add             SP, SP, #8
    // 0xc32cb4: r1 = <List<Object>>
    //     0xc32cb4: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xc32cb8: stur            x0, [fp, #-8]
    // 0xc32cbc: r0 = ErrorDescription()
    //     0xc32cbc: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xc32cc0: stur            x0, [fp, #-0x10]
    // 0xc32cc4: ldur            x16, [fp, #-8]
    // 0xc32cc8: stp             x16, x0, [SP, #-0x10]!
    // 0xc32ccc: r16 = Instance_DiagnosticLevel
    //     0xc32ccc: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xc32cd0: SaveReg r16
    //     0xc32cd0: str             x16, [SP, #-8]!
    // 0xc32cd4: r0 = _ErrorDiagnostic()
    //     0xc32cd4: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xc32cd8: add             SP, SP, #0x18
    // 0xc32cdc: r1 = Null
    //     0xc32cdc: mov             x1, NULL
    // 0xc32ce0: r2 = 2
    //     0xc32ce0: mov             x2, #2
    // 0xc32ce4: r0 = AllocateArray()
    //     0xc32ce4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc32ce8: mov             x2, x0
    // 0xc32cec: ldur            x0, [fp, #-0x10]
    // 0xc32cf0: stur            x2, [fp, #-8]
    // 0xc32cf4: StoreField: r2->field_f = r0
    //     0xc32cf4: stur            w0, [x2, #0xf]
    // 0xc32cf8: r1 = <DiagnosticsNode>
    //     0xc32cf8: ldr             x1, [PP, #0x3930]  ; [pp+0x3930] TypeArguments: <DiagnosticsNode>
    // 0xc32cfc: r0 = AllocateGrowableArray()
    //     0xc32cfc: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xc32d00: ldur            x1, [fp, #-8]
    // 0xc32d04: StoreField: r0->field_f = r1
    //     0xc32d04: stur            w1, [x0, #0xf]
    // 0xc32d08: r1 = 2
    //     0xc32d08: mov             x1, #2
    // 0xc32d0c: StoreField: r0->field_b = r1
    //     0xc32d0c: stur            w1, [x0, #0xb]
    // 0xc32d10: LeaveFrame
    //     0xc32d10: mov             SP, fp
    //     0xc32d14: ldp             fp, lr, [SP], #0x10
    // 0xc32d18: ret
    //     0xc32d18: ret             
    // 0xc32d1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc32d1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc32d20: b               #0xc32c28
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0xc4cd9c, size: 0x28
    // 0xc4cd9c: EnterFrame
    //     0xc4cd9c: stp             fp, lr, [SP, #-0x10]!
    //     0xc4cda0: mov             fp, SP
    // 0xc4cda4: r1 = <FileImage>
    //     0xc4cda4: add             x1, PP, #0x3e, lsl #12  ; [pp+0x3e3d0] TypeArguments: <FileImage>
    //     0xc4cda8: ldr             x1, [x1, #0x3d0]
    // 0xc4cdac: r0 = SynchronousFuture()
    //     0xc4cdac: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xc4cdb0: ldr             x1, [fp, #0x18]
    // 0xc4cdb4: StoreField: r0->field_b = r1
    //     0xc4cdb4: stur            w1, [x0, #0xb]
    // 0xc4cdb8: LeaveFrame
    //     0xc4cdb8: mov             SP, fp
    //     0xc4cdbc: ldp             fp, lr, [SP], #0x10
    // 0xc4cdc0: ret
    //     0xc4cdc0: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6fc3c, size: 0x17c
    // 0xc6fc3c: EnterFrame
    //     0xc6fc3c: stp             fp, lr, [SP, #-0x10]!
    //     0xc6fc40: mov             fp, SP
    // 0xc6fc44: AllocStack(0x8)
    //     0xc6fc44: sub             SP, SP, #8
    // 0xc6fc48: CheckStackOverflow
    //     0xc6fc48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6fc4c: cmp             SP, x16
    //     0xc6fc50: b.ls            #0xc6fdb0
    // 0xc6fc54: ldr             x1, [fp, #0x10]
    // 0xc6fc58: cmp             w1, NULL
    // 0xc6fc5c: b.ne            #0xc6fc70
    // 0xc6fc60: r0 = false
    //     0xc6fc60: add             x0, NULL, #0x30  ; false
    // 0xc6fc64: LeaveFrame
    //     0xc6fc64: mov             SP, fp
    //     0xc6fc68: ldp             fp, lr, [SP], #0x10
    // 0xc6fc6c: ret
    //     0xc6fc6c: ret             
    // 0xc6fc70: r0 = 59
    //     0xc6fc70: mov             x0, #0x3b
    // 0xc6fc74: branchIfSmi(r1, 0xc6fc80)
    //     0xc6fc74: tbz             w1, #0, #0xc6fc80
    // 0xc6fc78: r0 = LoadClassIdInstr(r1)
    //     0xc6fc78: ldur            x0, [x1, #-1]
    //     0xc6fc7c: ubfx            x0, x0, #0xc, #0x14
    // 0xc6fc80: SaveReg r1
    //     0xc6fc80: str             x1, [SP, #-8]!
    // 0xc6fc84: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc6fc84: mov             x17, #0x57c5
    //     0xc6fc88: add             lr, x0, x17
    //     0xc6fc8c: ldr             lr, [x21, lr, lsl #3]
    //     0xc6fc90: blr             lr
    // 0xc6fc94: add             SP, SP, #8
    // 0xc6fc98: r1 = LoadClassIdInstr(r0)
    //     0xc6fc98: ldur            x1, [x0, #-1]
    //     0xc6fc9c: ubfx            x1, x1, #0xc, #0x14
    // 0xc6fca0: r16 = FileImage<FileImage>
    //     0xc6fca0: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c0d0] Type: FileImage<FileImage>
    //     0xc6fca4: ldr             x16, [x16, #0xd0]
    // 0xc6fca8: stp             x16, x0, [SP, #-0x10]!
    // 0xc6fcac: mov             x0, x1
    // 0xc6fcb0: mov             lr, x0
    // 0xc6fcb4: ldr             lr, [x21, lr, lsl #3]
    // 0xc6fcb8: blr             lr
    // 0xc6fcbc: add             SP, SP, #0x10
    // 0xc6fcc0: tbz             w0, #4, #0xc6fcd4
    // 0xc6fcc4: r0 = false
    //     0xc6fcc4: add             x0, NULL, #0x30  ; false
    // 0xc6fcc8: LeaveFrame
    //     0xc6fcc8: mov             SP, fp
    //     0xc6fccc: ldp             fp, lr, [SP], #0x10
    // 0xc6fcd0: ret
    //     0xc6fcd0: ret             
    // 0xc6fcd4: ldr             x0, [fp, #0x10]
    // 0xc6fcd8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6fcd8: mov             x1, #0x76
    //     0xc6fcdc: tbz             w0, #0, #0xc6fcec
    //     0xc6fce0: ldur            x1, [x0, #-1]
    //     0xc6fce4: ubfx            x1, x1, #0xc, #0x14
    //     0xc6fce8: lsl             x1, x1, #1
    // 0xc6fcec: r17 = 8924
    //     0xc6fcec: mov             x17, #0x22dc
    // 0xc6fcf0: cmp             w1, w17
    // 0xc6fcf4: b.ne            #0xc6fda0
    // 0xc6fcf8: ldr             x1, [fp, #0x18]
    // 0xc6fcfc: LoadField: r2 = r0->field_b
    //     0xc6fcfc: ldur            w2, [x0, #0xb]
    // 0xc6fd00: DecompressPointer r2
    //     0xc6fd00: add             x2, x2, HEAP, lsl #32
    // 0xc6fd04: r0 = LoadClassIdInstr(r2)
    //     0xc6fd04: ldur            x0, [x2, #-1]
    //     0xc6fd08: ubfx            x0, x0, #0xc, #0x14
    // 0xc6fd0c: SaveReg r2
    //     0xc6fd0c: str             x2, [SP, #-8]!
    // 0xc6fd10: r0 = GDT[cid_x0 + -0xf40]()
    //     0xc6fd10: sub             lr, x0, #0xf40
    //     0xc6fd14: ldr             lr, [x21, lr, lsl #3]
    //     0xc6fd18: blr             lr
    // 0xc6fd1c: add             SP, SP, #8
    // 0xc6fd20: mov             x1, x0
    // 0xc6fd24: ldr             x0, [fp, #0x18]
    // 0xc6fd28: stur            x1, [fp, #-8]
    // 0xc6fd2c: LoadField: r2 = r0->field_b
    //     0xc6fd2c: ldur            w2, [x0, #0xb]
    // 0xc6fd30: DecompressPointer r2
    //     0xc6fd30: add             x2, x2, HEAP, lsl #32
    // 0xc6fd34: r0 = LoadClassIdInstr(r2)
    //     0xc6fd34: ldur            x0, [x2, #-1]
    //     0xc6fd38: ubfx            x0, x0, #0xc, #0x14
    // 0xc6fd3c: SaveReg r2
    //     0xc6fd3c: str             x2, [SP, #-8]!
    // 0xc6fd40: r0 = GDT[cid_x0 + -0xf40]()
    //     0xc6fd40: sub             lr, x0, #0xf40
    //     0xc6fd44: ldr             lr, [x21, lr, lsl #3]
    //     0xc6fd48: blr             lr
    // 0xc6fd4c: add             SP, SP, #8
    // 0xc6fd50: mov             x1, x0
    // 0xc6fd54: ldur            x0, [fp, #-8]
    // 0xc6fd58: r2 = LoadClassIdInstr(r0)
    //     0xc6fd58: ldur            x2, [x0, #-1]
    //     0xc6fd5c: ubfx            x2, x2, #0xc, #0x14
    // 0xc6fd60: stp             x1, x0, [SP, #-0x10]!
    // 0xc6fd64: mov             x0, x2
    // 0xc6fd68: mov             lr, x0
    // 0xc6fd6c: ldr             lr, [x21, lr, lsl #3]
    // 0xc6fd70: blr             lr
    // 0xc6fd74: add             SP, SP, #0x10
    // 0xc6fd78: tbnz            w0, #4, #0xc6fda0
    // 0xc6fd7c: d0 = 1.000000
    //     0xc6fd7c: fmov            d0, #1.00000000
    // 0xc6fd80: fcmp            d0, d0
    // 0xc6fd84: b.vs            #0xc6fd8c
    // 0xc6fd88: b.eq            #0xc6fd94
    // 0xc6fd8c: r1 = false
    //     0xc6fd8c: add             x1, NULL, #0x30  ; false
    // 0xc6fd90: b               #0xc6fd98
    // 0xc6fd94: r1 = true
    //     0xc6fd94: add             x1, NULL, #0x20  ; true
    // 0xc6fd98: mov             x0, x1
    // 0xc6fd9c: b               #0xc6fda4
    // 0xc6fda0: r0 = false
    //     0xc6fda0: add             x0, NULL, #0x30  ; false
    // 0xc6fda4: LeaveFrame
    //     0xc6fda4: mov             SP, fp
    //     0xc6fda8: ldp             fp, lr, [SP], #0x10
    // 0xc6fdac: ret
    //     0xc6fdac: ret             
    // 0xc6fdb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6fdb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6fdb4: b               #0xc6fc54
  }
}

// class id: 4464, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class AssetBundleImageProvider extends ImageProvider<AssetBundleImageKey> {

  _ loadBuffer(/* No info */) {
    // ** addr: 0xc31b20, size: 0xd4
    // 0xc31b20: EnterFrame
    //     0xc31b20: stp             fp, lr, [SP, #-0x10]!
    //     0xc31b24: mov             fp, SP
    // 0xc31b28: AllocStack(0x20)
    //     0xc31b28: sub             SP, SP, #0x20
    // 0xc31b2c: CheckStackOverflow
    //     0xc31b2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc31b30: cmp             SP, x16
    //     0xc31b34: b.ls            #0xc31bec
    // 0xc31b38: ldr             x0, [fp, #0x18]
    // 0xc31b3c: r2 = Null
    //     0xc31b3c: mov             x2, NULL
    // 0xc31b40: r1 = Null
    //     0xc31b40: mov             x1, NULL
    // 0xc31b44: r4 = 59
    //     0xc31b44: mov             x4, #0x3b
    // 0xc31b48: branchIfSmi(r0, 0xc31b54)
    //     0xc31b48: tbz             w0, #0, #0xc31b54
    // 0xc31b4c: r4 = LoadClassIdInstr(r0)
    //     0xc31b4c: ldur            x4, [x0, #-1]
    //     0xc31b50: ubfx            x4, x4, #0xc, #0x14
    // 0xc31b54: cmp             x4, #0x827
    // 0xc31b58: b.eq            #0xc31b70
    // 0xc31b5c: r8 = AssetBundleImageKey
    //     0xc31b5c: add             x8, PP, #0x38, lsl #12  ; [pp+0x382c0] Type: AssetBundleImageKey
    //     0xc31b60: ldr             x8, [x8, #0x2c0]
    // 0xc31b64: r3 = Null
    //     0xc31b64: add             x3, PP, #0x38, lsl #12  ; [pp+0x382e8] Null
    //     0xc31b68: ldr             x3, [x3, #0x2e8]
    // 0xc31b6c: r0 = AssetBundleImageKey()
    //     0xc31b6c: bl              #0x7f4ec8  ; IsType_AssetBundleImageKey_Stub
    // 0xc31b70: ldr             x16, [fp, #0x20]
    // 0xc31b74: ldr             lr, [fp, #0x18]
    // 0xc31b78: stp             lr, x16, [SP, #-0x10]!
    // 0xc31b7c: ldr             x16, [fp, #0x10]
    // 0xc31b80: SaveReg r16
    //     0xc31b80: str             x16, [SP, #-8]!
    // 0xc31b84: r0 = _loadAsync()
    //     0xc31b84: bl              #0xc31bf4  ; [package:flutter/src/painting/image_provider.dart] AssetBundleImageProvider::_loadAsync
    // 0xc31b88: add             SP, SP, #0x18
    // 0xc31b8c: mov             x1, x0
    // 0xc31b90: ldr             x0, [fp, #0x18]
    // 0xc31b94: stur            x1, [fp, #-0x10]
    // 0xc31b98: LoadField: d0 = r0->field_f
    //     0xc31b98: ldur            d0, [x0, #0xf]
    // 0xc31b9c: stur            d0, [fp, #-0x20]
    // 0xc31ba0: LoadField: r2 = r0->field_b
    //     0xc31ba0: ldur            w2, [x0, #0xb]
    // 0xc31ba4: DecompressPointer r2
    //     0xc31ba4: add             x2, x2, HEAP, lsl #32
    // 0xc31ba8: stur            x2, [fp, #-8]
    // 0xc31bac: r0 = MultiFrameImageStreamCompleter()
    //     0xc31bac: bl              #0xc30830  ; AllocateMultiFrameImageStreamCompleterStub -> MultiFrameImageStreamCompleter (size=0x60)
    // 0xc31bb0: stur            x0, [fp, #-0x18]
    // 0xc31bb4: ldur            x16, [fp, #-0x10]
    // 0xc31bb8: stp             x16, x0, [SP, #-0x10]!
    // 0xc31bbc: ldur            d0, [fp, #-0x20]
    // 0xc31bc0: SaveReg d0
    //     0xc31bc0: str             d0, [SP, #-8]!
    // 0xc31bc4: ldur            x16, [fp, #-8]
    // 0xc31bc8: stp             NULL, x16, [SP, #-0x10]!
    // 0xc31bcc: r4 = const [0, 0x5, 0x5, 0x3, debugLabel, 0x3, informationCollector, 0x4, null]
    //     0xc31bcc: add             x4, PP, #0x38, lsl #12  ; [pp+0x382f8] List(9) [0, 0x5, 0x5, 0x3, "debugLabel", 0x3, "informationCollector", 0x4, Null]
    //     0xc31bd0: ldr             x4, [x4, #0x2f8]
    // 0xc31bd4: r0 = MultiFrameImageStreamCompleter()
    //     0xc31bd4: bl              #0xc30420  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter
    // 0xc31bd8: add             SP, SP, #0x28
    // 0xc31bdc: ldur            x0, [fp, #-0x18]
    // 0xc31be0: LeaveFrame
    //     0xc31be0: mov             SP, fp
    //     0xc31be4: ldp             fp, lr, [SP], #0x10
    // 0xc31be8: ret
    //     0xc31be8: ret             
    // 0xc31bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc31bec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc31bf0: b               #0xc31b38
  }
  _ _loadAsync(/* No info */) async {
    // ** addr: 0xc31bf4, size: 0x1a8
    // 0xc31bf4: EnterFrame
    //     0xc31bf4: stp             fp, lr, [SP, #-0x10]!
    //     0xc31bf8: mov             fp, SP
    // 0xc31bfc: AllocStack(0x70)
    //     0xc31bfc: sub             SP, SP, #0x70
    // 0xc31c00: SetupParameters(AssetBundleImageProvider<AssetBundleImageKey> this /* r1, fp-0x70 */, dynamic _ /* r2, fp-0x68 */, dynamic _ /* r3, fp-0x60 */)
    //     0xc31c00: stur            NULL, [fp, #-8]
    //     0xc31c04: mov             x0, #0
    //     0xc31c08: add             x1, fp, w0, sxtw #2
    //     0xc31c0c: ldr             x1, [x1, #0x20]
    //     0xc31c10: stur            x1, [fp, #-0x70]
    //     0xc31c14: add             x2, fp, w0, sxtw #2
    //     0xc31c18: ldr             x2, [x2, #0x18]
    //     0xc31c1c: stur            x2, [fp, #-0x68]
    //     0xc31c20: add             x3, fp, w0, sxtw #2
    //     0xc31c24: ldr             x3, [x3, #0x10]
    //     0xc31c28: stur            x3, [fp, #-0x60]
    // 0xc31c2c: CheckStackOverflow
    //     0xc31c2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc31c30: cmp             SP, x16
    //     0xc31c34: b.ls            #0xc31d78
    // 0xc31c38: InitAsync() -> Future<Codec>
    //     0xc31c38: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c998] TypeArguments: <Codec>
    //     0xc31c3c: ldr             x0, [x0, #0x998]
    //     0xc31c40: bl              #0x4b92e4
    // 0xc31c44: ldur            x0, [fp, #-0x68]
    // 0xc31c48: LoadField: r1 = r0->field_7
    //     0xc31c48: ldur            w1, [x0, #7]
    // 0xc31c4c: DecompressPointer r1
    //     0xc31c4c: add             x1, x1, HEAP, lsl #32
    // 0xc31c50: LoadField: r2 = r0->field_b
    //     0xc31c50: ldur            w2, [x0, #0xb]
    // 0xc31c54: DecompressPointer r2
    //     0xc31c54: add             x2, x2, HEAP, lsl #32
    // 0xc31c58: stp             x2, x1, [SP, #-0x10]!
    // 0xc31c5c: r0 = loadBuffer()
    //     0xc31c5c: bl              #0xc31d9c  ; [package:flutter/src/services/asset_bundle.dart] PlatformAssetBundle::loadBuffer
    // 0xc31c60: add             SP, SP, #0x10
    // 0xc31c64: mov             x1, x0
    // 0xc31c68: stur            x1, [fp, #-0x70]
    // 0xc31c6c: r0 = Await()
    //     0xc31c6c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc31c70: cmp             w0, NULL
    // 0xc31c74: b.eq            #0xc31cd0
    // 0xc31c78: ldur            x1, [fp, #-0x60]
    // 0xc31c7c: cmp             w1, NULL
    // 0xc31c80: b.eq            #0xc31d80
    // 0xc31c84: stp             x0, x1, [SP, #-0x10]!
    // 0xc31c88: mov             x0, x1
    // 0xc31c8c: ClosureCall
    //     0xc31c8c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc31c90: ldur            x2, [x0, #0x1f]
    //     0xc31c94: blr             x2
    // 0xc31c98: add             SP, SP, #0x10
    // 0xc31c9c: r0 = ReturnAsync()
    //     0xc31c9c: b               #0x501858  ; ReturnAsyncStub
    // 0xc31ca0: sub             SP, fp, #0x70
    // 0xc31ca4: stur            x0, [fp, #-0x60]
    // 0xc31ca8: stur            x1, [fp, #-0x68]
    // 0xc31cac: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc31cac: mov             x2, #0x76
    //     0xc31cb0: tbz             w0, #0, #0xc31cc0
    //     0xc31cb4: ldur            x2, [x0, #-1]
    //     0xc31cb8: ubfx            x2, x2, #0xc, #0x14
    //     0xc31cbc: lsl             x2, x2, #1
    // 0xc31cc0: r17 = 12316
    //     0xc31cc0: mov             x17, #0x301c
    // 0xc31cc4: cmp             w2, w17
    // 0xc31cc8: b.ne            #0xc31d68
    // 0xc31ccc: b               #0xc31d24
    // 0xc31cd0: r0 = LoadStaticField(0xe6c)
    //     0xc31cd0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc31cd4: ldr             x0, [x0, #0x1cd8]
    // 0xc31cd8: cmp             w0, NULL
    // 0xc31cdc: b.eq            #0xc31d84
    // 0xc31ce0: LoadField: r1 = r0->field_a7
    //     0xc31ce0: ldur            w1, [x0, #0xa7]
    // 0xc31ce4: DecompressPointer r1
    //     0xc31ce4: add             x1, x1, HEAP, lsl #32
    // 0xc31ce8: r16 = Sentinel
    //     0xc31ce8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc31cec: cmp             w1, w16
    // 0xc31cf0: b.eq            #0xc31d88
    // 0xc31cf4: ldur            x16, [fp, #-0x68]
    // 0xc31cf8: stp             x16, x1, [SP, #-0x10]!
    // 0xc31cfc: r0 = evict()
    //     0xc31cfc: bl              #0xc316b4  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0xc31d00: add             SP, SP, #0x10
    // 0xc31d04: r0 = StateError()
    //     0xc31d04: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc31d08: mov             x1, x0
    // 0xc31d0c: r0 = "Unable to read data"
    //     0xc31d0c: add             x0, PP, #0x38, lsl #12  ; [pp+0x38300] "Unable to read data"
    //     0xc31d10: ldr             x0, [x0, #0x300]
    // 0xc31d14: StoreField: r1->field_b = r0
    //     0xc31d14: stur            w0, [x1, #0xb]
    // 0xc31d18: mov             x0, x1
    // 0xc31d1c: r0 = Throw()
    //     0xc31d1c: bl              #0xd67e38  ; ThrowStub
    // 0xc31d20: brk             #0
    // 0xc31d24: r2 = LoadStaticField(0xe6c)
    //     0xc31d24: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0xc31d28: ldr             x2, [x2, #0x1cd8]
    // 0xc31d2c: cmp             w2, NULL
    // 0xc31d30: b.eq            #0xc31d90
    // 0xc31d34: LoadField: r3 = r2->field_a7
    //     0xc31d34: ldur            w3, [x2, #0xa7]
    // 0xc31d38: DecompressPointer r3
    //     0xc31d38: add             x3, x3, HEAP, lsl #32
    // 0xc31d3c: r16 = Sentinel
    //     0xc31d3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc31d40: cmp             w3, w16
    // 0xc31d44: b.eq            #0xc31d94
    // 0xc31d48: ldur            x16, [fp, #-0x18]
    // 0xc31d4c: stp             x16, x3, [SP, #-0x10]!
    // 0xc31d50: r0 = evict()
    //     0xc31d50: bl              #0xc316b4  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0xc31d54: add             SP, SP, #0x10
    // 0xc31d58: ldur            x0, [fp, #-0x60]
    // 0xc31d5c: ldur            x1, [fp, #-0x68]
    // 0xc31d60: r0 = ReThrow()
    //     0xc31d60: bl              #0xd67e14  ; ReThrowStub
    // 0xc31d64: brk             #0
    // 0xc31d68: ldur            x0, [fp, #-0x60]
    // 0xc31d6c: ldur            x1, [fp, #-0x68]
    // 0xc31d70: r0 = ReThrow()
    //     0xc31d70: bl              #0xd67e14  ; ReThrowStub
    // 0xc31d74: brk             #0
    // 0xc31d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc31d78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc31d7c: b               #0xc31c38
    // 0xc31d80: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc31d80: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xc31d84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc31d84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc31d88: r9 = _imageCache
    //     0xc31d88: ldr             x9, [PP, #0x4f50]  ; [pp+0x4f50] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@423399801._imageCache@846047248>: late (offset: 0xa8)
    // 0xc31d8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc31d8c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc31d90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc31d90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc31d94: r9 = _imageCache
    //     0xc31d94: ldr             x9, [PP, #0x4f50]  ; [pp+0x4f50] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@423399801._imageCache@846047248>: late (offset: 0xa8)
    // 0xc31d98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc31d98: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4468, size: 0xc, field offset: 0xc
abstract class NetworkImage extends ImageProvider<NetworkImage> {
}

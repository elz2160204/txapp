// lib: , url: package:flutter/src/painting/borders.dart

// class id: 1049349, size: 0x8
class :: {

  static _ paintBorder(/* No info */) {
    // ** addr: 0x6709c0, size: 0xa8c
    // 0x6709c0: EnterFrame
    //     0x6709c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6709c4: mov             fp, SP
    // 0x6709c8: AllocStack(0x38)
    //     0x6709c8: sub             SP, SP, #0x38
    // 0x6709cc: CheckStackOverflow
    //     0x6709cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6709d0: cmp             SP, x16
    //     0x6709d4: b.ls            #0x6712b4
    // 0x6709d8: r16 = 112
    //     0x6709d8: mov             x16, #0x70
    // 0x6709dc: stp             x16, NULL, [SP, #-0x10]!
    // 0x6709e0: r0 = ByteData()
    //     0x6709e0: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x6709e4: add             SP, SP, #0x10
    // 0x6709e8: stur            x0, [fp, #-8]
    // 0x6709ec: r0 = Paint()
    //     0x6709ec: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6709f0: mov             x1, x0
    // 0x6709f4: ldur            x0, [fp, #-8]
    // 0x6709f8: stur            x1, [fp, #-0x18]
    // 0x6709fc: StoreField: r1->field_7 = r0
    //     0x6709fc: stur            w0, [x1, #7]
    // 0x670a00: LoadField: r2 = r0->field_17
    //     0x670a00: ldur            w2, [x0, #0x17]
    // 0x670a04: DecompressPointer r2
    //     0x670a04: add             x2, x2, HEAP, lsl #32
    // 0x670a08: stur            x2, [fp, #-0x10]
    // 0x670a0c: d0 = 0.000000
    //     0x670a0c: eor             v0.16b, v0.16b, v0.16b
    // 0x670a10: fcvt            s1, d0
    // 0x670a14: LoadField: r0 = r2->field_7
    //     0x670a14: ldur            x0, [x2, #7]
    // 0x670a18: str             s1, [x0, #0x10]
    // 0x670a1c: r0 = Path()
    //     0x670a1c: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x670a20: stur            x0, [fp, #-8]
    // 0x670a24: SaveReg r0
    //     0x670a24: str             x0, [SP, #-8]!
    // 0x670a28: r0 = _constructor()
    //     0x670a28: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x670a2c: add             SP, SP, #8
    // 0x670a30: ldr             x0, [fp, #0x10]
    // 0x670a34: LoadField: r1 = r0->field_13
    //     0x670a34: ldur            w1, [x0, #0x13]
    // 0x670a38: DecompressPointer r1
    //     0x670a38: add             x1, x1, HEAP, lsl #32
    // 0x670a3c: LoadField: r2 = r1->field_7
    //     0x670a3c: ldur            x2, [x1, #7]
    // 0x670a40: cmp             x2, #0
    // 0x670a44: b.le            #0x670c74
    // 0x670a48: LoadField: r1 = r0->field_7
    //     0x670a48: ldur            w1, [x0, #7]
    // 0x670a4c: DecompressPointer r1
    //     0x670a4c: add             x1, x1, HEAP, lsl #32
    // 0x670a50: r2 = LoadClassIdInstr(r1)
    //     0x670a50: ldur            x2, [x1, #-1]
    //     0x670a54: ubfx            x2, x2, #0xc, #0x14
    // 0x670a58: lsl             x2, x2, #1
    // 0x670a5c: r17 = 10124
    //     0x670a5c: mov             x17, #0x278c
    // 0x670a60: cmp             w2, w17
    // 0x670a64: b.gt            #0x670a74
    // 0x670a68: r17 = 10122
    //     0x670a68: mov             x17, #0x278a
    // 0x670a6c: cmp             w2, w17
    // 0x670a70: b.ge            #0x670a8c
    // 0x670a74: r17 = 10114
    //     0x670a74: mov             x17, #0x2782
    // 0x670a78: cmp             w2, w17
    // 0x670a7c: b.eq            #0x670a8c
    // 0x670a80: r17 = 10118
    //     0x670a80: mov             x17, #0x2786
    // 0x670a84: cmp             w2, w17
    // 0x670a88: b.ne            #0x670a98
    // 0x670a8c: LoadField: r2 = r1->field_7
    //     0x670a8c: ldur            x2, [x1, #7]
    // 0x670a90: mov             x3, x2
    // 0x670a94: b               #0x670aa8
    // 0x670a98: LoadField: r2 = r1->field_f
    //     0x670a98: ldur            w2, [x1, #0xf]
    // 0x670a9c: DecompressPointer r2
    //     0x670a9c: add             x2, x2, HEAP, lsl #32
    // 0x670aa0: LoadField: r1 = r2->field_7
    //     0x670aa0: ldur            x1, [x2, #7]
    // 0x670aa4: mov             x3, x1
    // 0x670aa8: ldr             x2, [fp, #0x30]
    // 0x670aac: ldur            x1, [fp, #-0x10]
    // 0x670ab0: eor             x4, x3, #0xff000000
    // 0x670ab4: sxtw            x4, w4
    // 0x670ab8: LoadField: r3 = r1->field_7
    //     0x670ab8: ldur            x3, [x1, #7]
    // 0x670abc: str             w4, [x3, #4]
    // 0x670ac0: ldur            x16, [fp, #-8]
    // 0x670ac4: SaveReg r16
    //     0x670ac4: str             x16, [SP, #-8]!
    // 0x670ac8: r0 = reset()
    //     0x670ac8: bl              #0x67144c  ; [dart:ui] Path::reset
    // 0x670acc: add             SP, SP, #8
    // 0x670ad0: ldr             x0, [fp, #0x30]
    // 0x670ad4: LoadField: d0 = r0->field_7
    //     0x670ad4: ldur            d0, [x0, #7]
    // 0x670ad8: stur            d0, [fp, #-0x30]
    // 0x670adc: LoadField: d1 = r0->field_f
    //     0x670adc: ldur            d1, [x0, #0xf]
    // 0x670ae0: stur            d1, [fp, #-0x28]
    // 0x670ae4: r1 = inline_Allocate_Double()
    //     0x670ae4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x670ae8: add             x1, x1, #0x10
    //     0x670aec: cmp             x2, x1
    //     0x670af0: b.ls            #0x6712bc
    //     0x670af4: str             x1, [THR, #0x60]  ; THR::top
    //     0x670af8: sub             x1, x1, #0xf
    //     0x670afc: mov             x2, #0xd108
    //     0x670b00: movk            x2, #3, lsl #16
    //     0x670b04: stur            x2, [x1, #-1]
    // 0x670b08: StoreField: r1->field_7 = d0
    //     0x670b08: stur            d0, [x1, #7]
    // 0x670b0c: ldur            x16, [fp, #-8]
    // 0x670b10: stp             x1, x16, [SP, #-0x10]!
    // 0x670b14: SaveReg d1
    //     0x670b14: str             d1, [SP, #-8]!
    // 0x670b18: r0 = moveTo()
    //     0x670b18: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0x670b1c: add             SP, SP, #0x18
    // 0x670b20: ldr             x0, [fp, #0x30]
    // 0x670b24: LoadField: d0 = r0->field_17
    //     0x670b24: ldur            d0, [x0, #0x17]
    // 0x670b28: stur            d0, [fp, #-0x38]
    // 0x670b2c: r1 = inline_Allocate_Double()
    //     0x670b2c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x670b30: add             x1, x1, #0x10
    //     0x670b34: cmp             x2, x1
    //     0x670b38: b.ls            #0x6712d8
    //     0x670b3c: str             x1, [THR, #0x60]  ; THR::top
    //     0x670b40: sub             x1, x1, #0xf
    //     0x670b44: mov             x2, #0xd108
    //     0x670b48: movk            x2, #3, lsl #16
    //     0x670b4c: stur            x2, [x1, #-1]
    // 0x670b50: StoreField: r1->field_7 = d0
    //     0x670b50: stur            d0, [x1, #7]
    // 0x670b54: ldur            x16, [fp, #-8]
    // 0x670b58: stp             x1, x16, [SP, #-0x10]!
    // 0x670b5c: ldur            d1, [fp, #-0x28]
    // 0x670b60: SaveReg d1
    //     0x670b60: str             d1, [SP, #-8]!
    // 0x670b64: r0 = lineTo()
    //     0x670b64: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x670b68: add             SP, SP, #0x18
    // 0x670b6c: ldr             x0, [fp, #0x10]
    // 0x670b70: LoadField: d0 = r0->field_b
    //     0x670b70: ldur            d0, [x0, #0xb]
    // 0x670b74: d1 = 0.000000
    //     0x670b74: eor             v1.16b, v1.16b, v1.16b
    // 0x670b78: fcmp            d0, d1
    // 0x670b7c: b.vs            #0x670b98
    // 0x670b80: b.ne            #0x670b98
    // 0x670b84: ldur            x1, [fp, #-0x10]
    // 0x670b88: r2 = 1
    //     0x670b88: mov             x2, #1
    // 0x670b8c: LoadField: r3 = r1->field_7
    //     0x670b8c: ldur            x3, [x1, #7]
    // 0x670b90: str             w2, [x3, #0xc]
    // 0x670b94: b               #0x670c58
    // 0x670b98: ldr             x4, [fp, #0x20]
    // 0x670b9c: ldr             x3, [fp, #0x18]
    // 0x670ba0: ldur            d4, [fp, #-0x30]
    // 0x670ba4: ldur            d3, [fp, #-0x28]
    // 0x670ba8: ldur            d2, [fp, #-0x38]
    // 0x670bac: ldur            x1, [fp, #-0x10]
    // 0x670bb0: r2 = 1
    //     0x670bb0: mov             x2, #1
    // 0x670bb4: LoadField: r5 = r1->field_7
    //     0x670bb4: ldur            x5, [x1, #7]
    // 0x670bb8: str             wzr, [x5, #0xc]
    // 0x670bbc: LoadField: d5 = r3->field_b
    //     0x670bbc: ldur            d5, [x3, #0xb]
    // 0x670bc0: fsub            d6, d2, d5
    // 0x670bc4: fadd            d2, d3, d0
    // 0x670bc8: stur            d2, [fp, #-0x38]
    // 0x670bcc: r5 = inline_Allocate_Double()
    //     0x670bcc: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x670bd0: add             x5, x5, #0x10
    //     0x670bd4: cmp             x6, x5
    //     0x670bd8: b.ls            #0x6712f4
    //     0x670bdc: str             x5, [THR, #0x60]  ; THR::top
    //     0x670be0: sub             x5, x5, #0xf
    //     0x670be4: mov             x6, #0xd108
    //     0x670be8: movk            x6, #3, lsl #16
    //     0x670bec: stur            x6, [x5, #-1]
    // 0x670bf0: StoreField: r5->field_7 = d6
    //     0x670bf0: stur            d6, [x5, #7]
    // 0x670bf4: ldur            x16, [fp, #-8]
    // 0x670bf8: stp             x5, x16, [SP, #-0x10]!
    // 0x670bfc: SaveReg d2
    //     0x670bfc: str             d2, [SP, #-8]!
    // 0x670c00: r0 = lineTo()
    //     0x670c00: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x670c04: add             SP, SP, #0x18
    // 0x670c08: ldr             x0, [fp, #0x20]
    // 0x670c0c: LoadField: d0 = r0->field_b
    //     0x670c0c: ldur            d0, [x0, #0xb]
    // 0x670c10: ldur            d1, [fp, #-0x30]
    // 0x670c14: fadd            d2, d1, d0
    // 0x670c18: r1 = inline_Allocate_Double()
    //     0x670c18: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x670c1c: add             x1, x1, #0x10
    //     0x670c20: cmp             x2, x1
    //     0x670c24: b.ls            #0x671328
    //     0x670c28: str             x1, [THR, #0x60]  ; THR::top
    //     0x670c2c: sub             x1, x1, #0xf
    //     0x670c30: mov             x2, #0xd108
    //     0x670c34: movk            x2, #3, lsl #16
    //     0x670c38: stur            x2, [x1, #-1]
    // 0x670c3c: StoreField: r1->field_7 = d2
    //     0x670c3c: stur            d2, [x1, #7]
    // 0x670c40: ldur            x16, [fp, #-8]
    // 0x670c44: stp             x1, x16, [SP, #-0x10]!
    // 0x670c48: ldur            d0, [fp, #-0x38]
    // 0x670c4c: SaveReg d0
    //     0x670c4c: str             d0, [SP, #-8]!
    // 0x670c50: r0 = lineTo()
    //     0x670c50: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x670c54: add             SP, SP, #0x18
    // 0x670c58: ldr             x16, [fp, #0x38]
    // 0x670c5c: ldur            lr, [fp, #-8]
    // 0x670c60: stp             lr, x16, [SP, #-0x10]!
    // 0x670c64: ldur            x16, [fp, #-0x18]
    // 0x670c68: SaveReg r16
    //     0x670c68: str             x16, [SP, #-8]!
    // 0x670c6c: r0 = drawPath()
    //     0x670c6c: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0x670c70: add             SP, SP, #0x18
    // 0x670c74: ldr             x0, [fp, #0x18]
    // 0x670c78: LoadField: r1 = r0->field_13
    //     0x670c78: ldur            w1, [x0, #0x13]
    // 0x670c7c: DecompressPointer r1
    //     0x670c7c: add             x1, x1, HEAP, lsl #32
    // 0x670c80: LoadField: r2 = r1->field_7
    //     0x670c80: ldur            x2, [x1, #7]
    // 0x670c84: cmp             x2, #0
    // 0x670c88: b.le            #0x670e6c
    // 0x670c8c: LoadField: r1 = r0->field_7
    //     0x670c8c: ldur            w1, [x0, #7]
    // 0x670c90: DecompressPointer r1
    //     0x670c90: add             x1, x1, HEAP, lsl #32
    // 0x670c94: r2 = LoadClassIdInstr(r1)
    //     0x670c94: ldur            x2, [x1, #-1]
    //     0x670c98: ubfx            x2, x2, #0xc, #0x14
    // 0x670c9c: lsl             x2, x2, #1
    // 0x670ca0: r17 = 10124
    //     0x670ca0: mov             x17, #0x278c
    // 0x670ca4: cmp             w2, w17
    // 0x670ca8: b.gt            #0x670cb8
    // 0x670cac: r17 = 10122
    //     0x670cac: mov             x17, #0x278a
    // 0x670cb0: cmp             w2, w17
    // 0x670cb4: b.ge            #0x670cd0
    // 0x670cb8: r17 = 10114
    //     0x670cb8: mov             x17, #0x2782
    // 0x670cbc: cmp             w2, w17
    // 0x670cc0: b.eq            #0x670cd0
    // 0x670cc4: r17 = 10118
    //     0x670cc4: mov             x17, #0x2786
    // 0x670cc8: cmp             w2, w17
    // 0x670ccc: b.ne            #0x670cdc
    // 0x670cd0: LoadField: r2 = r1->field_7
    //     0x670cd0: ldur            x2, [x1, #7]
    // 0x670cd4: mov             x3, x2
    // 0x670cd8: b               #0x670cec
    // 0x670cdc: LoadField: r2 = r1->field_f
    //     0x670cdc: ldur            w2, [x1, #0xf]
    // 0x670ce0: DecompressPointer r2
    //     0x670ce0: add             x2, x2, HEAP, lsl #32
    // 0x670ce4: LoadField: r1 = r2->field_7
    //     0x670ce4: ldur            x1, [x2, #7]
    // 0x670ce8: mov             x3, x1
    // 0x670cec: ldr             x2, [fp, #0x30]
    // 0x670cf0: ldur            x1, [fp, #-0x10]
    // 0x670cf4: eor             x4, x3, #0xff000000
    // 0x670cf8: sxtw            x4, w4
    // 0x670cfc: LoadField: r3 = r1->field_7
    //     0x670cfc: ldur            x3, [x1, #7]
    // 0x670d00: str             w4, [x3, #4]
    // 0x670d04: ldur            x16, [fp, #-8]
    // 0x670d08: SaveReg r16
    //     0x670d08: str             x16, [SP, #-8]!
    // 0x670d0c: r0 = reset()
    //     0x670d0c: bl              #0x67144c  ; [dart:ui] Path::reset
    // 0x670d10: add             SP, SP, #8
    // 0x670d14: ldr             x0, [fp, #0x30]
    // 0x670d18: LoadField: d0 = r0->field_17
    //     0x670d18: ldur            d0, [x0, #0x17]
    // 0x670d1c: stur            d0, [fp, #-0x30]
    // 0x670d20: LoadField: d1 = r0->field_f
    //     0x670d20: ldur            d1, [x0, #0xf]
    // 0x670d24: stur            d1, [fp, #-0x28]
    // 0x670d28: r1 = inline_Allocate_Double()
    //     0x670d28: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x670d2c: add             x1, x1, #0x10
    //     0x670d30: cmp             x2, x1
    //     0x670d34: b.ls            #0x671344
    //     0x670d38: str             x1, [THR, #0x60]  ; THR::top
    //     0x670d3c: sub             x1, x1, #0xf
    //     0x670d40: mov             x2, #0xd108
    //     0x670d44: movk            x2, #3, lsl #16
    //     0x670d48: stur            x2, [x1, #-1]
    // 0x670d4c: StoreField: r1->field_7 = d0
    //     0x670d4c: stur            d0, [x1, #7]
    // 0x670d50: stur            x1, [fp, #-0x20]
    // 0x670d54: ldur            x16, [fp, #-8]
    // 0x670d58: stp             x1, x16, [SP, #-0x10]!
    // 0x670d5c: SaveReg d1
    //     0x670d5c: str             d1, [SP, #-8]!
    // 0x670d60: r0 = moveTo()
    //     0x670d60: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0x670d64: add             SP, SP, #0x18
    // 0x670d68: ldr             x0, [fp, #0x30]
    // 0x670d6c: LoadField: d0 = r0->field_1f
    //     0x670d6c: ldur            d0, [x0, #0x1f]
    // 0x670d70: stur            d0, [fp, #-0x38]
    // 0x670d74: ldur            x16, [fp, #-8]
    // 0x670d78: ldur            lr, [fp, #-0x20]
    // 0x670d7c: stp             lr, x16, [SP, #-0x10]!
    // 0x670d80: SaveReg d0
    //     0x670d80: str             d0, [SP, #-8]!
    // 0x670d84: r0 = lineTo()
    //     0x670d84: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x670d88: add             SP, SP, #0x18
    // 0x670d8c: ldr             x0, [fp, #0x18]
    // 0x670d90: LoadField: d0 = r0->field_b
    //     0x670d90: ldur            d0, [x0, #0xb]
    // 0x670d94: d1 = 0.000000
    //     0x670d94: eor             v1.16b, v1.16b, v1.16b
    // 0x670d98: fcmp            d0, d1
    // 0x670d9c: b.vs            #0x670db8
    // 0x670da0: b.ne            #0x670db8
    // 0x670da4: ldur            x1, [fp, #-0x10]
    // 0x670da8: r2 = 1
    //     0x670da8: mov             x2, #1
    // 0x670dac: LoadField: r3 = r1->field_7
    //     0x670dac: ldur            x3, [x1, #7]
    // 0x670db0: str             w2, [x3, #0xc]
    // 0x670db4: b               #0x670e50
    // 0x670db8: ldr             x4, [fp, #0x28]
    // 0x670dbc: ldr             x3, [fp, #0x10]
    // 0x670dc0: ldur            d3, [fp, #-0x30]
    // 0x670dc4: ldur            d4, [fp, #-0x28]
    // 0x670dc8: ldur            d2, [fp, #-0x38]
    // 0x670dcc: ldur            x1, [fp, #-0x10]
    // 0x670dd0: r2 = 1
    //     0x670dd0: mov             x2, #1
    // 0x670dd4: LoadField: r5 = r1->field_7
    //     0x670dd4: ldur            x5, [x1, #7]
    // 0x670dd8: str             wzr, [x5, #0xc]
    // 0x670ddc: fsub            d5, d3, d0
    // 0x670de0: LoadField: d0 = r4->field_b
    //     0x670de0: ldur            d0, [x4, #0xb]
    // 0x670de4: fsub            d3, d2, d0
    // 0x670de8: r5 = inline_Allocate_Double()
    //     0x670de8: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x670dec: add             x5, x5, #0x10
    //     0x670df0: cmp             x6, x5
    //     0x670df4: b.ls            #0x671360
    //     0x670df8: str             x5, [THR, #0x60]  ; THR::top
    //     0x670dfc: sub             x5, x5, #0xf
    //     0x670e00: mov             x6, #0xd108
    //     0x670e04: movk            x6, #3, lsl #16
    //     0x670e08: stur            x6, [x5, #-1]
    // 0x670e0c: StoreField: r5->field_7 = d5
    //     0x670e0c: stur            d5, [x5, #7]
    // 0x670e10: stur            x5, [fp, #-0x20]
    // 0x670e14: ldur            x16, [fp, #-8]
    // 0x670e18: stp             x5, x16, [SP, #-0x10]!
    // 0x670e1c: SaveReg d3
    //     0x670e1c: str             d3, [SP, #-8]!
    // 0x670e20: r0 = lineTo()
    //     0x670e20: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x670e24: add             SP, SP, #0x18
    // 0x670e28: ldr             x0, [fp, #0x10]
    // 0x670e2c: LoadField: d0 = r0->field_b
    //     0x670e2c: ldur            d0, [x0, #0xb]
    // 0x670e30: ldur            d1, [fp, #-0x28]
    // 0x670e34: fadd            d2, d1, d0
    // 0x670e38: ldur            x16, [fp, #-8]
    // 0x670e3c: ldur            lr, [fp, #-0x20]
    // 0x670e40: stp             lr, x16, [SP, #-0x10]!
    // 0x670e44: SaveReg d2
    //     0x670e44: str             d2, [SP, #-8]!
    // 0x670e48: r0 = lineTo()
    //     0x670e48: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x670e4c: add             SP, SP, #0x18
    // 0x670e50: ldr             x16, [fp, #0x38]
    // 0x670e54: ldur            lr, [fp, #-8]
    // 0x670e58: stp             lr, x16, [SP, #-0x10]!
    // 0x670e5c: ldur            x16, [fp, #-0x18]
    // 0x670e60: SaveReg r16
    //     0x670e60: str             x16, [SP, #-8]!
    // 0x670e64: r0 = drawPath()
    //     0x670e64: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0x670e68: add             SP, SP, #0x18
    // 0x670e6c: ldr             x0, [fp, #0x28]
    // 0x670e70: LoadField: r1 = r0->field_13
    //     0x670e70: ldur            w1, [x0, #0x13]
    // 0x670e74: DecompressPointer r1
    //     0x670e74: add             x1, x1, HEAP, lsl #32
    // 0x670e78: LoadField: r2 = r1->field_7
    //     0x670e78: ldur            x2, [x1, #7]
    // 0x670e7c: cmp             x2, #0
    // 0x670e80: b.le            #0x6710b0
    // 0x670e84: LoadField: r1 = r0->field_7
    //     0x670e84: ldur            w1, [x0, #7]
    // 0x670e88: DecompressPointer r1
    //     0x670e88: add             x1, x1, HEAP, lsl #32
    // 0x670e8c: r2 = LoadClassIdInstr(r1)
    //     0x670e8c: ldur            x2, [x1, #-1]
    //     0x670e90: ubfx            x2, x2, #0xc, #0x14
    // 0x670e94: lsl             x2, x2, #1
    // 0x670e98: r17 = 10124
    //     0x670e98: mov             x17, #0x278c
    // 0x670e9c: cmp             w2, w17
    // 0x670ea0: b.gt            #0x670eb0
    // 0x670ea4: r17 = 10122
    //     0x670ea4: mov             x17, #0x278a
    // 0x670ea8: cmp             w2, w17
    // 0x670eac: b.ge            #0x670ec8
    // 0x670eb0: r17 = 10114
    //     0x670eb0: mov             x17, #0x2782
    // 0x670eb4: cmp             w2, w17
    // 0x670eb8: b.eq            #0x670ec8
    // 0x670ebc: r17 = 10118
    //     0x670ebc: mov             x17, #0x2786
    // 0x670ec0: cmp             w2, w17
    // 0x670ec4: b.ne            #0x670ed4
    // 0x670ec8: LoadField: r2 = r1->field_7
    //     0x670ec8: ldur            x2, [x1, #7]
    // 0x670ecc: mov             x3, x2
    // 0x670ed0: b               #0x670ee4
    // 0x670ed4: LoadField: r2 = r1->field_f
    //     0x670ed4: ldur            w2, [x1, #0xf]
    // 0x670ed8: DecompressPointer r2
    //     0x670ed8: add             x2, x2, HEAP, lsl #32
    // 0x670edc: LoadField: r1 = r2->field_7
    //     0x670edc: ldur            x1, [x2, #7]
    // 0x670ee0: mov             x3, x1
    // 0x670ee4: ldr             x2, [fp, #0x30]
    // 0x670ee8: ldur            x1, [fp, #-0x10]
    // 0x670eec: eor             x4, x3, #0xff000000
    // 0x670ef0: sxtw            x4, w4
    // 0x670ef4: LoadField: r3 = r1->field_7
    //     0x670ef4: ldur            x3, [x1, #7]
    // 0x670ef8: str             w4, [x3, #4]
    // 0x670efc: ldur            x16, [fp, #-8]
    // 0x670f00: SaveReg r16
    //     0x670f00: str             x16, [SP, #-8]!
    // 0x670f04: r0 = reset()
    //     0x670f04: bl              #0x67144c  ; [dart:ui] Path::reset
    // 0x670f08: add             SP, SP, #8
    // 0x670f0c: ldr             x0, [fp, #0x30]
    // 0x670f10: LoadField: d0 = r0->field_17
    //     0x670f10: ldur            d0, [x0, #0x17]
    // 0x670f14: stur            d0, [fp, #-0x30]
    // 0x670f18: LoadField: d1 = r0->field_1f
    //     0x670f18: ldur            d1, [x0, #0x1f]
    // 0x670f1c: stur            d1, [fp, #-0x28]
    // 0x670f20: r1 = inline_Allocate_Double()
    //     0x670f20: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x670f24: add             x1, x1, #0x10
    //     0x670f28: cmp             x2, x1
    //     0x670f2c: b.ls            #0x671394
    //     0x670f30: str             x1, [THR, #0x60]  ; THR::top
    //     0x670f34: sub             x1, x1, #0xf
    //     0x670f38: mov             x2, #0xd108
    //     0x670f3c: movk            x2, #3, lsl #16
    //     0x670f40: stur            x2, [x1, #-1]
    // 0x670f44: StoreField: r1->field_7 = d0
    //     0x670f44: stur            d0, [x1, #7]
    // 0x670f48: ldur            x16, [fp, #-8]
    // 0x670f4c: stp             x1, x16, [SP, #-0x10]!
    // 0x670f50: SaveReg d1
    //     0x670f50: str             d1, [SP, #-8]!
    // 0x670f54: r0 = moveTo()
    //     0x670f54: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0x670f58: add             SP, SP, #0x18
    // 0x670f5c: ldr             x0, [fp, #0x30]
    // 0x670f60: LoadField: d0 = r0->field_7
    //     0x670f60: ldur            d0, [x0, #7]
    // 0x670f64: stur            d0, [fp, #-0x38]
    // 0x670f68: r1 = inline_Allocate_Double()
    //     0x670f68: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x670f6c: add             x1, x1, #0x10
    //     0x670f70: cmp             x2, x1
    //     0x670f74: b.ls            #0x6713b0
    //     0x670f78: str             x1, [THR, #0x60]  ; THR::top
    //     0x670f7c: sub             x1, x1, #0xf
    //     0x670f80: mov             x2, #0xd108
    //     0x670f84: movk            x2, #3, lsl #16
    //     0x670f88: stur            x2, [x1, #-1]
    // 0x670f8c: StoreField: r1->field_7 = d0
    //     0x670f8c: stur            d0, [x1, #7]
    // 0x670f90: ldur            x16, [fp, #-8]
    // 0x670f94: stp             x1, x16, [SP, #-0x10]!
    // 0x670f98: ldur            d1, [fp, #-0x28]
    // 0x670f9c: SaveReg d1
    //     0x670f9c: str             d1, [SP, #-8]!
    // 0x670fa0: r0 = lineTo()
    //     0x670fa0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x670fa4: add             SP, SP, #0x18
    // 0x670fa8: ldr             x0, [fp, #0x28]
    // 0x670fac: LoadField: d0 = r0->field_b
    //     0x670fac: ldur            d0, [x0, #0xb]
    // 0x670fb0: d1 = 0.000000
    //     0x670fb0: eor             v1.16b, v1.16b, v1.16b
    // 0x670fb4: fcmp            d0, d1
    // 0x670fb8: b.vs            #0x670fd4
    // 0x670fbc: b.ne            #0x670fd4
    // 0x670fc0: ldur            x1, [fp, #-0x10]
    // 0x670fc4: r2 = 1
    //     0x670fc4: mov             x2, #1
    // 0x670fc8: LoadField: r3 = r1->field_7
    //     0x670fc8: ldur            x3, [x1, #7]
    // 0x670fcc: str             w2, [x3, #0xc]
    // 0x670fd0: b               #0x671094
    // 0x670fd4: ldr             x4, [fp, #0x20]
    // 0x670fd8: ldr             x3, [fp, #0x18]
    // 0x670fdc: ldur            d4, [fp, #-0x30]
    // 0x670fe0: ldur            d3, [fp, #-0x28]
    // 0x670fe4: ldur            d2, [fp, #-0x38]
    // 0x670fe8: ldur            x1, [fp, #-0x10]
    // 0x670fec: r2 = 1
    //     0x670fec: mov             x2, #1
    // 0x670ff0: LoadField: r5 = r1->field_7
    //     0x670ff0: ldur            x5, [x1, #7]
    // 0x670ff4: str             wzr, [x5, #0xc]
    // 0x670ff8: LoadField: d5 = r4->field_b
    //     0x670ff8: ldur            d5, [x4, #0xb]
    // 0x670ffc: fadd            d6, d2, d5
    // 0x671000: fsub            d2, d3, d0
    // 0x671004: stur            d2, [fp, #-0x38]
    // 0x671008: r5 = inline_Allocate_Double()
    //     0x671008: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x67100c: add             x5, x5, #0x10
    //     0x671010: cmp             x6, x5
    //     0x671014: b.ls            #0x6713cc
    //     0x671018: str             x5, [THR, #0x60]  ; THR::top
    //     0x67101c: sub             x5, x5, #0xf
    //     0x671020: mov             x6, #0xd108
    //     0x671024: movk            x6, #3, lsl #16
    //     0x671028: stur            x6, [x5, #-1]
    // 0x67102c: StoreField: r5->field_7 = d6
    //     0x67102c: stur            d6, [x5, #7]
    // 0x671030: ldur            x16, [fp, #-8]
    // 0x671034: stp             x5, x16, [SP, #-0x10]!
    // 0x671038: SaveReg d2
    //     0x671038: str             d2, [SP, #-8]!
    // 0x67103c: r0 = lineTo()
    //     0x67103c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x671040: add             SP, SP, #0x18
    // 0x671044: ldr             x0, [fp, #0x18]
    // 0x671048: LoadField: d0 = r0->field_b
    //     0x671048: ldur            d0, [x0, #0xb]
    // 0x67104c: ldur            d1, [fp, #-0x30]
    // 0x671050: fsub            d2, d1, d0
    // 0x671054: r0 = inline_Allocate_Double()
    //     0x671054: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x671058: add             x0, x0, #0x10
    //     0x67105c: cmp             x1, x0
    //     0x671060: b.ls            #0x671400
    //     0x671064: str             x0, [THR, #0x60]  ; THR::top
    //     0x671068: sub             x0, x0, #0xf
    //     0x67106c: mov             x1, #0xd108
    //     0x671070: movk            x1, #3, lsl #16
    //     0x671074: stur            x1, [x0, #-1]
    // 0x671078: StoreField: r0->field_7 = d2
    //     0x671078: stur            d2, [x0, #7]
    // 0x67107c: ldur            x16, [fp, #-8]
    // 0x671080: stp             x0, x16, [SP, #-0x10]!
    // 0x671084: ldur            d0, [fp, #-0x38]
    // 0x671088: SaveReg d0
    //     0x671088: str             d0, [SP, #-8]!
    // 0x67108c: r0 = lineTo()
    //     0x67108c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x671090: add             SP, SP, #0x18
    // 0x671094: ldr             x16, [fp, #0x38]
    // 0x671098: ldur            lr, [fp, #-8]
    // 0x67109c: stp             lr, x16, [SP, #-0x10]!
    // 0x6710a0: ldur            x16, [fp, #-0x18]
    // 0x6710a4: SaveReg r16
    //     0x6710a4: str             x16, [SP, #-8]!
    // 0x6710a8: r0 = drawPath()
    //     0x6710a8: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0x6710ac: add             SP, SP, #0x18
    // 0x6710b0: ldr             x0, [fp, #0x20]
    // 0x6710b4: LoadField: r1 = r0->field_13
    //     0x6710b4: ldur            w1, [x0, #0x13]
    // 0x6710b8: DecompressPointer r1
    //     0x6710b8: add             x1, x1, HEAP, lsl #32
    // 0x6710bc: LoadField: r2 = r1->field_7
    //     0x6710bc: ldur            x2, [x1, #7]
    // 0x6710c0: cmp             x2, #0
    // 0x6710c4: b.le            #0x6712a4
    // 0x6710c8: LoadField: r1 = r0->field_7
    //     0x6710c8: ldur            w1, [x0, #7]
    // 0x6710cc: DecompressPointer r1
    //     0x6710cc: add             x1, x1, HEAP, lsl #32
    // 0x6710d0: r2 = LoadClassIdInstr(r1)
    //     0x6710d0: ldur            x2, [x1, #-1]
    //     0x6710d4: ubfx            x2, x2, #0xc, #0x14
    // 0x6710d8: lsl             x2, x2, #1
    // 0x6710dc: r17 = 10124
    //     0x6710dc: mov             x17, #0x278c
    // 0x6710e0: cmp             w2, w17
    // 0x6710e4: b.gt            #0x6710f4
    // 0x6710e8: r17 = 10122
    //     0x6710e8: mov             x17, #0x278a
    // 0x6710ec: cmp             w2, w17
    // 0x6710f0: b.ge            #0x67110c
    // 0x6710f4: r17 = 10114
    //     0x6710f4: mov             x17, #0x2782
    // 0x6710f8: cmp             w2, w17
    // 0x6710fc: b.eq            #0x67110c
    // 0x671100: r17 = 10118
    //     0x671100: mov             x17, #0x2786
    // 0x671104: cmp             w2, w17
    // 0x671108: b.ne            #0x671118
    // 0x67110c: LoadField: r2 = r1->field_7
    //     0x67110c: ldur            x2, [x1, #7]
    // 0x671110: mov             x3, x2
    // 0x671114: b               #0x671128
    // 0x671118: LoadField: r2 = r1->field_f
    //     0x671118: ldur            w2, [x1, #0xf]
    // 0x67111c: DecompressPointer r2
    //     0x67111c: add             x2, x2, HEAP, lsl #32
    // 0x671120: LoadField: r1 = r2->field_7
    //     0x671120: ldur            x1, [x2, #7]
    // 0x671124: mov             x3, x1
    // 0x671128: ldr             x2, [fp, #0x30]
    // 0x67112c: ldur            x1, [fp, #-0x10]
    // 0x671130: eor             x4, x3, #0xff000000
    // 0x671134: sxtw            x4, w4
    // 0x671138: LoadField: r3 = r1->field_7
    //     0x671138: ldur            x3, [x1, #7]
    // 0x67113c: str             w4, [x3, #4]
    // 0x671140: ldur            x16, [fp, #-8]
    // 0x671144: SaveReg r16
    //     0x671144: str             x16, [SP, #-8]!
    // 0x671148: r0 = reset()
    //     0x671148: bl              #0x67144c  ; [dart:ui] Path::reset
    // 0x67114c: add             SP, SP, #8
    // 0x671150: ldr             x0, [fp, #0x30]
    // 0x671154: LoadField: d0 = r0->field_7
    //     0x671154: ldur            d0, [x0, #7]
    // 0x671158: stur            d0, [fp, #-0x30]
    // 0x67115c: LoadField: d1 = r0->field_1f
    //     0x67115c: ldur            d1, [x0, #0x1f]
    // 0x671160: stur            d1, [fp, #-0x28]
    // 0x671164: r1 = inline_Allocate_Double()
    //     0x671164: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x671168: add             x1, x1, #0x10
    //     0x67116c: cmp             x2, x1
    //     0x671170: b.ls            #0x671410
    //     0x671174: str             x1, [THR, #0x60]  ; THR::top
    //     0x671178: sub             x1, x1, #0xf
    //     0x67117c: mov             x2, #0xd108
    //     0x671180: movk            x2, #3, lsl #16
    //     0x671184: stur            x2, [x1, #-1]
    // 0x671188: StoreField: r1->field_7 = d0
    //     0x671188: stur            d0, [x1, #7]
    // 0x67118c: stur            x1, [fp, #-0x20]
    // 0x671190: ldur            x16, [fp, #-8]
    // 0x671194: stp             x1, x16, [SP, #-0x10]!
    // 0x671198: SaveReg d1
    //     0x671198: str             d1, [SP, #-8]!
    // 0x67119c: r0 = moveTo()
    //     0x67119c: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0x6711a0: add             SP, SP, #0x18
    // 0x6711a4: ldr             x0, [fp, #0x30]
    // 0x6711a8: LoadField: d0 = r0->field_f
    //     0x6711a8: ldur            d0, [x0, #0xf]
    // 0x6711ac: stur            d0, [fp, #-0x38]
    // 0x6711b0: ldur            x16, [fp, #-8]
    // 0x6711b4: ldur            lr, [fp, #-0x20]
    // 0x6711b8: stp             lr, x16, [SP, #-0x10]!
    // 0x6711bc: SaveReg d0
    //     0x6711bc: str             d0, [SP, #-8]!
    // 0x6711c0: r0 = lineTo()
    //     0x6711c0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x6711c4: add             SP, SP, #0x18
    // 0x6711c8: ldr             x0, [fp, #0x20]
    // 0x6711cc: LoadField: d0 = r0->field_b
    //     0x6711cc: ldur            d0, [x0, #0xb]
    // 0x6711d0: d1 = 0.000000
    //     0x6711d0: eor             v1.16b, v1.16b, v1.16b
    // 0x6711d4: fcmp            d0, d1
    // 0x6711d8: b.vs            #0x6711f4
    // 0x6711dc: b.ne            #0x6711f4
    // 0x6711e0: ldur            x0, [fp, #-0x10]
    // 0x6711e4: r1 = 1
    //     0x6711e4: mov             x1, #1
    // 0x6711e8: LoadField: r2 = r0->field_7
    //     0x6711e8: ldur            x2, [x0, #7]
    // 0x6711ec: str             w1, [x2, #0xc]
    // 0x6711f0: b               #0x671288
    // 0x6711f4: ldr             x1, [fp, #0x28]
    // 0x6711f8: ldr             x2, [fp, #0x10]
    // 0x6711fc: ldur            d2, [fp, #-0x30]
    // 0x671200: ldur            d3, [fp, #-0x28]
    // 0x671204: ldur            d1, [fp, #-0x38]
    // 0x671208: ldur            x0, [fp, #-0x10]
    // 0x67120c: LoadField: r3 = r0->field_7
    //     0x67120c: ldur            x3, [x0, #7]
    // 0x671210: str             wzr, [x3, #0xc]
    // 0x671214: fadd            d4, d2, d0
    // 0x671218: LoadField: d0 = r2->field_b
    //     0x671218: ldur            d0, [x2, #0xb]
    // 0x67121c: fadd            d2, d1, d0
    // 0x671220: r0 = inline_Allocate_Double()
    //     0x671220: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x671224: add             x0, x0, #0x10
    //     0x671228: cmp             x2, x0
    //     0x67122c: b.ls            #0x67142c
    //     0x671230: str             x0, [THR, #0x60]  ; THR::top
    //     0x671234: sub             x0, x0, #0xf
    //     0x671238: mov             x2, #0xd108
    //     0x67123c: movk            x2, #3, lsl #16
    //     0x671240: stur            x2, [x0, #-1]
    // 0x671244: StoreField: r0->field_7 = d4
    //     0x671244: stur            d4, [x0, #7]
    // 0x671248: stur            x0, [fp, #-0x10]
    // 0x67124c: ldur            x16, [fp, #-8]
    // 0x671250: stp             x0, x16, [SP, #-0x10]!
    // 0x671254: SaveReg d2
    //     0x671254: str             d2, [SP, #-8]!
    // 0x671258: r0 = lineTo()
    //     0x671258: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x67125c: add             SP, SP, #0x18
    // 0x671260: ldr             x0, [fp, #0x28]
    // 0x671264: LoadField: d0 = r0->field_b
    //     0x671264: ldur            d0, [x0, #0xb]
    // 0x671268: ldur            d1, [fp, #-0x28]
    // 0x67126c: fsub            d2, d1, d0
    // 0x671270: ldur            x16, [fp, #-8]
    // 0x671274: ldur            lr, [fp, #-0x10]
    // 0x671278: stp             lr, x16, [SP, #-0x10]!
    // 0x67127c: SaveReg d2
    //     0x67127c: str             d2, [SP, #-8]!
    // 0x671280: r0 = lineTo()
    //     0x671280: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x671284: add             SP, SP, #0x18
    // 0x671288: ldr             x16, [fp, #0x38]
    // 0x67128c: ldur            lr, [fp, #-8]
    // 0x671290: stp             lr, x16, [SP, #-0x10]!
    // 0x671294: ldur            x16, [fp, #-0x18]
    // 0x671298: SaveReg r16
    //     0x671298: str             x16, [SP, #-8]!
    // 0x67129c: r0 = drawPath()
    //     0x67129c: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0x6712a0: add             SP, SP, #0x18
    // 0x6712a4: r0 = Null
    //     0x6712a4: mov             x0, NULL
    // 0x6712a8: LeaveFrame
    //     0x6712a8: mov             SP, fp
    //     0x6712ac: ldp             fp, lr, [SP], #0x10
    // 0x6712b0: ret
    //     0x6712b0: ret             
    // 0x6712b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6712b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6712b8: b               #0x6709d8
    // 0x6712bc: stp             q0, q1, [SP, #-0x20]!
    // 0x6712c0: SaveReg r0
    //     0x6712c0: str             x0, [SP, #-8]!
    // 0x6712c4: r0 = AllocateDouble()
    //     0x6712c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6712c8: mov             x1, x0
    // 0x6712cc: RestoreReg r0
    //     0x6712cc: ldr             x0, [SP], #8
    // 0x6712d0: ldp             q0, q1, [SP], #0x20
    // 0x6712d4: b               #0x670b08
    // 0x6712d8: SaveReg d0
    //     0x6712d8: str             q0, [SP, #-0x10]!
    // 0x6712dc: SaveReg r0
    //     0x6712dc: str             x0, [SP, #-8]!
    // 0x6712e0: r0 = AllocateDouble()
    //     0x6712e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6712e4: mov             x1, x0
    // 0x6712e8: RestoreReg r0
    //     0x6712e8: ldr             x0, [SP], #8
    // 0x6712ec: RestoreReg d0
    //     0x6712ec: ldr             q0, [SP], #0x10
    // 0x6712f0: b               #0x670b50
    // 0x6712f4: stp             q4, q6, [SP, #-0x20]!
    // 0x6712f8: stp             q1, q2, [SP, #-0x20]!
    // 0x6712fc: stp             x3, x4, [SP, #-0x10]!
    // 0x671300: stp             x1, x2, [SP, #-0x10]!
    // 0x671304: SaveReg r0
    //     0x671304: str             x0, [SP, #-8]!
    // 0x671308: r0 = AllocateDouble()
    //     0x671308: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67130c: mov             x5, x0
    // 0x671310: RestoreReg r0
    //     0x671310: ldr             x0, [SP], #8
    // 0x671314: ldp             x1, x2, [SP], #0x10
    // 0x671318: ldp             x3, x4, [SP], #0x10
    // 0x67131c: ldp             q1, q2, [SP], #0x20
    // 0x671320: ldp             q4, q6, [SP], #0x20
    // 0x671324: b               #0x670bf0
    // 0x671328: SaveReg d2
    //     0x671328: str             q2, [SP, #-0x10]!
    // 0x67132c: SaveReg r0
    //     0x67132c: str             x0, [SP, #-8]!
    // 0x671330: r0 = AllocateDouble()
    //     0x671330: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x671334: mov             x1, x0
    // 0x671338: RestoreReg r0
    //     0x671338: ldr             x0, [SP], #8
    // 0x67133c: RestoreReg d2
    //     0x67133c: ldr             q2, [SP], #0x10
    // 0x671340: b               #0x670c3c
    // 0x671344: stp             q0, q1, [SP, #-0x20]!
    // 0x671348: SaveReg r0
    //     0x671348: str             x0, [SP, #-8]!
    // 0x67134c: r0 = AllocateDouble()
    //     0x67134c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x671350: mov             x1, x0
    // 0x671354: RestoreReg r0
    //     0x671354: ldr             x0, [SP], #8
    // 0x671358: ldp             q0, q1, [SP], #0x20
    // 0x67135c: b               #0x670d4c
    // 0x671360: stp             q4, q5, [SP, #-0x20]!
    // 0x671364: stp             q1, q3, [SP, #-0x20]!
    // 0x671368: stp             x3, x4, [SP, #-0x10]!
    // 0x67136c: stp             x1, x2, [SP, #-0x10]!
    // 0x671370: SaveReg r0
    //     0x671370: str             x0, [SP, #-8]!
    // 0x671374: r0 = AllocateDouble()
    //     0x671374: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x671378: mov             x5, x0
    // 0x67137c: RestoreReg r0
    //     0x67137c: ldr             x0, [SP], #8
    // 0x671380: ldp             x1, x2, [SP], #0x10
    // 0x671384: ldp             x3, x4, [SP], #0x10
    // 0x671388: ldp             q1, q3, [SP], #0x20
    // 0x67138c: ldp             q4, q5, [SP], #0x20
    // 0x671390: b               #0x670e0c
    // 0x671394: stp             q0, q1, [SP, #-0x20]!
    // 0x671398: SaveReg r0
    //     0x671398: str             x0, [SP, #-8]!
    // 0x67139c: r0 = AllocateDouble()
    //     0x67139c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6713a0: mov             x1, x0
    // 0x6713a4: RestoreReg r0
    //     0x6713a4: ldr             x0, [SP], #8
    // 0x6713a8: ldp             q0, q1, [SP], #0x20
    // 0x6713ac: b               #0x670f44
    // 0x6713b0: SaveReg d0
    //     0x6713b0: str             q0, [SP, #-0x10]!
    // 0x6713b4: SaveReg r0
    //     0x6713b4: str             x0, [SP, #-8]!
    // 0x6713b8: r0 = AllocateDouble()
    //     0x6713b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6713bc: mov             x1, x0
    // 0x6713c0: RestoreReg r0
    //     0x6713c0: ldr             x0, [SP], #8
    // 0x6713c4: RestoreReg d0
    //     0x6713c4: ldr             q0, [SP], #0x10
    // 0x6713c8: b               #0x670f8c
    // 0x6713cc: stp             q4, q6, [SP, #-0x20]!
    // 0x6713d0: stp             q1, q2, [SP, #-0x20]!
    // 0x6713d4: stp             x3, x4, [SP, #-0x10]!
    // 0x6713d8: stp             x1, x2, [SP, #-0x10]!
    // 0x6713dc: SaveReg r0
    //     0x6713dc: str             x0, [SP, #-8]!
    // 0x6713e0: r0 = AllocateDouble()
    //     0x6713e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6713e4: mov             x5, x0
    // 0x6713e8: RestoreReg r0
    //     0x6713e8: ldr             x0, [SP], #8
    // 0x6713ec: ldp             x1, x2, [SP], #0x10
    // 0x6713f0: ldp             x3, x4, [SP], #0x10
    // 0x6713f4: ldp             q1, q2, [SP], #0x20
    // 0x6713f8: ldp             q4, q6, [SP], #0x20
    // 0x6713fc: b               #0x67102c
    // 0x671400: SaveReg d2
    //     0x671400: str             q2, [SP, #-0x10]!
    // 0x671404: r0 = AllocateDouble()
    //     0x671404: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x671408: RestoreReg d2
    //     0x671408: ldr             q2, [SP], #0x10
    // 0x67140c: b               #0x671078
    // 0x671410: stp             q0, q1, [SP, #-0x20]!
    // 0x671414: SaveReg r0
    //     0x671414: str             x0, [SP, #-8]!
    // 0x671418: r0 = AllocateDouble()
    //     0x671418: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67141c: mov             x1, x0
    // 0x671420: RestoreReg r0
    //     0x671420: ldr             x0, [SP], #8
    // 0x671424: ldp             q0, q1, [SP], #0x20
    // 0x671428: b               #0x671188
    // 0x67142c: stp             q3, q4, [SP, #-0x20]!
    // 0x671430: SaveReg d2
    //     0x671430: str             q2, [SP, #-0x10]!
    // 0x671434: SaveReg r1
    //     0x671434: str             x1, [SP, #-8]!
    // 0x671438: r0 = AllocateDouble()
    //     0x671438: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x67143c: RestoreReg r1
    //     0x67143c: ldr             x1, [SP], #8
    // 0x671440: RestoreReg d2
    //     0x671440: ldr             q2, [SP], #0x10
    // 0x671444: ldp             q3, q4, [SP], #0x20
    // 0x671448: b               #0x671244
  }
}

// class id: 2172, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class ShapeBorder extends Object {

  ShapeBorder +(ShapeBorder, ShapeBorder) {
    // ** addr: 0x70ded8, size: 0x68
    // 0x70ded8: EnterFrame
    //     0x70ded8: stp             fp, lr, [SP, #-0x10]!
    //     0x70dedc: mov             fp, SP
    // 0x70dee0: ldr             x0, [fp, #0x10]
    // 0x70dee4: r2 = Null
    //     0x70dee4: mov             x2, NULL
    // 0x70dee8: r1 = Null
    //     0x70dee8: mov             x1, NULL
    // 0x70deec: r4 = 59
    //     0x70deec: mov             x4, #0x3b
    // 0x70def0: branchIfSmi(r0, 0x70defc)
    //     0x70def0: tbz             w0, #0, #0x70defc
    // 0x70def4: r4 = LoadClassIdInstr(r0)
    //     0x70def4: ldur            x4, [x0, #-1]
    //     0x70def8: ubfx            x4, x4, #0xc, #0x14
    // 0x70defc: sub             x4, x4, #0x87d
    // 0x70df00: cmp             x4, #0xf
    // 0x70df04: b.ls            #0x70df1c
    // 0x70df08: r8 = ShapeBorder
    //     0x70df08: add             x8, PP, #0x28, lsl #12  ; [pp+0x288b0] Type: ShapeBorder
    //     0x70df0c: ldr             x8, [x8, #0x8b0]
    // 0x70df10: r3 = Null
    //     0x70df10: add             x3, PP, #0x28, lsl #12  ; [pp+0x288b8] Null
    //     0x70df14: ldr             x3, [x3, #0x8b8]
    // 0x70df18: r0 = DefaultTypeTest()
    //     0x70df18: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x70df1c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x70df1c: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x70df20: r0 = Throw()
    //     0x70df20: bl              #0xd67e38  ; ThrowStub
    // 0x70df24: brk             #0
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0x70f880, size: 0x78
    // 0x70f880: EnterFrame
    //     0x70f880: stp             fp, lr, [SP, #-0x10]!
    //     0x70f884: mov             fp, SP
    // 0x70f888: CheckStackOverflow
    //     0x70f888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70f88c: cmp             SP, x16
    //     0x70f890: b.ls            #0x70f8f0
    // 0x70f894: ldr             x0, [fp, #0x18]
    // 0x70f898: cmp             w0, NULL
    // 0x70f89c: b.ne            #0x70f8e0
    // 0x70f8a0: ldr             x0, [fp, #0x20]
    // 0x70f8a4: ldr             d1, [fp, #0x10]
    // 0x70f8a8: d0 = 1.000000
    //     0x70f8a8: fmov            d0, #1.00000000
    // 0x70f8ac: fsub            d2, d0, d1
    // 0x70f8b0: r1 = LoadClassIdInstr(r0)
    //     0x70f8b0: ldur            x1, [x0, #-1]
    //     0x70f8b4: ubfx            x1, x1, #0xc, #0x14
    // 0x70f8b8: SaveReg r0
    //     0x70f8b8: str             x0, [SP, #-8]!
    // 0x70f8bc: SaveReg d2
    //     0x70f8bc: str             d2, [SP, #-8]!
    // 0x70f8c0: mov             x0, x1
    // 0x70f8c4: r0 = GDT[cid_x0 + -0xfa0]()
    //     0x70f8c4: sub             lr, x0, #0xfa0
    //     0x70f8c8: ldr             lr, [x21, lr, lsl #3]
    //     0x70f8cc: blr             lr
    // 0x70f8d0: add             SP, SP, #0x10
    // 0x70f8d4: LeaveFrame
    //     0x70f8d4: mov             SP, fp
    //     0x70f8d8: ldp             fp, lr, [SP], #0x10
    // 0x70f8dc: ret
    //     0x70f8dc: ret             
    // 0x70f8e0: r0 = Null
    //     0x70f8e0: mov             x0, NULL
    // 0x70f8e4: LeaveFrame
    //     0x70f8e4: mov             SP, fp
    //     0x70f8e8: ldp             fp, lr, [SP], #0x10
    // 0x70f8ec: ret
    //     0x70f8ec: ret             
    // 0x70f8f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70f8f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70f8f4: b               #0x70f894
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x710eb4, size: 0x70
    // 0x710eb4: EnterFrame
    //     0x710eb4: stp             fp, lr, [SP, #-0x10]!
    //     0x710eb8: mov             fp, SP
    // 0x710ebc: CheckStackOverflow
    //     0x710ebc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x710ec0: cmp             SP, x16
    //     0x710ec4: b.ls            #0x710f1c
    // 0x710ec8: ldr             x0, [fp, #0x18]
    // 0x710ecc: cmp             w0, NULL
    // 0x710ed0: b.ne            #0x710f0c
    // 0x710ed4: ldr             x0, [fp, #0x20]
    // 0x710ed8: ldr             d0, [fp, #0x10]
    // 0x710edc: r1 = LoadClassIdInstr(r0)
    //     0x710edc: ldur            x1, [x0, #-1]
    //     0x710ee0: ubfx            x1, x1, #0xc, #0x14
    // 0x710ee4: SaveReg r0
    //     0x710ee4: str             x0, [SP, #-8]!
    // 0x710ee8: SaveReg d0
    //     0x710ee8: str             d0, [SP, #-8]!
    // 0x710eec: mov             x0, x1
    // 0x710ef0: r0 = GDT[cid_x0 + -0xfa0]()
    //     0x710ef0: sub             lr, x0, #0xfa0
    //     0x710ef4: ldr             lr, [x21, lr, lsl #3]
    //     0x710ef8: blr             lr
    // 0x710efc: add             SP, SP, #0x10
    // 0x710f00: LeaveFrame
    //     0x710f00: mov             SP, fp
    //     0x710f04: ldp             fp, lr, [SP], #0x10
    // 0x710f08: ret
    //     0x710f08: ret             
    // 0x710f0c: r0 = Null
    //     0x710f0c: mov             x0, NULL
    // 0x710f10: LeaveFrame
    //     0x710f10: mov             SP, fp
    //     0x710f14: ldp             fp, lr, [SP], #0x10
    // 0x710f18: ret
    //     0x710f18: ret             
    // 0x710f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x710f1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x710f20: b               #0x710ec8
  }
  _ toString(/* No info */) {
    // ** addr: 0xadb990, size: 0xc
    // 0xadb990: r0 = "ShapeBorder()"
    //     0xadb990: add             x0, PP, #0xe, lsl #12  ; [pp+0xe7e8] "ShapeBorder()"
    //     0xadb994: ldr             x0, [x0, #0x7e8]
    // 0xadb998: ret
    //     0xadb998: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbecbbc, size: 0xe8
    // 0xbecbbc: EnterFrame
    //     0xbecbbc: stp             fp, lr, [SP, #-0x10]!
    //     0xbecbc0: mov             fp, SP
    // 0xbecbc4: CheckStackOverflow
    //     0xbecbc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbecbc8: cmp             SP, x16
    //     0xbecbcc: b.ls            #0xbecc9c
    // 0xbecbd0: ldr             x1, [fp, #0x18]
    // 0xbecbd4: cmp             w1, NULL
    // 0xbecbd8: b.eq            #0xbecc0c
    // 0xbecbdc: ldr             d0, [fp, #0x10]
    // 0xbecbe0: r0 = LoadClassIdInstr(r1)
    //     0xbecbe0: ldur            x0, [x1, #-1]
    //     0xbecbe4: ubfx            x0, x0, #0xc, #0x14
    // 0xbecbe8: ldr             x16, [fp, #0x20]
    // 0xbecbec: stp             x16, x1, [SP, #-0x10]!
    // 0xbecbf0: SaveReg d0
    //     0xbecbf0: str             d0, [SP, #-8]!
    // 0xbecbf4: r0 = GDT[cid_x0 + 0xc591]()
    //     0xbecbf4: mov             x17, #0xc591
    //     0xbecbf8: add             lr, x0, x17
    //     0xbecbfc: ldr             lr, [x21, lr, lsl #3]
    //     0xbecc00: blr             lr
    // 0xbecc04: add             SP, SP, #0x18
    // 0xbecc08: b               #0xbecc10
    // 0xbecc0c: r0 = Null
    //     0xbecc0c: mov             x0, NULL
    // 0xbecc10: cmp             w0, NULL
    // 0xbecc14: b.ne            #0xbecc58
    // 0xbecc18: ldr             x1, [fp, #0x20]
    // 0xbecc1c: cmp             w1, NULL
    // 0xbecc20: b.eq            #0xbecc58
    // 0xbecc24: ldr             d0, [fp, #0x10]
    // 0xbecc28: r0 = LoadClassIdInstr(r1)
    //     0xbecc28: ldur            x0, [x1, #-1]
    //     0xbecc2c: ubfx            x0, x0, #0xc, #0x14
    // 0xbecc30: ldr             x16, [fp, #0x18]
    // 0xbecc34: stp             x16, x1, [SP, #-0x10]!
    // 0xbecc38: SaveReg d0
    //     0xbecc38: str             d0, [SP, #-8]!
    // 0xbecc3c: r0 = GDT[cid_x0 + 0xc5cb]()
    //     0xbecc3c: mov             x17, #0xc5cb
    //     0xbecc40: add             lr, x0, x17
    //     0xbecc44: ldr             lr, [x21, lr, lsl #3]
    //     0xbecc48: blr             lr
    // 0xbecc4c: add             SP, SP, #0x18
    // 0xbecc50: mov             x1, x0
    // 0xbecc54: b               #0xbecc5c
    // 0xbecc58: mov             x1, x0
    // 0xbecc5c: cmp             w1, NULL
    // 0xbecc60: b.ne            #0xbecc8c
    // 0xbecc64: ldr             d0, [fp, #0x10]
    // 0xbecc68: d1 = 0.500000
    //     0xbecc68: fmov            d1, #0.50000000
    // 0xbecc6c: fcmp            d0, d1
    // 0xbecc70: b.vs            #0xbecc80
    // 0xbecc74: b.ge            #0xbecc80
    // 0xbecc78: ldr             x2, [fp, #0x20]
    // 0xbecc7c: b               #0xbecc84
    // 0xbecc80: ldr             x2, [fp, #0x18]
    // 0xbecc84: mov             x0, x2
    // 0xbecc88: b               #0xbecc90
    // 0xbecc8c: mov             x0, x1
    // 0xbecc90: LeaveFrame
    //     0xbecc90: mov             SP, fp
    //     0xbecc94: ldp             fp, lr, [SP], #0x10
    // 0xbecc98: ret
    //     0xbecc98: ret             
    // 0xbecc9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbecc9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbecca0: b               #0xbecbd0
  }
}

// class id: 2174, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class OutlinedBorder extends ShapeBorder {

  [closure] static OutlinedBorder? lerp(dynamic, OutlinedBorder?, OutlinedBorder?, double) {
    // ** addr: 0xbf0d9c, size: 0x44
    // 0xbf0d9c: EnterFrame
    //     0xbf0d9c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0da0: mov             fp, SP
    // 0xbf0da4: CheckStackOverflow
    //     0xbf0da4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf0da8: cmp             SP, x16
    //     0xbf0dac: b.ls            #0xbf0dd8
    // 0xbf0db0: ldr             x16, [fp, #0x20]
    // 0xbf0db4: ldr             lr, [fp, #0x18]
    // 0xbf0db8: stp             lr, x16, [SP, #-0x10]!
    // 0xbf0dbc: ldr             x16, [fp, #0x10]
    // 0xbf0dc0: SaveReg r16
    //     0xbf0dc0: str             x16, [SP, #-8]!
    // 0xbf0dc4: r0 = lerp()
    //     0xbf0dc4: bl              #0xbf0de0  ; [package:flutter/src/painting/borders.dart] OutlinedBorder::lerp
    // 0xbf0dc8: add             SP, SP, #0x18
    // 0xbf0dcc: LeaveFrame
    //     0xbf0dcc: mov             SP, fp
    //     0xbf0dd0: ldp             fp, lr, [SP], #0x10
    // 0xbf0dd4: ret
    //     0xbf0dd4: ret             
    // 0xbf0dd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0dd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0ddc: b               #0xbf0db0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf0de0, size: 0xf4
    // 0xbf0de0: EnterFrame
    //     0xbf0de0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0de4: mov             fp, SP
    // 0xbf0de8: CheckStackOverflow
    //     0xbf0de8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf0dec: cmp             SP, x16
    //     0xbf0df0: b.ls            #0xbf0ecc
    // 0xbf0df4: ldr             x1, [fp, #0x18]
    // 0xbf0df8: cmp             w1, NULL
    // 0xbf0dfc: b.eq            #0xbf0e34
    // 0xbf0e00: ldr             x2, [fp, #0x10]
    // 0xbf0e04: LoadField: d0 = r2->field_7
    //     0xbf0e04: ldur            d0, [x2, #7]
    // 0xbf0e08: r0 = LoadClassIdInstr(r1)
    //     0xbf0e08: ldur            x0, [x1, #-1]
    //     0xbf0e0c: ubfx            x0, x0, #0xc, #0x14
    // 0xbf0e10: ldr             x16, [fp, #0x20]
    // 0xbf0e14: stp             x16, x1, [SP, #-0x10]!
    // 0xbf0e18: SaveReg d0
    //     0xbf0e18: str             d0, [SP, #-8]!
    // 0xbf0e1c: r0 = GDT[cid_x0 + 0xc591]()
    //     0xbf0e1c: mov             x17, #0xc591
    //     0xbf0e20: add             lr, x0, x17
    //     0xbf0e24: ldr             lr, [x21, lr, lsl #3]
    //     0xbf0e28: blr             lr
    // 0xbf0e2c: add             SP, SP, #0x18
    // 0xbf0e30: b               #0xbf0e38
    // 0xbf0e34: r0 = Null
    //     0xbf0e34: mov             x0, NULL
    // 0xbf0e38: cmp             w0, NULL
    // 0xbf0e3c: b.ne            #0xbf0e84
    // 0xbf0e40: ldr             x1, [fp, #0x20]
    // 0xbf0e44: cmp             w1, NULL
    // 0xbf0e48: b.eq            #0xbf0e84
    // 0xbf0e4c: ldr             x2, [fp, #0x10]
    // 0xbf0e50: LoadField: d0 = r2->field_7
    //     0xbf0e50: ldur            d0, [x2, #7]
    // 0xbf0e54: r0 = LoadClassIdInstr(r1)
    //     0xbf0e54: ldur            x0, [x1, #-1]
    //     0xbf0e58: ubfx            x0, x0, #0xc, #0x14
    // 0xbf0e5c: ldr             x16, [fp, #0x18]
    // 0xbf0e60: stp             x16, x1, [SP, #-0x10]!
    // 0xbf0e64: SaveReg d0
    //     0xbf0e64: str             d0, [SP, #-8]!
    // 0xbf0e68: r0 = GDT[cid_x0 + 0xc5cb]()
    //     0xbf0e68: mov             x17, #0xc5cb
    //     0xbf0e6c: add             lr, x0, x17
    //     0xbf0e70: ldr             lr, [x21, lr, lsl #3]
    //     0xbf0e74: blr             lr
    // 0xbf0e78: add             SP, SP, #0x18
    // 0xbf0e7c: mov             x1, x0
    // 0xbf0e80: b               #0xbf0e88
    // 0xbf0e84: mov             x1, x0
    // 0xbf0e88: cmp             w1, NULL
    // 0xbf0e8c: b.ne            #0xbf0ebc
    // 0xbf0e90: ldr             x2, [fp, #0x10]
    // 0xbf0e94: d0 = 0.500000
    //     0xbf0e94: fmov            d0, #0.50000000
    // 0xbf0e98: LoadField: d1 = r2->field_7
    //     0xbf0e98: ldur            d1, [x2, #7]
    // 0xbf0e9c: fcmp            d1, d0
    // 0xbf0ea0: b.vs            #0xbf0eb0
    // 0xbf0ea4: b.ge            #0xbf0eb0
    // 0xbf0ea8: ldr             x2, [fp, #0x20]
    // 0xbf0eac: b               #0xbf0eb4
    // 0xbf0eb0: ldr             x2, [fp, #0x18]
    // 0xbf0eb4: mov             x0, x2
    // 0xbf0eb8: b               #0xbf0ec0
    // 0xbf0ebc: mov             x0, x1
    // 0xbf0ec0: LeaveFrame
    //     0xbf0ec0: mov             SP, fp
    //     0xbf0ec4: ldp             fp, lr, [SP], #0x10
    // 0xbf0ec8: ret
    //     0xbf0ec8: ret             
    // 0xbf0ecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0ecc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0ed0: b               #0xbf0df4
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0xceedc4, size: 0xa8
    // 0xceedc4: EnterFrame
    //     0xceedc4: stp             fp, lr, [SP, #-0x10]!
    //     0xceedc8: mov             fp, SP
    // 0xceedcc: AllocStack(0x8)
    //     0xceedcc: sub             SP, SP, #8
    // 0xceedd0: d2 = 1.000000
    //     0xceedd0: fmov            d2, #1.00000000
    // 0xceedd4: d1 = 2.000000
    //     0xceedd4: fmov            d1, #2.00000000
    // 0xceedd8: d0 = 0.000000
    //     0xceedd8: eor             v0.16b, v0.16b, v0.16b
    // 0xceeddc: ldr             x0, [fp, #0x10]
    // 0xceede0: LoadField: r1 = r0->field_7
    //     0xceede0: ldur            w1, [x0, #7]
    // 0xceede4: DecompressPointer r1
    //     0xceede4: add             x1, x1, HEAP, lsl #32
    // 0xceede8: LoadField: d3 = r1->field_b
    //     0xceede8: ldur            d3, [x1, #0xb]
    // 0xceedec: LoadField: d4 = r1->field_17
    //     0xceedec: ldur            d4, [x1, #0x17]
    // 0xceedf0: fadd            d5, d2, d4
    // 0xceedf4: fdiv            d4, d5, d1
    // 0xceedf8: fsub            d1, d2, d4
    // 0xceedfc: fmul            d2, d3, d1
    // 0xceee00: fcmp            d2, d0
    // 0xceee04: b.vs            #0xceee14
    // 0xceee08: b.le            #0xceee14
    // 0xceee0c: mov             v0.16b, v2.16b
    // 0xceee10: b               #0xceee44
    // 0xceee14: fcmp            d2, d0
    // 0xceee18: b.vs            #0xceee28
    // 0xceee1c: b.ge            #0xceee28
    // 0xceee20: d0 = 0.000000
    //     0xceee20: eor             v0.16b, v0.16b, v0.16b
    // 0xceee24: b               #0xceee44
    // 0xceee28: fcmp            d2, d0
    // 0xceee2c: b.vs            #0xceee40
    // 0xceee30: b.ne            #0xceee40
    // 0xceee34: fadd            d1, d2, d0
    // 0xceee38: mov             v0.16b, v1.16b
    // 0xceee3c: b               #0xceee44
    // 0xceee40: mov             v0.16b, v2.16b
    // 0xceee44: stur            d0, [fp, #-8]
    // 0xceee48: r0 = EdgeInsets()
    //     0xceee48: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xceee4c: ldur            d0, [fp, #-8]
    // 0xceee50: StoreField: r0->field_7 = d0
    //     0xceee50: stur            d0, [x0, #7]
    // 0xceee54: StoreField: r0->field_f = d0
    //     0xceee54: stur            d0, [x0, #0xf]
    // 0xceee58: StoreField: r0->field_17 = d0
    //     0xceee58: stur            d0, [x0, #0x17]
    // 0xceee5c: StoreField: r0->field_1f = d0
    //     0xceee5c: stur            d0, [x0, #0x1f]
    // 0xceee60: LeaveFrame
    //     0xceee60: mov             SP, fp
    //     0xceee64: ldp             fp, lr, [SP], #0x10
    // 0xceee68: ret
    //     0xceee68: ret             
  }
}

// class id: 2790, size: 0x20, field offset: 0x8
//   const constructor, 
class BorderSide extends _DiagnosticableTree&Object&Diagnosticable {

  Color field_8;
  _Mint field_c;
  BorderStyle field_14;
  _Double field_18;

  static _ lerp(/* No info */) {
    // ** addr: 0x5b4870, size: 0x480
    // 0x5b4870: EnterFrame
    //     0x5b4870: stp             fp, lr, [SP, #-0x10]!
    //     0x5b4874: mov             fp, SP
    // 0x5b4878: AllocStack(0x38)
    //     0x5b4878: sub             SP, SP, #0x38
    // 0x5b487c: d0 = 0.000000
    //     0x5b487c: eor             v0.16b, v0.16b, v0.16b
    // 0x5b4880: CheckStackOverflow
    //     0x5b4880: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b4884: cmp             SP, x16
    //     0x5b4888: b.ls            #0x5b4c28
    // 0x5b488c: ldr             d1, [fp, #0x10]
    // 0x5b4890: fcmp            d1, d0
    // 0x5b4894: b.vs            #0x5b48ac
    // 0x5b4898: b.ne            #0x5b48ac
    // 0x5b489c: ldr             x0, [fp, #0x20]
    // 0x5b48a0: LeaveFrame
    //     0x5b48a0: mov             SP, fp
    //     0x5b48a4: ldp             fp, lr, [SP], #0x10
    // 0x5b48a8: ret
    //     0x5b48a8: ret             
    // 0x5b48ac: d2 = 1.000000
    //     0x5b48ac: fmov            d2, #1.00000000
    // 0x5b48b0: fcmp            d1, d2
    // 0x5b48b4: b.vs            #0x5b48cc
    // 0x5b48b8: b.ne            #0x5b48cc
    // 0x5b48bc: ldr             x0, [fp, #0x18]
    // 0x5b48c0: LeaveFrame
    //     0x5b48c0: mov             SP, fp
    //     0x5b48c4: ldp             fp, lr, [SP], #0x10
    // 0x5b48c8: ret
    //     0x5b48c8: ret             
    // 0x5b48cc: ldr             x1, [fp, #0x20]
    // 0x5b48d0: ldr             x0, [fp, #0x18]
    // 0x5b48d4: LoadField: d2 = r1->field_b
    //     0x5b48d4: ldur            d2, [x1, #0xb]
    // 0x5b48d8: LoadField: d3 = r0->field_b
    //     0x5b48d8: ldur            d3, [x0, #0xb]
    // 0x5b48dc: r2 = inline_Allocate_Double()
    //     0x5b48dc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x5b48e0: add             x2, x2, #0x10
    //     0x5b48e4: cmp             x3, x2
    //     0x5b48e8: b.ls            #0x5b4c30
    //     0x5b48ec: str             x2, [THR, #0x60]  ; THR::top
    //     0x5b48f0: sub             x2, x2, #0xf
    //     0x5b48f4: mov             x3, #0xd108
    //     0x5b48f8: movk            x3, #3, lsl #16
    //     0x5b48fc: stur            x3, [x2, #-1]
    // 0x5b4900: StoreField: r2->field_7 = d1
    //     0x5b4900: stur            d1, [x2, #7]
    // 0x5b4904: stur            x2, [fp, #-8]
    // 0x5b4908: r3 = inline_Allocate_Double()
    //     0x5b4908: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x5b490c: add             x3, x3, #0x10
    //     0x5b4910: cmp             x4, x3
    //     0x5b4914: b.ls            #0x5b4c54
    //     0x5b4918: str             x3, [THR, #0x60]  ; THR::top
    //     0x5b491c: sub             x3, x3, #0xf
    //     0x5b4920: mov             x4, #0xd108
    //     0x5b4924: movk            x4, #3, lsl #16
    //     0x5b4928: stur            x4, [x3, #-1]
    // 0x5b492c: StoreField: r3->field_7 = d2
    //     0x5b492c: stur            d2, [x3, #7]
    // 0x5b4930: r4 = inline_Allocate_Double()
    //     0x5b4930: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x5b4934: add             x4, x4, #0x10
    //     0x5b4938: cmp             x5, x4
    //     0x5b493c: b.ls            #0x5b4c80
    //     0x5b4940: str             x4, [THR, #0x60]  ; THR::top
    //     0x5b4944: sub             x4, x4, #0xf
    //     0x5b4948: mov             x5, #0xd108
    //     0x5b494c: movk            x5, #3, lsl #16
    //     0x5b4950: stur            x5, [x4, #-1]
    // 0x5b4954: StoreField: r4->field_7 = d3
    //     0x5b4954: stur            d3, [x4, #7]
    // 0x5b4958: stp             x4, x3, [SP, #-0x10]!
    // 0x5b495c: SaveReg r2
    //     0x5b495c: str             x2, [SP, #-8]!
    // 0x5b4960: r0 = lerpDouble()
    //     0x5b4960: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x5b4964: add             SP, SP, #0x18
    // 0x5b4968: cmp             w0, NULL
    // 0x5b496c: b.eq            #0x5b4ca4
    // 0x5b4970: LoadField: d0 = r0->field_7
    //     0x5b4970: ldur            d0, [x0, #7]
    // 0x5b4974: stur            d0, [fp, #-0x30]
    // 0x5b4978: d1 = 0.000000
    //     0x5b4978: eor             v1.16b, v1.16b, v1.16b
    // 0x5b497c: fcmp            d0, d1
    // 0x5b4980: b.vs            #0x5b499c
    // 0x5b4984: b.ge            #0x5b499c
    // 0x5b4988: r0 = Instance_BorderSide
    //     0x5b4988: add             x0, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x5b498c: ldr             x0, [x0, #0x2f0]
    // 0x5b4990: LeaveFrame
    //     0x5b4990: mov             SP, fp
    //     0x5b4994: ldp             fp, lr, [SP], #0x10
    // 0x5b4998: ret
    //     0x5b4998: ret             
    // 0x5b499c: ldr             x1, [fp, #0x20]
    // 0x5b49a0: ldr             x0, [fp, #0x18]
    // 0x5b49a4: LoadField: r2 = r1->field_13
    //     0x5b49a4: ldur            w2, [x1, #0x13]
    // 0x5b49a8: DecompressPointer r2
    //     0x5b49a8: add             x2, x2, HEAP, lsl #32
    // 0x5b49ac: stur            x2, [fp, #-0x10]
    // 0x5b49b0: LoadField: r3 = r0->field_13
    //     0x5b49b0: ldur            w3, [x0, #0x13]
    // 0x5b49b4: DecompressPointer r3
    //     0x5b49b4: add             x3, x3, HEAP, lsl #32
    // 0x5b49b8: stur            x3, [fp, #-0x20]
    // 0x5b49bc: cmp             w2, w3
    // 0x5b49c0: b.ne            #0x5b4a44
    // 0x5b49c4: LoadField: d1 = r1->field_17
    //     0x5b49c4: ldur            d1, [x1, #0x17]
    // 0x5b49c8: stur            d1, [fp, #-0x28]
    // 0x5b49cc: LoadField: d2 = r0->field_17
    //     0x5b49cc: ldur            d2, [x0, #0x17]
    // 0x5b49d0: fcmp            d1, d2
    // 0x5b49d4: b.vs            #0x5b4a44
    // 0x5b49d8: b.ne            #0x5b4a44
    // 0x5b49dc: LoadField: r3 = r1->field_7
    //     0x5b49dc: ldur            w3, [x1, #7]
    // 0x5b49e0: DecompressPointer r3
    //     0x5b49e0: add             x3, x3, HEAP, lsl #32
    // 0x5b49e4: LoadField: r1 = r0->field_7
    //     0x5b49e4: ldur            w1, [x0, #7]
    // 0x5b49e8: DecompressPointer r1
    //     0x5b49e8: add             x1, x1, HEAP, lsl #32
    // 0x5b49ec: stp             x1, x3, [SP, #-0x10]!
    // 0x5b49f0: ldur            x16, [fp, #-8]
    // 0x5b49f4: SaveReg r16
    //     0x5b49f4: str             x16, [SP, #-8]!
    // 0x5b49f8: r0 = lerp()
    //     0x5b49f8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0x5b49fc: add             SP, SP, #0x18
    // 0x5b4a00: stur            x0, [fp, #-0x18]
    // 0x5b4a04: cmp             w0, NULL
    // 0x5b4a08: b.eq            #0x5b4ca8
    // 0x5b4a0c: r0 = BorderSide()
    //     0x5b4a0c: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x5b4a10: mov             x1, x0
    // 0x5b4a14: ldur            x0, [fp, #-0x18]
    // 0x5b4a18: StoreField: r1->field_7 = r0
    //     0x5b4a18: stur            w0, [x1, #7]
    // 0x5b4a1c: ldur            d0, [fp, #-0x30]
    // 0x5b4a20: StoreField: r1->field_b = d0
    //     0x5b4a20: stur            d0, [x1, #0xb]
    // 0x5b4a24: ldur            x2, [fp, #-0x10]
    // 0x5b4a28: StoreField: r1->field_13 = r2
    //     0x5b4a28: stur            w2, [x1, #0x13]
    // 0x5b4a2c: ldur            d0, [fp, #-0x28]
    // 0x5b4a30: StoreField: r1->field_17 = d0
    //     0x5b4a30: stur            d0, [x1, #0x17]
    // 0x5b4a34: mov             x0, x1
    // 0x5b4a38: LeaveFrame
    //     0x5b4a38: mov             SP, fp
    //     0x5b4a3c: ldp             fp, lr, [SP], #0x10
    // 0x5b4a40: ret
    //     0x5b4a40: ret             
    // 0x5b4a44: LoadField: r4 = r2->field_7
    //     0x5b4a44: ldur            x4, [x2, #7]
    // 0x5b4a48: cmp             x4, #0
    // 0x5b4a4c: b.gt            #0x5b4a70
    // 0x5b4a50: LoadField: r2 = r1->field_7
    //     0x5b4a50: ldur            w2, [x1, #7]
    // 0x5b4a54: DecompressPointer r2
    //     0x5b4a54: add             x2, x2, HEAP, lsl #32
    // 0x5b4a58: stp             xzr, x2, [SP, #-0x10]!
    // 0x5b4a5c: r0 = withAlpha()
    //     0x5b4a5c: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x5b4a60: add             SP, SP, #0x10
    // 0x5b4a64: mov             x2, x0
    // 0x5b4a68: ldr             x0, [fp, #0x20]
    // 0x5b4a6c: b               #0x5b4a80
    // 0x5b4a70: mov             x0, x1
    // 0x5b4a74: LoadField: r1 = r0->field_7
    //     0x5b4a74: ldur            w1, [x0, #7]
    // 0x5b4a78: DecompressPointer r1
    //     0x5b4a78: add             x1, x1, HEAP, lsl #32
    // 0x5b4a7c: mov             x2, x1
    // 0x5b4a80: ldur            x1, [fp, #-0x20]
    // 0x5b4a84: stur            x2, [fp, #-0x10]
    // 0x5b4a88: LoadField: r3 = r1->field_7
    //     0x5b4a88: ldur            x3, [x1, #7]
    // 0x5b4a8c: cmp             x3, #0
    // 0x5b4a90: b.gt            #0x5b4ab8
    // 0x5b4a94: ldr             x1, [fp, #0x18]
    // 0x5b4a98: LoadField: r3 = r1->field_7
    //     0x5b4a98: ldur            w3, [x1, #7]
    // 0x5b4a9c: DecompressPointer r3
    //     0x5b4a9c: add             x3, x3, HEAP, lsl #32
    // 0x5b4aa0: stp             xzr, x3, [SP, #-0x10]!
    // 0x5b4aa4: r0 = withAlpha()
    //     0x5b4aa4: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x5b4aa8: add             SP, SP, #0x10
    // 0x5b4aac: mov             x2, x0
    // 0x5b4ab0: ldr             x0, [fp, #0x18]
    // 0x5b4ab4: b               #0x5b4ac8
    // 0x5b4ab8: ldr             x0, [fp, #0x18]
    // 0x5b4abc: LoadField: r1 = r0->field_7
    //     0x5b4abc: ldur            w1, [x0, #7]
    // 0x5b4ac0: DecompressPointer r1
    //     0x5b4ac0: add             x1, x1, HEAP, lsl #32
    // 0x5b4ac4: mov             x2, x1
    // 0x5b4ac8: ldr             x1, [fp, #0x20]
    // 0x5b4acc: LoadField: d0 = r1->field_17
    //     0x5b4acc: ldur            d0, [x1, #0x17]
    // 0x5b4ad0: stur            d0, [fp, #-0x38]
    // 0x5b4ad4: LoadField: d1 = r0->field_17
    //     0x5b4ad4: ldur            d1, [x0, #0x17]
    // 0x5b4ad8: stur            d1, [fp, #-0x28]
    // 0x5b4adc: fcmp            d0, d1
    // 0x5b4ae0: b.eq            #0x5b4bc4
    // 0x5b4ae4: ldur            d2, [fp, #-0x30]
    // 0x5b4ae8: ldur            x16, [fp, #-0x10]
    // 0x5b4aec: stp             x2, x16, [SP, #-0x10]!
    // 0x5b4af0: ldur            x16, [fp, #-8]
    // 0x5b4af4: SaveReg r16
    //     0x5b4af4: str             x16, [SP, #-8]!
    // 0x5b4af8: r0 = lerp()
    //     0x5b4af8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0x5b4afc: add             SP, SP, #0x18
    // 0x5b4b00: stur            x0, [fp, #-0x18]
    // 0x5b4b04: cmp             w0, NULL
    // 0x5b4b08: b.eq            #0x5b4cac
    // 0x5b4b0c: ldur            d0, [fp, #-0x38]
    // 0x5b4b10: r1 = inline_Allocate_Double()
    //     0x5b4b10: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x5b4b14: add             x1, x1, #0x10
    //     0x5b4b18: cmp             x2, x1
    //     0x5b4b1c: b.ls            #0x5b4cb0
    //     0x5b4b20: str             x1, [THR, #0x60]  ; THR::top
    //     0x5b4b24: sub             x1, x1, #0xf
    //     0x5b4b28: mov             x2, #0xd108
    //     0x5b4b2c: movk            x2, #3, lsl #16
    //     0x5b4b30: stur            x2, [x1, #-1]
    // 0x5b4b34: StoreField: r1->field_7 = d0
    //     0x5b4b34: stur            d0, [x1, #7]
    // 0x5b4b38: ldur            d0, [fp, #-0x28]
    // 0x5b4b3c: r2 = inline_Allocate_Double()
    //     0x5b4b3c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x5b4b40: add             x2, x2, #0x10
    //     0x5b4b44: cmp             x3, x2
    //     0x5b4b48: b.ls            #0x5b4ccc
    //     0x5b4b4c: str             x2, [THR, #0x60]  ; THR::top
    //     0x5b4b50: sub             x2, x2, #0xf
    //     0x5b4b54: mov             x3, #0xd108
    //     0x5b4b58: movk            x3, #3, lsl #16
    //     0x5b4b5c: stur            x3, [x2, #-1]
    // 0x5b4b60: StoreField: r2->field_7 = d0
    //     0x5b4b60: stur            d0, [x2, #7]
    // 0x5b4b64: stp             x2, x1, [SP, #-0x10]!
    // 0x5b4b68: ldur            x16, [fp, #-8]
    // 0x5b4b6c: SaveReg r16
    //     0x5b4b6c: str             x16, [SP, #-8]!
    // 0x5b4b70: r0 = lerpDouble()
    //     0x5b4b70: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x5b4b74: add             SP, SP, #0x18
    // 0x5b4b78: stur            x0, [fp, #-0x20]
    // 0x5b4b7c: cmp             w0, NULL
    // 0x5b4b80: b.eq            #0x5b4ce8
    // 0x5b4b84: r0 = BorderSide()
    //     0x5b4b84: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x5b4b88: mov             x1, x0
    // 0x5b4b8c: ldur            x0, [fp, #-0x18]
    // 0x5b4b90: StoreField: r1->field_7 = r0
    //     0x5b4b90: stur            w0, [x1, #7]
    // 0x5b4b94: ldur            d1, [fp, #-0x30]
    // 0x5b4b98: StoreField: r1->field_b = d1
    //     0x5b4b98: stur            d1, [x1, #0xb]
    // 0x5b4b9c: r0 = Instance_BorderStyle
    //     0x5b4b9c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b4ba0: ldr             x0, [x0, #0xbd0]
    // 0x5b4ba4: StoreField: r1->field_13 = r0
    //     0x5b4ba4: stur            w0, [x1, #0x13]
    // 0x5b4ba8: ldur            x0, [fp, #-0x20]
    // 0x5b4bac: LoadField: d0 = r0->field_7
    //     0x5b4bac: ldur            d0, [x0, #7]
    // 0x5b4bb0: StoreField: r1->field_17 = d0
    //     0x5b4bb0: stur            d0, [x1, #0x17]
    // 0x5b4bb4: mov             x0, x1
    // 0x5b4bb8: LeaveFrame
    //     0x5b4bb8: mov             SP, fp
    //     0x5b4bbc: ldp             fp, lr, [SP], #0x10
    // 0x5b4bc0: ret
    //     0x5b4bc0: ret             
    // 0x5b4bc4: ldur            d1, [fp, #-0x30]
    // 0x5b4bc8: r0 = Instance_BorderStyle
    //     0x5b4bc8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b4bcc: ldr             x0, [x0, #0xbd0]
    // 0x5b4bd0: ldur            x16, [fp, #-0x10]
    // 0x5b4bd4: stp             x2, x16, [SP, #-0x10]!
    // 0x5b4bd8: ldur            x16, [fp, #-8]
    // 0x5b4bdc: SaveReg r16
    //     0x5b4bdc: str             x16, [SP, #-8]!
    // 0x5b4be0: r0 = lerp()
    //     0x5b4be0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0x5b4be4: add             SP, SP, #0x18
    // 0x5b4be8: stur            x0, [fp, #-8]
    // 0x5b4bec: cmp             w0, NULL
    // 0x5b4bf0: b.eq            #0x5b4cec
    // 0x5b4bf4: r0 = BorderSide()
    //     0x5b4bf4: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x5b4bf8: ldur            x1, [fp, #-8]
    // 0x5b4bfc: StoreField: r0->field_7 = r1
    //     0x5b4bfc: stur            w1, [x0, #7]
    // 0x5b4c00: ldur            d0, [fp, #-0x30]
    // 0x5b4c04: StoreField: r0->field_b = d0
    //     0x5b4c04: stur            d0, [x0, #0xb]
    // 0x5b4c08: r1 = Instance_BorderStyle
    //     0x5b4c08: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b4c0c: ldr             x1, [x1, #0xbd0]
    // 0x5b4c10: StoreField: r0->field_13 = r1
    //     0x5b4c10: stur            w1, [x0, #0x13]
    // 0x5b4c14: ldur            d0, [fp, #-0x38]
    // 0x5b4c18: StoreField: r0->field_17 = d0
    //     0x5b4c18: stur            d0, [x0, #0x17]
    // 0x5b4c1c: LeaveFrame
    //     0x5b4c1c: mov             SP, fp
    //     0x5b4c20: ldp             fp, lr, [SP], #0x10
    // 0x5b4c24: ret
    //     0x5b4c24: ret             
    // 0x5b4c28: r0 = StackOverflowSharedWithFPURegs()
    //     0x5b4c28: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x5b4c2c: b               #0x5b488c
    // 0x5b4c30: stp             q2, q3, [SP, #-0x20]!
    // 0x5b4c34: stp             q0, q1, [SP, #-0x20]!
    // 0x5b4c38: stp             x0, x1, [SP, #-0x10]!
    // 0x5b4c3c: r0 = AllocateDouble()
    //     0x5b4c3c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b4c40: mov             x2, x0
    // 0x5b4c44: ldp             x0, x1, [SP], #0x10
    // 0x5b4c48: ldp             q0, q1, [SP], #0x20
    // 0x5b4c4c: ldp             q2, q3, [SP], #0x20
    // 0x5b4c50: b               #0x5b4900
    // 0x5b4c54: stp             q2, q3, [SP, #-0x20]!
    // 0x5b4c58: SaveReg d0
    //     0x5b4c58: str             q0, [SP, #-0x10]!
    // 0x5b4c5c: stp             x1, x2, [SP, #-0x10]!
    // 0x5b4c60: SaveReg r0
    //     0x5b4c60: str             x0, [SP, #-8]!
    // 0x5b4c64: r0 = AllocateDouble()
    //     0x5b4c64: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b4c68: mov             x3, x0
    // 0x5b4c6c: RestoreReg r0
    //     0x5b4c6c: ldr             x0, [SP], #8
    // 0x5b4c70: ldp             x1, x2, [SP], #0x10
    // 0x5b4c74: RestoreReg d0
    //     0x5b4c74: ldr             q0, [SP], #0x10
    // 0x5b4c78: ldp             q2, q3, [SP], #0x20
    // 0x5b4c7c: b               #0x5b492c
    // 0x5b4c80: stp             q0, q3, [SP, #-0x20]!
    // 0x5b4c84: stp             x2, x3, [SP, #-0x10]!
    // 0x5b4c88: stp             x0, x1, [SP, #-0x10]!
    // 0x5b4c8c: r0 = AllocateDouble()
    //     0x5b4c8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b4c90: mov             x4, x0
    // 0x5b4c94: ldp             x0, x1, [SP], #0x10
    // 0x5b4c98: ldp             x2, x3, [SP], #0x10
    // 0x5b4c9c: ldp             q0, q3, [SP], #0x20
    // 0x5b4ca0: b               #0x5b4954
    // 0x5b4ca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5b4ca4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5b4ca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5b4ca8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5b4cac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5b4cac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5b4cb0: SaveReg d0
    //     0x5b4cb0: str             q0, [SP, #-0x10]!
    // 0x5b4cb4: SaveReg r0
    //     0x5b4cb4: str             x0, [SP, #-8]!
    // 0x5b4cb8: r0 = AllocateDouble()
    //     0x5b4cb8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b4cbc: mov             x1, x0
    // 0x5b4cc0: RestoreReg r0
    //     0x5b4cc0: ldr             x0, [SP], #8
    // 0x5b4cc4: RestoreReg d0
    //     0x5b4cc4: ldr             q0, [SP], #0x10
    // 0x5b4cc8: b               #0x5b4b34
    // 0x5b4ccc: SaveReg d0
    //     0x5b4ccc: str             q0, [SP, #-0x10]!
    // 0x5b4cd0: stp             x0, x1, [SP, #-0x10]!
    // 0x5b4cd4: r0 = AllocateDouble()
    //     0x5b4cd4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b4cd8: mov             x2, x0
    // 0x5b4cdc: ldp             x0, x1, [SP], #0x10
    // 0x5b4ce0: RestoreReg d0
    //     0x5b4ce0: ldr             q0, [SP], #0x10
    // 0x5b4ce4: b               #0x5b4b60
    // 0x5b4ce8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5b4ce8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5b4cec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5b4cec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toStringShort(/* No info */) {
    // ** addr: 0xa77e10, size: 0xc
    // 0xa77e10: r0 = "BorderSide"
    //     0xa77e10: add             x0, PP, #0xd, lsl #12  ; [pp+0xdec8] "BorderSide"
    //     0xa77e14: ldr             x0, [x0, #0xec8]
    // 0xa77e18: ret
    //     0xa77e18: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0055c, size: 0xfc
    // 0xb0055c: EnterFrame
    //     0xb0055c: stp             fp, lr, [SP, #-0x10]!
    //     0xb00560: mov             fp, SP
    // 0xb00564: CheckStackOverflow
    //     0xb00564: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00568: cmp             SP, x16
    //     0xb0056c: b.ls            #0xb00614
    // 0xb00570: ldr             x0, [fp, #0x10]
    // 0xb00574: LoadField: r1 = r0->field_7
    //     0xb00574: ldur            w1, [x0, #7]
    // 0xb00578: DecompressPointer r1
    //     0xb00578: add             x1, x1, HEAP, lsl #32
    // 0xb0057c: LoadField: d0 = r0->field_b
    //     0xb0057c: ldur            d0, [x0, #0xb]
    // 0xb00580: LoadField: r2 = r0->field_13
    //     0xb00580: ldur            w2, [x0, #0x13]
    // 0xb00584: DecompressPointer r2
    //     0xb00584: add             x2, x2, HEAP, lsl #32
    // 0xb00588: LoadField: d1 = r0->field_17
    //     0xb00588: ldur            d1, [x0, #0x17]
    // 0xb0058c: r0 = inline_Allocate_Double()
    //     0xb0058c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xb00590: add             x0, x0, #0x10
    //     0xb00594: cmp             x3, x0
    //     0xb00598: b.ls            #0xb0061c
    //     0xb0059c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb005a0: sub             x0, x0, #0xf
    //     0xb005a4: mov             x3, #0xd108
    //     0xb005a8: movk            x3, #3, lsl #16
    //     0xb005ac: stur            x3, [x0, #-1]
    // 0xb005b0: StoreField: r0->field_7 = d0
    //     0xb005b0: stur            d0, [x0, #7]
    // 0xb005b4: r3 = inline_Allocate_Double()
    //     0xb005b4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb005b8: add             x3, x3, #0x10
    //     0xb005bc: cmp             x4, x3
    //     0xb005c0: b.ls            #0xb00634
    //     0xb005c4: str             x3, [THR, #0x60]  ; THR::top
    //     0xb005c8: sub             x3, x3, #0xf
    //     0xb005cc: mov             x4, #0xd108
    //     0xb005d0: movk            x4, #3, lsl #16
    //     0xb005d4: stur            x4, [x3, #-1]
    // 0xb005d8: StoreField: r3->field_7 = d1
    //     0xb005d8: stur            d1, [x3, #7]
    // 0xb005dc: stp             x0, x1, [SP, #-0x10]!
    // 0xb005e0: stp             x3, x2, [SP, #-0x10]!
    // 0xb005e4: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xb005e4: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xb005e8: r0 = hash()
    //     0xb005e8: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb005ec: add             SP, SP, #0x20
    // 0xb005f0: mov             x2, x0
    // 0xb005f4: r0 = BoxInt64Instr(r2)
    //     0xb005f4: sbfiz           x0, x2, #1, #0x1f
    //     0xb005f8: cmp             x2, x0, asr #1
    //     0xb005fc: b.eq            #0xb00608
    //     0xb00600: bl              #0xd69bb8
    //     0xb00604: stur            x2, [x0, #7]
    // 0xb00608: LeaveFrame
    //     0xb00608: mov             SP, fp
    //     0xb0060c: ldp             fp, lr, [SP], #0x10
    // 0xb00610: ret
    //     0xb00610: ret             
    // 0xb00614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00614: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00618: b               #0xb00570
    // 0xb0061c: stp             q0, q1, [SP, #-0x20]!
    // 0xb00620: stp             x1, x2, [SP, #-0x10]!
    // 0xb00624: r0 = AllocateDouble()
    //     0xb00624: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb00628: ldp             x1, x2, [SP], #0x10
    // 0xb0062c: ldp             q0, q1, [SP], #0x20
    // 0xb00630: b               #0xb005b0
    // 0xb00634: SaveReg d1
    //     0xb00634: str             q1, [SP, #-0x10]!
    // 0xb00638: stp             x1, x2, [SP, #-0x10]!
    // 0xb0063c: SaveReg r0
    //     0xb0063c: str             x0, [SP, #-8]!
    // 0xb00640: r0 = AllocateDouble()
    //     0xb00640: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb00644: mov             x3, x0
    // 0xb00648: RestoreReg r0
    //     0xb00648: ldr             x0, [SP], #8
    // 0xb0064c: ldp             x1, x2, [SP], #0x10
    // 0xb00650: RestoreReg d1
    //     0xb00650: ldr             q1, [SP], #0x10
    // 0xb00654: b               #0xb005d8
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xb62db0, size: 0x78
    // 0xb62db0: EnterFrame
    //     0xb62db0: stp             fp, lr, [SP, #-0x10]!
    //     0xb62db4: mov             fp, SP
    // 0xb62db8: AllocStack(0x10)
    //     0xb62db8: sub             SP, SP, #0x10
    // 0xb62dbc: ldr             x0, [fp, #0x20]
    // 0xb62dc0: cmp             w0, NULL
    // 0xb62dc4: b.ne            #0xb62ddc
    // 0xb62dc8: ldr             x1, [fp, #0x28]
    // 0xb62dcc: LoadField: r0 = r1->field_7
    //     0xb62dcc: ldur            w0, [x1, #7]
    // 0xb62dd0: DecompressPointer r0
    //     0xb62dd0: add             x0, x0, HEAP, lsl #32
    // 0xb62dd4: mov             x2, x0
    // 0xb62dd8: b               #0xb62de4
    // 0xb62ddc: ldr             x1, [fp, #0x28]
    // 0xb62de0: mov             x2, x0
    // 0xb62de4: ldr             x0, [fp, #0x18]
    // 0xb62de8: ldr             d0, [fp, #0x10]
    // 0xb62dec: stur            x2, [fp, #-8]
    // 0xb62df0: LoadField: d1 = r1->field_17
    //     0xb62df0: ldur            d1, [x1, #0x17]
    // 0xb62df4: stur            d1, [fp, #-0x10]
    // 0xb62df8: r0 = BorderSide()
    //     0xb62df8: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xb62dfc: ldur            x1, [fp, #-8]
    // 0xb62e00: StoreField: r0->field_7 = r1
    //     0xb62e00: stur            w1, [x0, #7]
    // 0xb62e04: ldr             d0, [fp, #0x10]
    // 0xb62e08: StoreField: r0->field_b = d0
    //     0xb62e08: stur            d0, [x0, #0xb]
    // 0xb62e0c: ldr             x1, [fp, #0x18]
    // 0xb62e10: StoreField: r0->field_13 = r1
    //     0xb62e10: stur            w1, [x0, #0x13]
    // 0xb62e14: ldur            d0, [fp, #-0x10]
    // 0xb62e18: StoreField: r0->field_17 = d0
    //     0xb62e18: stur            d0, [x0, #0x17]
    // 0xb62e1c: LeaveFrame
    //     0xb62e1c: mov             SP, fp
    //     0xb62e20: ldp             fp, lr, [SP], #0x10
    // 0xb62e24: ret
    //     0xb62e24: ret             
  }
  _ toPaint(/* No info */) {
    // ** addr: 0xbd2f38, size: 0x214
    // 0xbd2f38: EnterFrame
    //     0xbd2f38: stp             fp, lr, [SP, #-0x10]!
    //     0xbd2f3c: mov             fp, SP
    // 0xbd2f40: AllocStack(0x18)
    //     0xbd2f40: sub             SP, SP, #0x18
    // 0xbd2f44: CheckStackOverflow
    //     0xbd2f44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd2f48: cmp             SP, x16
    //     0xbd2f4c: b.ls            #0xbd3134
    // 0xbd2f50: ldr             x0, [fp, #0x10]
    // 0xbd2f54: LoadField: r1 = r0->field_13
    //     0xbd2f54: ldur            w1, [x0, #0x13]
    // 0xbd2f58: DecompressPointer r1
    //     0xbd2f58: add             x1, x1, HEAP, lsl #32
    // 0xbd2f5c: LoadField: r2 = r1->field_7
    //     0xbd2f5c: ldur            x2, [x1, #7]
    // 0xbd2f60: cmp             x2, #0
    // 0xbd2f64: b.gt            #0xbd3000
    // 0xbd2f68: r16 = 112
    //     0xbd2f68: mov             x16, #0x70
    // 0xbd2f6c: stp             x16, NULL, [SP, #-0x10]!
    // 0xbd2f70: r0 = ByteData()
    //     0xbd2f70: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xbd2f74: add             SP, SP, #0x10
    // 0xbd2f78: stur            x0, [fp, #-8]
    // 0xbd2f7c: r0 = Paint()
    //     0xbd2f7c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xbd2f80: mov             x1, x0
    // 0xbd2f84: ldur            x0, [fp, #-8]
    // 0xbd2f88: stur            x1, [fp, #-0x18]
    // 0xbd2f8c: StoreField: r1->field_7 = r0
    //     0xbd2f8c: stur            w0, [x1, #7]
    // 0xbd2f90: LoadField: r2 = r0->field_17
    //     0xbd2f90: ldur            w2, [x0, #0x17]
    // 0xbd2f94: DecompressPointer r2
    //     0xbd2f94: add             x2, x2, HEAP, lsl #32
    // 0xbd2f98: stur            x2, [fp, #-0x10]
    // 0xbd2f9c: r16 = 8
    //     0xbd2f9c: mov             x16, #8
    // 0xbd2fa0: stp             x16, x2, [SP, #-0x10]!
    // 0xbd2fa4: r16 = 4278190080
    //     0xbd2fa4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28770] 0xff000000
    //     0xbd2fa8: ldr             x16, [x16, #0x770]
    // 0xbd2fac: SaveReg r16
    //     0xbd2fac: str             x16, [SP, #-8]!
    // 0xbd2fb0: r0 = _setInt32()
    //     0xbd2fb0: bl              #0x65ff8c  ; [dart:typed_data] _TypedList::_setInt32
    // 0xbd2fb4: add             SP, SP, #0x18
    // 0xbd2fb8: ldur            x16, [fp, #-0x10]
    // 0xbd2fbc: r30 = 32
    //     0xbd2fbc: mov             lr, #0x20
    // 0xbd2fc0: stp             lr, x16, [SP, #-0x10]!
    // 0xbd2fc4: r16 = 0.000000
    //     0xbd2fc4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xbd2fc8: SaveReg r16
    //     0xbd2fc8: str             x16, [SP, #-8]!
    // 0xbd2fcc: r0 = _setFloat32()
    //     0xbd2fcc: bl              #0xa746e4  ; [dart:typed_data] _TypedList::_setFloat32
    // 0xbd2fd0: add             SP, SP, #0x18
    // 0xbd2fd4: ldur            x16, [fp, #-0x10]
    // 0xbd2fd8: r30 = 24
    //     0xbd2fd8: mov             lr, #0x18
    // 0xbd2fdc: stp             lr, x16, [SP, #-0x10]!
    // 0xbd2fe0: r16 = 2
    //     0xbd2fe0: mov             x16, #2
    // 0xbd2fe4: SaveReg r16
    //     0xbd2fe4: str             x16, [SP, #-8]!
    // 0xbd2fe8: r0 = _setInt32()
    //     0xbd2fe8: bl              #0x65ff8c  ; [dart:typed_data] _TypedList::_setInt32
    // 0xbd2fec: add             SP, SP, #0x18
    // 0xbd2ff0: ldur            x0, [fp, #-0x18]
    // 0xbd2ff4: LeaveFrame
    //     0xbd2ff4: mov             SP, fp
    //     0xbd2ff8: ldp             fp, lr, [SP], #0x10
    // 0xbd2ffc: ret
    //     0xbd2ffc: ret             
    // 0xbd3000: r16 = 112
    //     0xbd3000: mov             x16, #0x70
    // 0xbd3004: stp             x16, NULL, [SP, #-0x10]!
    // 0xbd3008: r0 = ByteData()
    //     0xbd3008: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xbd300c: add             SP, SP, #0x10
    // 0xbd3010: stur            x0, [fp, #-8]
    // 0xbd3014: r0 = Paint()
    //     0xbd3014: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xbd3018: mov             x2, x0
    // 0xbd301c: ldur            x0, [fp, #-8]
    // 0xbd3020: stur            x2, [fp, #-0x18]
    // 0xbd3024: StoreField: r2->field_7 = r0
    //     0xbd3024: stur            w0, [x2, #7]
    // 0xbd3028: ldr             x3, [fp, #0x10]
    // 0xbd302c: LoadField: r1 = r3->field_7
    //     0xbd302c: ldur            w1, [x3, #7]
    // 0xbd3030: DecompressPointer r1
    //     0xbd3030: add             x1, x1, HEAP, lsl #32
    // 0xbd3034: r4 = LoadClassIdInstr(r1)
    //     0xbd3034: ldur            x4, [x1, #-1]
    //     0xbd3038: ubfx            x4, x4, #0xc, #0x14
    // 0xbd303c: lsl             x4, x4, #1
    // 0xbd3040: r17 = 10124
    //     0xbd3040: mov             x17, #0x278c
    // 0xbd3044: cmp             w4, w17
    // 0xbd3048: b.gt            #0xbd3058
    // 0xbd304c: r17 = 10122
    //     0xbd304c: mov             x17, #0x278a
    // 0xbd3050: cmp             w4, w17
    // 0xbd3054: b.ge            #0xbd3070
    // 0xbd3058: r17 = 10114
    //     0xbd3058: mov             x17, #0x2782
    // 0xbd305c: cmp             w4, w17
    // 0xbd3060: b.eq            #0xbd3070
    // 0xbd3064: r17 = 10118
    //     0xbd3064: mov             x17, #0x2786
    // 0xbd3068: cmp             w4, w17
    // 0xbd306c: b.ne            #0xbd307c
    // 0xbd3070: LoadField: r4 = r1->field_7
    //     0xbd3070: ldur            x4, [x1, #7]
    // 0xbd3074: mov             x1, x4
    // 0xbd3078: b               #0xbd3088
    // 0xbd307c: LoadField: r4 = r1->field_f
    //     0xbd307c: ldur            w4, [x1, #0xf]
    // 0xbd3080: DecompressPointer r4
    //     0xbd3080: add             x4, x4, HEAP, lsl #32
    // 0xbd3084: LoadField: r1 = r4->field_7
    //     0xbd3084: ldur            x1, [x4, #7]
    // 0xbd3088: eor             x4, x1, #0xff000000
    // 0xbd308c: LoadField: r5 = r0->field_17
    //     0xbd308c: ldur            w5, [x0, #0x17]
    // 0xbd3090: DecompressPointer r5
    //     0xbd3090: add             x5, x5, HEAP, lsl #32
    // 0xbd3094: stur            x5, [fp, #-0x10]
    // 0xbd3098: r0 = BoxInt64Instr(r4)
    //     0xbd3098: sbfiz           x0, x4, #1, #0x1f
    //     0xbd309c: cmp             x4, x0, asr #1
    //     0xbd30a0: b.eq            #0xbd30ac
    //     0xbd30a4: bl              #0xd69bb8
    //     0xbd30a8: stur            x4, [x0, #7]
    // 0xbd30ac: r16 = 8
    //     0xbd30ac: mov             x16, #8
    // 0xbd30b0: stp             x16, x5, [SP, #-0x10]!
    // 0xbd30b4: SaveReg r0
    //     0xbd30b4: str             x0, [SP, #-8]!
    // 0xbd30b8: r0 = _setInt32()
    //     0xbd30b8: bl              #0x65ff8c  ; [dart:typed_data] _TypedList::_setInt32
    // 0xbd30bc: add             SP, SP, #0x18
    // 0xbd30c0: ldr             x0, [fp, #0x10]
    // 0xbd30c4: LoadField: d0 = r0->field_b
    //     0xbd30c4: ldur            d0, [x0, #0xb]
    // 0xbd30c8: r0 = inline_Allocate_Double()
    //     0xbd30c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbd30cc: add             x0, x0, #0x10
    //     0xbd30d0: cmp             x1, x0
    //     0xbd30d4: b.ls            #0xbd313c
    //     0xbd30d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbd30dc: sub             x0, x0, #0xf
    //     0xbd30e0: mov             x1, #0xd108
    //     0xbd30e4: movk            x1, #3, lsl #16
    //     0xbd30e8: stur            x1, [x0, #-1]
    // 0xbd30ec: StoreField: r0->field_7 = d0
    //     0xbd30ec: stur            d0, [x0, #7]
    // 0xbd30f0: ldur            x16, [fp, #-0x10]
    // 0xbd30f4: r30 = 32
    //     0xbd30f4: mov             lr, #0x20
    // 0xbd30f8: stp             lr, x16, [SP, #-0x10]!
    // 0xbd30fc: SaveReg r0
    //     0xbd30fc: str             x0, [SP, #-8]!
    // 0xbd3100: r0 = _setFloat32()
    //     0xbd3100: bl              #0xa746e4  ; [dart:typed_data] _TypedList::_setFloat32
    // 0xbd3104: add             SP, SP, #0x18
    // 0xbd3108: ldur            x16, [fp, #-0x10]
    // 0xbd310c: r30 = 24
    //     0xbd310c: mov             lr, #0x18
    // 0xbd3110: stp             lr, x16, [SP, #-0x10]!
    // 0xbd3114: r16 = 2
    //     0xbd3114: mov             x16, #2
    // 0xbd3118: SaveReg r16
    //     0xbd3118: str             x16, [SP, #-8]!
    // 0xbd311c: r0 = _setInt32()
    //     0xbd311c: bl              #0x65ff8c  ; [dart:typed_data] _TypedList::_setInt32
    // 0xbd3120: add             SP, SP, #0x18
    // 0xbd3124: ldur            x0, [fp, #-0x18]
    // 0xbd3128: LeaveFrame
    //     0xbd3128: mov             SP, fp
    //     0xbd312c: ldp             fp, lr, [SP], #0x10
    // 0xbd3130: ret
    //     0xbd3130: ret             
    // 0xbd3134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd3134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd3138: b               #0xbd2f50
    // 0xbd313c: SaveReg d0
    //     0xbd313c: str             q0, [SP, #-0x10]!
    // 0xbd3140: r0 = AllocateDouble()
    //     0xbd3140: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbd3144: RestoreReg d0
    //     0xbd3144: ldr             q0, [SP], #0x10
    // 0xbd3148: b               #0xbd30ec
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8b318, size: 0x2b8
    // 0xc8b318: EnterFrame
    //     0xc8b318: stp             fp, lr, [SP, #-0x10]!
    //     0xc8b31c: mov             fp, SP
    // 0xc8b320: AllocStack(0x18)
    //     0xc8b320: sub             SP, SP, #0x18
    // 0xc8b324: CheckStackOverflow
    //     0xc8b324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8b328: cmp             SP, x16
    //     0xc8b32c: b.ls            #0xc8b5c8
    // 0xc8b330: ldr             x1, [fp, #0x10]
    // 0xc8b334: cmp             w1, NULL
    // 0xc8b338: b.ne            #0xc8b34c
    // 0xc8b33c: r0 = false
    //     0xc8b33c: add             x0, NULL, #0x30  ; false
    // 0xc8b340: LeaveFrame
    //     0xc8b340: mov             SP, fp
    //     0xc8b344: ldp             fp, lr, [SP], #0x10
    // 0xc8b348: ret
    //     0xc8b348: ret             
    // 0xc8b34c: ldr             x2, [fp, #0x18]
    // 0xc8b350: cmp             w2, w1
    // 0xc8b354: b.ne            #0xc8b368
    // 0xc8b358: r0 = true
    //     0xc8b358: add             x0, NULL, #0x20  ; true
    // 0xc8b35c: LeaveFrame
    //     0xc8b35c: mov             SP, fp
    //     0xc8b360: ldp             fp, lr, [SP], #0x10
    // 0xc8b364: ret
    //     0xc8b364: ret             
    // 0xc8b368: r0 = 59
    //     0xc8b368: mov             x0, #0x3b
    // 0xc8b36c: branchIfSmi(r1, 0xc8b378)
    //     0xc8b36c: tbz             w1, #0, #0xc8b378
    // 0xc8b370: r0 = LoadClassIdInstr(r1)
    //     0xc8b370: ldur            x0, [x1, #-1]
    //     0xc8b374: ubfx            x0, x0, #0xc, #0x14
    // 0xc8b378: SaveReg r1
    //     0xc8b378: str             x1, [SP, #-8]!
    // 0xc8b37c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8b37c: mov             x17, #0x57c5
    //     0xc8b380: add             lr, x0, x17
    //     0xc8b384: ldr             lr, [x21, lr, lsl #3]
    //     0xc8b388: blr             lr
    // 0xc8b38c: add             SP, SP, #8
    // 0xc8b390: stur            x0, [fp, #-8]
    // 0xc8b394: ldr             x16, [fp, #0x18]
    // 0xc8b398: SaveReg r16
    //     0xc8b398: str             x16, [SP, #-8]!
    // 0xc8b39c: r0 = runtimeType()
    //     0xc8b39c: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc8b3a0: add             SP, SP, #8
    // 0xc8b3a4: mov             x1, x0
    // 0xc8b3a8: ldur            x0, [fp, #-8]
    // 0xc8b3ac: r2 = LoadClassIdInstr(r0)
    //     0xc8b3ac: ldur            x2, [x0, #-1]
    //     0xc8b3b0: ubfx            x2, x2, #0xc, #0x14
    // 0xc8b3b4: stp             x1, x0, [SP, #-0x10]!
    // 0xc8b3b8: mov             x0, x2
    // 0xc8b3bc: mov             lr, x0
    // 0xc8b3c0: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b3c4: blr             lr
    // 0xc8b3c8: add             SP, SP, #0x10
    // 0xc8b3cc: tbz             w0, #4, #0xc8b3e0
    // 0xc8b3d0: r0 = false
    //     0xc8b3d0: add             x0, NULL, #0x30  ; false
    // 0xc8b3d4: LeaveFrame
    //     0xc8b3d4: mov             SP, fp
    //     0xc8b3d8: ldp             fp, lr, [SP], #0x10
    // 0xc8b3dc: ret
    //     0xc8b3dc: ret             
    // 0xc8b3e0: ldr             x0, [fp, #0x10]
    // 0xc8b3e4: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8b3e4: mov             x1, #0x76
    //     0xc8b3e8: tbz             w0, #0, #0xc8b3f8
    //     0xc8b3ec: ldur            x1, [x0, #-1]
    //     0xc8b3f0: ubfx            x1, x1, #0xc, #0x14
    //     0xc8b3f4: lsl             x1, x1, #1
    // 0xc8b3f8: r2 = LoadInt32Instr(r1)
    //     0xc8b3f8: sbfx            x2, x1, #1, #0x1f
    // 0xc8b3fc: cmp             x2, #0xae6
    // 0xc8b400: b.lt            #0xc8b5b8
    // 0xc8b404: cmp             x2, #0xae8
    // 0xc8b408: b.gt            #0xc8b5b8
    // 0xc8b40c: ldr             x1, [fp, #0x18]
    // 0xc8b410: LoadField: r2 = r0->field_7
    //     0xc8b410: ldur            w2, [x0, #7]
    // 0xc8b414: DecompressPointer r2
    //     0xc8b414: add             x2, x2, HEAP, lsl #32
    // 0xc8b418: stur            x2, [fp, #-0x18]
    // 0xc8b41c: LoadField: r3 = r1->field_7
    //     0xc8b41c: ldur            w3, [x1, #7]
    // 0xc8b420: DecompressPointer r3
    //     0xc8b420: add             x3, x3, HEAP, lsl #32
    // 0xc8b424: stur            x3, [fp, #-0x10]
    // 0xc8b428: r4 = LoadClassIdInstr(r2)
    //     0xc8b428: ldur            x4, [x2, #-1]
    //     0xc8b42c: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b430: lsl             x4, x4, #1
    // 0xc8b434: stur            x4, [fp, #-8]
    // 0xc8b438: r17 = 10114
    //     0xc8b438: mov             x17, #0x2782
    // 0xc8b43c: cmp             w4, w17
    // 0xc8b440: b.eq            #0xc8b450
    // 0xc8b444: r17 = 10118
    //     0xc8b444: mov             x17, #0x2786
    // 0xc8b448: cmp             w4, w17
    // 0xc8b44c: b.ne            #0xc8b534
    // 0xc8b450: cmp             w2, w3
    // 0xc8b454: b.ne            #0xc8b464
    // 0xc8b458: mov             x2, x1
    // 0xc8b45c: mov             x1, x0
    // 0xc8b460: b               #0xc8b564
    // 0xc8b464: stp             x2, x3, [SP, #-0x10]!
    // 0xc8b468: r0 = _haveSameRuntimeType()
    //     0xc8b468: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc8b46c: add             SP, SP, #0x10
    // 0xc8b470: tbnz            w0, #4, #0xc8b5b8
    // 0xc8b474: ldur            x0, [fp, #-0x10]
    // 0xc8b478: r1 = LoadClassIdInstr(r0)
    //     0xc8b478: ldur            x1, [x0, #-1]
    //     0xc8b47c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8b480: lsl             x1, x1, #1
    // 0xc8b484: r17 = 10124
    //     0xc8b484: mov             x17, #0x278c
    // 0xc8b488: cmp             w1, w17
    // 0xc8b48c: b.gt            #0xc8b49c
    // 0xc8b490: r17 = 10122
    //     0xc8b490: mov             x17, #0x278a
    // 0xc8b494: cmp             w1, w17
    // 0xc8b498: b.ge            #0xc8b4b4
    // 0xc8b49c: r17 = 10114
    //     0xc8b49c: mov             x17, #0x2782
    // 0xc8b4a0: cmp             w1, w17
    // 0xc8b4a4: b.eq            #0xc8b4b4
    // 0xc8b4a8: r17 = 10118
    //     0xc8b4a8: mov             x17, #0x2786
    // 0xc8b4ac: cmp             w1, w17
    // 0xc8b4b0: b.ne            #0xc8b4bc
    // 0xc8b4b4: LoadField: r1 = r0->field_7
    //     0xc8b4b4: ldur            x1, [x0, #7]
    // 0xc8b4b8: b               #0xc8b4cc
    // 0xc8b4bc: LoadField: r1 = r0->field_f
    //     0xc8b4bc: ldur            w1, [x0, #0xf]
    // 0xc8b4c0: DecompressPointer r1
    //     0xc8b4c0: add             x1, x1, HEAP, lsl #32
    // 0xc8b4c4: LoadField: r0 = r1->field_7
    //     0xc8b4c4: ldur            x0, [x1, #7]
    // 0xc8b4c8: mov             x1, x0
    // 0xc8b4cc: ldur            x0, [fp, #-8]
    // 0xc8b4d0: r17 = 10124
    //     0xc8b4d0: mov             x17, #0x278c
    // 0xc8b4d4: cmp             w0, w17
    // 0xc8b4d8: b.gt            #0xc8b4e8
    // 0xc8b4dc: r17 = 10122
    //     0xc8b4dc: mov             x17, #0x278a
    // 0xc8b4e0: cmp             w0, w17
    // 0xc8b4e4: b.ge            #0xc8b500
    // 0xc8b4e8: r17 = 10114
    //     0xc8b4e8: mov             x17, #0x2782
    // 0xc8b4ec: cmp             w0, w17
    // 0xc8b4f0: b.eq            #0xc8b500
    // 0xc8b4f4: r17 = 10118
    //     0xc8b4f4: mov             x17, #0x2786
    // 0xc8b4f8: cmp             w0, w17
    // 0xc8b4fc: b.ne            #0xc8b50c
    // 0xc8b500: ldur            x2, [fp, #-0x18]
    // 0xc8b504: LoadField: r0 = r2->field_7
    //     0xc8b504: ldur            x0, [x2, #7]
    // 0xc8b508: b               #0xc8b520
    // 0xc8b50c: ldur            x2, [fp, #-0x18]
    // 0xc8b510: LoadField: r0 = r2->field_f
    //     0xc8b510: ldur            w0, [x2, #0xf]
    // 0xc8b514: DecompressPointer r0
    //     0xc8b514: add             x0, x0, HEAP, lsl #32
    // 0xc8b518: LoadField: r2 = r0->field_7
    //     0xc8b518: ldur            x2, [x0, #7]
    // 0xc8b51c: mov             x0, x2
    // 0xc8b520: cmp             x1, x0
    // 0xc8b524: b.ne            #0xc8b5b8
    // 0xc8b528: ldr             x2, [fp, #0x18]
    // 0xc8b52c: ldr             x1, [fp, #0x10]
    // 0xc8b530: b               #0xc8b564
    // 0xc8b534: mov             x0, x3
    // 0xc8b538: r1 = LoadClassIdInstr(r2)
    //     0xc8b538: ldur            x1, [x2, #-1]
    //     0xc8b53c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8b540: stp             x0, x2, [SP, #-0x10]!
    // 0xc8b544: mov             x0, x1
    // 0xc8b548: mov             lr, x0
    // 0xc8b54c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b550: blr             lr
    // 0xc8b554: add             SP, SP, #0x10
    // 0xc8b558: tbnz            w0, #4, #0xc8b5b8
    // 0xc8b55c: ldr             x2, [fp, #0x18]
    // 0xc8b560: ldr             x1, [fp, #0x10]
    // 0xc8b564: LoadField: d0 = r1->field_b
    //     0xc8b564: ldur            d0, [x1, #0xb]
    // 0xc8b568: LoadField: d1 = r2->field_b
    //     0xc8b568: ldur            d1, [x2, #0xb]
    // 0xc8b56c: fcmp            d0, d1
    // 0xc8b570: b.vs            #0xc8b5b8
    // 0xc8b574: b.ne            #0xc8b5b8
    // 0xc8b578: LoadField: r3 = r1->field_13
    //     0xc8b578: ldur            w3, [x1, #0x13]
    // 0xc8b57c: DecompressPointer r3
    //     0xc8b57c: add             x3, x3, HEAP, lsl #32
    // 0xc8b580: LoadField: r4 = r2->field_13
    //     0xc8b580: ldur            w4, [x2, #0x13]
    // 0xc8b584: DecompressPointer r4
    //     0xc8b584: add             x4, x4, HEAP, lsl #32
    // 0xc8b588: cmp             w3, w4
    // 0xc8b58c: b.ne            #0xc8b5b8
    // 0xc8b590: LoadField: d0 = r1->field_17
    //     0xc8b590: ldur            d0, [x1, #0x17]
    // 0xc8b594: LoadField: d1 = r2->field_17
    //     0xc8b594: ldur            d1, [x2, #0x17]
    // 0xc8b598: fcmp            d0, d1
    // 0xc8b59c: b.vs            #0xc8b5a4
    // 0xc8b5a0: b.eq            #0xc8b5ac
    // 0xc8b5a4: r1 = false
    //     0xc8b5a4: add             x1, NULL, #0x30  ; false
    // 0xc8b5a8: b               #0xc8b5b0
    // 0xc8b5ac: r1 = true
    //     0xc8b5ac: add             x1, NULL, #0x20  ; true
    // 0xc8b5b0: mov             x0, x1
    // 0xc8b5b4: b               #0xc8b5bc
    // 0xc8b5b8: r0 = false
    //     0xc8b5b8: add             x0, NULL, #0x30  ; false
    // 0xc8b5bc: LeaveFrame
    //     0xc8b5bc: mov             SP, fp
    //     0xc8b5c0: ldp             fp, lr, [SP], #0x10
    // 0xc8b5c4: ret
    //     0xc8b5c4: ret             
    // 0xc8b5c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8b5c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8b5cc: b               #0xc8b330
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf83e4, size: 0xd8
    // 0xcf83e4: EnterFrame
    //     0xcf83e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf83e8: mov             fp, SP
    // 0xcf83ec: AllocStack(0x18)
    //     0xcf83ec: sub             SP, SP, #0x18
    // 0xcf83f0: d0 = 0.000000
    //     0xcf83f0: eor             v0.16b, v0.16b, v0.16b
    // 0xcf83f4: ldr             x0, [fp, #0x18]
    // 0xcf83f8: LoadField: r1 = r0->field_7
    //     0xcf83f8: ldur            w1, [x0, #7]
    // 0xcf83fc: DecompressPointer r1
    //     0xcf83fc: add             x1, x1, HEAP, lsl #32
    // 0xcf8400: stur            x1, [fp, #-0x10]
    // 0xcf8404: LoadField: d1 = r0->field_b
    //     0xcf8404: ldur            d1, [x0, #0xb]
    // 0xcf8408: ldr             d2, [fp, #0x10]
    // 0xcf840c: fmul            d3, d1, d2
    // 0xcf8410: fcmp            d0, d3
    // 0xcf8414: b.vs            #0xcf8424
    // 0xcf8418: b.le            #0xcf8424
    // 0xcf841c: d1 = 0.000000
    //     0xcf841c: eor             v1.16b, v1.16b, v1.16b
    // 0xcf8420: b               #0xcf8460
    // 0xcf8424: fcmp            d0, d3
    // 0xcf8428: b.vs            #0xcf8438
    // 0xcf842c: b.ge            #0xcf8438
    // 0xcf8430: mov             v1.16b, v3.16b
    // 0xcf8434: b               #0xcf8460
    // 0xcf8438: fcmp            d0, d0
    // 0xcf843c: b.vs            #0xcf844c
    // 0xcf8440: b.ne            #0xcf844c
    // 0xcf8444: fadd            d1, d0, d3
    // 0xcf8448: b               #0xcf8460
    // 0xcf844c: fcmp            d3, d3
    // 0xcf8450: b.vc            #0xcf845c
    // 0xcf8454: mov             v1.16b, v3.16b
    // 0xcf8458: b               #0xcf8460
    // 0xcf845c: d1 = 0.000000
    //     0xcf845c: eor             v1.16b, v1.16b, v1.16b
    // 0xcf8460: stur            d1, [fp, #-0x18]
    // 0xcf8464: fcmp            d2, d0
    // 0xcf8468: b.vs            #0xcf847c
    // 0xcf846c: b.gt            #0xcf847c
    // 0xcf8470: r0 = Instance_BorderStyle
    //     0xcf8470: add             x0, PP, #0x37, lsl #12  ; [pp+0x37188] Obj!BorderStyle@b64ed1
    //     0xcf8474: ldr             x0, [x0, #0x188]
    // 0xcf8478: b               #0xcf8488
    // 0xcf847c: LoadField: r2 = r0->field_13
    //     0xcf847c: ldur            w2, [x0, #0x13]
    // 0xcf8480: DecompressPointer r2
    //     0xcf8480: add             x2, x2, HEAP, lsl #32
    // 0xcf8484: mov             x0, x2
    // 0xcf8488: stur            x0, [fp, #-8]
    // 0xcf848c: r0 = BorderSide()
    //     0xcf848c: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xcf8490: ldur            x1, [fp, #-0x10]
    // 0xcf8494: StoreField: r0->field_7 = r1
    //     0xcf8494: stur            w1, [x0, #7]
    // 0xcf8498: ldur            d0, [fp, #-0x18]
    // 0xcf849c: StoreField: r0->field_b = d0
    //     0xcf849c: stur            d0, [x0, #0xb]
    // 0xcf84a0: ldur            x1, [fp, #-8]
    // 0xcf84a4: StoreField: r0->field_13 = r1
    //     0xcf84a4: stur            w1, [x0, #0x13]
    // 0xcf84a8: d0 = -1.000000
    //     0xcf84a8: fmov            d0, #-1.00000000
    // 0xcf84ac: StoreField: r0->field_17 = d0
    //     0xcf84ac: stur            d0, [x0, #0x17]
    // 0xcf84b0: LeaveFrame
    //     0xcf84b0: mov             SP, fp
    //     0xcf84b4: ldp             fp, lr, [SP], #0x10
    // 0xcf84b8: ret
    //     0xcf84b8: ret             
  }
}

// class id: 5936, size: 0x14, field offset: 0x14
enum BorderStyle extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb168c4, size: 0x5c
    // 0xb168c4: EnterFrame
    //     0xb168c4: stp             fp, lr, [SP, #-0x10]!
    //     0xb168c8: mov             fp, SP
    // 0xb168cc: CheckStackOverflow
    //     0xb168cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb168d0: cmp             SP, x16
    //     0xb168d4: b.ls            #0xb16918
    // 0xb168d8: r1 = Null
    //     0xb168d8: mov             x1, NULL
    // 0xb168dc: r2 = 4
    //     0xb168dc: mov             x2, #4
    // 0xb168e0: r0 = AllocateArray()
    //     0xb168e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb168e4: r17 = "BorderStyle."
    //     0xb168e4: add             x17, PP, #0xd, lsl #12  ; [pp+0xdec0] "BorderStyle."
    //     0xb168e8: ldr             x17, [x17, #0xec0]
    // 0xb168ec: StoreField: r0->field_f = r17
    //     0xb168ec: stur            w17, [x0, #0xf]
    // 0xb168f0: ldr             x1, [fp, #0x10]
    // 0xb168f4: LoadField: r2 = r1->field_f
    //     0xb168f4: ldur            w2, [x1, #0xf]
    // 0xb168f8: DecompressPointer r2
    //     0xb168f8: add             x2, x2, HEAP, lsl #32
    // 0xb168fc: StoreField: r0->field_13 = r2
    //     0xb168fc: stur            w2, [x0, #0x13]
    // 0xb16900: SaveReg r0
    //     0xb16900: str             x0, [SP, #-8]!
    // 0xb16904: r0 = _interpolate()
    //     0xb16904: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16908: add             SP, SP, #8
    // 0xb1690c: LeaveFrame
    //     0xb1690c: mov             SP, fp
    //     0xb16910: ldp             fp, lr, [SP], #0x10
    // 0xb16914: ret
    //     0xb16914: ret             
    // 0xb16918: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16918: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1691c: b               #0xb168d8
  }
}

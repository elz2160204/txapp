// lib: , url: package:flutter/src/painting/image_cache.dart

// class id: 1049366, size: 0x8
class :: {
}

// class id: 2089, size: 0x10, field offset: 0x8
class _PendingImage extends Object {

  _ removeListener(/* No info */) {
    // ** addr: 0x5cd248, size: 0xd0
    // 0x5cd248: EnterFrame
    //     0x5cd248: stp             fp, lr, [SP, #-0x10]!
    //     0x5cd24c: mov             fp, SP
    // 0x5cd250: AllocStack(0x8)
    //     0x5cd250: sub             SP, SP, #8
    // 0x5cd254: CheckStackOverflow
    //     0x5cd254: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cd258: cmp             SP, x16
    //     0x5cd25c: b.ls            #0x5cd310
    // 0x5cd260: ldr             x0, [fp, #0x10]
    // 0x5cd264: LoadField: r1 = r0->field_7
    //     0x5cd264: ldur            w1, [x0, #7]
    // 0x5cd268: DecompressPointer r1
    //     0x5cd268: add             x1, x1, HEAP, lsl #32
    // 0x5cd26c: stur            x1, [fp, #-8]
    // 0x5cd270: LoadField: r2 = r0->field_b
    //     0x5cd270: ldur            w2, [x0, #0xb]
    // 0x5cd274: DecompressPointer r2
    //     0x5cd274: add             x2, x2, HEAP, lsl #32
    // 0x5cd278: r0 = LoadClassIdInstr(r1)
    //     0x5cd278: ldur            x0, [x1, #-1]
    //     0x5cd27c: ubfx            x0, x0, #0xc, #0x14
    // 0x5cd280: lsl             x0, x0, #1
    // 0x5cd284: r17 = 5422
    //     0x5cd284: mov             x17, #0x152e
    // 0x5cd288: cmp             w0, w17
    // 0x5cd28c: b.ne            #0x5cd2dc
    // 0x5cd290: stp             x2, x1, [SP, #-0x10]!
    // 0x5cd294: r0 = removeListener()
    //     0x5cd294: bl              #0xcedf10  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x5cd298: add             SP, SP, #0x10
    // 0x5cd29c: ldur            x0, [fp, #-8]
    // 0x5cd2a0: LoadField: r1 = r0->field_7
    //     0x5cd2a0: ldur            w1, [x0, #7]
    // 0x5cd2a4: DecompressPointer r1
    //     0x5cd2a4: add             x1, x1, HEAP, lsl #32
    // 0x5cd2a8: LoadField: r2 = r1->field_b
    //     0x5cd2a8: ldur            w2, [x1, #0xb]
    // 0x5cd2ac: DecompressPointer r2
    //     0x5cd2ac: add             x2, x2, HEAP, lsl #32
    // 0x5cd2b0: cbnz            w2, #0x5cd300
    // 0x5cd2b4: LoadField: r1 = r0->field_57
    //     0x5cd2b4: ldur            w1, [x0, #0x57]
    // 0x5cd2b8: DecompressPointer r1
    //     0x5cd2b8: add             x1, x1, HEAP, lsl #32
    // 0x5cd2bc: cmp             w1, NULL
    // 0x5cd2c0: b.eq            #0x5cd2d4
    // 0x5cd2c4: SaveReg r1
    //     0x5cd2c4: str             x1, [SP, #-8]!
    // 0x5cd2c8: r0 = cancel()
    //     0x5cd2c8: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x5cd2cc: add             SP, SP, #8
    // 0x5cd2d0: ldur            x0, [fp, #-8]
    // 0x5cd2d4: StoreField: r0->field_57 = rNULL
    //     0x5cd2d4: stur            NULL, [x0, #0x57]
    // 0x5cd2d8: b               #0x5cd300
    // 0x5cd2dc: mov             x0, x1
    // 0x5cd2e0: r1 = LoadClassIdInstr(r0)
    //     0x5cd2e0: ldur            x1, [x0, #-1]
    //     0x5cd2e4: ubfx            x1, x1, #0xc, #0x14
    // 0x5cd2e8: stp             x2, x0, [SP, #-0x10]!
    // 0x5cd2ec: mov             x0, x1
    // 0x5cd2f0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5cd2f0: sub             lr, x0, #1, lsl #12
    //     0x5cd2f4: ldr             lr, [x21, lr, lsl #3]
    //     0x5cd2f8: blr             lr
    // 0x5cd2fc: add             SP, SP, #0x10
    // 0x5cd300: r0 = Null
    //     0x5cd300: mov             x0, NULL
    // 0x5cd304: LeaveFrame
    //     0x5cd304: mov             SP, fp
    //     0x5cd308: ldp             fp, lr, [SP], #0x10
    // 0x5cd30c: ret
    //     0x5cd30c: ret             
    // 0x5cd310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cd310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cd314: b               #0x5cd260
  }
}

// class id: 2090, size: 0x14, field offset: 0x8
abstract class _CachedImageBase extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0x5cd318, size: 0x140
    // 0x5cd318: EnterFrame
    //     0x5cd318: stp             fp, lr, [SP, #-0x10]!
    //     0x5cd31c: mov             fp, SP
    // 0x5cd320: AllocStack(0x18)
    //     0x5cd320: sub             SP, SP, #0x18
    // 0x5cd324: CheckStackOverflow
    //     0x5cd324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cd328: cmp             SP, x16
    //     0x5cd32c: b.ls            #0x5cd448
    // 0x5cd330: r1 = 1
    //     0x5cd330: mov             x1, #1
    // 0x5cd334: r0 = AllocateContext()
    //     0x5cd334: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5cd338: mov             x1, x0
    // 0x5cd33c: ldr             x0, [fp, #0x10]
    // 0x5cd340: StoreField: r1->field_f = r0
    //     0x5cd340: stur            w0, [x1, #0xf]
    // 0x5cd344: r0 = LoadStaticField(0xf10)
    //     0x5cd344: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5cd348: ldr             x0, [x0, #0x1e20]
    // 0x5cd34c: cmp             w0, NULL
    // 0x5cd350: b.eq            #0x5cd450
    // 0x5cd354: LoadField: r3 = r0->field_57
    //     0x5cd354: ldur            w3, [x0, #0x57]
    // 0x5cd358: DecompressPointer r3
    //     0x5cd358: add             x3, x3, HEAP, lsl #32
    // 0x5cd35c: stur            x3, [fp, #-0x10]
    // 0x5cd360: LoadField: r0 = r3->field_7
    //     0x5cd360: ldur            w0, [x3, #7]
    // 0x5cd364: DecompressPointer r0
    //     0x5cd364: add             x0, x0, HEAP, lsl #32
    // 0x5cd368: mov             x2, x1
    // 0x5cd36c: stur            x0, [fp, #-8]
    // 0x5cd370: r1 = Function '<anonymous closure>':.
    //     0x5cd370: ldr             x1, [PP, #0x4f68]  ; [pp+0x4f68] AnonymousClosure: (0x5cd480), in [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose (0x5cd318)
    // 0x5cd374: r0 = AllocateClosure()
    //     0x5cd374: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5cd378: ldur            x2, [fp, #-8]
    // 0x5cd37c: mov             x3, x0
    // 0x5cd380: r1 = Null
    //     0x5cd380: mov             x1, NULL
    // 0x5cd384: stur            x3, [fp, #-8]
    // 0x5cd388: cmp             w2, NULL
    // 0x5cd38c: b.eq            #0x5cd3ac
    // 0x5cd390: LoadField: r4 = r2->field_17
    //     0x5cd390: ldur            w4, [x2, #0x17]
    // 0x5cd394: DecompressPointer r4
    //     0x5cd394: add             x4, x4, HEAP, lsl #32
    // 0x5cd398: r8 = X0
    //     0x5cd398: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5cd39c: LoadField: r9 = r4->field_7
    //     0x5cd39c: ldur            x9, [x4, #7]
    // 0x5cd3a0: r3 = Null
    //     0x5cd3a0: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cb68] Null
    //     0x5cd3a4: ldr             x3, [x3, #0xb68]
    // 0x5cd3a8: blr             x9
    // 0x5cd3ac: ldur            x0, [fp, #-0x10]
    // 0x5cd3b0: LoadField: r1 = r0->field_b
    //     0x5cd3b0: ldur            w1, [x0, #0xb]
    // 0x5cd3b4: DecompressPointer r1
    //     0x5cd3b4: add             x1, x1, HEAP, lsl #32
    // 0x5cd3b8: stur            x1, [fp, #-0x18]
    // 0x5cd3bc: LoadField: r2 = r0->field_f
    //     0x5cd3bc: ldur            w2, [x0, #0xf]
    // 0x5cd3c0: DecompressPointer r2
    //     0x5cd3c0: add             x2, x2, HEAP, lsl #32
    // 0x5cd3c4: LoadField: r3 = r2->field_b
    //     0x5cd3c4: ldur            w3, [x2, #0xb]
    // 0x5cd3c8: DecompressPointer r3
    //     0x5cd3c8: add             x3, x3, HEAP, lsl #32
    // 0x5cd3cc: cmp             w1, w3
    // 0x5cd3d0: b.ne            #0x5cd3e0
    // 0x5cd3d4: SaveReg r0
    //     0x5cd3d4: str             x0, [SP, #-8]!
    // 0x5cd3d8: r0 = _growToNextCapacity()
    //     0x5cd3d8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5cd3dc: add             SP, SP, #8
    // 0x5cd3e0: ldur            x2, [fp, #-0x10]
    // 0x5cd3e4: ldur            x3, [fp, #-0x18]
    // 0x5cd3e8: r4 = LoadInt32Instr(r3)
    //     0x5cd3e8: sbfx            x4, x3, #1, #0x1f
    // 0x5cd3ec: add             x0, x4, #1
    // 0x5cd3f0: lsl             x3, x0, #1
    // 0x5cd3f4: StoreField: r2->field_b = r3
    //     0x5cd3f4: stur            w3, [x2, #0xb]
    // 0x5cd3f8: mov             x1, x4
    // 0x5cd3fc: cmp             x1, x0
    // 0x5cd400: b.hs            #0x5cd454
    // 0x5cd404: LoadField: r1 = r2->field_f
    //     0x5cd404: ldur            w1, [x2, #0xf]
    // 0x5cd408: DecompressPointer r1
    //     0x5cd408: add             x1, x1, HEAP, lsl #32
    // 0x5cd40c: ldur            x0, [fp, #-8]
    // 0x5cd410: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5cd410: add             x25, x1, x4, lsl #2
    //     0x5cd414: add             x25, x25, #0xf
    //     0x5cd418: str             w0, [x25]
    //     0x5cd41c: tbz             w0, #0, #0x5cd438
    //     0x5cd420: ldurb           w16, [x1, #-1]
    //     0x5cd424: ldurb           w17, [x0, #-1]
    //     0x5cd428: and             x16, x17, x16, lsr #2
    //     0x5cd42c: tst             x16, HEAP, lsr #32
    //     0x5cd430: b.eq            #0x5cd438
    //     0x5cd434: bl              #0xd67e5c
    // 0x5cd438: r0 = Null
    //     0x5cd438: mov             x0, NULL
    // 0x5cd43c: LeaveFrame
    //     0x5cd43c: mov             SP, fp
    //     0x5cd440: ldp             fp, lr, [SP], #0x10
    // 0x5cd444: ret
    //     0x5cd444: ret             
    // 0x5cd448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cd448: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cd44c: b               #0x5cd330
    // 0x5cd450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5cd450: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5cd454: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5cd454: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x5cd480, size: 0x74
    // 0x5cd480: EnterFrame
    //     0x5cd480: stp             fp, lr, [SP, #-0x10]!
    //     0x5cd484: mov             fp, SP
    // 0x5cd488: AllocStack(0x8)
    //     0x5cd488: sub             SP, SP, #8
    // 0x5cd48c: SetupParameters()
    //     0x5cd48c: ldr             x0, [fp, #0x18]
    //     0x5cd490: ldur            w1, [x0, #0x17]
    //     0x5cd494: add             x1, x1, HEAP, lsl #32
    //     0x5cd498: stur            x1, [fp, #-8]
    // 0x5cd49c: CheckStackOverflow
    //     0x5cd49c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cd4a0: cmp             SP, x16
    //     0x5cd4a4: b.ls            #0x5cd4ec
    // 0x5cd4a8: LoadField: r0 = r1->field_f
    //     0x5cd4a8: ldur            w0, [x1, #0xf]
    // 0x5cd4ac: DecompressPointer r0
    //     0x5cd4ac: add             x0, x0, HEAP, lsl #32
    // 0x5cd4b0: LoadField: r2 = r0->field_f
    //     0x5cd4b0: ldur            w2, [x0, #0xf]
    // 0x5cd4b4: DecompressPointer r2
    //     0x5cd4b4: add             x2, x2, HEAP, lsl #32
    // 0x5cd4b8: cmp             w2, NULL
    // 0x5cd4bc: b.eq            #0x5cd4d0
    // 0x5cd4c0: SaveReg r2
    //     0x5cd4c0: str             x2, [SP, #-8]!
    // 0x5cd4c4: r0 = dispose()
    //     0x5cd4c4: bl              #0x5cd4f4  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleterHandle::dispose
    // 0x5cd4c8: add             SP, SP, #8
    // 0x5cd4cc: ldur            x1, [fp, #-8]
    // 0x5cd4d0: LoadField: r2 = r1->field_f
    //     0x5cd4d0: ldur            w2, [x1, #0xf]
    // 0x5cd4d4: DecompressPointer r2
    //     0x5cd4d4: add             x2, x2, HEAP, lsl #32
    // 0x5cd4d8: StoreField: r2->field_f = rNULL
    //     0x5cd4d8: stur            NULL, [x2, #0xf]
    // 0x5cd4dc: r0 = Null
    //     0x5cd4dc: mov             x0, NULL
    // 0x5cd4e0: LeaveFrame
    //     0x5cd4e0: mov             SP, fp
    //     0x5cd4e4: ldp             fp, lr, [SP], #0x10
    // 0x5cd4e8: ret
    //     0x5cd4e8: ret             
    // 0x5cd4ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cd4ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cd4f0: b               #0x5cd4a8
  }
}

// class id: 2091, size: 0x18, field offset: 0x14
class _LiveImage extends _CachedImageBase {

  late (dynamic) => void _handleRemove; // offset: 0x14

  _ dispose(/* No info */) {
    // ** addr: 0xc317c0, size: 0x74
    // 0xc317c0: EnterFrame
    //     0xc317c0: stp             fp, lr, [SP, #-0x10]!
    //     0xc317c4: mov             fp, SP
    // 0xc317c8: CheckStackOverflow
    //     0xc317c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc317cc: cmp             SP, x16
    //     0xc317d0: b.ls            #0xc31820
    // 0xc317d4: ldr             x0, [fp, #0x10]
    // 0xc317d8: LoadField: r1 = r0->field_7
    //     0xc317d8: ldur            w1, [x0, #7]
    // 0xc317dc: DecompressPointer r1
    //     0xc317dc: add             x1, x1, HEAP, lsl #32
    // 0xc317e0: LoadField: r2 = r0->field_13
    //     0xc317e0: ldur            w2, [x0, #0x13]
    // 0xc317e4: DecompressPointer r2
    //     0xc317e4: add             x2, x2, HEAP, lsl #32
    // 0xc317e8: r16 = Sentinel
    //     0xc317e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc317ec: cmp             w2, w16
    // 0xc317f0: b.eq            #0xc31828
    // 0xc317f4: stp             x2, x1, [SP, #-0x10]!
    // 0xc317f8: r0 = removeOnLastListenerRemovedCallback()
    //     0xc317f8: bl              #0xc31834  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeOnLastListenerRemovedCallback
    // 0xc317fc: add             SP, SP, #0x10
    // 0xc31800: ldr             x16, [fp, #0x10]
    // 0xc31804: SaveReg r16
    //     0xc31804: str             x16, [SP, #-8]!
    // 0xc31808: r0 = dispose()
    //     0xc31808: bl              #0x5cd318  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0xc3180c: add             SP, SP, #8
    // 0xc31810: r0 = Null
    //     0xc31810: mov             x0, NULL
    // 0xc31814: LeaveFrame
    //     0xc31814: mov             SP, fp
    //     0xc31818: ldp             fp, lr, [SP], #0x10
    // 0xc3181c: ret
    //     0xc3181c: ret             
    // 0xc31820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc31820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc31824: b               #0xc317d4
    // 0xc31828: r9 = _handleRemove
    //     0xc31828: add             x9, PP, #0x2c, lsl #12  ; [pp+0x2cba0] Field <_LiveImage@863034022._handleRemove@863034022>: late (offset: 0x14)
    //     0xc3182c: ldr             x9, [x9, #0xba0]
    // 0xc31830: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc31830: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _LiveImage(/* No info */) {
    // ** addr: 0xc40644, size: 0xec
    // 0xc40644: EnterFrame
    //     0xc40644: stp             fp, lr, [SP, #-0x10]!
    //     0xc40648: mov             fp, SP
    // 0xc4064c: AllocStack(0x8)
    //     0xc4064c: sub             SP, SP, #8
    // 0xc40650: CheckStackOverflow
    //     0xc40650: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc40654: cmp             SP, x16
    //     0xc40658: b.ls            #0xc40728
    // 0xc4065c: r1 = 2
    //     0xc4065c: mov             x1, #2
    // 0xc40660: r0 = AllocateContext()
    //     0xc40660: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc40664: mov             x2, x0
    // 0xc40668: ldr             x1, [fp, #0x20]
    // 0xc4066c: stur            x2, [fp, #-8]
    // 0xc40670: StoreField: r2->field_f = r1
    //     0xc40670: stur            w1, [x2, #0xf]
    // 0xc40674: ldr             x0, [fp, #0x10]
    // 0xc40678: StoreField: r2->field_13 = r0
    //     0xc40678: stur            w0, [x2, #0x13]
    // 0xc4067c: r0 = Sentinel
    //     0xc4067c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc40680: StoreField: r1->field_13 = r0
    //     0xc40680: stur            w0, [x1, #0x13]
    // 0xc40684: ldr             x0, [fp, #0x18]
    // 0xc40688: StoreField: r1->field_7 = r0
    //     0xc40688: stur            w0, [x1, #7]
    //     0xc4068c: ldurb           w16, [x1, #-1]
    //     0xc40690: ldurb           w17, [x0, #-1]
    //     0xc40694: and             x16, x17, x16, lsr #2
    //     0xc40698: tst             x16, HEAP, lsr #32
    //     0xc4069c: b.eq            #0xc406a4
    //     0xc406a0: bl              #0xd6826c
    // 0xc406a4: ldr             x16, [fp, #0x18]
    // 0xc406a8: SaveReg r16
    //     0xc406a8: str             x16, [SP, #-8]!
    // 0xc406ac: r0 = keepAlive()
    //     0xc406ac: bl              #0xa4ede0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::keepAlive
    // 0xc406b0: add             SP, SP, #8
    // 0xc406b4: ldr             x3, [fp, #0x20]
    // 0xc406b8: StoreField: r3->field_f = r0
    //     0xc406b8: stur            w0, [x3, #0xf]
    //     0xc406bc: ldurb           w16, [x3, #-1]
    //     0xc406c0: ldurb           w17, [x0, #-1]
    //     0xc406c4: and             x16, x17, x16, lsr #2
    //     0xc406c8: tst             x16, HEAP, lsr #32
    //     0xc406cc: b.eq            #0xc406d4
    //     0xc406d0: bl              #0xd682ac
    // 0xc406d4: ldur            x2, [fp, #-8]
    // 0xc406d8: r1 = Function '<anonymous closure>':.
    //     0xc406d8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb98] AnonymousClosure: (0xc40844), in [package:flutter/src/painting/image_cache.dart] _LiveImage::_LiveImage (0xc40644)
    //     0xc406dc: ldr             x1, [x1, #0xb98]
    // 0xc406e0: r0 = AllocateClosure()
    //     0xc406e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc406e4: mov             x2, x0
    // 0xc406e8: ldr             x1, [fp, #0x20]
    // 0xc406ec: StoreField: r1->field_13 = r0
    //     0xc406ec: stur            w0, [x1, #0x13]
    //     0xc406f0: ldurb           w16, [x1, #-1]
    //     0xc406f4: ldurb           w17, [x0, #-1]
    //     0xc406f8: and             x16, x17, x16, lsr #2
    //     0xc406fc: tst             x16, HEAP, lsr #32
    //     0xc40700: b.eq            #0xc40708
    //     0xc40704: bl              #0xd6826c
    // 0xc40708: ldr             x16, [fp, #0x18]
    // 0xc4070c: stp             x2, x16, [SP, #-0x10]!
    // 0xc40710: r0 = addOnLastListenerRemovedCallback()
    //     0xc40710: bl              #0xc40730  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addOnLastListenerRemovedCallback
    // 0xc40714: add             SP, SP, #0x10
    // 0xc40718: r0 = Null
    //     0xc40718: mov             x0, NULL
    // 0xc4071c: LeaveFrame
    //     0xc4071c: mov             SP, fp
    //     0xc40720: ldp             fp, lr, [SP], #0x10
    // 0xc40724: ret
    //     0xc40724: ret             
    // 0xc40728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc40728: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4072c: b               #0xc4065c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc40844, size: 0x80
    // 0xc40844: EnterFrame
    //     0xc40844: stp             fp, lr, [SP, #-0x10]!
    //     0xc40848: mov             fp, SP
    // 0xc4084c: AllocStack(0x8)
    //     0xc4084c: sub             SP, SP, #8
    // 0xc40850: SetupParameters()
    //     0xc40850: ldr             x0, [fp, #0x10]
    //     0xc40854: ldur            w1, [x0, #0x17]
    //     0xc40858: add             x1, x1, HEAP, lsl #32
    //     0xc4085c: stur            x1, [fp, #-8]
    // 0xc40860: CheckStackOverflow
    //     0xc40860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc40864: cmp             SP, x16
    //     0xc40868: b.ls            #0xc408b8
    // 0xc4086c: LoadField: r0 = r1->field_13
    //     0xc4086c: ldur            w0, [x1, #0x13]
    // 0xc40870: DecompressPointer r0
    //     0xc40870: add             x0, x0, HEAP, lsl #32
    // 0xc40874: cmp             w0, NULL
    // 0xc40878: b.eq            #0xc408c0
    // 0xc4087c: SaveReg r0
    //     0xc4087c: str             x0, [SP, #-8]!
    // 0xc40880: ClosureCall
    //     0xc40880: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc40884: ldur            x2, [x0, #0x1f]
    //     0xc40888: blr             x2
    // 0xc4088c: add             SP, SP, #8
    // 0xc40890: ldur            x0, [fp, #-8]
    // 0xc40894: LoadField: r1 = r0->field_f
    //     0xc40894: ldur            w1, [x0, #0xf]
    // 0xc40898: DecompressPointer r1
    //     0xc40898: add             x1, x1, HEAP, lsl #32
    // 0xc4089c: SaveReg r1
    //     0xc4089c: str             x1, [SP, #-8]!
    // 0xc408a0: r0 = dispose()
    //     0xc408a0: bl              #0xc317c0  ; [package:flutter/src/painting/image_cache.dart] _LiveImage::dispose
    // 0xc408a4: add             SP, SP, #8
    // 0xc408a8: r0 = Null
    //     0xc408a8: mov             x0, NULL
    // 0xc408ac: LeaveFrame
    //     0xc408ac: mov             SP, fp
    //     0xc408b0: ldp             fp, lr, [SP], #0x10
    // 0xc408b4: ret
    //     0xc408b4: ret             
    // 0xc408b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc408b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc408bc: b               #0xc4086c
    // 0xc408c0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc408c0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2092, size: 0x14, field offset: 0x14
class _CachedImage extends _CachedImageBase {
}

// class id: 2094, size: 0x2c, field offset: 0x8
class ImageCache extends Object {

  _ ImageCache(/* No info */) {
    // ** addr: 0x5bcbc8, size: 0xf0
    // 0x5bcbc8: EnterFrame
    //     0x5bcbc8: stp             fp, lr, [SP, #-0x10]!
    //     0x5bcbcc: mov             fp, SP
    // 0x5bcbd0: r2 = 1000
    //     0x5bcbd0: mov             x2, #0x3e8
    // 0x5bcbd4: r1 = 104857600
    //     0x5bcbd4: mov             x1, #0x6400000
    // 0x5bcbd8: r0 = 0
    //     0x5bcbd8: mov             x0, #0
    // 0x5bcbdc: CheckStackOverflow
    //     0x5bcbdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bcbe0: cmp             SP, x16
    //     0x5bcbe4: b.ls            #0x5bccb0
    // 0x5bcbe8: ldr             x3, [fp, #0x10]
    // 0x5bcbec: StoreField: r3->field_13 = r2
    //     0x5bcbec: stur            x2, [x3, #0x13]
    // 0x5bcbf0: StoreField: r3->field_1b = r1
    //     0x5bcbf0: stur            x1, [x3, #0x1b]
    // 0x5bcbf4: StoreField: r3->field_23 = r0
    //     0x5bcbf4: stur            x0, [x3, #0x23]
    // 0x5bcbf8: r16 = <Object, _PendingImage>
    //     0x5bcbf8: ldr             x16, [PP, #0x4e20]  ; [pp+0x4e20] TypeArguments: <Object, _PendingImage>
    // 0x5bcbfc: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5bcc00: stp             lr, x16, [SP, #-0x10]!
    // 0x5bcc04: r0 = Map._fromLiteral()
    //     0x5bcc04: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5bcc08: add             SP, SP, #0x10
    // 0x5bcc0c: ldr             x1, [fp, #0x10]
    // 0x5bcc10: StoreField: r1->field_7 = r0
    //     0x5bcc10: stur            w0, [x1, #7]
    //     0x5bcc14: tbz             w0, #0, #0x5bcc30
    //     0x5bcc18: ldurb           w16, [x1, #-1]
    //     0x5bcc1c: ldurb           w17, [x0, #-1]
    //     0x5bcc20: and             x16, x17, x16, lsr #2
    //     0x5bcc24: tst             x16, HEAP, lsr #32
    //     0x5bcc28: b.eq            #0x5bcc30
    //     0x5bcc2c: bl              #0xd6826c
    // 0x5bcc30: r16 = <Object, _CachedImage>
    //     0x5bcc30: ldr             x16, [PP, #0x4e28]  ; [pp+0x4e28] TypeArguments: <Object, _CachedImage>
    // 0x5bcc34: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5bcc38: stp             lr, x16, [SP, #-0x10]!
    // 0x5bcc3c: r0 = Map._fromLiteral()
    //     0x5bcc3c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5bcc40: add             SP, SP, #0x10
    // 0x5bcc44: ldr             x1, [fp, #0x10]
    // 0x5bcc48: StoreField: r1->field_b = r0
    //     0x5bcc48: stur            w0, [x1, #0xb]
    //     0x5bcc4c: tbz             w0, #0, #0x5bcc68
    //     0x5bcc50: ldurb           w16, [x1, #-1]
    //     0x5bcc54: ldurb           w17, [x0, #-1]
    //     0x5bcc58: and             x16, x17, x16, lsr #2
    //     0x5bcc5c: tst             x16, HEAP, lsr #32
    //     0x5bcc60: b.eq            #0x5bcc68
    //     0x5bcc64: bl              #0xd6826c
    // 0x5bcc68: r16 = <Object, _LiveImage>
    //     0x5bcc68: ldr             x16, [PP, #0x4e30]  ; [pp+0x4e30] TypeArguments: <Object, _LiveImage>
    // 0x5bcc6c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5bcc70: stp             lr, x16, [SP, #-0x10]!
    // 0x5bcc74: r0 = Map._fromLiteral()
    //     0x5bcc74: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5bcc78: add             SP, SP, #0x10
    // 0x5bcc7c: ldr             x1, [fp, #0x10]
    // 0x5bcc80: StoreField: r1->field_f = r0
    //     0x5bcc80: stur            w0, [x1, #0xf]
    //     0x5bcc84: tbz             w0, #0, #0x5bcca0
    //     0x5bcc88: ldurb           w16, [x1, #-1]
    //     0x5bcc8c: ldurb           w17, [x0, #-1]
    //     0x5bcc90: and             x16, x17, x16, lsr #2
    //     0x5bcc94: tst             x16, HEAP, lsr #32
    //     0x5bcc98: b.eq            #0x5bcca0
    //     0x5bcc9c: bl              #0xd6826c
    // 0x5bcca0: r0 = Null
    //     0x5bcca0: mov             x0, NULL
    // 0x5bcca4: LeaveFrame
    //     0x5bcca4: mov             SP, fp
    //     0x5bcca8: ldp             fp, lr, [SP], #0x10
    // 0x5bccac: ret
    //     0x5bccac: ret             
    // 0x5bccb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bccb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bccb4: b               #0x5bcbe8
  }
  bool containsKey(ImageCache, Object) {
    // ** addr: 0x5bccd0, size: 0x78
    // 0x5bccd0: EnterFrame
    //     0x5bccd0: stp             fp, lr, [SP, #-0x10]!
    //     0x5bccd4: mov             fp, SP
    // 0x5bccd8: CheckStackOverflow
    //     0x5bccd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bccdc: cmp             SP, x16
    //     0x5bcce0: b.ls            #0x5bcd28
    // 0x5bcce4: ldr             x0, [fp, #0x10]
    // 0x5bcce8: r2 = Null
    //     0x5bcce8: mov             x2, NULL
    // 0x5bccec: r1 = Null
    //     0x5bccec: mov             x1, NULL
    // 0x5bccf0: cmp             w0, NULL
    // 0x5bccf4: b.ne            #0x5bcd08
    // 0x5bccf8: r8 = Object
    //     0x5bccf8: ldr             x8, [PP, #0x3408]  ; [pp+0x3408] Type: Object
    // 0x5bccfc: r3 = Null
    //     0x5bccfc: add             x3, PP, #0x15, lsl #12  ; [pp+0x15250] Null
    //     0x5bcd00: ldr             x3, [x3, #0x250]
    // 0x5bcd04: r0 = Object()
    //     0x5bcd04: bl              #0xd74634  ; IsType_Object_Stub
    // 0x5bcd08: ldr             x16, [fp, #0x18]
    // 0x5bcd0c: ldr             lr, [fp, #0x10]
    // 0x5bcd10: stp             lr, x16, [SP, #-0x10]!
    // 0x5bcd14: r0 = containsKey()
    //     0x5bcd14: bl              #0x5bcd30  ; [package:flutter/src/painting/image_cache.dart] ImageCache::containsKey
    // 0x5bcd18: add             SP, SP, #0x10
    // 0x5bcd1c: LeaveFrame
    //     0x5bcd1c: mov             SP, fp
    //     0x5bcd20: ldp             fp, lr, [SP], #0x10
    // 0x5bcd24: ret
    //     0x5bcd24: ret             
    // 0x5bcd28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bcd28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bcd2c: b               #0x5bcce4
  }
  bool containsKey(ImageCache, Object) {
    // ** addr: 0x5bcd30, size: 0xc8
    // 0x5bcd30: EnterFrame
    //     0x5bcd30: stp             fp, lr, [SP, #-0x10]!
    //     0x5bcd34: mov             fp, SP
    // 0x5bcd38: AllocStack(0x8)
    //     0x5bcd38: sub             SP, SP, #8
    // 0x5bcd3c: CheckStackOverflow
    //     0x5bcd3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bcd40: cmp             SP, x16
    //     0x5bcd44: b.ls            #0x5bcdf0
    // 0x5bcd48: ldr             x0, [fp, #0x18]
    // 0x5bcd4c: LoadField: r1 = r0->field_7
    //     0x5bcd4c: ldur            w1, [x0, #7]
    // 0x5bcd50: DecompressPointer r1
    //     0x5bcd50: add             x1, x1, HEAP, lsl #32
    // 0x5bcd54: stur            x1, [fp, #-8]
    // 0x5bcd58: ldr             x16, [fp, #0x10]
    // 0x5bcd5c: stp             x16, x1, [SP, #-0x10]!
    // 0x5bcd60: r0 = _getValueOrData()
    //     0x5bcd60: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5bcd64: add             SP, SP, #0x10
    // 0x5bcd68: mov             x1, x0
    // 0x5bcd6c: ldur            x0, [fp, #-8]
    // 0x5bcd70: LoadField: r2 = r0->field_f
    //     0x5bcd70: ldur            w2, [x0, #0xf]
    // 0x5bcd74: DecompressPointer r2
    //     0x5bcd74: add             x2, x2, HEAP, lsl #32
    // 0x5bcd78: cmp             w2, w1
    // 0x5bcd7c: b.eq            #0x5bcd90
    // 0x5bcd80: cmp             w1, NULL
    // 0x5bcd84: b.eq            #0x5bcd90
    // 0x5bcd88: r0 = true
    //     0x5bcd88: add             x0, NULL, #0x20  ; true
    // 0x5bcd8c: b               #0x5bcde4
    // 0x5bcd90: ldr             x0, [fp, #0x18]
    // 0x5bcd94: LoadField: r1 = r0->field_b
    //     0x5bcd94: ldur            w1, [x0, #0xb]
    // 0x5bcd98: DecompressPointer r1
    //     0x5bcd98: add             x1, x1, HEAP, lsl #32
    // 0x5bcd9c: stur            x1, [fp, #-8]
    // 0x5bcda0: ldr             x16, [fp, #0x10]
    // 0x5bcda4: stp             x16, x1, [SP, #-0x10]!
    // 0x5bcda8: r0 = _getValueOrData()
    //     0x5bcda8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x5bcdac: add             SP, SP, #0x10
    // 0x5bcdb0: ldur            x1, [fp, #-8]
    // 0x5bcdb4: LoadField: r2 = r1->field_f
    //     0x5bcdb4: ldur            w2, [x1, #0xf]
    // 0x5bcdb8: DecompressPointer r2
    //     0x5bcdb8: add             x2, x2, HEAP, lsl #32
    // 0x5bcdbc: cmp             w2, w0
    // 0x5bcdc0: b.ne            #0x5bcdcc
    // 0x5bcdc4: r1 = Null
    //     0x5bcdc4: mov             x1, NULL
    // 0x5bcdc8: b               #0x5bcdd0
    // 0x5bcdcc: mov             x1, x0
    // 0x5bcdd0: cmp             w1, NULL
    // 0x5bcdd4: r16 = true
    //     0x5bcdd4: add             x16, NULL, #0x20  ; true
    // 0x5bcdd8: r17 = false
    //     0x5bcdd8: add             x17, NULL, #0x30  ; false
    // 0x5bcddc: csel            x2, x16, x17, ne
    // 0x5bcde0: mov             x0, x2
    // 0x5bcde4: LeaveFrame
    //     0x5bcde4: mov             SP, fp
    //     0x5bcde8: ldp             fp, lr, [SP], #0x10
    // 0x5bcdec: ret
    //     0x5bcdec: ret             
    // 0x5bcdf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bcdf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bcdf4: b               #0x5bcd48
  }
  _ clear(/* No info */) {
    // ** addr: 0x5ccedc, size: 0x36c
    // 0x5ccedc: EnterFrame
    //     0x5ccedc: stp             fp, lr, [SP, #-0x10]!
    //     0x5ccee0: mov             fp, SP
    // 0x5ccee4: AllocStack(0x30)
    //     0x5ccee4: sub             SP, SP, #0x30
    // 0x5ccee8: CheckStackOverflow
    //     0x5ccee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cceec: cmp             SP, x16
    //     0x5ccef0: b.ls            #0x5cd228
    // 0x5ccef4: ldr             x0, [fp, #0x10]
    // 0x5ccef8: LoadField: r1 = r0->field_b
    //     0x5ccef8: ldur            w1, [x0, #0xb]
    // 0x5ccefc: DecompressPointer r1
    //     0x5ccefc: add             x1, x1, HEAP, lsl #32
    // 0x5ccf00: stur            x1, [fp, #-8]
    // 0x5ccf04: SaveReg r1
    //     0x5ccf04: str             x1, [SP, #-8]!
    // 0x5ccf08: r0 = values()
    //     0x5ccf08: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x5ccf0c: add             SP, SP, #8
    // 0x5ccf10: SaveReg r0
    //     0x5ccf10: str             x0, [SP, #-8]!
    // 0x5ccf14: r0 = iterator()
    //     0x5ccf14: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x5ccf18: add             SP, SP, #8
    // 0x5ccf1c: stur            x0, [fp, #-0x18]
    // 0x5ccf20: LoadField: r2 = r0->field_7
    //     0x5ccf20: ldur            w2, [x0, #7]
    // 0x5ccf24: DecompressPointer r2
    //     0x5ccf24: add             x2, x2, HEAP, lsl #32
    // 0x5ccf28: stur            x2, [fp, #-0x10]
    // 0x5ccf2c: CheckStackOverflow
    //     0x5ccf2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ccf30: cmp             SP, x16
    //     0x5ccf34: b.ls            #0x5cd230
    // 0x5ccf38: SaveReg r0
    //     0x5ccf38: str             x0, [SP, #-8]!
    // 0x5ccf3c: r0 = moveNext()
    //     0x5ccf3c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x5ccf40: add             SP, SP, #8
    // 0x5ccf44: tbnz            w0, #4, #0x5cd0a0
    // 0x5ccf48: ldur            x3, [fp, #-0x18]
    // 0x5ccf4c: LoadField: r4 = r3->field_33
    //     0x5ccf4c: ldur            w4, [x3, #0x33]
    // 0x5ccf50: DecompressPointer r4
    //     0x5ccf50: add             x4, x4, HEAP, lsl #32
    // 0x5ccf54: stur            x4, [fp, #-0x20]
    // 0x5ccf58: cmp             w4, NULL
    // 0x5ccf5c: b.ne            #0x5ccf8c
    // 0x5ccf60: mov             x0, x4
    // 0x5ccf64: ldur            x2, [fp, #-0x10]
    // 0x5ccf68: r1 = Null
    //     0x5ccf68: mov             x1, NULL
    // 0x5ccf6c: cmp             w2, NULL
    // 0x5ccf70: b.eq            #0x5ccf8c
    // 0x5ccf74: LoadField: r4 = r2->field_17
    //     0x5ccf74: ldur            w4, [x2, #0x17]
    // 0x5ccf78: DecompressPointer r4
    //     0x5ccf78: add             x4, x4, HEAP, lsl #32
    // 0x5ccf7c: r8 = X0
    //     0x5ccf7c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5ccf80: LoadField: r9 = r4->field_7
    //     0x5ccf80: ldur            x9, [x4, #7]
    // 0x5ccf84: r3 = Null
    //     0x5ccf84: ldr             x3, [PP, #0x4f58]  ; [pp+0x4f58] Null
    // 0x5ccf88: blr             x9
    // 0x5ccf8c: ldur            x0, [fp, #-0x20]
    // 0x5ccf90: r1 = 1
    //     0x5ccf90: mov             x1, #1
    // 0x5ccf94: r0 = AllocateContext()
    //     0x5ccf94: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5ccf98: mov             x1, x0
    // 0x5ccf9c: ldur            x0, [fp, #-0x20]
    // 0x5ccfa0: StoreField: r1->field_f = r0
    //     0x5ccfa0: stur            w0, [x1, #0xf]
    // 0x5ccfa4: r0 = LoadStaticField(0xf10)
    //     0x5ccfa4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5ccfa8: ldr             x0, [x0, #0x1e20]
    // 0x5ccfac: cmp             w0, NULL
    // 0x5ccfb0: b.eq            #0x5cd238
    // 0x5ccfb4: LoadField: r3 = r0->field_57
    //     0x5ccfb4: ldur            w3, [x0, #0x57]
    // 0x5ccfb8: DecompressPointer r3
    //     0x5ccfb8: add             x3, x3, HEAP, lsl #32
    // 0x5ccfbc: stur            x3, [fp, #-0x28]
    // 0x5ccfc0: LoadField: r0 = r3->field_7
    //     0x5ccfc0: ldur            w0, [x3, #7]
    // 0x5ccfc4: DecompressPointer r0
    //     0x5ccfc4: add             x0, x0, HEAP, lsl #32
    // 0x5ccfc8: mov             x2, x1
    // 0x5ccfcc: stur            x0, [fp, #-0x20]
    // 0x5ccfd0: r1 = Function '<anonymous closure>':.
    //     0x5ccfd0: ldr             x1, [PP, #0x4f68]  ; [pp+0x4f68] AnonymousClosure: (0x5cd480), in [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose (0x5cd318)
    // 0x5ccfd4: r0 = AllocateClosure()
    //     0x5ccfd4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5ccfd8: ldur            x2, [fp, #-0x20]
    // 0x5ccfdc: mov             x3, x0
    // 0x5ccfe0: r1 = Null
    //     0x5ccfe0: mov             x1, NULL
    // 0x5ccfe4: stur            x3, [fp, #-0x20]
    // 0x5ccfe8: cmp             w2, NULL
    // 0x5ccfec: b.eq            #0x5cd008
    // 0x5ccff0: LoadField: r4 = r2->field_17
    //     0x5ccff0: ldur            w4, [x2, #0x17]
    // 0x5ccff4: DecompressPointer r4
    //     0x5ccff4: add             x4, x4, HEAP, lsl #32
    // 0x5ccff8: r8 = X0
    //     0x5ccff8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5ccffc: LoadField: r9 = r4->field_7
    //     0x5ccffc: ldur            x9, [x4, #7]
    // 0x5cd000: r3 = Null
    //     0x5cd000: ldr             x3, [PP, #0x4f70]  ; [pp+0x4f70] Null
    // 0x5cd004: blr             x9
    // 0x5cd008: ldur            x0, [fp, #-0x28]
    // 0x5cd00c: LoadField: r1 = r0->field_b
    //     0x5cd00c: ldur            w1, [x0, #0xb]
    // 0x5cd010: DecompressPointer r1
    //     0x5cd010: add             x1, x1, HEAP, lsl #32
    // 0x5cd014: stur            x1, [fp, #-0x30]
    // 0x5cd018: LoadField: r2 = r0->field_f
    //     0x5cd018: ldur            w2, [x0, #0xf]
    // 0x5cd01c: DecompressPointer r2
    //     0x5cd01c: add             x2, x2, HEAP, lsl #32
    // 0x5cd020: LoadField: r3 = r2->field_b
    //     0x5cd020: ldur            w3, [x2, #0xb]
    // 0x5cd024: DecompressPointer r3
    //     0x5cd024: add             x3, x3, HEAP, lsl #32
    // 0x5cd028: cmp             w1, w3
    // 0x5cd02c: b.ne            #0x5cd03c
    // 0x5cd030: SaveReg r0
    //     0x5cd030: str             x0, [SP, #-8]!
    // 0x5cd034: r0 = _growToNextCapacity()
    //     0x5cd034: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5cd038: add             SP, SP, #8
    // 0x5cd03c: ldur            x2, [fp, #-0x28]
    // 0x5cd040: ldur            x0, [fp, #-0x30]
    // 0x5cd044: r3 = LoadInt32Instr(r0)
    //     0x5cd044: sbfx            x3, x0, #1, #0x1f
    // 0x5cd048: add             x0, x3, #1
    // 0x5cd04c: lsl             x1, x0, #1
    // 0x5cd050: StoreField: r2->field_b = r1
    //     0x5cd050: stur            w1, [x2, #0xb]
    // 0x5cd054: mov             x1, x3
    // 0x5cd058: cmp             x1, x0
    // 0x5cd05c: b.hs            #0x5cd23c
    // 0x5cd060: LoadField: r1 = r2->field_f
    //     0x5cd060: ldur            w1, [x2, #0xf]
    // 0x5cd064: DecompressPointer r1
    //     0x5cd064: add             x1, x1, HEAP, lsl #32
    // 0x5cd068: ldur            x0, [fp, #-0x20]
    // 0x5cd06c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x5cd06c: add             x25, x1, x3, lsl #2
    //     0x5cd070: add             x25, x25, #0xf
    //     0x5cd074: str             w0, [x25]
    //     0x5cd078: tbz             w0, #0, #0x5cd094
    //     0x5cd07c: ldurb           w16, [x1, #-1]
    //     0x5cd080: ldurb           w17, [x0, #-1]
    //     0x5cd084: and             x16, x17, x16, lsr #2
    //     0x5cd088: tst             x16, HEAP, lsr #32
    //     0x5cd08c: b.eq            #0x5cd094
    //     0x5cd090: bl              #0xd67e5c
    // 0x5cd094: ldur            x0, [fp, #-0x18]
    // 0x5cd098: ldur            x2, [fp, #-0x10]
    // 0x5cd09c: b               #0x5ccf2c
    // 0x5cd0a0: ldr             x0, [fp, #0x10]
    // 0x5cd0a4: ldur            x16, [fp, #-8]
    // 0x5cd0a8: SaveReg r16
    //     0x5cd0a8: str             x16, [SP, #-8]!
    // 0x5cd0ac: r0 = clear()
    //     0x5cd0ac: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x5cd0b0: add             SP, SP, #8
    // 0x5cd0b4: ldr             x0, [fp, #0x10]
    // 0x5cd0b8: LoadField: r1 = r0->field_7
    //     0x5cd0b8: ldur            w1, [x0, #7]
    // 0x5cd0bc: DecompressPointer r1
    //     0x5cd0bc: add             x1, x1, HEAP, lsl #32
    // 0x5cd0c0: stur            x1, [fp, #-8]
    // 0x5cd0c4: SaveReg r1
    //     0x5cd0c4: str             x1, [SP, #-8]!
    // 0x5cd0c8: r0 = values()
    //     0x5cd0c8: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x5cd0cc: add             SP, SP, #8
    // 0x5cd0d0: SaveReg r0
    //     0x5cd0d0: str             x0, [SP, #-8]!
    // 0x5cd0d4: r0 = iterator()
    //     0x5cd0d4: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x5cd0d8: add             SP, SP, #8
    // 0x5cd0dc: stur            x0, [fp, #-0x18]
    // 0x5cd0e0: LoadField: r2 = r0->field_7
    //     0x5cd0e0: ldur            w2, [x0, #7]
    // 0x5cd0e4: DecompressPointer r2
    //     0x5cd0e4: add             x2, x2, HEAP, lsl #32
    // 0x5cd0e8: stur            x2, [fp, #-0x10]
    // 0x5cd0ec: CheckStackOverflow
    //     0x5cd0ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5cd0f0: cmp             SP, x16
    //     0x5cd0f4: b.ls            #0x5cd240
    // 0x5cd0f8: SaveReg r0
    //     0x5cd0f8: str             x0, [SP, #-8]!
    // 0x5cd0fc: r0 = moveNext()
    //     0x5cd0fc: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x5cd100: add             SP, SP, #8
    // 0x5cd104: tbnz            w0, #4, #0x5cd1f8
    // 0x5cd108: ldur            x3, [fp, #-0x18]
    // 0x5cd10c: LoadField: r4 = r3->field_33
    //     0x5cd10c: ldur            w4, [x3, #0x33]
    // 0x5cd110: DecompressPointer r4
    //     0x5cd110: add             x4, x4, HEAP, lsl #32
    // 0x5cd114: stur            x4, [fp, #-0x20]
    // 0x5cd118: cmp             w4, NULL
    // 0x5cd11c: b.ne            #0x5cd14c
    // 0x5cd120: mov             x0, x4
    // 0x5cd124: ldur            x2, [fp, #-0x10]
    // 0x5cd128: r1 = Null
    //     0x5cd128: mov             x1, NULL
    // 0x5cd12c: cmp             w2, NULL
    // 0x5cd130: b.eq            #0x5cd14c
    // 0x5cd134: LoadField: r4 = r2->field_17
    //     0x5cd134: ldur            w4, [x2, #0x17]
    // 0x5cd138: DecompressPointer r4
    //     0x5cd138: add             x4, x4, HEAP, lsl #32
    // 0x5cd13c: r8 = X0
    //     0x5cd13c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5cd140: LoadField: r9 = r4->field_7
    //     0x5cd140: ldur            x9, [x4, #7]
    // 0x5cd144: r3 = Null
    //     0x5cd144: ldr             x3, [PP, #0x4f80]  ; [pp+0x4f80] Null
    // 0x5cd148: blr             x9
    // 0x5cd14c: ldur            x0, [fp, #-0x20]
    // 0x5cd150: LoadField: r1 = r0->field_7
    //     0x5cd150: ldur            w1, [x0, #7]
    // 0x5cd154: DecompressPointer r1
    //     0x5cd154: add             x1, x1, HEAP, lsl #32
    // 0x5cd158: stur            x1, [fp, #-0x28]
    // 0x5cd15c: LoadField: r2 = r0->field_b
    //     0x5cd15c: ldur            w2, [x0, #0xb]
    // 0x5cd160: DecompressPointer r2
    //     0x5cd160: add             x2, x2, HEAP, lsl #32
    // 0x5cd164: r0 = LoadClassIdInstr(r1)
    //     0x5cd164: ldur            x0, [x1, #-1]
    //     0x5cd168: ubfx            x0, x0, #0xc, #0x14
    // 0x5cd16c: lsl             x0, x0, #1
    // 0x5cd170: r17 = 5422
    //     0x5cd170: mov             x17, #0x152e
    // 0x5cd174: cmp             w0, w17
    // 0x5cd178: b.ne            #0x5cd1c8
    // 0x5cd17c: stp             x2, x1, [SP, #-0x10]!
    // 0x5cd180: r0 = removeListener()
    //     0x5cd180: bl              #0xcedf10  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x5cd184: add             SP, SP, #0x10
    // 0x5cd188: ldur            x16, [fp, #-0x28]
    // 0x5cd18c: SaveReg r16
    //     0x5cd18c: str             x16, [SP, #-8]!
    // 0x5cd190: r0 = hasListeners()
    //     0x5cd190: bl              #0x5cd458  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::hasListeners
    // 0x5cd194: add             SP, SP, #8
    // 0x5cd198: tbz             w0, #4, #0x5cd1ec
    // 0x5cd19c: ldur            x0, [fp, #-0x28]
    // 0x5cd1a0: LoadField: r1 = r0->field_57
    //     0x5cd1a0: ldur            w1, [x0, #0x57]
    // 0x5cd1a4: DecompressPointer r1
    //     0x5cd1a4: add             x1, x1, HEAP, lsl #32
    // 0x5cd1a8: cmp             w1, NULL
    // 0x5cd1ac: b.eq            #0x5cd1c0
    // 0x5cd1b0: SaveReg r1
    //     0x5cd1b0: str             x1, [SP, #-8]!
    // 0x5cd1b4: r0 = cancel()
    //     0x5cd1b4: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x5cd1b8: add             SP, SP, #8
    // 0x5cd1bc: ldur            x0, [fp, #-0x28]
    // 0x5cd1c0: StoreField: r0->field_57 = rNULL
    //     0x5cd1c0: stur            NULL, [x0, #0x57]
    // 0x5cd1c4: b               #0x5cd1ec
    // 0x5cd1c8: mov             x0, x1
    // 0x5cd1cc: r1 = LoadClassIdInstr(r0)
    //     0x5cd1cc: ldur            x1, [x0, #-1]
    //     0x5cd1d0: ubfx            x1, x1, #0xc, #0x14
    // 0x5cd1d4: stp             x2, x0, [SP, #-0x10]!
    // 0x5cd1d8: mov             x0, x1
    // 0x5cd1dc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x5cd1dc: sub             lr, x0, #1, lsl #12
    //     0x5cd1e0: ldr             lr, [x21, lr, lsl #3]
    //     0x5cd1e4: blr             lr
    // 0x5cd1e8: add             SP, SP, #0x10
    // 0x5cd1ec: ldur            x0, [fp, #-0x18]
    // 0x5cd1f0: ldur            x2, [fp, #-0x10]
    // 0x5cd1f4: b               #0x5cd0ec
    // 0x5cd1f8: ldr             x0, [fp, #0x10]
    // 0x5cd1fc: ldur            x16, [fp, #-8]
    // 0x5cd200: SaveReg r16
    //     0x5cd200: str             x16, [SP, #-8]!
    // 0x5cd204: r0 = clear()
    //     0x5cd204: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x5cd208: add             SP, SP, #8
    // 0x5cd20c: ldr             x1, [fp, #0x10]
    // 0x5cd210: r2 = 0
    //     0x5cd210: mov             x2, #0
    // 0x5cd214: StoreField: r1->field_23 = r2
    //     0x5cd214: stur            x2, [x1, #0x23]
    // 0x5cd218: r0 = Null
    //     0x5cd218: mov             x0, NULL
    // 0x5cd21c: LeaveFrame
    //     0x5cd21c: mov             SP, fp
    //     0x5cd220: ldp             fp, lr, [SP], #0x10
    // 0x5cd224: ret
    //     0x5cd224: ret             
    // 0x5cd228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cd228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cd22c: b               #0x5ccef4
    // 0x5cd230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cd230: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cd234: b               #0x5ccf38
    // 0x5cd238: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5cd238: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5cd23c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5cd23c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5cd240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5cd240: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5cd244: b               #0x5cd0f8
  }
  bool evict(ImageCache, Object) {
    // ** addr: 0xc316b4, size: 0x10c
    // 0xc316b4: EnterFrame
    //     0xc316b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc316b8: mov             fp, SP
    // 0xc316bc: CheckStackOverflow
    //     0xc316bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc316c0: cmp             SP, x16
    //     0xc316c4: b.ls            #0xc317b4
    // 0xc316c8: ldr             x0, [fp, #0x18]
    // 0xc316cc: LoadField: r1 = r0->field_f
    //     0xc316cc: ldur            w1, [x0, #0xf]
    // 0xc316d0: DecompressPointer r1
    //     0xc316d0: add             x1, x1, HEAP, lsl #32
    // 0xc316d4: ldr             x16, [fp, #0x10]
    // 0xc316d8: stp             x16, x1, [SP, #-0x10]!
    // 0xc316dc: r0 = remove()
    //     0xc316dc: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc316e0: add             SP, SP, #0x10
    // 0xc316e4: cmp             w0, NULL
    // 0xc316e8: b.eq            #0xc316f8
    // 0xc316ec: SaveReg r0
    //     0xc316ec: str             x0, [SP, #-8]!
    // 0xc316f0: r0 = dispose()
    //     0xc316f0: bl              #0xc317c0  ; [package:flutter/src/painting/image_cache.dart] _LiveImage::dispose
    // 0xc316f4: add             SP, SP, #8
    // 0xc316f8: ldr             x0, [fp, #0x18]
    // 0xc316fc: LoadField: r1 = r0->field_7
    //     0xc316fc: ldur            w1, [x0, #7]
    // 0xc31700: DecompressPointer r1
    //     0xc31700: add             x1, x1, HEAP, lsl #32
    // 0xc31704: ldr             x16, [fp, #0x10]
    // 0xc31708: stp             x16, x1, [SP, #-0x10]!
    // 0xc3170c: r0 = remove()
    //     0xc3170c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc31710: add             SP, SP, #0x10
    // 0xc31714: cmp             w0, NULL
    // 0xc31718: b.eq            #0xc31738
    // 0xc3171c: SaveReg r0
    //     0xc3171c: str             x0, [SP, #-8]!
    // 0xc31720: r0 = removeListener()
    //     0xc31720: bl              #0x5cd248  ; [package:flutter/src/painting/image_cache.dart] _PendingImage::removeListener
    // 0xc31724: add             SP, SP, #8
    // 0xc31728: r0 = true
    //     0xc31728: add             x0, NULL, #0x20  ; true
    // 0xc3172c: LeaveFrame
    //     0xc3172c: mov             SP, fp
    //     0xc31730: ldp             fp, lr, [SP], #0x10
    // 0xc31734: ret
    //     0xc31734: ret             
    // 0xc31738: ldr             x0, [fp, #0x18]
    // 0xc3173c: LoadField: r1 = r0->field_b
    //     0xc3173c: ldur            w1, [x0, #0xb]
    // 0xc31740: DecompressPointer r1
    //     0xc31740: add             x1, x1, HEAP, lsl #32
    // 0xc31744: ldr             x16, [fp, #0x10]
    // 0xc31748: stp             x16, x1, [SP, #-0x10]!
    // 0xc3174c: r0 = remove()
    //     0xc3174c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc31750: add             SP, SP, #0x10
    // 0xc31754: cmp             w0, NULL
    // 0xc31758: b.eq            #0xc317a4
    // 0xc3175c: ldr             x1, [fp, #0x18]
    // 0xc31760: LoadField: r2 = r1->field_23
    //     0xc31760: ldur            x2, [x1, #0x23]
    // 0xc31764: LoadField: r3 = r0->field_b
    //     0xc31764: ldur            w3, [x0, #0xb]
    // 0xc31768: DecompressPointer r3
    //     0xc31768: add             x3, x3, HEAP, lsl #32
    // 0xc3176c: cmp             w3, NULL
    // 0xc31770: b.eq            #0xc317bc
    // 0xc31774: r4 = LoadInt32Instr(r3)
    //     0xc31774: sbfx            x4, x3, #1, #0x1f
    //     0xc31778: tbz             w3, #0, #0xc31780
    //     0xc3177c: ldur            x4, [x3, #7]
    // 0xc31780: sub             x3, x2, x4
    // 0xc31784: StoreField: r1->field_23 = r3
    //     0xc31784: stur            x3, [x1, #0x23]
    // 0xc31788: SaveReg r0
    //     0xc31788: str             x0, [SP, #-8]!
    // 0xc3178c: r0 = dispose()
    //     0xc3178c: bl              #0x5cd318  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0xc31790: add             SP, SP, #8
    // 0xc31794: r0 = true
    //     0xc31794: add             x0, NULL, #0x20  ; true
    // 0xc31798: LeaveFrame
    //     0xc31798: mov             SP, fp
    //     0xc3179c: ldp             fp, lr, [SP], #0x10
    // 0xc317a0: ret
    //     0xc317a0: ret             
    // 0xc317a4: r0 = false
    //     0xc317a4: add             x0, NULL, #0x30  ; false
    // 0xc317a8: LeaveFrame
    //     0xc317a8: mov             SP, fp
    //     0xc317ac: ldp             fp, lr, [SP], #0x10
    // 0xc317b0: ret
    //     0xc317b0: ret             
    // 0xc317b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc317b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc317b8: b               #0xc316c8
    // 0xc317bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc317bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ putIfAbsent(/* No info */) {
    // ** addr: 0xc3fd40, size: 0x3fc
    // 0xc3fd40: EnterFrame
    //     0xc3fd40: stp             fp, lr, [SP, #-0x10]!
    //     0xc3fd44: mov             fp, SP
    // 0xc3fd48: AllocStack(0xa0)
    //     0xc3fd48: sub             SP, SP, #0xa0
    // 0xc3fd4c: CheckStackOverflow
    //     0xc3fd4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3fd50: cmp             SP, x16
    //     0xc3fd54: b.ls            #0xc40130
    // 0xc3fd58: r1 = 6
    //     0xc3fd58: mov             x1, #6
    // 0xc3fd5c: r0 = AllocateContext()
    //     0xc3fd5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc3fd60: mov             x1, x0
    // 0xc3fd64: ldr             x0, [fp, #0x28]
    // 0xc3fd68: stur            x1, [fp, #-0x80]
    // 0xc3fd6c: StoreField: r1->field_f = r0
    //     0xc3fd6c: stur            w0, [x1, #0xf]
    // 0xc3fd70: ldr             x2, [fp, #0x20]
    // 0xc3fd74: StoreField: r1->field_13 = r2
    //     0xc3fd74: stur            w2, [x1, #0x13]
    // 0xc3fd78: LoadField: r3 = r0->field_7
    //     0xc3fd78: ldur            w3, [x0, #7]
    // 0xc3fd7c: DecompressPointer r3
    //     0xc3fd7c: add             x3, x3, HEAP, lsl #32
    // 0xc3fd80: stur            x3, [fp, #-0x78]
    // 0xc3fd84: stp             x2, x3, [SP, #-0x10]!
    // 0xc3fd88: r0 = _getValueOrData()
    //     0xc3fd88: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc3fd8c: add             SP, SP, #0x10
    // 0xc3fd90: ldur            x1, [fp, #-0x78]
    // 0xc3fd94: LoadField: r2 = r1->field_f
    //     0xc3fd94: ldur            w2, [x1, #0xf]
    // 0xc3fd98: DecompressPointer r2
    //     0xc3fd98: add             x2, x2, HEAP, lsl #32
    // 0xc3fd9c: cmp             w2, w0
    // 0xc3fda0: b.ne            #0xc3fda8
    // 0xc3fda4: r0 = Null
    //     0xc3fda4: mov             x0, NULL
    // 0xc3fda8: cmp             w0, NULL
    // 0xc3fdac: b.ne            #0xc3fdb8
    // 0xc3fdb0: r3 = Null
    //     0xc3fdb0: mov             x3, NULL
    // 0xc3fdb4: b               #0xc3fdc4
    // 0xc3fdb8: LoadField: r2 = r0->field_7
    //     0xc3fdb8: ldur            w2, [x0, #7]
    // 0xc3fdbc: DecompressPointer r2
    //     0xc3fdbc: add             x2, x2, HEAP, lsl #32
    // 0xc3fdc0: mov             x3, x2
    // 0xc3fdc4: ldur            x2, [fp, #-0x80]
    // 0xc3fdc8: mov             x0, x3
    // 0xc3fdcc: StoreField: r2->field_17 = r0
    //     0xc3fdcc: stur            w0, [x2, #0x17]
    //     0xc3fdd0: ldurb           w16, [x2, #-1]
    //     0xc3fdd4: ldurb           w17, [x0, #-1]
    //     0xc3fdd8: and             x16, x17, x16, lsr #2
    //     0xc3fddc: tst             x16, HEAP, lsr #32
    //     0xc3fde0: b.eq            #0xc3fde8
    //     0xc3fde4: bl              #0xd6828c
    // 0xc3fde8: cmp             w3, NULL
    // 0xc3fdec: b.eq            #0xc3fe00
    // 0xc3fdf0: mov             x0, x3
    // 0xc3fdf4: LeaveFrame
    //     0xc3fdf4: mov             SP, fp
    //     0xc3fdf8: ldp             fp, lr, [SP], #0x10
    // 0xc3fdfc: ret
    //     0xc3fdfc: ret             
    // 0xc3fe00: ldr             x0, [fp, #0x28]
    // 0xc3fe04: LoadField: r3 = r0->field_b
    //     0xc3fe04: ldur            w3, [x0, #0xb]
    // 0xc3fe08: DecompressPointer r3
    //     0xc3fe08: add             x3, x3, HEAP, lsl #32
    // 0xc3fe0c: stur            x3, [fp, #-0x88]
    // 0xc3fe10: LoadField: r4 = r2->field_13
    //     0xc3fe10: ldur            w4, [x2, #0x13]
    // 0xc3fe14: DecompressPointer r4
    //     0xc3fe14: add             x4, x4, HEAP, lsl #32
    // 0xc3fe18: stp             x4, x3, [SP, #-0x10]!
    // 0xc3fe1c: r0 = remove()
    //     0xc3fe1c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc3fe20: add             SP, SP, #0x10
    // 0xc3fe24: stur            x0, [fp, #-0x98]
    // 0xc3fe28: cmp             w0, NULL
    // 0xc3fe2c: b.eq            #0xc3fe98
    // 0xc3fe30: ldur            x2, [fp, #-0x80]
    // 0xc3fe34: LoadField: r1 = r2->field_13
    //     0xc3fe34: ldur            w1, [x2, #0x13]
    // 0xc3fe38: DecompressPointer r1
    //     0xc3fe38: add             x1, x1, HEAP, lsl #32
    // 0xc3fe3c: LoadField: r3 = r0->field_7
    //     0xc3fe3c: ldur            w3, [x0, #7]
    // 0xc3fe40: DecompressPointer r3
    //     0xc3fe40: add             x3, x3, HEAP, lsl #32
    // 0xc3fe44: stur            x3, [fp, #-0x90]
    // 0xc3fe48: LoadField: r4 = r0->field_b
    //     0xc3fe48: ldur            w4, [x0, #0xb]
    // 0xc3fe4c: DecompressPointer r4
    //     0xc3fe4c: add             x4, x4, HEAP, lsl #32
    // 0xc3fe50: ldr             x16, [fp, #0x28]
    // 0xc3fe54: stp             x1, x16, [SP, #-0x10]!
    // 0xc3fe58: stp             x4, x3, [SP, #-0x10]!
    // 0xc3fe5c: r0 = _trackLiveImage()
    //     0xc3fe5c: bl              #0xc40508  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage
    // 0xc3fe60: add             SP, SP, #0x20
    // 0xc3fe64: ldur            x2, [fp, #-0x80]
    // 0xc3fe68: LoadField: r0 = r2->field_13
    //     0xc3fe68: ldur            w0, [x2, #0x13]
    // 0xc3fe6c: DecompressPointer r0
    //     0xc3fe6c: add             x0, x0, HEAP, lsl #32
    // 0xc3fe70: ldur            x16, [fp, #-0x88]
    // 0xc3fe74: stp             x0, x16, [SP, #-0x10]!
    // 0xc3fe78: ldur            x16, [fp, #-0x98]
    // 0xc3fe7c: SaveReg r16
    //     0xc3fe7c: str             x16, [SP, #-8]!
    // 0xc3fe80: r0 = []=()
    //     0xc3fe80: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xc3fe84: add             SP, SP, #0x18
    // 0xc3fe88: ldur            x0, [fp, #-0x90]
    // 0xc3fe8c: LeaveFrame
    //     0xc3fe8c: mov             SP, fp
    //     0xc3fe90: ldp             fp, lr, [SP], #0x10
    // 0xc3fe94: ret
    //     0xc3fe94: ret             
    // 0xc3fe98: ldr             x0, [fp, #0x28]
    // 0xc3fe9c: ldur            x2, [fp, #-0x80]
    // 0xc3fea0: LoadField: r1 = r0->field_f
    //     0xc3fea0: ldur            w1, [x0, #0xf]
    // 0xc3fea4: DecompressPointer r1
    //     0xc3fea4: add             x1, x1, HEAP, lsl #32
    // 0xc3fea8: stur            x1, [fp, #-0x88]
    // 0xc3feac: LoadField: r3 = r2->field_13
    //     0xc3feac: ldur            w3, [x2, #0x13]
    // 0xc3feb0: DecompressPointer r3
    //     0xc3feb0: add             x3, x3, HEAP, lsl #32
    // 0xc3feb4: stp             x3, x1, [SP, #-0x10]!
    // 0xc3feb8: r0 = _getValueOrData()
    //     0xc3feb8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc3febc: add             SP, SP, #0x10
    // 0xc3fec0: mov             x1, x0
    // 0xc3fec4: ldur            x0, [fp, #-0x88]
    // 0xc3fec8: LoadField: r2 = r0->field_f
    //     0xc3fec8: ldur            w2, [x0, #0xf]
    // 0xc3fecc: DecompressPointer r2
    //     0xc3fecc: add             x2, x2, HEAP, lsl #32
    // 0xc3fed0: cmp             w2, w1
    // 0xc3fed4: b.ne            #0xc3fee0
    // 0xc3fed8: r0 = Null
    //     0xc3fed8: mov             x0, NULL
    // 0xc3fedc: b               #0xc3fee4
    // 0xc3fee0: mov             x0, x1
    // 0xc3fee4: cmp             w0, NULL
    // 0xc3fee8: b.eq            #0xc3ff84
    // 0xc3feec: ldur            x2, [fp, #-0x80]
    // 0xc3fef0: LoadField: r1 = r2->field_13
    //     0xc3fef0: ldur            w1, [x2, #0x13]
    // 0xc3fef4: DecompressPointer r1
    //     0xc3fef4: add             x1, x1, HEAP, lsl #32
    // 0xc3fef8: stur            x1, [fp, #-0x98]
    // 0xc3fefc: LoadField: r2 = r0->field_7
    //     0xc3fefc: ldur            w2, [x0, #7]
    // 0xc3ff00: DecompressPointer r2
    //     0xc3ff00: add             x2, x2, HEAP, lsl #32
    // 0xc3ff04: stur            x2, [fp, #-0x90]
    // 0xc3ff08: LoadField: r3 = r0->field_b
    //     0xc3ff08: ldur            w3, [x0, #0xb]
    // 0xc3ff0c: DecompressPointer r3
    //     0xc3ff0c: add             x3, x3, HEAP, lsl #32
    // 0xc3ff10: stur            x3, [fp, #-0x88]
    // 0xc3ff14: r0 = _CachedImage()
    //     0xc3ff14: bl              #0xc404fc  ; Allocate_CachedImageStub -> _CachedImage (size=0x14)
    // 0xc3ff18: mov             x1, x0
    // 0xc3ff1c: ldur            x0, [fp, #-0x90]
    // 0xc3ff20: stur            x1, [fp, #-0xa0]
    // 0xc3ff24: StoreField: r1->field_7 = r0
    //     0xc3ff24: stur            w0, [x1, #7]
    // 0xc3ff28: ldur            x2, [fp, #-0x88]
    // 0xc3ff2c: StoreField: r1->field_b = r2
    //     0xc3ff2c: stur            w2, [x1, #0xb]
    // 0xc3ff30: SaveReg r0
    //     0xc3ff30: str             x0, [SP, #-8]!
    // 0xc3ff34: r0 = keepAlive()
    //     0xc3ff34: bl              #0xa4ede0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::keepAlive
    // 0xc3ff38: add             SP, SP, #8
    // 0xc3ff3c: ldur            x1, [fp, #-0xa0]
    // 0xc3ff40: StoreField: r1->field_f = r0
    //     0xc3ff40: stur            w0, [x1, #0xf]
    //     0xc3ff44: ldurb           w16, [x1, #-1]
    //     0xc3ff48: ldurb           w17, [x0, #-1]
    //     0xc3ff4c: and             x16, x17, x16, lsr #2
    //     0xc3ff50: tst             x16, HEAP, lsr #32
    //     0xc3ff54: b.eq            #0xc3ff5c
    //     0xc3ff58: bl              #0xd6826c
    // 0xc3ff5c: ldr             x16, [fp, #0x28]
    // 0xc3ff60: ldur            lr, [fp, #-0x98]
    // 0xc3ff64: stp             lr, x16, [SP, #-0x10]!
    // 0xc3ff68: SaveReg r1
    //     0xc3ff68: str             x1, [SP, #-8]!
    // 0xc3ff6c: r0 = _touch()
    //     0xc3ff6c: bl              #0xc40148  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_touch
    // 0xc3ff70: add             SP, SP, #0x18
    // 0xc3ff74: ldur            x0, [fp, #-0x90]
    // 0xc3ff78: LeaveFrame
    //     0xc3ff78: mov             SP, fp
    //     0xc3ff7c: ldp             fp, lr, [SP], #0x10
    // 0xc3ff80: ret
    //     0xc3ff80: ret             
    // 0xc3ff84: ldur            x2, [fp, #-0x80]
    // 0xc3ff88: ldr             x16, [fp, #0x18]
    // 0xc3ff8c: SaveReg r16
    //     0xc3ff8c: str             x16, [SP, #-8]!
    // 0xc3ff90: ldr             x0, [fp, #0x18]
    // 0xc3ff94: ClosureCall
    //     0xc3ff94: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc3ff98: ldur            x2, [x0, #0x1f]
    //     0xc3ff9c: blr             x2
    // 0xc3ffa0: add             SP, SP, #8
    // 0xc3ffa4: mov             x1, x0
    // 0xc3ffa8: ldur            x2, [fp, #-0x80]
    // 0xc3ffac: StoreField: r2->field_17 = r0
    //     0xc3ffac: stur            w0, [x2, #0x17]
    //     0xc3ffb0: tbz             w0, #0, #0xc3ffcc
    //     0xc3ffb4: ldurb           w16, [x2, #-1]
    //     0xc3ffb8: ldurb           w17, [x0, #-1]
    //     0xc3ffbc: and             x16, x17, x16, lsr #2
    //     0xc3ffc0: tst             x16, HEAP, lsr #32
    //     0xc3ffc4: b.eq            #0xc3ffcc
    //     0xc3ffc8: bl              #0xd6828c
    // 0xc3ffcc: LoadField: r0 = r2->field_13
    //     0xc3ffcc: ldur            w0, [x2, #0x13]
    // 0xc3ffd0: DecompressPointer r0
    //     0xc3ffd0: add             x0, x0, HEAP, lsl #32
    // 0xc3ffd4: ldr             x16, [fp, #0x28]
    // 0xc3ffd8: stp             x0, x16, [SP, #-0x10]!
    // 0xc3ffdc: stp             NULL, x1, [SP, #-0x10]!
    // 0xc3ffe0: r0 = _trackLiveImage()
    //     0xc3ffe0: bl              #0xc40508  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage
    // 0xc3ffe4: add             SP, SP, #0x20
    // 0xc3ffe8: ldur            x0, [fp, #-0x80]
    // 0xc3ffec: r3 = false
    //     0xc3ffec: add             x3, NULL, #0x30  ; false
    // 0xc3fff0: r2 = true
    //     0xc3fff0: add             x2, NULL, #0x20  ; true
    // 0xc3fff4: r1 = Sentinel
    //     0xc3fff4: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc3fff8: StoreField: r0->field_1b = r3
    //     0xc3fff8: stur            w3, [x0, #0x1b]
    // 0xc3fffc: StoreField: r0->field_1f = r2
    //     0xc3fffc: stur            w2, [x0, #0x1f]
    // 0xc40000: StoreField: r0->field_23 = r1
    //     0xc40000: stur            w1, [x0, #0x23]
    // 0xc40004: mov             x2, x0
    // 0xc40008: r1 = Function 'listener':.
    //     0xc40008: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb48] AnonymousClosure: (0xc4092c), in [package:flutter/src/painting/image_cache.dart] ImageCache::putIfAbsent (0xc3fd40)
    //     0xc4000c: ldr             x1, [x1, #0xb48]
    // 0xc40010: r0 = AllocateClosure()
    //     0xc40010: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc40014: stur            x0, [fp, #-0x88]
    // 0xc40018: r0 = ImageStreamListener()
    //     0xc40018: bl              #0x794068  ; AllocateImageStreamListenerStub -> ImageStreamListener (size=0x14)
    // 0xc4001c: mov             x1, x0
    // 0xc40020: ldur            x0, [fp, #-0x88]
    // 0xc40024: stur            x1, [fp, #-0x90]
    // 0xc40028: StoreField: r1->field_7 = r0
    //     0xc40028: stur            w0, [x1, #7]
    // 0xc4002c: ldur            x0, [fp, #-0x80]
    // 0xc40030: LoadField: r2 = r0->field_17
    //     0xc40030: ldur            w2, [x0, #0x17]
    // 0xc40034: DecompressPointer r2
    //     0xc40034: add             x2, x2, HEAP, lsl #32
    // 0xc40038: stur            x2, [fp, #-0x88]
    // 0xc4003c: r0 = _PendingImage()
    //     0xc4003c: bl              #0xc4013c  ; Allocate_PendingImageStub -> _PendingImage (size=0x10)
    // 0xc40040: mov             x1, x0
    // 0xc40044: ldur            x0, [fp, #-0x88]
    // 0xc40048: StoreField: r1->field_7 = r0
    //     0xc40048: stur            w0, [x1, #7]
    // 0xc4004c: ldur            x2, [fp, #-0x90]
    // 0xc40050: StoreField: r1->field_b = r2
    //     0xc40050: stur            w2, [x1, #0xb]
    // 0xc40054: mov             x0, x1
    // 0xc40058: ldur            x1, [fp, #-0x80]
    // 0xc4005c: StoreField: r1->field_23 = r0
    //     0xc4005c: stur            w0, [x1, #0x23]
    //     0xc40060: ldurb           w16, [x1, #-1]
    //     0xc40064: ldurb           w17, [x0, #-1]
    //     0xc40068: and             x16, x17, x16, lsr #2
    //     0xc4006c: tst             x16, HEAP, lsr #32
    //     0xc40070: b.eq            #0xc40078
    //     0xc40074: bl              #0xd6826c
    // 0xc40078: LoadField: r0 = r1->field_13
    //     0xc40078: ldur            w0, [x1, #0x13]
    // 0xc4007c: DecompressPointer r0
    //     0xc4007c: add             x0, x0, HEAP, lsl #32
    // 0xc40080: LoadField: r3 = r1->field_23
    //     0xc40080: ldur            w3, [x1, #0x23]
    // 0xc40084: DecompressPointer r3
    //     0xc40084: add             x3, x3, HEAP, lsl #32
    // 0xc40088: ldur            x16, [fp, #-0x78]
    // 0xc4008c: stp             x0, x16, [SP, #-0x10]!
    // 0xc40090: SaveReg r3
    //     0xc40090: str             x3, [SP, #-8]!
    // 0xc40094: r0 = []=()
    //     0xc40094: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xc40098: add             SP, SP, #0x18
    // 0xc4009c: ldur            x1, [fp, #-0x80]
    // 0xc400a0: LoadField: r0 = r1->field_17
    //     0xc400a0: ldur            w0, [x1, #0x17]
    // 0xc400a4: DecompressPointer r0
    //     0xc400a4: add             x0, x0, HEAP, lsl #32
    // 0xc400a8: r2 = LoadClassIdInstr(r0)
    //     0xc400a8: ldur            x2, [x0, #-1]
    //     0xc400ac: ubfx            x2, x2, #0xc, #0x14
    // 0xc400b0: ldur            x16, [fp, #-0x90]
    // 0xc400b4: stp             x16, x0, [SP, #-0x10]!
    // 0xc400b8: mov             x0, x2
    // 0xc400bc: r0 = GDT[cid_x0 + -0xff2]()
    //     0xc400bc: sub             lr, x0, #0xff2
    //     0xc400c0: ldr             lr, [x21, lr, lsl #3]
    //     0xc400c4: blr             lr
    // 0xc400c8: add             SP, SP, #0x10
    // 0xc400cc: ldur            x0, [fp, #-0x80]
    // 0xc400d0: LoadField: r1 = r0->field_17
    //     0xc400d0: ldur            w1, [x0, #0x17]
    // 0xc400d4: DecompressPointer r1
    //     0xc400d4: add             x1, x1, HEAP, lsl #32
    // 0xc400d8: mov             x0, x1
    // 0xc400dc: LeaveFrame
    //     0xc400dc: mov             SP, fp
    //     0xc400e0: ldp             fp, lr, [SP], #0x10
    // 0xc400e4: ret
    //     0xc400e4: ret             
    // 0xc400e8: sub             SP, fp, #0xa0
    // 0xc400ec: ldr             x2, [fp, #0x10]
    // 0xc400f0: mov             x16, x1
    // 0xc400f4: mov             x1, x0
    // 0xc400f8: mov             x0, x16
    // 0xc400fc: cmp             w2, NULL
    // 0xc40100: b.eq            #0xc40138
    // 0xc40104: stp             x1, x2, [SP, #-0x10]!
    // 0xc40108: SaveReg r0
    //     0xc40108: str             x0, [SP, #-8]!
    // 0xc4010c: mov             x0, x2
    // 0xc40110: ClosureCall
    //     0xc40110: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc40114: ldur            x2, [x0, #0x1f]
    //     0xc40118: blr             x2
    // 0xc4011c: add             SP, SP, #0x18
    // 0xc40120: r0 = Null
    //     0xc40120: mov             x0, NULL
    // 0xc40124: LeaveFrame
    //     0xc40124: mov             SP, fp
    //     0xc40128: ldp             fp, lr, [SP], #0x10
    // 0xc4012c: ret
    //     0xc4012c: ret             
    // 0xc40130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc40130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc40134: b               #0xc3fd58
    // 0xc40138: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc40138: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _touch(/* No info */) {
    // ** addr: 0xc40148, size: 0xa4
    // 0xc40148: EnterFrame
    //     0xc40148: stp             fp, lr, [SP, #-0x10]!
    //     0xc4014c: mov             fp, SP
    // 0xc40150: CheckStackOverflow
    //     0xc40150: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc40154: cmp             SP, x16
    //     0xc40158: b.ls            #0xc401e4
    // 0xc4015c: ldr             x0, [fp, #0x10]
    // 0xc40160: LoadField: r1 = r0->field_b
    //     0xc40160: ldur            w1, [x0, #0xb]
    // 0xc40164: DecompressPointer r1
    //     0xc40164: add             x1, x1, HEAP, lsl #32
    // 0xc40168: cmp             w1, NULL
    // 0xc4016c: b.eq            #0xc401c8
    // 0xc40170: r2 = LoadInt32Instr(r1)
    //     0xc40170: sbfx            x2, x1, #1, #0x1f
    //     0xc40174: tbz             w1, #0, #0xc4017c
    //     0xc40178: ldur            x2, [x1, #7]
    // 0xc4017c: r17 = 104857600
    //     0xc4017c: mov             x17, #0x6400000
    // 0xc40180: cmp             x2, x17
    // 0xc40184: b.gt            #0xc401c8
    // 0xc40188: ldr             x1, [fp, #0x20]
    // 0xc4018c: LoadField: r3 = r1->field_23
    //     0xc4018c: ldur            x3, [x1, #0x23]
    // 0xc40190: add             x4, x3, x2
    // 0xc40194: StoreField: r1->field_23 = r4
    //     0xc40194: stur            x4, [x1, #0x23]
    // 0xc40198: LoadField: r2 = r1->field_b
    //     0xc40198: ldur            w2, [x1, #0xb]
    // 0xc4019c: DecompressPointer r2
    //     0xc4019c: add             x2, x2, HEAP, lsl #32
    // 0xc401a0: ldr             x16, [fp, #0x18]
    // 0xc401a4: stp             x16, x2, [SP, #-0x10]!
    // 0xc401a8: SaveReg r0
    //     0xc401a8: str             x0, [SP, #-8]!
    // 0xc401ac: r0 = []=()
    //     0xc401ac: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xc401b0: add             SP, SP, #0x18
    // 0xc401b4: ldr             x16, [fp, #0x20]
    // 0xc401b8: SaveReg r16
    //     0xc401b8: str             x16, [SP, #-8]!
    // 0xc401bc: r0 = _checkCacheSize()
    //     0xc401bc: bl              #0xc401ec  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_checkCacheSize
    // 0xc401c0: add             SP, SP, #8
    // 0xc401c4: b               #0xc401d4
    // 0xc401c8: SaveReg r0
    //     0xc401c8: str             x0, [SP, #-8]!
    // 0xc401cc: r0 = dispose()
    //     0xc401cc: bl              #0x5cd318  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0xc401d0: add             SP, SP, #8
    // 0xc401d4: r0 = Null
    //     0xc401d4: mov             x0, NULL
    // 0xc401d8: LeaveFrame
    //     0xc401d8: mov             SP, fp
    //     0xc401dc: ldp             fp, lr, [SP], #0x10
    // 0xc401e0: ret
    //     0xc401e0: ret             
    // 0xc401e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc401e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc401e8: b               #0xc4015c
  }
  _ _checkCacheSize(/* No info */) {
    // ** addr: 0xc401ec, size: 0x310
    // 0xc401ec: EnterFrame
    //     0xc401ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc401f0: mov             fp, SP
    // 0xc401f4: AllocStack(0x30)
    //     0xc401f4: sub             SP, SP, #0x30
    // 0xc401f8: CheckStackOverflow
    //     0xc401f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc401fc: cmp             SP, x16
    //     0xc40200: b.ls            #0xc404dc
    // 0xc40204: r16 = <String, dynamic>
    //     0xc40204: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc40208: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xc4020c: stp             lr, x16, [SP, #-0x10]!
    // 0xc40210: r0 = Map._fromLiteral()
    //     0xc40210: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc40214: add             SP, SP, #0x10
    // 0xc40218: ldr             x0, [fp, #0x10]
    // 0xc4021c: LoadField: r2 = r0->field_b
    //     0xc4021c: ldur            w2, [x0, #0xb]
    // 0xc40220: DecompressPointer r2
    //     0xc40220: add             x2, x2, HEAP, lsl #32
    // 0xc40224: stur            x2, [fp, #-0x20]
    // 0xc40228: LoadField: r3 = r2->field_7
    //     0xc40228: ldur            w3, [x2, #7]
    // 0xc4022c: DecompressPointer r3
    //     0xc4022c: add             x3, x3, HEAP, lsl #32
    // 0xc40230: stur            x3, [fp, #-0x18]
    // 0xc40234: CheckStackOverflow
    //     0xc40234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc40238: cmp             SP, x16
    //     0xc4023c: b.ls            #0xc404e4
    // 0xc40240: LoadField: r1 = r0->field_23
    //     0xc40240: ldur            x1, [x0, #0x23]
    // 0xc40244: r17 = 104857600
    //     0xc40244: mov             x17, #0x6400000
    // 0xc40248: cmp             x1, x17
    // 0xc4024c: b.gt            #0xc40278
    // 0xc40250: LoadField: r1 = r2->field_13
    //     0xc40250: ldur            w1, [x2, #0x13]
    // 0xc40254: DecompressPointer r1
    //     0xc40254: add             x1, x1, HEAP, lsl #32
    // 0xc40258: r4 = LoadInt32Instr(r1)
    //     0xc40258: sbfx            x4, x1, #1, #0x1f
    // 0xc4025c: asr             x1, x4, #1
    // 0xc40260: LoadField: r4 = r2->field_17
    //     0xc40260: ldur            w4, [x2, #0x17]
    // 0xc40264: DecompressPointer r4
    //     0xc40264: add             x4, x4, HEAP, lsl #32
    // 0xc40268: r5 = LoadInt32Instr(r4)
    //     0xc40268: sbfx            x5, x4, #1, #0x1f
    // 0xc4026c: sub             x4, x1, x5
    // 0xc40270: cmp             x4, #0x3e8
    // 0xc40274: b.le            #0xc404c0
    // 0xc40278: LoadField: r4 = r2->field_f
    //     0xc40278: ldur            w4, [x2, #0xf]
    // 0xc4027c: DecompressPointer r4
    //     0xc4027c: add             x4, x4, HEAP, lsl #32
    // 0xc40280: stur            x4, [fp, #-0x10]
    // 0xc40284: LoadField: r5 = r2->field_13
    //     0xc40284: ldur            w5, [x2, #0x13]
    // 0xc40288: DecompressPointer r5
    //     0xc40288: add             x5, x5, HEAP, lsl #32
    // 0xc4028c: mov             x1, x3
    // 0xc40290: stur            x5, [fp, #-8]
    // 0xc40294: r0 = _CompactIterable()
    //     0xc40294: bl              #0x6493d0  ; Allocate_CompactIterableStub -> _CompactIterable<X0> (size=0x2c)
    // 0xc40298: mov             x1, x0
    // 0xc4029c: ldur            x0, [fp, #-0x20]
    // 0xc402a0: StoreField: r1->field_b = r0
    //     0xc402a0: stur            w0, [x1, #0xb]
    // 0xc402a4: ldur            x2, [fp, #-0x10]
    // 0xc402a8: StoreField: r1->field_f = r2
    //     0xc402a8: stur            w2, [x1, #0xf]
    // 0xc402ac: ldur            x2, [fp, #-8]
    // 0xc402b0: r3 = LoadInt32Instr(r2)
    //     0xc402b0: sbfx            x3, x2, #1, #0x1f
    // 0xc402b4: StoreField: r1->field_13 = r3
    //     0xc402b4: stur            x3, [x1, #0x13]
    // 0xc402b8: r2 = -2
    //     0xc402b8: mov             x2, #-2
    // 0xc402bc: StoreField: r1->field_1b = r2
    //     0xc402bc: stur            x2, [x1, #0x1b]
    // 0xc402c0: r3 = 2
    //     0xc402c0: mov             x3, #2
    // 0xc402c4: StoreField: r1->field_23 = r3
    //     0xc402c4: stur            x3, [x1, #0x23]
    // 0xc402c8: SaveReg r1
    //     0xc402c8: str             x1, [SP, #-8]!
    // 0xc402cc: r0 = iterator()
    //     0xc402cc: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0xc402d0: add             SP, SP, #8
    // 0xc402d4: mov             x1, x0
    // 0xc402d8: stur            x1, [fp, #-8]
    // 0xc402dc: r0 = LoadClassIdInstr(r1)
    //     0xc402dc: ldur            x0, [x1, #-1]
    //     0xc402e0: ubfx            x0, x0, #0xc, #0x14
    // 0xc402e4: SaveReg r1
    //     0xc402e4: str             x1, [SP, #-8]!
    // 0xc402e8: r0 = GDT[cid_x0 + 0x541]()
    //     0xc402e8: add             lr, x0, #0x541
    //     0xc402ec: ldr             lr, [x21, lr, lsl #3]
    //     0xc402f0: blr             lr
    // 0xc402f4: add             SP, SP, #8
    // 0xc402f8: tbnz            w0, #4, #0xc404d0
    // 0xc402fc: ldur            x1, [fp, #-0x20]
    // 0xc40300: ldur            x0, [fp, #-8]
    // 0xc40304: r2 = LoadClassIdInstr(r0)
    //     0xc40304: ldur            x2, [x0, #-1]
    //     0xc40308: ubfx            x2, x2, #0xc, #0x14
    // 0xc4030c: SaveReg r0
    //     0xc4030c: str             x0, [SP, #-8]!
    // 0xc40310: mov             x0, x2
    // 0xc40314: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc40314: add             lr, x0, #0x5ca
    //     0xc40318: ldr             lr, [x21, lr, lsl #3]
    //     0xc4031c: blr             lr
    // 0xc40320: add             SP, SP, #8
    // 0xc40324: stur            x0, [fp, #-8]
    // 0xc40328: ldur            x16, [fp, #-0x20]
    // 0xc4032c: stp             x0, x16, [SP, #-0x10]!
    // 0xc40330: r0 = _getValueOrData()
    //     0xc40330: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc40334: add             SP, SP, #0x10
    // 0xc40338: mov             x1, x0
    // 0xc4033c: ldur            x0, [fp, #-0x20]
    // 0xc40340: LoadField: r2 = r0->field_f
    //     0xc40340: ldur            w2, [x0, #0xf]
    // 0xc40344: DecompressPointer r2
    //     0xc40344: add             x2, x2, HEAP, lsl #32
    // 0xc40348: cmp             w2, w1
    // 0xc4034c: b.ne            #0xc40358
    // 0xc40350: r2 = Null
    //     0xc40350: mov             x2, NULL
    // 0xc40354: b               #0xc4035c
    // 0xc40358: mov             x2, x1
    // 0xc4035c: ldr             x1, [fp, #0x10]
    // 0xc40360: stur            x2, [fp, #-0x10]
    // 0xc40364: cmp             w2, NULL
    // 0xc40368: b.eq            #0xc404ec
    // 0xc4036c: LoadField: r3 = r1->field_23
    //     0xc4036c: ldur            x3, [x1, #0x23]
    // 0xc40370: LoadField: r4 = r2->field_b
    //     0xc40370: ldur            w4, [x2, #0xb]
    // 0xc40374: DecompressPointer r4
    //     0xc40374: add             x4, x4, HEAP, lsl #32
    // 0xc40378: cmp             w4, NULL
    // 0xc4037c: b.eq            #0xc404f0
    // 0xc40380: r5 = LoadInt32Instr(r4)
    //     0xc40380: sbfx            x5, x4, #1, #0x1f
    //     0xc40384: tbz             w4, #0, #0xc4038c
    //     0xc40388: ldur            x5, [x4, #7]
    // 0xc4038c: sub             x4, x3, x5
    // 0xc40390: StoreField: r1->field_23 = r4
    //     0xc40390: stur            x4, [x1, #0x23]
    // 0xc40394: r1 = 1
    //     0xc40394: mov             x1, #1
    // 0xc40398: r0 = AllocateContext()
    //     0xc40398: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc4039c: mov             x1, x0
    // 0xc403a0: ldur            x0, [fp, #-0x10]
    // 0xc403a4: StoreField: r1->field_f = r0
    //     0xc403a4: stur            w0, [x1, #0xf]
    // 0xc403a8: r0 = LoadStaticField(0xf10)
    //     0xc403a8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc403ac: ldr             x0, [x0, #0x1e20]
    // 0xc403b0: cmp             w0, NULL
    // 0xc403b4: b.eq            #0xc404f4
    // 0xc403b8: LoadField: r3 = r0->field_57
    //     0xc403b8: ldur            w3, [x0, #0x57]
    // 0xc403bc: DecompressPointer r3
    //     0xc403bc: add             x3, x3, HEAP, lsl #32
    // 0xc403c0: stur            x3, [fp, #-0x28]
    // 0xc403c4: LoadField: r0 = r3->field_7
    //     0xc403c4: ldur            w0, [x3, #7]
    // 0xc403c8: DecompressPointer r0
    //     0xc403c8: add             x0, x0, HEAP, lsl #32
    // 0xc403cc: mov             x2, x1
    // 0xc403d0: stur            x0, [fp, #-0x10]
    // 0xc403d4: r1 = Function '<anonymous closure>':.
    //     0xc403d4: ldr             x1, [PP, #0x4f68]  ; [pp+0x4f68] AnonymousClosure: (0x5cd480), in [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose (0x5cd318)
    // 0xc403d8: r0 = AllocateClosure()
    //     0xc403d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc403dc: ldur            x2, [fp, #-0x10]
    // 0xc403e0: mov             x3, x0
    // 0xc403e4: r1 = Null
    //     0xc403e4: mov             x1, NULL
    // 0xc403e8: stur            x3, [fp, #-0x10]
    // 0xc403ec: cmp             w2, NULL
    // 0xc403f0: b.eq            #0xc40410
    // 0xc403f4: LoadField: r4 = r2->field_17
    //     0xc403f4: ldur            w4, [x2, #0x17]
    // 0xc403f8: DecompressPointer r4
    //     0xc403f8: add             x4, x4, HEAP, lsl #32
    // 0xc403fc: r8 = X0
    //     0xc403fc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc40400: LoadField: r9 = r4->field_7
    //     0xc40400: ldur            x9, [x4, #7]
    // 0xc40404: r3 = Null
    //     0xc40404: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cb78] Null
    //     0xc40408: ldr             x3, [x3, #0xb78]
    // 0xc4040c: blr             x9
    // 0xc40410: ldur            x0, [fp, #-0x28]
    // 0xc40414: LoadField: r1 = r0->field_b
    //     0xc40414: ldur            w1, [x0, #0xb]
    // 0xc40418: DecompressPointer r1
    //     0xc40418: add             x1, x1, HEAP, lsl #32
    // 0xc4041c: stur            x1, [fp, #-0x30]
    // 0xc40420: LoadField: r2 = r0->field_f
    //     0xc40420: ldur            w2, [x0, #0xf]
    // 0xc40424: DecompressPointer r2
    //     0xc40424: add             x2, x2, HEAP, lsl #32
    // 0xc40428: LoadField: r3 = r2->field_b
    //     0xc40428: ldur            w3, [x2, #0xb]
    // 0xc4042c: DecompressPointer r3
    //     0xc4042c: add             x3, x3, HEAP, lsl #32
    // 0xc40430: cmp             w1, w3
    // 0xc40434: b.ne            #0xc40444
    // 0xc40438: SaveReg r0
    //     0xc40438: str             x0, [SP, #-8]!
    // 0xc4043c: r0 = _growToNextCapacity()
    //     0xc4043c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc40440: add             SP, SP, #8
    // 0xc40444: ldur            x2, [fp, #-0x28]
    // 0xc40448: ldur            x0, [fp, #-0x30]
    // 0xc4044c: r3 = LoadInt32Instr(r0)
    //     0xc4044c: sbfx            x3, x0, #1, #0x1f
    // 0xc40450: add             x0, x3, #1
    // 0xc40454: lsl             x1, x0, #1
    // 0xc40458: StoreField: r2->field_b = r1
    //     0xc40458: stur            w1, [x2, #0xb]
    // 0xc4045c: mov             x1, x3
    // 0xc40460: cmp             x1, x0
    // 0xc40464: b.hs            #0xc404f8
    // 0xc40468: LoadField: r1 = r2->field_f
    //     0xc40468: ldur            w1, [x2, #0xf]
    // 0xc4046c: DecompressPointer r1
    //     0xc4046c: add             x1, x1, HEAP, lsl #32
    // 0xc40470: ldur            x0, [fp, #-0x10]
    // 0xc40474: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc40474: add             x25, x1, x3, lsl #2
    //     0xc40478: add             x25, x25, #0xf
    //     0xc4047c: str             w0, [x25]
    //     0xc40480: tbz             w0, #0, #0xc4049c
    //     0xc40484: ldurb           w16, [x1, #-1]
    //     0xc40488: ldurb           w17, [x0, #-1]
    //     0xc4048c: and             x16, x17, x16, lsr #2
    //     0xc40490: tst             x16, HEAP, lsr #32
    //     0xc40494: b.eq            #0xc4049c
    //     0xc40498: bl              #0xd67e5c
    // 0xc4049c: ldur            x16, [fp, #-0x20]
    // 0xc404a0: ldur            lr, [fp, #-8]
    // 0xc404a4: stp             lr, x16, [SP, #-0x10]!
    // 0xc404a8: r0 = remove()
    //     0xc404a8: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc404ac: add             SP, SP, #0x10
    // 0xc404b0: ldr             x0, [fp, #0x10]
    // 0xc404b4: ldur            x2, [fp, #-0x20]
    // 0xc404b8: ldur            x3, [fp, #-0x18]
    // 0xc404bc: b               #0xc40234
    // 0xc404c0: r0 = Null
    //     0xc404c0: mov             x0, NULL
    // 0xc404c4: LeaveFrame
    //     0xc404c4: mov             SP, fp
    //     0xc404c8: ldp             fp, lr, [SP], #0x10
    // 0xc404cc: ret
    //     0xc404cc: ret             
    // 0xc404d0: r0 = noElement()
    //     0xc404d0: bl              #0x4c8048  ; [dart:_internal] IterableElementError::noElement
    // 0xc404d4: r0 = Throw()
    //     0xc404d4: bl              #0xd67e38  ; ThrowStub
    // 0xc404d8: brk             #0
    // 0xc404dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc404dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc404e0: b               #0xc40204
    // 0xc404e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc404e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc404e8: b               #0xc40240
    // 0xc404ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc404ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc404f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc404f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc404f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc404f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc404f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc404f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _trackLiveImage(/* No info */) {
    // ** addr: 0xc40508, size: 0xc0
    // 0xc40508: EnterFrame
    //     0xc40508: stp             fp, lr, [SP, #-0x10]!
    //     0xc4050c: mov             fp, SP
    // 0xc40510: AllocStack(0x8)
    //     0xc40510: sub             SP, SP, #8
    // 0xc40514: CheckStackOverflow
    //     0xc40514: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc40518: cmp             SP, x16
    //     0xc4051c: b.ls            #0xc405c0
    // 0xc40520: r1 = 3
    //     0xc40520: mov             x1, #3
    // 0xc40524: r0 = AllocateContext()
    //     0xc40524: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc40528: mov             x1, x0
    // 0xc4052c: ldr             x0, [fp, #0x28]
    // 0xc40530: StoreField: r1->field_f = r0
    //     0xc40530: stur            w0, [x1, #0xf]
    // 0xc40534: ldr             x3, [fp, #0x20]
    // 0xc40538: StoreField: r1->field_13 = r3
    //     0xc40538: stur            w3, [x1, #0x13]
    // 0xc4053c: ldr             x2, [fp, #0x18]
    // 0xc40540: StoreField: r1->field_17 = r2
    //     0xc40540: stur            w2, [x1, #0x17]
    // 0xc40544: LoadField: r4 = r0->field_f
    //     0xc40544: ldur            w4, [x0, #0xf]
    // 0xc40548: DecompressPointer r4
    //     0xc40548: add             x4, x4, HEAP, lsl #32
    // 0xc4054c: mov             x2, x1
    // 0xc40550: stur            x4, [fp, #-8]
    // 0xc40554: r1 = Function '<anonymous closure>':.
    //     0xc40554: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb88] AnonymousClosure: (0xc405c8), in [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage (0xc40508)
    //     0xc40558: ldr             x1, [x1, #0xb88]
    // 0xc4055c: r0 = AllocateClosure()
    //     0xc4055c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc40560: ldur            x16, [fp, #-8]
    // 0xc40564: ldr             lr, [fp, #0x20]
    // 0xc40568: stp             lr, x16, [SP, #-0x10]!
    // 0xc4056c: SaveReg r0
    //     0xc4056c: str             x0, [SP, #-8]!
    // 0xc40570: r0 = putIfAbsent()
    //     0xc40570: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xc40574: add             SP, SP, #0x18
    // 0xc40578: mov             x1, x0
    // 0xc4057c: LoadField: r2 = r1->field_b
    //     0xc4057c: ldur            w2, [x1, #0xb]
    // 0xc40580: DecompressPointer r2
    //     0xc40580: add             x2, x2, HEAP, lsl #32
    // 0xc40584: cmp             w2, NULL
    // 0xc40588: b.ne            #0xc405b0
    // 0xc4058c: ldr             x0, [fp, #0x10]
    // 0xc40590: StoreField: r1->field_b = r0
    //     0xc40590: stur            w0, [x1, #0xb]
    //     0xc40594: tbz             w0, #0, #0xc405b0
    //     0xc40598: ldurb           w16, [x1, #-1]
    //     0xc4059c: ldurb           w17, [x0, #-1]
    //     0xc405a0: and             x16, x17, x16, lsr #2
    //     0xc405a4: tst             x16, HEAP, lsr #32
    //     0xc405a8: b.eq            #0xc405b0
    //     0xc405ac: bl              #0xd6826c
    // 0xc405b0: r0 = Null
    //     0xc405b0: mov             x0, NULL
    // 0xc405b4: LeaveFrame
    //     0xc405b4: mov             SP, fp
    //     0xc405b8: ldp             fp, lr, [SP], #0x10
    // 0xc405bc: ret
    //     0xc405bc: ret             
    // 0xc405c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc405c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc405c4: b               #0xc40520
  }
  [closure] _LiveImage <anonymous closure>(dynamic) {
    // ** addr: 0xc405c8, size: 0x7c
    // 0xc405c8: EnterFrame
    //     0xc405c8: stp             fp, lr, [SP, #-0x10]!
    //     0xc405cc: mov             fp, SP
    // 0xc405d0: AllocStack(0x10)
    //     0xc405d0: sub             SP, SP, #0x10
    // 0xc405d4: SetupParameters()
    //     0xc405d4: ldr             x0, [fp, #0x10]
    //     0xc405d8: ldur            w2, [x0, #0x17]
    //     0xc405dc: add             x2, x2, HEAP, lsl #32
    //     0xc405e0: stur            x2, [fp, #-0x10]
    // 0xc405e4: CheckStackOverflow
    //     0xc405e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc405e8: cmp             SP, x16
    //     0xc405ec: b.ls            #0xc4063c
    // 0xc405f0: LoadField: r0 = r2->field_17
    //     0xc405f0: ldur            w0, [x2, #0x17]
    // 0xc405f4: DecompressPointer r0
    //     0xc405f4: add             x0, x0, HEAP, lsl #32
    // 0xc405f8: stur            x0, [fp, #-8]
    // 0xc405fc: r0 = _LiveImage()
    //     0xc405fc: bl              #0xc408c4  ; Allocate_LiveImageStub -> _LiveImage (size=0x18)
    // 0xc40600: ldur            x2, [fp, #-0x10]
    // 0xc40604: r1 = Function '<anonymous closure>':.
    //     0xc40604: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cb90] AnonymousClosure: (0xc408d0), in [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage (0xc40508)
    //     0xc40608: ldr             x1, [x1, #0xb90]
    // 0xc4060c: stur            x0, [fp, #-0x10]
    // 0xc40610: r0 = AllocateClosure()
    //     0xc40610: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc40614: ldur            x16, [fp, #-0x10]
    // 0xc40618: ldur            lr, [fp, #-8]
    // 0xc4061c: stp             lr, x16, [SP, #-0x10]!
    // 0xc40620: SaveReg r0
    //     0xc40620: str             x0, [SP, #-8]!
    // 0xc40624: r0 = _LiveImage()
    //     0xc40624: bl              #0xc40644  ; [package:flutter/src/painting/image_cache.dart] _LiveImage::_LiveImage
    // 0xc40628: add             SP, SP, #0x18
    // 0xc4062c: ldur            x0, [fp, #-0x10]
    // 0xc40630: LeaveFrame
    //     0xc40630: mov             SP, fp
    //     0xc40634: ldp             fp, lr, [SP], #0x10
    // 0xc40638: ret
    //     0xc40638: ret             
    // 0xc4063c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4063c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc40640: b               #0xc405f0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc408d0, size: 0x5c
    // 0xc408d0: EnterFrame
    //     0xc408d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc408d4: mov             fp, SP
    // 0xc408d8: ldr             x0, [fp, #0x10]
    // 0xc408dc: LoadField: r1 = r0->field_17
    //     0xc408dc: ldur            w1, [x0, #0x17]
    // 0xc408e0: DecompressPointer r1
    //     0xc408e0: add             x1, x1, HEAP, lsl #32
    // 0xc408e4: CheckStackOverflow
    //     0xc408e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc408e8: cmp             SP, x16
    //     0xc408ec: b.ls            #0xc40924
    // 0xc408f0: LoadField: r0 = r1->field_f
    //     0xc408f0: ldur            w0, [x1, #0xf]
    // 0xc408f4: DecompressPointer r0
    //     0xc408f4: add             x0, x0, HEAP, lsl #32
    // 0xc408f8: LoadField: r2 = r0->field_f
    //     0xc408f8: ldur            w2, [x0, #0xf]
    // 0xc408fc: DecompressPointer r2
    //     0xc408fc: add             x2, x2, HEAP, lsl #32
    // 0xc40900: LoadField: r0 = r1->field_13
    //     0xc40900: ldur            w0, [x1, #0x13]
    // 0xc40904: DecompressPointer r0
    //     0xc40904: add             x0, x0, HEAP, lsl #32
    // 0xc40908: stp             x0, x2, [SP, #-0x10]!
    // 0xc4090c: r0 = remove()
    //     0xc4090c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc40910: add             SP, SP, #0x10
    // 0xc40914: r0 = Null
    //     0xc40914: mov             x0, NULL
    // 0xc40918: LeaveFrame
    //     0xc40918: mov             SP, fp
    //     0xc4091c: ldp             fp, lr, [SP], #0x10
    // 0xc40920: ret
    //     0xc40920: ret             
    // 0xc40924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc40924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc40928: b               #0xc408f0
  }
  [closure] void listener(dynamic, ImageInfo?, bool) {
    // ** addr: 0xc4092c, size: 0x238
    // 0xc4092c: EnterFrame
    //     0xc4092c: stp             fp, lr, [SP, #-0x10]!
    //     0xc40930: mov             fp, SP
    // 0xc40934: AllocStack(0x28)
    //     0xc40934: sub             SP, SP, #0x28
    // 0xc40938: SetupParameters()
    //     0xc40938: ldr             x0, [fp, #0x20]
    //     0xc4093c: ldur            w1, [x0, #0x17]
    //     0xc40940: add             x1, x1, HEAP, lsl #32
    //     0xc40944: stur            x1, [fp, #-0x10]
    // 0xc40948: CheckStackOverflow
    //     0xc40948: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4094c: cmp             SP, x16
    //     0xc40950: b.ls            #0xc40b54
    // 0xc40954: ldr             x0, [fp, #0x18]
    // 0xc40958: cmp             w0, NULL
    // 0xc4095c: b.eq            #0xc409a8
    // 0xc40960: LoadField: r2 = r0->field_7
    //     0xc40960: ldur            w2, [x0, #7]
    // 0xc40964: DecompressPointer r2
    //     0xc40964: add             x2, x2, HEAP, lsl #32
    // 0xc40968: LoadField: r3 = r2->field_17
    //     0xc40968: ldur            x3, [x2, #0x17]
    // 0xc4096c: LoadField: r4 = r2->field_f
    //     0xc4096c: ldur            x4, [x2, #0xf]
    // 0xc40970: mul             x2, x3, x4
    // 0xc40974: lsl             x3, x2, #2
    // 0xc40978: stur            x3, [fp, #-8]
    // 0xc4097c: SaveReg r0
    //     0xc4097c: str             x0, [SP, #-8]!
    // 0xc40980: r0 = dispose()
    //     0xc40980: bl              #0x794180  ; [package:flutter/src/painting/image_stream.dart] ImageInfo::dispose
    // 0xc40984: add             SP, SP, #8
    // 0xc40988: ldur            x2, [fp, #-8]
    // 0xc4098c: r0 = BoxInt64Instr(r2)
    //     0xc4098c: sbfiz           x0, x2, #1, #0x1f
    //     0xc40990: cmp             x2, x0, asr #1
    //     0xc40994: b.eq            #0xc409a0
    //     0xc40998: bl              #0xd69bb8
    //     0xc4099c: stur            x2, [x0, #7]
    // 0xc409a0: mov             x1, x0
    // 0xc409a4: b               #0xc409ac
    // 0xc409a8: r1 = Null
    //     0xc409a8: mov             x1, NULL
    // 0xc409ac: ldur            x0, [fp, #-0x10]
    // 0xc409b0: stur            x1, [fp, #-0x20]
    // 0xc409b4: LoadField: r2 = r0->field_17
    //     0xc409b4: ldur            w2, [x0, #0x17]
    // 0xc409b8: DecompressPointer r2
    //     0xc409b8: add             x2, x2, HEAP, lsl #32
    // 0xc409bc: stur            x2, [fp, #-0x18]
    // 0xc409c0: cmp             w2, NULL
    // 0xc409c4: b.eq            #0xc40b5c
    // 0xc409c8: r0 = _CachedImage()
    //     0xc409c8: bl              #0xc404fc  ; Allocate_CachedImageStub -> _CachedImage (size=0x14)
    // 0xc409cc: mov             x1, x0
    // 0xc409d0: ldur            x0, [fp, #-0x18]
    // 0xc409d4: stur            x1, [fp, #-0x28]
    // 0xc409d8: StoreField: r1->field_7 = r0
    //     0xc409d8: stur            w0, [x1, #7]
    // 0xc409dc: ldur            x2, [fp, #-0x20]
    // 0xc409e0: StoreField: r1->field_b = r2
    //     0xc409e0: stur            w2, [x1, #0xb]
    // 0xc409e4: SaveReg r0
    //     0xc409e4: str             x0, [SP, #-8]!
    // 0xc409e8: r0 = keepAlive()
    //     0xc409e8: bl              #0xa4ede0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::keepAlive
    // 0xc409ec: add             SP, SP, #8
    // 0xc409f0: ldur            x1, [fp, #-0x28]
    // 0xc409f4: StoreField: r1->field_f = r0
    //     0xc409f4: stur            w0, [x1, #0xf]
    //     0xc409f8: ldurb           w16, [x1, #-1]
    //     0xc409fc: ldurb           w17, [x0, #-1]
    //     0xc40a00: and             x16, x17, x16, lsr #2
    //     0xc40a04: tst             x16, HEAP, lsr #32
    //     0xc40a08: b.eq            #0xc40a10
    //     0xc40a0c: bl              #0xd6826c
    // 0xc40a10: ldur            x0, [fp, #-0x10]
    // 0xc40a14: LoadField: r2 = r0->field_f
    //     0xc40a14: ldur            w2, [x0, #0xf]
    // 0xc40a18: DecompressPointer r2
    //     0xc40a18: add             x2, x2, HEAP, lsl #32
    // 0xc40a1c: LoadField: r3 = r0->field_13
    //     0xc40a1c: ldur            w3, [x0, #0x13]
    // 0xc40a20: DecompressPointer r3
    //     0xc40a20: add             x3, x3, HEAP, lsl #32
    // 0xc40a24: LoadField: r4 = r0->field_17
    //     0xc40a24: ldur            w4, [x0, #0x17]
    // 0xc40a28: DecompressPointer r4
    //     0xc40a28: add             x4, x4, HEAP, lsl #32
    // 0xc40a2c: stp             x3, x2, [SP, #-0x10]!
    // 0xc40a30: ldur            x16, [fp, #-0x20]
    // 0xc40a34: stp             x16, x4, [SP, #-0x10]!
    // 0xc40a38: r0 = _trackLiveImage()
    //     0xc40a38: bl              #0xc40508  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_trackLiveImage
    // 0xc40a3c: add             SP, SP, #0x20
    // 0xc40a40: ldur            x1, [fp, #-0x10]
    // 0xc40a44: LoadField: r2 = r1->field_1f
    //     0xc40a44: ldur            w2, [x1, #0x1f]
    // 0xc40a48: DecompressPointer r2
    //     0xc40a48: add             x2, x2, HEAP, lsl #32
    // 0xc40a4c: mov             x0, x2
    // 0xc40a50: stur            x2, [fp, #-0x18]
    // 0xc40a54: tbnz            w0, #5, #0xc40a5c
    // 0xc40a58: r0 = AssertBoolean()
    //     0xc40a58: bl              #0xd67df0  ; AssertBooleanStub
    // 0xc40a5c: ldur            x0, [fp, #-0x18]
    // 0xc40a60: tbnz            w0, #4, #0xc40a90
    // 0xc40a64: ldur            x0, [fp, #-0x10]
    // 0xc40a68: LoadField: r1 = r0->field_f
    //     0xc40a68: ldur            w1, [x0, #0xf]
    // 0xc40a6c: DecompressPointer r1
    //     0xc40a6c: add             x1, x1, HEAP, lsl #32
    // 0xc40a70: LoadField: r2 = r0->field_13
    //     0xc40a70: ldur            w2, [x0, #0x13]
    // 0xc40a74: DecompressPointer r2
    //     0xc40a74: add             x2, x2, HEAP, lsl #32
    // 0xc40a78: stp             x2, x1, [SP, #-0x10]!
    // 0xc40a7c: ldur            x16, [fp, #-0x28]
    // 0xc40a80: SaveReg r16
    //     0xc40a80: str             x16, [SP, #-8]!
    // 0xc40a84: r0 = _touch()
    //     0xc40a84: bl              #0xc40148  ; [package:flutter/src/painting/image_cache.dart] ImageCache::_touch
    // 0xc40a88: add             SP, SP, #0x18
    // 0xc40a8c: b               #0xc40aa0
    // 0xc40a90: ldur            x16, [fp, #-0x28]
    // 0xc40a94: SaveReg r16
    //     0xc40a94: str             x16, [SP, #-8]!
    // 0xc40a98: r0 = dispose()
    //     0xc40a98: bl              #0x5cd318  ; [package:flutter/src/painting/image_cache.dart] _CachedImageBase::dispose
    // 0xc40a9c: add             SP, SP, #8
    // 0xc40aa0: ldur            x0, [fp, #-0x10]
    // 0xc40aa4: LoadField: r1 = r0->field_f
    //     0xc40aa4: ldur            w1, [x0, #0xf]
    // 0xc40aa8: DecompressPointer r1
    //     0xc40aa8: add             x1, x1, HEAP, lsl #32
    // 0xc40aac: LoadField: r2 = r1->field_7
    //     0xc40aac: ldur            w2, [x1, #7]
    // 0xc40ab0: DecompressPointer r2
    //     0xc40ab0: add             x2, x2, HEAP, lsl #32
    // 0xc40ab4: LoadField: r1 = r0->field_13
    //     0xc40ab4: ldur            w1, [x0, #0x13]
    // 0xc40ab8: DecompressPointer r1
    //     0xc40ab8: add             x1, x1, HEAP, lsl #32
    // 0xc40abc: stp             x1, x2, [SP, #-0x10]!
    // 0xc40ac0: r0 = remove()
    //     0xc40ac0: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc40ac4: add             SP, SP, #0x10
    // 0xc40ac8: ldur            x1, [fp, #-0x10]
    // 0xc40acc: LoadField: r2 = r1->field_1b
    //     0xc40acc: ldur            w2, [x1, #0x1b]
    // 0xc40ad0: DecompressPointer r2
    //     0xc40ad0: add             x2, x2, HEAP, lsl #32
    // 0xc40ad4: mov             x0, x2
    // 0xc40ad8: stur            x2, [fp, #-0x18]
    // 0xc40adc: tbnz            w0, #5, #0xc40ae4
    // 0xc40ae0: r0 = AssertBoolean()
    //     0xc40ae0: bl              #0xd67df0  ; AssertBooleanStub
    // 0xc40ae4: ldur            x0, [fp, #-0x18]
    // 0xc40ae8: tbz             w0, #4, #0xc40b38
    // 0xc40aec: ldur            x0, [fp, #-0x10]
    // 0xc40af0: LoadField: r1 = r0->field_23
    //     0xc40af0: ldur            w1, [x0, #0x23]
    // 0xc40af4: DecompressPointer r1
    //     0xc40af4: add             x1, x1, HEAP, lsl #32
    // 0xc40af8: r16 = Sentinel
    //     0xc40af8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc40afc: cmp             w1, w16
    // 0xc40b00: b.ne            #0xc40b18
    // 0xc40b04: r16 = "pendingImage"
    //     0xc40b04: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2cb58] "pendingImage"
    //     0xc40b08: ldr             x16, [x16, #0xb58]
    // 0xc40b0c: SaveReg r16
    //     0xc40b0c: str             x16, [SP, #-8]!
    // 0xc40b10: r0 = _throwLocalNotInitialized()
    //     0xc40b10: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xc40b14: add             SP, SP, #8
    // 0xc40b18: ldur            x0, [fp, #-0x10]
    // 0xc40b1c: LoadField: r1 = r0->field_23
    //     0xc40b1c: ldur            w1, [x0, #0x23]
    // 0xc40b20: DecompressPointer r1
    //     0xc40b20: add             x1, x1, HEAP, lsl #32
    // 0xc40b24: cmp             w1, NULL
    // 0xc40b28: b.eq            #0xc40b60
    // 0xc40b2c: SaveReg r1
    //     0xc40b2c: str             x1, [SP, #-8]!
    // 0xc40b30: r0 = removeListener()
    //     0xc40b30: bl              #0x5cd248  ; [package:flutter/src/painting/image_cache.dart] _PendingImage::removeListener
    // 0xc40b34: add             SP, SP, #8
    // 0xc40b38: ldur            x1, [fp, #-0x10]
    // 0xc40b3c: r2 = true
    //     0xc40b3c: add             x2, NULL, #0x20  ; true
    // 0xc40b40: StoreField: r1->field_1b = r2
    //     0xc40b40: stur            w2, [x1, #0x1b]
    // 0xc40b44: r0 = Null
    //     0xc40b44: mov             x0, NULL
    // 0xc40b48: LeaveFrame
    //     0xc40b48: mov             SP, fp
    //     0xc40b4c: ldp             fp, lr, [SP], #0x10
    // 0xc40b50: ret
    //     0xc40b50: ret             
    // 0xc40b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc40b54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc40b58: b               #0xc40954
    // 0xc40b5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc40b5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc40b60: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc40b60: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

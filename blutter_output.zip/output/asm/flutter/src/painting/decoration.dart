// lib: , url: package:flutter/src/painting/decoration.dart

// class id: 1049359, size: 0x8
class :: {
}

// class id: 2934, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Decoration extends _DiagnosticableTree&Object&Diagnosticable {

  _ toStringShort(/* No info */) {
    // ** addr: 0xa77da8, size: 0xc
    // 0xa77da8: r0 = "Decoration"
    //     0xa77da8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe530] "Decoration"
    //     0xa77dac: ldr             x0, [x0, #0x530]
    // 0xa77db0: ret
    //     0xa77db0: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf2618, size: 0x224
    // 0xbf2618: EnterFrame
    //     0xbf2618: stp             fp, lr, [SP, #-0x10]!
    //     0xbf261c: mov             fp, SP
    // 0xbf2620: CheckStackOverflow
    //     0xbf2620: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf2624: cmp             SP, x16
    //     0xbf2628: b.ls            #0xbf2830
    // 0xbf262c: ldr             x1, [fp, #0x20]
    // 0xbf2630: cmp             w1, NULL
    // 0xbf2634: b.ne            #0xbf2654
    // 0xbf2638: ldr             x2, [fp, #0x18]
    // 0xbf263c: cmp             w2, NULL
    // 0xbf2640: b.ne            #0xbf2658
    // 0xbf2644: r0 = Null
    //     0xbf2644: mov             x0, NULL
    // 0xbf2648: LeaveFrame
    //     0xbf2648: mov             SP, fp
    //     0xbf264c: ldp             fp, lr, [SP], #0x10
    // 0xbf2650: ret
    //     0xbf2650: ret             
    // 0xbf2654: ldr             x2, [fp, #0x18]
    // 0xbf2658: cmp             w1, NULL
    // 0xbf265c: b.ne            #0xbf26a4
    // 0xbf2660: ldr             d0, [fp, #0x10]
    // 0xbf2664: cmp             w2, NULL
    // 0xbf2668: b.eq            #0xbf2838
    // 0xbf266c: r0 = LoadClassIdInstr(r2)
    //     0xbf266c: ldur            x0, [x2, #-1]
    //     0xbf2670: ubfx            x0, x0, #0xc, #0x14
    // 0xbf2674: stp             NULL, x2, [SP, #-0x10]!
    // 0xbf2678: SaveReg d0
    //     0xbf2678: str             d0, [SP, #-8]!
    // 0xbf267c: r0 = GDT[cid_x0 + -0xc7c]()
    //     0xbf267c: sub             lr, x0, #0xc7c
    //     0xbf2680: ldr             lr, [x21, lr, lsl #3]
    //     0xbf2684: blr             lr
    // 0xbf2688: add             SP, SP, #0x18
    // 0xbf268c: cmp             w0, NULL
    // 0xbf2690: b.ne            #0xbf2698
    // 0xbf2694: ldr             x0, [fp, #0x18]
    // 0xbf2698: LeaveFrame
    //     0xbf2698: mov             SP, fp
    //     0xbf269c: ldp             fp, lr, [SP], #0x10
    // 0xbf26a0: ret
    //     0xbf26a0: ret             
    // 0xbf26a4: ldr             d0, [fp, #0x10]
    // 0xbf26a8: cmp             w2, NULL
    // 0xbf26ac: b.ne            #0xbf26e8
    // 0xbf26b0: r0 = LoadClassIdInstr(r1)
    //     0xbf26b0: ldur            x0, [x1, #-1]
    //     0xbf26b4: ubfx            x0, x0, #0xc, #0x14
    // 0xbf26b8: stp             NULL, x1, [SP, #-0x10]!
    // 0xbf26bc: SaveReg d0
    //     0xbf26bc: str             d0, [SP, #-8]!
    // 0xbf26c0: r0 = GDT[cid_x0 + -0xc72]()
    //     0xbf26c0: sub             lr, x0, #0xc72
    //     0xbf26c4: ldr             lr, [x21, lr, lsl #3]
    //     0xbf26c8: blr             lr
    // 0xbf26cc: add             SP, SP, #0x18
    // 0xbf26d0: cmp             w0, NULL
    // 0xbf26d4: b.ne            #0xbf26dc
    // 0xbf26d8: ldr             x0, [fp, #0x20]
    // 0xbf26dc: LeaveFrame
    //     0xbf26dc: mov             SP, fp
    //     0xbf26e0: ldp             fp, lr, [SP], #0x10
    // 0xbf26e4: ret
    //     0xbf26e4: ret             
    // 0xbf26e8: d1 = 0.000000
    //     0xbf26e8: eor             v1.16b, v1.16b, v1.16b
    // 0xbf26ec: fcmp            d0, d1
    // 0xbf26f0: b.vs            #0xbf2708
    // 0xbf26f4: b.ne            #0xbf2708
    // 0xbf26f8: ldr             x0, [fp, #0x20]
    // 0xbf26fc: LeaveFrame
    //     0xbf26fc: mov             SP, fp
    //     0xbf2700: ldp             fp, lr, [SP], #0x10
    // 0xbf2704: ret
    //     0xbf2704: ret             
    // 0xbf2708: d1 = 1.000000
    //     0xbf2708: fmov            d1, #1.00000000
    // 0xbf270c: fcmp            d0, d1
    // 0xbf2710: b.vs            #0xbf2728
    // 0xbf2714: b.ne            #0xbf2728
    // 0xbf2718: mov             x0, x2
    // 0xbf271c: LeaveFrame
    //     0xbf271c: mov             SP, fp
    //     0xbf2720: ldp             fp, lr, [SP], #0x10
    // 0xbf2724: ret
    //     0xbf2724: ret             
    // 0xbf2728: r0 = LoadClassIdInstr(r2)
    //     0xbf2728: ldur            x0, [x2, #-1]
    //     0xbf272c: ubfx            x0, x0, #0xc, #0x14
    // 0xbf2730: ldr             x16, [fp, #0x20]
    // 0xbf2734: stp             x16, x2, [SP, #-0x10]!
    // 0xbf2738: SaveReg d0
    //     0xbf2738: str             d0, [SP, #-8]!
    // 0xbf273c: r0 = GDT[cid_x0 + -0xc7c]()
    //     0xbf273c: sub             lr, x0, #0xc7c
    //     0xbf2740: ldr             lr, [x21, lr, lsl #3]
    //     0xbf2744: blr             lr
    // 0xbf2748: add             SP, SP, #0x18
    // 0xbf274c: cmp             w0, NULL
    // 0xbf2750: b.ne            #0xbf2780
    // 0xbf2754: ldr             x1, [fp, #0x20]
    // 0xbf2758: ldr             d0, [fp, #0x10]
    // 0xbf275c: r0 = LoadClassIdInstr(r1)
    //     0xbf275c: ldur            x0, [x1, #-1]
    //     0xbf2760: ubfx            x0, x0, #0xc, #0x14
    // 0xbf2764: ldr             x16, [fp, #0x18]
    // 0xbf2768: stp             x16, x1, [SP, #-0x10]!
    // 0xbf276c: SaveReg d0
    //     0xbf276c: str             d0, [SP, #-8]!
    // 0xbf2770: r0 = GDT[cid_x0 + -0xc72]()
    //     0xbf2770: sub             lr, x0, #0xc72
    //     0xbf2774: ldr             lr, [x21, lr, lsl #3]
    //     0xbf2778: blr             lr
    // 0xbf277c: add             SP, SP, #0x18
    // 0xbf2780: cmp             w0, NULL
    // 0xbf2784: b.ne            #0xbf2824
    // 0xbf2788: ldr             d0, [fp, #0x10]
    // 0xbf278c: d1 = 0.500000
    //     0xbf278c: fmov            d1, #0.50000000
    // 0xbf2790: fcmp            d0, d1
    // 0xbf2794: b.vs            #0xbf27dc
    // 0xbf2798: b.ge            #0xbf27dc
    // 0xbf279c: ldr             x1, [fp, #0x20]
    // 0xbf27a0: d2 = 2.000000
    //     0xbf27a0: fmov            d2, #2.00000000
    // 0xbf27a4: fmul            d1, d0, d2
    // 0xbf27a8: r0 = LoadClassIdInstr(r1)
    //     0xbf27a8: ldur            x0, [x1, #-1]
    //     0xbf27ac: ubfx            x0, x0, #0xc, #0x14
    // 0xbf27b0: stp             NULL, x1, [SP, #-0x10]!
    // 0xbf27b4: SaveReg d1
    //     0xbf27b4: str             d1, [SP, #-8]!
    // 0xbf27b8: r0 = GDT[cid_x0 + -0xc72]()
    //     0xbf27b8: sub             lr, x0, #0xc72
    //     0xbf27bc: ldr             lr, [x21, lr, lsl #3]
    //     0xbf27c0: blr             lr
    // 0xbf27c4: add             SP, SP, #0x18
    // 0xbf27c8: cmp             w0, NULL
    // 0xbf27cc: b.ne            #0xbf27d4
    // 0xbf27d0: ldr             x0, [fp, #0x20]
    // 0xbf27d4: mov             x1, x0
    // 0xbf27d8: b               #0xbf2820
    // 0xbf27dc: ldr             x1, [fp, #0x18]
    // 0xbf27e0: d2 = 2.000000
    //     0xbf27e0: fmov            d2, #2.00000000
    // 0xbf27e4: fsub            d3, d0, d1
    // 0xbf27e8: fmul            d0, d3, d2
    // 0xbf27ec: r0 = LoadClassIdInstr(r1)
    //     0xbf27ec: ldur            x0, [x1, #-1]
    //     0xbf27f0: ubfx            x0, x0, #0xc, #0x14
    // 0xbf27f4: stp             NULL, x1, [SP, #-0x10]!
    // 0xbf27f8: SaveReg d0
    //     0xbf27f8: str             d0, [SP, #-8]!
    // 0xbf27fc: r0 = GDT[cid_x0 + -0xc7c]()
    //     0xbf27fc: sub             lr, x0, #0xc7c
    //     0xbf2800: ldr             lr, [x21, lr, lsl #3]
    //     0xbf2804: blr             lr
    // 0xbf2808: add             SP, SP, #0x18
    // 0xbf280c: cmp             w0, NULL
    // 0xbf2810: b.ne            #0xbf281c
    // 0xbf2814: ldr             x1, [fp, #0x18]
    // 0xbf2818: b               #0xbf2820
    // 0xbf281c: mov             x1, x0
    // 0xbf2820: mov             x0, x1
    // 0xbf2824: LeaveFrame
    //     0xbf2824: mov             SP, fp
    //     0xbf2828: ldp             fp, lr, [SP], #0x10
    // 0xbf282c: ret
    //     0xbf282c: ret             
    // 0xbf2830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2830: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2834: b               #0xbf262c
    // 0xbf2838: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf2838: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 4508, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class BoxPainter extends Object {
}

// lib: , url: package:flutter/src/foundation/_isolates_io.dart

// class id: 1049120, size: 0x8
class :: {

  [closure] static Future<Y1> compute<Y0, Y1>(dynamic, (dynamic, Y0) => FutureOr<Y1>, Y0, {String? debugLabel}) {
    // ** addr: 0x5be368, size: 0xd0
    // 0x5be368: EnterFrame
    //     0x5be368: stp             fp, lr, [SP, #-0x10]!
    //     0x5be36c: mov             fp, SP
    // 0x5be370: mov             x0, x4
    // 0x5be374: LoadField: r1 = r0->field_13
    //     0x5be374: ldur            w1, [x0, #0x13]
    // 0x5be378: DecompressPointer r1
    //     0x5be378: add             x1, x1, HEAP, lsl #32
    // 0x5be37c: sub             x2, x1, #6
    // 0x5be380: add             x3, fp, w2, sxtw #2
    // 0x5be384: ldr             x3, [x3, #0x20]
    // 0x5be388: add             x4, fp, w2, sxtw #2
    // 0x5be38c: ldr             x4, [x4, #0x18]
    // 0x5be390: add             x5, fp, w2, sxtw #2
    // 0x5be394: ldr             x5, [x5, #0x10]
    // 0x5be398: LoadField: r2 = r0->field_1f
    //     0x5be398: ldur            w2, [x0, #0x1f]
    // 0x5be39c: DecompressPointer r2
    //     0x5be39c: add             x2, x2, HEAP, lsl #32
    // 0x5be3a0: r16 = "debugLabel"
    //     0x5be3a0: ldr             x16, [PP, #0x44b0]  ; [pp+0x44b0] "debugLabel"
    // 0x5be3a4: cmp             w2, w16
    // 0x5be3a8: b.ne            #0x5be3c4
    // 0x5be3ac: LoadField: r2 = r0->field_23
    //     0x5be3ac: ldur            w2, [x0, #0x23]
    // 0x5be3b0: DecompressPointer r2
    //     0x5be3b0: add             x2, x2, HEAP, lsl #32
    // 0x5be3b4: sub             w6, w1, w2
    // 0x5be3b8: add             x1, fp, w6, sxtw #2
    // 0x5be3bc: ldr             x1, [x1, #8]
    // 0x5be3c0: b               #0x5be3c8
    // 0x5be3c4: r1 = Null
    //     0x5be3c4: mov             x1, NULL
    // 0x5be3c8: LoadField: r2 = r0->field_f
    //     0x5be3c8: ldur            w2, [x0, #0xf]
    // 0x5be3cc: DecompressPointer r2
    //     0x5be3cc: add             x2, x2, HEAP, lsl #32
    // 0x5be3d0: cbnz            w2, #0x5be3dc
    // 0x5be3d4: r0 = Null
    //     0x5be3d4: mov             x0, NULL
    // 0x5be3d8: b               #0x5be3ec
    // 0x5be3dc: LoadField: r2 = r0->field_17
    //     0x5be3dc: ldur            w2, [x0, #0x17]
    // 0x5be3e0: DecompressPointer r2
    //     0x5be3e0: add             x2, x2, HEAP, lsl #32
    // 0x5be3e4: add             x0, fp, w2, sxtw #2
    // 0x5be3e8: ldr             x0, [x0, #0x10]
    // 0x5be3ec: LoadField: r2 = r3->field_f
    //     0x5be3ec: ldur            w2, [x3, #0xf]
    // 0x5be3f0: DecompressPointer r2
    //     0x5be3f0: add             x2, x2, HEAP, lsl #32
    // 0x5be3f4: r16 = 
    //     0x5be3f4: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: 
    // 0x5be3f8: cmp             w2, w16
    // 0x5be3fc: b.eq            #0x5be404
    // 0x5be400: mov             x0, x2
    // 0x5be404: CheckStackOverflow
    //     0x5be404: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5be408: cmp             SP, x16
    //     0x5be40c: b.ls            #0x5be430
    // 0x5be410: stp             x4, x0, [SP, #-0x10]!
    // 0x5be414: stp             x1, x5, [SP, #-0x10]!
    // 0x5be418: r4 = const [0x2, 0x3, 0x3, 0x2, debugLabel, 0x2, null]
    //     0x5be418: ldr             x4, [PP, #0x50e8]  ; [pp+0x50e8] List(7) [0x2, 0x3, 0x3, 0x2, "debugLabel", 0x2, Null]
    // 0x5be41c: r0 = compute()
    //     0x5be41c: bl              #0x5be438  ; [package:flutter/src/foundation/_isolates_io.dart] ::compute
    // 0x5be420: add             SP, SP, #0x20
    // 0x5be424: LeaveFrame
    //     0x5be424: mov             SP, fp
    //     0x5be428: ldp             fp, lr, [SP], #0x10
    // 0x5be42c: ret
    //     0x5be42c: ret             
    // 0x5be430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5be430: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5be434: b               #0x5be410
  }
  static _ compute(/* No info */) async {
    // ** addr: 0x5be438, size: 0x188
    // 0x5be438: EnterFrame
    //     0x5be438: stp             fp, lr, [SP, #-0x10]!
    //     0x5be43c: mov             fp, SP
    // 0x5be440: AllocStack(0x30)
    //     0x5be440: sub             SP, SP, #0x30
    // 0x5be444: SetupParameters(dynamic _ /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, {dynamic debugLabel = Null /* r1, fp-0x18 */})
    //     0x5be444: stur            NULL, [fp, #-8]
    //     0x5be448: mov             x0, x4
    //     0x5be44c: ldur            w1, [x0, #0x13]
    //     0x5be450: add             x1, x1, HEAP, lsl #32
    //     0x5be454: sub             x2, x1, #4
    //     0x5be458: add             x3, fp, w2, sxtw #2
    //     0x5be45c: ldr             x3, [x3, #0x18]
    //     0x5be460: stur            x3, [fp, #-0x28]
    //     0x5be464: add             x4, fp, w2, sxtw #2
    //     0x5be468: ldr             x4, [x4, #0x10]
    //     0x5be46c: stur            x4, [fp, #-0x20]
    //     0x5be470: ldur            w2, [x0, #0x1f]
    //     0x5be474: add             x2, x2, HEAP, lsl #32
    //     0x5be478: ldr             x16, [PP, #0x44b0]  ; [pp+0x44b0] "debugLabel"
    //     0x5be47c: cmp             w2, w16
    //     0x5be480: b.ne            #0x5be49c
    //     0x5be484: ldur            w2, [x0, #0x23]
    //     0x5be488: add             x2, x2, HEAP, lsl #32
    //     0x5be48c: sub             w5, w1, w2
    //     0x5be490: add             x1, fp, w5, sxtw #2
    //     0x5be494: ldr             x1, [x1, #8]
    //     0x5be498: b               #0x5be4a0
    //     0x5be49c: mov             x1, NULL
    //     0x5be4a0: stur            x1, [fp, #-0x18]
    //     0x5be4a4: ldur            w2, [x0, #0xf]
    //     0x5be4a8: add             x2, x2, HEAP, lsl #32
    //     0x5be4ac: cbnz            w2, #0x5be4b8
    //     0x5be4b0: mov             x0, NULL
    //     0x5be4b4: b               #0x5be4c8
    //     0x5be4b8: ldur            w2, [x0, #0x17]
    //     0x5be4bc: add             x2, x2, HEAP, lsl #32
    //     0x5be4c0: add             x0, fp, w2, sxtw #2
    //     0x5be4c4: ldr             x0, [x0, #0x10]
    //     0x5be4c8: stur            x0, [fp, #-0x10]
    // 0x5be4cc: CheckStackOverflow
    //     0x5be4cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5be4d0: cmp             SP, x16
    //     0x5be4d4: b.ls            #0x5be5b8
    // 0x5be4d8: r1 = 2
    //     0x5be4d8: mov             x1, #2
    // 0x5be4dc: r0 = AllocateContext()
    //     0x5be4dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5be4e0: mov             x4, x0
    // 0x5be4e4: ldur            x0, [fp, #-0x28]
    // 0x5be4e8: stur            x4, [fp, #-0x30]
    // 0x5be4ec: StoreField: r4->field_f = r0
    //     0x5be4ec: stur            w0, [x4, #0xf]
    // 0x5be4f0: ldur            x0, [fp, #-0x20]
    // 0x5be4f4: StoreField: r4->field_13 = r0
    //     0x5be4f4: stur            w0, [x4, #0x13]
    // 0x5be4f8: ldur            x1, [fp, #-0x10]
    // 0x5be4fc: r2 = Null
    //     0x5be4fc: mov             x2, NULL
    // 0x5be500: r3 = <Y1>
    //     0x5be500: ldr             x3, [PP, #0x50f0]  ; [pp+0x50f0] TypeArguments: <Y1>
    // 0x5be504: r0 = Null
    //     0x5be504: mov             x0, NULL
    // 0x5be508: cmp             x2, x0
    // 0x5be50c: b.ne            #0x5be518
    // 0x5be510: cmp             x1, x0
    // 0x5be514: b.eq            #0x5be524
    // 0x5be518: r24 = InstantiateTypeArgumentsStub
    //     0x5be518: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x5be51c: LoadField: r30 = r24->field_7
    //     0x5be51c: ldur            lr, [x24, #7]
    // 0x5be520: blr             lr
    // 0x5be524: mov             x1, x0
    // 0x5be528: stur            x1, [fp, #-0x20]
    // 0x5be52c: r0 = InitAsync()
    //     0x5be52c: bl              #0x4b92e4  ; InitAsyncStub
    // 0x5be530: ldur            x0, [fp, #-0x18]
    // 0x5be534: cmp             w0, NULL
    // 0x5be538: b.ne            #0x5be544
    // 0x5be53c: r4 = "compute"
    //     0x5be53c: ldr             x4, [PP, #0x50f8]  ; [pp+0x50f8] "compute"
    // 0x5be540: b               #0x5be548
    // 0x5be544: mov             x4, x0
    // 0x5be548: ldur            x0, [fp, #-0x10]
    // 0x5be54c: mov             x1, x0
    // 0x5be550: stur            x4, [fp, #-0x18]
    // 0x5be554: r2 = Null
    //     0x5be554: mov             x2, NULL
    // 0x5be558: r3 = <Y1>
    //     0x5be558: ldr             x3, [PP, #0x50f0]  ; [pp+0x50f0] TypeArguments: <Y1>
    // 0x5be55c: r0 = Null
    //     0x5be55c: mov             x0, NULL
    // 0x5be560: cmp             x2, x0
    // 0x5be564: b.ne            #0x5be570
    // 0x5be568: cmp             x1, x0
    // 0x5be56c: b.eq            #0x5be57c
    // 0x5be570: r24 = InstantiateTypeArgumentsStub
    //     0x5be570: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x5be574: LoadField: r30 = r24->field_7
    //     0x5be574: ldur            lr, [x24, #7]
    // 0x5be578: blr             lr
    // 0x5be57c: ldur            x2, [fp, #-0x30]
    // 0x5be580: r1 = Function '<anonymous closure>': static.
    //     0x5be580: ldr             x1, [PP, #0x5100]  ; [pp+0x5100] AnonymousClosure: static (0x5bef68), in [package:flutter/src/foundation/_isolates_io.dart] ::compute (0x5be438)
    // 0x5be584: stur            x0, [fp, #-0x20]
    // 0x5be588: r0 = AllocateClosure()
    //     0x5be588: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5be58c: mov             x1, x0
    // 0x5be590: ldur            x0, [fp, #-0x10]
    // 0x5be594: StoreField: r1->field_b = r0
    //     0x5be594: stur            w0, [x1, #0xb]
    // 0x5be598: ldur            x16, [fp, #-0x20]
    // 0x5be59c: stp             x1, x16, [SP, #-0x10]!
    // 0x5be5a0: ldur            x16, [fp, #-0x18]
    // 0x5be5a4: SaveReg r16
    //     0x5be5a4: str             x16, [SP, #-8]!
    // 0x5be5a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5be5a8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5be5ac: r0 = run()
    //     0x5be5ac: bl              #0x5be5c0  ; [dart:isolate] Isolate::run
    // 0x5be5b0: add             SP, SP, #0x18
    // 0x5be5b4: r0 = ReturnAsync()
    //     0x5be5b4: b               #0x501858  ; ReturnAsyncStub
    // 0x5be5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5be5b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5be5bc: b               #0x5be4d8
  }
  [closure] static FutureOr<Y1> <anonymous closure>(dynamic) {
    // ** addr: 0x5bef68, size: 0x64
    // 0x5bef68: EnterFrame
    //     0x5bef68: stp             fp, lr, [SP, #-0x10]!
    //     0x5bef6c: mov             fp, SP
    // 0x5bef70: ldr             x0, [fp, #0x10]
    // 0x5bef74: LoadField: r1 = r0->field_17
    //     0x5bef74: ldur            w1, [x0, #0x17]
    // 0x5bef78: DecompressPointer r1
    //     0x5bef78: add             x1, x1, HEAP, lsl #32
    // 0x5bef7c: CheckStackOverflow
    //     0x5bef7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bef80: cmp             SP, x16
    //     0x5bef84: b.ls            #0x5befc0
    // 0x5bef88: LoadField: r0 = r1->field_f
    //     0x5bef88: ldur            w0, [x1, #0xf]
    // 0x5bef8c: DecompressPointer r0
    //     0x5bef8c: add             x0, x0, HEAP, lsl #32
    // 0x5bef90: LoadField: r2 = r1->field_13
    //     0x5bef90: ldur            w2, [x1, #0x13]
    // 0x5bef94: DecompressPointer r2
    //     0x5bef94: add             x2, x2, HEAP, lsl #32
    // 0x5bef98: cmp             w0, NULL
    // 0x5bef9c: b.eq            #0x5befc8
    // 0x5befa0: stp             x2, x0, [SP, #-0x10]!
    // 0x5befa4: ClosureCall
    //     0x5befa4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5befa8: ldur            x2, [x0, #0x1f]
    //     0x5befac: blr             x2
    // 0x5befb0: add             SP, SP, #0x10
    // 0x5befb4: LeaveFrame
    //     0x5befb4: mov             SP, fp
    //     0x5befb8: ldp             fp, lr, [SP], #0x10
    // 0x5befbc: ret
    //     0x5befbc: ret             
    // 0x5befc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5befc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5befc4: b               #0x5bef88
    // 0x5befc8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5befc8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

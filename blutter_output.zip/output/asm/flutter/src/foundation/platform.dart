// lib: , url: package:flutter/src/foundation/platform.dart

// class id: 1049142, size: 0x8
class :: {
}

// class id: 5983, size: 0x14, field offset: 0x14
enum TargetPlatform extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15c30, size: 0x5c
    // 0xb15c30: EnterFrame
    //     0xb15c30: stp             fp, lr, [SP, #-0x10]!
    //     0xb15c34: mov             fp, SP
    // 0xb15c38: CheckStackOverflow
    //     0xb15c38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15c3c: cmp             SP, x16
    //     0xb15c40: b.ls            #0xb15c84
    // 0xb15c44: r1 = Null
    //     0xb15c44: mov             x1, NULL
    // 0xb15c48: r2 = 4
    //     0xb15c48: mov             x2, #4
    // 0xb15c4c: r0 = AllocateArray()
    //     0xb15c4c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15c50: r17 = "TargetPlatform."
    //     0xb15c50: add             x17, PP, #0xb, lsl #12  ; [pp+0xb128] "TargetPlatform."
    //     0xb15c54: ldr             x17, [x17, #0x128]
    // 0xb15c58: StoreField: r0->field_f = r17
    //     0xb15c58: stur            w17, [x0, #0xf]
    // 0xb15c5c: ldr             x1, [fp, #0x10]
    // 0xb15c60: LoadField: r2 = r1->field_f
    //     0xb15c60: ldur            w2, [x1, #0xf]
    // 0xb15c64: DecompressPointer r2
    //     0xb15c64: add             x2, x2, HEAP, lsl #32
    // 0xb15c68: StoreField: r0->field_13 = r2
    //     0xb15c68: stur            w2, [x0, #0x13]
    // 0xb15c6c: SaveReg r0
    //     0xb15c6c: str             x0, [SP, #-8]!
    // 0xb15c70: r0 = _interpolate()
    //     0xb15c70: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15c74: add             SP, SP, #8
    // 0xb15c78: LeaveFrame
    //     0xb15c78: mov             SP, fp
    //     0xb15c7c: ldp             fp, lr, [SP], #0x10
    // 0xb15c80: ret
    //     0xb15c80: ret             
    // 0xb15c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15c84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15c88: b               #0xb15c44
  }
}

// lib: , url: package:flutter/src/foundation/assertions.dart

// class id: 1049123, size: 0x8
class :: {

  static _ debugPrintStack(/* No info */) {
    // ** addr: 0x4fd370, size: 0x188
    // 0x4fd370: EnterFrame
    //     0x4fd370: stp             fp, lr, [SP, #-0x10]!
    //     0x4fd374: mov             fp, SP
    // 0x4fd378: AllocStack(0x10)
    //     0x4fd378: sub             SP, SP, #0x10
    // 0x4fd37c: CheckStackOverflow
    //     0x4fd37c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fd380: cmp             SP, x16
    //     0x4fd384: b.ls            #0x4fd4f0
    // 0x4fd388: ldr             x0, [fp, #0x18]
    // 0x4fd38c: cmp             w0, NULL
    // 0x4fd390: b.eq            #0x4fd3c8
    // 0x4fd394: r0 = InitLateStaticField(0xd2c) // [package:flutter/src/foundation/print.dart] ::debugPrint
    //     0x4fd394: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4fd398: ldr             x0, [x0, #0x1a58]
    //     0x4fd39c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4fd3a0: cmp             w0, w16
    //     0x4fd3a4: b.ne            #0x4fd3b0
    //     0x4fd3a8: ldr             x2, [PP, #0xf28]  ; [pp+0xf28] Field <::.debugPrint>: static late (offset: 0xd2c)
    //     0x4fd3ac: bl              #0xd67d44
    // 0x4fd3b0: ldr             x16, [fp, #0x18]
    // 0x4fd3b4: stp             x16, x0, [SP, #-0x10]!
    // 0x4fd3b8: ClosureCall
    //     0x4fd3b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4fd3bc: ldur            x2, [x0, #0x1f]
    //     0x4fd3c0: blr             x2
    // 0x4fd3c4: add             SP, SP, #0x10
    // 0x4fd3c8: ldr             x0, [fp, #0x10]
    // 0x4fd3cc: cmp             w0, NULL
    // 0x4fd3d0: b.ne            #0x4fd3dc
    // 0x4fd3d4: r0 = current()
    //     0x4fd3d4: bl              #0x4ff3d0  ; [dart:core] StackTrace::current
    // 0x4fd3d8: b               #0x4fd410
    // 0x4fd3dc: r0 = InitLateStaticField(0xcf8) // [package:flutter/src/foundation/assertions.dart] FlutterError::demangleStackTrace
    //     0x4fd3dc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4fd3e0: ldr             x0, [x0, #0x19f0]
    //     0x4fd3e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4fd3e8: cmp             w0, w16
    //     0x4fd3ec: b.ne            #0x4fd3f8
    //     0x4fd3f0: ldr             x2, [PP, #0xfa8]  ; [pp+0xfa8] Field <FlutterError.demangleStackTrace>: static late (offset: 0xcf8)
    //     0x4fd3f4: bl              #0xd67d44
    // 0x4fd3f8: ldr             x16, [fp, #0x10]
    // 0x4fd3fc: stp             x16, x0, [SP, #-0x10]!
    // 0x4fd400: ClosureCall
    //     0x4fd400: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4fd404: ldur            x2, [x0, #0x1f]
    //     0x4fd408: blr             x2
    // 0x4fd40c: add             SP, SP, #0x10
    // 0x4fd410: r1 = LoadClassIdInstr(r0)
    //     0x4fd410: ldur            x1, [x0, #-1]
    //     0x4fd414: ubfx            x1, x1, #0xc, #0x14
    // 0x4fd418: SaveReg r0
    //     0x4fd418: str             x0, [SP, #-8]!
    // 0x4fd41c: mov             x0, x1
    // 0x4fd420: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fd420: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fd424: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x4fd424: mov             x17, #0x3f73
    //     0x4fd428: add             lr, x0, x17
    //     0x4fd42c: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd430: blr             lr
    // 0x4fd434: add             SP, SP, #8
    // 0x4fd438: SaveReg r0
    //     0x4fd438: str             x0, [SP, #-8]!
    // 0x4fd43c: r0 = trimRight()
    //     0x4fd43c: bl              #0x4fce30  ; [dart:core] _StringBase::trimRight
    // 0x4fd440: add             SP, SP, #8
    // 0x4fd444: r1 = LoadClassIdInstr(r0)
    //     0x4fd444: ldur            x1, [x0, #-1]
    //     0x4fd448: ubfx            x1, x1, #0xc, #0x14
    // 0x4fd44c: r16 = "\n"
    //     0x4fd44c: ldr             x16, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x4fd450: stp             x16, x0, [SP, #-0x10]!
    // 0x4fd454: mov             x0, x1
    // 0x4fd458: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4fd458: sub             lr, x0, #0xff8
    //     0x4fd45c: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd460: blr             lr
    // 0x4fd464: add             SP, SP, #0x10
    // 0x4fd468: SaveReg r0
    //     0x4fd468: str             x0, [SP, #-8]!
    // 0x4fd46c: r0 = 100
    //     0x4fd46c: mov             x0, #0x64
    // 0x4fd470: SaveReg r0
    //     0x4fd470: str             x0, [SP, #-8]!
    // 0x4fd474: r0 = take()
    //     0x4fd474: bl              #0x622048  ; [dart:collection] _ListBase&Object&ListMixin::take
    // 0x4fd478: add             SP, SP, #0x10
    // 0x4fd47c: stur            x0, [fp, #-8]
    // 0x4fd480: r0 = InitLateStaticField(0xd2c) // [package:flutter/src/foundation/print.dart] ::debugPrint
    //     0x4fd480: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4fd484: ldr             x0, [x0, #0x1a58]
    //     0x4fd488: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4fd48c: cmp             w0, w16
    //     0x4fd490: b.ne            #0x4fd49c
    //     0x4fd494: ldr             x2, [PP, #0xf28]  ; [pp+0xf28] Field <::.debugPrint>: static late (offset: 0xd2c)
    //     0x4fd498: bl              #0xd67d44
    // 0x4fd49c: stur            x0, [fp, #-0x10]
    // 0x4fd4a0: ldur            x16, [fp, #-8]
    // 0x4fd4a4: SaveReg r16
    //     0x4fd4a4: str             x16, [SP, #-8]!
    // 0x4fd4a8: r0 = defaultStackFilter()
    //     0x4fd4a8: bl              #0x4fd4f8  ; [package:flutter/src/foundation/assertions.dart] FlutterError::defaultStackFilter
    // 0x4fd4ac: add             SP, SP, #8
    // 0x4fd4b0: r16 = "\n"
    //     0x4fd4b0: ldr             x16, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x4fd4b4: stp             x16, x0, [SP, #-0x10]!
    // 0x4fd4b8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fd4b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fd4bc: r0 = join()
    //     0x4fd4bc: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0x4fd4c0: add             SP, SP, #0x10
    // 0x4fd4c4: ldur            x16, [fp, #-0x10]
    // 0x4fd4c8: stp             x0, x16, [SP, #-0x10]!
    // 0x4fd4cc: ldur            x0, [fp, #-0x10]
    // 0x4fd4d0: ClosureCall
    //     0x4fd4d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4fd4d4: ldur            x2, [x0, #0x1f]
    //     0x4fd4d8: blr             x2
    // 0x4fd4dc: add             SP, SP, #0x10
    // 0x4fd4e0: r0 = Null
    //     0x4fd4e0: mov             x0, NULL
    // 0x4fd4e4: LeaveFrame
    //     0x4fd4e4: mov             SP, fp
    //     0x4fd4e8: ldp             fp, lr, [SP], #0x10
    // 0x4fd4ec: ret
    //     0x4fd4ec: ret             
    // 0x4fd4f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fd4f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fd4f4: b               #0x4fd388
  }
}

// class id: 2612, size: 0xc, field offset: 0xc
class _FlutterErrorDetailsNode extends DiagnosticableNode<FlutterErrorDetails> {
}

// class id: 2633, size: 0x30, field offset: 0x30
abstract class _ErrorDiagnostic extends DiagnosticsProperty<List<Object>> {

  _ _ErrorDiagnostic(/* No info */) {
    // ** addr: 0x500dcc, size: 0xa4
    // 0x500dcc: EnterFrame
    //     0x500dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x500dd0: mov             fp, SP
    // 0x500dd4: AllocStack(0x8)
    //     0x500dd4: sub             SP, SP, #8
    // 0x500dd8: r0 = 2
    //     0x500dd8: mov             x0, #2
    // 0x500ddc: mov             x2, x0
    // 0x500de0: r1 = Null
    //     0x500de0: mov             x1, NULL
    // 0x500de4: r0 = AllocateArray()
    //     0x500de4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x500de8: mov             x2, x0
    // 0x500dec: ldr             x0, [fp, #0x18]
    // 0x500df0: stur            x2, [fp, #-8]
    // 0x500df4: StoreField: r2->field_f = r0
    //     0x500df4: stur            w0, [x2, #0xf]
    // 0x500df8: r1 = <Object>
    //     0x500df8: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0x500dfc: r0 = AllocateGrowableArray()
    //     0x500dfc: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x500e00: ldur            x1, [fp, #-8]
    // 0x500e04: StoreField: r0->field_f = r1
    //     0x500e04: stur            w1, [x0, #0xf]
    // 0x500e08: r1 = 2
    //     0x500e08: mov             x1, #2
    // 0x500e0c: StoreField: r0->field_b = r1
    //     0x500e0c: stur            w1, [x0, #0xb]
    // 0x500e10: ldr             x2, [fp, #0x20]
    // 0x500e14: r1 = false
    //     0x500e14: add             x1, NULL, #0x30  ; false
    // 0x500e18: StoreField: r2->field_13 = r1
    //     0x500e18: stur            w1, [x2, #0x13]
    // 0x500e1c: r1 = true
    //     0x500e1c: add             x1, NULL, #0x20  ; true
    // 0x500e20: StoreField: r2->field_1b = r1
    //     0x500e20: stur            w1, [x2, #0x1b]
    // 0x500e24: StoreField: r2->field_17 = r0
    //     0x500e24: stur            w0, [x2, #0x17]
    //     0x500e28: ldurb           w16, [x2, #-1]
    //     0x500e2c: ldurb           w17, [x0, #-1]
    //     0x500e30: and             x16, x17, x16, lsr #2
    //     0x500e34: tst             x16, HEAP, lsr #32
    //     0x500e38: b.eq            #0x500e40
    //     0x500e3c: bl              #0xd6828c
    // 0x500e40: ldr             x0, [fp, #0x10]
    // 0x500e44: StoreField: r2->field_27 = r0
    //     0x500e44: stur            w0, [x2, #0x27]
    //     0x500e48: ldurb           w16, [x2, #-1]
    //     0x500e4c: ldurb           w17, [x0, #-1]
    //     0x500e50: and             x16, x17, x16, lsr #2
    //     0x500e54: tst             x16, HEAP, lsr #32
    //     0x500e58: b.eq            #0x500e60
    //     0x500e5c: bl              #0xd6828c
    // 0x500e60: r0 = Null
    //     0x500e60: mov             x0, NULL
    // 0x500e64: LeaveFrame
    //     0x500e64: mov             SP, fp
    //     0x500e68: ldp             fp, lr, [SP], #0x10
    // 0x500e6c: ret
    //     0x500e6c: ret             
  }
  _ valueToString(/* No info */) {
    // ** addr: 0xab7c14, size: 0x60
    // 0xab7c14: EnterFrame
    //     0xab7c14: stp             fp, lr, [SP, #-0x10]!
    //     0xab7c18: mov             fp, SP
    // 0xab7c1c: CheckStackOverflow
    //     0xab7c1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xab7c20: cmp             SP, x16
    //     0xab7c24: b.ls            #0xab7c6c
    // 0xab7c28: ldr             x16, [fp, #0x10]
    // 0xab7c2c: SaveReg r16
    //     0xab7c2c: str             x16, [SP, #-8]!
    // 0xab7c30: r0 = value()
    //     0xab7c30: bl              #0xb8066c  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::value
    // 0xab7c34: add             SP, SP, #8
    // 0xab7c38: r1 = LoadClassIdInstr(r0)
    //     0xab7c38: ldur            x1, [x0, #-1]
    //     0xab7c3c: ubfx            x1, x1, #0xc, #0x14
    // 0xab7c40: SaveReg r0
    //     0xab7c40: str             x0, [SP, #-8]!
    // 0xab7c44: mov             x0, x1
    // 0xab7c48: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xab7c48: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xab7c4c: r0 = GDT[cid_x0 + 0xcf23]()
    //     0xab7c4c: mov             x17, #0xcf23
    //     0xab7c50: add             lr, x0, x17
    //     0xab7c54: ldr             lr, [x21, lr, lsl #3]
    //     0xab7c58: blr             lr
    // 0xab7c5c: add             SP, SP, #8
    // 0xab7c60: LeaveFrame
    //     0xab7c60: mov             SP, fp
    //     0xab7c64: ldp             fp, lr, [SP], #0x10
    // 0xab7c68: ret
    //     0xab7c68: ret             
    // 0xab7c6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xab7c6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xab7c70: b               #0xab7c28
  }
  get _ value(/* No info */) {
    // ** addr: 0xb8066c, size: 0x44
    // 0xb8066c: EnterFrame
    //     0xb8066c: stp             fp, lr, [SP, #-0x10]!
    //     0xb80670: mov             fp, SP
    // 0xb80674: CheckStackOverflow
    //     0xb80674: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb80678: cmp             SP, x16
    //     0xb8067c: b.ls            #0xb806a4
    // 0xb80680: ldr             x16, [fp, #0x10]
    // 0xb80684: SaveReg r16
    //     0xb80684: str             x16, [SP, #-8]!
    // 0xb80688: r0 = value()
    //     0xb80688: bl              #0xb80794  ; [package:flutter/src/foundation/diagnostics.dart] DiagnosticsProperty::value
    // 0xb8068c: add             SP, SP, #8
    // 0xb80690: cmp             w0, NULL
    // 0xb80694: b.eq            #0xb806ac
    // 0xb80698: LeaveFrame
    //     0xb80698: mov             SP, fp
    //     0xb8069c: ldp             fp, lr, [SP], #0x10
    // 0xb806a0: ret
    //     0xb806a0: ret             
    // 0xb806a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb806a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb806a8: b               #0xb80680
    // 0xb806ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb806ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2634, size: 0x30, field offset: 0x30
class ErrorHint extends _ErrorDiagnostic {
}

// class id: 2635, size: 0x30, field offset: 0x30
class ErrorSummary extends _ErrorDiagnostic {
}

// class id: 2636, size: 0x30, field offset: 0x30
class ErrorDescription extends _ErrorDiagnostic {
}

// class id: 2655, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class StackFilter extends Object {
}

// class id: 2894, size: 0x24, field offset: 0x8
//   const constructor, 
class FlutterErrorDetails extends _DiagnosticableTree&Object&Diagnosticable {

  get _ summary(/* No info */) {
    // ** addr: 0x4fc48c, size: 0xa8
    // 0x4fc48c: EnterFrame
    //     0x4fc48c: stp             fp, lr, [SP, #-0x10]!
    //     0x4fc490: mov             fp, SP
    // 0x4fc494: CheckStackOverflow
    //     0x4fc494: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fc498: cmp             SP, x16
    //     0x4fc49c: b.ls            #0x4fc528
    // 0x4fc4a0: ldr             x16, [fp, #0x10]
    // 0x4fc4a4: SaveReg r16
    //     0x4fc4a4: str             x16, [SP, #-8]!
    // 0x4fc4a8: r0 = exceptionAsString()
    //     0x4fc4a8: bl              #0x4fc888  ; [package:flutter/src/foundation/assertions.dart] FlutterErrorDetails::exceptionAsString
    // 0x4fc4ac: add             SP, SP, #8
    // 0x4fc4b0: r1 = LoadClassIdInstr(r0)
    //     0x4fc4b0: ldur            x1, [x0, #-1]
    //     0x4fc4b4: ubfx            x1, x1, #0xc, #0x14
    // 0x4fc4b8: r16 = "\n"
    //     0x4fc4b8: ldr             x16, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x4fc4bc: stp             x16, x0, [SP, #-0x10]!
    // 0x4fc4c0: mov             x0, x1
    // 0x4fc4c4: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4fc4c4: sub             lr, x0, #0xff8
    //     0x4fc4c8: ldr             lr, [x21, lr, lsl #3]
    //     0x4fc4cc: blr             lr
    // 0x4fc4d0: add             SP, SP, #0x10
    // 0x4fc4d4: mov             x2, x0
    // 0x4fc4d8: LoadField: r0 = r2->field_b
    //     0x4fc4d8: ldur            w0, [x2, #0xb]
    // 0x4fc4dc: DecompressPointer r0
    //     0x4fc4dc: add             x0, x0, HEAP, lsl #32
    // 0x4fc4e0: r1 = LoadInt32Instr(r0)
    //     0x4fc4e0: sbfx            x1, x0, #1, #0x1f
    // 0x4fc4e4: mov             x0, x1
    // 0x4fc4e8: r1 = 0
    //     0x4fc4e8: mov             x1, #0
    // 0x4fc4ec: cmp             x1, x0
    // 0x4fc4f0: b.hs            #0x4fc530
    // 0x4fc4f4: LoadField: r0 = r2->field_f
    //     0x4fc4f4: ldur            w0, [x2, #0xf]
    // 0x4fc4f8: DecompressPointer r0
    //     0x4fc4f8: add             x0, x0, HEAP, lsl #32
    // 0x4fc4fc: LoadField: r1 = r0->field_f
    //     0x4fc4fc: ldur            w1, [x0, #0xf]
    // 0x4fc500: DecompressPointer r1
    //     0x4fc500: add             x1, x1, HEAP, lsl #32
    // 0x4fc504: SaveReg r1
    //     0x4fc504: str             x1, [SP, #-8]!
    // 0x4fc508: r0 = trimLeft()
    //     0x4fc508: bl              #0x4fc57c  ; [dart:core] _StringBase::trimLeft
    // 0x4fc50c: add             SP, SP, #8
    // 0x4fc510: SaveReg rNULL
    //     0x4fc510: str             NULL, [SP, #-8]!
    // 0x4fc514: r0 = DiagnosticsNode.message()
    //     0x4fc514: bl              #0x4fc534  ; [package:flutter/src/foundation/diagnostics.dart] DiagnosticsNode::DiagnosticsNode.message
    // 0x4fc518: add             SP, SP, #8
    // 0x4fc51c: LeaveFrame
    //     0x4fc51c: mov             SP, fp
    //     0x4fc520: ldp             fp, lr, [SP], #0x10
    // 0x4fc524: ret
    //     0x4fc524: ret             
    // 0x4fc528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fc528: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fc52c: b               #0x4fc4a0
    // 0x4fc530: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fc530: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ exceptionAsString(/* No info */) {
    // ** addr: 0x4fc888, size: 0x5a8
    // 0x4fc888: EnterFrame
    //     0x4fc888: stp             fp, lr, [SP, #-0x10]!
    //     0x4fc88c: mov             fp, SP
    // 0x4fc890: AllocStack(0x40)
    //     0x4fc890: sub             SP, SP, #0x40
    // 0x4fc894: CheckStackOverflow
    //     0x4fc894: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fc898: cmp             SP, x16
    //     0x4fc89c: b.ls            #0x4fce28
    // 0x4fc8a0: ldr             x0, [fp, #0x10]
    // 0x4fc8a4: LoadField: r3 = r0->field_7
    //     0x4fc8a4: ldur            w3, [x0, #7]
    // 0x4fc8a8: DecompressPointer r3
    //     0x4fc8a8: add             x3, x3, HEAP, lsl #32
    // 0x4fc8ac: mov             x0, x3
    // 0x4fc8b0: stur            x3, [fp, #-8]
    // 0x4fc8b4: r2 = Null
    //     0x4fc8b4: mov             x2, NULL
    // 0x4fc8b8: r1 = Null
    //     0x4fc8b8: mov             x1, NULL
    // 0x4fc8bc: cmp             w0, NULL
    // 0x4fc8c0: b.eq            #0x4fc8ec
    // 0x4fc8c4: branchIfSmi(r0, 0x4fc8ec)
    //     0x4fc8c4: tbz             w0, #0, #0x4fc8ec
    // 0x4fc8c8: r3 = LoadClassIdInstr(r0)
    //     0x4fc8c8: ldur            x3, [x0, #-1]
    //     0x4fc8cc: ubfx            x3, x3, #0xc, #0x14
    // 0x4fc8d0: r17 = 6158
    //     0x4fc8d0: mov             x17, #0x180e
    // 0x4fc8d4: cmp             x3, x17
    // 0x4fc8d8: b.eq            #0x4fc8f4
    // 0x4fc8dc: r17 = -6183
    //     0x4fc8dc: mov             x17, #-0x1827
    // 0x4fc8e0: add             x3, x3, x17
    // 0x4fc8e4: cmp             x3, #1
    // 0x4fc8e8: b.ls            #0x4fc8f4
    // 0x4fc8ec: r0 = false
    //     0x4fc8ec: add             x0, NULL, #0x30  ; false
    // 0x4fc8f0: b               #0x4fc8f8
    // 0x4fc8f4: r0 = true
    //     0x4fc8f4: add             x0, NULL, #0x20  ; true
    // 0x4fc8f8: tbnz            w0, #4, #0x4fcbe8
    // 0x4fc8fc: ldur            x1, [fp, #-8]
    // 0x4fc900: r0 = LoadClassIdInstr(r1)
    //     0x4fc900: ldur            x0, [x1, #-1]
    //     0x4fc904: ubfx            x0, x0, #0xc, #0x14
    // 0x4fc908: SaveReg r1
    //     0x4fc908: str             x1, [SP, #-8]!
    // 0x4fc90c: r0 = GDT[cid_x0 + -0xfd3]()
    //     0x4fc90c: sub             lr, x0, #0xfd3
    //     0x4fc910: ldr             lr, [x21, lr, lsl #3]
    //     0x4fc914: blr             lr
    // 0x4fc918: add             SP, SP, #8
    // 0x4fc91c: mov             x1, x0
    // 0x4fc920: ldur            x3, [fp, #-8]
    // 0x4fc924: stur            x1, [fp, #-0x10]
    // 0x4fc928: r0 = LoadClassIdInstr(r3)
    //     0x4fc928: ldur            x0, [x3, #-1]
    //     0x4fc92c: ubfx            x0, x0, #0xc, #0x14
    // 0x4fc930: SaveReg r3
    //     0x4fc930: str             x3, [SP, #-8]!
    // 0x4fc934: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fc934: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fc938: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x4fc938: mov             x17, #0x3f73
    //     0x4fc93c: add             lr, x0, x17
    //     0x4fc940: ldr             lr, [x21, lr, lsl #3]
    //     0x4fc944: blr             lr
    // 0x4fc948: add             SP, SP, #8
    // 0x4fc94c: mov             x2, x0
    // 0x4fc950: ldur            x1, [fp, #-0x10]
    // 0x4fc954: stur            x2, [fp, #-0x18]
    // 0x4fc958: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x4fc958: mov             x0, #0x76
    //     0x4fc95c: tbz             w1, #0, #0x4fc96c
    //     0x4fc960: ldur            x0, [x1, #-1]
    //     0x4fc964: ubfx            x0, x0, #0xc, #0x14
    //     0x4fc968: lsl             x0, x0, #1
    // 0x4fc96c: r3 = LoadInt32Instr(r0)
    //     0x4fc96c: sbfx            x3, x0, #1, #0x1f
    // 0x4fc970: cmp             x3, #0x5d
    // 0x4fc974: b.lt            #0x4fcbd4
    // 0x4fc978: cmp             x3, #0x60
    // 0x4fc97c: b.gt            #0x4fcbd4
    // 0x4fc980: r0 = LoadClassIdInstr(r1)
    //     0x4fc980: ldur            x0, [x1, #-1]
    //     0x4fc984: ubfx            x0, x0, #0xc, #0x14
    // 0x4fc988: stp             x2, x1, [SP, #-0x10]!
    // 0x4fc98c: mov             lr, x0
    // 0x4fc990: ldr             lr, [x21, lr, lsl #3]
    // 0x4fc994: blr             lr
    // 0x4fc998: add             SP, SP, #0x10
    // 0x4fc99c: tbz             w0, #4, #0x4fcbd4
    // 0x4fc9a0: ldur            x0, [fp, #-0x10]
    // 0x4fc9a4: ldur            x1, [fp, #-0x18]
    // 0x4fc9a8: LoadField: r2 = r1->field_7
    //     0x4fc9a8: ldur            w2, [x1, #7]
    // 0x4fc9ac: DecompressPointer r2
    //     0x4fc9ac: add             x2, x2, HEAP, lsl #32
    // 0x4fc9b0: LoadField: r3 = r0->field_7
    //     0x4fc9b0: ldur            w3, [x0, #7]
    // 0x4fc9b4: DecompressPointer r3
    //     0x4fc9b4: add             x3, x3, HEAP, lsl #32
    // 0x4fc9b8: r4 = LoadInt32Instr(r2)
    //     0x4fc9b8: sbfx            x4, x2, #1, #0x1f
    // 0x4fc9bc: stur            x4, [fp, #-0x28]
    // 0x4fc9c0: r2 = LoadInt32Instr(r3)
    //     0x4fc9c0: sbfx            x2, x3, #1, #0x1f
    // 0x4fc9c4: stur            x2, [fp, #-0x20]
    // 0x4fc9c8: cmp             x4, x2
    // 0x4fc9cc: b.le            #0x4fcbcc
    // 0x4fc9d0: stp             x0, x1, [SP, #-0x10]!
    // 0x4fc9d4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fc9d4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fc9d8: r0 = lastIndexOf()
    //     0x4fc9d8: bl              #0x4fd12c  ; [dart:core] _StringBase::lastIndexOf
    // 0x4fc9dc: add             SP, SP, #0x10
    // 0x4fc9e0: mov             x2, x0
    // 0x4fc9e4: ldur            x0, [fp, #-0x28]
    // 0x4fc9e8: ldur            x1, [fp, #-0x20]
    // 0x4fc9ec: sub             x3, x0, x1
    // 0x4fc9f0: cmp             x2, x3
    // 0x4fc9f4: b.ne            #0x4fcbc4
    // 0x4fc9f8: cmp             x2, #2
    // 0x4fc9fc: b.le            #0x4fcbc4
    // 0x4fca00: sub             x3, x2, #2
    // 0x4fca04: stur            x3, [fp, #-0x20]
    // 0x4fca08: r0 = BoxInt64Instr(r2)
    //     0x4fca08: sbfiz           x0, x2, #1, #0x1f
    //     0x4fca0c: cmp             x2, x0, asr #1
    //     0x4fca10: b.eq            #0x4fca1c
    //     0x4fca14: bl              #0xd69bb8
    //     0x4fca18: stur            x2, [x0, #7]
    // 0x4fca1c: ldur            x16, [fp, #-0x18]
    // 0x4fca20: stp             x3, x16, [SP, #-0x10]!
    // 0x4fca24: SaveReg r0
    //     0x4fca24: str             x0, [SP, #-8]!
    // 0x4fca28: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x4fca28: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x4fca2c: r0 = substring()
    //     0x4fca2c: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0x4fca30: add             SP, SP, #0x18
    // 0x4fca34: r1 = LoadClassIdInstr(r0)
    //     0x4fca34: ldur            x1, [x0, #-1]
    //     0x4fca38: ubfx            x1, x1, #0xc, #0x14
    // 0x4fca3c: r16 = ": "
    //     0x4fca3c: ldr             x16, [PP, #0xf48]  ; [pp+0xf48] ": "
    // 0x4fca40: stp             x16, x0, [SP, #-0x10]!
    // 0x4fca44: mov             x0, x1
    // 0x4fca48: mov             lr, x0
    // 0x4fca4c: ldr             lr, [x21, lr, lsl #3]
    // 0x4fca50: blr             lr
    // 0x4fca54: add             SP, SP, #0x10
    // 0x4fca58: tbnz            w0, #4, #0x4fcbc4
    // 0x4fca5c: ldur            x2, [fp, #-0x20]
    // 0x4fca60: r0 = BoxInt64Instr(r2)
    //     0x4fca60: sbfiz           x0, x2, #1, #0x1f
    //     0x4fca64: cmp             x2, x0, asr #1
    //     0x4fca68: b.eq            #0x4fca74
    //     0x4fca6c: bl              #0xd69bb8
    //     0x4fca70: stur            x2, [x0, #7]
    // 0x4fca74: ldur            x16, [fp, #-0x18]
    // 0x4fca78: stp             xzr, x16, [SP, #-0x10]!
    // 0x4fca7c: SaveReg r0
    //     0x4fca7c: str             x0, [SP, #-8]!
    // 0x4fca80: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x4fca80: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x4fca84: r0 = substring()
    //     0x4fca84: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0x4fca88: add             SP, SP, #0x18
    // 0x4fca8c: mov             x1, x0
    // 0x4fca90: stur            x1, [fp, #-0x30]
    // 0x4fca94: r0 = LoadClassIdInstr(r1)
    //     0x4fca94: ldur            x0, [x1, #-1]
    //     0x4fca98: ubfx            x0, x0, #0xc, #0x14
    // 0x4fca9c: r16 = " Failed assertion:"
    //     0x4fca9c: ldr             x16, [PP, #0xf50]  ; [pp+0xf50] " Failed assertion:"
    // 0x4fcaa0: stp             x16, x1, [SP, #-0x10]!
    // 0x4fcaa4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fcaa4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fcaa8: r0 = GDT[cid_x0 + -0xff0]()
    //     0x4fcaa8: sub             lr, x0, #0xff0
    //     0x4fcaac: ldr             lr, [x21, lr, lsl #3]
    //     0x4fcab0: blr             lr
    // 0x4fcab4: add             SP, SP, #0x10
    // 0x4fcab8: mov             x2, x0
    // 0x4fcabc: stur            x2, [fp, #-0x20]
    // 0x4fcac0: tbnz            x2, #0x3f, #0x4fcb70
    // 0x4fcac4: r0 = BoxInt64Instr(r2)
    //     0x4fcac4: sbfiz           x0, x2, #1, #0x1f
    //     0x4fcac8: cmp             x2, x0, asr #1
    //     0x4fcacc: b.eq            #0x4fcad8
    //     0x4fcad0: bl              #0xd69bb8
    //     0x4fcad4: stur            x2, [x0, #7]
    // 0x4fcad8: ldur            x16, [fp, #-0x30]
    // 0x4fcadc: stp             xzr, x16, [SP, #-0x10]!
    // 0x4fcae0: SaveReg r0
    //     0x4fcae0: str             x0, [SP, #-8]!
    // 0x4fcae4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x4fcae4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x4fcae8: r0 = substring()
    //     0x4fcae8: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0x4fcaec: add             SP, SP, #0x18
    // 0x4fcaf0: r1 = Null
    //     0x4fcaf0: mov             x1, NULL
    // 0x4fcaf4: r2 = 6
    //     0x4fcaf4: mov             x2, #6
    // 0x4fcaf8: stur            x0, [fp, #-0x38]
    // 0x4fcafc: r0 = AllocateArray()
    //     0x4fcafc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fcb00: mov             x1, x0
    // 0x4fcb04: ldur            x0, [fp, #-0x38]
    // 0x4fcb08: stur            x1, [fp, #-0x40]
    // 0x4fcb0c: StoreField: r1->field_f = r0
    //     0x4fcb0c: stur            w0, [x1, #0xf]
    // 0x4fcb10: r17 = "\n"
    //     0x4fcb10: ldr             x17, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x4fcb14: StoreField: r1->field_13 = r17
    //     0x4fcb14: stur            w17, [x1, #0x13]
    // 0x4fcb18: ldur            x0, [fp, #-0x20]
    // 0x4fcb1c: add             x2, x0, #1
    // 0x4fcb20: ldur            x16, [fp, #-0x30]
    // 0x4fcb24: stp             x2, x16, [SP, #-0x10]!
    // 0x4fcb28: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fcb28: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fcb2c: r0 = substring()
    //     0x4fcb2c: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0x4fcb30: add             SP, SP, #0x10
    // 0x4fcb34: ldur            x1, [fp, #-0x40]
    // 0x4fcb38: ArrayStore: r1[2] = r0  ; List_4
    //     0x4fcb38: add             x25, x1, #0x17
    //     0x4fcb3c: str             w0, [x25]
    //     0x4fcb40: tbz             w0, #0, #0x4fcb5c
    //     0x4fcb44: ldurb           w16, [x1, #-1]
    //     0x4fcb48: ldurb           w17, [x0, #-1]
    //     0x4fcb4c: and             x16, x17, x16, lsr #2
    //     0x4fcb50: tst             x16, HEAP, lsr #32
    //     0x4fcb54: b.eq            #0x4fcb5c
    //     0x4fcb58: bl              #0xd67e5c
    // 0x4fcb5c: ldur            x16, [fp, #-0x40]
    // 0x4fcb60: SaveReg r16
    //     0x4fcb60: str             x16, [SP, #-8]!
    // 0x4fcb64: r0 = _interpolate()
    //     0x4fcb64: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fcb68: add             SP, SP, #8
    // 0x4fcb6c: b               #0x4fcb74
    // 0x4fcb70: ldur            x0, [fp, #-0x30]
    // 0x4fcb74: stur            x0, [fp, #-0x30]
    // 0x4fcb78: ldur            x16, [fp, #-0x10]
    // 0x4fcb7c: SaveReg r16
    //     0x4fcb7c: str             x16, [SP, #-8]!
    // 0x4fcb80: r0 = trimRight()
    //     0x4fcb80: bl              #0x4fce30  ; [dart:core] _StringBase::trimRight
    // 0x4fcb84: add             SP, SP, #8
    // 0x4fcb88: r1 = Null
    //     0x4fcb88: mov             x1, NULL
    // 0x4fcb8c: r2 = 6
    //     0x4fcb8c: mov             x2, #6
    // 0x4fcb90: stur            x0, [fp, #-0x10]
    // 0x4fcb94: r0 = AllocateArray()
    //     0x4fcb94: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fcb98: mov             x1, x0
    // 0x4fcb9c: ldur            x0, [fp, #-0x10]
    // 0x4fcba0: StoreField: r1->field_f = r0
    //     0x4fcba0: stur            w0, [x1, #0xf]
    // 0x4fcba4: r17 = "\n"
    //     0x4fcba4: ldr             x17, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x4fcba8: StoreField: r1->field_13 = r17
    //     0x4fcba8: stur            w17, [x1, #0x13]
    // 0x4fcbac: ldur            x0, [fp, #-0x30]
    // 0x4fcbb0: StoreField: r1->field_17 = r0
    //     0x4fcbb0: stur            w0, [x1, #0x17]
    // 0x4fcbb4: SaveReg r1
    //     0x4fcbb4: str             x1, [SP, #-8]!
    // 0x4fcbb8: r0 = _interpolate()
    //     0x4fcbb8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fcbbc: add             SP, SP, #8
    // 0x4fcbc0: b               #0x4fcbd8
    // 0x4fcbc4: r0 = Null
    //     0x4fcbc4: mov             x0, NULL
    // 0x4fcbc8: b               #0x4fcbd8
    // 0x4fcbcc: r0 = Null
    //     0x4fcbcc: mov             x0, NULL
    // 0x4fcbd0: b               #0x4fcbd8
    // 0x4fcbd4: r0 = Null
    //     0x4fcbd4: mov             x0, NULL
    // 0x4fcbd8: cmp             w0, NULL
    // 0x4fcbdc: b.ne            #0x4fce00
    // 0x4fcbe0: ldur            x0, [fp, #-0x18]
    // 0x4fcbe4: b               #0x4fce00
    // 0x4fcbe8: ldur            x3, [fp, #-8]
    // 0x4fcbec: r0 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0x4fcbec: mov             x0, #0x76
    //     0x4fcbf0: tbz             w3, #0, #0x4fcc00
    //     0x4fcbf4: ldur            x0, [x3, #-1]
    //     0x4fcbf8: ubfx            x0, x0, #0xc, #0x14
    //     0x4fcbfc: lsl             x0, x0, #1
    // 0x4fcc00: r1 = LoadInt32Instr(r0)
    //     0x4fcc00: sbfx            x1, x0, #1, #0x1f
    // 0x4fcc04: cmp             x1, #0x5d
    // 0x4fcc08: b.lt            #0x4fcc50
    // 0x4fcc0c: cmp             x1, #0x60
    // 0x4fcc10: b.gt            #0x4fcc50
    // 0x4fcc14: mov             x0, x3
    // 0x4fcc18: r2 = Null
    //     0x4fcc18: mov             x2, NULL
    // 0x4fcc1c: r1 = Null
    //     0x4fcc1c: mov             x1, NULL
    // 0x4fcc20: r4 = 59
    //     0x4fcc20: mov             x4, #0x3b
    // 0x4fcc24: branchIfSmi(r0, 0x4fcc30)
    //     0x4fcc24: tbz             w0, #0, #0x4fcc30
    // 0x4fcc28: r4 = LoadClassIdInstr(r0)
    //     0x4fcc28: ldur            x4, [x0, #-1]
    //     0x4fcc2c: ubfx            x4, x4, #0xc, #0x14
    // 0x4fcc30: sub             x4, x4, #0x5d
    // 0x4fcc34: cmp             x4, #3
    // 0x4fcc38: b.ls            #0x4fcc48
    // 0x4fcc3c: r8 = String
    //     0x4fcc3c: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x4fcc40: r3 = Null
    //     0x4fcc40: ldr             x3, [PP, #0xf58]  ; [pp+0xf58] Null
    // 0x4fcc44: r0 = String()
    //     0x4fcc44: bl              #0xd72afc  ; IsType_String_Stub
    // 0x4fcc48: ldur            x0, [fp, #-8]
    // 0x4fcc4c: b               #0x4fce00
    // 0x4fcc50: ldur            x0, [fp, #-8]
    // 0x4fcc54: r2 = Null
    //     0x4fcc54: mov             x2, NULL
    // 0x4fcc58: r1 = Null
    //     0x4fcc58: mov             x1, NULL
    // 0x4fcc5c: cmp             w0, NULL
    // 0x4fcc60: b.eq            #0x4fccec
    // 0x4fcc64: branchIfSmi(r0, 0x4fccec)
    //     0x4fcc64: tbz             w0, #0, #0x4fccec
    // 0x4fcc68: r3 = LoadClassIdInstr(r0)
    //     0x4fcc68: ldur            x3, [x0, #-1]
    //     0x4fcc6c: ubfx            x3, x3, #0xc, #0x14
    // 0x4fcc70: r17 = 6153
    //     0x4fcc70: mov             x17, #0x1809
    // 0x4fcc74: cmp             x3, x17
    // 0x4fcc78: b.eq            #0x4fccf4
    // 0x4fcc7c: r4 = LoadClassIdInstr(r0)
    //     0x4fcc7c: ldur            x4, [x0, #-1]
    //     0x4fcc80: ubfx            x4, x4, #0xc, #0x14
    // 0x4fcc84: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x4fcc88: ldr             x3, [x3, #0x18]
    // 0x4fcc8c: ldr             x3, [x3, x4, lsl #3]
    // 0x4fcc90: LoadField: r3 = r3->field_2b
    //     0x4fcc90: ldur            w3, [x3, #0x2b]
    // 0x4fcc94: DecompressPointer r3
    //     0x4fcc94: add             x3, x3, HEAP, lsl #32
    // 0x4fcc98: cmp             w3, NULL
    // 0x4fcc9c: b.eq            #0x4fccec
    // 0x4fcca0: LoadField: r3 = r3->field_f
    //     0x4fcca0: ldur            w3, [x3, #0xf]
    // 0x4fcca4: lsr             x3, x3, #4
    // 0x4fcca8: r17 = 6153
    //     0x4fcca8: mov             x17, #0x1809
    // 0x4fccac: cmp             x3, x17
    // 0x4fccb0: b.eq            #0x4fccf4
    // 0x4fccb4: r3 = SubtypeTestCache
    //     0x4fccb4: ldr             x3, [PP, #0xf68]  ; [pp+0xf68] SubtypeTestCache
    // 0x4fccb8: r24 = Subtype1TestCacheStub
    //     0x4fccb8: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x4fccbc: LoadField: r30 = r24->field_7
    //     0x4fccbc: ldur            lr, [x24, #7]
    // 0x4fccc0: blr             lr
    // 0x4fccc4: cmp             w7, NULL
    // 0x4fccc8: b.eq            #0x4fccd4
    // 0x4fcccc: tbnz            w7, #4, #0x4fccec
    // 0x4fccd0: b               #0x4fccf4
    // 0x4fccd4: r8 = Error
    //     0x4fccd4: ldr             x8, [PP, #0xf70]  ; [pp+0xf70] Type: Error
    // 0x4fccd8: r3 = SubtypeTestCache
    //     0x4fccd8: ldr             x3, [PP, #0xf78]  ; [pp+0xf78] SubtypeTestCache
    // 0x4fccdc: r24 = InstanceOfStub
    //     0x4fccdc: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x4fcce0: LoadField: r30 = r24->field_7
    //     0x4fcce0: ldur            lr, [x24, #7]
    // 0x4fcce4: blr             lr
    // 0x4fcce8: b               #0x4fccf8
    // 0x4fccec: r0 = false
    //     0x4fccec: add             x0, NULL, #0x30  ; false
    // 0x4fccf0: b               #0x4fccf8
    // 0x4fccf4: r0 = true
    //     0x4fccf4: add             x0, NULL, #0x20  ; true
    // 0x4fccf8: tbz             w0, #4, #0x4fcd9c
    // 0x4fccfc: ldur            x0, [fp, #-8]
    // 0x4fcd00: r2 = Null
    //     0x4fcd00: mov             x2, NULL
    // 0x4fcd04: r1 = Null
    //     0x4fcd04: mov             x1, NULL
    // 0x4fcd08: cmp             w0, NULL
    // 0x4fcd0c: b.eq            #0x4fcd8c
    // 0x4fcd10: branchIfSmi(r0, 0x4fcd8c)
    //     0x4fcd10: tbz             w0, #0, #0x4fcd8c
    // 0x4fcd14: r3 = LoadClassIdInstr(r0)
    //     0x4fcd14: ldur            x3, [x0, #-1]
    //     0x4fcd18: ubfx            x3, x3, #0xc, #0x14
    // 0x4fcd1c: r4 = LoadClassIdInstr(r0)
    //     0x4fcd1c: ldur            x4, [x0, #-1]
    //     0x4fcd20: ubfx            x4, x4, #0xc, #0x14
    // 0x4fcd24: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x4fcd28: ldr             x3, [x3, #0x18]
    // 0x4fcd2c: ldr             x3, [x3, x4, lsl #3]
    // 0x4fcd30: LoadField: r3 = r3->field_2b
    //     0x4fcd30: ldur            w3, [x3, #0x2b]
    // 0x4fcd34: DecompressPointer r3
    //     0x4fcd34: add             x3, x3, HEAP, lsl #32
    // 0x4fcd38: cmp             w3, NULL
    // 0x4fcd3c: b.eq            #0x4fcd8c
    // 0x4fcd40: LoadField: r3 = r3->field_f
    //     0x4fcd40: ldur            w3, [x3, #0xf]
    // 0x4fcd44: lsr             x3, x3, #4
    // 0x4fcd48: r17 = 5704
    //     0x4fcd48: mov             x17, #0x1648
    // 0x4fcd4c: cmp             x3, x17
    // 0x4fcd50: b.eq            #0x4fcd94
    // 0x4fcd54: r3 = SubtypeTestCache
    //     0x4fcd54: ldr             x3, [PP, #0xf80]  ; [pp+0xf80] SubtypeTestCache
    // 0x4fcd58: r24 = Subtype1TestCacheStub
    //     0x4fcd58: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x4fcd5c: LoadField: r30 = r24->field_7
    //     0x4fcd5c: ldur            lr, [x24, #7]
    // 0x4fcd60: blr             lr
    // 0x4fcd64: cmp             w7, NULL
    // 0x4fcd68: b.eq            #0x4fcd74
    // 0x4fcd6c: tbnz            w7, #4, #0x4fcd8c
    // 0x4fcd70: b               #0x4fcd94
    // 0x4fcd74: r8 = Exception
    //     0x4fcd74: ldr             x8, [PP, #0xf88]  ; [pp+0xf88] Type: Exception
    // 0x4fcd78: r3 = SubtypeTestCache
    //     0x4fcd78: ldr             x3, [PP, #0xf90]  ; [pp+0xf90] SubtypeTestCache
    // 0x4fcd7c: r24 = InstanceOfStub
    //     0x4fcd7c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x4fcd80: LoadField: r30 = r24->field_7
    //     0x4fcd80: ldur            lr, [x24, #7]
    // 0x4fcd84: blr             lr
    // 0x4fcd88: b               #0x4fcd98
    // 0x4fcd8c: r0 = false
    //     0x4fcd8c: add             x0, NULL, #0x30  ; false
    // 0x4fcd90: b               #0x4fcd98
    // 0x4fcd94: r0 = true
    //     0x4fcd94: add             x0, NULL, #0x20  ; true
    // 0x4fcd98: tbnz            w0, #4, #0x4fcdd4
    // 0x4fcd9c: ldur            x0, [fp, #-8]
    // 0x4fcda0: r1 = 59
    //     0x4fcda0: mov             x1, #0x3b
    // 0x4fcda4: branchIfSmi(r0, 0x4fcdb0)
    //     0x4fcda4: tbz             w0, #0, #0x4fcdb0
    // 0x4fcda8: r1 = LoadClassIdInstr(r0)
    //     0x4fcda8: ldur            x1, [x0, #-1]
    //     0x4fcdac: ubfx            x1, x1, #0xc, #0x14
    // 0x4fcdb0: SaveReg r0
    //     0x4fcdb0: str             x0, [SP, #-8]!
    // 0x4fcdb4: mov             x0, x1
    // 0x4fcdb8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fcdb8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fcdbc: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x4fcdbc: mov             x17, #0x3f73
    //     0x4fcdc0: add             lr, x0, x17
    //     0x4fcdc4: ldr             lr, [x21, lr, lsl #3]
    //     0x4fcdc8: blr             lr
    // 0x4fcdcc: add             SP, SP, #8
    // 0x4fcdd0: b               #0x4fce00
    // 0x4fcdd4: ldur            x0, [fp, #-8]
    // 0x4fcdd8: r1 = Null
    //     0x4fcdd8: mov             x1, NULL
    // 0x4fcddc: r2 = 4
    //     0x4fcddc: mov             x2, #4
    // 0x4fcde0: r0 = AllocateArray()
    //     0x4fcde0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fcde4: r17 = "  "
    //     0x4fcde4: ldr             x17, [PP, #0xf98]  ; [pp+0xf98] "  "
    // 0x4fcde8: StoreField: r0->field_f = r17
    //     0x4fcde8: stur            w17, [x0, #0xf]
    // 0x4fcdec: ldur            x1, [fp, #-8]
    // 0x4fcdf0: StoreField: r0->field_13 = r1
    //     0x4fcdf0: stur            w1, [x0, #0x13]
    // 0x4fcdf4: SaveReg r0
    //     0x4fcdf4: str             x0, [SP, #-8]!
    // 0x4fcdf8: r0 = _interpolate()
    //     0x4fcdf8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fcdfc: add             SP, SP, #8
    // 0x4fce00: SaveReg r0
    //     0x4fce00: str             x0, [SP, #-8]!
    // 0x4fce04: r0 = trimRight()
    //     0x4fce04: bl              #0x4fce30  ; [dart:core] _StringBase::trimRight
    // 0x4fce08: add             SP, SP, #8
    // 0x4fce0c: LoadField: r1 = r0->field_7
    //     0x4fce0c: ldur            w1, [x0, #7]
    // 0x4fce10: DecompressPointer r1
    //     0x4fce10: add             x1, x1, HEAP, lsl #32
    // 0x4fce14: cbnz            w1, #0x4fce1c
    // 0x4fce18: r0 = "  <no message available>"
    //     0x4fce18: ldr             x0, [PP, #0xfa0]  ; [pp+0xfa0] "  <no message available>"
    // 0x4fce1c: LeaveFrame
    //     0x4fce1c: mov             SP, fp
    //     0x4fce20: ldp             fp, lr, [SP], #0x10
    // 0x4fce24: ret
    //     0x4fce24: ret             
    // 0x4fce28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fce28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fce2c: b               #0x4fc8a0
  }
  _ toStringShort(/* No info */) {
    // ** addr: 0xa77db4, size: 0x5c
    // 0xa77db4: EnterFrame
    //     0xa77db4: stp             fp, lr, [SP, #-0x10]!
    //     0xa77db8: mov             fp, SP
    // 0xa77dbc: CheckStackOverflow
    //     0xa77dbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa77dc0: cmp             SP, x16
    //     0xa77dc4: b.ls            #0xa77e08
    // 0xa77dc8: r1 = Null
    //     0xa77dc8: mov             x1, NULL
    // 0xa77dcc: r2 = 4
    //     0xa77dcc: mov             x2, #4
    // 0xa77dd0: r0 = AllocateArray()
    //     0xa77dd0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa77dd4: r17 = "Exception caught by "
    //     0xa77dd4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb138] "Exception caught by "
    //     0xa77dd8: ldr             x17, [x17, #0x138]
    // 0xa77ddc: StoreField: r0->field_f = r17
    //     0xa77ddc: stur            w17, [x0, #0xf]
    // 0xa77de0: ldr             x1, [fp, #0x10]
    // 0xa77de4: LoadField: r2 = r1->field_f
    //     0xa77de4: ldur            w2, [x1, #0xf]
    // 0xa77de8: DecompressPointer r2
    //     0xa77de8: add             x2, x2, HEAP, lsl #32
    // 0xa77dec: StoreField: r0->field_13 = r2
    //     0xa77dec: stur            w2, [x0, #0x13]
    // 0xa77df0: SaveReg r0
    //     0xa77df0: str             x0, [SP, #-8]!
    // 0xa77df4: r0 = _interpolate()
    //     0xa77df4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa77df8: add             SP, SP, #8
    // 0xa77dfc: LeaveFrame
    //     0xa77dfc: mov             SP, fp
    //     0xa77e00: ldp             fp, lr, [SP], #0x10
    // 0xa77e04: ret
    //     0xa77e04: ret             
    // 0xa77e08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa77e08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa77e0c: b               #0xa77dc8
  }
  _ toString(/* No info */) {
    // ** addr: 0xad7778, size: 0x50
    // 0xad7778: EnterFrame
    //     0xad7778: stp             fp, lr, [SP, #-0x10]!
    //     0xad777c: mov             fp, SP
    // 0xad7780: mov             x0, x4
    // 0xad7784: LoadField: r1 = r0->field_13
    //     0xad7784: ldur            w1, [x0, #0x13]
    // 0xad7788: DecompressPointer r1
    //     0xad7788: add             x1, x1, HEAP, lsl #32
    // 0xad778c: sub             x0, x1, #2
    // 0xad7790: add             x1, fp, w0, sxtw #2
    // 0xad7794: ldr             x1, [x1, #0x10]
    // 0xad7798: CheckStackOverflow
    //     0xad7798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad779c: cmp             SP, x16
    //     0xad77a0: b.ls            #0xad77c0
    // 0xad77a4: SaveReg r1
    //     0xad77a4: str             x1, [SP, #-8]!
    // 0xad77a8: r0 = toDiagnosticsNode()
    //     0xad77a8: bl              #0xad77c8  ; [package:flutter/src/foundation/assertions.dart] FlutterErrorDetails::toDiagnosticsNode
    // 0xad77ac: add             SP, SP, #8
    // 0xad77b0: r0 = ""
    //     0xad77b0: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xad77b4: LeaveFrame
    //     0xad77b4: mov             SP, fp
    //     0xad77b8: ldp             fp, lr, [SP], #0x10
    // 0xad77bc: ret
    //     0xad77bc: ret             
    // 0xad77c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad77c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad77c4: b               #0xad77a4
  }
  _ toDiagnosticsNode(/* No info */) {
    // ** addr: 0xad77c8, size: 0x1c
    // 0xad77c8: EnterFrame
    //     0xad77c8: stp             fp, lr, [SP, #-0x10]!
    //     0xad77cc: mov             fp, SP
    // 0xad77d0: r1 = <FlutterErrorDetails>
    //     0xad77d0: ldr             x1, [PP, #0x7510]  ; [pp+0x7510] TypeArguments: <FlutterErrorDetails>
    // 0xad77d4: r0 = _FlutterErrorDetailsNode()
    //     0xad77d4: bl              #0xad77e4  ; Allocate_FlutterErrorDetailsNodeStub -> _FlutterErrorDetailsNode (size=0xc)
    // 0xad77d8: LeaveFrame
    //     0xad77d8: mov             SP, fp
    //     0xad77dc: ldp             fp, lr, [SP], #0x10
    // 0xad77e0: ret
    //     0xad77e0: ret             
  }
}

// class id: 6157, size: 0xc, field offset: 0xc
//   transformed mixin,
abstract class _FlutterError&Error&DiagnosticableTreeMixin extends Error
     with DiagnosticableTreeMixin {
}

// class id: 6158, size: 0x10, field offset: 0xc
class FlutterError extends _FlutterError&Error&DiagnosticableTreeMixin
    implements AssertionError {

  static late ((dynamic, FlutterErrorDetails) => void)? onError; // offset: 0xcf4
  static late (dynamic, FlutterErrorDetails) => void presentError; // offset: 0xcfc
  static late (dynamic, StackTrace) => StackTrace demangleStackTrace; // offset: 0xcf8
  static late final List<StackFilter> _stackFilters; // offset: 0xd04

  static _ reportError(/* No info */) {
    // ** addr: 0x4fc16c, size: 0x68
    // 0x4fc16c: EnterFrame
    //     0x4fc16c: stp             fp, lr, [SP, #-0x10]!
    //     0x4fc170: mov             fp, SP
    // 0x4fc174: CheckStackOverflow
    //     0x4fc174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fc178: cmp             SP, x16
    //     0x4fc17c: b.ls            #0x4fc1cc
    // 0x4fc180: r0 = InitLateStaticField(0xcf4) // [package:flutter/src/foundation/assertions.dart] FlutterError::onError
    //     0x4fc180: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4fc184: ldr             x0, [x0, #0x19e8]
    //     0x4fc188: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4fc18c: cmp             w0, w16
    //     0x4fc190: b.ne            #0x4fc19c
    //     0x4fc194: ldr             x2, [PP, #0xf00]  ; [pp+0xf00] Field <FlutterError.onError>: static late (offset: 0xcf4)
    //     0x4fc198: bl              #0xd67d44
    // 0x4fc19c: cmp             w0, NULL
    // 0x4fc1a0: b.eq            #0x4fc1bc
    // 0x4fc1a4: ldr             x16, [fp, #0x10]
    // 0x4fc1a8: stp             x16, x0, [SP, #-0x10]!
    // 0x4fc1ac: ClosureCall
    //     0x4fc1ac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4fc1b0: ldur            x2, [x0, #0x1f]
    //     0x4fc1b4: blr             x2
    // 0x4fc1b8: add             SP, SP, #0x10
    // 0x4fc1bc: r0 = Null
    //     0x4fc1bc: mov             x0, NULL
    // 0x4fc1c0: LeaveFrame
    //     0x4fc1c0: mov             SP, fp
    //     0x4fc1c4: ldp             fp, lr, [SP], #0x10
    // 0x4fc1c8: ret
    //     0x4fc1c8: ret             
    // 0x4fc1cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fc1cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fc1d0: b               #0x4fc180
  }
  static ((dynamic, FlutterErrorDetails) => void)? onError() {
    // ** addr: 0x4fc1d4, size: 0x44
    // 0x4fc1d4: EnterFrame
    //     0x4fc1d4: stp             fp, lr, [SP, #-0x10]!
    //     0x4fc1d8: mov             fp, SP
    // 0x4fc1dc: CheckStackOverflow
    //     0x4fc1dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fc1e0: cmp             SP, x16
    //     0x4fc1e4: b.ls            #0x4fc210
    // 0x4fc1e8: r0 = InitLateStaticField(0xcfc) // [package:flutter/src/foundation/assertions.dart] FlutterError::presentError
    //     0x4fc1e8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4fc1ec: ldr             x0, [x0, #0x19f8]
    //     0x4fc1f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4fc1f4: cmp             w0, w16
    //     0x4fc1f8: b.ne            #0x4fc204
    //     0x4fc1fc: ldr             x2, [PP, #0xf08]  ; [pp+0xf08] Field <FlutterError.presentError>: static late (offset: 0xcfc)
    //     0x4fc200: bl              #0xd67d44
    // 0x4fc204: LeaveFrame
    //     0x4fc204: mov             SP, fp
    //     0x4fc208: ldp             fp, lr, [SP], #0x10
    // 0x4fc20c: ret
    //     0x4fc20c: ret             
    // 0x4fc210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fc210: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fc214: b               #0x4fc1e8
  }
  static (dynamic, FlutterErrorDetails) => void presentError() {
    // ** addr: 0x4fc218, size: 0x8
    // 0x4fc218: r0 = Closure: (FlutterErrorDetails, {bool forceReport}) => void from Function 'dumpErrorToConsole': static.
    //     0x4fc218: ldr             x0, [PP, #0xf10]  ; [pp+0xf10] Closure: (FlutterErrorDetails, {bool forceReport}) => void from Function 'dumpErrorToConsole': static. (0x7fe6e1cfc220)
    // 0x4fc21c: ret
    //     0x4fc21c: ret             
  }
  [closure] static void dumpErrorToConsole(dynamic, FlutterErrorDetails, {bool forceReport}) {
    // ** addr: 0x4fc220, size: 0x84
    // 0x4fc220: EnterFrame
    //     0x4fc220: stp             fp, lr, [SP, #-0x10]!
    //     0x4fc224: mov             fp, SP
    // 0x4fc228: mov             x0, x4
    // 0x4fc22c: LoadField: r1 = r0->field_13
    //     0x4fc22c: ldur            w1, [x0, #0x13]
    // 0x4fc230: DecompressPointer r1
    //     0x4fc230: add             x1, x1, HEAP, lsl #32
    // 0x4fc234: sub             x2, x1, #4
    // 0x4fc238: add             x3, fp, w2, sxtw #2
    // 0x4fc23c: ldr             x3, [x3, #0x10]
    // 0x4fc240: LoadField: r2 = r0->field_1f
    //     0x4fc240: ldur            w2, [x0, #0x1f]
    // 0x4fc244: DecompressPointer r2
    //     0x4fc244: add             x2, x2, HEAP, lsl #32
    // 0x4fc248: r16 = "forceReport"
    //     0x4fc248: ldr             x16, [PP, #0xf18]  ; [pp+0xf18] "forceReport"
    // 0x4fc24c: cmp             w2, w16
    // 0x4fc250: b.ne            #0x4fc270
    // 0x4fc254: LoadField: r2 = r0->field_23
    //     0x4fc254: ldur            w2, [x0, #0x23]
    // 0x4fc258: DecompressPointer r2
    //     0x4fc258: add             x2, x2, HEAP, lsl #32
    // 0x4fc25c: sub             w0, w1, w2
    // 0x4fc260: add             x1, fp, w0, sxtw #2
    // 0x4fc264: ldr             x1, [x1, #8]
    // 0x4fc268: mov             x0, x1
    // 0x4fc26c: b               #0x4fc274
    // 0x4fc270: r0 = false
    //     0x4fc270: add             x0, NULL, #0x30  ; false
    // 0x4fc274: CheckStackOverflow
    //     0x4fc274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fc278: cmp             SP, x16
    //     0x4fc27c: b.ls            #0x4fc29c
    // 0x4fc280: stp             x0, x3, [SP, #-0x10]!
    // 0x4fc284: r4 = const [0, 0x2, 0x2, 0x1, forceReport, 0x1, null]
    //     0x4fc284: ldr             x4, [PP, #0xf20]  ; [pp+0xf20] List(7) [0, 0x2, 0x2, 0x1, "forceReport", 0x1, Null]
    // 0x4fc288: r0 = dumpErrorToConsole()
    //     0x4fc288: bl              #0x4fc2a4  ; [package:flutter/src/foundation/assertions.dart] FlutterError::dumpErrorToConsole
    // 0x4fc28c: add             SP, SP, #0x10
    // 0x4fc290: LeaveFrame
    //     0x4fc290: mov             SP, fp
    //     0x4fc294: ldp             fp, lr, [SP], #0x10
    // 0x4fc298: ret
    //     0x4fc298: ret             
    // 0x4fc29c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fc29c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fc2a0: b               #0x4fc280
  }
  static _ dumpErrorToConsole(/* No info */) {
    // ** addr: 0x4fc2a4, size: 0x1e8
    // 0x4fc2a4: EnterFrame
    //     0x4fc2a4: stp             fp, lr, [SP, #-0x10]!
    //     0x4fc2a8: mov             fp, SP
    // 0x4fc2ac: AllocStack(0x18)
    //     0x4fc2ac: sub             SP, SP, #0x18
    // 0x4fc2b0: SetupParameters(dynamic _ /* r3, fp-0x10 */, {dynamic forceReport = false /* r0 */})
    //     0x4fc2b0: mov             x0, x4
    //     0x4fc2b4: ldur            w1, [x0, #0x13]
    //     0x4fc2b8: add             x1, x1, HEAP, lsl #32
    //     0x4fc2bc: sub             x2, x1, #2
    //     0x4fc2c0: add             x3, fp, w2, sxtw #2
    //     0x4fc2c4: ldr             x3, [x3, #0x10]
    //     0x4fc2c8: stur            x3, [fp, #-0x10]
    //     0x4fc2cc: ldur            w2, [x0, #0x1f]
    //     0x4fc2d0: add             x2, x2, HEAP, lsl #32
    //     0x4fc2d4: ldr             x16, [PP, #0xf18]  ; [pp+0xf18] "forceReport"
    //     0x4fc2d8: cmp             w2, w16
    //     0x4fc2dc: b.ne            #0x4fc2fc
    //     0x4fc2e0: ldur            w2, [x0, #0x23]
    //     0x4fc2e4: add             x2, x2, HEAP, lsl #32
    //     0x4fc2e8: sub             w0, w1, w2
    //     0x4fc2ec: add             x1, fp, w0, sxtw #2
    //     0x4fc2f0: ldr             x1, [x1, #8]
    //     0x4fc2f4: mov             x0, x1
    //     0x4fc2f8: b               #0x4fc300
    //     0x4fc2fc: add             x0, NULL, #0x30  ; false
    // 0x4fc300: CheckStackOverflow
    //     0x4fc300: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fc304: cmp             SP, x16
    //     0x4fc308: b.ls            #0x4fc484
    // 0x4fc30c: LoadField: r1 = r3->field_1f
    //     0x4fc30c: ldur            w1, [x3, #0x1f]
    // 0x4fc310: DecompressPointer r1
    //     0x4fc310: add             x1, x1, HEAP, lsl #32
    // 0x4fc314: eor             x2, x1, #0x10
    // 0x4fc318: tbz             w2, #4, #0x4fc330
    // 0x4fc31c: tbz             w0, #4, #0x4fc330
    // 0x4fc320: r0 = Null
    //     0x4fc320: mov             x0, NULL
    // 0x4fc324: LeaveFrame
    //     0x4fc324: mov             SP, fp
    //     0x4fc328: ldp             fp, lr, [SP], #0x10
    // 0x4fc32c: ret
    //     0x4fc32c: ret             
    // 0x4fc330: r1 = LoadStaticField(0xd00)
    //     0x4fc330: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x4fc334: ldr             x1, [x1, #0x1a00]
    // 0x4fc338: r2 = LoadInt32Instr(r1)
    //     0x4fc338: sbfx            x2, x1, #1, #0x1f
    //     0x4fc33c: tbz             w1, #0, #0x4fc344
    //     0x4fc340: ldur            x2, [x1, #7]
    // 0x4fc344: cbz             x2, #0x4fc34c
    // 0x4fc348: tbnz            w0, #4, #0x4fc3a4
    // 0x4fc34c: LoadField: r1 = r3->field_b
    //     0x4fc34c: ldur            w1, [x3, #0xb]
    // 0x4fc350: DecompressPointer r1
    //     0x4fc350: add             x1, x1, HEAP, lsl #32
    // 0x4fc354: stur            x1, [fp, #-8]
    // 0x4fc358: LoadField: r0 = r3->field_7
    //     0x4fc358: ldur            w0, [x3, #7]
    // 0x4fc35c: DecompressPointer r0
    //     0x4fc35c: add             x0, x0, HEAP, lsl #32
    // 0x4fc360: r2 = 59
    //     0x4fc360: mov             x2, #0x3b
    // 0x4fc364: branchIfSmi(r0, 0x4fc370)
    //     0x4fc364: tbz             w0, #0, #0x4fc370
    // 0x4fc368: r2 = LoadClassIdInstr(r0)
    //     0x4fc368: ldur            x2, [x0, #-1]
    //     0x4fc36c: ubfx            x2, x2, #0xc, #0x14
    // 0x4fc370: SaveReg r0
    //     0x4fc370: str             x0, [SP, #-8]!
    // 0x4fc374: mov             x0, x2
    // 0x4fc378: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fc378: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fc37c: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x4fc37c: mov             x17, #0x3f73
    //     0x4fc380: add             lr, x0, x17
    //     0x4fc384: ldr             lr, [x21, lr, lsl #3]
    //     0x4fc388: blr             lr
    // 0x4fc38c: add             SP, SP, #8
    // 0x4fc390: ldur            x16, [fp, #-8]
    // 0x4fc394: stp             x16, x0, [SP, #-0x10]!
    // 0x4fc398: r0 = debugPrintStack()
    //     0x4fc398: bl              #0x4fd370  ; [package:flutter/src/foundation/assertions.dart] ::debugPrintStack
    // 0x4fc39c: add             SP, SP, #0x10
    // 0x4fc3a0: b               #0x4fc440
    // 0x4fc3a4: r0 = InitLateStaticField(0xd2c) // [package:flutter/src/foundation/print.dart] ::debugPrint
    //     0x4fc3a4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4fc3a8: ldr             x0, [x0, #0x1a58]
    //     0x4fc3ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4fc3b0: cmp             w0, w16
    //     0x4fc3b4: b.ne            #0x4fc3c0
    //     0x4fc3b8: ldr             x2, [PP, #0xf28]  ; [pp+0xf28] Field <::.debugPrint>: static late (offset: 0xd2c)
    //     0x4fc3bc: bl              #0xd67d44
    // 0x4fc3c0: r1 = Null
    //     0x4fc3c0: mov             x1, NULL
    // 0x4fc3c4: r2 = 4
    //     0x4fc3c4: mov             x2, #4
    // 0x4fc3c8: stur            x0, [fp, #-8]
    // 0x4fc3cc: r0 = AllocateArray()
    //     0x4fc3cc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fc3d0: stur            x0, [fp, #-0x18]
    // 0x4fc3d4: r17 = "Another exception was thrown: "
    //     0x4fc3d4: ldr             x17, [PP, #0xf30]  ; [pp+0xf30] "Another exception was thrown: "
    // 0x4fc3d8: StoreField: r0->field_f = r17
    //     0x4fc3d8: stur            w17, [x0, #0xf]
    // 0x4fc3dc: ldur            x16, [fp, #-0x10]
    // 0x4fc3e0: SaveReg r16
    //     0x4fc3e0: str             x16, [SP, #-8]!
    // 0x4fc3e4: r0 = summary()
    //     0x4fc3e4: bl              #0x4fc48c  ; [package:flutter/src/foundation/assertions.dart] FlutterErrorDetails::summary
    // 0x4fc3e8: add             SP, SP, #8
    // 0x4fc3ec: ldur            x1, [fp, #-0x18]
    // 0x4fc3f0: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fc3f0: add             x25, x1, #0x13
    //     0x4fc3f4: str             w0, [x25]
    //     0x4fc3f8: tbz             w0, #0, #0x4fc414
    //     0x4fc3fc: ldurb           w16, [x1, #-1]
    //     0x4fc400: ldurb           w17, [x0, #-1]
    //     0x4fc404: and             x16, x17, x16, lsr #2
    //     0x4fc408: tst             x16, HEAP, lsr #32
    //     0x4fc40c: b.eq            #0x4fc414
    //     0x4fc410: bl              #0xd67e5c
    // 0x4fc414: ldur            x16, [fp, #-0x18]
    // 0x4fc418: SaveReg r16
    //     0x4fc418: str             x16, [SP, #-8]!
    // 0x4fc41c: r0 = _interpolate()
    //     0x4fc41c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fc420: add             SP, SP, #8
    // 0x4fc424: ldur            x16, [fp, #-8]
    // 0x4fc428: stp             x0, x16, [SP, #-0x10]!
    // 0x4fc42c: ldur            x0, [fp, #-8]
    // 0x4fc430: ClosureCall
    //     0x4fc430: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4fc434: ldur            x2, [x0, #0x1f]
    //     0x4fc438: blr             x2
    // 0x4fc43c: add             SP, SP, #0x10
    // 0x4fc440: r2 = LoadStaticField(0xd00)
    //     0x4fc440: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0x4fc444: ldr             x2, [x2, #0x1a00]
    // 0x4fc448: r3 = LoadInt32Instr(r2)
    //     0x4fc448: sbfx            x3, x2, #1, #0x1f
    //     0x4fc44c: tbz             w2, #0, #0x4fc454
    //     0x4fc450: ldur            x3, [x2, #7]
    // 0x4fc454: add             x2, x3, #1
    // 0x4fc458: r0 = BoxInt64Instr(r2)
    //     0x4fc458: sbfiz           x0, x2, #1, #0x1f
    //     0x4fc45c: cmp             x2, x0, asr #1
    //     0x4fc460: b.eq            #0x4fc46c
    //     0x4fc464: bl              #0xd69bb8
    //     0x4fc468: stur            x2, [x0, #7]
    // 0x4fc46c: StoreStaticField(0xd00, r0)
    //     0x4fc46c: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x4fc470: str             x0, [x1, #0x1a00]
    // 0x4fc474: r0 = Null
    //     0x4fc474: mov             x0, NULL
    // 0x4fc478: LeaveFrame
    //     0x4fc478: mov             SP, fp
    //     0x4fc47c: ldp             fp, lr, [SP], #0x10
    // 0x4fc480: ret
    //     0x4fc480: ret             
    // 0x4fc484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fc484: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fc488: b               #0x4fc30c
  }
  static _ defaultStackFilter(/* No info */) {
    // ** addr: 0x4fd4f8, size: 0xf20
    // 0x4fd4f8: EnterFrame
    //     0x4fd4f8: stp             fp, lr, [SP, #-0x10]!
    //     0x4fd4fc: mov             fp, SP
    // 0x4fd500: AllocStack(0x80)
    //     0x4fd500: sub             SP, SP, #0x80
    // 0x4fd504: CheckStackOverflow
    //     0x4fd504: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fd508: cmp             SP, x16
    //     0x4fd50c: b.ls            #0x4fe3cc
    // 0x4fd510: r1 = Null
    //     0x4fd510: mov             x1, NULL
    // 0x4fd514: r2 = 32
    //     0x4fd514: mov             x2, #0x20
    // 0x4fd518: r0 = AllocateArray()
    //     0x4fd518: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fd51c: r17 = "dart:async-patch"
    //     0x4fd51c: ldr             x17, [PP, #0xfc8]  ; [pp+0xfc8] "dart:async-patch"
    // 0x4fd520: StoreField: r0->field_f = r17
    //     0x4fd520: stur            w17, [x0, #0xf]
    // 0x4fd524: StoreField: r0->field_13 = rZR
    //     0x4fd524: stur            wzr, [x0, #0x13]
    // 0x4fd528: r17 = "dart:async"
    //     0x4fd528: ldr             x17, [PP, #0xfd0]  ; [pp+0xfd0] "dart:async"
    // 0x4fd52c: StoreField: r0->field_17 = r17
    //     0x4fd52c: stur            w17, [x0, #0x17]
    // 0x4fd530: StoreField: r0->field_1b = rZR
    //     0x4fd530: stur            wzr, [x0, #0x1b]
    // 0x4fd534: r17 = "package:stack_trace"
    //     0x4fd534: ldr             x17, [PP, #0xfd8]  ; [pp+0xfd8] "package:stack_trace"
    // 0x4fd538: StoreField: r0->field_1f = r17
    //     0x4fd538: stur            w17, [x0, #0x1f]
    // 0x4fd53c: StoreField: r0->field_23 = rZR
    //     0x4fd53c: stur            wzr, [x0, #0x23]
    // 0x4fd540: r17 = "class _AssertionError"
    //     0x4fd540: ldr             x17, [PP, #0xfe0]  ; [pp+0xfe0] "class _AssertionError"
    // 0x4fd544: StoreField: r0->field_27 = r17
    //     0x4fd544: stur            w17, [x0, #0x27]
    // 0x4fd548: StoreField: r0->field_2b = rZR
    //     0x4fd548: stur            wzr, [x0, #0x2b]
    // 0x4fd54c: r17 = "class _FakeAsync"
    //     0x4fd54c: ldr             x17, [PP, #0xfe8]  ; [pp+0xfe8] "class _FakeAsync"
    // 0x4fd550: StoreField: r0->field_2f = r17
    //     0x4fd550: stur            w17, [x0, #0x2f]
    // 0x4fd554: StoreField: r0->field_33 = rZR
    //     0x4fd554: stur            wzr, [x0, #0x33]
    // 0x4fd558: r17 = "class _FrameCallbackEntry"
    //     0x4fd558: ldr             x17, [PP, #0xff0]  ; [pp+0xff0] "class _FrameCallbackEntry"
    // 0x4fd55c: StoreField: r0->field_37 = r17
    //     0x4fd55c: stur            w17, [x0, #0x37]
    // 0x4fd560: StoreField: r0->field_3b = rZR
    //     0x4fd560: stur            wzr, [x0, #0x3b]
    // 0x4fd564: r17 = "class _Timer"
    //     0x4fd564: ldr             x17, [PP, #0xff8]  ; [pp+0xff8] "class _Timer"
    // 0x4fd568: StoreField: r0->field_3f = r17
    //     0x4fd568: stur            w17, [x0, #0x3f]
    // 0x4fd56c: StoreField: r0->field_43 = rZR
    //     0x4fd56c: stur            wzr, [x0, #0x43]
    // 0x4fd570: r17 = "class _RawReceivePortImpl"
    //     0x4fd570: ldr             x17, [PP, #0x1000]  ; [pp+0x1000] "class _RawReceivePortImpl"
    // 0x4fd574: StoreField: r0->field_47 = r17
    //     0x4fd574: stur            w17, [x0, #0x47]
    // 0x4fd578: StoreField: r0->field_4b = rZR
    //     0x4fd578: stur            wzr, [x0, #0x4b]
    // 0x4fd57c: r16 = <String, int>
    //     0x4fd57c: ldr             x16, [PP, #0x7b0]  ; [pp+0x7b0] TypeArguments: <String, int>
    // 0x4fd580: stp             x0, x16, [SP, #-0x10]!
    // 0x4fd584: r0 = Map._fromLiteral()
    //     0x4fd584: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x4fd588: add             SP, SP, #0x10
    // 0x4fd58c: mov             x1, x0
    // 0x4fd590: ldr             x0, [fp, #0x10]
    // 0x4fd594: stur            x1, [fp, #-8]
    // 0x4fd598: r2 = LoadClassIdInstr(r0)
    //     0x4fd598: ldur            x2, [x0, #-1]
    //     0x4fd59c: ubfx            x2, x2, #0xc, #0x14
    // 0x4fd5a0: r16 = "\n"
    //     0x4fd5a0: ldr             x16, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x4fd5a4: stp             x16, x0, [SP, #-0x10]!
    // 0x4fd5a8: mov             x0, x2
    // 0x4fd5ac: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fd5ac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fd5b0: r0 = GDT[cid_x0 + 0xcf23]()
    //     0x4fd5b0: mov             x17, #0xcf23
    //     0x4fd5b4: add             lr, x0, x17
    //     0x4fd5b8: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd5bc: blr             lr
    // 0x4fd5c0: add             SP, SP, #0x10
    // 0x4fd5c4: SaveReg r0
    //     0x4fd5c4: str             x0, [SP, #-8]!
    // 0x4fd5c8: r0 = fromStackString()
    //     0x4fd5c8: bl              #0x4fe5b0  ; [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString
    // 0x4fd5cc: add             SP, SP, #8
    // 0x4fd5d0: mov             x1, x0
    // 0x4fd5d4: stur            x1, [fp, #-0x20]
    // 0x4fd5d8: r4 = 0
    //     0x4fd5d8: mov             x4, #0
    // 0x4fd5dc: r3 = 0
    //     0x4fd5dc: mov             x3, #0
    // 0x4fd5e0: ldur            x2, [fp, #-8]
    // 0x4fd5e4: stur            x4, [fp, #-0x10]
    // 0x4fd5e8: stur            x3, [fp, #-0x18]
    // 0x4fd5ec: CheckStackOverflow
    //     0x4fd5ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fd5f0: cmp             SP, x16
    //     0x4fd5f4: b.ls            #0x4fe3d4
    // 0x4fd5f8: r0 = LoadClassIdInstr(r1)
    //     0x4fd5f8: ldur            x0, [x1, #-1]
    //     0x4fd5fc: ubfx            x0, x0, #0xc, #0x14
    // 0x4fd600: SaveReg r1
    //     0x4fd600: str             x1, [SP, #-8]!
    // 0x4fd604: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x4fd604: mov             x17, #0xb8ea
    //     0x4fd608: add             lr, x0, x17
    //     0x4fd60c: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd610: blr             lr
    // 0x4fd614: add             SP, SP, #8
    // 0x4fd618: r1 = LoadInt32Instr(r0)
    //     0x4fd618: sbfx            x1, x0, #1, #0x1f
    // 0x4fd61c: ldur            x2, [fp, #-0x18]
    // 0x4fd620: cmp             x2, x1
    // 0x4fd624: b.ge            #0x4fd86c
    // 0x4fd628: ldur            x4, [fp, #-8]
    // 0x4fd62c: ldur            x3, [fp, #-0x20]
    // 0x4fd630: r0 = BoxInt64Instr(r2)
    //     0x4fd630: sbfiz           x0, x2, #1, #0x1f
    //     0x4fd634: cmp             x2, x0, asr #1
    //     0x4fd638: b.eq            #0x4fd644
    //     0x4fd63c: bl              #0xd69bb8
    //     0x4fd640: stur            x2, [x0, #7]
    // 0x4fd644: r1 = LoadClassIdInstr(r3)
    //     0x4fd644: ldur            x1, [x3, #-1]
    //     0x4fd648: ubfx            x1, x1, #0xc, #0x14
    // 0x4fd64c: stp             x0, x3, [SP, #-0x10]!
    // 0x4fd650: mov             x0, x1
    // 0x4fd654: r0 = GDT[cid_x0 + -0xd83]()
    //     0x4fd654: sub             lr, x0, #0xd83
    //     0x4fd658: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd65c: blr             lr
    // 0x4fd660: add             SP, SP, #0x10
    // 0x4fd664: r1 = Null
    //     0x4fd664: mov             x1, NULL
    // 0x4fd668: r2 = 4
    //     0x4fd668: mov             x2, #4
    // 0x4fd66c: stur            x0, [fp, #-0x28]
    // 0x4fd670: r0 = AllocateArray()
    //     0x4fd670: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fd674: r17 = "class "
    //     0x4fd674: ldr             x17, [PP, #0x1008]  ; [pp+0x1008] "class "
    // 0x4fd678: StoreField: r0->field_f = r17
    //     0x4fd678: stur            w17, [x0, #0xf]
    // 0x4fd67c: ldur            x1, [fp, #-0x28]
    // 0x4fd680: LoadField: r2 = r1->field_2f
    //     0x4fd680: ldur            w2, [x1, #0x2f]
    // 0x4fd684: DecompressPointer r2
    //     0x4fd684: add             x2, x2, HEAP, lsl #32
    // 0x4fd688: StoreField: r0->field_13 = r2
    //     0x4fd688: stur            w2, [x0, #0x13]
    // 0x4fd68c: SaveReg r0
    //     0x4fd68c: str             x0, [SP, #-8]!
    // 0x4fd690: r0 = _interpolate()
    //     0x4fd690: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fd694: add             SP, SP, #8
    // 0x4fd698: mov             x3, x0
    // 0x4fd69c: ldur            x0, [fp, #-0x28]
    // 0x4fd6a0: stur            x3, [fp, #-0x38]
    // 0x4fd6a4: LoadField: r4 = r0->field_13
    //     0x4fd6a4: ldur            w4, [x0, #0x13]
    // 0x4fd6a8: DecompressPointer r4
    //     0x4fd6a8: add             x4, x4, HEAP, lsl #32
    // 0x4fd6ac: stur            x4, [fp, #-0x30]
    // 0x4fd6b0: r1 = Null
    //     0x4fd6b0: mov             x1, NULL
    // 0x4fd6b4: r2 = 6
    //     0x4fd6b4: mov             x2, #6
    // 0x4fd6b8: r0 = AllocateArray()
    //     0x4fd6b8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fd6bc: mov             x1, x0
    // 0x4fd6c0: ldur            x0, [fp, #-0x30]
    // 0x4fd6c4: StoreField: r1->field_f = r0
    //     0x4fd6c4: stur            w0, [x1, #0xf]
    // 0x4fd6c8: r17 = ":"
    //     0x4fd6c8: ldr             x17, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0x4fd6cc: StoreField: r1->field_13 = r17
    //     0x4fd6cc: stur            w17, [x1, #0x13]
    // 0x4fd6d0: ldur            x0, [fp, #-0x28]
    // 0x4fd6d4: LoadField: r2 = r0->field_17
    //     0x4fd6d4: ldur            w2, [x0, #0x17]
    // 0x4fd6d8: DecompressPointer r2
    //     0x4fd6d8: add             x2, x2, HEAP, lsl #32
    // 0x4fd6dc: StoreField: r1->field_17 = r2
    //     0x4fd6dc: stur            w2, [x1, #0x17]
    // 0x4fd6e0: SaveReg r1
    //     0x4fd6e0: str             x1, [SP, #-8]!
    // 0x4fd6e4: r0 = _interpolate()
    //     0x4fd6e4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fd6e8: add             SP, SP, #8
    // 0x4fd6ec: mov             x1, x0
    // 0x4fd6f0: ldur            x0, [fp, #-8]
    // 0x4fd6f4: stur            x1, [fp, #-0x30]
    // 0x4fd6f8: LoadField: r2 = r0->field_f
    //     0x4fd6f8: ldur            w2, [x0, #0xf]
    // 0x4fd6fc: DecompressPointer r2
    //     0x4fd6fc: add             x2, x2, HEAP, lsl #32
    // 0x4fd700: stur            x2, [fp, #-0x28]
    // 0x4fd704: ldur            x16, [fp, #-0x38]
    // 0x4fd708: stp             x16, x0, [SP, #-0x10]!
    // 0x4fd70c: r0 = _getValueOrData()
    //     0x4fd70c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fd710: add             SP, SP, #0x10
    // 0x4fd714: mov             x1, x0
    // 0x4fd718: ldur            x0, [fp, #-0x28]
    // 0x4fd71c: cmp             w0, w1
    // 0x4fd720: b.eq            #0x4fd7a0
    // 0x4fd724: ldur            x3, [fp, #-0x20]
    // 0x4fd728: ldur            x1, [fp, #-0x10]
    // 0x4fd72c: ldur            x0, [fp, #-0x18]
    // 0x4fd730: add             x4, x1, #1
    // 0x4fd734: stur            x4, [fp, #-0x40]
    // 0x4fd738: r1 = Function '<anonymous closure>': static.
    //     0x4fd738: ldr             x1, [PP, #0x1010]  ; [pp+0x1010] AnonymousClosure: static (0x4ff394), in [package:flutter/src/foundation/assertions.dart] FlutterError::defaultStackFilter (0x4fd4f8)
    // 0x4fd73c: r2 = Null
    //     0x4fd73c: mov             x2, NULL
    // 0x4fd740: r0 = AllocateClosure()
    //     0x4fd740: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x4fd744: ldur            x16, [fp, #-8]
    // 0x4fd748: ldur            lr, [fp, #-0x38]
    // 0x4fd74c: stp             lr, x16, [SP, #-0x10]!
    // 0x4fd750: SaveReg r0
    //     0x4fd750: str             x0, [SP, #-8]!
    // 0x4fd754: r0 = update()
    //     0x4fd754: bl              #0x4fe418  ; [dart:collection] __Map&_HashVMBase&MapMixin::update
    // 0x4fd758: add             SP, SP, #0x18
    // 0x4fd75c: ldur            x1, [fp, #-0x20]
    // 0x4fd760: r0 = LoadClassIdInstr(r1)
    //     0x4fd760: ldur            x0, [x1, #-1]
    //     0x4fd764: ubfx            x0, x0, #0xc, #0x14
    // 0x4fd768: SaveReg r1
    //     0x4fd768: str             x1, [SP, #-8]!
    // 0x4fd76c: ldur            x2, [fp, #-0x18]
    // 0x4fd770: SaveReg r2
    //     0x4fd770: str             x2, [SP, #-8]!
    // 0x4fd774: r0 = GDT[cid_x0 + 0x102b7]()
    //     0x4fd774: mov             x17, #0x2b7
    //     0x4fd778: movk            x17, #1, lsl #16
    //     0x4fd77c: add             lr, x0, x17
    //     0x4fd780: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd784: blr             lr
    // 0x4fd788: add             SP, SP, #0x10
    // 0x4fd78c: ldur            x0, [fp, #-0x18]
    // 0x4fd790: sub             x1, x0, #1
    // 0x4fd794: ldur            x4, [fp, #-0x40]
    // 0x4fd798: mov             x0, x1
    // 0x4fd79c: b               #0x4fd860
    // 0x4fd7a0: ldur            x2, [fp, #-8]
    // 0x4fd7a4: ldur            x1, [fp, #-0x10]
    // 0x4fd7a8: ldur            x0, [fp, #-0x18]
    // 0x4fd7ac: LoadField: r3 = r2->field_f
    //     0x4fd7ac: ldur            w3, [x2, #0xf]
    // 0x4fd7b0: DecompressPointer r3
    //     0x4fd7b0: add             x3, x3, HEAP, lsl #32
    // 0x4fd7b4: stur            x3, [fp, #-0x28]
    // 0x4fd7b8: ldur            x16, [fp, #-0x30]
    // 0x4fd7bc: stp             x16, x2, [SP, #-0x10]!
    // 0x4fd7c0: r0 = _getValueOrData()
    //     0x4fd7c0: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x4fd7c4: add             SP, SP, #0x10
    // 0x4fd7c8: mov             x1, x0
    // 0x4fd7cc: ldur            x0, [fp, #-0x28]
    // 0x4fd7d0: cmp             w0, w1
    // 0x4fd7d4: b.eq            #0x4fd854
    // 0x4fd7d8: ldur            x3, [fp, #-0x20]
    // 0x4fd7dc: ldur            x1, [fp, #-0x10]
    // 0x4fd7e0: ldur            x0, [fp, #-0x18]
    // 0x4fd7e4: add             x4, x1, #1
    // 0x4fd7e8: stur            x4, [fp, #-0x40]
    // 0x4fd7ec: r1 = Function '<anonymous closure>': static.
    //     0x4fd7ec: ldr             x1, [PP, #0x1018]  ; [pp+0x1018] AnonymousClosure: static (0x4ff394), in [package:flutter/src/foundation/assertions.dart] FlutterError::defaultStackFilter (0x4fd4f8)
    // 0x4fd7f0: r2 = Null
    //     0x4fd7f0: mov             x2, NULL
    // 0x4fd7f4: r0 = AllocateClosure()
    //     0x4fd7f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x4fd7f8: ldur            x16, [fp, #-8]
    // 0x4fd7fc: ldur            lr, [fp, #-0x30]
    // 0x4fd800: stp             lr, x16, [SP, #-0x10]!
    // 0x4fd804: SaveReg r0
    //     0x4fd804: str             x0, [SP, #-8]!
    // 0x4fd808: r0 = update()
    //     0x4fd808: bl              #0x4fe418  ; [dart:collection] __Map&_HashVMBase&MapMixin::update
    // 0x4fd80c: add             SP, SP, #0x18
    // 0x4fd810: ldur            x1, [fp, #-0x20]
    // 0x4fd814: r0 = LoadClassIdInstr(r1)
    //     0x4fd814: ldur            x0, [x1, #-1]
    //     0x4fd818: ubfx            x0, x0, #0xc, #0x14
    // 0x4fd81c: SaveReg r1
    //     0x4fd81c: str             x1, [SP, #-8]!
    // 0x4fd820: ldur            x2, [fp, #-0x18]
    // 0x4fd824: SaveReg r2
    //     0x4fd824: str             x2, [SP, #-8]!
    // 0x4fd828: r0 = GDT[cid_x0 + 0x102b7]()
    //     0x4fd828: mov             x17, #0x2b7
    //     0x4fd82c: movk            x17, #1, lsl #16
    //     0x4fd830: add             lr, x0, x17
    //     0x4fd834: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd838: blr             lr
    // 0x4fd83c: add             SP, SP, #0x10
    // 0x4fd840: ldur            x0, [fp, #-0x18]
    // 0x4fd844: sub             x1, x0, #1
    // 0x4fd848: mov             x0, x1
    // 0x4fd84c: ldur            x1, [fp, #-0x40]
    // 0x4fd850: b               #0x4fd85c
    // 0x4fd854: ldur            x1, [fp, #-0x10]
    // 0x4fd858: ldur            x0, [fp, #-0x18]
    // 0x4fd85c: mov             x4, x1
    // 0x4fd860: add             x3, x0, #1
    // 0x4fd864: ldur            x1, [fp, #-0x20]
    // 0x4fd868: b               #0x4fd5e0
    // 0x4fd86c: ldur            x2, [fp, #-0x20]
    // 0x4fd870: ldur            x1, [fp, #-0x10]
    // 0x4fd874: r0 = LoadClassIdInstr(r2)
    //     0x4fd874: ldur            x0, [x2, #-1]
    //     0x4fd878: ubfx            x0, x0, #0xc, #0x14
    // 0x4fd87c: SaveReg r2
    //     0x4fd87c: str             x2, [SP, #-8]!
    // 0x4fd880: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x4fd880: mov             x17, #0xb8ea
    //     0x4fd884: add             lr, x0, x17
    //     0x4fd888: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd88c: blr             lr
    // 0x4fd890: add             SP, SP, #8
    // 0x4fd894: mov             x2, x0
    // 0x4fd898: r1 = <String?>
    //     0x4fd898: ldr             x1, [PP, #0x1020]  ; [pp+0x1020] TypeArguments: <String?>
    // 0x4fd89c: stur            x0, [fp, #-0x28]
    // 0x4fd8a0: r0 = AllocateArray()
    //     0x4fd8a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fd8a4: stur            x0, [fp, #-0x30]
    // 0x4fd8a8: r0 = InitLateStaticField(0xd04) // [package:flutter/src/foundation/assertions.dart] FlutterError::_stackFilters
    //     0x4fd8a8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4fd8ac: ldr             x0, [x0, #0x1a08]
    //     0x4fd8b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4fd8b4: cmp             w0, w16
    //     0x4fd8b8: b.ne            #0x4fd8c4
    //     0x4fd8bc: ldr             x2, [PP, #0x1028]  ; [pp+0x1028] Field <FlutterError._stackFilters@627022608>: static late final (offset: 0xd04)
    //     0x4fd8c0: bl              #0xd67cdc
    // 0x4fd8c4: mov             x1, x0
    // 0x4fd8c8: stur            x1, [fp, #-0x48]
    // 0x4fd8cc: LoadField: r2 = r1->field_7
    //     0x4fd8cc: ldur            w2, [x1, #7]
    // 0x4fd8d0: DecompressPointer r2
    //     0x4fd8d0: add             x2, x2, HEAP, lsl #32
    // 0x4fd8d4: stur            x2, [fp, #-0x38]
    // 0x4fd8d8: LoadField: r0 = r1->field_b
    //     0x4fd8d8: ldur            w0, [x1, #0xb]
    // 0x4fd8dc: DecompressPointer r0
    //     0x4fd8dc: add             x0, x0, HEAP, lsl #32
    // 0x4fd8e0: r3 = LoadInt32Instr(r0)
    //     0x4fd8e0: sbfx            x3, x0, #1, #0x1f
    // 0x4fd8e4: stur            x3, [fp, #-0x18]
    // 0x4fd8e8: r0 = LoadClassIdInstr(r1)
    //     0x4fd8e8: ldur            x0, [x1, #-1]
    //     0x4fd8ec: ubfx            x0, x0, #0xc, #0x14
    // 0x4fd8f0: SaveReg r1
    //     0x4fd8f0: str             x1, [SP, #-8]!
    // 0x4fd8f4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x4fd8f4: mov             x17, #0xb8ea
    //     0x4fd8f8: add             lr, x0, x17
    //     0x4fd8fc: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd900: blr             lr
    // 0x4fd904: add             SP, SP, #8
    // 0x4fd908: r1 = LoadInt32Instr(r0)
    //     0x4fd908: sbfx            x1, x0, #1, #0x1f
    //     0x4fd90c: tbz             w0, #0, #0x4fd914
    //     0x4fd910: ldur            x1, [x0, #7]
    // 0x4fd914: ldur            x0, [fp, #-0x18]
    // 0x4fd918: cmp             x0, x1
    // 0x4fd91c: b.ne            #0x4fe378
    // 0x4fd920: ldur            x0, [fp, #-0x48]
    // 0x4fd924: cmp             x1, #0
    // 0x4fd928: b.gt            #0x4fe348
    // 0x4fd92c: ldur            x0, [fp, #-0x28]
    // 0x4fd930: r16 = <String>
    //     0x4fd930: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x4fd934: stp             xzr, x16, [SP, #-0x10]!
    // 0x4fd938: r0 = _GrowableList()
    //     0x4fd938: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x4fd93c: add             SP, SP, #0x10
    // 0x4fd940: mov             x1, x0
    // 0x4fd944: ldur            x0, [fp, #-0x28]
    // 0x4fd948: stur            x1, [fp, #-0x58]
    // 0x4fd94c: r2 = LoadInt32Instr(r0)
    //     0x4fd94c: sbfx            x2, x0, #1, #0x1f
    // 0x4fd950: stur            x2, [fp, #-0x50]
    // 0x4fd954: sub             x3, x2, #1
    // 0x4fd958: stur            x3, [fp, #-0x40]
    // 0x4fd95c: r6 = 0
    //     0x4fd95c: mov             x6, #0
    // 0x4fd960: ldur            x5, [fp, #-0x20]
    // 0x4fd964: ldur            x4, [fp, #-0x30]
    // 0x4fd968: stur            x6, [fp, #-0x18]
    // 0x4fd96c: CheckStackOverflow
    //     0x4fd96c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fd970: cmp             SP, x16
    //     0x4fd974: b.ls            #0x4fe3dc
    // 0x4fd978: r0 = LoadClassIdInstr(r5)
    //     0x4fd978: ldur            x0, [x5, #-1]
    //     0x4fd97c: ubfx            x0, x0, #0xc, #0x14
    // 0x4fd980: SaveReg r5
    //     0x4fd980: str             x5, [SP, #-8]!
    // 0x4fd984: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x4fd984: mov             x17, #0xb8ea
    //     0x4fd988: add             lr, x0, x17
    //     0x4fd98c: ldr             lr, [x21, lr, lsl #3]
    //     0x4fd990: blr             lr
    // 0x4fd994: add             SP, SP, #8
    // 0x4fd998: r1 = LoadInt32Instr(r0)
    //     0x4fd998: sbfx            x1, x0, #1, #0x1f
    // 0x4fd99c: ldur            x2, [fp, #-0x18]
    // 0x4fd9a0: cmp             x2, x1
    // 0x4fd9a4: b.ge            #0x4fdc38
    // 0x4fd9a8: mov             x5, x2
    // 0x4fd9ac: ldur            x3, [fp, #-0x40]
    // 0x4fd9b0: ldur            x4, [fp, #-0x30]
    // 0x4fd9b4: stur            x5, [fp, #-0x68]
    // 0x4fd9b8: CheckStackOverflow
    //     0x4fd9b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fd9bc: cmp             SP, x16
    //     0x4fd9c0: b.ls            #0x4fe3e4
    // 0x4fd9c4: cmp             x5, x3
    // 0x4fd9c8: b.ge            #0x4fda44
    // 0x4fd9cc: ldur            x0, [fp, #-0x50]
    // 0x4fd9d0: mov             x1, x5
    // 0x4fd9d4: cmp             x1, x0
    // 0x4fd9d8: b.hs            #0x4fe3ec
    // 0x4fd9dc: ArrayLoad: r6 = r4[r5]  ; Unknown_4
    //     0x4fd9dc: add             x16, x4, x5, lsl #2
    //     0x4fd9e0: ldur            w6, [x16, #0xf]
    // 0x4fd9e4: DecompressPointer r6
    //     0x4fd9e4: add             x6, x6, HEAP, lsl #32
    // 0x4fd9e8: cmp             w6, NULL
    // 0x4fd9ec: b.eq            #0x4fda44
    // 0x4fd9f0: add             x7, x5, #1
    // 0x4fd9f4: ldur            x0, [fp, #-0x50]
    // 0x4fd9f8: mov             x1, x7
    // 0x4fd9fc: stur            x7, [fp, #-0x60]
    // 0x4fda00: cmp             x1, x0
    // 0x4fda04: b.hs            #0x4fe3f0
    // 0x4fda08: ArrayLoad: r0 = r4[r7]  ; Unknown_4
    //     0x4fda08: add             x16, x4, x7, lsl #2
    //     0x4fda0c: ldur            w0, [x16, #0xf]
    // 0x4fda10: DecompressPointer r0
    //     0x4fda10: add             x0, x0, HEAP, lsl #32
    // 0x4fda14: r1 = LoadClassIdInstr(r0)
    //     0x4fda14: ldur            x1, [x0, #-1]
    //     0x4fda18: ubfx            x1, x1, #0xc, #0x14
    // 0x4fda1c: stp             x6, x0, [SP, #-0x10]!
    // 0x4fda20: mov             x0, x1
    // 0x4fda24: mov             lr, x0
    // 0x4fda28: ldr             lr, [x21, lr, lsl #3]
    // 0x4fda2c: blr             lr
    // 0x4fda30: add             SP, SP, #0x10
    // 0x4fda34: tbnz            w0, #4, #0x4fda44
    // 0x4fda38: ldur            x5, [fp, #-0x60]
    // 0x4fda3c: ldur            x2, [fp, #-0x18]
    // 0x4fda40: b               #0x4fd9ac
    // 0x4fda44: ldur            x4, [fp, #-0x68]
    // 0x4fda48: ldur            x3, [fp, #-0x30]
    // 0x4fda4c: ldur            x0, [fp, #-0x50]
    // 0x4fda50: mov             x1, x4
    // 0x4fda54: cmp             x1, x0
    // 0x4fda58: b.hs            #0x4fe3f4
    // 0x4fda5c: r0 = BoxInt64Instr(r4)
    //     0x4fda5c: sbfiz           x0, x4, #1, #0x1f
    //     0x4fda60: cmp             x4, x0, asr #1
    //     0x4fda64: b.eq            #0x4fda70
    //     0x4fda68: bl              #0xd69bb8
    //     0x4fda6c: stur            x4, [x0, #7]
    // 0x4fda70: stur            x0, [fp, #-0x28]
    // 0x4fda74: ArrayLoad: r1 = r3[r4]  ; Unknown_4
    //     0x4fda74: add             x16, x3, x4, lsl #2
    //     0x4fda78: ldur            w1, [x16, #0xf]
    // 0x4fda7c: DecompressPointer r1
    //     0x4fda7c: add             x1, x1, HEAP, lsl #32
    // 0x4fda80: cmp             w1, NULL
    // 0x4fda84: b.eq            #0x4fdaf8
    // 0x4fda88: ldur            x5, [fp, #-0x18]
    // 0x4fda8c: cmp             x4, x5
    // 0x4fda90: b.eq            #0x4fdaec
    // 0x4fda94: r1 = Null
    //     0x4fda94: mov             x1, NULL
    // 0x4fda98: r2 = 6
    //     0x4fda98: mov             x2, #6
    // 0x4fda9c: r0 = AllocateArray()
    //     0x4fda9c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fdaa0: mov             x2, x0
    // 0x4fdaa4: r17 = " ("
    //     0x4fdaa4: ldr             x17, [PP, #0x1030]  ; [pp+0x1030] " ("
    // 0x4fdaa8: StoreField: r2->field_f = r17
    //     0x4fdaa8: stur            w17, [x2, #0xf]
    // 0x4fdaac: ldur            x0, [fp, #-0x18]
    // 0x4fdab0: ldur            x3, [fp, #-0x68]
    // 0x4fdab4: sub             x1, x3, x0
    // 0x4fdab8: add             x4, x1, #2
    // 0x4fdabc: r0 = BoxInt64Instr(r4)
    //     0x4fdabc: sbfiz           x0, x4, #1, #0x1f
    //     0x4fdac0: cmp             x4, x0, asr #1
    //     0x4fdac4: b.eq            #0x4fdad0
    //     0x4fdac8: bl              #0xd69bb8
    //     0x4fdacc: stur            x4, [x0, #7]
    // 0x4fdad0: StoreField: r2->field_13 = r0
    //     0x4fdad0: stur            w0, [x2, #0x13]
    // 0x4fdad4: r17 = " frames)"
    //     0x4fdad4: ldr             x17, [PP, #0x1038]  ; [pp+0x1038] " frames)"
    // 0x4fdad8: StoreField: r2->field_17 = r17
    //     0x4fdad8: stur            w17, [x2, #0x17]
    // 0x4fdadc: SaveReg r2
    //     0x4fdadc: str             x2, [SP, #-8]!
    // 0x4fdae0: r0 = _interpolate()
    //     0x4fdae0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fdae4: add             SP, SP, #8
    // 0x4fdae8: b               #0x4fdaf0
    // 0x4fdaec: r0 = " (1 frame)"
    //     0x4fdaec: ldr             x0, [PP, #0x1040]  ; [pp+0x1040] " (1 frame)"
    // 0x4fdaf0: mov             x3, x0
    // 0x4fdaf4: b               #0x4fdafc
    // 0x4fdaf8: r3 = ""
    //     0x4fdaf8: ldr             x3, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x4fdafc: ldur            x1, [fp, #-0x68]
    // 0x4fdb00: ldur            x2, [fp, #-0x30]
    // 0x4fdb04: stur            x3, [fp, #-0x70]
    // 0x4fdb08: ArrayLoad: r0 = r2[r1]  ; Unknown_4
    //     0x4fdb08: add             x16, x2, x1, lsl #2
    //     0x4fdb0c: ldur            w0, [x16, #0xf]
    // 0x4fdb10: DecompressPointer r0
    //     0x4fdb10: add             x0, x0, HEAP, lsl #32
    // 0x4fdb14: cmp             w0, NULL
    // 0x4fdb18: b.ne            #0x4fdb50
    // 0x4fdb1c: ldur            x4, [fp, #-0x20]
    // 0x4fdb20: r0 = LoadClassIdInstr(r4)
    //     0x4fdb20: ldur            x0, [x4, #-1]
    //     0x4fdb24: ubfx            x0, x0, #0xc, #0x14
    // 0x4fdb28: ldur            x16, [fp, #-0x28]
    // 0x4fdb2c: stp             x16, x4, [SP, #-0x10]!
    // 0x4fdb30: r0 = GDT[cid_x0 + -0xd83]()
    //     0x4fdb30: sub             lr, x0, #0xd83
    //     0x4fdb34: ldr             lr, [x21, lr, lsl #3]
    //     0x4fdb38: blr             lr
    // 0x4fdb3c: add             SP, SP, #0x10
    // 0x4fdb40: LoadField: r1 = r0->field_7
    //     0x4fdb40: ldur            w1, [x0, #7]
    // 0x4fdb44: DecompressPointer r1
    //     0x4fdb44: add             x1, x1, HEAP, lsl #32
    // 0x4fdb48: mov             x4, x1
    // 0x4fdb4c: b               #0x4fdb54
    // 0x4fdb50: mov             x4, x0
    // 0x4fdb54: ldur            x3, [fp, #-0x58]
    // 0x4fdb58: ldur            x0, [fp, #-0x70]
    // 0x4fdb5c: stur            x4, [fp, #-0x28]
    // 0x4fdb60: r1 = Null
    //     0x4fdb60: mov             x1, NULL
    // 0x4fdb64: r2 = 4
    //     0x4fdb64: mov             x2, #4
    // 0x4fdb68: r0 = AllocateArray()
    //     0x4fdb68: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fdb6c: mov             x1, x0
    // 0x4fdb70: ldur            x0, [fp, #-0x28]
    // 0x4fdb74: StoreField: r1->field_f = r0
    //     0x4fdb74: stur            w0, [x1, #0xf]
    // 0x4fdb78: ldur            x0, [fp, #-0x70]
    // 0x4fdb7c: StoreField: r1->field_13 = r0
    //     0x4fdb7c: stur            w0, [x1, #0x13]
    // 0x4fdb80: SaveReg r1
    //     0x4fdb80: str             x1, [SP, #-8]!
    // 0x4fdb84: r0 = _interpolate()
    //     0x4fdb84: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fdb88: add             SP, SP, #8
    // 0x4fdb8c: mov             x1, x0
    // 0x4fdb90: ldur            x0, [fp, #-0x58]
    // 0x4fdb94: stur            x1, [fp, #-0x70]
    // 0x4fdb98: LoadField: r2 = r0->field_b
    //     0x4fdb98: ldur            w2, [x0, #0xb]
    // 0x4fdb9c: DecompressPointer r2
    //     0x4fdb9c: add             x2, x2, HEAP, lsl #32
    // 0x4fdba0: stur            x2, [fp, #-0x28]
    // 0x4fdba4: LoadField: r3 = r0->field_f
    //     0x4fdba4: ldur            w3, [x0, #0xf]
    // 0x4fdba8: DecompressPointer r3
    //     0x4fdba8: add             x3, x3, HEAP, lsl #32
    // 0x4fdbac: LoadField: r4 = r3->field_b
    //     0x4fdbac: ldur            w4, [x3, #0xb]
    // 0x4fdbb0: DecompressPointer r4
    //     0x4fdbb0: add             x4, x4, HEAP, lsl #32
    // 0x4fdbb4: cmp             w2, w4
    // 0x4fdbb8: b.ne            #0x4fdbc8
    // 0x4fdbbc: SaveReg r0
    //     0x4fdbbc: str             x0, [SP, #-8]!
    // 0x4fdbc0: r0 = _growToNextCapacity()
    //     0x4fdbc0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4fdbc4: add             SP, SP, #8
    // 0x4fdbc8: ldur            x2, [fp, #-0x58]
    // 0x4fdbcc: ldur            x3, [fp, #-0x68]
    // 0x4fdbd0: ldur            x0, [fp, #-0x28]
    // 0x4fdbd4: r4 = LoadInt32Instr(r0)
    //     0x4fdbd4: sbfx            x4, x0, #1, #0x1f
    // 0x4fdbd8: add             x0, x4, #1
    // 0x4fdbdc: lsl             x1, x0, #1
    // 0x4fdbe0: StoreField: r2->field_b = r1
    //     0x4fdbe0: stur            w1, [x2, #0xb]
    // 0x4fdbe4: mov             x1, x4
    // 0x4fdbe8: cmp             x1, x0
    // 0x4fdbec: b.hs            #0x4fe3f8
    // 0x4fdbf0: LoadField: r1 = r2->field_f
    //     0x4fdbf0: ldur            w1, [x2, #0xf]
    // 0x4fdbf4: DecompressPointer r1
    //     0x4fdbf4: add             x1, x1, HEAP, lsl #32
    // 0x4fdbf8: ldur            x0, [fp, #-0x70]
    // 0x4fdbfc: ArrayStore: r1[r4] = r0  ; List_4
    //     0x4fdbfc: add             x25, x1, x4, lsl #2
    //     0x4fdc00: add             x25, x25, #0xf
    //     0x4fdc04: str             w0, [x25]
    //     0x4fdc08: tbz             w0, #0, #0x4fdc24
    //     0x4fdc0c: ldurb           w16, [x1, #-1]
    //     0x4fdc10: ldurb           w17, [x0, #-1]
    //     0x4fdc14: and             x16, x17, x16, lsr #2
    //     0x4fdc18: tst             x16, HEAP, lsr #32
    //     0x4fdc1c: b.eq            #0x4fdc24
    //     0x4fdc20: bl              #0xd67e5c
    // 0x4fdc24: add             x6, x3, #1
    // 0x4fdc28: mov             x1, x2
    // 0x4fdc2c: ldur            x3, [fp, #-0x40]
    // 0x4fdc30: ldur            x2, [fp, #-0x50]
    // 0x4fdc34: b               #0x4fd960
    // 0x4fdc38: ldur            x2, [fp, #-0x58]
    // 0x4fdc3c: r16 = <String>
    //     0x4fdc3c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x4fdc40: stp             xzr, x16, [SP, #-0x10]!
    // 0x4fdc44: r0 = _GrowableList()
    //     0x4fdc44: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x4fdc48: add             SP, SP, #0x10
    // 0x4fdc4c: stur            x0, [fp, #-0x20]
    // 0x4fdc50: ldur            x16, [fp, #-8]
    // 0x4fdc54: SaveReg r16
    //     0x4fdc54: str             x16, [SP, #-8]!
    // 0x4fdc58: r0 = entries()
    //     0x4fdc58: bl              #0xc761a0  ; [dart:collection] __Map&_HashVMBase&MapMixin::entries
    // 0x4fdc5c: add             SP, SP, #8
    // 0x4fdc60: SaveReg r0
    //     0x4fdc60: str             x0, [SP, #-8]!
    // 0x4fdc64: r0 = iterator()
    //     0x4fdc64: bl              #0x6fc978  ; [dart:_internal] MappedIterable::iterator
    // 0x4fdc68: add             SP, SP, #8
    // 0x4fdc6c: mov             x1, x0
    // 0x4fdc70: stur            x1, [fp, #-0x70]
    // 0x4fdc74: LoadField: r2 = r1->field_f
    //     0x4fdc74: ldur            w2, [x1, #0xf]
    // 0x4fdc78: DecompressPointer r2
    //     0x4fdc78: add             x2, x2, HEAP, lsl #32
    // 0x4fdc7c: stur            x2, [fp, #-0x30]
    // 0x4fdc80: LoadField: r3 = r1->field_13
    //     0x4fdc80: ldur            w3, [x1, #0x13]
    // 0x4fdc84: DecompressPointer r3
    //     0x4fdc84: add             x3, x3, HEAP, lsl #32
    // 0x4fdc88: stur            x3, [fp, #-0x28]
    // 0x4fdc8c: LoadField: r4 = r1->field_7
    //     0x4fdc8c: ldur            w4, [x1, #7]
    // 0x4fdc90: DecompressPointer r4
    //     0x4fdc90: add             x4, x4, HEAP, lsl #32
    // 0x4fdc94: stur            x4, [fp, #-8]
    // 0x4fdc98: ldur            x5, [fp, #-0x20]
    // 0x4fdc9c: CheckStackOverflow
    //     0x4fdc9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fdca0: cmp             SP, x16
    //     0x4fdca4: b.ls            #0x4fe3fc
    // 0x4fdca8: r0 = LoadClassIdInstr(r2)
    //     0x4fdca8: ldur            x0, [x2, #-1]
    //     0x4fdcac: ubfx            x0, x0, #0xc, #0x14
    // 0x4fdcb0: SaveReg r2
    //     0x4fdcb0: str             x2, [SP, #-8]!
    // 0x4fdcb4: r0 = GDT[cid_x0 + 0x541]()
    //     0x4fdcb4: add             lr, x0, #0x541
    //     0x4fdcb8: ldr             lr, [x21, lr, lsl #3]
    //     0x4fdcbc: blr             lr
    // 0x4fdcc0: add             SP, SP, #8
    // 0x4fdcc4: tbnz            w0, #4, #0x4fde90
    // 0x4fdcc8: ldur            x1, [fp, #-0x70]
    // 0x4fdccc: ldur            x2, [fp, #-0x30]
    // 0x4fdcd0: r0 = LoadClassIdInstr(r2)
    //     0x4fdcd0: ldur            x0, [x2, #-1]
    //     0x4fdcd4: ubfx            x0, x0, #0xc, #0x14
    // 0x4fdcd8: SaveReg r2
    //     0x4fdcd8: str             x2, [SP, #-8]!
    // 0x4fdcdc: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x4fdcdc: add             lr, x0, #0x5ca
    //     0x4fdce0: ldr             lr, [x21, lr, lsl #3]
    //     0x4fdce4: blr             lr
    // 0x4fdce8: add             SP, SP, #8
    // 0x4fdcec: ldur            x16, [fp, #-0x28]
    // 0x4fdcf0: stp             x0, x16, [SP, #-0x10]!
    // 0x4fdcf4: ldur            x0, [fp, #-0x28]
    // 0x4fdcf8: ClosureCall
    //     0x4fdcf8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4fdcfc: ldur            x2, [x0, #0x1f]
    //     0x4fdd00: blr             x2
    // 0x4fdd04: add             SP, SP, #0x10
    // 0x4fdd08: mov             x4, x0
    // 0x4fdd0c: ldur            x3, [fp, #-0x70]
    // 0x4fdd10: stur            x4, [fp, #-0x78]
    // 0x4fdd14: StoreField: r3->field_b = r0
    //     0x4fdd14: stur            w0, [x3, #0xb]
    //     0x4fdd18: tbz             w0, #0, #0x4fdd34
    //     0x4fdd1c: ldurb           w16, [x3, #-1]
    //     0x4fdd20: ldurb           w17, [x0, #-1]
    //     0x4fdd24: and             x16, x17, x16, lsr #2
    //     0x4fdd28: tst             x16, HEAP, lsr #32
    //     0x4fdd2c: b.eq            #0x4fdd34
    //     0x4fdd30: bl              #0xd682ac
    // 0x4fdd34: cmp             w4, NULL
    // 0x4fdd38: b.ne            #0x4fdd68
    // 0x4fdd3c: mov             x0, x4
    // 0x4fdd40: ldur            x2, [fp, #-8]
    // 0x4fdd44: r1 = Null
    //     0x4fdd44: mov             x1, NULL
    // 0x4fdd48: cmp             w2, NULL
    // 0x4fdd4c: b.eq            #0x4fdd68
    // 0x4fdd50: LoadField: r4 = r2->field_1f
    //     0x4fdd50: ldur            w4, [x2, #0x1f]
    // 0x4fdd54: DecompressPointer r4
    //     0x4fdd54: add             x4, x4, HEAP, lsl #32
    // 0x4fdd58: r8 = C1X1
    //     0x4fdd58: ldr             x8, [PP, #0x1048]  ; [pp+0x1048] TypeParameter: C1X1
    // 0x4fdd5c: LoadField: r9 = r4->field_7
    //     0x4fdd5c: ldur            x9, [x4, #7]
    // 0x4fdd60: r3 = Null
    //     0x4fdd60: ldr             x3, [PP, #0x1050]  ; [pp+0x1050] Null
    // 0x4fdd64: blr             x9
    // 0x4fdd68: ldur            x1, [fp, #-0x78]
    // 0x4fdd6c: r0 = LoadClassIdInstr(r1)
    //     0x4fdd6c: ldur            x0, [x1, #-1]
    //     0x4fdd70: ubfx            x0, x0, #0xc, #0x14
    // 0x4fdd74: SaveReg r1
    //     0x4fdd74: str             x1, [SP, #-8]!
    // 0x4fdd78: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x4fdd78: sub             lr, x0, #0xfc4
    //     0x4fdd7c: ldr             lr, [x21, lr, lsl #3]
    //     0x4fdd80: blr             lr
    // 0x4fdd84: add             SP, SP, #8
    // 0x4fdd88: r1 = 59
    //     0x4fdd88: mov             x1, #0x3b
    // 0x4fdd8c: branchIfSmi(r0, 0x4fdd98)
    //     0x4fdd8c: tbz             w0, #0, #0x4fdd98
    // 0x4fdd90: r1 = LoadClassIdInstr(r0)
    //     0x4fdd90: ldur            x1, [x0, #-1]
    //     0x4fdd94: ubfx            x1, x1, #0xc, #0x14
    // 0x4fdd98: stp             xzr, x0, [SP, #-0x10]!
    // 0x4fdd9c: mov             x0, x1
    // 0x4fdda0: r0 = GDT[cid_x0 + -0xfed]()
    //     0x4fdda0: sub             lr, x0, #0xfed
    //     0x4fdda4: ldr             lr, [x21, lr, lsl #3]
    //     0x4fdda8: blr             lr
    // 0x4fddac: add             SP, SP, #0x10
    // 0x4fddb0: tbnz            w0, #4, #0x4fde74
    // 0x4fddb4: ldur            x1, [fp, #-0x20]
    // 0x4fddb8: ldur            x0, [fp, #-0x78]
    // 0x4fddbc: r2 = LoadClassIdInstr(r0)
    //     0x4fddbc: ldur            x2, [x0, #-1]
    //     0x4fddc0: ubfx            x2, x2, #0xc, #0x14
    // 0x4fddc4: SaveReg r0
    //     0x4fddc4: str             x0, [SP, #-8]!
    // 0x4fddc8: mov             x0, x2
    // 0x4fddcc: r0 = GDT[cid_x0 + -0xfba]()
    //     0x4fddcc: sub             lr, x0, #0xfba
    //     0x4fddd0: ldr             lr, [x21, lr, lsl #3]
    //     0x4fddd4: blr             lr
    // 0x4fddd8: add             SP, SP, #8
    // 0x4fdddc: mov             x1, x0
    // 0x4fdde0: ldur            x0, [fp, #-0x20]
    // 0x4fdde4: stur            x1, [fp, #-0x80]
    // 0x4fdde8: LoadField: r2 = r0->field_b
    //     0x4fdde8: ldur            w2, [x0, #0xb]
    // 0x4fddec: DecompressPointer r2
    //     0x4fddec: add             x2, x2, HEAP, lsl #32
    // 0x4fddf0: stur            x2, [fp, #-0x78]
    // 0x4fddf4: LoadField: r3 = r0->field_f
    //     0x4fddf4: ldur            w3, [x0, #0xf]
    // 0x4fddf8: DecompressPointer r3
    //     0x4fddf8: add             x3, x3, HEAP, lsl #32
    // 0x4fddfc: LoadField: r4 = r3->field_b
    //     0x4fddfc: ldur            w4, [x3, #0xb]
    // 0x4fde00: DecompressPointer r4
    //     0x4fde00: add             x4, x4, HEAP, lsl #32
    // 0x4fde04: cmp             w2, w4
    // 0x4fde08: b.ne            #0x4fde18
    // 0x4fde0c: SaveReg r0
    //     0x4fde0c: str             x0, [SP, #-8]!
    // 0x4fde10: r0 = _growToNextCapacity()
    //     0x4fde10: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4fde14: add             SP, SP, #8
    // 0x4fde18: ldur            x2, [fp, #-0x20]
    // 0x4fde1c: ldur            x0, [fp, #-0x78]
    // 0x4fde20: r3 = LoadInt32Instr(r0)
    //     0x4fde20: sbfx            x3, x0, #1, #0x1f
    // 0x4fde24: add             x0, x3, #1
    // 0x4fde28: lsl             x1, x0, #1
    // 0x4fde2c: StoreField: r2->field_b = r1
    //     0x4fde2c: stur            w1, [x2, #0xb]
    // 0x4fde30: mov             x1, x3
    // 0x4fde34: cmp             x1, x0
    // 0x4fde38: b.hs            #0x4fe404
    // 0x4fde3c: LoadField: r1 = r2->field_f
    //     0x4fde3c: ldur            w1, [x2, #0xf]
    // 0x4fde40: DecompressPointer r1
    //     0x4fde40: add             x1, x1, HEAP, lsl #32
    // 0x4fde44: ldur            x0, [fp, #-0x80]
    // 0x4fde48: ArrayStore: r1[r3] = r0  ; List_4
    //     0x4fde48: add             x25, x1, x3, lsl #2
    //     0x4fde4c: add             x25, x25, #0xf
    //     0x4fde50: str             w0, [x25]
    //     0x4fde54: tbz             w0, #0, #0x4fde70
    //     0x4fde58: ldurb           w16, [x1, #-1]
    //     0x4fde5c: ldurb           w17, [x0, #-1]
    //     0x4fde60: and             x16, x17, x16, lsr #2
    //     0x4fde64: tst             x16, HEAP, lsr #32
    //     0x4fde68: b.eq            #0x4fde70
    //     0x4fde6c: bl              #0xd67e5c
    // 0x4fde70: b               #0x4fde78
    // 0x4fde74: ldur            x2, [fp, #-0x20]
    // 0x4fde78: mov             x5, x2
    // 0x4fde7c: ldur            x1, [fp, #-0x70]
    // 0x4fde80: ldur            x4, [fp, #-8]
    // 0x4fde84: ldur            x2, [fp, #-0x30]
    // 0x4fde88: ldur            x3, [fp, #-0x28]
    // 0x4fde8c: b               #0x4fdc9c
    // 0x4fde90: ldur            x1, [fp, #-0x10]
    // 0x4fde94: ldur            x2, [fp, #-0x20]
    // 0x4fde98: ldur            x0, [fp, #-0x70]
    // 0x4fde9c: StoreField: r0->field_b = rNULL
    //     0x4fde9c: stur            NULL, [x0, #0xb]
    // 0x4fdea0: SaveReg r2
    //     0x4fdea0: str             x2, [SP, #-8]!
    // 0x4fdea4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fdea4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fdea8: r0 = sort()
    //     0x4fdea8: bl              #0x5edd6c  ; [dart:collection] _ListBase&Object&ListMixin::sort
    // 0x4fdeac: add             SP, SP, #8
    // 0x4fdeb0: ldur            x0, [fp, #-0x10]
    // 0x4fdeb4: cmp             x0, #1
    // 0x4fdeb8: b.ne            #0x4fdfc4
    // 0x4fdebc: ldur            x0, [fp, #-0x58]
    // 0x4fdec0: r1 = Null
    //     0x4fdec0: mov             x1, NULL
    // 0x4fdec4: r2 = 6
    //     0x4fdec4: mov             x2, #6
    // 0x4fdec8: r0 = AllocateArray()
    //     0x4fdec8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fdecc: stur            x0, [fp, #-8]
    // 0x4fded0: r17 = "(elided one frame from "
    //     0x4fded0: ldr             x17, [PP, #0x1070]  ; [pp+0x1070] "(elided one frame from "
    // 0x4fded4: StoreField: r0->field_f = r17
    //     0x4fded4: stur            w17, [x0, #0xf]
    // 0x4fded8: ldur            x16, [fp, #-0x20]
    // 0x4fdedc: SaveReg r16
    //     0x4fdedc: str             x16, [SP, #-8]!
    // 0x4fdee0: r0 = single()
    //     0x4fdee0: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x4fdee4: add             SP, SP, #8
    // 0x4fdee8: ldur            x1, [fp, #-8]
    // 0x4fdeec: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fdeec: add             x25, x1, #0x13
    //     0x4fdef0: str             w0, [x25]
    //     0x4fdef4: tbz             w0, #0, #0x4fdf10
    //     0x4fdef8: ldurb           w16, [x1, #-1]
    //     0x4fdefc: ldurb           w17, [x0, #-1]
    //     0x4fdf00: and             x16, x17, x16, lsr #2
    //     0x4fdf04: tst             x16, HEAP, lsr #32
    //     0x4fdf08: b.eq            #0x4fdf10
    //     0x4fdf0c: bl              #0xd67e5c
    // 0x4fdf10: ldur            x0, [fp, #-8]
    // 0x4fdf14: r17 = ")"
    //     0x4fdf14: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0x4fdf18: StoreField: r0->field_17 = r17
    //     0x4fdf18: stur            w17, [x0, #0x17]
    // 0x4fdf1c: SaveReg r0
    //     0x4fdf1c: str             x0, [SP, #-8]!
    // 0x4fdf20: r0 = _interpolate()
    //     0x4fdf20: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fdf24: add             SP, SP, #8
    // 0x4fdf28: mov             x1, x0
    // 0x4fdf2c: ldur            x0, [fp, #-0x58]
    // 0x4fdf30: stur            x1, [fp, #-0x28]
    // 0x4fdf34: LoadField: r2 = r0->field_b
    //     0x4fdf34: ldur            w2, [x0, #0xb]
    // 0x4fdf38: DecompressPointer r2
    //     0x4fdf38: add             x2, x2, HEAP, lsl #32
    // 0x4fdf3c: stur            x2, [fp, #-8]
    // 0x4fdf40: LoadField: r3 = r0->field_f
    //     0x4fdf40: ldur            w3, [x0, #0xf]
    // 0x4fdf44: DecompressPointer r3
    //     0x4fdf44: add             x3, x3, HEAP, lsl #32
    // 0x4fdf48: LoadField: r4 = r3->field_b
    //     0x4fdf48: ldur            w4, [x3, #0xb]
    // 0x4fdf4c: DecompressPointer r4
    //     0x4fdf4c: add             x4, x4, HEAP, lsl #32
    // 0x4fdf50: cmp             w2, w4
    // 0x4fdf54: b.ne            #0x4fdf64
    // 0x4fdf58: SaveReg r0
    //     0x4fdf58: str             x0, [SP, #-8]!
    // 0x4fdf5c: r0 = _growToNextCapacity()
    //     0x4fdf5c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4fdf60: add             SP, SP, #8
    // 0x4fdf64: ldur            x3, [fp, #-0x58]
    // 0x4fdf68: ldur            x0, [fp, #-8]
    // 0x4fdf6c: r2 = LoadInt32Instr(r0)
    //     0x4fdf6c: sbfx            x2, x0, #1, #0x1f
    // 0x4fdf70: add             x0, x2, #1
    // 0x4fdf74: lsl             x1, x0, #1
    // 0x4fdf78: StoreField: r3->field_b = r1
    //     0x4fdf78: stur            w1, [x3, #0xb]
    // 0x4fdf7c: mov             x1, x2
    // 0x4fdf80: cmp             x1, x0
    // 0x4fdf84: b.hs            #0x4fe408
    // 0x4fdf88: LoadField: r1 = r3->field_f
    //     0x4fdf88: ldur            w1, [x3, #0xf]
    // 0x4fdf8c: DecompressPointer r1
    //     0x4fdf8c: add             x1, x1, HEAP, lsl #32
    // 0x4fdf90: ldur            x0, [fp, #-0x28]
    // 0x4fdf94: ArrayStore: r1[r2] = r0  ; List_4
    //     0x4fdf94: add             x25, x1, x2, lsl #2
    //     0x4fdf98: add             x25, x25, #0xf
    //     0x4fdf9c: str             w0, [x25]
    //     0x4fdfa0: tbz             w0, #0, #0x4fdfbc
    //     0x4fdfa4: ldurb           w16, [x1, #-1]
    //     0x4fdfa8: ldurb           w17, [x0, #-1]
    //     0x4fdfac: and             x16, x17, x16, lsr #2
    //     0x4fdfb0: tst             x16, HEAP, lsr #32
    //     0x4fdfb4: b.eq            #0x4fdfbc
    //     0x4fdfb8: bl              #0xd67e5c
    // 0x4fdfbc: mov             x2, x3
    // 0x4fdfc0: b               #0x4fe338
    // 0x4fdfc4: ldur            x3, [fp, #-0x58]
    // 0x4fdfc8: cmp             x0, #1
    // 0x4fdfcc: b.le            #0x4fe334
    // 0x4fdfd0: ldur            x4, [fp, #-0x20]
    // 0x4fdfd4: LoadField: r1 = r4->field_b
    //     0x4fdfd4: ldur            w1, [x4, #0xb]
    // 0x4fdfd8: DecompressPointer r1
    //     0x4fdfd8: add             x1, x1, HEAP, lsl #32
    // 0x4fdfdc: r2 = LoadInt32Instr(r1)
    //     0x4fdfdc: sbfx            x2, x1, #1, #0x1f
    // 0x4fdfe0: cmp             x2, #1
    // 0x4fdfe4: b.le            #0x4fe0b0
    // 0x4fdfe8: sub             x5, x2, #1
    // 0x4fdfec: stur            x5, [fp, #-0x18]
    // 0x4fdff0: r1 = Null
    //     0x4fdff0: mov             x1, NULL
    // 0x4fdff4: r2 = 4
    //     0x4fdff4: mov             x2, #4
    // 0x4fdff8: r0 = AllocateArray()
    //     0x4fdff8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fdffc: stur            x0, [fp, #-8]
    // 0x4fe000: r17 = "and "
    //     0x4fe000: ldr             x17, [PP, #0x1078]  ; [pp+0x1078] "and "
    // 0x4fe004: StoreField: r0->field_f = r17
    //     0x4fe004: stur            w17, [x0, #0xf]
    // 0x4fe008: ldur            x16, [fp, #-0x20]
    // 0x4fe00c: SaveReg r16
    //     0x4fe00c: str             x16, [SP, #-8]!
    // 0x4fe010: r0 = last()
    //     0x4fe010: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x4fe014: add             SP, SP, #8
    // 0x4fe018: ldur            x1, [fp, #-8]
    // 0x4fe01c: ArrayStore: r1[1] = r0  ; List_4
    //     0x4fe01c: add             x25, x1, #0x13
    //     0x4fe020: str             w0, [x25]
    //     0x4fe024: tbz             w0, #0, #0x4fe040
    //     0x4fe028: ldurb           w16, [x1, #-1]
    //     0x4fe02c: ldurb           w17, [x0, #-1]
    //     0x4fe030: and             x16, x17, x16, lsr #2
    //     0x4fe034: tst             x16, HEAP, lsr #32
    //     0x4fe038: b.eq            #0x4fe040
    //     0x4fe03c: bl              #0xd67e5c
    // 0x4fe040: ldur            x16, [fp, #-8]
    // 0x4fe044: SaveReg r16
    //     0x4fe044: str             x16, [SP, #-8]!
    // 0x4fe048: r0 = _interpolate()
    //     0x4fe048: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fe04c: add             SP, SP, #8
    // 0x4fe050: mov             x2, x0
    // 0x4fe054: ldur            x3, [fp, #-0x20]
    // 0x4fe058: LoadField: r4 = r3->field_b
    //     0x4fe058: ldur            w4, [x3, #0xb]
    // 0x4fe05c: DecompressPointer r4
    //     0x4fe05c: add             x4, x4, HEAP, lsl #32
    // 0x4fe060: r0 = LoadInt32Instr(r4)
    //     0x4fe060: sbfx            x0, x4, #1, #0x1f
    // 0x4fe064: ldur            x1, [fp, #-0x18]
    // 0x4fe068: cmp             x1, x0
    // 0x4fe06c: b.hs            #0x4fe40c
    // 0x4fe070: LoadField: r1 = r3->field_f
    //     0x4fe070: ldur            w1, [x3, #0xf]
    // 0x4fe074: DecompressPointer r1
    //     0x4fe074: add             x1, x1, HEAP, lsl #32
    // 0x4fe078: mov             x0, x2
    // 0x4fe07c: ldur            x2, [fp, #-0x18]
    // 0x4fe080: ArrayStore: r1[r2] = r0  ; List_4
    //     0x4fe080: add             x25, x1, x2, lsl #2
    //     0x4fe084: add             x25, x25, #0xf
    //     0x4fe088: str             w0, [x25]
    //     0x4fe08c: tbz             w0, #0, #0x4fe0a8
    //     0x4fe090: ldurb           w16, [x1, #-1]
    //     0x4fe094: ldurb           w17, [x0, #-1]
    //     0x4fe098: and             x16, x17, x16, lsr #2
    //     0x4fe09c: tst             x16, HEAP, lsr #32
    //     0x4fe0a0: b.eq            #0x4fe0a8
    //     0x4fe0a4: bl              #0xd67e5c
    // 0x4fe0a8: r0 = LoadInt32Instr(r4)
    //     0x4fe0a8: sbfx            x0, x4, #1, #0x1f
    // 0x4fe0ac: b               #0x4fe0b8
    // 0x4fe0b0: mov             x3, x4
    // 0x4fe0b4: r0 = LoadInt32Instr(r1)
    //     0x4fe0b4: sbfx            x0, x1, #1, #0x1f
    // 0x4fe0b8: cmp             x0, #2
    // 0x4fe0bc: b.le            #0x4fe1fc
    // 0x4fe0c0: ldur            x0, [fp, #-0x10]
    // 0x4fe0c4: ldur            x4, [fp, #-0x58]
    // 0x4fe0c8: r1 = Null
    //     0x4fe0c8: mov             x1, NULL
    // 0x4fe0cc: r2 = 10
    //     0x4fe0cc: mov             x2, #0xa
    // 0x4fe0d0: r0 = AllocateArray()
    //     0x4fe0d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fe0d4: mov             x2, x0
    // 0x4fe0d8: stur            x2, [fp, #-8]
    // 0x4fe0dc: r17 = "(elided "
    //     0x4fe0dc: ldr             x17, [PP, #0x1080]  ; [pp+0x1080] "(elided "
    // 0x4fe0e0: StoreField: r2->field_f = r17
    //     0x4fe0e0: stur            w17, [x2, #0xf]
    // 0x4fe0e4: ldur            x3, [fp, #-0x10]
    // 0x4fe0e8: r0 = BoxInt64Instr(r3)
    //     0x4fe0e8: sbfiz           x0, x3, #1, #0x1f
    //     0x4fe0ec: cmp             x3, x0, asr #1
    //     0x4fe0f0: b.eq            #0x4fe0fc
    //     0x4fe0f4: bl              #0xd69bb8
    //     0x4fe0f8: stur            x3, [x0, #7]
    // 0x4fe0fc: StoreField: r2->field_13 = r0
    //     0x4fe0fc: stur            w0, [x2, #0x13]
    // 0x4fe100: r17 = " frames from "
    //     0x4fe100: ldr             x17, [PP, #0x1088]  ; [pp+0x1088] " frames from "
    // 0x4fe104: StoreField: r2->field_17 = r17
    //     0x4fe104: stur            w17, [x2, #0x17]
    // 0x4fe108: ldur            x16, [fp, #-0x20]
    // 0x4fe10c: r30 = ", "
    //     0x4fe10c: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0x4fe110: stp             lr, x16, [SP, #-0x10]!
    // 0x4fe114: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fe114: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fe118: r0 = join()
    //     0x4fe118: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0x4fe11c: add             SP, SP, #0x10
    // 0x4fe120: ldur            x1, [fp, #-8]
    // 0x4fe124: ArrayStore: r1[3] = r0  ; List_4
    //     0x4fe124: add             x25, x1, #0x1b
    //     0x4fe128: str             w0, [x25]
    //     0x4fe12c: tbz             w0, #0, #0x4fe148
    //     0x4fe130: ldurb           w16, [x1, #-1]
    //     0x4fe134: ldurb           w17, [x0, #-1]
    //     0x4fe138: and             x16, x17, x16, lsr #2
    //     0x4fe13c: tst             x16, HEAP, lsr #32
    //     0x4fe140: b.eq            #0x4fe148
    //     0x4fe144: bl              #0xd67e5c
    // 0x4fe148: ldur            x0, [fp, #-8]
    // 0x4fe14c: r17 = ")"
    //     0x4fe14c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0x4fe150: StoreField: r0->field_1f = r17
    //     0x4fe150: stur            w17, [x0, #0x1f]
    // 0x4fe154: SaveReg r0
    //     0x4fe154: str             x0, [SP, #-8]!
    // 0x4fe158: r0 = _interpolate()
    //     0x4fe158: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fe15c: add             SP, SP, #8
    // 0x4fe160: mov             x1, x0
    // 0x4fe164: ldur            x0, [fp, #-0x58]
    // 0x4fe168: stur            x1, [fp, #-0x28]
    // 0x4fe16c: LoadField: r2 = r0->field_b
    //     0x4fe16c: ldur            w2, [x0, #0xb]
    // 0x4fe170: DecompressPointer r2
    //     0x4fe170: add             x2, x2, HEAP, lsl #32
    // 0x4fe174: stur            x2, [fp, #-8]
    // 0x4fe178: LoadField: r3 = r0->field_f
    //     0x4fe178: ldur            w3, [x0, #0xf]
    // 0x4fe17c: DecompressPointer r3
    //     0x4fe17c: add             x3, x3, HEAP, lsl #32
    // 0x4fe180: LoadField: r4 = r3->field_b
    //     0x4fe180: ldur            w4, [x3, #0xb]
    // 0x4fe184: DecompressPointer r4
    //     0x4fe184: add             x4, x4, HEAP, lsl #32
    // 0x4fe188: cmp             w2, w4
    // 0x4fe18c: b.ne            #0x4fe19c
    // 0x4fe190: SaveReg r0
    //     0x4fe190: str             x0, [SP, #-8]!
    // 0x4fe194: r0 = _growToNextCapacity()
    //     0x4fe194: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4fe198: add             SP, SP, #8
    // 0x4fe19c: ldur            x4, [fp, #-0x58]
    // 0x4fe1a0: ldur            x0, [fp, #-8]
    // 0x4fe1a4: r2 = LoadInt32Instr(r0)
    //     0x4fe1a4: sbfx            x2, x0, #1, #0x1f
    // 0x4fe1a8: add             x0, x2, #1
    // 0x4fe1ac: lsl             x1, x0, #1
    // 0x4fe1b0: StoreField: r4->field_b = r1
    //     0x4fe1b0: stur            w1, [x4, #0xb]
    // 0x4fe1b4: mov             x1, x2
    // 0x4fe1b8: cmp             x1, x0
    // 0x4fe1bc: b.hs            #0x4fe410
    // 0x4fe1c0: LoadField: r1 = r4->field_f
    //     0x4fe1c0: ldur            w1, [x4, #0xf]
    // 0x4fe1c4: DecompressPointer r1
    //     0x4fe1c4: add             x1, x1, HEAP, lsl #32
    // 0x4fe1c8: ldur            x0, [fp, #-0x28]
    // 0x4fe1cc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x4fe1cc: add             x25, x1, x2, lsl #2
    //     0x4fe1d0: add             x25, x25, #0xf
    //     0x4fe1d4: str             w0, [x25]
    //     0x4fe1d8: tbz             w0, #0, #0x4fe1f4
    //     0x4fe1dc: ldurb           w16, [x1, #-1]
    //     0x4fe1e0: ldurb           w17, [x0, #-1]
    //     0x4fe1e4: and             x16, x17, x16, lsr #2
    //     0x4fe1e8: tst             x16, HEAP, lsr #32
    //     0x4fe1ec: b.eq            #0x4fe1f4
    //     0x4fe1f0: bl              #0xd67e5c
    // 0x4fe1f4: mov             x2, x4
    // 0x4fe1f8: b               #0x4fe338
    // 0x4fe1fc: ldur            x3, [fp, #-0x10]
    // 0x4fe200: ldur            x4, [fp, #-0x58]
    // 0x4fe204: r1 = Null
    //     0x4fe204: mov             x1, NULL
    // 0x4fe208: r2 = 10
    //     0x4fe208: mov             x2, #0xa
    // 0x4fe20c: r0 = AllocateArray()
    //     0x4fe20c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4fe210: mov             x2, x0
    // 0x4fe214: stur            x2, [fp, #-8]
    // 0x4fe218: r17 = "(elided "
    //     0x4fe218: ldr             x17, [PP, #0x1080]  ; [pp+0x1080] "(elided "
    // 0x4fe21c: StoreField: r2->field_f = r17
    //     0x4fe21c: stur            w17, [x2, #0xf]
    // 0x4fe220: ldur            x3, [fp, #-0x10]
    // 0x4fe224: r0 = BoxInt64Instr(r3)
    //     0x4fe224: sbfiz           x0, x3, #1, #0x1f
    //     0x4fe228: cmp             x3, x0, asr #1
    //     0x4fe22c: b.eq            #0x4fe238
    //     0x4fe230: bl              #0xd69bb8
    //     0x4fe234: stur            x3, [x0, #7]
    // 0x4fe238: StoreField: r2->field_13 = r0
    //     0x4fe238: stur            w0, [x2, #0x13]
    // 0x4fe23c: r17 = " frames from "
    //     0x4fe23c: ldr             x17, [PP, #0x1088]  ; [pp+0x1088] " frames from "
    // 0x4fe240: StoreField: r2->field_17 = r17
    //     0x4fe240: stur            w17, [x2, #0x17]
    // 0x4fe244: ldur            x16, [fp, #-0x20]
    // 0x4fe248: r30 = " "
    //     0x4fe248: ldr             lr, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x4fe24c: stp             lr, x16, [SP, #-0x10]!
    // 0x4fe250: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fe250: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fe254: r0 = join()
    //     0x4fe254: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0x4fe258: add             SP, SP, #0x10
    // 0x4fe25c: ldur            x1, [fp, #-8]
    // 0x4fe260: ArrayStore: r1[3] = r0  ; List_4
    //     0x4fe260: add             x25, x1, #0x1b
    //     0x4fe264: str             w0, [x25]
    //     0x4fe268: tbz             w0, #0, #0x4fe284
    //     0x4fe26c: ldurb           w16, [x1, #-1]
    //     0x4fe270: ldurb           w17, [x0, #-1]
    //     0x4fe274: and             x16, x17, x16, lsr #2
    //     0x4fe278: tst             x16, HEAP, lsr #32
    //     0x4fe27c: b.eq            #0x4fe284
    //     0x4fe280: bl              #0xd67e5c
    // 0x4fe284: ldur            x0, [fp, #-8]
    // 0x4fe288: r17 = ")"
    //     0x4fe288: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0x4fe28c: StoreField: r0->field_1f = r17
    //     0x4fe28c: stur            w17, [x0, #0x1f]
    // 0x4fe290: SaveReg r0
    //     0x4fe290: str             x0, [SP, #-8]!
    // 0x4fe294: r0 = _interpolate()
    //     0x4fe294: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4fe298: add             SP, SP, #8
    // 0x4fe29c: mov             x1, x0
    // 0x4fe2a0: ldur            x0, [fp, #-0x58]
    // 0x4fe2a4: stur            x1, [fp, #-0x20]
    // 0x4fe2a8: LoadField: r2 = r0->field_b
    //     0x4fe2a8: ldur            w2, [x0, #0xb]
    // 0x4fe2ac: DecompressPointer r2
    //     0x4fe2ac: add             x2, x2, HEAP, lsl #32
    // 0x4fe2b0: stur            x2, [fp, #-8]
    // 0x4fe2b4: LoadField: r3 = r0->field_f
    //     0x4fe2b4: ldur            w3, [x0, #0xf]
    // 0x4fe2b8: DecompressPointer r3
    //     0x4fe2b8: add             x3, x3, HEAP, lsl #32
    // 0x4fe2bc: LoadField: r4 = r3->field_b
    //     0x4fe2bc: ldur            w4, [x3, #0xb]
    // 0x4fe2c0: DecompressPointer r4
    //     0x4fe2c0: add             x4, x4, HEAP, lsl #32
    // 0x4fe2c4: cmp             w2, w4
    // 0x4fe2c8: b.ne            #0x4fe2d8
    // 0x4fe2cc: SaveReg r0
    //     0x4fe2cc: str             x0, [SP, #-8]!
    // 0x4fe2d0: r0 = _growToNextCapacity()
    //     0x4fe2d0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x4fe2d4: add             SP, SP, #8
    // 0x4fe2d8: ldur            x2, [fp, #-0x58]
    // 0x4fe2dc: ldur            x0, [fp, #-8]
    // 0x4fe2e0: r3 = LoadInt32Instr(r0)
    //     0x4fe2e0: sbfx            x3, x0, #1, #0x1f
    // 0x4fe2e4: add             x0, x3, #1
    // 0x4fe2e8: lsl             x1, x0, #1
    // 0x4fe2ec: StoreField: r2->field_b = r1
    //     0x4fe2ec: stur            w1, [x2, #0xb]
    // 0x4fe2f0: mov             x1, x3
    // 0x4fe2f4: cmp             x1, x0
    // 0x4fe2f8: b.hs            #0x4fe414
    // 0x4fe2fc: LoadField: r1 = r2->field_f
    //     0x4fe2fc: ldur            w1, [x2, #0xf]
    // 0x4fe300: DecompressPointer r1
    //     0x4fe300: add             x1, x1, HEAP, lsl #32
    // 0x4fe304: ldur            x0, [fp, #-0x20]
    // 0x4fe308: ArrayStore: r1[r3] = r0  ; List_4
    //     0x4fe308: add             x25, x1, x3, lsl #2
    //     0x4fe30c: add             x25, x25, #0xf
    //     0x4fe310: str             w0, [x25]
    //     0x4fe314: tbz             w0, #0, #0x4fe330
    //     0x4fe318: ldurb           w16, [x1, #-1]
    //     0x4fe31c: ldurb           w17, [x0, #-1]
    //     0x4fe320: and             x16, x17, x16, lsr #2
    //     0x4fe324: tst             x16, HEAP, lsr #32
    //     0x4fe328: b.eq            #0x4fe330
    //     0x4fe32c: bl              #0xd67e5c
    // 0x4fe330: b               #0x4fe338
    // 0x4fe334: mov             x2, x3
    // 0x4fe338: mov             x0, x2
    // 0x4fe33c: LeaveFrame
    //     0x4fe33c: mov             SP, fp
    //     0x4fe340: ldp             fp, lr, [SP], #0x10
    // 0x4fe344: ret
    //     0x4fe344: ret             
    // 0x4fe348: r1 = LoadClassIdInstr(r0)
    //     0x4fe348: ldur            x1, [x0, #-1]
    //     0x4fe34c: ubfx            x1, x1, #0xc, #0x14
    // 0x4fe350: stp             xzr, x0, [SP, #-0x10]!
    // 0x4fe354: mov             x0, x1
    // 0x4fe358: r0 = GDT[cid_x0 + 0xd175]()
    //     0x4fe358: mov             x17, #0xd175
    //     0x4fe35c: add             lr, x0, x17
    //     0x4fe360: ldr             lr, [x21, lr, lsl #3]
    //     0x4fe364: blr             lr
    // 0x4fe368: add             SP, SP, #0x10
    // 0x4fe36c: cmp             w0, NULL
    // 0x4fe370: b.ne            #0x4fe3c0
    // 0x4fe374: b               #0x4fe398
    // 0x4fe378: ldur            x0, [fp, #-0x48]
    // 0x4fe37c: r0 = ConcurrentModificationError()
    //     0x4fe37c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x4fe380: mov             x1, x0
    // 0x4fe384: ldur            x0, [fp, #-0x48]
    // 0x4fe388: StoreField: r1->field_b = r0
    //     0x4fe388: stur            w0, [x1, #0xb]
    // 0x4fe38c: mov             x0, x1
    // 0x4fe390: r0 = Throw()
    //     0x4fe390: bl              #0xd67e38  ; ThrowStub
    // 0x4fe394: brk             #0
    // 0x4fe398: ldur            x2, [fp, #-0x38]
    // 0x4fe39c: r1 = Null
    //     0x4fe39c: mov             x1, NULL
    // 0x4fe3a0: cmp             w2, NULL
    // 0x4fe3a4: b.eq            #0x4fe3c0
    // 0x4fe3a8: LoadField: r4 = r2->field_17
    //     0x4fe3a8: ldur            w4, [x2, #0x17]
    // 0x4fe3ac: DecompressPointer r4
    //     0x4fe3ac: add             x4, x4, HEAP, lsl #32
    // 0x4fe3b0: r8 = X0
    //     0x4fe3b0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x4fe3b4: LoadField: r9 = r4->field_7
    //     0x4fe3b4: ldur            x9, [x4, #7]
    // 0x4fe3b8: r3 = Null
    //     0x4fe3b8: ldr             x3, [PP, #0x10a0]  ; [pp+0x10a0] Null
    // 0x4fe3bc: blr             x9
    // 0x4fe3c0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x4fe3c0: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x4fe3c4: r0 = Throw()
    //     0x4fe3c4: bl              #0xd67e38  ; ThrowStub
    // 0x4fe3c8: brk             #0
    // 0x4fe3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe3cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe3d0: b               #0x4fd510
    // 0x4fe3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe3d8: b               #0x4fd5f8
    // 0x4fe3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe3dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe3e0: b               #0x4fd978
    // 0x4fe3e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe3e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe3e8: b               #0x4fd9c4
    // 0x4fe3ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe3ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fe3f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe3f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fe3f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe3f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fe3f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe3f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fe3fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe3fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe400: b               #0x4fdca8
    // 0x4fe404: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe404: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fe408: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe408: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fe40c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe40c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fe410: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe410: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fe414: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fe414: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static List<StackFilter> _stackFilters() {
    // ** addr: 0x4ff340, size: 0x38
    // 0x4ff340: EnterFrame
    //     0x4ff340: stp             fp, lr, [SP, #-0x10]!
    //     0x4ff344: mov             fp, SP
    // 0x4ff348: CheckStackOverflow
    //     0x4ff348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ff34c: cmp             SP, x16
    //     0x4ff350: b.ls            #0x4ff370
    // 0x4ff354: r16 = <StackFilter>
    //     0x4ff354: ldr             x16, [PP, #0x16c8]  ; [pp+0x16c8] TypeArguments: <StackFilter>
    // 0x4ff358: stp             xzr, x16, [SP, #-0x10]!
    // 0x4ff35c: r0 = _GrowableList()
    //     0x4ff35c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x4ff360: add             SP, SP, #0x10
    // 0x4ff364: LeaveFrame
    //     0x4ff364: mov             SP, fp
    //     0x4ff368: ldp             fp, lr, [SP], #0x10
    // 0x4ff36c: ret
    //     0x4ff36c: ret             
    // 0x4ff370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ff370: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ff374: b               #0x4ff354
  }
  [closure] static int <anonymous closure>(dynamic, int) {
    // ** addr: 0x4ff394, size: 0x3c
    // 0x4ff394: EnterFrame
    //     0x4ff394: stp             fp, lr, [SP, #-0x10]!
    //     0x4ff398: mov             fp, SP
    // 0x4ff39c: ldr             x2, [fp, #0x10]
    // 0x4ff3a0: r3 = LoadInt32Instr(r2)
    //     0x4ff3a0: sbfx            x3, x2, #1, #0x1f
    //     0x4ff3a4: tbz             w2, #0, #0x4ff3ac
    //     0x4ff3a8: ldur            x3, [x2, #7]
    // 0x4ff3ac: add             x2, x3, #1
    // 0x4ff3b0: r0 = BoxInt64Instr(r2)
    //     0x4ff3b0: sbfiz           x0, x2, #1, #0x1f
    //     0x4ff3b4: cmp             x2, x0, asr #1
    //     0x4ff3b8: b.eq            #0x4ff3c4
    //     0x4ff3bc: bl              #0xd69bb8
    //     0x4ff3c0: stur            x2, [x0, #7]
    // 0x4ff3c4: LeaveFrame
    //     0x4ff3c4: mov             SP, fp
    //     0x4ff3c8: ldp             fp, lr, [SP], #0x10
    // 0x4ff3cc: ret
    //     0x4ff3cc: ret             
  }
  static (dynamic, StackTrace) => StackTrace demangleStackTrace() {
    // ** addr: 0x4ff44c, size: 0x8
    // 0x4ff44c: r0 = Closure: (StackTrace) => StackTrace from Function '_defaultStackTraceDemangler@627022608': static.
    //     0x4ff44c: ldr             x0, [PP, #0x16f8]  ; [pp+0x16f8] Closure: (StackTrace) => StackTrace from Function '_defaultStackTraceDemangler@627022608': static. (0x7fe6e25677cc)
    // 0x4ff450: ret
    //     0x4ff450: ret             
  }
  factory _ FlutterError(/* No info */) {
    // ** addr: 0x59ef18, size: 0x128
    // 0x59ef18: EnterFrame
    //     0x59ef18: stp             fp, lr, [SP, #-0x10]!
    //     0x59ef1c: mov             fp, SP
    // 0x59ef20: AllocStack(0x18)
    //     0x59ef20: sub             SP, SP, #0x18
    // 0x59ef24: CheckStackOverflow
    //     0x59ef24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59ef28: cmp             SP, x16
    //     0x59ef2c: b.ls            #0x59f038
    // 0x59ef30: ldr             x0, [fp, #0x10]
    // 0x59ef34: r1 = LoadClassIdInstr(r0)
    //     0x59ef34: ldur            x1, [x0, #-1]
    //     0x59ef38: ubfx            x1, x1, #0xc, #0x14
    // 0x59ef3c: r16 = "\n"
    //     0x59ef3c: ldr             x16, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x59ef40: stp             x16, x0, [SP, #-0x10]!
    // 0x59ef44: mov             x0, x1
    // 0x59ef48: r0 = GDT[cid_x0 + -0xff8]()
    //     0x59ef48: sub             lr, x0, #0xff8
    //     0x59ef4c: ldr             lr, [x21, lr, lsl #3]
    //     0x59ef50: blr             lr
    // 0x59ef54: add             SP, SP, #0x10
    // 0x59ef58: stur            x0, [fp, #-8]
    // 0x59ef5c: SaveReg r0
    //     0x59ef5c: str             x0, [SP, #-8]!
    // 0x59ef60: r0 = first()
    //     0x59ef60: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x59ef64: add             SP, SP, #8
    // 0x59ef68: r1 = <List<Object>>
    //     0x59ef68: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x59ef6c: stur            x0, [fp, #-0x10]
    // 0x59ef70: r0 = ErrorSummary()
    //     0x59ef70: bl              #0x59f04c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x30)
    // 0x59ef74: stur            x0, [fp, #-0x18]
    // 0x59ef78: ldur            x16, [fp, #-0x10]
    // 0x59ef7c: stp             x16, x0, [SP, #-0x10]!
    // 0x59ef80: r16 = Instance_DiagnosticLevel
    //     0x59ef80: ldr             x16, [PP, #0x43f0]  ; [pp+0x43f0] Obj!DiagnosticLevel@b65db1
    // 0x59ef84: SaveReg r16
    //     0x59ef84: str             x16, [SP, #-8]!
    // 0x59ef88: r0 = _ErrorDiagnostic()
    //     0x59ef88: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x59ef8c: add             SP, SP, #0x18
    // 0x59ef90: r1 = Null
    //     0x59ef90: mov             x1, NULL
    // 0x59ef94: r2 = 2
    //     0x59ef94: mov             x2, #2
    // 0x59ef98: r0 = AllocateArray()
    //     0x59ef98: bl              #0xd6987c  ; AllocateArrayStub
    // 0x59ef9c: mov             x2, x0
    // 0x59efa0: ldur            x0, [fp, #-0x18]
    // 0x59efa4: stur            x2, [fp, #-0x10]
    // 0x59efa8: StoreField: r2->field_f = r0
    //     0x59efa8: stur            w0, [x2, #0xf]
    // 0x59efac: r1 = <DiagnosticsNode>
    //     0x59efac: ldr             x1, [PP, #0x3930]  ; [pp+0x3930] TypeArguments: <DiagnosticsNode>
    // 0x59efb0: r0 = AllocateGrowableArray()
    //     0x59efb0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x59efb4: mov             x1, x0
    // 0x59efb8: ldur            x0, [fp, #-0x10]
    // 0x59efbc: stur            x1, [fp, #-0x18]
    // 0x59efc0: StoreField: r1->field_f = r0
    //     0x59efc0: stur            w0, [x1, #0xf]
    // 0x59efc4: r0 = 2
    //     0x59efc4: mov             x0, #2
    // 0x59efc8: StoreField: r1->field_b = r0
    //     0x59efc8: stur            w0, [x1, #0xb]
    // 0x59efcc: ldur            x16, [fp, #-8]
    // 0x59efd0: SaveReg r16
    //     0x59efd0: str             x16, [SP, #-8]!
    // 0x59efd4: r0 = 1
    //     0x59efd4: mov             x0, #1
    // 0x59efd8: SaveReg r0
    //     0x59efd8: str             x0, [SP, #-8]!
    // 0x59efdc: r0 = skip()
    //     0x59efdc: bl              #0x7118b4  ; [dart:collection] _ListBase&Object&ListMixin::skip
    // 0x59efe0: add             SP, SP, #0x10
    // 0x59efe4: r1 = Function '<anonymous closure>': static.
    //     0x59efe4: ldr             x1, [PP, #0x43f8]  ; [pp+0x43f8] AnonymousClosure: static (0x59f058), in [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError (0x59ef18)
    // 0x59efe8: r2 = Null
    //     0x59efe8: mov             x2, NULL
    // 0x59efec: stur            x0, [fp, #-8]
    // 0x59eff0: r0 = AllocateClosure()
    //     0x59eff0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x59eff4: r16 = <DiagnosticsNode>
    //     0x59eff4: ldr             x16, [PP, #0x3930]  ; [pp+0x3930] TypeArguments: <DiagnosticsNode>
    // 0x59eff8: ldur            lr, [fp, #-8]
    // 0x59effc: stp             lr, x16, [SP, #-0x10]!
    // 0x59f000: SaveReg r0
    //     0x59f000: str             x0, [SP, #-8]!
    // 0x59f004: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x59f004: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x59f008: r0 = map()
    //     0x59f008: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x59f00c: add             SP, SP, #0x18
    // 0x59f010: ldur            x16, [fp, #-0x18]
    // 0x59f014: stp             x0, x16, [SP, #-0x10]!
    // 0x59f018: r0 = addAll()
    //     0x59f018: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x59f01c: add             SP, SP, #0x10
    // 0x59f020: r0 = FlutterError()
    //     0x59f020: bl              #0x59f040  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0x59f024: ldur            x1, [fp, #-0x18]
    // 0x59f028: StoreField: r0->field_b = r1
    //     0x59f028: stur            w1, [x0, #0xb]
    // 0x59f02c: LeaveFrame
    //     0x59f02c: mov             SP, fp
    //     0x59f030: ldp             fp, lr, [SP], #0x10
    // 0x59f034: ret
    //     0x59f034: ret             
    // 0x59f038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59f038: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59f03c: b               #0x59ef30
  }
  [closure] static ErrorDescription <anonymous closure>(dynamic, String) {
    // ** addr: 0x59f058, size: 0x54
    // 0x59f058: EnterFrame
    //     0x59f058: stp             fp, lr, [SP, #-0x10]!
    //     0x59f05c: mov             fp, SP
    // 0x59f060: AllocStack(0x8)
    //     0x59f060: sub             SP, SP, #8
    // 0x59f064: CheckStackOverflow
    //     0x59f064: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59f068: cmp             SP, x16
    //     0x59f06c: b.ls            #0x59f0a4
    // 0x59f070: r1 = <List<Object>>
    //     0x59f070: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x59f074: r0 = ErrorDescription()
    //     0x59f074: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x59f078: stur            x0, [fp, #-8]
    // 0x59f07c: ldr             x16, [fp, #0x10]
    // 0x59f080: stp             x16, x0, [SP, #-0x10]!
    // 0x59f084: r16 = Instance_DiagnosticLevel
    //     0x59f084: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x59f088: SaveReg r16
    //     0x59f088: str             x16, [SP, #-8]!
    // 0x59f08c: r0 = _ErrorDiagnostic()
    //     0x59f08c: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x59f090: add             SP, SP, #0x18
    // 0x59f094: ldur            x0, [fp, #-8]
    // 0x59f098: LeaveFrame
    //     0x59f098: mov             SP, fp
    //     0x59f09c: ldp             fp, lr, [SP], #0x10
    // 0x59f0a0: ret
    //     0x59f0a0: ret             
    // 0x59f0a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59f0a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59f0a8: b               #0x59f070
  }
  _ toStringShort(/* No info */) {
    // ** addr: 0xa5d818, size: 0x8
    // 0xa5d818: r0 = "FlutterError"
    //     0xa5d818: ldr             x0, [PP, #0x7520]  ; [pp+0x7520] "FlutterError"
    // 0xa5d81c: ret
    //     0xa5d81c: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xab7b78, size: 0x9c
    // 0xab7b78: EnterFrame
    //     0xab7b78: stp             fp, lr, [SP, #-0x10]!
    //     0xab7b7c: mov             fp, SP
    // 0xab7b80: AllocStack(0x8)
    //     0xab7b80: sub             SP, SP, #8
    // 0xab7b84: SetupParameters(FlutterError this /* r1 */)
    //     0xab7b84: mov             x0, x4
    //     0xab7b88: ldur            w1, [x0, #0x13]
    //     0xab7b8c: add             x1, x1, HEAP, lsl #32
    //     0xab7b90: sub             x0, x1, #2
    //     0xab7b94: add             x1, fp, w0, sxtw #2
    //     0xab7b98: ldr             x1, [x1, #0x10]
    // 0xab7b9c: CheckStackOverflow
    //     0xab7b9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xab7ba0: cmp             SP, x16
    //     0xab7ba4: b.ls            #0xab7c0c
    // 0xab7ba8: LoadField: r0 = r1->field_b
    //     0xab7ba8: ldur            w0, [x1, #0xb]
    // 0xab7bac: DecompressPointer r0
    //     0xab7bac: add             x0, x0, HEAP, lsl #32
    // 0xab7bb0: r16 = <_ErrorDiagnostic<List<Object>>>
    //     0xab7bb0: ldr             x16, [PP, #0x7518]  ; [pp+0x7518] TypeArguments: <_ErrorDiagnostic<List<Object>>>
    // 0xab7bb4: stp             x0, x16, [SP, #-0x10]!
    // 0xab7bb8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xab7bb8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xab7bbc: r0 = whereType()
    //     0xab7bbc: bl              #0x6a7924  ; [dart:collection] _ListBase&Object&ListMixin::whereType
    // 0xab7bc0: add             SP, SP, #0x10
    // 0xab7bc4: stur            x0, [fp, #-8]
    // 0xab7bc8: SaveReg r0
    //     0xab7bc8: str             x0, [SP, #-8]!
    // 0xab7bcc: r0 = isEmpty()
    //     0xab7bcc: bl              #0x6ad3f0  ; [dart:core] Iterable::isEmpty
    // 0xab7bd0: add             SP, SP, #8
    // 0xab7bd4: eor             x1, x0, #0x10
    // 0xab7bd8: tbnz            w1, #4, #0xab7bfc
    // 0xab7bdc: ldur            x16, [fp, #-8]
    // 0xab7be0: SaveReg r16
    //     0xab7be0: str             x16, [SP, #-8]!
    // 0xab7be4: r0 = first()
    //     0xab7be4: bl              #0x6b8208  ; [dart:core] Iterable::first
    // 0xab7be8: add             SP, SP, #8
    // 0xab7bec: SaveReg r0
    //     0xab7bec: str             x0, [SP, #-8]!
    // 0xab7bf0: r0 = valueToString()
    //     0xab7bf0: bl              #0xab7c14  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::valueToString
    // 0xab7bf4: add             SP, SP, #8
    // 0xab7bf8: b               #0xab7c00
    // 0xab7bfc: r0 = "FlutterError"
    //     0xab7bfc: ldr             x0, [PP, #0x7520]  ; [pp+0x7520] "FlutterError"
    // 0xab7c00: LeaveFrame
    //     0xab7c00: mov             SP, fp
    //     0xab7c04: ldp             fp, lr, [SP], #0x10
    // 0xab7c08: ret
    //     0xab7c08: ret             
    // 0xab7c0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xab7c0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xab7c10: b               #0xab7ba8
  }
  get _ message(/* No info */) {
    // ** addr: 0xc9d074, size: 0x3c
    // 0xc9d074: EnterFrame
    //     0xc9d074: stp             fp, lr, [SP, #-0x10]!
    //     0xc9d078: mov             fp, SP
    // 0xc9d07c: CheckStackOverflow
    //     0xc9d07c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9d080: cmp             SP, x16
    //     0xc9d084: b.ls            #0xc9d0a8
    // 0xc9d088: ldr             x16, [fp, #0x10]
    // 0xc9d08c: SaveReg r16
    //     0xc9d08c: str             x16, [SP, #-8]!
    // 0xc9d090: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc9d090: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc9d094: r0 = toString()
    //     0xc9d094: bl              #0xab7b78  ; [package:flutter/src/foundation/assertions.dart] FlutterError::toString
    // 0xc9d098: add             SP, SP, #8
    // 0xc9d09c: LeaveFrame
    //     0xc9d09c: mov             SP, fp
    //     0xc9d0a0: ldp             fp, lr, [SP], #0x10
    // 0xc9d0a4: ret
    //     0xc9d0a4: ret             
    // 0xc9d0a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9d0a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9d0ac: b               #0xc9d088
  }
}

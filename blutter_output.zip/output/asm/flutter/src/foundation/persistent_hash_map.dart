// lib: , url: package:flutter/src/foundation/persistent_hash_map.dart

// class id: 1049141, size: 0x8
class :: {
}

// class id: 2372, size: 0x8, field offset: 0x8
abstract class _TrieNode extends Object {
}

// class id: 2373, size: 0x14, field offset: 0x8
class _HashCollisionNode extends _TrieNode {

  _ _indexOf(/* No info */) {
    // ** addr: 0x517d38, size: 0xe8
    // 0x517d38: EnterFrame
    //     0x517d38: stp             fp, lr, [SP, #-0x10]!
    //     0x517d3c: mov             fp, SP
    // 0x517d40: AllocStack(0x18)
    //     0x517d40: sub             SP, SP, #0x18
    // 0x517d44: CheckStackOverflow
    //     0x517d44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x517d48: cmp             SP, x16
    //     0x517d4c: b.ls            #0x517e0c
    // 0x517d50: ldr             x0, [fp, #0x18]
    // 0x517d54: LoadField: r2 = r0->field_f
    //     0x517d54: ldur            w2, [x0, #0xf]
    // 0x517d58: DecompressPointer r2
    //     0x517d58: add             x2, x2, HEAP, lsl #32
    // 0x517d5c: stur            x2, [fp, #-0x18]
    // 0x517d60: LoadField: r0 = r2->field_b
    //     0x517d60: ldur            w0, [x2, #0xb]
    // 0x517d64: DecompressPointer r0
    //     0x517d64: add             x0, x0, HEAP, lsl #32
    // 0x517d68: r3 = LoadInt32Instr(r0)
    //     0x517d68: sbfx            x3, x0, #1, #0x1f
    // 0x517d6c: stur            x3, [fp, #-0x10]
    // 0x517d70: r5 = 0
    //     0x517d70: mov             x5, #0
    // 0x517d74: ldr             x4, [fp, #0x10]
    // 0x517d78: stur            x5, [fp, #-8]
    // 0x517d7c: CheckStackOverflow
    //     0x517d7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x517d80: cmp             SP, x16
    //     0x517d84: b.ls            #0x517e14
    // 0x517d88: cmp             x5, x3
    // 0x517d8c: b.ge            #0x517dfc
    // 0x517d90: mov             x0, x3
    // 0x517d94: mov             x1, x5
    // 0x517d98: cmp             x1, x0
    // 0x517d9c: b.hs            #0x517e1c
    // 0x517da0: ArrayLoad: r0 = r2[r5]  ; Unknown_4
    //     0x517da0: add             x16, x2, x5, lsl #2
    //     0x517da4: ldur            w0, [x16, #0xf]
    // 0x517da8: DecompressPointer r0
    //     0x517da8: add             x0, x0, HEAP, lsl #32
    // 0x517dac: r1 = 59
    //     0x517dac: mov             x1, #0x3b
    // 0x517db0: branchIfSmi(r4, 0x517dbc)
    //     0x517db0: tbz             w4, #0, #0x517dbc
    // 0x517db4: r1 = LoadClassIdInstr(r4)
    //     0x517db4: ldur            x1, [x4, #-1]
    //     0x517db8: ubfx            x1, x1, #0xc, #0x14
    // 0x517dbc: stp             x0, x4, [SP, #-0x10]!
    // 0x517dc0: mov             x0, x1
    // 0x517dc4: mov             lr, x0
    // 0x517dc8: ldr             lr, [x21, lr, lsl #3]
    // 0x517dcc: blr             lr
    // 0x517dd0: add             SP, SP, #0x10
    // 0x517dd4: tbnz            w0, #4, #0x517de8
    // 0x517dd8: ldur            x0, [fp, #-8]
    // 0x517ddc: LeaveFrame
    //     0x517ddc: mov             SP, fp
    //     0x517de0: ldp             fp, lr, [SP], #0x10
    // 0x517de4: ret
    //     0x517de4: ret             
    // 0x517de8: ldur            x1, [fp, #-8]
    // 0x517dec: add             x5, x1, #2
    // 0x517df0: ldur            x2, [fp, #-0x18]
    // 0x517df4: ldur            x3, [fp, #-0x10]
    // 0x517df8: b               #0x517d74
    // 0x517dfc: r0 = -1
    //     0x517dfc: mov             x0, #-1
    // 0x517e00: LeaveFrame
    //     0x517e00: mov             SP, fp
    //     0x517e04: ldp             fp, lr, [SP], #0x10
    // 0x517e08: ret
    //     0x517e08: ret             
    // 0x517e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x517e0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x517e10: b               #0x517d50
    // 0x517e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x517e14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x517e18: b               #0x517d88
    // 0x517e1c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x517e1c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ get(/* No info */) {
    // ** addr: 0xcf5af4, size: 0x84
    // 0xcf5af4: EnterFrame
    //     0xcf5af4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5af8: mov             fp, SP
    // 0xcf5afc: CheckStackOverflow
    //     0xcf5afc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf5b00: cmp             SP, x16
    //     0xcf5b04: b.ls            #0xcf5b6c
    // 0xcf5b08: ldr             x16, [fp, #0x28]
    // 0xcf5b0c: ldr             lr, [fp, #0x18]
    // 0xcf5b10: stp             lr, x16, [SP, #-0x10]!
    // 0xcf5b14: r0 = _indexOf()
    //     0xcf5b14: bl              #0x517d38  ; [package:flutter/src/foundation/persistent_hash_map.dart] _HashCollisionNode::_indexOf
    // 0xcf5b18: add             SP, SP, #0x10
    // 0xcf5b1c: tbz             x0, #0x3f, #0xcf5b28
    // 0xcf5b20: r0 = Null
    //     0xcf5b20: mov             x0, NULL
    // 0xcf5b24: b               #0xcf5b60
    // 0xcf5b28: ldr             x2, [fp, #0x28]
    // 0xcf5b2c: LoadField: r3 = r2->field_f
    //     0xcf5b2c: ldur            w3, [x2, #0xf]
    // 0xcf5b30: DecompressPointer r3
    //     0xcf5b30: add             x3, x3, HEAP, lsl #32
    // 0xcf5b34: add             x2, x0, #1
    // 0xcf5b38: LoadField: r4 = r3->field_b
    //     0xcf5b38: ldur            w4, [x3, #0xb]
    // 0xcf5b3c: DecompressPointer r4
    //     0xcf5b3c: add             x4, x4, HEAP, lsl #32
    // 0xcf5b40: r0 = LoadInt32Instr(r4)
    //     0xcf5b40: sbfx            x0, x4, #1, #0x1f
    // 0xcf5b44: mov             x1, x2
    // 0xcf5b48: cmp             x1, x0
    // 0xcf5b4c: b.hs            #0xcf5b74
    // 0xcf5b50: ArrayLoad: r1 = r3[r2]  ; Unknown_4
    //     0xcf5b50: add             x16, x3, x2, lsl #2
    //     0xcf5b54: ldur            w1, [x16, #0xf]
    // 0xcf5b58: DecompressPointer r1
    //     0xcf5b58: add             x1, x1, HEAP, lsl #32
    // 0xcf5b5c: mov             x0, x1
    // 0xcf5b60: LeaveFrame
    //     0xcf5b60: mov             SP, fp
    //     0xcf5b64: ldp             fp, lr, [SP], #0x10
    // 0xcf5b68: ret
    //     0xcf5b68: ret             
    // 0xcf5b6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5b6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5b70: b               #0xcf5b08
    // 0xcf5b74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf5b74: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  factory _ _HashCollisionNode.fromCollision(/* No info */) {
    // ** addr: 0xcf6b78, size: 0x60
    // 0xcf6b78: EnterFrame
    //     0xcf6b78: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6b7c: mov             fp, SP
    // 0xcf6b80: AllocStack(0x8)
    //     0xcf6b80: sub             SP, SP, #8
    // 0xcf6b84: r1 = <Object?>
    //     0xcf6b84: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf6b88: r2 = 8
    //     0xcf6b88: mov             x2, #8
    // 0xcf6b8c: r0 = AllocateArray()
    //     0xcf6b8c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf6b90: mov             x1, x0
    // 0xcf6b94: ldr             x0, [fp, #0x28]
    // 0xcf6b98: stur            x1, [fp, #-8]
    // 0xcf6b9c: StoreField: r1->field_f = r0
    //     0xcf6b9c: stur            w0, [x1, #0xf]
    // 0xcf6ba0: ldr             x0, [fp, #0x20]
    // 0xcf6ba4: StoreField: r1->field_13 = r0
    //     0xcf6ba4: stur            w0, [x1, #0x13]
    // 0xcf6ba8: ldr             x0, [fp, #0x18]
    // 0xcf6bac: StoreField: r1->field_17 = r0
    //     0xcf6bac: stur            w0, [x1, #0x17]
    // 0xcf6bb0: ldr             x0, [fp, #0x10]
    // 0xcf6bb4: StoreField: r1->field_1b = r0
    //     0xcf6bb4: stur            w0, [x1, #0x1b]
    // 0xcf6bb8: r0 = _HashCollisionNode()
    //     0xcf6bb8: bl              #0xcf6bd8  ; Allocate_HashCollisionNodeStub -> _HashCollisionNode (size=0x14)
    // 0xcf6bbc: ldr             x1, [fp, #0x30]
    // 0xcf6bc0: StoreField: r0->field_7 = r1
    //     0xcf6bc0: stur            x1, [x0, #7]
    // 0xcf6bc4: ldur            x1, [fp, #-8]
    // 0xcf6bc8: StoreField: r0->field_f = r1
    //     0xcf6bc8: stur            w1, [x0, #0xf]
    // 0xcf6bcc: LeaveFrame
    //     0xcf6bcc: mov             SP, fp
    //     0xcf6bd0: ldp             fp, lr, [SP], #0x10
    // 0xcf6bd4: ret
    //     0xcf6bd4: ret             
  }
  _ put(/* No info */) {
    // ** addr: 0xcf6be4, size: 0x33c
    // 0xcf6be4: EnterFrame
    //     0xcf6be4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6be8: mov             fp, SP
    // 0xcf6bec: AllocStack(0x20)
    //     0xcf6bec: sub             SP, SP, #0x20
    // 0xcf6bf0: CheckStackOverflow
    //     0xcf6bf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6bf4: cmp             SP, x16
    //     0xcf6bf8: b.ls            #0xcf6f00
    // 0xcf6bfc: ldr             x0, [fp, #0x30]
    // 0xcf6c00: LoadField: r1 = r0->field_7
    //     0xcf6c00: ldur            x1, [x0, #7]
    // 0xcf6c04: ldr             x2, [fp, #0x18]
    // 0xcf6c08: cmp             x2, x1
    // 0xcf6c0c: b.ne            #0xcf6eb0
    // 0xcf6c10: ldr             x16, [fp, #0x20]
    // 0xcf6c14: stp             x16, x0, [SP, #-0x10]!
    // 0xcf6c18: r0 = _indexOf()
    //     0xcf6c18: bl              #0x517d38  ; [package:flutter/src/foundation/persistent_hash_map.dart] _HashCollisionNode::_indexOf
    // 0xcf6c1c: add             SP, SP, #0x10
    // 0xcf6c20: cmn             x0, #1
    // 0xcf6c24: b.eq            #0xcf6d6c
    // 0xcf6c28: ldr             x2, [fp, #0x30]
    // 0xcf6c2c: LoadField: r3 = r2->field_f
    //     0xcf6c2c: ldur            w3, [x2, #0xf]
    // 0xcf6c30: DecompressPointer r3
    //     0xcf6c30: add             x3, x3, HEAP, lsl #32
    // 0xcf6c34: stur            x3, [fp, #-0x20]
    // 0xcf6c38: add             x4, x0, #1
    // 0xcf6c3c: stur            x4, [fp, #-0x18]
    // 0xcf6c40: LoadField: r5 = r3->field_b
    //     0xcf6c40: ldur            w5, [x3, #0xb]
    // 0xcf6c44: DecompressPointer r5
    //     0xcf6c44: add             x5, x5, HEAP, lsl #32
    // 0xcf6c48: stur            x5, [fp, #-0x10]
    // 0xcf6c4c: r6 = LoadInt32Instr(r5)
    //     0xcf6c4c: sbfx            x6, x5, #1, #0x1f
    // 0xcf6c50: mov             x0, x6
    // 0xcf6c54: mov             x1, x4
    // 0xcf6c58: stur            x6, [fp, #-8]
    // 0xcf6c5c: cmp             x1, x0
    // 0xcf6c60: b.hs            #0xcf6f08
    // 0xcf6c64: ArrayLoad: r0 = r3[r4]  ; Unknown_4
    //     0xcf6c64: add             x16, x3, x4, lsl #2
    //     0xcf6c68: ldur            w0, [x16, #0xf]
    // 0xcf6c6c: DecompressPointer r0
    //     0xcf6c6c: add             x0, x0, HEAP, lsl #32
    // 0xcf6c70: ldr             x1, [fp, #0x10]
    // 0xcf6c74: stp             x1, x0, [SP, #-0x10]!
    // 0xcf6c78: r24 = OptimizedIdenticalWithNumberCheckStub
    //     0xcf6c78: ldr             x24, [PP, #0x198]  ; [pp+0x198] Stub: OptimizedIdenticalWithNumberCheck (0x4ae5e4)
    // 0xcf6c7c: LoadField: r30 = r24->field_7
    //     0xcf6c7c: ldur            lr, [x24, #7]
    // 0xcf6c80: blr             lr
    // 0xcf6c84: ldp             x1, x0, [SP], #0x10
    // 0xcf6c88: b.ne            #0xcf6c94
    // 0xcf6c8c: ldr             x0, [fp, #0x30]
    // 0xcf6c90: b               #0xcf6d60
    // 0xcf6c94: ldur            x2, [fp, #-0x10]
    // 0xcf6c98: r1 = <Object?>
    //     0xcf6c98: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf6c9c: r0 = AllocateArray()
    //     0xcf6c9c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf6ca0: mov             x2, x0
    // 0xcf6ca4: stur            x2, [fp, #-0x10]
    // 0xcf6ca8: ldur            x3, [fp, #-0x20]
    // 0xcf6cac: ldur            x4, [fp, #-8]
    // 0xcf6cb0: r5 = 0
    //     0xcf6cb0: mov             x5, #0
    // 0xcf6cb4: CheckStackOverflow
    //     0xcf6cb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6cb8: cmp             SP, x16
    //     0xcf6cbc: b.ls            #0xcf6f0c
    // 0xcf6cc0: cmp             x5, x4
    // 0xcf6cc4: b.ge            #0xcf6d0c
    // 0xcf6cc8: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0xcf6cc8: add             x16, x3, x5, lsl #2
    //     0xcf6ccc: ldur            w0, [x16, #0xf]
    // 0xcf6cd0: DecompressPointer r0
    //     0xcf6cd0: add             x0, x0, HEAP, lsl #32
    // 0xcf6cd4: mov             x1, x2
    // 0xcf6cd8: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcf6cd8: add             x25, x1, x5, lsl #2
    //     0xcf6cdc: add             x25, x25, #0xf
    //     0xcf6ce0: str             w0, [x25]
    //     0xcf6ce4: tbz             w0, #0, #0xcf6d00
    //     0xcf6ce8: ldurb           w16, [x1, #-1]
    //     0xcf6cec: ldurb           w17, [x0, #-1]
    //     0xcf6cf0: and             x16, x17, x16, lsr #2
    //     0xcf6cf4: tst             x16, HEAP, lsr #32
    //     0xcf6cf8: b.eq            #0xcf6d00
    //     0xcf6cfc: bl              #0xd67e5c
    // 0xcf6d00: add             x0, x5, #1
    // 0xcf6d04: mov             x5, x0
    // 0xcf6d08: b               #0xcf6cb4
    // 0xcf6d0c: ldr             x4, [fp, #0x18]
    // 0xcf6d10: ldur            x3, [fp, #-0x18]
    // 0xcf6d14: mov             x1, x2
    // 0xcf6d18: ldr             x0, [fp, #0x10]
    // 0xcf6d1c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xcf6d1c: add             x25, x1, x3, lsl #2
    //     0xcf6d20: add             x25, x25, #0xf
    //     0xcf6d24: str             w0, [x25]
    //     0xcf6d28: tbz             w0, #0, #0xcf6d44
    //     0xcf6d2c: ldurb           w16, [x1, #-1]
    //     0xcf6d30: ldurb           w17, [x0, #-1]
    //     0xcf6d34: and             x16, x17, x16, lsr #2
    //     0xcf6d38: tst             x16, HEAP, lsr #32
    //     0xcf6d3c: b.eq            #0xcf6d44
    //     0xcf6d40: bl              #0xd67e5c
    // 0xcf6d44: r0 = _HashCollisionNode()
    //     0xcf6d44: bl              #0xcf6bd8  ; Allocate_HashCollisionNodeStub -> _HashCollisionNode (size=0x14)
    // 0xcf6d48: mov             x1, x0
    // 0xcf6d4c: ldr             x0, [fp, #0x18]
    // 0xcf6d50: StoreField: r1->field_7 = r0
    //     0xcf6d50: stur            x0, [x1, #7]
    // 0xcf6d54: ldur            x0, [fp, #-0x10]
    // 0xcf6d58: StoreField: r1->field_f = r0
    //     0xcf6d58: stur            w0, [x1, #0xf]
    // 0xcf6d5c: mov             x0, x1
    // 0xcf6d60: LeaveFrame
    //     0xcf6d60: mov             SP, fp
    //     0xcf6d64: ldp             fp, lr, [SP], #0x10
    // 0xcf6d68: ret
    //     0xcf6d68: ret             
    // 0xcf6d6c: ldr             x2, [fp, #0x30]
    // 0xcf6d70: ldr             x0, [fp, #0x18]
    // 0xcf6d74: LoadField: r3 = r2->field_f
    //     0xcf6d74: ldur            w3, [x2, #0xf]
    // 0xcf6d78: DecompressPointer r3
    //     0xcf6d78: add             x3, x3, HEAP, lsl #32
    // 0xcf6d7c: stur            x3, [fp, #-0x10]
    // 0xcf6d80: LoadField: r1 = r3->field_b
    //     0xcf6d80: ldur            w1, [x3, #0xb]
    // 0xcf6d84: DecompressPointer r1
    //     0xcf6d84: add             x1, x1, HEAP, lsl #32
    // 0xcf6d88: r4 = LoadInt32Instr(r1)
    //     0xcf6d88: sbfx            x4, x1, #1, #0x1f
    // 0xcf6d8c: stur            x4, [fp, #-0x18]
    // 0xcf6d90: add             x5, x4, #2
    // 0xcf6d94: stur            x5, [fp, #-8]
    // 0xcf6d98: lsl             x2, x5, #1
    // 0xcf6d9c: r1 = <Object?>
    //     0xcf6d9c: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf6da0: r0 = AllocateArray()
    //     0xcf6da0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf6da4: mov             x2, x0
    // 0xcf6da8: stur            x2, [fp, #-0x20]
    // 0xcf6dac: ldur            x3, [fp, #-0x10]
    // 0xcf6db0: ldur            x4, [fp, #-0x18]
    // 0xcf6db4: r5 = 0
    //     0xcf6db4: mov             x5, #0
    // 0xcf6db8: CheckStackOverflow
    //     0xcf6db8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6dbc: cmp             SP, x16
    //     0xcf6dc0: b.ls            #0xcf6f14
    // 0xcf6dc4: cmp             x5, x4
    // 0xcf6dc8: b.ge            #0xcf6e10
    // 0xcf6dcc: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0xcf6dcc: add             x16, x3, x5, lsl #2
    //     0xcf6dd0: ldur            w0, [x16, #0xf]
    // 0xcf6dd4: DecompressPointer r0
    //     0xcf6dd4: add             x0, x0, HEAP, lsl #32
    // 0xcf6dd8: mov             x1, x2
    // 0xcf6ddc: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcf6ddc: add             x25, x1, x5, lsl #2
    //     0xcf6de0: add             x25, x25, #0xf
    //     0xcf6de4: str             w0, [x25]
    //     0xcf6de8: tbz             w0, #0, #0xcf6e04
    //     0xcf6dec: ldurb           w16, [x1, #-1]
    //     0xcf6df0: ldurb           w17, [x0, #-1]
    //     0xcf6df4: and             x16, x17, x16, lsr #2
    //     0xcf6df8: tst             x16, HEAP, lsr #32
    //     0xcf6dfc: b.eq            #0xcf6e04
    //     0xcf6e00: bl              #0xd67e5c
    // 0xcf6e04: add             x0, x5, #1
    // 0xcf6e08: mov             x5, x0
    // 0xcf6e0c: b               #0xcf6db8
    // 0xcf6e10: ldr             x3, [fp, #0x18]
    // 0xcf6e14: mov             x1, x2
    // 0xcf6e18: ldr             x0, [fp, #0x20]
    // 0xcf6e1c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcf6e1c: add             x25, x1, x4, lsl #2
    //     0xcf6e20: add             x25, x25, #0xf
    //     0xcf6e24: str             w0, [x25]
    //     0xcf6e28: tbz             w0, #0, #0xcf6e44
    //     0xcf6e2c: ldurb           w16, [x1, #-1]
    //     0xcf6e30: ldurb           w17, [x0, #-1]
    //     0xcf6e34: and             x16, x17, x16, lsr #2
    //     0xcf6e38: tst             x16, HEAP, lsr #32
    //     0xcf6e3c: b.eq            #0xcf6e44
    //     0xcf6e40: bl              #0xd67e5c
    // 0xcf6e44: add             x5, x4, #1
    // 0xcf6e48: ldur            x0, [fp, #-8]
    // 0xcf6e4c: mov             x1, x5
    // 0xcf6e50: cmp             x1, x0
    // 0xcf6e54: b.hs            #0xcf6f1c
    // 0xcf6e58: mov             x1, x2
    // 0xcf6e5c: ldr             x0, [fp, #0x10]
    // 0xcf6e60: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcf6e60: add             x25, x1, x5, lsl #2
    //     0xcf6e64: add             x25, x25, #0xf
    //     0xcf6e68: str             w0, [x25]
    //     0xcf6e6c: tbz             w0, #0, #0xcf6e88
    //     0xcf6e70: ldurb           w16, [x1, #-1]
    //     0xcf6e74: ldurb           w17, [x0, #-1]
    //     0xcf6e78: and             x16, x17, x16, lsr #2
    //     0xcf6e7c: tst             x16, HEAP, lsr #32
    //     0xcf6e80: b.eq            #0xcf6e88
    //     0xcf6e84: bl              #0xd67e5c
    // 0xcf6e88: r0 = _HashCollisionNode()
    //     0xcf6e88: bl              #0xcf6bd8  ; Allocate_HashCollisionNodeStub -> _HashCollisionNode (size=0x14)
    // 0xcf6e8c: mov             x1, x0
    // 0xcf6e90: ldr             x0, [fp, #0x18]
    // 0xcf6e94: StoreField: r1->field_7 = r0
    //     0xcf6e94: stur            x0, [x1, #7]
    // 0xcf6e98: ldur            x0, [fp, #-0x20]
    // 0xcf6e9c: StoreField: r1->field_f = r0
    //     0xcf6e9c: stur            w0, [x1, #0xf]
    // 0xcf6ea0: mov             x0, x1
    // 0xcf6ea4: LeaveFrame
    //     0xcf6ea4: mov             SP, fp
    //     0xcf6ea8: ldp             fp, lr, [SP], #0x10
    // 0xcf6eac: ret
    //     0xcf6eac: ret             
    // 0xcf6eb0: mov             x16, x2
    // 0xcf6eb4: mov             x2, x0
    // 0xcf6eb8: mov             x0, x16
    // 0xcf6ebc: ldr             x16, [fp, #0x28]
    // 0xcf6ec0: stp             x16, NULL, [SP, #-0x10]!
    // 0xcf6ec4: stp             x2, x1, [SP, #-0x10]!
    // 0xcf6ec8: r0 = _CompressedNode.single()
    //     0xcf6ec8: bl              #0xcf6f20  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::_CompressedNode.single
    // 0xcf6ecc: add             SP, SP, #0x20
    // 0xcf6ed0: ldr             x16, [fp, #0x28]
    // 0xcf6ed4: stp             x16, x0, [SP, #-0x10]!
    // 0xcf6ed8: ldr             x16, [fp, #0x20]
    // 0xcf6edc: SaveReg r16
    //     0xcf6edc: str             x16, [SP, #-8]!
    // 0xcf6ee0: ldr             x0, [fp, #0x18]
    // 0xcf6ee4: ldr             x16, [fp, #0x10]
    // 0xcf6ee8: stp             x16, x0, [SP, #-0x10]!
    // 0xcf6eec: r0 = put()
    //     0xcf6eec: bl              #0xcf5e04  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::put
    // 0xcf6ef0: add             SP, SP, #0x28
    // 0xcf6ef4: LeaveFrame
    //     0xcf6ef4: mov             SP, fp
    //     0xcf6ef8: ldp             fp, lr, [SP], #0x10
    // 0xcf6efc: ret
    //     0xcf6efc: ret             
    // 0xcf6f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6f00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6f04: b               #0xcf6bfc
    // 0xcf6f08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6f08: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf6f0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6f0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6f10: b               #0xcf6cc0
    // 0xcf6f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6f14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6f18: b               #0xcf6dc4
    // 0xcf6f1c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6f1c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2374, size: 0x14, field offset: 0x8
class _CompressedNode extends _TrieNode {

  static late final _CompressedNode empty; // offset: 0xd18
  static late final List<Object?> _emptyArray; // offset: 0xd1c

  static _CompressedNode empty() {
    // ** addr: 0x712d3c, size: 0x64
    // 0x712d3c: EnterFrame
    //     0x712d3c: stp             fp, lr, [SP, #-0x10]!
    //     0x712d40: mov             fp, SP
    // 0x712d44: AllocStack(0x8)
    //     0x712d44: sub             SP, SP, #8
    // 0x712d48: CheckStackOverflow
    //     0x712d48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x712d4c: cmp             SP, x16
    //     0x712d50: b.ls            #0x712d98
    // 0x712d54: r0 = InitLateStaticField(0xd1c) // [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::_emptyArray
    //     0x712d54: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x712d58: ldr             x0, [x0, #0x1a38]
    //     0x712d5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x712d60: cmp             w0, w16
    //     0x712d64: b.ne            #0x712d74
    //     0x712d68: add             x2, PP, #0x22, lsl #12  ; [pp+0x229c8] Field <_CompressedNode@644137193._emptyArray@644137193>: static late final (offset: 0xd1c)
    //     0x712d6c: ldr             x2, [x2, #0x9c8]
    //     0x712d70: bl              #0xd67cdc
    // 0x712d74: stur            x0, [fp, #-8]
    // 0x712d78: r0 = _CompressedNode()
    //     0x712d78: bl              #0x712da0  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0x712d7c: r1 = 0
    //     0x712d7c: mov             x1, #0
    // 0x712d80: StoreField: r0->field_7 = r1
    //     0x712d80: stur            x1, [x0, #7]
    // 0x712d84: ldur            x1, [fp, #-8]
    // 0x712d88: StoreField: r0->field_f = r1
    //     0x712d88: stur            w1, [x0, #0xf]
    // 0x712d8c: LeaveFrame
    //     0x712d8c: mov             SP, fp
    //     0x712d90: ldp             fp, lr, [SP], #0x10
    // 0x712d94: ret
    //     0x712d94: ret             
    // 0x712d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x712d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x712d9c: b               #0x712d54
  }
  static List<Object?> _emptyArray() {
    // ** addr: 0x712dac, size: 0x20
    // 0x712dac: EnterFrame
    //     0x712dac: stp             fp, lr, [SP, #-0x10]!
    //     0x712db0: mov             fp, SP
    // 0x712db4: r1 = <Object?>
    //     0x712db4: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0x712db8: r2 = 0
    //     0x712db8: mov             x2, #0
    // 0x712dbc: r0 = AllocateArray()
    //     0x712dbc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x712dc0: LeaveFrame
    //     0x712dc0: mov             SP, fp
    //     0x712dc4: ldp             fp, lr, [SP], #0x10
    // 0x712dc8: ret
    //     0x712dc8: ret             
  }
  _ get(/* No info */) {
    // ** addr: 0xcf5860, size: 0x294
    // 0xcf5860: EnterFrame
    //     0xcf5860: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5864: mov             fp, SP
    // 0xcf5868: AllocStack(0x10)
    //     0xcf5868: sub             SP, SP, #0x10
    // 0xcf586c: r1 = 1
    //     0xcf586c: mov             x1, #1
    // 0xcf5870: r0 = 31
    //     0xcf5870: mov             x0, #0x1f
    // 0xcf5874: CheckStackOverflow
    //     0xcf5874: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf5878: cmp             SP, x16
    //     0xcf587c: b.ls            #0xcf5ab8
    // 0xcf5880: ldr             x2, [fp, #0x20]
    // 0xcf5884: r3 = LoadInt32Instr(r2)
    //     0xcf5884: sbfx            x3, x2, #1, #0x1f
    //     0xcf5888: tbz             w2, #0, #0xcf5890
    //     0xcf588c: ldur            x3, [x2, #7]
    // 0xcf5890: ldr             x4, [fp, #0x10]
    // 0xcf5894: stur            x3, [fp, #-0x10]
    // 0xcf5898: cmp             x3, #0x3f
    // 0xcf589c: b.hi            #0xcf5ac0
    // 0xcf58a0: lsr             x2, x4, x3
    // 0xcf58a4: ubfx            x2, x2, #0, #0x20
    // 0xcf58a8: and             x5, x2, x0
    // 0xcf58ac: ubfx            x5, x5, #0, #0x20
    // 0xcf58b0: lsl             x0, x1, x5
    // 0xcf58b4: ldr             x1, [fp, #0x28]
    // 0xcf58b8: LoadField: r2 = r1->field_7
    //     0xcf58b8: ldur            x2, [x1, #7]
    // 0xcf58bc: mov             x5, x0
    // 0xcf58c0: ubfx            x5, x5, #0, #0x20
    // 0xcf58c4: mov             x6, x2
    // 0xcf58c8: ubfx            x6, x6, #0, #0x20
    // 0xcf58cc: and             x7, x6, x5
    // 0xcf58d0: ubfx            x7, x7, #0, #0x20
    // 0xcf58d4: cbnz            x7, #0xcf58e8
    // 0xcf58d8: r0 = Null
    //     0xcf58d8: mov             x0, NULL
    // 0xcf58dc: LeaveFrame
    //     0xcf58dc: mov             SP, fp
    //     0xcf58e0: ldp             fp, lr, [SP], #0x10
    // 0xcf58e4: ret
    //     0xcf58e4: ret             
    // 0xcf58e8: r9 = 1
    //     0xcf58e8: mov             x9, #1
    // 0xcf58ec: r8 = 1431655765
    //     0xcf58ec: mov             x8, #0x5555
    //     0xcf58f0: movk            x8, #0x5555, lsl #16
    // 0xcf58f4: r7 = 858993459
    //     0xcf58f4: mov             x7, #0x3333
    //     0xcf58f8: movk            x7, #0x3333, lsl #16
    // 0xcf58fc: r6 = 252645135
    //     0xcf58fc: mov             x6, #0xf0f
    //     0xcf5900: movk            x6, #0xf0f, lsl #16
    // 0xcf5904: r5 = 63
    //     0xcf5904: mov             x5, #0x3f
    // 0xcf5908: ubfx            x0, x0, #0, #0x20
    // 0xcf590c: sub             w10, w0, w9
    // 0xcf5910: ubfx            x2, x2, #0, #0x20
    // 0xcf5914: and             x0, x2, x10
    // 0xcf5918: lsr             w2, w0, #1
    // 0xcf591c: and             x9, x2, x8
    // 0xcf5920: ubfx            x0, x0, #0, #0x20
    // 0xcf5924: ubfx            x9, x9, #0, #0x20
    // 0xcf5928: sub             x2, x0, x9
    // 0xcf592c: mov             x0, x2
    // 0xcf5930: ubfx            x0, x0, #0, #0x20
    // 0xcf5934: and             x8, x0, x7
    // 0xcf5938: lsr             x0, x2, #2
    // 0xcf593c: ubfx            x0, x0, #0, #0x20
    // 0xcf5940: and             x2, x0, x7
    // 0xcf5944: add             w0, w8, w2
    // 0xcf5948: lsr             w2, w0, #4
    // 0xcf594c: add             w7, w0, w2
    // 0xcf5950: and             x0, x7, x6
    // 0xcf5954: lsr             w2, w0, #8
    // 0xcf5958: add             w6, w0, w2
    // 0xcf595c: lsr             w0, w6, #0x10
    // 0xcf5960: add             w2, w6, w0
    // 0xcf5964: and             x0, x2, x5
    // 0xcf5968: LoadField: r2 = r1->field_f
    //     0xcf5968: ldur            w2, [x1, #0xf]
    // 0xcf596c: DecompressPointer r2
    //     0xcf596c: add             x2, x2, HEAP, lsl #32
    // 0xcf5970: ubfx            x0, x0, #0, #0x20
    // 0xcf5974: lsl             x5, x0, #1
    // 0xcf5978: LoadField: r0 = r2->field_b
    //     0xcf5978: ldur            w0, [x2, #0xb]
    // 0xcf597c: DecompressPointer r0
    //     0xcf597c: add             x0, x0, HEAP, lsl #32
    // 0xcf5980: r6 = LoadInt32Instr(r0)
    //     0xcf5980: sbfx            x6, x0, #1, #0x1f
    // 0xcf5984: mov             x0, x6
    // 0xcf5988: mov             x1, x5
    // 0xcf598c: cmp             x1, x0
    // 0xcf5990: b.hs            #0xcf5aec
    // 0xcf5994: ArrayLoad: r7 = r2[r5]  ; Unknown_4
    //     0xcf5994: add             x16, x2, x5, lsl #2
    //     0xcf5998: ldur            w7, [x16, #0xf]
    // 0xcf599c: DecompressPointer r7
    //     0xcf599c: add             x7, x7, HEAP, lsl #32
    // 0xcf59a0: add             x8, x5, #1
    // 0xcf59a4: mov             x0, x6
    // 0xcf59a8: mov             x1, x8
    // 0xcf59ac: cmp             x1, x0
    // 0xcf59b0: b.hs            #0xcf5af0
    // 0xcf59b4: ArrayLoad: r5 = r2[r8]  ; Unknown_4
    //     0xcf59b4: add             x16, x2, x8, lsl #2
    //     0xcf59b8: ldur            w5, [x16, #0xf]
    // 0xcf59bc: DecompressPointer r5
    //     0xcf59bc: add             x5, x5, HEAP, lsl #32
    // 0xcf59c0: stur            x5, [fp, #-8]
    // 0xcf59c4: cmp             w7, NULL
    // 0xcf59c8: b.ne            #0xcf5a64
    // 0xcf59cc: mov             x0, x5
    // 0xcf59d0: r2 = Null
    //     0xcf59d0: mov             x2, NULL
    // 0xcf59d4: r1 = Null
    //     0xcf59d4: mov             x1, NULL
    // 0xcf59d8: r4 = 59
    //     0xcf59d8: mov             x4, #0x3b
    // 0xcf59dc: branchIfSmi(r0, 0xcf59e8)
    //     0xcf59dc: tbz             w0, #0, #0xcf59e8
    // 0xcf59e0: r4 = LoadClassIdInstr(r0)
    //     0xcf59e0: ldur            x4, [x0, #-1]
    //     0xcf59e4: ubfx            x4, x4, #0xc, #0x14
    // 0xcf59e8: sub             x4, x4, #0x945
    // 0xcf59ec: cmp             x4, #2
    // 0xcf59f0: b.ls            #0xcf5a08
    // 0xcf59f4: r8 = _TrieNode
    //     0xcf59f4: add             x8, PP, #0x28, lsl #12  ; [pp+0x28f60] Type: _TrieNode
    //     0xcf59f8: ldr             x8, [x8, #0xf60]
    // 0xcf59fc: r3 = Null
    //     0xcf59fc: add             x3, PP, #0x28, lsl #12  ; [pp+0x28f68] Null
    //     0xcf5a00: ldr             x3, [x3, #0xf68]
    // 0xcf5a04: r0 = DefaultTypeTest()
    //     0xcf5a04: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcf5a08: ldur            x0, [fp, #-0x10]
    // 0xcf5a0c: add             x2, x0, #5
    // 0xcf5a10: r0 = BoxInt64Instr(r2)
    //     0xcf5a10: sbfiz           x0, x2, #1, #0x1f
    //     0xcf5a14: cmp             x2, x0, asr #1
    //     0xcf5a18: b.eq            #0xcf5a24
    //     0xcf5a1c: bl              #0xd69bb8
    //     0xcf5a20: stur            x2, [x0, #7]
    // 0xcf5a24: ldur            x1, [fp, #-8]
    // 0xcf5a28: r2 = LoadClassIdInstr(r1)
    //     0xcf5a28: ldur            x2, [x1, #-1]
    //     0xcf5a2c: ubfx            x2, x2, #0xc, #0x14
    // 0xcf5a30: stp             x0, x1, [SP, #-0x10]!
    // 0xcf5a34: ldr             x16, [fp, #0x18]
    // 0xcf5a38: SaveReg r16
    //     0xcf5a38: str             x16, [SP, #-8]!
    // 0xcf5a3c: ldr             x0, [fp, #0x10]
    // 0xcf5a40: SaveReg r0
    //     0xcf5a40: str             x0, [SP, #-8]!
    // 0xcf5a44: mov             x0, x2
    // 0xcf5a48: r0 = GDT[cid_x0 + -0xff9]()
    //     0xcf5a48: sub             lr, x0, #0xff9
    //     0xcf5a4c: ldr             lr, [x21, lr, lsl #3]
    //     0xcf5a50: blr             lr
    // 0xcf5a54: add             SP, SP, #0x20
    // 0xcf5a58: LeaveFrame
    //     0xcf5a58: mov             SP, fp
    //     0xcf5a5c: ldp             fp, lr, [SP], #0x10
    // 0xcf5a60: ret
    //     0xcf5a60: ret             
    // 0xcf5a64: ldr             x0, [fp, #0x18]
    // 0xcf5a68: mov             x1, x5
    // 0xcf5a6c: r2 = 59
    //     0xcf5a6c: mov             x2, #0x3b
    // 0xcf5a70: branchIfSmi(r0, 0xcf5a7c)
    //     0xcf5a70: tbz             w0, #0, #0xcf5a7c
    // 0xcf5a74: r2 = LoadClassIdInstr(r0)
    //     0xcf5a74: ldur            x2, [x0, #-1]
    //     0xcf5a78: ubfx            x2, x2, #0xc, #0x14
    // 0xcf5a7c: stp             x7, x0, [SP, #-0x10]!
    // 0xcf5a80: mov             x0, x2
    // 0xcf5a84: mov             lr, x0
    // 0xcf5a88: ldr             lr, [x21, lr, lsl #3]
    // 0xcf5a8c: blr             lr
    // 0xcf5a90: add             SP, SP, #0x10
    // 0xcf5a94: tbnz            w0, #4, #0xcf5aa8
    // 0xcf5a98: ldur            x0, [fp, #-8]
    // 0xcf5a9c: LeaveFrame
    //     0xcf5a9c: mov             SP, fp
    //     0xcf5aa0: ldp             fp, lr, [SP], #0x10
    // 0xcf5aa4: ret
    //     0xcf5aa4: ret             
    // 0xcf5aa8: r0 = Null
    //     0xcf5aa8: mov             x0, NULL
    // 0xcf5aac: LeaveFrame
    //     0xcf5aac: mov             SP, fp
    //     0xcf5ab0: ldp             fp, lr, [SP], #0x10
    // 0xcf5ab4: ret
    //     0xcf5ab4: ret             
    // 0xcf5ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5ab8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5abc: b               #0xcf5880
    // 0xcf5ac0: tbnz            x3, #0x3f, #0xcf5acc
    // 0xcf5ac4: mov             x2, xzr
    // 0xcf5ac8: b               #0xcf58a4
    // 0xcf5acc: str             x3, [THR, #0xc0]  ; THR::
    // 0xcf5ad0: stp             x3, x4, [SP, #-0x10]!
    // 0xcf5ad4: stp             x0, x1, [SP, #-0x10]!
    // 0xcf5ad8: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcf5adc: r4 = 0
    //     0xcf5adc: mov             x4, #0
    // 0xcf5ae0: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcf5ae4: blr             lr
    // 0xcf5ae8: brk             #0
    // 0xcf5aec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf5aec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf5af0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf5af0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ put(/* No info */) {
    // ** addr: 0xcf5e04, size: 0x98c
    // 0xcf5e04: EnterFrame
    //     0xcf5e04: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5e08: mov             fp, SP
    // 0xcf5e0c: AllocStack(0x68)
    //     0xcf5e0c: sub             SP, SP, #0x68
    // 0xcf5e10: r6 = 1
    //     0xcf5e10: mov             x6, #1
    // 0xcf5e14: r5 = 31
    //     0xcf5e14: mov             x5, #0x1f
    // 0xcf5e18: r4 = 1
    //     0xcf5e18: mov             x4, #1
    // 0xcf5e1c: r3 = 1431655765
    //     0xcf5e1c: mov             x3, #0x5555
    //     0xcf5e20: movk            x3, #0x5555, lsl #16
    // 0xcf5e24: r2 = 858993459
    //     0xcf5e24: mov             x2, #0x3333
    //     0xcf5e28: movk            x2, #0x3333, lsl #16
    // 0xcf5e2c: r1 = 252645135
    //     0xcf5e2c: mov             x1, #0xf0f
    //     0xcf5e30: movk            x1, #0xf0f, lsl #16
    // 0xcf5e34: r0 = 63
    //     0xcf5e34: mov             x0, #0x3f
    // 0xcf5e38: CheckStackOverflow
    //     0xcf5e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf5e3c: cmp             SP, x16
    //     0xcf5e40: b.ls            #0xcf6704
    // 0xcf5e44: ldr             x7, [fp, #0x28]
    // 0xcf5e48: r8 = LoadInt32Instr(r7)
    //     0xcf5e48: sbfx            x8, x7, #1, #0x1f
    //     0xcf5e4c: tbz             w7, #0, #0xcf5e54
    //     0xcf5e50: ldur            x8, [x7, #7]
    // 0xcf5e54: ldr             x7, [fp, #0x18]
    // 0xcf5e58: stur            x8, [fp, #-0x38]
    // 0xcf5e5c: cmp             x8, #0x3f
    // 0xcf5e60: b.hi            #0xcf670c
    // 0xcf5e64: lsr             x9, x7, x8
    // 0xcf5e68: ubfx            x9, x9, #0, #0x20
    // 0xcf5e6c: and             x10, x9, x5
    // 0xcf5e70: stur            x10, [fp, #-0x60]
    // 0xcf5e74: mov             x5, x10
    // 0xcf5e78: ubfx            x5, x5, #0, #0x20
    // 0xcf5e7c: lsl             x9, x6, x5
    // 0xcf5e80: ldr             x5, [fp, #0x30]
    // 0xcf5e84: stur            x9, [fp, #-0x68]
    // 0xcf5e88: LoadField: r6 = r5->field_7
    //     0xcf5e88: ldur            x6, [x5, #7]
    // 0xcf5e8c: stur            x6, [fp, #-0x30]
    // 0xcf5e90: mov             x11, x9
    // 0xcf5e94: ubfx            x11, x11, #0, #0x20
    // 0xcf5e98: sub             w12, w11, w4
    // 0xcf5e9c: mov             x4, x6
    // 0xcf5ea0: ubfx            x4, x4, #0, #0x20
    // 0xcf5ea4: and             x11, x4, x12
    // 0xcf5ea8: lsr             w4, w11, #1
    // 0xcf5eac: and             x12, x4, x3
    // 0xcf5eb0: ubfx            x11, x11, #0, #0x20
    // 0xcf5eb4: ubfx            x12, x12, #0, #0x20
    // 0xcf5eb8: sub             x4, x11, x12
    // 0xcf5ebc: mov             x11, x4
    // 0xcf5ec0: ubfx            x11, x11, #0, #0x20
    // 0xcf5ec4: and             x12, x11, x2
    // 0xcf5ec8: lsr             x11, x4, #2
    // 0xcf5ecc: ubfx            x11, x11, #0, #0x20
    // 0xcf5ed0: and             x4, x11, x2
    // 0xcf5ed4: add             w11, w12, w4
    // 0xcf5ed8: lsr             w4, w11, #4
    // 0xcf5edc: add             w12, w11, w4
    // 0xcf5ee0: and             x4, x12, x1
    // 0xcf5ee4: lsr             w11, w4, #8
    // 0xcf5ee8: add             w12, w4, w11
    // 0xcf5eec: lsr             w4, w12, #0x10
    // 0xcf5ef0: add             w11, w12, w4
    // 0xcf5ef4: and             x4, x11, x0
    // 0xcf5ef8: mov             x11, x9
    // 0xcf5efc: ubfx            x11, x11, #0, #0x20
    // 0xcf5f00: mov             x12, x6
    // 0xcf5f04: ubfx            x12, x12, #0, #0x20
    // 0xcf5f08: and             x13, x12, x11
    // 0xcf5f0c: ubfx            x13, x13, #0, #0x20
    // 0xcf5f10: cbz             x13, #0xcf6388
    // 0xcf5f14: LoadField: r3 = r5->field_f
    //     0xcf5f14: ldur            w3, [x5, #0xf]
    // 0xcf5f18: DecompressPointer r3
    //     0xcf5f18: add             x3, x3, HEAP, lsl #32
    // 0xcf5f1c: stur            x3, [fp, #-0x28]
    // 0xcf5f20: mov             x0, x4
    // 0xcf5f24: ubfx            x0, x0, #0, #0x20
    // 0xcf5f28: lsl             x2, x0, #1
    // 0xcf5f2c: stur            x2, [fp, #-0x58]
    // 0xcf5f30: LoadField: r4 = r3->field_b
    //     0xcf5f30: ldur            w4, [x3, #0xb]
    // 0xcf5f34: DecompressPointer r4
    //     0xcf5f34: add             x4, x4, HEAP, lsl #32
    // 0xcf5f38: stur            x4, [fp, #-0x20]
    // 0xcf5f3c: r9 = LoadInt32Instr(r4)
    //     0xcf5f3c: sbfx            x9, x4, #1, #0x1f
    // 0xcf5f40: mov             x0, x9
    // 0xcf5f44: mov             x1, x2
    // 0xcf5f48: stur            x9, [fp, #-0x18]
    // 0xcf5f4c: cmp             x1, x0
    // 0xcf5f50: b.hs            #0xcf6744
    // 0xcf5f54: ArrayLoad: r10 = r3[r2]  ; Unknown_4
    //     0xcf5f54: add             x16, x3, x2, lsl #2
    //     0xcf5f58: ldur            w10, [x16, #0xf]
    // 0xcf5f5c: DecompressPointer r10
    //     0xcf5f5c: add             x10, x10, HEAP, lsl #32
    // 0xcf5f60: stur            x10, [fp, #-0x50]
    // 0xcf5f64: add             x11, x2, #1
    // 0xcf5f68: mov             x0, x9
    // 0xcf5f6c: mov             x1, x11
    // 0xcf5f70: stur            x11, [fp, #-0x10]
    // 0xcf5f74: cmp             x1, x0
    // 0xcf5f78: b.hs            #0xcf6748
    // 0xcf5f7c: ArrayLoad: r12 = r3[r11]  ; Unknown_4
    //     0xcf5f7c: add             x16, x3, x11, lsl #2
    //     0xcf5f80: ldur            w12, [x16, #0xf]
    // 0xcf5f84: DecompressPointer r12
    //     0xcf5f84: add             x12, x12, HEAP, lsl #32
    // 0xcf5f88: stur            x12, [fp, #-8]
    // 0xcf5f8c: cmp             w10, NULL
    // 0xcf5f90: b.ne            #0xcf6114
    // 0xcf5f94: mov             x0, x12
    // 0xcf5f98: r2 = Null
    //     0xcf5f98: mov             x2, NULL
    // 0xcf5f9c: r1 = Null
    //     0xcf5f9c: mov             x1, NULL
    // 0xcf5fa0: r4 = 59
    //     0xcf5fa0: mov             x4, #0x3b
    // 0xcf5fa4: branchIfSmi(r0, 0xcf5fb0)
    //     0xcf5fa4: tbz             w0, #0, #0xcf5fb0
    // 0xcf5fa8: r4 = LoadClassIdInstr(r0)
    //     0xcf5fa8: ldur            x4, [x0, #-1]
    //     0xcf5fac: ubfx            x4, x4, #0xc, #0x14
    // 0xcf5fb0: sub             x4, x4, #0x945
    // 0xcf5fb4: cmp             x4, #2
    // 0xcf5fb8: b.ls            #0xcf5fd0
    // 0xcf5fbc: r8 = _TrieNode
    //     0xcf5fbc: add             x8, PP, #0x28, lsl #12  ; [pp+0x28f60] Type: _TrieNode
    //     0xcf5fc0: ldr             x8, [x8, #0xf60]
    // 0xcf5fc4: r3 = Null
    //     0xcf5fc4: add             x3, PP, #0x28, lsl #12  ; [pp+0x28f78] Null
    //     0xcf5fc8: ldr             x3, [x3, #0xf78]
    // 0xcf5fcc: r0 = DefaultTypeTest()
    //     0xcf5fcc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcf5fd0: ldur            x1, [fp, #-0x38]
    // 0xcf5fd4: add             x2, x1, #5
    // 0xcf5fd8: r0 = BoxInt64Instr(r2)
    //     0xcf5fd8: sbfiz           x0, x2, #1, #0x1f
    //     0xcf5fdc: cmp             x2, x0, asr #1
    //     0xcf5fe0: b.eq            #0xcf5fec
    //     0xcf5fe4: bl              #0xd69bb8
    //     0xcf5fe8: stur            x2, [x0, #7]
    // 0xcf5fec: ldur            x1, [fp, #-8]
    // 0xcf5ff0: r2 = LoadClassIdInstr(r1)
    //     0xcf5ff0: ldur            x2, [x1, #-1]
    //     0xcf5ff4: ubfx            x2, x2, #0xc, #0x14
    // 0xcf5ff8: stp             x0, x1, [SP, #-0x10]!
    // 0xcf5ffc: ldr             x16, [fp, #0x20]
    // 0xcf6000: SaveReg r16
    //     0xcf6000: str             x16, [SP, #-8]!
    // 0xcf6004: ldr             x3, [fp, #0x18]
    // 0xcf6008: ldr             x16, [fp, #0x10]
    // 0xcf600c: stp             x16, x3, [SP, #-0x10]!
    // 0xcf6010: mov             x0, x2
    // 0xcf6014: r0 = GDT[cid_x0 + -0xfff]()
    //     0xcf6014: sub             lr, x0, #0xfff
    //     0xcf6018: ldr             lr, [x21, lr, lsl #3]
    //     0xcf601c: blr             lr
    // 0xcf6020: add             SP, SP, #0x28
    // 0xcf6024: ldur            x4, [fp, #-8]
    // 0xcf6028: stur            x0, [fp, #-0x40]
    // 0xcf602c: cmp             w0, w4
    // 0xcf6030: b.ne            #0xcf6044
    // 0xcf6034: ldr             x0, [fp, #0x30]
    // 0xcf6038: LeaveFrame
    //     0xcf6038: mov             SP, fp
    //     0xcf603c: ldp             fp, lr, [SP], #0x10
    // 0xcf6040: ret
    //     0xcf6040: ret             
    // 0xcf6044: ldur            x2, [fp, #-0x20]
    // 0xcf6048: r1 = <Object?>
    //     0xcf6048: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf604c: r0 = AllocateArray()
    //     0xcf604c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf6050: mov             x2, x0
    // 0xcf6054: stur            x2, [fp, #-0x48]
    // 0xcf6058: ldur            x5, [fp, #-0x28]
    // 0xcf605c: ldur            x6, [fp, #-0x18]
    // 0xcf6060: r3 = 0
    //     0xcf6060: mov             x3, #0
    // 0xcf6064: CheckStackOverflow
    //     0xcf6064: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6068: cmp             SP, x16
    //     0xcf606c: b.ls            #0xcf674c
    // 0xcf6070: cmp             x3, x6
    // 0xcf6074: b.ge            #0xcf60bc
    // 0xcf6078: ArrayLoad: r0 = r5[r3]  ; Unknown_4
    //     0xcf6078: add             x16, x5, x3, lsl #2
    //     0xcf607c: ldur            w0, [x16, #0xf]
    // 0xcf6080: DecompressPointer r0
    //     0xcf6080: add             x0, x0, HEAP, lsl #32
    // 0xcf6084: mov             x1, x2
    // 0xcf6088: ArrayStore: r1[r3] = r0  ; List_4
    //     0xcf6088: add             x25, x1, x3, lsl #2
    //     0xcf608c: add             x25, x25, #0xf
    //     0xcf6090: str             w0, [x25]
    //     0xcf6094: tbz             w0, #0, #0xcf60b0
    //     0xcf6098: ldurb           w16, [x1, #-1]
    //     0xcf609c: ldurb           w17, [x0, #-1]
    //     0xcf60a0: and             x16, x17, x16, lsr #2
    //     0xcf60a4: tst             x16, HEAP, lsr #32
    //     0xcf60a8: b.eq            #0xcf60b0
    //     0xcf60ac: bl              #0xd67e5c
    // 0xcf60b0: add             x0, x3, #1
    // 0xcf60b4: mov             x3, x0
    // 0xcf60b8: b               #0xcf6064
    // 0xcf60bc: ldur            x7, [fp, #-0x10]
    // 0xcf60c0: ldur            x3, [fp, #-0x30]
    // 0xcf60c4: mov             x1, x2
    // 0xcf60c8: ldur            x0, [fp, #-0x40]
    // 0xcf60cc: ArrayStore: r1[r7] = r0  ; List_4
    //     0xcf60cc: add             x25, x1, x7, lsl #2
    //     0xcf60d0: add             x25, x25, #0xf
    //     0xcf60d4: str             w0, [x25]
    //     0xcf60d8: tbz             w0, #0, #0xcf60f4
    //     0xcf60dc: ldurb           w16, [x1, #-1]
    //     0xcf60e0: ldurb           w17, [x0, #-1]
    //     0xcf60e4: and             x16, x17, x16, lsr #2
    //     0xcf60e8: tst             x16, HEAP, lsr #32
    //     0xcf60ec: b.eq            #0xcf60f4
    //     0xcf60f0: bl              #0xd67e5c
    // 0xcf60f4: r0 = _CompressedNode()
    //     0xcf60f4: bl              #0x712da0  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0xcf60f8: ldur            x8, [fp, #-0x30]
    // 0xcf60fc: StoreField: r0->field_7 = r8
    //     0xcf60fc: stur            x8, [x0, #7]
    // 0xcf6100: ldur            x1, [fp, #-0x48]
    // 0xcf6104: StoreField: r0->field_f = r1
    //     0xcf6104: stur            w1, [x0, #0xf]
    // 0xcf6108: LeaveFrame
    //     0xcf6108: mov             SP, fp
    //     0xcf610c: ldp             fp, lr, [SP], #0x10
    // 0xcf6110: ret
    //     0xcf6110: ret             
    // 0xcf6114: mov             x1, x8
    // 0xcf6118: mov             x8, x6
    // 0xcf611c: mov             x6, x9
    // 0xcf6120: ldr             x9, [fp, #0x20]
    // 0xcf6124: mov             x5, x3
    // 0xcf6128: mov             x3, x7
    // 0xcf612c: mov             x7, x11
    // 0xcf6130: mov             x4, x12
    // 0xcf6134: r0 = 59
    //     0xcf6134: mov             x0, #0x3b
    // 0xcf6138: branchIfSmi(r9, 0xcf6144)
    //     0xcf6138: tbz             w9, #0, #0xcf6144
    // 0xcf613c: r0 = LoadClassIdInstr(r9)
    //     0xcf613c: ldur            x0, [x9, #-1]
    //     0xcf6140: ubfx            x0, x0, #0xc, #0x14
    // 0xcf6144: stp             x10, x9, [SP, #-0x10]!
    // 0xcf6148: mov             lr, x0
    // 0xcf614c: ldr             lr, [x21, lr, lsl #3]
    // 0xcf6150: blr             lr
    // 0xcf6154: add             SP, SP, #0x10
    // 0xcf6158: tbnz            w0, #4, #0xcf6254
    // 0xcf615c: ldr             x0, [fp, #0x10]
    // 0xcf6160: ldur            x1, [fp, #-8]
    // 0xcf6164: stp             x1, x0, [SP, #-0x10]!
    // 0xcf6168: r24 = OptimizedIdenticalWithNumberCheckStub
    //     0xcf6168: ldr             x24, [PP, #0x198]  ; [pp+0x198] Stub: OptimizedIdenticalWithNumberCheck (0x4ae5e4)
    // 0xcf616c: LoadField: r30 = r24->field_7
    //     0xcf616c: ldur            lr, [x24, #7]
    // 0xcf6170: blr             lr
    // 0xcf6174: ldp             x1, x0, [SP], #0x10
    // 0xcf6178: b.ne            #0xcf6184
    // 0xcf617c: ldr             x0, [fp, #0x30]
    // 0xcf6180: b               #0xcf6248
    // 0xcf6184: ldur            x2, [fp, #-0x20]
    // 0xcf6188: r1 = <Object?>
    //     0xcf6188: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf618c: r0 = AllocateArray()
    //     0xcf618c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf6190: mov             x2, x0
    // 0xcf6194: stur            x2, [fp, #-0x40]
    // 0xcf6198: ldur            x3, [fp, #-0x28]
    // 0xcf619c: ldur            x4, [fp, #-0x18]
    // 0xcf61a0: r5 = 0
    //     0xcf61a0: mov             x5, #0
    // 0xcf61a4: CheckStackOverflow
    //     0xcf61a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf61a8: cmp             SP, x16
    //     0xcf61ac: b.ls            #0xcf6754
    // 0xcf61b0: cmp             x5, x4
    // 0xcf61b4: b.ge            #0xcf61fc
    // 0xcf61b8: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0xcf61b8: add             x16, x3, x5, lsl #2
    //     0xcf61bc: ldur            w0, [x16, #0xf]
    // 0xcf61c0: DecompressPointer r0
    //     0xcf61c0: add             x0, x0, HEAP, lsl #32
    // 0xcf61c4: mov             x1, x2
    // 0xcf61c8: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcf61c8: add             x25, x1, x5, lsl #2
    //     0xcf61cc: add             x25, x25, #0xf
    //     0xcf61d0: str             w0, [x25]
    //     0xcf61d4: tbz             w0, #0, #0xcf61f0
    //     0xcf61d8: ldurb           w16, [x1, #-1]
    //     0xcf61dc: ldurb           w17, [x0, #-1]
    //     0xcf61e0: and             x16, x17, x16, lsr #2
    //     0xcf61e4: tst             x16, HEAP, lsr #32
    //     0xcf61e8: b.eq            #0xcf61f0
    //     0xcf61ec: bl              #0xd67e5c
    // 0xcf61f0: add             x0, x5, #1
    // 0xcf61f4: mov             x5, x0
    // 0xcf61f8: b               #0xcf61a4
    // 0xcf61fc: ldur            x5, [fp, #-0x10]
    // 0xcf6200: ldur            x3, [fp, #-0x30]
    // 0xcf6204: mov             x1, x2
    // 0xcf6208: ldr             x0, [fp, #0x10]
    // 0xcf620c: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcf620c: add             x25, x1, x5, lsl #2
    //     0xcf6210: add             x25, x25, #0xf
    //     0xcf6214: str             w0, [x25]
    //     0xcf6218: tbz             w0, #0, #0xcf6234
    //     0xcf621c: ldurb           w16, [x1, #-1]
    //     0xcf6220: ldurb           w17, [x0, #-1]
    //     0xcf6224: and             x16, x17, x16, lsr #2
    //     0xcf6228: tst             x16, HEAP, lsr #32
    //     0xcf622c: b.eq            #0xcf6234
    //     0xcf6230: bl              #0xd67e5c
    // 0xcf6234: r0 = _CompressedNode()
    //     0xcf6234: bl              #0x712da0  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0xcf6238: ldur            x2, [fp, #-0x30]
    // 0xcf623c: StoreField: r0->field_7 = r2
    //     0xcf623c: stur            x2, [x0, #7]
    // 0xcf6240: ldur            x1, [fp, #-0x40]
    // 0xcf6244: StoreField: r0->field_f = r1
    //     0xcf6244: stur            w1, [x0, #0xf]
    // 0xcf6248: LeaveFrame
    //     0xcf6248: mov             SP, fp
    //     0xcf624c: ldp             fp, lr, [SP], #0x10
    // 0xcf6250: ret
    //     0xcf6250: ret             
    // 0xcf6254: ldr             x7, [fp, #0x18]
    // 0xcf6258: ldur            x3, [fp, #-0x28]
    // 0xcf625c: ldur            x5, [fp, #-0x10]
    // 0xcf6260: ldur            x2, [fp, #-0x30]
    // 0xcf6264: ldur            x6, [fp, #-0x38]
    // 0xcf6268: ldur            x4, [fp, #-0x18]
    // 0xcf626c: add             x8, x6, #5
    // 0xcf6270: r0 = BoxInt64Instr(r8)
    //     0xcf6270: sbfiz           x0, x8, #1, #0x1f
    //     0xcf6274: cmp             x8, x0, asr #1
    //     0xcf6278: b.eq            #0xcf6284
    //     0xcf627c: bl              #0xd69bb8
    //     0xcf6280: stur            x8, [x0, #7]
    // 0xcf6284: ldur            x16, [fp, #-0x50]
    // 0xcf6288: stp             x16, x0, [SP, #-0x10]!
    // 0xcf628c: ldur            x16, [fp, #-8]
    // 0xcf6290: ldr             lr, [fp, #0x20]
    // 0xcf6294: stp             lr, x16, [SP, #-0x10]!
    // 0xcf6298: ldr             x16, [fp, #0x10]
    // 0xcf629c: stp             x16, x7, [SP, #-0x10]!
    // 0xcf62a0: r0 = _resolveCollision()
    //     0xcf62a0: bl              #0xcf6a60  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::_resolveCollision
    // 0xcf62a4: add             SP, SP, #0x30
    // 0xcf62a8: ldur            x2, [fp, #-0x20]
    // 0xcf62ac: r1 = <Object?>
    //     0xcf62ac: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf62b0: stur            x0, [fp, #-8]
    // 0xcf62b4: r0 = AllocateArray()
    //     0xcf62b4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf62b8: mov             x2, x0
    // 0xcf62bc: stur            x2, [fp, #-0x20]
    // 0xcf62c0: ldur            x3, [fp, #-0x28]
    // 0xcf62c4: ldur            x4, [fp, #-0x18]
    // 0xcf62c8: r5 = 0
    //     0xcf62c8: mov             x5, #0
    // 0xcf62cc: CheckStackOverflow
    //     0xcf62cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf62d0: cmp             SP, x16
    //     0xcf62d4: b.ls            #0xcf675c
    // 0xcf62d8: cmp             x5, x4
    // 0xcf62dc: b.ge            #0xcf6324
    // 0xcf62e0: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0xcf62e0: add             x16, x3, x5, lsl #2
    //     0xcf62e4: ldur            w0, [x16, #0xf]
    // 0xcf62e8: DecompressPointer r0
    //     0xcf62e8: add             x0, x0, HEAP, lsl #32
    // 0xcf62ec: mov             x1, x2
    // 0xcf62f0: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcf62f0: add             x25, x1, x5, lsl #2
    //     0xcf62f4: add             x25, x25, #0xf
    //     0xcf62f8: str             w0, [x25]
    //     0xcf62fc: tbz             w0, #0, #0xcf6318
    //     0xcf6300: ldurb           w16, [x1, #-1]
    //     0xcf6304: ldurb           w17, [x0, #-1]
    //     0xcf6308: and             x16, x17, x16, lsr #2
    //     0xcf630c: tst             x16, HEAP, lsr #32
    //     0xcf6310: b.eq            #0xcf6318
    //     0xcf6314: bl              #0xd67e5c
    // 0xcf6318: add             x0, x5, #1
    // 0xcf631c: mov             x5, x0
    // 0xcf6320: b               #0xcf62cc
    // 0xcf6324: ldur            x3, [fp, #-0x10]
    // 0xcf6328: ldur            x4, [fp, #-0x30]
    // 0xcf632c: ldur            x0, [fp, #-0x58]
    // 0xcf6330: ArrayStore: r2[r0] = rNULL  ; Unknown_4
    //     0xcf6330: add             x1, x2, x0, lsl #2
    //     0xcf6334: stur            NULL, [x1, #0xf]
    // 0xcf6338: mov             x1, x2
    // 0xcf633c: ldur            x0, [fp, #-8]
    // 0xcf6340: ArrayStore: r1[r3] = r0  ; List_4
    //     0xcf6340: add             x25, x1, x3, lsl #2
    //     0xcf6344: add             x25, x25, #0xf
    //     0xcf6348: str             w0, [x25]
    //     0xcf634c: tbz             w0, #0, #0xcf6368
    //     0xcf6350: ldurb           w16, [x1, #-1]
    //     0xcf6354: ldurb           w17, [x0, #-1]
    //     0xcf6358: and             x16, x17, x16, lsr #2
    //     0xcf635c: tst             x16, HEAP, lsr #32
    //     0xcf6360: b.eq            #0xcf6368
    //     0xcf6364: bl              #0xd67e5c
    // 0xcf6368: r0 = _CompressedNode()
    //     0xcf6368: bl              #0x712da0  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0xcf636c: ldur            x5, [fp, #-0x30]
    // 0xcf6370: StoreField: r0->field_7 = r5
    //     0xcf6370: stur            x5, [x0, #7]
    // 0xcf6374: ldur            x1, [fp, #-0x20]
    // 0xcf6378: StoreField: r0->field_f = r1
    //     0xcf6378: stur            w1, [x0, #0xf]
    // 0xcf637c: LeaveFrame
    //     0xcf637c: mov             SP, fp
    //     0xcf6380: ldp             fp, lr, [SP], #0x10
    // 0xcf6384: ret
    //     0xcf6384: ret             
    // 0xcf6388: mov             x5, x6
    // 0xcf638c: mov             x6, x8
    // 0xcf6390: asr             x8, x5, #1
    // 0xcf6394: ubfx            x8, x8, #0, #0x20
    // 0xcf6398: and             x11, x8, x3
    // 0xcf639c: ubfx            x11, x11, #0, #0x20
    // 0xcf63a0: sub             x3, x5, x11
    // 0xcf63a4: mov             x8, x3
    // 0xcf63a8: ubfx            x8, x8, #0, #0x20
    // 0xcf63ac: and             x11, x8, x2
    // 0xcf63b0: lsr             x8, x3, #2
    // 0xcf63b4: ubfx            x8, x8, #0, #0x20
    // 0xcf63b8: and             x3, x8, x2
    // 0xcf63bc: add             w2, w11, w3
    // 0xcf63c0: lsr             w3, w2, #4
    // 0xcf63c4: add             w8, w2, w3
    // 0xcf63c8: and             x2, x8, x1
    // 0xcf63cc: lsr             w1, w2, #8
    // 0xcf63d0: add             w3, w2, w1
    // 0xcf63d4: lsr             w1, w3, #0x10
    // 0xcf63d8: add             w2, w3, w1
    // 0xcf63dc: and             x1, x2, x0
    // 0xcf63e0: mov             x0, x1
    // 0xcf63e4: ubfx            x0, x0, #0, #0x20
    // 0xcf63e8: cmp             x0, #0x10
    // 0xcf63ec: b.lt            #0xcf64dc
    // 0xcf63f0: ldr             x16, [fp, #0x30]
    // 0xcf63f4: stp             x6, x16, [SP, #-0x10]!
    // 0xcf63f8: r0 = _inflate()
    //     0xcf63f8: bl              #0xcf6790  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::_inflate
    // 0xcf63fc: add             SP, SP, #0x10
    // 0xcf6400: stur            x0, [fp, #-0x20]
    // 0xcf6404: LoadField: r1 = r0->field_7
    //     0xcf6404: ldur            w1, [x0, #7]
    // 0xcf6408: DecompressPointer r1
    //     0xcf6408: add             x1, x1, HEAP, lsl #32
    // 0xcf640c: stur            x1, [fp, #-8]
    // 0xcf6410: r0 = InitLateStaticField(0xd18) // [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::empty
    //     0xcf6410: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcf6414: ldr             x0, [x0, #0x1a30]
    //     0xcf6418: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcf641c: cmp             w0, w16
    //     0xcf6420: b.ne            #0xcf6430
    //     0xcf6424: add             x2, PP, #0x22, lsl #12  ; [pp+0x229c0] Field <_CompressedNode@644137193.empty>: static late final (offset: 0xd18)
    //     0xcf6428: ldr             x2, [x2, #0x9c0]
    //     0xcf642c: bl              #0xd67cdc
    // 0xcf6430: mov             x2, x0
    // 0xcf6434: ldur            x0, [fp, #-0x38]
    // 0xcf6438: add             x3, x0, #5
    // 0xcf643c: r0 = BoxInt64Instr(r3)
    //     0xcf643c: sbfiz           x0, x3, #1, #0x1f
    //     0xcf6440: cmp             x3, x0, asr #1
    //     0xcf6444: b.eq            #0xcf6450
    //     0xcf6448: bl              #0xd69bb8
    //     0xcf644c: stur            x3, [x0, #7]
    // 0xcf6450: stp             x0, x2, [SP, #-0x10]!
    // 0xcf6454: ldr             x16, [fp, #0x20]
    // 0xcf6458: SaveReg r16
    //     0xcf6458: str             x16, [SP, #-8]!
    // 0xcf645c: ldr             x0, [fp, #0x18]
    // 0xcf6460: ldr             x16, [fp, #0x10]
    // 0xcf6464: stp             x16, x0, [SP, #-0x10]!
    // 0xcf6468: r0 = put()
    //     0xcf6468: bl              #0xcf5e04  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::put
    // 0xcf646c: add             SP, SP, #0x28
    // 0xcf6470: mov             x3, x0
    // 0xcf6474: ldur            x2, [fp, #-8]
    // 0xcf6478: LoadField: r0 = r2->field_b
    //     0xcf6478: ldur            w0, [x2, #0xb]
    // 0xcf647c: DecompressPointer r0
    //     0xcf647c: add             x0, x0, HEAP, lsl #32
    // 0xcf6480: r1 = LoadInt32Instr(r0)
    //     0xcf6480: sbfx            x1, x0, #1, #0x1f
    // 0xcf6484: ldur            x4, [fp, #-0x60]
    // 0xcf6488: ubfx            x4, x4, #0, #0x20
    // 0xcf648c: mov             x0, x1
    // 0xcf6490: mov             x1, x4
    // 0xcf6494: cmp             x1, x0
    // 0xcf6498: b.hs            #0xcf6764
    // 0xcf649c: mov             x1, x2
    // 0xcf64a0: mov             x0, x3
    // 0xcf64a4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcf64a4: add             x25, x1, x4, lsl #2
    //     0xcf64a8: add             x25, x25, #0xf
    //     0xcf64ac: str             w0, [x25]
    //     0xcf64b0: tbz             w0, #0, #0xcf64cc
    //     0xcf64b4: ldurb           w16, [x1, #-1]
    //     0xcf64b8: ldurb           w17, [x0, #-1]
    //     0xcf64bc: and             x16, x17, x16, lsr #2
    //     0xcf64c0: tst             x16, HEAP, lsr #32
    //     0xcf64c4: b.eq            #0xcf64cc
    //     0xcf64c8: bl              #0xd67e5c
    // 0xcf64cc: ldur            x0, [fp, #-0x20]
    // 0xcf64d0: LeaveFrame
    //     0xcf64d0: mov             SP, fp
    //     0xcf64d4: ldp             fp, lr, [SP], #0x10
    // 0xcf64d8: ret
    //     0xcf64d8: ret             
    // 0xcf64dc: ldr             x0, [fp, #0x30]
    // 0xcf64e0: ubfx            x4, x4, #0, #0x20
    // 0xcf64e4: lsl             x3, x4, #1
    // 0xcf64e8: stur            x3, [fp, #-0x38]
    // 0xcf64ec: ubfx            x1, x1, #0, #0x20
    // 0xcf64f0: lsl             x4, x1, #1
    // 0xcf64f4: stur            x4, [fp, #-0x18]
    // 0xcf64f8: add             x6, x4, #2
    // 0xcf64fc: stur            x6, [fp, #-0x10]
    // 0xcf6500: lsl             x2, x6, #1
    // 0xcf6504: r1 = <Object?>
    //     0xcf6504: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf6508: r0 = AllocateArray()
    //     0xcf6508: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf650c: mov             x2, x0
    // 0xcf6510: ldr             x0, [fp, #0x30]
    // 0xcf6514: stur            x2, [fp, #-8]
    // 0xcf6518: LoadField: r3 = r0->field_f
    //     0xcf6518: ldur            w3, [x0, #0xf]
    // 0xcf651c: DecompressPointer r3
    //     0xcf651c: add             x3, x3, HEAP, lsl #32
    // 0xcf6520: LoadField: r0 = r3->field_b
    //     0xcf6520: ldur            w0, [x3, #0xb]
    // 0xcf6524: DecompressPointer r0
    //     0xcf6524: add             x0, x0, HEAP, lsl #32
    // 0xcf6528: r4 = LoadInt32Instr(r0)
    //     0xcf6528: sbfx            x4, x0, #1, #0x1f
    // 0xcf652c: ldur            x5, [fp, #-0x38]
    // 0xcf6530: r6 = 0
    //     0xcf6530: mov             x6, #0
    // 0xcf6534: CheckStackOverflow
    //     0xcf6534: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6538: cmp             SP, x16
    //     0xcf653c: b.ls            #0xcf6768
    // 0xcf6540: cmp             x6, x5
    // 0xcf6544: b.ge            #0xcf65b0
    // 0xcf6548: mov             x0, x4
    // 0xcf654c: mov             x1, x6
    // 0xcf6550: cmp             x1, x0
    // 0xcf6554: b.hs            #0xcf6770
    // 0xcf6558: ArrayLoad: r7 = r3[r6]  ; Unknown_4
    //     0xcf6558: add             x16, x3, x6, lsl #2
    //     0xcf655c: ldur            w7, [x16, #0xf]
    // 0xcf6560: DecompressPointer r7
    //     0xcf6560: add             x7, x7, HEAP, lsl #32
    // 0xcf6564: ldur            x0, [fp, #-0x10]
    // 0xcf6568: mov             x1, x6
    // 0xcf656c: cmp             x1, x0
    // 0xcf6570: b.hs            #0xcf6774
    // 0xcf6574: mov             x1, x2
    // 0xcf6578: mov             x0, x7
    // 0xcf657c: ArrayStore: r1[r6] = r0  ; List_4
    //     0xcf657c: add             x25, x1, x6, lsl #2
    //     0xcf6580: add             x25, x25, #0xf
    //     0xcf6584: str             w0, [x25]
    //     0xcf6588: tbz             w0, #0, #0xcf65a4
    //     0xcf658c: ldurb           w16, [x1, #-1]
    //     0xcf6590: ldurb           w17, [x0, #-1]
    //     0xcf6594: and             x16, x17, x16, lsr #2
    //     0xcf6598: tst             x16, HEAP, lsr #32
    //     0xcf659c: b.eq            #0xcf65a4
    //     0xcf65a0: bl              #0xd67e5c
    // 0xcf65a4: add             x0, x6, #1
    // 0xcf65a8: mov             x6, x0
    // 0xcf65ac: b               #0xcf6534
    // 0xcf65b0: ldur            x0, [fp, #-0x10]
    // 0xcf65b4: mov             x1, x5
    // 0xcf65b8: cmp             x1, x0
    // 0xcf65bc: b.hs            #0xcf6778
    // 0xcf65c0: mov             x1, x2
    // 0xcf65c4: ldr             x0, [fp, #0x20]
    // 0xcf65c8: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcf65c8: add             x25, x1, x5, lsl #2
    //     0xcf65cc: add             x25, x25, #0xf
    //     0xcf65d0: str             w0, [x25]
    //     0xcf65d4: tbz             w0, #0, #0xcf65f0
    //     0xcf65d8: ldurb           w16, [x1, #-1]
    //     0xcf65dc: ldurb           w17, [x0, #-1]
    //     0xcf65e0: and             x16, x17, x16, lsr #2
    //     0xcf65e4: tst             x16, HEAP, lsr #32
    //     0xcf65e8: b.eq            #0xcf65f0
    //     0xcf65ec: bl              #0xd67e5c
    // 0xcf65f0: add             x4, x5, #1
    // 0xcf65f4: ldur            x0, [fp, #-0x10]
    // 0xcf65f8: mov             x1, x4
    // 0xcf65fc: cmp             x1, x0
    // 0xcf6600: b.hs            #0xcf677c
    // 0xcf6604: mov             x1, x2
    // 0xcf6608: ldr             x0, [fp, #0x10]
    // 0xcf660c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcf660c: add             x25, x1, x4, lsl #2
    //     0xcf6610: add             x25, x25, #0xf
    //     0xcf6614: str             w0, [x25]
    //     0xcf6618: tbz             w0, #0, #0xcf6634
    //     0xcf661c: ldurb           w16, [x1, #-1]
    //     0xcf6620: ldurb           w17, [x0, #-1]
    //     0xcf6624: and             x16, x17, x16, lsr #2
    //     0xcf6628: tst             x16, HEAP, lsr #32
    //     0xcf662c: b.eq            #0xcf6634
    //     0xcf6630: bl              #0xd67e5c
    // 0xcf6634: add             x0, x5, #2
    // 0xcf6638: LoadField: r1 = r3->field_b
    //     0xcf6638: ldur            w1, [x3, #0xb]
    // 0xcf663c: DecompressPointer r1
    //     0xcf663c: add             x1, x1, HEAP, lsl #32
    // 0xcf6640: r4 = LoadInt32Instr(r1)
    //     0xcf6640: sbfx            x4, x1, #1, #0x1f
    // 0xcf6644: mov             x7, x5
    // 0xcf6648: mov             x6, x0
    // 0xcf664c: ldur            x5, [fp, #-0x18]
    // 0xcf6650: CheckStackOverflow
    //     0xcf6650: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6654: cmp             SP, x16
    //     0xcf6658: b.ls            #0xcf6780
    // 0xcf665c: cmp             x7, x5
    // 0xcf6660: b.ge            #0xcf66d4
    // 0xcf6664: mov             x0, x4
    // 0xcf6668: mov             x1, x7
    // 0xcf666c: cmp             x1, x0
    // 0xcf6670: b.hs            #0xcf6788
    // 0xcf6674: ArrayLoad: r8 = r3[r7]  ; Unknown_4
    //     0xcf6674: add             x16, x3, x7, lsl #2
    //     0xcf6678: ldur            w8, [x16, #0xf]
    // 0xcf667c: DecompressPointer r8
    //     0xcf667c: add             x8, x8, HEAP, lsl #32
    // 0xcf6680: ldur            x0, [fp, #-0x10]
    // 0xcf6684: mov             x1, x6
    // 0xcf6688: cmp             x1, x0
    // 0xcf668c: b.hs            #0xcf678c
    // 0xcf6690: mov             x1, x2
    // 0xcf6694: mov             x0, x8
    // 0xcf6698: ArrayStore: r1[r6] = r0  ; List_4
    //     0xcf6698: add             x25, x1, x6, lsl #2
    //     0xcf669c: add             x25, x25, #0xf
    //     0xcf66a0: str             w0, [x25]
    //     0xcf66a4: tbz             w0, #0, #0xcf66c0
    //     0xcf66a8: ldurb           w16, [x1, #-1]
    //     0xcf66ac: ldurb           w17, [x0, #-1]
    //     0xcf66b0: and             x16, x17, x16, lsr #2
    //     0xcf66b4: tst             x16, HEAP, lsr #32
    //     0xcf66b8: b.eq            #0xcf66c0
    //     0xcf66bc: bl              #0xd67e5c
    // 0xcf66c0: add             x0, x7, #1
    // 0xcf66c4: add             x1, x6, #1
    // 0xcf66c8: mov             x7, x0
    // 0xcf66cc: mov             x6, x1
    // 0xcf66d0: b               #0xcf6650
    // 0xcf66d4: ldur            x0, [fp, #-0x68]
    // 0xcf66d8: ldur            x1, [fp, #-0x30]
    // 0xcf66dc: orr             x3, x1, x0
    // 0xcf66e0: stur            x3, [fp, #-0x10]
    // 0xcf66e4: r0 = _CompressedNode()
    //     0xcf66e4: bl              #0x712da0  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0xcf66e8: ldur            x1, [fp, #-0x10]
    // 0xcf66ec: StoreField: r0->field_7 = r1
    //     0xcf66ec: stur            x1, [x0, #7]
    // 0xcf66f0: ldur            x1, [fp, #-8]
    // 0xcf66f4: StoreField: r0->field_f = r1
    //     0xcf66f4: stur            w1, [x0, #0xf]
    // 0xcf66f8: LeaveFrame
    //     0xcf66f8: mov             SP, fp
    //     0xcf66fc: ldp             fp, lr, [SP], #0x10
    // 0xcf6700: ret
    //     0xcf6700: ret             
    // 0xcf6704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6704: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6708: b               #0xcf5e44
    // 0xcf670c: tbnz            x8, #0x3f, #0xcf6718
    // 0xcf6710: mov             x9, xzr
    // 0xcf6714: b               #0xcf5e68
    // 0xcf6718: str             x8, [THR, #0xc0]  ; THR::
    // 0xcf671c: stp             x7, x8, [SP, #-0x10]!
    // 0xcf6720: stp             x5, x6, [SP, #-0x10]!
    // 0xcf6724: stp             x3, x4, [SP, #-0x10]!
    // 0xcf6728: stp             x1, x2, [SP, #-0x10]!
    // 0xcf672c: SaveReg r0
    //     0xcf672c: str             x0, [SP, #-8]!
    // 0xcf6730: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcf6734: r4 = 0
    //     0xcf6734: mov             x4, #0
    // 0xcf6738: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcf673c: blr             lr
    // 0xcf6740: brk             #0
    // 0xcf6744: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6744: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf6748: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6748: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf674c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf674c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6750: b               #0xcf6070
    // 0xcf6754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6758: b               #0xcf61b0
    // 0xcf675c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf675c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6760: b               #0xcf62d8
    // 0xcf6764: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6764: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf6768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6768: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf676c: b               #0xcf6540
    // 0xcf6770: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6770: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf6774: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6774: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf6778: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6778: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf677c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf677c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf6780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6784: b               #0xcf665c
    // 0xcf6788: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6788: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf678c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf678c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _inflate(/* No info */) {
    // ** addr: 0xcf6790, size: 0x2d0
    // 0xcf6790: EnterFrame
    //     0xcf6790: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6794: mov             fp, SP
    // 0xcf6798: AllocStack(0x48)
    //     0xcf6798: sub             SP, SP, #0x48
    // 0xcf679c: CheckStackOverflow
    //     0xcf679c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf67a0: cmp             SP, x16
    //     0xcf67a4: b.ls            #0xcf6a10
    // 0xcf67a8: r1 = <Object?>
    //     0xcf67a8: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf67ac: r2 = 64
    //     0xcf67ac: mov             x2, #0x40
    // 0xcf67b0: r0 = AllocateArray()
    //     0xcf67b0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf67b4: mov             x2, x0
    // 0xcf67b8: ldr             x0, [fp, #0x18]
    // 0xcf67bc: stur            x2, [fp, #-0x40]
    // 0xcf67c0: LoadField: r3 = r0->field_7
    //     0xcf67c0: ldur            x3, [x0, #7]
    // 0xcf67c4: stur            x3, [fp, #-0x38]
    // 0xcf67c8: LoadField: r4 = r0->field_f
    //     0xcf67c8: ldur            w4, [x0, #0xf]
    // 0xcf67cc: DecompressPointer r4
    //     0xcf67cc: add             x4, x4, HEAP, lsl #32
    // 0xcf67d0: stur            x4, [fp, #-0x30]
    // 0xcf67d4: LoadField: r0 = r4->field_b
    //     0xcf67d4: ldur            w0, [x4, #0xb]
    // 0xcf67d8: DecompressPointer r0
    //     0xcf67d8: add             x0, x0, HEAP, lsl #32
    // 0xcf67dc: r5 = LoadInt32Instr(r0)
    //     0xcf67dc: sbfx            x5, x0, #1, #0x1f
    // 0xcf67e0: ldr             x0, [fp, #0x10]
    // 0xcf67e4: stur            x5, [fp, #-0x28]
    // 0xcf67e8: add             x6, x0, #5
    // 0xcf67ec: r0 = BoxInt64Instr(r6)
    //     0xcf67ec: sbfiz           x0, x6, #1, #0x1f
    //     0xcf67f0: cmp             x6, x0, asr #1
    //     0xcf67f4: b.eq            #0xcf6800
    //     0xcf67f8: bl              #0xd69bb8
    //     0xcf67fc: stur            x6, [x0, #7]
    // 0xcf6800: mov             x6, x0
    // 0xcf6804: stur            x6, [fp, #-0x20]
    // 0xcf6808: r9 = 0
    //     0xcf6808: mov             x9, #0
    // 0xcf680c: r8 = 0
    //     0xcf680c: mov             x8, #0
    // 0xcf6810: r7 = 1
    //     0xcf6810: mov             x7, #1
    // 0xcf6814: stur            x9, [fp, #-0x10]
    // 0xcf6818: stur            x8, [fp, #-0x18]
    // 0xcf681c: CheckStackOverflow
    //     0xcf681c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6820: cmp             SP, x16
    //     0xcf6824: b.ls            #0xcf6a18
    // 0xcf6828: cmp             x8, #0x20
    // 0xcf682c: b.ge            #0xcf69f4
    // 0xcf6830: cmp             x8, #0x3f
    // 0xcf6834: b.hi            #0xcf6a20
    // 0xcf6838: lsr             x0, x3, x8
    // 0xcf683c: ubfx            x0, x0, #0, #0x20
    // 0xcf6840: and             x1, x0, x7
    // 0xcf6844: ubfx            x1, x1, #0, #0x20
    // 0xcf6848: cbz             x1, #0xcf69cc
    // 0xcf684c: mov             x0, x5
    // 0xcf6850: mov             x1, x9
    // 0xcf6854: cmp             x1, x0
    // 0xcf6858: b.hs            #0xcf6a54
    // 0xcf685c: ArrayLoad: r0 = r4[r9]  ; Unknown_4
    //     0xcf685c: add             x16, x4, x9, lsl #2
    //     0xcf6860: ldur            w0, [x16, #0xf]
    // 0xcf6864: DecompressPointer r0
    //     0xcf6864: add             x0, x0, HEAP, lsl #32
    // 0xcf6868: stur            x0, [fp, #-8]
    // 0xcf686c: cmp             w0, NULL
    // 0xcf6870: b.ne            #0xcf68cc
    // 0xcf6874: add             x10, x9, #1
    // 0xcf6878: mov             x0, x5
    // 0xcf687c: mov             x1, x10
    // 0xcf6880: cmp             x1, x0
    // 0xcf6884: b.hs            #0xcf6a58
    // 0xcf6888: ArrayLoad: r0 = r4[r10]  ; Unknown_4
    //     0xcf6888: add             x16, x4, x10, lsl #2
    //     0xcf688c: ldur            w0, [x16, #0xf]
    // 0xcf6890: DecompressPointer r0
    //     0xcf6890: add             x0, x0, HEAP, lsl #32
    // 0xcf6894: mov             x1, x2
    // 0xcf6898: ArrayStore: r1[r8] = r0  ; List_4
    //     0xcf6898: add             x25, x1, x8, lsl #2
    //     0xcf689c: add             x25, x25, #0xf
    //     0xcf68a0: str             w0, [x25]
    //     0xcf68a4: tbz             w0, #0, #0xcf68c0
    //     0xcf68a8: ldurb           w16, [x1, #-1]
    //     0xcf68ac: ldurb           w17, [x0, #-1]
    //     0xcf68b0: and             x16, x17, x16, lsr #2
    //     0xcf68b4: tst             x16, HEAP, lsr #32
    //     0xcf68b8: b.eq            #0xcf68c0
    //     0xcf68bc: bl              #0xd67e5c
    // 0xcf68c0: mov             x0, x9
    // 0xcf68c4: mov             x2, x8
    // 0xcf68c8: b               #0xcf69c0
    // 0xcf68cc: r0 = InitLateStaticField(0xd18) // [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::empty
    //     0xcf68cc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcf68d0: ldr             x0, [x0, #0x1a30]
    //     0xcf68d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcf68d8: cmp             w0, w16
    //     0xcf68dc: b.ne            #0xcf68ec
    //     0xcf68e0: add             x2, PP, #0x22, lsl #12  ; [pp+0x229c0] Field <_CompressedNode@644137193.empty>: static late final (offset: 0xd18)
    //     0xcf68e4: ldr             x2, [x2, #0x9c0]
    //     0xcf68e8: bl              #0xd67cdc
    // 0xcf68ec: mov             x3, x0
    // 0xcf68f0: ldur            x2, [fp, #-0x10]
    // 0xcf68f4: ldur            x1, [fp, #-0x30]
    // 0xcf68f8: stur            x3, [fp, #-0x48]
    // 0xcf68fc: ArrayLoad: r0 = r1[r2]  ; Unknown_4
    //     0xcf68fc: add             x16, x1, x2, lsl #2
    //     0xcf6900: ldur            w0, [x16, #0xf]
    // 0xcf6904: DecompressPointer r0
    //     0xcf6904: add             x0, x0, HEAP, lsl #32
    // 0xcf6908: r4 = 59
    //     0xcf6908: mov             x4, #0x3b
    // 0xcf690c: branchIfSmi(r0, 0xcf6918)
    //     0xcf690c: tbz             w0, #0, #0xcf6918
    // 0xcf6910: r4 = LoadClassIdInstr(r0)
    //     0xcf6910: ldur            x4, [x0, #-1]
    //     0xcf6914: ubfx            x4, x4, #0xc, #0x14
    // 0xcf6918: SaveReg r0
    //     0xcf6918: str             x0, [SP, #-8]!
    // 0xcf691c: mov             x0, x4
    // 0xcf6920: r0 = GDT[cid_x0 + 0x2721]()
    //     0xcf6920: mov             x17, #0x2721
    //     0xcf6924: add             lr, x0, x17
    //     0xcf6928: ldr             lr, [x21, lr, lsl #3]
    //     0xcf692c: blr             lr
    // 0xcf6930: add             SP, SP, #8
    // 0xcf6934: mov             x3, x0
    // 0xcf6938: ldur            x2, [fp, #-0x10]
    // 0xcf693c: add             x4, x2, #1
    // 0xcf6940: ldur            x0, [fp, #-0x28]
    // 0xcf6944: mov             x1, x4
    // 0xcf6948: cmp             x1, x0
    // 0xcf694c: b.hs            #0xcf6a5c
    // 0xcf6950: ldur            x0, [fp, #-0x30]
    // 0xcf6954: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0xcf6954: add             x16, x0, x4, lsl #2
    //     0xcf6958: ldur            w1, [x16, #0xf]
    // 0xcf695c: DecompressPointer r1
    //     0xcf695c: add             x1, x1, HEAP, lsl #32
    // 0xcf6960: r4 = LoadInt32Instr(r3)
    //     0xcf6960: sbfx            x4, x3, #1, #0x1f
    //     0xcf6964: tbz             w3, #0, #0xcf696c
    //     0xcf6968: ldur            x4, [x3, #7]
    // 0xcf696c: ldur            x16, [fp, #-0x48]
    // 0xcf6970: ldur            lr, [fp, #-0x20]
    // 0xcf6974: stp             lr, x16, [SP, #-0x10]!
    // 0xcf6978: ldur            x16, [fp, #-8]
    // 0xcf697c: stp             x4, x16, [SP, #-0x10]!
    // 0xcf6980: SaveReg r1
    //     0xcf6980: str             x1, [SP, #-8]!
    // 0xcf6984: r0 = put()
    //     0xcf6984: bl              #0xcf5e04  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::put
    // 0xcf6988: add             SP, SP, #0x28
    // 0xcf698c: ldur            x1, [fp, #-0x40]
    // 0xcf6990: ldur            x2, [fp, #-0x18]
    // 0xcf6994: ArrayStore: r1[r2] = r0  ; List_4
    //     0xcf6994: add             x25, x1, x2, lsl #2
    //     0xcf6998: add             x25, x25, #0xf
    //     0xcf699c: str             w0, [x25]
    //     0xcf69a0: tbz             w0, #0, #0xcf69bc
    //     0xcf69a4: ldurb           w16, [x1, #-1]
    //     0xcf69a8: ldurb           w17, [x0, #-1]
    //     0xcf69ac: and             x16, x17, x16, lsr #2
    //     0xcf69b0: tst             x16, HEAP, lsr #32
    //     0xcf69b4: b.eq            #0xcf69bc
    //     0xcf69b8: bl              #0xd67e5c
    // 0xcf69bc: ldur            x0, [fp, #-0x10]
    // 0xcf69c0: add             x1, x0, #2
    // 0xcf69c4: mov             x9, x1
    // 0xcf69c8: b               #0xcf69d8
    // 0xcf69cc: mov             x0, x9
    // 0xcf69d0: mov             x2, x8
    // 0xcf69d4: mov             x9, x0
    // 0xcf69d8: add             x8, x2, #1
    // 0xcf69dc: ldur            x3, [fp, #-0x38]
    // 0xcf69e0: ldur            x4, [fp, #-0x30]
    // 0xcf69e4: ldur            x2, [fp, #-0x40]
    // 0xcf69e8: ldur            x5, [fp, #-0x28]
    // 0xcf69ec: ldur            x6, [fp, #-0x20]
    // 0xcf69f0: b               #0xcf6810
    // 0xcf69f4: mov             x0, x2
    // 0xcf69f8: r0 = _FullNode()
    //     0xcf69f8: bl              #0xcf5df8  ; Allocate_FullNodeStub -> _FullNode (size=0xc)
    // 0xcf69fc: ldur            x1, [fp, #-0x40]
    // 0xcf6a00: StoreField: r0->field_7 = r1
    //     0xcf6a00: stur            w1, [x0, #7]
    // 0xcf6a04: LeaveFrame
    //     0xcf6a04: mov             SP, fp
    //     0xcf6a08: ldp             fp, lr, [SP], #0x10
    // 0xcf6a0c: ret
    //     0xcf6a0c: ret             
    // 0xcf6a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6a10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6a14: b               #0xcf67a8
    // 0xcf6a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6a18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6a1c: b               #0xcf6828
    // 0xcf6a20: tbnz            x8, #0x3f, #0xcf6a2c
    // 0xcf6a24: mov             x0, xzr
    // 0xcf6a28: b               #0xcf683c
    // 0xcf6a2c: str             x8, [THR, #0xc0]  ; THR::
    // 0xcf6a30: stp             x8, x9, [SP, #-0x10]!
    // 0xcf6a34: stp             x6, x7, [SP, #-0x10]!
    // 0xcf6a38: stp             x4, x5, [SP, #-0x10]!
    // 0xcf6a3c: stp             x2, x3, [SP, #-0x10]!
    // 0xcf6a40: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcf6a44: r4 = 0
    //     0xcf6a44: mov             x4, #0
    // 0xcf6a48: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcf6a4c: blr             lr
    // 0xcf6a50: brk             #0
    // 0xcf6a54: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6a54: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf6a58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6a58: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf6a5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf6a5c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _resolveCollision(/* No info */) {
    // ** addr: 0xcf6a60, size: 0x118
    // 0xcf6a60: EnterFrame
    //     0xcf6a60: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6a64: mov             fp, SP
    // 0xcf6a68: AllocStack(0x8)
    //     0xcf6a68: sub             SP, SP, #8
    // 0xcf6a6c: CheckStackOverflow
    //     0xcf6a6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6a70: cmp             SP, x16
    //     0xcf6a74: b.ls            #0xcf6b70
    // 0xcf6a78: ldr             x1, [fp, #0x30]
    // 0xcf6a7c: r0 = 59
    //     0xcf6a7c: mov             x0, #0x3b
    // 0xcf6a80: branchIfSmi(r1, 0xcf6a8c)
    //     0xcf6a80: tbz             w1, #0, #0xcf6a8c
    // 0xcf6a84: r0 = LoadClassIdInstr(r1)
    //     0xcf6a84: ldur            x0, [x1, #-1]
    //     0xcf6a88: ubfx            x0, x0, #0xc, #0x14
    // 0xcf6a8c: SaveReg r1
    //     0xcf6a8c: str             x1, [SP, #-8]!
    // 0xcf6a90: r0 = GDT[cid_x0 + 0x2721]()
    //     0xcf6a90: mov             x17, #0x2721
    //     0xcf6a94: add             lr, x0, x17
    //     0xcf6a98: ldr             lr, [x21, lr, lsl #3]
    //     0xcf6a9c: blr             lr
    // 0xcf6aa0: add             SP, SP, #8
    // 0xcf6aa4: r1 = LoadInt32Instr(r0)
    //     0xcf6aa4: sbfx            x1, x0, #1, #0x1f
    //     0xcf6aa8: tbz             w0, #0, #0xcf6ab0
    //     0xcf6aac: ldur            x1, [x0, #7]
    // 0xcf6ab0: ldr             x0, [fp, #0x18]
    // 0xcf6ab4: stur            x1, [fp, #-8]
    // 0xcf6ab8: cmp             x1, x0
    // 0xcf6abc: b.ne            #0xcf6ae8
    // 0xcf6ac0: stp             x0, NULL, [SP, #-0x10]!
    // 0xcf6ac4: ldr             x16, [fp, #0x30]
    // 0xcf6ac8: ldr             lr, [fp, #0x28]
    // 0xcf6acc: stp             lr, x16, [SP, #-0x10]!
    // 0xcf6ad0: ldr             x16, [fp, #0x20]
    // 0xcf6ad4: ldr             lr, [fp, #0x10]
    // 0xcf6ad8: stp             lr, x16, [SP, #-0x10]!
    // 0xcf6adc: r0 = _HashCollisionNode.fromCollision()
    //     0xcf6adc: bl              #0xcf6b78  ; [package:flutter/src/foundation/persistent_hash_map.dart] _HashCollisionNode::_HashCollisionNode.fromCollision
    // 0xcf6ae0: add             SP, SP, #0x30
    // 0xcf6ae4: b               #0xcf6b64
    // 0xcf6ae8: r0 = InitLateStaticField(0xd18) // [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::empty
    //     0xcf6ae8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcf6aec: ldr             x0, [x0, #0x1a30]
    //     0xcf6af0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcf6af4: cmp             w0, w16
    //     0xcf6af8: b.ne            #0xcf6b08
    //     0xcf6afc: add             x2, PP, #0x22, lsl #12  ; [pp+0x229c0] Field <_CompressedNode@644137193.empty>: static late final (offset: 0xd18)
    //     0xcf6b00: ldr             x2, [x2, #0x9c0]
    //     0xcf6b04: bl              #0xd67cdc
    // 0xcf6b08: ldr             x16, [fp, #0x38]
    // 0xcf6b0c: stp             x16, x0, [SP, #-0x10]!
    // 0xcf6b10: ldr             x16, [fp, #0x30]
    // 0xcf6b14: SaveReg r16
    //     0xcf6b14: str             x16, [SP, #-8]!
    // 0xcf6b18: ldur            x0, [fp, #-8]
    // 0xcf6b1c: ldr             x16, [fp, #0x28]
    // 0xcf6b20: stp             x16, x0, [SP, #-0x10]!
    // 0xcf6b24: r0 = put()
    //     0xcf6b24: bl              #0xcf5e04  ; [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::put
    // 0xcf6b28: add             SP, SP, #0x28
    // 0xcf6b2c: r1 = LoadClassIdInstr(r0)
    //     0xcf6b2c: ldur            x1, [x0, #-1]
    //     0xcf6b30: ubfx            x1, x1, #0xc, #0x14
    // 0xcf6b34: ldr             x16, [fp, #0x38]
    // 0xcf6b38: stp             x16, x0, [SP, #-0x10]!
    // 0xcf6b3c: ldr             x16, [fp, #0x20]
    // 0xcf6b40: SaveReg r16
    //     0xcf6b40: str             x16, [SP, #-8]!
    // 0xcf6b44: ldr             x0, [fp, #0x18]
    // 0xcf6b48: ldr             x16, [fp, #0x10]
    // 0xcf6b4c: stp             x16, x0, [SP, #-0x10]!
    // 0xcf6b50: mov             x0, x1
    // 0xcf6b54: r0 = GDT[cid_x0 + -0xfff]()
    //     0xcf6b54: sub             lr, x0, #0xfff
    //     0xcf6b58: ldr             lr, [x21, lr, lsl #3]
    //     0xcf6b5c: blr             lr
    // 0xcf6b60: add             SP, SP, #0x28
    // 0xcf6b64: LeaveFrame
    //     0xcf6b64: mov             SP, fp
    //     0xcf6b68: ldp             fp, lr, [SP], #0x10
    // 0xcf6b6c: ret
    //     0xcf6b6c: ret             
    // 0xcf6b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf6b70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf6b74: b               #0xcf6a78
  }
  factory _ _CompressedNode.single(/* No info */) {
    // ** addr: 0xcf6f20, size: 0xb0
    // 0xcf6f20: EnterFrame
    //     0xcf6f20: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6f24: mov             fp, SP
    // 0xcf6f28: AllocStack(0x10)
    //     0xcf6f28: sub             SP, SP, #0x10
    // 0xcf6f2c: r1 = 1
    //     0xcf6f2c: mov             x1, #1
    // 0xcf6f30: r0 = 31
    //     0xcf6f30: mov             x0, #0x1f
    // 0xcf6f34: ldr             x2, [fp, #0x20]
    // 0xcf6f38: r3 = LoadInt32Instr(r2)
    //     0xcf6f38: sbfx            x3, x2, #1, #0x1f
    //     0xcf6f3c: tbz             w2, #0, #0xcf6f44
    //     0xcf6f40: ldur            x3, [x2, #7]
    // 0xcf6f44: ldr             x2, [fp, #0x18]
    // 0xcf6f48: cmp             x3, #0x3f
    // 0xcf6f4c: b.hi            #0xcf6fa4
    // 0xcf6f50: lsr             x4, x2, x3
    // 0xcf6f54: ubfx            x4, x4, #0, #0x20
    // 0xcf6f58: and             x2, x4, x0
    // 0xcf6f5c: ubfx            x2, x2, #0, #0x20
    // 0xcf6f60: lsl             x0, x1, x2
    // 0xcf6f64: stur            x0, [fp, #-8]
    // 0xcf6f68: r1 = <Object?>
    //     0xcf6f68: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf6f6c: r2 = 4
    //     0xcf6f6c: mov             x2, #4
    // 0xcf6f70: r0 = AllocateArray()
    //     0xcf6f70: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf6f74: mov             x1, x0
    // 0xcf6f78: ldr             x0, [fp, #0x10]
    // 0xcf6f7c: stur            x1, [fp, #-0x10]
    // 0xcf6f80: StoreField: r1->field_13 = r0
    //     0xcf6f80: stur            w0, [x1, #0x13]
    // 0xcf6f84: r0 = _CompressedNode()
    //     0xcf6f84: bl              #0x712da0  ; Allocate_CompressedNodeStub -> _CompressedNode (size=0x14)
    // 0xcf6f88: ldur            x1, [fp, #-8]
    // 0xcf6f8c: StoreField: r0->field_7 = r1
    //     0xcf6f8c: stur            x1, [x0, #7]
    // 0xcf6f90: ldur            x1, [fp, #-0x10]
    // 0xcf6f94: StoreField: r0->field_f = r1
    //     0xcf6f94: stur            w1, [x0, #0xf]
    // 0xcf6f98: LeaveFrame
    //     0xcf6f98: mov             SP, fp
    //     0xcf6f9c: ldp             fp, lr, [SP], #0x10
    // 0xcf6fa0: ret
    //     0xcf6fa0: ret             
    // 0xcf6fa4: tbnz            x3, #0x3f, #0xcf6fb0
    // 0xcf6fa8: mov             x4, xzr
    // 0xcf6fac: b               #0xcf6f54
    // 0xcf6fb0: str             x3, [THR, #0xc0]  ; THR::
    // 0xcf6fb4: stp             x2, x3, [SP, #-0x10]!
    // 0xcf6fb8: stp             x0, x1, [SP, #-0x10]!
    // 0xcf6fbc: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcf6fc0: r4 = 0
    //     0xcf6fc0: mov             x4, #0
    // 0xcf6fc4: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcf6fc8: blr             lr
    // 0xcf6fcc: brk             #0
  }
}

// class id: 2375, size: 0xc, field offset: 0x8
class _FullNode extends _TrieNode {

  _ get(/* No info */) {
    // ** addr: 0xcf5700, size: 0x160
    // 0xcf5700: EnterFrame
    //     0xcf5700: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5704: mov             fp, SP
    // 0xcf5708: AllocStack(0x10)
    //     0xcf5708: sub             SP, SP, #0x10
    // 0xcf570c: r0 = 31
    //     0xcf570c: mov             x0, #0x1f
    // 0xcf5710: CheckStackOverflow
    //     0xcf5710: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf5714: cmp             SP, x16
    //     0xcf5718: b.ls            #0xcf5828
    // 0xcf571c: ldr             x1, [fp, #0x20]
    // 0xcf5720: r3 = LoadInt32Instr(r1)
    //     0xcf5720: sbfx            x3, x1, #1, #0x1f
    //     0xcf5724: tbz             w1, #0, #0xcf572c
    //     0xcf5728: ldur            x3, [x1, #7]
    // 0xcf572c: ldr             x4, [fp, #0x10]
    // 0xcf5730: stur            x3, [fp, #-0x10]
    // 0xcf5734: cmp             x3, #0x3f
    // 0xcf5738: b.hi            #0xcf5830
    // 0xcf573c: lsr             x1, x4, x3
    // 0xcf5740: ubfx            x1, x1, #0, #0x20
    // 0xcf5744: and             x2, x1, x0
    // 0xcf5748: ldr             x0, [fp, #0x28]
    // 0xcf574c: LoadField: r5 = r0->field_7
    //     0xcf574c: ldur            w5, [x0, #7]
    // 0xcf5750: DecompressPointer r5
    //     0xcf5750: add             x5, x5, HEAP, lsl #32
    // 0xcf5754: LoadField: r0 = r5->field_b
    //     0xcf5754: ldur            w0, [x5, #0xb]
    // 0xcf5758: DecompressPointer r0
    //     0xcf5758: add             x0, x0, HEAP, lsl #32
    // 0xcf575c: r1 = LoadInt32Instr(r0)
    //     0xcf575c: sbfx            x1, x0, #1, #0x1f
    // 0xcf5760: ubfx            x2, x2, #0, #0x20
    // 0xcf5764: mov             x0, x1
    // 0xcf5768: mov             x1, x2
    // 0xcf576c: cmp             x1, x0
    // 0xcf5770: b.hs            #0xcf585c
    // 0xcf5774: ArrayLoad: r6 = r5[r2]  ; Unknown_4
    //     0xcf5774: add             x16, x5, x2, lsl #2
    //     0xcf5778: ldur            w6, [x16, #0xf]
    // 0xcf577c: DecompressPointer r6
    //     0xcf577c: add             x6, x6, HEAP, lsl #32
    // 0xcf5780: mov             x0, x6
    // 0xcf5784: stur            x6, [fp, #-8]
    // 0xcf5788: r2 = Null
    //     0xcf5788: mov             x2, NULL
    // 0xcf578c: r1 = Null
    //     0xcf578c: mov             x1, NULL
    // 0xcf5790: r4 = 59
    //     0xcf5790: mov             x4, #0x3b
    // 0xcf5794: branchIfSmi(r0, 0xcf57a0)
    //     0xcf5794: tbz             w0, #0, #0xcf57a0
    // 0xcf5798: r4 = LoadClassIdInstr(r0)
    //     0xcf5798: ldur            x4, [x0, #-1]
    //     0xcf579c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf57a0: sub             x4, x4, #0x945
    // 0xcf57a4: cmp             x4, #2
    // 0xcf57a8: b.ls            #0xcf57c0
    // 0xcf57ac: r8 = _TrieNode?
    //     0xcf57ac: add             x8, PP, #0xe, lsl #12  ; [pp+0xe0d8] Type: _TrieNode?
    //     0xcf57b0: ldr             x8, [x8, #0xd8]
    // 0xcf57b4: r3 = Null
    //     0xcf57b4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e978] Null
    //     0xcf57b8: ldr             x3, [x3, #0x978]
    // 0xcf57bc: r0 = DefaultNullableTypeTest()
    //     0xcf57bc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xcf57c0: ldur            x2, [fp, #-8]
    // 0xcf57c4: cmp             w2, NULL
    // 0xcf57c8: b.ne            #0xcf57d4
    // 0xcf57cc: r0 = Null
    //     0xcf57cc: mov             x0, NULL
    // 0xcf57d0: b               #0xcf581c
    // 0xcf57d4: ldr             x3, [fp, #0x10]
    // 0xcf57d8: ldur            x0, [fp, #-0x10]
    // 0xcf57dc: add             x4, x0, #5
    // 0xcf57e0: r0 = BoxInt64Instr(r4)
    //     0xcf57e0: sbfiz           x0, x4, #1, #0x1f
    //     0xcf57e4: cmp             x4, x0, asr #1
    //     0xcf57e8: b.eq            #0xcf57f4
    //     0xcf57ec: bl              #0xd69bb8
    //     0xcf57f0: stur            x4, [x0, #7]
    // 0xcf57f4: r1 = LoadClassIdInstr(r2)
    //     0xcf57f4: ldur            x1, [x2, #-1]
    //     0xcf57f8: ubfx            x1, x1, #0xc, #0x14
    // 0xcf57fc: stp             x0, x2, [SP, #-0x10]!
    // 0xcf5800: ldr             x16, [fp, #0x18]
    // 0xcf5804: stp             x3, x16, [SP, #-0x10]!
    // 0xcf5808: mov             x0, x1
    // 0xcf580c: r0 = GDT[cid_x0 + -0xff9]()
    //     0xcf580c: sub             lr, x0, #0xff9
    //     0xcf5810: ldr             lr, [x21, lr, lsl #3]
    //     0xcf5814: blr             lr
    // 0xcf5818: add             SP, SP, #0x20
    // 0xcf581c: LeaveFrame
    //     0xcf581c: mov             SP, fp
    //     0xcf5820: ldp             fp, lr, [SP], #0x10
    // 0xcf5824: ret
    //     0xcf5824: ret             
    // 0xcf5828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf582c: b               #0xcf571c
    // 0xcf5830: tbnz            x3, #0x3f, #0xcf583c
    // 0xcf5834: mov             x1, xzr
    // 0xcf5838: b               #0xcf5740
    // 0xcf583c: str             x3, [THR, #0xc0]  ; THR::
    // 0xcf5840: stp             x3, x4, [SP, #-0x10]!
    // 0xcf5844: SaveReg r0
    //     0xcf5844: str             x0, [SP, #-8]!
    // 0xcf5848: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcf584c: r4 = 0
    //     0xcf584c: mov             x4, #0
    // 0xcf5850: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcf5854: blr             lr
    // 0xcf5858: brk             #0
    // 0xcf585c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf585c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ put(/* No info */) {
    // ** addr: 0xcf5b78, size: 0x280
    // 0xcf5b78: EnterFrame
    //     0xcf5b78: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5b7c: mov             fp, SP
    // 0xcf5b80: AllocStack(0x38)
    //     0xcf5b80: sub             SP, SP, #0x38
    // 0xcf5b84: r0 = 31
    //     0xcf5b84: mov             x0, #0x1f
    // 0xcf5b88: CheckStackOverflow
    //     0xcf5b88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf5b8c: cmp             SP, x16
    //     0xcf5b90: b.ls            #0xcf5db8
    // 0xcf5b94: ldr             x1, [fp, #0x28]
    // 0xcf5b98: r3 = LoadInt32Instr(r1)
    //     0xcf5b98: sbfx            x3, x1, #1, #0x1f
    //     0xcf5b9c: tbz             w1, #0, #0xcf5ba4
    //     0xcf5ba0: ldur            x3, [x1, #7]
    // 0xcf5ba4: ldr             x4, [fp, #0x18]
    // 0xcf5ba8: stur            x3, [fp, #-0x30]
    // 0xcf5bac: cmp             x3, #0x3f
    // 0xcf5bb0: b.hi            #0xcf5dc0
    // 0xcf5bb4: lsr             x1, x4, x3
    // 0xcf5bb8: ubfx            x1, x1, #0, #0x20
    // 0xcf5bbc: and             x2, x1, x0
    // 0xcf5bc0: ldr             x5, [fp, #0x30]
    // 0xcf5bc4: LoadField: r6 = r5->field_7
    //     0xcf5bc4: ldur            w6, [x5, #7]
    // 0xcf5bc8: DecompressPointer r6
    //     0xcf5bc8: add             x6, x6, HEAP, lsl #32
    // 0xcf5bcc: stur            x6, [fp, #-0x28]
    // 0xcf5bd0: LoadField: r7 = r6->field_b
    //     0xcf5bd0: ldur            w7, [x6, #0xb]
    // 0xcf5bd4: DecompressPointer r7
    //     0xcf5bd4: add             x7, x7, HEAP, lsl #32
    // 0xcf5bd8: stur            x7, [fp, #-0x20]
    // 0xcf5bdc: r8 = LoadInt32Instr(r7)
    //     0xcf5bdc: sbfx            x8, x7, #1, #0x1f
    // 0xcf5be0: stur            x8, [fp, #-0x18]
    // 0xcf5be4: mov             x9, x2
    // 0xcf5be8: ubfx            x9, x9, #0, #0x20
    // 0xcf5bec: mov             x0, x8
    // 0xcf5bf0: mov             x1, x9
    // 0xcf5bf4: stur            x9, [fp, #-0x10]
    // 0xcf5bf8: cmp             x1, x0
    // 0xcf5bfc: b.hs            #0xcf5dec
    // 0xcf5c00: ArrayLoad: r10 = r6[r9]  ; Unknown_4
    //     0xcf5c00: add             x16, x6, x9, lsl #2
    //     0xcf5c04: ldur            w10, [x16, #0xf]
    // 0xcf5c08: DecompressPointer r10
    //     0xcf5c08: add             x10, x10, HEAP, lsl #32
    // 0xcf5c0c: mov             x0, x10
    // 0xcf5c10: stur            x10, [fp, #-8]
    // 0xcf5c14: r2 = Null
    //     0xcf5c14: mov             x2, NULL
    // 0xcf5c18: r1 = Null
    //     0xcf5c18: mov             x1, NULL
    // 0xcf5c1c: r4 = 59
    //     0xcf5c1c: mov             x4, #0x3b
    // 0xcf5c20: branchIfSmi(r0, 0xcf5c2c)
    //     0xcf5c20: tbz             w0, #0, #0xcf5c2c
    // 0xcf5c24: r4 = LoadClassIdInstr(r0)
    //     0xcf5c24: ldur            x4, [x0, #-1]
    //     0xcf5c28: ubfx            x4, x4, #0xc, #0x14
    // 0xcf5c2c: sub             x4, x4, #0x945
    // 0xcf5c30: cmp             x4, #2
    // 0xcf5c34: b.ls            #0xcf5c4c
    // 0xcf5c38: r8 = _TrieNode?
    //     0xcf5c38: add             x8, PP, #0xe, lsl #12  ; [pp+0xe0d8] Type: _TrieNode?
    //     0xcf5c3c: ldr             x8, [x8, #0xd8]
    // 0xcf5c40: r3 = Null
    //     0xcf5c40: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e988] Null
    //     0xcf5c44: ldr             x3, [x3, #0x988]
    // 0xcf5c48: r0 = DefaultNullableTypeTest()
    //     0xcf5c48: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xcf5c4c: ldur            x0, [fp, #-8]
    // 0xcf5c50: cmp             w0, NULL
    // 0xcf5c54: b.ne            #0xcf5c80
    // 0xcf5c58: r0 = InitLateStaticField(0xd18) // [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::empty
    //     0xcf5c58: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcf5c5c: ldr             x0, [x0, #0x1a30]
    //     0xcf5c60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcf5c64: cmp             w0, w16
    //     0xcf5c68: b.ne            #0xcf5c78
    //     0xcf5c6c: add             x2, PP, #0x22, lsl #12  ; [pp+0x229c0] Field <_CompressedNode@644137193.empty>: static late final (offset: 0xd18)
    //     0xcf5c70: ldr             x2, [x2, #0x9c0]
    //     0xcf5c74: bl              #0xd67cdc
    // 0xcf5c78: mov             x3, x0
    // 0xcf5c7c: b               #0xcf5c84
    // 0xcf5c80: mov             x3, x0
    // 0xcf5c84: ldr             x2, [fp, #0x18]
    // 0xcf5c88: ldur            x0, [fp, #-0x30]
    // 0xcf5c8c: stur            x3, [fp, #-8]
    // 0xcf5c90: add             x4, x0, #5
    // 0xcf5c94: r0 = BoxInt64Instr(r4)
    //     0xcf5c94: sbfiz           x0, x4, #1, #0x1f
    //     0xcf5c98: cmp             x4, x0, asr #1
    //     0xcf5c9c: b.eq            #0xcf5ca8
    //     0xcf5ca0: bl              #0xd69bb8
    //     0xcf5ca4: stur            x4, [x0, #7]
    // 0xcf5ca8: r1 = LoadClassIdInstr(r3)
    //     0xcf5ca8: ldur            x1, [x3, #-1]
    //     0xcf5cac: ubfx            x1, x1, #0xc, #0x14
    // 0xcf5cb0: stp             x0, x3, [SP, #-0x10]!
    // 0xcf5cb4: ldr             x16, [fp, #0x20]
    // 0xcf5cb8: stp             x2, x16, [SP, #-0x10]!
    // 0xcf5cbc: ldr             x16, [fp, #0x10]
    // 0xcf5cc0: SaveReg r16
    //     0xcf5cc0: str             x16, [SP, #-8]!
    // 0xcf5cc4: mov             x0, x1
    // 0xcf5cc8: r0 = GDT[cid_x0 + -0xfff]()
    //     0xcf5cc8: sub             lr, x0, #0xfff
    //     0xcf5ccc: ldr             lr, [x21, lr, lsl #3]
    //     0xcf5cd0: blr             lr
    // 0xcf5cd4: add             SP, SP, #0x28
    // 0xcf5cd8: mov             x3, x0
    // 0xcf5cdc: ldur            x0, [fp, #-8]
    // 0xcf5ce0: stur            x3, [fp, #-0x38]
    // 0xcf5ce4: cmp             w3, w0
    // 0xcf5ce8: b.ne            #0xcf5cf4
    // 0xcf5cec: ldr             x0, [fp, #0x30]
    // 0xcf5cf0: b               #0xcf5dac
    // 0xcf5cf4: ldur            x2, [fp, #-0x20]
    // 0xcf5cf8: r1 = <Object?>
    //     0xcf5cf8: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xcf5cfc: r0 = AllocateArray()
    //     0xcf5cfc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcf5d00: mov             x2, x0
    // 0xcf5d04: stur            x2, [fp, #-8]
    // 0xcf5d08: ldur            x3, [fp, #-0x28]
    // 0xcf5d0c: ldur            x4, [fp, #-0x18]
    // 0xcf5d10: r5 = 0
    //     0xcf5d10: mov             x5, #0
    // 0xcf5d14: CheckStackOverflow
    //     0xcf5d14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf5d18: cmp             SP, x16
    //     0xcf5d1c: b.ls            #0xcf5df0
    // 0xcf5d20: cmp             x5, x4
    // 0xcf5d24: b.ge            #0xcf5d6c
    // 0xcf5d28: ArrayLoad: r0 = r3[r5]  ; Unknown_4
    //     0xcf5d28: add             x16, x3, x5, lsl #2
    //     0xcf5d2c: ldur            w0, [x16, #0xf]
    // 0xcf5d30: DecompressPointer r0
    //     0xcf5d30: add             x0, x0, HEAP, lsl #32
    // 0xcf5d34: mov             x1, x2
    // 0xcf5d38: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcf5d38: add             x25, x1, x5, lsl #2
    //     0xcf5d3c: add             x25, x25, #0xf
    //     0xcf5d40: str             w0, [x25]
    //     0xcf5d44: tbz             w0, #0, #0xcf5d60
    //     0xcf5d48: ldurb           w16, [x1, #-1]
    //     0xcf5d4c: ldurb           w17, [x0, #-1]
    //     0xcf5d50: and             x16, x17, x16, lsr #2
    //     0xcf5d54: tst             x16, HEAP, lsr #32
    //     0xcf5d58: b.eq            #0xcf5d60
    //     0xcf5d5c: bl              #0xd67e5c
    // 0xcf5d60: add             x0, x5, #1
    // 0xcf5d64: mov             x5, x0
    // 0xcf5d68: b               #0xcf5d14
    // 0xcf5d6c: ldur            x3, [fp, #-0x10]
    // 0xcf5d70: mov             x1, x2
    // 0xcf5d74: ldur            x0, [fp, #-0x38]
    // 0xcf5d78: ArrayStore: r1[r3] = r0  ; List_4
    //     0xcf5d78: add             x25, x1, x3, lsl #2
    //     0xcf5d7c: add             x25, x25, #0xf
    //     0xcf5d80: str             w0, [x25]
    //     0xcf5d84: tbz             w0, #0, #0xcf5da0
    //     0xcf5d88: ldurb           w16, [x1, #-1]
    //     0xcf5d8c: ldurb           w17, [x0, #-1]
    //     0xcf5d90: and             x16, x17, x16, lsr #2
    //     0xcf5d94: tst             x16, HEAP, lsr #32
    //     0xcf5d98: b.eq            #0xcf5da0
    //     0xcf5d9c: bl              #0xd67e5c
    // 0xcf5da0: r0 = _FullNode()
    //     0xcf5da0: bl              #0xcf5df8  ; Allocate_FullNodeStub -> _FullNode (size=0xc)
    // 0xcf5da4: ldur            x1, [fp, #-8]
    // 0xcf5da8: StoreField: r0->field_7 = r1
    //     0xcf5da8: stur            w1, [x0, #7]
    // 0xcf5dac: LeaveFrame
    //     0xcf5dac: mov             SP, fp
    //     0xcf5db0: ldp             fp, lr, [SP], #0x10
    // 0xcf5db4: ret
    //     0xcf5db4: ret             
    // 0xcf5db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5db8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5dbc: b               #0xcf5b94
    // 0xcf5dc0: tbnz            x3, #0x3f, #0xcf5dcc
    // 0xcf5dc4: mov             x1, xzr
    // 0xcf5dc8: b               #0xcf5bb8
    // 0xcf5dcc: str             x3, [THR, #0xc0]  ; THR::
    // 0xcf5dd0: stp             x3, x4, [SP, #-0x10]!
    // 0xcf5dd4: SaveReg r0
    //     0xcf5dd4: str             x0, [SP, #-8]!
    // 0xcf5dd8: ldr             x5, [THR, #0x4a0]  ; THR::ArgumentErrorUnboxedInt64
    // 0xcf5ddc: r4 = 0
    //     0xcf5ddc: mov             x4, #0
    // 0xcf5de0: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xcf5de4: blr             lr
    // 0xcf5de8: brk             #0
    // 0xcf5dec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcf5dec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcf5df0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5df0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5df4: b               #0xcf5d20
  }
}

// class id: 2376, size: 0x10, field offset: 0x8
//   const constructor, 
class PersistentHashMap<X0, X1> extends Object {

  X1? [](PersistentHashMap<X0, X1>, X0) {
    // ** addr: 0x517a84, size: 0x2cc
    // 0x517a84: EnterFrame
    //     0x517a84: stp             fp, lr, [SP, #-0x10]!
    //     0x517a88: mov             fp, SP
    // 0x517a8c: AllocStack(0x20)
    //     0x517a8c: sub             SP, SP, #0x20
    // 0x517a90: CheckStackOverflow
    //     0x517a90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x517a94: cmp             SP, x16
    //     0x517a98: b.ls            #0x517d28
    // 0x517a9c: ldr             x3, [fp, #0x18]
    // 0x517aa0: LoadField: r4 = r3->field_7
    //     0x517aa0: ldur            w4, [x3, #7]
    // 0x517aa4: DecompressPointer r4
    //     0x517aa4: add             x4, x4, HEAP, lsl #32
    // 0x517aa8: ldr             x0, [fp, #0x10]
    // 0x517aac: mov             x2, x4
    // 0x517ab0: stur            x4, [fp, #-8]
    // 0x517ab4: r1 = Null
    //     0x517ab4: mov             x1, NULL
    // 0x517ab8: cmp             w2, NULL
    // 0x517abc: b.eq            #0x517ae0
    // 0x517ac0: LoadField: r4 = r2->field_17
    //     0x517ac0: ldur            w4, [x2, #0x17]
    // 0x517ac4: DecompressPointer r4
    //     0x517ac4: add             x4, x4, HEAP, lsl #32
    // 0x517ac8: r8 = X0
    //     0x517ac8: add             x8, PP, #0xe, lsl #12  ; [pp+0xe0c0] TypeParameter: X0
    //     0x517acc: ldr             x8, [x8, #0xc0]
    // 0x517ad0: LoadField: r9 = r4->field_7
    //     0x517ad0: ldur            x9, [x4, #7]
    // 0x517ad4: r3 = Null
    //     0x517ad4: add             x3, PP, #0xe, lsl #12  ; [pp+0xe0c8] Null
    //     0x517ad8: ldr             x3, [x3, #0xc8]
    // 0x517adc: blr             x9
    // 0x517ae0: ldr             x0, [fp, #0x18]
    // 0x517ae4: LoadField: r1 = r0->field_b
    //     0x517ae4: ldur            w1, [x0, #0xb]
    // 0x517ae8: DecompressPointer r1
    //     0x517ae8: add             x1, x1, HEAP, lsl #32
    // 0x517aec: stur            x1, [fp, #-0x10]
    // 0x517af0: cmp             w1, NULL
    // 0x517af4: b.ne            #0x517b08
    // 0x517af8: r0 = Null
    //     0x517af8: mov             x0, NULL
    // 0x517afc: LeaveFrame
    //     0x517afc: mov             SP, fp
    //     0x517b00: ldp             fp, lr, [SP], #0x10
    // 0x517b04: ret
    //     0x517b04: ret             
    // 0x517b08: ldr             x2, [fp, #0x10]
    // 0x517b0c: r0 = 59
    //     0x517b0c: mov             x0, #0x3b
    // 0x517b10: branchIfSmi(r2, 0x517b1c)
    //     0x517b10: tbz             w2, #0, #0x517b1c
    // 0x517b14: r0 = LoadClassIdInstr(r2)
    //     0x517b14: ldur            x0, [x2, #-1]
    //     0x517b18: ubfx            x0, x0, #0xc, #0x14
    // 0x517b1c: SaveReg r2
    //     0x517b1c: str             x2, [SP, #-8]!
    // 0x517b20: r0 = GDT[cid_x0 + 0x2721]()
    //     0x517b20: mov             x17, #0x2721
    //     0x517b24: add             lr, x0, x17
    //     0x517b28: ldr             lr, [x21, lr, lsl #3]
    //     0x517b2c: blr             lr
    // 0x517b30: add             SP, SP, #8
    // 0x517b34: mov             x1, x0
    // 0x517b38: ldur            x0, [fp, #-0x10]
    // 0x517b3c: r2 = LoadClassIdInstr(r0)
    //     0x517b3c: ldur            x2, [x0, #-1]
    //     0x517b40: ubfx            x2, x2, #0xc, #0x14
    // 0x517b44: lsl             x2, x2, #1
    // 0x517b48: r17 = 4746
    //     0x517b48: mov             x17, #0x128a
    // 0x517b4c: cmp             w2, w17
    // 0x517b50: b.ne            #0x517bb0
    // 0x517b54: ldr             x16, [fp, #0x10]
    // 0x517b58: stp             x16, x0, [SP, #-0x10]!
    // 0x517b5c: r0 = _indexOf()
    //     0x517b5c: bl              #0x517d38  ; [package:flutter/src/foundation/persistent_hash_map.dart] _HashCollisionNode::_indexOf
    // 0x517b60: add             SP, SP, #0x10
    // 0x517b64: tbz             x0, #0x3f, #0x517b70
    // 0x517b68: r0 = Null
    //     0x517b68: mov             x0, NULL
    // 0x517b6c: b               #0x517ba8
    // 0x517b70: ldur            x3, [fp, #-0x10]
    // 0x517b74: LoadField: r2 = r3->field_f
    //     0x517b74: ldur            w2, [x3, #0xf]
    // 0x517b78: DecompressPointer r2
    //     0x517b78: add             x2, x2, HEAP, lsl #32
    // 0x517b7c: add             x3, x0, #1
    // 0x517b80: LoadField: r0 = r2->field_b
    //     0x517b80: ldur            w0, [x2, #0xb]
    // 0x517b84: DecompressPointer r0
    //     0x517b84: add             x0, x0, HEAP, lsl #32
    // 0x517b88: r1 = LoadInt32Instr(r0)
    //     0x517b88: sbfx            x1, x0, #1, #0x1f
    // 0x517b8c: mov             x0, x1
    // 0x517b90: mov             x1, x3
    // 0x517b94: cmp             x1, x0
    // 0x517b98: b.hs            #0x517d30
    // 0x517b9c: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0x517b9c: add             x16, x2, x3, lsl #2
    //     0x517ba0: ldur            w0, [x16, #0xf]
    // 0x517ba4: DecompressPointer r0
    //     0x517ba4: add             x0, x0, HEAP, lsl #32
    // 0x517ba8: mov             x3, x0
    // 0x517bac: b               #0x517cd8
    // 0x517bb0: mov             x3, x0
    // 0x517bb4: r17 = 4750
    //     0x517bb4: mov             x17, #0x128e
    // 0x517bb8: cmp             w2, w17
    // 0x517bbc: b.ne            #0x517ca0
    // 0x517bc0: r0 = 31
    //     0x517bc0: mov             x0, #0x1f
    // 0x517bc4: r4 = LoadInt32Instr(r1)
    //     0x517bc4: sbfx            x4, x1, #1, #0x1f
    //     0x517bc8: tbz             w1, #0, #0x517bd0
    //     0x517bcc: ldur            x4, [x1, #7]
    // 0x517bd0: stur            x4, [fp, #-0x20]
    // 0x517bd4: mov             x1, x4
    // 0x517bd8: ubfx            x1, x1, #0, #0x20
    // 0x517bdc: and             x2, x1, x0
    // 0x517be0: LoadField: r5 = r3->field_7
    //     0x517be0: ldur            w5, [x3, #7]
    // 0x517be4: DecompressPointer r5
    //     0x517be4: add             x5, x5, HEAP, lsl #32
    // 0x517be8: LoadField: r0 = r5->field_b
    //     0x517be8: ldur            w0, [x5, #0xb]
    // 0x517bec: DecompressPointer r0
    //     0x517bec: add             x0, x0, HEAP, lsl #32
    // 0x517bf0: r1 = LoadInt32Instr(r0)
    //     0x517bf0: sbfx            x1, x0, #1, #0x1f
    // 0x517bf4: ubfx            x2, x2, #0, #0x20
    // 0x517bf8: mov             x0, x1
    // 0x517bfc: mov             x1, x2
    // 0x517c00: cmp             x1, x0
    // 0x517c04: b.hs            #0x517d34
    // 0x517c08: ArrayLoad: r3 = r5[r2]  ; Unknown_4
    //     0x517c08: add             x16, x5, x2, lsl #2
    //     0x517c0c: ldur            w3, [x16, #0xf]
    // 0x517c10: DecompressPointer r3
    //     0x517c10: add             x3, x3, HEAP, lsl #32
    // 0x517c14: mov             x0, x3
    // 0x517c18: stur            x3, [fp, #-0x18]
    // 0x517c1c: r2 = Null
    //     0x517c1c: mov             x2, NULL
    // 0x517c20: r1 = Null
    //     0x517c20: mov             x1, NULL
    // 0x517c24: r4 = 59
    //     0x517c24: mov             x4, #0x3b
    // 0x517c28: branchIfSmi(r0, 0x517c34)
    //     0x517c28: tbz             w0, #0, #0x517c34
    // 0x517c2c: r4 = LoadClassIdInstr(r0)
    //     0x517c2c: ldur            x4, [x0, #-1]
    //     0x517c30: ubfx            x4, x4, #0xc, #0x14
    // 0x517c34: sub             x4, x4, #0x945
    // 0x517c38: cmp             x4, #2
    // 0x517c3c: b.ls            #0x517c54
    // 0x517c40: r8 = _TrieNode?
    //     0x517c40: add             x8, PP, #0xe, lsl #12  ; [pp+0xe0d8] Type: _TrieNode?
    //     0x517c44: ldr             x8, [x8, #0xd8]
    // 0x517c48: r3 = Null
    //     0x517c48: add             x3, PP, #0xe, lsl #12  ; [pp+0xe0e0] Null
    //     0x517c4c: ldr             x3, [x3, #0xe0]
    // 0x517c50: r0 = DefaultNullableTypeTest()
    //     0x517c50: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x517c54: ldur            x0, [fp, #-0x18]
    // 0x517c58: cmp             w0, NULL
    // 0x517c5c: b.ne            #0x517c68
    // 0x517c60: r0 = Null
    //     0x517c60: mov             x0, NULL
    // 0x517c64: b               #0x517c98
    // 0x517c68: ldur            x1, [fp, #-0x20]
    // 0x517c6c: r2 = LoadClassIdInstr(r0)
    //     0x517c6c: ldur            x2, [x0, #-1]
    //     0x517c70: ubfx            x2, x2, #0xc, #0x14
    // 0x517c74: r16 = 10
    //     0x517c74: mov             x16, #0xa
    // 0x517c78: stp             x16, x0, [SP, #-0x10]!
    // 0x517c7c: ldr             x16, [fp, #0x10]
    // 0x517c80: stp             x1, x16, [SP, #-0x10]!
    // 0x517c84: mov             x0, x2
    // 0x517c88: r0 = GDT[cid_x0 + -0xff9]()
    //     0x517c88: sub             lr, x0, #0xff9
    //     0x517c8c: ldr             lr, [x21, lr, lsl #3]
    //     0x517c90: blr             lr
    // 0x517c94: add             SP, SP, #0x20
    // 0x517c98: mov             x3, x0
    // 0x517c9c: b               #0x517cd8
    // 0x517ca0: r0 = LoadInt32Instr(r1)
    //     0x517ca0: sbfx            x0, x1, #1, #0x1f
    //     0x517ca4: tbz             w1, #0, #0x517cac
    //     0x517ca8: ldur            x0, [x1, #7]
    // 0x517cac: r1 = LoadClassIdInstr(r3)
    //     0x517cac: ldur            x1, [x3, #-1]
    //     0x517cb0: ubfx            x1, x1, #0xc, #0x14
    // 0x517cb4: stp             xzr, x3, [SP, #-0x10]!
    // 0x517cb8: ldr             x16, [fp, #0x10]
    // 0x517cbc: stp             x0, x16, [SP, #-0x10]!
    // 0x517cc0: mov             x0, x1
    // 0x517cc4: r0 = GDT[cid_x0 + -0xff9]()
    //     0x517cc4: sub             lr, x0, #0xff9
    //     0x517cc8: ldr             lr, [x21, lr, lsl #3]
    //     0x517ccc: blr             lr
    // 0x517cd0: add             SP, SP, #0x20
    // 0x517cd4: mov             x3, x0
    // 0x517cd8: mov             x0, x3
    // 0x517cdc: ldur            x2, [fp, #-8]
    // 0x517ce0: stur            x3, [fp, #-0x10]
    // 0x517ce4: r1 = Null
    //     0x517ce4: mov             x1, NULL
    // 0x517ce8: cmp             w0, NULL
    // 0x517cec: b.eq            #0x517d18
    // 0x517cf0: cmp             w2, NULL
    // 0x517cf4: b.eq            #0x517d18
    // 0x517cf8: LoadField: r4 = r2->field_1b
    //     0x517cf8: ldur            w4, [x2, #0x1b]
    // 0x517cfc: DecompressPointer r4
    //     0x517cfc: add             x4, x4, HEAP, lsl #32
    // 0x517d00: r8 = X1?
    //     0x517d00: add             x8, PP, #0xe, lsl #12  ; [pp+0xe0f0] TypeParameter: X1?
    //     0x517d04: ldr             x8, [x8, #0xf0]
    // 0x517d08: LoadField: r9 = r4->field_7
    //     0x517d08: ldur            x9, [x4, #7]
    // 0x517d0c: r3 = Null
    //     0x517d0c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe0f8] Null
    //     0x517d10: ldr             x3, [x3, #0xf8]
    // 0x517d14: blr             x9
    // 0x517d18: ldur            x0, [fp, #-0x10]
    // 0x517d1c: LeaveFrame
    //     0x517d1c: mov             SP, fp
    //     0x517d20: ldp             fp, lr, [SP], #0x10
    // 0x517d24: ret
    //     0x517d24: ret             
    // 0x517d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x517d28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x517d2c: b               #0x517a9c
    // 0x517d30: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x517d30: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x517d34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x517d34: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ put(/* No info */) {
    // ** addr: 0x712bac, size: 0x184
    // 0x712bac: EnterFrame
    //     0x712bac: stp             fp, lr, [SP, #-0x10]!
    //     0x712bb0: mov             fp, SP
    // 0x712bb4: AllocStack(0x18)
    //     0x712bb4: sub             SP, SP, #0x18
    // 0x712bb8: CheckStackOverflow
    //     0x712bb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x712bbc: cmp             SP, x16
    //     0x712bc0: b.ls            #0x712d28
    // 0x712bc4: ldr             x3, [fp, #0x20]
    // 0x712bc8: LoadField: r4 = r3->field_7
    //     0x712bc8: ldur            w4, [x3, #7]
    // 0x712bcc: DecompressPointer r4
    //     0x712bcc: add             x4, x4, HEAP, lsl #32
    // 0x712bd0: ldr             x0, [fp, #0x18]
    // 0x712bd4: mov             x2, x4
    // 0x712bd8: stur            x4, [fp, #-8]
    // 0x712bdc: r1 = Null
    //     0x712bdc: mov             x1, NULL
    // 0x712be0: cmp             w2, NULL
    // 0x712be4: b.eq            #0x712c08
    // 0x712be8: LoadField: r4 = r2->field_17
    //     0x712be8: ldur            w4, [x2, #0x17]
    // 0x712bec: DecompressPointer r4
    //     0x712bec: add             x4, x4, HEAP, lsl #32
    // 0x712bf0: r8 = X0
    //     0x712bf0: add             x8, PP, #0xe, lsl #12  ; [pp+0xe0c0] TypeParameter: X0
    //     0x712bf4: ldr             x8, [x8, #0xc0]
    // 0x712bf8: LoadField: r9 = r4->field_7
    //     0x712bf8: ldur            x9, [x4, #7]
    // 0x712bfc: r3 = Null
    //     0x712bfc: add             x3, PP, #0x22, lsl #12  ; [pp+0x229a0] Null
    //     0x712c00: ldr             x3, [x3, #0x9a0]
    // 0x712c04: blr             x9
    // 0x712c08: ldr             x0, [fp, #0x10]
    // 0x712c0c: ldur            x2, [fp, #-8]
    // 0x712c10: r1 = Null
    //     0x712c10: mov             x1, NULL
    // 0x712c14: cmp             w2, NULL
    // 0x712c18: b.eq            #0x712c38
    // 0x712c1c: LoadField: r4 = r2->field_1b
    //     0x712c1c: ldur            w4, [x2, #0x1b]
    // 0x712c20: DecompressPointer r4
    //     0x712c20: add             x4, x4, HEAP, lsl #32
    // 0x712c24: r8 = X1
    //     0x712c24: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0x712c28: LoadField: r9 = r4->field_7
    //     0x712c28: ldur            x9, [x4, #7]
    // 0x712c2c: r3 = Null
    //     0x712c2c: add             x3, PP, #0x22, lsl #12  ; [pp+0x229b0] Null
    //     0x712c30: ldr             x3, [x3, #0x9b0]
    // 0x712c34: blr             x9
    // 0x712c38: ldr             x0, [fp, #0x20]
    // 0x712c3c: LoadField: r1 = r0->field_b
    //     0x712c3c: ldur            w1, [x0, #0xb]
    // 0x712c40: DecompressPointer r1
    //     0x712c40: add             x1, x1, HEAP, lsl #32
    // 0x712c44: stur            x1, [fp, #-0x10]
    // 0x712c48: cmp             w1, NULL
    // 0x712c4c: b.ne            #0x712c78
    // 0x712c50: r0 = InitLateStaticField(0xd18) // [package:flutter/src/foundation/persistent_hash_map.dart] _CompressedNode::empty
    //     0x712c50: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x712c54: ldr             x0, [x0, #0x1a30]
    //     0x712c58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x712c5c: cmp             w0, w16
    //     0x712c60: b.ne            #0x712c70
    //     0x712c64: add             x2, PP, #0x22, lsl #12  ; [pp+0x229c0] Field <_CompressedNode@644137193.empty>: static late final (offset: 0xd18)
    //     0x712c68: ldr             x2, [x2, #0x9c0]
    //     0x712c6c: bl              #0xd67cdc
    // 0x712c70: mov             x3, x0
    // 0x712c74: b               #0x712c7c
    // 0x712c78: ldur            x3, [fp, #-0x10]
    // 0x712c7c: ldr             x2, [fp, #0x18]
    // 0x712c80: ldur            x1, [fp, #-0x10]
    // 0x712c84: stur            x3, [fp, #-0x18]
    // 0x712c88: r0 = 59
    //     0x712c88: mov             x0, #0x3b
    // 0x712c8c: branchIfSmi(r2, 0x712c98)
    //     0x712c8c: tbz             w2, #0, #0x712c98
    // 0x712c90: r0 = LoadClassIdInstr(r2)
    //     0x712c90: ldur            x0, [x2, #-1]
    //     0x712c94: ubfx            x0, x0, #0xc, #0x14
    // 0x712c98: SaveReg r2
    //     0x712c98: str             x2, [SP, #-8]!
    // 0x712c9c: r0 = GDT[cid_x0 + 0x2721]()
    //     0x712c9c: mov             x17, #0x2721
    //     0x712ca0: add             lr, x0, x17
    //     0x712ca4: ldr             lr, [x21, lr, lsl #3]
    //     0x712ca8: blr             lr
    // 0x712cac: add             SP, SP, #8
    // 0x712cb0: r1 = LoadInt32Instr(r0)
    //     0x712cb0: sbfx            x1, x0, #1, #0x1f
    // 0x712cb4: ldur            x0, [fp, #-0x18]
    // 0x712cb8: r2 = LoadClassIdInstr(r0)
    //     0x712cb8: ldur            x2, [x0, #-1]
    //     0x712cbc: ubfx            x2, x2, #0xc, #0x14
    // 0x712cc0: stp             xzr, x0, [SP, #-0x10]!
    // 0x712cc4: ldr             x16, [fp, #0x18]
    // 0x712cc8: stp             x1, x16, [SP, #-0x10]!
    // 0x712ccc: ldr             x16, [fp, #0x10]
    // 0x712cd0: SaveReg r16
    //     0x712cd0: str             x16, [SP, #-8]!
    // 0x712cd4: mov             x0, x2
    // 0x712cd8: r0 = GDT[cid_x0 + -0xfff]()
    //     0x712cd8: sub             lr, x0, #0xfff
    //     0x712cdc: ldr             lr, [x21, lr, lsl #3]
    //     0x712ce0: blr             lr
    // 0x712ce4: add             SP, SP, #0x28
    // 0x712ce8: mov             x2, x0
    // 0x712cec: ldur            x0, [fp, #-0x10]
    // 0x712cf0: stur            x2, [fp, #-0x18]
    // 0x712cf4: cmp             w2, w0
    // 0x712cf8: b.ne            #0x712d0c
    // 0x712cfc: ldr             x0, [fp, #0x20]
    // 0x712d00: LeaveFrame
    //     0x712d00: mov             SP, fp
    //     0x712d04: ldp             fp, lr, [SP], #0x10
    // 0x712d08: ret
    //     0x712d08: ret             
    // 0x712d0c: ldur            x1, [fp, #-8]
    // 0x712d10: r0 = PersistentHashMap()
    //     0x712d10: bl              #0x712d30  ; AllocatePersistentHashMapStub -> PersistentHashMap<X0, X1> (size=0x10)
    // 0x712d14: ldur            x1, [fp, #-0x18]
    // 0x712d18: StoreField: r0->field_b = r1
    //     0x712d18: stur            w1, [x0, #0xb]
    // 0x712d1c: LeaveFrame
    //     0x712d1c: mov             SP, fp
    //     0x712d20: ldp             fp, lr, [SP], #0x10
    // 0x712d24: ret
    //     0x712d24: ret             
    // 0x712d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x712d28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x712d2c: b               #0x712bc4
  }
}

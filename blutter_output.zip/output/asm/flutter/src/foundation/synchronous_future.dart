// lib: , url: package:flutter/src/foundation/synchronous_future.dart

// class id: 1049147, size: 0x8
class :: {
}

// class id: 2368, size: 0x10, field offset: 0x8
class SynchronousFuture<X0> extends Object
    implements Future<X0> {

  _ timeout(/* No info */) {
    // ** addr: 0xcee634, size: 0x170
    // 0xcee634: EnterFrame
    //     0xcee634: stp             fp, lr, [SP, #-0x10]!
    //     0xcee638: mov             fp, SP
    // 0xcee63c: AllocStack(0x28)
    //     0xcee63c: sub             SP, SP, #0x28
    // 0xcee640: SetupParameters(SynchronousFuture<X0> this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, {dynamic onTimeout = Null /* r5, fp-0x10 */})
    //     0xcee640: mov             x0, x4
    //     0xcee644: ldur            w1, [x0, #0x13]
    //     0xcee648: add             x1, x1, HEAP, lsl #32
    //     0xcee64c: sub             x2, x1, #4
    //     0xcee650: add             x3, fp, w2, sxtw #2
    //     0xcee654: ldr             x3, [x3, #0x18]
    //     0xcee658: stur            x3, [fp, #-0x20]
    //     0xcee65c: add             x4, fp, w2, sxtw #2
    //     0xcee660: ldr             x4, [x4, #0x10]
    //     0xcee664: stur            x4, [fp, #-0x18]
    //     0xcee668: ldur            w2, [x0, #0x1f]
    //     0xcee66c: add             x2, x2, HEAP, lsl #32
    //     0xcee670: ldr             x16, [PP, #0x2df0]  ; [pp+0x2df0] "onTimeout"
    //     0xcee674: cmp             w2, w16
    //     0xcee678: b.ne            #0xcee698
    //     0xcee67c: ldur            w2, [x0, #0x23]
    //     0xcee680: add             x2, x2, HEAP, lsl #32
    //     0xcee684: sub             w0, w1, w2
    //     0xcee688: add             x1, fp, w0, sxtw #2
    //     0xcee68c: ldr             x1, [x1, #8]
    //     0xcee690: mov             x5, x1
    //     0xcee694: b               #0xcee69c
    //     0xcee698: mov             x5, NULL
    //     0xcee69c: stur            x5, [fp, #-0x10]
    // 0xcee6a0: CheckStackOverflow
    //     0xcee6a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee6a4: cmp             SP, x16
    //     0xcee6a8: b.ls            #0xcee79c
    // 0xcee6ac: LoadField: r6 = r3->field_7
    //     0xcee6ac: ldur            w6, [x3, #7]
    // 0xcee6b0: DecompressPointer r6
    //     0xcee6b0: add             x6, x6, HEAP, lsl #32
    // 0xcee6b4: mov             x0, x5
    // 0xcee6b8: mov             x2, x6
    // 0xcee6bc: stur            x6, [fp, #-8]
    // 0xcee6c0: r1 = Null
    //     0xcee6c0: mov             x1, NULL
    // 0xcee6c4: r8 = ((dynamic this) => FutureOr<X0>)?
    //     0xcee6c4: ldr             x8, [PP, #0x2e00]  ; [pp+0x2e00] FunctionType: ((dynamic this) => FutureOr<X0>)?
    // 0xcee6c8: LoadField: r9 = r8->field_7
    //     0xcee6c8: ldur            x9, [x8, #7]
    // 0xcee6cc: r3 = Null
    //     0xcee6cc: add             x3, PP, #0x37, lsl #12  ; [pp+0x37b60] Null
    //     0xcee6d0: ldr             x3, [x3, #0xb60]
    // 0xcee6d4: blr             x9
    // 0xcee6d8: ldur            x0, [fp, #-0x20]
    // 0xcee6dc: LoadField: r3 = r0->field_b
    //     0xcee6dc: ldur            w3, [x0, #0xb]
    // 0xcee6e0: DecompressPointer r3
    //     0xcee6e0: add             x3, x3, HEAP, lsl #32
    // 0xcee6e4: stur            x3, [fp, #-0x28]
    // 0xcee6e8: cmp             w3, NULL
    // 0xcee6ec: b.ne            #0xcee720
    // 0xcee6f0: mov             x0, x3
    // 0xcee6f4: ldur            x2, [fp, #-8]
    // 0xcee6f8: r1 = Null
    //     0xcee6f8: mov             x1, NULL
    // 0xcee6fc: cmp             w2, NULL
    // 0xcee700: b.eq            #0xcee720
    // 0xcee704: LoadField: r4 = r2->field_17
    //     0xcee704: ldur            w4, [x2, #0x17]
    // 0xcee708: DecompressPointer r4
    //     0xcee708: add             x4, x4, HEAP, lsl #32
    // 0xcee70c: r8 = X0
    //     0xcee70c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xcee710: LoadField: r9 = r4->field_7
    //     0xcee710: ldur            x9, [x4, #7]
    // 0xcee714: r3 = Null
    //     0xcee714: add             x3, PP, #0x37, lsl #12  ; [pp+0x37b70] Null
    //     0xcee718: ldr             x3, [x3, #0xb70]
    // 0xcee71c: blr             x9
    // 0xcee720: ldur            x1, [fp, #-8]
    // 0xcee724: r0 = _Future()
    //     0xcee724: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xcee728: mov             x1, x0
    // 0xcee72c: r0 = 0
    //     0xcee72c: mov             x0, #0
    // 0xcee730: stur            x1, [fp, #-8]
    // 0xcee734: StoreField: r1->field_b = r0
    //     0xcee734: stur            x0, [x1, #0xb]
    // 0xcee738: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xcee738: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcee73c: ldr             x0, [x0, #0xb58]
    //     0xcee740: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcee744: cmp             w0, w16
    //     0xcee748: b.ne            #0xcee754
    //     0xcee74c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xcee750: bl              #0xd67d44
    // 0xcee754: mov             x1, x0
    // 0xcee758: ldur            x0, [fp, #-8]
    // 0xcee75c: StoreField: r0->field_13 = r1
    //     0xcee75c: stur            w1, [x0, #0x13]
    // 0xcee760: ldur            x16, [fp, #-0x28]
    // 0xcee764: stp             x16, x0, [SP, #-0x10]!
    // 0xcee768: r0 = _asyncComplete()
    //     0xcee768: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0xcee76c: add             SP, SP, #0x10
    // 0xcee770: ldur            x16, [fp, #-8]
    // 0xcee774: ldur            lr, [fp, #-0x18]
    // 0xcee778: stp             lr, x16, [SP, #-0x10]!
    // 0xcee77c: ldur            x16, [fp, #-0x10]
    // 0xcee780: SaveReg r16
    //     0xcee780: str             x16, [SP, #-8]!
    // 0xcee784: r4 = const [0, 0x3, 0x3, 0x2, onTimeout, 0x2, null]
    //     0xcee784: ldr             x4, [PP, #0x2df8]  ; [pp+0x2df8] List(7) [0, 0x3, 0x3, 0x2, "onTimeout", 0x2, Null]
    // 0xcee788: r0 = timeout()
    //     0xcee788: bl              #0xca0a98  ; [dart:async] _Future::timeout
    // 0xcee78c: add             SP, SP, #0x18
    // 0xcee790: LeaveFrame
    //     0xcee790: mov             SP, fp
    //     0xcee794: ldp             fp, lr, [SP], #0x10
    // 0xcee798: ret
    //     0xcee798: ret             
    // 0xcee79c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee79c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee7a0: b               #0xcee6ac
  }
  _ catchError(/* No info */) {
    // ** addr: 0xcf6fd0, size: 0x8c
    // 0xcf6fd0: EnterFrame
    //     0xcf6fd0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf6fd4: mov             fp, SP
    // 0xcf6fd8: AllocStack(0x8)
    //     0xcf6fd8: sub             SP, SP, #8
    // 0xcf6fdc: SetupParameters(SynchronousFuture<X0> this /* r1 */)
    //     0xcf6fdc: mov             x0, x4
    //     0xcf6fe0: ldur            w1, [x0, #0x13]
    //     0xcf6fe4: add             x1, x1, HEAP, lsl #32
    //     0xcf6fe8: sub             x0, x1, #4
    //     0xcf6fec: add             x1, fp, w0, sxtw #2
    //     0xcf6ff0: ldr             x1, [x1, #0x18]
    // 0xcf6ff4: CheckStackOverflow
    //     0xcf6ff4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf6ff8: cmp             SP, x16
    //     0xcf6ffc: b.ls            #0xcf7054
    // 0xcf7000: LoadField: r0 = r1->field_7
    //     0xcf7000: ldur            w0, [x1, #7]
    // 0xcf7004: DecompressPointer r0
    //     0xcf7004: add             x0, x0, HEAP, lsl #32
    // 0xcf7008: mov             x1, x0
    // 0xcf700c: r0 = _Future()
    //     0xcf700c: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xcf7010: mov             x1, x0
    // 0xcf7014: r0 = 0
    //     0xcf7014: mov             x0, #0
    // 0xcf7018: stur            x1, [fp, #-8]
    // 0xcf701c: StoreField: r1->field_b = r0
    //     0xcf701c: stur            x0, [x1, #0xb]
    // 0xcf7020: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xcf7020: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcf7024: ldr             x0, [x0, #0xb58]
    //     0xcf7028: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcf702c: cmp             w0, w16
    //     0xcf7030: b.ne            #0xcf703c
    //     0xcf7034: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xcf7038: bl              #0xd67d44
    // 0xcf703c: mov             x1, x0
    // 0xcf7040: ldur            x0, [fp, #-8]
    // 0xcf7044: StoreField: r0->field_13 = r1
    //     0xcf7044: stur            w1, [x0, #0x13]
    // 0xcf7048: LeaveFrame
    //     0xcf7048: mov             SP, fp
    //     0xcf704c: ldp             fp, lr, [SP], #0x10
    // 0xcf7050: ret
    //     0xcf7050: ret             
    // 0xcf7054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7054: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7058: b               #0xcf7000
  }
  _ whenComplete(/* No info */) {
    // ** addr: 0xcf705c, size: 0x1c4
    // 0xcf705c: EnterFrame
    //     0xcf705c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7060: mov             fp, SP
    // 0xcf7064: AllocStack(0x58)
    //     0xcf7064: sub             SP, SP, #0x58
    // 0xcf7068: CheckStackOverflow
    //     0xcf7068: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf706c: cmp             SP, x16
    //     0xcf7070: b.ls            #0xcf7218
    // 0xcf7074: r1 = 1
    //     0xcf7074: mov             x1, #1
    // 0xcf7078: r0 = AllocateContext()
    //     0xcf7078: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcf707c: mov             x2, x0
    // 0xcf7080: ldr             x1, [fp, #0x18]
    // 0xcf7084: stur            x2, [fp, #-0x48]
    // 0xcf7088: StoreField: r2->field_f = r1
    //     0xcf7088: stur            w1, [x2, #0xf]
    // 0xcf708c: ldr             x16, [fp, #0x10]
    // 0xcf7090: SaveReg r16
    //     0xcf7090: str             x16, [SP, #-8]!
    // 0xcf7094: ldr             x0, [fp, #0x10]
    // 0xcf7098: ClosureCall
    //     0xcf7098: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xcf709c: ldur            x2, [x0, #0x1f]
    //     0xcf70a0: blr             x2
    // 0xcf70a4: add             SP, SP, #8
    // 0xcf70a8: mov             x3, x0
    // 0xcf70ac: r2 = Null
    //     0xcf70ac: mov             x2, NULL
    // 0xcf70b0: r1 = Null
    //     0xcf70b0: mov             x1, NULL
    // 0xcf70b4: stur            x3, [fp, #-0x50]
    // 0xcf70b8: cmp             w0, NULL
    // 0xcf70bc: b.eq            #0xcf7154
    // 0xcf70c0: branchIfSmi(r0, 0xcf7154)
    //     0xcf70c0: tbz             w0, #0, #0xcf7154
    // 0xcf70c4: r3 = LoadClassIdInstr(r0)
    //     0xcf70c4: ldur            x3, [x0, #-1]
    //     0xcf70c8: ubfx            x3, x3, #0xc, #0x14
    // 0xcf70cc: r17 = 5667
    //     0xcf70cc: mov             x17, #0x1623
    // 0xcf70d0: cmp             x3, x17
    // 0xcf70d4: b.eq            #0xcf715c
    // 0xcf70d8: r4 = LoadClassIdInstr(r0)
    //     0xcf70d8: ldur            x4, [x0, #-1]
    //     0xcf70dc: ubfx            x4, x4, #0xc, #0x14
    // 0xcf70e0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcf70e4: ldr             x3, [x3, #0x18]
    // 0xcf70e8: ldr             x3, [x3, x4, lsl #3]
    // 0xcf70ec: LoadField: r3 = r3->field_2b
    //     0xcf70ec: ldur            w3, [x3, #0x2b]
    // 0xcf70f0: DecompressPointer r3
    //     0xcf70f0: add             x3, x3, HEAP, lsl #32
    // 0xcf70f4: cmp             w3, NULL
    // 0xcf70f8: b.eq            #0xcf7154
    // 0xcf70fc: LoadField: r3 = r3->field_f
    //     0xcf70fc: ldur            w3, [x3, #0xf]
    // 0xcf7100: lsr             x3, x3, #4
    // 0xcf7104: r17 = 5667
    //     0xcf7104: mov             x17, #0x1623
    // 0xcf7108: cmp             x3, x17
    // 0xcf710c: b.eq            #0xcf715c
    // 0xcf7110: r3 = SubtypeTestCache
    //     0xcf7110: add             x3, PP, #0x37, lsl #12  ; [pp+0x37b40] SubtypeTestCache
    //     0xcf7114: ldr             x3, [x3, #0xb40]
    // 0xcf7118: r24 = Subtype1TestCacheStub
    //     0xcf7118: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcf711c: LoadField: r30 = r24->field_7
    //     0xcf711c: ldur            lr, [x24, #7]
    // 0xcf7120: blr             lr
    // 0xcf7124: cmp             w7, NULL
    // 0xcf7128: b.eq            #0xcf7134
    // 0xcf712c: tbnz            w7, #4, #0xcf7154
    // 0xcf7130: b               #0xcf715c
    // 0xcf7134: r8 = Future
    //     0xcf7134: add             x8, PP, #0x37, lsl #12  ; [pp+0x37b48] Type: Future
    //     0xcf7138: ldr             x8, [x8, #0xb48]
    // 0xcf713c: r3 = SubtypeTestCache
    //     0xcf713c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37b50] SubtypeTestCache
    //     0xcf7140: ldr             x3, [x3, #0xb50]
    // 0xcf7144: r24 = InstanceOfStub
    //     0xcf7144: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcf7148: LoadField: r30 = r24->field_7
    //     0xcf7148: ldur            lr, [x24, #7]
    // 0xcf714c: blr             lr
    // 0xcf7150: b               #0xcf7160
    // 0xcf7154: r0 = false
    //     0xcf7154: add             x0, NULL, #0x30  ; false
    // 0xcf7158: b               #0xcf7160
    // 0xcf715c: r0 = true
    //     0xcf715c: add             x0, NULL, #0x20  ; true
    // 0xcf7160: tbnz            w0, #4, #0xcf71cc
    // 0xcf7164: ldr             x3, [fp, #0x18]
    // 0xcf7168: ldur            x0, [fp, #-0x50]
    // 0xcf716c: LoadField: r4 = r3->field_7
    //     0xcf716c: ldur            w4, [x3, #7]
    // 0xcf7170: DecompressPointer r4
    //     0xcf7170: add             x4, x4, HEAP, lsl #32
    // 0xcf7174: ldur            x2, [fp, #-0x48]
    // 0xcf7178: stur            x4, [fp, #-0x58]
    // 0xcf717c: r1 = Function '<anonymous closure>':.
    //     0xcf717c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37b58] AnonymousClosure: (0xcf7220), in [package:flutter/src/foundation/synchronous_future.dart] SynchronousFuture::whenComplete (0xcf705c)
    //     0xcf7180: ldr             x1, [x1, #0xb58]
    // 0xcf7184: r0 = AllocateClosure()
    //     0xcf7184: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcf7188: mov             x1, x0
    // 0xcf718c: ldur            x0, [fp, #-0x58]
    // 0xcf7190: StoreField: r1->field_7 = r0
    //     0xcf7190: stur            w0, [x1, #7]
    // 0xcf7194: ldur            x2, [fp, #-0x50]
    // 0xcf7198: r3 = LoadClassIdInstr(r2)
    //     0xcf7198: ldur            x3, [x2, #-1]
    //     0xcf719c: ubfx            x3, x3, #0xc, #0x14
    // 0xcf71a0: stp             x2, x0, [SP, #-0x10]!
    // 0xcf71a4: SaveReg r1
    //     0xcf71a4: str             x1, [SP, #-8]!
    // 0xcf71a8: mov             x0, x3
    // 0xcf71ac: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcf71ac: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcf71b0: r0 = GDT[cid_x0 + -0xffe]()
    //     0xcf71b0: sub             lr, x0, #0xffe
    //     0xcf71b4: ldr             lr, [x21, lr, lsl #3]
    //     0xcf71b8: blr             lr
    // 0xcf71bc: add             SP, SP, #0x18
    // 0xcf71c0: LeaveFrame
    //     0xcf71c0: mov             SP, fp
    //     0xcf71c4: ldp             fp, lr, [SP], #0x10
    // 0xcf71c8: ret
    //     0xcf71c8: ret             
    // 0xcf71cc: ldr             x0, [fp, #0x18]
    // 0xcf71d0: LeaveFrame
    //     0xcf71d0: mov             SP, fp
    //     0xcf71d4: ldp             fp, lr, [SP], #0x10
    // 0xcf71d8: ret
    //     0xcf71d8: ret             
    // 0xcf71dc: sub             SP, fp, #0x58
    // 0xcf71e0: ldr             x2, [fp, #0x18]
    // 0xcf71e4: mov             x16, x1
    // 0xcf71e8: mov             x1, x0
    // 0xcf71ec: mov             x0, x16
    // 0xcf71f0: LoadField: r3 = r2->field_7
    //     0xcf71f0: ldur            w3, [x2, #7]
    // 0xcf71f4: DecompressPointer r3
    //     0xcf71f4: add             x3, x3, HEAP, lsl #32
    // 0xcf71f8: stp             x1, x3, [SP, #-0x10]!
    // 0xcf71fc: SaveReg r0
    //     0xcf71fc: str             x0, [SP, #-8]!
    // 0xcf7200: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xcf7200: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xcf7204: r0 = Future.error()
    //     0xcf7204: bl              #0x4e95bc  ; [dart:async] Future::Future.error
    // 0xcf7208: add             SP, SP, #0x18
    // 0xcf720c: LeaveFrame
    //     0xcf720c: mov             SP, fp
    //     0xcf7210: ldp             fp, lr, [SP], #0x10
    // 0xcf7214: ret
    //     0xcf7214: ret             
    // 0xcf7218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf721c: b               #0xcf7074
  }
  [closure] X0 <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xcf7220, size: 0x20
    // 0xcf7220: ldr             x1, [SP, #8]
    // 0xcf7224: LoadField: r2 = r1->field_17
    //     0xcf7224: ldur            w2, [x1, #0x17]
    // 0xcf7228: DecompressPointer r2
    //     0xcf7228: add             x2, x2, HEAP, lsl #32
    // 0xcf722c: LoadField: r1 = r2->field_f
    //     0xcf722c: ldur            w1, [x2, #0xf]
    // 0xcf7230: DecompressPointer r1
    //     0xcf7230: add             x1, x1, HEAP, lsl #32
    // 0xcf7234: LoadField: r0 = r1->field_b
    //     0xcf7234: ldur            w0, [x1, #0xb]
    // 0xcf7238: DecompressPointer r0
    //     0xcf7238: add             x0, x0, HEAP, lsl #32
    // 0xcf723c: ret
    //     0xcf723c: ret             
  }
  _ then(/* No info */) {
    // ** addr: 0xcf7240, size: 0x134
    // 0xcf7240: EnterFrame
    //     0xcf7240: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7244: mov             fp, SP
    // 0xcf7248: AllocStack(0x10)
    //     0xcf7248: sub             SP, SP, #0x10
    // 0xcf724c: SetupParameters(SynchronousFuture<X0> this /* r1 */, dynamic _ /* r3 */)
    //     0xcf724c: mov             x0, x4
    //     0xcf7250: ldur            w1, [x0, #0x13]
    //     0xcf7254: add             x1, x1, HEAP, lsl #32
    //     0xcf7258: sub             x2, x1, #4
    //     0xcf725c: add             x1, fp, w2, sxtw #2
    //     0xcf7260: ldr             x1, [x1, #0x18]
    //     0xcf7264: add             x3, fp, w2, sxtw #2
    //     0xcf7268: ldr             x3, [x3, #0x10]
    //     0xcf726c: ldur            w2, [x0, #0xf]
    //     0xcf7270: add             x2, x2, HEAP, lsl #32
    //     0xcf7274: cbnz            w2, #0xcf7280
    //     0xcf7278: mov             x2, NULL
    //     0xcf727c: b               #0xcf7294
    //     0xcf7280: ldur            w2, [x0, #0x17]
    //     0xcf7284: add             x2, x2, HEAP, lsl #32
    //     0xcf7288: add             x0, fp, w2, sxtw #2
    //     0xcf728c: ldr             x0, [x0, #0x10]
    //     0xcf7290: mov             x2, x0
    //     0xcf7294: stur            x2, [fp, #-8]
    // 0xcf7298: CheckStackOverflow
    //     0xcf7298: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf729c: cmp             SP, x16
    //     0xcf72a0: b.ls            #0xcf736c
    // 0xcf72a4: LoadField: r0 = r1->field_b
    //     0xcf72a4: ldur            w0, [x1, #0xb]
    // 0xcf72a8: DecompressPointer r0
    //     0xcf72a8: add             x0, x0, HEAP, lsl #32
    // 0xcf72ac: stp             x0, x3, [SP, #-0x10]!
    // 0xcf72b0: mov             x0, x3
    // 0xcf72b4: ClosureCall
    //     0xcf72b4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcf72b8: ldur            x2, [x0, #0x1f]
    //     0xcf72bc: blr             x2
    // 0xcf72c0: add             SP, SP, #0x10
    // 0xcf72c4: ldur            x1, [fp, #-8]
    // 0xcf72c8: mov             x3, x0
    // 0xcf72cc: r2 = Null
    //     0xcf72cc: mov             x2, NULL
    // 0xcf72d0: stur            x3, [fp, #-0x10]
    // 0xcf72d4: cmp             w0, NULL
    // 0xcf72d8: b.eq            #0xcf732c
    // 0xcf72dc: branchIfSmi(r0, 0xcf732c)
    //     0xcf72dc: tbz             w0, #0, #0xcf732c
    // 0xcf72e0: r8 = Future<Y0>
    //     0xcf72e0: add             x8, PP, #0x37, lsl #12  ; [pp+0x37b80] Type: Future<Y0>
    //     0xcf72e4: ldr             x8, [x8, #0xb80]
    // 0xcf72e8: r3 = SubtypeTestCache
    //     0xcf72e8: add             x3, PP, #0x37, lsl #12  ; [pp+0x37b88] SubtypeTestCache
    //     0xcf72ec: ldr             x3, [x3, #0xb88]
    // 0xcf72f0: r24 = Subtype5TestCacheStub
    //     0xcf72f0: ldr             x24, [PP, #0xc78]  ; [pp+0xc78] Stub: Subtype5TestCache (0x4ae1bc)
    // 0xcf72f4: LoadField: r30 = r24->field_7
    //     0xcf72f4: ldur            lr, [x24, #7]
    // 0xcf72f8: blr             lr
    // 0xcf72fc: cmp             w7, NULL
    // 0xcf7300: b.eq            #0xcf730c
    // 0xcf7304: tbnz            w7, #4, #0xcf732c
    // 0xcf7308: b               #0xcf7334
    // 0xcf730c: r8 = Future<Y0>
    //     0xcf730c: add             x8, PP, #0x37, lsl #12  ; [pp+0x37b90] Type: Future<Y0>
    //     0xcf7310: ldr             x8, [x8, #0xb90]
    // 0xcf7314: r3 = SubtypeTestCache
    //     0xcf7314: add             x3, PP, #0x37, lsl #12  ; [pp+0x37b98] SubtypeTestCache
    //     0xcf7318: ldr             x3, [x3, #0xb98]
    // 0xcf731c: r24 = InstanceOfStub
    //     0xcf731c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcf7320: LoadField: r30 = r24->field_7
    //     0xcf7320: ldur            lr, [x24, #7]
    // 0xcf7324: blr             lr
    // 0xcf7328: b               #0xcf7338
    // 0xcf732c: r0 = false
    //     0xcf732c: add             x0, NULL, #0x30  ; false
    // 0xcf7330: b               #0xcf7338
    // 0xcf7334: r0 = true
    //     0xcf7334: add             x0, NULL, #0x20  ; true
    // 0xcf7338: tbnz            w0, #4, #0xcf734c
    // 0xcf733c: ldur            x0, [fp, #-0x10]
    // 0xcf7340: LeaveFrame
    //     0xcf7340: mov             SP, fp
    //     0xcf7344: ldp             fp, lr, [SP], #0x10
    // 0xcf7348: ret
    //     0xcf7348: ret             
    // 0xcf734c: ldur            x0, [fp, #-0x10]
    // 0xcf7350: ldur            x1, [fp, #-8]
    // 0xcf7354: r0 = SynchronousFuture()
    //     0xcf7354: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xcf7358: ldur            x1, [fp, #-0x10]
    // 0xcf735c: StoreField: r0->field_b = r1
    //     0xcf735c: stur            w1, [x0, #0xb]
    // 0xcf7360: LeaveFrame
    //     0xcf7360: mov             SP, fp
    //     0xcf7364: ldp             fp, lr, [SP], #0x10
    // 0xcf7368: ret
    //     0xcf7368: ret             
    // 0xcf736c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf736c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7370: b               #0xcf72a4
  }
}

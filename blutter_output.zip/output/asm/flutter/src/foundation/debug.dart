// lib: , url: package:flutter/src/foundation/debug.dart

// class id: 1049131, size: 0x8
class :: {

  static _ debugFormatDouble(/* No info */) {
    // ** addr: 0xa77fb4, size: 0x54
    // 0xa77fb4: EnterFrame
    //     0xa77fb4: stp             fp, lr, [SP, #-0x10]!
    //     0xa77fb8: mov             fp, SP
    // 0xa77fbc: CheckStackOverflow
    //     0xa77fbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa77fc0: cmp             SP, x16
    //     0xa77fc4: b.ls            #0xa78000
    // 0xa77fc8: ldr             x0, [fp, #0x10]
    // 0xa77fcc: cmp             w0, NULL
    // 0xa77fd0: b.ne            #0xa77fe4
    // 0xa77fd4: r0 = "null"
    //     0xa77fd4: ldr             x0, [PP, #0x1718]  ; [pp+0x1718] "null"
    // 0xa77fd8: LeaveFrame
    //     0xa77fd8: mov             SP, fp
    //     0xa77fdc: ldp             fp, lr, [SP], #0x10
    // 0xa77fe0: ret
    //     0xa77fe0: ret             
    // 0xa77fe4: r1 = 1
    //     0xa77fe4: mov             x1, #1
    // 0xa77fe8: stp             x1, x0, [SP, #-0x10]!
    // 0xa77fec: r0 = toStringAsFixed()
    //     0xa77fec: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xa77ff0: add             SP, SP, #0x10
    // 0xa77ff4: LeaveFrame
    //     0xa77ff4: mov             SP, fp
    //     0xa77ff8: ldp             fp, lr, [SP], #0x10
    // 0xa77ffc: ret
    //     0xa77ffc: ret             
    // 0xa78000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78000: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78004: b               #0xa77fc8
  }
}

// lib: , url: package:flutter/src/foundation/diagnostics.dart

// class id: 1049132, size: 0x8
class :: {

  static String describeIdentity(Object?) {
    // ** addr: 0xa77c6c, size: 0x94
    // 0xa77c6c: EnterFrame
    //     0xa77c6c: stp             fp, lr, [SP, #-0x10]!
    //     0xa77c70: mov             fp, SP
    // 0xa77c74: AllocStack(0x8)
    //     0xa77c74: sub             SP, SP, #8
    // 0xa77c78: CheckStackOverflow
    //     0xa77c78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa77c7c: cmp             SP, x16
    //     0xa77c80: b.ls            #0xa77cf8
    // 0xa77c84: r1 = Null
    //     0xa77c84: mov             x1, NULL
    // 0xa77c88: r2 = 6
    //     0xa77c88: mov             x2, #6
    // 0xa77c8c: r0 = AllocateArray()
    //     0xa77c8c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa77c90: stur            x0, [fp, #-8]
    // 0xa77c94: r17 = "<optimized out>"
    //     0xa77c94: ldr             x17, [PP, #0x70d0]  ; [pp+0x70d0] "<optimized out>"
    // 0xa77c98: StoreField: r0->field_f = r17
    //     0xa77c98: stur            w17, [x0, #0xf]
    // 0xa77c9c: r17 = "#"
    //     0xa77c9c: ldr             x17, [PP, #0x11c8]  ; [pp+0x11c8] "#"
    // 0xa77ca0: StoreField: r0->field_13 = r17
    //     0xa77ca0: stur            w17, [x0, #0x13]
    // 0xa77ca4: ldr             x16, [fp, #0x10]
    // 0xa77ca8: SaveReg r16
    //     0xa77ca8: str             x16, [SP, #-8]!
    // 0xa77cac: r0 = shortHash()
    //     0xa77cac: bl              #0xa77d00  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xa77cb0: add             SP, SP, #8
    // 0xa77cb4: ldur            x1, [fp, #-8]
    // 0xa77cb8: ArrayStore: r1[2] = r0  ; List_4
    //     0xa77cb8: add             x25, x1, #0x17
    //     0xa77cbc: str             w0, [x25]
    //     0xa77cc0: tbz             w0, #0, #0xa77cdc
    //     0xa77cc4: ldurb           w16, [x1, #-1]
    //     0xa77cc8: ldurb           w17, [x0, #-1]
    //     0xa77ccc: and             x16, x17, x16, lsr #2
    //     0xa77cd0: tst             x16, HEAP, lsr #32
    //     0xa77cd4: b.eq            #0xa77cdc
    //     0xa77cd8: bl              #0xd67e5c
    // 0xa77cdc: ldur            x16, [fp, #-8]
    // 0xa77ce0: SaveReg r16
    //     0xa77ce0: str             x16, [SP, #-8]!
    // 0xa77ce4: r0 = _interpolate()
    //     0xa77ce4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa77ce8: add             SP, SP, #8
    // 0xa77cec: LeaveFrame
    //     0xa77cec: mov             SP, fp
    //     0xa77cf0: ldp             fp, lr, [SP], #0x10
    // 0xa77cf4: ret
    //     0xa77cf4: ret             
    // 0xa77cf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa77cf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa77cfc: b               #0xa77c84
  }
  static String shortHash(Object?) {
    // ** addr: 0xa77d00, size: 0x9c
    // 0xa77d00: EnterFrame
    //     0xa77d00: stp             fp, lr, [SP, #-0x10]!
    //     0xa77d04: mov             fp, SP
    // 0xa77d08: CheckStackOverflow
    //     0xa77d08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa77d0c: cmp             SP, x16
    //     0xa77d10: b.ls            #0xa77d94
    // 0xa77d14: ldr             x0, [fp, #0x10]
    // 0xa77d18: r1 = 59
    //     0xa77d18: mov             x1, #0x3b
    // 0xa77d1c: branchIfSmi(r0, 0xa77d28)
    //     0xa77d1c: tbz             w0, #0, #0xa77d28
    // 0xa77d20: r1 = LoadClassIdInstr(r0)
    //     0xa77d20: ldur            x1, [x0, #-1]
    //     0xa77d24: ubfx            x1, x1, #0xc, #0x14
    // 0xa77d28: SaveReg r0
    //     0xa77d28: str             x0, [SP, #-8]!
    // 0xa77d2c: mov             x0, x1
    // 0xa77d30: r0 = GDT[cid_x0 + 0x2721]()
    //     0xa77d30: mov             x17, #0x2721
    //     0xa77d34: add             lr, x0, x17
    //     0xa77d38: ldr             lr, [x21, lr, lsl #3]
    //     0xa77d3c: blr             lr
    // 0xa77d40: add             SP, SP, #8
    // 0xa77d44: r1 = LoadInt32Instr(r0)
    //     0xa77d44: sbfx            x1, x0, #1, #0x1f
    //     0xa77d48: tbz             w0, #0, #0xa77d50
    //     0xa77d4c: ldur            x1, [x0, #7]
    // 0xa77d50: r0 = 1048575
    //     0xa77d50: mov             x0, #0xfffff
    // 0xa77d54: and             x2, x1, x0
    // 0xa77d58: lsl             w0, w2, #1
    // 0xa77d5c: SaveReg r0
    //     0xa77d5c: str             x0, [SP, #-8]!
    // 0xa77d60: r0 = 16
    //     0xa77d60: mov             x0, #0x10
    // 0xa77d64: SaveReg r0
    //     0xa77d64: str             x0, [SP, #-8]!
    // 0xa77d68: r0 = _toPow2String()
    //     0xa77d68: bl              #0x506b60  ; [dart:core] _IntegerImplementation::_toPow2String
    // 0xa77d6c: add             SP, SP, #0x10
    // 0xa77d70: SaveReg r0
    //     0xa77d70: str             x0, [SP, #-8]!
    // 0xa77d74: r0 = 5
    //     0xa77d74: mov             x0, #5
    // 0xa77d78: r16 = "0"
    //     0xa77d78: ldr             x16, [PP, #0x3af8]  ; [pp+0x3af8] "0"
    // 0xa77d7c: stp             x16, x0, [SP, #-0x10]!
    // 0xa77d80: r0 = padLeft()
    //     0xa77d80: bl              #0xd65600  ; [dart:core] _OneByteString::padLeft
    // 0xa77d84: add             SP, SP, #0x18
    // 0xa77d88: LeaveFrame
    //     0xa77d88: mov             SP, fp
    //     0xa77d8c: ldp             fp, lr, [SP], #0x10
    // 0xa77d90: ret
    //     0xa77d90: ret             
    // 0xa77d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa77d94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa77d98: b               #0xa77d14
  }
}

// class id: 2607, size: 0x8, field offset: 0x8
abstract class DiagnosticsNode extends Object {

  factory _ DiagnosticsNode.message(/* No info */) {
    // ** addr: 0x4fc534, size: 0x3c
    // 0x4fc534: EnterFrame
    //     0x4fc534: stp             fp, lr, [SP, #-0x10]!
    //     0x4fc538: mov             fp, SP
    // 0x4fc53c: r1 = <void?>
    //     0x4fc53c: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x4fc540: r0 = DiagnosticsProperty()
    //     0x4fc540: bl              #0x4fc570  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x30)
    // 0x4fc544: r1 = Instance__NoDefaultValue
    //     0x4fc544: ldr             x1, [PP, #0xf40]  ; [pp+0xf40] Obj!_NoDefaultValue@b387f1
    // 0x4fc548: StoreField: r0->field_23 = r1
    //     0x4fc548: stur            w1, [x0, #0x23]
    // 0x4fc54c: r1 = false
    //     0x4fc54c: add             x1, NULL, #0x30  ; false
    // 0x4fc550: StoreField: r0->field_13 = r1
    //     0x4fc550: stur            w1, [x0, #0x13]
    // 0x4fc554: r1 = true
    //     0x4fc554: add             x1, NULL, #0x20  ; true
    // 0x4fc558: StoreField: r0->field_1b = r1
    //     0x4fc558: stur            w1, [x0, #0x1b]
    // 0x4fc55c: r1 = Instance_DiagnosticLevel
    //     0x4fc55c: ldr             x1, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x4fc560: StoreField: r0->field_27 = r1
    //     0x4fc560: stur            w1, [x0, #0x27]
    // 0x4fc564: LeaveFrame
    //     0x4fc564: mov             SP, fp
    //     0x4fc568: ldp             fp, lr, [SP], #0x10
    // 0x4fc56c: ret
    //     0x4fc56c: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad8710, size: 0x60
    // 0xad8710: EnterFrame
    //     0xad8710: stp             fp, lr, [SP, #-0x10]!
    //     0xad8714: mov             fp, SP
    // 0xad8718: mov             x0, x4
    // 0xad871c: LoadField: r1 = r0->field_13
    //     0xad871c: ldur            w1, [x0, #0x13]
    // 0xad8720: DecompressPointer r1
    //     0xad8720: add             x1, x1, HEAP, lsl #32
    // 0xad8724: sub             x2, x1, #2
    // 0xad8728: add             x1, fp, w2, sxtw #2
    // 0xad872c: ldr             x1, [x1, #0x10]
    // 0xad8730: LoadField: r2 = r0->field_1f
    //     0xad8730: ldur            w2, [x0, #0x1f]
    // 0xad8734: DecompressPointer r2
    //     0xad8734: add             x2, x2, HEAP, lsl #32
    // 0xad8738: r16 = "minLevel"
    //     0xad8738: ldr             x16, [PP, #0x7500]  ; [pp+0x7500] "minLevel"
    // 0xad873c: cmp             w2, w16
    // 0xad8740: b.eq            #0xad8744
    // 0xad8744: CheckStackOverflow
    //     0xad8744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8748: cmp             SP, x16
    //     0xad874c: b.ls            #0xad8768
    // 0xad8750: SaveReg r1
    //     0xad8750: str             x1, [SP, #-8]!
    // 0xad8754: r0 = toString()
    //     0xad8754: bl              #0xaf6f6c  ; [dart:core] Object::toString
    // 0xad8758: add             SP, SP, #8
    // 0xad875c: LeaveFrame
    //     0xad875c: mov             SP, fp
    //     0xad8760: ldp             fp, lr, [SP], #0x10
    // 0xad8764: ret
    //     0xad8764: ret             
    // 0xad8768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad8768: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad876c: b               #0xad8750
  }
}

// class id: 2608, size: 0xc, field offset: 0x8
class DiagnosticableNode<X0 bound Diagnosticable> extends DiagnosticsNode {
}

// class id: 2610, size: 0xc, field offset: 0xc
class DiagnosticableTreeNode extends DiagnosticableNode<DiagnosticableTree> {
}

// class id: 2615, size: 0x30, field offset: 0x8
class DiagnosticsProperty<X0> extends DiagnosticsNode {

  get _ value(/* No info */) {
    // ** addr: 0xb80794, size: 0x44
    // 0xb80794: EnterFrame
    //     0xb80794: stp             fp, lr, [SP, #-0x10]!
    //     0xb80798: mov             fp, SP
    // 0xb8079c: CheckStackOverflow
    //     0xb8079c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb807a0: cmp             SP, x16
    //     0xb807a4: b.ls            #0xb807d0
    // 0xb807a8: ldr             x16, [fp, #0x10]
    // 0xb807ac: SaveReg r16
    //     0xb807ac: str             x16, [SP, #-8]!
    // 0xb807b0: r0 = _maybeCacheValue()
    //     0xb807b0: bl              #0xb807d8  ; [package:flutter/src/foundation/diagnostics.dart] DiagnosticsProperty::_maybeCacheValue
    // 0xb807b4: add             SP, SP, #8
    // 0xb807b8: ldr             x1, [fp, #0x10]
    // 0xb807bc: LoadField: r0 = r1->field_17
    //     0xb807bc: ldur            w0, [x1, #0x17]
    // 0xb807c0: DecompressPointer r0
    //     0xb807c0: add             x0, x0, HEAP, lsl #32
    // 0xb807c4: LeaveFrame
    //     0xb807c4: mov             SP, fp
    //     0xb807c8: ldp             fp, lr, [SP], #0x10
    // 0xb807cc: ret
    //     0xb807cc: ret             
    // 0xb807d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb807d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb807d4: b               #0xb807a8
  }
  _ _maybeCacheValue(/* No info */) {
    // ** addr: 0xb807d8, size: 0x58
    // 0xb807d8: EnterFrame
    //     0xb807d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb807dc: mov             fp, SP
    // 0xb807e0: AllocStack(0x30)
    //     0xb807e0: sub             SP, SP, #0x30
    // 0xb807e4: r0 = Null
    //     0xb807e4: mov             x0, NULL
    // 0xb807e8: LeaveFrame
    //     0xb807e8: mov             SP, fp
    //     0xb807ec: ldp             fp, lr, [SP], #0x10
    // 0xb807f0: ret
    //     0xb807f0: ret             
    // 0xb807f4: sub             SP, fp, #0x30
    // 0xb807f8: ldr             x1, [fp, #0x10]
    // 0xb807fc: StoreField: r1->field_1f = r0
    //     0xb807fc: stur            w0, [x1, #0x1f]
    //     0xb80800: tbz             w0, #0, #0xb8081c
    //     0xb80804: ldurb           w16, [x1, #-1]
    //     0xb80808: ldurb           w17, [x0, #-1]
    //     0xb8080c: and             x16, x17, x16, lsr #2
    //     0xb80810: tst             x16, HEAP, lsr #32
    //     0xb80814: b.eq            #0xb8081c
    //     0xb80818: bl              #0xd6826c
    // 0xb8081c: StoreField: r1->field_17 = rNULL
    //     0xb8081c: stur            NULL, [x1, #0x17]
    // 0xb80820: r0 = Null
    //     0xb80820: mov             x0, NULL
    // 0xb80824: LeaveFrame
    //     0xb80824: mov             SP, fp
    //     0xb80828: ldp             fp, lr, [SP], #0x10
    // 0xb8082c: ret
    //     0xb8082c: ret             
  }
}

// class id: 2638, size: 0x8, field offset: 0x8
//   const constructor, 
class _NoDefaultValue extends Object {
}

// class id: 2654, size: 0x8, field offset: 0x8
abstract class DiagnosticableTreeMixin extends Object
    implements DiagnosticableTree {
}

// class id: 2664, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class _DiagnosticableTree&Object&Diagnosticable extends Object
     with Diagnosticable {
}

// class id: 3423, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class DiagnosticableTree extends _DiagnosticableTree&Object&Diagnosticable {
}

// class id: 4251, size: 0x8, field offset: 0x8
abstract class Diagnosticable extends Object {
}

// class id: 5985, size: 0x14, field offset: 0x14
enum DiagnosticLevel extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15bd4, size: 0x5c
    // 0xb15bd4: EnterFrame
    //     0xb15bd4: stp             fp, lr, [SP, #-0x10]!
    //     0xb15bd8: mov             fp, SP
    // 0xb15bdc: CheckStackOverflow
    //     0xb15bdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15be0: cmp             SP, x16
    //     0xb15be4: b.ls            #0xb15c28
    // 0xb15be8: r1 = Null
    //     0xb15be8: mov             x1, NULL
    // 0xb15bec: r2 = 4
    //     0xb15bec: mov             x2, #4
    // 0xb15bf0: r0 = AllocateArray()
    //     0xb15bf0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15bf4: r17 = "DiagnosticLevel."
    //     0xb15bf4: add             x17, PP, #0xb, lsl #12  ; [pp+0xb130] "DiagnosticLevel."
    //     0xb15bf8: ldr             x17, [x17, #0x130]
    // 0xb15bfc: StoreField: r0->field_f = r17
    //     0xb15bfc: stur            w17, [x0, #0xf]
    // 0xb15c00: ldr             x1, [fp, #0x10]
    // 0xb15c04: LoadField: r2 = r1->field_f
    //     0xb15c04: ldur            w2, [x1, #0xf]
    // 0xb15c08: DecompressPointer r2
    //     0xb15c08: add             x2, x2, HEAP, lsl #32
    // 0xb15c0c: StoreField: r0->field_13 = r2
    //     0xb15c0c: stur            w2, [x0, #0x13]
    // 0xb15c10: SaveReg r0
    //     0xb15c10: str             x0, [SP, #-8]!
    // 0xb15c14: r0 = _interpolate()
    //     0xb15c14: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15c18: add             SP, SP, #8
    // 0xb15c1c: LeaveFrame
    //     0xb15c1c: mov             SP, fp
    //     0xb15c20: ldp             fp, lr, [SP], #0x10
    // 0xb15c24: ret
    //     0xb15c24: ret             
    // 0xb15c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15c28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15c2c: b               #0xb15be8
  }
}

// lib: , url: package:flutter/src/foundation/node.dart

// class id: 1049138, size: 0x8
class :: {
}

// class id: 2377, size: 0x18, field offset: 0x8
abstract class AbstractNode extends Object {

  _ dropChild(/* No info */) {
    // ** addr: 0x5df5b4, size: 0x6c
    // 0x5df5b4: EnterFrame
    //     0x5df5b4: stp             fp, lr, [SP, #-0x10]!
    //     0x5df5b8: mov             fp, SP
    // 0x5df5bc: CheckStackOverflow
    //     0x5df5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5df5c0: cmp             SP, x16
    //     0x5df5c4: b.ls            #0x5df618
    // 0x5df5c8: ldr             x0, [fp, #0x10]
    // 0x5df5cc: StoreField: r0->field_13 = rNULL
    //     0x5df5cc: stur            NULL, [x0, #0x13]
    // 0x5df5d0: ldr             x1, [fp, #0x18]
    // 0x5df5d4: LoadField: r2 = r1->field_f
    //     0x5df5d4: ldur            w2, [x1, #0xf]
    // 0x5df5d8: DecompressPointer r2
    //     0x5df5d8: add             x2, x2, HEAP, lsl #32
    // 0x5df5dc: cmp             w2, NULL
    // 0x5df5e0: b.eq            #0x5df608
    // 0x5df5e4: r1 = LoadClassIdInstr(r0)
    //     0x5df5e4: ldur            x1, [x0, #-1]
    //     0x5df5e8: ubfx            x1, x1, #0xc, #0x14
    // 0x5df5ec: SaveReg r0
    //     0x5df5ec: str             x0, [SP, #-8]!
    // 0x5df5f0: mov             x0, x1
    // 0x5df5f4: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0x5df5f4: mov             x17, #0xa3cc
    //     0x5df5f8: add             lr, x0, x17
    //     0x5df5fc: ldr             lr, [x21, lr, lsl #3]
    //     0x5df600: blr             lr
    // 0x5df604: add             SP, SP, #8
    // 0x5df608: r0 = Null
    //     0x5df608: mov             x0, NULL
    // 0x5df60c: LeaveFrame
    //     0x5df60c: mov             SP, fp
    //     0x5df610: ldp             fp, lr, [SP], #0x10
    // 0x5df614: ret
    //     0x5df614: ret             
    // 0x5df618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5df618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5df61c: b               #0x5df5c8
  }
  _ adoptChild(/* No info */) {
    // ** addr: 0x5e6280, size: 0x9c
    // 0x5e6280: EnterFrame
    //     0x5e6280: stp             fp, lr, [SP, #-0x10]!
    //     0x5e6284: mov             fp, SP
    // 0x5e6288: CheckStackOverflow
    //     0x5e6288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e628c: cmp             SP, x16
    //     0x5e6290: b.ls            #0x5e6314
    // 0x5e6294: ldr             x0, [fp, #0x18]
    // 0x5e6298: ldr             x1, [fp, #0x10]
    // 0x5e629c: StoreField: r1->field_13 = r0
    //     0x5e629c: stur            w0, [x1, #0x13]
    //     0x5e62a0: ldurb           w16, [x1, #-1]
    //     0x5e62a4: ldurb           w17, [x0, #-1]
    //     0x5e62a8: and             x16, x17, x16, lsr #2
    //     0x5e62ac: tst             x16, HEAP, lsr #32
    //     0x5e62b0: b.eq            #0x5e62b8
    //     0x5e62b4: bl              #0xd6826c
    // 0x5e62b8: ldr             x2, [fp, #0x18]
    // 0x5e62bc: LoadField: r0 = r2->field_f
    //     0x5e62bc: ldur            w0, [x2, #0xf]
    // 0x5e62c0: DecompressPointer r0
    //     0x5e62c0: add             x0, x0, HEAP, lsl #32
    // 0x5e62c4: cmp             w0, NULL
    // 0x5e62c8: b.eq            #0x5e62f0
    // 0x5e62cc: r3 = LoadClassIdInstr(r1)
    //     0x5e62cc: ldur            x3, [x1, #-1]
    //     0x5e62d0: ubfx            x3, x3, #0xc, #0x14
    // 0x5e62d4: stp             x0, x1, [SP, #-0x10]!
    // 0x5e62d8: mov             x0, x3
    // 0x5e62dc: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x5e62dc: mov             x17, #0xaf1f
    //     0x5e62e0: add             lr, x0, x17
    //     0x5e62e4: ldr             lr, [x21, lr, lsl #3]
    //     0x5e62e8: blr             lr
    // 0x5e62ec: add             SP, SP, #0x10
    // 0x5e62f0: ldr             x16, [fp, #0x18]
    // 0x5e62f4: ldr             lr, [fp, #0x10]
    // 0x5e62f8: stp             lr, x16, [SP, #-0x10]!
    // 0x5e62fc: r0 = redepthChild()
    //     0x5e62fc: bl              #0x5e631c  ; [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild
    // 0x5e6300: add             SP, SP, #0x10
    // 0x5e6304: r0 = Null
    //     0x5e6304: mov             x0, NULL
    // 0x5e6308: LeaveFrame
    //     0x5e6308: mov             SP, fp
    //     0x5e630c: ldp             fp, lr, [SP], #0x10
    // 0x5e6310: ret
    //     0x5e6310: ret             
    // 0x5e6314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e6314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e6318: b               #0x5e6294
  }
  _ redepthChild(/* No info */) {
    // ** addr: 0x5e631c, size: 0x70
    // 0x5e631c: EnterFrame
    //     0x5e631c: stp             fp, lr, [SP, #-0x10]!
    //     0x5e6320: mov             fp, SP
    // 0x5e6324: CheckStackOverflow
    //     0x5e6324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e6328: cmp             SP, x16
    //     0x5e632c: b.ls            #0x5e6384
    // 0x5e6330: ldr             x0, [fp, #0x10]
    // 0x5e6334: LoadField: r1 = r0->field_7
    //     0x5e6334: ldur            x1, [x0, #7]
    // 0x5e6338: ldr             x2, [fp, #0x18]
    // 0x5e633c: LoadField: r3 = r2->field_7
    //     0x5e633c: ldur            x3, [x2, #7]
    // 0x5e6340: cmp             x1, x3
    // 0x5e6344: b.gt            #0x5e6374
    // 0x5e6348: add             x1, x3, #1
    // 0x5e634c: StoreField: r0->field_7 = r1
    //     0x5e634c: stur            x1, [x0, #7]
    // 0x5e6350: r1 = LoadClassIdInstr(r0)
    //     0x5e6350: ldur            x1, [x0, #-1]
    //     0x5e6354: ubfx            x1, x1, #0xc, #0x14
    // 0x5e6358: SaveReg r0
    //     0x5e6358: str             x0, [SP, #-8]!
    // 0x5e635c: mov             x0, x1
    // 0x5e6360: r0 = GDT[cid_x0 + 0xbdf1]()
    //     0x5e6360: mov             x17, #0xbdf1
    //     0x5e6364: add             lr, x0, x17
    //     0x5e6368: ldr             lr, [x21, lr, lsl #3]
    //     0x5e636c: blr             lr
    // 0x5e6370: add             SP, SP, #8
    // 0x5e6374: r0 = Null
    //     0x5e6374: mov             x0, NULL
    // 0x5e6378: LeaveFrame
    //     0x5e6378: mov             SP, fp
    //     0x5e637c: ldp             fp, lr, [SP], #0x10
    // 0x5e6380: ret
    //     0x5e6380: ret             
    // 0x5e6384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e6384: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e6388: b               #0x5e6330
  }
  [closure] void redepthChild(dynamic, AbstractNode) {
    // ** addr: 0x5e638c, size: 0x4c
    // 0x5e638c: EnterFrame
    //     0x5e638c: stp             fp, lr, [SP, #-0x10]!
    //     0x5e6390: mov             fp, SP
    // 0x5e6394: ldr             x0, [fp, #0x18]
    // 0x5e6398: LoadField: r1 = r0->field_17
    //     0x5e6398: ldur            w1, [x0, #0x17]
    // 0x5e639c: DecompressPointer r1
    //     0x5e639c: add             x1, x1, HEAP, lsl #32
    // 0x5e63a0: CheckStackOverflow
    //     0x5e63a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e63a4: cmp             SP, x16
    //     0x5e63a8: b.ls            #0x5e63d0
    // 0x5e63ac: LoadField: r0 = r1->field_f
    //     0x5e63ac: ldur            w0, [x1, #0xf]
    // 0x5e63b0: DecompressPointer r0
    //     0x5e63b0: add             x0, x0, HEAP, lsl #32
    // 0x5e63b4: ldr             x16, [fp, #0x10]
    // 0x5e63b8: stp             x16, x0, [SP, #-0x10]!
    // 0x5e63bc: r0 = redepthChild()
    //     0x5e63bc: bl              #0x5e631c  ; [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild
    // 0x5e63c0: add             SP, SP, #0x10
    // 0x5e63c4: LeaveFrame
    //     0x5e63c4: mov             SP, fp
    //     0x5e63c8: ldp             fp, lr, [SP], #0x10
    // 0x5e63cc: ret
    //     0x5e63cc: ret             
    // 0x5e63d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e63d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e63d4: b               #0x5e63ac
  }
  _ detach(/* No info */) {
    // ** addr: 0xa6ade0, size: 0x10
    // 0xa6ade0: ldr             x1, [SP]
    // 0xa6ade4: StoreField: r1->field_f = rNULL
    //     0xa6ade4: stur            NULL, [x1, #0xf]
    // 0xa6ade8: r0 = Null
    //     0xa6ade8: mov             x0, NULL
    // 0xa6adec: ret
    //     0xa6adec: ret             
  }
}

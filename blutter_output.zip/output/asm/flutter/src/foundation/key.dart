// lib: , url: package:flutter/src/foundation/key.dart

// class id: 1049134, size: 0x8
class :: {
}

// class id: 2596, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Key extends Object {
}

// class id: 2601, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class LocalKey extends Key {
}

// class id: 2602, size: 0x10, field offset: 0x8
//   const constructor, 
class ValueKey<X0> extends LocalKey {

  _Mint field_c;

  _ toString(/* No info */) {
    // ** addr: 0xad8804, size: 0x228
    // 0xad8804: EnterFrame
    //     0xad8804: stp             fp, lr, [SP, #-0x10]!
    //     0xad8808: mov             fp, SP
    // 0xad880c: AllocStack(0x18)
    //     0xad880c: sub             SP, SP, #0x18
    // 0xad8810: CheckStackOverflow
    //     0xad8810: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8814: cmp             SP, x16
    //     0xad8818: b.ls            #0xad8a24
    // 0xad881c: ldr             x0, [fp, #0x10]
    // 0xad8820: LoadField: r3 = r0->field_7
    //     0xad8820: ldur            w3, [x0, #7]
    // 0xad8824: DecompressPointer r3
    //     0xad8824: add             x3, x3, HEAP, lsl #32
    // 0xad8828: mov             x2, x3
    // 0xad882c: stur            x3, [fp, #-8]
    // 0xad8830: r1 = Null
    //     0xad8830: mov             x1, NULL
    // 0xad8834: r3 = X0
    //     0xad8834: ldr             x3, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xad8838: r24 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0xad8838: add             x24, PP, #0xd, lsl #12  ; [pp+0xd4a8] Stub: InstantiateTypeNonNullableClassTypeParameter (0x4ace18)
    //     0xad883c: ldr             x24, [x24, #0x4a8]
    // 0xad8840: LoadField: r30 = r24->field_7
    //     0xad8840: ldur            lr, [x24, #7]
    // 0xad8844: blr             lr
    // 0xad8848: r1 = LoadClassIdInstr(r0)
    //     0xad8848: ldur            x1, [x0, #-1]
    //     0xad884c: ubfx            x1, x1, #0xc, #0x14
    // 0xad8850: r16 = String
    //     0xad8850: ldr             x16, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xad8854: stp             x16, x0, [SP, #-0x10]!
    // 0xad8858: mov             x0, x1
    // 0xad885c: mov             lr, x0
    // 0xad8860: ldr             lr, [x21, lr, lsl #3]
    // 0xad8864: blr             lr
    // 0xad8868: add             SP, SP, #0x10
    // 0xad886c: tbnz            w0, #4, #0xad88b8
    // 0xad8870: ldr             x0, [fp, #0x10]
    // 0xad8874: r1 = Null
    //     0xad8874: mov             x1, NULL
    // 0xad8878: r2 = 6
    //     0xad8878: mov             x2, #6
    // 0xad887c: r0 = AllocateArray()
    //     0xad887c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad8880: r17 = "<\'"
    //     0xad8880: add             x17, PP, #0xe, lsl #12  ; [pp+0xe4f0] "<\'"
    //     0xad8884: ldr             x17, [x17, #0x4f0]
    // 0xad8888: StoreField: r0->field_f = r17
    //     0xad8888: stur            w17, [x0, #0xf]
    // 0xad888c: ldr             x1, [fp, #0x10]
    // 0xad8890: LoadField: r2 = r1->field_b
    //     0xad8890: ldur            w2, [x1, #0xb]
    // 0xad8894: DecompressPointer r2
    //     0xad8894: add             x2, x2, HEAP, lsl #32
    // 0xad8898: StoreField: r0->field_13 = r2
    //     0xad8898: stur            w2, [x0, #0x13]
    // 0xad889c: r17 = "\'>"
    //     0xad889c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe4f8] "\'>"
    //     0xad88a0: ldr             x17, [x17, #0x4f8]
    // 0xad88a4: StoreField: r0->field_17 = r17
    //     0xad88a4: stur            w17, [x0, #0x17]
    // 0xad88a8: SaveReg r0
    //     0xad88a8: str             x0, [SP, #-8]!
    // 0xad88ac: r0 = _interpolate()
    //     0xad88ac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad88b0: add             SP, SP, #8
    // 0xad88b4: b               #0xad88f4
    // 0xad88b8: ldr             x0, [fp, #0x10]
    // 0xad88bc: r1 = Null
    //     0xad88bc: mov             x1, NULL
    // 0xad88c0: r2 = 6
    //     0xad88c0: mov             x2, #6
    // 0xad88c4: r0 = AllocateArray()
    //     0xad88c4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad88c8: r17 = "<"
    //     0xad88c8: ldr             x17, [PP, #0x1100]  ; [pp+0x1100] "<"
    // 0xad88cc: StoreField: r0->field_f = r17
    //     0xad88cc: stur            w17, [x0, #0xf]
    // 0xad88d0: ldr             x1, [fp, #0x10]
    // 0xad88d4: LoadField: r2 = r1->field_b
    //     0xad88d4: ldur            w2, [x1, #0xb]
    // 0xad88d8: DecompressPointer r2
    //     0xad88d8: add             x2, x2, HEAP, lsl #32
    // 0xad88dc: StoreField: r0->field_13 = r2
    //     0xad88dc: stur            w2, [x0, #0x13]
    // 0xad88e0: r17 = ">"
    //     0xad88e0: ldr             x17, [PP, #0x1068]  ; [pp+0x1068] ">"
    // 0xad88e4: StoreField: r0->field_17 = r17
    //     0xad88e4: stur            w17, [x0, #0x17]
    // 0xad88e8: SaveReg r0
    //     0xad88e8: str             x0, [SP, #-8]!
    // 0xad88ec: r0 = _interpolate()
    //     0xad88ec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad88f0: add             SP, SP, #8
    // 0xad88f4: stur            x0, [fp, #-0x10]
    // 0xad88f8: ldr             x16, [fp, #0x10]
    // 0xad88fc: SaveReg r16
    //     0xad88fc: str             x16, [SP, #-8]!
    // 0xad8900: r0 = runtimeType()
    //     0xad8900: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xad8904: add             SP, SP, #8
    // 0xad8908: ldur            x2, [fp, #-8]
    // 0xad890c: r1 = Null
    //     0xad890c: mov             x1, NULL
    // 0xad8910: r3 = <ValueKey<X0>>
    //     0xad8910: add             x3, PP, #0xe, lsl #12  ; [pp+0xe500] TypeArguments: <ValueKey<X0>>
    //     0xad8914: ldr             x3, [x3, #0x500]
    // 0xad8918: stur            x0, [fp, #-0x18]
    // 0xad891c: r24 = InstantiateTypeArgumentsStub
    //     0xad891c: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xad8920: LoadField: r30 = r24->field_7
    //     0xad8920: ldur            lr, [x24, #7]
    // 0xad8924: blr             lr
    // 0xad8928: mov             x2, x0
    // 0xad892c: r1 = Null
    //     0xad892c: mov             x1, NULL
    // 0xad8930: r3 = X0
    //     0xad8930: ldr             x3, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xad8934: r24 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0xad8934: add             x24, PP, #0xd, lsl #12  ; [pp+0xd4a8] Stub: InstantiateTypeNonNullableClassTypeParameter (0x4ace18)
    //     0xad8938: ldr             x24, [x24, #0x4a8]
    // 0xad893c: LoadField: r30 = r24->field_7
    //     0xad893c: ldur            lr, [x24, #7]
    // 0xad8940: blr             lr
    // 0xad8944: mov             x1, x0
    // 0xad8948: ldur            x0, [fp, #-0x18]
    // 0xad894c: r2 = LoadClassIdInstr(r0)
    //     0xad894c: ldur            x2, [x0, #-1]
    //     0xad8950: ubfx            x2, x2, #0xc, #0x14
    // 0xad8954: stp             x1, x0, [SP, #-0x10]!
    // 0xad8958: mov             x0, x2
    // 0xad895c: mov             lr, x0
    // 0xad8960: ldr             lr, [x21, lr, lsl #3]
    // 0xad8964: blr             lr
    // 0xad8968: add             SP, SP, #0x10
    // 0xad896c: tbnz            w0, #4, #0xad89b0
    // 0xad8970: ldur            x0, [fp, #-0x10]
    // 0xad8974: r1 = Null
    //     0xad8974: mov             x1, NULL
    // 0xad8978: r2 = 6
    //     0xad8978: mov             x2, #6
    // 0xad897c: r0 = AllocateArray()
    //     0xad897c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad8980: r17 = "["
    //     0xad8980: ldr             x17, [PP, #0x1468]  ; [pp+0x1468] "["
    // 0xad8984: StoreField: r0->field_f = r17
    //     0xad8984: stur            w17, [x0, #0xf]
    // 0xad8988: ldur            x3, [fp, #-0x10]
    // 0xad898c: StoreField: r0->field_13 = r3
    //     0xad898c: stur            w3, [x0, #0x13]
    // 0xad8990: r17 = "]"
    //     0xad8990: ldr             x17, [PP, #0x1460]  ; [pp+0x1460] "]"
    // 0xad8994: StoreField: r0->field_17 = r17
    //     0xad8994: stur            w17, [x0, #0x17]
    // 0xad8998: SaveReg r0
    //     0xad8998: str             x0, [SP, #-8]!
    // 0xad899c: r0 = _interpolate()
    //     0xad899c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad89a0: add             SP, SP, #8
    // 0xad89a4: LeaveFrame
    //     0xad89a4: mov             SP, fp
    //     0xad89a8: ldp             fp, lr, [SP], #0x10
    // 0xad89ac: ret
    //     0xad89ac: ret             
    // 0xad89b0: ldur            x3, [fp, #-0x10]
    // 0xad89b4: r1 = Null
    //     0xad89b4: mov             x1, NULL
    // 0xad89b8: r2 = 10
    //     0xad89b8: mov             x2, #0xa
    // 0xad89bc: r0 = AllocateArray()
    //     0xad89bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad89c0: stur            x0, [fp, #-0x18]
    // 0xad89c4: r17 = "["
    //     0xad89c4: ldr             x17, [PP, #0x1468]  ; [pp+0x1468] "["
    // 0xad89c8: StoreField: r0->field_f = r17
    //     0xad89c8: stur            w17, [x0, #0xf]
    // 0xad89cc: ldur            x2, [fp, #-8]
    // 0xad89d0: r1 = Null
    //     0xad89d0: mov             x1, NULL
    // 0xad89d4: r3 = X0
    //     0xad89d4: ldr             x3, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xad89d8: r24 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0xad89d8: add             x24, PP, #0xd, lsl #12  ; [pp+0xd4a8] Stub: InstantiateTypeNonNullableClassTypeParameter (0x4ace18)
    //     0xad89dc: ldr             x24, [x24, #0x4a8]
    // 0xad89e0: LoadField: r30 = r24->field_7
    //     0xad89e0: ldur            lr, [x24, #7]
    // 0xad89e4: blr             lr
    // 0xad89e8: mov             x1, x0
    // 0xad89ec: ldur            x0, [fp, #-0x18]
    // 0xad89f0: StoreField: r0->field_13 = r1
    //     0xad89f0: stur            w1, [x0, #0x13]
    // 0xad89f4: r17 = " "
    //     0xad89f4: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xad89f8: StoreField: r0->field_17 = r17
    //     0xad89f8: stur            w17, [x0, #0x17]
    // 0xad89fc: ldur            x1, [fp, #-0x10]
    // 0xad8a00: StoreField: r0->field_1b = r1
    //     0xad8a00: stur            w1, [x0, #0x1b]
    // 0xad8a04: r17 = "]"
    //     0xad8a04: ldr             x17, [PP, #0x1460]  ; [pp+0x1460] "]"
    // 0xad8a08: StoreField: r0->field_1f = r17
    //     0xad8a08: stur            w17, [x0, #0x1f]
    // 0xad8a0c: SaveReg r0
    //     0xad8a0c: str             x0, [SP, #-8]!
    // 0xad8a10: r0 = _interpolate()
    //     0xad8a10: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad8a14: add             SP, SP, #8
    // 0xad8a18: LeaveFrame
    //     0xad8a18: mov             SP, fp
    //     0xad8a1c: ldp             fp, lr, [SP], #0x10
    // 0xad8a20: ret
    //     0xad8a20: ret             
    // 0xad8a24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad8a24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad8a28: b               #0xad881c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb062f4, size: 0x70
    // 0xb062f4: EnterFrame
    //     0xb062f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb062f8: mov             fp, SP
    // 0xb062fc: CheckStackOverflow
    //     0xb062fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb06300: cmp             SP, x16
    //     0xb06304: b.ls            #0xb0635c
    // 0xb06308: ldr             x16, [fp, #0x10]
    // 0xb0630c: SaveReg r16
    //     0xb0630c: str             x16, [SP, #-8]!
    // 0xb06310: r0 = runtimeType()
    //     0xb06310: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xb06314: add             SP, SP, #8
    // 0xb06318: mov             x1, x0
    // 0xb0631c: ldr             x0, [fp, #0x10]
    // 0xb06320: LoadField: r2 = r0->field_b
    //     0xb06320: ldur            w2, [x0, #0xb]
    // 0xb06324: DecompressPointer r2
    //     0xb06324: add             x2, x2, HEAP, lsl #32
    // 0xb06328: stp             x2, x1, [SP, #-0x10]!
    // 0xb0632c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xb0632c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xb06330: r0 = hash()
    //     0xb06330: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb06334: add             SP, SP, #0x10
    // 0xb06338: mov             x2, x0
    // 0xb0633c: r0 = BoxInt64Instr(r2)
    //     0xb0633c: sbfiz           x0, x2, #1, #0x1f
    //     0xb06340: cmp             x2, x0, asr #1
    //     0xb06344: b.eq            #0xb06350
    //     0xb06348: bl              #0xd69bb8
    //     0xb0634c: stur            x2, [x0, #7]
    // 0xb06350: LeaveFrame
    //     0xb06350: mov             SP, fp
    //     0xb06354: ldp             fp, lr, [SP], #0x10
    // 0xb06358: ret
    //     0xb06358: ret             
    // 0xb0635c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0635c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb06360: b               #0xb06308
  }
  _ ==(/* No info */) {
    // ** addr: 0xc94b00, size: 0x180
    // 0xc94b00: EnterFrame
    //     0xc94b00: stp             fp, lr, [SP, #-0x10]!
    //     0xc94b04: mov             fp, SP
    // 0xc94b08: AllocStack(0x8)
    //     0xc94b08: sub             SP, SP, #8
    // 0xc94b0c: CheckStackOverflow
    //     0xc94b0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc94b10: cmp             SP, x16
    //     0xc94b14: b.ls            #0xc94c78
    // 0xc94b18: ldr             x1, [fp, #0x10]
    // 0xc94b1c: cmp             w1, NULL
    // 0xc94b20: b.ne            #0xc94b34
    // 0xc94b24: r0 = false
    //     0xc94b24: add             x0, NULL, #0x30  ; false
    // 0xc94b28: LeaveFrame
    //     0xc94b28: mov             SP, fp
    //     0xc94b2c: ldp             fp, lr, [SP], #0x10
    // 0xc94b30: ret
    //     0xc94b30: ret             
    // 0xc94b34: r0 = 59
    //     0xc94b34: mov             x0, #0x3b
    // 0xc94b38: branchIfSmi(r1, 0xc94b44)
    //     0xc94b38: tbz             w1, #0, #0xc94b44
    // 0xc94b3c: r0 = LoadClassIdInstr(r1)
    //     0xc94b3c: ldur            x0, [x1, #-1]
    //     0xc94b40: ubfx            x0, x0, #0xc, #0x14
    // 0xc94b44: SaveReg r1
    //     0xc94b44: str             x1, [SP, #-8]!
    // 0xc94b48: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc94b48: mov             x17, #0x57c5
    //     0xc94b4c: add             lr, x0, x17
    //     0xc94b50: ldr             lr, [x21, lr, lsl #3]
    //     0xc94b54: blr             lr
    // 0xc94b58: add             SP, SP, #8
    // 0xc94b5c: stur            x0, [fp, #-8]
    // 0xc94b60: ldr             x16, [fp, #0x18]
    // 0xc94b64: SaveReg r16
    //     0xc94b64: str             x16, [SP, #-8]!
    // 0xc94b68: r0 = runtimeType()
    //     0xc94b68: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc94b6c: add             SP, SP, #8
    // 0xc94b70: mov             x1, x0
    // 0xc94b74: ldur            x0, [fp, #-8]
    // 0xc94b78: r2 = LoadClassIdInstr(r0)
    //     0xc94b78: ldur            x2, [x0, #-1]
    //     0xc94b7c: ubfx            x2, x2, #0xc, #0x14
    // 0xc94b80: stp             x1, x0, [SP, #-0x10]!
    // 0xc94b84: mov             x0, x2
    // 0xc94b88: mov             lr, x0
    // 0xc94b8c: ldr             lr, [x21, lr, lsl #3]
    // 0xc94b90: blr             lr
    // 0xc94b94: add             SP, SP, #0x10
    // 0xc94b98: tbz             w0, #4, #0xc94bac
    // 0xc94b9c: r0 = false
    //     0xc94b9c: add             x0, NULL, #0x30  ; false
    // 0xc94ba0: LeaveFrame
    //     0xc94ba0: mov             SP, fp
    //     0xc94ba4: ldp             fp, lr, [SP], #0x10
    // 0xc94ba8: ret
    //     0xc94ba8: ret             
    // 0xc94bac: ldr             x3, [fp, #0x18]
    // 0xc94bb0: LoadField: r2 = r3->field_7
    //     0xc94bb0: ldur            w2, [x3, #7]
    // 0xc94bb4: DecompressPointer r2
    //     0xc94bb4: add             x2, x2, HEAP, lsl #32
    // 0xc94bb8: ldr             x0, [fp, #0x10]
    // 0xc94bbc: r1 = Null
    //     0xc94bbc: mov             x1, NULL
    // 0xc94bc0: cmp             w0, NULL
    // 0xc94bc4: b.eq            #0xc94c18
    // 0xc94bc8: branchIfSmi(r0, 0xc94c18)
    //     0xc94bc8: tbz             w0, #0, #0xc94c18
    // 0xc94bcc: r8 = ValueKey<X0>
    //     0xc94bcc: add             x8, PP, #0xe, lsl #12  ; [pp+0xe508] Type: ValueKey<X0>
    //     0xc94bd0: ldr             x8, [x8, #0x508]
    // 0xc94bd4: r3 = SubtypeTestCache
    //     0xc94bd4: add             x3, PP, #0xe, lsl #12  ; [pp+0xe510] SubtypeTestCache
    //     0xc94bd8: ldr             x3, [x3, #0x510]
    // 0xc94bdc: r24 = Subtype5TestCacheStub
    //     0xc94bdc: ldr             x24, [PP, #0xc78]  ; [pp+0xc78] Stub: Subtype5TestCache (0x4ae1bc)
    // 0xc94be0: LoadField: r30 = r24->field_7
    //     0xc94be0: ldur            lr, [x24, #7]
    // 0xc94be4: blr             lr
    // 0xc94be8: cmp             w7, NULL
    // 0xc94bec: b.eq            #0xc94bf8
    // 0xc94bf0: tbnz            w7, #4, #0xc94c18
    // 0xc94bf4: b               #0xc94c20
    // 0xc94bf8: r8 = ValueKey<X0>
    //     0xc94bf8: add             x8, PP, #0xe, lsl #12  ; [pp+0xe518] Type: ValueKey<X0>
    //     0xc94bfc: ldr             x8, [x8, #0x518]
    // 0xc94c00: r3 = SubtypeTestCache
    //     0xc94c00: add             x3, PP, #0xe, lsl #12  ; [pp+0xe520] SubtypeTestCache
    //     0xc94c04: ldr             x3, [x3, #0x520]
    // 0xc94c08: r24 = InstanceOfStub
    //     0xc94c08: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xc94c0c: LoadField: r30 = r24->field_7
    //     0xc94c0c: ldur            lr, [x24, #7]
    // 0xc94c10: blr             lr
    // 0xc94c14: b               #0xc94c24
    // 0xc94c18: r0 = false
    //     0xc94c18: add             x0, NULL, #0x30  ; false
    // 0xc94c1c: b               #0xc94c24
    // 0xc94c20: r0 = true
    //     0xc94c20: add             x0, NULL, #0x20  ; true
    // 0xc94c24: tbnz            w0, #4, #0xc94c68
    // 0xc94c28: ldr             x0, [fp, #0x18]
    // 0xc94c2c: ldr             x1, [fp, #0x10]
    // 0xc94c30: LoadField: r2 = r1->field_b
    //     0xc94c30: ldur            w2, [x1, #0xb]
    // 0xc94c34: DecompressPointer r2
    //     0xc94c34: add             x2, x2, HEAP, lsl #32
    // 0xc94c38: LoadField: r1 = r0->field_b
    //     0xc94c38: ldur            w1, [x0, #0xb]
    // 0xc94c3c: DecompressPointer r1
    //     0xc94c3c: add             x1, x1, HEAP, lsl #32
    // 0xc94c40: r0 = 59
    //     0xc94c40: mov             x0, #0x3b
    // 0xc94c44: branchIfSmi(r2, 0xc94c50)
    //     0xc94c44: tbz             w2, #0, #0xc94c50
    // 0xc94c48: r0 = LoadClassIdInstr(r2)
    //     0xc94c48: ldur            x0, [x2, #-1]
    //     0xc94c4c: ubfx            x0, x0, #0xc, #0x14
    // 0xc94c50: stp             x1, x2, [SP, #-0x10]!
    // 0xc94c54: mov             lr, x0
    // 0xc94c58: ldr             lr, [x21, lr, lsl #3]
    // 0xc94c5c: blr             lr
    // 0xc94c60: add             SP, SP, #0x10
    // 0xc94c64: b               #0xc94c6c
    // 0xc94c68: r0 = false
    //     0xc94c68: add             x0, NULL, #0x30  ; false
    // 0xc94c6c: LeaveFrame
    //     0xc94c6c: mov             SP, fp
    //     0xc94c70: ldp             fp, lr, [SP], #0x10
    // 0xc94c74: ret
    //     0xc94c74: ret             
    // 0xc94c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc94c78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc94c7c: b               #0xc94b18
  }
}

// class id: 2605, size: 0x8, field offset: 0x8
class UniqueKey extends LocalKey {

  _ toString(/* No info */) {
    // ** addr: 0xad8770, size: 0x94
    // 0xad8770: EnterFrame
    //     0xad8770: stp             fp, lr, [SP, #-0x10]!
    //     0xad8774: mov             fp, SP
    // 0xad8778: AllocStack(0x8)
    //     0xad8778: sub             SP, SP, #8
    // 0xad877c: CheckStackOverflow
    //     0xad877c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8780: cmp             SP, x16
    //     0xad8784: b.ls            #0xad87fc
    // 0xad8788: r1 = Null
    //     0xad8788: mov             x1, NULL
    // 0xad878c: r2 = 6
    //     0xad878c: mov             x2, #6
    // 0xad8790: r0 = AllocateArray()
    //     0xad8790: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad8794: stur            x0, [fp, #-8]
    // 0xad8798: r17 = "[#"
    //     0xad8798: ldr             x17, [PP, #0x74f8]  ; [pp+0x74f8] "[#"
    // 0xad879c: StoreField: r0->field_f = r17
    //     0xad879c: stur            w17, [x0, #0xf]
    // 0xad87a0: ldr             x16, [fp, #0x10]
    // 0xad87a4: SaveReg r16
    //     0xad87a4: str             x16, [SP, #-8]!
    // 0xad87a8: r0 = shortHash()
    //     0xad87a8: bl              #0xa77d00  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xad87ac: add             SP, SP, #8
    // 0xad87b0: ldur            x1, [fp, #-8]
    // 0xad87b4: ArrayStore: r1[1] = r0  ; List_4
    //     0xad87b4: add             x25, x1, #0x13
    //     0xad87b8: str             w0, [x25]
    //     0xad87bc: tbz             w0, #0, #0xad87d8
    //     0xad87c0: ldurb           w16, [x1, #-1]
    //     0xad87c4: ldurb           w17, [x0, #-1]
    //     0xad87c8: and             x16, x17, x16, lsr #2
    //     0xad87cc: tst             x16, HEAP, lsr #32
    //     0xad87d0: b.eq            #0xad87d8
    //     0xad87d4: bl              #0xd67e5c
    // 0xad87d8: ldur            x0, [fp, #-8]
    // 0xad87dc: r17 = "]"
    //     0xad87dc: ldr             x17, [PP, #0x1460]  ; [pp+0x1460] "]"
    // 0xad87e0: StoreField: r0->field_17 = r17
    //     0xad87e0: stur            w17, [x0, #0x17]
    // 0xad87e4: SaveReg r0
    //     0xad87e4: str             x0, [SP, #-8]!
    // 0xad87e8: r0 = _interpolate()
    //     0xad87e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad87ec: add             SP, SP, #8
    // 0xad87f0: LeaveFrame
    //     0xad87f0: mov             SP, fp
    //     0xad87f4: ldp             fp, lr, [SP], #0x10
    // 0xad87f8: ret
    //     0xad87f8: ret             
    // 0xad87fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad87fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad8800: b               #0xad8788
  }
}

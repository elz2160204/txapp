// lib: , url: package:flutter/src/foundation/binding.dart

// class id: 1049125, size: 0x8
class :: {
}

// class id: 2641, size: 0x10, field offset: 0x8
abstract class BindingBase extends Object {

  _ lockEvents(/* No info */) {
    // ** addr: 0x5b7e8c, size: 0xfc
    // 0x5b7e8c: EnterFrame
    //     0x5b7e8c: stp             fp, lr, [SP, #-0x10]!
    //     0x5b7e90: mov             fp, SP
    // 0x5b7e94: AllocStack(0x10)
    //     0x5b7e94: sub             SP, SP, #0x10
    // 0x5b7e98: CheckStackOverflow
    //     0x5b7e98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b7e9c: cmp             SP, x16
    //     0x5b7ea0: b.ls            #0x5b7f80
    // 0x5b7ea4: r1 = 2
    //     0x5b7ea4: mov             x1, #2
    // 0x5b7ea8: r0 = AllocateContext()
    //     0x5b7ea8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5b7eac: mov             x1, x0
    // 0x5b7eb0: ldr             x0, [fp, #0x18]
    // 0x5b7eb4: stur            x1, [fp, #-8]
    // 0x5b7eb8: StoreField: r1->field_f = r0
    //     0x5b7eb8: stur            w0, [x1, #0xf]
    // 0x5b7ebc: r0 = TimelineTask()
    //     0x5b7ebc: bl              #0x543c94  ; AllocateTimelineTaskStub -> TimelineTask (size=0x1c)
    // 0x5b7ec0: stur            x0, [fp, #-0x10]
    // 0x5b7ec4: SaveReg r0
    //     0x5b7ec4: str             x0, [SP, #-8]!
    // 0x5b7ec8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5b7ec8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5b7ecc: r0 = TimelineTask()
    //     0x5b7ecc: bl              #0x543aec  ; [dart:developer] TimelineTask::TimelineTask
    // 0x5b7ed0: add             SP, SP, #8
    // 0x5b7ed4: ldur            x16, [fp, #-0x10]
    // 0x5b7ed8: r30 = "Lock events"
    //     0x5b7ed8: ldr             lr, [PP, #0x37e8]  ; [pp+0x37e8] "Lock events"
    // 0x5b7edc: stp             lr, x16, [SP, #-0x10]!
    // 0x5b7ee0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5b7ee0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5b7ee4: r0 = start()
    //     0x5b7ee4: bl              #0x543660  ; [dart:developer] TimelineTask::start
    // 0x5b7ee8: add             SP, SP, #0x10
    // 0x5b7eec: ldur            x0, [fp, #-0x10]
    // 0x5b7ef0: ldur            x2, [fp, #-8]
    // 0x5b7ef4: StoreField: r2->field_13 = r0
    //     0x5b7ef4: stur            w0, [x2, #0x13]
    //     0x5b7ef8: ldurb           w16, [x2, #-1]
    //     0x5b7efc: ldurb           w17, [x0, #-1]
    //     0x5b7f00: and             x16, x17, x16, lsr #2
    //     0x5b7f04: tst             x16, HEAP, lsr #32
    //     0x5b7f08: b.eq            #0x5b7f10
    //     0x5b7f0c: bl              #0xd6828c
    // 0x5b7f10: ldr             x0, [fp, #0x18]
    // 0x5b7f14: LoadField: r1 = r0->field_7
    //     0x5b7f14: ldur            x1, [x0, #7]
    // 0x5b7f18: add             x3, x1, #1
    // 0x5b7f1c: StoreField: r0->field_7 = r3
    //     0x5b7f1c: stur            x3, [x0, #7]
    // 0x5b7f20: ldr             x16, [fp, #0x10]
    // 0x5b7f24: SaveReg r16
    //     0x5b7f24: str             x16, [SP, #-8]!
    // 0x5b7f28: ldr             x0, [fp, #0x10]
    // 0x5b7f2c: ClosureCall
    //     0x5b7f2c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x5b7f30: ldur            x2, [x0, #0x1f]
    //     0x5b7f34: blr             x2
    // 0x5b7f38: add             SP, SP, #8
    // 0x5b7f3c: ldur            x2, [fp, #-8]
    // 0x5b7f40: r1 = Function '<anonymous closure>':.
    //     0x5b7f40: ldr             x1, [PP, #0x37f0]  ; [pp+0x37f0] AnonymousClosure: (0x5b7f88), in [package:flutter/src/foundation/binding.dart] BindingBase::lockEvents (0x5b7e8c)
    // 0x5b7f44: stur            x0, [fp, #-8]
    // 0x5b7f48: r0 = AllocateClosure()
    //     0x5b7f48: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5b7f4c: ldur            x1, [fp, #-8]
    // 0x5b7f50: r2 = LoadClassIdInstr(r1)
    //     0x5b7f50: ldur            x2, [x1, #-1]
    //     0x5b7f54: ubfx            x2, x2, #0xc, #0x14
    // 0x5b7f58: stp             x0, x1, [SP, #-0x10]!
    // 0x5b7f5c: mov             x0, x2
    // 0x5b7f60: r0 = GDT[cid_x0 + -0xffc]()
    //     0x5b7f60: sub             lr, x0, #0xffc
    //     0x5b7f64: ldr             lr, [x21, lr, lsl #3]
    //     0x5b7f68: blr             lr
    // 0x5b7f6c: add             SP, SP, #0x10
    // 0x5b7f70: ldur            x0, [fp, #-8]
    // 0x5b7f74: LeaveFrame
    //     0x5b7f74: mov             SP, fp
    //     0x5b7f78: ldp             fp, lr, [SP], #0x10
    // 0x5b7f7c: ret
    //     0x5b7f7c: ret             
    // 0x5b7f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b7f80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b7f84: b               #0x5b7ea4
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x5b7f88, size: 0x8c
    // 0x5b7f88: EnterFrame
    //     0x5b7f88: stp             fp, lr, [SP, #-0x10]!
    //     0x5b7f8c: mov             fp, SP
    // 0x5b7f90: AllocStack(0x8)
    //     0x5b7f90: sub             SP, SP, #8
    // 0x5b7f94: SetupParameters()
    //     0x5b7f94: ldr             x0, [fp, #0x10]
    //     0x5b7f98: ldur            w1, [x0, #0x17]
    //     0x5b7f9c: add             x1, x1, HEAP, lsl #32
    //     0x5b7fa0: stur            x1, [fp, #-8]
    // 0x5b7fa4: CheckStackOverflow
    //     0x5b7fa4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b7fa8: cmp             SP, x16
    //     0x5b7fac: b.ls            #0x5b800c
    // 0x5b7fb0: LoadField: r0 = r1->field_f
    //     0x5b7fb0: ldur            w0, [x1, #0xf]
    // 0x5b7fb4: DecompressPointer r0
    //     0x5b7fb4: add             x0, x0, HEAP, lsl #32
    // 0x5b7fb8: LoadField: r2 = r0->field_7
    //     0x5b7fb8: ldur            x2, [x0, #7]
    // 0x5b7fbc: sub             x3, x2, #1
    // 0x5b7fc0: StoreField: r0->field_7 = r3
    //     0x5b7fc0: stur            x3, [x0, #7]
    // 0x5b7fc4: cmp             x3, #0
    // 0x5b7fc8: b.gt            #0x5b7ffc
    // 0x5b7fcc: LoadField: r0 = r1->field_13
    //     0x5b7fcc: ldur            w0, [x1, #0x13]
    // 0x5b7fd0: DecompressPointer r0
    //     0x5b7fd0: add             x0, x0, HEAP, lsl #32
    // 0x5b7fd4: SaveReg r0
    //     0x5b7fd4: str             x0, [SP, #-8]!
    // 0x5b7fd8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5b7fd8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5b7fdc: r0 = finish()
    //     0x5b7fdc: bl              #0x547d80  ; [dart:developer] TimelineTask::finish
    // 0x5b7fe0: add             SP, SP, #8
    // 0x5b7fe4: ldur            x0, [fp, #-8]
    // 0x5b7fe8: LoadField: r1 = r0->field_f
    //     0x5b7fe8: ldur            w1, [x0, #0xf]
    // 0x5b7fec: DecompressPointer r1
    //     0x5b7fec: add             x1, x1, HEAP, lsl #32
    // 0x5b7ff0: SaveReg r1
    //     0x5b7ff0: str             x1, [SP, #-8]!
    // 0x5b7ff4: r0 = unlocked()
    //     0x5b7ff4: bl              #0x5b8014  ; [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding::unlocked
    // 0x5b7ff8: add             SP, SP, #8
    // 0x5b7ffc: r0 = Null
    //     0x5b7ffc: mov             x0, NULL
    // 0x5b8000: LeaveFrame
    //     0x5b8000: mov             SP, fp
    //     0x5b8004: ldp             fp, lr, [SP], #0x10
    // 0x5b8008: ret
    //     0x5b8008: ret             
    // 0x5b800c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b800c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b8010: b               #0x5b7fb0
  }
  _ BindingBase(/* No info */) {
    // ** addr: 0x5b93b0, size: 0x84
    // 0x5b93b0: EnterFrame
    //     0x5b93b0: stp             fp, lr, [SP, #-0x10]!
    //     0x5b93b4: mov             fp, SP
    // 0x5b93b8: r0 = 0
    //     0x5b93b8: mov             x0, #0
    // 0x5b93bc: CheckStackOverflow
    //     0x5b93bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b93c0: cmp             SP, x16
    //     0x5b93c4: b.ls            #0x5b942c
    // 0x5b93c8: ldr             x1, [fp, #0x10]
    // 0x5b93cc: StoreField: r1->field_7 = r0
    //     0x5b93cc: stur            x0, [x1, #7]
    // 0x5b93d0: r16 = "Framework initialization"
    //     0x5b93d0: ldr             x16, [PP, #0x4250]  ; [pp+0x4250] "Framework initialization"
    // 0x5b93d4: SaveReg r16
    //     0x5b93d4: str             x16, [SP, #-8]!
    // 0x5b93d8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5b93d8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5b93dc: r0 = startSync()
    //     0x5b93dc: bl              #0x55da8c  ; [dart:developer] Timeline::startSync
    // 0x5b93e0: add             SP, SP, #8
    // 0x5b93e4: ldr             x16, [fp, #0x10]
    // 0x5b93e8: SaveReg r16
    //     0x5b93e8: str             x16, [SP, #-8]!
    // 0x5b93ec: r0 = initInstances()
    //     0x5b93ec: bl              #0x5b9434  ; [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::initInstances
    // 0x5b93f0: add             SP, SP, #8
    // 0x5b93f4: r16 = <String, String>
    //     0x5b93f4: ldr             x16, [PP, #0x278]  ; [pp+0x278] TypeArguments: <String, String>
    // 0x5b93f8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5b93fc: stp             lr, x16, [SP, #-0x10]!
    // 0x5b9400: r0 = Map._fromLiteral()
    //     0x5b9400: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5b9404: add             SP, SP, #0x10
    // 0x5b9408: r16 = "Flutter.FrameworkInitialization"
    //     0x5b9408: ldr             x16, [PP, #0x4258]  ; [pp+0x4258] "Flutter.FrameworkInitialization"
    // 0x5b940c: stp             x0, x16, [SP, #-0x10]!
    // 0x5b9410: r0 = Shader._()
    //     0x5b9410: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x5b9414: add             SP, SP, #0x10
    // 0x5b9418: r0 = finishSync()
    //     0x5b9418: bl              #0x55d838  ; [dart:developer] Timeline::finishSync
    // 0x5b941c: r0 = Null
    //     0x5b941c: mov             x0, NULL
    // 0x5b9420: LeaveFrame
    //     0x5b9420: mov             SP, fp
    //     0x5b9424: ldp             fp, lr, [SP], #0x10
    // 0x5b9428: ret
    //     0x5b9428: ret             
    // 0x5b942c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b942c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b9430: b               #0x5b93c8
  }
  _ toString(/* No info */) {
    // ** addr: 0xad7850, size: 0x8
    // 0xad7850: r0 = "<BindingBase>"
    //     0xad7850: ldr             x0, [PP, #0x7508]  ; [pp+0x7508] "<BindingBase>"
    // 0xad7854: ret
    //     0xad7854: ret             
  }
}

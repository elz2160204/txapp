// lib: , url: package:flutter/src/foundation/observer_list.dart

// class id: 1049140, size: 0x8
class :: {
}

// class id: 6077, size: 0x10, field offset: 0xc
class HashedObserverList<X0> extends Iterable<X0> {

  bool isEmpty(HashedObserverList<X0>) {
    // ** addr: 0xc21344, size: 0x68
    // 0xc21344: EnterFrame
    //     0xc21344: stp             fp, lr, [SP, #-0x10]!
    //     0xc21348: mov             fp, SP
    // 0xc2134c: ldr             x1, [fp, #0x10]
    // 0xc21350: LoadField: r2 = r1->field_b
    //     0xc21350: ldur            w2, [x1, #0xb]
    // 0xc21354: DecompressPointer r2
    //     0xc21354: add             x2, x2, HEAP, lsl #32
    // 0xc21358: LoadField: r1 = r2->field_13
    //     0xc21358: ldur            w1, [x2, #0x13]
    // 0xc2135c: DecompressPointer r1
    //     0xc2135c: add             x1, x1, HEAP, lsl #32
    // 0xc21360: r3 = LoadInt32Instr(r1)
    //     0xc21360: sbfx            x3, x1, #1, #0x1f
    // 0xc21364: asr             x1, x3, #1
    // 0xc21368: LoadField: r3 = r2->field_17
    //     0xc21368: ldur            w3, [x2, #0x17]
    // 0xc2136c: DecompressPointer r3
    //     0xc2136c: add             x3, x3, HEAP, lsl #32
    // 0xc21370: r2 = LoadInt32Instr(r3)
    //     0xc21370: sbfx            x2, x3, #1, #0x1f
    // 0xc21374: sub             x3, x1, x2
    // 0xc21378: cbz             x3, #0xc21384
    // 0xc2137c: r0 = false
    //     0xc2137c: add             x0, NULL, #0x30  ; false
    // 0xc21380: b               #0xc21388
    // 0xc21384: r0 = true
    //     0xc21384: add             x0, NULL, #0x20  ; true
    // 0xc21388: LeaveFrame
    //     0xc21388: mov             SP, fp
    //     0xc2138c: ldp             fp, lr, [SP], #0x10
    // 0xc21390: ret
    //     0xc21390: ret             
  }
  bool isNotEmpty(HashedObserverList<X0>) {
    // ** addr: 0xc03518, size: 0x68
    // 0xc03518: EnterFrame
    //     0xc03518: stp             fp, lr, [SP, #-0x10]!
    //     0xc0351c: mov             fp, SP
    // 0xc03520: ldr             x1, [fp, #0x10]
    // 0xc03524: LoadField: r2 = r1->field_b
    //     0xc03524: ldur            w2, [x1, #0xb]
    // 0xc03528: DecompressPointer r2
    //     0xc03528: add             x2, x2, HEAP, lsl #32
    // 0xc0352c: LoadField: r1 = r2->field_13
    //     0xc0352c: ldur            w1, [x2, #0x13]
    // 0xc03530: DecompressPointer r1
    //     0xc03530: add             x1, x1, HEAP, lsl #32
    // 0xc03534: r3 = LoadInt32Instr(r1)
    //     0xc03534: sbfx            x3, x1, #1, #0x1f
    // 0xc03538: asr             x1, x3, #1
    // 0xc0353c: LoadField: r3 = r2->field_17
    //     0xc0353c: ldur            w3, [x2, #0x17]
    // 0xc03540: DecompressPointer r3
    //     0xc03540: add             x3, x3, HEAP, lsl #32
    // 0xc03544: r2 = LoadInt32Instr(r3)
    //     0xc03544: sbfx            x2, x3, #1, #0x1f
    // 0xc03548: sub             x3, x1, x2
    // 0xc0354c: cbnz            x3, #0xc03558
    // 0xc03550: r0 = false
    //     0xc03550: add             x0, NULL, #0x30  ; false
    // 0xc03554: b               #0xc0355c
    // 0xc03558: r0 = true
    //     0xc03558: add             x0, NULL, #0x20  ; true
    // 0xc0355c: LeaveFrame
    //     0xc0355c: mov             SP, fp
    //     0xc03560: ldp             fp, lr, [SP], #0x10
    // 0xc03564: ret
    //     0xc03564: ret             
  }
  _ HashedObserverList(/* No info */) {
    // ** addr: 0x5badc0, size: 0xe0
    // 0x5badc0: EnterFrame
    //     0x5badc0: stp             fp, lr, [SP, #-0x10]!
    //     0x5badc4: mov             fp, SP
    // 0x5badc8: AllocStack(0x10)
    //     0x5badc8: sub             SP, SP, #0x10
    // 0x5badcc: CheckStackOverflow
    //     0x5badcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5badd0: cmp             SP, x16
    //     0x5badd4: b.ls            #0x5bae98
    // 0x5badd8: ldr             x0, [fp, #0x10]
    // 0x5baddc: LoadField: r2 = r0->field_7
    //     0x5baddc: ldur            w2, [x0, #7]
    // 0x5bade0: DecompressPointer r2
    //     0x5bade0: add             x2, x2, HEAP, lsl #32
    // 0x5bade4: r1 = Null
    //     0x5bade4: mov             x1, NULL
    // 0x5bade8: r3 = <X0, int>
    //     0x5bade8: ldr             x3, [PP, #0x44c8]  ; [pp+0x44c8] TypeArguments: <X0, int>
    // 0x5badec: r24 = InstantiateTypeArgumentsStub
    //     0x5badec: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x5badf0: LoadField: r30 = r24->field_7
    //     0x5badf0: ldur            lr, [x24, #7]
    // 0x5badf4: blr             lr
    // 0x5badf8: stur            x0, [fp, #-8]
    // 0x5badfc: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x5badfc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5bae00: ldr             x0, [x0, #0x598]
    //     0x5bae04: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5bae08: cmp             w0, w16
    //     0x5bae0c: b.ne            #0x5bae18
    //     0x5bae10: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x5bae14: bl              #0xd67cdc
    // 0x5bae18: ldur            x1, [fp, #-8]
    // 0x5bae1c: stur            x0, [fp, #-8]
    // 0x5bae20: r0 = _Map()
    //     0x5bae20: bl              #0x4b4914  ; Allocate_MapStub -> _Map<X0, X1> (size=-0x8)
    // 0x5bae24: mov             x1, x0
    // 0x5bae28: ldur            x0, [fp, #-8]
    // 0x5bae2c: stur            x1, [fp, #-0x10]
    // 0x5bae30: StoreField: r1->field_1b = r0
    //     0x5bae30: stur            w0, [x1, #0x1b]
    // 0x5bae34: StoreField: r1->field_b = rZR
    //     0x5bae34: stur            wzr, [x1, #0xb]
    // 0x5bae38: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x5bae38: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5bae3c: ldr             x0, [x0, #0x5a0]
    //     0x5bae40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5bae44: cmp             w0, w16
    //     0x5bae48: b.ne            #0x5bae54
    //     0x5bae4c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x5bae50: bl              #0xd67cdc
    // 0x5bae54: mov             x1, x0
    // 0x5bae58: ldur            x0, [fp, #-0x10]
    // 0x5bae5c: StoreField: r0->field_f = r1
    //     0x5bae5c: stur            w1, [x0, #0xf]
    // 0x5bae60: StoreField: r0->field_13 = rZR
    //     0x5bae60: stur            wzr, [x0, #0x13]
    // 0x5bae64: StoreField: r0->field_17 = rZR
    //     0x5bae64: stur            wzr, [x0, #0x17]
    // 0x5bae68: ldr             x1, [fp, #0x10]
    // 0x5bae6c: StoreField: r1->field_b = r0
    //     0x5bae6c: stur            w0, [x1, #0xb]
    //     0x5bae70: ldurb           w16, [x1, #-1]
    //     0x5bae74: ldurb           w17, [x0, #-1]
    //     0x5bae78: and             x16, x17, x16, lsr #2
    //     0x5bae7c: tst             x16, HEAP, lsr #32
    //     0x5bae80: b.eq            #0x5bae88
    //     0x5bae84: bl              #0xd6826c
    // 0x5bae88: r0 = Null
    //     0x5bae88: mov             x0, NULL
    // 0x5bae8c: LeaveFrame
    //     0x5bae8c: mov             SP, fp
    //     0x5bae90: ldp             fp, lr, [SP], #0x10
    // 0x5bae94: ret
    //     0x5bae94: ret             
    // 0x5bae98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bae98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bae9c: b               #0x5badd8
  }
  dynamic contains(dynamic) {
    // ** addr: 0x6a55bc, size: 0x18
    // 0x6a55bc: r4 = 7
    //     0x6a55bc: mov             x4, #7
    // 0x6a55c0: r1 = Function 'contains':.
    //     0x6a55c0: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4ba30] AnonymousClosure: (0x6a55d4), in [package:flutter/src/foundation/observer_list.dart] HashedObserverList::contains (0x6ba130)
    //     0x6a55c4: ldr             x1, [x17, #0xa30]
    // 0x6a55c8: r24 = BuildNonGenericMethodExtractorStub
    //     0x6a55c8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6a55cc: LoadField: r0 = r24->field_17
    //     0x6a55cc: ldur            x0, [x24, #0x17]
    // 0x6a55d0: br              x0
  }
  [closure] bool contains(dynamic, Object?) {
    // ** addr: 0x6a55d4, size: 0x4c
    // 0x6a55d4: EnterFrame
    //     0x6a55d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6a55d8: mov             fp, SP
    // 0x6a55dc: ldr             x0, [fp, #0x18]
    // 0x6a55e0: LoadField: r1 = r0->field_17
    //     0x6a55e0: ldur            w1, [x0, #0x17]
    // 0x6a55e4: DecompressPointer r1
    //     0x6a55e4: add             x1, x1, HEAP, lsl #32
    // 0x6a55e8: CheckStackOverflow
    //     0x6a55e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a55ec: cmp             SP, x16
    //     0x6a55f0: b.ls            #0x6a5618
    // 0x6a55f4: LoadField: r0 = r1->field_f
    //     0x6a55f4: ldur            w0, [x1, #0xf]
    // 0x6a55f8: DecompressPointer r0
    //     0x6a55f8: add             x0, x0, HEAP, lsl #32
    // 0x6a55fc: ldr             x16, [fp, #0x10]
    // 0x6a5600: stp             x16, x0, [SP, #-0x10]!
    // 0x6a5604: r0 = contains()
    //     0x6a5604: bl              #0x6ba130  ; [package:flutter/src/foundation/observer_list.dart] HashedObserverList::contains
    // 0x6a5608: add             SP, SP, #0x10
    // 0x6a560c: LeaveFrame
    //     0x6a560c: mov             SP, fp
    //     0x6a5610: ldp             fp, lr, [SP], #0x10
    // 0x6a5614: ret
    //     0x6a5614: ret             
    // 0x6a5618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a5618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a561c: b               #0x6a55f4
  }
  _ contains(/* No info */) {
    // ** addr: 0x6ba130, size: 0x44
    // 0x6ba130: EnterFrame
    //     0x6ba130: stp             fp, lr, [SP, #-0x10]!
    //     0x6ba134: mov             fp, SP
    // 0x6ba138: CheckStackOverflow
    //     0x6ba138: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ba13c: cmp             SP, x16
    //     0x6ba140: b.ls            #0x6ba16c
    // 0x6ba144: ldr             x0, [fp, #0x18]
    // 0x6ba148: LoadField: r1 = r0->field_b
    //     0x6ba148: ldur            w1, [x0, #0xb]
    // 0x6ba14c: DecompressPointer r1
    //     0x6ba14c: add             x1, x1, HEAP, lsl #32
    // 0x6ba150: ldr             x16, [fp, #0x10]
    // 0x6ba154: stp             x16, x1, [SP, #-0x10]!
    // 0x6ba158: r0 = containsKey()
    //     0x6ba158: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6ba15c: add             SP, SP, #0x10
    // 0x6ba160: LeaveFrame
    //     0x6ba160: mov             SP, fp
    //     0x6ba164: ldp             fp, lr, [SP], #0x10
    // 0x6ba168: ret
    //     0x6ba168: ret             
    // 0x6ba16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ba16c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ba170: b               #0x6ba144
  }
  get _ iterator(/* No info */) {
    // ** addr: 0x6fce6c, size: 0x4c
    // 0x6fce6c: EnterFrame
    //     0x6fce6c: stp             fp, lr, [SP, #-0x10]!
    //     0x6fce70: mov             fp, SP
    // 0x6fce74: CheckStackOverflow
    //     0x6fce74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6fce78: cmp             SP, x16
    //     0x6fce7c: b.ls            #0x6fceb0
    // 0x6fce80: ldr             x0, [fp, #0x10]
    // 0x6fce84: LoadField: r1 = r0->field_b
    //     0x6fce84: ldur            w1, [x0, #0xb]
    // 0x6fce88: DecompressPointer r1
    //     0x6fce88: add             x1, x1, HEAP, lsl #32
    // 0x6fce8c: SaveReg r1
    //     0x6fce8c: str             x1, [SP, #-8]!
    // 0x6fce90: r0 = keys()
    //     0x6fce90: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x6fce94: add             SP, SP, #8
    // 0x6fce98: SaveReg r0
    //     0x6fce98: str             x0, [SP, #-8]!
    // 0x6fce9c: r0 = iterator()
    //     0x6fce9c: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x6fcea0: add             SP, SP, #8
    // 0x6fcea4: LeaveFrame
    //     0x6fcea4: mov             SP, fp
    //     0x6fcea8: ldp             fp, lr, [SP], #0x10
    // 0x6fceac: ret
    //     0x6fceac: ret             
    // 0x6fceb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6fceb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6fceb4: b               #0x6fce80
  }
  _ add(/* No info */) {
    // ** addr: 0x9da0a8, size: 0xec
    // 0x9da0a8: EnterFrame
    //     0x9da0a8: stp             fp, lr, [SP, #-0x10]!
    //     0x9da0ac: mov             fp, SP
    // 0x9da0b0: AllocStack(0x8)
    //     0x9da0b0: sub             SP, SP, #8
    // 0x9da0b4: CheckStackOverflow
    //     0x9da0b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9da0b8: cmp             SP, x16
    //     0x9da0bc: b.ls            #0x9da18c
    // 0x9da0c0: ldr             x3, [fp, #0x18]
    // 0x9da0c4: LoadField: r2 = r3->field_7
    //     0x9da0c4: ldur            w2, [x3, #7]
    // 0x9da0c8: DecompressPointer r2
    //     0x9da0c8: add             x2, x2, HEAP, lsl #32
    // 0x9da0cc: ldr             x0, [fp, #0x10]
    // 0x9da0d0: r1 = Null
    //     0x9da0d0: mov             x1, NULL
    // 0x9da0d4: cmp             w2, NULL
    // 0x9da0d8: b.eq            #0x9da0f8
    // 0x9da0dc: LoadField: r4 = r2->field_17
    //     0x9da0dc: ldur            w4, [x2, #0x17]
    // 0x9da0e0: DecompressPointer r4
    //     0x9da0e0: add             x4, x4, HEAP, lsl #32
    // 0x9da0e4: r8 = X0
    //     0x9da0e4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x9da0e8: LoadField: r9 = r4->field_7
    //     0x9da0e8: ldur            x9, [x4, #7]
    // 0x9da0ec: r3 = Null
    //     0x9da0ec: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e520] Null
    //     0x9da0f0: ldr             x3, [x3, #0x520]
    // 0x9da0f4: blr             x9
    // 0x9da0f8: ldr             x0, [fp, #0x18]
    // 0x9da0fc: LoadField: r1 = r0->field_b
    //     0x9da0fc: ldur            w1, [x0, #0xb]
    // 0x9da100: DecompressPointer r1
    //     0x9da100: add             x1, x1, HEAP, lsl #32
    // 0x9da104: stur            x1, [fp, #-8]
    // 0x9da108: ldr             x16, [fp, #0x10]
    // 0x9da10c: stp             x16, x1, [SP, #-0x10]!
    // 0x9da110: r0 = _getValueOrData()
    //     0x9da110: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9da114: add             SP, SP, #0x10
    // 0x9da118: ldur            x2, [fp, #-8]
    // 0x9da11c: LoadField: r1 = r2->field_f
    //     0x9da11c: ldur            w1, [x2, #0xf]
    // 0x9da120: DecompressPointer r1
    //     0x9da120: add             x1, x1, HEAP, lsl #32
    // 0x9da124: cmp             w1, w0
    // 0x9da128: b.ne            #0x9da130
    // 0x9da12c: r0 = Null
    //     0x9da12c: mov             x0, NULL
    // 0x9da130: cmp             w0, NULL
    // 0x9da134: b.ne            #0x9da140
    // 0x9da138: r0 = 0
    //     0x9da138: mov             x0, #0
    // 0x9da13c: b               #0x9da150
    // 0x9da140: r1 = LoadInt32Instr(r0)
    //     0x9da140: sbfx            x1, x0, #1, #0x1f
    //     0x9da144: tbz             w0, #0, #0x9da14c
    //     0x9da148: ldur            x1, [x0, #7]
    // 0x9da14c: mov             x0, x1
    // 0x9da150: add             x3, x0, #1
    // 0x9da154: r0 = BoxInt64Instr(r3)
    //     0x9da154: sbfiz           x0, x3, #1, #0x1f
    //     0x9da158: cmp             x3, x0, asr #1
    //     0x9da15c: b.eq            #0x9da168
    //     0x9da160: bl              #0xd69bb8
    //     0x9da164: stur            x3, [x0, #7]
    // 0x9da168: ldr             x16, [fp, #0x10]
    // 0x9da16c: stp             x16, x2, [SP, #-0x10]!
    // 0x9da170: SaveReg r0
    //     0x9da170: str             x0, [SP, #-8]!
    // 0x9da174: r0 = []=()
    //     0x9da174: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x9da178: add             SP, SP, #0x18
    // 0x9da17c: r0 = Null
    //     0x9da17c: mov             x0, NULL
    // 0x9da180: LeaveFrame
    //     0x9da180: mov             SP, fp
    //     0x9da184: ldp             fp, lr, [SP], #0x10
    // 0x9da188: ret
    //     0x9da188: ret             
    // 0x9da18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9da18c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9da190: b               #0x9da0c0
  }
  _ remove(/* No info */) {
    // ** addr: 0xa51878, size: 0x10c
    // 0xa51878: EnterFrame
    //     0xa51878: stp             fp, lr, [SP, #-0x10]!
    //     0xa5187c: mov             fp, SP
    // 0xa51880: AllocStack(0x8)
    //     0xa51880: sub             SP, SP, #8
    // 0xa51884: CheckStackOverflow
    //     0xa51884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51888: cmp             SP, x16
    //     0xa5188c: b.ls            #0xa5197c
    // 0xa51890: ldr             x3, [fp, #0x18]
    // 0xa51894: LoadField: r2 = r3->field_7
    //     0xa51894: ldur            w2, [x3, #7]
    // 0xa51898: DecompressPointer r2
    //     0xa51898: add             x2, x2, HEAP, lsl #32
    // 0xa5189c: ldr             x0, [fp, #0x10]
    // 0xa518a0: r1 = Null
    //     0xa518a0: mov             x1, NULL
    // 0xa518a4: cmp             w2, NULL
    // 0xa518a8: b.eq            #0xa518c8
    // 0xa518ac: LoadField: r4 = r2->field_17
    //     0xa518ac: ldur            w4, [x2, #0x17]
    // 0xa518b0: DecompressPointer r4
    //     0xa518b0: add             x4, x4, HEAP, lsl #32
    // 0xa518b4: r8 = X0
    //     0xa518b4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa518b8: LoadField: r9 = r4->field_7
    //     0xa518b8: ldur            x9, [x4, #7]
    // 0xa518bc: r3 = Null
    //     0xa518bc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e4d8] Null
    //     0xa518c0: ldr             x3, [x3, #0x4d8]
    // 0xa518c4: blr             x9
    // 0xa518c8: ldr             x0, [fp, #0x18]
    // 0xa518cc: LoadField: r1 = r0->field_b
    //     0xa518cc: ldur            w1, [x0, #0xb]
    // 0xa518d0: DecompressPointer r1
    //     0xa518d0: add             x1, x1, HEAP, lsl #32
    // 0xa518d4: stur            x1, [fp, #-8]
    // 0xa518d8: ldr             x16, [fp, #0x10]
    // 0xa518dc: stp             x16, x1, [SP, #-0x10]!
    // 0xa518e0: r0 = _getValueOrData()
    //     0xa518e0: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa518e4: add             SP, SP, #0x10
    // 0xa518e8: ldur            x2, [fp, #-8]
    // 0xa518ec: LoadField: r1 = r2->field_f
    //     0xa518ec: ldur            w1, [x2, #0xf]
    // 0xa518f0: DecompressPointer r1
    //     0xa518f0: add             x1, x1, HEAP, lsl #32
    // 0xa518f4: cmp             w1, w0
    // 0xa518f8: b.ne            #0xa51900
    // 0xa518fc: r0 = Null
    //     0xa518fc: mov             x0, NULL
    // 0xa51900: cmp             w0, NULL
    // 0xa51904: b.ne            #0xa51918
    // 0xa51908: r0 = false
    //     0xa51908: add             x0, NULL, #0x30  ; false
    // 0xa5190c: LeaveFrame
    //     0xa5190c: mov             SP, fp
    //     0xa51910: ldp             fp, lr, [SP], #0x10
    // 0xa51914: ret
    //     0xa51914: ret             
    // 0xa51918: cmp             w0, #2
    // 0xa5191c: b.ne            #0xa51934
    // 0xa51920: ldr             x16, [fp, #0x10]
    // 0xa51924: stp             x16, x2, [SP, #-0x10]!
    // 0xa51928: r0 = remove()
    //     0xa51928: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xa5192c: add             SP, SP, #0x10
    // 0xa51930: b               #0xa5196c
    // 0xa51934: r1 = LoadInt32Instr(r0)
    //     0xa51934: sbfx            x1, x0, #1, #0x1f
    //     0xa51938: tbz             w0, #0, #0xa51940
    //     0xa5193c: ldur            x1, [x0, #7]
    // 0xa51940: sub             x3, x1, #1
    // 0xa51944: r0 = BoxInt64Instr(r3)
    //     0xa51944: sbfiz           x0, x3, #1, #0x1f
    //     0xa51948: cmp             x3, x0, asr #1
    //     0xa5194c: b.eq            #0xa51958
    //     0xa51950: bl              #0xd69bb8
    //     0xa51954: stur            x3, [x0, #7]
    // 0xa51958: ldr             x16, [fp, #0x10]
    // 0xa5195c: stp             x16, x2, [SP, #-0x10]!
    // 0xa51960: SaveReg r0
    //     0xa51960: str             x0, [SP, #-8]!
    // 0xa51964: r0 = []=()
    //     0xa51964: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xa51968: add             SP, SP, #0x18
    // 0xa5196c: r0 = true
    //     0xa5196c: add             x0, NULL, #0x20  ; true
    // 0xa51970: LeaveFrame
    //     0xa51970: mov             SP, fp
    //     0xa51974: ldp             fp, lr, [SP], #0x10
    // 0xa51978: ret
    //     0xa51978: ret             
    // 0xa5197c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5197c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa51980: b               #0xa51890
  }
}

// class id: 6078, size: 0x18, field offset: 0xc
class ObserverList<X0> extends Iterable<X0> {

  late final HashSet<X0> _set; // offset: 0x14

  bool isEmpty(ObserverList<X0>) {
    // ** addr: 0x6bc248, size: 0x40
    // 0x6bc248: ldr             x1, [SP]
    // 0x6bc24c: LoadField: r2 = r1->field_b
    //     0x6bc24c: ldur            w2, [x1, #0xb]
    // 0x6bc250: DecompressPointer r2
    //     0x6bc250: add             x2, x2, HEAP, lsl #32
    // 0x6bc254: LoadField: r1 = r2->field_b
    //     0x6bc254: ldur            w1, [x2, #0xb]
    // 0x6bc258: DecompressPointer r1
    //     0x6bc258: add             x1, x1, HEAP, lsl #32
    // 0x6bc25c: cbz             w1, #0x6bc268
    // 0x6bc260: r0 = false
    //     0x6bc260: add             x0, NULL, #0x30  ; false
    // 0x6bc264: b               #0x6bc26c
    // 0x6bc268: r0 = true
    //     0x6bc268: add             x0, NULL, #0x20  ; true
    // 0x6bc26c: ret
    //     0x6bc26c: ret             
  }
  bool isNotEmpty(ObserverList<X0>) {
    // ** addr: 0x6bc968, size: 0x40
    // 0x6bc968: ldr             x1, [SP]
    // 0x6bc96c: LoadField: r2 = r1->field_b
    //     0x6bc96c: ldur            w2, [x1, #0xb]
    // 0x6bc970: DecompressPointer r2
    //     0x6bc970: add             x2, x2, HEAP, lsl #32
    // 0x6bc974: LoadField: r1 = r2->field_b
    //     0x6bc974: ldur            w1, [x2, #0xb]
    // 0x6bc978: DecompressPointer r1
    //     0x6bc978: add             x1, x1, HEAP, lsl #32
    // 0x6bc97c: cbnz            w1, #0x6bc988
    // 0x6bc980: r0 = false
    //     0x6bc980: add             x0, NULL, #0x30  ; false
    // 0x6bc984: b               #0x6bc98c
    // 0x6bc988: r0 = true
    //     0x6bc988: add             x0, NULL, #0x20  ; true
    // 0x6bc98c: ret
    //     0x6bc98c: ret             
  }
  dynamic contains(dynamic) {
    // ** addr: 0x6a5558, size: 0x18
    // 0x6a5558: r4 = 7
    //     0x6a5558: mov             x4, #7
    // 0x6a555c: r1 = Function 'contains':.
    //     0x6a555c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4ba38] AnonymousClosure: (0x6a5570), in [package:flutter/src/foundation/observer_list.dart] ObserverList::contains (0x6b9fe4)
    //     0x6a5560: ldr             x1, [x17, #0xa38]
    // 0x6a5564: r24 = BuildNonGenericMethodExtractorStub
    //     0x6a5564: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6a5568: LoadField: r0 = r24->field_17
    //     0x6a5568: ldur            x0, [x24, #0x17]
    // 0x6a556c: br              x0
  }
  [closure] bool contains(dynamic, Object?) {
    // ** addr: 0x6a5570, size: 0x4c
    // 0x6a5570: EnterFrame
    //     0x6a5570: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5574: mov             fp, SP
    // 0x6a5578: ldr             x0, [fp, #0x18]
    // 0x6a557c: LoadField: r1 = r0->field_17
    //     0x6a557c: ldur            w1, [x0, #0x17]
    // 0x6a5580: DecompressPointer r1
    //     0x6a5580: add             x1, x1, HEAP, lsl #32
    // 0x6a5584: CheckStackOverflow
    //     0x6a5584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a5588: cmp             SP, x16
    //     0x6a558c: b.ls            #0x6a55b4
    // 0x6a5590: LoadField: r0 = r1->field_f
    //     0x6a5590: ldur            w0, [x1, #0xf]
    // 0x6a5594: DecompressPointer r0
    //     0x6a5594: add             x0, x0, HEAP, lsl #32
    // 0x6a5598: ldr             x16, [fp, #0x10]
    // 0x6a559c: stp             x16, x0, [SP, #-0x10]!
    // 0x6a55a0: r0 = contains()
    //     0x6a55a0: bl              #0x6b9fe4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0x6a55a4: add             SP, SP, #0x10
    // 0x6a55a8: LeaveFrame
    //     0x6a55a8: mov             SP, fp
    //     0x6a55ac: ldp             fp, lr, [SP], #0x10
    // 0x6a55b0: ret
    //     0x6a55b0: ret             
    // 0x6a55b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a55b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a55b8: b               #0x6a5590
  }
  _ contains(/* No info */) {
    // ** addr: 0x6b9fe4, size: 0x108
    // 0x6b9fe4: EnterFrame
    //     0x6b9fe4: stp             fp, lr, [SP, #-0x10]!
    //     0x6b9fe8: mov             fp, SP
    // 0x6b9fec: AllocStack(0x8)
    //     0x6b9fec: sub             SP, SP, #8
    // 0x6b9ff0: CheckStackOverflow
    //     0x6b9ff0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b9ff4: cmp             SP, x16
    //     0x6b9ff8: b.ls            #0x6ba0e4
    // 0x6b9ffc: ldr             x0, [fp, #0x18]
    // 0x6ba000: LoadField: r2 = r0->field_b
    //     0x6ba000: ldur            w2, [x0, #0xb]
    // 0x6ba004: DecompressPointer r2
    //     0x6ba004: add             x2, x2, HEAP, lsl #32
    // 0x6ba008: stur            x2, [fp, #-8]
    // 0x6ba00c: LoadField: r1 = r2->field_b
    //     0x6ba00c: ldur            w1, [x2, #0xb]
    // 0x6ba010: DecompressPointer r1
    //     0x6ba010: add             x1, x1, HEAP, lsl #32
    // 0x6ba014: r3 = LoadInt32Instr(r1)
    //     0x6ba014: sbfx            x3, x1, #1, #0x1f
    // 0x6ba018: cmp             x3, #3
    // 0x6ba01c: b.ge            #0x6ba03c
    // 0x6ba020: ldr             x16, [fp, #0x10]
    // 0x6ba024: stp             x16, x2, [SP, #-0x10]!
    // 0x6ba028: r0 = contains()
    //     0x6ba028: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0x6ba02c: add             SP, SP, #0x10
    // 0x6ba030: LeaveFrame
    //     0x6ba030: mov             SP, fp
    //     0x6ba034: ldp             fp, lr, [SP], #0x10
    // 0x6ba038: ret
    //     0x6ba038: ret             
    // 0x6ba03c: LoadField: r1 = r0->field_f
    //     0x6ba03c: ldur            w1, [x0, #0xf]
    // 0x6ba040: DecompressPointer r1
    //     0x6ba040: add             x1, x1, HEAP, lsl #32
    // 0x6ba044: tbnz            w1, #4, #0x6ba08c
    // 0x6ba048: mov             x1, x0
    // 0x6ba04c: LoadField: r0 = r1->field_13
    //     0x6ba04c: ldur            w0, [x1, #0x13]
    // 0x6ba050: DecompressPointer r0
    //     0x6ba050: add             x0, x0, HEAP, lsl #32
    // 0x6ba054: r16 = Sentinel
    //     0x6ba054: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ba058: cmp             w0, w16
    // 0x6ba05c: b.ne            #0x6ba06c
    // 0x6ba060: r2 = _set
    //     0x6ba060: add             x2, PP, #0xd, lsl #12  ; [pp+0xdbf8] Field <ObserverList._set@643023516>: late final (offset: 0x14)
    //     0x6ba064: ldr             x2, [x2, #0xbf8]
    // 0x6ba068: r0 = InitLateFinalInstanceField()
    //     0x6ba068: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6ba06c: ldur            x16, [fp, #-8]
    // 0x6ba070: stp             x16, x0, [SP, #-0x10]!
    // 0x6ba074: r0 = addAll()
    //     0x6ba074: bl              #0xbd9b94  ; [dart:collection] _HashSet::addAll
    // 0x6ba078: add             SP, SP, #0x10
    // 0x6ba07c: ldr             x1, [fp, #0x18]
    // 0x6ba080: r0 = false
    //     0x6ba080: add             x0, NULL, #0x30  ; false
    // 0x6ba084: StoreField: r1->field_f = r0
    //     0x6ba084: stur            w0, [x1, #0xf]
    // 0x6ba088: b               #0x6ba090
    // 0x6ba08c: mov             x1, x0
    // 0x6ba090: LoadField: r0 = r1->field_13
    //     0x6ba090: ldur            w0, [x1, #0x13]
    // 0x6ba094: DecompressPointer r0
    //     0x6ba094: add             x0, x0, HEAP, lsl #32
    // 0x6ba098: r16 = Sentinel
    //     0x6ba098: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ba09c: cmp             w0, w16
    // 0x6ba0a0: b.ne            #0x6ba0b0
    // 0x6ba0a4: r2 = _set
    //     0x6ba0a4: add             x2, PP, #0xd, lsl #12  ; [pp+0xdbf8] Field <ObserverList._set@643023516>: late final (offset: 0x14)
    //     0x6ba0a8: ldr             x2, [x2, #0xbf8]
    // 0x6ba0ac: r0 = InitLateFinalInstanceField()
    //     0x6ba0ac: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6ba0b0: r1 = LoadClassIdInstr(r0)
    //     0x6ba0b0: ldur            x1, [x0, #-1]
    //     0x6ba0b4: ubfx            x1, x1, #0xc, #0x14
    // 0x6ba0b8: ldr             x16, [fp, #0x10]
    // 0x6ba0bc: stp             x16, x0, [SP, #-0x10]!
    // 0x6ba0c0: mov             x0, x1
    // 0x6ba0c4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x6ba0c4: mov             x17, #0xc98a
    //     0x6ba0c8: add             lr, x0, x17
    //     0x6ba0cc: ldr             lr, [x21, lr, lsl #3]
    //     0x6ba0d0: blr             lr
    // 0x6ba0d4: add             SP, SP, #0x10
    // 0x6ba0d8: LeaveFrame
    //     0x6ba0d8: mov             SP, fp
    //     0x6ba0dc: ldp             fp, lr, [SP], #0x10
    // 0x6ba0e0: ret
    //     0x6ba0e0: ret             
    // 0x6ba0e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ba0e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ba0e8: b               #0x6b9ffc
  }
  HashSet<X0> _set(ObserverList<X0>) {
    // ** addr: 0x6ba0ec, size: 0x44
    // 0x6ba0ec: EnterFrame
    //     0x6ba0ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6ba0f0: mov             fp, SP
    // 0x6ba0f4: CheckStackOverflow
    //     0x6ba0f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ba0f8: cmp             SP, x16
    //     0x6ba0fc: b.ls            #0x6ba128
    // 0x6ba100: ldr             x0, [fp, #0x10]
    // 0x6ba104: LoadField: r1 = r0->field_7
    //     0x6ba104: ldur            w1, [x0, #7]
    // 0x6ba108: DecompressPointer r1
    //     0x6ba108: add             x1, x1, HEAP, lsl #32
    // 0x6ba10c: SaveReg r1
    //     0x6ba10c: str             x1, [SP, #-8]!
    // 0x6ba110: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ba110: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ba114: r0 = HashSet()
    //     0x6ba114: bl              #0x5519d0  ; [dart:collection] HashSet::HashSet
    // 0x6ba118: add             SP, SP, #8
    // 0x6ba11c: LeaveFrame
    //     0x6ba11c: mov             SP, fp
    //     0x6ba120: ldp             fp, lr, [SP], #0x10
    // 0x6ba124: ret
    //     0x6ba124: ret             
    // 0x6ba128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ba128: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ba12c: b               #0x6ba100
  }
  _ add(/* No info */) {
    // ** addr: 0x6e93b4, size: 0x144
    // 0x6e93b4: EnterFrame
    //     0x6e93b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e93b8: mov             fp, SP
    // 0x6e93bc: AllocStack(0x10)
    //     0x6e93bc: sub             SP, SP, #0x10
    // 0x6e93c0: CheckStackOverflow
    //     0x6e93c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e93c4: cmp             SP, x16
    //     0x6e93c8: b.ls            #0x6e94ec
    // 0x6e93cc: ldr             x3, [fp, #0x18]
    // 0x6e93d0: LoadField: r2 = r3->field_7
    //     0x6e93d0: ldur            w2, [x3, #7]
    // 0x6e93d4: DecompressPointer r2
    //     0x6e93d4: add             x2, x2, HEAP, lsl #32
    // 0x6e93d8: ldr             x0, [fp, #0x10]
    // 0x6e93dc: r1 = Null
    //     0x6e93dc: mov             x1, NULL
    // 0x6e93e0: cmp             w2, NULL
    // 0x6e93e4: b.eq            #0x6e9404
    // 0x6e93e8: LoadField: r4 = r2->field_17
    //     0x6e93e8: ldur            w4, [x2, #0x17]
    // 0x6e93ec: DecompressPointer r4
    //     0x6e93ec: add             x4, x4, HEAP, lsl #32
    // 0x6e93f0: r8 = X0
    //     0x6e93f0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e93f4: LoadField: r9 = r4->field_7
    //     0x6e93f4: ldur            x9, [x4, #7]
    // 0x6e93f8: r3 = Null
    //     0x6e93f8: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cb00] Null
    //     0x6e93fc: ldr             x3, [x3, #0xb00]
    // 0x6e9400: blr             x9
    // 0x6e9404: ldr             x1, [fp, #0x18]
    // 0x6e9408: r0 = true
    //     0x6e9408: add             x0, NULL, #0x20  ; true
    // 0x6e940c: StoreField: r1->field_f = r0
    //     0x6e940c: stur            w0, [x1, #0xf]
    // 0x6e9410: LoadField: r3 = r1->field_b
    //     0x6e9410: ldur            w3, [x1, #0xb]
    // 0x6e9414: DecompressPointer r3
    //     0x6e9414: add             x3, x3, HEAP, lsl #32
    // 0x6e9418: stur            x3, [fp, #-8]
    // 0x6e941c: LoadField: r2 = r3->field_7
    //     0x6e941c: ldur            w2, [x3, #7]
    // 0x6e9420: DecompressPointer r2
    //     0x6e9420: add             x2, x2, HEAP, lsl #32
    // 0x6e9424: ldr             x0, [fp, #0x10]
    // 0x6e9428: r1 = Null
    //     0x6e9428: mov             x1, NULL
    // 0x6e942c: cmp             w2, NULL
    // 0x6e9430: b.eq            #0x6e9450
    // 0x6e9434: LoadField: r4 = r2->field_17
    //     0x6e9434: ldur            w4, [x2, #0x17]
    // 0x6e9438: DecompressPointer r4
    //     0x6e9438: add             x4, x4, HEAP, lsl #32
    // 0x6e943c: r8 = X0
    //     0x6e943c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e9440: LoadField: r9 = r4->field_7
    //     0x6e9440: ldur            x9, [x4, #7]
    // 0x6e9444: r3 = Null
    //     0x6e9444: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1cb10] Null
    //     0x6e9448: ldr             x3, [x3, #0xb10]
    // 0x6e944c: blr             x9
    // 0x6e9450: ldur            x0, [fp, #-8]
    // 0x6e9454: LoadField: r1 = r0->field_b
    //     0x6e9454: ldur            w1, [x0, #0xb]
    // 0x6e9458: DecompressPointer r1
    //     0x6e9458: add             x1, x1, HEAP, lsl #32
    // 0x6e945c: stur            x1, [fp, #-0x10]
    // 0x6e9460: LoadField: r2 = r0->field_f
    //     0x6e9460: ldur            w2, [x0, #0xf]
    // 0x6e9464: DecompressPointer r2
    //     0x6e9464: add             x2, x2, HEAP, lsl #32
    // 0x6e9468: LoadField: r3 = r2->field_b
    //     0x6e9468: ldur            w3, [x2, #0xb]
    // 0x6e946c: DecompressPointer r3
    //     0x6e946c: add             x3, x3, HEAP, lsl #32
    // 0x6e9470: cmp             w1, w3
    // 0x6e9474: b.ne            #0x6e9484
    // 0x6e9478: SaveReg r0
    //     0x6e9478: str             x0, [SP, #-8]!
    // 0x6e947c: r0 = _growToNextCapacity()
    //     0x6e947c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6e9480: add             SP, SP, #8
    // 0x6e9484: ldur            x2, [fp, #-8]
    // 0x6e9488: ldur            x3, [fp, #-0x10]
    // 0x6e948c: r4 = LoadInt32Instr(r3)
    //     0x6e948c: sbfx            x4, x3, #1, #0x1f
    // 0x6e9490: add             x0, x4, #1
    // 0x6e9494: lsl             x3, x0, #1
    // 0x6e9498: StoreField: r2->field_b = r3
    //     0x6e9498: stur            w3, [x2, #0xb]
    // 0x6e949c: mov             x1, x4
    // 0x6e94a0: cmp             x1, x0
    // 0x6e94a4: b.hs            #0x6e94f4
    // 0x6e94a8: LoadField: r1 = r2->field_f
    //     0x6e94a8: ldur            w1, [x2, #0xf]
    // 0x6e94ac: DecompressPointer r1
    //     0x6e94ac: add             x1, x1, HEAP, lsl #32
    // 0x6e94b0: ldr             x0, [fp, #0x10]
    // 0x6e94b4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6e94b4: add             x25, x1, x4, lsl #2
    //     0x6e94b8: add             x25, x25, #0xf
    //     0x6e94bc: str             w0, [x25]
    //     0x6e94c0: tbz             w0, #0, #0x6e94dc
    //     0x6e94c4: ldurb           w16, [x1, #-1]
    //     0x6e94c8: ldurb           w17, [x0, #-1]
    //     0x6e94cc: and             x16, x17, x16, lsr #2
    //     0x6e94d0: tst             x16, HEAP, lsr #32
    //     0x6e94d4: b.eq            #0x6e94dc
    //     0x6e94d8: bl              #0xd67e5c
    // 0x6e94dc: r0 = Null
    //     0x6e94dc: mov             x0, NULL
    // 0x6e94e0: LeaveFrame
    //     0x6e94e0: mov             SP, fp
    //     0x6e94e4: ldp             fp, lr, [SP], #0x10
    // 0x6e94e8: ret
    //     0x6e94e8: ret             
    // 0x6e94ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e94ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e94f0: b               #0x6e93cc
    // 0x6e94f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e94f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0x6f5e78, size: 0xb8
    // 0x6f5e78: EnterFrame
    //     0x6f5e78: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5e7c: mov             fp, SP
    // 0x6f5e80: CheckStackOverflow
    //     0x6f5e80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5e84: cmp             SP, x16
    //     0x6f5e88: b.ls            #0x6f5f28
    // 0x6f5e8c: ldr             x3, [fp, #0x18]
    // 0x6f5e90: LoadField: r2 = r3->field_7
    //     0x6f5e90: ldur            w2, [x3, #7]
    // 0x6f5e94: DecompressPointer r2
    //     0x6f5e94: add             x2, x2, HEAP, lsl #32
    // 0x6f5e98: ldr             x0, [fp, #0x10]
    // 0x6f5e9c: r1 = Null
    //     0x6f5e9c: mov             x1, NULL
    // 0x6f5ea0: cmp             w2, NULL
    // 0x6f5ea4: b.eq            #0x6f5ec4
    // 0x6f5ea8: LoadField: r4 = r2->field_17
    //     0x6f5ea8: ldur            w4, [x2, #0x17]
    // 0x6f5eac: DecompressPointer r4
    //     0x6f5eac: add             x4, x4, HEAP, lsl #32
    // 0x6f5eb0: r8 = X0
    //     0x6f5eb0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6f5eb4: LoadField: r9 = r4->field_7
    //     0x6f5eb4: ldur            x9, [x4, #7]
    // 0x6f5eb8: r3 = Null
    //     0x6f5eb8: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1ca58] Null
    //     0x6f5ebc: ldr             x3, [x3, #0xa58]
    // 0x6f5ec0: blr             x9
    // 0x6f5ec4: ldr             x2, [fp, #0x18]
    // 0x6f5ec8: r0 = true
    //     0x6f5ec8: add             x0, NULL, #0x20  ; true
    // 0x6f5ecc: StoreField: r2->field_f = r0
    //     0x6f5ecc: stur            w0, [x2, #0xf]
    // 0x6f5ed0: mov             x1, x2
    // 0x6f5ed4: LoadField: r0 = r1->field_13
    //     0x6f5ed4: ldur            w0, [x1, #0x13]
    // 0x6f5ed8: DecompressPointer r0
    //     0x6f5ed8: add             x0, x0, HEAP, lsl #32
    // 0x6f5edc: r16 = Sentinel
    //     0x6f5edc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f5ee0: cmp             w0, w16
    // 0x6f5ee4: b.ne            #0x6f5ef4
    // 0x6f5ee8: r2 = _set
    //     0x6f5ee8: add             x2, PP, #0xd, lsl #12  ; [pp+0xdbf8] Field <ObserverList._set@643023516>: late final (offset: 0x14)
    //     0x6f5eec: ldr             x2, [x2, #0xbf8]
    // 0x6f5ef0: r0 = InitLateFinalInstanceField()
    //     0x6f5ef0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x6f5ef4: SaveReg r0
    //     0x6f5ef4: str             x0, [SP, #-8]!
    // 0x6f5ef8: r0 = clear()
    //     0x6f5ef8: bl              #0x592930  ; [dart:collection] _HashSet::clear
    // 0x6f5efc: add             SP, SP, #8
    // 0x6f5f00: ldr             x0, [fp, #0x18]
    // 0x6f5f04: LoadField: r1 = r0->field_b
    //     0x6f5f04: ldur            w1, [x0, #0xb]
    // 0x6f5f08: DecompressPointer r1
    //     0x6f5f08: add             x1, x1, HEAP, lsl #32
    // 0x6f5f0c: ldr             x16, [fp, #0x10]
    // 0x6f5f10: stp             x16, x1, [SP, #-0x10]!
    // 0x6f5f14: r0 = remove()
    //     0x6f5f14: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0x6f5f18: add             SP, SP, #0x10
    // 0x6f5f1c: LeaveFrame
    //     0x6f5f1c: mov             SP, fp
    //     0x6f5f20: ldp             fp, lr, [SP], #0x10
    // 0x6f5f24: ret
    //     0x6f5f24: ret             
    // 0x6f5f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f5f28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5f2c: b               #0x6f5e8c
  }
  _ clear(/* No info */) {
    // ** addr: 0x7014f0, size: 0x7c
    // 0x7014f0: EnterFrame
    //     0x7014f0: stp             fp, lr, [SP, #-0x10]!
    //     0x7014f4: mov             fp, SP
    // 0x7014f8: r0 = false
    //     0x7014f8: add             x0, NULL, #0x30  ; false
    // 0x7014fc: CheckStackOverflow
    //     0x7014fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x701500: cmp             SP, x16
    //     0x701504: b.ls            #0x701564
    // 0x701508: ldr             x1, [fp, #0x10]
    // 0x70150c: StoreField: r1->field_f = r0
    //     0x70150c: stur            w0, [x1, #0xf]
    // 0x701510: LoadField: r0 = r1->field_b
    //     0x701510: ldur            w0, [x1, #0xb]
    // 0x701514: DecompressPointer r0
    //     0x701514: add             x0, x0, HEAP, lsl #32
    // 0x701518: SaveReg r0
    //     0x701518: str             x0, [SP, #-8]!
    // 0x70151c: r0 = clear()
    //     0x70151c: bl              #0xd281bc  ; [dart:core] _GrowableList::clear
    // 0x701520: add             SP, SP, #8
    // 0x701524: ldr             x1, [fp, #0x10]
    // 0x701528: LoadField: r0 = r1->field_13
    //     0x701528: ldur            w0, [x1, #0x13]
    // 0x70152c: DecompressPointer r0
    //     0x70152c: add             x0, x0, HEAP, lsl #32
    // 0x701530: r16 = Sentinel
    //     0x701530: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x701534: cmp             w0, w16
    // 0x701538: b.ne            #0x701548
    // 0x70153c: r2 = _set
    //     0x70153c: add             x2, PP, #0xd, lsl #12  ; [pp+0xdbf8] Field <ObserverList._set@643023516>: late final (offset: 0x14)
    //     0x701540: ldr             x2, [x2, #0xbf8]
    // 0x701544: r0 = InitLateFinalInstanceField()
    //     0x701544: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x701548: SaveReg r0
    //     0x701548: str             x0, [SP, #-8]!
    // 0x70154c: r0 = clear()
    //     0x70154c: bl              #0x592930  ; [dart:collection] _HashSet::clear
    // 0x701550: add             SP, SP, #8
    // 0x701554: r0 = Null
    //     0x701554: mov             x0, NULL
    // 0x701558: LeaveFrame
    //     0x701558: mov             SP, fp
    //     0x70155c: ldp             fp, lr, [SP], #0x10
    // 0x701560: ret
    //     0x701560: ret             
    // 0x701564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x701564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x701568: b               #0x701508
  }
}

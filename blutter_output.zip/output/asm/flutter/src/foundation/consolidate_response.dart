// lib: , url: package:flutter/src/foundation/consolidate_response.dart

// class id: 1049129, size: 0x8
class :: {

  static _ consolidateHttpClientResponseBytes(/* No info */) {
    // ** addr: 0xc31098, size: 0x2b8
    // 0xc31098: EnterFrame
    //     0xc31098: stp             fp, lr, [SP, #-0x10]!
    //     0xc3109c: mov             fp, SP
    // 0xc310a0: AllocStack(0x20)
    //     0xc310a0: sub             SP, SP, #0x20
    // 0xc310a4: CheckStackOverflow
    //     0xc310a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc310a8: cmp             SP, x16
    //     0xc310ac: b.ls            #0xc31348
    // 0xc310b0: r1 = 7
    //     0xc310b0: mov             x1, #7
    // 0xc310b4: r0 = AllocateContext()
    //     0xc310b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc310b8: mov             x1, x0
    // 0xc310bc: ldr             x0, [fp, #0x10]
    // 0xc310c0: stur            x1, [fp, #-8]
    // 0xc310c4: StoreField: r1->field_f = r0
    //     0xc310c4: stur            w0, [x1, #0xf]
    // 0xc310c8: r16 = <Uint8List>
    //     0xc310c8: ldr             x16, [PP, #0x1540]  ; [pp+0x1540] TypeArguments: <Uint8List>
    // 0xc310cc: SaveReg r16
    //     0xc310cc: str             x16, [SP, #-8]!
    // 0xc310d0: r0 = Completer.sync()
    //     0xc310d0: bl              #0x52872c  ; [dart:async] Completer::Completer.sync
    // 0xc310d4: add             SP, SP, #8
    // 0xc310d8: mov             x3, x0
    // 0xc310dc: ldur            x2, [fp, #-8]
    // 0xc310e0: stur            x3, [fp, #-0x10]
    // 0xc310e4: StoreField: r2->field_13 = r0
    //     0xc310e4: stur            w0, [x2, #0x13]
    //     0xc310e8: ldurb           w16, [x2, #-1]
    //     0xc310ec: ldurb           w17, [x0, #-1]
    //     0xc310f0: and             x16, x17, x16, lsr #2
    //     0xc310f4: tst             x16, HEAP, lsr #32
    //     0xc310f8: b.eq            #0xc31100
    //     0xc310fc: bl              #0xd6828c
    // 0xc31100: r1 = <List<int>>
    //     0xc31100: ldr             x1, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0xc31104: r0 = _OutputBuffer()
    //     0xc31104: bl              #0xc31350  ; Allocate_OutputBufferStub -> _OutputBuffer (size=0x1c)
    // 0xc31108: mov             x1, x0
    // 0xc3110c: r0 = 0
    //     0xc3110c: mov             x0, #0
    // 0xc31110: stur            x1, [fp, #-0x18]
    // 0xc31114: StoreField: r1->field_f = r0
    //     0xc31114: stur            x0, [x1, #0xf]
    // 0xc31118: r16 = <List<int>>
    //     0xc31118: ldr             x16, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0xc3111c: stp             xzr, x16, [SP, #-0x10]!
    // 0xc31120: r0 = _GrowableList()
    //     0xc31120: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xc31124: add             SP, SP, #0x10
    // 0xc31128: ldur            x2, [fp, #-0x18]
    // 0xc3112c: StoreField: r2->field_b = r0
    //     0xc3112c: stur            w0, [x2, #0xb]
    //     0xc31130: ldurb           w16, [x2, #-1]
    //     0xc31134: ldurb           w17, [x0, #-1]
    //     0xc31138: and             x16, x17, x16, lsr #2
    //     0xc3113c: tst             x16, HEAP, lsr #32
    //     0xc31140: b.eq            #0xc31148
    //     0xc31144: bl              #0xd6828c
    // 0xc31148: mov             x0, x2
    // 0xc3114c: ldur            x3, [fp, #-8]
    // 0xc31150: StoreField: r3->field_17 = r0
    //     0xc31150: stur            w0, [x3, #0x17]
    //     0xc31154: ldurb           w16, [x3, #-1]
    //     0xc31158: ldurb           w17, [x0, #-1]
    //     0xc3115c: and             x16, x17, x16, lsr #2
    //     0xc31160: tst             x16, HEAP, lsr #32
    //     0xc31164: b.eq            #0xc3116c
    //     0xc31168: bl              #0xd682ac
    // 0xc3116c: mov             x0, x2
    // 0xc31170: StoreField: r3->field_1b = r0
    //     0xc31170: stur            w0, [x3, #0x1b]
    //     0xc31174: ldurb           w16, [x3, #-1]
    //     0xc31178: ldurb           w17, [x0, #-1]
    //     0xc3117c: and             x16, x17, x16, lsr #2
    //     0xc31180: tst             x16, HEAP, lsr #32
    //     0xc31184: b.eq            #0xc3118c
    //     0xc31188: bl              #0xd682ac
    // 0xc3118c: ldr             x4, [fp, #0x18]
    // 0xc31190: LoadField: r0 = r4->field_b
    //     0xc31190: ldur            w0, [x4, #0xb]
    // 0xc31194: DecompressPointer r0
    //     0xc31194: add             x0, x0, HEAP, lsl #32
    // 0xc31198: LoadField: r1 = r0->field_13
    //     0xc31198: ldur            w1, [x0, #0x13]
    // 0xc3119c: DecompressPointer r1
    //     0xc3119c: add             x1, x1, HEAP, lsl #32
    // 0xc311a0: LoadField: r5 = r1->field_1b
    //     0xc311a0: ldur            x5, [x1, #0x1b]
    // 0xc311a4: r0 = BoxInt64Instr(r5)
    //     0xc311a4: sbfiz           x0, x5, #1, #0x1f
    //     0xc311a8: cmp             x5, x0, asr #1
    //     0xc311ac: b.eq            #0xc311b8
    //     0xc311b0: bl              #0xd69bb8
    //     0xc311b4: stur            x5, [x0, #7]
    // 0xc311b8: mov             x1, x0
    // 0xc311bc: StoreField: r3->field_1f = r0
    //     0xc311bc: stur            w0, [x3, #0x1f]
    //     0xc311c0: tbz             w0, #0, #0xc311dc
    //     0xc311c4: ldurb           w16, [x3, #-1]
    //     0xc311c8: ldurb           w17, [x0, #-1]
    //     0xc311cc: and             x16, x17, x16, lsr #2
    //     0xc311d0: tst             x16, HEAP, lsr #32
    //     0xc311d4: b.eq            #0xc311dc
    //     0xc311d8: bl              #0xd682ac
    // 0xc311dc: cmn             w1, #2
    // 0xc311e0: b.ne            #0xc311e8
    // 0xc311e4: StoreField: r3->field_1f = rNULL
    //     0xc311e4: stur            NULL, [x3, #0x1f]
    // 0xc311e8: LoadField: r0 = r4->field_1b
    //     0xc311e8: ldur            w0, [x4, #0x1b]
    // 0xc311ec: DecompressPointer r0
    //     0xc311ec: add             x0, x0, HEAP, lsl #32
    // 0xc311f0: LoadField: r1 = r0->field_7
    //     0xc311f0: ldur            x1, [x0, #7]
    // 0xc311f4: cmp             x1, #1
    // 0xc311f8: b.gt            #0xc31218
    // 0xc311fc: cmp             x1, #0
    // 0xc31200: b.gt            #0xc3120c
    // 0xc31204: mov             x2, x3
    // 0xc31208: b               #0xc31264
    // 0xc3120c: StoreField: r3->field_1f = rNULL
    //     0xc3120c: stur            NULL, [x3, #0x1f]
    // 0xc31210: mov             x2, x3
    // 0xc31214: b               #0xc31264
    // 0xc31218: r1 = <List<int>, List<int>>
    //     0xc31218: ldr             x1, [PP, #0x5058]  ; [pp+0x5058] TypeArguments: <List<int>, List<int>>
    // 0xc3121c: r0 = ZLibDecoder()
    //     0xc3121c: bl              #0x7f57c8  ; AllocateZLibDecoderStub -> ZLibDecoder (size=0x1c)
    // 0xc31220: mov             x1, x0
    // 0xc31224: r0 = 15
    //     0xc31224: mov             x0, #0xf
    // 0xc31228: StoreField: r1->field_b = r0
    //     0xc31228: stur            x0, [x1, #0xb]
    // 0xc3122c: r0 = false
    //     0xc3122c: add             x0, NULL, #0x30  ; false
    // 0xc31230: StoreField: r1->field_17 = r0
    //     0xc31230: stur            w0, [x1, #0x17]
    // 0xc31234: ldur            x16, [fp, #-0x18]
    // 0xc31238: stp             x16, x1, [SP, #-0x10]!
    // 0xc3123c: r0 = startChunkedConversion()
    //     0xc3123c: bl              #0xc737c8  ; [dart:io] ZLibDecoder::startChunkedConversion
    // 0xc31240: add             SP, SP, #0x10
    // 0xc31244: ldur            x2, [fp, #-8]
    // 0xc31248: StoreField: r2->field_1b = r0
    //     0xc31248: stur            w0, [x2, #0x1b]
    //     0xc3124c: ldurb           w16, [x2, #-1]
    //     0xc31250: ldurb           w17, [x0, #-1]
    //     0xc31254: and             x16, x17, x16, lsr #2
    //     0xc31258: tst             x16, HEAP, lsr #32
    //     0xc3125c: b.eq            #0xc31264
    //     0xc31260: bl              #0xd6828c
    // 0xc31264: ldur            x1, [fp, #-0x10]
    // 0xc31268: r0 = Sentinel
    //     0xc31268: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc3126c: StoreField: r2->field_23 = rZR
    //     0xc3126c: stur            wzr, [x2, #0x23]
    // 0xc31270: StoreField: r2->field_27 = r0
    //     0xc31270: stur            w0, [x2, #0x27]
    // 0xc31274: r0 = LoadClassIdInstr(r1)
    //     0xc31274: ldur            x0, [x1, #-1]
    //     0xc31278: ubfx            x0, x0, #0xc, #0x14
    // 0xc3127c: SaveReg r1
    //     0xc3127c: str             x1, [SP, #-8]!
    // 0xc31280: r0 = GDT[cid_x0 + -0xf39]()
    //     0xc31280: sub             lr, x0, #0xf39
    //     0xc31284: ldr             lr, [x21, lr, lsl #3]
    //     0xc31288: blr             lr
    // 0xc3128c: add             SP, SP, #8
    // 0xc31290: ldur            x2, [fp, #-8]
    // 0xc31294: r1 = Function '<anonymous closure>': static.
    //     0xc31294: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cab8] AnonymousClosure: static (0xc31400), in [package:flutter/src/foundation/consolidate_response.dart] ::consolidateHttpClientResponseBytes (0xc31098)
    //     0xc31298: ldr             x1, [x1, #0xab8]
    // 0xc3129c: stur            x0, [fp, #-0x18]
    // 0xc312a0: r0 = AllocateClosure()
    //     0xc312a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc312a4: ldur            x2, [fp, #-8]
    // 0xc312a8: r1 = Function '<anonymous closure>': static.
    //     0xc312a8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cac0] AnonymousClosure: static (0xc3135c), in [package:flutter/src/foundation/consolidate_response.dart] ::consolidateHttpClientResponseBytes (0xc31098)
    //     0xc312ac: ldr             x1, [x1, #0xac0]
    // 0xc312b0: stur            x0, [fp, #-0x20]
    // 0xc312b4: r0 = AllocateClosure()
    //     0xc312b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc312b8: ldr             x16, [fp, #0x18]
    // 0xc312bc: ldur            lr, [fp, #-0x20]
    // 0xc312c0: stp             lr, x16, [SP, #-0x10]!
    // 0xc312c4: ldur            x16, [fp, #-0x18]
    // 0xc312c8: stp             x16, x0, [SP, #-0x10]!
    // 0xc312cc: r16 = true
    //     0xc312cc: add             x16, NULL, #0x20  ; true
    // 0xc312d0: SaveReg r16
    //     0xc312d0: str             x16, [SP, #-8]!
    // 0xc312d4: r4 = const [0, 0x5, 0x5, 0x2, cancelOnError, 0x4, onDone, 0x2, onError, 0x3, null]
    //     0xc312d4: add             x4, PP, #0x29, lsl #12  ; [pp+0x296a0] List(11) [0, 0x5, 0x5, 0x2, "cancelOnError", 0x4, "onDone", 0x2, "onError", 0x3, Null]
    //     0xc312d8: ldr             x4, [x4, #0x6a0]
    // 0xc312dc: r0 = listen()
    //     0xc312dc: bl              #0xc581e0  ; [dart:_http] _HttpClientResponse::listen
    // 0xc312e0: add             SP, SP, #0x28
    // 0xc312e4: ldur            x1, [fp, #-8]
    // 0xc312e8: LoadField: r2 = r1->field_27
    //     0xc312e8: ldur            w2, [x1, #0x27]
    // 0xc312ec: DecompressPointer r2
    //     0xc312ec: add             x2, x2, HEAP, lsl #32
    // 0xc312f0: r16 = Sentinel
    //     0xc312f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc312f4: cmp             w2, w16
    // 0xc312f8: b.ne            #0xc3131c
    // 0xc312fc: StoreField: r1->field_27 = r0
    //     0xc312fc: stur            w0, [x1, #0x27]
    //     0xc31300: ldurb           w16, [x1, #-1]
    //     0xc31304: ldurb           w17, [x0, #-1]
    //     0xc31308: and             x16, x17, x16, lsr #2
    //     0xc3130c: tst             x16, HEAP, lsr #32
    //     0xc31310: b.eq            #0xc31318
    //     0xc31314: bl              #0xd6826c
    // 0xc31318: b               #0xc31330
    // 0xc3131c: r16 = "subscription"
    //     0xc3131c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] "subscription"
    //     0xc31320: ldr             x16, [x16, #0xd58]
    // 0xc31324: SaveReg r16
    //     0xc31324: str             x16, [SP, #-8]!
    // 0xc31328: r0 = _throwLocalAlreadyInitialized()
    //     0xc31328: bl              #0x4fb7e0  ; [dart:_internal] LateError::_throwLocalAlreadyInitialized
    // 0xc3132c: add             SP, SP, #8
    // 0xc31330: ldur            x1, [fp, #-0x10]
    // 0xc31334: LoadField: r0 = r1->field_b
    //     0xc31334: ldur            w0, [x1, #0xb]
    // 0xc31338: DecompressPointer r0
    //     0xc31338: add             x0, x0, HEAP, lsl #32
    // 0xc3133c: LeaveFrame
    //     0xc3133c: mov             SP, fp
    //     0xc31340: ldp             fp, lr, [SP], #0x10
    // 0xc31344: ret
    //     0xc31344: ret             
    // 0xc31348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc31348: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3134c: b               #0xc310b0
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0xc3135c, size: 0xa4
    // 0xc3135c: EnterFrame
    //     0xc3135c: stp             fp, lr, [SP, #-0x10]!
    //     0xc31360: mov             fp, SP
    // 0xc31364: AllocStack(0x8)
    //     0xc31364: sub             SP, SP, #8
    // 0xc31368: SetupParameters()
    //     0xc31368: ldr             x0, [fp, #0x10]
    //     0xc3136c: ldur            w1, [x0, #0x17]
    //     0xc31370: add             x1, x1, HEAP, lsl #32
    //     0xc31374: stur            x1, [fp, #-8]
    // 0xc31378: CheckStackOverflow
    //     0xc31378: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3137c: cmp             SP, x16
    //     0xc31380: b.ls            #0xc313f4
    // 0xc31384: LoadField: r0 = r1->field_1b
    //     0xc31384: ldur            w0, [x1, #0x1b]
    // 0xc31388: DecompressPointer r0
    //     0xc31388: add             x0, x0, HEAP, lsl #32
    // 0xc3138c: r2 = LoadClassIdInstr(r0)
    //     0xc3138c: ldur            x2, [x0, #-1]
    //     0xc31390: ubfx            x2, x2, #0xc, #0x14
    // 0xc31394: SaveReg r0
    //     0xc31394: str             x0, [SP, #-8]!
    // 0xc31398: mov             x0, x2
    // 0xc3139c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc3139c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc313a0: r0 = GDT[cid_x0 + 0x8a8]()
    //     0xc313a0: add             lr, x0, #0x8a8
    //     0xc313a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc313a8: blr             lr
    // 0xc313ac: add             SP, SP, #8
    // 0xc313b0: ldur            x0, [fp, #-8]
    // 0xc313b4: LoadField: r1 = r0->field_13
    //     0xc313b4: ldur            w1, [x0, #0x13]
    // 0xc313b8: DecompressPointer r1
    //     0xc313b8: add             x1, x1, HEAP, lsl #32
    // 0xc313bc: LoadField: r2 = r0->field_17
    //     0xc313bc: ldur            w2, [x0, #0x17]
    // 0xc313c0: DecompressPointer r2
    //     0xc313c0: add             x2, x2, HEAP, lsl #32
    // 0xc313c4: LoadField: r0 = r2->field_17
    //     0xc313c4: ldur            w0, [x2, #0x17]
    // 0xc313c8: DecompressPointer r0
    //     0xc313c8: add             x0, x0, HEAP, lsl #32
    // 0xc313cc: cmp             w0, NULL
    // 0xc313d0: b.eq            #0xc313fc
    // 0xc313d4: stp             x0, x1, [SP, #-0x10]!
    // 0xc313d8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc313d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc313dc: r0 = complete()
    //     0xc313dc: bl              #0xca4040  ; [dart:async] _SyncCompleter::complete
    // 0xc313e0: add             SP, SP, #0x10
    // 0xc313e4: r0 = Null
    //     0xc313e4: mov             x0, NULL
    // 0xc313e8: LeaveFrame
    //     0xc313e8: mov             SP, fp
    //     0xc313ec: ldp             fp, lr, [SP], #0x10
    // 0xc313f0: ret
    //     0xc313f0: ret             
    // 0xc313f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc313f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc313f8: b               #0xc31384
    // 0xc313fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc313fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static void <anonymous closure>(dynamic, List<int>) {
    // ** addr: 0xc31400, size: 0x1f0
    // 0xc31400: EnterFrame
    //     0xc31400: stp             fp, lr, [SP, #-0x10]!
    //     0xc31404: mov             fp, SP
    // 0xc31408: AllocStack(0x40)
    //     0xc31408: sub             SP, SP, #0x40
    // 0xc3140c: SetupParameters()
    //     0xc3140c: ldr             x0, [fp, #0x18]
    //     0xc31410: ldur            w1, [x0, #0x17]
    //     0xc31414: add             x1, x1, HEAP, lsl #32
    //     0xc31418: stur            x1, [fp, #-0x38]
    // 0xc3141c: CheckStackOverflow
    //     0xc3141c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc31420: cmp             SP, x16
    //     0xc31424: b.ls            #0xc315e0
    // 0xc31428: LoadField: r0 = r1->field_1b
    //     0xc31428: ldur            w0, [x1, #0x1b]
    // 0xc3142c: DecompressPointer r0
    //     0xc3142c: add             x0, x0, HEAP, lsl #32
    // 0xc31430: r2 = LoadClassIdInstr(r0)
    //     0xc31430: ldur            x2, [x0, #-1]
    //     0xc31434: ubfx            x2, x2, #0xc, #0x14
    // 0xc31438: ldr             x16, [fp, #0x10]
    // 0xc3143c: stp             x16, x0, [SP, #-0x10]!
    // 0xc31440: mov             x0, x2
    // 0xc31444: r0 = GDT[cid_x0 + 0x6e6]()
    //     0xc31444: add             lr, x0, #0x6e6
    //     0xc31448: ldr             lr, [x21, lr, lsl #3]
    //     0xc3144c: blr             lr
    // 0xc31450: add             SP, SP, #0x10
    // 0xc31454: ldur            x1, [fp, #-0x38]
    // 0xc31458: LoadField: r0 = r1->field_f
    //     0xc31458: ldur            w0, [x1, #0xf]
    // 0xc3145c: DecompressPointer r0
    //     0xc3145c: add             x0, x0, HEAP, lsl #32
    // 0xc31460: cmp             w0, NULL
    // 0xc31464: b.eq            #0xc3153c
    // 0xc31468: ldr             x0, [fp, #0x10]
    // 0xc3146c: LoadField: r2 = r1->field_23
    //     0xc3146c: ldur            w2, [x1, #0x23]
    // 0xc31470: DecompressPointer r2
    //     0xc31470: add             x2, x2, HEAP, lsl #32
    // 0xc31474: stur            x2, [fp, #-0x40]
    // 0xc31478: r3 = LoadClassIdInstr(r0)
    //     0xc31478: ldur            x3, [x0, #-1]
    //     0xc3147c: ubfx            x3, x3, #0xc, #0x14
    // 0xc31480: SaveReg r0
    //     0xc31480: str             x0, [SP, #-8]!
    // 0xc31484: mov             x0, x3
    // 0xc31488: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc31488: mov             x17, #0xb8ea
    //     0xc3148c: add             lr, x0, x17
    //     0xc31490: ldr             lr, [x21, lr, lsl #3]
    //     0xc31494: blr             lr
    // 0xc31498: add             SP, SP, #8
    // 0xc3149c: mov             x1, x0
    // 0xc314a0: ldur            x0, [fp, #-0x40]
    // 0xc314a4: cmp             w0, NULL
    // 0xc314a8: b.eq            #0xc315e8
    // 0xc314ac: r2 = LoadInt32Instr(r1)
    //     0xc314ac: sbfx            x2, x1, #1, #0x1f
    //     0xc314b0: tbz             w1, #0, #0xc314b8
    //     0xc314b4: ldur            x2, [x1, #7]
    // 0xc314b8: r1 = LoadInt32Instr(r0)
    //     0xc314b8: sbfx            x1, x0, #1, #0x1f
    //     0xc314bc: tbz             w0, #0, #0xc314c4
    //     0xc314c0: ldur            x1, [x0, #7]
    // 0xc314c4: add             x3, x1, x2
    // 0xc314c8: r0 = BoxInt64Instr(r3)
    //     0xc314c8: sbfiz           x0, x3, #1, #0x1f
    //     0xc314cc: cmp             x3, x0, asr #1
    //     0xc314d0: b.eq            #0xc314dc
    //     0xc314d4: bl              #0xd69bb8
    //     0xc314d8: stur            x3, [x0, #7]
    // 0xc314dc: mov             x2, x0
    // 0xc314e0: ldur            x1, [fp, #-0x38]
    // 0xc314e4: StoreField: r1->field_23 = r0
    //     0xc314e4: stur            w0, [x1, #0x23]
    //     0xc314e8: tbz             w0, #0, #0xc31504
    //     0xc314ec: ldurb           w16, [x1, #-1]
    //     0xc314f0: ldurb           w17, [x0, #-1]
    //     0xc314f4: and             x16, x17, x16, lsr #2
    //     0xc314f8: tst             x16, HEAP, lsr #32
    //     0xc314fc: b.eq            #0xc31504
    //     0xc31500: bl              #0xd6826c
    // 0xc31504: LoadField: r3 = r1->field_f
    //     0xc31504: ldur            w3, [x1, #0xf]
    // 0xc31508: DecompressPointer r3
    //     0xc31508: add             x3, x3, HEAP, lsl #32
    // 0xc3150c: stur            x3, [fp, #-0x40]
    // 0xc31510: LoadField: r0 = r1->field_1f
    //     0xc31510: ldur            w0, [x1, #0x1f]
    // 0xc31514: DecompressPointer r0
    //     0xc31514: add             x0, x0, HEAP, lsl #32
    // 0xc31518: cmp             w3, NULL
    // 0xc3151c: b.eq            #0xc315ec
    // 0xc31520: stp             x2, x3, [SP, #-0x10]!
    // 0xc31524: SaveReg r0
    //     0xc31524: str             x0, [SP, #-8]!
    // 0xc31528: mov             x0, x3
    // 0xc3152c: ClosureCall
    //     0xc3152c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc31530: ldur            x2, [x0, #0x1f]
    //     0xc31534: blr             x2
    // 0xc31538: add             SP, SP, #0x18
    // 0xc3153c: r0 = Null
    //     0xc3153c: mov             x0, NULL
    // 0xc31540: LeaveFrame
    //     0xc31540: mov             SP, fp
    //     0xc31544: ldp             fp, lr, [SP], #0x10
    // 0xc31548: ret
    //     0xc31548: ret             
    // 0xc3154c: sub             SP, fp, #0x40
    // 0xc31550: ldur            x2, [fp, #-0x10]
    // 0xc31554: mov             x16, x1
    // 0xc31558: mov             x1, x0
    // 0xc3155c: mov             x0, x16
    // 0xc31560: LoadField: r3 = r2->field_13
    //     0xc31560: ldur            w3, [x2, #0x13]
    // 0xc31564: DecompressPointer r3
    //     0xc31564: add             x3, x3, HEAP, lsl #32
    // 0xc31568: stp             x1, x3, [SP, #-0x10]!
    // 0xc3156c: SaveReg r0
    //     0xc3156c: str             x0, [SP, #-8]!
    // 0xc31570: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xc31570: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xc31574: r0 = completeError()
    //     0xc31574: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0xc31578: add             SP, SP, #0x18
    // 0xc3157c: ldur            x0, [fp, #-0x10]
    // 0xc31580: LoadField: r1 = r0->field_27
    //     0xc31580: ldur            w1, [x0, #0x27]
    // 0xc31584: DecompressPointer r1
    //     0xc31584: add             x1, x1, HEAP, lsl #32
    // 0xc31588: r16 = Sentinel
    //     0xc31588: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc3158c: cmp             w1, w16
    // 0xc31590: b.ne            #0xc315a8
    // 0xc31594: r16 = "subscription"
    //     0xc31594: add             x16, PP, #0x13, lsl #12  ; [pp+0x13d58] "subscription"
    //     0xc31598: ldr             x16, [x16, #0xd58]
    // 0xc3159c: SaveReg r16
    //     0xc3159c: str             x16, [SP, #-8]!
    // 0xc315a0: r0 = _throwLocalNotInitialized()
    //     0xc315a0: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xc315a4: add             SP, SP, #8
    // 0xc315a8: ldur            x0, [fp, #-0x10]
    // 0xc315ac: LoadField: r1 = r0->field_27
    //     0xc315ac: ldur            w1, [x0, #0x27]
    // 0xc315b0: DecompressPointer r1
    //     0xc315b0: add             x1, x1, HEAP, lsl #32
    // 0xc315b4: r0 = LoadClassIdInstr(r1)
    //     0xc315b4: ldur            x0, [x1, #-1]
    //     0xc315b8: ubfx            x0, x0, #0xc, #0x14
    // 0xc315bc: SaveReg r1
    //     0xc315bc: str             x1, [SP, #-8]!
    // 0xc315c0: r0 = GDT[cid_x0 + 0x307]()
    //     0xc315c0: add             lr, x0, #0x307
    //     0xc315c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc315c8: blr             lr
    // 0xc315cc: add             SP, SP, #8
    // 0xc315d0: r0 = Null
    //     0xc315d0: mov             x0, NULL
    // 0xc315d4: LeaveFrame
    //     0xc315d4: mov             SP, fp
    //     0xc315d8: ldp             fp, lr, [SP], #0x10
    // 0xc315dc: ret
    //     0xc315dc: ret             
    // 0xc315e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc315e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc315e4: b               #0xc31428
    // 0xc315e8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc315e8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xc315ec: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc315ec: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 5392, size: 0x1c, field offset: 0xc
class _OutputBuffer extends ByteConversionSinkBase {

  dynamic close(dynamic) {
    // ** addr: 0xbce650, size: 0x18
    // 0xbce650: r4 = 7
    //     0xbce650: mov             x4, #7
    // 0xbce654: r1 = Function 'close':.
    //     0xbce654: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ba0] AnonymousClosure: (0xbce668), in [package:flutter/src/foundation/consolidate_response.dart] _OutputBuffer::close (0xc0a4f4)
    //     0xbce658: ldr             x1, [x17, #0xba0]
    // 0xbce65c: r24 = BuildNonGenericMethodExtractorStub
    //     0xbce65c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbce660: LoadField: r0 = r24->field_17
    //     0xbce660: ldur            x0, [x24, #0x17]
    // 0xbce664: br              x0
  }
  [closure] void close(dynamic) {
    // ** addr: 0xbce668, size: 0x48
    // 0xbce668: EnterFrame
    //     0xbce668: stp             fp, lr, [SP, #-0x10]!
    //     0xbce66c: mov             fp, SP
    // 0xbce670: ldr             x0, [fp, #0x10]
    // 0xbce674: LoadField: r1 = r0->field_17
    //     0xbce674: ldur            w1, [x0, #0x17]
    // 0xbce678: DecompressPointer r1
    //     0xbce678: add             x1, x1, HEAP, lsl #32
    // 0xbce67c: CheckStackOverflow
    //     0xbce67c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbce680: cmp             SP, x16
    //     0xbce684: b.ls            #0xbce6a8
    // 0xbce688: LoadField: r0 = r1->field_f
    //     0xbce688: ldur            w0, [x1, #0xf]
    // 0xbce68c: DecompressPointer r0
    //     0xbce68c: add             x0, x0, HEAP, lsl #32
    // 0xbce690: SaveReg r0
    //     0xbce690: str             x0, [SP, #-8]!
    // 0xbce694: r0 = close()
    //     0xbce694: bl              #0xc0a4f4  ; [package:flutter/src/foundation/consolidate_response.dart] _OutputBuffer::close
    // 0xbce698: add             SP, SP, #8
    // 0xbce69c: LeaveFrame
    //     0xbce69c: mov             SP, fp
    //     0xbce6a0: ldp             fp, lr, [SP], #0x10
    // 0xbce6a4: ret
    //     0xbce6a4: ret             
    // 0xbce6a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbce6a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbce6ac: b               #0xbce688
  }
  dynamic add(dynamic) {
    // ** addr: 0xbcf718, size: 0x18
    // 0xbcf718: r4 = 7
    //     0xbcf718: mov             x4, #7
    // 0xbcf71c: r1 = Function 'add':.
    //     0xbcf71c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ba8] AnonymousClosure: (0xbcf730), in [package:flutter/src/foundation/consolidate_response.dart] _OutputBuffer::add (0xc2f688)
    //     0xbcf720: ldr             x1, [x17, #0xba8]
    // 0xbcf724: r24 = BuildNonGenericMethodExtractorStub
    //     0xbcf724: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xbcf728: LoadField: r0 = r24->field_17
    //     0xbcf728: ldur            x0, [x24, #0x17]
    // 0xbcf72c: br              x0
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0xbcf730, size: 0x4c
    // 0xbcf730: EnterFrame
    //     0xbcf730: stp             fp, lr, [SP, #-0x10]!
    //     0xbcf734: mov             fp, SP
    // 0xbcf738: ldr             x0, [fp, #0x18]
    // 0xbcf73c: LoadField: r1 = r0->field_17
    //     0xbcf73c: ldur            w1, [x0, #0x17]
    // 0xbcf740: DecompressPointer r1
    //     0xbcf740: add             x1, x1, HEAP, lsl #32
    // 0xbcf744: CheckStackOverflow
    //     0xbcf744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbcf748: cmp             SP, x16
    //     0xbcf74c: b.ls            #0xbcf774
    // 0xbcf750: LoadField: r0 = r1->field_f
    //     0xbcf750: ldur            w0, [x1, #0xf]
    // 0xbcf754: DecompressPointer r0
    //     0xbcf754: add             x0, x0, HEAP, lsl #32
    // 0xbcf758: ldr             x16, [fp, #0x10]
    // 0xbcf75c: stp             x16, x0, [SP, #-0x10]!
    // 0xbcf760: r0 = add()
    //     0xbcf760: bl              #0xc2f688  ; [package:flutter/src/foundation/consolidate_response.dart] _OutputBuffer::add
    // 0xbcf764: add             SP, SP, #0x10
    // 0xbcf768: LeaveFrame
    //     0xbcf768: mov             SP, fp
    //     0xbcf76c: ldp             fp, lr, [SP], #0x10
    // 0xbcf770: ret
    //     0xbcf770: ret             
    // 0xbcf774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcf774: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcf778: b               #0xbcf750
  }
  _ close(/* No info */) {
    // ** addr: 0xc0a4f4, size: 0x2b8
    // 0xc0a4f4: EnterFrame
    //     0xc0a4f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a4f8: mov             fp, SP
    // 0xc0a4fc: AllocStack(0x40)
    //     0xc0a4fc: sub             SP, SP, #0x40
    // 0xc0a500: CheckStackOverflow
    //     0xc0a500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0a504: cmp             SP, x16
    //     0xc0a508: b.ls            #0xc0a794
    // 0xc0a50c: ldr             x2, [fp, #0x10]
    // 0xc0a510: LoadField: r0 = r2->field_17
    //     0xc0a510: ldur            w0, [x2, #0x17]
    // 0xc0a514: DecompressPointer r0
    //     0xc0a514: add             x0, x0, HEAP, lsl #32
    // 0xc0a518: cmp             w0, NULL
    // 0xc0a51c: b.eq            #0xc0a530
    // 0xc0a520: r0 = Null
    //     0xc0a520: mov             x0, NULL
    // 0xc0a524: LeaveFrame
    //     0xc0a524: mov             SP, fp
    //     0xc0a528: ldp             fp, lr, [SP], #0x10
    // 0xc0a52c: ret
    //     0xc0a52c: ret             
    // 0xc0a530: LoadField: r3 = r2->field_f
    //     0xc0a530: ldur            x3, [x2, #0xf]
    // 0xc0a534: r0 = BoxInt64Instr(r3)
    //     0xc0a534: sbfiz           x0, x3, #1, #0x1f
    //     0xc0a538: cmp             x3, x0, asr #1
    //     0xc0a53c: b.eq            #0xc0a548
    //     0xc0a540: bl              #0xd69bb8
    //     0xc0a544: stur            x3, [x0, #7]
    // 0xc0a548: mov             x4, x0
    // 0xc0a54c: r0 = AllocateUint8Array()
    //     0xc0a54c: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xc0a550: ldr             x1, [fp, #0x10]
    // 0xc0a554: StoreField: r1->field_17 = r0
    //     0xc0a554: stur            w0, [x1, #0x17]
    //     0xc0a558: ldurb           w16, [x1, #-1]
    //     0xc0a55c: ldurb           w17, [x0, #-1]
    //     0xc0a560: and             x16, x17, x16, lsr #2
    //     0xc0a564: tst             x16, HEAP, lsr #32
    //     0xc0a568: b.eq            #0xc0a570
    //     0xc0a56c: bl              #0xd6826c
    // 0xc0a570: LoadField: r2 = r1->field_b
    //     0xc0a570: ldur            w2, [x1, #0xb]
    // 0xc0a574: DecompressPointer r2
    //     0xc0a574: add             x2, x2, HEAP, lsl #32
    // 0xc0a578: stur            x2, [fp, #-0x28]
    // 0xc0a57c: cmp             w2, NULL
    // 0xc0a580: b.eq            #0xc0a79c
    // 0xc0a584: LoadField: r3 = r2->field_7
    //     0xc0a584: ldur            w3, [x2, #7]
    // 0xc0a588: DecompressPointer r3
    //     0xc0a588: add             x3, x3, HEAP, lsl #32
    // 0xc0a58c: stur            x3, [fp, #-0x20]
    // 0xc0a590: LoadField: r0 = r2->field_b
    //     0xc0a590: ldur            w0, [x2, #0xb]
    // 0xc0a594: DecompressPointer r0
    //     0xc0a594: add             x0, x0, HEAP, lsl #32
    // 0xc0a598: r4 = LoadInt32Instr(r0)
    //     0xc0a598: sbfx            x4, x0, #1, #0x1f
    // 0xc0a59c: stur            x4, [fp, #-0x18]
    // 0xc0a5a0: r6 = 0
    //     0xc0a5a0: mov             x6, #0
    // 0xc0a5a4: r5 = 0
    //     0xc0a5a4: mov             x5, #0
    // 0xc0a5a8: stur            x6, [fp, #-8]
    // 0xc0a5ac: stur            x5, [fp, #-0x10]
    // 0xc0a5b0: CheckStackOverflow
    //     0xc0a5b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0a5b4: cmp             SP, x16
    //     0xc0a5b8: b.ls            #0xc0a7a0
    // 0xc0a5bc: r0 = LoadClassIdInstr(r2)
    //     0xc0a5bc: ldur            x0, [x2, #-1]
    //     0xc0a5c0: ubfx            x0, x0, #0xc, #0x14
    // 0xc0a5c4: SaveReg r2
    //     0xc0a5c4: str             x2, [SP, #-8]!
    // 0xc0a5c8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc0a5c8: mov             x17, #0xb8ea
    //     0xc0a5cc: add             lr, x0, x17
    //     0xc0a5d0: ldr             lr, [x21, lr, lsl #3]
    //     0xc0a5d4: blr             lr
    // 0xc0a5d8: add             SP, SP, #8
    // 0xc0a5dc: r1 = LoadInt32Instr(r0)
    //     0xc0a5dc: sbfx            x1, x0, #1, #0x1f
    //     0xc0a5e0: tbz             w0, #0, #0xc0a5e8
    //     0xc0a5e4: ldur            x1, [x0, #7]
    // 0xc0a5e8: ldur            x2, [fp, #-0x18]
    // 0xc0a5ec: cmp             x2, x1
    // 0xc0a5f0: b.ne            #0xc0a77c
    // 0xc0a5f4: ldur            x3, [fp, #-0x28]
    // 0xc0a5f8: ldur            x4, [fp, #-0x10]
    // 0xc0a5fc: cmp             x4, x1
    // 0xc0a600: b.lt            #0xc0a61c
    // 0xc0a604: ldr             x5, [fp, #0x10]
    // 0xc0a608: StoreField: r5->field_b = rNULL
    //     0xc0a608: stur            NULL, [x5, #0xb]
    // 0xc0a60c: r0 = Null
    //     0xc0a60c: mov             x0, NULL
    // 0xc0a610: LeaveFrame
    //     0xc0a610: mov             SP, fp
    //     0xc0a614: ldp             fp, lr, [SP], #0x10
    // 0xc0a618: ret
    //     0xc0a618: ret             
    // 0xc0a61c: ldr             x5, [fp, #0x10]
    // 0xc0a620: r0 = BoxInt64Instr(r4)
    //     0xc0a620: sbfiz           x0, x4, #1, #0x1f
    //     0xc0a624: cmp             x4, x0, asr #1
    //     0xc0a628: b.eq            #0xc0a634
    //     0xc0a62c: bl              #0xd69bb8
    //     0xc0a630: stur            x4, [x0, #7]
    // 0xc0a634: r1 = LoadClassIdInstr(r3)
    //     0xc0a634: ldur            x1, [x3, #-1]
    //     0xc0a638: ubfx            x1, x1, #0xc, #0x14
    // 0xc0a63c: stp             x0, x3, [SP, #-0x10]!
    // 0xc0a640: mov             x0, x1
    // 0xc0a644: r0 = GDT[cid_x0 + 0xd175]()
    //     0xc0a644: mov             x17, #0xd175
    //     0xc0a648: add             lr, x0, x17
    //     0xc0a64c: ldr             lr, [x21, lr, lsl #3]
    //     0xc0a650: blr             lr
    // 0xc0a654: add             SP, SP, #0x10
    // 0xc0a658: mov             x3, x0
    // 0xc0a65c: ldur            x0, [fp, #-0x10]
    // 0xc0a660: stur            x3, [fp, #-0x38]
    // 0xc0a664: add             x5, x0, #1
    // 0xc0a668: stur            x5, [fp, #-0x30]
    // 0xc0a66c: cmp             w3, NULL
    // 0xc0a670: b.ne            #0xc0a6a4
    // 0xc0a674: mov             x0, x3
    // 0xc0a678: ldur            x2, [fp, #-0x20]
    // 0xc0a67c: r1 = Null
    //     0xc0a67c: mov             x1, NULL
    // 0xc0a680: cmp             w2, NULL
    // 0xc0a684: b.eq            #0xc0a6a4
    // 0xc0a688: LoadField: r4 = r2->field_17
    //     0xc0a688: ldur            w4, [x2, #0x17]
    // 0xc0a68c: DecompressPointer r4
    //     0xc0a68c: add             x4, x4, HEAP, lsl #32
    // 0xc0a690: r8 = X0
    //     0xc0a690: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc0a694: LoadField: r9 = r4->field_7
    //     0xc0a694: ldur            x9, [x4, #7]
    // 0xc0a698: r3 = Null
    //     0xc0a698: add             x3, PP, #0x37, lsl #12  ; [pp+0x37bb0] Null
    //     0xc0a69c: ldr             x3, [x3, #0xbb0]
    // 0xc0a6a0: blr             x9
    // 0xc0a6a4: ldr             x2, [fp, #0x10]
    // 0xc0a6a8: ldur            x3, [fp, #-8]
    // 0xc0a6ac: ldur            x1, [fp, #-0x38]
    // 0xc0a6b0: LoadField: r4 = r2->field_17
    //     0xc0a6b0: ldur            w4, [x2, #0x17]
    // 0xc0a6b4: DecompressPointer r4
    //     0xc0a6b4: add             x4, x4, HEAP, lsl #32
    // 0xc0a6b8: stur            x4, [fp, #-0x40]
    // 0xc0a6bc: cmp             w4, NULL
    // 0xc0a6c0: b.eq            #0xc0a7a8
    // 0xc0a6c4: r0 = LoadClassIdInstr(r1)
    //     0xc0a6c4: ldur            x0, [x1, #-1]
    //     0xc0a6c8: ubfx            x0, x0, #0xc, #0x14
    // 0xc0a6cc: SaveReg r1
    //     0xc0a6cc: str             x1, [SP, #-8]!
    // 0xc0a6d0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc0a6d0: mov             x17, #0xb8ea
    //     0xc0a6d4: add             lr, x0, x17
    //     0xc0a6d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc0a6dc: blr             lr
    // 0xc0a6e0: add             SP, SP, #8
    // 0xc0a6e4: r1 = LoadInt32Instr(r0)
    //     0xc0a6e4: sbfx            x1, x0, #1, #0x1f
    //     0xc0a6e8: tbz             w0, #0, #0xc0a6f0
    //     0xc0a6ec: ldur            x1, [x0, #7]
    // 0xc0a6f0: ldur            x2, [fp, #-8]
    // 0xc0a6f4: add             x3, x2, x1
    // 0xc0a6f8: r0 = BoxInt64Instr(r2)
    //     0xc0a6f8: sbfiz           x0, x2, #1, #0x1f
    //     0xc0a6fc: cmp             x2, x0, asr #1
    //     0xc0a700: b.eq            #0xc0a70c
    //     0xc0a704: bl              #0xd69bb8
    //     0xc0a708: stur            x2, [x0, #7]
    // 0xc0a70c: ldur            x16, [fp, #-0x40]
    // 0xc0a710: stp             x0, x16, [SP, #-0x10]!
    // 0xc0a714: ldur            x16, [fp, #-0x38]
    // 0xc0a718: stp             x16, x3, [SP, #-0x10]!
    // 0xc0a71c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xc0a71c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xc0a720: r0 = setRange()
    //     0xc0a720: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0xc0a724: add             SP, SP, #0x20
    // 0xc0a728: ldur            x0, [fp, #-0x38]
    // 0xc0a72c: r1 = LoadClassIdInstr(r0)
    //     0xc0a72c: ldur            x1, [x0, #-1]
    //     0xc0a730: ubfx            x1, x1, #0xc, #0x14
    // 0xc0a734: SaveReg r0
    //     0xc0a734: str             x0, [SP, #-8]!
    // 0xc0a738: mov             x0, x1
    // 0xc0a73c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc0a73c: mov             x17, #0xb8ea
    //     0xc0a740: add             lr, x0, x17
    //     0xc0a744: ldr             lr, [x21, lr, lsl #3]
    //     0xc0a748: blr             lr
    // 0xc0a74c: add             SP, SP, #8
    // 0xc0a750: r1 = LoadInt32Instr(r0)
    //     0xc0a750: sbfx            x1, x0, #1, #0x1f
    //     0xc0a754: tbz             w0, #0, #0xc0a75c
    //     0xc0a758: ldur            x1, [x0, #7]
    // 0xc0a75c: ldur            x0, [fp, #-8]
    // 0xc0a760: add             x6, x0, x1
    // 0xc0a764: ldur            x5, [fp, #-0x30]
    // 0xc0a768: ldr             x1, [fp, #0x10]
    // 0xc0a76c: ldur            x2, [fp, #-0x28]
    // 0xc0a770: ldur            x3, [fp, #-0x20]
    // 0xc0a774: ldur            x4, [fp, #-0x18]
    // 0xc0a778: b               #0xc0a5a8
    // 0xc0a77c: ldur            x0, [fp, #-0x28]
    // 0xc0a780: r0 = ConcurrentModificationError()
    //     0xc0a780: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc0a784: ldur            x3, [fp, #-0x28]
    // 0xc0a788: StoreField: r0->field_b = r3
    //     0xc0a788: stur            w3, [x0, #0xb]
    // 0xc0a78c: r0 = Throw()
    //     0xc0a78c: bl              #0xd67e38  ; ThrowStub
    // 0xc0a790: brk             #0
    // 0xc0a794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a794: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a798: b               #0xc0a50c
    // 0xc0a79c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc0a79c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc0a7a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a7a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a7a4: b               #0xc0a5bc
    // 0xc0a7a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc0a7a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ add(/* No info */) {
    // ** addr: 0xc2f688, size: 0x178
    // 0xc2f688: EnterFrame
    //     0xc2f688: stp             fp, lr, [SP, #-0x10]!
    //     0xc2f68c: mov             fp, SP
    // 0xc2f690: AllocStack(0x18)
    //     0xc2f690: sub             SP, SP, #0x18
    // 0xc2f694: CheckStackOverflow
    //     0xc2f694: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2f698: cmp             SP, x16
    //     0xc2f69c: b.ls            #0xc2f7f0
    // 0xc2f6a0: ldr             x0, [fp, #0x10]
    // 0xc2f6a4: r2 = Null
    //     0xc2f6a4: mov             x2, NULL
    // 0xc2f6a8: r1 = Null
    //     0xc2f6a8: mov             x1, NULL
    // 0xc2f6ac: r8 = List<int>
    //     0xc2f6ac: ldr             x8, [PP, #0xa60]  ; [pp+0xa60] Type: List<int>
    // 0xc2f6b0: r3 = Null
    //     0xc2f6b0: add             x3, PP, #0x37, lsl #12  ; [pp+0x37bc0] Null
    //     0xc2f6b4: ldr             x3, [x3, #0xbc0]
    // 0xc2f6b8: r0 = List<int>()
    //     0xc2f6b8: bl              #0x4b2744  ; IsType_List<int>_Stub
    // 0xc2f6bc: ldr             x3, [fp, #0x18]
    // 0xc2f6c0: LoadField: r4 = r3->field_b
    //     0xc2f6c0: ldur            w4, [x3, #0xb]
    // 0xc2f6c4: DecompressPointer r4
    //     0xc2f6c4: add             x4, x4, HEAP, lsl #32
    // 0xc2f6c8: stur            x4, [fp, #-8]
    // 0xc2f6cc: cmp             w4, NULL
    // 0xc2f6d0: b.eq            #0xc2f7f8
    // 0xc2f6d4: LoadField: r2 = r4->field_7
    //     0xc2f6d4: ldur            w2, [x4, #7]
    // 0xc2f6d8: DecompressPointer r2
    //     0xc2f6d8: add             x2, x2, HEAP, lsl #32
    // 0xc2f6dc: ldr             x0, [fp, #0x10]
    // 0xc2f6e0: r1 = Null
    //     0xc2f6e0: mov             x1, NULL
    // 0xc2f6e4: cmp             w2, NULL
    // 0xc2f6e8: b.eq            #0xc2f708
    // 0xc2f6ec: LoadField: r4 = r2->field_17
    //     0xc2f6ec: ldur            w4, [x2, #0x17]
    // 0xc2f6f0: DecompressPointer r4
    //     0xc2f6f0: add             x4, x4, HEAP, lsl #32
    // 0xc2f6f4: r8 = X0
    //     0xc2f6f4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc2f6f8: LoadField: r9 = r4->field_7
    //     0xc2f6f8: ldur            x9, [x4, #7]
    // 0xc2f6fc: r3 = Null
    //     0xc2f6fc: add             x3, PP, #0x37, lsl #12  ; [pp+0x37bd0] Null
    //     0xc2f700: ldr             x3, [x3, #0xbd0]
    // 0xc2f704: blr             x9
    // 0xc2f708: ldur            x0, [fp, #-8]
    // 0xc2f70c: LoadField: r1 = r0->field_b
    //     0xc2f70c: ldur            w1, [x0, #0xb]
    // 0xc2f710: DecompressPointer r1
    //     0xc2f710: add             x1, x1, HEAP, lsl #32
    // 0xc2f714: stur            x1, [fp, #-0x10]
    // 0xc2f718: LoadField: r2 = r0->field_f
    //     0xc2f718: ldur            w2, [x0, #0xf]
    // 0xc2f71c: DecompressPointer r2
    //     0xc2f71c: add             x2, x2, HEAP, lsl #32
    // 0xc2f720: LoadField: r3 = r2->field_b
    //     0xc2f720: ldur            w3, [x2, #0xb]
    // 0xc2f724: DecompressPointer r3
    //     0xc2f724: add             x3, x3, HEAP, lsl #32
    // 0xc2f728: cmp             w1, w3
    // 0xc2f72c: b.ne            #0xc2f73c
    // 0xc2f730: SaveReg r0
    //     0xc2f730: str             x0, [SP, #-8]!
    // 0xc2f734: r0 = _growToNextCapacity()
    //     0xc2f734: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc2f738: add             SP, SP, #8
    // 0xc2f73c: ldr             x3, [fp, #0x18]
    // 0xc2f740: ldr             x4, [fp, #0x10]
    // 0xc2f744: ldur            x2, [fp, #-8]
    // 0xc2f748: ldur            x0, [fp, #-0x10]
    // 0xc2f74c: r5 = LoadInt32Instr(r0)
    //     0xc2f74c: sbfx            x5, x0, #1, #0x1f
    // 0xc2f750: add             x0, x5, #1
    // 0xc2f754: lsl             x1, x0, #1
    // 0xc2f758: StoreField: r2->field_b = r1
    //     0xc2f758: stur            w1, [x2, #0xb]
    // 0xc2f75c: mov             x1, x5
    // 0xc2f760: cmp             x1, x0
    // 0xc2f764: b.hs            #0xc2f7fc
    // 0xc2f768: LoadField: r1 = r2->field_f
    //     0xc2f768: ldur            w1, [x2, #0xf]
    // 0xc2f76c: DecompressPointer r1
    //     0xc2f76c: add             x1, x1, HEAP, lsl #32
    // 0xc2f770: mov             x0, x4
    // 0xc2f774: ArrayStore: r1[r5] = r0  ; List_4
    //     0xc2f774: add             x25, x1, x5, lsl #2
    //     0xc2f778: add             x25, x25, #0xf
    //     0xc2f77c: str             w0, [x25]
    //     0xc2f780: tbz             w0, #0, #0xc2f79c
    //     0xc2f784: ldurb           w16, [x1, #-1]
    //     0xc2f788: ldurb           w17, [x0, #-1]
    //     0xc2f78c: and             x16, x17, x16, lsr #2
    //     0xc2f790: tst             x16, HEAP, lsr #32
    //     0xc2f794: b.eq            #0xc2f79c
    //     0xc2f798: bl              #0xd67e5c
    // 0xc2f79c: LoadField: r1 = r3->field_f
    //     0xc2f79c: ldur            x1, [x3, #0xf]
    // 0xc2f7a0: stur            x1, [fp, #-0x18]
    // 0xc2f7a4: r0 = LoadClassIdInstr(r4)
    //     0xc2f7a4: ldur            x0, [x4, #-1]
    //     0xc2f7a8: ubfx            x0, x0, #0xc, #0x14
    // 0xc2f7ac: SaveReg r4
    //     0xc2f7ac: str             x4, [SP, #-8]!
    // 0xc2f7b0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc2f7b0: mov             x17, #0xb8ea
    //     0xc2f7b4: add             lr, x0, x17
    //     0xc2f7b8: ldr             lr, [x21, lr, lsl #3]
    //     0xc2f7bc: blr             lr
    // 0xc2f7c0: add             SP, SP, #8
    // 0xc2f7c4: r1 = LoadInt32Instr(r0)
    //     0xc2f7c4: sbfx            x1, x0, #1, #0x1f
    //     0xc2f7c8: tbz             w0, #0, #0xc2f7d0
    //     0xc2f7cc: ldur            x1, [x0, #7]
    // 0xc2f7d0: ldur            x2, [fp, #-0x18]
    // 0xc2f7d4: add             x3, x2, x1
    // 0xc2f7d8: ldr             x1, [fp, #0x18]
    // 0xc2f7dc: StoreField: r1->field_f = r3
    //     0xc2f7dc: stur            x3, [x1, #0xf]
    // 0xc2f7e0: r0 = Null
    //     0xc2f7e0: mov             x0, NULL
    // 0xc2f7e4: LeaveFrame
    //     0xc2f7e4: mov             SP, fp
    //     0xc2f7e8: ldp             fp, lr, [SP], #0x10
    // 0xc2f7ec: ret
    //     0xc2f7ec: ret             
    // 0xc2f7f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2f7f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2f7f4: b               #0xc2f6a0
    // 0xc2f7f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc2f7f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc2f7fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc2f7fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

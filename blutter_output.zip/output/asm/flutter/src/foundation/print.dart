// lib: , url: package:flutter/src/foundation/print.dart

// class id: 1049143, size: 0x8
class :: {

  static late (dynamic, String?, {int? wrapWidth}) => void debugPrint; // offset: 0xd2c
  static late final Queue<String> _debugPrintBuffer; // offset: 0xd34
  static late final RegExp _indentPattern; // offset: 0xd44
  static late final Stopwatch _debugPrintStopwatch; // offset: 0xd38

  static (dynamic, String?, {int? wrapWidth}) => void debugPrint() {
    // ** addr: 0x4ff454, size: 0x8
    // 0x4ff454: r0 = Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static.
    //     0x4ff454: ldr             x0, [PP, #0x1700]  ; [pp+0x1700] Closure: (String?, {int? wrapWidth}) => void from Function 'debugPrintThrottled': static. (0x7fe6e1cff45c)
    // 0x4ff458: ret
    //     0x4ff458: ret             
  }
  [closure] static void debugPrintThrottled(dynamic, String?, {int? wrapWidth}) {
    // ** addr: 0x4ff45c, size: 0x84
    // 0x4ff45c: EnterFrame
    //     0x4ff45c: stp             fp, lr, [SP, #-0x10]!
    //     0x4ff460: mov             fp, SP
    // 0x4ff464: mov             x0, x4
    // 0x4ff468: LoadField: r1 = r0->field_13
    //     0x4ff468: ldur            w1, [x0, #0x13]
    // 0x4ff46c: DecompressPointer r1
    //     0x4ff46c: add             x1, x1, HEAP, lsl #32
    // 0x4ff470: sub             x2, x1, #4
    // 0x4ff474: add             x3, fp, w2, sxtw #2
    // 0x4ff478: ldr             x3, [x3, #0x10]
    // 0x4ff47c: LoadField: r2 = r0->field_1f
    //     0x4ff47c: ldur            w2, [x0, #0x1f]
    // 0x4ff480: DecompressPointer r2
    //     0x4ff480: add             x2, x2, HEAP, lsl #32
    // 0x4ff484: r16 = "wrapWidth"
    //     0x4ff484: ldr             x16, [PP, #0x1708]  ; [pp+0x1708] "wrapWidth"
    // 0x4ff488: cmp             w2, w16
    // 0x4ff48c: b.ne            #0x4ff4ac
    // 0x4ff490: LoadField: r2 = r0->field_23
    //     0x4ff490: ldur            w2, [x0, #0x23]
    // 0x4ff494: DecompressPointer r2
    //     0x4ff494: add             x2, x2, HEAP, lsl #32
    // 0x4ff498: sub             w0, w1, w2
    // 0x4ff49c: add             x1, fp, w0, sxtw #2
    // 0x4ff4a0: ldr             x1, [x1, #8]
    // 0x4ff4a4: mov             x0, x1
    // 0x4ff4a8: b               #0x4ff4b0
    // 0x4ff4ac: r0 = Null
    //     0x4ff4ac: mov             x0, NULL
    // 0x4ff4b0: CheckStackOverflow
    //     0x4ff4b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ff4b4: cmp             SP, x16
    //     0x4ff4b8: b.ls            #0x4ff4d8
    // 0x4ff4bc: stp             x0, x3, [SP, #-0x10]!
    // 0x4ff4c0: r4 = const [0, 0x2, 0x2, 0x1, wrapWidth, 0x1, null]
    //     0x4ff4c0: ldr             x4, [PP, #0x1710]  ; [pp+0x1710] List(7) [0, 0x2, 0x2, 0x1, "wrapWidth", 0x1, Null]
    // 0x4ff4c4: r0 = debugPrintThrottled()
    //     0x4ff4c4: bl              #0x4ff4e0  ; [package:flutter/src/foundation/print.dart] ::debugPrintThrottled
    // 0x4ff4c8: add             SP, SP, #0x10
    // 0x4ff4cc: LeaveFrame
    //     0x4ff4cc: mov             SP, fp
    //     0x4ff4d0: ldp             fp, lr, [SP], #0x10
    // 0x4ff4d4: ret
    //     0x4ff4d4: ret             
    // 0x4ff4d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ff4d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ff4dc: b               #0x4ff4bc
  }
  static _ debugPrintThrottled(/* No info */) {
    // ** addr: 0x4ff4e0, size: 0x1c8
    // 0x4ff4e0: EnterFrame
    //     0x4ff4e0: stp             fp, lr, [SP, #-0x10]!
    //     0x4ff4e4: mov             fp, SP
    // 0x4ff4e8: AllocStack(0x18)
    //     0x4ff4e8: sub             SP, SP, #0x18
    // 0x4ff4ec: SetupParameters(dynamic _ /* r3, fp-0x10 */, {dynamic wrapWidth = Null /* r0, fp-0x8 */})
    //     0x4ff4ec: mov             x0, x4
    //     0x4ff4f0: ldur            w1, [x0, #0x13]
    //     0x4ff4f4: add             x1, x1, HEAP, lsl #32
    //     0x4ff4f8: sub             x2, x1, #2
    //     0x4ff4fc: add             x3, fp, w2, sxtw #2
    //     0x4ff500: ldr             x3, [x3, #0x10]
    //     0x4ff504: stur            x3, [fp, #-0x10]
    //     0x4ff508: ldur            w2, [x0, #0x1f]
    //     0x4ff50c: add             x2, x2, HEAP, lsl #32
    //     0x4ff510: ldr             x16, [PP, #0x1708]  ; [pp+0x1708] "wrapWidth"
    //     0x4ff514: cmp             w2, w16
    //     0x4ff518: b.ne            #0x4ff538
    //     0x4ff51c: ldur            w2, [x0, #0x23]
    //     0x4ff520: add             x2, x2, HEAP, lsl #32
    //     0x4ff524: sub             w0, w1, w2
    //     0x4ff528: add             x1, fp, w0, sxtw #2
    //     0x4ff52c: ldr             x1, [x1, #8]
    //     0x4ff530: mov             x0, x1
    //     0x4ff534: b               #0x4ff53c
    //     0x4ff538: mov             x0, NULL
    //     0x4ff53c: stur            x0, [fp, #-8]
    // 0x4ff540: CheckStackOverflow
    //     0x4ff540: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ff544: cmp             SP, x16
    //     0x4ff548: b.ls            #0x4ff6a0
    // 0x4ff54c: r1 = 1
    //     0x4ff54c: mov             x1, #1
    // 0x4ff550: r0 = AllocateContext()
    //     0x4ff550: bl              #0xd68aa4  ; AllocateContextStub
    // 0x4ff554: mov             x1, x0
    // 0x4ff558: ldur            x0, [fp, #-8]
    // 0x4ff55c: stur            x1, [fp, #-0x18]
    // 0x4ff560: StoreField: r1->field_f = r0
    //     0x4ff560: stur            w0, [x1, #0xf]
    // 0x4ff564: ldur            x0, [fp, #-0x10]
    // 0x4ff568: cmp             w0, NULL
    // 0x4ff56c: b.ne            #0x4ff578
    // 0x4ff570: r0 = Null
    //     0x4ff570: mov             x0, NULL
    // 0x4ff574: b               #0x4ff59c
    // 0x4ff578: r2 = LoadClassIdInstr(r0)
    //     0x4ff578: ldur            x2, [x0, #-1]
    //     0x4ff57c: ubfx            x2, x2, #0xc, #0x14
    // 0x4ff580: r16 = "\n"
    //     0x4ff580: ldr             x16, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x4ff584: stp             x16, x0, [SP, #-0x10]!
    // 0x4ff588: mov             x0, x2
    // 0x4ff58c: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4ff58c: sub             lr, x0, #0xff8
    //     0x4ff590: ldr             lr, [x21, lr, lsl #3]
    //     0x4ff594: blr             lr
    // 0x4ff598: add             SP, SP, #0x10
    // 0x4ff59c: cmp             w0, NULL
    // 0x4ff5a0: b.ne            #0x4ff5e0
    // 0x4ff5a4: r0 = 2
    //     0x4ff5a4: mov             x0, #2
    // 0x4ff5a8: mov             x2, x0
    // 0x4ff5ac: r1 = Null
    //     0x4ff5ac: mov             x1, NULL
    // 0x4ff5b0: r0 = AllocateArray()
    //     0x4ff5b0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4ff5b4: stur            x0, [fp, #-8]
    // 0x4ff5b8: r17 = "null"
    //     0x4ff5b8: ldr             x17, [PP, #0x1718]  ; [pp+0x1718] "null"
    // 0x4ff5bc: StoreField: r0->field_f = r17
    //     0x4ff5bc: stur            w17, [x0, #0xf]
    // 0x4ff5c0: r1 = <String>
    //     0x4ff5c0: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x4ff5c4: r0 = AllocateGrowableArray()
    //     0x4ff5c4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x4ff5c8: mov             x1, x0
    // 0x4ff5cc: ldur            x0, [fp, #-8]
    // 0x4ff5d0: StoreField: r1->field_f = r0
    //     0x4ff5d0: stur            w0, [x1, #0xf]
    // 0x4ff5d4: r0 = 2
    //     0x4ff5d4: mov             x0, #2
    // 0x4ff5d8: StoreField: r1->field_b = r0
    //     0x4ff5d8: stur            w0, [x1, #0xb]
    // 0x4ff5dc: mov             x0, x1
    // 0x4ff5e0: ldur            x2, [fp, #-0x18]
    // 0x4ff5e4: stur            x0, [fp, #-8]
    // 0x4ff5e8: LoadField: r1 = r2->field_f
    //     0x4ff5e8: ldur            w1, [x2, #0xf]
    // 0x4ff5ec: DecompressPointer r1
    //     0x4ff5ec: add             x1, x1, HEAP, lsl #32
    // 0x4ff5f0: cmp             w1, NULL
    // 0x4ff5f4: b.eq            #0x4ff654
    // 0x4ff5f8: r0 = InitLateStaticField(0xd34) // [package:flutter/src/foundation/print.dart] ::_debugPrintBuffer
    //     0x4ff5f8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff5fc: ldr             x0, [x0, #0x1a68]
    //     0x4ff600: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4ff604: cmp             w0, w16
    //     0x4ff608: b.ne            #0x4ff614
    //     0x4ff60c: ldr             x2, [PP, #0x1720]  ; [pp+0x1720] Field <::._debugPrintBuffer@646110992>: static late final (offset: 0xd34)
    //     0x4ff610: bl              #0xd67cdc
    // 0x4ff614: ldur            x2, [fp, #-0x18]
    // 0x4ff618: r1 = Function '<anonymous closure>': static.
    //     0x4ff618: ldr             x1, [PP, #0x1728]  ; [pp+0x1728] AnonymousClosure: static (0x50053c), in [package:flutter/src/foundation/print.dart] ::debugPrintThrottled (0x4ff4e0)
    // 0x4ff61c: stur            x0, [fp, #-0x10]
    // 0x4ff620: r0 = AllocateClosure()
    //     0x4ff620: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x4ff624: r16 = <String>
    //     0x4ff624: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x4ff628: ldur            lr, [fp, #-8]
    // 0x4ff62c: stp             lr, x16, [SP, #-0x10]!
    // 0x4ff630: SaveReg r0
    //     0x4ff630: str             x0, [SP, #-8]!
    // 0x4ff634: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x4ff634: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x4ff638: r0 = expand()
    //     0x4ff638: bl              #0x5004a4  ; [dart:core] Iterable::expand
    // 0x4ff63c: add             SP, SP, #0x18
    // 0x4ff640: ldur            x16, [fp, #-0x10]
    // 0x4ff644: stp             x0, x16, [SP, #-0x10]!
    // 0x4ff648: r0 = addAll()
    //     0x4ff648: bl              #0x4fff08  ; [dart:collection] ListQueue::addAll
    // 0x4ff64c: add             SP, SP, #0x10
    // 0x4ff650: b               #0x4ff680
    // 0x4ff654: r0 = InitLateStaticField(0xd34) // [package:flutter/src/foundation/print.dart] ::_debugPrintBuffer
    //     0x4ff654: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff658: ldr             x0, [x0, #0x1a68]
    //     0x4ff65c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4ff660: cmp             w0, w16
    //     0x4ff664: b.ne            #0x4ff670
    //     0x4ff668: ldr             x2, [PP, #0x1720]  ; [pp+0x1720] Field <::._debugPrintBuffer@646110992>: static late final (offset: 0xd34)
    //     0x4ff66c: bl              #0xd67cdc
    // 0x4ff670: ldur            x16, [fp, #-8]
    // 0x4ff674: stp             x16, x0, [SP, #-0x10]!
    // 0x4ff678: r0 = addAll()
    //     0x4ff678: bl              #0x4fff08  ; [dart:collection] ListQueue::addAll
    // 0x4ff67c: add             SP, SP, #0x10
    // 0x4ff680: r0 = LoadStaticField(0xd40)
    //     0x4ff680: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff684: ldr             x0, [x0, #0x1a80]
    // 0x4ff688: tbz             w0, #4, #0x4ff690
    // 0x4ff68c: r0 = _debugPrintTask()
    //     0x4ff68c: bl              #0x4ff6a8  ; [package:flutter/src/foundation/print.dart] ::_debugPrintTask
    // 0x4ff690: r0 = Null
    //     0x4ff690: mov             x0, NULL
    // 0x4ff694: LeaveFrame
    //     0x4ff694: mov             SP, fp
    //     0x4ff698: ldp             fp, lr, [SP], #0x10
    // 0x4ff69c: ret
    //     0x4ff69c: ret             
    // 0x4ff6a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ff6a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ff6a4: b               #0x4ff54c
  }
  static void _debugPrintTask() {
    // ** addr: 0x4ff6a8, size: 0x284
    // 0x4ff6a8: EnterFrame
    //     0x4ff6a8: stp             fp, lr, [SP, #-0x10]!
    //     0x4ff6ac: mov             fp, SP
    // 0x4ff6b0: AllocStack(0x10)
    //     0x4ff6b0: sub             SP, SP, #0x10
    // 0x4ff6b4: r0 = false
    //     0x4ff6b4: add             x0, NULL, #0x30  ; false
    // 0x4ff6b8: CheckStackOverflow
    //     0x4ff6b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ff6bc: cmp             SP, x16
    //     0x4ff6c0: b.ls            #0x4ff91c
    // 0x4ff6c4: StoreStaticField(0xd40, r0)
    //     0x4ff6c4: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff6c8: str             x0, [x1, #0x1a80]
    // 0x4ff6cc: r0 = InitLateStaticField(0xd38) // [package:flutter/src/foundation/print.dart] ::_debugPrintStopwatch
    //     0x4ff6cc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff6d0: ldr             x0, [x0, #0x1a70]
    //     0x4ff6d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4ff6d8: cmp             w0, w16
    //     0x4ff6dc: b.ne            #0x4ff6e8
    //     0x4ff6e0: ldr             x2, [PP, #0x1780]  ; [pp+0x1780] Field <::._debugPrintStopwatch@646110992>: static late final (offset: 0xd38)
    //     0x4ff6e4: bl              #0xd67cdc
    // 0x4ff6e8: stur            x0, [fp, #-8]
    // 0x4ff6ec: SaveReg r0
    //     0x4ff6ec: str             x0, [SP, #-8]!
    // 0x4ff6f0: r0 = elapsed()
    //     0x4ff6f0: bl              #0x4ffbc8  ; [dart:core] Stopwatch::elapsed
    // 0x4ff6f4: add             SP, SP, #8
    // 0x4ff6f8: LoadField: r1 = r0->field_7
    //     0x4ff6f8: ldur            x1, [x0, #7]
    // 0x4ff6fc: r17 = 1000000
    //     0x4ff6fc: mov             x17, #0x4240
    //     0x4ff700: movk            x17, #0xf, lsl #16
    // 0x4ff704: cmp             x1, x17
    // 0x4ff708: b.le            #0x4ff73c
    // 0x4ff70c: ldur            x16, [fp, #-8]
    // 0x4ff710: SaveReg r16
    //     0x4ff710: str             x16, [SP, #-8]!
    // 0x4ff714: r0 = stop()
    //     0x4ff714: bl              #0x4ffb60  ; [dart:core] Stopwatch::stop
    // 0x4ff718: add             SP, SP, #8
    // 0x4ff71c: ldur            x16, [fp, #-8]
    // 0x4ff720: SaveReg r16
    //     0x4ff720: str             x16, [SP, #-8]!
    // 0x4ff724: r0 = reset()
    //     0x4ff724: bl              #0x4ffaf8  ; [dart:core] Stopwatch::reset
    // 0x4ff728: add             SP, SP, #8
    // 0x4ff72c: r0 = 0
    //     0x4ff72c: mov             x0, #0
    // 0x4ff730: StoreStaticField(0xd30, r0)
    //     0x4ff730: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff734: str             x0, [x1, #0x1a60]
    // 0x4ff738: b               #0x4ff740
    // 0x4ff73c: r0 = 0
    //     0x4ff73c: mov             x0, #0
    // 0x4ff740: CheckStackOverflow
    //     0x4ff740: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ff744: cmp             SP, x16
    //     0x4ff748: b.ls            #0x4ff924
    // 0x4ff74c: r1 = LoadStaticField(0xd30)
    //     0x4ff74c: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff750: ldr             x1, [x1, #0x1a60]
    // 0x4ff754: r2 = LoadInt32Instr(r1)
    //     0x4ff754: sbfx            x2, x1, #1, #0x1f
    //     0x4ff758: tbz             w1, #0, #0x4ff760
    //     0x4ff75c: ldur            x2, [x1, #7]
    // 0x4ff760: cmp             x2, #3, lsl #12
    // 0x4ff764: b.ge            #0x4ff804
    // 0x4ff768: r0 = InitLateStaticField(0xd34) // [package:flutter/src/foundation/print.dart] ::_debugPrintBuffer
    //     0x4ff768: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff76c: ldr             x0, [x0, #0x1a68]
    //     0x4ff770: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4ff774: cmp             w0, w16
    //     0x4ff778: b.ne            #0x4ff784
    //     0x4ff77c: ldr             x2, [PP, #0x1720]  ; [pp+0x1720] Field <::._debugPrintBuffer@646110992>: static late final (offset: 0xd34)
    //     0x4ff780: bl              #0xd67cdc
    // 0x4ff784: LoadField: r1 = r0->field_f
    //     0x4ff784: ldur            x1, [x0, #0xf]
    // 0x4ff788: LoadField: r2 = r0->field_17
    //     0x4ff788: ldur            x2, [x0, #0x17]
    // 0x4ff78c: cmp             x1, x2
    // 0x4ff790: b.eq            #0x4ff804
    // 0x4ff794: SaveReg r0
    //     0x4ff794: str             x0, [SP, #-8]!
    // 0x4ff798: r0 = removeFirst()
    //     0x4ff798: bl              #0x4ebdd0  ; [dart:collection] ListQueue::removeFirst
    // 0x4ff79c: add             SP, SP, #8
    // 0x4ff7a0: mov             x2, x0
    // 0x4ff7a4: r0 = LoadStaticField(0xd30)
    //     0x4ff7a4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff7a8: ldr             x0, [x0, #0x1a60]
    // 0x4ff7ac: LoadField: r1 = r2->field_7
    //     0x4ff7ac: ldur            w1, [x2, #7]
    // 0x4ff7b0: DecompressPointer r1
    //     0x4ff7b0: add             x1, x1, HEAP, lsl #32
    // 0x4ff7b4: r3 = LoadInt32Instr(r0)
    //     0x4ff7b4: sbfx            x3, x0, #1, #0x1f
    //     0x4ff7b8: tbz             w0, #0, #0x4ff7c0
    //     0x4ff7bc: ldur            x3, [x0, #7]
    // 0x4ff7c0: r0 = LoadInt32Instr(r1)
    //     0x4ff7c0: sbfx            x0, x1, #1, #0x1f
    // 0x4ff7c4: add             x4, x3, x0
    // 0x4ff7c8: r0 = BoxInt64Instr(r4)
    //     0x4ff7c8: sbfiz           x0, x4, #1, #0x1f
    //     0x4ff7cc: cmp             x4, x0, asr #1
    //     0x4ff7d0: b.eq            #0x4ff7dc
    //     0x4ff7d4: bl              #0xd69bb8
    //     0x4ff7d8: stur            x4, [x0, #7]
    // 0x4ff7dc: StoreStaticField(0xd30, r0)
    //     0x4ff7dc: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff7e0: str             x0, [x1, #0x1a60]
    // 0x4ff7e4: SaveReg r2
    //     0x4ff7e4: str             x2, [SP, #-8]!
    // 0x4ff7e8: r0 = _interpolateSingle()
    //     0x4ff7e8: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0x4ff7ec: add             SP, SP, #8
    // 0x4ff7f0: SaveReg r0
    //     0x4ff7f0: str             x0, [SP, #-8]!
    // 0x4ff7f4: r0 = printToConsole()
    //     0x4ff7f4: bl              #0x4ffa98  ; [dart:_internal] ::printToConsole
    // 0x4ff7f8: add             SP, SP, #8
    // 0x4ff7fc: r0 = 0
    //     0x4ff7fc: mov             x0, #0
    // 0x4ff800: b               #0x4ff740
    // 0x4ff804: r0 = InitLateStaticField(0xd34) // [package:flutter/src/foundation/print.dart] ::_debugPrintBuffer
    //     0x4ff804: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff808: ldr             x0, [x0, #0x1a68]
    //     0x4ff80c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4ff810: cmp             w0, w16
    //     0x4ff814: b.ne            #0x4ff820
    //     0x4ff818: ldr             x2, [PP, #0x1720]  ; [pp+0x1720] Field <::._debugPrintBuffer@646110992>: static late final (offset: 0xd34)
    //     0x4ff81c: bl              #0xd67cdc
    // 0x4ff820: LoadField: r1 = r0->field_f
    //     0x4ff820: ldur            x1, [x0, #0xf]
    // 0x4ff824: LoadField: r2 = r0->field_17
    //     0x4ff824: ldur            x2, [x0, #0x17]
    // 0x4ff828: cmp             x1, x2
    // 0x4ff82c: b.eq            #0x4ff8d4
    // 0x4ff830: r1 = true
    //     0x4ff830: add             x1, NULL, #0x20  ; true
    // 0x4ff834: r0 = 0
    //     0x4ff834: mov             x0, #0
    // 0x4ff838: StoreStaticField(0xd40, r1)
    //     0x4ff838: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff83c: str             x1, [x2, #0x1a80]
    // 0x4ff840: StoreStaticField(0xd30, r0)
    //     0x4ff840: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff844: str             x0, [x1, #0x1a60]
    // 0x4ff848: r16 = Instance_Duration
    //     0x4ff848: ldr             x16, [PP, #0x1788]  ; [pp+0x1788] Obj!Duration@b67a21
    // 0x4ff84c: stp             x16, NULL, [SP, #-0x10]!
    // 0x4ff850: r16 = Closure: () => void from Function '_debugPrintTask@646110992': static.
    //     0x4ff850: ldr             x16, [PP, #0x1790]  ; [pp+0x1790] Closure: () => void from Function '_debugPrintTask@646110992': static. (0x7fe6e1cff974)
    // 0x4ff854: SaveReg r16
    //     0x4ff854: str             x16, [SP, #-8]!
    // 0x4ff858: r0 = Timer()
    //     0x4ff858: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x4ff85c: add             SP, SP, #0x18
    // 0x4ff860: r0 = LoadStaticField(0xd3c)
    //     0x4ff860: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff864: ldr             x0, [x0, #0x1a78]
    // 0x4ff868: cmp             w0, NULL
    // 0x4ff86c: b.ne            #0x4ff8cc
    // 0x4ff870: r1 = <void?>
    //     0x4ff870: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x4ff874: r0 = _Future()
    //     0x4ff874: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x4ff878: mov             x1, x0
    // 0x4ff87c: r0 = 0
    //     0x4ff87c: mov             x0, #0
    // 0x4ff880: stur            x1, [fp, #-0x10]
    // 0x4ff884: StoreField: r1->field_b = r0
    //     0x4ff884: stur            x0, [x1, #0xb]
    // 0x4ff888: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x4ff888: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff88c: ldr             x0, [x0, #0xb58]
    //     0x4ff890: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4ff894: cmp             w0, w16
    //     0x4ff898: b.ne            #0x4ff8a4
    //     0x4ff89c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x4ff8a0: bl              #0xd67d44
    // 0x4ff8a4: mov             x1, x0
    // 0x4ff8a8: ldur            x0, [fp, #-0x10]
    // 0x4ff8ac: StoreField: r0->field_13 = r1
    //     0x4ff8ac: stur            w1, [x0, #0x13]
    // 0x4ff8b0: r1 = <void?>
    //     0x4ff8b0: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x4ff8b4: r0 = _AsyncCompleter()
    //     0x4ff8b4: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x4ff8b8: mov             x1, x0
    // 0x4ff8bc: ldur            x0, [fp, #-0x10]
    // 0x4ff8c0: StoreField: r1->field_b = r0
    //     0x4ff8c0: stur            w0, [x1, #0xb]
    // 0x4ff8c4: StoreStaticField(0xd3c, r1)
    //     0x4ff8c4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff8c8: str             x1, [x0, #0x1a78]
    // 0x4ff8cc: r0 = Null
    //     0x4ff8cc: mov             x0, NULL
    // 0x4ff8d0: b               #0x4ff910
    // 0x4ff8d4: ldur            x16, [fp, #-8]
    // 0x4ff8d8: SaveReg r16
    //     0x4ff8d8: str             x16, [SP, #-8]!
    // 0x4ff8dc: r0 = start()
    //     0x4ff8dc: bl              #0x4ff9a0  ; [dart:core] Stopwatch::start
    // 0x4ff8e0: add             SP, SP, #8
    // 0x4ff8e4: r0 = LoadStaticField(0xd3c)
    //     0x4ff8e4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff8e8: ldr             x0, [x0, #0x1a78]
    // 0x4ff8ec: cmp             w0, NULL
    // 0x4ff8f0: b.eq            #0x4ff904
    // 0x4ff8f4: SaveReg r0
    //     0x4ff8f4: str             x0, [SP, #-8]!
    // 0x4ff8f8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4ff8f8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4ff8fc: r0 = complete()
    //     0x4ff8fc: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x4ff900: add             SP, SP, #8
    // 0x4ff904: r0 = Null
    //     0x4ff904: mov             x0, NULL
    // 0x4ff908: StoreStaticField(0xd3c, r0)
    //     0x4ff908: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff90c: str             x0, [x1, #0x1a78]
    // 0x4ff910: LeaveFrame
    //     0x4ff910: mov             SP, fp
    //     0x4ff914: ldp             fp, lr, [SP], #0x10
    // 0x4ff918: ret
    //     0x4ff918: ret             
    // 0x4ff91c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ff91c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ff920: b               #0x4ff6c4
    // 0x4ff924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ff924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ff928: b               #0x4ff74c
  }
  [closure] static void _debugPrintTask(dynamic) {
    // ** addr: 0x4ff974, size: 0x2c
    // 0x4ff974: EnterFrame
    //     0x4ff974: stp             fp, lr, [SP, #-0x10]!
    //     0x4ff978: mov             fp, SP
    // 0x4ff97c: CheckStackOverflow
    //     0x4ff97c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ff980: cmp             SP, x16
    //     0x4ff984: b.ls            #0x4ff998
    // 0x4ff988: r0 = _debugPrintTask()
    //     0x4ff988: bl              #0x4ff6a8  ; [package:flutter/src/foundation/print.dart] ::_debugPrintTask
    // 0x4ff98c: LeaveFrame
    //     0x4ff98c: mov             SP, fp
    //     0x4ff990: ldp             fp, lr, [SP], #0x10
    // 0x4ff994: ret
    //     0x4ff994: ret             
    // 0x4ff998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ff998: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ff99c: b               #0x4ff988
  }
  static Stopwatch _debugPrintStopwatch() {
    // ** addr: 0x4ffe98, size: 0x64
    // 0x4ffe98: EnterFrame
    //     0x4ffe98: stp             fp, lr, [SP, #-0x10]!
    //     0x4ffe9c: mov             fp, SP
    // 0x4ffea0: AllocStack(0x8)
    //     0x4ffea0: sub             SP, SP, #8
    // 0x4ffea4: CheckStackOverflow
    //     0x4ffea4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ffea8: cmp             SP, x16
    //     0x4ffeac: b.ls            #0x4ffef4
    // 0x4ffeb0: r0 = Stopwatch()
    //     0x4ffeb0: bl              #0x4ffefc  ; AllocateStopwatchStub -> Stopwatch (size=0x14)
    // 0x4ffeb4: mov             x1, x0
    // 0x4ffeb8: r0 = 0
    //     0x4ffeb8: mov             x0, #0
    // 0x4ffebc: stur            x1, [fp, #-8]
    // 0x4ffec0: StoreField: r1->field_7 = r0
    //     0x4ffec0: stur            x0, [x1, #7]
    // 0x4ffec4: StoreField: r1->field_f = rZR
    //     0x4ffec4: stur            wzr, [x1, #0xf]
    // 0x4ffec8: r0 = InitLateStaticField(0x570) // [dart:core] Stopwatch::_frequency
    //     0x4ffec8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ffecc: ldr             x0, [x0, #0xae0]
    //     0x4ffed0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4ffed4: cmp             w0, w16
    //     0x4ffed8: b.ne            #0x4ffee4
    //     0x4ffedc: ldr             x2, [PP, #0x1b58]  ; [pp+0x1b58] Field <Stopwatch._frequency@0150898>: static late final (offset: 0x570)
    //     0x4ffee0: bl              #0xd67cdc
    // 0x4ffee4: ldur            x0, [fp, #-8]
    // 0x4ffee8: LeaveFrame
    //     0x4ffee8: mov             SP, fp
    //     0x4ffeec: ldp             fp, lr, [SP], #0x10
    // 0x4ffef0: ret
    //     0x4ffef0: ret             
    // 0x4ffef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ffef4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ffef8: b               #0x4ffeb0
  }
  [closure] static Iterable<String> <anonymous closure>(dynamic, String) {
    // ** addr: 0x50053c, size: 0x4c
    // 0x50053c: EnterFrame
    //     0x50053c: stp             fp, lr, [SP, #-0x10]!
    //     0x500540: mov             fp, SP
    // 0x500544: ldr             x0, [fp, #0x18]
    // 0x500548: LoadField: r1 = r0->field_17
    //     0x500548: ldur            w1, [x0, #0x17]
    // 0x50054c: DecompressPointer r1
    //     0x50054c: add             x1, x1, HEAP, lsl #32
    // 0x500550: CheckStackOverflow
    //     0x500550: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500554: cmp             SP, x16
    //     0x500558: b.ls            #0x500580
    // 0x50055c: LoadField: r0 = r1->field_f
    //     0x50055c: ldur            w0, [x1, #0xf]
    // 0x500560: DecompressPointer r0
    //     0x500560: add             x0, x0, HEAP, lsl #32
    // 0x500564: ldr             x16, [fp, #0x10]
    // 0x500568: stp             x0, x16, [SP, #-0x10]!
    // 0x50056c: r0 = debugWordWrap()
    //     0x50056c: bl              #0x500588  ; [package:flutter/src/foundation/print.dart] ::debugWordWrap
    // 0x500570: add             SP, SP, #0x10
    // 0x500574: LeaveFrame
    //     0x500574: mov             SP, fp
    //     0x500578: ldp             fp, lr, [SP], #0x10
    // 0x50057c: ret
    //     0x50057c: ret             
    // 0x500580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500584: b               #0x50055c
  }
  static _ debugWordWrap(/* No info */) {
    // ** addr: 0x500588, size: 0x7b0
    // 0x500588: EnterFrame
    //     0x500588: stp             fp, lr, [SP, #-0x10]!
    //     0x50058c: mov             fp, SP
    // 0x500590: AllocStack(0x68)
    //     0x500590: sub             SP, SP, #0x68
    // 0x500594: CheckStackOverflow
    //     0x500594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500598: cmp             SP, x16
    //     0x50059c: b.ls            #0x500cfc
    // 0x5005a0: ldr             x0, [fp, #0x18]
    // 0x5005a4: LoadField: r1 = r0->field_7
    //     0x5005a4: ldur            w1, [x0, #7]
    // 0x5005a8: DecompressPointer r1
    //     0x5005a8: add             x1, x1, HEAP, lsl #32
    // 0x5005ac: ldr             x2, [fp, #0x10]
    // 0x5005b0: cmp             w2, NULL
    // 0x5005b4: b.eq            #0x500d04
    // 0x5005b8: r3 = LoadInt32Instr(r1)
    //     0x5005b8: sbfx            x3, x1, #1, #0x1f
    // 0x5005bc: stur            x3, [fp, #-0x10]
    // 0x5005c0: r1 = LoadInt32Instr(r2)
    //     0x5005c0: sbfx            x1, x2, #1, #0x1f
    //     0x5005c4: tbz             w2, #0, #0x5005cc
    //     0x5005c8: ldur            x1, [x2, #7]
    // 0x5005cc: stur            x1, [fp, #-8]
    // 0x5005d0: cmp             x3, x1
    // 0x5005d4: b.lt            #0x50061c
    // 0x5005d8: SaveReg r0
    //     0x5005d8: str             x0, [SP, #-8]!
    // 0x5005dc: r0 = trimLeft()
    //     0x5005dc: bl              #0x4fc57c  ; [dart:core] _StringBase::trimLeft
    // 0x5005e0: add             SP, SP, #8
    // 0x5005e4: stp             xzr, x0, [SP, #-0x10]!
    // 0x5005e8: r0 = []()
    //     0x5005e8: bl              #0x4bdc9c  ; [dart:core] _StringBase::[]
    // 0x5005ec: add             SP, SP, #0x10
    // 0x5005f0: r1 = LoadClassIdInstr(r0)
    //     0x5005f0: ldur            x1, [x0, #-1]
    //     0x5005f4: ubfx            x1, x1, #0xc, #0x14
    // 0x5005f8: r16 = "#"
    //     0x5005f8: ldr             x16, [PP, #0x11c8]  ; [pp+0x11c8] "#"
    // 0x5005fc: stp             x16, x0, [SP, #-0x10]!
    // 0x500600: mov             x0, x1
    // 0x500604: mov             lr, x0
    // 0x500608: ldr             lr, [x21, lr, lsl #3]
    // 0x50060c: blr             lr
    // 0x500610: add             SP, SP, #0x10
    // 0x500614: tbnz            w0, #4, #0x500668
    // 0x500618: ldr             x0, [fp, #0x18]
    // 0x50061c: r3 = 2
    //     0x50061c: mov             x3, #2
    // 0x500620: mov             x2, x3
    // 0x500624: r1 = Null
    //     0x500624: mov             x1, NULL
    // 0x500628: r0 = AllocateArray()
    //     0x500628: bl              #0xd6987c  ; AllocateArrayStub
    // 0x50062c: mov             x2, x0
    // 0x500630: ldr             x0, [fp, #0x18]
    // 0x500634: stur            x2, [fp, #-0x18]
    // 0x500638: StoreField: r2->field_f = r0
    //     0x500638: stur            w0, [x2, #0xf]
    // 0x50063c: r1 = <String>
    //     0x50063c: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x500640: r0 = AllocateGrowableArray()
    //     0x500640: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x500644: mov             x1, x0
    // 0x500648: ldur            x0, [fp, #-0x18]
    // 0x50064c: StoreField: r1->field_f = r0
    //     0x50064c: stur            w0, [x1, #0xf]
    // 0x500650: r0 = 2
    //     0x500650: mov             x0, #2
    // 0x500654: StoreField: r1->field_b = r0
    //     0x500654: stur            w0, [x1, #0xb]
    // 0x500658: mov             x0, x1
    // 0x50065c: LeaveFrame
    //     0x50065c: mov             SP, fp
    //     0x500660: ldp             fp, lr, [SP], #0x10
    // 0x500664: ret
    //     0x500664: ret             
    // 0x500668: ldr             x0, [fp, #0x18]
    // 0x50066c: r16 = <String>
    //     0x50066c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x500670: stp             xzr, x16, [SP, #-0x10]!
    // 0x500674: r0 = _GrowableList()
    //     0x500674: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x500678: add             SP, SP, #0x10
    // 0x50067c: stur            x0, [fp, #-0x18]
    // 0x500680: r0 = InitLateStaticField(0xd44) // [package:flutter/src/foundation/print.dart] ::_indentPattern
    //     0x500680: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x500684: ldr             x0, [x0, #0x1a88]
    //     0x500688: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x50068c: cmp             w0, w16
    //     0x500690: b.ne            #0x50069c
    //     0x500694: ldr             x2, [PP, #0x1730]  ; [pp+0x1730] Field <::._indentPattern@646110992>: static late final (offset: 0xd44)
    //     0x500698: bl              #0xd67cdc
    // 0x50069c: ldr             x16, [fp, #0x18]
    // 0x5006a0: stp             x16, x0, [SP, #-0x10]!
    // 0x5006a4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x5006a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x5006a8: r0 = matchAsPrefix()
    //     0x5006a8: bl              #0xd65018  ; [dart:core] _RegExp::matchAsPrefix
    // 0x5006ac: add             SP, SP, #0x10
    // 0x5006b0: cmp             w0, NULL
    // 0x5006b4: b.eq            #0x500d08
    // 0x5006b8: stp             xzr, x0, [SP, #-0x10]!
    // 0x5006bc: r0 = group()
    //     0x5006bc: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x5006c0: add             SP, SP, #0x10
    // 0x5006c4: cmp             w0, NULL
    // 0x5006c8: b.eq            #0x500d0c
    // 0x5006cc: LoadField: r1 = r0->field_7
    //     0x5006cc: ldur            w1, [x0, #7]
    // 0x5006d0: DecompressPointer r1
    //     0x5006d0: add             x1, x1, HEAP, lsl #32
    // 0x5006d4: r0 = LoadInt32Instr(r1)
    //     0x5006d4: sbfx            x0, x1, #1, #0x1f
    // 0x5006d8: r16 = " "
    //     0x5006d8: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x5006dc: stp             x0, x16, [SP, #-0x10]!
    // 0x5006e0: r0 = *()
    //     0x5006e0: bl              #0xd648cc  ; [dart:core] _OneByteString::*
    // 0x5006e4: add             SP, SP, #0x10
    // 0x5006e8: r16 = ""
    //     0x5006e8: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x5006ec: stp             x0, x16, [SP, #-0x10]!
    // 0x5006f0: r0 = +()
    //     0x5006f0: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x5006f4: add             SP, SP, #0x10
    // 0x5006f8: mov             x2, x0
    // 0x5006fc: stur            x2, [fp, #-0x50]
    // 0x500700: LoadField: r0 = r2->field_7
    //     0x500700: ldur            w0, [x2, #7]
    // 0x500704: DecompressPointer r0
    //     0x500704: add             x0, x0, HEAP, lsl #32
    // 0x500708: r3 = LoadInt32Instr(r0)
    //     0x500708: sbfx            x3, x0, #1, #0x1f
    // 0x50070c: stur            x3, [fp, #-0x48]
    // 0x500710: mov             x9, x3
    // 0x500714: r12 = 0
    //     0x500714: mov             x12, #0
    // 0x500718: r11 = 0
    //     0x500718: mov             x11, #0
    // 0x50071c: r10 = false
    //     0x50071c: add             x10, NULL, #0x30  ; false
    // 0x500720: r0 = Instance__WordWrapParseMode
    //     0x500720: ldr             x0, [PP, #0x1738]  ; [pp+0x1738] Obj!_WordWrapParseMode@b65cb1
    // 0x500724: r8 = Sentinel
    //     0x500724: ldr             x8, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x500728: r7 = Null
    //     0x500728: mov             x7, NULL
    // 0x50072c: ldur            x4, [fp, #-0x18]
    // 0x500730: ldur            x5, [fp, #-0x10]
    // 0x500734: ldur            x6, [fp, #-8]
    // 0x500738: stur            x12, [fp, #-0x28]
    // 0x50073c: stur            x11, [fp, #-0x30]
    // 0x500740: stur            x10, [fp, #-0x38]
    // 0x500744: stur            x7, [fp, #-0x40]
    // 0x500748: stur            x8, [fp, #-0x58]
    // 0x50074c: stur            x9, [fp, #-0x60]
    // 0x500750: CheckStackOverflow
    //     0x500750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500754: cmp             SP, x16
    //     0x500758: b.ls            #0x500d10
    // 0x50075c: LoadField: r1 = r0->field_7
    //     0x50075c: ldur            x1, [x0, #7]
    // 0x500760: cmp             x1, #1
    // 0x500764: b.gt            #0x500900
    // 0x500768: cmp             x1, #0
    // 0x50076c: b.gt            #0x500850
    // 0x500770: mov             x8, x9
    // 0x500774: stur            x8, [fp, #-0x20]
    // 0x500778: CheckStackOverflow
    //     0x500778: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50077c: cmp             SP, x16
    //     0x500780: b.ls            #0x500d18
    // 0x500784: cmp             x8, x5
    // 0x500788: b.ge            #0x500810
    // 0x50078c: r0 = BoxInt64Instr(r8)
    //     0x50078c: sbfiz           x0, x8, #1, #0x1f
    //     0x500790: cmp             x8, x0, asr #1
    //     0x500794: b.eq            #0x5007a0
    //     0x500798: bl              #0xd69bb8
    //     0x50079c: stur            x8, [x0, #7]
    // 0x5007a0: ldr             x16, [fp, #0x18]
    // 0x5007a4: stp             x0, x16, [SP, #-0x10]!
    // 0x5007a8: r0 = []()
    //     0x5007a8: bl              #0x4bdc9c  ; [dart:core] _StringBase::[]
    // 0x5007ac: add             SP, SP, #0x10
    // 0x5007b0: r1 = LoadClassIdInstr(r0)
    //     0x5007b0: ldur            x1, [x0, #-1]
    //     0x5007b4: ubfx            x1, x1, #0xc, #0x14
    // 0x5007b8: r16 = " "
    //     0x5007b8: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x5007bc: stp             x16, x0, [SP, #-0x10]!
    // 0x5007c0: mov             x0, x1
    // 0x5007c4: mov             lr, x0
    // 0x5007c8: ldr             lr, [x21, lr, lsl #3]
    // 0x5007cc: blr             lr
    // 0x5007d0: add             SP, SP, #0x10
    // 0x5007d4: tbnz            w0, #4, #0x500808
    // 0x5007d8: ldur            x2, [fp, #-0x20]
    // 0x5007dc: add             x8, x2, #1
    // 0x5007e0: ldur            x4, [fp, #-0x18]
    // 0x5007e4: ldur            x2, [fp, #-0x50]
    // 0x5007e8: ldur            x12, [fp, #-0x28]
    // 0x5007ec: ldur            x11, [fp, #-0x30]
    // 0x5007f0: ldur            x10, [fp, #-0x38]
    // 0x5007f4: ldur            x7, [fp, #-0x40]
    // 0x5007f8: ldur            x5, [fp, #-0x10]
    // 0x5007fc: ldur            x6, [fp, #-8]
    // 0x500800: ldur            x3, [fp, #-0x48]
    // 0x500804: b               #0x500774
    // 0x500808: ldur            x2, [fp, #-0x20]
    // 0x50080c: b               #0x500814
    // 0x500810: mov             x2, x8
    // 0x500814: r0 = BoxInt64Instr(r2)
    //     0x500814: sbfiz           x0, x2, #1, #0x1f
    //     0x500818: cmp             x2, x0, asr #1
    //     0x50081c: b.eq            #0x500828
    //     0x500820: bl              #0xd69bb8
    //     0x500824: stur            x2, [x0, #7]
    // 0x500828: ldur            x12, [fp, #-0x28]
    // 0x50082c: ldur            x11, [fp, #-0x30]
    // 0x500830: ldur            x10, [fp, #-0x38]
    // 0x500834: mov             x9, x2
    // 0x500838: mov             x8, x0
    // 0x50083c: ldur            x7, [fp, #-0x40]
    // 0x500840: ldur            x6, [fp, #-0x48]
    // 0x500844: r0 = Instance__WordWrapParseMode
    //     0x500844: ldr             x0, [PP, #0x1740]  ; [pp+0x1740] Obj!_WordWrapParseMode@b65c91
    // 0x500848: r4 = "Local \'lastWordStart\' has not been initialized."
    //     0x500848: ldr             x4, [PP, #0x1748]  ; [pp+0x1748] "Local \'lastWordStart\' has not been initialized."
    // 0x50084c: b               #0x500cdc
    // 0x500850: mov             x3, x9
    // 0x500854: ldur            x2, [fp, #-0x10]
    // 0x500858: stur            x3, [fp, #-0x20]
    // 0x50085c: CheckStackOverflow
    //     0x50085c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500860: cmp             SP, x16
    //     0x500864: b.ls            #0x500d20
    // 0x500868: cmp             x3, x2
    // 0x50086c: b.ge            #0x5008d4
    // 0x500870: r0 = BoxInt64Instr(r3)
    //     0x500870: sbfiz           x0, x3, #1, #0x1f
    //     0x500874: cmp             x3, x0, asr #1
    //     0x500878: b.eq            #0x500884
    //     0x50087c: bl              #0xd69bb8
    //     0x500880: stur            x3, [x0, #7]
    // 0x500884: ldr             x16, [fp, #0x18]
    // 0x500888: stp             x0, x16, [SP, #-0x10]!
    // 0x50088c: r0 = []()
    //     0x50088c: bl              #0x4bdc9c  ; [dart:core] _StringBase::[]
    // 0x500890: add             SP, SP, #0x10
    // 0x500894: r1 = LoadClassIdInstr(r0)
    //     0x500894: ldur            x1, [x0, #-1]
    //     0x500898: ubfx            x1, x1, #0xc, #0x14
    // 0x50089c: r16 = " "
    //     0x50089c: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x5008a0: stp             x16, x0, [SP, #-0x10]!
    // 0x5008a4: mov             x0, x1
    // 0x5008a8: mov             lr, x0
    // 0x5008ac: ldr             lr, [x21, lr, lsl #3]
    // 0x5008b0: blr             lr
    // 0x5008b4: add             SP, SP, #0x10
    // 0x5008b8: tbz             w0, #4, #0x5008cc
    // 0x5008bc: ldur            x0, [fp, #-0x20]
    // 0x5008c0: add             x3, x0, #1
    // 0x5008c4: ldur            x8, [fp, #-0x58]
    // 0x5008c8: b               #0x500854
    // 0x5008cc: ldur            x0, [fp, #-0x20]
    // 0x5008d0: b               #0x5008d8
    // 0x5008d4: mov             x0, x3
    // 0x5008d8: ldur            x12, [fp, #-0x28]
    // 0x5008dc: ldur            x11, [fp, #-0x30]
    // 0x5008e0: ldur            x10, [fp, #-0x38]
    // 0x5008e4: mov             x9, x0
    // 0x5008e8: ldur            x8, [fp, #-0x58]
    // 0x5008ec: ldur            x7, [fp, #-0x40]
    // 0x5008f0: ldur            x6, [fp, #-0x48]
    // 0x5008f4: r0 = Instance__WordWrapParseMode
    //     0x5008f4: ldr             x0, [PP, #0x1750]  ; [pp+0x1750] Obj!_WordWrapParseMode@b65c71
    // 0x5008f8: r4 = "Local \'lastWordStart\' has not been initialized."
    //     0x5008f8: ldr             x4, [PP, #0x1748]  ; [pp+0x1748] "Local \'lastWordStart\' has not been initialized."
    // 0x5008fc: b               #0x500cdc
    // 0x500900: mov             x3, x11
    // 0x500904: mov             x2, x6
    // 0x500908: sub             x0, x9, x3
    // 0x50090c: cmp             x0, x2
    // 0x500910: b.le            #0x50091c
    // 0x500914: ldur            x4, [fp, #-0x10]
    // 0x500918: b               #0x500928
    // 0x50091c: ldur            x4, [fp, #-0x10]
    // 0x500920: cmp             x9, x4
    // 0x500924: b.ne            #0x500c90
    // 0x500928: cmp             x0, x2
    // 0x50092c: b.le            #0x50093c
    // 0x500930: ldur            x0, [fp, #-0x40]
    // 0x500934: cmp             w0, NULL
    // 0x500938: b.ne            #0x500944
    // 0x50093c: mov             x5, x9
    // 0x500940: b               #0x500954
    // 0x500944: r1 = LoadInt32Instr(r0)
    //     0x500944: sbfx            x1, x0, #1, #0x1f
    //     0x500948: tbz             w0, #0, #0x500950
    //     0x50094c: ldur            x1, [x0, #7]
    // 0x500950: mov             x5, x1
    // 0x500954: ldur            x3, [fp, #-0x38]
    // 0x500958: stur            x5, [fp, #-0x20]
    // 0x50095c: tbnz            w3, #4, #0x500a70
    // 0x500960: ldur            x6, [fp, #-0x18]
    // 0x500964: ldur            x12, [fp, #-0x28]
    // 0x500968: r0 = BoxInt64Instr(r12)
    //     0x500968: sbfiz           x0, x12, #1, #0x1f
    //     0x50096c: cmp             x12, x0, asr #1
    //     0x500970: b.eq            #0x50097c
    //     0x500974: bl              #0xd69bb8
    //     0x500978: stur            x12, [x0, #7]
    // 0x50097c: mov             x7, x0
    // 0x500980: stur            x7, [fp, #-0x40]
    // 0x500984: r0 = BoxInt64Instr(r5)
    //     0x500984: sbfiz           x0, x5, #1, #0x1f
    //     0x500988: cmp             x5, x0, asr #1
    //     0x50098c: b.eq            #0x500998
    //     0x500990: bl              #0xd69bb8
    //     0x500994: stur            x5, [x0, #7]
    // 0x500998: stp             x0, x7, [SP, #-0x10]!
    // 0x50099c: SaveReg r4
    //     0x50099c: str             x4, [SP, #-8]!
    // 0x5009a0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x5009a0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x5009a4: r0 = checkValidRange()
    //     0x5009a4: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x5009a8: add             SP, SP, #0x18
    // 0x5009ac: ldr             x16, [fp, #0x18]
    // 0x5009b0: ldur            lr, [fp, #-0x40]
    // 0x5009b4: stp             lr, x16, [SP, #-0x10]!
    // 0x5009b8: SaveReg r0
    //     0x5009b8: str             x0, [SP, #-8]!
    // 0x5009bc: r0 = _substringUnchecked()
    //     0x5009bc: bl              #0x4d0ab0  ; [dart:core] _StringBase::_substringUnchecked
    // 0x5009c0: add             SP, SP, #0x18
    // 0x5009c4: ldur            x16, [fp, #-0x50]
    // 0x5009c8: stp             x0, x16, [SP, #-0x10]!
    // 0x5009cc: r0 = +()
    //     0x5009cc: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x5009d0: add             SP, SP, #0x10
    // 0x5009d4: mov             x1, x0
    // 0x5009d8: ldur            x0, [fp, #-0x18]
    // 0x5009dc: stur            x1, [fp, #-0x68]
    // 0x5009e0: LoadField: r2 = r0->field_b
    //     0x5009e0: ldur            w2, [x0, #0xb]
    // 0x5009e4: DecompressPointer r2
    //     0x5009e4: add             x2, x2, HEAP, lsl #32
    // 0x5009e8: stur            x2, [fp, #-0x40]
    // 0x5009ec: LoadField: r3 = r0->field_f
    //     0x5009ec: ldur            w3, [x0, #0xf]
    // 0x5009f0: DecompressPointer r3
    //     0x5009f0: add             x3, x3, HEAP, lsl #32
    // 0x5009f4: LoadField: r4 = r3->field_b
    //     0x5009f4: ldur            w4, [x3, #0xb]
    // 0x5009f8: DecompressPointer r4
    //     0x5009f8: add             x4, x4, HEAP, lsl #32
    // 0x5009fc: cmp             w2, w4
    // 0x500a00: b.ne            #0x500a10
    // 0x500a04: SaveReg r0
    //     0x500a04: str             x0, [SP, #-8]!
    // 0x500a08: r0 = _growToNextCapacity()
    //     0x500a08: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x500a0c: add             SP, SP, #8
    // 0x500a10: ldur            x2, [fp, #-0x18]
    // 0x500a14: ldur            x0, [fp, #-0x40]
    // 0x500a18: r3 = LoadInt32Instr(r0)
    //     0x500a18: sbfx            x3, x0, #1, #0x1f
    // 0x500a1c: add             x0, x3, #1
    // 0x500a20: lsl             x1, x0, #1
    // 0x500a24: StoreField: r2->field_b = r1
    //     0x500a24: stur            w1, [x2, #0xb]
    // 0x500a28: mov             x1, x3
    // 0x500a2c: cmp             x1, x0
    // 0x500a30: b.hs            #0x500d28
    // 0x500a34: LoadField: r1 = r2->field_f
    //     0x500a34: ldur            w1, [x2, #0xf]
    // 0x500a38: DecompressPointer r1
    //     0x500a38: add             x1, x1, HEAP, lsl #32
    // 0x500a3c: ldur            x0, [fp, #-0x68]
    // 0x500a40: ArrayStore: r1[r3] = r0  ; List_4
    //     0x500a40: add             x25, x1, x3, lsl #2
    //     0x500a44: add             x25, x25, #0xf
    //     0x500a48: str             w0, [x25]
    //     0x500a4c: tbz             w0, #0, #0x500a68
    //     0x500a50: ldurb           w16, [x1, #-1]
    //     0x500a54: ldurb           w17, [x0, #-1]
    //     0x500a58: and             x16, x17, x16, lsr #2
    //     0x500a5c: tst             x16, HEAP, lsr #32
    //     0x500a60: b.eq            #0x500a68
    //     0x500a64: bl              #0xd67e5c
    // 0x500a68: ldur            x4, [fp, #-0x38]
    // 0x500a6c: b               #0x500b74
    // 0x500a70: ldur            x2, [fp, #-0x18]
    // 0x500a74: ldur            x12, [fp, #-0x28]
    // 0x500a78: mov             x3, x4
    // 0x500a7c: mov             x4, x5
    // 0x500a80: r0 = BoxInt64Instr(r12)
    //     0x500a80: sbfiz           x0, x12, #1, #0x1f
    //     0x500a84: cmp             x12, x0, asr #1
    //     0x500a88: b.eq            #0x500a94
    //     0x500a8c: bl              #0xd69bb8
    //     0x500a90: stur            x12, [x0, #7]
    // 0x500a94: mov             x5, x0
    // 0x500a98: stur            x5, [fp, #-0x40]
    // 0x500a9c: r0 = BoxInt64Instr(r4)
    //     0x500a9c: sbfiz           x0, x4, #1, #0x1f
    //     0x500aa0: cmp             x4, x0, asr #1
    //     0x500aa4: b.eq            #0x500ab0
    //     0x500aa8: bl              #0xd69bb8
    //     0x500aac: stur            x4, [x0, #7]
    // 0x500ab0: stp             x0, x5, [SP, #-0x10]!
    // 0x500ab4: SaveReg r3
    //     0x500ab4: str             x3, [SP, #-8]!
    // 0x500ab8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x500ab8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x500abc: r0 = checkValidRange()
    //     0x500abc: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x500ac0: add             SP, SP, #0x18
    // 0x500ac4: ldr             x16, [fp, #0x18]
    // 0x500ac8: ldur            lr, [fp, #-0x40]
    // 0x500acc: stp             lr, x16, [SP, #-0x10]!
    // 0x500ad0: SaveReg r0
    //     0x500ad0: str             x0, [SP, #-8]!
    // 0x500ad4: r0 = _substringUnchecked()
    //     0x500ad4: bl              #0x4d0ab0  ; [dart:core] _StringBase::_substringUnchecked
    // 0x500ad8: add             SP, SP, #0x18
    // 0x500adc: mov             x1, x0
    // 0x500ae0: ldur            x0, [fp, #-0x18]
    // 0x500ae4: stur            x1, [fp, #-0x68]
    // 0x500ae8: LoadField: r2 = r0->field_b
    //     0x500ae8: ldur            w2, [x0, #0xb]
    // 0x500aec: DecompressPointer r2
    //     0x500aec: add             x2, x2, HEAP, lsl #32
    // 0x500af0: stur            x2, [fp, #-0x40]
    // 0x500af4: LoadField: r3 = r0->field_f
    //     0x500af4: ldur            w3, [x0, #0xf]
    // 0x500af8: DecompressPointer r3
    //     0x500af8: add             x3, x3, HEAP, lsl #32
    // 0x500afc: LoadField: r4 = r3->field_b
    //     0x500afc: ldur            w4, [x3, #0xb]
    // 0x500b00: DecompressPointer r4
    //     0x500b00: add             x4, x4, HEAP, lsl #32
    // 0x500b04: cmp             w2, w4
    // 0x500b08: b.ne            #0x500b18
    // 0x500b0c: SaveReg r0
    //     0x500b0c: str             x0, [SP, #-8]!
    // 0x500b10: r0 = _growToNextCapacity()
    //     0x500b10: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x500b14: add             SP, SP, #8
    // 0x500b18: ldur            x2, [fp, #-0x18]
    // 0x500b1c: ldur            x0, [fp, #-0x40]
    // 0x500b20: r3 = LoadInt32Instr(r0)
    //     0x500b20: sbfx            x3, x0, #1, #0x1f
    // 0x500b24: add             x0, x3, #1
    // 0x500b28: lsl             x1, x0, #1
    // 0x500b2c: StoreField: r2->field_b = r1
    //     0x500b2c: stur            w1, [x2, #0xb]
    // 0x500b30: mov             x1, x3
    // 0x500b34: cmp             x1, x0
    // 0x500b38: b.hs            #0x500d2c
    // 0x500b3c: LoadField: r1 = r2->field_f
    //     0x500b3c: ldur            w1, [x2, #0xf]
    // 0x500b40: DecompressPointer r1
    //     0x500b40: add             x1, x1, HEAP, lsl #32
    // 0x500b44: ldur            x0, [fp, #-0x68]
    // 0x500b48: ArrayStore: r1[r3] = r0  ; List_4
    //     0x500b48: add             x25, x1, x3, lsl #2
    //     0x500b4c: add             x25, x25, #0xf
    //     0x500b50: str             w0, [x25]
    //     0x500b54: tbz             w0, #0, #0x500b70
    //     0x500b58: ldurb           w16, [x1, #-1]
    //     0x500b5c: ldurb           w17, [x0, #-1]
    //     0x500b60: and             x16, x17, x16, lsr #2
    //     0x500b64: tst             x16, HEAP, lsr #32
    //     0x500b68: b.eq            #0x500b70
    //     0x500b6c: bl              #0xd67e5c
    // 0x500b70: r4 = true
    //     0x500b70: add             x4, NULL, #0x20  ; true
    // 0x500b74: ldur            x0, [fp, #-0x20]
    // 0x500b78: ldur            x3, [fp, #-0x10]
    // 0x500b7c: stur            x4, [fp, #-0x40]
    // 0x500b80: cmp             x0, x3
    // 0x500b84: b.lt            #0x500b98
    // 0x500b88: mov             x0, x2
    // 0x500b8c: LeaveFrame
    //     0x500b8c: mov             SP, fp
    //     0x500b90: ldp             fp, lr, [SP], #0x10
    // 0x500b94: ret
    //     0x500b94: ret             
    // 0x500b98: ldur            x5, [fp, #-0x60]
    // 0x500b9c: cmp             x0, x5
    // 0x500ba0: b.ne            #0x500c44
    // 0x500ba4: stur            x5, [fp, #-0x20]
    // 0x500ba8: CheckStackOverflow
    //     0x500ba8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500bac: cmp             SP, x16
    //     0x500bb0: b.ls            #0x500d30
    // 0x500bb4: cmp             x5, x3
    // 0x500bb8: b.ge            #0x500c28
    // 0x500bbc: r0 = BoxInt64Instr(r5)
    //     0x500bbc: sbfiz           x0, x5, #1, #0x1f
    //     0x500bc0: cmp             x5, x0, asr #1
    //     0x500bc4: b.eq            #0x500bd0
    //     0x500bc8: bl              #0xd69bb8
    //     0x500bcc: stur            x5, [x0, #7]
    // 0x500bd0: ldr             x16, [fp, #0x18]
    // 0x500bd4: stp             x0, x16, [SP, #-0x10]!
    // 0x500bd8: r0 = []()
    //     0x500bd8: bl              #0x4bdc9c  ; [dart:core] _StringBase::[]
    // 0x500bdc: add             SP, SP, #0x10
    // 0x500be0: r1 = LoadClassIdInstr(r0)
    //     0x500be0: ldur            x1, [x0, #-1]
    //     0x500be4: ubfx            x1, x1, #0xc, #0x14
    // 0x500be8: r16 = " "
    //     0x500be8: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x500bec: stp             x16, x0, [SP, #-0x10]!
    // 0x500bf0: mov             x0, x1
    // 0x500bf4: mov             lr, x0
    // 0x500bf8: ldr             lr, [x21, lr, lsl #3]
    // 0x500bfc: blr             lr
    // 0x500c00: add             SP, SP, #0x10
    // 0x500c04: tbnz            w0, #4, #0x500c20
    // 0x500c08: ldur            x0, [fp, #-0x20]
    // 0x500c0c: add             x5, x0, #1
    // 0x500c10: ldur            x2, [fp, #-0x18]
    // 0x500c14: ldur            x4, [fp, #-0x40]
    // 0x500c18: ldur            x3, [fp, #-0x10]
    // 0x500c1c: b               #0x500ba4
    // 0x500c20: ldur            x0, [fp, #-0x20]
    // 0x500c24: b               #0x500c2c
    // 0x500c28: mov             x0, x5
    // 0x500c2c: mov             x3, x0
    // 0x500c30: mov             x1, x0
    // 0x500c34: ldur            x2, [fp, #-0x58]
    // 0x500c38: r0 = Instance__WordWrapParseMode
    //     0x500c38: ldr             x0, [PP, #0x1740]  ; [pp+0x1740] Obj!_WordWrapParseMode@b65c91
    // 0x500c3c: r4 = "Local \'lastWordStart\' has not been initialized."
    //     0x500c3c: ldr             x4, [PP, #0x1748]  ; [pp+0x1748] "Local \'lastWordStart\' has not been initialized."
    // 0x500c40: b               #0x500c70
    // 0x500c44: ldur            x2, [fp, #-0x58]
    // 0x500c48: r16 = Sentinel
    //     0x500c48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x500c4c: cmp             w2, w16
    // 0x500c50: b.eq            #0x500ce8
    // 0x500c54: r4 = "Local \'lastWordStart\' has not been initialized."
    //     0x500c54: ldr             x4, [PP, #0x1748]  ; [pp+0x1748] "Local \'lastWordStart\' has not been initialized."
    // 0x500c58: r6 = LoadInt32Instr(r2)
    //     0x500c58: sbfx            x6, x2, #1, #0x1f
    //     0x500c5c: tbz             w2, #0, #0x500c64
    //     0x500c60: ldur            x6, [x2, #7]
    // 0x500c64: mov             x3, x6
    // 0x500c68: mov             x1, x5
    // 0x500c6c: r0 = Instance__WordWrapParseMode
    //     0x500c6c: ldr             x0, [PP, #0x1750]  ; [pp+0x1750] Obj!_WordWrapParseMode@b65c71
    // 0x500c70: ldur            x6, [fp, #-0x48]
    // 0x500c74: sub             x5, x3, x6
    // 0x500c78: mov             x12, x3
    // 0x500c7c: mov             x11, x5
    // 0x500c80: ldur            x5, [fp, #-0x40]
    // 0x500c84: mov             x3, x1
    // 0x500c88: r1 = Null
    //     0x500c88: mov             x1, NULL
    // 0x500c8c: b               #0x500ccc
    // 0x500c90: ldur            x12, [fp, #-0x28]
    // 0x500c94: mov             x5, x9
    // 0x500c98: ldur            x2, [fp, #-0x58]
    // 0x500c9c: ldur            x6, [fp, #-0x48]
    // 0x500ca0: r4 = "Local \'lastWordStart\' has not been initialized."
    //     0x500ca0: ldr             x4, [PP, #0x1748]  ; [pp+0x1748] "Local \'lastWordStart\' has not been initialized."
    // 0x500ca4: r0 = BoxInt64Instr(r5)
    //     0x500ca4: sbfiz           x0, x5, #1, #0x1f
    //     0x500ca8: cmp             x5, x0, asr #1
    //     0x500cac: b.eq            #0x500cb8
    //     0x500cb0: bl              #0xd69bb8
    //     0x500cb4: stur            x5, [x0, #7]
    // 0x500cb8: mov             x1, x0
    // 0x500cbc: mov             x11, x3
    // 0x500cc0: mov             x3, x5
    // 0x500cc4: ldur            x5, [fp, #-0x38]
    // 0x500cc8: r0 = Instance__WordWrapParseMode
    //     0x500cc8: ldr             x0, [PP, #0x1738]  ; [pp+0x1738] Obj!_WordWrapParseMode@b65cb1
    // 0x500ccc: mov             x10, x5
    // 0x500cd0: mov             x9, x3
    // 0x500cd4: mov             x8, x2
    // 0x500cd8: mov             x7, x1
    // 0x500cdc: ldur            x2, [fp, #-0x50]
    // 0x500ce0: mov             x3, x6
    // 0x500ce4: b               #0x50072c
    // 0x500ce8: r0 = LateError()
    //     0x500ce8: bl              #0x4fba60  ; AllocateLateErrorStub -> LateError (size=0x10)
    // 0x500cec: r4 = "Local \'lastWordStart\' has not been initialized."
    //     0x500cec: ldr             x4, [PP, #0x1748]  ; [pp+0x1748] "Local \'lastWordStart\' has not been initialized."
    // 0x500cf0: StoreField: r0->field_b = r4
    //     0x500cf0: stur            w4, [x0, #0xb]
    // 0x500cf4: r0 = Throw()
    //     0x500cf4: bl              #0xd67e38  ; ThrowStub
    // 0x500cf8: brk             #0
    // 0x500cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500cfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500d00: b               #0x5005a0
    // 0x500d04: r0 = NullErrorSharedWithoutFPURegs()
    //     0x500d04: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x500d08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x500d08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x500d0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x500d0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x500d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500d10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500d14: b               #0x50075c
    // 0x500d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500d18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500d1c: b               #0x500784
    // 0x500d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500d20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500d24: b               #0x500868
    // 0x500d28: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x500d28: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x500d2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x500d2c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x500d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500d30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500d34: b               #0x500bb4
  }
  static RegExp _indentPattern() {
    // ** addr: 0x500d38, size: 0x3c
    // 0x500d38: EnterFrame
    //     0x500d38: stp             fp, lr, [SP, #-0x10]!
    //     0x500d3c: mov             fp, SP
    // 0x500d40: CheckStackOverflow
    //     0x500d40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500d44: cmp             SP, x16
    //     0x500d48: b.ls            #0x500d6c
    // 0x500d4c: r16 = "^ *(\?:[-+*] |[0-9]+[.):] )\?"
    //     0x500d4c: ldr             x16, [PP, #0x1778]  ; [pp+0x1778] "^ *(\?:[-+*] |[0-9]+[.):] )\?"
    // 0x500d50: stp             x16, NULL, [SP, #-0x10]!
    // 0x500d54: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x500d54: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x500d58: r0 = RegExp()
    //     0x500d58: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0x500d5c: add             SP, SP, #0x10
    // 0x500d60: LeaveFrame
    //     0x500d60: mov             SP, fp
    //     0x500d64: ldp             fp, lr, [SP], #0x10
    // 0x500d68: ret
    //     0x500d68: ret             
    // 0x500d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500d6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500d70: b               #0x500d4c
  }
  static Queue<String> _debugPrintBuffer() {
    // ** addr: 0x500d74, size: 0x4c
    // 0x500d74: EnterFrame
    //     0x500d74: stp             fp, lr, [SP, #-0x10]!
    //     0x500d78: mov             fp, SP
    // 0x500d7c: AllocStack(0x8)
    //     0x500d7c: sub             SP, SP, #8
    // 0x500d80: CheckStackOverflow
    //     0x500d80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500d84: cmp             SP, x16
    //     0x500d88: b.ls            #0x500db8
    // 0x500d8c: r1 = <String>
    //     0x500d8c: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x500d90: r0 = ListQueue()
    //     0x500d90: bl              #0x4ec788  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0x500d94: stur            x0, [fp, #-8]
    // 0x500d98: SaveReg r0
    //     0x500d98: str             x0, [SP, #-8]!
    // 0x500d9c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x500d9c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x500da0: r0 = ListQueue()
    //     0x500da0: bl              #0x4ec604  ; [dart:collection] ListQueue::ListQueue
    // 0x500da4: add             SP, SP, #8
    // 0x500da8: ldur            x0, [fp, #-8]
    // 0x500dac: LeaveFrame
    //     0x500dac: mov             SP, fp
    //     0x500db0: ldp             fp, lr, [SP], #0x10
    // 0x500db4: ret
    //     0x500db4: ret             
    // 0x500db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500db8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500dbc: b               #0x500d8c
  }
}

// class id: 5982, size: 0x14, field offset: 0x14
enum _WordWrapParseMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15c8c, size: 0x5c
    // 0xb15c8c: EnterFrame
    //     0xb15c8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb15c90: mov             fp, SP
    // 0xb15c94: CheckStackOverflow
    //     0xb15c94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15c98: cmp             SP, x16
    //     0xb15c9c: b.ls            #0xb15ce0
    // 0xb15ca0: r1 = Null
    //     0xb15ca0: mov             x1, NULL
    // 0xb15ca4: r2 = 4
    //     0xb15ca4: mov             x2, #4
    // 0xb15ca8: r0 = AllocateArray()
    //     0xb15ca8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15cac: r17 = "_WordWrapParseMode."
    //     0xb15cac: add             x17, PP, #0xb, lsl #12  ; [pp+0xb120] "_WordWrapParseMode."
    //     0xb15cb0: ldr             x17, [x17, #0x120]
    // 0xb15cb4: StoreField: r0->field_f = r17
    //     0xb15cb4: stur            w17, [x0, #0xf]
    // 0xb15cb8: ldr             x1, [fp, #0x10]
    // 0xb15cbc: LoadField: r2 = r1->field_f
    //     0xb15cbc: ldur            w2, [x1, #0xf]
    // 0xb15cc0: DecompressPointer r2
    //     0xb15cc0: add             x2, x2, HEAP, lsl #32
    // 0xb15cc4: StoreField: r0->field_13 = r2
    //     0xb15cc4: stur            w2, [x0, #0x13]
    // 0xb15cc8: SaveReg r0
    //     0xb15cc8: str             x0, [SP, #-8]!
    // 0xb15ccc: r0 = _interpolate()
    //     0xb15ccc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15cd0: add             SP, SP, #8
    // 0xb15cd4: LeaveFrame
    //     0xb15cd4: mov             SP, fp
    //     0xb15cd8: ldp             fp, lr, [SP], #0x10
    // 0xb15cdc: ret
    //     0xb15cdc: ret             
    // 0xb15ce0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15ce0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15ce4: b               #0xb15ca0
  }
}

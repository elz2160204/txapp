// lib: , url: package:flutter/src/foundation/collections.dart

// class id: 1049128, size: 0x8
class :: {

  static _ listEquals(/* No info */) {
    // ** addr: 0x512fbc, size: 0x224
    // 0x512fbc: EnterFrame
    //     0x512fbc: stp             fp, lr, [SP, #-0x10]!
    //     0x512fc0: mov             fp, SP
    // 0x512fc4: AllocStack(0x18)
    //     0x512fc4: sub             SP, SP, #0x18
    // 0x512fc8: CheckStackOverflow
    //     0x512fc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x512fcc: cmp             SP, x16
    //     0x512fd0: b.ls            #0x5131d0
    // 0x512fd4: ldr             x1, [fp, #0x18]
    // 0x512fd8: cmp             w1, NULL
    // 0x512fdc: b.ne            #0x513000
    // 0x512fe0: ldr             x2, [fp, #0x10]
    // 0x512fe4: cmp             w2, NULL
    // 0x512fe8: r16 = true
    //     0x512fe8: add             x16, NULL, #0x20  ; true
    // 0x512fec: r17 = false
    //     0x512fec: add             x17, NULL, #0x30  ; false
    // 0x512ff0: csel            x0, x16, x17, eq
    // 0x512ff4: LeaveFrame
    //     0x512ff4: mov             SP, fp
    //     0x512ff8: ldp             fp, lr, [SP], #0x10
    // 0x512ffc: ret
    //     0x512ffc: ret             
    // 0x513000: ldr             x2, [fp, #0x10]
    // 0x513004: cmp             w2, NULL
    // 0x513008: b.eq            #0x513080
    // 0x51300c: r0 = LoadClassIdInstr(r1)
    //     0x51300c: ldur            x0, [x1, #-1]
    //     0x513010: ubfx            x0, x0, #0xc, #0x14
    // 0x513014: SaveReg r1
    //     0x513014: str             x1, [SP, #-8]!
    // 0x513018: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x513018: mov             x17, #0xb8ea
    //     0x51301c: add             lr, x0, x17
    //     0x513020: ldr             lr, [x21, lr, lsl #3]
    //     0x513024: blr             lr
    // 0x513028: add             SP, SP, #8
    // 0x51302c: mov             x2, x0
    // 0x513030: ldr             x1, [fp, #0x10]
    // 0x513034: stur            x2, [fp, #-8]
    // 0x513038: r0 = LoadClassIdInstr(r1)
    //     0x513038: ldur            x0, [x1, #-1]
    //     0x51303c: ubfx            x0, x0, #0xc, #0x14
    // 0x513040: SaveReg r1
    //     0x513040: str             x1, [SP, #-8]!
    // 0x513044: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x513044: mov             x17, #0xb8ea
    //     0x513048: add             lr, x0, x17
    //     0x51304c: ldr             lr, [x21, lr, lsl #3]
    //     0x513050: blr             lr
    // 0x513054: add             SP, SP, #8
    // 0x513058: mov             x1, x0
    // 0x51305c: ldur            x0, [fp, #-8]
    // 0x513060: r2 = LoadInt32Instr(r0)
    //     0x513060: sbfx            x2, x0, #1, #0x1f
    //     0x513064: tbz             w0, #0, #0x51306c
    //     0x513068: ldur            x2, [x0, #7]
    // 0x51306c: r0 = LoadInt32Instr(r1)
    //     0x51306c: sbfx            x0, x1, #1, #0x1f
    //     0x513070: tbz             w1, #0, #0x513078
    //     0x513074: ldur            x0, [x1, #7]
    // 0x513078: cmp             x2, x0
    // 0x51307c: b.eq            #0x513090
    // 0x513080: r0 = false
    //     0x513080: add             x0, NULL, #0x30  ; false
    // 0x513084: LeaveFrame
    //     0x513084: mov             SP, fp
    //     0x513088: ldp             fp, lr, [SP], #0x10
    // 0x51308c: ret
    //     0x51308c: ret             
    // 0x513090: ldr             x2, [fp, #0x18]
    // 0x513094: ldr             x1, [fp, #0x10]
    // 0x513098: cmp             w2, w1
    // 0x51309c: b.ne            #0x5130b0
    // 0x5130a0: r0 = true
    //     0x5130a0: add             x0, NULL, #0x20  ; true
    // 0x5130a4: LeaveFrame
    //     0x5130a4: mov             SP, fp
    //     0x5130a8: ldp             fp, lr, [SP], #0x10
    // 0x5130ac: ret
    //     0x5130ac: ret             
    // 0x5130b0: r3 = 0
    //     0x5130b0: mov             x3, #0
    // 0x5130b4: stur            x3, [fp, #-0x10]
    // 0x5130b8: CheckStackOverflow
    //     0x5130b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5130bc: cmp             SP, x16
    //     0x5130c0: b.ls            #0x5131d8
    // 0x5130c4: r0 = LoadClassIdInstr(r2)
    //     0x5130c4: ldur            x0, [x2, #-1]
    //     0x5130c8: ubfx            x0, x0, #0xc, #0x14
    // 0x5130cc: SaveReg r2
    //     0x5130cc: str             x2, [SP, #-8]!
    // 0x5130d0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x5130d0: mov             x17, #0xb8ea
    //     0x5130d4: add             lr, x0, x17
    //     0x5130d8: ldr             lr, [x21, lr, lsl #3]
    //     0x5130dc: blr             lr
    // 0x5130e0: add             SP, SP, #8
    // 0x5130e4: r1 = LoadInt32Instr(r0)
    //     0x5130e4: sbfx            x1, x0, #1, #0x1f
    //     0x5130e8: tbz             w0, #0, #0x5130f0
    //     0x5130ec: ldur            x1, [x0, #7]
    // 0x5130f0: ldur            x2, [fp, #-0x10]
    // 0x5130f4: cmp             x2, x1
    // 0x5130f8: b.ge            #0x5131c0
    // 0x5130fc: ldr             x4, [fp, #0x18]
    // 0x513100: ldr             x3, [fp, #0x10]
    // 0x513104: r0 = BoxInt64Instr(r2)
    //     0x513104: sbfiz           x0, x2, #1, #0x1f
    //     0x513108: cmp             x2, x0, asr #1
    //     0x51310c: b.eq            #0x513118
    //     0x513110: bl              #0xd69bb8
    //     0x513114: stur            x2, [x0, #7]
    // 0x513118: mov             x1, x0
    // 0x51311c: stur            x1, [fp, #-8]
    // 0x513120: r0 = LoadClassIdInstr(r4)
    //     0x513120: ldur            x0, [x4, #-1]
    //     0x513124: ubfx            x0, x0, #0xc, #0x14
    // 0x513128: stp             x1, x4, [SP, #-0x10]!
    // 0x51312c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x51312c: sub             lr, x0, #0xd83
    //     0x513130: ldr             lr, [x21, lr, lsl #3]
    //     0x513134: blr             lr
    // 0x513138: add             SP, SP, #0x10
    // 0x51313c: mov             x2, x0
    // 0x513140: ldr             x1, [fp, #0x10]
    // 0x513144: stur            x2, [fp, #-0x18]
    // 0x513148: r0 = LoadClassIdInstr(r1)
    //     0x513148: ldur            x0, [x1, #-1]
    //     0x51314c: ubfx            x0, x0, #0xc, #0x14
    // 0x513150: ldur            x16, [fp, #-8]
    // 0x513154: stp             x16, x1, [SP, #-0x10]!
    // 0x513158: r0 = GDT[cid_x0 + -0xd83]()
    //     0x513158: sub             lr, x0, #0xd83
    //     0x51315c: ldr             lr, [x21, lr, lsl #3]
    //     0x513160: blr             lr
    // 0x513164: add             SP, SP, #0x10
    // 0x513168: mov             x1, x0
    // 0x51316c: ldur            x0, [fp, #-0x18]
    // 0x513170: r2 = 59
    //     0x513170: mov             x2, #0x3b
    // 0x513174: branchIfSmi(r0, 0x513180)
    //     0x513174: tbz             w0, #0, #0x513180
    // 0x513178: r2 = LoadClassIdInstr(r0)
    //     0x513178: ldur            x2, [x0, #-1]
    //     0x51317c: ubfx            x2, x2, #0xc, #0x14
    // 0x513180: stp             x1, x0, [SP, #-0x10]!
    // 0x513184: mov             x0, x2
    // 0x513188: mov             lr, x0
    // 0x51318c: ldr             lr, [x21, lr, lsl #3]
    // 0x513190: blr             lr
    // 0x513194: add             SP, SP, #0x10
    // 0x513198: tbz             w0, #4, #0x5131ac
    // 0x51319c: r0 = false
    //     0x51319c: add             x0, NULL, #0x30  ; false
    // 0x5131a0: LeaveFrame
    //     0x5131a0: mov             SP, fp
    //     0x5131a4: ldp             fp, lr, [SP], #0x10
    // 0x5131a8: ret
    //     0x5131a8: ret             
    // 0x5131ac: ldur            x1, [fp, #-0x10]
    // 0x5131b0: add             x3, x1, #1
    // 0x5131b4: ldr             x2, [fp, #0x18]
    // 0x5131b8: ldr             x1, [fp, #0x10]
    // 0x5131bc: b               #0x5130b4
    // 0x5131c0: r0 = true
    //     0x5131c0: add             x0, NULL, #0x20  ; true
    // 0x5131c4: LeaveFrame
    //     0x5131c4: mov             SP, fp
    //     0x5131c8: ldp             fp, lr, [SP], #0x10
    // 0x5131cc: ret
    //     0x5131cc: ret             
    // 0x5131d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5131d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5131d4: b               #0x512fd4
    // 0x5131d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5131d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5131dc: b               #0x5130c4
  }
  static _ setEquals(/* No info */) {
    // ** addr: 0x6d44d4, size: 0x1a0
    // 0x6d44d4: EnterFrame
    //     0x6d44d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6d44d8: mov             fp, SP
    // 0x6d44dc: AllocStack(0x20)
    //     0x6d44dc: sub             SP, SP, #0x20
    // 0x6d44e0: CheckStackOverflow
    //     0x6d44e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d44e4: cmp             SP, x16
    //     0x6d44e8: b.ls            #0x6d4664
    // 0x6d44ec: ldr             x0, [fp, #0x18]
    // 0x6d44f0: cmp             w0, NULL
    // 0x6d44f4: b.ne            #0x6d4518
    // 0x6d44f8: ldr             x1, [fp, #0x10]
    // 0x6d44fc: cmp             w1, NULL
    // 0x6d4500: r16 = true
    //     0x6d4500: add             x16, NULL, #0x20  ; true
    // 0x6d4504: r17 = false
    //     0x6d4504: add             x17, NULL, #0x30  ; false
    // 0x6d4508: csel            x0, x16, x17, eq
    // 0x6d450c: LeaveFrame
    //     0x6d450c: mov             SP, fp
    //     0x6d4510: ldp             fp, lr, [SP], #0x10
    // 0x6d4514: ret
    //     0x6d4514: ret             
    // 0x6d4518: ldr             x1, [fp, #0x10]
    // 0x6d451c: cmp             w1, NULL
    // 0x6d4520: b.eq            #0x6d4564
    // 0x6d4524: LoadField: r2 = r0->field_13
    //     0x6d4524: ldur            w2, [x0, #0x13]
    // 0x6d4528: DecompressPointer r2
    //     0x6d4528: add             x2, x2, HEAP, lsl #32
    // 0x6d452c: LoadField: r3 = r0->field_17
    //     0x6d452c: ldur            w3, [x0, #0x17]
    // 0x6d4530: DecompressPointer r3
    //     0x6d4530: add             x3, x3, HEAP, lsl #32
    // 0x6d4534: r4 = LoadInt32Instr(r2)
    //     0x6d4534: sbfx            x4, x2, #1, #0x1f
    // 0x6d4538: r2 = LoadInt32Instr(r3)
    //     0x6d4538: sbfx            x2, x3, #1, #0x1f
    // 0x6d453c: sub             x3, x4, x2
    // 0x6d4540: LoadField: r2 = r1->field_13
    //     0x6d4540: ldur            w2, [x1, #0x13]
    // 0x6d4544: DecompressPointer r2
    //     0x6d4544: add             x2, x2, HEAP, lsl #32
    // 0x6d4548: LoadField: r4 = r1->field_17
    //     0x6d4548: ldur            w4, [x1, #0x17]
    // 0x6d454c: DecompressPointer r4
    //     0x6d454c: add             x4, x4, HEAP, lsl #32
    // 0x6d4550: r5 = LoadInt32Instr(r2)
    //     0x6d4550: sbfx            x5, x2, #1, #0x1f
    // 0x6d4554: r2 = LoadInt32Instr(r4)
    //     0x6d4554: sbfx            x2, x4, #1, #0x1f
    // 0x6d4558: sub             x4, x5, x2
    // 0x6d455c: cmp             x3, x4
    // 0x6d4560: b.eq            #0x6d4574
    // 0x6d4564: r0 = false
    //     0x6d4564: add             x0, NULL, #0x30  ; false
    // 0x6d4568: LeaveFrame
    //     0x6d4568: mov             SP, fp
    //     0x6d456c: ldp             fp, lr, [SP], #0x10
    // 0x6d4570: ret
    //     0x6d4570: ret             
    // 0x6d4574: cmp             w0, w1
    // 0x6d4578: b.ne            #0x6d458c
    // 0x6d457c: r0 = true
    //     0x6d457c: add             x0, NULL, #0x20  ; true
    // 0x6d4580: LeaveFrame
    //     0x6d4580: mov             SP, fp
    //     0x6d4584: ldp             fp, lr, [SP], #0x10
    // 0x6d4588: ret
    //     0x6d4588: ret             
    // 0x6d458c: SaveReg r0
    //     0x6d458c: str             x0, [SP, #-8]!
    // 0x6d4590: r0 = iterator()
    //     0x6d4590: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x6d4594: add             SP, SP, #8
    // 0x6d4598: stur            x0, [fp, #-0x10]
    // 0x6d459c: LoadField: r2 = r0->field_7
    //     0x6d459c: ldur            w2, [x0, #7]
    // 0x6d45a0: DecompressPointer r2
    //     0x6d45a0: add             x2, x2, HEAP, lsl #32
    // 0x6d45a4: stur            x2, [fp, #-8]
    // 0x6d45a8: ldr             x1, [fp, #0x10]
    // 0x6d45ac: CheckStackOverflow
    //     0x6d45ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d45b0: cmp             SP, x16
    //     0x6d45b4: b.ls            #0x6d466c
    // 0x6d45b8: SaveReg r0
    //     0x6d45b8: str             x0, [SP, #-8]!
    // 0x6d45bc: r0 = moveNext()
    //     0x6d45bc: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x6d45c0: add             SP, SP, #8
    // 0x6d45c4: tbnz            w0, #4, #0x6d4654
    // 0x6d45c8: ldur            x3, [fp, #-0x10]
    // 0x6d45cc: LoadField: r4 = r3->field_33
    //     0x6d45cc: ldur            w4, [x3, #0x33]
    // 0x6d45d0: DecompressPointer r4
    //     0x6d45d0: add             x4, x4, HEAP, lsl #32
    // 0x6d45d4: stur            x4, [fp, #-0x18]
    // 0x6d45d8: cmp             w4, NULL
    // 0x6d45dc: b.ne            #0x6d460c
    // 0x6d45e0: mov             x0, x4
    // 0x6d45e4: ldur            x2, [fp, #-8]
    // 0x6d45e8: r1 = Null
    //     0x6d45e8: mov             x1, NULL
    // 0x6d45ec: cmp             w2, NULL
    // 0x6d45f0: b.eq            #0x6d460c
    // 0x6d45f4: LoadField: r4 = r2->field_17
    //     0x6d45f4: ldur            w4, [x2, #0x17]
    // 0x6d45f8: DecompressPointer r4
    //     0x6d45f8: add             x4, x4, HEAP, lsl #32
    // 0x6d45fc: r8 = X0
    //     0x6d45fc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6d4600: LoadField: r9 = r4->field_7
    //     0x6d4600: ldur            x9, [x4, #7]
    // 0x6d4604: r3 = Null
    //     0x6d4604: ldr             x3, [PP, #0x70e0]  ; [pp+0x70e0] Null
    // 0x6d4608: blr             x9
    // 0x6d460c: ldr             x0, [fp, #0x10]
    // 0x6d4610: LoadField: r1 = r0->field_f
    //     0x6d4610: ldur            w1, [x0, #0xf]
    // 0x6d4614: DecompressPointer r1
    //     0x6d4614: add             x1, x1, HEAP, lsl #32
    // 0x6d4618: stur            x1, [fp, #-0x20]
    // 0x6d461c: ldur            x16, [fp, #-0x18]
    // 0x6d4620: stp             x16, x0, [SP, #-0x10]!
    // 0x6d4624: r0 = _getKeyOrData()
    //     0x6d4624: bl              #0x5c2074  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x6d4628: add             SP, SP, #0x10
    // 0x6d462c: ldur            x1, [fp, #-0x20]
    // 0x6d4630: cmp             w1, w0
    // 0x6d4634: b.ne            #0x6d4648
    // 0x6d4638: r0 = false
    //     0x6d4638: add             x0, NULL, #0x30  ; false
    // 0x6d463c: LeaveFrame
    //     0x6d463c: mov             SP, fp
    //     0x6d4640: ldp             fp, lr, [SP], #0x10
    // 0x6d4644: ret
    //     0x6d4644: ret             
    // 0x6d4648: ldur            x0, [fp, #-0x10]
    // 0x6d464c: ldur            x2, [fp, #-8]
    // 0x6d4650: b               #0x6d45a8
    // 0x6d4654: r0 = true
    //     0x6d4654: add             x0, NULL, #0x20  ; true
    // 0x6d4658: LeaveFrame
    //     0x6d4658: mov             SP, fp
    //     0x6d465c: ldp             fp, lr, [SP], #0x10
    // 0x6d4660: ret
    //     0x6d4660: ret             
    // 0x6d4664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d4664: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4668: b               #0x6d44ec
    // 0x6d466c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d466c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4670: b               #0x6d45b8
  }
  static _ mapEquals(/* No info */) {
    // ** addr: 0x7d6da4, size: 0x24c
    // 0x7d6da4: EnterFrame
    //     0x7d6da4: stp             fp, lr, [SP, #-0x10]!
    //     0x7d6da8: mov             fp, SP
    // 0x7d6dac: AllocStack(0x18)
    //     0x7d6dac: sub             SP, SP, #0x18
    // 0x7d6db0: CheckStackOverflow
    //     0x7d6db0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7d6db4: cmp             SP, x16
    //     0x7d6db8: b.ls            #0x7d6fe0
    // 0x7d6dbc: ldr             x1, [fp, #0x18]
    // 0x7d6dc0: r0 = LoadClassIdInstr(r1)
    //     0x7d6dc0: ldur            x0, [x1, #-1]
    //     0x7d6dc4: ubfx            x0, x0, #0xc, #0x14
    // 0x7d6dc8: SaveReg r1
    //     0x7d6dc8: str             x1, [SP, #-8]!
    // 0x7d6dcc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7d6dcc: mov             x17, #0xb8ea
    //     0x7d6dd0: add             lr, x0, x17
    //     0x7d6dd4: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6dd8: blr             lr
    // 0x7d6ddc: add             SP, SP, #8
    // 0x7d6de0: mov             x2, x0
    // 0x7d6de4: ldr             x1, [fp, #0x10]
    // 0x7d6de8: stur            x2, [fp, #-8]
    // 0x7d6dec: r0 = LoadClassIdInstr(r1)
    //     0x7d6dec: ldur            x0, [x1, #-1]
    //     0x7d6df0: ubfx            x0, x0, #0xc, #0x14
    // 0x7d6df4: SaveReg r1
    //     0x7d6df4: str             x1, [SP, #-8]!
    // 0x7d6df8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7d6df8: mov             x17, #0xb8ea
    //     0x7d6dfc: add             lr, x0, x17
    //     0x7d6e00: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6e04: blr             lr
    // 0x7d6e08: add             SP, SP, #8
    // 0x7d6e0c: mov             x1, x0
    // 0x7d6e10: ldur            x0, [fp, #-8]
    // 0x7d6e14: r2 = LoadInt32Instr(r0)
    //     0x7d6e14: sbfx            x2, x0, #1, #0x1f
    //     0x7d6e18: tbz             w0, #0, #0x7d6e20
    //     0x7d6e1c: ldur            x2, [x0, #7]
    // 0x7d6e20: r0 = LoadInt32Instr(r1)
    //     0x7d6e20: sbfx            x0, x1, #1, #0x1f
    //     0x7d6e24: tbz             w1, #0, #0x7d6e2c
    //     0x7d6e28: ldur            x0, [x1, #7]
    // 0x7d6e2c: cmp             x2, x0
    // 0x7d6e30: b.eq            #0x7d6e44
    // 0x7d6e34: r0 = false
    //     0x7d6e34: add             x0, NULL, #0x30  ; false
    // 0x7d6e38: LeaveFrame
    //     0x7d6e38: mov             SP, fp
    //     0x7d6e3c: ldp             fp, lr, [SP], #0x10
    // 0x7d6e40: ret
    //     0x7d6e40: ret             
    // 0x7d6e44: ldr             x2, [fp, #0x18]
    // 0x7d6e48: ldr             x1, [fp, #0x10]
    // 0x7d6e4c: cmp             w2, w1
    // 0x7d6e50: b.ne            #0x7d6e64
    // 0x7d6e54: r0 = true
    //     0x7d6e54: add             x0, NULL, #0x20  ; true
    // 0x7d6e58: LeaveFrame
    //     0x7d6e58: mov             SP, fp
    //     0x7d6e5c: ldp             fp, lr, [SP], #0x10
    // 0x7d6e60: ret
    //     0x7d6e60: ret             
    // 0x7d6e64: r0 = LoadClassIdInstr(r2)
    //     0x7d6e64: ldur            x0, [x2, #-1]
    //     0x7d6e68: ubfx            x0, x0, #0xc, #0x14
    // 0x7d6e6c: SaveReg r2
    //     0x7d6e6c: str             x2, [SP, #-8]!
    // 0x7d6e70: r0 = GDT[cid_x0 + 0x6d7]()
    //     0x7d6e70: add             lr, x0, #0x6d7
    //     0x7d6e74: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6e78: blr             lr
    // 0x7d6e7c: add             SP, SP, #8
    // 0x7d6e80: r1 = LoadClassIdInstr(r0)
    //     0x7d6e80: ldur            x1, [x0, #-1]
    //     0x7d6e84: ubfx            x1, x1, #0xc, #0x14
    // 0x7d6e88: SaveReg r0
    //     0x7d6e88: str             x0, [SP, #-8]!
    // 0x7d6e8c: mov             x0, x1
    // 0x7d6e90: r0 = GDT[cid_x0 + 0xb940]()
    //     0x7d6e90: mov             x17, #0xb940
    //     0x7d6e94: add             lr, x0, x17
    //     0x7d6e98: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6e9c: blr             lr
    // 0x7d6ea0: add             SP, SP, #8
    // 0x7d6ea4: mov             x1, x0
    // 0x7d6ea8: stur            x1, [fp, #-8]
    // 0x7d6eac: ldr             x3, [fp, #0x18]
    // 0x7d6eb0: ldr             x2, [fp, #0x10]
    // 0x7d6eb4: CheckStackOverflow
    //     0x7d6eb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7d6eb8: cmp             SP, x16
    //     0x7d6ebc: b.ls            #0x7d6fe8
    // 0x7d6ec0: r0 = LoadClassIdInstr(r1)
    //     0x7d6ec0: ldur            x0, [x1, #-1]
    //     0x7d6ec4: ubfx            x0, x0, #0xc, #0x14
    // 0x7d6ec8: SaveReg r1
    //     0x7d6ec8: str             x1, [SP, #-8]!
    // 0x7d6ecc: r0 = GDT[cid_x0 + 0x541]()
    //     0x7d6ecc: add             lr, x0, #0x541
    //     0x7d6ed0: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6ed4: blr             lr
    // 0x7d6ed8: add             SP, SP, #8
    // 0x7d6edc: tbnz            w0, #4, #0x7d6fd0
    // 0x7d6ee0: ldr             x2, [fp, #0x10]
    // 0x7d6ee4: ldur            x1, [fp, #-8]
    // 0x7d6ee8: r0 = LoadClassIdInstr(r1)
    //     0x7d6ee8: ldur            x0, [x1, #-1]
    //     0x7d6eec: ubfx            x0, x0, #0xc, #0x14
    // 0x7d6ef0: SaveReg r1
    //     0x7d6ef0: str             x1, [SP, #-8]!
    // 0x7d6ef4: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x7d6ef4: add             lr, x0, #0x5ca
    //     0x7d6ef8: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6efc: blr             lr
    // 0x7d6f00: add             SP, SP, #8
    // 0x7d6f04: mov             x2, x0
    // 0x7d6f08: ldr             x1, [fp, #0x10]
    // 0x7d6f0c: stur            x2, [fp, #-0x10]
    // 0x7d6f10: r0 = LoadClassIdInstr(r1)
    //     0x7d6f10: ldur            x0, [x1, #-1]
    //     0x7d6f14: ubfx            x0, x0, #0xc, #0x14
    // 0x7d6f18: stp             x2, x1, [SP, #-0x10]!
    // 0x7d6f1c: r0 = GDT[cid_x0 + 0x579]()
    //     0x7d6f1c: add             lr, x0, #0x579
    //     0x7d6f20: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6f24: blr             lr
    // 0x7d6f28: add             SP, SP, #0x10
    // 0x7d6f2c: tbnz            w0, #4, #0x7d6fb8
    // 0x7d6f30: ldr             x2, [fp, #0x18]
    // 0x7d6f34: ldr             x1, [fp, #0x10]
    // 0x7d6f38: r0 = LoadClassIdInstr(r1)
    //     0x7d6f38: ldur            x0, [x1, #-1]
    //     0x7d6f3c: ubfx            x0, x0, #0xc, #0x14
    // 0x7d6f40: ldur            x16, [fp, #-0x10]
    // 0x7d6f44: stp             x16, x1, [SP, #-0x10]!
    // 0x7d6f48: r0 = GDT[cid_x0 + -0xef]()
    //     0x7d6f48: sub             lr, x0, #0xef
    //     0x7d6f4c: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6f50: blr             lr
    // 0x7d6f54: add             SP, SP, #0x10
    // 0x7d6f58: mov             x2, x0
    // 0x7d6f5c: ldr             x1, [fp, #0x18]
    // 0x7d6f60: stur            x2, [fp, #-0x18]
    // 0x7d6f64: r0 = LoadClassIdInstr(r1)
    //     0x7d6f64: ldur            x0, [x1, #-1]
    //     0x7d6f68: ubfx            x0, x0, #0xc, #0x14
    // 0x7d6f6c: ldur            x16, [fp, #-0x10]
    // 0x7d6f70: stp             x16, x1, [SP, #-0x10]!
    // 0x7d6f74: r0 = GDT[cid_x0 + -0xef]()
    //     0x7d6f74: sub             lr, x0, #0xef
    //     0x7d6f78: ldr             lr, [x21, lr, lsl #3]
    //     0x7d6f7c: blr             lr
    // 0x7d6f80: add             SP, SP, #0x10
    // 0x7d6f84: mov             x1, x0
    // 0x7d6f88: ldur            x0, [fp, #-0x18]
    // 0x7d6f8c: r2 = 59
    //     0x7d6f8c: mov             x2, #0x3b
    // 0x7d6f90: branchIfSmi(r0, 0x7d6f9c)
    //     0x7d6f90: tbz             w0, #0, #0x7d6f9c
    // 0x7d6f94: r2 = LoadClassIdInstr(r0)
    //     0x7d6f94: ldur            x2, [x0, #-1]
    //     0x7d6f98: ubfx            x2, x2, #0xc, #0x14
    // 0x7d6f9c: stp             x1, x0, [SP, #-0x10]!
    // 0x7d6fa0: mov             x0, x2
    // 0x7d6fa4: mov             lr, x0
    // 0x7d6fa8: ldr             lr, [x21, lr, lsl #3]
    // 0x7d6fac: blr             lr
    // 0x7d6fb0: add             SP, SP, #0x10
    // 0x7d6fb4: tbz             w0, #4, #0x7d6fc8
    // 0x7d6fb8: r0 = false
    //     0x7d6fb8: add             x0, NULL, #0x30  ; false
    // 0x7d6fbc: LeaveFrame
    //     0x7d6fbc: mov             SP, fp
    //     0x7d6fc0: ldp             fp, lr, [SP], #0x10
    // 0x7d6fc4: ret
    //     0x7d6fc4: ret             
    // 0x7d6fc8: ldur            x1, [fp, #-8]
    // 0x7d6fcc: b               #0x7d6eac
    // 0x7d6fd0: r0 = true
    //     0x7d6fd0: add             x0, NULL, #0x20  ; true
    // 0x7d6fd4: LeaveFrame
    //     0x7d6fd4: mov             SP, fp
    //     0x7d6fd8: ldp             fp, lr, [SP], #0x10
    // 0x7d6fdc: ret
    //     0x7d6fdc: ret             
    // 0x7d6fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7d6fe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7d6fe4: b               #0x7d6dbc
    // 0x7d6fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7d6fe8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7d6fec: b               #0x7d6ec0
  }
  static _ mergeSort(/* No info */) {
    // ** addr: 0xcc6f10, size: 0x2e8
    // 0xcc6f10: EnterFrame
    //     0xcc6f10: stp             fp, lr, [SP, #-0x10]!
    //     0xcc6f14: mov             fp, SP
    // 0xcc6f18: AllocStack(0x50)
    //     0xcc6f18: sub             SP, SP, #0x50
    // 0xcc6f1c: SetupParameters(dynamic _ /* r1, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xcc6f1c: mov             x0, x4
    //     0xcc6f20: ldur            w1, [x0, #0x13]
    //     0xcc6f24: add             x1, x1, HEAP, lsl #32
    //     0xcc6f28: sub             x2, x1, #4
    //     0xcc6f2c: add             x1, fp, w2, sxtw #2
    //     0xcc6f30: ldr             x1, [x1, #0x18]
    //     0xcc6f34: stur            x1, [fp, #-0x18]
    //     0xcc6f38: add             x3, fp, w2, sxtw #2
    //     0xcc6f3c: ldr             x3, [x3, #0x10]
    //     0xcc6f40: stur            x3, [fp, #-0x10]
    //     0xcc6f44: ldur            w2, [x0, #0xf]
    //     0xcc6f48: add             x2, x2, HEAP, lsl #32
    //     0xcc6f4c: cbnz            w2, #0xcc6f58
    //     0xcc6f50: mov             x2, NULL
    //     0xcc6f54: b               #0xcc6f6c
    //     0xcc6f58: ldur            w2, [x0, #0x17]
    //     0xcc6f5c: add             x2, x2, HEAP, lsl #32
    //     0xcc6f60: add             x0, fp, w2, sxtw #2
    //     0xcc6f64: ldr             x0, [x0, #0x10]
    //     0xcc6f68: mov             x2, x0
    //     0xcc6f6c: stur            x2, [fp, #-8]
    // 0xcc6f70: CheckStackOverflow
    //     0xcc6f70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc6f74: cmp             SP, x16
    //     0xcc6f78: b.ls            #0xcc71e8
    // 0xcc6f7c: r0 = LoadClassIdInstr(r1)
    //     0xcc6f7c: ldur            x0, [x1, #-1]
    //     0xcc6f80: ubfx            x0, x0, #0xc, #0x14
    // 0xcc6f84: SaveReg r1
    //     0xcc6f84: str             x1, [SP, #-8]!
    // 0xcc6f88: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcc6f88: mov             x17, #0xb8ea
    //     0xcc6f8c: add             lr, x0, x17
    //     0xcc6f90: ldr             lr, [x21, lr, lsl #3]
    //     0xcc6f94: blr             lr
    // 0xcc6f98: add             SP, SP, #8
    // 0xcc6f9c: mov             x1, x0
    // 0xcc6fa0: stur            x1, [fp, #-0x30]
    // 0xcc6fa4: r0 = LoadInt32Instr(r1)
    //     0xcc6fa4: sbfx            x0, x1, #1, #0x1f
    //     0xcc6fa8: tbz             w1, #0, #0xcc6fb0
    //     0xcc6fac: ldur            x0, [x1, #7]
    // 0xcc6fb0: cmp             x0, #2
    // 0xcc6fb4: b.ge            #0xcc6fc8
    // 0xcc6fb8: r0 = Null
    //     0xcc6fb8: mov             x0, NULL
    // 0xcc6fbc: LeaveFrame
    //     0xcc6fbc: mov             SP, fp
    //     0xcc6fc0: ldp             fp, lr, [SP], #0x10
    // 0xcc6fc4: ret
    //     0xcc6fc4: ret             
    // 0xcc6fc8: cmp             x0, #0x20
    // 0xcc6fcc: b.ge            #0xcc7000
    // 0xcc6fd0: ldur            x16, [fp, #-8]
    // 0xcc6fd4: ldur            lr, [fp, #-0x18]
    // 0xcc6fd8: stp             lr, x16, [SP, #-0x10]!
    // 0xcc6fdc: ldur            x16, [fp, #-0x10]
    // 0xcc6fe0: stp             x0, x16, [SP, #-0x10]!
    // 0xcc6fe4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xcc6fe4: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xcc6fe8: r0 = _insertionSort()
    //     0xcc6fe8: bl              #0xcc7c08  ; [package:flutter/src/foundation/collections.dart] ::_insertionSort
    // 0xcc6fec: add             SP, SP, #0x20
    // 0xcc6ff0: r0 = Null
    //     0xcc6ff0: mov             x0, NULL
    // 0xcc6ff4: LeaveFrame
    //     0xcc6ff4: mov             SP, fp
    //     0xcc6ff8: ldp             fp, lr, [SP], #0x10
    // 0xcc6ffc: ret
    //     0xcc6ffc: ret             
    // 0xcc7000: ldur            x2, [fp, #-0x18]
    // 0xcc7004: asr             x3, x0, #1
    // 0xcc7008: stur            x3, [fp, #-0x28]
    // 0xcc700c: sub             x4, x0, x3
    // 0xcc7010: stur            x4, [fp, #-0x20]
    // 0xcc7014: r0 = LoadClassIdInstr(r2)
    //     0xcc7014: ldur            x0, [x2, #-1]
    //     0xcc7018: ubfx            x0, x0, #0xc, #0x14
    // 0xcc701c: stp             xzr, x2, [SP, #-0x10]!
    // 0xcc7020: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc7020: sub             lr, x0, #0xd83
    //     0xcc7024: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7028: blr             lr
    // 0xcc702c: add             SP, SP, #0x10
    // 0xcc7030: mov             x4, x0
    // 0xcc7034: ldur            x3, [fp, #-0x20]
    // 0xcc7038: stur            x4, [fp, #-0x40]
    // 0xcc703c: r0 = BoxInt64Instr(r3)
    //     0xcc703c: sbfiz           x0, x3, #1, #0x1f
    //     0xcc7040: cmp             x3, x0, asr #1
    //     0xcc7044: b.eq            #0xcc7050
    //     0xcc7048: bl              #0xd69bb8
    //     0xcc704c: stur            x3, [x0, #7]
    // 0xcc7050: ldur            x1, [fp, #-8]
    // 0xcc7054: mov             x2, x0
    // 0xcc7058: stur            x0, [fp, #-0x38]
    // 0xcc705c: r0 = AllocateArray()
    //     0xcc705c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xcc7060: mov             x4, x0
    // 0xcc7064: ldur            x3, [fp, #-0x40]
    // 0xcc7068: stur            x4, [fp, #-0x50]
    // 0xcc706c: cmp             w3, NULL
    // 0xcc7070: b.eq            #0xcc7108
    // 0xcc7074: r6 = 0
    //     0xcc7074: mov             x6, #0
    // 0xcc7078: ldur            x5, [fp, #-0x20]
    // 0xcc707c: stur            x6, [fp, #-0x48]
    // 0xcc7080: CheckStackOverflow
    //     0xcc7080: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc7084: cmp             SP, x16
    //     0xcc7088: b.ls            #0xcc71f0
    // 0xcc708c: cmp             x6, x5
    // 0xcc7090: b.ge            #0xcc7108
    // 0xcc7094: mov             x0, x3
    // 0xcc7098: ldur            x2, [fp, #-8]
    // 0xcc709c: r1 = Null
    //     0xcc709c: mov             x1, NULL
    // 0xcc70a0: cmp             w2, NULL
    // 0xcc70a4: b.eq            #0xcc70c4
    // 0xcc70a8: LoadField: r4 = r2->field_17
    //     0xcc70a8: ldur            w4, [x2, #0x17]
    // 0xcc70ac: DecompressPointer r4
    //     0xcc70ac: add             x4, x4, HEAP, lsl #32
    // 0xcc70b0: r8 = X0
    //     0xcc70b0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xcc70b4: LoadField: r9 = r4->field_7
    //     0xcc70b4: ldur            x9, [x4, #7]
    // 0xcc70b8: r3 = Null
    //     0xcc70b8: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3f408] Null
    //     0xcc70bc: ldr             x3, [x3, #0x408]
    // 0xcc70c0: blr             x9
    // 0xcc70c4: ldur            x1, [fp, #-0x50]
    // 0xcc70c8: ldur            x0, [fp, #-0x40]
    // 0xcc70cc: ldur            x2, [fp, #-0x48]
    // 0xcc70d0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xcc70d0: add             x25, x1, x2, lsl #2
    //     0xcc70d4: add             x25, x25, #0xf
    //     0xcc70d8: str             w0, [x25]
    //     0xcc70dc: tbz             w0, #0, #0xcc70f8
    //     0xcc70e0: ldurb           w16, [x1, #-1]
    //     0xcc70e4: ldurb           w17, [x0, #-1]
    //     0xcc70e8: and             x16, x17, x16, lsr #2
    //     0xcc70ec: tst             x16, HEAP, lsr #32
    //     0xcc70f0: b.eq            #0xcc70f8
    //     0xcc70f4: bl              #0xd67e5c
    // 0xcc70f8: add             x6, x2, #1
    // 0xcc70fc: ldur            x3, [fp, #-0x40]
    // 0xcc7100: ldur            x4, [fp, #-0x50]
    // 0xcc7104: b               #0xcc7078
    // 0xcc7108: ldur            x3, [fp, #-0x28]
    // 0xcc710c: ldur            x2, [fp, #-0x20]
    // 0xcc7110: r0 = BoxInt64Instr(r3)
    //     0xcc7110: sbfiz           x0, x3, #1, #0x1f
    //     0xcc7114: cmp             x3, x0, asr #1
    //     0xcc7118: b.eq            #0xcc7124
    //     0xcc711c: bl              #0xd69bb8
    //     0xcc7120: stur            x3, [x0, #7]
    // 0xcc7124: stur            x0, [fp, #-0x40]
    // 0xcc7128: ldur            x16, [fp, #-8]
    // 0xcc712c: ldur            lr, [fp, #-0x18]
    // 0xcc7130: stp             lr, x16, [SP, #-0x10]!
    // 0xcc7134: ldur            x16, [fp, #-0x10]
    // 0xcc7138: stp             x0, x16, [SP, #-0x10]!
    // 0xcc713c: ldur            x16, [fp, #-0x30]
    // 0xcc7140: ldur            lr, [fp, #-0x50]
    // 0xcc7144: stp             lr, x16, [SP, #-0x10]!
    // 0xcc7148: SaveReg rZR
    //     0xcc7148: str             xzr, [SP, #-8]!
    // 0xcc714c: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xcc714c: add             x4, PP, #0x12, lsl #12  ; [pp+0x12cb8] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xcc7150: ldr             x4, [x4, #0xcb8]
    // 0xcc7154: r0 = _mergeSort()
    //     0xcc7154: bl              #0xcc76e4  ; [package:flutter/src/foundation/collections.dart] ::_mergeSort
    // 0xcc7158: add             SP, SP, #0x38
    // 0xcc715c: ldur            x16, [fp, #-8]
    // 0xcc7160: ldur            lr, [fp, #-0x18]
    // 0xcc7164: stp             lr, x16, [SP, #-0x10]!
    // 0xcc7168: ldur            x16, [fp, #-0x10]
    // 0xcc716c: stp             xzr, x16, [SP, #-0x10]!
    // 0xcc7170: ldur            x16, [fp, #-0x40]
    // 0xcc7174: ldur            lr, [fp, #-0x18]
    // 0xcc7178: stp             lr, x16, [SP, #-0x10]!
    // 0xcc717c: ldur            x0, [fp, #-0x20]
    // 0xcc7180: SaveReg r0
    //     0xcc7180: str             x0, [SP, #-8]!
    // 0xcc7184: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xcc7184: add             x4, PP, #0x12, lsl #12  ; [pp+0x12cb8] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xcc7188: ldr             x4, [x4, #0xcb8]
    // 0xcc718c: r0 = _mergeSort()
    //     0xcc718c: bl              #0xcc76e4  ; [package:flutter/src/foundation/collections.dart] ::_mergeSort
    // 0xcc7190: add             SP, SP, #0x38
    // 0xcc7194: ldur            x16, [fp, #-8]
    // 0xcc7198: ldur            lr, [fp, #-0x10]
    // 0xcc719c: stp             lr, x16, [SP, #-0x10]!
    // 0xcc71a0: ldur            x16, [fp, #-0x18]
    // 0xcc71a4: ldur            lr, [fp, #-0x38]
    // 0xcc71a8: stp             lr, x16, [SP, #-0x10]!
    // 0xcc71ac: ldur            x16, [fp, #-0x30]
    // 0xcc71b0: ldur            lr, [fp, #-0x50]
    // 0xcc71b4: stp             lr, x16, [SP, #-0x10]!
    // 0xcc71b8: ldur            x16, [fp, #-0x38]
    // 0xcc71bc: stp             x16, xzr, [SP, #-0x10]!
    // 0xcc71c0: ldur            x16, [fp, #-0x18]
    // 0xcc71c4: stp             xzr, x16, [SP, #-0x10]!
    // 0xcc71c8: r4 = const [0x1, 0x9, 0x9, 0x9, null]
    //     0xcc71c8: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f418] List(5) [0x1, 0x9, 0x9, 0x9, Null]
    //     0xcc71cc: ldr             x4, [x4, #0x418]
    // 0xcc71d0: r0 = _merge()
    //     0xcc71d0: bl              #0xcc71f8  ; [package:flutter/src/foundation/collections.dart] ::_merge
    // 0xcc71d4: add             SP, SP, #0x50
    // 0xcc71d8: r0 = Null
    //     0xcc71d8: mov             x0, NULL
    // 0xcc71dc: LeaveFrame
    //     0xcc71dc: mov             SP, fp
    //     0xcc71e0: ldp             fp, lr, [SP], #0x10
    // 0xcc71e4: ret
    //     0xcc71e4: ret             
    // 0xcc71e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc71e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc71ec: b               #0xcc6f7c
    // 0xcc71f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc71f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc71f4: b               #0xcc708c
  }
  static _ _merge(/* No info */) {
    // ** addr: 0xcc71f8, size: 0x4ec
    // 0xcc71f8: EnterFrame
    //     0xcc71f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcc71fc: mov             fp, SP
    // 0xcc7200: AllocStack(0x48)
    //     0xcc7200: sub             SP, SP, #0x48
    // 0xcc7204: CheckStackOverflow
    //     0xcc7204: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc7208: cmp             SP, x16
    //     0xcc720c: b.ls            #0xcc76d0
    // 0xcc7210: ldr             x0, [fp, #0x40]
    // 0xcc7214: r1 = LoadInt32Instr(r0)
    //     0xcc7214: sbfx            x1, x0, #1, #0x1f
    //     0xcc7218: tbz             w0, #0, #0xcc7220
    //     0xcc721c: ldur            x1, [x0, #7]
    // 0xcc7220: add             x2, x1, #1
    // 0xcc7224: ldr             x1, [fp, #0x48]
    // 0xcc7228: stur            x2, [fp, #-8]
    // 0xcc722c: r3 = LoadClassIdInstr(r1)
    //     0xcc722c: ldur            x3, [x1, #-1]
    //     0xcc7230: ubfx            x3, x3, #0xc, #0x14
    // 0xcc7234: stp             x0, x1, [SP, #-0x10]!
    // 0xcc7238: mov             x0, x3
    // 0xcc723c: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc723c: sub             lr, x0, #0xd83
    //     0xcc7240: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7244: blr             lr
    // 0xcc7248: add             SP, SP, #0x10
    // 0xcc724c: mov             x1, x0
    // 0xcc7250: ldr             x0, [fp, #0x28]
    // 0xcc7254: stur            x1, [fp, #-0x18]
    // 0xcc7258: r2 = LoadInt32Instr(r0)
    //     0xcc7258: sbfx            x2, x0, #1, #0x1f
    //     0xcc725c: tbz             w0, #0, #0xcc7264
    //     0xcc7260: ldur            x2, [x0, #7]
    // 0xcc7264: add             x3, x2, #1
    // 0xcc7268: ldr             x2, [fp, #0x30]
    // 0xcc726c: stur            x3, [fp, #-0x10]
    // 0xcc7270: r4 = LoadClassIdInstr(r2)
    //     0xcc7270: ldur            x4, [x2, #-1]
    //     0xcc7274: ubfx            x4, x4, #0xc, #0x14
    // 0xcc7278: stp             x0, x2, [SP, #-0x10]!
    // 0xcc727c: mov             x0, x4
    // 0xcc7280: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc7280: sub             lr, x0, #0xd83
    //     0xcc7284: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7288: blr             lr
    // 0xcc728c: add             SP, SP, #0x10
    // 0xcc7290: ldr             x1, [fp, #0x20]
    // 0xcc7294: r2 = LoadInt32Instr(r1)
    //     0xcc7294: sbfx            x2, x1, #1, #0x1f
    //     0xcc7298: tbz             w1, #0, #0xcc72a0
    //     0xcc729c: ldur            x2, [x1, #7]
    // 0xcc72a0: ldr             x3, [fp, #0x38]
    // 0xcc72a4: stur            x2, [fp, #-0x38]
    // 0xcc72a8: r4 = LoadInt32Instr(r3)
    //     0xcc72a8: sbfx            x4, x3, #1, #0x1f
    //     0xcc72ac: tbz             w3, #0, #0xcc72b4
    //     0xcc72b0: ldur            x4, [x3, #7]
    // 0xcc72b4: ldr             x5, [fp, #0x10]
    // 0xcc72b8: stur            x4, [fp, #-0x30]
    // 0xcc72bc: mov             x12, x5
    // 0xcc72c0: ldur            x11, [fp, #-8]
    // 0xcc72c4: ldur            x10, [fp, #-0x10]
    // 0xcc72c8: ldur            x9, [fp, #-0x18]
    // 0xcc72cc: mov             x8, x0
    // 0xcc72d0: ldr             x6, [fp, #0x48]
    // 0xcc72d4: ldr             x5, [fp, #0x30]
    // 0xcc72d8: ldr             x7, [fp, #0x18]
    // 0xcc72dc: stur            x12, [fp, #-8]
    // 0xcc72e0: stur            x11, [fp, #-0x10]
    // 0xcc72e4: stur            x10, [fp, #-0x20]
    // 0xcc72e8: stur            x9, [fp, #-0x18]
    // 0xcc72ec: stur            x8, [fp, #-0x28]
    // 0xcc72f0: CheckStackOverflow
    //     0xcc72f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc72f4: cmp             SP, x16
    //     0xcc72f8: b.ls            #0xcc76d8
    // 0xcc72fc: ldr             x16, [fp, #0x50]
    // 0xcc7300: stp             x9, x16, [SP, #-0x10]!
    // 0xcc7304: SaveReg r8
    //     0xcc7304: str             x8, [SP, #-8]!
    // 0xcc7308: ldr             x0, [fp, #0x50]
    // 0xcc730c: ClosureCall
    //     0xcc730c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xcc7310: ldur            x2, [x0, #0x1f]
    //     0xcc7314: blr             x2
    // 0xcc7318: add             SP, SP, #0x18
    // 0xcc731c: cmp             w0, NULL
    // 0xcc7320: b.eq            #0xcc76e0
    // 0xcc7324: r1 = LoadInt32Instr(r0)
    //     0xcc7324: sbfx            x1, x0, #1, #0x1f
    //     0xcc7328: tbz             w0, #0, #0xcc7330
    //     0xcc732c: ldur            x1, [x0, #7]
    // 0xcc7330: cmp             x1, #0
    // 0xcc7334: b.gt            #0xcc7500
    // 0xcc7338: ldr             x3, [fp, #0x18]
    // 0xcc733c: ldur            x5, [fp, #-8]
    // 0xcc7340: ldur            x4, [fp, #-0x10]
    // 0xcc7344: ldur            x2, [fp, #-0x30]
    // 0xcc7348: add             x6, x5, #1
    // 0xcc734c: stur            x6, [fp, #-0x40]
    // 0xcc7350: r0 = BoxInt64Instr(r5)
    //     0xcc7350: sbfiz           x0, x5, #1, #0x1f
    //     0xcc7354: cmp             x5, x0, asr #1
    //     0xcc7358: b.eq            #0xcc7364
    //     0xcc735c: bl              #0xd69bb8
    //     0xcc7360: stur            x5, [x0, #7]
    // 0xcc7364: r1 = LoadClassIdInstr(r3)
    //     0xcc7364: ldur            x1, [x3, #-1]
    //     0xcc7368: ubfx            x1, x1, #0xc, #0x14
    // 0xcc736c: stp             x0, x3, [SP, #-0x10]!
    // 0xcc7370: ldur            x16, [fp, #-0x18]
    // 0xcc7374: SaveReg r16
    //     0xcc7374: str             x16, [SP, #-8]!
    // 0xcc7378: mov             x0, x1
    // 0xcc737c: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xcc737c: mov             x17, #0x15e
    //     0xcc7380: movk            x17, #1, lsl #16
    //     0xcc7384: add             lr, x0, x17
    //     0xcc7388: ldr             lr, [x21, lr, lsl #3]
    //     0xcc738c: blr             lr
    // 0xcc7390: add             SP, SP, #0x18
    // 0xcc7394: ldur            x3, [fp, #-0x10]
    // 0xcc7398: ldur            x2, [fp, #-0x30]
    // 0xcc739c: cmp             x3, x2
    // 0xcc73a0: b.ne            #0xcc7498
    // 0xcc73a4: ldr             x3, [fp, #0x20]
    // 0xcc73a8: ldr             x2, [fp, #0x18]
    // 0xcc73ac: ldur            x5, [fp, #-0x20]
    // 0xcc73b0: ldur            x4, [fp, #-0x40]
    // 0xcc73b4: add             x6, x4, #1
    // 0xcc73b8: stur            x6, [fp, #-0x48]
    // 0xcc73bc: r0 = BoxInt64Instr(r4)
    //     0xcc73bc: sbfiz           x0, x4, #1, #0x1f
    //     0xcc73c0: cmp             x4, x0, asr #1
    //     0xcc73c4: b.eq            #0xcc73d0
    //     0xcc73c8: bl              #0xd69bb8
    //     0xcc73cc: stur            x4, [x0, #7]
    // 0xcc73d0: r1 = LoadClassIdInstr(r2)
    //     0xcc73d0: ldur            x1, [x2, #-1]
    //     0xcc73d4: ubfx            x1, x1, #0xc, #0x14
    // 0xcc73d8: stp             x0, x2, [SP, #-0x10]!
    // 0xcc73dc: ldur            x16, [fp, #-0x28]
    // 0xcc73e0: SaveReg r16
    //     0xcc73e0: str             x16, [SP, #-8]!
    // 0xcc73e4: mov             x0, x1
    // 0xcc73e8: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xcc73e8: mov             x17, #0x15e
    //     0xcc73ec: movk            x17, #1, lsl #16
    //     0xcc73f0: add             lr, x0, x17
    //     0xcc73f4: ldr             lr, [x21, lr, lsl #3]
    //     0xcc73f8: blr             lr
    // 0xcc73fc: add             SP, SP, #0x18
    // 0xcc7400: ldr             x5, [fp, #0x20]
    // 0xcc7404: r0 = LoadInt32Instr(r5)
    //     0xcc7404: sbfx            x0, x5, #1, #0x1f
    //     0xcc7408: tbz             w5, #0, #0xcc7410
    //     0xcc740c: ldur            x0, [x5, #7]
    // 0xcc7410: ldur            x6, [fp, #-0x20]
    // 0xcc7414: sub             x1, x0, x6
    // 0xcc7418: ldur            x2, [fp, #-0x48]
    // 0xcc741c: add             x3, x2, x1
    // 0xcc7420: r0 = BoxInt64Instr(r6)
    //     0xcc7420: sbfiz           x0, x6, #1, #0x1f
    //     0xcc7424: cmp             x6, x0, asr #1
    //     0xcc7428: b.eq            #0xcc7434
    //     0xcc742c: bl              #0xd69bb8
    //     0xcc7430: stur            x6, [x0, #7]
    // 0xcc7434: mov             x4, x0
    // 0xcc7438: r0 = BoxInt64Instr(r2)
    //     0xcc7438: sbfiz           x0, x2, #1, #0x1f
    //     0xcc743c: cmp             x2, x0, asr #1
    //     0xcc7440: b.eq            #0xcc744c
    //     0xcc7444: bl              #0xd69bb8
    //     0xcc7448: stur            x2, [x0, #7]
    // 0xcc744c: ldr             x7, [fp, #0x18]
    // 0xcc7450: r1 = LoadClassIdInstr(r7)
    //     0xcc7450: ldur            x1, [x7, #-1]
    //     0xcc7454: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7458: stp             x0, x7, [SP, #-0x10]!
    // 0xcc745c: ldr             x16, [fp, #0x30]
    // 0xcc7460: stp             x16, x3, [SP, #-0x10]!
    // 0xcc7464: SaveReg r4
    //     0xcc7464: str             x4, [SP, #-8]!
    // 0xcc7468: mov             x0, x1
    // 0xcc746c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xcc746c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xcc7470: r0 = GDT[cid_x0 + 0x10330]()
    //     0xcc7470: mov             x17, #0x330
    //     0xcc7474: movk            x17, #1, lsl #16
    //     0xcc7478: add             lr, x0, x17
    //     0xcc747c: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7480: blr             lr
    // 0xcc7484: add             SP, SP, #0x28
    // 0xcc7488: r0 = Null
    //     0xcc7488: mov             x0, NULL
    // 0xcc748c: LeaveFrame
    //     0xcc748c: mov             SP, fp
    //     0xcc7490: ldp             fp, lr, [SP], #0x10
    // 0xcc7494: ret
    //     0xcc7494: ret             
    // 0xcc7498: ldr             x8, [fp, #0x48]
    // 0xcc749c: ldr             x5, [fp, #0x20]
    // 0xcc74a0: ldr             x7, [fp, #0x18]
    // 0xcc74a4: ldur            x6, [fp, #-0x20]
    // 0xcc74a8: ldur            x4, [fp, #-0x40]
    // 0xcc74ac: add             x9, x3, #1
    // 0xcc74b0: stur            x9, [fp, #-0x48]
    // 0xcc74b4: r0 = BoxInt64Instr(r3)
    //     0xcc74b4: sbfiz           x0, x3, #1, #0x1f
    //     0xcc74b8: cmp             x3, x0, asr #1
    //     0xcc74bc: b.eq            #0xcc74c8
    //     0xcc74c0: bl              #0xd69bb8
    //     0xcc74c4: stur            x3, [x0, #7]
    // 0xcc74c8: r1 = LoadClassIdInstr(r8)
    //     0xcc74c8: ldur            x1, [x8, #-1]
    //     0xcc74cc: ubfx            x1, x1, #0xc, #0x14
    // 0xcc74d0: stp             x0, x8, [SP, #-0x10]!
    // 0xcc74d4: mov             x0, x1
    // 0xcc74d8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc74d8: sub             lr, x0, #0xd83
    //     0xcc74dc: ldr             lr, [x21, lr, lsl #3]
    //     0xcc74e0: blr             lr
    // 0xcc74e4: add             SP, SP, #0x10
    // 0xcc74e8: ldur            x12, [fp, #-0x40]
    // 0xcc74ec: ldur            x11, [fp, #-0x48]
    // 0xcc74f0: ldur            x10, [fp, #-0x20]
    // 0xcc74f4: mov             x9, x0
    // 0xcc74f8: ldur            x8, [fp, #-0x28]
    // 0xcc74fc: b               #0xcc75c4
    // 0xcc7500: ldr             x4, [fp, #0x18]
    // 0xcc7504: ldur            x5, [fp, #-8]
    // 0xcc7508: ldur            x3, [fp, #-0x10]
    // 0xcc750c: ldur            x2, [fp, #-0x20]
    // 0xcc7510: ldur            x6, [fp, #-0x38]
    // 0xcc7514: add             x7, x5, #1
    // 0xcc7518: stur            x7, [fp, #-0x40]
    // 0xcc751c: r0 = BoxInt64Instr(r5)
    //     0xcc751c: sbfiz           x0, x5, #1, #0x1f
    //     0xcc7520: cmp             x5, x0, asr #1
    //     0xcc7524: b.eq            #0xcc7530
    //     0xcc7528: bl              #0xd69bb8
    //     0xcc752c: stur            x5, [x0, #7]
    // 0xcc7530: r1 = LoadClassIdInstr(r4)
    //     0xcc7530: ldur            x1, [x4, #-1]
    //     0xcc7534: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7538: stp             x0, x4, [SP, #-0x10]!
    // 0xcc753c: ldur            x16, [fp, #-0x28]
    // 0xcc7540: SaveReg r16
    //     0xcc7540: str             x16, [SP, #-8]!
    // 0xcc7544: mov             x0, x1
    // 0xcc7548: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xcc7548: mov             x17, #0x15e
    //     0xcc754c: movk            x17, #1, lsl #16
    //     0xcc7550: add             lr, x0, x17
    //     0xcc7554: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7558: blr             lr
    // 0xcc755c: add             SP, SP, #0x18
    // 0xcc7560: ldur            x2, [fp, #-0x20]
    // 0xcc7564: ldur            x3, [fp, #-0x38]
    // 0xcc7568: cmp             x2, x3
    // 0xcc756c: b.eq            #0xcc75d8
    // 0xcc7570: ldr             x4, [fp, #0x30]
    // 0xcc7574: add             x5, x2, #1
    // 0xcc7578: stur            x5, [fp, #-8]
    // 0xcc757c: r0 = BoxInt64Instr(r2)
    //     0xcc757c: sbfiz           x0, x2, #1, #0x1f
    //     0xcc7580: cmp             x2, x0, asr #1
    //     0xcc7584: b.eq            #0xcc7590
    //     0xcc7588: bl              #0xd69bb8
    //     0xcc758c: stur            x2, [x0, #7]
    // 0xcc7590: r1 = LoadClassIdInstr(r4)
    //     0xcc7590: ldur            x1, [x4, #-1]
    //     0xcc7594: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7598: stp             x0, x4, [SP, #-0x10]!
    // 0xcc759c: mov             x0, x1
    // 0xcc75a0: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc75a0: sub             lr, x0, #0xd83
    //     0xcc75a4: ldr             lr, [x21, lr, lsl #3]
    //     0xcc75a8: blr             lr
    // 0xcc75ac: add             SP, SP, #0x10
    // 0xcc75b0: ldur            x12, [fp, #-0x40]
    // 0xcc75b4: ldur            x11, [fp, #-0x10]
    // 0xcc75b8: ldur            x10, [fp, #-8]
    // 0xcc75bc: ldur            x9, [fp, #-0x18]
    // 0xcc75c0: mov             x8, x0
    // 0xcc75c4: ldr             x3, [fp, #0x38]
    // 0xcc75c8: ldr             x1, [fp, #0x20]
    // 0xcc75cc: ldur            x4, [fp, #-0x30]
    // 0xcc75d0: ldur            x2, [fp, #-0x38]
    // 0xcc75d4: b               #0xcc72d0
    // 0xcc75d8: ldr             x5, [fp, #0x38]
    // 0xcc75dc: ldr             x3, [fp, #0x18]
    // 0xcc75e0: ldur            x2, [fp, #-0x10]
    // 0xcc75e4: ldur            x4, [fp, #-0x40]
    // 0xcc75e8: add             x6, x4, #1
    // 0xcc75ec: stur            x6, [fp, #-8]
    // 0xcc75f0: r0 = BoxInt64Instr(r4)
    //     0xcc75f0: sbfiz           x0, x4, #1, #0x1f
    //     0xcc75f4: cmp             x4, x0, asr #1
    //     0xcc75f8: b.eq            #0xcc7604
    //     0xcc75fc: bl              #0xd69bb8
    //     0xcc7600: stur            x4, [x0, #7]
    // 0xcc7604: r1 = LoadClassIdInstr(r3)
    //     0xcc7604: ldur            x1, [x3, #-1]
    //     0xcc7608: ubfx            x1, x1, #0xc, #0x14
    // 0xcc760c: stp             x0, x3, [SP, #-0x10]!
    // 0xcc7610: ldur            x16, [fp, #-0x18]
    // 0xcc7614: SaveReg r16
    //     0xcc7614: str             x16, [SP, #-8]!
    // 0xcc7618: mov             x0, x1
    // 0xcc761c: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xcc761c: mov             x17, #0x15e
    //     0xcc7620: movk            x17, #1, lsl #16
    //     0xcc7624: add             lr, x0, x17
    //     0xcc7628: ldr             lr, [x21, lr, lsl #3]
    //     0xcc762c: blr             lr
    // 0xcc7630: add             SP, SP, #0x18
    // 0xcc7634: ldr             x0, [fp, #0x38]
    // 0xcc7638: r1 = LoadInt32Instr(r0)
    //     0xcc7638: sbfx            x1, x0, #1, #0x1f
    //     0xcc763c: tbz             w0, #0, #0xcc7644
    //     0xcc7640: ldur            x1, [x0, #7]
    // 0xcc7644: ldur            x2, [fp, #-0x10]
    // 0xcc7648: sub             x0, x1, x2
    // 0xcc764c: ldur            x3, [fp, #-8]
    // 0xcc7650: add             x4, x3, x0
    // 0xcc7654: r0 = BoxInt64Instr(r2)
    //     0xcc7654: sbfiz           x0, x2, #1, #0x1f
    //     0xcc7658: cmp             x2, x0, asr #1
    //     0xcc765c: b.eq            #0xcc7668
    //     0xcc7660: bl              #0xd69bb8
    //     0xcc7664: stur            x2, [x0, #7]
    // 0xcc7668: mov             x2, x0
    // 0xcc766c: r0 = BoxInt64Instr(r3)
    //     0xcc766c: sbfiz           x0, x3, #1, #0x1f
    //     0xcc7670: cmp             x3, x0, asr #1
    //     0xcc7674: b.eq            #0xcc7680
    //     0xcc7678: bl              #0xd69bb8
    //     0xcc767c: stur            x3, [x0, #7]
    // 0xcc7680: mov             x1, x0
    // 0xcc7684: ldr             x0, [fp, #0x18]
    // 0xcc7688: r3 = LoadClassIdInstr(r0)
    //     0xcc7688: ldur            x3, [x0, #-1]
    //     0xcc768c: ubfx            x3, x3, #0xc, #0x14
    // 0xcc7690: stp             x1, x0, [SP, #-0x10]!
    // 0xcc7694: ldr             x16, [fp, #0x48]
    // 0xcc7698: stp             x16, x4, [SP, #-0x10]!
    // 0xcc769c: SaveReg r2
    //     0xcc769c: str             x2, [SP, #-8]!
    // 0xcc76a0: mov             x0, x3
    // 0xcc76a4: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xcc76a4: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xcc76a8: r0 = GDT[cid_x0 + 0x10330]()
    //     0xcc76a8: mov             x17, #0x330
    //     0xcc76ac: movk            x17, #1, lsl #16
    //     0xcc76b0: add             lr, x0, x17
    //     0xcc76b4: ldr             lr, [x21, lr, lsl #3]
    //     0xcc76b8: blr             lr
    // 0xcc76bc: add             SP, SP, #0x28
    // 0xcc76c0: r0 = Null
    //     0xcc76c0: mov             x0, NULL
    // 0xcc76c4: LeaveFrame
    //     0xcc76c4: mov             SP, fp
    //     0xcc76c8: ldp             fp, lr, [SP], #0x10
    // 0xcc76cc: ret
    //     0xcc76cc: ret             
    // 0xcc76d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc76d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc76d4: b               #0xcc7210
    // 0xcc76d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc76d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc76dc: b               #0xcc72fc
    // 0xcc76e0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcc76e0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ _mergeSort(/* No info */) {
    // ** addr: 0xcc76e4, size: 0x214
    // 0xcc76e4: EnterFrame
    //     0xcc76e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcc76e8: mov             fp, SP
    // 0xcc76ec: AllocStack(0x30)
    //     0xcc76ec: sub             SP, SP, #0x30
    // 0xcc76f0: SetupParameters()
    //     0xcc76f0: mov             x0, x4
    //     0xcc76f4: ldur            w1, [x0, #0xf]
    //     0xcc76f8: add             x1, x1, HEAP, lsl #32
    //     0xcc76fc: cbnz            w1, #0xcc7708
    //     0xcc7700: mov             x4, NULL
    //     0xcc7704: b               #0xcc771c
    //     0xcc7708: ldur            w1, [x0, #0x17]
    //     0xcc770c: add             x1, x1, HEAP, lsl #32
    //     0xcc7710: add             x0, fp, w1, sxtw #2
    //     0xcc7714: ldr             x0, [x0, #0x10]
    //     0xcc7718: mov             x4, x0
    //     0xcc771c: ldr             x3, [fp, #0x28]
    //     0xcc7720: ldr             x2, [fp, #0x20]
    //     0xcc7724: stur            x4, [fp, #-0x30]
    // 0xcc7728: CheckStackOverflow
    //     0xcc7728: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc772c: cmp             SP, x16
    //     0xcc7730: b.ls            #0xcc78f0
    // 0xcc7734: r0 = LoadInt32Instr(r3)
    //     0xcc7734: sbfx            x0, x3, #1, #0x1f
    //     0xcc7738: tbz             w3, #0, #0xcc7740
    //     0xcc773c: ldur            x0, [x3, #7]
    // 0xcc7740: r1 = LoadInt32Instr(r2)
    //     0xcc7740: sbfx            x1, x2, #1, #0x1f
    //     0xcc7744: tbz             w2, #0, #0xcc774c
    //     0xcc7748: ldur            x1, [x2, #7]
    // 0xcc774c: sub             x5, x1, x0
    // 0xcc7750: cmp             x5, #0x20
    // 0xcc7754: b.ge            #0xcc7798
    // 0xcc7758: ldr             x6, [fp, #0x10]
    // 0xcc775c: ldr             x16, [fp, #0x38]
    // 0xcc7760: stp             x16, x4, [SP, #-0x10]!
    // 0xcc7764: ldr             x16, [fp, #0x30]
    // 0xcc7768: stp             x3, x16, [SP, #-0x10]!
    // 0xcc776c: ldr             x16, [fp, #0x18]
    // 0xcc7770: stp             x16, x2, [SP, #-0x10]!
    // 0xcc7774: SaveReg r6
    //     0xcc7774: str             x6, [SP, #-8]!
    // 0xcc7778: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xcc7778: add             x4, PP, #0x12, lsl #12  ; [pp+0x12cb8] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xcc777c: ldr             x4, [x4, #0xcb8]
    // 0xcc7780: r0 = _movingInsertionSort()
    //     0xcc7780: bl              #0xcc78f8  ; [package:flutter/src/foundation/collections.dart] ::_movingInsertionSort
    // 0xcc7784: add             SP, SP, #0x38
    // 0xcc7788: r0 = Null
    //     0xcc7788: mov             x0, NULL
    // 0xcc778c: LeaveFrame
    //     0xcc778c: mov             SP, fp
    //     0xcc7790: ldp             fp, lr, [SP], #0x10
    // 0xcc7794: ret
    //     0xcc7794: ret             
    // 0xcc7798: ldr             x6, [fp, #0x10]
    // 0xcc779c: asr             x7, x5, #1
    // 0xcc77a0: add             x5, x0, x7
    // 0xcc77a4: stur            x5, [fp, #-0x28]
    // 0xcc77a8: sub             x7, x5, x0
    // 0xcc77ac: stur            x7, [fp, #-0x20]
    // 0xcc77b0: sub             x8, x1, x5
    // 0xcc77b4: stur            x8, [fp, #-0x18]
    // 0xcc77b8: add             x9, x6, x7
    // 0xcc77bc: stur            x9, [fp, #-0x10]
    // 0xcc77c0: r0 = BoxInt64Instr(r5)
    //     0xcc77c0: sbfiz           x0, x5, #1, #0x1f
    //     0xcc77c4: cmp             x5, x0, asr #1
    //     0xcc77c8: b.eq            #0xcc77d4
    //     0xcc77cc: bl              #0xd69bb8
    //     0xcc77d0: stur            x5, [x0, #7]
    // 0xcc77d4: stur            x0, [fp, #-8]
    // 0xcc77d8: ldr             x16, [fp, #0x38]
    // 0xcc77dc: stp             x16, x4, [SP, #-0x10]!
    // 0xcc77e0: ldr             x16, [fp, #0x30]
    // 0xcc77e4: stp             x0, x16, [SP, #-0x10]!
    // 0xcc77e8: ldr             x16, [fp, #0x18]
    // 0xcc77ec: stp             x16, x2, [SP, #-0x10]!
    // 0xcc77f0: SaveReg r9
    //     0xcc77f0: str             x9, [SP, #-8]!
    // 0xcc77f4: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xcc77f4: add             x4, PP, #0x12, lsl #12  ; [pp+0x12cb8] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xcc77f8: ldr             x4, [x4, #0xcb8]
    // 0xcc77fc: r0 = _mergeSort()
    //     0xcc77fc: bl              #0xcc76e4  ; [package:flutter/src/foundation/collections.dart] ::_mergeSort
    // 0xcc7800: add             SP, SP, #0x38
    // 0xcc7804: ldur            x16, [fp, #-0x30]
    // 0xcc7808: ldr             lr, [fp, #0x38]
    // 0xcc780c: stp             lr, x16, [SP, #-0x10]!
    // 0xcc7810: ldr             x16, [fp, #0x30]
    // 0xcc7814: ldr             lr, [fp, #0x28]
    // 0xcc7818: stp             lr, x16, [SP, #-0x10]!
    // 0xcc781c: ldur            x16, [fp, #-8]
    // 0xcc7820: ldr             lr, [fp, #0x38]
    // 0xcc7824: stp             lr, x16, [SP, #-0x10]!
    // 0xcc7828: ldur            x0, [fp, #-0x28]
    // 0xcc782c: SaveReg r0
    //     0xcc782c: str             x0, [SP, #-8]!
    // 0xcc7830: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xcc7830: add             x4, PP, #0x12, lsl #12  ; [pp+0x12cb8] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xcc7834: ldr             x4, [x4, #0xcb8]
    // 0xcc7838: r0 = _mergeSort()
    //     0xcc7838: bl              #0xcc76e4  ; [package:flutter/src/foundation/collections.dart] ::_mergeSort
    // 0xcc783c: add             SP, SP, #0x38
    // 0xcc7840: ldur            x0, [fp, #-0x28]
    // 0xcc7844: ldur            x1, [fp, #-0x20]
    // 0xcc7848: add             x2, x0, x1
    // 0xcc784c: ldur            x0, [fp, #-0x18]
    // 0xcc7850: ldur            x3, [fp, #-0x10]
    // 0xcc7854: add             x4, x3, x0
    // 0xcc7858: r0 = BoxInt64Instr(r3)
    //     0xcc7858: sbfiz           x0, x3, #1, #0x1f
    //     0xcc785c: cmp             x3, x0, asr #1
    //     0xcc7860: b.eq            #0xcc786c
    //     0xcc7864: bl              #0xd69bb8
    //     0xcc7868: stur            x3, [x0, #7]
    // 0xcc786c: mov             x3, x0
    // 0xcc7870: r0 = BoxInt64Instr(r2)
    //     0xcc7870: sbfiz           x0, x2, #1, #0x1f
    //     0xcc7874: cmp             x2, x0, asr #1
    //     0xcc7878: b.eq            #0xcc7884
    //     0xcc787c: bl              #0xd69bb8
    //     0xcc7880: stur            x2, [x0, #7]
    // 0xcc7884: mov             x2, x0
    // 0xcc7888: r0 = BoxInt64Instr(r4)
    //     0xcc7888: sbfiz           x0, x4, #1, #0x1f
    //     0xcc788c: cmp             x4, x0, asr #1
    //     0xcc7890: b.eq            #0xcc789c
    //     0xcc7894: bl              #0xd69bb8
    //     0xcc7898: stur            x4, [x0, #7]
    // 0xcc789c: ldur            x16, [fp, #-0x30]
    // 0xcc78a0: ldr             lr, [fp, #0x30]
    // 0xcc78a4: stp             lr, x16, [SP, #-0x10]!
    // 0xcc78a8: ldr             x16, [fp, #0x38]
    // 0xcc78ac: ldur            lr, [fp, #-8]
    // 0xcc78b0: stp             lr, x16, [SP, #-0x10]!
    // 0xcc78b4: ldr             x16, [fp, #0x18]
    // 0xcc78b8: stp             x16, x2, [SP, #-0x10]!
    // 0xcc78bc: stp             x0, x3, [SP, #-0x10]!
    // 0xcc78c0: ldr             x16, [fp, #0x18]
    // 0xcc78c4: SaveReg r16
    //     0xcc78c4: str             x16, [SP, #-8]!
    // 0xcc78c8: ldr             x0, [fp, #0x10]
    // 0xcc78cc: SaveReg r0
    //     0xcc78cc: str             x0, [SP, #-8]!
    // 0xcc78d0: r4 = const [0x1, 0x9, 0x9, 0x9, null]
    //     0xcc78d0: add             x4, PP, #0x3f, lsl #12  ; [pp+0x3f418] List(5) [0x1, 0x9, 0x9, 0x9, Null]
    //     0xcc78d4: ldr             x4, [x4, #0x418]
    // 0xcc78d8: r0 = _merge()
    //     0xcc78d8: bl              #0xcc71f8  ; [package:flutter/src/foundation/collections.dart] ::_merge
    // 0xcc78dc: add             SP, SP, #0x50
    // 0xcc78e0: r0 = Null
    //     0xcc78e0: mov             x0, NULL
    // 0xcc78e4: LeaveFrame
    //     0xcc78e4: mov             SP, fp
    //     0xcc78e8: ldp             fp, lr, [SP], #0x10
    // 0xcc78ec: ret
    //     0xcc78ec: ret             
    // 0xcc78f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc78f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc78f4: b               #0xcc7734
  }
  static _ _movingInsertionSort(/* No info */) {
    // ** addr: 0xcc78f8, size: 0x310
    // 0xcc78f8: EnterFrame
    //     0xcc78f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcc78fc: mov             fp, SP
    // 0xcc7900: AllocStack(0x48)
    //     0xcc7900: sub             SP, SP, #0x48
    // 0xcc7904: CheckStackOverflow
    //     0xcc7904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc7908: cmp             SP, x16
    //     0xcc790c: b.ls            #0xcc7bec
    // 0xcc7910: ldr             x0, [fp, #0x28]
    // 0xcc7914: r1 = LoadInt32Instr(r0)
    //     0xcc7914: sbfx            x1, x0, #1, #0x1f
    //     0xcc7918: tbz             w0, #0, #0xcc7920
    //     0xcc791c: ldur            x1, [x0, #7]
    // 0xcc7920: ldr             x2, [fp, #0x20]
    // 0xcc7924: stur            x1, [fp, #-0x10]
    // 0xcc7928: r3 = LoadInt32Instr(r2)
    //     0xcc7928: sbfx            x3, x2, #1, #0x1f
    //     0xcc792c: tbz             w2, #0, #0xcc7934
    //     0xcc7930: ldur            x3, [x2, #7]
    // 0xcc7934: sub             x2, x3, x1
    // 0xcc7938: stur            x2, [fp, #-8]
    // 0xcc793c: cbnz            x2, #0xcc7950
    // 0xcc7940: r0 = Null
    //     0xcc7940: mov             x0, NULL
    // 0xcc7944: LeaveFrame
    //     0xcc7944: mov             SP, fp
    //     0xcc7948: ldp             fp, lr, [SP], #0x10
    // 0xcc794c: ret
    //     0xcc794c: ret             
    // 0xcc7950: ldr             x5, [fp, #0x38]
    // 0xcc7954: ldr             x4, [fp, #0x18]
    // 0xcc7958: ldr             x3, [fp, #0x10]
    // 0xcc795c: r6 = LoadClassIdInstr(r5)
    //     0xcc795c: ldur            x6, [x5, #-1]
    //     0xcc7960: ubfx            x6, x6, #0xc, #0x14
    // 0xcc7964: stp             x0, x5, [SP, #-0x10]!
    // 0xcc7968: mov             x0, x6
    // 0xcc796c: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc796c: sub             lr, x0, #0xd83
    //     0xcc7970: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7974: blr             lr
    // 0xcc7978: add             SP, SP, #0x10
    // 0xcc797c: mov             x3, x0
    // 0xcc7980: ldr             x2, [fp, #0x10]
    // 0xcc7984: r0 = BoxInt64Instr(r2)
    //     0xcc7984: sbfiz           x0, x2, #1, #0x1f
    //     0xcc7988: cmp             x2, x0, asr #1
    //     0xcc798c: b.eq            #0xcc7998
    //     0xcc7990: bl              #0xd69bb8
    //     0xcc7994: stur            x2, [x0, #7]
    // 0xcc7998: ldr             x1, [fp, #0x18]
    // 0xcc799c: r4 = LoadClassIdInstr(r1)
    //     0xcc799c: ldur            x4, [x1, #-1]
    //     0xcc79a0: ubfx            x4, x4, #0xc, #0x14
    // 0xcc79a4: stp             x0, x1, [SP, #-0x10]!
    // 0xcc79a8: SaveReg r3
    //     0xcc79a8: str             x3, [SP, #-8]!
    // 0xcc79ac: mov             x0, x4
    // 0xcc79b0: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xcc79b0: mov             x17, #0x15e
    //     0xcc79b4: movk            x17, #1, lsl #16
    //     0xcc79b8: add             lr, x0, x17
    //     0xcc79bc: ldr             lr, [x21, lr, lsl #3]
    //     0xcc79c0: blr             lr
    // 0xcc79c4: add             SP, SP, #0x18
    // 0xcc79c8: r7 = 1
    //     0xcc79c8: mov             x7, #1
    // 0xcc79cc: ldr             x6, [fp, #0x38]
    // 0xcc79d0: ldr             x3, [fp, #0x18]
    // 0xcc79d4: ldr             x2, [fp, #0x10]
    // 0xcc79d8: ldur            x5, [fp, #-8]
    // 0xcc79dc: ldur            x4, [fp, #-0x10]
    // 0xcc79e0: stur            x7, [fp, #-0x18]
    // 0xcc79e4: CheckStackOverflow
    //     0xcc79e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc79e8: cmp             SP, x16
    //     0xcc79ec: b.ls            #0xcc7bf4
    // 0xcc79f0: cmp             x7, x5
    // 0xcc79f4: b.ge            #0xcc7bdc
    // 0xcc79f8: add             x8, x4, x7
    // 0xcc79fc: r0 = BoxInt64Instr(r8)
    //     0xcc79fc: sbfiz           x0, x8, #1, #0x1f
    //     0xcc7a00: cmp             x8, x0, asr #1
    //     0xcc7a04: b.eq            #0xcc7a10
    //     0xcc7a08: bl              #0xd69bb8
    //     0xcc7a0c: stur            x8, [x0, #7]
    // 0xcc7a10: r1 = LoadClassIdInstr(r6)
    //     0xcc7a10: ldur            x1, [x6, #-1]
    //     0xcc7a14: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7a18: stp             x0, x6, [SP, #-0x10]!
    // 0xcc7a1c: mov             x0, x1
    // 0xcc7a20: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc7a20: sub             lr, x0, #0xd83
    //     0xcc7a24: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7a28: blr             lr
    // 0xcc7a2c: add             SP, SP, #0x10
    // 0xcc7a30: mov             x4, x0
    // 0xcc7a34: ldr             x2, [fp, #0x10]
    // 0xcc7a38: ldur            x3, [fp, #-0x18]
    // 0xcc7a3c: stur            x4, [fp, #-0x40]
    // 0xcc7a40: add             x5, x2, x3
    // 0xcc7a44: stur            x5, [fp, #-0x38]
    // 0xcc7a48: mov             x8, x2
    // 0xcc7a4c: mov             x7, x5
    // 0xcc7a50: ldr             x6, [fp, #0x18]
    // 0xcc7a54: stur            x8, [fp, #-0x28]
    // 0xcc7a58: stur            x7, [fp, #-0x30]
    // 0xcc7a5c: CheckStackOverflow
    //     0xcc7a5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc7a60: cmp             SP, x16
    //     0xcc7a64: b.ls            #0xcc7bfc
    // 0xcc7a68: cmp             x8, x7
    // 0xcc7a6c: b.ge            #0xcc7b20
    // 0xcc7a70: sub             x0, x7, x8
    // 0xcc7a74: asr             x1, x0, #1
    // 0xcc7a78: add             x9, x8, x1
    // 0xcc7a7c: stur            x9, [fp, #-0x20]
    // 0xcc7a80: r0 = BoxInt64Instr(r9)
    //     0xcc7a80: sbfiz           x0, x9, #1, #0x1f
    //     0xcc7a84: cmp             x9, x0, asr #1
    //     0xcc7a88: b.eq            #0xcc7a94
    //     0xcc7a8c: bl              #0xd69bb8
    //     0xcc7a90: stur            x9, [x0, #7]
    // 0xcc7a94: r1 = LoadClassIdInstr(r6)
    //     0xcc7a94: ldur            x1, [x6, #-1]
    //     0xcc7a98: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7a9c: stp             x0, x6, [SP, #-0x10]!
    // 0xcc7aa0: mov             x0, x1
    // 0xcc7aa4: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc7aa4: sub             lr, x0, #0xd83
    //     0xcc7aa8: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7aac: blr             lr
    // 0xcc7ab0: add             SP, SP, #0x10
    // 0xcc7ab4: ldr             x16, [fp, #0x30]
    // 0xcc7ab8: ldur            lr, [fp, #-0x40]
    // 0xcc7abc: stp             lr, x16, [SP, #-0x10]!
    // 0xcc7ac0: SaveReg r0
    //     0xcc7ac0: str             x0, [SP, #-8]!
    // 0xcc7ac4: ldr             x0, [fp, #0x30]
    // 0xcc7ac8: ClosureCall
    //     0xcc7ac8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xcc7acc: ldur            x2, [x0, #0x1f]
    //     0xcc7ad0: blr             x2
    // 0xcc7ad4: add             SP, SP, #0x18
    // 0xcc7ad8: cmp             w0, NULL
    // 0xcc7adc: b.eq            #0xcc7c04
    // 0xcc7ae0: r1 = LoadInt32Instr(r0)
    //     0xcc7ae0: sbfx            x1, x0, #1, #0x1f
    //     0xcc7ae4: tbz             w0, #0, #0xcc7aec
    //     0xcc7ae8: ldur            x1, [x0, #7]
    // 0xcc7aec: tbz             x1, #0x3f, #0xcc7afc
    // 0xcc7af0: ldur            x8, [fp, #-0x28]
    // 0xcc7af4: ldur            x7, [fp, #-0x20]
    // 0xcc7af8: b               #0xcc7b0c
    // 0xcc7afc: ldur            x0, [fp, #-0x20]
    // 0xcc7b00: add             x1, x0, #1
    // 0xcc7b04: mov             x8, x1
    // 0xcc7b08: ldur            x7, [fp, #-0x30]
    // 0xcc7b0c: ldr             x2, [fp, #0x10]
    // 0xcc7b10: ldur            x3, [fp, #-0x18]
    // 0xcc7b14: ldur            x4, [fp, #-0x40]
    // 0xcc7b18: ldur            x5, [fp, #-0x38]
    // 0xcc7b1c: b               #0xcc7a50
    // 0xcc7b20: mov             x2, x3
    // 0xcc7b24: mov             x3, x6
    // 0xcc7b28: mov             x0, x5
    // 0xcc7b2c: mov             x4, x8
    // 0xcc7b30: add             x5, x4, #1
    // 0xcc7b34: add             x6, x0, #1
    // 0xcc7b38: r0 = BoxInt64Instr(r4)
    //     0xcc7b38: sbfiz           x0, x4, #1, #0x1f
    //     0xcc7b3c: cmp             x4, x0, asr #1
    //     0xcc7b40: b.eq            #0xcc7b4c
    //     0xcc7b44: bl              #0xd69bb8
    //     0xcc7b48: stur            x4, [x0, #7]
    // 0xcc7b4c: mov             x4, x0
    // 0xcc7b50: stur            x4, [fp, #-0x48]
    // 0xcc7b54: r0 = BoxInt64Instr(r5)
    //     0xcc7b54: sbfiz           x0, x5, #1, #0x1f
    //     0xcc7b58: cmp             x5, x0, asr #1
    //     0xcc7b5c: b.eq            #0xcc7b68
    //     0xcc7b60: bl              #0xd69bb8
    //     0xcc7b64: stur            x5, [x0, #7]
    // 0xcc7b68: r1 = LoadClassIdInstr(r3)
    //     0xcc7b68: ldur            x1, [x3, #-1]
    //     0xcc7b6c: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7b70: stp             x0, x3, [SP, #-0x10]!
    // 0xcc7b74: stp             x3, x6, [SP, #-0x10]!
    // 0xcc7b78: SaveReg r4
    //     0xcc7b78: str             x4, [SP, #-8]!
    // 0xcc7b7c: mov             x0, x1
    // 0xcc7b80: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xcc7b80: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xcc7b84: r0 = GDT[cid_x0 + 0x10330]()
    //     0xcc7b84: mov             x17, #0x330
    //     0xcc7b88: movk            x17, #1, lsl #16
    //     0xcc7b8c: add             lr, x0, x17
    //     0xcc7b90: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7b94: blr             lr
    // 0xcc7b98: add             SP, SP, #0x28
    // 0xcc7b9c: ldr             x1, [fp, #0x18]
    // 0xcc7ba0: r0 = LoadClassIdInstr(r1)
    //     0xcc7ba0: ldur            x0, [x1, #-1]
    //     0xcc7ba4: ubfx            x0, x0, #0xc, #0x14
    // 0xcc7ba8: ldur            x16, [fp, #-0x48]
    // 0xcc7bac: stp             x16, x1, [SP, #-0x10]!
    // 0xcc7bb0: ldur            x16, [fp, #-0x40]
    // 0xcc7bb4: SaveReg r16
    //     0xcc7bb4: str             x16, [SP, #-8]!
    // 0xcc7bb8: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xcc7bb8: mov             x17, #0x15e
    //     0xcc7bbc: movk            x17, #1, lsl #16
    //     0xcc7bc0: add             lr, x0, x17
    //     0xcc7bc4: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7bc8: blr             lr
    // 0xcc7bcc: add             SP, SP, #0x18
    // 0xcc7bd0: ldur            x1, [fp, #-0x18]
    // 0xcc7bd4: add             x7, x1, #1
    // 0xcc7bd8: b               #0xcc79cc
    // 0xcc7bdc: r0 = Null
    //     0xcc7bdc: mov             x0, NULL
    // 0xcc7be0: LeaveFrame
    //     0xcc7be0: mov             SP, fp
    //     0xcc7be4: ldp             fp, lr, [SP], #0x10
    // 0xcc7be8: ret
    //     0xcc7be8: ret             
    // 0xcc7bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc7bec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc7bf0: b               #0xcc7910
    // 0xcc7bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc7bf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc7bf8: b               #0xcc79f0
    // 0xcc7bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc7bfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc7c00: b               #0xcc7a68
    // 0xcc7c04: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcc7c04: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ _insertionSort(/* No info */) {
    // ** addr: 0xcc7c08, size: 0x228
    // 0xcc7c08: EnterFrame
    //     0xcc7c08: stp             fp, lr, [SP, #-0x10]!
    //     0xcc7c0c: mov             fp, SP
    // 0xcc7c10: AllocStack(0x30)
    //     0xcc7c10: sub             SP, SP, #0x30
    // 0xcc7c14: CheckStackOverflow
    //     0xcc7c14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc7c18: cmp             SP, x16
    //     0xcc7c1c: b.ls            #0xcc7e14
    // 0xcc7c20: r4 = 1
    //     0xcc7c20: mov             x4, #1
    // 0xcc7c24: ldr             x3, [fp, #0x20]
    // 0xcc7c28: ldr             x2, [fp, #0x10]
    // 0xcc7c2c: stur            x4, [fp, #-8]
    // 0xcc7c30: CheckStackOverflow
    //     0xcc7c30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc7c34: cmp             SP, x16
    //     0xcc7c38: b.ls            #0xcc7e1c
    // 0xcc7c3c: cmp             x4, x2
    // 0xcc7c40: b.ge            #0xcc7e04
    // 0xcc7c44: r0 = BoxInt64Instr(r4)
    //     0xcc7c44: sbfiz           x0, x4, #1, #0x1f
    //     0xcc7c48: cmp             x4, x0, asr #1
    //     0xcc7c4c: b.eq            #0xcc7c58
    //     0xcc7c50: bl              #0xd69bb8
    //     0xcc7c54: stur            x4, [x0, #7]
    // 0xcc7c58: r1 = LoadClassIdInstr(r3)
    //     0xcc7c58: ldur            x1, [x3, #-1]
    //     0xcc7c5c: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7c60: stp             x0, x3, [SP, #-0x10]!
    // 0xcc7c64: mov             x0, x1
    // 0xcc7c68: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc7c68: sub             lr, x0, #0xd83
    //     0xcc7c6c: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7c70: blr             lr
    // 0xcc7c74: add             SP, SP, #0x10
    // 0xcc7c78: mov             x2, x0
    // 0xcc7c7c: stur            x2, [fp, #-0x28]
    // 0xcc7c80: ldur            x4, [fp, #-8]
    // 0xcc7c84: r5 = 0
    //     0xcc7c84: mov             x5, #0
    // 0xcc7c88: ldr             x3, [fp, #0x20]
    // 0xcc7c8c: stur            x5, [fp, #-0x18]
    // 0xcc7c90: stur            x4, [fp, #-0x20]
    // 0xcc7c94: CheckStackOverflow
    //     0xcc7c94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc7c98: cmp             SP, x16
    //     0xcc7c9c: b.ls            #0xcc7e24
    // 0xcc7ca0: cmp             x5, x4
    // 0xcc7ca4: b.ge            #0xcc7d4c
    // 0xcc7ca8: sub             x0, x4, x5
    // 0xcc7cac: asr             x1, x0, #1
    // 0xcc7cb0: add             x6, x5, x1
    // 0xcc7cb4: stur            x6, [fp, #-0x10]
    // 0xcc7cb8: r0 = BoxInt64Instr(r6)
    //     0xcc7cb8: sbfiz           x0, x6, #1, #0x1f
    //     0xcc7cbc: cmp             x6, x0, asr #1
    //     0xcc7cc0: b.eq            #0xcc7ccc
    //     0xcc7cc4: bl              #0xd69bb8
    //     0xcc7cc8: stur            x6, [x0, #7]
    // 0xcc7ccc: r1 = LoadClassIdInstr(r3)
    //     0xcc7ccc: ldur            x1, [x3, #-1]
    //     0xcc7cd0: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7cd4: stp             x0, x3, [SP, #-0x10]!
    // 0xcc7cd8: mov             x0, x1
    // 0xcc7cdc: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcc7cdc: sub             lr, x0, #0xd83
    //     0xcc7ce0: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7ce4: blr             lr
    // 0xcc7ce8: add             SP, SP, #0x10
    // 0xcc7cec: ldr             x16, [fp, #0x18]
    // 0xcc7cf0: ldur            lr, [fp, #-0x28]
    // 0xcc7cf4: stp             lr, x16, [SP, #-0x10]!
    // 0xcc7cf8: SaveReg r0
    //     0xcc7cf8: str             x0, [SP, #-8]!
    // 0xcc7cfc: ldr             x0, [fp, #0x18]
    // 0xcc7d00: ClosureCall
    //     0xcc7d00: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xcc7d04: ldur            x2, [x0, #0x1f]
    //     0xcc7d08: blr             x2
    // 0xcc7d0c: add             SP, SP, #0x18
    // 0xcc7d10: cmp             w0, NULL
    // 0xcc7d14: b.eq            #0xcc7e2c
    // 0xcc7d18: r1 = LoadInt32Instr(r0)
    //     0xcc7d18: sbfx            x1, x0, #1, #0x1f
    //     0xcc7d1c: tbz             w0, #0, #0xcc7d24
    //     0xcc7d20: ldur            x1, [x0, #7]
    // 0xcc7d24: tbz             x1, #0x3f, #0xcc7d34
    // 0xcc7d28: ldur            x5, [fp, #-0x18]
    // 0xcc7d2c: ldur            x4, [fp, #-0x10]
    // 0xcc7d30: b               #0xcc7d44
    // 0xcc7d34: ldur            x0, [fp, #-0x10]
    // 0xcc7d38: add             x1, x0, #1
    // 0xcc7d3c: mov             x5, x1
    // 0xcc7d40: ldur            x4, [fp, #-0x20]
    // 0xcc7d44: ldur            x2, [fp, #-0x28]
    // 0xcc7d48: b               #0xcc7c88
    // 0xcc7d4c: mov             x2, x3
    // 0xcc7d50: ldur            x0, [fp, #-8]
    // 0xcc7d54: mov             x3, x5
    // 0xcc7d58: add             x4, x3, #1
    // 0xcc7d5c: add             x5, x0, #1
    // 0xcc7d60: stur            x5, [fp, #-0x10]
    // 0xcc7d64: r0 = BoxInt64Instr(r3)
    //     0xcc7d64: sbfiz           x0, x3, #1, #0x1f
    //     0xcc7d68: cmp             x3, x0, asr #1
    //     0xcc7d6c: b.eq            #0xcc7d78
    //     0xcc7d70: bl              #0xd69bb8
    //     0xcc7d74: stur            x3, [x0, #7]
    // 0xcc7d78: mov             x3, x0
    // 0xcc7d7c: stur            x3, [fp, #-0x30]
    // 0xcc7d80: r0 = BoxInt64Instr(r4)
    //     0xcc7d80: sbfiz           x0, x4, #1, #0x1f
    //     0xcc7d84: cmp             x4, x0, asr #1
    //     0xcc7d88: b.eq            #0xcc7d94
    //     0xcc7d8c: bl              #0xd69bb8
    //     0xcc7d90: stur            x4, [x0, #7]
    // 0xcc7d94: r1 = LoadClassIdInstr(r2)
    //     0xcc7d94: ldur            x1, [x2, #-1]
    //     0xcc7d98: ubfx            x1, x1, #0xc, #0x14
    // 0xcc7d9c: stp             x0, x2, [SP, #-0x10]!
    // 0xcc7da0: stp             x2, x5, [SP, #-0x10]!
    // 0xcc7da4: SaveReg r3
    //     0xcc7da4: str             x3, [SP, #-8]!
    // 0xcc7da8: mov             x0, x1
    // 0xcc7dac: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xcc7dac: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xcc7db0: r0 = GDT[cid_x0 + 0x10330]()
    //     0xcc7db0: mov             x17, #0x330
    //     0xcc7db4: movk            x17, #1, lsl #16
    //     0xcc7db8: add             lr, x0, x17
    //     0xcc7dbc: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7dc0: blr             lr
    // 0xcc7dc4: add             SP, SP, #0x28
    // 0xcc7dc8: ldr             x1, [fp, #0x20]
    // 0xcc7dcc: r0 = LoadClassIdInstr(r1)
    //     0xcc7dcc: ldur            x0, [x1, #-1]
    //     0xcc7dd0: ubfx            x0, x0, #0xc, #0x14
    // 0xcc7dd4: ldur            x16, [fp, #-0x30]
    // 0xcc7dd8: stp             x16, x1, [SP, #-0x10]!
    // 0xcc7ddc: ldur            x16, [fp, #-0x28]
    // 0xcc7de0: SaveReg r16
    //     0xcc7de0: str             x16, [SP, #-8]!
    // 0xcc7de4: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xcc7de4: mov             x17, #0x15e
    //     0xcc7de8: movk            x17, #1, lsl #16
    //     0xcc7dec: add             lr, x0, x17
    //     0xcc7df0: ldr             lr, [x21, lr, lsl #3]
    //     0xcc7df4: blr             lr
    // 0xcc7df8: add             SP, SP, #0x18
    // 0xcc7dfc: ldur            x4, [fp, #-0x10]
    // 0xcc7e00: b               #0xcc7c24
    // 0xcc7e04: r0 = Null
    //     0xcc7e04: mov             x0, NULL
    // 0xcc7e08: LeaveFrame
    //     0xcc7e08: mov             SP, fp
    //     0xcc7e0c: ldp             fp, lr, [SP], #0x10
    // 0xcc7e10: ret
    //     0xcc7e10: ret             
    // 0xcc7e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc7e14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc7e18: b               #0xcc7c20
    // 0xcc7e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc7e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc7e20: b               #0xcc7c3c
    // 0xcc7e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc7e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc7e28: b               #0xcc7ca0
    // 0xcc7e2c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcc7e2c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:flutter/src/foundation/change_notifier.dart

// class id: 1049127, size: 0x8
class :: {
}

// class id: 4311, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Listenable extends Object {
}

// class id: 4326, size: 0xc, field offset: 0x8
class _MergingListenable extends Listenable {

  _ addListener(/* No info */) {
    // ** addr: 0x6e95a4, size: 0x19c
    // 0x6e95a4: EnterFrame
    //     0x6e95a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e95a8: mov             fp, SP
    // 0x6e95ac: AllocStack(0x30)
    //     0x6e95ac: sub             SP, SP, #0x30
    // 0x6e95b0: CheckStackOverflow
    //     0x6e95b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e95b4: cmp             SP, x16
    //     0x6e95b8: b.ls            #0x6e9730
    // 0x6e95bc: ldr             x0, [fp, #0x18]
    // 0x6e95c0: LoadField: r1 = r0->field_7
    //     0x6e95c0: ldur            w1, [x0, #7]
    // 0x6e95c4: DecompressPointer r1
    //     0x6e95c4: add             x1, x1, HEAP, lsl #32
    // 0x6e95c8: stur            x1, [fp, #-0x20]
    // 0x6e95cc: LoadField: r2 = r1->field_7
    //     0x6e95cc: ldur            w2, [x1, #7]
    // 0x6e95d0: DecompressPointer r2
    //     0x6e95d0: add             x2, x2, HEAP, lsl #32
    // 0x6e95d4: stur            x2, [fp, #-0x18]
    // 0x6e95d8: LoadField: r0 = r1->field_b
    //     0x6e95d8: ldur            w0, [x1, #0xb]
    // 0x6e95dc: DecompressPointer r0
    //     0x6e95dc: add             x0, x0, HEAP, lsl #32
    // 0x6e95e0: r3 = LoadInt32Instr(r0)
    //     0x6e95e0: sbfx            x3, x0, #1, #0x1f
    // 0x6e95e4: stur            x3, [fp, #-0x10]
    // 0x6e95e8: r4 = 0
    //     0x6e95e8: mov             x4, #0
    // 0x6e95ec: stur            x4, [fp, #-8]
    // 0x6e95f0: CheckStackOverflow
    //     0x6e95f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e95f4: cmp             SP, x16
    //     0x6e95f8: b.ls            #0x6e9738
    // 0x6e95fc: r0 = LoadClassIdInstr(r1)
    //     0x6e95fc: ldur            x0, [x1, #-1]
    //     0x6e9600: ubfx            x0, x0, #0xc, #0x14
    // 0x6e9604: SaveReg r1
    //     0x6e9604: str             x1, [SP, #-8]!
    // 0x6e9608: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6e9608: mov             x17, #0xb8ea
    //     0x6e960c: add             lr, x0, x17
    //     0x6e9610: ldr             lr, [x21, lr, lsl #3]
    //     0x6e9614: blr             lr
    // 0x6e9618: add             SP, SP, #8
    // 0x6e961c: r1 = LoadInt32Instr(r0)
    //     0x6e961c: sbfx            x1, x0, #1, #0x1f
    //     0x6e9620: tbz             w0, #0, #0x6e9628
    //     0x6e9624: ldur            x1, [x0, #7]
    // 0x6e9628: ldur            x2, [fp, #-0x10]
    // 0x6e962c: cmp             x2, x1
    // 0x6e9630: b.ne            #0x6e9718
    // 0x6e9634: ldur            x3, [fp, #-0x20]
    // 0x6e9638: ldur            x4, [fp, #-8]
    // 0x6e963c: cmp             x4, x1
    // 0x6e9640: b.lt            #0x6e9654
    // 0x6e9644: r0 = Null
    //     0x6e9644: mov             x0, NULL
    // 0x6e9648: LeaveFrame
    //     0x6e9648: mov             SP, fp
    //     0x6e964c: ldp             fp, lr, [SP], #0x10
    // 0x6e9650: ret
    //     0x6e9650: ret             
    // 0x6e9654: r0 = BoxInt64Instr(r4)
    //     0x6e9654: sbfiz           x0, x4, #1, #0x1f
    //     0x6e9658: cmp             x4, x0, asr #1
    //     0x6e965c: b.eq            #0x6e9668
    //     0x6e9660: bl              #0xd69bb8
    //     0x6e9664: stur            x4, [x0, #7]
    // 0x6e9668: r1 = LoadClassIdInstr(r3)
    //     0x6e9668: ldur            x1, [x3, #-1]
    //     0x6e966c: ubfx            x1, x1, #0xc, #0x14
    // 0x6e9670: stp             x0, x3, [SP, #-0x10]!
    // 0x6e9674: mov             x0, x1
    // 0x6e9678: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6e9678: mov             x17, #0xd175
    //     0x6e967c: add             lr, x0, x17
    //     0x6e9680: ldr             lr, [x21, lr, lsl #3]
    //     0x6e9684: blr             lr
    // 0x6e9688: add             SP, SP, #0x10
    // 0x6e968c: mov             x3, x0
    // 0x6e9690: ldur            x0, [fp, #-8]
    // 0x6e9694: stur            x3, [fp, #-0x30]
    // 0x6e9698: add             x4, x0, #1
    // 0x6e969c: stur            x4, [fp, #-0x28]
    // 0x6e96a0: cmp             w3, NULL
    // 0x6e96a4: b.ne            #0x6e96d8
    // 0x6e96a8: mov             x0, x3
    // 0x6e96ac: ldur            x2, [fp, #-0x18]
    // 0x6e96b0: r1 = Null
    //     0x6e96b0: mov             x1, NULL
    // 0x6e96b4: cmp             w2, NULL
    // 0x6e96b8: b.eq            #0x6e96d8
    // 0x6e96bc: LoadField: r4 = r2->field_17
    //     0x6e96bc: ldur            w4, [x2, #0x17]
    // 0x6e96c0: DecompressPointer r4
    //     0x6e96c0: add             x4, x4, HEAP, lsl #32
    // 0x6e96c4: r8 = X0
    //     0x6e96c4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e96c8: LoadField: r9 = r4->field_7
    //     0x6e96c8: ldur            x9, [x4, #7]
    // 0x6e96cc: r3 = Null
    //     0x6e96cc: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f108] Null
    //     0x6e96d0: ldr             x3, [x3, #0x108]
    // 0x6e96d4: blr             x9
    // 0x6e96d8: ldur            x0, [fp, #-0x30]
    // 0x6e96dc: r1 = LoadClassIdInstr(r0)
    //     0x6e96dc: ldur            x1, [x0, #-1]
    //     0x6e96e0: ubfx            x1, x1, #0xc, #0x14
    // 0x6e96e4: ldr             x16, [fp, #0x10]
    // 0x6e96e8: stp             x16, x0, [SP, #-0x10]!
    // 0x6e96ec: mov             x0, x1
    // 0x6e96f0: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6e96f0: mov             x17, #0xc3ab
    //     0x6e96f4: add             lr, x0, x17
    //     0x6e96f8: ldr             lr, [x21, lr, lsl #3]
    //     0x6e96fc: blr             lr
    // 0x6e9700: add             SP, SP, #0x10
    // 0x6e9704: ldur            x4, [fp, #-0x28]
    // 0x6e9708: ldur            x1, [fp, #-0x20]
    // 0x6e970c: ldur            x2, [fp, #-0x18]
    // 0x6e9710: ldur            x3, [fp, #-0x10]
    // 0x6e9714: b               #0x6e95ec
    // 0x6e9718: ldur            x0, [fp, #-0x20]
    // 0x6e971c: r0 = ConcurrentModificationError()
    //     0x6e971c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6e9720: ldur            x3, [fp, #-0x20]
    // 0x6e9724: StoreField: r0->field_b = r3
    //     0x6e9724: stur            w3, [x0, #0xb]
    // 0x6e9728: r0 = Throw()
    //     0x6e9728: bl              #0xd67e38  ; ThrowStub
    // 0x6e972c: brk             #0
    // 0x6e9730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9730: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9734: b               #0x6e95bc
    // 0x6e9738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9738: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e973c: b               #0x6e95fc
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6f6224, size: 0x19c
    // 0x6f6224: EnterFrame
    //     0x6f6224: stp             fp, lr, [SP, #-0x10]!
    //     0x6f6228: mov             fp, SP
    // 0x6f622c: AllocStack(0x30)
    //     0x6f622c: sub             SP, SP, #0x30
    // 0x6f6230: CheckStackOverflow
    //     0x6f6230: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f6234: cmp             SP, x16
    //     0x6f6238: b.ls            #0x6f63b0
    // 0x6f623c: ldr             x0, [fp, #0x18]
    // 0x6f6240: LoadField: r1 = r0->field_7
    //     0x6f6240: ldur            w1, [x0, #7]
    // 0x6f6244: DecompressPointer r1
    //     0x6f6244: add             x1, x1, HEAP, lsl #32
    // 0x6f6248: stur            x1, [fp, #-0x20]
    // 0x6f624c: LoadField: r2 = r1->field_7
    //     0x6f624c: ldur            w2, [x1, #7]
    // 0x6f6250: DecompressPointer r2
    //     0x6f6250: add             x2, x2, HEAP, lsl #32
    // 0x6f6254: stur            x2, [fp, #-0x18]
    // 0x6f6258: LoadField: r0 = r1->field_b
    //     0x6f6258: ldur            w0, [x1, #0xb]
    // 0x6f625c: DecompressPointer r0
    //     0x6f625c: add             x0, x0, HEAP, lsl #32
    // 0x6f6260: r3 = LoadInt32Instr(r0)
    //     0x6f6260: sbfx            x3, x0, #1, #0x1f
    // 0x6f6264: stur            x3, [fp, #-0x10]
    // 0x6f6268: r4 = 0
    //     0x6f6268: mov             x4, #0
    // 0x6f626c: stur            x4, [fp, #-8]
    // 0x6f6270: CheckStackOverflow
    //     0x6f6270: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f6274: cmp             SP, x16
    //     0x6f6278: b.ls            #0x6f63b8
    // 0x6f627c: r0 = LoadClassIdInstr(r1)
    //     0x6f627c: ldur            x0, [x1, #-1]
    //     0x6f6280: ubfx            x0, x0, #0xc, #0x14
    // 0x6f6284: SaveReg r1
    //     0x6f6284: str             x1, [SP, #-8]!
    // 0x6f6288: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6f6288: mov             x17, #0xb8ea
    //     0x6f628c: add             lr, x0, x17
    //     0x6f6290: ldr             lr, [x21, lr, lsl #3]
    //     0x6f6294: blr             lr
    // 0x6f6298: add             SP, SP, #8
    // 0x6f629c: r1 = LoadInt32Instr(r0)
    //     0x6f629c: sbfx            x1, x0, #1, #0x1f
    //     0x6f62a0: tbz             w0, #0, #0x6f62a8
    //     0x6f62a4: ldur            x1, [x0, #7]
    // 0x6f62a8: ldur            x2, [fp, #-0x10]
    // 0x6f62ac: cmp             x2, x1
    // 0x6f62b0: b.ne            #0x6f6398
    // 0x6f62b4: ldur            x3, [fp, #-0x20]
    // 0x6f62b8: ldur            x4, [fp, #-8]
    // 0x6f62bc: cmp             x4, x1
    // 0x6f62c0: b.lt            #0x6f62d4
    // 0x6f62c4: r0 = Null
    //     0x6f62c4: mov             x0, NULL
    // 0x6f62c8: LeaveFrame
    //     0x6f62c8: mov             SP, fp
    //     0x6f62cc: ldp             fp, lr, [SP], #0x10
    // 0x6f62d0: ret
    //     0x6f62d0: ret             
    // 0x6f62d4: r0 = BoxInt64Instr(r4)
    //     0x6f62d4: sbfiz           x0, x4, #1, #0x1f
    //     0x6f62d8: cmp             x4, x0, asr #1
    //     0x6f62dc: b.eq            #0x6f62e8
    //     0x6f62e0: bl              #0xd69bb8
    //     0x6f62e4: stur            x4, [x0, #7]
    // 0x6f62e8: r1 = LoadClassIdInstr(r3)
    //     0x6f62e8: ldur            x1, [x3, #-1]
    //     0x6f62ec: ubfx            x1, x1, #0xc, #0x14
    // 0x6f62f0: stp             x0, x3, [SP, #-0x10]!
    // 0x6f62f4: mov             x0, x1
    // 0x6f62f8: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6f62f8: mov             x17, #0xd175
    //     0x6f62fc: add             lr, x0, x17
    //     0x6f6300: ldr             lr, [x21, lr, lsl #3]
    //     0x6f6304: blr             lr
    // 0x6f6308: add             SP, SP, #0x10
    // 0x6f630c: mov             x3, x0
    // 0x6f6310: ldur            x0, [fp, #-8]
    // 0x6f6314: stur            x3, [fp, #-0x30]
    // 0x6f6318: add             x4, x0, #1
    // 0x6f631c: stur            x4, [fp, #-0x28]
    // 0x6f6320: cmp             w3, NULL
    // 0x6f6324: b.ne            #0x6f6358
    // 0x6f6328: mov             x0, x3
    // 0x6f632c: ldur            x2, [fp, #-0x18]
    // 0x6f6330: r1 = Null
    //     0x6f6330: mov             x1, NULL
    // 0x6f6334: cmp             w2, NULL
    // 0x6f6338: b.eq            #0x6f6358
    // 0x6f633c: LoadField: r4 = r2->field_17
    //     0x6f633c: ldur            w4, [x2, #0x17]
    // 0x6f6340: DecompressPointer r4
    //     0x6f6340: add             x4, x4, HEAP, lsl #32
    // 0x6f6344: r8 = X0
    //     0x6f6344: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6f6348: LoadField: r9 = r4->field_7
    //     0x6f6348: ldur            x9, [x4, #7]
    // 0x6f634c: r3 = Null
    //     0x6f634c: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f0f8] Null
    //     0x6f6350: ldr             x3, [x3, #0xf8]
    // 0x6f6354: blr             x9
    // 0x6f6358: ldur            x0, [fp, #-0x30]
    // 0x6f635c: r1 = LoadClassIdInstr(r0)
    //     0x6f635c: ldur            x1, [x0, #-1]
    //     0x6f6360: ubfx            x1, x1, #0xc, #0x14
    // 0x6f6364: ldr             x16, [fp, #0x10]
    // 0x6f6368: stp             x16, x0, [SP, #-0x10]!
    // 0x6f636c: mov             x0, x1
    // 0x6f6370: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6f6370: mov             x17, #0xc2d6
    //     0x6f6374: add             lr, x0, x17
    //     0x6f6378: ldr             lr, [x21, lr, lsl #3]
    //     0x6f637c: blr             lr
    // 0x6f6380: add             SP, SP, #0x10
    // 0x6f6384: ldur            x4, [fp, #-0x28]
    // 0x6f6388: ldur            x1, [fp, #-0x20]
    // 0x6f638c: ldur            x2, [fp, #-0x18]
    // 0x6f6390: ldur            x3, [fp, #-0x10]
    // 0x6f6394: b               #0x6f626c
    // 0x6f6398: ldur            x0, [fp, #-0x20]
    // 0x6f639c: r0 = ConcurrentModificationError()
    //     0x6f639c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6f63a0: ldur            x3, [fp, #-0x20]
    // 0x6f63a4: StoreField: r0->field_b = r3
    //     0x6f63a4: stur            w3, [x0, #0xb]
    // 0x6f63a8: r0 = Throw()
    //     0x6f63a8: bl              #0xd67e38  ; ThrowStub
    // 0x6f63ac: brk             #0
    // 0x6f63b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f63b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f63b4: b               #0x6f623c
    // 0x6f63b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f63b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f63bc: b               #0x6f627c
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4c9c, size: 0xac
    // 0xad4c9c: EnterFrame
    //     0xad4c9c: stp             fp, lr, [SP, #-0x10]!
    //     0xad4ca0: mov             fp, SP
    // 0xad4ca4: AllocStack(0x8)
    //     0xad4ca4: sub             SP, SP, #8
    // 0xad4ca8: CheckStackOverflow
    //     0xad4ca8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4cac: cmp             SP, x16
    //     0xad4cb0: b.ls            #0xad4d40
    // 0xad4cb4: r1 = Null
    //     0xad4cb4: mov             x1, NULL
    // 0xad4cb8: r2 = 6
    //     0xad4cb8: mov             x2, #6
    // 0xad4cbc: r0 = AllocateArray()
    //     0xad4cbc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4cc0: stur            x0, [fp, #-8]
    // 0xad4cc4: r17 = "Listenable.merge(["
    //     0xad4cc4: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2f0f0] "Listenable.merge(["
    //     0xad4cc8: ldr             x17, [x17, #0xf0]
    // 0xad4ccc: StoreField: r0->field_f = r17
    //     0xad4ccc: stur            w17, [x0, #0xf]
    // 0xad4cd0: ldr             x1, [fp, #0x10]
    // 0xad4cd4: LoadField: r2 = r1->field_7
    //     0xad4cd4: ldur            w2, [x1, #7]
    // 0xad4cd8: DecompressPointer r2
    //     0xad4cd8: add             x2, x2, HEAP, lsl #32
    // 0xad4cdc: r16 = ", "
    //     0xad4cdc: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad4ce0: stp             x16, x2, [SP, #-0x10]!
    // 0xad4ce4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad4ce4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad4ce8: r0 = join()
    //     0xad4ce8: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xad4cec: add             SP, SP, #0x10
    // 0xad4cf0: ldur            x1, [fp, #-8]
    // 0xad4cf4: ArrayStore: r1[1] = r0  ; List_4
    //     0xad4cf4: add             x25, x1, #0x13
    //     0xad4cf8: str             w0, [x25]
    //     0xad4cfc: tbz             w0, #0, #0xad4d18
    //     0xad4d00: ldurb           w16, [x1, #-1]
    //     0xad4d04: ldurb           w17, [x0, #-1]
    //     0xad4d08: and             x16, x17, x16, lsr #2
    //     0xad4d0c: tst             x16, HEAP, lsr #32
    //     0xad4d10: b.eq            #0xad4d18
    //     0xad4d14: bl              #0xd67e5c
    // 0xad4d18: ldur            x0, [fp, #-8]
    // 0xad4d1c: r17 = "])"
    //     0xad4d1c: add             x17, PP, #0xb, lsl #12  ; [pp+0xb298] "])"
    //     0xad4d20: ldr             x17, [x17, #0x298]
    // 0xad4d24: StoreField: r0->field_17 = r17
    //     0xad4d24: stur            w17, [x0, #0x17]
    // 0xad4d28: SaveReg r0
    //     0xad4d28: str             x0, [SP, #-8]!
    // 0xad4d2c: r0 = _interpolate()
    //     0xad4d2c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4d30: add             SP, SP, #8
    // 0xad4d34: LeaveFrame
    //     0xad4d34: mov             SP, fp
    //     0xad4d38: ldp             fp, lr, [SP], #0x10
    // 0xad4d3c: ret
    //     0xad4d3c: ret             
    // 0xad4d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4d40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4d44: b               #0xad4cb4
  }
}

// class id: 4356, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ValueListenable<X0> extends Listenable {
}

// class id: 4793, size: 0x24, field offset: 0x8
abstract class ChangeNotifier extends Object
    implements Listenable {

  static late final List<((dynamic) => void)?> _emptyListeners; // offset: 0xac0

  _ notifyListeners(/* No info */) {
    // ** addr: 0x500f60, size: 0x590
    // 0x500f60: EnterFrame
    //     0x500f60: stp             fp, lr, [SP, #-0x10]!
    //     0x500f64: mov             fp, SP
    // 0x500f68: AllocStack(0xc8)
    //     0x500f68: sub             SP, SP, #0xc8
    // 0x500f6c: CheckStackOverflow
    //     0x500f6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500f70: cmp             SP, x16
    //     0x500f74: b.ls            #0x5014b4
    // 0x500f78: r1 = 1
    //     0x500f78: mov             x1, #1
    // 0x500f7c: r0 = AllocateContext()
    //     0x500f7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x500f80: mov             x3, x0
    // 0x500f84: ldr             x2, [fp, #0x10]
    // 0x500f88: StoreField: r3->field_f = r2
    //     0x500f88: stur            w2, [x3, #0xf]
    // 0x500f8c: LoadField: r4 = r2->field_7
    //     0x500f8c: ldur            x4, [x2, #7]
    // 0x500f90: cbnz            x4, #0x500fa4
    // 0x500f94: r0 = Null
    //     0x500f94: mov             x0, NULL
    // 0x500f98: LeaveFrame
    //     0x500f98: mov             SP, fp
    //     0x500f9c: ldp             fp, lr, [SP], #0x10
    // 0x500fa0: ret
    //     0x500fa0: ret             
    // 0x500fa4: LoadField: r0 = r2->field_13
    //     0x500fa4: ldur            x0, [x2, #0x13]
    // 0x500fa8: add             x1, x0, #1
    // 0x500fac: StoreField: r2->field_13 = r1
    //     0x500fac: stur            x1, [x2, #0x13]
    // 0x500fb0: r0 = BoxInt64Instr(r4)
    //     0x500fb0: sbfiz           x0, x4, #1, #0x1f
    //     0x500fb4: cmp             x4, x0, asr #1
    //     0x500fb8: b.eq            #0x500fc4
    //     0x500fbc: bl              #0xd69bb8
    //     0x500fc0: stur            x4, [x0, #7]
    // 0x500fc4: mov             x5, x2
    // 0x500fc8: mov             x4, x3
    // 0x500fcc: mov             x3, x0
    // 0x500fd0: r2 = 0
    //     0x500fd0: mov             x2, #0
    // 0x500fd4: b               #0x5010fc
    // 0x500fd8: sub             SP, fp, #0xc8
    // 0x500fdc: mov             x3, x0
    // 0x500fe0: stur            x0, [fp, #-0x78]
    // 0x500fe4: mov             x0, x1
    // 0x500fe8: stur            x1, [fp, #-0x80]
    // 0x500fec: r1 = Null
    //     0x500fec: mov             x1, NULL
    // 0x500ff0: r2 = 4
    //     0x500ff0: mov             x2, #4
    // 0x500ff4: r0 = AllocateArray()
    //     0x500ff4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x500ff8: stur            x0, [fp, #-0x88]
    // 0x500ffc: r17 = "while dispatching notifications for "
    //     0x500ffc: ldr             x17, [PP, #0x3a10]  ; [pp+0x3a10] "while dispatching notifications for "
    // 0x501000: StoreField: r0->field_f = r17
    //     0x501000: stur            w17, [x0, #0xf]
    // 0x501004: ldr             x16, [fp, #0x10]
    // 0x501008: SaveReg r16
    //     0x501008: str             x16, [SP, #-8]!
    // 0x50100c: r0 = runtimeType()
    //     0x50100c: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0x501010: add             SP, SP, #8
    // 0x501014: ldur            x1, [fp, #-0x88]
    // 0x501018: ArrayStore: r1[1] = r0  ; List_4
    //     0x501018: add             x25, x1, #0x13
    //     0x50101c: str             w0, [x25]
    //     0x501020: tbz             w0, #0, #0x50103c
    //     0x501024: ldurb           w16, [x1, #-1]
    //     0x501028: ldurb           w17, [x0, #-1]
    //     0x50102c: and             x16, x17, x16, lsr #2
    //     0x501030: tst             x16, HEAP, lsr #32
    //     0x501034: b.eq            #0x50103c
    //     0x501038: bl              #0xd67e5c
    // 0x50103c: ldur            x16, [fp, #-0x88]
    // 0x501040: SaveReg r16
    //     0x501040: str             x16, [SP, #-8]!
    // 0x501044: r0 = _interpolate()
    //     0x501044: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x501048: add             SP, SP, #8
    // 0x50104c: r1 = <List<Object>>
    //     0x50104c: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x501050: stur            x0, [fp, #-0x88]
    // 0x501054: r0 = ErrorDescription()
    //     0x501054: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x501058: stur            x0, [fp, #-0x90]
    // 0x50105c: ldur            x16, [fp, #-0x88]
    // 0x501060: stp             x16, x0, [SP, #-0x10]!
    // 0x501064: r16 = Instance_DiagnosticLevel
    //     0x501064: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x501068: SaveReg r16
    //     0x501068: str             x16, [SP, #-8]!
    // 0x50106c: r0 = _ErrorDiagnostic()
    //     0x50106c: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x501070: add             SP, SP, #0x18
    // 0x501074: r0 = FlutterErrorDetails()
    //     0x501074: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x501078: mov             x3, x0
    // 0x50107c: ldur            x0, [fp, #-0x78]
    // 0x501080: stur            x3, [fp, #-0x88]
    // 0x501084: StoreField: r3->field_7 = r0
    //     0x501084: stur            w0, [x3, #7]
    // 0x501088: ldur            x0, [fp, #-0x80]
    // 0x50108c: StoreField: r3->field_b = r0
    //     0x50108c: stur            w0, [x3, #0xb]
    // 0x501090: r0 = "foundation library"
    //     0x501090: ldr             x0, [PP, #0x3a18]  ; [pp+0x3a18] "foundation library"
    // 0x501094: StoreField: r3->field_f = r0
    //     0x501094: stur            w0, [x3, #0xf]
    // 0x501098: ldur            x0, [fp, #-0x90]
    // 0x50109c: StoreField: r3->field_13 = r0
    //     0x50109c: stur            w0, [x3, #0x13]
    // 0x5010a0: ldur            x2, [fp, #-0x10]
    // 0x5010a4: r1 = Function '<anonymous closure>':.
    //     0x5010a4: ldr             x1, [PP, #0x3a20]  ; [pp+0x3a20] AnonymousClosure: (0x501538), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    // 0x5010a8: r0 = AllocateClosure()
    //     0x5010a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5010ac: mov             x1, x0
    // 0x5010b0: ldur            x0, [fp, #-0x88]
    // 0x5010b4: StoreField: r0->field_1b = r1
    //     0x5010b4: stur            w1, [x0, #0x1b]
    // 0x5010b8: r1 = false
    //     0x5010b8: add             x1, NULL, #0x30  ; false
    // 0x5010bc: StoreField: r0->field_1f = r1
    //     0x5010bc: stur            w1, [x0, #0x1f]
    // 0x5010c0: SaveReg r0
    //     0x5010c0: str             x0, [SP, #-8]!
    // 0x5010c4: r0 = reportError()
    //     0x5010c4: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x5010c8: add             SP, SP, #8
    // 0x5010cc: ldr             x3, [fp, #0x10]
    // 0x5010d0: ldur            x2, [fp, #-0x10]
    // 0x5010d4: ldur            x1, [fp, #-0x38]
    // 0x5010d8: ldur            x0, [fp, #-0x40]
    // 0x5010dc: r4 = LoadInt32Instr(r0)
    //     0x5010dc: sbfx            x4, x0, #1, #0x1f
    //     0x5010e0: tbz             w0, #0, #0x5010e8
    //     0x5010e4: ldur            x4, [x0, #7]
    // 0x5010e8: add             x0, x4, #1
    // 0x5010ec: mov             x5, x3
    // 0x5010f0: mov             x4, x2
    // 0x5010f4: mov             x3, x1
    // 0x5010f8: mov             x2, x0
    // 0x5010fc: stur            x5, [fp, #-0x88]
    // 0x501100: stur            x4, [fp, #-0x90]
    // 0x501104: stur            x3, [fp, #-0x98]
    // 0x501108: stur            x2, [fp, #-0xa0]
    // 0x50110c: CheckStackOverflow
    //     0x50110c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x501110: cmp             SP, x16
    //     0x501114: b.ls            #0x5014bc
    // 0x501118: r0 = LoadInt32Instr(r3)
    //     0x501118: sbfx            x0, x3, #1, #0x1f
    //     0x50111c: tbz             w3, #0, #0x501124
    //     0x501120: ldur            x0, [x3, #7]
    // 0x501124: cmp             x2, x0
    // 0x501128: b.ge            #0x5011b0
    // 0x50112c: LoadField: r6 = r5->field_f
    //     0x50112c: ldur            w6, [x5, #0xf]
    // 0x501130: DecompressPointer r6
    //     0x501130: add             x6, x6, HEAP, lsl #32
    // 0x501134: LoadField: r0 = r6->field_b
    //     0x501134: ldur            w0, [x6, #0xb]
    // 0x501138: DecompressPointer r0
    //     0x501138: add             x0, x0, HEAP, lsl #32
    // 0x50113c: r1 = LoadInt32Instr(r0)
    //     0x50113c: sbfx            x1, x0, #1, #0x1f
    // 0x501140: mov             x0, x1
    // 0x501144: mov             x1, x2
    // 0x501148: cmp             x1, x0
    // 0x50114c: b.hs            #0x5014c4
    // 0x501150: r0 = BoxInt64Instr(r2)
    //     0x501150: sbfiz           x0, x2, #1, #0x1f
    //     0x501154: cmp             x2, x0, asr #1
    //     0x501158: b.eq            #0x501164
    //     0x50115c: bl              #0xd69bb8
    //     0x501160: stur            x2, [x0, #7]
    // 0x501164: mov             x1, x0
    // 0x501168: stur            x1, [fp, #-0x80]
    // 0x50116c: ArrayLoad: r7 = r6[r2]  ; Unknown_4
    //     0x50116c: add             x16, x6, x2, lsl #2
    //     0x501170: ldur            w7, [x16, #0xf]
    // 0x501174: DecompressPointer r7
    //     0x501174: add             x7, x7, HEAP, lsl #32
    // 0x501178: stur            x7, [fp, #-0x78]
    // 0x50117c: cmp             w7, NULL
    // 0x501180: b.eq            #0x50119c
    // 0x501184: SaveReg r7
    //     0x501184: str             x7, [SP, #-8]!
    // 0x501188: mov             x0, x7
    // 0x50118c: ClosureCall
    //     0x50118c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x501190: ldur            x2, [x0, #0x1f]
    //     0x501194: blr             x2
    // 0x501198: add             SP, SP, #8
    // 0x50119c: ldur            x3, [fp, #-0x88]
    // 0x5011a0: ldur            x2, [fp, #-0x90]
    // 0x5011a4: ldur            x1, [fp, #-0x98]
    // 0x5011a8: ldur            x0, [fp, #-0x80]
    // 0x5011ac: b               #0x5010dc
    // 0x5011b0: mov             x3, x5
    // 0x5011b4: LoadField: r0 = r3->field_13
    //     0x5011b4: ldur            x0, [x3, #0x13]
    // 0x5011b8: sub             x1, x0, #1
    // 0x5011bc: StoreField: r3->field_13 = r1
    //     0x5011bc: stur            x1, [x3, #0x13]
    // 0x5011c0: cbnz            x1, #0x5014a4
    // 0x5011c4: LoadField: r0 = r3->field_1b
    //     0x5011c4: ldur            x0, [x3, #0x1b]
    // 0x5011c8: cmp             x0, #0
    // 0x5011cc: b.le            #0x5014a4
    // 0x5011d0: LoadField: r4 = r3->field_7
    //     0x5011d0: ldur            x4, [x3, #7]
    // 0x5011d4: stur            x4, [fp, #-0xb0]
    // 0x5011d8: sub             x5, x4, x0
    // 0x5011dc: stur            x5, [fp, #-0xa8]
    // 0x5011e0: lsl             x0, x5, #1
    // 0x5011e4: LoadField: r6 = r3->field_f
    //     0x5011e4: ldur            w6, [x3, #0xf]
    // 0x5011e8: DecompressPointer r6
    //     0x5011e8: add             x6, x6, HEAP, lsl #32
    // 0x5011ec: stur            x6, [fp, #-0x78]
    // 0x5011f0: LoadField: r1 = r6->field_b
    //     0x5011f0: ldur            w1, [x6, #0xb]
    // 0x5011f4: DecompressPointer r1
    //     0x5011f4: add             x1, x1, HEAP, lsl #32
    // 0x5011f8: r7 = LoadInt32Instr(r1)
    //     0x5011f8: sbfx            x7, x1, #1, #0x1f
    // 0x5011fc: stur            x7, [fp, #-0xa0]
    // 0x501200: cmp             x0, x7
    // 0x501204: b.gt            #0x501334
    // 0x501208: r0 = BoxInt64Instr(r5)
    //     0x501208: sbfiz           x0, x5, #1, #0x1f
    //     0x50120c: cmp             x5, x0, asr #1
    //     0x501210: b.eq            #0x50121c
    //     0x501214: bl              #0xd69bb8
    //     0x501218: stur            x5, [x0, #7]
    // 0x50121c: mov             x2, x0
    // 0x501220: r1 = <((dynamic this) => void?)?>
    //     0x501220: ldr             x1, [PP, #0x3a28]  ; [pp+0x3a28] TypeArguments: <((dynamic this) => void?)?>
    // 0x501224: r0 = AllocateArray()
    //     0x501224: bl              #0xd6987c  ; AllocateArrayStub
    // 0x501228: mov             x3, x0
    // 0x50122c: stur            x3, [fp, #-0x90]
    // 0x501230: r7 = 0
    //     0x501230: mov             x7, #0
    // 0x501234: r6 = 0
    //     0x501234: mov             x6, #0
    // 0x501238: ldur            x4, [fp, #-0xb0]
    // 0x50123c: ldur            x5, [fp, #-0x78]
    // 0x501240: stur            x7, [fp, #-0xc0]
    // 0x501244: stur            x6, [fp, #-0xc8]
    // 0x501248: CheckStackOverflow
    //     0x501248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50124c: cmp             SP, x16
    //     0x501250: b.ls            #0x5014c8
    // 0x501254: cmp             x6, x4
    // 0x501258: b.ge            #0x501308
    // 0x50125c: ldur            x0, [fp, #-0xa0]
    // 0x501260: mov             x1, x6
    // 0x501264: cmp             x1, x0
    // 0x501268: b.hs            #0x5014d0
    // 0x50126c: ArrayLoad: r8 = r5[r6]  ; Unknown_4
    //     0x50126c: add             x16, x5, x6, lsl #2
    //     0x501270: ldur            w8, [x16, #0xf]
    // 0x501274: DecompressPointer r8
    //     0x501274: add             x8, x8, HEAP, lsl #32
    // 0x501278: stur            x8, [fp, #-0x80]
    // 0x50127c: cmp             w8, NULL
    // 0x501280: b.eq            #0x5012f0
    // 0x501284: add             x9, x7, #1
    // 0x501288: mov             x0, x8
    // 0x50128c: stur            x9, [fp, #-0xb8]
    // 0x501290: r2 = Null
    //     0x501290: mov             x2, NULL
    // 0x501294: r1 = Null
    //     0x501294: mov             x1, NULL
    // 0x501298: r8 = ((dynamic this) => void?)?
    //     0x501298: ldr             x8, [PP, #0x3a30]  ; [pp+0x3a30] FunctionType: ((dynamic this) => void?)?
    // 0x50129c: r3 = Null
    //     0x50129c: ldr             x3, [PP, #0x3a38]  ; [pp+0x3a38] Null
    // 0x5012a0: r0 = DefaultNullableTypeTest()
    //     0x5012a0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x5012a4: ldur            x0, [fp, #-0xa8]
    // 0x5012a8: ldur            x1, [fp, #-0xc0]
    // 0x5012ac: cmp             x1, x0
    // 0x5012b0: b.hs            #0x5014d4
    // 0x5012b4: ldur            x1, [fp, #-0x90]
    // 0x5012b8: ldur            x0, [fp, #-0x80]
    // 0x5012bc: ldur            x2, [fp, #-0xc0]
    // 0x5012c0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x5012c0: add             x25, x1, x2, lsl #2
    //     0x5012c4: add             x25, x25, #0xf
    //     0x5012c8: str             w0, [x25]
    //     0x5012cc: tbz             w0, #0, #0x5012e8
    //     0x5012d0: ldurb           w16, [x1, #-1]
    //     0x5012d4: ldurb           w17, [x0, #-1]
    //     0x5012d8: and             x16, x17, x16, lsr #2
    //     0x5012dc: tst             x16, HEAP, lsr #32
    //     0x5012e0: b.eq            #0x5012e8
    //     0x5012e4: bl              #0xd67e5c
    // 0x5012e8: ldur            x7, [fp, #-0xb8]
    // 0x5012ec: b               #0x5012f8
    // 0x5012f0: mov             x2, x7
    // 0x5012f4: mov             x7, x2
    // 0x5012f8: ldur            x0, [fp, #-0xc8]
    // 0x5012fc: add             x6, x0, #1
    // 0x501300: ldur            x3, [fp, #-0x90]
    // 0x501304: b               #0x501238
    // 0x501308: ldur            x3, [fp, #-0x88]
    // 0x50130c: ldur            x0, [fp, #-0x90]
    // 0x501310: StoreField: r3->field_f = r0
    //     0x501310: stur            w0, [x3, #0xf]
    //     0x501314: ldurb           w16, [x3, #-1]
    //     0x501318: ldurb           w17, [x0, #-1]
    //     0x50131c: and             x16, x17, x16, lsr #2
    //     0x501320: tst             x16, HEAP, lsr #32
    //     0x501324: b.eq            #0x50132c
    //     0x501328: bl              #0xd682ac
    // 0x50132c: mov             x1, x3
    // 0x501330: b               #0x501494
    // 0x501334: mov             x4, x6
    // 0x501338: LoadField: r5 = r4->field_7
    //     0x501338: ldur            w5, [x4, #7]
    // 0x50133c: DecompressPointer r5
    //     0x50133c: add             x5, x5, HEAP, lsl #32
    // 0x501340: stur            x5, [fp, #-0x90]
    // 0x501344: r7 = 0
    //     0x501344: mov             x7, #0
    // 0x501348: ldur            x6, [fp, #-0xa8]
    // 0x50134c: stur            x7, [fp, #-0xb8]
    // 0x501350: CheckStackOverflow
    //     0x501350: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x501354: cmp             SP, x16
    //     0x501358: b.ls            #0x5014d8
    // 0x50135c: cmp             x7, x6
    // 0x501360: b.ge            #0x501490
    // 0x501364: ldur            x0, [fp, #-0xa0]
    // 0x501368: mov             x1, x7
    // 0x50136c: cmp             x1, x0
    // 0x501370: b.hs            #0x5014e0
    // 0x501374: ArrayLoad: r0 = r4[r7]  ; Unknown_4
    //     0x501374: add             x16, x4, x7, lsl #2
    //     0x501378: ldur            w0, [x16, #0xf]
    // 0x50137c: DecompressPointer r0
    //     0x50137c: add             x0, x0, HEAP, lsl #32
    // 0x501380: cmp             w0, NULL
    // 0x501384: b.ne            #0x501474
    // 0x501388: add             x0, x7, #1
    // 0x50138c: mov             x8, x0
    // 0x501390: stur            x8, [fp, #-0xb0]
    // 0x501394: CheckStackOverflow
    //     0x501394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x501398: cmp             SP, x16
    //     0x50139c: b.ls            #0x5014e4
    // 0x5013a0: ldur            x0, [fp, #-0xa0]
    // 0x5013a4: mov             x1, x8
    // 0x5013a8: cmp             x1, x0
    // 0x5013ac: b.hs            #0x5014ec
    // 0x5013b0: ArrayLoad: r9 = r4[r8]  ; Unknown_4
    //     0x5013b0: add             x16, x4, x8, lsl #2
    //     0x5013b4: ldur            w9, [x16, #0xf]
    // 0x5013b8: DecompressPointer r9
    //     0x5013b8: add             x9, x9, HEAP, lsl #32
    // 0x5013bc: stur            x9, [fp, #-0x80]
    // 0x5013c0: cmp             w9, NULL
    // 0x5013c4: b.ne            #0x5013d4
    // 0x5013c8: add             x0, x8, #1
    // 0x5013cc: mov             x8, x0
    // 0x5013d0: b               #0x501390
    // 0x5013d4: mov             x0, x9
    // 0x5013d8: mov             x2, x5
    // 0x5013dc: r1 = Null
    //     0x5013dc: mov             x1, NULL
    // 0x5013e0: cmp             w2, NULL
    // 0x5013e4: b.eq            #0x501400
    // 0x5013e8: LoadField: r4 = r2->field_17
    //     0x5013e8: ldur            w4, [x2, #0x17]
    // 0x5013ec: DecompressPointer r4
    //     0x5013ec: add             x4, x4, HEAP, lsl #32
    // 0x5013f0: r8 = X0
    //     0x5013f0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5013f4: LoadField: r9 = r4->field_7
    //     0x5013f4: ldur            x9, [x4, #7]
    // 0x5013f8: r3 = Null
    //     0x5013f8: ldr             x3, [PP, #0x3a48]  ; [pp+0x3a48] Null
    // 0x5013fc: blr             x9
    // 0x501400: ldur            x1, [fp, #-0x78]
    // 0x501404: ldur            x0, [fp, #-0x80]
    // 0x501408: ldur            x3, [fp, #-0xb8]
    // 0x50140c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x50140c: add             x25, x1, x3, lsl #2
    //     0x501410: add             x25, x25, #0xf
    //     0x501414: str             w0, [x25]
    //     0x501418: tbz             w0, #0, #0x501434
    //     0x50141c: ldurb           w16, [x1, #-1]
    //     0x501420: ldurb           w17, [x0, #-1]
    //     0x501424: and             x16, x17, x16, lsr #2
    //     0x501428: tst             x16, HEAP, lsr #32
    //     0x50142c: b.eq            #0x501434
    //     0x501430: bl              #0xd67e5c
    // 0x501434: ldur            x2, [fp, #-0x90]
    // 0x501438: r0 = Null
    //     0x501438: mov             x0, NULL
    // 0x50143c: r1 = Null
    //     0x50143c: mov             x1, NULL
    // 0x501440: cmp             w2, NULL
    // 0x501444: b.eq            #0x501460
    // 0x501448: LoadField: r4 = r2->field_17
    //     0x501448: ldur            w4, [x2, #0x17]
    // 0x50144c: DecompressPointer r4
    //     0x50144c: add             x4, x4, HEAP, lsl #32
    // 0x501450: r8 = X0
    //     0x501450: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x501454: LoadField: r9 = r4->field_7
    //     0x501454: ldur            x9, [x4, #7]
    // 0x501458: r3 = Null
    //     0x501458: ldr             x3, [PP, #0x3a58]  ; [pp+0x3a58] Null
    // 0x50145c: blr             x9
    // 0x501460: ldur            x1, [fp, #-0x78]
    // 0x501464: ldur            x2, [fp, #-0xb0]
    // 0x501468: ArrayStore: r1[r2] = rNULL  ; Unknown_4
    //     0x501468: add             x3, x1, x2, lsl #2
    //     0x50146c: stur            NULL, [x3, #0xf]
    // 0x501470: b               #0x501478
    // 0x501474: mov             x1, x4
    // 0x501478: ldur            x2, [fp, #-0xb8]
    // 0x50147c: add             x7, x2, #1
    // 0x501480: ldur            x3, [fp, #-0x88]
    // 0x501484: mov             x4, x1
    // 0x501488: ldur            x5, [fp, #-0x90]
    // 0x50148c: b               #0x501348
    // 0x501490: ldur            x1, [fp, #-0x88]
    // 0x501494: ldur            x2, [fp, #-0xa8]
    // 0x501498: r3 = 0
    //     0x501498: mov             x3, #0
    // 0x50149c: StoreField: r1->field_1b = r3
    //     0x50149c: stur            x3, [x1, #0x1b]
    // 0x5014a0: StoreField: r1->field_7 = r2
    //     0x5014a0: stur            x2, [x1, #7]
    // 0x5014a4: r0 = Null
    //     0x5014a4: mov             x0, NULL
    // 0x5014a8: LeaveFrame
    //     0x5014a8: mov             SP, fp
    //     0x5014ac: ldp             fp, lr, [SP], #0x10
    // 0x5014b0: ret
    //     0x5014b0: ret             
    // 0x5014b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5014b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5014b8: b               #0x500f78
    // 0x5014bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5014bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5014c0: b               #0x501118
    // 0x5014c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5014c4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5014c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5014c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5014cc: b               #0x501254
    // 0x5014d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5014d0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5014d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5014d4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5014d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5014d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5014dc: b               #0x50135c
    // 0x5014e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5014e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5014e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5014e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5014e8: b               #0x5013a0
    // 0x5014ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5014ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void notifyListeners(dynamic) {
    // ** addr: 0x5014f0, size: 0x48
    // 0x5014f0: EnterFrame
    //     0x5014f0: stp             fp, lr, [SP, #-0x10]!
    //     0x5014f4: mov             fp, SP
    // 0x5014f8: ldr             x0, [fp, #0x10]
    // 0x5014fc: LoadField: r1 = r0->field_17
    //     0x5014fc: ldur            w1, [x0, #0x17]
    // 0x501500: DecompressPointer r1
    //     0x501500: add             x1, x1, HEAP, lsl #32
    // 0x501504: CheckStackOverflow
    //     0x501504: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x501508: cmp             SP, x16
    //     0x50150c: b.ls            #0x501530
    // 0x501510: LoadField: r0 = r1->field_f
    //     0x501510: ldur            w0, [x1, #0xf]
    // 0x501514: DecompressPointer r0
    //     0x501514: add             x0, x0, HEAP, lsl #32
    // 0x501518: SaveReg r0
    //     0x501518: str             x0, [SP, #-8]!
    // 0x50151c: r0 = notifyListeners()
    //     0x50151c: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x501520: add             SP, SP, #8
    // 0x501524: LeaveFrame
    //     0x501524: mov             SP, fp
    //     0x501528: ldp             fp, lr, [SP], #0x10
    // 0x50152c: ret
    //     0x50152c: ret             
    // 0x501530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x501530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x501534: b               #0x501510
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0x501538, size: 0x128
    // 0x501538: EnterFrame
    //     0x501538: stp             fp, lr, [SP, #-0x10]!
    //     0x50153c: mov             fp, SP
    // 0x501540: AllocStack(0x10)
    //     0x501540: sub             SP, SP, #0x10
    // 0x501544: SetupParameters()
    //     0x501544: ldr             x0, [fp, #0x10]
    //     0x501548: ldur            w3, [x0, #0x17]
    //     0x50154c: add             x3, x3, HEAP, lsl #32
    //     0x501550: stur            x3, [fp, #-8]
    // 0x501554: CheckStackOverflow
    //     0x501554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x501558: cmp             SP, x16
    //     0x50155c: b.ls            #0x501658
    // 0x501560: r1 = Null
    //     0x501560: mov             x1, NULL
    // 0x501564: r2 = 6
    //     0x501564: mov             x2, #6
    // 0x501568: r0 = AllocateArray()
    //     0x501568: bl              #0xd6987c  ; AllocateArrayStub
    // 0x50156c: stur            x0, [fp, #-0x10]
    // 0x501570: r17 = "The "
    //     0x501570: ldr             x17, [PP, #0x3a68]  ; [pp+0x3a68] "The "
    // 0x501574: StoreField: r0->field_f = r17
    //     0x501574: stur            w17, [x0, #0xf]
    // 0x501578: ldur            x1, [fp, #-8]
    // 0x50157c: LoadField: r2 = r1->field_f
    //     0x50157c: ldur            w2, [x1, #0xf]
    // 0x501580: DecompressPointer r2
    //     0x501580: add             x2, x2, HEAP, lsl #32
    // 0x501584: SaveReg r2
    //     0x501584: str             x2, [SP, #-8]!
    // 0x501588: r0 = runtimeType()
    //     0x501588: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0x50158c: add             SP, SP, #8
    // 0x501590: ldur            x1, [fp, #-0x10]
    // 0x501594: ArrayStore: r1[1] = r0  ; List_4
    //     0x501594: add             x25, x1, #0x13
    //     0x501598: str             w0, [x25]
    //     0x50159c: tbz             w0, #0, #0x5015b8
    //     0x5015a0: ldurb           w16, [x1, #-1]
    //     0x5015a4: ldurb           w17, [x0, #-1]
    //     0x5015a8: and             x16, x17, x16, lsr #2
    //     0x5015ac: tst             x16, HEAP, lsr #32
    //     0x5015b0: b.eq            #0x5015b8
    //     0x5015b4: bl              #0xd67e5c
    // 0x5015b8: ldur            x0, [fp, #-0x10]
    // 0x5015bc: r17 = " sending notification was"
    //     0x5015bc: ldr             x17, [PP, #0x3a70]  ; [pp+0x3a70] " sending notification was"
    // 0x5015c0: StoreField: r0->field_17 = r17
    //     0x5015c0: stur            w17, [x0, #0x17]
    // 0x5015c4: SaveReg r0
    //     0x5015c4: str             x0, [SP, #-8]!
    // 0x5015c8: r0 = _interpolate()
    //     0x5015c8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5015cc: add             SP, SP, #8
    // 0x5015d0: ldur            x0, [fp, #-8]
    // 0x5015d4: LoadField: r2 = r0->field_f
    //     0x5015d4: ldur            w2, [x0, #0xf]
    // 0x5015d8: DecompressPointer r2
    //     0x5015d8: add             x2, x2, HEAP, lsl #32
    // 0x5015dc: stur            x2, [fp, #-0x10]
    // 0x5015e0: r1 = <ChangeNotifier>
    //     0x5015e0: ldr             x1, [PP, #0x3a78]  ; [pp+0x3a78] TypeArguments: <ChangeNotifier>
    // 0x5015e4: r0 = DiagnosticsProperty()
    //     0x5015e4: bl              #0x4fc570  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x30)
    // 0x5015e8: mov             x3, x0
    // 0x5015ec: r0 = Instance__NoDefaultValue
    //     0x5015ec: ldr             x0, [PP, #0xf40]  ; [pp+0xf40] Obj!_NoDefaultValue@b387f1
    // 0x5015f0: stur            x3, [fp, #-8]
    // 0x5015f4: StoreField: r3->field_23 = r0
    //     0x5015f4: stur            w0, [x3, #0x23]
    // 0x5015f8: r0 = false
    //     0x5015f8: add             x0, NULL, #0x30  ; false
    // 0x5015fc: StoreField: r3->field_13 = r0
    //     0x5015fc: stur            w0, [x3, #0x13]
    // 0x501600: r0 = true
    //     0x501600: add             x0, NULL, #0x20  ; true
    // 0x501604: StoreField: r3->field_1b = r0
    //     0x501604: stur            w0, [x3, #0x1b]
    // 0x501608: ldur            x0, [fp, #-0x10]
    // 0x50160c: StoreField: r3->field_17 = r0
    //     0x50160c: stur            w0, [x3, #0x17]
    // 0x501610: r0 = Instance_DiagnosticLevel
    //     0x501610: ldr             x0, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x501614: StoreField: r3->field_27 = r0
    //     0x501614: stur            w0, [x3, #0x27]
    // 0x501618: r1 = Null
    //     0x501618: mov             x1, NULL
    // 0x50161c: r2 = 2
    //     0x50161c: mov             x2, #2
    // 0x501620: r0 = AllocateArray()
    //     0x501620: bl              #0xd6987c  ; AllocateArrayStub
    // 0x501624: mov             x2, x0
    // 0x501628: ldur            x0, [fp, #-8]
    // 0x50162c: stur            x2, [fp, #-0x10]
    // 0x501630: StoreField: r2->field_f = r0
    //     0x501630: stur            w0, [x2, #0xf]
    // 0x501634: r1 = <DiagnosticsNode>
    //     0x501634: ldr             x1, [PP, #0x3930]  ; [pp+0x3930] TypeArguments: <DiagnosticsNode>
    // 0x501638: r0 = AllocateGrowableArray()
    //     0x501638: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x50163c: ldur            x1, [fp, #-0x10]
    // 0x501640: StoreField: r0->field_f = r1
    //     0x501640: stur            w1, [x0, #0xf]
    // 0x501644: r1 = 2
    //     0x501644: mov             x1, #2
    // 0x501648: StoreField: r0->field_b = r1
    //     0x501648: stur            w1, [x0, #0xb]
    // 0x50164c: LeaveFrame
    //     0x50164c: mov             SP, fp
    //     0x501650: ldp             fp, lr, [SP], #0x10
    // 0x501654: ret
    //     0x501654: ret             
    // 0x501658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x501658: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50165c: b               #0x501560
  }
  static List<((dynamic) => void)?> _emptyListeners() {
    // ** addr: 0x515210, size: 0x20
    // 0x515210: EnterFrame
    //     0x515210: stp             fp, lr, [SP, #-0x10]!
    //     0x515214: mov             fp, SP
    // 0x515218: r1 = <((dynamic this) => void?)?>
    //     0x515218: ldr             x1, [PP, #0x3a28]  ; [pp+0x3a28] TypeArguments: <((dynamic this) => void?)?>
    // 0x51521c: r2 = 0
    //     0x51521c: mov             x2, #0
    // 0x515220: r0 = AllocateArray()
    //     0x515220: bl              #0xd6987c  ; AllocateArrayStub
    // 0x515224: LeaveFrame
    //     0x515224: mov             SP, fp
    //     0x515228: ldp             fp, lr, [SP], #0x10
    // 0x51522c: ret
    //     0x51522c: ret             
  }
  _ addListener(/* No info */) {
    // ** addr: 0x6e79e8, size: 0x234
    // 0x6e79e8: EnterFrame
    //     0x6e79e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e79ec: mov             fp, SP
    // 0x6e79f0: AllocStack(0x38)
    //     0x6e79f0: sub             SP, SP, #0x38
    // 0x6e79f4: ldr             x0, [fp, #0x18]
    // 0x6e79f8: LoadField: r3 = r0->field_7
    //     0x6e79f8: ldur            x3, [x0, #7]
    // 0x6e79fc: stur            x3, [fp, #-8]
    // 0x6e7a00: LoadField: r4 = r0->field_f
    //     0x6e7a00: ldur            w4, [x0, #0xf]
    // 0x6e7a04: DecompressPointer r4
    //     0x6e7a04: add             x4, x4, HEAP, lsl #32
    // 0x6e7a08: stur            x4, [fp, #-0x20]
    // 0x6e7a0c: LoadField: r1 = r4->field_b
    //     0x6e7a0c: ldur            w1, [x4, #0xb]
    // 0x6e7a10: DecompressPointer r1
    //     0x6e7a10: add             x1, x1, HEAP, lsl #32
    // 0x6e7a14: r5 = LoadInt32Instr(r1)
    //     0x6e7a14: sbfx            x5, x1, #1, #0x1f
    // 0x6e7a18: stur            x5, [fp, #-0x18]
    // 0x6e7a1c: cmp             x3, x5
    // 0x6e7a20: b.ne            #0x6e7b60
    // 0x6e7a24: cbnz            x3, #0x6e7a64
    // 0x6e7a28: r1 = <((dynamic this) => void?)?>
    //     0x6e7a28: ldr             x1, [PP, #0x3a28]  ; [pp+0x3a28] TypeArguments: <((dynamic this) => void?)?>
    // 0x6e7a2c: r2 = 2
    //     0x6e7a2c: mov             x2, #2
    // 0x6e7a30: r0 = AllocateArray()
    //     0x6e7a30: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6e7a34: mov             x1, x0
    // 0x6e7a38: ldr             x3, [fp, #0x18]
    // 0x6e7a3c: StoreField: r3->field_f = r0
    //     0x6e7a3c: stur            w0, [x3, #0xf]
    //     0x6e7a40: ldurb           w16, [x3, #-1]
    //     0x6e7a44: ldurb           w17, [x0, #-1]
    //     0x6e7a48: and             x16, x17, x16, lsr #2
    //     0x6e7a4c: tst             x16, HEAP, lsr #32
    //     0x6e7a50: b.eq            #0x6e7a58
    //     0x6e7a54: bl              #0xd682ac
    // 0x6e7a58: mov             x0, x1
    // 0x6e7a5c: mov             x1, x3
    // 0x6e7a60: b               #0x6e7b58
    // 0x6e7a64: mov             x3, x0
    // 0x6e7a68: lsl             x0, x5, #1
    // 0x6e7a6c: stur            x0, [fp, #-0x10]
    // 0x6e7a70: lsl             x2, x0, #1
    // 0x6e7a74: r1 = <((dynamic this) => void?)?>
    //     0x6e7a74: ldr             x1, [PP, #0x3a28]  ; [pp+0x3a28] TypeArguments: <((dynamic this) => void?)?>
    // 0x6e7a78: r0 = AllocateArray()
    //     0x6e7a78: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6e7a7c: mov             x3, x0
    // 0x6e7a80: stur            x3, [fp, #-0x38]
    // 0x6e7a84: r6 = 0
    //     0x6e7a84: mov             x6, #0
    // 0x6e7a88: ldur            x5, [fp, #-8]
    // 0x6e7a8c: ldur            x4, [fp, #-0x20]
    // 0x6e7a90: stur            x6, [fp, #-0x30]
    // 0x6e7a94: CheckStackOverflow
    //     0x6e7a94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e7a98: cmp             SP, x16
    //     0x6e7a9c: b.ls            #0x6e7c08
    // 0x6e7aa0: cmp             x6, x5
    // 0x6e7aa4: b.ge            #0x6e7b30
    // 0x6e7aa8: ldur            x0, [fp, #-0x18]
    // 0x6e7aac: mov             x1, x6
    // 0x6e7ab0: cmp             x1, x0
    // 0x6e7ab4: b.hs            #0x6e7c10
    // 0x6e7ab8: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x6e7ab8: add             x16, x4, x6, lsl #2
    //     0x6e7abc: ldur            w7, [x16, #0xf]
    // 0x6e7ac0: DecompressPointer r7
    //     0x6e7ac0: add             x7, x7, HEAP, lsl #32
    // 0x6e7ac4: mov             x0, x7
    // 0x6e7ac8: stur            x7, [fp, #-0x28]
    // 0x6e7acc: r2 = Null
    //     0x6e7acc: mov             x2, NULL
    // 0x6e7ad0: r1 = Null
    //     0x6e7ad0: mov             x1, NULL
    // 0x6e7ad4: r8 = ((dynamic this) => void?)?
    //     0x6e7ad4: ldr             x8, [PP, #0x3a30]  ; [pp+0x3a30] FunctionType: ((dynamic this) => void?)?
    // 0x6e7ad8: r3 = Null
    //     0x6e7ad8: ldr             x3, [PP, #0x4d68]  ; [pp+0x4d68] Null
    // 0x6e7adc: r0 = DefaultNullableTypeTest()
    //     0x6e7adc: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6e7ae0: ldur            x0, [fp, #-0x10]
    // 0x6e7ae4: ldur            x1, [fp, #-0x30]
    // 0x6e7ae8: cmp             x1, x0
    // 0x6e7aec: b.hs            #0x6e7c14
    // 0x6e7af0: ldur            x1, [fp, #-0x38]
    // 0x6e7af4: ldur            x0, [fp, #-0x28]
    // 0x6e7af8: ldur            x2, [fp, #-0x30]
    // 0x6e7afc: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6e7afc: add             x25, x1, x2, lsl #2
    //     0x6e7b00: add             x25, x25, #0xf
    //     0x6e7b04: str             w0, [x25]
    //     0x6e7b08: tbz             w0, #0, #0x6e7b24
    //     0x6e7b0c: ldurb           w16, [x1, #-1]
    //     0x6e7b10: ldurb           w17, [x0, #-1]
    //     0x6e7b14: and             x16, x17, x16, lsr #2
    //     0x6e7b18: tst             x16, HEAP, lsr #32
    //     0x6e7b1c: b.eq            #0x6e7b24
    //     0x6e7b20: bl              #0xd67e5c
    // 0x6e7b24: add             x6, x2, #1
    // 0x6e7b28: ldur            x3, [fp, #-0x38]
    // 0x6e7b2c: b               #0x6e7a88
    // 0x6e7b30: ldr             x1, [fp, #0x18]
    // 0x6e7b34: ldur            x0, [fp, #-0x38]
    // 0x6e7b38: StoreField: r1->field_f = r0
    //     0x6e7b38: stur            w0, [x1, #0xf]
    //     0x6e7b3c: ldurb           w16, [x1, #-1]
    //     0x6e7b40: ldurb           w17, [x0, #-1]
    //     0x6e7b44: and             x16, x17, x16, lsr #2
    //     0x6e7b48: tst             x16, HEAP, lsr #32
    //     0x6e7b4c: b.eq            #0x6e7b54
    //     0x6e7b50: bl              #0xd6826c
    // 0x6e7b54: ldur            x0, [fp, #-0x38]
    // 0x6e7b58: mov             x4, x0
    // 0x6e7b5c: b               #0x6e7b68
    // 0x6e7b60: mov             x1, x0
    // 0x6e7b64: ldur            x4, [fp, #-0x20]
    // 0x6e7b68: ldur            x3, [fp, #-8]
    // 0x6e7b6c: stur            x4, [fp, #-0x20]
    // 0x6e7b70: add             x0, x3, #1
    // 0x6e7b74: StoreField: r1->field_7 = r0
    //     0x6e7b74: stur            x0, [x1, #7]
    // 0x6e7b78: LoadField: r2 = r4->field_7
    //     0x6e7b78: ldur            w2, [x4, #7]
    // 0x6e7b7c: DecompressPointer r2
    //     0x6e7b7c: add             x2, x2, HEAP, lsl #32
    // 0x6e7b80: ldr             x0, [fp, #0x10]
    // 0x6e7b84: r1 = Null
    //     0x6e7b84: mov             x1, NULL
    // 0x6e7b88: cmp             w2, NULL
    // 0x6e7b8c: b.eq            #0x6e7ba8
    // 0x6e7b90: LoadField: r4 = r2->field_17
    //     0x6e7b90: ldur            w4, [x2, #0x17]
    // 0x6e7b94: DecompressPointer r4
    //     0x6e7b94: add             x4, x4, HEAP, lsl #32
    // 0x6e7b98: r8 = X0
    //     0x6e7b98: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e7b9c: LoadField: r9 = r4->field_7
    //     0x6e7b9c: ldur            x9, [x4, #7]
    // 0x6e7ba0: r3 = Null
    //     0x6e7ba0: ldr             x3, [PP, #0x4d78]  ; [pp+0x4d78] Null
    // 0x6e7ba4: blr             x9
    // 0x6e7ba8: ldur            x2, [fp, #-0x20]
    // 0x6e7bac: LoadField: r3 = r2->field_b
    //     0x6e7bac: ldur            w3, [x2, #0xb]
    // 0x6e7bb0: DecompressPointer r3
    //     0x6e7bb0: add             x3, x3, HEAP, lsl #32
    // 0x6e7bb4: r0 = LoadInt32Instr(r3)
    //     0x6e7bb4: sbfx            x0, x3, #1, #0x1f
    // 0x6e7bb8: ldur            x1, [fp, #-8]
    // 0x6e7bbc: cmp             x1, x0
    // 0x6e7bc0: b.hs            #0x6e7c18
    // 0x6e7bc4: mov             x1, x2
    // 0x6e7bc8: ldr             x0, [fp, #0x10]
    // 0x6e7bcc: ldur            x2, [fp, #-8]
    // 0x6e7bd0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6e7bd0: add             x25, x1, x2, lsl #2
    //     0x6e7bd4: add             x25, x25, #0xf
    //     0x6e7bd8: str             w0, [x25]
    //     0x6e7bdc: tbz             w0, #0, #0x6e7bf8
    //     0x6e7be0: ldurb           w16, [x1, #-1]
    //     0x6e7be4: ldurb           w17, [x0, #-1]
    //     0x6e7be8: and             x16, x17, x16, lsr #2
    //     0x6e7bec: tst             x16, HEAP, lsr #32
    //     0x6e7bf0: b.eq            #0x6e7bf8
    //     0x6e7bf4: bl              #0xd67e5c
    // 0x6e7bf8: r0 = Null
    //     0x6e7bf8: mov             x0, NULL
    // 0x6e7bfc: LeaveFrame
    //     0x6e7bfc: mov             SP, fp
    //     0x6e7c00: ldp             fp, lr, [SP], #0x10
    // 0x6e7c04: ret
    //     0x6e7c04: ret             
    // 0x6e7c08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e7c08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e7c0c: b               #0x6e7aa0
    // 0x6e7c10: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e7c10: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e7c14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e7c14: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e7c18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e7c18: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6e83ac, size: 0x180
    // 0x6e83ac: EnterFrame
    //     0x6e83ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6e83b0: mov             fp, SP
    // 0x6e83b4: AllocStack(0x10)
    //     0x6e83b4: sub             SP, SP, #0x10
    // 0x6e83b8: CheckStackOverflow
    //     0x6e83b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e83bc: cmp             SP, x16
    //     0x6e83c0: b.ls            #0x6e8514
    // 0x6e83c4: ldr             x2, [fp, #0x18]
    // 0x6e83c8: r3 = 0
    //     0x6e83c8: mov             x3, #0
    // 0x6e83cc: stur            x3, [fp, #-8]
    // 0x6e83d0: CheckStackOverflow
    //     0x6e83d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e83d4: cmp             SP, x16
    //     0x6e83d8: b.ls            #0x6e851c
    // 0x6e83dc: LoadField: r0 = r2->field_7
    //     0x6e83dc: ldur            x0, [x2, #7]
    // 0x6e83e0: cmp             x3, x0
    // 0x6e83e4: b.ge            #0x6e8504
    // 0x6e83e8: LoadField: r4 = r2->field_f
    //     0x6e83e8: ldur            w4, [x2, #0xf]
    // 0x6e83ec: DecompressPointer r4
    //     0x6e83ec: add             x4, x4, HEAP, lsl #32
    // 0x6e83f0: LoadField: r0 = r4->field_b
    //     0x6e83f0: ldur            w0, [x4, #0xb]
    // 0x6e83f4: DecompressPointer r0
    //     0x6e83f4: add             x0, x0, HEAP, lsl #32
    // 0x6e83f8: r1 = LoadInt32Instr(r0)
    //     0x6e83f8: sbfx            x1, x0, #1, #0x1f
    // 0x6e83fc: mov             x0, x1
    // 0x6e8400: mov             x1, x3
    // 0x6e8404: cmp             x1, x0
    // 0x6e8408: b.hs            #0x6e8524
    // 0x6e840c: ArrayLoad: r0 = r4[r3]  ; Unknown_4
    //     0x6e840c: add             x16, x4, x3, lsl #2
    //     0x6e8410: ldur            w0, [x16, #0xf]
    // 0x6e8414: DecompressPointer r0
    //     0x6e8414: add             x0, x0, HEAP, lsl #32
    // 0x6e8418: r1 = 59
    //     0x6e8418: mov             x1, #0x3b
    // 0x6e841c: branchIfSmi(r0, 0x6e8428)
    //     0x6e841c: tbz             w0, #0, #0x6e8428
    // 0x6e8420: r1 = LoadClassIdInstr(r0)
    //     0x6e8420: ldur            x1, [x0, #-1]
    //     0x6e8424: ubfx            x1, x1, #0xc, #0x14
    // 0x6e8428: ldr             x16, [fp, #0x10]
    // 0x6e842c: stp             x16, x0, [SP, #-0x10]!
    // 0x6e8430: mov             x0, x1
    // 0x6e8434: mov             lr, x0
    // 0x6e8438: ldr             lr, [x21, lr, lsl #3]
    // 0x6e843c: blr             lr
    // 0x6e8440: add             SP, SP, #0x10
    // 0x6e8444: tbnz            w0, #4, #0x6e84f0
    // 0x6e8448: ldr             x3, [fp, #0x18]
    // 0x6e844c: LoadField: r0 = r3->field_13
    //     0x6e844c: ldur            x0, [x3, #0x13]
    // 0x6e8450: cmp             x0, #0
    // 0x6e8454: b.le            #0x6e84d8
    // 0x6e8458: ldur            x4, [fp, #-8]
    // 0x6e845c: LoadField: r5 = r3->field_f
    //     0x6e845c: ldur            w5, [x3, #0xf]
    // 0x6e8460: DecompressPointer r5
    //     0x6e8460: add             x5, x5, HEAP, lsl #32
    // 0x6e8464: stur            x5, [fp, #-0x10]
    // 0x6e8468: LoadField: r2 = r5->field_7
    //     0x6e8468: ldur            w2, [x5, #7]
    // 0x6e846c: DecompressPointer r2
    //     0x6e846c: add             x2, x2, HEAP, lsl #32
    // 0x6e8470: r0 = Null
    //     0x6e8470: mov             x0, NULL
    // 0x6e8474: r1 = Null
    //     0x6e8474: mov             x1, NULL
    // 0x6e8478: cmp             w2, NULL
    // 0x6e847c: b.eq            #0x6e8498
    // 0x6e8480: LoadField: r4 = r2->field_17
    //     0x6e8480: ldur            w4, [x2, #0x17]
    // 0x6e8484: DecompressPointer r4
    //     0x6e8484: add             x4, x4, HEAP, lsl #32
    // 0x6e8488: r8 = X0
    //     0x6e8488: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e848c: LoadField: r9 = r4->field_7
    //     0x6e848c: ldur            x9, [x4, #7]
    // 0x6e8490: r3 = Null
    //     0x6e8490: ldr             x3, [PP, #0x4d10]  ; [pp+0x4d10] Null
    // 0x6e8494: blr             x9
    // 0x6e8498: ldur            x2, [fp, #-0x10]
    // 0x6e849c: LoadField: r0 = r2->field_b
    //     0x6e849c: ldur            w0, [x2, #0xb]
    // 0x6e84a0: DecompressPointer r0
    //     0x6e84a0: add             x0, x0, HEAP, lsl #32
    // 0x6e84a4: r1 = LoadInt32Instr(r0)
    //     0x6e84a4: sbfx            x1, x0, #1, #0x1f
    // 0x6e84a8: mov             x0, x1
    // 0x6e84ac: ldur            x1, [fp, #-8]
    // 0x6e84b0: cmp             x1, x0
    // 0x6e84b4: b.hs            #0x6e8528
    // 0x6e84b8: ldur            x0, [fp, #-8]
    // 0x6e84bc: ArrayStore: r2[r0] = rNULL  ; Unknown_4
    //     0x6e84bc: add             x1, x2, x0, lsl #2
    //     0x6e84c0: stur            NULL, [x1, #0xf]
    // 0x6e84c4: ldr             x1, [fp, #0x18]
    // 0x6e84c8: LoadField: r0 = r1->field_1b
    //     0x6e84c8: ldur            x0, [x1, #0x1b]
    // 0x6e84cc: add             x2, x0, #1
    // 0x6e84d0: StoreField: r1->field_1b = r2
    //     0x6e84d0: stur            x2, [x1, #0x1b]
    // 0x6e84d4: b               #0x6e8504
    // 0x6e84d8: mov             x1, x3
    // 0x6e84dc: ldur            x0, [fp, #-8]
    // 0x6e84e0: stp             x0, x1, [SP, #-0x10]!
    // 0x6e84e4: r0 = _removeAt()
    //     0x6e84e4: bl              #0x6e852c  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_removeAt
    // 0x6e84e8: add             SP, SP, #0x10
    // 0x6e84ec: b               #0x6e8504
    // 0x6e84f0: ldr             x1, [fp, #0x18]
    // 0x6e84f4: ldur            x0, [fp, #-8]
    // 0x6e84f8: add             x3, x0, #1
    // 0x6e84fc: mov             x2, x1
    // 0x6e8500: b               #0x6e83cc
    // 0x6e8504: r0 = Null
    //     0x6e8504: mov             x0, NULL
    // 0x6e8508: LeaveFrame
    //     0x6e8508: mov             SP, fp
    //     0x6e850c: ldp             fp, lr, [SP], #0x10
    // 0x6e8510: ret
    //     0x6e8510: ret             
    // 0x6e8514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8514: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8518: b               #0x6e83c4
    // 0x6e851c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e851c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8520: b               #0x6e83dc
    // 0x6e8524: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8524: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e8528: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8528: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _removeAt(/* No info */) {
    // ** addr: 0x6e852c, size: 0x360
    // 0x6e852c: EnterFrame
    //     0x6e852c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8530: mov             fp, SP
    // 0x6e8534: AllocStack(0x38)
    //     0x6e8534: sub             SP, SP, #0x38
    // 0x6e8538: ldr             x3, [fp, #0x18]
    // 0x6e853c: LoadField: r0 = r3->field_7
    //     0x6e853c: ldur            x0, [x3, #7]
    // 0x6e8540: sub             x4, x0, #1
    // 0x6e8544: stur            x4, [fp, #-0x18]
    // 0x6e8548: StoreField: r3->field_7 = r4
    //     0x6e8548: stur            x4, [x3, #7]
    // 0x6e854c: lsl             x0, x4, #1
    // 0x6e8550: LoadField: r5 = r3->field_f
    //     0x6e8550: ldur            w5, [x3, #0xf]
    // 0x6e8554: DecompressPointer r5
    //     0x6e8554: add             x5, x5, HEAP, lsl #32
    // 0x6e8558: stur            x5, [fp, #-0x10]
    // 0x6e855c: LoadField: r1 = r5->field_b
    //     0x6e855c: ldur            w1, [x5, #0xb]
    // 0x6e8560: DecompressPointer r1
    //     0x6e8560: add             x1, x1, HEAP, lsl #32
    // 0x6e8564: r6 = LoadInt32Instr(r1)
    //     0x6e8564: sbfx            x6, x1, #1, #0x1f
    // 0x6e8568: stur            x6, [fp, #-8]
    // 0x6e856c: cmp             x0, x6
    // 0x6e8570: b.gt            #0x6e8720
    // 0x6e8574: r0 = BoxInt64Instr(r4)
    //     0x6e8574: sbfiz           x0, x4, #1, #0x1f
    //     0x6e8578: cmp             x4, x0, asr #1
    //     0x6e857c: b.eq            #0x6e8588
    //     0x6e8580: bl              #0xd69bb8
    //     0x6e8584: stur            x4, [x0, #7]
    // 0x6e8588: mov             x2, x0
    // 0x6e858c: r1 = <((dynamic this) => void?)?>
    //     0x6e858c: ldr             x1, [PP, #0x3a28]  ; [pp+0x3a28] TypeArguments: <((dynamic this) => void?)?>
    // 0x6e8590: r0 = AllocateArray()
    //     0x6e8590: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6e8594: mov             x3, x0
    // 0x6e8598: stur            x3, [fp, #-0x30]
    // 0x6e859c: r6 = 0
    //     0x6e859c: mov             x6, #0
    // 0x6e85a0: ldr             x5, [fp, #0x10]
    // 0x6e85a4: ldur            x4, [fp, #-0x10]
    // 0x6e85a8: stur            x6, [fp, #-0x28]
    // 0x6e85ac: CheckStackOverflow
    //     0x6e85ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e85b0: cmp             SP, x16
    //     0x6e85b4: b.ls            #0x6e8858
    // 0x6e85b8: cmp             x6, x5
    // 0x6e85bc: b.ge            #0x6e8648
    // 0x6e85c0: ldur            x0, [fp, #-8]
    // 0x6e85c4: mov             x1, x6
    // 0x6e85c8: cmp             x1, x0
    // 0x6e85cc: b.hs            #0x6e8860
    // 0x6e85d0: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x6e85d0: add             x16, x4, x6, lsl #2
    //     0x6e85d4: ldur            w7, [x16, #0xf]
    // 0x6e85d8: DecompressPointer r7
    //     0x6e85d8: add             x7, x7, HEAP, lsl #32
    // 0x6e85dc: mov             x0, x7
    // 0x6e85e0: stur            x7, [fp, #-0x20]
    // 0x6e85e4: r2 = Null
    //     0x6e85e4: mov             x2, NULL
    // 0x6e85e8: r1 = Null
    //     0x6e85e8: mov             x1, NULL
    // 0x6e85ec: r8 = ((dynamic this) => void?)?
    //     0x6e85ec: ldr             x8, [PP, #0x3a30]  ; [pp+0x3a30] FunctionType: ((dynamic this) => void?)?
    // 0x6e85f0: r3 = Null
    //     0x6e85f0: ldr             x3, [PP, #0x4d20]  ; [pp+0x4d20] Null
    // 0x6e85f4: r0 = DefaultNullableTypeTest()
    //     0x6e85f4: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6e85f8: ldur            x0, [fp, #-0x18]
    // 0x6e85fc: ldur            x1, [fp, #-0x28]
    // 0x6e8600: cmp             x1, x0
    // 0x6e8604: b.hs            #0x6e8864
    // 0x6e8608: ldur            x1, [fp, #-0x30]
    // 0x6e860c: ldur            x0, [fp, #-0x20]
    // 0x6e8610: ldur            x2, [fp, #-0x28]
    // 0x6e8614: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6e8614: add             x25, x1, x2, lsl #2
    //     0x6e8618: add             x25, x25, #0xf
    //     0x6e861c: str             w0, [x25]
    //     0x6e8620: tbz             w0, #0, #0x6e863c
    //     0x6e8624: ldurb           w16, [x1, #-1]
    //     0x6e8628: ldurb           w17, [x0, #-1]
    //     0x6e862c: and             x16, x17, x16, lsr #2
    //     0x6e8630: tst             x16, HEAP, lsr #32
    //     0x6e8634: b.eq            #0x6e863c
    //     0x6e8638: bl              #0xd67e5c
    // 0x6e863c: add             x6, x2, #1
    // 0x6e8640: ldur            x3, [fp, #-0x30]
    // 0x6e8644: b               #0x6e85a0
    // 0x6e8648: ldr             x5, [fp, #0x10]
    // 0x6e864c: ldur            x4, [fp, #-0x18]
    // 0x6e8650: ldur            x3, [fp, #-0x10]
    // 0x6e8654: stur            x5, [fp, #-0x38]
    // 0x6e8658: CheckStackOverflow
    //     0x6e8658: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e865c: cmp             SP, x16
    //     0x6e8660: b.ls            #0x6e8868
    // 0x6e8664: cmp             x5, x4
    // 0x6e8668: b.ge            #0x6e86f8
    // 0x6e866c: add             x6, x5, #1
    // 0x6e8670: ldur            x0, [fp, #-8]
    // 0x6e8674: mov             x1, x6
    // 0x6e8678: stur            x6, [fp, #-0x28]
    // 0x6e867c: cmp             x1, x0
    // 0x6e8680: b.hs            #0x6e8870
    // 0x6e8684: ArrayLoad: r7 = r3[r6]  ; Unknown_4
    //     0x6e8684: add             x16, x3, x6, lsl #2
    //     0x6e8688: ldur            w7, [x16, #0xf]
    // 0x6e868c: DecompressPointer r7
    //     0x6e868c: add             x7, x7, HEAP, lsl #32
    // 0x6e8690: mov             x0, x7
    // 0x6e8694: stur            x7, [fp, #-0x20]
    // 0x6e8698: r2 = Null
    //     0x6e8698: mov             x2, NULL
    // 0x6e869c: r1 = Null
    //     0x6e869c: mov             x1, NULL
    // 0x6e86a0: r8 = ((dynamic this) => void?)?
    //     0x6e86a0: ldr             x8, [PP, #0x3a30]  ; [pp+0x3a30] FunctionType: ((dynamic this) => void?)?
    // 0x6e86a4: r3 = Null
    //     0x6e86a4: ldr             x3, [PP, #0x4d30]  ; [pp+0x4d30] Null
    // 0x6e86a8: r0 = DefaultNullableTypeTest()
    //     0x6e86a8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0x6e86ac: ldur            x0, [fp, #-0x18]
    // 0x6e86b0: ldur            x1, [fp, #-0x38]
    // 0x6e86b4: cmp             x1, x0
    // 0x6e86b8: b.hs            #0x6e8874
    // 0x6e86bc: ldur            x1, [fp, #-0x30]
    // 0x6e86c0: ldur            x0, [fp, #-0x20]
    // 0x6e86c4: ldur            x2, [fp, #-0x38]
    // 0x6e86c8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6e86c8: add             x25, x1, x2, lsl #2
    //     0x6e86cc: add             x25, x25, #0xf
    //     0x6e86d0: str             w0, [x25]
    //     0x6e86d4: tbz             w0, #0, #0x6e86f0
    //     0x6e86d8: ldurb           w16, [x1, #-1]
    //     0x6e86dc: ldurb           w17, [x0, #-1]
    //     0x6e86e0: and             x16, x17, x16, lsr #2
    //     0x6e86e4: tst             x16, HEAP, lsr #32
    //     0x6e86e8: b.eq            #0x6e86f0
    //     0x6e86ec: bl              #0xd67e5c
    // 0x6e86f0: ldur            x5, [fp, #-0x28]
    // 0x6e86f4: b               #0x6e864c
    // 0x6e86f8: ldr             x1, [fp, #0x18]
    // 0x6e86fc: ldur            x0, [fp, #-0x30]
    // 0x6e8700: StoreField: r1->field_f = r0
    //     0x6e8700: stur            w0, [x1, #0xf]
    //     0x6e8704: ldurb           w16, [x1, #-1]
    //     0x6e8708: ldurb           w17, [x0, #-1]
    //     0x6e870c: and             x16, x17, x16, lsr #2
    //     0x6e8710: tst             x16, HEAP, lsr #32
    //     0x6e8714: b.eq            #0x6e871c
    //     0x6e8718: bl              #0xd6826c
    // 0x6e871c: b               #0x6e8848
    // 0x6e8720: mov             x3, x5
    // 0x6e8724: LoadField: r4 = r3->field_7
    //     0x6e8724: ldur            w4, [x3, #7]
    // 0x6e8728: DecompressPointer r4
    //     0x6e8728: add             x4, x4, HEAP, lsl #32
    // 0x6e872c: stur            x4, [fp, #-0x30]
    // 0x6e8730: ldr             x6, [fp, #0x10]
    // 0x6e8734: ldur            x5, [fp, #-0x18]
    // 0x6e8738: stur            x6, [fp, #-0x38]
    // 0x6e873c: CheckStackOverflow
    //     0x6e873c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8740: cmp             SP, x16
    //     0x6e8744: b.ls            #0x6e8878
    // 0x6e8748: cmp             x6, x5
    // 0x6e874c: b.ge            #0x6e87f8
    // 0x6e8750: add             x7, x6, #1
    // 0x6e8754: ldur            x0, [fp, #-8]
    // 0x6e8758: mov             x1, x7
    // 0x6e875c: stur            x7, [fp, #-0x28]
    // 0x6e8760: cmp             x1, x0
    // 0x6e8764: b.hs            #0x6e8880
    // 0x6e8768: ArrayLoad: r8 = r3[r7]  ; Unknown_4
    //     0x6e8768: add             x16, x3, x7, lsl #2
    //     0x6e876c: ldur            w8, [x16, #0xf]
    // 0x6e8770: DecompressPointer r8
    //     0x6e8770: add             x8, x8, HEAP, lsl #32
    // 0x6e8774: mov             x0, x8
    // 0x6e8778: mov             x2, x4
    // 0x6e877c: stur            x8, [fp, #-0x20]
    // 0x6e8780: r1 = Null
    //     0x6e8780: mov             x1, NULL
    // 0x6e8784: cmp             w2, NULL
    // 0x6e8788: b.eq            #0x6e87a4
    // 0x6e878c: LoadField: r4 = r2->field_17
    //     0x6e878c: ldur            w4, [x2, #0x17]
    // 0x6e8790: DecompressPointer r4
    //     0x6e8790: add             x4, x4, HEAP, lsl #32
    // 0x6e8794: r8 = X0
    //     0x6e8794: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e8798: LoadField: r9 = r4->field_7
    //     0x6e8798: ldur            x9, [x4, #7]
    // 0x6e879c: r3 = Null
    //     0x6e879c: ldr             x3, [PP, #0x4d40]  ; [pp+0x4d40] Null
    // 0x6e87a0: blr             x9
    // 0x6e87a4: ldur            x0, [fp, #-8]
    // 0x6e87a8: ldur            x1, [fp, #-0x38]
    // 0x6e87ac: cmp             x1, x0
    // 0x6e87b0: b.hs            #0x6e8884
    // 0x6e87b4: ldur            x1, [fp, #-0x10]
    // 0x6e87b8: ldur            x0, [fp, #-0x20]
    // 0x6e87bc: ldur            x2, [fp, #-0x38]
    // 0x6e87c0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x6e87c0: add             x25, x1, x2, lsl #2
    //     0x6e87c4: add             x25, x25, #0xf
    //     0x6e87c8: str             w0, [x25]
    //     0x6e87cc: tbz             w0, #0, #0x6e87e8
    //     0x6e87d0: ldurb           w16, [x1, #-1]
    //     0x6e87d4: ldurb           w17, [x0, #-1]
    //     0x6e87d8: and             x16, x17, x16, lsr #2
    //     0x6e87dc: tst             x16, HEAP, lsr #32
    //     0x6e87e0: b.eq            #0x6e87e8
    //     0x6e87e4: bl              #0xd67e5c
    // 0x6e87e8: ldur            x6, [fp, #-0x28]
    // 0x6e87ec: ldur            x3, [fp, #-0x10]
    // 0x6e87f0: ldur            x4, [fp, #-0x30]
    // 0x6e87f4: b               #0x6e8734
    // 0x6e87f8: mov             x4, x5
    // 0x6e87fc: ldur            x2, [fp, #-0x30]
    // 0x6e8800: r0 = Null
    //     0x6e8800: mov             x0, NULL
    // 0x6e8804: r1 = Null
    //     0x6e8804: mov             x1, NULL
    // 0x6e8808: cmp             w2, NULL
    // 0x6e880c: b.eq            #0x6e8828
    // 0x6e8810: LoadField: r4 = r2->field_17
    //     0x6e8810: ldur            w4, [x2, #0x17]
    // 0x6e8814: DecompressPointer r4
    //     0x6e8814: add             x4, x4, HEAP, lsl #32
    // 0x6e8818: r8 = X0
    //     0x6e8818: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6e881c: LoadField: r9 = r4->field_7
    //     0x6e881c: ldur            x9, [x4, #7]
    // 0x6e8820: r3 = Null
    //     0x6e8820: ldr             x3, [PP, #0x4d50]  ; [pp+0x4d50] Null
    // 0x6e8824: blr             x9
    // 0x6e8828: ldur            x0, [fp, #-8]
    // 0x6e882c: ldur            x1, [fp, #-0x18]
    // 0x6e8830: cmp             x1, x0
    // 0x6e8834: b.hs            #0x6e8888
    // 0x6e8838: ldur            x2, [fp, #-0x18]
    // 0x6e883c: ldur            x1, [fp, #-0x10]
    // 0x6e8840: ArrayStore: r1[r2] = rNULL  ; Unknown_4
    //     0x6e8840: add             x3, x1, x2, lsl #2
    //     0x6e8844: stur            NULL, [x3, #0xf]
    // 0x6e8848: r0 = Null
    //     0x6e8848: mov             x0, NULL
    // 0x6e884c: LeaveFrame
    //     0x6e884c: mov             SP, fp
    //     0x6e8850: ldp             fp, lr, [SP], #0x10
    // 0x6e8854: ret
    //     0x6e8854: ret             
    // 0x6e8858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8858: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e885c: b               #0x6e85b8
    // 0x6e8860: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8860: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e8864: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8864: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e8868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8868: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e886c: b               #0x6e8664
    // 0x6e8870: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8870: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e8874: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8874: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e8878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8878: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e887c: b               #0x6e8748
    // 0x6e8880: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8880: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e8884: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8884: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6e8888: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e8888: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0x9ba5c8, size: 0x18
    // 0x9ba5c8: r4 = 0
    //     0x9ba5c8: mov             x4, #0
    // 0x9ba5cc: r1 = Function 'dispose':.
    //     0x9ba5cc: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dc70] AnonymousClosure: (0x9ba5e0), in [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose (0xa6b240)
    //     0x9ba5d0: ldr             x1, [x17, #0xc70]
    // 0x9ba5d4: r24 = BuildNonGenericMethodExtractorStub
    //     0x9ba5d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x9ba5d8: LoadField: r0 = r24->field_17
    //     0x9ba5d8: ldur            x0, [x24, #0x17]
    // 0x9ba5dc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0x9ba5e0, size: 0x48
    // 0x9ba5e0: EnterFrame
    //     0x9ba5e0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ba5e4: mov             fp, SP
    // 0x9ba5e8: ldr             x0, [fp, #0x10]
    // 0x9ba5ec: LoadField: r1 = r0->field_17
    //     0x9ba5ec: ldur            w1, [x0, #0x17]
    // 0x9ba5f0: DecompressPointer r1
    //     0x9ba5f0: add             x1, x1, HEAP, lsl #32
    // 0x9ba5f4: CheckStackOverflow
    //     0x9ba5f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ba5f8: cmp             SP, x16
    //     0x9ba5fc: b.ls            #0x9ba620
    // 0x9ba600: LoadField: r0 = r1->field_f
    //     0x9ba600: ldur            w0, [x1, #0xf]
    // 0x9ba604: DecompressPointer r0
    //     0x9ba604: add             x0, x0, HEAP, lsl #32
    // 0x9ba608: SaveReg r0
    //     0x9ba608: str             x0, [SP, #-8]!
    // 0x9ba60c: r0 = dispose()
    //     0x9ba60c: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x9ba610: add             SP, SP, #8
    // 0x9ba614: LeaveFrame
    //     0x9ba614: mov             SP, fp
    //     0x9ba618: ldp             fp, lr, [SP], #0x10
    // 0x9ba61c: ret
    //     0x9ba61c: ret             
    // 0x9ba620: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba620: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba624: b               #0x9ba600
  }
}

// class id: 4866, size: 0x2c, field offset: 0x24
class ValueNotifier<X0> extends ChangeNotifier
    implements ValueListenable<X0> {

  set _ value=(/* No info */) {
    // ** addr: 0x500e7c, size: 0xe4
    // 0x500e7c: EnterFrame
    //     0x500e7c: stp             fp, lr, [SP, #-0x10]!
    //     0x500e80: mov             fp, SP
    // 0x500e84: CheckStackOverflow
    //     0x500e84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x500e88: cmp             SP, x16
    //     0x500e8c: b.ls            #0x500f58
    // 0x500e90: ldr             x3, [fp, #0x18]
    // 0x500e94: LoadField: r2 = r3->field_23
    //     0x500e94: ldur            w2, [x3, #0x23]
    // 0x500e98: DecompressPointer r2
    //     0x500e98: add             x2, x2, HEAP, lsl #32
    // 0x500e9c: ldr             x0, [fp, #0x10]
    // 0x500ea0: r1 = Null
    //     0x500ea0: mov             x1, NULL
    // 0x500ea4: cmp             w2, NULL
    // 0x500ea8: b.eq            #0x500ec8
    // 0x500eac: LoadField: r4 = r2->field_17
    //     0x500eac: ldur            w4, [x2, #0x17]
    // 0x500eb0: DecompressPointer r4
    //     0x500eb0: add             x4, x4, HEAP, lsl #32
    // 0x500eb4: r8 = X0
    //     0x500eb4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x500eb8: LoadField: r9 = r4->field_7
    //     0x500eb8: ldur            x9, [x4, #7]
    // 0x500ebc: r3 = Null
    //     0x500ebc: add             x3, PP, #0xf, lsl #12  ; [pp+0xf778] Null
    //     0x500ec0: ldr             x3, [x3, #0x778]
    // 0x500ec4: blr             x9
    // 0x500ec8: ldr             x1, [fp, #0x18]
    // 0x500ecc: LoadField: r0 = r1->field_27
    //     0x500ecc: ldur            w0, [x1, #0x27]
    // 0x500ed0: DecompressPointer r0
    //     0x500ed0: add             x0, x0, HEAP, lsl #32
    // 0x500ed4: r2 = 59
    //     0x500ed4: mov             x2, #0x3b
    // 0x500ed8: branchIfSmi(r0, 0x500ee4)
    //     0x500ed8: tbz             w0, #0, #0x500ee4
    // 0x500edc: r2 = LoadClassIdInstr(r0)
    //     0x500edc: ldur            x2, [x0, #-1]
    //     0x500ee0: ubfx            x2, x2, #0xc, #0x14
    // 0x500ee4: ldr             x16, [fp, #0x10]
    // 0x500ee8: stp             x16, x0, [SP, #-0x10]!
    // 0x500eec: mov             x0, x2
    // 0x500ef0: mov             lr, x0
    // 0x500ef4: ldr             lr, [x21, lr, lsl #3]
    // 0x500ef8: blr             lr
    // 0x500efc: add             SP, SP, #0x10
    // 0x500f00: tbnz            w0, #4, #0x500f14
    // 0x500f04: r0 = Null
    //     0x500f04: mov             x0, NULL
    // 0x500f08: LeaveFrame
    //     0x500f08: mov             SP, fp
    //     0x500f0c: ldp             fp, lr, [SP], #0x10
    // 0x500f10: ret
    //     0x500f10: ret             
    // 0x500f14: ldr             x1, [fp, #0x18]
    // 0x500f18: ldr             x0, [fp, #0x10]
    // 0x500f1c: StoreField: r1->field_27 = r0
    //     0x500f1c: stur            w0, [x1, #0x27]
    //     0x500f20: tbz             w0, #0, #0x500f3c
    //     0x500f24: ldurb           w16, [x1, #-1]
    //     0x500f28: ldurb           w17, [x0, #-1]
    //     0x500f2c: and             x16, x17, x16, lsr #2
    //     0x500f30: tst             x16, HEAP, lsr #32
    //     0x500f34: b.eq            #0x500f3c
    //     0x500f38: bl              #0xd6826c
    // 0x500f3c: SaveReg r1
    //     0x500f3c: str             x1, [SP, #-8]!
    // 0x500f40: r0 = notifyListeners()
    //     0x500f40: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x500f44: add             SP, SP, #8
    // 0x500f48: r0 = Null
    //     0x500f48: mov             x0, NULL
    // 0x500f4c: LeaveFrame
    //     0x500f4c: mov             SP, fp
    //     0x500f50: ldp             fp, lr, [SP], #0x10
    // 0x500f54: ret
    //     0x500f54: ret             
    // 0x500f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x500f58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x500f5c: b               #0x500e90
  }
}

// lib: , url: package:flutter/src/foundation/serialization.dart

// class id: 1049144, size: 0x8
class :: {
}

// class id: 2370, size: 0x14, field offset: 0x8
class ReadBuffer extends Object {

  get _ hasRemaining(/* No info */) {
    // ** addr: 0x71a31c, size: 0x30
    // 0x71a31c: ldr             x1, [SP]
    // 0x71a320: LoadField: r2 = r1->field_b
    //     0x71a320: ldur            x2, [x1, #0xb]
    // 0x71a324: LoadField: r3 = r1->field_7
    //     0x71a324: ldur            w3, [x1, #7]
    // 0x71a328: DecompressPointer r3
    //     0x71a328: add             x3, x3, HEAP, lsl #32
    // 0x71a32c: LoadField: r1 = r3->field_13
    //     0x71a32c: ldur            w1, [x3, #0x13]
    // 0x71a330: DecompressPointer r1
    //     0x71a330: add             x1, x1, HEAP, lsl #32
    // 0x71a334: r3 = LoadInt32Instr(r1)
    //     0x71a334: sbfx            x3, x1, #1, #0x1f
    // 0x71a338: cmp             x2, x3
    // 0x71a33c: r16 = true
    //     0x71a33c: add             x16, NULL, #0x20  ; true
    // 0x71a340: r17 = false
    //     0x71a340: add             x17, NULL, #0x30  ; false
    // 0x71a344: csel            x0, x16, x17, lt
    // 0x71a348: ret
    //     0x71a348: ret             
  }
  _ getUint8(/* No info */) {
    // ** addr: 0x71a3e8, size: 0xd0
    // 0x71a3e8: EnterFrame
    //     0x71a3e8: stp             fp, lr, [SP, #-0x10]!
    //     0x71a3ec: mov             fp, SP
    // 0x71a3f0: AllocStack(0x10)
    //     0x71a3f0: sub             SP, SP, #0x10
    // 0x71a3f4: ldr             x0, [fp, #0x10]
    // 0x71a3f8: LoadField: r1 = r0->field_7
    //     0x71a3f8: ldur            w1, [x0, #7]
    // 0x71a3fc: DecompressPointer r1
    //     0x71a3fc: add             x1, x1, HEAP, lsl #32
    // 0x71a400: LoadField: r2 = r0->field_b
    //     0x71a400: ldur            x2, [x0, #0xb]
    // 0x71a404: stur            x2, [fp, #-0x10]
    // 0x71a408: add             x3, x2, #1
    // 0x71a40c: StoreField: r0->field_b = r3
    //     0x71a40c: stur            x3, [x0, #0xb]
    // 0x71a410: tbnz            x2, #0x3f, #0x71a458
    // 0x71a414: LoadField: r0 = r1->field_13
    //     0x71a414: ldur            w0, [x1, #0x13]
    // 0x71a418: DecompressPointer r0
    //     0x71a418: add             x0, x0, HEAP, lsl #32
    // 0x71a41c: r3 = LoadInt32Instr(r0)
    //     0x71a41c: sbfx            x3, x0, #1, #0x1f
    // 0x71a420: cmp             x2, x3
    // 0x71a424: b.ge            #0x71a458
    // 0x71a428: mov             x3, x2
    // 0x71a42c: LoadField: r2 = r1->field_17
    //     0x71a42c: ldur            w2, [x1, #0x17]
    // 0x71a430: DecompressPointer r2
    //     0x71a430: add             x2, x2, HEAP, lsl #32
    // 0x71a434: LoadField: r4 = r1->field_1b
    //     0x71a434: ldur            w4, [x1, #0x1b]
    // 0x71a438: DecompressPointer r4
    //     0x71a438: add             x4, x4, HEAP, lsl #32
    // 0x71a43c: r1 = LoadInt32Instr(r4)
    //     0x71a43c: sbfx            x1, x4, #1, #0x1f
    // 0x71a440: add             x4, x1, x3
    // 0x71a444: LoadField: r1 = r2->field_7
    //     0x71a444: ldur            x1, [x2, #7]
    // 0x71a448: ldrb            w0, [x1, x4]
    // 0x71a44c: LeaveFrame
    //     0x71a44c: mov             SP, fp
    //     0x71a450: ldp             fp, lr, [SP], #0x10
    // 0x71a454: ret
    //     0x71a454: ret             
    // 0x71a458: LoadField: r0 = r1->field_13
    //     0x71a458: ldur            w0, [x1, #0x13]
    // 0x71a45c: DecompressPointer r0
    //     0x71a45c: add             x0, x0, HEAP, lsl #32
    // 0x71a460: r1 = LoadInt32Instr(r0)
    //     0x71a460: sbfx            x1, x0, #1, #0x1f
    // 0x71a464: stur            x1, [fp, #-8]
    // 0x71a468: r0 = IndexError()
    //     0x71a468: bl              #0x4c67ac  ; AllocateIndexErrorStub -> IndexError (size=0x24)
    // 0x71a46c: mov             x2, x0
    // 0x71a470: ldur            x0, [fp, #-8]
    // 0x71a474: StoreField: r2->field_1b = r0
    //     0x71a474: stur            x0, [x2, #0x1b]
    // 0x71a478: r0 = "byteOffset"
    //     0x71a478: ldr             x0, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0x71a47c: StoreField: r2->field_13 = r0
    //     0x71a47c: stur            w0, [x2, #0x13]
    // 0x71a480: r0 = "Index out of range"
    //     0x71a480: ldr             x0, [PP, #0xd40]  ; [pp+0xd40] "Index out of range"
    // 0x71a484: StoreField: r2->field_17 = r0
    //     0x71a484: stur            w0, [x2, #0x17]
    // 0x71a488: ldur            x3, [fp, #-0x10]
    // 0x71a48c: r0 = BoxInt64Instr(r3)
    //     0x71a48c: sbfiz           x0, x3, #1, #0x1f
    //     0x71a490: cmp             x3, x0, asr #1
    //     0x71a494: b.eq            #0x71a4a0
    //     0x71a498: bl              #0xd69bb8
    //     0x71a49c: stur            x3, [x0, #7]
    // 0x71a4a0: StoreField: r2->field_f = r0
    //     0x71a4a0: stur            w0, [x2, #0xf]
    // 0x71a4a4: r0 = true
    //     0x71a4a4: add             x0, NULL, #0x20  ; true
    // 0x71a4a8: StoreField: r2->field_b = r0
    //     0x71a4a8: stur            w0, [x2, #0xb]
    // 0x71a4ac: mov             x0, x2
    // 0x71a4b0: r0 = Throw()
    //     0x71a4b0: bl              #0xd67e38  ; ThrowStub
    // 0x71a4b4: brk             #0
  }
  _ getFloat32List(/* No info */) {
    // ** addr: 0xa80d88, size: 0xe0
    // 0xa80d88: EnterFrame
    //     0xa80d88: stp             fp, lr, [SP, #-0x10]!
    //     0xa80d8c: mov             fp, SP
    // 0xa80d90: AllocStack(0x8)
    //     0xa80d90: sub             SP, SP, #8
    // 0xa80d94: r0 = 4
    //     0xa80d94: mov             x0, #4
    // 0xa80d98: CheckStackOverflow
    //     0xa80d98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa80d9c: cmp             SP, x16
    //     0xa80da0: b.ls            #0xa80e5c
    // 0xa80da4: ldr             x16, [fp, #0x18]
    // 0xa80da8: stp             x0, x16, [SP, #-0x10]!
    // 0xa80dac: r0 = _alignTo()
    //     0xa80dac: bl              #0xa80e68  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0xa80db0: add             SP, SP, #0x10
    // 0xa80db4: ldr             x1, [fp, #0x18]
    // 0xa80db8: LoadField: r2 = r1->field_7
    //     0xa80db8: ldur            w2, [x1, #7]
    // 0xa80dbc: DecompressPointer r2
    //     0xa80dbc: add             x2, x2, HEAP, lsl #32
    // 0xa80dc0: stur            x2, [fp, #-8]
    // 0xa80dc4: r0 = LoadClassIdInstr(r2)
    //     0xa80dc4: ldur            x0, [x2, #-1]
    //     0xa80dc8: ubfx            x0, x0, #0xc, #0x14
    // 0xa80dcc: SaveReg r2
    //     0xa80dcc: str             x2, [SP, #-8]!
    // 0xa80dd0: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xa80dd0: sub             lr, x0, #0xf7e
    //     0xa80dd4: ldr             lr, [x21, lr, lsl #3]
    //     0xa80dd8: blr             lr
    // 0xa80ddc: add             SP, SP, #8
    // 0xa80de0: mov             x1, x0
    // 0xa80de4: ldur            x0, [fp, #-8]
    // 0xa80de8: LoadField: r2 = r0->field_1b
    //     0xa80de8: ldur            w2, [x0, #0x1b]
    // 0xa80dec: DecompressPointer r2
    //     0xa80dec: add             x2, x2, HEAP, lsl #32
    // 0xa80df0: ldr             x3, [fp, #0x18]
    // 0xa80df4: LoadField: r0 = r3->field_b
    //     0xa80df4: ldur            x0, [x3, #0xb]
    // 0xa80df8: r4 = LoadInt32Instr(r2)
    //     0xa80df8: sbfx            x4, x2, #1, #0x1f
    // 0xa80dfc: add             x2, x4, x0
    // 0xa80e00: r0 = LoadClassIdInstr(r1)
    //     0xa80e00: ldur            x0, [x1, #-1]
    //     0xa80e04: ubfx            x0, x0, #0xc, #0x14
    // 0xa80e08: stp             x2, x1, [SP, #-0x10]!
    // 0xa80e0c: ldr             x16, [fp, #0x10]
    // 0xa80e10: SaveReg r16
    //     0xa80e10: str             x16, [SP, #-8]!
    // 0xa80e14: r0 = GDT[cid_x0 + -0xfbe]()
    //     0xa80e14: sub             lr, x0, #0xfbe
    //     0xa80e18: ldr             lr, [x21, lr, lsl #3]
    //     0xa80e1c: blr             lr
    // 0xa80e20: add             SP, SP, #0x18
    // 0xa80e24: ldr             x1, [fp, #0x18]
    // 0xa80e28: LoadField: r2 = r1->field_b
    //     0xa80e28: ldur            x2, [x1, #0xb]
    // 0xa80e2c: ldr             x3, [fp, #0x10]
    // 0xa80e30: cmp             w3, NULL
    // 0xa80e34: b.eq            #0xa80e64
    // 0xa80e38: r4 = LoadInt32Instr(r3)
    //     0xa80e38: sbfx            x4, x3, #1, #0x1f
    //     0xa80e3c: tbz             w3, #0, #0xa80e44
    //     0xa80e40: ldur            x4, [x3, #7]
    // 0xa80e44: lsl             x3, x4, #2
    // 0xa80e48: add             x4, x2, x3
    // 0xa80e4c: StoreField: r1->field_b = r4
    //     0xa80e4c: stur            x4, [x1, #0xb]
    // 0xa80e50: LeaveFrame
    //     0xa80e50: mov             SP, fp
    //     0xa80e54: ldp             fp, lr, [SP], #0x10
    // 0xa80e58: ret
    //     0xa80e58: ret             
    // 0xa80e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa80e5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa80e60: b               #0xa80da4
    // 0xa80e64: r0 = NullErrorSharedWithoutFPURegs()
    //     0xa80e64: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _alignTo(/* No info */) {
    // ** addr: 0xa80e68, size: 0x78
    // 0xa80e68: EnterFrame
    //     0xa80e68: stp             fp, lr, [SP, #-0x10]!
    //     0xa80e6c: mov             fp, SP
    // 0xa80e70: ldr             x1, [fp, #0x18]
    // 0xa80e74: LoadField: r2 = r1->field_b
    //     0xa80e74: ldur            x2, [x1, #0xb]
    // 0xa80e78: ldr             x3, [fp, #0x10]
    // 0xa80e7c: cbz             x3, #0xa80eb0
    // 0xa80e80: sdiv            x5, x2, x3
    // 0xa80e84: msub            x4, x5, x3, x2
    // 0xa80e88: cmp             x4, xzr
    // 0xa80e8c: b.lt            #0xa80ecc
    // 0xa80e90: cbz             x4, #0xa80ea0
    // 0xa80e94: sub             x5, x3, x4
    // 0xa80e98: add             x3, x2, x5
    // 0xa80e9c: StoreField: r1->field_b = r3
    //     0xa80e9c: stur            x3, [x1, #0xb]
    // 0xa80ea0: r0 = Null
    //     0xa80ea0: mov             x0, NULL
    // 0xa80ea4: LeaveFrame
    //     0xa80ea4: mov             SP, fp
    //     0xa80ea8: ldp             fp, lr, [SP], #0x10
    // 0xa80eac: ret
    //     0xa80eac: ret             
    // 0xa80eb0: stp             x2, x3, [SP, #-0x10]!
    // 0xa80eb4: SaveReg r1
    //     0xa80eb4: str             x1, [SP, #-8]!
    // 0xa80eb8: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0xa80ebc: r4 = 0
    //     0xa80ebc: mov             x4, #0
    // 0xa80ec0: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xa80ec4: blr             lr
    // 0xa80ec8: brk             #0
    // 0xa80ecc: cmp             x3, xzr
    // 0xa80ed0: sub             x5, x4, x3
    // 0xa80ed4: add             x4, x4, x3
    // 0xa80ed8: csel            x4, x5, x4, lt
    // 0xa80edc: b               #0xa80e90
  }
  _ getFloat64List(/* No info */) {
    // ** addr: 0xa80ee0, size: 0xe0
    // 0xa80ee0: EnterFrame
    //     0xa80ee0: stp             fp, lr, [SP, #-0x10]!
    //     0xa80ee4: mov             fp, SP
    // 0xa80ee8: AllocStack(0x8)
    //     0xa80ee8: sub             SP, SP, #8
    // 0xa80eec: r0 = 8
    //     0xa80eec: mov             x0, #8
    // 0xa80ef0: CheckStackOverflow
    //     0xa80ef0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa80ef4: cmp             SP, x16
    //     0xa80ef8: b.ls            #0xa80fb4
    // 0xa80efc: ldr             x16, [fp, #0x18]
    // 0xa80f00: stp             x0, x16, [SP, #-0x10]!
    // 0xa80f04: r0 = _alignTo()
    //     0xa80f04: bl              #0xa80e68  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0xa80f08: add             SP, SP, #0x10
    // 0xa80f0c: ldr             x1, [fp, #0x18]
    // 0xa80f10: LoadField: r2 = r1->field_7
    //     0xa80f10: ldur            w2, [x1, #7]
    // 0xa80f14: DecompressPointer r2
    //     0xa80f14: add             x2, x2, HEAP, lsl #32
    // 0xa80f18: stur            x2, [fp, #-8]
    // 0xa80f1c: r0 = LoadClassIdInstr(r2)
    //     0xa80f1c: ldur            x0, [x2, #-1]
    //     0xa80f20: ubfx            x0, x0, #0xc, #0x14
    // 0xa80f24: SaveReg r2
    //     0xa80f24: str             x2, [SP, #-8]!
    // 0xa80f28: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xa80f28: sub             lr, x0, #0xf7e
    //     0xa80f2c: ldr             lr, [x21, lr, lsl #3]
    //     0xa80f30: blr             lr
    // 0xa80f34: add             SP, SP, #8
    // 0xa80f38: mov             x1, x0
    // 0xa80f3c: ldur            x0, [fp, #-8]
    // 0xa80f40: LoadField: r2 = r0->field_1b
    //     0xa80f40: ldur            w2, [x0, #0x1b]
    // 0xa80f44: DecompressPointer r2
    //     0xa80f44: add             x2, x2, HEAP, lsl #32
    // 0xa80f48: ldr             x3, [fp, #0x18]
    // 0xa80f4c: LoadField: r0 = r3->field_b
    //     0xa80f4c: ldur            x0, [x3, #0xb]
    // 0xa80f50: r4 = LoadInt32Instr(r2)
    //     0xa80f50: sbfx            x4, x2, #1, #0x1f
    // 0xa80f54: add             x2, x4, x0
    // 0xa80f58: r0 = LoadClassIdInstr(r1)
    //     0xa80f58: ldur            x0, [x1, #-1]
    //     0xa80f5c: ubfx            x0, x0, #0xc, #0x14
    // 0xa80f60: stp             x2, x1, [SP, #-0x10]!
    // 0xa80f64: ldr             x16, [fp, #0x10]
    // 0xa80f68: SaveReg r16
    //     0xa80f68: str             x16, [SP, #-8]!
    // 0xa80f6c: r0 = GDT[cid_x0 + -0xfbc]()
    //     0xa80f6c: sub             lr, x0, #0xfbc
    //     0xa80f70: ldr             lr, [x21, lr, lsl #3]
    //     0xa80f74: blr             lr
    // 0xa80f78: add             SP, SP, #0x18
    // 0xa80f7c: ldr             x1, [fp, #0x18]
    // 0xa80f80: LoadField: r2 = r1->field_b
    //     0xa80f80: ldur            x2, [x1, #0xb]
    // 0xa80f84: ldr             x3, [fp, #0x10]
    // 0xa80f88: cmp             w3, NULL
    // 0xa80f8c: b.eq            #0xa80fbc
    // 0xa80f90: r4 = LoadInt32Instr(r3)
    //     0xa80f90: sbfx            x4, x3, #1, #0x1f
    //     0xa80f94: tbz             w3, #0, #0xa80f9c
    //     0xa80f98: ldur            x4, [x3, #7]
    // 0xa80f9c: lsl             x3, x4, #3
    // 0xa80fa0: add             x4, x2, x3
    // 0xa80fa4: StoreField: r1->field_b = r4
    //     0xa80fa4: stur            x4, [x1, #0xb]
    // 0xa80fa8: LeaveFrame
    //     0xa80fa8: mov             SP, fp
    //     0xa80fac: ldp             fp, lr, [SP], #0x10
    // 0xa80fb0: ret
    //     0xa80fb0: ret             
    // 0xa80fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa80fb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa80fb8: b               #0xa80efc
    // 0xa80fbc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xa80fbc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getInt64List(/* No info */) {
    // ** addr: 0xa80fc0, size: 0x100
    // 0xa80fc0: EnterFrame
    //     0xa80fc0: stp             fp, lr, [SP, #-0x10]!
    //     0xa80fc4: mov             fp, SP
    // 0xa80fc8: AllocStack(0x10)
    //     0xa80fc8: sub             SP, SP, #0x10
    // 0xa80fcc: r0 = 8
    //     0xa80fcc: mov             x0, #8
    // 0xa80fd0: CheckStackOverflow
    //     0xa80fd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa80fd4: cmp             SP, x16
    //     0xa80fd8: b.ls            #0xa810b4
    // 0xa80fdc: ldr             x16, [fp, #0x18]
    // 0xa80fe0: stp             x0, x16, [SP, #-0x10]!
    // 0xa80fe4: r0 = _alignTo()
    //     0xa80fe4: bl              #0xa80e68  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0xa80fe8: add             SP, SP, #0x10
    // 0xa80fec: ldr             x1, [fp, #0x18]
    // 0xa80ff0: LoadField: r2 = r1->field_7
    //     0xa80ff0: ldur            w2, [x1, #7]
    // 0xa80ff4: DecompressPointer r2
    //     0xa80ff4: add             x2, x2, HEAP, lsl #32
    // 0xa80ff8: stur            x2, [fp, #-8]
    // 0xa80ffc: r0 = LoadClassIdInstr(r2)
    //     0xa80ffc: ldur            x0, [x2, #-1]
    //     0xa81000: ubfx            x0, x0, #0xc, #0x14
    // 0xa81004: SaveReg r2
    //     0xa81004: str             x2, [SP, #-8]!
    // 0xa81008: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xa81008: sub             lr, x0, #0xf7e
    //     0xa8100c: ldr             lr, [x21, lr, lsl #3]
    //     0xa81010: blr             lr
    // 0xa81014: add             SP, SP, #8
    // 0xa81018: mov             x2, x0
    // 0xa8101c: ldur            x0, [fp, #-8]
    // 0xa81020: LoadField: r1 = r0->field_1b
    //     0xa81020: ldur            w1, [x0, #0x1b]
    // 0xa81024: DecompressPointer r1
    //     0xa81024: add             x1, x1, HEAP, lsl #32
    // 0xa81028: ldr             x3, [fp, #0x18]
    // 0xa8102c: LoadField: r0 = r3->field_b
    //     0xa8102c: ldur            x0, [x3, #0xb]
    // 0xa81030: r4 = LoadInt32Instr(r1)
    //     0xa81030: sbfx            x4, x1, #1, #0x1f
    // 0xa81034: add             x5, x4, x0
    // 0xa81038: ldr             x4, [fp, #0x10]
    // 0xa8103c: r6 = LoadInt32Instr(r4)
    //     0xa8103c: sbfx            x6, x4, #1, #0x1f
    //     0xa81040: tbz             w4, #0, #0xa81048
    //     0xa81044: ldur            x6, [x4, #7]
    // 0xa81048: stur            x6, [fp, #-0x10]
    // 0xa8104c: r0 = BoxInt64Instr(r5)
    //     0xa8104c: sbfiz           x0, x5, #1, #0x1f
    //     0xa81050: cmp             x5, x0, asr #1
    //     0xa81054: b.eq            #0xa81060
    //     0xa81058: bl              #0xd69bb8
    //     0xa8105c: stur            x5, [x0, #7]
    // 0xa81060: r1 = LoadClassIdInstr(r2)
    //     0xa81060: ldur            x1, [x2, #-1]
    //     0xa81064: ubfx            x1, x1, #0xc, #0x14
    // 0xa81068: stp             x0, x2, [SP, #-0x10]!
    // 0xa8106c: SaveReg r6
    //     0xa8106c: str             x6, [SP, #-8]!
    // 0xa81070: mov             x0, x1
    // 0xa81074: r0 = GDT[cid_x0 + -0xfcf]()
    //     0xa81074: sub             lr, x0, #0xfcf
    //     0xa81078: ldr             lr, [x21, lr, lsl #3]
    //     0xa8107c: blr             lr
    // 0xa81080: add             SP, SP, #0x18
    // 0xa81084: ldr             x1, [fp, #0x18]
    // 0xa81088: LoadField: r2 = r1->field_b
    //     0xa81088: ldur            x2, [x1, #0xb]
    // 0xa8108c: ldr             x3, [fp, #0x10]
    // 0xa81090: cmp             w3, NULL
    // 0xa81094: b.eq            #0xa810bc
    // 0xa81098: ldur            x3, [fp, #-0x10]
    // 0xa8109c: lsl             x4, x3, #3
    // 0xa810a0: add             x3, x2, x4
    // 0xa810a4: StoreField: r1->field_b = r3
    //     0xa810a4: stur            x3, [x1, #0xb]
    // 0xa810a8: LeaveFrame
    //     0xa810a8: mov             SP, fp
    //     0xa810ac: ldp             fp, lr, [SP], #0x10
    // 0xa810b0: ret
    //     0xa810b0: ret             
    // 0xa810b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa810b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa810b8: b               #0xa80fdc
    // 0xa810bc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xa810bc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getInt32List(/* No info */) {
    // ** addr: 0xa810c0, size: 0xe0
    // 0xa810c0: EnterFrame
    //     0xa810c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa810c4: mov             fp, SP
    // 0xa810c8: AllocStack(0x8)
    //     0xa810c8: sub             SP, SP, #8
    // 0xa810cc: r0 = 4
    //     0xa810cc: mov             x0, #4
    // 0xa810d0: CheckStackOverflow
    //     0xa810d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa810d4: cmp             SP, x16
    //     0xa810d8: b.ls            #0xa81194
    // 0xa810dc: ldr             x16, [fp, #0x18]
    // 0xa810e0: stp             x0, x16, [SP, #-0x10]!
    // 0xa810e4: r0 = _alignTo()
    //     0xa810e4: bl              #0xa80e68  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0xa810e8: add             SP, SP, #0x10
    // 0xa810ec: ldr             x1, [fp, #0x18]
    // 0xa810f0: LoadField: r2 = r1->field_7
    //     0xa810f0: ldur            w2, [x1, #7]
    // 0xa810f4: DecompressPointer r2
    //     0xa810f4: add             x2, x2, HEAP, lsl #32
    // 0xa810f8: stur            x2, [fp, #-8]
    // 0xa810fc: r0 = LoadClassIdInstr(r2)
    //     0xa810fc: ldur            x0, [x2, #-1]
    //     0xa81100: ubfx            x0, x0, #0xc, #0x14
    // 0xa81104: SaveReg r2
    //     0xa81104: str             x2, [SP, #-8]!
    // 0xa81108: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xa81108: sub             lr, x0, #0xf7e
    //     0xa8110c: ldr             lr, [x21, lr, lsl #3]
    //     0xa81110: blr             lr
    // 0xa81114: add             SP, SP, #8
    // 0xa81118: mov             x1, x0
    // 0xa8111c: ldur            x0, [fp, #-8]
    // 0xa81120: LoadField: r2 = r0->field_1b
    //     0xa81120: ldur            w2, [x0, #0x1b]
    // 0xa81124: DecompressPointer r2
    //     0xa81124: add             x2, x2, HEAP, lsl #32
    // 0xa81128: ldr             x3, [fp, #0x18]
    // 0xa8112c: LoadField: r0 = r3->field_b
    //     0xa8112c: ldur            x0, [x3, #0xb]
    // 0xa81130: r4 = LoadInt32Instr(r2)
    //     0xa81130: sbfx            x4, x2, #1, #0x1f
    // 0xa81134: add             x2, x4, x0
    // 0xa81138: r0 = LoadClassIdInstr(r1)
    //     0xa81138: ldur            x0, [x1, #-1]
    //     0xa8113c: ubfx            x0, x0, #0xc, #0x14
    // 0xa81140: stp             x2, x1, [SP, #-0x10]!
    // 0xa81144: ldr             x16, [fp, #0x10]
    // 0xa81148: SaveReg r16
    //     0xa81148: str             x16, [SP, #-8]!
    // 0xa8114c: r0 = GDT[cid_x0 + -0xfea]()
    //     0xa8114c: sub             lr, x0, #0xfea
    //     0xa81150: ldr             lr, [x21, lr, lsl #3]
    //     0xa81154: blr             lr
    // 0xa81158: add             SP, SP, #0x18
    // 0xa8115c: ldr             x1, [fp, #0x18]
    // 0xa81160: LoadField: r2 = r1->field_b
    //     0xa81160: ldur            x2, [x1, #0xb]
    // 0xa81164: ldr             x3, [fp, #0x10]
    // 0xa81168: cmp             w3, NULL
    // 0xa8116c: b.eq            #0xa8119c
    // 0xa81170: r4 = LoadInt32Instr(r3)
    //     0xa81170: sbfx            x4, x3, #1, #0x1f
    //     0xa81174: tbz             w3, #0, #0xa8117c
    //     0xa81178: ldur            x4, [x3, #7]
    // 0xa8117c: lsl             x3, x4, #2
    // 0xa81180: add             x4, x2, x3
    // 0xa81184: StoreField: r1->field_b = r4
    //     0xa81184: stur            x4, [x1, #0xb]
    // 0xa81188: LeaveFrame
    //     0xa81188: mov             SP, fp
    //     0xa8118c: ldp             fp, lr, [SP], #0x10
    // 0xa81190: ret
    //     0xa81190: ret             
    // 0xa81194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa81194: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa81198: b               #0xa810dc
    // 0xa8119c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xa8119c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getUint8List(/* No info */) {
    // ** addr: 0xa811a0, size: 0xe4
    // 0xa811a0: EnterFrame
    //     0xa811a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa811a4: mov             fp, SP
    // 0xa811a8: AllocStack(0x8)
    //     0xa811a8: sub             SP, SP, #8
    // 0xa811ac: CheckStackOverflow
    //     0xa811ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa811b0: cmp             SP, x16
    //     0xa811b4: b.ls            #0xa81278
    // 0xa811b8: ldr             x1, [fp, #0x18]
    // 0xa811bc: LoadField: r2 = r1->field_7
    //     0xa811bc: ldur            w2, [x1, #7]
    // 0xa811c0: DecompressPointer r2
    //     0xa811c0: add             x2, x2, HEAP, lsl #32
    // 0xa811c4: stur            x2, [fp, #-8]
    // 0xa811c8: r0 = LoadClassIdInstr(r2)
    //     0xa811c8: ldur            x0, [x2, #-1]
    //     0xa811cc: ubfx            x0, x0, #0xc, #0x14
    // 0xa811d0: SaveReg r2
    //     0xa811d0: str             x2, [SP, #-8]!
    // 0xa811d4: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xa811d4: sub             lr, x0, #0xf7e
    //     0xa811d8: ldr             lr, [x21, lr, lsl #3]
    //     0xa811dc: blr             lr
    // 0xa811e0: add             SP, SP, #8
    // 0xa811e4: mov             x2, x0
    // 0xa811e8: ldur            x0, [fp, #-8]
    // 0xa811ec: LoadField: r1 = r0->field_1b
    //     0xa811ec: ldur            w1, [x0, #0x1b]
    // 0xa811f0: DecompressPointer r1
    //     0xa811f0: add             x1, x1, HEAP, lsl #32
    // 0xa811f4: ldr             x3, [fp, #0x18]
    // 0xa811f8: LoadField: r0 = r3->field_b
    //     0xa811f8: ldur            x0, [x3, #0xb]
    // 0xa811fc: r4 = LoadInt32Instr(r1)
    //     0xa811fc: sbfx            x4, x1, #1, #0x1f
    // 0xa81200: add             x5, x4, x0
    // 0xa81204: r0 = BoxInt64Instr(r5)
    //     0xa81204: sbfiz           x0, x5, #1, #0x1f
    //     0xa81208: cmp             x5, x0, asr #1
    //     0xa8120c: b.eq            #0xa81218
    //     0xa81210: bl              #0xd69bb8
    //     0xa81214: stur            x5, [x0, #7]
    // 0xa81218: r1 = LoadClassIdInstr(r2)
    //     0xa81218: ldur            x1, [x2, #-1]
    //     0xa8121c: ubfx            x1, x1, #0xc, #0x14
    // 0xa81220: stp             x0, x2, [SP, #-0x10]!
    // 0xa81224: ldr             x16, [fp, #0x10]
    // 0xa81228: SaveReg r16
    //     0xa81228: str             x16, [SP, #-8]!
    // 0xa8122c: mov             x0, x1
    // 0xa81230: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa81230: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa81234: r0 = GDT[cid_x0 + -0xffc]()
    //     0xa81234: sub             lr, x0, #0xffc
    //     0xa81238: ldr             lr, [x21, lr, lsl #3]
    //     0xa8123c: blr             lr
    // 0xa81240: add             SP, SP, #0x18
    // 0xa81244: ldr             x1, [fp, #0x18]
    // 0xa81248: LoadField: r2 = r1->field_b
    //     0xa81248: ldur            x2, [x1, #0xb]
    // 0xa8124c: ldr             x3, [fp, #0x10]
    // 0xa81250: cmp             w3, NULL
    // 0xa81254: b.eq            #0xa81280
    // 0xa81258: r4 = LoadInt32Instr(r3)
    //     0xa81258: sbfx            x4, x3, #1, #0x1f
    //     0xa8125c: tbz             w3, #0, #0xa81264
    //     0xa81260: ldur            x4, [x3, #7]
    // 0xa81264: add             x3, x2, x4
    // 0xa81268: StoreField: r1->field_b = r3
    //     0xa81268: stur            x3, [x1, #0xb]
    // 0xa8126c: LeaveFrame
    //     0xa8126c: mov             SP, fp
    //     0xa81270: ldp             fp, lr, [SP], #0x10
    // 0xa81274: ret
    //     0xa81274: ret             
    // 0xa81278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa81278: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8127c: b               #0xa811b8
    // 0xa81280: r0 = NullErrorSharedWithoutFPURegs()
    //     0xa81280: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getUint32(/* No info */) {
    // ** addr: 0xa8134c, size: 0xf0
    // 0xa8134c: EnterFrame
    //     0xa8134c: stp             fp, lr, [SP, #-0x10]!
    //     0xa81350: mov             fp, SP
    // 0xa81354: AllocStack(0x18)
    //     0xa81354: sub             SP, SP, #0x18
    // 0xa81358: CheckStackOverflow
    //     0xa81358: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8135c: cmp             SP, x16
    //     0xa81360: b.ls            #0xa81434
    // 0xa81364: ldr             x0, [fp, #0x10]
    // 0xa81368: LoadField: r1 = r0->field_7
    //     0xa81368: ldur            w1, [x0, #7]
    // 0xa8136c: DecompressPointer r1
    //     0xa8136c: add             x1, x1, HEAP, lsl #32
    // 0xa81370: LoadField: r2 = r0->field_b
    //     0xa81370: ldur            x2, [x0, #0xb]
    // 0xa81374: tbnz            x2, #0x3f, #0xa813cc
    // 0xa81378: add             x3, x2, #3
    // 0xa8137c: LoadField: r4 = r1->field_13
    //     0xa8137c: ldur            w4, [x1, #0x13]
    // 0xa81380: DecompressPointer r4
    //     0xa81380: add             x4, x4, HEAP, lsl #32
    // 0xa81384: r5 = LoadInt32Instr(r4)
    //     0xa81384: sbfx            x5, x4, #1, #0x1f
    // 0xa81388: cmp             x3, x5
    // 0xa8138c: b.ge            #0xa813cc
    // 0xa81390: LoadField: r3 = r1->field_17
    //     0xa81390: ldur            w3, [x1, #0x17]
    // 0xa81394: DecompressPointer r3
    //     0xa81394: add             x3, x3, HEAP, lsl #32
    // 0xa81398: LoadField: r4 = r1->field_1b
    //     0xa81398: ldur            w4, [x1, #0x1b]
    // 0xa8139c: DecompressPointer r4
    //     0xa8139c: add             x4, x4, HEAP, lsl #32
    // 0xa813a0: r1 = LoadInt32Instr(r4)
    //     0xa813a0: sbfx            x1, x4, #1, #0x1f
    // 0xa813a4: add             x4, x1, x2
    // 0xa813a8: LoadField: r1 = r3->field_7
    //     0xa813a8: ldur            x1, [x3, #7]
    // 0xa813ac: ldr             w3, [x1, x4]
    // 0xa813b0: add             x1, x2, #4
    // 0xa813b4: StoreField: r0->field_b = r1
    //     0xa813b4: stur            x1, [x0, #0xb]
    // 0xa813b8: ubfx            x3, x3, #0, #0x20
    // 0xa813bc: mov             x0, x3
    // 0xa813c0: LeaveFrame
    //     0xa813c0: mov             SP, fp
    //     0xa813c4: ldp             fp, lr, [SP], #0x10
    // 0xa813c8: ret
    //     0xa813c8: ret             
    // 0xa813cc: LoadField: r0 = r1->field_13
    //     0xa813cc: ldur            w0, [x1, #0x13]
    // 0xa813d0: DecompressPointer r0
    //     0xa813d0: add             x0, x0, HEAP, lsl #32
    // 0xa813d4: r1 = LoadInt32Instr(r0)
    //     0xa813d4: sbfx            x1, x0, #1, #0x1f
    // 0xa813d8: sub             x3, x1, #4
    // 0xa813dc: r0 = BoxInt64Instr(r2)
    //     0xa813dc: sbfiz           x0, x2, #1, #0x1f
    //     0xa813e0: cmp             x2, x0, asr #1
    //     0xa813e4: b.eq            #0xa813f0
    //     0xa813e8: bl              #0xd69bb8
    //     0xa813ec: stur            x2, [x0, #7]
    // 0xa813f0: stur            x0, [fp, #-0x10]
    // 0xa813f4: lsl             x1, x3, #1
    // 0xa813f8: stur            x1, [fp, #-8]
    // 0xa813fc: r0 = RangeError()
    //     0xa813fc: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa81400: stur            x0, [fp, #-0x18]
    // 0xa81404: ldur            x16, [fp, #-0x10]
    // 0xa81408: stp             x16, x0, [SP, #-0x10]!
    // 0xa8140c: ldur            x16, [fp, #-8]
    // 0xa81410: stp             x16, xzr, [SP, #-0x10]!
    // 0xa81414: r16 = "byteOffset"
    //     0xa81414: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa81418: SaveReg r16
    //     0xa81418: str             x16, [SP, #-8]!
    // 0xa8141c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa8141c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa81420: r0 = RangeError.range()
    //     0xa81420: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa81424: add             SP, SP, #0x28
    // 0xa81428: ldur            x0, [fp, #-0x18]
    // 0xa8142c: r0 = Throw()
    //     0xa8142c: bl              #0xd67e38  ; ThrowStub
    // 0xa81430: brk             #0
    // 0xa81434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa81434: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa81438: b               #0xa81364
  }
  _ getUint16(/* No info */) {
    // ** addr: 0xa8143c, size: 0xec
    // 0xa8143c: EnterFrame
    //     0xa8143c: stp             fp, lr, [SP, #-0x10]!
    //     0xa81440: mov             fp, SP
    // 0xa81444: AllocStack(0x18)
    //     0xa81444: sub             SP, SP, #0x18
    // 0xa81448: CheckStackOverflow
    //     0xa81448: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8144c: cmp             SP, x16
    //     0xa81450: b.ls            #0xa81520
    // 0xa81454: ldr             x0, [fp, #0x10]
    // 0xa81458: LoadField: r1 = r0->field_7
    //     0xa81458: ldur            w1, [x0, #7]
    // 0xa8145c: DecompressPointer r1
    //     0xa8145c: add             x1, x1, HEAP, lsl #32
    // 0xa81460: LoadField: r2 = r0->field_b
    //     0xa81460: ldur            x2, [x0, #0xb]
    // 0xa81464: tbnz            x2, #0x3f, #0xa814b8
    // 0xa81468: add             x3, x2, #1
    // 0xa8146c: LoadField: r4 = r1->field_13
    //     0xa8146c: ldur            w4, [x1, #0x13]
    // 0xa81470: DecompressPointer r4
    //     0xa81470: add             x4, x4, HEAP, lsl #32
    // 0xa81474: r5 = LoadInt32Instr(r4)
    //     0xa81474: sbfx            x5, x4, #1, #0x1f
    // 0xa81478: cmp             x3, x5
    // 0xa8147c: b.ge            #0xa814b8
    // 0xa81480: LoadField: r3 = r1->field_17
    //     0xa81480: ldur            w3, [x1, #0x17]
    // 0xa81484: DecompressPointer r3
    //     0xa81484: add             x3, x3, HEAP, lsl #32
    // 0xa81488: LoadField: r4 = r1->field_1b
    //     0xa81488: ldur            w4, [x1, #0x1b]
    // 0xa8148c: DecompressPointer r4
    //     0xa8148c: add             x4, x4, HEAP, lsl #32
    // 0xa81490: r1 = LoadInt32Instr(r4)
    //     0xa81490: sbfx            x1, x4, #1, #0x1f
    // 0xa81494: add             x4, x1, x2
    // 0xa81498: LoadField: r1 = r3->field_7
    //     0xa81498: ldur            x1, [x3, #7]
    // 0xa8149c: ldrh            w3, [x1, x4]
    // 0xa814a0: add             x1, x2, #2
    // 0xa814a4: StoreField: r0->field_b = r1
    //     0xa814a4: stur            x1, [x0, #0xb]
    // 0xa814a8: mov             x0, x3
    // 0xa814ac: LeaveFrame
    //     0xa814ac: mov             SP, fp
    //     0xa814b0: ldp             fp, lr, [SP], #0x10
    // 0xa814b4: ret
    //     0xa814b4: ret             
    // 0xa814b8: LoadField: r0 = r1->field_13
    //     0xa814b8: ldur            w0, [x1, #0x13]
    // 0xa814bc: DecompressPointer r0
    //     0xa814bc: add             x0, x0, HEAP, lsl #32
    // 0xa814c0: r1 = LoadInt32Instr(r0)
    //     0xa814c0: sbfx            x1, x0, #1, #0x1f
    // 0xa814c4: sub             x3, x1, #2
    // 0xa814c8: r0 = BoxInt64Instr(r2)
    //     0xa814c8: sbfiz           x0, x2, #1, #0x1f
    //     0xa814cc: cmp             x2, x0, asr #1
    //     0xa814d0: b.eq            #0xa814dc
    //     0xa814d4: bl              #0xd69bb8
    //     0xa814d8: stur            x2, [x0, #7]
    // 0xa814dc: stur            x0, [fp, #-0x10]
    // 0xa814e0: lsl             x1, x3, #1
    // 0xa814e4: stur            x1, [fp, #-8]
    // 0xa814e8: r0 = RangeError()
    //     0xa814e8: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa814ec: stur            x0, [fp, #-0x18]
    // 0xa814f0: ldur            x16, [fp, #-0x10]
    // 0xa814f4: stp             x16, x0, [SP, #-0x10]!
    // 0xa814f8: ldur            x16, [fp, #-8]
    // 0xa814fc: stp             x16, xzr, [SP, #-0x10]!
    // 0xa81500: r16 = "byteOffset"
    //     0xa81500: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa81504: SaveReg r16
    //     0xa81504: str             x16, [SP, #-8]!
    // 0xa81508: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa81508: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa8150c: r0 = RangeError.range()
    //     0xa8150c: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa81510: add             SP, SP, #0x28
    // 0xa81514: ldur            x0, [fp, #-0x18]
    // 0xa81518: r0 = Throw()
    //     0xa81518: bl              #0xd67e38  ; ThrowStub
    // 0xa8151c: brk             #0
    // 0xa81520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa81520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa81524: b               #0xa81454
  }
  _ getFloat64(/* No info */) {
    // ** addr: 0xa81528, size: 0xfc
    // 0xa81528: EnterFrame
    //     0xa81528: stp             fp, lr, [SP, #-0x10]!
    //     0xa8152c: mov             fp, SP
    // 0xa81530: AllocStack(0x18)
    //     0xa81530: sub             SP, SP, #0x18
    // 0xa81534: r0 = 8
    //     0xa81534: mov             x0, #8
    // 0xa81538: CheckStackOverflow
    //     0xa81538: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8153c: cmp             SP, x16
    //     0xa81540: b.ls            #0xa8161c
    // 0xa81544: ldr             x16, [fp, #0x10]
    // 0xa81548: stp             x0, x16, [SP, #-0x10]!
    // 0xa8154c: r0 = _alignTo()
    //     0xa8154c: bl              #0xa80e68  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::_alignTo
    // 0xa81550: add             SP, SP, #0x10
    // 0xa81554: ldr             x0, [fp, #0x10]
    // 0xa81558: LoadField: r1 = r0->field_7
    //     0xa81558: ldur            w1, [x0, #7]
    // 0xa8155c: DecompressPointer r1
    //     0xa8155c: add             x1, x1, HEAP, lsl #32
    // 0xa81560: LoadField: r2 = r0->field_b
    //     0xa81560: ldur            x2, [x0, #0xb]
    // 0xa81564: tbnz            x2, #0x3f, #0xa815b4
    // 0xa81568: add             x3, x2, #7
    // 0xa8156c: LoadField: r4 = r1->field_13
    //     0xa8156c: ldur            w4, [x1, #0x13]
    // 0xa81570: DecompressPointer r4
    //     0xa81570: add             x4, x4, HEAP, lsl #32
    // 0xa81574: r5 = LoadInt32Instr(r4)
    //     0xa81574: sbfx            x5, x4, #1, #0x1f
    // 0xa81578: cmp             x3, x5
    // 0xa8157c: b.ge            #0xa815b4
    // 0xa81580: LoadField: r3 = r1->field_17
    //     0xa81580: ldur            w3, [x1, #0x17]
    // 0xa81584: DecompressPointer r3
    //     0xa81584: add             x3, x3, HEAP, lsl #32
    // 0xa81588: LoadField: r4 = r1->field_1b
    //     0xa81588: ldur            w4, [x1, #0x1b]
    // 0xa8158c: DecompressPointer r4
    //     0xa8158c: add             x4, x4, HEAP, lsl #32
    // 0xa81590: r1 = LoadInt32Instr(r4)
    //     0xa81590: sbfx            x1, x4, #1, #0x1f
    // 0xa81594: add             x4, x1, x2
    // 0xa81598: LoadField: r1 = r3->field_7
    //     0xa81598: ldur            x1, [x3, #7]
    // 0xa8159c: ldr             d0, [x1, x4]
    // 0xa815a0: add             x1, x2, #8
    // 0xa815a4: StoreField: r0->field_b = r1
    //     0xa815a4: stur            x1, [x0, #0xb]
    // 0xa815a8: LeaveFrame
    //     0xa815a8: mov             SP, fp
    //     0xa815ac: ldp             fp, lr, [SP], #0x10
    // 0xa815b0: ret
    //     0xa815b0: ret             
    // 0xa815b4: LoadField: r0 = r1->field_13
    //     0xa815b4: ldur            w0, [x1, #0x13]
    // 0xa815b8: DecompressPointer r0
    //     0xa815b8: add             x0, x0, HEAP, lsl #32
    // 0xa815bc: r1 = LoadInt32Instr(r0)
    //     0xa815bc: sbfx            x1, x0, #1, #0x1f
    // 0xa815c0: sub             x3, x1, #8
    // 0xa815c4: r0 = BoxInt64Instr(r2)
    //     0xa815c4: sbfiz           x0, x2, #1, #0x1f
    //     0xa815c8: cmp             x2, x0, asr #1
    //     0xa815cc: b.eq            #0xa815d8
    //     0xa815d0: bl              #0xd69bb8
    //     0xa815d4: stur            x2, [x0, #7]
    // 0xa815d8: stur            x0, [fp, #-0x10]
    // 0xa815dc: lsl             x1, x3, #1
    // 0xa815e0: stur            x1, [fp, #-8]
    // 0xa815e4: r0 = RangeError()
    //     0xa815e4: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa815e8: stur            x0, [fp, #-0x18]
    // 0xa815ec: ldur            x16, [fp, #-0x10]
    // 0xa815f0: stp             x16, x0, [SP, #-0x10]!
    // 0xa815f4: ldur            x16, [fp, #-8]
    // 0xa815f8: stp             x16, xzr, [SP, #-0x10]!
    // 0xa815fc: r16 = "byteOffset"
    //     0xa815fc: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa81600: SaveReg r16
    //     0xa81600: str             x16, [SP, #-8]!
    // 0xa81604: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa81604: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa81608: r0 = RangeError.range()
    //     0xa81608: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa8160c: add             SP, SP, #0x28
    // 0xa81610: ldur            x0, [fp, #-0x18]
    // 0xa81614: r0 = Throw()
    //     0xa81614: bl              #0xd67e38  ; ThrowStub
    // 0xa81618: brk             #0
    // 0xa8161c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8161c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa81620: b               #0xa81544
  }
  _ getInt64(/* No info */) {
    // ** addr: 0xa81624, size: 0xec
    // 0xa81624: EnterFrame
    //     0xa81624: stp             fp, lr, [SP, #-0x10]!
    //     0xa81628: mov             fp, SP
    // 0xa8162c: AllocStack(0x18)
    //     0xa8162c: sub             SP, SP, #0x18
    // 0xa81630: CheckStackOverflow
    //     0xa81630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa81634: cmp             SP, x16
    //     0xa81638: b.ls            #0xa81708
    // 0xa8163c: ldr             x0, [fp, #0x10]
    // 0xa81640: LoadField: r1 = r0->field_7
    //     0xa81640: ldur            w1, [x0, #7]
    // 0xa81644: DecompressPointer r1
    //     0xa81644: add             x1, x1, HEAP, lsl #32
    // 0xa81648: LoadField: r2 = r0->field_b
    //     0xa81648: ldur            x2, [x0, #0xb]
    // 0xa8164c: tbnz            x2, #0x3f, #0xa816a0
    // 0xa81650: add             x3, x2, #7
    // 0xa81654: LoadField: r4 = r1->field_13
    //     0xa81654: ldur            w4, [x1, #0x13]
    // 0xa81658: DecompressPointer r4
    //     0xa81658: add             x4, x4, HEAP, lsl #32
    // 0xa8165c: r5 = LoadInt32Instr(r4)
    //     0xa8165c: sbfx            x5, x4, #1, #0x1f
    // 0xa81660: cmp             x3, x5
    // 0xa81664: b.ge            #0xa816a0
    // 0xa81668: LoadField: r3 = r1->field_17
    //     0xa81668: ldur            w3, [x1, #0x17]
    // 0xa8166c: DecompressPointer r3
    //     0xa8166c: add             x3, x3, HEAP, lsl #32
    // 0xa81670: LoadField: r4 = r1->field_1b
    //     0xa81670: ldur            w4, [x1, #0x1b]
    // 0xa81674: DecompressPointer r4
    //     0xa81674: add             x4, x4, HEAP, lsl #32
    // 0xa81678: r1 = LoadInt32Instr(r4)
    //     0xa81678: sbfx            x1, x4, #1, #0x1f
    // 0xa8167c: add             x4, x1, x2
    // 0xa81680: LoadField: r1 = r3->field_7
    //     0xa81680: ldur            x1, [x3, #7]
    // 0xa81684: ldr             x3, [x1, x4]
    // 0xa81688: add             x1, x2, #8
    // 0xa8168c: StoreField: r0->field_b = r1
    //     0xa8168c: stur            x1, [x0, #0xb]
    // 0xa81690: mov             x0, x3
    // 0xa81694: LeaveFrame
    //     0xa81694: mov             SP, fp
    //     0xa81698: ldp             fp, lr, [SP], #0x10
    // 0xa8169c: ret
    //     0xa8169c: ret             
    // 0xa816a0: LoadField: r0 = r1->field_13
    //     0xa816a0: ldur            w0, [x1, #0x13]
    // 0xa816a4: DecompressPointer r0
    //     0xa816a4: add             x0, x0, HEAP, lsl #32
    // 0xa816a8: r1 = LoadInt32Instr(r0)
    //     0xa816a8: sbfx            x1, x0, #1, #0x1f
    // 0xa816ac: sub             x3, x1, #8
    // 0xa816b0: r0 = BoxInt64Instr(r2)
    //     0xa816b0: sbfiz           x0, x2, #1, #0x1f
    //     0xa816b4: cmp             x2, x0, asr #1
    //     0xa816b8: b.eq            #0xa816c4
    //     0xa816bc: bl              #0xd69bb8
    //     0xa816c0: stur            x2, [x0, #7]
    // 0xa816c4: stur            x0, [fp, #-0x10]
    // 0xa816c8: lsl             x1, x3, #1
    // 0xa816cc: stur            x1, [fp, #-8]
    // 0xa816d0: r0 = RangeError()
    //     0xa816d0: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa816d4: stur            x0, [fp, #-0x18]
    // 0xa816d8: ldur            x16, [fp, #-0x10]
    // 0xa816dc: stp             x16, x0, [SP, #-0x10]!
    // 0xa816e0: ldur            x16, [fp, #-8]
    // 0xa816e4: stp             x16, xzr, [SP, #-0x10]!
    // 0xa816e8: r16 = "byteOffset"
    //     0xa816e8: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa816ec: SaveReg r16
    //     0xa816ec: str             x16, [SP, #-8]!
    // 0xa816f0: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa816f0: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa816f4: r0 = RangeError.range()
    //     0xa816f4: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa816f8: add             SP, SP, #0x28
    // 0xa816fc: ldur            x0, [fp, #-0x18]
    // 0xa81700: r0 = Throw()
    //     0xa81700: bl              #0xd67e38  ; ThrowStub
    // 0xa81704: brk             #0
    // 0xa81708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa81708: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8170c: b               #0xa8163c
  }
  _ getInt32(/* No info */) {
    // ** addr: 0xa81710, size: 0xf0
    // 0xa81710: EnterFrame
    //     0xa81710: stp             fp, lr, [SP, #-0x10]!
    //     0xa81714: mov             fp, SP
    // 0xa81718: AllocStack(0x18)
    //     0xa81718: sub             SP, SP, #0x18
    // 0xa8171c: CheckStackOverflow
    //     0xa8171c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa81720: cmp             SP, x16
    //     0xa81724: b.ls            #0xa817f8
    // 0xa81728: ldr             x0, [fp, #0x10]
    // 0xa8172c: LoadField: r1 = r0->field_7
    //     0xa8172c: ldur            w1, [x0, #7]
    // 0xa81730: DecompressPointer r1
    //     0xa81730: add             x1, x1, HEAP, lsl #32
    // 0xa81734: LoadField: r2 = r0->field_b
    //     0xa81734: ldur            x2, [x0, #0xb]
    // 0xa81738: tbnz            x2, #0x3f, #0xa81790
    // 0xa8173c: add             x3, x2, #3
    // 0xa81740: LoadField: r4 = r1->field_13
    //     0xa81740: ldur            w4, [x1, #0x13]
    // 0xa81744: DecompressPointer r4
    //     0xa81744: add             x4, x4, HEAP, lsl #32
    // 0xa81748: r5 = LoadInt32Instr(r4)
    //     0xa81748: sbfx            x5, x4, #1, #0x1f
    // 0xa8174c: cmp             x3, x5
    // 0xa81750: b.ge            #0xa81790
    // 0xa81754: LoadField: r3 = r1->field_17
    //     0xa81754: ldur            w3, [x1, #0x17]
    // 0xa81758: DecompressPointer r3
    //     0xa81758: add             x3, x3, HEAP, lsl #32
    // 0xa8175c: LoadField: r4 = r1->field_1b
    //     0xa8175c: ldur            w4, [x1, #0x1b]
    // 0xa81760: DecompressPointer r4
    //     0xa81760: add             x4, x4, HEAP, lsl #32
    // 0xa81764: r1 = LoadInt32Instr(r4)
    //     0xa81764: sbfx            x1, x4, #1, #0x1f
    // 0xa81768: add             x4, x1, x2
    // 0xa8176c: LoadField: r1 = r3->field_7
    //     0xa8176c: ldur            x1, [x3, #7]
    // 0xa81770: ldrsw           x3, [x1, x4]
    // 0xa81774: add             x1, x2, #4
    // 0xa81778: StoreField: r0->field_b = r1
    //     0xa81778: stur            x1, [x0, #0xb]
    // 0xa8177c: sxtw            x3, w3
    // 0xa81780: mov             x0, x3
    // 0xa81784: LeaveFrame
    //     0xa81784: mov             SP, fp
    //     0xa81788: ldp             fp, lr, [SP], #0x10
    // 0xa8178c: ret
    //     0xa8178c: ret             
    // 0xa81790: LoadField: r0 = r1->field_13
    //     0xa81790: ldur            w0, [x1, #0x13]
    // 0xa81794: DecompressPointer r0
    //     0xa81794: add             x0, x0, HEAP, lsl #32
    // 0xa81798: r1 = LoadInt32Instr(r0)
    //     0xa81798: sbfx            x1, x0, #1, #0x1f
    // 0xa8179c: sub             x3, x1, #4
    // 0xa817a0: r0 = BoxInt64Instr(r2)
    //     0xa817a0: sbfiz           x0, x2, #1, #0x1f
    //     0xa817a4: cmp             x2, x0, asr #1
    //     0xa817a8: b.eq            #0xa817b4
    //     0xa817ac: bl              #0xd69bb8
    //     0xa817b0: stur            x2, [x0, #7]
    // 0xa817b4: stur            x0, [fp, #-0x10]
    // 0xa817b8: lsl             x1, x3, #1
    // 0xa817bc: stur            x1, [fp, #-8]
    // 0xa817c0: r0 = RangeError()
    //     0xa817c0: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xa817c4: stur            x0, [fp, #-0x18]
    // 0xa817c8: ldur            x16, [fp, #-0x10]
    // 0xa817cc: stp             x16, x0, [SP, #-0x10]!
    // 0xa817d0: ldur            x16, [fp, #-8]
    // 0xa817d4: stp             x16, xzr, [SP, #-0x10]!
    // 0xa817d8: r16 = "byteOffset"
    //     0xa817d8: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xa817dc: SaveReg r16
    //     0xa817dc: str             x16, [SP, #-8]!
    // 0xa817e0: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xa817e0: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xa817e4: r0 = RangeError.range()
    //     0xa817e4: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xa817e8: add             SP, SP, #0x28
    // 0xa817ec: ldur            x0, [fp, #-0x18]
    // 0xa817f0: r0 = Throw()
    //     0xa817f0: bl              #0xd67e38  ; ThrowStub
    // 0xa817f4: brk             #0
    // 0xa817f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa817f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa817fc: b               #0xa81728
  }
}

// class id: 2371, size: 0x20, field offset: 0x8
class WriteBuffer extends Object {

  static late final Uint8List _zeroBuffer; // offset: 0xd48

  _ done(/* No info */) {
    // ** addr: 0x781de0, size: 0x110
    // 0x781de0: EnterFrame
    //     0x781de0: stp             fp, lr, [SP, #-0x10]!
    //     0x781de4: mov             fp, SP
    // 0x781de8: AllocStack(0x8)
    //     0x781de8: sub             SP, SP, #8
    // 0x781dec: CheckStackOverflow
    //     0x781dec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x781df0: cmp             SP, x16
    //     0x781df4: b.ls            #0x781ee8
    // 0x781df8: ldr             x0, [fp, #0x10]
    // 0x781dfc: LoadField: r1 = r0->field_13
    //     0x781dfc: ldur            w1, [x0, #0x13]
    // 0x781e00: DecompressPointer r1
    //     0x781e00: add             x1, x1, HEAP, lsl #32
    // 0x781e04: tbz             w1, #4, #0x781e98
    // 0x781e08: LoadField: r1 = r0->field_7
    //     0x781e08: ldur            w1, [x0, #7]
    // 0x781e0c: DecompressPointer r1
    //     0x781e0c: add             x1, x1, HEAP, lsl #32
    // 0x781e10: stur            x1, [fp, #-8]
    // 0x781e14: r0 = _ByteBuffer()
    //     0x781e14: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x781e18: mov             x2, x0
    // 0x781e1c: ldur            x0, [fp, #-8]
    // 0x781e20: StoreField: r2->field_7 = r0
    //     0x781e20: stur            w0, [x2, #7]
    // 0x781e24: ldr             x3, [fp, #0x10]
    // 0x781e28: LoadField: r4 = r3->field_b
    //     0x781e28: ldur            x4, [x3, #0xb]
    // 0x781e2c: r0 = BoxInt64Instr(r4)
    //     0x781e2c: sbfiz           x0, x4, #1, #0x1f
    //     0x781e30: cmp             x4, x0, asr #1
    //     0x781e34: b.eq            #0x781e40
    //     0x781e38: bl              #0xd69bb8
    //     0x781e3c: stur            x4, [x0, #7]
    // 0x781e40: stp             xzr, x2, [SP, #-0x10]!
    // 0x781e44: SaveReg r0
    //     0x781e44: str             x0, [SP, #-8]!
    // 0x781e48: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x781e48: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x781e4c: r0 = asByteData()
    //     0x781e4c: bl              #0xd64334  ; [dart:typed_data] _ByteBuffer::asByteData
    // 0x781e50: add             SP, SP, #0x18
    // 0x781e54: r4 = 0
    //     0x781e54: mov             x4, #0
    // 0x781e58: stur            x0, [fp, #-8]
    // 0x781e5c: r0 = AllocateUint8Array()
    //     0x781e5c: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x781e60: ldr             x1, [fp, #0x10]
    // 0x781e64: StoreField: r1->field_7 = r0
    //     0x781e64: stur            w0, [x1, #7]
    //     0x781e68: ldurb           w16, [x1, #-1]
    //     0x781e6c: ldurb           w17, [x0, #-1]
    //     0x781e70: and             x16, x17, x16, lsr #2
    //     0x781e74: tst             x16, HEAP, lsr #32
    //     0x781e78: b.eq            #0x781e80
    //     0x781e7c: bl              #0xd6826c
    // 0x781e80: r2 = true
    //     0x781e80: add             x2, NULL, #0x20  ; true
    // 0x781e84: StoreField: r1->field_13 = r2
    //     0x781e84: stur            w2, [x1, #0x13]
    // 0x781e88: ldur            x0, [fp, #-8]
    // 0x781e8c: LeaveFrame
    //     0x781e8c: mov             SP, fp
    //     0x781e90: ldp             fp, lr, [SP], #0x10
    // 0x781e94: ret
    //     0x781e94: ret             
    // 0x781e98: r1 = Null
    //     0x781e98: mov             x1, NULL
    // 0x781e9c: r2 = 6
    //     0x781e9c: mov             x2, #6
    // 0x781ea0: r0 = AllocateArray()
    //     0x781ea0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x781ea4: r17 = "done() must not be called more than once on the same "
    //     0x781ea4: ldr             x17, [PP, #0x5ae0]  ; [pp+0x5ae0] "done() must not be called more than once on the same "
    // 0x781ea8: StoreField: r0->field_f = r17
    //     0x781ea8: stur            w17, [x0, #0xf]
    // 0x781eac: r17 = WriteBuffer
    //     0x781eac: ldr             x17, [PP, #0x5ae8]  ; [pp+0x5ae8] Type: WriteBuffer
    // 0x781eb0: StoreField: r0->field_13 = r17
    //     0x781eb0: stur            w17, [x0, #0x13]
    // 0x781eb4: r17 = "."
    //     0x781eb4: ldr             x17, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x781eb8: StoreField: r0->field_17 = r17
    //     0x781eb8: stur            w17, [x0, #0x17]
    // 0x781ebc: SaveReg r0
    //     0x781ebc: str             x0, [SP, #-8]!
    // 0x781ec0: r0 = _interpolate()
    //     0x781ec0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x781ec4: add             SP, SP, #8
    // 0x781ec8: stur            x0, [fp, #-8]
    // 0x781ecc: r0 = StateError()
    //     0x781ecc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x781ed0: mov             x1, x0
    // 0x781ed4: ldur            x0, [fp, #-8]
    // 0x781ed8: StoreField: r1->field_b = r0
    //     0x781ed8: stur            w0, [x1, #0xb]
    // 0x781edc: mov             x0, x1
    // 0x781ee0: r0 = Throw()
    //     0x781ee0: bl              #0xd67e38  ; ThrowStub
    // 0x781ee4: brk             #0
    // 0x781ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x781ee8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x781eec: b               #0x781df8
  }
  factory _ WriteBuffer(/* No info */) {
    // ** addr: 0x781ef0, size: 0xb0
    // 0x781ef0: EnterFrame
    //     0x781ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x781ef4: mov             fp, SP
    // 0x781ef8: AllocStack(0x18)
    //     0x781ef8: sub             SP, SP, #0x18
    // 0x781efc: CheckStackOverflow
    //     0x781efc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x781f00: cmp             SP, x16
    //     0x781f04: b.ls            #0x781f98
    // 0x781f08: r16 = 16
    //     0x781f08: mov             x16, #0x10
    // 0x781f0c: stp             x16, NULL, [SP, #-0x10]!
    // 0x781f10: r0 = ByteData()
    //     0x781f10: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x781f14: add             SP, SP, #0x10
    // 0x781f18: stur            x0, [fp, #-0x10]
    // 0x781f1c: LoadField: r1 = r0->field_17
    //     0x781f1c: ldur            w1, [x0, #0x17]
    // 0x781f20: DecompressPointer r1
    //     0x781f20: add             x1, x1, HEAP, lsl #32
    // 0x781f24: stur            x1, [fp, #-8]
    // 0x781f28: r0 = _ByteBuffer()
    //     0x781f28: bl              #0x4b2c3c  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x781f2c: mov             x1, x0
    // 0x781f30: ldur            x0, [fp, #-8]
    // 0x781f34: StoreField: r1->field_7 = r0
    //     0x781f34: stur            w0, [x1, #7]
    // 0x781f38: SaveReg r1
    //     0x781f38: str             x1, [SP, #-8]!
    // 0x781f3c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x781f3c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x781f40: r0 = asUint8List()
    //     0x781f40: bl              #0xd64518  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0x781f44: add             SP, SP, #8
    // 0x781f48: stur            x0, [fp, #-8]
    // 0x781f4c: r0 = WriteBuffer()
    //     0x781f4c: bl              #0x781fa0  ; AllocateWriteBufferStub -> WriteBuffer (size=0x20)
    // 0x781f50: mov             x1, x0
    // 0x781f54: r0 = 0
    //     0x781f54: mov             x0, #0
    // 0x781f58: stur            x1, [fp, #-0x18]
    // 0x781f5c: StoreField: r1->field_b = r0
    //     0x781f5c: stur            x0, [x1, #0xb]
    // 0x781f60: r0 = false
    //     0x781f60: add             x0, NULL, #0x30  ; false
    // 0x781f64: StoreField: r1->field_13 = r0
    //     0x781f64: stur            w0, [x1, #0x13]
    // 0x781f68: r4 = 128
    //     0x781f68: mov             x4, #0x80
    // 0x781f6c: r0 = AllocateUint8Array()
    //     0x781f6c: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x781f70: mov             x1, x0
    // 0x781f74: ldur            x0, [fp, #-0x18]
    // 0x781f78: StoreField: r0->field_7 = r1
    //     0x781f78: stur            w1, [x0, #7]
    // 0x781f7c: ldur            x1, [fp, #-0x10]
    // 0x781f80: StoreField: r0->field_17 = r1
    //     0x781f80: stur            w1, [x0, #0x17]
    // 0x781f84: ldur            x1, [fp, #-8]
    // 0x781f88: StoreField: r0->field_1b = r1
    //     0x781f88: stur            w1, [x0, #0x1b]
    // 0x781f8c: LeaveFrame
    //     0x781f8c: mov             SP, fp
    //     0x781f90: ldp             fp, lr, [SP], #0x10
    // 0x781f94: ret
    //     0x781f94: ret             
    // 0x781f98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x781f98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x781f9c: b               #0x781f08
  }
  _ _add(/* No info */) {
    // ** addr: 0xbe0178, size: 0xa0
    // 0xbe0178: EnterFrame
    //     0xbe0178: stp             fp, lr, [SP, #-0x10]!
    //     0xbe017c: mov             fp, SP
    // 0xbe0180: CheckStackOverflow
    //     0xbe0180: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe0184: cmp             SP, x16
    //     0xbe0188: b.ls            #0xbe020c
    // 0xbe018c: ldr             x0, [fp, #0x18]
    // 0xbe0190: LoadField: r1 = r0->field_b
    //     0xbe0190: ldur            x1, [x0, #0xb]
    // 0xbe0194: LoadField: r2 = r0->field_7
    //     0xbe0194: ldur            w2, [x0, #7]
    // 0xbe0198: DecompressPointer r2
    //     0xbe0198: add             x2, x2, HEAP, lsl #32
    // 0xbe019c: LoadField: r3 = r2->field_13
    //     0xbe019c: ldur            w3, [x2, #0x13]
    // 0xbe01a0: DecompressPointer r3
    //     0xbe01a0: add             x3, x3, HEAP, lsl #32
    // 0xbe01a4: r2 = LoadInt32Instr(r3)
    //     0xbe01a4: sbfx            x2, x3, #1, #0x1f
    // 0xbe01a8: cmp             x1, x2
    // 0xbe01ac: b.ne            #0xbe01c0
    // 0xbe01b0: SaveReg r0
    //     0xbe01b0: str             x0, [SP, #-8]!
    // 0xbe01b4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xbe01b4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xbe01b8: r0 = _resize()
    //     0xbe01b8: bl              #0xbe0218  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_resize
    // 0xbe01bc: add             SP, SP, #8
    // 0xbe01c0: ldr             x2, [fp, #0x18]
    // 0xbe01c4: ldr             x3, [fp, #0x10]
    // 0xbe01c8: LoadField: r4 = r2->field_7
    //     0xbe01c8: ldur            w4, [x2, #7]
    // 0xbe01cc: DecompressPointer r4
    //     0xbe01cc: add             x4, x4, HEAP, lsl #32
    // 0xbe01d0: LoadField: r5 = r2->field_b
    //     0xbe01d0: ldur            x5, [x2, #0xb]
    // 0xbe01d4: LoadField: r6 = r4->field_13
    //     0xbe01d4: ldur            w6, [x4, #0x13]
    // 0xbe01d8: DecompressPointer r6
    //     0xbe01d8: add             x6, x6, HEAP, lsl #32
    // 0xbe01dc: r0 = LoadInt32Instr(r6)
    //     0xbe01dc: sbfx            x0, x6, #1, #0x1f
    // 0xbe01e0: mov             x1, x5
    // 0xbe01e4: cmp             x1, x0
    // 0xbe01e8: b.hs            #0xbe0214
    // 0xbe01ec: LoadField: r1 = r4->field_7
    //     0xbe01ec: ldur            x1, [x4, #7]
    // 0xbe01f0: strb            w3, [x1, x5]
    // 0xbe01f4: add             x1, x5, #1
    // 0xbe01f8: StoreField: r2->field_b = r1
    //     0xbe01f8: stur            x1, [x2, #0xb]
    // 0xbe01fc: r0 = Null
    //     0xbe01fc: mov             x0, NULL
    // 0xbe0200: LeaveFrame
    //     0xbe0200: mov             SP, fp
    //     0xbe0204: ldp             fp, lr, [SP], #0x10
    // 0xbe0208: ret
    //     0xbe0208: ret             
    // 0xbe020c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe020c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe0210: b               #0xbe018c
    // 0xbe0214: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe0214: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _resize(/* No info */) {
    // ** addr: 0xbe0218, size: 0x2f4
    // 0xbe0218: EnterFrame
    //     0xbe0218: stp             fp, lr, [SP, #-0x10]!
    //     0xbe021c: mov             fp, SP
    // 0xbe0220: AllocStack(0x20)
    //     0xbe0220: sub             SP, SP, #0x20
    // 0xbe0224: SetupParameters(WriteBuffer this /* r3, fp-0x10 */, [dynamic _ = Null /* r0 */])
    //     0xbe0224: mov             x0, x4
    //     0xbe0228: ldur            w1, [x0, #0x13]
    //     0xbe022c: add             x1, x1, HEAP, lsl #32
    //     0xbe0230: sub             x0, x1, #2
    //     0xbe0234: add             x3, fp, w0, sxtw #2
    //     0xbe0238: ldr             x3, [x3, #0x10]
    //     0xbe023c: stur            x3, [fp, #-0x10]
    //     0xbe0240: cmp             w0, #2
    //     0xbe0244: b.lt            #0xbe0258
    //     0xbe0248: add             x1, fp, w0, sxtw #2
    //     0xbe024c: ldr             x1, [x1, #8]
    //     0xbe0250: mov             x0, x1
    //     0xbe0254: b               #0xbe025c
    //     0xbe0258: mov             x0, NULL
    // 0xbe025c: CheckStackOverflow
    //     0xbe025c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe0260: cmp             SP, x16
    //     0xbe0264: b.ls            #0xbe04e8
    // 0xbe0268: LoadField: r1 = r3->field_7
    //     0xbe0268: ldur            w1, [x3, #7]
    // 0xbe026c: DecompressPointer r1
    //     0xbe026c: add             x1, x1, HEAP, lsl #32
    // 0xbe0270: LoadField: r2 = r1->field_13
    //     0xbe0270: ldur            w2, [x1, #0x13]
    // 0xbe0274: DecompressPointer r2
    //     0xbe0274: add             x2, x2, HEAP, lsl #32
    // 0xbe0278: r1 = LoadInt32Instr(r2)
    //     0xbe0278: sbfx            x1, x2, #1, #0x1f
    // 0xbe027c: lsl             x2, x1, #1
    // 0xbe0280: cmp             w0, NULL
    // 0xbe0284: b.ne            #0xbe0290
    // 0xbe0288: r4 = 0
    //     0xbe0288: mov             x4, #0
    // 0xbe028c: b               #0xbe02a0
    // 0xbe0290: r1 = LoadInt32Instr(r0)
    //     0xbe0290: sbfx            x1, x0, #1, #0x1f
    //     0xbe0294: tbz             w0, #0, #0xbe029c
    //     0xbe0298: ldur            x1, [x0, #7]
    // 0xbe029c: mov             x4, x1
    // 0xbe02a0: stur            x4, [fp, #-0x20]
    // 0xbe02a4: cmp             x4, x2
    // 0xbe02a8: b.le            #0xbe02cc
    // 0xbe02ac: r0 = BoxInt64Instr(r4)
    //     0xbe02ac: sbfiz           x0, x4, #1, #0x1f
    //     0xbe02b0: cmp             x4, x0, asr #1
    //     0xbe02b4: b.eq            #0xbe02c0
    //     0xbe02b8: bl              #0xd69bb8
    //     0xbe02bc: stur            x4, [x0, #7]
    // 0xbe02c0: mov             x4, x0
    // 0xbe02c4: mov             x0, x3
    // 0xbe02c8: b               #0xbe0474
    // 0xbe02cc: cmp             x4, x2
    // 0xbe02d0: b.ge            #0xbe02f4
    // 0xbe02d4: r0 = BoxInt64Instr(r2)
    //     0xbe02d4: sbfiz           x0, x2, #1, #0x1f
    //     0xbe02d8: cmp             x2, x0, asr #1
    //     0xbe02dc: b.eq            #0xbe02e8
    //     0xbe02e0: bl              #0xd69bb8
    //     0xbe02e4: stur            x2, [x0, #7]
    // 0xbe02e8: mov             x4, x0
    // 0xbe02ec: mov             x0, x3
    // 0xbe02f0: b               #0xbe0474
    // 0xbe02f4: r0 = BoxInt64Instr(r2)
    //     0xbe02f4: sbfiz           x0, x2, #1, #0x1f
    //     0xbe02f8: cmp             x2, x0, asr #1
    //     0xbe02fc: b.eq            #0xbe0308
    //     0xbe0300: bl              #0xd69bb8
    //     0xbe0304: stur            x2, [x0, #7]
    // 0xbe0308: mov             x5, x0
    // 0xbe030c: stur            x5, [fp, #-0x18]
    // 0xbe0310: r0 = LoadTaggedClassIdMayBeSmiInstr(r5)
    //     0xbe0310: mov             x0, #0x76
    //     0xbe0314: tbz             w5, #0, #0xbe0324
    //     0xbe0318: ldur            x0, [x5, #-1]
    //     0xbe031c: ubfx            x0, x0, #0xc, #0x14
    //     0xbe0320: lsl             x0, x0, #1
    // 0xbe0324: cmp             w0, #0x7a
    // 0xbe0328: b.ne            #0xbe0404
    // 0xbe032c: r0 = BoxInt64Instr(r4)
    //     0xbe032c: sbfiz           x0, x4, #1, #0x1f
    //     0xbe0330: cmp             x4, x0, asr #1
    //     0xbe0334: b.eq            #0xbe0340
    //     0xbe0338: bl              #0xd69bb8
    //     0xbe033c: stur            x4, [x0, #7]
    // 0xbe0340: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xbe0340: mov             x1, #0x76
    //     0xbe0344: tbz             w0, #0, #0xbe0354
    //     0xbe0348: ldur            x1, [x0, #-1]
    //     0xbe034c: ubfx            x1, x1, #0xc, #0x14
    //     0xbe0350: lsl             x1, x1, #1
    // 0xbe0354: cmp             w1, #0x7a
    // 0xbe0358: b.ne            #0xbe03e0
    // 0xbe035c: d0 = 0.000000
    //     0xbe035c: eor             v0.16b, v0.16b, v0.16b
    // 0xbe0360: LoadField: d1 = r0->field_7
    //     0xbe0360: ldur            d1, [x0, #7]
    // 0xbe0364: fcmp            d1, d0
    // 0xbe0368: b.vs            #0xbe03e0
    // 0xbe036c: b.ne            #0xbe03e0
    // 0xbe0370: scvtf           d0, x2
    // 0xbe0374: fadd            d2, d1, d0
    // 0xbe0378: r4 = inline_Allocate_Double()
    //     0xbe0378: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0xbe037c: add             x4, x4, #0x10
    //     0xbe0380: cmp             x0, x4
    //     0xbe0384: b.ls            #0xbe04f0
    //     0xbe0388: str             x4, [THR, #0x60]  ; THR::top
    //     0xbe038c: sub             x4, x4, #0xf
    //     0xbe0390: mov             x0, #0xd108
    //     0xbe0394: movk            x0, #3, lsl #16
    //     0xbe0398: stur            x0, [x4, #-1]
    // 0xbe039c: StoreField: r4->field_7 = d2
    //     0xbe039c: stur            d2, [x4, #7]
    // 0xbe03a0: mov             x0, x4
    // 0xbe03a4: stur            x4, [fp, #-8]
    // 0xbe03a8: r2 = Null
    //     0xbe03a8: mov             x2, NULL
    // 0xbe03ac: r1 = Null
    //     0xbe03ac: mov             x1, NULL
    // 0xbe03b0: branchIfSmi(r0, 0xbe03d4)
    //     0xbe03b0: tbz             w0, #0, #0xbe03d4
    // 0xbe03b4: r4 = LoadClassIdInstr(r0)
    //     0xbe03b4: ldur            x4, [x0, #-1]
    //     0xbe03b8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe03bc: sub             x4, x4, #0x3b
    // 0xbe03c0: cmp             x4, #1
    // 0xbe03c4: b.ls            #0xbe03d4
    // 0xbe03c8: r8 = int
    //     0xbe03c8: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xbe03cc: r3 = Null
    //     0xbe03cc: ldr             x3, [PP, #0x6f40]  ; [pp+0x6f40] Null
    // 0xbe03d0: r0 = int()
    //     0xbe03d0: bl              #0xd73714  ; IsType_int_Stub
    // 0xbe03d4: ldur            x4, [fp, #-8]
    // 0xbe03d8: ldur            x0, [fp, #-0x10]
    // 0xbe03dc: b               #0xbe0474
    // 0xbe03e0: LoadField: d0 = r5->field_7
    //     0xbe03e0: ldur            d0, [x5, #7]
    // 0xbe03e4: fcmp            d0, d0
    // 0xbe03e8: b.vc            #0xbe03f8
    // 0xbe03ec: mov             x4, x5
    // 0xbe03f0: ldur            x0, [fp, #-0x10]
    // 0xbe03f4: b               #0xbe0474
    // 0xbe03f8: mov             x4, x0
    // 0xbe03fc: ldur            x0, [fp, #-0x10]
    // 0xbe0400: b               #0xbe0474
    // 0xbe0404: cbnz            x2, #0xbe0454
    // 0xbe0408: r0 = BoxInt64Instr(r4)
    //     0xbe0408: sbfiz           x0, x4, #1, #0x1f
    //     0xbe040c: cmp             x4, x0, asr #1
    //     0xbe0410: b.eq            #0xbe041c
    //     0xbe0414: bl              #0xd69bb8
    //     0xbe0418: stur            x4, [x0, #7]
    // 0xbe041c: r1 = 59
    //     0xbe041c: mov             x1, #0x3b
    // 0xbe0420: branchIfSmi(r0, 0xbe042c)
    //     0xbe0420: tbz             w0, #0, #0xbe042c
    // 0xbe0424: r1 = LoadClassIdInstr(r0)
    //     0xbe0424: ldur            x1, [x0, #-1]
    //     0xbe0428: ubfx            x1, x1, #0xc, #0x14
    // 0xbe042c: SaveReg r0
    //     0xbe042c: str             x0, [SP, #-8]!
    // 0xbe0430: mov             x0, x1
    // 0xbe0434: r0 = GDT[cid_x0 + -0xfb6]()
    //     0xbe0434: sub             lr, x0, #0xfb6
    //     0xbe0438: ldr             lr, [x21, lr, lsl #3]
    //     0xbe043c: blr             lr
    // 0xbe0440: add             SP, SP, #8
    // 0xbe0444: tbnz            w0, #4, #0xbe0454
    // 0xbe0448: ldur            x4, [fp, #-0x18]
    // 0xbe044c: ldur            x0, [fp, #-0x10]
    // 0xbe0450: b               #0xbe0474
    // 0xbe0454: ldur            x2, [fp, #-0x20]
    // 0xbe0458: r0 = BoxInt64Instr(r2)
    //     0xbe0458: sbfiz           x0, x2, #1, #0x1f
    //     0xbe045c: cmp             x2, x0, asr #1
    //     0xbe0460: b.eq            #0xbe046c
    //     0xbe0464: bl              #0xd69bb8
    //     0xbe0468: stur            x2, [x0, #7]
    // 0xbe046c: mov             x4, x0
    // 0xbe0470: ldur            x0, [fp, #-0x10]
    // 0xbe0474: LoadField: r1 = r0->field_7
    //     0xbe0474: ldur            w1, [x0, #7]
    // 0xbe0478: DecompressPointer r1
    //     0xbe0478: add             x1, x1, HEAP, lsl #32
    // 0xbe047c: stur            x1, [fp, #-8]
    // 0xbe0480: LoadField: r2 = r1->field_13
    //     0xbe0480: ldur            w2, [x1, #0x13]
    // 0xbe0484: DecompressPointer r2
    //     0xbe0484: add             x2, x2, HEAP, lsl #32
    // 0xbe0488: r3 = LoadInt32Instr(r2)
    //     0xbe0488: sbfx            x3, x2, #1, #0x1f
    // 0xbe048c: stur            x3, [fp, #-0x20]
    // 0xbe0490: r0 = AllocateUint8Array()
    //     0xbe0490: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xbe0494: stur            x0, [fp, #-0x18]
    // 0xbe0498: stp             xzr, x0, [SP, #-0x10]!
    // 0xbe049c: ldur            x1, [fp, #-0x20]
    // 0xbe04a0: ldur            x16, [fp, #-8]
    // 0xbe04a4: stp             x16, x1, [SP, #-0x10]!
    // 0xbe04a8: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xbe04a8: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xbe04ac: r0 = setRange()
    //     0xbe04ac: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0xbe04b0: add             SP, SP, #0x20
    // 0xbe04b4: ldur            x0, [fp, #-0x18]
    // 0xbe04b8: ldur            x1, [fp, #-0x10]
    // 0xbe04bc: StoreField: r1->field_7 = r0
    //     0xbe04bc: stur            w0, [x1, #7]
    //     0xbe04c0: ldurb           w16, [x1, #-1]
    //     0xbe04c4: ldurb           w17, [x0, #-1]
    //     0xbe04c8: and             x16, x17, x16, lsr #2
    //     0xbe04cc: tst             x16, HEAP, lsr #32
    //     0xbe04d0: b.eq            #0xbe04d8
    //     0xbe04d4: bl              #0xd6826c
    // 0xbe04d8: r0 = Null
    //     0xbe04d8: mov             x0, NULL
    // 0xbe04dc: LeaveFrame
    //     0xbe04dc: mov             SP, fp
    //     0xbe04e0: ldp             fp, lr, [SP], #0x10
    // 0xbe04e4: ret
    //     0xbe04e4: ret             
    // 0xbe04e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe04e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe04ec: b               #0xbe0268
    // 0xbe04f0: SaveReg d2
    //     0xbe04f0: str             q2, [SP, #-0x10]!
    // 0xbe04f4: SaveReg r3
    //     0xbe04f4: str             x3, [SP, #-8]!
    // 0xbe04f8: r0 = AllocateDouble()
    //     0xbe04f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbe04fc: mov             x4, x0
    // 0xbe0500: RestoreReg r3
    //     0xbe0500: ldr             x3, [SP], #8
    // 0xbe0504: RestoreReg d2
    //     0xbe0504: ldr             q2, [SP], #0x10
    // 0xbe0508: b               #0xbe039c
  }
  _ putInt64List(/* No info */) {
    // ** addr: 0xbe2e7c, size: 0xf8
    // 0xbe2e7c: EnterFrame
    //     0xbe2e7c: stp             fp, lr, [SP, #-0x10]!
    //     0xbe2e80: mov             fp, SP
    // 0xbe2e84: AllocStack(0x8)
    //     0xbe2e84: sub             SP, SP, #8
    // 0xbe2e88: r0 = 8
    //     0xbe2e88: mov             x0, #8
    // 0xbe2e8c: CheckStackOverflow
    //     0xbe2e8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe2e90: cmp             SP, x16
    //     0xbe2e94: b.ls            #0xbe2f6c
    // 0xbe2e98: ldr             x16, [fp, #0x18]
    // 0xbe2e9c: stp             x0, x16, [SP, #-0x10]!
    // 0xbe2ea0: r0 = _alignTo()
    //     0xbe2ea0: bl              #0xbe2f74  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_alignTo
    // 0xbe2ea4: add             SP, SP, #0x10
    // 0xbe2ea8: ldr             x1, [fp, #0x10]
    // 0xbe2eac: r0 = LoadClassIdInstr(r1)
    //     0xbe2eac: ldur            x0, [x1, #-1]
    //     0xbe2eb0: ubfx            x0, x0, #0xc, #0x14
    // 0xbe2eb4: SaveReg r1
    //     0xbe2eb4: str             x1, [SP, #-8]!
    // 0xbe2eb8: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xbe2eb8: sub             lr, x0, #0xf7e
    //     0xbe2ebc: ldr             lr, [x21, lr, lsl #3]
    //     0xbe2ec0: blr             lr
    // 0xbe2ec4: add             SP, SP, #8
    // 0xbe2ec8: mov             x2, x0
    // 0xbe2ecc: ldr             x1, [fp, #0x10]
    // 0xbe2ed0: stur            x2, [fp, #-8]
    // 0xbe2ed4: r0 = LoadClassIdInstr(r1)
    //     0xbe2ed4: ldur            x0, [x1, #-1]
    //     0xbe2ed8: ubfx            x0, x0, #0xc, #0x14
    // 0xbe2edc: SaveReg r1
    //     0xbe2edc: str             x1, [SP, #-8]!
    // 0xbe2ee0: r0 = GDT[cid_x0 + -0xef6]()
    //     0xbe2ee0: sub             lr, x0, #0xef6
    //     0xbe2ee4: ldr             lr, [x21, lr, lsl #3]
    //     0xbe2ee8: blr             lr
    // 0xbe2eec: add             SP, SP, #8
    // 0xbe2ef0: mov             x2, x0
    // 0xbe2ef4: ldr             x0, [fp, #0x10]
    // 0xbe2ef8: LoadField: r1 = r0->field_13
    //     0xbe2ef8: ldur            w1, [x0, #0x13]
    // 0xbe2efc: DecompressPointer r1
    //     0xbe2efc: add             x1, x1, HEAP, lsl #32
    // 0xbe2f00: r0 = LoadInt32Instr(r1)
    //     0xbe2f00: sbfx            x0, x1, #1, #0x1f
    // 0xbe2f04: lsl             x3, x0, #3
    // 0xbe2f08: r0 = BoxInt64Instr(r3)
    //     0xbe2f08: sbfiz           x0, x3, #1, #0x1f
    //     0xbe2f0c: cmp             x3, x0, asr #1
    //     0xbe2f10: b.eq            #0xbe2f1c
    //     0xbe2f14: bl              #0xd69bb8
    //     0xbe2f18: stur            x3, [x0, #7]
    // 0xbe2f1c: mov             x1, x0
    // 0xbe2f20: ldur            x0, [fp, #-8]
    // 0xbe2f24: r3 = LoadClassIdInstr(r0)
    //     0xbe2f24: ldur            x3, [x0, #-1]
    //     0xbe2f28: ubfx            x3, x3, #0xc, #0x14
    // 0xbe2f2c: stp             x2, x0, [SP, #-0x10]!
    // 0xbe2f30: SaveReg r1
    //     0xbe2f30: str             x1, [SP, #-8]!
    // 0xbe2f34: mov             x0, x3
    // 0xbe2f38: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbe2f38: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbe2f3c: r0 = GDT[cid_x0 + -0xffc]()
    //     0xbe2f3c: sub             lr, x0, #0xffc
    //     0xbe2f40: ldr             lr, [x21, lr, lsl #3]
    //     0xbe2f44: blr             lr
    // 0xbe2f48: add             SP, SP, #0x18
    // 0xbe2f4c: ldr             x16, [fp, #0x18]
    // 0xbe2f50: stp             x0, x16, [SP, #-0x10]!
    // 0xbe2f54: r0 = _append()
    //     0xbe2f54: bl              #0xbe32a4  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_append
    // 0xbe2f58: add             SP, SP, #0x10
    // 0xbe2f5c: r0 = Null
    //     0xbe2f5c: mov             x0, NULL
    // 0xbe2f60: LeaveFrame
    //     0xbe2f60: mov             SP, fp
    //     0xbe2f64: ldp             fp, lr, [SP], #0x10
    // 0xbe2f68: ret
    //     0xbe2f68: ret             
    // 0xbe2f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe2f6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe2f70: b               #0xbe2e98
  }
  _ _alignTo(/* No info */) {
    // ** addr: 0xbe2f74, size: 0xe0
    // 0xbe2f74: EnterFrame
    //     0xbe2f74: stp             fp, lr, [SP, #-0x10]!
    //     0xbe2f78: mov             fp, SP
    // 0xbe2f7c: AllocStack(0x8)
    //     0xbe2f7c: sub             SP, SP, #8
    // 0xbe2f80: CheckStackOverflow
    //     0xbe2f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe2f84: cmp             SP, x16
    //     0xbe2f88: b.ls            #0xbe301c
    // 0xbe2f8c: ldr             x0, [fp, #0x18]
    // 0xbe2f90: LoadField: r1 = r0->field_b
    //     0xbe2f90: ldur            x1, [x0, #0xb]
    // 0xbe2f94: ldr             x2, [fp, #0x10]
    // 0xbe2f98: cbz             x2, #0xbe3024
    // 0xbe2f9c: sdiv            x4, x1, x2
    // 0xbe2fa0: msub            x3, x4, x2, x1
    // 0xbe2fa4: cmp             x3, xzr
    // 0xbe2fa8: b.lt            #0xbe3040
    // 0xbe2fac: stur            x3, [fp, #-8]
    // 0xbe2fb0: cbz             x3, #0xbe300c
    // 0xbe2fb4: r0 = InitLateStaticField(0xd48) // [package:flutter/src/foundation/serialization.dart] WriteBuffer::_zeroBuffer
    //     0xbe2fb4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xbe2fb8: ldr             x0, [x0, #0x1a90]
    //     0xbe2fbc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xbe2fc0: cmp             w0, w16
    //     0xbe2fc4: b.ne            #0xbe2fd0
    //     0xbe2fc8: ldr             x2, [PP, #0x6fa8]  ; [pp+0x6fa8] Field <WriteBuffer._zeroBuffer@647185525>: static late final (offset: 0xd48)
    //     0xbe2fcc: bl              #0xd67cdc
    // 0xbe2fd0: mov             x2, x0
    // 0xbe2fd4: ldr             x0, [fp, #0x10]
    // 0xbe2fd8: ldur            x1, [fp, #-8]
    // 0xbe2fdc: sub             x3, x0, x1
    // 0xbe2fe0: r0 = BoxInt64Instr(r3)
    //     0xbe2fe0: sbfiz           x0, x3, #1, #0x1f
    //     0xbe2fe4: cmp             x3, x0, asr #1
    //     0xbe2fe8: b.eq            #0xbe2ff4
    //     0xbe2fec: bl              #0xd69bb8
    //     0xbe2ff0: stur            x3, [x0, #7]
    // 0xbe2ff4: ldr             x16, [fp, #0x18]
    // 0xbe2ff8: stp             x2, x16, [SP, #-0x10]!
    // 0xbe2ffc: SaveReg r0
    //     0xbe2ffc: str             x0, [SP, #-8]!
    // 0xbe3000: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbe3000: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbe3004: r0 = _addAll()
    //     0xbe3004: bl              #0xbe3054  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0xbe3008: add             SP, SP, #0x18
    // 0xbe300c: r0 = Null
    //     0xbe300c: mov             x0, NULL
    // 0xbe3010: LeaveFrame
    //     0xbe3010: mov             SP, fp
    //     0xbe3014: ldp             fp, lr, [SP], #0x10
    // 0xbe3018: ret
    //     0xbe3018: ret             
    // 0xbe301c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe301c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe3020: b               #0xbe2f8c
    // 0xbe3024: stp             x1, x2, [SP, #-0x10]!
    // 0xbe3028: SaveReg r0
    //     0xbe3028: str             x0, [SP, #-8]!
    // 0xbe302c: ldr             x5, [THR, #0x4a8]  ; THR::IntegerDivisionByZeroException
    // 0xbe3030: r4 = 0
    //     0xbe3030: mov             x4, #0
    // 0xbe3034: ldr             lr, [THR, #0x258]  ; THR::call_to_runtime_entry_point
    // 0xbe3038: blr             lr
    // 0xbe303c: brk             #0
    // 0xbe3040: cmp             x2, xzr
    // 0xbe3044: sub             x4, x3, x2
    // 0xbe3048: add             x3, x3, x2
    // 0xbe304c: csel            x3, x4, x3, lt
    // 0xbe3050: b               #0xbe2fac
  }
  _ _addAll(/* No info */) {
    // ** addr: 0xbe3054, size: 0x13c
    // 0xbe3054: EnterFrame
    //     0xbe3054: stp             fp, lr, [SP, #-0x10]!
    //     0xbe3058: mov             fp, SP
    // 0xbe305c: AllocStack(0x18)
    //     0xbe305c: sub             SP, SP, #0x18
    // 0xbe3060: SetupParameters(WriteBuffer this /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */, [dynamic _ = Null /* r0 */])
    //     0xbe3060: mov             x0, x4
    //     0xbe3064: ldur            w1, [x0, #0x13]
    //     0xbe3068: add             x1, x1, HEAP, lsl #32
    //     0xbe306c: sub             x0, x1, #4
    //     0xbe3070: add             x2, fp, w0, sxtw #2
    //     0xbe3074: ldr             x2, [x2, #0x18]
    //     0xbe3078: stur            x2, [fp, #-0x18]
    //     0xbe307c: add             x3, fp, w0, sxtw #2
    //     0xbe3080: ldr             x3, [x3, #0x10]
    //     0xbe3084: stur            x3, [fp, #-0x10]
    //     0xbe3088: cmp             w0, #2
    //     0xbe308c: b.lt            #0xbe30a0
    //     0xbe3090: add             x1, fp, w0, sxtw #2
    //     0xbe3094: ldr             x1, [x1, #8]
    //     0xbe3098: mov             x0, x1
    //     0xbe309c: b               #0xbe30a4
    //     0xbe30a0: mov             x0, NULL
    // 0xbe30a4: CheckStackOverflow
    //     0xbe30a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe30a8: cmp             SP, x16
    //     0xbe30ac: b.ls            #0xbe3188
    // 0xbe30b0: cmp             w0, NULL
    // 0xbe30b4: b.ne            #0xbe30d0
    // 0xbe30b8: LoadField: r0 = r2->field_1b
    //     0xbe30b8: ldur            w0, [x2, #0x1b]
    // 0xbe30bc: DecompressPointer r0
    //     0xbe30bc: add             x0, x0, HEAP, lsl #32
    // 0xbe30c0: LoadField: r1 = r0->field_13
    //     0xbe30c0: ldur            w1, [x0, #0x13]
    // 0xbe30c4: DecompressPointer r1
    //     0xbe30c4: add             x1, x1, HEAP, lsl #32
    // 0xbe30c8: r0 = LoadInt32Instr(r1)
    //     0xbe30c8: sbfx            x0, x1, #1, #0x1f
    // 0xbe30cc: b               #0xbe30e0
    // 0xbe30d0: r1 = LoadInt32Instr(r0)
    //     0xbe30d0: sbfx            x1, x0, #1, #0x1f
    //     0xbe30d4: tbz             w0, #0, #0xbe30dc
    //     0xbe30d8: ldur            x1, [x0, #7]
    // 0xbe30dc: mov             x0, x1
    // 0xbe30e0: LoadField: r1 = r2->field_b
    //     0xbe30e0: ldur            x1, [x2, #0xb]
    // 0xbe30e4: add             x4, x1, x0
    // 0xbe30e8: stur            x4, [fp, #-8]
    // 0xbe30ec: LoadField: r0 = r2->field_7
    //     0xbe30ec: ldur            w0, [x2, #7]
    // 0xbe30f0: DecompressPointer r0
    //     0xbe30f0: add             x0, x0, HEAP, lsl #32
    // 0xbe30f4: LoadField: r1 = r0->field_13
    //     0xbe30f4: ldur            w1, [x0, #0x13]
    // 0xbe30f8: DecompressPointer r1
    //     0xbe30f8: add             x1, x1, HEAP, lsl #32
    // 0xbe30fc: r0 = LoadInt32Instr(r1)
    //     0xbe30fc: sbfx            x0, x1, #1, #0x1f
    // 0xbe3100: cmp             x4, x0
    // 0xbe3104: b.lt            #0xbe312c
    // 0xbe3108: r0 = BoxInt64Instr(r4)
    //     0xbe3108: sbfiz           x0, x4, #1, #0x1f
    //     0xbe310c: cmp             x4, x0, asr #1
    //     0xbe3110: b.eq            #0xbe311c
    //     0xbe3114: bl              #0xd69bb8
    //     0xbe3118: stur            x4, [x0, #7]
    // 0xbe311c: stp             x0, x2, [SP, #-0x10]!
    // 0xbe3120: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe3120: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe3124: r0 = _resize()
    //     0xbe3124: bl              #0xbe0218  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_resize
    // 0xbe3128: add             SP, SP, #0x10
    // 0xbe312c: ldur            x2, [fp, #-0x18]
    // 0xbe3130: ldur            x3, [fp, #-8]
    // 0xbe3134: LoadField: r4 = r2->field_7
    //     0xbe3134: ldur            w4, [x2, #7]
    // 0xbe3138: DecompressPointer r4
    //     0xbe3138: add             x4, x4, HEAP, lsl #32
    // 0xbe313c: LoadField: r5 = r2->field_b
    //     0xbe313c: ldur            x5, [x2, #0xb]
    // 0xbe3140: r0 = BoxInt64Instr(r5)
    //     0xbe3140: sbfiz           x0, x5, #1, #0x1f
    //     0xbe3144: cmp             x5, x0, asr #1
    //     0xbe3148: b.eq            #0xbe3154
    //     0xbe314c: bl              #0xd69bb8
    //     0xbe3150: stur            x5, [x0, #7]
    // 0xbe3154: stp             x0, x4, [SP, #-0x10]!
    // 0xbe3158: ldur            x16, [fp, #-0x10]
    // 0xbe315c: stp             x16, x3, [SP, #-0x10]!
    // 0xbe3160: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xbe3160: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xbe3164: r0 = setRange()
    //     0xbe3164: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0xbe3168: add             SP, SP, #0x20
    // 0xbe316c: ldur            x1, [fp, #-0x18]
    // 0xbe3170: ldur            x2, [fp, #-8]
    // 0xbe3174: StoreField: r1->field_b = r2
    //     0xbe3174: stur            x2, [x1, #0xb]
    // 0xbe3178: r0 = Null
    //     0xbe3178: mov             x0, NULL
    // 0xbe317c: LeaveFrame
    //     0xbe317c: mov             SP, fp
    //     0xbe3180: ldp             fp, lr, [SP], #0x10
    // 0xbe3184: ret
    //     0xbe3184: ret             
    // 0xbe3188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe3188: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe318c: b               #0xbe30b0
  }
  static Uint8List _zeroBuffer() {
    // ** addr: 0xbe3190, size: 0x1c
    // 0xbe3190: EnterFrame
    //     0xbe3190: stp             fp, lr, [SP, #-0x10]!
    //     0xbe3194: mov             fp, SP
    // 0xbe3198: r4 = 16
    //     0xbe3198: mov             x4, #0x10
    // 0xbe319c: r0 = AllocateUint8Array()
    //     0xbe319c: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0xbe31a0: LeaveFrame
    //     0xbe31a0: mov             SP, fp
    //     0xbe31a4: ldp             fp, lr, [SP], #0x10
    // 0xbe31a8: ret
    //     0xbe31a8: ret             
  }
  _ putInt32List(/* No info */) {
    // ** addr: 0xbe31ac, size: 0xf8
    // 0xbe31ac: EnterFrame
    //     0xbe31ac: stp             fp, lr, [SP, #-0x10]!
    //     0xbe31b0: mov             fp, SP
    // 0xbe31b4: AllocStack(0x8)
    //     0xbe31b4: sub             SP, SP, #8
    // 0xbe31b8: r0 = 4
    //     0xbe31b8: mov             x0, #4
    // 0xbe31bc: CheckStackOverflow
    //     0xbe31bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe31c0: cmp             SP, x16
    //     0xbe31c4: b.ls            #0xbe329c
    // 0xbe31c8: ldr             x16, [fp, #0x18]
    // 0xbe31cc: stp             x0, x16, [SP, #-0x10]!
    // 0xbe31d0: r0 = _alignTo()
    //     0xbe31d0: bl              #0xbe2f74  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_alignTo
    // 0xbe31d4: add             SP, SP, #0x10
    // 0xbe31d8: ldr             x1, [fp, #0x10]
    // 0xbe31dc: r0 = LoadClassIdInstr(r1)
    //     0xbe31dc: ldur            x0, [x1, #-1]
    //     0xbe31e0: ubfx            x0, x0, #0xc, #0x14
    // 0xbe31e4: SaveReg r1
    //     0xbe31e4: str             x1, [SP, #-8]!
    // 0xbe31e8: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xbe31e8: sub             lr, x0, #0xf7e
    //     0xbe31ec: ldr             lr, [x21, lr, lsl #3]
    //     0xbe31f0: blr             lr
    // 0xbe31f4: add             SP, SP, #8
    // 0xbe31f8: mov             x2, x0
    // 0xbe31fc: ldr             x1, [fp, #0x10]
    // 0xbe3200: stur            x2, [fp, #-8]
    // 0xbe3204: r0 = LoadClassIdInstr(r1)
    //     0xbe3204: ldur            x0, [x1, #-1]
    //     0xbe3208: ubfx            x0, x0, #0xc, #0x14
    // 0xbe320c: SaveReg r1
    //     0xbe320c: str             x1, [SP, #-8]!
    // 0xbe3210: r0 = GDT[cid_x0 + -0xef6]()
    //     0xbe3210: sub             lr, x0, #0xef6
    //     0xbe3214: ldr             lr, [x21, lr, lsl #3]
    //     0xbe3218: blr             lr
    // 0xbe321c: add             SP, SP, #8
    // 0xbe3220: mov             x2, x0
    // 0xbe3224: ldr             x0, [fp, #0x10]
    // 0xbe3228: LoadField: r1 = r0->field_13
    //     0xbe3228: ldur            w1, [x0, #0x13]
    // 0xbe322c: DecompressPointer r1
    //     0xbe322c: add             x1, x1, HEAP, lsl #32
    // 0xbe3230: r0 = LoadInt32Instr(r1)
    //     0xbe3230: sbfx            x0, x1, #1, #0x1f
    // 0xbe3234: lsl             x3, x0, #2
    // 0xbe3238: r0 = BoxInt64Instr(r3)
    //     0xbe3238: sbfiz           x0, x3, #1, #0x1f
    //     0xbe323c: cmp             x3, x0, asr #1
    //     0xbe3240: b.eq            #0xbe324c
    //     0xbe3244: bl              #0xd69bb8
    //     0xbe3248: stur            x3, [x0, #7]
    // 0xbe324c: mov             x1, x0
    // 0xbe3250: ldur            x0, [fp, #-8]
    // 0xbe3254: r3 = LoadClassIdInstr(r0)
    //     0xbe3254: ldur            x3, [x0, #-1]
    //     0xbe3258: ubfx            x3, x3, #0xc, #0x14
    // 0xbe325c: stp             x2, x0, [SP, #-0x10]!
    // 0xbe3260: SaveReg r1
    //     0xbe3260: str             x1, [SP, #-8]!
    // 0xbe3264: mov             x0, x3
    // 0xbe3268: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbe3268: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbe326c: r0 = GDT[cid_x0 + -0xffc]()
    //     0xbe326c: sub             lr, x0, #0xffc
    //     0xbe3270: ldr             lr, [x21, lr, lsl #3]
    //     0xbe3274: blr             lr
    // 0xbe3278: add             SP, SP, #0x18
    // 0xbe327c: ldr             x16, [fp, #0x18]
    // 0xbe3280: stp             x0, x16, [SP, #-0x10]!
    // 0xbe3284: r0 = _append()
    //     0xbe3284: bl              #0xbe32a4  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_append
    // 0xbe3288: add             SP, SP, #0x10
    // 0xbe328c: r0 = Null
    //     0xbe328c: mov             x0, NULL
    // 0xbe3290: LeaveFrame
    //     0xbe3290: mov             SP, fp
    //     0xbe3294: ldp             fp, lr, [SP], #0x10
    // 0xbe3298: ret
    //     0xbe3298: ret             
    // 0xbe329c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe329c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe32a0: b               #0xbe31c8
  }
  _ _append(/* No info */) {
    // ** addr: 0xbe32a4, size: 0xec
    // 0xbe32a4: EnterFrame
    //     0xbe32a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbe32a8: mov             fp, SP
    // 0xbe32ac: AllocStack(0x10)
    //     0xbe32ac: sub             SP, SP, #0x10
    // 0xbe32b0: CheckStackOverflow
    //     0xbe32b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe32b4: cmp             SP, x16
    //     0xbe32b8: b.ls            #0xbe3388
    // 0xbe32bc: ldr             x2, [fp, #0x18]
    // 0xbe32c0: LoadField: r0 = r2->field_b
    //     0xbe32c0: ldur            x0, [x2, #0xb]
    // 0xbe32c4: ldr             x3, [fp, #0x10]
    // 0xbe32c8: LoadField: r1 = r3->field_13
    //     0xbe32c8: ldur            w1, [x3, #0x13]
    // 0xbe32cc: DecompressPointer r1
    //     0xbe32cc: add             x1, x1, HEAP, lsl #32
    // 0xbe32d0: r4 = LoadInt32Instr(r1)
    //     0xbe32d0: sbfx            x4, x1, #1, #0x1f
    // 0xbe32d4: stur            x4, [fp, #-0x10]
    // 0xbe32d8: add             x5, x0, x4
    // 0xbe32dc: stur            x5, [fp, #-8]
    // 0xbe32e0: LoadField: r0 = r2->field_7
    //     0xbe32e0: ldur            w0, [x2, #7]
    // 0xbe32e4: DecompressPointer r0
    //     0xbe32e4: add             x0, x0, HEAP, lsl #32
    // 0xbe32e8: LoadField: r1 = r0->field_13
    //     0xbe32e8: ldur            w1, [x0, #0x13]
    // 0xbe32ec: DecompressPointer r1
    //     0xbe32ec: add             x1, x1, HEAP, lsl #32
    // 0xbe32f0: r0 = LoadInt32Instr(r1)
    //     0xbe32f0: sbfx            x0, x1, #1, #0x1f
    // 0xbe32f4: cmp             x5, x0
    // 0xbe32f8: b.lt            #0xbe3320
    // 0xbe32fc: r0 = BoxInt64Instr(r5)
    //     0xbe32fc: sbfiz           x0, x5, #1, #0x1f
    //     0xbe3300: cmp             x5, x0, asr #1
    //     0xbe3304: b.eq            #0xbe3310
    //     0xbe3308: bl              #0xd69bb8
    //     0xbe330c: stur            x5, [x0, #7]
    // 0xbe3310: stp             x0, x2, [SP, #-0x10]!
    // 0xbe3314: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe3314: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe3318: r0 = _resize()
    //     0xbe3318: bl              #0xbe0218  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_resize
    // 0xbe331c: add             SP, SP, #0x10
    // 0xbe3320: ldr             x2, [fp, #0x18]
    // 0xbe3324: ldur            x4, [fp, #-8]
    // 0xbe3328: ldur            x3, [fp, #-0x10]
    // 0xbe332c: LoadField: r5 = r2->field_7
    //     0xbe332c: ldur            w5, [x2, #7]
    // 0xbe3330: DecompressPointer r5
    //     0xbe3330: add             x5, x5, HEAP, lsl #32
    // 0xbe3334: LoadField: r6 = r2->field_b
    //     0xbe3334: ldur            x6, [x2, #0xb]
    // 0xbe3338: r0 = BoxInt64Instr(r6)
    //     0xbe3338: sbfiz           x0, x6, #1, #0x1f
    //     0xbe333c: cmp             x6, x0, asr #1
    //     0xbe3340: b.eq            #0xbe334c
    //     0xbe3344: bl              #0xd69bb8
    //     0xbe3348: stur            x6, [x0, #7]
    // 0xbe334c: stp             x0, x5, [SP, #-0x10]!
    // 0xbe3350: ldr             x16, [fp, #0x10]
    // 0xbe3354: stp             x16, x4, [SP, #-0x10]!
    // 0xbe3358: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xbe3358: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xbe335c: r0 = setRange()
    //     0xbe335c: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0xbe3360: add             SP, SP, #0x20
    // 0xbe3364: ldr             x1, [fp, #0x18]
    // 0xbe3368: LoadField: r2 = r1->field_b
    //     0xbe3368: ldur            x2, [x1, #0xb]
    // 0xbe336c: ldur            x3, [fp, #-0x10]
    // 0xbe3370: add             x4, x2, x3
    // 0xbe3374: StoreField: r1->field_b = r4
    //     0xbe3374: stur            x4, [x1, #0xb]
    // 0xbe3378: r0 = Null
    //     0xbe3378: mov             x0, NULL
    // 0xbe337c: LeaveFrame
    //     0xbe337c: mov             SP, fp
    //     0xbe3380: ldp             fp, lr, [SP], #0x10
    // 0xbe3384: ret
    //     0xbe3384: ret             
    // 0xbe3388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe3388: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe338c: b               #0xbe32bc
  }
  _ putUint32(/* No info */) {
    // ** addr: 0xbe34ec, size: 0xd8
    // 0xbe34ec: EnterFrame
    //     0xbe34ec: stp             fp, lr, [SP, #-0x10]!
    //     0xbe34f0: mov             fp, SP
    // 0xbe34f4: AllocStack(0x10)
    //     0xbe34f4: sub             SP, SP, #0x10
    // 0xbe34f8: CheckStackOverflow
    //     0xbe34f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe34fc: cmp             SP, x16
    //     0xbe3500: b.ls            #0xbe35bc
    // 0xbe3504: ldr             x0, [fp, #0x18]
    // 0xbe3508: LoadField: r1 = r0->field_17
    //     0xbe3508: ldur            w1, [x0, #0x17]
    // 0xbe350c: DecompressPointer r1
    //     0xbe350c: add             x1, x1, HEAP, lsl #32
    // 0xbe3510: LoadField: r2 = r1->field_13
    //     0xbe3510: ldur            w2, [x1, #0x13]
    // 0xbe3514: DecompressPointer r2
    //     0xbe3514: add             x2, x2, HEAP, lsl #32
    // 0xbe3518: r3 = LoadInt32Instr(r2)
    //     0xbe3518: sbfx            x3, x2, #1, #0x1f
    // 0xbe351c: cmp             x3, #3
    // 0xbe3520: b.le            #0xbe357c
    // 0xbe3524: LoadField: r2 = r1->field_17
    //     0xbe3524: ldur            w2, [x1, #0x17]
    // 0xbe3528: DecompressPointer r2
    //     0xbe3528: add             x2, x2, HEAP, lsl #32
    // 0xbe352c: LoadField: r3 = r1->field_1b
    //     0xbe352c: ldur            w3, [x1, #0x1b]
    // 0xbe3530: DecompressPointer r3
    //     0xbe3530: add             x3, x3, HEAP, lsl #32
    // 0xbe3534: ldr             x1, [fp, #0x10]
    // 0xbe3538: ubfx            x1, x1, #0, #0x20
    // 0xbe353c: LoadField: r4 = r2->field_7
    //     0xbe353c: ldur            x4, [x2, #7]
    // 0xbe3540: asr             w2, w3, #1
    // 0xbe3544: add             x2, x4, w2, sxtw
    // 0xbe3548: str             w1, [x2]
    // 0xbe354c: LoadField: r1 = r0->field_1b
    //     0xbe354c: ldur            w1, [x0, #0x1b]
    // 0xbe3550: DecompressPointer r1
    //     0xbe3550: add             x1, x1, HEAP, lsl #32
    // 0xbe3554: stp             x1, x0, [SP, #-0x10]!
    // 0xbe3558: r16 = 8
    //     0xbe3558: mov             x16, #8
    // 0xbe355c: SaveReg r16
    //     0xbe355c: str             x16, [SP, #-8]!
    // 0xbe3560: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbe3560: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbe3564: r0 = _addAll()
    //     0xbe3564: bl              #0xbe3054  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0xbe3568: add             SP, SP, #0x18
    // 0xbe356c: r0 = Null
    //     0xbe356c: mov             x0, NULL
    // 0xbe3570: LeaveFrame
    //     0xbe3570: mov             SP, fp
    //     0xbe3574: ldp             fp, lr, [SP], #0x10
    // 0xbe3578: ret
    //     0xbe3578: ret             
    // 0xbe357c: sub             x0, x3, #4
    // 0xbe3580: lsl             x1, x0, #1
    // 0xbe3584: stur            x1, [fp, #-8]
    // 0xbe3588: r0 = RangeError()
    //     0xbe3588: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xbe358c: stur            x0, [fp, #-0x10]
    // 0xbe3590: stp             xzr, x0, [SP, #-0x10]!
    // 0xbe3594: ldur            x16, [fp, #-8]
    // 0xbe3598: stp             x16, xzr, [SP, #-0x10]!
    // 0xbe359c: r16 = "byteOffset"
    //     0xbe359c: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xbe35a0: SaveReg r16
    //     0xbe35a0: str             x16, [SP, #-8]!
    // 0xbe35a4: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xbe35a4: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xbe35a8: r0 = RangeError.range()
    //     0xbe35a8: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xbe35ac: add             SP, SP, #0x28
    // 0xbe35b0: ldur            x0, [fp, #-0x10]
    // 0xbe35b4: r0 = Throw()
    //     0xbe35b4: bl              #0xd67e38  ; ThrowStub
    // 0xbe35b8: brk             #0
    // 0xbe35bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe35bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe35c0: b               #0xbe3504
  }
  _ putUint16(/* No info */) {
    // ** addr: 0xbe35c4, size: 0xd4
    // 0xbe35c4: EnterFrame
    //     0xbe35c4: stp             fp, lr, [SP, #-0x10]!
    //     0xbe35c8: mov             fp, SP
    // 0xbe35cc: AllocStack(0x10)
    //     0xbe35cc: sub             SP, SP, #0x10
    // 0xbe35d0: CheckStackOverflow
    //     0xbe35d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe35d4: cmp             SP, x16
    //     0xbe35d8: b.ls            #0xbe3690
    // 0xbe35dc: ldr             x0, [fp, #0x18]
    // 0xbe35e0: LoadField: r1 = r0->field_17
    //     0xbe35e0: ldur            w1, [x0, #0x17]
    // 0xbe35e4: DecompressPointer r1
    //     0xbe35e4: add             x1, x1, HEAP, lsl #32
    // 0xbe35e8: LoadField: r2 = r1->field_13
    //     0xbe35e8: ldur            w2, [x1, #0x13]
    // 0xbe35ec: DecompressPointer r2
    //     0xbe35ec: add             x2, x2, HEAP, lsl #32
    // 0xbe35f0: r3 = LoadInt32Instr(r2)
    //     0xbe35f0: sbfx            x3, x2, #1, #0x1f
    // 0xbe35f4: cmp             x3, #1
    // 0xbe35f8: b.le            #0xbe3650
    // 0xbe35fc: ldr             x2, [fp, #0x10]
    // 0xbe3600: LoadField: r3 = r1->field_17
    //     0xbe3600: ldur            w3, [x1, #0x17]
    // 0xbe3604: DecompressPointer r3
    //     0xbe3604: add             x3, x3, HEAP, lsl #32
    // 0xbe3608: LoadField: r4 = r1->field_1b
    //     0xbe3608: ldur            w4, [x1, #0x1b]
    // 0xbe360c: DecompressPointer r4
    //     0xbe360c: add             x4, x4, HEAP, lsl #32
    // 0xbe3610: LoadField: r1 = r3->field_7
    //     0xbe3610: ldur            x1, [x3, #7]
    // 0xbe3614: asr             w3, w4, #1
    // 0xbe3618: add             x3, x1, w3, sxtw
    // 0xbe361c: strh            w2, [x3]
    // 0xbe3620: LoadField: r1 = r0->field_1b
    //     0xbe3620: ldur            w1, [x0, #0x1b]
    // 0xbe3624: DecompressPointer r1
    //     0xbe3624: add             x1, x1, HEAP, lsl #32
    // 0xbe3628: stp             x1, x0, [SP, #-0x10]!
    // 0xbe362c: r16 = 4
    //     0xbe362c: mov             x16, #4
    // 0xbe3630: SaveReg r16
    //     0xbe3630: str             x16, [SP, #-8]!
    // 0xbe3634: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbe3634: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbe3638: r0 = _addAll()
    //     0xbe3638: bl              #0xbe3054  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0xbe363c: add             SP, SP, #0x18
    // 0xbe3640: r0 = Null
    //     0xbe3640: mov             x0, NULL
    // 0xbe3644: LeaveFrame
    //     0xbe3644: mov             SP, fp
    //     0xbe3648: ldp             fp, lr, [SP], #0x10
    // 0xbe364c: ret
    //     0xbe364c: ret             
    // 0xbe3650: sub             x0, x3, #2
    // 0xbe3654: lsl             x1, x0, #1
    // 0xbe3658: stur            x1, [fp, #-8]
    // 0xbe365c: r0 = RangeError()
    //     0xbe365c: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xbe3660: stur            x0, [fp, #-0x10]
    // 0xbe3664: stp             xzr, x0, [SP, #-0x10]!
    // 0xbe3668: ldur            x16, [fp, #-8]
    // 0xbe366c: stp             x16, xzr, [SP, #-0x10]!
    // 0xbe3670: r16 = "byteOffset"
    //     0xbe3670: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xbe3674: SaveReg r16
    //     0xbe3674: str             x16, [SP, #-8]!
    // 0xbe3678: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xbe3678: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xbe367c: r0 = RangeError.range()
    //     0xbe367c: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xbe3680: add             SP, SP, #0x28
    // 0xbe3684: ldur            x0, [fp, #-0x10]
    // 0xbe3688: r0 = Throw()
    //     0xbe3688: bl              #0xd67e38  ; ThrowStub
    // 0xbe368c: brk             #0
    // 0xbe3690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe3690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe3694: b               #0xbe35dc
  }
  _ putInt64(/* No info */) {
    // ** addr: 0xbe3698, size: 0xd4
    // 0xbe3698: EnterFrame
    //     0xbe3698: stp             fp, lr, [SP, #-0x10]!
    //     0xbe369c: mov             fp, SP
    // 0xbe36a0: AllocStack(0x10)
    //     0xbe36a0: sub             SP, SP, #0x10
    // 0xbe36a4: CheckStackOverflow
    //     0xbe36a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe36a8: cmp             SP, x16
    //     0xbe36ac: b.ls            #0xbe3764
    // 0xbe36b0: ldr             x0, [fp, #0x18]
    // 0xbe36b4: LoadField: r1 = r0->field_17
    //     0xbe36b4: ldur            w1, [x0, #0x17]
    // 0xbe36b8: DecompressPointer r1
    //     0xbe36b8: add             x1, x1, HEAP, lsl #32
    // 0xbe36bc: LoadField: r2 = r1->field_13
    //     0xbe36bc: ldur            w2, [x1, #0x13]
    // 0xbe36c0: DecompressPointer r2
    //     0xbe36c0: add             x2, x2, HEAP, lsl #32
    // 0xbe36c4: r3 = LoadInt32Instr(r2)
    //     0xbe36c4: sbfx            x3, x2, #1, #0x1f
    // 0xbe36c8: cmp             x3, #7
    // 0xbe36cc: b.le            #0xbe3724
    // 0xbe36d0: ldr             x2, [fp, #0x10]
    // 0xbe36d4: LoadField: r3 = r1->field_17
    //     0xbe36d4: ldur            w3, [x1, #0x17]
    // 0xbe36d8: DecompressPointer r3
    //     0xbe36d8: add             x3, x3, HEAP, lsl #32
    // 0xbe36dc: LoadField: r4 = r1->field_1b
    //     0xbe36dc: ldur            w4, [x1, #0x1b]
    // 0xbe36e0: DecompressPointer r4
    //     0xbe36e0: add             x4, x4, HEAP, lsl #32
    // 0xbe36e4: LoadField: r1 = r3->field_7
    //     0xbe36e4: ldur            x1, [x3, #7]
    // 0xbe36e8: asr             w3, w4, #1
    // 0xbe36ec: add             x3, x1, w3, sxtw
    // 0xbe36f0: str             x2, [x3]
    // 0xbe36f4: LoadField: r1 = r0->field_1b
    //     0xbe36f4: ldur            w1, [x0, #0x1b]
    // 0xbe36f8: DecompressPointer r1
    //     0xbe36f8: add             x1, x1, HEAP, lsl #32
    // 0xbe36fc: stp             x1, x0, [SP, #-0x10]!
    // 0xbe3700: r16 = 16
    //     0xbe3700: mov             x16, #0x10
    // 0xbe3704: SaveReg r16
    //     0xbe3704: str             x16, [SP, #-8]!
    // 0xbe3708: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbe3708: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbe370c: r0 = _addAll()
    //     0xbe370c: bl              #0xbe3054  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0xbe3710: add             SP, SP, #0x18
    // 0xbe3714: r0 = Null
    //     0xbe3714: mov             x0, NULL
    // 0xbe3718: LeaveFrame
    //     0xbe3718: mov             SP, fp
    //     0xbe371c: ldp             fp, lr, [SP], #0x10
    // 0xbe3720: ret
    //     0xbe3720: ret             
    // 0xbe3724: sub             x0, x3, #8
    // 0xbe3728: lsl             x1, x0, #1
    // 0xbe372c: stur            x1, [fp, #-8]
    // 0xbe3730: r0 = RangeError()
    //     0xbe3730: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xbe3734: stur            x0, [fp, #-0x10]
    // 0xbe3738: stp             xzr, x0, [SP, #-0x10]!
    // 0xbe373c: ldur            x16, [fp, #-8]
    // 0xbe3740: stp             x16, xzr, [SP, #-0x10]!
    // 0xbe3744: r16 = "byteOffset"
    //     0xbe3744: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xbe3748: SaveReg r16
    //     0xbe3748: str             x16, [SP, #-8]!
    // 0xbe374c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xbe374c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xbe3750: r0 = RangeError.range()
    //     0xbe3750: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xbe3754: add             SP, SP, #0x28
    // 0xbe3758: ldur            x0, [fp, #-0x10]
    // 0xbe375c: r0 = Throw()
    //     0xbe375c: bl              #0xd67e38  ; ThrowStub
    // 0xbe3760: brk             #0
    // 0xbe3764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe3764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe3768: b               #0xbe36b0
  }
  _ putInt32(/* No info */) {
    // ** addr: 0xbe376c, size: 0xd8
    // 0xbe376c: EnterFrame
    //     0xbe376c: stp             fp, lr, [SP, #-0x10]!
    //     0xbe3770: mov             fp, SP
    // 0xbe3774: AllocStack(0x10)
    //     0xbe3774: sub             SP, SP, #0x10
    // 0xbe3778: CheckStackOverflow
    //     0xbe3778: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe377c: cmp             SP, x16
    //     0xbe3780: b.ls            #0xbe383c
    // 0xbe3784: ldr             x0, [fp, #0x18]
    // 0xbe3788: LoadField: r1 = r0->field_17
    //     0xbe3788: ldur            w1, [x0, #0x17]
    // 0xbe378c: DecompressPointer r1
    //     0xbe378c: add             x1, x1, HEAP, lsl #32
    // 0xbe3790: LoadField: r2 = r1->field_13
    //     0xbe3790: ldur            w2, [x1, #0x13]
    // 0xbe3794: DecompressPointer r2
    //     0xbe3794: add             x2, x2, HEAP, lsl #32
    // 0xbe3798: r3 = LoadInt32Instr(r2)
    //     0xbe3798: sbfx            x3, x2, #1, #0x1f
    // 0xbe379c: cmp             x3, #3
    // 0xbe37a0: b.le            #0xbe37fc
    // 0xbe37a4: LoadField: r2 = r1->field_17
    //     0xbe37a4: ldur            w2, [x1, #0x17]
    // 0xbe37a8: DecompressPointer r2
    //     0xbe37a8: add             x2, x2, HEAP, lsl #32
    // 0xbe37ac: LoadField: r3 = r1->field_1b
    //     0xbe37ac: ldur            w3, [x1, #0x1b]
    // 0xbe37b0: DecompressPointer r3
    //     0xbe37b0: add             x3, x3, HEAP, lsl #32
    // 0xbe37b4: ldr             x1, [fp, #0x10]
    // 0xbe37b8: sxtw            x1, w1
    // 0xbe37bc: LoadField: r4 = r2->field_7
    //     0xbe37bc: ldur            x4, [x2, #7]
    // 0xbe37c0: asr             w2, w3, #1
    // 0xbe37c4: add             x2, x4, w2, sxtw
    // 0xbe37c8: str             w1, [x2]
    // 0xbe37cc: LoadField: r1 = r0->field_1b
    //     0xbe37cc: ldur            w1, [x0, #0x1b]
    // 0xbe37d0: DecompressPointer r1
    //     0xbe37d0: add             x1, x1, HEAP, lsl #32
    // 0xbe37d4: stp             x1, x0, [SP, #-0x10]!
    // 0xbe37d8: r16 = 8
    //     0xbe37d8: mov             x16, #8
    // 0xbe37dc: SaveReg r16
    //     0xbe37dc: str             x16, [SP, #-8]!
    // 0xbe37e0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbe37e0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbe37e4: r0 = _addAll()
    //     0xbe37e4: bl              #0xbe3054  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0xbe37e8: add             SP, SP, #0x18
    // 0xbe37ec: r0 = Null
    //     0xbe37ec: mov             x0, NULL
    // 0xbe37f0: LeaveFrame
    //     0xbe37f0: mov             SP, fp
    //     0xbe37f4: ldp             fp, lr, [SP], #0x10
    // 0xbe37f8: ret
    //     0xbe37f8: ret             
    // 0xbe37fc: sub             x0, x3, #4
    // 0xbe3800: lsl             x1, x0, #1
    // 0xbe3804: stur            x1, [fp, #-8]
    // 0xbe3808: r0 = RangeError()
    //     0xbe3808: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xbe380c: stur            x0, [fp, #-0x10]
    // 0xbe3810: stp             xzr, x0, [SP, #-0x10]!
    // 0xbe3814: ldur            x16, [fp, #-8]
    // 0xbe3818: stp             x16, xzr, [SP, #-0x10]!
    // 0xbe381c: r16 = "byteOffset"
    //     0xbe381c: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xbe3820: SaveReg r16
    //     0xbe3820: str             x16, [SP, #-8]!
    // 0xbe3824: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xbe3824: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xbe3828: r0 = RangeError.range()
    //     0xbe3828: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xbe382c: add             SP, SP, #0x28
    // 0xbe3830: ldur            x0, [fp, #-0x10]
    // 0xbe3834: r0 = Throw()
    //     0xbe3834: bl              #0xd67e38  ; ThrowStub
    // 0xbe3838: brk             #0
    // 0xbe383c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe383c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe3840: b               #0xbe3784
  }
  _ putFloat64(/* No info */) {
    // ** addr: 0xbe3844, size: 0xe0
    // 0xbe3844: EnterFrame
    //     0xbe3844: stp             fp, lr, [SP, #-0x10]!
    //     0xbe3848: mov             fp, SP
    // 0xbe384c: AllocStack(0x10)
    //     0xbe384c: sub             SP, SP, #0x10
    // 0xbe3850: r0 = 8
    //     0xbe3850: mov             x0, #8
    // 0xbe3854: CheckStackOverflow
    //     0xbe3854: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe3858: cmp             SP, x16
    //     0xbe385c: b.ls            #0xbe391c
    // 0xbe3860: ldr             x16, [fp, #0x18]
    // 0xbe3864: stp             x0, x16, [SP, #-0x10]!
    // 0xbe3868: r0 = _alignTo()
    //     0xbe3868: bl              #0xbe2f74  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_alignTo
    // 0xbe386c: add             SP, SP, #0x10
    // 0xbe3870: ldr             x0, [fp, #0x18]
    // 0xbe3874: LoadField: r1 = r0->field_17
    //     0xbe3874: ldur            w1, [x0, #0x17]
    // 0xbe3878: DecompressPointer r1
    //     0xbe3878: add             x1, x1, HEAP, lsl #32
    // 0xbe387c: LoadField: r2 = r1->field_13
    //     0xbe387c: ldur            w2, [x1, #0x13]
    // 0xbe3880: DecompressPointer r2
    //     0xbe3880: add             x2, x2, HEAP, lsl #32
    // 0xbe3884: r3 = LoadInt32Instr(r2)
    //     0xbe3884: sbfx            x3, x2, #1, #0x1f
    // 0xbe3888: cmp             x3, #7
    // 0xbe388c: b.le            #0xbe38dc
    // 0xbe3890: ldr             d0, [fp, #0x10]
    // 0xbe3894: LoadField: r2 = r1->field_17
    //     0xbe3894: ldur            w2, [x1, #0x17]
    // 0xbe3898: DecompressPointer r2
    //     0xbe3898: add             x2, x2, HEAP, lsl #32
    // 0xbe389c: LoadField: r3 = r1->field_1b
    //     0xbe389c: ldur            w3, [x1, #0x1b]
    // 0xbe38a0: DecompressPointer r3
    //     0xbe38a0: add             x3, x3, HEAP, lsl #32
    // 0xbe38a4: LoadField: r1 = r2->field_7
    //     0xbe38a4: ldur            x1, [x2, #7]
    // 0xbe38a8: asr             w2, w3, #1
    // 0xbe38ac: add             x2, x1, w2, sxtw
    // 0xbe38b0: str             d0, [x2]
    // 0xbe38b4: LoadField: r1 = r0->field_1b
    //     0xbe38b4: ldur            w1, [x0, #0x1b]
    // 0xbe38b8: DecompressPointer r1
    //     0xbe38b8: add             x1, x1, HEAP, lsl #32
    // 0xbe38bc: stp             x1, x0, [SP, #-0x10]!
    // 0xbe38c0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe38c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe38c4: r0 = _addAll()
    //     0xbe38c4: bl              #0xbe3054  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_addAll
    // 0xbe38c8: add             SP, SP, #0x10
    // 0xbe38cc: r0 = Null
    //     0xbe38cc: mov             x0, NULL
    // 0xbe38d0: LeaveFrame
    //     0xbe38d0: mov             SP, fp
    //     0xbe38d4: ldp             fp, lr, [SP], #0x10
    // 0xbe38d8: ret
    //     0xbe38d8: ret             
    // 0xbe38dc: sub             x0, x3, #8
    // 0xbe38e0: lsl             x1, x0, #1
    // 0xbe38e4: stur            x1, [fp, #-8]
    // 0xbe38e8: r0 = RangeError()
    //     0xbe38e8: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xbe38ec: stur            x0, [fp, #-0x10]
    // 0xbe38f0: stp             xzr, x0, [SP, #-0x10]!
    // 0xbe38f4: ldur            x16, [fp, #-8]
    // 0xbe38f8: stp             x16, xzr, [SP, #-0x10]!
    // 0xbe38fc: r16 = "byteOffset"
    //     0xbe38fc: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xbe3900: SaveReg r16
    //     0xbe3900: str             x16, [SP, #-8]!
    // 0xbe3904: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xbe3904: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xbe3908: r0 = RangeError.range()
    //     0xbe3908: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xbe390c: add             SP, SP, #0x28
    // 0xbe3910: ldur            x0, [fp, #-0x10]
    // 0xbe3914: r0 = Throw()
    //     0xbe3914: bl              #0xd67e38  ; ThrowStub
    // 0xbe3918: brk             #0
    // 0xbe391c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe391c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe3920: b               #0xbe3860
  }
}

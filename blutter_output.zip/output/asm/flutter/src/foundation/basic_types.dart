// lib: , url: package:flutter/src/foundation/basic_types.dart

// class id: 1049124, size: 0x8
class :: {
}

// class id: 2653, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Factory<X0> extends Object {
}

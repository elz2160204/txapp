// lib: , url: package:flutter/src/foundation/_platform_io.dart

// class id: 1049121, size: 0x8
class :: {

  get _ defaultTargetPlatform(/* No info */) {
    // ** addr: 0x59ed88, size: 0x190
    // 0x59ed88: EnterFrame
    //     0x59ed88: stp             fp, lr, [SP, #-0x10]!
    //     0x59ed8c: mov             fp, SP
    // 0x59ed90: AllocStack(0x8)
    //     0x59ed90: sub             SP, SP, #8
    // 0x59ed94: CheckStackOverflow
    //     0x59ed94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59ed98: cmp             SP, x16
    //     0x59ed9c: b.ls            #0x59ef10
    // 0x59eda0: r0 = InitLateStaticField(0x698) // [dart:io] Platform::isAndroid
    //     0x59eda0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x59eda4: ldr             x0, [x0, #0xd30]
    //     0x59eda8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x59edac: cmp             w0, w16
    //     0x59edb0: b.ne            #0x59edbc
    //     0x59edb4: ldr             x2, [PP, #0x60]  ; [pp+0x60] Field <Platform.isAndroid>: static late final (offset: 0x698)
    //     0x59edb8: bl              #0xd67cdc
    // 0x59edbc: tbnz            w0, #4, #0x59edc8
    // 0x59edc0: r0 = Instance_TargetPlatform
    //     0x59edc0: ldr             x0, [PP, #0x43a8]  ; [pp+0x43a8] Obj!TargetPlatform@b65d71
    // 0x59edc4: b               #0x59ee94
    // 0x59edc8: r0 = InitLateStaticField(0x69c) // [dart:io] Platform::isIOS
    //     0x59edc8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x59edcc: ldr             x0, [x0, #0xd38]
    //     0x59edd0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x59edd4: cmp             w0, w16
    //     0x59edd8: b.ne            #0x59ede4
    //     0x59eddc: ldr             x2, [PP, #0x68]  ; [pp+0x68] Field <Platform.isIOS>: static late final (offset: 0x69c)
    //     0x59ede0: bl              #0xd67cdc
    // 0x59ede4: tbnz            w0, #4, #0x59edf0
    // 0x59ede8: r0 = Instance_TargetPlatform
    //     0x59ede8: ldr             x0, [PP, #0x43b0]  ; [pp+0x43b0] Obj!TargetPlatform@b65d51
    // 0x59edec: b               #0x59ee94
    // 0x59edf0: r0 = InitLateStaticField(0x6a0) // [dart:io] Platform::isFuchsia
    //     0x59edf0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x59edf4: ldr             x0, [x0, #0xd40]
    //     0x59edf8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x59edfc: cmp             w0, w16
    //     0x59ee00: b.ne            #0x59ee0c
    //     0x59ee04: ldr             x2, [PP, #0x43b8]  ; [pp+0x43b8] Field <Platform.isFuchsia>: static late final (offset: 0x6a0)
    //     0x59ee08: bl              #0xd67cdc
    // 0x59ee0c: tbnz            w0, #4, #0x59ee18
    // 0x59ee10: r0 = Instance_TargetPlatform
    //     0x59ee10: ldr             x0, [PP, #0x43c0]  ; [pp+0x43c0] Obj!TargetPlatform@b65d31
    // 0x59ee14: b               #0x59ee94
    // 0x59ee18: r0 = InitLateStaticField(0x68c) // [dart:io] Platform::isLinux
    //     0x59ee18: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x59ee1c: ldr             x0, [x0, #0xd18]
    //     0x59ee20: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x59ee24: cmp             w0, w16
    //     0x59ee28: b.ne            #0x59ee34
    //     0x59ee2c: ldr             x2, [PP, #0x70]  ; [pp+0x70] Field <Platform.isLinux>: static late final (offset: 0x68c)
    //     0x59ee30: bl              #0xd67cdc
    // 0x59ee34: tbnz            w0, #4, #0x59ee40
    // 0x59ee38: r0 = Instance_TargetPlatform
    //     0x59ee38: ldr             x0, [PP, #0x43c8]  ; [pp+0x43c8] Obj!TargetPlatform@b65d11
    // 0x59ee3c: b               #0x59ee94
    // 0x59ee40: r0 = InitLateStaticField(0x690) // [dart:io] Platform::isMacOS
    //     0x59ee40: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x59ee44: ldr             x0, [x0, #0xd20]
    //     0x59ee48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x59ee4c: cmp             w0, w16
    //     0x59ee50: b.ne            #0x59ee5c
    //     0x59ee54: ldr             x2, [PP, #0x78]  ; [pp+0x78] Field <Platform.isMacOS>: static late final (offset: 0x690)
    //     0x59ee58: bl              #0xd67cdc
    // 0x59ee5c: tbnz            w0, #4, #0x59ee68
    // 0x59ee60: r0 = Instance_TargetPlatform
    //     0x59ee60: ldr             x0, [PP, #0x43d0]  ; [pp+0x43d0] Obj!TargetPlatform@b65cf1
    // 0x59ee64: b               #0x59ee94
    // 0x59ee68: r0 = InitLateStaticField(0x694) // [dart:io] Platform::isWindows
    //     0x59ee68: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x59ee6c: ldr             x0, [x0, #0xd28]
    //     0x59ee70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x59ee74: cmp             w0, w16
    //     0x59ee78: b.ne            #0x59ee84
    //     0x59ee7c: ldr             x2, [PP, #0x80]  ; [pp+0x80] Field <Platform.isWindows>: static late final (offset: 0x694)
    //     0x59ee80: bl              #0xd67cdc
    // 0x59ee84: tbnz            w0, #4, #0x59ee90
    // 0x59ee88: r0 = Instance_TargetPlatform
    //     0x59ee88: ldr             x0, [PP, #0x43d8]  ; [pp+0x43d8] Obj!TargetPlatform@b65cd1
    // 0x59ee8c: b               #0x59ee94
    // 0x59ee90: r0 = Null
    //     0x59ee90: mov             x0, NULL
    // 0x59ee94: cmp             w0, NULL
    // 0x59ee98: b.eq            #0x59eea8
    // 0x59ee9c: LeaveFrame
    //     0x59ee9c: mov             SP, fp
    //     0x59eea0: ldp             fp, lr, [SP], #0x10
    // 0x59eea4: ret
    //     0x59eea4: ret             
    // 0x59eea8: r1 = Null
    //     0x59eea8: mov             x1, NULL
    // 0x59eeac: r2 = 6
    //     0x59eeac: mov             x2, #6
    // 0x59eeb0: r0 = AllocateArray()
    //     0x59eeb0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x59eeb4: stur            x0, [fp, #-8]
    // 0x59eeb8: r17 = "Unknown platform.\n"
    //     0x59eeb8: ldr             x17, [PP, #0x43e0]  ; [pp+0x43e0] "Unknown platform.\n"
    // 0x59eebc: StoreField: r0->field_f = r17
    //     0x59eebc: stur            w17, [x0, #0xf]
    // 0x59eec0: r0 = InitLateStaticField(0x67c) // [dart:io] Platform::_operatingSystem
    //     0x59eec0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x59eec4: ldr             x0, [x0, #0xcf8]
    //     0x59eec8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x59eecc: cmp             w0, w16
    //     0x59eed0: b.ne            #0x59eedc
    //     0x59eed4: ldr             x2, [PP, #0x1400]  ; [pp+0x1400] Field <Platform._operatingSystem@14069316>: static late final (offset: 0x67c)
    //     0x59eed8: bl              #0xd67cdc
    // 0x59eedc: mov             x1, x0
    // 0x59eee0: ldur            x0, [fp, #-8]
    // 0x59eee4: StoreField: r0->field_13 = r1
    //     0x59eee4: stur            w1, [x0, #0x13]
    // 0x59eee8: r17 = " was not recognized as a target platform. Consider updating the list of TargetPlatforms to include this platform."
    //     0x59eee8: ldr             x17, [PP, #0x43e8]  ; [pp+0x43e8] " was not recognized as a target platform. Consider updating the list of TargetPlatforms to include this platform."
    // 0x59eeec: StoreField: r0->field_17 = r17
    //     0x59eeec: stur            w17, [x0, #0x17]
    // 0x59eef0: SaveReg r0
    //     0x59eef0: str             x0, [SP, #-8]!
    // 0x59eef4: r0 = _interpolate()
    //     0x59eef4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x59eef8: add             SP, SP, #8
    // 0x59eefc: stp             x0, NULL, [SP, #-0x10]!
    // 0x59ef00: r0 = FlutterError()
    //     0x59ef00: bl              #0x59ef18  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0x59ef04: add             SP, SP, #0x10
    // 0x59ef08: r0 = Throw()
    //     0x59ef08: bl              #0xd67e38  ; ThrowStub
    // 0x59ef0c: brk             #0
    // 0x59ef10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59ef10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59ef14: b               #0x59eda0
  }
}

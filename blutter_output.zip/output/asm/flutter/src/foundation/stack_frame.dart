// lib: , url: package:flutter/src/foundation/stack_frame.dart

// class id: 1049146, size: 0x8
class :: {
}

// class id: 2369, size: 0x3c, field offset: 0x8
//   const constructor, 
class StackFrame extends Object {

  _OneByteString field_8;
  _Mint field_c;
  _OneByteString field_14;
  _OneByteString field_18;
  _OneByteString field_1c;
  _Mint field_20;
  _Mint field_28;
  _OneByteString field_30;
  _OneByteString field_34;
  bool field_38;
  static late final RegExp _webNonDebugFramePattern; // offset: 0xd4c

  static _ fromStackString(/* No info */) {
    // ** addr: 0x4fe5b0, size: 0xc0
    // 0x4fe5b0: EnterFrame
    //     0x4fe5b0: stp             fp, lr, [SP, #-0x10]!
    //     0x4fe5b4: mov             fp, SP
    // 0x4fe5b8: AllocStack(0x8)
    //     0x4fe5b8: sub             SP, SP, #8
    // 0x4fe5bc: CheckStackOverflow
    //     0x4fe5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fe5c0: cmp             SP, x16
    //     0x4fe5c4: b.ls            #0x4fe668
    // 0x4fe5c8: ldr             x16, [fp, #0x10]
    // 0x4fe5cc: SaveReg r16
    //     0x4fe5cc: str             x16, [SP, #-8]!
    // 0x4fe5d0: r0 = trim()
    //     0x4fe5d0: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x4fe5d4: add             SP, SP, #8
    // 0x4fe5d8: r1 = LoadClassIdInstr(r0)
    //     0x4fe5d8: ldur            x1, [x0, #-1]
    //     0x4fe5dc: ubfx            x1, x1, #0xc, #0x14
    // 0x4fe5e0: r16 = "\n"
    //     0x4fe5e0: ldr             x16, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0x4fe5e4: stp             x16, x0, [SP, #-0x10]!
    // 0x4fe5e8: mov             x0, x1
    // 0x4fe5ec: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4fe5ec: sub             lr, x0, #0xff8
    //     0x4fe5f0: ldr             lr, [x21, lr, lsl #3]
    //     0x4fe5f4: blr             lr
    // 0x4fe5f8: add             SP, SP, #0x10
    // 0x4fe5fc: r1 = Function '<anonymous closure>': static.
    //     0x4fe5fc: ldr             x1, [PP, #0x1188]  ; [pp+0x1188] AnonymousClosure: static (0x4ff320), in [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackString (0x4fe5b0)
    // 0x4fe600: r2 = Null
    //     0x4fe600: mov             x2, NULL
    // 0x4fe604: stur            x0, [fp, #-8]
    // 0x4fe608: r0 = AllocateClosure()
    //     0x4fe608: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x4fe60c: ldur            x16, [fp, #-8]
    // 0x4fe610: stp             x0, x16, [SP, #-0x10]!
    // 0x4fe614: r0 = where()
    //     0x4fe614: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0x4fe618: add             SP, SP, #0x10
    // 0x4fe61c: r16 = <StackFrame?>
    //     0x4fe61c: ldr             x16, [PP, #0x1190]  ; [pp+0x1190] TypeArguments: <StackFrame?>
    // 0x4fe620: stp             x0, x16, [SP, #-0x10]!
    // 0x4fe624: r16 = Closure: (String) => StackFrame? from Function 'fromStackTraceLine': static.
    //     0x4fe624: ldr             x16, [PP, #0x1198]  ; [pp+0x1198] Closure: (String) => StackFrame? from Function 'fromStackTraceLine': static. (0x7fe6e1cfe670)
    // 0x4fe628: SaveReg r16
    //     0x4fe628: str             x16, [SP, #-8]!
    // 0x4fe62c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x4fe62c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x4fe630: r0 = map()
    //     0x4fe630: bl              #0x6ba568  ; [dart:_internal] WhereIterable::map
    // 0x4fe634: add             SP, SP, #0x18
    // 0x4fe638: r16 = <StackFrame>
    //     0x4fe638: ldr             x16, [PP, #0x11a0]  ; [pp+0x11a0] TypeArguments: <StackFrame>
    // 0x4fe63c: stp             x0, x16, [SP, #-0x10]!
    // 0x4fe640: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x4fe640: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x4fe644: r0 = whereType()
    //     0x4fe644: bl              #0x6a7924  ; [dart:collection] _ListBase&Object&ListMixin::whereType
    // 0x4fe648: add             SP, SP, #0x10
    // 0x4fe64c: SaveReg r0
    //     0x4fe64c: str             x0, [SP, #-8]!
    // 0x4fe650: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fe650: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fe654: r0 = toList()
    //     0x4fe654: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x4fe658: add             SP, SP, #8
    // 0x4fe65c: LeaveFrame
    //     0x4fe65c: mov             SP, fp
    //     0x4fe660: ldp             fp, lr, [SP], #0x10
    // 0x4fe664: ret
    //     0x4fe664: ret             
    // 0x4fe668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe66c: b               #0x4fe5c8
  }
  [closure] static StackFrame? fromStackTraceLine(dynamic, String) {
    // ** addr: 0x4fe670, size: 0x38
    // 0x4fe670: EnterFrame
    //     0x4fe670: stp             fp, lr, [SP, #-0x10]!
    //     0x4fe674: mov             fp, SP
    // 0x4fe678: CheckStackOverflow
    //     0x4fe678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fe67c: cmp             SP, x16
    //     0x4fe680: b.ls            #0x4fe6a0
    // 0x4fe684: ldr             x16, [fp, #0x10]
    // 0x4fe688: SaveReg r16
    //     0x4fe688: str             x16, [SP, #-8]!
    // 0x4fe68c: r0 = fromStackTraceLine()
    //     0x4fe68c: bl              #0x4fe6a8  ; [package:flutter/src/foundation/stack_frame.dart] StackFrame::fromStackTraceLine
    // 0x4fe690: add             SP, SP, #8
    // 0x4fe694: LeaveFrame
    //     0x4fe694: mov             SP, fp
    //     0x4fe698: ldp             fp, lr, [SP], #0x10
    // 0x4fe69c: ret
    //     0x4fe69c: ret             
    // 0x4fe6a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4fe6a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4fe6a4: b               #0x4fe684
  }
  static _ fromStackTraceLine(/* No info */) {
    // ** addr: 0x4fe6a8, size: 0x734
    // 0x4fe6a8: EnterFrame
    //     0x4fe6a8: stp             fp, lr, [SP, #-0x10]!
    //     0x4fe6ac: mov             fp, SP
    // 0x4fe6b0: AllocStack(0x60)
    //     0x4fe6b0: sub             SP, SP, #0x60
    // 0x4fe6b4: CheckStackOverflow
    //     0x4fe6b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4fe6b8: cmp             SP, x16
    //     0x4fe6bc: b.ls            #0x4feda0
    // 0x4fe6c0: ldr             x1, [fp, #0x10]
    // 0x4fe6c4: r0 = LoadClassIdInstr(r1)
    //     0x4fe6c4: ldur            x0, [x1, #-1]
    //     0x4fe6c8: ubfx            x0, x0, #0xc, #0x14
    // 0x4fe6cc: r16 = "<asynchronous suspension>"
    //     0x4fe6cc: ldr             x16, [PP, #0x11a8]  ; [pp+0x11a8] "<asynchronous suspension>"
    // 0x4fe6d0: stp             x16, x1, [SP, #-0x10]!
    // 0x4fe6d4: mov             lr, x0
    // 0x4fe6d8: ldr             lr, [x21, lr, lsl #3]
    // 0x4fe6dc: blr             lr
    // 0x4fe6e0: add             SP, SP, #0x10
    // 0x4fe6e4: tbnz            w0, #4, #0x4fe6f8
    // 0x4fe6e8: r0 = Instance_StackFrame
    //     0x4fe6e8: ldr             x0, [PP, #0x11b0]  ; [pp+0x11b0] Obj!StackFrame@b38791
    // 0x4fe6ec: LeaveFrame
    //     0x4fe6ec: mov             SP, fp
    //     0x4fe6f0: ldp             fp, lr, [SP], #0x10
    // 0x4fe6f4: ret
    //     0x4fe6f4: ret             
    // 0x4fe6f8: ldr             x1, [fp, #0x10]
    // 0x4fe6fc: r0 = LoadClassIdInstr(r1)
    //     0x4fe6fc: ldur            x0, [x1, #-1]
    //     0x4fe700: ubfx            x0, x0, #0xc, #0x14
    // 0x4fe704: r16 = "..."
    //     0x4fe704: ldr             x16, [PP, #0x11b8]  ; [pp+0x11b8] "..."
    // 0x4fe708: stp             x16, x1, [SP, #-0x10]!
    // 0x4fe70c: mov             lr, x0
    // 0x4fe710: ldr             lr, [x21, lr, lsl #3]
    // 0x4fe714: blr             lr
    // 0x4fe718: add             SP, SP, #0x10
    // 0x4fe71c: tbnz            w0, #4, #0x4fe730
    // 0x4fe720: r0 = Instance_StackFrame
    //     0x4fe720: ldr             x0, [PP, #0x11c0]  ; [pp+0x11c0] Obj!StackFrame@b38751
    // 0x4fe724: LeaveFrame
    //     0x4fe724: mov             SP, fp
    //     0x4fe728: ldp             fp, lr, [SP], #0x10
    // 0x4fe72c: ret
    //     0x4fe72c: ret             
    // 0x4fe730: ldr             x16, [fp, #0x10]
    // 0x4fe734: r30 = "#"
    //     0x4fe734: ldr             lr, [PP, #0x11c8]  ; [pp+0x11c8] "#"
    // 0x4fe738: stp             lr, x16, [SP, #-0x10]!
    // 0x4fe73c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fe73c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fe740: r0 = startsWith()
    //     0x4fe740: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x4fe744: add             SP, SP, #0x10
    // 0x4fe748: tbz             w0, #4, #0x4fe768
    // 0x4fe74c: ldr             x16, [fp, #0x10]
    // 0x4fe750: SaveReg r16
    //     0x4fe750: str             x16, [SP, #-8]!
    // 0x4fe754: r0 = _parseWebNonDebugFrame()
    //     0x4fe754: bl              #0x4ff15c  ; [package:flutter/src/foundation/stack_frame.dart] StackFrame::_parseWebNonDebugFrame
    // 0x4fe758: add             SP, SP, #8
    // 0x4fe75c: LeaveFrame
    //     0x4fe75c: mov             SP, fp
    //     0x4fe760: ldp             fp, lr, [SP], #0x10
    // 0x4fe764: ret
    //     0x4fe764: ret             
    // 0x4fe768: r16 = "^#(\\d+) +(.+) \\((.+\?):\?(\\d+){0,1}:\?(\\d+){0,1}\\)$"
    //     0x4fe768: ldr             x16, [PP, #0x11d0]  ; [pp+0x11d0] "^#(\\d+) +(.+) \\((.+\?):\?(\\d+){0,1}:\?(\\d+){0,1}\\)$"
    // 0x4fe76c: stp             x16, NULL, [SP, #-0x10]!
    // 0x4fe770: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fe770: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fe774: r0 = RegExp()
    //     0x4fe774: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0x4fe778: add             SP, SP, #0x10
    // 0x4fe77c: ldr             x16, [fp, #0x10]
    // 0x4fe780: stp             x16, x0, [SP, #-0x10]!
    // 0x4fe784: r0 = firstMatch()
    //     0x4fe784: bl              #0x4fef70  ; [dart:core] _RegExp::firstMatch
    // 0x4fe788: add             SP, SP, #0x10
    // 0x4fe78c: stur            x0, [fp, #-8]
    // 0x4fe790: cmp             w0, NULL
    // 0x4fe794: b.eq            #0x4feda8
    // 0x4fe798: SaveReg r0
    //     0x4fe798: str             x0, [SP, #-8]!
    // 0x4fe79c: r1 = 2
    //     0x4fe79c: mov             x1, #2
    // 0x4fe7a0: SaveReg r1
    //     0x4fe7a0: str             x1, [SP, #-8]!
    // 0x4fe7a4: r0 = group()
    //     0x4fe7a4: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x4fe7a8: add             SP, SP, #0x10
    // 0x4fe7ac: cmp             w0, NULL
    // 0x4fe7b0: b.eq            #0x4fedac
    // 0x4fe7b4: r16 = ".<anonymous closure>"
    //     0x4fe7b4: ldr             x16, [PP, #0x11d8]  ; [pp+0x11d8] ".<anonymous closure>"
    // 0x4fe7b8: stp             x16, x0, [SP, #-0x10]!
    // 0x4fe7bc: r16 = ""
    //     0x4fe7bc: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x4fe7c0: SaveReg r16
    //     0x4fe7c0: str             x16, [SP, #-8]!
    // 0x4fe7c4: r0 = replaceAll()
    //     0x4fe7c4: bl              #0x4bca70  ; [dart:core] _StringBase::replaceAll
    // 0x4fe7c8: add             SP, SP, #0x18
    // 0x4fe7cc: stur            x0, [fp, #-0x10]
    // 0x4fe7d0: r16 = "new"
    //     0x4fe7d0: ldr             x16, [PP, #0x11e0]  ; [pp+0x11e0] "new"
    // 0x4fe7d4: stp             x16, x0, [SP, #-0x10]!
    // 0x4fe7d8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fe7d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fe7dc: r0 = startsWith()
    //     0x4fe7dc: bl              #0x4e13d0  ; [dart:core] _StringBase::startsWith
    // 0x4fe7e0: add             SP, SP, #0x10
    // 0x4fe7e4: tbnz            w0, #4, #0x4fe93c
    // 0x4fe7e8: ldur            x1, [fp, #-0x10]
    // 0x4fe7ec: r0 = LoadClassIdInstr(r1)
    //     0x4fe7ec: ldur            x0, [x1, #-1]
    //     0x4fe7f0: ubfx            x0, x0, #0xc, #0x14
    // 0x4fe7f4: r16 = " "
    //     0x4fe7f4: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x4fe7f8: stp             x16, x1, [SP, #-0x10]!
    // 0x4fe7fc: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4fe7fc: sub             lr, x0, #0xff8
    //     0x4fe800: ldr             lr, [x21, lr, lsl #3]
    //     0x4fe804: blr             lr
    // 0x4fe808: add             SP, SP, #0x10
    // 0x4fe80c: LoadField: r1 = r0->field_b
    //     0x4fe80c: ldur            w1, [x0, #0xb]
    // 0x4fe810: DecompressPointer r1
    //     0x4fe810: add             x1, x1, HEAP, lsl #32
    // 0x4fe814: r0 = LoadInt32Instr(r1)
    //     0x4fe814: sbfx            x0, x1, #1, #0x1f
    // 0x4fe818: cmp             x0, #1
    // 0x4fe81c: b.le            #0x4fe878
    // 0x4fe820: ldur            x1, [fp, #-0x10]
    // 0x4fe824: r0 = LoadClassIdInstr(r1)
    //     0x4fe824: ldur            x0, [x1, #-1]
    //     0x4fe828: ubfx            x0, x0, #0xc, #0x14
    // 0x4fe82c: r16 = " "
    //     0x4fe82c: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x4fe830: stp             x16, x1, [SP, #-0x10]!
    // 0x4fe834: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4fe834: sub             lr, x0, #0xff8
    //     0x4fe838: ldr             lr, [x21, lr, lsl #3]
    //     0x4fe83c: blr             lr
    // 0x4fe840: add             SP, SP, #0x10
    // 0x4fe844: mov             x2, x0
    // 0x4fe848: LoadField: r0 = r2->field_b
    //     0x4fe848: ldur            w0, [x2, #0xb]
    // 0x4fe84c: DecompressPointer r0
    //     0x4fe84c: add             x0, x0, HEAP, lsl #32
    // 0x4fe850: r1 = LoadInt32Instr(r0)
    //     0x4fe850: sbfx            x1, x0, #1, #0x1f
    // 0x4fe854: mov             x0, x1
    // 0x4fe858: r1 = 1
    //     0x4fe858: mov             x1, #1
    // 0x4fe85c: cmp             x1, x0
    // 0x4fe860: b.hs            #0x4fedb0
    // 0x4fe864: LoadField: r0 = r2->field_f
    //     0x4fe864: ldur            w0, [x2, #0xf]
    // 0x4fe868: DecompressPointer r0
    //     0x4fe868: add             x0, x0, HEAP, lsl #32
    // 0x4fe86c: LoadField: r1 = r0->field_13
    //     0x4fe86c: ldur            w1, [x0, #0x13]
    // 0x4fe870: DecompressPointer r1
    //     0x4fe870: add             x1, x1, HEAP, lsl #32
    // 0x4fe874: b               #0x4fe87c
    // 0x4fe878: r1 = "<unknown>"
    //     0x4fe878: ldr             x1, [PP, #0x11e8]  ; [pp+0x11e8] "<unknown>"
    // 0x4fe87c: stur            x1, [fp, #-0x18]
    // 0x4fe880: r0 = LoadClassIdInstr(r1)
    //     0x4fe880: ldur            x0, [x1, #-1]
    //     0x4fe884: ubfx            x0, x0, #0xc, #0x14
    // 0x4fe888: r16 = "."
    //     0x4fe888: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x4fe88c: stp             x16, x1, [SP, #-0x10]!
    // 0x4fe890: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fe890: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fe894: r0 = GDT[cid_x0 + -0xffc]()
    //     0x4fe894: sub             lr, x0, #0xffc
    //     0x4fe898: ldr             lr, [x21, lr, lsl #3]
    //     0x4fe89c: blr             lr
    // 0x4fe8a0: add             SP, SP, #0x10
    // 0x4fe8a4: tbnz            w0, #4, #0x4fe920
    // 0x4fe8a8: ldur            x0, [fp, #-0x18]
    // 0x4fe8ac: r1 = LoadClassIdInstr(r0)
    //     0x4fe8ac: ldur            x1, [x0, #-1]
    //     0x4fe8b0: ubfx            x1, x1, #0xc, #0x14
    // 0x4fe8b4: r16 = "."
    //     0x4fe8b4: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x4fe8b8: stp             x16, x0, [SP, #-0x10]!
    // 0x4fe8bc: mov             x0, x1
    // 0x4fe8c0: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4fe8c0: sub             lr, x0, #0xff8
    //     0x4fe8c4: ldr             lr, [x21, lr, lsl #3]
    //     0x4fe8c8: blr             lr
    // 0x4fe8cc: add             SP, SP, #0x10
    // 0x4fe8d0: mov             x2, x0
    // 0x4fe8d4: LoadField: r0 = r2->field_b
    //     0x4fe8d4: ldur            w0, [x2, #0xb]
    // 0x4fe8d8: DecompressPointer r0
    //     0x4fe8d8: add             x0, x0, HEAP, lsl #32
    // 0x4fe8dc: r3 = LoadInt32Instr(r0)
    //     0x4fe8dc: sbfx            x3, x0, #1, #0x1f
    // 0x4fe8e0: mov             x0, x3
    // 0x4fe8e4: r1 = 0
    //     0x4fe8e4: mov             x1, #0
    // 0x4fe8e8: cmp             x1, x0
    // 0x4fe8ec: b.hs            #0x4fedb4
    // 0x4fe8f0: LoadField: r4 = r2->field_f
    //     0x4fe8f0: ldur            w4, [x2, #0xf]
    // 0x4fe8f4: DecompressPointer r4
    //     0x4fe8f4: add             x4, x4, HEAP, lsl #32
    // 0x4fe8f8: LoadField: r2 = r4->field_f
    //     0x4fe8f8: ldur            w2, [x4, #0xf]
    // 0x4fe8fc: DecompressPointer r2
    //     0x4fe8fc: add             x2, x2, HEAP, lsl #32
    // 0x4fe900: mov             x0, x3
    // 0x4fe904: r1 = 1
    //     0x4fe904: mov             x1, #1
    // 0x4fe908: cmp             x1, x0
    // 0x4fe90c: b.hs            #0x4fedb8
    // 0x4fe910: LoadField: r0 = r4->field_13
    //     0x4fe910: ldur            w0, [x4, #0x13]
    // 0x4fe914: DecompressPointer r0
    //     0x4fe914: add             x0, x0, HEAP, lsl #32
    // 0x4fe918: mov             x1, x2
    // 0x4fe91c: b               #0x4fe92c
    // 0x4fe920: ldur            x0, [fp, #-0x18]
    // 0x4fe924: mov             x1, x0
    // 0x4fe928: r0 = ""
    //     0x4fe928: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x4fe92c: mov             x2, x1
    // 0x4fe930: mov             x1, x0
    // 0x4fe934: r3 = true
    //     0x4fe934: add             x3, NULL, #0x20  ; true
    // 0x4fe938: b               #0x4fe9f4
    // 0x4fe93c: ldur            x1, [fp, #-0x10]
    // 0x4fe940: r0 = LoadClassIdInstr(r1)
    //     0x4fe940: ldur            x0, [x1, #-1]
    //     0x4fe944: ubfx            x0, x0, #0xc, #0x14
    // 0x4fe948: r16 = "."
    //     0x4fe948: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x4fe94c: stp             x16, x1, [SP, #-0x10]!
    // 0x4fe950: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4fe950: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4fe954: r0 = GDT[cid_x0 + -0xffc]()
    //     0x4fe954: sub             lr, x0, #0xffc
    //     0x4fe958: ldr             lr, [x21, lr, lsl #3]
    //     0x4fe95c: blr             lr
    // 0x4fe960: add             SP, SP, #0x10
    // 0x4fe964: tbnz            w0, #4, #0x4fe9e0
    // 0x4fe968: ldur            x0, [fp, #-0x10]
    // 0x4fe96c: r1 = LoadClassIdInstr(r0)
    //     0x4fe96c: ldur            x1, [x0, #-1]
    //     0x4fe970: ubfx            x1, x1, #0xc, #0x14
    // 0x4fe974: r16 = "."
    //     0x4fe974: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x4fe978: stp             x16, x0, [SP, #-0x10]!
    // 0x4fe97c: mov             x0, x1
    // 0x4fe980: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4fe980: sub             lr, x0, #0xff8
    //     0x4fe984: ldr             lr, [x21, lr, lsl #3]
    //     0x4fe988: blr             lr
    // 0x4fe98c: add             SP, SP, #0x10
    // 0x4fe990: mov             x2, x0
    // 0x4fe994: LoadField: r0 = r2->field_b
    //     0x4fe994: ldur            w0, [x2, #0xb]
    // 0x4fe998: DecompressPointer r0
    //     0x4fe998: add             x0, x0, HEAP, lsl #32
    // 0x4fe99c: r3 = LoadInt32Instr(r0)
    //     0x4fe99c: sbfx            x3, x0, #1, #0x1f
    // 0x4fe9a0: mov             x0, x3
    // 0x4fe9a4: r1 = 0
    //     0x4fe9a4: mov             x1, #0
    // 0x4fe9a8: cmp             x1, x0
    // 0x4fe9ac: b.hs            #0x4fedbc
    // 0x4fe9b0: LoadField: r4 = r2->field_f
    //     0x4fe9b0: ldur            w4, [x2, #0xf]
    // 0x4fe9b4: DecompressPointer r4
    //     0x4fe9b4: add             x4, x4, HEAP, lsl #32
    // 0x4fe9b8: LoadField: r2 = r4->field_f
    //     0x4fe9b8: ldur            w2, [x4, #0xf]
    // 0x4fe9bc: DecompressPointer r2
    //     0x4fe9bc: add             x2, x2, HEAP, lsl #32
    // 0x4fe9c0: mov             x0, x3
    // 0x4fe9c4: r1 = 1
    //     0x4fe9c4: mov             x1, #1
    // 0x4fe9c8: cmp             x1, x0
    // 0x4fe9cc: b.hs            #0x4fedc0
    // 0x4fe9d0: LoadField: r0 = r4->field_13
    //     0x4fe9d0: ldur            w0, [x4, #0x13]
    // 0x4fe9d4: DecompressPointer r0
    //     0x4fe9d4: add             x0, x0, HEAP, lsl #32
    // 0x4fe9d8: mov             x1, x2
    // 0x4fe9dc: b               #0x4fe9e8
    // 0x4fe9e0: ldur            x0, [fp, #-0x10]
    // 0x4fe9e4: r1 = ""
    //     0x4fe9e4: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x4fe9e8: mov             x2, x1
    // 0x4fe9ec: mov             x1, x0
    // 0x4fe9f0: r3 = false
    //     0x4fe9f0: add             x3, NULL, #0x30  ; false
    // 0x4fe9f4: r0 = 3
    //     0x4fe9f4: mov             x0, #3
    // 0x4fe9f8: stur            x3, [fp, #-0x10]
    // 0x4fe9fc: stur            x2, [fp, #-0x18]
    // 0x4fea00: stur            x1, [fp, #-0x20]
    // 0x4fea04: ldur            x16, [fp, #-8]
    // 0x4fea08: stp             x0, x16, [SP, #-0x10]!
    // 0x4fea0c: r0 = group()
    //     0x4fea0c: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x4fea10: add             SP, SP, #0x10
    // 0x4fea14: cmp             w0, NULL
    // 0x4fea18: b.eq            #0x4fedc4
    // 0x4fea1c: SaveReg r0
    //     0x4fea1c: str             x0, [SP, #-8]!
    // 0x4fea20: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fea20: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fea24: r0 = parse()
    //     0x4fea24: bl              #0x4da468  ; [dart:core] Uri::parse
    // 0x4fea28: add             SP, SP, #8
    // 0x4fea2c: mov             x1, x0
    // 0x4fea30: stur            x1, [fp, #-0x28]
    // 0x4fea34: r0 = LoadClassIdInstr(r1)
    //     0x4fea34: ldur            x0, [x1, #-1]
    //     0x4fea38: ubfx            x0, x0, #0xc, #0x14
    // 0x4fea3c: SaveReg r1
    //     0x4fea3c: str             x1, [SP, #-8]!
    // 0x4fea40: r0 = GDT[cid_x0 + -0xf96]()
    //     0x4fea40: sub             lr, x0, #0xf96
    //     0x4fea44: ldr             lr, [x21, lr, lsl #3]
    //     0x4fea48: blr             lr
    // 0x4fea4c: add             SP, SP, #8
    // 0x4fea50: mov             x2, x0
    // 0x4fea54: ldur            x1, [fp, #-0x28]
    // 0x4fea58: stur            x2, [fp, #-0x30]
    // 0x4fea5c: r0 = LoadClassIdInstr(r1)
    //     0x4fea5c: ldur            x0, [x1, #-1]
    //     0x4fea60: ubfx            x0, x0, #0xc, #0x14
    // 0x4fea64: SaveReg r1
    //     0x4fea64: str             x1, [SP, #-8]!
    // 0x4fea68: r0 = GDT[cid_x0 + -0xfb3]()
    //     0x4fea68: sub             lr, x0, #0xfb3
    //     0x4fea6c: ldr             lr, [x21, lr, lsl #3]
    //     0x4fea70: blr             lr
    // 0x4fea74: add             SP, SP, #8
    // 0x4fea78: r1 = LoadClassIdInstr(r0)
    //     0x4fea78: ldur            x1, [x0, #-1]
    //     0x4fea7c: ubfx            x1, x1, #0xc, #0x14
    // 0x4fea80: r16 = "dart"
    //     0x4fea80: ldr             x16, [PP, #0x11f0]  ; [pp+0x11f0] "dart"
    // 0x4fea84: stp             x16, x0, [SP, #-0x10]!
    // 0x4fea88: mov             x0, x1
    // 0x4fea8c: mov             lr, x0
    // 0x4fea90: ldr             lr, [x21, lr, lsl #3]
    // 0x4fea94: blr             lr
    // 0x4fea98: add             SP, SP, #0x10
    // 0x4fea9c: tbz             w0, #4, #0x4feae8
    // 0x4feaa0: ldur            x1, [fp, #-0x28]
    // 0x4feaa4: r0 = LoadClassIdInstr(r1)
    //     0x4feaa4: ldur            x0, [x1, #-1]
    //     0x4feaa8: ubfx            x0, x0, #0xc, #0x14
    // 0x4feaac: SaveReg r1
    //     0x4feaac: str             x1, [SP, #-8]!
    // 0x4feab0: r0 = GDT[cid_x0 + -0xfb3]()
    //     0x4feab0: sub             lr, x0, #0xfb3
    //     0x4feab4: ldr             lr, [x21, lr, lsl #3]
    //     0x4feab8: blr             lr
    // 0x4feabc: add             SP, SP, #8
    // 0x4feac0: r1 = LoadClassIdInstr(r0)
    //     0x4feac0: ldur            x1, [x0, #-1]
    //     0x4feac4: ubfx            x1, x1, #0xc, #0x14
    // 0x4feac8: r16 = "package"
    //     0x4feac8: ldr             x16, [PP, #0x11f8]  ; [pp+0x11f8] "package"
    // 0x4feacc: stp             x16, x0, [SP, #-0x10]!
    // 0x4fead0: mov             x0, x1
    // 0x4fead4: mov             lr, x0
    // 0x4fead8: ldr             lr, [x21, lr, lsl #3]
    // 0x4feadc: blr             lr
    // 0x4feae0: add             SP, SP, #0x10
    // 0x4feae4: tbnz            w0, #4, #0x4febf8
    // 0x4feae8: ldur            x1, [fp, #-0x28]
    // 0x4feaec: r0 = LoadClassIdInstr(r1)
    //     0x4feaec: ldur            x0, [x1, #-1]
    //     0x4feaf0: ubfx            x0, x0, #0xc, #0x14
    // 0x4feaf4: SaveReg r1
    //     0x4feaf4: str             x1, [SP, #-8]!
    // 0x4feaf8: r0 = GDT[cid_x0 + -0xf54]()
    //     0x4feaf8: sub             lr, x0, #0xf54
    //     0x4feafc: ldr             lr, [x21, lr, lsl #3]
    //     0x4feb00: blr             lr
    // 0x4feb04: add             SP, SP, #8
    // 0x4feb08: mov             x2, x0
    // 0x4feb0c: LoadField: r0 = r2->field_b
    //     0x4feb0c: ldur            w0, [x2, #0xb]
    // 0x4feb10: DecompressPointer r0
    //     0x4feb10: add             x0, x0, HEAP, lsl #32
    // 0x4feb14: r1 = LoadInt32Instr(r0)
    //     0x4feb14: sbfx            x1, x0, #1, #0x1f
    // 0x4feb18: mov             x0, x1
    // 0x4feb1c: r1 = 0
    //     0x4feb1c: mov             x1, #0
    // 0x4feb20: cmp             x1, x0
    // 0x4feb24: b.hs            #0x4fedc8
    // 0x4feb28: LoadField: r1 = r2->field_f
    //     0x4feb28: ldur            w1, [x2, #0xf]
    // 0x4feb2c: DecompressPointer r1
    //     0x4feb2c: add             x1, x1, HEAP, lsl #32
    // 0x4feb30: ldur            x2, [fp, #-0x28]
    // 0x4feb34: stur            x1, [fp, #-0x38]
    // 0x4feb38: r0 = LoadClassIdInstr(r2)
    //     0x4feb38: ldur            x0, [x2, #-1]
    //     0x4feb3c: ubfx            x0, x0, #0xc, #0x14
    // 0x4feb40: SaveReg r2
    //     0x4feb40: str             x2, [SP, #-8]!
    // 0x4feb44: r0 = GDT[cid_x0 + -0xf96]()
    //     0x4feb44: sub             lr, x0, #0xf96
    //     0x4feb48: ldr             lr, [x21, lr, lsl #3]
    //     0x4feb4c: blr             lr
    // 0x4feb50: add             SP, SP, #8
    // 0x4feb54: mov             x2, x0
    // 0x4feb58: ldur            x1, [fp, #-0x28]
    // 0x4feb5c: stur            x2, [fp, #-0x40]
    // 0x4feb60: r0 = LoadClassIdInstr(r1)
    //     0x4feb60: ldur            x0, [x1, #-1]
    //     0x4feb64: ubfx            x0, x0, #0xc, #0x14
    // 0x4feb68: SaveReg r1
    //     0x4feb68: str             x1, [SP, #-8]!
    // 0x4feb6c: r0 = GDT[cid_x0 + -0xf54]()
    //     0x4feb6c: sub             lr, x0, #0xf54
    //     0x4feb70: ldr             lr, [x21, lr, lsl #3]
    //     0x4feb74: blr             lr
    // 0x4feb78: add             SP, SP, #8
    // 0x4feb7c: mov             x2, x0
    // 0x4feb80: LoadField: r0 = r2->field_b
    //     0x4feb80: ldur            w0, [x2, #0xb]
    // 0x4feb84: DecompressPointer r0
    //     0x4feb84: add             x0, x0, HEAP, lsl #32
    // 0x4feb88: r1 = LoadInt32Instr(r0)
    //     0x4feb88: sbfx            x1, x0, #1, #0x1f
    // 0x4feb8c: mov             x0, x1
    // 0x4feb90: r1 = 0
    //     0x4feb90: mov             x1, #0
    // 0x4feb94: cmp             x1, x0
    // 0x4feb98: b.hs            #0x4fedcc
    // 0x4feb9c: LoadField: r0 = r2->field_f
    //     0x4feb9c: ldur            w0, [x2, #0xf]
    // 0x4feba0: DecompressPointer r0
    //     0x4feba0: add             x0, x0, HEAP, lsl #32
    // 0x4feba4: stur            x0, [fp, #-0x48]
    // 0x4feba8: r1 = Null
    //     0x4feba8: mov             x1, NULL
    // 0x4febac: r2 = 4
    //     0x4febac: mov             x2, #4
    // 0x4febb0: r0 = AllocateArray()
    //     0x4febb0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x4febb4: mov             x1, x0
    // 0x4febb8: ldur            x0, [fp, #-0x48]
    // 0x4febbc: StoreField: r1->field_f = r0
    //     0x4febbc: stur            w0, [x1, #0xf]
    // 0x4febc0: r17 = "/"
    //     0x4febc0: ldr             x17, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x4febc4: StoreField: r1->field_13 = r17
    //     0x4febc4: stur            w17, [x1, #0x13]
    // 0x4febc8: SaveReg r1
    //     0x4febc8: str             x1, [SP, #-8]!
    // 0x4febcc: r0 = _interpolate()
    //     0x4febcc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x4febd0: add             SP, SP, #8
    // 0x4febd4: ldur            x16, [fp, #-0x40]
    // 0x4febd8: stp             x0, x16, [SP, #-0x10]!
    // 0x4febdc: r16 = ""
    //     0x4febdc: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x4febe0: SaveReg r16
    //     0x4febe0: str             x16, [SP, #-8]!
    // 0x4febe4: r0 = replaceFirst()
    //     0x4febe4: bl              #0x4fede8  ; [dart:core] _StringBase::replaceFirst
    // 0x4febe8: add             SP, SP, #0x18
    // 0x4febec: ldur            x3, [fp, #-0x38]
    // 0x4febf0: mov             x2, x0
    // 0x4febf4: b               #0x4fec00
    // 0x4febf8: ldur            x2, [fp, #-0x30]
    // 0x4febfc: r3 = "<unknown>"
    //     0x4febfc: ldr             x3, [PP, #0x11e8]  ; [pp+0x11e8] "<unknown>"
    // 0x4fec00: ldur            x0, [fp, #-0x28]
    // 0x4fec04: r1 = 1
    //     0x4fec04: mov             x1, #1
    // 0x4fec08: stur            x3, [fp, #-0x30]
    // 0x4fec0c: stur            x2, [fp, #-0x38]
    // 0x4fec10: ldur            x16, [fp, #-8]
    // 0x4fec14: stp             x1, x16, [SP, #-0x10]!
    // 0x4fec18: r0 = group()
    //     0x4fec18: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x4fec1c: add             SP, SP, #0x10
    // 0x4fec20: cmp             w0, NULL
    // 0x4fec24: b.eq            #0x4fedd0
    // 0x4fec28: SaveReg r0
    //     0x4fec28: str             x0, [SP, #-8]!
    // 0x4fec2c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fec2c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fec30: r0 = parse()
    //     0x4fec30: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0x4fec34: add             SP, SP, #8
    // 0x4fec38: mov             x1, x0
    // 0x4fec3c: ldur            x0, [fp, #-0x28]
    // 0x4fec40: stur            x1, [fp, #-0x50]
    // 0x4fec44: r2 = LoadClassIdInstr(r0)
    //     0x4fec44: ldur            x2, [x0, #-1]
    //     0x4fec48: ubfx            x2, x2, #0xc, #0x14
    // 0x4fec4c: SaveReg r0
    //     0x4fec4c: str             x0, [SP, #-8]!
    // 0x4fec50: mov             x0, x2
    // 0x4fec54: r0 = GDT[cid_x0 + -0xfb3]()
    //     0x4fec54: sub             lr, x0, #0xfb3
    //     0x4fec58: ldr             lr, [x21, lr, lsl #3]
    //     0x4fec5c: blr             lr
    // 0x4fec60: add             SP, SP, #8
    // 0x4fec64: stur            x0, [fp, #-0x28]
    // 0x4fec68: ldur            x16, [fp, #-8]
    // 0x4fec6c: SaveReg r16
    //     0x4fec6c: str             x16, [SP, #-8]!
    // 0x4fec70: r1 = 4
    //     0x4fec70: mov             x1, #4
    // 0x4fec74: SaveReg r1
    //     0x4fec74: str             x1, [SP, #-8]!
    // 0x4fec78: r0 = group()
    //     0x4fec78: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x4fec7c: add             SP, SP, #0x10
    // 0x4fec80: cmp             w0, NULL
    // 0x4fec84: b.ne            #0x4fec90
    // 0x4fec88: r1 = -1
    //     0x4fec88: mov             x1, #-1
    // 0x4fec8c: b               #0x4fecc0
    // 0x4fec90: r0 = 4
    //     0x4fec90: mov             x0, #4
    // 0x4fec94: ldur            x16, [fp, #-8]
    // 0x4fec98: stp             x0, x16, [SP, #-0x10]!
    // 0x4fec9c: r0 = group()
    //     0x4fec9c: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x4feca0: add             SP, SP, #0x10
    // 0x4feca4: cmp             w0, NULL
    // 0x4feca8: b.eq            #0x4fedd4
    // 0x4fecac: SaveReg r0
    //     0x4fecac: str             x0, [SP, #-8]!
    // 0x4fecb0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fecb0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fecb4: r0 = parse()
    //     0x4fecb4: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0x4fecb8: add             SP, SP, #8
    // 0x4fecbc: mov             x1, x0
    // 0x4fecc0: r0 = 5
    //     0x4fecc0: mov             x0, #5
    // 0x4fecc4: stur            x1, [fp, #-0x58]
    // 0x4fecc8: ldur            x16, [fp, #-8]
    // 0x4feccc: stp             x0, x16, [SP, #-0x10]!
    // 0x4fecd0: r0 = group()
    //     0x4fecd0: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x4fecd4: add             SP, SP, #0x10
    // 0x4fecd8: cmp             w0, NULL
    // 0x4fecdc: b.ne            #0x4fece8
    // 0x4fece0: r9 = -1
    //     0x4fece0: mov             x9, #-1
    // 0x4fece4: b               #0x4fed18
    // 0x4fece8: r0 = 5
    //     0x4fece8: mov             x0, #5
    // 0x4fecec: ldur            x16, [fp, #-8]
    // 0x4fecf0: stp             x0, x16, [SP, #-0x10]!
    // 0x4fecf4: r0 = group()
    //     0x4fecf4: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x4fecf8: add             SP, SP, #0x10
    // 0x4fecfc: cmp             w0, NULL
    // 0x4fed00: b.eq            #0x4fedd8
    // 0x4fed04: SaveReg r0
    //     0x4fed04: str             x0, [SP, #-8]!
    // 0x4fed08: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x4fed08: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x4fed0c: r0 = parse()
    //     0x4fed0c: bl              #0x4d5d84  ; [dart:core] int::parse
    // 0x4fed10: add             SP, SP, #8
    // 0x4fed14: mov             x9, x0
    // 0x4fed18: ldr             x8, [fp, #0x10]
    // 0x4fed1c: ldur            x7, [fp, #-0x10]
    // 0x4fed20: ldur            x6, [fp, #-0x18]
    // 0x4fed24: ldur            x5, [fp, #-0x20]
    // 0x4fed28: ldur            x4, [fp, #-0x30]
    // 0x4fed2c: ldur            x3, [fp, #-0x38]
    // 0x4fed30: ldur            x2, [fp, #-0x50]
    // 0x4fed34: ldur            x1, [fp, #-0x28]
    // 0x4fed38: ldur            x0, [fp, #-0x58]
    // 0x4fed3c: stur            x9, [fp, #-0x60]
    // 0x4fed40: r0 = StackFrame()
    //     0x4fed40: bl              #0x4feddc  ; AllocateStackFrameStub -> StackFrame (size=0x3c)
    // 0x4fed44: ldur            x1, [fp, #-0x50]
    // 0x4fed48: StoreField: r0->field_b = r1
    //     0x4fed48: stur            x1, [x0, #0xb]
    // 0x4fed4c: ldur            x1, [fp, #-0x60]
    // 0x4fed50: StoreField: r0->field_27 = r1
    //     0x4fed50: stur            x1, [x0, #0x27]
    // 0x4fed54: ldur            x1, [fp, #-0x58]
    // 0x4fed58: StoreField: r0->field_1f = r1
    //     0x4fed58: stur            x1, [x0, #0x1f]
    // 0x4fed5c: ldur            x1, [fp, #-0x28]
    // 0x4fed60: StoreField: r0->field_13 = r1
    //     0x4fed60: stur            w1, [x0, #0x13]
    // 0x4fed64: ldur            x1, [fp, #-0x30]
    // 0x4fed68: StoreField: r0->field_17 = r1
    //     0x4fed68: stur            w1, [x0, #0x17]
    // 0x4fed6c: ldur            x1, [fp, #-0x38]
    // 0x4fed70: StoreField: r0->field_1b = r1
    //     0x4fed70: stur            w1, [x0, #0x1b]
    // 0x4fed74: ldur            x1, [fp, #-0x18]
    // 0x4fed78: StoreField: r0->field_2f = r1
    //     0x4fed78: stur            w1, [x0, #0x2f]
    // 0x4fed7c: ldur            x1, [fp, #-0x20]
    // 0x4fed80: StoreField: r0->field_33 = r1
    //     0x4fed80: stur            w1, [x0, #0x33]
    // 0x4fed84: ldur            x1, [fp, #-0x10]
    // 0x4fed88: StoreField: r0->field_37 = r1
    //     0x4fed88: stur            w1, [x0, #0x37]
    // 0x4fed8c: ldr             x1, [fp, #0x10]
    // 0x4fed90: StoreField: r0->field_7 = r1
    //     0x4fed90: stur            w1, [x0, #7]
    // 0x4fed94: LeaveFrame
    //     0x4fed94: mov             SP, fp
    //     0x4fed98: ldp             fp, lr, [SP], #0x10
    // 0x4fed9c: ret
    //     0x4fed9c: ret             
    // 0x4feda0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4feda0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4feda4: b               #0x4fe6c0
    // 0x4feda8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4feda8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4fedac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4fedac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4fedb0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fedb0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fedb4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fedb4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fedb8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fedb8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fedbc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fedbc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fedc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fedc0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fedc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4fedc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4fedc8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fedc8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fedcc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x4fedcc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x4fedd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4fedd0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4fedd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4fedd4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x4fedd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4fedd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _parseWebNonDebugFrame(/* No info */) {
    // ** addr: 0x4ff15c, size: 0x188
    // 0x4ff15c: EnterFrame
    //     0x4ff15c: stp             fp, lr, [SP, #-0x10]!
    //     0x4ff160: mov             fp, SP
    // 0x4ff164: AllocStack(0x10)
    //     0x4ff164: sub             SP, SP, #0x10
    // 0x4ff168: CheckStackOverflow
    //     0x4ff168: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ff16c: cmp             SP, x16
    //     0x4ff170: b.ls            #0x4ff2d8
    // 0x4ff174: r0 = InitLateStaticField(0xd4c) // [package:flutter/src/foundation/stack_frame.dart] StackFrame::_webNonDebugFramePattern
    //     0x4ff174: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x4ff178: ldr             x0, [x0, #0x1a98]
    //     0x4ff17c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x4ff180: cmp             w0, w16
    //     0x4ff184: b.ne            #0x4ff190
    //     0x4ff188: ldr             x2, [PP, #0x16b8]  ; [pp+0x16b8] Field <StackFrame._webNonDebugFramePattern@649425567>: static late final (offset: 0xd4c)
    //     0x4ff18c: bl              #0xd67cdc
    // 0x4ff190: ldr             x16, [fp, #0x10]
    // 0x4ff194: stp             x16, x0, [SP, #-0x10]!
    // 0x4ff198: r0 = firstMatch()
    //     0x4ff198: bl              #0x4fef70  ; [dart:core] _RegExp::firstMatch
    // 0x4ff19c: add             SP, SP, #0x10
    // 0x4ff1a0: cmp             w0, NULL
    // 0x4ff1a4: b.ne            #0x4ff1b8
    // 0x4ff1a8: r0 = Null
    //     0x4ff1a8: mov             x0, NULL
    // 0x4ff1ac: LeaveFrame
    //     0x4ff1ac: mov             SP, fp
    //     0x4ff1b0: ldp             fp, lr, [SP], #0x10
    // 0x4ff1b4: ret
    //     0x4ff1b4: ret             
    // 0x4ff1b8: r1 = 1
    //     0x4ff1b8: mov             x1, #1
    // 0x4ff1bc: stp             x1, x0, [SP, #-0x10]!
    // 0x4ff1c0: r0 = group()
    //     0x4ff1c0: bl              #0xc9eba8  ; [dart:core] _RegExpMatch::group
    // 0x4ff1c4: add             SP, SP, #0x10
    // 0x4ff1c8: cmp             w0, NULL
    // 0x4ff1cc: b.eq            #0x4ff2e0
    // 0x4ff1d0: r1 = LoadClassIdInstr(r0)
    //     0x4ff1d0: ldur            x1, [x0, #-1]
    //     0x4ff1d4: ubfx            x1, x1, #0xc, #0x14
    // 0x4ff1d8: r16 = "."
    //     0x4ff1d8: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x4ff1dc: stp             x16, x0, [SP, #-0x10]!
    // 0x4ff1e0: mov             x0, x1
    // 0x4ff1e4: r0 = GDT[cid_x0 + -0xff8]()
    //     0x4ff1e4: sub             lr, x0, #0xff8
    //     0x4ff1e8: ldr             lr, [x21, lr, lsl #3]
    //     0x4ff1ec: blr             lr
    // 0x4ff1f0: add             SP, SP, #0x10
    // 0x4ff1f4: stur            x0, [fp, #-8]
    // 0x4ff1f8: LoadField: r1 = r0->field_b
    //     0x4ff1f8: ldur            w1, [x0, #0xb]
    // 0x4ff1fc: DecompressPointer r1
    //     0x4ff1fc: add             x1, x1, HEAP, lsl #32
    // 0x4ff200: r2 = LoadInt32Instr(r1)
    //     0x4ff200: sbfx            x2, x1, #1, #0x1f
    // 0x4ff204: cmp             x2, #1
    // 0x4ff208: b.le            #0x4ff220
    // 0x4ff20c: SaveReg r0
    //     0x4ff20c: str             x0, [SP, #-8]!
    // 0x4ff210: r0 = first()
    //     0x4ff210: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x4ff214: add             SP, SP, #8
    // 0x4ff218: mov             x1, x0
    // 0x4ff21c: b               #0x4ff224
    // 0x4ff220: r1 = "<unknown>"
    //     0x4ff220: ldr             x1, [PP, #0x11e8]  ; [pp+0x11e8] "<unknown>"
    // 0x4ff224: ldur            x0, [fp, #-8]
    // 0x4ff228: stur            x1, [fp, #-0x10]
    // 0x4ff22c: LoadField: r2 = r0->field_b
    //     0x4ff22c: ldur            w2, [x0, #0xb]
    // 0x4ff230: DecompressPointer r2
    //     0x4ff230: add             x2, x2, HEAP, lsl #32
    // 0x4ff234: r3 = LoadInt32Instr(r2)
    //     0x4ff234: sbfx            x3, x2, #1, #0x1f
    // 0x4ff238: cmp             x3, #1
    // 0x4ff23c: b.le            #0x4ff26c
    // 0x4ff240: r2 = 1
    //     0x4ff240: mov             x2, #1
    // 0x4ff244: stp             x2, x0, [SP, #-0x10]!
    // 0x4ff248: r0 = skip()
    //     0x4ff248: bl              #0x7118b4  ; [dart:collection] _ListBase&Object&ListMixin::skip
    // 0x4ff24c: add             SP, SP, #0x10
    // 0x4ff250: r16 = "."
    //     0x4ff250: ldr             x16, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x4ff254: stp             x16, x0, [SP, #-0x10]!
    // 0x4ff258: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4ff258: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4ff25c: r0 = join()
    //     0x4ff25c: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0x4ff260: add             SP, SP, #0x10
    // 0x4ff264: mov             x2, x0
    // 0x4ff268: b               #0x4ff27c
    // 0x4ff26c: SaveReg r0
    //     0x4ff26c: str             x0, [SP, #-8]!
    // 0x4ff270: r0 = single()
    //     0x4ff270: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x4ff274: add             SP, SP, #8
    // 0x4ff278: mov             x2, x0
    // 0x4ff27c: ldr             x1, [fp, #0x10]
    // 0x4ff280: ldur            x0, [fp, #-0x10]
    // 0x4ff284: stur            x2, [fp, #-8]
    // 0x4ff288: r0 = StackFrame()
    //     0x4ff288: bl              #0x4feddc  ; AllocateStackFrameStub -> StackFrame (size=0x3c)
    // 0x4ff28c: r1 = -1
    //     0x4ff28c: mov             x1, #-1
    // 0x4ff290: StoreField: r0->field_b = r1
    //     0x4ff290: stur            x1, [x0, #0xb]
    // 0x4ff294: StoreField: r0->field_27 = r1
    //     0x4ff294: stur            x1, [x0, #0x27]
    // 0x4ff298: StoreField: r0->field_1f = r1
    //     0x4ff298: stur            x1, [x0, #0x1f]
    // 0x4ff29c: r1 = "<unknown>"
    //     0x4ff29c: ldr             x1, [PP, #0x11e8]  ; [pp+0x11e8] "<unknown>"
    // 0x4ff2a0: StoreField: r0->field_13 = r1
    //     0x4ff2a0: stur            w1, [x0, #0x13]
    // 0x4ff2a4: StoreField: r0->field_17 = r1
    //     0x4ff2a4: stur            w1, [x0, #0x17]
    // 0x4ff2a8: StoreField: r0->field_1b = r1
    //     0x4ff2a8: stur            w1, [x0, #0x1b]
    // 0x4ff2ac: ldur            x1, [fp, #-0x10]
    // 0x4ff2b0: StoreField: r0->field_2f = r1
    //     0x4ff2b0: stur            w1, [x0, #0x2f]
    // 0x4ff2b4: ldur            x1, [fp, #-8]
    // 0x4ff2b8: StoreField: r0->field_33 = r1
    //     0x4ff2b8: stur            w1, [x0, #0x33]
    // 0x4ff2bc: r1 = false
    //     0x4ff2bc: add             x1, NULL, #0x30  ; false
    // 0x4ff2c0: StoreField: r0->field_37 = r1
    //     0x4ff2c0: stur            w1, [x0, #0x37]
    // 0x4ff2c4: ldr             x1, [fp, #0x10]
    // 0x4ff2c8: StoreField: r0->field_7 = r1
    //     0x4ff2c8: stur            w1, [x0, #7]
    // 0x4ff2cc: LeaveFrame
    //     0x4ff2cc: mov             SP, fp
    //     0x4ff2d0: ldp             fp, lr, [SP], #0x10
    // 0x4ff2d4: ret
    //     0x4ff2d4: ret             
    // 0x4ff2d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ff2d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ff2dc: b               #0x4ff174
    // 0x4ff2e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x4ff2e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static RegExp _webNonDebugFramePattern() {
    // ** addr: 0x4ff2e4, size: 0x3c
    // 0x4ff2e4: EnterFrame
    //     0x4ff2e4: stp             fp, lr, [SP, #-0x10]!
    //     0x4ff2e8: mov             fp, SP
    // 0x4ff2ec: CheckStackOverflow
    //     0x4ff2ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ff2f0: cmp             SP, x16
    //     0x4ff2f4: b.ls            #0x4ff318
    // 0x4ff2f8: r16 = "^\\s*at ([^\\s]+).*$"
    //     0x4ff2f8: ldr             x16, [PP, #0x16c0]  ; [pp+0x16c0] "^\\s*at ([^\\s]+).*$"
    // 0x4ff2fc: stp             x16, NULL, [SP, #-0x10]!
    // 0x4ff300: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x4ff300: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x4ff304: r0 = RegExp()
    //     0x4ff304: bl              #0x4d8ea0  ; [dart:core] RegExp::RegExp
    // 0x4ff308: add             SP, SP, #0x10
    // 0x4ff30c: LeaveFrame
    //     0x4ff30c: mov             SP, fp
    //     0x4ff310: ldp             fp, lr, [SP], #0x10
    // 0x4ff314: ret
    //     0x4ff314: ret             
    // 0x4ff318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ff318: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ff31c: b               #0x4ff2f8
  }
  [closure] static bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x4ff320, size: 0x20
    // 0x4ff320: ldr             x1, [SP]
    // 0x4ff324: LoadField: r2 = r1->field_7
    //     0x4ff324: ldur            w2, [x1, #7]
    // 0x4ff328: DecompressPointer r2
    //     0x4ff328: add             x2, x2, HEAP, lsl #32
    // 0x4ff32c: cbnz            w2, #0x4ff338
    // 0x4ff330: r0 = false
    //     0x4ff330: add             x0, NULL, #0x30  ; false
    // 0x4ff334: b               #0x4ff33c
    // 0x4ff338: r0 = true
    //     0x4ff338: add             x0, NULL, #0x20  ; true
    // 0x4ff33c: ret
    //     0x4ff33c: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad8e6c, size: 0x248
    // 0xad8e6c: EnterFrame
    //     0xad8e6c: stp             fp, lr, [SP, #-0x10]!
    //     0xad8e70: mov             fp, SP
    // 0xad8e74: CheckStackOverflow
    //     0xad8e74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8e78: cmp             SP, x16
    //     0xad8e7c: b.ls            #0xad90ac
    // 0xad8e80: r1 = Null
    //     0xad8e80: mov             x1, NULL
    // 0xad8e84: r2 = 36
    //     0xad8e84: mov             x2, #0x24
    // 0xad8e88: r0 = AllocateArray()
    //     0xad8e88: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad8e8c: mov             x2, x0
    // 0xad8e90: r17 = "StackFrame"
    //     0xad8e90: ldr             x17, [PP, #0x74d0]  ; [pp+0x74d0] "StackFrame"
    // 0xad8e94: StoreField: r2->field_f = r17
    //     0xad8e94: stur            w17, [x2, #0xf]
    // 0xad8e98: r17 = "(#"
    //     0xad8e98: ldr             x17, [PP, #0x74d8]  ; [pp+0x74d8] "(#"
    // 0xad8e9c: StoreField: r2->field_13 = r17
    //     0xad8e9c: stur            w17, [x2, #0x13]
    // 0xad8ea0: ldr             x3, [fp, #0x10]
    // 0xad8ea4: LoadField: r4 = r3->field_b
    //     0xad8ea4: ldur            x4, [x3, #0xb]
    // 0xad8ea8: r0 = BoxInt64Instr(r4)
    //     0xad8ea8: sbfiz           x0, x4, #1, #0x1f
    //     0xad8eac: cmp             x4, x0, asr #1
    //     0xad8eb0: b.eq            #0xad8ebc
    //     0xad8eb4: bl              #0xd69bb8
    //     0xad8eb8: stur            x4, [x0, #7]
    // 0xad8ebc: mov             x1, x2
    // 0xad8ec0: ArrayStore: r1[2] = r0  ; List_4
    //     0xad8ec0: add             x25, x1, #0x17
    //     0xad8ec4: str             w0, [x25]
    //     0xad8ec8: tbz             w0, #0, #0xad8ee4
    //     0xad8ecc: ldurb           w16, [x1, #-1]
    //     0xad8ed0: ldurb           w17, [x0, #-1]
    //     0xad8ed4: and             x16, x17, x16, lsr #2
    //     0xad8ed8: tst             x16, HEAP, lsr #32
    //     0xad8edc: b.eq            #0xad8ee4
    //     0xad8ee0: bl              #0xd67e5c
    // 0xad8ee4: r17 = ", "
    //     0xad8ee4: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad8ee8: StoreField: r2->field_1b = r17
    //     0xad8ee8: stur            w17, [x2, #0x1b]
    // 0xad8eec: LoadField: r0 = r3->field_13
    //     0xad8eec: ldur            w0, [x3, #0x13]
    // 0xad8ef0: DecompressPointer r0
    //     0xad8ef0: add             x0, x0, HEAP, lsl #32
    // 0xad8ef4: mov             x1, x2
    // 0xad8ef8: ArrayStore: r1[4] = r0  ; List_4
    //     0xad8ef8: add             x25, x1, #0x1f
    //     0xad8efc: str             w0, [x25]
    //     0xad8f00: tbz             w0, #0, #0xad8f1c
    //     0xad8f04: ldurb           w16, [x1, #-1]
    //     0xad8f08: ldurb           w17, [x0, #-1]
    //     0xad8f0c: and             x16, x17, x16, lsr #2
    //     0xad8f10: tst             x16, HEAP, lsr #32
    //     0xad8f14: b.eq            #0xad8f1c
    //     0xad8f18: bl              #0xd67e5c
    // 0xad8f1c: r17 = ":"
    //     0xad8f1c: ldr             x17, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xad8f20: StoreField: r2->field_23 = r17
    //     0xad8f20: stur            w17, [x2, #0x23]
    // 0xad8f24: LoadField: r0 = r3->field_17
    //     0xad8f24: ldur            w0, [x3, #0x17]
    // 0xad8f28: DecompressPointer r0
    //     0xad8f28: add             x0, x0, HEAP, lsl #32
    // 0xad8f2c: mov             x1, x2
    // 0xad8f30: ArrayStore: r1[6] = r0  ; List_4
    //     0xad8f30: add             x25, x1, #0x27
    //     0xad8f34: str             w0, [x25]
    //     0xad8f38: tbz             w0, #0, #0xad8f54
    //     0xad8f3c: ldurb           w16, [x1, #-1]
    //     0xad8f40: ldurb           w17, [x0, #-1]
    //     0xad8f44: and             x16, x17, x16, lsr #2
    //     0xad8f48: tst             x16, HEAP, lsr #32
    //     0xad8f4c: b.eq            #0xad8f54
    //     0xad8f50: bl              #0xd67e5c
    // 0xad8f54: r17 = "/"
    //     0xad8f54: ldr             x17, [PP, #0x768]  ; [pp+0x768] "/"
    // 0xad8f58: StoreField: r2->field_2b = r17
    //     0xad8f58: stur            w17, [x2, #0x2b]
    // 0xad8f5c: LoadField: r0 = r3->field_1b
    //     0xad8f5c: ldur            w0, [x3, #0x1b]
    // 0xad8f60: DecompressPointer r0
    //     0xad8f60: add             x0, x0, HEAP, lsl #32
    // 0xad8f64: mov             x1, x2
    // 0xad8f68: ArrayStore: r1[8] = r0  ; List_4
    //     0xad8f68: add             x25, x1, #0x2f
    //     0xad8f6c: str             w0, [x25]
    //     0xad8f70: tbz             w0, #0, #0xad8f8c
    //     0xad8f74: ldurb           w16, [x1, #-1]
    //     0xad8f78: ldurb           w17, [x0, #-1]
    //     0xad8f7c: and             x16, x17, x16, lsr #2
    //     0xad8f80: tst             x16, HEAP, lsr #32
    //     0xad8f84: b.eq            #0xad8f8c
    //     0xad8f88: bl              #0xd67e5c
    // 0xad8f8c: r17 = ":"
    //     0xad8f8c: ldr             x17, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xad8f90: StoreField: r2->field_33 = r17
    //     0xad8f90: stur            w17, [x2, #0x33]
    // 0xad8f94: LoadField: r4 = r3->field_1f
    //     0xad8f94: ldur            x4, [x3, #0x1f]
    // 0xad8f98: r0 = BoxInt64Instr(r4)
    //     0xad8f98: sbfiz           x0, x4, #1, #0x1f
    //     0xad8f9c: cmp             x4, x0, asr #1
    //     0xad8fa0: b.eq            #0xad8fac
    //     0xad8fa4: bl              #0xd69bb8
    //     0xad8fa8: stur            x4, [x0, #7]
    // 0xad8fac: mov             x1, x2
    // 0xad8fb0: ArrayStore: r1[10] = r0  ; List_4
    //     0xad8fb0: add             x25, x1, #0x37
    //     0xad8fb4: str             w0, [x25]
    //     0xad8fb8: tbz             w0, #0, #0xad8fd4
    //     0xad8fbc: ldurb           w16, [x1, #-1]
    //     0xad8fc0: ldurb           w17, [x0, #-1]
    //     0xad8fc4: and             x16, x17, x16, lsr #2
    //     0xad8fc8: tst             x16, HEAP, lsr #32
    //     0xad8fcc: b.eq            #0xad8fd4
    //     0xad8fd0: bl              #0xd67e5c
    // 0xad8fd4: r17 = ":"
    //     0xad8fd4: ldr             x17, [PP, #0x6f8]  ; [pp+0x6f8] ":"
    // 0xad8fd8: StoreField: r2->field_3b = r17
    //     0xad8fd8: stur            w17, [x2, #0x3b]
    // 0xad8fdc: LoadField: r4 = r3->field_27
    //     0xad8fdc: ldur            x4, [x3, #0x27]
    // 0xad8fe0: r0 = BoxInt64Instr(r4)
    //     0xad8fe0: sbfiz           x0, x4, #1, #0x1f
    //     0xad8fe4: cmp             x4, x0, asr #1
    //     0xad8fe8: b.eq            #0xad8ff4
    //     0xad8fec: bl              #0xd69bb8
    //     0xad8ff0: stur            x4, [x0, #7]
    // 0xad8ff4: mov             x1, x2
    // 0xad8ff8: ArrayStore: r1[12] = r0  ; List_4
    //     0xad8ff8: add             x25, x1, #0x3f
    //     0xad8ffc: str             w0, [x25]
    //     0xad9000: tbz             w0, #0, #0xad901c
    //     0xad9004: ldurb           w16, [x1, #-1]
    //     0xad9008: ldurb           w17, [x0, #-1]
    //     0xad900c: and             x16, x17, x16, lsr #2
    //     0xad9010: tst             x16, HEAP, lsr #32
    //     0xad9014: b.eq            #0xad901c
    //     0xad9018: bl              #0xd67e5c
    // 0xad901c: r17 = ", className: "
    //     0xad901c: ldr             x17, [PP, #0x74e0]  ; [pp+0x74e0] ", className: "
    // 0xad9020: StoreField: r2->field_43 = r17
    //     0xad9020: stur            w17, [x2, #0x43]
    // 0xad9024: LoadField: r0 = r3->field_2f
    //     0xad9024: ldur            w0, [x3, #0x2f]
    // 0xad9028: DecompressPointer r0
    //     0xad9028: add             x0, x0, HEAP, lsl #32
    // 0xad902c: mov             x1, x2
    // 0xad9030: ArrayStore: r1[14] = r0  ; List_4
    //     0xad9030: add             x25, x1, #0x47
    //     0xad9034: str             w0, [x25]
    //     0xad9038: tbz             w0, #0, #0xad9054
    //     0xad903c: ldurb           w16, [x1, #-1]
    //     0xad9040: ldurb           w17, [x0, #-1]
    //     0xad9044: and             x16, x17, x16, lsr #2
    //     0xad9048: tst             x16, HEAP, lsr #32
    //     0xad904c: b.eq            #0xad9054
    //     0xad9050: bl              #0xd67e5c
    // 0xad9054: r17 = ", method: "
    //     0xad9054: ldr             x17, [PP, #0x74e8]  ; [pp+0x74e8] ", method: "
    // 0xad9058: StoreField: r2->field_4b = r17
    //     0xad9058: stur            w17, [x2, #0x4b]
    // 0xad905c: LoadField: r0 = r3->field_33
    //     0xad905c: ldur            w0, [x3, #0x33]
    // 0xad9060: DecompressPointer r0
    //     0xad9060: add             x0, x0, HEAP, lsl #32
    // 0xad9064: mov             x1, x2
    // 0xad9068: ArrayStore: r1[16] = r0  ; List_4
    //     0xad9068: add             x25, x1, #0x4f
    //     0xad906c: str             w0, [x25]
    //     0xad9070: tbz             w0, #0, #0xad908c
    //     0xad9074: ldurb           w16, [x1, #-1]
    //     0xad9078: ldurb           w17, [x0, #-1]
    //     0xad907c: and             x16, x17, x16, lsr #2
    //     0xad9080: tst             x16, HEAP, lsr #32
    //     0xad9084: b.eq            #0xad908c
    //     0xad9088: bl              #0xd67e5c
    // 0xad908c: r17 = ")"
    //     0xad908c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9090: StoreField: r2->field_53 = r17
    //     0xad9090: stur            w17, [x2, #0x53]
    // 0xad9094: SaveReg r2
    //     0xad9094: str             x2, [SP, #-8]!
    // 0xad9098: r0 = _interpolate()
    //     0xad9098: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad909c: add             SP, SP, #8
    // 0xad90a0: LeaveFrame
    //     0xad90a0: mov             SP, fp
    //     0xad90a4: ldp             fp, lr, [SP], #0x10
    // 0xad90a8: ret
    //     0xad90a8: ret             
    // 0xad90ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad90ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad90b0: b               #0xad8e80
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0d568, size: 0xd0
    // 0xb0d568: EnterFrame
    //     0xb0d568: stp             fp, lr, [SP, #-0x10]!
    //     0xb0d56c: mov             fp, SP
    // 0xb0d570: CheckStackOverflow
    //     0xb0d570: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0d574: cmp             SP, x16
    //     0xb0d578: b.ls            #0xb0d630
    // 0xb0d57c: ldr             x0, [fp, #0x10]
    // 0xb0d580: LoadField: r2 = r0->field_b
    //     0xb0d580: ldur            x2, [x0, #0xb]
    // 0xb0d584: LoadField: r3 = r0->field_17
    //     0xb0d584: ldur            w3, [x0, #0x17]
    // 0xb0d588: DecompressPointer r3
    //     0xb0d588: add             x3, x3, HEAP, lsl #32
    // 0xb0d58c: LoadField: r4 = r0->field_1f
    //     0xb0d58c: ldur            x4, [x0, #0x1f]
    // 0xb0d590: LoadField: r5 = r0->field_27
    //     0xb0d590: ldur            x5, [x0, #0x27]
    // 0xb0d594: LoadField: r6 = r0->field_2f
    //     0xb0d594: ldur            w6, [x0, #0x2f]
    // 0xb0d598: DecompressPointer r6
    //     0xb0d598: add             x6, x6, HEAP, lsl #32
    // 0xb0d59c: LoadField: r7 = r0->field_33
    //     0xb0d59c: ldur            w7, [x0, #0x33]
    // 0xb0d5a0: DecompressPointer r7
    //     0xb0d5a0: add             x7, x7, HEAP, lsl #32
    // 0xb0d5a4: LoadField: r8 = r0->field_7
    //     0xb0d5a4: ldur            w8, [x0, #7]
    // 0xb0d5a8: DecompressPointer r8
    //     0xb0d5a8: add             x8, x8, HEAP, lsl #32
    // 0xb0d5ac: r0 = BoxInt64Instr(r2)
    //     0xb0d5ac: sbfiz           x0, x2, #1, #0x1f
    //     0xb0d5b0: cmp             x2, x0, asr #1
    //     0xb0d5b4: b.eq            #0xb0d5c0
    //     0xb0d5b8: bl              #0xd69bb8
    //     0xb0d5bc: stur            x2, [x0, #7]
    // 0xb0d5c0: mov             x2, x0
    // 0xb0d5c4: r0 = BoxInt64Instr(r4)
    //     0xb0d5c4: sbfiz           x0, x4, #1, #0x1f
    //     0xb0d5c8: cmp             x4, x0, asr #1
    //     0xb0d5cc: b.eq            #0xb0d5d8
    //     0xb0d5d0: bl              #0xd69bb8
    //     0xb0d5d4: stur            x4, [x0, #7]
    // 0xb0d5d8: mov             x4, x0
    // 0xb0d5dc: r0 = BoxInt64Instr(r5)
    //     0xb0d5dc: sbfiz           x0, x5, #1, #0x1f
    //     0xb0d5e0: cmp             x5, x0, asr #1
    //     0xb0d5e4: b.eq            #0xb0d5f0
    //     0xb0d5e8: bl              #0xd69bb8
    //     0xb0d5ec: stur            x5, [x0, #7]
    // 0xb0d5f0: stp             x3, x2, [SP, #-0x10]!
    // 0xb0d5f4: stp             x0, x4, [SP, #-0x10]!
    // 0xb0d5f8: stp             x7, x6, [SP, #-0x10]!
    // 0xb0d5fc: SaveReg r8
    //     0xb0d5fc: str             x8, [SP, #-8]!
    // 0xb0d600: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0xb0d600: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0xb0d604: r0 = hash()
    //     0xb0d604: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0d608: add             SP, SP, #0x38
    // 0xb0d60c: mov             x2, x0
    // 0xb0d610: r0 = BoxInt64Instr(r2)
    //     0xb0d610: sbfiz           x0, x2, #1, #0x1f
    //     0xb0d614: cmp             x2, x0, asr #1
    //     0xb0d618: b.eq            #0xb0d624
    //     0xb0d61c: bl              #0xd69bb8
    //     0xb0d620: stur            x2, [x0, #7]
    // 0xb0d624: LeaveFrame
    //     0xb0d624: mov             SP, fp
    //     0xb0d628: ldp             fp, lr, [SP], #0x10
    // 0xb0d62c: ret
    //     0xb0d62c: ret             
    // 0xb0d630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0d630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0d634: b               #0xb0d57c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc982e8, size: 0x1e8
    // 0xc982e8: EnterFrame
    //     0xc982e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc982ec: mov             fp, SP
    // 0xc982f0: CheckStackOverflow
    //     0xc982f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc982f4: cmp             SP, x16
    //     0xc982f8: b.ls            #0xc984c8
    // 0xc982fc: ldr             x1, [fp, #0x10]
    // 0xc98300: cmp             w1, NULL
    // 0xc98304: b.ne            #0xc98318
    // 0xc98308: r0 = false
    //     0xc98308: add             x0, NULL, #0x30  ; false
    // 0xc9830c: LeaveFrame
    //     0xc9830c: mov             SP, fp
    //     0xc98310: ldp             fp, lr, [SP], #0x10
    // 0xc98314: ret
    //     0xc98314: ret             
    // 0xc98318: r0 = 59
    //     0xc98318: mov             x0, #0x3b
    // 0xc9831c: branchIfSmi(r1, 0xc98328)
    //     0xc9831c: tbz             w1, #0, #0xc98328
    // 0xc98320: r0 = LoadClassIdInstr(r1)
    //     0xc98320: ldur            x0, [x1, #-1]
    //     0xc98324: ubfx            x0, x0, #0xc, #0x14
    // 0xc98328: SaveReg r1
    //     0xc98328: str             x1, [SP, #-8]!
    // 0xc9832c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc9832c: mov             x17, #0x57c5
    //     0xc98330: add             lr, x0, x17
    //     0xc98334: ldr             lr, [x21, lr, lsl #3]
    //     0xc98338: blr             lr
    // 0xc9833c: add             SP, SP, #8
    // 0xc98340: r1 = LoadClassIdInstr(r0)
    //     0xc98340: ldur            x1, [x0, #-1]
    //     0xc98344: ubfx            x1, x1, #0xc, #0x14
    // 0xc98348: r16 = StackFrame
    //     0xc98348: ldr             x16, [PP, #0x74f0]  ; [pp+0x74f0] Type: StackFrame
    // 0xc9834c: stp             x16, x0, [SP, #-0x10]!
    // 0xc98350: mov             x0, x1
    // 0xc98354: mov             lr, x0
    // 0xc98358: ldr             lr, [x21, lr, lsl #3]
    // 0xc9835c: blr             lr
    // 0xc98360: add             SP, SP, #0x10
    // 0xc98364: tbz             w0, #4, #0xc98378
    // 0xc98368: r0 = false
    //     0xc98368: add             x0, NULL, #0x30  ; false
    // 0xc9836c: LeaveFrame
    //     0xc9836c: mov             SP, fp
    //     0xc98370: ldp             fp, lr, [SP], #0x10
    // 0xc98374: ret
    //     0xc98374: ret             
    // 0xc98378: ldr             x1, [fp, #0x10]
    // 0xc9837c: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9837c: mov             x0, #0x76
    //     0xc98380: tbz             w1, #0, #0xc98390
    //     0xc98384: ldur            x0, [x1, #-1]
    //     0xc98388: ubfx            x0, x0, #0xc, #0x14
    //     0xc9838c: lsl             x0, x0, #1
    // 0xc98390: r17 = 4738
    //     0xc98390: mov             x17, #0x1282
    // 0xc98394: cmp             w0, w17
    // 0xc98398: b.ne            #0xc984b8
    // 0xc9839c: ldr             x2, [fp, #0x18]
    // 0xc983a0: LoadField: r0 = r1->field_b
    //     0xc983a0: ldur            x0, [x1, #0xb]
    // 0xc983a4: LoadField: r3 = r2->field_b
    //     0xc983a4: ldur            x3, [x2, #0xb]
    // 0xc983a8: cmp             x0, x3
    // 0xc983ac: b.ne            #0xc984b8
    // 0xc983b0: LoadField: r0 = r1->field_17
    //     0xc983b0: ldur            w0, [x1, #0x17]
    // 0xc983b4: DecompressPointer r0
    //     0xc983b4: add             x0, x0, HEAP, lsl #32
    // 0xc983b8: LoadField: r3 = r2->field_17
    //     0xc983b8: ldur            w3, [x2, #0x17]
    // 0xc983bc: DecompressPointer r3
    //     0xc983bc: add             x3, x3, HEAP, lsl #32
    // 0xc983c0: r4 = LoadClassIdInstr(r0)
    //     0xc983c0: ldur            x4, [x0, #-1]
    //     0xc983c4: ubfx            x4, x4, #0xc, #0x14
    // 0xc983c8: stp             x3, x0, [SP, #-0x10]!
    // 0xc983cc: mov             x0, x4
    // 0xc983d0: mov             lr, x0
    // 0xc983d4: ldr             lr, [x21, lr, lsl #3]
    // 0xc983d8: blr             lr
    // 0xc983dc: add             SP, SP, #0x10
    // 0xc983e0: tbnz            w0, #4, #0xc984b8
    // 0xc983e4: ldr             x2, [fp, #0x18]
    // 0xc983e8: ldr             x1, [fp, #0x10]
    // 0xc983ec: LoadField: r0 = r1->field_1f
    //     0xc983ec: ldur            x0, [x1, #0x1f]
    // 0xc983f0: LoadField: r3 = r2->field_1f
    //     0xc983f0: ldur            x3, [x2, #0x1f]
    // 0xc983f4: cmp             x0, x3
    // 0xc983f8: b.ne            #0xc984b8
    // 0xc983fc: LoadField: r0 = r1->field_27
    //     0xc983fc: ldur            x0, [x1, #0x27]
    // 0xc98400: LoadField: r3 = r2->field_27
    //     0xc98400: ldur            x3, [x2, #0x27]
    // 0xc98404: cmp             x0, x3
    // 0xc98408: b.ne            #0xc984b8
    // 0xc9840c: LoadField: r0 = r1->field_2f
    //     0xc9840c: ldur            w0, [x1, #0x2f]
    // 0xc98410: DecompressPointer r0
    //     0xc98410: add             x0, x0, HEAP, lsl #32
    // 0xc98414: LoadField: r3 = r2->field_2f
    //     0xc98414: ldur            w3, [x2, #0x2f]
    // 0xc98418: DecompressPointer r3
    //     0xc98418: add             x3, x3, HEAP, lsl #32
    // 0xc9841c: r4 = LoadClassIdInstr(r0)
    //     0xc9841c: ldur            x4, [x0, #-1]
    //     0xc98420: ubfx            x4, x4, #0xc, #0x14
    // 0xc98424: stp             x3, x0, [SP, #-0x10]!
    // 0xc98428: mov             x0, x4
    // 0xc9842c: mov             lr, x0
    // 0xc98430: ldr             lr, [x21, lr, lsl #3]
    // 0xc98434: blr             lr
    // 0xc98438: add             SP, SP, #0x10
    // 0xc9843c: tbnz            w0, #4, #0xc984b8
    // 0xc98440: ldr             x2, [fp, #0x18]
    // 0xc98444: ldr             x1, [fp, #0x10]
    // 0xc98448: LoadField: r0 = r1->field_33
    //     0xc98448: ldur            w0, [x1, #0x33]
    // 0xc9844c: DecompressPointer r0
    //     0xc9844c: add             x0, x0, HEAP, lsl #32
    // 0xc98450: LoadField: r3 = r2->field_33
    //     0xc98450: ldur            w3, [x2, #0x33]
    // 0xc98454: DecompressPointer r3
    //     0xc98454: add             x3, x3, HEAP, lsl #32
    // 0xc98458: r4 = LoadClassIdInstr(r0)
    //     0xc98458: ldur            x4, [x0, #-1]
    //     0xc9845c: ubfx            x4, x4, #0xc, #0x14
    // 0xc98460: stp             x3, x0, [SP, #-0x10]!
    // 0xc98464: mov             x0, x4
    // 0xc98468: mov             lr, x0
    // 0xc9846c: ldr             lr, [x21, lr, lsl #3]
    // 0xc98470: blr             lr
    // 0xc98474: add             SP, SP, #0x10
    // 0xc98478: tbnz            w0, #4, #0xc984b8
    // 0xc9847c: ldr             x1, [fp, #0x18]
    // 0xc98480: ldr             x0, [fp, #0x10]
    // 0xc98484: LoadField: r2 = r0->field_7
    //     0xc98484: ldur            w2, [x0, #7]
    // 0xc98488: DecompressPointer r2
    //     0xc98488: add             x2, x2, HEAP, lsl #32
    // 0xc9848c: LoadField: r0 = r1->field_7
    //     0xc9848c: ldur            w0, [x1, #7]
    // 0xc98490: DecompressPointer r0
    //     0xc98490: add             x0, x0, HEAP, lsl #32
    // 0xc98494: r1 = LoadClassIdInstr(r2)
    //     0xc98494: ldur            x1, [x2, #-1]
    //     0xc98498: ubfx            x1, x1, #0xc, #0x14
    // 0xc9849c: stp             x0, x2, [SP, #-0x10]!
    // 0xc984a0: mov             x0, x1
    // 0xc984a4: mov             lr, x0
    // 0xc984a8: ldr             lr, [x21, lr, lsl #3]
    // 0xc984ac: blr             lr
    // 0xc984b0: add             SP, SP, #0x10
    // 0xc984b4: b               #0xc984bc
    // 0xc984b8: r0 = false
    //     0xc984b8: add             x0, NULL, #0x30  ; false
    // 0xc984bc: LeaveFrame
    //     0xc984bc: mov             SP, fp
    //     0xc984c0: ldp             fp, lr, [SP], #0x10
    // 0xc984c4: ret
    //     0xc984c4: ret             
    // 0xc984c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc984c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc984cc: b               #0xc982fc
  }
}

// lib: , url: package:flutter/src/foundation/licenses.dart

// class id: 1049135, size: 0x8
class :: {
}

// class id: 2592, size: 0x8, field offset: 0x8
abstract class LicenseRegistry extends Object {

  static _ addLicense(/* No info */) {
    // ** addr: 0x5bd678, size: 0x128
    // 0x5bd678: EnterFrame
    //     0x5bd678: stp             fp, lr, [SP, #-0x10]!
    //     0x5bd67c: mov             fp, SP
    // 0x5bd680: AllocStack(0x10)
    //     0x5bd680: sub             SP, SP, #0x10
    // 0x5bd684: CheckStackOverflow
    //     0x5bd684: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5bd688: cmp             SP, x16
    //     0x5bd68c: b.ls            #0x5bd794
    // 0x5bd690: r0 = LoadStaticField(0xd14)
    //     0x5bd690: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5bd694: ldr             x0, [x0, #0x1a28]
    // 0x5bd698: cmp             w0, NULL
    // 0x5bd69c: b.ne            #0x5bd6c0
    // 0x5bd6a0: r16 = <(dynamic this) => Stream<LicenseEntry>>
    //     0x5bd6a0: ldr             x16, [PP, #0x5338]  ; [pp+0x5338] TypeArguments: <(dynamic this) => Stream<LicenseEntry>>
    // 0x5bd6a4: stp             xzr, x16, [SP, #-0x10]!
    // 0x5bd6a8: r0 = _GrowableList()
    //     0x5bd6a8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5bd6ac: add             SP, SP, #0x10
    // 0x5bd6b0: StoreStaticField(0xd14, r0)
    //     0x5bd6b0: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x5bd6b4: str             x0, [x1, #0x1a28]
    // 0x5bd6b8: mov             x3, x0
    // 0x5bd6bc: b               #0x5bd6c4
    // 0x5bd6c0: mov             x3, x0
    // 0x5bd6c4: stur            x3, [fp, #-8]
    // 0x5bd6c8: LoadField: r2 = r3->field_7
    //     0x5bd6c8: ldur            w2, [x3, #7]
    // 0x5bd6cc: DecompressPointer r2
    //     0x5bd6cc: add             x2, x2, HEAP, lsl #32
    // 0x5bd6d0: ldr             x0, [fp, #0x10]
    // 0x5bd6d4: r1 = Null
    //     0x5bd6d4: mov             x1, NULL
    // 0x5bd6d8: cmp             w2, NULL
    // 0x5bd6dc: b.eq            #0x5bd6f8
    // 0x5bd6e0: LoadField: r4 = r2->field_17
    //     0x5bd6e0: ldur            w4, [x2, #0x17]
    // 0x5bd6e4: DecompressPointer r4
    //     0x5bd6e4: add             x4, x4, HEAP, lsl #32
    // 0x5bd6e8: r8 = X0
    //     0x5bd6e8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5bd6ec: LoadField: r9 = r4->field_7
    //     0x5bd6ec: ldur            x9, [x4, #7]
    // 0x5bd6f0: r3 = Null
    //     0x5bd6f0: ldr             x3, [PP, #0x5340]  ; [pp+0x5340] Null
    // 0x5bd6f4: blr             x9
    // 0x5bd6f8: ldur            x0, [fp, #-8]
    // 0x5bd6fc: LoadField: r1 = r0->field_b
    //     0x5bd6fc: ldur            w1, [x0, #0xb]
    // 0x5bd700: DecompressPointer r1
    //     0x5bd700: add             x1, x1, HEAP, lsl #32
    // 0x5bd704: stur            x1, [fp, #-0x10]
    // 0x5bd708: LoadField: r2 = r0->field_f
    //     0x5bd708: ldur            w2, [x0, #0xf]
    // 0x5bd70c: DecompressPointer r2
    //     0x5bd70c: add             x2, x2, HEAP, lsl #32
    // 0x5bd710: LoadField: r3 = r2->field_b
    //     0x5bd710: ldur            w3, [x2, #0xb]
    // 0x5bd714: DecompressPointer r3
    //     0x5bd714: add             x3, x3, HEAP, lsl #32
    // 0x5bd718: cmp             w1, w3
    // 0x5bd71c: b.ne            #0x5bd72c
    // 0x5bd720: SaveReg r0
    //     0x5bd720: str             x0, [SP, #-8]!
    // 0x5bd724: r0 = _growToNextCapacity()
    //     0x5bd724: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x5bd728: add             SP, SP, #8
    // 0x5bd72c: ldur            x3, [fp, #-0x10]
    // 0x5bd730: ldur            x2, [fp, #-8]
    // 0x5bd734: r4 = LoadInt32Instr(r3)
    //     0x5bd734: sbfx            x4, x3, #1, #0x1f
    // 0x5bd738: add             x0, x4, #1
    // 0x5bd73c: lsl             x3, x0, #1
    // 0x5bd740: StoreField: r2->field_b = r3
    //     0x5bd740: stur            w3, [x2, #0xb]
    // 0x5bd744: mov             x1, x4
    // 0x5bd748: cmp             x1, x0
    // 0x5bd74c: b.hs            #0x5bd79c
    // 0x5bd750: LoadField: r1 = r2->field_f
    //     0x5bd750: ldur            w1, [x2, #0xf]
    // 0x5bd754: DecompressPointer r1
    //     0x5bd754: add             x1, x1, HEAP, lsl #32
    // 0x5bd758: ldr             x0, [fp, #0x10]
    // 0x5bd75c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x5bd75c: add             x25, x1, x4, lsl #2
    //     0x5bd760: add             x25, x25, #0xf
    //     0x5bd764: str             w0, [x25]
    //     0x5bd768: tbz             w0, #0, #0x5bd784
    //     0x5bd76c: ldurb           w16, [x1, #-1]
    //     0x5bd770: ldurb           w17, [x0, #-1]
    //     0x5bd774: and             x16, x17, x16, lsr #2
    //     0x5bd778: tst             x16, HEAP, lsr #32
    //     0x5bd77c: b.eq            #0x5bd784
    //     0x5bd780: bl              #0xd67e5c
    // 0x5bd784: r0 = Null
    //     0x5bd784: mov             x0, NULL
    // 0x5bd788: LeaveFrame
    //     0x5bd788: mov             SP, fp
    //     0x5bd78c: ldp             fp, lr, [SP], #0x10
    // 0x5bd790: ret
    //     0x5bd790: ret             
    // 0x5bd794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5bd794: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5bd798: b               #0x5bd690
    // 0x5bd79c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5bd79c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2593, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class LicenseEntry extends Object {
}

// class id: 2594, size: 0x8, field offset: 0x8
//   const constructor, 
class LicenseEntryWithLineBreaks extends LicenseEntry {
}

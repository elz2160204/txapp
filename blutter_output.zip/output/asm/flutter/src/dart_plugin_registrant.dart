// lib: , url: package:flutter/src/dart_plugin_registrant.dart

// class id: 1049118, size: 0x8
class :: {

  static late final const String dartPluginRegistrantLibrary; // offset: 0xfa0

  const String dartPluginRegistrantLibrary() {
    // ** addr: 0xd707b4, size: 0x8
    // 0xd707b4: r0 = "file:///var/www/html/flutter3/tx_app/.dart_tool/flutter_build/dart_plugin_registrant.dart"
    //     0xd707b4: ldr             x0, [PP, #0x58]  ; [pp+0x58] "file:///var/www/html/flutter3/tx_app/.dart_tool/flutter_build/dart_plugin_registrant.dart"
    // 0xd707b8: ret
    //     0xd707b8: ret             
  }
}

// lib: , url: package:flutter/src/gestures/multitap.dart

// class id: 1049165, size: 0x8
class :: {
}

// class id: 2267, size: 0x28, field offset: 0x8
class _TapTracker extends Object {

  _ startTrackingPointer(/* No info */) {
    // ** addr: 0x784698, size: 0x80
    // 0x784698: EnterFrame
    //     0x784698: stp             fp, lr, [SP, #-0x10]!
    //     0x78469c: mov             fp, SP
    // 0x7846a0: CheckStackOverflow
    //     0x7846a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7846a4: cmp             SP, x16
    //     0x7846a8: b.ls            #0x78470c
    // 0x7846ac: ldr             x0, [fp, #0x20]
    // 0x7846b0: LoadField: r1 = r0->field_23
    //     0x7846b0: ldur            w1, [x0, #0x23]
    // 0x7846b4: DecompressPointer r1
    //     0x7846b4: add             x1, x1, HEAP, lsl #32
    // 0x7846b8: tbz             w1, #4, #0x7846fc
    // 0x7846bc: r1 = true
    //     0x7846bc: add             x1, NULL, #0x20  ; true
    // 0x7846c0: StoreField: r0->field_23 = r1
    //     0x7846c0: stur            w1, [x0, #0x23]
    // 0x7846c4: r1 = LoadStaticField(0xd54)
    //     0x7846c4: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x7846c8: ldr             x1, [x1, #0x1aa8]
    // 0x7846cc: cmp             w1, NULL
    // 0x7846d0: b.eq            #0x784714
    // 0x7846d4: LoadField: r2 = r1->field_13
    //     0x7846d4: ldur            w2, [x1, #0x13]
    // 0x7846d8: DecompressPointer r2
    //     0x7846d8: add             x2, x2, HEAP, lsl #32
    // 0x7846dc: LoadField: r1 = r0->field_7
    //     0x7846dc: ldur            x1, [x0, #7]
    // 0x7846e0: stp             x1, x2, [SP, #-0x10]!
    // 0x7846e4: ldr             x16, [fp, #0x18]
    // 0x7846e8: ldr             lr, [fp, #0x10]
    // 0x7846ec: stp             lr, x16, [SP, #-0x10]!
    // 0x7846f0: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x7846f0: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x7846f4: r0 = addRoute()
    //     0x7846f4: bl              #0x711788  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addRoute
    // 0x7846f8: add             SP, SP, #0x20
    // 0x7846fc: r0 = Null
    //     0x7846fc: mov             x0, NULL
    // 0x784700: LeaveFrame
    //     0x784700: mov             SP, fp
    //     0x784704: ldp             fp, lr, [SP], #0x10
    // 0x784708: ret
    //     0x784708: ret             
    // 0x78470c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78470c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784710: b               #0x7846ac
    // 0x784714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x784714: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _TapTracker(/* No info */) {
    // ** addr: 0x784738, size: 0x130
    // 0x784738: EnterFrame
    //     0x784738: stp             fp, lr, [SP, #-0x10]!
    //     0x78473c: mov             fp, SP
    // 0x784740: AllocStack(0x8)
    //     0x784740: sub             SP, SP, #8
    // 0x784744: r0 = false
    //     0x784744: add             x0, NULL, #0x30  ; false
    // 0x784748: CheckStackOverflow
    //     0x784748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78474c: cmp             SP, x16
    //     0x784750: b.ls            #0x784860
    // 0x784754: ldr             x1, [fp, #0x20]
    // 0x784758: StoreField: r1->field_23 = r0
    //     0x784758: stur            w0, [x1, #0x23]
    // 0x78475c: ldr             x0, [fp, #0x18]
    // 0x784760: StoreField: r1->field_f = r0
    //     0x784760: stur            w0, [x1, #0xf]
    //     0x784764: ldurb           w16, [x1, #-1]
    //     0x784768: ldurb           w17, [x0, #-1]
    //     0x78476c: and             x16, x17, x16, lsr #2
    //     0x784770: tst             x16, HEAP, lsr #32
    //     0x784774: b.eq            #0x78477c
    //     0x784778: bl              #0xd6826c
    // 0x78477c: ldr             x2, [fp, #0x10]
    // 0x784780: r0 = LoadClassIdInstr(r2)
    //     0x784780: ldur            x0, [x2, #-1]
    //     0x784784: ubfx            x0, x0, #0xc, #0x14
    // 0x784788: SaveReg r2
    //     0x784788: str             x2, [SP, #-8]!
    // 0x78478c: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78478c: sub             lr, x0, #0xfff
    //     0x784790: ldr             lr, [x21, lr, lsl #3]
    //     0x784794: blr             lr
    // 0x784798: add             SP, SP, #8
    // 0x78479c: ldr             x1, [fp, #0x20]
    // 0x7847a0: StoreField: r1->field_7 = r0
    //     0x7847a0: stur            x0, [x1, #7]
    // 0x7847a4: ldr             x2, [fp, #0x10]
    // 0x7847a8: r0 = LoadClassIdInstr(r2)
    //     0x7847a8: ldur            x0, [x2, #-1]
    //     0x7847ac: ubfx            x0, x0, #0xc, #0x14
    // 0x7847b0: SaveReg r2
    //     0x7847b0: str             x2, [SP, #-8]!
    // 0x7847b4: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x7847b4: sub             lr, x0, #0xfd9
    //     0x7847b8: ldr             lr, [x21, lr, lsl #3]
    //     0x7847bc: blr             lr
    // 0x7847c0: add             SP, SP, #8
    // 0x7847c4: ldr             x1, [fp, #0x20]
    // 0x7847c8: StoreField: r1->field_13 = r0
    //     0x7847c8: stur            w0, [x1, #0x13]
    //     0x7847cc: ldurb           w16, [x1, #-1]
    //     0x7847d0: ldurb           w17, [x0, #-1]
    //     0x7847d4: and             x16, x17, x16, lsr #2
    //     0x7847d8: tst             x16, HEAP, lsr #32
    //     0x7847dc: b.eq            #0x7847e4
    //     0x7847e0: bl              #0xd6826c
    // 0x7847e4: ldr             x0, [fp, #0x10]
    // 0x7847e8: r2 = LoadClassIdInstr(r0)
    //     0x7847e8: ldur            x2, [x0, #-1]
    //     0x7847ec: ubfx            x2, x2, #0xc, #0x14
    // 0x7847f0: SaveReg r0
    //     0x7847f0: str             x0, [SP, #-8]!
    // 0x7847f4: mov             x0, x2
    // 0x7847f8: r0 = GDT[cid_x0 + 0x271c]()
    //     0x7847f8: mov             x17, #0x271c
    //     0x7847fc: add             lr, x0, x17
    //     0x784800: ldr             lr, [x21, lr, lsl #3]
    //     0x784804: blr             lr
    // 0x784808: add             SP, SP, #8
    // 0x78480c: mov             x1, x0
    // 0x784810: ldr             x0, [fp, #0x20]
    // 0x784814: StoreField: r0->field_17 = r1
    //     0x784814: stur            x1, [x0, #0x17]
    // 0x784818: r0 = _CountdownZoned()
    //     0x784818: bl              #0x784938  ; Allocate_CountdownZonedStub -> _CountdownZoned (size=0xc)
    // 0x78481c: stur            x0, [fp, #-8]
    // 0x784820: SaveReg r0
    //     0x784820: str             x0, [SP, #-8]!
    // 0x784824: r0 = _CountdownZoned()
    //     0x784824: bl              #0x784868  ; [package:flutter/src/gestures/multitap.dart] _CountdownZoned::_CountdownZoned
    // 0x784828: add             SP, SP, #8
    // 0x78482c: ldur            x0, [fp, #-8]
    // 0x784830: ldr             x1, [fp, #0x20]
    // 0x784834: StoreField: r1->field_1f = r0
    //     0x784834: stur            w0, [x1, #0x1f]
    //     0x784838: ldurb           w16, [x1, #-1]
    //     0x78483c: ldurb           w17, [x0, #-1]
    //     0x784840: and             x16, x17, x16, lsr #2
    //     0x784844: tst             x16, HEAP, lsr #32
    //     0x784848: b.eq            #0x784850
    //     0x78484c: bl              #0xd6826c
    // 0x784850: r0 = Null
    //     0x784850: mov             x0, NULL
    // 0x784854: LeaveFrame
    //     0x784854: mov             SP, fp
    //     0x784858: ldp             fp, lr, [SP], #0x10
    // 0x78485c: ret
    //     0x78485c: ret             
    // 0x784860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x784860: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784864: b               #0x784754
  }
  _ stopTrackingPointer(/* No info */) {
    // ** addr: 0x784da4, size: 0x78
    // 0x784da4: EnterFrame
    //     0x784da4: stp             fp, lr, [SP, #-0x10]!
    //     0x784da8: mov             fp, SP
    // 0x784dac: CheckStackOverflow
    //     0x784dac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784db0: cmp             SP, x16
    //     0x784db4: b.ls            #0x784e10
    // 0x784db8: ldr             x0, [fp, #0x18]
    // 0x784dbc: LoadField: r1 = r0->field_23
    //     0x784dbc: ldur            w1, [x0, #0x23]
    // 0x784dc0: DecompressPointer r1
    //     0x784dc0: add             x1, x1, HEAP, lsl #32
    // 0x784dc4: tbnz            w1, #4, #0x784e00
    // 0x784dc8: r1 = false
    //     0x784dc8: add             x1, NULL, #0x30  ; false
    // 0x784dcc: StoreField: r0->field_23 = r1
    //     0x784dcc: stur            w1, [x0, #0x23]
    // 0x784dd0: r1 = LoadStaticField(0xd54)
    //     0x784dd0: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x784dd4: ldr             x1, [x1, #0x1aa8]
    // 0x784dd8: cmp             w1, NULL
    // 0x784ddc: b.eq            #0x784e18
    // 0x784de0: LoadField: r2 = r1->field_13
    //     0x784de0: ldur            w2, [x1, #0x13]
    // 0x784de4: DecompressPointer r2
    //     0x784de4: add             x2, x2, HEAP, lsl #32
    // 0x784de8: LoadField: r1 = r0->field_7
    //     0x784de8: ldur            x1, [x0, #7]
    // 0x784dec: stp             x1, x2, [SP, #-0x10]!
    // 0x784df0: ldr             x16, [fp, #0x10]
    // 0x784df4: SaveReg r16
    //     0x784df4: str             x16, [SP, #-8]!
    // 0x784df8: r0 = removeRoute()
    //     0x784df8: bl              #0x7134d4  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::removeRoute
    // 0x784dfc: add             SP, SP, #0x18
    // 0x784e00: r0 = Null
    //     0x784e00: mov             x0, NULL
    // 0x784e04: LeaveFrame
    //     0x784e04: mov             SP, fp
    //     0x784e08: ldp             fp, lr, [SP], #0x10
    // 0x784e0c: ret
    //     0x784e0c: ret             
    // 0x784e10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x784e10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784e14: b               #0x784db8
    // 0x784e18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x784e18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hasSameButton(/* No info */) {
    // ** addr: 0x7853ec, size: 0x6c
    // 0x7853ec: EnterFrame
    //     0x7853ec: stp             fp, lr, [SP, #-0x10]!
    //     0x7853f0: mov             fp, SP
    // 0x7853f4: CheckStackOverflow
    //     0x7853f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7853f8: cmp             SP, x16
    //     0x7853fc: b.ls            #0x785450
    // 0x785400: ldr             x0, [fp, #0x10]
    // 0x785404: r1 = LoadClassIdInstr(r0)
    //     0x785404: ldur            x1, [x0, #-1]
    //     0x785408: ubfx            x1, x1, #0xc, #0x14
    // 0x78540c: SaveReg r0
    //     0x78540c: str             x0, [SP, #-8]!
    // 0x785410: mov             x0, x1
    // 0x785414: r0 = GDT[cid_x0 + 0x271c]()
    //     0x785414: mov             x17, #0x271c
    //     0x785418: add             lr, x0, x17
    //     0x78541c: ldr             lr, [x21, lr, lsl #3]
    //     0x785420: blr             lr
    // 0x785424: add             SP, SP, #8
    // 0x785428: ldr             x1, [fp, #0x18]
    // 0x78542c: LoadField: r2 = r1->field_17
    //     0x78542c: ldur            x2, [x1, #0x17]
    // 0x785430: cmp             x0, x2
    // 0x785434: r16 = true
    //     0x785434: add             x16, NULL, #0x20  ; true
    // 0x785438: r17 = false
    //     0x785438: add             x17, NULL, #0x30  ; false
    // 0x78543c: csel            x1, x16, x17, eq
    // 0x785440: mov             x0, x1
    // 0x785444: LeaveFrame
    //     0x785444: mov             SP, fp
    //     0x785448: ldp             fp, lr, [SP], #0x10
    // 0x78544c: ret
    //     0x78544c: ret             
    // 0x785450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x785450: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x785454: b               #0x785400
  }
  _ hasElapsedMinTime(/* No info */) {
    // ** addr: 0x785458, size: 0x18
    // 0x785458: ldr             x1, [SP]
    // 0x78545c: LoadField: r2 = r1->field_1f
    //     0x78545c: ldur            w2, [x1, #0x1f]
    // 0x785460: DecompressPointer r2
    //     0x785460: add             x2, x2, HEAP, lsl #32
    // 0x785464: LoadField: r0 = r2->field_7
    //     0x785464: ldur            w0, [x2, #7]
    // 0x785468: DecompressPointer r0
    //     0x785468: add             x0, x0, HEAP, lsl #32
    // 0x78546c: ret
    //     0x78546c: ret             
  }
  _ isWithinGlobalTolerance(/* No info */) {
    // ** addr: 0x785470, size: 0x9c
    // 0x785470: EnterFrame
    //     0x785470: stp             fp, lr, [SP, #-0x10]!
    //     0x785474: mov             fp, SP
    // 0x785478: CheckStackOverflow
    //     0x785478: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78547c: cmp             SP, x16
    //     0x785480: b.ls            #0x785504
    // 0x785484: ldr             x0, [fp, #0x18]
    // 0x785488: r1 = LoadClassIdInstr(r0)
    //     0x785488: ldur            x1, [x0, #-1]
    //     0x78548c: ubfx            x1, x1, #0xc, #0x14
    // 0x785490: SaveReg r0
    //     0x785490: str             x0, [SP, #-8]!
    // 0x785494: mov             x0, x1
    // 0x785498: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x785498: sub             lr, x0, #0xfd9
    //     0x78549c: ldr             lr, [x21, lr, lsl #3]
    //     0x7854a0: blr             lr
    // 0x7854a4: add             SP, SP, #8
    // 0x7854a8: mov             x1, x0
    // 0x7854ac: ldr             x0, [fp, #0x20]
    // 0x7854b0: LoadField: r2 = r0->field_13
    //     0x7854b0: ldur            w2, [x0, #0x13]
    // 0x7854b4: DecompressPointer r2
    //     0x7854b4: add             x2, x2, HEAP, lsl #32
    // 0x7854b8: stp             x2, x1, [SP, #-0x10]!
    // 0x7854bc: r0 = -()
    //     0x7854bc: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x7854c0: add             SP, SP, #0x10
    // 0x7854c4: LoadField: d0 = r0->field_7
    //     0x7854c4: ldur            d0, [x0, #7]
    // 0x7854c8: fmul            d1, d0, d0
    // 0x7854cc: LoadField: d0 = r0->field_f
    //     0x7854cc: ldur            d0, [x0, #0xf]
    // 0x7854d0: fmul            d2, d0, d0
    // 0x7854d4: fadd            d0, d1, d2
    // 0x7854d8: fsqrt           d1, d0
    // 0x7854dc: ldr             d0, [fp, #0x10]
    // 0x7854e0: fcmp            d1, d0
    // 0x7854e4: b.vs            #0x7854ec
    // 0x7854e8: b.le            #0x7854f4
    // 0x7854ec: r0 = false
    //     0x7854ec: add             x0, NULL, #0x30  ; false
    // 0x7854f0: b               #0x7854f8
    // 0x7854f4: r0 = true
    //     0x7854f4: add             x0, NULL, #0x20  ; true
    // 0x7854f8: LeaveFrame
    //     0x7854f8: mov             SP, fp
    //     0x7854fc: ldp             fp, lr, [SP], #0x10
    // 0x785500: ret
    //     0x785500: ret             
    // 0x785504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x785504: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x785508: b               #0x785484
  }
}

// class id: 2268, size: 0xc, field offset: 0x8
class _CountdownZoned extends Object {

  _ _CountdownZoned(/* No info */) {
    // ** addr: 0x784868, size: 0x74
    // 0x784868: EnterFrame
    //     0x784868: stp             fp, lr, [SP, #-0x10]!
    //     0x78486c: mov             fp, SP
    // 0x784870: r0 = false
    //     0x784870: add             x0, NULL, #0x30  ; false
    // 0x784874: CheckStackOverflow
    //     0x784874: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784878: cmp             SP, x16
    //     0x78487c: b.ls            #0x7848d4
    // 0x784880: ldr             x1, [fp, #0x10]
    // 0x784884: StoreField: r1->field_7 = r0
    //     0x784884: stur            w0, [x1, #7]
    // 0x784888: r1 = 1
    //     0x784888: mov             x1, #1
    // 0x78488c: r0 = AllocateContext()
    //     0x78488c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x784890: mov             x1, x0
    // 0x784894: ldr             x0, [fp, #0x10]
    // 0x784898: StoreField: r1->field_f = r0
    //     0x784898: stur            w0, [x1, #0xf]
    // 0x78489c: mov             x2, x1
    // 0x7848a0: r1 = Function '_onTimeout@668391311':.
    //     0x7848a0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ee8] AnonymousClosure: (0x7848dc), in [package:flutter/src/gestures/multitap.dart] _CountdownZoned::_onTimeout (0x784924)
    //     0x7848a4: ldr             x1, [x1, #0xee8]
    // 0x7848a8: r0 = AllocateClosure()
    //     0x7848a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7848ac: r16 = Instance_Duration
    //     0x7848ac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ef0] Obj!Duration@b67b21
    //     0x7848b0: ldr             x16, [x16, #0xef0]
    // 0x7848b4: stp             x16, NULL, [SP, #-0x10]!
    // 0x7848b8: SaveReg r0
    //     0x7848b8: str             x0, [SP, #-8]!
    // 0x7848bc: r0 = Timer()
    //     0x7848bc: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x7848c0: add             SP, SP, #0x18
    // 0x7848c4: r0 = Null
    //     0x7848c4: mov             x0, NULL
    // 0x7848c8: LeaveFrame
    //     0x7848c8: mov             SP, fp
    //     0x7848cc: ldp             fp, lr, [SP], #0x10
    // 0x7848d0: ret
    //     0x7848d0: ret             
    // 0x7848d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7848d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7848d8: b               #0x784880
  }
  [closure] void _onTimeout(dynamic) {
    // ** addr: 0x7848dc, size: 0x48
    // 0x7848dc: EnterFrame
    //     0x7848dc: stp             fp, lr, [SP, #-0x10]!
    //     0x7848e0: mov             fp, SP
    // 0x7848e4: ldr             x0, [fp, #0x10]
    // 0x7848e8: LoadField: r1 = r0->field_17
    //     0x7848e8: ldur            w1, [x0, #0x17]
    // 0x7848ec: DecompressPointer r1
    //     0x7848ec: add             x1, x1, HEAP, lsl #32
    // 0x7848f0: CheckStackOverflow
    //     0x7848f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7848f4: cmp             SP, x16
    //     0x7848f8: b.ls            #0x78491c
    // 0x7848fc: LoadField: r0 = r1->field_f
    //     0x7848fc: ldur            w0, [x1, #0xf]
    // 0x784900: DecompressPointer r0
    //     0x784900: add             x0, x0, HEAP, lsl #32
    // 0x784904: SaveReg r0
    //     0x784904: str             x0, [SP, #-8]!
    // 0x784908: r0 = _onTimeout()
    //     0x784908: bl              #0x784924  ; [package:flutter/src/gestures/multitap.dart] _CountdownZoned::_onTimeout
    // 0x78490c: add             SP, SP, #8
    // 0x784910: LeaveFrame
    //     0x784910: mov             SP, fp
    //     0x784914: ldp             fp, lr, [SP], #0x10
    // 0x784918: ret
    //     0x784918: ret             
    // 0x78491c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78491c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784920: b               #0x7848fc
  }
  _ _onTimeout(/* No info */) {
    // ** addr: 0x784924, size: 0x14
    // 0x784924: r1 = true
    //     0x784924: add             x1, NULL, #0x20  ; true
    // 0x784928: ldr             x2, [SP]
    // 0x78492c: StoreField: r2->field_7 = r1
    //     0x78492c: stur            w1, [x2, #7]
    // 0x784930: r0 = Null
    //     0x784930: mov             x0, NULL
    // 0x784934: ret
    //     0x784934: ret             
  }
}

// class id: 2344, size: 0x2c, field offset: 0x14
class DoubleTapGestureRecognizer extends GestureRecognizer {

  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x7843e4, size: 0x10c
    // 0x7843e4: EnterFrame
    //     0x7843e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7843e8: mov             fp, SP
    // 0x7843ec: CheckStackOverflow
    //     0x7843ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7843f0: cmp             SP, x16
    //     0x7843f4: b.ls            #0x7844e0
    // 0x7843f8: ldr             x0, [fp, #0x18]
    // 0x7843fc: LoadField: r1 = r0->field_23
    //     0x7843fc: ldur            w1, [x0, #0x23]
    // 0x784400: DecompressPointer r1
    //     0x784400: add             x1, x1, HEAP, lsl #32
    // 0x784404: cmp             w1, NULL
    // 0x784408: b.eq            #0x7844bc
    // 0x78440c: d0 = 100.000000
    //     0x78440c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x784410: ldr             d0, [x17, #0x308]
    // 0x784414: ldr             x16, [fp, #0x10]
    // 0x784418: stp             x16, x1, [SP, #-0x10]!
    // 0x78441c: SaveReg d0
    //     0x78441c: str             d0, [SP, #-8]!
    // 0x784420: r0 = isWithinGlobalTolerance()
    //     0x784420: bl              #0x785470  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::isWithinGlobalTolerance
    // 0x784424: add             SP, SP, #0x18
    // 0x784428: tbz             w0, #4, #0x78443c
    // 0x78442c: r0 = Null
    //     0x78442c: mov             x0, NULL
    // 0x784430: LeaveFrame
    //     0x784430: mov             SP, fp
    //     0x784434: ldp             fp, lr, [SP], #0x10
    // 0x784438: ret
    //     0x784438: ret             
    // 0x78443c: ldr             x0, [fp, #0x18]
    // 0x784440: LoadField: r1 = r0->field_23
    //     0x784440: ldur            w1, [x0, #0x23]
    // 0x784444: DecompressPointer r1
    //     0x784444: add             x1, x1, HEAP, lsl #32
    // 0x784448: cmp             w1, NULL
    // 0x78444c: b.eq            #0x7844e8
    // 0x784450: SaveReg r1
    //     0x784450: str             x1, [SP, #-8]!
    // 0x784454: r0 = hasElapsedMinTime()
    //     0x784454: bl              #0x785458  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::hasElapsedMinTime
    // 0x784458: add             SP, SP, #8
    // 0x78445c: tbnz            w0, #4, #0x784488
    // 0x784460: ldr             x0, [fp, #0x18]
    // 0x784464: LoadField: r1 = r0->field_23
    //     0x784464: ldur            w1, [x0, #0x23]
    // 0x784468: DecompressPointer r1
    //     0x784468: add             x1, x1, HEAP, lsl #32
    // 0x78446c: cmp             w1, NULL
    // 0x784470: b.eq            #0x7844ec
    // 0x784474: ldr             x16, [fp, #0x10]
    // 0x784478: stp             x16, x1, [SP, #-0x10]!
    // 0x78447c: r0 = hasSameButton()
    //     0x78447c: bl              #0x7853ec  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::hasSameButton
    // 0x784480: add             SP, SP, #0x10
    // 0x784484: tbz             w0, #4, #0x7844bc
    // 0x784488: ldr             x16, [fp, #0x18]
    // 0x78448c: SaveReg r16
    //     0x78448c: str             x16, [SP, #-8]!
    // 0x784490: r0 = _reset()
    //     0x784490: bl              #0x78527c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0x784494: add             SP, SP, #8
    // 0x784498: ldr             x16, [fp, #0x18]
    // 0x78449c: ldr             lr, [fp, #0x10]
    // 0x7844a0: stp             lr, x16, [SP, #-0x10]!
    // 0x7844a4: r0 = _trackTap()
    //     0x7844a4: bl              #0x784510  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_trackTap
    // 0x7844a8: add             SP, SP, #0x10
    // 0x7844ac: r0 = Null
    //     0x7844ac: mov             x0, NULL
    // 0x7844b0: LeaveFrame
    //     0x7844b0: mov             SP, fp
    //     0x7844b4: ldp             fp, lr, [SP], #0x10
    // 0x7844b8: ret
    //     0x7844b8: ret             
    // 0x7844bc: ldr             x16, [fp, #0x18]
    // 0x7844c0: ldr             lr, [fp, #0x10]
    // 0x7844c4: stp             lr, x16, [SP, #-0x10]!
    // 0x7844c8: r0 = _trackTap()
    //     0x7844c8: bl              #0x784510  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_trackTap
    // 0x7844cc: add             SP, SP, #0x10
    // 0x7844d0: r0 = Null
    //     0x7844d0: mov             x0, NULL
    // 0x7844d4: LeaveFrame
    //     0x7844d4: mov             SP, fp
    //     0x7844d8: ldp             fp, lr, [SP], #0x10
    // 0x7844dc: ret
    //     0x7844dc: ret             
    // 0x7844e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7844e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7844e4: b               #0x7843f8
    // 0x7844e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7844e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7844ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7844ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _trackTap(/* No info */) {
    // ** addr: 0x784510, size: 0x188
    // 0x784510: EnterFrame
    //     0x784510: stp             fp, lr, [SP, #-0x10]!
    //     0x784514: mov             fp, SP
    // 0x784518: AllocStack(0x10)
    //     0x784518: sub             SP, SP, #0x10
    // 0x78451c: CheckStackOverflow
    //     0x78451c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784520: cmp             SP, x16
    //     0x784524: b.ls            #0x78468c
    // 0x784528: ldr             x16, [fp, #0x18]
    // 0x78452c: SaveReg r16
    //     0x78452c: str             x16, [SP, #-8]!
    // 0x784530: r0 = _stopDoubleTapTimer()
    //     0x784530: bl              #0x784950  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_stopDoubleTapTimer
    // 0x784534: add             SP, SP, #8
    // 0x784538: r0 = LoadStaticField(0xd54)
    //     0x784538: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x78453c: ldr             x0, [x0, #0x1aa8]
    // 0x784540: cmp             w0, NULL
    // 0x784544: b.eq            #0x784694
    // 0x784548: LoadField: r1 = r0->field_17
    //     0x784548: ldur            w1, [x0, #0x17]
    // 0x78454c: DecompressPointer r1
    //     0x78454c: add             x1, x1, HEAP, lsl #32
    // 0x784550: ldr             x2, [fp, #0x10]
    // 0x784554: stur            x1, [fp, #-8]
    // 0x784558: r0 = LoadClassIdInstr(r2)
    //     0x784558: ldur            x0, [x2, #-1]
    //     0x78455c: ubfx            x0, x0, #0xc, #0x14
    // 0x784560: SaveReg r2
    //     0x784560: str             x2, [SP, #-8]!
    // 0x784564: r0 = GDT[cid_x0 + -0xfff]()
    //     0x784564: sub             lr, x0, #0xfff
    //     0x784568: ldr             lr, [x21, lr, lsl #3]
    //     0x78456c: blr             lr
    // 0x784570: add             SP, SP, #8
    // 0x784574: ldur            x16, [fp, #-8]
    // 0x784578: stp             x0, x16, [SP, #-0x10]!
    // 0x78457c: ldr             x16, [fp, #0x18]
    // 0x784580: SaveReg r16
    //     0x784580: str             x16, [SP, #-8]!
    // 0x784584: r0 = add()
    //     0x784584: bl              #0x7112b0  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::add
    // 0x784588: add             SP, SP, #0x18
    // 0x78458c: stur            x0, [fp, #-8]
    // 0x784590: r0 = _TapTracker()
    //     0x784590: bl              #0x784944  ; Allocate_TapTrackerStub -> _TapTracker (size=0x28)
    // 0x784594: stur            x0, [fp, #-0x10]
    // 0x784598: ldur            x16, [fp, #-8]
    // 0x78459c: stp             x16, x0, [SP, #-0x10]!
    // 0x7845a0: ldr             x16, [fp, #0x10]
    // 0x7845a4: SaveReg r16
    //     0x7845a4: str             x16, [SP, #-8]!
    // 0x7845a8: r0 = _TapTracker()
    //     0x7845a8: bl              #0x784738  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::_TapTracker
    // 0x7845ac: add             SP, SP, #0x18
    // 0x7845b0: ldr             x1, [fp, #0x18]
    // 0x7845b4: LoadField: r2 = r1->field_27
    //     0x7845b4: ldur            w2, [x1, #0x27]
    // 0x7845b8: DecompressPointer r2
    //     0x7845b8: add             x2, x2, HEAP, lsl #32
    // 0x7845bc: ldr             x3, [fp, #0x10]
    // 0x7845c0: stur            x2, [fp, #-8]
    // 0x7845c4: r0 = LoadClassIdInstr(r3)
    //     0x7845c4: ldur            x0, [x3, #-1]
    //     0x7845c8: ubfx            x0, x0, #0xc, #0x14
    // 0x7845cc: SaveReg r3
    //     0x7845cc: str             x3, [SP, #-8]!
    // 0x7845d0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x7845d0: sub             lr, x0, #0xfff
    //     0x7845d4: ldr             lr, [x21, lr, lsl #3]
    //     0x7845d8: blr             lr
    // 0x7845dc: add             SP, SP, #8
    // 0x7845e0: mov             x2, x0
    // 0x7845e4: r0 = BoxInt64Instr(r2)
    //     0x7845e4: sbfiz           x0, x2, #1, #0x1f
    //     0x7845e8: cmp             x2, x0, asr #1
    //     0x7845ec: b.eq            #0x7845f8
    //     0x7845f0: bl              #0xd69bb8
    //     0x7845f4: stur            x2, [x0, #7]
    // 0x7845f8: ldur            x16, [fp, #-8]
    // 0x7845fc: stp             x0, x16, [SP, #-0x10]!
    // 0x784600: ldur            x16, [fp, #-0x10]
    // 0x784604: SaveReg r16
    //     0x784604: str             x16, [SP, #-8]!
    // 0x784608: r0 = []=()
    //     0x784608: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x78460c: add             SP, SP, #0x18
    // 0x784610: r1 = 1
    //     0x784610: mov             x1, #1
    // 0x784614: r0 = AllocateContext()
    //     0x784614: bl              #0xd68aa4  ; AllocateContextStub
    // 0x784618: mov             x1, x0
    // 0x78461c: ldr             x0, [fp, #0x18]
    // 0x784620: stur            x1, [fp, #-8]
    // 0x784624: StoreField: r1->field_f = r0
    //     0x784624: stur            w0, [x1, #0xf]
    // 0x784628: ldr             x0, [fp, #0x10]
    // 0x78462c: r2 = LoadClassIdInstr(r0)
    //     0x78462c: ldur            x2, [x0, #-1]
    //     0x784630: ubfx            x2, x2, #0xc, #0x14
    // 0x784634: SaveReg r0
    //     0x784634: str             x0, [SP, #-8]!
    // 0x784638: mov             x0, x2
    // 0x78463c: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x78463c: mov             x17, #0x3f6e
    //     0x784640: add             lr, x0, x17
    //     0x784644: ldr             lr, [x21, lr, lsl #3]
    //     0x784648: blr             lr
    // 0x78464c: add             SP, SP, #8
    // 0x784650: ldur            x2, [fp, #-8]
    // 0x784654: r1 = Function '_handleEvent@668391311':.
    //     0x784654: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ec8] AnonymousClosure: (0x7849a4), in [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_handleEvent (0x7849f0)
    //     0x784658: ldr             x1, [x1, #0xec8]
    // 0x78465c: stur            x0, [fp, #-8]
    // 0x784660: r0 = AllocateClosure()
    //     0x784660: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x784664: ldur            x16, [fp, #-0x10]
    // 0x784668: stp             x0, x16, [SP, #-0x10]!
    // 0x78466c: ldur            x16, [fp, #-8]
    // 0x784670: SaveReg r16
    //     0x784670: str             x16, [SP, #-8]!
    // 0x784674: r0 = startTrackingPointer()
    //     0x784674: bl              #0x784698  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::startTrackingPointer
    // 0x784678: add             SP, SP, #0x18
    // 0x78467c: r0 = Null
    //     0x78467c: mov             x0, NULL
    // 0x784680: LeaveFrame
    //     0x784680: mov             SP, fp
    //     0x784684: ldp             fp, lr, [SP], #0x10
    // 0x784688: ret
    //     0x784688: ret             
    // 0x78468c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78468c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784690: b               #0x784528
    // 0x784694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x784694: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _stopDoubleTapTimer(/* No info */) {
    // ** addr: 0x784950, size: 0x54
    // 0x784950: EnterFrame
    //     0x784950: stp             fp, lr, [SP, #-0x10]!
    //     0x784954: mov             fp, SP
    // 0x784958: CheckStackOverflow
    //     0x784958: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78495c: cmp             SP, x16
    //     0x784960: b.ls            #0x78499c
    // 0x784964: ldr             x0, [fp, #0x10]
    // 0x784968: LoadField: r1 = r0->field_1f
    //     0x784968: ldur            w1, [x0, #0x1f]
    // 0x78496c: DecompressPointer r1
    //     0x78496c: add             x1, x1, HEAP, lsl #32
    // 0x784970: cmp             w1, NULL
    // 0x784974: b.eq            #0x78498c
    // 0x784978: SaveReg r1
    //     0x784978: str             x1, [SP, #-8]!
    // 0x78497c: r0 = cancel()
    //     0x78497c: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x784980: add             SP, SP, #8
    // 0x784984: ldr             x1, [fp, #0x10]
    // 0x784988: StoreField: r1->field_1f = rNULL
    //     0x784988: stur            NULL, [x1, #0x1f]
    // 0x78498c: r0 = Null
    //     0x78498c: mov             x0, NULL
    // 0x784990: LeaveFrame
    //     0x784990: mov             SP, fp
    //     0x784994: ldp             fp, lr, [SP], #0x10
    // 0x784998: ret
    //     0x784998: ret             
    // 0x78499c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78499c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7849a0: b               #0x784964
  }
  [closure] void _handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x7849a4, size: 0x4c
    // 0x7849a4: EnterFrame
    //     0x7849a4: stp             fp, lr, [SP, #-0x10]!
    //     0x7849a8: mov             fp, SP
    // 0x7849ac: ldr             x0, [fp, #0x18]
    // 0x7849b0: LoadField: r1 = r0->field_17
    //     0x7849b0: ldur            w1, [x0, #0x17]
    // 0x7849b4: DecompressPointer r1
    //     0x7849b4: add             x1, x1, HEAP, lsl #32
    // 0x7849b8: CheckStackOverflow
    //     0x7849b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7849bc: cmp             SP, x16
    //     0x7849c0: b.ls            #0x7849e8
    // 0x7849c4: LoadField: r0 = r1->field_f
    //     0x7849c4: ldur            w0, [x1, #0xf]
    // 0x7849c8: DecompressPointer r0
    //     0x7849c8: add             x0, x0, HEAP, lsl #32
    // 0x7849cc: ldr             x16, [fp, #0x10]
    // 0x7849d0: stp             x16, x0, [SP, #-0x10]!
    // 0x7849d4: r0 = _handleEvent()
    //     0x7849d4: bl              #0x7849f0  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_handleEvent
    // 0x7849d8: add             SP, SP, #0x10
    // 0x7849dc: LeaveFrame
    //     0x7849dc: mov             SP, fp
    //     0x7849e0: ldp             fp, lr, [SP], #0x10
    // 0x7849e4: ret
    //     0x7849e4: ret             
    // 0x7849e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7849e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7849ec: b               #0x7849c4
  }
  _ _handleEvent(/* No info */) {
    // ** addr: 0x7849f0, size: 0x208
    // 0x7849f0: EnterFrame
    //     0x7849f0: stp             fp, lr, [SP, #-0x10]!
    //     0x7849f4: mov             fp, SP
    // 0x7849f8: AllocStack(0x8)
    //     0x7849f8: sub             SP, SP, #8
    // 0x7849fc: CheckStackOverflow
    //     0x7849fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784a00: cmp             SP, x16
    //     0x784a04: b.ls            #0x784bec
    // 0x784a08: ldr             x1, [fp, #0x18]
    // 0x784a0c: LoadField: r2 = r1->field_27
    //     0x784a0c: ldur            w2, [x1, #0x27]
    // 0x784a10: DecompressPointer r2
    //     0x784a10: add             x2, x2, HEAP, lsl #32
    // 0x784a14: ldr             x3, [fp, #0x10]
    // 0x784a18: stur            x2, [fp, #-8]
    // 0x784a1c: r0 = LoadClassIdInstr(r3)
    //     0x784a1c: ldur            x0, [x3, #-1]
    //     0x784a20: ubfx            x0, x0, #0xc, #0x14
    // 0x784a24: SaveReg r3
    //     0x784a24: str             x3, [SP, #-8]!
    // 0x784a28: r0 = GDT[cid_x0 + -0xfff]()
    //     0x784a28: sub             lr, x0, #0xfff
    //     0x784a2c: ldr             lr, [x21, lr, lsl #3]
    //     0x784a30: blr             lr
    // 0x784a34: add             SP, SP, #8
    // 0x784a38: mov             x2, x0
    // 0x784a3c: r0 = BoxInt64Instr(r2)
    //     0x784a3c: sbfiz           x0, x2, #1, #0x1f
    //     0x784a40: cmp             x2, x0, asr #1
    //     0x784a44: b.eq            #0x784a50
    //     0x784a48: bl              #0xd69bb8
    //     0x784a4c: stur            x2, [x0, #7]
    // 0x784a50: ldur            x16, [fp, #-8]
    // 0x784a54: stp             x0, x16, [SP, #-0x10]!
    // 0x784a58: r0 = _getValueOrData()
    //     0x784a58: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x784a5c: add             SP, SP, #0x10
    // 0x784a60: mov             x1, x0
    // 0x784a64: ldur            x0, [fp, #-8]
    // 0x784a68: LoadField: r2 = r0->field_f
    //     0x784a68: ldur            w2, [x0, #0xf]
    // 0x784a6c: DecompressPointer r2
    //     0x784a6c: add             x2, x2, HEAP, lsl #32
    // 0x784a70: cmp             w2, w1
    // 0x784a74: b.ne            #0x784a80
    // 0x784a78: r3 = Null
    //     0x784a78: mov             x3, NULL
    // 0x784a7c: b               #0x784a84
    // 0x784a80: mov             x3, x1
    // 0x784a84: stur            x3, [fp, #-8]
    // 0x784a88: cmp             w3, NULL
    // 0x784a8c: b.eq            #0x784bf4
    // 0x784a90: ldr             x0, [fp, #0x10]
    // 0x784a94: r2 = Null
    //     0x784a94: mov             x2, NULL
    // 0x784a98: r1 = Null
    //     0x784a98: mov             x1, NULL
    // 0x784a9c: cmp             w0, NULL
    // 0x784aa0: b.eq            #0x784ac0
    // 0x784aa4: branchIfSmi(r0, 0x784ac0)
    //     0x784aa4: tbz             w0, #0, #0x784ac0
    // 0x784aa8: r3 = LoadClassIdInstr(r0)
    //     0x784aa8: ldur            x3, [x0, #-1]
    //     0x784aac: ubfx            x3, x3, #0xc, #0x14
    // 0x784ab0: cmp             x3, #0x906
    // 0x784ab4: b.eq            #0x784ac8
    // 0x784ab8: cmp             x3, #0xb3d
    // 0x784abc: b.eq            #0x784ac8
    // 0x784ac0: r0 = false
    //     0x784ac0: add             x0, NULL, #0x30  ; false
    // 0x784ac4: b               #0x784acc
    // 0x784ac8: r0 = true
    //     0x784ac8: add             x0, NULL, #0x20  ; true
    // 0x784acc: tbnz            w0, #4, #0x784b0c
    // 0x784ad0: ldr             x3, [fp, #0x18]
    // 0x784ad4: LoadField: r0 = r3->field_23
    //     0x784ad4: ldur            w0, [x3, #0x23]
    // 0x784ad8: DecompressPointer r0
    //     0x784ad8: add             x0, x0, HEAP, lsl #32
    // 0x784adc: cmp             w0, NULL
    // 0x784ae0: b.ne            #0x784af8
    // 0x784ae4: ldur            x16, [fp, #-8]
    // 0x784ae8: stp             x16, x3, [SP, #-0x10]!
    // 0x784aec: r0 = _registerFirstTap()
    //     0x784aec: bl              #0x784f5c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_registerFirstTap
    // 0x784af0: add             SP, SP, #0x10
    // 0x784af4: b               #0x784bdc
    // 0x784af8: ldur            x16, [fp, #-8]
    // 0x784afc: stp             x16, x3, [SP, #-0x10]!
    // 0x784b00: r0 = _registerSecondTap()
    //     0x784b00: bl              #0x784e1c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_registerSecondTap
    // 0x784b04: add             SP, SP, #0x10
    // 0x784b08: b               #0x784bdc
    // 0x784b0c: ldr             x3, [fp, #0x18]
    // 0x784b10: ldr             x0, [fp, #0x10]
    // 0x784b14: r2 = Null
    //     0x784b14: mov             x2, NULL
    // 0x784b18: r1 = Null
    //     0x784b18: mov             x1, NULL
    // 0x784b1c: cmp             w0, NULL
    // 0x784b20: b.eq            #0x784b40
    // 0x784b24: branchIfSmi(r0, 0x784b40)
    //     0x784b24: tbz             w0, #0, #0x784b40
    // 0x784b28: r3 = LoadClassIdInstr(r0)
    //     0x784b28: ldur            x3, [x0, #-1]
    //     0x784b2c: ubfx            x3, x3, #0xc, #0x14
    // 0x784b30: cmp             x3, #0x908
    // 0x784b34: b.eq            #0x784b48
    // 0x784b38: cmp             x3, #0xb3f
    // 0x784b3c: b.eq            #0x784b48
    // 0x784b40: r0 = false
    //     0x784b40: add             x0, NULL, #0x30  ; false
    // 0x784b44: b               #0x784b4c
    // 0x784b48: r0 = true
    //     0x784b48: add             x0, NULL, #0x20  ; true
    // 0x784b4c: tbnz            w0, #4, #0x784b88
    // 0x784b50: d0 = 18.000000
    //     0x784b50: fmov            d0, #18.00000000
    // 0x784b54: ldur            x16, [fp, #-8]
    // 0x784b58: ldr             lr, [fp, #0x10]
    // 0x784b5c: stp             lr, x16, [SP, #-0x10]!
    // 0x784b60: SaveReg d0
    //     0x784b60: str             d0, [SP, #-8]!
    // 0x784b64: r0 = isWithinGlobalTolerance()
    //     0x784b64: bl              #0x785470  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::isWithinGlobalTolerance
    // 0x784b68: add             SP, SP, #0x18
    // 0x784b6c: tbz             w0, #4, #0x784bdc
    // 0x784b70: ldr             x16, [fp, #0x18]
    // 0x784b74: ldur            lr, [fp, #-8]
    // 0x784b78: stp             lr, x16, [SP, #-0x10]!
    // 0x784b7c: r0 = _reject()
    //     0x784b7c: bl              #0x784bf8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0x784b80: add             SP, SP, #0x10
    // 0x784b84: b               #0x784bdc
    // 0x784b88: ldr             x0, [fp, #0x10]
    // 0x784b8c: r2 = Null
    //     0x784b8c: mov             x2, NULL
    // 0x784b90: r1 = Null
    //     0x784b90: mov             x1, NULL
    // 0x784b94: cmp             w0, NULL
    // 0x784b98: b.eq            #0x784bb8
    // 0x784b9c: branchIfSmi(r0, 0x784bb8)
    //     0x784b9c: tbz             w0, #0, #0x784bb8
    // 0x784ba0: r3 = LoadClassIdInstr(r0)
    //     0x784ba0: ldur            x3, [x0, #-1]
    //     0x784ba4: ubfx            x3, x3, #0xc, #0x14
    // 0x784ba8: cmp             x3, #0x8f8
    // 0x784bac: b.eq            #0x784bc0
    // 0x784bb0: cmp             x3, #0xb35
    // 0x784bb4: b.eq            #0x784bc0
    // 0x784bb8: r0 = false
    //     0x784bb8: add             x0, NULL, #0x30  ; false
    // 0x784bbc: b               #0x784bc4
    // 0x784bc0: r0 = true
    //     0x784bc0: add             x0, NULL, #0x20  ; true
    // 0x784bc4: tbnz            w0, #4, #0x784bdc
    // 0x784bc8: ldr             x16, [fp, #0x18]
    // 0x784bcc: ldur            lr, [fp, #-8]
    // 0x784bd0: stp             lr, x16, [SP, #-0x10]!
    // 0x784bd4: r0 = _reject()
    //     0x784bd4: bl              #0x784bf8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0x784bd8: add             SP, SP, #0x10
    // 0x784bdc: r0 = Null
    //     0x784bdc: mov             x0, NULL
    // 0x784be0: LeaveFrame
    //     0x784be0: mov             SP, fp
    //     0x784be4: ldp             fp, lr, [SP], #0x10
    // 0x784be8: ret
    //     0x784be8: ret             
    // 0x784bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x784bec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784bf0: b               #0x784a08
    // 0x784bf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x784bf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _reject(/* No info */) {
    // ** addr: 0x784bf8, size: 0x100
    // 0x784bf8: EnterFrame
    //     0x784bf8: stp             fp, lr, [SP, #-0x10]!
    //     0x784bfc: mov             fp, SP
    // 0x784c00: AllocStack(0x8)
    //     0x784c00: sub             SP, SP, #8
    // 0x784c04: CheckStackOverflow
    //     0x784c04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784c08: cmp             SP, x16
    //     0x784c0c: b.ls            #0x784cf0
    // 0x784c10: ldr             x2, [fp, #0x18]
    // 0x784c14: LoadField: r3 = r2->field_27
    //     0x784c14: ldur            w3, [x2, #0x27]
    // 0x784c18: DecompressPointer r3
    //     0x784c18: add             x3, x3, HEAP, lsl #32
    // 0x784c1c: ldr             x4, [fp, #0x10]
    // 0x784c20: stur            x3, [fp, #-8]
    // 0x784c24: LoadField: r5 = r4->field_7
    //     0x784c24: ldur            x5, [x4, #7]
    // 0x784c28: r0 = BoxInt64Instr(r5)
    //     0x784c28: sbfiz           x0, x5, #1, #0x1f
    //     0x784c2c: cmp             x5, x0, asr #1
    //     0x784c30: b.eq            #0x784c3c
    //     0x784c34: bl              #0xd69bb8
    //     0x784c38: stur            x5, [x0, #7]
    // 0x784c3c: stp             x0, x3, [SP, #-0x10]!
    // 0x784c40: r0 = remove()
    //     0x784c40: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x784c44: add             SP, SP, #0x10
    // 0x784c48: ldr             x0, [fp, #0x10]
    // 0x784c4c: LoadField: r1 = r0->field_f
    //     0x784c4c: ldur            w1, [x0, #0xf]
    // 0x784c50: DecompressPointer r1
    //     0x784c50: add             x1, x1, HEAP, lsl #32
    // 0x784c54: r16 = Instance_GestureDisposition
    //     0x784c54: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x784c58: ldr             x16, [x16, #0xeb8]
    // 0x784c5c: stp             x16, x1, [SP, #-0x10]!
    // 0x784c60: r0 = resolve()
    //     0x784c60: bl              #0xcf7450  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0x784c64: add             SP, SP, #0x10
    // 0x784c68: ldr             x16, [fp, #0x18]
    // 0x784c6c: ldr             lr, [fp, #0x10]
    // 0x784c70: stp             lr, x16, [SP, #-0x10]!
    // 0x784c74: r0 = _freezeTracker()
    //     0x784c74: bl              #0x784d44  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_freezeTracker
    // 0x784c78: add             SP, SP, #0x10
    // 0x784c7c: ldr             x0, [fp, #0x18]
    // 0x784c80: LoadField: r1 = r0->field_23
    //     0x784c80: ldur            w1, [x0, #0x23]
    // 0x784c84: DecompressPointer r1
    //     0x784c84: add             x1, x1, HEAP, lsl #32
    // 0x784c88: cmp             w1, NULL
    // 0x784c8c: b.eq            #0x784ce0
    // 0x784c90: ldr             x2, [fp, #0x10]
    // 0x784c94: cmp             w2, w1
    // 0x784c98: b.ne            #0x784cac
    // 0x784c9c: SaveReg r0
    //     0x784c9c: str             x0, [SP, #-8]!
    // 0x784ca0: r0 = _reset()
    //     0x784ca0: bl              #0x78527c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0x784ca4: add             SP, SP, #8
    // 0x784ca8: b               #0x784ce0
    // 0x784cac: ldur            x1, [fp, #-8]
    // 0x784cb0: LoadField: r2 = r1->field_13
    //     0x784cb0: ldur            w2, [x1, #0x13]
    // 0x784cb4: DecompressPointer r2
    //     0x784cb4: add             x2, x2, HEAP, lsl #32
    // 0x784cb8: r3 = LoadInt32Instr(r2)
    //     0x784cb8: sbfx            x3, x2, #1, #0x1f
    // 0x784cbc: asr             x2, x3, #1
    // 0x784cc0: LoadField: r3 = r1->field_17
    //     0x784cc0: ldur            w3, [x1, #0x17]
    // 0x784cc4: DecompressPointer r3
    //     0x784cc4: add             x3, x3, HEAP, lsl #32
    // 0x784cc8: r1 = LoadInt32Instr(r3)
    //     0x784cc8: sbfx            x1, x3, #1, #0x1f
    // 0x784ccc: sub             x3, x2, x1
    // 0x784cd0: cbnz            x3, #0x784ce0
    // 0x784cd4: SaveReg r0
    //     0x784cd4: str             x0, [SP, #-8]!
    // 0x784cd8: r0 = _reset()
    //     0x784cd8: bl              #0x78527c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0x784cdc: add             SP, SP, #8
    // 0x784ce0: r0 = Null
    //     0x784ce0: mov             x0, NULL
    // 0x784ce4: LeaveFrame
    //     0x784ce4: mov             SP, fp
    //     0x784ce8: ldp             fp, lr, [SP], #0x10
    // 0x784cec: ret
    //     0x784cec: ret             
    // 0x784cf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x784cf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784cf4: b               #0x784c10
  }
  [closure] void _reject(dynamic, _TapTracker) {
    // ** addr: 0x784cf8, size: 0x4c
    // 0x784cf8: EnterFrame
    //     0x784cf8: stp             fp, lr, [SP, #-0x10]!
    //     0x784cfc: mov             fp, SP
    // 0x784d00: ldr             x0, [fp, #0x18]
    // 0x784d04: LoadField: r1 = r0->field_17
    //     0x784d04: ldur            w1, [x0, #0x17]
    // 0x784d08: DecompressPointer r1
    //     0x784d08: add             x1, x1, HEAP, lsl #32
    // 0x784d0c: CheckStackOverflow
    //     0x784d0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784d10: cmp             SP, x16
    //     0x784d14: b.ls            #0x784d3c
    // 0x784d18: LoadField: r0 = r1->field_f
    //     0x784d18: ldur            w0, [x1, #0xf]
    // 0x784d1c: DecompressPointer r0
    //     0x784d1c: add             x0, x0, HEAP, lsl #32
    // 0x784d20: ldr             x16, [fp, #0x10]
    // 0x784d24: stp             x16, x0, [SP, #-0x10]!
    // 0x784d28: r0 = _reject()
    //     0x784d28: bl              #0x784bf8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0x784d2c: add             SP, SP, #0x10
    // 0x784d30: LeaveFrame
    //     0x784d30: mov             SP, fp
    //     0x784d34: ldp             fp, lr, [SP], #0x10
    // 0x784d38: ret
    //     0x784d38: ret             
    // 0x784d3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x784d3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784d40: b               #0x784d18
  }
  _ _freezeTracker(/* No info */) {
    // ** addr: 0x784d44, size: 0x60
    // 0x784d44: EnterFrame
    //     0x784d44: stp             fp, lr, [SP, #-0x10]!
    //     0x784d48: mov             fp, SP
    // 0x784d4c: CheckStackOverflow
    //     0x784d4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784d50: cmp             SP, x16
    //     0x784d54: b.ls            #0x784d9c
    // 0x784d58: r1 = 1
    //     0x784d58: mov             x1, #1
    // 0x784d5c: r0 = AllocateContext()
    //     0x784d5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x784d60: mov             x1, x0
    // 0x784d64: ldr             x0, [fp, #0x18]
    // 0x784d68: StoreField: r1->field_f = r0
    //     0x784d68: stur            w0, [x1, #0xf]
    // 0x784d6c: mov             x2, x1
    // 0x784d70: r1 = Function '_handleEvent@668391311':.
    //     0x784d70: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ec8] AnonymousClosure: (0x7849a4), in [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_handleEvent (0x7849f0)
    //     0x784d74: ldr             x1, [x1, #0xec8]
    // 0x784d78: r0 = AllocateClosure()
    //     0x784d78: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x784d7c: ldr             x16, [fp, #0x10]
    // 0x784d80: stp             x0, x16, [SP, #-0x10]!
    // 0x784d84: r0 = stopTrackingPointer()
    //     0x784d84: bl              #0x784da4  ; [package:flutter/src/gestures/multitap.dart] _TapTracker::stopTrackingPointer
    // 0x784d88: add             SP, SP, #0x10
    // 0x784d8c: r0 = Null
    //     0x784d8c: mov             x0, NULL
    // 0x784d90: LeaveFrame
    //     0x784d90: mov             SP, fp
    //     0x784d94: ldp             fp, lr, [SP], #0x10
    // 0x784d98: ret
    //     0x784d98: ret             
    // 0x784d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x784d9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784da0: b               #0x784d58
  }
  _ _registerSecondTap(/* No info */) {
    // ** addr: 0x784e1c, size: 0xe8
    // 0x784e1c: EnterFrame
    //     0x784e1c: stp             fp, lr, [SP, #-0x10]!
    //     0x784e20: mov             fp, SP
    // 0x784e24: CheckStackOverflow
    //     0x784e24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784e28: cmp             SP, x16
    //     0x784e2c: b.ls            #0x784ef8
    // 0x784e30: ldr             x0, [fp, #0x18]
    // 0x784e34: LoadField: r1 = r0->field_23
    //     0x784e34: ldur            w1, [x0, #0x23]
    // 0x784e38: DecompressPointer r1
    //     0x784e38: add             x1, x1, HEAP, lsl #32
    // 0x784e3c: cmp             w1, NULL
    // 0x784e40: b.eq            #0x784f00
    // 0x784e44: LoadField: r2 = r1->field_f
    //     0x784e44: ldur            w2, [x1, #0xf]
    // 0x784e48: DecompressPointer r2
    //     0x784e48: add             x2, x2, HEAP, lsl #32
    // 0x784e4c: r16 = Instance_GestureDisposition
    //     0x784e4c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x784e50: ldr             x16, [x16, #0xed0]
    // 0x784e54: stp             x16, x2, [SP, #-0x10]!
    // 0x784e58: r0 = resolve()
    //     0x784e58: bl              #0xcf7450  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0x784e5c: add             SP, SP, #0x10
    // 0x784e60: ldr             x0, [fp, #0x10]
    // 0x784e64: LoadField: r1 = r0->field_f
    //     0x784e64: ldur            w1, [x0, #0xf]
    // 0x784e68: DecompressPointer r1
    //     0x784e68: add             x1, x1, HEAP, lsl #32
    // 0x784e6c: r16 = Instance_GestureDisposition
    //     0x784e6c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x784e70: ldr             x16, [x16, #0xed0]
    // 0x784e74: stp             x16, x1, [SP, #-0x10]!
    // 0x784e78: r0 = resolve()
    //     0x784e78: bl              #0xcf7450  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0x784e7c: add             SP, SP, #0x10
    // 0x784e80: ldr             x16, [fp, #0x18]
    // 0x784e84: ldr             lr, [fp, #0x10]
    // 0x784e88: stp             lr, x16, [SP, #-0x10]!
    // 0x784e8c: r0 = _freezeTracker()
    //     0x784e8c: bl              #0x784d44  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_freezeTracker
    // 0x784e90: add             SP, SP, #0x10
    // 0x784e94: ldr             x2, [fp, #0x18]
    // 0x784e98: LoadField: r3 = r2->field_27
    //     0x784e98: ldur            w3, [x2, #0x27]
    // 0x784e9c: DecompressPointer r3
    //     0x784e9c: add             x3, x3, HEAP, lsl #32
    // 0x784ea0: ldr             x0, [fp, #0x10]
    // 0x784ea4: LoadField: r4 = r0->field_7
    //     0x784ea4: ldur            x4, [x0, #7]
    // 0x784ea8: r0 = BoxInt64Instr(r4)
    //     0x784ea8: sbfiz           x0, x4, #1, #0x1f
    //     0x784eac: cmp             x4, x0, asr #1
    //     0x784eb0: b.eq            #0x784ebc
    //     0x784eb4: bl              #0xd69bb8
    //     0x784eb8: stur            x4, [x0, #7]
    // 0x784ebc: stp             x0, x3, [SP, #-0x10]!
    // 0x784ec0: r0 = remove()
    //     0x784ec0: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x784ec4: add             SP, SP, #0x10
    // 0x784ec8: ldr             x16, [fp, #0x18]
    // 0x784ecc: SaveReg r16
    //     0x784ecc: str             x16, [SP, #-8]!
    // 0x784ed0: r0 = _checkUp()
    //     0x784ed0: bl              #0x784f04  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_checkUp
    // 0x784ed4: add             SP, SP, #8
    // 0x784ed8: ldr             x16, [fp, #0x18]
    // 0x784edc: SaveReg r16
    //     0x784edc: str             x16, [SP, #-8]!
    // 0x784ee0: r0 = _reset()
    //     0x784ee0: bl              #0x78527c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0x784ee4: add             SP, SP, #8
    // 0x784ee8: r0 = Null
    //     0x784ee8: mov             x0, NULL
    // 0x784eec: LeaveFrame
    //     0x784eec: mov             SP, fp
    //     0x784ef0: ldp             fp, lr, [SP], #0x10
    // 0x784ef4: ret
    //     0x784ef4: ret             
    // 0x784ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x784ef8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784efc: b               #0x784e30
    // 0x784f00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x784f00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkUp(/* No info */) {
    // ** addr: 0x784f04, size: 0x58
    // 0x784f04: EnterFrame
    //     0x784f04: stp             fp, lr, [SP, #-0x10]!
    //     0x784f08: mov             fp, SP
    // 0x784f0c: CheckStackOverflow
    //     0x784f0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784f10: cmp             SP, x16
    //     0x784f14: b.ls            #0x784f54
    // 0x784f18: ldr             x0, [fp, #0x10]
    // 0x784f1c: LoadField: r1 = r0->field_17
    //     0x784f1c: ldur            w1, [x0, #0x17]
    // 0x784f20: DecompressPointer r1
    //     0x784f20: add             x1, x1, HEAP, lsl #32
    // 0x784f24: cmp             w1, NULL
    // 0x784f28: b.eq            #0x784f44
    // 0x784f2c: r16 = <void?>
    //     0x784f2c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x784f30: stp             x0, x16, [SP, #-0x10]!
    // 0x784f34: SaveReg r1
    //     0x784f34: str             x1, [SP, #-8]!
    // 0x784f38: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x784f38: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x784f3c: r0 = invokeCallback()
    //     0x784f3c: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x784f40: add             SP, SP, #0x18
    // 0x784f44: r0 = Null
    //     0x784f44: mov             x0, NULL
    // 0x784f48: LeaveFrame
    //     0x784f48: mov             SP, fp
    //     0x784f4c: ldp             fp, lr, [SP], #0x10
    // 0x784f50: ret
    //     0x784f50: ret             
    // 0x784f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x784f54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x784f58: b               #0x784f18
  }
  _ _registerFirstTap(/* No info */) {
    // ** addr: 0x784f5c, size: 0xec
    // 0x784f5c: EnterFrame
    //     0x784f5c: stp             fp, lr, [SP, #-0x10]!
    //     0x784f60: mov             fp, SP
    // 0x784f64: AllocStack(0x8)
    //     0x784f64: sub             SP, SP, #8
    // 0x784f68: CheckStackOverflow
    //     0x784f68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784f6c: cmp             SP, x16
    //     0x784f70: b.ls            #0x78503c
    // 0x784f74: ldr             x16, [fp, #0x18]
    // 0x784f78: SaveReg r16
    //     0x784f78: str             x16, [SP, #-8]!
    // 0x784f7c: r0 = _startDoubleTapTimer()
    //     0x784f7c: bl              #0x785198  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_startDoubleTapTimer
    // 0x784f80: add             SP, SP, #8
    // 0x784f84: r0 = LoadStaticField(0xd54)
    //     0x784f84: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x784f88: ldr             x0, [x0, #0x1aa8]
    // 0x784f8c: cmp             w0, NULL
    // 0x784f90: b.eq            #0x785044
    // 0x784f94: LoadField: r1 = r0->field_17
    //     0x784f94: ldur            w1, [x0, #0x17]
    // 0x784f98: DecompressPointer r1
    //     0x784f98: add             x1, x1, HEAP, lsl #32
    // 0x784f9c: ldr             x0, [fp, #0x10]
    // 0x784fa0: LoadField: r2 = r0->field_7
    //     0x784fa0: ldur            x2, [x0, #7]
    // 0x784fa4: stur            x2, [fp, #-8]
    // 0x784fa8: stp             x2, x1, [SP, #-0x10]!
    // 0x784fac: r0 = hold()
    //     0x784fac: bl              #0x7850f4  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::hold
    // 0x784fb0: add             SP, SP, #0x10
    // 0x784fb4: ldr             x16, [fp, #0x18]
    // 0x784fb8: ldr             lr, [fp, #0x10]
    // 0x784fbc: stp             lr, x16, [SP, #-0x10]!
    // 0x784fc0: r0 = _freezeTracker()
    //     0x784fc0: bl              #0x784d44  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_freezeTracker
    // 0x784fc4: add             SP, SP, #0x10
    // 0x784fc8: ldr             x2, [fp, #0x18]
    // 0x784fcc: LoadField: r3 = r2->field_27
    //     0x784fcc: ldur            w3, [x2, #0x27]
    // 0x784fd0: DecompressPointer r3
    //     0x784fd0: add             x3, x3, HEAP, lsl #32
    // 0x784fd4: ldur            x4, [fp, #-8]
    // 0x784fd8: r0 = BoxInt64Instr(r4)
    //     0x784fd8: sbfiz           x0, x4, #1, #0x1f
    //     0x784fdc: cmp             x4, x0, asr #1
    //     0x784fe0: b.eq            #0x784fec
    //     0x784fe4: bl              #0xd69bb8
    //     0x784fe8: stur            x4, [x0, #7]
    // 0x784fec: stp             x0, x3, [SP, #-0x10]!
    // 0x784ff0: r0 = remove()
    //     0x784ff0: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x784ff4: add             SP, SP, #0x10
    // 0x784ff8: ldr             x16, [fp, #0x18]
    // 0x784ffc: SaveReg r16
    //     0x784ffc: str             x16, [SP, #-8]!
    // 0x785000: r0 = _clearTrackers()
    //     0x785000: bl              #0x785048  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_clearTrackers
    // 0x785004: add             SP, SP, #8
    // 0x785008: ldr             x0, [fp, #0x10]
    // 0x78500c: ldr             x1, [fp, #0x18]
    // 0x785010: StoreField: r1->field_23 = r0
    //     0x785010: stur            w0, [x1, #0x23]
    //     0x785014: ldurb           w16, [x1, #-1]
    //     0x785018: ldurb           w17, [x0, #-1]
    //     0x78501c: and             x16, x17, x16, lsr #2
    //     0x785020: tst             x16, HEAP, lsr #32
    //     0x785024: b.eq            #0x78502c
    //     0x785028: bl              #0xd6826c
    // 0x78502c: r0 = Null
    //     0x78502c: mov             x0, NULL
    // 0x785030: LeaveFrame
    //     0x785030: mov             SP, fp
    //     0x785034: ldp             fp, lr, [SP], #0x10
    // 0x785038: ret
    //     0x785038: ret             
    // 0x78503c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78503c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x785040: b               #0x784f74
    // 0x785044: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x785044: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _clearTrackers(/* No info */) {
    // ** addr: 0x785048, size: 0xac
    // 0x785048: EnterFrame
    //     0x785048: stp             fp, lr, [SP, #-0x10]!
    //     0x78504c: mov             fp, SP
    // 0x785050: AllocStack(0x8)
    //     0x785050: sub             SP, SP, #8
    // 0x785054: CheckStackOverflow
    //     0x785054: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x785058: cmp             SP, x16
    //     0x78505c: b.ls            #0x7850ec
    // 0x785060: ldr             x0, [fp, #0x10]
    // 0x785064: LoadField: r1 = r0->field_27
    //     0x785064: ldur            w1, [x0, #0x27]
    // 0x785068: DecompressPointer r1
    //     0x785068: add             x1, x1, HEAP, lsl #32
    // 0x78506c: SaveReg r1
    //     0x78506c: str             x1, [SP, #-8]!
    // 0x785070: r0 = values()
    //     0x785070: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x785074: add             SP, SP, #8
    // 0x785078: SaveReg r0
    //     0x785078: str             x0, [SP, #-8]!
    // 0x78507c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x78507c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x785080: r0 = toList()
    //     0x785080: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x785084: add             SP, SP, #8
    // 0x785088: stur            x0, [fp, #-8]
    // 0x78508c: r1 = 1
    //     0x78508c: mov             x1, #1
    // 0x785090: r0 = AllocateContext()
    //     0x785090: bl              #0xd68aa4  ; AllocateContextStub
    // 0x785094: mov             x1, x0
    // 0x785098: ldr             x0, [fp, #0x10]
    // 0x78509c: StoreField: r1->field_f = r0
    //     0x78509c: stur            w0, [x1, #0xf]
    // 0x7850a0: mov             x2, x1
    // 0x7850a4: r1 = Function '_reject@668391311':.
    //     0x7850a4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ec0] AnonymousClosure: (0x784cf8), in [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject (0x784bf8)
    //     0x7850a8: ldr             x1, [x1, #0xec0]
    // 0x7850ac: r0 = AllocateClosure()
    //     0x7850ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7850b0: mov             x1, x0
    // 0x7850b4: ldur            x0, [fp, #-8]
    // 0x7850b8: r2 = LoadClassIdInstr(r0)
    //     0x7850b8: ldur            x2, [x0, #-1]
    //     0x7850bc: ubfx            x2, x2, #0xc, #0x14
    // 0x7850c0: stp             x1, x0, [SP, #-0x10]!
    // 0x7850c4: mov             x0, x2
    // 0x7850c8: r0 = GDT[cid_x0 + 0xce6e]()
    //     0x7850c8: mov             x17, #0xce6e
    //     0x7850cc: add             lr, x0, x17
    //     0x7850d0: ldr             lr, [x21, lr, lsl #3]
    //     0x7850d4: blr             lr
    // 0x7850d8: add             SP, SP, #0x10
    // 0x7850dc: r0 = Null
    //     0x7850dc: mov             x0, NULL
    // 0x7850e0: LeaveFrame
    //     0x7850e0: mov             SP, fp
    //     0x7850e4: ldp             fp, lr, [SP], #0x10
    // 0x7850e8: ret
    //     0x7850e8: ret             
    // 0x7850ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7850ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7850f0: b               #0x785060
  }
  _ _startDoubleTapTimer(/* No info */) {
    // ** addr: 0x785198, size: 0x9c
    // 0x785198: EnterFrame
    //     0x785198: stp             fp, lr, [SP, #-0x10]!
    //     0x78519c: mov             fp, SP
    // 0x7851a0: CheckStackOverflow
    //     0x7851a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7851a4: cmp             SP, x16
    //     0x7851a8: b.ls            #0x78522c
    // 0x7851ac: ldr             x0, [fp, #0x10]
    // 0x7851b0: LoadField: r1 = r0->field_1f
    //     0x7851b0: ldur            w1, [x0, #0x1f]
    // 0x7851b4: DecompressPointer r1
    //     0x7851b4: add             x1, x1, HEAP, lsl #32
    // 0x7851b8: cmp             w1, NULL
    // 0x7851bc: b.ne            #0x78521c
    // 0x7851c0: r1 = 1
    //     0x7851c0: mov             x1, #1
    // 0x7851c4: r0 = AllocateContext()
    //     0x7851c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7851c8: mov             x1, x0
    // 0x7851cc: ldr             x0, [fp, #0x10]
    // 0x7851d0: StoreField: r1->field_f = r0
    //     0x7851d0: stur            w0, [x1, #0xf]
    // 0x7851d4: mov             x2, x1
    // 0x7851d8: r1 = Function '_reset@668391311':.
    //     0x7851d8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ed8] AnonymousClosure: (0x785234), in [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset (0x78527c)
    //     0x7851dc: ldr             x1, [x1, #0xed8]
    // 0x7851e0: r0 = AllocateClosure()
    //     0x7851e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7851e4: r16 = Instance_Duration
    //     0x7851e4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x7851e8: ldr             x16, [x16, #0xc88]
    // 0x7851ec: stp             x16, NULL, [SP, #-0x10]!
    // 0x7851f0: SaveReg r0
    //     0x7851f0: str             x0, [SP, #-8]!
    // 0x7851f4: r0 = Timer()
    //     0x7851f4: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x7851f8: add             SP, SP, #0x18
    // 0x7851fc: ldr             x1, [fp, #0x10]
    // 0x785200: StoreField: r1->field_1f = r0
    //     0x785200: stur            w0, [x1, #0x1f]
    //     0x785204: ldurb           w16, [x1, #-1]
    //     0x785208: ldurb           w17, [x0, #-1]
    //     0x78520c: and             x16, x17, x16, lsr #2
    //     0x785210: tst             x16, HEAP, lsr #32
    //     0x785214: b.eq            #0x78521c
    //     0x785218: bl              #0xd6826c
    // 0x78521c: r0 = Null
    //     0x78521c: mov             x0, NULL
    // 0x785220: LeaveFrame
    //     0x785220: mov             SP, fp
    //     0x785224: ldp             fp, lr, [SP], #0x10
    // 0x785228: ret
    //     0x785228: ret             
    // 0x78522c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78522c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x785230: b               #0x7851ac
  }
  [closure] void _reset(dynamic) {
    // ** addr: 0x785234, size: 0x48
    // 0x785234: EnterFrame
    //     0x785234: stp             fp, lr, [SP, #-0x10]!
    //     0x785238: mov             fp, SP
    // 0x78523c: ldr             x0, [fp, #0x10]
    // 0x785240: LoadField: r1 = r0->field_17
    //     0x785240: ldur            w1, [x0, #0x17]
    // 0x785244: DecompressPointer r1
    //     0x785244: add             x1, x1, HEAP, lsl #32
    // 0x785248: CheckStackOverflow
    //     0x785248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78524c: cmp             SP, x16
    //     0x785250: b.ls            #0x785274
    // 0x785254: LoadField: r0 = r1->field_f
    //     0x785254: ldur            w0, [x1, #0xf]
    // 0x785258: DecompressPointer r0
    //     0x785258: add             x0, x0, HEAP, lsl #32
    // 0x78525c: SaveReg r0
    //     0x78525c: str             x0, [SP, #-8]!
    // 0x785260: r0 = _reset()
    //     0x785260: bl              #0x78527c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0x785264: add             SP, SP, #8
    // 0x785268: LeaveFrame
    //     0x785268: mov             SP, fp
    //     0x78526c: ldp             fp, lr, [SP], #0x10
    // 0x785270: ret
    //     0x785270: ret             
    // 0x785274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x785274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x785278: b               #0x785254
  }
  _ _reset(/* No info */) {
    // ** addr: 0x78527c, size: 0xa8
    // 0x78527c: EnterFrame
    //     0x78527c: stp             fp, lr, [SP, #-0x10]!
    //     0x785280: mov             fp, SP
    // 0x785284: AllocStack(0x8)
    //     0x785284: sub             SP, SP, #8
    // 0x785288: CheckStackOverflow
    //     0x785288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78528c: cmp             SP, x16
    //     0x785290: b.ls            #0x785318
    // 0x785294: ldr             x16, [fp, #0x10]
    // 0x785298: SaveReg r16
    //     0x785298: str             x16, [SP, #-8]!
    // 0x78529c: r0 = _stopDoubleTapTimer()
    //     0x78529c: bl              #0x784950  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_stopDoubleTapTimer
    // 0x7852a0: add             SP, SP, #8
    // 0x7852a4: ldr             x0, [fp, #0x10]
    // 0x7852a8: LoadField: r1 = r0->field_23
    //     0x7852a8: ldur            w1, [x0, #0x23]
    // 0x7852ac: DecompressPointer r1
    //     0x7852ac: add             x1, x1, HEAP, lsl #32
    // 0x7852b0: stur            x1, [fp, #-8]
    // 0x7852b4: cmp             w1, NULL
    // 0x7852b8: b.eq            #0x7852f8
    // 0x7852bc: StoreField: r0->field_23 = rNULL
    //     0x7852bc: stur            NULL, [x0, #0x23]
    // 0x7852c0: stp             x1, x0, [SP, #-0x10]!
    // 0x7852c4: r0 = _reject()
    //     0x7852c4: bl              #0x784bf8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0x7852c8: add             SP, SP, #0x10
    // 0x7852cc: r0 = LoadStaticField(0xd54)
    //     0x7852cc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7852d0: ldr             x0, [x0, #0x1aa8]
    // 0x7852d4: cmp             w0, NULL
    // 0x7852d8: b.eq            #0x785320
    // 0x7852dc: LoadField: r1 = r0->field_17
    //     0x7852dc: ldur            w1, [x0, #0x17]
    // 0x7852e0: DecompressPointer r1
    //     0x7852e0: add             x1, x1, HEAP, lsl #32
    // 0x7852e4: ldur            x0, [fp, #-8]
    // 0x7852e8: LoadField: r2 = r0->field_7
    //     0x7852e8: ldur            x2, [x0, #7]
    // 0x7852ec: stp             x2, x1, [SP, #-0x10]!
    // 0x7852f0: r0 = release()
    //     0x7852f0: bl              #0x785324  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::release
    // 0x7852f4: add             SP, SP, #0x10
    // 0x7852f8: ldr             x16, [fp, #0x10]
    // 0x7852fc: SaveReg r16
    //     0x7852fc: str             x16, [SP, #-8]!
    // 0x785300: r0 = _clearTrackers()
    //     0x785300: bl              #0x785048  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_clearTrackers
    // 0x785304: add             SP, SP, #8
    // 0x785308: r0 = Null
    //     0x785308: mov             x0, NULL
    // 0x78530c: LeaveFrame
    //     0x78530c: mov             SP, fp
    //     0x785310: ldp             fp, lr, [SP], #0x10
    // 0x785314: ret
    //     0x785314: ret             
    // 0x785318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x785318: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78531c: b               #0x785294
    // 0x785320: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x785320: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xa82a7c, size: 0xe4
    // 0xa82a7c: EnterFrame
    //     0xa82a7c: stp             fp, lr, [SP, #-0x10]!
    //     0xa82a80: mov             fp, SP
    // 0xa82a84: CheckStackOverflow
    //     0xa82a84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa82a88: cmp             SP, x16
    //     0xa82a8c: b.ls            #0xa82b58
    // 0xa82a90: ldr             x1, [fp, #0x18]
    // 0xa82a94: LoadField: r0 = r1->field_23
    //     0xa82a94: ldur            w0, [x1, #0x23]
    // 0xa82a98: DecompressPointer r0
    //     0xa82a98: add             x0, x0, HEAP, lsl #32
    // 0xa82a9c: cmp             w0, NULL
    // 0xa82aa0: b.ne            #0xa82b38
    // 0xa82aa4: ldr             x2, [fp, #0x10]
    // 0xa82aa8: r0 = LoadClassIdInstr(r2)
    //     0xa82aa8: ldur            x0, [x2, #-1]
    //     0xa82aac: ubfx            x0, x0, #0xc, #0x14
    // 0xa82ab0: SaveReg r2
    //     0xa82ab0: str             x2, [SP, #-8]!
    // 0xa82ab4: r0 = GDT[cid_x0 + 0x271c]()
    //     0xa82ab4: mov             x17, #0x271c
    //     0xa82ab8: add             lr, x0, x17
    //     0xa82abc: ldr             lr, [x21, lr, lsl #3]
    //     0xa82ac0: blr             lr
    // 0xa82ac4: add             SP, SP, #8
    // 0xa82ac8: mov             x2, x0
    // 0xa82acc: r0 = BoxInt64Instr(r2)
    //     0xa82acc: sbfiz           x0, x2, #1, #0x1f
    //     0xa82ad0: cmp             x2, x0, asr #1
    //     0xa82ad4: b.eq            #0xa82ae0
    //     0xa82ad8: bl              #0xd69bb8
    //     0xa82adc: stur            x2, [x0, #7]
    // 0xa82ae0: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xa82ae0: mov             x1, #0x76
    //     0xa82ae4: tbz             w0, #0, #0xa82af4
    //     0xa82ae8: ldur            x1, [x0, #-1]
    //     0xa82aec: ubfx            x1, x1, #0xc, #0x14
    //     0xa82af0: lsl             x1, x1, #1
    // 0xa82af4: cmp             w1, #0x76
    // 0xa82af8: b.ne            #0xa82b28
    // 0xa82afc: cmp             w0, #2
    // 0xa82b00: b.ne            #0xa82b28
    // 0xa82b04: ldr             x0, [fp, #0x18]
    // 0xa82b08: LoadField: r1 = r0->field_17
    //     0xa82b08: ldur            w1, [x0, #0x17]
    // 0xa82b0c: DecompressPointer r1
    //     0xa82b0c: add             x1, x1, HEAP, lsl #32
    // 0xa82b10: cmp             w1, NULL
    // 0xa82b14: b.ne            #0xa82b3c
    // 0xa82b18: r0 = false
    //     0xa82b18: add             x0, NULL, #0x30  ; false
    // 0xa82b1c: LeaveFrame
    //     0xa82b1c: mov             SP, fp
    //     0xa82b20: ldp             fp, lr, [SP], #0x10
    // 0xa82b24: ret
    //     0xa82b24: ret             
    // 0xa82b28: r0 = false
    //     0xa82b28: add             x0, NULL, #0x30  ; false
    // 0xa82b2c: LeaveFrame
    //     0xa82b2c: mov             SP, fp
    //     0xa82b30: ldp             fp, lr, [SP], #0x10
    // 0xa82b34: ret
    //     0xa82b34: ret             
    // 0xa82b38: mov             x0, x1
    // 0xa82b3c: ldr             x16, [fp, #0x10]
    // 0xa82b40: stp             x16, x0, [SP, #-0x10]!
    // 0xa82b44: r0 = isPointerAllowed()
    //     0xa82b44: bl              #0xa829e0  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xa82b48: add             SP, SP, #0x10
    // 0xa82b4c: LeaveFrame
    //     0xa82b4c: mov             SP, fp
    //     0xa82b50: ldp             fp, lr, [SP], #0x10
    // 0xa82b54: ret
    //     0xa82b54: ret             
    // 0xa82b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa82b58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa82b5c: b               #0xa82a90
  }
  _ DoubleTapGestureRecognizer(/* No info */) {
    // ** addr: 0xb29510, size: 0x78
    // 0xb29510: EnterFrame
    //     0xb29510: stp             fp, lr, [SP, #-0x10]!
    //     0xb29514: mov             fp, SP
    // 0xb29518: CheckStackOverflow
    //     0xb29518: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2951c: cmp             SP, x16
    //     0xb29520: b.ls            #0xb29580
    // 0xb29524: r16 = <int, _TapTracker>
    //     0xb29524: add             x16, PP, #0x21, lsl #12  ; [pp+0x21510] TypeArguments: <int, _TapTracker>
    //     0xb29528: ldr             x16, [x16, #0x510]
    // 0xb2952c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xb29530: stp             lr, x16, [SP, #-0x10]!
    // 0xb29534: r0 = Map._fromLiteral()
    //     0xb29534: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xb29538: add             SP, SP, #0x10
    // 0xb2953c: ldr             x1, [fp, #0x10]
    // 0xb29540: StoreField: r1->field_27 = r0
    //     0xb29540: stur            w0, [x1, #0x27]
    //     0xb29544: tbz             w0, #0, #0xb29560
    //     0xb29548: ldurb           w16, [x1, #-1]
    //     0xb2954c: ldurb           w17, [x0, #-1]
    //     0xb29550: and             x16, x17, x16, lsr #2
    //     0xb29554: tst             x16, HEAP, lsr #32
    //     0xb29558: b.eq            #0xb29560
    //     0xb2955c: bl              #0xd6826c
    // 0xb29560: stp             NULL, x1, [SP, #-0x10]!
    // 0xb29564: SaveReg rNULL
    //     0xb29564: str             NULL, [SP, #-8]!
    // 0xb29568: r0 = GestureRecognizer()
    //     0xb29568: bl              #0x6d4060  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::GestureRecognizer
    // 0xb2956c: add             SP, SP, #0x18
    // 0xb29570: r0 = Null
    //     0xb29570: mov             x0, NULL
    // 0xb29574: LeaveFrame
    //     0xb29574: mov             SP, fp
    //     0xb29578: ldp             fp, lr, [SP], #0x10
    // 0xb2957c: ret
    //     0xb2957c: ret             
    // 0xb29580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29584: b               #0xb29524
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbd9688, size: 0x3c
    // 0xbd9688: EnterFrame
    //     0xbd9688: stp             fp, lr, [SP, #-0x10]!
    //     0xbd968c: mov             fp, SP
    // 0xbd9690: CheckStackOverflow
    //     0xbd9690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd9694: cmp             SP, x16
    //     0xbd9698: b.ls            #0xbd96bc
    // 0xbd969c: ldr             x16, [fp, #0x10]
    // 0xbd96a0: SaveReg r16
    //     0xbd96a0: str             x16, [SP, #-8]!
    // 0xbd96a4: r0 = _reset()
    //     0xbd96a4: bl              #0x78527c  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reset
    // 0xbd96a8: add             SP, SP, #8
    // 0xbd96ac: r0 = Null
    //     0xbd96ac: mov             x0, NULL
    // 0xbd96b0: LeaveFrame
    //     0xbd96b0: mov             SP, fp
    //     0xbd96b4: ldp             fp, lr, [SP], #0x10
    // 0xbd96b8: ret
    //     0xbd96b8: ret             
    // 0xbd96bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd96bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd96c0: b               #0xbd969c
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee8ac, size: 0xd4
    // 0xcee8ac: EnterFrame
    //     0xcee8ac: stp             fp, lr, [SP, #-0x10]!
    //     0xcee8b0: mov             fp, SP
    // 0xcee8b4: AllocStack(0x8)
    //     0xcee8b4: sub             SP, SP, #8
    // 0xcee8b8: CheckStackOverflow
    //     0xcee8b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee8bc: cmp             SP, x16
    //     0xcee8c0: b.ls            #0xcee978
    // 0xcee8c4: ldr             x2, [fp, #0x18]
    // 0xcee8c8: LoadField: r3 = r2->field_27
    //     0xcee8c8: ldur            w3, [x2, #0x27]
    // 0xcee8cc: DecompressPointer r3
    //     0xcee8cc: add             x3, x3, HEAP, lsl #32
    // 0xcee8d0: ldr             x4, [fp, #0x10]
    // 0xcee8d4: stur            x3, [fp, #-8]
    // 0xcee8d8: r0 = BoxInt64Instr(r4)
    //     0xcee8d8: sbfiz           x0, x4, #1, #0x1f
    //     0xcee8dc: cmp             x4, x0, asr #1
    //     0xcee8e0: b.eq            #0xcee8ec
    //     0xcee8e4: bl              #0xd69bb8
    //     0xcee8e8: stur            x4, [x0, #7]
    // 0xcee8ec: stp             x0, x3, [SP, #-0x10]!
    // 0xcee8f0: r0 = _getValueOrData()
    //     0xcee8f0: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcee8f4: add             SP, SP, #0x10
    // 0xcee8f8: mov             x1, x0
    // 0xcee8fc: ldur            x0, [fp, #-8]
    // 0xcee900: LoadField: r2 = r0->field_f
    //     0xcee900: ldur            w2, [x0, #0xf]
    // 0xcee904: DecompressPointer r2
    //     0xcee904: add             x2, x2, HEAP, lsl #32
    // 0xcee908: cmp             w2, w1
    // 0xcee90c: b.ne            #0xcee918
    // 0xcee910: r0 = Null
    //     0xcee910: mov             x0, NULL
    // 0xcee914: b               #0xcee91c
    // 0xcee918: mov             x0, x1
    // 0xcee91c: cmp             w0, NULL
    // 0xcee920: b.ne            #0xcee950
    // 0xcee924: ldr             x1, [fp, #0x18]
    // 0xcee928: LoadField: r2 = r1->field_23
    //     0xcee928: ldur            w2, [x1, #0x23]
    // 0xcee92c: DecompressPointer r2
    //     0xcee92c: add             x2, x2, HEAP, lsl #32
    // 0xcee930: cmp             w2, NULL
    // 0xcee934: b.eq            #0xcee954
    // 0xcee938: ldr             x3, [fp, #0x10]
    // 0xcee93c: LoadField: r4 = r2->field_7
    //     0xcee93c: ldur            x4, [x2, #7]
    // 0xcee940: cmp             x4, x3
    // 0xcee944: b.ne            #0xcee954
    // 0xcee948: mov             x0, x2
    // 0xcee94c: b               #0xcee954
    // 0xcee950: ldr             x1, [fp, #0x18]
    // 0xcee954: cmp             w0, NULL
    // 0xcee958: b.eq            #0xcee968
    // 0xcee95c: stp             x0, x1, [SP, #-0x10]!
    // 0xcee960: r0 = _reject()
    //     0xcee960: bl              #0x784bf8  ; [package:flutter/src/gestures/multitap.dart] DoubleTapGestureRecognizer::_reject
    // 0xcee964: add             SP, SP, #0x10
    // 0xcee968: r0 = Null
    //     0xcee968: mov             x0, NULL
    // 0xcee96c: LeaveFrame
    //     0xcee96c: mov             SP, fp
    //     0xcee970: ldp             fp, lr, [SP], #0x10
    // 0xcee974: ret
    //     0xcee974: ret             
    // 0xcee978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee978: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee97c: b               #0xcee8c4
  }
}

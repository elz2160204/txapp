// lib: , url: package:flutter/src/gestures/scale.dart

// class id: 1049170, size: 0x8
class :: {

  static _ _isFlingGesture(/* No info */) {
    // ** addr: 0x78cb18, size: 0x44
    // 0x78cb18: d0 = 2500.000000
    //     0x78cb18: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e858] IMM: double(2500) from 0x40a3880000000000
    //     0x78cb1c: ldr             d0, [x17, #0x858]
    // 0x78cb20: ldr             x1, [SP]
    // 0x78cb24: LoadField: r2 = r1->field_7
    //     0x78cb24: ldur            w2, [x1, #7]
    // 0x78cb28: DecompressPointer r2
    //     0x78cb28: add             x2, x2, HEAP, lsl #32
    // 0x78cb2c: LoadField: d1 = r2->field_7
    //     0x78cb2c: ldur            d1, [x2, #7]
    // 0x78cb30: fmul            d2, d1, d1
    // 0x78cb34: LoadField: d1 = r2->field_f
    //     0x78cb34: ldur            d1, [x2, #0xf]
    // 0x78cb38: fmul            d3, d1, d1
    // 0x78cb3c: fadd            d1, d2, d3
    // 0x78cb40: fcmp            d1, d0
    // 0x78cb44: b.vs            #0x78cb4c
    // 0x78cb48: b.gt            #0x78cb54
    // 0x78cb4c: r0 = false
    //     0x78cb4c: add             x0, NULL, #0x30  ; false
    // 0x78cb50: b               #0x78cb58
    // 0x78cb54: r0 = true
    //     0x78cb54: add             x0, NULL, #0x20  ; true
    // 0x78cb58: ret
    //     0x78cb58: ret             
  }
}

// class id: 2258, size: 0x20, field offset: 0x8
class _LineBetweenPointers extends Object {
}

// class id: 2259, size: 0x14, field offset: 0x8
class ScaleEndDetails extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad9cb4, size: 0x90
    // 0xad9cb4: EnterFrame
    //     0xad9cb4: stp             fp, lr, [SP, #-0x10]!
    //     0xad9cb8: mov             fp, SP
    // 0xad9cbc: CheckStackOverflow
    //     0xad9cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9cc0: cmp             SP, x16
    //     0xad9cc4: b.ls            #0xad9d3c
    // 0xad9cc8: r1 = Null
    //     0xad9cc8: mov             x1, NULL
    // 0xad9ccc: r2 = 10
    //     0xad9ccc: mov             x2, #0xa
    // 0xad9cd0: r0 = AllocateArray()
    //     0xad9cd0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9cd4: mov             x2, x0
    // 0xad9cd8: r17 = "ScaleEndDetails(velocity: "
    //     0xad9cd8: add             x17, PP, #0x37, lsl #12  ; [pp+0x37af0] "ScaleEndDetails(velocity: "
    //     0xad9cdc: ldr             x17, [x17, #0xaf0]
    // 0xad9ce0: StoreField: r2->field_f = r17
    //     0xad9ce0: stur            w17, [x2, #0xf]
    // 0xad9ce4: ldr             x0, [fp, #0x10]
    // 0xad9ce8: LoadField: r1 = r0->field_7
    //     0xad9ce8: ldur            w1, [x0, #7]
    // 0xad9cec: DecompressPointer r1
    //     0xad9cec: add             x1, x1, HEAP, lsl #32
    // 0xad9cf0: StoreField: r2->field_13 = r1
    //     0xad9cf0: stur            w1, [x2, #0x13]
    // 0xad9cf4: r17 = ", pointerCount: "
    //     0xad9cf4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ae0] ", pointerCount: "
    //     0xad9cf8: ldr             x17, [x17, #0xae0]
    // 0xad9cfc: StoreField: r2->field_17 = r17
    //     0xad9cfc: stur            w17, [x2, #0x17]
    // 0xad9d00: LoadField: r3 = r0->field_b
    //     0xad9d00: ldur            x3, [x0, #0xb]
    // 0xad9d04: r0 = BoxInt64Instr(r3)
    //     0xad9d04: sbfiz           x0, x3, #1, #0x1f
    //     0xad9d08: cmp             x3, x0, asr #1
    //     0xad9d0c: b.eq            #0xad9d18
    //     0xad9d10: bl              #0xd69bb8
    //     0xad9d14: stur            x3, [x0, #7]
    // 0xad9d18: StoreField: r2->field_1b = r0
    //     0xad9d18: stur            w0, [x2, #0x1b]
    // 0xad9d1c: r17 = ")"
    //     0xad9d1c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9d20: StoreField: r2->field_1f = r17
    //     0xad9d20: stur            w17, [x2, #0x1f]
    // 0xad9d24: SaveReg r2
    //     0xad9d24: str             x2, [SP, #-8]!
    // 0xad9d28: r0 = _interpolate()
    //     0xad9d28: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad9d2c: add             SP, SP, #8
    // 0xad9d30: LeaveFrame
    //     0xad9d30: mov             SP, fp
    //     0xad9d34: ldp             fp, lr, [SP], #0x10
    // 0xad9d38: ret
    //     0xad9d38: ret             
    // 0xad9d3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9d3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9d40: b               #0xad9cc8
  }
}

// class id: 2260, size: 0x3c, field offset: 0x8
class ScaleUpdateDetails extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad99cc, size: 0x2e8
    // 0xad99cc: EnterFrame
    //     0xad99cc: stp             fp, lr, [SP, #-0x10]!
    //     0xad99d0: mov             fp, SP
    // 0xad99d4: CheckStackOverflow
    //     0xad99d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad99d8: cmp             SP, x16
    //     0xad99dc: b.ls            #0xad9c4c
    // 0xad99e0: r1 = Null
    //     0xad99e0: mov             x1, NULL
    // 0xad99e4: r2 = 34
    //     0xad99e4: mov             x2, #0x22
    // 0xad99e8: r0 = AllocateArray()
    //     0xad99e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad99ec: mov             x2, x0
    // 0xad99f0: r17 = "ScaleUpdateDetails(focalPoint: "
    //     0xad99f0: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ac0] "ScaleUpdateDetails(focalPoint: "
    //     0xad99f4: ldr             x17, [x17, #0xac0]
    // 0xad99f8: StoreField: r2->field_f = r17
    //     0xad99f8: stur            w17, [x2, #0xf]
    // 0xad99fc: ldr             x3, [fp, #0x10]
    // 0xad9a00: LoadField: r0 = r3->field_b
    //     0xad9a00: ldur            w0, [x3, #0xb]
    // 0xad9a04: DecompressPointer r0
    //     0xad9a04: add             x0, x0, HEAP, lsl #32
    // 0xad9a08: StoreField: r2->field_13 = r0
    //     0xad9a08: stur            w0, [x2, #0x13]
    // 0xad9a0c: r17 = ", localFocalPoint: "
    //     0xad9a0c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e8a8] ", localFocalPoint: "
    //     0xad9a10: ldr             x17, [x17, #0x8a8]
    // 0xad9a14: StoreField: r2->field_17 = r17
    //     0xad9a14: stur            w17, [x2, #0x17]
    // 0xad9a18: LoadField: r0 = r3->field_f
    //     0xad9a18: ldur            w0, [x3, #0xf]
    // 0xad9a1c: DecompressPointer r0
    //     0xad9a1c: add             x0, x0, HEAP, lsl #32
    // 0xad9a20: StoreField: r2->field_1b = r0
    //     0xad9a20: stur            w0, [x2, #0x1b]
    // 0xad9a24: r17 = ", scale: "
    //     0xad9a24: add             x17, PP, #0x29, lsl #12  ; [pp+0x29230] ", scale: "
    //     0xad9a28: ldr             x17, [x17, #0x230]
    // 0xad9a2c: StoreField: r2->field_1f = r17
    //     0xad9a2c: stur            w17, [x2, #0x1f]
    // 0xad9a30: LoadField: d0 = r3->field_13
    //     0xad9a30: ldur            d0, [x3, #0x13]
    // 0xad9a34: r0 = inline_Allocate_Double()
    //     0xad9a34: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad9a38: add             x0, x0, #0x10
    //     0xad9a3c: cmp             x1, x0
    //     0xad9a40: b.ls            #0xad9c54
    //     0xad9a44: str             x0, [THR, #0x60]  ; THR::top
    //     0xad9a48: sub             x0, x0, #0xf
    //     0xad9a4c: mov             x1, #0xd108
    //     0xad9a50: movk            x1, #3, lsl #16
    //     0xad9a54: stur            x1, [x0, #-1]
    // 0xad9a58: StoreField: r0->field_7 = d0
    //     0xad9a58: stur            d0, [x0, #7]
    // 0xad9a5c: mov             x1, x2
    // 0xad9a60: ArrayStore: r1[5] = r0  ; List_4
    //     0xad9a60: add             x25, x1, #0x23
    //     0xad9a64: str             w0, [x25]
    //     0xad9a68: tbz             w0, #0, #0xad9a84
    //     0xad9a6c: ldurb           w16, [x1, #-1]
    //     0xad9a70: ldurb           w17, [x0, #-1]
    //     0xad9a74: and             x16, x17, x16, lsr #2
    //     0xad9a78: tst             x16, HEAP, lsr #32
    //     0xad9a7c: b.eq            #0xad9a84
    //     0xad9a80: bl              #0xd67e5c
    // 0xad9a84: r17 = ", horizontalScale: "
    //     0xad9a84: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ac8] ", horizontalScale: "
    //     0xad9a88: ldr             x17, [x17, #0xac8]
    // 0xad9a8c: StoreField: r2->field_27 = r17
    //     0xad9a8c: stur            w17, [x2, #0x27]
    // 0xad9a90: LoadField: d0 = r3->field_1b
    //     0xad9a90: ldur            d0, [x3, #0x1b]
    // 0xad9a94: r0 = inline_Allocate_Double()
    //     0xad9a94: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad9a98: add             x0, x0, #0x10
    //     0xad9a9c: cmp             x1, x0
    //     0xad9aa0: b.ls            #0xad9c6c
    //     0xad9aa4: str             x0, [THR, #0x60]  ; THR::top
    //     0xad9aa8: sub             x0, x0, #0xf
    //     0xad9aac: mov             x1, #0xd108
    //     0xad9ab0: movk            x1, #3, lsl #16
    //     0xad9ab4: stur            x1, [x0, #-1]
    // 0xad9ab8: StoreField: r0->field_7 = d0
    //     0xad9ab8: stur            d0, [x0, #7]
    // 0xad9abc: mov             x1, x2
    // 0xad9ac0: ArrayStore: r1[7] = r0  ; List_4
    //     0xad9ac0: add             x25, x1, #0x2b
    //     0xad9ac4: str             w0, [x25]
    //     0xad9ac8: tbz             w0, #0, #0xad9ae4
    //     0xad9acc: ldurb           w16, [x1, #-1]
    //     0xad9ad0: ldurb           w17, [x0, #-1]
    //     0xad9ad4: and             x16, x17, x16, lsr #2
    //     0xad9ad8: tst             x16, HEAP, lsr #32
    //     0xad9adc: b.eq            #0xad9ae4
    //     0xad9ae0: bl              #0xd67e5c
    // 0xad9ae4: r17 = ", verticalScale: "
    //     0xad9ae4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ad0] ", verticalScale: "
    //     0xad9ae8: ldr             x17, [x17, #0xad0]
    // 0xad9aec: StoreField: r2->field_2f = r17
    //     0xad9aec: stur            w17, [x2, #0x2f]
    // 0xad9af0: LoadField: d0 = r3->field_23
    //     0xad9af0: ldur            d0, [x3, #0x23]
    // 0xad9af4: r0 = inline_Allocate_Double()
    //     0xad9af4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad9af8: add             x0, x0, #0x10
    //     0xad9afc: cmp             x1, x0
    //     0xad9b00: b.ls            #0xad9c84
    //     0xad9b04: str             x0, [THR, #0x60]  ; THR::top
    //     0xad9b08: sub             x0, x0, #0xf
    //     0xad9b0c: mov             x1, #0xd108
    //     0xad9b10: movk            x1, #3, lsl #16
    //     0xad9b14: stur            x1, [x0, #-1]
    // 0xad9b18: StoreField: r0->field_7 = d0
    //     0xad9b18: stur            d0, [x0, #7]
    // 0xad9b1c: mov             x1, x2
    // 0xad9b20: ArrayStore: r1[9] = r0  ; List_4
    //     0xad9b20: add             x25, x1, #0x33
    //     0xad9b24: str             w0, [x25]
    //     0xad9b28: tbz             w0, #0, #0xad9b44
    //     0xad9b2c: ldurb           w16, [x1, #-1]
    //     0xad9b30: ldurb           w17, [x0, #-1]
    //     0xad9b34: and             x16, x17, x16, lsr #2
    //     0xad9b38: tst             x16, HEAP, lsr #32
    //     0xad9b3c: b.eq            #0xad9b44
    //     0xad9b40: bl              #0xd67e5c
    // 0xad9b44: r17 = ", rotation: "
    //     0xad9b44: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ad8] ", rotation: "
    //     0xad9b48: ldr             x17, [x17, #0xad8]
    // 0xad9b4c: StoreField: r2->field_37 = r17
    //     0xad9b4c: stur            w17, [x2, #0x37]
    // 0xad9b50: LoadField: d0 = r3->field_2b
    //     0xad9b50: ldur            d0, [x3, #0x2b]
    // 0xad9b54: r0 = inline_Allocate_Double()
    //     0xad9b54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad9b58: add             x0, x0, #0x10
    //     0xad9b5c: cmp             x1, x0
    //     0xad9b60: b.ls            #0xad9c9c
    //     0xad9b64: str             x0, [THR, #0x60]  ; THR::top
    //     0xad9b68: sub             x0, x0, #0xf
    //     0xad9b6c: mov             x1, #0xd108
    //     0xad9b70: movk            x1, #3, lsl #16
    //     0xad9b74: stur            x1, [x0, #-1]
    // 0xad9b78: StoreField: r0->field_7 = d0
    //     0xad9b78: stur            d0, [x0, #7]
    // 0xad9b7c: mov             x1, x2
    // 0xad9b80: ArrayStore: r1[11] = r0  ; List_4
    //     0xad9b80: add             x25, x1, #0x3b
    //     0xad9b84: str             w0, [x25]
    //     0xad9b88: tbz             w0, #0, #0xad9ba4
    //     0xad9b8c: ldurb           w16, [x1, #-1]
    //     0xad9b90: ldurb           w17, [x0, #-1]
    //     0xad9b94: and             x16, x17, x16, lsr #2
    //     0xad9b98: tst             x16, HEAP, lsr #32
    //     0xad9b9c: b.eq            #0xad9ba4
    //     0xad9ba0: bl              #0xd67e5c
    // 0xad9ba4: r17 = ", pointerCount: "
    //     0xad9ba4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ae0] ", pointerCount: "
    //     0xad9ba8: ldr             x17, [x17, #0xae0]
    // 0xad9bac: StoreField: r2->field_3f = r17
    //     0xad9bac: stur            w17, [x2, #0x3f]
    // 0xad9bb0: LoadField: r4 = r3->field_33
    //     0xad9bb0: ldur            x4, [x3, #0x33]
    // 0xad9bb4: r0 = BoxInt64Instr(r4)
    //     0xad9bb4: sbfiz           x0, x4, #1, #0x1f
    //     0xad9bb8: cmp             x4, x0, asr #1
    //     0xad9bbc: b.eq            #0xad9bc8
    //     0xad9bc0: bl              #0xd69bb8
    //     0xad9bc4: stur            x4, [x0, #7]
    // 0xad9bc8: mov             x1, x2
    // 0xad9bcc: ArrayStore: r1[13] = r0  ; List_4
    //     0xad9bcc: add             x25, x1, #0x43
    //     0xad9bd0: str             w0, [x25]
    //     0xad9bd4: tbz             w0, #0, #0xad9bf0
    //     0xad9bd8: ldurb           w16, [x1, #-1]
    //     0xad9bdc: ldurb           w17, [x0, #-1]
    //     0xad9be0: and             x16, x17, x16, lsr #2
    //     0xad9be4: tst             x16, HEAP, lsr #32
    //     0xad9be8: b.eq            #0xad9bf0
    //     0xad9bec: bl              #0xd67e5c
    // 0xad9bf0: r17 = ", focalPointDelta: "
    //     0xad9bf0: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ae8] ", focalPointDelta: "
    //     0xad9bf4: ldr             x17, [x17, #0xae8]
    // 0xad9bf8: StoreField: r2->field_47 = r17
    //     0xad9bf8: stur            w17, [x2, #0x47]
    // 0xad9bfc: LoadField: r0 = r3->field_7
    //     0xad9bfc: ldur            w0, [x3, #7]
    // 0xad9c00: DecompressPointer r0
    //     0xad9c00: add             x0, x0, HEAP, lsl #32
    // 0xad9c04: mov             x1, x2
    // 0xad9c08: ArrayStore: r1[15] = r0  ; List_4
    //     0xad9c08: add             x25, x1, #0x4b
    //     0xad9c0c: str             w0, [x25]
    //     0xad9c10: tbz             w0, #0, #0xad9c2c
    //     0xad9c14: ldurb           w16, [x1, #-1]
    //     0xad9c18: ldurb           w17, [x0, #-1]
    //     0xad9c1c: and             x16, x17, x16, lsr #2
    //     0xad9c20: tst             x16, HEAP, lsr #32
    //     0xad9c24: b.eq            #0xad9c2c
    //     0xad9c28: bl              #0xd67e5c
    // 0xad9c2c: r17 = ")"
    //     0xad9c2c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9c30: StoreField: r2->field_4f = r17
    //     0xad9c30: stur            w17, [x2, #0x4f]
    // 0xad9c34: SaveReg r2
    //     0xad9c34: str             x2, [SP, #-8]!
    // 0xad9c38: r0 = _interpolate()
    //     0xad9c38: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad9c3c: add             SP, SP, #8
    // 0xad9c40: LeaveFrame
    //     0xad9c40: mov             SP, fp
    //     0xad9c44: ldp             fp, lr, [SP], #0x10
    // 0xad9c48: ret
    //     0xad9c48: ret             
    // 0xad9c4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9c4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9c50: b               #0xad99e0
    // 0xad9c54: SaveReg d0
    //     0xad9c54: str             q0, [SP, #-0x10]!
    // 0xad9c58: stp             x2, x3, [SP, #-0x10]!
    // 0xad9c5c: r0 = AllocateDouble()
    //     0xad9c5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad9c60: ldp             x2, x3, [SP], #0x10
    // 0xad9c64: RestoreReg d0
    //     0xad9c64: ldr             q0, [SP], #0x10
    // 0xad9c68: b               #0xad9a58
    // 0xad9c6c: SaveReg d0
    //     0xad9c6c: str             q0, [SP, #-0x10]!
    // 0xad9c70: stp             x2, x3, [SP, #-0x10]!
    // 0xad9c74: r0 = AllocateDouble()
    //     0xad9c74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad9c78: ldp             x2, x3, [SP], #0x10
    // 0xad9c7c: RestoreReg d0
    //     0xad9c7c: ldr             q0, [SP], #0x10
    // 0xad9c80: b               #0xad9ab8
    // 0xad9c84: SaveReg d0
    //     0xad9c84: str             q0, [SP, #-0x10]!
    // 0xad9c88: stp             x2, x3, [SP, #-0x10]!
    // 0xad9c8c: r0 = AllocateDouble()
    //     0xad9c8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad9c90: ldp             x2, x3, [SP], #0x10
    // 0xad9c94: RestoreReg d0
    //     0xad9c94: ldr             q0, [SP], #0x10
    // 0xad9c98: b               #0xad9b18
    // 0xad9c9c: SaveReg d0
    //     0xad9c9c: str             q0, [SP, #-0x10]!
    // 0xad9ca0: stp             x2, x3, [SP, #-0x10]!
    // 0xad9ca4: r0 = AllocateDouble()
    //     0xad9ca4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad9ca8: ldp             x2, x3, [SP], #0x10
    // 0xad9cac: RestoreReg d0
    //     0xad9cac: ldr             q0, [SP], #0x10
    // 0xad9cb0: b               #0xad9b78
  }
}

// class id: 2261, size: 0x18, field offset: 0x8
class ScaleStartDetails extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad9924, size: 0xa8
    // 0xad9924: EnterFrame
    //     0xad9924: stp             fp, lr, [SP, #-0x10]!
    //     0xad9928: mov             fp, SP
    // 0xad992c: CheckStackOverflow
    //     0xad992c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9930: cmp             SP, x16
    //     0xad9934: b.ls            #0xad99c4
    // 0xad9938: r1 = Null
    //     0xad9938: mov             x1, NULL
    // 0xad993c: r2 = 14
    //     0xad993c: mov             x2, #0xe
    // 0xad9940: r0 = AllocateArray()
    //     0xad9940: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9944: mov             x2, x0
    // 0xad9948: r17 = "ScaleStartDetails(focalPoint: "
    //     0xad9948: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e8a0] "ScaleStartDetails(focalPoint: "
    //     0xad994c: ldr             x17, [x17, #0x8a0]
    // 0xad9950: StoreField: r2->field_f = r17
    //     0xad9950: stur            w17, [x2, #0xf]
    // 0xad9954: ldr             x0, [fp, #0x10]
    // 0xad9958: LoadField: r1 = r0->field_7
    //     0xad9958: ldur            w1, [x0, #7]
    // 0xad995c: DecompressPointer r1
    //     0xad995c: add             x1, x1, HEAP, lsl #32
    // 0xad9960: StoreField: r2->field_13 = r1
    //     0xad9960: stur            w1, [x2, #0x13]
    // 0xad9964: r17 = ", localFocalPoint: "
    //     0xad9964: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e8a8] ", localFocalPoint: "
    //     0xad9968: ldr             x17, [x17, #0x8a8]
    // 0xad996c: StoreField: r2->field_17 = r17
    //     0xad996c: stur            w17, [x2, #0x17]
    // 0xad9970: LoadField: r1 = r0->field_b
    //     0xad9970: ldur            w1, [x0, #0xb]
    // 0xad9974: DecompressPointer r1
    //     0xad9974: add             x1, x1, HEAP, lsl #32
    // 0xad9978: StoreField: r2->field_1b = r1
    //     0xad9978: stur            w1, [x2, #0x1b]
    // 0xad997c: r17 = ", pointersCount: "
    //     0xad997c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e8b0] ", pointersCount: "
    //     0xad9980: ldr             x17, [x17, #0x8b0]
    // 0xad9984: StoreField: r2->field_1f = r17
    //     0xad9984: stur            w17, [x2, #0x1f]
    // 0xad9988: LoadField: r3 = r0->field_f
    //     0xad9988: ldur            x3, [x0, #0xf]
    // 0xad998c: r0 = BoxInt64Instr(r3)
    //     0xad998c: sbfiz           x0, x3, #1, #0x1f
    //     0xad9990: cmp             x3, x0, asr #1
    //     0xad9994: b.eq            #0xad99a0
    //     0xad9998: bl              #0xd69bb8
    //     0xad999c: stur            x3, [x0, #7]
    // 0xad99a0: StoreField: r2->field_23 = r0
    //     0xad99a0: stur            w0, [x2, #0x23]
    // 0xad99a4: r17 = ")"
    //     0xad99a4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad99a8: StoreField: r2->field_27 = r17
    //     0xad99a8: stur            w17, [x2, #0x27]
    // 0xad99ac: SaveReg r2
    //     0xad99ac: str             x2, [SP, #-8]!
    // 0xad99b0: r0 = _interpolate()
    //     0xad99b0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad99b4: add             SP, SP, #8
    // 0xad99b8: LeaveFrame
    //     0xad99b8: mov             SP, fp
    //     0xad99bc: ldp             fp, lr, [SP], #0x10
    // 0xad99c0: ret
    //     0xad99c0: ret             
    // 0xad99c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad99c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad99c8: b               #0xad9938
  }
}

// class id: 2262, size: 0x1c, field offset: 0x8
class _PointerPanZoomData extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad9810, size: 0x114
    // 0xad9810: EnterFrame
    //     0xad9810: stp             fp, lr, [SP, #-0x10]!
    //     0xad9814: mov             fp, SP
    // 0xad9818: CheckStackOverflow
    //     0xad9818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad981c: cmp             SP, x16
    //     0xad9820: b.ls            #0xad98e4
    // 0xad9824: r1 = Null
    //     0xad9824: mov             x1, NULL
    // 0xad9828: r2 = 14
    //     0xad9828: mov             x2, #0xe
    // 0xad982c: r0 = AllocateArray()
    //     0xad982c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9830: r17 = "_PointerPanZoomData(focalPoint: "
    //     0xad9830: add             x17, PP, #0x37, lsl #12  ; [pp+0x37af8] "_PointerPanZoomData(focalPoint: "
    //     0xad9834: ldr             x17, [x17, #0xaf8]
    // 0xad9838: StoreField: r0->field_f = r17
    //     0xad9838: stur            w17, [x0, #0xf]
    // 0xad983c: ldr             x1, [fp, #0x10]
    // 0xad9840: LoadField: r2 = r1->field_7
    //     0xad9840: ldur            w2, [x1, #7]
    // 0xad9844: DecompressPointer r2
    //     0xad9844: add             x2, x2, HEAP, lsl #32
    // 0xad9848: StoreField: r0->field_13 = r2
    //     0xad9848: stur            w2, [x0, #0x13]
    // 0xad984c: r17 = ", scale: "
    //     0xad984c: add             x17, PP, #0x29, lsl #12  ; [pp+0x29230] ", scale: "
    //     0xad9850: ldr             x17, [x17, #0x230]
    // 0xad9854: StoreField: r0->field_17 = r17
    //     0xad9854: stur            w17, [x0, #0x17]
    // 0xad9858: LoadField: d0 = r1->field_b
    //     0xad9858: ldur            d0, [x1, #0xb]
    // 0xad985c: r2 = inline_Allocate_Double()
    //     0xad985c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad9860: add             x2, x2, #0x10
    //     0xad9864: cmp             x3, x2
    //     0xad9868: b.ls            #0xad98ec
    //     0xad986c: str             x2, [THR, #0x60]  ; THR::top
    //     0xad9870: sub             x2, x2, #0xf
    //     0xad9874: mov             x3, #0xd108
    //     0xad9878: movk            x3, #3, lsl #16
    //     0xad987c: stur            x3, [x2, #-1]
    // 0xad9880: StoreField: r2->field_7 = d0
    //     0xad9880: stur            d0, [x2, #7]
    // 0xad9884: StoreField: r0->field_1b = r2
    //     0xad9884: stur            w2, [x0, #0x1b]
    // 0xad9888: r17 = ", angle: "
    //     0xad9888: add             x17, PP, #0x37, lsl #12  ; [pp+0x37b00] ", angle: "
    //     0xad988c: ldr             x17, [x17, #0xb00]
    // 0xad9890: StoreField: r0->field_1f = r17
    //     0xad9890: stur            w17, [x0, #0x1f]
    // 0xad9894: LoadField: d0 = r1->field_13
    //     0xad9894: ldur            d0, [x1, #0x13]
    // 0xad9898: r1 = inline_Allocate_Double()
    //     0xad9898: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xad989c: add             x1, x1, #0x10
    //     0xad98a0: cmp             x2, x1
    //     0xad98a4: b.ls            #0xad9908
    //     0xad98a8: str             x1, [THR, #0x60]  ; THR::top
    //     0xad98ac: sub             x1, x1, #0xf
    //     0xad98b0: mov             x2, #0xd108
    //     0xad98b4: movk            x2, #3, lsl #16
    //     0xad98b8: stur            x2, [x1, #-1]
    // 0xad98bc: StoreField: r1->field_7 = d0
    //     0xad98bc: stur            d0, [x1, #7]
    // 0xad98c0: StoreField: r0->field_23 = r1
    //     0xad98c0: stur            w1, [x0, #0x23]
    // 0xad98c4: r17 = ")"
    //     0xad98c4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad98c8: StoreField: r0->field_27 = r17
    //     0xad98c8: stur            w17, [x0, #0x27]
    // 0xad98cc: SaveReg r0
    //     0xad98cc: str             x0, [SP, #-8]!
    // 0xad98d0: r0 = _interpolate()
    //     0xad98d0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad98d4: add             SP, SP, #8
    // 0xad98d8: LeaveFrame
    //     0xad98d8: mov             SP, fp
    //     0xad98dc: ldp             fp, lr, [SP], #0x10
    // 0xad98e0: ret
    //     0xad98e0: ret             
    // 0xad98e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad98e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad98e8: b               #0xad9824
    // 0xad98ec: SaveReg d0
    //     0xad98ec: str             q0, [SP, #-0x10]!
    // 0xad98f0: stp             x0, x1, [SP, #-0x10]!
    // 0xad98f4: r0 = AllocateDouble()
    //     0xad98f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad98f8: mov             x2, x0
    // 0xad98fc: ldp             x0, x1, [SP], #0x10
    // 0xad9900: RestoreReg d0
    //     0xad9900: ldr             q0, [SP], #0x10
    // 0xad9904: b               #0xad9880
    // 0xad9908: SaveReg d0
    //     0xad9908: str             q0, [SP, #-0x10]!
    // 0xad990c: SaveReg r0
    //     0xad990c: str             x0, [SP, #-8]!
    // 0xad9910: r0 = AllocateDouble()
    //     0xad9910: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad9914: mov             x1, x0
    // 0xad9918: RestoreReg r0
    //     0xad9918: ldr             x0, [SP], #8
    // 0xad991c: RestoreReg d0
    //     0xad991c: ldr             q0, [SP], #0x10
    // 0xad9920: b               #0xad98bc
  }
}

// class id: 2351, size: 0x88, field offset: 0x20
class ScaleGestureRecognizer extends OneSequenceGestureRecognizer {

  late double _currentSpan; // offset: 0x44
  late double _currentHorizontalSpan; // offset: 0x4c
  late double _currentVerticalSpan; // offset: 0x54
  late double _initialSpan; // offset: 0x40
  late Offset _localFocalPoint; // offset: 0x58
  late Offset _initialFocalPoint; // offset: 0x38
  late Offset _delta; // offset: 0x70
  late double _initialVerticalSpan; // offset: 0x50
  late double _initialHorizontalSpan; // offset: 0x48

  [closure] double <anonymous closure>(dynamic, double, double) {
    // ** addr: 0x70410c, size: 0x60
    // 0x70410c: EnterFrame
    //     0x70410c: stp             fp, lr, [SP, #-0x10]!
    //     0x704110: mov             fp, SP
    // 0x704114: ldr             x1, [fp, #0x18]
    // 0x704118: LoadField: d0 = r1->field_7
    //     0x704118: ldur            d0, [x1, #7]
    // 0x70411c: ldr             x1, [fp, #0x10]
    // 0x704120: LoadField: d1 = r1->field_7
    //     0x704120: ldur            d1, [x1, #7]
    // 0x704124: fadd            d2, d0, d1
    // 0x704128: r0 = inline_Allocate_Double()
    //     0x704128: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x70412c: add             x0, x0, #0x10
    //     0x704130: cmp             x1, x0
    //     0x704134: b.ls            #0x70415c
    //     0x704138: str             x0, [THR, #0x60]  ; THR::top
    //     0x70413c: sub             x0, x0, #0xf
    //     0x704140: mov             x1, #0xd108
    //     0x704144: movk            x1, #3, lsl #16
    //     0x704148: stur            x1, [x0, #-1]
    // 0x70414c: StoreField: r0->field_7 = d2
    //     0x70414c: stur            d2, [x0, #7]
    // 0x704150: LeaveFrame
    //     0x704150: mov             SP, fp
    //     0x704154: ldp             fp, lr, [SP], #0x10
    // 0x704158: ret
    //     0x704158: ret             
    // 0x70415c: SaveReg d2
    //     0x70415c: str             q2, [SP, #-0x10]!
    // 0x704160: r0 = AllocateDouble()
    //     0x704160: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x704164: RestoreReg d2
    //     0x704164: ldr             q2, [SP], #0x10
    // 0x704168: b               #0x70414c
  }
  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0x714a08, size: 0x80
    // 0x714a08: EnterFrame
    //     0x714a08: stp             fp, lr, [SP, #-0x10]!
    //     0x714a0c: mov             fp, SP
    // 0x714a10: CheckStackOverflow
    //     0x714a10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714a14: cmp             SP, x16
    //     0x714a18: b.ls            #0x714a80
    // 0x714a1c: ldr             x0, [fp, #0x18]
    // 0x714a20: LoadField: r1 = r0->field_2f
    //     0x714a20: ldur            w1, [x0, #0x2f]
    // 0x714a24: DecompressPointer r1
    //     0x714a24: add             x1, x1, HEAP, lsl #32
    // 0x714a28: LoadField: r2 = r1->field_7
    //     0x714a28: ldur            x2, [x1, #7]
    // 0x714a2c: cmp             x2, #1
    // 0x714a30: b.gt            #0x714a60
    // 0x714a34: cmp             x2, #0
    // 0x714a38: b.gt            #0x714a44
    // 0x714a3c: mov             x1, x0
    // 0x714a40: b               #0x714a64
    // 0x714a44: r16 = Instance_GestureDisposition
    //     0x714a44: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x714a48: ldr             x16, [x16, #0xeb8]
    // 0x714a4c: stp             x16, x0, [SP, #-0x10]!
    // 0x714a50: r0 = resolve()
    //     0x714a50: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x714a54: add             SP, SP, #0x10
    // 0x714a58: ldr             x1, [fp, #0x18]
    // 0x714a5c: b               #0x714a64
    // 0x714a60: ldr             x1, [fp, #0x18]
    // 0x714a64: r2 = Instance__ScaleState
    //     0x714a64: add             x2, PP, #0x21, lsl #12  ; [pp+0x21488] Obj!_ScaleState@b65a11
    //     0x714a68: ldr             x2, [x2, #0x488]
    // 0x714a6c: StoreField: r1->field_2f = r2
    //     0x714a6c: stur            w2, [x1, #0x2f]
    // 0x714a70: r0 = Null
    //     0x714a70: mov             x0, NULL
    // 0x714a74: LeaveFrame
    //     0x714a74: mov             SP, fp
    //     0x714a78: ldp             fp, lr, [SP], #0x10
    // 0x714a7c: ret
    //     0x714a7c: ret             
    // 0x714a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714a80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714a84: b               #0x714a1c
  }
  _ addAllowedPointerPanZoom(/* No info */) {
    // ** addr: 0x719fd4, size: 0x18c
    // 0x719fd4: EnterFrame
    //     0x719fd4: stp             fp, lr, [SP, #-0x10]!
    //     0x719fd8: mov             fp, SP
    // 0x719fdc: AllocStack(0x20)
    //     0x719fdc: sub             SP, SP, #0x20
    // 0x719fe0: CheckStackOverflow
    //     0x719fe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x719fe4: cmp             SP, x16
    //     0x719fe8: b.ls            #0x71a158
    // 0x719fec: ldr             x1, [fp, #0x10]
    // 0x719ff0: r0 = LoadClassIdInstr(r1)
    //     0x719ff0: ldur            x0, [x1, #-1]
    //     0x719ff4: ubfx            x0, x0, #0xc, #0x14
    // 0x719ff8: SaveReg r1
    //     0x719ff8: str             x1, [SP, #-8]!
    // 0x719ffc: r0 = GDT[cid_x0 + -0xfff]()
    //     0x719ffc: sub             lr, x0, #0xfff
    //     0x71a000: ldr             lr, [x21, lr, lsl #3]
    //     0x71a004: blr             lr
    // 0x71a008: add             SP, SP, #8
    // 0x71a00c: mov             x2, x0
    // 0x71a010: ldr             x1, [fp, #0x10]
    // 0x71a014: stur            x2, [fp, #-8]
    // 0x71a018: r0 = LoadClassIdInstr(r1)
    //     0x71a018: ldur            x0, [x1, #-1]
    //     0x71a01c: ubfx            x0, x0, #0xc, #0x14
    // 0x71a020: SaveReg r1
    //     0x71a020: str             x1, [SP, #-8]!
    // 0x71a024: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x71a024: mov             x17, #0x3f6e
    //     0x71a028: add             lr, x0, x17
    //     0x71a02c: ldr             lr, [x21, lr, lsl #3]
    //     0x71a030: blr             lr
    // 0x71a034: add             SP, SP, #8
    // 0x71a038: ldr             x16, [fp, #0x18]
    // 0x71a03c: SaveReg r16
    //     0x71a03c: str             x16, [SP, #-8]!
    // 0x71a040: ldur            x1, [fp, #-8]
    // 0x71a044: stp             x0, x1, [SP, #-0x10]!
    // 0x71a048: r0 = startTrackingPointer()
    //     0x71a048: bl              #0x71111c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::startTrackingPointer
    // 0x71a04c: add             SP, SP, #0x18
    // 0x71a050: ldr             x1, [fp, #0x18]
    // 0x71a054: LoadField: r2 = r1->field_6b
    //     0x71a054: ldur            w2, [x1, #0x6b]
    // 0x71a058: DecompressPointer r2
    //     0x71a058: add             x2, x2, HEAP, lsl #32
    // 0x71a05c: ldr             x3, [fp, #0x10]
    // 0x71a060: stur            x2, [fp, #-0x10]
    // 0x71a064: r0 = LoadClassIdInstr(r3)
    //     0x71a064: ldur            x0, [x3, #-1]
    //     0x71a068: ubfx            x0, x0, #0xc, #0x14
    // 0x71a06c: SaveReg r3
    //     0x71a06c: str             x3, [SP, #-8]!
    // 0x71a070: r0 = GDT[cid_x0 + -0xfff]()
    //     0x71a070: sub             lr, x0, #0xfff
    //     0x71a074: ldr             lr, [x21, lr, lsl #3]
    //     0x71a078: blr             lr
    // 0x71a07c: add             SP, SP, #8
    // 0x71a080: mov             x1, x0
    // 0x71a084: ldr             x0, [fp, #0x10]
    // 0x71a088: stur            x1, [fp, #-8]
    // 0x71a08c: r2 = LoadClassIdInstr(r0)
    //     0x71a08c: ldur            x2, [x0, #-1]
    //     0x71a090: ubfx            x2, x2, #0xc, #0x14
    // 0x71a094: SaveReg r0
    //     0x71a094: str             x0, [SP, #-8]!
    // 0x71a098: mov             x0, x2
    // 0x71a09c: r0 = GDT[cid_x0 + -0xf60]()
    //     0x71a09c: sub             lr, x0, #0xf60
    //     0x71a0a0: ldr             lr, [x21, lr, lsl #3]
    //     0x71a0a4: blr             lr
    // 0x71a0a8: add             SP, SP, #8
    // 0x71a0ac: stur            x0, [fp, #-0x18]
    // 0x71a0b0: r0 = VelocityTracker()
    //     0x71a0b0: bl              #0x6ee4b0  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x18)
    // 0x71a0b4: mov             x3, x0
    // 0x71a0b8: r0 = 0
    //     0x71a0b8: mov             x0, #0
    // 0x71a0bc: stur            x3, [fp, #-0x20]
    // 0x71a0c0: StoreField: r3->field_f = r0
    //     0x71a0c0: stur            x0, [x3, #0xf]
    // 0x71a0c4: r1 = <_PointAtTime?>
    //     0x71a0c4: add             x1, PP, #0x21, lsl #12  ; [pp+0x214e8] TypeArguments: <_PointAtTime?>
    //     0x71a0c8: ldr             x1, [x1, #0x4e8]
    // 0x71a0cc: r2 = 40
    //     0x71a0cc: mov             x2, #0x28
    // 0x71a0d0: r0 = AllocateArray()
    //     0x71a0d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x71a0d4: ldur            x2, [fp, #-0x20]
    // 0x71a0d8: StoreField: r2->field_b = r0
    //     0x71a0d8: stur            w0, [x2, #0xb]
    // 0x71a0dc: ldur            x0, [fp, #-0x18]
    // 0x71a0e0: StoreField: r2->field_7 = r0
    //     0x71a0e0: stur            w0, [x2, #7]
    // 0x71a0e4: ldur            x3, [fp, #-8]
    // 0x71a0e8: r0 = BoxInt64Instr(r3)
    //     0x71a0e8: sbfiz           x0, x3, #1, #0x1f
    //     0x71a0ec: cmp             x3, x0, asr #1
    //     0x71a0f0: b.eq            #0x71a0fc
    //     0x71a0f4: bl              #0xd69bb8
    //     0x71a0f8: stur            x3, [x0, #7]
    // 0x71a0fc: ldur            x16, [fp, #-0x10]
    // 0x71a100: stp             x0, x16, [SP, #-0x10]!
    // 0x71a104: SaveReg r2
    //     0x71a104: str             x2, [SP, #-8]!
    // 0x71a108: r0 = []=()
    //     0x71a108: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x71a10c: add             SP, SP, #0x18
    // 0x71a110: ldr             x1, [fp, #0x18]
    // 0x71a114: LoadField: r2 = r1->field_2f
    //     0x71a114: ldur            w2, [x1, #0x2f]
    // 0x71a118: DecompressPointer r2
    //     0x71a118: add             x2, x2, HEAP, lsl #32
    // 0x71a11c: r16 = Instance__ScaleState
    //     0x71a11c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21488] Obj!_ScaleState@b65a11
    //     0x71a120: ldr             x16, [x16, #0x488]
    // 0x71a124: cmp             w2, w16
    // 0x71a128: b.ne            #0x71a148
    // 0x71a12c: r2 = Instance__ScaleState
    //     0x71a12c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28e18] Obj!_ScaleState@b65a31
    //     0x71a130: ldr             x2, [x2, #0xe18]
    // 0x71a134: d1 = 1.000000
    //     0x71a134: fmov            d1, #1.00000000
    // 0x71a138: d0 = 0.000000
    //     0x71a138: eor             v0.16b, v0.16b, v0.16b
    // 0x71a13c: StoreField: r1->field_2f = r2
    //     0x71a13c: stur            w2, [x1, #0x2f]
    // 0x71a140: StoreField: r1->field_77 = d1
    //     0x71a140: stur            d1, [x1, #0x77]
    // 0x71a144: StoreField: r1->field_7f = d0
    //     0x71a144: stur            d0, [x1, #0x7f]
    // 0x71a148: r0 = Null
    //     0x71a148: mov             x0, NULL
    // 0x71a14c: LeaveFrame
    //     0x71a14c: mov             SP, fp
    //     0x71a150: ldp             fp, lr, [SP], #0x10
    // 0x71a154: ret
    //     0x71a154: ret             
    // 0x71a158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71a158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71a15c: b               #0x719fec
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x782f70, size: 0x148
    // 0x782f70: EnterFrame
    //     0x782f70: stp             fp, lr, [SP, #-0x10]!
    //     0x782f74: mov             fp, SP
    // 0x782f78: AllocStack(0x20)
    //     0x782f78: sub             SP, SP, #0x20
    // 0x782f7c: CheckStackOverflow
    //     0x782f7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782f80: cmp             SP, x16
    //     0x782f84: b.ls            #0x7830b0
    // 0x782f88: ldr             x16, [fp, #0x18]
    // 0x782f8c: ldr             lr, [fp, #0x10]
    // 0x782f90: stp             lr, x16, [SP, #-0x10]!
    // 0x782f94: r0 = addAllowedPointer()
    //     0x782f94: bl              #0x782114  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0x782f98: add             SP, SP, #0x10
    // 0x782f9c: ldr             x1, [fp, #0x18]
    // 0x782fa0: LoadField: r2 = r1->field_6b
    //     0x782fa0: ldur            w2, [x1, #0x6b]
    // 0x782fa4: DecompressPointer r2
    //     0x782fa4: add             x2, x2, HEAP, lsl #32
    // 0x782fa8: ldr             x3, [fp, #0x10]
    // 0x782fac: stur            x2, [fp, #-8]
    // 0x782fb0: r0 = LoadClassIdInstr(r3)
    //     0x782fb0: ldur            x0, [x3, #-1]
    //     0x782fb4: ubfx            x0, x0, #0xc, #0x14
    // 0x782fb8: SaveReg r3
    //     0x782fb8: str             x3, [SP, #-8]!
    // 0x782fbc: r0 = GDT[cid_x0 + -0xfff]()
    //     0x782fbc: sub             lr, x0, #0xfff
    //     0x782fc0: ldr             lr, [x21, lr, lsl #3]
    //     0x782fc4: blr             lr
    // 0x782fc8: add             SP, SP, #8
    // 0x782fcc: mov             x1, x0
    // 0x782fd0: ldr             x0, [fp, #0x10]
    // 0x782fd4: stur            x1, [fp, #-0x10]
    // 0x782fd8: r2 = LoadClassIdInstr(r0)
    //     0x782fd8: ldur            x2, [x0, #-1]
    //     0x782fdc: ubfx            x2, x2, #0xc, #0x14
    // 0x782fe0: SaveReg r0
    //     0x782fe0: str             x0, [SP, #-8]!
    // 0x782fe4: mov             x0, x2
    // 0x782fe8: r0 = GDT[cid_x0 + -0xf60]()
    //     0x782fe8: sub             lr, x0, #0xf60
    //     0x782fec: ldr             lr, [x21, lr, lsl #3]
    //     0x782ff0: blr             lr
    // 0x782ff4: add             SP, SP, #8
    // 0x782ff8: stur            x0, [fp, #-0x18]
    // 0x782ffc: r0 = VelocityTracker()
    //     0x782ffc: bl              #0x6ee4b0  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x18)
    // 0x783000: mov             x3, x0
    // 0x783004: r0 = 0
    //     0x783004: mov             x0, #0
    // 0x783008: stur            x3, [fp, #-0x20]
    // 0x78300c: StoreField: r3->field_f = r0
    //     0x78300c: stur            x0, [x3, #0xf]
    // 0x783010: r1 = <_PointAtTime?>
    //     0x783010: add             x1, PP, #0x21, lsl #12  ; [pp+0x214e8] TypeArguments: <_PointAtTime?>
    //     0x783014: ldr             x1, [x1, #0x4e8]
    // 0x783018: r2 = 40
    //     0x783018: mov             x2, #0x28
    // 0x78301c: r0 = AllocateArray()
    //     0x78301c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x783020: ldur            x2, [fp, #-0x20]
    // 0x783024: StoreField: r2->field_b = r0
    //     0x783024: stur            w0, [x2, #0xb]
    // 0x783028: ldur            x0, [fp, #-0x18]
    // 0x78302c: StoreField: r2->field_7 = r0
    //     0x78302c: stur            w0, [x2, #7]
    // 0x783030: ldur            x3, [fp, #-0x10]
    // 0x783034: r0 = BoxInt64Instr(r3)
    //     0x783034: sbfiz           x0, x3, #1, #0x1f
    //     0x783038: cmp             x3, x0, asr #1
    //     0x78303c: b.eq            #0x783048
    //     0x783040: bl              #0xd69bb8
    //     0x783044: stur            x3, [x0, #7]
    // 0x783048: ldur            x16, [fp, #-8]
    // 0x78304c: stp             x0, x16, [SP, #-0x10]!
    // 0x783050: SaveReg r2
    //     0x783050: str             x2, [SP, #-8]!
    // 0x783054: r0 = []=()
    //     0x783054: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x783058: add             SP, SP, #0x18
    // 0x78305c: ldr             x1, [fp, #0x18]
    // 0x783060: LoadField: r2 = r1->field_2f
    //     0x783060: ldur            w2, [x1, #0x2f]
    // 0x783064: DecompressPointer r2
    //     0x783064: add             x2, x2, HEAP, lsl #32
    // 0x783068: r16 = Instance__ScaleState
    //     0x783068: add             x16, PP, #0x21, lsl #12  ; [pp+0x21488] Obj!_ScaleState@b65a11
    //     0x78306c: ldr             x16, [x16, #0x488]
    // 0x783070: cmp             w2, w16
    // 0x783074: b.ne            #0x7830a0
    // 0x783078: r3 = Instance__ScaleState
    //     0x783078: add             x3, PP, #0x28, lsl #12  ; [pp+0x28e18] Obj!_ScaleState@b65a31
    //     0x78307c: ldr             x3, [x3, #0xe18]
    // 0x783080: r2 = 0.000000
    //     0x783080: ldr             x2, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x783084: StoreField: r1->field_2f = r3
    //     0x783084: stur            w3, [x1, #0x2f]
    // 0x783088: StoreField: r1->field_3f = r2
    //     0x783088: stur            w2, [x1, #0x3f]
    // 0x78308c: StoreField: r1->field_43 = r2
    //     0x78308c: stur            w2, [x1, #0x43]
    // 0x783090: StoreField: r1->field_47 = r2
    //     0x783090: stur            w2, [x1, #0x47]
    // 0x783094: StoreField: r1->field_4b = r2
    //     0x783094: stur            w2, [x1, #0x4b]
    // 0x783098: StoreField: r1->field_4f = r2
    //     0x783098: stur            w2, [x1, #0x4f]
    // 0x78309c: StoreField: r1->field_53 = r2
    //     0x78309c: stur            w2, [x1, #0x53]
    // 0x7830a0: r0 = Null
    //     0x7830a0: mov             x0, NULL
    // 0x7830a4: LeaveFrame
    //     0x7830a4: mov             SP, fp
    //     0x7830a8: ldp             fp, lr, [SP], #0x10
    // 0x7830ac: ret
    //     0x7830ac: ret             
    // 0x7830b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7830b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7830b4: b               #0x782f88
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0x78ac94, size: 0x18
    // 0x78ac94: r4 = 0
    //     0x78ac94: mov             x4, #0
    // 0x78ac98: r1 = Function 'handleEvent':.
    //     0x78ac98: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e7b0] AnonymousClosure: (0x78acac), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::handleEvent (0x78acf8)
    //     0x78ac9c: ldr             x1, [x17, #0x7b0]
    // 0x78aca0: r24 = BuildNonGenericMethodExtractorStub
    //     0x78aca0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x78aca4: LoadField: r0 = r24->field_17
    //     0x78aca4: ldur            x0, [x24, #0x17]
    // 0x78aca8: br              x0
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x78acac, size: 0x4c
    // 0x78acac: EnterFrame
    //     0x78acac: stp             fp, lr, [SP, #-0x10]!
    //     0x78acb0: mov             fp, SP
    // 0x78acb4: ldr             x0, [fp, #0x18]
    // 0x78acb8: LoadField: r1 = r0->field_17
    //     0x78acb8: ldur            w1, [x0, #0x17]
    // 0x78acbc: DecompressPointer r1
    //     0x78acbc: add             x1, x1, HEAP, lsl #32
    // 0x78acc0: CheckStackOverflow
    //     0x78acc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78acc4: cmp             SP, x16
    //     0x78acc8: b.ls            #0x78acf0
    // 0x78accc: LoadField: r0 = r1->field_f
    //     0x78accc: ldur            w0, [x1, #0xf]
    // 0x78acd0: DecompressPointer r0
    //     0x78acd0: add             x0, x0, HEAP, lsl #32
    // 0x78acd4: ldr             x16, [fp, #0x10]
    // 0x78acd8: stp             x16, x0, [SP, #-0x10]!
    // 0x78acdc: r0 = handleEvent()
    //     0x78acdc: bl              #0x78acf8  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::handleEvent
    // 0x78ace0: add             SP, SP, #0x10
    // 0x78ace4: LeaveFrame
    //     0x78ace4: mov             SP, fp
    //     0x78ace8: ldp             fp, lr, [SP], #0x10
    // 0x78acec: ret
    //     0x78acec: ret             
    // 0x78acf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78acf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78acf4: b               #0x78accc
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x78acf8, size: 0xb3c
    // 0x78acf8: EnterFrame
    //     0x78acf8: stp             fp, lr, [SP, #-0x10]!
    //     0x78acfc: mov             fp, SP
    // 0x78ad00: AllocStack(0x28)
    //     0x78ad00: sub             SP, SP, #0x28
    // 0x78ad04: CheckStackOverflow
    //     0x78ad04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78ad08: cmp             SP, x16
    //     0x78ad0c: b.ls            #0x78b820
    // 0x78ad10: ldr             x0, [fp, #0x10]
    // 0x78ad14: r2 = Null
    //     0x78ad14: mov             x2, NULL
    // 0x78ad18: r1 = Null
    //     0x78ad18: mov             x1, NULL
    // 0x78ad1c: cmp             w0, NULL
    // 0x78ad20: b.eq            #0x78ad40
    // 0x78ad24: branchIfSmi(r0, 0x78ad40)
    //     0x78ad24: tbz             w0, #0, #0x78ad40
    // 0x78ad28: r3 = LoadClassIdInstr(r0)
    //     0x78ad28: ldur            x3, [x0, #-1]
    //     0x78ad2c: ubfx            x3, x3, #0xc, #0x14
    // 0x78ad30: cmp             x3, #0x908
    // 0x78ad34: b.eq            #0x78ad48
    // 0x78ad38: cmp             x3, #0xb3f
    // 0x78ad3c: b.eq            #0x78ad48
    // 0x78ad40: r0 = false
    //     0x78ad40: add             x0, NULL, #0x30  ; false
    // 0x78ad44: b               #0x78ad4c
    // 0x78ad48: r0 = true
    //     0x78ad48: add             x0, NULL, #0x20  ; true
    // 0x78ad4c: tbnz            w0, #4, #0x78af54
    // 0x78ad50: ldr             x2, [fp, #0x18]
    // 0x78ad54: ldr             x1, [fp, #0x10]
    // 0x78ad58: LoadField: r3 = r2->field_6b
    //     0x78ad58: ldur            w3, [x2, #0x6b]
    // 0x78ad5c: DecompressPointer r3
    //     0x78ad5c: add             x3, x3, HEAP, lsl #32
    // 0x78ad60: stur            x3, [fp, #-8]
    // 0x78ad64: r0 = LoadClassIdInstr(r1)
    //     0x78ad64: ldur            x0, [x1, #-1]
    //     0x78ad68: ubfx            x0, x0, #0xc, #0x14
    // 0x78ad6c: SaveReg r1
    //     0x78ad6c: str             x1, [SP, #-8]!
    // 0x78ad70: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78ad70: sub             lr, x0, #0xfff
    //     0x78ad74: ldr             lr, [x21, lr, lsl #3]
    //     0x78ad78: blr             lr
    // 0x78ad7c: add             SP, SP, #8
    // 0x78ad80: mov             x2, x0
    // 0x78ad84: r0 = BoxInt64Instr(r2)
    //     0x78ad84: sbfiz           x0, x2, #1, #0x1f
    //     0x78ad88: cmp             x2, x0, asr #1
    //     0x78ad8c: b.eq            #0x78ad98
    //     0x78ad90: bl              #0xd69bb8
    //     0x78ad94: stur            x2, [x0, #7]
    // 0x78ad98: ldur            x16, [fp, #-8]
    // 0x78ad9c: stp             x0, x16, [SP, #-0x10]!
    // 0x78ada0: r0 = _getValueOrData()
    //     0x78ada0: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78ada4: add             SP, SP, #0x10
    // 0x78ada8: mov             x1, x0
    // 0x78adac: ldur            x0, [fp, #-8]
    // 0x78adb0: LoadField: r2 = r0->field_f
    //     0x78adb0: ldur            w2, [x0, #0xf]
    // 0x78adb4: DecompressPointer r2
    //     0x78adb4: add             x2, x2, HEAP, lsl #32
    // 0x78adb8: cmp             w2, w1
    // 0x78adbc: b.ne            #0x78adc8
    // 0x78adc0: r2 = Null
    //     0x78adc0: mov             x2, NULL
    // 0x78adc4: b               #0x78adcc
    // 0x78adc8: mov             x2, x1
    // 0x78adcc: ldr             x1, [fp, #0x10]
    // 0x78add0: stur            x2, [fp, #-8]
    // 0x78add4: cmp             w2, NULL
    // 0x78add8: b.eq            #0x78b828
    // 0x78addc: r0 = LoadClassIdInstr(r1)
    //     0x78addc: ldur            x0, [x1, #-1]
    //     0x78ade0: ubfx            x0, x0, #0xc, #0x14
    // 0x78ade4: SaveReg r1
    //     0x78ade4: str             x1, [SP, #-8]!
    // 0x78ade8: r0 = GDT[cid_x0 + 0x7012]()
    //     0x78ade8: mov             x17, #0x7012
    //     0x78adec: add             lr, x0, x17
    //     0x78adf0: ldr             lr, [x21, lr, lsl #3]
    //     0x78adf4: blr             lr
    // 0x78adf8: add             SP, SP, #8
    // 0x78adfc: tbz             w0, #4, #0x78ae7c
    // 0x78ae00: ldr             x1, [fp, #0x10]
    // 0x78ae04: ldur            x2, [fp, #-8]
    // 0x78ae08: r0 = LoadClassIdInstr(r1)
    //     0x78ae08: ldur            x0, [x1, #-1]
    //     0x78ae0c: ubfx            x0, x0, #0xc, #0x14
    // 0x78ae10: SaveReg r1
    //     0x78ae10: str             x1, [SP, #-8]!
    // 0x78ae14: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x78ae14: sub             lr, x0, #0xf3a
    //     0x78ae18: ldr             lr, [x21, lr, lsl #3]
    //     0x78ae1c: blr             lr
    // 0x78ae20: add             SP, SP, #8
    // 0x78ae24: mov             x2, x0
    // 0x78ae28: ldr             x1, [fp, #0x10]
    // 0x78ae2c: stur            x2, [fp, #-0x10]
    // 0x78ae30: r0 = LoadClassIdInstr(r1)
    //     0x78ae30: ldur            x0, [x1, #-1]
    //     0x78ae34: ubfx            x0, x0, #0xc, #0x14
    // 0x78ae38: SaveReg r1
    //     0x78ae38: str             x1, [SP, #-8]!
    // 0x78ae3c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x78ae3c: sub             lr, x0, #0xfd9
    //     0x78ae40: ldr             lr, [x21, lr, lsl #3]
    //     0x78ae44: blr             lr
    // 0x78ae48: add             SP, SP, #8
    // 0x78ae4c: mov             x1, x0
    // 0x78ae50: ldur            x0, [fp, #-8]
    // 0x78ae54: r2 = LoadClassIdInstr(r0)
    //     0x78ae54: ldur            x2, [x0, #-1]
    //     0x78ae58: ubfx            x2, x2, #0xc, #0x14
    // 0x78ae5c: ldur            x16, [fp, #-0x10]
    // 0x78ae60: stp             x16, x0, [SP, #-0x10]!
    // 0x78ae64: SaveReg r1
    //     0x78ae64: str             x1, [SP, #-8]!
    // 0x78ae68: mov             x0, x2
    // 0x78ae6c: r0 = GDT[cid_x0 + -0xf82]()
    //     0x78ae6c: sub             lr, x0, #0xf82
    //     0x78ae70: ldr             lr, [x21, lr, lsl #3]
    //     0x78ae74: blr             lr
    // 0x78ae78: add             SP, SP, #0x18
    // 0x78ae7c: ldr             x2, [fp, #0x18]
    // 0x78ae80: ldr             x1, [fp, #0x10]
    // 0x78ae84: LoadField: r3 = r2->field_63
    //     0x78ae84: ldur            w3, [x2, #0x63]
    // 0x78ae88: DecompressPointer r3
    //     0x78ae88: add             x3, x3, HEAP, lsl #32
    // 0x78ae8c: stur            x3, [fp, #-8]
    // 0x78ae90: r0 = LoadClassIdInstr(r1)
    //     0x78ae90: ldur            x0, [x1, #-1]
    //     0x78ae94: ubfx            x0, x0, #0xc, #0x14
    // 0x78ae98: SaveReg r1
    //     0x78ae98: str             x1, [SP, #-8]!
    // 0x78ae9c: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78ae9c: sub             lr, x0, #0xfff
    //     0x78aea0: ldr             lr, [x21, lr, lsl #3]
    //     0x78aea4: blr             lr
    // 0x78aea8: add             SP, SP, #8
    // 0x78aeac: mov             x2, x0
    // 0x78aeb0: ldr             x1, [fp, #0x10]
    // 0x78aeb4: stur            x2, [fp, #-0x18]
    // 0x78aeb8: r0 = LoadClassIdInstr(r1)
    //     0x78aeb8: ldur            x0, [x1, #-1]
    //     0x78aebc: ubfx            x0, x0, #0xc, #0x14
    // 0x78aec0: SaveReg r1
    //     0x78aec0: str             x1, [SP, #-8]!
    // 0x78aec4: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x78aec4: sub             lr, x0, #0xfd9
    //     0x78aec8: ldr             lr, [x21, lr, lsl #3]
    //     0x78aecc: blr             lr
    // 0x78aed0: add             SP, SP, #8
    // 0x78aed4: mov             x3, x0
    // 0x78aed8: ldur            x2, [fp, #-0x18]
    // 0x78aedc: r0 = BoxInt64Instr(r2)
    //     0x78aedc: sbfiz           x0, x2, #1, #0x1f
    //     0x78aee0: cmp             x2, x0, asr #1
    //     0x78aee4: b.eq            #0x78aef0
    //     0x78aee8: bl              #0xd69bb8
    //     0x78aeec: stur            x2, [x0, #7]
    // 0x78aef0: ldur            x16, [fp, #-8]
    // 0x78aef4: stp             x0, x16, [SP, #-0x10]!
    // 0x78aef8: SaveReg r3
    //     0x78aef8: str             x3, [SP, #-8]!
    // 0x78aefc: r0 = []=()
    //     0x78aefc: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x78af00: add             SP, SP, #0x18
    // 0x78af04: ldr             x1, [fp, #0x10]
    // 0x78af08: r0 = LoadClassIdInstr(r1)
    //     0x78af08: ldur            x0, [x1, #-1]
    //     0x78af0c: ubfx            x0, x0, #0xc, #0x14
    // 0x78af10: SaveReg r1
    //     0x78af10: str             x1, [SP, #-8]!
    // 0x78af14: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x78af14: mov             x17, #0x3f6e
    //     0x78af18: add             lr, x0, x17
    //     0x78af1c: ldr             lr, [x21, lr, lsl #3]
    //     0x78af20: blr             lr
    // 0x78af24: add             SP, SP, #8
    // 0x78af28: ldr             x3, [fp, #0x18]
    // 0x78af2c: StoreField: r3->field_33 = r0
    //     0x78af2c: stur            w0, [x3, #0x33]
    //     0x78af30: ldurb           w16, [x3, #-1]
    //     0x78af34: ldurb           w17, [x0, #-1]
    //     0x78af38: and             x16, x17, x16, lsr #2
    //     0x78af3c: tst             x16, HEAP, lsr #32
    //     0x78af40: b.eq            #0x78af48
    //     0x78af44: bl              #0xd682ac
    // 0x78af48: r1 = false
    //     0x78af48: add             x1, NULL, #0x30  ; false
    // 0x78af4c: r0 = true
    //     0x78af4c: add             x0, NULL, #0x20  ; true
    // 0x78af50: b               #0x78b760
    // 0x78af54: ldr             x3, [fp, #0x18]
    // 0x78af58: ldr             x0, [fp, #0x10]
    // 0x78af5c: r2 = Null
    //     0x78af5c: mov             x2, NULL
    // 0x78af60: r1 = Null
    //     0x78af60: mov             x1, NULL
    // 0x78af64: cmp             w0, NULL
    // 0x78af68: b.eq            #0x78af88
    // 0x78af6c: branchIfSmi(r0, 0x78af88)
    //     0x78af6c: tbz             w0, #0, #0x78af88
    // 0x78af70: r3 = LoadClassIdInstr(r0)
    //     0x78af70: ldur            x3, [x0, #-1]
    //     0x78af74: ubfx            x3, x3, #0xc, #0x14
    // 0x78af78: cmp             x3, #0x90a
    // 0x78af7c: b.eq            #0x78af90
    // 0x78af80: cmp             x3, #0xb41
    // 0x78af84: b.eq            #0x78af90
    // 0x78af88: r0 = false
    //     0x78af88: add             x0, NULL, #0x30  ; false
    // 0x78af8c: b               #0x78af94
    // 0x78af90: r0 = true
    //     0x78af90: add             x0, NULL, #0x20  ; true
    // 0x78af94: tbnz            w0, #4, #0x78b150
    // 0x78af98: ldr             x1, [fp, #0x18]
    // 0x78af9c: ldr             x2, [fp, #0x10]
    // 0x78afa0: LoadField: r3 = r1->field_63
    //     0x78afa0: ldur            w3, [x1, #0x63]
    // 0x78afa4: DecompressPointer r3
    //     0x78afa4: add             x3, x3, HEAP, lsl #32
    // 0x78afa8: stur            x3, [fp, #-8]
    // 0x78afac: r0 = LoadClassIdInstr(r2)
    //     0x78afac: ldur            x0, [x2, #-1]
    //     0x78afb0: ubfx            x0, x0, #0xc, #0x14
    // 0x78afb4: SaveReg r2
    //     0x78afb4: str             x2, [SP, #-8]!
    // 0x78afb8: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78afb8: sub             lr, x0, #0xfff
    //     0x78afbc: ldr             lr, [x21, lr, lsl #3]
    //     0x78afc0: blr             lr
    // 0x78afc4: add             SP, SP, #8
    // 0x78afc8: mov             x2, x0
    // 0x78afcc: ldr             x1, [fp, #0x10]
    // 0x78afd0: stur            x2, [fp, #-0x18]
    // 0x78afd4: r0 = LoadClassIdInstr(r1)
    //     0x78afd4: ldur            x0, [x1, #-1]
    //     0x78afd8: ubfx            x0, x0, #0xc, #0x14
    // 0x78afdc: SaveReg r1
    //     0x78afdc: str             x1, [SP, #-8]!
    // 0x78afe0: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x78afe0: sub             lr, x0, #0xfd9
    //     0x78afe4: ldr             lr, [x21, lr, lsl #3]
    //     0x78afe8: blr             lr
    // 0x78afec: add             SP, SP, #8
    // 0x78aff0: mov             x3, x0
    // 0x78aff4: ldur            x2, [fp, #-0x18]
    // 0x78aff8: r0 = BoxInt64Instr(r2)
    //     0x78aff8: sbfiz           x0, x2, #1, #0x1f
    //     0x78affc: cmp             x2, x0, asr #1
    //     0x78b000: b.eq            #0x78b00c
    //     0x78b004: bl              #0xd69bb8
    //     0x78b008: stur            x2, [x0, #7]
    // 0x78b00c: ldur            x16, [fp, #-8]
    // 0x78b010: stp             x0, x16, [SP, #-0x10]!
    // 0x78b014: SaveReg r3
    //     0x78b014: str             x3, [SP, #-8]!
    // 0x78b018: r0 = []=()
    //     0x78b018: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x78b01c: add             SP, SP, #0x18
    // 0x78b020: ldr             x1, [fp, #0x18]
    // 0x78b024: LoadField: r2 = r1->field_67
    //     0x78b024: ldur            w2, [x1, #0x67]
    // 0x78b028: DecompressPointer r2
    //     0x78b028: add             x2, x2, HEAP, lsl #32
    // 0x78b02c: ldr             x3, [fp, #0x10]
    // 0x78b030: stur            x2, [fp, #-8]
    // 0x78b034: r0 = LoadClassIdInstr(r3)
    //     0x78b034: ldur            x0, [x3, #-1]
    //     0x78b038: ubfx            x0, x0, #0xc, #0x14
    // 0x78b03c: SaveReg r3
    //     0x78b03c: str             x3, [SP, #-8]!
    // 0x78b040: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78b040: sub             lr, x0, #0xfff
    //     0x78b044: ldr             lr, [x21, lr, lsl #3]
    //     0x78b048: blr             lr
    // 0x78b04c: add             SP, SP, #8
    // 0x78b050: mov             x1, x0
    // 0x78b054: ldur            x0, [fp, #-8]
    // 0x78b058: stur            x1, [fp, #-0x18]
    // 0x78b05c: LoadField: r2 = r0->field_b
    //     0x78b05c: ldur            w2, [x0, #0xb]
    // 0x78b060: DecompressPointer r2
    //     0x78b060: add             x2, x2, HEAP, lsl #32
    // 0x78b064: stur            x2, [fp, #-0x10]
    // 0x78b068: LoadField: r3 = r0->field_f
    //     0x78b068: ldur            w3, [x0, #0xf]
    // 0x78b06c: DecompressPointer r3
    //     0x78b06c: add             x3, x3, HEAP, lsl #32
    // 0x78b070: LoadField: r4 = r3->field_b
    //     0x78b070: ldur            w4, [x3, #0xb]
    // 0x78b074: DecompressPointer r4
    //     0x78b074: add             x4, x4, HEAP, lsl #32
    // 0x78b078: cmp             w2, w4
    // 0x78b07c: b.ne            #0x78b08c
    // 0x78b080: SaveReg r0
    //     0x78b080: str             x0, [SP, #-8]!
    // 0x78b084: r0 = _growToNextCapacity()
    //     0x78b084: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x78b088: add             SP, SP, #8
    // 0x78b08c: ldr             x4, [fp, #0x18]
    // 0x78b090: ldr             x5, [fp, #0x10]
    // 0x78b094: ldur            x2, [fp, #-8]
    // 0x78b098: ldur            x3, [fp, #-0x18]
    // 0x78b09c: ldur            x0, [fp, #-0x10]
    // 0x78b0a0: r6 = LoadInt32Instr(r0)
    //     0x78b0a0: sbfx            x6, x0, #1, #0x1f
    // 0x78b0a4: add             x0, x6, #1
    // 0x78b0a8: lsl             x1, x0, #1
    // 0x78b0ac: StoreField: r2->field_b = r1
    //     0x78b0ac: stur            w1, [x2, #0xb]
    // 0x78b0b0: mov             x1, x6
    // 0x78b0b4: cmp             x1, x0
    // 0x78b0b8: b.hs            #0x78b82c
    // 0x78b0bc: LoadField: r7 = r2->field_f
    //     0x78b0bc: ldur            w7, [x2, #0xf]
    // 0x78b0c0: DecompressPointer r7
    //     0x78b0c0: add             x7, x7, HEAP, lsl #32
    // 0x78b0c4: r0 = BoxInt64Instr(r3)
    //     0x78b0c4: sbfiz           x0, x3, #1, #0x1f
    //     0x78b0c8: cmp             x3, x0, asr #1
    //     0x78b0cc: b.eq            #0x78b0d8
    //     0x78b0d0: bl              #0xd69bb8
    //     0x78b0d4: stur            x3, [x0, #7]
    // 0x78b0d8: mov             x1, x7
    // 0x78b0dc: ArrayStore: r1[r6] = r0  ; List_4
    //     0x78b0dc: add             x25, x1, x6, lsl #2
    //     0x78b0e0: add             x25, x25, #0xf
    //     0x78b0e4: str             w0, [x25]
    //     0x78b0e8: tbz             w0, #0, #0x78b104
    //     0x78b0ec: ldurb           w16, [x1, #-1]
    //     0x78b0f0: ldurb           w17, [x0, #-1]
    //     0x78b0f4: and             x16, x17, x16, lsr #2
    //     0x78b0f8: tst             x16, HEAP, lsr #32
    //     0x78b0fc: b.eq            #0x78b104
    //     0x78b100: bl              #0xd67e5c
    // 0x78b104: r0 = LoadClassIdInstr(r5)
    //     0x78b104: ldur            x0, [x5, #-1]
    //     0x78b108: ubfx            x0, x0, #0xc, #0x14
    // 0x78b10c: SaveReg r5
    //     0x78b10c: str             x5, [SP, #-8]!
    // 0x78b110: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x78b110: mov             x17, #0x3f6e
    //     0x78b114: add             lr, x0, x17
    //     0x78b118: ldr             lr, [x21, lr, lsl #3]
    //     0x78b11c: blr             lr
    // 0x78b120: add             SP, SP, #8
    // 0x78b124: ldr             x3, [fp, #0x18]
    // 0x78b128: StoreField: r3->field_33 = r0
    //     0x78b128: stur            w0, [x3, #0x33]
    //     0x78b12c: ldurb           w16, [x3, #-1]
    //     0x78b130: ldurb           w17, [x0, #-1]
    //     0x78b134: and             x16, x17, x16, lsr #2
    //     0x78b138: tst             x16, HEAP, lsr #32
    //     0x78b13c: b.eq            #0x78b144
    //     0x78b140: bl              #0xd682ac
    // 0x78b144: r1 = true
    //     0x78b144: add             x1, NULL, #0x20  ; true
    // 0x78b148: r0 = true
    //     0x78b148: add             x0, NULL, #0x20  ; true
    // 0x78b14c: b               #0x78b760
    // 0x78b150: ldr             x3, [fp, #0x18]
    // 0x78b154: ldr             x0, [fp, #0x10]
    // 0x78b158: r2 = Null
    //     0x78b158: mov             x2, NULL
    // 0x78b15c: r1 = Null
    //     0x78b15c: mov             x1, NULL
    // 0x78b160: cmp             w0, NULL
    // 0x78b164: b.eq            #0x78b184
    // 0x78b168: branchIfSmi(r0, 0x78b184)
    //     0x78b168: tbz             w0, #0, #0x78b184
    // 0x78b16c: r3 = LoadClassIdInstr(r0)
    //     0x78b16c: ldur            x3, [x0, #-1]
    //     0x78b170: ubfx            x3, x3, #0xc, #0x14
    // 0x78b174: cmp             x3, #0x906
    // 0x78b178: b.eq            #0x78b18c
    // 0x78b17c: cmp             x3, #0xb3d
    // 0x78b180: b.eq            #0x78b18c
    // 0x78b184: r0 = false
    //     0x78b184: add             x0, NULL, #0x30  ; false
    // 0x78b188: b               #0x78b190
    // 0x78b18c: r0 = true
    //     0x78b18c: add             x0, NULL, #0x20  ; true
    // 0x78b190: tbz             w0, #4, #0x78b1d4
    // 0x78b194: ldr             x0, [fp, #0x10]
    // 0x78b198: r2 = Null
    //     0x78b198: mov             x2, NULL
    // 0x78b19c: r1 = Null
    //     0x78b19c: mov             x1, NULL
    // 0x78b1a0: cmp             w0, NULL
    // 0x78b1a4: b.eq            #0x78b1c4
    // 0x78b1a8: branchIfSmi(r0, 0x78b1c4)
    //     0x78b1a8: tbz             w0, #0, #0x78b1c4
    // 0x78b1ac: r3 = LoadClassIdInstr(r0)
    //     0x78b1ac: ldur            x3, [x0, #-1]
    //     0x78b1b0: ubfx            x3, x3, #0xc, #0x14
    // 0x78b1b4: cmp             x3, #0x8f8
    // 0x78b1b8: b.eq            #0x78b1cc
    // 0x78b1bc: cmp             x3, #0xb35
    // 0x78b1c0: b.eq            #0x78b1cc
    // 0x78b1c4: r0 = false
    //     0x78b1c4: add             x0, NULL, #0x30  ; false
    // 0x78b1c8: b               #0x78b1d0
    // 0x78b1cc: r0 = true
    //     0x78b1cc: add             x0, NULL, #0x20  ; true
    // 0x78b1d0: tbnz            w0, #4, #0x78b2d4
    // 0x78b1d4: ldr             x1, [fp, #0x18]
    // 0x78b1d8: ldr             x2, [fp, #0x10]
    // 0x78b1dc: LoadField: r3 = r1->field_63
    //     0x78b1dc: ldur            w3, [x1, #0x63]
    // 0x78b1e0: DecompressPointer r3
    //     0x78b1e0: add             x3, x3, HEAP, lsl #32
    // 0x78b1e4: stur            x3, [fp, #-8]
    // 0x78b1e8: r0 = LoadClassIdInstr(r2)
    //     0x78b1e8: ldur            x0, [x2, #-1]
    //     0x78b1ec: ubfx            x0, x0, #0xc, #0x14
    // 0x78b1f0: SaveReg r2
    //     0x78b1f0: str             x2, [SP, #-8]!
    // 0x78b1f4: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78b1f4: sub             lr, x0, #0xfff
    //     0x78b1f8: ldr             lr, [x21, lr, lsl #3]
    //     0x78b1fc: blr             lr
    // 0x78b200: add             SP, SP, #8
    // 0x78b204: mov             x2, x0
    // 0x78b208: r0 = BoxInt64Instr(r2)
    //     0x78b208: sbfiz           x0, x2, #1, #0x1f
    //     0x78b20c: cmp             x2, x0, asr #1
    //     0x78b210: b.eq            #0x78b21c
    //     0x78b214: bl              #0xd69bb8
    //     0x78b218: stur            x2, [x0, #7]
    // 0x78b21c: ldur            x16, [fp, #-8]
    // 0x78b220: stp             x0, x16, [SP, #-0x10]!
    // 0x78b224: r0 = remove()
    //     0x78b224: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x78b228: add             SP, SP, #0x10
    // 0x78b22c: ldr             x1, [fp, #0x18]
    // 0x78b230: LoadField: r2 = r1->field_67
    //     0x78b230: ldur            w2, [x1, #0x67]
    // 0x78b234: DecompressPointer r2
    //     0x78b234: add             x2, x2, HEAP, lsl #32
    // 0x78b238: ldr             x3, [fp, #0x10]
    // 0x78b23c: stur            x2, [fp, #-8]
    // 0x78b240: r0 = LoadClassIdInstr(r3)
    //     0x78b240: ldur            x0, [x3, #-1]
    //     0x78b244: ubfx            x0, x0, #0xc, #0x14
    // 0x78b248: SaveReg r3
    //     0x78b248: str             x3, [SP, #-8]!
    // 0x78b24c: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78b24c: sub             lr, x0, #0xfff
    //     0x78b250: ldr             lr, [x21, lr, lsl #3]
    //     0x78b254: blr             lr
    // 0x78b258: add             SP, SP, #8
    // 0x78b25c: mov             x2, x0
    // 0x78b260: r0 = BoxInt64Instr(r2)
    //     0x78b260: sbfiz           x0, x2, #1, #0x1f
    //     0x78b264: cmp             x2, x0, asr #1
    //     0x78b268: b.eq            #0x78b274
    //     0x78b26c: bl              #0xd69bb8
    //     0x78b270: stur            x2, [x0, #7]
    // 0x78b274: ldur            x16, [fp, #-8]
    // 0x78b278: stp             x0, x16, [SP, #-0x10]!
    // 0x78b27c: r0 = remove()
    //     0x78b27c: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0x78b280: add             SP, SP, #0x10
    // 0x78b284: ldr             x1, [fp, #0x10]
    // 0x78b288: r0 = LoadClassIdInstr(r1)
    //     0x78b288: ldur            x0, [x1, #-1]
    //     0x78b28c: ubfx            x0, x0, #0xc, #0x14
    // 0x78b290: SaveReg r1
    //     0x78b290: str             x1, [SP, #-8]!
    // 0x78b294: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x78b294: mov             x17, #0x3f6e
    //     0x78b298: add             lr, x0, x17
    //     0x78b29c: ldr             lr, [x21, lr, lsl #3]
    //     0x78b2a0: blr             lr
    // 0x78b2a4: add             SP, SP, #8
    // 0x78b2a8: ldr             x3, [fp, #0x18]
    // 0x78b2ac: StoreField: r3->field_33 = r0
    //     0x78b2ac: stur            w0, [x3, #0x33]
    //     0x78b2b0: ldurb           w16, [x3, #-1]
    //     0x78b2b4: ldurb           w17, [x0, #-1]
    //     0x78b2b8: and             x16, x17, x16, lsr #2
    //     0x78b2bc: tst             x16, HEAP, lsr #32
    //     0x78b2c0: b.eq            #0x78b2c8
    //     0x78b2c4: bl              #0xd682ac
    // 0x78b2c8: r1 = true
    //     0x78b2c8: add             x1, NULL, #0x20  ; true
    // 0x78b2cc: r0 = false
    //     0x78b2cc: add             x0, NULL, #0x30  ; false
    // 0x78b2d0: b               #0x78b760
    // 0x78b2d4: ldr             x3, [fp, #0x18]
    // 0x78b2d8: ldr             x0, [fp, #0x10]
    // 0x78b2dc: r2 = Null
    //     0x78b2dc: mov             x2, NULL
    // 0x78b2e0: r1 = Null
    //     0x78b2e0: mov             x1, NULL
    // 0x78b2e4: cmp             w0, NULL
    // 0x78b2e8: b.eq            #0x78b308
    // 0x78b2ec: branchIfSmi(r0, 0x78b308)
    //     0x78b2ec: tbz             w0, #0, #0x78b308
    // 0x78b2f0: r3 = LoadClassIdInstr(r0)
    //     0x78b2f0: ldur            x3, [x0, #-1]
    //     0x78b2f4: ubfx            x3, x3, #0xc, #0x14
    // 0x78b2f8: cmp             x3, #0x8fe
    // 0x78b2fc: b.eq            #0x78b310
    // 0x78b300: cmp             x3, #0xb3b
    // 0x78b304: b.eq            #0x78b310
    // 0x78b308: r0 = false
    //     0x78b308: add             x0, NULL, #0x30  ; false
    // 0x78b30c: b               #0x78b314
    // 0x78b310: r0 = true
    //     0x78b310: add             x0, NULL, #0x20  ; true
    // 0x78b314: tbnz            w0, #4, #0x78b3cc
    // 0x78b318: ldr             x1, [fp, #0x18]
    // 0x78b31c: ldr             x2, [fp, #0x10]
    // 0x78b320: LoadField: r3 = r1->field_73
    //     0x78b320: ldur            w3, [x1, #0x73]
    // 0x78b324: DecompressPointer r3
    //     0x78b324: add             x3, x3, HEAP, lsl #32
    // 0x78b328: stur            x3, [fp, #-8]
    // 0x78b32c: r0 = LoadClassIdInstr(r2)
    //     0x78b32c: ldur            x0, [x2, #-1]
    //     0x78b330: ubfx            x0, x0, #0xc, #0x14
    // 0x78b334: SaveReg r2
    //     0x78b334: str             x2, [SP, #-8]!
    // 0x78b338: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78b338: sub             lr, x0, #0xfff
    //     0x78b33c: ldr             lr, [x21, lr, lsl #3]
    //     0x78b340: blr             lr
    // 0x78b344: add             SP, SP, #8
    // 0x78b348: mov             x2, x0
    // 0x78b34c: ldr             x1, [fp, #0x10]
    // 0x78b350: stur            x2, [fp, #-0x18]
    // 0x78b354: r0 = LoadClassIdInstr(r1)
    //     0x78b354: ldur            x0, [x1, #-1]
    //     0x78b358: ubfx            x0, x0, #0xc, #0x14
    // 0x78b35c: SaveReg r1
    //     0x78b35c: str             x1, [SP, #-8]!
    // 0x78b360: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x78b360: sub             lr, x0, #0xfd9
    //     0x78b364: ldr             lr, [x21, lr, lsl #3]
    //     0x78b368: blr             lr
    // 0x78b36c: add             SP, SP, #8
    // 0x78b370: stur            x0, [fp, #-0x10]
    // 0x78b374: r0 = _PointerPanZoomData()
    //     0x78b374: bl              #0x78dd08  ; Allocate_PointerPanZoomDataStub -> _PointerPanZoomData (size=0x1c)
    // 0x78b378: mov             x2, x0
    // 0x78b37c: ldur            x0, [fp, #-0x10]
    // 0x78b380: StoreField: r2->field_7 = r0
    //     0x78b380: stur            w0, [x2, #7]
    // 0x78b384: d0 = 1.000000
    //     0x78b384: fmov            d0, #1.00000000
    // 0x78b388: StoreField: r2->field_b = d0
    //     0x78b388: stur            d0, [x2, #0xb]
    // 0x78b38c: d0 = 0.000000
    //     0x78b38c: eor             v0.16b, v0.16b, v0.16b
    // 0x78b390: StoreField: r2->field_13 = d0
    //     0x78b390: stur            d0, [x2, #0x13]
    // 0x78b394: ldur            x3, [fp, #-0x18]
    // 0x78b398: r0 = BoxInt64Instr(r3)
    //     0x78b398: sbfiz           x0, x3, #1, #0x1f
    //     0x78b39c: cmp             x3, x0, asr #1
    //     0x78b3a0: b.eq            #0x78b3ac
    //     0x78b3a4: bl              #0xd69bb8
    //     0x78b3a8: stur            x3, [x0, #7]
    // 0x78b3ac: ldur            x16, [fp, #-8]
    // 0x78b3b0: stp             x0, x16, [SP, #-0x10]!
    // 0x78b3b4: SaveReg r2
    //     0x78b3b4: str             x2, [SP, #-8]!
    // 0x78b3b8: r0 = []=()
    //     0x78b3b8: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x78b3bc: add             SP, SP, #0x18
    // 0x78b3c0: r1 = true
    //     0x78b3c0: add             x1, NULL, #0x20  ; true
    // 0x78b3c4: r0 = true
    //     0x78b3c4: add             x0, NULL, #0x20  ; true
    // 0x78b3c8: b               #0x78b760
    // 0x78b3cc: ldr             x0, [fp, #0x10]
    // 0x78b3d0: r2 = Null
    //     0x78b3d0: mov             x2, NULL
    // 0x78b3d4: r1 = Null
    //     0x78b3d4: mov             x1, NULL
    // 0x78b3d8: cmp             w0, NULL
    // 0x78b3dc: b.eq            #0x78b3fc
    // 0x78b3e0: branchIfSmi(r0, 0x78b3fc)
    //     0x78b3e0: tbz             w0, #0, #0x78b3fc
    // 0x78b3e4: r3 = LoadClassIdInstr(r0)
    //     0x78b3e4: ldur            x3, [x0, #-1]
    //     0x78b3e8: ubfx            x3, x3, #0xc, #0x14
    // 0x78b3ec: cmp             x3, #0x8fc
    // 0x78b3f0: b.eq            #0x78b404
    // 0x78b3f4: cmp             x3, #0xb39
    // 0x78b3f8: b.eq            #0x78b404
    // 0x78b3fc: r0 = false
    //     0x78b3fc: add             x0, NULL, #0x30  ; false
    // 0x78b400: b               #0x78b408
    // 0x78b404: r0 = true
    //     0x78b404: add             x0, NULL, #0x20  ; true
    // 0x78b408: tbnz            w0, #4, #0x78b6b0
    // 0x78b40c: ldr             x1, [fp, #0x10]
    // 0x78b410: r0 = LoadClassIdInstr(r1)
    //     0x78b410: ldur            x0, [x1, #-1]
    //     0x78b414: ubfx            x0, x0, #0xc, #0x14
    // 0x78b418: SaveReg r1
    //     0x78b418: str             x1, [SP, #-8]!
    // 0x78b41c: r0 = GDT[cid_x0 + 0x7012]()
    //     0x78b41c: mov             x17, #0x7012
    //     0x78b420: add             lr, x0, x17
    //     0x78b424: ldr             lr, [x21, lr, lsl #3]
    //     0x78b428: blr             lr
    // 0x78b42c: add             SP, SP, #8
    // 0x78b430: tbz             w0, #4, #0x78b534
    // 0x78b434: ldr             x2, [fp, #0x18]
    // 0x78b438: ldr             x1, [fp, #0x10]
    // 0x78b43c: LoadField: r3 = r2->field_6b
    //     0x78b43c: ldur            w3, [x2, #0x6b]
    // 0x78b440: DecompressPointer r3
    //     0x78b440: add             x3, x3, HEAP, lsl #32
    // 0x78b444: stur            x3, [fp, #-8]
    // 0x78b448: r0 = LoadClassIdInstr(r1)
    //     0x78b448: ldur            x0, [x1, #-1]
    //     0x78b44c: ubfx            x0, x0, #0xc, #0x14
    // 0x78b450: SaveReg r1
    //     0x78b450: str             x1, [SP, #-8]!
    // 0x78b454: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78b454: sub             lr, x0, #0xfff
    //     0x78b458: ldr             lr, [x21, lr, lsl #3]
    //     0x78b45c: blr             lr
    // 0x78b460: add             SP, SP, #8
    // 0x78b464: mov             x2, x0
    // 0x78b468: r0 = BoxInt64Instr(r2)
    //     0x78b468: sbfiz           x0, x2, #1, #0x1f
    //     0x78b46c: cmp             x2, x0, asr #1
    //     0x78b470: b.eq            #0x78b47c
    //     0x78b474: bl              #0xd69bb8
    //     0x78b478: stur            x2, [x0, #7]
    // 0x78b47c: ldur            x16, [fp, #-8]
    // 0x78b480: stp             x0, x16, [SP, #-0x10]!
    // 0x78b484: r0 = _getValueOrData()
    //     0x78b484: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78b488: add             SP, SP, #0x10
    // 0x78b48c: mov             x1, x0
    // 0x78b490: ldur            x0, [fp, #-8]
    // 0x78b494: LoadField: r2 = r0->field_f
    //     0x78b494: ldur            w2, [x0, #0xf]
    // 0x78b498: DecompressPointer r2
    //     0x78b498: add             x2, x2, HEAP, lsl #32
    // 0x78b49c: cmp             w2, w1
    // 0x78b4a0: b.ne            #0x78b4ac
    // 0x78b4a4: r2 = Null
    //     0x78b4a4: mov             x2, NULL
    // 0x78b4a8: b               #0x78b4b0
    // 0x78b4ac: mov             x2, x1
    // 0x78b4b0: ldr             x1, [fp, #0x10]
    // 0x78b4b4: stur            x2, [fp, #-8]
    // 0x78b4b8: cmp             w2, NULL
    // 0x78b4bc: b.eq            #0x78b830
    // 0x78b4c0: r0 = LoadClassIdInstr(r1)
    //     0x78b4c0: ldur            x0, [x1, #-1]
    //     0x78b4c4: ubfx            x0, x0, #0xc, #0x14
    // 0x78b4c8: SaveReg r1
    //     0x78b4c8: str             x1, [SP, #-8]!
    // 0x78b4cc: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x78b4cc: sub             lr, x0, #0xf3a
    //     0x78b4d0: ldr             lr, [x21, lr, lsl #3]
    //     0x78b4d4: blr             lr
    // 0x78b4d8: add             SP, SP, #8
    // 0x78b4dc: mov             x2, x0
    // 0x78b4e0: ldr             x1, [fp, #0x10]
    // 0x78b4e4: stur            x2, [fp, #-0x10]
    // 0x78b4e8: r0 = LoadClassIdInstr(r1)
    //     0x78b4e8: ldur            x0, [x1, #-1]
    //     0x78b4ec: ubfx            x0, x0, #0xc, #0x14
    // 0x78b4f0: SaveReg r1
    //     0x78b4f0: str             x1, [SP, #-8]!
    // 0x78b4f4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x78b4f4: sub             lr, x0, #1, lsl #12
    //     0x78b4f8: ldr             lr, [x21, lr, lsl #3]
    //     0x78b4fc: blr             lr
    // 0x78b500: add             SP, SP, #8
    // 0x78b504: mov             x1, x0
    // 0x78b508: ldur            x0, [fp, #-8]
    // 0x78b50c: r2 = LoadClassIdInstr(r0)
    //     0x78b50c: ldur            x2, [x0, #-1]
    //     0x78b510: ubfx            x2, x2, #0xc, #0x14
    // 0x78b514: ldur            x16, [fp, #-0x10]
    // 0x78b518: stp             x16, x0, [SP, #-0x10]!
    // 0x78b51c: SaveReg r1
    //     0x78b51c: str             x1, [SP, #-8]!
    // 0x78b520: mov             x0, x2
    // 0x78b524: r0 = GDT[cid_x0 + -0xf82]()
    //     0x78b524: sub             lr, x0, #0xf82
    //     0x78b528: ldr             lr, [x21, lr, lsl #3]
    //     0x78b52c: blr             lr
    // 0x78b530: add             SP, SP, #0x18
    // 0x78b534: ldr             x2, [fp, #0x18]
    // 0x78b538: ldr             x1, [fp, #0x10]
    // 0x78b53c: LoadField: r3 = r2->field_73
    //     0x78b53c: ldur            w3, [x2, #0x73]
    // 0x78b540: DecompressPointer r3
    //     0x78b540: add             x3, x3, HEAP, lsl #32
    // 0x78b544: stur            x3, [fp, #-8]
    // 0x78b548: r0 = LoadClassIdInstr(r1)
    //     0x78b548: ldur            x0, [x1, #-1]
    //     0x78b54c: ubfx            x0, x0, #0xc, #0x14
    // 0x78b550: SaveReg r1
    //     0x78b550: str             x1, [SP, #-8]!
    // 0x78b554: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78b554: sub             lr, x0, #0xfff
    //     0x78b558: ldr             lr, [x21, lr, lsl #3]
    //     0x78b55c: blr             lr
    // 0x78b560: add             SP, SP, #8
    // 0x78b564: mov             x2, x0
    // 0x78b568: ldr             x1, [fp, #0x10]
    // 0x78b56c: stur            x2, [fp, #-0x18]
    // 0x78b570: r0 = LoadClassIdInstr(r1)
    //     0x78b570: ldur            x0, [x1, #-1]
    //     0x78b574: ubfx            x0, x0, #0xc, #0x14
    // 0x78b578: SaveReg r1
    //     0x78b578: str             x1, [SP, #-8]!
    // 0x78b57c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x78b57c: sub             lr, x0, #0xfd9
    //     0x78b580: ldr             lr, [x21, lr, lsl #3]
    //     0x78b584: blr             lr
    // 0x78b588: add             SP, SP, #8
    // 0x78b58c: mov             x2, x0
    // 0x78b590: ldr             x1, [fp, #0x10]
    // 0x78b594: stur            x2, [fp, #-0x10]
    // 0x78b598: r0 = LoadClassIdInstr(r1)
    //     0x78b598: ldur            x0, [x1, #-1]
    //     0x78b59c: ubfx            x0, x0, #0xc, #0x14
    // 0x78b5a0: SaveReg r1
    //     0x78b5a0: str             x1, [SP, #-8]!
    // 0x78b5a4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x78b5a4: sub             lr, x0, #1, lsl #12
    //     0x78b5a8: ldr             lr, [x21, lr, lsl #3]
    //     0x78b5ac: blr             lr
    // 0x78b5b0: add             SP, SP, #8
    // 0x78b5b4: ldur            x16, [fp, #-0x10]
    // 0x78b5b8: stp             x0, x16, [SP, #-0x10]!
    // 0x78b5bc: r0 = +()
    //     0x78b5bc: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x78b5c0: add             SP, SP, #0x10
    // 0x78b5c4: mov             x2, x0
    // 0x78b5c8: ldr             x1, [fp, #0x10]
    // 0x78b5cc: stur            x2, [fp, #-0x10]
    // 0x78b5d0: r0 = LoadClassIdInstr(r1)
    //     0x78b5d0: ldur            x0, [x1, #-1]
    //     0x78b5d4: ubfx            x0, x0, #0xc, #0x14
    // 0x78b5d8: SaveReg r1
    //     0x78b5d8: str             x1, [SP, #-8]!
    // 0x78b5dc: r0 = GDT[cid_x0 + -0xff6]()
    //     0x78b5dc: sub             lr, x0, #0xff6
    //     0x78b5e0: ldr             lr, [x21, lr, lsl #3]
    //     0x78b5e4: blr             lr
    // 0x78b5e8: add             SP, SP, #8
    // 0x78b5ec: ldr             x1, [fp, #0x10]
    // 0x78b5f0: stur            d0, [fp, #-0x20]
    // 0x78b5f4: r0 = LoadClassIdInstr(r1)
    //     0x78b5f4: ldur            x0, [x1, #-1]
    //     0x78b5f8: ubfx            x0, x0, #0xc, #0x14
    // 0x78b5fc: SaveReg r1
    //     0x78b5fc: str             x1, [SP, #-8]!
    // 0x78b600: r0 = GDT[cid_x0 + -0xff4]()
    //     0x78b600: sub             lr, x0, #0xff4
    //     0x78b604: ldr             lr, [x21, lr, lsl #3]
    //     0x78b608: blr             lr
    // 0x78b60c: add             SP, SP, #8
    // 0x78b610: stur            d0, [fp, #-0x28]
    // 0x78b614: r0 = _PointerPanZoomData()
    //     0x78b614: bl              #0x78dd08  ; Allocate_PointerPanZoomDataStub -> _PointerPanZoomData (size=0x1c)
    // 0x78b618: mov             x2, x0
    // 0x78b61c: ldur            x0, [fp, #-0x10]
    // 0x78b620: StoreField: r2->field_7 = r0
    //     0x78b620: stur            w0, [x2, #7]
    // 0x78b624: ldur            d0, [fp, #-0x20]
    // 0x78b628: StoreField: r2->field_b = d0
    //     0x78b628: stur            d0, [x2, #0xb]
    // 0x78b62c: ldur            d0, [fp, #-0x28]
    // 0x78b630: StoreField: r2->field_13 = d0
    //     0x78b630: stur            d0, [x2, #0x13]
    // 0x78b634: ldur            x3, [fp, #-0x18]
    // 0x78b638: r0 = BoxInt64Instr(r3)
    //     0x78b638: sbfiz           x0, x3, #1, #0x1f
    //     0x78b63c: cmp             x3, x0, asr #1
    //     0x78b640: b.eq            #0x78b64c
    //     0x78b644: bl              #0xd69bb8
    //     0x78b648: stur            x3, [x0, #7]
    // 0x78b64c: ldur            x16, [fp, #-8]
    // 0x78b650: stp             x0, x16, [SP, #-0x10]!
    // 0x78b654: SaveReg r2
    //     0x78b654: str             x2, [SP, #-8]!
    // 0x78b658: r0 = []=()
    //     0x78b658: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x78b65c: add             SP, SP, #0x18
    // 0x78b660: ldr             x1, [fp, #0x10]
    // 0x78b664: r0 = LoadClassIdInstr(r1)
    //     0x78b664: ldur            x0, [x1, #-1]
    //     0x78b668: ubfx            x0, x0, #0xc, #0x14
    // 0x78b66c: SaveReg r1
    //     0x78b66c: str             x1, [SP, #-8]!
    // 0x78b670: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x78b670: mov             x17, #0x3f6e
    //     0x78b674: add             lr, x0, x17
    //     0x78b678: ldr             lr, [x21, lr, lsl #3]
    //     0x78b67c: blr             lr
    // 0x78b680: add             SP, SP, #8
    // 0x78b684: ldr             x3, [fp, #0x18]
    // 0x78b688: StoreField: r3->field_33 = r0
    //     0x78b688: stur            w0, [x3, #0x33]
    //     0x78b68c: ldurb           w16, [x3, #-1]
    //     0x78b690: ldurb           w17, [x0, #-1]
    //     0x78b694: and             x16, x17, x16, lsr #2
    //     0x78b698: tst             x16, HEAP, lsr #32
    //     0x78b69c: b.eq            #0x78b6a4
    //     0x78b6a0: bl              #0xd682ac
    // 0x78b6a4: r1 = false
    //     0x78b6a4: add             x1, NULL, #0x30  ; false
    // 0x78b6a8: r0 = true
    //     0x78b6a8: add             x0, NULL, #0x20  ; true
    // 0x78b6ac: b               #0x78b760
    // 0x78b6b0: ldr             x3, [fp, #0x18]
    // 0x78b6b4: ldr             x0, [fp, #0x10]
    // 0x78b6b8: r2 = Null
    //     0x78b6b8: mov             x2, NULL
    // 0x78b6bc: r1 = Null
    //     0x78b6bc: mov             x1, NULL
    // 0x78b6c0: cmp             w0, NULL
    // 0x78b6c4: b.eq            #0x78b6e4
    // 0x78b6c8: branchIfSmi(r0, 0x78b6e4)
    //     0x78b6c8: tbz             w0, #0, #0x78b6e4
    // 0x78b6cc: r3 = LoadClassIdInstr(r0)
    //     0x78b6cc: ldur            x3, [x0, #-1]
    //     0x78b6d0: ubfx            x3, x3, #0xc, #0x14
    // 0x78b6d4: cmp             x3, #0x8fa
    // 0x78b6d8: b.eq            #0x78b6ec
    // 0x78b6dc: cmp             x3, #0xb37
    // 0x78b6e0: b.eq            #0x78b6ec
    // 0x78b6e4: r0 = false
    //     0x78b6e4: add             x0, NULL, #0x30  ; false
    // 0x78b6e8: b               #0x78b6f0
    // 0x78b6ec: r0 = true
    //     0x78b6ec: add             x0, NULL, #0x20  ; true
    // 0x78b6f0: tbnz            w0, #4, #0x78b754
    // 0x78b6f4: ldr             x1, [fp, #0x18]
    // 0x78b6f8: ldr             x2, [fp, #0x10]
    // 0x78b6fc: LoadField: r3 = r1->field_73
    //     0x78b6fc: ldur            w3, [x1, #0x73]
    // 0x78b700: DecompressPointer r3
    //     0x78b700: add             x3, x3, HEAP, lsl #32
    // 0x78b704: stur            x3, [fp, #-8]
    // 0x78b708: r0 = LoadClassIdInstr(r2)
    //     0x78b708: ldur            x0, [x2, #-1]
    //     0x78b70c: ubfx            x0, x0, #0xc, #0x14
    // 0x78b710: SaveReg r2
    //     0x78b710: str             x2, [SP, #-8]!
    // 0x78b714: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78b714: sub             lr, x0, #0xfff
    //     0x78b718: ldr             lr, [x21, lr, lsl #3]
    //     0x78b71c: blr             lr
    // 0x78b720: add             SP, SP, #8
    // 0x78b724: mov             x2, x0
    // 0x78b728: r0 = BoxInt64Instr(r2)
    //     0x78b728: sbfiz           x0, x2, #1, #0x1f
    //     0x78b72c: cmp             x2, x0, asr #1
    //     0x78b730: b.eq            #0x78b73c
    //     0x78b734: bl              #0xd69bb8
    //     0x78b738: stur            x2, [x0, #7]
    // 0x78b73c: ldur            x16, [fp, #-8]
    // 0x78b740: stp             x0, x16, [SP, #-0x10]!
    // 0x78b744: r0 = remove()
    //     0x78b744: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x78b748: add             SP, SP, #0x10
    // 0x78b74c: r0 = true
    //     0x78b74c: add             x0, NULL, #0x20  ; true
    // 0x78b750: b               #0x78b758
    // 0x78b754: r0 = false
    //     0x78b754: add             x0, NULL, #0x30  ; false
    // 0x78b758: mov             x1, x0
    // 0x78b75c: r0 = false
    //     0x78b75c: add             x0, NULL, #0x30  ; false
    // 0x78b760: stur            x1, [fp, #-8]
    // 0x78b764: stur            x0, [fp, #-0x10]
    // 0x78b768: ldr             x16, [fp, #0x18]
    // 0x78b76c: SaveReg r16
    //     0x78b76c: str             x16, [SP, #-8]!
    // 0x78b770: r0 = _updateLines()
    //     0x78b770: bl              #0x78d8d4  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_updateLines
    // 0x78b774: add             SP, SP, #8
    // 0x78b778: ldr             x16, [fp, #0x18]
    // 0x78b77c: SaveReg r16
    //     0x78b77c: str             x16, [SP, #-8]!
    // 0x78b780: r0 = _update()
    //     0x78b780: bl              #0x78cf4c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_update
    // 0x78b784: add             SP, SP, #8
    // 0x78b788: ldur            x0, [fp, #-8]
    // 0x78b78c: tbnz            w0, #4, #0x78b7c4
    // 0x78b790: ldr             x1, [fp, #0x10]
    // 0x78b794: r0 = LoadClassIdInstr(r1)
    //     0x78b794: ldur            x0, [x1, #-1]
    //     0x78b798: ubfx            x0, x0, #0xc, #0x14
    // 0x78b79c: SaveReg r1
    //     0x78b79c: str             x1, [SP, #-8]!
    // 0x78b7a0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78b7a0: sub             lr, x0, #0xfff
    //     0x78b7a4: ldr             lr, [x21, lr, lsl #3]
    //     0x78b7a8: blr             lr
    // 0x78b7ac: add             SP, SP, #8
    // 0x78b7b0: ldr             x16, [fp, #0x18]
    // 0x78b7b4: stp             x0, x16, [SP, #-0x10]!
    // 0x78b7b8: r0 = _reconfigure()
    //     0x78b7b8: bl              #0x78c648  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure
    // 0x78b7bc: add             SP, SP, #0x10
    // 0x78b7c0: tbnz            w0, #4, #0x78b7fc
    // 0x78b7c4: ldr             x1, [fp, #0x10]
    // 0x78b7c8: r0 = LoadClassIdInstr(r1)
    //     0x78b7c8: ldur            x0, [x1, #-1]
    //     0x78b7cc: ubfx            x0, x0, #0xc, #0x14
    // 0x78b7d0: SaveReg r1
    //     0x78b7d0: str             x1, [SP, #-8]!
    // 0x78b7d4: r0 = GDT[cid_x0 + -0xf60]()
    //     0x78b7d4: sub             lr, x0, #0xf60
    //     0x78b7d8: ldr             lr, [x21, lr, lsl #3]
    //     0x78b7dc: blr             lr
    // 0x78b7e0: add             SP, SP, #8
    // 0x78b7e4: ldr             x16, [fp, #0x18]
    // 0x78b7e8: ldur            lr, [fp, #-0x10]
    // 0x78b7ec: stp             lr, x16, [SP, #-0x10]!
    // 0x78b7f0: SaveReg r0
    //     0x78b7f0: str             x0, [SP, #-8]!
    // 0x78b7f4: r0 = _advanceStateMachine()
    //     0x78b7f4: bl              #0x78b834  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_advanceStateMachine
    // 0x78b7f8: add             SP, SP, #0x18
    // 0x78b7fc: ldr             x16, [fp, #0x18]
    // 0x78b800: ldr             lr, [fp, #0x10]
    // 0x78b804: stp             lr, x16, [SP, #-0x10]!
    // 0x78b808: r0 = stopTrackingIfPointerNoLongerDown()
    //     0x78b808: bl              #0x7891a8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0x78b80c: add             SP, SP, #0x10
    // 0x78b810: r0 = Null
    //     0x78b810: mov             x0, NULL
    // 0x78b814: LeaveFrame
    //     0x78b814: mov             SP, fp
    //     0x78b818: ldp             fp, lr, [SP], #0x10
    // 0x78b81c: ret
    //     0x78b81c: ret             
    // 0x78b820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78b820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78b824: b               #0x78ad10
    // 0x78b828: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78b828: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78b82c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x78b82c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x78b830: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78b830: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _advanceStateMachine(/* No info */) {
    // ** addr: 0x78b834, size: 0x3b8
    // 0x78b834: EnterFrame
    //     0x78b834: stp             fp, lr, [SP, #-0x10]!
    //     0x78b838: mov             fp, SP
    // 0x78b83c: AllocStack(0x18)
    //     0x78b83c: sub             SP, SP, #0x18
    // 0x78b840: CheckStackOverflow
    //     0x78b840: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78b844: cmp             SP, x16
    //     0x78b848: b.ls            #0x78bbb8
    // 0x78b84c: r1 = 1
    //     0x78b84c: mov             x1, #1
    // 0x78b850: r0 = AllocateContext()
    //     0x78b850: bl              #0xd68aa4  ; AllocateContextStub
    // 0x78b854: mov             x1, x0
    // 0x78b858: ldr             x0, [fp, #0x20]
    // 0x78b85c: stur            x1, [fp, #-8]
    // 0x78b860: StoreField: r1->field_f = r0
    //     0x78b860: stur            w0, [x1, #0xf]
    // 0x78b864: LoadField: r2 = r0->field_2f
    //     0x78b864: ldur            w2, [x0, #0x2f]
    // 0x78b868: DecompressPointer r2
    //     0x78b868: add             x2, x2, HEAP, lsl #32
    // 0x78b86c: r16 = Instance__ScaleState
    //     0x78b86c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21488] Obj!_ScaleState@b65a11
    //     0x78b870: ldr             x16, [x16, #0x488]
    // 0x78b874: cmp             w2, w16
    // 0x78b878: b.ne            #0x78b890
    // 0x78b87c: r2 = Instance__ScaleState
    //     0x78b87c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28e18] Obj!_ScaleState@b65a31
    //     0x78b880: ldr             x2, [x2, #0xe18]
    // 0x78b884: StoreField: r0->field_2f = r2
    //     0x78b884: stur            w2, [x0, #0x2f]
    // 0x78b888: r2 = Instance__ScaleState
    //     0x78b888: add             x2, PP, #0x28, lsl #12  ; [pp+0x28e18] Obj!_ScaleState@b65a31
    //     0x78b88c: ldr             x2, [x2, #0xe18]
    // 0x78b890: r16 = Instance__ScaleState
    //     0x78b890: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e18] Obj!_ScaleState@b65a31
    //     0x78b894: ldr             x16, [x16, #0xe18]
    // 0x78b898: cmp             w2, w16
    // 0x78b89c: b.ne            #0x78baf0
    // 0x78b8a0: d0 = 0.000000
    //     0x78b8a0: eor             v0.16b, v0.16b, v0.16b
    // 0x78b8a4: LoadField: r2 = r0->field_43
    //     0x78b8a4: ldur            w2, [x0, #0x43]
    // 0x78b8a8: DecompressPointer r2
    //     0x78b8a8: add             x2, x2, HEAP, lsl #32
    // 0x78b8ac: r16 = Sentinel
    //     0x78b8ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78b8b0: cmp             w2, w16
    // 0x78b8b4: b.eq            #0x78bbc0
    // 0x78b8b8: LoadField: r3 = r0->field_3f
    //     0x78b8b8: ldur            w3, [x0, #0x3f]
    // 0x78b8bc: DecompressPointer r3
    //     0x78b8bc: add             x3, x3, HEAP, lsl #32
    // 0x78b8c0: r16 = Sentinel
    //     0x78b8c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78b8c4: cmp             w3, w16
    // 0x78b8c8: b.eq            #0x78bbcc
    // 0x78b8cc: LoadField: d1 = r2->field_7
    //     0x78b8cc: ldur            d1, [x2, #7]
    // 0x78b8d0: LoadField: d2 = r3->field_7
    //     0x78b8d0: ldur            d2, [x3, #7]
    // 0x78b8d4: fsub            d3, d1, d2
    // 0x78b8d8: fcmp            d3, d0
    // 0x78b8dc: b.vs            #0x78b8ec
    // 0x78b8e0: b.ne            #0x78b8ec
    // 0x78b8e4: d1 = 0.000000
    //     0x78b8e4: eor             v1.16b, v1.16b, v1.16b
    // 0x78b8e8: b               #0x78b904
    // 0x78b8ec: fcmp            d3, d0
    // 0x78b8f0: b.vs            #0x78b900
    // 0x78b8f4: b.ge            #0x78b900
    // 0x78b8f8: fneg            d1, d3
    // 0x78b8fc: b               #0x78b904
    // 0x78b900: mov             v1.16b, v3.16b
    // 0x78b904: ldr             x2, [fp, #0x10]
    // 0x78b908: stur            d1, [fp, #-0x10]
    // 0x78b90c: LoadField: r3 = r0->field_3b
    //     0x78b90c: ldur            w3, [x0, #0x3b]
    // 0x78b910: DecompressPointer r3
    //     0x78b910: add             x3, x3, HEAP, lsl #32
    // 0x78b914: cmp             w3, NULL
    // 0x78b918: b.eq            #0x78bbd8
    // 0x78b91c: LoadField: r4 = r0->field_37
    //     0x78b91c: ldur            w4, [x0, #0x37]
    // 0x78b920: DecompressPointer r4
    //     0x78b920: add             x4, x4, HEAP, lsl #32
    // 0x78b924: r16 = Sentinel
    //     0x78b924: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78b928: cmp             w4, w16
    // 0x78b92c: b.eq            #0x78bbdc
    // 0x78b930: stp             x4, x3, [SP, #-0x10]!
    // 0x78b934: r0 = -()
    //     0x78b934: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x78b938: add             SP, SP, #0x10
    // 0x78b93c: LoadField: d0 = r0->field_7
    //     0x78b93c: ldur            d0, [x0, #7]
    // 0x78b940: fmul            d1, d0, d0
    // 0x78b944: LoadField: d0 = r0->field_f
    //     0x78b944: ldur            d0, [x0, #0xf]
    // 0x78b948: fmul            d2, d0, d0
    // 0x78b94c: fadd            d0, d1, d2
    // 0x78b950: fsqrt           d1, d0
    // 0x78b954: ldr             x0, [fp, #0x10]
    // 0x78b958: stur            d1, [fp, #-0x18]
    // 0x78b95c: LoadField: r1 = r0->field_7
    //     0x78b95c: ldur            x1, [x0, #7]
    // 0x78b960: cmp             x1, #2
    // 0x78b964: b.gt            #0x78b980
    // 0x78b968: cmp             x1, #1
    // 0x78b96c: b.gt            #0x78b980
    // 0x78b970: cmp             x1, #0
    // 0x78b974: b.le            #0x78b980
    // 0x78b978: d2 = 1.000000
    //     0x78b978: fmov            d2, #1.00000000
    // 0x78b97c: b               #0x78b984
    // 0x78b980: d2 = 18.000000
    //     0x78b980: fmov            d2, #18.00000000
    // 0x78b984: ldur            d0, [fp, #-0x10]
    // 0x78b988: fcmp            d0, d2
    // 0x78b98c: b.vs            #0x78b994
    // 0x78b990: b.gt            #0x78bad4
    // 0x78b994: ldr             x1, [fp, #0x20]
    // 0x78b998: LoadField: r2 = r1->field_7
    //     0x78b998: ldur            w2, [x1, #7]
    // 0x78b99c: DecompressPointer r2
    //     0x78b99c: add             x2, x2, HEAP, lsl #32
    // 0x78b9a0: stp             x2, x0, [SP, #-0x10]!
    // 0x78b9a4: r0 = computePanSlop()
    //     0x78b9a4: bl              #0x78a9bc  ; [package:flutter/src/gestures/events.dart] ::computePanSlop
    // 0x78b9a8: add             SP, SP, #0x10
    // 0x78b9ac: cmp             w0, NULL
    // 0x78b9b0: b.eq            #0x78bbe8
    // 0x78b9b4: LoadField: d0 = r0->field_7
    //     0x78b9b4: ldur            d0, [x0, #7]
    // 0x78b9b8: ldur            d1, [fp, #-0x18]
    // 0x78b9bc: fcmp            d1, d0
    // 0x78b9c0: b.vs            #0x78b9c8
    // 0x78b9c4: b.gt            #0x78bad4
    // 0x78b9c8: ldr             x0, [fp, #0x20]
    // 0x78b9cc: SaveReg r0
    //     0x78b9cc: str             x0, [SP, #-8]!
    // 0x78b9d0: r0 = _scaleFactor()
    //     0x78b9d0: bl              #0x78bdb0  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0x78b9d4: add             SP, SP, #8
    // 0x78b9d8: ldr             x0, [fp, #0x20]
    // 0x78b9dc: LoadField: r1 = r0->field_3f
    //     0x78b9dc: ldur            w1, [x0, #0x3f]
    // 0x78b9e0: DecompressPointer r1
    //     0x78b9e0: add             x1, x1, HEAP, lsl #32
    // 0x78b9e4: LoadField: d1 = r1->field_7
    //     0x78b9e4: ldur            d1, [x1, #7]
    // 0x78b9e8: d2 = 0.000000
    //     0x78b9e8: eor             v2.16b, v2.16b, v2.16b
    // 0x78b9ec: fcmp            d1, d2
    // 0x78b9f0: b.vs            #0x78b9f8
    // 0x78b9f4: b.gt            #0x78ba00
    // 0x78b9f8: r1 = false
    //     0x78b9f8: add             x1, NULL, #0x30  ; false
    // 0x78b9fc: b               #0x78ba04
    // 0x78ba00: r1 = true
    //     0x78ba00: add             x1, NULL, #0x20  ; true
    // 0x78ba04: tbnz            w1, #4, #0x78ba20
    // 0x78ba08: LoadField: r2 = r0->field_43
    //     0x78ba08: ldur            w2, [x0, #0x43]
    // 0x78ba0c: DecompressPointer r2
    //     0x78ba0c: add             x2, x2, HEAP, lsl #32
    // 0x78ba10: LoadField: d3 = r2->field_7
    //     0x78ba10: ldur            d3, [x2, #7]
    // 0x78ba14: fdiv            d4, d3, d1
    // 0x78ba18: mov             v3.16b, v4.16b
    // 0x78ba1c: b               #0x78ba24
    // 0x78ba20: d3 = 1.000000
    //     0x78ba20: fmov            d3, #1.00000000
    // 0x78ba24: fdiv            d4, d0, d3
    // 0x78ba28: stur            d4, [fp, #-0x18]
    // 0x78ba2c: tbnz            w1, #4, #0x78ba48
    // 0x78ba30: LoadField: r1 = r0->field_43
    //     0x78ba30: ldur            w1, [x0, #0x43]
    // 0x78ba34: DecompressPointer r1
    //     0x78ba34: add             x1, x1, HEAP, lsl #32
    // 0x78ba38: LoadField: d0 = r1->field_7
    //     0x78ba38: ldur            d0, [x1, #7]
    // 0x78ba3c: fdiv            d3, d0, d1
    // 0x78ba40: mov             v0.16b, v3.16b
    // 0x78ba44: b               #0x78ba4c
    // 0x78ba48: d0 = 1.000000
    //     0x78ba48: fmov            d0, #1.00000000
    // 0x78ba4c: stur            d0, [fp, #-0x10]
    // 0x78ba50: SaveReg r0
    //     0x78ba50: str             x0, [SP, #-8]!
    // 0x78ba54: r0 = _scaleFactor()
    //     0x78ba54: bl              #0x78bdb0  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0x78ba58: add             SP, SP, #8
    // 0x78ba5c: mov             v1.16b, v0.16b
    // 0x78ba60: ldur            d0, [fp, #-0x10]
    // 0x78ba64: fdiv            d2, d0, d1
    // 0x78ba68: ldur            d0, [fp, #-0x18]
    // 0x78ba6c: fcmp            d0, d2
    // 0x78ba70: b.vs            #0x78ba80
    // 0x78ba74: b.le            #0x78ba80
    // 0x78ba78: mov             v1.16b, v0.16b
    // 0x78ba7c: b               #0x78bac0
    // 0x78ba80: fcmp            d0, d2
    // 0x78ba84: b.vs            #0x78ba94
    // 0x78ba88: b.ge            #0x78ba94
    // 0x78ba8c: mov             v1.16b, v2.16b
    // 0x78ba90: b               #0x78bac0
    // 0x78ba94: d1 = 0.000000
    //     0x78ba94: eor             v1.16b, v1.16b, v1.16b
    // 0x78ba98: fcmp            d0, d1
    // 0x78ba9c: b.vs            #0x78baac
    // 0x78baa0: b.ne            #0x78baac
    // 0x78baa4: fadd            d1, d0, d2
    // 0x78baa8: b               #0x78bac0
    // 0x78baac: fcmp            d2, d2
    // 0x78bab0: b.vc            #0x78babc
    // 0x78bab4: mov             v1.16b, v2.16b
    // 0x78bab8: b               #0x78bac0
    // 0x78babc: mov             v1.16b, v0.16b
    // 0x78bac0: d0 = 1.050000
    //     0x78bac0: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e7b8] IMM: double(1.05) from 0x3ff0cccccccccccd
    //     0x78bac4: ldr             d0, [x17, #0x7b8]
    // 0x78bac8: fcmp            d1, d0
    // 0x78bacc: b.vs            #0x78bb14
    // 0x78bad0: b.le            #0x78bb14
    // 0x78bad4: ldr             x16, [fp, #0x20]
    // 0x78bad8: r30 = Instance_GestureDisposition
    //     0x78bad8: add             lr, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x78badc: ldr             lr, [lr, #0xed0]
    // 0x78bae0: stp             lr, x16, [SP, #-0x10]!
    // 0x78bae4: r0 = resolve()
    //     0x78bae4: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x78bae8: add             SP, SP, #0x10
    // 0x78baec: b               #0x78bb14
    // 0x78baf0: LoadField: r0 = r2->field_7
    //     0x78baf0: ldur            x0, [x2, #7]
    // 0x78baf4: cmp             x0, #2
    // 0x78baf8: b.lt            #0x78bb14
    // 0x78bafc: ldr             x16, [fp, #0x20]
    // 0x78bb00: r30 = Instance_GestureDisposition
    //     0x78bb00: add             lr, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x78bb04: ldr             lr, [lr, #0xed0]
    // 0x78bb08: stp             lr, x16, [SP, #-0x10]!
    // 0x78bb0c: r0 = resolve()
    //     0x78bb0c: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x78bb10: add             SP, SP, #0x10
    // 0x78bb14: ldr             x0, [fp, #0x20]
    // 0x78bb18: LoadField: r1 = r0->field_2f
    //     0x78bb18: ldur            w1, [x0, #0x2f]
    // 0x78bb1c: DecompressPointer r1
    //     0x78bb1c: add             x1, x1, HEAP, lsl #32
    // 0x78bb20: r16 = Instance__ScaleState
    //     0x78bb20: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e7c0] Obj!_ScaleState@b65a51
    //     0x78bb24: ldr             x16, [x16, #0x7c0]
    // 0x78bb28: cmp             w1, w16
    // 0x78bb2c: b.ne            #0x78bb50
    // 0x78bb30: ldr             x1, [fp, #0x18]
    // 0x78bb34: tbnz            w1, #4, #0x78bb50
    // 0x78bb38: r1 = Instance__ScaleState
    //     0x78bb38: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e20] Obj!_ScaleState@b65a71
    //     0x78bb3c: ldr             x1, [x1, #0xe20]
    // 0x78bb40: StoreField: r0->field_2f = r1
    //     0x78bb40: stur            w1, [x0, #0x2f]
    // 0x78bb44: SaveReg r0
    //     0x78bb44: str             x0, [SP, #-8]!
    // 0x78bb48: r0 = _dispatchOnStartCallbackIfNeeded()
    //     0x78bb48: bl              #0x78bbec  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_dispatchOnStartCallbackIfNeeded
    // 0x78bb4c: add             SP, SP, #8
    // 0x78bb50: ldr             x0, [fp, #0x20]
    // 0x78bb54: LoadField: r1 = r0->field_2f
    //     0x78bb54: ldur            w1, [x0, #0x2f]
    // 0x78bb58: DecompressPointer r1
    //     0x78bb58: add             x1, x1, HEAP, lsl #32
    // 0x78bb5c: r16 = Instance__ScaleState
    //     0x78bb5c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e20] Obj!_ScaleState@b65a71
    //     0x78bb60: ldr             x16, [x16, #0xe20]
    // 0x78bb64: cmp             w1, w16
    // 0x78bb68: b.ne            #0x78bba8
    // 0x78bb6c: LoadField: r1 = r0->field_27
    //     0x78bb6c: ldur            w1, [x0, #0x27]
    // 0x78bb70: DecompressPointer r1
    //     0x78bb70: add             x1, x1, HEAP, lsl #32
    // 0x78bb74: cmp             w1, NULL
    // 0x78bb78: b.eq            #0x78bba8
    // 0x78bb7c: ldur            x2, [fp, #-8]
    // 0x78bb80: r1 = Function '<anonymous closure>':.
    //     0x78bb80: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e7c8] AnonymousClosure: (0x78bf24), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_advanceStateMachine (0x78b834)
    //     0x78bb84: ldr             x1, [x1, #0x7c8]
    // 0x78bb88: r0 = AllocateClosure()
    //     0x78bb88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x78bb8c: r16 = <void?>
    //     0x78bb8c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x78bb90: ldr             lr, [fp, #0x20]
    // 0x78bb94: stp             lr, x16, [SP, #-0x10]!
    // 0x78bb98: SaveReg r0
    //     0x78bb98: str             x0, [SP, #-8]!
    // 0x78bb9c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x78bb9c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78bba0: r0 = invokeCallback()
    //     0x78bba0: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x78bba4: add             SP, SP, #0x18
    // 0x78bba8: r0 = Null
    //     0x78bba8: mov             x0, NULL
    // 0x78bbac: LeaveFrame
    //     0x78bbac: mov             SP, fp
    //     0x78bbb0: ldp             fp, lr, [SP], #0x10
    // 0x78bbb4: ret
    //     0x78bbb4: ret             
    // 0x78bbb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78bbb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78bbbc: b               #0x78b84c
    // 0x78bbc0: r9 = _currentSpan
    //     0x78bbc0: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e38] Field <ScaleGestureRecognizer._currentSpan@672213599>: late (offset: 0x44)
    //     0x78bbc4: ldr             x9, [x9, #0xe38]
    // 0x78bbc8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78bbc8: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78bbcc: r9 = _initialSpan
    //     0x78bbcc: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e80] Field <ScaleGestureRecognizer._initialSpan@672213599>: late (offset: 0x40)
    //     0x78bbd0: ldr             x9, [x9, #0xe80]
    // 0x78bbd4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78bbd4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78bbd8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x78bbd8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x78bbdc: r9 = _initialFocalPoint
    //     0x78bbdc: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e7d0] Field <ScaleGestureRecognizer._initialFocalPoint@672213599>: late (offset: 0x38)
    //     0x78bbe0: ldr             x9, [x9, #0x7d0]
    // 0x78bbe4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78bbe4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78bbe8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x78bbe8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _dispatchOnStartCallbackIfNeeded(/* No info */) {
    // ** addr: 0x78bbec, size: 0x7c
    // 0x78bbec: EnterFrame
    //     0x78bbec: stp             fp, lr, [SP, #-0x10]!
    //     0x78bbf0: mov             fp, SP
    // 0x78bbf4: CheckStackOverflow
    //     0x78bbf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78bbf8: cmp             SP, x16
    //     0x78bbfc: b.ls            #0x78bc60
    // 0x78bc00: r1 = 1
    //     0x78bc00: mov             x1, #1
    // 0x78bc04: r0 = AllocateContext()
    //     0x78bc04: bl              #0xd68aa4  ; AllocateContextStub
    // 0x78bc08: mov             x1, x0
    // 0x78bc0c: ldr             x0, [fp, #0x10]
    // 0x78bc10: StoreField: r1->field_f = r0
    //     0x78bc10: stur            w0, [x1, #0xf]
    // 0x78bc14: LoadField: r2 = r0->field_23
    //     0x78bc14: ldur            w2, [x0, #0x23]
    // 0x78bc18: DecompressPointer r2
    //     0x78bc18: add             x2, x2, HEAP, lsl #32
    // 0x78bc1c: cmp             w2, NULL
    // 0x78bc20: b.eq            #0x78bc50
    // 0x78bc24: mov             x2, x1
    // 0x78bc28: r1 = Function '<anonymous closure>':.
    //     0x78bc28: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e98] AnonymousClosure: (0x78bc68), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_dispatchOnStartCallbackIfNeeded (0x78bbec)
    //     0x78bc2c: ldr             x1, [x1, #0xe98]
    // 0x78bc30: r0 = AllocateClosure()
    //     0x78bc30: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x78bc34: r16 = <void?>
    //     0x78bc34: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x78bc38: ldr             lr, [fp, #0x10]
    // 0x78bc3c: stp             lr, x16, [SP, #-0x10]!
    // 0x78bc40: SaveReg r0
    //     0x78bc40: str             x0, [SP, #-8]!
    // 0x78bc44: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x78bc44: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78bc48: r0 = invokeCallback()
    //     0x78bc48: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x78bc4c: add             SP, SP, #0x18
    // 0x78bc50: r0 = Null
    //     0x78bc50: mov             x0, NULL
    // 0x78bc54: LeaveFrame
    //     0x78bc54: mov             SP, fp
    //     0x78bc58: ldp             fp, lr, [SP], #0x10
    // 0x78bc5c: ret
    //     0x78bc5c: ret             
    // 0x78bc60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78bc60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78bc64: b               #0x78bc00
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x78bc68, size: 0xe4
    // 0x78bc68: EnterFrame
    //     0x78bc68: stp             fp, lr, [SP, #-0x10]!
    //     0x78bc6c: mov             fp, SP
    // 0x78bc70: AllocStack(0x20)
    //     0x78bc70: sub             SP, SP, #0x20
    // 0x78bc74: SetupParameters()
    //     0x78bc74: ldr             x0, [fp, #0x10]
    //     0x78bc78: ldur            w1, [x0, #0x17]
    //     0x78bc7c: add             x1, x1, HEAP, lsl #32
    // 0x78bc80: CheckStackOverflow
    //     0x78bc80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78bc84: cmp             SP, x16
    //     0x78bc88: b.ls            #0x78bd30
    // 0x78bc8c: LoadField: r0 = r1->field_f
    //     0x78bc8c: ldur            w0, [x1, #0xf]
    // 0x78bc90: DecompressPointer r0
    //     0x78bc90: add             x0, x0, HEAP, lsl #32
    // 0x78bc94: LoadField: r1 = r0->field_23
    //     0x78bc94: ldur            w1, [x0, #0x23]
    // 0x78bc98: DecompressPointer r1
    //     0x78bc98: add             x1, x1, HEAP, lsl #32
    // 0x78bc9c: stur            x1, [fp, #-0x18]
    // 0x78bca0: cmp             w1, NULL
    // 0x78bca4: b.eq            #0x78bd38
    // 0x78bca8: LoadField: r2 = r0->field_3b
    //     0x78bca8: ldur            w2, [x0, #0x3b]
    // 0x78bcac: DecompressPointer r2
    //     0x78bcac: add             x2, x2, HEAP, lsl #32
    // 0x78bcb0: stur            x2, [fp, #-0x10]
    // 0x78bcb4: cmp             w2, NULL
    // 0x78bcb8: b.eq            #0x78bd3c
    // 0x78bcbc: LoadField: r3 = r0->field_57
    //     0x78bcbc: ldur            w3, [x0, #0x57]
    // 0x78bcc0: DecompressPointer r3
    //     0x78bcc0: add             x3, x3, HEAP, lsl #32
    // 0x78bcc4: r16 = Sentinel
    //     0x78bcc4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78bcc8: cmp             w3, w16
    // 0x78bccc: b.eq            #0x78bd40
    // 0x78bcd0: stur            x3, [fp, #-8]
    // 0x78bcd4: SaveReg r0
    //     0x78bcd4: str             x0, [SP, #-8]!
    // 0x78bcd8: r0 = _pointerCount()
    //     0x78bcd8: bl              #0x78bd58  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerCount
    // 0x78bcdc: add             SP, SP, #8
    // 0x78bce0: stur            x0, [fp, #-0x20]
    // 0x78bce4: r0 = ScaleStartDetails()
    //     0x78bce4: bl              #0x78bd4c  ; AllocateScaleStartDetailsStub -> ScaleStartDetails (size=0x18)
    // 0x78bce8: mov             x1, x0
    // 0x78bcec: ldur            x0, [fp, #-0x10]
    // 0x78bcf0: StoreField: r1->field_7 = r0
    //     0x78bcf0: stur            w0, [x1, #7]
    // 0x78bcf4: ldur            x0, [fp, #-0x20]
    // 0x78bcf8: StoreField: r1->field_f = r0
    //     0x78bcf8: stur            x0, [x1, #0xf]
    // 0x78bcfc: ldur            x0, [fp, #-8]
    // 0x78bd00: StoreField: r1->field_b = r0
    //     0x78bd00: stur            w0, [x1, #0xb]
    // 0x78bd04: ldur            x16, [fp, #-0x18]
    // 0x78bd08: stp             x1, x16, [SP, #-0x10]!
    // 0x78bd0c: ldur            x0, [fp, #-0x18]
    // 0x78bd10: ClosureCall
    //     0x78bd10: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x78bd14: ldur            x2, [x0, #0x1f]
    //     0x78bd18: blr             x2
    // 0x78bd1c: add             SP, SP, #0x10
    // 0x78bd20: r0 = Null
    //     0x78bd20: mov             x0, NULL
    // 0x78bd24: LeaveFrame
    //     0x78bd24: mov             SP, fp
    //     0x78bd28: ldp             fp, lr, [SP], #0x10
    // 0x78bd2c: ret
    //     0x78bd2c: ret             
    // 0x78bd30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78bd30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78bd34: b               #0x78bc8c
    // 0x78bd38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78bd38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78bd3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78bd3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78bd40: r9 = _localFocalPoint
    //     0x78bd40: add             x9, PP, #0x28, lsl #12  ; [pp+0x28ea0] Field <ScaleGestureRecognizer._localFocalPoint@672213599>: late (offset: 0x58)
    //     0x78bd44: ldr             x9, [x9, #0xea0]
    // 0x78bd48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78bd48: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _pointerCount(/* No info */) {
    // ** addr: 0x78bd58, size: 0x58
    // 0x78bd58: EnterFrame
    //     0x78bd58: stp             fp, lr, [SP, #-0x10]!
    //     0x78bd5c: mov             fp, SP
    // 0x78bd60: ldr             x1, [fp, #0x10]
    // 0x78bd64: LoadField: r2 = r1->field_73
    //     0x78bd64: ldur            w2, [x1, #0x73]
    // 0x78bd68: DecompressPointer r2
    //     0x78bd68: add             x2, x2, HEAP, lsl #32
    // 0x78bd6c: LoadField: r3 = r2->field_13
    //     0x78bd6c: ldur            w3, [x2, #0x13]
    // 0x78bd70: DecompressPointer r3
    //     0x78bd70: add             x3, x3, HEAP, lsl #32
    // 0x78bd74: r4 = LoadInt32Instr(r3)
    //     0x78bd74: sbfx            x4, x3, #1, #0x1f
    // 0x78bd78: asr             x3, x4, #1
    // 0x78bd7c: LoadField: r4 = r2->field_17
    //     0x78bd7c: ldur            w4, [x2, #0x17]
    // 0x78bd80: DecompressPointer r4
    //     0x78bd80: add             x4, x4, HEAP, lsl #32
    // 0x78bd84: r2 = LoadInt32Instr(r4)
    //     0x78bd84: sbfx            x2, x4, #1, #0x1f
    // 0x78bd88: sub             x4, x3, x2
    // 0x78bd8c: LoadField: r2 = r1->field_67
    //     0x78bd8c: ldur            w2, [x1, #0x67]
    // 0x78bd90: DecompressPointer r2
    //     0x78bd90: add             x2, x2, HEAP, lsl #32
    // 0x78bd94: LoadField: r1 = r2->field_b
    //     0x78bd94: ldur            w1, [x2, #0xb]
    // 0x78bd98: DecompressPointer r1
    //     0x78bd98: add             x1, x1, HEAP, lsl #32
    // 0x78bd9c: r2 = LoadInt32Instr(r1)
    //     0x78bd9c: sbfx            x2, x1, #1, #0x1f
    // 0x78bda0: add             x0, x4, x2
    // 0x78bda4: LeaveFrame
    //     0x78bda4: mov             SP, fp
    //     0x78bda8: ldp             fp, lr, [SP], #0x10
    // 0x78bdac: ret
    //     0x78bdac: ret             
  }
  get _ _scaleFactor(/* No info */) {
    // ** addr: 0x78bdb0, size: 0x174
    // 0x78bdb0: EnterFrame
    //     0x78bdb0: stp             fp, lr, [SP, #-0x10]!
    //     0x78bdb4: mov             fp, SP
    // 0x78bdb8: AllocStack(0x20)
    //     0x78bdb8: sub             SP, SP, #0x20
    // 0x78bdbc: d0 = 0.000000
    //     0x78bdbc: eor             v0.16b, v0.16b, v0.16b
    // 0x78bdc0: CheckStackOverflow
    //     0x78bdc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78bdc4: cmp             SP, x16
    //     0x78bdc8: b.ls            #0x78befc
    // 0x78bdcc: ldr             x0, [fp, #0x10]
    // 0x78bdd0: LoadField: r1 = r0->field_3f
    //     0x78bdd0: ldur            w1, [x0, #0x3f]
    // 0x78bdd4: DecompressPointer r1
    //     0x78bdd4: add             x1, x1, HEAP, lsl #32
    // 0x78bdd8: r16 = Sentinel
    //     0x78bdd8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78bddc: cmp             w1, w16
    // 0x78bde0: b.eq            #0x78bf04
    // 0x78bde4: LoadField: d1 = r1->field_7
    //     0x78bde4: ldur            d1, [x1, #7]
    // 0x78bde8: fcmp            d1, d0
    // 0x78bdec: b.vs            #0x78be18
    // 0x78bdf0: b.le            #0x78be18
    // 0x78bdf4: LoadField: r1 = r0->field_43
    //     0x78bdf4: ldur            w1, [x0, #0x43]
    // 0x78bdf8: DecompressPointer r1
    //     0x78bdf8: add             x1, x1, HEAP, lsl #32
    // 0x78bdfc: r16 = Sentinel
    //     0x78bdfc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78be00: cmp             w1, w16
    // 0x78be04: b.eq            #0x78bf10
    // 0x78be08: LoadField: d0 = r1->field_7
    //     0x78be08: ldur            d0, [x1, #7]
    // 0x78be0c: fdiv            d2, d0, d1
    // 0x78be10: mov             v0.16b, v2.16b
    // 0x78be14: b               #0x78be1c
    // 0x78be18: d0 = 1.000000
    //     0x78be18: fmov            d0, #1.00000000
    // 0x78be1c: stur            d0, [fp, #-0x20]
    // 0x78be20: LoadField: r1 = r0->field_73
    //     0x78be20: ldur            w1, [x0, #0x73]
    // 0x78be24: DecompressPointer r1
    //     0x78be24: add             x1, x1, HEAP, lsl #32
    // 0x78be28: SaveReg r1
    //     0x78be28: str             x1, [SP, #-8]!
    // 0x78be2c: r0 = values()
    //     0x78be2c: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x78be30: add             SP, SP, #8
    // 0x78be34: SaveReg r0
    //     0x78be34: str             x0, [SP, #-8]!
    // 0x78be38: r0 = iterator()
    //     0x78be38: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x78be3c: add             SP, SP, #8
    // 0x78be40: stur            x0, [fp, #-0x10]
    // 0x78be44: LoadField: r2 = r0->field_7
    //     0x78be44: ldur            w2, [x0, #7]
    // 0x78be48: DecompressPointer r2
    //     0x78be48: add             x2, x2, HEAP, lsl #32
    // 0x78be4c: stur            x2, [fp, #-8]
    // 0x78be50: ldur            d0, [fp, #-0x20]
    // 0x78be54: ldr             x1, [fp, #0x10]
    // 0x78be58: stur            d0, [fp, #-0x20]
    // 0x78be5c: CheckStackOverflow
    //     0x78be5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78be60: cmp             SP, x16
    //     0x78be64: b.ls            #0x78bf1c
    // 0x78be68: SaveReg r0
    //     0x78be68: str             x0, [SP, #-8]!
    // 0x78be6c: r0 = moveNext()
    //     0x78be6c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78be70: add             SP, SP, #8
    // 0x78be74: tbnz            w0, #4, #0x78beec
    // 0x78be78: ldur            x3, [fp, #-0x10]
    // 0x78be7c: LoadField: r4 = r3->field_33
    //     0x78be7c: ldur            w4, [x3, #0x33]
    // 0x78be80: DecompressPointer r4
    //     0x78be80: add             x4, x4, HEAP, lsl #32
    // 0x78be84: stur            x4, [fp, #-0x18]
    // 0x78be88: cmp             w4, NULL
    // 0x78be8c: b.ne            #0x78bec0
    // 0x78be90: mov             x0, x4
    // 0x78be94: ldur            x2, [fp, #-8]
    // 0x78be98: r1 = Null
    //     0x78be98: mov             x1, NULL
    // 0x78be9c: cmp             w2, NULL
    // 0x78bea0: b.eq            #0x78bec0
    // 0x78bea4: LoadField: r4 = r2->field_17
    //     0x78bea4: ldur            w4, [x2, #0x17]
    // 0x78bea8: DecompressPointer r4
    //     0x78bea8: add             x4, x4, HEAP, lsl #32
    // 0x78beac: r8 = X0
    //     0x78beac: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78beb0: LoadField: r9 = r4->field_7
    //     0x78beb0: ldur            x9, [x4, #7]
    // 0x78beb4: r3 = Null
    //     0x78beb4: add             x3, PP, #0x28, lsl #12  ; [pp+0x28e88] Null
    //     0x78beb8: ldr             x3, [x3, #0xe88]
    // 0x78bebc: blr             x9
    // 0x78bec0: ldr             x1, [fp, #0x10]
    // 0x78bec4: ldur            d0, [fp, #-0x20]
    // 0x78bec8: ldur            x0, [fp, #-0x18]
    // 0x78becc: LoadField: d1 = r0->field_b
    //     0x78becc: ldur            d1, [x0, #0xb]
    // 0x78bed0: LoadField: d2 = r1->field_77
    //     0x78bed0: ldur            d2, [x1, #0x77]
    // 0x78bed4: fdiv            d3, d1, d2
    // 0x78bed8: fmul            d1, d0, d3
    // 0x78bedc: mov             v0.16b, v1.16b
    // 0x78bee0: ldur            x0, [fp, #-0x10]
    // 0x78bee4: ldur            x2, [fp, #-8]
    // 0x78bee8: b               #0x78be58
    // 0x78beec: ldur            d0, [fp, #-0x20]
    // 0x78bef0: LeaveFrame
    //     0x78bef0: mov             SP, fp
    //     0x78bef4: ldp             fp, lr, [SP], #0x10
    // 0x78bef8: ret
    //     0x78bef8: ret             
    // 0x78befc: r0 = StackOverflowSharedWithFPURegs()
    //     0x78befc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x78bf00: b               #0x78bdcc
    // 0x78bf04: r9 = _initialSpan
    //     0x78bf04: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e80] Field <ScaleGestureRecognizer._initialSpan@672213599>: late (offset: 0x40)
    //     0x78bf08: ldr             x9, [x9, #0xe80]
    // 0x78bf0c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78bf0c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78bf10: r9 = _currentSpan
    //     0x78bf10: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e38] Field <ScaleGestureRecognizer._currentSpan@672213599>: late (offset: 0x44)
    //     0x78bf14: ldr             x9, [x9, #0xe38]
    // 0x78bf18: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78bf18: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78bf1c: r0 = StackOverflowSharedWithFPURegs()
    //     0x78bf1c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x78bf20: b               #0x78be68
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x78bf24, size: 0x1b4
    // 0x78bf24: EnterFrame
    //     0x78bf24: stp             fp, lr, [SP, #-0x10]!
    //     0x78bf28: mov             fp, SP
    // 0x78bf2c: AllocStack(0x48)
    //     0x78bf2c: sub             SP, SP, #0x48
    // 0x78bf30: SetupParameters()
    //     0x78bf30: ldr             x0, [fp, #0x10]
    //     0x78bf34: ldur            w1, [x0, #0x17]
    //     0x78bf38: add             x1, x1, HEAP, lsl #32
    //     0x78bf3c: stur            x1, [fp, #-0x10]
    // 0x78bf40: CheckStackOverflow
    //     0x78bf40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78bf44: cmp             SP, x16
    //     0x78bf48: b.ls            #0x78c0b0
    // 0x78bf4c: LoadField: r0 = r1->field_f
    //     0x78bf4c: ldur            w0, [x1, #0xf]
    // 0x78bf50: DecompressPointer r0
    //     0x78bf50: add             x0, x0, HEAP, lsl #32
    // 0x78bf54: LoadField: r2 = r0->field_27
    //     0x78bf54: ldur            w2, [x0, #0x27]
    // 0x78bf58: DecompressPointer r2
    //     0x78bf58: add             x2, x2, HEAP, lsl #32
    // 0x78bf5c: stur            x2, [fp, #-8]
    // 0x78bf60: cmp             w2, NULL
    // 0x78bf64: b.eq            #0x78c0b8
    // 0x78bf68: SaveReg r0
    //     0x78bf68: str             x0, [SP, #-8]!
    // 0x78bf6c: r0 = _scaleFactor()
    //     0x78bf6c: bl              #0x78bdb0  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0x78bf70: add             SP, SP, #8
    // 0x78bf74: ldur            x0, [fp, #-0x10]
    // 0x78bf78: stur            d0, [fp, #-0x30]
    // 0x78bf7c: LoadField: r1 = r0->field_f
    //     0x78bf7c: ldur            w1, [x0, #0xf]
    // 0x78bf80: DecompressPointer r1
    //     0x78bf80: add             x1, x1, HEAP, lsl #32
    // 0x78bf84: SaveReg r1
    //     0x78bf84: str             x1, [SP, #-8]!
    // 0x78bf88: r0 = _horizontalScaleFactor()
    //     0x78bf88: bl              #0x78c4ac  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_horizontalScaleFactor
    // 0x78bf8c: add             SP, SP, #8
    // 0x78bf90: ldur            x0, [fp, #-0x10]
    // 0x78bf94: stur            d0, [fp, #-0x38]
    // 0x78bf98: LoadField: r1 = r0->field_f
    //     0x78bf98: ldur            w1, [x0, #0xf]
    // 0x78bf9c: DecompressPointer r1
    //     0x78bf9c: add             x1, x1, HEAP, lsl #32
    // 0x78bfa0: SaveReg r1
    //     0x78bfa0: str             x1, [SP, #-8]!
    // 0x78bfa4: r0 = _verticalScaleFactor()
    //     0x78bfa4: bl              #0x78c310  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_verticalScaleFactor
    // 0x78bfa8: add             SP, SP, #8
    // 0x78bfac: ldur            x0, [fp, #-0x10]
    // 0x78bfb0: stur            d0, [fp, #-0x40]
    // 0x78bfb4: LoadField: r1 = r0->field_f
    //     0x78bfb4: ldur            w1, [x0, #0xf]
    // 0x78bfb8: DecompressPointer r1
    //     0x78bfb8: add             x1, x1, HEAP, lsl #32
    // 0x78bfbc: LoadField: r2 = r1->field_3b
    //     0x78bfbc: ldur            w2, [x1, #0x3b]
    // 0x78bfc0: DecompressPointer r2
    //     0x78bfc0: add             x2, x2, HEAP, lsl #32
    // 0x78bfc4: stur            x2, [fp, #-0x20]
    // 0x78bfc8: cmp             w2, NULL
    // 0x78bfcc: b.eq            #0x78c0bc
    // 0x78bfd0: LoadField: r3 = r1->field_57
    //     0x78bfd0: ldur            w3, [x1, #0x57]
    // 0x78bfd4: DecompressPointer r3
    //     0x78bfd4: add             x3, x3, HEAP, lsl #32
    // 0x78bfd8: r16 = Sentinel
    //     0x78bfd8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78bfdc: cmp             w3, w16
    // 0x78bfe0: b.eq            #0x78c0c0
    // 0x78bfe4: stur            x3, [fp, #-0x18]
    // 0x78bfe8: SaveReg r1
    //     0x78bfe8: str             x1, [SP, #-8]!
    // 0x78bfec: r0 = _computeRotationFactor()
    //     0x78bfec: bl              #0x78c0e4  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_computeRotationFactor
    // 0x78bff0: add             SP, SP, #8
    // 0x78bff4: ldur            x0, [fp, #-0x10]
    // 0x78bff8: stur            d0, [fp, #-0x48]
    // 0x78bffc: LoadField: r1 = r0->field_f
    //     0x78bffc: ldur            w1, [x0, #0xf]
    // 0x78c000: DecompressPointer r1
    //     0x78c000: add             x1, x1, HEAP, lsl #32
    // 0x78c004: SaveReg r1
    //     0x78c004: str             x1, [SP, #-8]!
    // 0x78c008: r0 = _pointerCount()
    //     0x78c008: bl              #0x78bd58  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerCount
    // 0x78c00c: add             SP, SP, #8
    // 0x78c010: mov             x1, x0
    // 0x78c014: ldur            x0, [fp, #-0x10]
    // 0x78c018: stur            x1, [fp, #-0x28]
    // 0x78c01c: LoadField: r2 = r0->field_f
    //     0x78c01c: ldur            w2, [x0, #0xf]
    // 0x78c020: DecompressPointer r2
    //     0x78c020: add             x2, x2, HEAP, lsl #32
    // 0x78c024: LoadField: r0 = r2->field_6f
    //     0x78c024: ldur            w0, [x2, #0x6f]
    // 0x78c028: DecompressPointer r0
    //     0x78c028: add             x0, x0, HEAP, lsl #32
    // 0x78c02c: r16 = Sentinel
    //     0x78c02c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78c030: cmp             w0, w16
    // 0x78c034: b.eq            #0x78c0cc
    // 0x78c038: stur            x0, [fp, #-0x10]
    // 0x78c03c: r0 = ScaleUpdateDetails()
    //     0x78c03c: bl              #0x78c0d8  ; AllocateScaleUpdateDetailsStub -> ScaleUpdateDetails (size=0x3c)
    // 0x78c040: mov             x1, x0
    // 0x78c044: ldur            x0, [fp, #-0x20]
    // 0x78c048: StoreField: r1->field_b = r0
    //     0x78c048: stur            w0, [x1, #0xb]
    // 0x78c04c: ldur            d0, [fp, #-0x30]
    // 0x78c050: StoreField: r1->field_13 = d0
    //     0x78c050: stur            d0, [x1, #0x13]
    // 0x78c054: ldur            d0, [fp, #-0x38]
    // 0x78c058: StoreField: r1->field_1b = d0
    //     0x78c058: stur            d0, [x1, #0x1b]
    // 0x78c05c: ldur            d0, [fp, #-0x40]
    // 0x78c060: StoreField: r1->field_23 = d0
    //     0x78c060: stur            d0, [x1, #0x23]
    // 0x78c064: ldur            d0, [fp, #-0x48]
    // 0x78c068: StoreField: r1->field_2b = d0
    //     0x78c068: stur            d0, [x1, #0x2b]
    // 0x78c06c: ldur            x0, [fp, #-0x28]
    // 0x78c070: StoreField: r1->field_33 = r0
    //     0x78c070: stur            x0, [x1, #0x33]
    // 0x78c074: ldur            x0, [fp, #-0x10]
    // 0x78c078: StoreField: r1->field_7 = r0
    //     0x78c078: stur            w0, [x1, #7]
    // 0x78c07c: ldur            x0, [fp, #-0x18]
    // 0x78c080: StoreField: r1->field_f = r0
    //     0x78c080: stur            w0, [x1, #0xf]
    // 0x78c084: ldur            x16, [fp, #-8]
    // 0x78c088: stp             x1, x16, [SP, #-0x10]!
    // 0x78c08c: ldur            x0, [fp, #-8]
    // 0x78c090: ClosureCall
    //     0x78c090: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x78c094: ldur            x2, [x0, #0x1f]
    //     0x78c098: blr             x2
    // 0x78c09c: add             SP, SP, #0x10
    // 0x78c0a0: r0 = Null
    //     0x78c0a0: mov             x0, NULL
    // 0x78c0a4: LeaveFrame
    //     0x78c0a4: mov             SP, fp
    //     0x78c0a8: ldp             fp, lr, [SP], #0x10
    // 0x78c0ac: ret
    //     0x78c0ac: ret             
    // 0x78c0b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c0b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c0b4: b               #0x78bf4c
    // 0x78c0b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78c0b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78c0bc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x78c0bc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x78c0c0: r9 = _localFocalPoint
    //     0x78c0c0: add             x9, PP, #0x28, lsl #12  ; [pp+0x28ea0] Field <ScaleGestureRecognizer._localFocalPoint@672213599>: late (offset: 0x58)
    //     0x78c0c4: ldr             x9, [x9, #0xea0]
    // 0x78c0c8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78c0c8: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78c0cc: r9 = _delta
    //     0x78c0cc: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e7d8] Field <ScaleGestureRecognizer._delta@672213599>: late (offset: 0x70)
    //     0x78c0d0: ldr             x9, [x9, #0x7d8]
    // 0x78c0d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78c0d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _computeRotationFactor(/* No info */) {
    // ** addr: 0x78c0e4, size: 0x22c
    // 0x78c0e4: EnterFrame
    //     0x78c0e4: stp             fp, lr, [SP, #-0x10]!
    //     0x78c0e8: mov             fp, SP
    // 0x78c0ec: AllocStack(0x40)
    //     0x78c0ec: sub             SP, SP, #0x40
    // 0x78c0f0: CheckStackOverflow
    //     0x78c0f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78c0f4: cmp             SP, x16
    //     0x78c0f8: b.ls            #0x78c300
    // 0x78c0fc: ldr             x0, [fp, #0x10]
    // 0x78c100: LoadField: r1 = r0->field_5b
    //     0x78c100: ldur            w1, [x0, #0x5b]
    // 0x78c104: DecompressPointer r1
    //     0x78c104: add             x1, x1, HEAP, lsl #32
    // 0x78c108: cmp             w1, NULL
    // 0x78c10c: b.eq            #0x78c220
    // 0x78c110: LoadField: r2 = r0->field_5f
    //     0x78c110: ldur            w2, [x0, #0x5f]
    // 0x78c114: DecompressPointer r2
    //     0x78c114: add             x2, x2, HEAP, lsl #32
    // 0x78c118: cmp             w2, NULL
    // 0x78c11c: b.eq            #0x78c220
    // 0x78c120: LoadField: r3 = r1->field_7
    //     0x78c120: ldur            w3, [x1, #7]
    // 0x78c124: DecompressPointer r3
    //     0x78c124: add             x3, x3, HEAP, lsl #32
    // 0x78c128: LoadField: d0 = r3->field_7
    //     0x78c128: ldur            d0, [x3, #7]
    // 0x78c12c: LoadField: d1 = r3->field_f
    //     0x78c12c: ldur            d1, [x3, #0xf]
    // 0x78c130: LoadField: r3 = r1->field_13
    //     0x78c130: ldur            w3, [x1, #0x13]
    // 0x78c134: DecompressPointer r3
    //     0x78c134: add             x3, x3, HEAP, lsl #32
    // 0x78c138: LoadField: d2 = r3->field_7
    //     0x78c138: ldur            d2, [x3, #7]
    // 0x78c13c: LoadField: d3 = r3->field_f
    //     0x78c13c: ldur            d3, [x3, #0xf]
    // 0x78c140: LoadField: r1 = r2->field_7
    //     0x78c140: ldur            w1, [x2, #7]
    // 0x78c144: DecompressPointer r1
    //     0x78c144: add             x1, x1, HEAP, lsl #32
    // 0x78c148: LoadField: d4 = r1->field_7
    //     0x78c148: ldur            d4, [x1, #7]
    // 0x78c14c: stur            d4, [fp, #-0x38]
    // 0x78c150: LoadField: d5 = r1->field_f
    //     0x78c150: ldur            d5, [x1, #0xf]
    // 0x78c154: stur            d5, [fp, #-0x30]
    // 0x78c158: LoadField: r1 = r2->field_13
    //     0x78c158: ldur            w1, [x2, #0x13]
    // 0x78c15c: DecompressPointer r1
    //     0x78c15c: add             x1, x1, HEAP, lsl #32
    // 0x78c160: LoadField: d6 = r1->field_7
    //     0x78c160: ldur            d6, [x1, #7]
    // 0x78c164: stur            d6, [fp, #-0x28]
    // 0x78c168: LoadField: d7 = r1->field_f
    //     0x78c168: ldur            d7, [x1, #0xf]
    // 0x78c16c: stur            d7, [fp, #-0x20]
    // 0x78c170: fsub            d8, d1, d3
    // 0x78c174: fsub            d1, d0, d2
    // 0x78c178: mov             v0.16b, v8.16b
    // 0x78c17c: stp             fp, lr, [SP, #-0x10]!
    // 0x78c180: mov             fp, SP
    // 0x78c184: CallRuntime_LibcAtan2(double, double) -> double
    //     0x78c184: and             SP, SP, #0xfffffffffffffff0
    //     0x78c188: mov             sp, SP
    //     0x78c18c: ldr             x16, [THR, #0x5b0]  ; THR::LibcAtan2
    //     0x78c190: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x78c194: blr             x16
    //     0x78c198: mov             x16, #8
    //     0x78c19c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x78c1a0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x78c1a4: sub             sp, x16, #1, lsl #12
    //     0x78c1a8: mov             SP, fp
    //     0x78c1ac: ldp             fp, lr, [SP], #0x10
    // 0x78c1b0: mov             v2.16b, v0.16b
    // 0x78c1b4: ldur            d0, [fp, #-0x30]
    // 0x78c1b8: ldur            d1, [fp, #-0x20]
    // 0x78c1bc: stur            d2, [fp, #-0x40]
    // 0x78c1c0: fsub            d3, d0, d1
    // 0x78c1c4: ldur            d0, [fp, #-0x38]
    // 0x78c1c8: ldur            d1, [fp, #-0x28]
    // 0x78c1cc: fsub            d4, d0, d1
    // 0x78c1d0: mov             v0.16b, v3.16b
    // 0x78c1d4: mov             v1.16b, v4.16b
    // 0x78c1d8: stp             fp, lr, [SP, #-0x10]!
    // 0x78c1dc: mov             fp, SP
    // 0x78c1e0: CallRuntime_LibcAtan2(double, double) -> double
    //     0x78c1e0: and             SP, SP, #0xfffffffffffffff0
    //     0x78c1e4: mov             sp, SP
    //     0x78c1e8: ldr             x16, [THR, #0x5b0]  ; THR::LibcAtan2
    //     0x78c1ec: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x78c1f0: blr             x16
    //     0x78c1f4: mov             x16, #8
    //     0x78c1f8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x78c1fc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x78c200: sub             sp, x16, #1, lsl #12
    //     0x78c204: mov             SP, fp
    //     0x78c208: ldp             fp, lr, [SP], #0x10
    // 0x78c20c: mov             v1.16b, v0.16b
    // 0x78c210: ldur            d0, [fp, #-0x40]
    // 0x78c214: fsub            d2, d1, d0
    // 0x78c218: mov             v0.16b, v2.16b
    // 0x78c21c: b               #0x78c224
    // 0x78c220: d0 = 0.000000
    //     0x78c220: eor             v0.16b, v0.16b, v0.16b
    // 0x78c224: ldr             x0, [fp, #0x10]
    // 0x78c228: stur            d0, [fp, #-0x20]
    // 0x78c22c: LoadField: r1 = r0->field_73
    //     0x78c22c: ldur            w1, [x0, #0x73]
    // 0x78c230: DecompressPointer r1
    //     0x78c230: add             x1, x1, HEAP, lsl #32
    // 0x78c234: SaveReg r1
    //     0x78c234: str             x1, [SP, #-8]!
    // 0x78c238: r0 = values()
    //     0x78c238: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x78c23c: add             SP, SP, #8
    // 0x78c240: SaveReg r0
    //     0x78c240: str             x0, [SP, #-8]!
    // 0x78c244: r0 = iterator()
    //     0x78c244: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x78c248: add             SP, SP, #8
    // 0x78c24c: stur            x0, [fp, #-0x10]
    // 0x78c250: LoadField: r2 = r0->field_7
    //     0x78c250: ldur            w2, [x0, #7]
    // 0x78c254: DecompressPointer r2
    //     0x78c254: add             x2, x2, HEAP, lsl #32
    // 0x78c258: stur            x2, [fp, #-8]
    // 0x78c25c: ldur            d0, [fp, #-0x20]
    // 0x78c260: stur            d0, [fp, #-0x20]
    // 0x78c264: CheckStackOverflow
    //     0x78c264: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78c268: cmp             SP, x16
    //     0x78c26c: b.ls            #0x78c308
    // 0x78c270: SaveReg r0
    //     0x78c270: str             x0, [SP, #-8]!
    // 0x78c274: r0 = moveNext()
    //     0x78c274: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78c278: add             SP, SP, #8
    // 0x78c27c: tbnz            w0, #4, #0x78c2e4
    // 0x78c280: ldur            x3, [fp, #-0x10]
    // 0x78c284: LoadField: r4 = r3->field_33
    //     0x78c284: ldur            w4, [x3, #0x33]
    // 0x78c288: DecompressPointer r4
    //     0x78c288: add             x4, x4, HEAP, lsl #32
    // 0x78c28c: stur            x4, [fp, #-0x18]
    // 0x78c290: cmp             w4, NULL
    // 0x78c294: b.ne            #0x78c2c8
    // 0x78c298: mov             x0, x4
    // 0x78c29c: ldur            x2, [fp, #-8]
    // 0x78c2a0: r1 = Null
    //     0x78c2a0: mov             x1, NULL
    // 0x78c2a4: cmp             w2, NULL
    // 0x78c2a8: b.eq            #0x78c2c8
    // 0x78c2ac: LoadField: r4 = r2->field_17
    //     0x78c2ac: ldur            w4, [x2, #0x17]
    // 0x78c2b0: DecompressPointer r4
    //     0x78c2b0: add             x4, x4, HEAP, lsl #32
    // 0x78c2b4: r8 = X0
    //     0x78c2b4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78c2b8: LoadField: r9 = r4->field_7
    //     0x78c2b8: ldur            x9, [x4, #7]
    // 0x78c2bc: r3 = Null
    //     0x78c2bc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e7e0] Null
    //     0x78c2c0: ldr             x3, [x3, #0x7e0]
    // 0x78c2c4: blr             x9
    // 0x78c2c8: ldur            d1, [fp, #-0x20]
    // 0x78c2cc: ldur            x0, [fp, #-0x18]
    // 0x78c2d0: LoadField: d2 = r0->field_13
    //     0x78c2d0: ldur            d2, [x0, #0x13]
    // 0x78c2d4: fadd            d0, d1, d2
    // 0x78c2d8: ldur            x0, [fp, #-0x10]
    // 0x78c2dc: ldur            x2, [fp, #-8]
    // 0x78c2e0: b               #0x78c260
    // 0x78c2e4: ldr             x0, [fp, #0x10]
    // 0x78c2e8: ldur            d1, [fp, #-0x20]
    // 0x78c2ec: LoadField: d2 = r0->field_7f
    //     0x78c2ec: ldur            d2, [x0, #0x7f]
    // 0x78c2f0: fsub            d0, d1, d2
    // 0x78c2f4: LeaveFrame
    //     0x78c2f4: mov             SP, fp
    //     0x78c2f8: ldp             fp, lr, [SP], #0x10
    // 0x78c2fc: ret
    //     0x78c2fc: ret             
    // 0x78c300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c304: b               #0x78c0fc
    // 0x78c308: r0 = StackOverflowSharedWithFPURegs()
    //     0x78c308: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x78c30c: b               #0x78c270
  }
  get _ _verticalScaleFactor(/* No info */) {
    // ** addr: 0x78c310, size: 0x11c
    // 0x78c310: EnterFrame
    //     0x78c310: stp             fp, lr, [SP, #-0x10]!
    //     0x78c314: mov             fp, SP
    // 0x78c318: AllocStack(0x20)
    //     0x78c318: sub             SP, SP, #0x20
    // 0x78c31c: CheckStackOverflow
    //     0x78c31c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78c320: cmp             SP, x16
    //     0x78c324: b.ls            #0x78c41c
    // 0x78c328: ldr             x16, [fp, #0x10]
    // 0x78c32c: SaveReg r16
    //     0x78c32c: str             x16, [SP, #-8]!
    // 0x78c330: r0 = _pointerVerticalScaleFactor()
    //     0x78c330: bl              #0x78c42c  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerVerticalScaleFactor
    // 0x78c334: add             SP, SP, #8
    // 0x78c338: ldr             x0, [fp, #0x10]
    // 0x78c33c: stur            d0, [fp, #-0x20]
    // 0x78c340: LoadField: r1 = r0->field_73
    //     0x78c340: ldur            w1, [x0, #0x73]
    // 0x78c344: DecompressPointer r1
    //     0x78c344: add             x1, x1, HEAP, lsl #32
    // 0x78c348: SaveReg r1
    //     0x78c348: str             x1, [SP, #-8]!
    // 0x78c34c: r0 = values()
    //     0x78c34c: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x78c350: add             SP, SP, #8
    // 0x78c354: SaveReg r0
    //     0x78c354: str             x0, [SP, #-8]!
    // 0x78c358: r0 = iterator()
    //     0x78c358: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x78c35c: add             SP, SP, #8
    // 0x78c360: stur            x0, [fp, #-0x10]
    // 0x78c364: LoadField: r2 = r0->field_7
    //     0x78c364: ldur            w2, [x0, #7]
    // 0x78c368: DecompressPointer r2
    //     0x78c368: add             x2, x2, HEAP, lsl #32
    // 0x78c36c: stur            x2, [fp, #-8]
    // 0x78c370: ldur            d0, [fp, #-0x20]
    // 0x78c374: ldr             x1, [fp, #0x10]
    // 0x78c378: stur            d0, [fp, #-0x20]
    // 0x78c37c: CheckStackOverflow
    //     0x78c37c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78c380: cmp             SP, x16
    //     0x78c384: b.ls            #0x78c424
    // 0x78c388: SaveReg r0
    //     0x78c388: str             x0, [SP, #-8]!
    // 0x78c38c: r0 = moveNext()
    //     0x78c38c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78c390: add             SP, SP, #8
    // 0x78c394: tbnz            w0, #4, #0x78c40c
    // 0x78c398: ldur            x3, [fp, #-0x10]
    // 0x78c39c: LoadField: r4 = r3->field_33
    //     0x78c39c: ldur            w4, [x3, #0x33]
    // 0x78c3a0: DecompressPointer r4
    //     0x78c3a0: add             x4, x4, HEAP, lsl #32
    // 0x78c3a4: stur            x4, [fp, #-0x18]
    // 0x78c3a8: cmp             w4, NULL
    // 0x78c3ac: b.ne            #0x78c3e0
    // 0x78c3b0: mov             x0, x4
    // 0x78c3b4: ldur            x2, [fp, #-8]
    // 0x78c3b8: r1 = Null
    //     0x78c3b8: mov             x1, NULL
    // 0x78c3bc: cmp             w2, NULL
    // 0x78c3c0: b.eq            #0x78c3e0
    // 0x78c3c4: LoadField: r4 = r2->field_17
    //     0x78c3c4: ldur            w4, [x2, #0x17]
    // 0x78c3c8: DecompressPointer r4
    //     0x78c3c8: add             x4, x4, HEAP, lsl #32
    // 0x78c3cc: r8 = X0
    //     0x78c3cc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78c3d0: LoadField: r9 = r4->field_7
    //     0x78c3d0: ldur            x9, [x4, #7]
    // 0x78c3d4: r3 = Null
    //     0x78c3d4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e7f0] Null
    //     0x78c3d8: ldr             x3, [x3, #0x7f0]
    // 0x78c3dc: blr             x9
    // 0x78c3e0: ldr             x1, [fp, #0x10]
    // 0x78c3e4: ldur            d0, [fp, #-0x20]
    // 0x78c3e8: ldur            x0, [fp, #-0x18]
    // 0x78c3ec: LoadField: d1 = r0->field_b
    //     0x78c3ec: ldur            d1, [x0, #0xb]
    // 0x78c3f0: LoadField: d2 = r1->field_77
    //     0x78c3f0: ldur            d2, [x1, #0x77]
    // 0x78c3f4: fdiv            d3, d1, d2
    // 0x78c3f8: fmul            d1, d0, d3
    // 0x78c3fc: mov             v0.16b, v1.16b
    // 0x78c400: ldur            x0, [fp, #-0x10]
    // 0x78c404: ldur            x2, [fp, #-8]
    // 0x78c408: b               #0x78c378
    // 0x78c40c: ldur            d0, [fp, #-0x20]
    // 0x78c410: LeaveFrame
    //     0x78c410: mov             SP, fp
    //     0x78c414: ldp             fp, lr, [SP], #0x10
    // 0x78c418: ret
    //     0x78c418: ret             
    // 0x78c41c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c41c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c420: b               #0x78c328
    // 0x78c424: r0 = StackOverflowSharedWithFPURegs()
    //     0x78c424: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x78c428: b               #0x78c388
  }
  get _ _pointerVerticalScaleFactor(/* No info */) {
    // ** addr: 0x78c42c, size: 0x80
    // 0x78c42c: EnterFrame
    //     0x78c42c: stp             fp, lr, [SP, #-0x10]!
    //     0x78c430: mov             fp, SP
    // 0x78c434: d1 = 0.000000
    //     0x78c434: eor             v1.16b, v1.16b, v1.16b
    // 0x78c438: ldr             x0, [fp, #0x10]
    // 0x78c43c: LoadField: r1 = r0->field_4f
    //     0x78c43c: ldur            w1, [x0, #0x4f]
    // 0x78c440: DecompressPointer r1
    //     0x78c440: add             x1, x1, HEAP, lsl #32
    // 0x78c444: r16 = Sentinel
    //     0x78c444: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78c448: cmp             w1, w16
    // 0x78c44c: b.eq            #0x78c494
    // 0x78c450: LoadField: d2 = r1->field_7
    //     0x78c450: ldur            d2, [x1, #7]
    // 0x78c454: fcmp            d2, d1
    // 0x78c458: b.vs            #0x78c484
    // 0x78c45c: b.le            #0x78c484
    // 0x78c460: LoadField: r1 = r0->field_53
    //     0x78c460: ldur            w1, [x0, #0x53]
    // 0x78c464: DecompressPointer r1
    //     0x78c464: add             x1, x1, HEAP, lsl #32
    // 0x78c468: r16 = Sentinel
    //     0x78c468: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78c46c: cmp             w1, w16
    // 0x78c470: b.eq            #0x78c4a0
    // 0x78c474: LoadField: d1 = r1->field_7
    //     0x78c474: ldur            d1, [x1, #7]
    // 0x78c478: fdiv            d3, d1, d2
    // 0x78c47c: mov             v0.16b, v3.16b
    // 0x78c480: b               #0x78c488
    // 0x78c484: d0 = 1.000000
    //     0x78c484: fmov            d0, #1.00000000
    // 0x78c488: LeaveFrame
    //     0x78c488: mov             SP, fp
    //     0x78c48c: ldp             fp, lr, [SP], #0x10
    // 0x78c490: ret
    //     0x78c490: ret             
    // 0x78c494: r9 = _initialVerticalSpan
    //     0x78c494: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e800] Field <ScaleGestureRecognizer._initialVerticalSpan@672213599>: late (offset: 0x50)
    //     0x78c498: ldr             x9, [x9, #0x800]
    // 0x78c49c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78c49c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78c4a0: r9 = _currentVerticalSpan
    //     0x78c4a0: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e48] Field <ScaleGestureRecognizer._currentVerticalSpan@672213599>: late (offset: 0x54)
    //     0x78c4a4: ldr             x9, [x9, #0xe48]
    // 0x78c4a8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78c4a8: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
  get _ _horizontalScaleFactor(/* No info */) {
    // ** addr: 0x78c4ac, size: 0x11c
    // 0x78c4ac: EnterFrame
    //     0x78c4ac: stp             fp, lr, [SP, #-0x10]!
    //     0x78c4b0: mov             fp, SP
    // 0x78c4b4: AllocStack(0x20)
    //     0x78c4b4: sub             SP, SP, #0x20
    // 0x78c4b8: CheckStackOverflow
    //     0x78c4b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78c4bc: cmp             SP, x16
    //     0x78c4c0: b.ls            #0x78c5b8
    // 0x78c4c4: ldr             x16, [fp, #0x10]
    // 0x78c4c8: SaveReg r16
    //     0x78c4c8: str             x16, [SP, #-8]!
    // 0x78c4cc: r0 = _pointerHorizontalScaleFactor()
    //     0x78c4cc: bl              #0x78c5c8  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerHorizontalScaleFactor
    // 0x78c4d0: add             SP, SP, #8
    // 0x78c4d4: ldr             x0, [fp, #0x10]
    // 0x78c4d8: stur            d0, [fp, #-0x20]
    // 0x78c4dc: LoadField: r1 = r0->field_73
    //     0x78c4dc: ldur            w1, [x0, #0x73]
    // 0x78c4e0: DecompressPointer r1
    //     0x78c4e0: add             x1, x1, HEAP, lsl #32
    // 0x78c4e4: SaveReg r1
    //     0x78c4e4: str             x1, [SP, #-8]!
    // 0x78c4e8: r0 = values()
    //     0x78c4e8: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x78c4ec: add             SP, SP, #8
    // 0x78c4f0: SaveReg r0
    //     0x78c4f0: str             x0, [SP, #-8]!
    // 0x78c4f4: r0 = iterator()
    //     0x78c4f4: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x78c4f8: add             SP, SP, #8
    // 0x78c4fc: stur            x0, [fp, #-0x10]
    // 0x78c500: LoadField: r2 = r0->field_7
    //     0x78c500: ldur            w2, [x0, #7]
    // 0x78c504: DecompressPointer r2
    //     0x78c504: add             x2, x2, HEAP, lsl #32
    // 0x78c508: stur            x2, [fp, #-8]
    // 0x78c50c: ldur            d0, [fp, #-0x20]
    // 0x78c510: ldr             x1, [fp, #0x10]
    // 0x78c514: stur            d0, [fp, #-0x20]
    // 0x78c518: CheckStackOverflow
    //     0x78c518: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78c51c: cmp             SP, x16
    //     0x78c520: b.ls            #0x78c5c0
    // 0x78c524: SaveReg r0
    //     0x78c524: str             x0, [SP, #-8]!
    // 0x78c528: r0 = moveNext()
    //     0x78c528: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78c52c: add             SP, SP, #8
    // 0x78c530: tbnz            w0, #4, #0x78c5a8
    // 0x78c534: ldur            x3, [fp, #-0x10]
    // 0x78c538: LoadField: r4 = r3->field_33
    //     0x78c538: ldur            w4, [x3, #0x33]
    // 0x78c53c: DecompressPointer r4
    //     0x78c53c: add             x4, x4, HEAP, lsl #32
    // 0x78c540: stur            x4, [fp, #-0x18]
    // 0x78c544: cmp             w4, NULL
    // 0x78c548: b.ne            #0x78c57c
    // 0x78c54c: mov             x0, x4
    // 0x78c550: ldur            x2, [fp, #-8]
    // 0x78c554: r1 = Null
    //     0x78c554: mov             x1, NULL
    // 0x78c558: cmp             w2, NULL
    // 0x78c55c: b.eq            #0x78c57c
    // 0x78c560: LoadField: r4 = r2->field_17
    //     0x78c560: ldur            w4, [x2, #0x17]
    // 0x78c564: DecompressPointer r4
    //     0x78c564: add             x4, x4, HEAP, lsl #32
    // 0x78c568: r8 = X0
    //     0x78c568: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78c56c: LoadField: r9 = r4->field_7
    //     0x78c56c: ldur            x9, [x4, #7]
    // 0x78c570: r3 = Null
    //     0x78c570: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e808] Null
    //     0x78c574: ldr             x3, [x3, #0x808]
    // 0x78c578: blr             x9
    // 0x78c57c: ldr             x1, [fp, #0x10]
    // 0x78c580: ldur            d0, [fp, #-0x20]
    // 0x78c584: ldur            x0, [fp, #-0x18]
    // 0x78c588: LoadField: d1 = r0->field_b
    //     0x78c588: ldur            d1, [x0, #0xb]
    // 0x78c58c: LoadField: d2 = r1->field_77
    //     0x78c58c: ldur            d2, [x1, #0x77]
    // 0x78c590: fdiv            d3, d1, d2
    // 0x78c594: fmul            d1, d0, d3
    // 0x78c598: mov             v0.16b, v1.16b
    // 0x78c59c: ldur            x0, [fp, #-0x10]
    // 0x78c5a0: ldur            x2, [fp, #-8]
    // 0x78c5a4: b               #0x78c514
    // 0x78c5a8: ldur            d0, [fp, #-0x20]
    // 0x78c5ac: LeaveFrame
    //     0x78c5ac: mov             SP, fp
    //     0x78c5b0: ldp             fp, lr, [SP], #0x10
    // 0x78c5b4: ret
    //     0x78c5b4: ret             
    // 0x78c5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78c5b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78c5bc: b               #0x78c4c4
    // 0x78c5c0: r0 = StackOverflowSharedWithFPURegs()
    //     0x78c5c0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x78c5c4: b               #0x78c524
  }
  get _ _pointerHorizontalScaleFactor(/* No info */) {
    // ** addr: 0x78c5c8, size: 0x80
    // 0x78c5c8: EnterFrame
    //     0x78c5c8: stp             fp, lr, [SP, #-0x10]!
    //     0x78c5cc: mov             fp, SP
    // 0x78c5d0: d1 = 0.000000
    //     0x78c5d0: eor             v1.16b, v1.16b, v1.16b
    // 0x78c5d4: ldr             x0, [fp, #0x10]
    // 0x78c5d8: LoadField: r1 = r0->field_47
    //     0x78c5d8: ldur            w1, [x0, #0x47]
    // 0x78c5dc: DecompressPointer r1
    //     0x78c5dc: add             x1, x1, HEAP, lsl #32
    // 0x78c5e0: r16 = Sentinel
    //     0x78c5e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78c5e4: cmp             w1, w16
    // 0x78c5e8: b.eq            #0x78c630
    // 0x78c5ec: LoadField: d2 = r1->field_7
    //     0x78c5ec: ldur            d2, [x1, #7]
    // 0x78c5f0: fcmp            d2, d1
    // 0x78c5f4: b.vs            #0x78c620
    // 0x78c5f8: b.le            #0x78c620
    // 0x78c5fc: LoadField: r1 = r0->field_4b
    //     0x78c5fc: ldur            w1, [x0, #0x4b]
    // 0x78c600: DecompressPointer r1
    //     0x78c600: add             x1, x1, HEAP, lsl #32
    // 0x78c604: r16 = Sentinel
    //     0x78c604: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78c608: cmp             w1, w16
    // 0x78c60c: b.eq            #0x78c63c
    // 0x78c610: LoadField: d1 = r1->field_7
    //     0x78c610: ldur            d1, [x1, #7]
    // 0x78c614: fdiv            d3, d1, d2
    // 0x78c618: mov             v0.16b, v3.16b
    // 0x78c61c: b               #0x78c624
    // 0x78c620: d0 = 1.000000
    //     0x78c620: fmov            d0, #1.00000000
    // 0x78c624: LeaveFrame
    //     0x78c624: mov             SP, fp
    //     0x78c628: ldp             fp, lr, [SP], #0x10
    // 0x78c62c: ret
    //     0x78c62c: ret             
    // 0x78c630: r9 = _initialHorizontalSpan
    //     0x78c630: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e818] Field <ScaleGestureRecognizer._initialHorizontalSpan@672213599>: late (offset: 0x48)
    //     0x78c634: ldr             x9, [x9, #0x818]
    // 0x78c638: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78c638: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78c63c: r9 = _currentHorizontalSpan
    //     0x78c63c: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e40] Field <ScaleGestureRecognizer._currentHorizontalSpan@672213599>: late (offset: 0x4c)
    //     0x78c640: ldr             x9, [x9, #0xe40]
    // 0x78c644: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78c644: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _reconfigure(/* No info */) {
    // ** addr: 0x78c648, size: 0x4b4
    // 0x78c648: EnterFrame
    //     0x78c648: stp             fp, lr, [SP, #-0x10]!
    //     0x78c64c: mov             fp, SP
    // 0x78c650: AllocStack(0x10)
    //     0x78c650: sub             SP, SP, #0x10
    // 0x78c654: CheckStackOverflow
    //     0x78c654: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78c658: cmp             SP, x16
    //     0x78c65c: b.ls            #0x78caac
    // 0x78c660: r1 = 2
    //     0x78c660: mov             x1, #2
    // 0x78c664: r0 = AllocateContext()
    //     0x78c664: bl              #0xd68aa4  ; AllocateContextStub
    // 0x78c668: mov             x2, x0
    // 0x78c66c: ldr             x1, [fp, #0x18]
    // 0x78c670: stur            x2, [fp, #-0x10]
    // 0x78c674: StoreField: r2->field_f = r1
    //     0x78c674: stur            w1, [x2, #0xf]
    // 0x78c678: LoadField: r0 = r1->field_3b
    //     0x78c678: ldur            w0, [x1, #0x3b]
    // 0x78c67c: DecompressPointer r0
    //     0x78c67c: add             x0, x0, HEAP, lsl #32
    // 0x78c680: cmp             w0, NULL
    // 0x78c684: b.eq            #0x78cab4
    // 0x78c688: StoreField: r1->field_37 = r0
    //     0x78c688: stur            w0, [x1, #0x37]
    //     0x78c68c: ldurb           w16, [x1, #-1]
    //     0x78c690: ldurb           w17, [x0, #-1]
    //     0x78c694: and             x16, x17, x16, lsr #2
    //     0x78c698: tst             x16, HEAP, lsr #32
    //     0x78c69c: b.eq            #0x78c6a4
    //     0x78c6a0: bl              #0xd6826c
    // 0x78c6a4: LoadField: r0 = r1->field_43
    //     0x78c6a4: ldur            w0, [x1, #0x43]
    // 0x78c6a8: DecompressPointer r0
    //     0x78c6a8: add             x0, x0, HEAP, lsl #32
    // 0x78c6ac: r16 = Sentinel
    //     0x78c6ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78c6b0: cmp             w0, w16
    // 0x78c6b4: b.eq            #0x78cab8
    // 0x78c6b8: StoreField: r1->field_3f = r0
    //     0x78c6b8: stur            w0, [x1, #0x3f]
    //     0x78c6bc: ldurb           w16, [x1, #-1]
    //     0x78c6c0: ldurb           w17, [x0, #-1]
    //     0x78c6c4: and             x16, x17, x16, lsr #2
    //     0x78c6c8: tst             x16, HEAP, lsr #32
    //     0x78c6cc: b.eq            #0x78c6d4
    //     0x78c6d0: bl              #0xd6826c
    // 0x78c6d4: LoadField: r0 = r1->field_5f
    //     0x78c6d4: ldur            w0, [x1, #0x5f]
    // 0x78c6d8: DecompressPointer r0
    //     0x78c6d8: add             x0, x0, HEAP, lsl #32
    // 0x78c6dc: StoreField: r1->field_5b = r0
    //     0x78c6dc: stur            w0, [x1, #0x5b]
    //     0x78c6e0: ldurb           w16, [x1, #-1]
    //     0x78c6e4: ldurb           w17, [x0, #-1]
    //     0x78c6e8: and             x16, x17, x16, lsr #2
    //     0x78c6ec: tst             x16, HEAP, lsr #32
    //     0x78c6f0: b.eq            #0x78c6f8
    //     0x78c6f4: bl              #0xd6826c
    // 0x78c6f8: LoadField: r0 = r1->field_4b
    //     0x78c6f8: ldur            w0, [x1, #0x4b]
    // 0x78c6fc: DecompressPointer r0
    //     0x78c6fc: add             x0, x0, HEAP, lsl #32
    // 0x78c700: r16 = Sentinel
    //     0x78c700: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78c704: cmp             w0, w16
    // 0x78c708: b.eq            #0x78cac4
    // 0x78c70c: StoreField: r1->field_47 = r0
    //     0x78c70c: stur            w0, [x1, #0x47]
    //     0x78c710: ldurb           w16, [x1, #-1]
    //     0x78c714: ldurb           w17, [x0, #-1]
    //     0x78c718: and             x16, x17, x16, lsr #2
    //     0x78c71c: tst             x16, HEAP, lsr #32
    //     0x78c720: b.eq            #0x78c728
    //     0x78c724: bl              #0xd6826c
    // 0x78c728: LoadField: r0 = r1->field_53
    //     0x78c728: ldur            w0, [x1, #0x53]
    // 0x78c72c: DecompressPointer r0
    //     0x78c72c: add             x0, x0, HEAP, lsl #32
    // 0x78c730: r16 = Sentinel
    //     0x78c730: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78c734: cmp             w0, w16
    // 0x78c738: b.eq            #0x78cad0
    // 0x78c73c: StoreField: r1->field_4f = r0
    //     0x78c73c: stur            w0, [x1, #0x4f]
    //     0x78c740: ldurb           w16, [x1, #-1]
    //     0x78c744: ldurb           w17, [x0, #-1]
    //     0x78c748: and             x16, x17, x16, lsr #2
    //     0x78c74c: tst             x16, HEAP, lsr #32
    //     0x78c750: b.eq            #0x78c758
    //     0x78c754: bl              #0xd6826c
    // 0x78c758: LoadField: r0 = r1->field_73
    //     0x78c758: ldur            w0, [x1, #0x73]
    // 0x78c75c: DecompressPointer r0
    //     0x78c75c: add             x0, x0, HEAP, lsl #32
    // 0x78c760: stur            x0, [fp, #-8]
    // 0x78c764: LoadField: r3 = r0->field_13
    //     0x78c764: ldur            w3, [x0, #0x13]
    // 0x78c768: DecompressPointer r3
    //     0x78c768: add             x3, x3, HEAP, lsl #32
    // 0x78c76c: r4 = LoadInt32Instr(r3)
    //     0x78c76c: sbfx            x4, x3, #1, #0x1f
    // 0x78c770: asr             x3, x4, #1
    // 0x78c774: LoadField: r4 = r0->field_17
    //     0x78c774: ldur            w4, [x0, #0x17]
    // 0x78c778: DecompressPointer r4
    //     0x78c778: add             x4, x4, HEAP, lsl #32
    // 0x78c77c: r5 = LoadInt32Instr(r4)
    //     0x78c77c: sbfx            x5, x4, #1, #0x1f
    // 0x78c780: sub             x4, x3, x5
    // 0x78c784: cbnz            x4, #0x78c7a0
    // 0x78c788: d1 = 1.000000
    //     0x78c788: fmov            d1, #1.00000000
    // 0x78c78c: d0 = 0.000000
    //     0x78c78c: eor             v0.16b, v0.16b, v0.16b
    // 0x78c790: StoreField: r1->field_77 = d1
    //     0x78c790: stur            d1, [x1, #0x77]
    // 0x78c794: StoreField: r1->field_7f = d0
    //     0x78c794: stur            d0, [x1, #0x7f]
    // 0x78c798: mov             x2, x1
    // 0x78c79c: b               #0x78c864
    // 0x78c7a0: d0 = 0.000000
    //     0x78c7a0: eor             v0.16b, v0.16b, v0.16b
    // 0x78c7a4: SaveReg r1
    //     0x78c7a4: str             x1, [SP, #-8]!
    // 0x78c7a8: r0 = _scaleFactor()
    //     0x78c7a8: bl              #0x78bdb0  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0x78c7ac: add             SP, SP, #8
    // 0x78c7b0: ldr             x0, [fp, #0x18]
    // 0x78c7b4: LoadField: r1 = r0->field_3f
    //     0x78c7b4: ldur            w1, [x0, #0x3f]
    // 0x78c7b8: DecompressPointer r1
    //     0x78c7b8: add             x1, x1, HEAP, lsl #32
    // 0x78c7bc: LoadField: d1 = r1->field_7
    //     0x78c7bc: ldur            d1, [x1, #7]
    // 0x78c7c0: d2 = 0.000000
    //     0x78c7c0: eor             v2.16b, v2.16b, v2.16b
    // 0x78c7c4: fcmp            d1, d2
    // 0x78c7c8: b.vs            #0x78c7e8
    // 0x78c7cc: b.le            #0x78c7e8
    // 0x78c7d0: LoadField: r1 = r0->field_43
    //     0x78c7d0: ldur            w1, [x0, #0x43]
    // 0x78c7d4: DecompressPointer r1
    //     0x78c7d4: add             x1, x1, HEAP, lsl #32
    // 0x78c7d8: LoadField: d2 = r1->field_7
    //     0x78c7d8: ldur            d2, [x1, #7]
    // 0x78c7dc: fdiv            d3, d2, d1
    // 0x78c7e0: mov             v1.16b, v3.16b
    // 0x78c7e4: b               #0x78c7ec
    // 0x78c7e8: d1 = 1.000000
    //     0x78c7e8: fmov            d1, #1.00000000
    // 0x78c7ec: fdiv            d2, d0, d1
    // 0x78c7f0: StoreField: r0->field_77 = d2
    //     0x78c7f0: stur            d2, [x0, #0x77]
    // 0x78c7f4: ldur            x16, [fp, #-8]
    // 0x78c7f8: SaveReg r16
    //     0x78c7f8: str             x16, [SP, #-8]!
    // 0x78c7fc: r0 = values()
    //     0x78c7fc: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x78c800: add             SP, SP, #8
    // 0x78c804: r1 = Function '<anonymous closure>':.
    //     0x78c804: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e820] AnonymousClosure: (0x78ced8), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::acceptGesture (0xbdbe38)
    //     0x78c808: ldr             x1, [x1, #0x820]
    // 0x78c80c: r2 = Null
    //     0x78c80c: mov             x2, NULL
    // 0x78c810: stur            x0, [fp, #-8]
    // 0x78c814: r0 = AllocateClosure()
    //     0x78c814: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x78c818: r16 = <double>
    //     0x78c818: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x78c81c: ldur            lr, [fp, #-8]
    // 0x78c820: stp             lr, x16, [SP, #-0x10]!
    // 0x78c824: SaveReg r0
    //     0x78c824: str             x0, [SP, #-8]!
    // 0x78c828: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x78c828: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78c82c: r0 = map()
    //     0x78c82c: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0x78c830: add             SP, SP, #0x18
    // 0x78c834: r1 = Function '<anonymous closure>':.
    //     0x78c834: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e828] AnonymousClosure: (0x70410c), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::acceptGesture (0xbdbe38)
    //     0x78c838: ldr             x1, [x1, #0x828]
    // 0x78c83c: r2 = Null
    //     0x78c83c: mov             x2, NULL
    // 0x78c840: stur            x0, [fp, #-8]
    // 0x78c844: r0 = AllocateClosure()
    //     0x78c844: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x78c848: ldur            x16, [fp, #-8]
    // 0x78c84c: stp             x0, x16, [SP, #-0x10]!
    // 0x78c850: r0 = reduce()
    //     0x78c850: bl              #0x78cb5c  ; [dart:core] Iterable::reduce
    // 0x78c854: add             SP, SP, #0x10
    // 0x78c858: LoadField: d0 = r0->field_7
    //     0x78c858: ldur            d0, [x0, #7]
    // 0x78c85c: ldr             x2, [fp, #0x18]
    // 0x78c860: StoreField: r2->field_7f = d0
    //     0x78c860: stur            d0, [x2, #0x7f]
    // 0x78c864: LoadField: r0 = r2->field_2f
    //     0x78c864: ldur            w0, [x2, #0x2f]
    // 0x78c868: DecompressPointer r0
    //     0x78c868: add             x0, x0, HEAP, lsl #32
    // 0x78c86c: r16 = Instance__ScaleState
    //     0x78c86c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e20] Obj!_ScaleState@b65a71
    //     0x78c870: ldr             x16, [x16, #0xe20]
    // 0x78c874: cmp             w0, w16
    // 0x78c878: b.ne            #0x78ca9c
    // 0x78c87c: LoadField: r0 = r2->field_2b
    //     0x78c87c: ldur            w0, [x2, #0x2b]
    // 0x78c880: DecompressPointer r0
    //     0x78c880: add             x0, x0, HEAP, lsl #32
    // 0x78c884: cmp             w0, NULL
    // 0x78c888: b.eq            #0x78ca7c
    // 0x78c88c: ldr             x3, [fp, #0x10]
    // 0x78c890: LoadField: r4 = r2->field_6b
    //     0x78c890: ldur            w4, [x2, #0x6b]
    // 0x78c894: DecompressPointer r4
    //     0x78c894: add             x4, x4, HEAP, lsl #32
    // 0x78c898: stur            x4, [fp, #-8]
    // 0x78c89c: r0 = BoxInt64Instr(r3)
    //     0x78c89c: sbfiz           x0, x3, #1, #0x1f
    //     0x78c8a0: cmp             x3, x0, asr #1
    //     0x78c8a4: b.eq            #0x78c8b0
    //     0x78c8a8: bl              #0xd69bb8
    //     0x78c8ac: stur            x3, [x0, #7]
    // 0x78c8b0: stp             x0, x4, [SP, #-0x10]!
    // 0x78c8b4: r0 = _getValueOrData()
    //     0x78c8b4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78c8b8: add             SP, SP, #0x10
    // 0x78c8bc: mov             x1, x0
    // 0x78c8c0: ldur            x0, [fp, #-8]
    // 0x78c8c4: LoadField: r2 = r0->field_f
    //     0x78c8c4: ldur            w2, [x0, #0xf]
    // 0x78c8c8: DecompressPointer r2
    //     0x78c8c8: add             x2, x2, HEAP, lsl #32
    // 0x78c8cc: cmp             w2, w1
    // 0x78c8d0: b.ne            #0x78c8dc
    // 0x78c8d4: r0 = Null
    //     0x78c8d4: mov             x0, NULL
    // 0x78c8d8: b               #0x78c8e0
    // 0x78c8dc: mov             x0, x1
    // 0x78c8e0: ldur            x2, [fp, #-0x10]
    // 0x78c8e4: cmp             w0, NULL
    // 0x78c8e8: b.eq            #0x78cadc
    // 0x78c8ec: r1 = LoadClassIdInstr(r0)
    //     0x78c8ec: ldur            x1, [x0, #-1]
    //     0x78c8f0: ubfx            x1, x1, #0xc, #0x14
    // 0x78c8f4: SaveReg r0
    //     0x78c8f4: str             x0, [SP, #-8]!
    // 0x78c8f8: mov             x0, x1
    // 0x78c8fc: r0 = GDT[cid_x0 + 0x92c]()
    //     0x78c8fc: add             lr, x0, #0x92c
    //     0x78c900: ldr             lr, [x21, lr, lsl #3]
    //     0x78c904: blr             lr
    // 0x78c908: add             SP, SP, #8
    // 0x78c90c: mov             x1, x0
    // 0x78c910: ldur            x2, [fp, #-0x10]
    // 0x78c914: StoreField: r2->field_13 = r0
    //     0x78c914: stur            w0, [x2, #0x13]
    //     0x78c918: ldurb           w16, [x2, #-1]
    //     0x78c91c: ldurb           w17, [x0, #-1]
    //     0x78c920: and             x16, x17, x16, lsr #2
    //     0x78c924: tst             x16, HEAP, lsr #32
    //     0x78c928: b.eq            #0x78c930
    //     0x78c92c: bl              #0xd6828c
    // 0x78c930: SaveReg r1
    //     0x78c930: str             x1, [SP, #-8]!
    // 0x78c934: r0 = _isFlingGesture()
    //     0x78c934: bl              #0x78cb18  ; [package:flutter/src/gestures/scale.dart] ::_isFlingGesture
    // 0x78c938: add             SP, SP, #8
    // 0x78c93c: tbnz            w0, #4, #0x78ca50
    // 0x78c940: ldur            x2, [fp, #-0x10]
    // 0x78c944: LoadField: r0 = r2->field_13
    //     0x78c944: ldur            w0, [x2, #0x13]
    // 0x78c948: DecompressPointer r0
    //     0x78c948: add             x0, x0, HEAP, lsl #32
    // 0x78c94c: LoadField: r1 = r0->field_7
    //     0x78c94c: ldur            w1, [x0, #7]
    // 0x78c950: DecompressPointer r1
    //     0x78c950: add             x1, x1, HEAP, lsl #32
    // 0x78c954: stur            x1, [fp, #-8]
    // 0x78c958: SaveReg r1
    //     0x78c958: str             x1, [SP, #-8]!
    // 0x78c95c: r0 = distanceSquared()
    //     0x78c95c: bl              #0x78cafc  ; [dart:ui] Offset::distanceSquared
    // 0x78c960: add             SP, SP, #8
    // 0x78c964: mov             v1.16b, v0.16b
    // 0x78c968: d0 = 64000000.000000
    //     0x78c968: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e830] IMM: double(6.4e+07) from 0x418e848000000000
    //     0x78c96c: ldr             d0, [x17, #0x830]
    // 0x78c970: fcmp            d1, d0
    // 0x78c974: b.vs            #0x78ca20
    // 0x78c978: b.le            #0x78ca20
    // 0x78c97c: ldur            x2, [fp, #-0x10]
    // 0x78c980: ldur            x0, [fp, #-8]
    // 0x78c984: LoadField: d0 = r0->field_7
    //     0x78c984: ldur            d0, [x0, #7]
    // 0x78c988: fmul            d1, d0, d0
    // 0x78c98c: LoadField: d0 = r0->field_f
    //     0x78c98c: ldur            d0, [x0, #0xf]
    // 0x78c990: fmul            d2, d0, d0
    // 0x78c994: fadd            d0, d1, d2
    // 0x78c998: fsqrt           d1, d0
    // 0x78c99c: r1 = inline_Allocate_Double()
    //     0x78c99c: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x78c9a0: add             x1, x1, #0x10
    //     0x78c9a4: cmp             x3, x1
    //     0x78c9a8: b.ls            #0x78cae0
    //     0x78c9ac: str             x1, [THR, #0x60]  ; THR::top
    //     0x78c9b0: sub             x1, x1, #0xf
    //     0x78c9b4: mov             x3, #0xd108
    //     0x78c9b8: movk            x3, #3, lsl #16
    //     0x78c9bc: stur            x3, [x1, #-1]
    // 0x78c9c0: StoreField: r1->field_7 = d1
    //     0x78c9c0: stur            d1, [x1, #7]
    // 0x78c9c4: stp             x1, x0, [SP, #-0x10]!
    // 0x78c9c8: r0 = /()
    //     0x78c9c8: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x78c9cc: add             SP, SP, #0x10
    // 0x78c9d0: r16 = 8000.000000
    //     0x78c9d0: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e838] 8000
    //     0x78c9d4: ldr             x16, [x16, #0x838]
    // 0x78c9d8: stp             x16, x0, [SP, #-0x10]!
    // 0x78c9dc: r0 = *()
    //     0x78c9dc: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x78c9e0: add             SP, SP, #0x10
    // 0x78c9e4: stur            x0, [fp, #-8]
    // 0x78c9e8: r0 = Velocity()
    //     0x78c9e8: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x78c9ec: mov             x1, x0
    // 0x78c9f0: ldur            x0, [fp, #-8]
    // 0x78c9f4: StoreField: r1->field_7 = r0
    //     0x78c9f4: stur            w0, [x1, #7]
    // 0x78c9f8: mov             x0, x1
    // 0x78c9fc: ldur            x2, [fp, #-0x10]
    // 0x78ca00: StoreField: r2->field_13 = r0
    //     0x78ca00: stur            w0, [x2, #0x13]
    //     0x78ca04: ldurb           w16, [x2, #-1]
    //     0x78ca08: ldurb           w17, [x0, #-1]
    //     0x78ca0c: and             x16, x17, x16, lsr #2
    //     0x78ca10: tst             x16, HEAP, lsr #32
    //     0x78ca14: b.eq            #0x78ca1c
    //     0x78ca18: bl              #0xd6828c
    // 0x78ca1c: b               #0x78ca24
    // 0x78ca20: ldur            x2, [fp, #-0x10]
    // 0x78ca24: r1 = Function '<anonymous closure>':.
    //     0x78ca24: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e840] AnonymousClosure: (0x78ce30), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0x78c648)
    //     0x78ca28: ldr             x1, [x1, #0x840]
    // 0x78ca2c: r0 = AllocateClosure()
    //     0x78ca2c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x78ca30: r16 = <void?>
    //     0x78ca30: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x78ca34: ldr             lr, [fp, #0x18]
    // 0x78ca38: stp             lr, x16, [SP, #-0x10]!
    // 0x78ca3c: SaveReg r0
    //     0x78ca3c: str             x0, [SP, #-8]!
    // 0x78ca40: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x78ca40: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78ca44: r0 = invokeCallback()
    //     0x78ca44: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x78ca48: add             SP, SP, #0x18
    // 0x78ca4c: b               #0x78ca7c
    // 0x78ca50: ldur            x2, [fp, #-0x10]
    // 0x78ca54: r1 = Function '<anonymous closure>':.
    //     0x78ca54: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e848] AnonymousClosure: (0x78cd84), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0x78c648)
    //     0x78ca58: ldr             x1, [x1, #0x848]
    // 0x78ca5c: r0 = AllocateClosure()
    //     0x78ca5c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x78ca60: r16 = <void?>
    //     0x78ca60: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x78ca64: ldr             lr, [fp, #0x18]
    // 0x78ca68: stp             lr, x16, [SP, #-0x10]!
    // 0x78ca6c: SaveReg r0
    //     0x78ca6c: str             x0, [SP, #-8]!
    // 0x78ca70: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x78ca70: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78ca74: r0 = invokeCallback()
    //     0x78ca74: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x78ca78: add             SP, SP, #0x18
    // 0x78ca7c: ldr             x1, [fp, #0x18]
    // 0x78ca80: r2 = Instance__ScaleState
    //     0x78ca80: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e7c0] Obj!_ScaleState@b65a51
    //     0x78ca84: ldr             x2, [x2, #0x7c0]
    // 0x78ca88: StoreField: r1->field_2f = r2
    //     0x78ca88: stur            w2, [x1, #0x2f]
    // 0x78ca8c: r0 = false
    //     0x78ca8c: add             x0, NULL, #0x30  ; false
    // 0x78ca90: LeaveFrame
    //     0x78ca90: mov             SP, fp
    //     0x78ca94: ldp             fp, lr, [SP], #0x10
    // 0x78ca98: ret
    //     0x78ca98: ret             
    // 0x78ca9c: r0 = true
    //     0x78ca9c: add             x0, NULL, #0x20  ; true
    // 0x78caa0: LeaveFrame
    //     0x78caa0: mov             SP, fp
    //     0x78caa4: ldp             fp, lr, [SP], #0x10
    // 0x78caa8: ret
    //     0x78caa8: ret             
    // 0x78caac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78caac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78cab0: b               #0x78c660
    // 0x78cab4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78cab4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78cab8: r9 = _currentSpan
    //     0x78cab8: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e38] Field <ScaleGestureRecognizer._currentSpan@672213599>: late (offset: 0x44)
    //     0x78cabc: ldr             x9, [x9, #0xe38]
    // 0x78cac0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78cac0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x78cac4: r9 = _currentHorizontalSpan
    //     0x78cac4: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e40] Field <ScaleGestureRecognizer._currentHorizontalSpan@672213599>: late (offset: 0x4c)
    //     0x78cac8: ldr             x9, [x9, #0xe40]
    // 0x78cacc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78cacc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x78cad0: r9 = _currentVerticalSpan
    //     0x78cad0: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e48] Field <ScaleGestureRecognizer._currentVerticalSpan@672213599>: late (offset: 0x54)
    //     0x78cad4: ldr             x9, [x9, #0xe48]
    // 0x78cad8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78cad8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x78cadc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78cadc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78cae0: SaveReg d1
    //     0x78cae0: str             q1, [SP, #-0x10]!
    // 0x78cae4: stp             x0, x2, [SP, #-0x10]!
    // 0x78cae8: r0 = AllocateDouble()
    //     0x78cae8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78caec: mov             x1, x0
    // 0x78caf0: ldp             x0, x2, [SP], #0x10
    // 0x78caf4: RestoreReg d1
    //     0x78caf4: ldr             q1, [SP], #0x10
    // 0x78caf8: b               #0x78c9c0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x78cd84, size: 0xa0
    // 0x78cd84: EnterFrame
    //     0x78cd84: stp             fp, lr, [SP, #-0x10]!
    //     0x78cd88: mov             fp, SP
    // 0x78cd8c: AllocStack(0x10)
    //     0x78cd8c: sub             SP, SP, #0x10
    // 0x78cd90: SetupParameters()
    //     0x78cd90: ldr             x0, [fp, #0x10]
    //     0x78cd94: ldur            w1, [x0, #0x17]
    //     0x78cd98: add             x1, x1, HEAP, lsl #32
    // 0x78cd9c: CheckStackOverflow
    //     0x78cd9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78cda0: cmp             SP, x16
    //     0x78cda4: b.ls            #0x78ce18
    // 0x78cda8: LoadField: r0 = r1->field_f
    //     0x78cda8: ldur            w0, [x1, #0xf]
    // 0x78cdac: DecompressPointer r0
    //     0x78cdac: add             x0, x0, HEAP, lsl #32
    // 0x78cdb0: LoadField: r1 = r0->field_2b
    //     0x78cdb0: ldur            w1, [x0, #0x2b]
    // 0x78cdb4: DecompressPointer r1
    //     0x78cdb4: add             x1, x1, HEAP, lsl #32
    // 0x78cdb8: stur            x1, [fp, #-8]
    // 0x78cdbc: cmp             w1, NULL
    // 0x78cdc0: b.eq            #0x78ce20
    // 0x78cdc4: SaveReg r0
    //     0x78cdc4: str             x0, [SP, #-8]!
    // 0x78cdc8: r0 = _pointerCount()
    //     0x78cdc8: bl              #0x78bd58  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerCount
    // 0x78cdcc: add             SP, SP, #8
    // 0x78cdd0: stur            x0, [fp, #-0x10]
    // 0x78cdd4: r0 = ScaleEndDetails()
    //     0x78cdd4: bl              #0x78ce24  ; AllocateScaleEndDetailsStub -> ScaleEndDetails (size=0x14)
    // 0x78cdd8: mov             x1, x0
    // 0x78cddc: r0 = Instance_Velocity
    //     0x78cddc: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0x78cde0: ldr             x0, [x0, #0x850]
    // 0x78cde4: StoreField: r1->field_7 = r0
    //     0x78cde4: stur            w0, [x1, #7]
    // 0x78cde8: ldur            x0, [fp, #-0x10]
    // 0x78cdec: StoreField: r1->field_b = r0
    //     0x78cdec: stur            x0, [x1, #0xb]
    // 0x78cdf0: ldur            x16, [fp, #-8]
    // 0x78cdf4: stp             x1, x16, [SP, #-0x10]!
    // 0x78cdf8: ldur            x0, [fp, #-8]
    // 0x78cdfc: ClosureCall
    //     0x78cdfc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x78ce00: ldur            x2, [x0, #0x1f]
    //     0x78ce04: blr             x2
    // 0x78ce08: add             SP, SP, #0x10
    // 0x78ce0c: LeaveFrame
    //     0x78ce0c: mov             SP, fp
    //     0x78ce10: ldp             fp, lr, [SP], #0x10
    // 0x78ce14: ret
    //     0x78ce14: ret             
    // 0x78ce18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78ce18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78ce1c: b               #0x78cda8
    // 0x78ce20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78ce20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x78ce30, size: 0xa8
    // 0x78ce30: EnterFrame
    //     0x78ce30: stp             fp, lr, [SP, #-0x10]!
    //     0x78ce34: mov             fp, SP
    // 0x78ce38: AllocStack(0x18)
    //     0x78ce38: sub             SP, SP, #0x18
    // 0x78ce3c: SetupParameters()
    //     0x78ce3c: ldr             x0, [fp, #0x10]
    //     0x78ce40: ldur            w1, [x0, #0x17]
    //     0x78ce44: add             x1, x1, HEAP, lsl #32
    // 0x78ce48: CheckStackOverflow
    //     0x78ce48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78ce4c: cmp             SP, x16
    //     0x78ce50: b.ls            #0x78cecc
    // 0x78ce54: LoadField: r0 = r1->field_f
    //     0x78ce54: ldur            w0, [x1, #0xf]
    // 0x78ce58: DecompressPointer r0
    //     0x78ce58: add             x0, x0, HEAP, lsl #32
    // 0x78ce5c: LoadField: r2 = r0->field_2b
    //     0x78ce5c: ldur            w2, [x0, #0x2b]
    // 0x78ce60: DecompressPointer r2
    //     0x78ce60: add             x2, x2, HEAP, lsl #32
    // 0x78ce64: stur            x2, [fp, #-0x10]
    // 0x78ce68: cmp             w2, NULL
    // 0x78ce6c: b.eq            #0x78ced4
    // 0x78ce70: LoadField: r3 = r1->field_13
    //     0x78ce70: ldur            w3, [x1, #0x13]
    // 0x78ce74: DecompressPointer r3
    //     0x78ce74: add             x3, x3, HEAP, lsl #32
    // 0x78ce78: stur            x3, [fp, #-8]
    // 0x78ce7c: SaveReg r0
    //     0x78ce7c: str             x0, [SP, #-8]!
    // 0x78ce80: r0 = _pointerCount()
    //     0x78ce80: bl              #0x78bd58  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerCount
    // 0x78ce84: add             SP, SP, #8
    // 0x78ce88: stur            x0, [fp, #-0x18]
    // 0x78ce8c: r0 = ScaleEndDetails()
    //     0x78ce8c: bl              #0x78ce24  ; AllocateScaleEndDetailsStub -> ScaleEndDetails (size=0x14)
    // 0x78ce90: mov             x1, x0
    // 0x78ce94: ldur            x0, [fp, #-8]
    // 0x78ce98: StoreField: r1->field_7 = r0
    //     0x78ce98: stur            w0, [x1, #7]
    // 0x78ce9c: ldur            x0, [fp, #-0x18]
    // 0x78cea0: StoreField: r1->field_b = r0
    //     0x78cea0: stur            x0, [x1, #0xb]
    // 0x78cea4: ldur            x16, [fp, #-0x10]
    // 0x78cea8: stp             x1, x16, [SP, #-0x10]!
    // 0x78ceac: ldur            x0, [fp, #-0x10]
    // 0x78ceb0: ClosureCall
    //     0x78ceb0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x78ceb4: ldur            x2, [x0, #0x1f]
    //     0x78ceb8: blr             x2
    // 0x78cebc: add             SP, SP, #0x10
    // 0x78cec0: LeaveFrame
    //     0x78cec0: mov             SP, fp
    //     0x78cec4: ldp             fp, lr, [SP], #0x10
    // 0x78cec8: ret
    //     0x78cec8: ret             
    // 0x78cecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78cecc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78ced0: b               #0x78ce54
    // 0x78ced4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78ced4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double <anonymous closure>(dynamic, _PointerPanZoomData) {
    // ** addr: 0x78ced8, size: 0x54
    // 0x78ced8: EnterFrame
    //     0x78ced8: stp             fp, lr, [SP, #-0x10]!
    //     0x78cedc: mov             fp, SP
    // 0x78cee0: ldr             x1, [fp, #0x10]
    // 0x78cee4: LoadField: d0 = r1->field_13
    //     0x78cee4: ldur            d0, [x1, #0x13]
    // 0x78cee8: r0 = inline_Allocate_Double()
    //     0x78cee8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x78ceec: add             x0, x0, #0x10
    //     0x78cef0: cmp             x1, x0
    //     0x78cef4: b.ls            #0x78cf1c
    //     0x78cef8: str             x0, [THR, #0x60]  ; THR::top
    //     0x78cefc: sub             x0, x0, #0xf
    //     0x78cf00: mov             x1, #0xd108
    //     0x78cf04: movk            x1, #3, lsl #16
    //     0x78cf08: stur            x1, [x0, #-1]
    // 0x78cf0c: StoreField: r0->field_7 = d0
    //     0x78cf0c: stur            d0, [x0, #7]
    // 0x78cf10: LeaveFrame
    //     0x78cf10: mov             SP, fp
    //     0x78cf14: ldp             fp, lr, [SP], #0x10
    // 0x78cf18: ret
    //     0x78cf18: ret             
    // 0x78cf1c: SaveReg d0
    //     0x78cf1c: str             q0, [SP, #-0x10]!
    // 0x78cf20: r0 = AllocateDouble()
    //     0x78cf20: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78cf24: RestoreReg d0
    //     0x78cf24: ldr             q0, [SP], #0x10
    // 0x78cf28: b               #0x78cf0c
  }
  _ _update(/* No info */) {
    // ** addr: 0x78cf4c, size: 0x988
    // 0x78cf4c: EnterFrame
    //     0x78cf4c: stp             fp, lr, [SP, #-0x10]!
    //     0x78cf50: mov             fp, SP
    // 0x78cf54: AllocStack(0x70)
    //     0x78cf54: sub             SP, SP, #0x70
    // 0x78cf58: CheckStackOverflow
    //     0x78cf58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78cf5c: cmp             SP, x16
    //     0x78cf60: b.ls            #0x78d82c
    // 0x78cf64: ldr             x0, [fp, #0x10]
    // 0x78cf68: LoadField: r1 = r0->field_3b
    //     0x78cf68: ldur            w1, [x0, #0x3b]
    // 0x78cf6c: DecompressPointer r1
    //     0x78cf6c: add             x1, x1, HEAP, lsl #32
    // 0x78cf70: stur            x1, [fp, #-0x10]
    // 0x78cf74: LoadField: r2 = r0->field_63
    //     0x78cf74: ldur            w2, [x0, #0x63]
    // 0x78cf78: DecompressPointer r2
    //     0x78cf78: add             x2, x2, HEAP, lsl #32
    // 0x78cf7c: stur            x2, [fp, #-8]
    // 0x78cf80: SaveReg r2
    //     0x78cf80: str             x2, [SP, #-8]!
    // 0x78cf84: r0 = keys()
    //     0x78cf84: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x78cf88: add             SP, SP, #8
    // 0x78cf8c: SaveReg r0
    //     0x78cf8c: str             x0, [SP, #-8]!
    // 0x78cf90: r0 = iterator()
    //     0x78cf90: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x78cf94: add             SP, SP, #8
    // 0x78cf98: stur            x0, [fp, #-0x28]
    // 0x78cf9c: LoadField: r2 = r0->field_7
    //     0x78cf9c: ldur            w2, [x0, #7]
    // 0x78cfa0: DecompressPointer r2
    //     0x78cfa0: add             x2, x2, HEAP, lsl #32
    // 0x78cfa4: stur            x2, [fp, #-0x20]
    // 0x78cfa8: r3 = Instance_Offset
    //     0x78cfa8: ldr             x3, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x78cfac: ldur            x1, [fp, #-8]
    // 0x78cfb0: stur            x3, [fp, #-0x18]
    // 0x78cfb4: CheckStackOverflow
    //     0x78cfb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78cfb8: cmp             SP, x16
    //     0x78cfbc: b.ls            #0x78d834
    // 0x78cfc0: SaveReg r0
    //     0x78cfc0: str             x0, [SP, #-8]!
    // 0x78cfc4: r0 = moveNext()
    //     0x78cfc4: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78cfc8: add             SP, SP, #8
    // 0x78cfcc: tbnz            w0, #4, #0x78d0a0
    // 0x78cfd0: ldur            x3, [fp, #-0x28]
    // 0x78cfd4: LoadField: r4 = r3->field_33
    //     0x78cfd4: ldur            w4, [x3, #0x33]
    // 0x78cfd8: DecompressPointer r4
    //     0x78cfd8: add             x4, x4, HEAP, lsl #32
    // 0x78cfdc: stur            x4, [fp, #-0x30]
    // 0x78cfe0: cmp             w4, NULL
    // 0x78cfe4: b.ne            #0x78d018
    // 0x78cfe8: mov             x0, x4
    // 0x78cfec: ldur            x2, [fp, #-0x20]
    // 0x78cff0: r1 = Null
    //     0x78cff0: mov             x1, NULL
    // 0x78cff4: cmp             w2, NULL
    // 0x78cff8: b.eq            #0x78d018
    // 0x78cffc: LoadField: r4 = r2->field_17
    //     0x78cffc: ldur            w4, [x2, #0x17]
    // 0x78d000: DecompressPointer r4
    //     0x78d000: add             x4, x4, HEAP, lsl #32
    // 0x78d004: r8 = X0
    //     0x78d004: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78d008: LoadField: r9 = r4->field_7
    //     0x78d008: ldur            x9, [x4, #7]
    // 0x78d00c: r3 = Null
    //     0x78d00c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e860] Null
    //     0x78d010: ldr             x3, [x3, #0x860]
    // 0x78d014: blr             x9
    // 0x78d018: ldur            x0, [fp, #-8]
    // 0x78d01c: ldur            x16, [fp, #-0x30]
    // 0x78d020: stp             x16, x0, [SP, #-0x10]!
    // 0x78d024: r0 = _getValueOrData()
    //     0x78d024: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78d028: add             SP, SP, #0x10
    // 0x78d02c: mov             x1, x0
    // 0x78d030: ldur            x0, [fp, #-8]
    // 0x78d034: LoadField: r2 = r0->field_f
    //     0x78d034: ldur            w2, [x0, #0xf]
    // 0x78d038: DecompressPointer r2
    //     0x78d038: add             x2, x2, HEAP, lsl #32
    // 0x78d03c: cmp             w2, w1
    // 0x78d040: b.ne            #0x78d04c
    // 0x78d044: r2 = Null
    //     0x78d044: mov             x2, NULL
    // 0x78d048: b               #0x78d050
    // 0x78d04c: mov             x2, x1
    // 0x78d050: ldur            x1, [fp, #-0x18]
    // 0x78d054: cmp             w2, NULL
    // 0x78d058: b.eq            #0x78d83c
    // 0x78d05c: LoadField: d0 = r1->field_7
    //     0x78d05c: ldur            d0, [x1, #7]
    // 0x78d060: LoadField: d1 = r2->field_7
    //     0x78d060: ldur            d1, [x2, #7]
    // 0x78d064: fadd            d2, d0, d1
    // 0x78d068: stur            d2, [fp, #-0x48]
    // 0x78d06c: LoadField: d0 = r1->field_f
    //     0x78d06c: ldur            d0, [x1, #0xf]
    // 0x78d070: LoadField: d1 = r2->field_f
    //     0x78d070: ldur            d1, [x2, #0xf]
    // 0x78d074: fadd            d3, d0, d1
    // 0x78d078: stur            d3, [fp, #-0x40]
    // 0x78d07c: r0 = Offset()
    //     0x78d07c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x78d080: ldur            d0, [fp, #-0x48]
    // 0x78d084: StoreField: r0->field_7 = d0
    //     0x78d084: stur            d0, [x0, #7]
    // 0x78d088: ldur            d0, [fp, #-0x40]
    // 0x78d08c: StoreField: r0->field_f = d0
    //     0x78d08c: stur            d0, [x0, #0xf]
    // 0x78d090: mov             x3, x0
    // 0x78d094: ldur            x0, [fp, #-0x28]
    // 0x78d098: ldur            x2, [fp, #-0x20]
    // 0x78d09c: b               #0x78cfac
    // 0x78d0a0: ldr             x0, [fp, #0x10]
    // 0x78d0a4: ldur            x1, [fp, #-0x18]
    // 0x78d0a8: LoadField: r2 = r0->field_73
    //     0x78d0a8: ldur            w2, [x0, #0x73]
    // 0x78d0ac: DecompressPointer r2
    //     0x78d0ac: add             x2, x2, HEAP, lsl #32
    // 0x78d0b0: SaveReg r2
    //     0x78d0b0: str             x2, [SP, #-8]!
    // 0x78d0b4: r0 = values()
    //     0x78d0b4: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x78d0b8: add             SP, SP, #8
    // 0x78d0bc: SaveReg r0
    //     0x78d0bc: str             x0, [SP, #-8]!
    // 0x78d0c0: r0 = iterator()
    //     0x78d0c0: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x78d0c4: add             SP, SP, #8
    // 0x78d0c8: stur            x0, [fp, #-0x28]
    // 0x78d0cc: LoadField: r2 = r0->field_7
    //     0x78d0cc: ldur            w2, [x0, #7]
    // 0x78d0d0: DecompressPointer r2
    //     0x78d0d0: add             x2, x2, HEAP, lsl #32
    // 0x78d0d4: stur            x2, [fp, #-0x20]
    // 0x78d0d8: ldur            x1, [fp, #-0x18]
    // 0x78d0dc: stur            x1, [fp, #-0x18]
    // 0x78d0e0: CheckStackOverflow
    //     0x78d0e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78d0e4: cmp             SP, x16
    //     0x78d0e8: b.ls            #0x78d840
    // 0x78d0ec: SaveReg r0
    //     0x78d0ec: str             x0, [SP, #-8]!
    // 0x78d0f0: r0 = moveNext()
    //     0x78d0f0: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78d0f4: add             SP, SP, #8
    // 0x78d0f8: tbnz            w0, #4, #0x78d198
    // 0x78d0fc: ldur            x3, [fp, #-0x28]
    // 0x78d100: LoadField: r4 = r3->field_33
    //     0x78d100: ldur            w4, [x3, #0x33]
    // 0x78d104: DecompressPointer r4
    //     0x78d104: add             x4, x4, HEAP, lsl #32
    // 0x78d108: stur            x4, [fp, #-0x30]
    // 0x78d10c: cmp             w4, NULL
    // 0x78d110: b.ne            #0x78d144
    // 0x78d114: mov             x0, x4
    // 0x78d118: ldur            x2, [fp, #-0x20]
    // 0x78d11c: r1 = Null
    //     0x78d11c: mov             x1, NULL
    // 0x78d120: cmp             w2, NULL
    // 0x78d124: b.eq            #0x78d144
    // 0x78d128: LoadField: r4 = r2->field_17
    //     0x78d128: ldur            w4, [x2, #0x17]
    // 0x78d12c: DecompressPointer r4
    //     0x78d12c: add             x4, x4, HEAP, lsl #32
    // 0x78d130: r8 = X0
    //     0x78d130: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78d134: LoadField: r9 = r4->field_7
    //     0x78d134: ldur            x9, [x4, #7]
    // 0x78d138: r3 = Null
    //     0x78d138: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e870] Null
    //     0x78d13c: ldr             x3, [x3, #0x870]
    // 0x78d140: blr             x9
    // 0x78d144: ldur            x1, [fp, #-0x18]
    // 0x78d148: ldur            x0, [fp, #-0x30]
    // 0x78d14c: LoadField: r2 = r0->field_7
    //     0x78d14c: ldur            w2, [x0, #7]
    // 0x78d150: DecompressPointer r2
    //     0x78d150: add             x2, x2, HEAP, lsl #32
    // 0x78d154: LoadField: d0 = r1->field_7
    //     0x78d154: ldur            d0, [x1, #7]
    // 0x78d158: LoadField: d1 = r2->field_7
    //     0x78d158: ldur            d1, [x2, #7]
    // 0x78d15c: fadd            d2, d0, d1
    // 0x78d160: stur            d2, [fp, #-0x48]
    // 0x78d164: LoadField: d0 = r1->field_f
    //     0x78d164: ldur            d0, [x1, #0xf]
    // 0x78d168: LoadField: d1 = r2->field_f
    //     0x78d168: ldur            d1, [x2, #0xf]
    // 0x78d16c: fadd            d3, d0, d1
    // 0x78d170: stur            d3, [fp, #-0x40]
    // 0x78d174: r0 = Offset()
    //     0x78d174: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x78d178: ldur            d0, [fp, #-0x48]
    // 0x78d17c: StoreField: r0->field_7 = d0
    //     0x78d17c: stur            d0, [x0, #7]
    // 0x78d180: ldur            d0, [fp, #-0x40]
    // 0x78d184: StoreField: r0->field_f = d0
    //     0x78d184: stur            d0, [x0, #0xf]
    // 0x78d188: mov             x1, x0
    // 0x78d18c: ldur            x0, [fp, #-0x28]
    // 0x78d190: ldur            x2, [fp, #-0x20]
    // 0x78d194: b               #0x78d0dc
    // 0x78d198: ldur            x1, [fp, #-0x18]
    // 0x78d19c: ldr             x16, [fp, #0x10]
    // 0x78d1a0: SaveReg r16
    //     0x78d1a0: str             x16, [SP, #-8]!
    // 0x78d1a4: r0 = _pointerCount()
    //     0x78d1a4: bl              #0x78bd58  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerCount
    // 0x78d1a8: add             SP, SP, #8
    // 0x78d1ac: cmp             x0, #0
    // 0x78d1b0: b.le            #0x78d200
    // 0x78d1b4: ldr             x16, [fp, #0x10]
    // 0x78d1b8: SaveReg r16
    //     0x78d1b8: str             x16, [SP, #-8]!
    // 0x78d1bc: r0 = _pointerCount()
    //     0x78d1bc: bl              #0x78bd58  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerCount
    // 0x78d1c0: add             SP, SP, #8
    // 0x78d1c4: mov             x2, x0
    // 0x78d1c8: r0 = BoxInt64Instr(r2)
    //     0x78d1c8: sbfiz           x0, x2, #1, #0x1f
    //     0x78d1cc: cmp             x2, x0, asr #1
    //     0x78d1d0: b.eq            #0x78d1dc
    //     0x78d1d4: bl              #0xd69bb8
    //     0x78d1d8: stur            x2, [x0, #7]
    // 0x78d1dc: stp             x0, NULL, [SP, #-0x10]!
    // 0x78d1e0: r0 = _Double.fromInteger()
    //     0x78d1e0: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x78d1e4: add             SP, SP, #0x10
    // 0x78d1e8: ldur            x16, [fp, #-0x18]
    // 0x78d1ec: stp             x0, x16, [SP, #-0x10]!
    // 0x78d1f0: r0 = /()
    //     0x78d1f0: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x78d1f4: add             SP, SP, #0x10
    // 0x78d1f8: mov             x3, x0
    // 0x78d1fc: b               #0x78d204
    // 0x78d200: r3 = Instance_Offset
    //     0x78d200: ldr             x3, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x78d204: ldr             x1, [fp, #0x10]
    // 0x78d208: ldur            x2, [fp, #-0x10]
    // 0x78d20c: mov             x0, x3
    // 0x78d210: StoreField: r1->field_3b = r0
    //     0x78d210: stur            w0, [x1, #0x3b]
    //     0x78d214: ldurb           w16, [x1, #-1]
    //     0x78d218: ldurb           w17, [x0, #-1]
    //     0x78d21c: and             x16, x17, x16, lsr #2
    //     0x78d220: tst             x16, HEAP, lsr #32
    //     0x78d224: b.eq            #0x78d22c
    //     0x78d228: bl              #0xd6826c
    // 0x78d22c: cmp             w2, NULL
    // 0x78d230: b.ne            #0x78d274
    // 0x78d234: LoadField: r0 = r1->field_33
    //     0x78d234: ldur            w0, [x1, #0x33]
    // 0x78d238: DecompressPointer r0
    //     0x78d238: add             x0, x0, HEAP, lsl #32
    // 0x78d23c: stp             x3, x0, [SP, #-0x10]!
    // 0x78d240: r0 = transformPosition()
    //     0x78d240: bl              #0x5b659c  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0x78d244: add             SP, SP, #0x10
    // 0x78d248: ldr             x1, [fp, #0x10]
    // 0x78d24c: StoreField: r1->field_57 = r0
    //     0x78d24c: stur            w0, [x1, #0x57]
    //     0x78d250: ldurb           w16, [x1, #-1]
    //     0x78d254: ldurb           w17, [x0, #-1]
    //     0x78d258: and             x16, x17, x16, lsr #2
    //     0x78d25c: tst             x16, HEAP, lsr #32
    //     0x78d260: b.eq            #0x78d268
    //     0x78d264: bl              #0xd6826c
    // 0x78d268: r0 = Instance_Offset
    //     0x78d268: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x78d26c: StoreField: r1->field_6f = r0
    //     0x78d26c: stur            w0, [x1, #0x6f]
    // 0x78d270: b               #0x78d2f4
    // 0x78d274: LoadField: r0 = r1->field_57
    //     0x78d274: ldur            w0, [x1, #0x57]
    // 0x78d278: DecompressPointer r0
    //     0x78d278: add             x0, x0, HEAP, lsl #32
    // 0x78d27c: r16 = Sentinel
    //     0x78d27c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78d280: cmp             w0, w16
    // 0x78d284: b.eq            #0x78d848
    // 0x78d288: stur            x0, [fp, #-0x10]
    // 0x78d28c: LoadField: r2 = r1->field_33
    //     0x78d28c: ldur            w2, [x1, #0x33]
    // 0x78d290: DecompressPointer r2
    //     0x78d290: add             x2, x2, HEAP, lsl #32
    // 0x78d294: stp             x3, x2, [SP, #-0x10]!
    // 0x78d298: r0 = transformPosition()
    //     0x78d298: bl              #0x5b659c  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0x78d29c: add             SP, SP, #0x10
    // 0x78d2a0: mov             x2, x0
    // 0x78d2a4: ldr             x1, [fp, #0x10]
    // 0x78d2a8: StoreField: r1->field_57 = r0
    //     0x78d2a8: stur            w0, [x1, #0x57]
    //     0x78d2ac: ldurb           w16, [x1, #-1]
    //     0x78d2b0: ldurb           w17, [x0, #-1]
    //     0x78d2b4: and             x16, x17, x16, lsr #2
    //     0x78d2b8: tst             x16, HEAP, lsr #32
    //     0x78d2bc: b.eq            #0x78d2c4
    //     0x78d2c0: bl              #0xd6826c
    // 0x78d2c4: ldur            x16, [fp, #-0x10]
    // 0x78d2c8: stp             x16, x2, [SP, #-0x10]!
    // 0x78d2cc: r0 = -()
    //     0x78d2cc: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x78d2d0: add             SP, SP, #0x10
    // 0x78d2d4: ldr             x1, [fp, #0x10]
    // 0x78d2d8: StoreField: r1->field_6f = r0
    //     0x78d2d8: stur            w0, [x1, #0x6f]
    //     0x78d2dc: ldurb           w16, [x1, #-1]
    //     0x78d2e0: ldurb           w17, [x0, #-1]
    //     0x78d2e4: and             x16, x17, x16, lsr #2
    //     0x78d2e8: tst             x16, HEAP, lsr #32
    //     0x78d2ec: b.eq            #0x78d2f4
    //     0x78d2f0: bl              #0xd6826c
    // 0x78d2f4: ldur            x16, [fp, #-8]
    // 0x78d2f8: SaveReg r16
    //     0x78d2f8: str             x16, [SP, #-8]!
    // 0x78d2fc: r0 = keys()
    //     0x78d2fc: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x78d300: add             SP, SP, #8
    // 0x78d304: LoadField: r1 = r0->field_b
    //     0x78d304: ldur            w1, [x0, #0xb]
    // 0x78d308: DecompressPointer r1
    //     0x78d308: add             x1, x1, HEAP, lsl #32
    // 0x78d30c: r0 = LoadClassIdInstr(r1)
    //     0x78d30c: ldur            x0, [x1, #-1]
    //     0x78d310: ubfx            x0, x0, #0xc, #0x14
    // 0x78d314: SaveReg r1
    //     0x78d314: str             x1, [SP, #-8]!
    // 0x78d318: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x78d318: mov             x17, #0xb8ea
    //     0x78d31c: add             lr, x0, x17
    //     0x78d320: ldr             lr, [x21, lr, lsl #3]
    //     0x78d324: blr             lr
    // 0x78d328: add             SP, SP, #8
    // 0x78d32c: stur            x0, [fp, #-0x10]
    // 0x78d330: ldur            x16, [fp, #-8]
    // 0x78d334: SaveReg r16
    //     0x78d334: str             x16, [SP, #-8]!
    // 0x78d338: r0 = keys()
    //     0x78d338: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x78d33c: add             SP, SP, #8
    // 0x78d340: SaveReg r0
    //     0x78d340: str             x0, [SP, #-8]!
    // 0x78d344: r0 = iterator()
    //     0x78d344: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x78d348: add             SP, SP, #8
    // 0x78d34c: stur            x0, [fp, #-0x28]
    // 0x78d350: LoadField: r2 = r0->field_7
    //     0x78d350: ldur            w2, [x0, #7]
    // 0x78d354: DecompressPointer r2
    //     0x78d354: add             x2, x2, HEAP, lsl #32
    // 0x78d358: stur            x2, [fp, #-0x20]
    // 0x78d35c: r3 = Instance_Offset
    //     0x78d35c: ldr             x3, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x78d360: ldur            x1, [fp, #-8]
    // 0x78d364: stur            x3, [fp, #-0x18]
    // 0x78d368: CheckStackOverflow
    //     0x78d368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78d36c: cmp             SP, x16
    //     0x78d370: b.ls            #0x78d854
    // 0x78d374: SaveReg r0
    //     0x78d374: str             x0, [SP, #-8]!
    // 0x78d378: r0 = moveNext()
    //     0x78d378: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78d37c: add             SP, SP, #8
    // 0x78d380: tbnz            w0, #4, #0x78d454
    // 0x78d384: ldur            x3, [fp, #-0x28]
    // 0x78d388: LoadField: r4 = r3->field_33
    //     0x78d388: ldur            w4, [x3, #0x33]
    // 0x78d38c: DecompressPointer r4
    //     0x78d38c: add             x4, x4, HEAP, lsl #32
    // 0x78d390: stur            x4, [fp, #-0x30]
    // 0x78d394: cmp             w4, NULL
    // 0x78d398: b.ne            #0x78d3cc
    // 0x78d39c: mov             x0, x4
    // 0x78d3a0: ldur            x2, [fp, #-0x20]
    // 0x78d3a4: r1 = Null
    //     0x78d3a4: mov             x1, NULL
    // 0x78d3a8: cmp             w2, NULL
    // 0x78d3ac: b.eq            #0x78d3cc
    // 0x78d3b0: LoadField: r4 = r2->field_17
    //     0x78d3b0: ldur            w4, [x2, #0x17]
    // 0x78d3b4: DecompressPointer r4
    //     0x78d3b4: add             x4, x4, HEAP, lsl #32
    // 0x78d3b8: r8 = X0
    //     0x78d3b8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78d3bc: LoadField: r9 = r4->field_7
    //     0x78d3bc: ldur            x9, [x4, #7]
    // 0x78d3c0: r3 = Null
    //     0x78d3c0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e880] Null
    //     0x78d3c4: ldr             x3, [x3, #0x880]
    // 0x78d3c8: blr             x9
    // 0x78d3cc: ldur            x0, [fp, #-8]
    // 0x78d3d0: ldur            x16, [fp, #-0x30]
    // 0x78d3d4: stp             x16, x0, [SP, #-0x10]!
    // 0x78d3d8: r0 = _getValueOrData()
    //     0x78d3d8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78d3dc: add             SP, SP, #0x10
    // 0x78d3e0: mov             x1, x0
    // 0x78d3e4: ldur            x0, [fp, #-8]
    // 0x78d3e8: LoadField: r2 = r0->field_f
    //     0x78d3e8: ldur            w2, [x0, #0xf]
    // 0x78d3ec: DecompressPointer r2
    //     0x78d3ec: add             x2, x2, HEAP, lsl #32
    // 0x78d3f0: cmp             w2, w1
    // 0x78d3f4: b.ne            #0x78d400
    // 0x78d3f8: r2 = Null
    //     0x78d3f8: mov             x2, NULL
    // 0x78d3fc: b               #0x78d404
    // 0x78d400: mov             x2, x1
    // 0x78d404: ldur            x1, [fp, #-0x18]
    // 0x78d408: cmp             w2, NULL
    // 0x78d40c: b.eq            #0x78d85c
    // 0x78d410: LoadField: d0 = r1->field_7
    //     0x78d410: ldur            d0, [x1, #7]
    // 0x78d414: LoadField: d1 = r2->field_7
    //     0x78d414: ldur            d1, [x2, #7]
    // 0x78d418: fadd            d2, d0, d1
    // 0x78d41c: stur            d2, [fp, #-0x48]
    // 0x78d420: LoadField: d0 = r1->field_f
    //     0x78d420: ldur            d0, [x1, #0xf]
    // 0x78d424: LoadField: d1 = r2->field_f
    //     0x78d424: ldur            d1, [x2, #0xf]
    // 0x78d428: fadd            d3, d0, d1
    // 0x78d42c: stur            d3, [fp, #-0x40]
    // 0x78d430: r0 = Offset()
    //     0x78d430: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x78d434: ldur            d0, [fp, #-0x48]
    // 0x78d438: StoreField: r0->field_7 = d0
    //     0x78d438: stur            d0, [x0, #7]
    // 0x78d43c: ldur            d0, [fp, #-0x40]
    // 0x78d440: StoreField: r0->field_f = d0
    //     0x78d440: stur            d0, [x0, #0xf]
    // 0x78d444: mov             x3, x0
    // 0x78d448: ldur            x0, [fp, #-0x28]
    // 0x78d44c: ldur            x2, [fp, #-0x20]
    // 0x78d450: b               #0x78d360
    // 0x78d454: ldur            x1, [fp, #-0x18]
    // 0x78d458: ldur            x0, [fp, #-0x10]
    // 0x78d45c: r2 = LoadInt32Instr(r0)
    //     0x78d45c: sbfx            x2, x0, #1, #0x1f
    //     0x78d460: tbz             w0, #0, #0x78d468
    //     0x78d464: ldur            x2, [x0, #7]
    // 0x78d468: stur            x2, [fp, #-0x38]
    // 0x78d46c: cmp             x2, #0
    // 0x78d470: r16 = true
    //     0x78d470: add             x16, NULL, #0x20  ; true
    // 0x78d474: r17 = false
    //     0x78d474: add             x17, NULL, #0x30  ; false
    // 0x78d478: csel            x3, x16, x17, gt
    // 0x78d47c: stur            x3, [fp, #-0x20]
    // 0x78d480: tbnz            w3, #4, #0x78d4a4
    // 0x78d484: stp             x0, NULL, [SP, #-0x10]!
    // 0x78d488: r0 = _Double.fromInteger()
    //     0x78d488: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x78d48c: add             SP, SP, #0x10
    // 0x78d490: ldur            x16, [fp, #-0x18]
    // 0x78d494: stp             x0, x16, [SP, #-0x10]!
    // 0x78d498: r0 = /()
    //     0x78d498: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x78d49c: add             SP, SP, #0x10
    // 0x78d4a0: b               #0x78d4a8
    // 0x78d4a4: ldur            x0, [fp, #-0x18]
    // 0x78d4a8: stur            x0, [fp, #-0x10]
    // 0x78d4ac: ldur            x16, [fp, #-8]
    // 0x78d4b0: SaveReg r16
    //     0x78d4b0: str             x16, [SP, #-8]!
    // 0x78d4b4: r0 = keys()
    //     0x78d4b4: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x78d4b8: add             SP, SP, #8
    // 0x78d4bc: SaveReg r0
    //     0x78d4bc: str             x0, [SP, #-8]!
    // 0x78d4c0: r0 = iterator()
    //     0x78d4c0: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x78d4c4: add             SP, SP, #8
    // 0x78d4c8: mov             x1, x0
    // 0x78d4cc: ldur            x0, [fp, #-0x10]
    // 0x78d4d0: stur            x1, [fp, #-0x18]
    // 0x78d4d4: LoadField: d0 = r0->field_7
    //     0x78d4d4: ldur            d0, [x0, #7]
    // 0x78d4d8: stur            d0, [fp, #-0x60]
    // 0x78d4dc: LoadField: d1 = r0->field_f
    //     0x78d4dc: ldur            d1, [x0, #0xf]
    // 0x78d4e0: stur            d1, [fp, #-0x58]
    // 0x78d4e4: LoadField: r2 = r1->field_7
    //     0x78d4e4: ldur            w2, [x1, #7]
    // 0x78d4e8: DecompressPointer r2
    //     0x78d4e8: add             x2, x2, HEAP, lsl #32
    // 0x78d4ec: stur            x2, [fp, #-0x10]
    // 0x78d4f0: ldur            x0, [fp, #-8]
    // 0x78d4f4: d4 = 0.000000
    //     0x78d4f4: eor             v4.16b, v4.16b, v4.16b
    // 0x78d4f8: d3 = 0.000000
    //     0x78d4f8: eor             v3.16b, v3.16b, v3.16b
    // 0x78d4fc: d2 = 0.000000
    //     0x78d4fc: eor             v2.16b, v2.16b, v2.16b
    // 0x78d500: stur            d4, [fp, #-0x40]
    // 0x78d504: stur            d3, [fp, #-0x48]
    // 0x78d508: stur            d2, [fp, #-0x50]
    // 0x78d50c: CheckStackOverflow
    //     0x78d50c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78d510: cmp             SP, x16
    //     0x78d514: b.ls            #0x78d860
    // 0x78d518: SaveReg r1
    //     0x78d518: str             x1, [SP, #-8]!
    // 0x78d51c: r0 = moveNext()
    //     0x78d51c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x78d520: add             SP, SP, #8
    // 0x78d524: tbnz            w0, #4, #0x78d6ec
    // 0x78d528: ldur            x3, [fp, #-0x18]
    // 0x78d52c: LoadField: r4 = r3->field_33
    //     0x78d52c: ldur            w4, [x3, #0x33]
    // 0x78d530: DecompressPointer r4
    //     0x78d530: add             x4, x4, HEAP, lsl #32
    // 0x78d534: stur            x4, [fp, #-0x28]
    // 0x78d538: cmp             w4, NULL
    // 0x78d53c: b.ne            #0x78d570
    // 0x78d540: mov             x0, x4
    // 0x78d544: ldur            x2, [fp, #-0x10]
    // 0x78d548: r1 = Null
    //     0x78d548: mov             x1, NULL
    // 0x78d54c: cmp             w2, NULL
    // 0x78d550: b.eq            #0x78d570
    // 0x78d554: LoadField: r4 = r2->field_17
    //     0x78d554: ldur            w4, [x2, #0x17]
    // 0x78d558: DecompressPointer r4
    //     0x78d558: add             x4, x4, HEAP, lsl #32
    // 0x78d55c: r8 = X0
    //     0x78d55c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x78d560: LoadField: r9 = r4->field_7
    //     0x78d560: ldur            x9, [x4, #7]
    // 0x78d564: r3 = Null
    //     0x78d564: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e890] Null
    //     0x78d568: ldr             x3, [x3, #0x890]
    // 0x78d56c: blr             x9
    // 0x78d570: ldur            x0, [fp, #-8]
    // 0x78d574: ldur            x16, [fp, #-0x28]
    // 0x78d578: stp             x16, x0, [SP, #-0x10]!
    // 0x78d57c: r0 = _getValueOrData()
    //     0x78d57c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78d580: add             SP, SP, #0x10
    // 0x78d584: mov             x1, x0
    // 0x78d588: ldur            x0, [fp, #-8]
    // 0x78d58c: LoadField: r2 = r0->field_f
    //     0x78d58c: ldur            w2, [x0, #0xf]
    // 0x78d590: DecompressPointer r2
    //     0x78d590: add             x2, x2, HEAP, lsl #32
    // 0x78d594: cmp             w2, w1
    // 0x78d598: b.ne            #0x78d5a0
    // 0x78d59c: r1 = Null
    //     0x78d59c: mov             x1, NULL
    // 0x78d5a0: ldur            d2, [fp, #-0x40]
    // 0x78d5a4: ldur            d0, [fp, #-0x60]
    // 0x78d5a8: ldur            d1, [fp, #-0x58]
    // 0x78d5ac: cmp             w1, NULL
    // 0x78d5b0: b.eq            #0x78d868
    // 0x78d5b4: LoadField: d3 = r1->field_7
    //     0x78d5b4: ldur            d3, [x1, #7]
    // 0x78d5b8: fsub            d4, d0, d3
    // 0x78d5bc: LoadField: d3 = r1->field_f
    //     0x78d5bc: ldur            d3, [x1, #0xf]
    // 0x78d5c0: fsub            d5, d1, d3
    // 0x78d5c4: fmul            d3, d4, d4
    // 0x78d5c8: fmul            d4, d5, d5
    // 0x78d5cc: fadd            d5, d3, d4
    // 0x78d5d0: fsqrt           d3, d5
    // 0x78d5d4: fadd            d4, d2, d3
    // 0x78d5d8: stur            d4, [fp, #-0x68]
    // 0x78d5dc: ldur            x16, [fp, #-0x28]
    // 0x78d5e0: stp             x16, x0, [SP, #-0x10]!
    // 0x78d5e4: r0 = _getValueOrData()
    //     0x78d5e4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78d5e8: add             SP, SP, #0x10
    // 0x78d5ec: mov             x1, x0
    // 0x78d5f0: ldur            x0, [fp, #-8]
    // 0x78d5f4: LoadField: r2 = r0->field_f
    //     0x78d5f4: ldur            w2, [x0, #0xf]
    // 0x78d5f8: DecompressPointer r2
    //     0x78d5f8: add             x2, x2, HEAP, lsl #32
    // 0x78d5fc: cmp             w2, w1
    // 0x78d600: b.ne            #0x78d608
    // 0x78d604: r1 = Null
    //     0x78d604: mov             x1, NULL
    // 0x78d608: ldur            d0, [fp, #-0x60]
    // 0x78d60c: d1 = 0.000000
    //     0x78d60c: eor             v1.16b, v1.16b, v1.16b
    // 0x78d610: cmp             w1, NULL
    // 0x78d614: b.eq            #0x78d86c
    // 0x78d618: LoadField: d2 = r1->field_7
    //     0x78d618: ldur            d2, [x1, #7]
    // 0x78d61c: fsub            d5, d0, d2
    // 0x78d620: fcmp            d5, d1
    // 0x78d624: b.vs            #0x78d634
    // 0x78d628: b.ne            #0x78d634
    // 0x78d62c: d2 = 0.000000
    //     0x78d62c: eor             v2.16b, v2.16b, v2.16b
    // 0x78d630: b               #0x78d64c
    // 0x78d634: fcmp            d5, d1
    // 0x78d638: b.vs            #0x78d648
    // 0x78d63c: b.ge            #0x78d648
    // 0x78d640: fneg            d6, d5
    // 0x78d644: mov             v5.16b, v6.16b
    // 0x78d648: mov             v2.16b, v5.16b
    // 0x78d64c: ldur            d3, [fp, #-0x48]
    // 0x78d650: fadd            d4, d3, d2
    // 0x78d654: stur            d4, [fp, #-0x70]
    // 0x78d658: ldur            x16, [fp, #-0x28]
    // 0x78d65c: stp             x16, x0, [SP, #-0x10]!
    // 0x78d660: r0 = _getValueOrData()
    //     0x78d660: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78d664: add             SP, SP, #0x10
    // 0x78d668: ldur            x1, [fp, #-8]
    // 0x78d66c: LoadField: r2 = r1->field_f
    //     0x78d66c: ldur            w2, [x1, #0xf]
    // 0x78d670: DecompressPointer r2
    //     0x78d670: add             x2, x2, HEAP, lsl #32
    // 0x78d674: cmp             w2, w0
    // 0x78d678: b.ne            #0x78d684
    // 0x78d67c: r2 = Null
    //     0x78d67c: mov             x2, NULL
    // 0x78d680: b               #0x78d688
    // 0x78d684: mov             x2, x0
    // 0x78d688: ldur            d1, [fp, #-0x58]
    // 0x78d68c: d0 = 0.000000
    //     0x78d68c: eor             v0.16b, v0.16b, v0.16b
    // 0x78d690: cmp             w2, NULL
    // 0x78d694: b.eq            #0x78d870
    // 0x78d698: LoadField: d4 = r2->field_f
    //     0x78d698: ldur            d4, [x2, #0xf]
    // 0x78d69c: fsub            d5, d1, d4
    // 0x78d6a0: fcmp            d5, d0
    // 0x78d6a4: b.vs            #0x78d6b4
    // 0x78d6a8: b.ne            #0x78d6b4
    // 0x78d6ac: d5 = 0.000000
    //     0x78d6ac: eor             v5.16b, v5.16b, v5.16b
    // 0x78d6b0: b               #0x78d6c8
    // 0x78d6b4: fcmp            d5, d0
    // 0x78d6b8: b.vs            #0x78d6c8
    // 0x78d6bc: b.ge            #0x78d6c8
    // 0x78d6c0: fneg            d6, d5
    // 0x78d6c4: mov             v5.16b, v6.16b
    // 0x78d6c8: ldur            d4, [fp, #-0x50]
    // 0x78d6cc: fadd            d2, d4, d5
    // 0x78d6d0: ldur            d4, [fp, #-0x68]
    // 0x78d6d4: ldur            d3, [fp, #-0x70]
    // 0x78d6d8: mov             x0, x1
    // 0x78d6dc: ldur            x1, [fp, #-0x18]
    // 0x78d6e0: ldur            x2, [fp, #-0x10]
    // 0x78d6e4: ldur            d0, [fp, #-0x60]
    // 0x78d6e8: b               #0x78d500
    // 0x78d6ec: ldur            x1, [fp, #-0x20]
    // 0x78d6f0: ldur            d2, [fp, #-0x40]
    // 0x78d6f4: ldur            d3, [fp, #-0x48]
    // 0x78d6f8: ldur            d4, [fp, #-0x50]
    // 0x78d6fc: tbnz            w1, #4, #0x78d714
    // 0x78d700: ldur            x2, [fp, #-0x38]
    // 0x78d704: scvtf           d0, x2
    // 0x78d708: fdiv            d1, d2, d0
    // 0x78d70c: mov             v0.16b, v1.16b
    // 0x78d710: b               #0x78d71c
    // 0x78d714: ldur            x2, [fp, #-0x38]
    // 0x78d718: d0 = 0.000000
    //     0x78d718: eor             v0.16b, v0.16b, v0.16b
    // 0x78d71c: ldr             x3, [fp, #0x10]
    // 0x78d720: r0 = inline_Allocate_Double()
    //     0x78d720: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x78d724: add             x0, x0, #0x10
    //     0x78d728: cmp             x4, x0
    //     0x78d72c: b.ls            #0x78d874
    //     0x78d730: str             x0, [THR, #0x60]  ; THR::top
    //     0x78d734: sub             x0, x0, #0xf
    //     0x78d738: mov             x4, #0xd108
    //     0x78d73c: movk            x4, #3, lsl #16
    //     0x78d740: stur            x4, [x0, #-1]
    // 0x78d744: StoreField: r0->field_7 = d0
    //     0x78d744: stur            d0, [x0, #7]
    // 0x78d748: StoreField: r3->field_43 = r0
    //     0x78d748: stur            w0, [x3, #0x43]
    //     0x78d74c: ldurb           w16, [x3, #-1]
    //     0x78d750: ldurb           w17, [x0, #-1]
    //     0x78d754: and             x16, x17, x16, lsr #2
    //     0x78d758: tst             x16, HEAP, lsr #32
    //     0x78d75c: b.eq            #0x78d764
    //     0x78d760: bl              #0xd682ac
    // 0x78d764: tbnz            w1, #4, #0x78d778
    // 0x78d768: scvtf           d0, x2
    // 0x78d76c: fdiv            d1, d3, d0
    // 0x78d770: mov             v0.16b, v1.16b
    // 0x78d774: b               #0x78d77c
    // 0x78d778: d0 = 0.000000
    //     0x78d778: eor             v0.16b, v0.16b, v0.16b
    // 0x78d77c: r0 = inline_Allocate_Double()
    //     0x78d77c: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x78d780: add             x0, x0, #0x10
    //     0x78d784: cmp             x4, x0
    //     0x78d788: b.ls            #0x78d89c
    //     0x78d78c: str             x0, [THR, #0x60]  ; THR::top
    //     0x78d790: sub             x0, x0, #0xf
    //     0x78d794: mov             x4, #0xd108
    //     0x78d798: movk            x4, #3, lsl #16
    //     0x78d79c: stur            x4, [x0, #-1]
    // 0x78d7a0: StoreField: r0->field_7 = d0
    //     0x78d7a0: stur            d0, [x0, #7]
    // 0x78d7a4: StoreField: r3->field_4b = r0
    //     0x78d7a4: stur            w0, [x3, #0x4b]
    //     0x78d7a8: ldurb           w16, [x3, #-1]
    //     0x78d7ac: ldurb           w17, [x0, #-1]
    //     0x78d7b0: and             x16, x17, x16, lsr #2
    //     0x78d7b4: tst             x16, HEAP, lsr #32
    //     0x78d7b8: b.eq            #0x78d7c0
    //     0x78d7bc: bl              #0xd682ac
    // 0x78d7c0: tbnz            w1, #4, #0x78d7d4
    // 0x78d7c4: scvtf           d0, x2
    // 0x78d7c8: fdiv            d1, d4, d0
    // 0x78d7cc: mov             v0.16b, v1.16b
    // 0x78d7d0: b               #0x78d7d8
    // 0x78d7d4: d0 = 0.000000
    //     0x78d7d4: eor             v0.16b, v0.16b, v0.16b
    // 0x78d7d8: r0 = inline_Allocate_Double()
    //     0x78d7d8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x78d7dc: add             x0, x0, #0x10
    //     0x78d7e0: cmp             x1, x0
    //     0x78d7e4: b.ls            #0x78d8bc
    //     0x78d7e8: str             x0, [THR, #0x60]  ; THR::top
    //     0x78d7ec: sub             x0, x0, #0xf
    //     0x78d7f0: mov             x1, #0xd108
    //     0x78d7f4: movk            x1, #3, lsl #16
    //     0x78d7f8: stur            x1, [x0, #-1]
    // 0x78d7fc: StoreField: r0->field_7 = d0
    //     0x78d7fc: stur            d0, [x0, #7]
    // 0x78d800: StoreField: r3->field_53 = r0
    //     0x78d800: stur            w0, [x3, #0x53]
    //     0x78d804: ldurb           w16, [x3, #-1]
    //     0x78d808: ldurb           w17, [x0, #-1]
    //     0x78d80c: and             x16, x17, x16, lsr #2
    //     0x78d810: tst             x16, HEAP, lsr #32
    //     0x78d814: b.eq            #0x78d81c
    //     0x78d818: bl              #0xd682ac
    // 0x78d81c: r0 = Null
    //     0x78d81c: mov             x0, NULL
    // 0x78d820: LeaveFrame
    //     0x78d820: mov             SP, fp
    //     0x78d824: ldp             fp, lr, [SP], #0x10
    // 0x78d828: ret
    //     0x78d828: ret             
    // 0x78d82c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78d82c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78d830: b               #0x78cf64
    // 0x78d834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78d834: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78d838: b               #0x78cfc0
    // 0x78d83c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78d83c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78d840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78d840: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78d844: b               #0x78d0ec
    // 0x78d848: r9 = _localFocalPoint
    //     0x78d848: add             x9, PP, #0x28, lsl #12  ; [pp+0x28ea0] Field <ScaleGestureRecognizer._localFocalPoint@672213599>: late (offset: 0x58)
    //     0x78d84c: ldr             x9, [x9, #0xea0]
    // 0x78d850: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78d850: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x78d854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78d854: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78d858: b               #0x78d374
    // 0x78d85c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78d85c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78d860: r0 = StackOverflowSharedWithFPURegs()
    //     0x78d860: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x78d864: b               #0x78d518
    // 0x78d868: r0 = NullCastErrorSharedWithFPURegs()
    //     0x78d868: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x78d86c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x78d86c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x78d870: r0 = NullCastErrorSharedWithFPURegs()
    //     0x78d870: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x78d874: stp             q3, q4, [SP, #-0x20]!
    // 0x78d878: SaveReg d0
    //     0x78d878: str             q0, [SP, #-0x10]!
    // 0x78d87c: stp             x2, x3, [SP, #-0x10]!
    // 0x78d880: SaveReg r1
    //     0x78d880: str             x1, [SP, #-8]!
    // 0x78d884: r0 = AllocateDouble()
    //     0x78d884: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78d888: RestoreReg r1
    //     0x78d888: ldr             x1, [SP], #8
    // 0x78d88c: ldp             x2, x3, [SP], #0x10
    // 0x78d890: RestoreReg d0
    //     0x78d890: ldr             q0, [SP], #0x10
    // 0x78d894: ldp             q3, q4, [SP], #0x20
    // 0x78d898: b               #0x78d744
    // 0x78d89c: stp             q0, q4, [SP, #-0x20]!
    // 0x78d8a0: stp             x2, x3, [SP, #-0x10]!
    // 0x78d8a4: SaveReg r1
    //     0x78d8a4: str             x1, [SP, #-8]!
    // 0x78d8a8: r0 = AllocateDouble()
    //     0x78d8a8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78d8ac: RestoreReg r1
    //     0x78d8ac: ldr             x1, [SP], #8
    // 0x78d8b0: ldp             x2, x3, [SP], #0x10
    // 0x78d8b4: ldp             q0, q4, [SP], #0x20
    // 0x78d8b8: b               #0x78d7a0
    // 0x78d8bc: SaveReg d0
    //     0x78d8bc: str             q0, [SP, #-0x10]!
    // 0x78d8c0: SaveReg r3
    //     0x78d8c0: str             x3, [SP, #-8]!
    // 0x78d8c4: r0 = AllocateDouble()
    //     0x78d8c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78d8c8: RestoreReg r3
    //     0x78d8c8: ldr             x3, [SP], #8
    // 0x78d8cc: RestoreReg d0
    //     0x78d8cc: ldr             q0, [SP], #0x10
    // 0x78d8d0: b               #0x78d7fc
  }
  _ _updateLines(/* No info */) {
    // ** addr: 0x78d8d4, size: 0x428
    // 0x78d8d4: EnterFrame
    //     0x78d8d4: stp             fp, lr, [SP, #-0x10]!
    //     0x78d8d8: mov             fp, SP
    // 0x78d8dc: AllocStack(0x28)
    //     0x78d8dc: sub             SP, SP, #0x28
    // 0x78d8e0: CheckStackOverflow
    //     0x78d8e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78d8e4: cmp             SP, x16
    //     0x78d8e8: b.ls            #0x78dcd0
    // 0x78d8ec: ldr             x0, [fp, #0x10]
    // 0x78d8f0: LoadField: r1 = r0->field_63
    //     0x78d8f0: ldur            w1, [x0, #0x63]
    // 0x78d8f4: DecompressPointer r1
    //     0x78d8f4: add             x1, x1, HEAP, lsl #32
    // 0x78d8f8: stur            x1, [fp, #-8]
    // 0x78d8fc: SaveReg r1
    //     0x78d8fc: str             x1, [SP, #-8]!
    // 0x78d900: r0 = keys()
    //     0x78d900: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x78d904: add             SP, SP, #8
    // 0x78d908: LoadField: r1 = r0->field_b
    //     0x78d908: ldur            w1, [x0, #0xb]
    // 0x78d90c: DecompressPointer r1
    //     0x78d90c: add             x1, x1, HEAP, lsl #32
    // 0x78d910: r0 = LoadClassIdInstr(r1)
    //     0x78d910: ldur            x0, [x1, #-1]
    //     0x78d914: ubfx            x0, x0, #0xc, #0x14
    // 0x78d918: SaveReg r1
    //     0x78d918: str             x1, [SP, #-8]!
    // 0x78d91c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x78d91c: mov             x17, #0xb8ea
    //     0x78d920: add             lr, x0, x17
    //     0x78d924: ldr             lr, [x21, lr, lsl #3]
    //     0x78d928: blr             lr
    // 0x78d92c: add             SP, SP, #8
    // 0x78d930: r1 = LoadInt32Instr(r0)
    //     0x78d930: sbfx            x1, x0, #1, #0x1f
    //     0x78d934: tbz             w0, #0, #0x78d93c
    //     0x78d938: ldur            x1, [x0, #7]
    // 0x78d93c: cmp             x1, #2
    // 0x78d940: b.ge            #0x78d970
    // 0x78d944: ldr             x2, [fp, #0x10]
    // 0x78d948: LoadField: r0 = r2->field_5f
    //     0x78d948: ldur            w0, [x2, #0x5f]
    // 0x78d94c: DecompressPointer r0
    //     0x78d94c: add             x0, x0, HEAP, lsl #32
    // 0x78d950: StoreField: r2->field_5b = r0
    //     0x78d950: stur            w0, [x2, #0x5b]
    //     0x78d954: ldurb           w16, [x2, #-1]
    //     0x78d958: ldurb           w17, [x0, #-1]
    //     0x78d95c: and             x16, x17, x16, lsr #2
    //     0x78d960: tst             x16, HEAP, lsr #32
    //     0x78d964: b.eq            #0x78d96c
    //     0x78d968: bl              #0xd6828c
    // 0x78d96c: b               #0x78dcc0
    // 0x78d970: ldr             x2, [fp, #0x10]
    // 0x78d974: LoadField: r3 = r2->field_5b
    //     0x78d974: ldur            w3, [x2, #0x5b]
    // 0x78d978: DecompressPointer r3
    //     0x78d978: add             x3, x3, HEAP, lsl #32
    // 0x78d97c: cmp             w3, NULL
    // 0x78d980: b.eq            #0x78db40
    // 0x78d984: LoadField: r4 = r3->field_b
    //     0x78d984: ldur            x4, [x3, #0xb]
    // 0x78d988: LoadField: r5 = r2->field_67
    //     0x78d988: ldur            w5, [x2, #0x67]
    // 0x78d98c: DecompressPointer r5
    //     0x78d98c: add             x5, x5, HEAP, lsl #32
    // 0x78d990: stur            x5, [fp, #-0x18]
    // 0x78d994: LoadField: r0 = r5->field_b
    //     0x78d994: ldur            w0, [x5, #0xb]
    // 0x78d998: DecompressPointer r0
    //     0x78d998: add             x0, x0, HEAP, lsl #32
    // 0x78d99c: r6 = LoadInt32Instr(r0)
    //     0x78d99c: sbfx            x6, x0, #1, #0x1f
    // 0x78d9a0: mov             x0, x6
    // 0x78d9a4: r1 = 0
    //     0x78d9a4: mov             x1, #0
    // 0x78d9a8: cmp             x1, x0
    // 0x78d9ac: b.hs            #0x78dcd8
    // 0x78d9b0: LoadField: r7 = r5->field_f
    //     0x78d9b0: ldur            w7, [x5, #0xf]
    // 0x78d9b4: DecompressPointer r7
    //     0x78d9b4: add             x7, x7, HEAP, lsl #32
    // 0x78d9b8: LoadField: r8 = r7->field_f
    //     0x78d9b8: ldur            w8, [x7, #0xf]
    // 0x78d9bc: DecompressPointer r8
    //     0x78d9bc: add             x8, x8, HEAP, lsl #32
    // 0x78d9c0: stur            x8, [fp, #-0x10]
    // 0x78d9c4: r0 = LoadInt32Instr(r8)
    //     0x78d9c4: sbfx            x0, x8, #1, #0x1f
    //     0x78d9c8: tbz             w8, #0, #0x78d9d0
    //     0x78d9cc: ldur            x0, [x8, #7]
    // 0x78d9d0: cmp             x4, x0
    // 0x78d9d4: b.ne            #0x78db34
    // 0x78d9d8: LoadField: r4 = r3->field_17
    //     0x78d9d8: ldur            x4, [x3, #0x17]
    // 0x78d9dc: mov             x0, x6
    // 0x78d9e0: r1 = 1
    //     0x78d9e0: mov             x1, #1
    // 0x78d9e4: cmp             x1, x0
    // 0x78d9e8: b.hs            #0x78dcdc
    // 0x78d9ec: LoadField: r0 = r7->field_13
    //     0x78d9ec: ldur            w0, [x7, #0x13]
    // 0x78d9f0: DecompressPointer r0
    //     0x78d9f0: add             x0, x0, HEAP, lsl #32
    // 0x78d9f4: r1 = LoadInt32Instr(r0)
    //     0x78d9f4: sbfx            x1, x0, #1, #0x1f
    //     0x78d9f8: tbz             w0, #0, #0x78da00
    //     0x78d9fc: ldur            x1, [x0, #7]
    // 0x78da00: cmp             x4, x1
    // 0x78da04: b.ne            #0x78db28
    // 0x78da08: ldur            x0, [fp, #-8]
    // 0x78da0c: stp             x8, x0, [SP, #-0x10]!
    // 0x78da10: r0 = _getValueOrData()
    //     0x78da10: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78da14: add             SP, SP, #0x10
    // 0x78da18: ldur            x2, [fp, #-8]
    // 0x78da1c: LoadField: r1 = r2->field_f
    //     0x78da1c: ldur            w1, [x2, #0xf]
    // 0x78da20: DecompressPointer r1
    //     0x78da20: add             x1, x1, HEAP, lsl #32
    // 0x78da24: cmp             w1, w0
    // 0x78da28: b.ne            #0x78da34
    // 0x78da2c: r4 = Null
    //     0x78da2c: mov             x4, NULL
    // 0x78da30: b               #0x78da38
    // 0x78da34: mov             x4, x0
    // 0x78da38: ldur            x3, [fp, #-0x18]
    // 0x78da3c: stur            x4, [fp, #-0x20]
    // 0x78da40: cmp             w4, NULL
    // 0x78da44: b.eq            #0x78dce0
    // 0x78da48: LoadField: r0 = r3->field_b
    //     0x78da48: ldur            w0, [x3, #0xb]
    // 0x78da4c: DecompressPointer r0
    //     0x78da4c: add             x0, x0, HEAP, lsl #32
    // 0x78da50: r1 = LoadInt32Instr(r0)
    //     0x78da50: sbfx            x1, x0, #1, #0x1f
    // 0x78da54: mov             x0, x1
    // 0x78da58: r1 = 1
    //     0x78da58: mov             x1, #1
    // 0x78da5c: cmp             x1, x0
    // 0x78da60: b.hs            #0x78dce4
    // 0x78da64: LoadField: r0 = r3->field_f
    //     0x78da64: ldur            w0, [x3, #0xf]
    // 0x78da68: DecompressPointer r0
    //     0x78da68: add             x0, x0, HEAP, lsl #32
    // 0x78da6c: LoadField: r1 = r0->field_13
    //     0x78da6c: ldur            w1, [x0, #0x13]
    // 0x78da70: DecompressPointer r1
    //     0x78da70: add             x1, x1, HEAP, lsl #32
    // 0x78da74: stur            x1, [fp, #-0x18]
    // 0x78da78: stp             x1, x2, [SP, #-0x10]!
    // 0x78da7c: r0 = _getValueOrData()
    //     0x78da7c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78da80: add             SP, SP, #0x10
    // 0x78da84: ldur            x2, [fp, #-8]
    // 0x78da88: LoadField: r1 = r2->field_f
    //     0x78da88: ldur            w1, [x2, #0xf]
    // 0x78da8c: DecompressPointer r1
    //     0x78da8c: add             x1, x1, HEAP, lsl #32
    // 0x78da90: cmp             w1, w0
    // 0x78da94: b.ne            #0x78daa0
    // 0x78da98: r4 = Null
    //     0x78da98: mov             x4, NULL
    // 0x78da9c: b               #0x78daa4
    // 0x78daa0: mov             x4, x0
    // 0x78daa4: ldr             x2, [fp, #0x10]
    // 0x78daa8: ldur            x0, [fp, #-0x20]
    // 0x78daac: ldur            x3, [fp, #-0x10]
    // 0x78dab0: ldur            x1, [fp, #-0x18]
    // 0x78dab4: stur            x4, [fp, #-0x28]
    // 0x78dab8: cmp             w4, NULL
    // 0x78dabc: b.eq            #0x78dce8
    // 0x78dac0: r0 = _LineBetweenPointers()
    //     0x78dac0: bl              #0x78dcfc  ; Allocate_LineBetweenPointersStub -> _LineBetweenPointers (size=0x20)
    // 0x78dac4: mov             x1, x0
    // 0x78dac8: ldur            x0, [fp, #-0x20]
    // 0x78dacc: StoreField: r1->field_7 = r0
    //     0x78dacc: stur            w0, [x1, #7]
    // 0x78dad0: ldur            x0, [fp, #-0x10]
    // 0x78dad4: r2 = LoadInt32Instr(r0)
    //     0x78dad4: sbfx            x2, x0, #1, #0x1f
    //     0x78dad8: tbz             w0, #0, #0x78dae0
    //     0x78dadc: ldur            x2, [x0, #7]
    // 0x78dae0: StoreField: r1->field_b = r2
    //     0x78dae0: stur            x2, [x1, #0xb]
    // 0x78dae4: ldur            x0, [fp, #-0x28]
    // 0x78dae8: StoreField: r1->field_13 = r0
    //     0x78dae8: stur            w0, [x1, #0x13]
    // 0x78daec: ldur            x0, [fp, #-0x18]
    // 0x78daf0: r2 = LoadInt32Instr(r0)
    //     0x78daf0: sbfx            x2, x0, #1, #0x1f
    //     0x78daf4: tbz             w0, #0, #0x78dafc
    //     0x78daf8: ldur            x2, [x0, #7]
    // 0x78dafc: StoreField: r1->field_17 = r2
    //     0x78dafc: stur            x2, [x1, #0x17]
    // 0x78db00: mov             x0, x1
    // 0x78db04: ldr             x3, [fp, #0x10]
    // 0x78db08: StoreField: r3->field_5f = r0
    //     0x78db08: stur            w0, [x3, #0x5f]
    //     0x78db0c: ldurb           w16, [x3, #-1]
    //     0x78db10: ldurb           w17, [x0, #-1]
    //     0x78db14: and             x16, x17, x16, lsr #2
    //     0x78db18: tst             x16, HEAP, lsr #32
    //     0x78db1c: b.eq            #0x78db24
    //     0x78db20: bl              #0xd682ac
    // 0x78db24: b               #0x78dcc0
    // 0x78db28: mov             x3, x2
    // 0x78db2c: ldur            x2, [fp, #-8]
    // 0x78db30: b               #0x78db48
    // 0x78db34: mov             x3, x2
    // 0x78db38: ldur            x2, [fp, #-8]
    // 0x78db3c: b               #0x78db48
    // 0x78db40: mov             x3, x2
    // 0x78db44: ldur            x2, [fp, #-8]
    // 0x78db48: LoadField: r4 = r3->field_67
    //     0x78db48: ldur            w4, [x3, #0x67]
    // 0x78db4c: DecompressPointer r4
    //     0x78db4c: add             x4, x4, HEAP, lsl #32
    // 0x78db50: stur            x4, [fp, #-0x18]
    // 0x78db54: LoadField: r0 = r4->field_b
    //     0x78db54: ldur            w0, [x4, #0xb]
    // 0x78db58: DecompressPointer r0
    //     0x78db58: add             x0, x0, HEAP, lsl #32
    // 0x78db5c: r1 = LoadInt32Instr(r0)
    //     0x78db5c: sbfx            x1, x0, #1, #0x1f
    // 0x78db60: mov             x0, x1
    // 0x78db64: r1 = 0
    //     0x78db64: mov             x1, #0
    // 0x78db68: cmp             x1, x0
    // 0x78db6c: b.hs            #0x78dcec
    // 0x78db70: LoadField: r0 = r4->field_f
    //     0x78db70: ldur            w0, [x4, #0xf]
    // 0x78db74: DecompressPointer r0
    //     0x78db74: add             x0, x0, HEAP, lsl #32
    // 0x78db78: LoadField: r1 = r0->field_f
    //     0x78db78: ldur            w1, [x0, #0xf]
    // 0x78db7c: DecompressPointer r1
    //     0x78db7c: add             x1, x1, HEAP, lsl #32
    // 0x78db80: stur            x1, [fp, #-0x10]
    // 0x78db84: stp             x1, x2, [SP, #-0x10]!
    // 0x78db88: r0 = _getValueOrData()
    //     0x78db88: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78db8c: add             SP, SP, #0x10
    // 0x78db90: ldur            x2, [fp, #-8]
    // 0x78db94: LoadField: r1 = r2->field_f
    //     0x78db94: ldur            w1, [x2, #0xf]
    // 0x78db98: DecompressPointer r1
    //     0x78db98: add             x1, x1, HEAP, lsl #32
    // 0x78db9c: cmp             w1, w0
    // 0x78dba0: b.ne            #0x78dbac
    // 0x78dba4: r4 = Null
    //     0x78dba4: mov             x4, NULL
    // 0x78dba8: b               #0x78dbb0
    // 0x78dbac: mov             x4, x0
    // 0x78dbb0: ldur            x3, [fp, #-0x18]
    // 0x78dbb4: stur            x4, [fp, #-0x20]
    // 0x78dbb8: cmp             w4, NULL
    // 0x78dbbc: b.eq            #0x78dcf0
    // 0x78dbc0: LoadField: r0 = r3->field_b
    //     0x78dbc0: ldur            w0, [x3, #0xb]
    // 0x78dbc4: DecompressPointer r0
    //     0x78dbc4: add             x0, x0, HEAP, lsl #32
    // 0x78dbc8: r1 = LoadInt32Instr(r0)
    //     0x78dbc8: sbfx            x1, x0, #1, #0x1f
    // 0x78dbcc: mov             x0, x1
    // 0x78dbd0: r1 = 1
    //     0x78dbd0: mov             x1, #1
    // 0x78dbd4: cmp             x1, x0
    // 0x78dbd8: b.hs            #0x78dcf4
    // 0x78dbdc: LoadField: r0 = r3->field_f
    //     0x78dbdc: ldur            w0, [x3, #0xf]
    // 0x78dbe0: DecompressPointer r0
    //     0x78dbe0: add             x0, x0, HEAP, lsl #32
    // 0x78dbe4: LoadField: r1 = r0->field_13
    //     0x78dbe4: ldur            w1, [x0, #0x13]
    // 0x78dbe8: DecompressPointer r1
    //     0x78dbe8: add             x1, x1, HEAP, lsl #32
    // 0x78dbec: stur            x1, [fp, #-0x18]
    // 0x78dbf0: stp             x1, x2, [SP, #-0x10]!
    // 0x78dbf4: r0 = _getValueOrData()
    //     0x78dbf4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78dbf8: add             SP, SP, #0x10
    // 0x78dbfc: mov             x1, x0
    // 0x78dc00: ldur            x0, [fp, #-8]
    // 0x78dc04: LoadField: r2 = r0->field_f
    //     0x78dc04: ldur            w2, [x0, #0xf]
    // 0x78dc08: DecompressPointer r2
    //     0x78dc08: add             x2, x2, HEAP, lsl #32
    // 0x78dc0c: cmp             w2, w1
    // 0x78dc10: b.ne            #0x78dc1c
    // 0x78dc14: r4 = Null
    //     0x78dc14: mov             x4, NULL
    // 0x78dc18: b               #0x78dc20
    // 0x78dc1c: mov             x4, x1
    // 0x78dc20: ldr             x2, [fp, #0x10]
    // 0x78dc24: ldur            x0, [fp, #-0x20]
    // 0x78dc28: ldur            x3, [fp, #-0x10]
    // 0x78dc2c: ldur            x1, [fp, #-0x18]
    // 0x78dc30: stur            x4, [fp, #-8]
    // 0x78dc34: cmp             w4, NULL
    // 0x78dc38: b.eq            #0x78dcf8
    // 0x78dc3c: r0 = _LineBetweenPointers()
    //     0x78dc3c: bl              #0x78dcfc  ; Allocate_LineBetweenPointersStub -> _LineBetweenPointers (size=0x20)
    // 0x78dc40: mov             x2, x0
    // 0x78dc44: ldur            x1, [fp, #-0x20]
    // 0x78dc48: StoreField: r2->field_7 = r1
    //     0x78dc48: stur            w1, [x2, #7]
    // 0x78dc4c: ldur            x1, [fp, #-0x10]
    // 0x78dc50: r3 = LoadInt32Instr(r1)
    //     0x78dc50: sbfx            x3, x1, #1, #0x1f
    //     0x78dc54: tbz             w1, #0, #0x78dc5c
    //     0x78dc58: ldur            x3, [x1, #7]
    // 0x78dc5c: StoreField: r2->field_b = r3
    //     0x78dc5c: stur            x3, [x2, #0xb]
    // 0x78dc60: ldur            x1, [fp, #-8]
    // 0x78dc64: StoreField: r2->field_13 = r1
    //     0x78dc64: stur            w1, [x2, #0x13]
    // 0x78dc68: ldur            x1, [fp, #-0x18]
    // 0x78dc6c: r3 = LoadInt32Instr(r1)
    //     0x78dc6c: sbfx            x3, x1, #1, #0x1f
    //     0x78dc70: tbz             w1, #0, #0x78dc78
    //     0x78dc74: ldur            x3, [x1, #7]
    // 0x78dc78: StoreField: r2->field_17 = r3
    //     0x78dc78: stur            x3, [x2, #0x17]
    // 0x78dc7c: mov             x0, x2
    // 0x78dc80: ldr             x1, [fp, #0x10]
    // 0x78dc84: StoreField: r1->field_5b = r0
    //     0x78dc84: stur            w0, [x1, #0x5b]
    //     0x78dc88: ldurb           w16, [x1, #-1]
    //     0x78dc8c: ldurb           w17, [x0, #-1]
    //     0x78dc90: and             x16, x17, x16, lsr #2
    //     0x78dc94: tst             x16, HEAP, lsr #32
    //     0x78dc98: b.eq            #0x78dca0
    //     0x78dc9c: bl              #0xd6826c
    // 0x78dca0: mov             x0, x2
    // 0x78dca4: StoreField: r1->field_5f = r0
    //     0x78dca4: stur            w0, [x1, #0x5f]
    //     0x78dca8: ldurb           w16, [x1, #-1]
    //     0x78dcac: ldurb           w17, [x0, #-1]
    //     0x78dcb0: and             x16, x17, x16, lsr #2
    //     0x78dcb4: tst             x16, HEAP, lsr #32
    //     0x78dcb8: b.eq            #0x78dcc0
    //     0x78dcbc: bl              #0xd6826c
    // 0x78dcc0: r0 = Null
    //     0x78dcc0: mov             x0, NULL
    // 0x78dcc4: LeaveFrame
    //     0x78dcc4: mov             SP, fp
    //     0x78dcc8: ldp             fp, lr, [SP], #0x10
    // 0x78dccc: ret
    //     0x78dccc: ret             
    // 0x78dcd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78dcd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78dcd4: b               #0x78d8ec
    // 0x78dcd8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x78dcd8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x78dcdc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x78dcdc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x78dce0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78dce0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78dce4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x78dce4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x78dce8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78dce8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78dcec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x78dcec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x78dcf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78dcf0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78dcf4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x78dcf4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x78dcf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78dcf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ScaleGestureRecognizer(/* No info */) {
    // ** addr: 0xb28e64, size: 0x17c
    // 0xb28e64: EnterFrame
    //     0xb28e64: stp             fp, lr, [SP, #-0x10]!
    //     0xb28e68: mov             fp, SP
    // 0xb28e6c: r1 = Instance__ScaleState
    //     0xb28e6c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21488] Obj!_ScaleState@b65a11
    //     0xb28e70: ldr             x1, [x1, #0x488]
    // 0xb28e74: r0 = Sentinel
    //     0xb28e74: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb28e78: d1 = 1.000000
    //     0xb28e78: fmov            d1, #1.00000000
    // 0xb28e7c: d0 = 0.000000
    //     0xb28e7c: eor             v0.16b, v0.16b, v0.16b
    // 0xb28e80: CheckStackOverflow
    //     0xb28e80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb28e84: cmp             SP, x16
    //     0xb28e88: b.ls            #0xb28fd8
    // 0xb28e8c: ldr             x2, [fp, #0x10]
    // 0xb28e90: StoreField: r2->field_2f = r1
    //     0xb28e90: stur            w1, [x2, #0x2f]
    // 0xb28e94: StoreField: r2->field_37 = r0
    //     0xb28e94: stur            w0, [x2, #0x37]
    // 0xb28e98: StoreField: r2->field_3f = r0
    //     0xb28e98: stur            w0, [x2, #0x3f]
    // 0xb28e9c: StoreField: r2->field_43 = r0
    //     0xb28e9c: stur            w0, [x2, #0x43]
    // 0xb28ea0: StoreField: r2->field_47 = r0
    //     0xb28ea0: stur            w0, [x2, #0x47]
    // 0xb28ea4: StoreField: r2->field_4b = r0
    //     0xb28ea4: stur            w0, [x2, #0x4b]
    // 0xb28ea8: StoreField: r2->field_4f = r0
    //     0xb28ea8: stur            w0, [x2, #0x4f]
    // 0xb28eac: StoreField: r2->field_53 = r0
    //     0xb28eac: stur            w0, [x2, #0x53]
    // 0xb28eb0: StoreField: r2->field_57 = r0
    //     0xb28eb0: stur            w0, [x2, #0x57]
    // 0xb28eb4: StoreField: r2->field_6f = r0
    //     0xb28eb4: stur            w0, [x2, #0x6f]
    // 0xb28eb8: StoreField: r2->field_77 = d1
    //     0xb28eb8: stur            d1, [x2, #0x77]
    // 0xb28ebc: StoreField: r2->field_7f = d0
    //     0xb28ebc: stur            d0, [x2, #0x7f]
    // 0xb28ec0: r16 = <int, Offset>
    //     0xb28ec0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21490] TypeArguments: <int, Offset>
    //     0xb28ec4: ldr             x16, [x16, #0x490]
    // 0xb28ec8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xb28ecc: stp             lr, x16, [SP, #-0x10]!
    // 0xb28ed0: r0 = Map._fromLiteral()
    //     0xb28ed0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xb28ed4: add             SP, SP, #0x10
    // 0xb28ed8: ldr             x1, [fp, #0x10]
    // 0xb28edc: StoreField: r1->field_63 = r0
    //     0xb28edc: stur            w0, [x1, #0x63]
    //     0xb28ee0: tbz             w0, #0, #0xb28efc
    //     0xb28ee4: ldurb           w16, [x1, #-1]
    //     0xb28ee8: ldurb           w17, [x0, #-1]
    //     0xb28eec: and             x16, x17, x16, lsr #2
    //     0xb28ef0: tst             x16, HEAP, lsr #32
    //     0xb28ef4: b.eq            #0xb28efc
    //     0xb28ef8: bl              #0xd6826c
    // 0xb28efc: r16 = <int>
    //     0xb28efc: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0xb28f00: stp             xzr, x16, [SP, #-0x10]!
    // 0xb28f04: r0 = _GrowableList()
    //     0xb28f04: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xb28f08: add             SP, SP, #0x10
    // 0xb28f0c: ldr             x1, [fp, #0x10]
    // 0xb28f10: StoreField: r1->field_67 = r0
    //     0xb28f10: stur            w0, [x1, #0x67]
    //     0xb28f14: ldurb           w16, [x1, #-1]
    //     0xb28f18: ldurb           w17, [x0, #-1]
    //     0xb28f1c: and             x16, x17, x16, lsr #2
    //     0xb28f20: tst             x16, HEAP, lsr #32
    //     0xb28f24: b.eq            #0xb28f2c
    //     0xb28f28: bl              #0xd6826c
    // 0xb28f2c: r16 = <int, VelocityTracker>
    //     0xb28f2c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21498] TypeArguments: <int, VelocityTracker>
    //     0xb28f30: ldr             x16, [x16, #0x498]
    // 0xb28f34: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xb28f38: stp             lr, x16, [SP, #-0x10]!
    // 0xb28f3c: r0 = Map._fromLiteral()
    //     0xb28f3c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xb28f40: add             SP, SP, #0x10
    // 0xb28f44: ldr             x1, [fp, #0x10]
    // 0xb28f48: StoreField: r1->field_6b = r0
    //     0xb28f48: stur            w0, [x1, #0x6b]
    //     0xb28f4c: tbz             w0, #0, #0xb28f68
    //     0xb28f50: ldurb           w16, [x1, #-1]
    //     0xb28f54: ldurb           w17, [x0, #-1]
    //     0xb28f58: and             x16, x17, x16, lsr #2
    //     0xb28f5c: tst             x16, HEAP, lsr #32
    //     0xb28f60: b.eq            #0xb28f68
    //     0xb28f64: bl              #0xd6826c
    // 0xb28f68: r16 = <int, _PointerPanZoomData>
    //     0xb28f68: add             x16, PP, #0x21, lsl #12  ; [pp+0x214a0] TypeArguments: <int, _PointerPanZoomData>
    //     0xb28f6c: ldr             x16, [x16, #0x4a0]
    // 0xb28f70: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xb28f74: stp             lr, x16, [SP, #-0x10]!
    // 0xb28f78: r0 = Map._fromLiteral()
    //     0xb28f78: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xb28f7c: add             SP, SP, #0x10
    // 0xb28f80: ldr             x1, [fp, #0x10]
    // 0xb28f84: StoreField: r1->field_73 = r0
    //     0xb28f84: stur            w0, [x1, #0x73]
    //     0xb28f88: tbz             w0, #0, #0xb28fa4
    //     0xb28f8c: ldurb           w16, [x1, #-1]
    //     0xb28f90: ldurb           w17, [x0, #-1]
    //     0xb28f94: and             x16, x17, x16, lsr #2
    //     0xb28f98: tst             x16, HEAP, lsr #32
    //     0xb28f9c: b.eq            #0xb28fa4
    //     0xb28fa0: bl              #0xd6826c
    // 0xb28fa4: r0 = Instance_DragStartBehavior
    //     0xb28fa4: add             x0, PP, #0x21, lsl #12  ; [pp+0x214a8] Obj!DragStartBehavior@b65b11
    //     0xb28fa8: ldr             x0, [x0, #0x4a8]
    // 0xb28fac: StoreField: r1->field_1f = r0
    //     0xb28fac: stur            w0, [x1, #0x1f]
    // 0xb28fb0: stp             NULL, x1, [SP, #-0x10]!
    // 0xb28fb4: SaveReg rNULL
    //     0xb28fb4: str             NULL, [SP, #-8]!
    // 0xb28fb8: r4 = const [0, 0x3, 0x3, 0x1, kind, 0x1, supportedDevices, 0x2, null]
    //     0xb28fb8: add             x4, PP, #0x21, lsl #12  ; [pp+0x214b0] List(9) [0, 0x3, 0x3, 0x1, "kind", 0x1, "supportedDevices", 0x2, Null]
    //     0xb28fbc: ldr             x4, [x4, #0x4b0]
    // 0xb28fc0: r0 = OneSequenceGestureRecognizer()
    //     0xb28fc0: bl              #0x6d3ef4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0xb28fc4: add             SP, SP, #0x18
    // 0xb28fc8: r0 = Null
    //     0xb28fc8: mov             x0, NULL
    // 0xb28fcc: LeaveFrame
    //     0xb28fcc: mov             SP, fp
    //     0xb28fd0: ldp             fp, lr, [SP], #0x10
    // 0xb28fd4: ret
    //     0xb28fd4: ret             
    // 0xb28fd8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb28fd8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xb28fdc: b               #0xb28e8c
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbd9350, size: 0x54
    // 0xbd9350: EnterFrame
    //     0xbd9350: stp             fp, lr, [SP, #-0x10]!
    //     0xbd9354: mov             fp, SP
    // 0xbd9358: CheckStackOverflow
    //     0xbd9358: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd935c: cmp             SP, x16
    //     0xbd9360: b.ls            #0xbd939c
    // 0xbd9364: ldr             x0, [fp, #0x10]
    // 0xbd9368: LoadField: r1 = r0->field_6b
    //     0xbd9368: ldur            w1, [x0, #0x6b]
    // 0xbd936c: DecompressPointer r1
    //     0xbd936c: add             x1, x1, HEAP, lsl #32
    // 0xbd9370: SaveReg r1
    //     0xbd9370: str             x1, [SP, #-8]!
    // 0xbd9374: r0 = clear()
    //     0xbd9374: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbd9378: add             SP, SP, #8
    // 0xbd937c: ldr             x16, [fp, #0x10]
    // 0xbd9380: SaveReg r16
    //     0xbd9380: str             x16, [SP, #-8]!
    // 0xbd9384: r0 = dispose()
    //     0xbd9384: bl              #0xbd93a4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0xbd9388: add             SP, SP, #8
    // 0xbd938c: r0 = Null
    //     0xbd938c: mov             x0, NULL
    // 0xbd9390: LeaveFrame
    //     0xbd9390: mov             SP, fp
    //     0xbd9394: ldp             fp, lr, [SP], #0x10
    // 0xbd9398: ret
    //     0xbd9398: ret             
    // 0xbd939c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd939c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd93a0: b               #0xbd9364
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdbe38, size: 0x270
    // 0xbdbe38: EnterFrame
    //     0xbdbe38: stp             fp, lr, [SP, #-0x10]!
    //     0xbdbe3c: mov             fp, SP
    // 0xbdbe40: AllocStack(0x10)
    //     0xbdbe40: sub             SP, SP, #0x10
    // 0xbdbe44: CheckStackOverflow
    //     0xbdbe44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdbe48: cmp             SP, x16
    //     0xbdbe4c: b.ls            #0xbdc078
    // 0xbdbe50: ldr             x0, [fp, #0x18]
    // 0xbdbe54: LoadField: r1 = r0->field_2f
    //     0xbdbe54: ldur            w1, [x0, #0x2f]
    // 0xbdbe58: DecompressPointer r1
    //     0xbdbe58: add             x1, x1, HEAP, lsl #32
    // 0xbdbe5c: r16 = Instance__ScaleState
    //     0xbdbe5c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e18] Obj!_ScaleState@b65a31
    //     0xbdbe60: ldr             x16, [x16, #0xe18]
    // 0xbdbe64: cmp             w1, w16
    // 0xbdbe68: b.ne            #0xbdc068
    // 0xbdbe6c: r1 = Instance__ScaleState
    //     0xbdbe6c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e20] Obj!_ScaleState@b65a71
    //     0xbdbe70: ldr             x1, [x1, #0xe20]
    // 0xbdbe74: StoreField: r0->field_2f = r1
    //     0xbdbe74: stur            w1, [x0, #0x2f]
    // 0xbdbe78: SaveReg r0
    //     0xbdbe78: str             x0, [SP, #-8]!
    // 0xbdbe7c: r0 = _dispatchOnStartCallbackIfNeeded()
    //     0xbdbe7c: bl              #0x78bbec  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_dispatchOnStartCallbackIfNeeded
    // 0xbdbe80: add             SP, SP, #8
    // 0xbdbe84: ldr             x1, [fp, #0x18]
    // 0xbdbe88: LoadField: r0 = r1->field_1f
    //     0xbdbe88: ldur            w0, [x1, #0x1f]
    // 0xbdbe8c: DecompressPointer r0
    //     0xbdbe8c: add             x0, x0, HEAP, lsl #32
    // 0xbdbe90: r16 = Instance_DragStartBehavior
    //     0xbdbe90: add             x16, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0xbdbe94: ldr             x16, [x16, #0xf88]
    // 0xbdbe98: cmp             w0, w16
    // 0xbdbe9c: b.ne            #0xbdc068
    // 0xbdbea0: LoadField: r0 = r1->field_3b
    //     0xbdbea0: ldur            w0, [x1, #0x3b]
    // 0xbdbea4: DecompressPointer r0
    //     0xbdbea4: add             x0, x0, HEAP, lsl #32
    // 0xbdbea8: cmp             w0, NULL
    // 0xbdbeac: b.eq            #0xbdc080
    // 0xbdbeb0: StoreField: r1->field_37 = r0
    //     0xbdbeb0: stur            w0, [x1, #0x37]
    //     0xbdbeb4: ldurb           w16, [x1, #-1]
    //     0xbdbeb8: ldurb           w17, [x0, #-1]
    //     0xbdbebc: and             x16, x17, x16, lsr #2
    //     0xbdbec0: tst             x16, HEAP, lsr #32
    //     0xbdbec4: b.eq            #0xbdbecc
    //     0xbdbec8: bl              #0xd6826c
    // 0xbdbecc: LoadField: r0 = r1->field_43
    //     0xbdbecc: ldur            w0, [x1, #0x43]
    // 0xbdbed0: DecompressPointer r0
    //     0xbdbed0: add             x0, x0, HEAP, lsl #32
    // 0xbdbed4: r16 = Sentinel
    //     0xbdbed4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdbed8: cmp             w0, w16
    // 0xbdbedc: b.eq            #0xbdc084
    // 0xbdbee0: StoreField: r1->field_3f = r0
    //     0xbdbee0: stur            w0, [x1, #0x3f]
    //     0xbdbee4: ldurb           w16, [x1, #-1]
    //     0xbdbee8: ldurb           w17, [x0, #-1]
    //     0xbdbeec: and             x16, x17, x16, lsr #2
    //     0xbdbef0: tst             x16, HEAP, lsr #32
    //     0xbdbef4: b.eq            #0xbdbefc
    //     0xbdbef8: bl              #0xd6826c
    // 0xbdbefc: LoadField: r0 = r1->field_5f
    //     0xbdbefc: ldur            w0, [x1, #0x5f]
    // 0xbdbf00: DecompressPointer r0
    //     0xbdbf00: add             x0, x0, HEAP, lsl #32
    // 0xbdbf04: StoreField: r1->field_5b = r0
    //     0xbdbf04: stur            w0, [x1, #0x5b]
    //     0xbdbf08: ldurb           w16, [x1, #-1]
    //     0xbdbf0c: ldurb           w17, [x0, #-1]
    //     0xbdbf10: and             x16, x17, x16, lsr #2
    //     0xbdbf14: tst             x16, HEAP, lsr #32
    //     0xbdbf18: b.eq            #0xbdbf20
    //     0xbdbf1c: bl              #0xd6826c
    // 0xbdbf20: LoadField: r0 = r1->field_4b
    //     0xbdbf20: ldur            w0, [x1, #0x4b]
    // 0xbdbf24: DecompressPointer r0
    //     0xbdbf24: add             x0, x0, HEAP, lsl #32
    // 0xbdbf28: r16 = Sentinel
    //     0xbdbf28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdbf2c: cmp             w0, w16
    // 0xbdbf30: b.eq            #0xbdc090
    // 0xbdbf34: StoreField: r1->field_47 = r0
    //     0xbdbf34: stur            w0, [x1, #0x47]
    //     0xbdbf38: ldurb           w16, [x1, #-1]
    //     0xbdbf3c: ldurb           w17, [x0, #-1]
    //     0xbdbf40: and             x16, x17, x16, lsr #2
    //     0xbdbf44: tst             x16, HEAP, lsr #32
    //     0xbdbf48: b.eq            #0xbdbf50
    //     0xbdbf4c: bl              #0xd6826c
    // 0xbdbf50: LoadField: r0 = r1->field_53
    //     0xbdbf50: ldur            w0, [x1, #0x53]
    // 0xbdbf54: DecompressPointer r0
    //     0xbdbf54: add             x0, x0, HEAP, lsl #32
    // 0xbdbf58: r16 = Sentinel
    //     0xbdbf58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdbf5c: cmp             w0, w16
    // 0xbdbf60: b.eq            #0xbdc09c
    // 0xbdbf64: StoreField: r1->field_4f = r0
    //     0xbdbf64: stur            w0, [x1, #0x4f]
    //     0xbdbf68: ldurb           w16, [x1, #-1]
    //     0xbdbf6c: ldurb           w17, [x0, #-1]
    //     0xbdbf70: and             x16, x17, x16, lsr #2
    //     0xbdbf74: tst             x16, HEAP, lsr #32
    //     0xbdbf78: b.eq            #0xbdbf80
    //     0xbdbf7c: bl              #0xd6826c
    // 0xbdbf80: LoadField: r0 = r1->field_73
    //     0xbdbf80: ldur            w0, [x1, #0x73]
    // 0xbdbf84: DecompressPointer r0
    //     0xbdbf84: add             x0, x0, HEAP, lsl #32
    // 0xbdbf88: stur            x0, [fp, #-8]
    // 0xbdbf8c: LoadField: r2 = r0->field_13
    //     0xbdbf8c: ldur            w2, [x0, #0x13]
    // 0xbdbf90: DecompressPointer r2
    //     0xbdbf90: add             x2, x2, HEAP, lsl #32
    // 0xbdbf94: r3 = LoadInt32Instr(r2)
    //     0xbdbf94: sbfx            x3, x2, #1, #0x1f
    // 0xbdbf98: asr             x2, x3, #1
    // 0xbdbf9c: LoadField: r3 = r0->field_17
    //     0xbdbf9c: ldur            w3, [x0, #0x17]
    // 0xbdbfa0: DecompressPointer r3
    //     0xbdbfa0: add             x3, x3, HEAP, lsl #32
    // 0xbdbfa4: r4 = LoadInt32Instr(r3)
    //     0xbdbfa4: sbfx            x4, x3, #1, #0x1f
    // 0xbdbfa8: sub             x3, x2, x4
    // 0xbdbfac: cbnz            x3, #0xbdbfc4
    // 0xbdbfb0: d1 = 1.000000
    //     0xbdbfb0: fmov            d1, #1.00000000
    // 0xbdbfb4: d0 = 0.000000
    //     0xbdbfb4: eor             v0.16b, v0.16b, v0.16b
    // 0xbdbfb8: StoreField: r1->field_77 = d1
    //     0xbdbfb8: stur            d1, [x1, #0x77]
    // 0xbdbfbc: StoreField: r1->field_7f = d0
    //     0xbdbfbc: stur            d0, [x1, #0x7f]
    // 0xbdbfc0: b               #0xbdc068
    // 0xbdbfc4: SaveReg r1
    //     0xbdbfc4: str             x1, [SP, #-8]!
    // 0xbdbfc8: r0 = _scaleFactor()
    //     0xbdbfc8: bl              #0x78bdb0  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_scaleFactor
    // 0xbdbfcc: add             SP, SP, #8
    // 0xbdbfd0: stur            d0, [fp, #-0x10]
    // 0xbdbfd4: ldr             x16, [fp, #0x18]
    // 0xbdbfd8: SaveReg r16
    //     0xbdbfd8: str             x16, [SP, #-8]!
    // 0xbdbfdc: r0 = _pointerScaleFactor()
    //     0xbdbfdc: bl              #0xbdc0a8  ; [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_pointerScaleFactor
    // 0xbdbfe0: add             SP, SP, #8
    // 0xbdbfe4: mov             v1.16b, v0.16b
    // 0xbdbfe8: ldur            d0, [fp, #-0x10]
    // 0xbdbfec: fdiv            d2, d0, d1
    // 0xbdbff0: ldr             x0, [fp, #0x18]
    // 0xbdbff4: StoreField: r0->field_77 = d2
    //     0xbdbff4: stur            d2, [x0, #0x77]
    // 0xbdbff8: ldur            x16, [fp, #-8]
    // 0xbdbffc: SaveReg r16
    //     0xbdbffc: str             x16, [SP, #-8]!
    // 0xbdc000: r0 = values()
    //     0xbdc000: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0xbdc004: add             SP, SP, #8
    // 0xbdc008: r1 = Function '<anonymous closure>':.
    //     0xbdc008: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e28] AnonymousClosure: (0x78ced8), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::acceptGesture (0xbdbe38)
    //     0xbdc00c: ldr             x1, [x1, #0xe28]
    // 0xbdc010: r2 = Null
    //     0xbdc010: mov             x2, NULL
    // 0xbdc014: stur            x0, [fp, #-8]
    // 0xbdc018: r0 = AllocateClosure()
    //     0xbdc018: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbdc01c: r16 = <double>
    //     0xbdc01c: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xbdc020: ldur            lr, [fp, #-8]
    // 0xbdc024: stp             lr, x16, [SP, #-0x10]!
    // 0xbdc028: SaveReg r0
    //     0xbdc028: str             x0, [SP, #-8]!
    // 0xbdc02c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbdc02c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbdc030: r0 = map()
    //     0xbdc030: bl              #0x6ba600  ; [dart:core] Iterable::map
    // 0xbdc034: add             SP, SP, #0x18
    // 0xbdc038: r1 = Function '<anonymous closure>':.
    //     0xbdc038: add             x1, PP, #0x28, lsl #12  ; [pp+0x28e30] AnonymousClosure: (0x70410c), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::acceptGesture (0xbdbe38)
    //     0xbdc03c: ldr             x1, [x1, #0xe30]
    // 0xbdc040: r2 = Null
    //     0xbdc040: mov             x2, NULL
    // 0xbdc044: stur            x0, [fp, #-8]
    // 0xbdc048: r0 = AllocateClosure()
    //     0xbdc048: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbdc04c: ldur            x16, [fp, #-8]
    // 0xbdc050: stp             x0, x16, [SP, #-0x10]!
    // 0xbdc054: r0 = reduce()
    //     0xbdc054: bl              #0x78cb5c  ; [dart:core] Iterable::reduce
    // 0xbdc058: add             SP, SP, #0x10
    // 0xbdc05c: LoadField: d0 = r0->field_7
    //     0xbdc05c: ldur            d0, [x0, #7]
    // 0xbdc060: ldr             x1, [fp, #0x18]
    // 0xbdc064: StoreField: r1->field_7f = d0
    //     0xbdc064: stur            d0, [x1, #0x7f]
    // 0xbdc068: r0 = Null
    //     0xbdc068: mov             x0, NULL
    // 0xbdc06c: LeaveFrame
    //     0xbdc06c: mov             SP, fp
    //     0xbdc070: ldp             fp, lr, [SP], #0x10
    // 0xbdc074: ret
    //     0xbdc074: ret             
    // 0xbdc078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc07c: b               #0xbdbe50
    // 0xbdc080: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdc080: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbdc084: r9 = _currentSpan
    //     0xbdc084: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e38] Field <ScaleGestureRecognizer._currentSpan@672213599>: late (offset: 0x44)
    //     0xbdc088: ldr             x9, [x9, #0xe38]
    // 0xbdc08c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdc08c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbdc090: r9 = _currentHorizontalSpan
    //     0xbdc090: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e40] Field <ScaleGestureRecognizer._currentHorizontalSpan@672213599>: late (offset: 0x4c)
    //     0xbdc094: ldr             x9, [x9, #0xe40]
    // 0xbdc098: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdc098: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbdc09c: r9 = _currentVerticalSpan
    //     0xbdc09c: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e48] Field <ScaleGestureRecognizer._currentVerticalSpan@672213599>: late (offset: 0x54)
    //     0xbdc0a0: ldr             x9, [x9, #0xe48]
    // 0xbdc0a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdc0a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _pointerScaleFactor(/* No info */) {
    // ** addr: 0xbdc0a8, size: 0x80
    // 0xbdc0a8: EnterFrame
    //     0xbdc0a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc0ac: mov             fp, SP
    // 0xbdc0b0: d1 = 0.000000
    //     0xbdc0b0: eor             v1.16b, v1.16b, v1.16b
    // 0xbdc0b4: ldr             x0, [fp, #0x10]
    // 0xbdc0b8: LoadField: r1 = r0->field_3f
    //     0xbdc0b8: ldur            w1, [x0, #0x3f]
    // 0xbdc0bc: DecompressPointer r1
    //     0xbdc0bc: add             x1, x1, HEAP, lsl #32
    // 0xbdc0c0: r16 = Sentinel
    //     0xbdc0c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdc0c4: cmp             w1, w16
    // 0xbdc0c8: b.eq            #0xbdc110
    // 0xbdc0cc: LoadField: d2 = r1->field_7
    //     0xbdc0cc: ldur            d2, [x1, #7]
    // 0xbdc0d0: fcmp            d2, d1
    // 0xbdc0d4: b.vs            #0xbdc100
    // 0xbdc0d8: b.le            #0xbdc100
    // 0xbdc0dc: LoadField: r1 = r0->field_43
    //     0xbdc0dc: ldur            w1, [x0, #0x43]
    // 0xbdc0e0: DecompressPointer r1
    //     0xbdc0e0: add             x1, x1, HEAP, lsl #32
    // 0xbdc0e4: r16 = Sentinel
    //     0xbdc0e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdc0e8: cmp             w1, w16
    // 0xbdc0ec: b.eq            #0xbdc11c
    // 0xbdc0f0: LoadField: d1 = r1->field_7
    //     0xbdc0f0: ldur            d1, [x1, #7]
    // 0xbdc0f4: fdiv            d3, d1, d2
    // 0xbdc0f8: mov             v0.16b, v3.16b
    // 0xbdc0fc: b               #0xbdc104
    // 0xbdc100: d0 = 1.000000
    //     0xbdc100: fmov            d0, #1.00000000
    // 0xbdc104: LeaveFrame
    //     0xbdc104: mov             SP, fp
    //     0xbdc108: ldp             fp, lr, [SP], #0x10
    // 0xbdc10c: ret
    //     0xbdc10c: ret             
    // 0xbdc110: r9 = _initialSpan
    //     0xbdc110: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e80] Field <ScaleGestureRecognizer._initialSpan@672213599>: late (offset: 0x40)
    //     0xbdc114: ldr             x9, [x9, #0xe80]
    // 0xbdc118: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbdc118: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbdc11c: r9 = _currentSpan
    //     0xbdc11c: add             x9, PP, #0x28, lsl #12  ; [pp+0x28e38] Field <ScaleGestureRecognizer._currentSpan@672213599>: late (offset: 0x44)
    //     0xbdc120: ldr             x9, [x9, #0xe38]
    // 0xbdc124: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbdc124: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee4c8, size: 0xb0
    // 0xcee4c8: EnterFrame
    //     0xcee4c8: stp             fp, lr, [SP, #-0x10]!
    //     0xcee4cc: mov             fp, SP
    // 0xcee4d0: AllocStack(0x8)
    //     0xcee4d0: sub             SP, SP, #8
    // 0xcee4d4: CheckStackOverflow
    //     0xcee4d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee4d8: cmp             SP, x16
    //     0xcee4dc: b.ls            #0xcee570
    // 0xcee4e0: ldr             x2, [fp, #0x18]
    // 0xcee4e4: LoadField: r3 = r2->field_73
    //     0xcee4e4: ldur            w3, [x2, #0x73]
    // 0xcee4e8: DecompressPointer r3
    //     0xcee4e8: add             x3, x3, HEAP, lsl #32
    // 0xcee4ec: ldr             x4, [fp, #0x10]
    // 0xcee4f0: r0 = BoxInt64Instr(r4)
    //     0xcee4f0: sbfiz           x0, x4, #1, #0x1f
    //     0xcee4f4: cmp             x4, x0, asr #1
    //     0xcee4f8: b.eq            #0xcee504
    //     0xcee4fc: bl              #0xd69bb8
    //     0xcee500: stur            x4, [x0, #7]
    // 0xcee504: stur            x0, [fp, #-8]
    // 0xcee508: stp             x0, x3, [SP, #-0x10]!
    // 0xcee50c: r0 = remove()
    //     0xcee50c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xcee510: add             SP, SP, #0x10
    // 0xcee514: ldr             x0, [fp, #0x18]
    // 0xcee518: LoadField: r1 = r0->field_63
    //     0xcee518: ldur            w1, [x0, #0x63]
    // 0xcee51c: DecompressPointer r1
    //     0xcee51c: add             x1, x1, HEAP, lsl #32
    // 0xcee520: ldur            x16, [fp, #-8]
    // 0xcee524: stp             x16, x1, [SP, #-0x10]!
    // 0xcee528: r0 = remove()
    //     0xcee528: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xcee52c: add             SP, SP, #0x10
    // 0xcee530: ldr             x0, [fp, #0x18]
    // 0xcee534: LoadField: r1 = r0->field_67
    //     0xcee534: ldur            w1, [x0, #0x67]
    // 0xcee538: DecompressPointer r1
    //     0xcee538: add             x1, x1, HEAP, lsl #32
    // 0xcee53c: ldur            x16, [fp, #-8]
    // 0xcee540: stp             x16, x1, [SP, #-0x10]!
    // 0xcee544: r0 = remove()
    //     0xcee544: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0xcee548: add             SP, SP, #0x10
    // 0xcee54c: ldr             x16, [fp, #0x18]
    // 0xcee550: ldur            lr, [fp, #-8]
    // 0xcee554: stp             lr, x16, [SP, #-0x10]!
    // 0xcee558: r0 = stopTrackingPointer()
    //     0xcee558: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xcee55c: add             SP, SP, #0x10
    // 0xcee560: r0 = Null
    //     0xcee560: mov             x0, NULL
    // 0xcee564: LeaveFrame
    //     0xcee564: mov             SP, fp
    //     0xcee568: ldp             fp, lr, [SP], #0x10
    // 0xcee56c: ret
    //     0xcee56c: ret             
    // 0xcee570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee574: b               #0xcee4e0
  }
}

// class id: 5976, size: 0x14, field offset: 0x14
enum _ScaleState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15eb4, size: 0x5c
    // 0xb15eb4: EnterFrame
    //     0xb15eb4: stp             fp, lr, [SP, #-0x10]!
    //     0xb15eb8: mov             fp, SP
    // 0xb15ebc: CheckStackOverflow
    //     0xb15ebc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15ec0: cmp             SP, x16
    //     0xb15ec4: b.ls            #0xb15f08
    // 0xb15ec8: r1 = Null
    //     0xb15ec8: mov             x1, NULL
    // 0xb15ecc: r2 = 4
    //     0xb15ecc: mov             x2, #4
    // 0xb15ed0: r0 = AllocateArray()
    //     0xb15ed0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15ed4: r17 = "_ScaleState."
    //     0xb15ed4: add             x17, PP, #0x28, lsl #12  ; [pp+0x28e10] "_ScaleState."
    //     0xb15ed8: ldr             x17, [x17, #0xe10]
    // 0xb15edc: StoreField: r0->field_f = r17
    //     0xb15edc: stur            w17, [x0, #0xf]
    // 0xb15ee0: ldr             x1, [fp, #0x10]
    // 0xb15ee4: LoadField: r2 = r1->field_f
    //     0xb15ee4: ldur            w2, [x1, #0xf]
    // 0xb15ee8: DecompressPointer r2
    //     0xb15ee8: add             x2, x2, HEAP, lsl #32
    // 0xb15eec: StoreField: r0->field_13 = r2
    //     0xb15eec: stur            w2, [x0, #0x13]
    // 0xb15ef0: SaveReg r0
    //     0xb15ef0: str             x0, [SP, #-8]!
    // 0xb15ef4: r0 = _interpolate()
    //     0xb15ef4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15ef8: add             SP, SP, #8
    // 0xb15efc: LeaveFrame
    //     0xb15efc: mov             SP, fp
    //     0xb15f00: ldp             fp, lr, [SP], #0x10
    // 0xb15f04: ret
    //     0xb15f04: ret             
    // 0xb15f08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15f08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15f0c: b               #0xb15ec8
  }
}

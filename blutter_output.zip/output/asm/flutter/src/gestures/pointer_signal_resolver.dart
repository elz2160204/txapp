// lib: , url: package:flutter/src/gestures/pointer_signal_resolver.dart

// class id: 1049167, size: 0x8
class :: {
}

// class id: 2265, size: 0x10, field offset: 0x8
class PointerSignalResolver extends Object {

  _ resolve(/* No info */) {
    // ** addr: 0x714d04, size: 0x10c
    // 0x714d04: EnterFrame
    //     0x714d04: stp             fp, lr, [SP, #-0x10]!
    //     0x714d08: mov             fp, SP
    // 0x714d0c: AllocStack(0x68)
    //     0x714d0c: sub             SP, SP, #0x68
    // 0x714d10: CheckStackOverflow
    //     0x714d10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714d14: cmp             SP, x16
    //     0x714d18: b.ls            #0x714e04
    // 0x714d1c: ldr             x1, [fp, #0x10]
    // 0x714d20: LoadField: r2 = r1->field_7
    //     0x714d20: ldur            w2, [x1, #7]
    // 0x714d24: DecompressPointer r2
    //     0x714d24: add             x2, x2, HEAP, lsl #32
    // 0x714d28: stur            x2, [fp, #-0x58]
    // 0x714d2c: cmp             w2, NULL
    // 0x714d30: b.ne            #0x714d44
    // 0x714d34: r0 = Null
    //     0x714d34: mov             x0, NULL
    // 0x714d38: LeaveFrame
    //     0x714d38: mov             SP, fp
    //     0x714d3c: ldp             fp, lr, [SP], #0x10
    // 0x714d40: ret
    //     0x714d40: ret             
    // 0x714d44: LoadField: r0 = r1->field_b
    //     0x714d44: ldur            w0, [x1, #0xb]
    // 0x714d48: DecompressPointer r0
    //     0x714d48: add             x0, x0, HEAP, lsl #32
    // 0x714d4c: cmp             w0, NULL
    // 0x714d50: b.eq            #0x714e0c
    // 0x714d54: stp             x0, x2, [SP, #-0x10]!
    // 0x714d58: mov             x0, x2
    // 0x714d5c: ClosureCall
    //     0x714d5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x714d60: ldur            x2, [x0, #0x1f]
    //     0x714d64: blr             x2
    // 0x714d68: add             SP, SP, #0x10
    // 0x714d6c: ldr             x1, [fp, #0x10]
    // 0x714d70: b               #0x714dec
    // 0x714d74: sub             SP, fp, #0x68
    // 0x714d78: mov             x2, x0
    // 0x714d7c: stur            x0, [fp, #-0x58]
    // 0x714d80: mov             x0, x1
    // 0x714d84: stur            x1, [fp, #-0x60]
    // 0x714d88: r1 = <List<Object>>
    //     0x714d88: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x714d8c: r0 = ErrorDescription()
    //     0x714d8c: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x714d90: stur            x0, [fp, #-0x68]
    // 0x714d94: r16 = "while resolving a PointerSignalEvent"
    //     0x714d94: ldr             x16, [PP, #0x7580]  ; [pp+0x7580] "while resolving a PointerSignalEvent"
    // 0x714d98: stp             x16, x0, [SP, #-0x10]!
    // 0x714d9c: r16 = Instance_DiagnosticLevel
    //     0x714d9c: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x714da0: SaveReg r16
    //     0x714da0: str             x16, [SP, #-8]!
    // 0x714da4: r0 = _ErrorDiagnostic()
    //     0x714da4: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x714da8: add             SP, SP, #0x18
    // 0x714dac: r0 = FlutterErrorDetails()
    //     0x714dac: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x714db0: mov             x1, x0
    // 0x714db4: ldur            x0, [fp, #-0x58]
    // 0x714db8: StoreField: r1->field_7 = r0
    //     0x714db8: stur            w0, [x1, #7]
    // 0x714dbc: ldur            x0, [fp, #-0x60]
    // 0x714dc0: StoreField: r1->field_b = r0
    //     0x714dc0: stur            w0, [x1, #0xb]
    // 0x714dc4: r0 = "gesture library"
    //     0x714dc4: ldr             x0, [PP, #0x38f8]  ; [pp+0x38f8] "gesture library"
    // 0x714dc8: StoreField: r1->field_f = r0
    //     0x714dc8: stur            w0, [x1, #0xf]
    // 0x714dcc: ldur            x0, [fp, #-0x68]
    // 0x714dd0: StoreField: r1->field_13 = r0
    //     0x714dd0: stur            w0, [x1, #0x13]
    // 0x714dd4: r0 = false
    //     0x714dd4: add             x0, NULL, #0x30  ; false
    // 0x714dd8: StoreField: r1->field_1f = r0
    //     0x714dd8: stur            w0, [x1, #0x1f]
    // 0x714ddc: SaveReg r1
    //     0x714ddc: str             x1, [SP, #-8]!
    // 0x714de0: r0 = reportError()
    //     0x714de0: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x714de4: add             SP, SP, #8
    // 0x714de8: ldr             x1, [fp, #0x10]
    // 0x714dec: StoreField: r1->field_7 = rNULL
    //     0x714dec: stur            NULL, [x1, #7]
    // 0x714df0: StoreField: r1->field_b = rNULL
    //     0x714df0: stur            NULL, [x1, #0xb]
    // 0x714df4: r0 = Null
    //     0x714df4: mov             x0, NULL
    // 0x714df8: LeaveFrame
    //     0x714df8: mov             SP, fp
    //     0x714dfc: ldp             fp, lr, [SP], #0x10
    // 0x714e00: ret
    //     0x714e00: ret             
    // 0x714e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714e04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714e08: b               #0x714d1c
    // 0x714e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x714e0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ register(/* No info */) {
    // ** addr: 0x8306fc, size: 0x7c
    // 0x8306fc: EnterFrame
    //     0x8306fc: stp             fp, lr, [SP, #-0x10]!
    //     0x830700: mov             fp, SP
    // 0x830704: ldr             x1, [fp, #0x20]
    // 0x830708: LoadField: r2 = r1->field_7
    //     0x830708: ldur            w2, [x1, #7]
    // 0x83070c: DecompressPointer r2
    //     0x83070c: add             x2, x2, HEAP, lsl #32
    // 0x830710: cmp             w2, NULL
    // 0x830714: b.eq            #0x830728
    // 0x830718: r0 = Null
    //     0x830718: mov             x0, NULL
    // 0x83071c: LeaveFrame
    //     0x83071c: mov             SP, fp
    //     0x830720: ldp             fp, lr, [SP], #0x10
    // 0x830724: ret
    //     0x830724: ret             
    // 0x830728: ldr             x0, [fp, #0x18]
    // 0x83072c: StoreField: r1->field_b = r0
    //     0x83072c: stur            w0, [x1, #0xb]
    //     0x830730: ldurb           w16, [x1, #-1]
    //     0x830734: ldurb           w17, [x0, #-1]
    //     0x830738: and             x16, x17, x16, lsr #2
    //     0x83073c: tst             x16, HEAP, lsr #32
    //     0x830740: b.eq            #0x830748
    //     0x830744: bl              #0xd6826c
    // 0x830748: ldr             x0, [fp, #0x10]
    // 0x83074c: StoreField: r1->field_7 = r0
    //     0x83074c: stur            w0, [x1, #7]
    //     0x830750: ldurb           w16, [x1, #-1]
    //     0x830754: ldurb           w17, [x0, #-1]
    //     0x830758: and             x16, x17, x16, lsr #2
    //     0x83075c: tst             x16, HEAP, lsr #32
    //     0x830760: b.eq            #0x830768
    //     0x830764: bl              #0xd6826c
    // 0x830768: r0 = Null
    //     0x830768: mov             x0, NULL
    // 0x83076c: LeaveFrame
    //     0x83076c: mov             SP, fp
    //     0x830770: ldp             fp, lr, [SP], #0x10
    // 0x830774: ret
    //     0x830774: ret             
  }
}

// lib: , url: package:flutter/src/gestures/gesture_settings.dart

// class id: 1049159, size: 0x8
class :: {
}

// class id: 2289, size: 0xc, field offset: 0x8
//   const constructor, 
class DeviceGestureSettings extends Object {

  factory _ DeviceGestureSettings.fromWindow(/* No info */) {
    // ** addr: 0x87fbfc, size: 0x138
    // 0x87fbfc: EnterFrame
    //     0x87fbfc: stp             fp, lr, [SP, #-0x10]!
    //     0x87fc00: mov             fp, SP
    // 0x87fc04: AllocStack(0x18)
    //     0x87fc04: sub             SP, SP, #0x18
    // 0x87fc08: CheckStackOverflow
    //     0x87fc08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x87fc0c: cmp             SP, x16
    //     0x87fc10: b.ls            #0x87fd14
    // 0x87fc14: ldr             x0, [fp, #0x10]
    // 0x87fc18: LoadField: r1 = r0->field_b
    //     0x87fc18: ldur            w1, [x0, #0xb]
    // 0x87fc1c: DecompressPointer r1
    //     0x87fc1c: add             x1, x1, HEAP, lsl #32
    // 0x87fc20: LoadField: r2 = r1->field_17
    //     0x87fc20: ldur            w2, [x1, #0x17]
    // 0x87fc24: DecompressPointer r2
    //     0x87fc24: add             x2, x2, HEAP, lsl #32
    // 0x87fc28: stur            x2, [fp, #-0x10]
    // 0x87fc2c: LoadField: r1 = r0->field_7
    //     0x87fc2c: ldur            w1, [x0, #7]
    // 0x87fc30: DecompressPointer r1
    //     0x87fc30: add             x1, x1, HEAP, lsl #32
    // 0x87fc34: stur            x1, [fp, #-8]
    // 0x87fc38: stp             x1, x2, [SP, #-0x10]!
    // 0x87fc3c: r0 = _getValueOrData()
    //     0x87fc3c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x87fc40: add             SP, SP, #0x10
    // 0x87fc44: mov             x1, x0
    // 0x87fc48: ldur            x0, [fp, #-0x10]
    // 0x87fc4c: LoadField: r2 = r0->field_f
    //     0x87fc4c: ldur            w2, [x0, #0xf]
    // 0x87fc50: DecompressPointer r2
    //     0x87fc50: add             x2, x2, HEAP, lsl #32
    // 0x87fc54: cmp             w2, w1
    // 0x87fc58: b.ne            #0x87fc60
    // 0x87fc5c: r1 = Null
    //     0x87fc5c: mov             x1, NULL
    // 0x87fc60: cmp             w1, NULL
    // 0x87fc64: b.eq            #0x87fd1c
    // 0x87fc68: LoadField: r2 = r1->field_2b
    //     0x87fc68: ldur            w2, [x1, #0x2b]
    // 0x87fc6c: DecompressPointer r2
    //     0x87fc6c: add             x2, x2, HEAP, lsl #32
    // 0x87fc70: LoadField: r1 = r2->field_7
    //     0x87fc70: ldur            w1, [x2, #7]
    // 0x87fc74: DecompressPointer r1
    //     0x87fc74: add             x1, x1, HEAP, lsl #32
    // 0x87fc78: stur            x1, [fp, #-0x18]
    // 0x87fc7c: cmp             w1, NULL
    // 0x87fc80: b.ne            #0x87fc8c
    // 0x87fc84: r0 = Null
    //     0x87fc84: mov             x0, NULL
    // 0x87fc88: b               #0x87fcf8
    // 0x87fc8c: ldur            x16, [fp, #-8]
    // 0x87fc90: stp             x16, x0, [SP, #-0x10]!
    // 0x87fc94: r0 = _getValueOrData()
    //     0x87fc94: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x87fc98: add             SP, SP, #0x10
    // 0x87fc9c: mov             x1, x0
    // 0x87fca0: ldur            x0, [fp, #-0x10]
    // 0x87fca4: LoadField: r2 = r0->field_f
    //     0x87fca4: ldur            w2, [x0, #0xf]
    // 0x87fca8: DecompressPointer r2
    //     0x87fca8: add             x2, x2, HEAP, lsl #32
    // 0x87fcac: cmp             w2, w1
    // 0x87fcb0: b.ne            #0x87fcb8
    // 0x87fcb4: r1 = Null
    //     0x87fcb4: mov             x1, NULL
    // 0x87fcb8: ldur            x0, [fp, #-0x18]
    // 0x87fcbc: cmp             w1, NULL
    // 0x87fcc0: b.eq            #0x87fd20
    // 0x87fcc4: LoadField: d0 = r1->field_b
    //     0x87fcc4: ldur            d0, [x1, #0xb]
    // 0x87fcc8: LoadField: d1 = r0->field_7
    //     0x87fcc8: ldur            d1, [x0, #7]
    // 0x87fccc: fdiv            d2, d1, d0
    // 0x87fcd0: r0 = inline_Allocate_Double()
    //     0x87fcd0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x87fcd4: add             x0, x0, #0x10
    //     0x87fcd8: cmp             x1, x0
    //     0x87fcdc: b.ls            #0x87fd24
    //     0x87fce0: str             x0, [THR, #0x60]  ; THR::top
    //     0x87fce4: sub             x0, x0, #0xf
    //     0x87fce8: mov             x1, #0xd108
    //     0x87fcec: movk            x1, #3, lsl #16
    //     0x87fcf0: stur            x1, [x0, #-1]
    // 0x87fcf4: StoreField: r0->field_7 = d2
    //     0x87fcf4: stur            d2, [x0, #7]
    // 0x87fcf8: stur            x0, [fp, #-8]
    // 0x87fcfc: r0 = DeviceGestureSettings()
    //     0x87fcfc: bl              #0x87fd34  ; AllocateDeviceGestureSettingsStub -> DeviceGestureSettings (size=0xc)
    // 0x87fd00: ldur            x1, [fp, #-8]
    // 0x87fd04: StoreField: r0->field_7 = r1
    //     0x87fd04: stur            w1, [x0, #7]
    // 0x87fd08: LeaveFrame
    //     0x87fd08: mov             SP, fp
    //     0x87fd0c: ldp             fp, lr, [SP], #0x10
    // 0x87fd10: ret
    //     0x87fd10: ret             
    // 0x87fd14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87fd14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87fd18: b               #0x87fc14
    // 0x87fd1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87fd1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87fd20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87fd20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87fd24: SaveReg d2
    //     0x87fd24: str             q2, [SP, #-0x10]!
    // 0x87fd28: r0 = AllocateDouble()
    //     0x87fd28: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x87fd2c: RestoreReg d2
    //     0x87fd2c: ldr             q2, [SP], #0x10
    // 0x87fd30: b               #0x87fcf4
  }
  _ toString(/* No info */) {
    // ** addr: 0xad94c0, size: 0x64
    // 0xad94c0: EnterFrame
    //     0xad94c0: stp             fp, lr, [SP, #-0x10]!
    //     0xad94c4: mov             fp, SP
    // 0xad94c8: CheckStackOverflow
    //     0xad94c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad94cc: cmp             SP, x16
    //     0xad94d0: b.ls            #0xad951c
    // 0xad94d4: r1 = Null
    //     0xad94d4: mov             x1, NULL
    // 0xad94d8: r2 = 6
    //     0xad94d8: mov             x2, #6
    // 0xad94dc: r0 = AllocateArray()
    //     0xad94dc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad94e0: r17 = "DeviceGestureSettings(touchSlop: "
    //     0xad94e0: add             x17, PP, #0x22, lsl #12  ; [pp+0x22120] "DeviceGestureSettings(touchSlop: "
    //     0xad94e4: ldr             x17, [x17, #0x120]
    // 0xad94e8: StoreField: r0->field_f = r17
    //     0xad94e8: stur            w17, [x0, #0xf]
    // 0xad94ec: ldr             x1, [fp, #0x10]
    // 0xad94f0: LoadField: r2 = r1->field_7
    //     0xad94f0: ldur            w2, [x1, #7]
    // 0xad94f4: DecompressPointer r2
    //     0xad94f4: add             x2, x2, HEAP, lsl #32
    // 0xad94f8: StoreField: r0->field_13 = r2
    //     0xad94f8: stur            w2, [x0, #0x13]
    // 0xad94fc: r17 = ")"
    //     0xad94fc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9500: StoreField: r0->field_17 = r17
    //     0xad9500: stur            w17, [x0, #0x17]
    // 0xad9504: SaveReg r0
    //     0xad9504: str             x0, [SP, #-8]!
    // 0xad9508: r0 = _interpolate()
    //     0xad9508: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad950c: add             SP, SP, #8
    // 0xad9510: LeaveFrame
    //     0xad9510: mov             SP, fp
    //     0xad9514: ldp             fp, lr, [SP], #0x10
    // 0xad9518: ret
    //     0xad9518: ret             
    // 0xad951c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad951c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9520: b               #0xad94d4
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0d6d4, size: 0x60
    // 0xb0d6d4: EnterFrame
    //     0xb0d6d4: stp             fp, lr, [SP, #-0x10]!
    //     0xb0d6d8: mov             fp, SP
    // 0xb0d6dc: CheckStackOverflow
    //     0xb0d6dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0d6e0: cmp             SP, x16
    //     0xb0d6e4: b.ls            #0xb0d72c
    // 0xb0d6e8: ldr             x0, [fp, #0x10]
    // 0xb0d6ec: LoadField: r1 = r0->field_7
    //     0xb0d6ec: ldur            w1, [x0, #7]
    // 0xb0d6f0: DecompressPointer r1
    //     0xb0d6f0: add             x1, x1, HEAP, lsl #32
    // 0xb0d6f4: r16 = 46
    //     0xb0d6f4: mov             x16, #0x2e
    // 0xb0d6f8: stp             x16, x1, [SP, #-0x10]!
    // 0xb0d6fc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xb0d6fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xb0d700: r0 = hash()
    //     0xb0d700: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0d704: add             SP, SP, #0x10
    // 0xb0d708: mov             x2, x0
    // 0xb0d70c: r0 = BoxInt64Instr(r2)
    //     0xb0d70c: sbfiz           x0, x2, #1, #0x1f
    //     0xb0d710: cmp             x2, x0, asr #1
    //     0xb0d714: b.eq            #0xb0d720
    //     0xb0d718: bl              #0xd69bb8
    //     0xb0d71c: stur            x2, [x0, #7]
    // 0xb0d720: LeaveFrame
    //     0xb0d720: mov             SP, fp
    //     0xb0d724: ldp             fp, lr, [SP], #0x10
    // 0xb0d728: ret
    //     0xb0d728: ret             
    // 0xb0d72c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0d72c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0d730: b               #0xb0d6e8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9857c, size: 0x108
    // 0xc9857c: EnterFrame
    //     0xc9857c: stp             fp, lr, [SP, #-0x10]!
    //     0xc98580: mov             fp, SP
    // 0xc98584: CheckStackOverflow
    //     0xc98584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc98588: cmp             SP, x16
    //     0xc9858c: b.ls            #0xc9867c
    // 0xc98590: ldr             x1, [fp, #0x10]
    // 0xc98594: cmp             w1, NULL
    // 0xc98598: b.ne            #0xc985ac
    // 0xc9859c: r0 = false
    //     0xc9859c: add             x0, NULL, #0x30  ; false
    // 0xc985a0: LeaveFrame
    //     0xc985a0: mov             SP, fp
    //     0xc985a4: ldp             fp, lr, [SP], #0x10
    // 0xc985a8: ret
    //     0xc985a8: ret             
    // 0xc985ac: r0 = 59
    //     0xc985ac: mov             x0, #0x3b
    // 0xc985b0: branchIfSmi(r1, 0xc985bc)
    //     0xc985b0: tbz             w1, #0, #0xc985bc
    // 0xc985b4: r0 = LoadClassIdInstr(r1)
    //     0xc985b4: ldur            x0, [x1, #-1]
    //     0xc985b8: ubfx            x0, x0, #0xc, #0x14
    // 0xc985bc: SaveReg r1
    //     0xc985bc: str             x1, [SP, #-8]!
    // 0xc985c0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc985c0: mov             x17, #0x57c5
    //     0xc985c4: add             lr, x0, x17
    //     0xc985c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc985cc: blr             lr
    // 0xc985d0: add             SP, SP, #8
    // 0xc985d4: r1 = LoadClassIdInstr(r0)
    //     0xc985d4: ldur            x1, [x0, #-1]
    //     0xc985d8: ubfx            x1, x1, #0xc, #0x14
    // 0xc985dc: r16 = DeviceGestureSettings
    //     0xc985dc: add             x16, PP, #0x22, lsl #12  ; [pp+0x22128] Type: DeviceGestureSettings
    //     0xc985e0: ldr             x16, [x16, #0x128]
    // 0xc985e4: stp             x16, x0, [SP, #-0x10]!
    // 0xc985e8: mov             x0, x1
    // 0xc985ec: mov             lr, x0
    // 0xc985f0: ldr             lr, [x21, lr, lsl #3]
    // 0xc985f4: blr             lr
    // 0xc985f8: add             SP, SP, #0x10
    // 0xc985fc: tbz             w0, #4, #0xc98610
    // 0xc98600: r0 = false
    //     0xc98600: add             x0, NULL, #0x30  ; false
    // 0xc98604: LeaveFrame
    //     0xc98604: mov             SP, fp
    //     0xc98608: ldp             fp, lr, [SP], #0x10
    // 0xc9860c: ret
    //     0xc9860c: ret             
    // 0xc98610: ldr             x0, [fp, #0x10]
    // 0xc98614: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc98614: mov             x1, #0x76
    //     0xc98618: tbz             w0, #0, #0xc98628
    //     0xc9861c: ldur            x1, [x0, #-1]
    //     0xc98620: ubfx            x1, x1, #0xc, #0x14
    //     0xc98624: lsl             x1, x1, #1
    // 0xc98628: r17 = 4578
    //     0xc98628: mov             x17, #0x11e2
    // 0xc9862c: cmp             w1, w17
    // 0xc98630: b.ne            #0xc9866c
    // 0xc98634: ldr             x1, [fp, #0x18]
    // 0xc98638: LoadField: r2 = r0->field_7
    //     0xc98638: ldur            w2, [x0, #7]
    // 0xc9863c: DecompressPointer r2
    //     0xc9863c: add             x2, x2, HEAP, lsl #32
    // 0xc98640: LoadField: r0 = r1->field_7
    //     0xc98640: ldur            w0, [x1, #7]
    // 0xc98644: DecompressPointer r0
    //     0xc98644: add             x0, x0, HEAP, lsl #32
    // 0xc98648: r1 = LoadClassIdInstr(r2)
    //     0xc98648: ldur            x1, [x2, #-1]
    //     0xc9864c: ubfx            x1, x1, #0xc, #0x14
    // 0xc98650: stp             x0, x2, [SP, #-0x10]!
    // 0xc98654: mov             x0, x1
    // 0xc98658: mov             lr, x0
    // 0xc9865c: ldr             lr, [x21, lr, lsl #3]
    // 0xc98660: blr             lr
    // 0xc98664: add             SP, SP, #0x10
    // 0xc98668: b               #0xc98670
    // 0xc9866c: r0 = false
    //     0xc9866c: add             x0, NULL, #0x30  ; false
    // 0xc98670: LeaveFrame
    //     0xc98670: mov             SP, fp
    //     0xc98674: ldp             fp, lr, [SP], #0x10
    // 0xc98678: ret
    //     0xc98678: ret             
    // 0xc9867c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9867c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc98680: b               #0xc98590
  }
}

// lib: , url: package:flutter/src/gestures/velocity_tracker.dart

// class id: 1049173, size: 0x8
class :: {
}

// class id: 2251, size: 0x10, field offset: 0x8
//   const constructor, 
class _PointAtTime extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xada160, size: 0x78
    // 0xada160: EnterFrame
    //     0xada160: stp             fp, lr, [SP, #-0x10]!
    //     0xada164: mov             fp, SP
    // 0xada168: CheckStackOverflow
    //     0xada168: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xada16c: cmp             SP, x16
    //     0xada170: b.ls            #0xada1d0
    // 0xada174: r1 = Null
    //     0xada174: mov             x1, NULL
    // 0xada178: r2 = 10
    //     0xada178: mov             x2, #0xa
    // 0xada17c: r0 = AllocateArray()
    //     0xada17c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada180: r17 = "_PointAtTime("
    //     0xada180: add             x17, PP, #0x40, lsl #12  ; [pp+0x40dd8] "_PointAtTime("
    //     0xada184: ldr             x17, [x17, #0xdd8]
    // 0xada188: StoreField: r0->field_f = r17
    //     0xada188: stur            w17, [x0, #0xf]
    // 0xada18c: ldr             x1, [fp, #0x10]
    // 0xada190: LoadField: r2 = r1->field_b
    //     0xada190: ldur            w2, [x1, #0xb]
    // 0xada194: DecompressPointer r2
    //     0xada194: add             x2, x2, HEAP, lsl #32
    // 0xada198: StoreField: r0->field_13 = r2
    //     0xada198: stur            w2, [x0, #0x13]
    // 0xada19c: r17 = " at "
    //     0xada19c: ldr             x17, [PP, #0x71c0]  ; [pp+0x71c0] " at "
    // 0xada1a0: StoreField: r0->field_17 = r17
    //     0xada1a0: stur            w17, [x0, #0x17]
    // 0xada1a4: LoadField: r2 = r1->field_7
    //     0xada1a4: ldur            w2, [x1, #7]
    // 0xada1a8: DecompressPointer r2
    //     0xada1a8: add             x2, x2, HEAP, lsl #32
    // 0xada1ac: StoreField: r0->field_1b = r2
    //     0xada1ac: stur            w2, [x0, #0x1b]
    // 0xada1b0: r17 = ")"
    //     0xada1b0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xada1b4: StoreField: r0->field_1f = r17
    //     0xada1b4: stur            w17, [x0, #0x1f]
    // 0xada1b8: SaveReg r0
    //     0xada1b8: str             x0, [SP, #-8]!
    // 0xada1bc: r0 = _interpolate()
    //     0xada1bc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada1c0: add             SP, SP, #8
    // 0xada1c4: LeaveFrame
    //     0xada1c4: mov             SP, fp
    //     0xada1c8: ldp             fp, lr, [SP], #0x10
    // 0xada1cc: ret
    //     0xada1cc: ret             
    // 0xada1d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xada1d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xada1d4: b               #0xada174
  }
}

// class id: 2252, size: 0x1c, field offset: 0x8
//   const constructor, 
class VelocityEstimate extends Object {

  Offset field_8;
  _Mint field_c;
  Duration field_14;
  Offset field_18;

  _ toString(/* No info */) {
    // ** addr: 0xad9ec8, size: 0x298
    // 0xad9ec8: EnterFrame
    //     0xad9ec8: stp             fp, lr, [SP, #-0x10]!
    //     0xad9ecc: mov             fp, SP
    // 0xad9ed0: AllocStack(0x10)
    //     0xad9ed0: sub             SP, SP, #0x10
    // 0xad9ed4: CheckStackOverflow
    //     0xad9ed4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9ed8: cmp             SP, x16
    //     0xad9edc: b.ls            #0xada104
    // 0xad9ee0: r1 = Null
    //     0xad9ee0: mov             x1, NULL
    // 0xad9ee4: r2 = 22
    //     0xad9ee4: mov             x2, #0x16
    // 0xad9ee8: r0 = AllocateArray()
    //     0xad9ee8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9eec: stur            x0, [fp, #-0x10]
    // 0xad9ef0: r17 = "VelocityEstimate("
    //     0xad9ef0: add             x17, PP, #0x40, lsl #12  ; [pp+0x40de0] "VelocityEstimate("
    //     0xad9ef4: ldr             x17, [x17, #0xde0]
    // 0xad9ef8: StoreField: r0->field_f = r17
    //     0xad9ef8: stur            w17, [x0, #0xf]
    // 0xad9efc: ldr             x1, [fp, #0x10]
    // 0xad9f00: LoadField: r2 = r1->field_7
    //     0xad9f00: ldur            w2, [x1, #7]
    // 0xad9f04: DecompressPointer r2
    //     0xad9f04: add             x2, x2, HEAP, lsl #32
    // 0xad9f08: stur            x2, [fp, #-8]
    // 0xad9f0c: LoadField: d0 = r2->field_7
    //     0xad9f0c: ldur            d0, [x2, #7]
    // 0xad9f10: r3 = inline_Allocate_Double()
    //     0xad9f10: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xad9f14: add             x3, x3, #0x10
    //     0xad9f18: cmp             x4, x3
    //     0xad9f1c: b.ls            #0xada10c
    //     0xad9f20: str             x3, [THR, #0x60]  ; THR::top
    //     0xad9f24: sub             x3, x3, #0xf
    //     0xad9f28: mov             x4, #0xd108
    //     0xad9f2c: movk            x4, #3, lsl #16
    //     0xad9f30: stur            x4, [x3, #-1]
    // 0xad9f34: StoreField: r3->field_7 = d0
    //     0xad9f34: stur            d0, [x3, #7]
    // 0xad9f38: SaveReg r3
    //     0xad9f38: str             x3, [SP, #-8]!
    // 0xad9f3c: r3 = 1
    //     0xad9f3c: mov             x3, #1
    // 0xad9f40: SaveReg r3
    //     0xad9f40: str             x3, [SP, #-8]!
    // 0xad9f44: r0 = toStringAsFixed()
    //     0xad9f44: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad9f48: add             SP, SP, #0x10
    // 0xad9f4c: ldur            x1, [fp, #-0x10]
    // 0xad9f50: ArrayStore: r1[1] = r0  ; List_4
    //     0xad9f50: add             x25, x1, #0x13
    //     0xad9f54: str             w0, [x25]
    //     0xad9f58: tbz             w0, #0, #0xad9f74
    //     0xad9f5c: ldurb           w16, [x1, #-1]
    //     0xad9f60: ldurb           w17, [x0, #-1]
    //     0xad9f64: and             x16, x17, x16, lsr #2
    //     0xad9f68: tst             x16, HEAP, lsr #32
    //     0xad9f6c: b.eq            #0xad9f74
    //     0xad9f70: bl              #0xd67e5c
    // 0xad9f74: ldur            x1, [fp, #-0x10]
    // 0xad9f78: r17 = ", "
    //     0xad9f78: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad9f7c: StoreField: r1->field_17 = r17
    //     0xad9f7c: stur            w17, [x1, #0x17]
    // 0xad9f80: ldur            x0, [fp, #-8]
    // 0xad9f84: LoadField: d0 = r0->field_f
    //     0xad9f84: ldur            d0, [x0, #0xf]
    // 0xad9f88: r0 = inline_Allocate_Double()
    //     0xad9f88: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xad9f8c: add             x0, x0, #0x10
    //     0xad9f90: cmp             x2, x0
    //     0xad9f94: b.ls            #0xada130
    //     0xad9f98: str             x0, [THR, #0x60]  ; THR::top
    //     0xad9f9c: sub             x0, x0, #0xf
    //     0xad9fa0: mov             x2, #0xd108
    //     0xad9fa4: movk            x2, #3, lsl #16
    //     0xad9fa8: stur            x2, [x0, #-1]
    // 0xad9fac: StoreField: r0->field_7 = d0
    //     0xad9fac: stur            d0, [x0, #7]
    // 0xad9fb0: SaveReg r0
    //     0xad9fb0: str             x0, [SP, #-8]!
    // 0xad9fb4: r0 = 1
    //     0xad9fb4: mov             x0, #1
    // 0xad9fb8: SaveReg r0
    //     0xad9fb8: str             x0, [SP, #-8]!
    // 0xad9fbc: r0 = toStringAsFixed()
    //     0xad9fbc: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad9fc0: add             SP, SP, #0x10
    // 0xad9fc4: ldur            x1, [fp, #-0x10]
    // 0xad9fc8: ArrayStore: r1[3] = r0  ; List_4
    //     0xad9fc8: add             x25, x1, #0x1b
    //     0xad9fcc: str             w0, [x25]
    //     0xad9fd0: tbz             w0, #0, #0xad9fec
    //     0xad9fd4: ldurb           w16, [x1, #-1]
    //     0xad9fd8: ldurb           w17, [x0, #-1]
    //     0xad9fdc: and             x16, x17, x16, lsr #2
    //     0xad9fe0: tst             x16, HEAP, lsr #32
    //     0xad9fe4: b.eq            #0xad9fec
    //     0xad9fe8: bl              #0xd67e5c
    // 0xad9fec: ldur            x2, [fp, #-0x10]
    // 0xad9ff0: r17 = "; offset: "
    //     0xad9ff0: add             x17, PP, #0x40, lsl #12  ; [pp+0x40de8] "; offset: "
    //     0xad9ff4: ldr             x17, [x17, #0xde8]
    // 0xad9ff8: StoreField: r2->field_1f = r17
    //     0xad9ff8: stur            w17, [x2, #0x1f]
    // 0xad9ffc: ldr             x3, [fp, #0x10]
    // 0xada000: LoadField: r0 = r3->field_17
    //     0xada000: ldur            w0, [x3, #0x17]
    // 0xada004: DecompressPointer r0
    //     0xada004: add             x0, x0, HEAP, lsl #32
    // 0xada008: mov             x1, x2
    // 0xada00c: ArrayStore: r1[5] = r0  ; List_4
    //     0xada00c: add             x25, x1, #0x23
    //     0xada010: str             w0, [x25]
    //     0xada014: tbz             w0, #0, #0xada030
    //     0xada018: ldurb           w16, [x1, #-1]
    //     0xada01c: ldurb           w17, [x0, #-1]
    //     0xada020: and             x16, x17, x16, lsr #2
    //     0xada024: tst             x16, HEAP, lsr #32
    //     0xada028: b.eq            #0xada030
    //     0xada02c: bl              #0xd67e5c
    // 0xada030: r17 = ", duration: "
    //     0xada030: add             x17, PP, #0x40, lsl #12  ; [pp+0x40df0] ", duration: "
    //     0xada034: ldr             x17, [x17, #0xdf0]
    // 0xada038: StoreField: r2->field_27 = r17
    //     0xada038: stur            w17, [x2, #0x27]
    // 0xada03c: LoadField: r0 = r3->field_13
    //     0xada03c: ldur            w0, [x3, #0x13]
    // 0xada040: DecompressPointer r0
    //     0xada040: add             x0, x0, HEAP, lsl #32
    // 0xada044: mov             x1, x2
    // 0xada048: ArrayStore: r1[7] = r0  ; List_4
    //     0xada048: add             x25, x1, #0x2b
    //     0xada04c: str             w0, [x25]
    //     0xada050: tbz             w0, #0, #0xada06c
    //     0xada054: ldurb           w16, [x1, #-1]
    //     0xada058: ldurb           w17, [x0, #-1]
    //     0xada05c: and             x16, x17, x16, lsr #2
    //     0xada060: tst             x16, HEAP, lsr #32
    //     0xada064: b.eq            #0xada06c
    //     0xada068: bl              #0xd67e5c
    // 0xada06c: r17 = ", confidence: "
    //     0xada06c: add             x17, PP, #0x40, lsl #12  ; [pp+0x40df8] ", confidence: "
    //     0xada070: ldr             x17, [x17, #0xdf8]
    // 0xada074: StoreField: r2->field_2f = r17
    //     0xada074: stur            w17, [x2, #0x2f]
    // 0xada078: LoadField: d0 = r3->field_b
    //     0xada078: ldur            d0, [x3, #0xb]
    // 0xada07c: r0 = inline_Allocate_Double()
    //     0xada07c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xada080: add             x0, x0, #0x10
    //     0xada084: cmp             x1, x0
    //     0xada088: b.ls            #0xada148
    //     0xada08c: str             x0, [THR, #0x60]  ; THR::top
    //     0xada090: sub             x0, x0, #0xf
    //     0xada094: mov             x1, #0xd108
    //     0xada098: movk            x1, #3, lsl #16
    //     0xada09c: stur            x1, [x0, #-1]
    // 0xada0a0: StoreField: r0->field_7 = d0
    //     0xada0a0: stur            d0, [x0, #7]
    // 0xada0a4: SaveReg r0
    //     0xada0a4: str             x0, [SP, #-8]!
    // 0xada0a8: r0 = 1
    //     0xada0a8: mov             x0, #1
    // 0xada0ac: SaveReg r0
    //     0xada0ac: str             x0, [SP, #-8]!
    // 0xada0b0: r0 = toStringAsFixed()
    //     0xada0b0: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xada0b4: add             SP, SP, #0x10
    // 0xada0b8: ldur            x1, [fp, #-0x10]
    // 0xada0bc: ArrayStore: r1[9] = r0  ; List_4
    //     0xada0bc: add             x25, x1, #0x33
    //     0xada0c0: str             w0, [x25]
    //     0xada0c4: tbz             w0, #0, #0xada0e0
    //     0xada0c8: ldurb           w16, [x1, #-1]
    //     0xada0cc: ldurb           w17, [x0, #-1]
    //     0xada0d0: and             x16, x17, x16, lsr #2
    //     0xada0d4: tst             x16, HEAP, lsr #32
    //     0xada0d8: b.eq            #0xada0e0
    //     0xada0dc: bl              #0xd67e5c
    // 0xada0e0: ldur            x0, [fp, #-0x10]
    // 0xada0e4: r17 = ")"
    //     0xada0e4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xada0e8: StoreField: r0->field_37 = r17
    //     0xada0e8: stur            w17, [x0, #0x37]
    // 0xada0ec: SaveReg r0
    //     0xada0ec: str             x0, [SP, #-8]!
    // 0xada0f0: r0 = _interpolate()
    //     0xada0f0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada0f4: add             SP, SP, #8
    // 0xada0f8: LeaveFrame
    //     0xada0f8: mov             SP, fp
    //     0xada0fc: ldp             fp, lr, [SP], #0x10
    // 0xada100: ret
    //     0xada100: ret             
    // 0xada104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xada104: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xada108: b               #0xad9ee0
    // 0xada10c: SaveReg d0
    //     0xada10c: str             q0, [SP, #-0x10]!
    // 0xada110: stp             x1, x2, [SP, #-0x10]!
    // 0xada114: SaveReg r0
    //     0xada114: str             x0, [SP, #-8]!
    // 0xada118: r0 = AllocateDouble()
    //     0xada118: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xada11c: mov             x3, x0
    // 0xada120: RestoreReg r0
    //     0xada120: ldr             x0, [SP], #8
    // 0xada124: ldp             x1, x2, [SP], #0x10
    // 0xada128: RestoreReg d0
    //     0xada128: ldr             q0, [SP], #0x10
    // 0xada12c: b               #0xad9f34
    // 0xada130: SaveReg d0
    //     0xada130: str             q0, [SP, #-0x10]!
    // 0xada134: SaveReg r1
    //     0xada134: str             x1, [SP, #-8]!
    // 0xada138: r0 = AllocateDouble()
    //     0xada138: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xada13c: RestoreReg r1
    //     0xada13c: ldr             x1, [SP], #8
    // 0xada140: RestoreReg d0
    //     0xada140: ldr             q0, [SP], #0x10
    // 0xada144: b               #0xad9fac
    // 0xada148: SaveReg d0
    //     0xada148: str             q0, [SP, #-0x10]!
    // 0xada14c: SaveReg r2
    //     0xada14c: str             x2, [SP, #-8]!
    // 0xada150: r0 = AllocateDouble()
    //     0xada150: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xada154: RestoreReg r2
    //     0xada154: ldr             x2, [SP], #8
    // 0xada158: RestoreReg d0
    //     0xada158: ldr             q0, [SP], #0x10
    // 0xada15c: b               #0xada0a0
  }
}

// class id: 2253, size: 0xc, field offset: 0x8
//   const constructor, 
class Velocity extends Object {

  Offset field_8;

  _ clampMagnitude(/* No info */) {
    // ** addr: 0x713c18, size: 0x1bc
    // 0x713c18: EnterFrame
    //     0x713c18: stp             fp, lr, [SP, #-0x10]!
    //     0x713c1c: mov             fp, SP
    // 0x713c20: AllocStack(0x8)
    //     0x713c20: sub             SP, SP, #8
    // 0x713c24: CheckStackOverflow
    //     0x713c24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x713c28: cmp             SP, x16
    //     0x713c2c: b.ls            #0x713d80
    // 0x713c30: ldr             x0, [fp, #0x20]
    // 0x713c34: LoadField: r1 = r0->field_7
    //     0x713c34: ldur            w1, [x0, #7]
    // 0x713c38: DecompressPointer r1
    //     0x713c38: add             x1, x1, HEAP, lsl #32
    // 0x713c3c: LoadField: d0 = r1->field_7
    //     0x713c3c: ldur            d0, [x1, #7]
    // 0x713c40: fmul            d1, d0, d0
    // 0x713c44: LoadField: d0 = r1->field_f
    //     0x713c44: ldur            d0, [x1, #0xf]
    // 0x713c48: fmul            d2, d0, d0
    // 0x713c4c: fadd            d0, d1, d2
    // 0x713c50: ldr             d1, [fp, #0x10]
    // 0x713c54: fmul            d2, d1, d1
    // 0x713c58: fcmp            d0, d2
    // 0x713c5c: b.vs            #0x713cf8
    // 0x713c60: b.le            #0x713cf8
    // 0x713c64: fsqrt           d2, d0
    // 0x713c68: r0 = inline_Allocate_Double()
    //     0x713c68: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x713c6c: add             x0, x0, #0x10
    //     0x713c70: cmp             x2, x0
    //     0x713c74: b.ls            #0x713d88
    //     0x713c78: str             x0, [THR, #0x60]  ; THR::top
    //     0x713c7c: sub             x0, x0, #0xf
    //     0x713c80: mov             x2, #0xd108
    //     0x713c84: movk            x2, #3, lsl #16
    //     0x713c88: stur            x2, [x0, #-1]
    // 0x713c8c: StoreField: r0->field_7 = d2
    //     0x713c8c: stur            d2, [x0, #7]
    // 0x713c90: stp             x0, x1, [SP, #-0x10]!
    // 0x713c94: r0 = /()
    //     0x713c94: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x713c98: add             SP, SP, #0x10
    // 0x713c9c: ldr             d0, [fp, #0x10]
    // 0x713ca0: r1 = inline_Allocate_Double()
    //     0x713ca0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x713ca4: add             x1, x1, #0x10
    //     0x713ca8: cmp             x2, x1
    //     0x713cac: b.ls            #0x713da0
    //     0x713cb0: str             x1, [THR, #0x60]  ; THR::top
    //     0x713cb4: sub             x1, x1, #0xf
    //     0x713cb8: mov             x2, #0xd108
    //     0x713cbc: movk            x2, #3, lsl #16
    //     0x713cc0: stur            x2, [x1, #-1]
    // 0x713cc4: StoreField: r1->field_7 = d0
    //     0x713cc4: stur            d0, [x1, #7]
    // 0x713cc8: stp             x1, x0, [SP, #-0x10]!
    // 0x713ccc: r0 = *()
    //     0x713ccc: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x713cd0: add             SP, SP, #0x10
    // 0x713cd4: stur            x0, [fp, #-8]
    // 0x713cd8: r0 = Velocity()
    //     0x713cd8: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x713cdc: mov             x1, x0
    // 0x713ce0: ldur            x0, [fp, #-8]
    // 0x713ce4: StoreField: r1->field_7 = r0
    //     0x713ce4: stur            w0, [x1, #7]
    // 0x713ce8: mov             x0, x1
    // 0x713cec: LeaveFrame
    //     0x713cec: mov             SP, fp
    //     0x713cf0: ldp             fp, lr, [SP], #0x10
    // 0x713cf4: ret
    //     0x713cf4: ret             
    // 0x713cf8: ldr             x2, [fp, #0x18]
    // 0x713cfc: LoadField: d1 = r2->field_7
    //     0x713cfc: ldur            d1, [x2, #7]
    // 0x713d00: fmul            d2, d1, d1
    // 0x713d04: fcmp            d0, d2
    // 0x713d08: b.vs            #0x713d74
    // 0x713d0c: b.ge            #0x713d74
    // 0x713d10: fsqrt           d1, d0
    // 0x713d14: r0 = inline_Allocate_Double()
    //     0x713d14: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x713d18: add             x0, x0, #0x10
    //     0x713d1c: cmp             x3, x0
    //     0x713d20: b.ls            #0x713dbc
    //     0x713d24: str             x0, [THR, #0x60]  ; THR::top
    //     0x713d28: sub             x0, x0, #0xf
    //     0x713d2c: mov             x3, #0xd108
    //     0x713d30: movk            x3, #3, lsl #16
    //     0x713d34: stur            x3, [x0, #-1]
    // 0x713d38: StoreField: r0->field_7 = d1
    //     0x713d38: stur            d1, [x0, #7]
    // 0x713d3c: stp             x0, x1, [SP, #-0x10]!
    // 0x713d40: r0 = /()
    //     0x713d40: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x713d44: add             SP, SP, #0x10
    // 0x713d48: ldr             x16, [fp, #0x18]
    // 0x713d4c: stp             x16, x0, [SP, #-0x10]!
    // 0x713d50: r0 = *()
    //     0x713d50: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x713d54: add             SP, SP, #0x10
    // 0x713d58: stur            x0, [fp, #-8]
    // 0x713d5c: r0 = Velocity()
    //     0x713d5c: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x713d60: ldur            x1, [fp, #-8]
    // 0x713d64: StoreField: r0->field_7 = r1
    //     0x713d64: stur            w1, [x0, #7]
    // 0x713d68: LeaveFrame
    //     0x713d68: mov             SP, fp
    //     0x713d6c: ldp             fp, lr, [SP], #0x10
    // 0x713d70: ret
    //     0x713d70: ret             
    // 0x713d74: LeaveFrame
    //     0x713d74: mov             SP, fp
    //     0x713d78: ldp             fp, lr, [SP], #0x10
    // 0x713d7c: ret
    //     0x713d7c: ret             
    // 0x713d80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x713d80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713d84: b               #0x713c30
    // 0x713d88: stp             q1, q2, [SP, #-0x20]!
    // 0x713d8c: SaveReg r1
    //     0x713d8c: str             x1, [SP, #-8]!
    // 0x713d90: r0 = AllocateDouble()
    //     0x713d90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x713d94: RestoreReg r1
    //     0x713d94: ldr             x1, [SP], #8
    // 0x713d98: ldp             q1, q2, [SP], #0x20
    // 0x713d9c: b               #0x713c8c
    // 0x713da0: SaveReg d0
    //     0x713da0: str             q0, [SP, #-0x10]!
    // 0x713da4: SaveReg r0
    //     0x713da4: str             x0, [SP, #-8]!
    // 0x713da8: r0 = AllocateDouble()
    //     0x713da8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x713dac: mov             x1, x0
    // 0x713db0: RestoreReg r0
    //     0x713db0: ldr             x0, [SP], #8
    // 0x713db4: RestoreReg d0
    //     0x713db4: ldr             q0, [SP], #0x10
    // 0x713db8: b               #0x713cc4
    // 0x713dbc: SaveReg d1
    //     0x713dbc: str             q1, [SP, #-0x10]!
    // 0x713dc0: stp             x1, x2, [SP, #-0x10]!
    // 0x713dc4: r0 = AllocateDouble()
    //     0x713dc4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x713dc8: ldp             x1, x2, [SP], #0x10
    // 0x713dcc: RestoreReg d1
    //     0x713dcc: ldr             q1, [SP], #0x10
    // 0x713dd0: b               #0x713d38
  }
  Velocity +(Velocity, Velocity) {
    // ** addr: 0x713dec, size: 0x64
    // 0x713dec: EnterFrame
    //     0x713dec: stp             fp, lr, [SP, #-0x10]!
    //     0x713df0: mov             fp, SP
    // 0x713df4: ldr             x0, [fp, #0x10]
    // 0x713df8: r2 = Null
    //     0x713df8: mov             x2, NULL
    // 0x713dfc: r1 = Null
    //     0x713dfc: mov             x1, NULL
    // 0x713e00: r4 = 59
    //     0x713e00: mov             x4, #0x3b
    // 0x713e04: branchIfSmi(r0, 0x713e10)
    //     0x713e04: tbz             w0, #0, #0x713e10
    // 0x713e08: r4 = LoadClassIdInstr(r0)
    //     0x713e08: ldur            x4, [x0, #-1]
    //     0x713e0c: ubfx            x4, x4, #0xc, #0x14
    // 0x713e10: cmp             x4, #0x8cd
    // 0x713e14: b.eq            #0x713e2c
    // 0x713e18: r8 = Velocity
    //     0x713e18: add             x8, PP, #0x38, lsl #12  ; [pp+0x38428] Type: Velocity
    //     0x713e1c: ldr             x8, [x8, #0x428]
    // 0x713e20: r3 = Null
    //     0x713e20: add             x3, PP, #0x38, lsl #12  ; [pp+0x38430] Null
    //     0x713e24: ldr             x3, [x3, #0x430]
    // 0x713e28: r0 = DefaultTypeTest()
    //     0x713e28: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x713e2c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x713e2c: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x713e30: r0 = Throw()
    //     0x713e30: bl              #0xd67e38  ; ThrowStub
    // 0x713e34: brk             #0
  }
  Velocity -(Velocity, Velocity) {
    // ** addr: 0x713e50, size: 0x8c
    // 0x713e50: EnterFrame
    //     0x713e50: stp             fp, lr, [SP, #-0x10]!
    //     0x713e54: mov             fp, SP
    // 0x713e58: CheckStackOverflow
    //     0x713e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x713e5c: cmp             SP, x16
    //     0x713e60: b.ls            #0x713ebc
    // 0x713e64: ldr             x0, [fp, #0x10]
    // 0x713e68: r2 = Null
    //     0x713e68: mov             x2, NULL
    // 0x713e6c: r1 = Null
    //     0x713e6c: mov             x1, NULL
    // 0x713e70: r4 = 59
    //     0x713e70: mov             x4, #0x3b
    // 0x713e74: branchIfSmi(r0, 0x713e80)
    //     0x713e74: tbz             w0, #0, #0x713e80
    // 0x713e78: r4 = LoadClassIdInstr(r0)
    //     0x713e78: ldur            x4, [x0, #-1]
    //     0x713e7c: ubfx            x4, x4, #0xc, #0x14
    // 0x713e80: cmp             x4, #0x8cd
    // 0x713e84: b.eq            #0x713e9c
    // 0x713e88: r8 = Velocity
    //     0x713e88: add             x8, PP, #0x38, lsl #12  ; [pp+0x38428] Type: Velocity
    //     0x713e8c: ldr             x8, [x8, #0x428]
    // 0x713e90: r3 = Null
    //     0x713e90: add             x3, PP, #0x38, lsl #12  ; [pp+0x38440] Null
    //     0x713e94: ldr             x3, [x3, #0x440]
    // 0x713e98: r0 = DefaultTypeTest()
    //     0x713e98: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x713e9c: ldr             x16, [fp, #0x18]
    // 0x713ea0: ldr             lr, [fp, #0x10]
    // 0x713ea4: stp             lr, x16, [SP, #-0x10]!
    // 0x713ea8: r0 = -()
    //     0x713ea8: bl              #0x713ec4  ; [package:flutter/src/gestures/velocity_tracker.dart] Velocity::-
    // 0x713eac: add             SP, SP, #0x10
    // 0x713eb0: LeaveFrame
    //     0x713eb0: mov             SP, fp
    //     0x713eb4: ldp             fp, lr, [SP], #0x10
    // 0x713eb8: ret
    //     0x713eb8: ret             
    // 0x713ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x713ebc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713ec0: b               #0x713e64
  }
  Velocity -(Velocity, Velocity) {
    // ** addr: 0x713ec4, size: 0x60
    // 0x713ec4: EnterFrame
    //     0x713ec4: stp             fp, lr, [SP, #-0x10]!
    //     0x713ec8: mov             fp, SP
    // 0x713ecc: AllocStack(0x8)
    //     0x713ecc: sub             SP, SP, #8
    // 0x713ed0: CheckStackOverflow
    //     0x713ed0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x713ed4: cmp             SP, x16
    //     0x713ed8: b.ls            #0x713f1c
    // 0x713edc: ldr             x0, [fp, #0x18]
    // 0x713ee0: LoadField: r1 = r0->field_7
    //     0x713ee0: ldur            w1, [x0, #7]
    // 0x713ee4: DecompressPointer r1
    //     0x713ee4: add             x1, x1, HEAP, lsl #32
    // 0x713ee8: ldr             x0, [fp, #0x10]
    // 0x713eec: LoadField: r2 = r0->field_7
    //     0x713eec: ldur            w2, [x0, #7]
    // 0x713ef0: DecompressPointer r2
    //     0x713ef0: add             x2, x2, HEAP, lsl #32
    // 0x713ef4: stp             x2, x1, [SP, #-0x10]!
    // 0x713ef8: r0 = -()
    //     0x713ef8: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x713efc: add             SP, SP, #0x10
    // 0x713f00: stur            x0, [fp, #-8]
    // 0x713f04: r0 = Velocity()
    //     0x713f04: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x713f08: ldur            x1, [fp, #-8]
    // 0x713f0c: StoreField: r0->field_7 = r1
    //     0x713f0c: stur            w1, [x0, #7]
    // 0x713f10: LeaveFrame
    //     0x713f10: mov             SP, fp
    //     0x713f14: ldp             fp, lr, [SP], #0x10
    // 0x713f18: ret
    //     0x713f18: ret             
    // 0x713f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x713f1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713f20: b               #0x713edc
  }
  _ toString(/* No info */) {
    // ** addr: 0xad9d44, size: 0x184
    // 0xad9d44: EnterFrame
    //     0xad9d44: stp             fp, lr, [SP, #-0x10]!
    //     0xad9d48: mov             fp, SP
    // 0xad9d4c: AllocStack(0x10)
    //     0xad9d4c: sub             SP, SP, #0x10
    // 0xad9d50: CheckStackOverflow
    //     0xad9d50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9d54: cmp             SP, x16
    //     0xad9d58: b.ls            #0xad9e8c
    // 0xad9d5c: r1 = Null
    //     0xad9d5c: mov             x1, NULL
    // 0xad9d60: r2 = 10
    //     0xad9d60: mov             x2, #0xa
    // 0xad9d64: r0 = AllocateArray()
    //     0xad9d64: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9d68: stur            x0, [fp, #-0x10]
    // 0xad9d6c: r17 = "Velocity("
    //     0xad9d6c: add             x17, PP, #0x38, lsl #12  ; [pp+0x38420] "Velocity("
    //     0xad9d70: ldr             x17, [x17, #0x420]
    // 0xad9d74: StoreField: r0->field_f = r17
    //     0xad9d74: stur            w17, [x0, #0xf]
    // 0xad9d78: ldr             x1, [fp, #0x10]
    // 0xad9d7c: LoadField: r2 = r1->field_7
    //     0xad9d7c: ldur            w2, [x1, #7]
    // 0xad9d80: DecompressPointer r2
    //     0xad9d80: add             x2, x2, HEAP, lsl #32
    // 0xad9d84: stur            x2, [fp, #-8]
    // 0xad9d88: LoadField: d0 = r2->field_7
    //     0xad9d88: ldur            d0, [x2, #7]
    // 0xad9d8c: r1 = inline_Allocate_Double()
    //     0xad9d8c: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xad9d90: add             x1, x1, #0x10
    //     0xad9d94: cmp             x3, x1
    //     0xad9d98: b.ls            #0xad9e94
    //     0xad9d9c: str             x1, [THR, #0x60]  ; THR::top
    //     0xad9da0: sub             x1, x1, #0xf
    //     0xad9da4: mov             x3, #0xd108
    //     0xad9da8: movk            x3, #3, lsl #16
    //     0xad9dac: stur            x3, [x1, #-1]
    // 0xad9db0: StoreField: r1->field_7 = d0
    //     0xad9db0: stur            d0, [x1, #7]
    // 0xad9db4: SaveReg r1
    //     0xad9db4: str             x1, [SP, #-8]!
    // 0xad9db8: r1 = 1
    //     0xad9db8: mov             x1, #1
    // 0xad9dbc: SaveReg r1
    //     0xad9dbc: str             x1, [SP, #-8]!
    // 0xad9dc0: r0 = toStringAsFixed()
    //     0xad9dc0: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad9dc4: add             SP, SP, #0x10
    // 0xad9dc8: ldur            x1, [fp, #-0x10]
    // 0xad9dcc: ArrayStore: r1[1] = r0  ; List_4
    //     0xad9dcc: add             x25, x1, #0x13
    //     0xad9dd0: str             w0, [x25]
    //     0xad9dd4: tbz             w0, #0, #0xad9df0
    //     0xad9dd8: ldurb           w16, [x1, #-1]
    //     0xad9ddc: ldurb           w17, [x0, #-1]
    //     0xad9de0: and             x16, x17, x16, lsr #2
    //     0xad9de4: tst             x16, HEAP, lsr #32
    //     0xad9de8: b.eq            #0xad9df0
    //     0xad9dec: bl              #0xd67e5c
    // 0xad9df0: ldur            x1, [fp, #-0x10]
    // 0xad9df4: r17 = ", "
    //     0xad9df4: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad9df8: StoreField: r1->field_17 = r17
    //     0xad9df8: stur            w17, [x1, #0x17]
    // 0xad9dfc: ldur            x0, [fp, #-8]
    // 0xad9e00: LoadField: d0 = r0->field_f
    //     0xad9e00: ldur            d0, [x0, #0xf]
    // 0xad9e04: r0 = inline_Allocate_Double()
    //     0xad9e04: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xad9e08: add             x0, x0, #0x10
    //     0xad9e0c: cmp             x2, x0
    //     0xad9e10: b.ls            #0xad9eb0
    //     0xad9e14: str             x0, [THR, #0x60]  ; THR::top
    //     0xad9e18: sub             x0, x0, #0xf
    //     0xad9e1c: mov             x2, #0xd108
    //     0xad9e20: movk            x2, #3, lsl #16
    //     0xad9e24: stur            x2, [x0, #-1]
    // 0xad9e28: StoreField: r0->field_7 = d0
    //     0xad9e28: stur            d0, [x0, #7]
    // 0xad9e2c: SaveReg r0
    //     0xad9e2c: str             x0, [SP, #-8]!
    // 0xad9e30: r0 = 1
    //     0xad9e30: mov             x0, #1
    // 0xad9e34: SaveReg r0
    //     0xad9e34: str             x0, [SP, #-8]!
    // 0xad9e38: r0 = toStringAsFixed()
    //     0xad9e38: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad9e3c: add             SP, SP, #0x10
    // 0xad9e40: ldur            x1, [fp, #-0x10]
    // 0xad9e44: ArrayStore: r1[3] = r0  ; List_4
    //     0xad9e44: add             x25, x1, #0x1b
    //     0xad9e48: str             w0, [x25]
    //     0xad9e4c: tbz             w0, #0, #0xad9e68
    //     0xad9e50: ldurb           w16, [x1, #-1]
    //     0xad9e54: ldurb           w17, [x0, #-1]
    //     0xad9e58: and             x16, x17, x16, lsr #2
    //     0xad9e5c: tst             x16, HEAP, lsr #32
    //     0xad9e60: b.eq            #0xad9e68
    //     0xad9e64: bl              #0xd67e5c
    // 0xad9e68: ldur            x0, [fp, #-0x10]
    // 0xad9e6c: r17 = ")"
    //     0xad9e6c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9e70: StoreField: r0->field_1f = r17
    //     0xad9e70: stur            w17, [x0, #0x1f]
    // 0xad9e74: SaveReg r0
    //     0xad9e74: str             x0, [SP, #-8]!
    // 0xad9e78: r0 = _interpolate()
    //     0xad9e78: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad9e7c: add             SP, SP, #8
    // 0xad9e80: LeaveFrame
    //     0xad9e80: mov             SP, fp
    //     0xad9e84: ldp             fp, lr, [SP], #0x10
    // 0xad9e88: ret
    //     0xad9e88: ret             
    // 0xad9e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9e8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9e90: b               #0xad9d5c
    // 0xad9e94: SaveReg d0
    //     0xad9e94: str             q0, [SP, #-0x10]!
    // 0xad9e98: stp             x0, x2, [SP, #-0x10]!
    // 0xad9e9c: r0 = AllocateDouble()
    //     0xad9e9c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad9ea0: mov             x1, x0
    // 0xad9ea4: ldp             x0, x2, [SP], #0x10
    // 0xad9ea8: RestoreReg d0
    //     0xad9ea8: ldr             q0, [SP], #0x10
    // 0xad9eac: b               #0xad9db0
    // 0xad9eb0: SaveReg d0
    //     0xad9eb0: str             q0, [SP, #-0x10]!
    // 0xad9eb4: SaveReg r1
    //     0xad9eb4: str             x1, [SP, #-8]!
    // 0xad9eb8: r0 = AllocateDouble()
    //     0xad9eb8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad9ebc: RestoreReg r1
    //     0xad9ebc: ldr             x1, [SP], #8
    // 0xad9ec0: RestoreReg d0
    //     0xad9ec0: ldr             q0, [SP], #0x10
    // 0xad9ec4: b               #0xad9e28
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0d734, size: 0x40
    // 0xb0d734: EnterFrame
    //     0xb0d734: stp             fp, lr, [SP, #-0x10]!
    //     0xb0d738: mov             fp, SP
    // 0xb0d73c: CheckStackOverflow
    //     0xb0d73c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0d740: cmp             SP, x16
    //     0xb0d744: b.ls            #0xb0d76c
    // 0xb0d748: ldr             x0, [fp, #0x10]
    // 0xb0d74c: LoadField: r1 = r0->field_7
    //     0xb0d74c: ldur            w1, [x0, #7]
    // 0xb0d750: DecompressPointer r1
    //     0xb0d750: add             x1, x1, HEAP, lsl #32
    // 0xb0d754: SaveReg r1
    //     0xb0d754: str             x1, [SP, #-8]!
    // 0xb0d758: r0 = hashCode()
    //     0xb0d758: bl              #0xb05768  ; [package:flutter/src/material/theme_data.dart] VisualDensity::hashCode
    // 0xb0d75c: add             SP, SP, #8
    // 0xb0d760: LeaveFrame
    //     0xb0d760: mov             SP, fp
    //     0xb0d764: ldp             fp, lr, [SP], #0x10
    // 0xb0d768: ret
    //     0xb0d768: ret             
    // 0xb0d76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0d76c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0d770: b               #0xb0d748
  }
  _ ==(/* No info */) {
    // ** addr: 0xc98684, size: 0x8c
    // 0xc98684: EnterFrame
    //     0xc98684: stp             fp, lr, [SP, #-0x10]!
    //     0xc98688: mov             fp, SP
    // 0xc9868c: CheckStackOverflow
    //     0xc9868c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc98690: cmp             SP, x16
    //     0xc98694: b.ls            #0xc98708
    // 0xc98698: ldr             x0, [fp, #0x10]
    // 0xc9869c: cmp             w0, NULL
    // 0xc986a0: b.ne            #0xc986b4
    // 0xc986a4: r0 = false
    //     0xc986a4: add             x0, NULL, #0x30  ; false
    // 0xc986a8: LeaveFrame
    //     0xc986a8: mov             SP, fp
    //     0xc986ac: ldp             fp, lr, [SP], #0x10
    // 0xc986b0: ret
    //     0xc986b0: ret             
    // 0xc986b4: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc986b4: mov             x1, #0x76
    //     0xc986b8: tbz             w0, #0, #0xc986c8
    //     0xc986bc: ldur            x1, [x0, #-1]
    //     0xc986c0: ubfx            x1, x1, #0xc, #0x14
    //     0xc986c4: lsl             x1, x1, #1
    // 0xc986c8: r17 = 4506
    //     0xc986c8: mov             x17, #0x119a
    // 0xc986cc: cmp             w1, w17
    // 0xc986d0: b.ne            #0xc986f8
    // 0xc986d4: ldr             x1, [fp, #0x18]
    // 0xc986d8: LoadField: r2 = r0->field_7
    //     0xc986d8: ldur            w2, [x0, #7]
    // 0xc986dc: DecompressPointer r2
    //     0xc986dc: add             x2, x2, HEAP, lsl #32
    // 0xc986e0: LoadField: r0 = r1->field_7
    //     0xc986e0: ldur            w0, [x1, #7]
    // 0xc986e4: DecompressPointer r0
    //     0xc986e4: add             x0, x0, HEAP, lsl #32
    // 0xc986e8: stp             x0, x2, [SP, #-0x10]!
    // 0xc986ec: r0 = ==()
    //     0xc986ec: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xc986f0: add             SP, SP, #0x10
    // 0xc986f4: b               #0xc986fc
    // 0xc986f8: r0 = false
    //     0xc986f8: add             x0, NULL, #0x30  ; false
    // 0xc986fc: LeaveFrame
    //     0xc986fc: mov             SP, fp
    //     0xc98700: ldp             fp, lr, [SP], #0x10
    // 0xc98704: ret
    //     0xc98704: ret             
    // 0xc98708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc98708: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9870c: b               #0xc98698
  }
}

// class id: 4470, size: 0x18, field offset: 0x8
class VelocityTracker extends Object {

  _ getVelocity(/* No info */) {
    // ** addr: 0xc3ec88, size: 0x9c
    // 0xc3ec88: EnterFrame
    //     0xc3ec88: stp             fp, lr, [SP, #-0x10]!
    //     0xc3ec8c: mov             fp, SP
    // 0xc3ec90: AllocStack(0x8)
    //     0xc3ec90: sub             SP, SP, #8
    // 0xc3ec94: CheckStackOverflow
    //     0xc3ec94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3ec98: cmp             SP, x16
    //     0xc3ec9c: b.ls            #0xc3ed1c
    // 0xc3eca0: ldr             x0, [fp, #0x10]
    // 0xc3eca4: r1 = LoadClassIdInstr(r0)
    //     0xc3eca4: ldur            x1, [x0, #-1]
    //     0xc3eca8: ubfx            x1, x1, #0xc, #0x14
    // 0xc3ecac: SaveReg r0
    //     0xc3ecac: str             x0, [SP, #-8]!
    // 0xc3ecb0: mov             x0, x1
    // 0xc3ecb4: r0 = GDT[cid_x0 + -0xf7d]()
    //     0xc3ecb4: sub             lr, x0, #0xf7d
    //     0xc3ecb8: ldr             lr, [x21, lr, lsl #3]
    //     0xc3ecbc: blr             lr
    // 0xc3ecc0: add             SP, SP, #8
    // 0xc3ecc4: cmp             w0, NULL
    // 0xc3ecc8: b.eq            #0xc3ecec
    // 0xc3eccc: LoadField: r1 = r0->field_7
    //     0xc3eccc: ldur            w1, [x0, #7]
    // 0xc3ecd0: DecompressPointer r1
    //     0xc3ecd0: add             x1, x1, HEAP, lsl #32
    // 0xc3ecd4: stur            x1, [fp, #-8]
    // 0xc3ecd8: r16 = Instance_Offset
    //     0xc3ecd8: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xc3ecdc: stp             x16, x1, [SP, #-0x10]!
    // 0xc3ece0: r0 = ==()
    //     0xc3ece0: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xc3ece4: add             SP, SP, #0x10
    // 0xc3ece8: tbnz            w0, #4, #0xc3ed00
    // 0xc3ecec: r0 = Instance_Velocity
    //     0xc3ecec: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0xc3ecf0: ldr             x0, [x0, #0x850]
    // 0xc3ecf4: LeaveFrame
    //     0xc3ecf4: mov             SP, fp
    //     0xc3ecf8: ldp             fp, lr, [SP], #0x10
    // 0xc3ecfc: ret
    //     0xc3ecfc: ret             
    // 0xc3ed00: ldur            x0, [fp, #-8]
    // 0xc3ed04: r0 = Velocity()
    //     0xc3ed04: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0xc3ed08: ldur            x1, [fp, #-8]
    // 0xc3ed0c: StoreField: r0->field_7 = r1
    //     0xc3ed0c: stur            w1, [x0, #7]
    // 0xc3ed10: LeaveFrame
    //     0xc3ed10: mov             SP, fp
    //     0xc3ed14: ldp             fp, lr, [SP], #0x10
    // 0xc3ed18: ret
    //     0xc3ed18: ret             
    // 0xc3ed1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3ed1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3ed20: b               #0xc3eca0
  }
  _ getVelocityEstimate(/* No info */) {
    // ** addr: 0xcb5194, size: 0x88c
    // 0xcb5194: EnterFrame
    //     0xcb5194: stp             fp, lr, [SP, #-0x10]!
    //     0xcb5198: mov             fp, SP
    // 0xcb519c: AllocStack(0x90)
    //     0xcb519c: sub             SP, SP, #0x90
    // 0xcb51a0: CheckStackOverflow
    //     0xcb51a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb51a4: cmp             SP, x16
    //     0xcb51a8: b.ls            #0xcb5970
    // 0xcb51ac: r16 = <double>
    //     0xcb51ac: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcb51b0: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb51b4: r0 = _GrowableList()
    //     0xcb51b4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcb51b8: add             SP, SP, #0x10
    // 0xcb51bc: stur            x0, [fp, #-8]
    // 0xcb51c0: r16 = <double>
    //     0xcb51c0: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcb51c4: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb51c8: r0 = _GrowableList()
    //     0xcb51c8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcb51cc: add             SP, SP, #0x10
    // 0xcb51d0: stur            x0, [fp, #-0x10]
    // 0xcb51d4: r16 = <double>
    //     0xcb51d4: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcb51d8: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb51dc: r0 = _GrowableList()
    //     0xcb51dc: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcb51e0: add             SP, SP, #0x10
    // 0xcb51e4: stur            x0, [fp, #-0x18]
    // 0xcb51e8: r16 = <double>
    //     0xcb51e8: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcb51ec: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb51f0: r0 = _GrowableList()
    //     0xcb51f0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcb51f4: add             SP, SP, #0x10
    // 0xcb51f8: mov             x2, x0
    // 0xcb51fc: ldr             x0, [fp, #0x10]
    // 0xcb5200: stur            x2, [fp, #-0x80]
    // 0xcb5204: LoadField: r3 = r0->field_f
    //     0xcb5204: ldur            x3, [x0, #0xf]
    // 0xcb5208: LoadField: r4 = r0->field_b
    //     0xcb5208: ldur            w4, [x0, #0xb]
    // 0xcb520c: DecompressPointer r4
    //     0xcb520c: add             x4, x4, HEAP, lsl #32
    // 0xcb5210: stur            x4, [fp, #-0x78]
    // 0xcb5214: LoadField: r0 = r4->field_b
    //     0xcb5214: ldur            w0, [x4, #0xb]
    // 0xcb5218: DecompressPointer r0
    //     0xcb5218: add             x0, x0, HEAP, lsl #32
    // 0xcb521c: r5 = LoadInt32Instr(r0)
    //     0xcb521c: sbfx            x5, x0, #1, #0x1f
    // 0xcb5220: mov             x0, x5
    // 0xcb5224: mov             x1, x3
    // 0xcb5228: stur            x5, [fp, #-0x70]
    // 0xcb522c: cmp             x1, x0
    // 0xcb5230: b.hs            #0xcb5978
    // 0xcb5234: ArrayLoad: r6 = r4[r3]  ; Unknown_4
    //     0xcb5234: add             x16, x4, x3, lsl #2
    //     0xcb5238: ldur            w6, [x16, #0xf]
    // 0xcb523c: DecompressPointer r6
    //     0xcb523c: add             x6, x6, HEAP, lsl #32
    // 0xcb5240: stur            x6, [fp, #-0x68]
    // 0xcb5244: cmp             w6, NULL
    // 0xcb5248: b.ne            #0xcb525c
    // 0xcb524c: r0 = Null
    //     0xcb524c: mov             x0, NULL
    // 0xcb5250: LeaveFrame
    //     0xcb5250: mov             SP, fp
    //     0xcb5254: ldp             fp, lr, [SP], #0x10
    // 0xcb5258: ret
    //     0xcb5258: ret             
    // 0xcb525c: LoadField: r7 = r6->field_7
    //     0xcb525c: ldur            w7, [x6, #7]
    // 0xcb5260: DecompressPointer r7
    //     0xcb5260: add             x7, x7, HEAP, lsl #32
    // 0xcb5264: stur            x7, [fp, #-0x60]
    // 0xcb5268: LoadField: r8 = r7->field_7
    //     0xcb5268: ldur            x8, [x7, #7]
    // 0xcb526c: stur            x8, [fp, #-0x58]
    // 0xcb5270: mov             x13, x3
    // 0xcb5274: mov             x12, x6
    // 0xcb5278: mov             x11, x7
    // 0xcb527c: r14 = 0
    //     0xcb527c: mov             x14, #0
    // 0xcb5280: ldur            x10, [fp, #-8]
    // 0xcb5284: ldur            x9, [fp, #-0x10]
    // 0xcb5288: ldur            x3, [fp, #-0x18]
    // 0xcb528c: stur            x14, [fp, #-0x38]
    // 0xcb5290: stur            x13, [fp, #-0x40]
    // 0xcb5294: stur            x12, [fp, #-0x48]
    // 0xcb5298: stur            x11, [fp, #-0x50]
    // 0xcb529c: CheckStackOverflow
    //     0xcb529c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb52a0: cmp             SP, x16
    //     0xcb52a4: b.ls            #0xcb597c
    // 0xcb52a8: mov             x0, x5
    // 0xcb52ac: mov             x1, x13
    // 0xcb52b0: cmp             x1, x0
    // 0xcb52b4: b.hs            #0xcb5984
    // 0xcb52b8: ArrayLoad: r19 = r4[r13]  ; Unknown_4
    //     0xcb52b8: add             x16, x4, x13, lsl #2
    //     0xcb52bc: ldur            w19, [x16, #0xf]
    // 0xcb52c0: DecompressPointer r19
    //     0xcb52c0: add             x19, x19, HEAP, lsl #32
    // 0xcb52c4: stur            x19, [fp, #-0x30]
    // 0xcb52c8: cmp             w19, NULL
    // 0xcb52cc: b.ne            #0xcb52e0
    // 0xcb52d0: mov             x3, x14
    // 0xcb52d4: mov             x1, x12
    // 0xcb52d8: mov             x0, x11
    // 0xcb52dc: b               #0xcb56c4
    // 0xcb52e0: LoadField: r20 = r19->field_7
    //     0xcb52e0: ldur            w20, [x19, #7]
    // 0xcb52e4: DecompressPointer r20
    //     0xcb52e4: add             x20, x20, HEAP, lsl #32
    // 0xcb52e8: stur            x20, [fp, #-0x28]
    // 0xcb52ec: LoadField: r23 = r20->field_7
    //     0xcb52ec: ldur            x23, [x20, #7]
    // 0xcb52f0: stur            x23, [fp, #-0x20]
    // 0xcb52f4: sub             x24, x8, x23
    // 0xcb52f8: r0 = BoxInt64Instr(r24)
    //     0xcb52f8: sbfiz           x0, x24, #1, #0x1f
    //     0xcb52fc: cmp             x24, x0, asr #1
    //     0xcb5300: b.eq            #0xcb530c
    //     0xcb5304: bl              #0xd69bb8
    //     0xcb5308: stur            x24, [x0, #7]
    // 0xcb530c: stp             x0, NULL, [SP, #-0x10]!
    // 0xcb5310: r0 = _Double.fromInteger()
    //     0xcb5310: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xcb5314: add             SP, SP, #0x10
    // 0xcb5318: LoadField: d0 = r0->field_7
    //     0xcb5318: ldur            d0, [x0, #7]
    // 0xcb531c: d1 = 1000.000000
    //     0xcb531c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0xcb5320: ldr             d1, [x17, #0x3b0]
    // 0xcb5324: fdiv            d2, d0, d1
    // 0xcb5328: ldur            x2, [fp, #-0x50]
    // 0xcb532c: stur            d2, [fp, #-0x88]
    // 0xcb5330: LoadField: r0 = r2->field_7
    //     0xcb5330: ldur            x0, [x2, #7]
    // 0xcb5334: ldur            x1, [fp, #-0x20]
    // 0xcb5338: sub             x3, x1, x0
    // 0xcb533c: tbz             x3, #0x3f, #0xcb5348
    // 0xcb5340: neg             x0, x3
    // 0xcb5344: mov             x3, x0
    // 0xcb5348: r0 = BoxInt64Instr(r3)
    //     0xcb5348: sbfiz           x0, x3, #1, #0x1f
    //     0xcb534c: cmp             x3, x0, asr #1
    //     0xcb5350: b.eq            #0xcb535c
    //     0xcb5354: bl              #0xd69c6c
    //     0xcb5358: stur            x3, [x0, #7]
    // 0xcb535c: stp             x0, NULL, [SP, #-0x10]!
    // 0xcb5360: r0 = _Double.fromInteger()
    //     0xcb5360: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xcb5364: add             SP, SP, #0x10
    // 0xcb5368: LoadField: d0 = r0->field_7
    //     0xcb5368: ldur            d0, [x0, #7]
    // 0xcb536c: d1 = 1000.000000
    //     0xcb536c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0xcb5370: ldr             d1, [x17, #0x3b0]
    // 0xcb5374: fdiv            d2, d0, d1
    // 0xcb5378: ldur            d0, [fp, #-0x88]
    // 0xcb537c: d3 = 100.000000
    //     0xcb537c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0xcb5380: ldr             d3, [x17, #0x308]
    // 0xcb5384: fcmp            d0, d3
    // 0xcb5388: b.vs            #0xcb5390
    // 0xcb538c: b.gt            #0xcb53a4
    // 0xcb5390: d4 = 40.000000
    //     0xcb5390: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0xcb5394: ldr             d4, [x17, #0xdc0]
    // 0xcb5398: fcmp            d2, d4
    // 0xcb539c: b.vs            #0xcb53b8
    // 0xcb53a0: b.le            #0xcb53b8
    // 0xcb53a4: ldur            x3, [fp, #-0x38]
    // 0xcb53a8: ldur            x1, [fp, #-0x48]
    // 0xcb53ac: ldur            x0, [fp, #-0x50]
    // 0xcb53b0: ldur            x2, [fp, #-0x80]
    // 0xcb53b4: b               #0xcb56c4
    // 0xcb53b8: ldur            x0, [fp, #-8]
    // 0xcb53bc: ldur            x12, [fp, #-0x30]
    // 0xcb53c0: LoadField: r1 = r12->field_b
    //     0xcb53c0: ldur            w1, [x12, #0xb]
    // 0xcb53c4: DecompressPointer r1
    //     0xcb53c4: add             x1, x1, HEAP, lsl #32
    // 0xcb53c8: stur            x1, [fp, #-0x50]
    // 0xcb53cc: LoadField: d2 = r1->field_7
    //     0xcb53cc: ldur            d2, [x1, #7]
    // 0xcb53d0: stur            d2, [fp, #-0x90]
    // 0xcb53d4: LoadField: r2 = r0->field_b
    //     0xcb53d4: ldur            w2, [x0, #0xb]
    // 0xcb53d8: DecompressPointer r2
    //     0xcb53d8: add             x2, x2, HEAP, lsl #32
    // 0xcb53dc: stur            x2, [fp, #-0x48]
    // 0xcb53e0: LoadField: r3 = r0->field_f
    //     0xcb53e0: ldur            w3, [x0, #0xf]
    // 0xcb53e4: DecompressPointer r3
    //     0xcb53e4: add             x3, x3, HEAP, lsl #32
    // 0xcb53e8: LoadField: r4 = r3->field_b
    //     0xcb53e8: ldur            w4, [x3, #0xb]
    // 0xcb53ec: DecompressPointer r4
    //     0xcb53ec: add             x4, x4, HEAP, lsl #32
    // 0xcb53f0: cmp             w2, w4
    // 0xcb53f4: b.ne            #0xcb5404
    // 0xcb53f8: SaveReg r0
    //     0xcb53f8: str             x0, [SP, #-8]!
    // 0xcb53fc: r0 = _growToNextCapacity()
    //     0xcb53fc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcb5400: add             SP, SP, #8
    // 0xcb5404: ldur            x2, [fp, #-8]
    // 0xcb5408: ldur            x4, [fp, #-0x10]
    // 0xcb540c: ldur            x3, [fp, #-0x50]
    // 0xcb5410: ldur            d0, [fp, #-0x90]
    // 0xcb5414: ldur            x0, [fp, #-0x48]
    // 0xcb5418: r5 = LoadInt32Instr(r0)
    //     0xcb5418: sbfx            x5, x0, #1, #0x1f
    // 0xcb541c: add             x0, x5, #1
    // 0xcb5420: lsl             x1, x0, #1
    // 0xcb5424: StoreField: r2->field_b = r1
    //     0xcb5424: stur            w1, [x2, #0xb]
    // 0xcb5428: mov             x1, x5
    // 0xcb542c: cmp             x1, x0
    // 0xcb5430: b.hs            #0xcb5988
    // 0xcb5434: LoadField: r1 = r2->field_f
    //     0xcb5434: ldur            w1, [x2, #0xf]
    // 0xcb5438: DecompressPointer r1
    //     0xcb5438: add             x1, x1, HEAP, lsl #32
    // 0xcb543c: r0 = inline_Allocate_Double()
    //     0xcb543c: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0xcb5440: add             x0, x0, #0x10
    //     0xcb5444: cmp             x6, x0
    //     0xcb5448: b.ls            #0xcb598c
    //     0xcb544c: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb5450: sub             x0, x0, #0xf
    //     0xcb5454: mov             x6, #0xd108
    //     0xcb5458: movk            x6, #3, lsl #16
    //     0xcb545c: stur            x6, [x0, #-1]
    // 0xcb5460: StoreField: r0->field_7 = d0
    //     0xcb5460: stur            d0, [x0, #7]
    // 0xcb5464: ArrayStore: r1[r5] = r0  ; List_4
    //     0xcb5464: add             x25, x1, x5, lsl #2
    //     0xcb5468: add             x25, x25, #0xf
    //     0xcb546c: str             w0, [x25]
    //     0xcb5470: tbz             w0, #0, #0xcb548c
    //     0xcb5474: ldurb           w16, [x1, #-1]
    //     0xcb5478: ldurb           w17, [x0, #-1]
    //     0xcb547c: and             x16, x17, x16, lsr #2
    //     0xcb5480: tst             x16, HEAP, lsr #32
    //     0xcb5484: b.eq            #0xcb548c
    //     0xcb5488: bl              #0xd67e5c
    // 0xcb548c: LoadField: d0 = r3->field_f
    //     0xcb548c: ldur            d0, [x3, #0xf]
    // 0xcb5490: stur            d0, [fp, #-0x90]
    // 0xcb5494: LoadField: r0 = r4->field_b
    //     0xcb5494: ldur            w0, [x4, #0xb]
    // 0xcb5498: DecompressPointer r0
    //     0xcb5498: add             x0, x0, HEAP, lsl #32
    // 0xcb549c: stur            x0, [fp, #-0x48]
    // 0xcb54a0: LoadField: r1 = r4->field_f
    //     0xcb54a0: ldur            w1, [x4, #0xf]
    // 0xcb54a4: DecompressPointer r1
    //     0xcb54a4: add             x1, x1, HEAP, lsl #32
    // 0xcb54a8: LoadField: r3 = r1->field_b
    //     0xcb54a8: ldur            w3, [x1, #0xb]
    // 0xcb54ac: DecompressPointer r3
    //     0xcb54ac: add             x3, x3, HEAP, lsl #32
    // 0xcb54b0: cmp             w0, w3
    // 0xcb54b4: b.ne            #0xcb54c4
    // 0xcb54b8: SaveReg r4
    //     0xcb54b8: str             x4, [SP, #-8]!
    // 0xcb54bc: r0 = _growToNextCapacity()
    //     0xcb54bc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcb54c0: add             SP, SP, #8
    // 0xcb54c4: ldur            x2, [fp, #-0x10]
    // 0xcb54c8: ldur            x3, [fp, #-0x18]
    // 0xcb54cc: ldur            d0, [fp, #-0x90]
    // 0xcb54d0: ldur            x0, [fp, #-0x48]
    // 0xcb54d4: r4 = LoadInt32Instr(r0)
    //     0xcb54d4: sbfx            x4, x0, #1, #0x1f
    // 0xcb54d8: add             x0, x4, #1
    // 0xcb54dc: lsl             x1, x0, #1
    // 0xcb54e0: StoreField: r2->field_b = r1
    //     0xcb54e0: stur            w1, [x2, #0xb]
    // 0xcb54e4: mov             x1, x4
    // 0xcb54e8: cmp             x1, x0
    // 0xcb54ec: b.hs            #0xcb59b4
    // 0xcb54f0: LoadField: r1 = r2->field_f
    //     0xcb54f0: ldur            w1, [x2, #0xf]
    // 0xcb54f4: DecompressPointer r1
    //     0xcb54f4: add             x1, x1, HEAP, lsl #32
    // 0xcb54f8: r0 = inline_Allocate_Double()
    //     0xcb54f8: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0xcb54fc: add             x0, x0, #0x10
    //     0xcb5500: cmp             x5, x0
    //     0xcb5504: b.ls            #0xcb59b8
    //     0xcb5508: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb550c: sub             x0, x0, #0xf
    //     0xcb5510: mov             x5, #0xd108
    //     0xcb5514: movk            x5, #3, lsl #16
    //     0xcb5518: stur            x5, [x0, #-1]
    // 0xcb551c: StoreField: r0->field_7 = d0
    //     0xcb551c: stur            d0, [x0, #7]
    // 0xcb5520: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcb5520: add             x25, x1, x4, lsl #2
    //     0xcb5524: add             x25, x25, #0xf
    //     0xcb5528: str             w0, [x25]
    //     0xcb552c: tbz             w0, #0, #0xcb5548
    //     0xcb5530: ldurb           w16, [x1, #-1]
    //     0xcb5534: ldurb           w17, [x0, #-1]
    //     0xcb5538: and             x16, x17, x16, lsr #2
    //     0xcb553c: tst             x16, HEAP, lsr #32
    //     0xcb5540: b.eq            #0xcb5548
    //     0xcb5544: bl              #0xd67e5c
    // 0xcb5548: LoadField: r0 = r3->field_b
    //     0xcb5548: ldur            w0, [x3, #0xb]
    // 0xcb554c: DecompressPointer r0
    //     0xcb554c: add             x0, x0, HEAP, lsl #32
    // 0xcb5550: stur            x0, [fp, #-0x48]
    // 0xcb5554: LoadField: r1 = r3->field_f
    //     0xcb5554: ldur            w1, [x3, #0xf]
    // 0xcb5558: DecompressPointer r1
    //     0xcb5558: add             x1, x1, HEAP, lsl #32
    // 0xcb555c: LoadField: r4 = r1->field_b
    //     0xcb555c: ldur            w4, [x1, #0xb]
    // 0xcb5560: DecompressPointer r4
    //     0xcb5560: add             x4, x4, HEAP, lsl #32
    // 0xcb5564: cmp             w0, w4
    // 0xcb5568: b.ne            #0xcb5578
    // 0xcb556c: SaveReg r3
    //     0xcb556c: str             x3, [SP, #-8]!
    // 0xcb5570: r0 = _growToNextCapacity()
    //     0xcb5570: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcb5574: add             SP, SP, #8
    // 0xcb5578: ldur            x2, [fp, #-0x18]
    // 0xcb557c: ldur            x3, [fp, #-0x80]
    // 0xcb5580: ldur            d0, [fp, #-0x88]
    // 0xcb5584: ldur            x0, [fp, #-0x48]
    // 0xcb5588: r4 = LoadInt32Instr(r0)
    //     0xcb5588: sbfx            x4, x0, #1, #0x1f
    // 0xcb558c: add             x0, x4, #1
    // 0xcb5590: lsl             x1, x0, #1
    // 0xcb5594: StoreField: r2->field_b = r1
    //     0xcb5594: stur            w1, [x2, #0xb]
    // 0xcb5598: mov             x1, x4
    // 0xcb559c: cmp             x1, x0
    // 0xcb55a0: b.hs            #0xcb59d8
    // 0xcb55a4: LoadField: r0 = r2->field_f
    //     0xcb55a4: ldur            w0, [x2, #0xf]
    // 0xcb55a8: DecompressPointer r0
    //     0xcb55a8: add             x0, x0, HEAP, lsl #32
    // 0xcb55ac: add             x1, x0, x4, lsl #2
    // 0xcb55b0: r17 = 1.000000
    //     0xcb55b0: ldr             x17, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xcb55b4: StoreField: r1->field_f = r17
    //     0xcb55b4: stur            w17, [x1, #0xf]
    // 0xcb55b8: fneg            d1, d0
    // 0xcb55bc: stur            d1, [fp, #-0x90]
    // 0xcb55c0: LoadField: r0 = r3->field_b
    //     0xcb55c0: ldur            w0, [x3, #0xb]
    // 0xcb55c4: DecompressPointer r0
    //     0xcb55c4: add             x0, x0, HEAP, lsl #32
    // 0xcb55c8: stur            x0, [fp, #-0x48]
    // 0xcb55cc: LoadField: r1 = r3->field_f
    //     0xcb55cc: ldur            w1, [x3, #0xf]
    // 0xcb55d0: DecompressPointer r1
    //     0xcb55d0: add             x1, x1, HEAP, lsl #32
    // 0xcb55d4: LoadField: r4 = r1->field_b
    //     0xcb55d4: ldur            w4, [x1, #0xb]
    // 0xcb55d8: DecompressPointer r4
    //     0xcb55d8: add             x4, x4, HEAP, lsl #32
    // 0xcb55dc: cmp             w0, w4
    // 0xcb55e0: b.ne            #0xcb55f0
    // 0xcb55e4: SaveReg r3
    //     0xcb55e4: str             x3, [SP, #-8]!
    // 0xcb55e8: r0 = _growToNextCapacity()
    //     0xcb55e8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcb55ec: add             SP, SP, #8
    // 0xcb55f0: ldur            x2, [fp, #-0x80]
    // 0xcb55f4: ldur            x3, [fp, #-0x40]
    // 0xcb55f8: ldur            d0, [fp, #-0x90]
    // 0xcb55fc: ldur            x0, [fp, #-0x48]
    // 0xcb5600: r4 = LoadInt32Instr(r0)
    //     0xcb5600: sbfx            x4, x0, #1, #0x1f
    // 0xcb5604: add             x0, x4, #1
    // 0xcb5608: lsl             x1, x0, #1
    // 0xcb560c: StoreField: r2->field_b = r1
    //     0xcb560c: stur            w1, [x2, #0xb]
    // 0xcb5610: mov             x1, x4
    // 0xcb5614: cmp             x1, x0
    // 0xcb5618: b.hs            #0xcb59dc
    // 0xcb561c: LoadField: r1 = r2->field_f
    //     0xcb561c: ldur            w1, [x2, #0xf]
    // 0xcb5620: DecompressPointer r1
    //     0xcb5620: add             x1, x1, HEAP, lsl #32
    // 0xcb5624: r0 = inline_Allocate_Double()
    //     0xcb5624: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0xcb5628: add             x0, x0, #0x10
    //     0xcb562c: cmp             x5, x0
    //     0xcb5630: b.ls            #0xcb59e0
    //     0xcb5634: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb5638: sub             x0, x0, #0xf
    //     0xcb563c: mov             x5, #0xd108
    //     0xcb5640: movk            x5, #3, lsl #16
    //     0xcb5644: stur            x5, [x0, #-1]
    // 0xcb5648: StoreField: r0->field_7 = d0
    //     0xcb5648: stur            d0, [x0, #7]
    // 0xcb564c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcb564c: add             x25, x1, x4, lsl #2
    //     0xcb5650: add             x25, x25, #0xf
    //     0xcb5654: str             w0, [x25]
    //     0xcb5658: tbz             w0, #0, #0xcb5674
    //     0xcb565c: ldurb           w16, [x1, #-1]
    //     0xcb5660: ldurb           w17, [x0, #-1]
    //     0xcb5664: and             x16, x17, x16, lsr #2
    //     0xcb5668: tst             x16, HEAP, lsr #32
    //     0xcb566c: b.eq            #0xcb5674
    //     0xcb5670: bl              #0xd67e5c
    // 0xcb5674: cbnz            x3, #0xcb5680
    // 0xcb5678: r1 = 20
    //     0xcb5678: mov             x1, #0x14
    // 0xcb567c: b               #0xcb5684
    // 0xcb5680: mov             x1, x3
    // 0xcb5684: ldur            x0, [fp, #-0x38]
    // 0xcb5688: sub             x13, x1, #1
    // 0xcb568c: add             x14, x0, #1
    // 0xcb5690: cmp             x14, #0x14
    // 0xcb5694: b.ge            #0xcb56b8
    // 0xcb5698: ldur            x12, [fp, #-0x30]
    // 0xcb569c: ldur            x11, [fp, #-0x28]
    // 0xcb56a0: ldur            x4, [fp, #-0x78]
    // 0xcb56a4: ldur            x7, [fp, #-0x60]
    // 0xcb56a8: ldur            x8, [fp, #-0x58]
    // 0xcb56ac: ldur            x5, [fp, #-0x70]
    // 0xcb56b0: ldur            x6, [fp, #-0x68]
    // 0xcb56b4: b               #0xcb5280
    // 0xcb56b8: mov             x3, x14
    // 0xcb56bc: ldur            x1, [fp, #-0x30]
    // 0xcb56c0: ldur            x0, [fp, #-0x28]
    // 0xcb56c4: stur            x1, [fp, #-0x28]
    // 0xcb56c8: stur            x0, [fp, #-0x30]
    // 0xcb56cc: cmp             x3, #3
    // 0xcb56d0: b.lt            #0xcb58e4
    // 0xcb56d4: ldur            x4, [fp, #-8]
    // 0xcb56d8: ldur            x3, [fp, #-0x18]
    // 0xcb56dc: r0 = LeastSquaresSolver()
    //     0xcb56dc: bl              #0xcb4b54  ; AllocateLeastSquaresSolverStub -> LeastSquaresSolver (size=0x14)
    // 0xcb56e0: mov             x1, x0
    // 0xcb56e4: ldur            x0, [fp, #-0x80]
    // 0xcb56e8: StoreField: r1->field_7 = r0
    //     0xcb56e8: stur            w0, [x1, #7]
    // 0xcb56ec: ldur            x2, [fp, #-8]
    // 0xcb56f0: StoreField: r1->field_b = r2
    //     0xcb56f0: stur            w2, [x1, #0xb]
    // 0xcb56f4: ldur            x2, [fp, #-0x18]
    // 0xcb56f8: StoreField: r1->field_f = r2
    //     0xcb56f8: stur            w2, [x1, #0xf]
    // 0xcb56fc: SaveReg r1
    //     0xcb56fc: str             x1, [SP, #-8]!
    // 0xcb5700: r0 = solve()
    //     0xcb5700: bl              #0xcb3b60  ; [package:flutter/src/gestures/lsq_solver.dart] LeastSquaresSolver::solve
    // 0xcb5704: add             SP, SP, #8
    // 0xcb5708: stur            x0, [fp, #-8]
    // 0xcb570c: cmp             w0, NULL
    // 0xcb5710: b.eq            #0xcb58d0
    // 0xcb5714: ldur            x3, [fp, #-0x10]
    // 0xcb5718: ldur            x2, [fp, #-0x18]
    // 0xcb571c: ldur            x1, [fp, #-0x80]
    // 0xcb5720: r0 = LeastSquaresSolver()
    //     0xcb5720: bl              #0xcb4b54  ; AllocateLeastSquaresSolverStub -> LeastSquaresSolver (size=0x14)
    // 0xcb5724: mov             x1, x0
    // 0xcb5728: ldur            x0, [fp, #-0x80]
    // 0xcb572c: StoreField: r1->field_7 = r0
    //     0xcb572c: stur            w0, [x1, #7]
    // 0xcb5730: ldur            x0, [fp, #-0x10]
    // 0xcb5734: StoreField: r1->field_b = r0
    //     0xcb5734: stur            w0, [x1, #0xb]
    // 0xcb5738: ldur            x0, [fp, #-0x18]
    // 0xcb573c: StoreField: r1->field_f = r0
    //     0xcb573c: stur            w0, [x1, #0xf]
    // 0xcb5740: SaveReg r1
    //     0xcb5740: str             x1, [SP, #-8]!
    // 0xcb5744: r0 = solve()
    //     0xcb5744: bl              #0xcb3b60  ; [package:flutter/src/gestures/lsq_solver.dart] LeastSquaresSolver::solve
    // 0xcb5748: add             SP, SP, #8
    // 0xcb574c: mov             x2, x0
    // 0xcb5750: stur            x2, [fp, #-0x10]
    // 0xcb5754: cmp             w2, NULL
    // 0xcb5758: b.eq            #0xcb58bc
    // 0xcb575c: ldur            x7, [fp, #-0x60]
    // 0xcb5760: ldur            x5, [fp, #-0x28]
    // 0xcb5764: ldur            x3, [fp, #-8]
    // 0xcb5768: ldur            x6, [fp, #-0x68]
    // 0xcb576c: ldur            x4, [fp, #-0x30]
    // 0xcb5770: d0 = 1000.000000
    //     0xcb5770: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0xcb5774: ldr             d0, [x17, #0x3b0]
    // 0xcb5778: LoadField: r8 = r3->field_7
    //     0xcb5778: ldur            w8, [x3, #7]
    // 0xcb577c: DecompressPointer r8
    //     0xcb577c: add             x8, x8, HEAP, lsl #32
    // 0xcb5780: LoadField: r0 = r8->field_13
    //     0xcb5780: ldur            w0, [x8, #0x13]
    // 0xcb5784: DecompressPointer r0
    //     0xcb5784: add             x0, x0, HEAP, lsl #32
    // 0xcb5788: r1 = LoadInt32Instr(r0)
    //     0xcb5788: sbfx            x1, x0, #1, #0x1f
    // 0xcb578c: mov             x0, x1
    // 0xcb5790: r1 = 1
    //     0xcb5790: mov             x1, #1
    // 0xcb5794: cmp             x1, x0
    // 0xcb5798: b.hs            #0xcb5a00
    // 0xcb579c: LoadField: d1 = r8->field_1f
    //     0xcb579c: ldur            d1, [x8, #0x1f]
    // 0xcb57a0: fmul            d2, d1, d0
    // 0xcb57a4: stur            d2, [fp, #-0x90]
    // 0xcb57a8: LoadField: r8 = r2->field_7
    //     0xcb57a8: ldur            w8, [x2, #7]
    // 0xcb57ac: DecompressPointer r8
    //     0xcb57ac: add             x8, x8, HEAP, lsl #32
    // 0xcb57b0: LoadField: r0 = r8->field_13
    //     0xcb57b0: ldur            w0, [x8, #0x13]
    // 0xcb57b4: DecompressPointer r0
    //     0xcb57b4: add             x0, x0, HEAP, lsl #32
    // 0xcb57b8: r1 = LoadInt32Instr(r0)
    //     0xcb57b8: sbfx            x1, x0, #1, #0x1f
    // 0xcb57bc: mov             x0, x1
    // 0xcb57c0: r1 = 1
    //     0xcb57c0: mov             x1, #1
    // 0xcb57c4: cmp             x1, x0
    // 0xcb57c8: b.hs            #0xcb5a04
    // 0xcb57cc: LoadField: d1 = r8->field_1f
    //     0xcb57cc: ldur            d1, [x8, #0x1f]
    // 0xcb57d0: fmul            d3, d1, d0
    // 0xcb57d4: stur            d3, [fp, #-0x88]
    // 0xcb57d8: r0 = Offset()
    //     0xcb57d8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcb57dc: ldur            d0, [fp, #-0x90]
    // 0xcb57e0: stur            x0, [fp, #-0x18]
    // 0xcb57e4: StoreField: r0->field_7 = d0
    //     0xcb57e4: stur            d0, [x0, #7]
    // 0xcb57e8: ldur            d0, [fp, #-0x88]
    // 0xcb57ec: StoreField: r0->field_f = d0
    //     0xcb57ec: stur            d0, [x0, #0xf]
    // 0xcb57f0: ldur            x1, [fp, #-8]
    // 0xcb57f4: LoadField: r2 = r1->field_b
    //     0xcb57f4: ldur            w2, [x1, #0xb]
    // 0xcb57f8: DecompressPointer r2
    //     0xcb57f8: add             x2, x2, HEAP, lsl #32
    // 0xcb57fc: r16 = Sentinel
    //     0xcb57fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcb5800: cmp             w2, w16
    // 0xcb5804: b.eq            #0xcb5a08
    // 0xcb5808: ldur            x1, [fp, #-0x10]
    // 0xcb580c: LoadField: r3 = r1->field_b
    //     0xcb580c: ldur            w3, [x1, #0xb]
    // 0xcb5810: DecompressPointer r3
    //     0xcb5810: add             x3, x3, HEAP, lsl #32
    // 0xcb5814: r16 = Sentinel
    //     0xcb5814: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcb5818: cmp             w3, w16
    // 0xcb581c: b.eq            #0xcb5a14
    // 0xcb5820: LoadField: d0 = r2->field_7
    //     0xcb5820: ldur            d0, [x2, #7]
    // 0xcb5824: LoadField: d1 = r3->field_7
    //     0xcb5824: ldur            d1, [x3, #7]
    // 0xcb5828: fmul            d2, d0, d1
    // 0xcb582c: ldur            x1, [fp, #-0x60]
    // 0xcb5830: stur            d2, [fp, #-0x88]
    // 0xcb5834: LoadField: r2 = r1->field_7
    //     0xcb5834: ldur            x2, [x1, #7]
    // 0xcb5838: ldur            x3, [fp, #-0x30]
    // 0xcb583c: LoadField: r1 = r3->field_7
    //     0xcb583c: ldur            x1, [x3, #7]
    // 0xcb5840: sub             x3, x2, x1
    // 0xcb5844: stur            x3, [fp, #-0x20]
    // 0xcb5848: r0 = Duration()
    //     0xcb5848: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xcb584c: mov             x1, x0
    // 0xcb5850: ldur            x0, [fp, #-0x20]
    // 0xcb5854: stur            x1, [fp, #-8]
    // 0xcb5858: StoreField: r1->field_7 = r0
    //     0xcb5858: stur            x0, [x1, #7]
    // 0xcb585c: ldur            x0, [fp, #-0x68]
    // 0xcb5860: LoadField: r2 = r0->field_b
    //     0xcb5860: ldur            w2, [x0, #0xb]
    // 0xcb5864: DecompressPointer r2
    //     0xcb5864: add             x2, x2, HEAP, lsl #32
    // 0xcb5868: ldur            x4, [fp, #-0x28]
    // 0xcb586c: LoadField: r0 = r4->field_b
    //     0xcb586c: ldur            w0, [x4, #0xb]
    // 0xcb5870: DecompressPointer r0
    //     0xcb5870: add             x0, x0, HEAP, lsl #32
    // 0xcb5874: stp             x0, x2, [SP, #-0x10]!
    // 0xcb5878: r0 = -()
    //     0xcb5878: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xcb587c: add             SP, SP, #0x10
    // 0xcb5880: stur            x0, [fp, #-0x10]
    // 0xcb5884: r0 = VelocityEstimate()
    //     0xcb5884: bl              #0xcb3b54  ; AllocateVelocityEstimateStub -> VelocityEstimate (size=0x1c)
    // 0xcb5888: mov             x1, x0
    // 0xcb588c: ldur            x0, [fp, #-0x18]
    // 0xcb5890: StoreField: r1->field_7 = r0
    //     0xcb5890: stur            w0, [x1, #7]
    // 0xcb5894: ldur            d0, [fp, #-0x88]
    // 0xcb5898: StoreField: r1->field_b = d0
    //     0xcb5898: stur            d0, [x1, #0xb]
    // 0xcb589c: ldur            x0, [fp, #-8]
    // 0xcb58a0: StoreField: r1->field_13 = r0
    //     0xcb58a0: stur            w0, [x1, #0x13]
    // 0xcb58a4: ldur            x0, [fp, #-0x10]
    // 0xcb58a8: StoreField: r1->field_17 = r0
    //     0xcb58a8: stur            w0, [x1, #0x17]
    // 0xcb58ac: mov             x0, x1
    // 0xcb58b0: LeaveFrame
    //     0xcb58b0: mov             SP, fp
    //     0xcb58b4: ldp             fp, lr, [SP], #0x10
    // 0xcb58b8: ret
    //     0xcb58b8: ret             
    // 0xcb58bc: ldur            x1, [fp, #-0x60]
    // 0xcb58c0: ldur            x4, [fp, #-0x28]
    // 0xcb58c4: ldur            x0, [fp, #-0x68]
    // 0xcb58c8: ldur            x3, [fp, #-0x30]
    // 0xcb58cc: b               #0xcb58f4
    // 0xcb58d0: ldur            x1, [fp, #-0x60]
    // 0xcb58d4: ldur            x4, [fp, #-0x28]
    // 0xcb58d8: ldur            x0, [fp, #-0x68]
    // 0xcb58dc: ldur            x3, [fp, #-0x30]
    // 0xcb58e0: b               #0xcb58f4
    // 0xcb58e4: mov             x4, x1
    // 0xcb58e8: ldur            x1, [fp, #-0x60]
    // 0xcb58ec: mov             x3, x0
    // 0xcb58f0: ldur            x0, [fp, #-0x68]
    // 0xcb58f4: LoadField: r2 = r1->field_7
    //     0xcb58f4: ldur            x2, [x1, #7]
    // 0xcb58f8: LoadField: r1 = r3->field_7
    //     0xcb58f8: ldur            x1, [x3, #7]
    // 0xcb58fc: sub             x3, x2, x1
    // 0xcb5900: stur            x3, [fp, #-0x20]
    // 0xcb5904: r0 = Duration()
    //     0xcb5904: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xcb5908: mov             x1, x0
    // 0xcb590c: ldur            x0, [fp, #-0x20]
    // 0xcb5910: stur            x1, [fp, #-8]
    // 0xcb5914: StoreField: r1->field_7 = r0
    //     0xcb5914: stur            x0, [x1, #7]
    // 0xcb5918: ldur            x0, [fp, #-0x68]
    // 0xcb591c: LoadField: r2 = r0->field_b
    //     0xcb591c: ldur            w2, [x0, #0xb]
    // 0xcb5920: DecompressPointer r2
    //     0xcb5920: add             x2, x2, HEAP, lsl #32
    // 0xcb5924: ldur            x0, [fp, #-0x28]
    // 0xcb5928: LoadField: r3 = r0->field_b
    //     0xcb5928: ldur            w3, [x0, #0xb]
    // 0xcb592c: DecompressPointer r3
    //     0xcb592c: add             x3, x3, HEAP, lsl #32
    // 0xcb5930: stp             x3, x2, [SP, #-0x10]!
    // 0xcb5934: r0 = -()
    //     0xcb5934: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xcb5938: add             SP, SP, #0x10
    // 0xcb593c: stur            x0, [fp, #-0x10]
    // 0xcb5940: r0 = VelocityEstimate()
    //     0xcb5940: bl              #0xcb3b54  ; AllocateVelocityEstimateStub -> VelocityEstimate (size=0x1c)
    // 0xcb5944: r1 = Instance_Offset
    //     0xcb5944: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcb5948: StoreField: r0->field_7 = r1
    //     0xcb5948: stur            w1, [x0, #7]
    // 0xcb594c: d0 = 1.000000
    //     0xcb594c: fmov            d0, #1.00000000
    // 0xcb5950: StoreField: r0->field_b = d0
    //     0xcb5950: stur            d0, [x0, #0xb]
    // 0xcb5954: ldur            x1, [fp, #-8]
    // 0xcb5958: StoreField: r0->field_13 = r1
    //     0xcb5958: stur            w1, [x0, #0x13]
    // 0xcb595c: ldur            x1, [fp, #-0x10]
    // 0xcb5960: StoreField: r0->field_17 = r1
    //     0xcb5960: stur            w1, [x0, #0x17]
    // 0xcb5964: LeaveFrame
    //     0xcb5964: mov             SP, fp
    //     0xcb5968: ldp             fp, lr, [SP], #0x10
    // 0xcb596c: ret
    //     0xcb596c: ret             
    // 0xcb5970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb5970: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb5974: b               #0xcb51ac
    // 0xcb5978: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb5978: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb597c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb597c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb5980: b               #0xcb52a8
    // 0xcb5984: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb5984: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb5988: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb5988: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb598c: SaveReg d0
    //     0xcb598c: str             q0, [SP, #-0x10]!
    // 0xcb5990: stp             x4, x5, [SP, #-0x10]!
    // 0xcb5994: stp             x2, x3, [SP, #-0x10]!
    // 0xcb5998: SaveReg r1
    //     0xcb5998: str             x1, [SP, #-8]!
    // 0xcb599c: r0 = AllocateDouble()
    //     0xcb599c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb59a0: RestoreReg r1
    //     0xcb59a0: ldr             x1, [SP], #8
    // 0xcb59a4: ldp             x2, x3, [SP], #0x10
    // 0xcb59a8: ldp             x4, x5, [SP], #0x10
    // 0xcb59ac: RestoreReg d0
    //     0xcb59ac: ldr             q0, [SP], #0x10
    // 0xcb59b0: b               #0xcb5460
    // 0xcb59b4: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb59b4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb59b8: SaveReg d0
    //     0xcb59b8: str             q0, [SP, #-0x10]!
    // 0xcb59bc: stp             x3, x4, [SP, #-0x10]!
    // 0xcb59c0: stp             x1, x2, [SP, #-0x10]!
    // 0xcb59c4: r0 = AllocateDouble()
    //     0xcb59c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb59c8: ldp             x1, x2, [SP], #0x10
    // 0xcb59cc: ldp             x3, x4, [SP], #0x10
    // 0xcb59d0: RestoreReg d0
    //     0xcb59d0: ldr             q0, [SP], #0x10
    // 0xcb59d4: b               #0xcb551c
    // 0xcb59d8: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb59d8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb59dc: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb59dc: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb59e0: SaveReg d0
    //     0xcb59e0: str             q0, [SP, #-0x10]!
    // 0xcb59e4: stp             x3, x4, [SP, #-0x10]!
    // 0xcb59e8: stp             x1, x2, [SP, #-0x10]!
    // 0xcb59ec: r0 = AllocateDouble()
    //     0xcb59ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb59f0: ldp             x1, x2, [SP], #0x10
    // 0xcb59f4: ldp             x3, x4, [SP], #0x10
    // 0xcb59f8: RestoreReg d0
    //     0xcb59f8: ldr             q0, [SP], #0x10
    // 0xcb59fc: b               #0xcb5648
    // 0xcb5a00: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb5a00: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb5a04: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb5a04: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb5a08: r9 = confidence
    //     0xcb5a08: add             x9, PP, #0x38, lsl #12  ; [pp+0x38450] Field <PolynomialFit.confidence>: late (offset: 0xc)
    //     0xcb5a0c: ldr             x9, [x9, #0x450]
    // 0xcb5a10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcb5a10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcb5a14: r9 = confidence
    //     0xcb5a14: add             x9, PP, #0x38, lsl #12  ; [pp+0x38450] Field <PolynomialFit.confidence>: late (offset: 0xc)
    //     0xcb5a18: ldr             x9, [x9, #0x450]
    // 0xcb5a1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcb5a1c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ addPosition(/* No info */) {
    // ** addr: 0xcb5c90, size: 0xcc
    // 0xcb5c90: EnterFrame
    //     0xcb5c90: stp             fp, lr, [SP, #-0x10]!
    //     0xcb5c94: mov             fp, SP
    // 0xcb5c98: AllocStack(0x10)
    //     0xcb5c98: sub             SP, SP, #0x10
    // 0xcb5c9c: ldr             x0, [fp, #0x20]
    // 0xcb5ca0: LoadField: r1 = r0->field_f
    //     0xcb5ca0: ldur            x1, [x0, #0xf]
    // 0xcb5ca4: add             x2, x1, #1
    // 0xcb5ca8: StoreField: r0->field_f = r2
    //     0xcb5ca8: stur            x2, [x0, #0xf]
    // 0xcb5cac: cmp             x2, #0x14
    // 0xcb5cb0: b.ne            #0xcb5cc4
    // 0xcb5cb4: r1 = 0
    //     0xcb5cb4: mov             x1, #0
    // 0xcb5cb8: StoreField: r0->field_f = r1
    //     0xcb5cb8: stur            x1, [x0, #0xf]
    // 0xcb5cbc: r3 = 0
    //     0xcb5cbc: mov             x3, #0
    // 0xcb5cc0: b               #0xcb5cc8
    // 0xcb5cc4: mov             x3, x2
    // 0xcb5cc8: ldr             x2, [fp, #0x18]
    // 0xcb5ccc: ldr             x1, [fp, #0x10]
    // 0xcb5cd0: stur            x3, [fp, #-0x10]
    // 0xcb5cd4: LoadField: r4 = r0->field_b
    //     0xcb5cd4: ldur            w4, [x0, #0xb]
    // 0xcb5cd8: DecompressPointer r4
    //     0xcb5cd8: add             x4, x4, HEAP, lsl #32
    // 0xcb5cdc: stur            x4, [fp, #-8]
    // 0xcb5ce0: r0 = _PointAtTime()
    //     0xcb5ce0: bl              #0xcb5c84  ; Allocate_PointAtTimeStub -> _PointAtTime (size=0x10)
    // 0xcb5ce4: mov             x3, x0
    // 0xcb5ce8: ldr             x2, [fp, #0x10]
    // 0xcb5cec: StoreField: r3->field_b = r2
    //     0xcb5cec: stur            w2, [x3, #0xb]
    // 0xcb5cf0: ldr             x2, [fp, #0x18]
    // 0xcb5cf4: StoreField: r3->field_7 = r2
    //     0xcb5cf4: stur            w2, [x3, #7]
    // 0xcb5cf8: ldur            x2, [fp, #-8]
    // 0xcb5cfc: LoadField: r4 = r2->field_b
    //     0xcb5cfc: ldur            w4, [x2, #0xb]
    // 0xcb5d00: DecompressPointer r4
    //     0xcb5d00: add             x4, x4, HEAP, lsl #32
    // 0xcb5d04: r0 = LoadInt32Instr(r4)
    //     0xcb5d04: sbfx            x0, x4, #1, #0x1f
    // 0xcb5d08: ldur            x1, [fp, #-0x10]
    // 0xcb5d0c: cmp             x1, x0
    // 0xcb5d10: b.hs            #0xcb5d58
    // 0xcb5d14: mov             x1, x2
    // 0xcb5d18: mov             x0, x3
    // 0xcb5d1c: ldur            x2, [fp, #-0x10]
    // 0xcb5d20: ArrayStore: r1[r2] = r0  ; List_4
    //     0xcb5d20: add             x25, x1, x2, lsl #2
    //     0xcb5d24: add             x25, x25, #0xf
    //     0xcb5d28: str             w0, [x25]
    //     0xcb5d2c: tbz             w0, #0, #0xcb5d48
    //     0xcb5d30: ldurb           w16, [x1, #-1]
    //     0xcb5d34: ldurb           w17, [x0, #-1]
    //     0xcb5d38: and             x16, x17, x16, lsr #2
    //     0xcb5d3c: tst             x16, HEAP, lsr #32
    //     0xcb5d40: b.eq            #0xcb5d48
    //     0xcb5d44: bl              #0xd67e5c
    // 0xcb5d48: r0 = Null
    //     0xcb5d48: mov             x0, NULL
    // 0xcb5d4c: LeaveFrame
    //     0xcb5d4c: mov             SP, fp
    //     0xcb5d50: ldp             fp, lr, [SP], #0x10
    // 0xcb5d54: ret
    //     0xcb5d54: ret             
    // 0xcb5d58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb5d58: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 4471, size: 0x1c, field offset: 0x18
class IOSScrollViewFlingVelocityTracker extends VelocityTracker {

  _ _previousVelocityAt(/* No info */) {
    // ** addr: 0xcb4d94, size: 0x1cc
    // 0xcb4d94: EnterFrame
    //     0xcb4d94: stp             fp, lr, [SP, #-0x10]!
    //     0xcb4d98: mov             fp, SP
    // 0xcb4d9c: AllocStack(0x10)
    //     0xcb4d9c: sub             SP, SP, #0x10
    // 0xcb4da0: r0 = 20
    //     0xcb4da0: mov             x0, #0x14
    // 0xcb4da4: CheckStackOverflow
    //     0xcb4da4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4da8: cmp             SP, x16
    //     0xcb4dac: b.ls            #0xcb4f30
    // 0xcb4db0: ldr             x1, [fp, #0x18]
    // 0xcb4db4: LoadField: r2 = r1->field_f
    //     0xcb4db4: ldur            x2, [x1, #0xf]
    // 0xcb4db8: ldr             x3, [fp, #0x10]
    // 0xcb4dbc: add             x4, x2, x3
    // 0xcb4dc0: sdiv            x3, x4, x0
    // 0xcb4dc4: msub            x2, x3, x0, x4
    // 0xcb4dc8: cmp             x2, xzr
    // 0xcb4dcc: b.lt            #0xcb4f38
    // 0xcb4dd0: sub             x3, x4, #1
    // 0xcb4dd4: sdiv            x5, x3, x0
    // 0xcb4dd8: msub            x4, x5, x0, x3
    // 0xcb4ddc: cmp             x4, xzr
    // 0xcb4de0: b.lt            #0xcb4f40
    // 0xcb4de4: LoadField: r3 = r1->field_17
    //     0xcb4de4: ldur            w3, [x1, #0x17]
    // 0xcb4de8: DecompressPointer r3
    //     0xcb4de8: add             x3, x3, HEAP, lsl #32
    // 0xcb4dec: LoadField: r0 = r3->field_b
    //     0xcb4dec: ldur            w0, [x3, #0xb]
    // 0xcb4df0: DecompressPointer r0
    //     0xcb4df0: add             x0, x0, HEAP, lsl #32
    // 0xcb4df4: r5 = LoadInt32Instr(r0)
    //     0xcb4df4: sbfx            x5, x0, #1, #0x1f
    // 0xcb4df8: mov             x0, x5
    // 0xcb4dfc: mov             x1, x2
    // 0xcb4e00: cmp             x1, x0
    // 0xcb4e04: b.hs            #0xcb4f48
    // 0xcb4e08: ArrayLoad: r6 = r3[r2]  ; Unknown_4
    //     0xcb4e08: add             x16, x3, x2, lsl #2
    //     0xcb4e0c: ldur            w6, [x16, #0xf]
    // 0xcb4e10: DecompressPointer r6
    //     0xcb4e10: add             x6, x6, HEAP, lsl #32
    // 0xcb4e14: mov             x0, x5
    // 0xcb4e18: mov             x1, x4
    // 0xcb4e1c: cmp             x1, x0
    // 0xcb4e20: b.hs            #0xcb4f4c
    // 0xcb4e24: ArrayLoad: r0 = r3[r4]  ; Unknown_4
    //     0xcb4e24: add             x16, x3, x4, lsl #2
    //     0xcb4e28: ldur            w0, [x16, #0xf]
    // 0xcb4e2c: DecompressPointer r0
    //     0xcb4e2c: add             x0, x0, HEAP, lsl #32
    // 0xcb4e30: cmp             w6, NULL
    // 0xcb4e34: b.eq            #0xcb4e40
    // 0xcb4e38: cmp             w0, NULL
    // 0xcb4e3c: b.ne            #0xcb4e50
    // 0xcb4e40: r0 = Instance_Offset
    //     0xcb4e40: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcb4e44: LeaveFrame
    //     0xcb4e44: mov             SP, fp
    //     0xcb4e48: ldp             fp, lr, [SP], #0x10
    // 0xcb4e4c: ret
    //     0xcb4e4c: ret             
    // 0xcb4e50: LoadField: r1 = r6->field_7
    //     0xcb4e50: ldur            w1, [x6, #7]
    // 0xcb4e54: DecompressPointer r1
    //     0xcb4e54: add             x1, x1, HEAP, lsl #32
    // 0xcb4e58: LoadField: r2 = r0->field_7
    //     0xcb4e58: ldur            w2, [x0, #7]
    // 0xcb4e5c: DecompressPointer r2
    //     0xcb4e5c: add             x2, x2, HEAP, lsl #32
    // 0xcb4e60: LoadField: r3 = r1->field_7
    //     0xcb4e60: ldur            x3, [x1, #7]
    // 0xcb4e64: LoadField: r1 = r2->field_7
    //     0xcb4e64: ldur            x1, [x2, #7]
    // 0xcb4e68: sub             x2, x3, x1
    // 0xcb4e6c: stur            x2, [fp, #-8]
    // 0xcb4e70: cmp             x2, #0
    // 0xcb4e74: b.le            #0xcb4f20
    // 0xcb4e78: LoadField: r1 = r6->field_b
    //     0xcb4e78: ldur            w1, [x6, #0xb]
    // 0xcb4e7c: DecompressPointer r1
    //     0xcb4e7c: add             x1, x1, HEAP, lsl #32
    // 0xcb4e80: LoadField: r3 = r0->field_b
    //     0xcb4e80: ldur            w3, [x0, #0xb]
    // 0xcb4e84: DecompressPointer r3
    //     0xcb4e84: add             x3, x3, HEAP, lsl #32
    // 0xcb4e88: stp             x3, x1, [SP, #-0x10]!
    // 0xcb4e8c: r0 = -()
    //     0xcb4e8c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xcb4e90: add             SP, SP, #0x10
    // 0xcb4e94: r16 = 1000.000000
    //     0xcb4e94: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c170] 1000
    //     0xcb4e98: ldr             x16, [x16, #0x170]
    // 0xcb4e9c: stp             x16, x0, [SP, #-0x10]!
    // 0xcb4ea0: r0 = *()
    //     0xcb4ea0: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcb4ea4: add             SP, SP, #0x10
    // 0xcb4ea8: mov             x3, x0
    // 0xcb4eac: ldur            x2, [fp, #-8]
    // 0xcb4eb0: stur            x3, [fp, #-0x10]
    // 0xcb4eb4: r0 = BoxInt64Instr(r2)
    //     0xcb4eb4: sbfiz           x0, x2, #1, #0x1f
    //     0xcb4eb8: cmp             x2, x0, asr #1
    //     0xcb4ebc: b.eq            #0xcb4ec8
    //     0xcb4ec0: bl              #0xd69bb8
    //     0xcb4ec4: stur            x2, [x0, #7]
    // 0xcb4ec8: stp             x0, NULL, [SP, #-0x10]!
    // 0xcb4ecc: r0 = _Double.fromInteger()
    //     0xcb4ecc: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xcb4ed0: add             SP, SP, #0x10
    // 0xcb4ed4: LoadField: d0 = r0->field_7
    //     0xcb4ed4: ldur            d0, [x0, #7]
    // 0xcb4ed8: d1 = 1000.000000
    //     0xcb4ed8: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0xcb4edc: ldr             d1, [x17, #0x3b0]
    // 0xcb4ee0: fdiv            d2, d0, d1
    // 0xcb4ee4: r0 = inline_Allocate_Double()
    //     0xcb4ee4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcb4ee8: add             x0, x0, #0x10
    //     0xcb4eec: cmp             x1, x0
    //     0xcb4ef0: b.ls            #0xcb4f50
    //     0xcb4ef4: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb4ef8: sub             x0, x0, #0xf
    //     0xcb4efc: mov             x1, #0xd108
    //     0xcb4f00: movk            x1, #3, lsl #16
    //     0xcb4f04: stur            x1, [x0, #-1]
    // 0xcb4f08: StoreField: r0->field_7 = d2
    //     0xcb4f08: stur            d2, [x0, #7]
    // 0xcb4f0c: ldur            x16, [fp, #-0x10]
    // 0xcb4f10: stp             x0, x16, [SP, #-0x10]!
    // 0xcb4f14: r0 = /()
    //     0xcb4f14: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0xcb4f18: add             SP, SP, #0x10
    // 0xcb4f1c: b               #0xcb4f24
    // 0xcb4f20: r0 = Instance_Offset
    //     0xcb4f20: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcb4f24: LeaveFrame
    //     0xcb4f24: mov             SP, fp
    //     0xcb4f28: ldp             fp, lr, [SP], #0x10
    // 0xcb4f2c: ret
    //     0xcb4f2c: ret             
    // 0xcb4f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb4f30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb4f34: b               #0xcb4db0
    // 0xcb4f38: add             x2, x2, x0
    // 0xcb4f3c: b               #0xcb4dd0
    // 0xcb4f40: add             x4, x4, x0
    // 0xcb4f44: b               #0xcb4de4
    // 0xcb4f48: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4f48: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb4f4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4f4c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb4f50: SaveReg d2
    //     0xcb4f50: str             q2, [SP, #-0x10]!
    // 0xcb4f54: r0 = AllocateDouble()
    //     0xcb4f54: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb4f58: RestoreReg d2
    //     0xcb4f58: ldr             q2, [SP], #0x10
    // 0xcb4f5c: b               #0xcb4f08
  }
  _ getVelocityEstimate(/* No info */) {
    // ** addr: 0xcb4f60, size: 0x234
    // 0xcb4f60: EnterFrame
    //     0xcb4f60: stp             fp, lr, [SP, #-0x10]!
    //     0xcb4f64: mov             fp, SP
    // 0xcb4f68: AllocStack(0x28)
    //     0xcb4f68: sub             SP, SP, #0x28
    // 0xcb4f6c: r0 = -2
    //     0xcb4f6c: mov             x0, #-2
    // 0xcb4f70: CheckStackOverflow
    //     0xcb4f70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4f74: cmp             SP, x16
    //     0xcb4f78: b.ls            #0xcb5174
    // 0xcb4f7c: ldr             x16, [fp, #0x10]
    // 0xcb4f80: stp             x0, x16, [SP, #-0x10]!
    // 0xcb4f84: r0 = _previousVelocityAt()
    //     0xcb4f84: bl              #0xcb4d94  ; [package:flutter/src/gestures/velocity_tracker.dart] IOSScrollViewFlingVelocityTracker::_previousVelocityAt
    // 0xcb4f88: add             SP, SP, #0x10
    // 0xcb4f8c: r16 = 0.600000
    //     0xcb4f8c: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c150] 0.6
    //     0xcb4f90: ldr             x16, [x16, #0x150]
    // 0xcb4f94: stp             x16, x0, [SP, #-0x10]!
    // 0xcb4f98: r0 = *()
    //     0xcb4f98: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcb4f9c: add             SP, SP, #0x10
    // 0xcb4fa0: stur            x0, [fp, #-8]
    // 0xcb4fa4: ldr             x16, [fp, #0x10]
    // 0xcb4fa8: SaveReg r16
    //     0xcb4fa8: str             x16, [SP, #-8]!
    // 0xcb4fac: r1 = -1
    //     0xcb4fac: mov             x1, #-1
    // 0xcb4fb0: SaveReg r1
    //     0xcb4fb0: str             x1, [SP, #-8]!
    // 0xcb4fb4: r0 = _previousVelocityAt()
    //     0xcb4fb4: bl              #0xcb4d94  ; [package:flutter/src/gestures/velocity_tracker.dart] IOSScrollViewFlingVelocityTracker::_previousVelocityAt
    // 0xcb4fb8: add             SP, SP, #0x10
    // 0xcb4fbc: r16 = 0.350000
    //     0xcb4fbc: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c158] 0.35
    //     0xcb4fc0: ldr             x16, [x16, #0x158]
    // 0xcb4fc4: stp             x16, x0, [SP, #-0x10]!
    // 0xcb4fc8: r0 = *()
    //     0xcb4fc8: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcb4fcc: add             SP, SP, #0x10
    // 0xcb4fd0: ldur            x16, [fp, #-8]
    // 0xcb4fd4: stp             x0, x16, [SP, #-0x10]!
    // 0xcb4fd8: r0 = +()
    //     0xcb4fd8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xcb4fdc: add             SP, SP, #0x10
    // 0xcb4fe0: stur            x0, [fp, #-8]
    // 0xcb4fe4: ldr             x16, [fp, #0x10]
    // 0xcb4fe8: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb4fec: r0 = _previousVelocityAt()
    //     0xcb4fec: bl              #0xcb4d94  ; [package:flutter/src/gestures/velocity_tracker.dart] IOSScrollViewFlingVelocityTracker::_previousVelocityAt
    // 0xcb4ff0: add             SP, SP, #0x10
    // 0xcb4ff4: r16 = 0.050000
    //     0xcb4ff4: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c160] 0.05
    //     0xcb4ff8: ldr             x16, [x16, #0x160]
    // 0xcb4ffc: stp             x16, x0, [SP, #-0x10]!
    // 0xcb5000: r0 = *()
    //     0xcb5000: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcb5004: add             SP, SP, #0x10
    // 0xcb5008: ldur            x16, [fp, #-8]
    // 0xcb500c: stp             x0, x16, [SP, #-0x10]!
    // 0xcb5010: r0 = +()
    //     0xcb5010: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xcb5014: add             SP, SP, #0x10
    // 0xcb5018: mov             x2, x0
    // 0xcb501c: ldr             x0, [fp, #0x10]
    // 0xcb5020: stur            x2, [fp, #-0x20]
    // 0xcb5024: LoadField: r3 = r0->field_17
    //     0xcb5024: ldur            w3, [x0, #0x17]
    // 0xcb5028: DecompressPointer r3
    //     0xcb5028: add             x3, x3, HEAP, lsl #32
    // 0xcb502c: LoadField: r4 = r0->field_f
    //     0xcb502c: ldur            x4, [x0, #0xf]
    // 0xcb5030: LoadField: r0 = r3->field_b
    //     0xcb5030: ldur            w0, [x3, #0xb]
    // 0xcb5034: DecompressPointer r0
    //     0xcb5034: add             x0, x0, HEAP, lsl #32
    // 0xcb5038: r5 = LoadInt32Instr(r0)
    //     0xcb5038: sbfx            x5, x0, #1, #0x1f
    // 0xcb503c: mov             x0, x5
    // 0xcb5040: mov             x1, x4
    // 0xcb5044: cmp             x1, x0
    // 0xcb5048: b.hs            #0xcb517c
    // 0xcb504c: ArrayLoad: r6 = r3[r4]  ; Unknown_4
    //     0xcb504c: add             x16, x3, x4, lsl #2
    //     0xcb5050: ldur            w6, [x16, #0xf]
    // 0xcb5054: DecompressPointer r6
    //     0xcb5054: add             x6, x6, HEAP, lsl #32
    // 0xcb5058: stur            x6, [fp, #-0x18]
    // 0xcb505c: r0 = Null
    //     0xcb505c: mov             x0, NULL
    // 0xcb5060: r8 = 1
    //     0xcb5060: mov             x8, #1
    // 0xcb5064: r7 = 20
    //     0xcb5064: mov             x7, #0x14
    // 0xcb5068: CheckStackOverflow
    //     0xcb5068: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb506c: cmp             SP, x16
    //     0xcb5070: b.ls            #0xcb5180
    // 0xcb5074: cmp             x8, #0x14
    // 0xcb5078: b.gt            #0xcb50c0
    // 0xcb507c: add             x0, x4, x8
    // 0xcb5080: sdiv            x1, x0, x7
    // 0xcb5084: msub            x9, x1, x7, x0
    // 0xcb5088: cmp             x9, xzr
    // 0xcb508c: b.lt            #0xcb5188
    // 0xcb5090: mov             x0, x5
    // 0xcb5094: mov             x1, x9
    // 0xcb5098: cmp             x1, x0
    // 0xcb509c: b.hs            #0xcb5190
    // 0xcb50a0: ArrayLoad: r0 = r3[r9]  ; Unknown_4
    //     0xcb50a0: add             x16, x3, x9, lsl #2
    //     0xcb50a4: ldur            w0, [x16, #0xf]
    // 0xcb50a8: DecompressPointer r0
    //     0xcb50a8: add             x0, x0, HEAP, lsl #32
    // 0xcb50ac: cmp             w0, NULL
    // 0xcb50b0: b.ne            #0xcb50c0
    // 0xcb50b4: add             x1, x8, #1
    // 0xcb50b8: mov             x8, x1
    // 0xcb50bc: b               #0xcb5068
    // 0xcb50c0: stur            x0, [fp, #-8]
    // 0xcb50c4: cmp             w0, NULL
    // 0xcb50c8: b.eq            #0xcb50d4
    // 0xcb50cc: cmp             w6, NULL
    // 0xcb50d0: b.ne            #0xcb50e8
    // 0xcb50d4: r0 = Instance_VelocityEstimate
    //     0xcb50d4: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c168] Obj!VelocityEstimate@b386e1
    //     0xcb50d8: ldr             x0, [x0, #0x168]
    // 0xcb50dc: LeaveFrame
    //     0xcb50dc: mov             SP, fp
    //     0xcb50e0: ldp             fp, lr, [SP], #0x10
    // 0xcb50e4: ret
    //     0xcb50e4: ret             
    // 0xcb50e8: LoadField: r1 = r6->field_7
    //     0xcb50e8: ldur            w1, [x6, #7]
    // 0xcb50ec: DecompressPointer r1
    //     0xcb50ec: add             x1, x1, HEAP, lsl #32
    // 0xcb50f0: LoadField: r3 = r0->field_7
    //     0xcb50f0: ldur            w3, [x0, #7]
    // 0xcb50f4: DecompressPointer r3
    //     0xcb50f4: add             x3, x3, HEAP, lsl #32
    // 0xcb50f8: LoadField: r4 = r1->field_7
    //     0xcb50f8: ldur            x4, [x1, #7]
    // 0xcb50fc: LoadField: r1 = r3->field_7
    //     0xcb50fc: ldur            x1, [x3, #7]
    // 0xcb5100: sub             x3, x4, x1
    // 0xcb5104: stur            x3, [fp, #-0x10]
    // 0xcb5108: r0 = Duration()
    //     0xcb5108: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xcb510c: mov             x1, x0
    // 0xcb5110: ldur            x0, [fp, #-0x10]
    // 0xcb5114: stur            x1, [fp, #-0x28]
    // 0xcb5118: StoreField: r1->field_7 = r0
    //     0xcb5118: stur            x0, [x1, #7]
    // 0xcb511c: ldur            x0, [fp, #-0x18]
    // 0xcb5120: LoadField: r2 = r0->field_b
    //     0xcb5120: ldur            w2, [x0, #0xb]
    // 0xcb5124: DecompressPointer r2
    //     0xcb5124: add             x2, x2, HEAP, lsl #32
    // 0xcb5128: ldur            x0, [fp, #-8]
    // 0xcb512c: LoadField: r3 = r0->field_b
    //     0xcb512c: ldur            w3, [x0, #0xb]
    // 0xcb5130: DecompressPointer r3
    //     0xcb5130: add             x3, x3, HEAP, lsl #32
    // 0xcb5134: stp             x3, x2, [SP, #-0x10]!
    // 0xcb5138: r0 = -()
    //     0xcb5138: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xcb513c: add             SP, SP, #0x10
    // 0xcb5140: stur            x0, [fp, #-8]
    // 0xcb5144: r0 = VelocityEstimate()
    //     0xcb5144: bl              #0xcb3b54  ; AllocateVelocityEstimateStub -> VelocityEstimate (size=0x1c)
    // 0xcb5148: ldur            x1, [fp, #-0x20]
    // 0xcb514c: StoreField: r0->field_7 = r1
    //     0xcb514c: stur            w1, [x0, #7]
    // 0xcb5150: d0 = 1.000000
    //     0xcb5150: fmov            d0, #1.00000000
    // 0xcb5154: StoreField: r0->field_b = d0
    //     0xcb5154: stur            d0, [x0, #0xb]
    // 0xcb5158: ldur            x1, [fp, #-0x28]
    // 0xcb515c: StoreField: r0->field_13 = r1
    //     0xcb515c: stur            w1, [x0, #0x13]
    // 0xcb5160: ldur            x1, [fp, #-8]
    // 0xcb5164: StoreField: r0->field_17 = r1
    //     0xcb5164: stur            w1, [x0, #0x17]
    // 0xcb5168: LeaveFrame
    //     0xcb5168: mov             SP, fp
    //     0xcb516c: ldp             fp, lr, [SP], #0x10
    // 0xcb5170: ret
    //     0xcb5170: ret             
    // 0xcb5174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb5174: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb5178: b               #0xcb4f7c
    // 0xcb517c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb517c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb5180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb5180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb5184: b               #0xcb5074
    // 0xcb5188: add             x9, x9, x7
    // 0xcb518c: b               #0xcb5090
    // 0xcb5190: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb5190: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ addPosition(/* No info */) {
    // ** addr: 0xcb5bc0, size: 0xc4
    // 0xcb5bc0: EnterFrame
    //     0xcb5bc0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb5bc4: mov             fp, SP
    // 0xcb5bc8: AllocStack(0x10)
    //     0xcb5bc8: sub             SP, SP, #0x10
    // 0xcb5bcc: r0 = 20
    //     0xcb5bcc: mov             x0, #0x14
    // 0xcb5bd0: ldr             x1, [fp, #0x20]
    // 0xcb5bd4: LoadField: r2 = r1->field_f
    //     0xcb5bd4: ldur            x2, [x1, #0xf]
    // 0xcb5bd8: add             x3, x2, #1
    // 0xcb5bdc: sdiv            x4, x3, x0
    // 0xcb5be0: msub            x2, x4, x0, x3
    // 0xcb5be4: cmp             x2, xzr
    // 0xcb5be8: b.lt            #0xcb5c78
    // 0xcb5bec: stur            x2, [fp, #-0x10]
    // 0xcb5bf0: StoreField: r1->field_f = r2
    //     0xcb5bf0: stur            x2, [x1, #0xf]
    // 0xcb5bf4: LoadField: r0 = r1->field_17
    //     0xcb5bf4: ldur            w0, [x1, #0x17]
    // 0xcb5bf8: DecompressPointer r0
    //     0xcb5bf8: add             x0, x0, HEAP, lsl #32
    // 0xcb5bfc: stur            x0, [fp, #-8]
    // 0xcb5c00: r0 = _PointAtTime()
    //     0xcb5c00: bl              #0xcb5c84  ; Allocate_PointAtTimeStub -> _PointAtTime (size=0x10)
    // 0xcb5c04: mov             x3, x0
    // 0xcb5c08: ldr             x2, [fp, #0x10]
    // 0xcb5c0c: StoreField: r3->field_b = r2
    //     0xcb5c0c: stur            w2, [x3, #0xb]
    // 0xcb5c10: ldr             x2, [fp, #0x18]
    // 0xcb5c14: StoreField: r3->field_7 = r2
    //     0xcb5c14: stur            w2, [x3, #7]
    // 0xcb5c18: ldur            x2, [fp, #-8]
    // 0xcb5c1c: LoadField: r4 = r2->field_b
    //     0xcb5c1c: ldur            w4, [x2, #0xb]
    // 0xcb5c20: DecompressPointer r4
    //     0xcb5c20: add             x4, x4, HEAP, lsl #32
    // 0xcb5c24: r0 = LoadInt32Instr(r4)
    //     0xcb5c24: sbfx            x0, x4, #1, #0x1f
    // 0xcb5c28: ldur            x1, [fp, #-0x10]
    // 0xcb5c2c: cmp             x1, x0
    // 0xcb5c30: b.hs            #0xcb5c80
    // 0xcb5c34: mov             x1, x2
    // 0xcb5c38: mov             x0, x3
    // 0xcb5c3c: ldur            x2, [fp, #-0x10]
    // 0xcb5c40: ArrayStore: r1[r2] = r0  ; List_4
    //     0xcb5c40: add             x25, x1, x2, lsl #2
    //     0xcb5c44: add             x25, x25, #0xf
    //     0xcb5c48: str             w0, [x25]
    //     0xcb5c4c: tbz             w0, #0, #0xcb5c68
    //     0xcb5c50: ldurb           w16, [x1, #-1]
    //     0xcb5c54: ldurb           w17, [x0, #-1]
    //     0xcb5c58: and             x16, x17, x16, lsr #2
    //     0xcb5c5c: tst             x16, HEAP, lsr #32
    //     0xcb5c60: b.eq            #0xcb5c68
    //     0xcb5c64: bl              #0xd67e5c
    // 0xcb5c68: r0 = Null
    //     0xcb5c68: mov             x0, NULL
    // 0xcb5c6c: LeaveFrame
    //     0xcb5c6c: mov             SP, fp
    //     0xcb5c70: ldp             fp, lr, [SP], #0x10
    // 0xcb5c74: ret
    //     0xcb5c74: ret             
    // 0xcb5c78: add             x2, x2, x0
    // 0xcb5c7c: b               #0xcb5bec
    // 0xcb5c80: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb5c80: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 4472, size: 0x1c, field offset: 0x1c
class MacOSScrollViewFlingVelocityTracker extends IOSScrollViewFlingVelocityTracker {

  _ getVelocityEstimate(/* No info */) {
    // ** addr: 0xcb4b60, size: 0x234
    // 0xcb4b60: EnterFrame
    //     0xcb4b60: stp             fp, lr, [SP, #-0x10]!
    //     0xcb4b64: mov             fp, SP
    // 0xcb4b68: AllocStack(0x28)
    //     0xcb4b68: sub             SP, SP, #0x28
    // 0xcb4b6c: r0 = -2
    //     0xcb4b6c: mov             x0, #-2
    // 0xcb4b70: CheckStackOverflow
    //     0xcb4b70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4b74: cmp             SP, x16
    //     0xcb4b78: b.ls            #0xcb4d74
    // 0xcb4b7c: ldr             x16, [fp, #0x10]
    // 0xcb4b80: stp             x0, x16, [SP, #-0x10]!
    // 0xcb4b84: r0 = _previousVelocityAt()
    //     0xcb4b84: bl              #0xcb4d94  ; [package:flutter/src/gestures/velocity_tracker.dart] IOSScrollViewFlingVelocityTracker::_previousVelocityAt
    // 0xcb4b88: add             SP, SP, #0x10
    // 0xcb4b8c: r16 = 0.150000
    //     0xcb4b8c: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c178] 0.15
    //     0xcb4b90: ldr             x16, [x16, #0x178]
    // 0xcb4b94: stp             x16, x0, [SP, #-0x10]!
    // 0xcb4b98: r0 = *()
    //     0xcb4b98: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcb4b9c: add             SP, SP, #0x10
    // 0xcb4ba0: stur            x0, [fp, #-8]
    // 0xcb4ba4: ldr             x16, [fp, #0x10]
    // 0xcb4ba8: SaveReg r16
    //     0xcb4ba8: str             x16, [SP, #-8]!
    // 0xcb4bac: r1 = -1
    //     0xcb4bac: mov             x1, #-1
    // 0xcb4bb0: SaveReg r1
    //     0xcb4bb0: str             x1, [SP, #-8]!
    // 0xcb4bb4: r0 = _previousVelocityAt()
    //     0xcb4bb4: bl              #0xcb4d94  ; [package:flutter/src/gestures/velocity_tracker.dart] IOSScrollViewFlingVelocityTracker::_previousVelocityAt
    // 0xcb4bb8: add             SP, SP, #0x10
    // 0xcb4bbc: r16 = 0.650000
    //     0xcb4bbc: add             x16, PP, #0x4c, lsl #12  ; [pp+0x4c180] 0.65
    //     0xcb4bc0: ldr             x16, [x16, #0x180]
    // 0xcb4bc4: stp             x16, x0, [SP, #-0x10]!
    // 0xcb4bc8: r0 = *()
    //     0xcb4bc8: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcb4bcc: add             SP, SP, #0x10
    // 0xcb4bd0: ldur            x16, [fp, #-8]
    // 0xcb4bd4: stp             x0, x16, [SP, #-0x10]!
    // 0xcb4bd8: r0 = +()
    //     0xcb4bd8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xcb4bdc: add             SP, SP, #0x10
    // 0xcb4be0: stur            x0, [fp, #-8]
    // 0xcb4be4: ldr             x16, [fp, #0x10]
    // 0xcb4be8: stp             xzr, x16, [SP, #-0x10]!
    // 0xcb4bec: r0 = _previousVelocityAt()
    //     0xcb4bec: bl              #0xcb4d94  ; [package:flutter/src/gestures/velocity_tracker.dart] IOSScrollViewFlingVelocityTracker::_previousVelocityAt
    // 0xcb4bf0: add             SP, SP, #0x10
    // 0xcb4bf4: r16 = 0.200000
    //     0xcb4bf4: add             x16, PP, #0x25, lsl #12  ; [pp+0x25df0] 0.2
    //     0xcb4bf8: ldr             x16, [x16, #0xdf0]
    // 0xcb4bfc: stp             x16, x0, [SP, #-0x10]!
    // 0xcb4c00: r0 = *()
    //     0xcb4c00: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0xcb4c04: add             SP, SP, #0x10
    // 0xcb4c08: ldur            x16, [fp, #-8]
    // 0xcb4c0c: stp             x0, x16, [SP, #-0x10]!
    // 0xcb4c10: r0 = +()
    //     0xcb4c10: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xcb4c14: add             SP, SP, #0x10
    // 0xcb4c18: mov             x2, x0
    // 0xcb4c1c: ldr             x0, [fp, #0x10]
    // 0xcb4c20: stur            x2, [fp, #-0x20]
    // 0xcb4c24: LoadField: r3 = r0->field_17
    //     0xcb4c24: ldur            w3, [x0, #0x17]
    // 0xcb4c28: DecompressPointer r3
    //     0xcb4c28: add             x3, x3, HEAP, lsl #32
    // 0xcb4c2c: LoadField: r4 = r0->field_f
    //     0xcb4c2c: ldur            x4, [x0, #0xf]
    // 0xcb4c30: LoadField: r0 = r3->field_b
    //     0xcb4c30: ldur            w0, [x3, #0xb]
    // 0xcb4c34: DecompressPointer r0
    //     0xcb4c34: add             x0, x0, HEAP, lsl #32
    // 0xcb4c38: r5 = LoadInt32Instr(r0)
    //     0xcb4c38: sbfx            x5, x0, #1, #0x1f
    // 0xcb4c3c: mov             x0, x5
    // 0xcb4c40: mov             x1, x4
    // 0xcb4c44: cmp             x1, x0
    // 0xcb4c48: b.hs            #0xcb4d7c
    // 0xcb4c4c: ArrayLoad: r6 = r3[r4]  ; Unknown_4
    //     0xcb4c4c: add             x16, x3, x4, lsl #2
    //     0xcb4c50: ldur            w6, [x16, #0xf]
    // 0xcb4c54: DecompressPointer r6
    //     0xcb4c54: add             x6, x6, HEAP, lsl #32
    // 0xcb4c58: stur            x6, [fp, #-0x18]
    // 0xcb4c5c: r0 = Null
    //     0xcb4c5c: mov             x0, NULL
    // 0xcb4c60: r8 = 1
    //     0xcb4c60: mov             x8, #1
    // 0xcb4c64: r7 = 20
    //     0xcb4c64: mov             x7, #0x14
    // 0xcb4c68: CheckStackOverflow
    //     0xcb4c68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4c6c: cmp             SP, x16
    //     0xcb4c70: b.ls            #0xcb4d80
    // 0xcb4c74: cmp             x8, #0x14
    // 0xcb4c78: b.gt            #0xcb4cc0
    // 0xcb4c7c: add             x0, x4, x8
    // 0xcb4c80: sdiv            x1, x0, x7
    // 0xcb4c84: msub            x9, x1, x7, x0
    // 0xcb4c88: cmp             x9, xzr
    // 0xcb4c8c: b.lt            #0xcb4d88
    // 0xcb4c90: mov             x0, x5
    // 0xcb4c94: mov             x1, x9
    // 0xcb4c98: cmp             x1, x0
    // 0xcb4c9c: b.hs            #0xcb4d90
    // 0xcb4ca0: ArrayLoad: r0 = r3[r9]  ; Unknown_4
    //     0xcb4ca0: add             x16, x3, x9, lsl #2
    //     0xcb4ca4: ldur            w0, [x16, #0xf]
    // 0xcb4ca8: DecompressPointer r0
    //     0xcb4ca8: add             x0, x0, HEAP, lsl #32
    // 0xcb4cac: cmp             w0, NULL
    // 0xcb4cb0: b.ne            #0xcb4cc0
    // 0xcb4cb4: add             x1, x8, #1
    // 0xcb4cb8: mov             x8, x1
    // 0xcb4cbc: b               #0xcb4c68
    // 0xcb4cc0: stur            x0, [fp, #-8]
    // 0xcb4cc4: cmp             w0, NULL
    // 0xcb4cc8: b.eq            #0xcb4cd4
    // 0xcb4ccc: cmp             w6, NULL
    // 0xcb4cd0: b.ne            #0xcb4ce8
    // 0xcb4cd4: r0 = Instance_VelocityEstimate
    //     0xcb4cd4: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c168] Obj!VelocityEstimate@b386e1
    //     0xcb4cd8: ldr             x0, [x0, #0x168]
    // 0xcb4cdc: LeaveFrame
    //     0xcb4cdc: mov             SP, fp
    //     0xcb4ce0: ldp             fp, lr, [SP], #0x10
    // 0xcb4ce4: ret
    //     0xcb4ce4: ret             
    // 0xcb4ce8: LoadField: r1 = r6->field_7
    //     0xcb4ce8: ldur            w1, [x6, #7]
    // 0xcb4cec: DecompressPointer r1
    //     0xcb4cec: add             x1, x1, HEAP, lsl #32
    // 0xcb4cf0: LoadField: r3 = r0->field_7
    //     0xcb4cf0: ldur            w3, [x0, #7]
    // 0xcb4cf4: DecompressPointer r3
    //     0xcb4cf4: add             x3, x3, HEAP, lsl #32
    // 0xcb4cf8: LoadField: r4 = r1->field_7
    //     0xcb4cf8: ldur            x4, [x1, #7]
    // 0xcb4cfc: LoadField: r1 = r3->field_7
    //     0xcb4cfc: ldur            x1, [x3, #7]
    // 0xcb4d00: sub             x3, x4, x1
    // 0xcb4d04: stur            x3, [fp, #-0x10]
    // 0xcb4d08: r0 = Duration()
    //     0xcb4d08: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xcb4d0c: mov             x1, x0
    // 0xcb4d10: ldur            x0, [fp, #-0x10]
    // 0xcb4d14: stur            x1, [fp, #-0x28]
    // 0xcb4d18: StoreField: r1->field_7 = r0
    //     0xcb4d18: stur            x0, [x1, #7]
    // 0xcb4d1c: ldur            x0, [fp, #-0x18]
    // 0xcb4d20: LoadField: r2 = r0->field_b
    //     0xcb4d20: ldur            w2, [x0, #0xb]
    // 0xcb4d24: DecompressPointer r2
    //     0xcb4d24: add             x2, x2, HEAP, lsl #32
    // 0xcb4d28: ldur            x0, [fp, #-8]
    // 0xcb4d2c: LoadField: r3 = r0->field_b
    //     0xcb4d2c: ldur            w3, [x0, #0xb]
    // 0xcb4d30: DecompressPointer r3
    //     0xcb4d30: add             x3, x3, HEAP, lsl #32
    // 0xcb4d34: stp             x3, x2, [SP, #-0x10]!
    // 0xcb4d38: r0 = -()
    //     0xcb4d38: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xcb4d3c: add             SP, SP, #0x10
    // 0xcb4d40: stur            x0, [fp, #-8]
    // 0xcb4d44: r0 = VelocityEstimate()
    //     0xcb4d44: bl              #0xcb3b54  ; AllocateVelocityEstimateStub -> VelocityEstimate (size=0x1c)
    // 0xcb4d48: ldur            x1, [fp, #-0x20]
    // 0xcb4d4c: StoreField: r0->field_7 = r1
    //     0xcb4d4c: stur            w1, [x0, #7]
    // 0xcb4d50: d0 = 1.000000
    //     0xcb4d50: fmov            d0, #1.00000000
    // 0xcb4d54: StoreField: r0->field_b = d0
    //     0xcb4d54: stur            d0, [x0, #0xb]
    // 0xcb4d58: ldur            x1, [fp, #-0x28]
    // 0xcb4d5c: StoreField: r0->field_13 = r1
    //     0xcb4d5c: stur            w1, [x0, #0x13]
    // 0xcb4d60: ldur            x1, [fp, #-8]
    // 0xcb4d64: StoreField: r0->field_17 = r1
    //     0xcb4d64: stur            w1, [x0, #0x17]
    // 0xcb4d68: LeaveFrame
    //     0xcb4d68: mov             SP, fp
    //     0xcb4d6c: ldp             fp, lr, [SP], #0x10
    // 0xcb4d70: ret
    //     0xcb4d70: ret             
    // 0xcb4d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb4d74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb4d78: b               #0xcb4b7c
    // 0xcb4d7c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4d7c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb4d80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb4d80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb4d84: b               #0xcb4c74
    // 0xcb4d88: add             x9, x9, x7
    // 0xcb4d8c: b               #0xcb4c90
    // 0xcb4d90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4d90: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

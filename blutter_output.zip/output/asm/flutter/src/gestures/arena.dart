// lib: , url: package:flutter/src/gestures/arena.dart

// class id: 1049149, size: 0x8
class :: {
}

// class id: 2337, size: 0xc, field offset: 0x8
class GestureArenaManager extends Object {

  _ add(/* No info */) {
    // ** addr: 0x7112b0, size: 0x140
    // 0x7112b0: EnterFrame
    //     0x7112b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7112b4: mov             fp, SP
    // 0x7112b8: AllocStack(0x10)
    //     0x7112b8: sub             SP, SP, #0x10
    // 0x7112bc: CheckStackOverflow
    //     0x7112bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7112c0: cmp             SP, x16
    //     0x7112c4: b.ls            #0x7113e4
    // 0x7112c8: ldr             x3, [fp, #0x20]
    // 0x7112cc: LoadField: r4 = r3->field_7
    //     0x7112cc: ldur            w4, [x3, #7]
    // 0x7112d0: DecompressPointer r4
    //     0x7112d0: add             x4, x4, HEAP, lsl #32
    // 0x7112d4: ldr             x5, [fp, #0x18]
    // 0x7112d8: stur            x4, [fp, #-0x10]
    // 0x7112dc: r0 = BoxInt64Instr(r5)
    //     0x7112dc: sbfiz           x0, x5, #1, #0x1f
    //     0x7112e0: cmp             x5, x0, asr #1
    //     0x7112e4: b.eq            #0x7112f0
    //     0x7112e8: bl              #0xd69bb8
    //     0x7112ec: stur            x5, [x0, #7]
    // 0x7112f0: r1 = Function '<anonymous closure>':.
    //     0x7112f0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ef8] AnonymousClosure: (0x7113fc), in [package:flutter/src/gestures/arena.dart] GestureArenaManager::add (0x7112b0)
    //     0x7112f4: ldr             x1, [x1, #0xef8]
    // 0x7112f8: r2 = Null
    //     0x7112f8: mov             x2, NULL
    // 0x7112fc: stur            x0, [fp, #-8]
    // 0x711300: r0 = AllocateClosure()
    //     0x711300: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x711304: ldur            x16, [fp, #-0x10]
    // 0x711308: ldur            lr, [fp, #-8]
    // 0x71130c: stp             lr, x16, [SP, #-0x10]!
    // 0x711310: SaveReg r0
    //     0x711310: str             x0, [SP, #-8]!
    // 0x711314: r0 = putIfAbsent()
    //     0x711314: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x711318: add             SP, SP, #0x18
    // 0x71131c: LoadField: r1 = r0->field_7
    //     0x71131c: ldur            w1, [x0, #7]
    // 0x711320: DecompressPointer r1
    //     0x711320: add             x1, x1, HEAP, lsl #32
    // 0x711324: stur            x1, [fp, #-0x10]
    // 0x711328: LoadField: r0 = r1->field_b
    //     0x711328: ldur            w0, [x1, #0xb]
    // 0x71132c: DecompressPointer r0
    //     0x71132c: add             x0, x0, HEAP, lsl #32
    // 0x711330: stur            x0, [fp, #-8]
    // 0x711334: LoadField: r2 = r1->field_f
    //     0x711334: ldur            w2, [x1, #0xf]
    // 0x711338: DecompressPointer r2
    //     0x711338: add             x2, x2, HEAP, lsl #32
    // 0x71133c: LoadField: r3 = r2->field_b
    //     0x71133c: ldur            w3, [x2, #0xb]
    // 0x711340: DecompressPointer r3
    //     0x711340: add             x3, x3, HEAP, lsl #32
    // 0x711344: cmp             w0, w3
    // 0x711348: b.ne            #0x711358
    // 0x71134c: SaveReg r1
    //     0x71134c: str             x1, [SP, #-8]!
    // 0x711350: r0 = _growToNextCapacity()
    //     0x711350: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x711354: add             SP, SP, #8
    // 0x711358: ldr             x3, [fp, #0x20]
    // 0x71135c: ldr             x4, [fp, #0x18]
    // 0x711360: ldr             x5, [fp, #0x10]
    // 0x711364: ldur            x2, [fp, #-0x10]
    // 0x711368: ldur            x0, [fp, #-8]
    // 0x71136c: r6 = LoadInt32Instr(r0)
    //     0x71136c: sbfx            x6, x0, #1, #0x1f
    // 0x711370: add             x0, x6, #1
    // 0x711374: lsl             x1, x0, #1
    // 0x711378: StoreField: r2->field_b = r1
    //     0x711378: stur            w1, [x2, #0xb]
    // 0x71137c: mov             x1, x6
    // 0x711380: cmp             x1, x0
    // 0x711384: b.hs            #0x7113ec
    // 0x711388: LoadField: r1 = r2->field_f
    //     0x711388: ldur            w1, [x2, #0xf]
    // 0x71138c: DecompressPointer r1
    //     0x71138c: add             x1, x1, HEAP, lsl #32
    // 0x711390: mov             x0, x5
    // 0x711394: ArrayStore: r1[r6] = r0  ; List_4
    //     0x711394: add             x25, x1, x6, lsl #2
    //     0x711398: add             x25, x25, #0xf
    //     0x71139c: str             w0, [x25]
    //     0x7113a0: tbz             w0, #0, #0x7113bc
    //     0x7113a4: ldurb           w16, [x1, #-1]
    //     0x7113a8: ldurb           w17, [x0, #-1]
    //     0x7113ac: and             x16, x17, x16, lsr #2
    //     0x7113b0: tst             x16, HEAP, lsr #32
    //     0x7113b4: b.eq            #0x7113bc
    //     0x7113b8: bl              #0xd67e5c
    // 0x7113bc: r0 = GestureArenaEntry()
    //     0x7113bc: bl              #0x7113f0  ; AllocateGestureArenaEntryStub -> GestureArenaEntry (size=0x18)
    // 0x7113c0: ldr             x1, [fp, #0x20]
    // 0x7113c4: StoreField: r0->field_7 = r1
    //     0x7113c4: stur            w1, [x0, #7]
    // 0x7113c8: ldr             x1, [fp, #0x18]
    // 0x7113cc: StoreField: r0->field_b = r1
    //     0x7113cc: stur            x1, [x0, #0xb]
    // 0x7113d0: ldr             x1, [fp, #0x10]
    // 0x7113d4: StoreField: r0->field_13 = r1
    //     0x7113d4: stur            w1, [x0, #0x13]
    // 0x7113d8: LeaveFrame
    //     0x7113d8: mov             SP, fp
    //     0x7113dc: ldp             fp, lr, [SP], #0x10
    // 0x7113e0: ret
    //     0x7113e0: ret             
    // 0x7113e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7113e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7113e8: b               #0x7112c8
    // 0x7113ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7113ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] _GestureArena <anonymous closure>(dynamic) {
    // ** addr: 0x7113fc, size: 0x84
    // 0x7113fc: EnterFrame
    //     0x7113fc: stp             fp, lr, [SP, #-0x10]!
    //     0x711400: mov             fp, SP
    // 0x711404: AllocStack(0x8)
    //     0x711404: sub             SP, SP, #8
    // 0x711408: CheckStackOverflow
    //     0x711408: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71140c: cmp             SP, x16
    //     0x711410: b.ls            #0x711478
    // 0x711414: r0 = _GestureArena()
    //     0x711414: bl              #0x711480  ; Allocate_GestureArenaStub -> _GestureArena (size=0x1c)
    // 0x711418: mov             x1, x0
    // 0x71141c: r0 = true
    //     0x71141c: add             x0, NULL, #0x20  ; true
    // 0x711420: stur            x1, [fp, #-8]
    // 0x711424: StoreField: r1->field_b = r0
    //     0x711424: stur            w0, [x1, #0xb]
    // 0x711428: r0 = false
    //     0x711428: add             x0, NULL, #0x30  ; false
    // 0x71142c: StoreField: r1->field_f = r0
    //     0x71142c: stur            w0, [x1, #0xf]
    // 0x711430: StoreField: r1->field_13 = r0
    //     0x711430: stur            w0, [x1, #0x13]
    // 0x711434: r16 = <GestureArenaMember>
    //     0x711434: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f00] TypeArguments: <GestureArenaMember>
    //     0x711438: ldr             x16, [x16, #0xf00]
    // 0x71143c: stp             xzr, x16, [SP, #-0x10]!
    // 0x711440: r0 = _GrowableList()
    //     0x711440: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x711444: add             SP, SP, #0x10
    // 0x711448: ldur            x1, [fp, #-8]
    // 0x71144c: StoreField: r1->field_7 = r0
    //     0x71144c: stur            w0, [x1, #7]
    //     0x711450: ldurb           w16, [x1, #-1]
    //     0x711454: ldurb           w17, [x0, #-1]
    //     0x711458: and             x16, x17, x16, lsr #2
    //     0x71145c: tst             x16, HEAP, lsr #32
    //     0x711460: b.eq            #0x711468
    //     0x711464: bl              #0xd6826c
    // 0x711468: mov             x0, x1
    // 0x71146c: LeaveFrame
    //     0x71146c: mov             SP, fp
    //     0x711470: ldp             fp, lr, [SP], #0x10
    // 0x711474: ret
    //     0x711474: ret             
    // 0x711478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711478: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71147c: b               #0x711414
  }
  _ sweep(/* No info */) {
    // ** addr: 0x714e10, size: 0x1b4
    // 0x714e10: EnterFrame
    //     0x714e10: stp             fp, lr, [SP, #-0x10]!
    //     0x714e14: mov             fp, SP
    // 0x714e18: AllocStack(0x20)
    //     0x714e18: sub             SP, SP, #0x20
    // 0x714e1c: CheckStackOverflow
    //     0x714e1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714e20: cmp             SP, x16
    //     0x714e24: b.ls            #0x714fb0
    // 0x714e28: ldr             x0, [fp, #0x18]
    // 0x714e2c: LoadField: r2 = r0->field_7
    //     0x714e2c: ldur            w2, [x0, #7]
    // 0x714e30: DecompressPointer r2
    //     0x714e30: add             x2, x2, HEAP, lsl #32
    // 0x714e34: ldr             x3, [fp, #0x10]
    // 0x714e38: stur            x2, [fp, #-0x10]
    // 0x714e3c: r0 = BoxInt64Instr(r3)
    //     0x714e3c: sbfiz           x0, x3, #1, #0x1f
    //     0x714e40: cmp             x3, x0, asr #1
    //     0x714e44: b.eq            #0x714e50
    //     0x714e48: bl              #0xd69bb8
    //     0x714e4c: stur            x3, [x0, #7]
    // 0x714e50: stur            x0, [fp, #-8]
    // 0x714e54: stp             x0, x2, [SP, #-0x10]!
    // 0x714e58: r0 = _getValueOrData()
    //     0x714e58: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x714e5c: add             SP, SP, #0x10
    // 0x714e60: mov             x1, x0
    // 0x714e64: ldur            x0, [fp, #-0x10]
    // 0x714e68: LoadField: r2 = r0->field_f
    //     0x714e68: ldur            w2, [x0, #0xf]
    // 0x714e6c: DecompressPointer r2
    //     0x714e6c: add             x2, x2, HEAP, lsl #32
    // 0x714e70: cmp             w2, w1
    // 0x714e74: b.ne            #0x714e7c
    // 0x714e78: r1 = Null
    //     0x714e78: mov             x1, NULL
    // 0x714e7c: stur            x1, [fp, #-0x18]
    // 0x714e80: cmp             w1, NULL
    // 0x714e84: b.ne            #0x714e98
    // 0x714e88: r0 = Null
    //     0x714e88: mov             x0, NULL
    // 0x714e8c: LeaveFrame
    //     0x714e8c: mov             SP, fp
    //     0x714e90: ldp             fp, lr, [SP], #0x10
    // 0x714e94: ret
    //     0x714e94: ret             
    // 0x714e98: LoadField: r2 = r1->field_f
    //     0x714e98: ldur            w2, [x1, #0xf]
    // 0x714e9c: DecompressPointer r2
    //     0x714e9c: add             x2, x2, HEAP, lsl #32
    // 0x714ea0: tbnz            w2, #4, #0x714ebc
    // 0x714ea4: r0 = true
    //     0x714ea4: add             x0, NULL, #0x20  ; true
    // 0x714ea8: StoreField: r1->field_13 = r0
    //     0x714ea8: stur            w0, [x1, #0x13]
    // 0x714eac: r0 = Null
    //     0x714eac: mov             x0, NULL
    // 0x714eb0: LeaveFrame
    //     0x714eb0: mov             SP, fp
    //     0x714eb4: ldp             fp, lr, [SP], #0x10
    // 0x714eb8: ret
    //     0x714eb8: ret             
    // 0x714ebc: ldur            x16, [fp, #-8]
    // 0x714ec0: stp             x16, x0, [SP, #-0x10]!
    // 0x714ec4: r0 = remove()
    //     0x714ec4: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x714ec8: add             SP, SP, #0x10
    // 0x714ecc: ldur            x0, [fp, #-0x18]
    // 0x714ed0: LoadField: r1 = r0->field_7
    //     0x714ed0: ldur            w1, [x0, #7]
    // 0x714ed4: DecompressPointer r1
    //     0x714ed4: add             x1, x1, HEAP, lsl #32
    // 0x714ed8: stur            x1, [fp, #-8]
    // 0x714edc: LoadField: r0 = r1->field_b
    //     0x714edc: ldur            w0, [x1, #0xb]
    // 0x714ee0: DecompressPointer r0
    //     0x714ee0: add             x0, x0, HEAP, lsl #32
    // 0x714ee4: cbz             w0, #0x714fa0
    // 0x714ee8: ldr             x0, [fp, #0x10]
    // 0x714eec: SaveReg r1
    //     0x714eec: str             x1, [SP, #-8]!
    // 0x714ef0: r0 = first()
    //     0x714ef0: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x714ef4: add             SP, SP, #8
    // 0x714ef8: r1 = LoadClassIdInstr(r0)
    //     0x714ef8: ldur            x1, [x0, #-1]
    //     0x714efc: ubfx            x1, x1, #0xc, #0x14
    // 0x714f00: SaveReg r0
    //     0x714f00: str             x0, [SP, #-8]!
    // 0x714f04: ldr             x2, [fp, #0x10]
    // 0x714f08: SaveReg r2
    //     0x714f08: str             x2, [SP, #-8]!
    // 0x714f0c: mov             x0, x1
    // 0x714f10: r0 = GDT[cid_x0 + 0x18e8]()
    //     0x714f10: mov             x17, #0x18e8
    //     0x714f14: add             lr, x0, x17
    //     0x714f18: ldr             lr, [x21, lr, lsl #3]
    //     0x714f1c: blr             lr
    // 0x714f20: add             SP, SP, #0x10
    // 0x714f24: r4 = 1
    //     0x714f24: mov             x4, #1
    // 0x714f28: ldr             x2, [fp, #0x10]
    // 0x714f2c: ldur            x3, [fp, #-8]
    // 0x714f30: stur            x4, [fp, #-0x20]
    // 0x714f34: CheckStackOverflow
    //     0x714f34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714f38: cmp             SP, x16
    //     0x714f3c: b.ls            #0x714fb8
    // 0x714f40: LoadField: r0 = r3->field_b
    //     0x714f40: ldur            w0, [x3, #0xb]
    // 0x714f44: DecompressPointer r0
    //     0x714f44: add             x0, x0, HEAP, lsl #32
    // 0x714f48: r1 = LoadInt32Instr(r0)
    //     0x714f48: sbfx            x1, x0, #1, #0x1f
    // 0x714f4c: cmp             x4, x1
    // 0x714f50: b.ge            #0x714fa0
    // 0x714f54: mov             x0, x1
    // 0x714f58: mov             x1, x4
    // 0x714f5c: cmp             x1, x0
    // 0x714f60: b.hs            #0x714fc0
    // 0x714f64: LoadField: r0 = r3->field_f
    //     0x714f64: ldur            w0, [x3, #0xf]
    // 0x714f68: DecompressPointer r0
    //     0x714f68: add             x0, x0, HEAP, lsl #32
    // 0x714f6c: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x714f6c: add             x16, x0, x4, lsl #2
    //     0x714f70: ldur            w1, [x16, #0xf]
    // 0x714f74: DecompressPointer r1
    //     0x714f74: add             x1, x1, HEAP, lsl #32
    // 0x714f78: r0 = LoadClassIdInstr(r1)
    //     0x714f78: ldur            x0, [x1, #-1]
    //     0x714f7c: ubfx            x0, x0, #0xc, #0x14
    // 0x714f80: stp             x2, x1, [SP, #-0x10]!
    // 0x714f84: r0 = GDT[cid_x0 + -0xeac]()
    //     0x714f84: sub             lr, x0, #0xeac
    //     0x714f88: ldr             lr, [x21, lr, lsl #3]
    //     0x714f8c: blr             lr
    // 0x714f90: add             SP, SP, #0x10
    // 0x714f94: ldur            x1, [fp, #-0x20]
    // 0x714f98: add             x4, x1, #1
    // 0x714f9c: b               #0x714f28
    // 0x714fa0: r0 = Null
    //     0x714fa0: mov             x0, NULL
    // 0x714fa4: LeaveFrame
    //     0x714fa4: mov             SP, fp
    //     0x714fa8: ldp             fp, lr, [SP], #0x10
    // 0x714fac: ret
    //     0x714fac: ret             
    // 0x714fb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714fb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714fb4: b               #0x714e28
    // 0x714fb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714fb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714fbc: b               #0x714f40
    // 0x714fc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x714fc0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ close(/* No info */) {
    // ** addr: 0x714fc4, size: 0xc0
    // 0x714fc4: EnterFrame
    //     0x714fc4: stp             fp, lr, [SP, #-0x10]!
    //     0x714fc8: mov             fp, SP
    // 0x714fcc: AllocStack(0x8)
    //     0x714fcc: sub             SP, SP, #8
    // 0x714fd0: CheckStackOverflow
    //     0x714fd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714fd4: cmp             SP, x16
    //     0x714fd8: b.ls            #0x71507c
    // 0x714fdc: ldr             x2, [fp, #0x18]
    // 0x714fe0: LoadField: r3 = r2->field_7
    //     0x714fe0: ldur            w3, [x2, #7]
    // 0x714fe4: DecompressPointer r3
    //     0x714fe4: add             x3, x3, HEAP, lsl #32
    // 0x714fe8: ldr             x4, [fp, #0x10]
    // 0x714fec: stur            x3, [fp, #-8]
    // 0x714ff0: r0 = BoxInt64Instr(r4)
    //     0x714ff0: sbfiz           x0, x4, #1, #0x1f
    //     0x714ff4: cmp             x4, x0, asr #1
    //     0x714ff8: b.eq            #0x715004
    //     0x714ffc: bl              #0xd69bb8
    //     0x715000: stur            x4, [x0, #7]
    // 0x715004: stp             x0, x3, [SP, #-0x10]!
    // 0x715008: r0 = _getValueOrData()
    //     0x715008: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x71500c: add             SP, SP, #0x10
    // 0x715010: mov             x1, x0
    // 0x715014: ldur            x0, [fp, #-8]
    // 0x715018: LoadField: r2 = r0->field_f
    //     0x715018: ldur            w2, [x0, #0xf]
    // 0x71501c: DecompressPointer r2
    //     0x71501c: add             x2, x2, HEAP, lsl #32
    // 0x715020: cmp             w2, w1
    // 0x715024: b.ne            #0x715030
    // 0x715028: r0 = Null
    //     0x715028: mov             x0, NULL
    // 0x71502c: b               #0x715034
    // 0x715030: mov             x0, x1
    // 0x715034: cmp             w0, NULL
    // 0x715038: b.ne            #0x71504c
    // 0x71503c: r0 = Null
    //     0x71503c: mov             x0, NULL
    // 0x715040: LeaveFrame
    //     0x715040: mov             SP, fp
    //     0x715044: ldp             fp, lr, [SP], #0x10
    // 0x715048: ret
    //     0x715048: ret             
    // 0x71504c: ldr             x1, [fp, #0x10]
    // 0x715050: r2 = false
    //     0x715050: add             x2, NULL, #0x30  ; false
    // 0x715054: StoreField: r0->field_b = r2
    //     0x715054: stur            w2, [x0, #0xb]
    // 0x715058: ldr             x16, [fp, #0x18]
    // 0x71505c: stp             x1, x16, [SP, #-0x10]!
    // 0x715060: SaveReg r0
    //     0x715060: str             x0, [SP, #-8]!
    // 0x715064: r0 = _tryToResolveArena()
    //     0x715064: bl              #0x715084  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_tryToResolveArena
    // 0x715068: add             SP, SP, #0x18
    // 0x71506c: r0 = Null
    //     0x71506c: mov             x0, NULL
    // 0x715070: LeaveFrame
    //     0x715070: mov             SP, fp
    //     0x715074: ldp             fp, lr, [SP], #0x10
    // 0x715078: ret
    //     0x715078: ret             
    // 0x71507c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71507c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715080: b               #0x714fdc
  }
  _ _tryToResolveArena(/* No info */) {
    // ** addr: 0x715084, size: 0xd4
    // 0x715084: EnterFrame
    //     0x715084: stp             fp, lr, [SP, #-0x10]!
    //     0x715088: mov             fp, SP
    // 0x71508c: CheckStackOverflow
    //     0x71508c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715090: cmp             SP, x16
    //     0x715094: b.ls            #0x715150
    // 0x715098: r1 = 3
    //     0x715098: mov             x1, #3
    // 0x71509c: r0 = AllocateContext()
    //     0x71509c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7150a0: mov             x3, x0
    // 0x7150a4: ldr             x2, [fp, #0x20]
    // 0x7150a8: StoreField: r3->field_f = r2
    //     0x7150a8: stur            w2, [x3, #0xf]
    // 0x7150ac: ldr             x4, [fp, #0x18]
    // 0x7150b0: r0 = BoxInt64Instr(r4)
    //     0x7150b0: sbfiz           x0, x4, #1, #0x1f
    //     0x7150b4: cmp             x4, x0, asr #1
    //     0x7150b8: b.eq            #0x7150c4
    //     0x7150bc: bl              #0xd69bb8
    //     0x7150c0: stur            x4, [x0, #7]
    // 0x7150c4: StoreField: r3->field_13 = r0
    //     0x7150c4: stur            w0, [x3, #0x13]
    // 0x7150c8: ldr             x1, [fp, #0x10]
    // 0x7150cc: StoreField: r3->field_17 = r1
    //     0x7150cc: stur            w1, [x3, #0x17]
    // 0x7150d0: LoadField: r5 = r1->field_7
    //     0x7150d0: ldur            w5, [x1, #7]
    // 0x7150d4: DecompressPointer r5
    //     0x7150d4: add             x5, x5, HEAP, lsl #32
    // 0x7150d8: LoadField: r6 = r5->field_b
    //     0x7150d8: ldur            w6, [x5, #0xb]
    // 0x7150dc: DecompressPointer r6
    //     0x7150dc: add             x6, x6, HEAP, lsl #32
    // 0x7150e0: cmp             w6, #2
    // 0x7150e4: b.ne            #0x715104
    // 0x7150e8: mov             x2, x3
    // 0x7150ec: r1 = Function '<anonymous closure>':.
    //     0x7150ec: ldr             x1, [PP, #0x7588]  ; [pp+0x7588] AnonymousClosure: (0x715360), in [package:flutter/src/gestures/arena.dart] GestureArenaManager::_tryToResolveArena (0x715084)
    // 0x7150f0: r0 = AllocateClosure()
    //     0x7150f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7150f4: SaveReg r0
    //     0x7150f4: str             x0, [SP, #-8]!
    // 0x7150f8: r0 = scheduleMicrotask()
    //     0x7150f8: bl              #0x4b5c38  ; [dart:async] ::scheduleMicrotask
    // 0x7150fc: add             SP, SP, #8
    // 0x715100: b               #0x715140
    // 0x715104: cbnz            w6, #0x715120
    // 0x715108: LoadField: r1 = r2->field_7
    //     0x715108: ldur            w1, [x2, #7]
    // 0x71510c: DecompressPointer r1
    //     0x71510c: add             x1, x1, HEAP, lsl #32
    // 0x715110: stp             x0, x1, [SP, #-0x10]!
    // 0x715114: r0 = remove()
    //     0x715114: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x715118: add             SP, SP, #0x10
    // 0x71511c: b               #0x715140
    // 0x715120: LoadField: r0 = r1->field_17
    //     0x715120: ldur            w0, [x1, #0x17]
    // 0x715124: DecompressPointer r0
    //     0x715124: add             x0, x0, HEAP, lsl #32
    // 0x715128: cmp             w0, NULL
    // 0x71512c: b.eq            #0x715140
    // 0x715130: stp             x4, x2, [SP, #-0x10]!
    // 0x715134: stp             x0, x1, [SP, #-0x10]!
    // 0x715138: r0 = _resolveInFavorOf()
    //     0x715138: bl              #0x715158  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_resolveInFavorOf
    // 0x71513c: add             SP, SP, #0x20
    // 0x715140: r0 = Null
    //     0x715140: mov             x0, NULL
    // 0x715144: LeaveFrame
    //     0x715144: mov             SP, fp
    //     0x715148: ldp             fp, lr, [SP], #0x10
    // 0x71514c: ret
    //     0x71514c: ret             
    // 0x715150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x715150: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715154: b               #0x715098
  }
  _ _resolveInFavorOf(/* No info */) {
    // ** addr: 0x715158, size: 0x208
    // 0x715158: EnterFrame
    //     0x715158: stp             fp, lr, [SP, #-0x10]!
    //     0x71515c: mov             fp, SP
    // 0x715160: AllocStack(0x30)
    //     0x715160: sub             SP, SP, #0x30
    // 0x715164: CheckStackOverflow
    //     0x715164: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715168: cmp             SP, x16
    //     0x71516c: b.ls            #0x715350
    // 0x715170: ldr             x0, [fp, #0x28]
    // 0x715174: LoadField: r2 = r0->field_7
    //     0x715174: ldur            w2, [x0, #7]
    // 0x715178: DecompressPointer r2
    //     0x715178: add             x2, x2, HEAP, lsl #32
    // 0x71517c: ldr             x3, [fp, #0x20]
    // 0x715180: r0 = BoxInt64Instr(r3)
    //     0x715180: sbfiz           x0, x3, #1, #0x1f
    //     0x715184: cmp             x3, x0, asr #1
    //     0x715188: b.eq            #0x715194
    //     0x71518c: bl              #0xd69bb8
    //     0x715190: stur            x3, [x0, #7]
    // 0x715194: stp             x0, x2, [SP, #-0x10]!
    // 0x715198: r0 = remove()
    //     0x715198: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x71519c: add             SP, SP, #0x10
    // 0x7151a0: ldr             x0, [fp, #0x18]
    // 0x7151a4: LoadField: r1 = r0->field_7
    //     0x7151a4: ldur            w1, [x0, #7]
    // 0x7151a8: DecompressPointer r1
    //     0x7151a8: add             x1, x1, HEAP, lsl #32
    // 0x7151ac: stur            x1, [fp, #-0x20]
    // 0x7151b0: LoadField: r2 = r1->field_7
    //     0x7151b0: ldur            w2, [x1, #7]
    // 0x7151b4: DecompressPointer r2
    //     0x7151b4: add             x2, x2, HEAP, lsl #32
    // 0x7151b8: stur            x2, [fp, #-0x18]
    // 0x7151bc: LoadField: r0 = r1->field_b
    //     0x7151bc: ldur            w0, [x1, #0xb]
    // 0x7151c0: DecompressPointer r0
    //     0x7151c0: add             x0, x0, HEAP, lsl #32
    // 0x7151c4: r3 = LoadInt32Instr(r0)
    //     0x7151c4: sbfx            x3, x0, #1, #0x1f
    // 0x7151c8: stur            x3, [fp, #-0x10]
    // 0x7151cc: r6 = 0
    //     0x7151cc: mov             x6, #0
    // 0x7151d0: ldr             x4, [fp, #0x20]
    // 0x7151d4: ldr             x5, [fp, #0x10]
    // 0x7151d8: stur            x6, [fp, #-8]
    // 0x7151dc: CheckStackOverflow
    //     0x7151dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7151e0: cmp             SP, x16
    //     0x7151e4: b.ls            #0x715358
    // 0x7151e8: r0 = LoadClassIdInstr(r1)
    //     0x7151e8: ldur            x0, [x1, #-1]
    //     0x7151ec: ubfx            x0, x0, #0xc, #0x14
    // 0x7151f0: SaveReg r1
    //     0x7151f0: str             x1, [SP, #-8]!
    // 0x7151f4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7151f4: mov             x17, #0xb8ea
    //     0x7151f8: add             lr, x0, x17
    //     0x7151fc: ldr             lr, [x21, lr, lsl #3]
    //     0x715200: blr             lr
    // 0x715204: add             SP, SP, #8
    // 0x715208: r1 = LoadInt32Instr(r0)
    //     0x715208: sbfx            x1, x0, #1, #0x1f
    //     0x71520c: tbz             w0, #0, #0x715214
    //     0x715210: ldur            x1, [x0, #7]
    // 0x715214: ldur            x2, [fp, #-0x10]
    // 0x715218: cmp             x2, x1
    // 0x71521c: b.ne            #0x715338
    // 0x715220: ldur            x3, [fp, #-0x20]
    // 0x715224: ldur            x4, [fp, #-8]
    // 0x715228: cmp             x4, x1
    // 0x71522c: b.lt            #0x715268
    // 0x715230: ldr             x5, [fp, #0x20]
    // 0x715234: ldr             x6, [fp, #0x10]
    // 0x715238: r0 = LoadClassIdInstr(r6)
    //     0x715238: ldur            x0, [x6, #-1]
    //     0x71523c: ubfx            x0, x0, #0xc, #0x14
    // 0x715240: stp             x5, x6, [SP, #-0x10]!
    // 0x715244: r0 = GDT[cid_x0 + 0x18e8]()
    //     0x715244: mov             x17, #0x18e8
    //     0x715248: add             lr, x0, x17
    //     0x71524c: ldr             lr, [x21, lr, lsl #3]
    //     0x715250: blr             lr
    // 0x715254: add             SP, SP, #0x10
    // 0x715258: r0 = Null
    //     0x715258: mov             x0, NULL
    // 0x71525c: LeaveFrame
    //     0x71525c: mov             SP, fp
    //     0x715260: ldp             fp, lr, [SP], #0x10
    // 0x715264: ret
    //     0x715264: ret             
    // 0x715268: ldr             x5, [fp, #0x20]
    // 0x71526c: ldr             x6, [fp, #0x10]
    // 0x715270: r0 = BoxInt64Instr(r4)
    //     0x715270: sbfiz           x0, x4, #1, #0x1f
    //     0x715274: cmp             x4, x0, asr #1
    //     0x715278: b.eq            #0x715284
    //     0x71527c: bl              #0xd69bb8
    //     0x715280: stur            x4, [x0, #7]
    // 0x715284: r1 = LoadClassIdInstr(r3)
    //     0x715284: ldur            x1, [x3, #-1]
    //     0x715288: ubfx            x1, x1, #0xc, #0x14
    // 0x71528c: stp             x0, x3, [SP, #-0x10]!
    // 0x715290: mov             x0, x1
    // 0x715294: r0 = GDT[cid_x0 + 0xd175]()
    //     0x715294: mov             x17, #0xd175
    //     0x715298: add             lr, x0, x17
    //     0x71529c: ldr             lr, [x21, lr, lsl #3]
    //     0x7152a0: blr             lr
    // 0x7152a4: add             SP, SP, #0x10
    // 0x7152a8: mov             x3, x0
    // 0x7152ac: ldur            x0, [fp, #-8]
    // 0x7152b0: stur            x3, [fp, #-0x30]
    // 0x7152b4: add             x6, x0, #1
    // 0x7152b8: stur            x6, [fp, #-0x28]
    // 0x7152bc: cmp             w3, NULL
    // 0x7152c0: b.ne            #0x7152f0
    // 0x7152c4: mov             x0, x3
    // 0x7152c8: ldur            x2, [fp, #-0x18]
    // 0x7152cc: r1 = Null
    //     0x7152cc: mov             x1, NULL
    // 0x7152d0: cmp             w2, NULL
    // 0x7152d4: b.eq            #0x7152f0
    // 0x7152d8: LoadField: r4 = r2->field_17
    //     0x7152d8: ldur            w4, [x2, #0x17]
    // 0x7152dc: DecompressPointer r4
    //     0x7152dc: add             x4, x4, HEAP, lsl #32
    // 0x7152e0: r8 = X0
    //     0x7152e0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x7152e4: LoadField: r9 = r4->field_7
    //     0x7152e4: ldur            x9, [x4, #7]
    // 0x7152e8: r3 = Null
    //     0x7152e8: ldr             x3, [PP, #0x7590]  ; [pp+0x7590] Null
    // 0x7152ec: blr             x9
    // 0x7152f0: ldr             x1, [fp, #0x10]
    // 0x7152f4: ldur            x0, [fp, #-0x30]
    // 0x7152f8: cmp             w0, w1
    // 0x7152fc: b.eq            #0x715324
    // 0x715300: ldr             x2, [fp, #0x20]
    // 0x715304: r3 = LoadClassIdInstr(r0)
    //     0x715304: ldur            x3, [x0, #-1]
    //     0x715308: ubfx            x3, x3, #0xc, #0x14
    // 0x71530c: stp             x2, x0, [SP, #-0x10]!
    // 0x715310: mov             x0, x3
    // 0x715314: r0 = GDT[cid_x0 + -0xeac]()
    //     0x715314: sub             lr, x0, #0xeac
    //     0x715318: ldr             lr, [x21, lr, lsl #3]
    //     0x71531c: blr             lr
    // 0x715320: add             SP, SP, #0x10
    // 0x715324: ldur            x6, [fp, #-0x28]
    // 0x715328: ldur            x1, [fp, #-0x20]
    // 0x71532c: ldur            x2, [fp, #-0x18]
    // 0x715330: ldur            x3, [fp, #-0x10]
    // 0x715334: b               #0x7151d0
    // 0x715338: ldur            x0, [fp, #-0x20]
    // 0x71533c: r0 = ConcurrentModificationError()
    //     0x71533c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x715340: ldur            x3, [fp, #-0x20]
    // 0x715344: StoreField: r0->field_b = r3
    //     0x715344: stur            w3, [x0, #0xb]
    // 0x715348: r0 = Throw()
    //     0x715348: bl              #0xd67e38  ; ThrowStub
    // 0x71534c: brk             #0
    // 0x715350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x715350: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715354: b               #0x715170
    // 0x715358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x715358: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71535c: b               #0x7151e8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x715360, size: 0x68
    // 0x715360: EnterFrame
    //     0x715360: stp             fp, lr, [SP, #-0x10]!
    //     0x715364: mov             fp, SP
    // 0x715368: ldr             x0, [fp, #0x10]
    // 0x71536c: LoadField: r1 = r0->field_17
    //     0x71536c: ldur            w1, [x0, #0x17]
    // 0x715370: DecompressPointer r1
    //     0x715370: add             x1, x1, HEAP, lsl #32
    // 0x715374: CheckStackOverflow
    //     0x715374: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715378: cmp             SP, x16
    //     0x71537c: b.ls            #0x7153c0
    // 0x715380: LoadField: r0 = r1->field_f
    //     0x715380: ldur            w0, [x1, #0xf]
    // 0x715384: DecompressPointer r0
    //     0x715384: add             x0, x0, HEAP, lsl #32
    // 0x715388: LoadField: r2 = r1->field_13
    //     0x715388: ldur            w2, [x1, #0x13]
    // 0x71538c: DecompressPointer r2
    //     0x71538c: add             x2, x2, HEAP, lsl #32
    // 0x715390: LoadField: r3 = r1->field_17
    //     0x715390: ldur            w3, [x1, #0x17]
    // 0x715394: DecompressPointer r3
    //     0x715394: add             x3, x3, HEAP, lsl #32
    // 0x715398: r1 = LoadInt32Instr(r2)
    //     0x715398: sbfx            x1, x2, #1, #0x1f
    //     0x71539c: tbz             w2, #0, #0x7153a4
    //     0x7153a0: ldur            x1, [x2, #7]
    // 0x7153a4: stp             x1, x0, [SP, #-0x10]!
    // 0x7153a8: SaveReg r3
    //     0x7153a8: str             x3, [SP, #-8]!
    // 0x7153ac: r0 = _resolveByDefault()
    //     0x7153ac: bl              #0x7153c8  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_resolveByDefault
    // 0x7153b0: add             SP, SP, #0x18
    // 0x7153b4: LeaveFrame
    //     0x7153b4: mov             SP, fp
    //     0x7153b8: ldp             fp, lr, [SP], #0x10
    // 0x7153bc: ret
    //     0x7153bc: ret             
    // 0x7153c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7153c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7153c4: b               #0x715380
  }
  _ _resolveByDefault(/* No info */) {
    // ** addr: 0x7153c8, size: 0xdc
    // 0x7153c8: EnterFrame
    //     0x7153c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7153cc: mov             fp, SP
    // 0x7153d0: AllocStack(0x10)
    //     0x7153d0: sub             SP, SP, #0x10
    // 0x7153d4: CheckStackOverflow
    //     0x7153d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7153d8: cmp             SP, x16
    //     0x7153dc: b.ls            #0x71549c
    // 0x7153e0: ldr             x0, [fp, #0x20]
    // 0x7153e4: LoadField: r2 = r0->field_7
    //     0x7153e4: ldur            w2, [x0, #7]
    // 0x7153e8: DecompressPointer r2
    //     0x7153e8: add             x2, x2, HEAP, lsl #32
    // 0x7153ec: ldr             x3, [fp, #0x18]
    // 0x7153f0: stur            x2, [fp, #-0x10]
    // 0x7153f4: r0 = BoxInt64Instr(r3)
    //     0x7153f4: sbfiz           x0, x3, #1, #0x1f
    //     0x7153f8: cmp             x3, x0, asr #1
    //     0x7153fc: b.eq            #0x715408
    //     0x715400: bl              #0xd69bb8
    //     0x715404: stur            x3, [x0, #7]
    // 0x715408: stur            x0, [fp, #-8]
    // 0x71540c: stp             x0, x2, [SP, #-0x10]!
    // 0x715410: r0 = containsKey()
    //     0x715410: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x715414: add             SP, SP, #0x10
    // 0x715418: tbz             w0, #4, #0x71542c
    // 0x71541c: r0 = Null
    //     0x71541c: mov             x0, NULL
    // 0x715420: LeaveFrame
    //     0x715420: mov             SP, fp
    //     0x715424: ldp             fp, lr, [SP], #0x10
    // 0x715428: ret
    //     0x715428: ret             
    // 0x71542c: ldr             x0, [fp, #0x18]
    // 0x715430: ldr             x1, [fp, #0x10]
    // 0x715434: ldur            x16, [fp, #-0x10]
    // 0x715438: ldur            lr, [fp, #-8]
    // 0x71543c: stp             lr, x16, [SP, #-0x10]!
    // 0x715440: r0 = remove()
    //     0x715440: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x715444: add             SP, SP, #0x10
    // 0x715448: ldr             x0, [fp, #0x10]
    // 0x71544c: LoadField: r1 = r0->field_7
    //     0x71544c: ldur            w1, [x0, #7]
    // 0x715450: DecompressPointer r1
    //     0x715450: add             x1, x1, HEAP, lsl #32
    // 0x715454: SaveReg r1
    //     0x715454: str             x1, [SP, #-8]!
    // 0x715458: r0 = first()
    //     0x715458: bl              #0x7192e8  ; [dart:core] _GrowableList::first
    // 0x71545c: add             SP, SP, #8
    // 0x715460: r1 = LoadClassIdInstr(r0)
    //     0x715460: ldur            x1, [x0, #-1]
    //     0x715464: ubfx            x1, x1, #0xc, #0x14
    // 0x715468: SaveReg r0
    //     0x715468: str             x0, [SP, #-8]!
    // 0x71546c: ldr             x0, [fp, #0x18]
    // 0x715470: SaveReg r0
    //     0x715470: str             x0, [SP, #-8]!
    // 0x715474: mov             x0, x1
    // 0x715478: r0 = GDT[cid_x0 + 0x18e8]()
    //     0x715478: mov             x17, #0x18e8
    //     0x71547c: add             lr, x0, x17
    //     0x715480: ldr             lr, [x21, lr, lsl #3]
    //     0x715484: blr             lr
    // 0x715488: add             SP, SP, #0x10
    // 0x71548c: r0 = Null
    //     0x71548c: mov             x0, NULL
    // 0x715490: LeaveFrame
    //     0x715490: mov             SP, fp
    //     0x715494: ldp             fp, lr, [SP], #0x10
    // 0x715498: ret
    //     0x715498: ret             
    // 0x71549c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71549c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7154a0: b               #0x7153e0
  }
  _ hold(/* No info */) {
    // ** addr: 0x7850f4, size: 0xa4
    // 0x7850f4: EnterFrame
    //     0x7850f4: stp             fp, lr, [SP, #-0x10]!
    //     0x7850f8: mov             fp, SP
    // 0x7850fc: AllocStack(0x8)
    //     0x7850fc: sub             SP, SP, #8
    // 0x785100: CheckStackOverflow
    //     0x785100: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x785104: cmp             SP, x16
    //     0x785108: b.ls            #0x785190
    // 0x78510c: ldr             x0, [fp, #0x18]
    // 0x785110: LoadField: r2 = r0->field_7
    //     0x785110: ldur            w2, [x0, #7]
    // 0x785114: DecompressPointer r2
    //     0x785114: add             x2, x2, HEAP, lsl #32
    // 0x785118: ldr             x3, [fp, #0x10]
    // 0x78511c: stur            x2, [fp, #-8]
    // 0x785120: r0 = BoxInt64Instr(r3)
    //     0x785120: sbfiz           x0, x3, #1, #0x1f
    //     0x785124: cmp             x3, x0, asr #1
    //     0x785128: b.eq            #0x785134
    //     0x78512c: bl              #0xd69bb8
    //     0x785130: stur            x3, [x0, #7]
    // 0x785134: stp             x0, x2, [SP, #-0x10]!
    // 0x785138: r0 = _getValueOrData()
    //     0x785138: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78513c: add             SP, SP, #0x10
    // 0x785140: ldur            x1, [fp, #-8]
    // 0x785144: LoadField: r2 = r1->field_f
    //     0x785144: ldur            w2, [x1, #0xf]
    // 0x785148: DecompressPointer r2
    //     0x785148: add             x2, x2, HEAP, lsl #32
    // 0x78514c: cmp             w2, w0
    // 0x785150: b.ne            #0x78515c
    // 0x785154: r1 = Null
    //     0x785154: mov             x1, NULL
    // 0x785158: b               #0x785160
    // 0x78515c: mov             x1, x0
    // 0x785160: cmp             w1, NULL
    // 0x785164: b.ne            #0x785178
    // 0x785168: r0 = Null
    //     0x785168: mov             x0, NULL
    // 0x78516c: LeaveFrame
    //     0x78516c: mov             SP, fp
    //     0x785170: ldp             fp, lr, [SP], #0x10
    // 0x785174: ret
    //     0x785174: ret             
    // 0x785178: r2 = true
    //     0x785178: add             x2, NULL, #0x20  ; true
    // 0x78517c: StoreField: r1->field_f = r2
    //     0x78517c: stur            w2, [x1, #0xf]
    // 0x785180: r0 = Null
    //     0x785180: mov             x0, NULL
    // 0x785184: LeaveFrame
    //     0x785184: mov             SP, fp
    //     0x785188: ldp             fp, lr, [SP], #0x10
    // 0x78518c: ret
    //     0x78518c: ret             
    // 0x785190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x785190: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x785194: b               #0x78510c
  }
  _ release(/* No info */) {
    // ** addr: 0x785324, size: 0xc8
    // 0x785324: EnterFrame
    //     0x785324: stp             fp, lr, [SP, #-0x10]!
    //     0x785328: mov             fp, SP
    // 0x78532c: AllocStack(0x8)
    //     0x78532c: sub             SP, SP, #8
    // 0x785330: CheckStackOverflow
    //     0x785330: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x785334: cmp             SP, x16
    //     0x785338: b.ls            #0x7853e4
    // 0x78533c: ldr             x2, [fp, #0x18]
    // 0x785340: LoadField: r3 = r2->field_7
    //     0x785340: ldur            w3, [x2, #7]
    // 0x785344: DecompressPointer r3
    //     0x785344: add             x3, x3, HEAP, lsl #32
    // 0x785348: ldr             x4, [fp, #0x10]
    // 0x78534c: stur            x3, [fp, #-8]
    // 0x785350: r0 = BoxInt64Instr(r4)
    //     0x785350: sbfiz           x0, x4, #1, #0x1f
    //     0x785354: cmp             x4, x0, asr #1
    //     0x785358: b.eq            #0x785364
    //     0x78535c: bl              #0xd69bb8
    //     0x785360: stur            x4, [x0, #7]
    // 0x785364: stp             x0, x3, [SP, #-0x10]!
    // 0x785368: r0 = _getValueOrData()
    //     0x785368: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x78536c: add             SP, SP, #0x10
    // 0x785370: mov             x1, x0
    // 0x785374: ldur            x0, [fp, #-8]
    // 0x785378: LoadField: r2 = r0->field_f
    //     0x785378: ldur            w2, [x0, #0xf]
    // 0x78537c: DecompressPointer r2
    //     0x78537c: add             x2, x2, HEAP, lsl #32
    // 0x785380: cmp             w2, w1
    // 0x785384: b.ne            #0x785390
    // 0x785388: r0 = Null
    //     0x785388: mov             x0, NULL
    // 0x78538c: b               #0x785394
    // 0x785390: mov             x0, x1
    // 0x785394: cmp             w0, NULL
    // 0x785398: b.ne            #0x7853ac
    // 0x78539c: r0 = Null
    //     0x78539c: mov             x0, NULL
    // 0x7853a0: LeaveFrame
    //     0x7853a0: mov             SP, fp
    //     0x7853a4: ldp             fp, lr, [SP], #0x10
    // 0x7853a8: ret
    //     0x7853a8: ret             
    // 0x7853ac: r1 = false
    //     0x7853ac: add             x1, NULL, #0x30  ; false
    // 0x7853b0: StoreField: r0->field_f = r1
    //     0x7853b0: stur            w1, [x0, #0xf]
    // 0x7853b4: LoadField: r1 = r0->field_13
    //     0x7853b4: ldur            w1, [x0, #0x13]
    // 0x7853b8: DecompressPointer r1
    //     0x7853b8: add             x1, x1, HEAP, lsl #32
    // 0x7853bc: tbnz            w1, #4, #0x7853d4
    // 0x7853c0: ldr             x0, [fp, #0x10]
    // 0x7853c4: ldr             x16, [fp, #0x18]
    // 0x7853c8: stp             x0, x16, [SP, #-0x10]!
    // 0x7853cc: r0 = sweep()
    //     0x7853cc: bl              #0x714e10  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::sweep
    // 0x7853d0: add             SP, SP, #0x10
    // 0x7853d4: r0 = Null
    //     0x7853d4: mov             x0, NULL
    // 0x7853d8: LeaveFrame
    //     0x7853d8: mov             SP, fp
    //     0x7853dc: ldp             fp, lr, [SP], #0x10
    // 0x7853e0: ret
    //     0x7853e0: ret             
    // 0x7853e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7853e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7853e8: b               #0x78533c
  }
  _ _resolve(/* No info */) {
    // ** addr: 0xcf74a8, size: 0x188
    // 0xcf74a8: EnterFrame
    //     0xcf74a8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf74ac: mov             fp, SP
    // 0xcf74b0: AllocStack(0x8)
    //     0xcf74b0: sub             SP, SP, #8
    // 0xcf74b4: CheckStackOverflow
    //     0xcf74b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf74b8: cmp             SP, x16
    //     0xcf74bc: b.ls            #0xcf7628
    // 0xcf74c0: ldr             x2, [fp, #0x28]
    // 0xcf74c4: LoadField: r3 = r2->field_7
    //     0xcf74c4: ldur            w3, [x2, #7]
    // 0xcf74c8: DecompressPointer r3
    //     0xcf74c8: add             x3, x3, HEAP, lsl #32
    // 0xcf74cc: ldr             x4, [fp, #0x20]
    // 0xcf74d0: stur            x3, [fp, #-8]
    // 0xcf74d4: r0 = BoxInt64Instr(r4)
    //     0xcf74d4: sbfiz           x0, x4, #1, #0x1f
    //     0xcf74d8: cmp             x4, x0, asr #1
    //     0xcf74dc: b.eq            #0xcf74e8
    //     0xcf74e0: bl              #0xd69bb8
    //     0xcf74e4: stur            x4, [x0, #7]
    // 0xcf74e8: stp             x0, x3, [SP, #-0x10]!
    // 0xcf74ec: r0 = _getValueOrData()
    //     0xcf74ec: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcf74f0: add             SP, SP, #0x10
    // 0xcf74f4: mov             x1, x0
    // 0xcf74f8: ldur            x0, [fp, #-8]
    // 0xcf74fc: LoadField: r2 = r0->field_f
    //     0xcf74fc: ldur            w2, [x0, #0xf]
    // 0xcf7500: DecompressPointer r2
    //     0xcf7500: add             x2, x2, HEAP, lsl #32
    // 0xcf7504: cmp             w2, w1
    // 0xcf7508: b.ne            #0xcf7514
    // 0xcf750c: r0 = Null
    //     0xcf750c: mov             x0, NULL
    // 0xcf7510: b               #0xcf7518
    // 0xcf7514: mov             x0, x1
    // 0xcf7518: stur            x0, [fp, #-8]
    // 0xcf751c: cmp             w0, NULL
    // 0xcf7520: b.ne            #0xcf7534
    // 0xcf7524: r0 = Null
    //     0xcf7524: mov             x0, NULL
    // 0xcf7528: LeaveFrame
    //     0xcf7528: mov             SP, fp
    //     0xcf752c: ldp             fp, lr, [SP], #0x10
    // 0xcf7530: ret
    //     0xcf7530: ret             
    // 0xcf7534: ldr             x1, [fp, #0x10]
    // 0xcf7538: r16 = Instance_GestureDisposition
    //     0xcf7538: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xcf753c: ldr             x16, [x16, #0xeb8]
    // 0xcf7540: cmp             w1, w16
    // 0xcf7544: b.ne            #0xcf75bc
    // 0xcf7548: ldr             x1, [fp, #0x20]
    // 0xcf754c: ldr             x2, [fp, #0x18]
    // 0xcf7550: LoadField: r3 = r0->field_7
    //     0xcf7550: ldur            w3, [x0, #7]
    // 0xcf7554: DecompressPointer r3
    //     0xcf7554: add             x3, x3, HEAP, lsl #32
    // 0xcf7558: stp             x2, x3, [SP, #-0x10]!
    // 0xcf755c: r0 = remove()
    //     0xcf755c: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0xcf7560: add             SP, SP, #0x10
    // 0xcf7564: ldr             x0, [fp, #0x18]
    // 0xcf7568: r1 = LoadClassIdInstr(r0)
    //     0xcf7568: ldur            x1, [x0, #-1]
    //     0xcf756c: ubfx            x1, x1, #0xc, #0x14
    // 0xcf7570: SaveReg r0
    //     0xcf7570: str             x0, [SP, #-8]!
    // 0xcf7574: ldr             x2, [fp, #0x20]
    // 0xcf7578: SaveReg r2
    //     0xcf7578: str             x2, [SP, #-8]!
    // 0xcf757c: mov             x0, x1
    // 0xcf7580: r0 = GDT[cid_x0 + -0xeac]()
    //     0xcf7580: sub             lr, x0, #0xeac
    //     0xcf7584: ldr             lr, [x21, lr, lsl #3]
    //     0xcf7588: blr             lr
    // 0xcf758c: add             SP, SP, #0x10
    // 0xcf7590: ldur            x1, [fp, #-8]
    // 0xcf7594: LoadField: r0 = r1->field_b
    //     0xcf7594: ldur            w0, [x1, #0xb]
    // 0xcf7598: DecompressPointer r0
    //     0xcf7598: add             x0, x0, HEAP, lsl #32
    // 0xcf759c: tbz             w0, #4, #0xcf7618
    // 0xcf75a0: ldr             x2, [fp, #0x20]
    // 0xcf75a4: ldr             x16, [fp, #0x28]
    // 0xcf75a8: stp             x2, x16, [SP, #-0x10]!
    // 0xcf75ac: SaveReg r1
    //     0xcf75ac: str             x1, [SP, #-8]!
    // 0xcf75b0: r0 = _tryToResolveArena()
    //     0xcf75b0: bl              #0x715084  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_tryToResolveArena
    // 0xcf75b4: add             SP, SP, #0x18
    // 0xcf75b8: b               #0xcf7618
    // 0xcf75bc: ldr             x2, [fp, #0x20]
    // 0xcf75c0: mov             x1, x0
    // 0xcf75c4: ldr             x0, [fp, #0x18]
    // 0xcf75c8: LoadField: r3 = r1->field_b
    //     0xcf75c8: ldur            w3, [x1, #0xb]
    // 0xcf75cc: DecompressPointer r3
    //     0xcf75cc: add             x3, x3, HEAP, lsl #32
    // 0xcf75d0: tbnz            w3, #4, #0xcf7604
    // 0xcf75d4: LoadField: r2 = r1->field_17
    //     0xcf75d4: ldur            w2, [x1, #0x17]
    // 0xcf75d8: DecompressPointer r2
    //     0xcf75d8: add             x2, x2, HEAP, lsl #32
    // 0xcf75dc: cmp             w2, NULL
    // 0xcf75e0: b.ne            #0xcf7618
    // 0xcf75e4: StoreField: r1->field_17 = r0
    //     0xcf75e4: stur            w0, [x1, #0x17]
    //     0xcf75e8: ldurb           w16, [x1, #-1]
    //     0xcf75ec: ldurb           w17, [x0, #-1]
    //     0xcf75f0: and             x16, x17, x16, lsr #2
    //     0xcf75f4: tst             x16, HEAP, lsr #32
    //     0xcf75f8: b.eq            #0xcf7600
    //     0xcf75fc: bl              #0xd6826c
    // 0xcf7600: b               #0xcf7618
    // 0xcf7604: ldr             x16, [fp, #0x28]
    // 0xcf7608: stp             x2, x16, [SP, #-0x10]!
    // 0xcf760c: stp             x0, x1, [SP, #-0x10]!
    // 0xcf7610: r0 = _resolveInFavorOf()
    //     0xcf7610: bl              #0x715158  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_resolveInFavorOf
    // 0xcf7614: add             SP, SP, #0x20
    // 0xcf7618: r0 = Null
    //     0xcf7618: mov             x0, NULL
    // 0xcf761c: LeaveFrame
    //     0xcf761c: mov             SP, fp
    //     0xcf7620: ldp             fp, lr, [SP], #0x10
    // 0xcf7624: ret
    //     0xcf7624: ret             
    // 0xcf7628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf762c: b               #0xcf74c0
  }
}

// class id: 2338, size: 0x1c, field offset: 0x8
class _GestureArena extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad910c, size: 0x16c
    // 0xad910c: EnterFrame
    //     0xad910c: stp             fp, lr, [SP, #-0x10]!
    //     0xad9110: mov             fp, SP
    // 0xad9114: AllocStack(0x18)
    //     0xad9114: sub             SP, SP, #0x18
    // 0xad9118: CheckStackOverflow
    //     0xad9118: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad911c: cmp             SP, x16
    //     0xad9120: b.ls            #0xad9270
    // 0xad9124: r1 = 1
    //     0xad9124: mov             x1, #1
    // 0xad9128: r0 = AllocateContext()
    //     0xad9128: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad912c: mov             x1, x0
    // 0xad9130: ldr             x0, [fp, #0x10]
    // 0xad9134: stur            x1, [fp, #-8]
    // 0xad9138: StoreField: r1->field_f = r0
    //     0xad9138: stur            w0, [x1, #0xf]
    // 0xad913c: r0 = StringBuffer()
    //     0xad913c: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xad9140: stur            x0, [fp, #-0x10]
    // 0xad9144: SaveReg r0
    //     0xad9144: str             x0, [SP, #-8]!
    // 0xad9148: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad9148: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad914c: r0 = StringBuffer()
    //     0xad914c: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0xad9150: add             SP, SP, #8
    // 0xad9154: ldr             x0, [fp, #0x10]
    // 0xad9158: LoadField: r3 = r0->field_7
    //     0xad9158: ldur            w3, [x0, #7]
    // 0xad915c: DecompressPointer r3
    //     0xad915c: add             x3, x3, HEAP, lsl #32
    // 0xad9160: stur            x3, [fp, #-0x18]
    // 0xad9164: LoadField: r1 = r3->field_b
    //     0xad9164: ldur            w1, [x3, #0xb]
    // 0xad9168: DecompressPointer r1
    //     0xad9168: add             x1, x1, HEAP, lsl #32
    // 0xad916c: cbnz            w1, #0xad918c
    // 0xad9170: ldur            x16, [fp, #-0x10]
    // 0xad9174: r30 = "<empty>"
    //     0xad9174: add             lr, PP, #0x2e, lsl #12  ; [pp+0x2e948] "<empty>"
    //     0xad9178: ldr             lr, [lr, #0x948]
    // 0xad917c: stp             lr, x16, [SP, #-0x10]!
    // 0xad9180: r0 = write()
    //     0xad9180: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xad9184: add             SP, SP, #0x10
    // 0xad9188: b               #0xad91dc
    // 0xad918c: ldur            x2, [fp, #-8]
    // 0xad9190: r1 = Function '<anonymous closure>':.
    //     0xad9190: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e950] AnonymousClosure: (0xad9278), in [package:flutter/src/gestures/arena.dart] _GestureArena::toString (0xad910c)
    //     0xad9194: ldr             x1, [x1, #0x950]
    // 0xad9198: r0 = AllocateClosure()
    //     0xad9198: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad919c: r16 = <String>
    //     0xad919c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xad91a0: ldur            lr, [fp, #-0x18]
    // 0xad91a4: stp             lr, x16, [SP, #-0x10]!
    // 0xad91a8: SaveReg r0
    //     0xad91a8: str             x0, [SP, #-8]!
    // 0xad91ac: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xad91ac: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xad91b0: r0 = map()
    //     0xad91b0: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xad91b4: add             SP, SP, #0x18
    // 0xad91b8: r16 = ", "
    //     0xad91b8: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad91bc: stp             x16, x0, [SP, #-0x10]!
    // 0xad91c0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad91c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad91c4: r0 = join()
    //     0xad91c4: bl              #0x6a9240  ; [dart:_internal] ListIterable::join
    // 0xad91c8: add             SP, SP, #0x10
    // 0xad91cc: ldur            x16, [fp, #-0x10]
    // 0xad91d0: stp             x0, x16, [SP, #-0x10]!
    // 0xad91d4: r0 = write()
    //     0xad91d4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xad91d8: add             SP, SP, #0x10
    // 0xad91dc: ldr             x0, [fp, #0x10]
    // 0xad91e0: LoadField: r1 = r0->field_b
    //     0xad91e0: ldur            w1, [x0, #0xb]
    // 0xad91e4: DecompressPointer r1
    //     0xad91e4: add             x1, x1, HEAP, lsl #32
    // 0xad91e8: tbnz            w1, #4, #0xad9204
    // 0xad91ec: ldur            x16, [fp, #-0x10]
    // 0xad91f0: r30 = " [open]"
    //     0xad91f0: add             lr, PP, #0x2e, lsl #12  ; [pp+0x2e958] " [open]"
    //     0xad91f4: ldr             lr, [lr, #0x958]
    // 0xad91f8: stp             lr, x16, [SP, #-0x10]!
    // 0xad91fc: r0 = write()
    //     0xad91fc: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xad9200: add             SP, SP, #0x10
    // 0xad9204: ldr             x0, [fp, #0x10]
    // 0xad9208: LoadField: r1 = r0->field_f
    //     0xad9208: ldur            w1, [x0, #0xf]
    // 0xad920c: DecompressPointer r1
    //     0xad920c: add             x1, x1, HEAP, lsl #32
    // 0xad9210: tbnz            w1, #4, #0xad922c
    // 0xad9214: ldur            x16, [fp, #-0x10]
    // 0xad9218: r30 = " [held]"
    //     0xad9218: add             lr, PP, #0x2e, lsl #12  ; [pp+0x2e960] " [held]"
    //     0xad921c: ldr             lr, [lr, #0x960]
    // 0xad9220: stp             lr, x16, [SP, #-0x10]!
    // 0xad9224: r0 = write()
    //     0xad9224: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xad9228: add             SP, SP, #0x10
    // 0xad922c: ldr             x0, [fp, #0x10]
    // 0xad9230: LoadField: r1 = r0->field_13
    //     0xad9230: ldur            w1, [x0, #0x13]
    // 0xad9234: DecompressPointer r1
    //     0xad9234: add             x1, x1, HEAP, lsl #32
    // 0xad9238: tbnz            w1, #4, #0xad9254
    // 0xad923c: ldur            x16, [fp, #-0x10]
    // 0xad9240: r30 = " [hasPendingSweep]"
    //     0xad9240: add             lr, PP, #0x2e, lsl #12  ; [pp+0x2e968] " [hasPendingSweep]"
    //     0xad9244: ldr             lr, [lr, #0x968]
    // 0xad9248: stp             lr, x16, [SP, #-0x10]!
    // 0xad924c: r0 = write()
    //     0xad924c: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xad9250: add             SP, SP, #0x10
    // 0xad9254: ldur            x16, [fp, #-0x10]
    // 0xad9258: SaveReg r16
    //     0xad9258: str             x16, [SP, #-8]!
    // 0xad925c: r0 = toString()
    //     0xad925c: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0xad9260: add             SP, SP, #8
    // 0xad9264: LeaveFrame
    //     0xad9264: mov             SP, fp
    //     0xad9268: ldp             fp, lr, [SP], #0x10
    // 0xad926c: ret
    //     0xad926c: ret             
    // 0xad9270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9270: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9274: b               #0xad9124
  }
  [closure] String <anonymous closure>(dynamic, GestureArenaMember) {
    // ** addr: 0xad9278, size: 0x98
    // 0xad9278: EnterFrame
    //     0xad9278: stp             fp, lr, [SP, #-0x10]!
    //     0xad927c: mov             fp, SP
    // 0xad9280: ldr             x0, [fp, #0x18]
    // 0xad9284: LoadField: r1 = r0->field_17
    //     0xad9284: ldur            w1, [x0, #0x17]
    // 0xad9288: DecompressPointer r1
    //     0xad9288: add             x1, x1, HEAP, lsl #32
    // 0xad928c: CheckStackOverflow
    //     0xad928c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9290: cmp             SP, x16
    //     0xad9294: b.ls            #0xad9308
    // 0xad9298: LoadField: r0 = r1->field_f
    //     0xad9298: ldur            w0, [x1, #0xf]
    // 0xad929c: DecompressPointer r0
    //     0xad929c: add             x0, x0, HEAP, lsl #32
    // 0xad92a0: LoadField: r1 = r0->field_17
    //     0xad92a0: ldur            w1, [x0, #0x17]
    // 0xad92a4: DecompressPointer r1
    //     0xad92a4: add             x1, x1, HEAP, lsl #32
    // 0xad92a8: ldr             x0, [fp, #0x10]
    // 0xad92ac: cmp             w0, w1
    // 0xad92b0: b.ne            #0xad92f0
    // 0xad92b4: r1 = Null
    //     0xad92b4: mov             x1, NULL
    // 0xad92b8: r2 = 4
    //     0xad92b8: mov             x2, #4
    // 0xad92bc: r0 = AllocateArray()
    //     0xad92bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad92c0: mov             x1, x0
    // 0xad92c4: ldr             x0, [fp, #0x10]
    // 0xad92c8: StoreField: r1->field_f = r0
    //     0xad92c8: stur            w0, [x1, #0xf]
    // 0xad92cc: r17 = " (eager winner)"
    //     0xad92cc: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e970] " (eager winner)"
    //     0xad92d0: ldr             x17, [x17, #0x970]
    // 0xad92d4: StoreField: r1->field_13 = r17
    //     0xad92d4: stur            w17, [x1, #0x13]
    // 0xad92d8: SaveReg r1
    //     0xad92d8: str             x1, [SP, #-8]!
    // 0xad92dc: r0 = _interpolate()
    //     0xad92dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad92e0: add             SP, SP, #8
    // 0xad92e4: LeaveFrame
    //     0xad92e4: mov             SP, fp
    //     0xad92e8: ldp             fp, lr, [SP], #0x10
    // 0xad92ec: ret
    //     0xad92ec: ret             
    // 0xad92f0: SaveReg r0
    //     0xad92f0: str             x0, [SP, #-8]!
    // 0xad92f4: r0 = _interpolateSingle()
    //     0xad92f4: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0xad92f8: add             SP, SP, #8
    // 0xad92fc: LeaveFrame
    //     0xad92fc: mov             SP, fp
    //     0xad9300: ldp             fp, lr, [SP], #0x10
    // 0xad9304: ret
    //     0xad9304: ret             
    // 0xad9308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9308: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad930c: b               #0xad9298
  }
}

// class id: 2339, size: 0x18, field offset: 0x8
class GestureArenaEntry extends Object {

  _ resolve(/* No info */) {
    // ** addr: 0xcf7450, size: 0x58
    // 0xcf7450: EnterFrame
    //     0xcf7450: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7454: mov             fp, SP
    // 0xcf7458: CheckStackOverflow
    //     0xcf7458: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf745c: cmp             SP, x16
    //     0xcf7460: b.ls            #0xcf74a0
    // 0xcf7464: ldr             x0, [fp, #0x18]
    // 0xcf7468: LoadField: r1 = r0->field_7
    //     0xcf7468: ldur            w1, [x0, #7]
    // 0xcf746c: DecompressPointer r1
    //     0xcf746c: add             x1, x1, HEAP, lsl #32
    // 0xcf7470: LoadField: r2 = r0->field_b
    //     0xcf7470: ldur            x2, [x0, #0xb]
    // 0xcf7474: LoadField: r3 = r0->field_13
    //     0xcf7474: ldur            w3, [x0, #0x13]
    // 0xcf7478: DecompressPointer r3
    //     0xcf7478: add             x3, x3, HEAP, lsl #32
    // 0xcf747c: stp             x2, x1, [SP, #-0x10]!
    // 0xcf7480: ldr             x16, [fp, #0x10]
    // 0xcf7484: stp             x16, x3, [SP, #-0x10]!
    // 0xcf7488: r0 = _resolve()
    //     0xcf7488: bl              #0xcf74a8  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::_resolve
    // 0xcf748c: add             SP, SP, #0x20
    // 0xcf7490: r0 = Null
    //     0xcf7490: mov             x0, NULL
    // 0xcf7494: LeaveFrame
    //     0xcf7494: mov             SP, fp
    //     0xcf7498: ldp             fp, lr, [SP], #0x10
    // 0xcf749c: ret
    //     0xcf749c: ret             
    // 0xcf74a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf74a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf74a4: b               #0xcf7464
  }
}

// class id: 2340, size: 0x8, field offset: 0x8
abstract class GestureArenaMember extends Object {
}

// class id: 5981, size: 0x14, field offset: 0x14
enum GestureDisposition extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15ce8, size: 0x5c
    // 0xb15ce8: EnterFrame
    //     0xb15ce8: stp             fp, lr, [SP, #-0x10]!
    //     0xb15cec: mov             fp, SP
    // 0xb15cf0: CheckStackOverflow
    //     0xb15cf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15cf4: cmp             SP, x16
    //     0xb15cf8: b.ls            #0xb15d3c
    // 0xb15cfc: r1 = Null
    //     0xb15cfc: mov             x1, NULL
    // 0xb15d00: r2 = 4
    //     0xb15d00: mov             x2, #4
    // 0xb15d04: r0 = AllocateArray()
    //     0xb15d04: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15d08: r17 = "GestureDisposition."
    //     0xb15d08: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e940] "GestureDisposition."
    //     0xb15d0c: ldr             x17, [x17, #0x940]
    // 0xb15d10: StoreField: r0->field_f = r17
    //     0xb15d10: stur            w17, [x0, #0xf]
    // 0xb15d14: ldr             x1, [fp, #0x10]
    // 0xb15d18: LoadField: r2 = r1->field_f
    //     0xb15d18: ldur            w2, [x1, #0xf]
    // 0xb15d1c: DecompressPointer r2
    //     0xb15d1c: add             x2, x2, HEAP, lsl #32
    // 0xb15d20: StoreField: r0->field_13 = r2
    //     0xb15d20: stur            w2, [x0, #0x13]
    // 0xb15d24: SaveReg r0
    //     0xb15d24: str             x0, [SP, #-8]!
    // 0xb15d28: r0 = _interpolate()
    //     0xb15d28: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15d2c: add             SP, SP, #8
    // 0xb15d30: LeaveFrame
    //     0xb15d30: mov             SP, fp
    //     0xb15d34: ldp             fp, lr, [SP], #0x10
    // 0xb15d38: ret
    //     0xb15d38: ret             
    // 0xb15d3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15d3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15d40: b               #0xb15cfc
  }
}

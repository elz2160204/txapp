// lib: , url: package:flutter/src/gestures/binding.dart

// class id: 1049150, size: 0x8
class :: {
}

// class id: 2335, size: 0x28, field offset: 0x8
class _Resampler extends Object {

  _ stop(/* No info */) {
    // ** addr: 0x50f36c, size: 0x148
    // 0x50f36c: EnterFrame
    //     0x50f36c: stp             fp, lr, [SP, #-0x10]!
    //     0x50f370: mov             fp, SP
    // 0x50f374: AllocStack(0x28)
    //     0x50f374: sub             SP, SP, #0x28
    // 0x50f378: CheckStackOverflow
    //     0x50f378: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50f37c: cmp             SP, x16
    //     0x50f380: b.ls            #0x50f4a4
    // 0x50f384: ldr             x0, [fp, #0x10]
    // 0x50f388: LoadField: r1 = r0->field_7
    //     0x50f388: ldur            w1, [x0, #7]
    // 0x50f38c: DecompressPointer r1
    //     0x50f38c: add             x1, x1, HEAP, lsl #32
    // 0x50f390: stur            x1, [fp, #-8]
    // 0x50f394: SaveReg r1
    //     0x50f394: str             x1, [SP, #-8]!
    // 0x50f398: r0 = values()
    //     0x50f398: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x50f39c: add             SP, SP, #8
    // 0x50f3a0: SaveReg r0
    //     0x50f3a0: str             x0, [SP, #-8]!
    // 0x50f3a4: r0 = iterator()
    //     0x50f3a4: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x50f3a8: add             SP, SP, #8
    // 0x50f3ac: mov             x1, x0
    // 0x50f3b0: ldr             x0, [fp, #0x10]
    // 0x50f3b4: stur            x1, [fp, #-0x20]
    // 0x50f3b8: LoadField: r2 = r0->field_17
    //     0x50f3b8: ldur            w2, [x0, #0x17]
    // 0x50f3bc: DecompressPointer r2
    //     0x50f3bc: add             x2, x2, HEAP, lsl #32
    // 0x50f3c0: stur            x2, [fp, #-0x18]
    // 0x50f3c4: LoadField: r3 = r1->field_7
    //     0x50f3c4: ldur            w3, [x1, #7]
    // 0x50f3c8: DecompressPointer r3
    //     0x50f3c8: add             x3, x3, HEAP, lsl #32
    // 0x50f3cc: stur            x3, [fp, #-0x10]
    // 0x50f3d0: CheckStackOverflow
    //     0x50f3d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50f3d4: cmp             SP, x16
    //     0x50f3d8: b.ls            #0x50f4ac
    // 0x50f3dc: SaveReg r1
    //     0x50f3dc: str             x1, [SP, #-8]!
    // 0x50f3e0: r0 = moveNext()
    //     0x50f3e0: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x50f3e4: add             SP, SP, #8
    // 0x50f3e8: tbnz            w0, #4, #0x50f458
    // 0x50f3ec: ldur            x3, [fp, #-0x20]
    // 0x50f3f0: LoadField: r4 = r3->field_33
    //     0x50f3f0: ldur            w4, [x3, #0x33]
    // 0x50f3f4: DecompressPointer r4
    //     0x50f3f4: add             x4, x4, HEAP, lsl #32
    // 0x50f3f8: stur            x4, [fp, #-0x28]
    // 0x50f3fc: cmp             w4, NULL
    // 0x50f400: b.ne            #0x50f430
    // 0x50f404: mov             x0, x4
    // 0x50f408: ldur            x2, [fp, #-0x10]
    // 0x50f40c: r1 = Null
    //     0x50f40c: mov             x1, NULL
    // 0x50f410: cmp             w2, NULL
    // 0x50f414: b.eq            #0x50f430
    // 0x50f418: LoadField: r4 = r2->field_17
    //     0x50f418: ldur            w4, [x2, #0x17]
    // 0x50f41c: DecompressPointer r4
    //     0x50f41c: add             x4, x4, HEAP, lsl #32
    // 0x50f420: r8 = X0
    //     0x50f420: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x50f424: LoadField: r9 = r4->field_7
    //     0x50f424: ldur            x9, [x4, #7]
    // 0x50f428: r3 = Null
    //     0x50f428: ldr             x3, [PP, #0x3ac0]  ; [pp+0x3ac0] Null
    // 0x50f42c: blr             x9
    // 0x50f430: ldur            x16, [fp, #-0x28]
    // 0x50f434: ldur            lr, [fp, #-0x18]
    // 0x50f438: stp             lr, x16, [SP, #-0x10]!
    // 0x50f43c: r0 = stop()
    //     0x50f43c: bl              #0x50f580  ; [package:flutter/src/gestures/resampler.dart] PointerEventResampler::stop
    // 0x50f440: add             SP, SP, #0x10
    // 0x50f444: ldr             x0, [fp, #0x10]
    // 0x50f448: ldur            x1, [fp, #-0x20]
    // 0x50f44c: ldur            x2, [fp, #-0x18]
    // 0x50f450: ldur            x3, [fp, #-0x10]
    // 0x50f454: b               #0x50f3d0
    // 0x50f458: ldr             x0, [fp, #0x10]
    // 0x50f45c: ldur            x16, [fp, #-8]
    // 0x50f460: SaveReg r16
    //     0x50f460: str             x16, [SP, #-8]!
    // 0x50f464: r0 = clear()
    //     0x50f464: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x50f468: add             SP, SP, #8
    // 0x50f46c: ldr             x0, [fp, #0x10]
    // 0x50f470: r1 = Instance_Duration
    //     0x50f470: ldr             x1, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x50f474: StoreField: r0->field_f = r1
    //     0x50f474: stur            w1, [x0, #0xf]
    // 0x50f478: LoadField: r1 = r0->field_23
    //     0x50f478: ldur            w1, [x0, #0x23]
    // 0x50f47c: DecompressPointer r1
    //     0x50f47c: add             x1, x1, HEAP, lsl #32
    // 0x50f480: cmp             w1, NULL
    // 0x50f484: b.eq            #0x50f494
    // 0x50f488: SaveReg r1
    //     0x50f488: str             x1, [SP, #-8]!
    // 0x50f48c: r0 = cancel()
    //     0x50f48c: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x50f490: add             SP, SP, #8
    // 0x50f494: r0 = Null
    //     0x50f494: mov             x0, NULL
    // 0x50f498: LeaveFrame
    //     0x50f498: mov             SP, fp
    //     0x50f49c: ldp             fp, lr, [SP], #0x10
    // 0x50f4a0: ret
    //     0x50f4a0: ret             
    // 0x50f4a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50f4a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50f4a8: b               #0x50f384
    // 0x50f4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50f4ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50f4b0: b               #0x50f3dc
  }
  _ _Resampler(/* No info */) {
    // ** addr: 0x50f710, size: 0x11c
    // 0x50f710: EnterFrame
    //     0x50f710: stp             fp, lr, [SP, #-0x10]!
    //     0x50f714: mov             fp, SP
    // 0x50f718: AllocStack(0x8)
    //     0x50f718: sub             SP, SP, #8
    // 0x50f71c: r1 = false
    //     0x50f71c: add             x1, NULL, #0x30  ; false
    // 0x50f720: r0 = Instance_Duration
    //     0x50f720: ldr             x0, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x50f724: CheckStackOverflow
    //     0x50f724: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50f728: cmp             SP, x16
    //     0x50f72c: b.ls            #0x50f824
    // 0x50f730: ldr             x2, [fp, #0x20]
    // 0x50f734: StoreField: r2->field_b = r1
    //     0x50f734: stur            w1, [x2, #0xb]
    // 0x50f738: StoreField: r2->field_f = r0
    //     0x50f738: stur            w0, [x2, #0xf]
    // 0x50f73c: r16 = <int, PointerEventResampler>
    //     0x50f73c: ldr             x16, [PP, #0x38b8]  ; [pp+0x38b8] TypeArguments: <int, PointerEventResampler>
    // 0x50f740: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x50f744: stp             lr, x16, [SP, #-0x10]!
    // 0x50f748: r0 = Map._fromLiteral()
    //     0x50f748: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x50f74c: add             SP, SP, #0x10
    // 0x50f750: ldr             x1, [fp, #0x20]
    // 0x50f754: StoreField: r1->field_7 = r0
    //     0x50f754: stur            w0, [x1, #7]
    //     0x50f758: tbz             w0, #0, #0x50f774
    //     0x50f75c: ldurb           w16, [x1, #-1]
    //     0x50f760: ldurb           w17, [x0, #-1]
    //     0x50f764: and             x16, x17, x16, lsr #2
    //     0x50f768: tst             x16, HEAP, lsr #32
    //     0x50f76c: b.eq            #0x50f774
    //     0x50f770: bl              #0xd6826c
    // 0x50f774: r0 = Stopwatch()
    //     0x50f774: bl              #0x4ffefc  ; AllocateStopwatchStub -> Stopwatch (size=0x14)
    // 0x50f778: mov             x1, x0
    // 0x50f77c: r0 = 0
    //     0x50f77c: mov             x0, #0
    // 0x50f780: stur            x1, [fp, #-8]
    // 0x50f784: StoreField: r1->field_7 = r0
    //     0x50f784: stur            x0, [x1, #7]
    // 0x50f788: StoreField: r1->field_f = rZR
    //     0x50f788: stur            wzr, [x1, #0xf]
    // 0x50f78c: r0 = InitLateStaticField(0x570) // [dart:core] Stopwatch::_frequency
    //     0x50f78c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x50f790: ldr             x0, [x0, #0xae0]
    //     0x50f794: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x50f798: cmp             w0, w16
    //     0x50f79c: b.ne            #0x50f7a8
    //     0x50f7a0: ldr             x2, [PP, #0x1b58]  ; [pp+0x1b58] Field <Stopwatch._frequency@0150898>: static late final (offset: 0x570)
    //     0x50f7a4: bl              #0xd67cdc
    // 0x50f7a8: ldur            x0, [fp, #-8]
    // 0x50f7ac: ldr             x1, [fp, #0x20]
    // 0x50f7b0: StoreField: r1->field_13 = r0
    //     0x50f7b0: stur            w0, [x1, #0x13]
    //     0x50f7b4: ldurb           w16, [x1, #-1]
    //     0x50f7b8: ldurb           w17, [x0, #-1]
    //     0x50f7bc: and             x16, x17, x16, lsr #2
    //     0x50f7c0: tst             x16, HEAP, lsr #32
    //     0x50f7c4: b.eq            #0x50f7cc
    //     0x50f7c8: bl              #0xd6826c
    // 0x50f7cc: ldr             x0, [fp, #0x18]
    // 0x50f7d0: StoreField: r1->field_17 = r0
    //     0x50f7d0: stur            w0, [x1, #0x17]
    //     0x50f7d4: ldurb           w16, [x1, #-1]
    //     0x50f7d8: ldurb           w17, [x0, #-1]
    //     0x50f7dc: and             x16, x17, x16, lsr #2
    //     0x50f7e0: tst             x16, HEAP, lsr #32
    //     0x50f7e4: b.eq            #0x50f7ec
    //     0x50f7e8: bl              #0xd6826c
    // 0x50f7ec: ldr             x0, [fp, #0x10]
    // 0x50f7f0: StoreField: r1->field_1b = r0
    //     0x50f7f0: stur            w0, [x1, #0x1b]
    //     0x50f7f4: ldurb           w16, [x1, #-1]
    //     0x50f7f8: ldurb           w17, [x0, #-1]
    //     0x50f7fc: and             x16, x17, x16, lsr #2
    //     0x50f800: tst             x16, HEAP, lsr #32
    //     0x50f804: b.eq            #0x50f80c
    //     0x50f808: bl              #0xd6826c
    // 0x50f80c: r2 = Instance_Duration
    //     0x50f80c: ldr             x2, [PP, #0x38c0]  ; [pp+0x38c0] Obj!Duration@b67a31
    // 0x50f810: StoreField: r1->field_1f = r2
    //     0x50f810: stur            w2, [x1, #0x1f]
    // 0x50f814: r0 = Null
    //     0x50f814: mov             x0, NULL
    // 0x50f818: LeaveFrame
    //     0x50f818: mov             SP, fp
    //     0x50f81c: ldp             fp, lr, [SP], #0x10
    // 0x50f820: ret
    //     0x50f820: ret             
    // 0x50f824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50f824: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50f828: b               #0x50f730
  }
}

// class id: 2652, size: 0x10, field offset: 0x10
abstract class GestureBinding extends BindingBase
    implements HitTestable, HitTestDispatcher, HitTestTarget {

  get _ instance(/* No info */) {
    // ** addr: 0x5b9c64, size: 0x28
    // 0x5b9c64: EnterFrame
    //     0x5b9c64: stp             fp, lr, [SP, #-0x10]!
    //     0x5b9c68: mov             fp, SP
    // 0x5b9c6c: r0 = LoadStaticField(0xd54)
    //     0x5b9c6c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5b9c70: ldr             x0, [x0, #0x1aa8]
    // 0x5b9c74: cmp             w0, NULL
    // 0x5b9c78: b.eq            #0x5b9c88
    // 0x5b9c7c: LeaveFrame
    //     0x5b9c7c: mov             SP, fp
    //     0x5b9c80: ldp             fp, lr, [SP], #0x10
    // 0x5b9c84: ret
    //     0x5b9c84: ret             
    // 0x5b9c88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5b9c88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2895, size: 0x24, field offset: 0x24
//   const constructor, 
class FlutterErrorDetailsForPointerEventDispatcher extends FlutterErrorDetails {
}

// lib: , url: package:flutter/src/gestures/multidrag.dart

// class id: 1049164, size: 0x8
class :: {
}

// class id: 2269, size: 0x28, field offset: 0x8
abstract class MultiDragPointerState extends Object {

  _ MultiDragPointerState(/* No info */) {
    // ** addr: 0x7837a0, size: 0xe0
    // 0x7837a0: EnterFrame
    //     0x7837a0: stp             fp, lr, [SP, #-0x10]!
    //     0x7837a4: mov             fp, SP
    // 0x7837a8: AllocStack(0x8)
    //     0x7837a8: sub             SP, SP, #8
    // 0x7837ac: r0 = Instance_Offset
    //     0x7837ac: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x7837b0: ldr             x1, [fp, #0x28]
    // 0x7837b4: StoreField: r1->field_1b = r0
    //     0x7837b4: stur            w0, [x1, #0x1b]
    // 0x7837b8: ldr             x0, [fp, #0x20]
    // 0x7837bc: StoreField: r1->field_b = r0
    //     0x7837bc: stur            w0, [x1, #0xb]
    //     0x7837c0: ldurb           w16, [x1, #-1]
    //     0x7837c4: ldurb           w17, [x0, #-1]
    //     0x7837c8: and             x16, x17, x16, lsr #2
    //     0x7837cc: tst             x16, HEAP, lsr #32
    //     0x7837d0: b.eq            #0x7837d8
    //     0x7837d4: bl              #0xd6826c
    // 0x7837d8: ldr             x0, [fp, #0x18]
    // 0x7837dc: StoreField: r1->field_13 = r0
    //     0x7837dc: stur            w0, [x1, #0x13]
    //     0x7837e0: ldurb           w16, [x1, #-1]
    //     0x7837e4: ldurb           w17, [x0, #-1]
    //     0x7837e8: and             x16, x17, x16, lsr #2
    //     0x7837ec: tst             x16, HEAP, lsr #32
    //     0x7837f0: b.eq            #0x7837f8
    //     0x7837f4: bl              #0xd6826c
    // 0x7837f8: ldr             x0, [fp, #0x10]
    // 0x7837fc: StoreField: r1->field_7 = r0
    //     0x7837fc: stur            w0, [x1, #7]
    //     0x783800: ldurb           w16, [x1, #-1]
    //     0x783804: ldurb           w17, [x0, #-1]
    //     0x783808: and             x16, x17, x16, lsr #2
    //     0x78380c: tst             x16, HEAP, lsr #32
    //     0x783810: b.eq            #0x783818
    //     0x783814: bl              #0xd6826c
    // 0x783818: r0 = VelocityTracker()
    //     0x783818: bl              #0x6ee4b0  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x18)
    // 0x78381c: mov             x3, x0
    // 0x783820: r0 = 0
    //     0x783820: mov             x0, #0
    // 0x783824: stur            x3, [fp, #-8]
    // 0x783828: StoreField: r3->field_f = r0
    //     0x783828: stur            x0, [x3, #0xf]
    // 0x78382c: r1 = <_PointAtTime?>
    //     0x78382c: add             x1, PP, #0x21, lsl #12  ; [pp+0x214e8] TypeArguments: <_PointAtTime?>
    //     0x783830: ldr             x1, [x1, #0x4e8]
    // 0x783834: r2 = 40
    //     0x783834: mov             x2, #0x28
    // 0x783838: r0 = AllocateArray()
    //     0x783838: bl              #0xd6987c  ; AllocateArrayStub
    // 0x78383c: mov             x1, x0
    // 0x783840: ldur            x0, [fp, #-8]
    // 0x783844: StoreField: r0->field_b = r1
    //     0x783844: stur            w1, [x0, #0xb]
    // 0x783848: ldr             x1, [fp, #0x18]
    // 0x78384c: StoreField: r0->field_7 = r1
    //     0x78384c: stur            w1, [x0, #7]
    // 0x783850: ldr             x1, [fp, #0x28]
    // 0x783854: StoreField: r1->field_f = r0
    //     0x783854: stur            w0, [x1, #0xf]
    //     0x783858: ldurb           w16, [x1, #-1]
    //     0x78385c: ldurb           w17, [x0, #-1]
    //     0x783860: and             x16, x17, x16, lsr #2
    //     0x783864: tst             x16, HEAP, lsr #32
    //     0x783868: b.eq            #0x783870
    //     0x78386c: bl              #0xd6826c
    // 0x783870: r0 = Null
    //     0x783870: mov             x0, NULL
    // 0x783874: LeaveFrame
    //     0x783874: mov             SP, fp
    //     0x783878: ldp             fp, lr, [SP], #0x10
    // 0x78387c: ret
    //     0x78387c: ret             
  }
  _ resolve(/* No info */) {
    // ** addr: 0x783a24, size: 0x54
    // 0x783a24: EnterFrame
    //     0x783a24: stp             fp, lr, [SP, #-0x10]!
    //     0x783a28: mov             fp, SP
    // 0x783a2c: CheckStackOverflow
    //     0x783a2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783a30: cmp             SP, x16
    //     0x783a34: b.ls            #0x783a6c
    // 0x783a38: ldr             x0, [fp, #0x18]
    // 0x783a3c: LoadField: r1 = r0->field_23
    //     0x783a3c: ldur            w1, [x0, #0x23]
    // 0x783a40: DecompressPointer r1
    //     0x783a40: add             x1, x1, HEAP, lsl #32
    // 0x783a44: cmp             w1, NULL
    // 0x783a48: b.eq            #0x783a74
    // 0x783a4c: ldr             x16, [fp, #0x10]
    // 0x783a50: stp             x16, x1, [SP, #-0x10]!
    // 0x783a54: r0 = resolve()
    //     0x783a54: bl              #0xcf7450  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0x783a58: add             SP, SP, #0x10
    // 0x783a5c: r0 = Null
    //     0x783a5c: mov             x0, NULL
    // 0x783a60: LeaveFrame
    //     0x783a60: mov             SP, fp
    //     0x783a64: ldp             fp, lr, [SP], #0x10
    // 0x783a68: ret
    //     0x783a68: ret             
    // 0x783a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783a6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783a70: b               #0x783a38
    // 0x783a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783a74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _cancel(/* No info */) {
    // ** addr: 0x783d74, size: 0x6c
    // 0x783d74: EnterFrame
    //     0x783d74: stp             fp, lr, [SP, #-0x10]!
    //     0x783d78: mov             fp, SP
    // 0x783d7c: CheckStackOverflow
    //     0x783d7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783d80: cmp             SP, x16
    //     0x783d84: b.ls            #0x783dd8
    // 0x783d88: ldr             x0, [fp, #0x10]
    // 0x783d8c: LoadField: r1 = r0->field_17
    //     0x783d8c: ldur            w1, [x0, #0x17]
    // 0x783d90: DecompressPointer r1
    //     0x783d90: add             x1, x1, HEAP, lsl #32
    // 0x783d94: cmp             w1, NULL
    // 0x783d98: b.eq            #0x783dc0
    // 0x783d9c: StoreField: r0->field_17 = rNULL
    //     0x783d9c: stur            NULL, [x0, #0x17]
    // 0x783da0: r0 = LoadClassIdInstr(r1)
    //     0x783da0: ldur            x0, [x1, #-1]
    //     0x783da4: ubfx            x0, x0, #0xc, #0x14
    // 0x783da8: SaveReg r1
    //     0x783da8: str             x1, [SP, #-8]!
    // 0x783dac: r0 = GDT[cid_x0 + -0xfe4]()
    //     0x783dac: sub             lr, x0, #0xfe4
    //     0x783db0: ldr             lr, [x21, lr, lsl #3]
    //     0x783db4: blr             lr
    // 0x783db8: add             SP, SP, #8
    // 0x783dbc: b               #0x783dc8
    // 0x783dc0: StoreField: r0->field_1b = rNULL
    //     0x783dc0: stur            NULL, [x0, #0x1b]
    // 0x783dc4: StoreField: r0->field_1f = rNULL
    //     0x783dc4: stur            NULL, [x0, #0x1f]
    // 0x783dc8: r0 = Null
    //     0x783dc8: mov             x0, NULL
    // 0x783dcc: LeaveFrame
    //     0x783dcc: mov             SP, fp
    //     0x783dd0: ldp             fp, lr, [SP], #0x10
    // 0x783dd4: ret
    //     0x783dd4: ret             
    // 0x783dd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783dd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783ddc: b               #0x783d88
  }
  _ _up(/* No info */) {
    // ** addr: 0x783f48, size: 0xb0
    // 0x783f48: EnterFrame
    //     0x783f48: stp             fp, lr, [SP, #-0x10]!
    //     0x783f4c: mov             fp, SP
    // 0x783f50: AllocStack(0x8)
    //     0x783f50: sub             SP, SP, #8
    // 0x783f54: CheckStackOverflow
    //     0x783f54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783f58: cmp             SP, x16
    //     0x783f5c: b.ls            #0x783fec
    // 0x783f60: ldr             x0, [fp, #0x10]
    // 0x783f64: LoadField: r1 = r0->field_17
    //     0x783f64: ldur            w1, [x0, #0x17]
    // 0x783f68: DecompressPointer r1
    //     0x783f68: add             x1, x1, HEAP, lsl #32
    // 0x783f6c: cmp             w1, NULL
    // 0x783f70: b.eq            #0x783fd4
    // 0x783f74: LoadField: r1 = r0->field_f
    //     0x783f74: ldur            w1, [x0, #0xf]
    // 0x783f78: DecompressPointer r1
    //     0x783f78: add             x1, x1, HEAP, lsl #32
    // 0x783f7c: SaveReg r1
    //     0x783f7c: str             x1, [SP, #-8]!
    // 0x783f80: r0 = getVelocity()
    //     0x783f80: bl              #0xc3ec88  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::getVelocity
    // 0x783f84: add             SP, SP, #8
    // 0x783f88: stur            x0, [fp, #-8]
    // 0x783f8c: r0 = DragEndDetails()
    //     0x783f8c: bl              #0x713c0c  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x10)
    // 0x783f90: mov             x1, x0
    // 0x783f94: ldur            x0, [fp, #-8]
    // 0x783f98: StoreField: r1->field_7 = r0
    //     0x783f98: stur            w0, [x1, #7]
    // 0x783f9c: ldr             x0, [fp, #0x10]
    // 0x783fa0: LoadField: r2 = r0->field_17
    //     0x783fa0: ldur            w2, [x0, #0x17]
    // 0x783fa4: DecompressPointer r2
    //     0x783fa4: add             x2, x2, HEAP, lsl #32
    // 0x783fa8: cmp             w2, NULL
    // 0x783fac: b.eq            #0x783ff4
    // 0x783fb0: StoreField: r0->field_17 = rNULL
    //     0x783fb0: stur            NULL, [x0, #0x17]
    // 0x783fb4: r0 = LoadClassIdInstr(r2)
    //     0x783fb4: ldur            x0, [x2, #-1]
    //     0x783fb8: ubfx            x0, x0, #0xc, #0x14
    // 0x783fbc: stp             x1, x2, [SP, #-0x10]!
    // 0x783fc0: r0 = GDT[cid_x0 + -0xfea]()
    //     0x783fc0: sub             lr, x0, #0xfea
    //     0x783fc4: ldr             lr, [x21, lr, lsl #3]
    //     0x783fc8: blr             lr
    // 0x783fcc: add             SP, SP, #0x10
    // 0x783fd0: b               #0x783fdc
    // 0x783fd4: StoreField: r0->field_1b = rNULL
    //     0x783fd4: stur            NULL, [x0, #0x1b]
    // 0x783fd8: StoreField: r0->field_1f = rNULL
    //     0x783fd8: stur            NULL, [x0, #0x1f]
    // 0x783fdc: r0 = Null
    //     0x783fdc: mov             x0, NULL
    // 0x783fe0: LeaveFrame
    //     0x783fe0: mov             SP, fp
    //     0x783fe4: ldp             fp, lr, [SP], #0x10
    // 0x783fe8: ret
    //     0x783fe8: ret             
    // 0x783fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783fec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783ff0: b               #0x783f60
    // 0x783ff4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783ff4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _move(/* No info */) {
    // ** addr: 0x783ff8, size: 0x3ec
    // 0x783ff8: EnterFrame
    //     0x783ff8: stp             fp, lr, [SP, #-0x10]!
    //     0x783ffc: mov             fp, SP
    // 0x784000: AllocStack(0x20)
    //     0x784000: sub             SP, SP, #0x20
    // 0x784004: CheckStackOverflow
    //     0x784004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x784008: cmp             SP, x16
    //     0x78400c: b.ls            #0x7843d0
    // 0x784010: ldr             x1, [fp, #0x10]
    // 0x784014: r0 = LoadClassIdInstr(r1)
    //     0x784014: ldur            x0, [x1, #-1]
    //     0x784018: ubfx            x0, x0, #0xc, #0x14
    // 0x78401c: SaveReg r1
    //     0x78401c: str             x1, [SP, #-8]!
    // 0x784020: r0 = GDT[cid_x0 + 0x7012]()
    //     0x784020: mov             x17, #0x7012
    //     0x784024: add             lr, x0, x17
    //     0x784028: ldr             lr, [x21, lr, lsl #3]
    //     0x78402c: blr             lr
    // 0x784030: add             SP, SP, #8
    // 0x784034: tbz             w0, #4, #0x7840a8
    // 0x784038: ldr             x2, [fp, #0x18]
    // 0x78403c: ldr             x1, [fp, #0x10]
    // 0x784040: LoadField: r3 = r2->field_f
    //     0x784040: ldur            w3, [x2, #0xf]
    // 0x784044: DecompressPointer r3
    //     0x784044: add             x3, x3, HEAP, lsl #32
    // 0x784048: stur            x3, [fp, #-8]
    // 0x78404c: r0 = LoadClassIdInstr(r1)
    //     0x78404c: ldur            x0, [x1, #-1]
    //     0x784050: ubfx            x0, x0, #0xc, #0x14
    // 0x784054: SaveReg r1
    //     0x784054: str             x1, [SP, #-8]!
    // 0x784058: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x784058: sub             lr, x0, #0xf3a
    //     0x78405c: ldr             lr, [x21, lr, lsl #3]
    //     0x784060: blr             lr
    // 0x784064: add             SP, SP, #8
    // 0x784068: mov             x2, x0
    // 0x78406c: ldr             x1, [fp, #0x10]
    // 0x784070: stur            x2, [fp, #-0x10]
    // 0x784074: r0 = LoadClassIdInstr(r1)
    //     0x784074: ldur            x0, [x1, #-1]
    //     0x784078: ubfx            x0, x0, #0xc, #0x14
    // 0x78407c: SaveReg r1
    //     0x78407c: str             x1, [SP, #-8]!
    // 0x784080: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x784080: sub             lr, x0, #0xfd9
    //     0x784084: ldr             lr, [x21, lr, lsl #3]
    //     0x784088: blr             lr
    // 0x78408c: add             SP, SP, #8
    // 0x784090: ldur            x16, [fp, #-8]
    // 0x784094: ldur            lr, [fp, #-0x10]
    // 0x784098: stp             lr, x16, [SP, #-0x10]!
    // 0x78409c: SaveReg r0
    //     0x78409c: str             x0, [SP, #-8]!
    // 0x7840a0: r0 = addPosition()
    //     0x7840a0: bl              #0xcb5c90  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::addPosition
    // 0x7840a4: add             SP, SP, #0x18
    // 0x7840a8: ldr             x1, [fp, #0x18]
    // 0x7840ac: LoadField: r2 = r1->field_17
    //     0x7840ac: ldur            w2, [x1, #0x17]
    // 0x7840b0: DecompressPointer r2
    //     0x7840b0: add             x2, x2, HEAP, lsl #32
    // 0x7840b4: stur            x2, [fp, #-8]
    // 0x7840b8: cmp             w2, NULL
    // 0x7840bc: b.eq            #0x784184
    // 0x7840c0: ldr             x1, [fp, #0x10]
    // 0x7840c4: r0 = LoadClassIdInstr(r1)
    //     0x7840c4: ldur            x0, [x1, #-1]
    //     0x7840c8: ubfx            x0, x0, #0xc, #0x14
    // 0x7840cc: SaveReg r1
    //     0x7840cc: str             x1, [SP, #-8]!
    // 0x7840d0: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x7840d0: sub             lr, x0, #0xf3a
    //     0x7840d4: ldr             lr, [x21, lr, lsl #3]
    //     0x7840d8: blr             lr
    // 0x7840dc: add             SP, SP, #8
    // 0x7840e0: mov             x2, x0
    // 0x7840e4: ldr             x1, [fp, #0x10]
    // 0x7840e8: stur            x2, [fp, #-0x10]
    // 0x7840ec: r0 = LoadClassIdInstr(r1)
    //     0x7840ec: ldur            x0, [x1, #-1]
    //     0x7840f0: ubfx            x0, x0, #0xc, #0x14
    // 0x7840f4: SaveReg r1
    //     0x7840f4: str             x1, [SP, #-8]!
    // 0x7840f8: r0 = GDT[cid_x0 + 0x9887]()
    //     0x7840f8: mov             x17, #0x9887
    //     0x7840fc: add             lr, x0, x17
    //     0x784100: ldr             lr, [x21, lr, lsl #3]
    //     0x784104: blr             lr
    // 0x784108: add             SP, SP, #8
    // 0x78410c: mov             x1, x0
    // 0x784110: ldr             x2, [fp, #0x10]
    // 0x784114: stur            x1, [fp, #-0x18]
    // 0x784118: r0 = LoadClassIdInstr(r2)
    //     0x784118: ldur            x0, [x2, #-1]
    //     0x78411c: ubfx            x0, x0, #0xc, #0x14
    // 0x784120: SaveReg r2
    //     0x784120: str             x2, [SP, #-8]!
    // 0x784124: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x784124: sub             lr, x0, #0xfd9
    //     0x784128: ldr             lr, [x21, lr, lsl #3]
    //     0x78412c: blr             lr
    // 0x784130: add             SP, SP, #8
    // 0x784134: stur            x0, [fp, #-0x20]
    // 0x784138: r0 = DragUpdateDetails()
    //     0x784138: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0x78413c: mov             x1, x0
    // 0x784140: ldur            x0, [fp, #-0x10]
    // 0x784144: StoreField: r1->field_7 = r0
    //     0x784144: stur            w0, [x1, #7]
    // 0x784148: ldur            x0, [fp, #-0x18]
    // 0x78414c: StoreField: r1->field_b = r0
    //     0x78414c: stur            w0, [x1, #0xb]
    // 0x784150: ldur            x0, [fp, #-0x20]
    // 0x784154: StoreField: r1->field_13 = r0
    //     0x784154: stur            w0, [x1, #0x13]
    // 0x784158: StoreField: r1->field_17 = r0
    //     0x784158: stur            w0, [x1, #0x17]
    // 0x78415c: ldur            x0, [fp, #-8]
    // 0x784160: r2 = LoadClassIdInstr(r0)
    //     0x784160: ldur            x2, [x0, #-1]
    //     0x784164: ubfx            x2, x2, #0xc, #0x14
    // 0x784168: stp             x1, x0, [SP, #-0x10]!
    // 0x78416c: mov             x0, x2
    // 0x784170: r0 = GDT[cid_x0 + -0x1000]()
    //     0x784170: sub             lr, x0, #1, lsl #12
    //     0x784174: ldr             lr, [x21, lr, lsl #3]
    //     0x784178: blr             lr
    // 0x78417c: add             SP, SP, #0x10
    // 0x784180: b               #0x7843c0
    // 0x784184: ldr             x2, [fp, #0x10]
    // 0x784188: LoadField: r3 = r1->field_1b
    //     0x784188: ldur            w3, [x1, #0x1b]
    // 0x78418c: DecompressPointer r3
    //     0x78418c: add             x3, x3, HEAP, lsl #32
    // 0x784190: stur            x3, [fp, #-8]
    // 0x784194: cmp             w3, NULL
    // 0x784198: b.eq            #0x7843d8
    // 0x78419c: r0 = LoadClassIdInstr(r2)
    //     0x78419c: ldur            x0, [x2, #-1]
    //     0x7841a0: ubfx            x0, x0, #0xc, #0x14
    // 0x7841a4: SaveReg r2
    //     0x7841a4: str             x2, [SP, #-8]!
    // 0x7841a8: r0 = GDT[cid_x0 + 0x9887]()
    //     0x7841a8: mov             x17, #0x9887
    //     0x7841ac: add             lr, x0, x17
    //     0x7841b0: ldr             lr, [x21, lr, lsl #3]
    //     0x7841b4: blr             lr
    // 0x7841b8: add             SP, SP, #8
    // 0x7841bc: ldur            x16, [fp, #-8]
    // 0x7841c0: stp             x0, x16, [SP, #-0x10]!
    // 0x7841c4: r0 = +()
    //     0x7841c4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7841c8: add             SP, SP, #0x10
    // 0x7841cc: ldr             x1, [fp, #0x18]
    // 0x7841d0: StoreField: r1->field_1b = r0
    //     0x7841d0: stur            w0, [x1, #0x1b]
    //     0x7841d4: ldurb           w16, [x1, #-1]
    //     0x7841d8: ldurb           w17, [x0, #-1]
    //     0x7841dc: and             x16, x17, x16, lsr #2
    //     0x7841e0: tst             x16, HEAP, lsr #32
    //     0x7841e4: b.eq            #0x7841ec
    //     0x7841e8: bl              #0xd6826c
    // 0x7841ec: ldr             x0, [fp, #0x10]
    // 0x7841f0: r2 = LoadClassIdInstr(r0)
    //     0x7841f0: ldur            x2, [x0, #-1]
    //     0x7841f4: ubfx            x2, x2, #0xc, #0x14
    // 0x7841f8: SaveReg r0
    //     0x7841f8: str             x0, [SP, #-8]!
    // 0x7841fc: mov             x0, x2
    // 0x784200: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x784200: sub             lr, x0, #0xf3a
    //     0x784204: ldr             lr, [x21, lr, lsl #3]
    //     0x784208: blr             lr
    // 0x78420c: add             SP, SP, #8
    // 0x784210: ldr             x1, [fp, #0x18]
    // 0x784214: StoreField: r1->field_1f = r0
    //     0x784214: stur            w0, [x1, #0x1f]
    //     0x784218: ldurb           w16, [x1, #-1]
    //     0x78421c: ldurb           w17, [x0, #-1]
    //     0x784220: and             x16, x17, x16, lsr #2
    //     0x784224: tst             x16, HEAP, lsr #32
    //     0x784228: b.eq            #0x784230
    //     0x78422c: bl              #0xd6826c
    // 0x784230: r0 = LoadClassIdInstr(r1)
    //     0x784230: ldur            x0, [x1, #-1]
    //     0x784234: ubfx            x0, x0, #0xc, #0x14
    // 0x784238: lsl             x0, x0, #1
    // 0x78423c: r17 = 4540
    //     0x78423c: mov             x17, #0x11bc
    // 0x784240: cmp             w0, w17
    // 0x784244: b.ne            #0x784314
    // 0x784248: LoadField: r0 = r1->field_27
    //     0x784248: ldur            w0, [x1, #0x27]
    // 0x78424c: DecompressPointer r0
    //     0x78424c: add             x0, x0, HEAP, lsl #32
    // 0x784250: cmp             w0, NULL
    // 0x784254: b.eq            #0x7843c0
    // 0x784258: LoadField: r0 = r1->field_1b
    //     0x784258: ldur            w0, [x1, #0x1b]
    // 0x78425c: DecompressPointer r0
    //     0x78425c: add             x0, x0, HEAP, lsl #32
    // 0x784260: cmp             w0, NULL
    // 0x784264: b.eq            #0x7843dc
    // 0x784268: LoadField: d0 = r0->field_7
    //     0x784268: ldur            d0, [x0, #7]
    // 0x78426c: fmul            d1, d0, d0
    // 0x784270: LoadField: d0 = r0->field_f
    //     0x784270: ldur            d0, [x0, #0xf]
    // 0x784274: fmul            d2, d0, d0
    // 0x784278: fadd            d0, d1, d2
    // 0x78427c: fsqrt           d1, d0
    // 0x784280: LoadField: r0 = r1->field_13
    //     0x784280: ldur            w0, [x1, #0x13]
    // 0x784284: DecompressPointer r0
    //     0x784284: add             x0, x0, HEAP, lsl #32
    // 0x784288: LoadField: r2 = r1->field_7
    //     0x784288: ldur            w2, [x1, #7]
    // 0x78428c: DecompressPointer r2
    //     0x78428c: add             x2, x2, HEAP, lsl #32
    // 0x784290: LoadField: r3 = r0->field_7
    //     0x784290: ldur            x3, [x0, #7]
    // 0x784294: cmp             x3, #2
    // 0x784298: b.gt            #0x7842b4
    // 0x78429c: cmp             x3, #1
    // 0x7842a0: b.gt            #0x7842b4
    // 0x7842a4: cmp             x3, #0
    // 0x7842a8: b.le            #0x7842b4
    // 0x7842ac: d0 = 1.000000
    //     0x7842ac: fmov            d0, #1.00000000
    // 0x7842b0: b               #0x7842e0
    // 0x7842b4: cmp             w2, NULL
    // 0x7842b8: b.ne            #0x7842c4
    // 0x7842bc: r0 = Null
    //     0x7842bc: mov             x0, NULL
    // 0x7842c0: b               #0x7842cc
    // 0x7842c4: LoadField: r0 = r2->field_7
    //     0x7842c4: ldur            w0, [x2, #7]
    // 0x7842c8: DecompressPointer r0
    //     0x7842c8: add             x0, x0, HEAP, lsl #32
    // 0x7842cc: cmp             w0, NULL
    // 0x7842d0: b.ne            #0x7842dc
    // 0x7842d4: d0 = 18.000000
    //     0x7842d4: fmov            d0, #18.00000000
    // 0x7842d8: b               #0x7842e0
    // 0x7842dc: LoadField: d0 = r0->field_7
    //     0x7842dc: ldur            d0, [x0, #7]
    // 0x7842e0: fcmp            d1, d0
    // 0x7842e4: b.vs            #0x7843c0
    // 0x7842e8: b.le            #0x7843c0
    // 0x7842ec: r16 = Instance_GestureDisposition
    //     0x7842ec: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x7842f0: ldr             x16, [x16, #0xeb8]
    // 0x7842f4: stp             x16, x1, [SP, #-0x10]!
    // 0x7842f8: r0 = resolve()
    //     0x7842f8: bl              #0x783a24  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::resolve
    // 0x7842fc: add             SP, SP, #0x10
    // 0x784300: ldr             x16, [fp, #0x18]
    // 0x784304: SaveReg r16
    //     0x784304: str             x16, [SP, #-8]!
    // 0x784308: r0 = stopTimer()
    //     0x784308: bl              #0x540abc  ; [dart:_http] _HttpClientConnection::stopTimer
    // 0x78430c: add             SP, SP, #8
    // 0x784310: b               #0x7843c0
    // 0x784314: mov             x0, x1
    // 0x784318: LoadField: r1 = r0->field_1b
    //     0x784318: ldur            w1, [x0, #0x1b]
    // 0x78431c: DecompressPointer r1
    //     0x78431c: add             x1, x1, HEAP, lsl #32
    // 0x784320: cmp             w1, NULL
    // 0x784324: b.eq            #0x7843e0
    // 0x784328: LoadField: d0 = r1->field_7
    //     0x784328: ldur            d0, [x1, #7]
    // 0x78432c: fmul            d1, d0, d0
    // 0x784330: LoadField: d0 = r1->field_f
    //     0x784330: ldur            d0, [x1, #0xf]
    // 0x784334: fmul            d2, d0, d0
    // 0x784338: fadd            d0, d1, d2
    // 0x78433c: fsqrt           d1, d0
    // 0x784340: LoadField: r1 = r0->field_13
    //     0x784340: ldur            w1, [x0, #0x13]
    // 0x784344: DecompressPointer r1
    //     0x784344: add             x1, x1, HEAP, lsl #32
    // 0x784348: LoadField: r2 = r0->field_7
    //     0x784348: ldur            w2, [x0, #7]
    // 0x78434c: DecompressPointer r2
    //     0x78434c: add             x2, x2, HEAP, lsl #32
    // 0x784350: LoadField: r3 = r1->field_7
    //     0x784350: ldur            x3, [x1, #7]
    // 0x784354: cmp             x3, #2
    // 0x784358: b.gt            #0x784374
    // 0x78435c: cmp             x3, #1
    // 0x784360: b.gt            #0x784374
    // 0x784364: cmp             x3, #0
    // 0x784368: b.le            #0x784374
    // 0x78436c: d0 = 1.000000
    //     0x78436c: fmov            d0, #1.00000000
    // 0x784370: b               #0x7843a0
    // 0x784374: cmp             w2, NULL
    // 0x784378: b.ne            #0x784384
    // 0x78437c: r1 = Null
    //     0x78437c: mov             x1, NULL
    // 0x784380: b               #0x78438c
    // 0x784384: LoadField: r1 = r2->field_7
    //     0x784384: ldur            w1, [x2, #7]
    // 0x784388: DecompressPointer r1
    //     0x784388: add             x1, x1, HEAP, lsl #32
    // 0x78438c: cmp             w1, NULL
    // 0x784390: b.ne            #0x78439c
    // 0x784394: d0 = 18.000000
    //     0x784394: fmov            d0, #18.00000000
    // 0x784398: b               #0x7843a0
    // 0x78439c: LoadField: d0 = r1->field_7
    //     0x78439c: ldur            d0, [x1, #7]
    // 0x7843a0: fcmp            d1, d0
    // 0x7843a4: b.vs            #0x7843c0
    // 0x7843a8: b.le            #0x7843c0
    // 0x7843ac: r16 = Instance_GestureDisposition
    //     0x7843ac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x7843b0: ldr             x16, [x16, #0xed0]
    // 0x7843b4: stp             x16, x0, [SP, #-0x10]!
    // 0x7843b8: r0 = resolve()
    //     0x7843b8: bl              #0x783a24  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::resolve
    // 0x7843bc: add             SP, SP, #0x10
    // 0x7843c0: r0 = Null
    //     0x7843c0: mov             x0, NULL
    // 0x7843c4: LeaveFrame
    //     0x7843c4: mov             SP, fp
    //     0x7843c8: ldp             fp, lr, [SP], #0x10
    // 0x7843cc: ret
    //     0x7843cc: ret             
    // 0x7843d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7843d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7843d4: b               #0x784010
    // 0x7843d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7843d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7843dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7843dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7843e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7843e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _startDrag(/* No info */) {
    // ** addr: 0xbdc5cc, size: 0xd8
    // 0xbdc5cc: EnterFrame
    //     0xbdc5cc: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc5d0: mov             fp, SP
    // 0xbdc5d4: AllocStack(0x18)
    //     0xbdc5d4: sub             SP, SP, #0x18
    // 0xbdc5d8: CheckStackOverflow
    //     0xbdc5d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc5dc: cmp             SP, x16
    //     0xbdc5e0: b.ls            #0xbdc698
    // 0xbdc5e4: ldr             x0, [fp, #0x10]
    // 0xbdc5e8: ldr             x1, [fp, #0x18]
    // 0xbdc5ec: StoreField: r1->field_17 = r0
    //     0xbdc5ec: stur            w0, [x1, #0x17]
    //     0xbdc5f0: ldurb           w16, [x1, #-1]
    //     0xbdc5f4: ldurb           w17, [x0, #-1]
    //     0xbdc5f8: and             x16, x17, x16, lsr #2
    //     0xbdc5fc: tst             x16, HEAP, lsr #32
    //     0xbdc600: b.eq            #0xbdc608
    //     0xbdc604: bl              #0xd6826c
    // 0xbdc608: LoadField: r0 = r1->field_1f
    //     0xbdc608: ldur            w0, [x1, #0x1f]
    // 0xbdc60c: DecompressPointer r0
    //     0xbdc60c: add             x0, x0, HEAP, lsl #32
    // 0xbdc610: stur            x0, [fp, #-0x18]
    // 0xbdc614: LoadField: r2 = r1->field_1b
    //     0xbdc614: ldur            w2, [x1, #0x1b]
    // 0xbdc618: DecompressPointer r2
    //     0xbdc618: add             x2, x2, HEAP, lsl #32
    // 0xbdc61c: stur            x2, [fp, #-0x10]
    // 0xbdc620: cmp             w2, NULL
    // 0xbdc624: b.eq            #0xbdc6a0
    // 0xbdc628: LoadField: r3 = r1->field_b
    //     0xbdc628: ldur            w3, [x1, #0xb]
    // 0xbdc62c: DecompressPointer r3
    //     0xbdc62c: add             x3, x3, HEAP, lsl #32
    // 0xbdc630: stur            x3, [fp, #-8]
    // 0xbdc634: r0 = DragUpdateDetails()
    //     0xbdc634: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0xbdc638: mov             x1, x0
    // 0xbdc63c: ldur            x0, [fp, #-0x18]
    // 0xbdc640: StoreField: r1->field_7 = r0
    //     0xbdc640: stur            w0, [x1, #7]
    // 0xbdc644: ldur            x0, [fp, #-0x10]
    // 0xbdc648: StoreField: r1->field_b = r0
    //     0xbdc648: stur            w0, [x1, #0xb]
    // 0xbdc64c: ldur            x0, [fp, #-8]
    // 0xbdc650: StoreField: r1->field_13 = r0
    //     0xbdc650: stur            w0, [x1, #0x13]
    // 0xbdc654: StoreField: r1->field_17 = r0
    //     0xbdc654: stur            w0, [x1, #0x17]
    // 0xbdc658: ldr             x0, [fp, #0x18]
    // 0xbdc65c: StoreField: r0->field_1b = rNULL
    //     0xbdc65c: stur            NULL, [x0, #0x1b]
    // 0xbdc660: StoreField: r0->field_1f = rNULL
    //     0xbdc660: stur            NULL, [x0, #0x1f]
    // 0xbdc664: ldr             x0, [fp, #0x10]
    // 0xbdc668: r2 = LoadClassIdInstr(r0)
    //     0xbdc668: ldur            x2, [x0, #-1]
    //     0xbdc66c: ubfx            x2, x2, #0xc, #0x14
    // 0xbdc670: stp             x1, x0, [SP, #-0x10]!
    // 0xbdc674: mov             x0, x2
    // 0xbdc678: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbdc678: sub             lr, x0, #1, lsl #12
    //     0xbdc67c: ldr             lr, [x21, lr, lsl #3]
    //     0xbdc680: blr             lr
    // 0xbdc684: add             SP, SP, #0x10
    // 0xbdc688: r0 = Null
    //     0xbdc688: mov             x0, NULL
    // 0xbdc68c: LeaveFrame
    //     0xbdc68c: mov             SP, fp
    //     0xbdc690: ldp             fp, lr, [SP], #0x10
    // 0xbdc694: ret
    //     0xbdc694: ret             
    // 0xbdc698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc69c: b               #0xbdc5e4
    // 0xbdc6a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdc6a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ rejected(/* No info */) {
    // ** addr: 0xcee894, size: 0x18
    // 0xcee894: ldr             x1, [SP]
    // 0xcee898: StoreField: r1->field_1b = rNULL
    //     0xcee898: stur            NULL, [x1, #0x1b]
    // 0xcee89c: StoreField: r1->field_1f = rNULL
    //     0xcee89c: stur            NULL, [x1, #0x1f]
    // 0xcee8a0: StoreField: r1->field_23 = rNULL
    //     0xcee8a0: stur            NULL, [x1, #0x23]
    // 0xcee8a4: r0 = Null
    //     0xcee8a4: mov             x0, NULL
    // 0xcee8a8: ret
    //     0xcee8a8: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0xcf7e78, size: 0x64
    // 0xcf7e78: EnterFrame
    //     0xcf7e78: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7e7c: mov             fp, SP
    // 0xcf7e80: CheckStackOverflow
    //     0xcf7e80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf7e84: cmp             SP, x16
    //     0xcf7e88: b.ls            #0xcf7ed4
    // 0xcf7e8c: ldr             x0, [fp, #0x10]
    // 0xcf7e90: LoadField: r1 = r0->field_23
    //     0xcf7e90: ldur            w1, [x0, #0x23]
    // 0xcf7e94: DecompressPointer r1
    //     0xcf7e94: add             x1, x1, HEAP, lsl #32
    // 0xcf7e98: cmp             w1, NULL
    // 0xcf7e9c: b.ne            #0xcf7ea8
    // 0xcf7ea0: mov             x1, x0
    // 0xcf7ea4: b               #0xcf7ec0
    // 0xcf7ea8: r16 = Instance_GestureDisposition
    //     0xcf7ea8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xcf7eac: ldr             x16, [x16, #0xeb8]
    // 0xcf7eb0: stp             x16, x1, [SP, #-0x10]!
    // 0xcf7eb4: r0 = resolve()
    //     0xcf7eb4: bl              #0xcf7450  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0xcf7eb8: add             SP, SP, #0x10
    // 0xcf7ebc: ldr             x1, [fp, #0x10]
    // 0xcf7ec0: StoreField: r1->field_23 = rNULL
    //     0xcf7ec0: stur            NULL, [x1, #0x23]
    // 0xcf7ec4: r0 = Null
    //     0xcf7ec4: mov             x0, NULL
    // 0xcf7ec8: LeaveFrame
    //     0xcf7ec8: mov             SP, fp
    //     0xcf7ecc: ldp             fp, lr, [SP], #0x10
    // 0xcf7ed0: ret
    //     0xcf7ed0: ret             
    // 0xcf7ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7ed4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7ed8: b               #0xcf7e8c
  }
}

// class id: 2270, size: 0x30, field offset: 0x28
class _DelayedPointerState extends MultiDragPointerState {

  _ _DelayedPointerState(/* No info */) {
    // ** addr: 0x7838b0, size: 0xa8
    // 0x7838b0: EnterFrame
    //     0x7838b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7838b4: mov             fp, SP
    // 0x7838b8: CheckStackOverflow
    //     0x7838b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7838bc: cmp             SP, x16
    //     0x7838c0: b.ls            #0x783950
    // 0x7838c4: ldr             x16, [fp, #0x28]
    // 0x7838c8: ldr             lr, [fp, #0x20]
    // 0x7838cc: stp             lr, x16, [SP, #-0x10]!
    // 0x7838d0: ldr             x16, [fp, #0x18]
    // 0x7838d4: ldr             lr, [fp, #0x10]
    // 0x7838d8: stp             lr, x16, [SP, #-0x10]!
    // 0x7838dc: r0 = MultiDragPointerState()
    //     0x7838dc: bl              #0x7837a0  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::MultiDragPointerState
    // 0x7838e0: add             SP, SP, #0x20
    // 0x7838e4: r1 = 1
    //     0x7838e4: mov             x1, #1
    // 0x7838e8: r0 = AllocateContext()
    //     0x7838e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7838ec: mov             x1, x0
    // 0x7838f0: ldr             x0, [fp, #0x28]
    // 0x7838f4: StoreField: r1->field_f = r0
    //     0x7838f4: stur            w0, [x1, #0xf]
    // 0x7838f8: mov             x2, x1
    // 0x7838fc: r1 = Function '_delayPassed@667470698':.
    //     0x7838fc: add             x1, PP, #0x57, lsl #12  ; [pp+0x57340] AnonymousClosure: (0x783958), in [package:flutter/src/gestures/multidrag.dart] _DelayedPointerState::_delayPassed (0x7839a0)
    //     0x783900: ldr             x1, [x1, #0x340]
    // 0x783904: r0 = AllocateClosure()
    //     0x783904: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x783908: r16 = Instance_Duration
    //     0x783908: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f718] Obj!Duration@b67b11
    //     0x78390c: ldr             x16, [x16, #0x718]
    // 0x783910: stp             x16, NULL, [SP, #-0x10]!
    // 0x783914: SaveReg r0
    //     0x783914: str             x0, [SP, #-8]!
    // 0x783918: r0 = Timer()
    //     0x783918: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x78391c: add             SP, SP, #0x18
    // 0x783920: ldr             x1, [fp, #0x28]
    // 0x783924: StoreField: r1->field_27 = r0
    //     0x783924: stur            w0, [x1, #0x27]
    //     0x783928: ldurb           w16, [x1, #-1]
    //     0x78392c: ldurb           w17, [x0, #-1]
    //     0x783930: and             x16, x17, x16, lsr #2
    //     0x783934: tst             x16, HEAP, lsr #32
    //     0x783938: b.eq            #0x783940
    //     0x78393c: bl              #0xd6826c
    // 0x783940: r0 = Null
    //     0x783940: mov             x0, NULL
    // 0x783944: LeaveFrame
    //     0x783944: mov             SP, fp
    //     0x783948: ldp             fp, lr, [SP], #0x10
    // 0x78394c: ret
    //     0x78394c: ret             
    // 0x783950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783950: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783954: b               #0x7838c4
  }
  [closure] void _delayPassed(dynamic) {
    // ** addr: 0x783958, size: 0x48
    // 0x783958: EnterFrame
    //     0x783958: stp             fp, lr, [SP, #-0x10]!
    //     0x78395c: mov             fp, SP
    // 0x783960: ldr             x0, [fp, #0x10]
    // 0x783964: LoadField: r1 = r0->field_17
    //     0x783964: ldur            w1, [x0, #0x17]
    // 0x783968: DecompressPointer r1
    //     0x783968: add             x1, x1, HEAP, lsl #32
    // 0x78396c: CheckStackOverflow
    //     0x78396c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783970: cmp             SP, x16
    //     0x783974: b.ls            #0x783998
    // 0x783978: LoadField: r0 = r1->field_f
    //     0x783978: ldur            w0, [x1, #0xf]
    // 0x78397c: DecompressPointer r0
    //     0x78397c: add             x0, x0, HEAP, lsl #32
    // 0x783980: SaveReg r0
    //     0x783980: str             x0, [SP, #-8]!
    // 0x783984: r0 = _delayPassed()
    //     0x783984: bl              #0x7839a0  ; [package:flutter/src/gestures/multidrag.dart] _DelayedPointerState::_delayPassed
    // 0x783988: add             SP, SP, #8
    // 0x78398c: LeaveFrame
    //     0x78398c: mov             SP, fp
    //     0x783990: ldp             fp, lr, [SP], #0x10
    // 0x783994: ret
    //     0x783994: ret             
    // 0x783998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783998: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78399c: b               #0x783978
  }
  _ _delayPassed(/* No info */) {
    // ** addr: 0x7839a0, size: 0x84
    // 0x7839a0: EnterFrame
    //     0x7839a0: stp             fp, lr, [SP, #-0x10]!
    //     0x7839a4: mov             fp, SP
    // 0x7839a8: CheckStackOverflow
    //     0x7839a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7839ac: cmp             SP, x16
    //     0x7839b0: b.ls            #0x783a1c
    // 0x7839b4: ldr             x1, [fp, #0x10]
    // 0x7839b8: StoreField: r1->field_27 = rNULL
    //     0x7839b8: stur            NULL, [x1, #0x27]
    // 0x7839bc: LoadField: r0 = r1->field_2b
    //     0x7839bc: ldur            w0, [x1, #0x2b]
    // 0x7839c0: DecompressPointer r0
    //     0x7839c0: add             x0, x0, HEAP, lsl #32
    // 0x7839c4: cmp             w0, NULL
    // 0x7839c8: b.eq            #0x7839f4
    // 0x7839cc: LoadField: r2 = r1->field_b
    //     0x7839cc: ldur            w2, [x1, #0xb]
    // 0x7839d0: DecompressPointer r2
    //     0x7839d0: add             x2, x2, HEAP, lsl #32
    // 0x7839d4: stp             x2, x0, [SP, #-0x10]!
    // 0x7839d8: ClosureCall
    //     0x7839d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7839dc: ldur            x2, [x0, #0x1f]
    //     0x7839e0: blr             x2
    // 0x7839e4: add             SP, SP, #0x10
    // 0x7839e8: ldr             x0, [fp, #0x10]
    // 0x7839ec: StoreField: r0->field_2b = rNULL
    //     0x7839ec: stur            NULL, [x0, #0x2b]
    // 0x7839f0: b               #0x783a0c
    // 0x7839f4: mov             x0, x1
    // 0x7839f8: r16 = Instance_GestureDisposition
    //     0x7839f8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x7839fc: ldr             x16, [x16, #0xed0]
    // 0x783a00: stp             x16, x0, [SP, #-0x10]!
    // 0x783a04: r0 = resolve()
    //     0x783a04: bl              #0x783a24  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::resolve
    // 0x783a08: add             SP, SP, #0x10
    // 0x783a0c: r0 = Null
    //     0x783a0c: mov             x0, NULL
    // 0x783a10: LeaveFrame
    //     0x783a10: mov             SP, fp
    //     0x783a14: ldp             fp, lr, [SP], #0x10
    // 0x783a18: ret
    //     0x783a18: ret             
    // 0x783a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783a1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783a20: b               #0x7839b4
  }
  _ dispose(/* No info */) {
    // ** addr: 0xcf7edc, size: 0x4c
    // 0xcf7edc: EnterFrame
    //     0xcf7edc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7ee0: mov             fp, SP
    // 0xcf7ee4: CheckStackOverflow
    //     0xcf7ee4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf7ee8: cmp             SP, x16
    //     0xcf7eec: b.ls            #0xcf7f20
    // 0xcf7ef0: ldr             x16, [fp, #0x10]
    // 0xcf7ef4: SaveReg r16
    //     0xcf7ef4: str             x16, [SP, #-8]!
    // 0xcf7ef8: r0 = stopTimer()
    //     0xcf7ef8: bl              #0x540abc  ; [dart:_http] _HttpClientConnection::stopTimer
    // 0xcf7efc: add             SP, SP, #8
    // 0xcf7f00: ldr             x16, [fp, #0x10]
    // 0xcf7f04: SaveReg r16
    //     0xcf7f04: str             x16, [SP, #-8]!
    // 0xcf7f08: r0 = dispose()
    //     0xcf7f08: bl              #0xcf7e78  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::dispose
    // 0xcf7f0c: add             SP, SP, #8
    // 0xcf7f10: r0 = Null
    //     0xcf7f10: mov             x0, NULL
    // 0xcf7f14: LeaveFrame
    //     0xcf7f14: mov             SP, fp
    //     0xcf7f18: ldp             fp, lr, [SP], #0x10
    // 0xcf7f1c: ret
    //     0xcf7f1c: ret             
    // 0xcf7f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7f20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7f24: b               #0xcf7ef0
  }
  _ accepted(/* No info */) {
    // ** addr: 0xcf7f7c, size: 0x88
    // 0xcf7f7c: EnterFrame
    //     0xcf7f7c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7f80: mov             fp, SP
    // 0xcf7f84: CheckStackOverflow
    //     0xcf7f84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf7f88: cmp             SP, x16
    //     0xcf7f8c: b.ls            #0xcf7ffc
    // 0xcf7f90: ldr             x1, [fp, #0x18]
    // 0xcf7f94: LoadField: r0 = r1->field_27
    //     0xcf7f94: ldur            w0, [x1, #0x27]
    // 0xcf7f98: DecompressPointer r0
    //     0xcf7f98: add             x0, x0, HEAP, lsl #32
    // 0xcf7f9c: cmp             w0, NULL
    // 0xcf7fa0: b.ne            #0xcf7fcc
    // 0xcf7fa4: LoadField: r0 = r1->field_b
    //     0xcf7fa4: ldur            w0, [x1, #0xb]
    // 0xcf7fa8: DecompressPointer r0
    //     0xcf7fa8: add             x0, x0, HEAP, lsl #32
    // 0xcf7fac: ldr             x16, [fp, #0x10]
    // 0xcf7fb0: stp             x0, x16, [SP, #-0x10]!
    // 0xcf7fb4: ldr             x0, [fp, #0x10]
    // 0xcf7fb8: ClosureCall
    //     0xcf7fb8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcf7fbc: ldur            x2, [x0, #0x1f]
    //     0xcf7fc0: blr             x2
    // 0xcf7fc4: add             SP, SP, #0x10
    // 0xcf7fc8: b               #0xcf7fec
    // 0xcf7fcc: ldr             x0, [fp, #0x10]
    // 0xcf7fd0: StoreField: r1->field_2b = r0
    //     0xcf7fd0: stur            w0, [x1, #0x2b]
    //     0xcf7fd4: ldurb           w16, [x1, #-1]
    //     0xcf7fd8: ldurb           w17, [x0, #-1]
    //     0xcf7fdc: and             x16, x17, x16, lsr #2
    //     0xcf7fe0: tst             x16, HEAP, lsr #32
    //     0xcf7fe4: b.eq            #0xcf7fec
    //     0xcf7fe8: bl              #0xd6826c
    // 0xcf7fec: r0 = Null
    //     0xcf7fec: mov             x0, NULL
    // 0xcf7ff0: LeaveFrame
    //     0xcf7ff0: mov             SP, fp
    //     0xcf7ff4: ldp             fp, lr, [SP], #0x10
    // 0xcf7ff8: ret
    //     0xcf7ff8: ret             
    // 0xcf7ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7ffc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8000: b               #0xcf7f90
  }
}

// class id: 2271, size: 0x28, field offset: 0x28
class _ImmediatePointerState extends MultiDragPointerState {

  _ accepted(/* No info */) {
    // ** addr: 0xcf7f28, size: 0x54
    // 0xcf7f28: EnterFrame
    //     0xcf7f28: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7f2c: mov             fp, SP
    // 0xcf7f30: CheckStackOverflow
    //     0xcf7f30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf7f34: cmp             SP, x16
    //     0xcf7f38: b.ls            #0xcf7f74
    // 0xcf7f3c: ldr             x0, [fp, #0x18]
    // 0xcf7f40: LoadField: r1 = r0->field_b
    //     0xcf7f40: ldur            w1, [x0, #0xb]
    // 0xcf7f44: DecompressPointer r1
    //     0xcf7f44: add             x1, x1, HEAP, lsl #32
    // 0xcf7f48: ldr             x16, [fp, #0x10]
    // 0xcf7f4c: stp             x1, x16, [SP, #-0x10]!
    // 0xcf7f50: ldr             x0, [fp, #0x10]
    // 0xcf7f54: ClosureCall
    //     0xcf7f54: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcf7f58: ldur            x2, [x0, #0x1f]
    //     0xcf7f5c: blr             x2
    // 0xcf7f60: add             SP, SP, #0x10
    // 0xcf7f64: r0 = Null
    //     0xcf7f64: mov             x0, NULL
    // 0xcf7f68: LeaveFrame
    //     0xcf7f68: mov             SP, fp
    //     0xcf7f6c: ldp             fp, lr, [SP], #0x10
    // 0xcf7f70: ret
    //     0xcf7f70: ret             
    // 0xcf7f74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7f74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7f78: b               #0xcf7f3c
  }
}

// class id: 2345, size: 0x1c, field offset: 0x14
abstract class MultiDragGestureRecognizer extends GestureRecognizer {

  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x7834d0, size: 0x2d0
    // 0x7834d0: EnterFrame
    //     0x7834d0: stp             fp, lr, [SP, #-0x10]!
    //     0x7834d4: mov             fp, SP
    // 0x7834d8: AllocStack(0x28)
    //     0x7834d8: sub             SP, SP, #0x28
    // 0x7834dc: CheckStackOverflow
    //     0x7834dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7834e0: cmp             SP, x16
    //     0x7834e4: b.ls            #0x78378c
    // 0x7834e8: ldr             x1, [fp, #0x18]
    // 0x7834ec: r0 = LoadClassIdInstr(r1)
    //     0x7834ec: ldur            x0, [x1, #-1]
    //     0x7834f0: ubfx            x0, x0, #0xc, #0x14
    // 0x7834f4: lsl             x0, x0, #1
    // 0x7834f8: r17 = 4692
    //     0x7834f8: mov             x17, #0x1254
    // 0x7834fc: cmp             w0, w17
    // 0x783500: b.ne            #0x783590
    // 0x783504: ldr             x2, [fp, #0x10]
    // 0x783508: r0 = LoadClassIdInstr(r2)
    //     0x783508: ldur            x0, [x2, #-1]
    //     0x78350c: ubfx            x0, x0, #0xc, #0x14
    // 0x783510: SaveReg r2
    //     0x783510: str             x2, [SP, #-8]!
    // 0x783514: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x783514: sub             lr, x0, #0xfd9
    //     0x783518: ldr             lr, [x21, lr, lsl #3]
    //     0x78351c: blr             lr
    // 0x783520: add             SP, SP, #8
    // 0x783524: mov             x2, x0
    // 0x783528: ldr             x1, [fp, #0x10]
    // 0x78352c: stur            x2, [fp, #-8]
    // 0x783530: r0 = LoadClassIdInstr(r1)
    //     0x783530: ldur            x0, [x1, #-1]
    //     0x783534: ubfx            x0, x0, #0xc, #0x14
    // 0x783538: SaveReg r1
    //     0x783538: str             x1, [SP, #-8]!
    // 0x78353c: r0 = GDT[cid_x0 + -0xf60]()
    //     0x78353c: sub             lr, x0, #0xf60
    //     0x783540: ldr             lr, [x21, lr, lsl #3]
    //     0x783544: blr             lr
    // 0x783548: add             SP, SP, #8
    // 0x78354c: mov             x1, x0
    // 0x783550: ldr             x0, [fp, #0x18]
    // 0x783554: stur            x1, [fp, #-0x18]
    // 0x783558: LoadField: r2 = r0->field_7
    //     0x783558: ldur            w2, [x0, #7]
    // 0x78355c: DecompressPointer r2
    //     0x78355c: add             x2, x2, HEAP, lsl #32
    // 0x783560: stur            x2, [fp, #-0x10]
    // 0x783564: r0 = _DelayedPointerState()
    //     0x783564: bl              #0x783a78  ; Allocate_DelayedPointerStateStub -> _DelayedPointerState (size=0x30)
    // 0x783568: stur            x0, [fp, #-0x20]
    // 0x78356c: ldur            x16, [fp, #-8]
    // 0x783570: stp             x16, x0, [SP, #-0x10]!
    // 0x783574: ldur            x16, [fp, #-0x18]
    // 0x783578: ldur            lr, [fp, #-0x10]
    // 0x78357c: stp             lr, x16, [SP, #-0x10]!
    // 0x783580: r0 = _DelayedPointerState()
    //     0x783580: bl              #0x7838b0  ; [package:flutter/src/gestures/multidrag.dart] _DelayedPointerState::_DelayedPointerState
    // 0x783584: add             SP, SP, #0x20
    // 0x783588: ldur            x3, [fp, #-0x20]
    // 0x78358c: b               #0x783618
    // 0x783590: ldr             x2, [fp, #0x10]
    // 0x783594: r0 = LoadClassIdInstr(r2)
    //     0x783594: ldur            x0, [x2, #-1]
    //     0x783598: ubfx            x0, x0, #0xc, #0x14
    // 0x78359c: SaveReg r2
    //     0x78359c: str             x2, [SP, #-8]!
    // 0x7835a0: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x7835a0: sub             lr, x0, #0xfd9
    //     0x7835a4: ldr             lr, [x21, lr, lsl #3]
    //     0x7835a8: blr             lr
    // 0x7835ac: add             SP, SP, #8
    // 0x7835b0: mov             x2, x0
    // 0x7835b4: ldr             x1, [fp, #0x10]
    // 0x7835b8: stur            x2, [fp, #-8]
    // 0x7835bc: r0 = LoadClassIdInstr(r1)
    //     0x7835bc: ldur            x0, [x1, #-1]
    //     0x7835c0: ubfx            x0, x0, #0xc, #0x14
    // 0x7835c4: SaveReg r1
    //     0x7835c4: str             x1, [SP, #-8]!
    // 0x7835c8: r0 = GDT[cid_x0 + -0xf60]()
    //     0x7835c8: sub             lr, x0, #0xf60
    //     0x7835cc: ldr             lr, [x21, lr, lsl #3]
    //     0x7835d0: blr             lr
    // 0x7835d4: add             SP, SP, #8
    // 0x7835d8: mov             x1, x0
    // 0x7835dc: ldr             x0, [fp, #0x18]
    // 0x7835e0: stur            x1, [fp, #-0x18]
    // 0x7835e4: LoadField: r2 = r0->field_7
    //     0x7835e4: ldur            w2, [x0, #7]
    // 0x7835e8: DecompressPointer r2
    //     0x7835e8: add             x2, x2, HEAP, lsl #32
    // 0x7835ec: stur            x2, [fp, #-0x10]
    // 0x7835f0: r0 = _ImmediatePointerState()
    //     0x7835f0: bl              #0x7838a4  ; Allocate_ImmediatePointerStateStub -> _ImmediatePointerState (size=0x28)
    // 0x7835f4: stur            x0, [fp, #-0x20]
    // 0x7835f8: ldur            x16, [fp, #-8]
    // 0x7835fc: stp             x16, x0, [SP, #-0x10]!
    // 0x783600: ldur            x16, [fp, #-0x18]
    // 0x783604: ldur            lr, [fp, #-0x10]
    // 0x783608: stp             lr, x16, [SP, #-0x10]!
    // 0x78360c: r0 = MultiDragPointerState()
    //     0x78360c: bl              #0x7837a0  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::MultiDragPointerState
    // 0x783610: add             SP, SP, #0x20
    // 0x783614: ldur            x3, [fp, #-0x20]
    // 0x783618: ldr             x1, [fp, #0x18]
    // 0x78361c: ldr             x2, [fp, #0x10]
    // 0x783620: stur            x3, [fp, #-0x10]
    // 0x783624: LoadField: r4 = r1->field_17
    //     0x783624: ldur            w4, [x1, #0x17]
    // 0x783628: DecompressPointer r4
    //     0x783628: add             x4, x4, HEAP, lsl #32
    // 0x78362c: stur            x4, [fp, #-8]
    // 0x783630: cmp             w4, NULL
    // 0x783634: b.eq            #0x783794
    // 0x783638: r0 = LoadClassIdInstr(r2)
    //     0x783638: ldur            x0, [x2, #-1]
    //     0x78363c: ubfx            x0, x0, #0xc, #0x14
    // 0x783640: SaveReg r2
    //     0x783640: str             x2, [SP, #-8]!
    // 0x783644: r0 = GDT[cid_x0 + -0xfff]()
    //     0x783644: sub             lr, x0, #0xfff
    //     0x783648: ldr             lr, [x21, lr, lsl #3]
    //     0x78364c: blr             lr
    // 0x783650: add             SP, SP, #8
    // 0x783654: mov             x2, x0
    // 0x783658: r0 = BoxInt64Instr(r2)
    //     0x783658: sbfiz           x0, x2, #1, #0x1f
    //     0x78365c: cmp             x2, x0, asr #1
    //     0x783660: b.eq            #0x78366c
    //     0x783664: bl              #0xd69bb8
    //     0x783668: stur            x2, [x0, #7]
    // 0x78366c: ldur            x16, [fp, #-8]
    // 0x783670: stp             x0, x16, [SP, #-0x10]!
    // 0x783674: ldur            x16, [fp, #-0x10]
    // 0x783678: SaveReg r16
    //     0x783678: str             x16, [SP, #-8]!
    // 0x78367c: r0 = []=()
    //     0x78367c: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x783680: add             SP, SP, #0x18
    // 0x783684: r0 = LoadStaticField(0xd54)
    //     0x783684: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x783688: ldr             x0, [x0, #0x1aa8]
    // 0x78368c: cmp             w0, NULL
    // 0x783690: b.eq            #0x783798
    // 0x783694: LoadField: r1 = r0->field_13
    //     0x783694: ldur            w1, [x0, #0x13]
    // 0x783698: DecompressPointer r1
    //     0x783698: add             x1, x1, HEAP, lsl #32
    // 0x78369c: ldr             x2, [fp, #0x10]
    // 0x7836a0: stur            x1, [fp, #-8]
    // 0x7836a4: r0 = LoadClassIdInstr(r2)
    //     0x7836a4: ldur            x0, [x2, #-1]
    //     0x7836a8: ubfx            x0, x0, #0xc, #0x14
    // 0x7836ac: SaveReg r2
    //     0x7836ac: str             x2, [SP, #-8]!
    // 0x7836b0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x7836b0: sub             lr, x0, #0xfff
    //     0x7836b4: ldr             lr, [x21, lr, lsl #3]
    //     0x7836b8: blr             lr
    // 0x7836bc: add             SP, SP, #8
    // 0x7836c0: stur            x0, [fp, #-0x28]
    // 0x7836c4: r1 = 1
    //     0x7836c4: mov             x1, #1
    // 0x7836c8: r0 = AllocateContext()
    //     0x7836c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7836cc: mov             x1, x0
    // 0x7836d0: ldr             x0, [fp, #0x18]
    // 0x7836d4: StoreField: r1->field_f = r0
    //     0x7836d4: stur            w0, [x1, #0xf]
    // 0x7836d8: mov             x2, x1
    // 0x7836dc: r1 = Function '_handleEvent@667470698':.
    //     0x7836dc: add             x1, PP, #0x56, lsl #12  ; [pp+0x56aa8] AnonymousClosure: (0x783a84), in [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_handleEvent (0x783ad0)
    //     0x7836e0: ldr             x1, [x1, #0xaa8]
    // 0x7836e4: r0 = AllocateClosure()
    //     0x7836e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7836e8: ldur            x16, [fp, #-8]
    // 0x7836ec: SaveReg r16
    //     0x7836ec: str             x16, [SP, #-8]!
    // 0x7836f0: ldur            x1, [fp, #-0x28]
    // 0x7836f4: stp             x0, x1, [SP, #-0x10]!
    // 0x7836f8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7836f8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7836fc: r0 = addRoute()
    //     0x7836fc: bl              #0x711788  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addRoute
    // 0x783700: add             SP, SP, #0x18
    // 0x783704: r0 = LoadStaticField(0xd54)
    //     0x783704: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x783708: ldr             x0, [x0, #0x1aa8]
    // 0x78370c: cmp             w0, NULL
    // 0x783710: b.eq            #0x78379c
    // 0x783714: LoadField: r1 = r0->field_17
    //     0x783714: ldur            w1, [x0, #0x17]
    // 0x783718: DecompressPointer r1
    //     0x783718: add             x1, x1, HEAP, lsl #32
    // 0x78371c: ldr             x0, [fp, #0x10]
    // 0x783720: stur            x1, [fp, #-8]
    // 0x783724: r2 = LoadClassIdInstr(r0)
    //     0x783724: ldur            x2, [x0, #-1]
    //     0x783728: ubfx            x2, x2, #0xc, #0x14
    // 0x78372c: SaveReg r0
    //     0x78372c: str             x0, [SP, #-8]!
    // 0x783730: mov             x0, x2
    // 0x783734: r0 = GDT[cid_x0 + -0xfff]()
    //     0x783734: sub             lr, x0, #0xfff
    //     0x783738: ldr             lr, [x21, lr, lsl #3]
    //     0x78373c: blr             lr
    // 0x783740: add             SP, SP, #8
    // 0x783744: ldur            x16, [fp, #-8]
    // 0x783748: stp             x0, x16, [SP, #-0x10]!
    // 0x78374c: ldr             x16, [fp, #0x18]
    // 0x783750: SaveReg r16
    //     0x783750: str             x16, [SP, #-8]!
    // 0x783754: r0 = add()
    //     0x783754: bl              #0x7112b0  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::add
    // 0x783758: add             SP, SP, #0x18
    // 0x78375c: ldur            x1, [fp, #-0x10]
    // 0x783760: StoreField: r1->field_23 = r0
    //     0x783760: stur            w0, [x1, #0x23]
    //     0x783764: ldurb           w16, [x1, #-1]
    //     0x783768: ldurb           w17, [x0, #-1]
    //     0x78376c: and             x16, x17, x16, lsr #2
    //     0x783770: tst             x16, HEAP, lsr #32
    //     0x783774: b.eq            #0x78377c
    //     0x783778: bl              #0xd6826c
    // 0x78377c: r0 = Null
    //     0x78377c: mov             x0, NULL
    // 0x783780: LeaveFrame
    //     0x783780: mov             SP, fp
    //     0x783784: ldp             fp, lr, [SP], #0x10
    // 0x783788: ret
    //     0x783788: ret             
    // 0x78378c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78378c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783790: b               #0x7834e8
    // 0x783794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783794: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x783798: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783798: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78379c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78379c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x783a84, size: 0x4c
    // 0x783a84: EnterFrame
    //     0x783a84: stp             fp, lr, [SP, #-0x10]!
    //     0x783a88: mov             fp, SP
    // 0x783a8c: ldr             x0, [fp, #0x18]
    // 0x783a90: LoadField: r1 = r0->field_17
    //     0x783a90: ldur            w1, [x0, #0x17]
    // 0x783a94: DecompressPointer r1
    //     0x783a94: add             x1, x1, HEAP, lsl #32
    // 0x783a98: CheckStackOverflow
    //     0x783a98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783a9c: cmp             SP, x16
    //     0x783aa0: b.ls            #0x783ac8
    // 0x783aa4: LoadField: r0 = r1->field_f
    //     0x783aa4: ldur            w0, [x1, #0xf]
    // 0x783aa8: DecompressPointer r0
    //     0x783aa8: add             x0, x0, HEAP, lsl #32
    // 0x783aac: ldr             x16, [fp, #0x10]
    // 0x783ab0: stp             x16, x0, [SP, #-0x10]!
    // 0x783ab4: r0 = _handleEvent()
    //     0x783ab4: bl              #0x783ad0  ; [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_handleEvent
    // 0x783ab8: add             SP, SP, #0x10
    // 0x783abc: LeaveFrame
    //     0x783abc: mov             SP, fp
    //     0x783ac0: ldp             fp, lr, [SP], #0x10
    // 0x783ac4: ret
    //     0x783ac4: ret             
    // 0x783ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783ac8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783acc: b               #0x783aa4
  }
  _ _handleEvent(/* No info */) {
    // ** addr: 0x783ad0, size: 0x2a4
    // 0x783ad0: EnterFrame
    //     0x783ad0: stp             fp, lr, [SP, #-0x10]!
    //     0x783ad4: mov             fp, SP
    // 0x783ad8: AllocStack(0x8)
    //     0x783ad8: sub             SP, SP, #8
    // 0x783adc: CheckStackOverflow
    //     0x783adc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783ae0: cmp             SP, x16
    //     0x783ae4: b.ls            #0x783d64
    // 0x783ae8: ldr             x1, [fp, #0x18]
    // 0x783aec: LoadField: r2 = r1->field_17
    //     0x783aec: ldur            w2, [x1, #0x17]
    // 0x783af0: DecompressPointer r2
    //     0x783af0: add             x2, x2, HEAP, lsl #32
    // 0x783af4: stur            x2, [fp, #-8]
    // 0x783af8: cmp             w2, NULL
    // 0x783afc: b.eq            #0x783d6c
    // 0x783b00: ldr             x3, [fp, #0x10]
    // 0x783b04: r0 = LoadClassIdInstr(r3)
    //     0x783b04: ldur            x0, [x3, #-1]
    //     0x783b08: ubfx            x0, x0, #0xc, #0x14
    // 0x783b0c: SaveReg r3
    //     0x783b0c: str             x3, [SP, #-8]!
    // 0x783b10: r0 = GDT[cid_x0 + -0xfff]()
    //     0x783b10: sub             lr, x0, #0xfff
    //     0x783b14: ldr             lr, [x21, lr, lsl #3]
    //     0x783b18: blr             lr
    // 0x783b1c: add             SP, SP, #8
    // 0x783b20: mov             x2, x0
    // 0x783b24: r0 = BoxInt64Instr(r2)
    //     0x783b24: sbfiz           x0, x2, #1, #0x1f
    //     0x783b28: cmp             x2, x0, asr #1
    //     0x783b2c: b.eq            #0x783b38
    //     0x783b30: bl              #0xd69bb8
    //     0x783b34: stur            x2, [x0, #7]
    // 0x783b38: ldur            x16, [fp, #-8]
    // 0x783b3c: stp             x0, x16, [SP, #-0x10]!
    // 0x783b40: r0 = _getValueOrData()
    //     0x783b40: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x783b44: add             SP, SP, #0x10
    // 0x783b48: mov             x1, x0
    // 0x783b4c: ldur            x0, [fp, #-8]
    // 0x783b50: LoadField: r2 = r0->field_f
    //     0x783b50: ldur            w2, [x0, #0xf]
    // 0x783b54: DecompressPointer r2
    //     0x783b54: add             x2, x2, HEAP, lsl #32
    // 0x783b58: cmp             w2, w1
    // 0x783b5c: b.ne            #0x783b68
    // 0x783b60: r3 = Null
    //     0x783b60: mov             x3, NULL
    // 0x783b64: b               #0x783b6c
    // 0x783b68: mov             x3, x1
    // 0x783b6c: stur            x3, [fp, #-8]
    // 0x783b70: cmp             w3, NULL
    // 0x783b74: b.eq            #0x783d70
    // 0x783b78: ldr             x0, [fp, #0x10]
    // 0x783b7c: r2 = Null
    //     0x783b7c: mov             x2, NULL
    // 0x783b80: r1 = Null
    //     0x783b80: mov             x1, NULL
    // 0x783b84: cmp             w0, NULL
    // 0x783b88: b.eq            #0x783ba8
    // 0x783b8c: branchIfSmi(r0, 0x783ba8)
    //     0x783b8c: tbz             w0, #0, #0x783ba8
    // 0x783b90: r3 = LoadClassIdInstr(r0)
    //     0x783b90: ldur            x3, [x0, #-1]
    //     0x783b94: ubfx            x3, x3, #0xc, #0x14
    // 0x783b98: cmp             x3, #0x908
    // 0x783b9c: b.eq            #0x783bb0
    // 0x783ba0: cmp             x3, #0xb3f
    // 0x783ba4: b.eq            #0x783bb0
    // 0x783ba8: r0 = false
    //     0x783ba8: add             x0, NULL, #0x30  ; false
    // 0x783bac: b               #0x783bb4
    // 0x783bb0: r0 = true
    //     0x783bb0: add             x0, NULL, #0x20  ; true
    // 0x783bb4: tbnz            w0, #4, #0x783bd0
    // 0x783bb8: ldur            x16, [fp, #-8]
    // 0x783bbc: ldr             lr, [fp, #0x10]
    // 0x783bc0: stp             lr, x16, [SP, #-0x10]!
    // 0x783bc4: r0 = _move()
    //     0x783bc4: bl              #0x783ff8  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::_move
    // 0x783bc8: add             SP, SP, #0x10
    // 0x783bcc: b               #0x783d54
    // 0x783bd0: ldr             x0, [fp, #0x10]
    // 0x783bd4: r2 = Null
    //     0x783bd4: mov             x2, NULL
    // 0x783bd8: r1 = Null
    //     0x783bd8: mov             x1, NULL
    // 0x783bdc: cmp             w0, NULL
    // 0x783be0: b.eq            #0x783c00
    // 0x783be4: branchIfSmi(r0, 0x783c00)
    //     0x783be4: tbz             w0, #0, #0x783c00
    // 0x783be8: r3 = LoadClassIdInstr(r0)
    //     0x783be8: ldur            x3, [x0, #-1]
    //     0x783bec: ubfx            x3, x3, #0xc, #0x14
    // 0x783bf0: cmp             x3, #0x906
    // 0x783bf4: b.eq            #0x783c08
    // 0x783bf8: cmp             x3, #0xb3d
    // 0x783bfc: b.eq            #0x783c08
    // 0x783c00: r0 = false
    //     0x783c00: add             x0, NULL, #0x30  ; false
    // 0x783c04: b               #0x783c0c
    // 0x783c08: r0 = true
    //     0x783c08: add             x0, NULL, #0x20  ; true
    // 0x783c0c: tbnz            w0, #4, #0x783c70
    // 0x783c10: ldr             x0, [fp, #0x10]
    // 0x783c14: ldur            x16, [fp, #-8]
    // 0x783c18: SaveReg r16
    //     0x783c18: str             x16, [SP, #-8]!
    // 0x783c1c: r0 = _up()
    //     0x783c1c: bl              #0x783f48  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::_up
    // 0x783c20: add             SP, SP, #8
    // 0x783c24: ldr             x3, [fp, #0x10]
    // 0x783c28: r0 = LoadClassIdInstr(r3)
    //     0x783c28: ldur            x0, [x3, #-1]
    //     0x783c2c: ubfx            x0, x0, #0xc, #0x14
    // 0x783c30: SaveReg r3
    //     0x783c30: str             x3, [SP, #-8]!
    // 0x783c34: r0 = GDT[cid_x0 + -0xfff]()
    //     0x783c34: sub             lr, x0, #0xfff
    //     0x783c38: ldr             lr, [x21, lr, lsl #3]
    //     0x783c3c: blr             lr
    // 0x783c40: add             SP, SP, #8
    // 0x783c44: mov             x2, x0
    // 0x783c48: r0 = BoxInt64Instr(r2)
    //     0x783c48: sbfiz           x0, x2, #1, #0x1f
    //     0x783c4c: cmp             x2, x0, asr #1
    //     0x783c50: b.eq            #0x783c5c
    //     0x783c54: bl              #0xd69bb8
    //     0x783c58: stur            x2, [x0, #7]
    // 0x783c5c: ldr             x16, [fp, #0x18]
    // 0x783c60: stp             x0, x16, [SP, #-0x10]!
    // 0x783c64: r0 = _removeState()
    //     0x783c64: bl              #0x783de0  ; [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_removeState
    // 0x783c68: add             SP, SP, #0x10
    // 0x783c6c: b               #0x783d54
    // 0x783c70: ldr             x3, [fp, #0x10]
    // 0x783c74: mov             x0, x3
    // 0x783c78: r2 = Null
    //     0x783c78: mov             x2, NULL
    // 0x783c7c: r1 = Null
    //     0x783c7c: mov             x1, NULL
    // 0x783c80: cmp             w0, NULL
    // 0x783c84: b.eq            #0x783ca4
    // 0x783c88: branchIfSmi(r0, 0x783ca4)
    //     0x783c88: tbz             w0, #0, #0x783ca4
    // 0x783c8c: r3 = LoadClassIdInstr(r0)
    //     0x783c8c: ldur            x3, [x0, #-1]
    //     0x783c90: ubfx            x3, x3, #0xc, #0x14
    // 0x783c94: cmp             x3, #0x8f8
    // 0x783c98: b.eq            #0x783cac
    // 0x783c9c: cmp             x3, #0xb35
    // 0x783ca0: b.eq            #0x783cac
    // 0x783ca4: r0 = false
    //     0x783ca4: add             x0, NULL, #0x30  ; false
    // 0x783ca8: b               #0x783cb0
    // 0x783cac: r0 = true
    //     0x783cac: add             x0, NULL, #0x20  ; true
    // 0x783cb0: tbnz            w0, #4, #0x783d18
    // 0x783cb4: ldr             x0, [fp, #0x10]
    // 0x783cb8: ldur            x16, [fp, #-8]
    // 0x783cbc: SaveReg r16
    //     0x783cbc: str             x16, [SP, #-8]!
    // 0x783cc0: r0 = _cancel()
    //     0x783cc0: bl              #0x783d74  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::_cancel
    // 0x783cc4: add             SP, SP, #8
    // 0x783cc8: ldr             x0, [fp, #0x10]
    // 0x783ccc: r1 = LoadClassIdInstr(r0)
    //     0x783ccc: ldur            x1, [x0, #-1]
    //     0x783cd0: ubfx            x1, x1, #0xc, #0x14
    // 0x783cd4: SaveReg r0
    //     0x783cd4: str             x0, [SP, #-8]!
    // 0x783cd8: mov             x0, x1
    // 0x783cdc: r0 = GDT[cid_x0 + -0xfff]()
    //     0x783cdc: sub             lr, x0, #0xfff
    //     0x783ce0: ldr             lr, [x21, lr, lsl #3]
    //     0x783ce4: blr             lr
    // 0x783ce8: add             SP, SP, #8
    // 0x783cec: mov             x2, x0
    // 0x783cf0: r0 = BoxInt64Instr(r2)
    //     0x783cf0: sbfiz           x0, x2, #1, #0x1f
    //     0x783cf4: cmp             x2, x0, asr #1
    //     0x783cf8: b.eq            #0x783d04
    //     0x783cfc: bl              #0xd69bb8
    //     0x783d00: stur            x2, [x0, #7]
    // 0x783d04: ldr             x16, [fp, #0x18]
    // 0x783d08: stp             x0, x16, [SP, #-0x10]!
    // 0x783d0c: r0 = _removeState()
    //     0x783d0c: bl              #0x783de0  ; [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_removeState
    // 0x783d10: add             SP, SP, #0x10
    // 0x783d14: b               #0x783d54
    // 0x783d18: ldr             x0, [fp, #0x10]
    // 0x783d1c: r2 = Null
    //     0x783d1c: mov             x2, NULL
    // 0x783d20: r1 = Null
    //     0x783d20: mov             x1, NULL
    // 0x783d24: cmp             w0, NULL
    // 0x783d28: b.eq            #0x783d48
    // 0x783d2c: branchIfSmi(r0, 0x783d48)
    //     0x783d2c: tbz             w0, #0, #0x783d48
    // 0x783d30: r3 = LoadClassIdInstr(r0)
    //     0x783d30: ldur            x3, [x0, #-1]
    //     0x783d34: ubfx            x3, x3, #0xc, #0x14
    // 0x783d38: cmp             x3, #0x90a
    // 0x783d3c: b.eq            #0x783d50
    // 0x783d40: cmp             x3, #0xb41
    // 0x783d44: b.eq            #0x783d50
    // 0x783d48: r0 = false
    //     0x783d48: add             x0, NULL, #0x30  ; false
    // 0x783d4c: b               #0x783d54
    // 0x783d50: r0 = true
    //     0x783d50: add             x0, NULL, #0x20  ; true
    // 0x783d54: r0 = Null
    //     0x783d54: mov             x0, NULL
    // 0x783d58: LeaveFrame
    //     0x783d58: mov             SP, fp
    //     0x783d5c: ldp             fp, lr, [SP], #0x10
    // 0x783d60: ret
    //     0x783d60: ret             
    // 0x783d64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783d64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783d68: b               #0x783ae8
    // 0x783d6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783d6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x783d70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783d70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _removeState(/* No info */) {
    // ** addr: 0x783de0, size: 0x11c
    // 0x783de0: EnterFrame
    //     0x783de0: stp             fp, lr, [SP, #-0x10]!
    //     0x783de4: mov             fp, SP
    // 0x783de8: AllocStack(0x10)
    //     0x783de8: sub             SP, SP, #0x10
    // 0x783dec: CheckStackOverflow
    //     0x783dec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783df0: cmp             SP, x16
    //     0x783df4: b.ls            #0x783ee8
    // 0x783df8: ldr             x0, [fp, #0x18]
    // 0x783dfc: LoadField: r1 = r0->field_17
    //     0x783dfc: ldur            w1, [x0, #0x17]
    // 0x783e00: DecompressPointer r1
    //     0x783e00: add             x1, x1, HEAP, lsl #32
    // 0x783e04: cmp             w1, NULL
    // 0x783e08: b.ne            #0x783e1c
    // 0x783e0c: r0 = Null
    //     0x783e0c: mov             x0, NULL
    // 0x783e10: LeaveFrame
    //     0x783e10: mov             SP, fp
    //     0x783e14: ldp             fp, lr, [SP], #0x10
    // 0x783e18: ret
    //     0x783e18: ret             
    // 0x783e1c: ldr             x1, [fp, #0x10]
    // 0x783e20: r2 = LoadStaticField(0xd54)
    //     0x783e20: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0x783e24: ldr             x2, [x2, #0x1aa8]
    // 0x783e28: cmp             w2, NULL
    // 0x783e2c: b.eq            #0x783ef0
    // 0x783e30: LoadField: r3 = r2->field_13
    //     0x783e30: ldur            w3, [x2, #0x13]
    // 0x783e34: DecompressPointer r3
    //     0x783e34: add             x3, x3, HEAP, lsl #32
    // 0x783e38: stur            x3, [fp, #-8]
    // 0x783e3c: r1 = 1
    //     0x783e3c: mov             x1, #1
    // 0x783e40: r0 = AllocateContext()
    //     0x783e40: bl              #0xd68aa4  ; AllocateContextStub
    // 0x783e44: mov             x1, x0
    // 0x783e48: ldr             x0, [fp, #0x18]
    // 0x783e4c: StoreField: r1->field_f = r0
    //     0x783e4c: stur            w0, [x1, #0xf]
    // 0x783e50: ldr             x3, [fp, #0x10]
    // 0x783e54: r4 = LoadInt32Instr(r3)
    //     0x783e54: sbfx            x4, x3, #1, #0x1f
    //     0x783e58: tbz             w3, #0, #0x783e60
    //     0x783e5c: ldur            x4, [x3, #7]
    // 0x783e60: mov             x2, x1
    // 0x783e64: stur            x4, [fp, #-0x10]
    // 0x783e68: r1 = Function '_handleEvent@667470698':.
    //     0x783e68: add             x1, PP, #0x56, lsl #12  ; [pp+0x56aa8] AnonymousClosure: (0x783a84), in [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_handleEvent (0x783ad0)
    //     0x783e6c: ldr             x1, [x1, #0xaa8]
    // 0x783e70: r0 = AllocateClosure()
    //     0x783e70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x783e74: ldur            x16, [fp, #-8]
    // 0x783e78: SaveReg r16
    //     0x783e78: str             x16, [SP, #-8]!
    // 0x783e7c: ldur            x1, [fp, #-0x10]
    // 0x783e80: stp             x0, x1, [SP, #-0x10]!
    // 0x783e84: r0 = removeRoute()
    //     0x783e84: bl              #0x7134d4  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::removeRoute
    // 0x783e88: add             SP, SP, #0x18
    // 0x783e8c: ldr             x0, [fp, #0x18]
    // 0x783e90: LoadField: r1 = r0->field_17
    //     0x783e90: ldur            w1, [x0, #0x17]
    // 0x783e94: DecompressPointer r1
    //     0x783e94: add             x1, x1, HEAP, lsl #32
    // 0x783e98: cmp             w1, NULL
    // 0x783e9c: b.eq            #0x783ef4
    // 0x783ea0: ldr             x16, [fp, #0x10]
    // 0x783ea4: stp             x16, x1, [SP, #-0x10]!
    // 0x783ea8: r0 = remove()
    //     0x783ea8: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x783eac: add             SP, SP, #0x10
    // 0x783eb0: cmp             w0, NULL
    // 0x783eb4: b.eq            #0x783ef8
    // 0x783eb8: r1 = LoadClassIdInstr(r0)
    //     0x783eb8: ldur            x1, [x0, #-1]
    //     0x783ebc: ubfx            x1, x1, #0xc, #0x14
    // 0x783ec0: SaveReg r0
    //     0x783ec0: str             x0, [SP, #-8]!
    // 0x783ec4: mov             x0, x1
    // 0x783ec8: r0 = GDT[cid_x0 + -0xfeb]()
    //     0x783ec8: sub             lr, x0, #0xfeb
    //     0x783ecc: ldr             lr, [x21, lr, lsl #3]
    //     0x783ed0: blr             lr
    // 0x783ed4: add             SP, SP, #8
    // 0x783ed8: r0 = Null
    //     0x783ed8: mov             x0, NULL
    // 0x783edc: LeaveFrame
    //     0x783edc: mov             SP, fp
    //     0x783ee0: ldp             fp, lr, [SP], #0x10
    // 0x783ee4: ret
    //     0x783ee4: ret             
    // 0x783ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783ee8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783eec: b               #0x783df8
    // 0x783ef0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783ef0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x783ef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783ef4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x783ef8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x783ef8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _removeState(dynamic, int) {
    // ** addr: 0x783efc, size: 0x4c
    // 0x783efc: EnterFrame
    //     0x783efc: stp             fp, lr, [SP, #-0x10]!
    //     0x783f00: mov             fp, SP
    // 0x783f04: ldr             x0, [fp, #0x18]
    // 0x783f08: LoadField: r1 = r0->field_17
    //     0x783f08: ldur            w1, [x0, #0x17]
    // 0x783f0c: DecompressPointer r1
    //     0x783f0c: add             x1, x1, HEAP, lsl #32
    // 0x783f10: CheckStackOverflow
    //     0x783f10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x783f14: cmp             SP, x16
    //     0x783f18: b.ls            #0x783f40
    // 0x783f1c: LoadField: r0 = r1->field_f
    //     0x783f1c: ldur            w0, [x1, #0xf]
    // 0x783f20: DecompressPointer r0
    //     0x783f20: add             x0, x0, HEAP, lsl #32
    // 0x783f24: ldr             x16, [fp, #0x10]
    // 0x783f28: stp             x16, x0, [SP, #-0x10]!
    // 0x783f2c: r0 = _removeState()
    //     0x783f2c: bl              #0x783de0  ; [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_removeState
    // 0x783f30: add             SP, SP, #0x10
    // 0x783f34: LeaveFrame
    //     0x783f34: mov             SP, fp
    //     0x783f38: ldp             fp, lr, [SP], #0x10
    // 0x783f3c: ret
    //     0x783f3c: ret             
    // 0x783f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x783f40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x783f44: b               #0x783f1c
  }
  _ MultiDragGestureRecognizer(/* No info */) {
    // ** addr: 0x995fbc, size: 0x78
    // 0x995fbc: EnterFrame
    //     0x995fbc: stp             fp, lr, [SP, #-0x10]!
    //     0x995fc0: mov             fp, SP
    // 0x995fc4: CheckStackOverflow
    //     0x995fc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x995fc8: cmp             SP, x16
    //     0x995fcc: b.ls            #0x99602c
    // 0x995fd0: r16 = <int, MultiDragPointerState>
    //     0x995fd0: add             x16, PP, #0x56, lsl #12  ; [pp+0x56ac0] TypeArguments: <int, MultiDragPointerState>
    //     0x995fd4: ldr             x16, [x16, #0xac0]
    // 0x995fd8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x995fdc: stp             lr, x16, [SP, #-0x10]!
    // 0x995fe0: r0 = Map._fromLiteral()
    //     0x995fe0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x995fe4: add             SP, SP, #0x10
    // 0x995fe8: ldr             x1, [fp, #0x10]
    // 0x995fec: StoreField: r1->field_17 = r0
    //     0x995fec: stur            w0, [x1, #0x17]
    //     0x995ff0: tbz             w0, #0, #0x99600c
    //     0x995ff4: ldurb           w16, [x1, #-1]
    //     0x995ff8: ldurb           w17, [x0, #-1]
    //     0x995ffc: and             x16, x17, x16, lsr #2
    //     0x996000: tst             x16, HEAP, lsr #32
    //     0x996004: b.eq            #0x99600c
    //     0x996008: bl              #0xd6826c
    // 0x99600c: stp             NULL, x1, [SP, #-0x10]!
    // 0x996010: SaveReg rNULL
    //     0x996010: str             NULL, [SP, #-8]!
    // 0x996014: r0 = GestureRecognizer()
    //     0x996014: bl              #0x6d4060  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::GestureRecognizer
    // 0x996018: add             SP, SP, #0x18
    // 0x99601c: r0 = Null
    //     0x99601c: mov             x0, NULL
    // 0x996020: LeaveFrame
    //     0x996020: mov             SP, fp
    //     0x996024: ldp             fp, lr, [SP], #0x10
    // 0x996028: ret
    //     0x996028: ret             
    // 0x99602c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x99602c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x996030: b               #0x995fd0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbd95c8, size: 0xc0
    // 0xbd95c8: EnterFrame
    //     0xbd95c8: stp             fp, lr, [SP, #-0x10]!
    //     0xbd95cc: mov             fp, SP
    // 0xbd95d0: AllocStack(0x8)
    //     0xbd95d0: sub             SP, SP, #8
    // 0xbd95d4: CheckStackOverflow
    //     0xbd95d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd95d8: cmp             SP, x16
    //     0xbd95dc: b.ls            #0xbd967c
    // 0xbd95e0: ldr             x0, [fp, #0x10]
    // 0xbd95e4: LoadField: r1 = r0->field_17
    //     0xbd95e4: ldur            w1, [x0, #0x17]
    // 0xbd95e8: DecompressPointer r1
    //     0xbd95e8: add             x1, x1, HEAP, lsl #32
    // 0xbd95ec: cmp             w1, NULL
    // 0xbd95f0: b.eq            #0xbd9684
    // 0xbd95f4: SaveReg r1
    //     0xbd95f4: str             x1, [SP, #-8]!
    // 0xbd95f8: r0 = keys()
    //     0xbd95f8: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0xbd95fc: add             SP, SP, #8
    // 0xbd9600: SaveReg r0
    //     0xbd9600: str             x0, [SP, #-8]!
    // 0xbd9604: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xbd9604: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xbd9608: r0 = toList()
    //     0xbd9608: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xbd960c: add             SP, SP, #8
    // 0xbd9610: stur            x0, [fp, #-8]
    // 0xbd9614: r1 = 1
    //     0xbd9614: mov             x1, #1
    // 0xbd9618: r0 = AllocateContext()
    //     0xbd9618: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbd961c: mov             x1, x0
    // 0xbd9620: ldr             x0, [fp, #0x10]
    // 0xbd9624: StoreField: r1->field_f = r0
    //     0xbd9624: stur            w0, [x1, #0xf]
    // 0xbd9628: mov             x2, x1
    // 0xbd962c: r1 = Function '_removeState@667470698':.
    //     0xbd962c: add             x1, PP, #0x56, lsl #12  ; [pp+0x56aa0] AnonymousClosure: (0x783efc), in [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_removeState (0x783de0)
    //     0xbd9630: ldr             x1, [x1, #0xaa0]
    // 0xbd9634: r0 = AllocateClosure()
    //     0xbd9634: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbd9638: mov             x1, x0
    // 0xbd963c: ldur            x0, [fp, #-8]
    // 0xbd9640: r2 = LoadClassIdInstr(r0)
    //     0xbd9640: ldur            x2, [x0, #-1]
    //     0xbd9644: ubfx            x2, x2, #0xc, #0x14
    // 0xbd9648: stp             x1, x0, [SP, #-0x10]!
    // 0xbd964c: mov             x0, x2
    // 0xbd9650: r0 = GDT[cid_x0 + 0xce6e]()
    //     0xbd9650: mov             x17, #0xce6e
    //     0xbd9654: add             lr, x0, x17
    //     0xbd9658: ldr             lr, [x21, lr, lsl #3]
    //     0xbd965c: blr             lr
    // 0xbd9660: add             SP, SP, #0x10
    // 0xbd9664: ldr             x1, [fp, #0x10]
    // 0xbd9668: StoreField: r1->field_17 = rNULL
    //     0xbd9668: stur            NULL, [x1, #0x17]
    // 0xbd966c: r0 = Null
    //     0xbd966c: mov             x0, NULL
    // 0xbd9670: LeaveFrame
    //     0xbd9670: mov             SP, fp
    //     0xbd9674: ldp             fp, lr, [SP], #0x10
    // 0xbd9678: ret
    //     0xbd9678: ret             
    // 0xbd967c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd967c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd9680: b               #0xbd95e0
    // 0xbd9684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd9684: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdc324, size: 0x100
    // 0xbdc324: EnterFrame
    //     0xbdc324: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc328: mov             fp, SP
    // 0xbdc32c: AllocStack(0x10)
    //     0xbdc32c: sub             SP, SP, #0x10
    // 0xbdc330: CheckStackOverflow
    //     0xbdc330: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc334: cmp             SP, x16
    //     0xbdc338: b.ls            #0xbdc418
    // 0xbdc33c: r1 = 2
    //     0xbdc33c: mov             x1, #2
    // 0xbdc340: r0 = AllocateContext()
    //     0xbdc340: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbdc344: mov             x3, x0
    // 0xbdc348: ldr             x2, [fp, #0x18]
    // 0xbdc34c: stur            x3, [fp, #-0x10]
    // 0xbdc350: StoreField: r3->field_f = r2
    //     0xbdc350: stur            w2, [x3, #0xf]
    // 0xbdc354: ldr             x4, [fp, #0x10]
    // 0xbdc358: r0 = BoxInt64Instr(r4)
    //     0xbdc358: sbfiz           x0, x4, #1, #0x1f
    //     0xbdc35c: cmp             x4, x0, asr #1
    //     0xbdc360: b.eq            #0xbdc36c
    //     0xbdc364: bl              #0xd69bb8
    //     0xbdc368: stur            x4, [x0, #7]
    // 0xbdc36c: StoreField: r3->field_13 = r0
    //     0xbdc36c: stur            w0, [x3, #0x13]
    // 0xbdc370: LoadField: r1 = r2->field_17
    //     0xbdc370: ldur            w1, [x2, #0x17]
    // 0xbdc374: DecompressPointer r1
    //     0xbdc374: add             x1, x1, HEAP, lsl #32
    // 0xbdc378: stur            x1, [fp, #-8]
    // 0xbdc37c: cmp             w1, NULL
    // 0xbdc380: b.eq            #0xbdc420
    // 0xbdc384: stp             x0, x1, [SP, #-0x10]!
    // 0xbdc388: r0 = _getValueOrData()
    //     0xbdc388: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xbdc38c: add             SP, SP, #0x10
    // 0xbdc390: mov             x1, x0
    // 0xbdc394: ldur            x0, [fp, #-8]
    // 0xbdc398: LoadField: r2 = r0->field_f
    //     0xbdc398: ldur            w2, [x0, #0xf]
    // 0xbdc39c: DecompressPointer r2
    //     0xbdc39c: add             x2, x2, HEAP, lsl #32
    // 0xbdc3a0: cmp             w2, w1
    // 0xbdc3a4: b.ne            #0xbdc3b0
    // 0xbdc3a8: r0 = Null
    //     0xbdc3a8: mov             x0, NULL
    // 0xbdc3ac: b               #0xbdc3b4
    // 0xbdc3b0: mov             x0, x1
    // 0xbdc3b4: stur            x0, [fp, #-8]
    // 0xbdc3b8: cmp             w0, NULL
    // 0xbdc3bc: b.ne            #0xbdc3d0
    // 0xbdc3c0: r0 = Null
    //     0xbdc3c0: mov             x0, NULL
    // 0xbdc3c4: LeaveFrame
    //     0xbdc3c4: mov             SP, fp
    //     0xbdc3c8: ldp             fp, lr, [SP], #0x10
    // 0xbdc3cc: ret
    //     0xbdc3cc: ret             
    // 0xbdc3d0: ldur            x2, [fp, #-0x10]
    // 0xbdc3d4: r1 = Function '<anonymous closure>':.
    //     0xbdc3d4: add             x1, PP, #0x57, lsl #12  ; [pp+0x57328] AnonymousClosure: (0xbdc424), in [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::acceptGesture (0xbdc324)
    //     0xbdc3d8: ldr             x1, [x1, #0x328]
    // 0xbdc3dc: r0 = AllocateClosure()
    //     0xbdc3dc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbdc3e0: mov             x1, x0
    // 0xbdc3e4: ldur            x0, [fp, #-8]
    // 0xbdc3e8: r2 = LoadClassIdInstr(r0)
    //     0xbdc3e8: ldur            x2, [x0, #-1]
    //     0xbdc3ec: ubfx            x2, x2, #0xc, #0x14
    // 0xbdc3f0: stp             x1, x0, [SP, #-0x10]!
    // 0xbdc3f4: mov             x0, x2
    // 0xbdc3f8: r0 = GDT[cid_x0 + -0xfed]()
    //     0xbdc3f8: sub             lr, x0, #0xfed
    //     0xbdc3fc: ldr             lr, [x21, lr, lsl #3]
    //     0xbdc400: blr             lr
    // 0xbdc404: add             SP, SP, #0x10
    // 0xbdc408: r0 = Null
    //     0xbdc408: mov             x0, NULL
    // 0xbdc40c: LeaveFrame
    //     0xbdc40c: mov             SP, fp
    //     0xbdc410: ldp             fp, lr, [SP], #0x10
    // 0xbdc414: ret
    //     0xbdc414: ret             
    // 0xbdc418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc41c: b               #0xbdc33c
    // 0xbdc420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdc420: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Drag? <anonymous closure>(dynamic, Offset) {
    // ** addr: 0xbdc424, size: 0x64
    // 0xbdc424: EnterFrame
    //     0xbdc424: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc428: mov             fp, SP
    // 0xbdc42c: ldr             x0, [fp, #0x18]
    // 0xbdc430: LoadField: r1 = r0->field_17
    //     0xbdc430: ldur            w1, [x0, #0x17]
    // 0xbdc434: DecompressPointer r1
    //     0xbdc434: add             x1, x1, HEAP, lsl #32
    // 0xbdc438: CheckStackOverflow
    //     0xbdc438: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc43c: cmp             SP, x16
    //     0xbdc440: b.ls            #0xbdc480
    // 0xbdc444: LoadField: r0 = r1->field_f
    //     0xbdc444: ldur            w0, [x1, #0xf]
    // 0xbdc448: DecompressPointer r0
    //     0xbdc448: add             x0, x0, HEAP, lsl #32
    // 0xbdc44c: LoadField: r2 = r1->field_13
    //     0xbdc44c: ldur            w2, [x1, #0x13]
    // 0xbdc450: DecompressPointer r2
    //     0xbdc450: add             x2, x2, HEAP, lsl #32
    // 0xbdc454: r1 = LoadInt32Instr(r2)
    //     0xbdc454: sbfx            x1, x2, #1, #0x1f
    //     0xbdc458: tbz             w2, #0, #0xbdc460
    //     0xbdc45c: ldur            x1, [x2, #7]
    // 0xbdc460: ldr             x16, [fp, #0x10]
    // 0xbdc464: stp             x16, x0, [SP, #-0x10]!
    // 0xbdc468: SaveReg r1
    //     0xbdc468: str             x1, [SP, #-8]!
    // 0xbdc46c: r0 = _startDrag()
    //     0xbdc46c: bl              #0xbdc488  ; [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_startDrag
    // 0xbdc470: add             SP, SP, #0x18
    // 0xbdc474: LeaveFrame
    //     0xbdc474: mov             SP, fp
    //     0xbdc478: ldp             fp, lr, [SP], #0x10
    // 0xbdc47c: ret
    //     0xbdc47c: ret             
    // 0xbdc480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc480: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc484: b               #0xbdc444
  }
  _ _startDrag(/* No info */) {
    // ** addr: 0xbdc488, size: 0x144
    // 0xbdc488: EnterFrame
    //     0xbdc488: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc48c: mov             fp, SP
    // 0xbdc490: AllocStack(0x18)
    //     0xbdc490: sub             SP, SP, #0x18
    // 0xbdc494: CheckStackOverflow
    //     0xbdc494: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc498: cmp             SP, x16
    //     0xbdc49c: b.ls            #0xbdc5bc
    // 0xbdc4a0: r1 = 2
    //     0xbdc4a0: mov             x1, #2
    // 0xbdc4a4: r0 = AllocateContext()
    //     0xbdc4a4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbdc4a8: mov             x3, x0
    // 0xbdc4ac: ldr             x2, [fp, #0x20]
    // 0xbdc4b0: stur            x3, [fp, #-0x18]
    // 0xbdc4b4: StoreField: r3->field_f = r2
    //     0xbdc4b4: stur            w2, [x3, #0xf]
    // 0xbdc4b8: ldr             x0, [fp, #0x18]
    // 0xbdc4bc: StoreField: r3->field_13 = r0
    //     0xbdc4bc: stur            w0, [x3, #0x13]
    // 0xbdc4c0: LoadField: r4 = r2->field_17
    //     0xbdc4c0: ldur            w4, [x2, #0x17]
    // 0xbdc4c4: DecompressPointer r4
    //     0xbdc4c4: add             x4, x4, HEAP, lsl #32
    // 0xbdc4c8: stur            x4, [fp, #-0x10]
    // 0xbdc4cc: cmp             w4, NULL
    // 0xbdc4d0: b.eq            #0xbdc5c4
    // 0xbdc4d4: ldr             x5, [fp, #0x10]
    // 0xbdc4d8: r0 = BoxInt64Instr(r5)
    //     0xbdc4d8: sbfiz           x0, x5, #1, #0x1f
    //     0xbdc4dc: cmp             x5, x0, asr #1
    //     0xbdc4e0: b.eq            #0xbdc4ec
    //     0xbdc4e4: bl              #0xd69bb8
    //     0xbdc4e8: stur            x5, [x0, #7]
    // 0xbdc4ec: stur            x0, [fp, #-8]
    // 0xbdc4f0: stp             x0, x4, [SP, #-0x10]!
    // 0xbdc4f4: r0 = _getValueOrData()
    //     0xbdc4f4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xbdc4f8: add             SP, SP, #0x10
    // 0xbdc4fc: mov             x1, x0
    // 0xbdc500: ldur            x0, [fp, #-0x10]
    // 0xbdc504: LoadField: r2 = r0->field_f
    //     0xbdc504: ldur            w2, [x0, #0xf]
    // 0xbdc508: DecompressPointer r2
    //     0xbdc508: add             x2, x2, HEAP, lsl #32
    // 0xbdc50c: cmp             w2, w1
    // 0xbdc510: b.ne            #0xbdc51c
    // 0xbdc514: r3 = Null
    //     0xbdc514: mov             x3, NULL
    // 0xbdc518: b               #0xbdc520
    // 0xbdc51c: mov             x3, x1
    // 0xbdc520: ldr             x0, [fp, #0x20]
    // 0xbdc524: stur            x3, [fp, #-0x10]
    // 0xbdc528: cmp             w3, NULL
    // 0xbdc52c: b.eq            #0xbdc5c8
    // 0xbdc530: LoadField: r1 = r0->field_13
    //     0xbdc530: ldur            w1, [x0, #0x13]
    // 0xbdc534: DecompressPointer r1
    //     0xbdc534: add             x1, x1, HEAP, lsl #32
    // 0xbdc538: cmp             w1, NULL
    // 0xbdc53c: b.eq            #0xbdc574
    // 0xbdc540: ldur            x2, [fp, #-0x18]
    // 0xbdc544: r1 = Function '<anonymous closure>':.
    //     0xbdc544: add             x1, PP, #0x57, lsl #12  ; [pp+0x57330] AnonymousClosure: (0xbdc6a4), in [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_startDrag (0xbdc488)
    //     0xbdc548: ldr             x1, [x1, #0x330]
    // 0xbdc54c: r0 = AllocateClosure()
    //     0xbdc54c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbdc550: r16 = <Drag?>
    //     0xbdc550: add             x16, PP, #0x57, lsl #12  ; [pp+0x57338] TypeArguments: <Drag?>
    //     0xbdc554: ldr             x16, [x16, #0x338]
    // 0xbdc558: ldr             lr, [fp, #0x20]
    // 0xbdc55c: stp             lr, x16, [SP, #-0x10]!
    // 0xbdc560: SaveReg r0
    //     0xbdc560: str             x0, [SP, #-8]!
    // 0xbdc564: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbdc564: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbdc568: r0 = invokeCallback()
    //     0xbdc568: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xbdc56c: add             SP, SP, #0x18
    // 0xbdc570: b               #0xbdc578
    // 0xbdc574: r0 = Null
    //     0xbdc574: mov             x0, NULL
    // 0xbdc578: stur            x0, [fp, #-0x18]
    // 0xbdc57c: cmp             w0, NULL
    // 0xbdc580: b.eq            #0xbdc598
    // 0xbdc584: ldur            x16, [fp, #-0x10]
    // 0xbdc588: stp             x0, x16, [SP, #-0x10]!
    // 0xbdc58c: r0 = _startDrag()
    //     0xbdc58c: bl              #0xbdc5cc  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::_startDrag
    // 0xbdc590: add             SP, SP, #0x10
    // 0xbdc594: b               #0xbdc5ac
    // 0xbdc598: ldr             x16, [fp, #0x20]
    // 0xbdc59c: ldur            lr, [fp, #-8]
    // 0xbdc5a0: stp             lr, x16, [SP, #-0x10]!
    // 0xbdc5a4: r0 = _removeState()
    //     0xbdc5a4: bl              #0x783de0  ; [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_removeState
    // 0xbdc5a8: add             SP, SP, #0x10
    // 0xbdc5ac: ldur            x0, [fp, #-0x18]
    // 0xbdc5b0: LeaveFrame
    //     0xbdc5b0: mov             SP, fp
    //     0xbdc5b4: ldp             fp, lr, [SP], #0x10
    // 0xbdc5b8: ret
    //     0xbdc5b8: ret             
    // 0xbdc5bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc5bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc5c0: b               #0xbdc4a0
    // 0xbdc5c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdc5c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbdc5c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdc5c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Drag? <anonymous closure>(dynamic) {
    // ** addr: 0xbdc6a4, size: 0x70
    // 0xbdc6a4: EnterFrame
    //     0xbdc6a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc6a8: mov             fp, SP
    // 0xbdc6ac: ldr             x0, [fp, #0x10]
    // 0xbdc6b0: LoadField: r1 = r0->field_17
    //     0xbdc6b0: ldur            w1, [x0, #0x17]
    // 0xbdc6b4: DecompressPointer r1
    //     0xbdc6b4: add             x1, x1, HEAP, lsl #32
    // 0xbdc6b8: CheckStackOverflow
    //     0xbdc6b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc6bc: cmp             SP, x16
    //     0xbdc6c0: b.ls            #0xbdc708
    // 0xbdc6c4: LoadField: r0 = r1->field_f
    //     0xbdc6c4: ldur            w0, [x1, #0xf]
    // 0xbdc6c8: DecompressPointer r0
    //     0xbdc6c8: add             x0, x0, HEAP, lsl #32
    // 0xbdc6cc: LoadField: r2 = r0->field_13
    //     0xbdc6cc: ldur            w2, [x0, #0x13]
    // 0xbdc6d0: DecompressPointer r2
    //     0xbdc6d0: add             x2, x2, HEAP, lsl #32
    // 0xbdc6d4: cmp             w2, NULL
    // 0xbdc6d8: b.eq            #0xbdc710
    // 0xbdc6dc: LoadField: r0 = r1->field_13
    //     0xbdc6dc: ldur            w0, [x1, #0x13]
    // 0xbdc6e0: DecompressPointer r0
    //     0xbdc6e0: add             x0, x0, HEAP, lsl #32
    // 0xbdc6e4: stp             x0, x2, [SP, #-0x10]!
    // 0xbdc6e8: mov             x0, x2
    // 0xbdc6ec: ClosureCall
    //     0xbdc6ec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbdc6f0: ldur            x2, [x0, #0x1f]
    //     0xbdc6f4: blr             x2
    // 0xbdc6f8: add             SP, SP, #0x10
    // 0xbdc6fc: LeaveFrame
    //     0xbdc6fc: mov             SP, fp
    //     0xbdc700: ldp             fp, lr, [SP], #0x10
    // 0xbdc704: ret
    //     0xbdc704: ret             
    // 0xbdc708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc708: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc70c: b               #0xbdc6c4
    // 0xbdc710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdc710: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee7a4, size: 0xf0
    // 0xcee7a4: EnterFrame
    //     0xcee7a4: stp             fp, lr, [SP, #-0x10]!
    //     0xcee7a8: mov             fp, SP
    // 0xcee7ac: AllocStack(0x10)
    //     0xcee7ac: sub             SP, SP, #0x10
    // 0xcee7b0: CheckStackOverflow
    //     0xcee7b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee7b4: cmp             SP, x16
    //     0xcee7b8: b.ls            #0xcee880
    // 0xcee7bc: ldr             x2, [fp, #0x18]
    // 0xcee7c0: LoadField: r3 = r2->field_17
    //     0xcee7c0: ldur            w3, [x2, #0x17]
    // 0xcee7c4: DecompressPointer r3
    //     0xcee7c4: add             x3, x3, HEAP, lsl #32
    // 0xcee7c8: cmp             w3, NULL
    // 0xcee7cc: b.eq            #0xcee888
    // 0xcee7d0: ldr             x4, [fp, #0x10]
    // 0xcee7d4: r0 = BoxInt64Instr(r4)
    //     0xcee7d4: sbfiz           x0, x4, #1, #0x1f
    //     0xcee7d8: cmp             x4, x0, asr #1
    //     0xcee7dc: b.eq            #0xcee7e8
    //     0xcee7e0: bl              #0xd69bb8
    //     0xcee7e4: stur            x4, [x0, #7]
    // 0xcee7e8: stur            x0, [fp, #-8]
    // 0xcee7ec: stp             x0, x3, [SP, #-0x10]!
    // 0xcee7f0: r0 = containsKey()
    //     0xcee7f0: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xcee7f4: add             SP, SP, #0x10
    // 0xcee7f8: tbnz            w0, #4, #0xcee870
    // 0xcee7fc: ldr             x0, [fp, #0x18]
    // 0xcee800: LoadField: r1 = r0->field_17
    //     0xcee800: ldur            w1, [x0, #0x17]
    // 0xcee804: DecompressPointer r1
    //     0xcee804: add             x1, x1, HEAP, lsl #32
    // 0xcee808: stur            x1, [fp, #-0x10]
    // 0xcee80c: cmp             w1, NULL
    // 0xcee810: b.eq            #0xcee88c
    // 0xcee814: ldur            x16, [fp, #-8]
    // 0xcee818: stp             x16, x1, [SP, #-0x10]!
    // 0xcee81c: r0 = _getValueOrData()
    //     0xcee81c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcee820: add             SP, SP, #0x10
    // 0xcee824: mov             x1, x0
    // 0xcee828: ldur            x0, [fp, #-0x10]
    // 0xcee82c: LoadField: r2 = r0->field_f
    //     0xcee82c: ldur            w2, [x0, #0xf]
    // 0xcee830: DecompressPointer r2
    //     0xcee830: add             x2, x2, HEAP, lsl #32
    // 0xcee834: cmp             w2, w1
    // 0xcee838: b.ne            #0xcee844
    // 0xcee83c: r0 = Null
    //     0xcee83c: mov             x0, NULL
    // 0xcee840: b               #0xcee848
    // 0xcee844: mov             x0, x1
    // 0xcee848: cmp             w0, NULL
    // 0xcee84c: b.eq            #0xcee890
    // 0xcee850: SaveReg r0
    //     0xcee850: str             x0, [SP, #-8]!
    // 0xcee854: r0 = rejected()
    //     0xcee854: bl              #0xcee894  ; [package:flutter/src/gestures/multidrag.dart] MultiDragPointerState::rejected
    // 0xcee858: add             SP, SP, #8
    // 0xcee85c: ldr             x16, [fp, #0x18]
    // 0xcee860: ldur            lr, [fp, #-8]
    // 0xcee864: stp             lr, x16, [SP, #-0x10]!
    // 0xcee868: r0 = _removeState()
    //     0xcee868: bl              #0x783de0  ; [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::_removeState
    // 0xcee86c: add             SP, SP, #0x10
    // 0xcee870: r0 = Null
    //     0xcee870: mov             x0, NULL
    // 0xcee874: LeaveFrame
    //     0xcee874: mov             SP, fp
    //     0xcee878: ldp             fp, lr, [SP], #0x10
    // 0xcee87c: ret
    //     0xcee87c: ret             
    // 0xcee880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee880: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee884: b               #0xcee7bc
    // 0xcee888: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcee888: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcee88c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcee88c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcee890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcee890: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2346, size: 0x20, field offset: 0x1c
class DelayedMultiDragGestureRecognizer extends MultiDragGestureRecognizer {

  _ DelayedMultiDragGestureRecognizer(/* No info */) {
    // ** addr: 0x995f74, size: 0x48
    // 0x995f74: EnterFrame
    //     0x995f74: stp             fp, lr, [SP, #-0x10]!
    //     0x995f78: mov             fp, SP
    // 0x995f7c: r0 = Instance_Duration
    //     0x995f7c: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f718] Obj!Duration@b67b11
    //     0x995f80: ldr             x0, [x0, #0x718]
    // 0x995f84: CheckStackOverflow
    //     0x995f84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x995f88: cmp             SP, x16
    //     0x995f8c: b.ls            #0x995fb4
    // 0x995f90: ldr             x1, [fp, #0x10]
    // 0x995f94: StoreField: r1->field_1b = r0
    //     0x995f94: stur            w0, [x1, #0x1b]
    // 0x995f98: SaveReg r1
    //     0x995f98: str             x1, [SP, #-8]!
    // 0x995f9c: r0 = MultiDragGestureRecognizer()
    //     0x995f9c: bl              #0x995fbc  ; [package:flutter/src/gestures/multidrag.dart] MultiDragGestureRecognizer::MultiDragGestureRecognizer
    // 0x995fa0: add             SP, SP, #8
    // 0x995fa4: r0 = Null
    //     0x995fa4: mov             x0, NULL
    // 0x995fa8: LeaveFrame
    //     0x995fa8: mov             SP, fp
    //     0x995fac: ldp             fp, lr, [SP], #0x10
    // 0x995fb0: ret
    //     0x995fb0: ret             
    // 0x995fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x995fb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x995fb8: b               #0x995f90
  }
}

// class id: 2347, size: 0x1c, field offset: 0x1c
class ImmediateMultiDragGestureRecognizer extends MultiDragGestureRecognizer {
}

// lib: , url: package:flutter/src/gestures/team.dart

// class id: 1049172, size: 0x8
class :: {
}

// class id: 2254, size: 0x10, field offset: 0x8
class GestureArenaTeam extends Object {

  _ add(/* No info */) {
    // ** addr: 0x71148c, size: 0xc8
    // 0x71148c: EnterFrame
    //     0x71148c: stp             fp, lr, [SP, #-0x10]!
    //     0x711490: mov             fp, SP
    // 0x711494: AllocStack(0x18)
    //     0x711494: sub             SP, SP, #0x18
    // 0x711498: CheckStackOverflow
    //     0x711498: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71149c: cmp             SP, x16
    //     0x7114a0: b.ls            #0x71154c
    // 0x7114a4: r1 = 2
    //     0x7114a4: mov             x1, #2
    // 0x7114a8: r0 = AllocateContext()
    //     0x7114a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7114ac: mov             x3, x0
    // 0x7114b0: ldr             x2, [fp, #0x20]
    // 0x7114b4: stur            x3, [fp, #-0x18]
    // 0x7114b8: StoreField: r3->field_f = r2
    //     0x7114b8: stur            w2, [x3, #0xf]
    // 0x7114bc: ldr             x4, [fp, #0x18]
    // 0x7114c0: r0 = BoxInt64Instr(r4)
    //     0x7114c0: sbfiz           x0, x4, #1, #0x1f
    //     0x7114c4: cmp             x4, x0, asr #1
    //     0x7114c8: b.eq            #0x7114d4
    //     0x7114cc: bl              #0xd69bb8
    //     0x7114d0: stur            x4, [x0, #7]
    // 0x7114d4: stur            x0, [fp, #-0x10]
    // 0x7114d8: StoreField: r3->field_13 = r0
    //     0x7114d8: stur            w0, [x3, #0x13]
    // 0x7114dc: LoadField: r4 = r2->field_7
    //     0x7114dc: ldur            w4, [x2, #7]
    // 0x7114e0: DecompressPointer r4
    //     0x7114e0: add             x4, x4, HEAP, lsl #32
    // 0x7114e4: mov             x2, x3
    // 0x7114e8: stur            x4, [fp, #-8]
    // 0x7114ec: r1 = Function '<anonymous closure>':.
    //     0x7114ec: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f080] AnonymousClosure: (0x7116ac), in [package:flutter/src/gestures/team.dart] GestureArenaTeam::add (0x71148c)
    //     0x7114f0: ldr             x1, [x1, #0x80]
    // 0x7114f4: r0 = AllocateClosure()
    //     0x7114f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7114f8: ldur            x16, [fp, #-8]
    // 0x7114fc: ldur            lr, [fp, #-0x10]
    // 0x711500: stp             lr, x16, [SP, #-0x10]!
    // 0x711504: SaveReg r0
    //     0x711504: str             x0, [SP, #-8]!
    // 0x711508: r0 = putIfAbsent()
    //     0x711508: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x71150c: add             SP, SP, #0x18
    // 0x711510: mov             x1, x0
    // 0x711514: ldur            x0, [fp, #-0x18]
    // 0x711518: LoadField: r2 = r0->field_13
    //     0x711518: ldur            w2, [x0, #0x13]
    // 0x71151c: DecompressPointer r2
    //     0x71151c: add             x2, x2, HEAP, lsl #32
    // 0x711520: r0 = LoadInt32Instr(r2)
    //     0x711520: sbfx            x0, x2, #1, #0x1f
    //     0x711524: tbz             w2, #0, #0x71152c
    //     0x711528: ldur            x0, [x2, #7]
    // 0x71152c: stp             x0, x1, [SP, #-0x10]!
    // 0x711530: ldr             x16, [fp, #0x10]
    // 0x711534: SaveReg r16
    //     0x711534: str             x16, [SP, #-8]!
    // 0x711538: r0 = _add()
    //     0x711538: bl              #0x711554  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaMember::_add
    // 0x71153c: add             SP, SP, #0x18
    // 0x711540: LeaveFrame
    //     0x711540: mov             SP, fp
    //     0x711544: ldp             fp, lr, [SP], #0x10
    // 0x711548: ret
    //     0x711548: ret             
    // 0x71154c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71154c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711550: b               #0x7114a4
  }
  [closure] _CombiningGestureArenaMember <anonymous closure>(dynamic) {
    // ** addr: 0x7116ac, size: 0xd0
    // 0x7116ac: EnterFrame
    //     0x7116ac: stp             fp, lr, [SP, #-0x10]!
    //     0x7116b0: mov             fp, SP
    // 0x7116b4: AllocStack(0x18)
    //     0x7116b4: sub             SP, SP, #0x18
    // 0x7116b8: SetupParameters()
    //     0x7116b8: ldr             x0, [fp, #0x10]
    //     0x7116bc: ldur            w1, [x0, #0x17]
    //     0x7116c0: add             x1, x1, HEAP, lsl #32
    // 0x7116c4: CheckStackOverflow
    //     0x7116c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7116c8: cmp             SP, x16
    //     0x7116cc: b.ls            #0x711774
    // 0x7116d0: LoadField: r0 = r1->field_f
    //     0x7116d0: ldur            w0, [x1, #0xf]
    // 0x7116d4: DecompressPointer r0
    //     0x7116d4: add             x0, x0, HEAP, lsl #32
    // 0x7116d8: stur            x0, [fp, #-0x10]
    // 0x7116dc: LoadField: r2 = r1->field_13
    //     0x7116dc: ldur            w2, [x1, #0x13]
    // 0x7116e0: DecompressPointer r2
    //     0x7116e0: add             x2, x2, HEAP, lsl #32
    // 0x7116e4: stur            x2, [fp, #-8]
    // 0x7116e8: r0 = _CombiningGestureArenaMember()
    //     0x7116e8: bl              #0x71177c  ; Allocate_CombiningGestureArenaMemberStub -> _CombiningGestureArenaMember (size=0x24)
    // 0x7116ec: mov             x1, x0
    // 0x7116f0: r0 = false
    //     0x7116f0: add             x0, NULL, #0x30  ; false
    // 0x7116f4: stur            x1, [fp, #-0x18]
    // 0x7116f8: StoreField: r1->field_17 = r0
    //     0x7116f8: stur            w0, [x1, #0x17]
    // 0x7116fc: r16 = <GestureArenaMember>
    //     0x7116fc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f00] TypeArguments: <GestureArenaMember>
    //     0x711700: ldr             x16, [x16, #0xf00]
    // 0x711704: stp             xzr, x16, [SP, #-0x10]!
    // 0x711708: r0 = _GrowableList()
    //     0x711708: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x71170c: add             SP, SP, #0x10
    // 0x711710: ldur            x1, [fp, #-0x18]
    // 0x711714: StoreField: r1->field_b = r0
    //     0x711714: stur            w0, [x1, #0xb]
    //     0x711718: ldurb           w16, [x1, #-1]
    //     0x71171c: ldurb           w17, [x0, #-1]
    //     0x711720: and             x16, x17, x16, lsr #2
    //     0x711724: tst             x16, HEAP, lsr #32
    //     0x711728: b.eq            #0x711730
    //     0x71172c: bl              #0xd6826c
    // 0x711730: ldur            x0, [fp, #-0x10]
    // 0x711734: StoreField: r1->field_7 = r0
    //     0x711734: stur            w0, [x1, #7]
    //     0x711738: ldurb           w16, [x1, #-1]
    //     0x71173c: ldurb           w17, [x0, #-1]
    //     0x711740: and             x16, x17, x16, lsr #2
    //     0x711744: tst             x16, HEAP, lsr #32
    //     0x711748: b.eq            #0x711750
    //     0x71174c: bl              #0xd6826c
    // 0x711750: ldur            x2, [fp, #-8]
    // 0x711754: r3 = LoadInt32Instr(r2)
    //     0x711754: sbfx            x3, x2, #1, #0x1f
    //     0x711758: tbz             w2, #0, #0x711760
    //     0x71175c: ldur            x3, [x2, #7]
    // 0x711760: StoreField: r1->field_f = r3
    //     0x711760: stur            x3, [x1, #0xf]
    // 0x711764: mov             x0, x1
    // 0x711768: LeaveFrame
    //     0x711768: mov             SP, fp
    //     0x71176c: ldp             fp, lr, [SP], #0x10
    // 0x711770: ret
    //     0x711770: ret             
    // 0x711774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711774: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711778: b               #0x7116d0
  }
}

// class id: 2255, size: 0x10, field offset: 0x8
class _CombiningGestureArenaEntry extends Object
    implements GestureArenaEntry {

  _ resolve(/* No info */) {
    // ** addr: 0xcf9754, size: 0x54
    // 0xcf9754: EnterFrame
    //     0xcf9754: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9758: mov             fp, SP
    // 0xcf975c: CheckStackOverflow
    //     0xcf975c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf9760: cmp             SP, x16
    //     0xcf9764: b.ls            #0xcf97a0
    // 0xcf9768: ldr             x0, [fp, #0x18]
    // 0xcf976c: LoadField: r1 = r0->field_7
    //     0xcf976c: ldur            w1, [x0, #7]
    // 0xcf9770: DecompressPointer r1
    //     0xcf9770: add             x1, x1, HEAP, lsl #32
    // 0xcf9774: LoadField: r2 = r0->field_b
    //     0xcf9774: ldur            w2, [x0, #0xb]
    // 0xcf9778: DecompressPointer r2
    //     0xcf9778: add             x2, x2, HEAP, lsl #32
    // 0xcf977c: stp             x2, x1, [SP, #-0x10]!
    // 0xcf9780: ldr             x16, [fp, #0x10]
    // 0xcf9784: SaveReg r16
    //     0xcf9784: str             x16, [SP, #-8]!
    // 0xcf9788: r0 = _resolve()
    //     0xcf9788: bl              #0xcf97a8  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaMember::_resolve
    // 0xcf978c: add             SP, SP, #0x18
    // 0xcf9790: r0 = Null
    //     0xcf9790: mov             x0, NULL
    // 0xcf9794: LeaveFrame
    //     0xcf9794: mov             SP, fp
    //     0xcf9798: ldp             fp, lr, [SP], #0x10
    // 0xcf979c: ret
    //     0xcf979c: ret             
    // 0xcf97a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf97a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf97a4: b               #0xcf9768
  }
}

// class id: 2341, size: 0x24, field offset: 0x8
class _CombiningGestureArenaMember extends GestureArenaMember {

  _ _add(/* No info */) {
    // ** addr: 0x711554, size: 0x14c
    // 0x711554: EnterFrame
    //     0x711554: stp             fp, lr, [SP, #-0x10]!
    //     0x711558: mov             fp, SP
    // 0x71155c: AllocStack(0x10)
    //     0x71155c: sub             SP, SP, #0x10
    // 0x711560: CheckStackOverflow
    //     0x711560: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711564: cmp             SP, x16
    //     0x711568: b.ls            #0x711690
    // 0x71156c: ldr             x0, [fp, #0x20]
    // 0x711570: LoadField: r1 = r0->field_b
    //     0x711570: ldur            w1, [x0, #0xb]
    // 0x711574: DecompressPointer r1
    //     0x711574: add             x1, x1, HEAP, lsl #32
    // 0x711578: stur            x1, [fp, #-0x10]
    // 0x71157c: LoadField: r2 = r1->field_b
    //     0x71157c: ldur            w2, [x1, #0xb]
    // 0x711580: DecompressPointer r2
    //     0x711580: add             x2, x2, HEAP, lsl #32
    // 0x711584: stur            x2, [fp, #-8]
    // 0x711588: LoadField: r3 = r1->field_f
    //     0x711588: ldur            w3, [x1, #0xf]
    // 0x71158c: DecompressPointer r3
    //     0x71158c: add             x3, x3, HEAP, lsl #32
    // 0x711590: LoadField: r4 = r3->field_b
    //     0x711590: ldur            w4, [x3, #0xb]
    // 0x711594: DecompressPointer r4
    //     0x711594: add             x4, x4, HEAP, lsl #32
    // 0x711598: cmp             w2, w4
    // 0x71159c: b.ne            #0x7115ac
    // 0x7115a0: SaveReg r1
    //     0x7115a0: str             x1, [SP, #-8]!
    // 0x7115a4: r0 = _growToNextCapacity()
    //     0x7115a4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7115a8: add             SP, SP, #8
    // 0x7115ac: ldr             x2, [fp, #0x20]
    // 0x7115b0: ldur            x3, [fp, #-0x10]
    // 0x7115b4: ldur            x0, [fp, #-8]
    // 0x7115b8: r4 = LoadInt32Instr(r0)
    //     0x7115b8: sbfx            x4, x0, #1, #0x1f
    // 0x7115bc: add             x0, x4, #1
    // 0x7115c0: lsl             x1, x0, #1
    // 0x7115c4: StoreField: r3->field_b = r1
    //     0x7115c4: stur            w1, [x3, #0xb]
    // 0x7115c8: mov             x1, x4
    // 0x7115cc: cmp             x1, x0
    // 0x7115d0: b.hs            #0x711698
    // 0x7115d4: LoadField: r1 = r3->field_f
    //     0x7115d4: ldur            w1, [x3, #0xf]
    // 0x7115d8: DecompressPointer r1
    //     0x7115d8: add             x1, x1, HEAP, lsl #32
    // 0x7115dc: ldr             x0, [fp, #0x10]
    // 0x7115e0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x7115e0: add             x25, x1, x4, lsl #2
    //     0x7115e4: add             x25, x25, #0xf
    //     0x7115e8: str             w0, [x25]
    //     0x7115ec: tbz             w0, #0, #0x711608
    //     0x7115f0: ldurb           w16, [x1, #-1]
    //     0x7115f4: ldurb           w17, [x0, #-1]
    //     0x7115f8: and             x16, x17, x16, lsr #2
    //     0x7115fc: tst             x16, HEAP, lsr #32
    //     0x711600: b.eq            #0x711608
    //     0x711604: bl              #0xd67e5c
    // 0x711608: LoadField: r0 = r2->field_1f
    //     0x711608: ldur            w0, [x2, #0x1f]
    // 0x71160c: DecompressPointer r0
    //     0x71160c: add             x0, x0, HEAP, lsl #32
    // 0x711610: cmp             w0, NULL
    // 0x711614: b.ne            #0x711668
    // 0x711618: ldr             x0, [fp, #0x18]
    // 0x71161c: r1 = LoadStaticField(0xd54)
    //     0x71161c: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x711620: ldr             x1, [x1, #0x1aa8]
    // 0x711624: cmp             w1, NULL
    // 0x711628: b.eq            #0x71169c
    // 0x71162c: LoadField: r3 = r1->field_17
    //     0x71162c: ldur            w3, [x1, #0x17]
    // 0x711630: DecompressPointer r3
    //     0x711630: add             x3, x3, HEAP, lsl #32
    // 0x711634: stp             x0, x3, [SP, #-0x10]!
    // 0x711638: SaveReg r2
    //     0x711638: str             x2, [SP, #-8]!
    // 0x71163c: r0 = add()
    //     0x71163c: bl              #0x7112b0  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::add
    // 0x711640: add             SP, SP, #0x18
    // 0x711644: ldr             x1, [fp, #0x20]
    // 0x711648: StoreField: r1->field_1f = r0
    //     0x711648: stur            w0, [x1, #0x1f]
    //     0x71164c: ldurb           w16, [x1, #-1]
    //     0x711650: ldurb           w17, [x0, #-1]
    //     0x711654: and             x16, x17, x16, lsr #2
    //     0x711658: tst             x16, HEAP, lsr #32
    //     0x71165c: b.eq            #0x711664
    //     0x711660: bl              #0xd6826c
    // 0x711664: b               #0x71166c
    // 0x711668: mov             x1, x2
    // 0x71166c: ldr             x0, [fp, #0x10]
    // 0x711670: r0 = _CombiningGestureArenaEntry()
    //     0x711670: bl              #0x7116a0  ; Allocate_CombiningGestureArenaEntryStub -> _CombiningGestureArenaEntry (size=0x10)
    // 0x711674: ldr             x1, [fp, #0x20]
    // 0x711678: StoreField: r0->field_7 = r1
    //     0x711678: stur            w1, [x0, #7]
    // 0x71167c: ldr             x1, [fp, #0x10]
    // 0x711680: StoreField: r0->field_b = r1
    //     0x711680: stur            w1, [x0, #0xb]
    // 0x711684: LeaveFrame
    //     0x711684: mov             SP, fp
    //     0x711688: ldp             fp, lr, [SP], #0x10
    // 0x71168c: ret
    //     0x71168c: ret             
    // 0x711690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711694: b               #0x71156c
    // 0x711698: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x711698: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x71169c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x71169c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdc714, size: 0x298
    // 0xbdc714: EnterFrame
    //     0xbdc714: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc718: mov             fp, SP
    // 0xbdc71c: AllocStack(0x30)
    //     0xbdc71c: sub             SP, SP, #0x30
    // 0xbdc720: CheckStackOverflow
    //     0xbdc720: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc724: cmp             SP, x16
    //     0xbdc728: b.ls            #0xbdc994
    // 0xbdc72c: ldr             x16, [fp, #0x18]
    // 0xbdc730: SaveReg r16
    //     0xbdc730: str             x16, [SP, #-8]!
    // 0xbdc734: r0 = _close()
    //     0xbdc734: bl              #0xbdc9ac  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaMember::_close
    // 0xbdc738: add             SP, SP, #8
    // 0xbdc73c: ldr             x2, [fp, #0x18]
    // 0xbdc740: LoadField: r0 = r2->field_1b
    //     0xbdc740: ldur            w0, [x2, #0x1b]
    // 0xbdc744: DecompressPointer r0
    //     0xbdc744: add             x0, x0, HEAP, lsl #32
    // 0xbdc748: cmp             w0, NULL
    // 0xbdc74c: b.ne            #0xbdc7c8
    // 0xbdc750: LoadField: r0 = r2->field_7
    //     0xbdc750: ldur            w0, [x2, #7]
    // 0xbdc754: DecompressPointer r0
    //     0xbdc754: add             x0, x0, HEAP, lsl #32
    // 0xbdc758: LoadField: r1 = r0->field_b
    //     0xbdc758: ldur            w1, [x0, #0xb]
    // 0xbdc75c: DecompressPointer r1
    //     0xbdc75c: add             x1, x1, HEAP, lsl #32
    // 0xbdc760: cmp             w1, NULL
    // 0xbdc764: b.ne            #0xbdc7a4
    // 0xbdc768: LoadField: r3 = r2->field_b
    //     0xbdc768: ldur            w3, [x2, #0xb]
    // 0xbdc76c: DecompressPointer r3
    //     0xbdc76c: add             x3, x3, HEAP, lsl #32
    // 0xbdc770: LoadField: r0 = r3->field_b
    //     0xbdc770: ldur            w0, [x3, #0xb]
    // 0xbdc774: DecompressPointer r0
    //     0xbdc774: add             x0, x0, HEAP, lsl #32
    // 0xbdc778: r1 = LoadInt32Instr(r0)
    //     0xbdc778: sbfx            x1, x0, #1, #0x1f
    // 0xbdc77c: mov             x0, x1
    // 0xbdc780: r1 = 0
    //     0xbdc780: mov             x1, #0
    // 0xbdc784: cmp             x1, x0
    // 0xbdc788: b.hs            #0xbdc99c
    // 0xbdc78c: LoadField: r0 = r3->field_f
    //     0xbdc78c: ldur            w0, [x3, #0xf]
    // 0xbdc790: DecompressPointer r0
    //     0xbdc790: add             x0, x0, HEAP, lsl #32
    // 0xbdc794: LoadField: r1 = r0->field_f
    //     0xbdc794: ldur            w1, [x0, #0xf]
    // 0xbdc798: DecompressPointer r1
    //     0xbdc798: add             x1, x1, HEAP, lsl #32
    // 0xbdc79c: mov             x0, x1
    // 0xbdc7a0: b               #0xbdc7a8
    // 0xbdc7a4: mov             x0, x1
    // 0xbdc7a8: StoreField: r2->field_1b = r0
    //     0xbdc7a8: stur            w0, [x2, #0x1b]
    //     0xbdc7ac: tbz             w0, #0, #0xbdc7c8
    //     0xbdc7b0: ldurb           w16, [x2, #-1]
    //     0xbdc7b4: ldurb           w17, [x0, #-1]
    //     0xbdc7b8: and             x16, x17, x16, lsr #2
    //     0xbdc7bc: tst             x16, HEAP, lsr #32
    //     0xbdc7c0: b.eq            #0xbdc7c8
    //     0xbdc7c4: bl              #0xd6828c
    // 0xbdc7c8: LoadField: r1 = r2->field_b
    //     0xbdc7c8: ldur            w1, [x2, #0xb]
    // 0xbdc7cc: DecompressPointer r1
    //     0xbdc7cc: add             x1, x1, HEAP, lsl #32
    // 0xbdc7d0: stur            x1, [fp, #-0x20]
    // 0xbdc7d4: LoadField: r3 = r1->field_7
    //     0xbdc7d4: ldur            w3, [x1, #7]
    // 0xbdc7d8: DecompressPointer r3
    //     0xbdc7d8: add             x3, x3, HEAP, lsl #32
    // 0xbdc7dc: stur            x3, [fp, #-0x18]
    // 0xbdc7e0: LoadField: r0 = r1->field_b
    //     0xbdc7e0: ldur            w0, [x1, #0xb]
    // 0xbdc7e4: DecompressPointer r0
    //     0xbdc7e4: add             x0, x0, HEAP, lsl #32
    // 0xbdc7e8: r4 = LoadInt32Instr(r0)
    //     0xbdc7e8: sbfx            x4, x0, #1, #0x1f
    // 0xbdc7ec: stur            x4, [fp, #-0x10]
    // 0xbdc7f0: r6 = 0
    //     0xbdc7f0: mov             x6, #0
    // 0xbdc7f4: ldr             x5, [fp, #0x10]
    // 0xbdc7f8: stur            x6, [fp, #-8]
    // 0xbdc7fc: CheckStackOverflow
    //     0xbdc7fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc800: cmp             SP, x16
    //     0xbdc804: b.ls            #0xbdc9a0
    // 0xbdc808: r0 = LoadClassIdInstr(r1)
    //     0xbdc808: ldur            x0, [x1, #-1]
    //     0xbdc80c: ubfx            x0, x0, #0xc, #0x14
    // 0xbdc810: SaveReg r1
    //     0xbdc810: str             x1, [SP, #-8]!
    // 0xbdc814: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xbdc814: mov             x17, #0xb8ea
    //     0xbdc818: add             lr, x0, x17
    //     0xbdc81c: ldr             lr, [x21, lr, lsl #3]
    //     0xbdc820: blr             lr
    // 0xbdc824: add             SP, SP, #8
    // 0xbdc828: r1 = LoadInt32Instr(r0)
    //     0xbdc828: sbfx            x1, x0, #1, #0x1f
    //     0xbdc82c: tbz             w0, #0, #0xbdc834
    //     0xbdc830: ldur            x1, [x0, #7]
    // 0xbdc834: ldur            x2, [fp, #-0x10]
    // 0xbdc838: cmp             x2, x1
    // 0xbdc83c: b.ne            #0xbdc97c
    // 0xbdc840: ldur            x3, [fp, #-0x20]
    // 0xbdc844: ldur            x4, [fp, #-8]
    // 0xbdc848: cmp             x4, x1
    // 0xbdc84c: b.lt            #0xbdc89c
    // 0xbdc850: ldr             x5, [fp, #0x18]
    // 0xbdc854: ldr             x6, [fp, #0x10]
    // 0xbdc858: LoadField: r0 = r5->field_1b
    //     0xbdc858: ldur            w0, [x5, #0x1b]
    // 0xbdc85c: DecompressPointer r0
    //     0xbdc85c: add             x0, x0, HEAP, lsl #32
    // 0xbdc860: cmp             w0, NULL
    // 0xbdc864: b.eq            #0xbdc9a8
    // 0xbdc868: r1 = LoadClassIdInstr(r0)
    //     0xbdc868: ldur            x1, [x0, #-1]
    //     0xbdc86c: ubfx            x1, x1, #0xc, #0x14
    // 0xbdc870: stp             x6, x0, [SP, #-0x10]!
    // 0xbdc874: mov             x0, x1
    // 0xbdc878: r0 = GDT[cid_x0 + 0x18e8]()
    //     0xbdc878: mov             x17, #0x18e8
    //     0xbdc87c: add             lr, x0, x17
    //     0xbdc880: ldr             lr, [x21, lr, lsl #3]
    //     0xbdc884: blr             lr
    // 0xbdc888: add             SP, SP, #0x10
    // 0xbdc88c: r0 = Null
    //     0xbdc88c: mov             x0, NULL
    // 0xbdc890: LeaveFrame
    //     0xbdc890: mov             SP, fp
    //     0xbdc894: ldp             fp, lr, [SP], #0x10
    // 0xbdc898: ret
    //     0xbdc898: ret             
    // 0xbdc89c: ldr             x5, [fp, #0x18]
    // 0xbdc8a0: ldr             x6, [fp, #0x10]
    // 0xbdc8a4: r0 = BoxInt64Instr(r4)
    //     0xbdc8a4: sbfiz           x0, x4, #1, #0x1f
    //     0xbdc8a8: cmp             x4, x0, asr #1
    //     0xbdc8ac: b.eq            #0xbdc8b8
    //     0xbdc8b0: bl              #0xd69bb8
    //     0xbdc8b4: stur            x4, [x0, #7]
    // 0xbdc8b8: r1 = LoadClassIdInstr(r3)
    //     0xbdc8b8: ldur            x1, [x3, #-1]
    //     0xbdc8bc: ubfx            x1, x1, #0xc, #0x14
    // 0xbdc8c0: stp             x0, x3, [SP, #-0x10]!
    // 0xbdc8c4: mov             x0, x1
    // 0xbdc8c8: r0 = GDT[cid_x0 + 0xd175]()
    //     0xbdc8c8: mov             x17, #0xd175
    //     0xbdc8cc: add             lr, x0, x17
    //     0xbdc8d0: ldr             lr, [x21, lr, lsl #3]
    //     0xbdc8d4: blr             lr
    // 0xbdc8d8: add             SP, SP, #0x10
    // 0xbdc8dc: mov             x3, x0
    // 0xbdc8e0: ldur            x0, [fp, #-8]
    // 0xbdc8e4: stur            x3, [fp, #-0x30]
    // 0xbdc8e8: add             x6, x0, #1
    // 0xbdc8ec: stur            x6, [fp, #-0x28]
    // 0xbdc8f0: cmp             w3, NULL
    // 0xbdc8f4: b.ne            #0xbdc928
    // 0xbdc8f8: mov             x0, x3
    // 0xbdc8fc: ldur            x2, [fp, #-0x18]
    // 0xbdc900: r1 = Null
    //     0xbdc900: mov             x1, NULL
    // 0xbdc904: cmp             w2, NULL
    // 0xbdc908: b.eq            #0xbdc928
    // 0xbdc90c: LoadField: r4 = r2->field_17
    //     0xbdc90c: ldur            w4, [x2, #0x17]
    // 0xbdc910: DecompressPointer r4
    //     0xbdc910: add             x4, x4, HEAP, lsl #32
    // 0xbdc914: r8 = X0
    //     0xbdc914: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbdc918: LoadField: r9 = r4->field_7
    //     0xbdc918: ldur            x9, [x4, #7]
    // 0xbdc91c: r3 = Null
    //     0xbdc91c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37ab0] Null
    //     0xbdc920: ldr             x3, [x3, #0xab0]
    // 0xbdc924: blr             x9
    // 0xbdc928: ldr             x1, [fp, #0x18]
    // 0xbdc92c: ldur            x0, [fp, #-0x30]
    // 0xbdc930: LoadField: r2 = r1->field_1b
    //     0xbdc930: ldur            w2, [x1, #0x1b]
    // 0xbdc934: DecompressPointer r2
    //     0xbdc934: add             x2, x2, HEAP, lsl #32
    // 0xbdc938: cmp             w0, w2
    // 0xbdc93c: b.eq            #0xbdc964
    // 0xbdc940: ldr             x2, [fp, #0x10]
    // 0xbdc944: r3 = LoadClassIdInstr(r0)
    //     0xbdc944: ldur            x3, [x0, #-1]
    //     0xbdc948: ubfx            x3, x3, #0xc, #0x14
    // 0xbdc94c: stp             x2, x0, [SP, #-0x10]!
    // 0xbdc950: mov             x0, x3
    // 0xbdc954: r0 = GDT[cid_x0 + -0xeac]()
    //     0xbdc954: sub             lr, x0, #0xeac
    //     0xbdc958: ldr             lr, [x21, lr, lsl #3]
    //     0xbdc95c: blr             lr
    // 0xbdc960: add             SP, SP, #0x10
    // 0xbdc964: ldur            x6, [fp, #-0x28]
    // 0xbdc968: ldr             x2, [fp, #0x18]
    // 0xbdc96c: ldur            x1, [fp, #-0x20]
    // 0xbdc970: ldur            x3, [fp, #-0x18]
    // 0xbdc974: ldur            x4, [fp, #-0x10]
    // 0xbdc978: b               #0xbdc7f4
    // 0xbdc97c: ldur            x0, [fp, #-0x20]
    // 0xbdc980: r0 = ConcurrentModificationError()
    //     0xbdc980: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbdc984: ldur            x3, [fp, #-0x20]
    // 0xbdc988: StoreField: r0->field_b = r3
    //     0xbdc988: stur            w3, [x0, #0xb]
    // 0xbdc98c: r0 = Throw()
    //     0xbdc98c: bl              #0xd67e38  ; ThrowStub
    // 0xbdc990: brk             #0
    // 0xbdc994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc994: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc998: b               #0xbdc72c
    // 0xbdc99c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbdc99c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbdc9a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc9a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc9a4: b               #0xbdc808
    // 0xbdc9a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdc9a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _close(/* No info */) {
    // ** addr: 0xbdc9ac, size: 0x6c
    // 0xbdc9ac: EnterFrame
    //     0xbdc9ac: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc9b0: mov             fp, SP
    // 0xbdc9b4: r0 = true
    //     0xbdc9b4: add             x0, NULL, #0x20  ; true
    // 0xbdc9b8: CheckStackOverflow
    //     0xbdc9b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc9bc: cmp             SP, x16
    //     0xbdc9c0: b.ls            #0xbdca10
    // 0xbdc9c4: ldr             x1, [fp, #0x10]
    // 0xbdc9c8: StoreField: r1->field_17 = r0
    //     0xbdc9c8: stur            w0, [x1, #0x17]
    // 0xbdc9cc: LoadField: r0 = r1->field_7
    //     0xbdc9cc: ldur            w0, [x1, #7]
    // 0xbdc9d0: DecompressPointer r0
    //     0xbdc9d0: add             x0, x0, HEAP, lsl #32
    // 0xbdc9d4: LoadField: r2 = r0->field_7
    //     0xbdc9d4: ldur            w2, [x0, #7]
    // 0xbdc9d8: DecompressPointer r2
    //     0xbdc9d8: add             x2, x2, HEAP, lsl #32
    // 0xbdc9dc: LoadField: r3 = r1->field_f
    //     0xbdc9dc: ldur            x3, [x1, #0xf]
    // 0xbdc9e0: r0 = BoxInt64Instr(r3)
    //     0xbdc9e0: sbfiz           x0, x3, #1, #0x1f
    //     0xbdc9e4: cmp             x3, x0, asr #1
    //     0xbdc9e8: b.eq            #0xbdc9f4
    //     0xbdc9ec: bl              #0xd69bb8
    //     0xbdc9f0: stur            x3, [x0, #7]
    // 0xbdc9f4: stp             x0, x2, [SP, #-0x10]!
    // 0xbdc9f8: r0 = remove()
    //     0xbdc9f8: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xbdc9fc: add             SP, SP, #0x10
    // 0xbdca00: r0 = Null
    //     0xbdca00: mov             x0, NULL
    // 0xbdca04: LeaveFrame
    //     0xbdca04: mov             SP, fp
    //     0xbdca08: ldp             fp, lr, [SP], #0x10
    // 0xbdca0c: ret
    //     0xbdca0c: ret             
    // 0xbdca10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdca10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdca14: b               #0xbdc9c4
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee980, size: 0x1ac
    // 0xcee980: EnterFrame
    //     0xcee980: stp             fp, lr, [SP, #-0x10]!
    //     0xcee984: mov             fp, SP
    // 0xcee988: AllocStack(0x30)
    //     0xcee988: sub             SP, SP, #0x30
    // 0xcee98c: CheckStackOverflow
    //     0xcee98c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee990: cmp             SP, x16
    //     0xcee994: b.ls            #0xceeb1c
    // 0xcee998: ldr             x16, [fp, #0x18]
    // 0xcee99c: SaveReg r16
    //     0xcee99c: str             x16, [SP, #-8]!
    // 0xcee9a0: r0 = _close()
    //     0xcee9a0: bl              #0xbdc9ac  ; [package:flutter/src/gestures/team.dart] _CombiningGestureArenaMember::_close
    // 0xcee9a4: add             SP, SP, #8
    // 0xcee9a8: ldr             x0, [fp, #0x18]
    // 0xcee9ac: LoadField: r1 = r0->field_b
    //     0xcee9ac: ldur            w1, [x0, #0xb]
    // 0xcee9b0: DecompressPointer r1
    //     0xcee9b0: add             x1, x1, HEAP, lsl #32
    // 0xcee9b4: stur            x1, [fp, #-0x20]
    // 0xcee9b8: LoadField: r2 = r1->field_7
    //     0xcee9b8: ldur            w2, [x1, #7]
    // 0xcee9bc: DecompressPointer r2
    //     0xcee9bc: add             x2, x2, HEAP, lsl #32
    // 0xcee9c0: stur            x2, [fp, #-0x18]
    // 0xcee9c4: LoadField: r0 = r1->field_b
    //     0xcee9c4: ldur            w0, [x1, #0xb]
    // 0xcee9c8: DecompressPointer r0
    //     0xcee9c8: add             x0, x0, HEAP, lsl #32
    // 0xcee9cc: r3 = LoadInt32Instr(r0)
    //     0xcee9cc: sbfx            x3, x0, #1, #0x1f
    // 0xcee9d0: stur            x3, [fp, #-0x10]
    // 0xcee9d4: r5 = 0
    //     0xcee9d4: mov             x5, #0
    // 0xcee9d8: ldr             x4, [fp, #0x10]
    // 0xcee9dc: stur            x5, [fp, #-8]
    // 0xcee9e0: CheckStackOverflow
    //     0xcee9e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee9e4: cmp             SP, x16
    //     0xcee9e8: b.ls            #0xceeb24
    // 0xcee9ec: r0 = LoadClassIdInstr(r1)
    //     0xcee9ec: ldur            x0, [x1, #-1]
    //     0xcee9f0: ubfx            x0, x0, #0xc, #0x14
    // 0xcee9f4: SaveReg r1
    //     0xcee9f4: str             x1, [SP, #-8]!
    // 0xcee9f8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcee9f8: mov             x17, #0xb8ea
    //     0xcee9fc: add             lr, x0, x17
    //     0xceea00: ldr             lr, [x21, lr, lsl #3]
    //     0xceea04: blr             lr
    // 0xceea08: add             SP, SP, #8
    // 0xceea0c: r1 = LoadInt32Instr(r0)
    //     0xceea0c: sbfx            x1, x0, #1, #0x1f
    //     0xceea10: tbz             w0, #0, #0xceea18
    //     0xceea14: ldur            x1, [x0, #7]
    // 0xceea18: ldur            x2, [fp, #-0x10]
    // 0xceea1c: cmp             x2, x1
    // 0xceea20: b.ne            #0xceeb04
    // 0xceea24: ldur            x3, [fp, #-0x20]
    // 0xceea28: ldur            x4, [fp, #-8]
    // 0xceea2c: cmp             x4, x1
    // 0xceea30: b.lt            #0xceea44
    // 0xceea34: r0 = Null
    //     0xceea34: mov             x0, NULL
    // 0xceea38: LeaveFrame
    //     0xceea38: mov             SP, fp
    //     0xceea3c: ldp             fp, lr, [SP], #0x10
    // 0xceea40: ret
    //     0xceea40: ret             
    // 0xceea44: r0 = BoxInt64Instr(r4)
    //     0xceea44: sbfiz           x0, x4, #1, #0x1f
    //     0xceea48: cmp             x4, x0, asr #1
    //     0xceea4c: b.eq            #0xceea58
    //     0xceea50: bl              #0xd69bb8
    //     0xceea54: stur            x4, [x0, #7]
    // 0xceea58: r1 = LoadClassIdInstr(r3)
    //     0xceea58: ldur            x1, [x3, #-1]
    //     0xceea5c: ubfx            x1, x1, #0xc, #0x14
    // 0xceea60: stp             x0, x3, [SP, #-0x10]!
    // 0xceea64: mov             x0, x1
    // 0xceea68: r0 = GDT[cid_x0 + 0xd175]()
    //     0xceea68: mov             x17, #0xd175
    //     0xceea6c: add             lr, x0, x17
    //     0xceea70: ldr             lr, [x21, lr, lsl #3]
    //     0xceea74: blr             lr
    // 0xceea78: add             SP, SP, #0x10
    // 0xceea7c: mov             x3, x0
    // 0xceea80: ldur            x0, [fp, #-8]
    // 0xceea84: stur            x3, [fp, #-0x30]
    // 0xceea88: add             x5, x0, #1
    // 0xceea8c: stur            x5, [fp, #-0x28]
    // 0xceea90: cmp             w3, NULL
    // 0xceea94: b.ne            #0xceeac8
    // 0xceea98: mov             x0, x3
    // 0xceea9c: ldur            x2, [fp, #-0x18]
    // 0xceeaa0: r1 = Null
    //     0xceeaa0: mov             x1, NULL
    // 0xceeaa4: cmp             w2, NULL
    // 0xceeaa8: b.eq            #0xceeac8
    // 0xceeaac: LoadField: r4 = r2->field_17
    //     0xceeaac: ldur            w4, [x2, #0x17]
    // 0xceeab0: DecompressPointer r4
    //     0xceeab0: add             x4, x4, HEAP, lsl #32
    // 0xceeab4: r8 = X0
    //     0xceeab4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xceeab8: LoadField: r9 = r4->field_7
    //     0xceeab8: ldur            x9, [x4, #7]
    // 0xceeabc: r3 = Null
    //     0xceeabc: add             x3, PP, #0x37, lsl #12  ; [pp+0x37aa0] Null
    //     0xceeac0: ldr             x3, [x3, #0xaa0]
    // 0xceeac4: blr             x9
    // 0xceeac8: ldr             x1, [fp, #0x10]
    // 0xceeacc: ldur            x0, [fp, #-0x30]
    // 0xceead0: r2 = LoadClassIdInstr(r0)
    //     0xceead0: ldur            x2, [x0, #-1]
    //     0xceead4: ubfx            x2, x2, #0xc, #0x14
    // 0xceead8: stp             x1, x0, [SP, #-0x10]!
    // 0xceeadc: mov             x0, x2
    // 0xceeae0: r0 = GDT[cid_x0 + -0xeac]()
    //     0xceeae0: sub             lr, x0, #0xeac
    //     0xceeae4: ldr             lr, [x21, lr, lsl #3]
    //     0xceeae8: blr             lr
    // 0xceeaec: add             SP, SP, #0x10
    // 0xceeaf0: ldur            x5, [fp, #-0x28]
    // 0xceeaf4: ldur            x1, [fp, #-0x20]
    // 0xceeaf8: ldur            x2, [fp, #-0x18]
    // 0xceeafc: ldur            x3, [fp, #-0x10]
    // 0xceeb00: b               #0xcee9d8
    // 0xceeb04: ldur            x0, [fp, #-0x20]
    // 0xceeb08: r0 = ConcurrentModificationError()
    //     0xceeb08: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xceeb0c: ldur            x3, [fp, #-0x20]
    // 0xceeb10: StoreField: r0->field_b = r3
    //     0xceeb10: stur            w3, [x0, #0xb]
    // 0xceeb14: r0 = Throw()
    //     0xceeb14: bl              #0xd67e38  ; ThrowStub
    // 0xceeb18: brk             #0
    // 0xceeb1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceeb1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceeb20: b               #0xcee998
    // 0xceeb24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceeb24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceeb28: b               #0xcee9ec
  }
  _ _resolve(/* No info */) {
    // ** addr: 0xcf97a8, size: 0x164
    // 0xcf97a8: EnterFrame
    //     0xcf97a8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf97ac: mov             fp, SP
    // 0xcf97b0: AllocStack(0x8)
    //     0xcf97b0: sub             SP, SP, #8
    // 0xcf97b4: CheckStackOverflow
    //     0xcf97b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf97b8: cmp             SP, x16
    //     0xcf97bc: b.ls            #0xcf98fc
    // 0xcf97c0: ldr             x0, [fp, #0x20]
    // 0xcf97c4: LoadField: r1 = r0->field_17
    //     0xcf97c4: ldur            w1, [x0, #0x17]
    // 0xcf97c8: DecompressPointer r1
    //     0xcf97c8: add             x1, x1, HEAP, lsl #32
    // 0xcf97cc: tbnz            w1, #4, #0xcf97e0
    // 0xcf97d0: r0 = Null
    //     0xcf97d0: mov             x0, NULL
    // 0xcf97d4: LeaveFrame
    //     0xcf97d4: mov             SP, fp
    //     0xcf97d8: ldp             fp, lr, [SP], #0x10
    // 0xcf97dc: ret
    //     0xcf97dc: ret             
    // 0xcf97e0: ldr             x1, [fp, #0x10]
    // 0xcf97e4: r16 = Instance_GestureDisposition
    //     0xcf97e4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xcf97e8: ldr             x16, [x16, #0xeb8]
    // 0xcf97ec: cmp             w1, w16
    // 0xcf97f0: b.ne            #0xcf9874
    // 0xcf97f4: ldr             x2, [fp, #0x18]
    // 0xcf97f8: LoadField: r3 = r0->field_b
    //     0xcf97f8: ldur            w3, [x0, #0xb]
    // 0xcf97fc: DecompressPointer r3
    //     0xcf97fc: add             x3, x3, HEAP, lsl #32
    // 0xcf9800: stur            x3, [fp, #-8]
    // 0xcf9804: stp             x2, x3, [SP, #-0x10]!
    // 0xcf9808: r0 = remove()
    //     0xcf9808: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0xcf980c: add             SP, SP, #0x10
    // 0xcf9810: ldr             x1, [fp, #0x20]
    // 0xcf9814: LoadField: r0 = r1->field_f
    //     0xcf9814: ldur            x0, [x1, #0xf]
    // 0xcf9818: ldr             x2, [fp, #0x18]
    // 0xcf981c: r3 = LoadClassIdInstr(r2)
    //     0xcf981c: ldur            x3, [x2, #-1]
    //     0xcf9820: ubfx            x3, x3, #0xc, #0x14
    // 0xcf9824: stp             x0, x2, [SP, #-0x10]!
    // 0xcf9828: mov             x0, x3
    // 0xcf982c: r0 = GDT[cid_x0 + -0xeac]()
    //     0xcf982c: sub             lr, x0, #0xeac
    //     0xcf9830: ldr             lr, [x21, lr, lsl #3]
    //     0xcf9834: blr             lr
    // 0xcf9838: add             SP, SP, #0x10
    // 0xcf983c: ldur            x0, [fp, #-8]
    // 0xcf9840: LoadField: r1 = r0->field_b
    //     0xcf9840: ldur            w1, [x0, #0xb]
    // 0xcf9844: DecompressPointer r1
    //     0xcf9844: add             x1, x1, HEAP, lsl #32
    // 0xcf9848: cbnz            w1, #0xcf98ec
    // 0xcf984c: ldr             x1, [fp, #0x20]
    // 0xcf9850: LoadField: r0 = r1->field_1f
    //     0xcf9850: ldur            w0, [x1, #0x1f]
    // 0xcf9854: DecompressPointer r0
    //     0xcf9854: add             x0, x0, HEAP, lsl #32
    // 0xcf9858: cmp             w0, NULL
    // 0xcf985c: b.eq            #0xcf9904
    // 0xcf9860: ldr             x16, [fp, #0x10]
    // 0xcf9864: stp             x16, x0, [SP, #-0x10]!
    // 0xcf9868: r0 = resolve()
    //     0xcf9868: bl              #0xcf7450  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0xcf986c: add             SP, SP, #0x10
    // 0xcf9870: b               #0xcf98ec
    // 0xcf9874: mov             x1, x0
    // 0xcf9878: ldr             x2, [fp, #0x18]
    // 0xcf987c: LoadField: r0 = r1->field_1b
    //     0xcf987c: ldur            w0, [x1, #0x1b]
    // 0xcf9880: DecompressPointer r0
    //     0xcf9880: add             x0, x0, HEAP, lsl #32
    // 0xcf9884: cmp             w0, NULL
    // 0xcf9888: b.ne            #0xcf98cc
    // 0xcf988c: LoadField: r0 = r1->field_7
    //     0xcf988c: ldur            w0, [x1, #7]
    // 0xcf9890: DecompressPointer r0
    //     0xcf9890: add             x0, x0, HEAP, lsl #32
    // 0xcf9894: LoadField: r3 = r0->field_b
    //     0xcf9894: ldur            w3, [x0, #0xb]
    // 0xcf9898: DecompressPointer r3
    //     0xcf9898: add             x3, x3, HEAP, lsl #32
    // 0xcf989c: cmp             w3, NULL
    // 0xcf98a0: b.ne            #0xcf98ac
    // 0xcf98a4: mov             x0, x2
    // 0xcf98a8: b               #0xcf98b0
    // 0xcf98ac: mov             x0, x3
    // 0xcf98b0: StoreField: r1->field_1b = r0
    //     0xcf98b0: stur            w0, [x1, #0x1b]
    //     0xcf98b4: ldurb           w16, [x1, #-1]
    //     0xcf98b8: ldurb           w17, [x0, #-1]
    //     0xcf98bc: and             x16, x17, x16, lsr #2
    //     0xcf98c0: tst             x16, HEAP, lsr #32
    //     0xcf98c4: b.eq            #0xcf98cc
    //     0xcf98c8: bl              #0xd6826c
    // 0xcf98cc: LoadField: r0 = r1->field_1f
    //     0xcf98cc: ldur            w0, [x1, #0x1f]
    // 0xcf98d0: DecompressPointer r0
    //     0xcf98d0: add             x0, x0, HEAP, lsl #32
    // 0xcf98d4: cmp             w0, NULL
    // 0xcf98d8: b.eq            #0xcf9908
    // 0xcf98dc: ldr             x16, [fp, #0x10]
    // 0xcf98e0: stp             x16, x0, [SP, #-0x10]!
    // 0xcf98e4: r0 = resolve()
    //     0xcf98e4: bl              #0xcf7450  ; [package:flutter/src/gestures/arena.dart] GestureArenaEntry::resolve
    // 0xcf98e8: add             SP, SP, #0x10
    // 0xcf98ec: r0 = Null
    //     0xcf98ec: mov             x0, NULL
    // 0xcf98f0: LeaveFrame
    //     0xcf98f0: mov             SP, fp
    //     0xcf98f4: ldp             fp, lr, [SP], #0x10
    // 0xcf98f8: ret
    //     0xcf98f8: ret             
    // 0xcf98fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf98fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9900: b               #0xcf97c0
    // 0xcf9904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf9904: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcf9908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf9908: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:flutter/src/gestures/resampler.dart

// class id: 1049169, size: 0x8
class :: {
}

// class id: 2263, size: 0x30, field offset: 0x8
class PointerEventResampler extends Object {

  _ stop(/* No info */) {
    // ** addr: 0x50f580, size: 0xc0
    // 0x50f580: EnterFrame
    //     0x50f580: stp             fp, lr, [SP, #-0x10]!
    //     0x50f584: mov             fp, SP
    // 0x50f588: AllocStack(0x8)
    //     0x50f588: sub             SP, SP, #8
    // 0x50f58c: CheckStackOverflow
    //     0x50f58c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50f590: cmp             SP, x16
    //     0x50f594: b.ls            #0x50f630
    // 0x50f598: ldr             x0, [fp, #0x18]
    // 0x50f59c: LoadField: r1 = r0->field_7
    //     0x50f59c: ldur            w1, [x0, #7]
    // 0x50f5a0: DecompressPointer r1
    //     0x50f5a0: add             x1, x1, HEAP, lsl #32
    // 0x50f5a4: stur            x1, [fp, #-8]
    // 0x50f5a8: CheckStackOverflow
    //     0x50f5a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50f5ac: cmp             SP, x16
    //     0x50f5b0: b.ls            #0x50f638
    // 0x50f5b4: LoadField: r2 = r1->field_f
    //     0x50f5b4: ldur            x2, [x1, #0xf]
    // 0x50f5b8: LoadField: r3 = r1->field_17
    //     0x50f5b8: ldur            x3, [x1, #0x17]
    // 0x50f5bc: cmp             x2, x3
    // 0x50f5c0: b.eq            #0x50f5f8
    // 0x50f5c4: SaveReg r1
    //     0x50f5c4: str             x1, [SP, #-8]!
    // 0x50f5c8: r0 = removeFirst()
    //     0x50f5c8: bl              #0x4ebdd0  ; [dart:collection] ListQueue::removeFirst
    // 0x50f5cc: add             SP, SP, #8
    // 0x50f5d0: ldr             x16, [fp, #0x10]
    // 0x50f5d4: stp             x0, x16, [SP, #-0x10]!
    // 0x50f5d8: ldr             x0, [fp, #0x10]
    // 0x50f5dc: ClosureCall
    //     0x50f5dc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x50f5e0: ldur            x2, [x0, #0x1f]
    //     0x50f5e4: blr             x2
    // 0x50f5e8: add             SP, SP, #0x10
    // 0x50f5ec: ldr             x0, [fp, #0x18]
    // 0x50f5f0: ldur            x1, [fp, #-8]
    // 0x50f5f4: b               #0x50f5a8
    // 0x50f5f8: mov             x1, x0
    // 0x50f5fc: r4 = false
    //     0x50f5fc: add             x4, NULL, #0x30  ; false
    // 0x50f600: r3 = Instance_Offset
    //     0x50f600: ldr             x3, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x50f604: r2 = 0
    //     0x50f604: mov             x2, #0
    // 0x50f608: StoreField: r1->field_1f = r2
    //     0x50f608: stur            x2, [x1, #0x1f]
    // 0x50f60c: StoreField: r1->field_1b = r4
    //     0x50f60c: stur            w4, [x1, #0x1b]
    // 0x50f610: StoreField: r1->field_17 = r4
    //     0x50f610: stur            w4, [x1, #0x17]
    // 0x50f614: StoreField: r1->field_13 = r3
    //     0x50f614: stur            w3, [x1, #0x13]
    // 0x50f618: StoreField: r1->field_f = rNULL
    //     0x50f618: stur            NULL, [x1, #0xf]
    // 0x50f61c: StoreField: r1->field_b = rNULL
    //     0x50f61c: stur            NULL, [x1, #0xb]
    // 0x50f620: r0 = Null
    //     0x50f620: mov             x0, NULL
    // 0x50f624: LeaveFrame
    //     0x50f624: mov             SP, fp
    //     0x50f628: ldp             fp, lr, [SP], #0x10
    // 0x50f62c: ret
    //     0x50f62c: ret             
    // 0x50f630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50f630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50f634: b               #0x50f598
    // 0x50f638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50f638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50f63c: b               #0x50f5b4
  }
}

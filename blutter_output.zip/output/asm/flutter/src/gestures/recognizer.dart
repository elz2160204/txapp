// lib: , url: package:flutter/src/gestures/recognizer.dart

// class id: 1049168, size: 0x8
class :: {
}

// class id: 2264, size: 0x10, field offset: 0x8
//   const constructor, 
class OffsetPair extends Object {

  Offset field_8;
  Offset field_c;

  OffsetPair -(OffsetPair, OffsetPair) {
    // ** addr: 0x7141e8, size: 0x8c
    // 0x7141e8: EnterFrame
    //     0x7141e8: stp             fp, lr, [SP, #-0x10]!
    //     0x7141ec: mov             fp, SP
    // 0x7141f0: CheckStackOverflow
    //     0x7141f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7141f4: cmp             SP, x16
    //     0x7141f8: b.ls            #0x714254
    // 0x7141fc: ldr             x0, [fp, #0x10]
    // 0x714200: r2 = Null
    //     0x714200: mov             x2, NULL
    // 0x714204: r1 = Null
    //     0x714204: mov             x1, NULL
    // 0x714208: r4 = 59
    //     0x714208: mov             x4, #0x3b
    // 0x71420c: branchIfSmi(r0, 0x714218)
    //     0x71420c: tbz             w0, #0, #0x714218
    // 0x714210: r4 = LoadClassIdInstr(r0)
    //     0x714210: ldur            x4, [x0, #-1]
    //     0x714214: ubfx            x4, x4, #0xc, #0x14
    // 0x714218: cmp             x4, #0x8d8
    // 0x71421c: b.eq            #0x714234
    // 0x714220: r8 = OffsetPair
    //     0x714220: add             x8, PP, #0x2f, lsl #12  ; [pp+0x2f050] Type: OffsetPair
    //     0x714224: ldr             x8, [x8, #0x50]
    // 0x714228: r3 = Null
    //     0x714228: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f058] Null
    //     0x71422c: ldr             x3, [x3, #0x58]
    // 0x714230: r0 = DefaultTypeTest()
    //     0x714230: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x714234: ldr             x16, [fp, #0x18]
    // 0x714238: ldr             lr, [fp, #0x10]
    // 0x71423c: stp             lr, x16, [SP, #-0x10]!
    // 0x714240: r0 = -()
    //     0x714240: bl              #0x71425c  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::-
    // 0x714244: add             SP, SP, #0x10
    // 0x714248: LeaveFrame
    //     0x714248: mov             SP, fp
    //     0x71424c: ldp             fp, lr, [SP], #0x10
    // 0x714250: ret
    //     0x714250: ret             
    // 0x714254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714254: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714258: b               #0x7141fc
  }
  OffsetPair -(OffsetPair, OffsetPair) {
    // ** addr: 0x71425c, size: 0x94
    // 0x71425c: EnterFrame
    //     0x71425c: stp             fp, lr, [SP, #-0x10]!
    //     0x714260: mov             fp, SP
    // 0x714264: AllocStack(0x10)
    //     0x714264: sub             SP, SP, #0x10
    // 0x714268: CheckStackOverflow
    //     0x714268: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71426c: cmp             SP, x16
    //     0x714270: b.ls            #0x7142e8
    // 0x714274: ldr             x0, [fp, #0x18]
    // 0x714278: LoadField: r1 = r0->field_7
    //     0x714278: ldur            w1, [x0, #7]
    // 0x71427c: DecompressPointer r1
    //     0x71427c: add             x1, x1, HEAP, lsl #32
    // 0x714280: ldr             x2, [fp, #0x10]
    // 0x714284: LoadField: r3 = r2->field_7
    //     0x714284: ldur            w3, [x2, #7]
    // 0x714288: DecompressPointer r3
    //     0x714288: add             x3, x3, HEAP, lsl #32
    // 0x71428c: stp             x3, x1, [SP, #-0x10]!
    // 0x714290: r0 = -()
    //     0x714290: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x714294: add             SP, SP, #0x10
    // 0x714298: mov             x1, x0
    // 0x71429c: ldr             x0, [fp, #0x18]
    // 0x7142a0: stur            x1, [fp, #-8]
    // 0x7142a4: LoadField: r2 = r0->field_b
    //     0x7142a4: ldur            w2, [x0, #0xb]
    // 0x7142a8: DecompressPointer r2
    //     0x7142a8: add             x2, x2, HEAP, lsl #32
    // 0x7142ac: ldr             x0, [fp, #0x10]
    // 0x7142b0: LoadField: r3 = r0->field_b
    //     0x7142b0: ldur            w3, [x0, #0xb]
    // 0x7142b4: DecompressPointer r3
    //     0x7142b4: add             x3, x3, HEAP, lsl #32
    // 0x7142b8: stp             x3, x2, [SP, #-0x10]!
    // 0x7142bc: r0 = -()
    //     0x7142bc: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x7142c0: add             SP, SP, #0x10
    // 0x7142c4: stur            x0, [fp, #-0x10]
    // 0x7142c8: r0 = OffsetPair()
    //     0x7142c8: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x7142cc: ldur            x1, [fp, #-8]
    // 0x7142d0: StoreField: r0->field_7 = r1
    //     0x7142d0: stur            w1, [x0, #7]
    // 0x7142d4: ldur            x1, [fp, #-0x10]
    // 0x7142d8: StoreField: r0->field_b = r1
    //     0x7142d8: stur            w1, [x0, #0xb]
    // 0x7142dc: LeaveFrame
    //     0x7142dc: mov             SP, fp
    //     0x7142e0: ldp             fp, lr, [SP], #0x10
    // 0x7142e4: ret
    //     0x7142e4: ret             
    // 0x7142e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7142e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7142ec: b               #0x714274
  }
  OffsetPair +(OffsetPair, OffsetPair) {
    // ** addr: 0x714314, size: 0x8c
    // 0x714314: EnterFrame
    //     0x714314: stp             fp, lr, [SP, #-0x10]!
    //     0x714318: mov             fp, SP
    // 0x71431c: CheckStackOverflow
    //     0x71431c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714320: cmp             SP, x16
    //     0x714324: b.ls            #0x714380
    // 0x714328: ldr             x0, [fp, #0x10]
    // 0x71432c: r2 = Null
    //     0x71432c: mov             x2, NULL
    // 0x714330: r1 = Null
    //     0x714330: mov             x1, NULL
    // 0x714334: r4 = 59
    //     0x714334: mov             x4, #0x3b
    // 0x714338: branchIfSmi(r0, 0x714344)
    //     0x714338: tbz             w0, #0, #0x714344
    // 0x71433c: r4 = LoadClassIdInstr(r0)
    //     0x71433c: ldur            x4, [x0, #-1]
    //     0x714340: ubfx            x4, x4, #0xc, #0x14
    // 0x714344: cmp             x4, #0x8d8
    // 0x714348: b.eq            #0x714360
    // 0x71434c: r8 = OffsetPair
    //     0x71434c: add             x8, PP, #0x2f, lsl #12  ; [pp+0x2f050] Type: OffsetPair
    //     0x714350: ldr             x8, [x8, #0x50]
    // 0x714354: r3 = Null
    //     0x714354: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f068] Null
    //     0x714358: ldr             x3, [x3, #0x68]
    // 0x71435c: r0 = DefaultTypeTest()
    //     0x71435c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x714360: ldr             x16, [fp, #0x18]
    // 0x714364: ldr             lr, [fp, #0x10]
    // 0x714368: stp             lr, x16, [SP, #-0x10]!
    // 0x71436c: r0 = +()
    //     0x71436c: bl              #0x714388  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0x714370: add             SP, SP, #0x10
    // 0x714374: LeaveFrame
    //     0x714374: mov             SP, fp
    //     0x714378: ldp             fp, lr, [SP], #0x10
    // 0x71437c: ret
    //     0x71437c: ret             
    // 0x714380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714380: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714384: b               #0x714328
  }
  OffsetPair +(OffsetPair, OffsetPair) {
    // ** addr: 0x714388, size: 0x94
    // 0x714388: EnterFrame
    //     0x714388: stp             fp, lr, [SP, #-0x10]!
    //     0x71438c: mov             fp, SP
    // 0x714390: AllocStack(0x10)
    //     0x714390: sub             SP, SP, #0x10
    // 0x714394: CheckStackOverflow
    //     0x714394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714398: cmp             SP, x16
    //     0x71439c: b.ls            #0x714414
    // 0x7143a0: ldr             x0, [fp, #0x18]
    // 0x7143a4: LoadField: r1 = r0->field_7
    //     0x7143a4: ldur            w1, [x0, #7]
    // 0x7143a8: DecompressPointer r1
    //     0x7143a8: add             x1, x1, HEAP, lsl #32
    // 0x7143ac: ldr             x2, [fp, #0x10]
    // 0x7143b0: LoadField: r3 = r2->field_7
    //     0x7143b0: ldur            w3, [x2, #7]
    // 0x7143b4: DecompressPointer r3
    //     0x7143b4: add             x3, x3, HEAP, lsl #32
    // 0x7143b8: stp             x3, x1, [SP, #-0x10]!
    // 0x7143bc: r0 = +()
    //     0x7143bc: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7143c0: add             SP, SP, #0x10
    // 0x7143c4: mov             x1, x0
    // 0x7143c8: ldr             x0, [fp, #0x18]
    // 0x7143cc: stur            x1, [fp, #-8]
    // 0x7143d0: LoadField: r2 = r0->field_b
    //     0x7143d0: ldur            w2, [x0, #0xb]
    // 0x7143d4: DecompressPointer r2
    //     0x7143d4: add             x2, x2, HEAP, lsl #32
    // 0x7143d8: ldr             x0, [fp, #0x10]
    // 0x7143dc: LoadField: r3 = r0->field_b
    //     0x7143dc: ldur            w3, [x0, #0xb]
    // 0x7143e0: DecompressPointer r3
    //     0x7143e0: add             x3, x3, HEAP, lsl #32
    // 0x7143e4: stp             x3, x2, [SP, #-0x10]!
    // 0x7143e8: r0 = +()
    //     0x7143e8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7143ec: add             SP, SP, #0x10
    // 0x7143f0: stur            x0, [fp, #-0x10]
    // 0x7143f4: r0 = OffsetPair()
    //     0x7143f4: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x7143f8: ldur            x1, [fp, #-8]
    // 0x7143fc: StoreField: r0->field_7 = r1
    //     0x7143fc: stur            w1, [x0, #7]
    // 0x714400: ldur            x1, [fp, #-0x10]
    // 0x714404: StoreField: r0->field_b = r1
    //     0x714404: stur            w1, [x0, #0xb]
    // 0x714408: LeaveFrame
    //     0x714408: mov             SP, fp
    //     0x71440c: ldp             fp, lr, [SP], #0x10
    // 0x714410: ret
    //     0x714410: ret             
    // 0x714414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714414: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714418: b               #0x7143a0
  }
  factory _ OffsetPair.fromEventPosition(/* No info */) {
    // ** addr: 0x78253c, size: 0x94
    // 0x78253c: EnterFrame
    //     0x78253c: stp             fp, lr, [SP, #-0x10]!
    //     0x782540: mov             fp, SP
    // 0x782544: AllocStack(0x10)
    //     0x782544: sub             SP, SP, #0x10
    // 0x782548: CheckStackOverflow
    //     0x782548: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78254c: cmp             SP, x16
    //     0x782550: b.ls            #0x7825c8
    // 0x782554: ldr             x1, [fp, #0x10]
    // 0x782558: r0 = LoadClassIdInstr(r1)
    //     0x782558: ldur            x0, [x1, #-1]
    //     0x78255c: ubfx            x0, x0, #0xc, #0x14
    // 0x782560: SaveReg r1
    //     0x782560: str             x1, [SP, #-8]!
    // 0x782564: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x782564: mov             x17, #0x57c0
    //     0x782568: add             lr, x0, x17
    //     0x78256c: ldr             lr, [x21, lr, lsl #3]
    //     0x782570: blr             lr
    // 0x782574: add             SP, SP, #8
    // 0x782578: mov             x1, x0
    // 0x78257c: ldr             x0, [fp, #0x10]
    // 0x782580: stur            x1, [fp, #-8]
    // 0x782584: r2 = LoadClassIdInstr(r0)
    //     0x782584: ldur            x2, [x0, #-1]
    //     0x782588: ubfx            x2, x2, #0xc, #0x14
    // 0x78258c: SaveReg r0
    //     0x78258c: str             x0, [SP, #-8]!
    // 0x782590: mov             x0, x2
    // 0x782594: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x782594: sub             lr, x0, #0xfd9
    //     0x782598: ldr             lr, [x21, lr, lsl #3]
    //     0x78259c: blr             lr
    // 0x7825a0: add             SP, SP, #8
    // 0x7825a4: stur            x0, [fp, #-0x10]
    // 0x7825a8: r0 = OffsetPair()
    //     0x7825a8: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x7825ac: ldur            x1, [fp, #-8]
    // 0x7825b0: StoreField: r0->field_7 = r1
    //     0x7825b0: stur            w1, [x0, #7]
    // 0x7825b4: ldur            x1, [fp, #-0x10]
    // 0x7825b8: StoreField: r0->field_b = r1
    //     0x7825b8: stur            w1, [x0, #0xb]
    // 0x7825bc: LeaveFrame
    //     0x7825bc: mov             SP, fp
    //     0x7825c0: ldp             fp, lr, [SP], #0x10
    // 0x7825c4: ret
    //     0x7825c4: ret             
    // 0x7825c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7825c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7825cc: b               #0x782554
  }
  _ toString(/* No info */) {
    // ** addr: 0xad9788, size: 0x88
    // 0xad9788: EnterFrame
    //     0xad9788: stp             fp, lr, [SP, #-0x10]!
    //     0xad978c: mov             fp, SP
    // 0xad9790: CheckStackOverflow
    //     0xad9790: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9794: cmp             SP, x16
    //     0xad9798: b.ls            #0xad9808
    // 0xad979c: r1 = Null
    //     0xad979c: mov             x1, NULL
    // 0xad97a0: r2 = 12
    //     0xad97a0: mov             x2, #0xc
    // 0xad97a4: r0 = AllocateArray()
    //     0xad97a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad97a8: r17 = "OffsetPair"
    //     0xad97a8: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2f038] "OffsetPair"
    //     0xad97ac: ldr             x17, [x17, #0x38]
    // 0xad97b0: StoreField: r0->field_f = r17
    //     0xad97b0: stur            w17, [x0, #0xf]
    // 0xad97b4: r17 = "(local: "
    //     0xad97b4: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2f040] "(local: "
    //     0xad97b8: ldr             x17, [x17, #0x40]
    // 0xad97bc: StoreField: r0->field_13 = r17
    //     0xad97bc: stur            w17, [x0, #0x13]
    // 0xad97c0: ldr             x1, [fp, #0x10]
    // 0xad97c4: LoadField: r2 = r1->field_7
    //     0xad97c4: ldur            w2, [x1, #7]
    // 0xad97c8: DecompressPointer r2
    //     0xad97c8: add             x2, x2, HEAP, lsl #32
    // 0xad97cc: StoreField: r0->field_17 = r2
    //     0xad97cc: stur            w2, [x0, #0x17]
    // 0xad97d0: r17 = ", global: "
    //     0xad97d0: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2f048] ", global: "
    //     0xad97d4: ldr             x17, [x17, #0x48]
    // 0xad97d8: StoreField: r0->field_1b = r17
    //     0xad97d8: stur            w17, [x0, #0x1b]
    // 0xad97dc: LoadField: r2 = r1->field_b
    //     0xad97dc: ldur            w2, [x1, #0xb]
    // 0xad97e0: DecompressPointer r2
    //     0xad97e0: add             x2, x2, HEAP, lsl #32
    // 0xad97e4: StoreField: r0->field_1f = r2
    //     0xad97e4: stur            w2, [x0, #0x1f]
    // 0xad97e8: r17 = ")"
    //     0xad97e8: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad97ec: StoreField: r0->field_23 = r17
    //     0xad97ec: stur            w17, [x0, #0x23]
    // 0xad97f0: SaveReg r0
    //     0xad97f0: str             x0, [SP, #-8]!
    // 0xad97f4: r0 = _interpolate()
    //     0xad97f4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad97f8: add             SP, SP, #8
    // 0xad97fc: LeaveFrame
    //     0xad97fc: mov             SP, fp
    //     0xad9800: ldp             fp, lr, [SP], #0x10
    // 0xad9804: ret
    //     0xad9804: ret             
    // 0xad9808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9808: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad980c: b               #0xad979c
  }
}

// class id: 2342, size: 0x8, field offset: 0x8
//   transformed mixin,
abstract class _GestureRecognizer&GestureArenaMember&DiagnosticableTreeMixin extends GestureArenaMember
     with DiagnosticableTreeMixin {

  _ toString(/* No info */) {
    // ** addr: 0xad90b4, size: 0x58
    // 0xad90b4: EnterFrame
    //     0xad90b4: stp             fp, lr, [SP, #-0x10]!
    //     0xad90b8: mov             fp, SP
    // 0xad90bc: mov             x0, x4
    // 0xad90c0: LoadField: r1 = r0->field_13
    //     0xad90c0: ldur            w1, [x0, #0x13]
    // 0xad90c4: DecompressPointer r1
    //     0xad90c4: add             x1, x1, HEAP, lsl #32
    // 0xad90c8: sub             x0, x1, #2
    // 0xad90cc: add             x1, fp, w0, sxtw #2
    // 0xad90d0: ldr             x1, [x1, #0x10]
    // 0xad90d4: CheckStackOverflow
    //     0xad90d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad90d8: cmp             SP, x16
    //     0xad90dc: b.ls            #0xad9104
    // 0xad90e0: SaveReg r1
    //     0xad90e0: str             x1, [SP, #-8]!
    // 0xad90e4: r0 = toDiagnosticsNode()
    //     0xad90e4: bl              #0x794ec0  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin::toDiagnosticsNode
    // 0xad90e8: add             SP, SP, #8
    // 0xad90ec: SaveReg r0
    //     0xad90ec: str             x0, [SP, #-8]!
    // 0xad90f0: r0 = toString()
    //     0xad90f0: bl              #0xaf6f6c  ; [dart:core] Object::toString
    // 0xad90f4: add             SP, SP, #8
    // 0xad90f8: LeaveFrame
    //     0xad90f8: mov             SP, fp
    //     0xad90fc: ldp             fp, lr, [SP], #0x10
    // 0xad9100: ret
    //     0xad9100: ret             
    // 0xad9104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9104: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9108: b               #0xad90e0
  }
}

// class id: 2343, size: 0x14, field offset: 0x8
abstract class GestureRecognizer extends _GestureRecognizer&GestureArenaMember&DiagnosticableTreeMixin {

  _ GestureRecognizer(/* No info */) {
    // ** addr: 0x6d4060, size: 0x128
    // 0x6d4060: EnterFrame
    //     0x6d4060: stp             fp, lr, [SP, #-0x10]!
    //     0x6d4064: mov             fp, SP
    // 0x6d4068: AllocStack(0x10)
    //     0x6d4068: sub             SP, SP, #0x10
    // 0x6d406c: CheckStackOverflow
    //     0x6d406c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d4070: cmp             SP, x16
    //     0x6d4074: b.ls            #0x6d4180
    // 0x6d4078: r16 = <int, PointerDeviceKind>
    //     0x6d4078: add             x16, PP, #0x21, lsl #12  ; [pp+0x214c8] TypeArguments: <int, PointerDeviceKind>
    //     0x6d407c: ldr             x16, [x16, #0x4c8]
    // 0x6d4080: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6d4084: stp             lr, x16, [SP, #-0x10]!
    // 0x6d4088: r0 = Map._fromLiteral()
    //     0x6d4088: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6d408c: add             SP, SP, #0x10
    // 0x6d4090: ldr             x1, [fp, #0x20]
    // 0x6d4094: StoreField: r1->field_f = r0
    //     0x6d4094: stur            w0, [x1, #0xf]
    //     0x6d4098: tbz             w0, #0, #0x6d40b4
    //     0x6d409c: ldurb           w16, [x1, #-1]
    //     0x6d40a0: ldurb           w17, [x0, #-1]
    //     0x6d40a4: and             x16, x17, x16, lsr #2
    //     0x6d40a8: tst             x16, HEAP, lsr #32
    //     0x6d40ac: b.eq            #0x6d40b4
    //     0x6d40b0: bl              #0xd6826c
    // 0x6d40b4: ldr             x0, [fp, #0x18]
    // 0x6d40b8: cmp             w0, NULL
    // 0x6d40bc: b.ne            #0x6d40c8
    // 0x6d40c0: ldr             x0, [fp, #0x10]
    // 0x6d40c4: b               #0x6d4150
    // 0x6d40c8: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x6d40c8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6d40cc: ldr             x0, [x0, #0x598]
    //     0x6d40d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6d40d4: cmp             w0, w16
    //     0x6d40d8: b.ne            #0x6d40e4
    //     0x6d40dc: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x6d40e0: bl              #0xd67cdc
    // 0x6d40e4: r1 = <PointerDeviceKind>
    //     0x6d40e4: add             x1, PP, #0x21, lsl #12  ; [pp+0x214d0] TypeArguments: <PointerDeviceKind>
    //     0x6d40e8: ldr             x1, [x1, #0x4d0]
    // 0x6d40ec: stur            x0, [fp, #-8]
    // 0x6d40f0: r0 = _Set()
    //     0x6d40f0: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x6d40f4: mov             x1, x0
    // 0x6d40f8: ldur            x0, [fp, #-8]
    // 0x6d40fc: stur            x1, [fp, #-0x10]
    // 0x6d4100: StoreField: r1->field_1b = r0
    //     0x6d4100: stur            w0, [x1, #0x1b]
    // 0x6d4104: StoreField: r1->field_b = rZR
    //     0x6d4104: stur            wzr, [x1, #0xb]
    // 0x6d4108: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x6d4108: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6d410c: ldr             x0, [x0, #0x5a0]
    //     0x6d4110: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6d4114: cmp             w0, w16
    //     0x6d4118: b.ne            #0x6d4124
    //     0x6d411c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x6d4120: bl              #0xd67cdc
    // 0x6d4124: mov             x1, x0
    // 0x6d4128: ldur            x0, [fp, #-0x10]
    // 0x6d412c: StoreField: r0->field_f = r1
    //     0x6d412c: stur            w1, [x0, #0xf]
    // 0x6d4130: StoreField: r0->field_13 = rZR
    //     0x6d4130: stur            wzr, [x0, #0x13]
    // 0x6d4134: StoreField: r0->field_17 = rZR
    //     0x6d4134: stur            wzr, [x0, #0x17]
    // 0x6d4138: ldr             x16, [fp, #0x18]
    // 0x6d413c: stp             x16, x0, [SP, #-0x10]!
    // 0x6d4140: r0 = add()
    //     0x6d4140: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x6d4144: add             SP, SP, #0x10
    // 0x6d4148: ldur            x0, [fp, #-0x10]
    // 0x6d414c: ldr             x1, [fp, #0x20]
    // 0x6d4150: StoreField: r1->field_b = r0
    //     0x6d4150: stur            w0, [x1, #0xb]
    //     0x6d4154: tbz             w0, #0, #0x6d4170
    //     0x6d4158: ldurb           w16, [x1, #-1]
    //     0x6d415c: ldurb           w17, [x0, #-1]
    //     0x6d4160: and             x16, x17, x16, lsr #2
    //     0x6d4164: tst             x16, HEAP, lsr #32
    //     0x6d4168: b.eq            #0x6d4170
    //     0x6d416c: bl              #0xd6826c
    // 0x6d4170: r0 = Null
    //     0x6d4170: mov             x0, NULL
    // 0x6d4174: LeaveFrame
    //     0x6d4174: mov             SP, fp
    //     0x6d4178: ldp             fp, lr, [SP], #0x10
    // 0x6d417c: ret
    //     0x6d417c: ret             
    // 0x6d4180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d4180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d4184: b               #0x6d4078
  }
  _ addPointer(/* No info */) {
    // ** addr: 0x6fd9cc, size: 0x13c
    // 0x6fd9cc: EnterFrame
    //     0x6fd9cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6fd9d0: mov             fp, SP
    // 0x6fd9d4: AllocStack(0x10)
    //     0x6fd9d4: sub             SP, SP, #0x10
    // 0x6fd9d8: CheckStackOverflow
    //     0x6fd9d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6fd9dc: cmp             SP, x16
    //     0x6fd9e0: b.ls            #0x6fdb00
    // 0x6fd9e4: ldr             x1, [fp, #0x18]
    // 0x6fd9e8: LoadField: r2 = r1->field_f
    //     0x6fd9e8: ldur            w2, [x1, #0xf]
    // 0x6fd9ec: DecompressPointer r2
    //     0x6fd9ec: add             x2, x2, HEAP, lsl #32
    // 0x6fd9f0: ldr             x3, [fp, #0x10]
    // 0x6fd9f4: stur            x2, [fp, #-8]
    // 0x6fd9f8: r0 = LoadClassIdInstr(r3)
    //     0x6fd9f8: ldur            x0, [x3, #-1]
    //     0x6fd9fc: ubfx            x0, x0, #0xc, #0x14
    // 0x6fda00: SaveReg r3
    //     0x6fda00: str             x3, [SP, #-8]!
    // 0x6fda04: r0 = GDT[cid_x0 + -0xfff]()
    //     0x6fda04: sub             lr, x0, #0xfff
    //     0x6fda08: ldr             lr, [x21, lr, lsl #3]
    //     0x6fda0c: blr             lr
    // 0x6fda10: add             SP, SP, #8
    // 0x6fda14: mov             x2, x0
    // 0x6fda18: ldr             x1, [fp, #0x10]
    // 0x6fda1c: stur            x2, [fp, #-0x10]
    // 0x6fda20: r0 = LoadClassIdInstr(r1)
    //     0x6fda20: ldur            x0, [x1, #-1]
    //     0x6fda24: ubfx            x0, x0, #0xc, #0x14
    // 0x6fda28: SaveReg r1
    //     0x6fda28: str             x1, [SP, #-8]!
    // 0x6fda2c: r0 = GDT[cid_x0 + -0xf60]()
    //     0x6fda2c: sub             lr, x0, #0xf60
    //     0x6fda30: ldr             lr, [x21, lr, lsl #3]
    //     0x6fda34: blr             lr
    // 0x6fda38: add             SP, SP, #8
    // 0x6fda3c: mov             x3, x0
    // 0x6fda40: ldur            x2, [fp, #-0x10]
    // 0x6fda44: r0 = BoxInt64Instr(r2)
    //     0x6fda44: sbfiz           x0, x2, #1, #0x1f
    //     0x6fda48: cmp             x2, x0, asr #1
    //     0x6fda4c: b.eq            #0x6fda58
    //     0x6fda50: bl              #0xd69bb8
    //     0x6fda54: stur            x2, [x0, #7]
    // 0x6fda58: ldur            x16, [fp, #-8]
    // 0x6fda5c: stp             x0, x16, [SP, #-0x10]!
    // 0x6fda60: SaveReg r3
    //     0x6fda60: str             x3, [SP, #-8]!
    // 0x6fda64: r0 = []=()
    //     0x6fda64: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6fda68: add             SP, SP, #0x18
    // 0x6fda6c: ldr             x1, [fp, #0x18]
    // 0x6fda70: r0 = LoadClassIdInstr(r1)
    //     0x6fda70: ldur            x0, [x1, #-1]
    //     0x6fda74: ubfx            x0, x0, #0xc, #0x14
    // 0x6fda78: ldr             x16, [fp, #0x10]
    // 0x6fda7c: stp             x16, x1, [SP, #-0x10]!
    // 0x6fda80: r0 = GDT[cid_x0 + 0x939e]()
    //     0x6fda80: mov             x17, #0x939e
    //     0x6fda84: add             lr, x0, x17
    //     0x6fda88: ldr             lr, [x21, lr, lsl #3]
    //     0x6fda8c: blr             lr
    // 0x6fda90: add             SP, SP, #0x10
    // 0x6fda94: tbnz            w0, #4, #0x6fdac8
    // 0x6fda98: ldr             x0, [fp, #0x18]
    // 0x6fda9c: r1 = LoadClassIdInstr(r0)
    //     0x6fda9c: ldur            x1, [x0, #-1]
    //     0x6fdaa0: ubfx            x1, x1, #0xc, #0x14
    // 0x6fdaa4: ldr             x16, [fp, #0x10]
    // 0x6fdaa8: stp             x16, x0, [SP, #-0x10]!
    // 0x6fdaac: mov             x0, x1
    // 0x6fdab0: r0 = GDT[cid_x0 + 0xc112]()
    //     0x6fdab0: mov             x17, #0xc112
    //     0x6fdab4: add             lr, x0, x17
    //     0x6fdab8: ldr             lr, [x21, lr, lsl #3]
    //     0x6fdabc: blr             lr
    // 0x6fdac0: add             SP, SP, #0x10
    // 0x6fdac4: b               #0x6fdaf0
    // 0x6fdac8: ldr             x0, [fp, #0x18]
    // 0x6fdacc: r1 = LoadClassIdInstr(r0)
    //     0x6fdacc: ldur            x1, [x0, #-1]
    //     0x6fdad0: ubfx            x1, x1, #0xc, #0x14
    // 0x6fdad4: SaveReg r0
    //     0x6fdad4: str             x0, [SP, #-8]!
    // 0x6fdad8: mov             x0, x1
    // 0x6fdadc: r0 = GDT[cid_x0 + 0xc293]()
    //     0x6fdadc: mov             x17, #0xc293
    //     0x6fdae0: add             lr, x0, x17
    //     0x6fdae4: ldr             lr, [x21, lr, lsl #3]
    //     0x6fdae8: blr             lr
    // 0x6fdaec: add             SP, SP, #8
    // 0x6fdaf0: r0 = Null
    //     0x6fdaf0: mov             x0, NULL
    // 0x6fdaf4: LeaveFrame
    //     0x6fdaf4: mov             SP, fp
    //     0x6fdaf8: ldp             fp, lr, [SP], #0x10
    // 0x6fdafc: ret
    //     0x6fdafc: ret             
    // 0x6fdb00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6fdb00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6fdb04: b               #0x6fd9e4
  }
  _ invokeCallback(/* No info */) {
    // ** addr: 0x713b40, size: 0xcc
    // 0x713b40: EnterFrame
    //     0x713b40: stp             fp, lr, [SP, #-0x10]!
    //     0x713b44: mov             fp, SP
    // 0x713b48: AllocStack(0x80)
    //     0x713b48: sub             SP, SP, #0x80
    // 0x713b4c: CheckStackOverflow
    //     0x713b4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x713b50: cmp             SP, x16
    //     0x713b54: b.ls            #0x713c04
    // 0x713b58: ldr             x16, [fp, #0x10]
    // 0x713b5c: SaveReg r16
    //     0x713b5c: str             x16, [SP, #-8]!
    // 0x713b60: ldr             x0, [fp, #0x10]
    // 0x713b64: ClosureCall
    //     0x713b64: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x713b68: ldur            x2, [x0, #0x1f]
    //     0x713b6c: blr             x2
    // 0x713b70: add             SP, SP, #8
    // 0x713b74: b               #0x713bf8
    // 0x713b78: sub             SP, fp, #0x80
    // 0x713b7c: mov             x2, x0
    // 0x713b80: stur            x0, [fp, #-0x70]
    // 0x713b84: mov             x0, x1
    // 0x713b88: stur            x1, [fp, #-0x78]
    // 0x713b8c: r1 = <List<Object>>
    //     0x713b8c: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x713b90: r0 = ErrorDescription()
    //     0x713b90: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x713b94: stur            x0, [fp, #-0x80]
    // 0x713b98: r16 = "while handling a gesture"
    //     0x713b98: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ea8] "while handling a gesture"
    //     0x713b9c: ldr             x16, [x16, #0xea8]
    // 0x713ba0: stp             x16, x0, [SP, #-0x10]!
    // 0x713ba4: r16 = Instance_DiagnosticLevel
    //     0x713ba4: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x713ba8: SaveReg r16
    //     0x713ba8: str             x16, [SP, #-8]!
    // 0x713bac: r0 = _ErrorDiagnostic()
    //     0x713bac: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x713bb0: add             SP, SP, #0x18
    // 0x713bb4: r0 = FlutterErrorDetails()
    //     0x713bb4: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x713bb8: mov             x1, x0
    // 0x713bbc: ldur            x0, [fp, #-0x70]
    // 0x713bc0: StoreField: r1->field_7 = r0
    //     0x713bc0: stur            w0, [x1, #7]
    // 0x713bc4: ldur            x0, [fp, #-0x78]
    // 0x713bc8: StoreField: r1->field_b = r0
    //     0x713bc8: stur            w0, [x1, #0xb]
    // 0x713bcc: r0 = "gesture"
    //     0x713bcc: add             x0, PP, #0x28, lsl #12  ; [pp+0x28eb0] "gesture"
    //     0x713bd0: ldr             x0, [x0, #0xeb0]
    // 0x713bd4: StoreField: r1->field_f = r0
    //     0x713bd4: stur            w0, [x1, #0xf]
    // 0x713bd8: ldur            x0, [fp, #-0x80]
    // 0x713bdc: StoreField: r1->field_13 = r0
    //     0x713bdc: stur            w0, [x1, #0x13]
    // 0x713be0: r0 = false
    //     0x713be0: add             x0, NULL, #0x30  ; false
    // 0x713be4: StoreField: r1->field_1f = r0
    //     0x713be4: stur            w0, [x1, #0x1f]
    // 0x713be8: SaveReg r1
    //     0x713be8: str             x1, [SP, #-8]!
    // 0x713bec: r0 = reportError()
    //     0x713bec: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x713bf0: add             SP, SP, #8
    // 0x713bf4: r0 = Null
    //     0x713bf4: mov             x0, NULL
    // 0x713bf8: LeaveFrame
    //     0x713bf8: mov             SP, fp
    //     0x713bfc: ldp             fp, lr, [SP], #0x10
    // 0x713c00: ret
    //     0x713c00: ret             
    // 0x713c04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x713c04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713c08: b               #0x713b58
  }
  _ getKindForPointer(/* No info */) {
    // ** addr: 0x719b14, size: 0x84
    // 0x719b14: EnterFrame
    //     0x719b14: stp             fp, lr, [SP, #-0x10]!
    //     0x719b18: mov             fp, SP
    // 0x719b1c: AllocStack(0x8)
    //     0x719b1c: sub             SP, SP, #8
    // 0x719b20: CheckStackOverflow
    //     0x719b20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x719b24: cmp             SP, x16
    //     0x719b28: b.ls            #0x719b8c
    // 0x719b2c: ldr             x0, [fp, #0x18]
    // 0x719b30: LoadField: r2 = r0->field_f
    //     0x719b30: ldur            w2, [x0, #0xf]
    // 0x719b34: DecompressPointer r2
    //     0x719b34: add             x2, x2, HEAP, lsl #32
    // 0x719b38: ldr             x3, [fp, #0x10]
    // 0x719b3c: stur            x2, [fp, #-8]
    // 0x719b40: r0 = BoxInt64Instr(r3)
    //     0x719b40: sbfiz           x0, x3, #1, #0x1f
    //     0x719b44: cmp             x3, x0, asr #1
    //     0x719b48: b.eq            #0x719b54
    //     0x719b4c: bl              #0xd69bb8
    //     0x719b50: stur            x3, [x0, #7]
    // 0x719b54: stp             x0, x2, [SP, #-0x10]!
    // 0x719b58: r0 = _getValueOrData()
    //     0x719b58: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x719b5c: add             SP, SP, #0x10
    // 0x719b60: ldur            x1, [fp, #-8]
    // 0x719b64: LoadField: r2 = r1->field_f
    //     0x719b64: ldur            w2, [x1, #0xf]
    // 0x719b68: DecompressPointer r2
    //     0x719b68: add             x2, x2, HEAP, lsl #32
    // 0x719b6c: cmp             w2, w0
    // 0x719b70: b.ne            #0x719b78
    // 0x719b74: r0 = Null
    //     0x719b74: mov             x0, NULL
    // 0x719b78: cmp             w0, NULL
    // 0x719b7c: b.eq            #0x719b94
    // 0x719b80: LeaveFrame
    //     0x719b80: mov             SP, fp
    //     0x719b84: ldp             fp, lr, [SP], #0x10
    // 0x719b88: ret
    //     0x719b88: ret             
    // 0x719b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x719b8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x719b90: b               #0x719b2c
    // 0x719b94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x719b94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xa829e0, size: 0x9c
    // 0xa829e0: EnterFrame
    //     0xa829e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa829e4: mov             fp, SP
    // 0xa829e8: AllocStack(0x8)
    //     0xa829e8: sub             SP, SP, #8
    // 0xa829ec: CheckStackOverflow
    //     0xa829ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa829f0: cmp             SP, x16
    //     0xa829f4: b.ls            #0xa82a74
    // 0xa829f8: ldr             x0, [fp, #0x18]
    // 0xa829fc: LoadField: r1 = r0->field_b
    //     0xa829fc: ldur            w1, [x0, #0xb]
    // 0xa82a00: DecompressPointer r1
    //     0xa82a00: add             x1, x1, HEAP, lsl #32
    // 0xa82a04: stur            x1, [fp, #-8]
    // 0xa82a08: cmp             w1, NULL
    // 0xa82a0c: b.ne            #0xa82a18
    // 0xa82a10: r0 = true
    //     0xa82a10: add             x0, NULL, #0x20  ; true
    // 0xa82a14: b               #0xa82a68
    // 0xa82a18: ldr             x0, [fp, #0x10]
    // 0xa82a1c: r2 = LoadClassIdInstr(r0)
    //     0xa82a1c: ldur            x2, [x0, #-1]
    //     0xa82a20: ubfx            x2, x2, #0xc, #0x14
    // 0xa82a24: SaveReg r0
    //     0xa82a24: str             x0, [SP, #-8]!
    // 0xa82a28: mov             x0, x2
    // 0xa82a2c: r0 = GDT[cid_x0 + -0xf60]()
    //     0xa82a2c: sub             lr, x0, #0xf60
    //     0xa82a30: ldr             lr, [x21, lr, lsl #3]
    //     0xa82a34: blr             lr
    // 0xa82a38: add             SP, SP, #8
    // 0xa82a3c: mov             x1, x0
    // 0xa82a40: ldur            x0, [fp, #-8]
    // 0xa82a44: r2 = LoadClassIdInstr(r0)
    //     0xa82a44: ldur            x2, [x0, #-1]
    //     0xa82a48: ubfx            x2, x2, #0xc, #0x14
    // 0xa82a4c: stp             x1, x0, [SP, #-0x10]!
    // 0xa82a50: mov             x0, x2
    // 0xa82a54: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xa82a54: mov             x17, #0xc98a
    //     0xa82a58: add             lr, x0, x17
    //     0xa82a5c: ldr             lr, [x21, lr, lsl #3]
    //     0xa82a60: blr             lr
    // 0xa82a64: add             SP, SP, #0x10
    // 0xa82a68: LeaveFrame
    //     0xa82a68: mov             SP, fp
    //     0xa82a6c: ldp             fp, lr, [SP], #0x10
    // 0xa82a70: ret
    //     0xa82a70: ret             
    // 0xa82a74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa82a74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa82a78: b               #0xa829f8
  }
}

// class id: 2348, size: 0x20, field offset: 0x14
abstract class OneSequenceGestureRecognizer extends GestureRecognizer {

  _ OneSequenceGestureRecognizer(/* No info */) {
    // ** addr: 0x6d3ef4, size: 0x16c
    // 0x6d3ef4: EnterFrame
    //     0x6d3ef4: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3ef8: mov             fp, SP
    // 0x6d3efc: AllocStack(0x18)
    //     0x6d3efc: sub             SP, SP, #0x18
    // 0x6d3f00: SetupParameters(OneSequenceGestureRecognizer this /* r3, fp-0x18 */, {dynamic kind = Null /* r4, fp-0x10 */, dynamic supportedDevices = Null /* r0, fp-0x8 */})
    //     0x6d3f00: mov             x0, x4
    //     0x6d3f04: ldur            w1, [x0, #0x13]
    //     0x6d3f08: add             x1, x1, HEAP, lsl #32
    //     0x6d3f0c: sub             x2, x1, #2
    //     0x6d3f10: add             x3, fp, w2, sxtw #2
    //     0x6d3f14: ldr             x3, [x3, #0x10]
    //     0x6d3f18: stur            x3, [fp, #-0x18]
    //     0x6d3f1c: ldur            w2, [x0, #0x1f]
    //     0x6d3f20: add             x2, x2, HEAP, lsl #32
    //     0x6d3f24: ldr             x16, [PP, #0x3998]  ; [pp+0x3998] "kind"
    //     0x6d3f28: cmp             w2, w16
    //     0x6d3f2c: b.ne            #0x6d3f50
    //     0x6d3f30: ldur            w2, [x0, #0x23]
    //     0x6d3f34: add             x2, x2, HEAP, lsl #32
    //     0x6d3f38: sub             w4, w1, w2
    //     0x6d3f3c: add             x2, fp, w4, sxtw #2
    //     0x6d3f40: ldr             x2, [x2, #8]
    //     0x6d3f44: mov             x4, x2
    //     0x6d3f48: mov             x2, #1
    //     0x6d3f4c: b               #0x6d3f58
    //     0x6d3f50: mov             x4, NULL
    //     0x6d3f54: mov             x2, #0
    //     0x6d3f58: stur            x4, [fp, #-0x10]
    //     0x6d3f5c: lsl             x5, x2, #1
    //     0x6d3f60: lsl             w2, w5, #1
    //     0x6d3f64: add             w5, w2, #8
    //     0x6d3f68: add             x16, x0, w5, sxtw #1
    //     0x6d3f6c: ldur            w6, [x16, #0xf]
    //     0x6d3f70: add             x6, x6, HEAP, lsl #32
    //     0x6d3f74: add             x16, PP, #0x21, lsl #12  ; [pp+0x214b8] "supportedDevices"
    //     0x6d3f78: ldr             x16, [x16, #0x4b8]
    //     0x6d3f7c: cmp             w6, w16
    //     0x6d3f80: b.ne            #0x6d3fa8
    //     0x6d3f84: add             w5, w2, #0xa
    //     0x6d3f88: add             x16, x0, w5, sxtw #1
    //     0x6d3f8c: ldur            w2, [x16, #0xf]
    //     0x6d3f90: add             x2, x2, HEAP, lsl #32
    //     0x6d3f94: sub             w0, w1, w2
    //     0x6d3f98: add             x1, fp, w0, sxtw #2
    //     0x6d3f9c: ldr             x1, [x1, #8]
    //     0x6d3fa0: mov             x0, x1
    //     0x6d3fa4: b               #0x6d3fac
    //     0x6d3fa8: mov             x0, NULL
    //     0x6d3fac: stur            x0, [fp, #-8]
    // 0x6d3fb0: CheckStackOverflow
    //     0x6d3fb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3fb4: cmp             SP, x16
    //     0x6d3fb8: b.ls            #0x6d4058
    // 0x6d3fbc: r16 = <int, GestureArenaEntry>
    //     0x6d3fbc: add             x16, PP, #0x21, lsl #12  ; [pp+0x214c0] TypeArguments: <int, GestureArenaEntry>
    //     0x6d3fc0: ldr             x16, [x16, #0x4c0]
    // 0x6d3fc4: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6d3fc8: stp             lr, x16, [SP, #-0x10]!
    // 0x6d3fcc: r0 = Map._fromLiteral()
    //     0x6d3fcc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6d3fd0: add             SP, SP, #0x10
    // 0x6d3fd4: ldur            x1, [fp, #-0x18]
    // 0x6d3fd8: StoreField: r1->field_13 = r0
    //     0x6d3fd8: stur            w0, [x1, #0x13]
    //     0x6d3fdc: tbz             w0, #0, #0x6d3ff8
    //     0x6d3fe0: ldurb           w16, [x1, #-1]
    //     0x6d3fe4: ldurb           w17, [x0, #-1]
    //     0x6d3fe8: and             x16, x17, x16, lsr #2
    //     0x6d3fec: tst             x16, HEAP, lsr #32
    //     0x6d3ff0: b.eq            #0x6d3ff8
    //     0x6d3ff4: bl              #0xd6826c
    // 0x6d3ff8: r16 = <int>
    //     0x6d3ff8: ldr             x16, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x6d3ffc: SaveReg r16
    //     0x6d3ffc: str             x16, [SP, #-8]!
    // 0x6d4000: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6d4000: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6d4004: r0 = HashSet()
    //     0x6d4004: bl              #0x5519d0  ; [dart:collection] HashSet::HashSet
    // 0x6d4008: add             SP, SP, #8
    // 0x6d400c: ldur            x1, [fp, #-0x18]
    // 0x6d4010: StoreField: r1->field_17 = r0
    //     0x6d4010: stur            w0, [x1, #0x17]
    //     0x6d4014: tbz             w0, #0, #0x6d4030
    //     0x6d4018: ldurb           w16, [x1, #-1]
    //     0x6d401c: ldurb           w17, [x0, #-1]
    //     0x6d4020: and             x16, x17, x16, lsr #2
    //     0x6d4024: tst             x16, HEAP, lsr #32
    //     0x6d4028: b.eq            #0x6d4030
    //     0x6d402c: bl              #0xd6826c
    // 0x6d4030: ldur            x16, [fp, #-0x10]
    // 0x6d4034: stp             x16, x1, [SP, #-0x10]!
    // 0x6d4038: ldur            x16, [fp, #-8]
    // 0x6d403c: SaveReg r16
    //     0x6d403c: str             x16, [SP, #-8]!
    // 0x6d4040: r0 = GestureRecognizer()
    //     0x6d4040: bl              #0x6d4060  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::GestureRecognizer
    // 0x6d4044: add             SP, SP, #0x18
    // 0x6d4048: r0 = Null
    //     0x6d4048: mov             x0, NULL
    // 0x6d404c: LeaveFrame
    //     0x6d404c: mov             SP, fp
    //     0x6d4050: ldp             fp, lr, [SP], #0x10
    // 0x6d4054: ret
    //     0x6d4054: ret             
    // 0x6d4058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d4058: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d405c: b               #0x6d3fbc
  }
  _ startTrackingPointer(/* No info */) {
    // ** addr: 0x71111c, size: 0x108
    // 0x71111c: EnterFrame
    //     0x71111c: stp             fp, lr, [SP, #-0x10]!
    //     0x711120: mov             fp, SP
    // 0x711124: AllocStack(0x10)
    //     0x711124: sub             SP, SP, #0x10
    // 0x711128: CheckStackOverflow
    //     0x711128: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71112c: cmp             SP, x16
    //     0x711130: b.ls            #0x711218
    // 0x711134: r0 = LoadStaticField(0xd54)
    //     0x711134: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x711138: ldr             x0, [x0, #0x1aa8]
    // 0x71113c: cmp             w0, NULL
    // 0x711140: b.eq            #0x711220
    // 0x711144: LoadField: r1 = r0->field_13
    //     0x711144: ldur            w1, [x0, #0x13]
    // 0x711148: DecompressPointer r1
    //     0x711148: add             x1, x1, HEAP, lsl #32
    // 0x71114c: ldr             x2, [fp, #0x20]
    // 0x711150: stur            x1, [fp, #-8]
    // 0x711154: r0 = LoadClassIdInstr(r2)
    //     0x711154: ldur            x0, [x2, #-1]
    //     0x711158: ubfx            x0, x0, #0xc, #0x14
    // 0x71115c: SaveReg r2
    //     0x71115c: str             x2, [SP, #-8]!
    // 0x711160: r0 = GDT[cid_x0 + 0xc063]()
    //     0x711160: mov             x17, #0xc063
    //     0x711164: add             lr, x0, x17
    //     0x711168: ldr             lr, [x21, lr, lsl #3]
    //     0x71116c: blr             lr
    // 0x711170: add             SP, SP, #8
    // 0x711174: ldur            x16, [fp, #-8]
    // 0x711178: SaveReg r16
    //     0x711178: str             x16, [SP, #-8]!
    // 0x71117c: ldr             x1, [fp, #0x18]
    // 0x711180: stp             x0, x1, [SP, #-0x10]!
    // 0x711184: ldr             x16, [fp, #0x10]
    // 0x711188: SaveReg r16
    //     0x711188: str             x16, [SP, #-8]!
    // 0x71118c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x71118c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x711190: r0 = addRoute()
    //     0x711190: bl              #0x711788  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addRoute
    // 0x711194: add             SP, SP, #0x20
    // 0x711198: ldr             x2, [fp, #0x20]
    // 0x71119c: LoadField: r3 = r2->field_17
    //     0x71119c: ldur            w3, [x2, #0x17]
    // 0x7111a0: DecompressPointer r3
    //     0x7111a0: add             x3, x3, HEAP, lsl #32
    // 0x7111a4: ldr             x4, [fp, #0x18]
    // 0x7111a8: r0 = BoxInt64Instr(r4)
    //     0x7111a8: sbfiz           x0, x4, #1, #0x1f
    //     0x7111ac: cmp             x4, x0, asr #1
    //     0x7111b0: b.eq            #0x7111bc
    //     0x7111b4: bl              #0xd69bb8
    //     0x7111b8: stur            x4, [x0, #7]
    // 0x7111bc: stur            x0, [fp, #-8]
    // 0x7111c0: stp             x0, x3, [SP, #-0x10]!
    // 0x7111c4: r0 = add()
    //     0x7111c4: bl              #0xc4af80  ; [dart:collection] _HashSet::add
    // 0x7111c8: add             SP, SP, #0x10
    // 0x7111cc: ldr             x0, [fp, #0x20]
    // 0x7111d0: LoadField: r1 = r0->field_13
    //     0x7111d0: ldur            w1, [x0, #0x13]
    // 0x7111d4: DecompressPointer r1
    //     0x7111d4: add             x1, x1, HEAP, lsl #32
    // 0x7111d8: stur            x1, [fp, #-0x10]
    // 0x7111dc: SaveReg r0
    //     0x7111dc: str             x0, [SP, #-8]!
    // 0x7111e0: ldr             x0, [fp, #0x18]
    // 0x7111e4: SaveReg r0
    //     0x7111e4: str             x0, [SP, #-8]!
    // 0x7111e8: r0 = _addPointerToArena()
    //     0x7111e8: bl              #0x711224  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::_addPointerToArena
    // 0x7111ec: add             SP, SP, #0x10
    // 0x7111f0: ldur            x16, [fp, #-0x10]
    // 0x7111f4: ldur            lr, [fp, #-8]
    // 0x7111f8: stp             lr, x16, [SP, #-0x10]!
    // 0x7111fc: SaveReg r0
    //     0x7111fc: str             x0, [SP, #-8]!
    // 0x711200: r0 = []=()
    //     0x711200: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x711204: add             SP, SP, #0x18
    // 0x711208: r0 = Null
    //     0x711208: mov             x0, NULL
    // 0x71120c: LeaveFrame
    //     0x71120c: mov             SP, fp
    //     0x711210: ldp             fp, lr, [SP], #0x10
    // 0x711214: ret
    //     0x711214: ret             
    // 0x711218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71121c: b               #0x711134
    // 0x711220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x711220: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _addPointerToArena(/* No info */) {
    // ** addr: 0x711224, size: 0x8c
    // 0x711224: EnterFrame
    //     0x711224: stp             fp, lr, [SP, #-0x10]!
    //     0x711228: mov             fp, SP
    // 0x71122c: CheckStackOverflow
    //     0x71122c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711230: cmp             SP, x16
    //     0x711234: b.ls            #0x7112a4
    // 0x711238: ldr             x0, [fp, #0x18]
    // 0x71123c: LoadField: r1 = r0->field_1b
    //     0x71123c: ldur            w1, [x0, #0x1b]
    // 0x711240: DecompressPointer r1
    //     0x711240: add             x1, x1, HEAP, lsl #32
    // 0x711244: cmp             w1, NULL
    // 0x711248: b.eq            #0x71126c
    // 0x71124c: ldr             x2, [fp, #0x10]
    // 0x711250: stp             x2, x1, [SP, #-0x10]!
    // 0x711254: SaveReg r0
    //     0x711254: str             x0, [SP, #-8]!
    // 0x711258: r0 = add()
    //     0x711258: bl              #0x71148c  ; [package:flutter/src/gestures/team.dart] GestureArenaTeam::add
    // 0x71125c: add             SP, SP, #0x18
    // 0x711260: LeaveFrame
    //     0x711260: mov             SP, fp
    //     0x711264: ldp             fp, lr, [SP], #0x10
    // 0x711268: ret
    //     0x711268: ret             
    // 0x71126c: ldr             x2, [fp, #0x10]
    // 0x711270: r1 = LoadStaticField(0xd54)
    //     0x711270: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x711274: ldr             x1, [x1, #0x1aa8]
    // 0x711278: cmp             w1, NULL
    // 0x71127c: b.eq            #0x7112ac
    // 0x711280: LoadField: r3 = r1->field_17
    //     0x711280: ldur            w3, [x1, #0x17]
    // 0x711284: DecompressPointer r3
    //     0x711284: add             x3, x3, HEAP, lsl #32
    // 0x711288: stp             x2, x3, [SP, #-0x10]!
    // 0x71128c: SaveReg r0
    //     0x71128c: str             x0, [SP, #-8]!
    // 0x711290: r0 = add()
    //     0x711290: bl              #0x7112b0  ; [package:flutter/src/gestures/arena.dart] GestureArenaManager::add
    // 0x711294: add             SP, SP, #0x18
    // 0x711298: LeaveFrame
    //     0x711298: mov             SP, fp
    //     0x71129c: ldp             fp, lr, [SP], #0x10
    // 0x7112a0: ret
    //     0x7112a0: ret             
    // 0x7112a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7112a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7112a8: b               #0x711238
    // 0x7112ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7112ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ stopTrackingPointer(/* No info */) {
    // ** addr: 0x71334c, size: 0x13c
    // 0x71334c: EnterFrame
    //     0x71334c: stp             fp, lr, [SP, #-0x10]!
    //     0x713350: mov             fp, SP
    // 0x713354: AllocStack(0x18)
    //     0x713354: sub             SP, SP, #0x18
    // 0x713358: CheckStackOverflow
    //     0x713358: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71335c: cmp             SP, x16
    //     0x713360: b.ls            #0x71347c
    // 0x713364: ldr             x1, [fp, #0x18]
    // 0x713368: LoadField: r2 = r1->field_17
    //     0x713368: ldur            w2, [x1, #0x17]
    // 0x71336c: DecompressPointer r2
    //     0x71336c: add             x2, x2, HEAP, lsl #32
    // 0x713370: stur            x2, [fp, #-8]
    // 0x713374: r0 = LoadClassIdInstr(r2)
    //     0x713374: ldur            x0, [x2, #-1]
    //     0x713378: ubfx            x0, x0, #0xc, #0x14
    // 0x71337c: ldr             x16, [fp, #0x10]
    // 0x713380: stp             x16, x2, [SP, #-0x10]!
    // 0x713384: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x713384: mov             x17, #0xc98a
    //     0x713388: add             lr, x0, x17
    //     0x71338c: ldr             lr, [x21, lr, lsl #3]
    //     0x713390: blr             lr
    // 0x713394: add             SP, SP, #0x10
    // 0x713398: tbnz            w0, #4, #0x71346c
    // 0x71339c: ldr             x1, [fp, #0x18]
    // 0x7133a0: ldr             x3, [fp, #0x10]
    // 0x7133a4: ldur            x2, [fp, #-8]
    // 0x7133a8: r0 = LoadStaticField(0xd54)
    //     0x7133a8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7133ac: ldr             x0, [x0, #0x1aa8]
    // 0x7133b0: cmp             w0, NULL
    // 0x7133b4: b.eq            #0x713484
    // 0x7133b8: LoadField: r4 = r0->field_13
    //     0x7133b8: ldur            w4, [x0, #0x13]
    // 0x7133bc: DecompressPointer r4
    //     0x7133bc: add             x4, x4, HEAP, lsl #32
    // 0x7133c0: stur            x4, [fp, #-0x10]
    // 0x7133c4: r0 = LoadClassIdInstr(r1)
    //     0x7133c4: ldur            x0, [x1, #-1]
    //     0x7133c8: ubfx            x0, x0, #0xc, #0x14
    // 0x7133cc: SaveReg r1
    //     0x7133cc: str             x1, [SP, #-8]!
    // 0x7133d0: r0 = GDT[cid_x0 + 0xc063]()
    //     0x7133d0: mov             x17, #0xc063
    //     0x7133d4: add             lr, x0, x17
    //     0x7133d8: ldr             lr, [x21, lr, lsl #3]
    //     0x7133dc: blr             lr
    // 0x7133e0: add             SP, SP, #8
    // 0x7133e4: mov             x1, x0
    // 0x7133e8: ldr             x0, [fp, #0x10]
    // 0x7133ec: r2 = LoadInt32Instr(r0)
    //     0x7133ec: sbfx            x2, x0, #1, #0x1f
    //     0x7133f0: tbz             w0, #0, #0x7133f8
    //     0x7133f4: ldur            x2, [x0, #7]
    // 0x7133f8: stur            x2, [fp, #-0x18]
    // 0x7133fc: ldur            x16, [fp, #-0x10]
    // 0x713400: stp             x2, x16, [SP, #-0x10]!
    // 0x713404: SaveReg r1
    //     0x713404: str             x1, [SP, #-8]!
    // 0x713408: r0 = removeRoute()
    //     0x713408: bl              #0x7134d4  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::removeRoute
    // 0x71340c: add             SP, SP, #0x18
    // 0x713410: ldur            x1, [fp, #-8]
    // 0x713414: r0 = LoadClassIdInstr(r1)
    //     0x713414: ldur            x0, [x1, #-1]
    //     0x713418: ubfx            x0, x0, #0xc, #0x14
    // 0x71341c: ldr             x16, [fp, #0x10]
    // 0x713420: stp             x16, x1, [SP, #-0x10]!
    // 0x713424: r0 = GDT[cid_x0 + 0x56]()
    //     0x713424: add             lr, x0, #0x56
    //     0x713428: ldr             lr, [x21, lr, lsl #3]
    //     0x71342c: blr             lr
    // 0x713430: add             SP, SP, #0x10
    // 0x713434: ldur            x0, [fp, #-8]
    // 0x713438: LoadField: r1 = r0->field_f
    //     0x713438: ldur            x1, [x0, #0xf]
    // 0x71343c: cbnz            x1, #0x71346c
    // 0x713440: ldr             x1, [fp, #0x18]
    // 0x713444: ldur            x0, [fp, #-0x18]
    // 0x713448: r2 = LoadClassIdInstr(r1)
    //     0x713448: ldur            x2, [x1, #-1]
    //     0x71344c: ubfx            x2, x2, #0xc, #0x14
    // 0x713450: stp             x0, x1, [SP, #-0x10]!
    // 0x713454: mov             x0, x2
    // 0x713458: r0 = GDT[cid_x0 + 0xc3e8]()
    //     0x713458: mov             x17, #0xc3e8
    //     0x71345c: add             lr, x0, x17
    //     0x713460: ldr             lr, [x21, lr, lsl #3]
    //     0x713464: blr             lr
    // 0x713468: add             SP, SP, #0x10
    // 0x71346c: r0 = Null
    //     0x71346c: mov             x0, NULL
    // 0x713470: LeaveFrame
    //     0x713470: mov             SP, fp
    //     0x713474: ldp             fp, lr, [SP], #0x10
    // 0x713478: ret
    //     0x713478: ret             
    // 0x71347c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71347c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x713480: b               #0x713364
    // 0x713484: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x713484: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void stopTrackingPointer(dynamic, int) {
    // ** addr: 0x713488, size: 0x4c
    // 0x713488: EnterFrame
    //     0x713488: stp             fp, lr, [SP, #-0x10]!
    //     0x71348c: mov             fp, SP
    // 0x713490: ldr             x0, [fp, #0x18]
    // 0x713494: LoadField: r1 = r0->field_17
    //     0x713494: ldur            w1, [x0, #0x17]
    // 0x713498: DecompressPointer r1
    //     0x713498: add             x1, x1, HEAP, lsl #32
    // 0x71349c: CheckStackOverflow
    //     0x71349c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7134a0: cmp             SP, x16
    //     0x7134a4: b.ls            #0x7134cc
    // 0x7134a8: LoadField: r0 = r1->field_f
    //     0x7134a8: ldur            w0, [x1, #0xf]
    // 0x7134ac: DecompressPointer r0
    //     0x7134ac: add             x0, x0, HEAP, lsl #32
    // 0x7134b0: ldr             x16, [fp, #0x10]
    // 0x7134b4: stp             x16, x0, [SP, #-0x10]!
    // 0x7134b8: r0 = stopTrackingPointer()
    //     0x7134b8: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x7134bc: add             SP, SP, #0x10
    // 0x7134c0: LeaveFrame
    //     0x7134c0: mov             SP, fp
    //     0x7134c4: ldp             fp, lr, [SP], #0x10
    // 0x7134c8: ret
    //     0x7134c8: ret             
    // 0x7134cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7134cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7134d0: b               #0x7134a8
  }
  _ resolve(/* No info */) {
    // ** addr: 0x715700, size: 0x10c
    // 0x715700: EnterFrame
    //     0x715700: stp             fp, lr, [SP, #-0x10]!
    //     0x715704: mov             fp, SP
    // 0x715708: AllocStack(0x10)
    //     0x715708: sub             SP, SP, #0x10
    // 0x71570c: CheckStackOverflow
    //     0x71570c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715710: cmp             SP, x16
    //     0x715714: b.ls            #0x7157fc
    // 0x715718: ldr             x0, [fp, #0x18]
    // 0x71571c: LoadField: r1 = r0->field_13
    //     0x71571c: ldur            w1, [x0, #0x13]
    // 0x715720: DecompressPointer r1
    //     0x715720: add             x1, x1, HEAP, lsl #32
    // 0x715724: stur            x1, [fp, #-8]
    // 0x715728: SaveReg r1
    //     0x715728: str             x1, [SP, #-8]!
    // 0x71572c: r0 = values()
    //     0x71572c: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x715730: add             SP, SP, #8
    // 0x715734: r16 = <GestureArenaEntry>
    //     0x715734: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f28] TypeArguments: <GestureArenaEntry>
    //     0x715738: ldr             x16, [x16, #0xf28]
    // 0x71573c: stp             x0, x16, [SP, #-0x10]!
    // 0x715740: r0 = _GrowableList.of()
    //     0x715740: bl              #0x4bfaf0  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x715744: add             SP, SP, #0x10
    // 0x715748: stur            x0, [fp, #-0x10]
    // 0x71574c: ldur            x16, [fp, #-8]
    // 0x715750: SaveReg r16
    //     0x715750: str             x16, [SP, #-8]!
    // 0x715754: r0 = clear()
    //     0x715754: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x715758: add             SP, SP, #8
    // 0x71575c: ldur            x16, [fp, #-0x10]
    // 0x715760: SaveReg r16
    //     0x715760: str             x16, [SP, #-8]!
    // 0x715764: r0 = iterator()
    //     0x715764: bl              #0x9bb07c  ; [dart:core] _GrowableList::iterator
    // 0x715768: add             SP, SP, #8
    // 0x71576c: mov             x1, x0
    // 0x715770: stur            x1, [fp, #-8]
    // 0x715774: CheckStackOverflow
    //     0x715774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715778: cmp             SP, x16
    //     0x71577c: b.ls            #0x715804
    // 0x715780: r0 = LoadClassIdInstr(r1)
    //     0x715780: ldur            x0, [x1, #-1]
    //     0x715784: ubfx            x0, x0, #0xc, #0x14
    // 0x715788: SaveReg r1
    //     0x715788: str             x1, [SP, #-8]!
    // 0x71578c: r0 = GDT[cid_x0 + 0x541]()
    //     0x71578c: add             lr, x0, #0x541
    //     0x715790: ldr             lr, [x21, lr, lsl #3]
    //     0x715794: blr             lr
    // 0x715798: add             SP, SP, #8
    // 0x71579c: tbnz            w0, #4, #0x7157ec
    // 0x7157a0: ldur            x1, [fp, #-8]
    // 0x7157a4: r0 = LoadClassIdInstr(r1)
    //     0x7157a4: ldur            x0, [x1, #-1]
    //     0x7157a8: ubfx            x0, x0, #0xc, #0x14
    // 0x7157ac: SaveReg r1
    //     0x7157ac: str             x1, [SP, #-8]!
    // 0x7157b0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x7157b0: add             lr, x0, #0x5ca
    //     0x7157b4: ldr             lr, [x21, lr, lsl #3]
    //     0x7157b8: blr             lr
    // 0x7157bc: add             SP, SP, #8
    // 0x7157c0: r1 = LoadClassIdInstr(r0)
    //     0x7157c0: ldur            x1, [x0, #-1]
    //     0x7157c4: ubfx            x1, x1, #0xc, #0x14
    // 0x7157c8: ldr             x16, [fp, #0x10]
    // 0x7157cc: stp             x16, x0, [SP, #-0x10]!
    // 0x7157d0: mov             x0, x1
    // 0x7157d4: r0 = GDT[cid_x0 + -0xfff]()
    //     0x7157d4: sub             lr, x0, #0xfff
    //     0x7157d8: ldr             lr, [x21, lr, lsl #3]
    //     0x7157dc: blr             lr
    // 0x7157e0: add             SP, SP, #0x10
    // 0x7157e4: ldur            x1, [fp, #-8]
    // 0x7157e8: b               #0x715774
    // 0x7157ec: r0 = Null
    //     0x7157ec: mov             x0, NULL
    // 0x7157f0: LeaveFrame
    //     0x7157f0: mov             SP, fp
    //     0x7157f4: ldp             fp, lr, [SP], #0x10
    // 0x7157f8: ret
    //     0x7157f8: ret             
    // 0x7157fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7157fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715800: b               #0x715718
    // 0x715804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x715804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715808: b               #0x715780
  }
  _ handleNonAllowedPointer(/* No info */) {
    // ** addr: 0x7172e0, size: 0x5c
    // 0x7172e0: EnterFrame
    //     0x7172e0: stp             fp, lr, [SP, #-0x10]!
    //     0x7172e4: mov             fp, SP
    // 0x7172e8: CheckStackOverflow
    //     0x7172e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7172ec: cmp             SP, x16
    //     0x7172f0: b.ls            #0x717334
    // 0x7172f4: ldr             x0, [fp, #0x10]
    // 0x7172f8: r1 = LoadClassIdInstr(r0)
    //     0x7172f8: ldur            x1, [x0, #-1]
    //     0x7172fc: ubfx            x1, x1, #0xc, #0x14
    // 0x717300: r16 = Instance_GestureDisposition
    //     0x717300: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x717304: ldr             x16, [x16, #0xeb8]
    // 0x717308: stp             x16, x0, [SP, #-0x10]!
    // 0x71730c: mov             x0, x1
    // 0x717310: r0 = GDT[cid_x0 + 0xc39b]()
    //     0x717310: mov             x17, #0xc39b
    //     0x717314: add             lr, x0, x17
    //     0x717318: ldr             lr, [x21, lr, lsl #3]
    //     0x71731c: blr             lr
    // 0x717320: add             SP, SP, #0x10
    // 0x717324: r0 = Null
    //     0x717324: mov             x0, NULL
    // 0x717328: LeaveFrame
    //     0x717328: mov             SP, fp
    //     0x71732c: ldp             fp, lr, [SP], #0x10
    // 0x717330: ret
    //     0x717330: ret             
    // 0x717334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x717334: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x717338: b               #0x7172f4
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x782114, size: 0xb4
    // 0x782114: EnterFrame
    //     0x782114: stp             fp, lr, [SP, #-0x10]!
    //     0x782118: mov             fp, SP
    // 0x78211c: AllocStack(0x8)
    //     0x78211c: sub             SP, SP, #8
    // 0x782120: CheckStackOverflow
    //     0x782120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782124: cmp             SP, x16
    //     0x782128: b.ls            #0x7821c0
    // 0x78212c: ldr             x1, [fp, #0x10]
    // 0x782130: r0 = LoadClassIdInstr(r1)
    //     0x782130: ldur            x0, [x1, #-1]
    //     0x782134: ubfx            x0, x0, #0xc, #0x14
    // 0x782138: SaveReg r1
    //     0x782138: str             x1, [SP, #-8]!
    // 0x78213c: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78213c: sub             lr, x0, #0xfff
    //     0x782140: ldr             lr, [x21, lr, lsl #3]
    //     0x782144: blr             lr
    // 0x782148: add             SP, SP, #8
    // 0x78214c: mov             x1, x0
    // 0x782150: ldr             x0, [fp, #0x10]
    // 0x782154: stur            x1, [fp, #-8]
    // 0x782158: r2 = LoadClassIdInstr(r0)
    //     0x782158: ldur            x2, [x0, #-1]
    //     0x78215c: ubfx            x2, x2, #0xc, #0x14
    // 0x782160: SaveReg r0
    //     0x782160: str             x0, [SP, #-8]!
    // 0x782164: mov             x0, x2
    // 0x782168: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x782168: mov             x17, #0x3f6e
    //     0x78216c: add             lr, x0, x17
    //     0x782170: ldr             lr, [x21, lr, lsl #3]
    //     0x782174: blr             lr
    // 0x782178: add             SP, SP, #8
    // 0x78217c: mov             x1, x0
    // 0x782180: ldr             x0, [fp, #0x18]
    // 0x782184: r2 = LoadClassIdInstr(r0)
    //     0x782184: ldur            x2, [x0, #-1]
    //     0x782188: ubfx            x2, x2, #0xc, #0x14
    // 0x78218c: SaveReg r0
    //     0x78218c: str             x0, [SP, #-8]!
    // 0x782190: ldur            x0, [fp, #-8]
    // 0x782194: stp             x1, x0, [SP, #-0x10]!
    // 0x782198: mov             x0, x2
    // 0x78219c: r0 = GDT[cid_x0 + 0xc494]()
    //     0x78219c: mov             x17, #0xc494
    //     0x7821a0: add             lr, x0, x17
    //     0x7821a4: ldr             lr, [x21, lr, lsl #3]
    //     0x7821a8: blr             lr
    // 0x7821ac: add             SP, SP, #0x18
    // 0x7821b0: r0 = Null
    //     0x7821b0: mov             x0, NULL
    // 0x7821b4: LeaveFrame
    //     0x7821b4: mov             SP, fp
    //     0x7821b8: ldp             fp, lr, [SP], #0x10
    // 0x7821bc: ret
    //     0x7821bc: ret             
    // 0x7821c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7821c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7821c4: b               #0x78212c
  }
  _ resolvePointer(/* No info */) {
    // ** addr: 0x788bec, size: 0xcc
    // 0x788bec: EnterFrame
    //     0x788bec: stp             fp, lr, [SP, #-0x10]!
    //     0x788bf0: mov             fp, SP
    // 0x788bf4: AllocStack(0x18)
    //     0x788bf4: sub             SP, SP, #0x18
    // 0x788bf8: CheckStackOverflow
    //     0x788bf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x788bfc: cmp             SP, x16
    //     0x788c00: b.ls            #0x788cb0
    // 0x788c04: ldr             x0, [fp, #0x18]
    // 0x788c08: LoadField: r2 = r0->field_13
    //     0x788c08: ldur            w2, [x0, #0x13]
    // 0x788c0c: DecompressPointer r2
    //     0x788c0c: add             x2, x2, HEAP, lsl #32
    // 0x788c10: ldr             x3, [fp, #0x10]
    // 0x788c14: stur            x2, [fp, #-0x10]
    // 0x788c18: r0 = BoxInt64Instr(r3)
    //     0x788c18: sbfiz           x0, x3, #1, #0x1f
    //     0x788c1c: cmp             x3, x0, asr #1
    //     0x788c20: b.eq            #0x788c2c
    //     0x788c24: bl              #0xd69bb8
    //     0x788c28: stur            x3, [x0, #7]
    // 0x788c2c: stur            x0, [fp, #-8]
    // 0x788c30: stp             x0, x2, [SP, #-0x10]!
    // 0x788c34: r0 = _getValueOrData()
    //     0x788c34: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x788c38: add             SP, SP, #0x10
    // 0x788c3c: mov             x1, x0
    // 0x788c40: ldur            x0, [fp, #-0x10]
    // 0x788c44: LoadField: r2 = r0->field_f
    //     0x788c44: ldur            w2, [x0, #0xf]
    // 0x788c48: DecompressPointer r2
    //     0x788c48: add             x2, x2, HEAP, lsl #32
    // 0x788c4c: cmp             w2, w1
    // 0x788c50: b.ne            #0x788c58
    // 0x788c54: r1 = Null
    //     0x788c54: mov             x1, NULL
    // 0x788c58: stur            x1, [fp, #-0x18]
    // 0x788c5c: cmp             w1, NULL
    // 0x788c60: b.eq            #0x788ca0
    // 0x788c64: ldur            x16, [fp, #-8]
    // 0x788c68: stp             x16, x0, [SP, #-0x10]!
    // 0x788c6c: r0 = remove()
    //     0x788c6c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x788c70: add             SP, SP, #0x10
    // 0x788c74: ldur            x0, [fp, #-0x18]
    // 0x788c78: r1 = LoadClassIdInstr(r0)
    //     0x788c78: ldur            x1, [x0, #-1]
    //     0x788c7c: ubfx            x1, x1, #0xc, #0x14
    // 0x788c80: r16 = Instance_GestureDisposition
    //     0x788c80: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x788c84: ldr             x16, [x16, #0xeb8]
    // 0x788c88: stp             x16, x0, [SP, #-0x10]!
    // 0x788c8c: mov             x0, x1
    // 0x788c90: r0 = GDT[cid_x0 + -0xfff]()
    //     0x788c90: sub             lr, x0, #0xfff
    //     0x788c94: ldr             lr, [x21, lr, lsl #3]
    //     0x788c98: blr             lr
    // 0x788c9c: add             SP, SP, #0x10
    // 0x788ca0: r0 = Null
    //     0x788ca0: mov             x0, NULL
    // 0x788ca4: LeaveFrame
    //     0x788ca4: mov             SP, fp
    //     0x788ca8: ldp             fp, lr, [SP], #0x10
    // 0x788cac: ret
    //     0x788cac: ret             
    // 0x788cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x788cb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x788cb4: b               #0x788c04
  }
  _ stopTrackingIfPointerNoLongerDown(/* No info */) {
    // ** addr: 0x7891a8, size: 0x158
    // 0x7891a8: EnterFrame
    //     0x7891a8: stp             fp, lr, [SP, #-0x10]!
    //     0x7891ac: mov             fp, SP
    // 0x7891b0: CheckStackOverflow
    //     0x7891b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7891b4: cmp             SP, x16
    //     0x7891b8: b.ls            #0x7892f8
    // 0x7891bc: ldr             x0, [fp, #0x10]
    // 0x7891c0: r2 = Null
    //     0x7891c0: mov             x2, NULL
    // 0x7891c4: r1 = Null
    //     0x7891c4: mov             x1, NULL
    // 0x7891c8: cmp             w0, NULL
    // 0x7891cc: b.eq            #0x7891ec
    // 0x7891d0: branchIfSmi(r0, 0x7891ec)
    //     0x7891d0: tbz             w0, #0, #0x7891ec
    // 0x7891d4: r3 = LoadClassIdInstr(r0)
    //     0x7891d4: ldur            x3, [x0, #-1]
    //     0x7891d8: ubfx            x3, x3, #0xc, #0x14
    // 0x7891dc: cmp             x3, #0x906
    // 0x7891e0: b.eq            #0x7891f4
    // 0x7891e4: cmp             x3, #0xb3d
    // 0x7891e8: b.eq            #0x7891f4
    // 0x7891ec: r0 = false
    //     0x7891ec: add             x0, NULL, #0x30  ; false
    // 0x7891f0: b               #0x7891f8
    // 0x7891f4: r0 = true
    //     0x7891f4: add             x0, NULL, #0x20  ; true
    // 0x7891f8: tbz             w0, #4, #0x78927c
    // 0x7891fc: ldr             x0, [fp, #0x10]
    // 0x789200: r2 = Null
    //     0x789200: mov             x2, NULL
    // 0x789204: r1 = Null
    //     0x789204: mov             x1, NULL
    // 0x789208: cmp             w0, NULL
    // 0x78920c: b.eq            #0x78922c
    // 0x789210: branchIfSmi(r0, 0x78922c)
    //     0x789210: tbz             w0, #0, #0x78922c
    // 0x789214: r3 = LoadClassIdInstr(r0)
    //     0x789214: ldur            x3, [x0, #-1]
    //     0x789218: ubfx            x3, x3, #0xc, #0x14
    // 0x78921c: cmp             x3, #0x8f8
    // 0x789220: b.eq            #0x789234
    // 0x789224: cmp             x3, #0xb35
    // 0x789228: b.eq            #0x789234
    // 0x78922c: r0 = false
    //     0x78922c: add             x0, NULL, #0x30  ; false
    // 0x789230: b               #0x789238
    // 0x789234: r0 = true
    //     0x789234: add             x0, NULL, #0x20  ; true
    // 0x789238: tbz             w0, #4, #0x78927c
    // 0x78923c: ldr             x0, [fp, #0x10]
    // 0x789240: r2 = Null
    //     0x789240: mov             x2, NULL
    // 0x789244: r1 = Null
    //     0x789244: mov             x1, NULL
    // 0x789248: cmp             w0, NULL
    // 0x78924c: b.eq            #0x78926c
    // 0x789250: branchIfSmi(r0, 0x78926c)
    //     0x789250: tbz             w0, #0, #0x78926c
    // 0x789254: r3 = LoadClassIdInstr(r0)
    //     0x789254: ldur            x3, [x0, #-1]
    //     0x789258: ubfx            x3, x3, #0xc, #0x14
    // 0x78925c: cmp             x3, #0x8fa
    // 0x789260: b.eq            #0x789274
    // 0x789264: cmp             x3, #0xb37
    // 0x789268: b.eq            #0x789274
    // 0x78926c: r0 = false
    //     0x78926c: add             x0, NULL, #0x30  ; false
    // 0x789270: b               #0x789278
    // 0x789274: r0 = true
    //     0x789274: add             x0, NULL, #0x20  ; true
    // 0x789278: tbnz            w0, #4, #0x7892e8
    // 0x78927c: ldr             x1, [fp, #0x18]
    // 0x789280: ldr             x0, [fp, #0x10]
    // 0x789284: r2 = LoadClassIdInstr(r0)
    //     0x789284: ldur            x2, [x0, #-1]
    //     0x789288: ubfx            x2, x2, #0xc, #0x14
    // 0x78928c: SaveReg r0
    //     0x78928c: str             x0, [SP, #-8]!
    // 0x789290: mov             x0, x2
    // 0x789294: r0 = GDT[cid_x0 + -0xfff]()
    //     0x789294: sub             lr, x0, #0xfff
    //     0x789298: ldr             lr, [x21, lr, lsl #3]
    //     0x78929c: blr             lr
    // 0x7892a0: add             SP, SP, #8
    // 0x7892a4: mov             x2, x0
    // 0x7892a8: r0 = BoxInt64Instr(r2)
    //     0x7892a8: sbfiz           x0, x2, #1, #0x1f
    //     0x7892ac: cmp             x2, x0, asr #1
    //     0x7892b0: b.eq            #0x7892bc
    //     0x7892b4: bl              #0xd69bb8
    //     0x7892b8: stur            x2, [x0, #7]
    // 0x7892bc: mov             x1, x0
    // 0x7892c0: ldr             x0, [fp, #0x18]
    // 0x7892c4: r2 = LoadClassIdInstr(r0)
    //     0x7892c4: ldur            x2, [x0, #-1]
    //     0x7892c8: ubfx            x2, x2, #0xc, #0x14
    // 0x7892cc: stp             x1, x0, [SP, #-0x10]!
    // 0x7892d0: mov             x0, x2
    // 0x7892d4: r0 = GDT[cid_x0 + 0xc400]()
    //     0x7892d4: mov             x17, #0xc400
    //     0x7892d8: add             lr, x0, x17
    //     0x7892dc: ldr             lr, [x21, lr, lsl #3]
    //     0x7892e0: blr             lr
    // 0x7892e4: add             SP, SP, #0x10
    // 0x7892e8: r0 = Null
    //     0x7892e8: mov             x0, NULL
    // 0x7892ec: LeaveFrame
    //     0x7892ec: mov             SP, fp
    //     0x7892f0: ldp             fp, lr, [SP], #0x10
    // 0x7892f4: ret
    //     0x7892f4: ret             
    // 0x7892f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7892f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7892fc: b               #0x7891bc
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbd93a4, size: 0x224
    // 0xbd93a4: EnterFrame
    //     0xbd93a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbd93a8: mov             fp, SP
    // 0xbd93ac: AllocStack(0x38)
    //     0xbd93ac: sub             SP, SP, #0x38
    // 0xbd93b0: CheckStackOverflow
    //     0xbd93b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd93b4: cmp             SP, x16
    //     0xbd93b8: b.ls            #0xbd95b0
    // 0xbd93bc: ldr             x1, [fp, #0x10]
    // 0xbd93c0: r0 = LoadClassIdInstr(r1)
    //     0xbd93c0: ldur            x0, [x1, #-1]
    //     0xbd93c4: ubfx            x0, x0, #0xc, #0x14
    // 0xbd93c8: r16 = Instance_GestureDisposition
    //     0xbd93c8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xbd93cc: ldr             x16, [x16, #0xeb8]
    // 0xbd93d0: stp             x16, x1, [SP, #-0x10]!
    // 0xbd93d4: r0 = GDT[cid_x0 + 0xc39b]()
    //     0xbd93d4: mov             x17, #0xc39b
    //     0xbd93d8: add             lr, x0, x17
    //     0xbd93dc: ldr             lr, [x21, lr, lsl #3]
    //     0xbd93e0: blr             lr
    // 0xbd93e4: add             SP, SP, #0x10
    // 0xbd93e8: ldr             x0, [fp, #0x10]
    // 0xbd93ec: LoadField: r2 = r0->field_17
    //     0xbd93ec: ldur            w2, [x0, #0x17]
    // 0xbd93f0: DecompressPointer r2
    //     0xbd93f0: add             x2, x2, HEAP, lsl #32
    // 0xbd93f4: stur            x2, [fp, #-0x10]
    // 0xbd93f8: LoadField: r3 = r2->field_7
    //     0xbd93f8: ldur            w3, [x2, #7]
    // 0xbd93fc: DecompressPointer r3
    //     0xbd93fc: add             x3, x3, HEAP, lsl #32
    // 0xbd9400: mov             x1, x3
    // 0xbd9404: stur            x3, [fp, #-8]
    // 0xbd9408: r0 = _HashSetIterator()
    //     0xbd9408: bl              #0x554e80  ; Allocate_HashSetIteratorStub -> _HashSetIterator<X0> (size=0x28)
    // 0xbd940c: mov             x1, x0
    // 0xbd9410: r0 = 0
    //     0xbd9410: mov             x0, #0
    // 0xbd9414: stur            x1, [fp, #-0x18]
    // 0xbd9418: StoreField: r1->field_17 = r0
    //     0xbd9418: stur            x0, [x1, #0x17]
    // 0xbd941c: ldur            x0, [fp, #-0x10]
    // 0xbd9420: StoreField: r1->field_b = r0
    //     0xbd9420: stur            w0, [x1, #0xb]
    // 0xbd9424: LoadField: r2 = r0->field_17
    //     0xbd9424: ldur            x2, [x0, #0x17]
    // 0xbd9428: StoreField: r1->field_f = r2
    //     0xbd9428: stur            x2, [x1, #0xf]
    // 0xbd942c: ldr             x2, [fp, #0x10]
    // 0xbd9430: CheckStackOverflow
    //     0xbd9430: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd9434: cmp             SP, x16
    //     0xbd9438: b.ls            #0xbd95b8
    // 0xbd943c: SaveReg r1
    //     0xbd943c: str             x1, [SP, #-8]!
    // 0xbd9440: r0 = moveNext()
    //     0xbd9440: bl              #0xc3c604  ; [dart:collection] _HashSetIterator::moveNext
    // 0xbd9444: add             SP, SP, #8
    // 0xbd9448: tbnz            w0, #4, #0xbd9590
    // 0xbd944c: ldur            x3, [fp, #-0x18]
    // 0xbd9450: LoadField: r4 = r3->field_23
    //     0xbd9450: ldur            w4, [x3, #0x23]
    // 0xbd9454: DecompressPointer r4
    //     0xbd9454: add             x4, x4, HEAP, lsl #32
    // 0xbd9458: stur            x4, [fp, #-0x20]
    // 0xbd945c: cmp             w4, NULL
    // 0xbd9460: b.ne            #0xbd9494
    // 0xbd9464: mov             x0, x4
    // 0xbd9468: ldur            x2, [fp, #-8]
    // 0xbd946c: r1 = Null
    //     0xbd946c: mov             x1, NULL
    // 0xbd9470: cmp             w2, NULL
    // 0xbd9474: b.eq            #0xbd9494
    // 0xbd9478: LoadField: r4 = r2->field_17
    //     0xbd9478: ldur            w4, [x2, #0x17]
    // 0xbd947c: DecompressPointer r4
    //     0xbd947c: add             x4, x4, HEAP, lsl #32
    // 0xbd9480: r8 = X0
    //     0xbd9480: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbd9484: LoadField: r9 = r4->field_7
    //     0xbd9484: ldur            x9, [x4, #7]
    // 0xbd9488: r3 = Null
    //     0xbd9488: add             x3, PP, #0x38, lsl #12  ; [pp+0x38458] Null
    //     0xbd948c: ldr             x3, [x3, #0x458]
    // 0xbd9490: blr             x9
    // 0xbd9494: ldr             x1, [fp, #0x10]
    // 0xbd9498: r0 = LoadStaticField(0xd54)
    //     0xbd9498: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xbd949c: ldr             x0, [x0, #0x1aa8]
    // 0xbd94a0: cmp             w0, NULL
    // 0xbd94a4: b.eq            #0xbd95c0
    // 0xbd94a8: LoadField: r2 = r0->field_13
    //     0xbd94a8: ldur            w2, [x0, #0x13]
    // 0xbd94ac: DecompressPointer r2
    //     0xbd94ac: add             x2, x2, HEAP, lsl #32
    // 0xbd94b0: stur            x2, [fp, #-0x28]
    // 0xbd94b4: r0 = LoadClassIdInstr(r1)
    //     0xbd94b4: ldur            x0, [x1, #-1]
    //     0xbd94b8: ubfx            x0, x0, #0xc, #0x14
    // 0xbd94bc: SaveReg r1
    //     0xbd94bc: str             x1, [SP, #-8]!
    // 0xbd94c0: r0 = GDT[cid_x0 + 0xc063]()
    //     0xbd94c0: mov             x17, #0xc063
    //     0xbd94c4: add             lr, x0, x17
    //     0xbd94c8: ldr             lr, [x21, lr, lsl #3]
    //     0xbd94cc: blr             lr
    // 0xbd94d0: add             SP, SP, #8
    // 0xbd94d4: mov             x1, x0
    // 0xbd94d8: ldur            x0, [fp, #-0x28]
    // 0xbd94dc: stur            x1, [fp, #-0x38]
    // 0xbd94e0: LoadField: r2 = r0->field_7
    //     0xbd94e0: ldur            w2, [x0, #7]
    // 0xbd94e4: DecompressPointer r2
    //     0xbd94e4: add             x2, x2, HEAP, lsl #32
    // 0xbd94e8: stur            x2, [fp, #-0x30]
    // 0xbd94ec: ldur            x16, [fp, #-0x20]
    // 0xbd94f0: stp             x16, x2, [SP, #-0x10]!
    // 0xbd94f4: r0 = _getValueOrData()
    //     0xbd94f4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xbd94f8: add             SP, SP, #0x10
    // 0xbd94fc: ldur            x1, [fp, #-0x30]
    // 0xbd9500: LoadField: r2 = r1->field_f
    //     0xbd9500: ldur            w2, [x1, #0xf]
    // 0xbd9504: DecompressPointer r2
    //     0xbd9504: add             x2, x2, HEAP, lsl #32
    // 0xbd9508: cmp             w2, w0
    // 0xbd950c: b.ne            #0xbd9518
    // 0xbd9510: r2 = Null
    //     0xbd9510: mov             x2, NULL
    // 0xbd9514: b               #0xbd951c
    // 0xbd9518: mov             x2, x0
    // 0xbd951c: stur            x2, [fp, #-0x28]
    // 0xbd9520: cmp             w2, NULL
    // 0xbd9524: b.eq            #0xbd95c4
    // 0xbd9528: r0 = LoadClassIdInstr(r2)
    //     0xbd9528: ldur            x0, [x2, #-1]
    //     0xbd952c: ubfx            x0, x0, #0xc, #0x14
    // 0xbd9530: ldur            x16, [fp, #-0x38]
    // 0xbd9534: stp             x16, x2, [SP, #-0x10]!
    // 0xbd9538: r0 = GDT[cid_x0 + 0x6e2]()
    //     0xbd9538: add             lr, x0, #0x6e2
    //     0xbd953c: ldr             lr, [x21, lr, lsl #3]
    //     0xbd9540: blr             lr
    // 0xbd9544: add             SP, SP, #0x10
    // 0xbd9548: ldur            x0, [fp, #-0x28]
    // 0xbd954c: r1 = LoadClassIdInstr(r0)
    //     0xbd954c: ldur            x1, [x0, #-1]
    //     0xbd9550: ubfx            x1, x1, #0xc, #0x14
    // 0xbd9554: SaveReg r0
    //     0xbd9554: str             x0, [SP, #-8]!
    // 0xbd9558: mov             x0, x1
    // 0xbd955c: r0 = GDT[cid_x0 + 0x747]()
    //     0xbd955c: add             lr, x0, #0x747
    //     0xbd9560: ldr             lr, [x21, lr, lsl #3]
    //     0xbd9564: blr             lr
    // 0xbd9568: add             SP, SP, #8
    // 0xbd956c: tbnz            w0, #4, #0xbd9584
    // 0xbd9570: ldur            x16, [fp, #-0x30]
    // 0xbd9574: ldur            lr, [fp, #-0x20]
    // 0xbd9578: stp             lr, x16, [SP, #-0x10]!
    // 0xbd957c: r0 = remove()
    //     0xbd957c: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xbd9580: add             SP, SP, #0x10
    // 0xbd9584: ldur            x0, [fp, #-0x10]
    // 0xbd9588: ldur            x1, [fp, #-0x18]
    // 0xbd958c: b               #0xbd942c
    // 0xbd9590: ldur            x16, [fp, #-0x10]
    // 0xbd9594: SaveReg r16
    //     0xbd9594: str             x16, [SP, #-8]!
    // 0xbd9598: r0 = clear()
    //     0xbd9598: bl              #0x592930  ; [dart:collection] _HashSet::clear
    // 0xbd959c: add             SP, SP, #8
    // 0xbd95a0: r0 = Null
    //     0xbd95a0: mov             x0, NULL
    // 0xbd95a4: LeaveFrame
    //     0xbd95a4: mov             SP, fp
    //     0xbd95a8: ldp             fp, lr, [SP], #0x10
    // 0xbd95ac: ret
    //     0xbd95ac: ret             
    // 0xbd95b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd95b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd95b4: b               #0xbd93bc
    // 0xbd95b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd95b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd95bc: b               #0xbd943c
    // 0xbd95c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd95c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbd95c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbd95c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2356, size: 0x44, field offset: 0x20
abstract class PrimaryPointerGestureRecognizer extends OneSequenceGestureRecognizer {

  _ PrimaryPointerGestureRecognizer(/* No info */) {
    // ** addr: 0x6ef26c, size: 0x150
    // 0x6ef26c: EnterFrame
    //     0x6ef26c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ef270: mov             fp, SP
    // 0x6ef274: mov             x0, x4
    // 0x6ef278: LoadField: r1 = r0->field_13
    //     0x6ef278: ldur            w1, [x0, #0x13]
    // 0x6ef27c: DecompressPointer r1
    //     0x6ef27c: add             x1, x1, HEAP, lsl #32
    // 0x6ef280: sub             x2, x1, #4
    // 0x6ef284: add             x3, fp, w2, sxtw #2
    // 0x6ef288: ldr             x3, [x3, #0x18]
    // 0x6ef28c: add             x4, fp, w2, sxtw #2
    // 0x6ef290: ldr             x4, [x4, #0x10]
    // 0x6ef294: LoadField: r2 = r0->field_1f
    //     0x6ef294: ldur            w2, [x0, #0x1f]
    // 0x6ef298: DecompressPointer r2
    //     0x6ef298: add             x2, x2, HEAP, lsl #32
    // 0x6ef29c: r16 = "kind"
    //     0x6ef29c: ldr             x16, [PP, #0x3998]  ; [pp+0x3998] "kind"
    // 0x6ef2a0: cmp             w2, w16
    // 0x6ef2a4: b.ne            #0x6ef2c8
    // 0x6ef2a8: LoadField: r2 = r0->field_23
    //     0x6ef2a8: ldur            w2, [x0, #0x23]
    // 0x6ef2ac: DecompressPointer r2
    //     0x6ef2ac: add             x2, x2, HEAP, lsl #32
    // 0x6ef2b0: sub             w5, w1, w2
    // 0x6ef2b4: add             x2, fp, w5, sxtw #2
    // 0x6ef2b8: ldr             x2, [x2, #8]
    // 0x6ef2bc: mov             x5, x2
    // 0x6ef2c0: r2 = 1
    //     0x6ef2c0: mov             x2, #1
    // 0x6ef2c4: b               #0x6ef2d0
    // 0x6ef2c8: r5 = Null
    //     0x6ef2c8: mov             x5, NULL
    // 0x6ef2cc: r2 = 0
    //     0x6ef2cc: mov             x2, #0
    // 0x6ef2d0: lsl             x6, x2, #1
    // 0x6ef2d4: lsl             w2, w6, #1
    // 0x6ef2d8: add             w6, w2, #8
    // 0x6ef2dc: ArrayLoad: r7 = r0[r6]  ; Unknown_4
    //     0x6ef2dc: add             x16, x0, w6, sxtw #1
    //     0x6ef2e0: ldur            w7, [x16, #0xf]
    // 0x6ef2e4: DecompressPointer r7
    //     0x6ef2e4: add             x7, x7, HEAP, lsl #32
    // 0x6ef2e8: r16 = "postAcceptSlopTolerance"
    //     0x6ef2e8: add             x16, PP, #0x21, lsl #12  ; [pp+0x214f8] "postAcceptSlopTolerance"
    //     0x6ef2ec: ldr             x16, [x16, #0x4f8]
    // 0x6ef2f0: cmp             w7, w16
    // 0x6ef2f4: b.ne            #0x6ef31c
    // 0x6ef2f8: add             w6, w2, #0xa
    // 0x6ef2fc: ArrayLoad: r2 = r0[r6]  ; Unknown_4
    //     0x6ef2fc: add             x16, x0, w6, sxtw #1
    //     0x6ef300: ldur            w2, [x16, #0xf]
    // 0x6ef304: DecompressPointer r2
    //     0x6ef304: add             x2, x2, HEAP, lsl #32
    // 0x6ef308: sub             w0, w1, w2
    // 0x6ef30c: add             x1, fp, w0, sxtw #2
    // 0x6ef310: ldr             x1, [x1, #8]
    // 0x6ef314: mov             x2, x1
    // 0x6ef318: b               #0x6ef324
    // 0x6ef31c: r2 = 18.000000
    //     0x6ef31c: add             x2, PP, #0x21, lsl #12  ; [pp+0x21500] 18
    //     0x6ef320: ldr             x2, [x2, #0x500]
    // 0x6ef324: r1 = Instance_GestureRecognizerState
    //     0x6ef324: add             x1, PP, #0x21, lsl #12  ; [pp+0x21508] Obj!GestureRecognizerState@b65a91
    //     0x6ef328: ldr             x1, [x1, #0x508]
    // 0x6ef32c: r0 = false
    //     0x6ef32c: add             x0, NULL, #0x30  ; false
    // 0x6ef330: d0 = 18.000000
    //     0x6ef330: fmov            d0, #18.00000000
    // 0x6ef334: CheckStackOverflow
    //     0x6ef334: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ef338: cmp             SP, x16
    //     0x6ef33c: b.ls            #0x6ef3b4
    // 0x6ef340: StoreField: r3->field_2f = r1
    //     0x6ef340: stur            w1, [x3, #0x2f]
    // 0x6ef344: StoreField: r3->field_3b = r0
    //     0x6ef344: stur            w0, [x3, #0x3b]
    // 0x6ef348: mov             x0, x4
    // 0x6ef34c: StoreField: r3->field_1f = r0
    //     0x6ef34c: stur            w0, [x3, #0x1f]
    //     0x6ef350: ldurb           w16, [x3, #-1]
    //     0x6ef354: ldurb           w17, [x0, #-1]
    //     0x6ef358: and             x16, x17, x16, lsr #2
    //     0x6ef35c: tst             x16, HEAP, lsr #32
    //     0x6ef360: b.eq            #0x6ef368
    //     0x6ef364: bl              #0xd682ac
    // 0x6ef368: StoreField: r3->field_23 = d0
    //     0x6ef368: stur            d0, [x3, #0x23]
    // 0x6ef36c: mov             x0, x2
    // 0x6ef370: StoreField: r3->field_2b = r0
    //     0x6ef370: stur            w0, [x3, #0x2b]
    //     0x6ef374: ldurb           w16, [x3, #-1]
    //     0x6ef378: ldurb           w17, [x0, #-1]
    //     0x6ef37c: and             x16, x17, x16, lsr #2
    //     0x6ef380: tst             x16, HEAP, lsr #32
    //     0x6ef384: b.eq            #0x6ef38c
    //     0x6ef388: bl              #0xd682ac
    // 0x6ef38c: stp             x5, x3, [SP, #-0x10]!
    // 0x6ef390: SaveReg rNULL
    //     0x6ef390: str             NULL, [SP, #-8]!
    // 0x6ef394: r4 = const [0, 0x3, 0x3, 0x1, kind, 0x1, supportedDevices, 0x2, null]
    //     0x6ef394: add             x4, PP, #0x21, lsl #12  ; [pp+0x214b0] List(9) [0, 0x3, 0x3, 0x1, "kind", 0x1, "supportedDevices", 0x2, Null]
    //     0x6ef398: ldr             x4, [x4, #0x4b0]
    // 0x6ef39c: r0 = OneSequenceGestureRecognizer()
    //     0x6ef39c: bl              #0x6d3ef4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0x6ef3a0: add             SP, SP, #0x18
    // 0x6ef3a4: r0 = Null
    //     0x6ef3a4: mov             x0, NULL
    // 0x6ef3a8: LeaveFrame
    //     0x6ef3a8: mov             SP, fp
    //     0x6ef3ac: ldp             fp, lr, [SP], #0x10
    // 0x6ef3b0: ret
    //     0x6ef3b0: ret             
    // 0x6ef3b4: r0 = StackOverflowSharedWithFPURegs()
    //     0x6ef3b4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6ef3b8: b               #0x6ef340
  }
  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0x71441c, size: 0x58
    // 0x71441c: EnterFrame
    //     0x71441c: stp             fp, lr, [SP, #-0x10]!
    //     0x714420: mov             fp, SP
    // 0x714424: CheckStackOverflow
    //     0x714424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714428: cmp             SP, x16
    //     0x71442c: b.ls            #0x71446c
    // 0x714430: ldr             x16, [fp, #0x18]
    // 0x714434: SaveReg r16
    //     0x714434: str             x16, [SP, #-8]!
    // 0x714438: r0 = _stopTimer()
    //     0x714438: bl              #0x714474  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_stopTimer
    // 0x71443c: add             SP, SP, #8
    // 0x714440: ldr             x2, [fp, #0x18]
    // 0x714444: r1 = Instance_GestureRecognizerState
    //     0x714444: add             x1, PP, #0x21, lsl #12  ; [pp+0x21508] Obj!GestureRecognizerState@b65a91
    //     0x714448: ldr             x1, [x1, #0x508]
    // 0x71444c: StoreField: r2->field_2f = r1
    //     0x71444c: stur            w1, [x2, #0x2f]
    // 0x714450: StoreField: r2->field_37 = rNULL
    //     0x714450: stur            NULL, [x2, #0x37]
    // 0x714454: r1 = false
    //     0x714454: add             x1, NULL, #0x30  ; false
    // 0x714458: StoreField: r2->field_3b = r1
    //     0x714458: stur            w1, [x2, #0x3b]
    // 0x71445c: r0 = Null
    //     0x71445c: mov             x0, NULL
    // 0x714460: LeaveFrame
    //     0x714460: mov             SP, fp
    //     0x714464: ldp             fp, lr, [SP], #0x10
    // 0x714468: ret
    //     0x714468: ret             
    // 0x71446c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71446c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714470: b               #0x714430
  }
  _ _stopTimer(/* No info */) {
    // ** addr: 0x714474, size: 0x54
    // 0x714474: EnterFrame
    //     0x714474: stp             fp, lr, [SP, #-0x10]!
    //     0x714478: mov             fp, SP
    // 0x71447c: CheckStackOverflow
    //     0x71447c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714480: cmp             SP, x16
    //     0x714484: b.ls            #0x7144c0
    // 0x714488: ldr             x0, [fp, #0x10]
    // 0x71448c: LoadField: r1 = r0->field_3f
    //     0x71448c: ldur            w1, [x0, #0x3f]
    // 0x714490: DecompressPointer r1
    //     0x714490: add             x1, x1, HEAP, lsl #32
    // 0x714494: cmp             w1, NULL
    // 0x714498: b.eq            #0x7144b0
    // 0x71449c: SaveReg r1
    //     0x71449c: str             x1, [SP, #-8]!
    // 0x7144a0: r0 = cancel()
    //     0x7144a0: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x7144a4: add             SP, SP, #8
    // 0x7144a8: ldr             x1, [fp, #0x10]
    // 0x7144ac: StoreField: r1->field_3f = rNULL
    //     0x7144ac: stur            NULL, [x1, #0x3f]
    // 0x7144b0: r0 = Null
    //     0x7144b0: mov             x0, NULL
    // 0x7144b4: LeaveFrame
    //     0x7144b4: mov             SP, fp
    //     0x7144b8: ldp             fp, lr, [SP], #0x10
    // 0x7144bc: ret
    //     0x7144bc: ret             
    // 0x7144c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7144c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7144c4: b               #0x714488
  }
  _ handleNonAllowedPointer(/* No info */) {
    // ** addr: 0x717298, size: 0x48
    // 0x717298: EnterFrame
    //     0x717298: stp             fp, lr, [SP, #-0x10]!
    //     0x71729c: mov             fp, SP
    // 0x7172a0: CheckStackOverflow
    //     0x7172a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7172a4: cmp             SP, x16
    //     0x7172a8: b.ls            #0x7172d8
    // 0x7172ac: ldr             x0, [fp, #0x10]
    // 0x7172b0: LoadField: r1 = r0->field_3b
    //     0x7172b0: ldur            w1, [x0, #0x3b]
    // 0x7172b4: DecompressPointer r1
    //     0x7172b4: add             x1, x1, HEAP, lsl #32
    // 0x7172b8: tbz             w1, #4, #0x7172c8
    // 0x7172bc: SaveReg r0
    //     0x7172bc: str             x0, [SP, #-8]!
    // 0x7172c0: r0 = handleNonAllowedPointer()
    //     0x7172c0: bl              #0x7172e0  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::handleNonAllowedPointer
    // 0x7172c4: add             SP, SP, #8
    // 0x7172c8: r0 = Null
    //     0x7172c8: mov             x0, NULL
    // 0x7172cc: LeaveFrame
    //     0x7172cc: mov             SP, fp
    //     0x7172d0: ldp             fp, lr, [SP], #0x10
    // 0x7172d4: ret
    //     0x7172d4: ret             
    // 0x7172d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7172d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7172dc: b               #0x7172ac
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x7825d0, size: 0x1bc
    // 0x7825d0: EnterFrame
    //     0x7825d0: stp             fp, lr, [SP, #-0x10]!
    //     0x7825d4: mov             fp, SP
    // 0x7825d8: AllocStack(0x18)
    //     0x7825d8: sub             SP, SP, #0x18
    // 0x7825dc: CheckStackOverflow
    //     0x7825dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7825e0: cmp             SP, x16
    //     0x7825e4: b.ls            #0x782784
    // 0x7825e8: r1 = 1
    //     0x7825e8: mov             x1, #1
    // 0x7825ec: r0 = AllocateContext()
    //     0x7825ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7825f0: mov             x1, x0
    // 0x7825f4: ldr             x0, [fp, #0x18]
    // 0x7825f8: stur            x1, [fp, #-8]
    // 0x7825fc: StoreField: r1->field_f = r0
    //     0x7825fc: stur            w0, [x1, #0xf]
    // 0x782600: ldr             x16, [fp, #0x10]
    // 0x782604: stp             x16, x0, [SP, #-0x10]!
    // 0x782608: r0 = addAllowedPointer()
    //     0x782608: bl              #0x782114  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0x78260c: add             SP, SP, #0x10
    // 0x782610: ldr             x1, [fp, #0x18]
    // 0x782614: LoadField: r0 = r1->field_2f
    //     0x782614: ldur            w0, [x1, #0x2f]
    // 0x782618: DecompressPointer r0
    //     0x782618: add             x0, x0, HEAP, lsl #32
    // 0x78261c: r16 = Instance_GestureRecognizerState
    //     0x78261c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21508] Obj!GestureRecognizerState@b65a91
    //     0x782620: ldr             x16, [x16, #0x508]
    // 0x782624: cmp             w0, w16
    // 0x782628: b.ne            #0x782774
    // 0x78262c: ldr             x2, [fp, #0x10]
    // 0x782630: r0 = Instance_GestureRecognizerState
    //     0x782630: add             x0, PP, #0x29, lsl #12  ; [pp+0x29248] Obj!GestureRecognizerState@b65ab1
    //     0x782634: ldr             x0, [x0, #0x248]
    // 0x782638: StoreField: r1->field_2f = r0
    //     0x782638: stur            w0, [x1, #0x2f]
    // 0x78263c: r0 = LoadClassIdInstr(r2)
    //     0x78263c: ldur            x0, [x2, #-1]
    //     0x782640: ubfx            x0, x0, #0xc, #0x14
    // 0x782644: SaveReg r2
    //     0x782644: str             x2, [SP, #-8]!
    // 0x782648: r0 = GDT[cid_x0 + -0xfff]()
    //     0x782648: sub             lr, x0, #0xfff
    //     0x78264c: ldr             lr, [x21, lr, lsl #3]
    //     0x782650: blr             lr
    // 0x782654: add             SP, SP, #8
    // 0x782658: mov             x2, x0
    // 0x78265c: r0 = BoxInt64Instr(r2)
    //     0x78265c: sbfiz           x0, x2, #1, #0x1f
    //     0x782660: cmp             x2, x0, asr #1
    //     0x782664: b.eq            #0x782670
    //     0x782668: bl              #0xd69bb8
    //     0x78266c: stur            x2, [x0, #7]
    // 0x782670: ldr             x1, [fp, #0x18]
    // 0x782674: StoreField: r1->field_33 = r0
    //     0x782674: stur            w0, [x1, #0x33]
    //     0x782678: tbz             w0, #0, #0x782694
    //     0x78267c: ldurb           w16, [x1, #-1]
    //     0x782680: ldurb           w17, [x0, #-1]
    //     0x782684: and             x16, x17, x16, lsr #2
    //     0x782688: tst             x16, HEAP, lsr #32
    //     0x78268c: b.eq            #0x782694
    //     0x782690: bl              #0xd6826c
    // 0x782694: ldr             x2, [fp, #0x10]
    // 0x782698: r0 = LoadClassIdInstr(r2)
    //     0x782698: ldur            x0, [x2, #-1]
    //     0x78269c: ubfx            x0, x0, #0xc, #0x14
    // 0x7826a0: SaveReg r2
    //     0x7826a0: str             x2, [SP, #-8]!
    // 0x7826a4: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x7826a4: mov             x17, #0x57c0
    //     0x7826a8: add             lr, x0, x17
    //     0x7826ac: ldr             lr, [x21, lr, lsl #3]
    //     0x7826b0: blr             lr
    // 0x7826b4: add             SP, SP, #8
    // 0x7826b8: mov             x1, x0
    // 0x7826bc: ldr             x0, [fp, #0x10]
    // 0x7826c0: stur            x1, [fp, #-0x10]
    // 0x7826c4: r2 = LoadClassIdInstr(r0)
    //     0x7826c4: ldur            x2, [x0, #-1]
    //     0x7826c8: ubfx            x2, x2, #0xc, #0x14
    // 0x7826cc: SaveReg r0
    //     0x7826cc: str             x0, [SP, #-8]!
    // 0x7826d0: mov             x0, x2
    // 0x7826d4: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x7826d4: sub             lr, x0, #0xfd9
    //     0x7826d8: ldr             lr, [x21, lr, lsl #3]
    //     0x7826dc: blr             lr
    // 0x7826e0: add             SP, SP, #8
    // 0x7826e4: stur            x0, [fp, #-0x18]
    // 0x7826e8: r0 = OffsetPair()
    //     0x7826e8: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x7826ec: mov             x1, x0
    // 0x7826f0: ldur            x0, [fp, #-0x10]
    // 0x7826f4: StoreField: r1->field_7 = r0
    //     0x7826f4: stur            w0, [x1, #7]
    // 0x7826f8: ldur            x0, [fp, #-0x18]
    // 0x7826fc: StoreField: r1->field_b = r0
    //     0x7826fc: stur            w0, [x1, #0xb]
    // 0x782700: mov             x0, x1
    // 0x782704: ldr             x3, [fp, #0x18]
    // 0x782708: StoreField: r3->field_37 = r0
    //     0x782708: stur            w0, [x3, #0x37]
    //     0x78270c: ldurb           w16, [x3, #-1]
    //     0x782710: ldurb           w17, [x0, #-1]
    //     0x782714: and             x16, x17, x16, lsr #2
    //     0x782718: tst             x16, HEAP, lsr #32
    //     0x78271c: b.eq            #0x782724
    //     0x782720: bl              #0xd682ac
    // 0x782724: LoadField: r0 = r3->field_1f
    //     0x782724: ldur            w0, [x3, #0x1f]
    // 0x782728: DecompressPointer r0
    //     0x782728: add             x0, x0, HEAP, lsl #32
    // 0x78272c: ldur            x2, [fp, #-8]
    // 0x782730: stur            x0, [fp, #-0x10]
    // 0x782734: r1 = Function '<anonymous closure>':.
    //     0x782734: add             x1, PP, #0x29, lsl #12  ; [pp+0x29258] AnonymousClosure: (0x78278c), in [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::addAllowedPointer (0x7825d0)
    //     0x782738: ldr             x1, [x1, #0x258]
    // 0x78273c: r0 = AllocateClosure()
    //     0x78273c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x782740: ldur            x16, [fp, #-0x10]
    // 0x782744: stp             x16, NULL, [SP, #-0x10]!
    // 0x782748: SaveReg r0
    //     0x782748: str             x0, [SP, #-8]!
    // 0x78274c: r0 = Timer()
    //     0x78274c: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x782750: add             SP, SP, #0x18
    // 0x782754: ldr             x1, [fp, #0x18]
    // 0x782758: StoreField: r1->field_3f = r0
    //     0x782758: stur            w0, [x1, #0x3f]
    //     0x78275c: ldurb           w16, [x1, #-1]
    //     0x782760: ldurb           w17, [x0, #-1]
    //     0x782764: and             x16, x17, x16, lsr #2
    //     0x782768: tst             x16, HEAP, lsr #32
    //     0x78276c: b.eq            #0x782774
    //     0x782770: bl              #0xd6826c
    // 0x782774: r0 = Null
    //     0x782774: mov             x0, NULL
    // 0x782778: LeaveFrame
    //     0x782778: mov             SP, fp
    //     0x78277c: ldp             fp, lr, [SP], #0x10
    // 0x782780: ret
    //     0x782780: ret             
    // 0x782784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782784: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782788: b               #0x7825e8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x78278c, size: 0x48
    // 0x78278c: EnterFrame
    //     0x78278c: stp             fp, lr, [SP, #-0x10]!
    //     0x782790: mov             fp, SP
    // 0x782794: ldr             x0, [fp, #0x10]
    // 0x782798: LoadField: r1 = r0->field_17
    //     0x782798: ldur            w1, [x0, #0x17]
    // 0x78279c: DecompressPointer r1
    //     0x78279c: add             x1, x1, HEAP, lsl #32
    // 0x7827a0: CheckStackOverflow
    //     0x7827a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7827a4: cmp             SP, x16
    //     0x7827a8: b.ls            #0x7827cc
    // 0x7827ac: LoadField: r0 = r1->field_f
    //     0x7827ac: ldur            w0, [x1, #0xf]
    // 0x7827b0: DecompressPointer r0
    //     0x7827b0: add             x0, x0, HEAP, lsl #32
    // 0x7827b4: SaveReg r0
    //     0x7827b4: str             x0, [SP, #-8]!
    // 0x7827b8: r0 = didExceedDeadlineWithEvent()
    //     0x7827b8: bl              #0x7827d4  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::didExceedDeadlineWithEvent
    // 0x7827bc: add             SP, SP, #8
    // 0x7827c0: LeaveFrame
    //     0x7827c0: mov             SP, fp
    //     0x7827c4: ldp             fp, lr, [SP], #0x10
    // 0x7827c8: ret
    //     0x7827c8: ret             
    // 0x7827cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7827cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7827d0: b               #0x7827ac
  }
  _ didExceedDeadlineWithEvent(/* No info */) {
    // ** addr: 0x7827d4, size: 0xc0
    // 0x7827d4: EnterFrame
    //     0x7827d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7827d8: mov             fp, SP
    // 0x7827dc: CheckStackOverflow
    //     0x7827dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7827e0: cmp             SP, x16
    //     0x7827e4: b.ls            #0x782888
    // 0x7827e8: ldr             x0, [fp, #0x10]
    // 0x7827ec: r1 = LoadClassIdInstr(r0)
    //     0x7827ec: ldur            x1, [x0, #-1]
    //     0x7827f0: ubfx            x1, x1, #0xc, #0x14
    // 0x7827f4: lsl             x1, x1, #1
    // 0x7827f8: r17 = 4720
    //     0x7827f8: mov             x17, #0x1270
    // 0x7827fc: cmp             w1, w17
    // 0x782800: b.gt            #0x782820
    // 0x782804: r17 = 4716
    //     0x782804: mov             x17, #0x126c
    // 0x782808: cmp             w1, w17
    // 0x78280c: b.lt            #0x782820
    // 0x782810: SaveReg r0
    //     0x782810: str             x0, [SP, #-8]!
    // 0x782814: r0 = _checkDown()
    //     0x782814: bl              #0x782b04  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkDown
    // 0x782818: add             SP, SP, #8
    // 0x78281c: b               #0x782878
    // 0x782820: r16 = Instance_GestureDisposition
    //     0x782820: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x782824: ldr             x16, [x16, #0xed0]
    // 0x782828: stp             x16, x0, [SP, #-0x10]!
    // 0x78282c: r0 = resolve()
    //     0x78282c: bl              #0x7154a4  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::resolve
    // 0x782830: add             SP, SP, #0x10
    // 0x782834: ldr             x0, [fp, #0x10]
    // 0x782838: r1 = true
    //     0x782838: add             x1, NULL, #0x20  ; true
    // 0x78283c: StoreField: r0->field_43 = r1
    //     0x78283c: stur            w1, [x0, #0x43]
    // 0x782840: LoadField: r1 = r0->field_33
    //     0x782840: ldur            w1, [x0, #0x33]
    // 0x782844: DecompressPointer r1
    //     0x782844: add             x1, x1, HEAP, lsl #32
    // 0x782848: cmp             w1, NULL
    // 0x78284c: b.eq            #0x782890
    // 0x782850: r2 = LoadInt32Instr(r1)
    //     0x782850: sbfx            x2, x1, #1, #0x1f
    //     0x782854: tbz             w1, #0, #0x78285c
    //     0x782858: ldur            x2, [x1, #7]
    // 0x78285c: stp             x2, x0, [SP, #-0x10]!
    // 0x782860: r0 = acceptGesture()
    //     0x782860: bl              #0x782a5c  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::acceptGesture
    // 0x782864: add             SP, SP, #0x10
    // 0x782868: ldr             x16, [fp, #0x10]
    // 0x78286c: SaveReg r16
    //     0x78286c: str             x16, [SP, #-8]!
    // 0x782870: r0 = _checkLongPressStart()
    //     0x782870: bl              #0x782894  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressStart
    // 0x782874: add             SP, SP, #8
    // 0x782878: r0 = Null
    //     0x782878: mov             x0, NULL
    // 0x78287c: LeaveFrame
    //     0x78287c: mov             SP, fp
    //     0x782880: ldp             fp, lr, [SP], #0x10
    // 0x782884: ret
    //     0x782884: ret             
    // 0x782888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782888: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78288c: b               #0x7827e8
    // 0x782890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x782890: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x782a5c, size: 0xa8
    // 0x782a5c: EnterFrame
    //     0x782a5c: stp             fp, lr, [SP, #-0x10]!
    //     0x782a60: mov             fp, SP
    // 0x782a64: CheckStackOverflow
    //     0x782a64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782a68: cmp             SP, x16
    //     0x782a6c: b.ls            #0x782afc
    // 0x782a70: ldr             x2, [fp, #0x18]
    // 0x782a74: LoadField: r3 = r2->field_33
    //     0x782a74: ldur            w3, [x2, #0x33]
    // 0x782a78: DecompressPointer r3
    //     0x782a78: add             x3, x3, HEAP, lsl #32
    // 0x782a7c: ldr             x4, [fp, #0x10]
    // 0x782a80: r0 = BoxInt64Instr(r4)
    //     0x782a80: sbfiz           x0, x4, #1, #0x1f
    //     0x782a84: cmp             x4, x0, asr #1
    //     0x782a88: b.eq            #0x782a94
    //     0x782a8c: bl              #0xd69bb8
    //     0x782a90: stur            x4, [x0, #7]
    // 0x782a94: cmp             w0, w3
    // 0x782a98: b.eq            #0x782ad4
    // 0x782a9c: and             w16, w0, w3
    // 0x782aa0: branchIfSmi(r16, 0x782aec)
    //     0x782aa0: tbz             w16, #0, #0x782aec
    // 0x782aa4: r16 = LoadClassIdInstr(r0)
    //     0x782aa4: ldur            x16, [x0, #-1]
    //     0x782aa8: ubfx            x16, x16, #0xc, #0x14
    // 0x782aac: cmp             x16, #0x3c
    // 0x782ab0: b.ne            #0x782aec
    // 0x782ab4: r16 = LoadClassIdInstr(r3)
    //     0x782ab4: ldur            x16, [x3, #-1]
    //     0x782ab8: ubfx            x16, x16, #0xc, #0x14
    // 0x782abc: cmp             x16, #0x3c
    // 0x782ac0: b.ne            #0x782aec
    // 0x782ac4: LoadField: r16 = r0->field_7
    //     0x782ac4: ldur            x16, [x0, #7]
    // 0x782ac8: LoadField: r17 = r3->field_7
    //     0x782ac8: ldur            x17, [x3, #7]
    // 0x782acc: cmp             x16, x17
    // 0x782ad0: b.ne            #0x782aec
    // 0x782ad4: SaveReg r2
    //     0x782ad4: str             x2, [SP, #-8]!
    // 0x782ad8: r0 = _stopTimer()
    //     0x782ad8: bl              #0x714474  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_stopTimer
    // 0x782adc: add             SP, SP, #8
    // 0x782ae0: ldr             x1, [fp, #0x18]
    // 0x782ae4: r2 = true
    //     0x782ae4: add             x2, NULL, #0x20  ; true
    // 0x782ae8: StoreField: r1->field_3b = r2
    //     0x782ae8: stur            w2, [x1, #0x3b]
    // 0x782aec: r0 = Null
    //     0x782aec: mov             x0, NULL
    // 0x782af0: LeaveFrame
    //     0x782af0: mov             SP, fp
    //     0x782af4: ldp             fp, lr, [SP], #0x10
    // 0x782af8: ret
    //     0x782af8: ret             
    // 0x782afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782afc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782b00: b               #0x782a70
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0x7893b0, size: 0x18
    // 0x7893b0: r4 = 0
    //     0x7893b0: mov             x4, #0
    // 0x7893b4: r1 = Function 'handleEvent':.
    //     0x7893b4: add             x17, PP, #0x2f, lsl #12  ; [pp+0x2f078] AnonymousClosure: (0x7893c8), in [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::handleEvent (0x789414)
    //     0x7893b8: ldr             x1, [x17, #0x78]
    // 0x7893bc: r24 = BuildNonGenericMethodExtractorStub
    //     0x7893bc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x7893c0: LoadField: r0 = r24->field_17
    //     0x7893c0: ldur            x0, [x24, #0x17]
    // 0x7893c4: br              x0
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x7893c8, size: 0x4c
    // 0x7893c8: EnterFrame
    //     0x7893c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7893cc: mov             fp, SP
    // 0x7893d0: ldr             x0, [fp, #0x18]
    // 0x7893d4: LoadField: r1 = r0->field_17
    //     0x7893d4: ldur            w1, [x0, #0x17]
    // 0x7893d8: DecompressPointer r1
    //     0x7893d8: add             x1, x1, HEAP, lsl #32
    // 0x7893dc: CheckStackOverflow
    //     0x7893dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7893e0: cmp             SP, x16
    //     0x7893e4: b.ls            #0x78940c
    // 0x7893e8: LoadField: r0 = r1->field_f
    //     0x7893e8: ldur            w0, [x1, #0xf]
    // 0x7893ec: DecompressPointer r0
    //     0x7893ec: add             x0, x0, HEAP, lsl #32
    // 0x7893f0: ldr             x16, [fp, #0x10]
    // 0x7893f4: stp             x16, x0, [SP, #-0x10]!
    // 0x7893f8: r0 = handleEvent()
    //     0x7893f8: bl              #0x789414  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::handleEvent
    // 0x7893fc: add             SP, SP, #0x10
    // 0x789400: LeaveFrame
    //     0x789400: mov             SP, fp
    //     0x789404: ldp             fp, lr, [SP], #0x10
    // 0x789408: ret
    //     0x789408: ret             
    // 0x78940c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78940c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x789410: b               #0x7893e8
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x789414, size: 0x2f0
    // 0x789414: EnterFrame
    //     0x789414: stp             fp, lr, [SP, #-0x10]!
    //     0x789418: mov             fp, SP
    // 0x78941c: AllocStack(0x10)
    //     0x78941c: sub             SP, SP, #0x10
    // 0x789420: CheckStackOverflow
    //     0x789420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x789424: cmp             SP, x16
    //     0x789428: b.ls            #0x7896f8
    // 0x78942c: ldr             x1, [fp, #0x18]
    // 0x789430: LoadField: r0 = r1->field_2f
    //     0x789430: ldur            w0, [x1, #0x2f]
    // 0x789434: DecompressPointer r0
    //     0x789434: add             x0, x0, HEAP, lsl #32
    // 0x789438: r16 = Instance_GestureRecognizerState
    //     0x789438: add             x16, PP, #0x29, lsl #12  ; [pp+0x29248] Obj!GestureRecognizerState@b65ab1
    //     0x78943c: ldr             x16, [x16, #0x248]
    // 0x789440: cmp             w0, w16
    // 0x789444: b.ne            #0x7896d4
    // 0x789448: ldr             x2, [fp, #0x10]
    // 0x78944c: r0 = LoadClassIdInstr(r2)
    //     0x78944c: ldur            x0, [x2, #-1]
    //     0x789450: ubfx            x0, x0, #0xc, #0x14
    // 0x789454: SaveReg r2
    //     0x789454: str             x2, [SP, #-8]!
    // 0x789458: r0 = GDT[cid_x0 + -0xfff]()
    //     0x789458: sub             lr, x0, #0xfff
    //     0x78945c: ldr             lr, [x21, lr, lsl #3]
    //     0x789460: blr             lr
    // 0x789464: add             SP, SP, #8
    // 0x789468: mov             x3, x0
    // 0x78946c: ldr             x2, [fp, #0x18]
    // 0x789470: LoadField: r4 = r2->field_33
    //     0x789470: ldur            w4, [x2, #0x33]
    // 0x789474: DecompressPointer r4
    //     0x789474: add             x4, x4, HEAP, lsl #32
    // 0x789478: r0 = BoxInt64Instr(r3)
    //     0x789478: sbfiz           x0, x3, #1, #0x1f
    //     0x78947c: cmp             x3, x0, asr #1
    //     0x789480: b.eq            #0x78948c
    //     0x789484: bl              #0xd69bb8
    //     0x789488: stur            x3, [x0, #7]
    // 0x78948c: cmp             w0, w4
    // 0x789490: b.eq            #0x7894cc
    // 0x789494: and             w16, w0, w4
    // 0x789498: branchIfSmi(r16, 0x7896d4)
    //     0x789498: tbz             w16, #0, #0x7896d4
    // 0x78949c: r16 = LoadClassIdInstr(r0)
    //     0x78949c: ldur            x16, [x0, #-1]
    //     0x7894a0: ubfx            x16, x16, #0xc, #0x14
    // 0x7894a4: cmp             x16, #0x3c
    // 0x7894a8: b.ne            #0x7896d4
    // 0x7894ac: r16 = LoadClassIdInstr(r4)
    //     0x7894ac: ldur            x16, [x4, #-1]
    //     0x7894b0: ubfx            x16, x16, #0xc, #0x14
    // 0x7894b4: cmp             x16, #0x3c
    // 0x7894b8: b.ne            #0x7896d4
    // 0x7894bc: LoadField: r16 = r0->field_7
    //     0x7894bc: ldur            x16, [x0, #7]
    // 0x7894c0: LoadField: r17 = r4->field_7
    //     0x7894c0: ldur            x17, [x4, #7]
    // 0x7894c4: cmp             x16, x17
    // 0x7894c8: b.ne            #0x7896d4
    // 0x7894cc: LoadField: r0 = r2->field_3b
    //     0x7894cc: ldur            w0, [x2, #0x3b]
    // 0x7894d0: DecompressPointer r0
    //     0x7894d0: add             x0, x0, HEAP, lsl #32
    // 0x7894d4: tbz             w0, #4, #0x789510
    // 0x7894d8: ldr             x16, [fp, #0x10]
    // 0x7894dc: stp             x16, x2, [SP, #-0x10]!
    // 0x7894e0: r0 = _getGlobalDistance()
    //     0x7894e0: bl              #0x789704  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_getGlobalDistance
    // 0x7894e4: add             SP, SP, #0x10
    // 0x7894e8: mov             v1.16b, v0.16b
    // 0x7894ec: d0 = 18.000000
    //     0x7894ec: fmov            d0, #18.00000000
    // 0x7894f0: fcmp            d1, d0
    // 0x7894f4: b.vs            #0x7894fc
    // 0x7894f8: b.gt            #0x789504
    // 0x7894fc: r0 = false
    //     0x7894fc: add             x0, NULL, #0x30  ; false
    // 0x789500: b               #0x789508
    // 0x789504: r0 = true
    //     0x789504: add             x0, NULL, #0x20  ; true
    // 0x789508: mov             x1, x0
    // 0x78950c: b               #0x789514
    // 0x789510: r1 = false
    //     0x789510: add             x1, NULL, #0x30  ; false
    // 0x789514: ldr             x0, [fp, #0x18]
    // 0x789518: stur            x1, [fp, #-0x10]
    // 0x78951c: LoadField: r2 = r0->field_3b
    //     0x78951c: ldur            w2, [x0, #0x3b]
    // 0x789520: DecompressPointer r2
    //     0x789520: add             x2, x2, HEAP, lsl #32
    // 0x789524: tbnz            w2, #4, #0x789574
    // 0x789528: LoadField: r2 = r0->field_2b
    //     0x789528: ldur            w2, [x0, #0x2b]
    // 0x78952c: DecompressPointer r2
    //     0x78952c: add             x2, x2, HEAP, lsl #32
    // 0x789530: stur            x2, [fp, #-8]
    // 0x789534: cmp             w2, NULL
    // 0x789538: b.eq            #0x789574
    // 0x78953c: ldr             x16, [fp, #0x10]
    // 0x789540: stp             x16, x0, [SP, #-0x10]!
    // 0x789544: r0 = _getGlobalDistance()
    //     0x789544: bl              #0x789704  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_getGlobalDistance
    // 0x789548: add             SP, SP, #0x10
    // 0x78954c: ldur            x0, [fp, #-8]
    // 0x789550: LoadField: d1 = r0->field_7
    //     0x789550: ldur            d1, [x0, #7]
    // 0x789554: fcmp            d0, d1
    // 0x789558: b.vs            #0x789560
    // 0x78955c: b.gt            #0x789568
    // 0x789560: r0 = false
    //     0x789560: add             x0, NULL, #0x30  ; false
    // 0x789564: b               #0x78956c
    // 0x789568: r0 = true
    //     0x789568: add             x0, NULL, #0x20  ; true
    // 0x78956c: mov             x3, x0
    // 0x789570: b               #0x789578
    // 0x789574: r3 = false
    //     0x789574: add             x3, NULL, #0x30  ; false
    // 0x789578: ldr             x0, [fp, #0x10]
    // 0x78957c: stur            x3, [fp, #-8]
    // 0x789580: r2 = Null
    //     0x789580: mov             x2, NULL
    // 0x789584: r1 = Null
    //     0x789584: mov             x1, NULL
    // 0x789588: cmp             w0, NULL
    // 0x78958c: b.eq            #0x7895ac
    // 0x789590: branchIfSmi(r0, 0x7895ac)
    //     0x789590: tbz             w0, #0, #0x7895ac
    // 0x789594: r3 = LoadClassIdInstr(r0)
    //     0x789594: ldur            x3, [x0, #-1]
    //     0x789598: ubfx            x3, x3, #0xc, #0x14
    // 0x78959c: cmp             x3, #0x908
    // 0x7895a0: b.eq            #0x7895b4
    // 0x7895a4: cmp             x3, #0xb3f
    // 0x7895a8: b.eq            #0x7895b4
    // 0x7895ac: r0 = false
    //     0x7895ac: add             x0, NULL, #0x30  ; false
    // 0x7895b0: b               #0x7895b8
    // 0x7895b4: r0 = true
    //     0x7895b4: add             x0, NULL, #0x20  ; true
    // 0x7895b8: tbnz            w0, #4, #0x7896ac
    // 0x7895bc: ldur            x0, [fp, #-0x10]
    // 0x7895c0: tbz             w0, #4, #0x7895cc
    // 0x7895c4: ldur            x0, [fp, #-8]
    // 0x7895c8: tbnz            w0, #4, #0x7896ac
    // 0x7895cc: ldr             x0, [fp, #0x18]
    // 0x7895d0: r1 = LoadClassIdInstr(r0)
    //     0x7895d0: ldur            x1, [x0, #-1]
    //     0x7895d4: ubfx            x1, x1, #0xc, #0x14
    // 0x7895d8: lsl             x1, x1, #1
    // 0x7895dc: r17 = 4720
    //     0x7895dc: mov             x17, #0x1270
    // 0x7895e0: cmp             w1, w17
    // 0x7895e4: b.gt            #0x789640
    // 0x7895e8: r17 = 4716
    //     0x7895e8: mov             x17, #0x126c
    // 0x7895ec: cmp             w1, w17
    // 0x7895f0: b.lt            #0x789640
    // 0x7895f4: LoadField: r1 = r0->field_47
    //     0x7895f4: ldur            w1, [x0, #0x47]
    // 0x7895f8: DecompressPointer r1
    //     0x7895f8: add             x1, x1, HEAP, lsl #32
    // 0x7895fc: tbnz            w1, #4, #0x789624
    // 0x789600: r16 = "spontaneous"
    //     0x789600: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e7a8] "spontaneous"
    //     0x789604: ldr             x16, [x16, #0x7a8]
    // 0x789608: stp             x16, x0, [SP, #-0x10]!
    // 0x78960c: r0 = _checkCancel()
    //     0x78960c: bl              #0x71567c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkCancel
    // 0x789610: add             SP, SP, #0x10
    // 0x789614: ldr             x16, [fp, #0x18]
    // 0x789618: SaveReg r16
    //     0x789618: str             x16, [SP, #-8]!
    // 0x78961c: r0 = _reset()
    //     0x78961c: bl              #0x71565c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0x789620: add             SP, SP, #8
    // 0x789624: ldr             x16, [fp, #0x18]
    // 0x789628: r30 = Instance_GestureDisposition
    //     0x789628: add             lr, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x78962c: ldr             lr, [lr, #0xeb8]
    // 0x789630: stp             lr, x16, [SP, #-0x10]!
    // 0x789634: r0 = resolve()
    //     0x789634: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x789638: add             SP, SP, #0x10
    // 0x78963c: b               #0x789688
    // 0x789640: ldr             x0, [fp, #0x18]
    // 0x789644: LoadField: r1 = r0->field_43
    //     0x789644: ldur            w1, [x0, #0x43]
    // 0x789648: DecompressPointer r1
    //     0x789648: add             x1, x1, HEAP, lsl #32
    // 0x78964c: tbnz            w1, #4, #0x789660
    // 0x789650: SaveReg r0
    //     0x789650: str             x0, [SP, #-8]!
    // 0x789654: r0 = _reset()
    //     0x789654: bl              #0x7155c4  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_reset
    // 0x789658: add             SP, SP, #8
    // 0x78965c: b               #0x789670
    // 0x789660: ldr             x16, [fp, #0x18]
    // 0x789664: SaveReg r16
    //     0x789664: str             x16, [SP, #-8]!
    // 0x789668: r0 = _checkLongPressCancel()
    //     0x789668: bl              #0x71554c  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressCancel
    // 0x78966c: add             SP, SP, #8
    // 0x789670: ldr             x16, [fp, #0x18]
    // 0x789674: r30 = Instance_GestureDisposition
    //     0x789674: add             lr, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x789678: ldr             lr, [lr, #0xeb8]
    // 0x78967c: stp             lr, x16, [SP, #-0x10]!
    // 0x789680: r0 = resolve()
    //     0x789680: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x789684: add             SP, SP, #0x10
    // 0x789688: ldr             x0, [fp, #0x18]
    // 0x78968c: LoadField: r1 = r0->field_33
    //     0x78968c: ldur            w1, [x0, #0x33]
    // 0x789690: DecompressPointer r1
    //     0x789690: add             x1, x1, HEAP, lsl #32
    // 0x789694: cmp             w1, NULL
    // 0x789698: b.eq            #0x789700
    // 0x78969c: stp             x1, x0, [SP, #-0x10]!
    // 0x7896a0: r0 = stopTrackingPointer()
    //     0x7896a0: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x7896a4: add             SP, SP, #0x10
    // 0x7896a8: b               #0x7896d4
    // 0x7896ac: ldr             x1, [fp, #0x18]
    // 0x7896b0: r0 = LoadClassIdInstr(r1)
    //     0x7896b0: ldur            x0, [x1, #-1]
    //     0x7896b4: ubfx            x0, x0, #0xc, #0x14
    // 0x7896b8: ldr             x16, [fp, #0x10]
    // 0x7896bc: stp             x16, x1, [SP, #-0x10]!
    // 0x7896c0: r0 = GDT[cid_x0 + 0x18d2]()
    //     0x7896c0: mov             x17, #0x18d2
    //     0x7896c4: add             lr, x0, x17
    //     0x7896c8: ldr             lr, [x21, lr, lsl #3]
    //     0x7896cc: blr             lr
    // 0x7896d0: add             SP, SP, #0x10
    // 0x7896d4: ldr             x16, [fp, #0x18]
    // 0x7896d8: ldr             lr, [fp, #0x10]
    // 0x7896dc: stp             lr, x16, [SP, #-0x10]!
    // 0x7896e0: r0 = stopTrackingIfPointerNoLongerDown()
    //     0x7896e0: bl              #0x7891a8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0x7896e4: add             SP, SP, #0x10
    // 0x7896e8: r0 = Null
    //     0x7896e8: mov             x0, NULL
    // 0x7896ec: LeaveFrame
    //     0x7896ec: mov             SP, fp
    //     0x7896f0: ldp             fp, lr, [SP], #0x10
    // 0x7896f4: ret
    //     0x7896f4: ret             
    // 0x7896f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7896f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7896fc: b               #0x78942c
    // 0x789700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x789700: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getGlobalDistance(/* No info */) {
    // ** addr: 0x789704, size: 0x94
    // 0x789704: EnterFrame
    //     0x789704: stp             fp, lr, [SP, #-0x10]!
    //     0x789708: mov             fp, SP
    // 0x78970c: CheckStackOverflow
    //     0x78970c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x789710: cmp             SP, x16
    //     0x789714: b.ls            #0x78978c
    // 0x789718: ldr             x0, [fp, #0x10]
    // 0x78971c: r1 = LoadClassIdInstr(r0)
    //     0x78971c: ldur            x1, [x0, #-1]
    //     0x789720: ubfx            x1, x1, #0xc, #0x14
    // 0x789724: SaveReg r0
    //     0x789724: str             x0, [SP, #-8]!
    // 0x789728: mov             x0, x1
    // 0x78972c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x78972c: sub             lr, x0, #0xfd9
    //     0x789730: ldr             lr, [x21, lr, lsl #3]
    //     0x789734: blr             lr
    // 0x789738: add             SP, SP, #8
    // 0x78973c: mov             x1, x0
    // 0x789740: ldr             x0, [fp, #0x18]
    // 0x789744: LoadField: r2 = r0->field_37
    //     0x789744: ldur            w2, [x0, #0x37]
    // 0x789748: DecompressPointer r2
    //     0x789748: add             x2, x2, HEAP, lsl #32
    // 0x78974c: cmp             w2, NULL
    // 0x789750: b.eq            #0x789794
    // 0x789754: LoadField: r0 = r2->field_b
    //     0x789754: ldur            w0, [x2, #0xb]
    // 0x789758: DecompressPointer r0
    //     0x789758: add             x0, x0, HEAP, lsl #32
    // 0x78975c: stp             x0, x1, [SP, #-0x10]!
    // 0x789760: r0 = -()
    //     0x789760: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x789764: add             SP, SP, #0x10
    // 0x789768: LoadField: d1 = r0->field_7
    //     0x789768: ldur            d1, [x0, #7]
    // 0x78976c: fmul            d2, d1, d1
    // 0x789770: LoadField: d1 = r0->field_f
    //     0x789770: ldur            d1, [x0, #0xf]
    // 0x789774: fmul            d3, d1, d1
    // 0x789778: fadd            d1, d2, d3
    // 0x78977c: fsqrt           d0, d1
    // 0x789780: LeaveFrame
    //     0x789780: mov             SP, fp
    //     0x789784: ldp             fp, lr, [SP], #0x10
    // 0x789788: ret
    //     0x789788: ret             
    // 0x78978c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78978c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x789790: b               #0x789718
    // 0x789794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x789794: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbd924c, size: 0x4c
    // 0xbd924c: EnterFrame
    //     0xbd924c: stp             fp, lr, [SP, #-0x10]!
    //     0xbd9250: mov             fp, SP
    // 0xbd9254: CheckStackOverflow
    //     0xbd9254: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd9258: cmp             SP, x16
    //     0xbd925c: b.ls            #0xbd9290
    // 0xbd9260: ldr             x16, [fp, #0x10]
    // 0xbd9264: SaveReg r16
    //     0xbd9264: str             x16, [SP, #-8]!
    // 0xbd9268: r0 = _stopTimer()
    //     0xbd9268: bl              #0x714474  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_stopTimer
    // 0xbd926c: add             SP, SP, #8
    // 0xbd9270: ldr             x16, [fp, #0x10]
    // 0xbd9274: SaveReg r16
    //     0xbd9274: str             x16, [SP, #-8]!
    // 0xbd9278: r0 = dispose()
    //     0xbd9278: bl              #0xbd93a4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0xbd927c: add             SP, SP, #8
    // 0xbd9280: r0 = Null
    //     0xbd9280: mov             x0, NULL
    // 0xbd9284: LeaveFrame
    //     0xbd9284: mov             SP, fp
    //     0xbd9288: ldp             fp, lr, [SP], #0x10
    // 0xbd928c: ret
    //     0xbd928c: ret             
    // 0xbd9290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd9290: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd9294: b               #0xbd9260
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee2e8, size: 0xc4
    // 0xcee2e8: EnterFrame
    //     0xcee2e8: stp             fp, lr, [SP, #-0x10]!
    //     0xcee2ec: mov             fp, SP
    // 0xcee2f0: CheckStackOverflow
    //     0xcee2f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee2f4: cmp             SP, x16
    //     0xcee2f8: b.ls            #0xcee3a4
    // 0xcee2fc: ldr             x2, [fp, #0x18]
    // 0xcee300: LoadField: r3 = r2->field_33
    //     0xcee300: ldur            w3, [x2, #0x33]
    // 0xcee304: DecompressPointer r3
    //     0xcee304: add             x3, x3, HEAP, lsl #32
    // 0xcee308: ldr             x4, [fp, #0x10]
    // 0xcee30c: r0 = BoxInt64Instr(r4)
    //     0xcee30c: sbfiz           x0, x4, #1, #0x1f
    //     0xcee310: cmp             x4, x0, asr #1
    //     0xcee314: b.eq            #0xcee320
    //     0xcee318: bl              #0xd69bb8
    //     0xcee31c: stur            x4, [x0, #7]
    // 0xcee320: cmp             w0, w3
    // 0xcee324: b.eq            #0xcee360
    // 0xcee328: and             w16, w0, w3
    // 0xcee32c: branchIfSmi(r16, 0xcee394)
    //     0xcee32c: tbz             w16, #0, #0xcee394
    // 0xcee330: r16 = LoadClassIdInstr(r0)
    //     0xcee330: ldur            x16, [x0, #-1]
    //     0xcee334: ubfx            x16, x16, #0xc, #0x14
    // 0xcee338: cmp             x16, #0x3c
    // 0xcee33c: b.ne            #0xcee394
    // 0xcee340: r16 = LoadClassIdInstr(r3)
    //     0xcee340: ldur            x16, [x3, #-1]
    //     0xcee344: ubfx            x16, x16, #0xc, #0x14
    // 0xcee348: cmp             x16, #0x3c
    // 0xcee34c: b.ne            #0xcee394
    // 0xcee350: LoadField: r16 = r0->field_7
    //     0xcee350: ldur            x16, [x0, #7]
    // 0xcee354: LoadField: r17 = r3->field_7
    //     0xcee354: ldur            x17, [x3, #7]
    // 0xcee358: cmp             x16, x17
    // 0xcee35c: b.ne            #0xcee394
    // 0xcee360: LoadField: r0 = r2->field_2f
    //     0xcee360: ldur            w0, [x2, #0x2f]
    // 0xcee364: DecompressPointer r0
    //     0xcee364: add             x0, x0, HEAP, lsl #32
    // 0xcee368: r16 = Instance_GestureRecognizerState
    //     0xcee368: add             x16, PP, #0x29, lsl #12  ; [pp+0x29248] Obj!GestureRecognizerState@b65ab1
    //     0xcee36c: ldr             x16, [x16, #0x248]
    // 0xcee370: cmp             w0, w16
    // 0xcee374: b.ne            #0xcee394
    // 0xcee378: SaveReg r2
    //     0xcee378: str             x2, [SP, #-8]!
    // 0xcee37c: r0 = _stopTimer()
    //     0xcee37c: bl              #0x714474  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::_stopTimer
    // 0xcee380: add             SP, SP, #8
    // 0xcee384: ldr             x1, [fp, #0x18]
    // 0xcee388: r2 = Instance_GestureRecognizerState
    //     0xcee388: add             x2, PP, #0x29, lsl #12  ; [pp+0x29250] Obj!GestureRecognizerState@b65ad1
    //     0xcee38c: ldr             x2, [x2, #0x250]
    // 0xcee390: StoreField: r1->field_2f = r2
    //     0xcee390: stur            w2, [x1, #0x2f]
    // 0xcee394: r0 = Null
    //     0xcee394: mov             x0, NULL
    // 0xcee398: LeaveFrame
    //     0xcee398: mov             SP, fp
    //     0xcee39c: ldp             fp, lr, [SP], #0x10
    // 0xcee3a0: ret
    //     0xcee3a0: ret             
    // 0xcee3a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee3a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee3a8: b               #0xcee2fc
  }
}

// class id: 5977, size: 0x14, field offset: 0x14
enum GestureRecognizerState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15e58, size: 0x5c
    // 0xb15e58: EnterFrame
    //     0xb15e58: stp             fp, lr, [SP, #-0x10]!
    //     0xb15e5c: mov             fp, SP
    // 0xb15e60: CheckStackOverflow
    //     0xb15e60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15e64: cmp             SP, x16
    //     0xb15e68: b.ls            #0xb15eac
    // 0xb15e6c: r1 = Null
    //     0xb15e6c: mov             x1, NULL
    // 0xb15e70: r2 = 4
    //     0xb15e70: mov             x2, #4
    // 0xb15e74: r0 = AllocateArray()
    //     0xb15e74: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15e78: r17 = "GestureRecognizerState."
    //     0xb15e78: add             x17, PP, #0x29, lsl #12  ; [pp+0x29240] "GestureRecognizerState."
    //     0xb15e7c: ldr             x17, [x17, #0x240]
    // 0xb15e80: StoreField: r0->field_f = r17
    //     0xb15e80: stur            w17, [x0, #0xf]
    // 0xb15e84: ldr             x1, [fp, #0x10]
    // 0xb15e88: LoadField: r2 = r1->field_f
    //     0xb15e88: ldur            w2, [x1, #0xf]
    // 0xb15e8c: DecompressPointer r2
    //     0xb15e8c: add             x2, x2, HEAP, lsl #32
    // 0xb15e90: StoreField: r0->field_13 = r2
    //     0xb15e90: stur            w2, [x0, #0x13]
    // 0xb15e94: SaveReg r0
    //     0xb15e94: str             x0, [SP, #-8]!
    // 0xb15e98: r0 = _interpolate()
    //     0xb15e98: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15e9c: add             SP, SP, #8
    // 0xb15ea0: LeaveFrame
    //     0xb15ea0: mov             SP, fp
    //     0xb15ea4: ldp             fp, lr, [SP], #0x10
    // 0xb15ea8: ret
    //     0xb15ea8: ret             
    // 0xb15eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15eac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15eb0: b               #0xb15e6c
  }
}

// class id: 5978, size: 0x14, field offset: 0x14
enum DragStartBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15dfc, size: 0x5c
    // 0xb15dfc: EnterFrame
    //     0xb15dfc: stp             fp, lr, [SP, #-0x10]!
    //     0xb15e00: mov             fp, SP
    // 0xb15e04: CheckStackOverflow
    //     0xb15e04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15e08: cmp             SP, x16
    //     0xb15e0c: b.ls            #0xb15e50
    // 0xb15e10: r1 = Null
    //     0xb15e10: mov             x1, NULL
    // 0xb15e14: r2 = 4
    //     0xb15e14: mov             x2, #4
    // 0xb15e18: r0 = AllocateArray()
    //     0xb15e18: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15e1c: r17 = "DragStartBehavior."
    //     0xb15e1c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d540] "DragStartBehavior."
    //     0xb15e20: ldr             x17, [x17, #0x540]
    // 0xb15e24: StoreField: r0->field_f = r17
    //     0xb15e24: stur            w17, [x0, #0xf]
    // 0xb15e28: ldr             x1, [fp, #0x10]
    // 0xb15e2c: LoadField: r2 = r1->field_f
    //     0xb15e2c: ldur            w2, [x1, #0xf]
    // 0xb15e30: DecompressPointer r2
    //     0xb15e30: add             x2, x2, HEAP, lsl #32
    // 0xb15e34: StoreField: r0->field_13 = r2
    //     0xb15e34: stur            w2, [x0, #0x13]
    // 0xb15e38: SaveReg r0
    //     0xb15e38: str             x0, [SP, #-8]!
    // 0xb15e3c: r0 = _interpolate()
    //     0xb15e3c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15e40: add             SP, SP, #8
    // 0xb15e44: LeaveFrame
    //     0xb15e44: mov             SP, fp
    //     0xb15e48: ldp             fp, lr, [SP], #0x10
    // 0xb15e4c: ret
    //     0xb15e4c: ret             
    // 0xb15e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15e50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15e54: b               #0xb15e10
  }
}

// lib: , url: package:flutter/src/gestures/drag_details.dart

// class id: 1049155, size: 0x8
class :: {
}

// class id: 2325, size: 0x10, field offset: 0x8
class DragEndDetails extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad9454, size: 0x6c
    // 0xad9454: EnterFrame
    //     0xad9454: stp             fp, lr, [SP, #-0x10]!
    //     0xad9458: mov             fp, SP
    // 0xad945c: CheckStackOverflow
    //     0xad945c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9460: cmp             SP, x16
    //     0xad9464: b.ls            #0xad94b8
    // 0xad9468: r1 = Null
    //     0xad9468: mov             x1, NULL
    // 0xad946c: r2 = 8
    //     0xad946c: mov             x2, #8
    // 0xad9470: r0 = AllocateArray()
    //     0xad9470: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9474: r17 = "DragEndDetails"
    //     0xad9474: add             x17, PP, #0x37, lsl #12  ; [pp+0x37b38] "DragEndDetails"
    //     0xad9478: ldr             x17, [x17, #0xb38]
    // 0xad947c: StoreField: r0->field_f = r17
    //     0xad947c: stur            w17, [x0, #0xf]
    // 0xad9480: r17 = "("
    //     0xad9480: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad9484: StoreField: r0->field_13 = r17
    //     0xad9484: stur            w17, [x0, #0x13]
    // 0xad9488: ldr             x1, [fp, #0x10]
    // 0xad948c: LoadField: r2 = r1->field_7
    //     0xad948c: ldur            w2, [x1, #7]
    // 0xad9490: DecompressPointer r2
    //     0xad9490: add             x2, x2, HEAP, lsl #32
    // 0xad9494: StoreField: r0->field_17 = r2
    //     0xad9494: stur            w2, [x0, #0x17]
    // 0xad9498: r17 = ")"
    //     0xad9498: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad949c: StoreField: r0->field_1b = r17
    //     0xad949c: stur            w17, [x0, #0x1b]
    // 0xad94a0: SaveReg r0
    //     0xad94a0: str             x0, [SP, #-8]!
    // 0xad94a4: r0 = _interpolate()
    //     0xad94a4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad94a8: add             SP, SP, #8
    // 0xad94ac: LeaveFrame
    //     0xad94ac: mov             SP, fp
    //     0xad94b0: ldp             fp, lr, [SP], #0x10
    // 0xad94b4: ret
    //     0xad94b4: ret             
    // 0xad94b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad94b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad94bc: b               #0xad9468
  }
}

// class id: 2326, size: 0x1c, field offset: 0x8
class DragUpdateDetails extends Object {

  const Offset globalPosition(DragUpdateDetails) {
    // ** addr: 0x9bb214, size: 0x28
    // 0x9bb214: ldr             x1, [SP]
    // 0x9bb218: LoadField: r0 = r1->field_13
    //     0x9bb218: ldur            w0, [x1, #0x13]
    // 0x9bb21c: DecompressPointer r0
    //     0x9bb21c: add             x0, x0, HEAP, lsl #32
    // 0x9bb220: ret
    //     0x9bb220: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad93e8, size: 0x6c
    // 0xad93e8: EnterFrame
    //     0xad93e8: stp             fp, lr, [SP, #-0x10]!
    //     0xad93ec: mov             fp, SP
    // 0xad93f0: CheckStackOverflow
    //     0xad93f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad93f4: cmp             SP, x16
    //     0xad93f8: b.ls            #0xad944c
    // 0xad93fc: r1 = Null
    //     0xad93fc: mov             x1, NULL
    // 0xad9400: r2 = 8
    //     0xad9400: mov             x2, #8
    // 0xad9404: r0 = AllocateArray()
    //     0xad9404: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9408: r17 = "DragUpdateDetails"
    //     0xad9408: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e928] "DragUpdateDetails"
    //     0xad940c: ldr             x17, [x17, #0x928]
    // 0xad9410: StoreField: r0->field_f = r17
    //     0xad9410: stur            w17, [x0, #0xf]
    // 0xad9414: r17 = "("
    //     0xad9414: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad9418: StoreField: r0->field_13 = r17
    //     0xad9418: stur            w17, [x0, #0x13]
    // 0xad941c: ldr             x1, [fp, #0x10]
    // 0xad9420: LoadField: r2 = r1->field_b
    //     0xad9420: ldur            w2, [x1, #0xb]
    // 0xad9424: DecompressPointer r2
    //     0xad9424: add             x2, x2, HEAP, lsl #32
    // 0xad9428: StoreField: r0->field_17 = r2
    //     0xad9428: stur            w2, [x0, #0x17]
    // 0xad942c: r17 = ")"
    //     0xad942c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9430: StoreField: r0->field_1b = r17
    //     0xad9430: stur            w17, [x0, #0x1b]
    // 0xad9434: SaveReg r0
    //     0xad9434: str             x0, [SP, #-8]!
    // 0xad9438: r0 = _interpolate()
    //     0xad9438: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad943c: add             SP, SP, #8
    // 0xad9440: LeaveFrame
    //     0xad9440: mov             SP, fp
    //     0xad9444: ldp             fp, lr, [SP], #0x10
    // 0xad9448: ret
    //     0xad9448: ret             
    // 0xad944c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad944c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9450: b               #0xad93fc
  }
}

// class id: 2327, size: 0x18, field offset: 0x8
class DragStartDetails extends Object {

  const Offset globalPosition(DragStartDetails) {
    // ** addr: 0x9bbf34, size: 0x28
    // 0x9bbf34: ldr             x1, [SP]
    // 0x9bbf38: LoadField: r0 = r1->field_b
    //     0x9bbf38: ldur            w0, [x1, #0xb]
    // 0x9bbf3c: DecompressPointer r0
    //     0x9bbf3c: add             x0, x0, HEAP, lsl #32
    // 0x9bbf40: ret
    //     0x9bbf40: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad937c, size: 0x6c
    // 0xad937c: EnterFrame
    //     0xad937c: stp             fp, lr, [SP, #-0x10]!
    //     0xad9380: mov             fp, SP
    // 0xad9384: CheckStackOverflow
    //     0xad9384: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad9388: cmp             SP, x16
    //     0xad938c: b.ls            #0xad93e0
    // 0xad9390: r1 = Null
    //     0xad9390: mov             x1, NULL
    // 0xad9394: r2 = 8
    //     0xad9394: mov             x2, #8
    // 0xad9398: r0 = AllocateArray()
    //     0xad9398: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad939c: r17 = "DragStartDetails"
    //     0xad939c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e930] "DragStartDetails"
    //     0xad93a0: ldr             x17, [x17, #0x930]
    // 0xad93a4: StoreField: r0->field_f = r17
    //     0xad93a4: stur            w17, [x0, #0xf]
    // 0xad93a8: r17 = "("
    //     0xad93a8: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad93ac: StoreField: r0->field_13 = r17
    //     0xad93ac: stur            w17, [x0, #0x13]
    // 0xad93b0: ldr             x1, [fp, #0x10]
    // 0xad93b4: LoadField: r2 = r1->field_b
    //     0xad93b4: ldur            w2, [x1, #0xb]
    // 0xad93b8: DecompressPointer r2
    //     0xad93b8: add             x2, x2, HEAP, lsl #32
    // 0xad93bc: StoreField: r0->field_17 = r2
    //     0xad93bc: stur            w2, [x0, #0x17]
    // 0xad93c0: r17 = ")"
    //     0xad93c0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad93c4: StoreField: r0->field_1b = r17
    //     0xad93c4: stur            w17, [x0, #0x1b]
    // 0xad93c8: SaveReg r0
    //     0xad93c8: str             x0, [SP, #-8]!
    // 0xad93cc: r0 = _interpolate()
    //     0xad93cc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad93d0: add             SP, SP, #8
    // 0xad93d4: LeaveFrame
    //     0xad93d4: mov             SP, fp
    //     0xad93d8: ldp             fp, lr, [SP], #0x10
    // 0xad93dc: ret
    //     0xad93dc: ret             
    // 0xad93e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad93e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad93e4: b               #0xad9390
  }
}

// class id: 2328, size: 0xc, field offset: 0x8
class DragDownDetails extends Object {

  const Offset globalPosition(DragDownDetails) {
    // ** addr: 0xd64bac, size: 0x28
    // 0xd64bac: ldr             x1, [SP]
    // 0xd64bb0: LoadField: r0 = r1->field_7
    //     0xd64bb0: ldur            w0, [x1, #7]
    // 0xd64bb4: DecompressPointer r0
    //     0xd64bb4: add             x0, x0, HEAP, lsl #32
    // 0xd64bb8: ret
    //     0xd64bb8: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xad9310, size: 0x6c
    // 0xad9310: EnterFrame
    //     0xad9310: stp             fp, lr, [SP, #-0x10]!
    //     0xad9314: mov             fp, SP
    // 0xad9318: CheckStackOverflow
    //     0xad9318: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad931c: cmp             SP, x16
    //     0xad9320: b.ls            #0xad9374
    // 0xad9324: r1 = Null
    //     0xad9324: mov             x1, NULL
    // 0xad9328: r2 = 8
    //     0xad9328: mov             x2, #8
    // 0xad932c: r0 = AllocateArray()
    //     0xad932c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad9330: r17 = "DragDownDetails"
    //     0xad9330: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e938] "DragDownDetails"
    //     0xad9334: ldr             x17, [x17, #0x938]
    // 0xad9338: StoreField: r0->field_f = r17
    //     0xad9338: stur            w17, [x0, #0xf]
    // 0xad933c: r17 = "("
    //     0xad933c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad9340: StoreField: r0->field_13 = r17
    //     0xad9340: stur            w17, [x0, #0x13]
    // 0xad9344: ldr             x1, [fp, #0x10]
    // 0xad9348: LoadField: r2 = r1->field_7
    //     0xad9348: ldur            w2, [x1, #7]
    // 0xad934c: DecompressPointer r2
    //     0xad934c: add             x2, x2, HEAP, lsl #32
    // 0xad9350: StoreField: r0->field_17 = r2
    //     0xad9350: stur            w2, [x0, #0x17]
    // 0xad9354: r17 = ")"
    //     0xad9354: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9358: StoreField: r0->field_1b = r17
    //     0xad9358: stur            w17, [x0, #0x1b]
    // 0xad935c: SaveReg r0
    //     0xad935c: str             x0, [SP, #-8]!
    // 0xad9360: r0 = _interpolate()
    //     0xad9360: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad9364: add             SP, SP, #8
    // 0xad9368: LeaveFrame
    //     0xad9368: mov             SP, fp
    //     0xad936c: ldp             fp, lr, [SP], #0x10
    // 0xad9370: ret
    //     0xad9370: ret             
    // 0xad9374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9378: b               #0xad9324
  }
}

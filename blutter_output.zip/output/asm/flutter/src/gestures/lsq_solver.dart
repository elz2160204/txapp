// lib: , url: package:flutter/src/gestures/lsq_solver.dart

// class id: 1049162, size: 0x8
class :: {
}

// class id: 2272, size: 0x14, field offset: 0x8
class LeastSquaresSolver extends Object {

  _ solve(/* No info */) {
    // ** addr: 0xcb3b60, size: 0xb5c
    // 0xcb3b60: EnterFrame
    //     0xcb3b60: stp             fp, lr, [SP, #-0x10]!
    //     0xcb3b64: mov             fp, SP
    // 0xcb3b68: AllocStack(0x70)
    //     0xcb3b68: sub             SP, SP, #0x70
    // 0xcb3b6c: CheckStackOverflow
    //     0xcb3b6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3b70: cmp             SP, x16
    //     0xcb3b74: b.ls            #0xcb459c
    // 0xcb3b78: ldr             x0, [fp, #0x10]
    // 0xcb3b7c: LoadField: r1 = r0->field_7
    //     0xcb3b7c: ldur            w1, [x0, #7]
    // 0xcb3b80: DecompressPointer r1
    //     0xcb3b80: add             x1, x1, HEAP, lsl #32
    // 0xcb3b84: stur            x1, [fp, #-0x18]
    // 0xcb3b88: LoadField: r4 = r1->field_b
    //     0xcb3b88: ldur            w4, [x1, #0xb]
    // 0xcb3b8c: DecompressPointer r4
    //     0xcb3b8c: add             x4, x4, HEAP, lsl #32
    // 0xcb3b90: stur            x4, [fp, #-0x10]
    // 0xcb3b94: r2 = LoadInt32Instr(r4)
    //     0xcb3b94: sbfx            x2, x4, #1, #0x1f
    // 0xcb3b98: stur            x2, [fp, #-8]
    // 0xcb3b9c: cmp             x2, #2
    // 0xcb3ba0: b.ge            #0xcb3bb4
    // 0xcb3ba4: r0 = Null
    //     0xcb3ba4: mov             x0, NULL
    // 0xcb3ba8: LeaveFrame
    //     0xcb3ba8: mov             SP, fp
    //     0xcb3bac: ldp             fp, lr, [SP], #0x10
    // 0xcb3bb0: ret
    //     0xcb3bb0: ret             
    // 0xcb3bb4: r0 = PolynomialFit()
    //     0xcb3bb4: bl              #0xcb4b48  ; AllocatePolynomialFitStub -> PolynomialFit (size=0x10)
    // 0xcb3bb8: mov             x1, x0
    // 0xcb3bbc: r0 = Sentinel
    //     0xcb3bbc: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcb3bc0: stur            x1, [fp, #-0x20]
    // 0xcb3bc4: StoreField: r1->field_b = r0
    //     0xcb3bc4: stur            w0, [x1, #0xb]
    // 0xcb3bc8: r4 = 6
    //     0xcb3bc8: mov             x4, #6
    // 0xcb3bcc: r0 = AllocateFloat64Array()
    //     0xcb3bcc: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xcb3bd0: mov             x1, x0
    // 0xcb3bd4: ldur            x0, [fp, #-0x20]
    // 0xcb3bd8: stur            x1, [fp, #-0x28]
    // 0xcb3bdc: StoreField: r0->field_7 = r1
    //     0xcb3bdc: stur            w1, [x0, #7]
    // 0xcb3be0: r0 = _Matrix()
    //     0xcb3be0: bl              #0xcb4b3c  ; Allocate_MatrixStub -> _Matrix (size=0x14)
    // 0xcb3be4: mov             x1, x0
    // 0xcb3be8: ldur            x0, [fp, #-8]
    // 0xcb3bec: stur            x1, [fp, #-0x40]
    // 0xcb3bf0: StoreField: r1->field_7 = r0
    //     0xcb3bf0: stur            x0, [x1, #7]
    // 0xcb3bf4: r16 = 3
    //     0xcb3bf4: mov             x16, #3
    // 0xcb3bf8: mul             x2, x0, x16
    // 0xcb3bfc: stur            x2, [fp, #-0x38]
    // 0xcb3c00: lsl             x3, x2, #1
    // 0xcb3c04: mov             x4, x3
    // 0xcb3c08: stur            x3, [fp, #-0x30]
    // 0xcb3c0c: r0 = AllocateFloat64Array()
    //     0xcb3c0c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xcb3c10: mov             x3, x0
    // 0xcb3c14: ldur            x2, [fp, #-0x40]
    // 0xcb3c18: stur            x3, [fp, #-0x58]
    // 0xcb3c1c: StoreField: r2->field_f = r3
    //     0xcb3c1c: stur            w3, [x2, #0xf]
    // 0xcb3c20: ldr             x4, [fp, #0x10]
    // 0xcb3c24: LoadField: r5 = r4->field_f
    //     0xcb3c24: ldur            w5, [x4, #0xf]
    // 0xcb3c28: DecompressPointer r5
    //     0xcb3c28: add             x5, x5, HEAP, lsl #32
    // 0xcb3c2c: stur            x5, [fp, #-0x50]
    // 0xcb3c30: ldur            x7, [fp, #-0x18]
    // 0xcb3c34: ldur            x6, [fp, #-8]
    // 0xcb3c38: r8 = 0
    //     0xcb3c38: mov             x8, #0
    // 0xcb3c3c: stur            x8, [fp, #-0x48]
    // 0xcb3c40: CheckStackOverflow
    //     0xcb3c40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3c44: cmp             SP, x16
    //     0xcb3c48: b.ls            #0xcb45a4
    // 0xcb3c4c: cmp             x8, x6
    // 0xcb3c50: b.ge            #0xcb3d7c
    // 0xcb3c54: LoadField: r0 = r5->field_b
    //     0xcb3c54: ldur            w0, [x5, #0xb]
    // 0xcb3c58: DecompressPointer r0
    //     0xcb3c58: add             x0, x0, HEAP, lsl #32
    // 0xcb3c5c: r1 = LoadInt32Instr(r0)
    //     0xcb3c5c: sbfx            x1, x0, #1, #0x1f
    // 0xcb3c60: mov             x0, x1
    // 0xcb3c64: mov             x1, x8
    // 0xcb3c68: cmp             x1, x0
    // 0xcb3c6c: b.hs            #0xcb45ac
    // 0xcb3c70: LoadField: r9 = r5->field_f
    //     0xcb3c70: ldur            w9, [x5, #0xf]
    // 0xcb3c74: DecompressPointer r9
    //     0xcb3c74: add             x9, x9, HEAP, lsl #32
    // 0xcb3c78: r0 = BoxInt64Instr(r8)
    //     0xcb3c78: sbfiz           x0, x8, #1, #0x1f
    //     0xcb3c7c: cmp             x8, x0, asr #1
    //     0xcb3c80: b.eq            #0xcb3c8c
    //     0xcb3c84: bl              #0xd69bb8
    //     0xcb3c88: stur            x8, [x0, #7]
    // 0xcb3c8c: ArrayLoad: r1 = r9[r8]  ; Unknown_4
    //     0xcb3c8c: add             x16, x9, x8, lsl #2
    //     0xcb3c90: ldur            w1, [x16, #0xf]
    // 0xcb3c94: DecompressPointer r1
    //     0xcb3c94: add             x1, x1, HEAP, lsl #32
    // 0xcb3c98: LoadField: d0 = r1->field_7
    //     0xcb3c98: ldur            d0, [x1, #7]
    // 0xcb3c9c: stp             xzr, x2, [SP, #-0x10]!
    // 0xcb3ca0: SaveReg r0
    //     0xcb3ca0: str             x0, [SP, #-8]!
    // 0xcb3ca4: SaveReg d0
    //     0xcb3ca4: str             d0, [SP, #-8]!
    // 0xcb3ca8: r0 = set()
    //     0xcb3ca8: bl              #0xcb4ac4  ; [package:flutter/src/gestures/lsq_solver.dart] _Matrix::set
    // 0xcb3cac: add             SP, SP, #0x20
    // 0xcb3cb0: ldur            x2, [fp, #-0x18]
    // 0xcb3cb4: LoadField: r0 = r2->field_b
    //     0xcb3cb4: ldur            w0, [x2, #0xb]
    // 0xcb3cb8: DecompressPointer r0
    //     0xcb3cb8: add             x0, x0, HEAP, lsl #32
    // 0xcb3cbc: r3 = LoadInt32Instr(r0)
    //     0xcb3cbc: sbfx            x3, x0, #1, #0x1f
    // 0xcb3cc0: LoadField: r4 = r2->field_f
    //     0xcb3cc0: ldur            w4, [x2, #0xf]
    // 0xcb3cc4: DecompressPointer r4
    //     0xcb3cc4: add             x4, x4, HEAP, lsl #32
    // 0xcb3cc8: ldur            x7, [fp, #-0x48]
    // 0xcb3ccc: ldur            x5, [fp, #-0x58]
    // 0xcb3cd0: ldur            x6, [fp, #-8]
    // 0xcb3cd4: r8 = 1
    //     0xcb3cd4: mov             x8, #1
    // 0xcb3cd8: CheckStackOverflow
    //     0xcb3cd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3cdc: cmp             SP, x16
    //     0xcb3ce0: b.ls            #0xcb45b0
    // 0xcb3ce4: cmp             x8, #3
    // 0xcb3ce8: b.ge            #0xcb3d60
    // 0xcb3cec: sub             x0, x8, #1
    // 0xcb3cf0: mul             x1, x0, x6
    // 0xcb3cf4: add             x9, x1, x7
    // 0xcb3cf8: ldur            x0, [fp, #-0x38]
    // 0xcb3cfc: mov             x1, x9
    // 0xcb3d00: cmp             x1, x0
    // 0xcb3d04: b.hs            #0xcb45b8
    // 0xcb3d08: ArrayLoad: d0 = r5[r9]  ; Unknown_8
    //     0xcb3d08: add             x16, x5, x9, lsl #3
    //     0xcb3d0c: ldur            d0, [x16, #0x17]
    // 0xcb3d10: mov             x0, x3
    // 0xcb3d14: mov             x1, x7
    // 0xcb3d18: cmp             x1, x0
    // 0xcb3d1c: b.hs            #0xcb45bc
    // 0xcb3d20: ArrayLoad: r0 = r4[r7]  ; Unknown_4
    //     0xcb3d20: add             x16, x4, x7, lsl #2
    //     0xcb3d24: ldur            w0, [x16, #0xf]
    // 0xcb3d28: DecompressPointer r0
    //     0xcb3d28: add             x0, x0, HEAP, lsl #32
    // 0xcb3d2c: LoadField: d1 = r0->field_7
    //     0xcb3d2c: ldur            d1, [x0, #7]
    // 0xcb3d30: fmul            d2, d0, d1
    // 0xcb3d34: mul             x0, x8, x6
    // 0xcb3d38: add             x9, x0, x7
    // 0xcb3d3c: ldur            x0, [fp, #-0x38]
    // 0xcb3d40: mov             x1, x9
    // 0xcb3d44: cmp             x1, x0
    // 0xcb3d48: b.hs            #0xcb45c0
    // 0xcb3d4c: ArrayStore: r5[r9] = d2  ; Unknown_8
    //     0xcb3d4c: add             x0, x5, x9, lsl #3
    //     0xcb3d50: stur            d2, [x0, #0x17]
    // 0xcb3d54: add             x0, x8, #1
    // 0xcb3d58: mov             x8, x0
    // 0xcb3d5c: b               #0xcb3cd8
    // 0xcb3d60: add             x8, x7, #1
    // 0xcb3d64: ldr             x4, [fp, #0x10]
    // 0xcb3d68: mov             x7, x2
    // 0xcb3d6c: ldur            x2, [fp, #-0x40]
    // 0xcb3d70: mov             x3, x5
    // 0xcb3d74: ldur            x5, [fp, #-0x50]
    // 0xcb3d78: b               #0xcb3c3c
    // 0xcb3d7c: mov             x2, x7
    // 0xcb3d80: mov             x5, x3
    // 0xcb3d84: r0 = _Matrix()
    //     0xcb3d84: bl              #0xcb4b3c  ; Allocate_MatrixStub -> _Matrix (size=0x14)
    // 0xcb3d88: mov             x1, x0
    // 0xcb3d8c: ldur            x0, [fp, #-8]
    // 0xcb3d90: stur            x1, [fp, #-0x40]
    // 0xcb3d94: StoreField: r1->field_7 = r0
    //     0xcb3d94: stur            x0, [x1, #7]
    // 0xcb3d98: ldur            x4, [fp, #-0x30]
    // 0xcb3d9c: r0 = AllocateFloat64Array()
    //     0xcb3d9c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xcb3da0: mov             x1, x0
    // 0xcb3da4: ldur            x0, [fp, #-0x40]
    // 0xcb3da8: stur            x1, [fp, #-0x30]
    // 0xcb3dac: StoreField: r0->field_f = r1
    //     0xcb3dac: stur            w1, [x0, #0xf]
    // 0xcb3db0: r0 = _Matrix()
    //     0xcb3db0: bl              #0xcb4b3c  ; Allocate_MatrixStub -> _Matrix (size=0x14)
    // 0xcb3db4: mov             x1, x0
    // 0xcb3db8: r0 = 3
    //     0xcb3db8: mov             x0, #3
    // 0xcb3dbc: stur            x1, [fp, #-0x60]
    // 0xcb3dc0: StoreField: r1->field_7 = r0
    //     0xcb3dc0: stur            x0, [x1, #7]
    // 0xcb3dc4: r4 = 18
    //     0xcb3dc4: mov             x4, #0x12
    // 0xcb3dc8: r0 = AllocateFloat64Array()
    //     0xcb3dc8: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xcb3dcc: mov             x3, x0
    // 0xcb3dd0: ldur            x2, [fp, #-0x60]
    // 0xcb3dd4: stur            x3, [fp, #-0x68]
    // 0xcb3dd8: StoreField: r2->field_f = r3
    //     0xcb3dd8: stur            w3, [x2, #0xf]
    // 0xcb3ddc: ldur            x4, [fp, #-0x30]
    // 0xcb3de0: ldur            x6, [fp, #-0x58]
    // 0xcb3de4: ldur            x5, [fp, #-8]
    // 0xcb3de8: r7 = 0
    //     0xcb3de8: mov             x7, #0
    // 0xcb3dec: stur            x7, [fp, #-0x48]
    // 0xcb3df0: CheckStackOverflow
    //     0xcb3df0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3df4: cmp             SP, x16
    //     0xcb3df8: b.ls            #0xcb45c4
    // 0xcb3dfc: cmp             x7, #3
    // 0xcb3e00: b.ge            #0xcb40f0
    // 0xcb3e04: mul             x8, x7, x5
    // 0xcb3e08: r9 = 0
    //     0xcb3e08: mov             x9, #0
    // 0xcb3e0c: CheckStackOverflow
    //     0xcb3e0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3e10: cmp             SP, x16
    //     0xcb3e14: b.ls            #0xcb45cc
    // 0xcb3e18: cmp             x9, x5
    // 0xcb3e1c: b.ge            #0xcb3e50
    // 0xcb3e20: add             x10, x8, x9
    // 0xcb3e24: ldur            x0, [fp, #-0x38]
    // 0xcb3e28: mov             x1, x10
    // 0xcb3e2c: cmp             x1, x0
    // 0xcb3e30: b.hs            #0xcb45d4
    // 0xcb3e34: ArrayLoad: d0 = r6[r10]  ; Unknown_8
    //     0xcb3e34: add             x16, x6, x10, lsl #3
    //     0xcb3e38: ldur            d0, [x16, #0x17]
    // 0xcb3e3c: ArrayStore: r4[r10] = d0  ; Unknown_8
    //     0xcb3e3c: add             x0, x4, x10, lsl #3
    //     0xcb3e40: stur            d0, [x0, #0x17]
    // 0xcb3e44: add             x0, x9, #1
    // 0xcb3e48: mov             x9, x0
    // 0xcb3e4c: b               #0xcb3e0c
    // 0xcb3e50: mul             x8, x7, x5
    // 0xcb3e54: r9 = 0
    //     0xcb3e54: mov             x9, #0
    // 0xcb3e58: CheckStackOverflow
    //     0xcb3e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3e5c: cmp             SP, x16
    //     0xcb3e60: b.ls            #0xcb45d8
    // 0xcb3e64: cmp             x9, x7
    // 0xcb3e68: b.ge            #0xcb3f54
    // 0xcb3e6c: mul             x10, x9, x5
    // 0xcb3e70: d0 = 0.000000
    //     0xcb3e70: eor             v0.16b, v0.16b, v0.16b
    // 0xcb3e74: r11 = 0
    //     0xcb3e74: mov             x11, #0
    // 0xcb3e78: CheckStackOverflow
    //     0xcb3e78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3e7c: cmp             SP, x16
    //     0xcb3e80: b.ls            #0xcb45e0
    // 0xcb3e84: cmp             x11, x5
    // 0xcb3e88: b.ge            #0xcb3edc
    // 0xcb3e8c: add             x12, x11, x8
    // 0xcb3e90: ldur            x0, [fp, #-0x38]
    // 0xcb3e94: mov             x1, x12
    // 0xcb3e98: cmp             x1, x0
    // 0xcb3e9c: b.hs            #0xcb45e8
    // 0xcb3ea0: ArrayLoad: d1 = r4[r12]  ; Unknown_8
    //     0xcb3ea0: add             x16, x4, x12, lsl #3
    //     0xcb3ea4: ldur            d1, [x16, #0x17]
    // 0xcb3ea8: add             x12, x11, x10
    // 0xcb3eac: ldur            x0, [fp, #-0x38]
    // 0xcb3eb0: mov             x1, x12
    // 0xcb3eb4: cmp             x1, x0
    // 0xcb3eb8: b.hs            #0xcb45ec
    // 0xcb3ebc: ArrayLoad: d2 = r4[r12]  ; Unknown_8
    //     0xcb3ebc: add             x16, x4, x12, lsl #3
    //     0xcb3ec0: ldur            d2, [x16, #0x17]
    // 0xcb3ec4: fmul            d3, d1, d2
    // 0xcb3ec8: fadd            d1, d0, d3
    // 0xcb3ecc: add             x0, x11, #1
    // 0xcb3ed0: mov             v0.16b, v1.16b
    // 0xcb3ed4: mov             x11, x0
    // 0xcb3ed8: b               #0xcb3e78
    // 0xcb3edc: r11 = 0
    //     0xcb3edc: mov             x11, #0
    // 0xcb3ee0: CheckStackOverflow
    //     0xcb3ee0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3ee4: cmp             SP, x16
    //     0xcb3ee8: b.ls            #0xcb45f0
    // 0xcb3eec: cmp             x11, x5
    // 0xcb3ef0: b.ge            #0xcb3f48
    // 0xcb3ef4: add             x12, x8, x11
    // 0xcb3ef8: ldur            x0, [fp, #-0x38]
    // 0xcb3efc: mov             x1, x12
    // 0xcb3f00: cmp             x1, x0
    // 0xcb3f04: b.hs            #0xcb45f8
    // 0xcb3f08: ArrayLoad: d1 = r4[r12]  ; Unknown_8
    //     0xcb3f08: add             x16, x4, x12, lsl #3
    //     0xcb3f0c: ldur            d1, [x16, #0x17]
    // 0xcb3f10: add             x13, x10, x11
    // 0xcb3f14: ldur            x0, [fp, #-0x38]
    // 0xcb3f18: mov             x1, x13
    // 0xcb3f1c: cmp             x1, x0
    // 0xcb3f20: b.hs            #0xcb45fc
    // 0xcb3f24: ArrayLoad: d2 = r4[r13]  ; Unknown_8
    //     0xcb3f24: add             x16, x4, x13, lsl #3
    //     0xcb3f28: ldur            d2, [x16, #0x17]
    // 0xcb3f2c: fmul            d3, d0, d2
    // 0xcb3f30: fsub            d2, d1, d3
    // 0xcb3f34: ArrayStore: r4[r12] = d2  ; Unknown_8
    //     0xcb3f34: add             x0, x4, x12, lsl #3
    //     0xcb3f38: stur            d2, [x0, #0x17]
    // 0xcb3f3c: add             x0, x11, #1
    // 0xcb3f40: mov             x11, x0
    // 0xcb3f44: b               #0xcb3ee0
    // 0xcb3f48: add             x0, x9, #1
    // 0xcb3f4c: mov             x9, x0
    // 0xcb3f50: b               #0xcb3e58
    // 0xcb3f54: ldur            x16, [fp, #-0x40]
    // 0xcb3f58: stp             x7, x16, [SP, #-0x10]!
    // 0xcb3f5c: r0 = getRow()
    //     0xcb3f5c: bl              #0xcb4a6c  ; [package:flutter/src/gestures/lsq_solver.dart] _Matrix::getRow
    // 0xcb3f60: add             SP, SP, #0x10
    // 0xcb3f64: SaveReg r0
    //     0xcb3f64: str             x0, [SP, #-8]!
    // 0xcb3f68: r0 = norm()
    //     0xcb3f68: bl              #0xcb4a28  ; [package:flutter/src/gestures/lsq_solver.dart] _Vector::norm
    // 0xcb3f6c: add             SP, SP, #8
    // 0xcb3f70: mov             v1.16b, v0.16b
    // 0xcb3f74: d0 = 0.000000
    //     0xcb3f74: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0xcb3f78: ldr             d0, [x17, #0x1e0]
    // 0xcb3f7c: fcmp            d1, d0
    // 0xcb3f80: b.vs            #0xcb3f98
    // 0xcb3f84: b.ge            #0xcb3f98
    // 0xcb3f88: r0 = Null
    //     0xcb3f88: mov             x0, NULL
    // 0xcb3f8c: LeaveFrame
    //     0xcb3f8c: mov             SP, fp
    //     0xcb3f90: ldp             fp, lr, [SP], #0x10
    // 0xcb3f94: ret
    //     0xcb3f94: ret             
    // 0xcb3f98: ldur            x3, [fp, #-0x48]
    // 0xcb3f9c: ldur            x2, [fp, #-8]
    // 0xcb3fa0: d2 = 1.000000
    //     0xcb3fa0: fmov            d2, #1.00000000
    // 0xcb3fa4: fdiv            d3, d2, d1
    // 0xcb3fa8: mul             x4, x3, x2
    // 0xcb3fac: ldur            x5, [fp, #-0x30]
    // 0xcb3fb0: r6 = 0
    //     0xcb3fb0: mov             x6, #0
    // 0xcb3fb4: CheckStackOverflow
    //     0xcb3fb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb3fb8: cmp             SP, x16
    //     0xcb3fbc: b.ls            #0xcb4600
    // 0xcb3fc0: cmp             x6, x2
    // 0xcb3fc4: b.ge            #0xcb3ffc
    // 0xcb3fc8: add             x7, x4, x6
    // 0xcb3fcc: ldur            x0, [fp, #-0x38]
    // 0xcb3fd0: mov             x1, x7
    // 0xcb3fd4: cmp             x1, x0
    // 0xcb3fd8: b.hs            #0xcb4608
    // 0xcb3fdc: ArrayLoad: d1 = r5[r7]  ; Unknown_8
    //     0xcb3fdc: add             x16, x5, x7, lsl #3
    //     0xcb3fe0: ldur            d1, [x16, #0x17]
    // 0xcb3fe4: fmul            d4, d1, d3
    // 0xcb3fe8: ArrayStore: r5[r7] = d4  ; Unknown_8
    //     0xcb3fe8: add             x0, x5, x7, lsl #3
    //     0xcb3fec: stur            d4, [x0, #0x17]
    // 0xcb3ff0: add             x0, x6, #1
    // 0xcb3ff4: mov             x6, x0
    // 0xcb3ff8: b               #0xcb3fb4
    // 0xcb3ffc: mul             x4, x3, x2
    // 0xcb4000: r16 = 3
    //     0xcb4000: mov             x16, #3
    // 0xcb4004: mul             x6, x3, x16
    // 0xcb4008: ldur            x7, [fp, #-0x68]
    // 0xcb400c: ldur            x8, [fp, #-0x58]
    // 0xcb4010: r9 = 0
    //     0xcb4010: mov             x9, #0
    // 0xcb4014: CheckStackOverflow
    //     0xcb4014: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4018: cmp             SP, x16
    //     0xcb401c: b.ls            #0xcb460c
    // 0xcb4020: cmp             x9, #3
    // 0xcb4024: b.ge            #0xcb40d0
    // 0xcb4028: cmp             x9, x3
    // 0xcb402c: b.ge            #0xcb4038
    // 0xcb4030: d1 = 0.000000
    //     0xcb4030: eor             v1.16b, v1.16b, v1.16b
    // 0xcb4034: b               #0xcb40a8
    // 0xcb4038: mul             x10, x9, x2
    // 0xcb403c: d1 = 0.000000
    //     0xcb403c: eor             v1.16b, v1.16b, v1.16b
    // 0xcb4040: r11 = 0
    //     0xcb4040: mov             x11, #0
    // 0xcb4044: CheckStackOverflow
    //     0xcb4044: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4048: cmp             SP, x16
    //     0xcb404c: b.ls            #0xcb4614
    // 0xcb4050: cmp             x11, x2
    // 0xcb4054: b.ge            #0xcb40a8
    // 0xcb4058: add             x12, x11, x4
    // 0xcb405c: ldur            x0, [fp, #-0x38]
    // 0xcb4060: mov             x1, x12
    // 0xcb4064: cmp             x1, x0
    // 0xcb4068: b.hs            #0xcb461c
    // 0xcb406c: ArrayLoad: d3 = r5[r12]  ; Unknown_8
    //     0xcb406c: add             x16, x5, x12, lsl #3
    //     0xcb4070: ldur            d3, [x16, #0x17]
    // 0xcb4074: add             x12, x11, x10
    // 0xcb4078: ldur            x0, [fp, #-0x38]
    // 0xcb407c: mov             x1, x12
    // 0xcb4080: cmp             x1, x0
    // 0xcb4084: b.hs            #0xcb4620
    // 0xcb4088: ArrayLoad: d4 = r8[r12]  ; Unknown_8
    //     0xcb4088: add             x16, x8, x12, lsl #3
    //     0xcb408c: ldur            d4, [x16, #0x17]
    // 0xcb4090: fmul            d5, d3, d4
    // 0xcb4094: fadd            d3, d1, d5
    // 0xcb4098: add             x0, x11, #1
    // 0xcb409c: mov             v1.16b, v3.16b
    // 0xcb40a0: mov             x11, x0
    // 0xcb40a4: b               #0xcb4044
    // 0xcb40a8: add             x10, x6, x9
    // 0xcb40ac: mov             x1, x10
    // 0xcb40b0: r0 = 9
    //     0xcb40b0: mov             x0, #9
    // 0xcb40b4: cmp             x1, x0
    // 0xcb40b8: b.hs            #0xcb4624
    // 0xcb40bc: ArrayStore: r7[r10] = d1  ; Unknown_8
    //     0xcb40bc: add             x0, x7, x10, lsl #3
    //     0xcb40c0: stur            d1, [x0, #0x17]
    // 0xcb40c4: add             x0, x9, #1
    // 0xcb40c8: mov             x9, x0
    // 0xcb40cc: b               #0xcb4014
    // 0xcb40d0: add             x0, x3, #1
    // 0xcb40d4: mov             x3, x7
    // 0xcb40d8: mov             x7, x0
    // 0xcb40dc: mov             x4, x5
    // 0xcb40e0: mov             x5, x2
    // 0xcb40e4: ldur            x2, [fp, #-0x60]
    // 0xcb40e8: mov             x6, x8
    // 0xcb40ec: b               #0xcb3dec
    // 0xcb40f0: ldr             x0, [fp, #0x10]
    // 0xcb40f4: mov             x7, x3
    // 0xcb40f8: mov             x2, x5
    // 0xcb40fc: d0 = 0.000000
    //     0xcb40fc: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0xcb4100: ldr             d0, [x17, #0x1e0]
    // 0xcb4104: d2 = 1.000000
    //     0xcb4104: fmov            d2, #1.00000000
    // 0xcb4108: r0 = _Vector()
    //     0xcb4108: bl              #0xcb4a1c  ; Allocate_VectorStub -> _Vector (size=0x1c)
    // 0xcb410c: mov             x1, x0
    // 0xcb4110: r0 = 0
    //     0xcb4110: mov             x0, #0
    // 0xcb4114: stur            x1, [fp, #-0x30]
    // 0xcb4118: StoreField: r1->field_7 = r0
    //     0xcb4118: stur            x0, [x1, #7]
    // 0xcb411c: ldur            x0, [fp, #-8]
    // 0xcb4120: StoreField: r1->field_f = r0
    //     0xcb4120: stur            x0, [x1, #0xf]
    // 0xcb4124: ldur            x4, [fp, #-0x10]
    // 0xcb4128: r0 = AllocateFloat64Array()
    //     0xcb4128: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xcb412c: ldur            x2, [fp, #-0x30]
    // 0xcb4130: StoreField: r2->field_17 = r0
    //     0xcb4130: stur            w0, [x2, #0x17]
    // 0xcb4134: ldr             x3, [fp, #0x10]
    // 0xcb4138: LoadField: r4 = r3->field_b
    //     0xcb4138: ldur            w4, [x3, #0xb]
    // 0xcb413c: DecompressPointer r4
    //     0xcb413c: add             x4, x4, HEAP, lsl #32
    // 0xcb4140: stur            x4, [fp, #-0x58]
    // 0xcb4144: r7 = 0
    //     0xcb4144: mov             x7, #0
    // 0xcb4148: ldur            x6, [fp, #-0x50]
    // 0xcb414c: ldur            x5, [fp, #-8]
    // 0xcb4150: stur            x7, [fp, #-0x38]
    // 0xcb4154: CheckStackOverflow
    //     0xcb4154: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4158: cmp             SP, x16
    //     0xcb415c: b.ls            #0xcb4628
    // 0xcb4160: cmp             x7, x5
    // 0xcb4164: b.ge            #0xcb423c
    // 0xcb4168: LoadField: r0 = r4->field_b
    //     0xcb4168: ldur            w0, [x4, #0xb]
    // 0xcb416c: DecompressPointer r0
    //     0xcb416c: add             x0, x0, HEAP, lsl #32
    // 0xcb4170: r1 = LoadInt32Instr(r0)
    //     0xcb4170: sbfx            x1, x0, #1, #0x1f
    // 0xcb4174: mov             x0, x1
    // 0xcb4178: mov             x1, x7
    // 0xcb417c: cmp             x1, x0
    // 0xcb4180: b.hs            #0xcb4630
    // 0xcb4184: LoadField: r8 = r4->field_f
    //     0xcb4184: ldur            w8, [x4, #0xf]
    // 0xcb4188: DecompressPointer r8
    //     0xcb4188: add             x8, x8, HEAP, lsl #32
    // 0xcb418c: r0 = BoxInt64Instr(r7)
    //     0xcb418c: sbfiz           x0, x7, #1, #0x1f
    //     0xcb4190: cmp             x7, x0, asr #1
    //     0xcb4194: b.eq            #0xcb41a0
    //     0xcb4198: bl              #0xd69bb8
    //     0xcb419c: stur            x7, [x0, #7]
    // 0xcb41a0: mov             x9, x0
    // 0xcb41a4: ArrayLoad: r10 = r8[r7]  ; Unknown_4
    //     0xcb41a4: add             x16, x8, x7, lsl #2
    //     0xcb41a8: ldur            w10, [x16, #0xf]
    // 0xcb41ac: DecompressPointer r10
    //     0xcb41ac: add             x10, x10, HEAP, lsl #32
    // 0xcb41b0: LoadField: r0 = r6->field_b
    //     0xcb41b0: ldur            w0, [x6, #0xb]
    // 0xcb41b4: DecompressPointer r0
    //     0xcb41b4: add             x0, x0, HEAP, lsl #32
    // 0xcb41b8: r1 = LoadInt32Instr(r0)
    //     0xcb41b8: sbfx            x1, x0, #1, #0x1f
    // 0xcb41bc: mov             x0, x1
    // 0xcb41c0: mov             x1, x7
    // 0xcb41c4: cmp             x1, x0
    // 0xcb41c8: b.hs            #0xcb4634
    // 0xcb41cc: LoadField: r0 = r6->field_f
    //     0xcb41cc: ldur            w0, [x6, #0xf]
    // 0xcb41d0: DecompressPointer r0
    //     0xcb41d0: add             x0, x0, HEAP, lsl #32
    // 0xcb41d4: ArrayLoad: r1 = r0[r7]  ; Unknown_4
    //     0xcb41d4: add             x16, x0, x7, lsl #2
    //     0xcb41d8: ldur            w1, [x16, #0xf]
    // 0xcb41dc: DecompressPointer r1
    //     0xcb41dc: add             x1, x1, HEAP, lsl #32
    // 0xcb41e0: LoadField: d0 = r10->field_7
    //     0xcb41e0: ldur            d0, [x10, #7]
    // 0xcb41e4: LoadField: d1 = r1->field_7
    //     0xcb41e4: ldur            d1, [x1, #7]
    // 0xcb41e8: fmul            d2, d0, d1
    // 0xcb41ec: r0 = inline_Allocate_Double()
    //     0xcb41ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcb41f0: add             x0, x0, #0x10
    //     0xcb41f4: cmp             x1, x0
    //     0xcb41f8: b.ls            #0xcb4638
    //     0xcb41fc: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb4200: sub             x0, x0, #0xf
    //     0xcb4204: mov             x1, #0xd108
    //     0xcb4208: movk            x1, #3, lsl #16
    //     0xcb420c: stur            x1, [x0, #-1]
    // 0xcb4210: StoreField: r0->field_7 = d2
    //     0xcb4210: stur            d2, [x0, #7]
    // 0xcb4214: stp             x9, x2, [SP, #-0x10]!
    // 0xcb4218: SaveReg r0
    //     0xcb4218: str             x0, [SP, #-8]!
    // 0xcb421c: r0 = []=()
    //     0xcb421c: bl              #0xcb49b4  ; [package:flutter/src/gestures/lsq_solver.dart] _Vector::[]=
    // 0xcb4220: add             SP, SP, #0x18
    // 0xcb4224: ldur            x0, [fp, #-0x38]
    // 0xcb4228: add             x7, x0, #1
    // 0xcb422c: ldr             x3, [fp, #0x10]
    // 0xcb4230: ldur            x2, [fp, #-0x30]
    // 0xcb4234: ldur            x4, [fp, #-0x58]
    // 0xcb4238: b               #0xcb4148
    // 0xcb423c: ldur            x1, [fp, #-0x28]
    // 0xcb4240: r2 = 2
    //     0xcb4240: mov             x2, #2
    // 0xcb4244: ldur            x0, [fp, #-0x68]
    // 0xcb4248: stur            x2, [fp, #-0x38]
    // 0xcb424c: CheckStackOverflow
    //     0xcb424c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4250: cmp             SP, x16
    //     0xcb4254: b.ls            #0xcb4668
    // 0xcb4258: tbnz            x2, #0x3f, #0xcb4350
    // 0xcb425c: ldur            x16, [fp, #-0x40]
    // 0xcb4260: stp             x2, x16, [SP, #-0x10]!
    // 0xcb4264: r0 = getRow()
    //     0xcb4264: bl              #0xcb4a6c  ; [package:flutter/src/gestures/lsq_solver.dart] _Matrix::getRow
    // 0xcb4268: add             SP, SP, #0x10
    // 0xcb426c: ldur            x16, [fp, #-0x30]
    // 0xcb4270: stp             x16, x0, [SP, #-0x10]!
    // 0xcb4274: r0 = *()
    //     0xcb4274: bl              #0xcb48e8  ; [package:flutter/src/gestures/lsq_solver.dart] _Vector::*
    // 0xcb4278: add             SP, SP, #0x10
    // 0xcb427c: ldur            x2, [fp, #-0x38]
    // 0xcb4280: r0 = BoxInt64Instr(r2)
    //     0xcb4280: sbfiz           x0, x2, #1, #0x1f
    //     0xcb4284: cmp             x2, x0, asr #1
    //     0xcb4288: b.eq            #0xcb4294
    //     0xcb428c: bl              #0xd69c6c
    //     0xcb4290: stur            x2, [x0, #7]
    // 0xcb4294: mov             x4, x0
    // 0xcb4298: ldur            x3, [fp, #-0x28]
    // 0xcb429c: ArrayStore: r3[r2] = d0  ; Unknown_8
    //     0xcb429c: add             x0, x3, x2, lsl #3
    //     0xcb42a0: stur            d0, [x0, #0x17]
    // 0xcb42a4: r16 = 3
    //     0xcb42a4: mov             x16, #3
    // 0xcb42a8: mul             x5, x2, x16
    // 0xcb42ac: ldur            x6, [fp, #-0x68]
    // 0xcb42b0: r7 = 2
    //     0xcb42b0: mov             x7, #2
    // 0xcb42b4: stur            d0, [fp, #-0x70]
    // 0xcb42b8: CheckStackOverflow
    //     0xcb42b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb42bc: cmp             SP, x16
    //     0xcb42c0: b.ls            #0xcb4670
    // 0xcb42c4: cmp             x7, x2
    // 0xcb42c8: b.le            #0xcb4310
    // 0xcb42cc: add             x8, x5, x7
    // 0xcb42d0: mov             x1, x8
    // 0xcb42d4: r0 = 9
    //     0xcb42d4: mov             x0, #9
    // 0xcb42d8: cmp             x1, x0
    // 0xcb42dc: b.hs            #0xcb4678
    // 0xcb42e0: ArrayLoad: d1 = r6[r8]  ; Unknown_8
    //     0xcb42e0: add             x16, x6, x8, lsl #3
    //     0xcb42e4: ldur            d1, [x16, #0x17]
    // 0xcb42e8: ArrayLoad: d2 = r3[r7]  ; Unknown_8
    //     0xcb42e8: add             x16, x3, x7, lsl #3
    //     0xcb42ec: ldur            d2, [x16, #0x17]
    // 0xcb42f0: fmul            d3, d1, d2
    // 0xcb42f4: fsub            d1, d0, d3
    // 0xcb42f8: ArrayStore: r3[r2] = d1  ; Unknown_8
    //     0xcb42f8: add             x0, x3, x2, lsl #3
    //     0xcb42fc: stur            d1, [x0, #0x17]
    // 0xcb4300: sub             x0, x7, #1
    // 0xcb4304: mov             x7, x0
    // 0xcb4308: mov             v0.16b, v1.16b
    // 0xcb430c: b               #0xcb42b4
    // 0xcb4310: ldur            x16, [fp, #-0x60]
    // 0xcb4314: stp             x4, x16, [SP, #-0x10]!
    // 0xcb4318: SaveReg r2
    //     0xcb4318: str             x2, [SP, #-8]!
    // 0xcb431c: r0 = get()
    //     0xcb431c: bl              #0xcb4884  ; [package:flutter/src/gestures/lsq_solver.dart] _Matrix::get
    // 0xcb4320: add             SP, SP, #0x18
    // 0xcb4324: mov             v1.16b, v0.16b
    // 0xcb4328: ldur            d0, [fp, #-0x70]
    // 0xcb432c: fdiv            d2, d0, d1
    // 0xcb4330: ldur            x2, [fp, #-0x38]
    // 0xcb4334: ldur            x3, [fp, #-0x28]
    // 0xcb4338: ArrayStore: r3[r2] = d2  ; Unknown_8
    //     0xcb4338: add             x4, x3, x2, lsl #3
    //     0xcb433c: stur            d2, [x4, #0x17]
    // 0xcb4340: sub             x0, x2, #1
    // 0xcb4344: mov             x2, x0
    // 0xcb4348: mov             x1, x3
    // 0xcb434c: b               #0xcb4244
    // 0xcb4350: ldur            x2, [fp, #-0x58]
    // 0xcb4354: mov             x3, x1
    // 0xcb4358: LoadField: r4 = r2->field_b
    //     0xcb4358: ldur            w4, [x2, #0xb]
    // 0xcb435c: DecompressPointer r4
    //     0xcb435c: add             x4, x4, HEAP, lsl #32
    // 0xcb4360: r5 = LoadInt32Instr(r4)
    //     0xcb4360: sbfx            x5, x4, #1, #0x1f
    // 0xcb4364: LoadField: r4 = r2->field_f
    //     0xcb4364: ldur            w4, [x2, #0xf]
    // 0xcb4368: DecompressPointer r4
    //     0xcb4368: add             x4, x4, HEAP, lsl #32
    // 0xcb436c: ldur            x6, [fp, #-8]
    // 0xcb4370: d0 = 0.000000
    //     0xcb4370: eor             v0.16b, v0.16b, v0.16b
    // 0xcb4374: r7 = 0
    //     0xcb4374: mov             x7, #0
    // 0xcb4378: CheckStackOverflow
    //     0xcb4378: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb437c: cmp             SP, x16
    //     0xcb4380: b.ls            #0xcb467c
    // 0xcb4384: cmp             x7, x6
    // 0xcb4388: b.ge            #0xcb43c0
    // 0xcb438c: mov             x0, x5
    // 0xcb4390: mov             x1, x7
    // 0xcb4394: cmp             x1, x0
    // 0xcb4398: b.hs            #0xcb4684
    // 0xcb439c: ArrayLoad: r8 = r4[r7]  ; Unknown_4
    //     0xcb439c: add             x16, x4, x7, lsl #2
    //     0xcb43a0: ldur            w8, [x16, #0xf]
    // 0xcb43a4: DecompressPointer r8
    //     0xcb43a4: add             x8, x8, HEAP, lsl #32
    // 0xcb43a8: LoadField: d1 = r8->field_7
    //     0xcb43a8: ldur            d1, [x8, #7]
    // 0xcb43ac: fadd            d2, d0, d1
    // 0xcb43b0: add             x0, x7, #1
    // 0xcb43b4: mov             v0.16b, v2.16b
    // 0xcb43b8: mov             x7, x0
    // 0xcb43bc: b               #0xcb4378
    // 0xcb43c0: ldur            x5, [fp, #-0x18]
    // 0xcb43c4: ldur            x4, [fp, #-0x50]
    // 0xcb43c8: ldur            x7, [fp, #-0x10]
    // 0xcb43cc: r16 = LoadInt32Instr(r7)
    //     0xcb43cc: sbfx            x16, x7, #1, #0x1f
    // 0xcb43d0: scvtf           d1, w16
    // 0xcb43d4: fdiv            d2, d0, d1
    // 0xcb43d8: LoadField: r8 = r2->field_b
    //     0xcb43d8: ldur            w8, [x2, #0xb]
    // 0xcb43dc: DecompressPointer r8
    //     0xcb43dc: add             x8, x8, HEAP, lsl #32
    // 0xcb43e0: r9 = LoadInt32Instr(r8)
    //     0xcb43e0: sbfx            x9, x8, #1, #0x1f
    // 0xcb43e4: LoadField: r8 = r2->field_f
    //     0xcb43e4: ldur            w8, [x2, #0xf]
    // 0xcb43e8: DecompressPointer r8
    //     0xcb43e8: add             x8, x8, HEAP, lsl #32
    // 0xcb43ec: LoadField: d0 = r3->field_17
    //     0xcb43ec: ldur            d0, [x3, #0x17]
    // 0xcb43f0: LoadField: r2 = r5->field_b
    //     0xcb43f0: ldur            w2, [x5, #0xb]
    // 0xcb43f4: DecompressPointer r2
    //     0xcb43f4: add             x2, x2, HEAP, lsl #32
    // 0xcb43f8: r10 = LoadInt32Instr(r2)
    //     0xcb43f8: sbfx            x10, x2, #1, #0x1f
    // 0xcb43fc: LoadField: r2 = r5->field_f
    //     0xcb43fc: ldur            w2, [x5, #0xf]
    // 0xcb4400: DecompressPointer r2
    //     0xcb4400: add             x2, x2, HEAP, lsl #32
    // 0xcb4404: LoadField: r5 = r4->field_b
    //     0xcb4404: ldur            w5, [x4, #0xb]
    // 0xcb4408: DecompressPointer r5
    //     0xcb4408: add             x5, x5, HEAP, lsl #32
    // 0xcb440c: r11 = LoadInt32Instr(r5)
    //     0xcb440c: sbfx            x11, x5, #1, #0x1f
    // 0xcb4410: LoadField: r5 = r4->field_f
    //     0xcb4410: ldur            w5, [x4, #0xf]
    // 0xcb4414: DecompressPointer r5
    //     0xcb4414: add             x5, x5, HEAP, lsl #32
    // 0xcb4418: d3 = 0.000000
    //     0xcb4418: eor             v3.16b, v3.16b, v3.16b
    // 0xcb441c: d1 = 0.000000
    //     0xcb441c: eor             v1.16b, v1.16b, v1.16b
    // 0xcb4420: r4 = 0
    //     0xcb4420: mov             x4, #0
    // 0xcb4424: CheckStackOverflow
    //     0xcb4424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4428: cmp             SP, x16
    //     0xcb442c: b.ls            #0xcb4688
    // 0xcb4430: cmp             x4, x6
    // 0xcb4434: b.ge            #0xcb4518
    // 0xcb4438: mov             x0, x9
    // 0xcb443c: mov             x1, x4
    // 0xcb4440: cmp             x1, x0
    // 0xcb4444: b.hs            #0xcb4690
    // 0xcb4448: ArrayLoad: r12 = r8[r4]  ; Unknown_4
    //     0xcb4448: add             x16, x8, x4, lsl #2
    //     0xcb444c: ldur            w12, [x16, #0xf]
    // 0xcb4450: DecompressPointer r12
    //     0xcb4450: add             x12, x12, HEAP, lsl #32
    // 0xcb4454: LoadField: d4 = r12->field_7
    //     0xcb4454: ldur            d4, [x12, #7]
    // 0xcb4458: fsub            d5, d4, d0
    // 0xcb445c: mov             x0, x10
    // 0xcb4460: mov             x1, x4
    // 0xcb4464: cmp             x1, x0
    // 0xcb4468: b.hs            #0xcb4694
    // 0xcb446c: ArrayLoad: r13 = r2[r4]  ; Unknown_4
    //     0xcb446c: add             x16, x2, x4, lsl #2
    //     0xcb4470: ldur            w13, [x16, #0xf]
    // 0xcb4474: DecompressPointer r13
    //     0xcb4474: add             x13, x13, HEAP, lsl #32
    // 0xcb4478: LoadField: d4 = r13->field_7
    //     0xcb4478: ldur            d4, [x13, #7]
    // 0xcb447c: d6 = 1.000000
    //     0xcb447c: fmov            d6, #1.00000000
    // 0xcb4480: r13 = 1
    //     0xcb4480: mov             x13, #1
    // 0xcb4484: CheckStackOverflow
    //     0xcb4484: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4488: cmp             SP, x16
    //     0xcb448c: b.ls            #0xcb4698
    // 0xcb4490: cmp             x13, #3
    // 0xcb4494: b.ge            #0xcb44c0
    // 0xcb4498: fmul            d7, d6, d4
    // 0xcb449c: ArrayLoad: d6 = r3[r13]  ; Unknown_8
    //     0xcb449c: add             x16, x3, x13, lsl #3
    //     0xcb44a0: ldur            d6, [x16, #0x17]
    // 0xcb44a4: fmul            d8, d7, d6
    // 0xcb44a8: fsub            d9, d5, d8
    // 0xcb44ac: add             x0, x13, #1
    // 0xcb44b0: mov             v6.16b, v7.16b
    // 0xcb44b4: mov             v5.16b, v9.16b
    // 0xcb44b8: mov             x13, x0
    // 0xcb44bc: b               #0xcb4484
    // 0xcb44c0: mov             x0, x11
    // 0xcb44c4: mov             x1, x4
    // 0xcb44c8: cmp             x1, x0
    // 0xcb44cc: b.hs            #0xcb46a0
    // 0xcb44d0: ArrayLoad: r1 = r5[r4]  ; Unknown_4
    //     0xcb44d0: add             x16, x5, x4, lsl #2
    //     0xcb44d4: ldur            w1, [x16, #0xf]
    // 0xcb44d8: DecompressPointer r1
    //     0xcb44d8: add             x1, x1, HEAP, lsl #32
    // 0xcb44dc: LoadField: d4 = r1->field_7
    //     0xcb44dc: ldur            d4, [x1, #7]
    // 0xcb44e0: fmul            d6, d4, d4
    // 0xcb44e4: fmul            d4, d6, d5
    // 0xcb44e8: fmul            d7, d4, d5
    // 0xcb44ec: fadd            d4, d3, d7
    // 0xcb44f0: LoadField: d5 = r12->field_7
    //     0xcb44f0: ldur            d5, [x12, #7]
    // 0xcb44f4: fsub            d7, d5, d2
    // 0xcb44f8: fmul            d5, d6, d7
    // 0xcb44fc: fmul            d6, d5, d7
    // 0xcb4500: fadd            d5, d1, d6
    // 0xcb4504: add             x0, x4, #1
    // 0xcb4508: mov             v3.16b, v4.16b
    // 0xcb450c: mov             v1.16b, v5.16b
    // 0xcb4510: mov             x4, x0
    // 0xcb4514: b               #0xcb4424
    // 0xcb4518: d0 = 0.000000
    //     0xcb4518: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1e0] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    //     0xcb451c: ldr             d0, [x17, #0x1e0]
    // 0xcb4520: fcmp            d1, d0
    // 0xcb4524: b.vs            #0xcb4534
    // 0xcb4528: b.gt            #0xcb4534
    // 0xcb452c: d0 = 1.000000
    //     0xcb452c: fmov            d0, #1.00000000
    // 0xcb4530: b               #0xcb4544
    // 0xcb4534: d0 = 1.000000
    //     0xcb4534: fmov            d0, #1.00000000
    // 0xcb4538: fdiv            d2, d3, d1
    // 0xcb453c: fsub            d1, d0, d2
    // 0xcb4540: mov             v0.16b, v1.16b
    // 0xcb4544: ldur            x1, [fp, #-0x20]
    // 0xcb4548: r0 = inline_Allocate_Double()
    //     0xcb4548: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xcb454c: add             x0, x0, #0x10
    //     0xcb4550: cmp             x2, x0
    //     0xcb4554: b.ls            #0xcb46a4
    //     0xcb4558: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb455c: sub             x0, x0, #0xf
    //     0xcb4560: mov             x2, #0xd108
    //     0xcb4564: movk            x2, #3, lsl #16
    //     0xcb4568: stur            x2, [x0, #-1]
    // 0xcb456c: StoreField: r0->field_7 = d0
    //     0xcb456c: stur            d0, [x0, #7]
    // 0xcb4570: StoreField: r1->field_b = r0
    //     0xcb4570: stur            w0, [x1, #0xb]
    //     0xcb4574: ldurb           w16, [x1, #-1]
    //     0xcb4578: ldurb           w17, [x0, #-1]
    //     0xcb457c: and             x16, x17, x16, lsr #2
    //     0xcb4580: tst             x16, HEAP, lsr #32
    //     0xcb4584: b.eq            #0xcb458c
    //     0xcb4588: bl              #0xd6826c
    // 0xcb458c: mov             x0, x1
    // 0xcb4590: LeaveFrame
    //     0xcb4590: mov             SP, fp
    //     0xcb4594: ldp             fp, lr, [SP], #0x10
    // 0xcb4598: ret
    //     0xcb4598: ret             
    // 0xcb459c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb459c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb45a0: b               #0xcb3b78
    // 0xcb45a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb45a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb45a8: b               #0xcb3c4c
    // 0xcb45ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb45ac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb45b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb45b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb45b4: b               #0xcb3ce4
    // 0xcb45b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb45b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb45bc: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb45bc: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb45c0: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb45c0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb45c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb45c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb45c8: b               #0xcb3dfc
    // 0xcb45cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb45cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb45d0: b               #0xcb3e18
    // 0xcb45d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb45d4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb45d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb45d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb45dc: b               #0xcb3e64
    // 0xcb45e0: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb45e0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb45e4: b               #0xcb3e84
    // 0xcb45e8: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb45e8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb45ec: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb45ec: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb45f0: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb45f0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb45f4: b               #0xcb3eec
    // 0xcb45f8: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb45f8: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb45fc: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb45fc: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb4600: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb4600: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb4604: b               #0xcb3fc0
    // 0xcb4608: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb4608: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb460c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb460c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb4610: b               #0xcb4020
    // 0xcb4614: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb4614: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb4618: b               #0xcb4050
    // 0xcb461c: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb461c: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb4620: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb4620: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb4624: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb4624: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb4628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb4628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb462c: b               #0xcb4160
    // 0xcb4630: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4630: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb4634: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4634: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb4638: SaveReg d2
    //     0xcb4638: str             q2, [SP, #-0x10]!
    // 0xcb463c: stp             x7, x9, [SP, #-0x10]!
    // 0xcb4640: stp             x5, x6, [SP, #-0x10]!
    // 0xcb4644: stp             x3, x4, [SP, #-0x10]!
    // 0xcb4648: SaveReg r2
    //     0xcb4648: str             x2, [SP, #-8]!
    // 0xcb464c: r0 = AllocateDouble()
    //     0xcb464c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb4650: RestoreReg r2
    //     0xcb4650: ldr             x2, [SP], #8
    // 0xcb4654: ldp             x3, x4, [SP], #0x10
    // 0xcb4658: ldp             x5, x6, [SP], #0x10
    // 0xcb465c: ldp             x7, x9, [SP], #0x10
    // 0xcb4660: RestoreReg d2
    //     0xcb4660: ldr             q2, [SP], #0x10
    // 0xcb4664: b               #0xcb4210
    // 0xcb4668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb4668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb466c: b               #0xcb4258
    // 0xcb4670: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb4670: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb4674: b               #0xcb42c4
    // 0xcb4678: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb4678: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb467c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb467c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb4680: b               #0xcb4384
    // 0xcb4684: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb4684: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb4688: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb4688: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb468c: b               #0xcb4430
    // 0xcb4690: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb4690: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb4694: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb4694: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb4698: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb4698: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb469c: b               #0xcb4490
    // 0xcb46a0: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb46a0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb46a4: SaveReg d0
    //     0xcb46a4: str             q0, [SP, #-0x10]!
    // 0xcb46a8: SaveReg r1
    //     0xcb46a8: str             x1, [SP, #-8]!
    // 0xcb46ac: r0 = AllocateDouble()
    //     0xcb46ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb46b0: RestoreReg r1
    //     0xcb46b0: ldr             x1, [SP], #8
    // 0xcb46b4: RestoreReg d0
    //     0xcb46b4: ldr             q0, [SP], #0x10
    // 0xcb46b8: b               #0xcb456c
  }
}

// class id: 2273, size: 0x10, field offset: 0x8
class PolynomialFit extends Object {

  late double confidence; // offset: 0xc
}

// class id: 2274, size: 0x14, field offset: 0x8
class _Matrix extends Object {

  _ get(/* No info */) {
    // ** addr: 0xcb4884, size: 0x64
    // 0xcb4884: EnterFrame
    //     0xcb4884: stp             fp, lr, [SP, #-0x10]!
    //     0xcb4888: mov             fp, SP
    // 0xcb488c: ldr             x2, [fp, #0x20]
    // 0xcb4890: LoadField: r3 = r2->field_f
    //     0xcb4890: ldur            w3, [x2, #0xf]
    // 0xcb4894: DecompressPointer r3
    //     0xcb4894: add             x3, x3, HEAP, lsl #32
    // 0xcb4898: LoadField: r4 = r2->field_7
    //     0xcb4898: ldur            x4, [x2, #7]
    // 0xcb489c: ldr             x2, [fp, #0x18]
    // 0xcb48a0: r5 = LoadInt32Instr(r2)
    //     0xcb48a0: sbfx            x5, x2, #1, #0x1f
    //     0xcb48a4: tbz             w2, #0, #0xcb48ac
    //     0xcb48a8: ldur            x5, [x2, #7]
    // 0xcb48ac: mul             x2, x5, x4
    // 0xcb48b0: ldr             x4, [fp, #0x10]
    // 0xcb48b4: add             x5, x2, x4
    // 0xcb48b8: LoadField: r2 = r3->field_13
    //     0xcb48b8: ldur            w2, [x3, #0x13]
    // 0xcb48bc: DecompressPointer r2
    //     0xcb48bc: add             x2, x2, HEAP, lsl #32
    // 0xcb48c0: r0 = LoadInt32Instr(r2)
    //     0xcb48c0: sbfx            x0, x2, #1, #0x1f
    // 0xcb48c4: mov             x1, x5
    // 0xcb48c8: cmp             x1, x0
    // 0xcb48cc: b.hs            #0xcb48e4
    // 0xcb48d0: ArrayLoad: d0 = r3[r5]  ; Unknown_8
    //     0xcb48d0: add             x16, x3, x5, lsl #3
    //     0xcb48d4: ldur            d0, [x16, #0x17]
    // 0xcb48d8: LeaveFrame
    //     0xcb48d8: mov             SP, fp
    //     0xcb48dc: ldp             fp, lr, [SP], #0x10
    // 0xcb48e0: ret
    //     0xcb48e0: ret             
    // 0xcb48e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb48e4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getRow(/* No info */) {
    // ** addr: 0xcb4a6c, size: 0x58
    // 0xcb4a6c: EnterFrame
    //     0xcb4a6c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb4a70: mov             fp, SP
    // 0xcb4a74: AllocStack(0x18)
    //     0xcb4a74: sub             SP, SP, #0x18
    // 0xcb4a78: ldr             x0, [fp, #0x18]
    // 0xcb4a7c: LoadField: r1 = r0->field_f
    //     0xcb4a7c: ldur            w1, [x0, #0xf]
    // 0xcb4a80: DecompressPointer r1
    //     0xcb4a80: add             x1, x1, HEAP, lsl #32
    // 0xcb4a84: stur            x1, [fp, #-0x18]
    // 0xcb4a88: LoadField: r2 = r0->field_7
    //     0xcb4a88: ldur            x2, [x0, #7]
    // 0xcb4a8c: ldr             x0, [fp, #0x10]
    // 0xcb4a90: stur            x2, [fp, #-0x10]
    // 0xcb4a94: mul             x3, x0, x2
    // 0xcb4a98: stur            x3, [fp, #-8]
    // 0xcb4a9c: r0 = _Vector()
    //     0xcb4a9c: bl              #0xcb4a1c  ; Allocate_VectorStub -> _Vector (size=0x1c)
    // 0xcb4aa0: ldur            x1, [fp, #-8]
    // 0xcb4aa4: StoreField: r0->field_7 = r1
    //     0xcb4aa4: stur            x1, [x0, #7]
    // 0xcb4aa8: ldur            x1, [fp, #-0x10]
    // 0xcb4aac: StoreField: r0->field_f = r1
    //     0xcb4aac: stur            x1, [x0, #0xf]
    // 0xcb4ab0: ldur            x1, [fp, #-0x18]
    // 0xcb4ab4: StoreField: r0->field_17 = r1
    //     0xcb4ab4: stur            w1, [x0, #0x17]
    // 0xcb4ab8: LeaveFrame
    //     0xcb4ab8: mov             SP, fp
    //     0xcb4abc: ldp             fp, lr, [SP], #0x10
    // 0xcb4ac0: ret
    //     0xcb4ac0: ret             
  }
  _ set(/* No info */) {
    // ** addr: 0xcb4ac4, size: 0x78
    // 0xcb4ac4: EnterFrame
    //     0xcb4ac4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb4ac8: mov             fp, SP
    // 0xcb4acc: ldr             x2, [fp, #0x28]
    // 0xcb4ad0: LoadField: r3 = r2->field_f
    //     0xcb4ad0: ldur            w3, [x2, #0xf]
    // 0xcb4ad4: DecompressPointer r3
    //     0xcb4ad4: add             x3, x3, HEAP, lsl #32
    // 0xcb4ad8: LoadField: r4 = r2->field_7
    //     0xcb4ad8: ldur            x4, [x2, #7]
    // 0xcb4adc: ldr             x2, [fp, #0x20]
    // 0xcb4ae0: r5 = LoadInt32Instr(r2)
    //     0xcb4ae0: sbfx            x5, x2, #1, #0x1f
    //     0xcb4ae4: tbz             w2, #0, #0xcb4aec
    //     0xcb4ae8: ldur            x5, [x2, #7]
    // 0xcb4aec: mul             x2, x5, x4
    // 0xcb4af0: ldr             x4, [fp, #0x18]
    // 0xcb4af4: r5 = LoadInt32Instr(r4)
    //     0xcb4af4: sbfx            x5, x4, #1, #0x1f
    //     0xcb4af8: tbz             w4, #0, #0xcb4b00
    //     0xcb4afc: ldur            x5, [x4, #7]
    // 0xcb4b00: add             x4, x2, x5
    // 0xcb4b04: LoadField: r2 = r3->field_13
    //     0xcb4b04: ldur            w2, [x3, #0x13]
    // 0xcb4b08: DecompressPointer r2
    //     0xcb4b08: add             x2, x2, HEAP, lsl #32
    // 0xcb4b0c: r0 = LoadInt32Instr(r2)
    //     0xcb4b0c: sbfx            x0, x2, #1, #0x1f
    // 0xcb4b10: mov             x1, x4
    // 0xcb4b14: cmp             x1, x0
    // 0xcb4b18: b.hs            #0xcb4b38
    // 0xcb4b1c: ldr             d0, [fp, #0x10]
    // 0xcb4b20: ArrayStore: r3[r4] = d0  ; Unknown_8
    //     0xcb4b20: add             x1, x3, x4, lsl #3
    //     0xcb4b24: stur            d0, [x1, #0x17]
    // 0xcb4b28: r0 = Null
    //     0xcb4b28: mov             x0, NULL
    // 0xcb4b2c: LeaveFrame
    //     0xcb4b2c: mov             SP, fp
    //     0xcb4b30: ldp             fp, lr, [SP], #0x10
    // 0xcb4b34: ret
    //     0xcb4b34: ret             
    // 0xcb4b38: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4b38: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2275, size: 0x1c, field offset: 0x8
class _Vector extends Object {

  void []=(_Vector, int, double) {
    // ** addr: 0xcb46d4, size: 0xe8
    // 0xcb46d4: EnterFrame
    //     0xcb46d4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb46d8: mov             fp, SP
    // 0xcb46dc: ldr             x0, [fp, #0x18]
    // 0xcb46e0: r2 = Null
    //     0xcb46e0: mov             x2, NULL
    // 0xcb46e4: r1 = Null
    //     0xcb46e4: mov             x1, NULL
    // 0xcb46e8: branchIfSmi(r0, 0xcb4710)
    //     0xcb46e8: tbz             w0, #0, #0xcb4710
    // 0xcb46ec: r4 = LoadClassIdInstr(r0)
    //     0xcb46ec: ldur            x4, [x0, #-1]
    //     0xcb46f0: ubfx            x4, x4, #0xc, #0x14
    // 0xcb46f4: sub             x4, x4, #0x3b
    // 0xcb46f8: cmp             x4, #1
    // 0xcb46fc: b.ls            #0xcb4710
    // 0xcb4700: r8 = int
    //     0xcb4700: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb4704: r3 = Null
    //     0xcb4704: add             x3, PP, #0x40, lsl #12  ; [pp+0x40328] Null
    //     0xcb4708: ldr             x3, [x3, #0x328]
    // 0xcb470c: r0 = int()
    //     0xcb470c: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb4710: ldr             x0, [fp, #0x10]
    // 0xcb4714: r2 = Null
    //     0xcb4714: mov             x2, NULL
    // 0xcb4718: r1 = Null
    //     0xcb4718: mov             x1, NULL
    // 0xcb471c: r4 = 59
    //     0xcb471c: mov             x4, #0x3b
    // 0xcb4720: branchIfSmi(r0, 0xcb472c)
    //     0xcb4720: tbz             w0, #0, #0xcb472c
    // 0xcb4724: r4 = LoadClassIdInstr(r0)
    //     0xcb4724: ldur            x4, [x0, #-1]
    //     0xcb4728: ubfx            x4, x4, #0xc, #0x14
    // 0xcb472c: cmp             x4, #0x3d
    // 0xcb4730: b.eq            #0xcb4744
    // 0xcb4734: r8 = double
    //     0xcb4734: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xcb4738: r3 = Null
    //     0xcb4738: add             x3, PP, #0x40, lsl #12  ; [pp+0x40338] Null
    //     0xcb473c: ldr             x3, [x3, #0x338]
    // 0xcb4740: r0 = double()
    //     0xcb4740: bl              #0xd72bac  ; IsType_double_Stub
    // 0xcb4744: ldr             x2, [fp, #0x20]
    // 0xcb4748: LoadField: r3 = r2->field_17
    //     0xcb4748: ldur            w3, [x2, #0x17]
    // 0xcb474c: DecompressPointer r3
    //     0xcb474c: add             x3, x3, HEAP, lsl #32
    // 0xcb4750: LoadField: r4 = r2->field_7
    //     0xcb4750: ldur            x4, [x2, #7]
    // 0xcb4754: ldr             x2, [fp, #0x18]
    // 0xcb4758: r5 = LoadInt32Instr(r2)
    //     0xcb4758: sbfx            x5, x2, #1, #0x1f
    //     0xcb475c: tbz             w2, #0, #0xcb4764
    //     0xcb4760: ldur            x5, [x2, #7]
    // 0xcb4764: add             x2, x5, x4
    // 0xcb4768: LoadField: r4 = r3->field_13
    //     0xcb4768: ldur            w4, [x3, #0x13]
    // 0xcb476c: DecompressPointer r4
    //     0xcb476c: add             x4, x4, HEAP, lsl #32
    // 0xcb4770: r0 = LoadInt32Instr(r4)
    //     0xcb4770: sbfx            x0, x4, #1, #0x1f
    // 0xcb4774: mov             x1, x2
    // 0xcb4778: cmp             x1, x0
    // 0xcb477c: b.hs            #0xcb47a0
    // 0xcb4780: ldr             x1, [fp, #0x10]
    // 0xcb4784: LoadField: d0 = r1->field_7
    //     0xcb4784: ldur            d0, [x1, #7]
    // 0xcb4788: ArrayStore: r3[r2] = d0  ; Unknown_8
    //     0xcb4788: add             x1, x3, x2, lsl #3
    //     0xcb478c: stur            d0, [x1, #0x17]
    // 0xcb4790: r0 = Null
    //     0xcb4790: mov             x0, NULL
    // 0xcb4794: LeaveFrame
    //     0xcb4794: mov             SP, fp
    //     0xcb4798: ldp             fp, lr, [SP], #0x10
    // 0xcb479c: ret
    //     0xcb479c: ret             
    // 0xcb47a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb47a0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  double [](_Vector, int) {
    // ** addr: 0xcb47bc, size: 0xe0
    // 0xcb47bc: EnterFrame
    //     0xcb47bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcb47c0: mov             fp, SP
    // 0xcb47c4: ldr             x0, [fp, #0x10]
    // 0xcb47c8: r2 = Null
    //     0xcb47c8: mov             x2, NULL
    // 0xcb47cc: r1 = Null
    //     0xcb47cc: mov             x1, NULL
    // 0xcb47d0: branchIfSmi(r0, 0xcb47f8)
    //     0xcb47d0: tbz             w0, #0, #0xcb47f8
    // 0xcb47d4: r4 = LoadClassIdInstr(r0)
    //     0xcb47d4: ldur            x4, [x0, #-1]
    //     0xcb47d8: ubfx            x4, x4, #0xc, #0x14
    // 0xcb47dc: sub             x4, x4, #0x3b
    // 0xcb47e0: cmp             x4, #1
    // 0xcb47e4: b.ls            #0xcb47f8
    // 0xcb47e8: r8 = int
    //     0xcb47e8: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xcb47ec: r3 = Null
    //     0xcb47ec: add             x3, PP, #0x40, lsl #12  ; [pp+0x40348] Null
    //     0xcb47f0: ldr             x3, [x3, #0x348]
    // 0xcb47f4: r0 = int()
    //     0xcb47f4: bl              #0xd73714  ; IsType_int_Stub
    // 0xcb47f8: ldr             x2, [fp, #0x18]
    // 0xcb47fc: LoadField: r3 = r2->field_17
    //     0xcb47fc: ldur            w3, [x2, #0x17]
    // 0xcb4800: DecompressPointer r3
    //     0xcb4800: add             x3, x3, HEAP, lsl #32
    // 0xcb4804: LoadField: r4 = r2->field_7
    //     0xcb4804: ldur            x4, [x2, #7]
    // 0xcb4808: ldr             x2, [fp, #0x10]
    // 0xcb480c: r5 = LoadInt32Instr(r2)
    //     0xcb480c: sbfx            x5, x2, #1, #0x1f
    //     0xcb4810: tbz             w2, #0, #0xcb4818
    //     0xcb4814: ldur            x5, [x2, #7]
    // 0xcb4818: add             x2, x5, x4
    // 0xcb481c: LoadField: r4 = r3->field_13
    //     0xcb481c: ldur            w4, [x3, #0x13]
    // 0xcb4820: DecompressPointer r4
    //     0xcb4820: add             x4, x4, HEAP, lsl #32
    // 0xcb4824: r0 = LoadInt32Instr(r4)
    //     0xcb4824: sbfx            x0, x4, #1, #0x1f
    // 0xcb4828: mov             x1, x2
    // 0xcb482c: cmp             x1, x0
    // 0xcb4830: b.hs            #0xcb4870
    // 0xcb4834: ArrayLoad: d0 = r3[r2]  ; Unknown_8
    //     0xcb4834: add             x16, x3, x2, lsl #3
    //     0xcb4838: ldur            d0, [x16, #0x17]
    // 0xcb483c: r0 = inline_Allocate_Double()
    //     0xcb483c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcb4840: add             x0, x0, #0x10
    //     0xcb4844: cmp             x1, x0
    //     0xcb4848: b.ls            #0xcb4874
    //     0xcb484c: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb4850: sub             x0, x0, #0xf
    //     0xcb4854: mov             x1, #0xd108
    //     0xcb4858: movk            x1, #3, lsl #16
    //     0xcb485c: stur            x1, [x0, #-1]
    // 0xcb4860: StoreField: r0->field_7 = d0
    //     0xcb4860: stur            d0, [x0, #7]
    // 0xcb4864: LeaveFrame
    //     0xcb4864: mov             SP, fp
    //     0xcb4868: ldp             fp, lr, [SP], #0x10
    // 0xcb486c: ret
    //     0xcb486c: ret             
    // 0xcb4870: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4870: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xcb4874: SaveReg d0
    //     0xcb4874: str             q0, [SP, #-0x10]!
    // 0xcb4878: r0 = AllocateDouble()
    //     0xcb4878: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb487c: RestoreReg d0
    //     0xcb487c: ldr             q0, [SP], #0x10
    // 0xcb4880: b               #0xcb4860
  }
  _ *(/* No info */) {
    // ** addr: 0xcb48e8, size: 0xcc
    // 0xcb48e8: EnterFrame
    //     0xcb48e8: stp             fp, lr, [SP, #-0x10]!
    //     0xcb48ec: mov             fp, SP
    // 0xcb48f0: ldr             x2, [fp, #0x18]
    // 0xcb48f4: LoadField: r3 = r2->field_f
    //     0xcb48f4: ldur            x3, [x2, #0xf]
    // 0xcb48f8: LoadField: r4 = r2->field_17
    //     0xcb48f8: ldur            w4, [x2, #0x17]
    // 0xcb48fc: DecompressPointer r4
    //     0xcb48fc: add             x4, x4, HEAP, lsl #32
    // 0xcb4900: LoadField: r5 = r2->field_7
    //     0xcb4900: ldur            x5, [x2, #7]
    // 0xcb4904: LoadField: r2 = r4->field_13
    //     0xcb4904: ldur            w2, [x4, #0x13]
    // 0xcb4908: DecompressPointer r2
    //     0xcb4908: add             x2, x2, HEAP, lsl #32
    // 0xcb490c: r6 = LoadInt32Instr(r2)
    //     0xcb490c: sbfx            x6, x2, #1, #0x1f
    // 0xcb4910: ldr             x2, [fp, #0x10]
    // 0xcb4914: LoadField: r7 = r2->field_17
    //     0xcb4914: ldur            w7, [x2, #0x17]
    // 0xcb4918: DecompressPointer r7
    //     0xcb4918: add             x7, x7, HEAP, lsl #32
    // 0xcb491c: LoadField: r8 = r2->field_7
    //     0xcb491c: ldur            x8, [x2, #7]
    // 0xcb4920: LoadField: r2 = r7->field_13
    //     0xcb4920: ldur            w2, [x7, #0x13]
    // 0xcb4924: DecompressPointer r2
    //     0xcb4924: add             x2, x2, HEAP, lsl #32
    // 0xcb4928: r9 = LoadInt32Instr(r2)
    //     0xcb4928: sbfx            x9, x2, #1, #0x1f
    // 0xcb492c: d0 = 0.000000
    //     0xcb492c: eor             v0.16b, v0.16b, v0.16b
    // 0xcb4930: r2 = 0
    //     0xcb4930: mov             x2, #0
    // 0xcb4934: CheckStackOverflow
    //     0xcb4934: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4938: cmp             SP, x16
    //     0xcb493c: b.ls            #0xcb49a4
    // 0xcb4940: cmp             x2, x3
    // 0xcb4944: b.ge            #0xcb4998
    // 0xcb4948: add             x10, x2, x5
    // 0xcb494c: mov             x0, x6
    // 0xcb4950: mov             x1, x10
    // 0xcb4954: cmp             x1, x0
    // 0xcb4958: b.hs            #0xcb49ac
    // 0xcb495c: ArrayLoad: d1 = r4[r10]  ; Unknown_8
    //     0xcb495c: add             x16, x4, x10, lsl #3
    //     0xcb4960: ldur            d1, [x16, #0x17]
    // 0xcb4964: add             x10, x2, x8
    // 0xcb4968: mov             x0, x9
    // 0xcb496c: mov             x1, x10
    // 0xcb4970: cmp             x1, x0
    // 0xcb4974: b.hs            #0xcb49b0
    // 0xcb4978: ArrayLoad: d2 = r7[r10]  ; Unknown_8
    //     0xcb4978: add             x16, x7, x10, lsl #3
    //     0xcb497c: ldur            d2, [x16, #0x17]
    // 0xcb4980: fmul            d3, d1, d2
    // 0xcb4984: fadd            d1, d0, d3
    // 0xcb4988: add             x0, x2, #1
    // 0xcb498c: mov             v0.16b, v1.16b
    // 0xcb4990: mov             x2, x0
    // 0xcb4994: b               #0xcb4934
    // 0xcb4998: LeaveFrame
    //     0xcb4998: mov             SP, fp
    //     0xcb499c: ldp             fp, lr, [SP], #0x10
    // 0xcb49a0: ret
    //     0xcb49a0: ret             
    // 0xcb49a4: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb49a4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb49a8: b               #0xcb4940
    // 0xcb49ac: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb49ac: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xcb49b0: r0 = RangeErrorSharedWithFPURegs()
    //     0xcb49b0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  void []=(_Vector, int, double) {
    // ** addr: 0xcb49b4, size: 0x68
    // 0xcb49b4: EnterFrame
    //     0xcb49b4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb49b8: mov             fp, SP
    // 0xcb49bc: ldr             x2, [fp, #0x20]
    // 0xcb49c0: LoadField: r3 = r2->field_17
    //     0xcb49c0: ldur            w3, [x2, #0x17]
    // 0xcb49c4: DecompressPointer r3
    //     0xcb49c4: add             x3, x3, HEAP, lsl #32
    // 0xcb49c8: LoadField: r4 = r2->field_7
    //     0xcb49c8: ldur            x4, [x2, #7]
    // 0xcb49cc: ldr             x2, [fp, #0x18]
    // 0xcb49d0: r5 = LoadInt32Instr(r2)
    //     0xcb49d0: sbfx            x5, x2, #1, #0x1f
    //     0xcb49d4: tbz             w2, #0, #0xcb49dc
    //     0xcb49d8: ldur            x5, [x2, #7]
    // 0xcb49dc: add             x2, x5, x4
    // 0xcb49e0: LoadField: r4 = r3->field_13
    //     0xcb49e0: ldur            w4, [x3, #0x13]
    // 0xcb49e4: DecompressPointer r4
    //     0xcb49e4: add             x4, x4, HEAP, lsl #32
    // 0xcb49e8: r0 = LoadInt32Instr(r4)
    //     0xcb49e8: sbfx            x0, x4, #1, #0x1f
    // 0xcb49ec: mov             x1, x2
    // 0xcb49f0: cmp             x1, x0
    // 0xcb49f4: b.hs            #0xcb4a18
    // 0xcb49f8: ldr             x1, [fp, #0x10]
    // 0xcb49fc: LoadField: d0 = r1->field_7
    //     0xcb49fc: ldur            d0, [x1, #7]
    // 0xcb4a00: ArrayStore: r3[r2] = d0  ; Unknown_8
    //     0xcb4a00: add             x1, x3, x2, lsl #3
    //     0xcb4a04: stur            d0, [x1, #0x17]
    // 0xcb4a08: r0 = Null
    //     0xcb4a08: mov             x0, NULL
    // 0xcb4a0c: LeaveFrame
    //     0xcb4a0c: mov             SP, fp
    //     0xcb4a10: ldp             fp, lr, [SP], #0x10
    // 0xcb4a14: ret
    //     0xcb4a14: ret             
    // 0xcb4a18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcb4a18: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ norm(/* No info */) {
    // ** addr: 0xcb4a28, size: 0x44
    // 0xcb4a28: EnterFrame
    //     0xcb4a28: stp             fp, lr, [SP, #-0x10]!
    //     0xcb4a2c: mov             fp, SP
    // 0xcb4a30: CheckStackOverflow
    //     0xcb4a30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb4a34: cmp             SP, x16
    //     0xcb4a38: b.ls            #0xcb4a64
    // 0xcb4a3c: ldr             x16, [fp, #0x10]
    // 0xcb4a40: ldr             lr, [fp, #0x10]
    // 0xcb4a44: stp             lr, x16, [SP, #-0x10]!
    // 0xcb4a48: r0 = *()
    //     0xcb4a48: bl              #0xcb48e8  ; [package:flutter/src/gestures/lsq_solver.dart] _Vector::*
    // 0xcb4a4c: add             SP, SP, #0x10
    // 0xcb4a50: fsqrt           d1, d0
    // 0xcb4a54: mov             v0.16b, v1.16b
    // 0xcb4a58: LeaveFrame
    //     0xcb4a58: mov             SP, fp
    //     0xcb4a5c: ldp             fp, lr, [SP], #0x10
    // 0xcb4a60: ret
    //     0xcb4a60: ret             
    // 0xcb4a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb4a64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb4a68: b               #0xcb4a3c
  }
}

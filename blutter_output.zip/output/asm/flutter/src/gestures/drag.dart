// lib: , url: package:flutter/src/gestures/drag.dart

// class id: 1049154, size: 0x8
class :: {
}

// class id: 2329, size: 0x8, field offset: 0x8
abstract class Drag extends Object {
}

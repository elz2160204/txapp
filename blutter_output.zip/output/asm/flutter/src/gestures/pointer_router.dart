// lib: , url: package:flutter/src/gestures/pointer_router.dart

// class id: 1049166, size: 0x8
class :: {
}

// class id: 2266, size: 0x10, field offset: 0x8
class PointerRouter extends Object {

  _ route(/* No info */) {
    // ** addr: 0x50a2ac, size: 0x128
    // 0x50a2ac: EnterFrame
    //     0x50a2ac: stp             fp, lr, [SP, #-0x10]!
    //     0x50a2b0: mov             fp, SP
    // 0x50a2b4: AllocStack(0x18)
    //     0x50a2b4: sub             SP, SP, #0x18
    // 0x50a2b8: CheckStackOverflow
    //     0x50a2b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50a2bc: cmp             SP, x16
    //     0x50a2c0: b.ls            #0x50a3cc
    // 0x50a2c4: ldr             x1, [fp, #0x18]
    // 0x50a2c8: LoadField: r2 = r1->field_7
    //     0x50a2c8: ldur            w2, [x1, #7]
    // 0x50a2cc: DecompressPointer r2
    //     0x50a2cc: add             x2, x2, HEAP, lsl #32
    // 0x50a2d0: ldr             x3, [fp, #0x10]
    // 0x50a2d4: stur            x2, [fp, #-8]
    // 0x50a2d8: r0 = LoadClassIdInstr(r3)
    //     0x50a2d8: ldur            x0, [x3, #-1]
    //     0x50a2dc: ubfx            x0, x0, #0xc, #0x14
    // 0x50a2e0: SaveReg r3
    //     0x50a2e0: str             x3, [SP, #-8]!
    // 0x50a2e4: r0 = GDT[cid_x0 + -0xfff]()
    //     0x50a2e4: sub             lr, x0, #0xfff
    //     0x50a2e8: ldr             lr, [x21, lr, lsl #3]
    //     0x50a2ec: blr             lr
    // 0x50a2f0: add             SP, SP, #8
    // 0x50a2f4: mov             x2, x0
    // 0x50a2f8: r0 = BoxInt64Instr(r2)
    //     0x50a2f8: sbfiz           x0, x2, #1, #0x1f
    //     0x50a2fc: cmp             x2, x0, asr #1
    //     0x50a300: b.eq            #0x50a30c
    //     0x50a304: bl              #0xd69bb8
    //     0x50a308: stur            x2, [x0, #7]
    // 0x50a30c: ldur            x16, [fp, #-8]
    // 0x50a310: stp             x0, x16, [SP, #-0x10]!
    // 0x50a314: r0 = _getValueOrData()
    //     0x50a314: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x50a318: add             SP, SP, #0x10
    // 0x50a31c: mov             x1, x0
    // 0x50a320: ldur            x0, [fp, #-8]
    // 0x50a324: LoadField: r2 = r0->field_f
    //     0x50a324: ldur            w2, [x0, #0xf]
    // 0x50a328: DecompressPointer r2
    //     0x50a328: add             x2, x2, HEAP, lsl #32
    // 0x50a32c: cmp             w2, w1
    // 0x50a330: b.ne            #0x50a338
    // 0x50a334: r1 = Null
    //     0x50a334: mov             x1, NULL
    // 0x50a338: ldr             x0, [fp, #0x18]
    // 0x50a33c: stur            x1, [fp, #-0x10]
    // 0x50a340: LoadField: r2 = r0->field_b
    //     0x50a340: ldur            w2, [x0, #0xb]
    // 0x50a344: DecompressPointer r2
    //     0x50a344: add             x2, x2, HEAP, lsl #32
    // 0x50a348: stur            x2, [fp, #-8]
    // 0x50a34c: r16 = <(dynamic this, PointerEvent) => void?, Matrix4?>
    //     0x50a34c: ldr             x16, [PP, #0x3938]  ; [pp+0x3938] TypeArguments: <(dynamic this, PointerEvent) => void?, Matrix4?>
    // 0x50a350: stp             x2, x16, [SP, #-0x10]!
    // 0x50a354: r0 = LinkedHashMap.of()
    //     0x50a354: bl              #0x50b77c  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x50a358: add             SP, SP, #0x10
    // 0x50a35c: mov             x1, x0
    // 0x50a360: ldur            x0, [fp, #-0x10]
    // 0x50a364: stur            x1, [fp, #-0x18]
    // 0x50a368: cmp             w0, NULL
    // 0x50a36c: b.eq            #0x50a39c
    // 0x50a370: r16 = <(dynamic this, PointerEvent) => void?, Matrix4?>
    //     0x50a370: ldr             x16, [PP, #0x3938]  ; [pp+0x3938] TypeArguments: <(dynamic this, PointerEvent) => void?, Matrix4?>
    // 0x50a374: stp             x0, x16, [SP, #-0x10]!
    // 0x50a378: r0 = LinkedHashMap.of()
    //     0x50a378: bl              #0x50b77c  ; [dart:collection] LinkedHashMap::LinkedHashMap.of
    // 0x50a37c: add             SP, SP, #0x10
    // 0x50a380: ldr             x16, [fp, #0x18]
    // 0x50a384: ldr             lr, [fp, #0x10]
    // 0x50a388: stp             lr, x16, [SP, #-0x10]!
    // 0x50a38c: ldur            x16, [fp, #-0x10]
    // 0x50a390: stp             x0, x16, [SP, #-0x10]!
    // 0x50a394: r0 = _dispatchEventToRoutes()
    //     0x50a394: bl              #0x50a3d4  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::_dispatchEventToRoutes
    // 0x50a398: add             SP, SP, #0x20
    // 0x50a39c: ldr             x16, [fp, #0x18]
    // 0x50a3a0: ldr             lr, [fp, #0x10]
    // 0x50a3a4: stp             lr, x16, [SP, #-0x10]!
    // 0x50a3a8: ldur            x16, [fp, #-8]
    // 0x50a3ac: ldur            lr, [fp, #-0x18]
    // 0x50a3b0: stp             lr, x16, [SP, #-0x10]!
    // 0x50a3b4: r0 = _dispatchEventToRoutes()
    //     0x50a3b4: bl              #0x50a3d4  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::_dispatchEventToRoutes
    // 0x50a3b8: add             SP, SP, #0x20
    // 0x50a3bc: r0 = Null
    //     0x50a3bc: mov             x0, NULL
    // 0x50a3c0: LeaveFrame
    //     0x50a3c0: mov             SP, fp
    //     0x50a3c4: ldp             fp, lr, [SP], #0x10
    // 0x50a3c8: ret
    //     0x50a3c8: ret             
    // 0x50a3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50a3cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50a3d0: b               #0x50a2c4
  }
  _ _dispatchEventToRoutes(/* No info */) {
    // ** addr: 0x50a3d4, size: 0x6c
    // 0x50a3d4: EnterFrame
    //     0x50a3d4: stp             fp, lr, [SP, #-0x10]!
    //     0x50a3d8: mov             fp, SP
    // 0x50a3dc: CheckStackOverflow
    //     0x50a3dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50a3e0: cmp             SP, x16
    //     0x50a3e4: b.ls            #0x50a438
    // 0x50a3e8: r1 = 3
    //     0x50a3e8: mov             x1, #3
    // 0x50a3ec: r0 = AllocateContext()
    //     0x50a3ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x50a3f0: mov             x1, x0
    // 0x50a3f4: ldr             x0, [fp, #0x28]
    // 0x50a3f8: StoreField: r1->field_f = r0
    //     0x50a3f8: stur            w0, [x1, #0xf]
    // 0x50a3fc: ldr             x0, [fp, #0x20]
    // 0x50a400: StoreField: r1->field_13 = r0
    //     0x50a400: stur            w0, [x1, #0x13]
    // 0x50a404: ldr             x0, [fp, #0x18]
    // 0x50a408: StoreField: r1->field_17 = r0
    //     0x50a408: stur            w0, [x1, #0x17]
    // 0x50a40c: mov             x2, x1
    // 0x50a410: r1 = Function '<anonymous closure>':.
    //     0x50a410: ldr             x1, [PP, #0x3940]  ; [pp+0x3940] AnonymousClosure: (0x50a440), in [package:flutter/src/gestures/pointer_router.dart] PointerRouter::_dispatchEventToRoutes (0x50a3d4)
    // 0x50a414: r0 = AllocateClosure()
    //     0x50a414: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x50a418: ldr             x16, [fp, #0x10]
    // 0x50a41c: stp             x0, x16, [SP, #-0x10]!
    // 0x50a420: r0 = forEach()
    //     0x50a420: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0x50a424: add             SP, SP, #0x10
    // 0x50a428: r0 = Null
    //     0x50a428: mov             x0, NULL
    // 0x50a42c: LeaveFrame
    //     0x50a42c: mov             SP, fp
    //     0x50a430: ldp             fp, lr, [SP], #0x10
    // 0x50a434: ret
    //     0x50a434: ret             
    // 0x50a438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50a438: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50a43c: b               #0x50a3e8
  }
  [closure] void <anonymous closure>(dynamic, (dynamic, PointerEvent) => void, Matrix4?) {
    // ** addr: 0x50a440, size: 0x9c
    // 0x50a440: EnterFrame
    //     0x50a440: stp             fp, lr, [SP, #-0x10]!
    //     0x50a444: mov             fp, SP
    // 0x50a448: AllocStack(0x8)
    //     0x50a448: sub             SP, SP, #8
    // 0x50a44c: SetupParameters()
    //     0x50a44c: ldr             x0, [fp, #0x20]
    //     0x50a450: ldur            w1, [x0, #0x17]
    //     0x50a454: add             x1, x1, HEAP, lsl #32
    //     0x50a458: stur            x1, [fp, #-8]
    // 0x50a45c: CheckStackOverflow
    //     0x50a45c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50a460: cmp             SP, x16
    //     0x50a464: b.ls            #0x50a4d4
    // 0x50a468: LoadField: r0 = r1->field_17
    //     0x50a468: ldur            w0, [x1, #0x17]
    // 0x50a46c: DecompressPointer r0
    //     0x50a46c: add             x0, x0, HEAP, lsl #32
    // 0x50a470: r2 = LoadClassIdInstr(r0)
    //     0x50a470: ldur            x2, [x0, #-1]
    //     0x50a474: ubfx            x2, x2, #0xc, #0x14
    // 0x50a478: ldr             x16, [fp, #0x18]
    // 0x50a47c: stp             x16, x0, [SP, #-0x10]!
    // 0x50a480: mov             x0, x2
    // 0x50a484: r0 = GDT[cid_x0 + 0x579]()
    //     0x50a484: add             lr, x0, #0x579
    //     0x50a488: ldr             lr, [x21, lr, lsl #3]
    //     0x50a48c: blr             lr
    // 0x50a490: add             SP, SP, #0x10
    // 0x50a494: tbnz            w0, #4, #0x50a4c4
    // 0x50a498: ldur            x0, [fp, #-8]
    // 0x50a49c: LoadField: r1 = r0->field_f
    //     0x50a49c: ldur            w1, [x0, #0xf]
    // 0x50a4a0: DecompressPointer r1
    //     0x50a4a0: add             x1, x1, HEAP, lsl #32
    // 0x50a4a4: LoadField: r2 = r0->field_13
    //     0x50a4a4: ldur            w2, [x0, #0x13]
    // 0x50a4a8: DecompressPointer r2
    //     0x50a4a8: add             x2, x2, HEAP, lsl #32
    // 0x50a4ac: stp             x2, x1, [SP, #-0x10]!
    // 0x50a4b0: ldr             x16, [fp, #0x18]
    // 0x50a4b4: ldr             lr, [fp, #0x10]
    // 0x50a4b8: stp             lr, x16, [SP, #-0x10]!
    // 0x50a4bc: r0 = _dispatch()
    //     0x50a4bc: bl              #0x50a4dc  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::_dispatch
    // 0x50a4c0: add             SP, SP, #0x20
    // 0x50a4c4: r0 = Null
    //     0x50a4c4: mov             x0, NULL
    // 0x50a4c8: LeaveFrame
    //     0x50a4c8: mov             SP, fp
    //     0x50a4cc: ldp             fp, lr, [SP], #0x10
    // 0x50a4d0: ret
    //     0x50a4d0: ret             
    // 0x50a4d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50a4d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50a4d8: b               #0x50a468
  }
  _ _dispatch(/* No info */) {
    // ** addr: 0x50a4dc, size: 0xf0
    // 0x50a4dc: EnterFrame
    //     0x50a4dc: stp             fp, lr, [SP, #-0x10]!
    //     0x50a4e0: mov             fp, SP
    // 0x50a4e4: AllocStack(0x68)
    //     0x50a4e4: sub             SP, SP, #0x68
    // 0x50a4e8: CheckStackOverflow
    //     0x50a4e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50a4ec: cmp             SP, x16
    //     0x50a4f0: b.ls            #0x50a5c4
    // 0x50a4f4: ldr             x0, [fp, #0x20]
    // 0x50a4f8: r1 = LoadClassIdInstr(r0)
    //     0x50a4f8: ldur            x1, [x0, #-1]
    //     0x50a4fc: ubfx            x1, x1, #0xc, #0x14
    // 0x50a500: ldr             x16, [fp, #0x10]
    // 0x50a504: stp             x16, x0, [SP, #-0x10]!
    // 0x50a508: mov             x0, x1
    // 0x50a50c: r0 = GDT[cid_x0 + 0xdefd]()
    //     0x50a50c: mov             x17, #0xdefd
    //     0x50a510: add             lr, x0, x17
    //     0x50a514: ldr             lr, [x21, lr, lsl #3]
    //     0x50a518: blr             lr
    // 0x50a51c: add             SP, SP, #0x10
    // 0x50a520: ldr             x16, [fp, #0x18]
    // 0x50a524: stp             x0, x16, [SP, #-0x10]!
    // 0x50a528: ldr             x0, [fp, #0x18]
    // 0x50a52c: ClosureCall
    //     0x50a52c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x50a530: ldur            x2, [x0, #0x1f]
    //     0x50a534: blr             x2
    // 0x50a538: add             SP, SP, #0x10
    // 0x50a53c: b               #0x50a5b4
    // 0x50a540: sub             SP, fp, #0x68
    // 0x50a544: mov             x2, x0
    // 0x50a548: stur            x0, [fp, #-0x58]
    // 0x50a54c: mov             x0, x1
    // 0x50a550: stur            x1, [fp, #-0x60]
    // 0x50a554: r1 = <List<Object>>
    //     0x50a554: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x50a558: r0 = ErrorDescription()
    //     0x50a558: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x50a55c: stur            x0, [fp, #-0x68]
    // 0x50a560: r16 = "while routing a pointer event"
    //     0x50a560: ldr             x16, [PP, #0x3950]  ; [pp+0x3950] "while routing a pointer event"
    // 0x50a564: stp             x16, x0, [SP, #-0x10]!
    // 0x50a568: r16 = Instance_DiagnosticLevel
    //     0x50a568: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x50a56c: SaveReg r16
    //     0x50a56c: str             x16, [SP, #-8]!
    // 0x50a570: r0 = _ErrorDiagnostic()
    //     0x50a570: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x50a574: add             SP, SP, #0x18
    // 0x50a578: r0 = FlutterErrorDetails()
    //     0x50a578: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x50a57c: mov             x1, x0
    // 0x50a580: ldur            x0, [fp, #-0x58]
    // 0x50a584: StoreField: r1->field_7 = r0
    //     0x50a584: stur            w0, [x1, #7]
    // 0x50a588: ldur            x0, [fp, #-0x60]
    // 0x50a58c: StoreField: r1->field_b = r0
    //     0x50a58c: stur            w0, [x1, #0xb]
    // 0x50a590: r0 = "gesture library"
    //     0x50a590: ldr             x0, [PP, #0x38f8]  ; [pp+0x38f8] "gesture library"
    // 0x50a594: StoreField: r1->field_f = r0
    //     0x50a594: stur            w0, [x1, #0xf]
    // 0x50a598: ldur            x0, [fp, #-0x68]
    // 0x50a59c: StoreField: r1->field_13 = r0
    //     0x50a59c: stur            w0, [x1, #0x13]
    // 0x50a5a0: r0 = false
    //     0x50a5a0: add             x0, NULL, #0x30  ; false
    // 0x50a5a4: StoreField: r1->field_1f = r0
    //     0x50a5a4: stur            w0, [x1, #0x1f]
    // 0x50a5a8: SaveReg r1
    //     0x50a5a8: str             x1, [SP, #-8]!
    // 0x50a5ac: r0 = reportError()
    //     0x50a5ac: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x50a5b0: add             SP, SP, #8
    // 0x50a5b4: r0 = Null
    //     0x50a5b4: mov             x0, NULL
    // 0x50a5b8: LeaveFrame
    //     0x50a5b8: mov             SP, fp
    //     0x50a5bc: ldp             fp, lr, [SP], #0x10
    // 0x50a5c0: ret
    //     0x50a5c0: ret             
    // 0x50a5c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50a5c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50a5c8: b               #0x50a4f4
  }
  _ addGlobalRoute(/* No info */) {
    // ** addr: 0x5b9b94, size: 0xd0
    // 0x5b9b94: EnterFrame
    //     0x5b9b94: stp             fp, lr, [SP, #-0x10]!
    //     0x5b9b98: mov             fp, SP
    // 0x5b9b9c: AllocStack(0x10)
    //     0x5b9b9c: sub             SP, SP, #0x10
    // 0x5b9ba0: CheckStackOverflow
    //     0x5b9ba0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b9ba4: cmp             SP, x16
    //     0x5b9ba8: b.ls            #0x5b9c5c
    // 0x5b9bac: ldr             x0, [fp, #0x18]
    // 0x5b9bb0: LoadField: r3 = r0->field_b
    //     0x5b9bb0: ldur            w3, [x0, #0xb]
    // 0x5b9bb4: DecompressPointer r3
    //     0x5b9bb4: add             x3, x3, HEAP, lsl #32
    // 0x5b9bb8: stur            x3, [fp, #-0x10]
    // 0x5b9bbc: LoadField: r4 = r3->field_7
    //     0x5b9bbc: ldur            w4, [x3, #7]
    // 0x5b9bc0: DecompressPointer r4
    //     0x5b9bc0: add             x4, x4, HEAP, lsl #32
    // 0x5b9bc4: ldr             x0, [fp, #0x10]
    // 0x5b9bc8: mov             x2, x4
    // 0x5b9bcc: stur            x4, [fp, #-8]
    // 0x5b9bd0: r1 = Null
    //     0x5b9bd0: mov             x1, NULL
    // 0x5b9bd4: cmp             w2, NULL
    // 0x5b9bd8: b.eq            #0x5b9bf4
    // 0x5b9bdc: LoadField: r4 = r2->field_17
    //     0x5b9bdc: ldur            w4, [x2, #0x17]
    // 0x5b9be0: DecompressPointer r4
    //     0x5b9be0: add             x4, x4, HEAP, lsl #32
    // 0x5b9be4: r8 = X0
    //     0x5b9be4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x5b9be8: LoadField: r9 = r4->field_7
    //     0x5b9be8: ldur            x9, [x4, #7]
    // 0x5b9bec: r3 = Null
    //     0x5b9bec: ldr             x3, [PP, #0x4460]  ; [pp+0x4460] Null
    // 0x5b9bf0: blr             x9
    // 0x5b9bf4: ldur            x2, [fp, #-8]
    // 0x5b9bf8: r0 = Null
    //     0x5b9bf8: mov             x0, NULL
    // 0x5b9bfc: r1 = Null
    //     0x5b9bfc: mov             x1, NULL
    // 0x5b9c00: cmp             w2, NULL
    // 0x5b9c04: b.eq            #0x5b9c20
    // 0x5b9c08: LoadField: r4 = r2->field_1b
    //     0x5b9c08: ldur            w4, [x2, #0x1b]
    // 0x5b9c0c: DecompressPointer r4
    //     0x5b9c0c: add             x4, x4, HEAP, lsl #32
    // 0x5b9c10: r8 = X1
    //     0x5b9c10: ldr             x8, [PP, #0x9a0]  ; [pp+0x9a0] TypeParameter: X1
    // 0x5b9c14: LoadField: r9 = r4->field_7
    //     0x5b9c14: ldur            x9, [x4, #7]
    // 0x5b9c18: r3 = Null
    //     0x5b9c18: ldr             x3, [PP, #0x4470]  ; [pp+0x4470] Null
    // 0x5b9c1c: blr             x9
    // 0x5b9c20: ldur            x16, [fp, #-0x10]
    // 0x5b9c24: ldr             lr, [fp, #0x10]
    // 0x5b9c28: stp             lr, x16, [SP, #-0x10]!
    // 0x5b9c2c: r0 = hash()
    //     0x5b9c2c: bl              #0xc0483c  ; [package:collection/src/equality.dart] DefaultEquality::hash
    // 0x5b9c30: add             SP, SP, #0x10
    // 0x5b9c34: ldur            x16, [fp, #-0x10]
    // 0x5b9c38: ldr             lr, [fp, #0x10]
    // 0x5b9c3c: stp             lr, x16, [SP, #-0x10]!
    // 0x5b9c40: stp             x0, NULL, [SP, #-0x10]!
    // 0x5b9c44: r0 = _set()
    //     0x5b9c44: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x5b9c48: add             SP, SP, #0x20
    // 0x5b9c4c: r0 = Null
    //     0x5b9c4c: mov             x0, NULL
    // 0x5b9c50: LeaveFrame
    //     0x5b9c50: mov             SP, fp
    //     0x5b9c54: ldp             fp, lr, [SP], #0x10
    // 0x5b9c58: ret
    //     0x5b9c58: ret             
    // 0x5b9c5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b9c5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b9c60: b               #0x5b9bac
  }
  _ PointerRouter(/* No info */) {
    // ** addr: 0x5e2dd4, size: 0x9c
    // 0x5e2dd4: EnterFrame
    //     0x5e2dd4: stp             fp, lr, [SP, #-0x10]!
    //     0x5e2dd8: mov             fp, SP
    // 0x5e2ddc: CheckStackOverflow
    //     0x5e2ddc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e2de0: cmp             SP, x16
    //     0x5e2de4: b.ls            #0x5e2e68
    // 0x5e2de8: r16 = <int, Map<(dynamic this, PointerEvent) => void?, Matrix4?>>
    //     0x5e2de8: ldr             x16, [PP, #0x6270]  ; [pp+0x6270] TypeArguments: <int, Map<(dynamic this, PointerEvent) => void?, Matrix4?>>
    // 0x5e2dec: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5e2df0: stp             lr, x16, [SP, #-0x10]!
    // 0x5e2df4: r0 = Map._fromLiteral()
    //     0x5e2df4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5e2df8: add             SP, SP, #0x10
    // 0x5e2dfc: ldr             x1, [fp, #0x10]
    // 0x5e2e00: StoreField: r1->field_7 = r0
    //     0x5e2e00: stur            w0, [x1, #7]
    //     0x5e2e04: tbz             w0, #0, #0x5e2e20
    //     0x5e2e08: ldurb           w16, [x1, #-1]
    //     0x5e2e0c: ldurb           w17, [x0, #-1]
    //     0x5e2e10: and             x16, x17, x16, lsr #2
    //     0x5e2e14: tst             x16, HEAP, lsr #32
    //     0x5e2e18: b.eq            #0x5e2e20
    //     0x5e2e1c: bl              #0xd6826c
    // 0x5e2e20: r16 = <(dynamic this, PointerEvent) => void?, Matrix4?>
    //     0x5e2e20: ldr             x16, [PP, #0x3938]  ; [pp+0x3938] TypeArguments: <(dynamic this, PointerEvent) => void?, Matrix4?>
    // 0x5e2e24: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5e2e28: stp             lr, x16, [SP, #-0x10]!
    // 0x5e2e2c: r0 = Map._fromLiteral()
    //     0x5e2e2c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5e2e30: add             SP, SP, #0x10
    // 0x5e2e34: ldr             x1, [fp, #0x10]
    // 0x5e2e38: StoreField: r1->field_b = r0
    //     0x5e2e38: stur            w0, [x1, #0xb]
    //     0x5e2e3c: tbz             w0, #0, #0x5e2e58
    //     0x5e2e40: ldurb           w16, [x1, #-1]
    //     0x5e2e44: ldurb           w17, [x0, #-1]
    //     0x5e2e48: and             x16, x17, x16, lsr #2
    //     0x5e2e4c: tst             x16, HEAP, lsr #32
    //     0x5e2e50: b.eq            #0x5e2e58
    //     0x5e2e54: bl              #0xd6826c
    // 0x5e2e58: r0 = Null
    //     0x5e2e58: mov             x0, NULL
    // 0x5e2e5c: LeaveFrame
    //     0x5e2e5c: mov             SP, fp
    //     0x5e2e60: ldp             fp, lr, [SP], #0x10
    // 0x5e2e64: ret
    //     0x5e2e64: ret             
    // 0x5e2e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e2e68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e2e6c: b               #0x5e2de8
  }
  _ addRoute(/* No info */) {
    // ** addr: 0x711788, size: 0xf0
    // 0x711788: EnterFrame
    //     0x711788: stp             fp, lr, [SP, #-0x10]!
    //     0x71178c: mov             fp, SP
    // 0x711790: AllocStack(0x20)
    //     0x711790: sub             SP, SP, #0x20
    // 0x711794: SetupParameters(PointerRouter this /* r1 */, dynamic _ /* r2 */, dynamic _ /* r3, fp-0x20 */, [dynamic _ = Null /* r4, fp-0x18 */])
    //     0x711794: mov             x0, x4
    //     0x711798: ldur            w1, [x0, #0x13]
    //     0x71179c: add             x1, x1, HEAP, lsl #32
    //     0x7117a0: sub             x0, x1, #6
    //     0x7117a4: add             x1, fp, w0, sxtw #2
    //     0x7117a8: ldr             x1, [x1, #0x20]
    //     0x7117ac: add             x2, fp, w0, sxtw #2
    //     0x7117b0: ldr             x2, [x2, #0x18]
    //     0x7117b4: add             x3, fp, w0, sxtw #2
    //     0x7117b8: ldr             x3, [x3, #0x10]
    //     0x7117bc: stur            x3, [fp, #-0x20]
    //     0x7117c0: cmp             w0, #2
    //     0x7117c4: b.lt            #0x7117d4
    //     0x7117c8: add             x4, fp, w0, sxtw #2
    //     0x7117cc: ldr             x4, [x4, #8]
    //     0x7117d0: b               #0x7117d8
    //     0x7117d4: mov             x4, NULL
    //     0x7117d8: stur            x4, [fp, #-0x18]
    // 0x7117dc: CheckStackOverflow
    //     0x7117dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7117e0: cmp             SP, x16
    //     0x7117e4: b.ls            #0x711870
    // 0x7117e8: LoadField: r5 = r1->field_7
    //     0x7117e8: ldur            w5, [x1, #7]
    // 0x7117ec: DecompressPointer r5
    //     0x7117ec: add             x5, x5, HEAP, lsl #32
    // 0x7117f0: stur            x5, [fp, #-0x10]
    // 0x7117f4: r0 = BoxInt64Instr(r2)
    //     0x7117f4: sbfiz           x0, x2, #1, #0x1f
    //     0x7117f8: cmp             x2, x0, asr #1
    //     0x7117fc: b.eq            #0x711808
    //     0x711800: bl              #0xd69bb8
    //     0x711804: stur            x2, [x0, #7]
    // 0x711808: r1 = Function '<anonymous closure>':.
    //     0x711808: add             x1, PP, #0x28, lsl #12  ; [pp+0x28ee0] AnonymousClosure: (0x711878), in [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addRoute (0x711788)
    //     0x71180c: ldr             x1, [x1, #0xee0]
    // 0x711810: r2 = Null
    //     0x711810: mov             x2, NULL
    // 0x711814: stur            x0, [fp, #-8]
    // 0x711818: r0 = AllocateClosure()
    //     0x711818: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x71181c: ldur            x16, [fp, #-0x10]
    // 0x711820: ldur            lr, [fp, #-8]
    // 0x711824: stp             lr, x16, [SP, #-0x10]!
    // 0x711828: SaveReg r0
    //     0x711828: str             x0, [SP, #-8]!
    // 0x71182c: r0 = putIfAbsent()
    //     0x71182c: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x711830: add             SP, SP, #0x18
    // 0x711834: r1 = LoadClassIdInstr(r0)
    //     0x711834: ldur            x1, [x0, #-1]
    //     0x711838: ubfx            x1, x1, #0xc, #0x14
    // 0x71183c: ldur            x16, [fp, #-0x20]
    // 0x711840: stp             x16, x0, [SP, #-0x10]!
    // 0x711844: ldur            x16, [fp, #-0x18]
    // 0x711848: SaveReg r16
    //     0x711848: str             x16, [SP, #-8]!
    // 0x71184c: mov             x0, x1
    // 0x711850: r0 = GDT[cid_x0 + 0x35a]()
    //     0x711850: add             lr, x0, #0x35a
    //     0x711854: ldr             lr, [x21, lr, lsl #3]
    //     0x711858: blr             lr
    // 0x71185c: add             SP, SP, #0x18
    // 0x711860: r0 = Null
    //     0x711860: mov             x0, NULL
    // 0x711864: LeaveFrame
    //     0x711864: mov             SP, fp
    //     0x711868: ldp             fp, lr, [SP], #0x10
    // 0x71186c: ret
    //     0x71186c: ret             
    // 0x711870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711870: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711874: b               #0x7117e8
  }
  [closure] Map<(dynamic, PointerEvent) => void, Matrix4?> <anonymous closure>(dynamic) {
    // ** addr: 0x711878, size: 0x3c
    // 0x711878: EnterFrame
    //     0x711878: stp             fp, lr, [SP, #-0x10]!
    //     0x71187c: mov             fp, SP
    // 0x711880: CheckStackOverflow
    //     0x711880: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711884: cmp             SP, x16
    //     0x711888: b.ls            #0x7118ac
    // 0x71188c: r16 = <(dynamic this, PointerEvent) => void?, Matrix4?>
    //     0x71188c: ldr             x16, [PP, #0x3938]  ; [pp+0x3938] TypeArguments: <(dynamic this, PointerEvent) => void?, Matrix4?>
    // 0x711890: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x711894: stp             lr, x16, [SP, #-0x10]!
    // 0x711898: r0 = Map._fromLiteral()
    //     0x711898: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x71189c: add             SP, SP, #0x10
    // 0x7118a0: LeaveFrame
    //     0x7118a0: mov             SP, fp
    //     0x7118a4: ldp             fp, lr, [SP], #0x10
    // 0x7118a8: ret
    //     0x7118a8: ret             
    // 0x7118ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7118ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7118b0: b               #0x71188c
  }
  _ removeRoute(/* No info */) {
    // ** addr: 0x7134d4, size: 0xf4
    // 0x7134d4: EnterFrame
    //     0x7134d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7134d8: mov             fp, SP
    // 0x7134dc: AllocStack(0x18)
    //     0x7134dc: sub             SP, SP, #0x18
    // 0x7134e0: CheckStackOverflow
    //     0x7134e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7134e4: cmp             SP, x16
    //     0x7134e8: b.ls            #0x7135bc
    // 0x7134ec: ldr             x0, [fp, #0x20]
    // 0x7134f0: LoadField: r2 = r0->field_7
    //     0x7134f0: ldur            w2, [x0, #7]
    // 0x7134f4: DecompressPointer r2
    //     0x7134f4: add             x2, x2, HEAP, lsl #32
    // 0x7134f8: ldr             x3, [fp, #0x18]
    // 0x7134fc: stur            x2, [fp, #-0x10]
    // 0x713500: r0 = BoxInt64Instr(r3)
    //     0x713500: sbfiz           x0, x3, #1, #0x1f
    //     0x713504: cmp             x3, x0, asr #1
    //     0x713508: b.eq            #0x713514
    //     0x71350c: bl              #0xd69bb8
    //     0x713510: stur            x3, [x0, #7]
    // 0x713514: stur            x0, [fp, #-8]
    // 0x713518: stp             x0, x2, [SP, #-0x10]!
    // 0x71351c: r0 = _getValueOrData()
    //     0x71351c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x713520: add             SP, SP, #0x10
    // 0x713524: ldur            x1, [fp, #-0x10]
    // 0x713528: LoadField: r2 = r1->field_f
    //     0x713528: ldur            w2, [x1, #0xf]
    // 0x71352c: DecompressPointer r2
    //     0x71352c: add             x2, x2, HEAP, lsl #32
    // 0x713530: cmp             w2, w0
    // 0x713534: b.ne            #0x713540
    // 0x713538: r2 = Null
    //     0x713538: mov             x2, NULL
    // 0x71353c: b               #0x713544
    // 0x713540: mov             x2, x0
    // 0x713544: stur            x2, [fp, #-0x18]
    // 0x713548: cmp             w2, NULL
    // 0x71354c: b.eq            #0x7135c4
    // 0x713550: r0 = LoadClassIdInstr(r2)
    //     0x713550: ldur            x0, [x2, #-1]
    //     0x713554: ubfx            x0, x0, #0xc, #0x14
    // 0x713558: ldr             x16, [fp, #0x10]
    // 0x71355c: stp             x16, x2, [SP, #-0x10]!
    // 0x713560: r0 = GDT[cid_x0 + 0x6e2]()
    //     0x713560: add             lr, x0, #0x6e2
    //     0x713564: ldr             lr, [x21, lr, lsl #3]
    //     0x713568: blr             lr
    // 0x71356c: add             SP, SP, #0x10
    // 0x713570: ldur            x0, [fp, #-0x18]
    // 0x713574: r1 = LoadClassIdInstr(r0)
    //     0x713574: ldur            x1, [x0, #-1]
    //     0x713578: ubfx            x1, x1, #0xc, #0x14
    // 0x71357c: SaveReg r0
    //     0x71357c: str             x0, [SP, #-8]!
    // 0x713580: mov             x0, x1
    // 0x713584: r0 = GDT[cid_x0 + 0x747]()
    //     0x713584: add             lr, x0, #0x747
    //     0x713588: ldr             lr, [x21, lr, lsl #3]
    //     0x71358c: blr             lr
    // 0x713590: add             SP, SP, #8
    // 0x713594: tbnz            w0, #4, #0x7135ac
    // 0x713598: ldur            x16, [fp, #-0x10]
    // 0x71359c: ldur            lr, [fp, #-8]
    // 0x7135a0: stp             lr, x16, [SP, #-0x10]!
    // 0x7135a4: r0 = remove()
    //     0x7135a4: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x7135a8: add             SP, SP, #0x10
    // 0x7135ac: r0 = Null
    //     0x7135ac: mov             x0, NULL
    // 0x7135b0: LeaveFrame
    //     0x7135b0: mov             SP, fp
    //     0x7135b4: ldp             fp, lr, [SP], #0x10
    // 0x7135b8: ret
    //     0x7135b8: ret             
    // 0x7135bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7135bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7135c0: b               #0x7134ec
    // 0x7135c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7135c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ removeGlobalRoute(/* No info */) {
    // ** addr: 0xa535e8, size: 0x48
    // 0xa535e8: EnterFrame
    //     0xa535e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa535ec: mov             fp, SP
    // 0xa535f0: CheckStackOverflow
    //     0xa535f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa535f4: cmp             SP, x16
    //     0xa535f8: b.ls            #0xa53628
    // 0xa535fc: ldr             x0, [fp, #0x18]
    // 0xa53600: LoadField: r1 = r0->field_b
    //     0xa53600: ldur            w1, [x0, #0xb]
    // 0xa53604: DecompressPointer r1
    //     0xa53604: add             x1, x1, HEAP, lsl #32
    // 0xa53608: ldr             x16, [fp, #0x10]
    // 0xa5360c: stp             x16, x1, [SP, #-0x10]!
    // 0xa53610: r0 = remove()
    //     0xa53610: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xa53614: add             SP, SP, #0x10
    // 0xa53618: r0 = Null
    //     0xa53618: mov             x0, NULL
    // 0xa5361c: LeaveFrame
    //     0xa5361c: mov             SP, fp
    //     0xa53620: ldp             fp, lr, [SP], #0x10
    // 0xa53624: ret
    //     0xa53624: ret             
    // 0xa53628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa53628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5362c: b               #0xa535fc
  }
}

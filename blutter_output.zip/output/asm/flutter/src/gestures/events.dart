// lib: , url: package:flutter/src/gestures/events.dart

// class id: 1049157, size: 0x8
class :: {

  static _ computePanSlop(/* No info */) {
    // ** addr: 0x78a9bc, size: 0x10c
    // 0x78a9bc: EnterFrame
    //     0x78a9bc: stp             fp, lr, [SP, #-0x10]!
    //     0x78a9c0: mov             fp, SP
    // 0x78a9c4: ldr             x1, [fp, #0x18]
    // 0x78a9c8: LoadField: r2 = r1->field_7
    //     0x78a9c8: ldur            x2, [x1, #7]
    // 0x78a9cc: cmp             x2, #2
    // 0x78a9d0: b.gt            #0x78a9f8
    // 0x78a9d4: cmp             x2, #1
    // 0x78a9d8: b.gt            #0x78a9f8
    // 0x78a9dc: cmp             x2, #0
    // 0x78a9e0: b.le            #0x78a9f8
    // 0x78a9e4: r0 = 2.000000
    //     0x78a9e4: add             x0, PP, #0x25, lsl #12  ; [pp+0x259a8] 2
    //     0x78a9e8: ldr             x0, [x0, #0x9a8]
    // 0x78a9ec: LeaveFrame
    //     0x78a9ec: mov             SP, fp
    //     0x78a9f0: ldp             fp, lr, [SP], #0x10
    // 0x78a9f4: ret
    //     0x78a9f4: ret             
    // 0x78a9f8: ldr             x1, [fp, #0x10]
    // 0x78a9fc: cmp             w1, NULL
    // 0x78aa00: b.ne            #0x78aa0c
    // 0x78aa04: r1 = Null
    //     0x78aa04: mov             x1, NULL
    // 0x78aa08: b               #0x78aa58
    // 0x78aa0c: LoadField: r2 = r1->field_7
    //     0x78aa0c: ldur            w2, [x1, #7]
    // 0x78aa10: DecompressPointer r2
    //     0x78aa10: add             x2, x2, HEAP, lsl #32
    // 0x78aa14: cmp             w2, NULL
    // 0x78aa18: b.eq            #0x78aa54
    // 0x78aa1c: d0 = 2.000000
    //     0x78aa1c: fmov            d0, #2.00000000
    // 0x78aa20: LoadField: d1 = r2->field_7
    //     0x78aa20: ldur            d1, [x2, #7]
    // 0x78aa24: fmul            d2, d1, d0
    // 0x78aa28: r1 = inline_Allocate_Double()
    //     0x78aa28: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x78aa2c: add             x1, x1, #0x10
    //     0x78aa30: cmp             x2, x1
    //     0x78aa34: b.ls            #0x78aaa4
    //     0x78aa38: str             x1, [THR, #0x60]  ; THR::top
    //     0x78aa3c: sub             x1, x1, #0xf
    //     0x78aa40: mov             x2, #0xd108
    //     0x78aa44: movk            x2, #3, lsl #16
    //     0x78aa48: stur            x2, [x1, #-1]
    // 0x78aa4c: StoreField: r1->field_7 = d2
    //     0x78aa4c: stur            d2, [x1, #7]
    // 0x78aa50: b               #0x78aa58
    // 0x78aa54: r1 = Null
    //     0x78aa54: mov             x1, NULL
    // 0x78aa58: cmp             w1, NULL
    // 0x78aa5c: b.ne            #0x78aa6c
    // 0x78aa60: d0 = 36.000000
    //     0x78aa60: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0x78aa64: ldr             d0, [x17, #0xfa8]
    // 0x78aa68: b               #0x78aa70
    // 0x78aa6c: LoadField: d0 = r1->field_7
    //     0x78aa6c: ldur            d0, [x1, #7]
    // 0x78aa70: r0 = inline_Allocate_Double()
    //     0x78aa70: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x78aa74: add             x0, x0, #0x10
    //     0x78aa78: cmp             x1, x0
    //     0x78aa7c: b.ls            #0x78aab8
    //     0x78aa80: str             x0, [THR, #0x60]  ; THR::top
    //     0x78aa84: sub             x0, x0, #0xf
    //     0x78aa88: mov             x1, #0xd108
    //     0x78aa8c: movk            x1, #3, lsl #16
    //     0x78aa90: stur            x1, [x0, #-1]
    // 0x78aa94: StoreField: r0->field_7 = d0
    //     0x78aa94: stur            d0, [x0, #7]
    // 0x78aa98: LeaveFrame
    //     0x78aa98: mov             SP, fp
    //     0x78aa9c: ldp             fp, lr, [SP], #0x10
    // 0x78aaa0: ret
    //     0x78aaa0: ret             
    // 0x78aaa4: SaveReg d2
    //     0x78aaa4: str             q2, [SP, #-0x10]!
    // 0x78aaa8: r0 = AllocateDouble()
    //     0x78aaa8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78aaac: mov             x1, x0
    // 0x78aab0: RestoreReg d2
    //     0x78aab0: ldr             q2, [SP], #0x10
    // 0x78aab4: b               #0x78aa4c
    // 0x78aab8: SaveReg d0
    //     0x78aab8: str             q0, [SP, #-0x10]!
    // 0x78aabc: r0 = AllocateDouble()
    //     0x78aabc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78aac0: RestoreReg d0
    //     0x78aac0: ldr             q0, [SP], #0x10
    // 0x78aac4: b               #0x78aa94
  }
}

// class id: 2291, size: 0x8, field offset: 0x8
abstract class _AbstractPointerEvent extends Object
    implements PointerEvent {
}

// class id: 2292, size: 0x8, field offset: 0x8
//   transformed mixin,
abstract class __TransformedPointerEvent&_AbstractPointerEvent&Diagnosticable extends _AbstractPointerEvent
     with Diagnosticable {
}

// class id: 2293, size: 0x8, field offset: 0x8
//   transformed mixin,
abstract class __TransformedPointerEvent&_AbstractPointerEvent&Diagnosticable&_PointerEventDescription extends __TransformedPointerEvent&_AbstractPointerEvent&Diagnosticable
     with _PointerEventDescription {
}

// class id: 2294, size: 0x10, field offset: 0x8
abstract class _TransformedPointerEvent extends __TransformedPointerEvent&_AbstractPointerEvent&Diagnosticable&_PointerEventDescription {

  late final Offset localPosition; // offset: 0x8
  late final Offset localDelta; // offset: 0xc

  const Offset localDelta(_TransformedPointerEvent) {
    // ** addr: 0x5b6390, size: 0x38
    // 0x5b6390: EnterFrame
    //     0x5b6390: stp             fp, lr, [SP, #-0x10]!
    //     0x5b6394: mov             fp, SP
    // 0x5b6398: ldr             x1, [fp, #0x10]
    // 0x5b639c: LoadField: r0 = r1->field_b
    //     0x5b639c: ldur            w0, [x1, #0xb]
    // 0x5b63a0: DecompressPointer r0
    //     0x5b63a0: add             x0, x0, HEAP, lsl #32
    // 0x5b63a4: r16 = Sentinel
    //     0x5b63a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5b63a8: cmp             w0, w16
    // 0x5b63ac: b.ne            #0x5b63bc
    // 0x5b63b0: r2 = localDelta
    //     0x5b63b0: add             x2, PP, #0x37, lsl #12  ; [pp+0x37b18] Field <_TransformedPointerEvent@660050165.localDelta>: late final (offset: 0xc)
    //     0x5b63b4: ldr             x2, [x2, #0xb18]
    // 0x5b63b8: r0 = InitLateFinalInstanceField()
    //     0x5b63b8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x5b63bc: LeaveFrame
    //     0x5b63bc: mov             SP, fp
    //     0x5b63c0: ldp             fp, lr, [SP], #0x10
    // 0x5b63c4: ret
    //     0x5b63c4: ret             
  }
  Offset localDelta(_TransformedPointerEvent) {
    // ** addr: 0x5b63c8, size: 0xd8
    // 0x5b63c8: EnterFrame
    //     0x5b63c8: stp             fp, lr, [SP, #-0x10]!
    //     0x5b63cc: mov             fp, SP
    // 0x5b63d0: AllocStack(0x18)
    //     0x5b63d0: sub             SP, SP, #0x18
    // 0x5b63d4: CheckStackOverflow
    //     0x5b63d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b63d8: cmp             SP, x16
    //     0x5b63dc: b.ls            #0x5b6498
    // 0x5b63e0: ldr             x1, [fp, #0x10]
    // 0x5b63e4: LoadField: r2 = r1->field_13
    //     0x5b63e4: ldur            w2, [x1, #0x13]
    // 0x5b63e8: DecompressPointer r2
    //     0x5b63e8: add             x2, x2, HEAP, lsl #32
    // 0x5b63ec: stur            x2, [fp, #-8]
    // 0x5b63f0: r0 = LoadClassIdInstr(r1)
    //     0x5b63f0: ldur            x0, [x1, #-1]
    //     0x5b63f4: ubfx            x0, x0, #0xc, #0x14
    // 0x5b63f8: SaveReg r1
    //     0x5b63f8: str             x1, [SP, #-8]!
    // 0x5b63fc: r0 = GDT[cid_x0 + -0x1]()
    //     0x5b63fc: sub             lr, x0, #1
    //     0x5b6400: ldr             lr, [x21, lr, lsl #3]
    //     0x5b6404: blr             lr
    // 0x5b6408: add             SP, SP, #8
    // 0x5b640c: LoadField: r1 = r0->field_2b
    //     0x5b640c: ldur            w1, [x0, #0x2b]
    // 0x5b6410: DecompressPointer r1
    //     0x5b6410: add             x1, x1, HEAP, lsl #32
    // 0x5b6414: ldr             x2, [fp, #0x10]
    // 0x5b6418: stur            x1, [fp, #-0x10]
    // 0x5b641c: r0 = LoadClassIdInstr(r2)
    //     0x5b641c: ldur            x0, [x2, #-1]
    //     0x5b6420: ubfx            x0, x0, #0xc, #0x14
    // 0x5b6424: SaveReg r2
    //     0x5b6424: str             x2, [SP, #-8]!
    // 0x5b6428: r0 = GDT[cid_x0 + -0x1]()
    //     0x5b6428: sub             lr, x0, #1
    //     0x5b642c: ldr             lr, [x21, lr, lsl #3]
    //     0x5b6430: blr             lr
    // 0x5b6434: add             SP, SP, #8
    // 0x5b6438: LoadField: r2 = r0->field_27
    //     0x5b6438: ldur            w2, [x0, #0x27]
    // 0x5b643c: DecompressPointer r2
    //     0x5b643c: add             x2, x2, HEAP, lsl #32
    // 0x5b6440: ldr             x1, [fp, #0x10]
    // 0x5b6444: stur            x2, [fp, #-0x18]
    // 0x5b6448: LoadField: r0 = r1->field_7
    //     0x5b6448: ldur            w0, [x1, #7]
    // 0x5b644c: DecompressPointer r0
    //     0x5b644c: add             x0, x0, HEAP, lsl #32
    // 0x5b6450: r16 = Sentinel
    //     0x5b6450: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5b6454: cmp             w0, w16
    // 0x5b6458: b.ne            #0x5b6468
    // 0x5b645c: r2 = localPosition
    //     0x5b645c: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e920] Field <_TransformedPointerEvent@660050165.localPosition>: late final (offset: 0x8)
    //     0x5b6460: ldr             x2, [x2, #0x920]
    // 0x5b6464: r0 = InitLateFinalInstanceField()
    //     0x5b6464: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x5b6468: ldur            x16, [fp, #-8]
    // 0x5b646c: ldur            lr, [fp, #-0x10]
    // 0x5b6470: stp             lr, x16, [SP, #-0x10]!
    // 0x5b6474: ldur            x16, [fp, #-0x18]
    // 0x5b6478: stp             x0, x16, [SP, #-0x10]!
    // 0x5b647c: r4 = const [0, 0x4, 0x4, 0x3, transformedEndPosition, 0x3, null]
    //     0x5b647c: add             x4, PP, #0x37, lsl #12  ; [pp+0x37b20] List(7) [0, 0x4, 0x4, 0x3, "transformedEndPosition", 0x3, Null]
    //     0x5b6480: ldr             x4, [x4, #0xb20]
    // 0x5b6484: r0 = transformDeltaViaPositions()
    //     0x5b6484: bl              #0x5b64a0  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0x5b6488: add             SP, SP, #0x20
    // 0x5b648c: LeaveFrame
    //     0x5b648c: mov             SP, fp
    //     0x5b6490: ldp             fp, lr, [SP], #0x10
    // 0x5b6494: ret
    //     0x5b6494: ret             
    // 0x5b6498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b6498: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b649c: b               #0x5b63e0
  }
  Offset localPosition(_TransformedPointerEvent) {
    // ** addr: 0x5b7188, size: 0x94
    // 0x5b7188: EnterFrame
    //     0x5b7188: stp             fp, lr, [SP, #-0x10]!
    //     0x5b718c: mov             fp, SP
    // 0x5b7190: AllocStack(0x8)
    //     0x5b7190: sub             SP, SP, #8
    // 0x5b7194: CheckStackOverflow
    //     0x5b7194: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b7198: cmp             SP, x16
    //     0x5b719c: b.ls            #0x5b7214
    // 0x5b71a0: ldr             x1, [fp, #0x10]
    // 0x5b71a4: r0 = LoadClassIdInstr(r1)
    //     0x5b71a4: ldur            x0, [x1, #-1]
    //     0x5b71a8: ubfx            x0, x0, #0xc, #0x14
    // 0x5b71ac: SaveReg r1
    //     0x5b71ac: str             x1, [SP, #-8]!
    // 0x5b71b0: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x5b71b0: mov             x17, #0x3f6e
    //     0x5b71b4: add             lr, x0, x17
    //     0x5b71b8: ldr             lr, [x21, lr, lsl #3]
    //     0x5b71bc: blr             lr
    // 0x5b71c0: add             SP, SP, #8
    // 0x5b71c4: mov             x1, x0
    // 0x5b71c8: ldr             x0, [fp, #0x10]
    // 0x5b71cc: stur            x1, [fp, #-8]
    // 0x5b71d0: r2 = LoadClassIdInstr(r0)
    //     0x5b71d0: ldur            x2, [x0, #-1]
    //     0x5b71d4: ubfx            x2, x2, #0xc, #0x14
    // 0x5b71d8: SaveReg r0
    //     0x5b71d8: str             x0, [SP, #-8]!
    // 0x5b71dc: mov             x0, x2
    // 0x5b71e0: r0 = GDT[cid_x0 + -0x1]()
    //     0x5b71e0: sub             lr, x0, #1
    //     0x5b71e4: ldr             lr, [x21, lr, lsl #3]
    //     0x5b71e8: blr             lr
    // 0x5b71ec: add             SP, SP, #8
    // 0x5b71f0: LoadField: r1 = r0->field_27
    //     0x5b71f0: ldur            w1, [x0, #0x27]
    // 0x5b71f4: DecompressPointer r1
    //     0x5b71f4: add             x1, x1, HEAP, lsl #32
    // 0x5b71f8: ldur            x16, [fp, #-8]
    // 0x5b71fc: stp             x1, x16, [SP, #-0x10]!
    // 0x5b7200: r0 = transformPosition()
    //     0x5b7200: bl              #0x5b659c  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0x5b7204: add             SP, SP, #0x10
    // 0x5b7208: LeaveFrame
    //     0x5b7208: mov             SP, fp
    //     0x5b720c: ldp             fp, lr, [SP], #0x10
    // 0x5b7210: ret
    //     0x5b7210: ret             
    // 0x5b7214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b7214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b7218: b               #0x5b71a0
  }
  get _ platformData(/* No info */) {
    // ** addr: 0x5b721c, size: 0x54
    // 0x5b721c: EnterFrame
    //     0x5b721c: stp             fp, lr, [SP, #-0x10]!
    //     0x5b7220: mov             fp, SP
    // 0x5b7224: CheckStackOverflow
    //     0x5b7224: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b7228: cmp             SP, x16
    //     0x5b722c: b.ls            #0x5b7268
    // 0x5b7230: ldr             x0, [fp, #0x10]
    // 0x5b7234: r1 = LoadClassIdInstr(r0)
    //     0x5b7234: ldur            x1, [x0, #-1]
    //     0x5b7238: ubfx            x1, x1, #0xc, #0x14
    // 0x5b723c: SaveReg r0
    //     0x5b723c: str             x0, [SP, #-8]!
    // 0x5b7240: mov             x0, x1
    // 0x5b7244: r0 = GDT[cid_x0 + -0x1]()
    //     0x5b7244: sub             lr, x0, #1
    //     0x5b7248: ldr             lr, [x21, lr, lsl #3]
    //     0x5b724c: blr             lr
    // 0x5b7250: add             SP, SP, #8
    // 0x5b7254: LoadField: r1 = r0->field_9f
    //     0x5b7254: ldur            x1, [x0, #0x9f]
    // 0x5b7258: mov             x0, x1
    // 0x5b725c: LeaveFrame
    //     0x5b725c: mov             SP, fp
    //     0x5b7260: ldp             fp, lr, [SP], #0x10
    // 0x5b7264: ret
    //     0x5b7264: ret             
    // 0x5b7268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b7268: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b726c: b               #0x5b7230
  }
  get _ distance(/* No info */) {
    // ** addr: 0x5e5928, size: 0x50
    // 0x5e5928: EnterFrame
    //     0x5e5928: stp             fp, lr, [SP, #-0x10]!
    //     0x5e592c: mov             fp, SP
    // 0x5e5930: CheckStackOverflow
    //     0x5e5930: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5934: cmp             SP, x16
    //     0x5e5938: b.ls            #0x5e5970
    // 0x5e593c: ldr             x0, [fp, #0x10]
    // 0x5e5940: r1 = LoadClassIdInstr(r0)
    //     0x5e5940: ldur            x1, [x0, #-1]
    //     0x5e5944: ubfx            x1, x1, #0xc, #0x14
    // 0x5e5948: SaveReg r0
    //     0x5e5948: str             x0, [SP, #-8]!
    // 0x5e594c: mov             x0, x1
    // 0x5e5950: r0 = GDT[cid_x0 + -0x1]()
    //     0x5e5950: sub             lr, x0, #1
    //     0x5e5954: ldr             lr, [x21, lr, lsl #3]
    //     0x5e5958: blr             lr
    // 0x5e595c: add             SP, SP, #8
    // 0x5e5960: LoadField: d0 = r0->field_57
    //     0x5e5960: ldur            d0, [x0, #0x57]
    // 0x5e5964: LeaveFrame
    //     0x5e5964: mov             SP, fp
    //     0x5e5968: ldp             fp, lr, [SP], #0x10
    // 0x5e596c: ret
    //     0x5e596c: ret             
    // 0x5e5970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e5970: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e5974: b               #0x5e593c
  }
  get _ pressure(/* No info */) {
    // ** addr: 0x5e5978, size: 0x50
    // 0x5e5978: EnterFrame
    //     0x5e5978: stp             fp, lr, [SP, #-0x10]!
    //     0x5e597c: mov             fp, SP
    // 0x5e5980: CheckStackOverflow
    //     0x5e5980: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e5984: cmp             SP, x16
    //     0x5e5988: b.ls            #0x5e59c0
    // 0x5e598c: ldr             x0, [fp, #0x10]
    // 0x5e5990: r1 = LoadClassIdInstr(r0)
    //     0x5e5990: ldur            x1, [x0, #-1]
    //     0x5e5994: ubfx            x1, x1, #0xc, #0x14
    // 0x5e5998: SaveReg r0
    //     0x5e5998: str             x0, [SP, #-8]!
    // 0x5e599c: mov             x0, x1
    // 0x5e59a0: r0 = GDT[cid_x0 + -0x1]()
    //     0x5e59a0: sub             lr, x0, #1
    //     0x5e59a4: ldr             lr, [x21, lr, lsl #3]
    //     0x5e59a8: blr             lr
    // 0x5e59ac: add             SP, SP, #8
    // 0x5e59b0: LoadField: d0 = r0->field_3f
    //     0x5e59b0: ldur            d0, [x0, #0x3f]
    // 0x5e59b4: LeaveFrame
    //     0x5e59b4: mov             SP, fp
    //     0x5e59b8: ldp             fp, lr, [SP], #0x10
    // 0x5e59bc: ret
    //     0x5e59bc: ret             
    // 0x5e59c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e59c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e59c4: b               #0x5e598c
  }
  get _ embedderId(/* No info */) {
    // ** addr: 0x62262c, size: 0x54
    // 0x62262c: EnterFrame
    //     0x62262c: stp             fp, lr, [SP, #-0x10]!
    //     0x622630: mov             fp, SP
    // 0x622634: CheckStackOverflow
    //     0x622634: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x622638: cmp             SP, x16
    //     0x62263c: b.ls            #0x622678
    // 0x622640: ldr             x0, [fp, #0x10]
    // 0x622644: r1 = LoadClassIdInstr(r0)
    //     0x622644: ldur            x1, [x0, #-1]
    //     0x622648: ubfx            x1, x1, #0xc, #0x14
    // 0x62264c: SaveReg r0
    //     0x62264c: str             x0, [SP, #-8]!
    // 0x622650: mov             x0, x1
    // 0x622654: r0 = GDT[cid_x0 + -0x1]()
    //     0x622654: sub             lr, x0, #1
    //     0x622658: ldr             lr, [x21, lr, lsl #3]
    //     0x62265c: blr             lr
    // 0x622660: add             SP, SP, #8
    // 0x622664: LoadField: r1 = r0->field_7
    //     0x622664: ldur            x1, [x0, #7]
    // 0x622668: mov             x0, x1
    // 0x62266c: LeaveFrame
    //     0x62266c: mov             SP, fp
    //     0x622670: ldp             fp, lr, [SP], #0x10
    // 0x622674: ret
    //     0x622674: ret             
    // 0x622678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622678: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62267c: b               #0x622640
  }
  get _ tilt(/* No info */) {
    // ** addr: 0x6a8220, size: 0x50
    // 0x6a8220: EnterFrame
    //     0x6a8220: stp             fp, lr, [SP, #-0x10]!
    //     0x6a8224: mov             fp, SP
    // 0x6a8228: CheckStackOverflow
    //     0x6a8228: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a822c: cmp             SP, x16
    //     0x6a8230: b.ls            #0x6a8268
    // 0x6a8234: ldr             x0, [fp, #0x10]
    // 0x6a8238: r1 = LoadClassIdInstr(r0)
    //     0x6a8238: ldur            x1, [x0, #-1]
    //     0x6a823c: ubfx            x1, x1, #0xc, #0x14
    // 0x6a8240: SaveReg r0
    //     0x6a8240: str             x0, [SP, #-8]!
    // 0x6a8244: mov             x0, x1
    // 0x6a8248: r0 = GDT[cid_x0 + -0x1]()
    //     0x6a8248: sub             lr, x0, #1
    //     0x6a824c: ldr             lr, [x21, lr, lsl #3]
    //     0x6a8250: blr             lr
    // 0x6a8254: add             SP, SP, #8
    // 0x6a8258: LoadField: d0 = r0->field_97
    //     0x6a8258: ldur            d0, [x0, #0x97]
    // 0x6a825c: LeaveFrame
    //     0x6a825c: mov             SP, fp
    //     0x6a8260: ldp             fp, lr, [SP], #0x10
    // 0x6a8264: ret
    //     0x6a8264: ret             
    // 0x6a8268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a8268: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a826c: b               #0x6a8234
  }
  get _ radiusMax(/* No info */) {
    // ** addr: 0x6a9184, size: 0x50
    // 0x6a9184: EnterFrame
    //     0x6a9184: stp             fp, lr, [SP, #-0x10]!
    //     0x6a9188: mov             fp, SP
    // 0x6a918c: CheckStackOverflow
    //     0x6a918c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a9190: cmp             SP, x16
    //     0x6a9194: b.ls            #0x6a91cc
    // 0x6a9198: ldr             x0, [fp, #0x10]
    // 0x6a919c: r1 = LoadClassIdInstr(r0)
    //     0x6a919c: ldur            x1, [x0, #-1]
    //     0x6a91a0: ubfx            x1, x1, #0xc, #0x14
    // 0x6a91a4: SaveReg r0
    //     0x6a91a4: str             x0, [SP, #-8]!
    // 0x6a91a8: mov             x0, x1
    // 0x6a91ac: r0 = GDT[cid_x0 + -0x1]()
    //     0x6a91ac: sub             lr, x0, #1
    //     0x6a91b0: ldr             lr, [x21, lr, lsl #3]
    //     0x6a91b4: blr             lr
    // 0x6a91b8: add             SP, SP, #8
    // 0x6a91bc: LoadField: d0 = r0->field_87
    //     0x6a91bc: ldur            d0, [x0, #0x87]
    // 0x6a91c0: LeaveFrame
    //     0x6a91c0: mov             SP, fp
    //     0x6a91c4: ldp             fp, lr, [SP], #0x10
    // 0x6a91c8: ret
    //     0x6a91c8: ret             
    // 0x6a91cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a91cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a91d0: b               #0x6a9198
  }
  get _ radiusMin(/* No info */) {
    // ** addr: 0x6ac2e4, size: 0x50
    // 0x6ac2e4: EnterFrame
    //     0x6ac2e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ac2e8: mov             fp, SP
    // 0x6ac2ec: CheckStackOverflow
    //     0x6ac2ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ac2f0: cmp             SP, x16
    //     0x6ac2f4: b.ls            #0x6ac32c
    // 0x6ac2f8: ldr             x0, [fp, #0x10]
    // 0x6ac2fc: r1 = LoadClassIdInstr(r0)
    //     0x6ac2fc: ldur            x1, [x0, #-1]
    //     0x6ac300: ubfx            x1, x1, #0xc, #0x14
    // 0x6ac304: SaveReg r0
    //     0x6ac304: str             x0, [SP, #-8]!
    // 0x6ac308: mov             x0, x1
    // 0x6ac30c: r0 = GDT[cid_x0 + -0x1]()
    //     0x6ac30c: sub             lr, x0, #1
    //     0x6ac310: ldr             lr, [x21, lr, lsl #3]
    //     0x6ac314: blr             lr
    // 0x6ac318: add             SP, SP, #8
    // 0x6ac31c: LoadField: d0 = r0->field_7f
    //     0x6ac31c: ldur            d0, [x0, #0x7f]
    // 0x6ac320: LeaveFrame
    //     0x6ac320: mov             SP, fp
    //     0x6ac324: ldp             fp, lr, [SP], #0x10
    // 0x6ac328: ret
    //     0x6ac328: ret             
    // 0x6ac32c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ac32c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ac330: b               #0x6ac2f8
  }
  get _ distanceMax(/* No info */) {
    // ** addr: 0x6bb3e4, size: 0x50
    // 0x6bb3e4: EnterFrame
    //     0x6bb3e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6bb3e8: mov             fp, SP
    // 0x6bb3ec: CheckStackOverflow
    //     0x6bb3ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bb3f0: cmp             SP, x16
    //     0x6bb3f4: b.ls            #0x6bb42c
    // 0x6bb3f8: ldr             x0, [fp, #0x10]
    // 0x6bb3fc: r1 = LoadClassIdInstr(r0)
    //     0x6bb3fc: ldur            x1, [x0, #-1]
    //     0x6bb400: ubfx            x1, x1, #0xc, #0x14
    // 0x6bb404: SaveReg r0
    //     0x6bb404: str             x0, [SP, #-8]!
    // 0x6bb408: mov             x0, x1
    // 0x6bb40c: r0 = GDT[cid_x0 + -0x1]()
    //     0x6bb40c: sub             lr, x0, #1
    //     0x6bb410: ldr             lr, [x21, lr, lsl #3]
    //     0x6bb414: blr             lr
    // 0x6bb418: add             SP, SP, #8
    // 0x6bb41c: LoadField: d0 = r0->field_5f
    //     0x6bb41c: ldur            d0, [x0, #0x5f]
    // 0x6bb420: LeaveFrame
    //     0x6bb420: mov             SP, fp
    //     0x6bb424: ldp             fp, lr, [SP], #0x10
    // 0x6bb428: ret
    //     0x6bb428: ret             
    // 0x6bb42c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bb42c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bb430: b               #0x6bb3f8
  }
  get _ obscured(/* No info */) {
    // ** addr: 0x6bb7f0, size: 0x58
    // 0x6bb7f0: EnterFrame
    //     0x6bb7f0: stp             fp, lr, [SP, #-0x10]!
    //     0x6bb7f4: mov             fp, SP
    // 0x6bb7f8: CheckStackOverflow
    //     0x6bb7f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bb7fc: cmp             SP, x16
    //     0x6bb800: b.ls            #0x6bb840
    // 0x6bb804: ldr             x0, [fp, #0x10]
    // 0x6bb808: r1 = LoadClassIdInstr(r0)
    //     0x6bb808: ldur            x1, [x0, #-1]
    //     0x6bb80c: ubfx            x1, x1, #0xc, #0x14
    // 0x6bb810: SaveReg r0
    //     0x6bb810: str             x0, [SP, #-8]!
    // 0x6bb814: mov             x0, x1
    // 0x6bb818: r0 = GDT[cid_x0 + -0x1]()
    //     0x6bb818: sub             lr, x0, #1
    //     0x6bb81c: ldr             lr, [x21, lr, lsl #3]
    //     0x6bb820: blr             lr
    // 0x6bb824: add             SP, SP, #8
    // 0x6bb828: LoadField: r1 = r0->field_3b
    //     0x6bb828: ldur            w1, [x0, #0x3b]
    // 0x6bb82c: DecompressPointer r1
    //     0x6bb82c: add             x1, x1, HEAP, lsl #32
    // 0x6bb830: mov             x0, x1
    // 0x6bb834: LeaveFrame
    //     0x6bb834: mov             SP, fp
    //     0x6bb838: ldp             fp, lr, [SP], #0x10
    // 0x6bb83c: ret
    //     0x6bb83c: ret             
    // 0x6bb840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bb840: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bb844: b               #0x6bb804
  }
  get _ down(/* No info */) {
    // ** addr: 0x6bb848, size: 0x58
    // 0x6bb848: EnterFrame
    //     0x6bb848: stp             fp, lr, [SP, #-0x10]!
    //     0x6bb84c: mov             fp, SP
    // 0x6bb850: CheckStackOverflow
    //     0x6bb850: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bb854: cmp             SP, x16
    //     0x6bb858: b.ls            #0x6bb898
    // 0x6bb85c: ldr             x0, [fp, #0x10]
    // 0x6bb860: r1 = LoadClassIdInstr(r0)
    //     0x6bb860: ldur            x1, [x0, #-1]
    //     0x6bb864: ubfx            x1, x1, #0xc, #0x14
    // 0x6bb868: SaveReg r0
    //     0x6bb868: str             x0, [SP, #-8]!
    // 0x6bb86c: mov             x0, x1
    // 0x6bb870: r0 = GDT[cid_x0 + -0x1]()
    //     0x6bb870: sub             lr, x0, #1
    //     0x6bb874: ldr             lr, [x21, lr, lsl #3]
    //     0x6bb878: blr             lr
    // 0x6bb87c: add             SP, SP, #8
    // 0x6bb880: LoadField: r1 = r0->field_37
    //     0x6bb880: ldur            w1, [x0, #0x37]
    // 0x6bb884: DecompressPointer r1
    //     0x6bb884: add             x1, x1, HEAP, lsl #32
    // 0x6bb888: mov             x0, x1
    // 0x6bb88c: LeaveFrame
    //     0x6bb88c: mov             SP, fp
    //     0x6bb890: ldp             fp, lr, [SP], #0x10
    // 0x6bb894: ret
    //     0x6bb894: ret             
    // 0x6bb898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bb898: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bb89c: b               #0x6bb85c
  }
  get _ orientation(/* No info */) {
    // ** addr: 0x6bd33c, size: 0x50
    // 0x6bd33c: EnterFrame
    //     0x6bd33c: stp             fp, lr, [SP, #-0x10]!
    //     0x6bd340: mov             fp, SP
    // 0x6bd344: CheckStackOverflow
    //     0x6bd344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bd348: cmp             SP, x16
    //     0x6bd34c: b.ls            #0x6bd384
    // 0x6bd350: ldr             x0, [fp, #0x10]
    // 0x6bd354: r1 = LoadClassIdInstr(r0)
    //     0x6bd354: ldur            x1, [x0, #-1]
    //     0x6bd358: ubfx            x1, x1, #0xc, #0x14
    // 0x6bd35c: SaveReg r0
    //     0x6bd35c: str             x0, [SP, #-8]!
    // 0x6bd360: mov             x0, x1
    // 0x6bd364: r0 = GDT[cid_x0 + -0x1]()
    //     0x6bd364: sub             lr, x0, #1
    //     0x6bd368: ldr             lr, [x21, lr, lsl #3]
    //     0x6bd36c: blr             lr
    // 0x6bd370: add             SP, SP, #8
    // 0x6bd374: LoadField: d0 = r0->field_8f
    //     0x6bd374: ldur            d0, [x0, #0x8f]
    // 0x6bd378: LeaveFrame
    //     0x6bd378: mov             SP, fp
    //     0x6bd37c: ldp             fp, lr, [SP], #0x10
    // 0x6bd380: ret
    //     0x6bd380: ret             
    // 0x6bd384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bd384: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bd388: b               #0x6bd350
  }
  get _ size(/* No info */) {
    // ** addr: 0x6bd38c, size: 0x50
    // 0x6bd38c: EnterFrame
    //     0x6bd38c: stp             fp, lr, [SP, #-0x10]!
    //     0x6bd390: mov             fp, SP
    // 0x6bd394: CheckStackOverflow
    //     0x6bd394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bd398: cmp             SP, x16
    //     0x6bd39c: b.ls            #0x6bd3d4
    // 0x6bd3a0: ldr             x0, [fp, #0x10]
    // 0x6bd3a4: r1 = LoadClassIdInstr(r0)
    //     0x6bd3a4: ldur            x1, [x0, #-1]
    //     0x6bd3a8: ubfx            x1, x1, #0xc, #0x14
    // 0x6bd3ac: SaveReg r0
    //     0x6bd3ac: str             x0, [SP, #-8]!
    // 0x6bd3b0: mov             x0, x1
    // 0x6bd3b4: r0 = GDT[cid_x0 + -0x1]()
    //     0x6bd3b4: sub             lr, x0, #1
    //     0x6bd3b8: ldr             lr, [x21, lr, lsl #3]
    //     0x6bd3bc: blr             lr
    // 0x6bd3c0: add             SP, SP, #8
    // 0x6bd3c4: LoadField: d0 = r0->field_67
    //     0x6bd3c4: ldur            d0, [x0, #0x67]
    // 0x6bd3c8: LeaveFrame
    //     0x6bd3c8: mov             SP, fp
    //     0x6bd3cc: ldp             fp, lr, [SP], #0x10
    // 0x6bd3d0: ret
    //     0x6bd3d0: ret             
    // 0x6bd3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bd3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bd3d8: b               #0x6bd3a0
  }
  get _ pressureMin(/* No info */) {
    // ** addr: 0x6be7ec, size: 0x50
    // 0x6be7ec: EnterFrame
    //     0x6be7ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6be7f0: mov             fp, SP
    // 0x6be7f4: CheckStackOverflow
    //     0x6be7f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6be7f8: cmp             SP, x16
    //     0x6be7fc: b.ls            #0x6be834
    // 0x6be800: ldr             x0, [fp, #0x10]
    // 0x6be804: r1 = LoadClassIdInstr(r0)
    //     0x6be804: ldur            x1, [x0, #-1]
    //     0x6be808: ubfx            x1, x1, #0xc, #0x14
    // 0x6be80c: SaveReg r0
    //     0x6be80c: str             x0, [SP, #-8]!
    // 0x6be810: mov             x0, x1
    // 0x6be814: r0 = GDT[cid_x0 + -0x1]()
    //     0x6be814: sub             lr, x0, #1
    //     0x6be818: ldr             lr, [x21, lr, lsl #3]
    //     0x6be81c: blr             lr
    // 0x6be820: add             SP, SP, #8
    // 0x6be824: LoadField: d0 = r0->field_47
    //     0x6be824: ldur            d0, [x0, #0x47]
    // 0x6be828: LeaveFrame
    //     0x6be828: mov             SP, fp
    //     0x6be82c: ldp             fp, lr, [SP], #0x10
    // 0x6be830: ret
    //     0x6be830: ret             
    // 0x6be834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6be834: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6be838: b               #0x6be800
  }
  get _ radiusMinor(/* No info */) {
    // ** addr: 0x6be83c, size: 0x50
    // 0x6be83c: EnterFrame
    //     0x6be83c: stp             fp, lr, [SP, #-0x10]!
    //     0x6be840: mov             fp, SP
    // 0x6be844: CheckStackOverflow
    //     0x6be844: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6be848: cmp             SP, x16
    //     0x6be84c: b.ls            #0x6be884
    // 0x6be850: ldr             x0, [fp, #0x10]
    // 0x6be854: r1 = LoadClassIdInstr(r0)
    //     0x6be854: ldur            x1, [x0, #-1]
    //     0x6be858: ubfx            x1, x1, #0xc, #0x14
    // 0x6be85c: SaveReg r0
    //     0x6be85c: str             x0, [SP, #-8]!
    // 0x6be860: mov             x0, x1
    // 0x6be864: r0 = GDT[cid_x0 + -0x1]()
    //     0x6be864: sub             lr, x0, #1
    //     0x6be868: ldr             lr, [x21, lr, lsl #3]
    //     0x6be86c: blr             lr
    // 0x6be870: add             SP, SP, #8
    // 0x6be874: LoadField: d0 = r0->field_77
    //     0x6be874: ldur            d0, [x0, #0x77]
    // 0x6be878: LeaveFrame
    //     0x6be878: mov             SP, fp
    //     0x6be87c: ldp             fp, lr, [SP], #0x10
    // 0x6be880: ret
    //     0x6be880: ret             
    // 0x6be884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6be884: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6be888: b               #0x6be850
  }
  get _ radiusMajor(/* No info */) {
    // ** addr: 0x6ff378, size: 0x50
    // 0x6ff378: EnterFrame
    //     0x6ff378: stp             fp, lr, [SP, #-0x10]!
    //     0x6ff37c: mov             fp, SP
    // 0x6ff380: CheckStackOverflow
    //     0x6ff380: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ff384: cmp             SP, x16
    //     0x6ff388: b.ls            #0x6ff3c0
    // 0x6ff38c: ldr             x0, [fp, #0x10]
    // 0x6ff390: r1 = LoadClassIdInstr(r0)
    //     0x6ff390: ldur            x1, [x0, #-1]
    //     0x6ff394: ubfx            x1, x1, #0xc, #0x14
    // 0x6ff398: SaveReg r0
    //     0x6ff398: str             x0, [SP, #-8]!
    // 0x6ff39c: mov             x0, x1
    // 0x6ff3a0: r0 = GDT[cid_x0 + -0x1]()
    //     0x6ff3a0: sub             lr, x0, #1
    //     0x6ff3a4: ldr             lr, [x21, lr, lsl #3]
    //     0x6ff3a8: blr             lr
    // 0x6ff3ac: add             SP, SP, #8
    // 0x6ff3b0: LoadField: d0 = r0->field_6f
    //     0x6ff3b0: ldur            d0, [x0, #0x6f]
    // 0x6ff3b4: LeaveFrame
    //     0x6ff3b4: mov             SP, fp
    //     0x6ff3b8: ldp             fp, lr, [SP], #0x10
    // 0x6ff3bc: ret
    //     0x6ff3bc: ret             
    // 0x6ff3c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ff3c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ff3c4: b               #0x6ff38c
  }
  get _ pressureMax(/* No info */) {
    // ** addr: 0x6ff3c8, size: 0x50
    // 0x6ff3c8: EnterFrame
    //     0x6ff3c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ff3cc: mov             fp, SP
    // 0x6ff3d0: CheckStackOverflow
    //     0x6ff3d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ff3d4: cmp             SP, x16
    //     0x6ff3d8: b.ls            #0x6ff410
    // 0x6ff3dc: ldr             x0, [fp, #0x10]
    // 0x6ff3e0: r1 = LoadClassIdInstr(r0)
    //     0x6ff3e0: ldur            x1, [x0, #-1]
    //     0x6ff3e4: ubfx            x1, x1, #0xc, #0x14
    // 0x6ff3e8: SaveReg r0
    //     0x6ff3e8: str             x0, [SP, #-8]!
    // 0x6ff3ec: mov             x0, x1
    // 0x6ff3f0: r0 = GDT[cid_x0 + -0x1]()
    //     0x6ff3f0: sub             lr, x0, #1
    //     0x6ff3f4: ldr             lr, [x21, lr, lsl #3]
    //     0x6ff3f8: blr             lr
    // 0x6ff3fc: add             SP, SP, #8
    // 0x6ff400: LoadField: d0 = r0->field_4f
    //     0x6ff400: ldur            d0, [x0, #0x4f]
    // 0x6ff404: LeaveFrame
    //     0x6ff404: mov             SP, fp
    //     0x6ff408: ldp             fp, lr, [SP], #0x10
    // 0x6ff40c: ret
    //     0x6ff40c: ret             
    // 0x6ff410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ff410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ff414: b               #0x6ff3dc
  }
  Offset delta(_TransformedPointerEvent) {
    // ** addr: 0xa78b80, size: 0x58
    // 0xa78b80: EnterFrame
    //     0xa78b80: stp             fp, lr, [SP, #-0x10]!
    //     0xa78b84: mov             fp, SP
    // 0xa78b88: CheckStackOverflow
    //     0xa78b88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa78b8c: cmp             SP, x16
    //     0xa78b90: b.ls            #0xa78bd0
    // 0xa78b94: ldr             x0, [fp, #0x10]
    // 0xa78b98: r1 = LoadClassIdInstr(r0)
    //     0xa78b98: ldur            x1, [x0, #-1]
    //     0xa78b9c: ubfx            x1, x1, #0xc, #0x14
    // 0xa78ba0: SaveReg r0
    //     0xa78ba0: str             x0, [SP, #-8]!
    // 0xa78ba4: mov             x0, x1
    // 0xa78ba8: r0 = GDT[cid_x0 + -0x1]()
    //     0xa78ba8: sub             lr, x0, #1
    //     0xa78bac: ldr             lr, [x21, lr, lsl #3]
    //     0xa78bb0: blr             lr
    // 0xa78bb4: add             SP, SP, #8
    // 0xa78bb8: LoadField: r1 = r0->field_2b
    //     0xa78bb8: ldur            w1, [x0, #0x2b]
    // 0xa78bbc: DecompressPointer r1
    //     0xa78bbc: add             x1, x1, HEAP, lsl #32
    // 0xa78bc0: mov             x0, x1
    // 0xa78bc4: LeaveFrame
    //     0xa78bc4: mov             SP, fp
    //     0xa78bc8: ldp             fp, lr, [SP], #0x10
    // 0xa78bcc: ret
    //     0xa78bcc: ret             
    // 0xa78bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa78bd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa78bd4: b               #0xa78b94
  }
  get _ device(/* No info */) {
    // ** addr: 0xa82cec, size: 0x54
    // 0xa82cec: EnterFrame
    //     0xa82cec: stp             fp, lr, [SP, #-0x10]!
    //     0xa82cf0: mov             fp, SP
    // 0xa82cf4: CheckStackOverflow
    //     0xa82cf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa82cf8: cmp             SP, x16
    //     0xa82cfc: b.ls            #0xa82d38
    // 0xa82d00: ldr             x0, [fp, #0x10]
    // 0xa82d04: r1 = LoadClassIdInstr(r0)
    //     0xa82d04: ldur            x1, [x0, #-1]
    //     0xa82d08: ubfx            x1, x1, #0xc, #0x14
    // 0xa82d0c: SaveReg r0
    //     0xa82d0c: str             x0, [SP, #-8]!
    // 0xa82d10: mov             x0, x1
    // 0xa82d14: r0 = GDT[cid_x0 + -0x1]()
    //     0xa82d14: sub             lr, x0, #1
    //     0xa82d18: ldr             lr, [x21, lr, lsl #3]
    //     0xa82d1c: blr             lr
    // 0xa82d20: add             SP, SP, #8
    // 0xa82d24: LoadField: r1 = r0->field_1f
    //     0xa82d24: ldur            x1, [x0, #0x1f]
    // 0xa82d28: mov             x0, x1
    // 0xa82d2c: LeaveFrame
    //     0xa82d2c: mov             SP, fp
    //     0xa82d30: ldp             fp, lr, [SP], #0x10
    // 0xa82d34: ret
    //     0xa82d34: ret             
    // 0xa82d38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa82d38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa82d3c: b               #0xa82d00
  }
  get _ synthesized(/* No info */) {
    // ** addr: 0xa888dc, size: 0x58
    // 0xa888dc: EnterFrame
    //     0xa888dc: stp             fp, lr, [SP, #-0x10]!
    //     0xa888e0: mov             fp, SP
    // 0xa888e4: CheckStackOverflow
    //     0xa888e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa888e8: cmp             SP, x16
    //     0xa888ec: b.ls            #0xa8892c
    // 0xa888f0: ldr             x0, [fp, #0x10]
    // 0xa888f4: r1 = LoadClassIdInstr(r0)
    //     0xa888f4: ldur            x1, [x0, #-1]
    //     0xa888f8: ubfx            x1, x1, #0xc, #0x14
    // 0xa888fc: SaveReg r0
    //     0xa888fc: str             x0, [SP, #-8]!
    // 0xa88900: mov             x0, x1
    // 0xa88904: r0 = GDT[cid_x0 + -0x1]()
    //     0xa88904: sub             lr, x0, #1
    //     0xa88908: ldr             lr, [x21, lr, lsl #3]
    //     0xa8890c: blr             lr
    // 0xa88910: add             SP, SP, #8
    // 0xa88914: LoadField: r1 = r0->field_a7
    //     0xa88914: ldur            w1, [x0, #0xa7]
    // 0xa88918: DecompressPointer r1
    //     0xa88918: add             x1, x1, HEAP, lsl #32
    // 0xa8891c: mov             x0, x1
    // 0xa88920: LeaveFrame
    //     0xa88920: mov             SP, fp
    //     0xa88924: ldp             fp, lr, [SP], #0x10
    // 0xa88928: ret
    //     0xa88928: ret             
    // 0xa8892c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8892c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa88930: b               #0xa888f0
  }
  const Offset localPosition(_TransformedPointerEvent) {
    // ** addr: 0xab27a0, size: 0x38
    // 0xab27a0: EnterFrame
    //     0xab27a0: stp             fp, lr, [SP, #-0x10]!
    //     0xab27a4: mov             fp, SP
    // 0xab27a8: ldr             x1, [fp, #0x10]
    // 0xab27ac: LoadField: r0 = r1->field_7
    //     0xab27ac: ldur            w0, [x1, #7]
    // 0xab27b0: DecompressPointer r0
    //     0xab27b0: add             x0, x0, HEAP, lsl #32
    // 0xab27b4: r16 = Sentinel
    //     0xab27b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xab27b8: cmp             w0, w16
    // 0xab27bc: b.ne            #0xab27cc
    // 0xab27c0: r2 = localPosition
    //     0xab27c0: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e920] Field <_TransformedPointerEvent@660050165.localPosition>: late final (offset: 0x8)
    //     0xab27c4: ldr             x2, [x2, #0x920]
    // 0xab27c8: r0 = InitLateFinalInstanceField()
    //     0xab27c8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xab27cc: LeaveFrame
    //     0xab27cc: mov             SP, fp
    //     0xab27d0: ldp             fp, lr, [SP], #0x10
    // 0xab27d4: ret
    //     0xab27d4: ret             
  }
  get _ buttons(/* No info */) {
    // ** addr: 0xb0d680, size: 0x54
    // 0xb0d680: EnterFrame
    //     0xb0d680: stp             fp, lr, [SP, #-0x10]!
    //     0xb0d684: mov             fp, SP
    // 0xb0d688: CheckStackOverflow
    //     0xb0d688: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0d68c: cmp             SP, x16
    //     0xb0d690: b.ls            #0xb0d6cc
    // 0xb0d694: ldr             x0, [fp, #0x10]
    // 0xb0d698: r1 = LoadClassIdInstr(r0)
    //     0xb0d698: ldur            x1, [x0, #-1]
    //     0xb0d69c: ubfx            x1, x1, #0xc, #0x14
    // 0xb0d6a0: SaveReg r0
    //     0xb0d6a0: str             x0, [SP, #-8]!
    // 0xb0d6a4: mov             x0, x1
    // 0xb0d6a8: r0 = GDT[cid_x0 + -0x1]()
    //     0xb0d6a8: sub             lr, x0, #1
    //     0xb0d6ac: ldr             lr, [x21, lr, lsl #3]
    //     0xb0d6b0: blr             lr
    // 0xb0d6b4: add             SP, SP, #8
    // 0xb0d6b8: LoadField: r1 = r0->field_2f
    //     0xb0d6b8: ldur            x1, [x0, #0x2f]
    // 0xb0d6bc: mov             x0, x1
    // 0xb0d6c0: LeaveFrame
    //     0xb0d6c0: mov             SP, fp
    //     0xb0d6c4: ldp             fp, lr, [SP], #0x10
    // 0xb0d6c8: ret
    //     0xb0d6c8: ret             
    // 0xb0d6cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0d6cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0d6d0: b               #0xb0d694
  }
  get _ timeStamp(/* No info */) {
    // ** addr: 0xcf0788, size: 0x58
    // 0xcf0788: EnterFrame
    //     0xcf0788: stp             fp, lr, [SP, #-0x10]!
    //     0xcf078c: mov             fp, SP
    // 0xcf0790: CheckStackOverflow
    //     0xcf0790: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf0794: cmp             SP, x16
    //     0xcf0798: b.ls            #0xcf07d8
    // 0xcf079c: ldr             x0, [fp, #0x10]
    // 0xcf07a0: r1 = LoadClassIdInstr(r0)
    //     0xcf07a0: ldur            x1, [x0, #-1]
    //     0xcf07a4: ubfx            x1, x1, #0xc, #0x14
    // 0xcf07a8: SaveReg r0
    //     0xcf07a8: str             x0, [SP, #-8]!
    // 0xcf07ac: mov             x0, x1
    // 0xcf07b0: r0 = GDT[cid_x0 + -0x1]()
    //     0xcf07b0: sub             lr, x0, #1
    //     0xcf07b4: ldr             lr, [x21, lr, lsl #3]
    //     0xcf07b8: blr             lr
    // 0xcf07bc: add             SP, SP, #8
    // 0xcf07c0: LoadField: r1 = r0->field_f
    //     0xcf07c0: ldur            w1, [x0, #0xf]
    // 0xcf07c4: DecompressPointer r1
    //     0xcf07c4: add             x1, x1, HEAP, lsl #32
    // 0xcf07c8: mov             x0, x1
    // 0xcf07cc: LeaveFrame
    //     0xcf07cc: mov             SP, fp
    //     0xcf07d0: ldp             fp, lr, [SP], #0x10
    // 0xcf07d4: ret
    //     0xcf07d4: ret             
    // 0xcf07d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf07d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf07dc: b               #0xcf079c
  }
  get _ kind(/* No info */) {
    // ** addr: 0xcf1340, size: 0x58
    // 0xcf1340: EnterFrame
    //     0xcf1340: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1344: mov             fp, SP
    // 0xcf1348: CheckStackOverflow
    //     0xcf1348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf134c: cmp             SP, x16
    //     0xcf1350: b.ls            #0xcf1390
    // 0xcf1354: ldr             x0, [fp, #0x10]
    // 0xcf1358: r1 = LoadClassIdInstr(r0)
    //     0xcf1358: ldur            x1, [x0, #-1]
    //     0xcf135c: ubfx            x1, x1, #0xc, #0x14
    // 0xcf1360: SaveReg r0
    //     0xcf1360: str             x0, [SP, #-8]!
    // 0xcf1364: mov             x0, x1
    // 0xcf1368: r0 = GDT[cid_x0 + -0x1]()
    //     0xcf1368: sub             lr, x0, #1
    //     0xcf136c: ldr             lr, [x21, lr, lsl #3]
    //     0xcf1370: blr             lr
    // 0xcf1374: add             SP, SP, #8
    // 0xcf1378: LoadField: r1 = r0->field_1b
    //     0xcf1378: ldur            w1, [x0, #0x1b]
    // 0xcf137c: DecompressPointer r1
    //     0xcf137c: add             x1, x1, HEAP, lsl #32
    // 0xcf1380: mov             x0, x1
    // 0xcf1384: LeaveFrame
    //     0xcf1384: mov             SP, fp
    //     0xcf1388: ldp             fp, lr, [SP], #0x10
    // 0xcf138c: ret
    //     0xcf138c: ret             
    // 0xcf1390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1394: b               #0xcf1354
  }
  Offset position(_TransformedPointerEvent) {
    // ** addr: 0xcf7630, size: 0x58
    // 0xcf7630: EnterFrame
    //     0xcf7630: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7634: mov             fp, SP
    // 0xcf7638: CheckStackOverflow
    //     0xcf7638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf763c: cmp             SP, x16
    //     0xcf7640: b.ls            #0xcf7680
    // 0xcf7644: ldr             x0, [fp, #0x10]
    // 0xcf7648: r1 = LoadClassIdInstr(r0)
    //     0xcf7648: ldur            x1, [x0, #-1]
    //     0xcf764c: ubfx            x1, x1, #0xc, #0x14
    // 0xcf7650: SaveReg r0
    //     0xcf7650: str             x0, [SP, #-8]!
    // 0xcf7654: mov             x0, x1
    // 0xcf7658: r0 = GDT[cid_x0 + -0x1]()
    //     0xcf7658: sub             lr, x0, #1
    //     0xcf765c: ldr             lr, [x21, lr, lsl #3]
    //     0xcf7660: blr             lr
    // 0xcf7664: add             SP, SP, #8
    // 0xcf7668: LoadField: r1 = r0->field_27
    //     0xcf7668: ldur            w1, [x0, #0x27]
    // 0xcf766c: DecompressPointer r1
    //     0xcf766c: add             x1, x1, HEAP, lsl #32
    // 0xcf7670: mov             x0, x1
    // 0xcf7674: LeaveFrame
    //     0xcf7674: mov             SP, fp
    //     0xcf7678: ldp             fp, lr, [SP], #0x10
    // 0xcf767c: ret
    //     0xcf767c: ret             
    // 0xcf7680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7680: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7684: b               #0xcf7644
  }
  get _ pointer(/* No info */) {
    // ** addr: 0xcf7d4c, size: 0x54
    // 0xcf7d4c: EnterFrame
    //     0xcf7d4c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7d50: mov             fp, SP
    // 0xcf7d54: CheckStackOverflow
    //     0xcf7d54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf7d58: cmp             SP, x16
    //     0xcf7d5c: b.ls            #0xcf7d98
    // 0xcf7d60: ldr             x0, [fp, #0x10]
    // 0xcf7d64: r1 = LoadClassIdInstr(r0)
    //     0xcf7d64: ldur            x1, [x0, #-1]
    //     0xcf7d68: ubfx            x1, x1, #0xc, #0x14
    // 0xcf7d6c: SaveReg r0
    //     0xcf7d6c: str             x0, [SP, #-8]!
    // 0xcf7d70: mov             x0, x1
    // 0xcf7d74: r0 = GDT[cid_x0 + -0x1]()
    //     0xcf7d74: sub             lr, x0, #1
    //     0xcf7d78: ldr             lr, [x21, lr, lsl #3]
    //     0xcf7d7c: blr             lr
    // 0xcf7d80: add             SP, SP, #8
    // 0xcf7d84: LoadField: r1 = r0->field_13
    //     0xcf7d84: ldur            x1, [x0, #0x13]
    // 0xcf7d88: mov             x0, x1
    // 0xcf7d8c: LeaveFrame
    //     0xcf7d8c: mov             SP, fp
    //     0xcf7d90: ldp             fp, lr, [SP], #0x10
    // 0xcf7d94: ret
    //     0xcf7d94: ret             
    // 0xcf7d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7d9c: b               #0xcf7d60
  }
}

// class id: 2295, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerCancelEvent&_TransformedPointerEvent&_CopyPointerCancelEvent extends _TransformedPointerEvent
     with _CopyPointerCancelEvent {
}

// class id: 2296, size: 0x18, field offset: 0x10
class _TransformedPointerCancelEvent extends __TransformedPointerCancelEvent&_TransformedPointerEvent&_CopyPointerCancelEvent
    implements PointerCancelEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a81dc, size: 0x44
    // 0x6a81dc: EnterFrame
    //     0x6a81dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6a81e0: mov             fp, SP
    // 0x6a81e4: CheckStackOverflow
    //     0x6a81e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a81e8: cmp             SP, x16
    //     0x6a81ec: b.ls            #0x6a8218
    // 0x6a81f0: ldr             x0, [fp, #0x18]
    // 0x6a81f4: LoadField: r1 = r0->field_f
    //     0x6a81f4: ldur            w1, [x0, #0xf]
    // 0x6a81f8: DecompressPointer r1
    //     0x6a81f8: add             x1, x1, HEAP, lsl #32
    // 0x6a81fc: ldr             x16, [fp, #0x10]
    // 0x6a8200: stp             x16, x1, [SP, #-0x10]!
    // 0x6a8204: r0 = transformed()
    //     0x6a8204: bl              #0x6a5a48  ; [package:flutter/src/gestures/events.dart] PointerCancelEvent::transformed
    // 0x6a8208: add             SP, SP, #0x10
    // 0x6a820c: LeaveFrame
    //     0x6a820c: mov             SP, fp
    //     0x6a8210: ldp             fp, lr, [SP], #0x10
    // 0x6a8214: ret
    //     0x6a8214: ret             
    // 0x6a8218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a8218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a821c: b               #0x6a81f0
  }
}

// class id: 2297, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerPanZoomEndEvent&_TransformedPointerEvent&_CopyPointerPanZoomEndEvent extends _TransformedPointerEvent
     with _CopyPointerPanZoomEndEvent {
}

// class id: 2298, size: 0x18, field offset: 0x10
class _TransformedPointerPanZoomEndEvent extends __TransformedPointerPanZoomEndEvent&_TransformedPointerEvent&_CopyPointerPanZoomEndEvent
    implements PointerPanZoomEndEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a8198, size: 0x44
    // 0x6a8198: EnterFrame
    //     0x6a8198: stp             fp, lr, [SP, #-0x10]!
    //     0x6a819c: mov             fp, SP
    // 0x6a81a0: CheckStackOverflow
    //     0x6a81a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a81a4: cmp             SP, x16
    //     0x6a81a8: b.ls            #0x6a81d4
    // 0x6a81ac: ldr             x0, [fp, #0x18]
    // 0x6a81b0: LoadField: r1 = r0->field_f
    //     0x6a81b0: ldur            w1, [x0, #0xf]
    // 0x6a81b4: DecompressPointer r1
    //     0x6a81b4: add             x1, x1, HEAP, lsl #32
    // 0x6a81b8: ldr             x16, [fp, #0x10]
    // 0x6a81bc: stp             x16, x1, [SP, #-0x10]!
    // 0x6a81c0: r0 = transformed()
    //     0x6a81c0: bl              #0x6a59e8  ; [package:flutter/src/gestures/events.dart] PointerPanZoomEndEvent::transformed
    // 0x6a81c4: add             SP, SP, #0x10
    // 0x6a81c8: LeaveFrame
    //     0x6a81c8: mov             SP, fp
    //     0x6a81cc: ldp             fp, lr, [SP], #0x10
    // 0x6a81d0: ret
    //     0x6a81d0: ret             
    // 0x6a81d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a81d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a81d8: b               #0x6a81ac
  }
}

// class id: 2299, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerPanZoomUpdateEvent&_TransformedPointerEvent&_CopyPointerPanZoomUpdateEvent extends _TransformedPointerEvent
     with _CopyPointerPanZoomUpdateEvent {
}

// class id: 2300, size: 0x20, field offset: 0x10
class _TransformedPointerPanZoomUpdateEvent extends __TransformedPointerPanZoomUpdateEvent&_TransformedPointerEvent&_CopyPointerPanZoomUpdateEvent
    implements PointerPanZoomUpdateEvent {

  late final Offset localPanDelta; // offset: 0x14
  late final Offset localPan; // offset: 0x10

  _ transformed(/* No info */) {
    // ** addr: 0x6a8154, size: 0x44
    // 0x6a8154: EnterFrame
    //     0x6a8154: stp             fp, lr, [SP, #-0x10]!
    //     0x6a8158: mov             fp, SP
    // 0x6a815c: CheckStackOverflow
    //     0x6a815c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a8160: cmp             SP, x16
    //     0x6a8164: b.ls            #0x6a8190
    // 0x6a8168: ldr             x0, [fp, #0x18]
    // 0x6a816c: LoadField: r1 = r0->field_17
    //     0x6a816c: ldur            w1, [x0, #0x17]
    // 0x6a8170: DecompressPointer r1
    //     0x6a8170: add             x1, x1, HEAP, lsl #32
    // 0x6a8174: ldr             x16, [fp, #0x10]
    // 0x6a8178: stp             x16, x1, [SP, #-0x10]!
    // 0x6a817c: r0 = transformed()
    //     0x6a817c: bl              #0x6a5980  ; [package:flutter/src/gestures/events.dart] PointerPanZoomUpdateEvent::transformed
    // 0x6a8180: add             SP, SP, #0x10
    // 0x6a8184: LeaveFrame
    //     0x6a8184: mov             SP, fp
    //     0x6a8188: ldp             fp, lr, [SP], #0x10
    // 0x6a818c: ret
    //     0x6a818c: ret             
    // 0x6a8190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a8190: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a8194: b               #0x6a8168
  }
  get _ rotation(/* No info */) {
    // ** addr: 0xcf7b7c, size: 0x14
    // 0xcf7b7c: ldr             x0, [SP]
    // 0xcf7b80: LoadField: r1 = r0->field_17
    //     0xcf7b80: ldur            w1, [x0, #0x17]
    // 0xcf7b84: DecompressPointer r1
    //     0xcf7b84: add             x1, x1, HEAP, lsl #32
    // 0xcf7b88: LoadField: d0 = r1->field_c3
    //     0xcf7b88: ldur            d0, [x1, #0xc3]
    // 0xcf7b8c: ret
    //     0xcf7b8c: ret             
  }
  get _ scale(/* No info */) {
    // ** addr: 0xcf7b90, size: 0x14
    // 0xcf7b90: ldr             x0, [SP]
    // 0xcf7b94: LoadField: r1 = r0->field_17
    //     0xcf7b94: ldur            w1, [x0, #0x17]
    // 0xcf7b98: DecompressPointer r1
    //     0xcf7b98: add             x1, x1, HEAP, lsl #32
    // 0xcf7b9c: LoadField: d0 = r1->field_bb
    //     0xcf7b9c: ldur            d0, [x1, #0xbb]
    // 0xcf7ba0: ret
    //     0xcf7ba0: ret             
  }
  const Offset localPanDelta(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0xcf7bbc, size: 0x38
    // 0xcf7bbc: EnterFrame
    //     0xcf7bbc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7bc0: mov             fp, SP
    // 0xcf7bc4: ldr             x1, [fp, #0x10]
    // 0xcf7bc8: LoadField: r0 = r1->field_13
    //     0xcf7bc8: ldur            w0, [x1, #0x13]
    // 0xcf7bcc: DecompressPointer r0
    //     0xcf7bcc: add             x0, x0, HEAP, lsl #32
    // 0xcf7bd0: r16 = Sentinel
    //     0xcf7bd0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcf7bd4: cmp             w0, w16
    // 0xcf7bd8: b.ne            #0xcf7be8
    // 0xcf7bdc: r2 = localPanDelta
    //     0xcf7bdc: add             x2, PP, #0x37, lsl #12  ; [pp+0x37b28] Field <_TransformedPointerPanZoomUpdateEvent@660050165.localPanDelta>: late final (offset: 0x14)
    //     0xcf7be0: ldr             x2, [x2, #0xb28]
    // 0xcf7be4: r0 = InitLateFinalInstanceField()
    //     0xcf7be4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xcf7be8: LeaveFrame
    //     0xcf7be8: mov             SP, fp
    //     0xcf7bec: ldp             fp, lr, [SP], #0x10
    // 0xcf7bf0: ret
    //     0xcf7bf0: ret             
  }
  Offset localPanDelta(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0xcf7bf4, size: 0xa0
    // 0xcf7bf4: EnterFrame
    //     0xcf7bf4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7bf8: mov             fp, SP
    // 0xcf7bfc: AllocStack(0x18)
    //     0xcf7bfc: sub             SP, SP, #0x18
    // 0xcf7c00: CheckStackOverflow
    //     0xcf7c00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf7c04: cmp             SP, x16
    //     0xcf7c08: b.ls            #0xcf7c8c
    // 0xcf7c0c: ldr             x1, [fp, #0x10]
    // 0xcf7c10: LoadField: r0 = r1->field_1b
    //     0xcf7c10: ldur            w0, [x1, #0x1b]
    // 0xcf7c14: DecompressPointer r0
    //     0xcf7c14: add             x0, x0, HEAP, lsl #32
    // 0xcf7c18: stur            x0, [fp, #-0x18]
    // 0xcf7c1c: LoadField: r2 = r1->field_17
    //     0xcf7c1c: ldur            w2, [x1, #0x17]
    // 0xcf7c20: DecompressPointer r2
    //     0xcf7c20: add             x2, x2, HEAP, lsl #32
    // 0xcf7c24: LoadField: r3 = r2->field_b7
    //     0xcf7c24: ldur            w3, [x2, #0xb7]
    // 0xcf7c28: DecompressPointer r3
    //     0xcf7c28: add             x3, x3, HEAP, lsl #32
    // 0xcf7c2c: stur            x3, [fp, #-0x10]
    // 0xcf7c30: LoadField: r4 = r2->field_b3
    //     0xcf7c30: ldur            w4, [x2, #0xb3]
    // 0xcf7c34: DecompressPointer r4
    //     0xcf7c34: add             x4, x4, HEAP, lsl #32
    // 0xcf7c38: stur            x4, [fp, #-8]
    // 0xcf7c3c: LoadField: r0 = r1->field_f
    //     0xcf7c3c: ldur            w0, [x1, #0xf]
    // 0xcf7c40: DecompressPointer r0
    //     0xcf7c40: add             x0, x0, HEAP, lsl #32
    // 0xcf7c44: r16 = Sentinel
    //     0xcf7c44: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcf7c48: cmp             w0, w16
    // 0xcf7c4c: b.ne            #0xcf7c5c
    // 0xcf7c50: r2 = localPan
    //     0xcf7c50: add             x2, PP, #0x37, lsl #12  ; [pp+0x37b30] Field <_TransformedPointerPanZoomUpdateEvent@660050165.localPan>: late final (offset: 0x10)
    //     0xcf7c54: ldr             x2, [x2, #0xb30]
    // 0xcf7c58: r0 = InitLateFinalInstanceField()
    //     0xcf7c58: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xcf7c5c: ldur            x16, [fp, #-0x18]
    // 0xcf7c60: ldur            lr, [fp, #-0x10]
    // 0xcf7c64: stp             lr, x16, [SP, #-0x10]!
    // 0xcf7c68: ldur            x16, [fp, #-8]
    // 0xcf7c6c: stp             x0, x16, [SP, #-0x10]!
    // 0xcf7c70: r4 = const [0, 0x4, 0x4, 0x3, transformedEndPosition, 0x3, null]
    //     0xcf7c70: add             x4, PP, #0x37, lsl #12  ; [pp+0x37b20] List(7) [0, 0x4, 0x4, 0x3, "transformedEndPosition", 0x3, Null]
    //     0xcf7c74: ldr             x4, [x4, #0xb20]
    // 0xcf7c78: r0 = transformDeltaViaPositions()
    //     0xcf7c78: bl              #0x5b64a0  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xcf7c7c: add             SP, SP, #0x20
    // 0xcf7c80: LeaveFrame
    //     0xcf7c80: mov             SP, fp
    //     0xcf7c84: ldp             fp, lr, [SP], #0x10
    // 0xcf7c88: ret
    //     0xcf7c88: ret             
    // 0xcf7c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7c8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7c90: b               #0xcf7c0c
  }
  Offset localPan(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0xcf7c94, size: 0x50
    // 0xcf7c94: EnterFrame
    //     0xcf7c94: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7c98: mov             fp, SP
    // 0xcf7c9c: CheckStackOverflow
    //     0xcf7c9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf7ca0: cmp             SP, x16
    //     0xcf7ca4: b.ls            #0xcf7cdc
    // 0xcf7ca8: ldr             x0, [fp, #0x10]
    // 0xcf7cac: LoadField: r1 = r0->field_1b
    //     0xcf7cac: ldur            w1, [x0, #0x1b]
    // 0xcf7cb0: DecompressPointer r1
    //     0xcf7cb0: add             x1, x1, HEAP, lsl #32
    // 0xcf7cb4: LoadField: r2 = r0->field_17
    //     0xcf7cb4: ldur            w2, [x0, #0x17]
    // 0xcf7cb8: DecompressPointer r2
    //     0xcf7cb8: add             x2, x2, HEAP, lsl #32
    // 0xcf7cbc: LoadField: r0 = r2->field_b3
    //     0xcf7cbc: ldur            w0, [x2, #0xb3]
    // 0xcf7cc0: DecompressPointer r0
    //     0xcf7cc0: add             x0, x0, HEAP, lsl #32
    // 0xcf7cc4: stp             x0, x1, [SP, #-0x10]!
    // 0xcf7cc8: r0 = transformPosition()
    //     0xcf7cc8: bl              #0x5b659c  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0xcf7ccc: add             SP, SP, #0x10
    // 0xcf7cd0: LeaveFrame
    //     0xcf7cd0: mov             SP, fp
    //     0xcf7cd4: ldp             fp, lr, [SP], #0x10
    // 0xcf7cd8: ret
    //     0xcf7cd8: ret             
    // 0xcf7cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7cdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7ce0: b               #0xcf7ca8
  }
  const Offset localPan(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0xcf7ce4, size: 0x38
    // 0xcf7ce4: EnterFrame
    //     0xcf7ce4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7ce8: mov             fp, SP
    // 0xcf7cec: ldr             x1, [fp, #0x10]
    // 0xcf7cf0: LoadField: r0 = r1->field_f
    //     0xcf7cf0: ldur            w0, [x1, #0xf]
    // 0xcf7cf4: DecompressPointer r0
    //     0xcf7cf4: add             x0, x0, HEAP, lsl #32
    // 0xcf7cf8: r16 = Sentinel
    //     0xcf7cf8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcf7cfc: cmp             w0, w16
    // 0xcf7d00: b.ne            #0xcf7d10
    // 0xcf7d04: r2 = localPan
    //     0xcf7d04: add             x2, PP, #0x37, lsl #12  ; [pp+0x37b30] Field <_TransformedPointerPanZoomUpdateEvent@660050165.localPan>: late final (offset: 0x10)
    //     0xcf7d08: ldr             x2, [x2, #0xb30]
    // 0xcf7d0c: r0 = InitLateFinalInstanceField()
    //     0xcf7d0c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xcf7d10: LeaveFrame
    //     0xcf7d10: mov             SP, fp
    //     0xcf7d14: ldp             fp, lr, [SP], #0x10
    // 0xcf7d18: ret
    //     0xcf7d18: ret             
  }
  Offset panDelta(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0xcf7d1c, size: 0x18
    // 0xcf7d1c: ldr             x1, [SP]
    // 0xcf7d20: LoadField: r2 = r1->field_17
    //     0xcf7d20: ldur            w2, [x1, #0x17]
    // 0xcf7d24: DecompressPointer r2
    //     0xcf7d24: add             x2, x2, HEAP, lsl #32
    // 0xcf7d28: LoadField: r0 = r2->field_b7
    //     0xcf7d28: ldur            w0, [x2, #0xb7]
    // 0xcf7d2c: DecompressPointer r0
    //     0xcf7d2c: add             x0, x0, HEAP, lsl #32
    // 0xcf7d30: ret
    //     0xcf7d30: ret             
  }
  Offset pan(_TransformedPointerPanZoomUpdateEvent) {
    // ** addr: 0xcf7d34, size: 0x18
    // 0xcf7d34: ldr             x1, [SP]
    // 0xcf7d38: LoadField: r2 = r1->field_17
    //     0xcf7d38: ldur            w2, [x1, #0x17]
    // 0xcf7d3c: DecompressPointer r2
    //     0xcf7d3c: add             x2, x2, HEAP, lsl #32
    // 0xcf7d40: LoadField: r0 = r2->field_b3
    //     0xcf7d40: ldur            w0, [x2, #0xb3]
    // 0xcf7d44: DecompressPointer r0
    //     0xcf7d44: add             x0, x0, HEAP, lsl #32
    // 0xcf7d48: ret
    //     0xcf7d48: ret             
  }
}

// class id: 2301, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerPanZoomStartEvent&_TransformedPointerEvent&_CopyPointerPanZoomStartEvent extends _TransformedPointerEvent
     with _CopyPointerPanZoomStartEvent {
}

// class id: 2302, size: 0x18, field offset: 0x10
class _TransformedPointerPanZoomStartEvent extends __TransformedPointerPanZoomStartEvent&_TransformedPointerEvent&_CopyPointerPanZoomStartEvent
    implements PointerPanZoomStartEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a8110, size: 0x44
    // 0x6a8110: EnterFrame
    //     0x6a8110: stp             fp, lr, [SP, #-0x10]!
    //     0x6a8114: mov             fp, SP
    // 0x6a8118: CheckStackOverflow
    //     0x6a8118: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a811c: cmp             SP, x16
    //     0x6a8120: b.ls            #0x6a814c
    // 0x6a8124: ldr             x0, [fp, #0x18]
    // 0x6a8128: LoadField: r1 = r0->field_f
    //     0x6a8128: ldur            w1, [x0, #0xf]
    // 0x6a812c: DecompressPointer r1
    //     0x6a812c: add             x1, x1, HEAP, lsl #32
    // 0x6a8130: ldr             x16, [fp, #0x10]
    // 0x6a8134: stp             x16, x1, [SP, #-0x10]!
    // 0x6a8138: r0 = transformed()
    //     0x6a8138: bl              #0x6a5920  ; [package:flutter/src/gestures/events.dart] PointerPanZoomStartEvent::transformed
    // 0x6a813c: add             SP, SP, #0x10
    // 0x6a8140: LeaveFrame
    //     0x6a8140: mov             SP, fp
    //     0x6a8144: ldp             fp, lr, [SP], #0x10
    // 0x6a8148: ret
    //     0x6a8148: ret             
    // 0x6a814c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a814c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a8150: b               #0x6a8124
  }
}

// class id: 2303, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerScaleEvent&_TransformedPointerEvent&_CopyPointerScaleEvent extends _TransformedPointerEvent
     with _CopyPointerScaleEvent {
}

// class id: 2304, size: 0x18, field offset: 0x10
class _TransformedPointerScaleEvent extends __TransformedPointerScaleEvent&_TransformedPointerEvent&_CopyPointerScaleEvent
    implements PointerScaleEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a80cc, size: 0x44
    // 0x6a80cc: EnterFrame
    //     0x6a80cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6a80d0: mov             fp, SP
    // 0x6a80d4: CheckStackOverflow
    //     0x6a80d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a80d8: cmp             SP, x16
    //     0x6a80dc: b.ls            #0x6a8108
    // 0x6a80e0: ldr             x0, [fp, #0x18]
    // 0x6a80e4: LoadField: r1 = r0->field_f
    //     0x6a80e4: ldur            w1, [x0, #0xf]
    // 0x6a80e8: DecompressPointer r1
    //     0x6a80e8: add             x1, x1, HEAP, lsl #32
    // 0x6a80ec: ldr             x16, [fp, #0x10]
    // 0x6a80f0: stp             x16, x1, [SP, #-0x10]!
    // 0x6a80f4: r0 = transformed()
    //     0x6a80f4: bl              #0x6a5b68  ; [package:flutter/src/gestures/events.dart] PointerScaleEvent::transformed
    // 0x6a80f8: add             SP, SP, #0x10
    // 0x6a80fc: LeaveFrame
    //     0x6a80fc: mov             SP, fp
    //     0x6a8100: ldp             fp, lr, [SP], #0x10
    // 0x6a8104: ret
    //     0x6a8104: ret             
    // 0x6a8108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a8108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a810c: b               #0x6a80e0
  }
}

// class id: 2305, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerScrollInertiaCancelEvent&_TransformedPointerEvent&_CopyPointerScrollInertiaCancelEvent extends _TransformedPointerEvent
     with _CopyPointerScrollInertiaCancelEvent {
}

// class id: 2306, size: 0x18, field offset: 0x10
class _TransformedPointerScrollInertiaCancelEvent extends __TransformedPointerScrollInertiaCancelEvent&_TransformedPointerEvent&_CopyPointerScrollInertiaCancelEvent
    implements PointerScrollInertiaCancelEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a8088, size: 0x44
    // 0x6a8088: EnterFrame
    //     0x6a8088: stp             fp, lr, [SP, #-0x10]!
    //     0x6a808c: mov             fp, SP
    // 0x6a8090: CheckStackOverflow
    //     0x6a8090: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a8094: cmp             SP, x16
    //     0x6a8098: b.ls            #0x6a80c4
    // 0x6a809c: ldr             x0, [fp, #0x18]
    // 0x6a80a0: LoadField: r1 = r0->field_f
    //     0x6a80a0: ldur            w1, [x0, #0xf]
    // 0x6a80a4: DecompressPointer r1
    //     0x6a80a4: add             x1, x1, HEAP, lsl #32
    // 0x6a80a8: ldr             x16, [fp, #0x10]
    // 0x6a80ac: stp             x16, x1, [SP, #-0x10]!
    // 0x6a80b0: r0 = transformed()
    //     0x6a80b0: bl              #0x6a5b08  ; [package:flutter/src/gestures/events.dart] PointerScrollInertiaCancelEvent::transformed
    // 0x6a80b4: add             SP, SP, #0x10
    // 0x6a80b8: LeaveFrame
    //     0x6a80b8: mov             SP, fp
    //     0x6a80bc: ldp             fp, lr, [SP], #0x10
    // 0x6a80c0: ret
    //     0x6a80c0: ret             
    // 0x6a80c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a80c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a80c8: b               #0x6a809c
  }
}

// class id: 2307, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerScrollEvent&_TransformedPointerEvent&_CopyPointerScrollEvent extends _TransformedPointerEvent
     with _CopyPointerScrollEvent {
}

// class id: 2308, size: 0x18, field offset: 0x10
class _TransformedPointerScrollEvent extends __TransformedPointerScrollEvent&_TransformedPointerEvent&_CopyPointerScrollEvent
    implements PointerScrollEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a8044, size: 0x44
    // 0x6a8044: EnterFrame
    //     0x6a8044: stp             fp, lr, [SP, #-0x10]!
    //     0x6a8048: mov             fp, SP
    // 0x6a804c: CheckStackOverflow
    //     0x6a804c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a8050: cmp             SP, x16
    //     0x6a8054: b.ls            #0x6a8080
    // 0x6a8058: ldr             x0, [fp, #0x18]
    // 0x6a805c: LoadField: r1 = r0->field_f
    //     0x6a805c: ldur            w1, [x0, #0xf]
    // 0x6a8060: DecompressPointer r1
    //     0x6a8060: add             x1, x1, HEAP, lsl #32
    // 0x6a8064: ldr             x16, [fp, #0x10]
    // 0x6a8068: stp             x16, x1, [SP, #-0x10]!
    // 0x6a806c: r0 = transformed()
    //     0x6a806c: bl              #0x6a5aa8  ; [package:flutter/src/gestures/events.dart] PointerScrollEvent::transformed
    // 0x6a8070: add             SP, SP, #0x10
    // 0x6a8074: LeaveFrame
    //     0x6a8074: mov             SP, fp
    //     0x6a8078: ldp             fp, lr, [SP], #0x10
    // 0x6a807c: ret
    //     0x6a807c: ret             
    // 0x6a8080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a8080: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a8084: b               #0x6a8058
  }
  get _ scrollDelta(/* No info */) {
    // ** addr: 0xcf7ba4, size: 0x18
    // 0xcf7ba4: ldr             x1, [SP]
    // 0xcf7ba8: LoadField: r2 = r1->field_f
    //     0xcf7ba8: ldur            w2, [x1, #0xf]
    // 0xcf7bac: DecompressPointer r2
    //     0xcf7bac: add             x2, x2, HEAP, lsl #32
    // 0xcf7bb0: LoadField: r0 = r2->field_b3
    //     0xcf7bb0: ldur            w0, [x2, #0xb3]
    // 0xcf7bb4: DecompressPointer r0
    //     0xcf7bb4: add             x0, x0, HEAP, lsl #32
    // 0xcf7bb8: ret
    //     0xcf7bb8: ret             
  }
}

// class id: 2309, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerUpEvent&_TransformedPointerEvent&_CopyPointerUpEvent extends _TransformedPointerEvent
     with _CopyPointerUpEvent {
}

// class id: 2310, size: 0x18, field offset: 0x10
class _TransformedPointerUpEvent extends __TransformedPointerUpEvent&_TransformedPointerEvent&_CopyPointerUpEvent
    implements PointerUpEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a8000, size: 0x44
    // 0x6a8000: EnterFrame
    //     0x6a8000: stp             fp, lr, [SP, #-0x10]!
    //     0x6a8004: mov             fp, SP
    // 0x6a8008: CheckStackOverflow
    //     0x6a8008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a800c: cmp             SP, x16
    //     0x6a8010: b.ls            #0x6a803c
    // 0x6a8014: ldr             x0, [fp, #0x18]
    // 0x6a8018: LoadField: r1 = r0->field_f
    //     0x6a8018: ldur            w1, [x0, #0xf]
    // 0x6a801c: DecompressPointer r1
    //     0x6a801c: add             x1, x1, HEAP, lsl #32
    // 0x6a8020: ldr             x16, [fp, #0x10]
    // 0x6a8024: stp             x16, x1, [SP, #-0x10]!
    // 0x6a8028: r0 = transformed()
    //     0x6a8028: bl              #0x6a58c0  ; [package:flutter/src/gestures/events.dart] PointerUpEvent::transformed
    // 0x6a802c: add             SP, SP, #0x10
    // 0x6a8030: LeaveFrame
    //     0x6a8030: mov             SP, fp
    //     0x6a8034: ldp             fp, lr, [SP], #0x10
    // 0x6a8038: ret
    //     0x6a8038: ret             
    // 0x6a803c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a803c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a8040: b               #0x6a8014
  }
}

// class id: 2311, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerMoveEvent&_TransformedPointerEvent&_CopyPointerMoveEvent extends _TransformedPointerEvent
     with _CopyPointerMoveEvent {
}

// class id: 2312, size: 0x18, field offset: 0x10
class _TransformedPointerMoveEvent extends __TransformedPointerMoveEvent&_TransformedPointerEvent&_CopyPointerMoveEvent
    implements PointerMoveEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a7fbc, size: 0x44
    // 0x6a7fbc: EnterFrame
    //     0x6a7fbc: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7fc0: mov             fp, SP
    // 0x6a7fc4: CheckStackOverflow
    //     0x6a7fc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a7fc8: cmp             SP, x16
    //     0x6a7fcc: b.ls            #0x6a7ff8
    // 0x6a7fd0: ldr             x0, [fp, #0x18]
    // 0x6a7fd4: LoadField: r1 = r0->field_f
    //     0x6a7fd4: ldur            w1, [x0, #0xf]
    // 0x6a7fd8: DecompressPointer r1
    //     0x6a7fd8: add             x1, x1, HEAP, lsl #32
    // 0x6a7fdc: ldr             x16, [fp, #0x10]
    // 0x6a7fe0: stp             x16, x1, [SP, #-0x10]!
    // 0x6a7fe4: r0 = transformed()
    //     0x6a7fe4: bl              #0x6a5860  ; [package:flutter/src/gestures/events.dart] PointerMoveEvent::transformed
    // 0x6a7fe8: add             SP, SP, #0x10
    // 0x6a7fec: LeaveFrame
    //     0x6a7fec: mov             SP, fp
    //     0x6a7ff0: ldp             fp, lr, [SP], #0x10
    // 0x6a7ff4: ret
    //     0x6a7ff4: ret             
    // 0x6a7ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7ff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7ffc: b               #0x6a7fd0
  }
}

// class id: 2313, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerDownEvent&_TransformedPointerEvent&_CopyPointerDownEvent extends _TransformedPointerEvent
     with _CopyPointerDownEvent {
}

// class id: 2314, size: 0x18, field offset: 0x10
class _TransformedPointerDownEvent extends __TransformedPointerDownEvent&_TransformedPointerEvent&_CopyPointerDownEvent
    implements PointerDownEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a7f78, size: 0x44
    // 0x6a7f78: EnterFrame
    //     0x6a7f78: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7f7c: mov             fp, SP
    // 0x6a7f80: CheckStackOverflow
    //     0x6a7f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a7f84: cmp             SP, x16
    //     0x6a7f88: b.ls            #0x6a7fb4
    // 0x6a7f8c: ldr             x0, [fp, #0x18]
    // 0x6a7f90: LoadField: r1 = r0->field_f
    //     0x6a7f90: ldur            w1, [x0, #0xf]
    // 0x6a7f94: DecompressPointer r1
    //     0x6a7f94: add             x1, x1, HEAP, lsl #32
    // 0x6a7f98: ldr             x16, [fp, #0x10]
    // 0x6a7f9c: stp             x16, x1, [SP, #-0x10]!
    // 0x6a7fa0: r0 = transformed()
    //     0x6a7fa0: bl              #0x6a5800  ; [package:flutter/src/gestures/events.dart] PointerDownEvent::transformed
    // 0x6a7fa4: add             SP, SP, #0x10
    // 0x6a7fa8: LeaveFrame
    //     0x6a7fa8: mov             SP, fp
    //     0x6a7fac: ldp             fp, lr, [SP], #0x10
    // 0x6a7fb0: ret
    //     0x6a7fb0: ret             
    // 0x6a7fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7fb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7fb8: b               #0x6a7f8c
  }
}

// class id: 2315, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerExitEvent&_TransformedPointerEvent&_CopyPointerExitEvent extends _TransformedPointerEvent
     with _CopyPointerExitEvent {
}

// class id: 2316, size: 0x18, field offset: 0x10
class _TransformedPointerExitEvent extends __TransformedPointerExitEvent&_TransformedPointerEvent&_CopyPointerExitEvent
    implements PointerExitEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a7f34, size: 0x44
    // 0x6a7f34: EnterFrame
    //     0x6a7f34: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7f38: mov             fp, SP
    // 0x6a7f3c: CheckStackOverflow
    //     0x6a7f3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a7f40: cmp             SP, x16
    //     0x6a7f44: b.ls            #0x6a7f70
    // 0x6a7f48: ldr             x0, [fp, #0x18]
    // 0x6a7f4c: LoadField: r1 = r0->field_f
    //     0x6a7f4c: ldur            w1, [x0, #0xf]
    // 0x6a7f50: DecompressPointer r1
    //     0x6a7f50: add             x1, x1, HEAP, lsl #32
    // 0x6a7f54: ldr             x16, [fp, #0x10]
    // 0x6a7f58: stp             x16, x1, [SP, #-0x10]!
    // 0x6a7f5c: r0 = transformed()
    //     0x6a7f5c: bl              #0x6a57a0  ; [package:flutter/src/gestures/events.dart] PointerExitEvent::transformed
    // 0x6a7f60: add             SP, SP, #0x10
    // 0x6a7f64: LeaveFrame
    //     0x6a7f64: mov             SP, fp
    //     0x6a7f68: ldp             fp, lr, [SP], #0x10
    // 0x6a7f6c: ret
    //     0x6a7f6c: ret             
    // 0x6a7f70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7f70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7f74: b               #0x6a7f48
  }
}

// class id: 2317, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerEnterEvent&_TransformedPointerEvent&_CopyPointerEnterEvent extends _TransformedPointerEvent
     with _CopyPointerEnterEvent {
}

// class id: 2318, size: 0x18, field offset: 0x10
class _TransformedPointerEnterEvent extends __TransformedPointerEnterEvent&_TransformedPointerEvent&_CopyPointerEnterEvent
    implements PointerEnterEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a7ef0, size: 0x44
    // 0x6a7ef0: EnterFrame
    //     0x6a7ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7ef4: mov             fp, SP
    // 0x6a7ef8: CheckStackOverflow
    //     0x6a7ef8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a7efc: cmp             SP, x16
    //     0x6a7f00: b.ls            #0x6a7f2c
    // 0x6a7f04: ldr             x0, [fp, #0x18]
    // 0x6a7f08: LoadField: r1 = r0->field_f
    //     0x6a7f08: ldur            w1, [x0, #0xf]
    // 0x6a7f0c: DecompressPointer r1
    //     0x6a7f0c: add             x1, x1, HEAP, lsl #32
    // 0x6a7f10: ldr             x16, [fp, #0x10]
    // 0x6a7f14: stp             x16, x1, [SP, #-0x10]!
    // 0x6a7f18: r0 = transformed()
    //     0x6a7f18: bl              #0x6a5740  ; [package:flutter/src/gestures/events.dart] PointerEnterEvent::transformed
    // 0x6a7f1c: add             SP, SP, #0x10
    // 0x6a7f20: LeaveFrame
    //     0x6a7f20: mov             SP, fp
    //     0x6a7f24: ldp             fp, lr, [SP], #0x10
    // 0x6a7f28: ret
    //     0x6a7f28: ret             
    // 0x6a7f2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7f2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7f30: b               #0x6a7f04
  }
}

// class id: 2319, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerHoverEvent&_TransformedPointerEvent&_CopyPointerHoverEvent extends _TransformedPointerEvent
     with _CopyPointerHoverEvent {
}

// class id: 2320, size: 0x18, field offset: 0x10
class _TransformedPointerHoverEvent extends __TransformedPointerHoverEvent&_TransformedPointerEvent&_CopyPointerHoverEvent
    implements PointerHoverEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a7eac, size: 0x44
    // 0x6a7eac: EnterFrame
    //     0x6a7eac: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7eb0: mov             fp, SP
    // 0x6a7eb4: CheckStackOverflow
    //     0x6a7eb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a7eb8: cmp             SP, x16
    //     0x6a7ebc: b.ls            #0x6a7ee8
    // 0x6a7ec0: ldr             x0, [fp, #0x18]
    // 0x6a7ec4: LoadField: r1 = r0->field_f
    //     0x6a7ec4: ldur            w1, [x0, #0xf]
    // 0x6a7ec8: DecompressPointer r1
    //     0x6a7ec8: add             x1, x1, HEAP, lsl #32
    // 0x6a7ecc: ldr             x16, [fp, #0x10]
    // 0x6a7ed0: stp             x16, x1, [SP, #-0x10]!
    // 0x6a7ed4: r0 = transformed()
    //     0x6a7ed4: bl              #0x6a56e0  ; [package:flutter/src/gestures/events.dart] PointerHoverEvent::transformed
    // 0x6a7ed8: add             SP, SP, #0x10
    // 0x6a7edc: LeaveFrame
    //     0x6a7edc: mov             SP, fp
    //     0x6a7ee0: ldp             fp, lr, [SP], #0x10
    // 0x6a7ee4: ret
    //     0x6a7ee4: ret             
    // 0x6a7ee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7ee8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7eec: b               #0x6a7ec0
  }
}

// class id: 2321, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerRemovedEvent&_TransformedPointerEvent&_CopyPointerRemovedEvent extends _TransformedPointerEvent
     with _CopyPointerRemovedEvent {
}

// class id: 2322, size: 0x18, field offset: 0x10
class _TransformedPointerRemovedEvent extends __TransformedPointerRemovedEvent&_TransformedPointerEvent&_CopyPointerRemovedEvent
    implements PointerRemovedEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a7e68, size: 0x44
    // 0x6a7e68: EnterFrame
    //     0x6a7e68: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7e6c: mov             fp, SP
    // 0x6a7e70: CheckStackOverflow
    //     0x6a7e70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a7e74: cmp             SP, x16
    //     0x6a7e78: b.ls            #0x6a7ea4
    // 0x6a7e7c: ldr             x0, [fp, #0x18]
    // 0x6a7e80: LoadField: r1 = r0->field_f
    //     0x6a7e80: ldur            w1, [x0, #0xf]
    // 0x6a7e84: DecompressPointer r1
    //     0x6a7e84: add             x1, x1, HEAP, lsl #32
    // 0x6a7e88: ldr             x16, [fp, #0x10]
    // 0x6a7e8c: stp             x16, x1, [SP, #-0x10]!
    // 0x6a7e90: r0 = transformed()
    //     0x6a7e90: bl              #0x6a5680  ; [package:flutter/src/gestures/events.dart] PointerRemovedEvent::transformed
    // 0x6a7e94: add             SP, SP, #0x10
    // 0x6a7e98: LeaveFrame
    //     0x6a7e98: mov             SP, fp
    //     0x6a7e9c: ldp             fp, lr, [SP], #0x10
    // 0x6a7ea0: ret
    //     0x6a7ea0: ret             
    // 0x6a7ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7ea4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7ea8: b               #0x6a7e7c
  }
}

// class id: 2323, size: 0x10, field offset: 0x10
//   transformed mixin,
abstract class __TransformedPointerAddedEvent&_TransformedPointerEvent&_CopyPointerAddedEvent extends _TransformedPointerEvent
     with _CopyPointerAddedEvent {
}

// class id: 2324, size: 0x18, field offset: 0x10
class _TransformedPointerAddedEvent extends __TransformedPointerAddedEvent&_TransformedPointerEvent&_CopyPointerAddedEvent
    implements PointerAddedEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a7e24, size: 0x44
    // 0x6a7e24: EnterFrame
    //     0x6a7e24: stp             fp, lr, [SP, #-0x10]!
    //     0x6a7e28: mov             fp, SP
    // 0x6a7e2c: CheckStackOverflow
    //     0x6a7e2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6a7e30: cmp             SP, x16
    //     0x6a7e34: b.ls            #0x6a7e60
    // 0x6a7e38: ldr             x0, [fp, #0x18]
    // 0x6a7e3c: LoadField: r1 = r0->field_f
    //     0x6a7e3c: ldur            w1, [x0, #0xf]
    // 0x6a7e40: DecompressPointer r1
    //     0x6a7e40: add             x1, x1, HEAP, lsl #32
    // 0x6a7e44: ldr             x16, [fp, #0x10]
    // 0x6a7e48: stp             x16, x1, [SP, #-0x10]!
    // 0x6a7e4c: r0 = transformed()
    //     0x6a7e4c: bl              #0x6a5620  ; [package:flutter/src/gestures/events.dart] PointerAddedEvent::transformed
    // 0x6a7e50: add             SP, SP, #0x10
    // 0x6a7e54: LeaveFrame
    //     0x6a7e54: mov             SP, fp
    //     0x6a7e58: ldp             fp, lr, [SP], #0x10
    // 0x6a7e5c: ret
    //     0x6a7e5c: ret             
    // 0x6a7e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6a7e60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6a7e64: b               #0x6a7e38
  }
}

// class id: 2844, size: 0xb4, field offset: 0x8
//   const constructor, 
abstract class PointerEvent extends _DiagnosticableTree&Object&Diagnosticable {

  const get _ platformData(/* No info */) {
    // ** addr: 0x5acc90, size: 0xc
    // 0x5acc90: ldr             x1, [SP]
    // 0x5acc94: LoadField: r0 = r1->field_9f
    //     0x5acc94: ldur            x0, [x1, #0x9f]
    // 0x5acc98: ret
    //     0x5acc98: ret             
  }
  const get _ distance(/* No info */) {
    // ** addr: 0x5b6378, size: 0xc
    // 0x5b6378: ldr             x0, [SP]
    // 0x5b637c: LoadField: d0 = r0->field_57
    //     0x5b637c: ldur            d0, [x0, #0x57]
    // 0x5b6380: ret
    //     0x5b6380: ret             
  }
  const get _ pressure(/* No info */) {
    // ** addr: 0x5b6384, size: 0xc
    // 0x5b6384: ldr             x0, [SP]
    // 0x5b6388: LoadField: d0 = r0->field_3f
    //     0x5b6388: ldur            d0, [x0, #0x3f]
    // 0x5b638c: ret
    //     0x5b638c: ret             
  }
  static _ transformDeltaViaPositions(/* No info */) {
    // ** addr: 0x5b64a0, size: 0xfc
    // 0x5b64a0: EnterFrame
    //     0x5b64a0: stp             fp, lr, [SP, #-0x10]!
    //     0x5b64a4: mov             fp, SP
    // 0x5b64a8: AllocStack(0x20)
    //     0x5b64a8: sub             SP, SP, #0x20
    // 0x5b64ac: SetupParameters(dynamic _ /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, dynamic _ /* r5, fp-0x8 */, {dynamic transformedEndPosition = Null /* r0 */})
    //     0x5b64ac: mov             x0, x4
    //     0x5b64b0: ldur            w1, [x0, #0x13]
    //     0x5b64b4: add             x1, x1, HEAP, lsl #32
    //     0x5b64b8: sub             x2, x1, #6
    //     0x5b64bc: add             x3, fp, w2, sxtw #2
    //     0x5b64c0: ldr             x3, [x3, #0x20]
    //     0x5b64c4: stur            x3, [fp, #-0x18]
    //     0x5b64c8: add             x4, fp, w2, sxtw #2
    //     0x5b64cc: ldr             x4, [x4, #0x18]
    //     0x5b64d0: stur            x4, [fp, #-0x10]
    //     0x5b64d4: add             x5, fp, w2, sxtw #2
    //     0x5b64d8: ldr             x5, [x5, #0x10]
    //     0x5b64dc: stur            x5, [fp, #-8]
    //     0x5b64e0: ldur            w2, [x0, #0x1f]
    //     0x5b64e4: add             x2, x2, HEAP, lsl #32
    //     0x5b64e8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f38] "transformedEndPosition"
    //     0x5b64ec: ldr             x16, [x16, #0xf38]
    //     0x5b64f0: cmp             w2, w16
    //     0x5b64f4: b.ne            #0x5b6514
    //     0x5b64f8: ldur            w2, [x0, #0x23]
    //     0x5b64fc: add             x2, x2, HEAP, lsl #32
    //     0x5b6500: sub             w0, w1, w2
    //     0x5b6504: add             x1, fp, w0, sxtw #2
    //     0x5b6508: ldr             x1, [x1, #8]
    //     0x5b650c: mov             x0, x1
    //     0x5b6510: b               #0x5b6518
    //     0x5b6514: mov             x0, NULL
    // 0x5b6518: CheckStackOverflow
    //     0x5b6518: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b651c: cmp             SP, x16
    //     0x5b6520: b.ls            #0x5b6594
    // 0x5b6524: cmp             w3, NULL
    // 0x5b6528: b.ne            #0x5b653c
    // 0x5b652c: mov             x0, x4
    // 0x5b6530: LeaveFrame
    //     0x5b6530: mov             SP, fp
    //     0x5b6534: ldp             fp, lr, [SP], #0x10
    // 0x5b6538: ret
    //     0x5b6538: ret             
    // 0x5b653c: cmp             w0, NULL
    // 0x5b6540: b.ne            #0x5b6550
    // 0x5b6544: stp             x5, x3, [SP, #-0x10]!
    // 0x5b6548: r0 = transformPosition()
    //     0x5b6548: bl              #0x5b659c  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0x5b654c: add             SP, SP, #0x10
    // 0x5b6550: stur            x0, [fp, #-0x20]
    // 0x5b6554: ldur            x16, [fp, #-8]
    // 0x5b6558: ldur            lr, [fp, #-0x10]
    // 0x5b655c: stp             lr, x16, [SP, #-0x10]!
    // 0x5b6560: r0 = -()
    //     0x5b6560: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x5b6564: add             SP, SP, #0x10
    // 0x5b6568: ldur            x16, [fp, #-0x18]
    // 0x5b656c: stp             x0, x16, [SP, #-0x10]!
    // 0x5b6570: r0 = transformPosition()
    //     0x5b6570: bl              #0x5b659c  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformPosition
    // 0x5b6574: add             SP, SP, #0x10
    // 0x5b6578: ldur            x16, [fp, #-0x20]
    // 0x5b657c: stp             x0, x16, [SP, #-0x10]!
    // 0x5b6580: r0 = -()
    //     0x5b6580: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x5b6584: add             SP, SP, #0x10
    // 0x5b6588: LeaveFrame
    //     0x5b6588: mov             SP, fp
    //     0x5b658c: ldp             fp, lr, [SP], #0x10
    // 0x5b6590: ret
    //     0x5b6590: ret             
    // 0x5b6594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b6594: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b6598: b               #0x5b6524
  }
  static _ transformPosition(/* No info */) {
    // ** addr: 0x5b659c, size: 0xfc
    // 0x5b659c: EnterFrame
    //     0x5b659c: stp             fp, lr, [SP, #-0x10]!
    //     0x5b65a0: mov             fp, SP
    // 0x5b65a4: AllocStack(0x18)
    //     0x5b65a4: sub             SP, SP, #0x18
    // 0x5b65a8: CheckStackOverflow
    //     0x5b65a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b65ac: cmp             SP, x16
    //     0x5b65b0: b.ls            #0x5b6688
    // 0x5b65b4: ldr             x0, [fp, #0x18]
    // 0x5b65b8: cmp             w0, NULL
    // 0x5b65bc: b.ne            #0x5b65d0
    // 0x5b65c0: ldr             x0, [fp, #0x10]
    // 0x5b65c4: LeaveFrame
    //     0x5b65c4: mov             SP, fp
    //     0x5b65c8: ldp             fp, lr, [SP], #0x10
    // 0x5b65cc: ret
    //     0x5b65cc: ret             
    // 0x5b65d0: ldr             x1, [fp, #0x10]
    // 0x5b65d4: LoadField: d0 = r1->field_7
    //     0x5b65d4: ldur            d0, [x1, #7]
    // 0x5b65d8: stur            d0, [fp, #-0x18]
    // 0x5b65dc: LoadField: d1 = r1->field_f
    //     0x5b65dc: ldur            d1, [x1, #0xf]
    // 0x5b65e0: stur            d1, [fp, #-0x10]
    // 0x5b65e4: r0 = Vector3()
    //     0x5b65e4: bl              #0x5b717c  ; AllocateVector3Stub -> Vector3 (size=0xc)
    // 0x5b65e8: r4 = 6
    //     0x5b65e8: mov             x4, #6
    // 0x5b65ec: stur            x0, [fp, #-8]
    // 0x5b65f0: r0 = AllocateFloat64Array()
    //     0x5b65f0: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x5b65f4: mov             x1, x0
    // 0x5b65f8: ldur            x0, [fp, #-8]
    // 0x5b65fc: StoreField: r0->field_7 = r1
    //     0x5b65fc: stur            w1, [x0, #7]
    // 0x5b6600: ldur            d0, [fp, #-0x18]
    // 0x5b6604: StoreField: r1->field_17 = d0
    //     0x5b6604: stur            d0, [x1, #0x17]
    // 0x5b6608: ldur            d0, [fp, #-0x10]
    // 0x5b660c: StoreField: r1->field_1f = d0
    //     0x5b660c: stur            d0, [x1, #0x1f]
    // 0x5b6610: StoreField: r1->field_27 = rZR
    //     0x5b6610: stur            xzr, [x1, #0x27]
    // 0x5b6614: ldr             x16, [fp, #0x18]
    // 0x5b6618: stp             x0, x16, [SP, #-0x10]!
    // 0x5b661c: r0 = perspectiveTransform()
    //     0x5b661c: bl              #0x5b6f78  ; [package:vector_math/vector_math_64.dart] Matrix4::perspectiveTransform
    // 0x5b6620: add             SP, SP, #0x10
    // 0x5b6624: LoadField: r2 = r0->field_7
    //     0x5b6624: ldur            w2, [x0, #7]
    // 0x5b6628: DecompressPointer r2
    //     0x5b6628: add             x2, x2, HEAP, lsl #32
    // 0x5b662c: LoadField: r0 = r2->field_13
    //     0x5b662c: ldur            w0, [x2, #0x13]
    // 0x5b6630: DecompressPointer r0
    //     0x5b6630: add             x0, x0, HEAP, lsl #32
    // 0x5b6634: r3 = LoadInt32Instr(r0)
    //     0x5b6634: sbfx            x3, x0, #1, #0x1f
    // 0x5b6638: mov             x0, x3
    // 0x5b663c: r1 = 0
    //     0x5b663c: mov             x1, #0
    // 0x5b6640: cmp             x1, x0
    // 0x5b6644: b.hs            #0x5b6690
    // 0x5b6648: LoadField: d0 = r2->field_17
    //     0x5b6648: ldur            d0, [x2, #0x17]
    // 0x5b664c: mov             x0, x3
    // 0x5b6650: stur            d0, [fp, #-0x18]
    // 0x5b6654: r1 = 1
    //     0x5b6654: mov             x1, #1
    // 0x5b6658: cmp             x1, x0
    // 0x5b665c: b.hs            #0x5b6694
    // 0x5b6660: LoadField: d1 = r2->field_1f
    //     0x5b6660: ldur            d1, [x2, #0x1f]
    // 0x5b6664: stur            d1, [fp, #-0x10]
    // 0x5b6668: r0 = Offset()
    //     0x5b6668: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x5b666c: ldur            d0, [fp, #-0x18]
    // 0x5b6670: StoreField: r0->field_7 = d0
    //     0x5b6670: stur            d0, [x0, #7]
    // 0x5b6674: ldur            d0, [fp, #-0x10]
    // 0x5b6678: StoreField: r0->field_f = d0
    //     0x5b6678: stur            d0, [x0, #0xf]
    // 0x5b667c: LeaveFrame
    //     0x5b667c: mov             SP, fp
    //     0x5b6680: ldp             fp, lr, [SP], #0x10
    // 0x5b6684: ret
    //     0x5b6684: ret             
    // 0x5b6688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b6688: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b668c: b               #0x5b65b4
    // 0x5b6690: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x5b6690: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x5b6694: r0 = RangeErrorSharedWithFPURegs()
    //     0x5b6694: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  static _ removePerspectiveTransform(/* No info */) {
    // ** addr: 0x623918, size: 0xf4
    // 0x623918: EnterFrame
    //     0x623918: stp             fp, lr, [SP, #-0x10]!
    //     0x62391c: mov             fp, SP
    // 0x623920: AllocStack(0x10)
    //     0x623920: sub             SP, SP, #0x10
    // 0x623924: CheckStackOverflow
    //     0x623924: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x623928: cmp             SP, x16
    //     0x62392c: b.ls            #0x6239fc
    // 0x623930: r16 = 0.000000
    //     0x623930: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x623934: stp             x16, NULL, [SP, #-0x10]!
    // 0x623938: r16 = 0.000000
    //     0x623938: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62393c: r30 = 1.000000
    //     0x62393c: ldr             lr, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x623940: stp             lr, x16, [SP, #-0x10]!
    // 0x623944: SaveReg rZR
    //     0x623944: str             xzr, [SP, #-8]!
    // 0x623948: r0 = Vector4()
    //     0x623948: bl              #0x623b34  ; [package:vector_math/vector_math_64.dart] Vector4::Vector4
    // 0x62394c: add             SP, SP, #0x28
    // 0x623950: stur            x0, [fp, #-8]
    // 0x623954: ldr             x16, [fp, #0x10]
    // 0x623958: SaveReg r16
    //     0x623958: str             x16, [SP, #-8]!
    // 0x62395c: r0 = Matrix4.copy()
    //     0x62395c: bl              #0x50aa74  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.copy
    // 0x623960: add             SP, SP, #8
    // 0x623964: mov             x3, x0
    // 0x623968: ldur            x2, [fp, #-8]
    // 0x62396c: stur            x3, [fp, #-0x10]
    // 0x623970: LoadField: r4 = r2->field_7
    //     0x623970: ldur            w4, [x2, #7]
    // 0x623974: DecompressPointer r4
    //     0x623974: add             x4, x4, HEAP, lsl #32
    // 0x623978: LoadField: r5 = r3->field_7
    //     0x623978: ldur            w5, [x3, #7]
    // 0x62397c: DecompressPointer r5
    //     0x62397c: add             x5, x5, HEAP, lsl #32
    // 0x623980: LoadField: r0 = r4->field_13
    //     0x623980: ldur            w0, [x4, #0x13]
    // 0x623984: DecompressPointer r0
    //     0x623984: add             x0, x0, HEAP, lsl #32
    // 0x623988: r1 = LoadInt32Instr(r0)
    //     0x623988: sbfx            x1, x0, #1, #0x1f
    // 0x62398c: mov             x0, x1
    // 0x623990: r1 = 3
    //     0x623990: mov             x1, #3
    // 0x623994: cmp             x1, x0
    // 0x623998: b.hs            #0x623a04
    // 0x62399c: LoadField: d0 = r4->field_2f
    //     0x62399c: ldur            d0, [x4, #0x2f]
    // 0x6239a0: LoadField: r0 = r5->field_13
    //     0x6239a0: ldur            w0, [x5, #0x13]
    // 0x6239a4: DecompressPointer r0
    //     0x6239a4: add             x0, x0, HEAP, lsl #32
    // 0x6239a8: r1 = LoadInt32Instr(r0)
    //     0x6239a8: sbfx            x1, x0, #1, #0x1f
    // 0x6239ac: mov             x0, x1
    // 0x6239b0: r1 = 11
    //     0x6239b0: mov             x1, #0xb
    // 0x6239b4: cmp             x1, x0
    // 0x6239b8: b.hs            #0x623a08
    // 0x6239bc: StoreField: r5->field_6f = d0
    //     0x6239bc: stur            d0, [x5, #0x6f]
    // 0x6239c0: LoadField: d0 = r4->field_27
    //     0x6239c0: ldur            d0, [x4, #0x27]
    // 0x6239c4: StoreField: r5->field_67 = d0
    //     0x6239c4: stur            d0, [x5, #0x67]
    // 0x6239c8: LoadField: d0 = r4->field_1f
    //     0x6239c8: ldur            d0, [x4, #0x1f]
    // 0x6239cc: StoreField: r5->field_5f = d0
    //     0x6239cc: stur            d0, [x5, #0x5f]
    // 0x6239d0: LoadField: d0 = r4->field_17
    //     0x6239d0: ldur            d0, [x4, #0x17]
    // 0x6239d4: StoreField: r5->field_57 = d0
    //     0x6239d4: stur            d0, [x5, #0x57]
    // 0x6239d8: SaveReg r3
    //     0x6239d8: str             x3, [SP, #-8]!
    // 0x6239dc: r0 = 2
    //     0x6239dc: mov             x0, #2
    // 0x6239e0: stp             x2, x0, [SP, #-0x10]!
    // 0x6239e4: r0 = setRow()
    //     0x6239e4: bl              #0x623a0c  ; [package:vector_math/vector_math_64.dart] Matrix4::setRow
    // 0x6239e8: add             SP, SP, #0x18
    // 0x6239ec: ldur            x0, [fp, #-0x10]
    // 0x6239f0: LeaveFrame
    //     0x6239f0: mov             SP, fp
    //     0x6239f4: ldp             fp, lr, [SP], #0x10
    // 0x6239f8: ret
    //     0x6239f8: ret             
    // 0x6239fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6239fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x623a00: b               #0x623930
    // 0x623a04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x623a04: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x623a08: r0 = RangeErrorSharedWithFPURegs()
    //     0x623a08: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
  const get _ tilt(/* No info */) {
    // ** addr: 0x6a5bc8, size: 0xc
    // 0x6a5bc8: ldr             x0, [SP]
    // 0x6a5bcc: LoadField: d0 = r0->field_97
    //     0x6a5bcc: ldur            d0, [x0, #0x97]
    // 0x6a5bd0: ret
    //     0x6a5bd0: ret             
  }
  const get _ radiusMax(/* No info */) {
    // ** addr: 0x6a6920, size: 0xc
    // 0x6a6920: ldr             x0, [SP]
    // 0x6a6924: LoadField: d0 = r0->field_87
    //     0x6a6924: ldur            d0, [x0, #0x87]
    // 0x6a6928: ret
    //     0x6a6928: ret             
  }
  const get _ radiusMin(/* No info */) {
    // ** addr: 0x6a91d4, size: 0xc
    // 0x6a91d4: ldr             x0, [SP]
    // 0x6a91d8: LoadField: d0 = r0->field_7f
    //     0x6a91d8: ldur            d0, [x0, #0x7f]
    // 0x6a91dc: ret
    //     0x6a91dc: ret             
  }
  const get _ distanceMax(/* No info */) {
    // ** addr: 0x6b82b4, size: 0xc
    // 0x6b82b4: ldr             x0, [SP]
    // 0x6b82b8: LoadField: d0 = r0->field_5f
    //     0x6b82b8: ldur            d0, [x0, #0x5f]
    // 0x6b82bc: ret
    //     0x6b82bc: ret             
  }
  const get _ orientation(/* No info */) {
    // ** addr: 0x6ba7bc, size: 0xc
    // 0x6ba7bc: ldr             x0, [SP]
    // 0x6ba7c0: LoadField: d0 = r0->field_8f
    //     0x6ba7c0: ldur            d0, [x0, #0x8f]
    // 0x6ba7c4: ret
    //     0x6ba7c4: ret             
  }
  const get _ size(/* No info */) {
    // ** addr: 0x6ba7c8, size: 0xc
    // 0x6ba7c8: ldr             x0, [SP]
    // 0x6ba7cc: LoadField: d0 = r0->field_67
    //     0x6ba7cc: ldur            d0, [x0, #0x67]
    // 0x6ba7d0: ret
    //     0x6ba7d0: ret             
  }
  const get _ pressureMin(/* No info */) {
    // ** addr: 0x6bb378, size: 0xc
    // 0x6bb378: ldr             x0, [SP]
    // 0x6bb37c: LoadField: d0 = r0->field_47
    //     0x6bb37c: ldur            d0, [x0, #0x47]
    // 0x6bb380: ret
    //     0x6bb380: ret             
  }
  const get _ radiusMinor(/* No info */) {
    // ** addr: 0x6bb384, size: 0xc
    // 0x6bb384: ldr             x0, [SP]
    // 0x6bb388: LoadField: d0 = r0->field_77
    //     0x6bb388: ldur            d0, [x0, #0x77]
    // 0x6bb38c: ret
    //     0x6bb38c: ret             
  }
  const get _ radiusMajor(/* No info */) {
    // ** addr: 0x6fb15c, size: 0xc
    // 0x6fb15c: ldr             x0, [SP]
    // 0x6fb160: LoadField: d0 = r0->field_6f
    //     0x6fb160: ldur            d0, [x0, #0x6f]
    // 0x6fb164: ret
    //     0x6fb164: ret             
  }
  const get _ pressureMax(/* No info */) {
    // ** addr: 0x6fb168, size: 0xc
    // 0x6fb168: ldr             x0, [SP]
    // 0x6fb16c: LoadField: d0 = r0->field_4f
    //     0x6fb16c: ldur            d0, [x0, #0x4f]
    // 0x6fb170: ret
    //     0x6fb170: ret             
  }
  const get _ original(/* No info */) {
    // ** addr: 0xc825b4, size: 0x10
    // 0xc825b4: ldr             x1, [SP]
    // 0xc825b8: LoadField: r0 = r1->field_af
    //     0xc825b8: ldur            w0, [x1, #0xaf]
    // 0xc825bc: DecompressPointer r0
    //     0xc825bc: add             x0, x0, HEAP, lsl #32
    // 0xc825c0: ret
    //     0xc825c0: ret             
  }
}

// class id: 2845, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerCancelEvent extends PointerEvent {
}

// class id: 2846, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerPanZoomEndEvent extends PointerEvent {
}

// class id: 2847, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerPanZoomUpdateEvent extends PointerEvent {
}

// class id: 2848, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerPanZoomStartEvent extends PointerEvent {
}

// class id: 2849, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerScaleEvent extends PointerEvent {
}

// class id: 2850, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerScrollInertiaCancelEvent extends PointerEvent {
}

// class id: 2851, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerScrollEvent extends PointerEvent {
}

// class id: 2852, size: 0xb4, field offset: 0xb4
//   const constructor, 
abstract class PointerSignalEvent extends PointerEvent {
}

// class id: 2853, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerScrollEvent&PointerSignalEvent&_PointerEventDescription extends PointerSignalEvent
     with _PointerEventDescription {
}

// class id: 2854, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerScaleEvent&PointerSignalEvent&_PointerEventDescription&_CopyPointerScaleEvent extends _PointerScrollEvent&PointerSignalEvent&_PointerEventDescription
     with _CopyPointerScaleEvent {
}

// class id: 2855, size: 0xbc, field offset: 0xb4
//   const constructor, 
class PointerScaleEvent extends _PointerScaleEvent&PointerSignalEvent&_PointerEventDescription&_CopyPointerScaleEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5b68, size: 0x54
    // 0x6a5b68: EnterFrame
    //     0x6a5b68: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5b6c: mov             fp, SP
    // 0x6a5b70: ldr             x0, [fp, #0x10]
    // 0x6a5b74: cmp             w0, NULL
    // 0x6a5b78: b.ne            #0x6a5b8c
    // 0x6a5b7c: ldr             x0, [fp, #0x18]
    // 0x6a5b80: LeaveFrame
    //     0x6a5b80: mov             SP, fp
    //     0x6a5b84: ldp             fp, lr, [SP], #0x10
    // 0x6a5b88: ret
    //     0x6a5b88: ret             
    // 0x6a5b8c: ldr             x1, [fp, #0x18]
    // 0x6a5b90: r0 = _TransformedPointerScaleEvent()
    //     0x6a5b90: bl              #0x6a5bbc  ; Allocate_TransformedPointerScaleEventStub -> _TransformedPointerScaleEvent (size=0x18)
    // 0x6a5b94: ldr             x1, [fp, #0x18]
    // 0x6a5b98: StoreField: r0->field_f = r1
    //     0x6a5b98: stur            w1, [x0, #0xf]
    // 0x6a5b9c: ldr             x1, [fp, #0x10]
    // 0x6a5ba0: StoreField: r0->field_13 = r1
    //     0x6a5ba0: stur            w1, [x0, #0x13]
    // 0x6a5ba4: r1 = Sentinel
    //     0x6a5ba4: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5ba8: StoreField: r0->field_7 = r1
    //     0x6a5ba8: stur            w1, [x0, #7]
    // 0x6a5bac: StoreField: r0->field_b = r1
    //     0x6a5bac: stur            w1, [x0, #0xb]
    // 0x6a5bb0: LeaveFrame
    //     0x6a5bb0: mov             SP, fp
    //     0x6a5bb4: ldp             fp, lr, [SP], #0x10
    // 0x6a5bb8: ret
    //     0x6a5bb8: ret             
  }
}

// class id: 2856, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerScrollInertiaCancelEvent&PointerSignalEvent&_PointerEventDescription&_CopyPointerScrollInertiaCancelEvent extends _PointerScrollEvent&PointerSignalEvent&_PointerEventDescription
     with _CopyPointerScrollInertiaCancelEvent {
}

// class id: 2857, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerScrollInertiaCancelEvent extends _PointerScrollInertiaCancelEvent&PointerSignalEvent&_PointerEventDescription&_CopyPointerScrollInertiaCancelEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5b08, size: 0x54
    // 0x6a5b08: EnterFrame
    //     0x6a5b08: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5b0c: mov             fp, SP
    // 0x6a5b10: ldr             x0, [fp, #0x10]
    // 0x6a5b14: cmp             w0, NULL
    // 0x6a5b18: b.ne            #0x6a5b2c
    // 0x6a5b1c: ldr             x0, [fp, #0x18]
    // 0x6a5b20: LeaveFrame
    //     0x6a5b20: mov             SP, fp
    //     0x6a5b24: ldp             fp, lr, [SP], #0x10
    // 0x6a5b28: ret
    //     0x6a5b28: ret             
    // 0x6a5b2c: ldr             x1, [fp, #0x18]
    // 0x6a5b30: r0 = _TransformedPointerScrollInertiaCancelEvent()
    //     0x6a5b30: bl              #0x6a5b5c  ; Allocate_TransformedPointerScrollInertiaCancelEventStub -> _TransformedPointerScrollInertiaCancelEvent (size=0x18)
    // 0x6a5b34: ldr             x1, [fp, #0x18]
    // 0x6a5b38: StoreField: r0->field_f = r1
    //     0x6a5b38: stur            w1, [x0, #0xf]
    // 0x6a5b3c: ldr             x1, [fp, #0x10]
    // 0x6a5b40: StoreField: r0->field_13 = r1
    //     0x6a5b40: stur            w1, [x0, #0x13]
    // 0x6a5b44: r1 = Sentinel
    //     0x6a5b44: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5b48: StoreField: r0->field_7 = r1
    //     0x6a5b48: stur            w1, [x0, #7]
    // 0x6a5b4c: StoreField: r0->field_b = r1
    //     0x6a5b4c: stur            w1, [x0, #0xb]
    // 0x6a5b50: LeaveFrame
    //     0x6a5b50: mov             SP, fp
    //     0x6a5b54: ldp             fp, lr, [SP], #0x10
    // 0x6a5b58: ret
    //     0x6a5b58: ret             
  }
}

// class id: 2858, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerScrollEvent&PointerSignalEvent&_PointerEventDescription&_CopyPointerScrollEvent extends _PointerScrollEvent&PointerSignalEvent&_PointerEventDescription
     with _CopyPointerScrollEvent {
}

// class id: 2859, size: 0xb8, field offset: 0xb4
//   const constructor, 
class PointerScrollEvent extends _PointerScrollEvent&PointerSignalEvent&_PointerEventDescription&_CopyPointerScrollEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5aa8, size: 0x54
    // 0x6a5aa8: EnterFrame
    //     0x6a5aa8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5aac: mov             fp, SP
    // 0x6a5ab0: ldr             x0, [fp, #0x10]
    // 0x6a5ab4: cmp             w0, NULL
    // 0x6a5ab8: b.ne            #0x6a5acc
    // 0x6a5abc: ldr             x0, [fp, #0x18]
    // 0x6a5ac0: LeaveFrame
    //     0x6a5ac0: mov             SP, fp
    //     0x6a5ac4: ldp             fp, lr, [SP], #0x10
    // 0x6a5ac8: ret
    //     0x6a5ac8: ret             
    // 0x6a5acc: ldr             x1, [fp, #0x18]
    // 0x6a5ad0: r0 = _TransformedPointerScrollEvent()
    //     0x6a5ad0: bl              #0x6a5afc  ; Allocate_TransformedPointerScrollEventStub -> _TransformedPointerScrollEvent (size=0x18)
    // 0x6a5ad4: ldr             x1, [fp, #0x18]
    // 0x6a5ad8: StoreField: r0->field_f = r1
    //     0x6a5ad8: stur            w1, [x0, #0xf]
    // 0x6a5adc: ldr             x1, [fp, #0x10]
    // 0x6a5ae0: StoreField: r0->field_13 = r1
    //     0x6a5ae0: stur            w1, [x0, #0x13]
    // 0x6a5ae4: r1 = Sentinel
    //     0x6a5ae4: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5ae8: StoreField: r0->field_7 = r1
    //     0x6a5ae8: stur            w1, [x0, #7]
    // 0x6a5aec: StoreField: r0->field_b = r1
    //     0x6a5aec: stur            w1, [x0, #0xb]
    // 0x6a5af0: LeaveFrame
    //     0x6a5af0: mov             SP, fp
    //     0x6a5af4: ldp             fp, lr, [SP], #0x10
    // 0x6a5af8: ret
    //     0x6a5af8: ret             
  }
  const get _ scrollDelta(/* No info */) {
    // ** addr: 0xcebc90, size: 0x10
    // 0xcebc90: ldr             x1, [SP]
    // 0xcebc94: LoadField: r0 = r1->field_b3
    //     0xcebc94: ldur            w0, [x1, #0xb3]
    // 0xcebc98: DecompressPointer r0
    //     0xcebc98: add             x0, x0, HEAP, lsl #32
    // 0xcebc9c: ret
    //     0xcebc9c: ret             
  }
}

// class id: 2860, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerUpEvent extends PointerEvent {
}

// class id: 2861, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerMoveEvent extends PointerEvent {
}

// class id: 2862, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerDownEvent extends PointerEvent {
}

// class id: 2863, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerExitEvent extends PointerEvent {
}

// class id: 2864, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerEnterEvent extends PointerEvent {
}

// class id: 2865, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerHoverEvent extends PointerEvent {
}

// class id: 2866, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerRemovedEvent extends PointerEvent {
}

// class id: 2867, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerAddedEvent&PointerEvent&_PointerEventDescription extends PointerEvent
     with _PointerEventDescription {
}

// class id: 2868, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerCancelEvent&PointerEvent&_PointerEventDescription&_CopyPointerCancelEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerCancelEvent {
}

// class id: 2869, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerCancelEvent extends _PointerCancelEvent&PointerEvent&_PointerEventDescription&_CopyPointerCancelEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5a48, size: 0x54
    // 0x6a5a48: EnterFrame
    //     0x6a5a48: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5a4c: mov             fp, SP
    // 0x6a5a50: ldr             x0, [fp, #0x10]
    // 0x6a5a54: cmp             w0, NULL
    // 0x6a5a58: b.ne            #0x6a5a6c
    // 0x6a5a5c: ldr             x0, [fp, #0x18]
    // 0x6a5a60: LeaveFrame
    //     0x6a5a60: mov             SP, fp
    //     0x6a5a64: ldp             fp, lr, [SP], #0x10
    // 0x6a5a68: ret
    //     0x6a5a68: ret             
    // 0x6a5a6c: ldr             x1, [fp, #0x18]
    // 0x6a5a70: r0 = _TransformedPointerCancelEvent()
    //     0x6a5a70: bl              #0x6a5a9c  ; Allocate_TransformedPointerCancelEventStub -> _TransformedPointerCancelEvent (size=0x18)
    // 0x6a5a74: ldr             x1, [fp, #0x18]
    // 0x6a5a78: StoreField: r0->field_f = r1
    //     0x6a5a78: stur            w1, [x0, #0xf]
    // 0x6a5a7c: ldr             x1, [fp, #0x10]
    // 0x6a5a80: StoreField: r0->field_13 = r1
    //     0x6a5a80: stur            w1, [x0, #0x13]
    // 0x6a5a84: r1 = Sentinel
    //     0x6a5a84: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5a88: StoreField: r0->field_7 = r1
    //     0x6a5a88: stur            w1, [x0, #7]
    // 0x6a5a8c: StoreField: r0->field_b = r1
    //     0x6a5a8c: stur            w1, [x0, #0xb]
    // 0x6a5a90: LeaveFrame
    //     0x6a5a90: mov             SP, fp
    //     0x6a5a94: ldp             fp, lr, [SP], #0x10
    // 0x6a5a98: ret
    //     0x6a5a98: ret             
  }
}

// class id: 2870, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerPanZoomEndEvent&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomEndEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerPanZoomEndEvent {
}

// class id: 2871, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerPanZoomEndEvent extends _PointerPanZoomEndEvent&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomEndEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a59e8, size: 0x54
    // 0x6a59e8: EnterFrame
    //     0x6a59e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6a59ec: mov             fp, SP
    // 0x6a59f0: ldr             x0, [fp, #0x10]
    // 0x6a59f4: cmp             w0, NULL
    // 0x6a59f8: b.ne            #0x6a5a0c
    // 0x6a59fc: ldr             x0, [fp, #0x18]
    // 0x6a5a00: LeaveFrame
    //     0x6a5a00: mov             SP, fp
    //     0x6a5a04: ldp             fp, lr, [SP], #0x10
    // 0x6a5a08: ret
    //     0x6a5a08: ret             
    // 0x6a5a0c: ldr             x1, [fp, #0x18]
    // 0x6a5a10: r0 = _TransformedPointerPanZoomEndEvent()
    //     0x6a5a10: bl              #0x6a5a3c  ; Allocate_TransformedPointerPanZoomEndEventStub -> _TransformedPointerPanZoomEndEvent (size=0x18)
    // 0x6a5a14: ldr             x1, [fp, #0x18]
    // 0x6a5a18: StoreField: r0->field_f = r1
    //     0x6a5a18: stur            w1, [x0, #0xf]
    // 0x6a5a1c: ldr             x1, [fp, #0x10]
    // 0x6a5a20: StoreField: r0->field_13 = r1
    //     0x6a5a20: stur            w1, [x0, #0x13]
    // 0x6a5a24: r1 = Sentinel
    //     0x6a5a24: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5a28: StoreField: r0->field_7 = r1
    //     0x6a5a28: stur            w1, [x0, #7]
    // 0x6a5a2c: StoreField: r0->field_b = r1
    //     0x6a5a2c: stur            w1, [x0, #0xb]
    // 0x6a5a30: LeaveFrame
    //     0x6a5a30: mov             SP, fp
    //     0x6a5a34: ldp             fp, lr, [SP], #0x10
    // 0x6a5a38: ret
    //     0x6a5a38: ret             
  }
}

// class id: 2872, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerPanZoomUpdateEvent&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomUpdateEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerPanZoomUpdateEvent {
}

// class id: 2873, size: 0xcc, field offset: 0xb4
//   const constructor, 
class PointerPanZoomUpdateEvent extends _PointerPanZoomUpdateEvent&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomUpdateEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5980, size: 0x5c
    // 0x6a5980: EnterFrame
    //     0x6a5980: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5984: mov             fp, SP
    // 0x6a5988: ldr             x0, [fp, #0x10]
    // 0x6a598c: cmp             w0, NULL
    // 0x6a5990: b.ne            #0x6a59a4
    // 0x6a5994: ldr             x0, [fp, #0x18]
    // 0x6a5998: LeaveFrame
    //     0x6a5998: mov             SP, fp
    //     0x6a599c: ldp             fp, lr, [SP], #0x10
    // 0x6a59a0: ret
    //     0x6a59a0: ret             
    // 0x6a59a4: ldr             x1, [fp, #0x18]
    // 0x6a59a8: r0 = _TransformedPointerPanZoomUpdateEvent()
    //     0x6a59a8: bl              #0x6a59dc  ; Allocate_TransformedPointerPanZoomUpdateEventStub -> _TransformedPointerPanZoomUpdateEvent (size=0x20)
    // 0x6a59ac: r1 = Sentinel
    //     0x6a59ac: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a59b0: StoreField: r0->field_f = r1
    //     0x6a59b0: stur            w1, [x0, #0xf]
    // 0x6a59b4: StoreField: r0->field_13 = r1
    //     0x6a59b4: stur            w1, [x0, #0x13]
    // 0x6a59b8: ldr             x2, [fp, #0x18]
    // 0x6a59bc: StoreField: r0->field_17 = r2
    //     0x6a59bc: stur            w2, [x0, #0x17]
    // 0x6a59c0: ldr             x2, [fp, #0x10]
    // 0x6a59c4: StoreField: r0->field_1b = r2
    //     0x6a59c4: stur            w2, [x0, #0x1b]
    // 0x6a59c8: StoreField: r0->field_7 = r1
    //     0x6a59c8: stur            w1, [x0, #7]
    // 0x6a59cc: StoreField: r0->field_b = r1
    //     0x6a59cc: stur            w1, [x0, #0xb]
    // 0x6a59d0: LeaveFrame
    //     0x6a59d0: mov             SP, fp
    //     0x6a59d4: ldp             fp, lr, [SP], #0x10
    // 0x6a59d8: ret
    //     0x6a59d8: ret             
  }
  const get _ rotation(/* No info */) {
    // ** addr: 0xcebc68, size: 0xc
    // 0xcebc68: ldr             x0, [SP]
    // 0xcebc6c: LoadField: d0 = r0->field_c3
    //     0xcebc6c: ldur            d0, [x0, #0xc3]
    // 0xcebc70: ret
    //     0xcebc70: ret             
  }
  const get _ scale(/* No info */) {
    // ** addr: 0xcebc74, size: 0xc
    // 0xcebc74: ldr             x0, [SP]
    // 0xcebc78: LoadField: d0 = r0->field_bb
    //     0xcebc78: ldur            d0, [x0, #0xbb]
    // 0xcebc7c: ret
    //     0xcebc7c: ret             
  }
  const get _ panDelta(/* No info */) {
    // ** addr: 0xcebc80, size: 0x10
    // 0xcebc80: ldr             x1, [SP]
    // 0xcebc84: LoadField: r0 = r1->field_b7
    //     0xcebc84: ldur            w0, [x1, #0xb7]
    // 0xcebc88: DecompressPointer r0
    //     0xcebc88: add             x0, x0, HEAP, lsl #32
    // 0xcebc8c: ret
    //     0xcebc8c: ret             
  }
}

// class id: 2874, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerPanZoomStartEvent&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomStartEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerPanZoomStartEvent {
}

// class id: 2875, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerPanZoomStartEvent extends _PointerPanZoomStartEvent&PointerEvent&_PointerEventDescription&_CopyPointerPanZoomStartEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5920, size: 0x54
    // 0x6a5920: EnterFrame
    //     0x6a5920: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5924: mov             fp, SP
    // 0x6a5928: ldr             x0, [fp, #0x10]
    // 0x6a592c: cmp             w0, NULL
    // 0x6a5930: b.ne            #0x6a5944
    // 0x6a5934: ldr             x0, [fp, #0x18]
    // 0x6a5938: LeaveFrame
    //     0x6a5938: mov             SP, fp
    //     0x6a593c: ldp             fp, lr, [SP], #0x10
    // 0x6a5940: ret
    //     0x6a5940: ret             
    // 0x6a5944: ldr             x1, [fp, #0x18]
    // 0x6a5948: r0 = _TransformedPointerPanZoomStartEvent()
    //     0x6a5948: bl              #0x6a5974  ; Allocate_TransformedPointerPanZoomStartEventStub -> _TransformedPointerPanZoomStartEvent (size=0x18)
    // 0x6a594c: ldr             x1, [fp, #0x18]
    // 0x6a5950: StoreField: r0->field_f = r1
    //     0x6a5950: stur            w1, [x0, #0xf]
    // 0x6a5954: ldr             x1, [fp, #0x10]
    // 0x6a5958: StoreField: r0->field_13 = r1
    //     0x6a5958: stur            w1, [x0, #0x13]
    // 0x6a595c: r1 = Sentinel
    //     0x6a595c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5960: StoreField: r0->field_7 = r1
    //     0x6a5960: stur            w1, [x0, #7]
    // 0x6a5964: StoreField: r0->field_b = r1
    //     0x6a5964: stur            w1, [x0, #0xb]
    // 0x6a5968: LeaveFrame
    //     0x6a5968: mov             SP, fp
    //     0x6a596c: ldp             fp, lr, [SP], #0x10
    // 0x6a5970: ret
    //     0x6a5970: ret             
  }
}

// class id: 2876, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerUpEvent&PointerEvent&_PointerEventDescription&_CopyPointerUpEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerUpEvent {
}

// class id: 2877, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerUpEvent extends _PointerUpEvent&PointerEvent&_PointerEventDescription&_CopyPointerUpEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a58c0, size: 0x54
    // 0x6a58c0: EnterFrame
    //     0x6a58c0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a58c4: mov             fp, SP
    // 0x6a58c8: ldr             x0, [fp, #0x10]
    // 0x6a58cc: cmp             w0, NULL
    // 0x6a58d0: b.ne            #0x6a58e4
    // 0x6a58d4: ldr             x0, [fp, #0x18]
    // 0x6a58d8: LeaveFrame
    //     0x6a58d8: mov             SP, fp
    //     0x6a58dc: ldp             fp, lr, [SP], #0x10
    // 0x6a58e0: ret
    //     0x6a58e0: ret             
    // 0x6a58e4: ldr             x1, [fp, #0x18]
    // 0x6a58e8: r0 = _TransformedPointerUpEvent()
    //     0x6a58e8: bl              #0x6a5914  ; Allocate_TransformedPointerUpEventStub -> _TransformedPointerUpEvent (size=0x18)
    // 0x6a58ec: ldr             x1, [fp, #0x18]
    // 0x6a58f0: StoreField: r0->field_f = r1
    //     0x6a58f0: stur            w1, [x0, #0xf]
    // 0x6a58f4: ldr             x1, [fp, #0x10]
    // 0x6a58f8: StoreField: r0->field_13 = r1
    //     0x6a58f8: stur            w1, [x0, #0x13]
    // 0x6a58fc: r1 = Sentinel
    //     0x6a58fc: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5900: StoreField: r0->field_7 = r1
    //     0x6a5900: stur            w1, [x0, #7]
    // 0x6a5904: StoreField: r0->field_b = r1
    //     0x6a5904: stur            w1, [x0, #0xb]
    // 0x6a5908: LeaveFrame
    //     0x6a5908: mov             SP, fp
    //     0x6a590c: ldp             fp, lr, [SP], #0x10
    // 0x6a5910: ret
    //     0x6a5910: ret             
  }
}

// class id: 2878, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerMoveEvent&PointerEvent&_PointerEventDescription&_CopyPointerMoveEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerMoveEvent {
}

// class id: 2879, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerMoveEvent extends _PointerMoveEvent&PointerEvent&_PointerEventDescription&_CopyPointerMoveEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5860, size: 0x54
    // 0x6a5860: EnterFrame
    //     0x6a5860: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5864: mov             fp, SP
    // 0x6a5868: ldr             x0, [fp, #0x10]
    // 0x6a586c: cmp             w0, NULL
    // 0x6a5870: b.ne            #0x6a5884
    // 0x6a5874: ldr             x0, [fp, #0x18]
    // 0x6a5878: LeaveFrame
    //     0x6a5878: mov             SP, fp
    //     0x6a587c: ldp             fp, lr, [SP], #0x10
    // 0x6a5880: ret
    //     0x6a5880: ret             
    // 0x6a5884: ldr             x1, [fp, #0x18]
    // 0x6a5888: r0 = _TransformedPointerMoveEvent()
    //     0x6a5888: bl              #0x6a58b4  ; Allocate_TransformedPointerMoveEventStub -> _TransformedPointerMoveEvent (size=0x18)
    // 0x6a588c: ldr             x1, [fp, #0x18]
    // 0x6a5890: StoreField: r0->field_f = r1
    //     0x6a5890: stur            w1, [x0, #0xf]
    // 0x6a5894: ldr             x1, [fp, #0x10]
    // 0x6a5898: StoreField: r0->field_13 = r1
    //     0x6a5898: stur            w1, [x0, #0x13]
    // 0x6a589c: r1 = Sentinel
    //     0x6a589c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a58a0: StoreField: r0->field_7 = r1
    //     0x6a58a0: stur            w1, [x0, #7]
    // 0x6a58a4: StoreField: r0->field_b = r1
    //     0x6a58a4: stur            w1, [x0, #0xb]
    // 0x6a58a8: LeaveFrame
    //     0x6a58a8: mov             SP, fp
    //     0x6a58ac: ldp             fp, lr, [SP], #0x10
    // 0x6a58b0: ret
    //     0x6a58b0: ret             
  }
}

// class id: 2880, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerDownEvent&PointerEvent&_PointerEventDescription&_CopyPointerDownEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerDownEvent {
}

// class id: 2881, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerDownEvent extends _PointerDownEvent&PointerEvent&_PointerEventDescription&_CopyPointerDownEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5800, size: 0x54
    // 0x6a5800: EnterFrame
    //     0x6a5800: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5804: mov             fp, SP
    // 0x6a5808: ldr             x0, [fp, #0x10]
    // 0x6a580c: cmp             w0, NULL
    // 0x6a5810: b.ne            #0x6a5824
    // 0x6a5814: ldr             x0, [fp, #0x18]
    // 0x6a5818: LeaveFrame
    //     0x6a5818: mov             SP, fp
    //     0x6a581c: ldp             fp, lr, [SP], #0x10
    // 0x6a5820: ret
    //     0x6a5820: ret             
    // 0x6a5824: ldr             x1, [fp, #0x18]
    // 0x6a5828: r0 = _TransformedPointerDownEvent()
    //     0x6a5828: bl              #0x6a5854  ; Allocate_TransformedPointerDownEventStub -> _TransformedPointerDownEvent (size=0x18)
    // 0x6a582c: ldr             x1, [fp, #0x18]
    // 0x6a5830: StoreField: r0->field_f = r1
    //     0x6a5830: stur            w1, [x0, #0xf]
    // 0x6a5834: ldr             x1, [fp, #0x10]
    // 0x6a5838: StoreField: r0->field_13 = r1
    //     0x6a5838: stur            w1, [x0, #0x13]
    // 0x6a583c: r1 = Sentinel
    //     0x6a583c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5840: StoreField: r0->field_7 = r1
    //     0x6a5840: stur            w1, [x0, #7]
    // 0x6a5844: StoreField: r0->field_b = r1
    //     0x6a5844: stur            w1, [x0, #0xb]
    // 0x6a5848: LeaveFrame
    //     0x6a5848: mov             SP, fp
    //     0x6a584c: ldp             fp, lr, [SP], #0x10
    // 0x6a5850: ret
    //     0x6a5850: ret             
  }
}

// class id: 2882, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerExitEvent&PointerEvent&_PointerEventDescription&_CopyPointerExitEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerExitEvent {
}

// class id: 2883, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerExitEvent extends _PointerExitEvent&PointerEvent&_PointerEventDescription&_CopyPointerExitEvent {

  factory _ PointerExitEvent.fromMouseEvent(/* No info */) {
    // ** addr: 0x50d228, size: 0x48c
    // 0x50d228: EnterFrame
    //     0x50d228: stp             fp, lr, [SP, #-0x10]!
    //     0x50d22c: mov             fp, SP
    // 0x50d230: AllocStack(0xb0)
    //     0x50d230: sub             SP, SP, #0xb0
    // 0x50d234: CheckStackOverflow
    //     0x50d234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50d238: cmp             SP, x16
    //     0x50d23c: b.ls            #0x50d6ac
    // 0x50d240: ldr             x1, [fp, #0x10]
    // 0x50d244: r0 = LoadClassIdInstr(r1)
    //     0x50d244: ldur            x0, [x1, #-1]
    //     0x50d248: ubfx            x0, x0, #0xc, #0x14
    // 0x50d24c: SaveReg r1
    //     0x50d24c: str             x1, [SP, #-8]!
    // 0x50d250: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x50d250: sub             lr, x0, #0xf3a
    //     0x50d254: ldr             lr, [x21, lr, lsl #3]
    //     0x50d258: blr             lr
    // 0x50d25c: add             SP, SP, #8
    // 0x50d260: mov             x2, x0
    // 0x50d264: ldr             x1, [fp, #0x10]
    // 0x50d268: stur            x2, [fp, #-8]
    // 0x50d26c: r0 = LoadClassIdInstr(r1)
    //     0x50d26c: ldur            x0, [x1, #-1]
    //     0x50d270: ubfx            x0, x0, #0xc, #0x14
    // 0x50d274: SaveReg r1
    //     0x50d274: str             x1, [SP, #-8]!
    // 0x50d278: r0 = GDT[cid_x0 + -0xfff]()
    //     0x50d278: sub             lr, x0, #0xfff
    //     0x50d27c: ldr             lr, [x21, lr, lsl #3]
    //     0x50d280: blr             lr
    // 0x50d284: add             SP, SP, #8
    // 0x50d288: mov             x2, x0
    // 0x50d28c: ldr             x1, [fp, #0x10]
    // 0x50d290: stur            x2, [fp, #-0x10]
    // 0x50d294: r0 = LoadClassIdInstr(r1)
    //     0x50d294: ldur            x0, [x1, #-1]
    //     0x50d298: ubfx            x0, x0, #0xc, #0x14
    // 0x50d29c: SaveReg r1
    //     0x50d29c: str             x1, [SP, #-8]!
    // 0x50d2a0: r0 = GDT[cid_x0 + -0xf60]()
    //     0x50d2a0: sub             lr, x0, #0xf60
    //     0x50d2a4: ldr             lr, [x21, lr, lsl #3]
    //     0x50d2a8: blr             lr
    // 0x50d2ac: add             SP, SP, #8
    // 0x50d2b0: mov             x2, x0
    // 0x50d2b4: ldr             x1, [fp, #0x10]
    // 0x50d2b8: stur            x2, [fp, #-0x18]
    // 0x50d2bc: r0 = LoadClassIdInstr(r1)
    //     0x50d2bc: ldur            x0, [x1, #-1]
    //     0x50d2c0: ubfx            x0, x0, #0xc, #0x14
    // 0x50d2c4: SaveReg r1
    //     0x50d2c4: str             x1, [SP, #-8]!
    // 0x50d2c8: r0 = GDT[cid_x0 + 0x8864]()
    //     0x50d2c8: mov             x17, #0x8864
    //     0x50d2cc: add             lr, x0, x17
    //     0x50d2d0: ldr             lr, [x21, lr, lsl #3]
    //     0x50d2d4: blr             lr
    // 0x50d2d8: add             SP, SP, #8
    // 0x50d2dc: mov             x2, x0
    // 0x50d2e0: ldr             x1, [fp, #0x10]
    // 0x50d2e4: stur            x2, [fp, #-0x20]
    // 0x50d2e8: r0 = LoadClassIdInstr(r1)
    //     0x50d2e8: ldur            x0, [x1, #-1]
    //     0x50d2ec: ubfx            x0, x0, #0xc, #0x14
    // 0x50d2f0: SaveReg r1
    //     0x50d2f0: str             x1, [SP, #-8]!
    // 0x50d2f4: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x50d2f4: sub             lr, x0, #0xfd9
    //     0x50d2f8: ldr             lr, [x21, lr, lsl #3]
    //     0x50d2fc: blr             lr
    // 0x50d300: add             SP, SP, #8
    // 0x50d304: mov             x2, x0
    // 0x50d308: ldr             x1, [fp, #0x10]
    // 0x50d30c: stur            x2, [fp, #-0x28]
    // 0x50d310: r0 = LoadClassIdInstr(r1)
    //     0x50d310: ldur            x0, [x1, #-1]
    //     0x50d314: ubfx            x0, x0, #0xc, #0x14
    // 0x50d318: SaveReg r1
    //     0x50d318: str             x1, [SP, #-8]!
    // 0x50d31c: r0 = GDT[cid_x0 + 0x9887]()
    //     0x50d31c: mov             x17, #0x9887
    //     0x50d320: add             lr, x0, x17
    //     0x50d324: ldr             lr, [x21, lr, lsl #3]
    //     0x50d328: blr             lr
    // 0x50d32c: add             SP, SP, #8
    // 0x50d330: mov             x2, x0
    // 0x50d334: ldr             x1, [fp, #0x10]
    // 0x50d338: stur            x2, [fp, #-0x30]
    // 0x50d33c: r0 = LoadClassIdInstr(r1)
    //     0x50d33c: ldur            x0, [x1, #-1]
    //     0x50d340: ubfx            x0, x0, #0xc, #0x14
    // 0x50d344: SaveReg r1
    //     0x50d344: str             x1, [SP, #-8]!
    // 0x50d348: r0 = GDT[cid_x0 + 0x271c]()
    //     0x50d348: mov             x17, #0x271c
    //     0x50d34c: add             lr, x0, x17
    //     0x50d350: ldr             lr, [x21, lr, lsl #3]
    //     0x50d354: blr             lr
    // 0x50d358: add             SP, SP, #8
    // 0x50d35c: mov             x2, x0
    // 0x50d360: ldr             x1, [fp, #0x10]
    // 0x50d364: stur            x2, [fp, #-0x38]
    // 0x50d368: r0 = LoadClassIdInstr(r1)
    //     0x50d368: ldur            x0, [x1, #-1]
    //     0x50d36c: ubfx            x0, x0, #0xc, #0x14
    // 0x50d370: SaveReg r1
    //     0x50d370: str             x1, [SP, #-8]!
    // 0x50d374: r0 = GDT[cid_x0 + 0xd6b9]()
    //     0x50d374: mov             x17, #0xd6b9
    //     0x50d378: add             lr, x0, x17
    //     0x50d37c: ldr             lr, [x21, lr, lsl #3]
    //     0x50d380: blr             lr
    // 0x50d384: add             SP, SP, #8
    // 0x50d388: mov             x2, x0
    // 0x50d38c: ldr             x1, [fp, #0x10]
    // 0x50d390: stur            x2, [fp, #-0x40]
    // 0x50d394: r0 = LoadClassIdInstr(r1)
    //     0x50d394: ldur            x0, [x1, #-1]
    //     0x50d398: ubfx            x0, x0, #0xc, #0x14
    // 0x50d39c: SaveReg r1
    //     0x50d39c: str             x1, [SP, #-8]!
    // 0x50d3a0: r0 = GDT[cid_x0 + 0xd50a]()
    //     0x50d3a0: mov             x17, #0xd50a
    //     0x50d3a4: add             lr, x0, x17
    //     0x50d3a8: ldr             lr, [x21, lr, lsl #3]
    //     0x50d3ac: blr             lr
    // 0x50d3b0: add             SP, SP, #8
    // 0x50d3b4: ldr             x1, [fp, #0x10]
    // 0x50d3b8: stur            d0, [fp, #-0x60]
    // 0x50d3bc: r0 = LoadClassIdInstr(r1)
    //     0x50d3bc: ldur            x0, [x1, #-1]
    //     0x50d3c0: ubfx            x0, x0, #0xc, #0x14
    // 0x50d3c4: SaveReg r1
    //     0x50d3c4: str             x1, [SP, #-8]!
    // 0x50d3c8: r0 = GDT[cid_x0 + 0xc61f]()
    //     0x50d3c8: mov             x17, #0xc61f
    //     0x50d3cc: add             lr, x0, x17
    //     0x50d3d0: ldr             lr, [x21, lr, lsl #3]
    //     0x50d3d4: blr             lr
    // 0x50d3d8: add             SP, SP, #8
    // 0x50d3dc: ldr             x1, [fp, #0x10]
    // 0x50d3e0: stur            d0, [fp, #-0x68]
    // 0x50d3e4: r0 = LoadClassIdInstr(r1)
    //     0x50d3e4: ldur            x0, [x1, #-1]
    //     0x50d3e8: ubfx            x0, x0, #0xc, #0x14
    // 0x50d3ec: SaveReg r1
    //     0x50d3ec: str             x1, [SP, #-8]!
    // 0x50d3f0: r0 = GDT[cid_x0 + 0x102da]()
    //     0x50d3f0: mov             x17, #0x2da
    //     0x50d3f4: movk            x17, #1, lsl #16
    //     0x50d3f8: add             lr, x0, x17
    //     0x50d3fc: ldr             lr, [x21, lr, lsl #3]
    //     0x50d400: blr             lr
    // 0x50d404: add             SP, SP, #8
    // 0x50d408: ldr             x1, [fp, #0x10]
    // 0x50d40c: stur            d0, [fp, #-0x70]
    // 0x50d410: r0 = LoadClassIdInstr(r1)
    //     0x50d410: ldur            x0, [x1, #-1]
    //     0x50d414: ubfx            x0, x0, #0xc, #0x14
    // 0x50d418: SaveReg r1
    //     0x50d418: str             x1, [SP, #-8]!
    // 0x50d41c: r0 = GDT[cid_x0 + 0xd714]()
    //     0x50d41c: mov             x17, #0xd714
    //     0x50d420: add             lr, x0, x17
    //     0x50d424: ldr             lr, [x21, lr, lsl #3]
    //     0x50d428: blr             lr
    // 0x50d42c: add             SP, SP, #8
    // 0x50d430: ldr             x1, [fp, #0x10]
    // 0x50d434: stur            d0, [fp, #-0x78]
    // 0x50d438: r0 = LoadClassIdInstr(r1)
    //     0x50d438: ldur            x0, [x1, #-1]
    //     0x50d43c: ubfx            x0, x0, #0xc, #0x14
    // 0x50d440: SaveReg r1
    //     0x50d440: str             x1, [SP, #-8]!
    // 0x50d444: r0 = GDT[cid_x0 + 0xd59a]()
    //     0x50d444: mov             x17, #0xd59a
    //     0x50d448: add             lr, x0, x17
    //     0x50d44c: ldr             lr, [x21, lr, lsl #3]
    //     0x50d450: blr             lr
    // 0x50d454: add             SP, SP, #8
    // 0x50d458: ldr             x1, [fp, #0x10]
    // 0x50d45c: stur            d0, [fp, #-0x80]
    // 0x50d460: r0 = LoadClassIdInstr(r1)
    //     0x50d460: ldur            x0, [x1, #-1]
    //     0x50d464: ubfx            x0, x0, #0xc, #0x14
    // 0x50d468: SaveReg r1
    //     0x50d468: str             x1, [SP, #-8]!
    // 0x50d46c: r0 = GDT[cid_x0 + 0xc620]()
    //     0x50d46c: mov             x17, #0xc620
    //     0x50d470: add             lr, x0, x17
    //     0x50d474: ldr             lr, [x21, lr, lsl #3]
    //     0x50d478: blr             lr
    // 0x50d47c: add             SP, SP, #8
    // 0x50d480: ldr             x1, [fp, #0x10]
    // 0x50d484: stur            d0, [fp, #-0x88]
    // 0x50d488: r0 = LoadClassIdInstr(r1)
    //     0x50d488: ldur            x0, [x1, #-1]
    //     0x50d48c: ubfx            x0, x0, #0xc, #0x14
    // 0x50d490: SaveReg r1
    //     0x50d490: str             x1, [SP, #-8]!
    // 0x50d494: r0 = GDT[cid_x0 + 0xd507]()
    //     0x50d494: mov             x17, #0xd507
    //     0x50d498: add             lr, x0, x17
    //     0x50d49c: ldr             lr, [x21, lr, lsl #3]
    //     0x50d4a0: blr             lr
    // 0x50d4a4: add             SP, SP, #8
    // 0x50d4a8: ldr             x1, [fp, #0x10]
    // 0x50d4ac: stur            d0, [fp, #-0x90]
    // 0x50d4b0: r0 = LoadClassIdInstr(r1)
    //     0x50d4b0: ldur            x0, [x1, #-1]
    //     0x50d4b4: ubfx            x0, x0, #0xc, #0x14
    // 0x50d4b8: SaveReg r1
    //     0x50d4b8: str             x1, [SP, #-8]!
    // 0x50d4bc: r0 = GDT[cid_x0 + 0xdc0a]()
    //     0x50d4bc: mov             x17, #0xdc0a
    //     0x50d4c0: add             lr, x0, x17
    //     0x50d4c4: ldr             lr, [x21, lr, lsl #3]
    //     0x50d4c8: blr             lr
    // 0x50d4cc: add             SP, SP, #8
    // 0x50d4d0: ldr             x1, [fp, #0x10]
    // 0x50d4d4: stur            d0, [fp, #-0x98]
    // 0x50d4d8: r0 = LoadClassIdInstr(r1)
    //     0x50d4d8: ldur            x0, [x1, #-1]
    //     0x50d4dc: ubfx            x0, x0, #0xc, #0x14
    // 0x50d4e0: SaveReg r1
    //     0x50d4e0: str             x1, [SP, #-8]!
    // 0x50d4e4: r0 = GDT[cid_x0 + 0xde44]()
    //     0x50d4e4: mov             x17, #0xde44
    //     0x50d4e8: add             lr, x0, x17
    //     0x50d4ec: ldr             lr, [x21, lr, lsl #3]
    //     0x50d4f0: blr             lr
    // 0x50d4f4: add             SP, SP, #8
    // 0x50d4f8: ldr             x1, [fp, #0x10]
    // 0x50d4fc: stur            d0, [fp, #-0xa0]
    // 0x50d500: r0 = LoadClassIdInstr(r1)
    //     0x50d500: ldur            x0, [x1, #-1]
    //     0x50d504: ubfx            x0, x0, #0xc, #0x14
    // 0x50d508: SaveReg r1
    //     0x50d508: str             x1, [SP, #-8]!
    // 0x50d50c: r0 = GDT[cid_x0 + 0xd59d]()
    //     0x50d50c: mov             x17, #0xd59d
    //     0x50d510: add             lr, x0, x17
    //     0x50d514: ldr             lr, [x21, lr, lsl #3]
    //     0x50d518: blr             lr
    // 0x50d51c: add             SP, SP, #8
    // 0x50d520: ldr             x1, [fp, #0x10]
    // 0x50d524: stur            d0, [fp, #-0xa8]
    // 0x50d528: r0 = LoadClassIdInstr(r1)
    //     0x50d528: ldur            x0, [x1, #-1]
    //     0x50d52c: ubfx            x0, x0, #0xc, #0x14
    // 0x50d530: SaveReg r1
    //     0x50d530: str             x1, [SP, #-8]!
    // 0x50d534: r0 = GDT[cid_x0 + 0xdefc]()
    //     0x50d534: mov             x17, #0xdefc
    //     0x50d538: add             lr, x0, x17
    //     0x50d53c: ldr             lr, [x21, lr, lsl #3]
    //     0x50d540: blr             lr
    // 0x50d544: add             SP, SP, #8
    // 0x50d548: ldr             x1, [fp, #0x10]
    // 0x50d54c: stur            d0, [fp, #-0xb0]
    // 0x50d550: r0 = LoadClassIdInstr(r1)
    //     0x50d550: ldur            x0, [x1, #-1]
    //     0x50d554: ubfx            x0, x0, #0xc, #0x14
    // 0x50d558: SaveReg r1
    //     0x50d558: str             x1, [SP, #-8]!
    // 0x50d55c: r0 = GDT[cid_x0 + 0xd6b8]()
    //     0x50d55c: mov             x17, #0xd6b8
    //     0x50d560: add             lr, x0, x17
    //     0x50d564: ldr             lr, [x21, lr, lsl #3]
    //     0x50d568: blr             lr
    // 0x50d56c: add             SP, SP, #8
    // 0x50d570: mov             x2, x0
    // 0x50d574: ldr             x1, [fp, #0x10]
    // 0x50d578: stur            x2, [fp, #-0x48]
    // 0x50d57c: r0 = LoadClassIdInstr(r1)
    //     0x50d57c: ldur            x0, [x1, #-1]
    //     0x50d580: ubfx            x0, x0, #0xc, #0x14
    // 0x50d584: SaveReg r1
    //     0x50d584: str             x1, [SP, #-8]!
    // 0x50d588: r0 = GDT[cid_x0 + 0x7012]()
    //     0x50d588: mov             x17, #0x7012
    //     0x50d58c: add             lr, x0, x17
    //     0x50d590: ldr             lr, [x21, lr, lsl #3]
    //     0x50d594: blr             lr
    // 0x50d598: add             SP, SP, #8
    // 0x50d59c: stur            x0, [fp, #-0x50]
    // 0x50d5a0: r0 = PointerExitEvent()
    //     0x50d5a0: bl              #0x50d6b4  ; AllocatePointerExitEventStub -> PointerExitEvent (size=0xb4)
    // 0x50d5a4: mov             x1, x0
    // 0x50d5a8: r0 = 0
    //     0x50d5a8: mov             x0, #0
    // 0x50d5ac: stur            x1, [fp, #-0x58]
    // 0x50d5b0: StoreField: r1->field_7 = r0
    //     0x50d5b0: stur            x0, [x1, #7]
    // 0x50d5b4: ldur            x2, [fp, #-8]
    // 0x50d5b8: StoreField: r1->field_f = r2
    //     0x50d5b8: stur            w2, [x1, #0xf]
    // 0x50d5bc: ldur            x2, [fp, #-0x10]
    // 0x50d5c0: StoreField: r1->field_13 = r2
    //     0x50d5c0: stur            x2, [x1, #0x13]
    // 0x50d5c4: ldur            x2, [fp, #-0x18]
    // 0x50d5c8: StoreField: r1->field_1b = r2
    //     0x50d5c8: stur            w2, [x1, #0x1b]
    // 0x50d5cc: ldur            x2, [fp, #-0x20]
    // 0x50d5d0: StoreField: r1->field_1f = r2
    //     0x50d5d0: stur            x2, [x1, #0x1f]
    // 0x50d5d4: ldur            x2, [fp, #-0x28]
    // 0x50d5d8: StoreField: r1->field_27 = r2
    //     0x50d5d8: stur            w2, [x1, #0x27]
    // 0x50d5dc: ldur            x2, [fp, #-0x30]
    // 0x50d5e0: StoreField: r1->field_2b = r2
    //     0x50d5e0: stur            w2, [x1, #0x2b]
    // 0x50d5e4: ldur            x2, [fp, #-0x38]
    // 0x50d5e8: StoreField: r1->field_2f = r2
    //     0x50d5e8: stur            x2, [x1, #0x2f]
    // 0x50d5ec: ldur            x2, [fp, #-0x48]
    // 0x50d5f0: StoreField: r1->field_37 = r2
    //     0x50d5f0: stur            w2, [x1, #0x37]
    // 0x50d5f4: ldur            x2, [fp, #-0x40]
    // 0x50d5f8: StoreField: r1->field_3b = r2
    //     0x50d5f8: stur            w2, [x1, #0x3b]
    // 0x50d5fc: d0 = 0.000000
    //     0x50d5fc: eor             v0.16b, v0.16b, v0.16b
    // 0x50d600: StoreField: r1->field_3f = d0
    //     0x50d600: stur            d0, [x1, #0x3f]
    // 0x50d604: ldur            d0, [fp, #-0x60]
    // 0x50d608: StoreField: r1->field_47 = d0
    //     0x50d608: stur            d0, [x1, #0x47]
    // 0x50d60c: ldur            d0, [fp, #-0x68]
    // 0x50d610: StoreField: r1->field_4f = d0
    //     0x50d610: stur            d0, [x1, #0x4f]
    // 0x50d614: ldur            d0, [fp, #-0x70]
    // 0x50d618: StoreField: r1->field_57 = d0
    //     0x50d618: stur            d0, [x1, #0x57]
    // 0x50d61c: ldur            d0, [fp, #-0x78]
    // 0x50d620: StoreField: r1->field_5f = d0
    //     0x50d620: stur            d0, [x1, #0x5f]
    // 0x50d624: ldur            d0, [fp, #-0x80]
    // 0x50d628: StoreField: r1->field_67 = d0
    //     0x50d628: stur            d0, [x1, #0x67]
    // 0x50d62c: ldur            d0, [fp, #-0x88]
    // 0x50d630: StoreField: r1->field_6f = d0
    //     0x50d630: stur            d0, [x1, #0x6f]
    // 0x50d634: ldur            d0, [fp, #-0x90]
    // 0x50d638: StoreField: r1->field_77 = d0
    //     0x50d638: stur            d0, [x1, #0x77]
    // 0x50d63c: ldur            d0, [fp, #-0x98]
    // 0x50d640: StoreField: r1->field_7f = d0
    //     0x50d640: stur            d0, [x1, #0x7f]
    // 0x50d644: ldur            d0, [fp, #-0xa0]
    // 0x50d648: StoreField: r1->field_87 = d0
    //     0x50d648: stur            d0, [x1, #0x87]
    // 0x50d64c: ldur            d0, [fp, #-0xa8]
    // 0x50d650: StoreField: r1->field_8f = d0
    //     0x50d650: stur            d0, [x1, #0x8f]
    // 0x50d654: ldur            d0, [fp, #-0xb0]
    // 0x50d658: StoreField: r1->field_97 = d0
    //     0x50d658: stur            d0, [x1, #0x97]
    // 0x50d65c: StoreField: r1->field_9f = r0
    //     0x50d65c: stur            x0, [x1, #0x9f]
    // 0x50d660: ldur            x0, [fp, #-0x50]
    // 0x50d664: StoreField: r1->field_a7 = r0
    //     0x50d664: stur            w0, [x1, #0xa7]
    // 0x50d668: ldr             x0, [fp, #0x10]
    // 0x50d66c: r2 = LoadClassIdInstr(r0)
    //     0x50d66c: ldur            x2, [x0, #-1]
    //     0x50d670: ubfx            x2, x2, #0xc, #0x14
    // 0x50d674: SaveReg r0
    //     0x50d674: str             x0, [SP, #-8]!
    // 0x50d678: mov             x0, x2
    // 0x50d67c: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x50d67c: mov             x17, #0x3f6e
    //     0x50d680: add             lr, x0, x17
    //     0x50d684: ldr             lr, [x21, lr, lsl #3]
    //     0x50d688: blr             lr
    // 0x50d68c: add             SP, SP, #8
    // 0x50d690: ldur            x16, [fp, #-0x58]
    // 0x50d694: stp             x0, x16, [SP, #-0x10]!
    // 0x50d698: r0 = transformed()
    //     0x50d698: bl              #0x6a57a0  ; [package:flutter/src/gestures/events.dart] PointerExitEvent::transformed
    // 0x50d69c: add             SP, SP, #0x10
    // 0x50d6a0: LeaveFrame
    //     0x50d6a0: mov             SP, fp
    //     0x50d6a4: ldp             fp, lr, [SP], #0x10
    // 0x50d6a8: ret
    //     0x50d6a8: ret             
    // 0x50d6ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50d6ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50d6b0: b               #0x50d240
  }
  _ transformed(/* No info */) {
    // ** addr: 0x6a57a0, size: 0x54
    // 0x6a57a0: EnterFrame
    //     0x6a57a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a57a4: mov             fp, SP
    // 0x6a57a8: ldr             x0, [fp, #0x10]
    // 0x6a57ac: cmp             w0, NULL
    // 0x6a57b0: b.ne            #0x6a57c4
    // 0x6a57b4: ldr             x0, [fp, #0x18]
    // 0x6a57b8: LeaveFrame
    //     0x6a57b8: mov             SP, fp
    //     0x6a57bc: ldp             fp, lr, [SP], #0x10
    // 0x6a57c0: ret
    //     0x6a57c0: ret             
    // 0x6a57c4: ldr             x1, [fp, #0x18]
    // 0x6a57c8: r0 = _TransformedPointerExitEvent()
    //     0x6a57c8: bl              #0x6a57f4  ; Allocate_TransformedPointerExitEventStub -> _TransformedPointerExitEvent (size=0x18)
    // 0x6a57cc: ldr             x1, [fp, #0x18]
    // 0x6a57d0: StoreField: r0->field_f = r1
    //     0x6a57d0: stur            w1, [x0, #0xf]
    // 0x6a57d4: ldr             x1, [fp, #0x10]
    // 0x6a57d8: StoreField: r0->field_13 = r1
    //     0x6a57d8: stur            w1, [x0, #0x13]
    // 0x6a57dc: r1 = Sentinel
    //     0x6a57dc: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a57e0: StoreField: r0->field_7 = r1
    //     0x6a57e0: stur            w1, [x0, #7]
    // 0x6a57e4: StoreField: r0->field_b = r1
    //     0x6a57e4: stur            w1, [x0, #0xb]
    // 0x6a57e8: LeaveFrame
    //     0x6a57e8: mov             SP, fp
    //     0x6a57ec: ldp             fp, lr, [SP], #0x10
    // 0x6a57f0: ret
    //     0x6a57f0: ret             
  }
}

// class id: 2884, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerEnterEvent&PointerEvent&_PointerEventDescription&_CopyPointerEnterEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerEnterEvent {
}

// class id: 2885, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerEnterEvent extends _PointerEnterEvent&PointerEvent&_PointerEventDescription&_CopyPointerEnterEvent {

  factory _ PointerEnterEvent.fromMouseEvent(/* No info */) {
    // ** addr: 0x50cd90, size: 0x48c
    // 0x50cd90: EnterFrame
    //     0x50cd90: stp             fp, lr, [SP, #-0x10]!
    //     0x50cd94: mov             fp, SP
    // 0x50cd98: AllocStack(0xb0)
    //     0x50cd98: sub             SP, SP, #0xb0
    // 0x50cd9c: CheckStackOverflow
    //     0x50cd9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50cda0: cmp             SP, x16
    //     0x50cda4: b.ls            #0x50d214
    // 0x50cda8: ldr             x1, [fp, #0x10]
    // 0x50cdac: r0 = LoadClassIdInstr(r1)
    //     0x50cdac: ldur            x0, [x1, #-1]
    //     0x50cdb0: ubfx            x0, x0, #0xc, #0x14
    // 0x50cdb4: SaveReg r1
    //     0x50cdb4: str             x1, [SP, #-8]!
    // 0x50cdb8: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x50cdb8: sub             lr, x0, #0xf3a
    //     0x50cdbc: ldr             lr, [x21, lr, lsl #3]
    //     0x50cdc0: blr             lr
    // 0x50cdc4: add             SP, SP, #8
    // 0x50cdc8: mov             x2, x0
    // 0x50cdcc: ldr             x1, [fp, #0x10]
    // 0x50cdd0: stur            x2, [fp, #-8]
    // 0x50cdd4: r0 = LoadClassIdInstr(r1)
    //     0x50cdd4: ldur            x0, [x1, #-1]
    //     0x50cdd8: ubfx            x0, x0, #0xc, #0x14
    // 0x50cddc: SaveReg r1
    //     0x50cddc: str             x1, [SP, #-8]!
    // 0x50cde0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x50cde0: sub             lr, x0, #0xfff
    //     0x50cde4: ldr             lr, [x21, lr, lsl #3]
    //     0x50cde8: blr             lr
    // 0x50cdec: add             SP, SP, #8
    // 0x50cdf0: mov             x2, x0
    // 0x50cdf4: ldr             x1, [fp, #0x10]
    // 0x50cdf8: stur            x2, [fp, #-0x10]
    // 0x50cdfc: r0 = LoadClassIdInstr(r1)
    //     0x50cdfc: ldur            x0, [x1, #-1]
    //     0x50ce00: ubfx            x0, x0, #0xc, #0x14
    // 0x50ce04: SaveReg r1
    //     0x50ce04: str             x1, [SP, #-8]!
    // 0x50ce08: r0 = GDT[cid_x0 + -0xf60]()
    //     0x50ce08: sub             lr, x0, #0xf60
    //     0x50ce0c: ldr             lr, [x21, lr, lsl #3]
    //     0x50ce10: blr             lr
    // 0x50ce14: add             SP, SP, #8
    // 0x50ce18: mov             x2, x0
    // 0x50ce1c: ldr             x1, [fp, #0x10]
    // 0x50ce20: stur            x2, [fp, #-0x18]
    // 0x50ce24: r0 = LoadClassIdInstr(r1)
    //     0x50ce24: ldur            x0, [x1, #-1]
    //     0x50ce28: ubfx            x0, x0, #0xc, #0x14
    // 0x50ce2c: SaveReg r1
    //     0x50ce2c: str             x1, [SP, #-8]!
    // 0x50ce30: r0 = GDT[cid_x0 + 0x8864]()
    //     0x50ce30: mov             x17, #0x8864
    //     0x50ce34: add             lr, x0, x17
    //     0x50ce38: ldr             lr, [x21, lr, lsl #3]
    //     0x50ce3c: blr             lr
    // 0x50ce40: add             SP, SP, #8
    // 0x50ce44: mov             x2, x0
    // 0x50ce48: ldr             x1, [fp, #0x10]
    // 0x50ce4c: stur            x2, [fp, #-0x20]
    // 0x50ce50: r0 = LoadClassIdInstr(r1)
    //     0x50ce50: ldur            x0, [x1, #-1]
    //     0x50ce54: ubfx            x0, x0, #0xc, #0x14
    // 0x50ce58: SaveReg r1
    //     0x50ce58: str             x1, [SP, #-8]!
    // 0x50ce5c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x50ce5c: sub             lr, x0, #0xfd9
    //     0x50ce60: ldr             lr, [x21, lr, lsl #3]
    //     0x50ce64: blr             lr
    // 0x50ce68: add             SP, SP, #8
    // 0x50ce6c: mov             x2, x0
    // 0x50ce70: ldr             x1, [fp, #0x10]
    // 0x50ce74: stur            x2, [fp, #-0x28]
    // 0x50ce78: r0 = LoadClassIdInstr(r1)
    //     0x50ce78: ldur            x0, [x1, #-1]
    //     0x50ce7c: ubfx            x0, x0, #0xc, #0x14
    // 0x50ce80: SaveReg r1
    //     0x50ce80: str             x1, [SP, #-8]!
    // 0x50ce84: r0 = GDT[cid_x0 + 0x9887]()
    //     0x50ce84: mov             x17, #0x9887
    //     0x50ce88: add             lr, x0, x17
    //     0x50ce8c: ldr             lr, [x21, lr, lsl #3]
    //     0x50ce90: blr             lr
    // 0x50ce94: add             SP, SP, #8
    // 0x50ce98: mov             x2, x0
    // 0x50ce9c: ldr             x1, [fp, #0x10]
    // 0x50cea0: stur            x2, [fp, #-0x30]
    // 0x50cea4: r0 = LoadClassIdInstr(r1)
    //     0x50cea4: ldur            x0, [x1, #-1]
    //     0x50cea8: ubfx            x0, x0, #0xc, #0x14
    // 0x50ceac: SaveReg r1
    //     0x50ceac: str             x1, [SP, #-8]!
    // 0x50ceb0: r0 = GDT[cid_x0 + 0x271c]()
    //     0x50ceb0: mov             x17, #0x271c
    //     0x50ceb4: add             lr, x0, x17
    //     0x50ceb8: ldr             lr, [x21, lr, lsl #3]
    //     0x50cebc: blr             lr
    // 0x50cec0: add             SP, SP, #8
    // 0x50cec4: mov             x2, x0
    // 0x50cec8: ldr             x1, [fp, #0x10]
    // 0x50cecc: stur            x2, [fp, #-0x38]
    // 0x50ced0: r0 = LoadClassIdInstr(r1)
    //     0x50ced0: ldur            x0, [x1, #-1]
    //     0x50ced4: ubfx            x0, x0, #0xc, #0x14
    // 0x50ced8: SaveReg r1
    //     0x50ced8: str             x1, [SP, #-8]!
    // 0x50cedc: r0 = GDT[cid_x0 + 0xd6b9]()
    //     0x50cedc: mov             x17, #0xd6b9
    //     0x50cee0: add             lr, x0, x17
    //     0x50cee4: ldr             lr, [x21, lr, lsl #3]
    //     0x50cee8: blr             lr
    // 0x50ceec: add             SP, SP, #8
    // 0x50cef0: mov             x2, x0
    // 0x50cef4: ldr             x1, [fp, #0x10]
    // 0x50cef8: stur            x2, [fp, #-0x40]
    // 0x50cefc: r0 = LoadClassIdInstr(r1)
    //     0x50cefc: ldur            x0, [x1, #-1]
    //     0x50cf00: ubfx            x0, x0, #0xc, #0x14
    // 0x50cf04: SaveReg r1
    //     0x50cf04: str             x1, [SP, #-8]!
    // 0x50cf08: r0 = GDT[cid_x0 + 0xd50a]()
    //     0x50cf08: mov             x17, #0xd50a
    //     0x50cf0c: add             lr, x0, x17
    //     0x50cf10: ldr             lr, [x21, lr, lsl #3]
    //     0x50cf14: blr             lr
    // 0x50cf18: add             SP, SP, #8
    // 0x50cf1c: ldr             x1, [fp, #0x10]
    // 0x50cf20: stur            d0, [fp, #-0x60]
    // 0x50cf24: r0 = LoadClassIdInstr(r1)
    //     0x50cf24: ldur            x0, [x1, #-1]
    //     0x50cf28: ubfx            x0, x0, #0xc, #0x14
    // 0x50cf2c: SaveReg r1
    //     0x50cf2c: str             x1, [SP, #-8]!
    // 0x50cf30: r0 = GDT[cid_x0 + 0xc61f]()
    //     0x50cf30: mov             x17, #0xc61f
    //     0x50cf34: add             lr, x0, x17
    //     0x50cf38: ldr             lr, [x21, lr, lsl #3]
    //     0x50cf3c: blr             lr
    // 0x50cf40: add             SP, SP, #8
    // 0x50cf44: ldr             x1, [fp, #0x10]
    // 0x50cf48: stur            d0, [fp, #-0x68]
    // 0x50cf4c: r0 = LoadClassIdInstr(r1)
    //     0x50cf4c: ldur            x0, [x1, #-1]
    //     0x50cf50: ubfx            x0, x0, #0xc, #0x14
    // 0x50cf54: SaveReg r1
    //     0x50cf54: str             x1, [SP, #-8]!
    // 0x50cf58: r0 = GDT[cid_x0 + 0x102da]()
    //     0x50cf58: mov             x17, #0x2da
    //     0x50cf5c: movk            x17, #1, lsl #16
    //     0x50cf60: add             lr, x0, x17
    //     0x50cf64: ldr             lr, [x21, lr, lsl #3]
    //     0x50cf68: blr             lr
    // 0x50cf6c: add             SP, SP, #8
    // 0x50cf70: ldr             x1, [fp, #0x10]
    // 0x50cf74: stur            d0, [fp, #-0x70]
    // 0x50cf78: r0 = LoadClassIdInstr(r1)
    //     0x50cf78: ldur            x0, [x1, #-1]
    //     0x50cf7c: ubfx            x0, x0, #0xc, #0x14
    // 0x50cf80: SaveReg r1
    //     0x50cf80: str             x1, [SP, #-8]!
    // 0x50cf84: r0 = GDT[cid_x0 + 0xd714]()
    //     0x50cf84: mov             x17, #0xd714
    //     0x50cf88: add             lr, x0, x17
    //     0x50cf8c: ldr             lr, [x21, lr, lsl #3]
    //     0x50cf90: blr             lr
    // 0x50cf94: add             SP, SP, #8
    // 0x50cf98: ldr             x1, [fp, #0x10]
    // 0x50cf9c: stur            d0, [fp, #-0x78]
    // 0x50cfa0: r0 = LoadClassIdInstr(r1)
    //     0x50cfa0: ldur            x0, [x1, #-1]
    //     0x50cfa4: ubfx            x0, x0, #0xc, #0x14
    // 0x50cfa8: SaveReg r1
    //     0x50cfa8: str             x1, [SP, #-8]!
    // 0x50cfac: r0 = GDT[cid_x0 + 0xd59a]()
    //     0x50cfac: mov             x17, #0xd59a
    //     0x50cfb0: add             lr, x0, x17
    //     0x50cfb4: ldr             lr, [x21, lr, lsl #3]
    //     0x50cfb8: blr             lr
    // 0x50cfbc: add             SP, SP, #8
    // 0x50cfc0: ldr             x1, [fp, #0x10]
    // 0x50cfc4: stur            d0, [fp, #-0x80]
    // 0x50cfc8: r0 = LoadClassIdInstr(r1)
    //     0x50cfc8: ldur            x0, [x1, #-1]
    //     0x50cfcc: ubfx            x0, x0, #0xc, #0x14
    // 0x50cfd0: SaveReg r1
    //     0x50cfd0: str             x1, [SP, #-8]!
    // 0x50cfd4: r0 = GDT[cid_x0 + 0xc620]()
    //     0x50cfd4: mov             x17, #0xc620
    //     0x50cfd8: add             lr, x0, x17
    //     0x50cfdc: ldr             lr, [x21, lr, lsl #3]
    //     0x50cfe0: blr             lr
    // 0x50cfe4: add             SP, SP, #8
    // 0x50cfe8: ldr             x1, [fp, #0x10]
    // 0x50cfec: stur            d0, [fp, #-0x88]
    // 0x50cff0: r0 = LoadClassIdInstr(r1)
    //     0x50cff0: ldur            x0, [x1, #-1]
    //     0x50cff4: ubfx            x0, x0, #0xc, #0x14
    // 0x50cff8: SaveReg r1
    //     0x50cff8: str             x1, [SP, #-8]!
    // 0x50cffc: r0 = GDT[cid_x0 + 0xd507]()
    //     0x50cffc: mov             x17, #0xd507
    //     0x50d000: add             lr, x0, x17
    //     0x50d004: ldr             lr, [x21, lr, lsl #3]
    //     0x50d008: blr             lr
    // 0x50d00c: add             SP, SP, #8
    // 0x50d010: ldr             x1, [fp, #0x10]
    // 0x50d014: stur            d0, [fp, #-0x90]
    // 0x50d018: r0 = LoadClassIdInstr(r1)
    //     0x50d018: ldur            x0, [x1, #-1]
    //     0x50d01c: ubfx            x0, x0, #0xc, #0x14
    // 0x50d020: SaveReg r1
    //     0x50d020: str             x1, [SP, #-8]!
    // 0x50d024: r0 = GDT[cid_x0 + 0xdc0a]()
    //     0x50d024: mov             x17, #0xdc0a
    //     0x50d028: add             lr, x0, x17
    //     0x50d02c: ldr             lr, [x21, lr, lsl #3]
    //     0x50d030: blr             lr
    // 0x50d034: add             SP, SP, #8
    // 0x50d038: ldr             x1, [fp, #0x10]
    // 0x50d03c: stur            d0, [fp, #-0x98]
    // 0x50d040: r0 = LoadClassIdInstr(r1)
    //     0x50d040: ldur            x0, [x1, #-1]
    //     0x50d044: ubfx            x0, x0, #0xc, #0x14
    // 0x50d048: SaveReg r1
    //     0x50d048: str             x1, [SP, #-8]!
    // 0x50d04c: r0 = GDT[cid_x0 + 0xde44]()
    //     0x50d04c: mov             x17, #0xde44
    //     0x50d050: add             lr, x0, x17
    //     0x50d054: ldr             lr, [x21, lr, lsl #3]
    //     0x50d058: blr             lr
    // 0x50d05c: add             SP, SP, #8
    // 0x50d060: ldr             x1, [fp, #0x10]
    // 0x50d064: stur            d0, [fp, #-0xa0]
    // 0x50d068: r0 = LoadClassIdInstr(r1)
    //     0x50d068: ldur            x0, [x1, #-1]
    //     0x50d06c: ubfx            x0, x0, #0xc, #0x14
    // 0x50d070: SaveReg r1
    //     0x50d070: str             x1, [SP, #-8]!
    // 0x50d074: r0 = GDT[cid_x0 + 0xd59d]()
    //     0x50d074: mov             x17, #0xd59d
    //     0x50d078: add             lr, x0, x17
    //     0x50d07c: ldr             lr, [x21, lr, lsl #3]
    //     0x50d080: blr             lr
    // 0x50d084: add             SP, SP, #8
    // 0x50d088: ldr             x1, [fp, #0x10]
    // 0x50d08c: stur            d0, [fp, #-0xa8]
    // 0x50d090: r0 = LoadClassIdInstr(r1)
    //     0x50d090: ldur            x0, [x1, #-1]
    //     0x50d094: ubfx            x0, x0, #0xc, #0x14
    // 0x50d098: SaveReg r1
    //     0x50d098: str             x1, [SP, #-8]!
    // 0x50d09c: r0 = GDT[cid_x0 + 0xdefc]()
    //     0x50d09c: mov             x17, #0xdefc
    //     0x50d0a0: add             lr, x0, x17
    //     0x50d0a4: ldr             lr, [x21, lr, lsl #3]
    //     0x50d0a8: blr             lr
    // 0x50d0ac: add             SP, SP, #8
    // 0x50d0b0: ldr             x1, [fp, #0x10]
    // 0x50d0b4: stur            d0, [fp, #-0xb0]
    // 0x50d0b8: r0 = LoadClassIdInstr(r1)
    //     0x50d0b8: ldur            x0, [x1, #-1]
    //     0x50d0bc: ubfx            x0, x0, #0xc, #0x14
    // 0x50d0c0: SaveReg r1
    //     0x50d0c0: str             x1, [SP, #-8]!
    // 0x50d0c4: r0 = GDT[cid_x0 + 0xd6b8]()
    //     0x50d0c4: mov             x17, #0xd6b8
    //     0x50d0c8: add             lr, x0, x17
    //     0x50d0cc: ldr             lr, [x21, lr, lsl #3]
    //     0x50d0d0: blr             lr
    // 0x50d0d4: add             SP, SP, #8
    // 0x50d0d8: mov             x2, x0
    // 0x50d0dc: ldr             x1, [fp, #0x10]
    // 0x50d0e0: stur            x2, [fp, #-0x48]
    // 0x50d0e4: r0 = LoadClassIdInstr(r1)
    //     0x50d0e4: ldur            x0, [x1, #-1]
    //     0x50d0e8: ubfx            x0, x0, #0xc, #0x14
    // 0x50d0ec: SaveReg r1
    //     0x50d0ec: str             x1, [SP, #-8]!
    // 0x50d0f0: r0 = GDT[cid_x0 + 0x7012]()
    //     0x50d0f0: mov             x17, #0x7012
    //     0x50d0f4: add             lr, x0, x17
    //     0x50d0f8: ldr             lr, [x21, lr, lsl #3]
    //     0x50d0fc: blr             lr
    // 0x50d100: add             SP, SP, #8
    // 0x50d104: stur            x0, [fp, #-0x50]
    // 0x50d108: r0 = PointerEnterEvent()
    //     0x50d108: bl              #0x50d21c  ; AllocatePointerEnterEventStub -> PointerEnterEvent (size=0xb4)
    // 0x50d10c: mov             x1, x0
    // 0x50d110: r0 = 0
    //     0x50d110: mov             x0, #0
    // 0x50d114: stur            x1, [fp, #-0x58]
    // 0x50d118: StoreField: r1->field_7 = r0
    //     0x50d118: stur            x0, [x1, #7]
    // 0x50d11c: ldur            x2, [fp, #-8]
    // 0x50d120: StoreField: r1->field_f = r2
    //     0x50d120: stur            w2, [x1, #0xf]
    // 0x50d124: ldur            x2, [fp, #-0x10]
    // 0x50d128: StoreField: r1->field_13 = r2
    //     0x50d128: stur            x2, [x1, #0x13]
    // 0x50d12c: ldur            x2, [fp, #-0x18]
    // 0x50d130: StoreField: r1->field_1b = r2
    //     0x50d130: stur            w2, [x1, #0x1b]
    // 0x50d134: ldur            x2, [fp, #-0x20]
    // 0x50d138: StoreField: r1->field_1f = r2
    //     0x50d138: stur            x2, [x1, #0x1f]
    // 0x50d13c: ldur            x2, [fp, #-0x28]
    // 0x50d140: StoreField: r1->field_27 = r2
    //     0x50d140: stur            w2, [x1, #0x27]
    // 0x50d144: ldur            x2, [fp, #-0x30]
    // 0x50d148: StoreField: r1->field_2b = r2
    //     0x50d148: stur            w2, [x1, #0x2b]
    // 0x50d14c: ldur            x2, [fp, #-0x38]
    // 0x50d150: StoreField: r1->field_2f = r2
    //     0x50d150: stur            x2, [x1, #0x2f]
    // 0x50d154: ldur            x2, [fp, #-0x48]
    // 0x50d158: StoreField: r1->field_37 = r2
    //     0x50d158: stur            w2, [x1, #0x37]
    // 0x50d15c: ldur            x2, [fp, #-0x40]
    // 0x50d160: StoreField: r1->field_3b = r2
    //     0x50d160: stur            w2, [x1, #0x3b]
    // 0x50d164: d0 = 0.000000
    //     0x50d164: eor             v0.16b, v0.16b, v0.16b
    // 0x50d168: StoreField: r1->field_3f = d0
    //     0x50d168: stur            d0, [x1, #0x3f]
    // 0x50d16c: ldur            d0, [fp, #-0x60]
    // 0x50d170: StoreField: r1->field_47 = d0
    //     0x50d170: stur            d0, [x1, #0x47]
    // 0x50d174: ldur            d0, [fp, #-0x68]
    // 0x50d178: StoreField: r1->field_4f = d0
    //     0x50d178: stur            d0, [x1, #0x4f]
    // 0x50d17c: ldur            d0, [fp, #-0x70]
    // 0x50d180: StoreField: r1->field_57 = d0
    //     0x50d180: stur            d0, [x1, #0x57]
    // 0x50d184: ldur            d0, [fp, #-0x78]
    // 0x50d188: StoreField: r1->field_5f = d0
    //     0x50d188: stur            d0, [x1, #0x5f]
    // 0x50d18c: ldur            d0, [fp, #-0x80]
    // 0x50d190: StoreField: r1->field_67 = d0
    //     0x50d190: stur            d0, [x1, #0x67]
    // 0x50d194: ldur            d0, [fp, #-0x88]
    // 0x50d198: StoreField: r1->field_6f = d0
    //     0x50d198: stur            d0, [x1, #0x6f]
    // 0x50d19c: ldur            d0, [fp, #-0x90]
    // 0x50d1a0: StoreField: r1->field_77 = d0
    //     0x50d1a0: stur            d0, [x1, #0x77]
    // 0x50d1a4: ldur            d0, [fp, #-0x98]
    // 0x50d1a8: StoreField: r1->field_7f = d0
    //     0x50d1a8: stur            d0, [x1, #0x7f]
    // 0x50d1ac: ldur            d0, [fp, #-0xa0]
    // 0x50d1b0: StoreField: r1->field_87 = d0
    //     0x50d1b0: stur            d0, [x1, #0x87]
    // 0x50d1b4: ldur            d0, [fp, #-0xa8]
    // 0x50d1b8: StoreField: r1->field_8f = d0
    //     0x50d1b8: stur            d0, [x1, #0x8f]
    // 0x50d1bc: ldur            d0, [fp, #-0xb0]
    // 0x50d1c0: StoreField: r1->field_97 = d0
    //     0x50d1c0: stur            d0, [x1, #0x97]
    // 0x50d1c4: StoreField: r1->field_9f = r0
    //     0x50d1c4: stur            x0, [x1, #0x9f]
    // 0x50d1c8: ldur            x0, [fp, #-0x50]
    // 0x50d1cc: StoreField: r1->field_a7 = r0
    //     0x50d1cc: stur            w0, [x1, #0xa7]
    // 0x50d1d0: ldr             x0, [fp, #0x10]
    // 0x50d1d4: r2 = LoadClassIdInstr(r0)
    //     0x50d1d4: ldur            x2, [x0, #-1]
    //     0x50d1d8: ubfx            x2, x2, #0xc, #0x14
    // 0x50d1dc: SaveReg r0
    //     0x50d1dc: str             x0, [SP, #-8]!
    // 0x50d1e0: mov             x0, x2
    // 0x50d1e4: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x50d1e4: mov             x17, #0x3f6e
    //     0x50d1e8: add             lr, x0, x17
    //     0x50d1ec: ldr             lr, [x21, lr, lsl #3]
    //     0x50d1f0: blr             lr
    // 0x50d1f4: add             SP, SP, #8
    // 0x50d1f8: ldur            x16, [fp, #-0x58]
    // 0x50d1fc: stp             x0, x16, [SP, #-0x10]!
    // 0x50d200: r0 = transformed()
    //     0x50d200: bl              #0x6a5740  ; [package:flutter/src/gestures/events.dart] PointerEnterEvent::transformed
    // 0x50d204: add             SP, SP, #0x10
    // 0x50d208: LeaveFrame
    //     0x50d208: mov             SP, fp
    //     0x50d20c: ldp             fp, lr, [SP], #0x10
    // 0x50d210: ret
    //     0x50d210: ret             
    // 0x50d214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50d214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50d218: b               #0x50cda8
  }
  _ transformed(/* No info */) {
    // ** addr: 0x6a5740, size: 0x54
    // 0x6a5740: EnterFrame
    //     0x6a5740: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5744: mov             fp, SP
    // 0x6a5748: ldr             x0, [fp, #0x10]
    // 0x6a574c: cmp             w0, NULL
    // 0x6a5750: b.ne            #0x6a5764
    // 0x6a5754: ldr             x0, [fp, #0x18]
    // 0x6a5758: LeaveFrame
    //     0x6a5758: mov             SP, fp
    //     0x6a575c: ldp             fp, lr, [SP], #0x10
    // 0x6a5760: ret
    //     0x6a5760: ret             
    // 0x6a5764: ldr             x1, [fp, #0x18]
    // 0x6a5768: r0 = _TransformedPointerEnterEvent()
    //     0x6a5768: bl              #0x6a5794  ; Allocate_TransformedPointerEnterEventStub -> _TransformedPointerEnterEvent (size=0x18)
    // 0x6a576c: ldr             x1, [fp, #0x18]
    // 0x6a5770: StoreField: r0->field_f = r1
    //     0x6a5770: stur            w1, [x0, #0xf]
    // 0x6a5774: ldr             x1, [fp, #0x10]
    // 0x6a5778: StoreField: r0->field_13 = r1
    //     0x6a5778: stur            w1, [x0, #0x13]
    // 0x6a577c: r1 = Sentinel
    //     0x6a577c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5780: StoreField: r0->field_7 = r1
    //     0x6a5780: stur            w1, [x0, #7]
    // 0x6a5784: StoreField: r0->field_b = r1
    //     0x6a5784: stur            w1, [x0, #0xb]
    // 0x6a5788: LeaveFrame
    //     0x6a5788: mov             SP, fp
    //     0x6a578c: ldp             fp, lr, [SP], #0x10
    // 0x6a5790: ret
    //     0x6a5790: ret             
  }
}

// class id: 2886, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerHoverEvent&PointerEvent&_PointerEventDescription&_CopyPointerHoverEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerHoverEvent {
}

// class id: 2887, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerHoverEvent extends _PointerHoverEvent&PointerEvent&_PointerEventDescription&_CopyPointerHoverEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a56e0, size: 0x54
    // 0x6a56e0: EnterFrame
    //     0x6a56e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6a56e4: mov             fp, SP
    // 0x6a56e8: ldr             x0, [fp, #0x10]
    // 0x6a56ec: cmp             w0, NULL
    // 0x6a56f0: b.ne            #0x6a5704
    // 0x6a56f4: ldr             x0, [fp, #0x18]
    // 0x6a56f8: LeaveFrame
    //     0x6a56f8: mov             SP, fp
    //     0x6a56fc: ldp             fp, lr, [SP], #0x10
    // 0x6a5700: ret
    //     0x6a5700: ret             
    // 0x6a5704: ldr             x1, [fp, #0x18]
    // 0x6a5708: r0 = _TransformedPointerHoverEvent()
    //     0x6a5708: bl              #0x6a5734  ; Allocate_TransformedPointerHoverEventStub -> _TransformedPointerHoverEvent (size=0x18)
    // 0x6a570c: ldr             x1, [fp, #0x18]
    // 0x6a5710: StoreField: r0->field_f = r1
    //     0x6a5710: stur            w1, [x0, #0xf]
    // 0x6a5714: ldr             x1, [fp, #0x10]
    // 0x6a5718: StoreField: r0->field_13 = r1
    //     0x6a5718: stur            w1, [x0, #0x13]
    // 0x6a571c: r1 = Sentinel
    //     0x6a571c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5720: StoreField: r0->field_7 = r1
    //     0x6a5720: stur            w1, [x0, #7]
    // 0x6a5724: StoreField: r0->field_b = r1
    //     0x6a5724: stur            w1, [x0, #0xb]
    // 0x6a5728: LeaveFrame
    //     0x6a5728: mov             SP, fp
    //     0x6a572c: ldp             fp, lr, [SP], #0x10
    // 0x6a5730: ret
    //     0x6a5730: ret             
  }
}

// class id: 2888, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerRemovedEvent&PointerEvent&_PointerEventDescription&_CopyPointerRemovedEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerRemovedEvent {
}

// class id: 2889, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerRemovedEvent extends _PointerRemovedEvent&PointerEvent&_PointerEventDescription&_CopyPointerRemovedEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5680, size: 0x54
    // 0x6a5680: EnterFrame
    //     0x6a5680: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5684: mov             fp, SP
    // 0x6a5688: ldr             x0, [fp, #0x10]
    // 0x6a568c: cmp             w0, NULL
    // 0x6a5690: b.ne            #0x6a56a4
    // 0x6a5694: ldr             x0, [fp, #0x18]
    // 0x6a5698: LeaveFrame
    //     0x6a5698: mov             SP, fp
    //     0x6a569c: ldp             fp, lr, [SP], #0x10
    // 0x6a56a0: ret
    //     0x6a56a0: ret             
    // 0x6a56a4: ldr             x1, [fp, #0x18]
    // 0x6a56a8: r0 = _TransformedPointerRemovedEvent()
    //     0x6a56a8: bl              #0x6a56d4  ; Allocate_TransformedPointerRemovedEventStub -> _TransformedPointerRemovedEvent (size=0x18)
    // 0x6a56ac: ldr             x1, [fp, #0x18]
    // 0x6a56b0: StoreField: r0->field_f = r1
    //     0x6a56b0: stur            w1, [x0, #0xf]
    // 0x6a56b4: ldr             x1, [fp, #0x10]
    // 0x6a56b8: StoreField: r0->field_13 = r1
    //     0x6a56b8: stur            w1, [x0, #0x13]
    // 0x6a56bc: r1 = Sentinel
    //     0x6a56bc: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a56c0: StoreField: r0->field_7 = r1
    //     0x6a56c0: stur            w1, [x0, #7]
    // 0x6a56c4: StoreField: r0->field_b = r1
    //     0x6a56c4: stur            w1, [x0, #0xb]
    // 0x6a56c8: LeaveFrame
    //     0x6a56c8: mov             SP, fp
    //     0x6a56cc: ldp             fp, lr, [SP], #0x10
    // 0x6a56d0: ret
    //     0x6a56d0: ret             
  }
}

// class id: 2890, size: 0xb4, field offset: 0xb4
//   const constructor, transformed mixin,
abstract class _PointerAddedEvent&PointerEvent&_PointerEventDescription&_CopyPointerAddedEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription
     with _CopyPointerAddedEvent {
}

// class id: 2891, size: 0xb4, field offset: 0xb4
//   const constructor, 
class PointerAddedEvent extends _PointerAddedEvent&PointerEvent&_PointerEventDescription&_CopyPointerAddedEvent {

  _ transformed(/* No info */) {
    // ** addr: 0x6a5620, size: 0x54
    // 0x6a5620: EnterFrame
    //     0x6a5620: stp             fp, lr, [SP, #-0x10]!
    //     0x6a5624: mov             fp, SP
    // 0x6a5628: ldr             x0, [fp, #0x10]
    // 0x6a562c: cmp             w0, NULL
    // 0x6a5630: b.ne            #0x6a5644
    // 0x6a5634: ldr             x0, [fp, #0x18]
    // 0x6a5638: LeaveFrame
    //     0x6a5638: mov             SP, fp
    //     0x6a563c: ldp             fp, lr, [SP], #0x10
    // 0x6a5640: ret
    //     0x6a5640: ret             
    // 0x6a5644: ldr             x1, [fp, #0x18]
    // 0x6a5648: r0 = _TransformedPointerAddedEvent()
    //     0x6a5648: bl              #0x6a5674  ; Allocate_TransformedPointerAddedEventStub -> _TransformedPointerAddedEvent (size=0x18)
    // 0x6a564c: ldr             x1, [fp, #0x18]
    // 0x6a5650: StoreField: r0->field_f = r1
    //     0x6a5650: stur            w1, [x0, #0xf]
    // 0x6a5654: ldr             x1, [fp, #0x10]
    // 0x6a5658: StoreField: r0->field_13 = r1
    //     0x6a5658: stur            w1, [x0, #0x13]
    // 0x6a565c: r1 = Sentinel
    //     0x6a565c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6a5660: StoreField: r0->field_7 = r1
    //     0x6a5660: stur            w1, [x0, #7]
    // 0x6a5664: StoreField: r0->field_b = r1
    //     0x6a5664: stur            w1, [x0, #0xb]
    // 0x6a5668: LeaveFrame
    //     0x6a5668: mov             SP, fp
    //     0x6a566c: ldp             fp, lr, [SP], #0x10
    // 0x6a5670: ret
    //     0x6a5670: ret             
  }
}

// class id: 2892, size: 0xb4, field offset: 0xb4
abstract class _CopyPointerAddedEvent extends PointerEvent {
}

// class id: 2893, size: 0xb4, field offset: 0xb4
abstract class _PointerEventDescription extends PointerEvent {
}

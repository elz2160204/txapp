// lib: , url: package:flutter/src/gestures/force_press.dart

// class id: 1049158, size: 0x8
class :: {
}

// class id: 2290, size: 0xc, field offset: 0x8
class ForcePressDetails extends Object {

  const Offset globalPosition(ForcePressDetails) {
    // ** addr: 0xd64bac, size: 0x28
    // 0xd64bac: ldr             x1, [SP]
    // 0xd64bb0: LoadField: r0 = r1->field_7
    //     0xd64bb0: ldur            w0, [x1, #7]
    // 0xd64bb4: DecompressPointer r0
    //     0xd64bb4: add             x0, x0, HEAP, lsl #32
    // 0xd64bb8: ret
    //     0xd64bb8: ret             
  }
}

// class id: 2363, size: 0x50, field offset: 0x20
class ForcePressGestureRecognizer extends OneSequenceGestureRecognizer {

  late OffsetPair _lastPosition; // offset: 0x44
  late double _lastPressure; // offset: 0x48

  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0x713ff8, size: 0xfc
    // 0x713ff8: EnterFrame
    //     0x713ff8: stp             fp, lr, [SP, #-0x10]!
    //     0x713ffc: mov             fp, SP
    // 0x714000: CheckStackOverflow
    //     0x714000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714004: cmp             SP, x16
    //     0x714008: b.ls            #0x7140ec
    // 0x71400c: r1 = 1
    //     0x71400c: mov             x1, #1
    // 0x714010: r0 = AllocateContext()
    //     0x714010: bl              #0xd68aa4  ; AllocateContextStub
    // 0x714014: mov             x1, x0
    // 0x714018: ldr             x0, [fp, #0x18]
    // 0x71401c: StoreField: r1->field_f = r0
    //     0x71401c: stur            w0, [x1, #0xf]
    // 0x714020: LoadField: r2 = r0->field_4b
    //     0x714020: ldur            w2, [x0, #0x4b]
    // 0x714024: DecompressPointer r2
    //     0x714024: add             x2, x2, HEAP, lsl #32
    // 0x714028: r16 = Instance__ForceState
    //     0x714028: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b9f0] Obj!_ForceState@b65bf1
    //     0x71402c: ldr             x16, [x16, #0x9f0]
    // 0x714030: cmp             w2, w16
    // 0x714034: b.ne            #0x714040
    // 0x714038: r3 = true
    //     0x714038: add             x3, NULL, #0x20  ; true
    // 0x71403c: b               #0x714058
    // 0x714040: r16 = Instance__ForceState
    //     0x714040: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4ba10] Obj!_ForceState@b65b91
    //     0x714044: ldr             x16, [x16, #0xa10]
    // 0x714048: cmp             w2, w16
    // 0x71404c: r16 = true
    //     0x71404c: add             x16, NULL, #0x20  ; true
    // 0x714050: r17 = false
    //     0x714050: add             x17, NULL, #0x30  ; false
    // 0x714054: csel            x3, x16, x17, eq
    // 0x714058: r16 = Instance__ForceState
    //     0x714058: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b9e8] Obj!_ForceState@b65bd1
    //     0x71405c: ldr             x16, [x16, #0x9e8]
    // 0x714060: cmp             w2, w16
    // 0x714064: b.ne            #0x71408c
    // 0x714068: r16 = Instance_GestureDisposition
    //     0x714068: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x71406c: ldr             x16, [x16, #0xeb8]
    // 0x714070: stp             x16, x0, [SP, #-0x10]!
    // 0x714074: r0 = resolve()
    //     0x714074: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x714078: add             SP, SP, #0x10
    // 0x71407c: r0 = Null
    //     0x71407c: mov             x0, NULL
    // 0x714080: LeaveFrame
    //     0x714080: mov             SP, fp
    //     0x714084: ldp             fp, lr, [SP], #0x10
    // 0x714088: ret
    //     0x714088: ret             
    // 0x71408c: tbnz            w3, #4, #0x7140cc
    // 0x714090: LoadField: r2 = r0->field_2b
    //     0x714090: ldur            w2, [x0, #0x2b]
    // 0x714094: DecompressPointer r2
    //     0x714094: add             x2, x2, HEAP, lsl #32
    // 0x714098: cmp             w2, NULL
    // 0x71409c: b.eq            #0x7140cc
    // 0x7140a0: mov             x2, x1
    // 0x7140a4: r1 = Function '<anonymous closure>':.
    //     0x7140a4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4ba18] AnonymousClosure: (0x714114), in [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::didStopTrackingLastPointer (0x713ff8)
    //     0x7140a8: ldr             x1, [x1, #0xa18]
    // 0x7140ac: r0 = AllocateClosure()
    //     0x7140ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7140b0: r16 = <void?>
    //     0x7140b0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7140b4: ldr             lr, [fp, #0x18]
    // 0x7140b8: stp             lr, x16, [SP, #-0x10]!
    // 0x7140bc: SaveReg r0
    //     0x7140bc: str             x0, [SP, #-8]!
    // 0x7140c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7140c0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7140c4: r0 = invokeCallback()
    //     0x7140c4: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x7140c8: add             SP, SP, #0x18
    // 0x7140cc: ldr             x1, [fp, #0x18]
    // 0x7140d0: r2 = Instance__ForceState
    //     0x7140d0: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3fb58] Obj!_ForceState@b65bb1
    //     0x7140d4: ldr             x2, [x2, #0xb58]
    // 0x7140d8: StoreField: r1->field_4b = r2
    //     0x7140d8: stur            w2, [x1, #0x4b]
    // 0x7140dc: r0 = Null
    //     0x7140dc: mov             x0, NULL
    // 0x7140e0: LeaveFrame
    //     0x7140e0: mov             SP, fp
    //     0x7140e4: ldp             fp, lr, [SP], #0x10
    // 0x7140e8: ret
    //     0x7140e8: ret             
    // 0x7140ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7140ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7140f0: b               #0x71400c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x714114, size: 0xb0
    // 0x714114: EnterFrame
    //     0x714114: stp             fp, lr, [SP, #-0x10]!
    //     0x714118: mov             fp, SP
    // 0x71411c: AllocStack(0x10)
    //     0x71411c: sub             SP, SP, #0x10
    // 0x714120: SetupParameters()
    //     0x714120: ldr             x0, [fp, #0x10]
    //     0x714124: ldur            w1, [x0, #0x17]
    //     0x714128: add             x1, x1, HEAP, lsl #32
    // 0x71412c: CheckStackOverflow
    //     0x71412c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714130: cmp             SP, x16
    //     0x714134: b.ls            #0x7141ac
    // 0x714138: LoadField: r0 = r1->field_f
    //     0x714138: ldur            w0, [x1, #0xf]
    // 0x71413c: DecompressPointer r0
    //     0x71413c: add             x0, x0, HEAP, lsl #32
    // 0x714140: LoadField: r1 = r0->field_2b
    //     0x714140: ldur            w1, [x0, #0x2b]
    // 0x714144: DecompressPointer r1
    //     0x714144: add             x1, x1, HEAP, lsl #32
    // 0x714148: stur            x1, [fp, #-0x10]
    // 0x71414c: cmp             w1, NULL
    // 0x714150: b.eq            #0x7141b4
    // 0x714154: LoadField: r2 = r0->field_43
    //     0x714154: ldur            w2, [x0, #0x43]
    // 0x714158: DecompressPointer r2
    //     0x714158: add             x2, x2, HEAP, lsl #32
    // 0x71415c: r16 = Sentinel
    //     0x71415c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x714160: cmp             w2, w16
    // 0x714164: b.eq            #0x7141b8
    // 0x714168: LoadField: r0 = r2->field_b
    //     0x714168: ldur            w0, [x2, #0xb]
    // 0x71416c: DecompressPointer r0
    //     0x71416c: add             x0, x0, HEAP, lsl #32
    // 0x714170: stur            x0, [fp, #-8]
    // 0x714174: r0 = ForcePressDetails()
    //     0x714174: bl              #0x7141c4  ; AllocateForcePressDetailsStub -> ForcePressDetails (size=0xc)
    // 0x714178: mov             x1, x0
    // 0x71417c: ldur            x0, [fp, #-8]
    // 0x714180: StoreField: r1->field_7 = r0
    //     0x714180: stur            w0, [x1, #7]
    // 0x714184: ldur            x16, [fp, #-0x10]
    // 0x714188: stp             x1, x16, [SP, #-0x10]!
    // 0x71418c: ldur            x0, [fp, #-0x10]
    // 0x714190: ClosureCall
    //     0x714190: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x714194: ldur            x2, [x0, #0x1f]
    //     0x714198: blr             x2
    // 0x71419c: add             SP, SP, #0x10
    // 0x7141a0: LeaveFrame
    //     0x7141a0: mov             SP, fp
    //     0x7141a4: ldp             fp, lr, [SP], #0x10
    // 0x7141a8: ret
    //     0x7141a8: ret             
    // 0x7141ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7141ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7141b0: b               #0x714138
    // 0x7141b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7141b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7141b8: r9 = _lastPosition
    //     0x7141b8: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4ba08] Field <ForcePressGestureRecognizer._lastPosition@661518508>: late (offset: 0x44)
    //     0x7141bc: ldr             x9, [x9, #0xa08]
    // 0x7141c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7141c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x782450, size: 0xec
    // 0x782450: EnterFrame
    //     0x782450: stp             fp, lr, [SP, #-0x10]!
    //     0x782454: mov             fp, SP
    // 0x782458: CheckStackOverflow
    //     0x782458: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78245c: cmp             SP, x16
    //     0x782460: b.ls            #0x782534
    // 0x782464: ldr             x1, [fp, #0x10]
    // 0x782468: r0 = LoadClassIdInstr(r1)
    //     0x782468: ldur            x0, [x1, #-1]
    //     0x78246c: ubfx            x0, x0, #0xc, #0x14
    // 0x782470: SaveReg r1
    //     0x782470: str             x1, [SP, #-8]!
    // 0x782474: r0 = GDT[cid_x0 + 0xc61f]()
    //     0x782474: mov             x17, #0xc61f
    //     0x782478: add             lr, x0, x17
    //     0x78247c: ldr             lr, [x21, lr, lsl #3]
    //     0x782480: blr             lr
    // 0x782484: add             SP, SP, #8
    // 0x782488: mov             v1.16b, v0.16b
    // 0x78248c: d0 = 1.000000
    //     0x78248c: fmov            d0, #1.00000000
    // 0x782490: fcmp            d1, d0
    // 0x782494: b.vs            #0x7824b8
    // 0x782498: b.gt            #0x7824b8
    // 0x78249c: ldr             x16, [fp, #0x18]
    // 0x7824a0: r30 = Instance_GestureDisposition
    //     0x7824a0: add             lr, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x7824a4: ldr             lr, [lr, #0xeb8]
    // 0x7824a8: stp             lr, x16, [SP, #-0x10]!
    // 0x7824ac: r0 = resolve()
    //     0x7824ac: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x7824b0: add             SP, SP, #0x10
    // 0x7824b4: b               #0x782524
    // 0x7824b8: ldr             x0, [fp, #0x18]
    // 0x7824bc: ldr             x16, [fp, #0x10]
    // 0x7824c0: stp             x16, x0, [SP, #-0x10]!
    // 0x7824c4: r0 = addAllowedPointer()
    //     0x7824c4: bl              #0x782114  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0x7824c8: add             SP, SP, #0x10
    // 0x7824cc: ldr             x0, [fp, #0x18]
    // 0x7824d0: LoadField: r1 = r0->field_4b
    //     0x7824d0: ldur            w1, [x0, #0x4b]
    // 0x7824d4: DecompressPointer r1
    //     0x7824d4: add             x1, x1, HEAP, lsl #32
    // 0x7824d8: r16 = Instance__ForceState
    //     0x7824d8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3fb58] Obj!_ForceState@b65bb1
    //     0x7824dc: ldr             x16, [x16, #0xb58]
    // 0x7824e0: cmp             w1, w16
    // 0x7824e4: b.ne            #0x782524
    // 0x7824e8: r1 = Instance__ForceState
    //     0x7824e8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b9e8] Obj!_ForceState@b65bd1
    //     0x7824ec: ldr             x1, [x1, #0x9e8]
    // 0x7824f0: StoreField: r0->field_4b = r1
    //     0x7824f0: stur            w1, [x0, #0x4b]
    // 0x7824f4: ldr             x16, [fp, #0x10]
    // 0x7824f8: stp             x16, NULL, [SP, #-0x10]!
    // 0x7824fc: r0 = OffsetPair.fromEventPosition()
    //     0x7824fc: bl              #0x78253c  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::OffsetPair.fromEventPosition
    // 0x782500: add             SP, SP, #0x10
    // 0x782504: ldr             x1, [fp, #0x18]
    // 0x782508: StoreField: r1->field_43 = r0
    //     0x782508: stur            w0, [x1, #0x43]
    //     0x78250c: ldurb           w16, [x1, #-1]
    //     0x782510: ldurb           w17, [x0, #-1]
    //     0x782514: and             x16, x17, x16, lsr #2
    //     0x782518: tst             x16, HEAP, lsr #32
    //     0x78251c: b.eq            #0x782524
    //     0x782520: bl              #0xd6826c
    // 0x782524: r0 = Null
    //     0x782524: mov             x0, NULL
    // 0x782528: LeaveFrame
    //     0x782528: mov             SP, fp
    //     0x78252c: ldp             fp, lr, [SP], #0x10
    // 0x782530: ret
    //     0x782530: ret             
    // 0x782534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782538: b               #0x782464
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0x788cb8, size: 0x18
    // 0x788cb8: r4 = 0
    //     0x788cb8: mov             x4, #0
    // 0x788cbc: r1 = Function 'handleEvent':.
    //     0x788cbc: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b9e0] AnonymousClosure: (0x788cd0), in [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::handleEvent (0x788d1c)
    //     0x788cc0: ldr             x1, [x17, #0x9e0]
    // 0x788cc4: r24 = BuildNonGenericMethodExtractorStub
    //     0x788cc4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x788cc8: LoadField: r0 = r24->field_17
    //     0x788cc8: ldur            x0, [x24, #0x17]
    // 0x788ccc: br              x0
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x788cd0, size: 0x4c
    // 0x788cd0: EnterFrame
    //     0x788cd0: stp             fp, lr, [SP, #-0x10]!
    //     0x788cd4: mov             fp, SP
    // 0x788cd8: ldr             x0, [fp, #0x18]
    // 0x788cdc: LoadField: r1 = r0->field_17
    //     0x788cdc: ldur            w1, [x0, #0x17]
    // 0x788ce0: DecompressPointer r1
    //     0x788ce0: add             x1, x1, HEAP, lsl #32
    // 0x788ce4: CheckStackOverflow
    //     0x788ce4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x788ce8: cmp             SP, x16
    //     0x788cec: b.ls            #0x788d14
    // 0x788cf0: LoadField: r0 = r1->field_f
    //     0x788cf0: ldur            w0, [x1, #0xf]
    // 0x788cf4: DecompressPointer r0
    //     0x788cf4: add             x0, x0, HEAP, lsl #32
    // 0x788cf8: ldr             x16, [fp, #0x10]
    // 0x788cfc: stp             x16, x0, [SP, #-0x10]!
    // 0x788d00: r0 = handleEvent()
    //     0x788d00: bl              #0x788d1c  ; [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::handleEvent
    // 0x788d04: add             SP, SP, #0x10
    // 0x788d08: LeaveFrame
    //     0x788d08: mov             SP, fp
    //     0x788d0c: ldp             fp, lr, [SP], #0x10
    // 0x788d10: ret
    //     0x788d10: ret             
    // 0x788d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x788d14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x788d18: b               #0x788cf0
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x788d1c, size: 0x48c
    // 0x788d1c: EnterFrame
    //     0x788d1c: stp             fp, lr, [SP, #-0x10]!
    //     0x788d20: mov             fp, SP
    // 0x788d24: AllocStack(0x20)
    //     0x788d24: sub             SP, SP, #0x20
    // 0x788d28: CheckStackOverflow
    //     0x788d28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x788d2c: cmp             SP, x16
    //     0x788d30: b.ls            #0x789134
    // 0x788d34: r1 = 1
    //     0x788d34: mov             x1, #1
    // 0x788d38: r0 = AllocateContext()
    //     0x788d38: bl              #0xd68aa4  ; AllocateContextStub
    // 0x788d3c: mov             x4, x0
    // 0x788d40: ldr             x3, [fp, #0x18]
    // 0x788d44: stur            x4, [fp, #-8]
    // 0x788d48: StoreField: r4->field_f = r3
    //     0x788d48: stur            w3, [x4, #0xf]
    // 0x788d4c: ldr             x0, [fp, #0x10]
    // 0x788d50: r2 = Null
    //     0x788d50: mov             x2, NULL
    // 0x788d54: r1 = Null
    //     0x788d54: mov             x1, NULL
    // 0x788d58: cmp             w0, NULL
    // 0x788d5c: b.eq            #0x788d7c
    // 0x788d60: branchIfSmi(r0, 0x788d7c)
    //     0x788d60: tbz             w0, #0, #0x788d7c
    // 0x788d64: r3 = LoadClassIdInstr(r0)
    //     0x788d64: ldur            x3, [x0, #-1]
    //     0x788d68: ubfx            x3, x3, #0xc, #0x14
    // 0x788d6c: cmp             x3, #0x908
    // 0x788d70: b.eq            #0x788d84
    // 0x788d74: cmp             x3, #0xb3f
    // 0x788d78: b.eq            #0x788d84
    // 0x788d7c: r0 = false
    //     0x788d7c: add             x0, NULL, #0x30  ; false
    // 0x788d80: b               #0x788d88
    // 0x788d84: r0 = true
    //     0x788d84: add             x0, NULL, #0x20  ; true
    // 0x788d88: tbz             w0, #4, #0x788dcc
    // 0x788d8c: ldr             x0, [fp, #0x10]
    // 0x788d90: r2 = Null
    //     0x788d90: mov             x2, NULL
    // 0x788d94: r1 = Null
    //     0x788d94: mov             x1, NULL
    // 0x788d98: cmp             w0, NULL
    // 0x788d9c: b.eq            #0x788dbc
    // 0x788da0: branchIfSmi(r0, 0x788dbc)
    //     0x788da0: tbz             w0, #0, #0x788dbc
    // 0x788da4: r3 = LoadClassIdInstr(r0)
    //     0x788da4: ldur            x3, [x0, #-1]
    //     0x788da8: ubfx            x3, x3, #0xc, #0x14
    // 0x788dac: cmp             x3, #0x90a
    // 0x788db0: b.eq            #0x788dc4
    // 0x788db4: cmp             x3, #0xb41
    // 0x788db8: b.eq            #0x788dc4
    // 0x788dbc: r0 = false
    //     0x788dbc: add             x0, NULL, #0x30  ; false
    // 0x788dc0: b               #0x788dc8
    // 0x788dc4: r0 = true
    //     0x788dc4: add             x0, NULL, #0x20  ; true
    // 0x788dc8: tbnz            w0, #4, #0x789110
    // 0x788dcc: ldr             x1, [fp, #0x18]
    // 0x788dd0: ldr             x2, [fp, #0x10]
    // 0x788dd4: r0 = LoadClassIdInstr(r2)
    //     0x788dd4: ldur            x0, [x2, #-1]
    //     0x788dd8: ubfx            x0, x0, #0xc, #0x14
    // 0x788ddc: SaveReg r2
    //     0x788ddc: str             x2, [SP, #-8]!
    // 0x788de0: r0 = GDT[cid_x0 + 0xd50a]()
    //     0x788de0: mov             x17, #0xd50a
    //     0x788de4: add             lr, x0, x17
    //     0x788de8: ldr             lr, [x21, lr, lsl #3]
    //     0x788dec: blr             lr
    // 0x788df0: add             SP, SP, #8
    // 0x788df4: ldr             x1, [fp, #0x10]
    // 0x788df8: stur            d0, [fp, #-0x18]
    // 0x788dfc: r0 = LoadClassIdInstr(r1)
    //     0x788dfc: ldur            x0, [x1, #-1]
    //     0x788e00: ubfx            x0, x0, #0xc, #0x14
    // 0x788e04: SaveReg r1
    //     0x788e04: str             x1, [SP, #-8]!
    // 0x788e08: r0 = GDT[cid_x0 + 0xc61f]()
    //     0x788e08: mov             x17, #0xc61f
    //     0x788e0c: add             lr, x0, x17
    //     0x788e10: ldr             lr, [x21, lr, lsl #3]
    //     0x788e14: blr             lr
    // 0x788e18: add             SP, SP, #8
    // 0x788e1c: ldr             x1, [fp, #0x10]
    // 0x788e20: stur            d0, [fp, #-0x20]
    // 0x788e24: r0 = LoadClassIdInstr(r1)
    //     0x788e24: ldur            x0, [x1, #-1]
    //     0x788e28: ubfx            x0, x0, #0xc, #0x14
    // 0x788e2c: SaveReg r1
    //     0x788e2c: str             x1, [SP, #-8]!
    // 0x788e30: r0 = GDT[cid_x0 + 0x102c9]()
    //     0x788e30: mov             x17, #0x2c9
    //     0x788e34: movk            x17, #1, lsl #16
    //     0x788e38: add             lr, x0, x17
    //     0x788e3c: ldr             lr, [x21, lr, lsl #3]
    //     0x788e40: blr             lr
    // 0x788e44: add             SP, SP, #8
    // 0x788e48: ldr             x1, [fp, #0x18]
    // 0x788e4c: LoadField: r0 = r1->field_3f
    //     0x788e4c: ldur            w0, [x1, #0x3f]
    // 0x788e50: DecompressPointer r0
    //     0x788e50: add             x0, x0, HEAP, lsl #32
    // 0x788e54: ldur            d1, [fp, #-0x18]
    // 0x788e58: r2 = inline_Allocate_Double()
    //     0x788e58: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x788e5c: add             x2, x2, #0x10
    //     0x788e60: cmp             x3, x2
    //     0x788e64: b.ls            #0x78913c
    //     0x788e68: str             x2, [THR, #0x60]  ; THR::top
    //     0x788e6c: sub             x2, x2, #0xf
    //     0x788e70: mov             x3, #0xd108
    //     0x788e74: movk            x3, #3, lsl #16
    //     0x788e78: stur            x3, [x2, #-1]
    // 0x788e7c: StoreField: r2->field_7 = d1
    //     0x788e7c: stur            d1, [x2, #7]
    // 0x788e80: ldur            d1, [fp, #-0x20]
    // 0x788e84: r3 = inline_Allocate_Double()
    //     0x788e84: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x788e88: add             x3, x3, #0x10
    //     0x788e8c: cmp             x4, x3
    //     0x788e90: b.ls            #0x789158
    //     0x788e94: str             x3, [THR, #0x60]  ; THR::top
    //     0x788e98: sub             x3, x3, #0xf
    //     0x788e9c: mov             x4, #0xd108
    //     0x788ea0: movk            x4, #3, lsl #16
    //     0x788ea4: stur            x4, [x3, #-1]
    // 0x788ea8: StoreField: r3->field_7 = d1
    //     0x788ea8: stur            d1, [x3, #7]
    // 0x788eac: r4 = inline_Allocate_Double()
    //     0x788eac: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x788eb0: add             x4, x4, #0x10
    //     0x788eb4: cmp             x5, x4
    //     0x788eb8: b.ls            #0x78917c
    //     0x788ebc: str             x4, [THR, #0x60]  ; THR::top
    //     0x788ec0: sub             x4, x4, #0xf
    //     0x788ec4: mov             x5, #0xd108
    //     0x788ec8: movk            x5, #3, lsl #16
    //     0x788ecc: stur            x5, [x4, #-1]
    // 0x788ed0: StoreField: r4->field_7 = d0
    //     0x788ed0: stur            d0, [x4, #7]
    // 0x788ed4: stp             x2, x0, [SP, #-0x10]!
    // 0x788ed8: stp             x4, x3, [SP, #-0x10]!
    // 0x788edc: ClosureCall
    //     0x788edc: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x788ee0: ldur            x2, [x0, #0x1f]
    //     0x788ee4: blr             x2
    // 0x788ee8: add             SP, SP, #0x20
    // 0x788eec: stur            x0, [fp, #-0x10]
    // 0x788ef0: ldr             x16, [fp, #0x10]
    // 0x788ef4: stp             x16, NULL, [SP, #-0x10]!
    // 0x788ef8: r0 = OffsetPair.fromEventPosition()
    //     0x788ef8: bl              #0x78253c  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::OffsetPair.fromEventPosition
    // 0x788efc: add             SP, SP, #0x10
    // 0x788f00: ldr             x1, [fp, #0x18]
    // 0x788f04: StoreField: r1->field_43 = r0
    //     0x788f04: stur            w0, [x1, #0x43]
    //     0x788f08: ldurb           w16, [x1, #-1]
    //     0x788f0c: ldurb           w17, [x0, #-1]
    //     0x788f10: and             x16, x17, x16, lsr #2
    //     0x788f14: tst             x16, HEAP, lsr #32
    //     0x788f18: b.eq            #0x788f20
    //     0x788f1c: bl              #0xd6826c
    // 0x788f20: ldur            x0, [fp, #-0x10]
    // 0x788f24: StoreField: r1->field_47 = r0
    //     0x788f24: stur            w0, [x1, #0x47]
    //     0x788f28: tbz             w0, #0, #0x788f44
    //     0x788f2c: ldurb           w16, [x1, #-1]
    //     0x788f30: ldurb           w17, [x0, #-1]
    //     0x788f34: and             x16, x17, x16, lsr #2
    //     0x788f38: tst             x16, HEAP, lsr #32
    //     0x788f3c: b.eq            #0x788f44
    //     0x788f40: bl              #0xd6826c
    // 0x788f44: LoadField: r0 = r1->field_4b
    //     0x788f44: ldur            w0, [x1, #0x4b]
    // 0x788f48: DecompressPointer r0
    //     0x788f48: add             x0, x0, HEAP, lsl #32
    // 0x788f4c: r16 = Instance__ForceState
    //     0x788f4c: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b9e8] Obj!_ForceState@b65bd1
    //     0x788f50: ldr             x16, [x16, #0x9e8]
    // 0x788f54: cmp             w0, w16
    // 0x788f58: b.ne            #0x789088
    // 0x788f5c: ldur            x0, [fp, #-0x10]
    // 0x788f60: d0 = 0.400000
    //     0x788f60: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x788f64: ldr             d0, [x17, #0x148]
    // 0x788f68: cmp             w0, NULL
    // 0x788f6c: b.eq            #0x7891a0
    // 0x788f70: LoadField: d1 = r0->field_7
    //     0x788f70: ldur            d1, [x0, #7]
    // 0x788f74: fcmp            d1, d0
    // 0x788f78: b.vs            #0x788fa4
    // 0x788f7c: b.le            #0x788fa4
    // 0x788f80: r2 = Instance__ForceState
    //     0x788f80: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b9f0] Obj!_ForceState@b65bf1
    //     0x788f84: ldr             x2, [x2, #0x9f0]
    // 0x788f88: StoreField: r1->field_4b = r2
    //     0x788f88: stur            w2, [x1, #0x4b]
    // 0x788f8c: r16 = Instance_GestureDisposition
    //     0x788f8c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x788f90: ldr             x16, [x16, #0xed0]
    // 0x788f94: stp             x16, x1, [SP, #-0x10]!
    // 0x788f98: r0 = resolve()
    //     0x788f98: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x788f9c: add             SP, SP, #0x10
    // 0x788fa0: b               #0x789088
    // 0x788fa4: ldr             x2, [fp, #0x10]
    // 0x788fa8: r0 = LoadClassIdInstr(r2)
    //     0x788fa8: ldur            x0, [x2, #-1]
    //     0x788fac: ubfx            x0, x0, #0xc, #0x14
    // 0x788fb0: SaveReg r2
    //     0x788fb0: str             x2, [SP, #-8]!
    // 0x788fb4: r0 = GDT[cid_x0 + 0x9887]()
    //     0x788fb4: mov             x17, #0x9887
    //     0x788fb8: add             lr, x0, x17
    //     0x788fbc: ldr             lr, [x21, lr, lsl #3]
    //     0x788fc0: blr             lr
    // 0x788fc4: add             SP, SP, #8
    // 0x788fc8: LoadField: d0 = r0->field_7
    //     0x788fc8: ldur            d0, [x0, #7]
    // 0x788fcc: fmul            d1, d0, d0
    // 0x788fd0: LoadField: d0 = r0->field_f
    //     0x788fd0: ldur            d0, [x0, #0xf]
    // 0x788fd4: fmul            d2, d0, d0
    // 0x788fd8: fadd            d0, d1, d2
    // 0x788fdc: ldr             x1, [fp, #0x10]
    // 0x788fe0: stur            d0, [fp, #-0x18]
    // 0x788fe4: r0 = LoadClassIdInstr(r1)
    //     0x788fe4: ldur            x0, [x1, #-1]
    //     0x788fe8: ubfx            x0, x0, #0xc, #0x14
    // 0x788fec: SaveReg r1
    //     0x788fec: str             x1, [SP, #-8]!
    // 0x788ff0: r0 = GDT[cid_x0 + -0xf60]()
    //     0x788ff0: sub             lr, x0, #0xf60
    //     0x788ff4: ldr             lr, [x21, lr, lsl #3]
    //     0x788ff8: blr             lr
    // 0x788ffc: add             SP, SP, #8
    // 0x789000: mov             x1, x0
    // 0x789004: ldr             x0, [fp, #0x18]
    // 0x789008: LoadField: r2 = r0->field_7
    //     0x789008: ldur            w2, [x0, #7]
    // 0x78900c: DecompressPointer r2
    //     0x78900c: add             x2, x2, HEAP, lsl #32
    // 0x789010: LoadField: r3 = r1->field_7
    //     0x789010: ldur            x3, [x1, #7]
    // 0x789014: cmp             x3, #2
    // 0x789018: b.gt            #0x789034
    // 0x78901c: cmp             x3, #1
    // 0x789020: b.gt            #0x789034
    // 0x789024: cmp             x3, #0
    // 0x789028: b.le            #0x789034
    // 0x78902c: d1 = 1.000000
    //     0x78902c: fmov            d1, #1.00000000
    // 0x789030: b               #0x789064
    // 0x789034: cmp             w2, NULL
    // 0x789038: b.ne            #0x789044
    // 0x78903c: r1 = Null
    //     0x78903c: mov             x1, NULL
    // 0x789040: b               #0x78904c
    // 0x789044: LoadField: r1 = r2->field_7
    //     0x789044: ldur            w1, [x2, #7]
    // 0x789048: DecompressPointer r1
    //     0x789048: add             x1, x1, HEAP, lsl #32
    // 0x78904c: cmp             w1, NULL
    // 0x789050: b.ne            #0x78905c
    // 0x789054: d0 = 18.000000
    //     0x789054: fmov            d0, #18.00000000
    // 0x789058: b               #0x789060
    // 0x78905c: LoadField: d0 = r1->field_7
    //     0x78905c: ldur            d0, [x1, #7]
    // 0x789060: mov             v1.16b, v0.16b
    // 0x789064: ldur            d0, [fp, #-0x18]
    // 0x789068: fcmp            d0, d1
    // 0x78906c: b.vs            #0x789088
    // 0x789070: b.le            #0x789088
    // 0x789074: r16 = Instance_GestureDisposition
    //     0x789074: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x789078: ldr             x16, [x16, #0xeb8]
    // 0x78907c: stp             x16, x0, [SP, #-0x10]!
    // 0x789080: r0 = resolve()
    //     0x789080: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x789084: add             SP, SP, #0x10
    // 0x789088: ldur            x0, [fp, #-0x10]
    // 0x78908c: d0 = 0.400000
    //     0x78908c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x789090: ldr             d0, [x17, #0x148]
    // 0x789094: cmp             w0, NULL
    // 0x789098: b.eq            #0x7891a4
    // 0x78909c: LoadField: d1 = r0->field_7
    //     0x78909c: ldur            d1, [x0, #7]
    // 0x7890a0: fcmp            d1, d0
    // 0x7890a4: b.vs            #0x789110
    // 0x7890a8: b.le            #0x789110
    // 0x7890ac: ldr             x0, [fp, #0x18]
    // 0x7890b0: LoadField: r1 = r0->field_4b
    //     0x7890b0: ldur            w1, [x0, #0x4b]
    // 0x7890b4: DecompressPointer r1
    //     0x7890b4: add             x1, x1, HEAP, lsl #32
    // 0x7890b8: r16 = Instance__ForceState
    //     0x7890b8: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b9f8] Obj!_ForceState@b65c11
    //     0x7890bc: ldr             x16, [x16, #0x9f8]
    // 0x7890c0: cmp             w1, w16
    // 0x7890c4: b.ne            #0x789110
    // 0x7890c8: r1 = Instance__ForceState
    //     0x7890c8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b9f0] Obj!_ForceState@b65bf1
    //     0x7890cc: ldr             x1, [x1, #0x9f0]
    // 0x7890d0: StoreField: r0->field_4b = r1
    //     0x7890d0: stur            w1, [x0, #0x4b]
    // 0x7890d4: LoadField: r1 = r0->field_1f
    //     0x7890d4: ldur            w1, [x0, #0x1f]
    // 0x7890d8: DecompressPointer r1
    //     0x7890d8: add             x1, x1, HEAP, lsl #32
    // 0x7890dc: cmp             w1, NULL
    // 0x7890e0: b.eq            #0x789110
    // 0x7890e4: ldur            x2, [fp, #-8]
    // 0x7890e8: r1 = Function '<anonymous closure>':.
    //     0x7890e8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4ba00] AnonymousClosure: (0x789300), in [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::handleEvent (0x788d1c)
    //     0x7890ec: ldr             x1, [x1, #0xa00]
    // 0x7890f0: r0 = AllocateClosure()
    //     0x7890f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7890f4: r16 = <void?>
    //     0x7890f4: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7890f8: ldr             lr, [fp, #0x18]
    // 0x7890fc: stp             lr, x16, [SP, #-0x10]!
    // 0x789100: SaveReg r0
    //     0x789100: str             x0, [SP, #-8]!
    // 0x789104: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x789104: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x789108: r0 = invokeCallback()
    //     0x789108: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x78910c: add             SP, SP, #0x18
    // 0x789110: ldr             x16, [fp, #0x18]
    // 0x789114: ldr             lr, [fp, #0x10]
    // 0x789118: stp             lr, x16, [SP, #-0x10]!
    // 0x78911c: r0 = stopTrackingIfPointerNoLongerDown()
    //     0x78911c: bl              #0x7891a8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0x789120: add             SP, SP, #0x10
    // 0x789124: r0 = Null
    //     0x789124: mov             x0, NULL
    // 0x789128: LeaveFrame
    //     0x789128: mov             SP, fp
    //     0x78912c: ldp             fp, lr, [SP], #0x10
    // 0x789130: ret
    //     0x789130: ret             
    // 0x789134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x789134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x789138: b               #0x788d34
    // 0x78913c: stp             q0, q1, [SP, #-0x20]!
    // 0x789140: stp             x0, x1, [SP, #-0x10]!
    // 0x789144: r0 = AllocateDouble()
    //     0x789144: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x789148: mov             x2, x0
    // 0x78914c: ldp             x0, x1, [SP], #0x10
    // 0x789150: ldp             q0, q1, [SP], #0x20
    // 0x789154: b               #0x788e7c
    // 0x789158: stp             q0, q1, [SP, #-0x20]!
    // 0x78915c: stp             x1, x2, [SP, #-0x10]!
    // 0x789160: SaveReg r0
    //     0x789160: str             x0, [SP, #-8]!
    // 0x789164: r0 = AllocateDouble()
    //     0x789164: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x789168: mov             x3, x0
    // 0x78916c: RestoreReg r0
    //     0x78916c: ldr             x0, [SP], #8
    // 0x789170: ldp             x1, x2, [SP], #0x10
    // 0x789174: ldp             q0, q1, [SP], #0x20
    // 0x789178: b               #0x788ea8
    // 0x78917c: SaveReg d0
    //     0x78917c: str             q0, [SP, #-0x10]!
    // 0x789180: stp             x2, x3, [SP, #-0x10]!
    // 0x789184: stp             x0, x1, [SP, #-0x10]!
    // 0x789188: r0 = AllocateDouble()
    //     0x789188: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78918c: mov             x4, x0
    // 0x789190: ldp             x0, x1, [SP], #0x10
    // 0x789194: ldp             x2, x3, [SP], #0x10
    // 0x789198: RestoreReg d0
    //     0x789198: ldr             q0, [SP], #0x10
    // 0x78919c: b               #0x788ed0
    // 0x7891a0: r0 = NullErrorSharedWithFPURegs()
    //     0x7891a0: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x7891a4: r0 = NullErrorSharedWithFPURegs()
    //     0x7891a4: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x789300, size: 0xb0
    // 0x789300: EnterFrame
    //     0x789300: stp             fp, lr, [SP, #-0x10]!
    //     0x789304: mov             fp, SP
    // 0x789308: AllocStack(0x10)
    //     0x789308: sub             SP, SP, #0x10
    // 0x78930c: SetupParameters()
    //     0x78930c: ldr             x0, [fp, #0x10]
    //     0x789310: ldur            w1, [x0, #0x17]
    //     0x789314: add             x1, x1, HEAP, lsl #32
    // 0x789318: CheckStackOverflow
    //     0x789318: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78931c: cmp             SP, x16
    //     0x789320: b.ls            #0x789398
    // 0x789324: LoadField: r0 = r1->field_f
    //     0x789324: ldur            w0, [x1, #0xf]
    // 0x789328: DecompressPointer r0
    //     0x789328: add             x0, x0, HEAP, lsl #32
    // 0x78932c: LoadField: r1 = r0->field_1f
    //     0x78932c: ldur            w1, [x0, #0x1f]
    // 0x789330: DecompressPointer r1
    //     0x789330: add             x1, x1, HEAP, lsl #32
    // 0x789334: stur            x1, [fp, #-0x10]
    // 0x789338: cmp             w1, NULL
    // 0x78933c: b.eq            #0x7893a0
    // 0x789340: LoadField: r2 = r0->field_43
    //     0x789340: ldur            w2, [x0, #0x43]
    // 0x789344: DecompressPointer r2
    //     0x789344: add             x2, x2, HEAP, lsl #32
    // 0x789348: r16 = Sentinel
    //     0x789348: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78934c: cmp             w2, w16
    // 0x789350: b.eq            #0x7893a4
    // 0x789354: LoadField: r0 = r2->field_b
    //     0x789354: ldur            w0, [x2, #0xb]
    // 0x789358: DecompressPointer r0
    //     0x789358: add             x0, x0, HEAP, lsl #32
    // 0x78935c: stur            x0, [fp, #-8]
    // 0x789360: r0 = ForcePressDetails()
    //     0x789360: bl              #0x7141c4  ; AllocateForcePressDetailsStub -> ForcePressDetails (size=0xc)
    // 0x789364: mov             x1, x0
    // 0x789368: ldur            x0, [fp, #-8]
    // 0x78936c: StoreField: r1->field_7 = r0
    //     0x78936c: stur            w0, [x1, #7]
    // 0x789370: ldur            x16, [fp, #-0x10]
    // 0x789374: stp             x1, x16, [SP, #-0x10]!
    // 0x789378: ldur            x0, [fp, #-0x10]
    // 0x78937c: ClosureCall
    //     0x78937c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x789380: ldur            x2, [x0, #0x1f]
    //     0x789384: blr             x2
    // 0x789388: add             SP, SP, #0x10
    // 0x78938c: LeaveFrame
    //     0x78938c: mov             SP, fp
    //     0x789390: ldp             fp, lr, [SP], #0x10
    // 0x789394: ret
    //     0x789394: ret             
    // 0x789398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x789398: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78939c: b               #0x789324
    // 0x7893a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7893a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7893a4: r9 = _lastPosition
    //     0x7893a4: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4ba08] Field <ForcePressGestureRecognizer._lastPosition@661518508>: late (offset: 0x44)
    //     0x7893a8: ldr             x9, [x9, #0xa08]
    // 0x7893ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7893ac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ ForcePressGestureRecognizer(/* No info */) {
    // ** addr: 0x88845c, size: 0x84
    // 0x88845c: EnterFrame
    //     0x88845c: stp             fp, lr, [SP, #-0x10]!
    //     0x888460: mov             fp, SP
    // 0x888464: r2 = Sentinel
    //     0x888464: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x888468: r1 = Instance__ForceState
    //     0x888468: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fb58] Obj!_ForceState@b65bb1
    //     0x88846c: ldr             x1, [x1, #0xb58]
    // 0x888470: r0 = Closure: (double, double, double) => double from Function '_inverseLerp@661518508': static.
    //     0x888470: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fb60] Closure: (double, double, double) => double from Function '_inverseLerp@661518508': static. (0x7fe6e20884e0)
    //     0x888474: ldr             x0, [x0, #0xb60]
    // 0x888478: d1 = 0.400000
    //     0x888478: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x88847c: ldr             d1, [x17, #0x148]
    // 0x888480: d0 = 0.850000
    //     0x888480: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fb68] IMM: double(0.85) from 0x3feb333333333333
    //     0x888484: ldr             d0, [x17, #0xb68]
    // 0x888488: CheckStackOverflow
    //     0x888488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x88848c: cmp             SP, x16
    //     0x888490: b.ls            #0x8884d8
    // 0x888494: ldr             x3, [fp, #0x10]
    // 0x888498: StoreField: r3->field_43 = r2
    //     0x888498: stur            w2, [x3, #0x43]
    // 0x88849c: StoreField: r3->field_47 = r2
    //     0x88849c: stur            w2, [x3, #0x47]
    // 0x8884a0: StoreField: r3->field_4b = r1
    //     0x8884a0: stur            w1, [x3, #0x4b]
    // 0x8884a4: StoreField: r3->field_2f = d1
    //     0x8884a4: stur            d1, [x3, #0x2f]
    // 0x8884a8: StoreField: r3->field_37 = d0
    //     0x8884a8: stur            d0, [x3, #0x37]
    // 0x8884ac: StoreField: r3->field_3f = r0
    //     0x8884ac: stur            w0, [x3, #0x3f]
    // 0x8884b0: stp             NULL, x3, [SP, #-0x10]!
    // 0x8884b4: SaveReg rNULL
    //     0x8884b4: str             NULL, [SP, #-8]!
    // 0x8884b8: r4 = const [0, 0x3, 0x3, 0x1, kind, 0x1, supportedDevices, 0x2, null]
    //     0x8884b8: add             x4, PP, #0x21, lsl #12  ; [pp+0x214b0] List(9) [0, 0x3, 0x3, 0x1, "kind", 0x1, "supportedDevices", 0x2, Null]
    //     0x8884bc: ldr             x4, [x4, #0x4b0]
    // 0x8884c0: r0 = OneSequenceGestureRecognizer()
    //     0x8884c0: bl              #0x6d3ef4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0x8884c4: add             SP, SP, #0x18
    // 0x8884c8: r0 = Null
    //     0x8884c8: mov             x0, NULL
    // 0x8884cc: LeaveFrame
    //     0x8884cc: mov             SP, fp
    //     0x8884d0: ldp             fp, lr, [SP], #0x10
    // 0x8884d4: ret
    //     0x8884d4: ret             
    // 0x8884d8: r0 = StackOverflowSharedWithFPURegs()
    //     0x8884d8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x8884dc: b               #0x888494
  }
  [closure] static double _inverseLerp(dynamic, double, double, double) {
    // ** addr: 0x8884e0, size: 0x7c
    // 0x8884e0: EnterFrame
    //     0x8884e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8884e4: mov             fp, SP
    // 0x8884e8: CheckStackOverflow
    //     0x8884e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8884ec: cmp             SP, x16
    //     0x8884f0: b.ls            #0x888544
    // 0x8884f4: ldr             x16, [fp, #0x20]
    // 0x8884f8: ldr             lr, [fp, #0x18]
    // 0x8884fc: stp             lr, x16, [SP, #-0x10]!
    // 0x888500: ldr             x16, [fp, #0x10]
    // 0x888504: SaveReg r16
    //     0x888504: str             x16, [SP, #-8]!
    // 0x888508: r0 = _inverseLerp()
    //     0x888508: bl              #0x88855c  ; [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::_inverseLerp
    // 0x88850c: add             SP, SP, #0x18
    // 0x888510: r0 = inline_Allocate_Double()
    //     0x888510: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x888514: add             x0, x0, #0x10
    //     0x888518: cmp             x1, x0
    //     0x88851c: b.ls            #0x88854c
    //     0x888520: str             x0, [THR, #0x60]  ; THR::top
    //     0x888524: sub             x0, x0, #0xf
    //     0x888528: mov             x1, #0xd108
    //     0x88852c: movk            x1, #3, lsl #16
    //     0x888530: stur            x1, [x0, #-1]
    // 0x888534: StoreField: r0->field_7 = d0
    //     0x888534: stur            d0, [x0, #7]
    // 0x888538: LeaveFrame
    //     0x888538: mov             SP, fp
    //     0x88853c: ldp             fp, lr, [SP], #0x10
    // 0x888540: ret
    //     0x888540: ret             
    // 0x888544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x888544: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x888548: b               #0x8884f4
    // 0x88854c: SaveReg d0
    //     0x88854c: str             q0, [SP, #-0x10]!
    // 0x888550: r0 = AllocateDouble()
    //     0x888550: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x888554: RestoreReg d0
    //     0x888554: ldr             q0, [SP], #0x10
    // 0x888558: b               #0x888534
  }
  static _ _inverseLerp(/* No info */) {
    // ** addr: 0x88855c, size: 0x80
    // 0x88855c: ldr             x0, [SP, #0x10]
    // 0x888560: LoadField: d1 = r0->field_7
    //     0x888560: ldur            d1, [x0, #7]
    // 0x888564: ldr             x0, [SP]
    // 0x888568: LoadField: d2 = r0->field_7
    //     0x888568: ldur            d2, [x0, #7]
    // 0x88856c: fsub            d3, d2, d1
    // 0x888570: ldr             x0, [SP, #8]
    // 0x888574: LoadField: d2 = r0->field_7
    //     0x888574: ldur            d2, [x0, #7]
    // 0x888578: fsub            d4, d2, d1
    // 0x88857c: fdiv            d1, d3, d4
    // 0x888580: fcmp            d1, d1
    // 0x888584: b.vs            #0x8885d4
    // 0x888588: d2 = 0.000000
    //     0x888588: eor             v2.16b, v2.16b, v2.16b
    // 0x88858c: fcmp            d1, d2
    // 0x888590: b.vs            #0x8885a0
    // 0x888594: b.ge            #0x8885a0
    // 0x888598: d2 = 0.000000
    //     0x888598: eor             v2.16b, v2.16b, v2.16b
    // 0x88859c: b               #0x8885cc
    // 0x8885a0: d2 = 1.000000
    //     0x8885a0: fmov            d2, #1.00000000
    // 0x8885a4: fcmp            d1, d2
    // 0x8885a8: b.vs            #0x8885b8
    // 0x8885ac: b.le            #0x8885b8
    // 0x8885b0: d2 = 1.000000
    //     0x8885b0: fmov            d2, #1.00000000
    // 0x8885b4: b               #0x8885cc
    // 0x8885b8: fcmp            d1, d1
    // 0x8885bc: b.vc            #0x8885c8
    // 0x8885c0: d2 = 1.000000
    //     0x8885c0: fmov            d2, #1.00000000
    // 0x8885c4: b               #0x8885cc
    // 0x8885c8: mov             v2.16b, v1.16b
    // 0x8885cc: mov             v0.16b, v2.16b
    // 0x8885d0: b               #0x8885d8
    // 0x8885d4: mov             v0.16b, v1.16b
    // 0x8885d8: ret
    //     0x8885d8: ret             
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdae6c, size: 0xb8
    // 0xbdae6c: EnterFrame
    //     0xbdae6c: stp             fp, lr, [SP, #-0x10]!
    //     0xbdae70: mov             fp, SP
    // 0xbdae74: CheckStackOverflow
    //     0xbdae74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdae78: cmp             SP, x16
    //     0xbdae7c: b.ls            #0xbdaf1c
    // 0xbdae80: r1 = 1
    //     0xbdae80: mov             x1, #1
    // 0xbdae84: r0 = AllocateContext()
    //     0xbdae84: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbdae88: mov             x1, x0
    // 0xbdae8c: ldr             x0, [fp, #0x18]
    // 0xbdae90: StoreField: r1->field_f = r0
    //     0xbdae90: stur            w0, [x1, #0xf]
    // 0xbdae94: LoadField: r2 = r0->field_4b
    //     0xbdae94: ldur            w2, [x0, #0x4b]
    // 0xbdae98: DecompressPointer r2
    //     0xbdae98: add             x2, x2, HEAP, lsl #32
    // 0xbdae9c: r16 = Instance__ForceState
    //     0xbdae9c: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b9e8] Obj!_ForceState@b65bd1
    //     0xbdaea0: ldr             x16, [x16, #0x9e8]
    // 0xbdaea4: cmp             w2, w16
    // 0xbdaea8: b.ne            #0xbdaec0
    // 0xbdaeac: r2 = Instance__ForceState
    //     0xbdaeac: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b9f8] Obj!_ForceState@b65c11
    //     0xbdaeb0: ldr             x2, [x2, #0x9f8]
    // 0xbdaeb4: StoreField: r0->field_4b = r2
    //     0xbdaeb4: stur            w2, [x0, #0x4b]
    // 0xbdaeb8: r2 = Instance__ForceState
    //     0xbdaeb8: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b9f8] Obj!_ForceState@b65c11
    //     0xbdaebc: ldr             x2, [x2, #0x9f8]
    // 0xbdaec0: LoadField: r3 = r0->field_1f
    //     0xbdaec0: ldur            w3, [x0, #0x1f]
    // 0xbdaec4: DecompressPointer r3
    //     0xbdaec4: add             x3, x3, HEAP, lsl #32
    // 0xbdaec8: cmp             w3, NULL
    // 0xbdaecc: b.eq            #0xbdaf0c
    // 0xbdaed0: r16 = Instance__ForceState
    //     0xbdaed0: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b9f0] Obj!_ForceState@b65bf1
    //     0xbdaed4: ldr             x16, [x16, #0x9f0]
    // 0xbdaed8: cmp             w2, w16
    // 0xbdaedc: b.ne            #0xbdaf0c
    // 0xbdaee0: mov             x2, x1
    // 0xbdaee4: r1 = Function '<anonymous closure>':.
    //     0xbdaee4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4ba20] AnonymousClosure: (0xbdaf24), in [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::acceptGesture (0xbdae6c)
    //     0xbdaee8: ldr             x1, [x1, #0xa20]
    // 0xbdaeec: r0 = AllocateClosure()
    //     0xbdaeec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbdaef0: r16 = <void?>
    //     0xbdaef0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xbdaef4: ldr             lr, [fp, #0x18]
    // 0xbdaef8: stp             lr, x16, [SP, #-0x10]!
    // 0xbdaefc: SaveReg r0
    //     0xbdaefc: str             x0, [SP, #-8]!
    // 0xbdaf00: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbdaf00: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbdaf04: r0 = invokeCallback()
    //     0xbdaf04: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xbdaf08: add             SP, SP, #0x18
    // 0xbdaf0c: r0 = Null
    //     0xbdaf0c: mov             x0, NULL
    // 0xbdaf10: LeaveFrame
    //     0xbdaf10: mov             SP, fp
    //     0xbdaf14: ldp             fp, lr, [SP], #0x10
    // 0xbdaf18: ret
    //     0xbdaf18: ret             
    // 0xbdaf1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdaf1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdaf20: b               #0xbdae80
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xbdaf24, size: 0xd0
    // 0xbdaf24: EnterFrame
    //     0xbdaf24: stp             fp, lr, [SP, #-0x10]!
    //     0xbdaf28: mov             fp, SP
    // 0xbdaf2c: AllocStack(0x10)
    //     0xbdaf2c: sub             SP, SP, #0x10
    // 0xbdaf30: SetupParameters()
    //     0xbdaf30: ldr             x0, [fp, #0x10]
    //     0xbdaf34: ldur            w1, [x0, #0x17]
    //     0xbdaf38: add             x1, x1, HEAP, lsl #32
    // 0xbdaf3c: CheckStackOverflow
    //     0xbdaf3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdaf40: cmp             SP, x16
    //     0xbdaf44: b.ls            #0xbdafd0
    // 0xbdaf48: LoadField: r0 = r1->field_f
    //     0xbdaf48: ldur            w0, [x1, #0xf]
    // 0xbdaf4c: DecompressPointer r0
    //     0xbdaf4c: add             x0, x0, HEAP, lsl #32
    // 0xbdaf50: LoadField: r1 = r0->field_1f
    //     0xbdaf50: ldur            w1, [x0, #0x1f]
    // 0xbdaf54: DecompressPointer r1
    //     0xbdaf54: add             x1, x1, HEAP, lsl #32
    // 0xbdaf58: stur            x1, [fp, #-0x10]
    // 0xbdaf5c: cmp             w1, NULL
    // 0xbdaf60: b.eq            #0xbdafd8
    // 0xbdaf64: LoadField: r2 = r0->field_47
    //     0xbdaf64: ldur            w2, [x0, #0x47]
    // 0xbdaf68: DecompressPointer r2
    //     0xbdaf68: add             x2, x2, HEAP, lsl #32
    // 0xbdaf6c: r16 = Sentinel
    //     0xbdaf6c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdaf70: cmp             w2, w16
    // 0xbdaf74: b.eq            #0xbdafdc
    // 0xbdaf78: LoadField: r2 = r0->field_43
    //     0xbdaf78: ldur            w2, [x0, #0x43]
    // 0xbdaf7c: DecompressPointer r2
    //     0xbdaf7c: add             x2, x2, HEAP, lsl #32
    // 0xbdaf80: r16 = Sentinel
    //     0xbdaf80: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdaf84: cmp             w2, w16
    // 0xbdaf88: b.eq            #0xbdafe8
    // 0xbdaf8c: LoadField: r0 = r2->field_b
    //     0xbdaf8c: ldur            w0, [x2, #0xb]
    // 0xbdaf90: DecompressPointer r0
    //     0xbdaf90: add             x0, x0, HEAP, lsl #32
    // 0xbdaf94: stur            x0, [fp, #-8]
    // 0xbdaf98: r0 = ForcePressDetails()
    //     0xbdaf98: bl              #0x7141c4  ; AllocateForcePressDetailsStub -> ForcePressDetails (size=0xc)
    // 0xbdaf9c: mov             x1, x0
    // 0xbdafa0: ldur            x0, [fp, #-8]
    // 0xbdafa4: StoreField: r1->field_7 = r0
    //     0xbdafa4: stur            w0, [x1, #7]
    // 0xbdafa8: ldur            x16, [fp, #-0x10]
    // 0xbdafac: stp             x1, x16, [SP, #-0x10]!
    // 0xbdafb0: ldur            x0, [fp, #-0x10]
    // 0xbdafb4: ClosureCall
    //     0xbdafb4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbdafb8: ldur            x2, [x0, #0x1f]
    //     0xbdafbc: blr             x2
    // 0xbdafc0: add             SP, SP, #0x10
    // 0xbdafc4: LeaveFrame
    //     0xbdafc4: mov             SP, fp
    //     0xbdafc8: ldp             fp, lr, [SP], #0x10
    // 0xbdafcc: ret
    //     0xbdafcc: ret             
    // 0xbdafd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdafd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdafd4: b               #0xbdaf48
    // 0xbdafd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdafd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbdafdc: r9 = _lastPressure
    //     0xbdafdc: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4ba28] Field <ForcePressGestureRecognizer._lastPressure@661518508>: late (offset: 0x48)
    //     0xbdafe0: ldr             x9, [x9, #0xa28]
    // 0xbdafe4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdafe4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbdafe8: r9 = _lastPosition
    //     0xbdafe8: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4ba08] Field <ForcePressGestureRecognizer._lastPosition@661518508>: late (offset: 0x44)
    //     0xbdafec: ldr             x9, [x9, #0xa08]
    // 0xbdaff0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdaff0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee27c, size: 0x6c
    // 0xcee27c: EnterFrame
    //     0xcee27c: stp             fp, lr, [SP, #-0x10]!
    //     0xcee280: mov             fp, SP
    // 0xcee284: CheckStackOverflow
    //     0xcee284: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee288: cmp             SP, x16
    //     0xcee28c: b.ls            #0xcee2e0
    // 0xcee290: ldr             x2, [fp, #0x10]
    // 0xcee294: r0 = BoxInt64Instr(r2)
    //     0xcee294: sbfiz           x0, x2, #1, #0x1f
    //     0xcee298: cmp             x2, x0, asr #1
    //     0xcee29c: b.eq            #0xcee2a8
    //     0xcee2a0: bl              #0xd69bb8
    //     0xcee2a4: stur            x2, [x0, #7]
    // 0xcee2a8: ldr             x16, [fp, #0x18]
    // 0xcee2ac: stp             x0, x16, [SP, #-0x10]!
    // 0xcee2b0: r0 = stopTrackingPointer()
    //     0xcee2b0: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xcee2b4: add             SP, SP, #0x10
    // 0xcee2b8: ldr             x16, [fp, #0x18]
    // 0xcee2bc: SaveReg r16
    //     0xcee2bc: str             x16, [SP, #-8]!
    // 0xcee2c0: ldr             x0, [fp, #0x10]
    // 0xcee2c4: SaveReg r0
    //     0xcee2c4: str             x0, [SP, #-8]!
    // 0xcee2c8: r0 = didStopTrackingLastPointer()
    //     0xcee2c8: bl              #0x713ff8  ; [package:flutter/src/gestures/force_press.dart] ForcePressGestureRecognizer::didStopTrackingLastPointer
    // 0xcee2cc: add             SP, SP, #0x10
    // 0xcee2d0: r0 = Null
    //     0xcee2d0: mov             x0, NULL
    // 0xcee2d4: LeaveFrame
    //     0xcee2d4: mov             SP, fp
    //     0xcee2d8: ldp             fp, lr, [SP], #0x10
    // 0xcee2dc: ret
    //     0xcee2dc: ret             
    // 0xcee2e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee2e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee2e4: b               #0xcee290
  }
}

// class id: 5980, size: 0x14, field offset: 0x14
enum _ForceState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15d44, size: 0x5c
    // 0xb15d44: EnterFrame
    //     0xb15d44: stp             fp, lr, [SP, #-0x10]!
    //     0xb15d48: mov             fp, SP
    // 0xb15d4c: CheckStackOverflow
    //     0xb15d4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15d50: cmp             SP, x16
    //     0xb15d54: b.ls            #0xb15d98
    // 0xb15d58: r1 = Null
    //     0xb15d58: mov             x1, NULL
    // 0xb15d5c: r2 = 4
    //     0xb15d5c: mov             x2, #4
    // 0xb15d60: r0 = AllocateArray()
    //     0xb15d60: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15d64: r17 = "_ForceState."
    //     0xb15d64: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b9d8] "_ForceState."
    //     0xb15d68: ldr             x17, [x17, #0x9d8]
    // 0xb15d6c: StoreField: r0->field_f = r17
    //     0xb15d6c: stur            w17, [x0, #0xf]
    // 0xb15d70: ldr             x1, [fp, #0x10]
    // 0xb15d74: LoadField: r2 = r1->field_f
    //     0xb15d74: ldur            w2, [x1, #0xf]
    // 0xb15d78: DecompressPointer r2
    //     0xb15d78: add             x2, x2, HEAP, lsl #32
    // 0xb15d7c: StoreField: r0->field_13 = r2
    //     0xb15d7c: stur            w2, [x0, #0x13]
    // 0xb15d80: SaveReg r0
    //     0xb15d80: str             x0, [SP, #-8]!
    // 0xb15d84: r0 = _interpolate()
    //     0xb15d84: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15d88: add             SP, SP, #8
    // 0xb15d8c: LeaveFrame
    //     0xb15d8c: mov             SP, fp
    //     0xb15d90: ldp             fp, lr, [SP], #0x10
    // 0xb15d94: ret
    //     0xb15d94: ret             
    // 0xb15d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15d9c: b               #0xb15d58
  }
}

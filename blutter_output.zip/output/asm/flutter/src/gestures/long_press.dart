// lib: , url: package:flutter/src/gestures/long_press.dart

// class id: 1049161, size: 0x8
class :: {
}

// class id: 2276, size: 0x14, field offset: 0x8
//   const constructor, 
class LongPressEndDetails extends Object {

  Offset field_8;
  Offset field_c;
  Velocity field_10;

  const Offset globalPosition(LongPressEndDetails) {
    // ** addr: 0xd64bac, size: 0x28
    // 0xd64bac: ldr             x1, [SP]
    // 0xd64bb0: LoadField: r0 = r1->field_7
    //     0xd64bb0: ldur            w0, [x1, #7]
    // 0xd64bb4: DecompressPointer r0
    //     0xd64bb4: add             x0, x0, HEAP, lsl #32
    // 0xd64bb8: ret
    //     0xd64bb8: ret             
  }
}

// class id: 2277, size: 0x14, field offset: 0x8
//   const constructor, 
class LongPressMoveUpdateDetails extends Object {

  const Offset globalPosition(LongPressMoveUpdateDetails) {
    // ** addr: 0xd64bac, size: 0x28
    // 0xd64bac: ldr             x1, [SP]
    // 0xd64bb0: LoadField: r0 = r1->field_7
    //     0xd64bb0: ldur            w0, [x1, #7]
    // 0xd64bb4: DecompressPointer r0
    //     0xd64bb4: add             x0, x0, HEAP, lsl #32
    // 0xd64bb8: ret
    //     0xd64bb8: ret             
  }
}

// class id: 2278, size: 0x10, field offset: 0x8
//   const constructor, 
class LongPressStartDetails extends Object {

  Offset field_8;
  Offset field_c;

  const Offset globalPosition(LongPressStartDetails) {
    // ** addr: 0xd64bac, size: 0x28
    // 0xd64bac: ldr             x1, [SP]
    // 0xd64bb0: LoadField: r0 = r1->field_7
    //     0xd64bb0: ldur            w0, [x1, #7]
    // 0xd64bb4: DecompressPointer r0
    //     0xd64bb4: add             x0, x0, HEAP, lsl #32
    // 0xd64bb8: ret
    //     0xd64bb8: ret             
  }
}

// class id: 2361, size: 0xa8, field offset: 0x44
class LongPressGestureRecognizer extends PrimaryPointerGestureRecognizer {

  _ resolve(/* No info */) {
    // ** addr: 0x7154a4, size: 0x84
    // 0x7154a4: EnterFrame
    //     0x7154a4: stp             fp, lr, [SP, #-0x10]!
    //     0x7154a8: mov             fp, SP
    // 0x7154ac: CheckStackOverflow
    //     0x7154ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7154b0: cmp             SP, x16
    //     0x7154b4: b.ls            #0x715520
    // 0x7154b8: ldr             x0, [fp, #0x10]
    // 0x7154bc: r16 = Instance_GestureDisposition
    //     0x7154bc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x7154c0: ldr             x16, [x16, #0xeb8]
    // 0x7154c4: cmp             w0, w16
    // 0x7154c8: b.ne            #0x7154fc
    // 0x7154cc: ldr             x1, [fp, #0x18]
    // 0x7154d0: LoadField: r2 = r1->field_43
    //     0x7154d0: ldur            w2, [x1, #0x43]
    // 0x7154d4: DecompressPointer r2
    //     0x7154d4: add             x2, x2, HEAP, lsl #32
    // 0x7154d8: tbnz            w2, #4, #0x7154ec
    // 0x7154dc: SaveReg r1
    //     0x7154dc: str             x1, [SP, #-8]!
    // 0x7154e0: r0 = _reset()
    //     0x7154e0: bl              #0x7155c4  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_reset
    // 0x7154e4: add             SP, SP, #8
    // 0x7154e8: b               #0x7154fc
    // 0x7154ec: ldr             x16, [fp, #0x18]
    // 0x7154f0: SaveReg r16
    //     0x7154f0: str             x16, [SP, #-8]!
    // 0x7154f4: r0 = _checkLongPressCancel()
    //     0x7154f4: bl              #0x71554c  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressCancel
    // 0x7154f8: add             SP, SP, #8
    // 0x7154fc: ldr             x16, [fp, #0x18]
    // 0x715500: ldr             lr, [fp, #0x10]
    // 0x715504: stp             lr, x16, [SP, #-0x10]!
    // 0x715508: r0 = resolve()
    //     0x715508: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x71550c: add             SP, SP, #0x10
    // 0x715510: r0 = Null
    //     0x715510: mov             x0, NULL
    // 0x715514: LeaveFrame
    //     0x715514: mov             SP, fp
    //     0x715518: ldp             fp, lr, [SP], #0x10
    // 0x71551c: ret
    //     0x71551c: ret             
    // 0x715520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x715520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715524: b               #0x7154b8
  }
  _ _checkLongPressCancel(/* No info */) {
    // ** addr: 0x71554c, size: 0x78
    // 0x71554c: ldr             x1, [SP]
    // 0x715550: LoadField: r2 = r1->field_2f
    //     0x715550: ldur            w2, [x1, #0x2f]
    // 0x715554: DecompressPointer r2
    //     0x715554: add             x2, x2, HEAP, lsl #32
    // 0x715558: r16 = Instance_GestureRecognizerState
    //     0x715558: add             x16, PP, #0x29, lsl #12  ; [pp+0x29248] Obj!GestureRecognizerState@b65ab1
    //     0x71555c: ldr             x16, [x16, #0x248]
    // 0x715560: cmp             w2, w16
    // 0x715564: b.ne            #0x7155bc
    // 0x715568: LoadField: r2 = r1->field_4b
    //     0x715568: ldur            w2, [x1, #0x4b]
    // 0x71556c: DecompressPointer r2
    //     0x71556c: add             x2, x2, HEAP, lsl #32
    // 0x715570: r1 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0x715570: mov             x1, #0x76
    //     0x715574: tbz             w2, #0, #0x715584
    //     0x715578: ldur            x1, [x2, #-1]
    //     0x71557c: ubfx            x1, x1, #0xc, #0x14
    //     0x715580: lsl             x1, x1, #1
    // 0x715584: cmp             w1, #0x76
    // 0x715588: b.ne            #0x7155bc
    // 0x71558c: r1 = LoadInt32Instr(r2)
    //     0x71558c: sbfx            x1, x2, #1, #0x1f
    // 0x715590: cmp             x1, #2
    // 0x715594: b.gt            #0x7155ac
    // 0x715598: cmp             x1, #1
    // 0x71559c: b.gt            #0x7155bc
    // 0x7155a0: cmp             w2, #2
    // 0x7155a4: b.ne            #0x7155bc
    // 0x7155a8: b               #0x7155bc
    // 0x7155ac: cmp             x1, #4
    // 0x7155b0: b.lt            #0x7155bc
    // 0x7155b4: cmp             w2, #8
    // 0x7155b8: b.eq            #0x7155bc
    // 0x7155bc: r0 = Null
    //     0x7155bc: mov             x0, NULL
    // 0x7155c0: ret
    //     0x7155c0: ret             
  }
  _ _reset(/* No info */) {
    // ** addr: 0x7155c4, size: 0x20
    // 0x7155c4: r1 = false
    //     0x7155c4: add             x1, NULL, #0x30  ; false
    // 0x7155c8: ldr             x2, [SP]
    // 0x7155cc: StoreField: r2->field_43 = r1
    //     0x7155cc: stur            w1, [x2, #0x43]
    // 0x7155d0: StoreField: r2->field_47 = rNULL
    //     0x7155d0: stur            NULL, [x2, #0x47]
    // 0x7155d4: StoreField: r2->field_4b = rNULL
    //     0x7155d4: stur            NULL, [x2, #0x4b]
    // 0x7155d8: StoreField: r2->field_a3 = rNULL
    //     0x7155d8: stur            NULL, [x2, #0xa3]
    // 0x7155dc: r0 = Null
    //     0x7155dc: mov             x0, NULL
    // 0x7155e0: ret
    //     0x7155e0: ret             
  }
  _ _checkLongPressStart(/* No info */) {
    // ** addr: 0x782894, size: 0x14c
    // 0x782894: EnterFrame
    //     0x782894: stp             fp, lr, [SP, #-0x10]!
    //     0x782898: mov             fp, SP
    // 0x78289c: AllocStack(0x18)
    //     0x78289c: sub             SP, SP, #0x18
    // 0x7828a0: CheckStackOverflow
    //     0x7828a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7828a4: cmp             SP, x16
    //     0x7828a8: b.ls            #0x7829d4
    // 0x7828ac: r1 = 2
    //     0x7828ac: mov             x1, #2
    // 0x7828b0: r0 = AllocateContext()
    //     0x7828b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7828b4: mov             x1, x0
    // 0x7828b8: ldr             x0, [fp, #0x10]
    // 0x7828bc: stur            x1, [fp, #-0x18]
    // 0x7828c0: StoreField: r1->field_f = r0
    //     0x7828c0: stur            w0, [x1, #0xf]
    // 0x7828c4: LoadField: r2 = r0->field_4b
    //     0x7828c4: ldur            w2, [x0, #0x4b]
    // 0x7828c8: DecompressPointer r2
    //     0x7828c8: add             x2, x2, HEAP, lsl #32
    // 0x7828cc: r3 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0x7828cc: mov             x3, #0x76
    //     0x7828d0: tbz             w2, #0, #0x7828e0
    //     0x7828d4: ldur            x3, [x2, #-1]
    //     0x7828d8: ubfx            x3, x3, #0xc, #0x14
    //     0x7828dc: lsl             x3, x3, #1
    // 0x7828e0: cmp             w3, #0x76
    // 0x7828e4: b.ne            #0x7829c4
    // 0x7828e8: r3 = LoadInt32Instr(r2)
    //     0x7828e8: sbfx            x3, x2, #1, #0x1f
    // 0x7828ec: cmp             x3, #2
    // 0x7828f0: b.gt            #0x7829b4
    // 0x7828f4: cmp             x3, #1
    // 0x7828f8: b.gt            #0x7829c4
    // 0x7828fc: cmp             w2, #2
    // 0x782900: b.ne            #0x7829c4
    // 0x782904: LoadField: r2 = r0->field_5b
    //     0x782904: ldur            w2, [x0, #0x5b]
    // 0x782908: DecompressPointer r2
    //     0x782908: add             x2, x2, HEAP, lsl #32
    // 0x78290c: cmp             w2, NULL
    // 0x782910: b.eq            #0x782984
    // 0x782914: LoadField: r2 = r0->field_47
    //     0x782914: ldur            w2, [x0, #0x47]
    // 0x782918: DecompressPointer r2
    //     0x782918: add             x2, x2, HEAP, lsl #32
    // 0x78291c: cmp             w2, NULL
    // 0x782920: b.eq            #0x7829dc
    // 0x782924: LoadField: r3 = r2->field_b
    //     0x782924: ldur            w3, [x2, #0xb]
    // 0x782928: DecompressPointer r3
    //     0x782928: add             x3, x3, HEAP, lsl #32
    // 0x78292c: stur            x3, [fp, #-0x10]
    // 0x782930: LoadField: r4 = r2->field_7
    //     0x782930: ldur            w4, [x2, #7]
    // 0x782934: DecompressPointer r4
    //     0x782934: add             x4, x4, HEAP, lsl #32
    // 0x782938: stur            x4, [fp, #-8]
    // 0x78293c: r0 = LongPressStartDetails()
    //     0x78293c: bl              #0x7829e0  ; AllocateLongPressStartDetailsStub -> LongPressStartDetails (size=0x10)
    // 0x782940: mov             x1, x0
    // 0x782944: ldur            x0, [fp, #-0x10]
    // 0x782948: StoreField: r1->field_7 = r0
    //     0x782948: stur            w0, [x1, #7]
    // 0x78294c: ldur            x0, [fp, #-8]
    // 0x782950: StoreField: r1->field_b = r0
    //     0x782950: stur            w0, [x1, #0xb]
    // 0x782954: ldur            x2, [fp, #-0x18]
    // 0x782958: StoreField: r2->field_13 = r1
    //     0x782958: stur            w1, [x2, #0x13]
    // 0x78295c: r1 = Function '<anonymous closure>':.
    //     0x78295c: add             x1, PP, #0x29, lsl #12  ; [pp+0x29260] AnonymousClosure: (0x7829ec), in [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressStart (0x782894)
    //     0x782960: ldr             x1, [x1, #0x260]
    // 0x782964: r0 = AllocateClosure()
    //     0x782964: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x782968: r16 = <void?>
    //     0x782968: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x78296c: ldr             lr, [fp, #0x10]
    // 0x782970: stp             lr, x16, [SP, #-0x10]!
    // 0x782974: SaveReg r0
    //     0x782974: str             x0, [SP, #-8]!
    // 0x782978: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x782978: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78297c: r0 = invokeCallback()
    //     0x78297c: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x782980: add             SP, SP, #0x18
    // 0x782984: ldr             x0, [fp, #0x10]
    // 0x782988: LoadField: r1 = r0->field_57
    //     0x782988: ldur            w1, [x0, #0x57]
    // 0x78298c: DecompressPointer r1
    //     0x78298c: add             x1, x1, HEAP, lsl #32
    // 0x782990: cmp             w1, NULL
    // 0x782994: b.eq            #0x7829c4
    // 0x782998: r16 = <void?>
    //     0x782998: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x78299c: stp             x0, x16, [SP, #-0x10]!
    // 0x7829a0: SaveReg r1
    //     0x7829a0: str             x1, [SP, #-8]!
    // 0x7829a4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7829a4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7829a8: r0 = invokeCallback()
    //     0x7829a8: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x7829ac: add             SP, SP, #0x18
    // 0x7829b0: b               #0x7829c4
    // 0x7829b4: cmp             x3, #4
    // 0x7829b8: b.lt            #0x7829c4
    // 0x7829bc: cmp             w2, #8
    // 0x7829c0: b.eq            #0x7829c4
    // 0x7829c4: r0 = Null
    //     0x7829c4: mov             x0, NULL
    // 0x7829c8: LeaveFrame
    //     0x7829c8: mov             SP, fp
    //     0x7829cc: ldp             fp, lr, [SP], #0x10
    // 0x7829d0: ret
    //     0x7829d0: ret             
    // 0x7829d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7829d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7829d8: b               #0x7828ac
    // 0x7829dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7829dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7829ec, size: 0x70
    // 0x7829ec: EnterFrame
    //     0x7829ec: stp             fp, lr, [SP, #-0x10]!
    //     0x7829f0: mov             fp, SP
    // 0x7829f4: ldr             x0, [fp, #0x10]
    // 0x7829f8: LoadField: r1 = r0->field_17
    //     0x7829f8: ldur            w1, [x0, #0x17]
    // 0x7829fc: DecompressPointer r1
    //     0x7829fc: add             x1, x1, HEAP, lsl #32
    // 0x782a00: CheckStackOverflow
    //     0x782a00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782a04: cmp             SP, x16
    //     0x782a08: b.ls            #0x782a50
    // 0x782a0c: LoadField: r0 = r1->field_f
    //     0x782a0c: ldur            w0, [x1, #0xf]
    // 0x782a10: DecompressPointer r0
    //     0x782a10: add             x0, x0, HEAP, lsl #32
    // 0x782a14: LoadField: r2 = r0->field_5b
    //     0x782a14: ldur            w2, [x0, #0x5b]
    // 0x782a18: DecompressPointer r2
    //     0x782a18: add             x2, x2, HEAP, lsl #32
    // 0x782a1c: cmp             w2, NULL
    // 0x782a20: b.eq            #0x782a58
    // 0x782a24: LoadField: r0 = r1->field_13
    //     0x782a24: ldur            w0, [x1, #0x13]
    // 0x782a28: DecompressPointer r0
    //     0x782a28: add             x0, x0, HEAP, lsl #32
    // 0x782a2c: stp             x0, x2, [SP, #-0x10]!
    // 0x782a30: mov             x0, x2
    // 0x782a34: ClosureCall
    //     0x782a34: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x782a38: ldur            x2, [x0, #0x1f]
    //     0x782a3c: blr             x2
    // 0x782a40: add             SP, SP, #0x10
    // 0x782a44: LeaveFrame
    //     0x782a44: mov             SP, fp
    //     0x782a48: ldp             fp, lr, [SP], #0x10
    // 0x782a4c: ret
    //     0x782a4c: ret             
    // 0x782a50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782a50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782a54: b               #0x782a0c
    // 0x782a58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x782a58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ LongPressGestureRecognizer(/* No info */) {
    // ** addr: 0x8426d4, size: 0x104
    // 0x8426d4: EnterFrame
    //     0x8426d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8426d8: mov             fp, SP
    // 0x8426dc: mov             x0, x4
    // 0x8426e0: LoadField: r1 = r0->field_13
    //     0x8426e0: ldur            w1, [x0, #0x13]
    // 0x8426e4: DecompressPointer r1
    //     0x8426e4: add             x1, x1, HEAP, lsl #32
    // 0x8426e8: sub             x2, x1, #2
    // 0x8426ec: add             x3, fp, w2, sxtw #2
    // 0x8426f0: ldr             x3, [x3, #0x10]
    // 0x8426f4: LoadField: r2 = r0->field_1f
    //     0x8426f4: ldur            w2, [x0, #0x1f]
    // 0x8426f8: DecompressPointer r2
    //     0x8426f8: add             x2, x2, HEAP, lsl #32
    // 0x8426fc: r16 = "duration"
    //     0x8426fc: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x842700: ldr             x16, [x16, #0xfd8]
    // 0x842704: cmp             w2, w16
    // 0x842708: b.ne            #0x84272c
    // 0x84270c: LoadField: r2 = r0->field_23
    //     0x84270c: ldur            w2, [x0, #0x23]
    // 0x842710: DecompressPointer r2
    //     0x842710: add             x2, x2, HEAP, lsl #32
    // 0x842714: sub             w4, w1, w2
    // 0x842718: add             x2, fp, w4, sxtw #2
    // 0x84271c: ldr             x2, [x2, #8]
    // 0x842720: mov             x4, x2
    // 0x842724: r2 = 1
    //     0x842724: mov             x2, #1
    // 0x842728: b               #0x842734
    // 0x84272c: r4 = Null
    //     0x84272c: mov             x4, NULL
    // 0x842730: r2 = 0
    //     0x842730: mov             x2, #0
    // 0x842734: lsl             x5, x2, #1
    // 0x842738: lsl             w2, w5, #1
    // 0x84273c: add             w5, w2, #8
    // 0x842740: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0x842740: add             x16, x0, w5, sxtw #1
    //     0x842744: ldur            w6, [x16, #0xf]
    // 0x842748: DecompressPointer r6
    //     0x842748: add             x6, x6, HEAP, lsl #32
    // 0x84274c: r16 = "kind"
    //     0x84274c: ldr             x16, [PP, #0x3998]  ; [pp+0x3998] "kind"
    // 0x842750: cmp             w6, w16
    // 0x842754: b.ne            #0x842778
    // 0x842758: add             w5, w2, #0xa
    // 0x84275c: ArrayLoad: r2 = r0[r5]  ; Unknown_4
    //     0x84275c: add             x16, x0, w5, sxtw #1
    //     0x842760: ldur            w2, [x16, #0xf]
    // 0x842764: DecompressPointer r2
    //     0x842764: add             x2, x2, HEAP, lsl #32
    // 0x842768: sub             w0, w1, w2
    // 0x84276c: add             x1, fp, w0, sxtw #2
    // 0x842770: ldr             x1, [x1, #8]
    // 0x842774: b               #0x84277c
    // 0x842778: r1 = Null
    //     0x842778: mov             x1, NULL
    // 0x84277c: r0 = false
    //     0x84277c: add             x0, NULL, #0x30  ; false
    // 0x842780: CheckStackOverflow
    //     0x842780: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x842784: cmp             SP, x16
    //     0x842788: b.ls            #0x8427d0
    // 0x84278c: StoreField: r3->field_43 = r0
    //     0x84278c: stur            w0, [x3, #0x43]
    // 0x842790: cmp             w4, NULL
    // 0x842794: b.ne            #0x8427a4
    // 0x842798: r0 = Instance_Duration
    //     0x842798: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f718] Obj!Duration@b67b11
    //     0x84279c: ldr             x0, [x0, #0x718]
    // 0x8427a0: b               #0x8427a8
    // 0x8427a4: mov             x0, x4
    // 0x8427a8: stp             x0, x3, [SP, #-0x10]!
    // 0x8427ac: stp             x1, NULL, [SP, #-0x10]!
    // 0x8427b0: r4 = const [0, 0x4, 0x4, 0x2, kind, 0x3, postAcceptSlopTolerance, 0x2, null]
    //     0x8427b0: add             x4, PP, #0x21, lsl #12  ; [pp+0x214f0] List(9) [0, 0x4, 0x4, 0x2, "kind", 0x3, "postAcceptSlopTolerance", 0x2, Null]
    //     0x8427b4: ldr             x4, [x4, #0x4f0]
    // 0x8427b8: r0 = PrimaryPointerGestureRecognizer()
    //     0x8427b8: bl              #0x6ef26c  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::PrimaryPointerGestureRecognizer
    // 0x8427bc: add             SP, SP, #0x20
    // 0x8427c0: r0 = Null
    //     0x8427c0: mov             x0, NULL
    // 0x8427c4: LeaveFrame
    //     0x8427c4: mov             SP, fp
    //     0x8427c8: ldp             fp, lr, [SP], #0x10
    // 0x8427cc: ret
    //     0x8427cc: ret             
    // 0x8427d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8427d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8427d4: b               #0x84278c
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xa82040, size: 0x13c
    // 0xa82040: EnterFrame
    //     0xa82040: stp             fp, lr, [SP, #-0x10]!
    //     0xa82044: mov             fp, SP
    // 0xa82048: CheckStackOverflow
    //     0xa82048: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8204c: cmp             SP, x16
    //     0xa82050: b.ls            #0xa82174
    // 0xa82054: ldr             x1, [fp, #0x10]
    // 0xa82058: r0 = LoadClassIdInstr(r1)
    //     0xa82058: ldur            x0, [x1, #-1]
    //     0xa8205c: ubfx            x0, x0, #0xc, #0x14
    // 0xa82060: SaveReg r1
    //     0xa82060: str             x1, [SP, #-8]!
    // 0xa82064: r0 = GDT[cid_x0 + 0x271c]()
    //     0xa82064: mov             x17, #0x271c
    //     0xa82068: add             lr, x0, x17
    //     0xa8206c: ldr             lr, [x21, lr, lsl #3]
    //     0xa82070: blr             lr
    // 0xa82074: add             SP, SP, #8
    // 0xa82078: mov             x2, x0
    // 0xa8207c: r0 = BoxInt64Instr(r2)
    //     0xa8207c: sbfiz           x0, x2, #1, #0x1f
    //     0xa82080: cmp             x2, x0, asr #1
    //     0xa82084: b.eq            #0xa82090
    //     0xa82088: bl              #0xd69bb8
    //     0xa8208c: stur            x2, [x0, #7]
    // 0xa82090: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xa82090: mov             x1, #0x76
    //     0xa82094: tbz             w0, #0, #0xa820a4
    //     0xa82098: ldur            x1, [x0, #-1]
    //     0xa8209c: ubfx            x1, x1, #0xc, #0x14
    //     0xa820a0: lsl             x1, x1, #1
    // 0xa820a4: cmp             w1, #0x76
    // 0xa820a8: b.ne            #0xa82164
    // 0xa820ac: cmp             x2, #2
    // 0xa820b0: b.gt            #0xa82144
    // 0xa820b4: cmp             x2, #1
    // 0xa820b8: b.gt            #0xa82134
    // 0xa820bc: cmp             w0, #2
    // 0xa820c0: b.ne            #0xa82164
    // 0xa820c4: ldr             x0, [fp, #0x18]
    // 0xa820c8: LoadField: r1 = r0->field_5b
    //     0xa820c8: ldur            w1, [x0, #0x5b]
    // 0xa820cc: DecompressPointer r1
    //     0xa820cc: add             x1, x1, HEAP, lsl #32
    // 0xa820d0: cmp             w1, NULL
    // 0xa820d4: b.ne            #0xa82118
    // 0xa820d8: LoadField: r1 = r0->field_57
    //     0xa820d8: ldur            w1, [x0, #0x57]
    // 0xa820dc: DecompressPointer r1
    //     0xa820dc: add             x1, x1, HEAP, lsl #32
    // 0xa820e0: cmp             w1, NULL
    // 0xa820e4: b.ne            #0xa82118
    // 0xa820e8: LoadField: r1 = r0->field_5f
    //     0xa820e8: ldur            w1, [x0, #0x5f]
    // 0xa820ec: DecompressPointer r1
    //     0xa820ec: add             x1, x1, HEAP, lsl #32
    // 0xa820f0: cmp             w1, NULL
    // 0xa820f4: b.ne            #0xa82118
    // 0xa820f8: LoadField: r1 = r0->field_67
    //     0xa820f8: ldur            w1, [x0, #0x67]
    // 0xa820fc: DecompressPointer r1
    //     0xa820fc: add             x1, x1, HEAP, lsl #32
    // 0xa82100: cmp             w1, NULL
    // 0xa82104: b.ne            #0xa82118
    // 0xa82108: r0 = false
    //     0xa82108: add             x0, NULL, #0x30  ; false
    // 0xa8210c: LeaveFrame
    //     0xa8210c: mov             SP, fp
    //     0xa82110: ldp             fp, lr, [SP], #0x10
    // 0xa82114: ret
    //     0xa82114: ret             
    // 0xa82118: ldr             x16, [fp, #0x10]
    // 0xa8211c: stp             x16, x0, [SP, #-0x10]!
    // 0xa82120: r0 = isPointerAllowed()
    //     0xa82120: bl              #0xa829e0  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xa82124: add             SP, SP, #0x10
    // 0xa82128: LeaveFrame
    //     0xa82128: mov             SP, fp
    //     0xa8212c: ldp             fp, lr, [SP], #0x10
    // 0xa82130: ret
    //     0xa82130: ret             
    // 0xa82134: r0 = false
    //     0xa82134: add             x0, NULL, #0x30  ; false
    // 0xa82138: LeaveFrame
    //     0xa82138: mov             SP, fp
    //     0xa8213c: ldp             fp, lr, [SP], #0x10
    // 0xa82140: ret
    //     0xa82140: ret             
    // 0xa82144: cmp             x2, #4
    // 0xa82148: b.lt            #0xa82164
    // 0xa8214c: cmp             w0, #8
    // 0xa82150: b.ne            #0xa82164
    // 0xa82154: r0 = false
    //     0xa82154: add             x0, NULL, #0x30  ; false
    // 0xa82158: LeaveFrame
    //     0xa82158: mov             SP, fp
    //     0xa8215c: ldp             fp, lr, [SP], #0x10
    // 0xa82160: ret
    //     0xa82160: ret             
    // 0xa82164: r0 = false
    //     0xa82164: add             x0, NULL, #0x30  ; false
    // 0xa82168: LeaveFrame
    //     0xa82168: mov             SP, fp
    //     0xa8216c: ldp             fp, lr, [SP], #0x10
    // 0xa82170: ret
    //     0xa82170: ret             
    // 0xa82174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa82174: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa82178: b               #0xa82054
  }
  _ handlePrimaryPointer(/* No info */) {
    // ** addr: 0xbdca18, size: 0x544
    // 0xbdca18: EnterFrame
    //     0xbdca18: stp             fp, lr, [SP, #-0x10]!
    //     0xbdca1c: mov             fp, SP
    // 0xbdca20: AllocStack(0x10)
    //     0xbdca20: sub             SP, SP, #0x10
    // 0xbdca24: CheckStackOverflow
    //     0xbdca24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdca28: cmp             SP, x16
    //     0xbdca2c: b.ls            #0xbdcf4c
    // 0xbdca30: ldr             x1, [fp, #0x10]
    // 0xbdca34: r0 = LoadClassIdInstr(r1)
    //     0xbdca34: ldur            x0, [x1, #-1]
    //     0xbdca38: ubfx            x0, x0, #0xc, #0x14
    // 0xbdca3c: SaveReg r1
    //     0xbdca3c: str             x1, [SP, #-8]!
    // 0xbdca40: r0 = GDT[cid_x0 + 0x7012]()
    //     0xbdca40: mov             x17, #0x7012
    //     0xbdca44: add             lr, x0, x17
    //     0xbdca48: ldr             lr, [x21, lr, lsl #3]
    //     0xbdca4c: blr             lr
    // 0xbdca50: add             SP, SP, #8
    // 0xbdca54: tbz             w0, #4, #0xbdcc38
    // 0xbdca58: ldr             x0, [fp, #0x10]
    // 0xbdca5c: r2 = Null
    //     0xbdca5c: mov             x2, NULL
    // 0xbdca60: r1 = Null
    //     0xbdca60: mov             x1, NULL
    // 0xbdca64: cmp             w0, NULL
    // 0xbdca68: b.eq            #0xbdca88
    // 0xbdca6c: branchIfSmi(r0, 0xbdca88)
    //     0xbdca6c: tbz             w0, #0, #0xbdca88
    // 0xbdca70: r3 = LoadClassIdInstr(r0)
    //     0xbdca70: ldur            x3, [x0, #-1]
    //     0xbdca74: ubfx            x3, x3, #0xc, #0x14
    // 0xbdca78: cmp             x3, #0x90a
    // 0xbdca7c: b.eq            #0xbdca90
    // 0xbdca80: cmp             x3, #0xb41
    // 0xbdca84: b.eq            #0xbdca90
    // 0xbdca88: r0 = false
    //     0xbdca88: add             x0, NULL, #0x30  ; false
    // 0xbdca8c: b               #0xbdca94
    // 0xbdca90: r0 = true
    //     0xbdca90: add             x0, NULL, #0x20  ; true
    // 0xbdca94: tbnz            w0, #4, #0xbdcb7c
    // 0xbdca98: ldr             x2, [fp, #0x18]
    // 0xbdca9c: ldr             x1, [fp, #0x10]
    // 0xbdcaa0: r0 = LoadClassIdInstr(r1)
    //     0xbdcaa0: ldur            x0, [x1, #-1]
    //     0xbdcaa4: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcaa8: SaveReg r1
    //     0xbdcaa8: str             x1, [SP, #-8]!
    // 0xbdcaac: r0 = GDT[cid_x0 + -0xf60]()
    //     0xbdcaac: sub             lr, x0, #0xf60
    //     0xbdcab0: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcab4: blr             lr
    // 0xbdcab8: add             SP, SP, #8
    // 0xbdcabc: stur            x0, [fp, #-8]
    // 0xbdcac0: r0 = VelocityTracker()
    //     0xbdcac0: bl              #0x6ee4b0  ; AllocateVelocityTrackerStub -> VelocityTracker (size=0x18)
    // 0xbdcac4: mov             x3, x0
    // 0xbdcac8: r0 = 0
    //     0xbdcac8: mov             x0, #0
    // 0xbdcacc: stur            x3, [fp, #-0x10]
    // 0xbdcad0: StoreField: r3->field_f = r0
    //     0xbdcad0: stur            x0, [x3, #0xf]
    // 0xbdcad4: r1 = <_PointAtTime?>
    //     0xbdcad4: add             x1, PP, #0x21, lsl #12  ; [pp+0x214e8] TypeArguments: <_PointAtTime?>
    //     0xbdcad8: ldr             x1, [x1, #0x4e8]
    // 0xbdcadc: r2 = 40
    //     0xbdcadc: mov             x2, #0x28
    // 0xbdcae0: r0 = AllocateArray()
    //     0xbdcae0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xbdcae4: ldur            x1, [fp, #-0x10]
    // 0xbdcae8: StoreField: r1->field_b = r0
    //     0xbdcae8: stur            w0, [x1, #0xb]
    // 0xbdcaec: ldur            x0, [fp, #-8]
    // 0xbdcaf0: StoreField: r1->field_7 = r0
    //     0xbdcaf0: stur            w0, [x1, #7]
    // 0xbdcaf4: mov             x0, x1
    // 0xbdcaf8: ldr             x2, [fp, #0x18]
    // 0xbdcafc: StoreField: r2->field_a3 = r0
    //     0xbdcafc: stur            w0, [x2, #0xa3]
    //     0xbdcb00: ldurb           w16, [x2, #-1]
    //     0xbdcb04: ldurb           w17, [x0, #-1]
    //     0xbdcb08: and             x16, x17, x16, lsr #2
    //     0xbdcb0c: tst             x16, HEAP, lsr #32
    //     0xbdcb10: b.eq            #0xbdcb18
    //     0xbdcb14: bl              #0xd6828c
    // 0xbdcb18: ldr             x3, [fp, #0x10]
    // 0xbdcb1c: r0 = LoadClassIdInstr(r3)
    //     0xbdcb1c: ldur            x0, [x3, #-1]
    //     0xbdcb20: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcb24: SaveReg r3
    //     0xbdcb24: str             x3, [SP, #-8]!
    // 0xbdcb28: r0 = GDT[cid_x0 + -0xf3a]()
    //     0xbdcb28: sub             lr, x0, #0xf3a
    //     0xbdcb2c: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcb30: blr             lr
    // 0xbdcb34: add             SP, SP, #8
    // 0xbdcb38: mov             x2, x0
    // 0xbdcb3c: ldr             x1, [fp, #0x10]
    // 0xbdcb40: stur            x2, [fp, #-8]
    // 0xbdcb44: r0 = LoadClassIdInstr(r1)
    //     0xbdcb44: ldur            x0, [x1, #-1]
    //     0xbdcb48: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcb4c: SaveReg r1
    //     0xbdcb4c: str             x1, [SP, #-8]!
    // 0xbdcb50: r0 = GDT[cid_x0 + 0x57c0]()
    //     0xbdcb50: mov             x17, #0x57c0
    //     0xbdcb54: add             lr, x0, x17
    //     0xbdcb58: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcb5c: blr             lr
    // 0xbdcb60: add             SP, SP, #8
    // 0xbdcb64: ldur            x16, [fp, #-0x10]
    // 0xbdcb68: ldur            lr, [fp, #-8]
    // 0xbdcb6c: stp             lr, x16, [SP, #-0x10]!
    // 0xbdcb70: SaveReg r0
    //     0xbdcb70: str             x0, [SP, #-8]!
    // 0xbdcb74: r0 = addPosition()
    //     0xbdcb74: bl              #0xcb5c90  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::addPosition
    // 0xbdcb78: add             SP, SP, #0x18
    // 0xbdcb7c: ldr             x0, [fp, #0x10]
    // 0xbdcb80: r2 = Null
    //     0xbdcb80: mov             x2, NULL
    // 0xbdcb84: r1 = Null
    //     0xbdcb84: mov             x1, NULL
    // 0xbdcb88: cmp             w0, NULL
    // 0xbdcb8c: b.eq            #0xbdcbac
    // 0xbdcb90: branchIfSmi(r0, 0xbdcbac)
    //     0xbdcb90: tbz             w0, #0, #0xbdcbac
    // 0xbdcb94: r3 = LoadClassIdInstr(r0)
    //     0xbdcb94: ldur            x3, [x0, #-1]
    //     0xbdcb98: ubfx            x3, x3, #0xc, #0x14
    // 0xbdcb9c: cmp             x3, #0x908
    // 0xbdcba0: b.eq            #0xbdcbb4
    // 0xbdcba4: cmp             x3, #0xb3f
    // 0xbdcba8: b.eq            #0xbdcbb4
    // 0xbdcbac: r0 = false
    //     0xbdcbac: add             x0, NULL, #0x30  ; false
    // 0xbdcbb0: b               #0xbdcbb8
    // 0xbdcbb4: r0 = true
    //     0xbdcbb4: add             x0, NULL, #0x20  ; true
    // 0xbdcbb8: tbnz            w0, #4, #0xbdcc38
    // 0xbdcbbc: ldr             x2, [fp, #0x18]
    // 0xbdcbc0: ldr             x1, [fp, #0x10]
    // 0xbdcbc4: LoadField: r3 = r2->field_a3
    //     0xbdcbc4: ldur            w3, [x2, #0xa3]
    // 0xbdcbc8: DecompressPointer r3
    //     0xbdcbc8: add             x3, x3, HEAP, lsl #32
    // 0xbdcbcc: stur            x3, [fp, #-8]
    // 0xbdcbd0: cmp             w3, NULL
    // 0xbdcbd4: b.eq            #0xbdcf54
    // 0xbdcbd8: r0 = LoadClassIdInstr(r1)
    //     0xbdcbd8: ldur            x0, [x1, #-1]
    //     0xbdcbdc: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcbe0: SaveReg r1
    //     0xbdcbe0: str             x1, [SP, #-8]!
    // 0xbdcbe4: r0 = GDT[cid_x0 + -0xf3a]()
    //     0xbdcbe4: sub             lr, x0, #0xf3a
    //     0xbdcbe8: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcbec: blr             lr
    // 0xbdcbf0: add             SP, SP, #8
    // 0xbdcbf4: mov             x2, x0
    // 0xbdcbf8: ldr             x1, [fp, #0x10]
    // 0xbdcbfc: stur            x2, [fp, #-0x10]
    // 0xbdcc00: r0 = LoadClassIdInstr(r1)
    //     0xbdcc00: ldur            x0, [x1, #-1]
    //     0xbdcc04: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcc08: SaveReg r1
    //     0xbdcc08: str             x1, [SP, #-8]!
    // 0xbdcc0c: r0 = GDT[cid_x0 + 0x57c0]()
    //     0xbdcc0c: mov             x17, #0x57c0
    //     0xbdcc10: add             lr, x0, x17
    //     0xbdcc14: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcc18: blr             lr
    // 0xbdcc1c: add             SP, SP, #8
    // 0xbdcc20: ldur            x16, [fp, #-8]
    // 0xbdcc24: ldur            lr, [fp, #-0x10]
    // 0xbdcc28: stp             lr, x16, [SP, #-0x10]!
    // 0xbdcc2c: SaveReg r0
    //     0xbdcc2c: str             x0, [SP, #-8]!
    // 0xbdcc30: r0 = addPosition()
    //     0xbdcc30: bl              #0xcb5c90  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::addPosition
    // 0xbdcc34: add             SP, SP, #0x18
    // 0xbdcc38: ldr             x0, [fp, #0x10]
    // 0xbdcc3c: r2 = Null
    //     0xbdcc3c: mov             x2, NULL
    // 0xbdcc40: r1 = Null
    //     0xbdcc40: mov             x1, NULL
    // 0xbdcc44: cmp             w0, NULL
    // 0xbdcc48: b.eq            #0xbdcc68
    // 0xbdcc4c: branchIfSmi(r0, 0xbdcc68)
    //     0xbdcc4c: tbz             w0, #0, #0xbdcc68
    // 0xbdcc50: r3 = LoadClassIdInstr(r0)
    //     0xbdcc50: ldur            x3, [x0, #-1]
    //     0xbdcc54: ubfx            x3, x3, #0xc, #0x14
    // 0xbdcc58: cmp             x3, #0x906
    // 0xbdcc5c: b.eq            #0xbdcc70
    // 0xbdcc60: cmp             x3, #0xb3d
    // 0xbdcc64: b.eq            #0xbdcc70
    // 0xbdcc68: r0 = false
    //     0xbdcc68: add             x0, NULL, #0x30  ; false
    // 0xbdcc6c: b               #0xbdcc74
    // 0xbdcc70: r0 = true
    //     0xbdcc70: add             x0, NULL, #0x20  ; true
    // 0xbdcc74: tbnz            w0, #4, #0xbdccc8
    // 0xbdcc78: ldr             x0, [fp, #0x18]
    // 0xbdcc7c: LoadField: r1 = r0->field_43
    //     0xbdcc7c: ldur            w1, [x0, #0x43]
    // 0xbdcc80: DecompressPointer r1
    //     0xbdcc80: add             x1, x1, HEAP, lsl #32
    // 0xbdcc84: tbnz            w1, #4, #0xbdcc9c
    // 0xbdcc88: ldr             x16, [fp, #0x10]
    // 0xbdcc8c: stp             x16, x0, [SP, #-0x10]!
    // 0xbdcc90: r0 = _checkLongPressEnd()
    //     0xbdcc90: bl              #0xbdd2c8  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressEnd
    // 0xbdcc94: add             SP, SP, #0x10
    // 0xbdcc98: b               #0xbdccb4
    // 0xbdcc9c: ldr             x16, [fp, #0x18]
    // 0xbdcca0: r30 = Instance_GestureDisposition
    //     0xbdcca0: add             lr, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xbdcca4: ldr             lr, [lr, #0xeb8]
    // 0xbdcca8: stp             lr, x16, [SP, #-0x10]!
    // 0xbdccac: r0 = resolve()
    //     0xbdccac: bl              #0x7154a4  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::resolve
    // 0xbdccb0: add             SP, SP, #0x10
    // 0xbdccb4: ldr             x16, [fp, #0x18]
    // 0xbdccb8: SaveReg r16
    //     0xbdccb8: str             x16, [SP, #-8]!
    // 0xbdccbc: r0 = _reset()
    //     0xbdccbc: bl              #0x7155c4  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_reset
    // 0xbdccc0: add             SP, SP, #8
    // 0xbdccc4: b               #0xbdcf3c
    // 0xbdccc8: ldr             x0, [fp, #0x10]
    // 0xbdcccc: r2 = Null
    //     0xbdcccc: mov             x2, NULL
    // 0xbdccd0: r1 = Null
    //     0xbdccd0: mov             x1, NULL
    // 0xbdccd4: cmp             w0, NULL
    // 0xbdccd8: b.eq            #0xbdccf8
    // 0xbdccdc: branchIfSmi(r0, 0xbdccf8)
    //     0xbdccdc: tbz             w0, #0, #0xbdccf8
    // 0xbdcce0: r3 = LoadClassIdInstr(r0)
    //     0xbdcce0: ldur            x3, [x0, #-1]
    //     0xbdcce4: ubfx            x3, x3, #0xc, #0x14
    // 0xbdcce8: cmp             x3, #0x8f8
    // 0xbdccec: b.eq            #0xbdcd00
    // 0xbdccf0: cmp             x3, #0xb35
    // 0xbdccf4: b.eq            #0xbdcd00
    // 0xbdccf8: r0 = false
    //     0xbdccf8: add             x0, NULL, #0x30  ; false
    // 0xbdccfc: b               #0xbdcd04
    // 0xbdcd00: r0 = true
    //     0xbdcd00: add             x0, NULL, #0x20  ; true
    // 0xbdcd04: tbnz            w0, #4, #0xbdcd2c
    // 0xbdcd08: ldr             x16, [fp, #0x18]
    // 0xbdcd0c: SaveReg r16
    //     0xbdcd0c: str             x16, [SP, #-8]!
    // 0xbdcd10: r0 = _checkLongPressCancel()
    //     0xbdcd10: bl              #0x71554c  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressCancel
    // 0xbdcd14: add             SP, SP, #8
    // 0xbdcd18: ldr             x16, [fp, #0x18]
    // 0xbdcd1c: SaveReg r16
    //     0xbdcd1c: str             x16, [SP, #-8]!
    // 0xbdcd20: r0 = _reset()
    //     0xbdcd20: bl              #0x7155c4  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_reset
    // 0xbdcd24: add             SP, SP, #8
    // 0xbdcd28: b               #0xbdcf3c
    // 0xbdcd2c: ldr             x0, [fp, #0x10]
    // 0xbdcd30: r2 = Null
    //     0xbdcd30: mov             x2, NULL
    // 0xbdcd34: r1 = Null
    //     0xbdcd34: mov             x1, NULL
    // 0xbdcd38: cmp             w0, NULL
    // 0xbdcd3c: b.eq            #0xbdcd5c
    // 0xbdcd40: branchIfSmi(r0, 0xbdcd5c)
    //     0xbdcd40: tbz             w0, #0, #0xbdcd5c
    // 0xbdcd44: r3 = LoadClassIdInstr(r0)
    //     0xbdcd44: ldur            x3, [x0, #-1]
    //     0xbdcd48: ubfx            x3, x3, #0xc, #0x14
    // 0xbdcd4c: cmp             x3, #0x90a
    // 0xbdcd50: b.eq            #0xbdcd64
    // 0xbdcd54: cmp             x3, #0xb41
    // 0xbdcd58: b.eq            #0xbdcd64
    // 0xbdcd5c: r0 = false
    //     0xbdcd5c: add             x0, NULL, #0x30  ; false
    // 0xbdcd60: b               #0xbdcd68
    // 0xbdcd64: r0 = true
    //     0xbdcd64: add             x0, NULL, #0x20  ; true
    // 0xbdcd68: tbnz            w0, #4, #0xbdce14
    // 0xbdcd6c: ldr             x0, [fp, #0x18]
    // 0xbdcd70: ldr             x1, [fp, #0x10]
    // 0xbdcd74: stp             x1, NULL, [SP, #-0x10]!
    // 0xbdcd78: r0 = OffsetPair.fromEventPosition()
    //     0xbdcd78: bl              #0x78253c  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::OffsetPair.fromEventPosition
    // 0xbdcd7c: add             SP, SP, #0x10
    // 0xbdcd80: ldr             x1, [fp, #0x18]
    // 0xbdcd84: StoreField: r1->field_47 = r0
    //     0xbdcd84: stur            w0, [x1, #0x47]
    //     0xbdcd88: ldurb           w16, [x1, #-1]
    //     0xbdcd8c: ldurb           w17, [x0, #-1]
    //     0xbdcd90: and             x16, x17, x16, lsr #2
    //     0xbdcd94: tst             x16, HEAP, lsr #32
    //     0xbdcd98: b.eq            #0xbdcda0
    //     0xbdcd9c: bl              #0xd6826c
    // 0xbdcda0: ldr             x2, [fp, #0x10]
    // 0xbdcda4: r0 = LoadClassIdInstr(r2)
    //     0xbdcda4: ldur            x0, [x2, #-1]
    //     0xbdcda8: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcdac: SaveReg r2
    //     0xbdcdac: str             x2, [SP, #-8]!
    // 0xbdcdb0: r0 = GDT[cid_x0 + 0x271c]()
    //     0xbdcdb0: mov             x17, #0x271c
    //     0xbdcdb4: add             lr, x0, x17
    //     0xbdcdb8: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcdbc: blr             lr
    // 0xbdcdc0: add             SP, SP, #8
    // 0xbdcdc4: mov             x2, x0
    // 0xbdcdc8: r0 = BoxInt64Instr(r2)
    //     0xbdcdc8: sbfiz           x0, x2, #1, #0x1f
    //     0xbdcdcc: cmp             x2, x0, asr #1
    //     0xbdcdd0: b.eq            #0xbdcddc
    //     0xbdcdd4: bl              #0xd69bb8
    //     0xbdcdd8: stur            x2, [x0, #7]
    // 0xbdcddc: ldr             x3, [fp, #0x18]
    // 0xbdcde0: StoreField: r3->field_4b = r0
    //     0xbdcde0: stur            w0, [x3, #0x4b]
    //     0xbdcde4: tbz             w0, #0, #0xbdce00
    //     0xbdcde8: ldurb           w16, [x3, #-1]
    //     0xbdcdec: ldurb           w17, [x0, #-1]
    //     0xbdcdf0: and             x16, x17, x16, lsr #2
    //     0xbdcdf4: tst             x16, HEAP, lsr #32
    //     0xbdcdf8: b.eq            #0xbdce00
    //     0xbdcdfc: bl              #0xd682ac
    // 0xbdce00: ldr             x16, [fp, #0x10]
    // 0xbdce04: stp             x16, x3, [SP, #-0x10]!
    // 0xbdce08: r0 = _checkLongPressDown()
    //     0xbdce08: bl              #0xbdd1f8  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressDown
    // 0xbdce0c: add             SP, SP, #0x10
    // 0xbdce10: b               #0xbdcf3c
    // 0xbdce14: ldr             x3, [fp, #0x18]
    // 0xbdce18: ldr             x0, [fp, #0x10]
    // 0xbdce1c: r2 = Null
    //     0xbdce1c: mov             x2, NULL
    // 0xbdce20: r1 = Null
    //     0xbdce20: mov             x1, NULL
    // 0xbdce24: cmp             w0, NULL
    // 0xbdce28: b.eq            #0xbdce48
    // 0xbdce2c: branchIfSmi(r0, 0xbdce48)
    //     0xbdce2c: tbz             w0, #0, #0xbdce48
    // 0xbdce30: r3 = LoadClassIdInstr(r0)
    //     0xbdce30: ldur            x3, [x0, #-1]
    //     0xbdce34: ubfx            x3, x3, #0xc, #0x14
    // 0xbdce38: cmp             x3, #0x908
    // 0xbdce3c: b.eq            #0xbdce50
    // 0xbdce40: cmp             x3, #0xb3f
    // 0xbdce44: b.eq            #0xbdce50
    // 0xbdce48: r0 = false
    //     0xbdce48: add             x0, NULL, #0x30  ; false
    // 0xbdce4c: b               #0xbdce54
    // 0xbdce50: r0 = true
    //     0xbdce50: add             x0, NULL, #0x20  ; true
    // 0xbdce54: tbnz            w0, #4, #0xbdcf3c
    // 0xbdce58: ldr             x1, [fp, #0x18]
    // 0xbdce5c: ldr             x2, [fp, #0x10]
    // 0xbdce60: r0 = LoadClassIdInstr(r2)
    //     0xbdce60: ldur            x0, [x2, #-1]
    //     0xbdce64: ubfx            x0, x0, #0xc, #0x14
    // 0xbdce68: SaveReg r2
    //     0xbdce68: str             x2, [SP, #-8]!
    // 0xbdce6c: r0 = GDT[cid_x0 + 0x271c]()
    //     0xbdce6c: mov             x17, #0x271c
    //     0xbdce70: add             lr, x0, x17
    //     0xbdce74: ldr             lr, [x21, lr, lsl #3]
    //     0xbdce78: blr             lr
    // 0xbdce7c: add             SP, SP, #8
    // 0xbdce80: mov             x3, x0
    // 0xbdce84: ldr             x2, [fp, #0x18]
    // 0xbdce88: LoadField: r4 = r2->field_4b
    //     0xbdce88: ldur            w4, [x2, #0x4b]
    // 0xbdce8c: DecompressPointer r4
    //     0xbdce8c: add             x4, x4, HEAP, lsl #32
    // 0xbdce90: r0 = BoxInt64Instr(r3)
    //     0xbdce90: sbfiz           x0, x3, #1, #0x1f
    //     0xbdce94: cmp             x3, x0, asr #1
    //     0xbdce98: b.eq            #0xbdcea4
    //     0xbdce9c: bl              #0xd69bb8
    //     0xbdcea0: stur            x3, [x0, #7]
    // 0xbdcea4: cmp             w0, w4
    // 0xbdcea8: b.eq            #0xbdcf1c
    // 0xbdceac: and             w16, w0, w4
    // 0xbdceb0: branchIfSmi(r16, 0xbdcee4)
    //     0xbdceb0: tbz             w16, #0, #0xbdcee4
    // 0xbdceb4: r16 = LoadClassIdInstr(r0)
    //     0xbdceb4: ldur            x16, [x0, #-1]
    //     0xbdceb8: ubfx            x16, x16, #0xc, #0x14
    // 0xbdcebc: cmp             x16, #0x3c
    // 0xbdcec0: b.ne            #0xbdcee4
    // 0xbdcec4: r16 = LoadClassIdInstr(r4)
    //     0xbdcec4: ldur            x16, [x4, #-1]
    //     0xbdcec8: ubfx            x16, x16, #0xc, #0x14
    // 0xbdcecc: cmp             x16, #0x3c
    // 0xbdced0: b.ne            #0xbdcee4
    // 0xbdced4: LoadField: r16 = r0->field_7
    //     0xbdced4: ldur            x16, [x0, #7]
    // 0xbdced8: LoadField: r17 = r4->field_7
    //     0xbdced8: ldur            x17, [x4, #7]
    // 0xbdcedc: cmp             x16, x17
    // 0xbdcee0: b.eq            #0xbdcf1c
    // 0xbdcee4: r16 = Instance_GestureDisposition
    //     0xbdcee4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xbdcee8: ldr             x16, [x16, #0xeb8]
    // 0xbdceec: stp             x16, x2, [SP, #-0x10]!
    // 0xbdcef0: r0 = resolve()
    //     0xbdcef0: bl              #0x7154a4  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::resolve
    // 0xbdcef4: add             SP, SP, #0x10
    // 0xbdcef8: ldr             x0, [fp, #0x18]
    // 0xbdcefc: LoadField: r1 = r0->field_33
    //     0xbdcefc: ldur            w1, [x0, #0x33]
    // 0xbdcf00: DecompressPointer r1
    //     0xbdcf00: add             x1, x1, HEAP, lsl #32
    // 0xbdcf04: cmp             w1, NULL
    // 0xbdcf08: b.eq            #0xbdcf58
    // 0xbdcf0c: stp             x1, x0, [SP, #-0x10]!
    // 0xbdcf10: r0 = stopTrackingPointer()
    //     0xbdcf10: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xbdcf14: add             SP, SP, #0x10
    // 0xbdcf18: b               #0xbdcf3c
    // 0xbdcf1c: mov             x0, x2
    // 0xbdcf20: LoadField: r1 = r0->field_43
    //     0xbdcf20: ldur            w1, [x0, #0x43]
    // 0xbdcf24: DecompressPointer r1
    //     0xbdcf24: add             x1, x1, HEAP, lsl #32
    // 0xbdcf28: tbnz            w1, #4, #0xbdcf3c
    // 0xbdcf2c: ldr             x16, [fp, #0x10]
    // 0xbdcf30: stp             x16, x0, [SP, #-0x10]!
    // 0xbdcf34: r0 = _checkLongPressMoveUpdate()
    //     0xbdcf34: bl              #0xbdcf5c  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressMoveUpdate
    // 0xbdcf38: add             SP, SP, #0x10
    // 0xbdcf3c: r0 = Null
    //     0xbdcf3c: mov             x0, NULL
    // 0xbdcf40: LeaveFrame
    //     0xbdcf40: mov             SP, fp
    //     0xbdcf44: ldp             fp, lr, [SP], #0x10
    // 0xbdcf48: ret
    //     0xbdcf48: ret             
    // 0xbdcf4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdcf4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdcf50: b               #0xbdca30
    // 0xbdcf54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdcf54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbdcf58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdcf58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkLongPressMoveUpdate(/* No info */) {
    // ** addr: 0xbdcf5c, size: 0x220
    // 0xbdcf5c: EnterFrame
    //     0xbdcf5c: stp             fp, lr, [SP, #-0x10]!
    //     0xbdcf60: mov             fp, SP
    // 0xbdcf64: AllocStack(0x20)
    //     0xbdcf64: sub             SP, SP, #0x20
    // 0xbdcf68: CheckStackOverflow
    //     0xbdcf68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdcf6c: cmp             SP, x16
    //     0xbdcf70: b.ls            #0xbdd16c
    // 0xbdcf74: r1 = 2
    //     0xbdcf74: mov             x1, #2
    // 0xbdcf78: r0 = AllocateContext()
    //     0xbdcf78: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbdcf7c: mov             x2, x0
    // 0xbdcf80: ldr             x1, [fp, #0x18]
    // 0xbdcf84: stur            x2, [fp, #-8]
    // 0xbdcf88: StoreField: r2->field_f = r1
    //     0xbdcf88: stur            w1, [x2, #0xf]
    // 0xbdcf8c: ldr             x3, [fp, #0x10]
    // 0xbdcf90: r0 = LoadClassIdInstr(r3)
    //     0xbdcf90: ldur            x0, [x3, #-1]
    //     0xbdcf94: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcf98: SaveReg r3
    //     0xbdcf98: str             x3, [SP, #-8]!
    // 0xbdcf9c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0xbdcf9c: sub             lr, x0, #0xfd9
    //     0xbdcfa0: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcfa4: blr             lr
    // 0xbdcfa8: add             SP, SP, #8
    // 0xbdcfac: mov             x2, x0
    // 0xbdcfb0: ldr             x1, [fp, #0x10]
    // 0xbdcfb4: stur            x2, [fp, #-0x10]
    // 0xbdcfb8: r0 = LoadClassIdInstr(r1)
    //     0xbdcfb8: ldur            x0, [x1, #-1]
    //     0xbdcfbc: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcfc0: SaveReg r1
    //     0xbdcfc0: str             x1, [SP, #-8]!
    // 0xbdcfc4: r0 = GDT[cid_x0 + 0x57c0]()
    //     0xbdcfc4: mov             x17, #0x57c0
    //     0xbdcfc8: add             lr, x0, x17
    //     0xbdcfcc: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcfd0: blr             lr
    // 0xbdcfd4: add             SP, SP, #8
    // 0xbdcfd8: mov             x2, x0
    // 0xbdcfdc: ldr             x1, [fp, #0x10]
    // 0xbdcfe0: stur            x2, [fp, #-0x18]
    // 0xbdcfe4: r0 = LoadClassIdInstr(r1)
    //     0xbdcfe4: ldur            x0, [x1, #-1]
    //     0xbdcfe8: ubfx            x0, x0, #0xc, #0x14
    // 0xbdcfec: SaveReg r1
    //     0xbdcfec: str             x1, [SP, #-8]!
    // 0xbdcff0: r0 = GDT[cid_x0 + -0xfd9]()
    //     0xbdcff0: sub             lr, x0, #0xfd9
    //     0xbdcff4: ldr             lr, [x21, lr, lsl #3]
    //     0xbdcff8: blr             lr
    // 0xbdcffc: add             SP, SP, #8
    // 0xbdd000: mov             x1, x0
    // 0xbdd004: ldr             x0, [fp, #0x18]
    // 0xbdd008: LoadField: r2 = r0->field_47
    //     0xbdd008: ldur            w2, [x0, #0x47]
    // 0xbdd00c: DecompressPointer r2
    //     0xbdd00c: add             x2, x2, HEAP, lsl #32
    // 0xbdd010: cmp             w2, NULL
    // 0xbdd014: b.eq            #0xbdd174
    // 0xbdd018: LoadField: r3 = r2->field_b
    //     0xbdd018: ldur            w3, [x2, #0xb]
    // 0xbdd01c: DecompressPointer r3
    //     0xbdd01c: add             x3, x3, HEAP, lsl #32
    // 0xbdd020: stp             x3, x1, [SP, #-0x10]!
    // 0xbdd024: r0 = -()
    //     0xbdd024: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xbdd028: add             SP, SP, #0x10
    // 0xbdd02c: mov             x1, x0
    // 0xbdd030: ldr             x0, [fp, #0x10]
    // 0xbdd034: stur            x1, [fp, #-0x20]
    // 0xbdd038: r2 = LoadClassIdInstr(r0)
    //     0xbdd038: ldur            x2, [x0, #-1]
    //     0xbdd03c: ubfx            x2, x2, #0xc, #0x14
    // 0xbdd040: SaveReg r0
    //     0xbdd040: str             x0, [SP, #-8]!
    // 0xbdd044: mov             x0, x2
    // 0xbdd048: r0 = GDT[cid_x0 + 0x57c0]()
    //     0xbdd048: mov             x17, #0x57c0
    //     0xbdd04c: add             lr, x0, x17
    //     0xbdd050: ldr             lr, [x21, lr, lsl #3]
    //     0xbdd054: blr             lr
    // 0xbdd058: add             SP, SP, #8
    // 0xbdd05c: mov             x1, x0
    // 0xbdd060: ldr             x0, [fp, #0x18]
    // 0xbdd064: LoadField: r2 = r0->field_47
    //     0xbdd064: ldur            w2, [x0, #0x47]
    // 0xbdd068: DecompressPointer r2
    //     0xbdd068: add             x2, x2, HEAP, lsl #32
    // 0xbdd06c: cmp             w2, NULL
    // 0xbdd070: b.eq            #0xbdd178
    // 0xbdd074: LoadField: r3 = r2->field_7
    //     0xbdd074: ldur            w3, [x2, #7]
    // 0xbdd078: DecompressPointer r3
    //     0xbdd078: add             x3, x3, HEAP, lsl #32
    // 0xbdd07c: stp             x3, x1, [SP, #-0x10]!
    // 0xbdd080: r0 = -()
    //     0xbdd080: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xbdd084: add             SP, SP, #0x10
    // 0xbdd088: r0 = LongPressMoveUpdateDetails()
    //     0xbdd088: bl              #0xbdd17c  ; AllocateLongPressMoveUpdateDetailsStub -> LongPressMoveUpdateDetails (size=0x14)
    // 0xbdd08c: mov             x1, x0
    // 0xbdd090: ldur            x0, [fp, #-0x10]
    // 0xbdd094: StoreField: r1->field_7 = r0
    //     0xbdd094: stur            w0, [x1, #7]
    // 0xbdd098: ldur            x0, [fp, #-0x20]
    // 0xbdd09c: StoreField: r1->field_f = r0
    //     0xbdd09c: stur            w0, [x1, #0xf]
    // 0xbdd0a0: ldur            x0, [fp, #-0x18]
    // 0xbdd0a4: StoreField: r1->field_b = r0
    //     0xbdd0a4: stur            w0, [x1, #0xb]
    // 0xbdd0a8: mov             x0, x1
    // 0xbdd0ac: ldur            x2, [fp, #-8]
    // 0xbdd0b0: StoreField: r2->field_13 = r0
    //     0xbdd0b0: stur            w0, [x2, #0x13]
    //     0xbdd0b4: ldurb           w16, [x2, #-1]
    //     0xbdd0b8: ldurb           w17, [x0, #-1]
    //     0xbdd0bc: and             x16, x17, x16, lsr #2
    //     0xbdd0c0: tst             x16, HEAP, lsr #32
    //     0xbdd0c4: b.eq            #0xbdd0cc
    //     0xbdd0c8: bl              #0xd6828c
    // 0xbdd0cc: ldr             x0, [fp, #0x18]
    // 0xbdd0d0: LoadField: r1 = r0->field_4b
    //     0xbdd0d0: ldur            w1, [x0, #0x4b]
    // 0xbdd0d4: DecompressPointer r1
    //     0xbdd0d4: add             x1, x1, HEAP, lsl #32
    // 0xbdd0d8: r3 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xbdd0d8: mov             x3, #0x76
    //     0xbdd0dc: tbz             w1, #0, #0xbdd0ec
    //     0xbdd0e0: ldur            x3, [x1, #-1]
    //     0xbdd0e4: ubfx            x3, x3, #0xc, #0x14
    //     0xbdd0e8: lsl             x3, x3, #1
    // 0xbdd0ec: cmp             w3, #0x76
    // 0xbdd0f0: b.ne            #0xbdd15c
    // 0xbdd0f4: r3 = LoadInt32Instr(r1)
    //     0xbdd0f4: sbfx            x3, x1, #1, #0x1f
    // 0xbdd0f8: cmp             x3, #2
    // 0xbdd0fc: b.gt            #0xbdd14c
    // 0xbdd100: cmp             x3, #1
    // 0xbdd104: b.gt            #0xbdd15c
    // 0xbdd108: cmp             w1, #2
    // 0xbdd10c: b.ne            #0xbdd15c
    // 0xbdd110: LoadField: r1 = r0->field_5f
    //     0xbdd110: ldur            w1, [x0, #0x5f]
    // 0xbdd114: DecompressPointer r1
    //     0xbdd114: add             x1, x1, HEAP, lsl #32
    // 0xbdd118: cmp             w1, NULL
    // 0xbdd11c: b.eq            #0xbdd15c
    // 0xbdd120: r1 = Function '<anonymous closure>':.
    //     0xbdd120: add             x1, PP, #0x37, lsl #12  ; [pp+0x37b08] AnonymousClosure: (0xbdd188), in [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::_checkLongPressMoveUpdate (0xbdcf5c)
    //     0xbdd124: ldr             x1, [x1, #0xb08]
    // 0xbdd128: r0 = AllocateClosure()
    //     0xbdd128: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbdd12c: r16 = <void?>
    //     0xbdd12c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xbdd130: ldr             lr, [fp, #0x18]
    // 0xbdd134: stp             lr, x16, [SP, #-0x10]!
    // 0xbdd138: SaveReg r0
    //     0xbdd138: str             x0, [SP, #-8]!
    // 0xbdd13c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbdd13c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbdd140: r0 = invokeCallback()
    //     0xbdd140: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xbdd144: add             SP, SP, #0x18
    // 0xbdd148: b               #0xbdd15c
    // 0xbdd14c: cmp             x3, #4
    // 0xbdd150: b.lt            #0xbdd15c
    // 0xbdd154: cmp             w1, #8
    // 0xbdd158: b.eq            #0xbdd15c
    // 0xbdd15c: r0 = Null
    //     0xbdd15c: mov             x0, NULL
    // 0xbdd160: LeaveFrame
    //     0xbdd160: mov             SP, fp
    //     0xbdd164: ldp             fp, lr, [SP], #0x10
    // 0xbdd168: ret
    //     0xbdd168: ret             
    // 0xbdd16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdd16c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdd170: b               #0xbdcf74
    // 0xbdd174: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdd174: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbdd178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdd178: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xbdd188, size: 0x70
    // 0xbdd188: EnterFrame
    //     0xbdd188: stp             fp, lr, [SP, #-0x10]!
    //     0xbdd18c: mov             fp, SP
    // 0xbdd190: ldr             x0, [fp, #0x10]
    // 0xbdd194: LoadField: r1 = r0->field_17
    //     0xbdd194: ldur            w1, [x0, #0x17]
    // 0xbdd198: DecompressPointer r1
    //     0xbdd198: add             x1, x1, HEAP, lsl #32
    // 0xbdd19c: CheckStackOverflow
    //     0xbdd19c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdd1a0: cmp             SP, x16
    //     0xbdd1a4: b.ls            #0xbdd1ec
    // 0xbdd1a8: LoadField: r0 = r1->field_f
    //     0xbdd1a8: ldur            w0, [x1, #0xf]
    // 0xbdd1ac: DecompressPointer r0
    //     0xbdd1ac: add             x0, x0, HEAP, lsl #32
    // 0xbdd1b0: LoadField: r2 = r0->field_5f
    //     0xbdd1b0: ldur            w2, [x0, #0x5f]
    // 0xbdd1b4: DecompressPointer r2
    //     0xbdd1b4: add             x2, x2, HEAP, lsl #32
    // 0xbdd1b8: cmp             w2, NULL
    // 0xbdd1bc: b.eq            #0xbdd1f4
    // 0xbdd1c0: LoadField: r0 = r1->field_13
    //     0xbdd1c0: ldur            w0, [x1, #0x13]
    // 0xbdd1c4: DecompressPointer r0
    //     0xbdd1c4: add             x0, x0, HEAP, lsl #32
    // 0xbdd1c8: stp             x0, x2, [SP, #-0x10]!
    // 0xbdd1cc: mov             x0, x2
    // 0xbdd1d0: ClosureCall
    //     0xbdd1d0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbdd1d4: ldur            x2, [x0, #0x1f]
    //     0xbdd1d8: blr             x2
    // 0xbdd1dc: add             SP, SP, #0x10
    // 0xbdd1e0: LeaveFrame
    //     0xbdd1e0: mov             SP, fp
    //     0xbdd1e4: ldp             fp, lr, [SP], #0x10
    // 0xbdd1e8: ret
    //     0xbdd1e8: ret             
    // 0xbdd1ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdd1ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdd1f0: b               #0xbdd1a8
    // 0xbdd1f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdd1f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkLongPressDown(/* No info */) {
    // ** addr: 0xbdd1f8, size: 0xd0
    // 0xbdd1f8: EnterFrame
    //     0xbdd1f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbdd1fc: mov             fp, SP
    // 0xbdd200: CheckStackOverflow
    //     0xbdd200: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdd204: cmp             SP, x16
    //     0xbdd208: b.ls            #0xbdd2bc
    // 0xbdd20c: ldr             x1, [fp, #0x18]
    // 0xbdd210: LoadField: r0 = r1->field_47
    //     0xbdd210: ldur            w0, [x1, #0x47]
    // 0xbdd214: DecompressPointer r0
    //     0xbdd214: add             x0, x0, HEAP, lsl #32
    // 0xbdd218: cmp             w0, NULL
    // 0xbdd21c: b.eq            #0xbdd2c4
    // 0xbdd220: ldr             x0, [fp, #0x10]
    // 0xbdd224: r2 = LoadClassIdInstr(r0)
    //     0xbdd224: ldur            x2, [x0, #-1]
    //     0xbdd228: ubfx            x2, x2, #0xc, #0x14
    // 0xbdd22c: SaveReg r0
    //     0xbdd22c: str             x0, [SP, #-8]!
    // 0xbdd230: mov             x0, x2
    // 0xbdd234: r0 = GDT[cid_x0 + -0xfff]()
    //     0xbdd234: sub             lr, x0, #0xfff
    //     0xbdd238: ldr             lr, [x21, lr, lsl #3]
    //     0xbdd23c: blr             lr
    // 0xbdd240: add             SP, SP, #8
    // 0xbdd244: ldr             x16, [fp, #0x18]
    // 0xbdd248: stp             x0, x16, [SP, #-0x10]!
    // 0xbdd24c: r0 = getKindForPointer()
    //     0xbdd24c: bl              #0x719b14  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xbdd250: add             SP, SP, #0x10
    // 0xbdd254: ldr             x1, [fp, #0x18]
    // 0xbdd258: LoadField: r2 = r1->field_4b
    //     0xbdd258: ldur            w2, [x1, #0x4b]
    // 0xbdd25c: DecompressPointer r2
    //     0xbdd25c: add             x2, x2, HEAP, lsl #32
    // 0xbdd260: r1 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0xbdd260: mov             x1, #0x76
    //     0xbdd264: tbz             w2, #0, #0xbdd274
    //     0xbdd268: ldur            x1, [x2, #-1]
    //     0xbdd26c: ubfx            x1, x1, #0xc, #0x14
    //     0xbdd270: lsl             x1, x1, #1
    // 0xbdd274: cmp             w1, #0x76
    // 0xbdd278: b.ne            #0xbdd2ac
    // 0xbdd27c: r1 = LoadInt32Instr(r2)
    //     0xbdd27c: sbfx            x1, x2, #1, #0x1f
    // 0xbdd280: cmp             x1, #2
    // 0xbdd284: b.gt            #0xbdd29c
    // 0xbdd288: cmp             x1, #1
    // 0xbdd28c: b.gt            #0xbdd2ac
    // 0xbdd290: cmp             w2, #2
    // 0xbdd294: b.ne            #0xbdd2ac
    // 0xbdd298: b               #0xbdd2ac
    // 0xbdd29c: cmp             x1, #4
    // 0xbdd2a0: b.lt            #0xbdd2ac
    // 0xbdd2a4: cmp             w2, #8
    // 0xbdd2a8: b.eq            #0xbdd2ac
    // 0xbdd2ac: r0 = Null
    //     0xbdd2ac: mov             x0, NULL
    // 0xbdd2b0: LeaveFrame
    //     0xbdd2b0: mov             SP, fp
    //     0xbdd2b4: ldp             fp, lr, [SP], #0x10
    // 0xbdd2b8: ret
    //     0xbdd2b8: ret             
    // 0xbdd2bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdd2bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdd2c0: b               #0xbdd20c
    // 0xbdd2c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdd2c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkLongPressEnd(/* No info */) {
    // ** addr: 0xbdd2c8, size: 0x1d4
    // 0xbdd2c8: EnterFrame
    //     0xbdd2c8: stp             fp, lr, [SP, #-0x10]!
    //     0xbdd2cc: mov             fp, SP
    // 0xbdd2d0: AllocStack(0x20)
    //     0xbdd2d0: sub             SP, SP, #0x20
    // 0xbdd2d4: CheckStackOverflow
    //     0xbdd2d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdd2d8: cmp             SP, x16
    //     0xbdd2dc: b.ls            #0xbdd490
    // 0xbdd2e0: r1 = 2
    //     0xbdd2e0: mov             x1, #2
    // 0xbdd2e4: r0 = AllocateContext()
    //     0xbdd2e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbdd2e8: mov             x1, x0
    // 0xbdd2ec: ldr             x0, [fp, #0x18]
    // 0xbdd2f0: stur            x1, [fp, #-8]
    // 0xbdd2f4: StoreField: r1->field_f = r0
    //     0xbdd2f4: stur            w0, [x1, #0xf]
    // 0xbdd2f8: LoadField: r2 = r0->field_a3
    //     0xbdd2f8: ldur            w2, [x0, #0xa3]
    // 0xbdd2fc: DecompressPointer r2
    //     0xbdd2fc: add             x2, x2, HEAP, lsl #32
    // 0xbdd300: cmp             w2, NULL
    // 0xbdd304: b.eq            #0xbdd498
    // 0xbdd308: SaveReg r2
    //     0xbdd308: str             x2, [SP, #-8]!
    // 0xbdd30c: r0 = getVelocityEstimate()
    //     0xbdd30c: bl              #0xcb5194  ; [package:flutter/src/gestures/velocity_tracker.dart] VelocityTracker::getVelocityEstimate
    // 0xbdd310: add             SP, SP, #8
    // 0xbdd314: cmp             w0, NULL
    // 0xbdd318: b.ne            #0xbdd328
    // 0xbdd31c: r4 = Instance_Velocity
    //     0xbdd31c: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0xbdd320: ldr             x4, [x4, #0x850]
    // 0xbdd324: b               #0xbdd348
    // 0xbdd328: LoadField: r1 = r0->field_7
    //     0xbdd328: ldur            w1, [x0, #7]
    // 0xbdd32c: DecompressPointer r1
    //     0xbdd32c: add             x1, x1, HEAP, lsl #32
    // 0xbdd330: stur            x1, [fp, #-0x10]
    // 0xbdd334: r0 = Velocity()
    //     0xbdd334: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0xbdd338: mov             x1, x0
    // 0xbdd33c: ldur            x0, [fp, #-0x10]
    // 0xbdd340: StoreField: r1->field_7 = r0
    //     0xbdd340: stur            w0, [x1, #7]
    // 0xbdd344: mov             x4, x1
    // 0xbdd348: ldr             x1, [fp, #0x18]
    // 0xbdd34c: ldr             x3, [fp, #0x10]
    // 0xbdd350: ldur            x2, [fp, #-8]
    // 0xbdd354: stur            x4, [fp, #-0x10]
    // 0xbdd358: r0 = LoadClassIdInstr(r3)
    //     0xbdd358: ldur            x0, [x3, #-1]
    //     0xbdd35c: ubfx            x0, x0, #0xc, #0x14
    // 0xbdd360: SaveReg r3
    //     0xbdd360: str             x3, [SP, #-8]!
    // 0xbdd364: r0 = GDT[cid_x0 + -0xfd9]()
    //     0xbdd364: sub             lr, x0, #0xfd9
    //     0xbdd368: ldr             lr, [x21, lr, lsl #3]
    //     0xbdd36c: blr             lr
    // 0xbdd370: add             SP, SP, #8
    // 0xbdd374: mov             x1, x0
    // 0xbdd378: ldr             x0, [fp, #0x10]
    // 0xbdd37c: stur            x1, [fp, #-0x18]
    // 0xbdd380: r2 = LoadClassIdInstr(r0)
    //     0xbdd380: ldur            x2, [x0, #-1]
    //     0xbdd384: ubfx            x2, x2, #0xc, #0x14
    // 0xbdd388: SaveReg r0
    //     0xbdd388: str             x0, [SP, #-8]!
    // 0xbdd38c: mov             x0, x2
    // 0xbdd390: r0 = GDT[cid_x0 + 0x57c0]()
    //     0xbdd390: mov             x17, #0x57c0
    //     0xbdd394: add             lr, x0, x17
    //     0xbdd398: ldr             lr, [x21, lr, lsl #3]
    //     0xbdd39c: blr             lr
    // 0xbdd3a0: add             SP, SP, #8
    // 0xbdd3a4: stur            x0, [fp, #-0x20]
    // 0xbdd3a8: r0 = LongPressEndDetails()
    //     0xbdd3a8: bl              #0xbdd49c  ; AllocateLongPressEndDetailsStub -> LongPressEndDetails (size=0x14)
    // 0xbdd3ac: mov             x1, x0
    // 0xbdd3b0: ldur            x0, [fp, #-0x18]
    // 0xbdd3b4: StoreField: r1->field_7 = r0
    //     0xbdd3b4: stur            w0, [x1, #7]
    // 0xbdd3b8: ldur            x0, [fp, #-0x10]
    // 0xbdd3bc: StoreField: r1->field_f = r0
    //     0xbdd3bc: stur            w0, [x1, #0xf]
    // 0xbdd3c0: ldur            x0, [fp, #-0x20]
    // 0xbdd3c4: StoreField: r1->field_b = r0
    //     0xbdd3c4: stur            w0, [x1, #0xb]
    // 0xbdd3c8: mov             x0, x1
    // 0xbdd3cc: ldur            x2, [fp, #-8]
    // 0xbdd3d0: StoreField: r2->field_13 = r0
    //     0xbdd3d0: stur            w0, [x2, #0x13]
    //     0xbdd3d4: ldurb           w16, [x2, #-1]
    //     0xbdd3d8: ldurb           w17, [x0, #-1]
    //     0xbdd3dc: and             x16, x17, x16, lsr #2
    //     0xbdd3e0: tst             x16, HEAP, lsr #32
    //     0xbdd3e4: b.eq            #0xbdd3ec
    //     0xbdd3e8: bl              #0xd6828c
    // 0xbdd3ec: ldr             x0, [fp, #0x18]
    // 0xbdd3f0: StoreField: r0->field_a3 = rNULL
    //     0xbdd3f0: stur            NULL, [x0, #0xa3]
    // 0xbdd3f4: LoadField: r1 = r0->field_4b
    //     0xbdd3f4: ldur            w1, [x0, #0x4b]
    // 0xbdd3f8: DecompressPointer r1
    //     0xbdd3f8: add             x1, x1, HEAP, lsl #32
    // 0xbdd3fc: r3 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xbdd3fc: mov             x3, #0x76
    //     0xbdd400: tbz             w1, #0, #0xbdd410
    //     0xbdd404: ldur            x3, [x1, #-1]
    //     0xbdd408: ubfx            x3, x3, #0xc, #0x14
    //     0xbdd40c: lsl             x3, x3, #1
    // 0xbdd410: cmp             w3, #0x76
    // 0xbdd414: b.ne            #0xbdd480
    // 0xbdd418: r3 = LoadInt32Instr(r1)
    //     0xbdd418: sbfx            x3, x1, #1, #0x1f
    // 0xbdd41c: cmp             x3, #2
    // 0xbdd420: b.gt            #0xbdd470
    // 0xbdd424: cmp             x3, #1
    // 0xbdd428: b.gt            #0xbdd480
    // 0xbdd42c: cmp             w1, #2
    // 0xbdd430: b.ne            #0xbdd480
    // 0xbdd434: LoadField: r1 = r0->field_67
    //     0xbdd434: ldur            w1, [x0, #0x67]
    // 0xbdd438: DecompressPointer r1
    //     0xbdd438: add             x1, x1, HEAP, lsl #32
    // 0xbdd43c: cmp             w1, NULL
    // 0xbdd440: b.eq            #0xbdd480
    // 0xbdd444: r1 = Function '<anonymous closure>':.
    //     0xbdd444: add             x1, PP, #0x37, lsl #12  ; [pp+0x37b10] AnonymousClosure: (0xbdd4a8), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapDown (0xcef5cc)
    //     0xbdd448: ldr             x1, [x1, #0xb10]
    // 0xbdd44c: r0 = AllocateClosure()
    //     0xbdd44c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbdd450: r16 = <void?>
    //     0xbdd450: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xbdd454: ldr             lr, [fp, #0x18]
    // 0xbdd458: stp             lr, x16, [SP, #-0x10]!
    // 0xbdd45c: SaveReg r0
    //     0xbdd45c: str             x0, [SP, #-8]!
    // 0xbdd460: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbdd460: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbdd464: r0 = invokeCallback()
    //     0xbdd464: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xbdd468: add             SP, SP, #0x18
    // 0xbdd46c: b               #0xbdd480
    // 0xbdd470: cmp             x3, #4
    // 0xbdd474: b.lt            #0xbdd480
    // 0xbdd478: cmp             w1, #8
    // 0xbdd47c: b.eq            #0xbdd480
    // 0xbdd480: r0 = Null
    //     0xbdd480: mov             x0, NULL
    // 0xbdd484: LeaveFrame
    //     0xbdd484: mov             SP, fp
    //     0xbdd488: ldp             fp, lr, [SP], #0x10
    // 0xbdd48c: ret
    //     0xbdd48c: ret             
    // 0xbdd490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdd490: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdd494: b               #0xbdd2e0
    // 0xbdd498: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdd498: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

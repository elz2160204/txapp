// lib: , url: package:flutter/src/gestures/monodrag.dart

// class id: 1049163, size: 0x8
class :: {
}

// class id: 2352, size: 0x6c, field offset: 0x20
abstract class DragGestureRecognizer extends OneSequenceGestureRecognizer {

  late OffsetPair _pendingDragOffset; // offset: 0x50
  late OffsetPair _initialPosition; // offset: 0x4c
  late double _globalDistanceMoved; // offset: 0x60

  _ DragGestureRecognizer(/* No info */) {
    // ** addr: 0x6ee278, size: 0x14c
    // 0x6ee278: EnterFrame
    //     0x6ee278: stp             fp, lr, [SP, #-0x10]!
    //     0x6ee27c: mov             fp, SP
    // 0x6ee280: AllocStack(0x10)
    //     0x6ee280: sub             SP, SP, #0x10
    // 0x6ee284: r1 = Instance__DragState
    //     0x6ee284: add             x1, PP, #0x21, lsl #12  ; [pp+0x214d8] Obj!_DragState@b65b31
    //     0x6ee288: ldr             x1, [x1, #0x4d8]
    // 0x6ee28c: r0 = Sentinel
    //     0x6ee28c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ee290: CheckStackOverflow
    //     0x6ee290: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ee294: cmp             SP, x16
    //     0x6ee298: b.ls            #0x6ee3bc
    // 0x6ee29c: ldr             x2, [fp, #0x18]
    // 0x6ee2a0: StoreField: r2->field_47 = r1
    //     0x6ee2a0: stur            w1, [x2, #0x47]
    // 0x6ee2a4: StoreField: r2->field_4b = r0
    //     0x6ee2a4: stur            w0, [x2, #0x4b]
    // 0x6ee2a8: StoreField: r2->field_4f = r0
    //     0x6ee2a8: stur            w0, [x2, #0x4f]
    // 0x6ee2ac: StoreField: r2->field_5f = r0
    //     0x6ee2ac: stur            w0, [x2, #0x5f]
    // 0x6ee2b0: r16 = <int, VelocityTracker>
    //     0x6ee2b0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21498] TypeArguments: <int, VelocityTracker>
    //     0x6ee2b4: ldr             x16, [x16, #0x498]
    // 0x6ee2b8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6ee2bc: stp             lr, x16, [SP, #-0x10]!
    // 0x6ee2c0: r0 = Map._fromLiteral()
    //     0x6ee2c0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6ee2c4: add             SP, SP, #0x10
    // 0x6ee2c8: ldr             x1, [fp, #0x18]
    // 0x6ee2cc: StoreField: r1->field_63 = r0
    //     0x6ee2cc: stur            w0, [x1, #0x63]
    //     0x6ee2d0: tbz             w0, #0, #0x6ee2ec
    //     0x6ee2d4: ldurb           w16, [x1, #-1]
    //     0x6ee2d8: ldurb           w17, [x0, #-1]
    //     0x6ee2dc: and             x16, x17, x16, lsr #2
    //     0x6ee2e0: tst             x16, HEAP, lsr #32
    //     0x6ee2e4: b.eq            #0x6ee2ec
    //     0x6ee2e8: bl              #0xd6826c
    // 0x6ee2ec: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x6ee2ec: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6ee2f0: ldr             x0, [x0, #0x598]
    //     0x6ee2f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6ee2f8: cmp             w0, w16
    //     0x6ee2fc: b.ne            #0x6ee308
    //     0x6ee300: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x6ee304: bl              #0xd67cdc
    // 0x6ee308: r1 = <int>
    //     0x6ee308: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x6ee30c: stur            x0, [fp, #-8]
    // 0x6ee310: r0 = _Set()
    //     0x6ee310: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x6ee314: mov             x1, x0
    // 0x6ee318: ldur            x0, [fp, #-8]
    // 0x6ee31c: stur            x1, [fp, #-0x10]
    // 0x6ee320: StoreField: r1->field_1b = r0
    //     0x6ee320: stur            w0, [x1, #0x1b]
    // 0x6ee324: StoreField: r1->field_b = rZR
    //     0x6ee324: stur            wzr, [x1, #0xb]
    // 0x6ee328: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x6ee328: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6ee32c: ldr             x0, [x0, #0x5a0]
    //     0x6ee330: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6ee334: cmp             w0, w16
    //     0x6ee338: b.ne            #0x6ee344
    //     0x6ee33c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x6ee340: bl              #0xd67cdc
    // 0x6ee344: mov             x1, x0
    // 0x6ee348: ldur            x0, [fp, #-0x10]
    // 0x6ee34c: StoreField: r0->field_f = r1
    //     0x6ee34c: stur            w1, [x0, #0xf]
    // 0x6ee350: StoreField: r0->field_13 = rZR
    //     0x6ee350: stur            wzr, [x0, #0x13]
    // 0x6ee354: StoreField: r0->field_17 = rZR
    //     0x6ee354: stur            wzr, [x0, #0x17]
    // 0x6ee358: ldr             x1, [fp, #0x18]
    // 0x6ee35c: StoreField: r1->field_67 = r0
    //     0x6ee35c: stur            w0, [x1, #0x67]
    //     0x6ee360: ldurb           w16, [x1, #-1]
    //     0x6ee364: ldurb           w17, [x0, #-1]
    //     0x6ee368: and             x16, x17, x16, lsr #2
    //     0x6ee36c: tst             x16, HEAP, lsr #32
    //     0x6ee370: b.eq            #0x6ee378
    //     0x6ee374: bl              #0xd6826c
    // 0x6ee378: r0 = Instance_DragStartBehavior
    //     0x6ee378: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x6ee37c: ldr             x0, [x0, #0xf88]
    // 0x6ee380: StoreField: r1->field_1f = r0
    //     0x6ee380: stur            w0, [x1, #0x1f]
    // 0x6ee384: r0 = Closure: (PointerEvent) => VelocityTracker from Function '_defaultBuilder@666099969': static.
    //     0x6ee384: add             x0, PP, #0x21, lsl #12  ; [pp+0x214e0] Closure: (PointerEvent) => VelocityTracker from Function '_defaultBuilder@666099969': static. (0x7fe6e1eee3c4)
    //     0x6ee388: ldr             x0, [x0, #0x4e0]
    // 0x6ee38c: StoreField: r1->field_43 = r0
    //     0x6ee38c: stur            w0, [x1, #0x43]
    // 0x6ee390: stp             NULL, x1, [SP, #-0x10]!
    // 0x6ee394: ldr             x16, [fp, #0x10]
    // 0x6ee398: SaveReg r16
    //     0x6ee398: str             x16, [SP, #-8]!
    // 0x6ee39c: r4 = const [0, 0x3, 0x3, 0x1, kind, 0x1, supportedDevices, 0x2, null]
    //     0x6ee39c: add             x4, PP, #0x21, lsl #12  ; [pp+0x214b0] List(9) [0, 0x3, 0x3, 0x1, "kind", 0x1, "supportedDevices", 0x2, Null]
    //     0x6ee3a0: ldr             x4, [x4, #0x4b0]
    // 0x6ee3a4: r0 = OneSequenceGestureRecognizer()
    //     0x6ee3a4: bl              #0x6d3ef4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0x6ee3a8: add             SP, SP, #0x18
    // 0x6ee3ac: r0 = Null
    //     0x6ee3ac: mov             x0, NULL
    // 0x6ee3b0: LeaveFrame
    //     0x6ee3b0: mov             SP, fp
    //     0x6ee3b4: ldp             fp, lr, [SP], #0x10
    // 0x6ee3b8: ret
    //     0x6ee3b8: ret             
    // 0x6ee3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ee3bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ee3c0: b               #0x6ee29c
  }
  [closure] static VelocityTracker _defaultBuilder(dynamic, PointerEvent) {
    // ** addr: 0x6ee3c4, size: 0x38
    // 0x6ee3c4: EnterFrame
    //     0x6ee3c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ee3c8: mov             fp, SP
    // 0x6ee3cc: CheckStackOverflow
    //     0x6ee3cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ee3d0: cmp             SP, x16
    //     0x6ee3d4: b.ls            #0x6ee3f4
    // 0x6ee3d8: ldr             x16, [fp, #0x10]
    // 0x6ee3dc: SaveReg r16
    //     0x6ee3dc: str             x16, [SP, #-8]!
    // 0x6ee3e0: r0 = <anonymous closure>()
    //     0x6ee3e0: bl              #0x6ee3fc  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollBehavior::<anonymous closure>
    // 0x6ee3e4: add             SP, SP, #8
    // 0x6ee3e8: LeaveFrame
    //     0x6ee3e8: mov             SP, fp
    //     0x6ee3ec: ldp             fp, lr, [SP], #0x10
    // 0x6ee3f0: ret
    //     0x6ee3f0: ret             
    // 0x6ee3f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ee3f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ee3f8: b               #0x6ee3d8
  }
  _ didStopTrackingLastPointer(/* No info */) {
    // ** addr: 0x7144c8, size: 0xb8
    // 0x7144c8: EnterFrame
    //     0x7144c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7144cc: mov             fp, SP
    // 0x7144d0: CheckStackOverflow
    //     0x7144d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7144d4: cmp             SP, x16
    //     0x7144d8: b.ls            #0x714578
    // 0x7144dc: ldr             x0, [fp, #0x18]
    // 0x7144e0: LoadField: r1 = r0->field_47
    //     0x7144e0: ldur            w1, [x0, #0x47]
    // 0x7144e4: DecompressPointer r1
    //     0x7144e4: add             x1, x1, HEAP, lsl #32
    // 0x7144e8: LoadField: r2 = r1->field_7
    //     0x7144e8: ldur            x2, [x1, #7]
    // 0x7144ec: cmp             x2, #1
    // 0x7144f0: b.gt            #0x714528
    // 0x7144f4: cmp             x2, #0
    // 0x7144f8: b.le            #0x714540
    // 0x7144fc: r16 = Instance_GestureDisposition
    //     0x7144fc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x714500: ldr             x16, [x16, #0xeb8]
    // 0x714504: stp             x16, x0, [SP, #-0x10]!
    // 0x714508: r0 = resolve()
    //     0x714508: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x71450c: add             SP, SP, #0x10
    // 0x714510: ldr             x16, [fp, #0x18]
    // 0x714514: SaveReg r16
    //     0x714514: str             x16, [SP, #-8]!
    // 0x714518: r0 = _checkCancel()
    //     0x714518: bl              #0x7149b0  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkCancel
    // 0x71451c: add             SP, SP, #8
    // 0x714520: ldr             x0, [fp, #0x18]
    // 0x714524: b               #0x714540
    // 0x714528: ldr             x0, [fp, #0x10]
    // 0x71452c: ldr             x16, [fp, #0x18]
    // 0x714530: stp             x0, x16, [SP, #-0x10]!
    // 0x714534: r0 = _checkEnd()
    //     0x714534: bl              #0x714580  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkEnd
    // 0x714538: add             SP, SP, #0x10
    // 0x71453c: ldr             x0, [fp, #0x18]
    // 0x714540: LoadField: r1 = r0->field_63
    //     0x714540: ldur            w1, [x0, #0x63]
    // 0x714544: DecompressPointer r1
    //     0x714544: add             x1, x1, HEAP, lsl #32
    // 0x714548: SaveReg r1
    //     0x714548: str             x1, [SP, #-8]!
    // 0x71454c: r0 = clear()
    //     0x71454c: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x714550: add             SP, SP, #8
    // 0x714554: ldr             x1, [fp, #0x18]
    // 0x714558: StoreField: r1->field_57 = rNULL
    //     0x714558: stur            NULL, [x1, #0x57]
    // 0x71455c: r2 = Instance__DragState
    //     0x71455c: add             x2, PP, #0x21, lsl #12  ; [pp+0x214d8] Obj!_DragState@b65b31
    //     0x714560: ldr             x2, [x2, #0x4d8]
    // 0x714564: StoreField: r1->field_47 = r2
    //     0x714564: stur            w2, [x1, #0x47]
    // 0x714568: r0 = Null
    //     0x714568: mov             x0, NULL
    // 0x71456c: LeaveFrame
    //     0x71456c: mov             SP, fp
    //     0x714570: ldp             fp, lr, [SP], #0x10
    // 0x714574: ret
    //     0x714574: ret             
    // 0x714578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714578: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71457c: b               #0x7144dc
  }
  _ _checkEnd(/* No info */) {
    // ** addr: 0x714580, size: 0x3c0
    // 0x714580: EnterFrame
    //     0x714580: stp             fp, lr, [SP, #-0x10]!
    //     0x714584: mov             fp, SP
    // 0x714588: AllocStack(0x18)
    //     0x714588: sub             SP, SP, #0x18
    // 0x71458c: CheckStackOverflow
    //     0x71458c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714590: cmp             SP, x16
    //     0x714594: b.ls            #0x7148d0
    // 0x714598: r1 = 4
    //     0x714598: mov             x1, #4
    // 0x71459c: r0 = AllocateContext()
    //     0x71459c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7145a0: mov             x3, x0
    // 0x7145a4: ldr             x2, [fp, #0x18]
    // 0x7145a8: stur            x3, [fp, #-0x10]
    // 0x7145ac: StoreField: r3->field_f = r2
    //     0x7145ac: stur            w2, [x3, #0xf]
    // 0x7145b0: LoadField: r0 = r2->field_2f
    //     0x7145b0: ldur            w0, [x2, #0x2f]
    // 0x7145b4: DecompressPointer r0
    //     0x7145b4: add             x0, x0, HEAP, lsl #32
    // 0x7145b8: cmp             w0, NULL
    // 0x7145bc: b.ne            #0x7145d0
    // 0x7145c0: r0 = Null
    //     0x7145c0: mov             x0, NULL
    // 0x7145c4: LeaveFrame
    //     0x7145c4: mov             SP, fp
    //     0x7145c8: ldp             fp, lr, [SP], #0x10
    // 0x7145cc: ret
    //     0x7145cc: ret             
    // 0x7145d0: ldr             x4, [fp, #0x10]
    // 0x7145d4: LoadField: r5 = r2->field_63
    //     0x7145d4: ldur            w5, [x2, #0x63]
    // 0x7145d8: DecompressPointer r5
    //     0x7145d8: add             x5, x5, HEAP, lsl #32
    // 0x7145dc: stur            x5, [fp, #-8]
    // 0x7145e0: r0 = BoxInt64Instr(r4)
    //     0x7145e0: sbfiz           x0, x4, #1, #0x1f
    //     0x7145e4: cmp             x4, x0, asr #1
    //     0x7145e8: b.eq            #0x7145f4
    //     0x7145ec: bl              #0xd69bb8
    //     0x7145f0: stur            x4, [x0, #7]
    // 0x7145f4: stp             x0, x5, [SP, #-0x10]!
    // 0x7145f8: r0 = _getValueOrData()
    //     0x7145f8: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x7145fc: add             SP, SP, #0x10
    // 0x714600: mov             x1, x0
    // 0x714604: ldur            x0, [fp, #-8]
    // 0x714608: LoadField: r2 = r0->field_f
    //     0x714608: ldur            w2, [x0, #0xf]
    // 0x71460c: DecompressPointer r2
    //     0x71460c: add             x2, x2, HEAP, lsl #32
    // 0x714610: cmp             w2, w1
    // 0x714614: b.ne            #0x71461c
    // 0x714618: r1 = Null
    //     0x714618: mov             x1, NULL
    // 0x71461c: ldur            x2, [fp, #-0x10]
    // 0x714620: stur            x1, [fp, #-8]
    // 0x714624: cmp             w1, NULL
    // 0x714628: b.eq            #0x7148d8
    // 0x71462c: StoreField: r2->field_13 = rNULL
    //     0x71462c: stur            NULL, [x2, #0x13]
    // 0x714630: r0 = LoadClassIdInstr(r1)
    //     0x714630: ldur            x0, [x1, #-1]
    //     0x714634: ubfx            x0, x0, #0xc, #0x14
    // 0x714638: SaveReg r1
    //     0x714638: str             x1, [SP, #-8]!
    // 0x71463c: r0 = GDT[cid_x0 + -0xf7d]()
    //     0x71463c: sub             lr, x0, #0xf7d
    //     0x714640: ldr             lr, [x21, lr, lsl #3]
    //     0x714644: blr             lr
    // 0x714648: add             SP, SP, #8
    // 0x71464c: mov             x1, x0
    // 0x714650: ldur            x2, [fp, #-0x10]
    // 0x714654: stur            x1, [fp, #-0x18]
    // 0x714658: StoreField: r2->field_17 = r0
    //     0x714658: stur            w0, [x2, #0x17]
    //     0x71465c: ldurb           w16, [x2, #-1]
    //     0x714660: ldurb           w17, [x0, #-1]
    //     0x714664: and             x16, x17, x16, lsr #2
    //     0x714668: tst             x16, HEAP, lsr #32
    //     0x71466c: b.eq            #0x714674
    //     0x714670: bl              #0xd6828c
    // 0x714674: cmp             w1, NULL
    // 0x714678: b.eq            #0x714858
    // 0x71467c: ldr             x3, [fp, #0x18]
    // 0x714680: ldur            x0, [fp, #-8]
    // 0x714684: LoadField: r4 = r0->field_7
    //     0x714684: ldur            w4, [x0, #7]
    // 0x714688: DecompressPointer r4
    //     0x714688: add             x4, x4, HEAP, lsl #32
    // 0x71468c: r0 = LoadClassIdInstr(r3)
    //     0x71468c: ldur            x0, [x3, #-1]
    //     0x714690: ubfx            x0, x0, #0xc, #0x14
    // 0x714694: stp             x1, x3, [SP, #-0x10]!
    // 0x714698: SaveReg r4
    //     0x714698: str             x4, [SP, #-8]!
    // 0x71469c: r0 = GDT[cid_x0 + -0x92a]()
    //     0x71469c: sub             lr, x0, #0x92a
    //     0x7146a0: ldr             lr, [x21, lr, lsl #3]
    //     0x7146a4: blr             lr
    // 0x7146a8: add             SP, SP, #0x18
    // 0x7146ac: tbnz            w0, #4, #0x714854
    // 0x7146b0: ldr             x1, [fp, #0x18]
    // 0x7146b4: ldur            x0, [fp, #-0x18]
    // 0x7146b8: LoadField: r2 = r0->field_7
    //     0x7146b8: ldur            w2, [x0, #7]
    // 0x7146bc: DecompressPointer r2
    //     0x7146bc: add             x2, x2, HEAP, lsl #32
    // 0x7146c0: stur            x2, [fp, #-8]
    // 0x7146c4: r0 = Velocity()
    //     0x7146c4: bl              #0x713f24  ; AllocateVelocityStub -> Velocity (size=0xc)
    // 0x7146c8: mov             x1, x0
    // 0x7146cc: ldur            x0, [fp, #-8]
    // 0x7146d0: StoreField: r1->field_7 = r0
    //     0x7146d0: stur            w0, [x1, #7]
    // 0x7146d4: ldr             x0, [fp, #0x18]
    // 0x7146d8: LoadField: r2 = r0->field_3b
    //     0x7146d8: ldur            w2, [x0, #0x3b]
    // 0x7146dc: DecompressPointer r2
    //     0x7146dc: add             x2, x2, HEAP, lsl #32
    // 0x7146e0: cmp             w2, NULL
    // 0x7146e4: b.ne            #0x7146f4
    // 0x7146e8: d0 = 50.000000
    //     0x7146e8: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0x7146ec: ldr             d0, [x17, #0x980]
    // 0x7146f0: b               #0x7146f8
    // 0x7146f4: LoadField: d0 = r2->field_7
    //     0x7146f4: ldur            d0, [x2, #7]
    // 0x7146f8: LoadField: r2 = r0->field_3f
    //     0x7146f8: ldur            w2, [x0, #0x3f]
    // 0x7146fc: DecompressPointer r2
    //     0x7146fc: add             x2, x2, HEAP, lsl #32
    // 0x714700: cmp             w2, NULL
    // 0x714704: b.ne            #0x714714
    // 0x714708: d1 = 8000.000000
    //     0x714708: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e910] IMM: double(8000) from 0x40bf400000000000
    //     0x71470c: ldr             d1, [x17, #0x910]
    // 0x714710: b               #0x714718
    // 0x714714: LoadField: d1 = r2->field_7
    //     0x714714: ldur            d1, [x2, #7]
    // 0x714718: ldur            x2, [fp, #-0x10]
    // 0x71471c: r3 = inline_Allocate_Double()
    //     0x71471c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x714720: add             x3, x3, #0x10
    //     0x714724: cmp             x4, x3
    //     0x714728: b.ls            #0x7148dc
    //     0x71472c: str             x3, [THR, #0x60]  ; THR::top
    //     0x714730: sub             x3, x3, #0xf
    //     0x714734: mov             x4, #0xd108
    //     0x714738: movk            x4, #3, lsl #16
    //     0x71473c: stur            x4, [x3, #-1]
    // 0x714740: StoreField: r3->field_7 = d0
    //     0x714740: stur            d0, [x3, #7]
    // 0x714744: stp             x3, x1, [SP, #-0x10]!
    // 0x714748: SaveReg d1
    //     0x714748: str             d1, [SP, #-8]!
    // 0x71474c: r0 = clampMagnitude()
    //     0x71474c: bl              #0x713c18  ; [package:flutter/src/gestures/velocity_tracker.dart] Velocity::clampMagnitude
    // 0x714750: add             SP, SP, #0x18
    // 0x714754: mov             x1, x0
    // 0x714758: ldur            x2, [fp, #-0x10]
    // 0x71475c: stur            x1, [fp, #-0x18]
    // 0x714760: StoreField: r2->field_1b = r0
    //     0x714760: stur            w0, [x2, #0x1b]
    //     0x714764: ldurb           w16, [x2, #-1]
    //     0x714768: ldurb           w17, [x0, #-1]
    //     0x71476c: and             x16, x17, x16, lsr #2
    //     0x714770: tst             x16, HEAP, lsr #32
    //     0x714774: b.eq            #0x71477c
    //     0x714778: bl              #0xd6828c
    // 0x71477c: LoadField: r0 = r1->field_7
    //     0x71477c: ldur            w0, [x1, #7]
    // 0x714780: DecompressPointer r0
    //     0x714780: add             x0, x0, HEAP, lsl #32
    // 0x714784: ldr             x3, [fp, #0x18]
    // 0x714788: r4 = LoadClassIdInstr(r3)
    //     0x714788: ldur            x4, [x3, #-1]
    //     0x71478c: ubfx            x4, x4, #0xc, #0x14
    // 0x714790: lsl             x4, x4, #1
    // 0x714794: r17 = 4706
    //     0x714794: mov             x17, #0x1262
    // 0x714798: cmp             w4, w17
    // 0x71479c: b.ne            #0x7147a8
    // 0x7147a0: r0 = Null
    //     0x7147a0: mov             x0, NULL
    // 0x7147a4: b               #0x714810
    // 0x7147a8: r17 = 4708
    //     0x7147a8: mov             x17, #0x1264
    // 0x7147ac: cmp             w4, w17
    // 0x7147b0: b.ne            #0x7147e4
    // 0x7147b4: LoadField: d0 = r0->field_7
    //     0x7147b4: ldur            d0, [x0, #7]
    // 0x7147b8: r0 = inline_Allocate_Double()
    //     0x7147b8: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x7147bc: add             x0, x0, #0x10
    //     0x7147c0: cmp             x4, x0
    //     0x7147c4: b.ls            #0x714900
    //     0x7147c8: str             x0, [THR, #0x60]  ; THR::top
    //     0x7147cc: sub             x0, x0, #0xf
    //     0x7147d0: mov             x4, #0xd108
    //     0x7147d4: movk            x4, #3, lsl #16
    //     0x7147d8: stur            x4, [x0, #-1]
    // 0x7147dc: StoreField: r0->field_7 = d0
    //     0x7147dc: stur            d0, [x0, #7]
    // 0x7147e0: b               #0x714810
    // 0x7147e4: LoadField: d0 = r0->field_f
    //     0x7147e4: ldur            d0, [x0, #0xf]
    // 0x7147e8: r0 = inline_Allocate_Double()
    //     0x7147e8: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x7147ec: add             x0, x0, #0x10
    //     0x7147f0: cmp             x4, x0
    //     0x7147f4: b.ls            #0x714920
    //     0x7147f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x7147fc: sub             x0, x0, #0xf
    //     0x714800: mov             x4, #0xd108
    //     0x714804: movk            x4, #3, lsl #16
    //     0x714808: stur            x4, [x0, #-1]
    // 0x71480c: StoreField: r0->field_7 = d0
    //     0x71480c: stur            d0, [x0, #7]
    // 0x714810: stur            x0, [fp, #-8]
    // 0x714814: r0 = DragEndDetails()
    //     0x714814: bl              #0x713c0c  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x10)
    // 0x714818: mov             x1, x0
    // 0x71481c: ldur            x0, [fp, #-0x18]
    // 0x714820: StoreField: r1->field_7 = r0
    //     0x714820: stur            w0, [x1, #7]
    // 0x714824: ldur            x0, [fp, #-8]
    // 0x714828: StoreField: r1->field_b = r0
    //     0x714828: stur            w0, [x1, #0xb]
    // 0x71482c: mov             x0, x1
    // 0x714830: ldur            x2, [fp, #-0x10]
    // 0x714834: StoreField: r2->field_13 = r0
    //     0x714834: stur            w0, [x2, #0x13]
    //     0x714838: ldurb           w16, [x2, #-1]
    //     0x71483c: ldurb           w17, [x0, #-1]
    //     0x714840: and             x16, x17, x16, lsr #2
    //     0x714844: tst             x16, HEAP, lsr #32
    //     0x714848: b.eq            #0x714850
    //     0x71484c: bl              #0xd6828c
    // 0x714850: b               #0x714898
    // 0x714854: ldur            x2, [fp, #-0x10]
    // 0x714858: r0 = DragEndDetails()
    //     0x714858: bl              #0x713c0c  ; AllocateDragEndDetailsStub -> DragEndDetails (size=0x10)
    // 0x71485c: mov             x1, x0
    // 0x714860: r0 = Instance_Velocity
    //     0x714860: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e850] Obj!Velocity@b38701
    //     0x714864: ldr             x0, [x0, #0x850]
    // 0x714868: StoreField: r1->field_7 = r0
    //     0x714868: stur            w0, [x1, #7]
    // 0x71486c: r0 = 0.000000
    //     0x71486c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x714870: StoreField: r1->field_b = r0
    //     0x714870: stur            w0, [x1, #0xb]
    // 0x714874: mov             x0, x1
    // 0x714878: ldur            x2, [fp, #-0x10]
    // 0x71487c: StoreField: r2->field_13 = r0
    //     0x71487c: stur            w0, [x2, #0x13]
    //     0x714880: ldurb           w16, [x2, #-1]
    //     0x714884: ldurb           w17, [x0, #-1]
    //     0x714888: and             x16, x17, x16, lsr #2
    //     0x71488c: tst             x16, HEAP, lsr #32
    //     0x714890: b.eq            #0x714898
    //     0x714894: bl              #0xd6828c
    // 0x714898: r1 = Function '<anonymous closure>':.
    //     0x714898: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e918] AnonymousClosure: (0x714940), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkEnd (0x714580)
    //     0x71489c: ldr             x1, [x1, #0x918]
    // 0x7148a0: r0 = AllocateClosure()
    //     0x7148a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7148a4: r16 = <void?>
    //     0x7148a4: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7148a8: ldr             lr, [fp, #0x18]
    // 0x7148ac: stp             lr, x16, [SP, #-0x10]!
    // 0x7148b0: SaveReg r0
    //     0x7148b0: str             x0, [SP, #-8]!
    // 0x7148b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7148b4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7148b8: r0 = invokeCallback()
    //     0x7148b8: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x7148bc: add             SP, SP, #0x18
    // 0x7148c0: r0 = Null
    //     0x7148c0: mov             x0, NULL
    // 0x7148c4: LeaveFrame
    //     0x7148c4: mov             SP, fp
    //     0x7148c8: ldp             fp, lr, [SP], #0x10
    // 0x7148cc: ret
    //     0x7148cc: ret             
    // 0x7148d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7148d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7148d4: b               #0x714598
    // 0x7148d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7148d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7148dc: stp             q0, q1, [SP, #-0x20]!
    // 0x7148e0: stp             x1, x2, [SP, #-0x10]!
    // 0x7148e4: SaveReg r0
    //     0x7148e4: str             x0, [SP, #-8]!
    // 0x7148e8: r0 = AllocateDouble()
    //     0x7148e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7148ec: mov             x3, x0
    // 0x7148f0: RestoreReg r0
    //     0x7148f0: ldr             x0, [SP], #8
    // 0x7148f4: ldp             x1, x2, [SP], #0x10
    // 0x7148f8: ldp             q0, q1, [SP], #0x20
    // 0x7148fc: b               #0x714740
    // 0x714900: SaveReg d0
    //     0x714900: str             q0, [SP, #-0x10]!
    // 0x714904: stp             x2, x3, [SP, #-0x10]!
    // 0x714908: SaveReg r1
    //     0x714908: str             x1, [SP, #-8]!
    // 0x71490c: r0 = AllocateDouble()
    //     0x71490c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x714910: RestoreReg r1
    //     0x714910: ldr             x1, [SP], #8
    // 0x714914: ldp             x2, x3, [SP], #0x10
    // 0x714918: RestoreReg d0
    //     0x714918: ldr             q0, [SP], #0x10
    // 0x71491c: b               #0x7147dc
    // 0x714920: SaveReg d0
    //     0x714920: str             q0, [SP, #-0x10]!
    // 0x714924: stp             x2, x3, [SP, #-0x10]!
    // 0x714928: SaveReg r1
    //     0x714928: str             x1, [SP, #-8]!
    // 0x71492c: r0 = AllocateDouble()
    //     0x71492c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x714930: RestoreReg r1
    //     0x714930: ldr             x1, [SP], #8
    // 0x714934: ldp             x2, x3, [SP], #0x10
    // 0x714938: RestoreReg d0
    //     0x714938: ldr             q0, [SP], #0x10
    // 0x71493c: b               #0x71480c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x714940, size: 0x70
    // 0x714940: EnterFrame
    //     0x714940: stp             fp, lr, [SP, #-0x10]!
    //     0x714944: mov             fp, SP
    // 0x714948: ldr             x0, [fp, #0x10]
    // 0x71494c: LoadField: r1 = r0->field_17
    //     0x71494c: ldur            w1, [x0, #0x17]
    // 0x714950: DecompressPointer r1
    //     0x714950: add             x1, x1, HEAP, lsl #32
    // 0x714954: CheckStackOverflow
    //     0x714954: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x714958: cmp             SP, x16
    //     0x71495c: b.ls            #0x7149a4
    // 0x714960: LoadField: r0 = r1->field_f
    //     0x714960: ldur            w0, [x1, #0xf]
    // 0x714964: DecompressPointer r0
    //     0x714964: add             x0, x0, HEAP, lsl #32
    // 0x714968: LoadField: r2 = r0->field_2f
    //     0x714968: ldur            w2, [x0, #0x2f]
    // 0x71496c: DecompressPointer r2
    //     0x71496c: add             x2, x2, HEAP, lsl #32
    // 0x714970: cmp             w2, NULL
    // 0x714974: b.eq            #0x7149ac
    // 0x714978: LoadField: r0 = r1->field_13
    //     0x714978: ldur            w0, [x1, #0x13]
    // 0x71497c: DecompressPointer r0
    //     0x71497c: add             x0, x0, HEAP, lsl #32
    // 0x714980: stp             x0, x2, [SP, #-0x10]!
    // 0x714984: mov             x0, x2
    // 0x714988: ClosureCall
    //     0x714988: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x71498c: ldur            x2, [x0, #0x1f]
    //     0x714990: blr             x2
    // 0x714994: add             SP, SP, #0x10
    // 0x714998: LeaveFrame
    //     0x714998: mov             SP, fp
    //     0x71499c: ldp             fp, lr, [SP], #0x10
    // 0x7149a0: ret
    //     0x7149a0: ret             
    // 0x7149a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7149a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7149a8: b               #0x714960
    // 0x7149ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7149ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkCancel(/* No info */) {
    // ** addr: 0x7149b0, size: 0x58
    // 0x7149b0: EnterFrame
    //     0x7149b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7149b4: mov             fp, SP
    // 0x7149b8: CheckStackOverflow
    //     0x7149b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7149bc: cmp             SP, x16
    //     0x7149c0: b.ls            #0x714a00
    // 0x7149c4: ldr             x0, [fp, #0x10]
    // 0x7149c8: LoadField: r1 = r0->field_33
    //     0x7149c8: ldur            w1, [x0, #0x33]
    // 0x7149cc: DecompressPointer r1
    //     0x7149cc: add             x1, x1, HEAP, lsl #32
    // 0x7149d0: cmp             w1, NULL
    // 0x7149d4: b.eq            #0x7149f0
    // 0x7149d8: r16 = <void?>
    //     0x7149d8: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7149dc: stp             x0, x16, [SP, #-0x10]!
    // 0x7149e0: SaveReg r1
    //     0x7149e0: str             x1, [SP, #-8]!
    // 0x7149e4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7149e4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7149e8: r0 = invokeCallback()
    //     0x7149e8: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x7149ec: add             SP, SP, #0x18
    // 0x7149f0: r0 = Null
    //     0x7149f0: mov             x0, NULL
    // 0x7149f4: LeaveFrame
    //     0x7149f4: mov             SP, fp
    //     0x7149f8: ldp             fp, lr, [SP], #0x10
    // 0x7149fc: ret
    //     0x7149fc: ret             
    // 0x714a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x714a00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x714a04: b               #0x7149c4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x71997c, size: 0x70
    // 0x71997c: EnterFrame
    //     0x71997c: stp             fp, lr, [SP, #-0x10]!
    //     0x719980: mov             fp, SP
    // 0x719984: ldr             x0, [fp, #0x10]
    // 0x719988: LoadField: r1 = r0->field_17
    //     0x719988: ldur            w1, [x0, #0x17]
    // 0x71998c: DecompressPointer r1
    //     0x71998c: add             x1, x1, HEAP, lsl #32
    // 0x719990: CheckStackOverflow
    //     0x719990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x719994: cmp             SP, x16
    //     0x719998: b.ls            #0x7199e0
    // 0x71999c: LoadField: r0 = r1->field_f
    //     0x71999c: ldur            w0, [x1, #0xf]
    // 0x7199a0: DecompressPointer r0
    //     0x7199a0: add             x0, x0, HEAP, lsl #32
    // 0x7199a4: LoadField: r2 = r0->field_27
    //     0x7199a4: ldur            w2, [x0, #0x27]
    // 0x7199a8: DecompressPointer r2
    //     0x7199a8: add             x2, x2, HEAP, lsl #32
    // 0x7199ac: cmp             w2, NULL
    // 0x7199b0: b.eq            #0x7199e8
    // 0x7199b4: LoadField: r0 = r1->field_13
    //     0x7199b4: ldur            w0, [x1, #0x13]
    // 0x7199b8: DecompressPointer r0
    //     0x7199b8: add             x0, x0, HEAP, lsl #32
    // 0x7199bc: stp             x0, x2, [SP, #-0x10]!
    // 0x7199c0: mov             x0, x2
    // 0x7199c4: ClosureCall
    //     0x7199c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7199c8: ldur            x2, [x0, #0x1f]
    //     0x7199cc: blr             x2
    // 0x7199d0: add             SP, SP, #0x10
    // 0x7199d4: LeaveFrame
    //     0x7199d4: mov             SP, fp
    //     0x7199d8: ldp             fp, lr, [SP], #0x10
    // 0x7199dc: ret
    //     0x7199dc: ret             
    // 0x7199e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7199e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7199e4: b               #0x71999c
    // 0x7199e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7199e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkStart(/* No info */) {
    // ** addr: 0x7199ec, size: 0x11c
    // 0x7199ec: EnterFrame
    //     0x7199ec: stp             fp, lr, [SP, #-0x10]!
    //     0x7199f0: mov             fp, SP
    // 0x7199f4: AllocStack(0x20)
    //     0x7199f4: sub             SP, SP, #0x20
    // 0x7199f8: CheckStackOverflow
    //     0x7199f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7199fc: cmp             SP, x16
    //     0x719a00: b.ls            #0x719af4
    // 0x719a04: r1 = 2
    //     0x719a04: mov             x1, #2
    // 0x719a08: r0 = AllocateContext()
    //     0x719a08: bl              #0xd68aa4  ; AllocateContextStub
    // 0x719a0c: mov             x1, x0
    // 0x719a10: ldr             x0, [fp, #0x20]
    // 0x719a14: stur            x1, [fp, #-0x18]
    // 0x719a18: StoreField: r1->field_f = r0
    //     0x719a18: stur            w0, [x1, #0xf]
    // 0x719a1c: LoadField: r2 = r0->field_27
    //     0x719a1c: ldur            w2, [x0, #0x27]
    // 0x719a20: DecompressPointer r2
    //     0x719a20: add             x2, x2, HEAP, lsl #32
    // 0x719a24: cmp             w2, NULL
    // 0x719a28: b.eq            #0x719ae4
    // 0x719a2c: ldr             x3, [fp, #0x18]
    // 0x719a30: ldr             x2, [fp, #0x10]
    // 0x719a34: LoadField: r4 = r0->field_4b
    //     0x719a34: ldur            w4, [x0, #0x4b]
    // 0x719a38: DecompressPointer r4
    //     0x719a38: add             x4, x4, HEAP, lsl #32
    // 0x719a3c: r16 = Sentinel
    //     0x719a3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x719a40: cmp             w4, w16
    // 0x719a44: b.eq            #0x719afc
    // 0x719a48: LoadField: r5 = r4->field_b
    //     0x719a48: ldur            w5, [x4, #0xb]
    // 0x719a4c: DecompressPointer r5
    //     0x719a4c: add             x5, x5, HEAP, lsl #32
    // 0x719a50: stur            x5, [fp, #-0x10]
    // 0x719a54: LoadField: r6 = r4->field_7
    //     0x719a54: ldur            w6, [x4, #7]
    // 0x719a58: DecompressPointer r6
    //     0x719a58: add             x6, x6, HEAP, lsl #32
    // 0x719a5c: stur            x6, [fp, #-8]
    // 0x719a60: stp             x2, x0, [SP, #-0x10]!
    // 0x719a64: r0 = getKindForPointer()
    //     0x719a64: bl              #0x719b14  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0x719a68: add             SP, SP, #0x10
    // 0x719a6c: stur            x0, [fp, #-0x20]
    // 0x719a70: r0 = DragStartDetails()
    //     0x719a70: bl              #0x719b08  ; AllocateDragStartDetailsStub -> DragStartDetails (size=0x18)
    // 0x719a74: mov             x1, x0
    // 0x719a78: ldr             x0, [fp, #0x18]
    // 0x719a7c: StoreField: r1->field_7 = r0
    //     0x719a7c: stur            w0, [x1, #7]
    // 0x719a80: ldur            x0, [fp, #-0x10]
    // 0x719a84: StoreField: r1->field_b = r0
    //     0x719a84: stur            w0, [x1, #0xb]
    // 0x719a88: ldur            x0, [fp, #-0x20]
    // 0x719a8c: StoreField: r1->field_13 = r0
    //     0x719a8c: stur            w0, [x1, #0x13]
    // 0x719a90: ldur            x0, [fp, #-8]
    // 0x719a94: StoreField: r1->field_f = r0
    //     0x719a94: stur            w0, [x1, #0xf]
    // 0x719a98: mov             x0, x1
    // 0x719a9c: ldur            x2, [fp, #-0x18]
    // 0x719aa0: StoreField: r2->field_13 = r0
    //     0x719aa0: stur            w0, [x2, #0x13]
    //     0x719aa4: ldurb           w16, [x2, #-1]
    //     0x719aa8: ldurb           w17, [x0, #-1]
    //     0x719aac: and             x16, x17, x16, lsr #2
    //     0x719ab0: tst             x16, HEAP, lsr #32
    //     0x719ab4: b.eq            #0x719abc
    //     0x719ab8: bl              #0xd6828c
    // 0x719abc: r1 = Function '<anonymous closure>':.
    //     0x719abc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f40] AnonymousClosure: (0x71997c), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkStart (0x7199ec)
    //     0x719ac0: ldr             x1, [x1, #0xf40]
    // 0x719ac4: r0 = AllocateClosure()
    //     0x719ac4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x719ac8: r16 = <void?>
    //     0x719ac8: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x719acc: ldr             lr, [fp, #0x20]
    // 0x719ad0: stp             lr, x16, [SP, #-0x10]!
    // 0x719ad4: SaveReg r0
    //     0x719ad4: str             x0, [SP, #-8]!
    // 0x719ad8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x719ad8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x719adc: r0 = invokeCallback()
    //     0x719adc: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x719ae0: add             SP, SP, #0x18
    // 0x719ae4: r0 = Null
    //     0x719ae4: mov             x0, NULL
    // 0x719ae8: LeaveFrame
    //     0x719ae8: mov             SP, fp
    //     0x719aec: ldp             fp, lr, [SP], #0x10
    // 0x719af0: ret
    //     0x719af0: ret             
    // 0x719af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x719af4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x719af8: b               #0x719a04
    // 0x719afc: r9 = _initialPosition
    //     0x719afc: add             x9, PP, #0x28, lsl #12  ; [pp+0x28f20] Field <DragGestureRecognizer._initialPosition@666099969>: late (offset: 0x4c)
    //     0x719b00: ldr             x9, [x9, #0xf20]
    // 0x719b04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x719b04: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointerPanZoom(/* No info */) {
    // ** addr: 0x719b98, size: 0xc8
    // 0x719b98: EnterFrame
    //     0x719b98: stp             fp, lr, [SP, #-0x10]!
    //     0x719b9c: mov             fp, SP
    // 0x719ba0: AllocStack(0x8)
    //     0x719ba0: sub             SP, SP, #8
    // 0x719ba4: CheckStackOverflow
    //     0x719ba4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x719ba8: cmp             SP, x16
    //     0x719bac: b.ls            #0x719c58
    // 0x719bb0: ldr             x1, [fp, #0x10]
    // 0x719bb4: r0 = LoadClassIdInstr(r1)
    //     0x719bb4: ldur            x0, [x1, #-1]
    //     0x719bb8: ubfx            x0, x0, #0xc, #0x14
    // 0x719bbc: SaveReg r1
    //     0x719bbc: str             x1, [SP, #-8]!
    // 0x719bc0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x719bc0: sub             lr, x0, #0xfff
    //     0x719bc4: ldr             lr, [x21, lr, lsl #3]
    //     0x719bc8: blr             lr
    // 0x719bcc: add             SP, SP, #8
    // 0x719bd0: mov             x2, x0
    // 0x719bd4: ldr             x1, [fp, #0x10]
    // 0x719bd8: stur            x2, [fp, #-8]
    // 0x719bdc: r0 = LoadClassIdInstr(r1)
    //     0x719bdc: ldur            x0, [x1, #-1]
    //     0x719be0: ubfx            x0, x0, #0xc, #0x14
    // 0x719be4: SaveReg r1
    //     0x719be4: str             x1, [SP, #-8]!
    // 0x719be8: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x719be8: mov             x17, #0x3f6e
    //     0x719bec: add             lr, x0, x17
    //     0x719bf0: ldr             lr, [x21, lr, lsl #3]
    //     0x719bf4: blr             lr
    // 0x719bf8: add             SP, SP, #8
    // 0x719bfc: ldr             x16, [fp, #0x18]
    // 0x719c00: SaveReg r16
    //     0x719c00: str             x16, [SP, #-8]!
    // 0x719c04: ldur            x1, [fp, #-8]
    // 0x719c08: stp             x0, x1, [SP, #-0x10]!
    // 0x719c0c: r0 = startTrackingPointer()
    //     0x719c0c: bl              #0x71111c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::startTrackingPointer
    // 0x719c10: add             SP, SP, #0x18
    // 0x719c14: ldr             x0, [fp, #0x18]
    // 0x719c18: LoadField: r1 = r0->field_47
    //     0x719c18: ldur            w1, [x0, #0x47]
    // 0x719c1c: DecompressPointer r1
    //     0x719c1c: add             x1, x1, HEAP, lsl #32
    // 0x719c20: r16 = Instance__DragState
    //     0x719c20: add             x16, PP, #0x21, lsl #12  ; [pp+0x214d8] Obj!_DragState@b65b31
    //     0x719c24: ldr             x16, [x16, #0x4d8]
    // 0x719c28: cmp             w1, w16
    // 0x719c2c: b.ne            #0x719c38
    // 0x719c30: r1 = 2
    //     0x719c30: mov             x1, #2
    // 0x719c34: StoreField: r0->field_57 = r1
    //     0x719c34: stur            w1, [x0, #0x57]
    // 0x719c38: ldr             x16, [fp, #0x10]
    // 0x719c3c: stp             x16, x0, [SP, #-0x10]!
    // 0x719c40: r0 = _addPointer()
    //     0x719c40: bl              #0x719c60  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_addPointer
    // 0x719c44: add             SP, SP, #0x10
    // 0x719c48: r0 = Null
    //     0x719c48: mov             x0, NULL
    // 0x719c4c: LeaveFrame
    //     0x719c4c: mov             SP, fp
    //     0x719c50: ldp             fp, lr, [SP], #0x10
    // 0x719c54: ret
    //     0x719c54: ret             
    // 0x719c58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x719c58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x719c5c: b               #0x719bb0
  }
  _ _addPointer(/* No info */) {
    // ** addr: 0x719c60, size: 0x240
    // 0x719c60: EnterFrame
    //     0x719c60: stp             fp, lr, [SP, #-0x10]!
    //     0x719c64: mov             fp, SP
    // 0x719c68: AllocStack(0x18)
    //     0x719c68: sub             SP, SP, #0x18
    // 0x719c6c: CheckStackOverflow
    //     0x719c6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x719c70: cmp             SP, x16
    //     0x719c74: b.ls            #0x719e98
    // 0x719c78: ldr             x1, [fp, #0x18]
    // 0x719c7c: LoadField: r2 = r1->field_63
    //     0x719c7c: ldur            w2, [x1, #0x63]
    // 0x719c80: DecompressPointer r2
    //     0x719c80: add             x2, x2, HEAP, lsl #32
    // 0x719c84: ldr             x3, [fp, #0x10]
    // 0x719c88: stur            x2, [fp, #-8]
    // 0x719c8c: r0 = LoadClassIdInstr(r3)
    //     0x719c8c: ldur            x0, [x3, #-1]
    //     0x719c90: ubfx            x0, x0, #0xc, #0x14
    // 0x719c94: SaveReg r3
    //     0x719c94: str             x3, [SP, #-8]!
    // 0x719c98: r0 = GDT[cid_x0 + -0xfff]()
    //     0x719c98: sub             lr, x0, #0xfff
    //     0x719c9c: ldr             lr, [x21, lr, lsl #3]
    //     0x719ca0: blr             lr
    // 0x719ca4: add             SP, SP, #8
    // 0x719ca8: mov             x2, x0
    // 0x719cac: ldr             x1, [fp, #0x18]
    // 0x719cb0: stur            x2, [fp, #-0x10]
    // 0x719cb4: LoadField: r0 = r1->field_43
    //     0x719cb4: ldur            w0, [x1, #0x43]
    // 0x719cb8: DecompressPointer r0
    //     0x719cb8: add             x0, x0, HEAP, lsl #32
    // 0x719cbc: ldr             x16, [fp, #0x10]
    // 0x719cc0: stp             x16, x0, [SP, #-0x10]!
    // 0x719cc4: ClosureCall
    //     0x719cc4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x719cc8: ldur            x2, [x0, #0x1f]
    //     0x719ccc: blr             x2
    // 0x719cd0: add             SP, SP, #0x10
    // 0x719cd4: mov             x3, x0
    // 0x719cd8: ldur            x2, [fp, #-0x10]
    // 0x719cdc: r0 = BoxInt64Instr(r2)
    //     0x719cdc: sbfiz           x0, x2, #1, #0x1f
    //     0x719ce0: cmp             x2, x0, asr #1
    //     0x719ce4: b.eq            #0x719cf0
    //     0x719ce8: bl              #0xd69bb8
    //     0x719cec: stur            x2, [x0, #7]
    // 0x719cf0: ldur            x16, [fp, #-8]
    // 0x719cf4: stp             x0, x16, [SP, #-0x10]!
    // 0x719cf8: SaveReg r3
    //     0x719cf8: str             x3, [SP, #-8]!
    // 0x719cfc: r0 = []=()
    //     0x719cfc: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x719d00: add             SP, SP, #0x18
    // 0x719d04: ldr             x1, [fp, #0x18]
    // 0x719d08: LoadField: r0 = r1->field_47
    //     0x719d08: ldur            w0, [x1, #0x47]
    // 0x719d0c: DecompressPointer r0
    //     0x719d0c: add             x0, x0, HEAP, lsl #32
    // 0x719d10: r16 = Instance__DragState
    //     0x719d10: add             x16, PP, #0x21, lsl #12  ; [pp+0x214d8] Obj!_DragState@b65b31
    //     0x719d14: ldr             x16, [x16, #0x4d8]
    // 0x719d18: cmp             w0, w16
    // 0x719d1c: b.ne            #0x719e64
    // 0x719d20: ldr             x2, [fp, #0x10]
    // 0x719d24: r0 = Instance__DragState
    //     0x719d24: add             x0, PP, #0x28, lsl #12  ; [pp+0x28f48] Obj!_DragState@b65b51
    //     0x719d28: ldr             x0, [x0, #0xf48]
    // 0x719d2c: StoreField: r1->field_47 = r0
    //     0x719d2c: stur            w0, [x1, #0x47]
    // 0x719d30: r0 = LoadClassIdInstr(r2)
    //     0x719d30: ldur            x0, [x2, #-1]
    //     0x719d34: ubfx            x0, x0, #0xc, #0x14
    // 0x719d38: SaveReg r2
    //     0x719d38: str             x2, [SP, #-8]!
    // 0x719d3c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x719d3c: sub             lr, x0, #0xfd9
    //     0x719d40: ldr             lr, [x21, lr, lsl #3]
    //     0x719d44: blr             lr
    // 0x719d48: add             SP, SP, #8
    // 0x719d4c: mov             x2, x0
    // 0x719d50: ldr             x1, [fp, #0x10]
    // 0x719d54: stur            x2, [fp, #-8]
    // 0x719d58: r0 = LoadClassIdInstr(r1)
    //     0x719d58: ldur            x0, [x1, #-1]
    //     0x719d5c: ubfx            x0, x0, #0xc, #0x14
    // 0x719d60: SaveReg r1
    //     0x719d60: str             x1, [SP, #-8]!
    // 0x719d64: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x719d64: mov             x17, #0x57c0
    //     0x719d68: add             lr, x0, x17
    //     0x719d6c: ldr             lr, [x21, lr, lsl #3]
    //     0x719d70: blr             lr
    // 0x719d74: add             SP, SP, #8
    // 0x719d78: stur            x0, [fp, #-0x18]
    // 0x719d7c: r0 = OffsetPair()
    //     0x719d7c: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x719d80: mov             x1, x0
    // 0x719d84: ldur            x0, [fp, #-0x18]
    // 0x719d88: StoreField: r1->field_7 = r0
    //     0x719d88: stur            w0, [x1, #7]
    // 0x719d8c: ldur            x0, [fp, #-8]
    // 0x719d90: StoreField: r1->field_b = r0
    //     0x719d90: stur            w0, [x1, #0xb]
    // 0x719d94: mov             x0, x1
    // 0x719d98: ldr             x1, [fp, #0x18]
    // 0x719d9c: StoreField: r1->field_4b = r0
    //     0x719d9c: stur            w0, [x1, #0x4b]
    //     0x719da0: ldurb           w16, [x1, #-1]
    //     0x719da4: ldurb           w17, [x0, #-1]
    //     0x719da8: and             x16, x17, x16, lsr #2
    //     0x719dac: tst             x16, HEAP, lsr #32
    //     0x719db0: b.eq            #0x719db8
    //     0x719db4: bl              #0xd6826c
    // 0x719db8: r0 = Instance_OffsetPair
    //     0x719db8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28f10] Obj!OffsetPair@b38711
    //     0x719dbc: ldr             x0, [x0, #0xf10]
    // 0x719dc0: StoreField: r1->field_4f = r0
    //     0x719dc0: stur            w0, [x1, #0x4f]
    // 0x719dc4: r0 = 0.000000
    //     0x719dc4: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x719dc8: StoreField: r1->field_5f = r0
    //     0x719dc8: stur            w0, [x1, #0x5f]
    // 0x719dcc: ldr             x2, [fp, #0x10]
    // 0x719dd0: r0 = LoadClassIdInstr(r2)
    //     0x719dd0: ldur            x0, [x2, #-1]
    //     0x719dd4: ubfx            x0, x0, #0xc, #0x14
    // 0x719dd8: SaveReg r2
    //     0x719dd8: str             x2, [SP, #-8]!
    // 0x719ddc: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x719ddc: sub             lr, x0, #0xf3a
    //     0x719de0: ldr             lr, [x21, lr, lsl #3]
    //     0x719de4: blr             lr
    // 0x719de8: add             SP, SP, #8
    // 0x719dec: ldr             x1, [fp, #0x18]
    // 0x719df0: StoreField: r1->field_53 = r0
    //     0x719df0: stur            w0, [x1, #0x53]
    //     0x719df4: ldurb           w16, [x1, #-1]
    //     0x719df8: ldurb           w17, [x0, #-1]
    //     0x719dfc: and             x16, x17, x16, lsr #2
    //     0x719e00: tst             x16, HEAP, lsr #32
    //     0x719e04: b.eq            #0x719e0c
    //     0x719e08: bl              #0xd6826c
    // 0x719e0c: ldr             x0, [fp, #0x10]
    // 0x719e10: r2 = LoadClassIdInstr(r0)
    //     0x719e10: ldur            x2, [x0, #-1]
    //     0x719e14: ubfx            x2, x2, #0xc, #0x14
    // 0x719e18: SaveReg r0
    //     0x719e18: str             x0, [SP, #-8]!
    // 0x719e1c: mov             x0, x2
    // 0x719e20: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x719e20: mov             x17, #0x3f6e
    //     0x719e24: add             lr, x0, x17
    //     0x719e28: ldr             lr, [x21, lr, lsl #3]
    //     0x719e2c: blr             lr
    // 0x719e30: add             SP, SP, #8
    // 0x719e34: ldr             x1, [fp, #0x18]
    // 0x719e38: StoreField: r1->field_5b = r0
    //     0x719e38: stur            w0, [x1, #0x5b]
    //     0x719e3c: ldurb           w16, [x1, #-1]
    //     0x719e40: ldurb           w17, [x0, #-1]
    //     0x719e44: and             x16, x17, x16, lsr #2
    //     0x719e48: tst             x16, HEAP, lsr #32
    //     0x719e4c: b.eq            #0x719e54
    //     0x719e50: bl              #0xd6826c
    // 0x719e54: SaveReg r1
    //     0x719e54: str             x1, [SP, #-8]!
    // 0x719e58: r0 = _checkDown()
    //     0x719e58: bl              #0x719ea0  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkDown
    // 0x719e5c: add             SP, SP, #8
    // 0x719e60: b               #0x719e88
    // 0x719e64: r16 = Instance__DragState
    //     0x719e64: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f08] Obj!_DragState@b65b71
    //     0x719e68: ldr             x16, [x16, #0xf08]
    // 0x719e6c: cmp             w0, w16
    // 0x719e70: b.ne            #0x719e88
    // 0x719e74: r16 = Instance_GestureDisposition
    //     0x719e74: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x719e78: ldr             x16, [x16, #0xed0]
    // 0x719e7c: stp             x16, x1, [SP, #-0x10]!
    // 0x719e80: r0 = resolve()
    //     0x719e80: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x719e84: add             SP, SP, #0x10
    // 0x719e88: r0 = Null
    //     0x719e88: mov             x0, NULL
    // 0x719e8c: LeaveFrame
    //     0x719e8c: mov             SP, fp
    //     0x719e90: ldp             fp, lr, [SP], #0x10
    // 0x719e94: ret
    //     0x719e94: ret             
    // 0x719e98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x719e98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x719e9c: b               #0x719c78
  }
  _ _checkDown(/* No info */) {
    // ** addr: 0x719ea0, size: 0xc4
    // 0x719ea0: EnterFrame
    //     0x719ea0: stp             fp, lr, [SP, #-0x10]!
    //     0x719ea4: mov             fp, SP
    // 0x719ea8: AllocStack(0x10)
    //     0x719ea8: sub             SP, SP, #0x10
    // 0x719eac: CheckStackOverflow
    //     0x719eac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x719eb0: cmp             SP, x16
    //     0x719eb4: b.ls            #0x719f50
    // 0x719eb8: r1 = 2
    //     0x719eb8: mov             x1, #2
    // 0x719ebc: r0 = AllocateContext()
    //     0x719ebc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x719ec0: mov             x1, x0
    // 0x719ec4: ldr             x0, [fp, #0x10]
    // 0x719ec8: stur            x1, [fp, #-0x10]
    // 0x719ecc: StoreField: r1->field_f = r0
    //     0x719ecc: stur            w0, [x1, #0xf]
    // 0x719ed0: LoadField: r2 = r0->field_23
    //     0x719ed0: ldur            w2, [x0, #0x23]
    // 0x719ed4: DecompressPointer r2
    //     0x719ed4: add             x2, x2, HEAP, lsl #32
    // 0x719ed8: cmp             w2, NULL
    // 0x719edc: b.eq            #0x719f40
    // 0x719ee0: LoadField: r2 = r0->field_4b
    //     0x719ee0: ldur            w2, [x0, #0x4b]
    // 0x719ee4: DecompressPointer r2
    //     0x719ee4: add             x2, x2, HEAP, lsl #32
    // 0x719ee8: r16 = Sentinel
    //     0x719ee8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x719eec: cmp             w2, w16
    // 0x719ef0: b.eq            #0x719f58
    // 0x719ef4: LoadField: r3 = r2->field_b
    //     0x719ef4: ldur            w3, [x2, #0xb]
    // 0x719ef8: DecompressPointer r3
    //     0x719ef8: add             x3, x3, HEAP, lsl #32
    // 0x719efc: stur            x3, [fp, #-8]
    // 0x719f00: r0 = DragDownDetails()
    //     0x719f00: bl              #0x719970  ; AllocateDragDownDetailsStub -> DragDownDetails (size=0xc)
    // 0x719f04: mov             x1, x0
    // 0x719f08: ldur            x0, [fp, #-8]
    // 0x719f0c: StoreField: r1->field_7 = r0
    //     0x719f0c: stur            w0, [x1, #7]
    // 0x719f10: ldur            x2, [fp, #-0x10]
    // 0x719f14: StoreField: r2->field_13 = r1
    //     0x719f14: stur            w1, [x2, #0x13]
    // 0x719f18: r1 = Function '<anonymous closure>':.
    //     0x719f18: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f50] AnonymousClosure: (0x719f64), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkDown (0x719ea0)
    //     0x719f1c: ldr             x1, [x1, #0xf50]
    // 0x719f20: r0 = AllocateClosure()
    //     0x719f20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x719f24: r16 = <void?>
    //     0x719f24: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x719f28: ldr             lr, [fp, #0x10]
    // 0x719f2c: stp             lr, x16, [SP, #-0x10]!
    // 0x719f30: SaveReg r0
    //     0x719f30: str             x0, [SP, #-8]!
    // 0x719f34: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x719f34: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x719f38: r0 = invokeCallback()
    //     0x719f38: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x719f3c: add             SP, SP, #0x18
    // 0x719f40: r0 = Null
    //     0x719f40: mov             x0, NULL
    // 0x719f44: LeaveFrame
    //     0x719f44: mov             SP, fp
    //     0x719f48: ldp             fp, lr, [SP], #0x10
    // 0x719f4c: ret
    //     0x719f4c: ret             
    // 0x719f50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x719f50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x719f54: b               #0x719eb8
    // 0x719f58: r9 = _initialPosition
    //     0x719f58: add             x9, PP, #0x28, lsl #12  ; [pp+0x28f20] Field <DragGestureRecognizer._initialPosition@666099969>: late (offset: 0x4c)
    //     0x719f5c: ldr             x9, [x9, #0xf20]
    // 0x719f60: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x719f60: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x719f64, size: 0x70
    // 0x719f64: EnterFrame
    //     0x719f64: stp             fp, lr, [SP, #-0x10]!
    //     0x719f68: mov             fp, SP
    // 0x719f6c: ldr             x0, [fp, #0x10]
    // 0x719f70: LoadField: r1 = r0->field_17
    //     0x719f70: ldur            w1, [x0, #0x17]
    // 0x719f74: DecompressPointer r1
    //     0x719f74: add             x1, x1, HEAP, lsl #32
    // 0x719f78: CheckStackOverflow
    //     0x719f78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x719f7c: cmp             SP, x16
    //     0x719f80: b.ls            #0x719fc8
    // 0x719f84: LoadField: r0 = r1->field_f
    //     0x719f84: ldur            w0, [x1, #0xf]
    // 0x719f88: DecompressPointer r0
    //     0x719f88: add             x0, x0, HEAP, lsl #32
    // 0x719f8c: LoadField: r2 = r0->field_23
    //     0x719f8c: ldur            w2, [x0, #0x23]
    // 0x719f90: DecompressPointer r2
    //     0x719f90: add             x2, x2, HEAP, lsl #32
    // 0x719f94: cmp             w2, NULL
    // 0x719f98: b.eq            #0x719fd0
    // 0x719f9c: LoadField: r0 = r1->field_13
    //     0x719f9c: ldur            w0, [x1, #0x13]
    // 0x719fa0: DecompressPointer r0
    //     0x719fa0: add             x0, x0, HEAP, lsl #32
    // 0x719fa4: stp             x0, x2, [SP, #-0x10]!
    // 0x719fa8: mov             x0, x2
    // 0x719fac: ClosureCall
    //     0x719fac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x719fb0: ldur            x2, [x0, #0x1f]
    //     0x719fb4: blr             x2
    // 0x719fb8: add             SP, SP, #0x10
    // 0x719fbc: LeaveFrame
    //     0x719fbc: mov             SP, fp
    //     0x719fc0: ldp             fp, lr, [SP], #0x10
    // 0x719fc4: ret
    //     0x719fc4: ret             
    // 0x719fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x719fc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x719fcc: b               #0x719f84
    // 0x719fd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x719fd0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x782ea4, size: 0xcc
    // 0x782ea4: EnterFrame
    //     0x782ea4: stp             fp, lr, [SP, #-0x10]!
    //     0x782ea8: mov             fp, SP
    // 0x782eac: CheckStackOverflow
    //     0x782eac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782eb0: cmp             SP, x16
    //     0x782eb4: b.ls            #0x782f68
    // 0x782eb8: ldr             x16, [fp, #0x18]
    // 0x782ebc: ldr             lr, [fp, #0x10]
    // 0x782ec0: stp             lr, x16, [SP, #-0x10]!
    // 0x782ec4: r0 = addAllowedPointer()
    //     0x782ec4: bl              #0x782114  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0x782ec8: add             SP, SP, #0x10
    // 0x782ecc: ldr             x1, [fp, #0x18]
    // 0x782ed0: LoadField: r0 = r1->field_47
    //     0x782ed0: ldur            w0, [x1, #0x47]
    // 0x782ed4: DecompressPointer r0
    //     0x782ed4: add             x0, x0, HEAP, lsl #32
    // 0x782ed8: r16 = Instance__DragState
    //     0x782ed8: add             x16, PP, #0x21, lsl #12  ; [pp+0x214d8] Obj!_DragState@b65b31
    //     0x782edc: ldr             x16, [x16, #0x4d8]
    // 0x782ee0: cmp             w0, w16
    // 0x782ee4: b.ne            #0x782f48
    // 0x782ee8: ldr             x2, [fp, #0x10]
    // 0x782eec: r0 = LoadClassIdInstr(r2)
    //     0x782eec: ldur            x0, [x2, #-1]
    //     0x782ef0: ubfx            x0, x0, #0xc, #0x14
    // 0x782ef4: SaveReg r2
    //     0x782ef4: str             x2, [SP, #-8]!
    // 0x782ef8: r0 = GDT[cid_x0 + 0x271c]()
    //     0x782ef8: mov             x17, #0x271c
    //     0x782efc: add             lr, x0, x17
    //     0x782f00: ldr             lr, [x21, lr, lsl #3]
    //     0x782f04: blr             lr
    // 0x782f08: add             SP, SP, #8
    // 0x782f0c: mov             x2, x0
    // 0x782f10: r0 = BoxInt64Instr(r2)
    //     0x782f10: sbfiz           x0, x2, #1, #0x1f
    //     0x782f14: cmp             x2, x0, asr #1
    //     0x782f18: b.eq            #0x782f24
    //     0x782f1c: bl              #0xd69bb8
    //     0x782f20: stur            x2, [x0, #7]
    // 0x782f24: ldr             x1, [fp, #0x18]
    // 0x782f28: StoreField: r1->field_57 = r0
    //     0x782f28: stur            w0, [x1, #0x57]
    //     0x782f2c: tbz             w0, #0, #0x782f48
    //     0x782f30: ldurb           w16, [x1, #-1]
    //     0x782f34: ldurb           w17, [x0, #-1]
    //     0x782f38: and             x16, x17, x16, lsr #2
    //     0x782f3c: tst             x16, HEAP, lsr #32
    //     0x782f40: b.eq            #0x782f48
    //     0x782f44: bl              #0xd6826c
    // 0x782f48: ldr             x16, [fp, #0x10]
    // 0x782f4c: stp             x16, x1, [SP, #-0x10]!
    // 0x782f50: r0 = _addPointer()
    //     0x782f50: bl              #0x719c60  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_addPointer
    // 0x782f54: add             SP, SP, #0x10
    // 0x782f58: r0 = Null
    //     0x782f58: mov             x0, NULL
    // 0x782f5c: LeaveFrame
    //     0x782f5c: mov             SP, fp
    //     0x782f60: ldp             fp, lr, [SP], #0x10
    // 0x782f64: ret
    //     0x782f64: ret             
    // 0x782f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782f68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782f6c: b               #0x782eb8
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0x789798, size: 0x18
    // 0x789798: r4 = 0
    //     0x789798: mov             x4, #0
    // 0x78979c: r1 = Function 'handleEvent':.
    //     0x78979c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e8b8] AnonymousClosure: (0x7897b0), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::handleEvent (0x7897fc)
    //     0x7897a0: ldr             x1, [x17, #0x8b8]
    // 0x7897a4: r24 = BuildNonGenericMethodExtractorStub
    //     0x7897a4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x7897a8: LoadField: r0 = r24->field_17
    //     0x7897a8: ldur            x0, [x24, #0x17]
    // 0x7897ac: br              x0
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0x7897b0, size: 0x4c
    // 0x7897b0: EnterFrame
    //     0x7897b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7897b4: mov             fp, SP
    // 0x7897b8: ldr             x0, [fp, #0x18]
    // 0x7897bc: LoadField: r1 = r0->field_17
    //     0x7897bc: ldur            w1, [x0, #0x17]
    // 0x7897c0: DecompressPointer r1
    //     0x7897c0: add             x1, x1, HEAP, lsl #32
    // 0x7897c4: CheckStackOverflow
    //     0x7897c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7897c8: cmp             SP, x16
    //     0x7897cc: b.ls            #0x7897f4
    // 0x7897d0: LoadField: r0 = r1->field_f
    //     0x7897d0: ldur            w0, [x1, #0xf]
    // 0x7897d4: DecompressPointer r0
    //     0x7897d4: add             x0, x0, HEAP, lsl #32
    // 0x7897d8: ldr             x16, [fp, #0x10]
    // 0x7897dc: stp             x16, x0, [SP, #-0x10]!
    // 0x7897e0: r0 = handleEvent()
    //     0x7897e0: bl              #0x7897fc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::handleEvent
    // 0x7897e4: add             SP, SP, #0x10
    // 0x7897e8: LeaveFrame
    //     0x7897e8: mov             SP, fp
    //     0x7897ec: ldp             fp, lr, [SP], #0x10
    // 0x7897f0: ret
    //     0x7897f0: ret             
    // 0x7897f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7897f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7897f8: b               #0x7897d0
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x7897fc, size: 0x1180
    // 0x7897fc: EnterFrame
    //     0x7897fc: stp             fp, lr, [SP, #-0x10]!
    //     0x789800: mov             fp, SP
    // 0x789804: AllocStack(0x38)
    //     0x789804: sub             SP, SP, #0x38
    // 0x789808: CheckStackOverflow
    //     0x789808: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78980c: cmp             SP, x16
    //     0x789810: b.ls            #0x78a8d0
    // 0x789814: ldr             x1, [fp, #0x10]
    // 0x789818: r0 = LoadClassIdInstr(r1)
    //     0x789818: ldur            x0, [x1, #-1]
    //     0x78981c: ubfx            x0, x0, #0xc, #0x14
    // 0x789820: SaveReg r1
    //     0x789820: str             x1, [SP, #-8]!
    // 0x789824: r0 = GDT[cid_x0 + 0x7012]()
    //     0x789824: mov             x17, #0x7012
    //     0x789828: add             lr, x0, x17
    //     0x78982c: ldr             lr, [x21, lr, lsl #3]
    //     0x789830: blr             lr
    // 0x789834: add             SP, SP, #8
    // 0x789838: tbz             w0, #4, #0x789b98
    // 0x78983c: ldr             x0, [fp, #0x10]
    // 0x789840: r2 = Null
    //     0x789840: mov             x2, NULL
    // 0x789844: r1 = Null
    //     0x789844: mov             x1, NULL
    // 0x789848: cmp             w0, NULL
    // 0x78984c: b.eq            #0x78986c
    // 0x789850: branchIfSmi(r0, 0x78986c)
    //     0x789850: tbz             w0, #0, #0x78986c
    // 0x789854: r3 = LoadClassIdInstr(r0)
    //     0x789854: ldur            x3, [x0, #-1]
    //     0x789858: ubfx            x3, x3, #0xc, #0x14
    // 0x78985c: cmp             x3, #0x90a
    // 0x789860: b.eq            #0x789874
    // 0x789864: cmp             x3, #0xb41
    // 0x789868: b.eq            #0x789874
    // 0x78986c: r0 = false
    //     0x78986c: add             x0, NULL, #0x30  ; false
    // 0x789870: b               #0x789878
    // 0x789874: r0 = true
    //     0x789874: add             x0, NULL, #0x20  ; true
    // 0x789878: tbz             w0, #4, #0x78993c
    // 0x78987c: ldr             x0, [fp, #0x10]
    // 0x789880: r2 = Null
    //     0x789880: mov             x2, NULL
    // 0x789884: r1 = Null
    //     0x789884: mov             x1, NULL
    // 0x789888: cmp             w0, NULL
    // 0x78988c: b.eq            #0x7898ac
    // 0x789890: branchIfSmi(r0, 0x7898ac)
    //     0x789890: tbz             w0, #0, #0x7898ac
    // 0x789894: r3 = LoadClassIdInstr(r0)
    //     0x789894: ldur            x3, [x0, #-1]
    //     0x789898: ubfx            x3, x3, #0xc, #0x14
    // 0x78989c: cmp             x3, #0x908
    // 0x7898a0: b.eq            #0x7898b4
    // 0x7898a4: cmp             x3, #0xb3f
    // 0x7898a8: b.eq            #0x7898b4
    // 0x7898ac: r0 = false
    //     0x7898ac: add             x0, NULL, #0x30  ; false
    // 0x7898b0: b               #0x7898b8
    // 0x7898b4: r0 = true
    //     0x7898b4: add             x0, NULL, #0x20  ; true
    // 0x7898b8: tbz             w0, #4, #0x78993c
    // 0x7898bc: ldr             x0, [fp, #0x10]
    // 0x7898c0: r2 = Null
    //     0x7898c0: mov             x2, NULL
    // 0x7898c4: r1 = Null
    //     0x7898c4: mov             x1, NULL
    // 0x7898c8: cmp             w0, NULL
    // 0x7898cc: b.eq            #0x7898ec
    // 0x7898d0: branchIfSmi(r0, 0x7898ec)
    //     0x7898d0: tbz             w0, #0, #0x7898ec
    // 0x7898d4: r3 = LoadClassIdInstr(r0)
    //     0x7898d4: ldur            x3, [x0, #-1]
    //     0x7898d8: ubfx            x3, x3, #0xc, #0x14
    // 0x7898dc: cmp             x3, #0x8fe
    // 0x7898e0: b.eq            #0x7898f4
    // 0x7898e4: cmp             x3, #0xb3b
    // 0x7898e8: b.eq            #0x7898f4
    // 0x7898ec: r0 = false
    //     0x7898ec: add             x0, NULL, #0x30  ; false
    // 0x7898f0: b               #0x7898f8
    // 0x7898f4: r0 = true
    //     0x7898f4: add             x0, NULL, #0x20  ; true
    // 0x7898f8: tbz             w0, #4, #0x78993c
    // 0x7898fc: ldr             x0, [fp, #0x10]
    // 0x789900: r2 = Null
    //     0x789900: mov             x2, NULL
    // 0x789904: r1 = Null
    //     0x789904: mov             x1, NULL
    // 0x789908: cmp             w0, NULL
    // 0x78990c: b.eq            #0x78992c
    // 0x789910: branchIfSmi(r0, 0x78992c)
    //     0x789910: tbz             w0, #0, #0x78992c
    // 0x789914: r3 = LoadClassIdInstr(r0)
    //     0x789914: ldur            x3, [x0, #-1]
    //     0x789918: ubfx            x3, x3, #0xc, #0x14
    // 0x78991c: cmp             x3, #0x8fc
    // 0x789920: b.eq            #0x789934
    // 0x789924: cmp             x3, #0xb39
    // 0x789928: b.eq            #0x789934
    // 0x78992c: r0 = false
    //     0x78992c: add             x0, NULL, #0x30  ; false
    // 0x789930: b               #0x789938
    // 0x789934: r0 = true
    //     0x789934: add             x0, NULL, #0x20  ; true
    // 0x789938: tbnz            w0, #4, #0x789b98
    // 0x78993c: ldr             x2, [fp, #0x18]
    // 0x789940: ldr             x1, [fp, #0x10]
    // 0x789944: LoadField: r3 = r2->field_63
    //     0x789944: ldur            w3, [x2, #0x63]
    // 0x789948: DecompressPointer r3
    //     0x789948: add             x3, x3, HEAP, lsl #32
    // 0x78994c: stur            x3, [fp, #-8]
    // 0x789950: r0 = LoadClassIdInstr(r1)
    //     0x789950: ldur            x0, [x1, #-1]
    //     0x789954: ubfx            x0, x0, #0xc, #0x14
    // 0x789958: SaveReg r1
    //     0x789958: str             x1, [SP, #-8]!
    // 0x78995c: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78995c: sub             lr, x0, #0xfff
    //     0x789960: ldr             lr, [x21, lr, lsl #3]
    //     0x789964: blr             lr
    // 0x789968: add             SP, SP, #8
    // 0x78996c: mov             x2, x0
    // 0x789970: r0 = BoxInt64Instr(r2)
    //     0x789970: sbfiz           x0, x2, #1, #0x1f
    //     0x789974: cmp             x2, x0, asr #1
    //     0x789978: b.eq            #0x789984
    //     0x78997c: bl              #0xd69bb8
    //     0x789980: stur            x2, [x0, #7]
    // 0x789984: ldur            x16, [fp, #-8]
    // 0x789988: stp             x0, x16, [SP, #-0x10]!
    // 0x78998c: r0 = _getValueOrData()
    //     0x78998c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x789990: add             SP, SP, #0x10
    // 0x789994: mov             x1, x0
    // 0x789998: ldur            x0, [fp, #-8]
    // 0x78999c: LoadField: r2 = r0->field_f
    //     0x78999c: ldur            w2, [x0, #0xf]
    // 0x7899a0: DecompressPointer r2
    //     0x7899a0: add             x2, x2, HEAP, lsl #32
    // 0x7899a4: cmp             w2, w1
    // 0x7899a8: b.ne            #0x7899b4
    // 0x7899ac: r3 = Null
    //     0x7899ac: mov             x3, NULL
    // 0x7899b0: b               #0x7899b8
    // 0x7899b4: mov             x3, x1
    // 0x7899b8: stur            x3, [fp, #-8]
    // 0x7899bc: cmp             w3, NULL
    // 0x7899c0: b.eq            #0x78a8d8
    // 0x7899c4: ldr             x0, [fp, #0x10]
    // 0x7899c8: r2 = Null
    //     0x7899c8: mov             x2, NULL
    // 0x7899cc: r1 = Null
    //     0x7899cc: mov             x1, NULL
    // 0x7899d0: cmp             w0, NULL
    // 0x7899d4: b.eq            #0x7899f4
    // 0x7899d8: branchIfSmi(r0, 0x7899f4)
    //     0x7899d8: tbz             w0, #0, #0x7899f4
    // 0x7899dc: r3 = LoadClassIdInstr(r0)
    //     0x7899dc: ldur            x3, [x0, #-1]
    //     0x7899e0: ubfx            x3, x3, #0xc, #0x14
    // 0x7899e4: cmp             x3, #0x8fe
    // 0x7899e8: b.eq            #0x7899fc
    // 0x7899ec: cmp             x3, #0xb3b
    // 0x7899f0: b.eq            #0x7899fc
    // 0x7899f4: r0 = false
    //     0x7899f4: add             x0, NULL, #0x30  ; false
    // 0x7899f8: b               #0x789a00
    // 0x7899fc: r0 = true
    //     0x7899fc: add             x0, NULL, #0x20  ; true
    // 0x789a00: tbnz            w0, #4, #0x789a58
    // 0x789a04: ldr             x2, [fp, #0x10]
    // 0x789a08: ldur            x1, [fp, #-8]
    // 0x789a0c: r0 = LoadClassIdInstr(r2)
    //     0x789a0c: ldur            x0, [x2, #-1]
    //     0x789a10: ubfx            x0, x0, #0xc, #0x14
    // 0x789a14: SaveReg r2
    //     0x789a14: str             x2, [SP, #-8]!
    // 0x789a18: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x789a18: sub             lr, x0, #0xf3a
    //     0x789a1c: ldr             lr, [x21, lr, lsl #3]
    //     0x789a20: blr             lr
    // 0x789a24: add             SP, SP, #8
    // 0x789a28: ldur            x3, [fp, #-8]
    // 0x789a2c: r1 = LoadClassIdInstr(r3)
    //     0x789a2c: ldur            x1, [x3, #-1]
    //     0x789a30: ubfx            x1, x1, #0xc, #0x14
    // 0x789a34: stp             x0, x3, [SP, #-0x10]!
    // 0x789a38: r16 = Instance_Offset
    //     0x789a38: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x789a3c: SaveReg r16
    //     0x789a3c: str             x16, [SP, #-8]!
    // 0x789a40: mov             x0, x1
    // 0x789a44: r0 = GDT[cid_x0 + -0xf82]()
    //     0x789a44: sub             lr, x0, #0xf82
    //     0x789a48: ldr             lr, [x21, lr, lsl #3]
    //     0x789a4c: blr             lr
    // 0x789a50: add             SP, SP, #0x18
    // 0x789a54: b               #0x789b98
    // 0x789a58: ldur            x3, [fp, #-8]
    // 0x789a5c: ldr             x0, [fp, #0x10]
    // 0x789a60: r2 = Null
    //     0x789a60: mov             x2, NULL
    // 0x789a64: r1 = Null
    //     0x789a64: mov             x1, NULL
    // 0x789a68: cmp             w0, NULL
    // 0x789a6c: b.eq            #0x789a8c
    // 0x789a70: branchIfSmi(r0, 0x789a8c)
    //     0x789a70: tbz             w0, #0, #0x789a8c
    // 0x789a74: r3 = LoadClassIdInstr(r0)
    //     0x789a74: ldur            x3, [x0, #-1]
    //     0x789a78: ubfx            x3, x3, #0xc, #0x14
    // 0x789a7c: cmp             x3, #0x8fc
    // 0x789a80: b.eq            #0x789a94
    // 0x789a84: cmp             x3, #0xb39
    // 0x789a88: b.eq            #0x789a94
    // 0x789a8c: r0 = false
    //     0x789a8c: add             x0, NULL, #0x30  ; false
    // 0x789a90: b               #0x789a98
    // 0x789a94: r0 = true
    //     0x789a94: add             x0, NULL, #0x20  ; true
    // 0x789a98: tbnz            w0, #4, #0x789b18
    // 0x789a9c: ldr             x2, [fp, #0x10]
    // 0x789aa0: ldur            x1, [fp, #-8]
    // 0x789aa4: r0 = LoadClassIdInstr(r2)
    //     0x789aa4: ldur            x0, [x2, #-1]
    //     0x789aa8: ubfx            x0, x0, #0xc, #0x14
    // 0x789aac: SaveReg r2
    //     0x789aac: str             x2, [SP, #-8]!
    // 0x789ab0: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x789ab0: sub             lr, x0, #0xf3a
    //     0x789ab4: ldr             lr, [x21, lr, lsl #3]
    //     0x789ab8: blr             lr
    // 0x789abc: add             SP, SP, #8
    // 0x789ac0: mov             x2, x0
    // 0x789ac4: ldr             x1, [fp, #0x10]
    // 0x789ac8: stur            x2, [fp, #-0x10]
    // 0x789acc: r0 = LoadClassIdInstr(r1)
    //     0x789acc: ldur            x0, [x1, #-1]
    //     0x789ad0: ubfx            x0, x0, #0xc, #0x14
    // 0x789ad4: SaveReg r1
    //     0x789ad4: str             x1, [SP, #-8]!
    // 0x789ad8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x789ad8: sub             lr, x0, #1, lsl #12
    //     0x789adc: ldr             lr, [x21, lr, lsl #3]
    //     0x789ae0: blr             lr
    // 0x789ae4: add             SP, SP, #8
    // 0x789ae8: ldur            x1, [fp, #-8]
    // 0x789aec: r2 = LoadClassIdInstr(r1)
    //     0x789aec: ldur            x2, [x1, #-1]
    //     0x789af0: ubfx            x2, x2, #0xc, #0x14
    // 0x789af4: ldur            x16, [fp, #-0x10]
    // 0x789af8: stp             x16, x1, [SP, #-0x10]!
    // 0x789afc: SaveReg r0
    //     0x789afc: str             x0, [SP, #-8]!
    // 0x789b00: mov             x0, x2
    // 0x789b04: r0 = GDT[cid_x0 + -0xf82]()
    //     0x789b04: sub             lr, x0, #0xf82
    //     0x789b08: ldr             lr, [x21, lr, lsl #3]
    //     0x789b0c: blr             lr
    // 0x789b10: add             SP, SP, #0x18
    // 0x789b14: b               #0x789b98
    // 0x789b18: ldr             x2, [fp, #0x10]
    // 0x789b1c: ldur            x1, [fp, #-8]
    // 0x789b20: r0 = LoadClassIdInstr(r2)
    //     0x789b20: ldur            x0, [x2, #-1]
    //     0x789b24: ubfx            x0, x0, #0xc, #0x14
    // 0x789b28: SaveReg r2
    //     0x789b28: str             x2, [SP, #-8]!
    // 0x789b2c: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x789b2c: sub             lr, x0, #0xf3a
    //     0x789b30: ldr             lr, [x21, lr, lsl #3]
    //     0x789b34: blr             lr
    // 0x789b38: add             SP, SP, #8
    // 0x789b3c: mov             x2, x0
    // 0x789b40: ldr             x1, [fp, #0x10]
    // 0x789b44: stur            x2, [fp, #-0x10]
    // 0x789b48: r0 = LoadClassIdInstr(r1)
    //     0x789b48: ldur            x0, [x1, #-1]
    //     0x789b4c: ubfx            x0, x0, #0xc, #0x14
    // 0x789b50: SaveReg r1
    //     0x789b50: str             x1, [SP, #-8]!
    // 0x789b54: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x789b54: mov             x17, #0x57c0
    //     0x789b58: add             lr, x0, x17
    //     0x789b5c: ldr             lr, [x21, lr, lsl #3]
    //     0x789b60: blr             lr
    // 0x789b64: add             SP, SP, #8
    // 0x789b68: mov             x1, x0
    // 0x789b6c: ldur            x0, [fp, #-8]
    // 0x789b70: r2 = LoadClassIdInstr(r0)
    //     0x789b70: ldur            x2, [x0, #-1]
    //     0x789b74: ubfx            x2, x2, #0xc, #0x14
    // 0x789b78: ldur            x16, [fp, #-0x10]
    // 0x789b7c: stp             x16, x0, [SP, #-0x10]!
    // 0x789b80: SaveReg r1
    //     0x789b80: str             x1, [SP, #-8]!
    // 0x789b84: mov             x0, x2
    // 0x789b88: r0 = GDT[cid_x0 + -0xf82]()
    //     0x789b88: sub             lr, x0, #0xf82
    //     0x789b8c: ldr             lr, [x21, lr, lsl #3]
    //     0x789b90: blr             lr
    // 0x789b94: add             SP, SP, #0x18
    // 0x789b98: ldr             x0, [fp, #0x10]
    // 0x789b9c: r2 = Null
    //     0x789b9c: mov             x2, NULL
    // 0x789ba0: r1 = Null
    //     0x789ba0: mov             x1, NULL
    // 0x789ba4: cmp             w0, NULL
    // 0x789ba8: b.eq            #0x789bc8
    // 0x789bac: branchIfSmi(r0, 0x789bc8)
    //     0x789bac: tbz             w0, #0, #0x789bc8
    // 0x789bb0: r3 = LoadClassIdInstr(r0)
    //     0x789bb0: ldur            x3, [x0, #-1]
    //     0x789bb4: ubfx            x3, x3, #0xc, #0x14
    // 0x789bb8: cmp             x3, #0x908
    // 0x789bbc: b.eq            #0x789bd0
    // 0x789bc0: cmp             x3, #0xb3f
    // 0x789bc4: b.eq            #0x789bd0
    // 0x789bc8: r0 = false
    //     0x789bc8: add             x0, NULL, #0x30  ; false
    // 0x789bcc: b               #0x789bd4
    // 0x789bd0: r0 = true
    //     0x789bd0: add             x0, NULL, #0x20  ; true
    // 0x789bd4: tbnz            w0, #4, #0x789cac
    // 0x789bd8: ldr             x2, [fp, #0x18]
    // 0x789bdc: ldr             x1, [fp, #0x10]
    // 0x789be0: r0 = LoadClassIdInstr(r1)
    //     0x789be0: ldur            x0, [x1, #-1]
    //     0x789be4: ubfx            x0, x0, #0xc, #0x14
    // 0x789be8: SaveReg r1
    //     0x789be8: str             x1, [SP, #-8]!
    // 0x789bec: r0 = GDT[cid_x0 + 0x271c]()
    //     0x789bec: mov             x17, #0x271c
    //     0x789bf0: add             lr, x0, x17
    //     0x789bf4: ldr             lr, [x21, lr, lsl #3]
    //     0x789bf8: blr             lr
    // 0x789bfc: add             SP, SP, #8
    // 0x789c00: mov             x3, x0
    // 0x789c04: ldr             x2, [fp, #0x18]
    // 0x789c08: LoadField: r4 = r2->field_57
    //     0x789c08: ldur            w4, [x2, #0x57]
    // 0x789c0c: DecompressPointer r4
    //     0x789c0c: add             x4, x4, HEAP, lsl #32
    // 0x789c10: r0 = BoxInt64Instr(r3)
    //     0x789c10: sbfiz           x0, x3, #1, #0x1f
    //     0x789c14: cmp             x3, x0, asr #1
    //     0x789c18: b.eq            #0x789c24
    //     0x789c1c: bl              #0xd69bb8
    //     0x789c20: stur            x3, [x0, #7]
    // 0x789c24: cmp             w0, w4
    // 0x789c28: b.eq            #0x789ca4
    // 0x789c2c: and             w16, w0, w4
    // 0x789c30: branchIfSmi(r16, 0x789c64)
    //     0x789c30: tbz             w16, #0, #0x789c64
    // 0x789c34: r16 = LoadClassIdInstr(r0)
    //     0x789c34: ldur            x16, [x0, #-1]
    //     0x789c38: ubfx            x16, x16, #0xc, #0x14
    // 0x789c3c: cmp             x16, #0x3c
    // 0x789c40: b.ne            #0x789c64
    // 0x789c44: r16 = LoadClassIdInstr(r4)
    //     0x789c44: ldur            x16, [x4, #-1]
    //     0x789c48: ubfx            x16, x16, #0xc, #0x14
    // 0x789c4c: cmp             x16, #0x3c
    // 0x789c50: b.ne            #0x789c64
    // 0x789c54: LoadField: r16 = r0->field_7
    //     0x789c54: ldur            x16, [x0, #7]
    // 0x789c58: LoadField: r17 = r4->field_7
    //     0x789c58: ldur            x17, [x4, #7]
    // 0x789c5c: cmp             x16, x17
    // 0x789c60: b.eq            #0x789ca4
    // 0x789c64: ldr             x3, [fp, #0x10]
    // 0x789c68: r0 = LoadClassIdInstr(r3)
    //     0x789c68: ldur            x0, [x3, #-1]
    //     0x789c6c: ubfx            x0, x0, #0xc, #0x14
    // 0x789c70: SaveReg r3
    //     0x789c70: str             x3, [SP, #-8]!
    // 0x789c74: r0 = GDT[cid_x0 + -0xfff]()
    //     0x789c74: sub             lr, x0, #0xfff
    //     0x789c78: ldr             lr, [x21, lr, lsl #3]
    //     0x789c7c: blr             lr
    // 0x789c80: add             SP, SP, #8
    // 0x789c84: ldr             x16, [fp, #0x18]
    // 0x789c88: stp             x0, x16, [SP, #-0x10]!
    // 0x789c8c: r0 = _giveUpPointer()
    //     0x789c8c: bl              #0x78ac04  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_giveUpPointer
    // 0x789c90: add             SP, SP, #0x10
    // 0x789c94: r0 = Null
    //     0x789c94: mov             x0, NULL
    // 0x789c98: LeaveFrame
    //     0x789c98: mov             SP, fp
    //     0x789c9c: ldp             fp, lr, [SP], #0x10
    // 0x789ca0: ret
    //     0x789ca0: ret             
    // 0x789ca4: ldr             x3, [fp, #0x10]
    // 0x789ca8: b               #0x789cb0
    // 0x789cac: ldr             x3, [fp, #0x10]
    // 0x789cb0: mov             x0, x3
    // 0x789cb4: r2 = Null
    //     0x789cb4: mov             x2, NULL
    // 0x789cb8: r1 = Null
    //     0x789cb8: mov             x1, NULL
    // 0x789cbc: cmp             w0, NULL
    // 0x789cc0: b.eq            #0x789ce0
    // 0x789cc4: branchIfSmi(r0, 0x789ce0)
    //     0x789cc4: tbz             w0, #0, #0x789ce0
    // 0x789cc8: r3 = LoadClassIdInstr(r0)
    //     0x789cc8: ldur            x3, [x0, #-1]
    //     0x789ccc: ubfx            x3, x3, #0xc, #0x14
    // 0x789cd0: cmp             x3, #0x908
    // 0x789cd4: b.eq            #0x789ce8
    // 0x789cd8: cmp             x3, #0xb3f
    // 0x789cdc: b.eq            #0x789ce8
    // 0x789ce0: r0 = false
    //     0x789ce0: add             x0, NULL, #0x30  ; false
    // 0x789ce4: b               #0x789cec
    // 0x789ce8: r0 = true
    //     0x789ce8: add             x0, NULL, #0x20  ; true
    // 0x789cec: tbz             w0, #4, #0x789d30
    // 0x789cf0: ldr             x0, [fp, #0x10]
    // 0x789cf4: r2 = Null
    //     0x789cf4: mov             x2, NULL
    // 0x789cf8: r1 = Null
    //     0x789cf8: mov             x1, NULL
    // 0x789cfc: cmp             w0, NULL
    // 0x789d00: b.eq            #0x789d20
    // 0x789d04: branchIfSmi(r0, 0x789d20)
    //     0x789d04: tbz             w0, #0, #0x789d20
    // 0x789d08: r3 = LoadClassIdInstr(r0)
    //     0x789d08: ldur            x3, [x0, #-1]
    //     0x789d0c: ubfx            x3, x3, #0xc, #0x14
    // 0x789d10: cmp             x3, #0x8fc
    // 0x789d14: b.eq            #0x789d28
    // 0x789d18: cmp             x3, #0xb39
    // 0x789d1c: b.eq            #0x789d28
    // 0x789d20: r0 = false
    //     0x789d20: add             x0, NULL, #0x30  ; false
    // 0x789d24: b               #0x789d2c
    // 0x789d28: r0 = true
    //     0x789d28: add             x0, NULL, #0x20  ; true
    // 0x789d2c: tbnz            w0, #4, #0x78a7cc
    // 0x789d30: ldr             x0, [fp, #0x10]
    // 0x789d34: r2 = Null
    //     0x789d34: mov             x2, NULL
    // 0x789d38: r1 = Null
    //     0x789d38: mov             x1, NULL
    // 0x789d3c: cmp             w0, NULL
    // 0x789d40: b.eq            #0x789d60
    // 0x789d44: branchIfSmi(r0, 0x789d60)
    //     0x789d44: tbz             w0, #0, #0x789d60
    // 0x789d48: r3 = LoadClassIdInstr(r0)
    //     0x789d48: ldur            x3, [x0, #-1]
    //     0x789d4c: ubfx            x3, x3, #0xc, #0x14
    // 0x789d50: cmp             x3, #0x908
    // 0x789d54: b.eq            #0x789d68
    // 0x789d58: cmp             x3, #0xb3f
    // 0x789d5c: b.eq            #0x789d68
    // 0x789d60: r0 = false
    //     0x789d60: add             x0, NULL, #0x30  ; false
    // 0x789d64: b               #0x789d6c
    // 0x789d68: r0 = true
    //     0x789d68: add             x0, NULL, #0x20  ; true
    // 0x789d6c: tbnz            w0, #4, #0x789d9c
    // 0x789d70: ldr             x1, [fp, #0x10]
    // 0x789d74: r0 = LoadClassIdInstr(r1)
    //     0x789d74: ldur            x0, [x1, #-1]
    //     0x789d78: ubfx            x0, x0, #0xc, #0x14
    // 0x789d7c: SaveReg r1
    //     0x789d7c: str             x1, [SP, #-8]!
    // 0x789d80: r0 = GDT[cid_x0 + 0x9887]()
    //     0x789d80: mov             x17, #0x9887
    //     0x789d84: add             lr, x0, x17
    //     0x789d88: ldr             lr, [x21, lr, lsl #3]
    //     0x789d8c: blr             lr
    // 0x789d90: add             SP, SP, #8
    // 0x789d94: mov             x3, x0
    // 0x789d98: b               #0x789dfc
    // 0x789d9c: ldr             x3, [fp, #0x10]
    // 0x789da0: mov             x0, x3
    // 0x789da4: r2 = Null
    //     0x789da4: mov             x2, NULL
    // 0x789da8: r1 = Null
    //     0x789da8: mov             x1, NULL
    // 0x789dac: r4 = LoadClassIdInstr(r0)
    //     0x789dac: ldur            x4, [x0, #-1]
    //     0x789db0: ubfx            x4, x4, #0xc, #0x14
    // 0x789db4: cmp             x4, #0x8fc
    // 0x789db8: b.eq            #0x789dd8
    // 0x789dbc: cmp             x4, #0xb39
    // 0x789dc0: b.eq            #0x789dd8
    // 0x789dc4: r8 = PointerPanZoomUpdateEvent
    //     0x789dc4: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e8c0] Type: PointerPanZoomUpdateEvent
    //     0x789dc8: ldr             x8, [x8, #0x8c0]
    // 0x789dcc: r3 = Null
    //     0x789dcc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e8c8] Null
    //     0x789dd0: ldr             x3, [x3, #0x8c8]
    // 0x789dd4: r0 = DefaultTypeTest()
    //     0x789dd4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x789dd8: ldr             x1, [fp, #0x10]
    // 0x789ddc: r0 = LoadClassIdInstr(r1)
    //     0x789ddc: ldur            x0, [x1, #-1]
    //     0x789de0: ubfx            x0, x0, #0xc, #0x14
    // 0x789de4: SaveReg r1
    //     0x789de4: str             x1, [SP, #-8]!
    // 0x789de8: r0 = GDT[cid_x0 + -0xffe]()
    //     0x789de8: sub             lr, x0, #0xffe
    //     0x789dec: ldr             lr, [x21, lr, lsl #3]
    //     0x789df0: blr             lr
    // 0x789df4: add             SP, SP, #8
    // 0x789df8: mov             x3, x0
    // 0x789dfc: ldr             x0, [fp, #0x10]
    // 0x789e00: stur            x3, [fp, #-8]
    // 0x789e04: r2 = Null
    //     0x789e04: mov             x2, NULL
    // 0x789e08: r1 = Null
    //     0x789e08: mov             x1, NULL
    // 0x789e0c: cmp             w0, NULL
    // 0x789e10: b.eq            #0x789e30
    // 0x789e14: branchIfSmi(r0, 0x789e30)
    //     0x789e14: tbz             w0, #0, #0x789e30
    // 0x789e18: r3 = LoadClassIdInstr(r0)
    //     0x789e18: ldur            x3, [x0, #-1]
    //     0x789e1c: ubfx            x3, x3, #0xc, #0x14
    // 0x789e20: cmp             x3, #0x908
    // 0x789e24: b.eq            #0x789e38
    // 0x789e28: cmp             x3, #0xb3f
    // 0x789e2c: b.eq            #0x789e38
    // 0x789e30: r0 = false
    //     0x789e30: add             x0, NULL, #0x30  ; false
    // 0x789e34: b               #0x789e3c
    // 0x789e38: r0 = true
    //     0x789e38: add             x0, NULL, #0x20  ; true
    // 0x789e3c: tbnz            w0, #4, #0x789e70
    // 0x789e40: ldr             x1, [fp, #0x10]
    // 0x789e44: r0 = LoadClassIdInstr(r1)
    //     0x789e44: ldur            x0, [x1, #-1]
    //     0x789e48: ubfx            x0, x0, #0xc, #0x14
    // 0x789e4c: SaveReg r1
    //     0x789e4c: str             x1, [SP, #-8]!
    // 0x789e50: r0 = GDT[cid_x0 + 0x104eb]()
    //     0x789e50: mov             x17, #0x4eb
    //     0x789e54: movk            x17, #1, lsl #16
    //     0x789e58: add             lr, x0, x17
    //     0x789e5c: ldr             lr, [x21, lr, lsl #3]
    //     0x789e60: blr             lr
    // 0x789e64: add             SP, SP, #8
    // 0x789e68: mov             x3, x0
    // 0x789e6c: b               #0x789ed0
    // 0x789e70: ldr             x3, [fp, #0x10]
    // 0x789e74: mov             x0, x3
    // 0x789e78: r2 = Null
    //     0x789e78: mov             x2, NULL
    // 0x789e7c: r1 = Null
    //     0x789e7c: mov             x1, NULL
    // 0x789e80: r4 = LoadClassIdInstr(r0)
    //     0x789e80: ldur            x4, [x0, #-1]
    //     0x789e84: ubfx            x4, x4, #0xc, #0x14
    // 0x789e88: cmp             x4, #0x8fc
    // 0x789e8c: b.eq            #0x789eac
    // 0x789e90: cmp             x4, #0xb39
    // 0x789e94: b.eq            #0x789eac
    // 0x789e98: r8 = PointerPanZoomUpdateEvent
    //     0x789e98: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e8c0] Type: PointerPanZoomUpdateEvent
    //     0x789e9c: ldr             x8, [x8, #0x8c0]
    // 0x789ea0: r3 = Null
    //     0x789ea0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e8d8] Null
    //     0x789ea4: ldr             x3, [x3, #0x8d8]
    // 0x789ea8: r0 = DefaultTypeTest()
    //     0x789ea8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x789eac: ldr             x1, [fp, #0x10]
    // 0x789eb0: r0 = LoadClassIdInstr(r1)
    //     0x789eb0: ldur            x0, [x1, #-1]
    //     0x789eb4: ubfx            x0, x0, #0xc, #0x14
    // 0x789eb8: SaveReg r1
    //     0x789eb8: str             x1, [SP, #-8]!
    // 0x789ebc: r0 = GDT[cid_x0 + -0xffa]()
    //     0x789ebc: sub             lr, x0, #0xffa
    //     0x789ec0: ldr             lr, [x21, lr, lsl #3]
    //     0x789ec4: blr             lr
    // 0x789ec8: add             SP, SP, #8
    // 0x789ecc: mov             x3, x0
    // 0x789ed0: ldr             x0, [fp, #0x10]
    // 0x789ed4: stur            x3, [fp, #-0x10]
    // 0x789ed8: r2 = Null
    //     0x789ed8: mov             x2, NULL
    // 0x789edc: r1 = Null
    //     0x789edc: mov             x1, NULL
    // 0x789ee0: cmp             w0, NULL
    // 0x789ee4: b.eq            #0x789f04
    // 0x789ee8: branchIfSmi(r0, 0x789f04)
    //     0x789ee8: tbz             w0, #0, #0x789f04
    // 0x789eec: r3 = LoadClassIdInstr(r0)
    //     0x789eec: ldur            x3, [x0, #-1]
    //     0x789ef0: ubfx            x3, x3, #0xc, #0x14
    // 0x789ef4: cmp             x3, #0x908
    // 0x789ef8: b.eq            #0x789f0c
    // 0x789efc: cmp             x3, #0xb3f
    // 0x789f00: b.eq            #0x789f0c
    // 0x789f04: r0 = false
    //     0x789f04: add             x0, NULL, #0x30  ; false
    // 0x789f08: b               #0x789f10
    // 0x789f0c: r0 = true
    //     0x789f0c: add             x0, NULL, #0x20  ; true
    // 0x789f10: tbnz            w0, #4, #0x789f3c
    // 0x789f14: ldr             x1, [fp, #0x10]
    // 0x789f18: r0 = LoadClassIdInstr(r1)
    //     0x789f18: ldur            x0, [x1, #-1]
    //     0x789f1c: ubfx            x0, x0, #0xc, #0x14
    // 0x789f20: SaveReg r1
    //     0x789f20: str             x1, [SP, #-8]!
    // 0x789f24: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x789f24: sub             lr, x0, #0xfd9
    //     0x789f28: ldr             lr, [x21, lr, lsl #3]
    //     0x789f2c: blr             lr
    // 0x789f30: add             SP, SP, #8
    // 0x789f34: mov             x3, x0
    // 0x789f38: b               #0x789fd0
    // 0x789f3c: ldr             x1, [fp, #0x10]
    // 0x789f40: r0 = LoadClassIdInstr(r1)
    //     0x789f40: ldur            x0, [x1, #-1]
    //     0x789f44: ubfx            x0, x0, #0xc, #0x14
    // 0x789f48: SaveReg r1
    //     0x789f48: str             x1, [SP, #-8]!
    // 0x789f4c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x789f4c: sub             lr, x0, #0xfd9
    //     0x789f50: ldr             lr, [x21, lr, lsl #3]
    //     0x789f54: blr             lr
    // 0x789f58: add             SP, SP, #8
    // 0x789f5c: mov             x3, x0
    // 0x789f60: ldr             x0, [fp, #0x10]
    // 0x789f64: r2 = Null
    //     0x789f64: mov             x2, NULL
    // 0x789f68: r1 = Null
    //     0x789f68: mov             x1, NULL
    // 0x789f6c: stur            x3, [fp, #-0x18]
    // 0x789f70: r4 = LoadClassIdInstr(r0)
    //     0x789f70: ldur            x4, [x0, #-1]
    //     0x789f74: ubfx            x4, x4, #0xc, #0x14
    // 0x789f78: cmp             x4, #0x8fc
    // 0x789f7c: b.eq            #0x789f9c
    // 0x789f80: cmp             x4, #0xb39
    // 0x789f84: b.eq            #0x789f9c
    // 0x789f88: r8 = PointerPanZoomUpdateEvent
    //     0x789f88: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e8c0] Type: PointerPanZoomUpdateEvent
    //     0x789f8c: ldr             x8, [x8, #0x8c0]
    // 0x789f90: r3 = Null
    //     0x789f90: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e8e8] Null
    //     0x789f94: ldr             x3, [x3, #0x8e8]
    // 0x789f98: r0 = DefaultTypeTest()
    //     0x789f98: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x789f9c: ldr             x1, [fp, #0x10]
    // 0x789fa0: r0 = LoadClassIdInstr(r1)
    //     0x789fa0: ldur            x0, [x1, #-1]
    //     0x789fa4: ubfx            x0, x0, #0xc, #0x14
    // 0x789fa8: SaveReg r1
    //     0x789fa8: str             x1, [SP, #-8]!
    // 0x789fac: r0 = GDT[cid_x0 + -0x1000]()
    //     0x789fac: sub             lr, x0, #1, lsl #12
    //     0x789fb0: ldr             lr, [x21, lr, lsl #3]
    //     0x789fb4: blr             lr
    // 0x789fb8: add             SP, SP, #8
    // 0x789fbc: ldur            x16, [fp, #-0x18]
    // 0x789fc0: stp             x0, x16, [SP, #-0x10]!
    // 0x789fc4: r0 = +()
    //     0x789fc4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x789fc8: add             SP, SP, #0x10
    // 0x789fcc: mov             x3, x0
    // 0x789fd0: ldr             x0, [fp, #0x10]
    // 0x789fd4: stur            x3, [fp, #-0x18]
    // 0x789fd8: r2 = Null
    //     0x789fd8: mov             x2, NULL
    // 0x789fdc: r1 = Null
    //     0x789fdc: mov             x1, NULL
    // 0x789fe0: cmp             w0, NULL
    // 0x789fe4: b.eq            #0x78a004
    // 0x789fe8: branchIfSmi(r0, 0x78a004)
    //     0x789fe8: tbz             w0, #0, #0x78a004
    // 0x789fec: r3 = LoadClassIdInstr(r0)
    //     0x789fec: ldur            x3, [x0, #-1]
    //     0x789ff0: ubfx            x3, x3, #0xc, #0x14
    // 0x789ff4: cmp             x3, #0x908
    // 0x789ff8: b.eq            #0x78a00c
    // 0x789ffc: cmp             x3, #0xb3f
    // 0x78a000: b.eq            #0x78a00c
    // 0x78a004: r0 = false
    //     0x78a004: add             x0, NULL, #0x30  ; false
    // 0x78a008: b               #0x78a010
    // 0x78a00c: r0 = true
    //     0x78a00c: add             x0, NULL, #0x20  ; true
    // 0x78a010: tbnz            w0, #4, #0x78a040
    // 0x78a014: ldr             x1, [fp, #0x10]
    // 0x78a018: r0 = LoadClassIdInstr(r1)
    //     0x78a018: ldur            x0, [x1, #-1]
    //     0x78a01c: ubfx            x0, x0, #0xc, #0x14
    // 0x78a020: SaveReg r1
    //     0x78a020: str             x1, [SP, #-8]!
    // 0x78a024: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x78a024: mov             x17, #0x57c0
    //     0x78a028: add             lr, x0, x17
    //     0x78a02c: ldr             lr, [x21, lr, lsl #3]
    //     0x78a030: blr             lr
    // 0x78a034: add             SP, SP, #8
    // 0x78a038: mov             x2, x0
    // 0x78a03c: b               #0x78a0d8
    // 0x78a040: ldr             x1, [fp, #0x10]
    // 0x78a044: r0 = LoadClassIdInstr(r1)
    //     0x78a044: ldur            x0, [x1, #-1]
    //     0x78a048: ubfx            x0, x0, #0xc, #0x14
    // 0x78a04c: SaveReg r1
    //     0x78a04c: str             x1, [SP, #-8]!
    // 0x78a050: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x78a050: mov             x17, #0x57c0
    //     0x78a054: add             lr, x0, x17
    //     0x78a058: ldr             lr, [x21, lr, lsl #3]
    //     0x78a05c: blr             lr
    // 0x78a060: add             SP, SP, #8
    // 0x78a064: mov             x3, x0
    // 0x78a068: ldr             x0, [fp, #0x10]
    // 0x78a06c: r2 = Null
    //     0x78a06c: mov             x2, NULL
    // 0x78a070: r1 = Null
    //     0x78a070: mov             x1, NULL
    // 0x78a074: stur            x3, [fp, #-0x20]
    // 0x78a078: r4 = LoadClassIdInstr(r0)
    //     0x78a078: ldur            x4, [x0, #-1]
    //     0x78a07c: ubfx            x4, x4, #0xc, #0x14
    // 0x78a080: cmp             x4, #0x8fc
    // 0x78a084: b.eq            #0x78a0a4
    // 0x78a088: cmp             x4, #0xb39
    // 0x78a08c: b.eq            #0x78a0a4
    // 0x78a090: r8 = PointerPanZoomUpdateEvent
    //     0x78a090: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e8c0] Type: PointerPanZoomUpdateEvent
    //     0x78a094: ldr             x8, [x8, #0x8c0]
    // 0x78a098: r3 = Null
    //     0x78a098: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e8f8] Null
    //     0x78a09c: ldr             x3, [x3, #0x8f8]
    // 0x78a0a0: r0 = DefaultTypeTest()
    //     0x78a0a0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x78a0a4: ldr             x1, [fp, #0x10]
    // 0x78a0a8: r0 = LoadClassIdInstr(r1)
    //     0x78a0a8: ldur            x0, [x1, #-1]
    //     0x78a0ac: ubfx            x0, x0, #0xc, #0x14
    // 0x78a0b0: SaveReg r1
    //     0x78a0b0: str             x1, [SP, #-8]!
    // 0x78a0b4: r0 = GDT[cid_x0 + -0xffc]()
    //     0x78a0b4: sub             lr, x0, #0xffc
    //     0x78a0b8: ldr             lr, [x21, lr, lsl #3]
    //     0x78a0bc: blr             lr
    // 0x78a0c0: add             SP, SP, #8
    // 0x78a0c4: ldur            x16, [fp, #-0x20]
    // 0x78a0c8: stp             x0, x16, [SP, #-0x10]!
    // 0x78a0cc: r0 = +()
    //     0x78a0cc: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x78a0d0: add             SP, SP, #0x10
    // 0x78a0d4: mov             x2, x0
    // 0x78a0d8: ldr             x1, [fp, #0x18]
    // 0x78a0dc: stur            x2, [fp, #-0x20]
    // 0x78a0e0: LoadField: r0 = r1->field_47
    //     0x78a0e0: ldur            w0, [x1, #0x47]
    // 0x78a0e4: DecompressPointer r0
    //     0x78a0e4: add             x0, x0, HEAP, lsl #32
    // 0x78a0e8: r16 = Instance__DragState
    //     0x78a0e8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f08] Obj!_DragState@b65b71
    //     0x78a0ec: ldr             x16, [x16, #0xf08]
    // 0x78a0f0: cmp             w0, w16
    // 0x78a0f4: b.ne            #0x78a25c
    // 0x78a0f8: ldr             x3, [fp, #0x10]
    // 0x78a0fc: r0 = LoadClassIdInstr(r3)
    //     0x78a0fc: ldur            x0, [x3, #-1]
    //     0x78a100: ubfx            x0, x0, #0xc, #0x14
    // 0x78a104: SaveReg r3
    //     0x78a104: str             x3, [SP, #-8]!
    // 0x78a108: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x78a108: sub             lr, x0, #0xf3a
    //     0x78a10c: ldr             lr, [x21, lr, lsl #3]
    //     0x78a110: blr             lr
    // 0x78a114: add             SP, SP, #8
    // 0x78a118: mov             x1, x0
    // 0x78a11c: ldr             x0, [fp, #0x18]
    // 0x78a120: stur            x1, [fp, #-0x30]
    // 0x78a124: r2 = LoadClassIdInstr(r0)
    //     0x78a124: ldur            x2, [x0, #-1]
    //     0x78a128: ubfx            x2, x2, #0xc, #0x14
    // 0x78a12c: lsl             x2, x2, #1
    // 0x78a130: stur            x2, [fp, #-0x28]
    // 0x78a134: r17 = 4706
    //     0x78a134: mov             x17, #0x1262
    // 0x78a138: cmp             w2, w17
    // 0x78a13c: b.ne            #0x78a14c
    // 0x78a140: ldur            x1, [fp, #-0x10]
    // 0x78a144: mov             x0, x2
    // 0x78a148: b               #0x78a1b0
    // 0x78a14c: r17 = 4708
    //     0x78a14c: mov             x17, #0x1264
    // 0x78a150: cmp             w2, w17
    // 0x78a154: b.ne            #0x78a184
    // 0x78a158: ldur            x3, [fp, #-0x10]
    // 0x78a15c: LoadField: d0 = r3->field_7
    //     0x78a15c: ldur            d0, [x3, #7]
    // 0x78a160: stur            d0, [fp, #-0x38]
    // 0x78a164: r0 = Offset()
    //     0x78a164: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x78a168: ldur            d0, [fp, #-0x38]
    // 0x78a16c: StoreField: r0->field_7 = d0
    //     0x78a16c: stur            d0, [x0, #7]
    // 0x78a170: d0 = 0.000000
    //     0x78a170: eor             v0.16b, v0.16b, v0.16b
    // 0x78a174: StoreField: r0->field_f = d0
    //     0x78a174: stur            d0, [x0, #0xf]
    // 0x78a178: mov             x1, x0
    // 0x78a17c: ldur            x0, [fp, #-0x28]
    // 0x78a180: b               #0x78a1b0
    // 0x78a184: ldur            x0, [fp, #-0x10]
    // 0x78a188: d0 = 0.000000
    //     0x78a188: eor             v0.16b, v0.16b, v0.16b
    // 0x78a18c: LoadField: d1 = r0->field_f
    //     0x78a18c: ldur            d1, [x0, #0xf]
    // 0x78a190: stur            d1, [fp, #-0x38]
    // 0x78a194: r0 = Offset()
    //     0x78a194: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x78a198: d0 = 0.000000
    //     0x78a198: eor             v0.16b, v0.16b, v0.16b
    // 0x78a19c: StoreField: r0->field_7 = d0
    //     0x78a19c: stur            d0, [x0, #7]
    // 0x78a1a0: ldur            d0, [fp, #-0x38]
    // 0x78a1a4: StoreField: r0->field_f = d0
    //     0x78a1a4: stur            d0, [x0, #0xf]
    // 0x78a1a8: mov             x1, x0
    // 0x78a1ac: ldur            x0, [fp, #-0x28]
    // 0x78a1b0: r17 = 4706
    //     0x78a1b0: mov             x17, #0x1262
    // 0x78a1b4: cmp             w0, w17
    // 0x78a1b8: b.ne            #0x78a1c4
    // 0x78a1bc: r0 = Null
    //     0x78a1bc: mov             x0, NULL
    // 0x78a1c0: b               #0x78a234
    // 0x78a1c4: r17 = 4708
    //     0x78a1c4: mov             x17, #0x1264
    // 0x78a1c8: cmp             w0, w17
    // 0x78a1cc: b.ne            #0x78a204
    // 0x78a1d0: ldur            x0, [fp, #-0x10]
    // 0x78a1d4: LoadField: d0 = r0->field_7
    //     0x78a1d4: ldur            d0, [x0, #7]
    // 0x78a1d8: r0 = inline_Allocate_Double()
    //     0x78a1d8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x78a1dc: add             x0, x0, #0x10
    //     0x78a1e0: cmp             x2, x0
    //     0x78a1e4: b.ls            #0x78a8dc
    //     0x78a1e8: str             x0, [THR, #0x60]  ; THR::top
    //     0x78a1ec: sub             x0, x0, #0xf
    //     0x78a1f0: mov             x2, #0xd108
    //     0x78a1f4: movk            x2, #3, lsl #16
    //     0x78a1f8: stur            x2, [x0, #-1]
    // 0x78a1fc: StoreField: r0->field_7 = d0
    //     0x78a1fc: stur            d0, [x0, #7]
    // 0x78a200: b               #0x78a234
    // 0x78a204: ldur            x0, [fp, #-0x10]
    // 0x78a208: LoadField: d0 = r0->field_f
    //     0x78a208: ldur            d0, [x0, #0xf]
    // 0x78a20c: r0 = inline_Allocate_Double()
    //     0x78a20c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x78a210: add             x0, x0, #0x10
    //     0x78a214: cmp             x2, x0
    //     0x78a218: b.ls            #0x78a8f4
    //     0x78a21c: str             x0, [THR, #0x60]  ; THR::top
    //     0x78a220: sub             x0, x0, #0xf
    //     0x78a224: mov             x2, #0xd108
    //     0x78a228: movk            x2, #3, lsl #16
    //     0x78a22c: stur            x2, [x0, #-1]
    // 0x78a230: StoreField: r0->field_7 = d0
    //     0x78a230: stur            d0, [x0, #7]
    // 0x78a234: ldr             x16, [fp, #0x18]
    // 0x78a238: stp             x1, x16, [SP, #-0x10]!
    // 0x78a23c: ldur            x16, [fp, #-0x18]
    // 0x78a240: ldur            lr, [fp, #-0x20]
    // 0x78a244: stp             lr, x16, [SP, #-0x10]!
    // 0x78a248: ldur            x16, [fp, #-0x30]
    // 0x78a24c: stp             x16, x0, [SP, #-0x10]!
    // 0x78a250: r0 = _checkUpdate()
    //     0x78a250: bl              #0x78aac8  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkUpdate
    // 0x78a254: add             SP, SP, #0x30
    // 0x78a258: b               #0x78a7cc
    // 0x78a25c: ldr             x2, [fp, #0x10]
    // 0x78a260: ldur            x3, [fp, #-8]
    // 0x78a264: ldur            x0, [fp, #-0x10]
    // 0x78a268: d0 = 0.000000
    //     0x78a268: eor             v0.16b, v0.16b, v0.16b
    // 0x78a26c: LoadField: r4 = r1->field_4f
    //     0x78a26c: ldur            w4, [x1, #0x4f]
    // 0x78a270: DecompressPointer r4
    //     0x78a270: add             x4, x4, HEAP, lsl #32
    // 0x78a274: r16 = Sentinel
    //     0x78a274: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78a278: cmp             w4, w16
    // 0x78a27c: b.eq            #0x78a90c
    // 0x78a280: stur            x4, [fp, #-0x18]
    // 0x78a284: r0 = OffsetPair()
    //     0x78a284: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0x78a288: mov             x1, x0
    // 0x78a28c: ldur            x0, [fp, #-0x10]
    // 0x78a290: StoreField: r1->field_7 = r0
    //     0x78a290: stur            w0, [x1, #7]
    // 0x78a294: ldur            x2, [fp, #-8]
    // 0x78a298: StoreField: r1->field_b = r2
    //     0x78a298: stur            w2, [x1, #0xb]
    // 0x78a29c: ldur            x16, [fp, #-0x18]
    // 0x78a2a0: stp             x1, x16, [SP, #-0x10]!
    // 0x78a2a4: r0 = +()
    //     0x78a2a4: bl              #0x714388  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0x78a2a8: add             SP, SP, #0x10
    // 0x78a2ac: ldr             x1, [fp, #0x18]
    // 0x78a2b0: StoreField: r1->field_4f = r0
    //     0x78a2b0: stur            w0, [x1, #0x4f]
    //     0x78a2b4: ldurb           w16, [x1, #-1]
    //     0x78a2b8: ldurb           w17, [x0, #-1]
    //     0x78a2bc: and             x16, x17, x16, lsr #2
    //     0x78a2c0: tst             x16, HEAP, lsr #32
    //     0x78a2c4: b.eq            #0x78a2cc
    //     0x78a2c8: bl              #0xd6826c
    // 0x78a2cc: ldr             x2, [fp, #0x10]
    // 0x78a2d0: r0 = LoadClassIdInstr(r2)
    //     0x78a2d0: ldur            x0, [x2, #-1]
    //     0x78a2d4: ubfx            x0, x0, #0xc, #0x14
    // 0x78a2d8: SaveReg r2
    //     0x78a2d8: str             x2, [SP, #-8]!
    // 0x78a2dc: r0 = GDT[cid_x0 + -0xf3a]()
    //     0x78a2dc: sub             lr, x0, #0xf3a
    //     0x78a2e0: ldr             lr, [x21, lr, lsl #3]
    //     0x78a2e4: blr             lr
    // 0x78a2e8: add             SP, SP, #8
    // 0x78a2ec: ldr             x1, [fp, #0x18]
    // 0x78a2f0: StoreField: r1->field_53 = r0
    //     0x78a2f0: stur            w0, [x1, #0x53]
    //     0x78a2f4: ldurb           w16, [x1, #-1]
    //     0x78a2f8: ldurb           w17, [x0, #-1]
    //     0x78a2fc: and             x16, x17, x16, lsr #2
    //     0x78a300: tst             x16, HEAP, lsr #32
    //     0x78a304: b.eq            #0x78a30c
    //     0x78a308: bl              #0xd6826c
    // 0x78a30c: ldr             x2, [fp, #0x10]
    // 0x78a310: r0 = LoadClassIdInstr(r2)
    //     0x78a310: ldur            x0, [x2, #-1]
    //     0x78a314: ubfx            x0, x0, #0xc, #0x14
    // 0x78a318: SaveReg r2
    //     0x78a318: str             x2, [SP, #-8]!
    // 0x78a31c: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x78a31c: mov             x17, #0x3f6e
    //     0x78a320: add             lr, x0, x17
    //     0x78a324: ldr             lr, [x21, lr, lsl #3]
    //     0x78a328: blr             lr
    // 0x78a32c: add             SP, SP, #8
    // 0x78a330: ldr             x1, [fp, #0x18]
    // 0x78a334: StoreField: r1->field_5b = r0
    //     0x78a334: stur            w0, [x1, #0x5b]
    //     0x78a338: ldurb           w16, [x1, #-1]
    //     0x78a33c: ldurb           w17, [x0, #-1]
    //     0x78a340: and             x16, x17, x16, lsr #2
    //     0x78a344: tst             x16, HEAP, lsr #32
    //     0x78a348: b.eq            #0x78a350
    //     0x78a34c: bl              #0xd6826c
    // 0x78a350: r0 = LoadClassIdInstr(r1)
    //     0x78a350: ldur            x0, [x1, #-1]
    //     0x78a354: ubfx            x0, x0, #0xc, #0x14
    // 0x78a358: lsl             x0, x0, #1
    // 0x78a35c: stur            x0, [fp, #-8]
    // 0x78a360: r17 = 4706
    //     0x78a360: mov             x17, #0x1262
    // 0x78a364: cmp             w0, w17
    // 0x78a368: b.ne            #0x78a378
    // 0x78a36c: ldur            x2, [fp, #-0x10]
    // 0x78a370: d0 = 0.000000
    //     0x78a370: eor             v0.16b, v0.16b, v0.16b
    // 0x78a374: b               #0x78a3d4
    // 0x78a378: r17 = 4708
    //     0x78a378: mov             x17, #0x1264
    // 0x78a37c: cmp             w0, w17
    // 0x78a380: b.ne            #0x78a3ac
    // 0x78a384: ldur            x2, [fp, #-0x10]
    // 0x78a388: LoadField: d0 = r2->field_7
    //     0x78a388: ldur            d0, [x2, #7]
    // 0x78a38c: stur            d0, [fp, #-0x38]
    // 0x78a390: r0 = Offset()
    //     0x78a390: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x78a394: ldur            d0, [fp, #-0x38]
    // 0x78a398: StoreField: r0->field_7 = d0
    //     0x78a398: stur            d0, [x0, #7]
    // 0x78a39c: d0 = 0.000000
    //     0x78a39c: eor             v0.16b, v0.16b, v0.16b
    // 0x78a3a0: StoreField: r0->field_f = d0
    //     0x78a3a0: stur            d0, [x0, #0xf]
    // 0x78a3a4: mov             x2, x0
    // 0x78a3a8: b               #0x78a3d4
    // 0x78a3ac: ldur            x2, [fp, #-0x10]
    // 0x78a3b0: d0 = 0.000000
    //     0x78a3b0: eor             v0.16b, v0.16b, v0.16b
    // 0x78a3b4: LoadField: d1 = r2->field_f
    //     0x78a3b4: ldur            d1, [x2, #0xf]
    // 0x78a3b8: stur            d1, [fp, #-0x38]
    // 0x78a3bc: r0 = Offset()
    //     0x78a3bc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x78a3c0: d0 = 0.000000
    //     0x78a3c0: eor             v0.16b, v0.16b, v0.16b
    // 0x78a3c4: StoreField: r0->field_7 = d0
    //     0x78a3c4: stur            d0, [x0, #7]
    // 0x78a3c8: ldur            d1, [fp, #-0x38]
    // 0x78a3cc: StoreField: r0->field_f = d1
    //     0x78a3cc: stur            d1, [x0, #0xf]
    // 0x78a3d0: mov             x2, x0
    // 0x78a3d4: ldr             x1, [fp, #0x10]
    // 0x78a3d8: stur            x2, [fp, #-0x10]
    // 0x78a3dc: r0 = LoadClassIdInstr(r1)
    //     0x78a3dc: ldur            x0, [x1, #-1]
    //     0x78a3e0: ubfx            x0, x0, #0xc, #0x14
    // 0x78a3e4: SaveReg r1
    //     0x78a3e4: str             x1, [SP, #-8]!
    // 0x78a3e8: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x78a3e8: mov             x17, #0x3f6e
    //     0x78a3ec: add             lr, x0, x17
    //     0x78a3f0: ldr             lr, [x21, lr, lsl #3]
    //     0x78a3f4: blr             lr
    // 0x78a3f8: add             SP, SP, #8
    // 0x78a3fc: cmp             w0, NULL
    // 0x78a400: b.ne            #0x78a40c
    // 0x78a404: r2 = Null
    //     0x78a404: mov             x2, NULL
    // 0x78a408: b               #0x78a448
    // 0x78a40c: ldr             x1, [fp, #0x10]
    // 0x78a410: r0 = LoadClassIdInstr(r1)
    //     0x78a410: ldur            x0, [x1, #-1]
    //     0x78a414: ubfx            x0, x0, #0xc, #0x14
    // 0x78a418: SaveReg r1
    //     0x78a418: str             x1, [SP, #-8]!
    // 0x78a41c: r0 = GDT[cid_x0 + 0x3f6e]()
    //     0x78a41c: mov             x17, #0x3f6e
    //     0x78a420: add             lr, x0, x17
    //     0x78a424: ldr             lr, [x21, lr, lsl #3]
    //     0x78a428: blr             lr
    // 0x78a42c: add             SP, SP, #8
    // 0x78a430: cmp             w0, NULL
    // 0x78a434: b.eq            #0x78a918
    // 0x78a438: SaveReg r0
    //     0x78a438: str             x0, [SP, #-8]!
    // 0x78a43c: r0 = tryInvert()
    //     0x78a43c: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x78a440: add             SP, SP, #8
    // 0x78a444: mov             x2, x0
    // 0x78a448: ldr             x0, [fp, #0x18]
    // 0x78a44c: ldur            x1, [fp, #-8]
    // 0x78a450: LoadField: r3 = r0->field_5f
    //     0x78a450: ldur            w3, [x0, #0x5f]
    // 0x78a454: DecompressPointer r3
    //     0x78a454: add             x3, x3, HEAP, lsl #32
    // 0x78a458: r16 = Sentinel
    //     0x78a458: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x78a45c: cmp             w3, w16
    // 0x78a460: b.eq            #0x78a91c
    // 0x78a464: stur            x3, [fp, #-0x18]
    // 0x78a468: ldur            x16, [fp, #-0x10]
    // 0x78a46c: stp             x16, x2, [SP, #-0x10]!
    // 0x78a470: ldur            x16, [fp, #-0x20]
    // 0x78a474: SaveReg r16
    //     0x78a474: str             x16, [SP, #-8]!
    // 0x78a478: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x78a478: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x78a47c: r0 = transformDeltaViaPositions()
    //     0x78a47c: bl              #0x5b64a0  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0x78a480: add             SP, SP, #0x18
    // 0x78a484: LoadField: d0 = r0->field_7
    //     0x78a484: ldur            d0, [x0, #7]
    // 0x78a488: fmul            d1, d0, d0
    // 0x78a48c: LoadField: d0 = r0->field_f
    //     0x78a48c: ldur            d0, [x0, #0xf]
    // 0x78a490: fmul            d2, d0, d0
    // 0x78a494: fadd            d0, d1, d2
    // 0x78a498: fsqrt           d1, d0
    // 0x78a49c: ldur            x1, [fp, #-8]
    // 0x78a4a0: r17 = 4706
    //     0x78a4a0: mov             x17, #0x1262
    // 0x78a4a4: cmp             w1, w17
    // 0x78a4a8: b.ne            #0x78a4b4
    // 0x78a4ac: r0 = Null
    //     0x78a4ac: mov             x0, NULL
    // 0x78a4b0: b               #0x78a524
    // 0x78a4b4: r17 = 4708
    //     0x78a4b4: mov             x17, #0x1264
    // 0x78a4b8: cmp             w1, w17
    // 0x78a4bc: b.ne            #0x78a4f4
    // 0x78a4c0: ldur            x0, [fp, #-0x10]
    // 0x78a4c4: LoadField: d0 = r0->field_7
    //     0x78a4c4: ldur            d0, [x0, #7]
    // 0x78a4c8: r0 = inline_Allocate_Double()
    //     0x78a4c8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x78a4cc: add             x0, x0, #0x10
    //     0x78a4d0: cmp             x2, x0
    //     0x78a4d4: b.ls            #0x78a928
    //     0x78a4d8: str             x0, [THR, #0x60]  ; THR::top
    //     0x78a4dc: sub             x0, x0, #0xf
    //     0x78a4e0: mov             x2, #0xd108
    //     0x78a4e4: movk            x2, #3, lsl #16
    //     0x78a4e8: stur            x2, [x0, #-1]
    // 0x78a4ec: StoreField: r0->field_7 = d0
    //     0x78a4ec: stur            d0, [x0, #7]
    // 0x78a4f0: b               #0x78a524
    // 0x78a4f4: ldur            x0, [fp, #-0x10]
    // 0x78a4f8: LoadField: d0 = r0->field_f
    //     0x78a4f8: ldur            d0, [x0, #0xf]
    // 0x78a4fc: r0 = inline_Allocate_Double()
    //     0x78a4fc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x78a500: add             x0, x0, #0x10
    //     0x78a504: cmp             x2, x0
    //     0x78a508: b.ls            #0x78a940
    //     0x78a50c: str             x0, [THR, #0x60]  ; THR::top
    //     0x78a510: sub             x0, x0, #0xf
    //     0x78a514: mov             x2, #0xd108
    //     0x78a518: movk            x2, #3, lsl #16
    //     0x78a51c: stur            x2, [x0, #-1]
    // 0x78a520: StoreField: r0->field_7 = d0
    //     0x78a520: stur            d0, [x0, #7]
    // 0x78a524: cmp             w0, NULL
    // 0x78a528: b.ne            #0x78a534
    // 0x78a52c: d2 = 1.000000
    //     0x78a52c: fmov            d2, #1.00000000
    // 0x78a530: b               #0x78a53c
    // 0x78a534: LoadField: d0 = r0->field_7
    //     0x78a534: ldur            d0, [x0, #7]
    // 0x78a538: mov             v2.16b, v0.16b
    // 0x78a53c: d0 = 0.000000
    //     0x78a53c: eor             v0.16b, v0.16b, v0.16b
    // 0x78a540: fcmp            d2, d0
    // 0x78a544: b.vs            #0x78a554
    // 0x78a548: b.le            #0x78a554
    // 0x78a54c: d2 = 1.000000
    //     0x78a54c: fmov            d2, #1.00000000
    // 0x78a550: b               #0x78a56c
    // 0x78a554: fcmp            d2, d0
    // 0x78a558: b.vs            #0x78a56c
    // 0x78a55c: b.ge            #0x78a56c
    // 0x78a560: d2 = 1.000000
    //     0x78a560: fmov            d2, #1.00000000
    // 0x78a564: fneg            d3, d2
    // 0x78a568: mov             v2.16b, v3.16b
    // 0x78a56c: ldr             x2, [fp, #0x18]
    // 0x78a570: ldr             x3, [fp, #0x10]
    // 0x78a574: ldur            x0, [fp, #-0x18]
    // 0x78a578: fmul            d3, d1, d2
    // 0x78a57c: LoadField: d1 = r0->field_7
    //     0x78a57c: ldur            d1, [x0, #7]
    // 0x78a580: fadd            d2, d1, d3
    // 0x78a584: r0 = inline_Allocate_Double()
    //     0x78a584: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x78a588: add             x0, x0, #0x10
    //     0x78a58c: cmp             x4, x0
    //     0x78a590: b.ls            #0x78a958
    //     0x78a594: str             x0, [THR, #0x60]  ; THR::top
    //     0x78a598: sub             x0, x0, #0xf
    //     0x78a59c: mov             x4, #0xd108
    //     0x78a5a0: movk            x4, #3, lsl #16
    //     0x78a5a4: stur            x4, [x0, #-1]
    // 0x78a5a8: StoreField: r0->field_7 = d2
    //     0x78a5a8: stur            d2, [x0, #7]
    // 0x78a5ac: StoreField: r2->field_5f = r0
    //     0x78a5ac: stur            w0, [x2, #0x5f]
    //     0x78a5b0: ldurb           w16, [x2, #-1]
    //     0x78a5b4: ldurb           w17, [x0, #-1]
    //     0x78a5b8: and             x16, x17, x16, lsr #2
    //     0x78a5bc: tst             x16, HEAP, lsr #32
    //     0x78a5c0: b.eq            #0x78a5c8
    //     0x78a5c4: bl              #0xd6828c
    // 0x78a5c8: r0 = LoadClassIdInstr(r3)
    //     0x78a5c8: ldur            x0, [x3, #-1]
    //     0x78a5cc: ubfx            x0, x0, #0xc, #0x14
    // 0x78a5d0: SaveReg r3
    //     0x78a5d0: str             x3, [SP, #-8]!
    // 0x78a5d4: r0 = GDT[cid_x0 + -0xf60]()
    //     0x78a5d4: sub             lr, x0, #0xf60
    //     0x78a5d8: ldr             lr, [x21, lr, lsl #3]
    //     0x78a5dc: blr             lr
    // 0x78a5e0: add             SP, SP, #8
    // 0x78a5e4: mov             x1, x0
    // 0x78a5e8: ldr             x0, [fp, #0x18]
    // 0x78a5ec: LoadField: r2 = r0->field_7
    //     0x78a5ec: ldur            w2, [x0, #7]
    // 0x78a5f0: DecompressPointer r2
    //     0x78a5f0: add             x2, x2, HEAP, lsl #32
    // 0x78a5f4: ldur            x3, [fp, #-8]
    // 0x78a5f8: r17 = 4706
    //     0x78a5f8: mov             x17, #0x1262
    // 0x78a5fc: cmp             w3, w17
    // 0x78a600: b.ne            #0x78a674
    // 0x78a604: d0 = 0.000000
    //     0x78a604: eor             v0.16b, v0.16b, v0.16b
    // 0x78a608: LoadField: r3 = r0->field_5f
    //     0x78a608: ldur            w3, [x0, #0x5f]
    // 0x78a60c: DecompressPointer r3
    //     0x78a60c: add             x3, x3, HEAP, lsl #32
    // 0x78a610: LoadField: d1 = r3->field_7
    //     0x78a610: ldur            d1, [x3, #7]
    // 0x78a614: fcmp            d1, d0
    // 0x78a618: b.vs            #0x78a628
    // 0x78a61c: b.ne            #0x78a628
    // 0x78a620: d0 = 0.000000
    //     0x78a620: eor             v0.16b, v0.16b, v0.16b
    // 0x78a624: b               #0x78a640
    // 0x78a628: fcmp            d1, d0
    // 0x78a62c: b.vs            #0x78a63c
    // 0x78a630: b.ge            #0x78a63c
    // 0x78a634: fneg            d0, d1
    // 0x78a638: b               #0x78a640
    // 0x78a63c: mov             v0.16b, v1.16b
    // 0x78a640: stur            d0, [fp, #-0x38]
    // 0x78a644: stp             x2, x1, [SP, #-0x10]!
    // 0x78a648: r0 = computePanSlop()
    //     0x78a648: bl              #0x78a9bc  ; [package:flutter/src/gestures/events.dart] ::computePanSlop
    // 0x78a64c: add             SP, SP, #0x10
    // 0x78a650: cmp             w0, NULL
    // 0x78a654: b.eq            #0x78a978
    // 0x78a658: LoadField: d0 = r0->field_7
    //     0x78a658: ldur            d0, [x0, #7]
    // 0x78a65c: ldur            d1, [fp, #-0x38]
    // 0x78a660: fcmp            d1, d0
    // 0x78a664: b.vs            #0x78a7cc
    // 0x78a668: b.le            #0x78a7cc
    // 0x78a66c: ldr             x0, [fp, #0x18]
    // 0x78a670: b               #0x78a7b8
    // 0x78a674: d0 = 0.000000
    //     0x78a674: eor             v0.16b, v0.16b, v0.16b
    // 0x78a678: r17 = 4708
    //     0x78a678: mov             x17, #0x1264
    // 0x78a67c: cmp             w3, w17
    // 0x78a680: b.ne            #0x78a720
    // 0x78a684: ldr             x0, [fp, #0x18]
    // 0x78a688: LoadField: r3 = r0->field_5f
    //     0x78a688: ldur            w3, [x0, #0x5f]
    // 0x78a68c: DecompressPointer r3
    //     0x78a68c: add             x3, x3, HEAP, lsl #32
    // 0x78a690: LoadField: d1 = r3->field_7
    //     0x78a690: ldur            d1, [x3, #7]
    // 0x78a694: fcmp            d1, d0
    // 0x78a698: b.vs            #0x78a6a8
    // 0x78a69c: b.ne            #0x78a6a8
    // 0x78a6a0: d0 = 0.000000
    //     0x78a6a0: eor             v0.16b, v0.16b, v0.16b
    // 0x78a6a4: b               #0x78a6c0
    // 0x78a6a8: fcmp            d1, d0
    // 0x78a6ac: b.vs            #0x78a6bc
    // 0x78a6b0: b.ge            #0x78a6bc
    // 0x78a6b4: fneg            d0, d1
    // 0x78a6b8: b               #0x78a6c0
    // 0x78a6bc: mov             v0.16b, v1.16b
    // 0x78a6c0: LoadField: r3 = r1->field_7
    //     0x78a6c0: ldur            x3, [x1, #7]
    // 0x78a6c4: cmp             x3, #2
    // 0x78a6c8: b.gt            #0x78a6e4
    // 0x78a6cc: cmp             x3, #1
    // 0x78a6d0: b.gt            #0x78a6e4
    // 0x78a6d4: cmp             x3, #0
    // 0x78a6d8: b.le            #0x78a6e4
    // 0x78a6dc: d1 = 1.000000
    //     0x78a6dc: fmov            d1, #1.00000000
    // 0x78a6e0: b               #0x78a710
    // 0x78a6e4: cmp             w2, NULL
    // 0x78a6e8: b.ne            #0x78a6f4
    // 0x78a6ec: r1 = Null
    //     0x78a6ec: mov             x1, NULL
    // 0x78a6f0: b               #0x78a6fc
    // 0x78a6f4: LoadField: r1 = r2->field_7
    //     0x78a6f4: ldur            w1, [x2, #7]
    // 0x78a6f8: DecompressPointer r1
    //     0x78a6f8: add             x1, x1, HEAP, lsl #32
    // 0x78a6fc: cmp             w1, NULL
    // 0x78a700: b.ne            #0x78a70c
    // 0x78a704: d1 = 18.000000
    //     0x78a704: fmov            d1, #18.00000000
    // 0x78a708: b               #0x78a710
    // 0x78a70c: LoadField: d1 = r1->field_7
    //     0x78a70c: ldur            d1, [x1, #7]
    // 0x78a710: fcmp            d0, d1
    // 0x78a714: b.vs            #0x78a7cc
    // 0x78a718: b.le            #0x78a7cc
    // 0x78a71c: b               #0x78a7b8
    // 0x78a720: ldr             x0, [fp, #0x18]
    // 0x78a724: LoadField: r3 = r0->field_5f
    //     0x78a724: ldur            w3, [x0, #0x5f]
    // 0x78a728: DecompressPointer r3
    //     0x78a728: add             x3, x3, HEAP, lsl #32
    // 0x78a72c: LoadField: d1 = r3->field_7
    //     0x78a72c: ldur            d1, [x3, #7]
    // 0x78a730: fcmp            d1, d0
    // 0x78a734: b.vs            #0x78a744
    // 0x78a738: b.ne            #0x78a744
    // 0x78a73c: d0 = 0.000000
    //     0x78a73c: eor             v0.16b, v0.16b, v0.16b
    // 0x78a740: b               #0x78a75c
    // 0x78a744: fcmp            d1, d0
    // 0x78a748: b.vs            #0x78a758
    // 0x78a74c: b.ge            #0x78a758
    // 0x78a750: fneg            d0, d1
    // 0x78a754: b               #0x78a75c
    // 0x78a758: mov             v0.16b, v1.16b
    // 0x78a75c: LoadField: r3 = r1->field_7
    //     0x78a75c: ldur            x3, [x1, #7]
    // 0x78a760: cmp             x3, #2
    // 0x78a764: b.gt            #0x78a780
    // 0x78a768: cmp             x3, #1
    // 0x78a76c: b.gt            #0x78a780
    // 0x78a770: cmp             x3, #0
    // 0x78a774: b.le            #0x78a780
    // 0x78a778: d1 = 1.000000
    //     0x78a778: fmov            d1, #1.00000000
    // 0x78a77c: b               #0x78a7ac
    // 0x78a780: cmp             w2, NULL
    // 0x78a784: b.ne            #0x78a790
    // 0x78a788: r1 = Null
    //     0x78a788: mov             x1, NULL
    // 0x78a78c: b               #0x78a798
    // 0x78a790: LoadField: r1 = r2->field_7
    //     0x78a790: ldur            w1, [x2, #7]
    // 0x78a794: DecompressPointer r1
    //     0x78a794: add             x1, x1, HEAP, lsl #32
    // 0x78a798: cmp             w1, NULL
    // 0x78a79c: b.ne            #0x78a7a8
    // 0x78a7a0: d1 = 18.000000
    //     0x78a7a0: fmov            d1, #18.00000000
    // 0x78a7a4: b               #0x78a7ac
    // 0x78a7a8: LoadField: d1 = r1->field_7
    //     0x78a7a8: ldur            d1, [x1, #7]
    // 0x78a7ac: fcmp            d0, d1
    // 0x78a7b0: b.vs            #0x78a7cc
    // 0x78a7b4: b.le            #0x78a7cc
    // 0x78a7b8: r16 = Instance_GestureDisposition
    //     0x78a7b8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0x78a7bc: ldr             x16, [x16, #0xed0]
    // 0x78a7c0: stp             x16, x0, [SP, #-0x10]!
    // 0x78a7c4: r0 = resolve()
    //     0x78a7c4: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x78a7c8: add             SP, SP, #0x10
    // 0x78a7cc: ldr             x0, [fp, #0x10]
    // 0x78a7d0: r2 = Null
    //     0x78a7d0: mov             x2, NULL
    // 0x78a7d4: r1 = Null
    //     0x78a7d4: mov             x1, NULL
    // 0x78a7d8: cmp             w0, NULL
    // 0x78a7dc: b.eq            #0x78a7fc
    // 0x78a7e0: branchIfSmi(r0, 0x78a7fc)
    //     0x78a7e0: tbz             w0, #0, #0x78a7fc
    // 0x78a7e4: r3 = LoadClassIdInstr(r0)
    //     0x78a7e4: ldur            x3, [x0, #-1]
    //     0x78a7e8: ubfx            x3, x3, #0xc, #0x14
    // 0x78a7ec: cmp             x3, #0x906
    // 0x78a7f0: b.eq            #0x78a804
    // 0x78a7f4: cmp             x3, #0xb3d
    // 0x78a7f8: b.eq            #0x78a804
    // 0x78a7fc: r0 = false
    //     0x78a7fc: add             x0, NULL, #0x30  ; false
    // 0x78a800: b               #0x78a808
    // 0x78a804: r0 = true
    //     0x78a804: add             x0, NULL, #0x20  ; true
    // 0x78a808: tbz             w0, #4, #0x78a88c
    // 0x78a80c: ldr             x0, [fp, #0x10]
    // 0x78a810: r2 = Null
    //     0x78a810: mov             x2, NULL
    // 0x78a814: r1 = Null
    //     0x78a814: mov             x1, NULL
    // 0x78a818: cmp             w0, NULL
    // 0x78a81c: b.eq            #0x78a83c
    // 0x78a820: branchIfSmi(r0, 0x78a83c)
    //     0x78a820: tbz             w0, #0, #0x78a83c
    // 0x78a824: r3 = LoadClassIdInstr(r0)
    //     0x78a824: ldur            x3, [x0, #-1]
    //     0x78a828: ubfx            x3, x3, #0xc, #0x14
    // 0x78a82c: cmp             x3, #0x8f8
    // 0x78a830: b.eq            #0x78a844
    // 0x78a834: cmp             x3, #0xb35
    // 0x78a838: b.eq            #0x78a844
    // 0x78a83c: r0 = false
    //     0x78a83c: add             x0, NULL, #0x30  ; false
    // 0x78a840: b               #0x78a848
    // 0x78a844: r0 = true
    //     0x78a844: add             x0, NULL, #0x20  ; true
    // 0x78a848: tbz             w0, #4, #0x78a88c
    // 0x78a84c: ldr             x0, [fp, #0x10]
    // 0x78a850: r2 = Null
    //     0x78a850: mov             x2, NULL
    // 0x78a854: r1 = Null
    //     0x78a854: mov             x1, NULL
    // 0x78a858: cmp             w0, NULL
    // 0x78a85c: b.eq            #0x78a87c
    // 0x78a860: branchIfSmi(r0, 0x78a87c)
    //     0x78a860: tbz             w0, #0, #0x78a87c
    // 0x78a864: r3 = LoadClassIdInstr(r0)
    //     0x78a864: ldur            x3, [x0, #-1]
    //     0x78a868: ubfx            x3, x3, #0xc, #0x14
    // 0x78a86c: cmp             x3, #0x8fa
    // 0x78a870: b.eq            #0x78a884
    // 0x78a874: cmp             x3, #0xb37
    // 0x78a878: b.eq            #0x78a884
    // 0x78a87c: r0 = false
    //     0x78a87c: add             x0, NULL, #0x30  ; false
    // 0x78a880: b               #0x78a888
    // 0x78a884: r0 = true
    //     0x78a884: add             x0, NULL, #0x20  ; true
    // 0x78a888: tbnz            w0, #4, #0x78a8c0
    // 0x78a88c: ldr             x0, [fp, #0x10]
    // 0x78a890: r1 = LoadClassIdInstr(r0)
    //     0x78a890: ldur            x1, [x0, #-1]
    //     0x78a894: ubfx            x1, x1, #0xc, #0x14
    // 0x78a898: SaveReg r0
    //     0x78a898: str             x0, [SP, #-8]!
    // 0x78a89c: mov             x0, x1
    // 0x78a8a0: r0 = GDT[cid_x0 + -0xfff]()
    //     0x78a8a0: sub             lr, x0, #0xfff
    //     0x78a8a4: ldr             lr, [x21, lr, lsl #3]
    //     0x78a8a8: blr             lr
    // 0x78a8ac: add             SP, SP, #8
    // 0x78a8b0: ldr             x16, [fp, #0x18]
    // 0x78a8b4: stp             x0, x16, [SP, #-0x10]!
    // 0x78a8b8: r0 = _giveUpPointer()
    //     0x78a8b8: bl              #0x78ac04  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_giveUpPointer
    // 0x78a8bc: add             SP, SP, #0x10
    // 0x78a8c0: r0 = Null
    //     0x78a8c0: mov             x0, NULL
    // 0x78a8c4: LeaveFrame
    //     0x78a8c4: mov             SP, fp
    //     0x78a8c8: ldp             fp, lr, [SP], #0x10
    // 0x78a8cc: ret
    //     0x78a8cc: ret             
    // 0x78a8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78a8d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78a8d4: b               #0x789814
    // 0x78a8d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78a8d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78a8dc: SaveReg d0
    //     0x78a8dc: str             q0, [SP, #-0x10]!
    // 0x78a8e0: SaveReg r1
    //     0x78a8e0: str             x1, [SP, #-8]!
    // 0x78a8e4: r0 = AllocateDouble()
    //     0x78a8e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78a8e8: RestoreReg r1
    //     0x78a8e8: ldr             x1, [SP], #8
    // 0x78a8ec: RestoreReg d0
    //     0x78a8ec: ldr             q0, [SP], #0x10
    // 0x78a8f0: b               #0x78a1fc
    // 0x78a8f4: SaveReg d0
    //     0x78a8f4: str             q0, [SP, #-0x10]!
    // 0x78a8f8: SaveReg r1
    //     0x78a8f8: str             x1, [SP, #-8]!
    // 0x78a8fc: r0 = AllocateDouble()
    //     0x78a8fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78a900: RestoreReg r1
    //     0x78a900: ldr             x1, [SP], #8
    // 0x78a904: RestoreReg d0
    //     0x78a904: ldr             q0, [SP], #0x10
    // 0x78a908: b               #0x78a230
    // 0x78a90c: r9 = _pendingDragOffset
    //     0x78a90c: add             x9, PP, #0x28, lsl #12  ; [pp+0x28f18] Field <DragGestureRecognizer._pendingDragOffset@666099969>: late (offset: 0x50)
    //     0x78a910: ldr             x9, [x9, #0xf18]
    // 0x78a914: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x78a914: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x78a918: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78a918: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x78a91c: r9 = _globalDistanceMoved
    //     0x78a91c: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e908] Field <DragGestureRecognizer._globalDistanceMoved@666099969>: late (offset: 0x60)
    //     0x78a920: ldr             x9, [x9, #0x908]
    // 0x78a924: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x78a924: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x78a928: stp             q0, q1, [SP, #-0x20]!
    // 0x78a92c: SaveReg r1
    //     0x78a92c: str             x1, [SP, #-8]!
    // 0x78a930: r0 = AllocateDouble()
    //     0x78a930: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78a934: RestoreReg r1
    //     0x78a934: ldr             x1, [SP], #8
    // 0x78a938: ldp             q0, q1, [SP], #0x20
    // 0x78a93c: b               #0x78a4ec
    // 0x78a940: stp             q0, q1, [SP, #-0x20]!
    // 0x78a944: SaveReg r1
    //     0x78a944: str             x1, [SP, #-8]!
    // 0x78a948: r0 = AllocateDouble()
    //     0x78a948: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78a94c: RestoreReg r1
    //     0x78a94c: ldr             x1, [SP], #8
    // 0x78a950: ldp             q0, q1, [SP], #0x20
    // 0x78a954: b               #0x78a520
    // 0x78a958: stp             q0, q2, [SP, #-0x20]!
    // 0x78a95c: stp             x2, x3, [SP, #-0x10]!
    // 0x78a960: SaveReg r1
    //     0x78a960: str             x1, [SP, #-8]!
    // 0x78a964: r0 = AllocateDouble()
    //     0x78a964: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x78a968: RestoreReg r1
    //     0x78a968: ldr             x1, [SP], #8
    // 0x78a96c: ldp             x2, x3, [SP], #0x10
    // 0x78a970: ldp             q0, q2, [SP], #0x20
    // 0x78a974: b               #0x78a5a8
    // 0x78a978: r0 = NullErrorSharedWithoutFPURegs()
    //     0x78a978: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _checkUpdate(/* No info */) {
    // ** addr: 0x78aac8, size: 0xcc
    // 0x78aac8: EnterFrame
    //     0x78aac8: stp             fp, lr, [SP, #-0x10]!
    //     0x78aacc: mov             fp, SP
    // 0x78aad0: AllocStack(0x8)
    //     0x78aad0: sub             SP, SP, #8
    // 0x78aad4: CheckStackOverflow
    //     0x78aad4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78aad8: cmp             SP, x16
    //     0x78aadc: b.ls            #0x78ab8c
    // 0x78aae0: r1 = 2
    //     0x78aae0: mov             x1, #2
    // 0x78aae4: r0 = AllocateContext()
    //     0x78aae4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x78aae8: mov             x1, x0
    // 0x78aaec: ldr             x0, [fp, #0x38]
    // 0x78aaf0: stur            x1, [fp, #-8]
    // 0x78aaf4: StoreField: r1->field_f = r0
    //     0x78aaf4: stur            w0, [x1, #0xf]
    // 0x78aaf8: LoadField: r2 = r0->field_2b
    //     0x78aaf8: ldur            w2, [x0, #0x2b]
    // 0x78aafc: DecompressPointer r2
    //     0x78aafc: add             x2, x2, HEAP, lsl #32
    // 0x78ab00: cmp             w2, NULL
    // 0x78ab04: b.eq            #0x78ab7c
    // 0x78ab08: ldr             x6, [fp, #0x30]
    // 0x78ab0c: ldr             x5, [fp, #0x28]
    // 0x78ab10: ldr             x4, [fp, #0x20]
    // 0x78ab14: ldr             x3, [fp, #0x18]
    // 0x78ab18: ldr             x2, [fp, #0x10]
    // 0x78ab1c: r0 = DragUpdateDetails()
    //     0x78ab1c: bl              #0x64e814  ; AllocateDragUpdateDetailsStub -> DragUpdateDetails (size=0x1c)
    // 0x78ab20: mov             x1, x0
    // 0x78ab24: ldr             x0, [fp, #0x10]
    // 0x78ab28: StoreField: r1->field_7 = r0
    //     0x78ab28: stur            w0, [x1, #7]
    // 0x78ab2c: ldr             x0, [fp, #0x30]
    // 0x78ab30: StoreField: r1->field_b = r0
    //     0x78ab30: stur            w0, [x1, #0xb]
    // 0x78ab34: ldr             x0, [fp, #0x18]
    // 0x78ab38: StoreField: r1->field_f = r0
    //     0x78ab38: stur            w0, [x1, #0xf]
    // 0x78ab3c: ldr             x0, [fp, #0x28]
    // 0x78ab40: StoreField: r1->field_13 = r0
    //     0x78ab40: stur            w0, [x1, #0x13]
    // 0x78ab44: ldr             x0, [fp, #0x20]
    // 0x78ab48: StoreField: r1->field_17 = r0
    //     0x78ab48: stur            w0, [x1, #0x17]
    // 0x78ab4c: ldur            x2, [fp, #-8]
    // 0x78ab50: StoreField: r2->field_13 = r1
    //     0x78ab50: stur            w1, [x2, #0x13]
    // 0x78ab54: r1 = Function '<anonymous closure>':.
    //     0x78ab54: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f30] AnonymousClosure: (0x78ab94), in [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkUpdate (0x78aac8)
    //     0x78ab58: ldr             x1, [x1, #0xf30]
    // 0x78ab5c: r0 = AllocateClosure()
    //     0x78ab5c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x78ab60: r16 = <void?>
    //     0x78ab60: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x78ab64: ldr             lr, [fp, #0x38]
    // 0x78ab68: stp             lr, x16, [SP, #-0x10]!
    // 0x78ab6c: SaveReg r0
    //     0x78ab6c: str             x0, [SP, #-8]!
    // 0x78ab70: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x78ab70: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x78ab74: r0 = invokeCallback()
    //     0x78ab74: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0x78ab78: add             SP, SP, #0x18
    // 0x78ab7c: r0 = Null
    //     0x78ab7c: mov             x0, NULL
    // 0x78ab80: LeaveFrame
    //     0x78ab80: mov             SP, fp
    //     0x78ab84: ldp             fp, lr, [SP], #0x10
    // 0x78ab88: ret
    //     0x78ab88: ret             
    // 0x78ab8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78ab8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78ab90: b               #0x78aae0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x78ab94, size: 0x70
    // 0x78ab94: EnterFrame
    //     0x78ab94: stp             fp, lr, [SP, #-0x10]!
    //     0x78ab98: mov             fp, SP
    // 0x78ab9c: ldr             x0, [fp, #0x10]
    // 0x78aba0: LoadField: r1 = r0->field_17
    //     0x78aba0: ldur            w1, [x0, #0x17]
    // 0x78aba4: DecompressPointer r1
    //     0x78aba4: add             x1, x1, HEAP, lsl #32
    // 0x78aba8: CheckStackOverflow
    //     0x78aba8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78abac: cmp             SP, x16
    //     0x78abb0: b.ls            #0x78abf8
    // 0x78abb4: LoadField: r0 = r1->field_f
    //     0x78abb4: ldur            w0, [x1, #0xf]
    // 0x78abb8: DecompressPointer r0
    //     0x78abb8: add             x0, x0, HEAP, lsl #32
    // 0x78abbc: LoadField: r2 = r0->field_2b
    //     0x78abbc: ldur            w2, [x0, #0x2b]
    // 0x78abc0: DecompressPointer r2
    //     0x78abc0: add             x2, x2, HEAP, lsl #32
    // 0x78abc4: cmp             w2, NULL
    // 0x78abc8: b.eq            #0x78ac00
    // 0x78abcc: LoadField: r0 = r1->field_13
    //     0x78abcc: ldur            w0, [x1, #0x13]
    // 0x78abd0: DecompressPointer r0
    //     0x78abd0: add             x0, x0, HEAP, lsl #32
    // 0x78abd4: stp             x0, x2, [SP, #-0x10]!
    // 0x78abd8: mov             x0, x2
    // 0x78abdc: ClosureCall
    //     0x78abdc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x78abe0: ldur            x2, [x0, #0x1f]
    //     0x78abe4: blr             x2
    // 0x78abe8: add             SP, SP, #0x10
    // 0x78abec: LeaveFrame
    //     0x78abec: mov             SP, fp
    //     0x78abf0: ldp             fp, lr, [SP], #0x10
    // 0x78abf4: ret
    //     0x78abf4: ret             
    // 0x78abf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78abf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78abfc: b               #0x78abb4
    // 0x78ac00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x78ac00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _giveUpPointer(/* No info */) {
    // ** addr: 0x78ac04, size: 0x90
    // 0x78ac04: EnterFrame
    //     0x78ac04: stp             fp, lr, [SP, #-0x10]!
    //     0x78ac08: mov             fp, SP
    // 0x78ac0c: AllocStack(0x8)
    //     0x78ac0c: sub             SP, SP, #8
    // 0x78ac10: CheckStackOverflow
    //     0x78ac10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x78ac14: cmp             SP, x16
    //     0x78ac18: b.ls            #0x78ac8c
    // 0x78ac1c: ldr             x2, [fp, #0x10]
    // 0x78ac20: r0 = BoxInt64Instr(r2)
    //     0x78ac20: sbfiz           x0, x2, #1, #0x1f
    //     0x78ac24: cmp             x2, x0, asr #1
    //     0x78ac28: b.eq            #0x78ac34
    //     0x78ac2c: bl              #0xd69bb8
    //     0x78ac30: stur            x2, [x0, #7]
    // 0x78ac34: stur            x0, [fp, #-8]
    // 0x78ac38: ldr             x16, [fp, #0x18]
    // 0x78ac3c: stp             x0, x16, [SP, #-0x10]!
    // 0x78ac40: r0 = stopTrackingPointer()
    //     0x78ac40: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0x78ac44: add             SP, SP, #0x10
    // 0x78ac48: ldr             x0, [fp, #0x18]
    // 0x78ac4c: LoadField: r1 = r0->field_67
    //     0x78ac4c: ldur            w1, [x0, #0x67]
    // 0x78ac50: DecompressPointer r1
    //     0x78ac50: add             x1, x1, HEAP, lsl #32
    // 0x78ac54: ldur            x16, [fp, #-8]
    // 0x78ac58: stp             x16, x1, [SP, #-0x10]!
    // 0x78ac5c: r0 = remove()
    //     0x78ac5c: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x78ac60: add             SP, SP, #0x10
    // 0x78ac64: tbz             w0, #4, #0x78ac7c
    // 0x78ac68: ldr             x0, [fp, #0x10]
    // 0x78ac6c: ldr             x16, [fp, #0x18]
    // 0x78ac70: stp             x0, x16, [SP, #-0x10]!
    // 0x78ac74: r0 = resolvePointer()
    //     0x78ac74: bl              #0x788bec  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolvePointer
    // 0x78ac78: add             SP, SP, #0x10
    // 0x78ac7c: r0 = Null
    //     0x78ac7c: mov             x0, NULL
    // 0x78ac80: LeaveFrame
    //     0x78ac80: mov             SP, fp
    //     0x78ac84: ldp             fp, lr, [SP], #0x10
    // 0x78ac88: ret
    //     0x78ac88: ret             
    // 0x78ac8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x78ac8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x78ac90: b               #0x78ac1c
  }
  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xa82820, size: 0x1c0
    // 0xa82820: EnterFrame
    //     0xa82820: stp             fp, lr, [SP, #-0x10]!
    //     0xa82824: mov             fp, SP
    // 0xa82828: CheckStackOverflow
    //     0xa82828: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8282c: cmp             SP, x16
    //     0xa82830: b.ls            #0xa829d8
    // 0xa82834: ldr             x1, [fp, #0x18]
    // 0xa82838: LoadField: r0 = r1->field_57
    //     0xa82838: ldur            w0, [x1, #0x57]
    // 0xa8283c: DecompressPointer r0
    //     0xa8283c: add             x0, x0, HEAP, lsl #32
    // 0xa82840: cmp             w0, NULL
    // 0xa82844: b.ne            #0xa82924
    // 0xa82848: ldr             x2, [fp, #0x10]
    // 0xa8284c: r0 = LoadClassIdInstr(r2)
    //     0xa8284c: ldur            x0, [x2, #-1]
    //     0xa82850: ubfx            x0, x0, #0xc, #0x14
    // 0xa82854: SaveReg r2
    //     0xa82854: str             x2, [SP, #-8]!
    // 0xa82858: r0 = GDT[cid_x0 + 0x271c]()
    //     0xa82858: mov             x17, #0x271c
    //     0xa8285c: add             lr, x0, x17
    //     0xa82860: ldr             lr, [x21, lr, lsl #3]
    //     0xa82864: blr             lr
    // 0xa82868: add             SP, SP, #8
    // 0xa8286c: mov             x2, x0
    // 0xa82870: r0 = BoxInt64Instr(r2)
    //     0xa82870: sbfiz           x0, x2, #1, #0x1f
    //     0xa82874: cmp             x2, x0, asr #1
    //     0xa82878: b.eq            #0xa82884
    //     0xa8287c: bl              #0xd69bb8
    //     0xa82880: stur            x2, [x0, #7]
    // 0xa82884: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xa82884: mov             x1, #0x76
    //     0xa82888: tbz             w0, #0, #0xa82898
    //     0xa8288c: ldur            x1, [x0, #-1]
    //     0xa82890: ubfx            x1, x1, #0xc, #0x14
    //     0xa82894: lsl             x1, x1, #1
    // 0xa82898: cmp             w1, #0x76
    // 0xa8289c: b.ne            #0xa82914
    // 0xa828a0: cmp             w0, #2
    // 0xa828a4: b.ne            #0xa82914
    // 0xa828a8: ldr             x1, [fp, #0x18]
    // 0xa828ac: LoadField: r0 = r1->field_23
    //     0xa828ac: ldur            w0, [x1, #0x23]
    // 0xa828b0: DecompressPointer r0
    //     0xa828b0: add             x0, x0, HEAP, lsl #32
    // 0xa828b4: cmp             w0, NULL
    // 0xa828b8: b.ne            #0xa8290c
    // 0xa828bc: LoadField: r0 = r1->field_27
    //     0xa828bc: ldur            w0, [x1, #0x27]
    // 0xa828c0: DecompressPointer r0
    //     0xa828c0: add             x0, x0, HEAP, lsl #32
    // 0xa828c4: cmp             w0, NULL
    // 0xa828c8: b.ne            #0xa8290c
    // 0xa828cc: LoadField: r0 = r1->field_2b
    //     0xa828cc: ldur            w0, [x1, #0x2b]
    // 0xa828d0: DecompressPointer r0
    //     0xa828d0: add             x0, x0, HEAP, lsl #32
    // 0xa828d4: cmp             w0, NULL
    // 0xa828d8: b.ne            #0xa8290c
    // 0xa828dc: LoadField: r0 = r1->field_2f
    //     0xa828dc: ldur            w0, [x1, #0x2f]
    // 0xa828e0: DecompressPointer r0
    //     0xa828e0: add             x0, x0, HEAP, lsl #32
    // 0xa828e4: cmp             w0, NULL
    // 0xa828e8: b.ne            #0xa8290c
    // 0xa828ec: LoadField: r0 = r1->field_33
    //     0xa828ec: ldur            w0, [x1, #0x33]
    // 0xa828f0: DecompressPointer r0
    //     0xa828f0: add             x0, x0, HEAP, lsl #32
    // 0xa828f4: cmp             w0, NULL
    // 0xa828f8: b.ne            #0xa8290c
    // 0xa828fc: r0 = false
    //     0xa828fc: add             x0, NULL, #0x30  ; false
    // 0xa82900: LeaveFrame
    //     0xa82900: mov             SP, fp
    //     0xa82904: ldp             fp, lr, [SP], #0x10
    // 0xa82908: ret
    //     0xa82908: ret             
    // 0xa8290c: mov             x2, x1
    // 0xa82910: b               #0xa829bc
    // 0xa82914: r0 = false
    //     0xa82914: add             x0, NULL, #0x30  ; false
    // 0xa82918: LeaveFrame
    //     0xa82918: mov             SP, fp
    //     0xa8291c: ldp             fp, lr, [SP], #0x10
    // 0xa82920: ret
    //     0xa82920: ret             
    // 0xa82924: ldr             x2, [fp, #0x10]
    // 0xa82928: r0 = LoadClassIdInstr(r2)
    //     0xa82928: ldur            x0, [x2, #-1]
    //     0xa8292c: ubfx            x0, x0, #0xc, #0x14
    // 0xa82930: SaveReg r2
    //     0xa82930: str             x2, [SP, #-8]!
    // 0xa82934: r0 = GDT[cid_x0 + 0x271c]()
    //     0xa82934: mov             x17, #0x271c
    //     0xa82938: add             lr, x0, x17
    //     0xa8293c: ldr             lr, [x21, lr, lsl #3]
    //     0xa82940: blr             lr
    // 0xa82944: add             SP, SP, #8
    // 0xa82948: mov             x3, x0
    // 0xa8294c: ldr             x2, [fp, #0x18]
    // 0xa82950: LoadField: r4 = r2->field_57
    //     0xa82950: ldur            w4, [x2, #0x57]
    // 0xa82954: DecompressPointer r4
    //     0xa82954: add             x4, x4, HEAP, lsl #32
    // 0xa82958: r0 = BoxInt64Instr(r3)
    //     0xa82958: sbfiz           x0, x3, #1, #0x1f
    //     0xa8295c: cmp             x3, x0, asr #1
    //     0xa82960: b.eq            #0xa8296c
    //     0xa82964: bl              #0xd69bb8
    //     0xa82968: stur            x3, [x0, #7]
    // 0xa8296c: cmp             w0, w4
    // 0xa82970: b.eq            #0xa829bc
    // 0xa82974: and             w16, w0, w4
    // 0xa82978: branchIfSmi(r16, 0xa829ac)
    //     0xa82978: tbz             w16, #0, #0xa829ac
    // 0xa8297c: r16 = LoadClassIdInstr(r0)
    //     0xa8297c: ldur            x16, [x0, #-1]
    //     0xa82980: ubfx            x16, x16, #0xc, #0x14
    // 0xa82984: cmp             x16, #0x3c
    // 0xa82988: b.ne            #0xa829ac
    // 0xa8298c: r16 = LoadClassIdInstr(r4)
    //     0xa8298c: ldur            x16, [x4, #-1]
    //     0xa82990: ubfx            x16, x16, #0xc, #0x14
    // 0xa82994: cmp             x16, #0x3c
    // 0xa82998: b.ne            #0xa829ac
    // 0xa8299c: LoadField: r16 = r0->field_7
    //     0xa8299c: ldur            x16, [x0, #7]
    // 0xa829a0: LoadField: r17 = r4->field_7
    //     0xa829a0: ldur            x17, [x4, #7]
    // 0xa829a4: cmp             x16, x17
    // 0xa829a8: b.eq            #0xa829bc
    // 0xa829ac: r0 = false
    //     0xa829ac: add             x0, NULL, #0x30  ; false
    // 0xa829b0: LeaveFrame
    //     0xa829b0: mov             SP, fp
    //     0xa829b4: ldp             fp, lr, [SP], #0x10
    // 0xa829b8: ret
    //     0xa829b8: ret             
    // 0xa829bc: ldr             x16, [fp, #0x10]
    // 0xa829c0: stp             x16, x2, [SP, #-0x10]!
    // 0xa829c4: r0 = isPointerAllowed()
    //     0xa829c4: bl              #0xa829e0  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xa829c8: add             SP, SP, #0x10
    // 0xa829cc: LeaveFrame
    //     0xa829cc: mov             SP, fp
    //     0xa829d0: ldp             fp, lr, [SP], #0x10
    // 0xa829d4: ret
    //     0xa829d4: ret             
    // 0xa829d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa829d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa829dc: b               #0xa82834
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbd92fc, size: 0x54
    // 0xbd92fc: EnterFrame
    //     0xbd92fc: stp             fp, lr, [SP, #-0x10]!
    //     0xbd9300: mov             fp, SP
    // 0xbd9304: CheckStackOverflow
    //     0xbd9304: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd9308: cmp             SP, x16
    //     0xbd930c: b.ls            #0xbd9348
    // 0xbd9310: ldr             x0, [fp, #0x10]
    // 0xbd9314: LoadField: r1 = r0->field_63
    //     0xbd9314: ldur            w1, [x0, #0x63]
    // 0xbd9318: DecompressPointer r1
    //     0xbd9318: add             x1, x1, HEAP, lsl #32
    // 0xbd931c: SaveReg r1
    //     0xbd931c: str             x1, [SP, #-8]!
    // 0xbd9320: r0 = clear()
    //     0xbd9320: bl              #0x4e32e4  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xbd9324: add             SP, SP, #8
    // 0xbd9328: ldr             x16, [fp, #0x10]
    // 0xbd932c: SaveReg r16
    //     0xbd932c: str             x16, [SP, #-8]!
    // 0xbd9330: r0 = dispose()
    //     0xbd9330: bl              #0xbd93a4  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::dispose
    // 0xbd9334: add             SP, SP, #8
    // 0xbd9338: r0 = Null
    //     0xbd9338: mov             x0, NULL
    // 0xbd933c: LeaveFrame
    //     0xbd933c: mov             SP, fp
    //     0xbd9340: ldp             fp, lr, [SP], #0x10
    // 0xbd9344: ret
    //     0xbd9344: ret             
    // 0xbd9348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd9348: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd934c: b               #0xbd9310
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdb470, size: 0x3e4
    // 0xbdb470: EnterFrame
    //     0xbdb470: stp             fp, lr, [SP, #-0x10]!
    //     0xbdb474: mov             fp, SP
    // 0xbdb478: AllocStack(0x20)
    //     0xbdb478: sub             SP, SP, #0x20
    // 0xbdb47c: CheckStackOverflow
    //     0xbdb47c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdb480: cmp             SP, x16
    //     0xbdb484: b.ls            #0xbdb7dc
    // 0xbdb488: ldr             x2, [fp, #0x18]
    // 0xbdb48c: LoadField: r3 = r2->field_67
    //     0xbdb48c: ldur            w3, [x2, #0x67]
    // 0xbdb490: DecompressPointer r3
    //     0xbdb490: add             x3, x3, HEAP, lsl #32
    // 0xbdb494: ldr             x4, [fp, #0x10]
    // 0xbdb498: r0 = BoxInt64Instr(r4)
    //     0xbdb498: sbfiz           x0, x4, #1, #0x1f
    //     0xbdb49c: cmp             x4, x0, asr #1
    //     0xbdb4a0: b.eq            #0xbdb4ac
    //     0xbdb4a4: bl              #0xd69bb8
    //     0xbdb4a8: stur            x4, [x0, #7]
    // 0xbdb4ac: stp             x0, x3, [SP, #-0x10]!
    // 0xbdb4b0: r0 = add()
    //     0xbdb4b0: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xbdb4b4: add             SP, SP, #0x10
    // 0xbdb4b8: ldr             x0, [fp, #0x18]
    // 0xbdb4bc: LoadField: r1 = r0->field_47
    //     0xbdb4bc: ldur            w1, [x0, #0x47]
    // 0xbdb4c0: DecompressPointer r1
    //     0xbdb4c0: add             x1, x1, HEAP, lsl #32
    // 0xbdb4c4: r16 = Instance__DragState
    //     0xbdb4c4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f08] Obj!_DragState@b65b71
    //     0xbdb4c8: ldr             x16, [x16, #0xf08]
    // 0xbdb4cc: cmp             w1, w16
    // 0xbdb4d0: b.eq            #0xbdb7cc
    // 0xbdb4d4: r1 = Instance__DragState
    //     0xbdb4d4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f08] Obj!_DragState@b65b71
    //     0xbdb4d8: ldr             x1, [x1, #0xf08]
    // 0xbdb4dc: StoreField: r0->field_47 = r1
    //     0xbdb4dc: stur            w1, [x0, #0x47]
    // 0xbdb4e0: LoadField: r1 = r0->field_4f
    //     0xbdb4e0: ldur            w1, [x0, #0x4f]
    // 0xbdb4e4: DecompressPointer r1
    //     0xbdb4e4: add             x1, x1, HEAP, lsl #32
    // 0xbdb4e8: r16 = Sentinel
    //     0xbdb4e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdb4ec: cmp             w1, w16
    // 0xbdb4f0: b.eq            #0xbdb7e4
    // 0xbdb4f4: LoadField: r2 = r0->field_53
    //     0xbdb4f4: ldur            w2, [x0, #0x53]
    // 0xbdb4f8: DecompressPointer r2
    //     0xbdb4f8: add             x2, x2, HEAP, lsl #32
    // 0xbdb4fc: stur            x2, [fp, #-0x10]
    // 0xbdb500: cmp             w2, NULL
    // 0xbdb504: b.eq            #0xbdb7f0
    // 0xbdb508: LoadField: r3 = r0->field_5b
    //     0xbdb508: ldur            w3, [x0, #0x5b]
    // 0xbdb50c: DecompressPointer r3
    //     0xbdb50c: add             x3, x3, HEAP, lsl #32
    // 0xbdb510: stur            x3, [fp, #-8]
    // 0xbdb514: LoadField: r4 = r0->field_1f
    //     0xbdb514: ldur            w4, [x0, #0x1f]
    // 0xbdb518: DecompressPointer r4
    //     0xbdb518: add             x4, x4, HEAP, lsl #32
    // 0xbdb51c: LoadField: r5 = r4->field_7
    //     0xbdb51c: ldur            x5, [x4, #7]
    // 0xbdb520: cmp             x5, #0
    // 0xbdb524: b.gt            #0xbdb5a8
    // 0xbdb528: LoadField: r4 = r1->field_7
    //     0xbdb528: ldur            w4, [x1, #7]
    // 0xbdb52c: DecompressPointer r4
    //     0xbdb52c: add             x4, x4, HEAP, lsl #32
    // 0xbdb530: r1 = LoadClassIdInstr(r0)
    //     0xbdb530: ldur            x1, [x0, #-1]
    //     0xbdb534: ubfx            x1, x1, #0xc, #0x14
    // 0xbdb538: lsl             x1, x1, #1
    // 0xbdb53c: r17 = 4706
    //     0xbdb53c: mov             x17, #0x1262
    // 0xbdb540: cmp             w1, w17
    // 0xbdb544: b.ne            #0xbdb550
    // 0xbdb548: mov             x0, x4
    // 0xbdb54c: b               #0xbdb59c
    // 0xbdb550: r17 = 4708
    //     0xbdb550: mov             x17, #0x1264
    // 0xbdb554: cmp             w1, w17
    // 0xbdb558: b.ne            #0xbdb57c
    // 0xbdb55c: LoadField: d0 = r4->field_7
    //     0xbdb55c: ldur            d0, [x4, #7]
    // 0xbdb560: stur            d0, [fp, #-0x20]
    // 0xbdb564: r0 = Offset()
    //     0xbdb564: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbdb568: ldur            d0, [fp, #-0x20]
    // 0xbdb56c: StoreField: r0->field_7 = d0
    //     0xbdb56c: stur            d0, [x0, #7]
    // 0xbdb570: d0 = 0.000000
    //     0xbdb570: eor             v0.16b, v0.16b, v0.16b
    // 0xbdb574: StoreField: r0->field_f = d0
    //     0xbdb574: stur            d0, [x0, #0xf]
    // 0xbdb578: b               #0xbdb59c
    // 0xbdb57c: d0 = 0.000000
    //     0xbdb57c: eor             v0.16b, v0.16b, v0.16b
    // 0xbdb580: LoadField: d1 = r4->field_f
    //     0xbdb580: ldur            d1, [x4, #0xf]
    // 0xbdb584: stur            d1, [fp, #-0x20]
    // 0xbdb588: r0 = Offset()
    //     0xbdb588: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbdb58c: d0 = 0.000000
    //     0xbdb58c: eor             v0.16b, v0.16b, v0.16b
    // 0xbdb590: StoreField: r0->field_7 = d0
    //     0xbdb590: stur            d0, [x0, #7]
    // 0xbdb594: ldur            d0, [fp, #-0x20]
    // 0xbdb598: StoreField: r0->field_f = d0
    //     0xbdb598: stur            d0, [x0, #0xf]
    // 0xbdb59c: mov             x3, x0
    // 0xbdb5a0: ldr             x1, [fp, #0x18]
    // 0xbdb5a4: b               #0xbdb5ec
    // 0xbdb5a8: LoadField: r2 = r0->field_4b
    //     0xbdb5a8: ldur            w2, [x0, #0x4b]
    // 0xbdb5ac: DecompressPointer r2
    //     0xbdb5ac: add             x2, x2, HEAP, lsl #32
    // 0xbdb5b0: r16 = Sentinel
    //     0xbdb5b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdb5b4: cmp             w2, w16
    // 0xbdb5b8: b.eq            #0xbdb7f4
    // 0xbdb5bc: stp             x1, x2, [SP, #-0x10]!
    // 0xbdb5c0: r0 = +()
    //     0xbdb5c0: bl              #0x714388  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xbdb5c4: add             SP, SP, #0x10
    // 0xbdb5c8: ldr             x1, [fp, #0x18]
    // 0xbdb5cc: StoreField: r1->field_4b = r0
    //     0xbdb5cc: stur            w0, [x1, #0x4b]
    //     0xbdb5d0: ldurb           w16, [x1, #-1]
    //     0xbdb5d4: ldurb           w17, [x0, #-1]
    //     0xbdb5d8: and             x16, x17, x16, lsr #2
    //     0xbdb5dc: tst             x16, HEAP, lsr #32
    //     0xbdb5e0: b.eq            #0xbdb5e8
    //     0xbdb5e4: bl              #0xd6826c
    // 0xbdb5e8: r3 = Instance_Offset
    //     0xbdb5e8: ldr             x3, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xbdb5ec: ldr             x0, [fp, #0x10]
    // 0xbdb5f0: r2 = Instance_OffsetPair
    //     0xbdb5f0: add             x2, PP, #0x28, lsl #12  ; [pp+0x28f10] Obj!OffsetPair@b38711
    //     0xbdb5f4: ldr             x2, [x2, #0xf10]
    // 0xbdb5f8: stur            x3, [fp, #-0x18]
    // 0xbdb5fc: StoreField: r1->field_4f = r2
    //     0xbdb5fc: stur            w2, [x1, #0x4f]
    // 0xbdb600: StoreField: r1->field_53 = rNULL
    //     0xbdb600: stur            NULL, [x1, #0x53]
    // 0xbdb604: StoreField: r1->field_5b = rNULL
    //     0xbdb604: stur            NULL, [x1, #0x5b]
    // 0xbdb608: ldur            x16, [fp, #-0x10]
    // 0xbdb60c: stp             x16, x1, [SP, #-0x10]!
    // 0xbdb610: SaveReg r0
    //     0xbdb610: str             x0, [SP, #-8]!
    // 0xbdb614: r0 = _checkStart()
    //     0xbdb614: bl              #0x7199ec  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkStart
    // 0xbdb618: add             SP, SP, #0x18
    // 0xbdb61c: ldur            x16, [fp, #-0x18]
    // 0xbdb620: r30 = Instance_Offset
    //     0xbdb620: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xbdb624: stp             lr, x16, [SP, #-0x10]!
    // 0xbdb628: r0 = ==()
    //     0xbdb628: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xbdb62c: add             SP, SP, #0x10
    // 0xbdb630: tbz             w0, #4, #0xbdb7b4
    // 0xbdb634: ldr             x0, [fp, #0x18]
    // 0xbdb638: LoadField: r1 = r0->field_2b
    //     0xbdb638: ldur            w1, [x0, #0x2b]
    // 0xbdb63c: DecompressPointer r1
    //     0xbdb63c: add             x1, x1, HEAP, lsl #32
    // 0xbdb640: cmp             w1, NULL
    // 0xbdb644: b.eq            #0xbdb7b4
    // 0xbdb648: ldur            x1, [fp, #-8]
    // 0xbdb64c: cmp             w1, NULL
    // 0xbdb650: b.eq            #0xbdb668
    // 0xbdb654: SaveReg r1
    //     0xbdb654: str             x1, [SP, #-8]!
    // 0xbdb658: r0 = tryInvert()
    //     0xbdb658: bl              #0x623294  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0xbdb65c: add             SP, SP, #8
    // 0xbdb660: mov             x2, x0
    // 0xbdb664: b               #0xbdb66c
    // 0xbdb668: r2 = Null
    //     0xbdb668: mov             x2, NULL
    // 0xbdb66c: ldr             x0, [fp, #0x18]
    // 0xbdb670: ldur            x1, [fp, #-0x18]
    // 0xbdb674: stur            x2, [fp, #-8]
    // 0xbdb678: LoadField: r3 = r0->field_4b
    //     0xbdb678: ldur            w3, [x0, #0x4b]
    // 0xbdb67c: DecompressPointer r3
    //     0xbdb67c: add             x3, x3, HEAP, lsl #32
    // 0xbdb680: r16 = Sentinel
    //     0xbdb680: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbdb684: cmp             w3, w16
    // 0xbdb688: b.eq            #0xbdb800
    // 0xbdb68c: LoadField: r4 = r3->field_7
    //     0xbdb68c: ldur            w4, [x3, #7]
    // 0xbdb690: DecompressPointer r4
    //     0xbdb690: add             x4, x4, HEAP, lsl #32
    // 0xbdb694: stp             x1, x4, [SP, #-0x10]!
    // 0xbdb698: r0 = +()
    //     0xbdb698: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xbdb69c: add             SP, SP, #0x10
    // 0xbdb6a0: ldur            x16, [fp, #-8]
    // 0xbdb6a4: ldur            lr, [fp, #-0x18]
    // 0xbdb6a8: stp             lr, x16, [SP, #-0x10]!
    // 0xbdb6ac: SaveReg r0
    //     0xbdb6ac: str             x0, [SP, #-8]!
    // 0xbdb6b0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xbdb6b0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xbdb6b4: r0 = transformDeltaViaPositions()
    //     0xbdb6b4: bl              #0x5b64a0  ; [package:flutter/src/gestures/events.dart] PointerEvent::transformDeltaViaPositions
    // 0xbdb6b8: add             SP, SP, #0x18
    // 0xbdb6bc: stur            x0, [fp, #-8]
    // 0xbdb6c0: r0 = OffsetPair()
    //     0xbdb6c0: bl              #0x7142f0  ; AllocateOffsetPairStub -> OffsetPair (size=0x10)
    // 0xbdb6c4: mov             x1, x0
    // 0xbdb6c8: ldur            x0, [fp, #-0x18]
    // 0xbdb6cc: StoreField: r1->field_7 = r0
    //     0xbdb6cc: stur            w0, [x1, #7]
    // 0xbdb6d0: ldur            x2, [fp, #-8]
    // 0xbdb6d4: StoreField: r1->field_b = r2
    //     0xbdb6d4: stur            w2, [x1, #0xb]
    // 0xbdb6d8: ldr             x2, [fp, #0x18]
    // 0xbdb6dc: LoadField: r3 = r2->field_4b
    //     0xbdb6dc: ldur            w3, [x2, #0x4b]
    // 0xbdb6e0: DecompressPointer r3
    //     0xbdb6e0: add             x3, x3, HEAP, lsl #32
    // 0xbdb6e4: stp             x1, x3, [SP, #-0x10]!
    // 0xbdb6e8: r0 = +()
    //     0xbdb6e8: bl              #0x714388  ; [package:flutter/src/gestures/recognizer.dart] OffsetPair::+
    // 0xbdb6ec: add             SP, SP, #0x10
    // 0xbdb6f0: mov             x1, x0
    // 0xbdb6f4: ldr             x0, [fp, #0x18]
    // 0xbdb6f8: r2 = LoadClassIdInstr(r0)
    //     0xbdb6f8: ldur            x2, [x0, #-1]
    //     0xbdb6fc: ubfx            x2, x2, #0xc, #0x14
    // 0xbdb700: lsl             x2, x2, #1
    // 0xbdb704: r17 = 4706
    //     0xbdb704: mov             x17, #0x1262
    // 0xbdb708: cmp             w2, w17
    // 0xbdb70c: b.ne            #0xbdb71c
    // 0xbdb710: ldur            x2, [fp, #-0x18]
    // 0xbdb714: r3 = Null
    //     0xbdb714: mov             x3, NULL
    // 0xbdb718: b               #0xbdb78c
    // 0xbdb71c: r17 = 4708
    //     0xbdb71c: mov             x17, #0x1264
    // 0xbdb720: cmp             w2, w17
    // 0xbdb724: b.ne            #0xbdb75c
    // 0xbdb728: ldur            x2, [fp, #-0x18]
    // 0xbdb72c: LoadField: d0 = r2->field_7
    //     0xbdb72c: ldur            d0, [x2, #7]
    // 0xbdb730: r3 = inline_Allocate_Double()
    //     0xbdb730: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbdb734: add             x3, x3, #0x10
    //     0xbdb738: cmp             x4, x3
    //     0xbdb73c: b.ls            #0xbdb80c
    //     0xbdb740: str             x3, [THR, #0x60]  ; THR::top
    //     0xbdb744: sub             x3, x3, #0xf
    //     0xbdb748: mov             x4, #0xd108
    //     0xbdb74c: movk            x4, #3, lsl #16
    //     0xbdb750: stur            x4, [x3, #-1]
    // 0xbdb754: StoreField: r3->field_7 = d0
    //     0xbdb754: stur            d0, [x3, #7]
    // 0xbdb758: b               #0xbdb78c
    // 0xbdb75c: ldur            x2, [fp, #-0x18]
    // 0xbdb760: LoadField: d0 = r2->field_f
    //     0xbdb760: ldur            d0, [x2, #0xf]
    // 0xbdb764: r3 = inline_Allocate_Double()
    //     0xbdb764: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbdb768: add             x3, x3, #0x10
    //     0xbdb76c: cmp             x4, x3
    //     0xbdb770: b.ls            #0xbdb830
    //     0xbdb774: str             x3, [THR, #0x60]  ; THR::top
    //     0xbdb778: sub             x3, x3, #0xf
    //     0xbdb77c: mov             x4, #0xd108
    //     0xbdb780: movk            x4, #3, lsl #16
    //     0xbdb784: stur            x4, [x3, #-1]
    // 0xbdb788: StoreField: r3->field_7 = d0
    //     0xbdb788: stur            d0, [x3, #7]
    // 0xbdb78c: LoadField: r4 = r1->field_b
    //     0xbdb78c: ldur            w4, [x1, #0xb]
    // 0xbdb790: DecompressPointer r4
    //     0xbdb790: add             x4, x4, HEAP, lsl #32
    // 0xbdb794: LoadField: r5 = r1->field_7
    //     0xbdb794: ldur            w5, [x1, #7]
    // 0xbdb798: DecompressPointer r5
    //     0xbdb798: add             x5, x5, HEAP, lsl #32
    // 0xbdb79c: stp             x2, x0, [SP, #-0x10]!
    // 0xbdb7a0: stp             x5, x4, [SP, #-0x10]!
    // 0xbdb7a4: ldur            x16, [fp, #-0x10]
    // 0xbdb7a8: stp             x16, x3, [SP, #-0x10]!
    // 0xbdb7ac: r0 = _checkUpdate()
    //     0xbdb7ac: bl              #0x78aac8  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_checkUpdate
    // 0xbdb7b0: add             SP, SP, #0x30
    // 0xbdb7b4: ldr             x16, [fp, #0x18]
    // 0xbdb7b8: r30 = Instance_GestureDisposition
    //     0xbdb7b8: add             lr, PP, #0x28, lsl #12  ; [pp+0x28ed0] Obj!GestureDisposition@b65c51
    //     0xbdb7bc: ldr             lr, [lr, #0xed0]
    // 0xbdb7c0: stp             lr, x16, [SP, #-0x10]!
    // 0xbdb7c4: r0 = resolve()
    //     0xbdb7c4: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xbdb7c8: add             SP, SP, #0x10
    // 0xbdb7cc: r0 = Null
    //     0xbdb7cc: mov             x0, NULL
    // 0xbdb7d0: LeaveFrame
    //     0xbdb7d0: mov             SP, fp
    //     0xbdb7d4: ldp             fp, lr, [SP], #0x10
    // 0xbdb7d8: ret
    //     0xbdb7d8: ret             
    // 0xbdb7dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdb7dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdb7e0: b               #0xbdb488
    // 0xbdb7e4: r9 = _pendingDragOffset
    //     0xbdb7e4: add             x9, PP, #0x28, lsl #12  ; [pp+0x28f18] Field <DragGestureRecognizer._pendingDragOffset@666099969>: late (offset: 0x50)
    //     0xbdb7e8: ldr             x9, [x9, #0xf18]
    // 0xbdb7ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdb7ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbdb7f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdb7f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbdb7f4: r9 = _initialPosition
    //     0xbdb7f4: add             x9, PP, #0x28, lsl #12  ; [pp+0x28f20] Field <DragGestureRecognizer._initialPosition@666099969>: late (offset: 0x4c)
    //     0xbdb7f8: ldr             x9, [x9, #0xf20]
    // 0xbdb7fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdb7fc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbdb800: r9 = _initialPosition
    //     0xbdb800: add             x9, PP, #0x28, lsl #12  ; [pp+0x28f20] Field <DragGestureRecognizer._initialPosition@666099969>: late (offset: 0x4c)
    //     0xbdb804: ldr             x9, [x9, #0xf20]
    // 0xbdb808: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbdb808: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbdb80c: SaveReg d0
    //     0xbdb80c: str             q0, [SP, #-0x10]!
    // 0xbdb810: stp             x1, x2, [SP, #-0x10]!
    // 0xbdb814: SaveReg r0
    //     0xbdb814: str             x0, [SP, #-8]!
    // 0xbdb818: r0 = AllocateDouble()
    //     0xbdb818: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbdb81c: mov             x3, x0
    // 0xbdb820: RestoreReg r0
    //     0xbdb820: ldr             x0, [SP], #8
    // 0xbdb824: ldp             x1, x2, [SP], #0x10
    // 0xbdb828: RestoreReg d0
    //     0xbdb828: ldr             q0, [SP], #0x10
    // 0xbdb82c: b               #0xbdb754
    // 0xbdb830: SaveReg d0
    //     0xbdb830: str             q0, [SP, #-0x10]!
    // 0xbdb834: stp             x1, x2, [SP, #-0x10]!
    // 0xbdb838: SaveReg r0
    //     0xbdb838: str             x0, [SP, #-8]!
    // 0xbdb83c: r0 = AllocateDouble()
    //     0xbdb83c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbdb840: mov             x3, x0
    // 0xbdb844: RestoreReg r0
    //     0xbdb844: ldr             x0, [SP], #8
    // 0xbdb848: ldp             x1, x2, [SP], #0x10
    // 0xbdb84c: RestoreReg d0
    //     0xbdb84c: ldr             q0, [SP], #0x10
    // 0xbdb850: b               #0xbdb788
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee484, size: 0x44
    // 0xcee484: EnterFrame
    //     0xcee484: stp             fp, lr, [SP, #-0x10]!
    //     0xcee488: mov             fp, SP
    // 0xcee48c: CheckStackOverflow
    //     0xcee48c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee490: cmp             SP, x16
    //     0xcee494: b.ls            #0xcee4c0
    // 0xcee498: ldr             x16, [fp, #0x18]
    // 0xcee49c: SaveReg r16
    //     0xcee49c: str             x16, [SP, #-8]!
    // 0xcee4a0: ldr             x0, [fp, #0x10]
    // 0xcee4a4: SaveReg r0
    //     0xcee4a4: str             x0, [SP, #-8]!
    // 0xcee4a8: r0 = _giveUpPointer()
    //     0xcee4a8: bl              #0x78ac04  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_giveUpPointer
    // 0xcee4ac: add             SP, SP, #0x10
    // 0xcee4b0: r0 = Null
    //     0xcee4b0: mov             x0, NULL
    // 0xcee4b4: LeaveFrame
    //     0xcee4b4: mov             SP, fp
    //     0xcee4b8: ldp             fp, lr, [SP], #0x10
    // 0xcee4bc: ret
    //     0xcee4bc: ret             
    // 0xcee4c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee4c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee4c4: b               #0xcee498
  }
}

// class id: 2353, size: 0x6c, field offset: 0x6c
class PanGestureRecognizer extends DragGestureRecognizer {

  _ isFlingGesture(/* No info */) {
    // ** addr: 0xcbcf1c, size: 0x110
    // 0xcbcf1c: ldr             x1, [SP, #0x10]
    // 0xcbcf20: LoadField: r2 = r1->field_3b
    //     0xcbcf20: ldur            w2, [x1, #0x3b]
    // 0xcbcf24: DecompressPointer r2
    //     0xcbcf24: add             x2, x2, HEAP, lsl #32
    // 0xcbcf28: cmp             w2, NULL
    // 0xcbcf2c: b.ne            #0xcbcf3c
    // 0xcbcf30: d0 = 50.000000
    //     0xcbcf30: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0xcbcf34: ldr             d0, [x17, #0x980]
    // 0xcbcf38: b               #0xcbcf40
    // 0xcbcf3c: LoadField: d0 = r2->field_7
    //     0xcbcf3c: ldur            d0, [x2, #7]
    // 0xcbcf40: LoadField: r2 = r1->field_37
    //     0xcbcf40: ldur            w2, [x1, #0x37]
    // 0xcbcf44: DecompressPointer r2
    //     0xcbcf44: add             x2, x2, HEAP, lsl #32
    // 0xcbcf48: cmp             w2, NULL
    // 0xcbcf4c: b.ne            #0xcbcfb0
    // 0xcbcf50: ldr             x3, [SP]
    // 0xcbcf54: LoadField: r4 = r1->field_7
    //     0xcbcf54: ldur            w4, [x1, #7]
    // 0xcbcf58: DecompressPointer r4
    //     0xcbcf58: add             x4, x4, HEAP, lsl #32
    // 0xcbcf5c: LoadField: r1 = r3->field_7
    //     0xcbcf5c: ldur            x1, [x3, #7]
    // 0xcbcf60: cmp             x1, #2
    // 0xcbcf64: b.gt            #0xcbcf80
    // 0xcbcf68: cmp             x1, #1
    // 0xcbcf6c: b.gt            #0xcbcf80
    // 0xcbcf70: cmp             x1, #0
    // 0xcbcf74: b.le            #0xcbcf80
    // 0xcbcf78: d1 = 1.000000
    //     0xcbcf78: fmov            d1, #1.00000000
    // 0xcbcf7c: b               #0xcbcfb4
    // 0xcbcf80: cmp             w4, NULL
    // 0xcbcf84: b.ne            #0xcbcf90
    // 0xcbcf88: r1 = Null
    //     0xcbcf88: mov             x1, NULL
    // 0xcbcf8c: b               #0xcbcf98
    // 0xcbcf90: LoadField: r1 = r4->field_7
    //     0xcbcf90: ldur            w1, [x4, #7]
    // 0xcbcf94: DecompressPointer r1
    //     0xcbcf94: add             x1, x1, HEAP, lsl #32
    // 0xcbcf98: cmp             w1, NULL
    // 0xcbcf9c: b.ne            #0xcbcfa8
    // 0xcbcfa0: d1 = 18.000000
    //     0xcbcfa0: fmov            d1, #18.00000000
    // 0xcbcfa4: b               #0xcbcfb4
    // 0xcbcfa8: LoadField: d1 = r1->field_7
    //     0xcbcfa8: ldur            d1, [x1, #7]
    // 0xcbcfac: b               #0xcbcfb4
    // 0xcbcfb0: LoadField: d1 = r2->field_7
    //     0xcbcfb0: ldur            d1, [x2, #7]
    // 0xcbcfb4: ldr             x1, [SP, #8]
    // 0xcbcfb8: LoadField: r2 = r1->field_7
    //     0xcbcfb8: ldur            w2, [x1, #7]
    // 0xcbcfbc: DecompressPointer r2
    //     0xcbcfbc: add             x2, x2, HEAP, lsl #32
    // 0xcbcfc0: LoadField: d2 = r2->field_7
    //     0xcbcfc0: ldur            d2, [x2, #7]
    // 0xcbcfc4: fmul            d3, d2, d2
    // 0xcbcfc8: LoadField: d2 = r2->field_f
    //     0xcbcfc8: ldur            d2, [x2, #0xf]
    // 0xcbcfcc: fmul            d4, d2, d2
    // 0xcbcfd0: fadd            d2, d3, d4
    // 0xcbcfd4: fmul            d3, d0, d0
    // 0xcbcfd8: fcmp            d2, d3
    // 0xcbcfdc: b.vs            #0xcbd024
    // 0xcbcfe0: b.le            #0xcbd024
    // 0xcbcfe4: LoadField: r2 = r1->field_17
    //     0xcbcfe4: ldur            w2, [x1, #0x17]
    // 0xcbcfe8: DecompressPointer r2
    //     0xcbcfe8: add             x2, x2, HEAP, lsl #32
    // 0xcbcfec: LoadField: d0 = r2->field_7
    //     0xcbcfec: ldur            d0, [x2, #7]
    // 0xcbcff0: fmul            d2, d0, d0
    // 0xcbcff4: LoadField: d0 = r2->field_f
    //     0xcbcff4: ldur            d0, [x2, #0xf]
    // 0xcbcff8: fmul            d3, d0, d0
    // 0xcbcffc: fadd            d0, d2, d3
    // 0xcbd000: fmul            d2, d1, d1
    // 0xcbd004: fcmp            d0, d2
    // 0xcbd008: b.vs            #0xcbd010
    // 0xcbd00c: b.gt            #0xcbd018
    // 0xcbd010: r1 = false
    //     0xcbd010: add             x1, NULL, #0x30  ; false
    // 0xcbd014: b               #0xcbd01c
    // 0xcbd018: r1 = true
    //     0xcbd018: add             x1, NULL, #0x20  ; true
    // 0xcbd01c: mov             x0, x1
    // 0xcbd020: b               #0xcbd028
    // 0xcbd024: r0 = false
    //     0xcbd024: add             x0, NULL, #0x30  ; false
    // 0xcbd028: ret
    //     0xcbd028: ret             
  }
}

// class id: 2354, size: 0x6c, field offset: 0x6c
class HorizontalDragGestureRecognizer extends DragGestureRecognizer {

  _ isFlingGesture(/* No info */) {
    // ** addr: 0xcbcdd8, size: 0x144
    // 0xcbcdd8: ldr             x1, [SP, #0x10]
    // 0xcbcddc: LoadField: r2 = r1->field_3b
    //     0xcbcddc: ldur            w2, [x1, #0x3b]
    // 0xcbcde0: DecompressPointer r2
    //     0xcbcde0: add             x2, x2, HEAP, lsl #32
    // 0xcbcde4: cmp             w2, NULL
    // 0xcbcde8: b.ne            #0xcbcdf8
    // 0xcbcdec: d0 = 50.000000
    //     0xcbcdec: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0xcbcdf0: ldr             d0, [x17, #0x980]
    // 0xcbcdf4: b               #0xcbcdfc
    // 0xcbcdf8: LoadField: d0 = r2->field_7
    //     0xcbcdf8: ldur            d0, [x2, #7]
    // 0xcbcdfc: LoadField: r2 = r1->field_37
    //     0xcbcdfc: ldur            w2, [x1, #0x37]
    // 0xcbce00: DecompressPointer r2
    //     0xcbce00: add             x2, x2, HEAP, lsl #32
    // 0xcbce04: cmp             w2, NULL
    // 0xcbce08: b.ne            #0xcbce70
    // 0xcbce0c: ldr             x3, [SP]
    // 0xcbce10: LoadField: r4 = r1->field_7
    //     0xcbce10: ldur            w4, [x1, #7]
    // 0xcbce14: DecompressPointer r4
    //     0xcbce14: add             x4, x4, HEAP, lsl #32
    // 0xcbce18: LoadField: r1 = r3->field_7
    //     0xcbce18: ldur            x1, [x3, #7]
    // 0xcbce1c: cmp             x1, #2
    // 0xcbce20: b.gt            #0xcbce3c
    // 0xcbce24: cmp             x1, #1
    // 0xcbce28: b.gt            #0xcbce3c
    // 0xcbce2c: cmp             x1, #0
    // 0xcbce30: b.le            #0xcbce3c
    // 0xcbce34: d1 = 1.000000
    //     0xcbce34: fmov            d1, #1.00000000
    // 0xcbce38: b               #0xcbce68
    // 0xcbce3c: cmp             w4, NULL
    // 0xcbce40: b.ne            #0xcbce4c
    // 0xcbce44: r1 = Null
    //     0xcbce44: mov             x1, NULL
    // 0xcbce48: b               #0xcbce54
    // 0xcbce4c: LoadField: r1 = r4->field_7
    //     0xcbce4c: ldur            w1, [x4, #7]
    // 0xcbce50: DecompressPointer r1
    //     0xcbce50: add             x1, x1, HEAP, lsl #32
    // 0xcbce54: cmp             w1, NULL
    // 0xcbce58: b.ne            #0xcbce64
    // 0xcbce5c: d1 = 18.000000
    //     0xcbce5c: fmov            d1, #18.00000000
    // 0xcbce60: b               #0xcbce68
    // 0xcbce64: LoadField: d1 = r1->field_7
    //     0xcbce64: ldur            d1, [x1, #7]
    // 0xcbce68: mov             v2.16b, v1.16b
    // 0xcbce6c: b               #0xcbce78
    // 0xcbce70: LoadField: d1 = r2->field_7
    //     0xcbce70: ldur            d1, [x2, #7]
    // 0xcbce74: mov             v2.16b, v1.16b
    // 0xcbce78: ldr             x1, [SP, #8]
    // 0xcbce7c: d1 = 0.000000
    //     0xcbce7c: eor             v1.16b, v1.16b, v1.16b
    // 0xcbce80: LoadField: r2 = r1->field_7
    //     0xcbce80: ldur            w2, [x1, #7]
    // 0xcbce84: DecompressPointer r2
    //     0xcbce84: add             x2, x2, HEAP, lsl #32
    // 0xcbce88: LoadField: d3 = r2->field_7
    //     0xcbce88: ldur            d3, [x2, #7]
    // 0xcbce8c: fcmp            d3, d1
    // 0xcbce90: b.vs            #0xcbcea0
    // 0xcbce94: b.ne            #0xcbcea0
    // 0xcbce98: d3 = 0.000000
    //     0xcbce98: eor             v3.16b, v3.16b, v3.16b
    // 0xcbce9c: b               #0xcbceb4
    // 0xcbcea0: fcmp            d3, d1
    // 0xcbcea4: b.vs            #0xcbceb4
    // 0xcbcea8: b.ge            #0xcbceb4
    // 0xcbceac: fneg            d4, d3
    // 0xcbceb0: mov             v3.16b, v4.16b
    // 0xcbceb4: fcmp            d3, d0
    // 0xcbceb8: b.vs            #0xcbcf14
    // 0xcbcebc: b.le            #0xcbcf14
    // 0xcbcec0: LoadField: r2 = r1->field_17
    //     0xcbcec0: ldur            w2, [x1, #0x17]
    // 0xcbcec4: DecompressPointer r2
    //     0xcbcec4: add             x2, x2, HEAP, lsl #32
    // 0xcbcec8: LoadField: d0 = r2->field_7
    //     0xcbcec8: ldur            d0, [x2, #7]
    // 0xcbcecc: fcmp            d0, d1
    // 0xcbced0: b.vs            #0xcbcee0
    // 0xcbced4: b.ne            #0xcbcee0
    // 0xcbced8: d0 = 0.000000
    //     0xcbced8: eor             v0.16b, v0.16b, v0.16b
    // 0xcbcedc: b               #0xcbcef4
    // 0xcbcee0: fcmp            d0, d1
    // 0xcbcee4: b.vs            #0xcbcef4
    // 0xcbcee8: b.ge            #0xcbcef4
    // 0xcbceec: fneg            d1, d0
    // 0xcbcef0: mov             v0.16b, v1.16b
    // 0xcbcef4: fcmp            d0, d2
    // 0xcbcef8: b.vs            #0xcbcf00
    // 0xcbcefc: b.gt            #0xcbcf08
    // 0xcbcf00: r1 = false
    //     0xcbcf00: add             x1, NULL, #0x30  ; false
    // 0xcbcf04: b               #0xcbcf0c
    // 0xcbcf08: r1 = true
    //     0xcbcf08: add             x1, NULL, #0x20  ; true
    // 0xcbcf0c: mov             x0, x1
    // 0xcbcf10: b               #0xcbcf18
    // 0xcbcf14: r0 = false
    //     0xcbcf14: add             x0, NULL, #0x30  ; false
    // 0xcbcf18: ret
    //     0xcbcf18: ret             
  }
}

// class id: 2355, size: 0x6c, field offset: 0x6c
class VerticalDragGestureRecognizer extends DragGestureRecognizer {

  _ isFlingGesture(/* No info */) {
    // ** addr: 0xcbcc94, size: 0x144
    // 0xcbcc94: ldr             x1, [SP, #0x10]
    // 0xcbcc98: LoadField: r2 = r1->field_3b
    //     0xcbcc98: ldur            w2, [x1, #0x3b]
    // 0xcbcc9c: DecompressPointer r2
    //     0xcbcc9c: add             x2, x2, HEAP, lsl #32
    // 0xcbcca0: cmp             w2, NULL
    // 0xcbcca4: b.ne            #0xcbccb4
    // 0xcbcca8: d0 = 50.000000
    //     0xcbcca8: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0xcbccac: ldr             d0, [x17, #0x980]
    // 0xcbccb0: b               #0xcbccb8
    // 0xcbccb4: LoadField: d0 = r2->field_7
    //     0xcbccb4: ldur            d0, [x2, #7]
    // 0xcbccb8: LoadField: r2 = r1->field_37
    //     0xcbccb8: ldur            w2, [x1, #0x37]
    // 0xcbccbc: DecompressPointer r2
    //     0xcbccbc: add             x2, x2, HEAP, lsl #32
    // 0xcbccc0: cmp             w2, NULL
    // 0xcbccc4: b.ne            #0xcbcd2c
    // 0xcbccc8: ldr             x3, [SP]
    // 0xcbcccc: LoadField: r4 = r1->field_7
    //     0xcbcccc: ldur            w4, [x1, #7]
    // 0xcbccd0: DecompressPointer r4
    //     0xcbccd0: add             x4, x4, HEAP, lsl #32
    // 0xcbccd4: LoadField: r1 = r3->field_7
    //     0xcbccd4: ldur            x1, [x3, #7]
    // 0xcbccd8: cmp             x1, #2
    // 0xcbccdc: b.gt            #0xcbccf8
    // 0xcbcce0: cmp             x1, #1
    // 0xcbcce4: b.gt            #0xcbccf8
    // 0xcbcce8: cmp             x1, #0
    // 0xcbccec: b.le            #0xcbccf8
    // 0xcbccf0: d1 = 1.000000
    //     0xcbccf0: fmov            d1, #1.00000000
    // 0xcbccf4: b               #0xcbcd24
    // 0xcbccf8: cmp             w4, NULL
    // 0xcbccfc: b.ne            #0xcbcd08
    // 0xcbcd00: r1 = Null
    //     0xcbcd00: mov             x1, NULL
    // 0xcbcd04: b               #0xcbcd10
    // 0xcbcd08: LoadField: r1 = r4->field_7
    //     0xcbcd08: ldur            w1, [x4, #7]
    // 0xcbcd0c: DecompressPointer r1
    //     0xcbcd0c: add             x1, x1, HEAP, lsl #32
    // 0xcbcd10: cmp             w1, NULL
    // 0xcbcd14: b.ne            #0xcbcd20
    // 0xcbcd18: d1 = 18.000000
    //     0xcbcd18: fmov            d1, #18.00000000
    // 0xcbcd1c: b               #0xcbcd24
    // 0xcbcd20: LoadField: d1 = r1->field_7
    //     0xcbcd20: ldur            d1, [x1, #7]
    // 0xcbcd24: mov             v2.16b, v1.16b
    // 0xcbcd28: b               #0xcbcd34
    // 0xcbcd2c: LoadField: d1 = r2->field_7
    //     0xcbcd2c: ldur            d1, [x2, #7]
    // 0xcbcd30: mov             v2.16b, v1.16b
    // 0xcbcd34: ldr             x1, [SP, #8]
    // 0xcbcd38: d1 = 0.000000
    //     0xcbcd38: eor             v1.16b, v1.16b, v1.16b
    // 0xcbcd3c: LoadField: r2 = r1->field_7
    //     0xcbcd3c: ldur            w2, [x1, #7]
    // 0xcbcd40: DecompressPointer r2
    //     0xcbcd40: add             x2, x2, HEAP, lsl #32
    // 0xcbcd44: LoadField: d3 = r2->field_f
    //     0xcbcd44: ldur            d3, [x2, #0xf]
    // 0xcbcd48: fcmp            d3, d1
    // 0xcbcd4c: b.vs            #0xcbcd5c
    // 0xcbcd50: b.ne            #0xcbcd5c
    // 0xcbcd54: d3 = 0.000000
    //     0xcbcd54: eor             v3.16b, v3.16b, v3.16b
    // 0xcbcd58: b               #0xcbcd70
    // 0xcbcd5c: fcmp            d3, d1
    // 0xcbcd60: b.vs            #0xcbcd70
    // 0xcbcd64: b.ge            #0xcbcd70
    // 0xcbcd68: fneg            d4, d3
    // 0xcbcd6c: mov             v3.16b, v4.16b
    // 0xcbcd70: fcmp            d3, d0
    // 0xcbcd74: b.vs            #0xcbcdd0
    // 0xcbcd78: b.le            #0xcbcdd0
    // 0xcbcd7c: LoadField: r2 = r1->field_17
    //     0xcbcd7c: ldur            w2, [x1, #0x17]
    // 0xcbcd80: DecompressPointer r2
    //     0xcbcd80: add             x2, x2, HEAP, lsl #32
    // 0xcbcd84: LoadField: d0 = r2->field_f
    //     0xcbcd84: ldur            d0, [x2, #0xf]
    // 0xcbcd88: fcmp            d0, d1
    // 0xcbcd8c: b.vs            #0xcbcd9c
    // 0xcbcd90: b.ne            #0xcbcd9c
    // 0xcbcd94: d0 = 0.000000
    //     0xcbcd94: eor             v0.16b, v0.16b, v0.16b
    // 0xcbcd98: b               #0xcbcdb0
    // 0xcbcd9c: fcmp            d0, d1
    // 0xcbcda0: b.vs            #0xcbcdb0
    // 0xcbcda4: b.ge            #0xcbcdb0
    // 0xcbcda8: fneg            d1, d0
    // 0xcbcdac: mov             v0.16b, v1.16b
    // 0xcbcdb0: fcmp            d0, d2
    // 0xcbcdb4: b.vs            #0xcbcdbc
    // 0xcbcdb8: b.gt            #0xcbcdc4
    // 0xcbcdbc: r1 = false
    //     0xcbcdbc: add             x1, NULL, #0x30  ; false
    // 0xcbcdc0: b               #0xcbcdc8
    // 0xcbcdc4: r1 = true
    //     0xcbcdc4: add             x1, NULL, #0x20  ; true
    // 0xcbcdc8: mov             x0, x1
    // 0xcbcdcc: b               #0xcbcdd4
    // 0xcbcdd0: r0 = false
    //     0xcbcdd0: add             x0, NULL, #0x30  ; false
    // 0xcbcdd4: ret
    //     0xcbcdd4: ret             
  }
}

// class id: 5979, size: 0x14, field offset: 0x14
enum _DragState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15da0, size: 0x5c
    // 0xb15da0: EnterFrame
    //     0xb15da0: stp             fp, lr, [SP, #-0x10]!
    //     0xb15da4: mov             fp, SP
    // 0xb15da8: CheckStackOverflow
    //     0xb15da8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15dac: cmp             SP, x16
    //     0xb15db0: b.ls            #0xb15df4
    // 0xb15db4: r1 = Null
    //     0xb15db4: mov             x1, NULL
    // 0xb15db8: r2 = 4
    //     0xb15db8: mov             x2, #4
    // 0xb15dbc: r0 = AllocateArray()
    //     0xb15dbc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15dc0: r17 = "_DragState."
    //     0xb15dc0: add             x17, PP, #0x28, lsl #12  ; [pp+0x28f58] "_DragState."
    //     0xb15dc4: ldr             x17, [x17, #0xf58]
    // 0xb15dc8: StoreField: r0->field_f = r17
    //     0xb15dc8: stur            w17, [x0, #0xf]
    // 0xb15dcc: ldr             x1, [fp, #0x10]
    // 0xb15dd0: LoadField: r2 = r1->field_f
    //     0xb15dd0: ldur            w2, [x1, #0xf]
    // 0xb15dd4: DecompressPointer r2
    //     0xb15dd4: add             x2, x2, HEAP, lsl #32
    // 0xb15dd8: StoreField: r0->field_13 = r2
    //     0xb15dd8: stur            w2, [x0, #0x13]
    // 0xb15ddc: SaveReg r0
    //     0xb15ddc: str             x0, [SP, #-8]!
    // 0xb15de0: r0 = _interpolate()
    //     0xb15de0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15de4: add             SP, SP, #8
    // 0xb15de8: LeaveFrame
    //     0xb15de8: mov             SP, fp
    //     0xb15dec: ldp             fp, lr, [SP], #0x10
    // 0xb15df0: ret
    //     0xb15df0: ret             
    // 0xb15df4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15df4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15df8: b               #0xb15db4
  }
}

// lib: , url: package:flutter/src/gestures/hit_test.dart

// class id: 1049160, size: 0x8
class :: {
}

// class id: 2280, size: 0x14, field offset: 0x8
class HitTestResult extends Object {

  _ add(/* No info */) {
    // ** addr: 0x50ea24, size: 0xfc
    // 0x50ea24: EnterFrame
    //     0x50ea24: stp             fp, lr, [SP, #-0x10]!
    //     0x50ea28: mov             fp, SP
    // 0x50ea2c: AllocStack(0x10)
    //     0x50ea2c: sub             SP, SP, #0x10
    // 0x50ea30: CheckStackOverflow
    //     0x50ea30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50ea34: cmp             SP, x16
    //     0x50ea38: b.ls            #0x50eb14
    // 0x50ea3c: ldr             x16, [fp, #0x18]
    // 0x50ea40: SaveReg r16
    //     0x50ea40: str             x16, [SP, #-8]!
    // 0x50ea44: r0 = _lastTransform()
    //     0x50ea44: bl              #0x50eb20  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::_lastTransform
    // 0x50ea48: add             SP, SP, #8
    // 0x50ea4c: ldr             x1, [fp, #0x10]
    // 0x50ea50: StoreField: r1->field_f = r0
    //     0x50ea50: stur            w0, [x1, #0xf]
    //     0x50ea54: ldurb           w16, [x1, #-1]
    //     0x50ea58: ldurb           w17, [x0, #-1]
    //     0x50ea5c: and             x16, x17, x16, lsr #2
    //     0x50ea60: tst             x16, HEAP, lsr #32
    //     0x50ea64: b.eq            #0x50ea6c
    //     0x50ea68: bl              #0xd6826c
    // 0x50ea6c: ldr             x0, [fp, #0x18]
    // 0x50ea70: LoadField: r2 = r0->field_7
    //     0x50ea70: ldur            w2, [x0, #7]
    // 0x50ea74: DecompressPointer r2
    //     0x50ea74: add             x2, x2, HEAP, lsl #32
    // 0x50ea78: stur            x2, [fp, #-0x10]
    // 0x50ea7c: LoadField: r0 = r2->field_b
    //     0x50ea7c: ldur            w0, [x2, #0xb]
    // 0x50ea80: DecompressPointer r0
    //     0x50ea80: add             x0, x0, HEAP, lsl #32
    // 0x50ea84: stur            x0, [fp, #-8]
    // 0x50ea88: LoadField: r3 = r2->field_f
    //     0x50ea88: ldur            w3, [x2, #0xf]
    // 0x50ea8c: DecompressPointer r3
    //     0x50ea8c: add             x3, x3, HEAP, lsl #32
    // 0x50ea90: LoadField: r4 = r3->field_b
    //     0x50ea90: ldur            w4, [x3, #0xb]
    // 0x50ea94: DecompressPointer r4
    //     0x50ea94: add             x4, x4, HEAP, lsl #32
    // 0x50ea98: cmp             w0, w4
    // 0x50ea9c: b.ne            #0x50eaac
    // 0x50eaa0: SaveReg r2
    //     0x50eaa0: str             x2, [SP, #-8]!
    // 0x50eaa4: r0 = _growToNextCapacity()
    //     0x50eaa4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x50eaa8: add             SP, SP, #8
    // 0x50eaac: ldur            x2, [fp, #-0x10]
    // 0x50eab0: ldur            x3, [fp, #-8]
    // 0x50eab4: r4 = LoadInt32Instr(r3)
    //     0x50eab4: sbfx            x4, x3, #1, #0x1f
    // 0x50eab8: add             x0, x4, #1
    // 0x50eabc: lsl             x3, x0, #1
    // 0x50eac0: StoreField: r2->field_b = r3
    //     0x50eac0: stur            w3, [x2, #0xb]
    // 0x50eac4: mov             x1, x4
    // 0x50eac8: cmp             x1, x0
    // 0x50eacc: b.hs            #0x50eb1c
    // 0x50ead0: LoadField: r1 = r2->field_f
    //     0x50ead0: ldur            w1, [x2, #0xf]
    // 0x50ead4: DecompressPointer r1
    //     0x50ead4: add             x1, x1, HEAP, lsl #32
    // 0x50ead8: ldr             x0, [fp, #0x10]
    // 0x50eadc: ArrayStore: r1[r4] = r0  ; List_4
    //     0x50eadc: add             x25, x1, x4, lsl #2
    //     0x50eae0: add             x25, x25, #0xf
    //     0x50eae4: str             w0, [x25]
    //     0x50eae8: tbz             w0, #0, #0x50eb04
    //     0x50eaec: ldurb           w16, [x1, #-1]
    //     0x50eaf0: ldurb           w17, [x0, #-1]
    //     0x50eaf4: and             x16, x17, x16, lsr #2
    //     0x50eaf8: tst             x16, HEAP, lsr #32
    //     0x50eafc: b.eq            #0x50eb04
    //     0x50eb00: bl              #0xd67e5c
    // 0x50eb04: r0 = Null
    //     0x50eb04: mov             x0, NULL
    // 0x50eb08: LeaveFrame
    //     0x50eb08: mov             SP, fp
    //     0x50eb0c: ldp             fp, lr, [SP], #0x10
    // 0x50eb10: ret
    //     0x50eb10: ret             
    // 0x50eb14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50eb14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50eb18: b               #0x50ea3c
    // 0x50eb1c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x50eb1c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ _lastTransform(/* No info */) {
    // ** addr: 0x50eb20, size: 0x50
    // 0x50eb20: EnterFrame
    //     0x50eb20: stp             fp, lr, [SP, #-0x10]!
    //     0x50eb24: mov             fp, SP
    // 0x50eb28: CheckStackOverflow
    //     0x50eb28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50eb2c: cmp             SP, x16
    //     0x50eb30: b.ls            #0x50eb68
    // 0x50eb34: ldr             x16, [fp, #0x10]
    // 0x50eb38: SaveReg r16
    //     0x50eb38: str             x16, [SP, #-8]!
    // 0x50eb3c: r0 = _globalizeTransforms()
    //     0x50eb3c: bl              #0x50eb70  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::_globalizeTransforms
    // 0x50eb40: add             SP, SP, #8
    // 0x50eb44: ldr             x0, [fp, #0x10]
    // 0x50eb48: LoadField: r1 = r0->field_b
    //     0x50eb48: ldur            w1, [x0, #0xb]
    // 0x50eb4c: DecompressPointer r1
    //     0x50eb4c: add             x1, x1, HEAP, lsl #32
    // 0x50eb50: SaveReg r1
    //     0x50eb50: str             x1, [SP, #-8]!
    // 0x50eb54: r0 = last()
    //     0x50eb54: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x50eb58: add             SP, SP, #8
    // 0x50eb5c: LeaveFrame
    //     0x50eb5c: mov             SP, fp
    //     0x50eb60: ldp             fp, lr, [SP], #0x10
    // 0x50eb64: ret
    //     0x50eb64: ret             
    // 0x50eb68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50eb68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50eb6c: b               #0x50eb34
  }
  _ _globalizeTransforms(/* No info */) {
    // ** addr: 0x50eb70, size: 0x288
    // 0x50eb70: EnterFrame
    //     0x50eb70: stp             fp, lr, [SP, #-0x10]!
    //     0x50eb74: mov             fp, SP
    // 0x50eb78: AllocStack(0x40)
    //     0x50eb78: sub             SP, SP, #0x40
    // 0x50eb7c: CheckStackOverflow
    //     0x50eb7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50eb80: cmp             SP, x16
    //     0x50eb84: b.ls            #0x50ede4
    // 0x50eb88: ldr             x0, [fp, #0x10]
    // 0x50eb8c: LoadField: r1 = r0->field_f
    //     0x50eb8c: ldur            w1, [x0, #0xf]
    // 0x50eb90: DecompressPointer r1
    //     0x50eb90: add             x1, x1, HEAP, lsl #32
    // 0x50eb94: stur            x1, [fp, #-0x10]
    // 0x50eb98: LoadField: r2 = r1->field_b
    //     0x50eb98: ldur            w2, [x1, #0xb]
    // 0x50eb9c: DecompressPointer r2
    //     0x50eb9c: add             x2, x2, HEAP, lsl #32
    // 0x50eba0: cbnz            w2, #0x50ebb4
    // 0x50eba4: r0 = Null
    //     0x50eba4: mov             x0, NULL
    // 0x50eba8: LeaveFrame
    //     0x50eba8: mov             SP, fp
    //     0x50ebac: ldp             fp, lr, [SP], #0x10
    // 0x50ebb0: ret
    //     0x50ebb0: ret             
    // 0x50ebb4: LoadField: r2 = r0->field_b
    //     0x50ebb4: ldur            w2, [x0, #0xb]
    // 0x50ebb8: DecompressPointer r2
    //     0x50ebb8: add             x2, x2, HEAP, lsl #32
    // 0x50ebbc: stur            x2, [fp, #-8]
    // 0x50ebc0: SaveReg r2
    //     0x50ebc0: str             x2, [SP, #-8]!
    // 0x50ebc4: r0 = last()
    //     0x50ebc4: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x50ebc8: add             SP, SP, #8
    // 0x50ebcc: ldur            x1, [fp, #-0x10]
    // 0x50ebd0: LoadField: r2 = r1->field_7
    //     0x50ebd0: ldur            w2, [x1, #7]
    // 0x50ebd4: DecompressPointer r2
    //     0x50ebd4: add             x2, x2, HEAP, lsl #32
    // 0x50ebd8: stur            x2, [fp, #-0x30]
    // 0x50ebdc: LoadField: r3 = r1->field_b
    //     0x50ebdc: ldur            w3, [x1, #0xb]
    // 0x50ebe0: DecompressPointer r3
    //     0x50ebe0: add             x3, x3, HEAP, lsl #32
    // 0x50ebe4: r4 = LoadInt32Instr(r3)
    //     0x50ebe4: sbfx            x4, x3, #1, #0x1f
    // 0x50ebe8: stur            x4, [fp, #-0x28]
    // 0x50ebec: mov             x6, x0
    // 0x50ebf0: ldur            x3, [fp, #-8]
    // 0x50ebf4: r5 = 0
    //     0x50ebf4: mov             x5, #0
    // 0x50ebf8: stur            x6, [fp, #-0x18]
    // 0x50ebfc: stur            x5, [fp, #-0x20]
    // 0x50ec00: CheckStackOverflow
    //     0x50ec00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50ec04: cmp             SP, x16
    //     0x50ec08: b.ls            #0x50edec
    // 0x50ec0c: r0 = LoadClassIdInstr(r1)
    //     0x50ec0c: ldur            x0, [x1, #-1]
    //     0x50ec10: ubfx            x0, x0, #0xc, #0x14
    // 0x50ec14: SaveReg r1
    //     0x50ec14: str             x1, [SP, #-8]!
    // 0x50ec18: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x50ec18: mov             x17, #0xb8ea
    //     0x50ec1c: add             lr, x0, x17
    //     0x50ec20: ldr             lr, [x21, lr, lsl #3]
    //     0x50ec24: blr             lr
    // 0x50ec28: add             SP, SP, #8
    // 0x50ec2c: r1 = LoadInt32Instr(r0)
    //     0x50ec2c: sbfx            x1, x0, #1, #0x1f
    //     0x50ec30: tbz             w0, #0, #0x50ec38
    //     0x50ec34: ldur            x1, [x0, #7]
    // 0x50ec38: ldur            x2, [fp, #-0x28]
    // 0x50ec3c: cmp             x2, x1
    // 0x50ec40: b.ne            #0x50edcc
    // 0x50ec44: ldur            x3, [fp, #-0x10]
    // 0x50ec48: ldur            x4, [fp, #-0x20]
    // 0x50ec4c: cmp             x4, x1
    // 0x50ec50: b.lt            #0x50ec70
    // 0x50ec54: SaveReg r3
    //     0x50ec54: str             x3, [SP, #-8]!
    // 0x50ec58: r0 = clear()
    //     0x50ec58: bl              #0xd281bc  ; [dart:core] _GrowableList::clear
    // 0x50ec5c: add             SP, SP, #8
    // 0x50ec60: r0 = Null
    //     0x50ec60: mov             x0, NULL
    // 0x50ec64: LeaveFrame
    //     0x50ec64: mov             SP, fp
    //     0x50ec68: ldp             fp, lr, [SP], #0x10
    // 0x50ec6c: ret
    //     0x50ec6c: ret             
    // 0x50ec70: r0 = BoxInt64Instr(r4)
    //     0x50ec70: sbfiz           x0, x4, #1, #0x1f
    //     0x50ec74: cmp             x4, x0, asr #1
    //     0x50ec78: b.eq            #0x50ec84
    //     0x50ec7c: bl              #0xd69bb8
    //     0x50ec80: stur            x4, [x0, #7]
    // 0x50ec84: r1 = LoadClassIdInstr(r3)
    //     0x50ec84: ldur            x1, [x3, #-1]
    //     0x50ec88: ubfx            x1, x1, #0xc, #0x14
    // 0x50ec8c: stp             x0, x3, [SP, #-0x10]!
    // 0x50ec90: mov             x0, x1
    // 0x50ec94: r0 = GDT[cid_x0 + 0xd175]()
    //     0x50ec94: mov             x17, #0xd175
    //     0x50ec98: add             lr, x0, x17
    //     0x50ec9c: ldr             lr, [x21, lr, lsl #3]
    //     0x50eca0: blr             lr
    // 0x50eca4: add             SP, SP, #0x10
    // 0x50eca8: mov             x3, x0
    // 0x50ecac: ldur            x0, [fp, #-0x20]
    // 0x50ecb0: stur            x3, [fp, #-0x40]
    // 0x50ecb4: add             x5, x0, #1
    // 0x50ecb8: stur            x5, [fp, #-0x38]
    // 0x50ecbc: cmp             w3, NULL
    // 0x50ecc0: b.ne            #0x50ecf0
    // 0x50ecc4: mov             x0, x3
    // 0x50ecc8: ldur            x2, [fp, #-0x30]
    // 0x50eccc: r1 = Null
    //     0x50eccc: mov             x1, NULL
    // 0x50ecd0: cmp             w2, NULL
    // 0x50ecd4: b.eq            #0x50ecf0
    // 0x50ecd8: LoadField: r4 = r2->field_17
    //     0x50ecd8: ldur            w4, [x2, #0x17]
    // 0x50ecdc: DecompressPointer r4
    //     0x50ecdc: add             x4, x4, HEAP, lsl #32
    // 0x50ece0: r8 = X0
    //     0x50ece0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x50ece4: LoadField: r9 = r4->field_7
    //     0x50ece4: ldur            x9, [x4, #7]
    // 0x50ece8: r3 = Null
    //     0x50ece8: ldr             x3, [PP, #0x38d8]  ; [pp+0x38d8] Null
    // 0x50ecec: blr             x9
    // 0x50ecf0: ldur            x1, [fp, #-8]
    // 0x50ecf4: ldur            x0, [fp, #-0x40]
    // 0x50ecf8: r2 = LoadClassIdInstr(r0)
    //     0x50ecf8: ldur            x2, [x0, #-1]
    //     0x50ecfc: ubfx            x2, x2, #0xc, #0x14
    // 0x50ed00: ldur            x16, [fp, #-0x18]
    // 0x50ed04: stp             x16, x0, [SP, #-0x10]!
    // 0x50ed08: mov             x0, x2
    // 0x50ed0c: r0 = GDT[cid_x0 + -0xfff]()
    //     0x50ed0c: sub             lr, x0, #0xfff
    //     0x50ed10: ldr             lr, [x21, lr, lsl #3]
    //     0x50ed14: blr             lr
    // 0x50ed18: add             SP, SP, #0x10
    // 0x50ed1c: mov             x1, x0
    // 0x50ed20: ldur            x0, [fp, #-8]
    // 0x50ed24: stur            x1, [fp, #-0x40]
    // 0x50ed28: LoadField: r2 = r0->field_b
    //     0x50ed28: ldur            w2, [x0, #0xb]
    // 0x50ed2c: DecompressPointer r2
    //     0x50ed2c: add             x2, x2, HEAP, lsl #32
    // 0x50ed30: stur            x2, [fp, #-0x18]
    // 0x50ed34: LoadField: r3 = r0->field_f
    //     0x50ed34: ldur            w3, [x0, #0xf]
    // 0x50ed38: DecompressPointer r3
    //     0x50ed38: add             x3, x3, HEAP, lsl #32
    // 0x50ed3c: LoadField: r4 = r3->field_b
    //     0x50ed3c: ldur            w4, [x3, #0xb]
    // 0x50ed40: DecompressPointer r4
    //     0x50ed40: add             x4, x4, HEAP, lsl #32
    // 0x50ed44: cmp             w2, w4
    // 0x50ed48: b.ne            #0x50ed58
    // 0x50ed4c: SaveReg r0
    //     0x50ed4c: str             x0, [SP, #-8]!
    // 0x50ed50: r0 = _growToNextCapacity()
    //     0x50ed50: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x50ed54: add             SP, SP, #8
    // 0x50ed58: ldur            x2, [fp, #-8]
    // 0x50ed5c: ldur            x3, [fp, #-0x18]
    // 0x50ed60: r4 = LoadInt32Instr(r3)
    //     0x50ed60: sbfx            x4, x3, #1, #0x1f
    // 0x50ed64: add             x0, x4, #1
    // 0x50ed68: lsl             x3, x0, #1
    // 0x50ed6c: StoreField: r2->field_b = r3
    //     0x50ed6c: stur            w3, [x2, #0xb]
    // 0x50ed70: mov             x1, x4
    // 0x50ed74: cmp             x1, x0
    // 0x50ed78: b.hs            #0x50edf4
    // 0x50ed7c: LoadField: r1 = r2->field_f
    //     0x50ed7c: ldur            w1, [x2, #0xf]
    // 0x50ed80: DecompressPointer r1
    //     0x50ed80: add             x1, x1, HEAP, lsl #32
    // 0x50ed84: ldur            x0, [fp, #-0x40]
    // 0x50ed88: ArrayStore: r1[r4] = r0  ; List_4
    //     0x50ed88: add             x25, x1, x4, lsl #2
    //     0x50ed8c: add             x25, x25, #0xf
    //     0x50ed90: str             w0, [x25]
    //     0x50ed94: tbz             w0, #0, #0x50edb0
    //     0x50ed98: ldurb           w16, [x1, #-1]
    //     0x50ed9c: ldurb           w17, [x0, #-1]
    //     0x50eda0: and             x16, x17, x16, lsr #2
    //     0x50eda4: tst             x16, HEAP, lsr #32
    //     0x50eda8: b.eq            #0x50edb0
    //     0x50edac: bl              #0xd67e5c
    // 0x50edb0: ldur            x6, [fp, #-0x40]
    // 0x50edb4: ldur            x5, [fp, #-0x38]
    // 0x50edb8: ldur            x1, [fp, #-0x10]
    // 0x50edbc: mov             x3, x2
    // 0x50edc0: ldur            x2, [fp, #-0x30]
    // 0x50edc4: ldur            x4, [fp, #-0x28]
    // 0x50edc8: b               #0x50ebf8
    // 0x50edcc: ldur            x0, [fp, #-0x10]
    // 0x50edd0: r0 = ConcurrentModificationError()
    //     0x50edd0: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x50edd4: ldur            x3, [fp, #-0x10]
    // 0x50edd8: StoreField: r0->field_b = r3
    //     0x50edd8: stur            w3, [x0, #0xb]
    // 0x50eddc: r0 = Throw()
    //     0x50eddc: bl              #0xd67e38  ; ThrowStub
    // 0x50ede0: brk             #0
    // 0x50ede4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50ede4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50ede8: b               #0x50eb88
    // 0x50edec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50edec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50edf0: b               #0x50ec0c
    // 0x50edf4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x50edf4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ HitTestResult(/* No info */) {
    // ** addr: 0x50ef3c, size: 0xfc
    // 0x50ef3c: EnterFrame
    //     0x50ef3c: stp             fp, lr, [SP, #-0x10]!
    //     0x50ef40: mov             fp, SP
    // 0x50ef44: AllocStack(0x10)
    //     0x50ef44: sub             SP, SP, #0x10
    // 0x50ef48: CheckStackOverflow
    //     0x50ef48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x50ef4c: cmp             SP, x16
    //     0x50ef50: b.ls            #0x50f030
    // 0x50ef54: r16 = <HitTestEntry<HitTestTarget>>
    //     0x50ef54: ldr             x16, [PP, #0x3aa8]  ; [pp+0x3aa8] TypeArguments: <HitTestEntry<HitTestTarget>>
    // 0x50ef58: stp             xzr, x16, [SP, #-0x10]!
    // 0x50ef5c: r0 = _GrowableList()
    //     0x50ef5c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x50ef60: add             SP, SP, #0x10
    // 0x50ef64: ldr             x1, [fp, #0x10]
    // 0x50ef68: StoreField: r1->field_7 = r0
    //     0x50ef68: stur            w0, [x1, #7]
    //     0x50ef6c: ldurb           w16, [x1, #-1]
    //     0x50ef70: ldurb           w17, [x0, #-1]
    //     0x50ef74: and             x16, x17, x16, lsr #2
    //     0x50ef78: tst             x16, HEAP, lsr #32
    //     0x50ef7c: b.eq            #0x50ef84
    //     0x50ef80: bl              #0xd6826c
    // 0x50ef84: SaveReg rNULL
    //     0x50ef84: str             NULL, [SP, #-8]!
    // 0x50ef88: r0 = Matrix4.identity()
    //     0x50ef88: bl              #0x50f038  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.identity
    // 0x50ef8c: add             SP, SP, #8
    // 0x50ef90: r1 = Null
    //     0x50ef90: mov             x1, NULL
    // 0x50ef94: r2 = 2
    //     0x50ef94: mov             x2, #2
    // 0x50ef98: stur            x0, [fp, #-8]
    // 0x50ef9c: r0 = AllocateArray()
    //     0x50ef9c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x50efa0: mov             x2, x0
    // 0x50efa4: ldur            x0, [fp, #-8]
    // 0x50efa8: stur            x2, [fp, #-0x10]
    // 0x50efac: StoreField: r2->field_f = r0
    //     0x50efac: stur            w0, [x2, #0xf]
    // 0x50efb0: r1 = <Matrix4>
    //     0x50efb0: ldr             x1, [PP, #0x3ab0]  ; [pp+0x3ab0] TypeArguments: <Matrix4>
    // 0x50efb4: r0 = AllocateGrowableArray()
    //     0x50efb4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x50efb8: mov             x1, x0
    // 0x50efbc: ldur            x0, [fp, #-0x10]
    // 0x50efc0: StoreField: r1->field_f = r0
    //     0x50efc0: stur            w0, [x1, #0xf]
    // 0x50efc4: r0 = 2
    //     0x50efc4: mov             x0, #2
    // 0x50efc8: StoreField: r1->field_b = r0
    //     0x50efc8: stur            w0, [x1, #0xb]
    // 0x50efcc: mov             x0, x1
    // 0x50efd0: ldr             x1, [fp, #0x10]
    // 0x50efd4: StoreField: r1->field_b = r0
    //     0x50efd4: stur            w0, [x1, #0xb]
    //     0x50efd8: ldurb           w16, [x1, #-1]
    //     0x50efdc: ldurb           w17, [x0, #-1]
    //     0x50efe0: and             x16, x17, x16, lsr #2
    //     0x50efe4: tst             x16, HEAP, lsr #32
    //     0x50efe8: b.eq            #0x50eff0
    //     0x50efec: bl              #0xd6826c
    // 0x50eff0: r16 = <_TransformPart>
    //     0x50eff0: ldr             x16, [PP, #0x3ab8]  ; [pp+0x3ab8] TypeArguments: <_TransformPart>
    // 0x50eff4: stp             xzr, x16, [SP, #-0x10]!
    // 0x50eff8: r0 = _GrowableList()
    //     0x50eff8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x50effc: add             SP, SP, #0x10
    // 0x50f000: ldr             x1, [fp, #0x10]
    // 0x50f004: StoreField: r1->field_f = r0
    //     0x50f004: stur            w0, [x1, #0xf]
    //     0x50f008: ldurb           w16, [x1, #-1]
    //     0x50f00c: ldurb           w17, [x0, #-1]
    //     0x50f010: and             x16, x17, x16, lsr #2
    //     0x50f014: tst             x16, HEAP, lsr #32
    //     0x50f018: b.eq            #0x50f020
    //     0x50f01c: bl              #0xd6826c
    // 0x50f020: r0 = Null
    //     0x50f020: mov             x0, NULL
    // 0x50f024: LeaveFrame
    //     0x50f024: mov             SP, fp
    //     0x50f028: ldp             fp, lr, [SP], #0x10
    // 0x50f02c: ret
    //     0x50f02c: ret             
    // 0x50f030: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x50f030: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x50f034: b               #0x50ef54
  }
  _ popTransform(/* No info */) {
    // ** addr: 0x6228f4, size: 0xa4
    // 0x6228f4: EnterFrame
    //     0x6228f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6228f8: mov             fp, SP
    // 0x6228fc: CheckStackOverflow
    //     0x6228fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x622900: cmp             SP, x16
    //     0x622904: b.ls            #0x622988
    // 0x622908: ldr             x0, [fp, #0x10]
    // 0x62290c: LoadField: r2 = r0->field_f
    //     0x62290c: ldur            w2, [x0, #0xf]
    // 0x622910: DecompressPointer r2
    //     0x622910: add             x2, x2, HEAP, lsl #32
    // 0x622914: LoadField: r1 = r2->field_b
    //     0x622914: ldur            w1, [x2, #0xb]
    // 0x622918: DecompressPointer r1
    //     0x622918: add             x1, x1, HEAP, lsl #32
    // 0x62291c: cbz             w1, #0x622944
    // 0x622920: r0 = LoadInt32Instr(r1)
    //     0x622920: sbfx            x0, x1, #1, #0x1f
    // 0x622924: sub             x3, x0, #1
    // 0x622928: mov             x1, x3
    // 0x62292c: cmp             x1, x0
    // 0x622930: b.hs            #0x622990
    // 0x622934: stp             x3, x2, [SP, #-0x10]!
    // 0x622938: r0 = length=()
    //     0x622938: bl              #0x5efc5c  ; [dart:core] _GrowableList::length=
    // 0x62293c: add             SP, SP, #0x10
    // 0x622940: b               #0x622978
    // 0x622944: LoadField: r2 = r0->field_b
    //     0x622944: ldur            w2, [x0, #0xb]
    // 0x622948: DecompressPointer r2
    //     0x622948: add             x2, x2, HEAP, lsl #32
    // 0x62294c: LoadField: r0 = r2->field_b
    //     0x62294c: ldur            w0, [x2, #0xb]
    // 0x622950: DecompressPointer r0
    //     0x622950: add             x0, x0, HEAP, lsl #32
    // 0x622954: r1 = LoadInt32Instr(r0)
    //     0x622954: sbfx            x1, x0, #1, #0x1f
    // 0x622958: sub             x3, x1, #1
    // 0x62295c: mov             x0, x1
    // 0x622960: mov             x1, x3
    // 0x622964: cmp             x1, x0
    // 0x622968: b.hs            #0x622994
    // 0x62296c: stp             x3, x2, [SP, #-0x10]!
    // 0x622970: r0 = length=()
    //     0x622970: bl              #0x5efc5c  ; [dart:core] _GrowableList::length=
    // 0x622974: add             SP, SP, #0x10
    // 0x622978: r0 = Null
    //     0x622978: mov             x0, NULL
    // 0x62297c: LeaveFrame
    //     0x62297c: mov             SP, fp
    //     0x622980: ldp             fp, lr, [SP], #0x10
    // 0x622984: ret
    //     0x622984: ret             
    // 0x622988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622988: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62298c: b               #0x622908
    // 0x622990: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x622990: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x622994: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x622994: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ pushOffset(/* No info */) {
    // ** addr: 0x622998, size: 0xe4
    // 0x622998: EnterFrame
    //     0x622998: stp             fp, lr, [SP, #-0x10]!
    //     0x62299c: mov             fp, SP
    // 0x6229a0: AllocStack(0x18)
    //     0x6229a0: sub             SP, SP, #0x18
    // 0x6229a4: CheckStackOverflow
    //     0x6229a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6229a8: cmp             SP, x16
    //     0x6229ac: b.ls            #0x622a70
    // 0x6229b0: ldr             x0, [fp, #0x18]
    // 0x6229b4: LoadField: r1 = r0->field_f
    //     0x6229b4: ldur            w1, [x0, #0xf]
    // 0x6229b8: DecompressPointer r1
    //     0x6229b8: add             x1, x1, HEAP, lsl #32
    // 0x6229bc: stur            x1, [fp, #-8]
    // 0x6229c0: r0 = _OffsetTransformPart()
    //     0x6229c0: bl              #0x622a7c  ; Allocate_OffsetTransformPartStub -> _OffsetTransformPart (size=0xc)
    // 0x6229c4: mov             x1, x0
    // 0x6229c8: ldr             x0, [fp, #0x10]
    // 0x6229cc: stur            x1, [fp, #-0x18]
    // 0x6229d0: StoreField: r1->field_7 = r0
    //     0x6229d0: stur            w0, [x1, #7]
    // 0x6229d4: ldur            x0, [fp, #-8]
    // 0x6229d8: LoadField: r2 = r0->field_b
    //     0x6229d8: ldur            w2, [x0, #0xb]
    // 0x6229dc: DecompressPointer r2
    //     0x6229dc: add             x2, x2, HEAP, lsl #32
    // 0x6229e0: stur            x2, [fp, #-0x10]
    // 0x6229e4: LoadField: r3 = r0->field_f
    //     0x6229e4: ldur            w3, [x0, #0xf]
    // 0x6229e8: DecompressPointer r3
    //     0x6229e8: add             x3, x3, HEAP, lsl #32
    // 0x6229ec: LoadField: r4 = r3->field_b
    //     0x6229ec: ldur            w4, [x3, #0xb]
    // 0x6229f0: DecompressPointer r4
    //     0x6229f0: add             x4, x4, HEAP, lsl #32
    // 0x6229f4: cmp             w2, w4
    // 0x6229f8: b.ne            #0x622a08
    // 0x6229fc: SaveReg r0
    //     0x6229fc: str             x0, [SP, #-8]!
    // 0x622a00: r0 = _growToNextCapacity()
    //     0x622a00: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x622a04: add             SP, SP, #8
    // 0x622a08: ldur            x2, [fp, #-8]
    // 0x622a0c: ldur            x3, [fp, #-0x10]
    // 0x622a10: r4 = LoadInt32Instr(r3)
    //     0x622a10: sbfx            x4, x3, #1, #0x1f
    // 0x622a14: add             x0, x4, #1
    // 0x622a18: lsl             x3, x0, #1
    // 0x622a1c: StoreField: r2->field_b = r3
    //     0x622a1c: stur            w3, [x2, #0xb]
    // 0x622a20: mov             x1, x4
    // 0x622a24: cmp             x1, x0
    // 0x622a28: b.hs            #0x622a78
    // 0x622a2c: LoadField: r1 = r2->field_f
    //     0x622a2c: ldur            w1, [x2, #0xf]
    // 0x622a30: DecompressPointer r1
    //     0x622a30: add             x1, x1, HEAP, lsl #32
    // 0x622a34: ldur            x0, [fp, #-0x18]
    // 0x622a38: ArrayStore: r1[r4] = r0  ; List_4
    //     0x622a38: add             x25, x1, x4, lsl #2
    //     0x622a3c: add             x25, x25, #0xf
    //     0x622a40: str             w0, [x25]
    //     0x622a44: tbz             w0, #0, #0x622a60
    //     0x622a48: ldurb           w16, [x1, #-1]
    //     0x622a4c: ldurb           w17, [x0, #-1]
    //     0x622a50: and             x16, x17, x16, lsr #2
    //     0x622a54: tst             x16, HEAP, lsr #32
    //     0x622a58: b.eq            #0x622a60
    //     0x622a5c: bl              #0xd67e5c
    // 0x622a60: r0 = Null
    //     0x622a60: mov             x0, NULL
    // 0x622a64: LeaveFrame
    //     0x622a64: mov             SP, fp
    //     0x622a68: ldp             fp, lr, [SP], #0x10
    // 0x622a6c: ret
    //     0x622a6c: ret             
    // 0x622a70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622a70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622a74: b               #0x6229b0
    // 0x622a78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x622a78: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ pushTransform(/* No info */) {
    // ** addr: 0x62304c, size: 0xe4
    // 0x62304c: EnterFrame
    //     0x62304c: stp             fp, lr, [SP, #-0x10]!
    //     0x623050: mov             fp, SP
    // 0x623054: AllocStack(0x18)
    //     0x623054: sub             SP, SP, #0x18
    // 0x623058: CheckStackOverflow
    //     0x623058: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62305c: cmp             SP, x16
    //     0x623060: b.ls            #0x623124
    // 0x623064: ldr             x0, [fp, #0x18]
    // 0x623068: LoadField: r1 = r0->field_f
    //     0x623068: ldur            w1, [x0, #0xf]
    // 0x62306c: DecompressPointer r1
    //     0x62306c: add             x1, x1, HEAP, lsl #32
    // 0x623070: stur            x1, [fp, #-8]
    // 0x623074: r0 = _MatrixTransformPart()
    //     0x623074: bl              #0x623130  ; Allocate_MatrixTransformPartStub -> _MatrixTransformPart (size=0xc)
    // 0x623078: mov             x1, x0
    // 0x62307c: ldr             x0, [fp, #0x10]
    // 0x623080: stur            x1, [fp, #-0x18]
    // 0x623084: StoreField: r1->field_7 = r0
    //     0x623084: stur            w0, [x1, #7]
    // 0x623088: ldur            x0, [fp, #-8]
    // 0x62308c: LoadField: r2 = r0->field_b
    //     0x62308c: ldur            w2, [x0, #0xb]
    // 0x623090: DecompressPointer r2
    //     0x623090: add             x2, x2, HEAP, lsl #32
    // 0x623094: stur            x2, [fp, #-0x10]
    // 0x623098: LoadField: r3 = r0->field_f
    //     0x623098: ldur            w3, [x0, #0xf]
    // 0x62309c: DecompressPointer r3
    //     0x62309c: add             x3, x3, HEAP, lsl #32
    // 0x6230a0: LoadField: r4 = r3->field_b
    //     0x6230a0: ldur            w4, [x3, #0xb]
    // 0x6230a4: DecompressPointer r4
    //     0x6230a4: add             x4, x4, HEAP, lsl #32
    // 0x6230a8: cmp             w2, w4
    // 0x6230ac: b.ne            #0x6230bc
    // 0x6230b0: SaveReg r0
    //     0x6230b0: str             x0, [SP, #-8]!
    // 0x6230b4: r0 = _growToNextCapacity()
    //     0x6230b4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6230b8: add             SP, SP, #8
    // 0x6230bc: ldur            x2, [fp, #-8]
    // 0x6230c0: ldur            x3, [fp, #-0x10]
    // 0x6230c4: r4 = LoadInt32Instr(r3)
    //     0x6230c4: sbfx            x4, x3, #1, #0x1f
    // 0x6230c8: add             x0, x4, #1
    // 0x6230cc: lsl             x3, x0, #1
    // 0x6230d0: StoreField: r2->field_b = r3
    //     0x6230d0: stur            w3, [x2, #0xb]
    // 0x6230d4: mov             x1, x4
    // 0x6230d8: cmp             x1, x0
    // 0x6230dc: b.hs            #0x62312c
    // 0x6230e0: LoadField: r1 = r2->field_f
    //     0x6230e0: ldur            w1, [x2, #0xf]
    // 0x6230e4: DecompressPointer r1
    //     0x6230e4: add             x1, x1, HEAP, lsl #32
    // 0x6230e8: ldur            x0, [fp, #-0x18]
    // 0x6230ec: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6230ec: add             x25, x1, x4, lsl #2
    //     0x6230f0: add             x25, x25, #0xf
    //     0x6230f4: str             w0, [x25]
    //     0x6230f8: tbz             w0, #0, #0x623114
    //     0x6230fc: ldurb           w16, [x1, #-1]
    //     0x623100: ldurb           w17, [x0, #-1]
    //     0x623104: and             x16, x17, x16, lsr #2
    //     0x623108: tst             x16, HEAP, lsr #32
    //     0x62310c: b.eq            #0x623114
    //     0x623110: bl              #0xd67e5c
    // 0x623114: r0 = Null
    //     0x623114: mov             x0, NULL
    // 0x623118: LeaveFrame
    //     0x623118: mov             SP, fp
    //     0x62311c: ldp             fp, lr, [SP], #0x10
    // 0x623120: ret
    //     0x623120: ret             
    // 0x623124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x623124: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x623128: b               #0x623064
    // 0x62312c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x62312c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xad96cc, size: 0xbc
    // 0xad96cc: EnterFrame
    //     0xad96cc: stp             fp, lr, [SP, #-0x10]!
    //     0xad96d0: mov             fp, SP
    // 0xad96d4: AllocStack(0x8)
    //     0xad96d4: sub             SP, SP, #8
    // 0xad96d8: CheckStackOverflow
    //     0xad96d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad96dc: cmp             SP, x16
    //     0xad96e0: b.ls            #0xad9780
    // 0xad96e4: r1 = Null
    //     0xad96e4: mov             x1, NULL
    // 0xad96e8: r2 = 6
    //     0xad96e8: mov             x2, #6
    // 0xad96ec: r0 = AllocateArray()
    //     0xad96ec: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad96f0: stur            x0, [fp, #-8]
    // 0xad96f4: r17 = "HitTestResult("
    //     0xad96f4: ldr             x17, [PP, #0x74c0]  ; [pp+0x74c0] "HitTestResult("
    // 0xad96f8: StoreField: r0->field_f = r17
    //     0xad96f8: stur            w17, [x0, #0xf]
    // 0xad96fc: ldr             x1, [fp, #0x10]
    // 0xad9700: LoadField: r2 = r1->field_7
    //     0xad9700: ldur            w2, [x1, #7]
    // 0xad9704: DecompressPointer r2
    //     0xad9704: add             x2, x2, HEAP, lsl #32
    // 0xad9708: LoadField: r1 = r2->field_b
    //     0xad9708: ldur            w1, [x2, #0xb]
    // 0xad970c: DecompressPointer r1
    //     0xad970c: add             x1, x1, HEAP, lsl #32
    // 0xad9710: cbnz            w1, #0xad9720
    // 0xad9714: mov             x2, x0
    // 0xad9718: r0 = "<empty path>"
    //     0xad9718: ldr             x0, [PP, #0x74c8]  ; [pp+0x74c8] "<empty path>"
    // 0xad971c: b               #0xad9738
    // 0xad9720: r16 = ", "
    //     0xad9720: ldr             x16, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad9724: stp             x16, x2, [SP, #-0x10]!
    // 0xad9728: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad9728: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad972c: r0 = join()
    //     0xad972c: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xad9730: add             SP, SP, #0x10
    // 0xad9734: ldur            x2, [fp, #-8]
    // 0xad9738: mov             x1, x2
    // 0xad973c: ArrayStore: r1[1] = r0  ; List_4
    //     0xad973c: add             x25, x1, #0x13
    //     0xad9740: str             w0, [x25]
    //     0xad9744: tbz             w0, #0, #0xad9760
    //     0xad9748: ldurb           w16, [x1, #-1]
    //     0xad974c: ldurb           w17, [x0, #-1]
    //     0xad9750: and             x16, x17, x16, lsr #2
    //     0xad9754: tst             x16, HEAP, lsr #32
    //     0xad9758: b.eq            #0xad9760
    //     0xad975c: bl              #0xd67e5c
    // 0xad9760: r17 = ")"
    //     0xad9760: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad9764: StoreField: r2->field_17 = r17
    //     0xad9764: stur            w17, [x2, #0x17]
    // 0xad9768: SaveReg r2
    //     0xad9768: str             x2, [SP, #-8]!
    // 0xad976c: r0 = _interpolate()
    //     0xad976c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad9770: add             SP, SP, #8
    // 0xad9774: LeaveFrame
    //     0xad9774: mov             SP, fp
    //     0xad9778: ldp             fp, lr, [SP], #0x10
    // 0xad977c: ret
    //     0xad977c: ret             
    // 0xad9780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad9780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad9784: b               #0xad96e4
  }
}

// class id: 2283, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class _TransformPart extends Object {
}

// class id: 2284, size: 0xc, field offset: 0x8
//   const constructor, 
class _OffsetTransformPart extends _TransformPart {

  _ multiply(/* No info */) {
    // ** addr: 0xcf809c, size: 0xac
    // 0xcf809c: EnterFrame
    //     0xcf809c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf80a0: mov             fp, SP
    // 0xcf80a4: AllocStack(0x8)
    //     0xcf80a4: sub             SP, SP, #8
    // 0xcf80a8: CheckStackOverflow
    //     0xcf80a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf80ac: cmp             SP, x16
    //     0xcf80b0: b.ls            #0xcf8128
    // 0xcf80b4: ldr             x16, [fp, #0x10]
    // 0xcf80b8: SaveReg r16
    //     0xcf80b8: str             x16, [SP, #-8]!
    // 0xcf80bc: r0 = Matrix4.copy()
    //     0xcf80bc: bl              #0x50aa74  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.copy
    // 0xcf80c0: add             SP, SP, #8
    // 0xcf80c4: mov             x1, x0
    // 0xcf80c8: ldr             x0, [fp, #0x18]
    // 0xcf80cc: stur            x1, [fp, #-8]
    // 0xcf80d0: LoadField: r2 = r0->field_7
    //     0xcf80d0: ldur            w2, [x0, #7]
    // 0xcf80d4: DecompressPointer r2
    //     0xcf80d4: add             x2, x2, HEAP, lsl #32
    // 0xcf80d8: LoadField: d0 = r2->field_7
    //     0xcf80d8: ldur            d0, [x2, #7]
    // 0xcf80dc: LoadField: d1 = r2->field_f
    //     0xcf80dc: ldur            d1, [x2, #0xf]
    // 0xcf80e0: r0 = inline_Allocate_Double()
    //     0xcf80e0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xcf80e4: add             x0, x0, #0x10
    //     0xcf80e8: cmp             x2, x0
    //     0xcf80ec: b.ls            #0xcf8130
    //     0xcf80f0: str             x0, [THR, #0x60]  ; THR::top
    //     0xcf80f4: sub             x0, x0, #0xf
    //     0xcf80f8: mov             x2, #0xd108
    //     0xcf80fc: movk            x2, #3, lsl #16
    //     0xcf8100: stur            x2, [x0, #-1]
    // 0xcf8104: StoreField: r0->field_7 = d0
    //     0xcf8104: stur            d0, [x0, #7]
    // 0xcf8108: stp             x0, x1, [SP, #-0x10]!
    // 0xcf810c: SaveReg d1
    //     0xcf810c: str             d1, [SP, #-8]!
    // 0xcf8110: r0 = leftTranslate()
    //     0xcf8110: bl              #0xcf8148  ; [package:vector_math/vector_math_64.dart] Matrix4::leftTranslate
    // 0xcf8114: add             SP, SP, #0x18
    // 0xcf8118: ldur            x0, [fp, #-8]
    // 0xcf811c: LeaveFrame
    //     0xcf811c: mov             SP, fp
    //     0xcf8120: ldp             fp, lr, [SP], #0x10
    // 0xcf8124: ret
    //     0xcf8124: ret             
    // 0xcf8128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8128: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf812c: b               #0xcf80b4
    // 0xcf8130: stp             q0, q1, [SP, #-0x20]!
    // 0xcf8134: SaveReg r1
    //     0xcf8134: str             x1, [SP, #-8]!
    // 0xcf8138: r0 = AllocateDouble()
    //     0xcf8138: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf813c: RestoreReg r1
    //     0xcf813c: ldr             x1, [SP], #8
    // 0xcf8140: ldp             q0, q1, [SP], #0x20
    // 0xcf8144: b               #0xcf8104
  }
}

// class id: 2285, size: 0xc, field offset: 0x8
//   const constructor, 
class _MatrixTransformPart extends _TransformPart {

  _ multiply(/* No info */) {
    // ** addr: 0xcf8004, size: 0x44
    // 0xcf8004: EnterFrame
    //     0xcf8004: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8008: mov             fp, SP
    // 0xcf800c: CheckStackOverflow
    //     0xcf800c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf8010: cmp             SP, x16
    //     0xcf8014: b.ls            #0xcf8040
    // 0xcf8018: ldr             x0, [fp, #0x18]
    // 0xcf801c: LoadField: r1 = r0->field_7
    //     0xcf801c: ldur            w1, [x0, #7]
    // 0xcf8020: DecompressPointer r1
    //     0xcf8020: add             x1, x1, HEAP, lsl #32
    // 0xcf8024: ldr             x16, [fp, #0x10]
    // 0xcf8028: stp             x16, x1, [SP, #-0x10]!
    // 0xcf802c: r0 = multiplied()
    //     0xcf802c: bl              #0xcf8048  ; [package:vector_math/vector_math_64.dart] Matrix4::multiplied
    // 0xcf8030: add             SP, SP, #0x10
    // 0xcf8034: LeaveFrame
    //     0xcf8034: mov             SP, fp
    //     0xcf8038: ldp             fp, lr, [SP], #0x10
    // 0xcf803c: ret
    //     0xcf803c: ret             
    // 0xcf8040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8040: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8044: b               #0xcf8018
  }
}

// class id: 2286, size: 0x14, field offset: 0x8
class HitTestEntry<X0 bound HitTestTarget> extends Object {
}

// class id: 2332, size: 0x8, field offset: 0x8
abstract class HitTestTarget extends Object {
}

// class id: 2333, size: 0x8, field offset: 0x8
abstract class HitTestDispatcher extends Object {
}

// class id: 2334, size: 0x8, field offset: 0x8
abstract class HitTestable extends Object {
}

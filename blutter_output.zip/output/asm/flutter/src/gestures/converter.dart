// lib: , url: package:flutter/src/gestures/converter.dart

// class id: 1049152, size: 0x8
class :: {
}

// class id: 2331, size: 0x8, field offset: 0x8
abstract class PointerEventConverter extends Object {

  static _ expand(/* No info */) {
    // ** addr: 0x5c720c, size: 0xcc
    // 0x5c720c: EnterFrame
    //     0x5c720c: stp             fp, lr, [SP, #-0x10]!
    //     0x5c7210: mov             fp, SP
    // 0x5c7214: AllocStack(0x10)
    //     0x5c7214: sub             SP, SP, #0x10
    // 0x5c7218: CheckStackOverflow
    //     0x5c7218: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5c721c: cmp             SP, x16
    //     0x5c7220: b.ls            #0x5c72c0
    // 0x5c7224: ldr             d0, [fp, #0x10]
    // 0x5c7228: r0 = inline_Allocate_Double()
    //     0x5c7228: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5c722c: add             x0, x0, #0x10
    //     0x5c7230: cmp             x1, x0
    //     0x5c7234: b.ls            #0x5c72c8
    //     0x5c7238: str             x0, [THR, #0x60]  ; THR::top
    //     0x5c723c: sub             x0, x0, #0xf
    //     0x5c7240: mov             x1, #0xd108
    //     0x5c7244: movk            x1, #3, lsl #16
    //     0x5c7248: stur            x1, [x0, #-1]
    // 0x5c724c: StoreField: r0->field_7 = d0
    //     0x5c724c: stur            d0, [x0, #7]
    // 0x5c7250: stur            x0, [fp, #-8]
    // 0x5c7254: r1 = 1
    //     0x5c7254: mov             x1, #1
    // 0x5c7258: r0 = AllocateContext()
    //     0x5c7258: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5c725c: mov             x3, x0
    // 0x5c7260: ldur            x0, [fp, #-8]
    // 0x5c7264: stur            x3, [fp, #-0x10]
    // 0x5c7268: StoreField: r3->field_f = r0
    //     0x5c7268: stur            w0, [x3, #0xf]
    // 0x5c726c: r1 = Function '<anonymous closure>': static.
    //     0x5c726c: ldr             x1, [PP, #0x5b88]  ; [pp+0x5b88] AnonymousClosure: static (0x5c8500), in [package:flutter/src/gestures/converter.dart] PointerEventConverter::expand (0x5c720c)
    // 0x5c7270: r2 = Null
    //     0x5c7270: mov             x2, NULL
    // 0x5c7274: r0 = AllocateClosure()
    //     0x5c7274: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5c7278: ldr             x16, [fp, #0x18]
    // 0x5c727c: stp             x0, x16, [SP, #-0x10]!
    // 0x5c7280: r0 = where()
    //     0x5c7280: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0x5c7284: add             SP, SP, #0x10
    // 0x5c7288: ldur            x2, [fp, #-0x10]
    // 0x5c728c: r1 = Function '<anonymous closure>': static.
    //     0x5c728c: ldr             x1, [PP, #0x5b90]  ; [pp+0x5b90] AnonymousClosure: static (0x5c72d8), in [package:flutter/src/gestures/converter.dart] PointerEventConverter::expand (0x5c720c)
    // 0x5c7290: stur            x0, [fp, #-8]
    // 0x5c7294: r0 = AllocateClosure()
    //     0x5c7294: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5c7298: r16 = <PointerEvent>
    //     0x5c7298: ldr             x16, [PP, #0x3928]  ; [pp+0x3928] TypeArguments: <PointerEvent>
    // 0x5c729c: ldur            lr, [fp, #-8]
    // 0x5c72a0: stp             lr, x16, [SP, #-0x10]!
    // 0x5c72a4: SaveReg r0
    //     0x5c72a4: str             x0, [SP, #-8]!
    // 0x5c72a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5c72a8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5c72ac: r0 = map()
    //     0x5c72ac: bl              #0x6ba568  ; [dart:_internal] WhereIterable::map
    // 0x5c72b0: add             SP, SP, #0x18
    // 0x5c72b4: LeaveFrame
    //     0x5c72b4: mov             SP, fp
    //     0x5c72b8: ldp             fp, lr, [SP], #0x10
    // 0x5c72bc: ret
    //     0x5c72bc: ret             
    // 0x5c72c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5c72c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5c72c4: b               #0x5c7224
    // 0x5c72c8: SaveReg d0
    //     0x5c72c8: str             q0, [SP, #-0x10]!
    // 0x5c72cc: r0 = AllocateDouble()
    //     0x5c72cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5c72d0: RestoreReg d0
    //     0x5c72d0: ldr             q0, [SP], #0x10
    // 0x5c72d4: b               #0x5c724c
  }
  [closure] static _PointerEventDescription <anonymous closure>(dynamic, PointerData) {
    // ** addr: 0x5c72d8, size: 0x1198
    // 0x5c72d8: EnterFrame
    //     0x5c72d8: stp             fp, lr, [SP, #-0x10]!
    //     0x5c72dc: mov             fp, SP
    // 0x5c72e0: AllocStack(0xc8)
    //     0x5c72e0: sub             SP, SP, #0xc8
    // 0x5c72e4: SetupParameters()
    //     0x5c72e4: ldr             x0, [fp, #0x18]
    //     0x5c72e8: ldur            w1, [x0, #0x17]
    //     0x5c72ec: add             x1, x1, HEAP, lsl #32
    //     0x5c72f0: stur            x1, [fp, #-8]
    // 0x5c72f4: CheckStackOverflow
    //     0x5c72f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5c72f8: cmp             SP, x16
    //     0x5c72fc: b.ls            #0x5c8464
    // 0x5c7300: ldr             x0, [fp, #0x10]
    // 0x5c7304: LoadField: d0 = r0->field_2f
    //     0x5c7304: ldur            d0, [x0, #0x2f]
    // 0x5c7308: stur            d0, [fp, #-0x78]
    // 0x5c730c: LoadField: d1 = r0->field_37
    //     0x5c730c: ldur            d1, [x0, #0x37]
    // 0x5c7310: stur            d1, [fp, #-0x70]
    // 0x5c7314: r0 = Offset()
    //     0x5c7314: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x5c7318: ldur            d0, [fp, #-0x78]
    // 0x5c731c: StoreField: r0->field_7 = d0
    //     0x5c731c: stur            d0, [x0, #7]
    // 0x5c7320: ldur            d0, [fp, #-0x70]
    // 0x5c7324: StoreField: r0->field_f = d0
    //     0x5c7324: stur            d0, [x0, #0xf]
    // 0x5c7328: ldur            x1, [fp, #-8]
    // 0x5c732c: LoadField: r2 = r1->field_f
    //     0x5c732c: ldur            w2, [x1, #0xf]
    // 0x5c7330: DecompressPointer r2
    //     0x5c7330: add             x2, x2, HEAP, lsl #32
    // 0x5c7334: stp             x2, x0, [SP, #-0x10]!
    // 0x5c7338: r0 = /()
    //     0x5c7338: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x5c733c: add             SP, SP, #0x10
    // 0x5c7340: mov             x1, x0
    // 0x5c7344: ldr             x0, [fp, #0x10]
    // 0x5c7348: stur            x1, [fp, #-0x10]
    // 0x5c734c: LoadField: d0 = r0->field_3f
    //     0x5c734c: ldur            d0, [x0, #0x3f]
    // 0x5c7350: stur            d0, [fp, #-0x78]
    // 0x5c7354: LoadField: d1 = r0->field_47
    //     0x5c7354: ldur            d1, [x0, #0x47]
    // 0x5c7358: stur            d1, [fp, #-0x70]
    // 0x5c735c: r0 = Offset()
    //     0x5c735c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x5c7360: ldur            d0, [fp, #-0x78]
    // 0x5c7364: StoreField: r0->field_7 = d0
    //     0x5c7364: stur            d0, [x0, #7]
    // 0x5c7368: ldur            d0, [fp, #-0x70]
    // 0x5c736c: StoreField: r0->field_f = d0
    //     0x5c736c: stur            d0, [x0, #0xf]
    // 0x5c7370: ldur            x1, [fp, #-8]
    // 0x5c7374: LoadField: r2 = r1->field_f
    //     0x5c7374: ldur            w2, [x1, #0xf]
    // 0x5c7378: DecompressPointer r2
    //     0x5c7378: add             x2, x2, HEAP, lsl #32
    // 0x5c737c: stp             x2, x0, [SP, #-0x10]!
    // 0x5c7380: r0 = /()
    //     0x5c7380: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x5c7384: add             SP, SP, #0x10
    // 0x5c7388: mov             x1, x0
    // 0x5c738c: ldr             x0, [fp, #0x10]
    // 0x5c7390: stur            x1, [fp, #-0x58]
    // 0x5c7394: LoadField: d0 = r0->field_97
    //     0x5c7394: ldur            d0, [x0, #0x97]
    // 0x5c7398: ldur            x2, [fp, #-8]
    // 0x5c739c: LoadField: r3 = r2->field_f
    //     0x5c739c: ldur            w3, [x2, #0xf]
    // 0x5c73a0: DecompressPointer r3
    //     0x5c73a0: add             x3, x3, HEAP, lsl #32
    // 0x5c73a4: stur            x3, [fp, #-0x68]
    // 0x5c73a8: cmp             w3, NULL
    // 0x5c73ac: b.eq            #0x5c846c
    // 0x5c73b0: LoadField: d1 = r3->field_7
    //     0x5c73b0: ldur            d1, [x3, #7]
    // 0x5c73b4: fdiv            d2, d0, d1
    // 0x5c73b8: stur            d2, [fp, #-0xc0]
    // 0x5c73bc: LoadField: d0 = r0->field_8f
    //     0x5c73bc: ldur            d0, [x0, #0x8f]
    // 0x5c73c0: fdiv            d3, d0, d1
    // 0x5c73c4: stur            d3, [fp, #-0xb8]
    // 0x5c73c8: LoadField: d0 = r0->field_9f
    //     0x5c73c8: ldur            d0, [x0, #0x9f]
    // 0x5c73cc: fdiv            d4, d0, d1
    // 0x5c73d0: stur            d4, [fp, #-0xb0]
    // 0x5c73d4: LoadField: d0 = r0->field_a7
    //     0x5c73d4: ldur            d0, [x0, #0xa7]
    // 0x5c73d8: fdiv            d5, d0, d1
    // 0x5c73dc: stur            d5, [fp, #-0xa8]
    // 0x5c73e0: LoadField: r4 = r0->field_f
    //     0x5c73e0: ldur            w4, [x0, #0xf]
    // 0x5c73e4: DecompressPointer r4
    //     0x5c73e4: add             x4, x4, HEAP, lsl #32
    // 0x5c73e8: stur            x4, [fp, #-0x48]
    // 0x5c73ec: LoadField: r5 = r0->field_17
    //     0x5c73ec: ldur            w5, [x0, #0x17]
    // 0x5c73f0: DecompressPointer r5
    //     0x5c73f0: add             x5, x5, HEAP, lsl #32
    // 0x5c73f4: stur            x5, [fp, #-0x40]
    // 0x5c73f8: LoadField: r6 = r0->field_1b
    //     0x5c73f8: ldur            w6, [x0, #0x1b]
    // 0x5c73fc: DecompressPointer r6
    //     0x5c73fc: add             x6, x6, HEAP, lsl #32
    // 0x5c7400: LoadField: r7 = r6->field_7
    //     0x5c7400: ldur            x7, [x6, #7]
    // 0x5c7404: cmp             x7, #2
    // 0x5c7408: b.gt            #0x5c8368
    // 0x5c740c: cmp             x7, #1
    // 0x5c7410: b.gt            #0x5c8298
    // 0x5c7414: cmp             x7, #0
    // 0x5c7418: b.gt            #0x5c817c
    // 0x5c741c: LoadField: r6 = r0->field_13
    //     0x5c741c: ldur            w6, [x0, #0x13]
    // 0x5c7420: DecompressPointer r6
    //     0x5c7420: add             x6, x6, HEAP, lsl #32
    // 0x5c7424: LoadField: r7 = r6->field_7
    //     0x5c7424: ldur            x7, [x6, #7]
    // 0x5c7428: cmp             x7, #4
    // 0x5c742c: b.gt            #0x5c7acc
    // 0x5c7430: cmp             x7, #2
    // 0x5c7434: b.gt            #0x5c77c0
    // 0x5c7438: cmp             x7, #1
    // 0x5c743c: b.gt            #0x5c76b4
    // 0x5c7440: cmp             x7, #0
    // 0x5c7444: b.gt            #0x5c7584
    // 0x5c7448: ldur            x1, [fp, #-0x10]
    // 0x5c744c: LoadField: r2 = r0->field_27
    //     0x5c744c: ldur            x2, [x0, #0x27]
    // 0x5c7450: stur            x2, [fp, #-0x38]
    // 0x5c7454: LoadField: r3 = r0->field_1f
    //     0x5c7454: ldur            x3, [x0, #0x1f]
    // 0x5c7458: stur            x3, [fp, #-0x30]
    // 0x5c745c: LoadField: r6 = r0->field_4f
    //     0x5c745c: ldur            x6, [x0, #0x4f]
    // 0x5c7460: stur            x6, [fp, #-0x28]
    // 0x5c7464: LoadField: r7 = r0->field_57
    //     0x5c7464: ldur            w7, [x0, #0x57]
    // 0x5c7468: DecompressPointer r7
    //     0x5c7468: add             x7, x7, HEAP, lsl #32
    // 0x5c746c: stur            x7, [fp, #-0x20]
    // 0x5c7470: LoadField: d0 = r0->field_67
    //     0x5c7470: ldur            d0, [x0, #0x67]
    // 0x5c7474: stur            d0, [fp, #-0xa0]
    // 0x5c7478: LoadField: d1 = r0->field_6f
    //     0x5c7478: ldur            d1, [x0, #0x6f]
    // 0x5c747c: stur            d1, [fp, #-0x98]
    // 0x5c7480: LoadField: d6 = r0->field_77
    //     0x5c7480: ldur            d6, [x0, #0x77]
    // 0x5c7484: stur            d6, [fp, #-0x90]
    // 0x5c7488: LoadField: d7 = r0->field_7f
    //     0x5c7488: ldur            d7, [x0, #0x7f]
    // 0x5c748c: stur            d7, [fp, #-0x88]
    // 0x5c7490: LoadField: d8 = r0->field_87
    //     0x5c7490: ldur            d8, [x0, #0x87]
    // 0x5c7494: stur            d8, [fp, #-0x80]
    // 0x5c7498: LoadField: d9 = r0->field_af
    //     0x5c7498: ldur            d9, [x0, #0xaf]
    // 0x5c749c: stur            d9, [fp, #-0x78]
    // 0x5c74a0: LoadField: d10 = r0->field_b7
    //     0x5c74a0: ldur            d10, [x0, #0xb7]
    // 0x5c74a4: stur            d10, [fp, #-0x70]
    // 0x5c74a8: LoadField: r8 = r0->field_7
    //     0x5c74a8: ldur            x8, [x0, #7]
    // 0x5c74ac: stur            x8, [fp, #-0x18]
    // 0x5c74b0: r0 = PointerCancelEvent()
    //     0x5c74b0: bl              #0x509714  ; AllocatePointerCancelEventStub -> PointerCancelEvent (size=0xb4)
    // 0x5c74b4: mov             x1, x0
    // 0x5c74b8: ldur            x0, [fp, #-0x18]
    // 0x5c74bc: StoreField: r1->field_7 = r0
    //     0x5c74bc: stur            x0, [x1, #7]
    // 0x5c74c0: ldur            x2, [fp, #-0x48]
    // 0x5c74c4: StoreField: r1->field_f = r2
    //     0x5c74c4: stur            w2, [x1, #0xf]
    // 0x5c74c8: ldur            x0, [fp, #-0x38]
    // 0x5c74cc: StoreField: r1->field_13 = r0
    //     0x5c74cc: stur            x0, [x1, #0x13]
    // 0x5c74d0: ldur            x3, [fp, #-0x40]
    // 0x5c74d4: StoreField: r1->field_1b = r3
    //     0x5c74d4: stur            w3, [x1, #0x1b]
    // 0x5c74d8: ldur            x0, [fp, #-0x30]
    // 0x5c74dc: StoreField: r1->field_1f = r0
    //     0x5c74dc: stur            x0, [x1, #0x1f]
    // 0x5c74e0: ldur            x4, [fp, #-0x10]
    // 0x5c74e4: StoreField: r1->field_27 = r4
    //     0x5c74e4: stur            w4, [x1, #0x27]
    // 0x5c74e8: r5 = Instance_Offset
    //     0x5c74e8: ldr             x5, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c74ec: StoreField: r1->field_2b = r5
    //     0x5c74ec: stur            w5, [x1, #0x2b]
    // 0x5c74f0: ldur            x0, [fp, #-0x28]
    // 0x5c74f4: StoreField: r1->field_2f = r0
    //     0x5c74f4: stur            x0, [x1, #0x2f]
    // 0x5c74f8: r6 = false
    //     0x5c74f8: add             x6, NULL, #0x30  ; false
    // 0x5c74fc: StoreField: r1->field_37 = r6
    //     0x5c74fc: stur            w6, [x1, #0x37]
    // 0x5c7500: ldur            x0, [fp, #-0x20]
    // 0x5c7504: StoreField: r1->field_3b = r0
    //     0x5c7504: stur            w0, [x1, #0x3b]
    // 0x5c7508: d0 = 0.000000
    //     0x5c7508: eor             v0.16b, v0.16b, v0.16b
    // 0x5c750c: StoreField: r1->field_3f = d0
    //     0x5c750c: stur            d0, [x1, #0x3f]
    // 0x5c7510: ldur            d0, [fp, #-0xa0]
    // 0x5c7514: StoreField: r1->field_47 = d0
    //     0x5c7514: stur            d0, [x1, #0x47]
    // 0x5c7518: ldur            d0, [fp, #-0x98]
    // 0x5c751c: StoreField: r1->field_4f = d0
    //     0x5c751c: stur            d0, [x1, #0x4f]
    // 0x5c7520: ldur            d0, [fp, #-0x90]
    // 0x5c7524: StoreField: r1->field_57 = d0
    //     0x5c7524: stur            d0, [x1, #0x57]
    // 0x5c7528: ldur            d0, [fp, #-0x88]
    // 0x5c752c: StoreField: r1->field_5f = d0
    //     0x5c752c: stur            d0, [x1, #0x5f]
    // 0x5c7530: ldur            d0, [fp, #-0x80]
    // 0x5c7534: StoreField: r1->field_67 = d0
    //     0x5c7534: stur            d0, [x1, #0x67]
    // 0x5c7538: ldur            d0, [fp, #-0xb8]
    // 0x5c753c: StoreField: r1->field_6f = d0
    //     0x5c753c: stur            d0, [x1, #0x6f]
    // 0x5c7540: ldur            d1, [fp, #-0xc0]
    // 0x5c7544: StoreField: r1->field_77 = d1
    //     0x5c7544: stur            d1, [x1, #0x77]
    // 0x5c7548: ldur            d1, [fp, #-0xb0]
    // 0x5c754c: StoreField: r1->field_7f = d1
    //     0x5c754c: stur            d1, [x1, #0x7f]
    // 0x5c7550: ldur            d2, [fp, #-0xa8]
    // 0x5c7554: StoreField: r1->field_87 = d2
    //     0x5c7554: stur            d2, [x1, #0x87]
    // 0x5c7558: ldur            d0, [fp, #-0x78]
    // 0x5c755c: StoreField: r1->field_8f = d0
    //     0x5c755c: stur            d0, [x1, #0x8f]
    // 0x5c7560: ldur            d0, [fp, #-0x70]
    // 0x5c7564: StoreField: r1->field_97 = d0
    //     0x5c7564: stur            d0, [x1, #0x97]
    // 0x5c7568: r7 = 0
    //     0x5c7568: mov             x7, #0
    // 0x5c756c: StoreField: r1->field_9f = r7
    //     0x5c756c: stur            x7, [x1, #0x9f]
    // 0x5c7570: StoreField: r1->field_a7 = r6
    //     0x5c7570: stur            w6, [x1, #0xa7]
    // 0x5c7574: mov             x0, x1
    // 0x5c7578: LeaveFrame
    //     0x5c7578: mov             SP, fp
    //     0x5c757c: ldp             fp, lr, [SP], #0x10
    // 0x5c7580: ret
    //     0x5c7580: ret             
    // 0x5c7584: mov             x2, x4
    // 0x5c7588: ldur            x4, [fp, #-0x10]
    // 0x5c758c: mov             x3, x5
    // 0x5c7590: mov             v1.16b, v4.16b
    // 0x5c7594: mov             v2.16b, v5.16b
    // 0x5c7598: r5 = Instance_Offset
    //     0x5c7598: ldr             x5, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c759c: r6 = false
    //     0x5c759c: add             x6, NULL, #0x30  ; false
    // 0x5c75a0: r7 = 0
    //     0x5c75a0: mov             x7, #0
    // 0x5c75a4: d0 = 0.000000
    //     0x5c75a4: eor             v0.16b, v0.16b, v0.16b
    // 0x5c75a8: LoadField: r1 = r0->field_1f
    //     0x5c75a8: ldur            x1, [x0, #0x1f]
    // 0x5c75ac: stur            x1, [fp, #-0x28]
    // 0x5c75b0: LoadField: r8 = r0->field_57
    //     0x5c75b0: ldur            w8, [x0, #0x57]
    // 0x5c75b4: DecompressPointer r8
    //     0x5c75b4: add             x8, x8, HEAP, lsl #32
    // 0x5c75b8: stur            x8, [fp, #-0x20]
    // 0x5c75bc: LoadField: d3 = r0->field_67
    //     0x5c75bc: ldur            d3, [x0, #0x67]
    // 0x5c75c0: stur            d3, [fp, #-0x98]
    // 0x5c75c4: LoadField: d4 = r0->field_6f
    //     0x5c75c4: ldur            d4, [x0, #0x6f]
    // 0x5c75c8: stur            d4, [fp, #-0x90]
    // 0x5c75cc: LoadField: d5 = r0->field_77
    //     0x5c75cc: ldur            d5, [x0, #0x77]
    // 0x5c75d0: stur            d5, [fp, #-0x88]
    // 0x5c75d4: LoadField: d6 = r0->field_7f
    //     0x5c75d4: ldur            d6, [x0, #0x7f]
    // 0x5c75d8: stur            d6, [fp, #-0x80]
    // 0x5c75dc: LoadField: d7 = r0->field_af
    //     0x5c75dc: ldur            d7, [x0, #0xaf]
    // 0x5c75e0: stur            d7, [fp, #-0x78]
    // 0x5c75e4: LoadField: d8 = r0->field_b7
    //     0x5c75e4: ldur            d8, [x0, #0xb7]
    // 0x5c75e8: stur            d8, [fp, #-0x70]
    // 0x5c75ec: LoadField: r9 = r0->field_7
    //     0x5c75ec: ldur            x9, [x0, #7]
    // 0x5c75f0: stur            x9, [fp, #-0x18]
    // 0x5c75f4: r0 = PointerAddedEvent()
    //     0x5c75f4: bl              #0x5c84f4  ; AllocatePointerAddedEventStub -> PointerAddedEvent (size=0xb4)
    // 0x5c75f8: mov             x1, x0
    // 0x5c75fc: ldur            x0, [fp, #-0x18]
    // 0x5c7600: StoreField: r1->field_7 = r0
    //     0x5c7600: stur            x0, [x1, #7]
    // 0x5c7604: ldur            x2, [fp, #-0x48]
    // 0x5c7608: StoreField: r1->field_f = r2
    //     0x5c7608: stur            w2, [x1, #0xf]
    // 0x5c760c: r3 = 0
    //     0x5c760c: mov             x3, #0
    // 0x5c7610: StoreField: r1->field_13 = r3
    //     0x5c7610: stur            x3, [x1, #0x13]
    // 0x5c7614: ldur            x4, [fp, #-0x40]
    // 0x5c7618: StoreField: r1->field_1b = r4
    //     0x5c7618: stur            w4, [x1, #0x1b]
    // 0x5c761c: ldur            x0, [fp, #-0x28]
    // 0x5c7620: StoreField: r1->field_1f = r0
    //     0x5c7620: stur            x0, [x1, #0x1f]
    // 0x5c7624: ldur            x5, [fp, #-0x10]
    // 0x5c7628: StoreField: r1->field_27 = r5
    //     0x5c7628: stur            w5, [x1, #0x27]
    // 0x5c762c: r6 = Instance_Offset
    //     0x5c762c: ldr             x6, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c7630: StoreField: r1->field_2b = r6
    //     0x5c7630: stur            w6, [x1, #0x2b]
    // 0x5c7634: StoreField: r1->field_2f = r3
    //     0x5c7634: stur            x3, [x1, #0x2f]
    // 0x5c7638: r7 = false
    //     0x5c7638: add             x7, NULL, #0x30  ; false
    // 0x5c763c: StoreField: r1->field_37 = r7
    //     0x5c763c: stur            w7, [x1, #0x37]
    // 0x5c7640: ldur            x0, [fp, #-0x20]
    // 0x5c7644: StoreField: r1->field_3b = r0
    //     0x5c7644: stur            w0, [x1, #0x3b]
    // 0x5c7648: d0 = 0.000000
    //     0x5c7648: eor             v0.16b, v0.16b, v0.16b
    // 0x5c764c: StoreField: r1->field_3f = d0
    //     0x5c764c: stur            d0, [x1, #0x3f]
    // 0x5c7650: ldur            d1, [fp, #-0x98]
    // 0x5c7654: StoreField: r1->field_47 = d1
    //     0x5c7654: stur            d1, [x1, #0x47]
    // 0x5c7658: ldur            d1, [fp, #-0x90]
    // 0x5c765c: StoreField: r1->field_4f = d1
    //     0x5c765c: stur            d1, [x1, #0x4f]
    // 0x5c7660: ldur            d1, [fp, #-0x88]
    // 0x5c7664: StoreField: r1->field_57 = d1
    //     0x5c7664: stur            d1, [x1, #0x57]
    // 0x5c7668: ldur            d1, [fp, #-0x80]
    // 0x5c766c: StoreField: r1->field_5f = d1
    //     0x5c766c: stur            d1, [x1, #0x5f]
    // 0x5c7670: StoreField: r1->field_67 = d0
    //     0x5c7670: stur            d0, [x1, #0x67]
    // 0x5c7674: StoreField: r1->field_6f = d0
    //     0x5c7674: stur            d0, [x1, #0x6f]
    // 0x5c7678: StoreField: r1->field_77 = d0
    //     0x5c7678: stur            d0, [x1, #0x77]
    // 0x5c767c: ldur            d1, [fp, #-0xb0]
    // 0x5c7680: StoreField: r1->field_7f = d1
    //     0x5c7680: stur            d1, [x1, #0x7f]
    // 0x5c7684: ldur            d2, [fp, #-0xa8]
    // 0x5c7688: StoreField: r1->field_87 = d2
    //     0x5c7688: stur            d2, [x1, #0x87]
    // 0x5c768c: ldur            d0, [fp, #-0x78]
    // 0x5c7690: StoreField: r1->field_8f = d0
    //     0x5c7690: stur            d0, [x1, #0x8f]
    // 0x5c7694: ldur            d0, [fp, #-0x70]
    // 0x5c7698: StoreField: r1->field_97 = d0
    //     0x5c7698: stur            d0, [x1, #0x97]
    // 0x5c769c: StoreField: r1->field_9f = r3
    //     0x5c769c: stur            x3, [x1, #0x9f]
    // 0x5c76a0: StoreField: r1->field_a7 = r7
    //     0x5c76a0: stur            w7, [x1, #0xa7]
    // 0x5c76a4: mov             x0, x1
    // 0x5c76a8: LeaveFrame
    //     0x5c76a8: mov             SP, fp
    //     0x5c76ac: ldp             fp, lr, [SP], #0x10
    // 0x5c76b0: ret
    //     0x5c76b0: ret             
    // 0x5c76b4: mov             x2, x4
    // 0x5c76b8: mov             x4, x5
    // 0x5c76bc: ldur            x5, [fp, #-0x10]
    // 0x5c76c0: mov             v1.16b, v4.16b
    // 0x5c76c4: mov             v2.16b, v5.16b
    // 0x5c76c8: r6 = Instance_Offset
    //     0x5c76c8: ldr             x6, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c76cc: r7 = false
    //     0x5c76cc: add             x7, NULL, #0x30  ; false
    // 0x5c76d0: r3 = 0
    //     0x5c76d0: mov             x3, #0
    // 0x5c76d4: d0 = 0.000000
    //     0x5c76d4: eor             v0.16b, v0.16b, v0.16b
    // 0x5c76d8: LoadField: r1 = r0->field_1f
    //     0x5c76d8: ldur            x1, [x0, #0x1f]
    // 0x5c76dc: stur            x1, [fp, #-0x28]
    // 0x5c76e0: LoadField: r8 = r0->field_57
    //     0x5c76e0: ldur            w8, [x0, #0x57]
    // 0x5c76e4: DecompressPointer r8
    //     0x5c76e4: add             x8, x8, HEAP, lsl #32
    // 0x5c76e8: stur            x8, [fp, #-0x20]
    // 0x5c76ec: LoadField: d3 = r0->field_67
    //     0x5c76ec: ldur            d3, [x0, #0x67]
    // 0x5c76f0: stur            d3, [fp, #-0x80]
    // 0x5c76f4: LoadField: d4 = r0->field_6f
    //     0x5c76f4: ldur            d4, [x0, #0x6f]
    // 0x5c76f8: stur            d4, [fp, #-0x78]
    // 0x5c76fc: LoadField: d5 = r0->field_7f
    //     0x5c76fc: ldur            d5, [x0, #0x7f]
    // 0x5c7700: stur            d5, [fp, #-0x70]
    // 0x5c7704: LoadField: r9 = r0->field_7
    //     0x5c7704: ldur            x9, [x0, #7]
    // 0x5c7708: stur            x9, [fp, #-0x18]
    // 0x5c770c: r0 = PointerRemovedEvent()
    //     0x5c770c: bl              #0x5c84e8  ; AllocatePointerRemovedEventStub -> PointerRemovedEvent (size=0xb4)
    // 0x5c7710: mov             x1, x0
    // 0x5c7714: ldur            x0, [fp, #-0x18]
    // 0x5c7718: StoreField: r1->field_7 = r0
    //     0x5c7718: stur            x0, [x1, #7]
    // 0x5c771c: ldur            x2, [fp, #-0x48]
    // 0x5c7720: StoreField: r1->field_f = r2
    //     0x5c7720: stur            w2, [x1, #0xf]
    // 0x5c7724: r3 = 0
    //     0x5c7724: mov             x3, #0
    // 0x5c7728: StoreField: r1->field_13 = r3
    //     0x5c7728: stur            x3, [x1, #0x13]
    // 0x5c772c: ldur            x4, [fp, #-0x40]
    // 0x5c7730: StoreField: r1->field_1b = r4
    //     0x5c7730: stur            w4, [x1, #0x1b]
    // 0x5c7734: ldur            x0, [fp, #-0x28]
    // 0x5c7738: StoreField: r1->field_1f = r0
    //     0x5c7738: stur            x0, [x1, #0x1f]
    // 0x5c773c: ldur            x5, [fp, #-0x10]
    // 0x5c7740: StoreField: r1->field_27 = r5
    //     0x5c7740: stur            w5, [x1, #0x27]
    // 0x5c7744: r6 = Instance_Offset
    //     0x5c7744: ldr             x6, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c7748: StoreField: r1->field_2b = r6
    //     0x5c7748: stur            w6, [x1, #0x2b]
    // 0x5c774c: StoreField: r1->field_2f = r3
    //     0x5c774c: stur            x3, [x1, #0x2f]
    // 0x5c7750: r8 = false
    //     0x5c7750: add             x8, NULL, #0x30  ; false
    // 0x5c7754: StoreField: r1->field_37 = r8
    //     0x5c7754: stur            w8, [x1, #0x37]
    // 0x5c7758: ldur            x0, [fp, #-0x20]
    // 0x5c775c: StoreField: r1->field_3b = r0
    //     0x5c775c: stur            w0, [x1, #0x3b]
    // 0x5c7760: d2 = 0.000000
    //     0x5c7760: eor             v2.16b, v2.16b, v2.16b
    // 0x5c7764: StoreField: r1->field_3f = d2
    //     0x5c7764: stur            d2, [x1, #0x3f]
    // 0x5c7768: ldur            d0, [fp, #-0x80]
    // 0x5c776c: StoreField: r1->field_47 = d0
    //     0x5c776c: stur            d0, [x1, #0x47]
    // 0x5c7770: ldur            d0, [fp, #-0x78]
    // 0x5c7774: StoreField: r1->field_4f = d0
    //     0x5c7774: stur            d0, [x1, #0x4f]
    // 0x5c7778: StoreField: r1->field_57 = d2
    //     0x5c7778: stur            d2, [x1, #0x57]
    // 0x5c777c: ldur            d0, [fp, #-0x70]
    // 0x5c7780: StoreField: r1->field_5f = d0
    //     0x5c7780: stur            d0, [x1, #0x5f]
    // 0x5c7784: StoreField: r1->field_67 = d2
    //     0x5c7784: stur            d2, [x1, #0x67]
    // 0x5c7788: StoreField: r1->field_6f = d2
    //     0x5c7788: stur            d2, [x1, #0x6f]
    // 0x5c778c: StoreField: r1->field_77 = d2
    //     0x5c778c: stur            d2, [x1, #0x77]
    // 0x5c7790: ldur            d3, [fp, #-0xb0]
    // 0x5c7794: StoreField: r1->field_7f = d3
    //     0x5c7794: stur            d3, [x1, #0x7f]
    // 0x5c7798: ldur            d4, [fp, #-0xa8]
    // 0x5c779c: StoreField: r1->field_87 = d4
    //     0x5c779c: stur            d4, [x1, #0x87]
    // 0x5c77a0: StoreField: r1->field_8f = d2
    //     0x5c77a0: stur            d2, [x1, #0x8f]
    // 0x5c77a4: StoreField: r1->field_97 = d2
    //     0x5c77a4: stur            d2, [x1, #0x97]
    // 0x5c77a8: StoreField: r1->field_9f = r3
    //     0x5c77a8: stur            x3, [x1, #0x9f]
    // 0x5c77ac: StoreField: r1->field_a7 = r8
    //     0x5c77ac: stur            w8, [x1, #0xa7]
    // 0x5c77b0: mov             x0, x1
    // 0x5c77b4: LeaveFrame
    //     0x5c77b4: mov             SP, fp
    //     0x5c77b8: ldp             fp, lr, [SP], #0x10
    // 0x5c77bc: ret
    //     0x5c77bc: ret             
    // 0x5c77c0: mov             x2, x4
    // 0x5c77c4: mov             x4, x5
    // 0x5c77c8: ldur            x5, [fp, #-0x10]
    // 0x5c77cc: mov             v1.16b, v2.16b
    // 0x5c77d0: mov             v0.16b, v3.16b
    // 0x5c77d4: mov             v3.16b, v4.16b
    // 0x5c77d8: mov             v4.16b, v5.16b
    // 0x5c77dc: r6 = Instance_Offset
    //     0x5c77dc: ldr             x6, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c77e0: r8 = false
    //     0x5c77e0: add             x8, NULL, #0x30  ; false
    // 0x5c77e4: r3 = 0
    //     0x5c77e4: mov             x3, #0
    // 0x5c77e8: d2 = 0.000000
    //     0x5c77e8: eor             v2.16b, v2.16b, v2.16b
    // 0x5c77ec: cmp             x7, #3
    // 0x5c77f0: b.gt            #0x5c7930
    // 0x5c77f4: LoadField: r6 = r0->field_1f
    //     0x5c77f4: ldur            x6, [x0, #0x1f]
    // 0x5c77f8: stur            x6, [fp, #-0x30]
    // 0x5c77fc: LoadField: r7 = r0->field_4f
    //     0x5c77fc: ldur            x7, [x0, #0x4f]
    // 0x5c7800: stur            x7, [fp, #-0x28]
    // 0x5c7804: LoadField: r9 = r0->field_57
    //     0x5c7804: ldur            w9, [x0, #0x57]
    // 0x5c7808: DecompressPointer r9
    //     0x5c7808: add             x9, x9, HEAP, lsl #32
    // 0x5c780c: stur            x9, [fp, #-0x50]
    // 0x5c7810: LoadField: d5 = r0->field_67
    //     0x5c7810: ldur            d5, [x0, #0x67]
    // 0x5c7814: stur            d5, [fp, #-0xa0]
    // 0x5c7818: LoadField: d6 = r0->field_6f
    //     0x5c7818: ldur            d6, [x0, #0x6f]
    // 0x5c781c: stur            d6, [fp, #-0x98]
    // 0x5c7820: LoadField: d7 = r0->field_77
    //     0x5c7820: ldur            d7, [x0, #0x77]
    // 0x5c7824: stur            d7, [fp, #-0x90]
    // 0x5c7828: LoadField: d8 = r0->field_7f
    //     0x5c7828: ldur            d8, [x0, #0x7f]
    // 0x5c782c: stur            d8, [fp, #-0x88]
    // 0x5c7830: LoadField: d9 = r0->field_87
    //     0x5c7830: ldur            d9, [x0, #0x87]
    // 0x5c7834: stur            d9, [fp, #-0x80]
    // 0x5c7838: LoadField: d10 = r0->field_af
    //     0x5c7838: ldur            d10, [x0, #0xaf]
    // 0x5c783c: stur            d10, [fp, #-0x78]
    // 0x5c7840: LoadField: d11 = r0->field_b7
    //     0x5c7840: ldur            d11, [x0, #0xb7]
    // 0x5c7844: stur            d11, [fp, #-0x70]
    // 0x5c7848: LoadField: r10 = r0->field_5b
    //     0x5c7848: ldur            w10, [x0, #0x5b]
    // 0x5c784c: DecompressPointer r10
    //     0x5c784c: add             x10, x10, HEAP, lsl #32
    // 0x5c7850: stur            x10, [fp, #-0x20]
    // 0x5c7854: LoadField: r11 = r0->field_7
    //     0x5c7854: ldur            x11, [x0, #7]
    // 0x5c7858: stur            x11, [fp, #-0x18]
    // 0x5c785c: r0 = PointerHoverEvent()
    //     0x5c785c: bl              #0x5c84dc  ; AllocatePointerHoverEventStub -> PointerHoverEvent (size=0xb4)
    // 0x5c7860: mov             x1, x0
    // 0x5c7864: ldur            x0, [fp, #-0x18]
    // 0x5c7868: StoreField: r1->field_7 = r0
    //     0x5c7868: stur            x0, [x1, #7]
    // 0x5c786c: ldur            x2, [fp, #-0x48]
    // 0x5c7870: StoreField: r1->field_f = r2
    //     0x5c7870: stur            w2, [x1, #0xf]
    // 0x5c7874: r3 = 0
    //     0x5c7874: mov             x3, #0
    // 0x5c7878: StoreField: r1->field_13 = r3
    //     0x5c7878: stur            x3, [x1, #0x13]
    // 0x5c787c: ldur            x4, [fp, #-0x40]
    // 0x5c7880: StoreField: r1->field_1b = r4
    //     0x5c7880: stur            w4, [x1, #0x1b]
    // 0x5c7884: ldur            x0, [fp, #-0x30]
    // 0x5c7888: StoreField: r1->field_1f = r0
    //     0x5c7888: stur            x0, [x1, #0x1f]
    // 0x5c788c: ldur            x5, [fp, #-0x10]
    // 0x5c7890: StoreField: r1->field_27 = r5
    //     0x5c7890: stur            w5, [x1, #0x27]
    // 0x5c7894: ldur            x4, [fp, #-0x58]
    // 0x5c7898: StoreField: r1->field_2b = r4
    //     0x5c7898: stur            w4, [x1, #0x2b]
    // 0x5c789c: ldur            x0, [fp, #-0x28]
    // 0x5c78a0: StoreField: r1->field_2f = r0
    //     0x5c78a0: stur            x0, [x1, #0x2f]
    // 0x5c78a4: r7 = false
    //     0x5c78a4: add             x7, NULL, #0x30  ; false
    // 0x5c78a8: StoreField: r1->field_37 = r7
    //     0x5c78a8: stur            w7, [x1, #0x37]
    // 0x5c78ac: ldur            x0, [fp, #-0x50]
    // 0x5c78b0: StoreField: r1->field_3b = r0
    //     0x5c78b0: stur            w0, [x1, #0x3b]
    // 0x5c78b4: d0 = 0.000000
    //     0x5c78b4: eor             v0.16b, v0.16b, v0.16b
    // 0x5c78b8: StoreField: r1->field_3f = d0
    //     0x5c78b8: stur            d0, [x1, #0x3f]
    // 0x5c78bc: ldur            d0, [fp, #-0xa0]
    // 0x5c78c0: StoreField: r1->field_47 = d0
    //     0x5c78c0: stur            d0, [x1, #0x47]
    // 0x5c78c4: ldur            d0, [fp, #-0x98]
    // 0x5c78c8: StoreField: r1->field_4f = d0
    //     0x5c78c8: stur            d0, [x1, #0x4f]
    // 0x5c78cc: ldur            d0, [fp, #-0x90]
    // 0x5c78d0: StoreField: r1->field_57 = d0
    //     0x5c78d0: stur            d0, [x1, #0x57]
    // 0x5c78d4: ldur            d0, [fp, #-0x88]
    // 0x5c78d8: StoreField: r1->field_5f = d0
    //     0x5c78d8: stur            d0, [x1, #0x5f]
    // 0x5c78dc: ldur            d0, [fp, #-0x80]
    // 0x5c78e0: StoreField: r1->field_67 = d0
    //     0x5c78e0: stur            d0, [x1, #0x67]
    // 0x5c78e4: ldur            d1, [fp, #-0xb8]
    // 0x5c78e8: StoreField: r1->field_6f = d1
    //     0x5c78e8: stur            d1, [x1, #0x6f]
    // 0x5c78ec: ldur            d2, [fp, #-0xc0]
    // 0x5c78f0: StoreField: r1->field_77 = d2
    //     0x5c78f0: stur            d2, [x1, #0x77]
    // 0x5c78f4: ldur            d3, [fp, #-0xb0]
    // 0x5c78f8: StoreField: r1->field_7f = d3
    //     0x5c78f8: stur            d3, [x1, #0x7f]
    // 0x5c78fc: ldur            d4, [fp, #-0xa8]
    // 0x5c7900: StoreField: r1->field_87 = d4
    //     0x5c7900: stur            d4, [x1, #0x87]
    // 0x5c7904: ldur            d0, [fp, #-0x78]
    // 0x5c7908: StoreField: r1->field_8f = d0
    //     0x5c7908: stur            d0, [x1, #0x8f]
    // 0x5c790c: ldur            d0, [fp, #-0x70]
    // 0x5c7910: StoreField: r1->field_97 = d0
    //     0x5c7910: stur            d0, [x1, #0x97]
    // 0x5c7914: StoreField: r1->field_9f = r3
    //     0x5c7914: stur            x3, [x1, #0x9f]
    // 0x5c7918: ldur            x0, [fp, #-0x20]
    // 0x5c791c: StoreField: r1->field_a7 = r0
    //     0x5c791c: stur            w0, [x1, #0xa7]
    // 0x5c7920: mov             x0, x1
    // 0x5c7924: LeaveFrame
    //     0x5c7924: mov             SP, fp
    //     0x5c7928: ldp             fp, lr, [SP], #0x10
    // 0x5c792c: ret
    //     0x5c792c: ret             
    // 0x5c7930: mov             v31.16b, v0.16b
    // 0x5c7934: mov             v0.16b, v1.16b
    // 0x5c7938: mov             v1.16b, v31.16b
    // 0x5c793c: mov             v31.16b, v2.16b
    // 0x5c7940: mov             v2.16b, v0.16b
    // 0x5c7944: mov             v0.16b, v31.16b
    // 0x5c7948: mov             x7, x8
    // 0x5c794c: LoadField: r1 = r0->field_27
    //     0x5c794c: ldur            x1, [x0, #0x27]
    // 0x5c7950: stur            x1, [fp, #-0x38]
    // 0x5c7954: LoadField: r8 = r0->field_1f
    //     0x5c7954: ldur            x8, [x0, #0x1f]
    // 0x5c7958: stur            x8, [fp, #-0x30]
    // 0x5c795c: LoadField: r9 = r0->field_4f
    //     0x5c795c: ldur            x9, [x0, #0x4f]
    // 0x5c7960: LoadField: r10 = r4->field_7
    //     0x5c7960: ldur            x10, [x4, #7]
    // 0x5c7964: cmp             x10, #2
    // 0x5c7968: b.gt            #0x5c7980
    // 0x5c796c: cmp             x10, #1
    // 0x5c7970: b.gt            #0x5c7990
    // 0x5c7974: cmp             x10, #0
    // 0x5c7978: b.gt            #0x5c79a4
    // 0x5c797c: b               #0x5c7990
    // 0x5c7980: cmp             x10, #4
    // 0x5c7984: b.gt            #0x5c799c
    // 0x5c7988: cmp             x10, #3
    // 0x5c798c: b.gt            #0x5c79a4
    // 0x5c7990: cbnz            x9, #0x5c79a4
    // 0x5c7994: r9 = 1
    //     0x5c7994: mov             x9, #1
    // 0x5c7998: b               #0x5c79a4
    // 0x5c799c: cbnz            x9, #0x5c79a4
    // 0x5c79a0: r9 = 1
    //     0x5c79a0: mov             x9, #1
    // 0x5c79a4: stur            x9, [fp, #-0x28]
    // 0x5c79a8: LoadField: r10 = r0->field_57
    //     0x5c79a8: ldur            w10, [x0, #0x57]
    // 0x5c79ac: DecompressPointer r10
    //     0x5c79ac: add             x10, x10, HEAP, lsl #32
    // 0x5c79b0: stur            x10, [fp, #-0x20]
    // 0x5c79b4: LoadField: d5 = r0->field_5f
    //     0x5c79b4: ldur            d5, [x0, #0x5f]
    // 0x5c79b8: stur            d5, [fp, #-0xa0]
    // 0x5c79bc: LoadField: d6 = r0->field_67
    //     0x5c79bc: ldur            d6, [x0, #0x67]
    // 0x5c79c0: stur            d6, [fp, #-0x98]
    // 0x5c79c4: LoadField: d7 = r0->field_6f
    //     0x5c79c4: ldur            d7, [x0, #0x6f]
    // 0x5c79c8: stur            d7, [fp, #-0x90]
    // 0x5c79cc: LoadField: d8 = r0->field_7f
    //     0x5c79cc: ldur            d8, [x0, #0x7f]
    // 0x5c79d0: stur            d8, [fp, #-0x88]
    // 0x5c79d4: LoadField: d9 = r0->field_87
    //     0x5c79d4: ldur            d9, [x0, #0x87]
    // 0x5c79d8: stur            d9, [fp, #-0x80]
    // 0x5c79dc: LoadField: d10 = r0->field_af
    //     0x5c79dc: ldur            d10, [x0, #0xaf]
    // 0x5c79e0: stur            d10, [fp, #-0x78]
    // 0x5c79e4: LoadField: d11 = r0->field_b7
    //     0x5c79e4: ldur            d11, [x0, #0xb7]
    // 0x5c79e8: stur            d11, [fp, #-0x70]
    // 0x5c79ec: LoadField: r11 = r0->field_7
    //     0x5c79ec: ldur            x11, [x0, #7]
    // 0x5c79f0: stur            x11, [fp, #-0x18]
    // 0x5c79f4: r0 = PointerDownEvent()
    //     0x5c79f4: bl              #0x5c84d0  ; AllocatePointerDownEventStub -> PointerDownEvent (size=0xb4)
    // 0x5c79f8: mov             x1, x0
    // 0x5c79fc: ldur            x0, [fp, #-0x18]
    // 0x5c7a00: StoreField: r1->field_7 = r0
    //     0x5c7a00: stur            x0, [x1, #7]
    // 0x5c7a04: ldur            x5, [fp, #-0x48]
    // 0x5c7a08: StoreField: r1->field_f = r5
    //     0x5c7a08: stur            w5, [x1, #0xf]
    // 0x5c7a0c: ldur            x0, [fp, #-0x38]
    // 0x5c7a10: StoreField: r1->field_13 = r0
    //     0x5c7a10: stur            x0, [x1, #0x13]
    // 0x5c7a14: ldur            x6, [fp, #-0x40]
    // 0x5c7a18: StoreField: r1->field_1b = r6
    //     0x5c7a18: stur            w6, [x1, #0x1b]
    // 0x5c7a1c: ldur            x0, [fp, #-0x30]
    // 0x5c7a20: StoreField: r1->field_1f = r0
    //     0x5c7a20: stur            x0, [x1, #0x1f]
    // 0x5c7a24: ldur            x8, [fp, #-0x10]
    // 0x5c7a28: StoreField: r1->field_27 = r8
    //     0x5c7a28: stur            w8, [x1, #0x27]
    // 0x5c7a2c: r9 = Instance_Offset
    //     0x5c7a2c: ldr             x9, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c7a30: StoreField: r1->field_2b = r9
    //     0x5c7a30: stur            w9, [x1, #0x2b]
    // 0x5c7a34: ldur            x0, [fp, #-0x28]
    // 0x5c7a38: StoreField: r1->field_2f = r0
    //     0x5c7a38: stur            x0, [x1, #0x2f]
    // 0x5c7a3c: r10 = true
    //     0x5c7a3c: add             x10, NULL, #0x20  ; true
    // 0x5c7a40: StoreField: r1->field_37 = r10
    //     0x5c7a40: stur            w10, [x1, #0x37]
    // 0x5c7a44: ldur            x0, [fp, #-0x20]
    // 0x5c7a48: StoreField: r1->field_3b = r0
    //     0x5c7a48: stur            w0, [x1, #0x3b]
    // 0x5c7a4c: ldur            d0, [fp, #-0xa0]
    // 0x5c7a50: StoreField: r1->field_3f = d0
    //     0x5c7a50: stur            d0, [x1, #0x3f]
    // 0x5c7a54: ldur            d0, [fp, #-0x98]
    // 0x5c7a58: StoreField: r1->field_47 = d0
    //     0x5c7a58: stur            d0, [x1, #0x47]
    // 0x5c7a5c: ldur            d0, [fp, #-0x90]
    // 0x5c7a60: StoreField: r1->field_4f = d0
    //     0x5c7a60: stur            d0, [x1, #0x4f]
    // 0x5c7a64: d0 = 0.000000
    //     0x5c7a64: eor             v0.16b, v0.16b, v0.16b
    // 0x5c7a68: StoreField: r1->field_57 = d0
    //     0x5c7a68: stur            d0, [x1, #0x57]
    // 0x5c7a6c: ldur            d0, [fp, #-0x88]
    // 0x5c7a70: StoreField: r1->field_5f = d0
    //     0x5c7a70: stur            d0, [x1, #0x5f]
    // 0x5c7a74: ldur            d0, [fp, #-0x80]
    // 0x5c7a78: StoreField: r1->field_67 = d0
    //     0x5c7a78: stur            d0, [x1, #0x67]
    // 0x5c7a7c: ldur            d1, [fp, #-0xb8]
    // 0x5c7a80: StoreField: r1->field_6f = d1
    //     0x5c7a80: stur            d1, [x1, #0x6f]
    // 0x5c7a84: ldur            d2, [fp, #-0xc0]
    // 0x5c7a88: StoreField: r1->field_77 = d2
    //     0x5c7a88: stur            d2, [x1, #0x77]
    // 0x5c7a8c: ldur            d3, [fp, #-0xb0]
    // 0x5c7a90: StoreField: r1->field_7f = d3
    //     0x5c7a90: stur            d3, [x1, #0x7f]
    // 0x5c7a94: ldur            d4, [fp, #-0xa8]
    // 0x5c7a98: StoreField: r1->field_87 = d4
    //     0x5c7a98: stur            d4, [x1, #0x87]
    // 0x5c7a9c: ldur            d0, [fp, #-0x78]
    // 0x5c7aa0: StoreField: r1->field_8f = d0
    //     0x5c7aa0: stur            d0, [x1, #0x8f]
    // 0x5c7aa4: ldur            d0, [fp, #-0x70]
    // 0x5c7aa8: StoreField: r1->field_97 = d0
    //     0x5c7aa8: stur            d0, [x1, #0x97]
    // 0x5c7aac: r11 = 0
    //     0x5c7aac: mov             x11, #0
    // 0x5c7ab0: StoreField: r1->field_9f = r11
    //     0x5c7ab0: stur            x11, [x1, #0x9f]
    // 0x5c7ab4: r12 = false
    //     0x5c7ab4: add             x12, NULL, #0x30  ; false
    // 0x5c7ab8: StoreField: r1->field_a7 = r12
    //     0x5c7ab8: stur            w12, [x1, #0xa7]
    // 0x5c7abc: mov             x0, x1
    // 0x5c7ac0: LeaveFrame
    //     0x5c7ac0: mov             SP, fp
    //     0x5c7ac4: ldp             fp, lr, [SP], #0x10
    // 0x5c7ac8: ret
    //     0x5c7ac8: ret             
    // 0x5c7acc: ldur            x8, [fp, #-0x10]
    // 0x5c7ad0: mov             x6, x5
    // 0x5c7ad4: mov             x5, x4
    // 0x5c7ad8: mov             x4, x1
    // 0x5c7adc: mov             v1.16b, v3.16b
    // 0x5c7ae0: mov             v3.16b, v4.16b
    // 0x5c7ae4: mov             v4.16b, v5.16b
    // 0x5c7ae8: r10 = true
    //     0x5c7ae8: add             x10, NULL, #0x20  ; true
    // 0x5c7aec: r9 = Instance_Offset
    //     0x5c7aec: ldr             x9, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c7af0: r12 = false
    //     0x5c7af0: add             x12, NULL, #0x30  ; false
    // 0x5c7af4: r11 = 0
    //     0x5c7af4: mov             x11, #0
    // 0x5c7af8: d0 = 0.000000
    //     0x5c7af8: eor             v0.16b, v0.16b, v0.16b
    // 0x5c7afc: cmp             x7, #7
    // 0x5c7b00: b.gt            #0x5c7ee4
    // 0x5c7b04: cmp             x7, #6
    // 0x5c7b08: b.gt            #0x5c7e04
    // 0x5c7b0c: cmp             x7, #5
    // 0x5c7b10: b.gt            #0x5c7ca8
    // 0x5c7b14: LoadField: r1 = r0->field_27
    //     0x5c7b14: ldur            x1, [x0, #0x27]
    // 0x5c7b18: stur            x1, [fp, #-0x60]
    // 0x5c7b1c: LoadField: r2 = r0->field_1f
    //     0x5c7b1c: ldur            x2, [x0, #0x1f]
    // 0x5c7b20: stur            x2, [fp, #-0x38]
    // 0x5c7b24: LoadField: r3 = r0->field_4f
    //     0x5c7b24: ldur            x3, [x0, #0x4f]
    // 0x5c7b28: LoadField: r7 = r6->field_7
    //     0x5c7b28: ldur            x7, [x6, #7]
    // 0x5c7b2c: cmp             x7, #2
    // 0x5c7b30: b.gt            #0x5c7b48
    // 0x5c7b34: cmp             x7, #1
    // 0x5c7b38: b.gt            #0x5c7b58
    // 0x5c7b3c: cmp             x7, #0
    // 0x5c7b40: b.gt            #0x5c7b6c
    // 0x5c7b44: b               #0x5c7b58
    // 0x5c7b48: cmp             x7, #4
    // 0x5c7b4c: b.gt            #0x5c7b64
    // 0x5c7b50: cmp             x7, #3
    // 0x5c7b54: b.gt            #0x5c7b6c
    // 0x5c7b58: cbnz            x3, #0x5c7b6c
    // 0x5c7b5c: r3 = 1
    //     0x5c7b5c: mov             x3, #1
    // 0x5c7b60: b               #0x5c7b6c
    // 0x5c7b64: cbnz            x3, #0x5c7b6c
    // 0x5c7b68: r3 = 1
    //     0x5c7b68: mov             x3, #1
    // 0x5c7b6c: stur            x3, [fp, #-0x30]
    // 0x5c7b70: LoadField: r7 = r0->field_57
    //     0x5c7b70: ldur            w7, [x0, #0x57]
    // 0x5c7b74: DecompressPointer r7
    //     0x5c7b74: add             x7, x7, HEAP, lsl #32
    // 0x5c7b78: stur            x7, [fp, #-0x50]
    // 0x5c7b7c: LoadField: d5 = r0->field_5f
    //     0x5c7b7c: ldur            d5, [x0, #0x5f]
    // 0x5c7b80: stur            d5, [fp, #-0xa0]
    // 0x5c7b84: LoadField: d6 = r0->field_67
    //     0x5c7b84: ldur            d6, [x0, #0x67]
    // 0x5c7b88: stur            d6, [fp, #-0x98]
    // 0x5c7b8c: LoadField: d7 = r0->field_6f
    //     0x5c7b8c: ldur            d7, [x0, #0x6f]
    // 0x5c7b90: stur            d7, [fp, #-0x90]
    // 0x5c7b94: LoadField: d8 = r0->field_7f
    //     0x5c7b94: ldur            d8, [x0, #0x7f]
    // 0x5c7b98: stur            d8, [fp, #-0x88]
    // 0x5c7b9c: LoadField: d9 = r0->field_87
    //     0x5c7b9c: ldur            d9, [x0, #0x87]
    // 0x5c7ba0: stur            d9, [fp, #-0x80]
    // 0x5c7ba4: LoadField: d10 = r0->field_af
    //     0x5c7ba4: ldur            d10, [x0, #0xaf]
    // 0x5c7ba8: stur            d10, [fp, #-0x78]
    // 0x5c7bac: LoadField: d11 = r0->field_b7
    //     0x5c7bac: ldur            d11, [x0, #0xb7]
    // 0x5c7bb0: stur            d11, [fp, #-0x70]
    // 0x5c7bb4: LoadField: r9 = r0->field_bf
    //     0x5c7bb4: ldur            x9, [x0, #0xbf]
    // 0x5c7bb8: stur            x9, [fp, #-0x28]
    // 0x5c7bbc: LoadField: r11 = r0->field_5b
    //     0x5c7bbc: ldur            w11, [x0, #0x5b]
    // 0x5c7bc0: DecompressPointer r11
    //     0x5c7bc0: add             x11, x11, HEAP, lsl #32
    // 0x5c7bc4: stur            x11, [fp, #-0x20]
    // 0x5c7bc8: LoadField: r12 = r0->field_7
    //     0x5c7bc8: ldur            x12, [x0, #7]
    // 0x5c7bcc: stur            x12, [fp, #-0x18]
    // 0x5c7bd0: r0 = PointerMoveEvent()
    //     0x5c7bd0: bl              #0x5c84c4  ; AllocatePointerMoveEventStub -> PointerMoveEvent (size=0xb4)
    // 0x5c7bd4: mov             x1, x0
    // 0x5c7bd8: ldur            x0, [fp, #-0x18]
    // 0x5c7bdc: StoreField: r1->field_7 = r0
    //     0x5c7bdc: stur            x0, [x1, #7]
    // 0x5c7be0: ldur            x2, [fp, #-0x48]
    // 0x5c7be4: StoreField: r1->field_f = r2
    //     0x5c7be4: stur            w2, [x1, #0xf]
    // 0x5c7be8: ldur            x0, [fp, #-0x60]
    // 0x5c7bec: StoreField: r1->field_13 = r0
    //     0x5c7bec: stur            x0, [x1, #0x13]
    // 0x5c7bf0: ldur            x3, [fp, #-0x40]
    // 0x5c7bf4: StoreField: r1->field_1b = r3
    //     0x5c7bf4: stur            w3, [x1, #0x1b]
    // 0x5c7bf8: ldur            x0, [fp, #-0x38]
    // 0x5c7bfc: StoreField: r1->field_1f = r0
    //     0x5c7bfc: stur            x0, [x1, #0x1f]
    // 0x5c7c00: ldur            x4, [fp, #-0x10]
    // 0x5c7c04: StoreField: r1->field_27 = r4
    //     0x5c7c04: stur            w4, [x1, #0x27]
    // 0x5c7c08: ldur            x0, [fp, #-0x58]
    // 0x5c7c0c: StoreField: r1->field_2b = r0
    //     0x5c7c0c: stur            w0, [x1, #0x2b]
    // 0x5c7c10: ldur            x0, [fp, #-0x30]
    // 0x5c7c14: StoreField: r1->field_2f = r0
    //     0x5c7c14: stur            x0, [x1, #0x2f]
    // 0x5c7c18: r0 = true
    //     0x5c7c18: add             x0, NULL, #0x20  ; true
    // 0x5c7c1c: StoreField: r1->field_37 = r0
    //     0x5c7c1c: stur            w0, [x1, #0x37]
    // 0x5c7c20: ldur            x0, [fp, #-0x50]
    // 0x5c7c24: StoreField: r1->field_3b = r0
    //     0x5c7c24: stur            w0, [x1, #0x3b]
    // 0x5c7c28: ldur            d0, [fp, #-0xa0]
    // 0x5c7c2c: StoreField: r1->field_3f = d0
    //     0x5c7c2c: stur            d0, [x1, #0x3f]
    // 0x5c7c30: ldur            d0, [fp, #-0x98]
    // 0x5c7c34: StoreField: r1->field_47 = d0
    //     0x5c7c34: stur            d0, [x1, #0x47]
    // 0x5c7c38: ldur            d0, [fp, #-0x90]
    // 0x5c7c3c: StoreField: r1->field_4f = d0
    //     0x5c7c3c: stur            d0, [x1, #0x4f]
    // 0x5c7c40: d0 = 0.000000
    //     0x5c7c40: eor             v0.16b, v0.16b, v0.16b
    // 0x5c7c44: StoreField: r1->field_57 = d0
    //     0x5c7c44: stur            d0, [x1, #0x57]
    // 0x5c7c48: ldur            d0, [fp, #-0x88]
    // 0x5c7c4c: StoreField: r1->field_5f = d0
    //     0x5c7c4c: stur            d0, [x1, #0x5f]
    // 0x5c7c50: ldur            d0, [fp, #-0x80]
    // 0x5c7c54: StoreField: r1->field_67 = d0
    //     0x5c7c54: stur            d0, [x1, #0x67]
    // 0x5c7c58: ldur            d0, [fp, #-0xb8]
    // 0x5c7c5c: StoreField: r1->field_6f = d0
    //     0x5c7c5c: stur            d0, [x1, #0x6f]
    // 0x5c7c60: ldur            d1, [fp, #-0xc0]
    // 0x5c7c64: StoreField: r1->field_77 = d1
    //     0x5c7c64: stur            d1, [x1, #0x77]
    // 0x5c7c68: ldur            d2, [fp, #-0xb0]
    // 0x5c7c6c: StoreField: r1->field_7f = d2
    //     0x5c7c6c: stur            d2, [x1, #0x7f]
    // 0x5c7c70: ldur            d3, [fp, #-0xa8]
    // 0x5c7c74: StoreField: r1->field_87 = d3
    //     0x5c7c74: stur            d3, [x1, #0x87]
    // 0x5c7c78: ldur            d0, [fp, #-0x78]
    // 0x5c7c7c: StoreField: r1->field_8f = d0
    //     0x5c7c7c: stur            d0, [x1, #0x8f]
    // 0x5c7c80: ldur            d0, [fp, #-0x70]
    // 0x5c7c84: StoreField: r1->field_97 = d0
    //     0x5c7c84: stur            d0, [x1, #0x97]
    // 0x5c7c88: ldur            x0, [fp, #-0x28]
    // 0x5c7c8c: StoreField: r1->field_9f = r0
    //     0x5c7c8c: stur            x0, [x1, #0x9f]
    // 0x5c7c90: ldur            x0, [fp, #-0x20]
    // 0x5c7c94: StoreField: r1->field_a7 = r0
    //     0x5c7c94: stur            w0, [x1, #0xa7]
    // 0x5c7c98: mov             x0, x1
    // 0x5c7c9c: LeaveFrame
    //     0x5c7c9c: mov             SP, fp
    //     0x5c7ca0: ldp             fp, lr, [SP], #0x10
    // 0x5c7ca4: ret
    //     0x5c7ca4: ret             
    // 0x5c7ca8: mov             x4, x8
    // 0x5c7cac: mov             x2, x5
    // 0x5c7cb0: mov             x3, x6
    // 0x5c7cb4: mov             v0.16b, v1.16b
    // 0x5c7cb8: mov             v1.16b, v2.16b
    // 0x5c7cbc: mov             v2.16b, v3.16b
    // 0x5c7cc0: mov             v3.16b, v4.16b
    // 0x5c7cc4: LoadField: r1 = r0->field_27
    //     0x5c7cc4: ldur            x1, [x0, #0x27]
    // 0x5c7cc8: stur            x1, [fp, #-0x38]
    // 0x5c7ccc: LoadField: r5 = r0->field_1f
    //     0x5c7ccc: ldur            x5, [x0, #0x1f]
    // 0x5c7cd0: stur            x5, [fp, #-0x30]
    // 0x5c7cd4: LoadField: r6 = r0->field_4f
    //     0x5c7cd4: ldur            x6, [x0, #0x4f]
    // 0x5c7cd8: stur            x6, [fp, #-0x28]
    // 0x5c7cdc: LoadField: r7 = r0->field_57
    //     0x5c7cdc: ldur            w7, [x0, #0x57]
    // 0x5c7ce0: DecompressPointer r7
    //     0x5c7ce0: add             x7, x7, HEAP, lsl #32
    // 0x5c7ce4: stur            x7, [fp, #-0x20]
    // 0x5c7ce8: LoadField: d4 = r0->field_5f
    //     0x5c7ce8: ldur            d4, [x0, #0x5f]
    // 0x5c7cec: stur            d4, [fp, #-0xc8]
    // 0x5c7cf0: LoadField: d5 = r0->field_67
    //     0x5c7cf0: ldur            d5, [x0, #0x67]
    // 0x5c7cf4: stur            d5, [fp, #-0xa0]
    // 0x5c7cf8: LoadField: d6 = r0->field_6f
    //     0x5c7cf8: ldur            d6, [x0, #0x6f]
    // 0x5c7cfc: stur            d6, [fp, #-0x98]
    // 0x5c7d00: LoadField: d7 = r0->field_77
    //     0x5c7d00: ldur            d7, [x0, #0x77]
    // 0x5c7d04: stur            d7, [fp, #-0x90]
    // 0x5c7d08: LoadField: d8 = r0->field_7f
    //     0x5c7d08: ldur            d8, [x0, #0x7f]
    // 0x5c7d0c: stur            d8, [fp, #-0x88]
    // 0x5c7d10: LoadField: d9 = r0->field_87
    //     0x5c7d10: ldur            d9, [x0, #0x87]
    // 0x5c7d14: stur            d9, [fp, #-0x80]
    // 0x5c7d18: LoadField: d10 = r0->field_af
    //     0x5c7d18: ldur            d10, [x0, #0xaf]
    // 0x5c7d1c: stur            d10, [fp, #-0x78]
    // 0x5c7d20: LoadField: d11 = r0->field_b7
    //     0x5c7d20: ldur            d11, [x0, #0xb7]
    // 0x5c7d24: stur            d11, [fp, #-0x70]
    // 0x5c7d28: LoadField: r8 = r0->field_7
    //     0x5c7d28: ldur            x8, [x0, #7]
    // 0x5c7d2c: stur            x8, [fp, #-0x18]
    // 0x5c7d30: r0 = PointerUpEvent()
    //     0x5c7d30: bl              #0x5c84b8  ; AllocatePointerUpEventStub -> PointerUpEvent (size=0xb4)
    // 0x5c7d34: mov             x1, x0
    // 0x5c7d38: ldur            x0, [fp, #-0x18]
    // 0x5c7d3c: StoreField: r1->field_7 = r0
    //     0x5c7d3c: stur            x0, [x1, #7]
    // 0x5c7d40: ldur            x2, [fp, #-0x48]
    // 0x5c7d44: StoreField: r1->field_f = r2
    //     0x5c7d44: stur            w2, [x1, #0xf]
    // 0x5c7d48: ldur            x0, [fp, #-0x38]
    // 0x5c7d4c: StoreField: r1->field_13 = r0
    //     0x5c7d4c: stur            x0, [x1, #0x13]
    // 0x5c7d50: ldur            x0, [fp, #-0x40]
    // 0x5c7d54: StoreField: r1->field_1b = r0
    //     0x5c7d54: stur            w0, [x1, #0x1b]
    // 0x5c7d58: ldur            x0, [fp, #-0x30]
    // 0x5c7d5c: StoreField: r1->field_1f = r0
    //     0x5c7d5c: stur            x0, [x1, #0x1f]
    // 0x5c7d60: ldur            x3, [fp, #-0x10]
    // 0x5c7d64: StoreField: r1->field_27 = r3
    //     0x5c7d64: stur            w3, [x1, #0x27]
    // 0x5c7d68: r4 = Instance_Offset
    //     0x5c7d68: ldr             x4, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c7d6c: StoreField: r1->field_2b = r4
    //     0x5c7d6c: stur            w4, [x1, #0x2b]
    // 0x5c7d70: ldur            x0, [fp, #-0x28]
    // 0x5c7d74: StoreField: r1->field_2f = r0
    //     0x5c7d74: stur            x0, [x1, #0x2f]
    // 0x5c7d78: r5 = false
    //     0x5c7d78: add             x5, NULL, #0x30  ; false
    // 0x5c7d7c: StoreField: r1->field_37 = r5
    //     0x5c7d7c: stur            w5, [x1, #0x37]
    // 0x5c7d80: ldur            x0, [fp, #-0x20]
    // 0x5c7d84: StoreField: r1->field_3b = r0
    //     0x5c7d84: stur            w0, [x1, #0x3b]
    // 0x5c7d88: ldur            d0, [fp, #-0xc8]
    // 0x5c7d8c: StoreField: r1->field_3f = d0
    //     0x5c7d8c: stur            d0, [x1, #0x3f]
    // 0x5c7d90: ldur            d0, [fp, #-0xa0]
    // 0x5c7d94: StoreField: r1->field_47 = d0
    //     0x5c7d94: stur            d0, [x1, #0x47]
    // 0x5c7d98: ldur            d0, [fp, #-0x98]
    // 0x5c7d9c: StoreField: r1->field_4f = d0
    //     0x5c7d9c: stur            d0, [x1, #0x4f]
    // 0x5c7da0: ldur            d0, [fp, #-0x90]
    // 0x5c7da4: StoreField: r1->field_57 = d0
    //     0x5c7da4: stur            d0, [x1, #0x57]
    // 0x5c7da8: ldur            d0, [fp, #-0x88]
    // 0x5c7dac: StoreField: r1->field_5f = d0
    //     0x5c7dac: stur            d0, [x1, #0x5f]
    // 0x5c7db0: ldur            d0, [fp, #-0x80]
    // 0x5c7db4: StoreField: r1->field_67 = d0
    //     0x5c7db4: stur            d0, [x1, #0x67]
    // 0x5c7db8: ldur            d0, [fp, #-0xb8]
    // 0x5c7dbc: StoreField: r1->field_6f = d0
    //     0x5c7dbc: stur            d0, [x1, #0x6f]
    // 0x5c7dc0: ldur            d0, [fp, #-0xc0]
    // 0x5c7dc4: StoreField: r1->field_77 = d0
    //     0x5c7dc4: stur            d0, [x1, #0x77]
    // 0x5c7dc8: ldur            d0, [fp, #-0xb0]
    // 0x5c7dcc: StoreField: r1->field_7f = d0
    //     0x5c7dcc: stur            d0, [x1, #0x7f]
    // 0x5c7dd0: ldur            d0, [fp, #-0xa8]
    // 0x5c7dd4: StoreField: r1->field_87 = d0
    //     0x5c7dd4: stur            d0, [x1, #0x87]
    // 0x5c7dd8: ldur            d0, [fp, #-0x78]
    // 0x5c7ddc: StoreField: r1->field_8f = d0
    //     0x5c7ddc: stur            d0, [x1, #0x8f]
    // 0x5c7de0: ldur            d0, [fp, #-0x70]
    // 0x5c7de4: StoreField: r1->field_97 = d0
    //     0x5c7de4: stur            d0, [x1, #0x97]
    // 0x5c7de8: r6 = 0
    //     0x5c7de8: mov             x6, #0
    // 0x5c7dec: StoreField: r1->field_9f = r6
    //     0x5c7dec: stur            x6, [x1, #0x9f]
    // 0x5c7df0: StoreField: r1->field_a7 = r5
    //     0x5c7df0: stur            w5, [x1, #0xa7]
    // 0x5c7df4: mov             x0, x1
    // 0x5c7df8: LeaveFrame
    //     0x5c7df8: mov             SP, fp
    //     0x5c7dfc: ldp             fp, lr, [SP], #0x10
    // 0x5c7e00: ret
    //     0x5c7e00: ret             
    // 0x5c7e04: mov             x3, x8
    // 0x5c7e08: mov             x2, x5
    // 0x5c7e0c: mov             x4, x9
    // 0x5c7e10: mov             x5, x12
    // 0x5c7e14: mov             x6, x11
    // 0x5c7e18: LoadField: r1 = r0->field_27
    //     0x5c7e18: ldur            x1, [x0, #0x27]
    // 0x5c7e1c: stur            x1, [fp, #-0x30]
    // 0x5c7e20: LoadField: r7 = r0->field_1f
    //     0x5c7e20: ldur            x7, [x0, #0x1f]
    // 0x5c7e24: stur            x7, [fp, #-0x28]
    // 0x5c7e28: LoadField: r8 = r0->field_7
    //     0x5c7e28: ldur            x8, [x0, #7]
    // 0x5c7e2c: stur            x8, [fp, #-0x18]
    // 0x5c7e30: LoadField: r9 = r0->field_5b
    //     0x5c7e30: ldur            w9, [x0, #0x5b]
    // 0x5c7e34: DecompressPointer r9
    //     0x5c7e34: add             x9, x9, HEAP, lsl #32
    // 0x5c7e38: stur            x9, [fp, #-0x20]
    // 0x5c7e3c: r0 = PointerPanZoomStartEvent()
    //     0x5c7e3c: bl              #0x5c84ac  ; AllocatePointerPanZoomStartEventStub -> PointerPanZoomStartEvent (size=0xb4)
    // 0x5c7e40: mov             x1, x0
    // 0x5c7e44: ldur            x0, [fp, #-0x18]
    // 0x5c7e48: StoreField: r1->field_7 = r0
    //     0x5c7e48: stur            x0, [x1, #7]
    // 0x5c7e4c: ldur            x4, [fp, #-0x48]
    // 0x5c7e50: StoreField: r1->field_f = r4
    //     0x5c7e50: stur            w4, [x1, #0xf]
    // 0x5c7e54: ldur            x0, [fp, #-0x30]
    // 0x5c7e58: StoreField: r1->field_13 = r0
    //     0x5c7e58: stur            x0, [x1, #0x13]
    // 0x5c7e5c: r5 = Instance_PointerDeviceKind
    //     0x5c7e5c: ldr             x5, [PP, #0x5b98]  ; [pp+0x5b98] Obj!PointerDeviceKind@b67131
    // 0x5c7e60: StoreField: r1->field_1b = r5
    //     0x5c7e60: stur            w5, [x1, #0x1b]
    // 0x5c7e64: ldur            x0, [fp, #-0x28]
    // 0x5c7e68: StoreField: r1->field_1f = r0
    //     0x5c7e68: stur            x0, [x1, #0x1f]
    // 0x5c7e6c: ldur            x6, [fp, #-0x10]
    // 0x5c7e70: StoreField: r1->field_27 = r6
    //     0x5c7e70: stur            w6, [x1, #0x27]
    // 0x5c7e74: r8 = Instance_Offset
    //     0x5c7e74: ldr             x8, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c7e78: StoreField: r1->field_2b = r8
    //     0x5c7e78: stur            w8, [x1, #0x2b]
    // 0x5c7e7c: r9 = 0
    //     0x5c7e7c: mov             x9, #0
    // 0x5c7e80: StoreField: r1->field_2f = r9
    //     0x5c7e80: stur            x9, [x1, #0x2f]
    // 0x5c7e84: r10 = false
    //     0x5c7e84: add             x10, NULL, #0x30  ; false
    // 0x5c7e88: StoreField: r1->field_37 = r10
    //     0x5c7e88: stur            w10, [x1, #0x37]
    // 0x5c7e8c: StoreField: r1->field_3b = r10
    //     0x5c7e8c: stur            w10, [x1, #0x3b]
    // 0x5c7e90: d0 = 1.000000
    //     0x5c7e90: fmov            d0, #1.00000000
    // 0x5c7e94: StoreField: r1->field_3f = d0
    //     0x5c7e94: stur            d0, [x1, #0x3f]
    // 0x5c7e98: StoreField: r1->field_47 = d0
    //     0x5c7e98: stur            d0, [x1, #0x47]
    // 0x5c7e9c: StoreField: r1->field_4f = d0
    //     0x5c7e9c: stur            d0, [x1, #0x4f]
    // 0x5c7ea0: d1 = 0.000000
    //     0x5c7ea0: eor             v1.16b, v1.16b, v1.16b
    // 0x5c7ea4: StoreField: r1->field_57 = d1
    //     0x5c7ea4: stur            d1, [x1, #0x57]
    // 0x5c7ea8: StoreField: r1->field_5f = d1
    //     0x5c7ea8: stur            d1, [x1, #0x5f]
    // 0x5c7eac: StoreField: r1->field_67 = d1
    //     0x5c7eac: stur            d1, [x1, #0x67]
    // 0x5c7eb0: StoreField: r1->field_6f = d1
    //     0x5c7eb0: stur            d1, [x1, #0x6f]
    // 0x5c7eb4: StoreField: r1->field_77 = d1
    //     0x5c7eb4: stur            d1, [x1, #0x77]
    // 0x5c7eb8: StoreField: r1->field_7f = d1
    //     0x5c7eb8: stur            d1, [x1, #0x7f]
    // 0x5c7ebc: StoreField: r1->field_87 = d1
    //     0x5c7ebc: stur            d1, [x1, #0x87]
    // 0x5c7ec0: StoreField: r1->field_8f = d1
    //     0x5c7ec0: stur            d1, [x1, #0x8f]
    // 0x5c7ec4: StoreField: r1->field_97 = d1
    //     0x5c7ec4: stur            d1, [x1, #0x97]
    // 0x5c7ec8: StoreField: r1->field_9f = r9
    //     0x5c7ec8: stur            x9, [x1, #0x9f]
    // 0x5c7ecc: ldur            x0, [fp, #-0x20]
    // 0x5c7ed0: StoreField: r1->field_a7 = r0
    //     0x5c7ed0: stur            w0, [x1, #0xa7]
    // 0x5c7ed4: mov             x0, x1
    // 0x5c7ed8: LeaveFrame
    //     0x5c7ed8: mov             SP, fp
    //     0x5c7edc: ldp             fp, lr, [SP], #0x10
    // 0x5c7ee0: ret
    //     0x5c7ee0: ret             
    // 0x5c7ee4: mov             x6, x8
    // 0x5c7ee8: mov             x4, x5
    // 0x5c7eec: mov             x8, x9
    // 0x5c7ef0: mov             x10, x12
    // 0x5c7ef4: mov             x9, x11
    // 0x5c7ef8: mov             v1.16b, v0.16b
    // 0x5c7efc: r5 = Instance_PointerDeviceKind
    //     0x5c7efc: ldr             x5, [PP, #0x5b98]  ; [pp+0x5b98] Obj!PointerDeviceKind@b67131
    // 0x5c7f00: d0 = 1.000000
    //     0x5c7f00: fmov            d0, #1.00000000
    // 0x5c7f04: cmp             x7, #8
    // 0x5c7f08: b.gt            #0x5c8094
    // 0x5c7f0c: LoadField: d2 = r0->field_d7
    //     0x5c7f0c: ldur            d2, [x0, #0xd7]
    // 0x5c7f10: stur            d2, [fp, #-0x78]
    // 0x5c7f14: LoadField: d3 = r0->field_df
    //     0x5c7f14: ldur            d3, [x0, #0xdf]
    // 0x5c7f18: stur            d3, [fp, #-0x70]
    // 0x5c7f1c: r0 = Offset()
    //     0x5c7f1c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x5c7f20: ldur            d0, [fp, #-0x78]
    // 0x5c7f24: StoreField: r0->field_7 = d0
    //     0x5c7f24: stur            d0, [x0, #7]
    // 0x5c7f28: ldur            d0, [fp, #-0x70]
    // 0x5c7f2c: StoreField: r0->field_f = d0
    //     0x5c7f2c: stur            d0, [x0, #0xf]
    // 0x5c7f30: ldur            x16, [fp, #-0x68]
    // 0x5c7f34: stp             x16, x0, [SP, #-0x10]!
    // 0x5c7f38: r0 = /()
    //     0x5c7f38: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x5c7f3c: add             SP, SP, #0x10
    // 0x5c7f40: mov             x1, x0
    // 0x5c7f44: ldr             x0, [fp, #0x10]
    // 0x5c7f48: stur            x1, [fp, #-0x20]
    // 0x5c7f4c: LoadField: d0 = r0->field_e7
    //     0x5c7f4c: ldur            d0, [x0, #0xe7]
    // 0x5c7f50: stur            d0, [fp, #-0x78]
    // 0x5c7f54: LoadField: d1 = r0->field_ef
    //     0x5c7f54: ldur            d1, [x0, #0xef]
    // 0x5c7f58: stur            d1, [fp, #-0x70]
    // 0x5c7f5c: r0 = Offset()
    //     0x5c7f5c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x5c7f60: ldur            d0, [fp, #-0x78]
    // 0x5c7f64: StoreField: r0->field_7 = d0
    //     0x5c7f64: stur            d0, [x0, #7]
    // 0x5c7f68: ldur            d0, [fp, #-0x70]
    // 0x5c7f6c: StoreField: r0->field_f = d0
    //     0x5c7f6c: stur            d0, [x0, #0xf]
    // 0x5c7f70: ldur            x1, [fp, #-8]
    // 0x5c7f74: LoadField: r2 = r1->field_f
    //     0x5c7f74: ldur            w2, [x1, #0xf]
    // 0x5c7f78: DecompressPointer r2
    //     0x5c7f78: add             x2, x2, HEAP, lsl #32
    // 0x5c7f7c: stp             x2, x0, [SP, #-0x10]!
    // 0x5c7f80: r0 = /()
    //     0x5c7f80: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x5c7f84: add             SP, SP, #0x10
    // 0x5c7f88: ldr             x1, [fp, #0x10]
    // 0x5c7f8c: stur            x0, [fp, #-0x58]
    // 0x5c7f90: LoadField: r2 = r1->field_27
    //     0x5c7f90: ldur            x2, [x1, #0x27]
    // 0x5c7f94: stur            x2, [fp, #-0x30]
    // 0x5c7f98: LoadField: r3 = r1->field_1f
    //     0x5c7f98: ldur            x3, [x1, #0x1f]
    // 0x5c7f9c: stur            x3, [fp, #-0x28]
    // 0x5c7fa0: LoadField: d0 = r1->field_f7
    //     0x5c7fa0: ldur            d0, [x1, #0xf7]
    // 0x5c7fa4: stur            d0, [fp, #-0x70]
    // 0x5c7fa8: LoadField: r4 = r1->field_ff
    //     0x5c7fa8: ldur            w4, [x1, #0xff]
    // 0x5c7fac: DecompressPointer r4
    //     0x5c7fac: add             x4, x4, HEAP, lsl #32
    // 0x5c7fb0: stur            x4, [fp, #-0x50]
    // 0x5c7fb4: LoadField: r5 = r1->field_7
    //     0x5c7fb4: ldur            x5, [x1, #7]
    // 0x5c7fb8: stur            x5, [fp, #-0x18]
    // 0x5c7fbc: LoadField: r6 = r1->field_5b
    //     0x5c7fbc: ldur            w6, [x1, #0x5b]
    // 0x5c7fc0: DecompressPointer r6
    //     0x5c7fc0: add             x6, x6, HEAP, lsl #32
    // 0x5c7fc4: stur            x6, [fp, #-8]
    // 0x5c7fc8: r0 = PointerPanZoomUpdateEvent()
    //     0x5c7fc8: bl              #0x5c84a0  ; AllocatePointerPanZoomUpdateEventStub -> PointerPanZoomUpdateEvent (size=0xcc)
    // 0x5c7fcc: mov             x1, x0
    // 0x5c7fd0: ldur            x0, [fp, #-0x20]
    // 0x5c7fd4: StoreField: r1->field_b3 = r0
    //     0x5c7fd4: stur            w0, [x1, #0xb3]
    // 0x5c7fd8: ldur            x0, [fp, #-0x58]
    // 0x5c7fdc: StoreField: r1->field_b7 = r0
    //     0x5c7fdc: stur            w0, [x1, #0xb7]
    // 0x5c7fe0: ldur            d0, [fp, #-0x70]
    // 0x5c7fe4: StoreField: r1->field_bb = d0
    //     0x5c7fe4: stur            d0, [x1, #0xbb]
    // 0x5c7fe8: ldur            x0, [fp, #-0x50]
    // 0x5c7fec: LoadField: d0 = r0->field_7
    //     0x5c7fec: ldur            d0, [x0, #7]
    // 0x5c7ff0: StoreField: r1->field_c3 = d0
    //     0x5c7ff0: stur            d0, [x1, #0xc3]
    // 0x5c7ff4: ldur            x0, [fp, #-0x18]
    // 0x5c7ff8: StoreField: r1->field_7 = r0
    //     0x5c7ff8: stur            x0, [x1, #7]
    // 0x5c7ffc: ldur            x0, [fp, #-0x48]
    // 0x5c8000: StoreField: r1->field_f = r0
    //     0x5c8000: stur            w0, [x1, #0xf]
    // 0x5c8004: ldur            x0, [fp, #-0x30]
    // 0x5c8008: StoreField: r1->field_13 = r0
    //     0x5c8008: stur            x0, [x1, #0x13]
    // 0x5c800c: r2 = Instance_PointerDeviceKind
    //     0x5c800c: ldr             x2, [PP, #0x5b98]  ; [pp+0x5b98] Obj!PointerDeviceKind@b67131
    // 0x5c8010: StoreField: r1->field_1b = r2
    //     0x5c8010: stur            w2, [x1, #0x1b]
    // 0x5c8014: ldur            x0, [fp, #-0x28]
    // 0x5c8018: StoreField: r1->field_1f = r0
    //     0x5c8018: stur            x0, [x1, #0x1f]
    // 0x5c801c: ldur            x3, [fp, #-0x10]
    // 0x5c8020: StoreField: r1->field_27 = r3
    //     0x5c8020: stur            w3, [x1, #0x27]
    // 0x5c8024: r4 = Instance_Offset
    //     0x5c8024: ldr             x4, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c8028: StoreField: r1->field_2b = r4
    //     0x5c8028: stur            w4, [x1, #0x2b]
    // 0x5c802c: r5 = 0
    //     0x5c802c: mov             x5, #0
    // 0x5c8030: StoreField: r1->field_2f = r5
    //     0x5c8030: stur            x5, [x1, #0x2f]
    // 0x5c8034: r6 = false
    //     0x5c8034: add             x6, NULL, #0x30  ; false
    // 0x5c8038: StoreField: r1->field_37 = r6
    //     0x5c8038: stur            w6, [x1, #0x37]
    // 0x5c803c: StoreField: r1->field_3b = r6
    //     0x5c803c: stur            w6, [x1, #0x3b]
    // 0x5c8040: d0 = 1.000000
    //     0x5c8040: fmov            d0, #1.00000000
    // 0x5c8044: StoreField: r1->field_3f = d0
    //     0x5c8044: stur            d0, [x1, #0x3f]
    // 0x5c8048: StoreField: r1->field_47 = d0
    //     0x5c8048: stur            d0, [x1, #0x47]
    // 0x5c804c: StoreField: r1->field_4f = d0
    //     0x5c804c: stur            d0, [x1, #0x4f]
    // 0x5c8050: d1 = 0.000000
    //     0x5c8050: eor             v1.16b, v1.16b, v1.16b
    // 0x5c8054: StoreField: r1->field_57 = d1
    //     0x5c8054: stur            d1, [x1, #0x57]
    // 0x5c8058: StoreField: r1->field_5f = d1
    //     0x5c8058: stur            d1, [x1, #0x5f]
    // 0x5c805c: StoreField: r1->field_67 = d1
    //     0x5c805c: stur            d1, [x1, #0x67]
    // 0x5c8060: StoreField: r1->field_6f = d1
    //     0x5c8060: stur            d1, [x1, #0x6f]
    // 0x5c8064: StoreField: r1->field_77 = d1
    //     0x5c8064: stur            d1, [x1, #0x77]
    // 0x5c8068: StoreField: r1->field_7f = d1
    //     0x5c8068: stur            d1, [x1, #0x7f]
    // 0x5c806c: StoreField: r1->field_87 = d1
    //     0x5c806c: stur            d1, [x1, #0x87]
    // 0x5c8070: StoreField: r1->field_8f = d1
    //     0x5c8070: stur            d1, [x1, #0x8f]
    // 0x5c8074: StoreField: r1->field_97 = d1
    //     0x5c8074: stur            d1, [x1, #0x97]
    // 0x5c8078: StoreField: r1->field_9f = r5
    //     0x5c8078: stur            x5, [x1, #0x9f]
    // 0x5c807c: ldur            x0, [fp, #-8]
    // 0x5c8080: StoreField: r1->field_a7 = r0
    //     0x5c8080: stur            w0, [x1, #0xa7]
    // 0x5c8084: mov             x0, x1
    // 0x5c8088: LeaveFrame
    //     0x5c8088: mov             SP, fp
    //     0x5c808c: ldp             fp, lr, [SP], #0x10
    // 0x5c8090: ret
    //     0x5c8090: ret             
    // 0x5c8094: mov             x1, x0
    // 0x5c8098: mov             x3, x6
    // 0x5c809c: mov             x0, x4
    // 0x5c80a0: mov             x4, x8
    // 0x5c80a4: mov             x6, x10
    // 0x5c80a8: mov             x2, x5
    // 0x5c80ac: mov             x5, x9
    // 0x5c80b0: LoadField: r7 = r1->field_27
    //     0x5c80b0: ldur            x7, [x1, #0x27]
    // 0x5c80b4: stur            x7, [fp, #-0x30]
    // 0x5c80b8: LoadField: r8 = r1->field_1f
    //     0x5c80b8: ldur            x8, [x1, #0x1f]
    // 0x5c80bc: stur            x8, [fp, #-0x28]
    // 0x5c80c0: LoadField: r9 = r1->field_7
    //     0x5c80c0: ldur            x9, [x1, #7]
    // 0x5c80c4: stur            x9, [fp, #-0x18]
    // 0x5c80c8: LoadField: r10 = r1->field_5b
    //     0x5c80c8: ldur            w10, [x1, #0x5b]
    // 0x5c80cc: DecompressPointer r10
    //     0x5c80cc: add             x10, x10, HEAP, lsl #32
    // 0x5c80d0: stur            x10, [fp, #-8]
    // 0x5c80d4: r0 = PointerPanZoomEndEvent()
    //     0x5c80d4: bl              #0x5c8494  ; AllocatePointerPanZoomEndEventStub -> PointerPanZoomEndEvent (size=0xb4)
    // 0x5c80d8: mov             x1, x0
    // 0x5c80dc: ldur            x0, [fp, #-0x18]
    // 0x5c80e0: StoreField: r1->field_7 = r0
    //     0x5c80e0: stur            x0, [x1, #7]
    // 0x5c80e4: ldur            x2, [fp, #-0x48]
    // 0x5c80e8: StoreField: r1->field_f = r2
    //     0x5c80e8: stur            w2, [x1, #0xf]
    // 0x5c80ec: ldur            x0, [fp, #-0x30]
    // 0x5c80f0: StoreField: r1->field_13 = r0
    //     0x5c80f0: stur            x0, [x1, #0x13]
    // 0x5c80f4: r0 = Instance_PointerDeviceKind
    //     0x5c80f4: ldr             x0, [PP, #0x5b98]  ; [pp+0x5b98] Obj!PointerDeviceKind@b67131
    // 0x5c80f8: StoreField: r1->field_1b = r0
    //     0x5c80f8: stur            w0, [x1, #0x1b]
    // 0x5c80fc: ldur            x0, [fp, #-0x28]
    // 0x5c8100: StoreField: r1->field_1f = r0
    //     0x5c8100: stur            x0, [x1, #0x1f]
    // 0x5c8104: ldur            x3, [fp, #-0x10]
    // 0x5c8108: StoreField: r1->field_27 = r3
    //     0x5c8108: stur            w3, [x1, #0x27]
    // 0x5c810c: r4 = Instance_Offset
    //     0x5c810c: ldr             x4, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c8110: StoreField: r1->field_2b = r4
    //     0x5c8110: stur            w4, [x1, #0x2b]
    // 0x5c8114: r5 = 0
    //     0x5c8114: mov             x5, #0
    // 0x5c8118: StoreField: r1->field_2f = r5
    //     0x5c8118: stur            x5, [x1, #0x2f]
    // 0x5c811c: r6 = false
    //     0x5c811c: add             x6, NULL, #0x30  ; false
    // 0x5c8120: StoreField: r1->field_37 = r6
    //     0x5c8120: stur            w6, [x1, #0x37]
    // 0x5c8124: StoreField: r1->field_3b = r6
    //     0x5c8124: stur            w6, [x1, #0x3b]
    // 0x5c8128: d0 = 1.000000
    //     0x5c8128: fmov            d0, #1.00000000
    // 0x5c812c: StoreField: r1->field_3f = d0
    //     0x5c812c: stur            d0, [x1, #0x3f]
    // 0x5c8130: StoreField: r1->field_47 = d0
    //     0x5c8130: stur            d0, [x1, #0x47]
    // 0x5c8134: StoreField: r1->field_4f = d0
    //     0x5c8134: stur            d0, [x1, #0x4f]
    // 0x5c8138: d1 = 0.000000
    //     0x5c8138: eor             v1.16b, v1.16b, v1.16b
    // 0x5c813c: StoreField: r1->field_57 = d1
    //     0x5c813c: stur            d1, [x1, #0x57]
    // 0x5c8140: StoreField: r1->field_5f = d1
    //     0x5c8140: stur            d1, [x1, #0x5f]
    // 0x5c8144: StoreField: r1->field_67 = d1
    //     0x5c8144: stur            d1, [x1, #0x67]
    // 0x5c8148: StoreField: r1->field_6f = d1
    //     0x5c8148: stur            d1, [x1, #0x6f]
    // 0x5c814c: StoreField: r1->field_77 = d1
    //     0x5c814c: stur            d1, [x1, #0x77]
    // 0x5c8150: StoreField: r1->field_7f = d1
    //     0x5c8150: stur            d1, [x1, #0x7f]
    // 0x5c8154: StoreField: r1->field_87 = d1
    //     0x5c8154: stur            d1, [x1, #0x87]
    // 0x5c8158: StoreField: r1->field_8f = d1
    //     0x5c8158: stur            d1, [x1, #0x8f]
    // 0x5c815c: StoreField: r1->field_97 = d1
    //     0x5c815c: stur            d1, [x1, #0x97]
    // 0x5c8160: StoreField: r1->field_9f = r5
    //     0x5c8160: stur            x5, [x1, #0x9f]
    // 0x5c8164: ldur            x0, [fp, #-8]
    // 0x5c8168: StoreField: r1->field_a7 = r0
    //     0x5c8168: stur            w0, [x1, #0xa7]
    // 0x5c816c: mov             x0, x1
    // 0x5c8170: LeaveFrame
    //     0x5c8170: mov             SP, fp
    //     0x5c8174: ldp             fp, lr, [SP], #0x10
    // 0x5c8178: ret
    //     0x5c8178: ret             
    // 0x5c817c: mov             x1, x0
    // 0x5c8180: ldur            x3, [fp, #-0x10]
    // 0x5c8184: mov             x2, x4
    // 0x5c8188: mov             x0, x5
    // 0x5c818c: r4 = Instance_Offset
    //     0x5c818c: ldr             x4, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c8190: r6 = false
    //     0x5c8190: add             x6, NULL, #0x30  ; false
    // 0x5c8194: r5 = 0
    //     0x5c8194: mov             x5, #0
    // 0x5c8198: d1 = 0.000000
    //     0x5c8198: eor             v1.16b, v1.16b, v1.16b
    // 0x5c819c: d0 = 1.000000
    //     0x5c819c: fmov            d0, #1.00000000
    // 0x5c81a0: LoadField: d2 = r1->field_c7
    //     0x5c81a0: ldur            d2, [x1, #0xc7]
    // 0x5c81a4: stur            d2, [fp, #-0x78]
    // 0x5c81a8: LoadField: d3 = r1->field_cf
    //     0x5c81a8: ldur            d3, [x1, #0xcf]
    // 0x5c81ac: stur            d3, [fp, #-0x70]
    // 0x5c81b0: r0 = Offset()
    //     0x5c81b0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x5c81b4: ldur            d0, [fp, #-0x78]
    // 0x5c81b8: StoreField: r0->field_7 = d0
    //     0x5c81b8: stur            d0, [x0, #7]
    // 0x5c81bc: ldur            d0, [fp, #-0x70]
    // 0x5c81c0: StoreField: r0->field_f = d0
    //     0x5c81c0: stur            d0, [x0, #0xf]
    // 0x5c81c4: ldur            x16, [fp, #-0x68]
    // 0x5c81c8: stp             x16, x0, [SP, #-0x10]!
    // 0x5c81cc: r0 = /()
    //     0x5c81cc: bl              #0x50e554  ; [dart:ui] Offset::/
    // 0x5c81d0: add             SP, SP, #0x10
    // 0x5c81d4: mov             x1, x0
    // 0x5c81d8: ldr             x0, [fp, #0x10]
    // 0x5c81dc: stur            x1, [fp, #-8]
    // 0x5c81e0: LoadField: r2 = r0->field_1f
    //     0x5c81e0: ldur            x2, [x0, #0x1f]
    // 0x5c81e4: stur            x2, [fp, #-0x28]
    // 0x5c81e8: LoadField: r3 = r0->field_7
    //     0x5c81e8: ldur            x3, [x0, #7]
    // 0x5c81ec: stur            x3, [fp, #-0x18]
    // 0x5c81f0: r0 = PointerScrollEvent()
    //     0x5c81f0: bl              #0x5c8488  ; AllocatePointerScrollEventStub -> PointerScrollEvent (size=0xb8)
    // 0x5c81f4: mov             x1, x0
    // 0x5c81f8: ldur            x0, [fp, #-8]
    // 0x5c81fc: StoreField: r1->field_b3 = r0
    //     0x5c81fc: stur            w0, [x1, #0xb3]
    // 0x5c8200: ldur            x0, [fp, #-0x18]
    // 0x5c8204: StoreField: r1->field_7 = r0
    //     0x5c8204: stur            x0, [x1, #7]
    // 0x5c8208: ldur            x2, [fp, #-0x48]
    // 0x5c820c: StoreField: r1->field_f = r2
    //     0x5c820c: stur            w2, [x1, #0xf]
    // 0x5c8210: r3 = 0
    //     0x5c8210: mov             x3, #0
    // 0x5c8214: StoreField: r1->field_13 = r3
    //     0x5c8214: stur            x3, [x1, #0x13]
    // 0x5c8218: ldur            x4, [fp, #-0x40]
    // 0x5c821c: StoreField: r1->field_1b = r4
    //     0x5c821c: stur            w4, [x1, #0x1b]
    // 0x5c8220: ldur            x0, [fp, #-0x28]
    // 0x5c8224: StoreField: r1->field_1f = r0
    //     0x5c8224: stur            x0, [x1, #0x1f]
    // 0x5c8228: ldur            x5, [fp, #-0x10]
    // 0x5c822c: StoreField: r1->field_27 = r5
    //     0x5c822c: stur            w5, [x1, #0x27]
    // 0x5c8230: r6 = Instance_Offset
    //     0x5c8230: ldr             x6, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c8234: StoreField: r1->field_2b = r6
    //     0x5c8234: stur            w6, [x1, #0x2b]
    // 0x5c8238: StoreField: r1->field_2f = r3
    //     0x5c8238: stur            x3, [x1, #0x2f]
    // 0x5c823c: r7 = false
    //     0x5c823c: add             x7, NULL, #0x30  ; false
    // 0x5c8240: StoreField: r1->field_37 = r7
    //     0x5c8240: stur            w7, [x1, #0x37]
    // 0x5c8244: StoreField: r1->field_3b = r7
    //     0x5c8244: stur            w7, [x1, #0x3b]
    // 0x5c8248: d0 = 1.000000
    //     0x5c8248: fmov            d0, #1.00000000
    // 0x5c824c: StoreField: r1->field_3f = d0
    //     0x5c824c: stur            d0, [x1, #0x3f]
    // 0x5c8250: StoreField: r1->field_47 = d0
    //     0x5c8250: stur            d0, [x1, #0x47]
    // 0x5c8254: StoreField: r1->field_4f = d0
    //     0x5c8254: stur            d0, [x1, #0x4f]
    // 0x5c8258: d1 = 0.000000
    //     0x5c8258: eor             v1.16b, v1.16b, v1.16b
    // 0x5c825c: StoreField: r1->field_57 = d1
    //     0x5c825c: stur            d1, [x1, #0x57]
    // 0x5c8260: StoreField: r1->field_5f = d1
    //     0x5c8260: stur            d1, [x1, #0x5f]
    // 0x5c8264: StoreField: r1->field_67 = d1
    //     0x5c8264: stur            d1, [x1, #0x67]
    // 0x5c8268: StoreField: r1->field_6f = d1
    //     0x5c8268: stur            d1, [x1, #0x6f]
    // 0x5c826c: StoreField: r1->field_77 = d1
    //     0x5c826c: stur            d1, [x1, #0x77]
    // 0x5c8270: StoreField: r1->field_7f = d1
    //     0x5c8270: stur            d1, [x1, #0x7f]
    // 0x5c8274: StoreField: r1->field_87 = d1
    //     0x5c8274: stur            d1, [x1, #0x87]
    // 0x5c8278: StoreField: r1->field_8f = d1
    //     0x5c8278: stur            d1, [x1, #0x8f]
    // 0x5c827c: StoreField: r1->field_97 = d1
    //     0x5c827c: stur            d1, [x1, #0x97]
    // 0x5c8280: StoreField: r1->field_9f = r3
    //     0x5c8280: stur            x3, [x1, #0x9f]
    // 0x5c8284: StoreField: r1->field_a7 = r7
    //     0x5c8284: stur            w7, [x1, #0xa7]
    // 0x5c8288: mov             x0, x1
    // 0x5c828c: LeaveFrame
    //     0x5c828c: mov             SP, fp
    //     0x5c8290: ldp             fp, lr, [SP], #0x10
    // 0x5c8294: ret
    //     0x5c8294: ret             
    // 0x5c8298: mov             x2, x4
    // 0x5c829c: mov             x4, x5
    // 0x5c82a0: ldur            x5, [fp, #-0x10]
    // 0x5c82a4: r6 = Instance_Offset
    //     0x5c82a4: ldr             x6, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c82a8: r7 = false
    //     0x5c82a8: add             x7, NULL, #0x30  ; false
    // 0x5c82ac: r3 = 0
    //     0x5c82ac: mov             x3, #0
    // 0x5c82b0: d1 = 0.000000
    //     0x5c82b0: eor             v1.16b, v1.16b, v1.16b
    // 0x5c82b4: d0 = 1.000000
    //     0x5c82b4: fmov            d0, #1.00000000
    // 0x5c82b8: LoadField: r1 = r0->field_1f
    //     0x5c82b8: ldur            x1, [x0, #0x1f]
    // 0x5c82bc: stur            x1, [fp, #-0x28]
    // 0x5c82c0: LoadField: r8 = r0->field_7
    //     0x5c82c0: ldur            x8, [x0, #7]
    // 0x5c82c4: stur            x8, [fp, #-0x18]
    // 0x5c82c8: r0 = PointerScrollInertiaCancelEvent()
    //     0x5c82c8: bl              #0x5c847c  ; AllocatePointerScrollInertiaCancelEventStub -> PointerScrollInertiaCancelEvent (size=0xb4)
    // 0x5c82cc: mov             x1, x0
    // 0x5c82d0: ldur            x0, [fp, #-0x18]
    // 0x5c82d4: StoreField: r1->field_7 = r0
    //     0x5c82d4: stur            x0, [x1, #7]
    // 0x5c82d8: ldur            x2, [fp, #-0x48]
    // 0x5c82dc: StoreField: r1->field_f = r2
    //     0x5c82dc: stur            w2, [x1, #0xf]
    // 0x5c82e0: r3 = 0
    //     0x5c82e0: mov             x3, #0
    // 0x5c82e4: StoreField: r1->field_13 = r3
    //     0x5c82e4: stur            x3, [x1, #0x13]
    // 0x5c82e8: ldur            x4, [fp, #-0x40]
    // 0x5c82ec: StoreField: r1->field_1b = r4
    //     0x5c82ec: stur            w4, [x1, #0x1b]
    // 0x5c82f0: ldur            x0, [fp, #-0x28]
    // 0x5c82f4: StoreField: r1->field_1f = r0
    //     0x5c82f4: stur            x0, [x1, #0x1f]
    // 0x5c82f8: ldur            x5, [fp, #-0x10]
    // 0x5c82fc: StoreField: r1->field_27 = r5
    //     0x5c82fc: stur            w5, [x1, #0x27]
    // 0x5c8300: r6 = Instance_Offset
    //     0x5c8300: ldr             x6, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c8304: StoreField: r1->field_2b = r6
    //     0x5c8304: stur            w6, [x1, #0x2b]
    // 0x5c8308: StoreField: r1->field_2f = r3
    //     0x5c8308: stur            x3, [x1, #0x2f]
    // 0x5c830c: r8 = false
    //     0x5c830c: add             x8, NULL, #0x30  ; false
    // 0x5c8310: StoreField: r1->field_37 = r8
    //     0x5c8310: stur            w8, [x1, #0x37]
    // 0x5c8314: StoreField: r1->field_3b = r8
    //     0x5c8314: stur            w8, [x1, #0x3b]
    // 0x5c8318: d0 = 1.000000
    //     0x5c8318: fmov            d0, #1.00000000
    // 0x5c831c: StoreField: r1->field_3f = d0
    //     0x5c831c: stur            d0, [x1, #0x3f]
    // 0x5c8320: StoreField: r1->field_47 = d0
    //     0x5c8320: stur            d0, [x1, #0x47]
    // 0x5c8324: StoreField: r1->field_4f = d0
    //     0x5c8324: stur            d0, [x1, #0x4f]
    // 0x5c8328: d1 = 0.000000
    //     0x5c8328: eor             v1.16b, v1.16b, v1.16b
    // 0x5c832c: StoreField: r1->field_57 = d1
    //     0x5c832c: stur            d1, [x1, #0x57]
    // 0x5c8330: StoreField: r1->field_5f = d1
    //     0x5c8330: stur            d1, [x1, #0x5f]
    // 0x5c8334: StoreField: r1->field_67 = d1
    //     0x5c8334: stur            d1, [x1, #0x67]
    // 0x5c8338: StoreField: r1->field_6f = d1
    //     0x5c8338: stur            d1, [x1, #0x6f]
    // 0x5c833c: StoreField: r1->field_77 = d1
    //     0x5c833c: stur            d1, [x1, #0x77]
    // 0x5c8340: StoreField: r1->field_7f = d1
    //     0x5c8340: stur            d1, [x1, #0x7f]
    // 0x5c8344: StoreField: r1->field_87 = d1
    //     0x5c8344: stur            d1, [x1, #0x87]
    // 0x5c8348: StoreField: r1->field_8f = d1
    //     0x5c8348: stur            d1, [x1, #0x8f]
    // 0x5c834c: StoreField: r1->field_97 = d1
    //     0x5c834c: stur            d1, [x1, #0x97]
    // 0x5c8350: StoreField: r1->field_9f = r3
    //     0x5c8350: stur            x3, [x1, #0x9f]
    // 0x5c8354: StoreField: r1->field_a7 = r8
    //     0x5c8354: stur            w8, [x1, #0xa7]
    // 0x5c8358: mov             x0, x1
    // 0x5c835c: LeaveFrame
    //     0x5c835c: mov             SP, fp
    //     0x5c8360: ldp             fp, lr, [SP], #0x10
    // 0x5c8364: ret
    //     0x5c8364: ret             
    // 0x5c8368: mov             x2, x4
    // 0x5c836c: mov             x4, x5
    // 0x5c8370: ldur            x5, [fp, #-0x10]
    // 0x5c8374: r6 = Instance_Offset
    //     0x5c8374: ldr             x6, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c8378: r8 = false
    //     0x5c8378: add             x8, NULL, #0x30  ; false
    // 0x5c837c: r3 = 0
    //     0x5c837c: mov             x3, #0
    // 0x5c8380: d1 = 0.000000
    //     0x5c8380: eor             v1.16b, v1.16b, v1.16b
    // 0x5c8384: d0 = 1.000000
    //     0x5c8384: fmov            d0, #1.00000000
    // 0x5c8388: cmp             x7, #3
    // 0x5c838c: b.gt            #0x5c8448
    // 0x5c8390: LoadField: r1 = r0->field_1f
    //     0x5c8390: ldur            x1, [x0, #0x1f]
    // 0x5c8394: stur            x1, [fp, #-0x28]
    // 0x5c8398: LoadField: r7 = r0->field_7
    //     0x5c8398: ldur            x7, [x0, #7]
    // 0x5c839c: stur            x7, [fp, #-0x18]
    // 0x5c83a0: LoadField: d2 = r0->field_f7
    //     0x5c83a0: ldur            d2, [x0, #0xf7]
    // 0x5c83a4: stur            d2, [fp, #-0x70]
    // 0x5c83a8: r0 = PointerScaleEvent()
    //     0x5c83a8: bl              #0x5c8470  ; AllocatePointerScaleEventStub -> PointerScaleEvent (size=0xbc)
    // 0x5c83ac: ldur            d0, [fp, #-0x70]
    // 0x5c83b0: StoreField: r0->field_b3 = d0
    //     0x5c83b0: stur            d0, [x0, #0xb3]
    // 0x5c83b4: ldur            x1, [fp, #-0x18]
    // 0x5c83b8: StoreField: r0->field_7 = r1
    //     0x5c83b8: stur            x1, [x0, #7]
    // 0x5c83bc: ldur            x1, [fp, #-0x48]
    // 0x5c83c0: StoreField: r0->field_f = r1
    //     0x5c83c0: stur            w1, [x0, #0xf]
    // 0x5c83c4: r1 = 0
    //     0x5c83c4: mov             x1, #0
    // 0x5c83c8: StoreField: r0->field_13 = r1
    //     0x5c83c8: stur            x1, [x0, #0x13]
    // 0x5c83cc: ldur            x2, [fp, #-0x40]
    // 0x5c83d0: StoreField: r0->field_1b = r2
    //     0x5c83d0: stur            w2, [x0, #0x1b]
    // 0x5c83d4: ldur            x2, [fp, #-0x28]
    // 0x5c83d8: StoreField: r0->field_1f = r2
    //     0x5c83d8: stur            x2, [x0, #0x1f]
    // 0x5c83dc: ldur            x2, [fp, #-0x10]
    // 0x5c83e0: StoreField: r0->field_27 = r2
    //     0x5c83e0: stur            w2, [x0, #0x27]
    // 0x5c83e4: r2 = Instance_Offset
    //     0x5c83e4: ldr             x2, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x5c83e8: StoreField: r0->field_2b = r2
    //     0x5c83e8: stur            w2, [x0, #0x2b]
    // 0x5c83ec: StoreField: r0->field_2f = r1
    //     0x5c83ec: stur            x1, [x0, #0x2f]
    // 0x5c83f0: r2 = false
    //     0x5c83f0: add             x2, NULL, #0x30  ; false
    // 0x5c83f4: StoreField: r0->field_37 = r2
    //     0x5c83f4: stur            w2, [x0, #0x37]
    // 0x5c83f8: StoreField: r0->field_3b = r2
    //     0x5c83f8: stur            w2, [x0, #0x3b]
    // 0x5c83fc: d0 = 1.000000
    //     0x5c83fc: fmov            d0, #1.00000000
    // 0x5c8400: StoreField: r0->field_3f = d0
    //     0x5c8400: stur            d0, [x0, #0x3f]
    // 0x5c8404: StoreField: r0->field_47 = d0
    //     0x5c8404: stur            d0, [x0, #0x47]
    // 0x5c8408: StoreField: r0->field_4f = d0
    //     0x5c8408: stur            d0, [x0, #0x4f]
    // 0x5c840c: d0 = 0.000000
    //     0x5c840c: eor             v0.16b, v0.16b, v0.16b
    // 0x5c8410: StoreField: r0->field_57 = d0
    //     0x5c8410: stur            d0, [x0, #0x57]
    // 0x5c8414: StoreField: r0->field_5f = d0
    //     0x5c8414: stur            d0, [x0, #0x5f]
    // 0x5c8418: StoreField: r0->field_67 = d0
    //     0x5c8418: stur            d0, [x0, #0x67]
    // 0x5c841c: StoreField: r0->field_6f = d0
    //     0x5c841c: stur            d0, [x0, #0x6f]
    // 0x5c8420: StoreField: r0->field_77 = d0
    //     0x5c8420: stur            d0, [x0, #0x77]
    // 0x5c8424: StoreField: r0->field_7f = d0
    //     0x5c8424: stur            d0, [x0, #0x7f]
    // 0x5c8428: StoreField: r0->field_87 = d0
    //     0x5c8428: stur            d0, [x0, #0x87]
    // 0x5c842c: StoreField: r0->field_8f = d0
    //     0x5c842c: stur            d0, [x0, #0x8f]
    // 0x5c8430: StoreField: r0->field_97 = d0
    //     0x5c8430: stur            d0, [x0, #0x97]
    // 0x5c8434: StoreField: r0->field_9f = r1
    //     0x5c8434: stur            x1, [x0, #0x9f]
    // 0x5c8438: StoreField: r0->field_a7 = r2
    //     0x5c8438: stur            w2, [x0, #0xa7]
    // 0x5c843c: LeaveFrame
    //     0x5c843c: mov             SP, fp
    //     0x5c8440: ldp             fp, lr, [SP], #0x10
    // 0x5c8444: ret
    //     0x5c8444: ret             
    // 0x5c8448: r0 = StateError()
    //     0x5c8448: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x5c844c: mov             x1, x0
    // 0x5c8450: r0 = "Unreachable"
    //     0x5c8450: ldr             x0, [PP, #0x5ba0]  ; [pp+0x5ba0] "Unreachable"
    // 0x5c8454: StoreField: r1->field_b = r0
    //     0x5c8454: stur            w0, [x1, #0xb]
    // 0x5c8458: mov             x0, x1
    // 0x5c845c: r0 = Throw()
    //     0x5c845c: bl              #0xd67e38  ; ThrowStub
    // 0x5c8460: brk             #0
    // 0x5c8464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5c8464: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5c8468: b               #0x5c7300
    // 0x5c846c: r0 = NullErrorSharedWithFPURegs()
    //     0x5c846c: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
  }
  [closure] static bool <anonymous closure>(dynamic, PointerData) {
    // ** addr: 0x5c8500, size: 0x24
    // 0x5c8500: ldr             x1, [SP]
    // 0x5c8504: LoadField: r2 = r1->field_1b
    //     0x5c8504: ldur            w2, [x1, #0x1b]
    // 0x5c8508: DecompressPointer r2
    //     0x5c8508: add             x2, x2, HEAP, lsl #32
    // 0x5c850c: r16 = Instance_PointerSignalKind
    //     0x5c850c: ldr             x16, [PP, #0x5ba8]  ; [pp+0x5ba8] Obj!PointerSignalKind@b67071
    // 0x5c8510: cmp             w2, w16
    // 0x5c8514: r16 = true
    //     0x5c8514: add             x16, NULL, #0x20  ; true
    // 0x5c8518: r17 = false
    //     0x5c8518: add             x17, NULL, #0x30  ; false
    // 0x5c851c: csel            x0, x16, x17, ne
    // 0x5c8520: ret
    //     0x5c8520: ret             
  }
}

// lib: , url: package:flutter/src/gestures/tap.dart

// class id: 1049171, size: 0x8
class :: {
}

// class id: 2256, size: 0x14, field offset: 0x8
class TapUpDetails extends Object {

  const Offset globalPosition(TapUpDetails) {
    // ** addr: 0xd64bac, size: 0x28
    // 0xd64bac: ldr             x1, [SP]
    // 0xd64bb0: LoadField: r0 = r1->field_7
    //     0xd64bb0: ldur            w0, [x1, #7]
    // 0xd64bb4: DecompressPointer r0
    //     0xd64bb4: add             x0, x0, HEAP, lsl #32
    // 0xd64bb8: ret
    //     0xd64bb8: ret             
  }
}

// class id: 2257, size: 0x14, field offset: 0x8
class TapDownDetails extends Object {

  const Offset globalPosition(TapDownDetails) {
    // ** addr: 0xd64bac, size: 0x28
    // 0xd64bac: ldr             x1, [SP]
    // 0xd64bb0: LoadField: r0 = r1->field_7
    //     0xd64bb0: ldur            w0, [x1, #7]
    // 0xd64bb4: DecompressPointer r0
    //     0xd64bb4: add             x0, x0, HEAP, lsl #32
    // 0xd64bb8: ret
    //     0xd64bb8: ret             
  }
}

// class id: 2357, size: 0x54, field offset: 0x44
abstract class BaseTapGestureRecognizer extends PrimaryPointerGestureRecognizer {

  _ startTrackingPointer(/* No info */) {
    // ** addr: 0x7110d4, size: 0x48
    // 0x7110d4: EnterFrame
    //     0x7110d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7110d8: mov             fp, SP
    // 0x7110dc: CheckStackOverflow
    //     0x7110dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7110e0: cmp             SP, x16
    //     0x7110e4: b.ls            #0x711114
    // 0x7110e8: ldr             x16, [fp, #0x20]
    // 0x7110ec: SaveReg r16
    //     0x7110ec: str             x16, [SP, #-8]!
    // 0x7110f0: ldr             x0, [fp, #0x18]
    // 0x7110f4: ldr             x16, [fp, #0x10]
    // 0x7110f8: stp             x16, x0, [SP, #-0x10]!
    // 0x7110fc: r0 = startTrackingPointer()
    //     0x7110fc: bl              #0x71111c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::startTrackingPointer
    // 0x711100: add             SP, SP, #0x18
    // 0x711104: r0 = Null
    //     0x711104: mov             x0, NULL
    // 0x711108: LeaveFrame
    //     0x711108: mov             SP, fp
    //     0x71110c: ldp             fp, lr, [SP], #0x10
    // 0x711110: ret
    //     0x711110: ret             
    // 0x711114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711114: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711118: b               #0x7110e8
  }
  _ resolve(/* No info */) {
    // ** addr: 0x7155e4, size: 0x78
    // 0x7155e4: EnterFrame
    //     0x7155e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7155e8: mov             fp, SP
    // 0x7155ec: CheckStackOverflow
    //     0x7155ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7155f0: cmp             SP, x16
    //     0x7155f4: b.ls            #0x715654
    // 0x7155f8: ldr             x0, [fp, #0x18]
    // 0x7155fc: LoadField: r1 = r0->field_47
    //     0x7155fc: ldur            w1, [x0, #0x47]
    // 0x715600: DecompressPointer r1
    //     0x715600: add             x1, x1, HEAP, lsl #32
    // 0x715604: tbnz            w1, #4, #0x71562c
    // 0x715608: r16 = "spontaneous"
    //     0x715608: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e7a8] "spontaneous"
    //     0x71560c: ldr             x16, [x16, #0x7a8]
    // 0x715610: stp             x16, x0, [SP, #-0x10]!
    // 0x715614: r0 = _checkCancel()
    //     0x715614: bl              #0x71567c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkCancel
    // 0x715618: add             SP, SP, #0x10
    // 0x71561c: ldr             x16, [fp, #0x18]
    // 0x715620: SaveReg r16
    //     0x715620: str             x16, [SP, #-8]!
    // 0x715624: r0 = _reset()
    //     0x715624: bl              #0x71565c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0x715628: add             SP, SP, #8
    // 0x71562c: ldr             x16, [fp, #0x18]
    // 0x715630: r30 = Instance_GestureDisposition
    //     0x715630: add             lr, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0x715634: ldr             lr, [lr, #0xeb8]
    // 0x715638: stp             lr, x16, [SP, #-0x10]!
    // 0x71563c: r0 = resolve()
    //     0x71563c: bl              #0x715700  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0x715640: add             SP, SP, #0x10
    // 0x715644: r0 = Null
    //     0x715644: mov             x0, NULL
    // 0x715648: LeaveFrame
    //     0x715648: mov             SP, fp
    //     0x71564c: ldp             fp, lr, [SP], #0x10
    // 0x715650: ret
    //     0x715650: ret             
    // 0x715654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x715654: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715658: b               #0x7155f8
  }
  _ _reset(/* No info */) {
    // ** addr: 0x71565c, size: 0x20
    // 0x71565c: r1 = false
    //     0x71565c: add             x1, NULL, #0x30  ; false
    // 0x715660: ldr             x2, [SP]
    // 0x715664: StoreField: r2->field_43 = r1
    //     0x715664: stur            w1, [x2, #0x43]
    // 0x715668: StoreField: r2->field_47 = r1
    //     0x715668: stur            w1, [x2, #0x47]
    // 0x71566c: StoreField: r2->field_4f = rNULL
    //     0x71566c: stur            NULL, [x2, #0x4f]
    // 0x715670: StoreField: r2->field_4b = rNULL
    //     0x715670: stur            NULL, [x2, #0x4b]
    // 0x715674: r0 = Null
    //     0x715674: mov             x0, NULL
    // 0x715678: ret
    //     0x715678: ret             
  }
  _ _checkCancel(/* No info */) {
    // ** addr: 0x71567c, size: 0x84
    // 0x71567c: EnterFrame
    //     0x71567c: stp             fp, lr, [SP, #-0x10]!
    //     0x715680: mov             fp, SP
    // 0x715684: CheckStackOverflow
    //     0x715684: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715688: cmp             SP, x16
    //     0x71568c: b.ls            #0x7156f4
    // 0x715690: ldr             x0, [fp, #0x18]
    // 0x715694: LoadField: r1 = r0->field_4b
    //     0x715694: ldur            w1, [x0, #0x4b]
    // 0x715698: DecompressPointer r1
    //     0x715698: add             x1, x1, HEAP, lsl #32
    // 0x71569c: cmp             w1, NULL
    // 0x7156a0: b.eq            #0x7156fc
    // 0x7156a4: r2 = LoadClassIdInstr(r0)
    //     0x7156a4: ldur            x2, [x0, #-1]
    //     0x7156a8: ubfx            x2, x2, #0xc, #0x14
    // 0x7156ac: lsl             x2, x2, #1
    // 0x7156b0: r17 = 4716
    //     0x7156b0: mov             x17, #0x126c
    // 0x7156b4: cmp             w2, w17
    // 0x7156b8: b.eq            #0x7156e4
    // 0x7156bc: r2 = LoadClassIdInstr(r0)
    //     0x7156bc: ldur            x2, [x0, #-1]
    //     0x7156c0: ubfx            x2, x2, #0xc, #0x14
    // 0x7156c4: stp             x1, x0, [SP, #-0x10]!
    // 0x7156c8: ldr             x16, [fp, #0x10]
    // 0x7156cc: SaveReg r16
    //     0x7156cc: str             x16, [SP, #-8]!
    // 0x7156d0: mov             x0, x2
    // 0x7156d4: r0 = GDT[cid_x0 + -0xf06]()
    //     0x7156d4: sub             lr, x0, #0xf06
    //     0x7156d8: ldr             lr, [x21, lr, lsl #3]
    //     0x7156dc: blr             lr
    // 0x7156e0: add             SP, SP, #0x18
    // 0x7156e4: r0 = Null
    //     0x7156e4: mov             x0, NULL
    // 0x7156e8: LeaveFrame
    //     0x7156e8: mov             SP, fp
    //     0x7156ec: ldp             fp, lr, [SP], #0x10
    // 0x7156f0: ret
    //     0x7156f0: ret             
    // 0x7156f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7156f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7156f8: b               #0x715690
    // 0x7156fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7156fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkDown(/* No info */) {
    // ** addr: 0x782b04, size: 0xa4
    // 0x782b04: EnterFrame
    //     0x782b04: stp             fp, lr, [SP, #-0x10]!
    //     0x782b08: mov             fp, SP
    // 0x782b0c: CheckStackOverflow
    //     0x782b0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782b10: cmp             SP, x16
    //     0x782b14: b.ls            #0x782b9c
    // 0x782b18: ldr             x1, [fp, #0x10]
    // 0x782b1c: LoadField: r0 = r1->field_43
    //     0x782b1c: ldur            w0, [x1, #0x43]
    // 0x782b20: DecompressPointer r0
    //     0x782b20: add             x0, x0, HEAP, lsl #32
    // 0x782b24: tbnz            w0, #4, #0x782b38
    // 0x782b28: r0 = Null
    //     0x782b28: mov             x0, NULL
    // 0x782b2c: LeaveFrame
    //     0x782b2c: mov             SP, fp
    //     0x782b30: ldp             fp, lr, [SP], #0x10
    // 0x782b34: ret
    //     0x782b34: ret             
    // 0x782b38: LoadField: r0 = r1->field_4b
    //     0x782b38: ldur            w0, [x1, #0x4b]
    // 0x782b3c: DecompressPointer r0
    //     0x782b3c: add             x0, x0, HEAP, lsl #32
    // 0x782b40: cmp             w0, NULL
    // 0x782b44: b.eq            #0x782ba4
    // 0x782b48: r2 = LoadClassIdInstr(r1)
    //     0x782b48: ldur            x2, [x1, #-1]
    //     0x782b4c: ubfx            x2, x2, #0xc, #0x14
    // 0x782b50: lsl             x2, x2, #1
    // 0x782b54: r17 = 4716
    //     0x782b54: mov             x17, #0x126c
    // 0x782b58: cmp             w2, w17
    // 0x782b5c: b.eq            #0x782b84
    // 0x782b60: r2 = LoadClassIdInstr(r1)
    //     0x782b60: ldur            x2, [x1, #-1]
    //     0x782b64: ubfx            x2, x2, #0xc, #0x14
    // 0x782b68: stp             x0, x1, [SP, #-0x10]!
    // 0x782b6c: mov             x0, x2
    // 0x782b70: r0 = GDT[cid_x0 + -0xf1d]()
    //     0x782b70: sub             lr, x0, #0xf1d
    //     0x782b74: ldr             lr, [x21, lr, lsl #3]
    //     0x782b78: blr             lr
    // 0x782b7c: add             SP, SP, #0x10
    // 0x782b80: ldr             x1, [fp, #0x10]
    // 0x782b84: r2 = true
    //     0x782b84: add             x2, NULL, #0x20  ; true
    // 0x782b88: StoreField: r1->field_43 = r2
    //     0x782b88: stur            w2, [x1, #0x43]
    // 0x782b8c: r0 = Null
    //     0x782b8c: mov             x0, NULL
    // 0x782b90: LeaveFrame
    //     0x782b90: mov             SP, fp
    //     0x782b94: ldp             fp, lr, [SP], #0x10
    // 0x782b98: ret
    //     0x782b98: ret             
    // 0x782b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782b9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782ba0: b               #0x782b18
    // 0x782ba4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x782ba4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0x782ba8, size: 0xc0
    // 0x782ba8: EnterFrame
    //     0x782ba8: stp             fp, lr, [SP, #-0x10]!
    //     0x782bac: mov             fp, SP
    // 0x782bb0: CheckStackOverflow
    //     0x782bb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x782bb4: cmp             SP, x16
    //     0x782bb8: b.ls            #0x782c60
    // 0x782bbc: ldr             x0, [fp, #0x18]
    // 0x782bc0: LoadField: r1 = r0->field_2f
    //     0x782bc0: ldur            w1, [x0, #0x2f]
    // 0x782bc4: DecompressPointer r1
    //     0x782bc4: add             x1, x1, HEAP, lsl #32
    // 0x782bc8: r16 = Instance_GestureRecognizerState
    //     0x782bc8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21508] Obj!GestureRecognizerState@b65a91
    //     0x782bcc: ldr             x16, [x16, #0x508]
    // 0x782bd0: cmp             w1, w16
    // 0x782bd4: b.ne            #0x782c2c
    // 0x782bd8: LoadField: r1 = r0->field_4b
    //     0x782bd8: ldur            w1, [x0, #0x4b]
    // 0x782bdc: DecompressPointer r1
    //     0x782bdc: add             x1, x1, HEAP, lsl #32
    // 0x782be0: cmp             w1, NULL
    // 0x782be4: b.eq            #0x782c04
    // 0x782be8: LoadField: r1 = r0->field_4f
    //     0x782be8: ldur            w1, [x0, #0x4f]
    // 0x782bec: DecompressPointer r1
    //     0x782bec: add             x1, x1, HEAP, lsl #32
    // 0x782bf0: cmp             w1, NULL
    // 0x782bf4: b.eq            #0x782c04
    // 0x782bf8: SaveReg r0
    //     0x782bf8: str             x0, [SP, #-8]!
    // 0x782bfc: r0 = _reset()
    //     0x782bfc: bl              #0x71565c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0x782c00: add             SP, SP, #8
    // 0x782c04: ldr             x1, [fp, #0x18]
    // 0x782c08: ldr             x0, [fp, #0x10]
    // 0x782c0c: StoreField: r1->field_4b = r0
    //     0x782c0c: stur            w0, [x1, #0x4b]
    //     0x782c10: ldurb           w16, [x1, #-1]
    //     0x782c14: ldurb           w17, [x0, #-1]
    //     0x782c18: and             x16, x17, x16, lsr #2
    //     0x782c1c: tst             x16, HEAP, lsr #32
    //     0x782c20: b.eq            #0x782c28
    //     0x782c24: bl              #0xd6826c
    // 0x782c28: b               #0x782c30
    // 0x782c2c: mov             x1, x0
    // 0x782c30: LoadField: r0 = r1->field_4b
    //     0x782c30: ldur            w0, [x1, #0x4b]
    // 0x782c34: DecompressPointer r0
    //     0x782c34: add             x0, x0, HEAP, lsl #32
    // 0x782c38: cmp             w0, NULL
    // 0x782c3c: b.eq            #0x782c50
    // 0x782c40: ldr             x16, [fp, #0x10]
    // 0x782c44: stp             x16, x1, [SP, #-0x10]!
    // 0x782c48: r0 = addAllowedPointer()
    //     0x782c48: bl              #0x7825d0  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::addAllowedPointer
    // 0x782c4c: add             SP, SP, #0x10
    // 0x782c50: r0 = Null
    //     0x782c50: mov             x0, NULL
    // 0x782c54: LeaveFrame
    //     0x782c54: mov             SP, fp
    //     0x782c58: ldp             fp, lr, [SP], #0x10
    // 0x782c5c: ret
    //     0x782c5c: ret             
    // 0x782c60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x782c60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x782c64: b               #0x782bbc
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0xbdaff4, size: 0xcc
    // 0xbdaff4: EnterFrame
    //     0xbdaff4: stp             fp, lr, [SP, #-0x10]!
    //     0xbdaff8: mov             fp, SP
    // 0xbdaffc: CheckStackOverflow
    //     0xbdaffc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdb000: cmp             SP, x16
    //     0xbdb004: b.ls            #0xbdb0b8
    // 0xbdb008: ldr             x16, [fp, #0x18]
    // 0xbdb00c: SaveReg r16
    //     0xbdb00c: str             x16, [SP, #-8]!
    // 0xbdb010: ldr             x0, [fp, #0x10]
    // 0xbdb014: SaveReg r0
    //     0xbdb014: str             x0, [SP, #-8]!
    // 0xbdb018: r0 = acceptGesture()
    //     0xbdb018: bl              #0x782a5c  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::acceptGesture
    // 0xbdb01c: add             SP, SP, #0x10
    // 0xbdb020: ldr             x2, [fp, #0x18]
    // 0xbdb024: LoadField: r3 = r2->field_33
    //     0xbdb024: ldur            w3, [x2, #0x33]
    // 0xbdb028: DecompressPointer r3
    //     0xbdb028: add             x3, x3, HEAP, lsl #32
    // 0xbdb02c: ldr             x4, [fp, #0x10]
    // 0xbdb030: r0 = BoxInt64Instr(r4)
    //     0xbdb030: sbfiz           x0, x4, #1, #0x1f
    //     0xbdb034: cmp             x4, x0, asr #1
    //     0xbdb038: b.eq            #0xbdb044
    //     0xbdb03c: bl              #0xd69bb8
    //     0xbdb040: stur            x4, [x0, #7]
    // 0xbdb044: cmp             w0, w3
    // 0xbdb048: b.eq            #0xbdb084
    // 0xbdb04c: and             w16, w0, w3
    // 0xbdb050: branchIfSmi(r16, 0xbdb0a8)
    //     0xbdb050: tbz             w16, #0, #0xbdb0a8
    // 0xbdb054: r16 = LoadClassIdInstr(r0)
    //     0xbdb054: ldur            x16, [x0, #-1]
    //     0xbdb058: ubfx            x16, x16, #0xc, #0x14
    // 0xbdb05c: cmp             x16, #0x3c
    // 0xbdb060: b.ne            #0xbdb0a8
    // 0xbdb064: r16 = LoadClassIdInstr(r3)
    //     0xbdb064: ldur            x16, [x3, #-1]
    //     0xbdb068: ubfx            x16, x16, #0xc, #0x14
    // 0xbdb06c: cmp             x16, #0x3c
    // 0xbdb070: b.ne            #0xbdb0a8
    // 0xbdb074: LoadField: r16 = r0->field_7
    //     0xbdb074: ldur            x16, [x0, #7]
    // 0xbdb078: LoadField: r17 = r3->field_7
    //     0xbdb078: ldur            x17, [x3, #7]
    // 0xbdb07c: cmp             x16, x17
    // 0xbdb080: b.ne            #0xbdb0a8
    // 0xbdb084: SaveReg r2
    //     0xbdb084: str             x2, [SP, #-8]!
    // 0xbdb088: r0 = _checkDown()
    //     0xbdb088: bl              #0x782b04  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkDown
    // 0xbdb08c: add             SP, SP, #8
    // 0xbdb090: ldr             x0, [fp, #0x18]
    // 0xbdb094: r1 = true
    //     0xbdb094: add             x1, NULL, #0x20  ; true
    // 0xbdb098: StoreField: r0->field_47 = r1
    //     0xbdb098: stur            w1, [x0, #0x47]
    // 0xbdb09c: SaveReg r0
    //     0xbdb09c: str             x0, [SP, #-8]!
    // 0xbdb0a0: r0 = _checkUp()
    //     0xbdb0a0: bl              #0xbdb0c0  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkUp
    // 0xbdb0a4: add             SP, SP, #8
    // 0xbdb0a8: r0 = Null
    //     0xbdb0a8: mov             x0, NULL
    // 0xbdb0ac: LeaveFrame
    //     0xbdb0ac: mov             SP, fp
    //     0xbdb0b0: ldp             fp, lr, [SP], #0x10
    // 0xbdb0b4: ret
    //     0xbdb0b4: ret             
    // 0xbdb0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdb0b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdb0bc: b               #0xbdb008
  }
  _ _checkUp(/* No info */) {
    // ** addr: 0xbdb0c0, size: 0xe4
    // 0xbdb0c0: EnterFrame
    //     0xbdb0c0: stp             fp, lr, [SP, #-0x10]!
    //     0xbdb0c4: mov             fp, SP
    // 0xbdb0c8: CheckStackOverflow
    //     0xbdb0c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdb0cc: cmp             SP, x16
    //     0xbdb0d0: b.ls            #0xbdb198
    // 0xbdb0d4: ldr             x1, [fp, #0x10]
    // 0xbdb0d8: LoadField: r0 = r1->field_47
    //     0xbdb0d8: ldur            w0, [x1, #0x47]
    // 0xbdb0dc: DecompressPointer r0
    //     0xbdb0dc: add             x0, x0, HEAP, lsl #32
    // 0xbdb0e0: tbnz            w0, #4, #0xbdb0f4
    // 0xbdb0e4: LoadField: r0 = r1->field_4f
    //     0xbdb0e4: ldur            w0, [x1, #0x4f]
    // 0xbdb0e8: DecompressPointer r0
    //     0xbdb0e8: add             x0, x0, HEAP, lsl #32
    // 0xbdb0ec: cmp             w0, NULL
    // 0xbdb0f0: b.ne            #0xbdb104
    // 0xbdb0f4: r0 = Null
    //     0xbdb0f4: mov             x0, NULL
    // 0xbdb0f8: LeaveFrame
    //     0xbdb0f8: mov             SP, fp
    //     0xbdb0fc: ldp             fp, lr, [SP], #0x10
    // 0xbdb100: ret
    //     0xbdb100: ret             
    // 0xbdb104: LoadField: r2 = r1->field_4b
    //     0xbdb104: ldur            w2, [x1, #0x4b]
    // 0xbdb108: DecompressPointer r2
    //     0xbdb108: add             x2, x2, HEAP, lsl #32
    // 0xbdb10c: cmp             w2, NULL
    // 0xbdb110: b.eq            #0xbdb1a0
    // 0xbdb114: r3 = LoadClassIdInstr(r1)
    //     0xbdb114: ldur            x3, [x1, #-1]
    //     0xbdb118: ubfx            x3, x3, #0xc, #0x14
    // 0xbdb11c: lsl             x3, x3, #1
    // 0xbdb120: r17 = 4716
    //     0xbdb120: mov             x17, #0x126c
    // 0xbdb124: cmp             w3, w17
    // 0xbdb128: b.ne            #0xbdb154
    // 0xbdb12c: LoadField: r0 = r1->field_53
    //     0xbdb12c: ldur            w0, [x1, #0x53]
    // 0xbdb130: DecompressPointer r0
    //     0xbdb130: add             x0, x0, HEAP, lsl #32
    // 0xbdb134: cmp             w0, NULL
    // 0xbdb138: b.eq            #0xbdb178
    // 0xbdb13c: SaveReg r0
    //     0xbdb13c: str             x0, [SP, #-8]!
    // 0xbdb140: ClosureCall
    //     0xbdb140: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbdb144: ldur            x2, [x0, #0x1f]
    //     0xbdb148: blr             x2
    // 0xbdb14c: add             SP, SP, #8
    // 0xbdb150: b               #0xbdb178
    // 0xbdb154: r3 = LoadClassIdInstr(r1)
    //     0xbdb154: ldur            x3, [x1, #-1]
    //     0xbdb158: ubfx            x3, x3, #0xc, #0x14
    // 0xbdb15c: stp             x2, x1, [SP, #-0x10]!
    // 0xbdb160: SaveReg r0
    //     0xbdb160: str             x0, [SP, #-8]!
    // 0xbdb164: mov             x0, x3
    // 0xbdb168: r0 = GDT[cid_x0 + -0xf0e]()
    //     0xbdb168: sub             lr, x0, #0xf0e
    //     0xbdb16c: ldr             lr, [x21, lr, lsl #3]
    //     0xbdb170: blr             lr
    // 0xbdb174: add             SP, SP, #0x18
    // 0xbdb178: ldr             x16, [fp, #0x10]
    // 0xbdb17c: SaveReg r16
    //     0xbdb17c: str             x16, [SP, #-8]!
    // 0xbdb180: r0 = _reset()
    //     0xbdb180: bl              #0x71565c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0xbdb184: add             SP, SP, #8
    // 0xbdb188: r0 = Null
    //     0xbdb188: mov             x0, NULL
    // 0xbdb18c: LeaveFrame
    //     0xbdb18c: mov             SP, fp
    //     0xbdb190: ldp             fp, lr, [SP], #0x10
    // 0xbdb194: ret
    //     0xbdb194: ret             
    // 0xbdb198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdb198: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdb19c: b               #0xbdb0d4
    // 0xbdb1a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdb1a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handlePrimaryPointer(/* No info */) {
    // ** addr: 0xbdd518, size: 0x1f0
    // 0xbdd518: EnterFrame
    //     0xbdd518: stp             fp, lr, [SP, #-0x10]!
    //     0xbdd51c: mov             fp, SP
    // 0xbdd520: AllocStack(0x8)
    //     0xbdd520: sub             SP, SP, #8
    // 0xbdd524: CheckStackOverflow
    //     0xbdd524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdd528: cmp             SP, x16
    //     0xbdd52c: b.ls            #0xbdd6f8
    // 0xbdd530: ldr             x0, [fp, #0x10]
    // 0xbdd534: r2 = Null
    //     0xbdd534: mov             x2, NULL
    // 0xbdd538: r1 = Null
    //     0xbdd538: mov             x1, NULL
    // 0xbdd53c: cmp             w0, NULL
    // 0xbdd540: b.eq            #0xbdd560
    // 0xbdd544: branchIfSmi(r0, 0xbdd560)
    //     0xbdd544: tbz             w0, #0, #0xbdd560
    // 0xbdd548: r3 = LoadClassIdInstr(r0)
    //     0xbdd548: ldur            x3, [x0, #-1]
    //     0xbdd54c: ubfx            x3, x3, #0xc, #0x14
    // 0xbdd550: cmp             x3, #0x906
    // 0xbdd554: b.eq            #0xbdd568
    // 0xbdd558: cmp             x3, #0xb3d
    // 0xbdd55c: b.eq            #0xbdd568
    // 0xbdd560: r0 = false
    //     0xbdd560: add             x0, NULL, #0x30  ; false
    // 0xbdd564: b               #0xbdd56c
    // 0xbdd568: r0 = true
    //     0xbdd568: add             x0, NULL, #0x20  ; true
    // 0xbdd56c: tbnz            w0, #4, #0xbdd5a4
    // 0xbdd570: ldr             x3, [fp, #0x18]
    // 0xbdd574: ldr             x0, [fp, #0x10]
    // 0xbdd578: StoreField: r3->field_4f = r0
    //     0xbdd578: stur            w0, [x3, #0x4f]
    //     0xbdd57c: ldurb           w16, [x3, #-1]
    //     0xbdd580: ldurb           w17, [x0, #-1]
    //     0xbdd584: and             x16, x17, x16, lsr #2
    //     0xbdd588: tst             x16, HEAP, lsr #32
    //     0xbdd58c: b.eq            #0xbdd594
    //     0xbdd590: bl              #0xd682ac
    // 0xbdd594: SaveReg r3
    //     0xbdd594: str             x3, [SP, #-8]!
    // 0xbdd598: r0 = _checkUp()
    //     0xbdd598: bl              #0xbdb0c0  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkUp
    // 0xbdd59c: add             SP, SP, #8
    // 0xbdd5a0: b               #0xbdd6e8
    // 0xbdd5a4: ldr             x3, [fp, #0x18]
    // 0xbdd5a8: ldr             x0, [fp, #0x10]
    // 0xbdd5ac: r2 = Null
    //     0xbdd5ac: mov             x2, NULL
    // 0xbdd5b0: r1 = Null
    //     0xbdd5b0: mov             x1, NULL
    // 0xbdd5b4: cmp             w0, NULL
    // 0xbdd5b8: b.eq            #0xbdd5d8
    // 0xbdd5bc: branchIfSmi(r0, 0xbdd5d8)
    //     0xbdd5bc: tbz             w0, #0, #0xbdd5d8
    // 0xbdd5c0: r3 = LoadClassIdInstr(r0)
    //     0xbdd5c0: ldur            x3, [x0, #-1]
    //     0xbdd5c4: ubfx            x3, x3, #0xc, #0x14
    // 0xbdd5c8: cmp             x3, #0x8f8
    // 0xbdd5cc: b.eq            #0xbdd5e0
    // 0xbdd5d0: cmp             x3, #0xb35
    // 0xbdd5d4: b.eq            #0xbdd5e0
    // 0xbdd5d8: r0 = false
    //     0xbdd5d8: add             x0, NULL, #0x30  ; false
    // 0xbdd5dc: b               #0xbdd5e4
    // 0xbdd5e0: r0 = true
    //     0xbdd5e0: add             x0, NULL, #0x20  ; true
    // 0xbdd5e4: tbnz            w0, #4, #0xbdd634
    // 0xbdd5e8: ldr             x0, [fp, #0x18]
    // 0xbdd5ec: r16 = Instance_GestureDisposition
    //     0xbdd5ec: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xbdd5f0: ldr             x16, [x16, #0xeb8]
    // 0xbdd5f4: stp             x16, x0, [SP, #-0x10]!
    // 0xbdd5f8: r0 = resolve()
    //     0xbdd5f8: bl              #0x7155e4  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::resolve
    // 0xbdd5fc: add             SP, SP, #0x10
    // 0xbdd600: ldr             x0, [fp, #0x18]
    // 0xbdd604: LoadField: r1 = r0->field_43
    //     0xbdd604: ldur            w1, [x0, #0x43]
    // 0xbdd608: DecompressPointer r1
    //     0xbdd608: add             x1, x1, HEAP, lsl #32
    // 0xbdd60c: tbnz            w1, #4, #0xbdd620
    // 0xbdd610: r16 = ""
    //     0xbdd610: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xbdd614: stp             x16, x0, [SP, #-0x10]!
    // 0xbdd618: r0 = _checkCancel()
    //     0xbdd618: bl              #0x71567c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkCancel
    // 0xbdd61c: add             SP, SP, #0x10
    // 0xbdd620: ldr             x16, [fp, #0x18]
    // 0xbdd624: SaveReg r16
    //     0xbdd624: str             x16, [SP, #-8]!
    // 0xbdd628: r0 = _reset()
    //     0xbdd628: bl              #0x71565c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0xbdd62c: add             SP, SP, #8
    // 0xbdd630: b               #0xbdd6e8
    // 0xbdd634: ldr             x1, [fp, #0x18]
    // 0xbdd638: ldr             x0, [fp, #0x10]
    // 0xbdd63c: r2 = LoadClassIdInstr(r0)
    //     0xbdd63c: ldur            x2, [x0, #-1]
    //     0xbdd640: ubfx            x2, x2, #0xc, #0x14
    // 0xbdd644: SaveReg r0
    //     0xbdd644: str             x0, [SP, #-8]!
    // 0xbdd648: mov             x0, x2
    // 0xbdd64c: r0 = GDT[cid_x0 + 0x271c]()
    //     0xbdd64c: mov             x17, #0x271c
    //     0xbdd650: add             lr, x0, x17
    //     0xbdd654: ldr             lr, [x21, lr, lsl #3]
    //     0xbdd658: blr             lr
    // 0xbdd65c: add             SP, SP, #8
    // 0xbdd660: mov             x2, x0
    // 0xbdd664: ldr             x1, [fp, #0x18]
    // 0xbdd668: stur            x2, [fp, #-8]
    // 0xbdd66c: LoadField: r0 = r1->field_4b
    //     0xbdd66c: ldur            w0, [x1, #0x4b]
    // 0xbdd670: DecompressPointer r0
    //     0xbdd670: add             x0, x0, HEAP, lsl #32
    // 0xbdd674: cmp             w0, NULL
    // 0xbdd678: b.eq            #0xbdd700
    // 0xbdd67c: r3 = LoadClassIdInstr(r0)
    //     0xbdd67c: ldur            x3, [x0, #-1]
    //     0xbdd680: ubfx            x3, x3, #0xc, #0x14
    // 0xbdd684: SaveReg r0
    //     0xbdd684: str             x0, [SP, #-8]!
    // 0xbdd688: mov             x0, x3
    // 0xbdd68c: r0 = GDT[cid_x0 + 0x271c]()
    //     0xbdd68c: mov             x17, #0x271c
    //     0xbdd690: add             lr, x0, x17
    //     0xbdd694: ldr             lr, [x21, lr, lsl #3]
    //     0xbdd698: blr             lr
    // 0xbdd69c: add             SP, SP, #8
    // 0xbdd6a0: mov             x1, x0
    // 0xbdd6a4: ldur            x0, [fp, #-8]
    // 0xbdd6a8: cmp             x0, x1
    // 0xbdd6ac: b.eq            #0xbdd6e8
    // 0xbdd6b0: ldr             x0, [fp, #0x18]
    // 0xbdd6b4: r16 = Instance_GestureDisposition
    //     0xbdd6b4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28eb8] Obj!GestureDisposition@b65c31
    //     0xbdd6b8: ldr             x16, [x16, #0xeb8]
    // 0xbdd6bc: stp             x16, x0, [SP, #-0x10]!
    // 0xbdd6c0: r0 = resolve()
    //     0xbdd6c0: bl              #0x7155e4  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::resolve
    // 0xbdd6c4: add             SP, SP, #0x10
    // 0xbdd6c8: ldr             x0, [fp, #0x18]
    // 0xbdd6cc: LoadField: r1 = r0->field_33
    //     0xbdd6cc: ldur            w1, [x0, #0x33]
    // 0xbdd6d0: DecompressPointer r1
    //     0xbdd6d0: add             x1, x1, HEAP, lsl #32
    // 0xbdd6d4: cmp             w1, NULL
    // 0xbdd6d8: b.eq            #0xbdd704
    // 0xbdd6dc: stp             x1, x0, [SP, #-0x10]!
    // 0xbdd6e0: r0 = stopTrackingPointer()
    //     0xbdd6e0: bl              #0x71334c  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xbdd6e4: add             SP, SP, #0x10
    // 0xbdd6e8: r0 = Null
    //     0xbdd6e8: mov             x0, NULL
    // 0xbdd6ec: LeaveFrame
    //     0xbdd6ec: mov             SP, fp
    //     0xbdd6f0: ldp             fp, lr, [SP], #0x10
    // 0xbdd6f4: ret
    //     0xbdd6f4: ret             
    // 0xbdd6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdd6f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdd6fc: b               #0xbdd530
    // 0xbdd700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdd700: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbdd704: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdd704: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0xcee3ac, size: 0xd8
    // 0xcee3ac: EnterFrame
    //     0xcee3ac: stp             fp, lr, [SP, #-0x10]!
    //     0xcee3b0: mov             fp, SP
    // 0xcee3b4: CheckStackOverflow
    //     0xcee3b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcee3b8: cmp             SP, x16
    //     0xcee3bc: b.ls            #0xcee47c
    // 0xcee3c0: ldr             x16, [fp, #0x18]
    // 0xcee3c4: SaveReg r16
    //     0xcee3c4: str             x16, [SP, #-8]!
    // 0xcee3c8: ldr             x0, [fp, #0x10]
    // 0xcee3cc: SaveReg r0
    //     0xcee3cc: str             x0, [SP, #-8]!
    // 0xcee3d0: r0 = rejectGesture()
    //     0xcee3d0: bl              #0xcee2e8  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::rejectGesture
    // 0xcee3d4: add             SP, SP, #0x10
    // 0xcee3d8: ldr             x2, [fp, #0x18]
    // 0xcee3dc: LoadField: r3 = r2->field_33
    //     0xcee3dc: ldur            w3, [x2, #0x33]
    // 0xcee3e0: DecompressPointer r3
    //     0xcee3e0: add             x3, x3, HEAP, lsl #32
    // 0xcee3e4: ldr             x4, [fp, #0x10]
    // 0xcee3e8: r0 = BoxInt64Instr(r4)
    //     0xcee3e8: sbfiz           x0, x4, #1, #0x1f
    //     0xcee3ec: cmp             x4, x0, asr #1
    //     0xcee3f0: b.eq            #0xcee3fc
    //     0xcee3f4: bl              #0xd69bb8
    //     0xcee3f8: stur            x4, [x0, #7]
    // 0xcee3fc: cmp             w0, w3
    // 0xcee400: b.eq            #0xcee43c
    // 0xcee404: and             w16, w0, w3
    // 0xcee408: branchIfSmi(r16, 0xcee46c)
    //     0xcee408: tbz             w16, #0, #0xcee46c
    // 0xcee40c: r16 = LoadClassIdInstr(r0)
    //     0xcee40c: ldur            x16, [x0, #-1]
    //     0xcee410: ubfx            x16, x16, #0xc, #0x14
    // 0xcee414: cmp             x16, #0x3c
    // 0xcee418: b.ne            #0xcee46c
    // 0xcee41c: r16 = LoadClassIdInstr(r3)
    //     0xcee41c: ldur            x16, [x3, #-1]
    //     0xcee420: ubfx            x16, x16, #0xc, #0x14
    // 0xcee424: cmp             x16, #0x3c
    // 0xcee428: b.ne            #0xcee46c
    // 0xcee42c: LoadField: r16 = r0->field_7
    //     0xcee42c: ldur            x16, [x0, #7]
    // 0xcee430: LoadField: r17 = r3->field_7
    //     0xcee430: ldur            x17, [x3, #7]
    // 0xcee434: cmp             x16, x17
    // 0xcee438: b.ne            #0xcee46c
    // 0xcee43c: LoadField: r0 = r2->field_43
    //     0xcee43c: ldur            w0, [x2, #0x43]
    // 0xcee440: DecompressPointer r0
    //     0xcee440: add             x0, x0, HEAP, lsl #32
    // 0xcee444: tbnz            w0, #4, #0xcee45c
    // 0xcee448: r16 = "forced"
    //     0xcee448: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e08] "forced"
    //     0xcee44c: ldr             x16, [x16, #0xe08]
    // 0xcee450: stp             x16, x2, [SP, #-0x10]!
    // 0xcee454: r0 = _checkCancel()
    //     0xcee454: bl              #0x71567c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_checkCancel
    // 0xcee458: add             SP, SP, #0x10
    // 0xcee45c: ldr             x16, [fp, #0x18]
    // 0xcee460: SaveReg r16
    //     0xcee460: str             x16, [SP, #-8]!
    // 0xcee464: r0 = _reset()
    //     0xcee464: bl              #0x71565c  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::_reset
    // 0xcee468: add             SP, SP, #8
    // 0xcee46c: r0 = Null
    //     0xcee46c: mov             x0, NULL
    // 0xcee470: LeaveFrame
    //     0xcee470: mov             SP, fp
    //     0xcee474: ldp             fp, lr, [SP], #0x10
    // 0xcee478: ret
    //     0xcee478: ret             
    // 0xcee47c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee47c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee480: b               #0xcee3c0
  }
}

// class id: 2359, size: 0x80, field offset: 0x54
class TapGestureRecognizer extends BaseTapGestureRecognizer {

  _ isPointerAllowed(/* No info */) {
    // ** addr: 0xa82644, size: 0x160
    // 0xa82644: EnterFrame
    //     0xa82644: stp             fp, lr, [SP, #-0x10]!
    //     0xa82648: mov             fp, SP
    // 0xa8264c: CheckStackOverflow
    //     0xa8264c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa82650: cmp             SP, x16
    //     0xa82654: b.ls            #0xa8279c
    // 0xa82658: ldr             x1, [fp, #0x10]
    // 0xa8265c: r0 = LoadClassIdInstr(r1)
    //     0xa8265c: ldur            x0, [x1, #-1]
    //     0xa82660: ubfx            x0, x0, #0xc, #0x14
    // 0xa82664: SaveReg r1
    //     0xa82664: str             x1, [SP, #-8]!
    // 0xa82668: r0 = GDT[cid_x0 + 0x271c]()
    //     0xa82668: mov             x17, #0x271c
    //     0xa8266c: add             lr, x0, x17
    //     0xa82670: ldr             lr, [x21, lr, lsl #3]
    //     0xa82674: blr             lr
    // 0xa82678: add             SP, SP, #8
    // 0xa8267c: mov             x2, x0
    // 0xa82680: r0 = BoxInt64Instr(r2)
    //     0xa82680: sbfiz           x0, x2, #1, #0x1f
    //     0xa82684: cmp             x2, x0, asr #1
    //     0xa82688: b.eq            #0xa82694
    //     0xa8268c: bl              #0xd69bb8
    //     0xa82690: stur            x2, [x0, #7]
    // 0xa82694: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xa82694: mov             x1, #0x76
    //     0xa82698: tbz             w0, #0, #0xa826a8
    //     0xa8269c: ldur            x1, [x0, #-1]
    //     0xa826a0: ubfx            x1, x1, #0xc, #0x14
    //     0xa826a4: lsl             x1, x1, #1
    // 0xa826a8: cmp             w1, #0x76
    // 0xa826ac: b.ne            #0xa8278c
    // 0xa826b0: cmp             x2, #2
    // 0xa826b4: b.gt            #0xa8276c
    // 0xa826b8: cmp             x2, #1
    // 0xa826bc: b.gt            #0xa8271c
    // 0xa826c0: cmp             w0, #2
    // 0xa826c4: b.ne            #0xa8278c
    // 0xa826c8: ldr             x0, [fp, #0x18]
    // 0xa826cc: LoadField: r1 = r0->field_53
    //     0xa826cc: ldur            w1, [x0, #0x53]
    // 0xa826d0: DecompressPointer r1
    //     0xa826d0: add             x1, x1, HEAP, lsl #32
    // 0xa826d4: cmp             w1, NULL
    // 0xa826d8: b.ne            #0xa82750
    // 0xa826dc: LoadField: r1 = r0->field_5b
    //     0xa826dc: ldur            w1, [x0, #0x5b]
    // 0xa826e0: DecompressPointer r1
    //     0xa826e0: add             x1, x1, HEAP, lsl #32
    // 0xa826e4: cmp             w1, NULL
    // 0xa826e8: b.ne            #0xa82750
    // 0xa826ec: LoadField: r1 = r0->field_57
    //     0xa826ec: ldur            w1, [x0, #0x57]
    // 0xa826f0: DecompressPointer r1
    //     0xa826f0: add             x1, x1, HEAP, lsl #32
    // 0xa826f4: cmp             w1, NULL
    // 0xa826f8: b.ne            #0xa82750
    // 0xa826fc: LoadField: r1 = r0->field_5f
    //     0xa826fc: ldur            w1, [x0, #0x5f]
    // 0xa82700: DecompressPointer r1
    //     0xa82700: add             x1, x1, HEAP, lsl #32
    // 0xa82704: cmp             w1, NULL
    // 0xa82708: b.ne            #0xa82750
    // 0xa8270c: r0 = false
    //     0xa8270c: add             x0, NULL, #0x30  ; false
    // 0xa82710: LeaveFrame
    //     0xa82710: mov             SP, fp
    //     0xa82714: ldp             fp, lr, [SP], #0x10
    // 0xa82718: ret
    //     0xa82718: ret             
    // 0xa8271c: ldr             x0, [fp, #0x18]
    // 0xa82720: LoadField: r1 = r0->field_63
    //     0xa82720: ldur            w1, [x0, #0x63]
    // 0xa82724: DecompressPointer r1
    //     0xa82724: add             x1, x1, HEAP, lsl #32
    // 0xa82728: cmp             w1, NULL
    // 0xa8272c: b.ne            #0xa82750
    // 0xa82730: LoadField: r1 = r0->field_67
    //     0xa82730: ldur            w1, [x0, #0x67]
    // 0xa82734: DecompressPointer r1
    //     0xa82734: add             x1, x1, HEAP, lsl #32
    // 0xa82738: cmp             w1, NULL
    // 0xa8273c: b.ne            #0xa82750
    // 0xa82740: r0 = false
    //     0xa82740: add             x0, NULL, #0x30  ; false
    // 0xa82744: LeaveFrame
    //     0xa82744: mov             SP, fp
    //     0xa82748: ldp             fp, lr, [SP], #0x10
    // 0xa8274c: ret
    //     0xa8274c: ret             
    // 0xa82750: ldr             x16, [fp, #0x10]
    // 0xa82754: stp             x16, x0, [SP, #-0x10]!
    // 0xa82758: r0 = isPointerAllowed()
    //     0xa82758: bl              #0xa829e0  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::isPointerAllowed
    // 0xa8275c: add             SP, SP, #0x10
    // 0xa82760: LeaveFrame
    //     0xa82760: mov             SP, fp
    //     0xa82764: ldp             fp, lr, [SP], #0x10
    // 0xa82768: ret
    //     0xa82768: ret             
    // 0xa8276c: cmp             x2, #4
    // 0xa82770: b.lt            #0xa8278c
    // 0xa82774: cmp             w0, #8
    // 0xa82778: b.ne            #0xa8278c
    // 0xa8277c: r0 = false
    //     0xa8277c: add             x0, NULL, #0x30  ; false
    // 0xa82780: LeaveFrame
    //     0xa82780: mov             SP, fp
    //     0xa82784: ldp             fp, lr, [SP], #0x10
    // 0xa82788: ret
    //     0xa82788: ret             
    // 0xa8278c: r0 = false
    //     0xa8278c: add             x0, NULL, #0x30  ; false
    // 0xa82790: LeaveFrame
    //     0xa82790: mov             SP, fp
    //     0xa82794: ldp             fp, lr, [SP], #0x10
    // 0xa82798: ret
    //     0xa82798: ret             
    // 0xa8279c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8279c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa827a0: b               #0xa82658
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xbdd4a8, size: 0x70
    // 0xbdd4a8: EnterFrame
    //     0xbdd4a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbdd4ac: mov             fp, SP
    // 0xbdd4b0: ldr             x0, [fp, #0x10]
    // 0xbdd4b4: LoadField: r1 = r0->field_17
    //     0xbdd4b4: ldur            w1, [x0, #0x17]
    // 0xbdd4b8: DecompressPointer r1
    //     0xbdd4b8: add             x1, x1, HEAP, lsl #32
    // 0xbdd4bc: CheckStackOverflow
    //     0xbdd4bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdd4c0: cmp             SP, x16
    //     0xbdd4c4: b.ls            #0xbdd50c
    // 0xbdd4c8: LoadField: r0 = r1->field_f
    //     0xbdd4c8: ldur            w0, [x1, #0xf]
    // 0xbdd4cc: DecompressPointer r0
    //     0xbdd4cc: add             x0, x0, HEAP, lsl #32
    // 0xbdd4d0: LoadField: r2 = r0->field_67
    //     0xbdd4d0: ldur            w2, [x0, #0x67]
    // 0xbdd4d4: DecompressPointer r2
    //     0xbdd4d4: add             x2, x2, HEAP, lsl #32
    // 0xbdd4d8: cmp             w2, NULL
    // 0xbdd4dc: b.eq            #0xbdd514
    // 0xbdd4e0: LoadField: r0 = r1->field_13
    //     0xbdd4e0: ldur            w0, [x1, #0x13]
    // 0xbdd4e4: DecompressPointer r0
    //     0xbdd4e4: add             x0, x0, HEAP, lsl #32
    // 0xbdd4e8: stp             x0, x2, [SP, #-0x10]!
    // 0xbdd4ec: mov             x0, x2
    // 0xbdd4f0: ClosureCall
    //     0xbdd4f0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbdd4f4: ldur            x2, [x0, #0x1f]
    //     0xbdd4f8: blr             x2
    // 0xbdd4fc: add             SP, SP, #0x10
    // 0xbdd500: LeaveFrame
    //     0xbdd500: mov             SP, fp
    //     0xbdd504: ldp             fp, lr, [SP], #0x10
    // 0xbdd508: ret
    //     0xbdd508: ret             
    // 0xbdd50c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdd50c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdd510: b               #0xbdd4c8
    // 0xbdd514: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbdd514: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleTapCancel(/* No info */) {
    // ** addr: 0xceeeec, size: 0x18c
    // 0xceeeec: EnterFrame
    //     0xceeeec: stp             fp, lr, [SP, #-0x10]!
    //     0xceeef0: mov             fp, SP
    // 0xceeef4: AllocStack(0x8)
    //     0xceeef4: sub             SP, SP, #8
    // 0xceeef8: CheckStackOverflow
    //     0xceeef8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xceeefc: cmp             SP, x16
    //     0xceef00: b.ls            #0xcef06c
    // 0xceef04: ldr             x16, [fp, #0x10]
    // 0xceef08: r30 = ""
    //     0xceef08: ldr             lr, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xceef0c: stp             lr, x16, [SP, #-0x10]!
    // 0xceef10: r0 = ==()
    //     0xceef10: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xceef14: add             SP, SP, #0x10
    // 0xceef18: tbnz            w0, #4, #0xceef28
    // 0xceef1c: ldr             x0, [fp, #0x10]
    // 0xceef20: mov             x1, x0
    // 0xceef24: b               #0xceef5c
    // 0xceef28: ldr             x0, [fp, #0x10]
    // 0xceef2c: r1 = Null
    //     0xceef2c: mov             x1, NULL
    // 0xceef30: r2 = 4
    //     0xceef30: mov             x2, #4
    // 0xceef34: r0 = AllocateArray()
    //     0xceef34: bl              #0xd6987c  ; AllocateArrayStub
    // 0xceef38: mov             x1, x0
    // 0xceef3c: ldr             x0, [fp, #0x10]
    // 0xceef40: StoreField: r1->field_f = r0
    //     0xceef40: stur            w0, [x1, #0xf]
    // 0xceef44: r17 = " "
    //     0xceef44: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xceef48: StoreField: r1->field_13 = r17
    //     0xceef48: stur            w17, [x1, #0x13]
    // 0xceef4c: SaveReg r1
    //     0xceef4c: str             x1, [SP, #-8]!
    // 0xceef50: r0 = _interpolate()
    //     0xceef50: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xceef54: add             SP, SP, #8
    // 0xceef58: mov             x1, x0
    // 0xceef5c: ldr             x0, [fp, #0x18]
    // 0xceef60: stur            x1, [fp, #-8]
    // 0xceef64: r2 = LoadClassIdInstr(r0)
    //     0xceef64: ldur            x2, [x0, #-1]
    //     0xceef68: ubfx            x2, x2, #0xc, #0x14
    // 0xceef6c: SaveReg r0
    //     0xceef6c: str             x0, [SP, #-8]!
    // 0xceef70: mov             x0, x2
    // 0xceef74: r0 = GDT[cid_x0 + 0x271c]()
    //     0xceef74: mov             x17, #0x271c
    //     0xceef78: add             lr, x0, x17
    //     0xceef7c: ldr             lr, [x21, lr, lsl #3]
    //     0xceef80: blr             lr
    // 0xceef84: add             SP, SP, #8
    // 0xceef88: mov             x2, x0
    // 0xceef8c: r0 = BoxInt64Instr(r2)
    //     0xceef8c: sbfiz           x0, x2, #1, #0x1f
    //     0xceef90: cmp             x2, x0, asr #1
    //     0xceef94: b.eq            #0xceefa0
    //     0xceef98: bl              #0xd69bb8
    //     0xceef9c: stur            x2, [x0, #7]
    // 0xceefa0: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xceefa0: mov             x1, #0x76
    //     0xceefa4: tbz             w0, #0, #0xceefb4
    //     0xceefa8: ldur            x1, [x0, #-1]
    //     0xceefac: ubfx            x1, x1, #0xc, #0x14
    //     0xceefb0: lsl             x1, x1, #1
    // 0xceefb4: cmp             w1, #0x76
    // 0xceefb8: b.ne            #0xcef05c
    // 0xceefbc: cmp             x2, #2
    // 0xceefc0: b.gt            #0xcef04c
    // 0xceefc4: cmp             x2, #1
    // 0xceefc8: b.gt            #0xcef05c
    // 0xceefcc: cmp             w0, #2
    // 0xceefd0: b.ne            #0xcef05c
    // 0xceefd4: ldr             x0, [fp, #0x20]
    // 0xceefd8: LoadField: r1 = r0->field_5f
    //     0xceefd8: ldur            w1, [x0, #0x5f]
    // 0xceefdc: DecompressPointer r1
    //     0xceefdc: add             x1, x1, HEAP, lsl #32
    // 0xceefe0: cmp             w1, NULL
    // 0xceefe4: b.eq            #0xcef05c
    // 0xceefe8: ldur            x3, [fp, #-8]
    // 0xceefec: r1 = Null
    //     0xceefec: mov             x1, NULL
    // 0xceeff0: r2 = 4
    //     0xceeff0: mov             x2, #4
    // 0xceeff4: r0 = AllocateArray()
    //     0xceeff4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xceeff8: mov             x1, x0
    // 0xceeffc: ldur            x0, [fp, #-8]
    // 0xcef000: StoreField: r1->field_f = r0
    //     0xcef000: stur            w0, [x1, #0xf]
    // 0xcef004: r17 = "onTapCancel"
    //     0xcef004: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c4b8] "onTapCancel"
    //     0xcef008: ldr             x17, [x17, #0x4b8]
    // 0xcef00c: StoreField: r1->field_13 = r17
    //     0xcef00c: stur            w17, [x1, #0x13]
    // 0xcef010: SaveReg r1
    //     0xcef010: str             x1, [SP, #-8]!
    // 0xcef014: r0 = _interpolate()
    //     0xcef014: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xcef018: add             SP, SP, #8
    // 0xcef01c: ldr             x0, [fp, #0x20]
    // 0xcef020: LoadField: r1 = r0->field_5f
    //     0xcef020: ldur            w1, [x0, #0x5f]
    // 0xcef024: DecompressPointer r1
    //     0xcef024: add             x1, x1, HEAP, lsl #32
    // 0xcef028: cmp             w1, NULL
    // 0xcef02c: b.eq            #0xcef074
    // 0xcef030: r16 = <void?>
    //     0xcef030: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xcef034: stp             x0, x16, [SP, #-0x10]!
    // 0xcef038: SaveReg r1
    //     0xcef038: str             x1, [SP, #-8]!
    // 0xcef03c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcef03c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcef040: r0 = invokeCallback()
    //     0xcef040: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xcef044: add             SP, SP, #0x18
    // 0xcef048: b               #0xcef05c
    // 0xcef04c: cmp             x2, #4
    // 0xcef050: b.lt            #0xcef05c
    // 0xcef054: cmp             w0, #8
    // 0xcef058: b.eq            #0xcef05c
    // 0xcef05c: r0 = Null
    //     0xcef05c: mov             x0, NULL
    // 0xcef060: LeaveFrame
    //     0xcef060: mov             SP, fp
    //     0xcef064: ldp             fp, lr, [SP], #0x10
    // 0xcef068: ret
    //     0xcef068: ret             
    // 0xcef06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef06c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef070: b               #0xceef04
    // 0xcef074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcef074: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleTapUp(/* No info */) {
    // ** addr: 0xcef164, size: 0x240
    // 0xcef164: EnterFrame
    //     0xcef164: stp             fp, lr, [SP, #-0x10]!
    //     0xcef168: mov             fp, SP
    // 0xcef16c: AllocStack(0x20)
    //     0xcef16c: sub             SP, SP, #0x20
    // 0xcef170: CheckStackOverflow
    //     0xcef170: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcef174: cmp             SP, x16
    //     0xcef178: b.ls            #0xcef39c
    // 0xcef17c: r1 = 2
    //     0xcef17c: mov             x1, #2
    // 0xcef180: r0 = AllocateContext()
    //     0xcef180: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcef184: mov             x2, x0
    // 0xcef188: ldr             x1, [fp, #0x20]
    // 0xcef18c: stur            x2, [fp, #-8]
    // 0xcef190: StoreField: r2->field_f = r1
    //     0xcef190: stur            w1, [x2, #0xf]
    // 0xcef194: ldr             x3, [fp, #0x10]
    // 0xcef198: r0 = LoadClassIdInstr(r3)
    //     0xcef198: ldur            x0, [x3, #-1]
    //     0xcef19c: ubfx            x0, x0, #0xc, #0x14
    // 0xcef1a0: SaveReg r3
    //     0xcef1a0: str             x3, [SP, #-8]!
    // 0xcef1a4: r0 = GDT[cid_x0 + -0xf60]()
    //     0xcef1a4: sub             lr, x0, #0xf60
    //     0xcef1a8: ldr             lr, [x21, lr, lsl #3]
    //     0xcef1ac: blr             lr
    // 0xcef1b0: add             SP, SP, #8
    // 0xcef1b4: mov             x2, x0
    // 0xcef1b8: ldr             x1, [fp, #0x10]
    // 0xcef1bc: stur            x2, [fp, #-0x10]
    // 0xcef1c0: r0 = LoadClassIdInstr(r1)
    //     0xcef1c0: ldur            x0, [x1, #-1]
    //     0xcef1c4: ubfx            x0, x0, #0xc, #0x14
    // 0xcef1c8: SaveReg r1
    //     0xcef1c8: str             x1, [SP, #-8]!
    // 0xcef1cc: r0 = GDT[cid_x0 + -0xfd9]()
    //     0xcef1cc: sub             lr, x0, #0xfd9
    //     0xcef1d0: ldr             lr, [x21, lr, lsl #3]
    //     0xcef1d4: blr             lr
    // 0xcef1d8: add             SP, SP, #8
    // 0xcef1dc: mov             x1, x0
    // 0xcef1e0: ldr             x0, [fp, #0x10]
    // 0xcef1e4: stur            x1, [fp, #-0x18]
    // 0xcef1e8: r2 = LoadClassIdInstr(r0)
    //     0xcef1e8: ldur            x2, [x0, #-1]
    //     0xcef1ec: ubfx            x2, x2, #0xc, #0x14
    // 0xcef1f0: SaveReg r0
    //     0xcef1f0: str             x0, [SP, #-8]!
    // 0xcef1f4: mov             x0, x2
    // 0xcef1f8: r0 = GDT[cid_x0 + 0x57c0]()
    //     0xcef1f8: mov             x17, #0x57c0
    //     0xcef1fc: add             lr, x0, x17
    //     0xcef200: ldr             lr, [x21, lr, lsl #3]
    //     0xcef204: blr             lr
    // 0xcef208: add             SP, SP, #8
    // 0xcef20c: stur            x0, [fp, #-0x20]
    // 0xcef210: r0 = TapUpDetails()
    //     0xcef210: bl              #0x9b4acc  ; AllocateTapUpDetailsStub -> TapUpDetails (size=0x14)
    // 0xcef214: mov             x1, x0
    // 0xcef218: ldur            x0, [fp, #-0x10]
    // 0xcef21c: StoreField: r1->field_f = r0
    //     0xcef21c: stur            w0, [x1, #0xf]
    // 0xcef220: ldur            x0, [fp, #-0x18]
    // 0xcef224: StoreField: r1->field_7 = r0
    //     0xcef224: stur            w0, [x1, #7]
    // 0xcef228: ldur            x0, [fp, #-0x20]
    // 0xcef22c: StoreField: r1->field_b = r0
    //     0xcef22c: stur            w0, [x1, #0xb]
    // 0xcef230: mov             x0, x1
    // 0xcef234: ldur            x2, [fp, #-8]
    // 0xcef238: StoreField: r2->field_13 = r0
    //     0xcef238: stur            w0, [x2, #0x13]
    //     0xcef23c: ldurb           w16, [x2, #-1]
    //     0xcef240: ldurb           w17, [x0, #-1]
    //     0xcef244: and             x16, x17, x16, lsr #2
    //     0xcef248: tst             x16, HEAP, lsr #32
    //     0xcef24c: b.eq            #0xcef254
    //     0xcef250: bl              #0xd6828c
    // 0xcef254: ldr             x0, [fp, #0x18]
    // 0xcef258: r1 = LoadClassIdInstr(r0)
    //     0xcef258: ldur            x1, [x0, #-1]
    //     0xcef25c: ubfx            x1, x1, #0xc, #0x14
    // 0xcef260: SaveReg r0
    //     0xcef260: str             x0, [SP, #-8]!
    // 0xcef264: mov             x0, x1
    // 0xcef268: r0 = GDT[cid_x0 + 0x271c]()
    //     0xcef268: mov             x17, #0x271c
    //     0xcef26c: add             lr, x0, x17
    //     0xcef270: ldr             lr, [x21, lr, lsl #3]
    //     0xcef274: blr             lr
    // 0xcef278: add             SP, SP, #8
    // 0xcef27c: mov             x2, x0
    // 0xcef280: r0 = BoxInt64Instr(r2)
    //     0xcef280: sbfiz           x0, x2, #1, #0x1f
    //     0xcef284: cmp             x2, x0, asr #1
    //     0xcef288: b.eq            #0xcef294
    //     0xcef28c: bl              #0xd69bb8
    //     0xcef290: stur            x2, [x0, #7]
    // 0xcef294: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xcef294: mov             x1, #0x76
    //     0xcef298: tbz             w0, #0, #0xcef2a8
    //     0xcef29c: ldur            x1, [x0, #-1]
    //     0xcef2a0: ubfx            x1, x1, #0xc, #0x14
    //     0xcef2a4: lsl             x1, x1, #1
    // 0xcef2a8: cmp             w1, #0x76
    // 0xcef2ac: b.ne            #0xcef38c
    // 0xcef2b0: cmp             x2, #2
    // 0xcef2b4: b.gt            #0xcef37c
    // 0xcef2b8: cmp             x2, #1
    // 0xcef2bc: b.gt            #0xcef338
    // 0xcef2c0: cmp             w0, #2
    // 0xcef2c4: b.ne            #0xcef38c
    // 0xcef2c8: ldr             x0, [fp, #0x20]
    // 0xcef2cc: LoadField: r1 = r0->field_57
    //     0xcef2cc: ldur            w1, [x0, #0x57]
    // 0xcef2d0: DecompressPointer r1
    //     0xcef2d0: add             x1, x1, HEAP, lsl #32
    // 0xcef2d4: cmp             w1, NULL
    // 0xcef2d8: b.eq            #0xcef308
    // 0xcef2dc: ldur            x2, [fp, #-8]
    // 0xcef2e0: r1 = Function '<anonymous closure>':.
    //     0xcef2e0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e788] AnonymousClosure: (0xcef40c), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapUp (0xcef164)
    //     0xcef2e4: ldr             x1, [x1, #0x788]
    // 0xcef2e8: r0 = AllocateClosure()
    //     0xcef2e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcef2ec: r16 = <void?>
    //     0xcef2ec: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xcef2f0: ldr             lr, [fp, #0x20]
    // 0xcef2f4: stp             lr, x16, [SP, #-0x10]!
    // 0xcef2f8: SaveReg r0
    //     0xcef2f8: str             x0, [SP, #-8]!
    // 0xcef2fc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcef2fc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcef300: r0 = invokeCallback()
    //     0xcef300: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xcef304: add             SP, SP, #0x18
    // 0xcef308: ldr             x0, [fp, #0x20]
    // 0xcef30c: LoadField: r1 = r0->field_5b
    //     0xcef30c: ldur            w1, [x0, #0x5b]
    // 0xcef310: DecompressPointer r1
    //     0xcef310: add             x1, x1, HEAP, lsl #32
    // 0xcef314: cmp             w1, NULL
    // 0xcef318: b.eq            #0xcef38c
    // 0xcef31c: r16 = <void?>
    //     0xcef31c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xcef320: stp             x0, x16, [SP, #-0x10]!
    // 0xcef324: SaveReg r1
    //     0xcef324: str             x1, [SP, #-8]!
    // 0xcef328: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcef328: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcef32c: r0 = invokeCallback()
    //     0xcef32c: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xcef330: add             SP, SP, #0x18
    // 0xcef334: b               #0xcef38c
    // 0xcef338: ldr             x0, [fp, #0x20]
    // 0xcef33c: LoadField: r1 = r0->field_63
    //     0xcef33c: ldur            w1, [x0, #0x63]
    // 0xcef340: DecompressPointer r1
    //     0xcef340: add             x1, x1, HEAP, lsl #32
    // 0xcef344: cmp             w1, NULL
    // 0xcef348: b.eq            #0xcef38c
    // 0xcef34c: ldur            x2, [fp, #-8]
    // 0xcef350: r1 = Function '<anonymous closure>':.
    //     0xcef350: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e790] AnonymousClosure: (0xcef3a4), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapUp (0xcef164)
    //     0xcef354: ldr             x1, [x1, #0x790]
    // 0xcef358: r0 = AllocateClosure()
    //     0xcef358: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcef35c: r16 = <void?>
    //     0xcef35c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xcef360: ldr             lr, [fp, #0x20]
    // 0xcef364: stp             lr, x16, [SP, #-0x10]!
    // 0xcef368: SaveReg r0
    //     0xcef368: str             x0, [SP, #-8]!
    // 0xcef36c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcef36c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcef370: r0 = invokeCallback()
    //     0xcef370: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xcef374: add             SP, SP, #0x18
    // 0xcef378: b               #0xcef38c
    // 0xcef37c: cmp             x2, #4
    // 0xcef380: b.lt            #0xcef38c
    // 0xcef384: cmp             w0, #8
    // 0xcef388: b.eq            #0xcef38c
    // 0xcef38c: r0 = Null
    //     0xcef38c: mov             x0, NULL
    // 0xcef390: LeaveFrame
    //     0xcef390: mov             SP, fp
    //     0xcef394: ldp             fp, lr, [SP], #0x10
    // 0xcef398: ret
    //     0xcef398: ret             
    // 0xcef39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef39c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef3a0: b               #0xcef17c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xcef3a4, size: 0x68
    // 0xcef3a4: EnterFrame
    //     0xcef3a4: stp             fp, lr, [SP, #-0x10]!
    //     0xcef3a8: mov             fp, SP
    // 0xcef3ac: ldr             x0, [fp, #0x10]
    // 0xcef3b0: LoadField: r1 = r0->field_17
    //     0xcef3b0: ldur            w1, [x0, #0x17]
    // 0xcef3b4: DecompressPointer r1
    //     0xcef3b4: add             x1, x1, HEAP, lsl #32
    // 0xcef3b8: CheckStackOverflow
    //     0xcef3b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcef3bc: cmp             SP, x16
    //     0xcef3c0: b.ls            #0xcef400
    // 0xcef3c4: LoadField: r0 = r1->field_f
    //     0xcef3c4: ldur            w0, [x1, #0xf]
    // 0xcef3c8: DecompressPointer r0
    //     0xcef3c8: add             x0, x0, HEAP, lsl #32
    // 0xcef3cc: LoadField: r1 = r0->field_63
    //     0xcef3cc: ldur            w1, [x0, #0x63]
    // 0xcef3d0: DecompressPointer r1
    //     0xcef3d0: add             x1, x1, HEAP, lsl #32
    // 0xcef3d4: cmp             w1, NULL
    // 0xcef3d8: b.eq            #0xcef408
    // 0xcef3dc: SaveReg r1
    //     0xcef3dc: str             x1, [SP, #-8]!
    // 0xcef3e0: mov             x0, x1
    // 0xcef3e4: ClosureCall
    //     0xcef3e4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xcef3e8: ldur            x2, [x0, #0x1f]
    //     0xcef3ec: blr             x2
    // 0xcef3f0: add             SP, SP, #8
    // 0xcef3f4: LeaveFrame
    //     0xcef3f4: mov             SP, fp
    //     0xcef3f8: ldp             fp, lr, [SP], #0x10
    // 0xcef3fc: ret
    //     0xcef3fc: ret             
    // 0xcef400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef400: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef404: b               #0xcef3c4
    // 0xcef408: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcef408: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xcef40c, size: 0x70
    // 0xcef40c: EnterFrame
    //     0xcef40c: stp             fp, lr, [SP, #-0x10]!
    //     0xcef410: mov             fp, SP
    // 0xcef414: ldr             x0, [fp, #0x10]
    // 0xcef418: LoadField: r1 = r0->field_17
    //     0xcef418: ldur            w1, [x0, #0x17]
    // 0xcef41c: DecompressPointer r1
    //     0xcef41c: add             x1, x1, HEAP, lsl #32
    // 0xcef420: CheckStackOverflow
    //     0xcef420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcef424: cmp             SP, x16
    //     0xcef428: b.ls            #0xcef470
    // 0xcef42c: LoadField: r0 = r1->field_f
    //     0xcef42c: ldur            w0, [x1, #0xf]
    // 0xcef430: DecompressPointer r0
    //     0xcef430: add             x0, x0, HEAP, lsl #32
    // 0xcef434: LoadField: r2 = r0->field_57
    //     0xcef434: ldur            w2, [x0, #0x57]
    // 0xcef438: DecompressPointer r2
    //     0xcef438: add             x2, x2, HEAP, lsl #32
    // 0xcef43c: cmp             w2, NULL
    // 0xcef440: b.eq            #0xcef478
    // 0xcef444: LoadField: r0 = r1->field_13
    //     0xcef444: ldur            w0, [x1, #0x13]
    // 0xcef448: DecompressPointer r0
    //     0xcef448: add             x0, x0, HEAP, lsl #32
    // 0xcef44c: stp             x0, x2, [SP, #-0x10]!
    // 0xcef450: mov             x0, x2
    // 0xcef454: ClosureCall
    //     0xcef454: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcef458: ldur            x2, [x0, #0x1f]
    //     0xcef45c: blr             x2
    // 0xcef460: add             SP, SP, #0x10
    // 0xcef464: LeaveFrame
    //     0xcef464: mov             SP, fp
    //     0xcef468: ldp             fp, lr, [SP], #0x10
    // 0xcef46c: ret
    //     0xcef46c: ret             
    // 0xcef470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef470: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef474: b               #0xcef42c
    // 0xcef478: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcef478: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleTapDown(/* No info */) {
    // ** addr: 0xcef5cc, size: 0x220
    // 0xcef5cc: EnterFrame
    //     0xcef5cc: stp             fp, lr, [SP, #-0x10]!
    //     0xcef5d0: mov             fp, SP
    // 0xcef5d4: AllocStack(0x20)
    //     0xcef5d4: sub             SP, SP, #0x20
    // 0xcef5d8: CheckStackOverflow
    //     0xcef5d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcef5dc: cmp             SP, x16
    //     0xcef5e0: b.ls            #0xcef7e4
    // 0xcef5e4: r1 = 2
    //     0xcef5e4: mov             x1, #2
    // 0xcef5e8: r0 = AllocateContext()
    //     0xcef5e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcef5ec: mov             x2, x0
    // 0xcef5f0: ldr             x1, [fp, #0x18]
    // 0xcef5f4: stur            x2, [fp, #-8]
    // 0xcef5f8: StoreField: r2->field_f = r1
    //     0xcef5f8: stur            w1, [x2, #0xf]
    // 0xcef5fc: ldr             x3, [fp, #0x10]
    // 0xcef600: r0 = LoadClassIdInstr(r3)
    //     0xcef600: ldur            x0, [x3, #-1]
    //     0xcef604: ubfx            x0, x0, #0xc, #0x14
    // 0xcef608: SaveReg r3
    //     0xcef608: str             x3, [SP, #-8]!
    // 0xcef60c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0xcef60c: sub             lr, x0, #0xfd9
    //     0xcef610: ldr             lr, [x21, lr, lsl #3]
    //     0xcef614: blr             lr
    // 0xcef618: add             SP, SP, #8
    // 0xcef61c: mov             x2, x0
    // 0xcef620: ldr             x1, [fp, #0x10]
    // 0xcef624: stur            x2, [fp, #-0x10]
    // 0xcef628: r0 = LoadClassIdInstr(r1)
    //     0xcef628: ldur            x0, [x1, #-1]
    //     0xcef62c: ubfx            x0, x0, #0xc, #0x14
    // 0xcef630: SaveReg r1
    //     0xcef630: str             x1, [SP, #-8]!
    // 0xcef634: r0 = GDT[cid_x0 + 0x57c0]()
    //     0xcef634: mov             x17, #0x57c0
    //     0xcef638: add             lr, x0, x17
    //     0xcef63c: ldr             lr, [x21, lr, lsl #3]
    //     0xcef640: blr             lr
    // 0xcef644: add             SP, SP, #8
    // 0xcef648: mov             x2, x0
    // 0xcef64c: ldr             x1, [fp, #0x10]
    // 0xcef650: stur            x2, [fp, #-0x18]
    // 0xcef654: r0 = LoadClassIdInstr(r1)
    //     0xcef654: ldur            x0, [x1, #-1]
    //     0xcef658: ubfx            x0, x0, #0xc, #0x14
    // 0xcef65c: SaveReg r1
    //     0xcef65c: str             x1, [SP, #-8]!
    // 0xcef660: r0 = GDT[cid_x0 + -0xfff]()
    //     0xcef660: sub             lr, x0, #0xfff
    //     0xcef664: ldr             lr, [x21, lr, lsl #3]
    //     0xcef668: blr             lr
    // 0xcef66c: add             SP, SP, #8
    // 0xcef670: ldr             x16, [fp, #0x18]
    // 0xcef674: stp             x0, x16, [SP, #-0x10]!
    // 0xcef678: r0 = getKindForPointer()
    //     0xcef678: bl              #0x719b14  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::getKindForPointer
    // 0xcef67c: add             SP, SP, #0x10
    // 0xcef680: stur            x0, [fp, #-0x20]
    // 0xcef684: r0 = TapDownDetails()
    //     0xcef684: bl              #0xcef7ec  ; AllocateTapDownDetailsStub -> TapDownDetails (size=0x14)
    // 0xcef688: mov             x1, x0
    // 0xcef68c: ldur            x0, [fp, #-0x10]
    // 0xcef690: StoreField: r1->field_7 = r0
    //     0xcef690: stur            w0, [x1, #7]
    // 0xcef694: ldur            x0, [fp, #-0x20]
    // 0xcef698: StoreField: r1->field_b = r0
    //     0xcef698: stur            w0, [x1, #0xb]
    // 0xcef69c: ldur            x0, [fp, #-0x18]
    // 0xcef6a0: StoreField: r1->field_f = r0
    //     0xcef6a0: stur            w0, [x1, #0xf]
    // 0xcef6a4: mov             x0, x1
    // 0xcef6a8: ldur            x2, [fp, #-8]
    // 0xcef6ac: StoreField: r2->field_13 = r0
    //     0xcef6ac: stur            w0, [x2, #0x13]
    //     0xcef6b0: ldurb           w16, [x2, #-1]
    //     0xcef6b4: ldurb           w17, [x0, #-1]
    //     0xcef6b8: and             x16, x17, x16, lsr #2
    //     0xcef6bc: tst             x16, HEAP, lsr #32
    //     0xcef6c0: b.eq            #0xcef6c8
    //     0xcef6c4: bl              #0xd6828c
    // 0xcef6c8: ldr             x0, [fp, #0x10]
    // 0xcef6cc: r1 = LoadClassIdInstr(r0)
    //     0xcef6cc: ldur            x1, [x0, #-1]
    //     0xcef6d0: ubfx            x1, x1, #0xc, #0x14
    // 0xcef6d4: SaveReg r0
    //     0xcef6d4: str             x0, [SP, #-8]!
    // 0xcef6d8: mov             x0, x1
    // 0xcef6dc: r0 = GDT[cid_x0 + 0x271c]()
    //     0xcef6dc: mov             x17, #0x271c
    //     0xcef6e0: add             lr, x0, x17
    //     0xcef6e4: ldr             lr, [x21, lr, lsl #3]
    //     0xcef6e8: blr             lr
    // 0xcef6ec: add             SP, SP, #8
    // 0xcef6f0: mov             x2, x0
    // 0xcef6f4: r0 = BoxInt64Instr(r2)
    //     0xcef6f4: sbfiz           x0, x2, #1, #0x1f
    //     0xcef6f8: cmp             x2, x0, asr #1
    //     0xcef6fc: b.eq            #0xcef708
    //     0xcef700: bl              #0xd69bb8
    //     0xcef704: stur            x2, [x0, #7]
    // 0xcef708: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xcef708: mov             x1, #0x76
    //     0xcef70c: tbz             w0, #0, #0xcef71c
    //     0xcef710: ldur            x1, [x0, #-1]
    //     0xcef714: ubfx            x1, x1, #0xc, #0x14
    //     0xcef718: lsl             x1, x1, #1
    // 0xcef71c: cmp             w1, #0x76
    // 0xcef720: b.ne            #0xcef7d4
    // 0xcef724: cmp             x2, #2
    // 0xcef728: b.gt            #0xcef7c4
    // 0xcef72c: cmp             x2, #1
    // 0xcef730: b.gt            #0xcef780
    // 0xcef734: cmp             w0, #2
    // 0xcef738: b.ne            #0xcef7d4
    // 0xcef73c: ldr             x0, [fp, #0x18]
    // 0xcef740: LoadField: r1 = r0->field_53
    //     0xcef740: ldur            w1, [x0, #0x53]
    // 0xcef744: DecompressPointer r1
    //     0xcef744: add             x1, x1, HEAP, lsl #32
    // 0xcef748: cmp             w1, NULL
    // 0xcef74c: b.eq            #0xcef7d4
    // 0xcef750: ldur            x2, [fp, #-8]
    // 0xcef754: r1 = Function '<anonymous closure>':.
    //     0xcef754: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e798] AnonymousClosure: (0xcef7f8), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapDown (0xcef5cc)
    //     0xcef758: ldr             x1, [x1, #0x798]
    // 0xcef75c: r0 = AllocateClosure()
    //     0xcef75c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcef760: r16 = <void?>
    //     0xcef760: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xcef764: ldr             lr, [fp, #0x18]
    // 0xcef768: stp             lr, x16, [SP, #-0x10]!
    // 0xcef76c: SaveReg r0
    //     0xcef76c: str             x0, [SP, #-8]!
    // 0xcef770: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcef770: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcef774: r0 = invokeCallback()
    //     0xcef774: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xcef778: add             SP, SP, #0x18
    // 0xcef77c: b               #0xcef7d4
    // 0xcef780: ldr             x0, [fp, #0x18]
    // 0xcef784: LoadField: r1 = r0->field_67
    //     0xcef784: ldur            w1, [x0, #0x67]
    // 0xcef788: DecompressPointer r1
    //     0xcef788: add             x1, x1, HEAP, lsl #32
    // 0xcef78c: cmp             w1, NULL
    // 0xcef790: b.eq            #0xcef7d4
    // 0xcef794: ldur            x2, [fp, #-8]
    // 0xcef798: r1 = Function '<anonymous closure>':.
    //     0xcef798: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e7a0] AnonymousClosure: (0xbdd4a8), in [package:flutter/src/gestures/tap.dart] TapGestureRecognizer::handleTapDown (0xcef5cc)
    //     0xcef79c: ldr             x1, [x1, #0x7a0]
    // 0xcef7a0: r0 = AllocateClosure()
    //     0xcef7a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcef7a4: r16 = <void?>
    //     0xcef7a4: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xcef7a8: ldr             lr, [fp, #0x18]
    // 0xcef7ac: stp             lr, x16, [SP, #-0x10]!
    // 0xcef7b0: SaveReg r0
    //     0xcef7b0: str             x0, [SP, #-8]!
    // 0xcef7b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcef7b4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcef7b8: r0 = invokeCallback()
    //     0xcef7b8: bl              #0x713b40  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::invokeCallback
    // 0xcef7bc: add             SP, SP, #0x18
    // 0xcef7c0: b               #0xcef7d4
    // 0xcef7c4: cmp             x2, #4
    // 0xcef7c8: b.lt            #0xcef7d4
    // 0xcef7cc: cmp             w0, #8
    // 0xcef7d0: b.eq            #0xcef7d4
    // 0xcef7d4: r0 = Null
    //     0xcef7d4: mov             x0, NULL
    // 0xcef7d8: LeaveFrame
    //     0xcef7d8: mov             SP, fp
    //     0xcef7dc: ldp             fp, lr, [SP], #0x10
    // 0xcef7e0: ret
    //     0xcef7e0: ret             
    // 0xcef7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef7e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef7e8: b               #0xcef5e4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xcef7f8, size: 0x70
    // 0xcef7f8: EnterFrame
    //     0xcef7f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcef7fc: mov             fp, SP
    // 0xcef800: ldr             x0, [fp, #0x10]
    // 0xcef804: LoadField: r1 = r0->field_17
    //     0xcef804: ldur            w1, [x0, #0x17]
    // 0xcef808: DecompressPointer r1
    //     0xcef808: add             x1, x1, HEAP, lsl #32
    // 0xcef80c: CheckStackOverflow
    //     0xcef80c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcef810: cmp             SP, x16
    //     0xcef814: b.ls            #0xcef85c
    // 0xcef818: LoadField: r0 = r1->field_f
    //     0xcef818: ldur            w0, [x1, #0xf]
    // 0xcef81c: DecompressPointer r0
    //     0xcef81c: add             x0, x0, HEAP, lsl #32
    // 0xcef820: LoadField: r2 = r0->field_53
    //     0xcef820: ldur            w2, [x0, #0x53]
    // 0xcef824: DecompressPointer r2
    //     0xcef824: add             x2, x2, HEAP, lsl #32
    // 0xcef828: cmp             w2, NULL
    // 0xcef82c: b.eq            #0xcef864
    // 0xcef830: LoadField: r0 = r1->field_13
    //     0xcef830: ldur            w0, [x1, #0x13]
    // 0xcef834: DecompressPointer r0
    //     0xcef834: add             x0, x0, HEAP, lsl #32
    // 0xcef838: stp             x0, x2, [SP, #-0x10]!
    // 0xcef83c: mov             x0, x2
    // 0xcef840: ClosureCall
    //     0xcef840: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcef844: ldur            x2, [x0, #0x1f]
    //     0xcef848: blr             x2
    // 0xcef84c: add             SP, SP, #0x10
    // 0xcef850: LeaveFrame
    //     0xcef850: mov             SP, fp
    //     0xcef854: ldp             fp, lr, [SP], #0x10
    // 0xcef858: ret
    //     0xcef858: ret             
    // 0xcef85c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef85c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef860: b               #0xcef818
    // 0xcef864: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcef864: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

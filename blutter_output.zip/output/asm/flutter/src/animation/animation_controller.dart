// lib: , url: package:flutter/src/animation/animation_controller.dart

// class id: 1049067, size: 0x8
class :: {

  static late final SpringDescription _kFlingSpringDescription; // offset: 0xcc0

  static SpringDescription _kFlingSpringDescription() {
    // ** addr: 0x82da0c, size: 0x3c
    // 0x82da0c: EnterFrame
    //     0x82da0c: stp             fp, lr, [SP, #-0x10]!
    //     0x82da10: mov             fp, SP
    // 0x82da14: r0 = SpringDescription()
    //     0x82da14: bl              #0x82da48  ; AllocateSpringDescriptionStub -> SpringDescription (size=0x20)
    // 0x82da18: d0 = 1.000000
    //     0x82da18: fmov            d0, #1.00000000
    // 0x82da1c: StoreField: r0->field_7 = d0
    //     0x82da1c: stur            d0, [x0, #7]
    // 0x82da20: d0 = 500.000000
    //     0x82da20: add             x17, PP, #0x34, lsl #12  ; [pp+0x34968] IMM: double(500) from 0x407f400000000000
    //     0x82da24: ldr             d0, [x17, #0x968]
    // 0x82da28: StoreField: r0->field_f = d0
    //     0x82da28: stur            d0, [x0, #0xf]
    // 0x82da2c: fsqrt           d1, d0
    // 0x82da30: d0 = 2.000000
    //     0x82da30: fmov            d0, #2.00000000
    // 0x82da34: fmul            d2, d0, d1
    // 0x82da38: StoreField: r0->field_17 = d2
    //     0x82da38: stur            d2, [x0, #0x17]
    // 0x82da3c: LeaveFrame
    //     0x82da3c: mov             SP, fp
    //     0x82da40: ldp             fp, lr, [SP], #0x10
    // 0x82da44: ret
    //     0x82da44: ret             
  }
}

// class id: 4306, size: 0x34, field offset: 0xc
class _RepeatingSimulation extends Simulation {

  _ _RepeatingSimulation(/* No info */) {
    // ** addr: 0x7b9154, size: 0xa4
    // 0x7b9154: d0 = 1000000.000000
    //     0x7b9154: add             x17, PP, #0xd, lsl #12  ; [pp+0xdbd8] IMM: double(1e+06) from 0x412e848000000000
    //     0x7b9158: ldr             d0, [x17, #0xbd8]
    // 0x7b915c: ldr             x1, [SP, #0x20]
    // 0x7b9160: LoadField: d1 = r1->field_7
    //     0x7b9160: ldur            d1, [x1, #7]
    // 0x7b9164: ldr             x1, [SP, #0x30]
    // 0x7b9168: StoreField: r1->field_b = d1
    //     0x7b9168: stur            d1, [x1, #0xb]
    // 0x7b916c: ldr             d2, [SP, #0x18]
    // 0x7b9170: StoreField: r1->field_13 = d2
    //     0x7b9170: stur            d2, [x1, #0x13]
    // 0x7b9174: ldr             x2, [SP, #0x10]
    // 0x7b9178: StoreField: r1->field_1b = r2
    //     0x7b9178: stur            w2, [x1, #0x1b]
    // 0x7b917c: ldr             x0, [SP]
    // 0x7b9180: StoreField: r1->field_1f = r0
    //     0x7b9180: stur            w0, [x1, #0x1f]
    //     0x7b9184: ldurb           w16, [x1, #-1]
    //     0x7b9188: ldurb           w17, [x0, #-1]
    //     0x7b918c: and             x16, x17, x16, lsr #2
    //     0x7b9190: tst             x16, HEAP, lsr #32
    //     0x7b9194: b.eq            #0x7b91a4
    //     0x7b9198: str             lr, [SP, #-8]!
    //     0x7b919c: bl              #0xd6826c
    //     0x7b91a0: ldr             lr, [SP], #8
    // 0x7b91a4: ldr             x2, [SP, #8]
    // 0x7b91a8: LoadField: r3 = r2->field_7
    //     0x7b91a8: ldur            x3, [x2, #7]
    // 0x7b91ac: scvtf           d3, x3
    // 0x7b91b0: fdiv            d4, d3, d0
    // 0x7b91b4: StoreField: r1->field_23 = d4
    //     0x7b91b4: stur            d4, [x1, #0x23]
    // 0x7b91b8: fcmp            d2, d1
    // 0x7b91bc: b.vs            #0x7b91cc
    // 0x7b91c0: b.ne            #0x7b91cc
    // 0x7b91c4: d0 = 0.000000
    //     0x7b91c4: eor             v0.16b, v0.16b, v0.16b
    // 0x7b91c8: b               #0x7b91e0
    // 0x7b91cc: ldr             x2, [SP, #0x28]
    // 0x7b91d0: fsub            d0, d2, d1
    // 0x7b91d4: LoadField: d1 = r2->field_7
    //     0x7b91d4: ldur            d1, [x2, #7]
    // 0x7b91d8: fdiv            d2, d1, d0
    // 0x7b91dc: fmul            d0, d2, d4
    // 0x7b91e0: r2 = Instance_Tolerance
    //     0x7b91e0: add             x2, PP, #0xd, lsl #12  ; [pp+0xdbd0] Obj!Tolerance@b35651
    //     0x7b91e4: ldr             x2, [x2, #0xbd0]
    // 0x7b91e8: StoreField: r1->field_2b = d0
    //     0x7b91e8: stur            d0, [x1, #0x2b]
    // 0x7b91ec: StoreField: r1->field_7 = r2
    //     0x7b91ec: stur            w2, [x1, #7]
    // 0x7b91f0: r0 = Null
    //     0x7b91f0: mov             x0, NULL
    // 0x7b91f4: ret
    //     0x7b91f4: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0xc2d904, size: 0x1c
    // 0xc2d904: ldr             x0, [SP, #8]
    // 0xc2d908: LoadField: d1 = r0->field_13
    //     0xc2d908: ldur            d1, [x0, #0x13]
    // 0xc2d90c: LoadField: d2 = r0->field_b
    //     0xc2d90c: ldur            d2, [x0, #0xb]
    // 0xc2d910: fsub            d3, d1, d2
    // 0xc2d914: LoadField: d1 = r0->field_23
    //     0xc2d914: ldur            d1, [x0, #0x23]
    // 0xc2d918: fdiv            d0, d3, d1
    // 0xc2d91c: ret
    //     0xc2d91c: ret             
  }
  _ x(/* No info */) {
    // ** addr: 0xcba06c, size: 0x3a0
    // 0xcba06c: EnterFrame
    //     0xcba06c: stp             fp, lr, [SP, #-0x10]!
    //     0xcba070: mov             fp, SP
    // 0xcba074: AllocStack(0x18)
    //     0xcba074: sub             SP, SP, #0x18
    // 0xcba078: CheckStackOverflow
    //     0xcba078: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcba07c: cmp             SP, x16
    //     0xcba080: b.ls            #0xcba330
    // 0xcba084: ldr             x0, [fp, #0x18]
    // 0xcba088: LoadField: d0 = r0->field_2b
    //     0xcba088: ldur            d0, [x0, #0x2b]
    // 0xcba08c: ldr             x1, [fp, #0x10]
    // 0xcba090: LoadField: d1 = r1->field_7
    //     0xcba090: ldur            d1, [x1, #7]
    // 0xcba094: fadd            d2, d1, d0
    // 0xcba098: stur            d2, [fp, #-0x10]
    // 0xcba09c: LoadField: d3 = r0->field_23
    //     0xcba09c: ldur            d3, [x0, #0x23]
    // 0xcba0a0: stur            d3, [fp, #-8]
    // 0xcba0a4: fdiv            d0, d2, d3
    // 0xcba0a8: d1 = 1.000000
    //     0xcba0a8: fmov            d1, #1.00000000
    // 0xcba0ac: stp             fp, lr, [SP, #-0x10]!
    // 0xcba0b0: mov             fp, SP
    // 0xcba0b4: CallRuntime_DartModulo(double, double) -> double
    //     0xcba0b4: and             SP, SP, #0xfffffffffffffff0
    //     0xcba0b8: mov             sp, SP
    //     0xcba0bc: ldr             x16, [THR, #0x558]  ; THR::DartModulo
    //     0xcba0c0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcba0c4: blr             x16
    //     0xcba0c8: mov             x16, #8
    //     0xcba0cc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcba0d0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcba0d4: sub             sp, x16, #1, lsl #12
    //     0xcba0d8: mov             SP, fp
    //     0xcba0dc: ldp             fp, lr, [SP], #0x10
    // 0xcba0e0: mov             v1.16b, v0.16b
    // 0xcba0e4: ldur            d0, [fp, #-0x10]
    // 0xcba0e8: stur            d1, [fp, #-0x18]
    // 0xcba0ec: r0 = inline_Allocate_Double()
    //     0xcba0ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcba0f0: add             x0, x0, #0x10
    //     0xcba0f4: cmp             x1, x0
    //     0xcba0f8: b.ls            #0xcba338
    //     0xcba0fc: str             x0, [THR, #0x60]  ; THR::top
    //     0xcba100: sub             x0, x0, #0xf
    //     0xcba104: mov             x1, #0xd108
    //     0xcba108: movk            x1, #3, lsl #16
    //     0xcba10c: stur            x1, [x0, #-1]
    // 0xcba110: StoreField: r0->field_7 = d0
    //     0xcba110: stur            d0, [x0, #7]
    // 0xcba114: ldur            d0, [fp, #-8]
    // 0xcba118: r1 = inline_Allocate_Double()
    //     0xcba118: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcba11c: add             x1, x1, #0x10
    //     0xcba120: cmp             x2, x1
    //     0xcba124: b.ls            #0xcba348
    //     0xcba128: str             x1, [THR, #0x60]  ; THR::top
    //     0xcba12c: sub             x1, x1, #0xf
    //     0xcba130: mov             x2, #0xd108
    //     0xcba134: movk            x2, #3, lsl #16
    //     0xcba138: stur            x2, [x1, #-1]
    // 0xcba13c: StoreField: r1->field_7 = d0
    //     0xcba13c: stur            d0, [x1, #7]
    // 0xcba140: stp             x1, x0, [SP, #-0x10]!
    // 0xcba144: r0 = ~/()
    //     0xcba144: bl              #0x65adc0  ; [dart:core] _Double::~/
    // 0xcba148: add             SP, SP, #0x10
    // 0xcba14c: r1 = LoadInt32Instr(r0)
    //     0xcba14c: sbfx            x1, x0, #1, #0x1f
    //     0xcba150: tbz             w0, #0, #0xcba158
    //     0xcba154: ldur            x1, [x0, #7]
    // 0xcba158: r0 = 1
    //     0xcba158: mov             x0, #1
    // 0xcba15c: and             x2, x1, x0
    // 0xcba160: ubfx            x2, x2, #0, #0x20
    // 0xcba164: ldr             x1, [fp, #0x18]
    // 0xcba168: LoadField: r0 = r1->field_1b
    //     0xcba168: ldur            w0, [x1, #0x1b]
    // 0xcba16c: DecompressPointer r0
    //     0xcba16c: add             x0, x0, HEAP, lsl #32
    // 0xcba170: tbnz            w0, #4, #0xcba258
    // 0xcba174: cbz             x2, #0xcba250
    // 0xcba178: ldur            d0, [fp, #-0x18]
    // 0xcba17c: LoadField: r0 = r1->field_1f
    //     0xcba17c: ldur            w0, [x1, #0x1f]
    // 0xcba180: DecompressPointer r0
    //     0xcba180: add             x0, x0, HEAP, lsl #32
    // 0xcba184: r16 = Instance__AnimationDirection
    //     0xcba184: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb90] Obj!_AnimationDirection@b65ef1
    //     0xcba188: ldr             x16, [x16, #0xb90]
    // 0xcba18c: stp             x16, x0, [SP, #-0x10]!
    // 0xcba190: ClosureCall
    //     0xcba190: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcba194: ldur            x2, [x0, #0x1f]
    //     0xcba198: blr             x2
    // 0xcba19c: add             SP, SP, #0x10
    // 0xcba1a0: ldr             x1, [fp, #0x18]
    // 0xcba1a4: LoadField: d0 = r1->field_13
    //     0xcba1a4: ldur            d0, [x1, #0x13]
    // 0xcba1a8: LoadField: d1 = r1->field_b
    //     0xcba1a8: ldur            d1, [x1, #0xb]
    // 0xcba1ac: ldur            d2, [fp, #-0x18]
    // 0xcba1b0: r0 = inline_Allocate_Double()
    //     0xcba1b0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcba1b4: add             x0, x0, #0x10
    //     0xcba1b8: cmp             x1, x0
    //     0xcba1bc: b.ls            #0xcba364
    //     0xcba1c0: str             x0, [THR, #0x60]  ; THR::top
    //     0xcba1c4: sub             x0, x0, #0xf
    //     0xcba1c8: mov             x1, #0xd108
    //     0xcba1cc: movk            x1, #3, lsl #16
    //     0xcba1d0: stur            x1, [x0, #-1]
    // 0xcba1d4: StoreField: r0->field_7 = d2
    //     0xcba1d4: stur            d2, [x0, #7]
    // 0xcba1d8: r1 = inline_Allocate_Double()
    //     0xcba1d8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcba1dc: add             x1, x1, #0x10
    //     0xcba1e0: cmp             x2, x1
    //     0xcba1e4: b.ls            #0xcba37c
    //     0xcba1e8: str             x1, [THR, #0x60]  ; THR::top
    //     0xcba1ec: sub             x1, x1, #0xf
    //     0xcba1f0: mov             x2, #0xd108
    //     0xcba1f4: movk            x2, #3, lsl #16
    //     0xcba1f8: stur            x2, [x1, #-1]
    // 0xcba1fc: StoreField: r1->field_7 = d0
    //     0xcba1fc: stur            d0, [x1, #7]
    // 0xcba200: r2 = inline_Allocate_Double()
    //     0xcba200: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xcba204: add             x2, x2, #0x10
    //     0xcba208: cmp             x3, x2
    //     0xcba20c: b.ls            #0xcba398
    //     0xcba210: str             x2, [THR, #0x60]  ; THR::top
    //     0xcba214: sub             x2, x2, #0xf
    //     0xcba218: mov             x3, #0xd108
    //     0xcba21c: movk            x3, #3, lsl #16
    //     0xcba220: stur            x3, [x2, #-1]
    // 0xcba224: StoreField: r2->field_7 = d1
    //     0xcba224: stur            d1, [x2, #7]
    // 0xcba228: stp             x2, x1, [SP, #-0x10]!
    // 0xcba22c: SaveReg r0
    //     0xcba22c: str             x0, [SP, #-8]!
    // 0xcba230: r0 = lerpDouble()
    //     0xcba230: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xcba234: add             SP, SP, #0x18
    // 0xcba238: cmp             w0, NULL
    // 0xcba23c: b.eq            #0xcba3b4
    // 0xcba240: LoadField: d0 = r0->field_7
    //     0xcba240: ldur            d0, [x0, #7]
    // 0xcba244: LeaveFrame
    //     0xcba244: mov             SP, fp
    //     0xcba248: ldp             fp, lr, [SP], #0x10
    // 0xcba24c: ret
    //     0xcba24c: ret             
    // 0xcba250: ldur            d2, [fp, #-0x18]
    // 0xcba254: b               #0xcba25c
    // 0xcba258: ldur            d2, [fp, #-0x18]
    // 0xcba25c: LoadField: r0 = r1->field_1f
    //     0xcba25c: ldur            w0, [x1, #0x1f]
    // 0xcba260: DecompressPointer r0
    //     0xcba260: add             x0, x0, HEAP, lsl #32
    // 0xcba264: r16 = Instance__AnimationDirection
    //     0xcba264: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0xcba268: ldr             x16, [x16, #0xb98]
    // 0xcba26c: stp             x16, x0, [SP, #-0x10]!
    // 0xcba270: ClosureCall
    //     0xcba270: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcba274: ldur            x2, [x0, #0x1f]
    //     0xcba278: blr             x2
    // 0xcba27c: add             SP, SP, #0x10
    // 0xcba280: ldr             x0, [fp, #0x18]
    // 0xcba284: LoadField: d0 = r0->field_b
    //     0xcba284: ldur            d0, [x0, #0xb]
    // 0xcba288: LoadField: d1 = r0->field_13
    //     0xcba288: ldur            d1, [x0, #0x13]
    // 0xcba28c: ldur            d2, [fp, #-0x18]
    // 0xcba290: r0 = inline_Allocate_Double()
    //     0xcba290: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcba294: add             x0, x0, #0x10
    //     0xcba298: cmp             x1, x0
    //     0xcba29c: b.ls            #0xcba3b8
    //     0xcba2a0: str             x0, [THR, #0x60]  ; THR::top
    //     0xcba2a4: sub             x0, x0, #0xf
    //     0xcba2a8: mov             x1, #0xd108
    //     0xcba2ac: movk            x1, #3, lsl #16
    //     0xcba2b0: stur            x1, [x0, #-1]
    // 0xcba2b4: StoreField: r0->field_7 = d2
    //     0xcba2b4: stur            d2, [x0, #7]
    // 0xcba2b8: r1 = inline_Allocate_Double()
    //     0xcba2b8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcba2bc: add             x1, x1, #0x10
    //     0xcba2c0: cmp             x2, x1
    //     0xcba2c4: b.ls            #0xcba3d0
    //     0xcba2c8: str             x1, [THR, #0x60]  ; THR::top
    //     0xcba2cc: sub             x1, x1, #0xf
    //     0xcba2d0: mov             x2, #0xd108
    //     0xcba2d4: movk            x2, #3, lsl #16
    //     0xcba2d8: stur            x2, [x1, #-1]
    // 0xcba2dc: StoreField: r1->field_7 = d0
    //     0xcba2dc: stur            d0, [x1, #7]
    // 0xcba2e0: r2 = inline_Allocate_Double()
    //     0xcba2e0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xcba2e4: add             x2, x2, #0x10
    //     0xcba2e8: cmp             x3, x2
    //     0xcba2ec: b.ls            #0xcba3ec
    //     0xcba2f0: str             x2, [THR, #0x60]  ; THR::top
    //     0xcba2f4: sub             x2, x2, #0xf
    //     0xcba2f8: mov             x3, #0xd108
    //     0xcba2fc: movk            x3, #3, lsl #16
    //     0xcba300: stur            x3, [x2, #-1]
    // 0xcba304: StoreField: r2->field_7 = d1
    //     0xcba304: stur            d1, [x2, #7]
    // 0xcba308: stp             x2, x1, [SP, #-0x10]!
    // 0xcba30c: SaveReg r0
    //     0xcba30c: str             x0, [SP, #-8]!
    // 0xcba310: r0 = lerpDouble()
    //     0xcba310: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xcba314: add             SP, SP, #0x18
    // 0xcba318: cmp             w0, NULL
    // 0xcba31c: b.eq            #0xcba408
    // 0xcba320: LoadField: d0 = r0->field_7
    //     0xcba320: ldur            d0, [x0, #7]
    // 0xcba324: LeaveFrame
    //     0xcba324: mov             SP, fp
    //     0xcba328: ldp             fp, lr, [SP], #0x10
    // 0xcba32c: ret
    //     0xcba32c: ret             
    // 0xcba330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcba330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcba334: b               #0xcba084
    // 0xcba338: stp             q0, q1, [SP, #-0x20]!
    // 0xcba33c: r0 = AllocateDouble()
    //     0xcba33c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcba340: ldp             q0, q1, [SP], #0x20
    // 0xcba344: b               #0xcba110
    // 0xcba348: stp             q0, q1, [SP, #-0x20]!
    // 0xcba34c: SaveReg r0
    //     0xcba34c: str             x0, [SP, #-8]!
    // 0xcba350: r0 = AllocateDouble()
    //     0xcba350: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcba354: mov             x1, x0
    // 0xcba358: RestoreReg r0
    //     0xcba358: ldr             x0, [SP], #8
    // 0xcba35c: ldp             q0, q1, [SP], #0x20
    // 0xcba360: b               #0xcba13c
    // 0xcba364: stp             q1, q2, [SP, #-0x20]!
    // 0xcba368: SaveReg d0
    //     0xcba368: str             q0, [SP, #-0x10]!
    // 0xcba36c: r0 = AllocateDouble()
    //     0xcba36c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcba370: RestoreReg d0
    //     0xcba370: ldr             q0, [SP], #0x10
    // 0xcba374: ldp             q1, q2, [SP], #0x20
    // 0xcba378: b               #0xcba1d4
    // 0xcba37c: stp             q0, q1, [SP, #-0x20]!
    // 0xcba380: SaveReg r0
    //     0xcba380: str             x0, [SP, #-8]!
    // 0xcba384: r0 = AllocateDouble()
    //     0xcba384: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcba388: mov             x1, x0
    // 0xcba38c: RestoreReg r0
    //     0xcba38c: ldr             x0, [SP], #8
    // 0xcba390: ldp             q0, q1, [SP], #0x20
    // 0xcba394: b               #0xcba1fc
    // 0xcba398: SaveReg d1
    //     0xcba398: str             q1, [SP, #-0x10]!
    // 0xcba39c: stp             x0, x1, [SP, #-0x10]!
    // 0xcba3a0: r0 = AllocateDouble()
    //     0xcba3a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcba3a4: mov             x2, x0
    // 0xcba3a8: ldp             x0, x1, [SP], #0x10
    // 0xcba3ac: RestoreReg d1
    //     0xcba3ac: ldr             q1, [SP], #0x10
    // 0xcba3b0: b               #0xcba224
    // 0xcba3b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcba3b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcba3b8: stp             q1, q2, [SP, #-0x20]!
    // 0xcba3bc: SaveReg d0
    //     0xcba3bc: str             q0, [SP, #-0x10]!
    // 0xcba3c0: r0 = AllocateDouble()
    //     0xcba3c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcba3c4: RestoreReg d0
    //     0xcba3c4: ldr             q0, [SP], #0x10
    // 0xcba3c8: ldp             q1, q2, [SP], #0x20
    // 0xcba3cc: b               #0xcba2b4
    // 0xcba3d0: stp             q0, q1, [SP, #-0x20]!
    // 0xcba3d4: SaveReg r0
    //     0xcba3d4: str             x0, [SP, #-8]!
    // 0xcba3d8: r0 = AllocateDouble()
    //     0xcba3d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcba3dc: mov             x1, x0
    // 0xcba3e0: RestoreReg r0
    //     0xcba3e0: ldr             x0, [SP], #8
    // 0xcba3e4: ldp             q0, q1, [SP], #0x20
    // 0xcba3e8: b               #0xcba2dc
    // 0xcba3ec: SaveReg d1
    //     0xcba3ec: str             q1, [SP, #-0x10]!
    // 0xcba3f0: stp             x0, x1, [SP, #-0x10]!
    // 0xcba3f4: r0 = AllocateDouble()
    //     0xcba3f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcba3f8: mov             x2, x0
    // 0xcba3fc: ldp             x0, x1, [SP], #0x10
    // 0xcba400: RestoreReg d1
    //     0xcba400: ldr             q1, [SP], #0x10
    // 0xcba404: b               #0xcba304
    // 0xcba408: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcba408: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4307, size: 0x28, field offset: 0xc
class _InterpolationSimulation extends Simulation {

  _ _InterpolationSimulation(/* No info */) {
    // ** addr: 0x592dc4, size: 0x7c
    // 0x592dc4: r1 = Instance_Tolerance
    //     0x592dc4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdbd0] Obj!Tolerance@b35651
    //     0x592dc8: ldr             x1, [x1, #0xbd0]
    // 0x592dcc: d0 = 1000000.000000
    //     0x592dcc: add             x17, PP, #0xd, lsl #12  ; [pp+0xdbd8] IMM: double(1e+06) from 0x412e848000000000
    //     0x592dd0: ldr             d0, [x17, #0xbd8]
    // 0x592dd4: ldr             x2, [SP, #0x20]
    // 0x592dd8: LoadField: d1 = r2->field_7
    //     0x592dd8: ldur            d1, [x2, #7]
    // 0x592ddc: ldr             x2, [SP, #0x28]
    // 0x592de0: StoreField: r2->field_13 = d1
    //     0x592de0: stur            d1, [x2, #0x13]
    // 0x592de4: ldr             x3, [SP, #0x18]
    // 0x592de8: LoadField: d1 = r3->field_7
    //     0x592de8: ldur            d1, [x3, #7]
    // 0x592dec: StoreField: r2->field_1b = d1
    //     0x592dec: stur            d1, [x2, #0x1b]
    // 0x592df0: ldr             x0, [SP, #8]
    // 0x592df4: StoreField: r2->field_23 = r0
    //     0x592df4: stur            w0, [x2, #0x23]
    //     0x592df8: ldurb           w16, [x2, #-1]
    //     0x592dfc: ldurb           w17, [x0, #-1]
    //     0x592e00: and             x16, x17, x16, lsr #2
    //     0x592e04: tst             x16, HEAP, lsr #32
    //     0x592e08: b.eq            #0x592e18
    //     0x592e0c: str             lr, [SP, #-8]!
    //     0x592e10: bl              #0xd6828c
    //     0x592e14: ldr             lr, [SP], #8
    // 0x592e18: ldr             x3, [SP, #0x10]
    // 0x592e1c: LoadField: r4 = r3->field_7
    //     0x592e1c: ldur            x4, [x3, #7]
    // 0x592e20: scvtf           d1, x4
    // 0x592e24: ldr             d2, [SP]
    // 0x592e28: fmul            d3, d1, d2
    // 0x592e2c: fdiv            d1, d3, d0
    // 0x592e30: StoreField: r2->field_b = d1
    //     0x592e30: stur            d1, [x2, #0xb]
    // 0x592e34: StoreField: r2->field_7 = r1
    //     0x592e34: stur            w1, [x2, #7]
    // 0x592e38: r0 = Null
    //     0x592e38: mov             x0, NULL
    // 0x592e3c: ret
    //     0x592e3c: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0xc2d7fc, size: 0x108
    // 0xc2d7fc: EnterFrame
    //     0xc2d7fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc2d800: mov             fp, SP
    // 0xc2d804: AllocStack(0x10)
    //     0xc2d804: sub             SP, SP, #0x10
    // 0xc2d808: d0 = 0.001000
    //     0xc2d808: add             x17, PP, #8, lsl #12  ; [pp+0x8c38] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    //     0xc2d80c: ldr             d0, [x17, #0xc38]
    // 0xc2d810: CheckStackOverflow
    //     0xc2d810: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2d814: cmp             SP, x16
    //     0xc2d818: b.ls            #0xc2d8d4
    // 0xc2d81c: ldr             x0, [fp, #0x10]
    // 0xc2d820: LoadField: d1 = r0->field_7
    //     0xc2d820: ldur            d1, [x0, #7]
    // 0xc2d824: stur            d1, [fp, #-8]
    // 0xc2d828: fadd            d2, d1, d0
    // 0xc2d82c: r0 = inline_Allocate_Double()
    //     0xc2d82c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc2d830: add             x0, x0, #0x10
    //     0xc2d834: cmp             x1, x0
    //     0xc2d838: b.ls            #0xc2d8dc
    //     0xc2d83c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc2d840: sub             x0, x0, #0xf
    //     0xc2d844: mov             x1, #0xd108
    //     0xc2d848: movk            x1, #3, lsl #16
    //     0xc2d84c: stur            x1, [x0, #-1]
    // 0xc2d850: StoreField: r0->field_7 = d2
    //     0xc2d850: stur            d2, [x0, #7]
    // 0xc2d854: ldr             x16, [fp, #0x18]
    // 0xc2d858: stp             x0, x16, [SP, #-0x10]!
    // 0xc2d85c: r0 = x()
    //     0xc2d85c: bl              #0xcb9f5c  ; [package:flutter/src/animation/animation_controller.dart] _InterpolationSimulation::x
    // 0xc2d860: add             SP, SP, #0x10
    // 0xc2d864: mov             v2.16b, v0.16b
    // 0xc2d868: ldur            d1, [fp, #-8]
    // 0xc2d86c: d0 = 0.001000
    //     0xc2d86c: add             x17, PP, #8, lsl #12  ; [pp+0x8c38] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    //     0xc2d870: ldr             d0, [x17, #0xc38]
    // 0xc2d874: stur            d2, [fp, #-0x10]
    // 0xc2d878: fsub            d3, d1, d0
    // 0xc2d87c: r0 = inline_Allocate_Double()
    //     0xc2d87c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc2d880: add             x0, x0, #0x10
    //     0xc2d884: cmp             x1, x0
    //     0xc2d888: b.ls            #0xc2d8f4
    //     0xc2d88c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc2d890: sub             x0, x0, #0xf
    //     0xc2d894: mov             x1, #0xd108
    //     0xc2d898: movk            x1, #3, lsl #16
    //     0xc2d89c: stur            x1, [x0, #-1]
    // 0xc2d8a0: StoreField: r0->field_7 = d3
    //     0xc2d8a0: stur            d3, [x0, #7]
    // 0xc2d8a4: ldr             x16, [fp, #0x18]
    // 0xc2d8a8: stp             x0, x16, [SP, #-0x10]!
    // 0xc2d8ac: r0 = x()
    //     0xc2d8ac: bl              #0xcb9f5c  ; [package:flutter/src/animation/animation_controller.dart] _InterpolationSimulation::x
    // 0xc2d8b0: add             SP, SP, #0x10
    // 0xc2d8b4: ldur            d1, [fp, #-0x10]
    // 0xc2d8b8: fsub            d2, d1, d0
    // 0xc2d8bc: d1 = 0.002000
    //     0xc2d8bc: add             x17, PP, #0x3a, lsl #12  ; [pp+0x3a050] IMM: double(0.002) from 0x3f60624dd2f1a9fc
    //     0xc2d8c0: ldr             d1, [x17, #0x50]
    // 0xc2d8c4: fdiv            d0, d2, d1
    // 0xc2d8c8: LeaveFrame
    //     0xc2d8c8: mov             SP, fp
    //     0xc2d8cc: ldp             fp, lr, [SP], #0x10
    // 0xc2d8d0: ret
    //     0xc2d8d0: ret             
    // 0xc2d8d4: r0 = StackOverflowSharedWithFPURegs()
    //     0xc2d8d4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc2d8d8: b               #0xc2d81c
    // 0xc2d8dc: stp             q1, q2, [SP, #-0x20]!
    // 0xc2d8e0: SaveReg d0
    //     0xc2d8e0: str             q0, [SP, #-0x10]!
    // 0xc2d8e4: r0 = AllocateDouble()
    //     0xc2d8e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc2d8e8: RestoreReg d0
    //     0xc2d8e8: ldr             q0, [SP], #0x10
    // 0xc2d8ec: ldp             q1, q2, [SP], #0x20
    // 0xc2d8f0: b               #0xc2d850
    // 0xc2d8f4: stp             q2, q3, [SP, #-0x20]!
    // 0xc2d8f8: r0 = AllocateDouble()
    //     0xc2d8f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc2d8fc: ldp             q2, q3, [SP], #0x20
    // 0xc2d900: b               #0xc2d8a0
  }
  _ isDone(/* No info */) {
    // ** addr: 0xc3c790, size: 0x28
    // 0xc3c790: ldr             x1, [SP, #8]
    // 0xc3c794: LoadField: d0 = r1->field_b
    //     0xc3c794: ldur            d0, [x1, #0xb]
    // 0xc3c798: ldr             d1, [SP]
    // 0xc3c79c: fcmp            d1, d0
    // 0xc3c7a0: b.vs            #0xc3c7a8
    // 0xc3c7a4: b.gt            #0xc3c7b0
    // 0xc3c7a8: r0 = false
    //     0xc3c7a8: add             x0, NULL, #0x30  ; false
    // 0xc3c7ac: b               #0xc3c7b4
    // 0xc3c7b0: r0 = true
    //     0xc3c7b0: add             x0, NULL, #0x20  ; true
    // 0xc3c7b4: ret
    //     0xc3c7b4: ret             
  }
  _ x(/* No info */) {
    // ** addr: 0xcb9f5c, size: 0x110
    // 0xcb9f5c: EnterFrame
    //     0xcb9f5c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb9f60: mov             fp, SP
    // 0xcb9f64: AllocStack(0x10)
    //     0xcb9f64: sub             SP, SP, #0x10
    // 0xcb9f68: d0 = 0.000000
    //     0xcb9f68: eor             v0.16b, v0.16b, v0.16b
    // 0xcb9f6c: CheckStackOverflow
    //     0xcb9f6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb9f70: cmp             SP, x16
    //     0xcb9f74: b.ls            #0xcba064
    // 0xcb9f78: ldr             x0, [fp, #0x18]
    // 0xcb9f7c: LoadField: d1 = r0->field_b
    //     0xcb9f7c: ldur            d1, [x0, #0xb]
    // 0xcb9f80: ldr             x1, [fp, #0x10]
    // 0xcb9f84: LoadField: d2 = r1->field_7
    //     0xcb9f84: ldur            d2, [x1, #7]
    // 0xcb9f88: fdiv            d3, d2, d1
    // 0xcb9f8c: fcmp            d3, d0
    // 0xcb9f90: b.vs            #0xcb9fa4
    // 0xcb9f94: b.ge            #0xcb9fa4
    // 0xcb9f98: d2 = 0.000000
    //     0xcb9f98: eor             v2.16b, v2.16b, v2.16b
    // 0xcb9f9c: d1 = 1.000000
    //     0xcb9f9c: fmov            d1, #1.00000000
    // 0xcb9fa0: b               #0xcb9fd0
    // 0xcb9fa4: d1 = 1.000000
    //     0xcb9fa4: fmov            d1, #1.00000000
    // 0xcb9fa8: fcmp            d3, d1
    // 0xcb9fac: b.vs            #0xcb9fbc
    // 0xcb9fb0: b.le            #0xcb9fbc
    // 0xcb9fb4: d2 = 1.000000
    //     0xcb9fb4: fmov            d2, #1.00000000
    // 0xcb9fb8: b               #0xcb9fd0
    // 0xcb9fbc: fcmp            d3, d3
    // 0xcb9fc0: b.vc            #0xcb9fcc
    // 0xcb9fc4: d2 = 1.000000
    //     0xcb9fc4: fmov            d2, #1.00000000
    // 0xcb9fc8: b               #0xcb9fd0
    // 0xcb9fcc: mov             v2.16b, v3.16b
    // 0xcb9fd0: fcmp            d2, d0
    // 0xcb9fd4: b.vs            #0xcb9fec
    // 0xcb9fd8: b.ne            #0xcb9fec
    // 0xcb9fdc: LoadField: d0 = r0->field_13
    //     0xcb9fdc: ldur            d0, [x0, #0x13]
    // 0xcb9fe0: LeaveFrame
    //     0xcb9fe0: mov             SP, fp
    //     0xcb9fe4: ldp             fp, lr, [SP], #0x10
    // 0xcb9fe8: ret
    //     0xcb9fe8: ret             
    // 0xcb9fec: fcmp            d2, d1
    // 0xcb9ff0: b.vs            #0xcba008
    // 0xcb9ff4: b.ne            #0xcba008
    // 0xcb9ff8: LoadField: d0 = r0->field_1b
    //     0xcb9ff8: ldur            d0, [x0, #0x1b]
    // 0xcb9ffc: LeaveFrame
    //     0xcb9ffc: mov             SP, fp
    //     0xcba000: ldp             fp, lr, [SP], #0x10
    // 0xcba004: ret
    //     0xcba004: ret             
    // 0xcba008: LoadField: d0 = r0->field_13
    //     0xcba008: ldur            d0, [x0, #0x13]
    // 0xcba00c: stur            d0, [fp, #-0x10]
    // 0xcba010: LoadField: d1 = r0->field_1b
    //     0xcba010: ldur            d1, [x0, #0x1b]
    // 0xcba014: fsub            d3, d1, d0
    // 0xcba018: stur            d3, [fp, #-8]
    // 0xcba01c: LoadField: r1 = r0->field_23
    //     0xcba01c: ldur            w1, [x0, #0x23]
    // 0xcba020: DecompressPointer r1
    //     0xcba020: add             x1, x1, HEAP, lsl #32
    // 0xcba024: r0 = LoadClassIdInstr(r1)
    //     0xcba024: ldur            x0, [x1, #-1]
    //     0xcba028: ubfx            x0, x0, #0xc, #0x14
    // 0xcba02c: SaveReg r1
    //     0xcba02c: str             x1, [SP, #-8]!
    // 0xcba030: SaveReg d2
    //     0xcba030: str             d2, [SP, #-8]!
    // 0xcba034: r0 = GDT[cid_x0 + 0x87f]()
    //     0xcba034: add             lr, x0, #0x87f
    //     0xcba038: ldr             lr, [x21, lr, lsl #3]
    //     0xcba03c: blr             lr
    // 0xcba040: add             SP, SP, #0x10
    // 0xcba044: LoadField: d1 = r0->field_7
    //     0xcba044: ldur            d1, [x0, #7]
    // 0xcba048: ldur            d2, [fp, #-8]
    // 0xcba04c: fmul            d3, d2, d1
    // 0xcba050: ldur            d1, [fp, #-0x10]
    // 0xcba054: fadd            d0, d1, d3
    // 0xcba058: LeaveFrame
    //     0xcba058: mov             SP, fp
    //     0xcba05c: ldp             fp, lr, [SP], #0x10
    // 0xcba060: ret
    //     0xcba060: ret             
    // 0xcba064: r0 = StackOverflowSharedWithFPURegs()
    //     0xcba064: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcba068: b               #0xcb9f78
  }
}

// class id: 4345, size: 0xc, field offset: 0xc
//   const constructor, transformed mixin,
abstract class _AnimationController&Animation&AnimationEagerListenerMixin extends Animation<double>
     with AnimationEagerListenerMixin {
}

// class id: 4346, size: 0x10, field offset: 0xc
//   transformed mixin,
abstract class _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin extends _AnimationController&Animation&AnimationEagerListenerMixin
     with AnimationLocalListenersMixin {

  _ notifyListeners(/* No info */) {
    // ** addr: 0x593248, size: 0x220
    // 0x593248: EnterFrame
    //     0x593248: stp             fp, lr, [SP, #-0x10]!
    //     0x59324c: mov             fp, SP
    // 0x593250: AllocStack(0x88)
    //     0x593250: sub             SP, SP, #0x88
    // 0x593254: CheckStackOverflow
    //     0x593254: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x593258: cmp             SP, x16
    //     0x59325c: b.ls            #0x593454
    // 0x593260: ldr             x0, [fp, #0x10]
    // 0x593264: LoadField: r1 = r0->field_b
    //     0x593264: ldur            w1, [x0, #0xb]
    // 0x593268: DecompressPointer r1
    //     0x593268: add             x1, x1, HEAP, lsl #32
    // 0x59326c: r16 = false
    //     0x59326c: add             x16, NULL, #0x30  ; false
    // 0x593270: stp             x16, x1, [SP, #-0x10]!
    // 0x593274: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0x593274: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0x593278: r0 = toList()
    //     0x593278: bl              #0x6c0b5c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::toList
    // 0x59327c: add             SP, SP, #0x10
    // 0x593280: r1 = LoadClassIdInstr(r0)
    //     0x593280: ldur            x1, [x0, #-1]
    //     0x593284: ubfx            x1, x1, #0xc, #0x14
    // 0x593288: SaveReg r0
    //     0x593288: str             x0, [SP, #-8]!
    // 0x59328c: mov             x0, x1
    // 0x593290: r0 = GDT[cid_x0 + 0xb940]()
    //     0x593290: mov             x17, #0xb940
    //     0x593294: add             lr, x0, x17
    //     0x593298: ldr             lr, [x21, lr, lsl #3]
    //     0x59329c: blr             lr
    // 0x5932a0: add             SP, SP, #8
    // 0x5932a4: ldr             x2, [fp, #0x10]
    // 0x5932a8: mov             x1, x0
    // 0x5932ac: b               #0x5933a0
    // 0x5932b0: sub             SP, fp, #0x88
    // 0x5932b4: mov             x3, x0
    // 0x5932b8: stur            x0, [fp, #-0x70]
    // 0x5932bc: mov             x0, x1
    // 0x5932c0: stur            x1, [fp, #-0x78]
    // 0x5932c4: r1 = Null
    //     0x5932c4: mov             x1, NULL
    // 0x5932c8: r2 = 4
    //     0x5932c8: mov             x2, #4
    // 0x5932cc: r0 = AllocateArray()
    //     0x5932cc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5932d0: stur            x0, [fp, #-0x80]
    // 0x5932d4: r17 = "while notifying listeners for "
    //     0x5932d4: add             x17, PP, #0xd, lsl #12  ; [pp+0xdc10] "while notifying listeners for "
    //     0x5932d8: ldr             x17, [x17, #0xc10]
    // 0x5932dc: StoreField: r0->field_f = r17
    //     0x5932dc: stur            w17, [x0, #0xf]
    // 0x5932e0: ldr             x16, [fp, #0x10]
    // 0x5932e4: SaveReg r16
    //     0x5932e4: str             x16, [SP, #-8]!
    // 0x5932e8: r0 = runtimeType()
    //     0x5932e8: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0x5932ec: add             SP, SP, #8
    // 0x5932f0: ldur            x1, [fp, #-0x80]
    // 0x5932f4: ArrayStore: r1[1] = r0  ; List_4
    //     0x5932f4: add             x25, x1, #0x13
    //     0x5932f8: str             w0, [x25]
    //     0x5932fc: tbz             w0, #0, #0x593318
    //     0x593300: ldurb           w16, [x1, #-1]
    //     0x593304: ldurb           w17, [x0, #-1]
    //     0x593308: and             x16, x17, x16, lsr #2
    //     0x59330c: tst             x16, HEAP, lsr #32
    //     0x593310: b.eq            #0x593318
    //     0x593314: bl              #0xd67e5c
    // 0x593318: ldur            x16, [fp, #-0x80]
    // 0x59331c: SaveReg r16
    //     0x59331c: str             x16, [SP, #-8]!
    // 0x593320: r0 = _interpolate()
    //     0x593320: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x593324: add             SP, SP, #8
    // 0x593328: r1 = <List<Object>>
    //     0x593328: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x59332c: stur            x0, [fp, #-0x80]
    // 0x593330: r0 = ErrorDescription()
    //     0x593330: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x593334: stur            x0, [fp, #-0x88]
    // 0x593338: ldur            x16, [fp, #-0x80]
    // 0x59333c: stp             x16, x0, [SP, #-0x10]!
    // 0x593340: r16 = Instance_DiagnosticLevel
    //     0x593340: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x593344: SaveReg r16
    //     0x593344: str             x16, [SP, #-8]!
    // 0x593348: r0 = _ErrorDiagnostic()
    //     0x593348: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x59334c: add             SP, SP, #0x18
    // 0x593350: r0 = FlutterErrorDetails()
    //     0x593350: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x593354: mov             x1, x0
    // 0x593358: ldur            x0, [fp, #-0x70]
    // 0x59335c: StoreField: r1->field_7 = r0
    //     0x59335c: stur            w0, [x1, #7]
    // 0x593360: ldur            x0, [fp, #-0x78]
    // 0x593364: StoreField: r1->field_b = r0
    //     0x593364: stur            w0, [x1, #0xb]
    // 0x593368: r0 = "animation library"
    //     0x593368: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbf0] "animation library"
    //     0x59336c: ldr             x0, [x0, #0xbf0]
    // 0x593370: StoreField: r1->field_f = r0
    //     0x593370: stur            w0, [x1, #0xf]
    // 0x593374: ldur            x0, [fp, #-0x88]
    // 0x593378: StoreField: r1->field_13 = r0
    //     0x593378: stur            w0, [x1, #0x13]
    // 0x59337c: r0 = false
    //     0x59337c: add             x0, NULL, #0x30  ; false
    // 0x593380: StoreField: r1->field_1f = r0
    //     0x593380: stur            w0, [x1, #0x1f]
    // 0x593384: SaveReg r1
    //     0x593384: str             x1, [SP, #-8]!
    // 0x593388: r0 = reportError()
    //     0x593388: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x59338c: add             SP, SP, #8
    // 0x593390: ldr             x1, [fp, #0x10]
    // 0x593394: ldur            x0, [fp, #-0x38]
    // 0x593398: mov             x2, x1
    // 0x59339c: mov             x1, x0
    // 0x5933a0: stur            x2, [fp, #-0x70]
    // 0x5933a4: stur            x1, [fp, #-0x78]
    // 0x5933a8: CheckStackOverflow
    //     0x5933a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5933ac: cmp             SP, x16
    //     0x5933b0: b.ls            #0x59345c
    // 0x5933b4: r0 = LoadClassIdInstr(r1)
    //     0x5933b4: ldur            x0, [x1, #-1]
    //     0x5933b8: ubfx            x0, x0, #0xc, #0x14
    // 0x5933bc: SaveReg r1
    //     0x5933bc: str             x1, [SP, #-8]!
    // 0x5933c0: r0 = GDT[cid_x0 + 0x541]()
    //     0x5933c0: add             lr, x0, #0x541
    //     0x5933c4: ldr             lr, [x21, lr, lsl #3]
    //     0x5933c8: blr             lr
    // 0x5933cc: add             SP, SP, #8
    // 0x5933d0: tbnz            w0, #4, #0x593444
    // 0x5933d4: ldur            x1, [fp, #-0x78]
    // 0x5933d8: r0 = LoadClassIdInstr(r1)
    //     0x5933d8: ldur            x0, [x1, #-1]
    //     0x5933dc: ubfx            x0, x0, #0xc, #0x14
    // 0x5933e0: SaveReg r1
    //     0x5933e0: str             x1, [SP, #-8]!
    // 0x5933e4: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x5933e4: add             lr, x0, #0x5ca
    //     0x5933e8: ldr             lr, [x21, lr, lsl #3]
    //     0x5933ec: blr             lr
    // 0x5933f0: add             SP, SP, #8
    // 0x5933f4: stur            x0, [fp, #-0x80]
    // 0x5933f8: ldur            x1, [fp, #-0x70]
    // 0x5933fc: LoadField: r2 = r1->field_b
    //     0x5933fc: ldur            w2, [x1, #0xb]
    // 0x593400: DecompressPointer r2
    //     0x593400: add             x2, x2, HEAP, lsl #32
    // 0x593404: stp             x0, x2, [SP, #-0x10]!
    // 0x593408: r0 = contains()
    //     0x593408: bl              #0x6b9fe4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0x59340c: add             SP, SP, #0x10
    // 0x593410: tbnz            w0, #4, #0x593438
    // 0x593414: ldur            x1, [fp, #-0x80]
    // 0x593418: cmp             w1, NULL
    // 0x59341c: b.eq            #0x593464
    // 0x593420: SaveReg r1
    //     0x593420: str             x1, [SP, #-8]!
    // 0x593424: mov             x0, x1
    // 0x593428: ClosureCall
    //     0x593428: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x59342c: ldur            x2, [x0, #0x1f]
    //     0x593430: blr             x2
    // 0x593434: add             SP, SP, #8
    // 0x593438: ldur            x1, [fp, #-0x70]
    // 0x59343c: ldur            x0, [fp, #-0x78]
    // 0x593440: b               #0x593398
    // 0x593444: r0 = Null
    //     0x593444: mov             x0, NULL
    // 0x593448: LeaveFrame
    //     0x593448: mov             SP, fp
    //     0x59344c: ldp             fp, lr, [SP], #0x10
    // 0x593450: ret
    //     0x593450: ret             
    // 0x593454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x593454: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x593458: b               #0x593260
    // 0x59345c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59345c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x593460: b               #0x5933b4
    // 0x593464: r0 = NullErrorSharedWithoutFPURegs()
    //     0x593464: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6f5e30, size: 0x48
    // 0x6f5e30: EnterFrame
    //     0x6f5e30: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5e34: mov             fp, SP
    // 0x6f5e38: CheckStackOverflow
    //     0x6f5e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5e3c: cmp             SP, x16
    //     0x6f5e40: b.ls            #0x6f5e70
    // 0x6f5e44: ldr             x0, [fp, #0x18]
    // 0x6f5e48: LoadField: r1 = r0->field_b
    //     0x6f5e48: ldur            w1, [x0, #0xb]
    // 0x6f5e4c: DecompressPointer r1
    //     0x6f5e4c: add             x1, x1, HEAP, lsl #32
    // 0x6f5e50: ldr             x16, [fp, #0x10]
    // 0x6f5e54: stp             x16, x1, [SP, #-0x10]!
    // 0x6f5e58: r0 = remove()
    //     0x6f5e58: bl              #0x6f5e78  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0x6f5e5c: add             SP, SP, #0x10
    // 0x6f5e60: r0 = Null
    //     0x6f5e60: mov             x0, NULL
    // 0x6f5e64: LeaveFrame
    //     0x6f5e64: mov             SP, fp
    //     0x6f5e68: ldp             fp, lr, [SP], #0x10
    // 0x6f5e6c: ret
    //     0x6f5e6c: ret             
    // 0x6f5e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f5e70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5e74: b               #0x6f5e44
  }
  _ clearListeners(/* No info */) {
    // ** addr: 0x7014ac, size: 0x44
    // 0x7014ac: EnterFrame
    //     0x7014ac: stp             fp, lr, [SP, #-0x10]!
    //     0x7014b0: mov             fp, SP
    // 0x7014b4: CheckStackOverflow
    //     0x7014b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7014b8: cmp             SP, x16
    //     0x7014bc: b.ls            #0x7014e8
    // 0x7014c0: ldr             x0, [fp, #0x10]
    // 0x7014c4: LoadField: r1 = r0->field_b
    //     0x7014c4: ldur            w1, [x0, #0xb]
    // 0x7014c8: DecompressPointer r1
    //     0x7014c8: add             x1, x1, HEAP, lsl #32
    // 0x7014cc: SaveReg r1
    //     0x7014cc: str             x1, [SP, #-8]!
    // 0x7014d0: r0 = clear()
    //     0x7014d0: bl              #0x7014f0  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::clear
    // 0x7014d4: add             SP, SP, #8
    // 0x7014d8: r0 = Null
    //     0x7014d8: mov             x0, NULL
    // 0x7014dc: LeaveFrame
    //     0x7014dc: mov             SP, fp
    //     0x7014e0: ldp             fp, lr, [SP], #0x10
    // 0x7014e4: ret
    //     0x7014e4: ret             
    // 0x7014e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7014e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7014ec: b               #0x7014c0
  }
}

// class id: 4347, size: 0x14, field offset: 0x10
//   transformed mixin,
abstract class _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin extends _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin
     with AnimationLocalStatusListenersMixin {

  _ notifyStatusListeners(/* No info */) {
    // ** addr: 0x59300c, size: 0x23c
    // 0x59300c: EnterFrame
    //     0x59300c: stp             fp, lr, [SP, #-0x10]!
    //     0x593010: mov             fp, SP
    // 0x593014: AllocStack(0x88)
    //     0x593014: sub             SP, SP, #0x88
    // 0x593018: CheckStackOverflow
    //     0x593018: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x59301c: cmp             SP, x16
    //     0x593020: b.ls            #0x593234
    // 0x593024: ldr             x0, [fp, #0x18]
    // 0x593028: LoadField: r1 = r0->field_f
    //     0x593028: ldur            w1, [x0, #0xf]
    // 0x59302c: DecompressPointer r1
    //     0x59302c: add             x1, x1, HEAP, lsl #32
    // 0x593030: r16 = false
    //     0x593030: add             x16, NULL, #0x30  ; false
    // 0x593034: stp             x16, x1, [SP, #-0x10]!
    // 0x593038: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0x593038: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0x59303c: r0 = toList()
    //     0x59303c: bl              #0x6c0b5c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::toList
    // 0x593040: add             SP, SP, #0x10
    // 0x593044: r1 = LoadClassIdInstr(r0)
    //     0x593044: ldur            x1, [x0, #-1]
    //     0x593048: ubfx            x1, x1, #0xc, #0x14
    // 0x59304c: SaveReg r0
    //     0x59304c: str             x0, [SP, #-8]!
    // 0x593050: mov             x0, x1
    // 0x593054: r0 = GDT[cid_x0 + 0xb940]()
    //     0x593054: mov             x17, #0xb940
    //     0x593058: add             lr, x0, x17
    //     0x59305c: ldr             lr, [x21, lr, lsl #3]
    //     0x593060: blr             lr
    // 0x593064: add             SP, SP, #8
    // 0x593068: mov             x1, x0
    // 0x59306c: ldr             x0, [fp, #0x10]
    // 0x593070: ldr             x3, [fp, #0x18]
    // 0x593074: mov             x2, x0
    // 0x593078: b               #0x593174
    // 0x59307c: sub             SP, fp, #0x88
    // 0x593080: mov             x3, x0
    // 0x593084: stur            x0, [fp, #-0x70]
    // 0x593088: mov             x0, x1
    // 0x59308c: stur            x1, [fp, #-0x78]
    // 0x593090: r1 = Null
    //     0x593090: mov             x1, NULL
    // 0x593094: r2 = 4
    //     0x593094: mov             x2, #4
    // 0x593098: r0 = AllocateArray()
    //     0x593098: bl              #0xd6987c  ; AllocateArrayStub
    // 0x59309c: stur            x0, [fp, #-0x80]
    // 0x5930a0: r17 = "while notifying status listeners for "
    //     0x5930a0: add             x17, PP, #0xd, lsl #12  ; [pp+0xdbe8] "while notifying status listeners for "
    //     0x5930a4: ldr             x17, [x17, #0xbe8]
    // 0x5930a8: StoreField: r0->field_f = r17
    //     0x5930a8: stur            w17, [x0, #0xf]
    // 0x5930ac: ldr             x16, [fp, #0x18]
    // 0x5930b0: SaveReg r16
    //     0x5930b0: str             x16, [SP, #-8]!
    // 0x5930b4: r0 = runtimeType()
    //     0x5930b4: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0x5930b8: add             SP, SP, #8
    // 0x5930bc: ldur            x1, [fp, #-0x80]
    // 0x5930c0: ArrayStore: r1[1] = r0  ; List_4
    //     0x5930c0: add             x25, x1, #0x13
    //     0x5930c4: str             w0, [x25]
    //     0x5930c8: tbz             w0, #0, #0x5930e4
    //     0x5930cc: ldurb           w16, [x1, #-1]
    //     0x5930d0: ldurb           w17, [x0, #-1]
    //     0x5930d4: and             x16, x17, x16, lsr #2
    //     0x5930d8: tst             x16, HEAP, lsr #32
    //     0x5930dc: b.eq            #0x5930e4
    //     0x5930e0: bl              #0xd67e5c
    // 0x5930e4: ldur            x16, [fp, #-0x80]
    // 0x5930e8: SaveReg r16
    //     0x5930e8: str             x16, [SP, #-8]!
    // 0x5930ec: r0 = _interpolate()
    //     0x5930ec: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x5930f0: add             SP, SP, #8
    // 0x5930f4: r1 = <List<Object>>
    //     0x5930f4: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x5930f8: stur            x0, [fp, #-0x80]
    // 0x5930fc: r0 = ErrorDescription()
    //     0x5930fc: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x593100: stur            x0, [fp, #-0x88]
    // 0x593104: ldur            x16, [fp, #-0x80]
    // 0x593108: stp             x16, x0, [SP, #-0x10]!
    // 0x59310c: r16 = Instance_DiagnosticLevel
    //     0x59310c: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x593110: SaveReg r16
    //     0x593110: str             x16, [SP, #-8]!
    // 0x593114: r0 = _ErrorDiagnostic()
    //     0x593114: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x593118: add             SP, SP, #0x18
    // 0x59311c: r0 = FlutterErrorDetails()
    //     0x59311c: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x593120: mov             x1, x0
    // 0x593124: ldur            x0, [fp, #-0x70]
    // 0x593128: StoreField: r1->field_7 = r0
    //     0x593128: stur            w0, [x1, #7]
    // 0x59312c: ldur            x0, [fp, #-0x78]
    // 0x593130: StoreField: r1->field_b = r0
    //     0x593130: stur            w0, [x1, #0xb]
    // 0x593134: r0 = "animation library"
    //     0x593134: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbf0] "animation library"
    //     0x593138: ldr             x0, [x0, #0xbf0]
    // 0x59313c: StoreField: r1->field_f = r0
    //     0x59313c: stur            w0, [x1, #0xf]
    // 0x593140: ldur            x0, [fp, #-0x88]
    // 0x593144: StoreField: r1->field_13 = r0
    //     0x593144: stur            w0, [x1, #0x13]
    // 0x593148: r0 = false
    //     0x593148: add             x0, NULL, #0x30  ; false
    // 0x59314c: StoreField: r1->field_1f = r0
    //     0x59314c: stur            w0, [x1, #0x1f]
    // 0x593150: SaveReg r1
    //     0x593150: str             x1, [SP, #-8]!
    // 0x593154: r0 = reportError()
    //     0x593154: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x593158: add             SP, SP, #8
    // 0x59315c: ldr             x2, [fp, #0x18]
    // 0x593160: ldr             x1, [fp, #0x10]
    // 0x593164: ldur            x0, [fp, #-0x38]
    // 0x593168: mov             x3, x2
    // 0x59316c: mov             x2, x1
    // 0x593170: mov             x1, x0
    // 0x593174: stur            x3, [fp, #-0x70]
    // 0x593178: stur            x2, [fp, #-0x78]
    // 0x59317c: stur            x1, [fp, #-0x80]
    // 0x593180: CheckStackOverflow
    //     0x593180: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x593184: cmp             SP, x16
    //     0x593188: b.ls            #0x59323c
    // 0x59318c: r0 = LoadClassIdInstr(r1)
    //     0x59318c: ldur            x0, [x1, #-1]
    //     0x593190: ubfx            x0, x0, #0xc, #0x14
    // 0x593194: SaveReg r1
    //     0x593194: str             x1, [SP, #-8]!
    // 0x593198: r0 = GDT[cid_x0 + 0x541]()
    //     0x593198: add             lr, x0, #0x541
    //     0x59319c: ldr             lr, [x21, lr, lsl #3]
    //     0x5931a0: blr             lr
    // 0x5931a4: add             SP, SP, #8
    // 0x5931a8: tbnz            w0, #4, #0x593224
    // 0x5931ac: ldur            x1, [fp, #-0x80]
    // 0x5931b0: r0 = LoadClassIdInstr(r1)
    //     0x5931b0: ldur            x0, [x1, #-1]
    //     0x5931b4: ubfx            x0, x0, #0xc, #0x14
    // 0x5931b8: SaveReg r1
    //     0x5931b8: str             x1, [SP, #-8]!
    // 0x5931bc: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x5931bc: add             lr, x0, #0x5ca
    //     0x5931c0: ldr             lr, [x21, lr, lsl #3]
    //     0x5931c4: blr             lr
    // 0x5931c8: add             SP, SP, #8
    // 0x5931cc: stur            x0, [fp, #-0x88]
    // 0x5931d0: ldur            x2, [fp, #-0x70]
    // 0x5931d4: LoadField: r1 = r2->field_f
    //     0x5931d4: ldur            w1, [x2, #0xf]
    // 0x5931d8: DecompressPointer r1
    //     0x5931d8: add             x1, x1, HEAP, lsl #32
    // 0x5931dc: stp             x0, x1, [SP, #-0x10]!
    // 0x5931e0: r0 = contains()
    //     0x5931e0: bl              #0x6b9fe4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0x5931e4: add             SP, SP, #0x10
    // 0x5931e8: tbnz            w0, #4, #0x593214
    // 0x5931ec: ldur            x1, [fp, #-0x88]
    // 0x5931f0: cmp             w1, NULL
    // 0x5931f4: b.eq            #0x593244
    // 0x5931f8: ldur            x16, [fp, #-0x78]
    // 0x5931fc: stp             x16, x1, [SP, #-0x10]!
    // 0x593200: mov             x0, x1
    // 0x593204: ClosureCall
    //     0x593204: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x593208: ldur            x2, [x0, #0x1f]
    //     0x59320c: blr             x2
    // 0x593210: add             SP, SP, #0x10
    // 0x593214: ldur            x2, [fp, #-0x70]
    // 0x593218: ldur            x1, [fp, #-0x78]
    // 0x59321c: ldur            x0, [fp, #-0x80]
    // 0x593220: b               #0x593168
    // 0x593224: r0 = Null
    //     0x593224: mov             x0, NULL
    // 0x593228: LeaveFrame
    //     0x593228: mov             SP, fp
    //     0x59322c: ldp             fp, lr, [SP], #0x10
    // 0x593230: ret
    //     0x593230: ret             
    // 0x593234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x593234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x593238: b               #0x593024
    // 0x59323c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x59323c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x593240: b               #0x59318c
    // 0x593244: r0 = NullErrorSharedWithoutFPURegs()
    //     0x593244: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin(/* No info */) {
    // ** addr: 0x6ea9d8, size: 0x120
    // 0x6ea9d8: EnterFrame
    //     0x6ea9d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea9dc: mov             fp, SP
    // 0x6ea9e0: AllocStack(0x8)
    //     0x6ea9e0: sub             SP, SP, #8
    // 0x6ea9e4: CheckStackOverflow
    //     0x6ea9e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea9e8: cmp             SP, x16
    //     0x6ea9ec: b.ls            #0x6eaaf0
    // 0x6ea9f0: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x6ea9f0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x6ea9f4: ldr             x1, [x1, #0x3d8]
    // 0x6ea9f8: r0 = ObserverList()
    //     0x6ea9f8: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x6ea9fc: mov             x1, x0
    // 0x6eaa00: r0 = false
    //     0x6eaa00: add             x0, NULL, #0x30  ; false
    // 0x6eaa04: stur            x1, [fp, #-8]
    // 0x6eaa08: StoreField: r1->field_f = r0
    //     0x6eaa08: stur            w0, [x1, #0xf]
    // 0x6eaa0c: r2 = Sentinel
    //     0x6eaa0c: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6eaa10: StoreField: r1->field_13 = r2
    //     0x6eaa10: stur            w2, [x1, #0x13]
    // 0x6eaa14: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x6eaa14: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x6eaa18: ldr             x16, [x16, #0x3d8]
    // 0x6eaa1c: stp             xzr, x16, [SP, #-0x10]!
    // 0x6eaa20: r0 = _GrowableList()
    //     0x6eaa20: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6eaa24: add             SP, SP, #0x10
    // 0x6eaa28: ldur            x1, [fp, #-8]
    // 0x6eaa2c: StoreField: r1->field_b = r0
    //     0x6eaa2c: stur            w0, [x1, #0xb]
    //     0x6eaa30: ldurb           w16, [x1, #-1]
    //     0x6eaa34: ldurb           w17, [x0, #-1]
    //     0x6eaa38: and             x16, x17, x16, lsr #2
    //     0x6eaa3c: tst             x16, HEAP, lsr #32
    //     0x6eaa40: b.eq            #0x6eaa48
    //     0x6eaa44: bl              #0xd6826c
    // 0x6eaa48: mov             x0, x1
    // 0x6eaa4c: ldr             x2, [fp, #0x10]
    // 0x6eaa50: StoreField: r2->field_f = r0
    //     0x6eaa50: stur            w0, [x2, #0xf]
    //     0x6eaa54: ldurb           w16, [x2, #-1]
    //     0x6eaa58: ldurb           w17, [x0, #-1]
    //     0x6eaa5c: and             x16, x17, x16, lsr #2
    //     0x6eaa60: tst             x16, HEAP, lsr #32
    //     0x6eaa64: b.eq            #0x6eaa6c
    //     0x6eaa68: bl              #0xd6828c
    // 0x6eaa6c: r1 = <(dynamic this) => void?>
    //     0x6eaa6c: ldr             x1, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0x6eaa70: r0 = ObserverList()
    //     0x6eaa70: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x6eaa74: mov             x1, x0
    // 0x6eaa78: r0 = false
    //     0x6eaa78: add             x0, NULL, #0x30  ; false
    // 0x6eaa7c: stur            x1, [fp, #-8]
    // 0x6eaa80: StoreField: r1->field_f = r0
    //     0x6eaa80: stur            w0, [x1, #0xf]
    // 0x6eaa84: r0 = Sentinel
    //     0x6eaa84: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6eaa88: StoreField: r1->field_13 = r0
    //     0x6eaa88: stur            w0, [x1, #0x13]
    // 0x6eaa8c: r16 = <(dynamic this) => void?>
    //     0x6eaa8c: ldr             x16, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0x6eaa90: stp             xzr, x16, [SP, #-0x10]!
    // 0x6eaa94: r0 = _GrowableList()
    //     0x6eaa94: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6eaa98: add             SP, SP, #0x10
    // 0x6eaa9c: ldur            x1, [fp, #-8]
    // 0x6eaaa0: StoreField: r1->field_b = r0
    //     0x6eaaa0: stur            w0, [x1, #0xb]
    //     0x6eaaa4: ldurb           w16, [x1, #-1]
    //     0x6eaaa8: ldurb           w17, [x0, #-1]
    //     0x6eaaac: and             x16, x17, x16, lsr #2
    //     0x6eaab0: tst             x16, HEAP, lsr #32
    //     0x6eaab4: b.eq            #0x6eaabc
    //     0x6eaab8: bl              #0xd6826c
    // 0x6eaabc: mov             x0, x1
    // 0x6eaac0: ldr             x1, [fp, #0x10]
    // 0x6eaac4: StoreField: r1->field_b = r0
    //     0x6eaac4: stur            w0, [x1, #0xb]
    //     0x6eaac8: ldurb           w16, [x1, #-1]
    //     0x6eaacc: ldurb           w17, [x0, #-1]
    //     0x6eaad0: and             x16, x17, x16, lsr #2
    //     0x6eaad4: tst             x16, HEAP, lsr #32
    //     0x6eaad8: b.eq            #0x6eaae0
    //     0x6eaadc: bl              #0xd6826c
    // 0x6eaae0: r0 = Null
    //     0x6eaae0: mov             x0, NULL
    // 0x6eaae4: LeaveFrame
    //     0x6eaae4: mov             SP, fp
    //     0x6eaae8: ldp             fp, lr, [SP], #0x10
    // 0x6eaaec: ret
    //     0x6eaaec: ret             
    // 0x6eaaf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eaaf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eaaf4: b               #0x6ea9f0
  }
  _ clearStatusListeners(/* No info */) {
    // ** addr: 0x70156c, size: 0x44
    // 0x70156c: EnterFrame
    //     0x70156c: stp             fp, lr, [SP, #-0x10]!
    //     0x701570: mov             fp, SP
    // 0x701574: CheckStackOverflow
    //     0x701574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x701578: cmp             SP, x16
    //     0x70157c: b.ls            #0x7015a8
    // 0x701580: ldr             x0, [fp, #0x10]
    // 0x701584: LoadField: r1 = r0->field_f
    //     0x701584: ldur            w1, [x0, #0xf]
    // 0x701588: DecompressPointer r1
    //     0x701588: add             x1, x1, HEAP, lsl #32
    // 0x70158c: SaveReg r1
    //     0x70158c: str             x1, [SP, #-8]!
    // 0x701590: r0 = clear()
    //     0x701590: bl              #0x7014f0  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::clear
    // 0x701594: add             SP, SP, #8
    // 0x701598: r0 = Null
    //     0x701598: mov             x0, NULL
    // 0x70159c: LeaveFrame
    //     0x70159c: mov             SP, fp
    //     0x7015a0: ldp             fp, lr, [SP], #0x10
    // 0x7015a4: ret
    //     0x7015a4: ret             
    // 0x7015a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7015a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7015ac: b               #0x701580
  }
  _ addStatusListener(/* No info */) {
    // ** addr: 0xc52a20, size: 0x48
    // 0xc52a20: EnterFrame
    //     0xc52a20: stp             fp, lr, [SP, #-0x10]!
    //     0xc52a24: mov             fp, SP
    // 0xc52a28: CheckStackOverflow
    //     0xc52a28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc52a2c: cmp             SP, x16
    //     0xc52a30: b.ls            #0xc52a60
    // 0xc52a34: ldr             x0, [fp, #0x18]
    // 0xc52a38: LoadField: r1 = r0->field_f
    //     0xc52a38: ldur            w1, [x0, #0xf]
    // 0xc52a3c: DecompressPointer r1
    //     0xc52a3c: add             x1, x1, HEAP, lsl #32
    // 0xc52a40: ldr             x16, [fp, #0x10]
    // 0xc52a44: stp             x16, x1, [SP, #-0x10]!
    // 0xc52a48: r0 = add()
    //     0xc52a48: bl              #0x6e93b4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::add
    // 0xc52a4c: add             SP, SP, #0x10
    // 0xc52a50: r0 = Null
    //     0xc52a50: mov             x0, NULL
    // 0xc52a54: LeaveFrame
    //     0xc52a54: mov             SP, fp
    //     0xc52a58: ldp             fp, lr, [SP], #0x10
    // 0xc52a5c: ret
    //     0xc52a5c: ret             
    // 0xc52a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc52a60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc52a64: b               #0xc52a34
  }
  _ removeStatusListener(/* No info */) {
    // ** addr: 0xc5df14, size: 0x48
    // 0xc5df14: EnterFrame
    //     0xc5df14: stp             fp, lr, [SP, #-0x10]!
    //     0xc5df18: mov             fp, SP
    // 0xc5df1c: CheckStackOverflow
    //     0xc5df1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5df20: cmp             SP, x16
    //     0xc5df24: b.ls            #0xc5df54
    // 0xc5df28: ldr             x0, [fp, #0x18]
    // 0xc5df2c: LoadField: r1 = r0->field_f
    //     0xc5df2c: ldur            w1, [x0, #0xf]
    // 0xc5df30: DecompressPointer r1
    //     0xc5df30: add             x1, x1, HEAP, lsl #32
    // 0xc5df34: ldr             x16, [fp, #0x10]
    // 0xc5df38: stp             x16, x1, [SP, #-0x10]!
    // 0xc5df3c: r0 = remove()
    //     0xc5df3c: bl              #0x6f5e78  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0xc5df40: add             SP, SP, #0x10
    // 0xc5df44: r0 = Null
    //     0xc5df44: mov             x0, NULL
    // 0xc5df48: LeaveFrame
    //     0xc5df48: mov             SP, fp
    //     0xc5df4c: ldp             fp, lr, [SP], #0x10
    // 0xc5df50: ret
    //     0xc5df50: ret             
    // 0xc5df54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5df54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5df58: b               #0xc5df28
  }
}

// class id: 4349, size: 0x4c, field offset: 0x14
class AnimationController extends _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin {

  late double _value; // offset: 0x38
  late AnimationStatus _status; // offset: 0x44

  _ reverse(/* No info */) {
    // ** addr: 0x591170, size: 0xc0
    // 0x591170: EnterFrame
    //     0x591170: stp             fp, lr, [SP, #-0x10]!
    //     0x591174: mov             fp, SP
    // 0x591178: AllocStack(0x8)
    //     0x591178: sub             SP, SP, #8
    // 0x59117c: SetupParameters(AnimationController<double> this /* r3, fp-0x8 */, {dynamic from = Null /* r1 */})
    //     0x59117c: mov             x0, x4
    //     0x591180: ldur            w1, [x0, #0x13]
    //     0x591184: add             x1, x1, HEAP, lsl #32
    //     0x591188: sub             x2, x1, #2
    //     0x59118c: add             x3, fp, w2, sxtw #2
    //     0x591190: ldr             x3, [x3, #0x10]
    //     0x591194: stur            x3, [fp, #-8]
    //     0x591198: ldur            w2, [x0, #0x1f]
    //     0x59119c: add             x2, x2, HEAP, lsl #32
    //     0x5911a0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb88] "from"
    //     0x5911a4: ldr             x16, [x16, #0xb88]
    //     0x5911a8: cmp             w2, w16
    //     0x5911ac: b.ne            #0x5911c8
    //     0x5911b0: ldur            w2, [x0, #0x23]
    //     0x5911b4: add             x2, x2, HEAP, lsl #32
    //     0x5911b8: sub             w0, w1, w2
    //     0x5911bc: add             x1, fp, w0, sxtw #2
    //     0x5911c0: ldr             x1, [x1, #8]
    //     0x5911c4: b               #0x5911cc
    //     0x5911c8: mov             x1, NULL
    //     0x5911cc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb90] Obj!_AnimationDirection@b65ef1
    //     0x5911d0: ldr             x0, [x0, #0xb90]
    // 0x5911cc: r0 = Instance__AnimationDirection
    // 0x5911d4: CheckStackOverflow
    //     0x5911d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5911d8: cmp             SP, x16
    //     0x5911dc: b.ls            #0x591228
    // 0x5911e0: StoreField: r3->field_3f = r0
    //     0x5911e0: stur            w0, [x3, #0x3f]
    // 0x5911e4: cmp             w1, NULL
    // 0x5911e8: b.eq            #0x591200
    // 0x5911ec: LoadField: d0 = r1->field_7
    //     0x5911ec: ldur            d0, [x1, #7]
    // 0x5911f0: SaveReg r3
    //     0x5911f0: str             x3, [SP, #-8]!
    // 0x5911f4: SaveReg d0
    //     0x5911f4: str             d0, [SP, #-8]!
    // 0x5911f8: r0 = value=()
    //     0x5911f8: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x5911fc: add             SP, SP, #0x10
    // 0x591200: ldur            x0, [fp, #-8]
    // 0x591204: LoadField: d0 = r0->field_13
    //     0x591204: ldur            d0, [x0, #0x13]
    // 0x591208: SaveReg r0
    //     0x591208: str             x0, [SP, #-8]!
    // 0x59120c: SaveReg d0
    //     0x59120c: str             d0, [SP, #-8]!
    // 0x591210: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x591210: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x591214: r0 = _animateToInternal()
    //     0x591214: bl              #0x591390  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_animateToInternal
    // 0x591218: add             SP, SP, #0x10
    // 0x59121c: LeaveFrame
    //     0x59121c: mov             SP, fp
    //     0x591220: ldp             fp, lr, [SP], #0x10
    // 0x591224: ret
    //     0x591224: ret             
    // 0x591228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x591228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59122c: b               #0x5911e0
  }
  [closure] TickerFuture reverse(dynamic, {double? from}) {
    // ** addr: 0x591230, size: 0x9c
    // 0x591230: EnterFrame
    //     0x591230: stp             fp, lr, [SP, #-0x10]!
    //     0x591234: mov             fp, SP
    // 0x591238: mov             x0, x4
    // 0x59123c: LoadField: r1 = r0->field_13
    //     0x59123c: ldur            w1, [x0, #0x13]
    // 0x591240: DecompressPointer r1
    //     0x591240: add             x1, x1, HEAP, lsl #32
    // 0x591244: sub             x2, x1, #2
    // 0x591248: add             x3, fp, w2, sxtw #2
    // 0x59124c: ldr             x3, [x3, #0x10]
    // 0x591250: LoadField: r2 = r0->field_1f
    //     0x591250: ldur            w2, [x0, #0x1f]
    // 0x591254: DecompressPointer r2
    //     0x591254: add             x2, x2, HEAP, lsl #32
    // 0x591258: r16 = "from"
    //     0x591258: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb88] "from"
    //     0x59125c: ldr             x16, [x16, #0xb88]
    // 0x591260: cmp             w2, w16
    // 0x591264: b.ne            #0x591284
    // 0x591268: LoadField: r2 = r0->field_23
    //     0x591268: ldur            w2, [x0, #0x23]
    // 0x59126c: DecompressPointer r2
    //     0x59126c: add             x2, x2, HEAP, lsl #32
    // 0x591270: sub             w0, w1, w2
    // 0x591274: add             x1, fp, w0, sxtw #2
    // 0x591278: ldr             x1, [x1, #8]
    // 0x59127c: mov             x0, x1
    // 0x591280: b               #0x591288
    // 0x591284: r0 = Null
    //     0x591284: mov             x0, NULL
    // 0x591288: LoadField: r1 = r3->field_17
    //     0x591288: ldur            w1, [x3, #0x17]
    // 0x59128c: DecompressPointer r1
    //     0x59128c: add             x1, x1, HEAP, lsl #32
    // 0x591290: CheckStackOverflow
    //     0x591290: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x591294: cmp             SP, x16
    //     0x591298: b.ls            #0x5912c4
    // 0x59129c: LoadField: r2 = r1->field_f
    //     0x59129c: ldur            w2, [x1, #0xf]
    // 0x5912a0: DecompressPointer r2
    //     0x5912a0: add             x2, x2, HEAP, lsl #32
    // 0x5912a4: stp             x0, x2, [SP, #-0x10]!
    // 0x5912a8: r4 = const [0, 0x2, 0x2, 0x1, from, 0x1, null]
    //     0x5912a8: add             x4, PP, #0x50, lsl #12  ; [pp+0x50438] List(7) [0, 0x2, 0x2, 0x1, "from", 0x1, Null]
    //     0x5912ac: ldr             x4, [x4, #0x438]
    // 0x5912b0: r0 = reverse()
    //     0x5912b0: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x5912b4: add             SP, SP, #0x10
    // 0x5912b8: LeaveFrame
    //     0x5912b8: mov             SP, fp
    //     0x5912bc: ldp             fp, lr, [SP], #0x10
    // 0x5912c0: ret
    //     0x5912c0: ret             
    // 0x5912c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5912c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5912c8: b               #0x59129c
  }
  _ _animateToInternal(/* No info */) {
    // ** addr: 0x591390, size: 0x514
    // 0x591390: EnterFrame
    //     0x591390: stp             fp, lr, [SP, #-0x10]!
    //     0x591394: mov             fp, SP
    // 0x591398: AllocStack(0x40)
    //     0x591398: sub             SP, SP, #0x40
    // 0x59139c: SetupParameters(AnimationController<double> this /* r3, fp-0x18 */, dynamic _ /* d0, fp-0x38 */, {dynamic curve = Instance__Linear /* r4, fp-0x10 */, dynamic duration = Null /* r0, fp-0x8 */})
    //     0x59139c: mov             x0, x4
    //     0x5913a0: ldur            w1, [x0, #0x13]
    //     0x5913a4: add             x1, x1, HEAP, lsl #32
    //     0x5913a8: sub             x2, x1, #4
    //     0x5913ac: add             x3, fp, w2, sxtw #2
    //     0x5913b0: ldr             x3, [x3, #0x18]
    //     0x5913b4: stur            x3, [fp, #-0x18]
    //     0x5913b8: add             x4, fp, w2, sxtw #2
    //     0x5913bc: ldr             d0, [x4, #0x10]
    //     0x5913c0: stur            d0, [fp, #-0x38]
    //     0x5913c4: ldur            w2, [x0, #0x1f]
    //     0x5913c8: add             x2, x2, HEAP, lsl #32
    //     0x5913cc: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc0] "curve"
    //     0x5913d0: ldr             x16, [x16, #0xfc0]
    //     0x5913d4: cmp             w2, w16
    //     0x5913d8: b.ne            #0x5913fc
    //     0x5913dc: ldur            w2, [x0, #0x23]
    //     0x5913e0: add             x2, x2, HEAP, lsl #32
    //     0x5913e4: sub             w4, w1, w2
    //     0x5913e8: add             x2, fp, w4, sxtw #2
    //     0x5913ec: ldr             x2, [x2, #8]
    //     0x5913f0: mov             x4, x2
    //     0x5913f4: mov             x2, #1
    //     0x5913f8: b               #0x591408
    //     0x5913fc: add             x4, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x591400: ldr             x4, [x4, #0x300]
    //     0x591404: mov             x2, #0
    //     0x591408: stur            x4, [fp, #-0x10]
    //     0x59140c: lsl             x5, x2, #1
    //     0x591410: lsl             w2, w5, #1
    //     0x591414: add             w5, w2, #8
    //     0x591418: add             x16, x0, w5, sxtw #1
    //     0x59141c: ldur            w6, [x16, #0xf]
    //     0x591420: add             x6, x6, HEAP, lsl #32
    //     0x591424: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x591428: ldr             x16, [x16, #0xfd8]
    //     0x59142c: cmp             w6, w16
    //     0x591430: b.ne            #0x591458
    //     0x591434: add             w5, w2, #0xa
    //     0x591438: add             x16, x0, w5, sxtw #1
    //     0x59143c: ldur            w2, [x16, #0xf]
    //     0x591440: add             x2, x2, HEAP, lsl #32
    //     0x591444: sub             w0, w1, w2
    //     0x591448: add             x1, fp, w0, sxtw #2
    //     0x59144c: ldr             x1, [x1, #8]
    //     0x591450: mov             x0, x1
    //     0x591454: b               #0x59145c
    //     0x591458: mov             x0, NULL
    //     0x59145c: stur            x0, [fp, #-8]
    // 0x591460: CheckStackOverflow
    //     0x591460: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x591464: cmp             SP, x16
    //     0x591468: b.ls            #0x59180c
    // 0x59146c: r1 = LoadStaticField(0xf1c)
    //     0x59146c: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x591470: ldr             x1, [x1, #0x1e38]
    // 0x591474: cmp             w1, NULL
    // 0x591478: b.eq            #0x591814
    // 0x59147c: SaveReg r1
    //     0x59147c: str             x1, [SP, #-8]!
    // 0x591480: r0 = disableAnimations()
    //     0x591480: bl              #0x59377c  ; [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding::disableAnimations
    // 0x591484: add             SP, SP, #8
    // 0x591488: tbnz            w0, #4, #0x5914b8
    // 0x59148c: ldur            x0, [fp, #-0x18]
    // 0x591490: LoadField: r1 = r0->field_23
    //     0x591490: ldur            w1, [x0, #0x23]
    // 0x591494: DecompressPointer r1
    //     0x591494: add             x1, x1, HEAP, lsl #32
    // 0x591498: LoadField: r2 = r1->field_7
    //     0x591498: ldur            x2, [x1, #7]
    // 0x59149c: cmp             x2, #0
    // 0x5914a0: b.gt            #0x5914b0
    // 0x5914a4: d0 = 0.050000
    //     0x5914a4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd208] IMM: double(0.05) from 0x3fa999999999999a
    //     0x5914a8: ldr             d0, [x17, #0x208]
    // 0x5914ac: b               #0x5914c0
    // 0x5914b0: d0 = 1.000000
    //     0x5914b0: fmov            d0, #1.00000000
    // 0x5914b4: b               #0x5914c0
    // 0x5914b8: ldur            x0, [fp, #-0x18]
    // 0x5914bc: d0 = 1.000000
    //     0x5914bc: fmov            d0, #1.00000000
    // 0x5914c0: ldur            x1, [fp, #-8]
    // 0x5914c4: stur            d0, [fp, #-0x40]
    // 0x5914c8: cmp             w1, NULL
    // 0x5914cc: b.ne            #0x5915e0
    // 0x5914d0: LoadField: d1 = r0->field_1b
    //     0x5914d0: ldur            d1, [x0, #0x1b]
    // 0x5914d4: LoadField: d2 = r0->field_13
    //     0x5914d4: ldur            d2, [x0, #0x13]
    // 0x5914d8: fsub            d3, d1, d2
    // 0x5914dc: mov             x1, v3.d[0]
    // 0x5914e0: and             x1, x1, #0x7fffffffffffffff
    // 0x5914e4: r17 = 9218868437227405312
    //     0x5914e4: mov             x17, #0x7ff0000000000000
    // 0x5914e8: cmp             x1, x17
    // 0x5914ec: b.eq            #0x59155c
    // 0x5914f0: fcmp            d3, d3
    // 0x5914f4: b.vs            #0x591554
    // 0x5914f8: ldur            d1, [fp, #-0x38]
    // 0x5914fc: d2 = 0.000000
    //     0x5914fc: eor             v2.16b, v2.16b, v2.16b
    // 0x591500: LoadField: r1 = r0->field_37
    //     0x591500: ldur            w1, [x0, #0x37]
    // 0x591504: DecompressPointer r1
    //     0x591504: add             x1, x1, HEAP, lsl #32
    // 0x591508: r16 = Sentinel
    //     0x591508: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x59150c: cmp             w1, w16
    // 0x591510: b.eq            #0x591818
    // 0x591514: LoadField: d4 = r1->field_7
    //     0x591514: ldur            d4, [x1, #7]
    // 0x591518: fsub            d5, d1, d4
    // 0x59151c: fcmp            d5, d2
    // 0x591520: b.vs            #0x591530
    // 0x591524: b.ne            #0x591530
    // 0x591528: d2 = 0.000000
    //     0x591528: eor             v2.16b, v2.16b, v2.16b
    // 0x59152c: b               #0x591548
    // 0x591530: fcmp            d5, d2
    // 0x591534: b.vs            #0x591544
    // 0x591538: b.ge            #0x591544
    // 0x59153c: fneg            d2, d5
    // 0x591540: b               #0x591548
    // 0x591544: mov             v2.16b, v5.16b
    // 0x591548: fdiv            d4, d2, d3
    // 0x59154c: mov             v2.16b, v4.16b
    // 0x591550: b               #0x591564
    // 0x591554: ldur            d1, [fp, #-0x38]
    // 0x591558: b               #0x591560
    // 0x59155c: ldur            d1, [fp, #-0x38]
    // 0x591560: d2 = 1.000000
    //     0x591560: fmov            d2, #1.00000000
    // 0x591564: LoadField: r1 = r0->field_3f
    //     0x591564: ldur            w1, [x0, #0x3f]
    // 0x591568: DecompressPointer r1
    //     0x591568: add             x1, x1, HEAP, lsl #32
    // 0x59156c: r16 = Instance__AnimationDirection
    //     0x59156c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb90] Obj!_AnimationDirection@b65ef1
    //     0x591570: ldr             x16, [x16, #0xb90]
    // 0x591574: cmp             w1, w16
    // 0x591578: b.ne            #0x59158c
    // 0x59157c: LoadField: r1 = r0->field_2b
    //     0x59157c: ldur            w1, [x0, #0x2b]
    // 0x591580: DecompressPointer r1
    //     0x591580: add             x1, x1, HEAP, lsl #32
    // 0x591584: cmp             w1, NULL
    // 0x591588: b.ne            #0x59159c
    // 0x59158c: LoadField: r1 = r0->field_27
    //     0x59158c: ldur            w1, [x0, #0x27]
    // 0x591590: DecompressPointer r1
    //     0x591590: add             x1, x1, HEAP, lsl #32
    // 0x591594: cmp             w1, NULL
    // 0x591598: b.eq            #0x591824
    // 0x59159c: r2 = inline_Allocate_Double()
    //     0x59159c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x5915a0: add             x2, x2, #0x10
    //     0x5915a4: cmp             x3, x2
    //     0x5915a8: b.ls            #0x591828
    //     0x5915ac: str             x2, [THR, #0x60]  ; THR::top
    //     0x5915b0: sub             x2, x2, #0xf
    //     0x5915b4: mov             x3, #0xd108
    //     0x5915b8: movk            x3, #3, lsl #16
    //     0x5915bc: stur            x3, [x2, #-1]
    // 0x5915c0: StoreField: r2->field_7 = d2
    //     0x5915c0: stur            d2, [x2, #7]
    // 0x5915c4: stp             x2, x1, [SP, #-0x10]!
    // 0x5915c8: r0 = *()
    //     0x5915c8: bl              #0x4b52d4  ; [dart:core] Duration::*
    // 0x5915cc: add             SP, SP, #0x10
    // 0x5915d0: mov             x1, x0
    // 0x5915d4: ldur            x0, [fp, #-0x18]
    // 0x5915d8: ldur            d0, [fp, #-0x38]
    // 0x5915dc: b               #0x59160c
    // 0x5915e0: ldur            d0, [fp, #-0x38]
    // 0x5915e4: LoadField: r2 = r0->field_37
    //     0x5915e4: ldur            w2, [x0, #0x37]
    // 0x5915e8: DecompressPointer r2
    //     0x5915e8: add             x2, x2, HEAP, lsl #32
    // 0x5915ec: r16 = Sentinel
    //     0x5915ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5915f0: cmp             w2, w16
    // 0x5915f4: b.eq            #0x59184c
    // 0x5915f8: LoadField: d1 = r2->field_7
    //     0x5915f8: ldur            d1, [x2, #7]
    // 0x5915fc: fcmp            d0, d1
    // 0x591600: b.vs            #0x59160c
    // 0x591604: b.ne            #0x59160c
    // 0x591608: r1 = Instance_Duration
    //     0x591608: ldr             x1, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x59160c: stur            x1, [fp, #-8]
    // 0x591610: SaveReg r0
    //     0x591610: str             x0, [SP, #-8]!
    // 0x591614: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x591614: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x591618: r0 = stop()
    //     0x591618: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x59161c: add             SP, SP, #8
    // 0x591620: ldur            x16, [fp, #-8]
    // 0x591624: r30 = Instance_Duration
    //     0x591624: ldr             lr, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x591628: stp             lr, x16, [SP, #-0x10]!
    // 0x59162c: r0 = ==()
    //     0x59162c: bl              #0xc5bcc0  ; [dart:core] Duration::==
    // 0x591630: add             SP, SP, #0x10
    // 0x591634: tbnz            w0, #4, #0x591768
    // 0x591638: ldur            x1, [fp, #-0x18]
    // 0x59163c: ldur            d0, [fp, #-0x38]
    // 0x591640: LoadField: r0 = r1->field_37
    //     0x591640: ldur            w0, [x1, #0x37]
    // 0x591644: DecompressPointer r0
    //     0x591644: add             x0, x0, HEAP, lsl #32
    // 0x591648: r16 = Sentinel
    //     0x591648: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x59164c: cmp             w0, w16
    // 0x591650: b.eq            #0x591858
    // 0x591654: LoadField: d1 = r0->field_7
    //     0x591654: ldur            d1, [x0, #7]
    // 0x591658: fcmp            d1, d0
    // 0x59165c: b.eq            #0x5916ec
    // 0x591660: LoadField: d1 = r1->field_13
    //     0x591660: ldur            d1, [x1, #0x13]
    // 0x591664: LoadField: d2 = r1->field_1b
    //     0x591664: ldur            d2, [x1, #0x1b]
    // 0x591668: fcmp            d0, d1
    // 0x59166c: b.vs            #0x59167c
    // 0x591670: b.ge            #0x59167c
    // 0x591674: mov             v0.16b, v1.16b
    // 0x591678: b               #0x59169c
    // 0x59167c: fcmp            d0, d2
    // 0x591680: b.vs            #0x591690
    // 0x591684: b.le            #0x591690
    // 0x591688: mov             v0.16b, v2.16b
    // 0x59168c: b               #0x59169c
    // 0x591690: fcmp            d0, d0
    // 0x591694: b.vc            #0x59169c
    // 0x591698: mov             v0.16b, v2.16b
    // 0x59169c: r0 = inline_Allocate_Double()
    //     0x59169c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x5916a0: add             x0, x0, #0x10
    //     0x5916a4: cmp             x2, x0
    //     0x5916a8: b.ls            #0x591864
    //     0x5916ac: str             x0, [THR, #0x60]  ; THR::top
    //     0x5916b0: sub             x0, x0, #0xf
    //     0x5916b4: mov             x2, #0xd108
    //     0x5916b8: movk            x2, #3, lsl #16
    //     0x5916bc: stur            x2, [x0, #-1]
    // 0x5916c0: StoreField: r0->field_7 = d0
    //     0x5916c0: stur            d0, [x0, #7]
    // 0x5916c4: StoreField: r1->field_37 = r0
    //     0x5916c4: stur            w0, [x1, #0x37]
    //     0x5916c8: ldurb           w16, [x1, #-1]
    //     0x5916cc: ldurb           w17, [x0, #-1]
    //     0x5916d0: and             x16, x17, x16, lsr #2
    //     0x5916d4: tst             x16, HEAP, lsr #32
    //     0x5916d8: b.eq            #0x5916e0
    //     0x5916dc: bl              #0xd6826c
    // 0x5916e0: SaveReg r1
    //     0x5916e0: str             x1, [SP, #-8]!
    // 0x5916e4: r0 = notifyListeners()
    //     0x5916e4: bl              #0x593248  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x5916e8: add             SP, SP, #8
    // 0x5916ec: ldur            x1, [fp, #-0x18]
    // 0x5916f0: LoadField: r0 = r1->field_3f
    //     0x5916f0: ldur            w0, [x1, #0x3f]
    // 0x5916f4: DecompressPointer r0
    //     0x5916f4: add             x0, x0, HEAP, lsl #32
    // 0x5916f8: r16 = Instance__AnimationDirection
    //     0x5916f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x5916fc: ldr             x16, [x16, #0xb98]
    // 0x591700: cmp             w0, w16
    // 0x591704: b.ne            #0x591714
    // 0x591708: r0 = Instance_AnimationStatus
    //     0x591708: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x59170c: ldr             x0, [x0, #0xba0]
    // 0x591710: b               #0x59171c
    // 0x591714: r0 = Instance_AnimationStatus
    //     0x591714: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x591718: ldr             x0, [x0, #0xba8]
    // 0x59171c: StoreField: r1->field_43 = r0
    //     0x59171c: stur            w0, [x1, #0x43]
    //     0x591720: ldurb           w16, [x1, #-1]
    //     0x591724: ldurb           w17, [x0, #-1]
    //     0x591728: and             x16, x17, x16, lsr #2
    //     0x59172c: tst             x16, HEAP, lsr #32
    //     0x591730: b.eq            #0x591738
    //     0x591734: bl              #0xd6826c
    // 0x591738: SaveReg r1
    //     0x591738: str             x1, [SP, #-8]!
    // 0x59173c: r0 = _checkStatusChanged()
    //     0x59173c: bl              #0x592f80  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0x591740: add             SP, SP, #8
    // 0x591744: r0 = TickerFuture()
    //     0x591744: bl              #0x592f74  ; AllocateTickerFutureStub -> TickerFuture (size=0x14)
    // 0x591748: stur            x0, [fp, #-0x20]
    // 0x59174c: SaveReg r0
    //     0x59174c: str             x0, [SP, #-8]!
    // 0x591750: r0 = TickerFuture.complete()
    //     0x591750: bl              #0x592e4c  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::TickerFuture.complete
    // 0x591754: add             SP, SP, #8
    // 0x591758: ldur            x0, [fp, #-0x20]
    // 0x59175c: LeaveFrame
    //     0x59175c: mov             SP, fp
    //     0x591760: ldp             fp, lr, [SP], #0x10
    // 0x591764: ret
    //     0x591764: ret             
    // 0x591768: ldur            x1, [fp, #-0x18]
    // 0x59176c: ldur            d0, [fp, #-0x38]
    // 0x591770: ldur            d1, [fp, #-0x40]
    // 0x591774: LoadField: r0 = r1->field_37
    //     0x591774: ldur            w0, [x1, #0x37]
    // 0x591778: DecompressPointer r0
    //     0x591778: add             x0, x0, HEAP, lsl #32
    // 0x59177c: r16 = Sentinel
    //     0x59177c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x591780: cmp             w0, w16
    // 0x591784: b.eq            #0x59187c
    // 0x591788: stur            x0, [fp, #-0x28]
    // 0x59178c: r2 = inline_Allocate_Double()
    //     0x59178c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x591790: add             x2, x2, #0x10
    //     0x591794: cmp             x3, x2
    //     0x591798: b.ls            #0x591888
    //     0x59179c: str             x2, [THR, #0x60]  ; THR::top
    //     0x5917a0: sub             x2, x2, #0xf
    //     0x5917a4: mov             x3, #0xd108
    //     0x5917a8: movk            x3, #3, lsl #16
    //     0x5917ac: stur            x3, [x2, #-1]
    // 0x5917b0: StoreField: r2->field_7 = d0
    //     0x5917b0: stur            d0, [x2, #7]
    // 0x5917b4: stur            x2, [fp, #-0x20]
    // 0x5917b8: r0 = _InterpolationSimulation()
    //     0x5917b8: bl              #0x592e40  ; Allocate_InterpolationSimulationStub -> _InterpolationSimulation (size=0x28)
    // 0x5917bc: stur            x0, [fp, #-0x30]
    // 0x5917c0: ldur            x16, [fp, #-0x28]
    // 0x5917c4: stp             x16, x0, [SP, #-0x10]!
    // 0x5917c8: ldur            x16, [fp, #-0x20]
    // 0x5917cc: ldur            lr, [fp, #-8]
    // 0x5917d0: stp             lr, x16, [SP, #-0x10]!
    // 0x5917d4: ldur            x16, [fp, #-0x10]
    // 0x5917d8: SaveReg r16
    //     0x5917d8: str             x16, [SP, #-8]!
    // 0x5917dc: ldur            d0, [fp, #-0x40]
    // 0x5917e0: SaveReg d0
    //     0x5917e0: str             d0, [SP, #-8]!
    // 0x5917e4: r0 = _InterpolationSimulation()
    //     0x5917e4: bl              #0x592dc4  ; [package:flutter/src/animation/animation_controller.dart] _InterpolationSimulation::_InterpolationSimulation
    // 0x5917e8: add             SP, SP, #0x30
    // 0x5917ec: ldur            x16, [fp, #-0x18]
    // 0x5917f0: ldur            lr, [fp, #-0x30]
    // 0x5917f4: stp             lr, x16, [SP, #-0x10]!
    // 0x5917f8: r0 = _startSimulation()
    //     0x5917f8: bl              #0x5918a4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0x5917fc: add             SP, SP, #0x10
    // 0x591800: LeaveFrame
    //     0x591800: mov             SP, fp
    //     0x591804: ldp             fp, lr, [SP], #0x10
    // 0x591808: ret
    //     0x591808: ret             
    // 0x59180c: r0 = StackOverflowSharedWithFPURegs()
    //     0x59180c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x591810: b               #0x59146c
    // 0x591814: r0 = NullCastErrorSharedWithFPURegs()
    //     0x591814: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x591818: r9 = _value
    //     0x591818: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x59181c: ldr             x9, [x9, #0xbb0]
    // 0x591820: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x591820: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x591824: r0 = NullCastErrorSharedWithFPURegs()
    //     0x591824: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x591828: stp             q1, q2, [SP, #-0x20]!
    // 0x59182c: SaveReg d0
    //     0x59182c: str             q0, [SP, #-0x10]!
    // 0x591830: stp             x0, x1, [SP, #-0x10]!
    // 0x591834: r0 = AllocateDouble()
    //     0x591834: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x591838: mov             x2, x0
    // 0x59183c: ldp             x0, x1, [SP], #0x10
    // 0x591840: RestoreReg d0
    //     0x591840: ldr             q0, [SP], #0x10
    // 0x591844: ldp             q1, q2, [SP], #0x20
    // 0x591848: b               #0x5915c0
    // 0x59184c: r9 = _value
    //     0x59184c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x591850: ldr             x9, [x9, #0xbb0]
    // 0x591854: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x591854: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x591858: r9 = _value
    //     0x591858: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x59185c: ldr             x9, [x9, #0xbb0]
    // 0x591860: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x591860: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x591864: SaveReg d0
    //     0x591864: str             q0, [SP, #-0x10]!
    // 0x591868: SaveReg r1
    //     0x591868: str             x1, [SP, #-8]!
    // 0x59186c: r0 = AllocateDouble()
    //     0x59186c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x591870: RestoreReg r1
    //     0x591870: ldr             x1, [SP], #8
    // 0x591874: RestoreReg d0
    //     0x591874: ldr             q0, [SP], #0x10
    // 0x591878: b               #0x5916c0
    // 0x59187c: r9 = _value
    //     0x59187c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x591880: ldr             x9, [x9, #0xbb0]
    // 0x591884: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x591884: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x591888: stp             q0, q1, [SP, #-0x20]!
    // 0x59188c: stp             x0, x1, [SP, #-0x10]!
    // 0x591890: r0 = AllocateDouble()
    //     0x591890: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x591894: mov             x2, x0
    // 0x591898: ldp             x0, x1, [SP], #0x10
    // 0x59189c: ldp             q0, q1, [SP], #0x20
    // 0x5918a0: b               #0x5917b0
  }
  _ _startSimulation(/* No info */) {
    // ** addr: 0x5918a4, size: 0x1a0
    // 0x5918a4: EnterFrame
    //     0x5918a4: stp             fp, lr, [SP, #-0x10]!
    //     0x5918a8: mov             fp, SP
    // 0x5918ac: AllocStack(0x8)
    //     0x5918ac: sub             SP, SP, #8
    // 0x5918b0: r1 = Instance_Duration
    //     0x5918b0: ldr             x1, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x5918b4: CheckStackOverflow
    //     0x5918b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5918b8: cmp             SP, x16
    //     0x5918bc: b.ls            #0x591a20
    // 0x5918c0: ldr             x0, [fp, #0x10]
    // 0x5918c4: ldr             x2, [fp, #0x18]
    // 0x5918c8: StoreField: r2->field_33 = r0
    //     0x5918c8: stur            w0, [x2, #0x33]
    //     0x5918cc: ldurb           w16, [x2, #-1]
    //     0x5918d0: ldurb           w17, [x0, #-1]
    //     0x5918d4: and             x16, x17, x16, lsr #2
    //     0x5918d8: tst             x16, HEAP, lsr #32
    //     0x5918dc: b.eq            #0x5918e4
    //     0x5918e0: bl              #0xd6828c
    // 0x5918e4: StoreField: r2->field_3b = r1
    //     0x5918e4: stur            w1, [x2, #0x3b]
    // 0x5918e8: ldr             x0, [fp, #0x10]
    // 0x5918ec: r1 = LoadClassIdInstr(r0)
    //     0x5918ec: ldur            x1, [x0, #-1]
    //     0x5918f0: ubfx            x1, x1, #0xc, #0x14
    // 0x5918f4: r16 = 0.000000
    //     0x5918f4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x5918f8: stp             x16, x0, [SP, #-0x10]!
    // 0x5918fc: mov             x0, x1
    // 0x591900: r0 = GDT[cid_x0 + -0xffe]()
    //     0x591900: sub             lr, x0, #0xffe
    //     0x591904: ldr             lr, [x21, lr, lsl #3]
    //     0x591908: blr             lr
    // 0x59190c: add             SP, SP, #0x10
    // 0x591910: ldr             x1, [fp, #0x18]
    // 0x591914: LoadField: d1 = r1->field_13
    //     0x591914: ldur            d1, [x1, #0x13]
    // 0x591918: LoadField: d2 = r1->field_1b
    //     0x591918: ldur            d2, [x1, #0x1b]
    // 0x59191c: fcmp            d0, d1
    // 0x591920: b.vs            #0x591930
    // 0x591924: b.ge            #0x591930
    // 0x591928: mov             v0.16b, v1.16b
    // 0x59192c: b               #0x591950
    // 0x591930: fcmp            d0, d2
    // 0x591934: b.vs            #0x591944
    // 0x591938: b.le            #0x591944
    // 0x59193c: mov             v0.16b, v2.16b
    // 0x591940: b               #0x591950
    // 0x591944: fcmp            d0, d0
    // 0x591948: b.vc            #0x591950
    // 0x59194c: mov             v0.16b, v2.16b
    // 0x591950: r0 = inline_Allocate_Double()
    //     0x591950: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x591954: add             x0, x0, #0x10
    //     0x591958: cmp             x2, x0
    //     0x59195c: b.ls            #0x591a28
    //     0x591960: str             x0, [THR, #0x60]  ; THR::top
    //     0x591964: sub             x0, x0, #0xf
    //     0x591968: mov             x2, #0xd108
    //     0x59196c: movk            x2, #3, lsl #16
    //     0x591970: stur            x2, [x0, #-1]
    // 0x591974: StoreField: r0->field_7 = d0
    //     0x591974: stur            d0, [x0, #7]
    // 0x591978: StoreField: r1->field_37 = r0
    //     0x591978: stur            w0, [x1, #0x37]
    //     0x59197c: ldurb           w16, [x1, #-1]
    //     0x591980: ldurb           w17, [x0, #-1]
    //     0x591984: and             x16, x17, x16, lsr #2
    //     0x591988: tst             x16, HEAP, lsr #32
    //     0x59198c: b.eq            #0x591994
    //     0x591990: bl              #0xd6826c
    // 0x591994: LoadField: r0 = r1->field_2f
    //     0x591994: ldur            w0, [x1, #0x2f]
    // 0x591998: DecompressPointer r0
    //     0x591998: add             x0, x0, HEAP, lsl #32
    // 0x59199c: cmp             w0, NULL
    // 0x5919a0: b.eq            #0x591a40
    // 0x5919a4: SaveReg r0
    //     0x5919a4: str             x0, [SP, #-8]!
    // 0x5919a8: r0 = start()
    //     0x5919a8: bl              #0x591a44  ; [package:flutter/src/scheduler/ticker.dart] Ticker::start
    // 0x5919ac: add             SP, SP, #8
    // 0x5919b0: mov             x2, x0
    // 0x5919b4: ldr             x1, [fp, #0x18]
    // 0x5919b8: stur            x2, [fp, #-8]
    // 0x5919bc: LoadField: r0 = r1->field_3f
    //     0x5919bc: ldur            w0, [x1, #0x3f]
    // 0x5919c0: DecompressPointer r0
    //     0x5919c0: add             x0, x0, HEAP, lsl #32
    // 0x5919c4: r16 = Instance__AnimationDirection
    //     0x5919c4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x5919c8: ldr             x16, [x16, #0xb98]
    // 0x5919cc: cmp             w0, w16
    // 0x5919d0: b.ne            #0x5919e0
    // 0x5919d4: r0 = Instance_AnimationStatus
    //     0x5919d4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0x5919d8: ldr             x0, [x0, #0xbb8]
    // 0x5919dc: b               #0x5919e8
    // 0x5919e0: r0 = Instance_AnimationStatus
    //     0x5919e0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0x5919e4: ldr             x0, [x0, #0xbc0]
    // 0x5919e8: StoreField: r1->field_43 = r0
    //     0x5919e8: stur            w0, [x1, #0x43]
    //     0x5919ec: ldurb           w16, [x1, #-1]
    //     0x5919f0: ldurb           w17, [x0, #-1]
    //     0x5919f4: and             x16, x17, x16, lsr #2
    //     0x5919f8: tst             x16, HEAP, lsr #32
    //     0x5919fc: b.eq            #0x591a04
    //     0x591a00: bl              #0xd6826c
    // 0x591a04: SaveReg r1
    //     0x591a04: str             x1, [SP, #-8]!
    // 0x591a08: r0 = _checkStatusChanged()
    //     0x591a08: bl              #0x592f80  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0x591a0c: add             SP, SP, #8
    // 0x591a10: ldur            x0, [fp, #-8]
    // 0x591a14: LeaveFrame
    //     0x591a14: mov             SP, fp
    //     0x591a18: ldp             fp, lr, [SP], #0x10
    // 0x591a1c: ret
    //     0x591a1c: ret             
    // 0x591a20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x591a20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x591a24: b               #0x5918c0
    // 0x591a28: SaveReg d0
    //     0x591a28: str             q0, [SP, #-0x10]!
    // 0x591a2c: SaveReg r1
    //     0x591a2c: str             x1, [SP, #-8]!
    // 0x591a30: r0 = AllocateDouble()
    //     0x591a30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x591a34: RestoreReg r1
    //     0x591a34: ldr             x1, [SP], #8
    // 0x591a38: RestoreReg d0
    //     0x591a38: ldr             q0, [SP], #0x10
    // 0x591a3c: b               #0x591974
    // 0x591a40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x591a40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _checkStatusChanged(/* No info */) {
    // ** addr: 0x592f80, size: 0x8c
    // 0x592f80: EnterFrame
    //     0x592f80: stp             fp, lr, [SP, #-0x10]!
    //     0x592f84: mov             fp, SP
    // 0x592f88: CheckStackOverflow
    //     0x592f88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x592f8c: cmp             SP, x16
    //     0x592f90: b.ls            #0x592ff8
    // 0x592f94: ldr             x1, [fp, #0x10]
    // 0x592f98: LoadField: r2 = r1->field_43
    //     0x592f98: ldur            w2, [x1, #0x43]
    // 0x592f9c: DecompressPointer r2
    //     0x592f9c: add             x2, x2, HEAP, lsl #32
    // 0x592fa0: r16 = Sentinel
    //     0x592fa0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x592fa4: cmp             w2, w16
    // 0x592fa8: b.eq            #0x593000
    // 0x592fac: LoadField: r0 = r1->field_47
    //     0x592fac: ldur            w0, [x1, #0x47]
    // 0x592fb0: DecompressPointer r0
    //     0x592fb0: add             x0, x0, HEAP, lsl #32
    // 0x592fb4: cmp             w0, w2
    // 0x592fb8: b.eq            #0x592fe8
    // 0x592fbc: mov             x0, x2
    // 0x592fc0: StoreField: r1->field_47 = r0
    //     0x592fc0: stur            w0, [x1, #0x47]
    //     0x592fc4: ldurb           w16, [x1, #-1]
    //     0x592fc8: ldurb           w17, [x0, #-1]
    //     0x592fcc: and             x16, x17, x16, lsr #2
    //     0x592fd0: tst             x16, HEAP, lsr #32
    //     0x592fd4: b.eq            #0x592fdc
    //     0x592fd8: bl              #0xd6826c
    // 0x592fdc: stp             x2, x1, [SP, #-0x10]!
    // 0x592fe0: r0 = notifyStatusListeners()
    //     0x592fe0: bl              #0x59300c  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0x592fe4: add             SP, SP, #0x10
    // 0x592fe8: r0 = Null
    //     0x592fe8: mov             x0, NULL
    // 0x592fec: LeaveFrame
    //     0x592fec: mov             SP, fp
    //     0x592ff0: ldp             fp, lr, [SP], #0x10
    // 0x592ff4: ret
    //     0x592ff4: ret             
    // 0x592ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x592ff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x592ffc: b               #0x592f94
    // 0x593000: r9 = _status
    //     0x593000: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbe0] Field <AnimationController._status@575066280>: late (offset: 0x44)
    //     0x593004: ldr             x9, [x9, #0xbe0]
    // 0x593008: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x593008: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ stop(/* No info */) {
    // ** addr: 0x593468, size: 0xac
    // 0x593468: EnterFrame
    //     0x593468: stp             fp, lr, [SP, #-0x10]!
    //     0x59346c: mov             fp, SP
    // 0x593470: mov             x0, x4
    // 0x593474: LoadField: r1 = r0->field_13
    //     0x593474: ldur            w1, [x0, #0x13]
    // 0x593478: DecompressPointer r1
    //     0x593478: add             x1, x1, HEAP, lsl #32
    // 0x59347c: sub             x2, x1, #2
    // 0x593480: add             x3, fp, w2, sxtw #2
    // 0x593484: ldr             x3, [x3, #0x10]
    // 0x593488: LoadField: r2 = r0->field_1f
    //     0x593488: ldur            w2, [x0, #0x1f]
    // 0x59348c: DecompressPointer r2
    //     0x59348c: add             x2, x2, HEAP, lsl #32
    // 0x593490: r16 = "canceled"
    //     0x593490: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc18] "canceled"
    //     0x593494: ldr             x16, [x16, #0xc18]
    // 0x593498: cmp             w2, w16
    // 0x59349c: b.ne            #0x5934bc
    // 0x5934a0: LoadField: r2 = r0->field_23
    //     0x5934a0: ldur            w2, [x0, #0x23]
    // 0x5934a4: DecompressPointer r2
    //     0x5934a4: add             x2, x2, HEAP, lsl #32
    // 0x5934a8: sub             w0, w1, w2
    // 0x5934ac: add             x1, fp, w0, sxtw #2
    // 0x5934b0: ldr             x1, [x1, #8]
    // 0x5934b4: mov             x0, x1
    // 0x5934b8: b               #0x5934c0
    // 0x5934bc: r0 = true
    //     0x5934bc: add             x0, NULL, #0x20  ; true
    // 0x5934c0: CheckStackOverflow
    //     0x5934c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5934c4: cmp             SP, x16
    //     0x5934c8: b.ls            #0x593508
    // 0x5934cc: StoreField: r3->field_33 = rNULL
    //     0x5934cc: stur            NULL, [x3, #0x33]
    // 0x5934d0: StoreField: r3->field_3b = rNULL
    //     0x5934d0: stur            NULL, [x3, #0x3b]
    // 0x5934d4: LoadField: r1 = r3->field_2f
    //     0x5934d4: ldur            w1, [x3, #0x2f]
    // 0x5934d8: DecompressPointer r1
    //     0x5934d8: add             x1, x1, HEAP, lsl #32
    // 0x5934dc: cmp             w1, NULL
    // 0x5934e0: b.eq            #0x593510
    // 0x5934e4: stp             x0, x1, [SP, #-0x10]!
    // 0x5934e8: r4 = const [0, 0x2, 0x2, 0x1, canceled, 0x1, null]
    //     0x5934e8: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc20] List(7) [0, 0x2, 0x2, 0x1, "canceled", 0x1, Null]
    //     0x5934ec: ldr             x4, [x4, #0xc20]
    // 0x5934f0: r0 = stop()
    //     0x5934f0: bl              #0x593514  ; [package:flutter/src/scheduler/ticker.dart] Ticker::stop
    // 0x5934f4: add             SP, SP, #0x10
    // 0x5934f8: r0 = Null
    //     0x5934f8: mov             x0, NULL
    // 0x5934fc: LeaveFrame
    //     0x5934fc: mov             SP, fp
    //     0x593500: ldp             fp, lr, [SP], #0x10
    // 0x593504: ret
    //     0x593504: ret             
    // 0x593508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x593508: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59350c: b               #0x5934cc
    // 0x593510: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x593510: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ value=(/* No info */) {
    // ** addr: 0x5937d8, size: 0x78
    // 0x5937d8: EnterFrame
    //     0x5937d8: stp             fp, lr, [SP, #-0x10]!
    //     0x5937dc: mov             fp, SP
    // 0x5937e0: CheckStackOverflow
    //     0x5937e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5937e4: cmp             SP, x16
    //     0x5937e8: b.ls            #0x593848
    // 0x5937ec: ldr             x16, [fp, #0x18]
    // 0x5937f0: SaveReg r16
    //     0x5937f0: str             x16, [SP, #-8]!
    // 0x5937f4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5937f4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5937f8: r0 = stop()
    //     0x5937f8: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x5937fc: add             SP, SP, #8
    // 0x593800: ldr             x16, [fp, #0x18]
    // 0x593804: SaveReg r16
    //     0x593804: str             x16, [SP, #-8]!
    // 0x593808: ldr             d0, [fp, #0x10]
    // 0x59380c: SaveReg d0
    //     0x59380c: str             d0, [SP, #-8]!
    // 0x593810: r0 = _internalSetValue()
    //     0x593810: bl              #0x593850  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_internalSetValue
    // 0x593814: add             SP, SP, #0x10
    // 0x593818: ldr             x16, [fp, #0x18]
    // 0x59381c: SaveReg r16
    //     0x59381c: str             x16, [SP, #-8]!
    // 0x593820: r0 = notifyListeners()
    //     0x593820: bl              #0x593248  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x593824: add             SP, SP, #8
    // 0x593828: ldr             x16, [fp, #0x18]
    // 0x59382c: SaveReg r16
    //     0x59382c: str             x16, [SP, #-8]!
    // 0x593830: r0 = _checkStatusChanged()
    //     0x593830: bl              #0x592f80  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0x593834: add             SP, SP, #8
    // 0x593838: r0 = Null
    //     0x593838: mov             x0, NULL
    // 0x59383c: LeaveFrame
    //     0x59383c: mov             SP, fp
    //     0x593840: ldp             fp, lr, [SP], #0x10
    // 0x593844: ret
    //     0x593844: ret             
    // 0x593848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x593848: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x59384c: b               #0x5937ec
  }
  _ _internalSetValue(/* No info */) {
    // ** addr: 0x593850, size: 0x140
    // 0x593850: EnterFrame
    //     0x593850: stp             fp, lr, [SP, #-0x10]!
    //     0x593854: mov             fp, SP
    // 0x593858: ldr             x1, [fp, #0x18]
    // 0x59385c: LoadField: d0 = r1->field_13
    //     0x59385c: ldur            d0, [x1, #0x13]
    // 0x593860: LoadField: d1 = r1->field_1b
    //     0x593860: ldur            d1, [x1, #0x1b]
    // 0x593864: ldr             d2, [fp, #0x10]
    // 0x593868: fcmp            d2, d0
    // 0x59386c: b.vs            #0x59387c
    // 0x593870: b.ge            #0x59387c
    // 0x593874: mov             v2.16b, v0.16b
    // 0x593878: b               #0x59389c
    // 0x59387c: fcmp            d2, d1
    // 0x593880: b.vs            #0x593890
    // 0x593884: b.le            #0x593890
    // 0x593888: mov             v2.16b, v1.16b
    // 0x59388c: b               #0x59389c
    // 0x593890: fcmp            d2, d2
    // 0x593894: b.vc            #0x59389c
    // 0x593898: mov             v2.16b, v1.16b
    // 0x59389c: r0 = inline_Allocate_Double()
    //     0x59389c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x5938a0: add             x0, x0, #0x10
    //     0x5938a4: cmp             x2, x0
    //     0x5938a8: b.ls            #0x593970
    //     0x5938ac: str             x0, [THR, #0x60]  ; THR::top
    //     0x5938b0: sub             x0, x0, #0xf
    //     0x5938b4: mov             x2, #0xd108
    //     0x5938b8: movk            x2, #3, lsl #16
    //     0x5938bc: stur            x2, [x0, #-1]
    // 0x5938c0: StoreField: r0->field_7 = d2
    //     0x5938c0: stur            d2, [x0, #7]
    // 0x5938c4: StoreField: r1->field_37 = r0
    //     0x5938c4: stur            w0, [x1, #0x37]
    //     0x5938c8: ldurb           w16, [x1, #-1]
    //     0x5938cc: ldurb           w17, [x0, #-1]
    //     0x5938d0: and             x16, x17, x16, lsr #2
    //     0x5938d4: tst             x16, HEAP, lsr #32
    //     0x5938d8: b.eq            #0x5938e0
    //     0x5938dc: bl              #0xd6826c
    // 0x5938e0: fcmp            d2, d0
    // 0x5938e4: b.vs            #0x5938fc
    // 0x5938e8: b.ne            #0x5938fc
    // 0x5938ec: r2 = Instance_AnimationStatus
    //     0x5938ec: add             x2, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x5938f0: ldr             x2, [x2, #0xba8]
    // 0x5938f4: StoreField: r1->field_43 = r2
    //     0x5938f4: stur            w2, [x1, #0x43]
    // 0x5938f8: b               #0x593960
    // 0x5938fc: fcmp            d2, d1
    // 0x593900: b.vs            #0x593918
    // 0x593904: b.ne            #0x593918
    // 0x593908: r2 = Instance_AnimationStatus
    //     0x593908: add             x2, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x59390c: ldr             x2, [x2, #0xba0]
    // 0x593910: StoreField: r1->field_43 = r2
    //     0x593910: stur            w2, [x1, #0x43]
    // 0x593914: b               #0x593960
    // 0x593918: LoadField: r2 = r1->field_3f
    //     0x593918: ldur            w2, [x1, #0x3f]
    // 0x59391c: DecompressPointer r2
    //     0x59391c: add             x2, x2, HEAP, lsl #32
    // 0x593920: r16 = Instance__AnimationDirection
    //     0x593920: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x593924: ldr             x16, [x16, #0xb98]
    // 0x593928: cmp             w2, w16
    // 0x59392c: b.ne            #0x59393c
    // 0x593930: r0 = Instance_AnimationStatus
    //     0x593930: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0x593934: ldr             x0, [x0, #0xbb8]
    // 0x593938: b               #0x593944
    // 0x59393c: r0 = Instance_AnimationStatus
    //     0x59393c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0x593940: ldr             x0, [x0, #0xbc0]
    // 0x593944: StoreField: r1->field_43 = r0
    //     0x593944: stur            w0, [x1, #0x43]
    //     0x593948: ldurb           w16, [x1, #-1]
    //     0x59394c: ldurb           w17, [x0, #-1]
    //     0x593950: and             x16, x17, x16, lsr #2
    //     0x593954: tst             x16, HEAP, lsr #32
    //     0x593958: b.eq            #0x593960
    //     0x59395c: bl              #0xd6826c
    // 0x593960: r0 = Null
    //     0x593960: mov             x0, NULL
    // 0x593964: LeaveFrame
    //     0x593964: mov             SP, fp
    //     0x593968: ldp             fp, lr, [SP], #0x10
    // 0x59396c: ret
    //     0x59396c: ret             
    // 0x593970: stp             q1, q2, [SP, #-0x20]!
    // 0x593974: SaveReg d0
    //     0x593974: str             q0, [SP, #-0x10]!
    // 0x593978: SaveReg r1
    //     0x593978: str             x1, [SP, #-8]!
    // 0x59397c: r0 = AllocateDouble()
    //     0x59397c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x593980: RestoreReg r1
    //     0x593980: ldr             x1, [SP], #8
    // 0x593984: RestoreReg d0
    //     0x593984: ldr             q0, [SP], #0x10
    // 0x593988: ldp             q1, q2, [SP], #0x20
    // 0x59398c: b               #0x5938c0
  }
  _ forward(/* No info */) {
    // ** addr: 0x691638, size: 0xc0
    // 0x691638: EnterFrame
    //     0x691638: stp             fp, lr, [SP, #-0x10]!
    //     0x69163c: mov             fp, SP
    // 0x691640: AllocStack(0x8)
    //     0x691640: sub             SP, SP, #8
    // 0x691644: SetupParameters(AnimationController<double> this /* r3, fp-0x8 */, {dynamic from = Null /* r1 */})
    //     0x691644: mov             x0, x4
    //     0x691648: ldur            w1, [x0, #0x13]
    //     0x69164c: add             x1, x1, HEAP, lsl #32
    //     0x691650: sub             x2, x1, #2
    //     0x691654: add             x3, fp, w2, sxtw #2
    //     0x691658: ldr             x3, [x3, #0x10]
    //     0x69165c: stur            x3, [fp, #-8]
    //     0x691660: ldur            w2, [x0, #0x1f]
    //     0x691664: add             x2, x2, HEAP, lsl #32
    //     0x691668: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb88] "from"
    //     0x69166c: ldr             x16, [x16, #0xb88]
    //     0x691670: cmp             w2, w16
    //     0x691674: b.ne            #0x691690
    //     0x691678: ldur            w2, [x0, #0x23]
    //     0x69167c: add             x2, x2, HEAP, lsl #32
    //     0x691680: sub             w0, w1, w2
    //     0x691684: add             x1, fp, w0, sxtw #2
    //     0x691688: ldr             x1, [x1, #8]
    //     0x69168c: b               #0x691694
    //     0x691690: mov             x1, NULL
    //     0x691694: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x691698: ldr             x0, [x0, #0xb98]
    // 0x691694: r0 = Instance__AnimationDirection
    // 0x69169c: CheckStackOverflow
    //     0x69169c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6916a0: cmp             SP, x16
    //     0x6916a4: b.ls            #0x6916f0
    // 0x6916a8: StoreField: r3->field_3f = r0
    //     0x6916a8: stur            w0, [x3, #0x3f]
    // 0x6916ac: cmp             w1, NULL
    // 0x6916b0: b.eq            #0x6916c8
    // 0x6916b4: LoadField: d0 = r1->field_7
    //     0x6916b4: ldur            d0, [x1, #7]
    // 0x6916b8: SaveReg r3
    //     0x6916b8: str             x3, [SP, #-8]!
    // 0x6916bc: SaveReg d0
    //     0x6916bc: str             d0, [SP, #-8]!
    // 0x6916c0: r0 = value=()
    //     0x6916c0: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x6916c4: add             SP, SP, #0x10
    // 0x6916c8: ldur            x0, [fp, #-8]
    // 0x6916cc: LoadField: d0 = r0->field_1b
    //     0x6916cc: ldur            d0, [x0, #0x1b]
    // 0x6916d0: SaveReg r0
    //     0x6916d0: str             x0, [SP, #-8]!
    // 0x6916d4: SaveReg d0
    //     0x6916d4: str             d0, [SP, #-8]!
    // 0x6916d8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6916d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6916dc: r0 = _animateToInternal()
    //     0x6916dc: bl              #0x591390  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_animateToInternal
    // 0x6916e0: add             SP, SP, #0x10
    // 0x6916e4: LeaveFrame
    //     0x6916e4: mov             SP, fp
    //     0x6916e8: ldp             fp, lr, [SP], #0x10
    // 0x6916ec: ret
    //     0x6916ec: ret             
    // 0x6916f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6916f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6916f4: b               #0x6916a8
  }
  _ resync(/* No info */) {
    // ** addr: 0x6c2d58, size: 0xd0
    // 0x6c2d58: EnterFrame
    //     0x6c2d58: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2d5c: mov             fp, SP
    // 0x6c2d60: AllocStack(0x8)
    //     0x6c2d60: sub             SP, SP, #8
    // 0x6c2d64: CheckStackOverflow
    //     0x6c2d64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2d68: cmp             SP, x16
    //     0x6c2d6c: b.ls            #0x6c2e1c
    // 0x6c2d70: ldr             x0, [fp, #0x18]
    // 0x6c2d74: LoadField: r1 = r0->field_2f
    //     0x6c2d74: ldur            w1, [x0, #0x2f]
    // 0x6c2d78: DecompressPointer r1
    //     0x6c2d78: add             x1, x1, HEAP, lsl #32
    // 0x6c2d7c: stur            x1, [fp, #-8]
    // 0x6c2d80: cmp             w1, NULL
    // 0x6c2d84: b.eq            #0x6c2e24
    // 0x6c2d88: r1 = 1
    //     0x6c2d88: mov             x1, #1
    // 0x6c2d8c: r0 = AllocateContext()
    //     0x6c2d8c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6c2d90: mov             x1, x0
    // 0x6c2d94: ldr             x0, [fp, #0x18]
    // 0x6c2d98: StoreField: r1->field_f = r0
    //     0x6c2d98: stur            w0, [x1, #0xf]
    // 0x6c2d9c: mov             x2, x1
    // 0x6c2da0: r1 = Function '_tick@575066280':.
    //     0x6c2da0: add             x1, PP, #0x22, lsl #12  ; [pp+0x221f0] AnonymousClosure: (0x6c2f7c), in [package:flutter/src/animation/animation_controller.dart] AnimationController::_tick (0x6c2fc8)
    //     0x6c2da4: ldr             x1, [x1, #0x1f0]
    // 0x6c2da8: r0 = AllocateClosure()
    //     0x6c2da8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6c2dac: mov             x1, x0
    // 0x6c2db0: ldr             x0, [fp, #0x10]
    // 0x6c2db4: r2 = LoadClassIdInstr(r0)
    //     0x6c2db4: ldur            x2, [x0, #-1]
    //     0x6c2db8: ubfx            x2, x2, #0xc, #0x14
    // 0x6c2dbc: stp             x1, x0, [SP, #-0x10]!
    // 0x6c2dc0: mov             x0, x2
    // 0x6c2dc4: r0 = GDT[cid_x0 + 0xf44b]()
    //     0x6c2dc4: mov             x17, #0xf44b
    //     0x6c2dc8: add             lr, x0, x17
    //     0x6c2dcc: ldr             lr, [x21, lr, lsl #3]
    //     0x6c2dd0: blr             lr
    // 0x6c2dd4: add             SP, SP, #0x10
    // 0x6c2dd8: mov             x2, x0
    // 0x6c2ddc: ldr             x1, [fp, #0x18]
    // 0x6c2de0: StoreField: r1->field_2f = r0
    //     0x6c2de0: stur            w0, [x1, #0x2f]
    //     0x6c2de4: ldurb           w16, [x1, #-1]
    //     0x6c2de8: ldurb           w17, [x0, #-1]
    //     0x6c2dec: and             x16, x17, x16, lsr #2
    //     0x6c2df0: tst             x16, HEAP, lsr #32
    //     0x6c2df4: b.eq            #0x6c2dfc
    //     0x6c2df8: bl              #0xd6826c
    // 0x6c2dfc: ldur            x16, [fp, #-8]
    // 0x6c2e00: stp             x16, x2, [SP, #-0x10]!
    // 0x6c2e04: r0 = absorbTicker()
    //     0x6c2e04: bl              #0x6c2e28  ; [package:flutter/src/scheduler/ticker.dart] Ticker::absorbTicker
    // 0x6c2e08: add             SP, SP, #0x10
    // 0x6c2e0c: r0 = Null
    //     0x6c2e0c: mov             x0, NULL
    // 0x6c2e10: LeaveFrame
    //     0x6c2e10: mov             SP, fp
    //     0x6c2e14: ldp             fp, lr, [SP], #0x10
    // 0x6c2e18: ret
    //     0x6c2e18: ret             
    // 0x6c2e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2e1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2e20: b               #0x6c2d70
    // 0x6c2e24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6c2e24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _tick(dynamic, Duration) {
    // ** addr: 0x6c2f7c, size: 0x4c
    // 0x6c2f7c: EnterFrame
    //     0x6c2f7c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2f80: mov             fp, SP
    // 0x6c2f84: ldr             x0, [fp, #0x18]
    // 0x6c2f88: LoadField: r1 = r0->field_17
    //     0x6c2f88: ldur            w1, [x0, #0x17]
    // 0x6c2f8c: DecompressPointer r1
    //     0x6c2f8c: add             x1, x1, HEAP, lsl #32
    // 0x6c2f90: CheckStackOverflow
    //     0x6c2f90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2f94: cmp             SP, x16
    //     0x6c2f98: b.ls            #0x6c2fc0
    // 0x6c2f9c: LoadField: r0 = r1->field_f
    //     0x6c2f9c: ldur            w0, [x1, #0xf]
    // 0x6c2fa0: DecompressPointer r0
    //     0x6c2fa0: add             x0, x0, HEAP, lsl #32
    // 0x6c2fa4: ldr             x16, [fp, #0x10]
    // 0x6c2fa8: stp             x16, x0, [SP, #-0x10]!
    // 0x6c2fac: r0 = _tick()
    //     0x6c2fac: bl              #0x6c2fc8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_tick
    // 0x6c2fb0: add             SP, SP, #0x10
    // 0x6c2fb4: LeaveFrame
    //     0x6c2fb4: mov             SP, fp
    //     0x6c2fb8: ldp             fp, lr, [SP], #0x10
    // 0x6c2fbc: ret
    //     0x6c2fbc: ret             
    // 0x6c2fc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2fc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2fc4: b               #0x6c2f9c
  }
  _ _tick(/* No info */) {
    // ** addr: 0x6c2fc8, size: 0x26c
    // 0x6c2fc8: EnterFrame
    //     0x6c2fc8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2fcc: mov             fp, SP
    // 0x6c2fd0: AllocStack(0x8)
    //     0x6c2fd0: sub             SP, SP, #8
    // 0x6c2fd4: CheckStackOverflow
    //     0x6c2fd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2fd8: cmp             SP, x16
    //     0x6c2fdc: b.ls            #0x6c31f0
    // 0x6c2fe0: ldr             x0, [fp, #0x10]
    // 0x6c2fe4: ldr             x2, [fp, #0x18]
    // 0x6c2fe8: StoreField: r2->field_3b = r0
    //     0x6c2fe8: stur            w0, [x2, #0x3b]
    //     0x6c2fec: ldurb           w16, [x2, #-1]
    //     0x6c2ff0: ldurb           w17, [x0, #-1]
    //     0x6c2ff4: and             x16, x17, x16, lsr #2
    //     0x6c2ff8: tst             x16, HEAP, lsr #32
    //     0x6c2ffc: b.eq            #0x6c3004
    //     0x6c3000: bl              #0xd6828c
    // 0x6c3004: ldr             x0, [fp, #0x10]
    // 0x6c3008: LoadField: r3 = r0->field_7
    //     0x6c3008: ldur            x3, [x0, #7]
    // 0x6c300c: r0 = BoxInt64Instr(r3)
    //     0x6c300c: sbfiz           x0, x3, #1, #0x1f
    //     0x6c3010: cmp             x3, x0, asr #1
    //     0x6c3014: b.eq            #0x6c3020
    //     0x6c3018: bl              #0xd69bb8
    //     0x6c301c: stur            x3, [x0, #7]
    // 0x6c3020: stp             x0, NULL, [SP, #-0x10]!
    // 0x6c3024: r0 = _Double.fromInteger()
    //     0x6c3024: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x6c3028: add             SP, SP, #0x10
    // 0x6c302c: LoadField: d0 = r0->field_7
    //     0x6c302c: ldur            d0, [x0, #7]
    // 0x6c3030: d1 = 1000000.000000
    //     0x6c3030: add             x17, PP, #0xd, lsl #12  ; [pp+0xdbd8] IMM: double(1e+06) from 0x412e848000000000
    //     0x6c3034: ldr             d1, [x17, #0xbd8]
    // 0x6c3038: fdiv            d2, d0, d1
    // 0x6c303c: ldr             x1, [fp, #0x18]
    // 0x6c3040: stur            d2, [fp, #-8]
    // 0x6c3044: LoadField: r0 = r1->field_33
    //     0x6c3044: ldur            w0, [x1, #0x33]
    // 0x6c3048: DecompressPointer r0
    //     0x6c3048: add             x0, x0, HEAP, lsl #32
    // 0x6c304c: cmp             w0, NULL
    // 0x6c3050: b.eq            #0x6c31f8
    // 0x6c3054: r2 = inline_Allocate_Double()
    //     0x6c3054: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x6c3058: add             x2, x2, #0x10
    //     0x6c305c: cmp             x3, x2
    //     0x6c3060: b.ls            #0x6c31fc
    //     0x6c3064: str             x2, [THR, #0x60]  ; THR::top
    //     0x6c3068: sub             x2, x2, #0xf
    //     0x6c306c: mov             x3, #0xd108
    //     0x6c3070: movk            x3, #3, lsl #16
    //     0x6c3074: stur            x3, [x2, #-1]
    // 0x6c3078: StoreField: r2->field_7 = d2
    //     0x6c3078: stur            d2, [x2, #7]
    // 0x6c307c: r3 = LoadClassIdInstr(r0)
    //     0x6c307c: ldur            x3, [x0, #-1]
    //     0x6c3080: ubfx            x3, x3, #0xc, #0x14
    // 0x6c3084: stp             x2, x0, [SP, #-0x10]!
    // 0x6c3088: mov             x0, x3
    // 0x6c308c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x6c308c: sub             lr, x0, #0xffe
    //     0x6c3090: ldr             lr, [x21, lr, lsl #3]
    //     0x6c3094: blr             lr
    // 0x6c3098: add             SP, SP, #0x10
    // 0x6c309c: ldr             x1, [fp, #0x18]
    // 0x6c30a0: LoadField: d1 = r1->field_13
    //     0x6c30a0: ldur            d1, [x1, #0x13]
    // 0x6c30a4: LoadField: d2 = r1->field_1b
    //     0x6c30a4: ldur            d2, [x1, #0x1b]
    // 0x6c30a8: fcmp            d0, d1
    // 0x6c30ac: b.vs            #0x6c30b4
    // 0x6c30b0: b.lt            #0x6c30dc
    // 0x6c30b4: fcmp            d0, d2
    // 0x6c30b8: b.vs            #0x6c30c8
    // 0x6c30bc: b.le            #0x6c30c8
    // 0x6c30c0: mov             v1.16b, v2.16b
    // 0x6c30c4: b               #0x6c30dc
    // 0x6c30c8: fcmp            d0, d0
    // 0x6c30cc: b.vc            #0x6c30d8
    // 0x6c30d0: mov             v1.16b, v2.16b
    // 0x6c30d4: b               #0x6c30dc
    // 0x6c30d8: mov             v1.16b, v0.16b
    // 0x6c30dc: ldur            d0, [fp, #-8]
    // 0x6c30e0: r0 = inline_Allocate_Double()
    //     0x6c30e0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6c30e4: add             x0, x0, #0x10
    //     0x6c30e8: cmp             x2, x0
    //     0x6c30ec: b.ls            #0x6c3218
    //     0x6c30f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6c30f4: sub             x0, x0, #0xf
    //     0x6c30f8: mov             x2, #0xd108
    //     0x6c30fc: movk            x2, #3, lsl #16
    //     0x6c3100: stur            x2, [x0, #-1]
    // 0x6c3104: StoreField: r0->field_7 = d1
    //     0x6c3104: stur            d1, [x0, #7]
    // 0x6c3108: StoreField: r1->field_37 = r0
    //     0x6c3108: stur            w0, [x1, #0x37]
    //     0x6c310c: ldurb           w16, [x1, #-1]
    //     0x6c3110: ldurb           w17, [x0, #-1]
    //     0x6c3114: and             x16, x17, x16, lsr #2
    //     0x6c3118: tst             x16, HEAP, lsr #32
    //     0x6c311c: b.eq            #0x6c3124
    //     0x6c3120: bl              #0xd6826c
    // 0x6c3124: LoadField: r0 = r1->field_33
    //     0x6c3124: ldur            w0, [x1, #0x33]
    // 0x6c3128: DecompressPointer r0
    //     0x6c3128: add             x0, x0, HEAP, lsl #32
    // 0x6c312c: cmp             w0, NULL
    // 0x6c3130: b.eq            #0x6c3230
    // 0x6c3134: r2 = LoadClassIdInstr(r0)
    //     0x6c3134: ldur            x2, [x0, #-1]
    //     0x6c3138: ubfx            x2, x2, #0xc, #0x14
    // 0x6c313c: SaveReg r0
    //     0x6c313c: str             x0, [SP, #-8]!
    // 0x6c3140: SaveReg d0
    //     0x6c3140: str             d0, [SP, #-8]!
    // 0x6c3144: mov             x0, x2
    // 0x6c3148: r0 = GDT[cid_x0 + 0xa14]()
    //     0x6c3148: add             lr, x0, #0xa14
    //     0x6c314c: ldr             lr, [x21, lr, lsl #3]
    //     0x6c3150: blr             lr
    // 0x6c3154: add             SP, SP, #0x10
    // 0x6c3158: tbnz            w0, #4, #0x6c31c0
    // 0x6c315c: ldr             x1, [fp, #0x18]
    // 0x6c3160: LoadField: r0 = r1->field_3f
    //     0x6c3160: ldur            w0, [x1, #0x3f]
    // 0x6c3164: DecompressPointer r0
    //     0x6c3164: add             x0, x0, HEAP, lsl #32
    // 0x6c3168: r16 = Instance__AnimationDirection
    //     0x6c3168: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x6c316c: ldr             x16, [x16, #0xb98]
    // 0x6c3170: cmp             w0, w16
    // 0x6c3174: b.ne            #0x6c3184
    // 0x6c3178: r0 = Instance_AnimationStatus
    //     0x6c3178: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x6c317c: ldr             x0, [x0, #0xba0]
    // 0x6c3180: b               #0x6c318c
    // 0x6c3184: r0 = Instance_AnimationStatus
    //     0x6c3184: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x6c3188: ldr             x0, [x0, #0xba8]
    // 0x6c318c: StoreField: r1->field_43 = r0
    //     0x6c318c: stur            w0, [x1, #0x43]
    //     0x6c3190: ldurb           w16, [x1, #-1]
    //     0x6c3194: ldurb           w17, [x0, #-1]
    //     0x6c3198: and             x16, x17, x16, lsr #2
    //     0x6c319c: tst             x16, HEAP, lsr #32
    //     0x6c31a0: b.eq            #0x6c31a8
    //     0x6c31a4: bl              #0xd6826c
    // 0x6c31a8: r16 = false
    //     0x6c31a8: add             x16, NULL, #0x30  ; false
    // 0x6c31ac: stp             x16, x1, [SP, #-0x10]!
    // 0x6c31b0: r4 = const [0, 0x2, 0x2, 0x1, canceled, 0x1, null]
    //     0x6c31b0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc20] List(7) [0, 0x2, 0x2, 0x1, "canceled", 0x1, Null]
    //     0x6c31b4: ldr             x4, [x4, #0xc20]
    // 0x6c31b8: r0 = stop()
    //     0x6c31b8: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x6c31bc: add             SP, SP, #0x10
    // 0x6c31c0: ldr             x16, [fp, #0x18]
    // 0x6c31c4: SaveReg r16
    //     0x6c31c4: str             x16, [SP, #-8]!
    // 0x6c31c8: r0 = notifyListeners()
    //     0x6c31c8: bl              #0x593248  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x6c31cc: add             SP, SP, #8
    // 0x6c31d0: ldr             x16, [fp, #0x18]
    // 0x6c31d4: SaveReg r16
    //     0x6c31d4: str             x16, [SP, #-8]!
    // 0x6c31d8: r0 = _checkStatusChanged()
    //     0x6c31d8: bl              #0x592f80  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0x6c31dc: add             SP, SP, #8
    // 0x6c31e0: r0 = Null
    //     0x6c31e0: mov             x0, NULL
    // 0x6c31e4: LeaveFrame
    //     0x6c31e4: mov             SP, fp
    //     0x6c31e8: ldp             fp, lr, [SP], #0x10
    // 0x6c31ec: ret
    //     0x6c31ec: ret             
    // 0x6c31f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c31f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c31f4: b               #0x6c2fe0
    // 0x6c31f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6c31f8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6c31fc: SaveReg d2
    //     0x6c31fc: str             q2, [SP, #-0x10]!
    // 0x6c3200: stp             x0, x1, [SP, #-0x10]!
    // 0x6c3204: r0 = AllocateDouble()
    //     0x6c3204: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6c3208: mov             x2, x0
    // 0x6c320c: ldp             x0, x1, [SP], #0x10
    // 0x6c3210: RestoreReg d2
    //     0x6c3210: ldr             q2, [SP], #0x10
    // 0x6c3214: b               #0x6c3078
    // 0x6c3218: stp             q0, q1, [SP, #-0x20]!
    // 0x6c321c: SaveReg r1
    //     0x6c321c: str             x1, [SP, #-8]!
    // 0x6c3220: r0 = AllocateDouble()
    //     0x6c3220: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6c3224: RestoreReg r1
    //     0x6c3224: ldr             x1, [SP], #8
    // 0x6c3228: ldp             q0, q1, [SP], #0x20
    // 0x6c322c: b               #0x6c3104
    // 0x6c3230: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6c3230: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ AnimationController(/* No info */) {
    // ** addr: 0x6ea76c, size: 0x26c
    // 0x6ea76c: EnterFrame
    //     0x6ea76c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea770: mov             fp, SP
    // 0x6ea774: AllocStack(0x18)
    //     0x6ea774: sub             SP, SP, #0x18
    // 0x6ea778: SetupParameters(AnimationController<double> this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic duration = Null /* r5 */, dynamic reverseDuration = Null /* r6 */, dynamic value = Null /* r8, fp-0x8 */})
    //     0x6ea778: mov             x0, x4
    //     0x6ea77c: ldur            w1, [x0, #0x13]
    //     0x6ea780: add             x1, x1, HEAP, lsl #32
    //     0x6ea784: sub             x2, x1, #4
    //     0x6ea788: add             x3, fp, w2, sxtw #2
    //     0x6ea78c: ldr             x3, [x3, #0x18]
    //     0x6ea790: stur            x3, [fp, #-0x18]
    //     0x6ea794: add             x4, fp, w2, sxtw #2
    //     0x6ea798: ldr             x4, [x4, #0x10]
    //     0x6ea79c: stur            x4, [fp, #-0x10]
    //     0x6ea7a0: ldur            w2, [x0, #0x1f]
    //     0x6ea7a4: add             x2, x2, HEAP, lsl #32
    //     0x6ea7a8: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x6ea7ac: ldr             x16, [x16, #0xfd8]
    //     0x6ea7b0: cmp             w2, w16
    //     0x6ea7b4: b.ne            #0x6ea7d8
    //     0x6ea7b8: ldur            w2, [x0, #0x23]
    //     0x6ea7bc: add             x2, x2, HEAP, lsl #32
    //     0x6ea7c0: sub             w5, w1, w2
    //     0x6ea7c4: add             x2, fp, w5, sxtw #2
    //     0x6ea7c8: ldr             x2, [x2, #8]
    //     0x6ea7cc: mov             x5, x2
    //     0x6ea7d0: mov             x2, #1
    //     0x6ea7d4: b               #0x6ea7e0
    //     0x6ea7d8: mov             x5, NULL
    //     0x6ea7dc: mov             x2, #0
    //     0x6ea7e0: lsl             x6, x2, #1
    //     0x6ea7e4: lsl             w7, w6, #1
    //     0x6ea7e8: add             w8, w7, #8
    //     0x6ea7ec: add             x16, x0, w8, sxtw #1
    //     0x6ea7f0: ldur            w9, [x16, #0xf]
    //     0x6ea7f4: add             x9, x9, HEAP, lsl #32
    //     0x6ea7f8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d0a8] "reverseDuration"
    //     0x6ea7fc: ldr             x16, [x16, #0xa8]
    //     0x6ea800: cmp             w9, w16
    //     0x6ea804: b.ne            #0x6ea838
    //     0x6ea808: add             w2, w7, #0xa
    //     0x6ea80c: add             x16, x0, w2, sxtw #1
    //     0x6ea810: ldur            w7, [x16, #0xf]
    //     0x6ea814: add             x7, x7, HEAP, lsl #32
    //     0x6ea818: sub             w2, w1, w7
    //     0x6ea81c: add             x7, fp, w2, sxtw #2
    //     0x6ea820: ldr             x7, [x7, #8]
    //     0x6ea824: add             w2, w6, #2
    //     0x6ea828: sbfx            x6, x2, #1, #0x1f
    //     0x6ea82c: mov             x2, x6
    //     0x6ea830: mov             x6, x7
    //     0x6ea834: b               #0x6ea83c
    //     0x6ea838: mov             x6, NULL
    //     0x6ea83c: lsl             x7, x2, #1
    //     0x6ea840: lsl             w2, w7, #1
    //     0x6ea844: add             w7, w2, #8
    //     0x6ea848: add             x16, x0, w7, sxtw #1
    //     0x6ea84c: ldur            w8, [x16, #0xf]
    //     0x6ea850: add             x8, x8, HEAP, lsl #32
    //     0x6ea854: ldr             x16, [PP, #0x408]  ; [pp+0x408] "value"
    //     0x6ea858: cmp             w8, w16
    //     0x6ea85c: b.ne            #0x6ea884
    //     0x6ea860: add             w7, w2, #0xa
    //     0x6ea864: add             x16, x0, w7, sxtw #1
    //     0x6ea868: ldur            w2, [x16, #0xf]
    //     0x6ea86c: add             x2, x2, HEAP, lsl #32
    //     0x6ea870: sub             w0, w1, w2
    //     0x6ea874: add             x1, fp, w0, sxtw #2
    //     0x6ea878: ldr             x1, [x1, #8]
    //     0x6ea87c: mov             x8, x1
    //     0x6ea880: b               #0x6ea888
    //     0x6ea884: mov             x8, NULL
    //     0x6ea888: ldr             x7, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6ea88c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x6ea890: ldr             x0, [x0, #0xba8]
    //     0x6ea894: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d0b0] Obj!AnimationBehavior@b65e91
    //     0x6ea898: ldr             x2, [x2, #0xb0]
    //     0x6ea89c: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x6ea8a0: ldr             x1, [x1, #0xb98]
    //     0x6ea8a4: eor             v1.16b, v1.16b, v1.16b
    //     0x6ea8a8: fmov            d0, #1.00000000
    //     0x6ea8ac: stur            x8, [fp, #-8]
    // 0x6ea888: r7 = Sentinel
    // 0x6ea88c: r0 = Instance_AnimationStatus
    // 0x6ea894: r2 = Instance_AnimationBehavior
    // 0x6ea89c: r1 = Instance__AnimationDirection
    // 0x6ea8a4: d1 = 0.000000
    // 0x6ea8a8: d0 = 1.000000
    // 0x6ea8b0: CheckStackOverflow
    //     0x6ea8b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea8b4: cmp             SP, x16
    //     0x6ea8b8: b.ls            #0x6ea9d0
    // 0x6ea8bc: StoreField: r3->field_37 = r7
    //     0x6ea8bc: stur            w7, [x3, #0x37]
    // 0x6ea8c0: StoreField: r3->field_43 = r7
    //     0x6ea8c0: stur            w7, [x3, #0x43]
    // 0x6ea8c4: StoreField: r3->field_47 = r0
    //     0x6ea8c4: stur            w0, [x3, #0x47]
    // 0x6ea8c8: mov             x0, x5
    // 0x6ea8cc: StoreField: r3->field_27 = r0
    //     0x6ea8cc: stur            w0, [x3, #0x27]
    //     0x6ea8d0: ldurb           w16, [x3, #-1]
    //     0x6ea8d4: ldurb           w17, [x0, #-1]
    //     0x6ea8d8: and             x16, x17, x16, lsr #2
    //     0x6ea8dc: tst             x16, HEAP, lsr #32
    //     0x6ea8e0: b.eq            #0x6ea8e8
    //     0x6ea8e4: bl              #0xd682ac
    // 0x6ea8e8: mov             x0, x6
    // 0x6ea8ec: StoreField: r3->field_2b = r0
    //     0x6ea8ec: stur            w0, [x3, #0x2b]
    //     0x6ea8f0: ldurb           w16, [x3, #-1]
    //     0x6ea8f4: ldurb           w17, [x0, #-1]
    //     0x6ea8f8: and             x16, x17, x16, lsr #2
    //     0x6ea8fc: tst             x16, HEAP, lsr #32
    //     0x6ea900: b.eq            #0x6ea908
    //     0x6ea904: bl              #0xd682ac
    // 0x6ea908: StoreField: r3->field_13 = d1
    //     0x6ea908: stur            d1, [x3, #0x13]
    // 0x6ea90c: StoreField: r3->field_1b = d0
    //     0x6ea90c: stur            d0, [x3, #0x1b]
    // 0x6ea910: StoreField: r3->field_23 = r2
    //     0x6ea910: stur            w2, [x3, #0x23]
    // 0x6ea914: StoreField: r3->field_3f = r1
    //     0x6ea914: stur            w1, [x3, #0x3f]
    // 0x6ea918: SaveReg r3
    //     0x6ea918: str             x3, [SP, #-8]!
    // 0x6ea91c: r0 = _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin()
    //     0x6ea91c: bl              #0x6ea9d8  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::_AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin
    // 0x6ea920: add             SP, SP, #8
    // 0x6ea924: ldur            x1, [fp, #-0x18]
    // 0x6ea928: r0 = 59
    //     0x6ea928: mov             x0, #0x3b
    // 0x6ea92c: branchIfSmi(r1, 0x6ea938)
    //     0x6ea92c: tbz             w1, #0, #0x6ea938
    // 0x6ea930: r0 = LoadClassIdInstr(r1)
    //     0x6ea930: ldur            x0, [x1, #-1]
    //     0x6ea934: ubfx            x0, x0, #0xc, #0x14
    // 0x6ea938: SaveReg r1
    //     0x6ea938: str             x1, [SP, #-8]!
    // 0x6ea93c: r0 = GDT[cid_x0 + -0xff4]()
    //     0x6ea93c: sub             lr, x0, #0xff4
    //     0x6ea940: ldr             lr, [x21, lr, lsl #3]
    //     0x6ea944: blr             lr
    // 0x6ea948: add             SP, SP, #8
    // 0x6ea94c: mov             x1, x0
    // 0x6ea950: ldur            x0, [fp, #-0x10]
    // 0x6ea954: r2 = LoadClassIdInstr(r0)
    //     0x6ea954: ldur            x2, [x0, #-1]
    //     0x6ea958: ubfx            x2, x2, #0xc, #0x14
    // 0x6ea95c: stp             x1, x0, [SP, #-0x10]!
    // 0x6ea960: mov             x0, x2
    // 0x6ea964: r0 = GDT[cid_x0 + 0xf44b]()
    //     0x6ea964: mov             x17, #0xf44b
    //     0x6ea968: add             lr, x0, x17
    //     0x6ea96c: ldr             lr, [x21, lr, lsl #3]
    //     0x6ea970: blr             lr
    // 0x6ea974: add             SP, SP, #0x10
    // 0x6ea978: ldur            x1, [fp, #-0x18]
    // 0x6ea97c: StoreField: r1->field_2f = r0
    //     0x6ea97c: stur            w0, [x1, #0x2f]
    //     0x6ea980: ldurb           w16, [x1, #-1]
    //     0x6ea984: ldurb           w17, [x0, #-1]
    //     0x6ea988: and             x16, x17, x16, lsr #2
    //     0x6ea98c: tst             x16, HEAP, lsr #32
    //     0x6ea990: b.eq            #0x6ea998
    //     0x6ea994: bl              #0xd6826c
    // 0x6ea998: ldur            x0, [fp, #-8]
    // 0x6ea99c: cmp             w0, NULL
    // 0x6ea9a0: b.ne            #0x6ea9ac
    // 0x6ea9a4: d0 = 0.000000
    //     0x6ea9a4: eor             v0.16b, v0.16b, v0.16b
    // 0x6ea9a8: b               #0x6ea9b0
    // 0x6ea9ac: LoadField: d0 = r0->field_7
    //     0x6ea9ac: ldur            d0, [x0, #7]
    // 0x6ea9b0: SaveReg r1
    //     0x6ea9b0: str             x1, [SP, #-8]!
    // 0x6ea9b4: SaveReg d0
    //     0x6ea9b4: str             d0, [SP, #-8]!
    // 0x6ea9b8: r0 = _internalSetValue()
    //     0x6ea9b8: bl              #0x593850  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_internalSetValue
    // 0x6ea9bc: add             SP, SP, #0x10
    // 0x6ea9c0: r0 = Null
    //     0x6ea9c0: mov             x0, NULL
    // 0x6ea9c4: LeaveFrame
    //     0x6ea9c4: mov             SP, fp
    //     0x6ea9c8: ldp             fp, lr, [SP], #0x10
    // 0x6ea9cc: ret
    //     0x6ea9cc: ret             
    // 0x6ea9d0: r0 = StackOverflowSharedWithFPURegs()
    //     0x6ea9d0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6ea9d4: b               #0x6ea8bc
  }
  _ dispose(/* No info */) {
    // ** addr: 0x7013ac, size: 0x100
    // 0x7013ac: EnterFrame
    //     0x7013ac: stp             fp, lr, [SP, #-0x10]!
    //     0x7013b0: mov             fp, SP
    // 0x7013b4: AllocStack(0x10)
    //     0x7013b4: sub             SP, SP, #0x10
    // 0x7013b8: CheckStackOverflow
    //     0x7013b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7013bc: cmp             SP, x16
    //     0x7013c0: b.ls            #0x7014a0
    // 0x7013c4: ldr             x0, [fp, #0x10]
    // 0x7013c8: LoadField: r1 = r0->field_2f
    //     0x7013c8: ldur            w1, [x0, #0x2f]
    // 0x7013cc: DecompressPointer r1
    //     0x7013cc: add             x1, x1, HEAP, lsl #32
    // 0x7013d0: stur            x1, [fp, #-0x10]
    // 0x7013d4: cmp             w1, NULL
    // 0x7013d8: b.eq            #0x7014a8
    // 0x7013dc: r2 = LoadClassIdInstr(r1)
    //     0x7013dc: ldur            x2, [x1, #-1]
    //     0x7013e0: ubfx            x2, x2, #0xc, #0x14
    // 0x7013e4: lsl             x2, x2, #1
    // 0x7013e8: cmp             w2, #0xf6c
    // 0x7013ec: b.ne            #0x70142c
    // 0x7013f0: LoadField: r2 = r1->field_7
    //     0x7013f0: ldur            w2, [x1, #7]
    // 0x7013f4: DecompressPointer r2
    //     0x7013f4: add             x2, x2, HEAP, lsl #32
    // 0x7013f8: stur            x2, [fp, #-8]
    // 0x7013fc: cmp             w2, NULL
    // 0x701400: b.eq            #0x70146c
    // 0x701404: StoreField: r1->field_7 = rNULL
    //     0x701404: stur            NULL, [x1, #7]
    // 0x701408: SaveReg r1
    //     0x701408: str             x1, [SP, #-8]!
    // 0x70140c: r0 = unscheduleTick()
    //     0x70140c: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x701410: add             SP, SP, #8
    // 0x701414: ldur            x16, [fp, #-8]
    // 0x701418: ldur            lr, [fp, #-0x10]
    // 0x70141c: stp             lr, x16, [SP, #-0x10]!
    // 0x701420: r0 = _cancel()
    //     0x701420: bl              #0x593604  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::_cancel
    // 0x701424: add             SP, SP, #0x10
    // 0x701428: b               #0x70146c
    // 0x70142c: LoadField: r0 = r1->field_1b
    //     0x70142c: ldur            w0, [x1, #0x1b]
    // 0x701430: DecompressPointer r0
    //     0x701430: add             x0, x0, HEAP, lsl #32
    // 0x701434: r2 = LoadClassIdInstr(r0)
    //     0x701434: ldur            x2, [x0, #-1]
    //     0x701438: ubfx            x2, x2, #0xc, #0x14
    // 0x70143c: stp             x1, x0, [SP, #-0x10]!
    // 0x701440: mov             x0, x2
    // 0x701444: r0 = GDT[cid_x0 + 0x10224]()
    //     0x701444: mov             x17, #0x224
    //     0x701448: movk            x17, #1, lsl #16
    //     0x70144c: add             lr, x0, x17
    //     0x701450: ldr             lr, [x21, lr, lsl #3]
    //     0x701454: blr             lr
    // 0x701458: add             SP, SP, #0x10
    // 0x70145c: ldur            x16, [fp, #-0x10]
    // 0x701460: SaveReg r16
    //     0x701460: str             x16, [SP, #-8]!
    // 0x701464: r0 = dispose()
    //     0x701464: bl              #0xd04324  ; [package:flutter/src/scheduler/ticker.dart] Ticker::dispose
    // 0x701468: add             SP, SP, #8
    // 0x70146c: ldr             x0, [fp, #0x10]
    // 0x701470: StoreField: r0->field_2f = rNULL
    //     0x701470: stur            NULL, [x0, #0x2f]
    // 0x701474: SaveReg r0
    //     0x701474: str             x0, [SP, #-8]!
    // 0x701478: r0 = clearStatusListeners()
    //     0x701478: bl              #0x70156c  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::clearStatusListeners
    // 0x70147c: add             SP, SP, #8
    // 0x701480: ldr             x16, [fp, #0x10]
    // 0x701484: SaveReg r16
    //     0x701484: str             x16, [SP, #-8]!
    // 0x701488: r0 = clearListeners()
    //     0x701488: bl              #0x7014ac  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::clearListeners
    // 0x70148c: add             SP, SP, #8
    // 0x701490: r0 = Null
    //     0x701490: mov             x0, NULL
    // 0x701494: LeaveFrame
    //     0x701494: mov             SP, fp
    //     0x701498: ldp             fp, lr, [SP], #0x10
    // 0x70149c: ret
    //     0x70149c: ret             
    // 0x7014a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7014a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7014a4: b               #0x7013c4
    // 0x7014a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7014a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ reset(/* No info */) {
    // ** addr: 0x7974f0, size: 0x44
    // 0x7974f0: EnterFrame
    //     0x7974f0: stp             fp, lr, [SP, #-0x10]!
    //     0x7974f4: mov             fp, SP
    // 0x7974f8: CheckStackOverflow
    //     0x7974f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7974fc: cmp             SP, x16
    //     0x797500: b.ls            #0x79752c
    // 0x797504: ldr             x0, [fp, #0x10]
    // 0x797508: LoadField: d0 = r0->field_13
    //     0x797508: ldur            d0, [x0, #0x13]
    // 0x79750c: SaveReg r0
    //     0x79750c: str             x0, [SP, #-8]!
    // 0x797510: SaveReg d0
    //     0x797510: str             d0, [SP, #-8]!
    // 0x797514: r0 = value=()
    //     0x797514: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x797518: add             SP, SP, #0x10
    // 0x79751c: r0 = Null
    //     0x79751c: mov             x0, NULL
    // 0x797520: LeaveFrame
    //     0x797520: mov             SP, fp
    //     0x797524: ldp             fp, lr, [SP], #0x10
    // 0x797528: ret
    //     0x797528: ret             
    // 0x79752c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79752c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x797530: b               #0x797504
  }
  _ animateTo(/* No info */) {
    // ** addr: 0x7a8100, size: 0x100
    // 0x7a8100: EnterFrame
    //     0x7a8100: stp             fp, lr, [SP, #-0x10]!
    //     0x7a8104: mov             fp, SP
    // 0x7a8108: mov             x0, x4
    // 0x7a810c: LoadField: r1 = r0->field_13
    //     0x7a810c: ldur            w1, [x0, #0x13]
    // 0x7a8110: DecompressPointer r1
    //     0x7a8110: add             x1, x1, HEAP, lsl #32
    // 0x7a8114: sub             x2, x1, #4
    // 0x7a8118: add             x3, fp, w2, sxtw #2
    // 0x7a811c: ldr             x3, [x3, #0x18]
    // 0x7a8120: add             x4, fp, w2, sxtw #2
    // 0x7a8124: ldr             d0, [x4, #0x10]
    // 0x7a8128: LoadField: r2 = r0->field_1f
    //     0x7a8128: ldur            w2, [x0, #0x1f]
    // 0x7a812c: DecompressPointer r2
    //     0x7a812c: add             x2, x2, HEAP, lsl #32
    // 0x7a8130: r16 = "curve"
    //     0x7a8130: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc0] "curve"
    //     0x7a8134: ldr             x16, [x16, #0xfc0]
    // 0x7a8138: cmp             w2, w16
    // 0x7a813c: b.ne            #0x7a8160
    // 0x7a8140: LoadField: r2 = r0->field_23
    //     0x7a8140: ldur            w2, [x0, #0x23]
    // 0x7a8144: DecompressPointer r2
    //     0x7a8144: add             x2, x2, HEAP, lsl #32
    // 0x7a8148: sub             w4, w1, w2
    // 0x7a814c: add             x2, fp, w4, sxtw #2
    // 0x7a8150: ldr             x2, [x2, #8]
    // 0x7a8154: mov             x4, x2
    // 0x7a8158: r2 = 1
    //     0x7a8158: mov             x2, #1
    // 0x7a815c: b               #0x7a816c
    // 0x7a8160: r4 = Instance__Linear
    //     0x7a8160: add             x4, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x7a8164: ldr             x4, [x4, #0x300]
    // 0x7a8168: r2 = 0
    //     0x7a8168: mov             x2, #0
    // 0x7a816c: lsl             x5, x2, #1
    // 0x7a8170: lsl             w2, w5, #1
    // 0x7a8174: add             w5, w2, #8
    // 0x7a8178: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0x7a8178: add             x16, x0, w5, sxtw #1
    //     0x7a817c: ldur            w6, [x16, #0xf]
    // 0x7a8180: DecompressPointer r6
    //     0x7a8180: add             x6, x6, HEAP, lsl #32
    // 0x7a8184: r16 = "duration"
    //     0x7a8184: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x7a8188: ldr             x16, [x16, #0xfd8]
    // 0x7a818c: cmp             w6, w16
    // 0x7a8190: b.ne            #0x7a81b4
    // 0x7a8194: add             w5, w2, #0xa
    // 0x7a8198: ArrayLoad: r2 = r0[r5]  ; Unknown_4
    //     0x7a8198: add             x16, x0, w5, sxtw #1
    //     0x7a819c: ldur            w2, [x16, #0xf]
    // 0x7a81a0: DecompressPointer r2
    //     0x7a81a0: add             x2, x2, HEAP, lsl #32
    // 0x7a81a4: sub             w0, w1, w2
    // 0x7a81a8: add             x1, fp, w0, sxtw #2
    // 0x7a81ac: ldr             x1, [x1, #8]
    // 0x7a81b0: b               #0x7a81b8
    // 0x7a81b4: r1 = Null
    //     0x7a81b4: mov             x1, NULL
    // 0x7a81b8: r0 = Instance__AnimationDirection
    //     0x7a81b8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x7a81bc: ldr             x0, [x0, #0xb98]
    // 0x7a81c0: CheckStackOverflow
    //     0x7a81c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a81c4: cmp             SP, x16
    //     0x7a81c8: b.ls            #0x7a81f8
    // 0x7a81cc: StoreField: r3->field_3f = r0
    //     0x7a81cc: stur            w0, [x3, #0x3f]
    // 0x7a81d0: SaveReg r3
    //     0x7a81d0: str             x3, [SP, #-8]!
    // 0x7a81d4: SaveReg d0
    //     0x7a81d4: str             d0, [SP, #-8]!
    // 0x7a81d8: stp             x4, x1, [SP, #-0x10]!
    // 0x7a81dc: r4 = const [0, 0x4, 0x4, 0x2, curve, 0x3, duration, 0x2, null]
    //     0x7a81dc: add             x4, PP, #0x27, lsl #12  ; [pp+0x272a0] List(9) [0, 0x4, 0x4, 0x2, "curve", 0x3, "duration", 0x2, Null]
    //     0x7a81e0: ldr             x4, [x4, #0x2a0]
    // 0x7a81e4: r0 = _animateToInternal()
    //     0x7a81e4: bl              #0x591390  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_animateToInternal
    // 0x7a81e8: add             SP, SP, #0x20
    // 0x7a81ec: LeaveFrame
    //     0x7a81ec: mov             SP, fp
    //     0x7a81f0: ldp             fp, lr, [SP], #0x10
    // 0x7a81f4: ret
    //     0x7a81f4: ret             
    // 0x7a81f8: r0 = StackOverflowSharedWithFPURegs()
    //     0x7a81f8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x7a81fc: b               #0x7a81cc
  }
  _ repeat(/* No info */) {
    // ** addr: 0x7b8ecc, size: 0x288
    // 0x7b8ecc: EnterFrame
    //     0x7b8ecc: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8ed0: mov             fp, SP
    // 0x7b8ed4: AllocStack(0x48)
    //     0x7b8ed4: sub             SP, SP, #0x48
    // 0x7b8ed8: SetupParameters(AnimationController<double> this /* r3, fp-0x18 */, {dynamic max, dynamic min, dynamic period = Null /* r4 */, dynamic reverse = false /* r0, fp-0x10 */})
    //     0x7b8ed8: mov             x0, x4
    //     0x7b8edc: ldur            w1, [x0, #0x13]
    //     0x7b8ee0: add             x1, x1, HEAP, lsl #32
    //     0x7b8ee4: sub             x2, x1, #2
    //     0x7b8ee8: add             x3, fp, w2, sxtw #2
    //     0x7b8eec: ldr             x3, [x3, #0x10]
    //     0x7b8ef0: stur            x3, [fp, #-0x18]
    //     0x7b8ef4: ldur            w2, [x0, #0x1f]
    //     0x7b8ef8: add             x2, x2, HEAP, lsl #32
    //     0x7b8efc: add             x16, PP, #0x14, lsl #12  ; [pp+0x148e0] "max"
    //     0x7b8f00: ldr             x16, [x16, #0x8e0]
    //     0x7b8f04: cmp             w2, w16
    //     0x7b8f08: b.ne            #0x7b8f14
    //     0x7b8f0c: mov             x2, #1
    //     0x7b8f10: b               #0x7b8f18
    //     0x7b8f14: mov             x2, #0
    //     0x7b8f18: lsl             x4, x2, #1
    //     0x7b8f1c: lsl             w5, w4, #1
    //     0x7b8f20: add             w6, w5, #8
    //     0x7b8f24: add             x16, x0, w6, sxtw #1
    //     0x7b8f28: ldur            w5, [x16, #0xf]
    //     0x7b8f2c: add             x5, x5, HEAP, lsl #32
    //     0x7b8f30: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d080] "min"
    //     0x7b8f34: ldr             x16, [x16, #0x80]
    //     0x7b8f38: cmp             w5, w16
    //     0x7b8f3c: b.ne            #0x7b8f4c
    //     0x7b8f40: add             w2, w4, #2
    //     0x7b8f44: sbfx            x4, x2, #1, #0x1f
    //     0x7b8f48: mov             x2, x4
    //     0x7b8f4c: lsl             x4, x2, #1
    //     0x7b8f50: lsl             w5, w4, #1
    //     0x7b8f54: add             w6, w5, #8
    //     0x7b8f58: add             x16, x0, w6, sxtw #1
    //     0x7b8f5c: ldur            w7, [x16, #0xf]
    //     0x7b8f60: add             x7, x7, HEAP, lsl #32
    //     0x7b8f64: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d088] "period"
    //     0x7b8f68: ldr             x16, [x16, #0x88]
    //     0x7b8f6c: cmp             w7, w16
    //     0x7b8f70: b.ne            #0x7b8fa4
    //     0x7b8f74: add             w2, w5, #0xa
    //     0x7b8f78: add             x16, x0, w2, sxtw #1
    //     0x7b8f7c: ldur            w5, [x16, #0xf]
    //     0x7b8f80: add             x5, x5, HEAP, lsl #32
    //     0x7b8f84: sub             w2, w1, w5
    //     0x7b8f88: add             x5, fp, w2, sxtw #2
    //     0x7b8f8c: ldr             x5, [x5, #8]
    //     0x7b8f90: add             w2, w4, #2
    //     0x7b8f94: sbfx            x4, x2, #1, #0x1f
    //     0x7b8f98: mov             x2, x4
    //     0x7b8f9c: mov             x4, x5
    //     0x7b8fa0: b               #0x7b8fa8
    //     0x7b8fa4: mov             x4, NULL
    //     0x7b8fa8: lsl             x5, x2, #1
    //     0x7b8fac: lsl             w2, w5, #1
    //     0x7b8fb0: add             w5, w2, #8
    //     0x7b8fb4: add             x16, x0, w5, sxtw #1
    //     0x7b8fb8: ldur            w6, [x16, #0xf]
    //     0x7b8fbc: add             x6, x6, HEAP, lsl #32
    //     0x7b8fc0: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d090] "reverse"
    //     0x7b8fc4: ldr             x16, [x16, #0x90]
    //     0x7b8fc8: cmp             w6, w16
    //     0x7b8fcc: b.ne            #0x7b8ff4
    //     0x7b8fd0: add             w5, w2, #0xa
    //     0x7b8fd4: add             x16, x0, w5, sxtw #1
    //     0x7b8fd8: ldur            w2, [x16, #0xf]
    //     0x7b8fdc: add             x2, x2, HEAP, lsl #32
    //     0x7b8fe0: sub             w0, w1, w2
    //     0x7b8fe4: add             x1, fp, w0, sxtw #2
    //     0x7b8fe8: ldr             x1, [x1, #8]
    //     0x7b8fec: mov             x0, x1
    //     0x7b8ff0: b               #0x7b8ff8
    //     0x7b8ff4: add             x0, NULL, #0x30  ; false
    //     0x7b8ff8: stur            x0, [fp, #-0x10]
    // 0x7b8ffc: CheckStackOverflow
    //     0x7b8ffc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b9000: cmp             SP, x16
    //     0x7b9004: b.ls            #0x7b9120
    // 0x7b9008: LoadField: d0 = r3->field_13
    //     0x7b9008: ldur            d0, [x3, #0x13]
    // 0x7b900c: stur            d0, [fp, #-0x48]
    // 0x7b9010: LoadField: d1 = r3->field_1b
    //     0x7b9010: ldur            d1, [x3, #0x1b]
    // 0x7b9014: stur            d1, [fp, #-0x40]
    // 0x7b9018: cmp             w4, NULL
    // 0x7b901c: b.ne            #0x7b902c
    // 0x7b9020: LoadField: r1 = r3->field_27
    //     0x7b9020: ldur            w1, [x3, #0x27]
    // 0x7b9024: DecompressPointer r1
    //     0x7b9024: add             x1, x1, HEAP, lsl #32
    // 0x7b9028: b               #0x7b9030
    // 0x7b902c: mov             x1, x4
    // 0x7b9030: stur            x1, [fp, #-8]
    // 0x7b9034: SaveReg r3
    //     0x7b9034: str             x3, [SP, #-8]!
    // 0x7b9038: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b9038: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b903c: r0 = stop()
    //     0x7b903c: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x7b9040: add             SP, SP, #8
    // 0x7b9044: ldur            x1, [fp, #-0x18]
    // 0x7b9048: LoadField: r2 = r1->field_37
    //     0x7b9048: ldur            w2, [x1, #0x37]
    // 0x7b904c: DecompressPointer r2
    //     0x7b904c: add             x2, x2, HEAP, lsl #32
    // 0x7b9050: r16 = Sentinel
    //     0x7b9050: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b9054: cmp             w2, w16
    // 0x7b9058: b.eq            #0x7b9128
    // 0x7b905c: ldur            x3, [fp, #-8]
    // 0x7b9060: stur            x2, [fp, #-0x20]
    // 0x7b9064: cmp             w3, NULL
    // 0x7b9068: b.eq            #0x7b9134
    // 0x7b906c: r0 = 59
    //     0x7b906c: mov             x0, #0x3b
    // 0x7b9070: branchIfSmi(r1, 0x7b907c)
    //     0x7b9070: tbz             w1, #0, #0x7b907c
    // 0x7b9074: r0 = LoadClassIdInstr(r1)
    //     0x7b9074: ldur            x0, [x1, #-1]
    //     0x7b9078: ubfx            x0, x0, #0xc, #0x14
    // 0x7b907c: SaveReg r1
    //     0x7b907c: str             x1, [SP, #-8]!
    // 0x7b9080: r0 = GDT[cid_x0 + -0xfdf]()
    //     0x7b9080: sub             lr, x0, #0xfdf
    //     0x7b9084: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9088: blr             lr
    // 0x7b908c: add             SP, SP, #8
    // 0x7b9090: ldur            d0, [fp, #-0x48]
    // 0x7b9094: stur            x0, [fp, #-0x30]
    // 0x7b9098: r1 = inline_Allocate_Double()
    //     0x7b9098: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x7b909c: add             x1, x1, #0x10
    //     0x7b90a0: cmp             x2, x1
    //     0x7b90a4: b.ls            #0x7b9138
    //     0x7b90a8: str             x1, [THR, #0x60]  ; THR::top
    //     0x7b90ac: sub             x1, x1, #0xf
    //     0x7b90b0: mov             x2, #0xd108
    //     0x7b90b4: movk            x2, #3, lsl #16
    //     0x7b90b8: stur            x2, [x1, #-1]
    // 0x7b90bc: StoreField: r1->field_7 = d0
    //     0x7b90bc: stur            d0, [x1, #7]
    // 0x7b90c0: stur            x1, [fp, #-0x28]
    // 0x7b90c4: r0 = _RepeatingSimulation()
    //     0x7b90c4: bl              #0x7b91f8  ; Allocate_RepeatingSimulationStub -> _RepeatingSimulation (size=0x34)
    // 0x7b90c8: stur            x0, [fp, #-0x38]
    // 0x7b90cc: ldur            x16, [fp, #-0x20]
    // 0x7b90d0: stp             x16, x0, [SP, #-0x10]!
    // 0x7b90d4: ldur            x16, [fp, #-0x28]
    // 0x7b90d8: SaveReg r16
    //     0x7b90d8: str             x16, [SP, #-8]!
    // 0x7b90dc: ldur            d0, [fp, #-0x40]
    // 0x7b90e0: SaveReg d0
    //     0x7b90e0: str             d0, [SP, #-8]!
    // 0x7b90e4: ldur            x16, [fp, #-0x10]
    // 0x7b90e8: ldur            lr, [fp, #-8]
    // 0x7b90ec: stp             lr, x16, [SP, #-0x10]!
    // 0x7b90f0: ldur            x16, [fp, #-0x30]
    // 0x7b90f4: SaveReg r16
    //     0x7b90f4: str             x16, [SP, #-8]!
    // 0x7b90f8: r0 = _RepeatingSimulation()
    //     0x7b90f8: bl              #0x7b9154  ; [package:flutter/src/animation/animation_controller.dart] _RepeatingSimulation::_RepeatingSimulation
    // 0x7b90fc: add             SP, SP, #0x38
    // 0x7b9100: ldur            x16, [fp, #-0x18]
    // 0x7b9104: ldur            lr, [fp, #-0x38]
    // 0x7b9108: stp             lr, x16, [SP, #-0x10]!
    // 0x7b910c: r0 = _startSimulation()
    //     0x7b910c: bl              #0x5918a4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0x7b9110: add             SP, SP, #0x10
    // 0x7b9114: LeaveFrame
    //     0x7b9114: mov             SP, fp
    //     0x7b9118: ldp             fp, lr, [SP], #0x10
    // 0x7b911c: ret
    //     0x7b911c: ret             
    // 0x7b9120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b9120: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b9124: b               #0x7b9008
    // 0x7b9128: r9 = _value
    //     0x7b9128: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x7b912c: ldr             x9, [x9, #0xbb0]
    // 0x7b9130: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b9130: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b9134: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b9134: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b9138: SaveReg d0
    //     0x7b9138: str             q0, [SP, #-0x10]!
    // 0x7b913c: SaveReg r0
    //     0x7b913c: str             x0, [SP, #-8]!
    // 0x7b9140: r0 = AllocateDouble()
    //     0x7b9140: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7b9144: mov             x1, x0
    // 0x7b9148: RestoreReg r0
    //     0x7b9148: ldr             x0, [SP], #8
    // 0x7b914c: RestoreReg d0
    //     0x7b914c: ldr             q0, [SP], #0x10
    // 0x7b9150: b               #0x7b90bc
  }
  get _ isAnimating(/* No info */) {
    // ** addr: 0x7b937c, size: 0x3c
    // 0x7b937c: ldr             x1, [SP]
    // 0x7b9380: LoadField: r2 = r1->field_2f
    //     0x7b9380: ldur            w2, [x1, #0x2f]
    // 0x7b9384: DecompressPointer r2
    //     0x7b9384: add             x2, x2, HEAP, lsl #32
    // 0x7b9388: cmp             w2, NULL
    // 0x7b938c: b.eq            #0x7b93b0
    // 0x7b9390: LoadField: r1 = r2->field_7
    //     0x7b9390: ldur            w1, [x2, #7]
    // 0x7b9394: DecompressPointer r1
    //     0x7b9394: add             x1, x1, HEAP, lsl #32
    // 0x7b9398: cmp             w1, NULL
    // 0x7b939c: r16 = true
    //     0x7b939c: add             x16, NULL, #0x20  ; true
    // 0x7b93a0: r17 = false
    //     0x7b93a0: add             x17, NULL, #0x30  ; false
    // 0x7b93a4: csel            x2, x16, x17, ne
    // 0x7b93a8: mov             x0, x2
    // 0x7b93ac: b               #0x7b93b4
    // 0x7b93b0: r0 = false
    //     0x7b93b0: add             x0, NULL, #0x30  ; false
    // 0x7b93b4: ret
    //     0x7b93b4: ret             
  }
  _ animateWith(/* No info */) {
    // ** addr: 0x7c723c, size: 0x5c
    // 0x7c723c: EnterFrame
    //     0x7c723c: stp             fp, lr, [SP, #-0x10]!
    //     0x7c7240: mov             fp, SP
    // 0x7c7244: CheckStackOverflow
    //     0x7c7244: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7c7248: cmp             SP, x16
    //     0x7c724c: b.ls            #0x7c7290
    // 0x7c7250: ldr             x16, [fp, #0x18]
    // 0x7c7254: SaveReg r16
    //     0x7c7254: str             x16, [SP, #-8]!
    // 0x7c7258: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7c7258: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7c725c: r0 = stop()
    //     0x7c725c: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x7c7260: add             SP, SP, #8
    // 0x7c7264: ldr             x1, [fp, #0x18]
    // 0x7c7268: r0 = Instance__AnimationDirection
    //     0x7c7268: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x7c726c: ldr             x0, [x0, #0xb98]
    // 0x7c7270: StoreField: r1->field_3f = r0
    //     0x7c7270: stur            w0, [x1, #0x3f]
    // 0x7c7274: ldr             x16, [fp, #0x10]
    // 0x7c7278: stp             x16, x1, [SP, #-0x10]!
    // 0x7c727c: r0 = _startSimulation()
    //     0x7c727c: bl              #0x5918a4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0x7c7280: add             SP, SP, #0x10
    // 0x7c7284: LeaveFrame
    //     0x7c7284: mov             SP, fp
    //     0x7c7288: ldp             fp, lr, [SP], #0x10
    // 0x7c728c: ret
    //     0x7c728c: ret             
    // 0x7c7290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7c7290: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7c7294: b               #0x7c7250
  }
  _ fling(/* No info */) {
    // ** addr: 0x82d318, size: 0x2d4
    // 0x82d318: EnterFrame
    //     0x82d318: stp             fp, lr, [SP, #-0x10]!
    //     0x82d31c: mov             fp, SP
    // 0x82d320: AllocStack(0x38)
    //     0x82d320: sub             SP, SP, #0x38
    // 0x82d324: SetupParameters(AnimationController<double> this /* r3, fp-0x8 */, {dynamic springDescription, _Double velocity = 1.000000 /* d0, fp-0x30 */})
    //     0x82d324: mov             x0, x4
    //     0x82d328: ldur            w1, [x0, #0x13]
    //     0x82d32c: add             x1, x1, HEAP, lsl #32
    //     0x82d330: sub             x2, x1, #2
    //     0x82d334: add             x3, fp, w2, sxtw #2
    //     0x82d338: ldr             x3, [x3, #0x10]
    //     0x82d33c: stur            x3, [fp, #-8]
    //     0x82d340: ldur            w2, [x0, #0x1f]
    //     0x82d344: add             x2, x2, HEAP, lsl #32
    //     0x82d348: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a18] "springDescription"
    //     0x82d34c: ldr             x16, [x16, #0xa18]
    //     0x82d350: cmp             w2, w16
    //     0x82d354: b.ne            #0x82d360
    //     0x82d358: mov             x2, #1
    //     0x82d35c: b               #0x82d364
    //     0x82d360: mov             x2, #0
    //     0x82d364: lsl             x4, x2, #1
    //     0x82d368: lsl             w2, w4, #1
    //     0x82d36c: add             w4, w2, #8
    //     0x82d370: add             x16, x0, w4, sxtw #1
    //     0x82d374: ldur            w5, [x16, #0xf]
    //     0x82d378: add             x5, x5, HEAP, lsl #32
    //     0x82d37c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a20] "velocity"
    //     0x82d380: ldr             x16, [x16, #0xa20]
    //     0x82d384: cmp             w5, w16
    //     0x82d388: b.ne            #0x82d3b0
    //     0x82d38c: add             w4, w2, #0xa
    //     0x82d390: add             x16, x0, w4, sxtw #1
    //     0x82d394: ldur            w2, [x16, #0xf]
    //     0x82d398: add             x2, x2, HEAP, lsl #32
    //     0x82d39c: sub             w0, w1, w2
    //     0x82d3a0: add             x1, fp, w0, sxtw #2
    //     0x82d3a4: ldr             x1, [x1, #8]
    //     0x82d3a8: ldur            d0, [x1, #7]
    //     0x82d3ac: b               #0x82d3b4
    //     0x82d3b0: fmov            d0, #1.00000000
    //     0x82d3b4: stur            d0, [fp, #-0x30]
    // 0x82d3b8: CheckStackOverflow
    //     0x82d3b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82d3bc: cmp             SP, x16
    //     0x82d3c0: b.ls            #0x82d5a4
    // 0x82d3c4: r0 = InitLateStaticField(0xcc0) // [package:flutter/src/animation/animation_controller.dart] ::_kFlingSpringDescription
    //     0x82d3c4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x82d3c8: ldr             x0, [x0, #0x1980]
    //     0x82d3cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x82d3d0: cmp             w0, w16
    //     0x82d3d4: b.ne            #0x82d3e4
    //     0x82d3d8: add             x2, PP, #0x37, lsl #12  ; [pp+0x37a28] Field <::._kFlingSpringDescription@575066280>: static late final (offset: 0xcc0)
    //     0x82d3dc: ldr             x2, [x2, #0xa28]
    //     0x82d3e0: bl              #0xd67cdc
    // 0x82d3e4: mov             x1, x0
    // 0x82d3e8: ldur            d1, [fp, #-0x30]
    // 0x82d3ec: d0 = 0.000000
    //     0x82d3ec: eor             v0.16b, v0.16b, v0.16b
    // 0x82d3f0: stur            x1, [fp, #-0x20]
    // 0x82d3f4: fcmp            d1, d0
    // 0x82d3f8: b.vs            #0x82d400
    // 0x82d3fc: b.lt            #0x82d408
    // 0x82d400: r2 = false
    //     0x82d400: add             x2, NULL, #0x30  ; false
    // 0x82d404: b               #0x82d40c
    // 0x82d408: r2 = true
    //     0x82d408: add             x2, NULL, #0x20  ; true
    // 0x82d40c: tbnz            w2, #4, #0x82d41c
    // 0x82d410: r0 = Instance__AnimationDirection
    //     0x82d410: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb90] Obj!_AnimationDirection@b65ef1
    //     0x82d414: ldr             x0, [x0, #0xb90]
    // 0x82d418: b               #0x82d424
    // 0x82d41c: r0 = Instance__AnimationDirection
    //     0x82d41c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x82d420: ldr             x0, [x0, #0xb98]
    // 0x82d424: ldur            x3, [fp, #-8]
    // 0x82d428: StoreField: r3->field_3f = r0
    //     0x82d428: stur            w0, [x3, #0x3f]
    //     0x82d42c: ldurb           w16, [x3, #-1]
    //     0x82d430: ldurb           w17, [x0, #-1]
    //     0x82d434: and             x16, x17, x16, lsr #2
    //     0x82d438: tst             x16, HEAP, lsr #32
    //     0x82d43c: b.eq            #0x82d444
    //     0x82d440: bl              #0xd682ac
    // 0x82d444: tbnz            w2, #4, #0x82d464
    // 0x82d448: r0 = Instance_Tolerance
    //     0x82d448: add             x0, PP, #0x37, lsl #12  ; [pp+0x37a30] Obj!Tolerance@b35671
    //     0x82d44c: ldr             x0, [x0, #0xa30]
    // 0x82d450: LoadField: d0 = r3->field_13
    //     0x82d450: ldur            d0, [x3, #0x13]
    // 0x82d454: LoadField: d2 = r0->field_7
    //     0x82d454: ldur            d2, [x0, #7]
    // 0x82d458: fsub            d3, d0, d2
    // 0x82d45c: mov             v0.16b, v3.16b
    // 0x82d460: b               #0x82d47c
    // 0x82d464: r0 = Instance_Tolerance
    //     0x82d464: add             x0, PP, #0x37, lsl #12  ; [pp+0x37a30] Obj!Tolerance@b35671
    //     0x82d468: ldr             x0, [x0, #0xa30]
    // 0x82d46c: LoadField: d0 = r3->field_1b
    //     0x82d46c: ldur            d0, [x3, #0x1b]
    // 0x82d470: LoadField: d2 = r0->field_7
    //     0x82d470: ldur            d2, [x0, #7]
    // 0x82d474: fadd            d3, d0, d2
    // 0x82d478: mov             v0.16b, v3.16b
    // 0x82d47c: r2 = 4
    //     0x82d47c: mov             x2, #4
    // 0x82d480: LoadField: r4 = r3->field_23
    //     0x82d480: ldur            w4, [x3, #0x23]
    // 0x82d484: DecompressPointer r4
    //     0x82d484: add             x4, x4, HEAP, lsl #32
    // 0x82d488: r5 = LoadStaticField(0xf1c)
    //     0x82d488: ldr             x5, [THR, #0x88]  ; THR::field_table_values
    //     0x82d48c: ldr             x5, [x5, #0x1e38]
    // 0x82d490: cmp             w5, NULL
    // 0x82d494: b.eq            #0x82d5ac
    // 0x82d498: LoadField: r6 = r5->field_af
    //     0x82d498: ldur            w6, [x5, #0xaf]
    // 0x82d49c: DecompressPointer r6
    //     0x82d49c: add             x6, x6, HEAP, lsl #32
    // 0x82d4a0: r16 = Sentinel
    //     0x82d4a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82d4a4: cmp             w6, w16
    // 0x82d4a8: b.eq            #0x82d5b0
    // 0x82d4ac: LoadField: r5 = r6->field_7
    //     0x82d4ac: ldur            x5, [x6, #7]
    // 0x82d4b0: ubfx            x5, x5, #0, #0x20
    // 0x82d4b4: and             x6, x5, x2
    // 0x82d4b8: ubfx            x6, x6, #0, #0x20
    // 0x82d4bc: cbz             x6, #0x82d4e0
    // 0x82d4c0: LoadField: r2 = r4->field_7
    //     0x82d4c0: ldur            x2, [x4, #7]
    // 0x82d4c4: cmp             x2, #0
    // 0x82d4c8: b.gt            #0x82d4d8
    // 0x82d4cc: d2 = 200.000000
    //     0x82d4cc: add             x17, PP, #0x32, lsl #12  ; [pp+0x32b20] IMM: double(200) from 0x4069000000000000
    //     0x82d4d0: ldr             d2, [x17, #0xb20]
    // 0x82d4d4: b               #0x82d4e4
    // 0x82d4d8: d2 = 1.000000
    //     0x82d4d8: fmov            d2, #1.00000000
    // 0x82d4dc: b               #0x82d4e4
    // 0x82d4e0: d2 = 1.000000
    //     0x82d4e0: fmov            d2, #1.00000000
    // 0x82d4e4: LoadField: r2 = r3->field_37
    //     0x82d4e4: ldur            w2, [x3, #0x37]
    // 0x82d4e8: DecompressPointer r2
    //     0x82d4e8: add             x2, x2, HEAP, lsl #32
    // 0x82d4ec: r16 = Sentinel
    //     0x82d4ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82d4f0: cmp             w2, w16
    // 0x82d4f4: b.eq            #0x82d5bc
    // 0x82d4f8: stur            x2, [fp, #-0x18]
    // 0x82d4fc: fmul            d3, d1, d2
    // 0x82d500: stur            d3, [fp, #-0x38]
    // 0x82d504: r4 = inline_Allocate_Double()
    //     0x82d504: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x82d508: add             x4, x4, #0x10
    //     0x82d50c: cmp             x5, x4
    //     0x82d510: b.ls            #0x82d5c8
    //     0x82d514: str             x4, [THR, #0x60]  ; THR::top
    //     0x82d518: sub             x4, x4, #0xf
    //     0x82d51c: mov             x5, #0xd108
    //     0x82d520: movk            x5, #3, lsl #16
    //     0x82d524: stur            x5, [x4, #-1]
    // 0x82d528: StoreField: r4->field_7 = d0
    //     0x82d528: stur            d0, [x4, #7]
    // 0x82d52c: stur            x4, [fp, #-0x10]
    // 0x82d530: r0 = SpringSimulation()
    //     0x82d530: bl              #0x82da00  ; AllocateSpringSimulationStub -> SpringSimulation (size=0x18)
    // 0x82d534: stur            x0, [fp, #-0x28]
    // 0x82d538: ldur            x16, [fp, #-0x20]
    // 0x82d53c: stp             x16, x0, [SP, #-0x10]!
    // 0x82d540: ldur            x16, [fp, #-0x18]
    // 0x82d544: ldur            lr, [fp, #-0x10]
    // 0x82d548: stp             lr, x16, [SP, #-0x10]!
    // 0x82d54c: ldur            d0, [fp, #-0x38]
    // 0x82d550: SaveReg d0
    //     0x82d550: str             d0, [SP, #-8]!
    // 0x82d554: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x82d554: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x82d558: r0 = SpringSimulation()
    //     0x82d558: bl              #0x82d5ec  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::SpringSimulation
    // 0x82d55c: add             SP, SP, #0x28
    // 0x82d560: ldur            x0, [fp, #-0x28]
    // 0x82d564: r1 = Instance_Tolerance
    //     0x82d564: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a30] Obj!Tolerance@b35671
    //     0x82d568: ldr             x1, [x1, #0xa30]
    // 0x82d56c: StoreField: r0->field_7 = r1
    //     0x82d56c: stur            w1, [x0, #7]
    // 0x82d570: ldur            x16, [fp, #-8]
    // 0x82d574: SaveReg r16
    //     0x82d574: str             x16, [SP, #-8]!
    // 0x82d578: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x82d578: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x82d57c: r0 = stop()
    //     0x82d57c: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x82d580: add             SP, SP, #8
    // 0x82d584: ldur            x16, [fp, #-8]
    // 0x82d588: ldur            lr, [fp, #-0x28]
    // 0x82d58c: stp             lr, x16, [SP, #-0x10]!
    // 0x82d590: r0 = _startSimulation()
    //     0x82d590: bl              #0x5918a4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_startSimulation
    // 0x82d594: add             SP, SP, #0x10
    // 0x82d598: LeaveFrame
    //     0x82d598: mov             SP, fp
    //     0x82d59c: ldp             fp, lr, [SP], #0x10
    // 0x82d5a0: ret
    //     0x82d5a0: ret             
    // 0x82d5a4: r0 = StackOverflowSharedWithFPURegs()
    //     0x82d5a4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x82d5a8: b               #0x82d3c4
    // 0x82d5ac: r0 = NullCastErrorSharedWithFPURegs()
    //     0x82d5ac: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x82d5b0: r9 = _accessibilityFeatures
    //     0x82d5b0: add             x9, PP, #0xd, lsl #12  ; [pp+0xdc28] Field <_WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding@423399801._accessibilityFeatures@932275577>: late (offset: 0xb0)
    //     0x82d5b4: ldr             x9, [x9, #0xc28]
    // 0x82d5b8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x82d5b8: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x82d5bc: r9 = _value
    //     0x82d5bc: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x82d5c0: ldr             x9, [x9, #0xbb0]
    // 0x82d5c4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x82d5c4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x82d5c8: stp             q0, q3, [SP, #-0x20]!
    // 0x82d5cc: stp             x2, x3, [SP, #-0x10]!
    // 0x82d5d0: stp             x0, x1, [SP, #-0x10]!
    // 0x82d5d4: r0 = AllocateDouble()
    //     0x82d5d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d5d8: mov             x4, x0
    // 0x82d5dc: ldp             x0, x1, [SP], #0x10
    // 0x82d5e0: ldp             x2, x3, [SP], #0x10
    // 0x82d5e4: ldp             q0, q3, [SP], #0x20
    // 0x82d5e8: b               #0x82d528
  }
  _ AnimationController.unbounded(/* No info */) {
    // ** addr: 0x9d5c78, size: 0x168
    // 0x9d5c78: EnterFrame
    //     0x9d5c78: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5c7c: mov             fp, SP
    // 0x9d5c80: AllocStack(0x18)
    //     0x9d5c80: sub             SP, SP, #0x18
    // 0x9d5c84: SetupParameters(AnimationController<double> this /* r3, fp-0x10 */, dynamic _ /* r4, fp-0x8 */, {_Double value = 0.000000 /* d2, fp-0x18 */})
    //     0x9d5c84: mov             x0, x4
    //     0x9d5c88: ldur            w1, [x0, #0x13]
    //     0x9d5c8c: add             x1, x1, HEAP, lsl #32
    //     0x9d5c90: sub             x2, x1, #4
    //     0x9d5c94: add             x3, fp, w2, sxtw #2
    //     0x9d5c98: ldr             x3, [x3, #0x18]
    //     0x9d5c9c: stur            x3, [fp, #-0x10]
    //     0x9d5ca0: add             x4, fp, w2, sxtw #2
    //     0x9d5ca4: ldr             x4, [x4, #0x10]
    //     0x9d5ca8: stur            x4, [fp, #-8]
    //     0x9d5cac: ldur            w2, [x0, #0x1f]
    //     0x9d5cb0: add             x2, x2, HEAP, lsl #32
    //     0x9d5cb4: ldr             x16, [PP, #0x408]  ; [pp+0x408] "value"
    //     0x9d5cb8: cmp             w2, w16
    //     0x9d5cbc: b.ne            #0x9d5ce0
    //     0x9d5cc0: ldur            w2, [x0, #0x23]
    //     0x9d5cc4: add             x2, x2, HEAP, lsl #32
    //     0x9d5cc8: sub             w0, w1, w2
    //     0x9d5ccc: add             x1, fp, w0, sxtw #2
    //     0x9d5cd0: ldr             x1, [x1, #8]
    //     0x9d5cd4: ldur            d0, [x1, #7]
    //     0x9d5cd8: mov             v2.16b, v0.16b
    //     0x9d5cdc: b               #0x9d5ce4
    //     0x9d5ce0: eor             v2.16b, v2.16b, v2.16b
    //     0x9d5ce4: ldr             x5, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9d5ce8: add             x2, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x9d5cec: ldr             x2, [x2, #0xba8]
    //     0x9d5cf0: add             x1, PP, #0x27, lsl #12  ; [pp+0x270e0] Obj!AnimationBehavior@b65eb1
    //     0x9d5cf4: ldr             x1, [x1, #0xe0]
    //     0x9d5cf8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0x9d5cfc: ldr             x0, [x0, #0xb98]
    //     0x9d5d00: ldr             d1, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    //     0x9d5d04: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    //     0x9d5d08: stur            d2, [fp, #-0x18]
    // 0x9d5ce4: r5 = Sentinel
    // 0x9d5ce8: r2 = Instance_AnimationStatus
    // 0x9d5cf0: r1 = Instance_AnimationBehavior
    // 0x9d5cf8: r0 = Instance__AnimationDirection
    // 0x9d5d00: d1 = -inf
    // 0x9d5d04: d0 = inf
    // 0x9d5d0c: CheckStackOverflow
    //     0x9d5d0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d5d10: cmp             SP, x16
    //     0x9d5d14: b.ls            #0x9d5dd8
    // 0x9d5d18: StoreField: r3->field_37 = r5
    //     0x9d5d18: stur            w5, [x3, #0x37]
    // 0x9d5d1c: StoreField: r3->field_43 = r5
    //     0x9d5d1c: stur            w5, [x3, #0x43]
    // 0x9d5d20: StoreField: r3->field_47 = r2
    //     0x9d5d20: stur            w2, [x3, #0x47]
    // 0x9d5d24: StoreField: r3->field_23 = r1
    //     0x9d5d24: stur            w1, [x3, #0x23]
    // 0x9d5d28: StoreField: r3->field_13 = d1
    //     0x9d5d28: stur            d1, [x3, #0x13]
    // 0x9d5d2c: StoreField: r3->field_1b = d0
    //     0x9d5d2c: stur            d0, [x3, #0x1b]
    // 0x9d5d30: StoreField: r3->field_3f = r0
    //     0x9d5d30: stur            w0, [x3, #0x3f]
    // 0x9d5d34: SaveReg r3
    //     0x9d5d34: str             x3, [SP, #-8]!
    // 0x9d5d38: r0 = _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin()
    //     0x9d5d38: bl              #0x6ea9d8  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::_AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin
    // 0x9d5d3c: add             SP, SP, #8
    // 0x9d5d40: ldur            x1, [fp, #-0x10]
    // 0x9d5d44: r0 = 59
    //     0x9d5d44: mov             x0, #0x3b
    // 0x9d5d48: branchIfSmi(r1, 0x9d5d54)
    //     0x9d5d48: tbz             w1, #0, #0x9d5d54
    // 0x9d5d4c: r0 = LoadClassIdInstr(r1)
    //     0x9d5d4c: ldur            x0, [x1, #-1]
    //     0x9d5d50: ubfx            x0, x0, #0xc, #0x14
    // 0x9d5d54: SaveReg r1
    //     0x9d5d54: str             x1, [SP, #-8]!
    // 0x9d5d58: r0 = GDT[cid_x0 + -0xff4]()
    //     0x9d5d58: sub             lr, x0, #0xff4
    //     0x9d5d5c: ldr             lr, [x21, lr, lsl #3]
    //     0x9d5d60: blr             lr
    // 0x9d5d64: add             SP, SP, #8
    // 0x9d5d68: mov             x1, x0
    // 0x9d5d6c: ldur            x0, [fp, #-8]
    // 0x9d5d70: r2 = LoadClassIdInstr(r0)
    //     0x9d5d70: ldur            x2, [x0, #-1]
    //     0x9d5d74: ubfx            x2, x2, #0xc, #0x14
    // 0x9d5d78: stp             x1, x0, [SP, #-0x10]!
    // 0x9d5d7c: mov             x0, x2
    // 0x9d5d80: r0 = GDT[cid_x0 + 0xf44b]()
    //     0x9d5d80: mov             x17, #0xf44b
    //     0x9d5d84: add             lr, x0, x17
    //     0x9d5d88: ldr             lr, [x21, lr, lsl #3]
    //     0x9d5d8c: blr             lr
    // 0x9d5d90: add             SP, SP, #0x10
    // 0x9d5d94: ldur            x1, [fp, #-0x10]
    // 0x9d5d98: StoreField: r1->field_2f = r0
    //     0x9d5d98: stur            w0, [x1, #0x2f]
    //     0x9d5d9c: ldurb           w16, [x1, #-1]
    //     0x9d5da0: ldurb           w17, [x0, #-1]
    //     0x9d5da4: and             x16, x17, x16, lsr #2
    //     0x9d5da8: tst             x16, HEAP, lsr #32
    //     0x9d5dac: b.eq            #0x9d5db4
    //     0x9d5db0: bl              #0xd6826c
    // 0x9d5db4: SaveReg r1
    //     0x9d5db4: str             x1, [SP, #-8]!
    // 0x9d5db8: ldur            d0, [fp, #-0x18]
    // 0x9d5dbc: SaveReg d0
    //     0x9d5dbc: str             d0, [SP, #-8]!
    // 0x9d5dc0: r0 = _internalSetValue()
    //     0x9d5dc0: bl              #0x593850  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_internalSetValue
    // 0x9d5dc4: add             SP, SP, #0x10
    // 0x9d5dc8: r0 = Null
    //     0x9d5dc8: mov             x0, NULL
    // 0x9d5dcc: LeaveFrame
    //     0x9d5dcc: mov             SP, fp
    //     0x9d5dd0: ldp             fp, lr, [SP], #0x10
    // 0x9d5dd4: ret
    //     0x9d5dd4: ret             
    // 0x9d5dd8: r0 = StackOverflowSharedWithFPURegs()
    //     0x9d5dd8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x9d5ddc: b               #0x9d5d18
  }
  _ animateBack(/* No info */) {
    // ** addr: 0x9d80b8, size: 0x5c
    // 0x9d80b8: EnterFrame
    //     0x9d80b8: stp             fp, lr, [SP, #-0x10]!
    //     0x9d80bc: mov             fp, SP
    // 0x9d80c0: r0 = Instance__AnimationDirection
    //     0x9d80c0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb90] Obj!_AnimationDirection@b65ef1
    //     0x9d80c4: ldr             x0, [x0, #0xb90]
    // 0x9d80c8: CheckStackOverflow
    //     0x9d80c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d80cc: cmp             SP, x16
    //     0x9d80d0: b.ls            #0x9d810c
    // 0x9d80d4: ldr             x1, [fp, #0x18]
    // 0x9d80d8: StoreField: r1->field_3f = r0
    //     0x9d80d8: stur            w0, [x1, #0x3f]
    // 0x9d80dc: stp             xzr, x1, [SP, #-0x10]!
    // 0x9d80e0: ldr             x16, [fp, #0x10]
    // 0x9d80e4: r30 = Instance_Cubic
    //     0x9d80e4: add             lr, PP, #0x3b, lsl #12  ; [pp+0x3bc30] Obj!Cubic<double>@b4f581
    //     0x9d80e8: ldr             lr, [lr, #0xc30]
    // 0x9d80ec: stp             lr, x16, [SP, #-0x10]!
    // 0x9d80f0: r4 = const [0, 0x4, 0x4, 0x2, curve, 0x3, duration, 0x2, null]
    //     0x9d80f0: add             x4, PP, #0x27, lsl #12  ; [pp+0x272a0] List(9) [0, 0x4, 0x4, 0x2, "curve", 0x3, "duration", 0x2, Null]
    //     0x9d80f4: ldr             x4, [x4, #0x2a0]
    // 0x9d80f8: r0 = _animateToInternal()
    //     0x9d80f8: bl              #0x591390  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_animateToInternal
    // 0x9d80fc: add             SP, SP, #0x20
    // 0x9d8100: LeaveFrame
    //     0x9d8100: mov             SP, fp
    //     0x9d8104: ldp             fp, lr, [SP], #0x10
    // 0x9d8108: ret
    //     0x9d8108: ret             
    // 0x9d810c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d810c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8110: b               #0x9d80d4
  }
  get _ velocity(/* No info */) {
    // ** addr: 0xae9d58, size: 0x11c
    // 0xae9d58: EnterFrame
    //     0xae9d58: stp             fp, lr, [SP, #-0x10]!
    //     0xae9d5c: mov             fp, SP
    // 0xae9d60: AllocStack(0x8)
    //     0xae9d60: sub             SP, SP, #8
    // 0xae9d64: CheckStackOverflow
    //     0xae9d64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae9d68: cmp             SP, x16
    //     0xae9d6c: b.ls            #0xae9e54
    // 0xae9d70: ldr             x0, [fp, #0x10]
    // 0xae9d74: LoadField: r1 = r0->field_2f
    //     0xae9d74: ldur            w1, [x0, #0x2f]
    // 0xae9d78: DecompressPointer r1
    //     0xae9d78: add             x1, x1, HEAP, lsl #32
    // 0xae9d7c: cmp             w1, NULL
    // 0xae9d80: b.eq            #0xae9e44
    // 0xae9d84: LoadField: r2 = r1->field_7
    //     0xae9d84: ldur            w2, [x1, #7]
    // 0xae9d88: DecompressPointer r2
    //     0xae9d88: add             x2, x2, HEAP, lsl #32
    // 0xae9d8c: cmp             w2, NULL
    // 0xae9d90: b.eq            #0xae9e44
    // 0xae9d94: LoadField: r2 = r0->field_33
    //     0xae9d94: ldur            w2, [x0, #0x33]
    // 0xae9d98: DecompressPointer r2
    //     0xae9d98: add             x2, x2, HEAP, lsl #32
    // 0xae9d9c: stur            x2, [fp, #-8]
    // 0xae9da0: cmp             w2, NULL
    // 0xae9da4: b.eq            #0xae9e5c
    // 0xae9da8: LoadField: r1 = r0->field_3b
    //     0xae9da8: ldur            w1, [x0, #0x3b]
    // 0xae9dac: DecompressPointer r1
    //     0xae9dac: add             x1, x1, HEAP, lsl #32
    // 0xae9db0: cmp             w1, NULL
    // 0xae9db4: b.eq            #0xae9e60
    // 0xae9db8: LoadField: r3 = r1->field_7
    //     0xae9db8: ldur            x3, [x1, #7]
    // 0xae9dbc: r0 = BoxInt64Instr(r3)
    //     0xae9dbc: sbfiz           x0, x3, #1, #0x1f
    //     0xae9dc0: cmp             x3, x0, asr #1
    //     0xae9dc4: b.eq            #0xae9dd0
    //     0xae9dc8: bl              #0xd69bb8
    //     0xae9dcc: stur            x3, [x0, #7]
    // 0xae9dd0: stp             x0, NULL, [SP, #-0x10]!
    // 0xae9dd4: r0 = _Double.fromInteger()
    //     0xae9dd4: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xae9dd8: add             SP, SP, #0x10
    // 0xae9ddc: LoadField: d0 = r0->field_7
    //     0xae9ddc: ldur            d0, [x0, #7]
    // 0xae9de0: d1 = 1000000.000000
    //     0xae9de0: add             x17, PP, #0xd, lsl #12  ; [pp+0xdbd8] IMM: double(1e+06) from 0x412e848000000000
    //     0xae9de4: ldr             d1, [x17, #0xbd8]
    // 0xae9de8: fdiv            d2, d0, d1
    // 0xae9dec: r0 = inline_Allocate_Double()
    //     0xae9dec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xae9df0: add             x0, x0, #0x10
    //     0xae9df4: cmp             x1, x0
    //     0xae9df8: b.ls            #0xae9e64
    //     0xae9dfc: str             x0, [THR, #0x60]  ; THR::top
    //     0xae9e00: sub             x0, x0, #0xf
    //     0xae9e04: mov             x1, #0xd108
    //     0xae9e08: movk            x1, #3, lsl #16
    //     0xae9e0c: stur            x1, [x0, #-1]
    // 0xae9e10: StoreField: r0->field_7 = d2
    //     0xae9e10: stur            d2, [x0, #7]
    // 0xae9e14: ldur            x1, [fp, #-8]
    // 0xae9e18: r2 = LoadClassIdInstr(r1)
    //     0xae9e18: ldur            x2, [x1, #-1]
    //     0xae9e1c: ubfx            x2, x2, #0xc, #0x14
    // 0xae9e20: stp             x0, x1, [SP, #-0x10]!
    // 0xae9e24: mov             x0, x2
    // 0xae9e28: r0 = GDT[cid_x0 + 0xb5d]()
    //     0xae9e28: add             lr, x0, #0xb5d
    //     0xae9e2c: ldr             lr, [x21, lr, lsl #3]
    //     0xae9e30: blr             lr
    // 0xae9e34: add             SP, SP, #0x10
    // 0xae9e38: LeaveFrame
    //     0xae9e38: mov             SP, fp
    //     0xae9e3c: ldp             fp, lr, [SP], #0x10
    // 0xae9e40: ret
    //     0xae9e40: ret             
    // 0xae9e44: d0 = 0.000000
    //     0xae9e44: eor             v0.16b, v0.16b, v0.16b
    // 0xae9e48: LeaveFrame
    //     0xae9e48: mov             SP, fp
    //     0xae9e4c: ldp             fp, lr, [SP], #0x10
    // 0xae9e50: ret
    //     0xae9e50: ret             
    // 0xae9e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae9e54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae9e58: b               #0xae9d70
    // 0xae9e5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xae9e5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xae9e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xae9e60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xae9e64: SaveReg d2
    //     0xae9e64: str             q2, [SP, #-0x10]!
    // 0xae9e68: r0 = AllocateDouble()
    //     0xae9e68: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae9e6c: RestoreReg d2
    //     0xae9e6c: ldr             q2, [SP], #0x10
    // 0xae9e70: b               #0xae9e10
  }
  _ toStringDetails(/* No info */) {
    // ** addr: 0xbea058, size: 0x17c
    // 0xbea058: EnterFrame
    //     0xbea058: stp             fp, lr, [SP, #-0x10]!
    //     0xbea05c: mov             fp, SP
    // 0xbea060: AllocStack(0x20)
    //     0xbea060: sub             SP, SP, #0x20
    // 0xbea064: CheckStackOverflow
    //     0xbea064: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbea068: cmp             SP, x16
    //     0xbea06c: b.ls            #0xbea1c0
    // 0xbea070: ldr             x0, [fp, #0x10]
    // 0xbea074: LoadField: r1 = r0->field_2f
    //     0xbea074: ldur            w1, [x0, #0x2f]
    // 0xbea078: DecompressPointer r1
    //     0xbea078: add             x1, x1, HEAP, lsl #32
    // 0xbea07c: cmp             w1, NULL
    // 0xbea080: b.eq            #0xbea09c
    // 0xbea084: LoadField: r2 = r1->field_7
    //     0xbea084: ldur            w2, [x1, #7]
    // 0xbea088: DecompressPointer r2
    //     0xbea088: add             x2, x2, HEAP, lsl #32
    // 0xbea08c: cmp             w2, NULL
    // 0xbea090: b.eq            #0xbea09c
    // 0xbea094: r2 = ""
    //     0xbea094: ldr             x2, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xbea098: b               #0xbea0a4
    // 0xbea09c: r2 = "; paused"
    //     0xbea09c: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d188] "; paused"
    //     0xbea0a0: ldr             x2, [x2, #0x188]
    // 0xbea0a4: stur            x2, [fp, #-0x10]
    // 0xbea0a8: cmp             w1, NULL
    // 0xbea0ac: b.ne            #0xbea0bc
    // 0xbea0b0: r1 = "; DISPOSED"
    //     0xbea0b0: add             x1, PP, #0x22, lsl #12  ; [pp+0x22200] "; DISPOSED"
    //     0xbea0b4: ldr             x1, [x1, #0x200]
    // 0xbea0b8: b               #0xbea0d8
    // 0xbea0bc: LoadField: r3 = r1->field_b
    //     0xbea0bc: ldur            w3, [x1, #0xb]
    // 0xbea0c0: DecompressPointer r3
    //     0xbea0c0: add             x3, x3, HEAP, lsl #32
    // 0xbea0c4: tbnz            w3, #4, #0xbea0d4
    // 0xbea0c8: r1 = "; silenced"
    //     0xbea0c8: add             x1, PP, #0x22, lsl #12  ; [pp+0x22208] "; silenced"
    //     0xbea0cc: ldr             x1, [x1, #0x208]
    // 0xbea0d0: b               #0xbea0d8
    // 0xbea0d4: r1 = ""
    //     0xbea0d4: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xbea0d8: stur            x1, [fp, #-8]
    // 0xbea0dc: SaveReg r0
    //     0xbea0dc: str             x0, [SP, #-8]!
    // 0xbea0e0: r0 = toStringDetails()
    //     0xbea0e0: bl              #0xbea25c  ; [package:flutter/src/animation/animation.dart] Animation::toStringDetails
    // 0xbea0e4: add             SP, SP, #8
    // 0xbea0e8: r1 = Null
    //     0xbea0e8: mov             x1, NULL
    // 0xbea0ec: r2 = 6
    //     0xbea0ec: mov             x2, #6
    // 0xbea0f0: stur            x0, [fp, #-0x18]
    // 0xbea0f4: r0 = AllocateArray()
    //     0xbea0f4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xbea0f8: mov             x1, x0
    // 0xbea0fc: ldur            x0, [fp, #-0x18]
    // 0xbea100: stur            x1, [fp, #-0x20]
    // 0xbea104: StoreField: r1->field_f = r0
    //     0xbea104: stur            w0, [x1, #0xf]
    // 0xbea108: r17 = " "
    //     0xbea108: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xbea10c: StoreField: r1->field_13 = r17
    //     0xbea10c: stur            w17, [x1, #0x13]
    // 0xbea110: ldr             x0, [fp, #0x10]
    // 0xbea114: LoadField: r2 = r0->field_37
    //     0xbea114: ldur            w2, [x0, #0x37]
    // 0xbea118: DecompressPointer r2
    //     0xbea118: add             x2, x2, HEAP, lsl #32
    // 0xbea11c: r16 = Sentinel
    //     0xbea11c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbea120: cmp             w2, w16
    // 0xbea124: b.eq            #0xbea1c8
    // 0xbea128: SaveReg r2
    //     0xbea128: str             x2, [SP, #-8]!
    // 0xbea12c: r0 = 3
    //     0xbea12c: mov             x0, #3
    // 0xbea130: SaveReg r0
    //     0xbea130: str             x0, [SP, #-8]!
    // 0xbea134: r0 = toStringAsFixed()
    //     0xbea134: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xbea138: add             SP, SP, #0x10
    // 0xbea13c: ldur            x1, [fp, #-0x20]
    // 0xbea140: ArrayStore: r1[2] = r0  ; List_4
    //     0xbea140: add             x25, x1, #0x17
    //     0xbea144: str             w0, [x25]
    //     0xbea148: tbz             w0, #0, #0xbea164
    //     0xbea14c: ldurb           w16, [x1, #-1]
    //     0xbea150: ldurb           w17, [x0, #-1]
    //     0xbea154: and             x16, x17, x16, lsr #2
    //     0xbea158: tst             x16, HEAP, lsr #32
    //     0xbea15c: b.eq            #0xbea164
    //     0xbea160: bl              #0xd67e5c
    // 0xbea164: ldur            x16, [fp, #-0x20]
    // 0xbea168: SaveReg r16
    //     0xbea168: str             x16, [SP, #-8]!
    // 0xbea16c: r0 = _interpolate()
    //     0xbea16c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xbea170: add             SP, SP, #8
    // 0xbea174: r1 = Null
    //     0xbea174: mov             x1, NULL
    // 0xbea178: r2 = 8
    //     0xbea178: mov             x2, #8
    // 0xbea17c: stur            x0, [fp, #-0x18]
    // 0xbea180: r0 = AllocateArray()
    //     0xbea180: bl              #0xd6987c  ; AllocateArrayStub
    // 0xbea184: mov             x1, x0
    // 0xbea188: ldur            x0, [fp, #-0x18]
    // 0xbea18c: StoreField: r1->field_f = r0
    //     0xbea18c: stur            w0, [x1, #0xf]
    // 0xbea190: ldur            x0, [fp, #-0x10]
    // 0xbea194: StoreField: r1->field_13 = r0
    //     0xbea194: stur            w0, [x1, #0x13]
    // 0xbea198: ldur            x0, [fp, #-8]
    // 0xbea19c: StoreField: r1->field_17 = r0
    //     0xbea19c: stur            w0, [x1, #0x17]
    // 0xbea1a0: r17 = ""
    //     0xbea1a0: ldr             x17, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xbea1a4: StoreField: r1->field_1b = r17
    //     0xbea1a4: stur            w17, [x1, #0x1b]
    // 0xbea1a8: SaveReg r1
    //     0xbea1a8: str             x1, [SP, #-8]!
    // 0xbea1ac: r0 = _interpolate()
    //     0xbea1ac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xbea1b0: add             SP, SP, #8
    // 0xbea1b4: LeaveFrame
    //     0xbea1b4: mov             SP, fp
    //     0xbea1b8: ldp             fp, lr, [SP], #0x10
    // 0xbea1bc: ret
    //     0xbea1bc: ret             
    // 0xbea1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbea1c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbea1c4: b               #0xbea070
    // 0xbea1c8: r9 = _value
    //     0xbea1c8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xbea1cc: ldr             x9, [x9, #0xbb0]
    // 0xbea1d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbea1d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ value(/* No info */) {
    // ** addr: 0xc24b8c, size: 0x38
    // 0xc24b8c: EnterFrame
    //     0xc24b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xc24b90: mov             fp, SP
    // 0xc24b94: ldr             x1, [fp, #0x10]
    // 0xc24b98: LoadField: r0 = r1->field_37
    //     0xc24b98: ldur            w0, [x1, #0x37]
    // 0xc24b9c: DecompressPointer r0
    //     0xc24b9c: add             x0, x0, HEAP, lsl #32
    // 0xc24ba0: r16 = Sentinel
    //     0xc24ba0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc24ba4: cmp             w0, w16
    // 0xc24ba8: b.eq            #0xc24bb8
    // 0xc24bac: LeaveFrame
    //     0xc24bac: mov             SP, fp
    //     0xc24bb0: ldp             fp, lr, [SP], #0x10
    // 0xc24bb4: ret
    //     0xc24bb4: ret             
    // 0xc24bb8: r9 = _value
    //     0xc24bb8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xc24bbc: ldr             x9, [x9, #0xbb0]
    // 0xc24bc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc24bc0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ status(/* No info */) {
    // ** addr: 0xc6445c, size: 0x38
    // 0xc6445c: EnterFrame
    //     0xc6445c: stp             fp, lr, [SP, #-0x10]!
    //     0xc64460: mov             fp, SP
    // 0xc64464: ldr             x1, [fp, #0x10]
    // 0xc64468: LoadField: r0 = r1->field_43
    //     0xc64468: ldur            w0, [x1, #0x43]
    // 0xc6446c: DecompressPointer r0
    //     0xc6446c: add             x0, x0, HEAP, lsl #32
    // 0xc64470: r16 = Sentinel
    //     0xc64470: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc64474: cmp             w0, w16
    // 0xc64478: b.eq            #0xc64488
    // 0xc6447c: LeaveFrame
    //     0xc6447c: mov             SP, fp
    //     0xc64480: ldp             fp, lr, [SP], #0x10
    // 0xc64484: ret
    //     0xc64484: ret             
    // 0xc64488: r9 = _status
    //     0xc64488: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbe0] Field <AnimationController._status@575066280>: late (offset: 0x44)
    //     0xc6448c: ldr             x9, [x9, #0xbe0]
    // 0xc64490: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc64490: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic _directionSetter(dynamic) {
    // ** addr: 0xcb977c, size: 0x18
    // 0xcb977c: r4 = 7
    //     0xcb977c: mov             x4, #7
    // 0xcb9780: r1 = Function '_directionSetter@575066280':.
    //     0xcb9780: add             x17, PP, #0x22, lsl #12  ; [pp+0x221f8] AnonymousClosure: (0xcb9794), in [package:flutter/src/animation/animation_controller.dart] AnimationController::_directionSetter (0xcb97e0)
    //     0xcb9784: ldr             x1, [x17, #0x1f8]
    // 0xcb9788: r24 = BuildNonGenericMethodExtractorStub
    //     0xcb9788: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcb978c: LoadField: r0 = r24->field_17
    //     0xcb978c: ldur            x0, [x24, #0x17]
    // 0xcb9790: br              x0
  }
  [closure] void _directionSetter(dynamic, _AnimationDirection) {
    // ** addr: 0xcb9794, size: 0x4c
    // 0xcb9794: EnterFrame
    //     0xcb9794: stp             fp, lr, [SP, #-0x10]!
    //     0xcb9798: mov             fp, SP
    // 0xcb979c: ldr             x0, [fp, #0x18]
    // 0xcb97a0: LoadField: r1 = r0->field_17
    //     0xcb97a0: ldur            w1, [x0, #0x17]
    // 0xcb97a4: DecompressPointer r1
    //     0xcb97a4: add             x1, x1, HEAP, lsl #32
    // 0xcb97a8: CheckStackOverflow
    //     0xcb97a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb97ac: cmp             SP, x16
    //     0xcb97b0: b.ls            #0xcb97d8
    // 0xcb97b4: LoadField: r0 = r1->field_f
    //     0xcb97b4: ldur            w0, [x1, #0xf]
    // 0xcb97b8: DecompressPointer r0
    //     0xcb97b8: add             x0, x0, HEAP, lsl #32
    // 0xcb97bc: ldr             x16, [fp, #0x10]
    // 0xcb97c0: stp             x16, x0, [SP, #-0x10]!
    // 0xcb97c4: r0 = _directionSetter()
    //     0xcb97c4: bl              #0xcb97e0  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_directionSetter
    // 0xcb97c8: add             SP, SP, #0x10
    // 0xcb97cc: LeaveFrame
    //     0xcb97cc: mov             SP, fp
    //     0xcb97d0: ldp             fp, lr, [SP], #0x10
    // 0xcb97d4: ret
    //     0xcb97d4: ret             
    // 0xcb97d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb97d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb97dc: b               #0xcb97b4
  }
  _ _directionSetter(/* No info */) {
    // ** addr: 0xcb97e0, size: 0xa0
    // 0xcb97e0: EnterFrame
    //     0xcb97e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb97e4: mov             fp, SP
    // 0xcb97e8: CheckStackOverflow
    //     0xcb97e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb97ec: cmp             SP, x16
    //     0xcb97f0: b.ls            #0xcb9878
    // 0xcb97f4: ldr             x0, [fp, #0x10]
    // 0xcb97f8: ldr             x1, [fp, #0x18]
    // 0xcb97fc: StoreField: r1->field_3f = r0
    //     0xcb97fc: stur            w0, [x1, #0x3f]
    //     0xcb9800: ldurb           w16, [x1, #-1]
    //     0xcb9804: ldurb           w17, [x0, #-1]
    //     0xcb9808: and             x16, x17, x16, lsr #2
    //     0xcb980c: tst             x16, HEAP, lsr #32
    //     0xcb9810: b.eq            #0xcb9818
    //     0xcb9814: bl              #0xd6826c
    // 0xcb9818: ldr             x0, [fp, #0x10]
    // 0xcb981c: r16 = Instance__AnimationDirection
    //     0xcb981c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb98] Obj!_AnimationDirection@b65ed1
    //     0xcb9820: ldr             x16, [x16, #0xb98]
    // 0xcb9824: cmp             w0, w16
    // 0xcb9828: b.ne            #0xcb9838
    // 0xcb982c: r0 = Instance_AnimationStatus
    //     0xcb982c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0xcb9830: ldr             x0, [x0, #0xbb8]
    // 0xcb9834: b               #0xcb9840
    // 0xcb9838: r0 = Instance_AnimationStatus
    //     0xcb9838: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0xcb983c: ldr             x0, [x0, #0xbc0]
    // 0xcb9840: StoreField: r1->field_43 = r0
    //     0xcb9840: stur            w0, [x1, #0x43]
    //     0xcb9844: ldurb           w16, [x1, #-1]
    //     0xcb9848: ldurb           w17, [x0, #-1]
    //     0xcb984c: and             x16, x17, x16, lsr #2
    //     0xcb9850: tst             x16, HEAP, lsr #32
    //     0xcb9854: b.eq            #0xcb985c
    //     0xcb9858: bl              #0xd6826c
    // 0xcb985c: SaveReg r1
    //     0xcb985c: str             x1, [SP, #-8]!
    // 0xcb9860: r0 = _checkStatusChanged()
    //     0xcb9860: bl              #0x592f80  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::_checkStatusChanged
    // 0xcb9864: add             SP, SP, #8
    // 0xcb9868: r0 = Null
    //     0xcb9868: mov             x0, NULL
    // 0xcb986c: LeaveFrame
    //     0xcb986c: mov             SP, fp
    //     0xcb9870: ldp             fp, lr, [SP], #0x10
    // 0xcb9874: ret
    //     0xcb9874: ret             
    // 0xcb9878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb9878: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb987c: b               #0xcb97f4
  }
  dynamic _tick(dynamic) {
    // ** addr: 0xcb98a8, size: 0x18
    // 0xcb98a8: r4 = 7
    //     0xcb98a8: mov             x4, #7
    // 0xcb98ac: r1 = Function '_tick@575066280':.
    //     0xcb98ac: add             x17, PP, #0x22, lsl #12  ; [pp+0x221f0] AnonymousClosure: (0x6c2f7c), in [package:flutter/src/animation/animation_controller.dart] AnimationController::_tick (0x6c2fc8)
    //     0xcb98b0: ldr             x1, [x17, #0x1f0]
    // 0xcb98b4: r24 = BuildNonGenericMethodExtractorStub
    //     0xcb98b4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcb98b8: LoadField: r0 = r24->field_17
    //     0xcb98b8: ldur            x0, [x24, #0x17]
    // 0xcb98bc: br              x0
  }
}

// class id: 5989, size: 0x14, field offset: 0x14
enum AnimationBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15ac0, size: 0x5c
    // 0xb15ac0: EnterFrame
    //     0xb15ac0: stp             fp, lr, [SP, #-0x10]!
    //     0xb15ac4: mov             fp, SP
    // 0xb15ac8: CheckStackOverflow
    //     0xb15ac8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15acc: cmp             SP, x16
    //     0xb15ad0: b.ls            #0xb15b14
    // 0xb15ad4: r1 = Null
    //     0xb15ad4: mov             x1, NULL
    // 0xb15ad8: r2 = 4
    //     0xb15ad8: mov             x2, #4
    // 0xb15adc: r0 = AllocateArray()
    //     0xb15adc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15ae0: r17 = "AnimationBehavior."
    //     0xb15ae0: add             x17, PP, #0x22, lsl #12  ; [pp+0x221e8] "AnimationBehavior."
    //     0xb15ae4: ldr             x17, [x17, #0x1e8]
    // 0xb15ae8: StoreField: r0->field_f = r17
    //     0xb15ae8: stur            w17, [x0, #0xf]
    // 0xb15aec: ldr             x1, [fp, #0x10]
    // 0xb15af0: LoadField: r2 = r1->field_f
    //     0xb15af0: ldur            w2, [x1, #0xf]
    // 0xb15af4: DecompressPointer r2
    //     0xb15af4: add             x2, x2, HEAP, lsl #32
    // 0xb15af8: StoreField: r0->field_13 = r2
    //     0xb15af8: stur            w2, [x0, #0x13]
    // 0xb15afc: SaveReg r0
    //     0xb15afc: str             x0, [SP, #-8]!
    // 0xb15b00: r0 = _interpolate()
    //     0xb15b00: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15b04: add             SP, SP, #8
    // 0xb15b08: LeaveFrame
    //     0xb15b08: mov             SP, fp
    //     0xb15b0c: ldp             fp, lr, [SP], #0x10
    // 0xb15b10: ret
    //     0xb15b10: ret             
    // 0xb15b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15b14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15b18: b               #0xb15ad4
  }
}

// class id: 5990, size: 0x14, field offset: 0x14
enum _AnimationDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15a64, size: 0x5c
    // 0xb15a64: EnterFrame
    //     0xb15a64: stp             fp, lr, [SP, #-0x10]!
    //     0xb15a68: mov             fp, SP
    // 0xb15a6c: CheckStackOverflow
    //     0xb15a6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15a70: cmp             SP, x16
    //     0xb15a74: b.ls            #0xb15ab8
    // 0xb15a78: r1 = Null
    //     0xb15a78: mov             x1, NULL
    // 0xb15a7c: r2 = 4
    //     0xb15a7c: mov             x2, #4
    // 0xb15a80: r0 = AllocateArray()
    //     0xb15a80: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15a84: r17 = "_AnimationDirection."
    //     0xb15a84: add             x17, PP, #0xe, lsl #12  ; [pp+0xe928] "_AnimationDirection."
    //     0xb15a88: ldr             x17, [x17, #0x928]
    // 0xb15a8c: StoreField: r0->field_f = r17
    //     0xb15a8c: stur            w17, [x0, #0xf]
    // 0xb15a90: ldr             x1, [fp, #0x10]
    // 0xb15a94: LoadField: r2 = r1->field_f
    //     0xb15a94: ldur            w2, [x1, #0xf]
    // 0xb15a98: DecompressPointer r2
    //     0xb15a98: add             x2, x2, HEAP, lsl #32
    // 0xb15a9c: StoreField: r0->field_13 = r2
    //     0xb15a9c: stur            w2, [x0, #0x13]
    // 0xb15aa0: SaveReg r0
    //     0xb15aa0: str             x0, [SP, #-8]!
    // 0xb15aa4: r0 = _interpolate()
    //     0xb15aa4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15aa8: add             SP, SP, #8
    // 0xb15aac: LeaveFrame
    //     0xb15aac: mov             SP, fp
    //     0xb15ab0: ldp             fp, lr, [SP], #0x10
    // 0xb15ab4: ret
    //     0xb15ab4: ret             
    // 0xb15ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15ab8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15abc: b               #0xb15a78
  }
}

// lib: , url: package:flutter/src/animation/animations.dart

// class id: 1049068, size: 0x8
class :: {
}

// class id: 4295, size: 0xc, field offset: 0x8
abstract class AnimationWithParentMixin<X0> extends Object {
}

// class id: 4330, size: 0x14, field offset: 0xc
//   transformed mixin,
abstract class _CompoundAnimation&Animation&AnimationLazyListenerMixin<X0> extends Animation<X0>
     with AnimationLazyListenerMixin {

  _ didRegisterListener(/* No info */) {
    // ** addr: 0x6e94f8, size: 0x54
    // 0x6e94f8: EnterFrame
    //     0x6e94f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e94fc: mov             fp, SP
    // 0x6e9500: CheckStackOverflow
    //     0x6e9500: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9504: cmp             SP, x16
    //     0x6e9508: b.ls            #0x6e9544
    // 0x6e950c: ldr             x0, [fp, #0x10]
    // 0x6e9510: LoadField: r1 = r0->field_b
    //     0x6e9510: ldur            x1, [x0, #0xb]
    // 0x6e9514: cbnz            x1, #0x6e9524
    // 0x6e9518: SaveReg r0
    //     0x6e9518: str             x0, [SP, #-8]!
    // 0x6e951c: r0 = didStartListening()
    //     0x6e951c: bl              #0xc69150  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::didStartListening
    // 0x6e9520: add             SP, SP, #8
    // 0x6e9524: ldr             x1, [fp, #0x10]
    // 0x6e9528: LoadField: r2 = r1->field_b
    //     0x6e9528: ldur            x2, [x1, #0xb]
    // 0x6e952c: add             x3, x2, #1
    // 0x6e9530: StoreField: r1->field_b = r3
    //     0x6e9530: stur            x3, [x1, #0xb]
    // 0x6e9534: r0 = Null
    //     0x6e9534: mov             x0, NULL
    // 0x6e9538: LeaveFrame
    //     0x6e9538: mov             SP, fp
    //     0x6e953c: ldp             fp, lr, [SP], #0x10
    // 0x6e9540: ret
    //     0x6e9540: ret             
    // 0x6e9544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9544: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9548: b               #0x6e950c
  }
  _ didUnregisterListener(/* No info */) {
    // ** addr: 0x6f6180, size: 0x4c
    // 0x6f6180: EnterFrame
    //     0x6f6180: stp             fp, lr, [SP, #-0x10]!
    //     0x6f6184: mov             fp, SP
    // 0x6f6188: CheckStackOverflow
    //     0x6f6188: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f618c: cmp             SP, x16
    //     0x6f6190: b.ls            #0x6f61c4
    // 0x6f6194: ldr             x0, [fp, #0x10]
    // 0x6f6198: LoadField: r1 = r0->field_b
    //     0x6f6198: ldur            x1, [x0, #0xb]
    // 0x6f619c: sub             x2, x1, #1
    // 0x6f61a0: StoreField: r0->field_b = r2
    //     0x6f61a0: stur            x2, [x0, #0xb]
    // 0x6f61a4: cbnz            x2, #0x6f61b4
    // 0x6f61a8: SaveReg r0
    //     0x6f61a8: str             x0, [SP, #-8]!
    // 0x6f61ac: r0 = didStopListening()
    //     0x6f61ac: bl              #0xc3d428  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::didStopListening
    // 0x6f61b0: add             SP, SP, #8
    // 0x6f61b4: r0 = Null
    //     0x6f61b4: mov             x0, NULL
    // 0x6f61b8: LeaveFrame
    //     0x6f61b8: mov             SP, fp
    //     0x6f61bc: ldp             fp, lr, [SP], #0x10
    // 0x6f61c0: ret
    //     0x6f61c0: ret             
    // 0x6f61c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f61c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f61c8: b               #0x6f6194
  }
}

// class id: 4331, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _CompoundAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin<X0> extends _CompoundAnimation&Animation&AnimationLazyListenerMixin<X0>
     with AnimationLocalListenersMixin {

  _ addListener(/* No info */) {
    // ** addr: 0x6e935c, size: 0x58
    // 0x6e935c: EnterFrame
    //     0x6e935c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9360: mov             fp, SP
    // 0x6e9364: CheckStackOverflow
    //     0x6e9364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9368: cmp             SP, x16
    //     0x6e936c: b.ls            #0x6e93ac
    // 0x6e9370: ldr             x16, [fp, #0x18]
    // 0x6e9374: SaveReg r16
    //     0x6e9374: str             x16, [SP, #-8]!
    // 0x6e9378: r0 = didRegisterListener()
    //     0x6e9378: bl              #0x6e94f8  ; [package:flutter/src/animation/animations.dart] _CompoundAnimation&Animation&AnimationLazyListenerMixin::didRegisterListener
    // 0x6e937c: add             SP, SP, #8
    // 0x6e9380: ldr             x0, [fp, #0x18]
    // 0x6e9384: LoadField: r1 = r0->field_13
    //     0x6e9384: ldur            w1, [x0, #0x13]
    // 0x6e9388: DecompressPointer r1
    //     0x6e9388: add             x1, x1, HEAP, lsl #32
    // 0x6e938c: ldr             x16, [fp, #0x10]
    // 0x6e9390: stp             x16, x1, [SP, #-0x10]!
    // 0x6e9394: r0 = add()
    //     0x6e9394: bl              #0x6e93b4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::add
    // 0x6e9398: add             SP, SP, #0x10
    // 0x6e939c: r0 = Null
    //     0x6e939c: mov             x0, NULL
    // 0x6e93a0: LeaveFrame
    //     0x6e93a0: mov             SP, fp
    //     0x6e93a4: ldp             fp, lr, [SP], #0x10
    // 0x6e93a8: ret
    //     0x6e93a8: ret             
    // 0x6e93ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e93ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e93b0: b               #0x6e9370
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6f6124, size: 0x5c
    // 0x6f6124: EnterFrame
    //     0x6f6124: stp             fp, lr, [SP, #-0x10]!
    //     0x6f6128: mov             fp, SP
    // 0x6f612c: CheckStackOverflow
    //     0x6f612c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f6130: cmp             SP, x16
    //     0x6f6134: b.ls            #0x6f6178
    // 0x6f6138: ldr             x0, [fp, #0x18]
    // 0x6f613c: LoadField: r1 = r0->field_13
    //     0x6f613c: ldur            w1, [x0, #0x13]
    // 0x6f6140: DecompressPointer r1
    //     0x6f6140: add             x1, x1, HEAP, lsl #32
    // 0x6f6144: ldr             x16, [fp, #0x10]
    // 0x6f6148: stp             x16, x1, [SP, #-0x10]!
    // 0x6f614c: r0 = remove()
    //     0x6f614c: bl              #0x6f5e78  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0x6f6150: add             SP, SP, #0x10
    // 0x6f6154: tbnz            w0, #4, #0x6f6168
    // 0x6f6158: ldr             x16, [fp, #0x18]
    // 0x6f615c: SaveReg r16
    //     0x6f615c: str             x16, [SP, #-8]!
    // 0x6f6160: r0 = didUnregisterListener()
    //     0x6f6160: bl              #0x6f6180  ; [package:flutter/src/animation/animations.dart] _CompoundAnimation&Animation&AnimationLazyListenerMixin::didUnregisterListener
    // 0x6f6164: add             SP, SP, #8
    // 0x6f6168: r0 = Null
    //     0x6f6168: mov             x0, NULL
    // 0x6f616c: LeaveFrame
    //     0x6f616c: mov             SP, fp
    //     0x6f6170: ldp             fp, lr, [SP], #0x10
    // 0x6f6174: ret
    //     0x6f6174: ret             
    // 0x6f6178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f6178: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f617c: b               #0x6f6138
  }
  _ notifyListeners(/* No info */) {
    // ** addr: 0xc3df44, size: 0x220
    // 0xc3df44: EnterFrame
    //     0xc3df44: stp             fp, lr, [SP, #-0x10]!
    //     0xc3df48: mov             fp, SP
    // 0xc3df4c: AllocStack(0x88)
    //     0xc3df4c: sub             SP, SP, #0x88
    // 0xc3df50: CheckStackOverflow
    //     0xc3df50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3df54: cmp             SP, x16
    //     0xc3df58: b.ls            #0xc3e150
    // 0xc3df5c: ldr             x0, [fp, #0x10]
    // 0xc3df60: LoadField: r1 = r0->field_13
    //     0xc3df60: ldur            w1, [x0, #0x13]
    // 0xc3df64: DecompressPointer r1
    //     0xc3df64: add             x1, x1, HEAP, lsl #32
    // 0xc3df68: r16 = false
    //     0xc3df68: add             x16, NULL, #0x30  ; false
    // 0xc3df6c: stp             x16, x1, [SP, #-0x10]!
    // 0xc3df70: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0xc3df70: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0xc3df74: r0 = toList()
    //     0xc3df74: bl              #0x6c0b5c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::toList
    // 0xc3df78: add             SP, SP, #0x10
    // 0xc3df7c: r1 = LoadClassIdInstr(r0)
    //     0xc3df7c: ldur            x1, [x0, #-1]
    //     0xc3df80: ubfx            x1, x1, #0xc, #0x14
    // 0xc3df84: SaveReg r0
    //     0xc3df84: str             x0, [SP, #-8]!
    // 0xc3df88: mov             x0, x1
    // 0xc3df8c: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc3df8c: mov             x17, #0xb940
    //     0xc3df90: add             lr, x0, x17
    //     0xc3df94: ldr             lr, [x21, lr, lsl #3]
    //     0xc3df98: blr             lr
    // 0xc3df9c: add             SP, SP, #8
    // 0xc3dfa0: ldr             x2, [fp, #0x10]
    // 0xc3dfa4: mov             x1, x0
    // 0xc3dfa8: b               #0xc3e09c
    // 0xc3dfac: sub             SP, fp, #0x88
    // 0xc3dfb0: mov             x3, x0
    // 0xc3dfb4: stur            x0, [fp, #-0x70]
    // 0xc3dfb8: mov             x0, x1
    // 0xc3dfbc: stur            x1, [fp, #-0x78]
    // 0xc3dfc0: r1 = Null
    //     0xc3dfc0: mov             x1, NULL
    // 0xc3dfc4: r2 = 4
    //     0xc3dfc4: mov             x2, #4
    // 0xc3dfc8: r0 = AllocateArray()
    //     0xc3dfc8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc3dfcc: stur            x0, [fp, #-0x80]
    // 0xc3dfd0: r17 = "while notifying listeners for "
    //     0xc3dfd0: add             x17, PP, #0xd, lsl #12  ; [pp+0xdc10] "while notifying listeners for "
    //     0xc3dfd4: ldr             x17, [x17, #0xc10]
    // 0xc3dfd8: StoreField: r0->field_f = r17
    //     0xc3dfd8: stur            w17, [x0, #0xf]
    // 0xc3dfdc: ldr             x16, [fp, #0x10]
    // 0xc3dfe0: SaveReg r16
    //     0xc3dfe0: str             x16, [SP, #-8]!
    // 0xc3dfe4: r0 = runtimeType()
    //     0xc3dfe4: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc3dfe8: add             SP, SP, #8
    // 0xc3dfec: ldur            x1, [fp, #-0x80]
    // 0xc3dff0: ArrayStore: r1[1] = r0  ; List_4
    //     0xc3dff0: add             x25, x1, #0x13
    //     0xc3dff4: str             w0, [x25]
    //     0xc3dff8: tbz             w0, #0, #0xc3e014
    //     0xc3dffc: ldurb           w16, [x1, #-1]
    //     0xc3e000: ldurb           w17, [x0, #-1]
    //     0xc3e004: and             x16, x17, x16, lsr #2
    //     0xc3e008: tst             x16, HEAP, lsr #32
    //     0xc3e00c: b.eq            #0xc3e014
    //     0xc3e010: bl              #0xd67e5c
    // 0xc3e014: ldur            x16, [fp, #-0x80]
    // 0xc3e018: SaveReg r16
    //     0xc3e018: str             x16, [SP, #-8]!
    // 0xc3e01c: r0 = _interpolate()
    //     0xc3e01c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc3e020: add             SP, SP, #8
    // 0xc3e024: r1 = <List<Object>>
    //     0xc3e024: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xc3e028: stur            x0, [fp, #-0x80]
    // 0xc3e02c: r0 = ErrorDescription()
    //     0xc3e02c: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xc3e030: stur            x0, [fp, #-0x88]
    // 0xc3e034: ldur            x16, [fp, #-0x80]
    // 0xc3e038: stp             x16, x0, [SP, #-0x10]!
    // 0xc3e03c: r16 = Instance_DiagnosticLevel
    //     0xc3e03c: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xc3e040: SaveReg r16
    //     0xc3e040: str             x16, [SP, #-8]!
    // 0xc3e044: r0 = _ErrorDiagnostic()
    //     0xc3e044: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xc3e048: add             SP, SP, #0x18
    // 0xc3e04c: r0 = FlutterErrorDetails()
    //     0xc3e04c: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0xc3e050: mov             x1, x0
    // 0xc3e054: ldur            x0, [fp, #-0x70]
    // 0xc3e058: StoreField: r1->field_7 = r0
    //     0xc3e058: stur            w0, [x1, #7]
    // 0xc3e05c: ldur            x0, [fp, #-0x78]
    // 0xc3e060: StoreField: r1->field_b = r0
    //     0xc3e060: stur            w0, [x1, #0xb]
    // 0xc3e064: r0 = "animation library"
    //     0xc3e064: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbf0] "animation library"
    //     0xc3e068: ldr             x0, [x0, #0xbf0]
    // 0xc3e06c: StoreField: r1->field_f = r0
    //     0xc3e06c: stur            w0, [x1, #0xf]
    // 0xc3e070: ldur            x0, [fp, #-0x88]
    // 0xc3e074: StoreField: r1->field_13 = r0
    //     0xc3e074: stur            w0, [x1, #0x13]
    // 0xc3e078: r0 = false
    //     0xc3e078: add             x0, NULL, #0x30  ; false
    // 0xc3e07c: StoreField: r1->field_1f = r0
    //     0xc3e07c: stur            w0, [x1, #0x1f]
    // 0xc3e080: SaveReg r1
    //     0xc3e080: str             x1, [SP, #-8]!
    // 0xc3e084: r0 = reportError()
    //     0xc3e084: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xc3e088: add             SP, SP, #8
    // 0xc3e08c: ldr             x1, [fp, #0x10]
    // 0xc3e090: ldur            x0, [fp, #-0x38]
    // 0xc3e094: mov             x2, x1
    // 0xc3e098: mov             x1, x0
    // 0xc3e09c: stur            x2, [fp, #-0x70]
    // 0xc3e0a0: stur            x1, [fp, #-0x78]
    // 0xc3e0a4: CheckStackOverflow
    //     0xc3e0a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3e0a8: cmp             SP, x16
    //     0xc3e0ac: b.ls            #0xc3e158
    // 0xc3e0b0: r0 = LoadClassIdInstr(r1)
    //     0xc3e0b0: ldur            x0, [x1, #-1]
    //     0xc3e0b4: ubfx            x0, x0, #0xc, #0x14
    // 0xc3e0b8: SaveReg r1
    //     0xc3e0b8: str             x1, [SP, #-8]!
    // 0xc3e0bc: r0 = GDT[cid_x0 + 0x541]()
    //     0xc3e0bc: add             lr, x0, #0x541
    //     0xc3e0c0: ldr             lr, [x21, lr, lsl #3]
    //     0xc3e0c4: blr             lr
    // 0xc3e0c8: add             SP, SP, #8
    // 0xc3e0cc: tbnz            w0, #4, #0xc3e140
    // 0xc3e0d0: ldur            x1, [fp, #-0x78]
    // 0xc3e0d4: r0 = LoadClassIdInstr(r1)
    //     0xc3e0d4: ldur            x0, [x1, #-1]
    //     0xc3e0d8: ubfx            x0, x0, #0xc, #0x14
    // 0xc3e0dc: SaveReg r1
    //     0xc3e0dc: str             x1, [SP, #-8]!
    // 0xc3e0e0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc3e0e0: add             lr, x0, #0x5ca
    //     0xc3e0e4: ldr             lr, [x21, lr, lsl #3]
    //     0xc3e0e8: blr             lr
    // 0xc3e0ec: add             SP, SP, #8
    // 0xc3e0f0: stur            x0, [fp, #-0x80]
    // 0xc3e0f4: ldur            x1, [fp, #-0x70]
    // 0xc3e0f8: LoadField: r2 = r1->field_13
    //     0xc3e0f8: ldur            w2, [x1, #0x13]
    // 0xc3e0fc: DecompressPointer r2
    //     0xc3e0fc: add             x2, x2, HEAP, lsl #32
    // 0xc3e100: stp             x0, x2, [SP, #-0x10]!
    // 0xc3e104: r0 = contains()
    //     0xc3e104: bl              #0x6b9fe4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0xc3e108: add             SP, SP, #0x10
    // 0xc3e10c: tbnz            w0, #4, #0xc3e134
    // 0xc3e110: ldur            x1, [fp, #-0x80]
    // 0xc3e114: cmp             w1, NULL
    // 0xc3e118: b.eq            #0xc3e160
    // 0xc3e11c: SaveReg r1
    //     0xc3e11c: str             x1, [SP, #-8]!
    // 0xc3e120: mov             x0, x1
    // 0xc3e124: ClosureCall
    //     0xc3e124: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc3e128: ldur            x2, [x0, #0x1f]
    //     0xc3e12c: blr             x2
    // 0xc3e130: add             SP, SP, #8
    // 0xc3e134: ldur            x1, [fp, #-0x70]
    // 0xc3e138: ldur            x0, [fp, #-0x78]
    // 0xc3e13c: b               #0xc3e094
    // 0xc3e140: r0 = Null
    //     0xc3e140: mov             x0, NULL
    // 0xc3e144: LeaveFrame
    //     0xc3e144: mov             SP, fp
    //     0xc3e148: ldp             fp, lr, [SP], #0x10
    // 0xc3e14c: ret
    //     0xc3e14c: ret             
    // 0xc3e150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3e150: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3e154: b               #0xc3df5c
    // 0xc3e158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3e158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3e15c: b               #0xc3e0b0
    // 0xc3e160: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc3e160: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 4332, size: 0x1c, field offset: 0x18
//   transformed mixin,
abstract class _CompoundAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin<X0> extends _CompoundAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin<X0>
     with AnimationLocalStatusListenersMixin {

  _ notifyStatusListeners(/* No info */) {
    // ** addr: 0xc3d690, size: 0x23c
    // 0xc3d690: EnterFrame
    //     0xc3d690: stp             fp, lr, [SP, #-0x10]!
    //     0xc3d694: mov             fp, SP
    // 0xc3d698: AllocStack(0x88)
    //     0xc3d698: sub             SP, SP, #0x88
    // 0xc3d69c: CheckStackOverflow
    //     0xc3d69c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3d6a0: cmp             SP, x16
    //     0xc3d6a4: b.ls            #0xc3d8b8
    // 0xc3d6a8: ldr             x0, [fp, #0x18]
    // 0xc3d6ac: LoadField: r1 = r0->field_17
    //     0xc3d6ac: ldur            w1, [x0, #0x17]
    // 0xc3d6b0: DecompressPointer r1
    //     0xc3d6b0: add             x1, x1, HEAP, lsl #32
    // 0xc3d6b4: r16 = false
    //     0xc3d6b4: add             x16, NULL, #0x30  ; false
    // 0xc3d6b8: stp             x16, x1, [SP, #-0x10]!
    // 0xc3d6bc: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0xc3d6bc: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0xc3d6c0: r0 = toList()
    //     0xc3d6c0: bl              #0x6c0b5c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::toList
    // 0xc3d6c4: add             SP, SP, #0x10
    // 0xc3d6c8: r1 = LoadClassIdInstr(r0)
    //     0xc3d6c8: ldur            x1, [x0, #-1]
    //     0xc3d6cc: ubfx            x1, x1, #0xc, #0x14
    // 0xc3d6d0: SaveReg r0
    //     0xc3d6d0: str             x0, [SP, #-8]!
    // 0xc3d6d4: mov             x0, x1
    // 0xc3d6d8: r0 = GDT[cid_x0 + 0xb940]()
    //     0xc3d6d8: mov             x17, #0xb940
    //     0xc3d6dc: add             lr, x0, x17
    //     0xc3d6e0: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d6e4: blr             lr
    // 0xc3d6e8: add             SP, SP, #8
    // 0xc3d6ec: mov             x1, x0
    // 0xc3d6f0: ldr             x0, [fp, #0x10]
    // 0xc3d6f4: ldr             x3, [fp, #0x18]
    // 0xc3d6f8: mov             x2, x0
    // 0xc3d6fc: b               #0xc3d7f8
    // 0xc3d700: sub             SP, fp, #0x88
    // 0xc3d704: mov             x3, x0
    // 0xc3d708: stur            x0, [fp, #-0x70]
    // 0xc3d70c: mov             x0, x1
    // 0xc3d710: stur            x1, [fp, #-0x78]
    // 0xc3d714: r1 = Null
    //     0xc3d714: mov             x1, NULL
    // 0xc3d718: r2 = 4
    //     0xc3d718: mov             x2, #4
    // 0xc3d71c: r0 = AllocateArray()
    //     0xc3d71c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc3d720: stur            x0, [fp, #-0x80]
    // 0xc3d724: r17 = "while notifying status listeners for "
    //     0xc3d724: add             x17, PP, #0xd, lsl #12  ; [pp+0xdbe8] "while notifying status listeners for "
    //     0xc3d728: ldr             x17, [x17, #0xbe8]
    // 0xc3d72c: StoreField: r0->field_f = r17
    //     0xc3d72c: stur            w17, [x0, #0xf]
    // 0xc3d730: ldr             x16, [fp, #0x18]
    // 0xc3d734: SaveReg r16
    //     0xc3d734: str             x16, [SP, #-8]!
    // 0xc3d738: r0 = runtimeType()
    //     0xc3d738: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc3d73c: add             SP, SP, #8
    // 0xc3d740: ldur            x1, [fp, #-0x80]
    // 0xc3d744: ArrayStore: r1[1] = r0  ; List_4
    //     0xc3d744: add             x25, x1, #0x13
    //     0xc3d748: str             w0, [x25]
    //     0xc3d74c: tbz             w0, #0, #0xc3d768
    //     0xc3d750: ldurb           w16, [x1, #-1]
    //     0xc3d754: ldurb           w17, [x0, #-1]
    //     0xc3d758: and             x16, x17, x16, lsr #2
    //     0xc3d75c: tst             x16, HEAP, lsr #32
    //     0xc3d760: b.eq            #0xc3d768
    //     0xc3d764: bl              #0xd67e5c
    // 0xc3d768: ldur            x16, [fp, #-0x80]
    // 0xc3d76c: SaveReg r16
    //     0xc3d76c: str             x16, [SP, #-8]!
    // 0xc3d770: r0 = _interpolate()
    //     0xc3d770: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc3d774: add             SP, SP, #8
    // 0xc3d778: r1 = <List<Object>>
    //     0xc3d778: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0xc3d77c: stur            x0, [fp, #-0x80]
    // 0xc3d780: r0 = ErrorDescription()
    //     0xc3d780: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0xc3d784: stur            x0, [fp, #-0x88]
    // 0xc3d788: ldur            x16, [fp, #-0x80]
    // 0xc3d78c: stp             x16, x0, [SP, #-0x10]!
    // 0xc3d790: r16 = Instance_DiagnosticLevel
    //     0xc3d790: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0xc3d794: SaveReg r16
    //     0xc3d794: str             x16, [SP, #-8]!
    // 0xc3d798: r0 = _ErrorDiagnostic()
    //     0xc3d798: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xc3d79c: add             SP, SP, #0x18
    // 0xc3d7a0: r0 = FlutterErrorDetails()
    //     0xc3d7a0: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0xc3d7a4: mov             x1, x0
    // 0xc3d7a8: ldur            x0, [fp, #-0x70]
    // 0xc3d7ac: StoreField: r1->field_7 = r0
    //     0xc3d7ac: stur            w0, [x1, #7]
    // 0xc3d7b0: ldur            x0, [fp, #-0x78]
    // 0xc3d7b4: StoreField: r1->field_b = r0
    //     0xc3d7b4: stur            w0, [x1, #0xb]
    // 0xc3d7b8: r0 = "animation library"
    //     0xc3d7b8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbf0] "animation library"
    //     0xc3d7bc: ldr             x0, [x0, #0xbf0]
    // 0xc3d7c0: StoreField: r1->field_f = r0
    //     0xc3d7c0: stur            w0, [x1, #0xf]
    // 0xc3d7c4: ldur            x0, [fp, #-0x88]
    // 0xc3d7c8: StoreField: r1->field_13 = r0
    //     0xc3d7c8: stur            w0, [x1, #0x13]
    // 0xc3d7cc: r0 = false
    //     0xc3d7cc: add             x0, NULL, #0x30  ; false
    // 0xc3d7d0: StoreField: r1->field_1f = r0
    //     0xc3d7d0: stur            w0, [x1, #0x1f]
    // 0xc3d7d4: SaveReg r1
    //     0xc3d7d4: str             x1, [SP, #-8]!
    // 0xc3d7d8: r0 = reportError()
    //     0xc3d7d8: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0xc3d7dc: add             SP, SP, #8
    // 0xc3d7e0: ldr             x2, [fp, #0x18]
    // 0xc3d7e4: ldr             x1, [fp, #0x10]
    // 0xc3d7e8: ldur            x0, [fp, #-0x38]
    // 0xc3d7ec: mov             x3, x2
    // 0xc3d7f0: mov             x2, x1
    // 0xc3d7f4: mov             x1, x0
    // 0xc3d7f8: stur            x3, [fp, #-0x70]
    // 0xc3d7fc: stur            x2, [fp, #-0x78]
    // 0xc3d800: stur            x1, [fp, #-0x80]
    // 0xc3d804: CheckStackOverflow
    //     0xc3d804: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3d808: cmp             SP, x16
    //     0xc3d80c: b.ls            #0xc3d8c0
    // 0xc3d810: r0 = LoadClassIdInstr(r1)
    //     0xc3d810: ldur            x0, [x1, #-1]
    //     0xc3d814: ubfx            x0, x0, #0xc, #0x14
    // 0xc3d818: SaveReg r1
    //     0xc3d818: str             x1, [SP, #-8]!
    // 0xc3d81c: r0 = GDT[cid_x0 + 0x541]()
    //     0xc3d81c: add             lr, x0, #0x541
    //     0xc3d820: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d824: blr             lr
    // 0xc3d828: add             SP, SP, #8
    // 0xc3d82c: tbnz            w0, #4, #0xc3d8a8
    // 0xc3d830: ldur            x1, [fp, #-0x80]
    // 0xc3d834: r0 = LoadClassIdInstr(r1)
    //     0xc3d834: ldur            x0, [x1, #-1]
    //     0xc3d838: ubfx            x0, x0, #0xc, #0x14
    // 0xc3d83c: SaveReg r1
    //     0xc3d83c: str             x1, [SP, #-8]!
    // 0xc3d840: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xc3d840: add             lr, x0, #0x5ca
    //     0xc3d844: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d848: blr             lr
    // 0xc3d84c: add             SP, SP, #8
    // 0xc3d850: stur            x0, [fp, #-0x88]
    // 0xc3d854: ldur            x2, [fp, #-0x70]
    // 0xc3d858: LoadField: r1 = r2->field_17
    //     0xc3d858: ldur            w1, [x2, #0x17]
    // 0xc3d85c: DecompressPointer r1
    //     0xc3d85c: add             x1, x1, HEAP, lsl #32
    // 0xc3d860: stp             x0, x1, [SP, #-0x10]!
    // 0xc3d864: r0 = contains()
    //     0xc3d864: bl              #0x6b9fe4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0xc3d868: add             SP, SP, #0x10
    // 0xc3d86c: tbnz            w0, #4, #0xc3d898
    // 0xc3d870: ldur            x1, [fp, #-0x88]
    // 0xc3d874: cmp             w1, NULL
    // 0xc3d878: b.eq            #0xc3d8c8
    // 0xc3d87c: ldur            x16, [fp, #-0x78]
    // 0xc3d880: stp             x16, x1, [SP, #-0x10]!
    // 0xc3d884: mov             x0, x1
    // 0xc3d888: ClosureCall
    //     0xc3d888: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc3d88c: ldur            x2, [x0, #0x1f]
    //     0xc3d890: blr             x2
    // 0xc3d894: add             SP, SP, #0x10
    // 0xc3d898: ldur            x2, [fp, #-0x70]
    // 0xc3d89c: ldur            x1, [fp, #-0x78]
    // 0xc3d8a0: ldur            x0, [fp, #-0x80]
    // 0xc3d8a4: b               #0xc3d7ec
    // 0xc3d8a8: r0 = Null
    //     0xc3d8a8: mov             x0, NULL
    // 0xc3d8ac: LeaveFrame
    //     0xc3d8ac: mov             SP, fp
    //     0xc3d8b0: ldp             fp, lr, [SP], #0x10
    // 0xc3d8b4: ret
    //     0xc3d8b4: ret             
    // 0xc3d8b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3d8b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3d8bc: b               #0xc3d6a8
    // 0xc3d8c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3d8c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3d8c4: b               #0xc3d810
    // 0xc3d8c8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc3d8c8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ addStatusListener(/* No info */) {
    // ** addr: 0xc52fb8, size: 0x58
    // 0xc52fb8: EnterFrame
    //     0xc52fb8: stp             fp, lr, [SP, #-0x10]!
    //     0xc52fbc: mov             fp, SP
    // 0xc52fc0: CheckStackOverflow
    //     0xc52fc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc52fc4: cmp             SP, x16
    //     0xc52fc8: b.ls            #0xc53008
    // 0xc52fcc: ldr             x16, [fp, #0x18]
    // 0xc52fd0: SaveReg r16
    //     0xc52fd0: str             x16, [SP, #-8]!
    // 0xc52fd4: r0 = didRegisterListener()
    //     0xc52fd4: bl              #0x6e94f8  ; [package:flutter/src/animation/animations.dart] _CompoundAnimation&Animation&AnimationLazyListenerMixin::didRegisterListener
    // 0xc52fd8: add             SP, SP, #8
    // 0xc52fdc: ldr             x0, [fp, #0x18]
    // 0xc52fe0: LoadField: r1 = r0->field_17
    //     0xc52fe0: ldur            w1, [x0, #0x17]
    // 0xc52fe4: DecompressPointer r1
    //     0xc52fe4: add             x1, x1, HEAP, lsl #32
    // 0xc52fe8: ldr             x16, [fp, #0x10]
    // 0xc52fec: stp             x16, x1, [SP, #-0x10]!
    // 0xc52ff0: r0 = add()
    //     0xc52ff0: bl              #0x6e93b4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::add
    // 0xc52ff4: add             SP, SP, #0x10
    // 0xc52ff8: r0 = Null
    //     0xc52ff8: mov             x0, NULL
    // 0xc52ffc: LeaveFrame
    //     0xc52ffc: mov             SP, fp
    //     0xc53000: ldp             fp, lr, [SP], #0x10
    // 0xc53004: ret
    //     0xc53004: ret             
    // 0xc53008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc53008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5300c: b               #0xc52fcc
  }
  _ removeStatusListener(/* No info */) {
    // ** addr: 0xc5e014, size: 0x5c
    // 0xc5e014: EnterFrame
    //     0xc5e014: stp             fp, lr, [SP, #-0x10]!
    //     0xc5e018: mov             fp, SP
    // 0xc5e01c: CheckStackOverflow
    //     0xc5e01c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5e020: cmp             SP, x16
    //     0xc5e024: b.ls            #0xc5e068
    // 0xc5e028: ldr             x0, [fp, #0x18]
    // 0xc5e02c: LoadField: r1 = r0->field_17
    //     0xc5e02c: ldur            w1, [x0, #0x17]
    // 0xc5e030: DecompressPointer r1
    //     0xc5e030: add             x1, x1, HEAP, lsl #32
    // 0xc5e034: ldr             x16, [fp, #0x10]
    // 0xc5e038: stp             x16, x1, [SP, #-0x10]!
    // 0xc5e03c: r0 = remove()
    //     0xc5e03c: bl              #0x6f5e78  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0xc5e040: add             SP, SP, #0x10
    // 0xc5e044: tbnz            w0, #4, #0xc5e058
    // 0xc5e048: ldr             x16, [fp, #0x18]
    // 0xc5e04c: SaveReg r16
    //     0xc5e04c: str             x16, [SP, #-8]!
    // 0xc5e050: r0 = didUnregisterListener()
    //     0xc5e050: bl              #0x6f6180  ; [package:flutter/src/animation/animations.dart] _CompoundAnimation&Animation&AnimationLazyListenerMixin::didUnregisterListener
    // 0xc5e054: add             SP, SP, #8
    // 0xc5e058: r0 = Null
    //     0xc5e058: mov             x0, NULL
    // 0xc5e05c: LeaveFrame
    //     0xc5e05c: mov             SP, fp
    //     0xc5e060: ldp             fp, lr, [SP], #0x10
    // 0xc5e064: ret
    //     0xc5e064: ret             
    // 0xc5e068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5e068: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5e06c: b               #0xc5e028
  }
}

// class id: 4333, size: 0x2c, field offset: 0x1c
abstract class CompoundAnimation<X0> extends _CompoundAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin<X0> {

  _ CompoundAnimation(/* No info */) {
    // ** addr: 0x7b9d00, size: 0x16c
    // 0x7b9d00: EnterFrame
    //     0x7b9d00: stp             fp, lr, [SP, #-0x10]!
    //     0x7b9d04: mov             fp, SP
    // 0x7b9d08: AllocStack(0x8)
    //     0x7b9d08: sub             SP, SP, #8
    // 0x7b9d0c: CheckStackOverflow
    //     0x7b9d0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b9d10: cmp             SP, x16
    //     0x7b9d14: b.ls            #0x7b9e64
    // 0x7b9d18: ldr             x0, [fp, #0x18]
    // 0x7b9d1c: ldr             x2, [fp, #0x20]
    // 0x7b9d20: StoreField: r2->field_1b = r0
    //     0x7b9d20: stur            w0, [x2, #0x1b]
    //     0x7b9d24: ldurb           w16, [x2, #-1]
    //     0x7b9d28: ldurb           w17, [x0, #-1]
    //     0x7b9d2c: and             x16, x17, x16, lsr #2
    //     0x7b9d30: tst             x16, HEAP, lsr #32
    //     0x7b9d34: b.eq            #0x7b9d3c
    //     0x7b9d38: bl              #0xd6828c
    // 0x7b9d3c: ldr             x0, [fp, #0x10]
    // 0x7b9d40: StoreField: r2->field_1f = r0
    //     0x7b9d40: stur            w0, [x2, #0x1f]
    //     0x7b9d44: ldurb           w16, [x2, #-1]
    //     0x7b9d48: ldurb           w17, [x0, #-1]
    //     0x7b9d4c: and             x16, x17, x16, lsr #2
    //     0x7b9d50: tst             x16, HEAP, lsr #32
    //     0x7b9d54: b.eq            #0x7b9d5c
    //     0x7b9d58: bl              #0xd6828c
    // 0x7b9d5c: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x7b9d5c: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x7b9d60: ldr             x1, [x1, #0x3d8]
    // 0x7b9d64: r0 = ObserverList()
    //     0x7b9d64: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x7b9d68: mov             x1, x0
    // 0x7b9d6c: r0 = false
    //     0x7b9d6c: add             x0, NULL, #0x30  ; false
    // 0x7b9d70: stur            x1, [fp, #-8]
    // 0x7b9d74: StoreField: r1->field_f = r0
    //     0x7b9d74: stur            w0, [x1, #0xf]
    // 0x7b9d78: r2 = Sentinel
    //     0x7b9d78: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b9d7c: StoreField: r1->field_13 = r2
    //     0x7b9d7c: stur            w2, [x1, #0x13]
    // 0x7b9d80: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x7b9d80: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x7b9d84: ldr             x16, [x16, #0x3d8]
    // 0x7b9d88: stp             xzr, x16, [SP, #-0x10]!
    // 0x7b9d8c: r0 = _GrowableList()
    //     0x7b9d8c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7b9d90: add             SP, SP, #0x10
    // 0x7b9d94: ldur            x1, [fp, #-8]
    // 0x7b9d98: StoreField: r1->field_b = r0
    //     0x7b9d98: stur            w0, [x1, #0xb]
    //     0x7b9d9c: ldurb           w16, [x1, #-1]
    //     0x7b9da0: ldurb           w17, [x0, #-1]
    //     0x7b9da4: and             x16, x17, x16, lsr #2
    //     0x7b9da8: tst             x16, HEAP, lsr #32
    //     0x7b9dac: b.eq            #0x7b9db4
    //     0x7b9db0: bl              #0xd6826c
    // 0x7b9db4: mov             x0, x1
    // 0x7b9db8: ldr             x2, [fp, #0x20]
    // 0x7b9dbc: StoreField: r2->field_17 = r0
    //     0x7b9dbc: stur            w0, [x2, #0x17]
    //     0x7b9dc0: ldurb           w16, [x2, #-1]
    //     0x7b9dc4: ldurb           w17, [x0, #-1]
    //     0x7b9dc8: and             x16, x17, x16, lsr #2
    //     0x7b9dcc: tst             x16, HEAP, lsr #32
    //     0x7b9dd0: b.eq            #0x7b9dd8
    //     0x7b9dd4: bl              #0xd6828c
    // 0x7b9dd8: r1 = <(dynamic this) => void?>
    //     0x7b9dd8: ldr             x1, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0x7b9ddc: r0 = ObserverList()
    //     0x7b9ddc: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x7b9de0: mov             x1, x0
    // 0x7b9de4: r0 = false
    //     0x7b9de4: add             x0, NULL, #0x30  ; false
    // 0x7b9de8: stur            x1, [fp, #-8]
    // 0x7b9dec: StoreField: r1->field_f = r0
    //     0x7b9dec: stur            w0, [x1, #0xf]
    // 0x7b9df0: r0 = Sentinel
    //     0x7b9df0: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b9df4: StoreField: r1->field_13 = r0
    //     0x7b9df4: stur            w0, [x1, #0x13]
    // 0x7b9df8: r16 = <(dynamic this) => void?>
    //     0x7b9df8: ldr             x16, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0x7b9dfc: stp             xzr, x16, [SP, #-0x10]!
    // 0x7b9e00: r0 = _GrowableList()
    //     0x7b9e00: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7b9e04: add             SP, SP, #0x10
    // 0x7b9e08: ldur            x1, [fp, #-8]
    // 0x7b9e0c: StoreField: r1->field_b = r0
    //     0x7b9e0c: stur            w0, [x1, #0xb]
    //     0x7b9e10: ldurb           w16, [x1, #-1]
    //     0x7b9e14: ldurb           w17, [x0, #-1]
    //     0x7b9e18: and             x16, x17, x16, lsr #2
    //     0x7b9e1c: tst             x16, HEAP, lsr #32
    //     0x7b9e20: b.eq            #0x7b9e28
    //     0x7b9e24: bl              #0xd6826c
    // 0x7b9e28: mov             x0, x1
    // 0x7b9e2c: ldr             x1, [fp, #0x20]
    // 0x7b9e30: StoreField: r1->field_13 = r0
    //     0x7b9e30: stur            w0, [x1, #0x13]
    //     0x7b9e34: ldurb           w16, [x1, #-1]
    //     0x7b9e38: ldurb           w17, [x0, #-1]
    //     0x7b9e3c: and             x16, x17, x16, lsr #2
    //     0x7b9e40: tst             x16, HEAP, lsr #32
    //     0x7b9e44: b.eq            #0x7b9e4c
    //     0x7b9e48: bl              #0xd6826c
    // 0x7b9e4c: r2 = 0
    //     0x7b9e4c: mov             x2, #0
    // 0x7b9e50: StoreField: r1->field_b = r2
    //     0x7b9e50: stur            x2, [x1, #0xb]
    // 0x7b9e54: r0 = Null
    //     0x7b9e54: mov             x0, NULL
    // 0x7b9e58: LeaveFrame
    //     0x7b9e58: mov             SP, fp
    //     0x7b9e5c: ldp             fp, lr, [SP], #0x10
    // 0x7b9e60: ret
    //     0x7b9e60: ret             
    // 0x7b9e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b9e64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b9e68: b               #0x7b9d18
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4b58, size: 0x80
    // 0xad4b58: EnterFrame
    //     0xad4b58: stp             fp, lr, [SP, #-0x10]!
    //     0xad4b5c: mov             fp, SP
    // 0xad4b60: CheckStackOverflow
    //     0xad4b60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4b64: cmp             SP, x16
    //     0xad4b68: b.ls            #0xad4bd0
    // 0xad4b6c: r1 = Null
    //     0xad4b6c: mov             x1, NULL
    // 0xad4b70: r2 = 12
    //     0xad4b70: mov             x2, #0xc
    // 0xad4b74: r0 = AllocateArray()
    //     0xad4b74: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4b78: r17 = "CompoundAnimation"
    //     0xad4b78: add             x17, PP, #0x37, lsl #12  ; [pp+0x37d60] "CompoundAnimation"
    //     0xad4b7c: ldr             x17, [x17, #0xd60]
    // 0xad4b80: StoreField: r0->field_f = r17
    //     0xad4b80: stur            w17, [x0, #0xf]
    // 0xad4b84: r17 = "("
    //     0xad4b84: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad4b88: StoreField: r0->field_13 = r17
    //     0xad4b88: stur            w17, [x0, #0x13]
    // 0xad4b8c: ldr             x1, [fp, #0x10]
    // 0xad4b90: LoadField: r2 = r1->field_1b
    //     0xad4b90: ldur            w2, [x1, #0x1b]
    // 0xad4b94: DecompressPointer r2
    //     0xad4b94: add             x2, x2, HEAP, lsl #32
    // 0xad4b98: StoreField: r0->field_17 = r2
    //     0xad4b98: stur            w2, [x0, #0x17]
    // 0xad4b9c: r17 = ", "
    //     0xad4b9c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad4ba0: StoreField: r0->field_1b = r17
    //     0xad4ba0: stur            w17, [x0, #0x1b]
    // 0xad4ba4: LoadField: r2 = r1->field_1f
    //     0xad4ba4: ldur            w2, [x1, #0x1f]
    // 0xad4ba8: DecompressPointer r2
    //     0xad4ba8: add             x2, x2, HEAP, lsl #32
    // 0xad4bac: StoreField: r0->field_1f = r2
    //     0xad4bac: stur            w2, [x0, #0x1f]
    // 0xad4bb0: r17 = ")"
    //     0xad4bb0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad4bb4: StoreField: r0->field_23 = r17
    //     0xad4bb4: stur            w17, [x0, #0x23]
    // 0xad4bb8: SaveReg r0
    //     0xad4bb8: str             x0, [SP, #-8]!
    // 0xad4bbc: r0 = _interpolate()
    //     0xad4bbc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4bc0: add             SP, SP, #8
    // 0xad4bc4: LeaveFrame
    //     0xad4bc4: mov             SP, fp
    //     0xad4bc8: ldp             fp, lr, [SP], #0x10
    // 0xad4bcc: ret
    //     0xad4bcc: ret             
    // 0xad4bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4bd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4bd4: b               #0xad4b6c
  }
  _ didStopListening(/* No info */) {
    // ** addr: 0xc3d428, size: 0x180
    // 0xc3d428: EnterFrame
    //     0xc3d428: stp             fp, lr, [SP, #-0x10]!
    //     0xc3d42c: mov             fp, SP
    // 0xc3d430: AllocStack(0x8)
    //     0xc3d430: sub             SP, SP, #8
    // 0xc3d434: CheckStackOverflow
    //     0xc3d434: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3d438: cmp             SP, x16
    //     0xc3d43c: b.ls            #0xc3d5a0
    // 0xc3d440: ldr             x0, [fp, #0x10]
    // 0xc3d444: LoadField: r1 = r0->field_1b
    //     0xc3d444: ldur            w1, [x0, #0x1b]
    // 0xc3d448: DecompressPointer r1
    //     0xc3d448: add             x1, x1, HEAP, lsl #32
    // 0xc3d44c: stur            x1, [fp, #-8]
    // 0xc3d450: r1 = 1
    //     0xc3d450: mov             x1, #1
    // 0xc3d454: r0 = AllocateContext()
    //     0xc3d454: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc3d458: mov             x1, x0
    // 0xc3d45c: ldr             x0, [fp, #0x10]
    // 0xc3d460: StoreField: r1->field_f = r0
    //     0xc3d460: stur            w0, [x1, #0xf]
    // 0xc3d464: mov             x2, x1
    // 0xc3d468: r1 = Function '_maybeNotifyListeners@576411118':.
    //     0xc3d468: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0a0] AnonymousClosure: (0xc3d8cc), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyListeners (0xc3d914)
    //     0xc3d46c: ldr             x1, [x1, #0xa0]
    // 0xc3d470: r0 = AllocateClosure()
    //     0xc3d470: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc3d474: ldur            x1, [fp, #-8]
    // 0xc3d478: r2 = LoadClassIdInstr(r1)
    //     0xc3d478: ldur            x2, [x1, #-1]
    //     0xc3d47c: ubfx            x2, x2, #0xc, #0x14
    // 0xc3d480: stp             x0, x1, [SP, #-0x10]!
    // 0xc3d484: mov             x0, x2
    // 0xc3d488: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xc3d488: mov             x17, #0xc2d6
    //     0xc3d48c: add             lr, x0, x17
    //     0xc3d490: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d494: blr             lr
    // 0xc3d498: add             SP, SP, #0x10
    // 0xc3d49c: r1 = 1
    //     0xc3d49c: mov             x1, #1
    // 0xc3d4a0: r0 = AllocateContext()
    //     0xc3d4a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc3d4a4: mov             x1, x0
    // 0xc3d4a8: ldr             x0, [fp, #0x10]
    // 0xc3d4ac: StoreField: r1->field_f = r0
    //     0xc3d4ac: stur            w0, [x1, #0xf]
    // 0xc3d4b0: mov             x2, x1
    // 0xc3d4b4: r1 = Function '_maybeNotifyStatusListeners@576411118':.
    //     0xc3d4b4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0a8] AnonymousClosure: (0xc3d5a8), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyStatusListeners (0xc3d5f4)
    //     0xc3d4b8: ldr             x1, [x1, #0xa8]
    // 0xc3d4bc: r0 = AllocateClosure()
    //     0xc3d4bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc3d4c0: mov             x1, x0
    // 0xc3d4c4: ldur            x0, [fp, #-8]
    // 0xc3d4c8: r2 = LoadClassIdInstr(r0)
    //     0xc3d4c8: ldur            x2, [x0, #-1]
    //     0xc3d4cc: ubfx            x2, x2, #0xc, #0x14
    // 0xc3d4d0: stp             x1, x0, [SP, #-0x10]!
    // 0xc3d4d4: mov             x0, x2
    // 0xc3d4d8: r0 = GDT[cid_x0 + 0x490]()
    //     0xc3d4d8: add             lr, x0, #0x490
    //     0xc3d4dc: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d4e0: blr             lr
    // 0xc3d4e4: add             SP, SP, #0x10
    // 0xc3d4e8: ldr             x0, [fp, #0x10]
    // 0xc3d4ec: LoadField: r1 = r0->field_1f
    //     0xc3d4ec: ldur            w1, [x0, #0x1f]
    // 0xc3d4f0: DecompressPointer r1
    //     0xc3d4f0: add             x1, x1, HEAP, lsl #32
    // 0xc3d4f4: stur            x1, [fp, #-8]
    // 0xc3d4f8: r1 = 1
    //     0xc3d4f8: mov             x1, #1
    // 0xc3d4fc: r0 = AllocateContext()
    //     0xc3d4fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc3d500: mov             x1, x0
    // 0xc3d504: ldr             x0, [fp, #0x10]
    // 0xc3d508: StoreField: r1->field_f = r0
    //     0xc3d508: stur            w0, [x1, #0xf]
    // 0xc3d50c: mov             x2, x1
    // 0xc3d510: r1 = Function '_maybeNotifyListeners@576411118':.
    //     0xc3d510: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0a0] AnonymousClosure: (0xc3d8cc), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyListeners (0xc3d914)
    //     0xc3d514: ldr             x1, [x1, #0xa0]
    // 0xc3d518: r0 = AllocateClosure()
    //     0xc3d518: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc3d51c: ldur            x1, [fp, #-8]
    // 0xc3d520: r2 = LoadClassIdInstr(r1)
    //     0xc3d520: ldur            x2, [x1, #-1]
    //     0xc3d524: ubfx            x2, x2, #0xc, #0x14
    // 0xc3d528: stp             x0, x1, [SP, #-0x10]!
    // 0xc3d52c: mov             x0, x2
    // 0xc3d530: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xc3d530: mov             x17, #0xc2d6
    //     0xc3d534: add             lr, x0, x17
    //     0xc3d538: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d53c: blr             lr
    // 0xc3d540: add             SP, SP, #0x10
    // 0xc3d544: r1 = 1
    //     0xc3d544: mov             x1, #1
    // 0xc3d548: r0 = AllocateContext()
    //     0xc3d548: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc3d54c: mov             x1, x0
    // 0xc3d550: ldr             x0, [fp, #0x10]
    // 0xc3d554: StoreField: r1->field_f = r0
    //     0xc3d554: stur            w0, [x1, #0xf]
    // 0xc3d558: mov             x2, x1
    // 0xc3d55c: r1 = Function '_maybeNotifyStatusListeners@576411118':.
    //     0xc3d55c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0a8] AnonymousClosure: (0xc3d5a8), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyStatusListeners (0xc3d5f4)
    //     0xc3d560: ldr             x1, [x1, #0xa8]
    // 0xc3d564: r0 = AllocateClosure()
    //     0xc3d564: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc3d568: mov             x1, x0
    // 0xc3d56c: ldur            x0, [fp, #-8]
    // 0xc3d570: r2 = LoadClassIdInstr(r0)
    //     0xc3d570: ldur            x2, [x0, #-1]
    //     0xc3d574: ubfx            x2, x2, #0xc, #0x14
    // 0xc3d578: stp             x1, x0, [SP, #-0x10]!
    // 0xc3d57c: mov             x0, x2
    // 0xc3d580: r0 = GDT[cid_x0 + 0x490]()
    //     0xc3d580: add             lr, x0, #0x490
    //     0xc3d584: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d588: blr             lr
    // 0xc3d58c: add             SP, SP, #0x10
    // 0xc3d590: r0 = Null
    //     0xc3d590: mov             x0, NULL
    // 0xc3d594: LeaveFrame
    //     0xc3d594: mov             SP, fp
    //     0xc3d598: ldp             fp, lr, [SP], #0x10
    // 0xc3d59c: ret
    //     0xc3d59c: ret             
    // 0xc3d5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3d5a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3d5a4: b               #0xc3d440
  }
  [closure] void _maybeNotifyStatusListeners(dynamic, AnimationStatus) {
    // ** addr: 0xc3d5a8, size: 0x4c
    // 0xc3d5a8: EnterFrame
    //     0xc3d5a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc3d5ac: mov             fp, SP
    // 0xc3d5b0: ldr             x0, [fp, #0x18]
    // 0xc3d5b4: LoadField: r1 = r0->field_17
    //     0xc3d5b4: ldur            w1, [x0, #0x17]
    // 0xc3d5b8: DecompressPointer r1
    //     0xc3d5b8: add             x1, x1, HEAP, lsl #32
    // 0xc3d5bc: CheckStackOverflow
    //     0xc3d5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3d5c0: cmp             SP, x16
    //     0xc3d5c4: b.ls            #0xc3d5ec
    // 0xc3d5c8: LoadField: r0 = r1->field_f
    //     0xc3d5c8: ldur            w0, [x1, #0xf]
    // 0xc3d5cc: DecompressPointer r0
    //     0xc3d5cc: add             x0, x0, HEAP, lsl #32
    // 0xc3d5d0: ldr             x16, [fp, #0x10]
    // 0xc3d5d4: stp             x16, x0, [SP, #-0x10]!
    // 0xc3d5d8: r0 = _maybeNotifyStatusListeners()
    //     0xc3d5d8: bl              #0xc3d5f4  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyStatusListeners
    // 0xc3d5dc: add             SP, SP, #0x10
    // 0xc3d5e0: LeaveFrame
    //     0xc3d5e0: mov             SP, fp
    //     0xc3d5e4: ldp             fp, lr, [SP], #0x10
    // 0xc3d5e8: ret
    //     0xc3d5e8: ret             
    // 0xc3d5ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3d5ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3d5f0: b               #0xc3d5c8
  }
  _ _maybeNotifyStatusListeners(/* No info */) {
    // ** addr: 0xc3d5f4, size: 0x9c
    // 0xc3d5f4: EnterFrame
    //     0xc3d5f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc3d5f8: mov             fp, SP
    // 0xc3d5fc: CheckStackOverflow
    //     0xc3d5fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3d600: cmp             SP, x16
    //     0xc3d604: b.ls            #0xc3d688
    // 0xc3d608: ldr             x16, [fp, #0x18]
    // 0xc3d60c: SaveReg r16
    //     0xc3d60c: str             x16, [SP, #-8]!
    // 0xc3d610: r0 = status()
    //     0xc3d610: bl              #0xc64888  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::status
    // 0xc3d614: add             SP, SP, #8
    // 0xc3d618: mov             x1, x0
    // 0xc3d61c: ldr             x0, [fp, #0x18]
    // 0xc3d620: LoadField: r2 = r0->field_23
    //     0xc3d620: ldur            w2, [x0, #0x23]
    // 0xc3d624: DecompressPointer r2
    //     0xc3d624: add             x2, x2, HEAP, lsl #32
    // 0xc3d628: cmp             w1, w2
    // 0xc3d62c: b.eq            #0xc3d678
    // 0xc3d630: SaveReg r0
    //     0xc3d630: str             x0, [SP, #-8]!
    // 0xc3d634: r0 = status()
    //     0xc3d634: bl              #0xc64888  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::status
    // 0xc3d638: add             SP, SP, #8
    // 0xc3d63c: ldr             x1, [fp, #0x18]
    // 0xc3d640: StoreField: r1->field_23 = r0
    //     0xc3d640: stur            w0, [x1, #0x23]
    //     0xc3d644: ldurb           w16, [x1, #-1]
    //     0xc3d648: ldurb           w17, [x0, #-1]
    //     0xc3d64c: and             x16, x17, x16, lsr #2
    //     0xc3d650: tst             x16, HEAP, lsr #32
    //     0xc3d654: b.eq            #0xc3d65c
    //     0xc3d658: bl              #0xd6826c
    // 0xc3d65c: SaveReg r1
    //     0xc3d65c: str             x1, [SP, #-8]!
    // 0xc3d660: r0 = status()
    //     0xc3d660: bl              #0xc64888  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::status
    // 0xc3d664: add             SP, SP, #8
    // 0xc3d668: ldr             x16, [fp, #0x18]
    // 0xc3d66c: stp             x0, x16, [SP, #-0x10]!
    // 0xc3d670: r0 = notifyStatusListeners()
    //     0xc3d670: bl              #0xc3d690  ; [package:flutter/src/animation/animations.dart] _CompoundAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0xc3d674: add             SP, SP, #0x10
    // 0xc3d678: r0 = Null
    //     0xc3d678: mov             x0, NULL
    // 0xc3d67c: LeaveFrame
    //     0xc3d67c: mov             SP, fp
    //     0xc3d680: ldp             fp, lr, [SP], #0x10
    // 0xc3d684: ret
    //     0xc3d684: ret             
    // 0xc3d688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3d688: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3d68c: b               #0xc3d608
  }
  [closure] void _maybeNotifyListeners(dynamic) {
    // ** addr: 0xc3d8cc, size: 0x48
    // 0xc3d8cc: EnterFrame
    //     0xc3d8cc: stp             fp, lr, [SP, #-0x10]!
    //     0xc3d8d0: mov             fp, SP
    // 0xc3d8d4: ldr             x0, [fp, #0x10]
    // 0xc3d8d8: LoadField: r1 = r0->field_17
    //     0xc3d8d8: ldur            w1, [x0, #0x17]
    // 0xc3d8dc: DecompressPointer r1
    //     0xc3d8dc: add             x1, x1, HEAP, lsl #32
    // 0xc3d8e0: CheckStackOverflow
    //     0xc3d8e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3d8e4: cmp             SP, x16
    //     0xc3d8e8: b.ls            #0xc3d90c
    // 0xc3d8ec: LoadField: r0 = r1->field_f
    //     0xc3d8ec: ldur            w0, [x1, #0xf]
    // 0xc3d8f0: DecompressPointer r0
    //     0xc3d8f0: add             x0, x0, HEAP, lsl #32
    // 0xc3d8f4: SaveReg r0
    //     0xc3d8f4: str             x0, [SP, #-8]!
    // 0xc3d8f8: r0 = _maybeNotifyListeners()
    //     0xc3d8f8: bl              #0xc3d914  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyListeners
    // 0xc3d8fc: add             SP, SP, #8
    // 0xc3d900: LeaveFrame
    //     0xc3d900: mov             SP, fp
    //     0xc3d904: ldp             fp, lr, [SP], #0x10
    // 0xc3d908: ret
    //     0xc3d908: ret             
    // 0xc3d90c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3d90c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3d910: b               #0xc3d8ec
  }
  _ _maybeNotifyListeners(/* No info */) {
    // ** addr: 0xc3d914, size: 0x630
    // 0xc3d914: EnterFrame
    //     0xc3d914: stp             fp, lr, [SP, #-0x10]!
    //     0xc3d918: mov             fp, SP
    // 0xc3d91c: AllocStack(0x28)
    //     0xc3d91c: sub             SP, SP, #0x28
    // 0xc3d920: CheckStackOverflow
    //     0xc3d920: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3d924: cmp             SP, x16
    //     0xc3d928: b.ls            #0xc3defc
    // 0xc3d92c: ldr             x1, [fp, #0x10]
    // 0xc3d930: r2 = LoadClassIdInstr(r1)
    //     0xc3d930: ldur            x2, [x1, #-1]
    //     0xc3d934: ubfx            x2, x2, #0xc, #0x14
    // 0xc3d938: lsl             x2, x2, #1
    // 0xc3d93c: stur            x2, [fp, #-8]
    // 0xc3d940: r17 = 8668
    //     0xc3d940: mov             x17, #0x21dc
    // 0xc3d944: cmp             w2, w17
    // 0xc3d948: b.ne            #0xc3d9d4
    // 0xc3d94c: d0 = 0.500000
    //     0xc3d94c: fmov            d0, #0.50000000
    // 0xc3d950: LoadField: r0 = r1->field_2b
    //     0xc3d950: ldur            w0, [x1, #0x2b]
    // 0xc3d954: DecompressPointer r0
    //     0xc3d954: add             x0, x0, HEAP, lsl #32
    // 0xc3d958: LoadField: r3 = r0->field_37
    //     0xc3d958: ldur            w3, [x0, #0x37]
    // 0xc3d95c: DecompressPointer r3
    //     0xc3d95c: add             x3, x3, HEAP, lsl #32
    // 0xc3d960: r16 = Sentinel
    //     0xc3d960: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc3d964: cmp             w3, w16
    // 0xc3d968: b.eq            #0xc3df04
    // 0xc3d96c: LoadField: d1 = r3->field_7
    //     0xc3d96c: ldur            d1, [x3, #7]
    // 0xc3d970: fcmp            d1, d0
    // 0xc3d974: b.vs            #0xc3d9a8
    // 0xc3d978: b.ge            #0xc3d9a8
    // 0xc3d97c: LoadField: r0 = r1->field_1b
    //     0xc3d97c: ldur            w0, [x1, #0x1b]
    // 0xc3d980: DecompressPointer r0
    //     0xc3d980: add             x0, x0, HEAP, lsl #32
    // 0xc3d984: r3 = LoadClassIdInstr(r0)
    //     0xc3d984: ldur            x3, [x0, #-1]
    //     0xc3d988: ubfx            x3, x3, #0xc, #0x14
    // 0xc3d98c: SaveReg r0
    //     0xc3d98c: str             x0, [SP, #-8]!
    // 0xc3d990: mov             x0, x3
    // 0xc3d994: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc3d994: add             lr, x0, #0xb7c
    //     0xc3d998: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d99c: blr             lr
    // 0xc3d9a0: add             SP, SP, #8
    // 0xc3d9a4: b               #0xc3dbdc
    // 0xc3d9a8: LoadField: r0 = r1->field_1f
    //     0xc3d9a8: ldur            w0, [x1, #0x1f]
    // 0xc3d9ac: DecompressPointer r0
    //     0xc3d9ac: add             x0, x0, HEAP, lsl #32
    // 0xc3d9b0: r2 = LoadClassIdInstr(r0)
    //     0xc3d9b0: ldur            x2, [x0, #-1]
    //     0xc3d9b4: ubfx            x2, x2, #0xc, #0x14
    // 0xc3d9b8: SaveReg r0
    //     0xc3d9b8: str             x0, [SP, #-8]!
    // 0xc3d9bc: mov             x0, x2
    // 0xc3d9c0: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc3d9c0: add             lr, x0, #0xb7c
    //     0xc3d9c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d9c8: blr             lr
    // 0xc3d9cc: add             SP, SP, #8
    // 0xc3d9d0: b               #0xc3dbdc
    // 0xc3d9d4: LoadField: r2 = r1->field_7
    //     0xc3d9d4: ldur            w2, [x1, #7]
    // 0xc3d9d8: DecompressPointer r2
    //     0xc3d9d8: add             x2, x2, HEAP, lsl #32
    // 0xc3d9dc: stur            x2, [fp, #-0x10]
    // 0xc3d9e0: LoadField: r0 = r1->field_1b
    //     0xc3d9e0: ldur            w0, [x1, #0x1b]
    // 0xc3d9e4: DecompressPointer r0
    //     0xc3d9e4: add             x0, x0, HEAP, lsl #32
    // 0xc3d9e8: r3 = LoadClassIdInstr(r0)
    //     0xc3d9e8: ldur            x3, [x0, #-1]
    //     0xc3d9ec: ubfx            x3, x3, #0xc, #0x14
    // 0xc3d9f0: SaveReg r0
    //     0xc3d9f0: str             x0, [SP, #-8]!
    // 0xc3d9f4: mov             x0, x3
    // 0xc3d9f8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc3d9f8: add             lr, x0, #0xb7c
    //     0xc3d9fc: ldr             lr, [x21, lr, lsl #3]
    //     0xc3da00: blr             lr
    // 0xc3da04: add             SP, SP, #8
    // 0xc3da08: mov             x2, x0
    // 0xc3da0c: ldr             x1, [fp, #0x10]
    // 0xc3da10: stur            x2, [fp, #-0x18]
    // 0xc3da14: LoadField: r0 = r1->field_1f
    //     0xc3da14: ldur            w0, [x1, #0x1f]
    // 0xc3da18: DecompressPointer r0
    //     0xc3da18: add             x0, x0, HEAP, lsl #32
    // 0xc3da1c: r3 = LoadClassIdInstr(r0)
    //     0xc3da1c: ldur            x3, [x0, #-1]
    //     0xc3da20: ubfx            x3, x3, #0xc, #0x14
    // 0xc3da24: SaveReg r0
    //     0xc3da24: str             x0, [SP, #-8]!
    // 0xc3da28: mov             x0, x3
    // 0xc3da2c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc3da2c: add             lr, x0, #0xb7c
    //     0xc3da30: ldr             lr, [x21, lr, lsl #3]
    //     0xc3da34: blr             lr
    // 0xc3da38: add             SP, SP, #8
    // 0xc3da3c: mov             x2, x0
    // 0xc3da40: ldur            x1, [fp, #-0x18]
    // 0xc3da44: stur            x2, [fp, #-0x20]
    // 0xc3da48: r0 = 59
    //     0xc3da48: mov             x0, #0x3b
    // 0xc3da4c: branchIfSmi(r1, 0xc3da58)
    //     0xc3da4c: tbz             w1, #0, #0xc3da58
    // 0xc3da50: r0 = LoadClassIdInstr(r1)
    //     0xc3da50: ldur            x0, [x1, #-1]
    //     0xc3da54: ubfx            x0, x0, #0xc, #0x14
    // 0xc3da58: stp             x2, x1, [SP, #-0x10]!
    // 0xc3da5c: r0 = GDT[cid_x0 + -0xfed]()
    //     0xc3da5c: sub             lr, x0, #0xfed
    //     0xc3da60: ldr             lr, [x21, lr, lsl #3]
    //     0xc3da64: blr             lr
    // 0xc3da68: add             SP, SP, #0x10
    // 0xc3da6c: tbnz            w0, #4, #0xc3da78
    // 0xc3da70: ldur            x0, [fp, #-0x20]
    // 0xc3da74: b               #0xc3dbdc
    // 0xc3da78: ldur            x1, [fp, #-0x18]
    // 0xc3da7c: r0 = 59
    //     0xc3da7c: mov             x0, #0x3b
    // 0xc3da80: branchIfSmi(r1, 0xc3da8c)
    //     0xc3da80: tbz             w1, #0, #0xc3da8c
    // 0xc3da84: r0 = LoadClassIdInstr(r1)
    //     0xc3da84: ldur            x0, [x1, #-1]
    //     0xc3da88: ubfx            x0, x0, #0xc, #0x14
    // 0xc3da8c: ldur            x16, [fp, #-0x20]
    // 0xc3da90: stp             x16, x1, [SP, #-0x10]!
    // 0xc3da94: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xc3da94: sub             lr, x0, #0xfb9
    //     0xc3da98: ldr             lr, [x21, lr, lsl #3]
    //     0xc3da9c: blr             lr
    // 0xc3daa0: add             SP, SP, #0x10
    // 0xc3daa4: tbnz            w0, #4, #0xc3dab0
    // 0xc3daa8: ldur            x0, [fp, #-0x18]
    // 0xc3daac: b               #0xc3dbdc
    // 0xc3dab0: ldur            x1, [fp, #-0x20]
    // 0xc3dab4: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc3dab4: mov             x0, #0x76
    //     0xc3dab8: tbz             w1, #0, #0xc3dac8
    //     0xc3dabc: ldur            x0, [x1, #-1]
    //     0xc3dac0: ubfx            x0, x0, #0xc, #0x14
    //     0xc3dac4: lsl             x0, x0, #1
    // 0xc3dac8: cmp             w0, #0x7a
    // 0xc3dacc: b.ne            #0xc3dbd8
    // 0xc3dad0: ldur            x2, [fp, #-0x18]
    // 0xc3dad4: r0 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0xc3dad4: mov             x0, #0x76
    //     0xc3dad8: tbz             w2, #0, #0xc3dae8
    //     0xc3dadc: ldur            x0, [x2, #-1]
    //     0xc3dae0: ubfx            x0, x0, #0xc, #0x14
    //     0xc3dae4: lsl             x0, x0, #1
    // 0xc3dae8: cmp             w0, #0x7a
    // 0xc3daec: b.ne            #0xc3db7c
    // 0xc3daf0: d0 = 0.000000
    //     0xc3daf0: eor             v0.16b, v0.16b, v0.16b
    // 0xc3daf4: LoadField: d1 = r2->field_7
    //     0xc3daf4: ldur            d1, [x2, #7]
    // 0xc3daf8: fcmp            d1, d0
    // 0xc3dafc: b.vs            #0xc3db7c
    // 0xc3db00: b.ne            #0xc3db7c
    // 0xc3db04: LoadField: d2 = r1->field_7
    //     0xc3db04: ldur            d2, [x1, #7]
    // 0xc3db08: fadd            d3, d1, d2
    // 0xc3db0c: fmul            d4, d3, d1
    // 0xc3db10: fmul            d1, d4, d2
    // 0xc3db14: r3 = inline_Allocate_Double()
    //     0xc3db14: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xc3db18: add             x3, x3, #0x10
    //     0xc3db1c: cmp             x0, x3
    //     0xc3db20: b.ls            #0xc3df10
    //     0xc3db24: str             x3, [THR, #0x60]  ; THR::top
    //     0xc3db28: sub             x3, x3, #0xf
    //     0xc3db2c: mov             x0, #0xd108
    //     0xc3db30: movk            x0, #3, lsl #16
    //     0xc3db34: stur            x0, [x3, #-1]
    // 0xc3db38: StoreField: r3->field_7 = d1
    //     0xc3db38: stur            d1, [x3, #7]
    // 0xc3db3c: mov             x0, x3
    // 0xc3db40: ldur            x1, [fp, #-0x10]
    // 0xc3db44: stur            x3, [fp, #-0x28]
    // 0xc3db48: r2 = Null
    //     0xc3db48: mov             x2, NULL
    // 0xc3db4c: cmp             w1, NULL
    // 0xc3db50: b.eq            #0xc3db74
    // 0xc3db54: LoadField: r4 = r1->field_17
    //     0xc3db54: ldur            w4, [x1, #0x17]
    // 0xc3db58: DecompressPointer r4
    //     0xc3db58: add             x4, x4, HEAP, lsl #32
    // 0xc3db5c: r8 = Y0 bound num
    //     0xc3db5c: add             x8, PP, #0x1b, lsl #12  ; [pp+0x1beb8] TypeParameter: Y0 bound num
    //     0xc3db60: ldr             x8, [x8, #0xeb8]
    // 0xc3db64: LoadField: r9 = r4->field_7
    //     0xc3db64: ldur            x9, [x4, #7]
    // 0xc3db68: r3 = Null
    //     0xc3db68: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e0b0] Null
    //     0xc3db6c: ldr             x3, [x3, #0xb0]
    // 0xc3db70: blr             x9
    // 0xc3db74: ldur            x0, [fp, #-0x28]
    // 0xc3db78: b               #0xc3dbdc
    // 0xc3db7c: r0 = 59
    //     0xc3db7c: mov             x0, #0x3b
    // 0xc3db80: branchIfSmi(r2, 0xc3db8c)
    //     0xc3db80: tbz             w2, #0, #0xc3db8c
    // 0xc3db84: r0 = LoadClassIdInstr(r2)
    //     0xc3db84: ldur            x0, [x2, #-1]
    //     0xc3db88: ubfx            x0, x0, #0xc, #0x14
    // 0xc3db8c: stp             xzr, x2, [SP, #-0x10]!
    // 0xc3db90: mov             lr, x0
    // 0xc3db94: ldr             lr, [x21, lr, lsl #3]
    // 0xc3db98: blr             lr
    // 0xc3db9c: add             SP, SP, #0x10
    // 0xc3dba0: tbnz            w0, #4, #0xc3dbc0
    // 0xc3dba4: ldur            x16, [fp, #-0x20]
    // 0xc3dba8: SaveReg r16
    //     0xc3dba8: str             x16, [SP, #-8]!
    // 0xc3dbac: r0 = isNegative()
    //     0xc3dbac: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xc3dbb0: add             SP, SP, #8
    // 0xc3dbb4: tbnz            w0, #4, #0xc3dbc0
    // 0xc3dbb8: ldur            x0, [fp, #-0x20]
    // 0xc3dbbc: b               #0xc3dbdc
    // 0xc3dbc0: ldur            x0, [fp, #-0x20]
    // 0xc3dbc4: LoadField: d0 = r0->field_7
    //     0xc3dbc4: ldur            d0, [x0, #7]
    // 0xc3dbc8: fcmp            d0, d0
    // 0xc3dbcc: b.vs            #0xc3dbdc
    // 0xc3dbd0: ldur            x0, [fp, #-0x18]
    // 0xc3dbd4: b               #0xc3dbdc
    // 0xc3dbd8: ldur            x0, [fp, #-0x18]
    // 0xc3dbdc: ldr             x1, [fp, #0x10]
    // 0xc3dbe0: LoadField: r2 = r1->field_27
    //     0xc3dbe0: ldur            w2, [x1, #0x27]
    // 0xc3dbe4: DecompressPointer r2
    //     0xc3dbe4: add             x2, x2, HEAP, lsl #32
    // 0xc3dbe8: r3 = 59
    //     0xc3dbe8: mov             x3, #0x3b
    // 0xc3dbec: branchIfSmi(r0, 0xc3dbf8)
    //     0xc3dbec: tbz             w0, #0, #0xc3dbf8
    // 0xc3dbf0: r3 = LoadClassIdInstr(r0)
    //     0xc3dbf0: ldur            x3, [x0, #-1]
    //     0xc3dbf4: ubfx            x3, x3, #0xc, #0x14
    // 0xc3dbf8: stp             x2, x0, [SP, #-0x10]!
    // 0xc3dbfc: mov             x0, x3
    // 0xc3dc00: mov             lr, x0
    // 0xc3dc04: ldr             lr, [x21, lr, lsl #3]
    // 0xc3dc08: blr             lr
    // 0xc3dc0c: add             SP, SP, #0x10
    // 0xc3dc10: tbz             w0, #4, #0xc3deec
    // 0xc3dc14: ldur            x0, [fp, #-8]
    // 0xc3dc18: r17 = 8668
    //     0xc3dc18: mov             x17, #0x21dc
    // 0xc3dc1c: cmp             w0, w17
    // 0xc3dc20: b.ne            #0xc3dcb0
    // 0xc3dc24: ldr             x1, [fp, #0x10]
    // 0xc3dc28: d0 = 0.500000
    //     0xc3dc28: fmov            d0, #0.50000000
    // 0xc3dc2c: LoadField: r0 = r1->field_2b
    //     0xc3dc2c: ldur            w0, [x1, #0x2b]
    // 0xc3dc30: DecompressPointer r0
    //     0xc3dc30: add             x0, x0, HEAP, lsl #32
    // 0xc3dc34: LoadField: r2 = r0->field_37
    //     0xc3dc34: ldur            w2, [x0, #0x37]
    // 0xc3dc38: DecompressPointer r2
    //     0xc3dc38: add             x2, x2, HEAP, lsl #32
    // 0xc3dc3c: r16 = Sentinel
    //     0xc3dc3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc3dc40: cmp             w2, w16
    // 0xc3dc44: b.eq            #0xc3df24
    // 0xc3dc48: LoadField: d1 = r2->field_7
    //     0xc3dc48: ldur            d1, [x2, #7]
    // 0xc3dc4c: fcmp            d1, d0
    // 0xc3dc50: b.vs            #0xc3dc84
    // 0xc3dc54: b.ge            #0xc3dc84
    // 0xc3dc58: LoadField: r0 = r1->field_1b
    //     0xc3dc58: ldur            w0, [x1, #0x1b]
    // 0xc3dc5c: DecompressPointer r0
    //     0xc3dc5c: add             x0, x0, HEAP, lsl #32
    // 0xc3dc60: r2 = LoadClassIdInstr(r0)
    //     0xc3dc60: ldur            x2, [x0, #-1]
    //     0xc3dc64: ubfx            x2, x2, #0xc, #0x14
    // 0xc3dc68: SaveReg r0
    //     0xc3dc68: str             x0, [SP, #-8]!
    // 0xc3dc6c: mov             x0, x2
    // 0xc3dc70: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc3dc70: add             lr, x0, #0xb7c
    //     0xc3dc74: ldr             lr, [x21, lr, lsl #3]
    //     0xc3dc78: blr             lr
    // 0xc3dc7c: add             SP, SP, #8
    // 0xc3dc80: b               #0xc3debc
    // 0xc3dc84: LoadField: r0 = r1->field_1f
    //     0xc3dc84: ldur            w0, [x1, #0x1f]
    // 0xc3dc88: DecompressPointer r0
    //     0xc3dc88: add             x0, x0, HEAP, lsl #32
    // 0xc3dc8c: r2 = LoadClassIdInstr(r0)
    //     0xc3dc8c: ldur            x2, [x0, #-1]
    //     0xc3dc90: ubfx            x2, x2, #0xc, #0x14
    // 0xc3dc94: SaveReg r0
    //     0xc3dc94: str             x0, [SP, #-8]!
    // 0xc3dc98: mov             x0, x2
    // 0xc3dc9c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc3dc9c: add             lr, x0, #0xb7c
    //     0xc3dca0: ldr             lr, [x21, lr, lsl #3]
    //     0xc3dca4: blr             lr
    // 0xc3dca8: add             SP, SP, #8
    // 0xc3dcac: b               #0xc3debc
    // 0xc3dcb0: ldr             x1, [fp, #0x10]
    // 0xc3dcb4: LoadField: r2 = r1->field_7
    //     0xc3dcb4: ldur            w2, [x1, #7]
    // 0xc3dcb8: DecompressPointer r2
    //     0xc3dcb8: add             x2, x2, HEAP, lsl #32
    // 0xc3dcbc: stur            x2, [fp, #-8]
    // 0xc3dcc0: LoadField: r0 = r1->field_1b
    //     0xc3dcc0: ldur            w0, [x1, #0x1b]
    // 0xc3dcc4: DecompressPointer r0
    //     0xc3dcc4: add             x0, x0, HEAP, lsl #32
    // 0xc3dcc8: r3 = LoadClassIdInstr(r0)
    //     0xc3dcc8: ldur            x3, [x0, #-1]
    //     0xc3dccc: ubfx            x3, x3, #0xc, #0x14
    // 0xc3dcd0: SaveReg r0
    //     0xc3dcd0: str             x0, [SP, #-8]!
    // 0xc3dcd4: mov             x0, x3
    // 0xc3dcd8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc3dcd8: add             lr, x0, #0xb7c
    //     0xc3dcdc: ldr             lr, [x21, lr, lsl #3]
    //     0xc3dce0: blr             lr
    // 0xc3dce4: add             SP, SP, #8
    // 0xc3dce8: mov             x2, x0
    // 0xc3dcec: ldr             x1, [fp, #0x10]
    // 0xc3dcf0: stur            x2, [fp, #-0x10]
    // 0xc3dcf4: LoadField: r0 = r1->field_1f
    //     0xc3dcf4: ldur            w0, [x1, #0x1f]
    // 0xc3dcf8: DecompressPointer r0
    //     0xc3dcf8: add             x0, x0, HEAP, lsl #32
    // 0xc3dcfc: r3 = LoadClassIdInstr(r0)
    //     0xc3dcfc: ldur            x3, [x0, #-1]
    //     0xc3dd00: ubfx            x3, x3, #0xc, #0x14
    // 0xc3dd04: SaveReg r0
    //     0xc3dd04: str             x0, [SP, #-8]!
    // 0xc3dd08: mov             x0, x3
    // 0xc3dd0c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc3dd0c: add             lr, x0, #0xb7c
    //     0xc3dd10: ldr             lr, [x21, lr, lsl #3]
    //     0xc3dd14: blr             lr
    // 0xc3dd18: add             SP, SP, #8
    // 0xc3dd1c: mov             x2, x0
    // 0xc3dd20: ldur            x1, [fp, #-0x10]
    // 0xc3dd24: stur            x2, [fp, #-0x18]
    // 0xc3dd28: r0 = 59
    //     0xc3dd28: mov             x0, #0x3b
    // 0xc3dd2c: branchIfSmi(r1, 0xc3dd38)
    //     0xc3dd2c: tbz             w1, #0, #0xc3dd38
    // 0xc3dd30: r0 = LoadClassIdInstr(r1)
    //     0xc3dd30: ldur            x0, [x1, #-1]
    //     0xc3dd34: ubfx            x0, x0, #0xc, #0x14
    // 0xc3dd38: stp             x2, x1, [SP, #-0x10]!
    // 0xc3dd3c: r0 = GDT[cid_x0 + -0xfed]()
    //     0xc3dd3c: sub             lr, x0, #0xfed
    //     0xc3dd40: ldr             lr, [x21, lr, lsl #3]
    //     0xc3dd44: blr             lr
    // 0xc3dd48: add             SP, SP, #0x10
    // 0xc3dd4c: tbnz            w0, #4, #0xc3dd58
    // 0xc3dd50: ldur            x0, [fp, #-0x18]
    // 0xc3dd54: b               #0xc3debc
    // 0xc3dd58: ldur            x1, [fp, #-0x10]
    // 0xc3dd5c: r0 = 59
    //     0xc3dd5c: mov             x0, #0x3b
    // 0xc3dd60: branchIfSmi(r1, 0xc3dd6c)
    //     0xc3dd60: tbz             w1, #0, #0xc3dd6c
    // 0xc3dd64: r0 = LoadClassIdInstr(r1)
    //     0xc3dd64: ldur            x0, [x1, #-1]
    //     0xc3dd68: ubfx            x0, x0, #0xc, #0x14
    // 0xc3dd6c: ldur            x16, [fp, #-0x18]
    // 0xc3dd70: stp             x16, x1, [SP, #-0x10]!
    // 0xc3dd74: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xc3dd74: sub             lr, x0, #0xfb9
    //     0xc3dd78: ldr             lr, [x21, lr, lsl #3]
    //     0xc3dd7c: blr             lr
    // 0xc3dd80: add             SP, SP, #0x10
    // 0xc3dd84: tbnz            w0, #4, #0xc3dd90
    // 0xc3dd88: ldur            x0, [fp, #-0x10]
    // 0xc3dd8c: b               #0xc3debc
    // 0xc3dd90: ldur            x1, [fp, #-0x18]
    // 0xc3dd94: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc3dd94: mov             x0, #0x76
    //     0xc3dd98: tbz             w1, #0, #0xc3dda8
    //     0xc3dd9c: ldur            x0, [x1, #-1]
    //     0xc3dda0: ubfx            x0, x0, #0xc, #0x14
    //     0xc3dda4: lsl             x0, x0, #1
    // 0xc3dda8: cmp             w0, #0x7a
    // 0xc3ddac: b.ne            #0xc3deb8
    // 0xc3ddb0: ldur            x2, [fp, #-0x10]
    // 0xc3ddb4: r0 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0xc3ddb4: mov             x0, #0x76
    //     0xc3ddb8: tbz             w2, #0, #0xc3ddc8
    //     0xc3ddbc: ldur            x0, [x2, #-1]
    //     0xc3ddc0: ubfx            x0, x0, #0xc, #0x14
    //     0xc3ddc4: lsl             x0, x0, #1
    // 0xc3ddc8: cmp             w0, #0x7a
    // 0xc3ddcc: b.ne            #0xc3de5c
    // 0xc3ddd0: d0 = 0.000000
    //     0xc3ddd0: eor             v0.16b, v0.16b, v0.16b
    // 0xc3ddd4: LoadField: d1 = r2->field_7
    //     0xc3ddd4: ldur            d1, [x2, #7]
    // 0xc3ddd8: fcmp            d1, d0
    // 0xc3dddc: b.vs            #0xc3de5c
    // 0xc3dde0: b.ne            #0xc3de5c
    // 0xc3dde4: LoadField: d0 = r1->field_7
    //     0xc3dde4: ldur            d0, [x1, #7]
    // 0xc3dde8: fadd            d2, d1, d0
    // 0xc3ddec: fmul            d3, d2, d1
    // 0xc3ddf0: fmul            d1, d3, d0
    // 0xc3ddf4: r3 = inline_Allocate_Double()
    //     0xc3ddf4: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xc3ddf8: add             x3, x3, #0x10
    //     0xc3ddfc: cmp             x0, x3
    //     0xc3de00: b.ls            #0xc3df30
    //     0xc3de04: str             x3, [THR, #0x60]  ; THR::top
    //     0xc3de08: sub             x3, x3, #0xf
    //     0xc3de0c: mov             x0, #0xd108
    //     0xc3de10: movk            x0, #3, lsl #16
    //     0xc3de14: stur            x0, [x3, #-1]
    // 0xc3de18: StoreField: r3->field_7 = d1
    //     0xc3de18: stur            d1, [x3, #7]
    // 0xc3de1c: mov             x0, x3
    // 0xc3de20: ldur            x1, [fp, #-8]
    // 0xc3de24: stur            x3, [fp, #-0x20]
    // 0xc3de28: r2 = Null
    //     0xc3de28: mov             x2, NULL
    // 0xc3de2c: cmp             w1, NULL
    // 0xc3de30: b.eq            #0xc3de54
    // 0xc3de34: LoadField: r4 = r1->field_17
    //     0xc3de34: ldur            w4, [x1, #0x17]
    // 0xc3de38: DecompressPointer r4
    //     0xc3de38: add             x4, x4, HEAP, lsl #32
    // 0xc3de3c: r8 = Y0 bound num
    //     0xc3de3c: add             x8, PP, #0x1b, lsl #12  ; [pp+0x1beb8] TypeParameter: Y0 bound num
    //     0xc3de40: ldr             x8, [x8, #0xeb8]
    // 0xc3de44: LoadField: r9 = r4->field_7
    //     0xc3de44: ldur            x9, [x4, #7]
    // 0xc3de48: r3 = Null
    //     0xc3de48: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e0c0] Null
    //     0xc3de4c: ldr             x3, [x3, #0xc0]
    // 0xc3de50: blr             x9
    // 0xc3de54: ldur            x0, [fp, #-0x20]
    // 0xc3de58: b               #0xc3debc
    // 0xc3de5c: r0 = 59
    //     0xc3de5c: mov             x0, #0x3b
    // 0xc3de60: branchIfSmi(r2, 0xc3de6c)
    //     0xc3de60: tbz             w2, #0, #0xc3de6c
    // 0xc3de64: r0 = LoadClassIdInstr(r2)
    //     0xc3de64: ldur            x0, [x2, #-1]
    //     0xc3de68: ubfx            x0, x0, #0xc, #0x14
    // 0xc3de6c: stp             xzr, x2, [SP, #-0x10]!
    // 0xc3de70: mov             lr, x0
    // 0xc3de74: ldr             lr, [x21, lr, lsl #3]
    // 0xc3de78: blr             lr
    // 0xc3de7c: add             SP, SP, #0x10
    // 0xc3de80: tbnz            w0, #4, #0xc3dea0
    // 0xc3de84: ldur            x16, [fp, #-0x18]
    // 0xc3de88: SaveReg r16
    //     0xc3de88: str             x16, [SP, #-8]!
    // 0xc3de8c: r0 = isNegative()
    //     0xc3de8c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xc3de90: add             SP, SP, #8
    // 0xc3de94: tbnz            w0, #4, #0xc3dea0
    // 0xc3de98: ldur            x0, [fp, #-0x18]
    // 0xc3de9c: b               #0xc3debc
    // 0xc3dea0: ldur            x0, [fp, #-0x18]
    // 0xc3dea4: LoadField: d0 = r0->field_7
    //     0xc3dea4: ldur            d0, [x0, #7]
    // 0xc3dea8: fcmp            d0, d0
    // 0xc3deac: b.vs            #0xc3debc
    // 0xc3deb0: ldur            x0, [fp, #-0x10]
    // 0xc3deb4: b               #0xc3debc
    // 0xc3deb8: ldur            x0, [fp, #-0x10]
    // 0xc3debc: ldr             x1, [fp, #0x10]
    // 0xc3dec0: StoreField: r1->field_27 = r0
    //     0xc3dec0: stur            w0, [x1, #0x27]
    //     0xc3dec4: tbz             w0, #0, #0xc3dee0
    //     0xc3dec8: ldurb           w16, [x1, #-1]
    //     0xc3decc: ldurb           w17, [x0, #-1]
    //     0xc3ded0: and             x16, x17, x16, lsr #2
    //     0xc3ded4: tst             x16, HEAP, lsr #32
    //     0xc3ded8: b.eq            #0xc3dee0
    //     0xc3dedc: bl              #0xd6826c
    // 0xc3dee0: SaveReg r1
    //     0xc3dee0: str             x1, [SP, #-8]!
    // 0xc3dee4: r0 = notifyListeners()
    //     0xc3dee4: bl              #0xc3df44  ; [package:flutter/src/animation/animations.dart] _CompoundAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0xc3dee8: add             SP, SP, #8
    // 0xc3deec: r0 = Null
    //     0xc3deec: mov             x0, NULL
    // 0xc3def0: LeaveFrame
    //     0xc3def0: mov             SP, fp
    //     0xc3def4: ldp             fp, lr, [SP], #0x10
    // 0xc3def8: ret
    //     0xc3def8: ret             
    // 0xc3defc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3defc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3df00: b               #0xc3d92c
    // 0xc3df04: r9 = _value
    //     0xc3df04: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xc3df08: ldr             x9, [x9, #0xbb0]
    // 0xc3df0c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xc3df0c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xc3df10: stp             q0, q1, [SP, #-0x20]!
    // 0xc3df14: r0 = AllocateDouble()
    //     0xc3df14: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc3df18: mov             x3, x0
    // 0xc3df1c: ldp             q0, q1, [SP], #0x20
    // 0xc3df20: b               #0xc3db38
    // 0xc3df24: r9 = _value
    //     0xc3df24: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xc3df28: ldr             x9, [x9, #0xbb0]
    // 0xc3df2c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xc3df2c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xc3df30: SaveReg d1
    //     0xc3df30: str             q1, [SP, #-0x10]!
    // 0xc3df34: r0 = AllocateDouble()
    //     0xc3df34: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc3df38: mov             x3, x0
    // 0xc3df3c: RestoreReg d1
    //     0xc3df3c: ldr             q1, [SP], #0x10
    // 0xc3df40: b               #0xc3de18
  }
  get _ status(/* No info */) {
    // ** addr: 0xc64888, size: 0xf0
    // 0xc64888: EnterFrame
    //     0xc64888: stp             fp, lr, [SP, #-0x10]!
    //     0xc6488c: mov             fp, SP
    // 0xc64890: AllocStack(0x8)
    //     0xc64890: sub             SP, SP, #8
    // 0xc64894: CheckStackOverflow
    //     0xc64894: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc64898: cmp             SP, x16
    //     0xc6489c: b.ls            #0xc64970
    // 0xc648a0: ldr             x1, [fp, #0x10]
    // 0xc648a4: LoadField: r2 = r1->field_1f
    //     0xc648a4: ldur            w2, [x1, #0x1f]
    // 0xc648a8: DecompressPointer r2
    //     0xc648a8: add             x2, x2, HEAP, lsl #32
    // 0xc648ac: stur            x2, [fp, #-8]
    // 0xc648b0: r0 = LoadClassIdInstr(r2)
    //     0xc648b0: ldur            x0, [x2, #-1]
    //     0xc648b4: ubfx            x0, x0, #0xc, #0x14
    // 0xc648b8: SaveReg r2
    //     0xc648b8: str             x2, [SP, #-8]!
    // 0xc648bc: r0 = GDT[cid_x0 + 0x376]()
    //     0xc648bc: add             lr, x0, #0x376
    //     0xc648c0: ldr             lr, [x21, lr, lsl #3]
    //     0xc648c4: blr             lr
    // 0xc648c8: add             SP, SP, #8
    // 0xc648cc: r16 = Instance_AnimationStatus
    //     0xc648cc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0xc648d0: ldr             x16, [x16, #0xbb8]
    // 0xc648d4: cmp             w0, w16
    // 0xc648d8: b.eq            #0xc6490c
    // 0xc648dc: ldur            x1, [fp, #-8]
    // 0xc648e0: r0 = LoadClassIdInstr(r1)
    //     0xc648e0: ldur            x0, [x1, #-1]
    //     0xc648e4: ubfx            x0, x0, #0xc, #0x14
    // 0xc648e8: SaveReg r1
    //     0xc648e8: str             x1, [SP, #-8]!
    // 0xc648ec: r0 = GDT[cid_x0 + 0x376]()
    //     0xc648ec: add             lr, x0, #0x376
    //     0xc648f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc648f4: blr             lr
    // 0xc648f8: add             SP, SP, #8
    // 0xc648fc: r16 = Instance_AnimationStatus
    //     0xc648fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0xc64900: ldr             x16, [x16, #0xbc0]
    // 0xc64904: cmp             w0, w16
    // 0xc64908: b.ne            #0xc6493c
    // 0xc6490c: ldur            x0, [fp, #-8]
    // 0xc64910: r1 = LoadClassIdInstr(r0)
    //     0xc64910: ldur            x1, [x0, #-1]
    //     0xc64914: ubfx            x1, x1, #0xc, #0x14
    // 0xc64918: SaveReg r0
    //     0xc64918: str             x0, [SP, #-8]!
    // 0xc6491c: mov             x0, x1
    // 0xc64920: r0 = GDT[cid_x0 + 0x376]()
    //     0xc64920: add             lr, x0, #0x376
    //     0xc64924: ldr             lr, [x21, lr, lsl #3]
    //     0xc64928: blr             lr
    // 0xc6492c: add             SP, SP, #8
    // 0xc64930: LeaveFrame
    //     0xc64930: mov             SP, fp
    //     0xc64934: ldp             fp, lr, [SP], #0x10
    // 0xc64938: ret
    //     0xc64938: ret             
    // 0xc6493c: ldr             x0, [fp, #0x10]
    // 0xc64940: LoadField: r1 = r0->field_1b
    //     0xc64940: ldur            w1, [x0, #0x1b]
    // 0xc64944: DecompressPointer r1
    //     0xc64944: add             x1, x1, HEAP, lsl #32
    // 0xc64948: r0 = LoadClassIdInstr(r1)
    //     0xc64948: ldur            x0, [x1, #-1]
    //     0xc6494c: ubfx            x0, x0, #0xc, #0x14
    // 0xc64950: SaveReg r1
    //     0xc64950: str             x1, [SP, #-8]!
    // 0xc64954: r0 = GDT[cid_x0 + 0x376]()
    //     0xc64954: add             lr, x0, #0x376
    //     0xc64958: ldr             lr, [x21, lr, lsl #3]
    //     0xc6495c: blr             lr
    // 0xc64960: add             SP, SP, #8
    // 0xc64964: LeaveFrame
    //     0xc64964: mov             SP, fp
    //     0xc64968: ldp             fp, lr, [SP], #0x10
    // 0xc6496c: ret
    //     0xc6496c: ret             
    // 0xc64970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc64970: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64974: b               #0xc648a0
  }
  _ didStartListening(/* No info */) {
    // ** addr: 0xc69150, size: 0x180
    // 0xc69150: EnterFrame
    //     0xc69150: stp             fp, lr, [SP, #-0x10]!
    //     0xc69154: mov             fp, SP
    // 0xc69158: AllocStack(0x8)
    //     0xc69158: sub             SP, SP, #8
    // 0xc6915c: CheckStackOverflow
    //     0xc6915c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc69160: cmp             SP, x16
    //     0xc69164: b.ls            #0xc692c8
    // 0xc69168: ldr             x0, [fp, #0x10]
    // 0xc6916c: LoadField: r1 = r0->field_1b
    //     0xc6916c: ldur            w1, [x0, #0x1b]
    // 0xc69170: DecompressPointer r1
    //     0xc69170: add             x1, x1, HEAP, lsl #32
    // 0xc69174: stur            x1, [fp, #-8]
    // 0xc69178: r1 = 1
    //     0xc69178: mov             x1, #1
    // 0xc6917c: r0 = AllocateContext()
    //     0xc6917c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc69180: mov             x1, x0
    // 0xc69184: ldr             x0, [fp, #0x10]
    // 0xc69188: StoreField: r1->field_f = r0
    //     0xc69188: stur            w0, [x1, #0xf]
    // 0xc6918c: mov             x2, x1
    // 0xc69190: r1 = Function '_maybeNotifyListeners@576411118':.
    //     0xc69190: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0a0] AnonymousClosure: (0xc3d8cc), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyListeners (0xc3d914)
    //     0xc69194: ldr             x1, [x1, #0xa0]
    // 0xc69198: r0 = AllocateClosure()
    //     0xc69198: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6919c: ldur            x1, [fp, #-8]
    // 0xc691a0: r2 = LoadClassIdInstr(r1)
    //     0xc691a0: ldur            x2, [x1, #-1]
    //     0xc691a4: ubfx            x2, x2, #0xc, #0x14
    // 0xc691a8: stp             x0, x1, [SP, #-0x10]!
    // 0xc691ac: mov             x0, x2
    // 0xc691b0: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0xc691b0: mov             x17, #0xc3ab
    //     0xc691b4: add             lr, x0, x17
    //     0xc691b8: ldr             lr, [x21, lr, lsl #3]
    //     0xc691bc: blr             lr
    // 0xc691c0: add             SP, SP, #0x10
    // 0xc691c4: r1 = 1
    //     0xc691c4: mov             x1, #1
    // 0xc691c8: r0 = AllocateContext()
    //     0xc691c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc691cc: mov             x1, x0
    // 0xc691d0: ldr             x0, [fp, #0x10]
    // 0xc691d4: StoreField: r1->field_f = r0
    //     0xc691d4: stur            w0, [x1, #0xf]
    // 0xc691d8: mov             x2, x1
    // 0xc691dc: r1 = Function '_maybeNotifyStatusListeners@576411118':.
    //     0xc691dc: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0a8] AnonymousClosure: (0xc3d5a8), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyStatusListeners (0xc3d5f4)
    //     0xc691e0: ldr             x1, [x1, #0xa8]
    // 0xc691e4: r0 = AllocateClosure()
    //     0xc691e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc691e8: mov             x1, x0
    // 0xc691ec: ldur            x0, [fp, #-8]
    // 0xc691f0: r2 = LoadClassIdInstr(r0)
    //     0xc691f0: ldur            x2, [x0, #-1]
    //     0xc691f4: ubfx            x2, x2, #0xc, #0x14
    // 0xc691f8: stp             x1, x0, [SP, #-0x10]!
    // 0xc691fc: mov             x0, x2
    // 0xc69200: r0 = GDT[cid_x0 + 0x80c]()
    //     0xc69200: add             lr, x0, #0x80c
    //     0xc69204: ldr             lr, [x21, lr, lsl #3]
    //     0xc69208: blr             lr
    // 0xc6920c: add             SP, SP, #0x10
    // 0xc69210: ldr             x0, [fp, #0x10]
    // 0xc69214: LoadField: r1 = r0->field_1f
    //     0xc69214: ldur            w1, [x0, #0x1f]
    // 0xc69218: DecompressPointer r1
    //     0xc69218: add             x1, x1, HEAP, lsl #32
    // 0xc6921c: stur            x1, [fp, #-8]
    // 0xc69220: r1 = 1
    //     0xc69220: mov             x1, #1
    // 0xc69224: r0 = AllocateContext()
    //     0xc69224: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc69228: mov             x1, x0
    // 0xc6922c: ldr             x0, [fp, #0x10]
    // 0xc69230: StoreField: r1->field_f = r0
    //     0xc69230: stur            w0, [x1, #0xf]
    // 0xc69234: mov             x2, x1
    // 0xc69238: r1 = Function '_maybeNotifyListeners@576411118':.
    //     0xc69238: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0a0] AnonymousClosure: (0xc3d8cc), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyListeners (0xc3d914)
    //     0xc6923c: ldr             x1, [x1, #0xa0]
    // 0xc69240: r0 = AllocateClosure()
    //     0xc69240: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc69244: ldur            x1, [fp, #-8]
    // 0xc69248: r2 = LoadClassIdInstr(r1)
    //     0xc69248: ldur            x2, [x1, #-1]
    //     0xc6924c: ubfx            x2, x2, #0xc, #0x14
    // 0xc69250: stp             x0, x1, [SP, #-0x10]!
    // 0xc69254: mov             x0, x2
    // 0xc69258: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0xc69258: mov             x17, #0xc3ab
    //     0xc6925c: add             lr, x0, x17
    //     0xc69260: ldr             lr, [x21, lr, lsl #3]
    //     0xc69264: blr             lr
    // 0xc69268: add             SP, SP, #0x10
    // 0xc6926c: r1 = 1
    //     0xc6926c: mov             x1, #1
    // 0xc69270: r0 = AllocateContext()
    //     0xc69270: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc69274: mov             x1, x0
    // 0xc69278: ldr             x0, [fp, #0x10]
    // 0xc6927c: StoreField: r1->field_f = r0
    //     0xc6927c: stur            w0, [x1, #0xf]
    // 0xc69280: mov             x2, x1
    // 0xc69284: r1 = Function '_maybeNotifyStatusListeners@576411118':.
    //     0xc69284: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0a8] AnonymousClosure: (0xc3d5a8), in [package:flutter/src/animation/animations.dart] CompoundAnimation::_maybeNotifyStatusListeners (0xc3d5f4)
    //     0xc69288: ldr             x1, [x1, #0xa8]
    // 0xc6928c: r0 = AllocateClosure()
    //     0xc6928c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc69290: mov             x1, x0
    // 0xc69294: ldur            x0, [fp, #-8]
    // 0xc69298: r2 = LoadClassIdInstr(r0)
    //     0xc69298: ldur            x2, [x0, #-1]
    //     0xc6929c: ubfx            x2, x2, #0xc, #0x14
    // 0xc692a0: stp             x1, x0, [SP, #-0x10]!
    // 0xc692a4: mov             x0, x2
    // 0xc692a8: r0 = GDT[cid_x0 + 0x80c]()
    //     0xc692a8: add             lr, x0, #0x80c
    //     0xc692ac: ldr             lr, [x21, lr, lsl #3]
    //     0xc692b0: blr             lr
    // 0xc692b4: add             SP, SP, #0x10
    // 0xc692b8: r0 = Null
    //     0xc692b8: mov             x0, NULL
    // 0xc692bc: LeaveFrame
    //     0xc692bc: mov             SP, fp
    //     0xc692c0: ldp             fp, lr, [SP], #0x10
    // 0xc692c4: ret
    //     0xc692c4: ret             
    // 0xc692c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc692c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc692cc: b               #0xc69168
  }
}

// class id: 4335, size: 0x2c, field offset: 0x2c
class AnimationMin<X0 bound num> extends CompoundAnimation<X0 bound num> {

  _ AnimationMin(/* No info */) {
    // ** addr: 0x7b9cb8, size: 0x48
    // 0x7b9cb8: EnterFrame
    //     0x7b9cb8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b9cbc: mov             fp, SP
    // 0x7b9cc0: CheckStackOverflow
    //     0x7b9cc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b9cc4: cmp             SP, x16
    //     0x7b9cc8: b.ls            #0x7b9cf8
    // 0x7b9ccc: ldr             x16, [fp, #0x20]
    // 0x7b9cd0: ldr             lr, [fp, #0x18]
    // 0x7b9cd4: stp             lr, x16, [SP, #-0x10]!
    // 0x7b9cd8: ldr             x16, [fp, #0x10]
    // 0x7b9cdc: SaveReg r16
    //     0x7b9cdc: str             x16, [SP, #-8]!
    // 0x7b9ce0: r0 = CompoundAnimation()
    //     0x7b9ce0: bl              #0x7b9d00  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::CompoundAnimation
    // 0x7b9ce4: add             SP, SP, #0x18
    // 0x7b9ce8: r0 = Null
    //     0x7b9ce8: mov             x0, NULL
    // 0x7b9cec: LeaveFrame
    //     0x7b9cec: mov             SP, fp
    //     0x7b9cf0: ldp             fp, lr, [SP], #0x10
    // 0x7b9cf4: ret
    //     0x7b9cf4: ret             
    // 0x7b9cf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b9cf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b9cfc: b               #0x7b9ccc
  }
  get _ value(/* No info */) {
    // ** addr: 0xc24e50, size: 0x250
    // 0xc24e50: EnterFrame
    //     0xc24e50: stp             fp, lr, [SP, #-0x10]!
    //     0xc24e54: mov             fp, SP
    // 0xc24e58: AllocStack(0x20)
    //     0xc24e58: sub             SP, SP, #0x20
    // 0xc24e5c: CheckStackOverflow
    //     0xc24e5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc24e60: cmp             SP, x16
    //     0xc24e64: b.ls            #0xc25084
    // 0xc24e68: ldr             x1, [fp, #0x10]
    // 0xc24e6c: LoadField: r2 = r1->field_7
    //     0xc24e6c: ldur            w2, [x1, #7]
    // 0xc24e70: DecompressPointer r2
    //     0xc24e70: add             x2, x2, HEAP, lsl #32
    // 0xc24e74: stur            x2, [fp, #-8]
    // 0xc24e78: LoadField: r0 = r1->field_1b
    //     0xc24e78: ldur            w0, [x1, #0x1b]
    // 0xc24e7c: DecompressPointer r0
    //     0xc24e7c: add             x0, x0, HEAP, lsl #32
    // 0xc24e80: r3 = LoadClassIdInstr(r0)
    //     0xc24e80: ldur            x3, [x0, #-1]
    //     0xc24e84: ubfx            x3, x3, #0xc, #0x14
    // 0xc24e88: SaveReg r0
    //     0xc24e88: str             x0, [SP, #-8]!
    // 0xc24e8c: mov             x0, x3
    // 0xc24e90: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc24e90: add             lr, x0, #0xb7c
    //     0xc24e94: ldr             lr, [x21, lr, lsl #3]
    //     0xc24e98: blr             lr
    // 0xc24e9c: add             SP, SP, #8
    // 0xc24ea0: mov             x1, x0
    // 0xc24ea4: ldr             x0, [fp, #0x10]
    // 0xc24ea8: stur            x1, [fp, #-0x10]
    // 0xc24eac: LoadField: r2 = r0->field_1f
    //     0xc24eac: ldur            w2, [x0, #0x1f]
    // 0xc24eb0: DecompressPointer r2
    //     0xc24eb0: add             x2, x2, HEAP, lsl #32
    // 0xc24eb4: r0 = LoadClassIdInstr(r2)
    //     0xc24eb4: ldur            x0, [x2, #-1]
    //     0xc24eb8: ubfx            x0, x0, #0xc, #0x14
    // 0xc24ebc: SaveReg r2
    //     0xc24ebc: str             x2, [SP, #-8]!
    // 0xc24ec0: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc24ec0: add             lr, x0, #0xb7c
    //     0xc24ec4: ldr             lr, [x21, lr, lsl #3]
    //     0xc24ec8: blr             lr
    // 0xc24ecc: add             SP, SP, #8
    // 0xc24ed0: mov             x2, x0
    // 0xc24ed4: ldur            x1, [fp, #-0x10]
    // 0xc24ed8: stur            x2, [fp, #-0x18]
    // 0xc24edc: r0 = 59
    //     0xc24edc: mov             x0, #0x3b
    // 0xc24ee0: branchIfSmi(r1, 0xc24eec)
    //     0xc24ee0: tbz             w1, #0, #0xc24eec
    // 0xc24ee4: r0 = LoadClassIdInstr(r1)
    //     0xc24ee4: ldur            x0, [x1, #-1]
    //     0xc24ee8: ubfx            x0, x0, #0xc, #0x14
    // 0xc24eec: stp             x2, x1, [SP, #-0x10]!
    // 0xc24ef0: r0 = GDT[cid_x0 + -0xfed]()
    //     0xc24ef0: sub             lr, x0, #0xfed
    //     0xc24ef4: ldr             lr, [x21, lr, lsl #3]
    //     0xc24ef8: blr             lr
    // 0xc24efc: add             SP, SP, #0x10
    // 0xc24f00: tbnz            w0, #4, #0xc24f0c
    // 0xc24f04: ldur            x0, [fp, #-0x18]
    // 0xc24f08: b               #0xc25078
    // 0xc24f0c: ldur            x1, [fp, #-0x10]
    // 0xc24f10: r0 = 59
    //     0xc24f10: mov             x0, #0x3b
    // 0xc24f14: branchIfSmi(r1, 0xc24f20)
    //     0xc24f14: tbz             w1, #0, #0xc24f20
    // 0xc24f18: r0 = LoadClassIdInstr(r1)
    //     0xc24f18: ldur            x0, [x1, #-1]
    //     0xc24f1c: ubfx            x0, x0, #0xc, #0x14
    // 0xc24f20: ldur            x16, [fp, #-0x18]
    // 0xc24f24: stp             x16, x1, [SP, #-0x10]!
    // 0xc24f28: r0 = GDT[cid_x0 + -0xfb9]()
    //     0xc24f28: sub             lr, x0, #0xfb9
    //     0xc24f2c: ldr             lr, [x21, lr, lsl #3]
    //     0xc24f30: blr             lr
    // 0xc24f34: add             SP, SP, #0x10
    // 0xc24f38: tbnz            w0, #4, #0xc24f44
    // 0xc24f3c: ldur            x0, [fp, #-0x10]
    // 0xc24f40: b               #0xc25078
    // 0xc24f44: ldur            x1, [fp, #-0x18]
    // 0xc24f48: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc24f48: mov             x0, #0x76
    //     0xc24f4c: tbz             w1, #0, #0xc24f5c
    //     0xc24f50: ldur            x0, [x1, #-1]
    //     0xc24f54: ubfx            x0, x0, #0xc, #0x14
    //     0xc24f58: lsl             x0, x0, #1
    // 0xc24f5c: cmp             w0, #0x7a
    // 0xc24f60: b.ne            #0xc25074
    // 0xc24f64: ldur            x2, [fp, #-0x10]
    // 0xc24f68: r0 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0xc24f68: mov             x0, #0x76
    //     0xc24f6c: tbz             w2, #0, #0xc24f7c
    //     0xc24f70: ldur            x0, [x2, #-1]
    //     0xc24f74: ubfx            x0, x0, #0xc, #0x14
    //     0xc24f78: lsl             x0, x0, #1
    // 0xc24f7c: cmp             w0, #0x7a
    // 0xc24f80: b.ne            #0xc25010
    // 0xc24f84: d0 = 0.000000
    //     0xc24f84: eor             v0.16b, v0.16b, v0.16b
    // 0xc24f88: LoadField: d1 = r2->field_7
    //     0xc24f88: ldur            d1, [x2, #7]
    // 0xc24f8c: fcmp            d1, d0
    // 0xc24f90: b.vs            #0xc25010
    // 0xc24f94: b.ne            #0xc25010
    // 0xc24f98: LoadField: d0 = r1->field_7
    //     0xc24f98: ldur            d0, [x1, #7]
    // 0xc24f9c: fadd            d2, d1, d0
    // 0xc24fa0: fmul            d3, d2, d1
    // 0xc24fa4: fmul            d1, d3, d0
    // 0xc24fa8: r3 = inline_Allocate_Double()
    //     0xc24fa8: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xc24fac: add             x3, x3, #0x10
    //     0xc24fb0: cmp             x0, x3
    //     0xc24fb4: b.ls            #0xc2508c
    //     0xc24fb8: str             x3, [THR, #0x60]  ; THR::top
    //     0xc24fbc: sub             x3, x3, #0xf
    //     0xc24fc0: mov             x0, #0xd108
    //     0xc24fc4: movk            x0, #3, lsl #16
    //     0xc24fc8: stur            x0, [x3, #-1]
    // 0xc24fcc: StoreField: r3->field_7 = d1
    //     0xc24fcc: stur            d1, [x3, #7]
    // 0xc24fd0: mov             x0, x3
    // 0xc24fd4: ldur            x1, [fp, #-8]
    // 0xc24fd8: stur            x3, [fp, #-0x20]
    // 0xc24fdc: r2 = Null
    //     0xc24fdc: mov             x2, NULL
    // 0xc24fe0: cmp             w1, NULL
    // 0xc24fe4: b.eq            #0xc25008
    // 0xc24fe8: LoadField: r4 = r1->field_17
    //     0xc24fe8: ldur            w4, [x1, #0x17]
    // 0xc24fec: DecompressPointer r4
    //     0xc24fec: add             x4, x4, HEAP, lsl #32
    // 0xc24ff0: r8 = Y0 bound num
    //     0xc24ff0: add             x8, PP, #0x1b, lsl #12  ; [pp+0x1beb8] TypeParameter: Y0 bound num
    //     0xc24ff4: ldr             x8, [x8, #0xeb8]
    // 0xc24ff8: LoadField: r9 = r4->field_7
    //     0xc24ff8: ldur            x9, [x4, #7]
    // 0xc24ffc: r3 = Null
    //     0xc24ffc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e090] Null
    //     0xc25000: ldr             x3, [x3, #0x90]
    // 0xc25004: blr             x9
    // 0xc25008: ldur            x0, [fp, #-0x20]
    // 0xc2500c: b               #0xc25078
    // 0xc25010: r0 = 59
    //     0xc25010: mov             x0, #0x3b
    // 0xc25014: branchIfSmi(r2, 0xc25020)
    //     0xc25014: tbz             w2, #0, #0xc25020
    // 0xc25018: r0 = LoadClassIdInstr(r2)
    //     0xc25018: ldur            x0, [x2, #-1]
    //     0xc2501c: ubfx            x0, x0, #0xc, #0x14
    // 0xc25020: stp             xzr, x2, [SP, #-0x10]!
    // 0xc25024: mov             lr, x0
    // 0xc25028: ldr             lr, [x21, lr, lsl #3]
    // 0xc2502c: blr             lr
    // 0xc25030: add             SP, SP, #0x10
    // 0xc25034: tbnz            w0, #4, #0xc25054
    // 0xc25038: ldur            x16, [fp, #-0x18]
    // 0xc2503c: SaveReg r16
    //     0xc2503c: str             x16, [SP, #-8]!
    // 0xc25040: r0 = isNegative()
    //     0xc25040: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xc25044: add             SP, SP, #8
    // 0xc25048: tbnz            w0, #4, #0xc25054
    // 0xc2504c: ldur            x1, [fp, #-0x18]
    // 0xc25050: b               #0xc25064
    // 0xc25054: ldur            x1, [fp, #-0x18]
    // 0xc25058: LoadField: d0 = r1->field_7
    //     0xc25058: ldur            d0, [x1, #7]
    // 0xc2505c: fcmp            d0, d0
    // 0xc25060: b.vc            #0xc2506c
    // 0xc25064: mov             x0, x1
    // 0xc25068: b               #0xc25078
    // 0xc2506c: ldur            x0, [fp, #-0x10]
    // 0xc25070: b               #0xc25078
    // 0xc25074: ldur            x0, [fp, #-0x10]
    // 0xc25078: LeaveFrame
    //     0xc25078: mov             SP, fp
    //     0xc2507c: ldp             fp, lr, [SP], #0x10
    // 0xc25080: ret
    //     0xc25080: ret             
    // 0xc25084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc25084: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc25088: b               #0xc24e68
    // 0xc2508c: SaveReg d1
    //     0xc2508c: str             q1, [SP, #-0x10]!
    // 0xc25090: r0 = AllocateDouble()
    //     0xc25090: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc25094: mov             x3, x0
    // 0xc25098: RestoreReg d1
    //     0xc25098: ldr             q1, [SP], #0x10
    // 0xc2509c: b               #0xc24fcc
  }
}

// class id: 4336, size: 0x14, field offset: 0xc
//   transformed mixin,
abstract class _ProxyAnimation&Animation&AnimationLazyListenerMixin extends Animation<double>
     with AnimationLazyListenerMixin {

  _ didRegisterListener(/* No info */) {
    // ** addr: 0x6e89d0, size: 0x18c
    // 0x6e89d0: EnterFrame
    //     0x6e89d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e89d4: mov             fp, SP
    // 0x6e89d8: AllocStack(0x8)
    //     0x6e89d8: sub             SP, SP, #8
    // 0x6e89dc: CheckStackOverflow
    //     0x6e89dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e89e0: cmp             SP, x16
    //     0x6e89e4: b.ls            #0x6e8b50
    // 0x6e89e8: ldr             x0, [fp, #0x10]
    // 0x6e89ec: LoadField: r1 = r0->field_b
    //     0x6e89ec: ldur            x1, [x0, #0xb]
    // 0x6e89f0: cbnz            x1, #0x6e8b30
    // 0x6e89f4: r1 = LoadClassIdInstr(r0)
    //     0x6e89f4: ldur            x1, [x0, #-1]
    //     0x6e89f8: ubfx            x1, x1, #0xc, #0x14
    // 0x6e89fc: lsl             x1, x1, #1
    // 0x6e8a00: r17 = 8676
    //     0x6e8a00: mov             x17, #0x21e4
    // 0x6e8a04: cmp             w1, w17
    // 0x6e8a08: b.ne            #0x6e8a68
    // 0x6e8a0c: LoadField: r1 = r0->field_17
    //     0x6e8a0c: ldur            w1, [x0, #0x17]
    // 0x6e8a10: DecompressPointer r1
    //     0x6e8a10: add             x1, x1, HEAP, lsl #32
    // 0x6e8a14: stur            x1, [fp, #-8]
    // 0x6e8a18: r1 = 1
    //     0x6e8a18: mov             x1, #1
    // 0x6e8a1c: r0 = AllocateContext()
    //     0x6e8a1c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6e8a20: mov             x1, x0
    // 0x6e8a24: ldr             x0, [fp, #0x10]
    // 0x6e8a28: StoreField: r1->field_f = r0
    //     0x6e8a28: stur            w0, [x1, #0xf]
    // 0x6e8a2c: mov             x2, x1
    // 0x6e8a30: r1 = Function '_statusChangeHandler@576411118':.
    //     0x6e8a30: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1ca50] AnonymousClosure: (0x6e904c), in [package:flutter/src/animation/animations.dart] ReverseAnimation::_statusChangeHandler (0x6e9098)
    //     0x6e8a34: ldr             x1, [x1, #0xa50]
    // 0x6e8a38: r0 = AllocateClosure()
    //     0x6e8a38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6e8a3c: mov             x1, x0
    // 0x6e8a40: ldur            x0, [fp, #-8]
    // 0x6e8a44: r2 = LoadClassIdInstr(r0)
    //     0x6e8a44: ldur            x2, [x0, #-1]
    //     0x6e8a48: ubfx            x2, x2, #0xc, #0x14
    // 0x6e8a4c: stp             x1, x0, [SP, #-0x10]!
    // 0x6e8a50: mov             x0, x2
    // 0x6e8a54: r0 = GDT[cid_x0 + 0x80c]()
    //     0x6e8a54: add             lr, x0, #0x80c
    //     0x6e8a58: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8a5c: blr             lr
    // 0x6e8a60: add             SP, SP, #0x10
    // 0x6e8a64: b               #0x6e8b30
    // 0x6e8a68: LoadField: r1 = r0->field_23
    //     0x6e8a68: ldur            w1, [x0, #0x23]
    // 0x6e8a6c: DecompressPointer r1
    //     0x6e8a6c: add             x1, x1, HEAP, lsl #32
    // 0x6e8a70: stur            x1, [fp, #-8]
    // 0x6e8a74: cmp             w1, NULL
    // 0x6e8a78: b.eq            #0x6e8b30
    // 0x6e8a7c: r1 = 1
    //     0x6e8a7c: mov             x1, #1
    // 0x6e8a80: r0 = AllocateContext()
    //     0x6e8a80: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6e8a84: mov             x1, x0
    // 0x6e8a88: ldr             x0, [fp, #0x10]
    // 0x6e8a8c: StoreField: r1->field_f = r0
    //     0x6e8a8c: stur            w0, [x1, #0xf]
    // 0x6e8a90: mov             x2, x1
    // 0x6e8a94: r1 = Function 'notifyListeners':.
    //     0x6e8a94: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c8e8] AnonymousClosure: (0x6e8de4), in [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners (0x6e8e2c)
    //     0x6e8a98: ldr             x1, [x1, #0x8e8]
    // 0x6e8a9c: r0 = AllocateClosure()
    //     0x6e8a9c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6e8aa0: mov             x1, x0
    // 0x6e8aa4: ldur            x0, [fp, #-8]
    // 0x6e8aa8: r2 = LoadClassIdInstr(r0)
    //     0x6e8aa8: ldur            x2, [x0, #-1]
    //     0x6e8aac: ubfx            x2, x2, #0xc, #0x14
    // 0x6e8ab0: stp             x1, x0, [SP, #-0x10]!
    // 0x6e8ab4: mov             x0, x2
    // 0x6e8ab8: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6e8ab8: mov             x17, #0xc3ab
    //     0x6e8abc: add             lr, x0, x17
    //     0x6e8ac0: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8ac4: blr             lr
    // 0x6e8ac8: add             SP, SP, #0x10
    // 0x6e8acc: ldr             x0, [fp, #0x10]
    // 0x6e8ad0: LoadField: r1 = r0->field_23
    //     0x6e8ad0: ldur            w1, [x0, #0x23]
    // 0x6e8ad4: DecompressPointer r1
    //     0x6e8ad4: add             x1, x1, HEAP, lsl #32
    // 0x6e8ad8: stur            x1, [fp, #-8]
    // 0x6e8adc: cmp             w1, NULL
    // 0x6e8ae0: b.eq            #0x6e8b58
    // 0x6e8ae4: r1 = 1
    //     0x6e8ae4: mov             x1, #1
    // 0x6e8ae8: r0 = AllocateContext()
    //     0x6e8ae8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6e8aec: mov             x1, x0
    // 0x6e8af0: ldr             x0, [fp, #0x10]
    // 0x6e8af4: StoreField: r1->field_f = r0
    //     0x6e8af4: stur            w0, [x1, #0xf]
    // 0x6e8af8: mov             x2, x1
    // 0x6e8afc: r1 = Function 'notifyStatusListeners':.
    //     0x6e8afc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c8f0] AnonymousClosure: (0x6e8b5c), in [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners (0x6e8ba8)
    //     0x6e8b00: ldr             x1, [x1, #0x8f0]
    // 0x6e8b04: r0 = AllocateClosure()
    //     0x6e8b04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6e8b08: mov             x1, x0
    // 0x6e8b0c: ldur            x0, [fp, #-8]
    // 0x6e8b10: r2 = LoadClassIdInstr(r0)
    //     0x6e8b10: ldur            x2, [x0, #-1]
    //     0x6e8b14: ubfx            x2, x2, #0xc, #0x14
    // 0x6e8b18: stp             x1, x0, [SP, #-0x10]!
    // 0x6e8b1c: mov             x0, x2
    // 0x6e8b20: r0 = GDT[cid_x0 + 0x80c]()
    //     0x6e8b20: add             lr, x0, #0x80c
    //     0x6e8b24: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8b28: blr             lr
    // 0x6e8b2c: add             SP, SP, #0x10
    // 0x6e8b30: ldr             x1, [fp, #0x10]
    // 0x6e8b34: LoadField: r2 = r1->field_b
    //     0x6e8b34: ldur            x2, [x1, #0xb]
    // 0x6e8b38: add             x3, x2, #1
    // 0x6e8b3c: StoreField: r1->field_b = r3
    //     0x6e8b3c: stur            x3, [x1, #0xb]
    // 0x6e8b40: r0 = Null
    //     0x6e8b40: mov             x0, NULL
    // 0x6e8b44: LeaveFrame
    //     0x6e8b44: mov             SP, fp
    //     0x6e8b48: ldp             fp, lr, [SP], #0x10
    // 0x6e8b4c: ret
    //     0x6e8b4c: ret             
    // 0x6e8b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8b50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8b54: b               #0x6e89e8
    // 0x6e8b58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6e8b58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUnregisterListener(/* No info */) {
    // ** addr: 0x6f5fa0, size: 0x184
    // 0x6f5fa0: EnterFrame
    //     0x6f5fa0: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5fa4: mov             fp, SP
    // 0x6f5fa8: AllocStack(0x8)
    //     0x6f5fa8: sub             SP, SP, #8
    // 0x6f5fac: CheckStackOverflow
    //     0x6f5fac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5fb0: cmp             SP, x16
    //     0x6f5fb4: b.ls            #0x6f6118
    // 0x6f5fb8: ldr             x0, [fp, #0x10]
    // 0x6f5fbc: LoadField: r1 = r0->field_b
    //     0x6f5fbc: ldur            x1, [x0, #0xb]
    // 0x6f5fc0: sub             x2, x1, #1
    // 0x6f5fc4: StoreField: r0->field_b = r2
    //     0x6f5fc4: stur            x2, [x0, #0xb]
    // 0x6f5fc8: cbnz            x2, #0x6f6108
    // 0x6f5fcc: r1 = LoadClassIdInstr(r0)
    //     0x6f5fcc: ldur            x1, [x0, #-1]
    //     0x6f5fd0: ubfx            x1, x1, #0xc, #0x14
    // 0x6f5fd4: lsl             x1, x1, #1
    // 0x6f5fd8: r17 = 8676
    //     0x6f5fd8: mov             x17, #0x21e4
    // 0x6f5fdc: cmp             w1, w17
    // 0x6f5fe0: b.ne            #0x6f6040
    // 0x6f5fe4: LoadField: r1 = r0->field_17
    //     0x6f5fe4: ldur            w1, [x0, #0x17]
    // 0x6f5fe8: DecompressPointer r1
    //     0x6f5fe8: add             x1, x1, HEAP, lsl #32
    // 0x6f5fec: stur            x1, [fp, #-8]
    // 0x6f5ff0: r1 = 1
    //     0x6f5ff0: mov             x1, #1
    // 0x6f5ff4: r0 = AllocateContext()
    //     0x6f5ff4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6f5ff8: mov             x1, x0
    // 0x6f5ffc: ldr             x0, [fp, #0x10]
    // 0x6f6000: StoreField: r1->field_f = r0
    //     0x6f6000: stur            w0, [x1, #0xf]
    // 0x6f6004: mov             x2, x1
    // 0x6f6008: r1 = Function '_statusChangeHandler@576411118':.
    //     0x6f6008: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1ca50] AnonymousClosure: (0x6e904c), in [package:flutter/src/animation/animations.dart] ReverseAnimation::_statusChangeHandler (0x6e9098)
    //     0x6f600c: ldr             x1, [x1, #0xa50]
    // 0x6f6010: r0 = AllocateClosure()
    //     0x6f6010: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6f6014: mov             x1, x0
    // 0x6f6018: ldur            x0, [fp, #-8]
    // 0x6f601c: r2 = LoadClassIdInstr(r0)
    //     0x6f601c: ldur            x2, [x0, #-1]
    //     0x6f6020: ubfx            x2, x2, #0xc, #0x14
    // 0x6f6024: stp             x1, x0, [SP, #-0x10]!
    // 0x6f6028: mov             x0, x2
    // 0x6f602c: r0 = GDT[cid_x0 + 0x490]()
    //     0x6f602c: add             lr, x0, #0x490
    //     0x6f6030: ldr             lr, [x21, lr, lsl #3]
    //     0x6f6034: blr             lr
    // 0x6f6038: add             SP, SP, #0x10
    // 0x6f603c: b               #0x6f6108
    // 0x6f6040: LoadField: r1 = r0->field_23
    //     0x6f6040: ldur            w1, [x0, #0x23]
    // 0x6f6044: DecompressPointer r1
    //     0x6f6044: add             x1, x1, HEAP, lsl #32
    // 0x6f6048: stur            x1, [fp, #-8]
    // 0x6f604c: cmp             w1, NULL
    // 0x6f6050: b.eq            #0x6f6108
    // 0x6f6054: r1 = 1
    //     0x6f6054: mov             x1, #1
    // 0x6f6058: r0 = AllocateContext()
    //     0x6f6058: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6f605c: mov             x1, x0
    // 0x6f6060: ldr             x0, [fp, #0x10]
    // 0x6f6064: StoreField: r1->field_f = r0
    //     0x6f6064: stur            w0, [x1, #0xf]
    // 0x6f6068: mov             x2, x1
    // 0x6f606c: r1 = Function 'notifyListeners':.
    //     0x6f606c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c8e8] AnonymousClosure: (0x6e8de4), in [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners (0x6e8e2c)
    //     0x6f6070: ldr             x1, [x1, #0x8e8]
    // 0x6f6074: r0 = AllocateClosure()
    //     0x6f6074: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6f6078: mov             x1, x0
    // 0x6f607c: ldur            x0, [fp, #-8]
    // 0x6f6080: r2 = LoadClassIdInstr(r0)
    //     0x6f6080: ldur            x2, [x0, #-1]
    //     0x6f6084: ubfx            x2, x2, #0xc, #0x14
    // 0x6f6088: stp             x1, x0, [SP, #-0x10]!
    // 0x6f608c: mov             x0, x2
    // 0x6f6090: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6f6090: mov             x17, #0xc2d6
    //     0x6f6094: add             lr, x0, x17
    //     0x6f6098: ldr             lr, [x21, lr, lsl #3]
    //     0x6f609c: blr             lr
    // 0x6f60a0: add             SP, SP, #0x10
    // 0x6f60a4: ldr             x0, [fp, #0x10]
    // 0x6f60a8: LoadField: r1 = r0->field_23
    //     0x6f60a8: ldur            w1, [x0, #0x23]
    // 0x6f60ac: DecompressPointer r1
    //     0x6f60ac: add             x1, x1, HEAP, lsl #32
    // 0x6f60b0: stur            x1, [fp, #-8]
    // 0x6f60b4: cmp             w1, NULL
    // 0x6f60b8: b.eq            #0x6f6120
    // 0x6f60bc: r1 = 1
    //     0x6f60bc: mov             x1, #1
    // 0x6f60c0: r0 = AllocateContext()
    //     0x6f60c0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6f60c4: mov             x1, x0
    // 0x6f60c8: ldr             x0, [fp, #0x10]
    // 0x6f60cc: StoreField: r1->field_f = r0
    //     0x6f60cc: stur            w0, [x1, #0xf]
    // 0x6f60d0: mov             x2, x1
    // 0x6f60d4: r1 = Function 'notifyStatusListeners':.
    //     0x6f60d4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c8f0] AnonymousClosure: (0x6e8b5c), in [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners (0x6e8ba8)
    //     0x6f60d8: ldr             x1, [x1, #0x8f0]
    // 0x6f60dc: r0 = AllocateClosure()
    //     0x6f60dc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6f60e0: mov             x1, x0
    // 0x6f60e4: ldur            x0, [fp, #-8]
    // 0x6f60e8: r2 = LoadClassIdInstr(r0)
    //     0x6f60e8: ldur            x2, [x0, #-1]
    //     0x6f60ec: ubfx            x2, x2, #0xc, #0x14
    // 0x6f60f0: stp             x1, x0, [SP, #-0x10]!
    // 0x6f60f4: mov             x0, x2
    // 0x6f60f8: r0 = GDT[cid_x0 + 0x490]()
    //     0x6f60f8: add             lr, x0, #0x490
    //     0x6f60fc: ldr             lr, [x21, lr, lsl #3]
    //     0x6f6100: blr             lr
    // 0x6f6104: add             SP, SP, #0x10
    // 0x6f6108: r0 = Null
    //     0x6f6108: mov             x0, NULL
    // 0x6f610c: LeaveFrame
    //     0x6f610c: mov             SP, fp
    //     0x6f6110: ldp             fp, lr, [SP], #0x10
    // 0x6f6114: ret
    //     0x6f6114: ret             
    // 0x6f6118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f6118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f611c: b               #0x6f5fb8
    // 0x6f6120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6f6120: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4337, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _ReverseAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin extends _ProxyAnimation&Animation&AnimationLazyListenerMixin
     with AnimationLocalStatusListenersMixin {

  _ notifyStatusListeners(/* No info */) {
    // ** addr: 0x6e9120, size: 0x23c
    // 0x6e9120: EnterFrame
    //     0x6e9120: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9124: mov             fp, SP
    // 0x6e9128: AllocStack(0x88)
    //     0x6e9128: sub             SP, SP, #0x88
    // 0x6e912c: CheckStackOverflow
    //     0x6e912c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9130: cmp             SP, x16
    //     0x6e9134: b.ls            #0x6e9348
    // 0x6e9138: ldr             x0, [fp, #0x18]
    // 0x6e913c: LoadField: r1 = r0->field_13
    //     0x6e913c: ldur            w1, [x0, #0x13]
    // 0x6e9140: DecompressPointer r1
    //     0x6e9140: add             x1, x1, HEAP, lsl #32
    // 0x6e9144: r16 = false
    //     0x6e9144: add             x16, NULL, #0x30  ; false
    // 0x6e9148: stp             x16, x1, [SP, #-0x10]!
    // 0x6e914c: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0x6e914c: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0x6e9150: r0 = toList()
    //     0x6e9150: bl              #0x6c0b5c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::toList
    // 0x6e9154: add             SP, SP, #0x10
    // 0x6e9158: r1 = LoadClassIdInstr(r0)
    //     0x6e9158: ldur            x1, [x0, #-1]
    //     0x6e915c: ubfx            x1, x1, #0xc, #0x14
    // 0x6e9160: SaveReg r0
    //     0x6e9160: str             x0, [SP, #-8]!
    // 0x6e9164: mov             x0, x1
    // 0x6e9168: r0 = GDT[cid_x0 + 0xb940]()
    //     0x6e9168: mov             x17, #0xb940
    //     0x6e916c: add             lr, x0, x17
    //     0x6e9170: ldr             lr, [x21, lr, lsl #3]
    //     0x6e9174: blr             lr
    // 0x6e9178: add             SP, SP, #8
    // 0x6e917c: mov             x1, x0
    // 0x6e9180: ldr             x0, [fp, #0x10]
    // 0x6e9184: ldr             x3, [fp, #0x18]
    // 0x6e9188: mov             x2, x0
    // 0x6e918c: b               #0x6e9288
    // 0x6e9190: sub             SP, fp, #0x88
    // 0x6e9194: mov             x3, x0
    // 0x6e9198: stur            x0, [fp, #-0x70]
    // 0x6e919c: mov             x0, x1
    // 0x6e91a0: stur            x1, [fp, #-0x78]
    // 0x6e91a4: r1 = Null
    //     0x6e91a4: mov             x1, NULL
    // 0x6e91a8: r2 = 4
    //     0x6e91a8: mov             x2, #4
    // 0x6e91ac: r0 = AllocateArray()
    //     0x6e91ac: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6e91b0: stur            x0, [fp, #-0x80]
    // 0x6e91b4: r17 = "while notifying status listeners for "
    //     0x6e91b4: add             x17, PP, #0xd, lsl #12  ; [pp+0xdbe8] "while notifying status listeners for "
    //     0x6e91b8: ldr             x17, [x17, #0xbe8]
    // 0x6e91bc: StoreField: r0->field_f = r17
    //     0x6e91bc: stur            w17, [x0, #0xf]
    // 0x6e91c0: ldr             x16, [fp, #0x18]
    // 0x6e91c4: SaveReg r16
    //     0x6e91c4: str             x16, [SP, #-8]!
    // 0x6e91c8: r0 = runtimeType()
    //     0x6e91c8: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0x6e91cc: add             SP, SP, #8
    // 0x6e91d0: ldur            x1, [fp, #-0x80]
    // 0x6e91d4: ArrayStore: r1[1] = r0  ; List_4
    //     0x6e91d4: add             x25, x1, #0x13
    //     0x6e91d8: str             w0, [x25]
    //     0x6e91dc: tbz             w0, #0, #0x6e91f8
    //     0x6e91e0: ldurb           w16, [x1, #-1]
    //     0x6e91e4: ldurb           w17, [x0, #-1]
    //     0x6e91e8: and             x16, x17, x16, lsr #2
    //     0x6e91ec: tst             x16, HEAP, lsr #32
    //     0x6e91f0: b.eq            #0x6e91f8
    //     0x6e91f4: bl              #0xd67e5c
    // 0x6e91f8: ldur            x16, [fp, #-0x80]
    // 0x6e91fc: SaveReg r16
    //     0x6e91fc: str             x16, [SP, #-8]!
    // 0x6e9200: r0 = _interpolate()
    //     0x6e9200: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x6e9204: add             SP, SP, #8
    // 0x6e9208: r1 = <List<Object>>
    //     0x6e9208: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x6e920c: stur            x0, [fp, #-0x80]
    // 0x6e9210: r0 = ErrorDescription()
    //     0x6e9210: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x6e9214: stur            x0, [fp, #-0x88]
    // 0x6e9218: ldur            x16, [fp, #-0x80]
    // 0x6e921c: stp             x16, x0, [SP, #-0x10]!
    // 0x6e9220: r16 = Instance_DiagnosticLevel
    //     0x6e9220: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x6e9224: SaveReg r16
    //     0x6e9224: str             x16, [SP, #-8]!
    // 0x6e9228: r0 = _ErrorDiagnostic()
    //     0x6e9228: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x6e922c: add             SP, SP, #0x18
    // 0x6e9230: r0 = FlutterErrorDetails()
    //     0x6e9230: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x6e9234: mov             x1, x0
    // 0x6e9238: ldur            x0, [fp, #-0x70]
    // 0x6e923c: StoreField: r1->field_7 = r0
    //     0x6e923c: stur            w0, [x1, #7]
    // 0x6e9240: ldur            x0, [fp, #-0x78]
    // 0x6e9244: StoreField: r1->field_b = r0
    //     0x6e9244: stur            w0, [x1, #0xb]
    // 0x6e9248: r0 = "animation library"
    //     0x6e9248: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbf0] "animation library"
    //     0x6e924c: ldr             x0, [x0, #0xbf0]
    // 0x6e9250: StoreField: r1->field_f = r0
    //     0x6e9250: stur            w0, [x1, #0xf]
    // 0x6e9254: ldur            x0, [fp, #-0x88]
    // 0x6e9258: StoreField: r1->field_13 = r0
    //     0x6e9258: stur            w0, [x1, #0x13]
    // 0x6e925c: r0 = false
    //     0x6e925c: add             x0, NULL, #0x30  ; false
    // 0x6e9260: StoreField: r1->field_1f = r0
    //     0x6e9260: stur            w0, [x1, #0x1f]
    // 0x6e9264: SaveReg r1
    //     0x6e9264: str             x1, [SP, #-8]!
    // 0x6e9268: r0 = reportError()
    //     0x6e9268: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x6e926c: add             SP, SP, #8
    // 0x6e9270: ldr             x2, [fp, #0x18]
    // 0x6e9274: ldr             x1, [fp, #0x10]
    // 0x6e9278: ldur            x0, [fp, #-0x38]
    // 0x6e927c: mov             x3, x2
    // 0x6e9280: mov             x2, x1
    // 0x6e9284: mov             x1, x0
    // 0x6e9288: stur            x3, [fp, #-0x70]
    // 0x6e928c: stur            x2, [fp, #-0x78]
    // 0x6e9290: stur            x1, [fp, #-0x80]
    // 0x6e9294: CheckStackOverflow
    //     0x6e9294: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9298: cmp             SP, x16
    //     0x6e929c: b.ls            #0x6e9350
    // 0x6e92a0: r0 = LoadClassIdInstr(r1)
    //     0x6e92a0: ldur            x0, [x1, #-1]
    //     0x6e92a4: ubfx            x0, x0, #0xc, #0x14
    // 0x6e92a8: SaveReg r1
    //     0x6e92a8: str             x1, [SP, #-8]!
    // 0x6e92ac: r0 = GDT[cid_x0 + 0x541]()
    //     0x6e92ac: add             lr, x0, #0x541
    //     0x6e92b0: ldr             lr, [x21, lr, lsl #3]
    //     0x6e92b4: blr             lr
    // 0x6e92b8: add             SP, SP, #8
    // 0x6e92bc: tbnz            w0, #4, #0x6e9338
    // 0x6e92c0: ldur            x1, [fp, #-0x80]
    // 0x6e92c4: r0 = LoadClassIdInstr(r1)
    //     0x6e92c4: ldur            x0, [x1, #-1]
    //     0x6e92c8: ubfx            x0, x0, #0xc, #0x14
    // 0x6e92cc: SaveReg r1
    //     0x6e92cc: str             x1, [SP, #-8]!
    // 0x6e92d0: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x6e92d0: add             lr, x0, #0x5ca
    //     0x6e92d4: ldr             lr, [x21, lr, lsl #3]
    //     0x6e92d8: blr             lr
    // 0x6e92dc: add             SP, SP, #8
    // 0x6e92e0: stur            x0, [fp, #-0x88]
    // 0x6e92e4: ldur            x2, [fp, #-0x70]
    // 0x6e92e8: LoadField: r1 = r2->field_13
    //     0x6e92e8: ldur            w1, [x2, #0x13]
    // 0x6e92ec: DecompressPointer r1
    //     0x6e92ec: add             x1, x1, HEAP, lsl #32
    // 0x6e92f0: stp             x0, x1, [SP, #-0x10]!
    // 0x6e92f4: r0 = contains()
    //     0x6e92f4: bl              #0x6b9fe4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0x6e92f8: add             SP, SP, #0x10
    // 0x6e92fc: tbnz            w0, #4, #0x6e9328
    // 0x6e9300: ldur            x1, [fp, #-0x88]
    // 0x6e9304: cmp             w1, NULL
    // 0x6e9308: b.eq            #0x6e9358
    // 0x6e930c: ldur            x16, [fp, #-0x78]
    // 0x6e9310: stp             x16, x1, [SP, #-0x10]!
    // 0x6e9314: mov             x0, x1
    // 0x6e9318: ClosureCall
    //     0x6e9318: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6e931c: ldur            x2, [x0, #0x1f]
    //     0x6e9320: blr             x2
    // 0x6e9324: add             SP, SP, #0x10
    // 0x6e9328: ldur            x2, [fp, #-0x70]
    // 0x6e932c: ldur            x1, [fp, #-0x78]
    // 0x6e9330: ldur            x0, [fp, #-0x80]
    // 0x6e9334: b               #0x6e927c
    // 0x6e9338: r0 = Null
    //     0x6e9338: mov             x0, NULL
    // 0x6e933c: LeaveFrame
    //     0x6e933c: mov             SP, fp
    //     0x6e9340: ldp             fp, lr, [SP], #0x10
    // 0x6e9344: ret
    //     0x6e9344: ret             
    // 0x6e9348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9348: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e934c: b               #0x6e9138
    // 0x6e9350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9350: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9354: b               #0x6e92a0
    // 0x6e9358: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6e9358: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ addStatusListener(/* No info */) {
    // ** addr: 0xc52dc8, size: 0x58
    // 0xc52dc8: EnterFrame
    //     0xc52dc8: stp             fp, lr, [SP, #-0x10]!
    //     0xc52dcc: mov             fp, SP
    // 0xc52dd0: CheckStackOverflow
    //     0xc52dd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc52dd4: cmp             SP, x16
    //     0xc52dd8: b.ls            #0xc52e18
    // 0xc52ddc: ldr             x16, [fp, #0x18]
    // 0xc52de0: SaveReg r16
    //     0xc52de0: str             x16, [SP, #-8]!
    // 0xc52de4: r0 = didRegisterListener()
    //     0xc52de4: bl              #0x6e89d0  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin::didRegisterListener
    // 0xc52de8: add             SP, SP, #8
    // 0xc52dec: ldr             x0, [fp, #0x18]
    // 0xc52df0: LoadField: r1 = r0->field_13
    //     0xc52df0: ldur            w1, [x0, #0x13]
    // 0xc52df4: DecompressPointer r1
    //     0xc52df4: add             x1, x1, HEAP, lsl #32
    // 0xc52df8: ldr             x16, [fp, #0x10]
    // 0xc52dfc: stp             x16, x1, [SP, #-0x10]!
    // 0xc52e00: r0 = add()
    //     0xc52e00: bl              #0x6e93b4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::add
    // 0xc52e04: add             SP, SP, #0x10
    // 0xc52e08: r0 = Null
    //     0xc52e08: mov             x0, NULL
    // 0xc52e0c: LeaveFrame
    //     0xc52e0c: mov             SP, fp
    //     0xc52e10: ldp             fp, lr, [SP], #0x10
    // 0xc52e14: ret
    //     0xc52e14: ret             
    // 0xc52e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc52e18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc52e1c: b               #0xc52ddc
  }
  _ removeStatusListener(/* No info */) {
    // ** addr: 0xc5dfb8, size: 0x5c
    // 0xc5dfb8: EnterFrame
    //     0xc5dfb8: stp             fp, lr, [SP, #-0x10]!
    //     0xc5dfbc: mov             fp, SP
    // 0xc5dfc0: CheckStackOverflow
    //     0xc5dfc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5dfc4: cmp             SP, x16
    //     0xc5dfc8: b.ls            #0xc5e00c
    // 0xc5dfcc: ldr             x0, [fp, #0x18]
    // 0xc5dfd0: LoadField: r1 = r0->field_13
    //     0xc5dfd0: ldur            w1, [x0, #0x13]
    // 0xc5dfd4: DecompressPointer r1
    //     0xc5dfd4: add             x1, x1, HEAP, lsl #32
    // 0xc5dfd8: ldr             x16, [fp, #0x10]
    // 0xc5dfdc: stp             x16, x1, [SP, #-0x10]!
    // 0xc5dfe0: r0 = remove()
    //     0xc5dfe0: bl              #0x6f5e78  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0xc5dfe4: add             SP, SP, #0x10
    // 0xc5dfe8: tbnz            w0, #4, #0xc5dffc
    // 0xc5dfec: ldr             x16, [fp, #0x18]
    // 0xc5dff0: SaveReg r16
    //     0xc5dff0: str             x16, [SP, #-8]!
    // 0xc5dff4: r0 = didUnregisterListener()
    //     0xc5dff4: bl              #0x6f5fa0  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin::didUnregisterListener
    // 0xc5dff8: add             SP, SP, #8
    // 0xc5dffc: r0 = Null
    //     0xc5dffc: mov             x0, NULL
    // 0xc5e000: LeaveFrame
    //     0xc5e000: mov             SP, fp
    //     0xc5e004: ldp             fp, lr, [SP], #0x10
    // 0xc5e008: ret
    //     0xc5e008: ret             
    // 0xc5e00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5e00c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5e010: b               #0xc5dfcc
  }
}

// class id: 4338, size: 0x1c, field offset: 0x18
class ReverseAnimation extends _ReverseAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin {

  _ addListener(/* No info */) {
    // ** addr: 0x6e8964, size: 0x6c
    // 0x6e8964: EnterFrame
    //     0x6e8964: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8968: mov             fp, SP
    // 0x6e896c: CheckStackOverflow
    //     0x6e896c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8970: cmp             SP, x16
    //     0x6e8974: b.ls            #0x6e89c8
    // 0x6e8978: ldr             x16, [fp, #0x18]
    // 0x6e897c: SaveReg r16
    //     0x6e897c: str             x16, [SP, #-8]!
    // 0x6e8980: r0 = didRegisterListener()
    //     0x6e8980: bl              #0x6e89d0  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin::didRegisterListener
    // 0x6e8984: add             SP, SP, #8
    // 0x6e8988: ldr             x0, [fp, #0x18]
    // 0x6e898c: LoadField: r1 = r0->field_17
    //     0x6e898c: ldur            w1, [x0, #0x17]
    // 0x6e8990: DecompressPointer r1
    //     0x6e8990: add             x1, x1, HEAP, lsl #32
    // 0x6e8994: r0 = LoadClassIdInstr(r1)
    //     0x6e8994: ldur            x0, [x1, #-1]
    //     0x6e8998: ubfx            x0, x0, #0xc, #0x14
    // 0x6e899c: ldr             x16, [fp, #0x10]
    // 0x6e89a0: stp             x16, x1, [SP, #-0x10]!
    // 0x6e89a4: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6e89a4: mov             x17, #0xc3ab
    //     0x6e89a8: add             lr, x0, x17
    //     0x6e89ac: ldr             lr, [x21, lr, lsl #3]
    //     0x6e89b0: blr             lr
    // 0x6e89b4: add             SP, SP, #0x10
    // 0x6e89b8: r0 = Null
    //     0x6e89b8: mov             x0, NULL
    // 0x6e89bc: LeaveFrame
    //     0x6e89bc: mov             SP, fp
    //     0x6e89c0: ldp             fp, lr, [SP], #0x10
    // 0x6e89c4: ret
    //     0x6e89c4: ret             
    // 0x6e89c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e89c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e89cc: b               #0x6e8978
  }
  [closure] void _statusChangeHandler(dynamic, AnimationStatus) {
    // ** addr: 0x6e904c, size: 0x4c
    // 0x6e904c: EnterFrame
    //     0x6e904c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9050: mov             fp, SP
    // 0x6e9054: ldr             x0, [fp, #0x18]
    // 0x6e9058: LoadField: r1 = r0->field_17
    //     0x6e9058: ldur            w1, [x0, #0x17]
    // 0x6e905c: DecompressPointer r1
    //     0x6e905c: add             x1, x1, HEAP, lsl #32
    // 0x6e9060: CheckStackOverflow
    //     0x6e9060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9064: cmp             SP, x16
    //     0x6e9068: b.ls            #0x6e9090
    // 0x6e906c: LoadField: r0 = r1->field_f
    //     0x6e906c: ldur            w0, [x1, #0xf]
    // 0x6e9070: DecompressPointer r0
    //     0x6e9070: add             x0, x0, HEAP, lsl #32
    // 0x6e9074: ldr             x16, [fp, #0x10]
    // 0x6e9078: stp             x16, x0, [SP, #-0x10]!
    // 0x6e907c: r0 = _statusChangeHandler()
    //     0x6e907c: bl              #0x6e9098  ; [package:flutter/src/animation/animations.dart] ReverseAnimation::_statusChangeHandler
    // 0x6e9080: add             SP, SP, #0x10
    // 0x6e9084: LeaveFrame
    //     0x6e9084: mov             SP, fp
    //     0x6e9088: ldp             fp, lr, [SP], #0x10
    // 0x6e908c: ret
    //     0x6e908c: ret             
    // 0x6e9090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9090: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9094: b               #0x6e906c
  }
  _ _statusChangeHandler(/* No info */) {
    // ** addr: 0x6e9098, size: 0x88
    // 0x6e9098: EnterFrame
    //     0x6e9098: stp             fp, lr, [SP, #-0x10]!
    //     0x6e909c: mov             fp, SP
    // 0x6e90a0: CheckStackOverflow
    //     0x6e90a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e90a4: cmp             SP, x16
    //     0x6e90a8: b.ls            #0x6e9118
    // 0x6e90ac: ldr             x0, [fp, #0x10]
    // 0x6e90b0: LoadField: r1 = r0->field_7
    //     0x6e90b0: ldur            x1, [x0, #7]
    // 0x6e90b4: cmp             x1, #1
    // 0x6e90b8: b.gt            #0x6e90dc
    // 0x6e90bc: cmp             x1, #0
    // 0x6e90c0: b.gt            #0x6e90d0
    // 0x6e90c4: r0 = Instance_AnimationStatus
    //     0x6e90c4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x6e90c8: ldr             x0, [x0, #0xba0]
    // 0x6e90cc: b               #0x6e90f8
    // 0x6e90d0: r0 = Instance_AnimationStatus
    //     0x6e90d0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0x6e90d4: ldr             x0, [x0, #0xbc0]
    // 0x6e90d8: b               #0x6e90f8
    // 0x6e90dc: cmp             x1, #2
    // 0x6e90e0: b.gt            #0x6e90f0
    // 0x6e90e4: r0 = Instance_AnimationStatus
    //     0x6e90e4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0x6e90e8: ldr             x0, [x0, #0xbb8]
    // 0x6e90ec: b               #0x6e90f8
    // 0x6e90f0: r0 = Instance_AnimationStatus
    //     0x6e90f0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x6e90f4: ldr             x0, [x0, #0xba8]
    // 0x6e90f8: ldr             x16, [fp, #0x18]
    // 0x6e90fc: stp             x0, x16, [SP, #-0x10]!
    // 0x6e9100: r0 = notifyStatusListeners()
    //     0x6e9100: bl              #0x6e9120  ; [package:flutter/src/animation/animations.dart] _ReverseAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0x6e9104: add             SP, SP, #0x10
    // 0x6e9108: r0 = Null
    //     0x6e9108: mov             x0, NULL
    // 0x6e910c: LeaveFrame
    //     0x6e910c: mov             SP, fp
    //     0x6e9110: ldp             fp, lr, [SP], #0x10
    // 0x6e9114: ret
    //     0x6e9114: ret             
    // 0x6e9118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e911c: b               #0x6e90ac
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6f5f30, size: 0x70
    // 0x6f5f30: EnterFrame
    //     0x6f5f30: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5f34: mov             fp, SP
    // 0x6f5f38: CheckStackOverflow
    //     0x6f5f38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5f3c: cmp             SP, x16
    //     0x6f5f40: b.ls            #0x6f5f98
    // 0x6f5f44: ldr             x1, [fp, #0x18]
    // 0x6f5f48: LoadField: r0 = r1->field_17
    //     0x6f5f48: ldur            w0, [x1, #0x17]
    // 0x6f5f4c: DecompressPointer r0
    //     0x6f5f4c: add             x0, x0, HEAP, lsl #32
    // 0x6f5f50: r2 = LoadClassIdInstr(r0)
    //     0x6f5f50: ldur            x2, [x0, #-1]
    //     0x6f5f54: ubfx            x2, x2, #0xc, #0x14
    // 0x6f5f58: ldr             x16, [fp, #0x10]
    // 0x6f5f5c: stp             x16, x0, [SP, #-0x10]!
    // 0x6f5f60: mov             x0, x2
    // 0x6f5f64: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6f5f64: mov             x17, #0xc2d6
    //     0x6f5f68: add             lr, x0, x17
    //     0x6f5f6c: ldr             lr, [x21, lr, lsl #3]
    //     0x6f5f70: blr             lr
    // 0x6f5f74: add             SP, SP, #0x10
    // 0x6f5f78: ldr             x16, [fp, #0x18]
    // 0x6f5f7c: SaveReg r16
    //     0x6f5f7c: str             x16, [SP, #-8]!
    // 0x6f5f80: r0 = didUnregisterListener()
    //     0x6f5f80: bl              #0x6f5fa0  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin::didUnregisterListener
    // 0x6f5f84: add             SP, SP, #8
    // 0x6f5f88: r0 = Null
    //     0x6f5f88: mov             x0, NULL
    // 0x6f5f8c: LeaveFrame
    //     0x6f5f8c: mov             SP, fp
    //     0x6f5f90: ldp             fp, lr, [SP], #0x10
    // 0x6f5f94: ret
    //     0x6f5f94: ret             
    // 0x6f5f98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f5f98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5f9c: b               #0x6f5f44
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4ae0, size: 0x78
    // 0xad4ae0: EnterFrame
    //     0xad4ae0: stp             fp, lr, [SP, #-0x10]!
    //     0xad4ae4: mov             fp, SP
    // 0xad4ae8: AllocStack(0x8)
    //     0xad4ae8: sub             SP, SP, #8
    // 0xad4aec: CheckStackOverflow
    //     0xad4aec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4af0: cmp             SP, x16
    //     0xad4af4: b.ls            #0xad4b50
    // 0xad4af8: ldr             x0, [fp, #0x10]
    // 0xad4afc: LoadField: r3 = r0->field_17
    //     0xad4afc: ldur            w3, [x0, #0x17]
    // 0xad4b00: DecompressPointer r3
    //     0xad4b00: add             x3, x3, HEAP, lsl #32
    // 0xad4b04: stur            x3, [fp, #-8]
    // 0xad4b08: r1 = Null
    //     0xad4b08: mov             x1, NULL
    // 0xad4b0c: r2 = 6
    //     0xad4b0c: mov             x2, #6
    // 0xad4b10: r0 = AllocateArray()
    //     0xad4b10: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4b14: mov             x1, x0
    // 0xad4b18: ldur            x0, [fp, #-8]
    // 0xad4b1c: StoreField: r1->field_f = r0
    //     0xad4b1c: stur            w0, [x1, #0xf]
    // 0xad4b20: r17 = "➪"
    //     0xad4b20: add             x17, PP, #0x22, lsl #12  ; [pp+0x221a0] "➪"
    //     0xad4b24: ldr             x17, [x17, #0x1a0]
    // 0xad4b28: StoreField: r1->field_13 = r17
    //     0xad4b28: stur            w17, [x1, #0x13]
    // 0xad4b2c: r17 = "ReverseAnimation"
    //     0xad4b2c: add             x17, PP, #0x22, lsl #12  ; [pp+0x221a8] "ReverseAnimation"
    //     0xad4b30: ldr             x17, [x17, #0x1a8]
    // 0xad4b34: StoreField: r1->field_17 = r17
    //     0xad4b34: stur            w17, [x1, #0x17]
    // 0xad4b38: SaveReg r1
    //     0xad4b38: str             x1, [SP, #-8]!
    // 0xad4b3c: r0 = _interpolate()
    //     0xad4b3c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4b40: add             SP, SP, #8
    // 0xad4b44: LeaveFrame
    //     0xad4b44: mov             SP, fp
    //     0xad4b48: ldp             fp, lr, [SP], #0x10
    // 0xad4b4c: ret
    //     0xad4b4c: ret             
    // 0xad4b50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4b50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4b54: b               #0xad4af8
  }
  get _ value(/* No info */) {
    // ** addr: 0xc24d44, size: 0x94
    // 0xc24d44: EnterFrame
    //     0xc24d44: stp             fp, lr, [SP, #-0x10]!
    //     0xc24d48: mov             fp, SP
    // 0xc24d4c: CheckStackOverflow
    //     0xc24d4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc24d50: cmp             SP, x16
    //     0xc24d54: b.ls            #0xc24dc0
    // 0xc24d58: ldr             x0, [fp, #0x10]
    // 0xc24d5c: LoadField: r1 = r0->field_17
    //     0xc24d5c: ldur            w1, [x0, #0x17]
    // 0xc24d60: DecompressPointer r1
    //     0xc24d60: add             x1, x1, HEAP, lsl #32
    // 0xc24d64: r0 = LoadClassIdInstr(r1)
    //     0xc24d64: ldur            x0, [x1, #-1]
    //     0xc24d68: ubfx            x0, x0, #0xc, #0x14
    // 0xc24d6c: SaveReg r1
    //     0xc24d6c: str             x1, [SP, #-8]!
    // 0xc24d70: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc24d70: add             lr, x0, #0xb7c
    //     0xc24d74: ldr             lr, [x21, lr, lsl #3]
    //     0xc24d78: blr             lr
    // 0xc24d7c: add             SP, SP, #8
    // 0xc24d80: LoadField: d0 = r0->field_7
    //     0xc24d80: ldur            d0, [x0, #7]
    // 0xc24d84: d1 = 1.000000
    //     0xc24d84: fmov            d1, #1.00000000
    // 0xc24d88: fsub            d2, d1, d0
    // 0xc24d8c: r0 = inline_Allocate_Double()
    //     0xc24d8c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc24d90: add             x0, x0, #0x10
    //     0xc24d94: cmp             x1, x0
    //     0xc24d98: b.ls            #0xc24dc8
    //     0xc24d9c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc24da0: sub             x0, x0, #0xf
    //     0xc24da4: mov             x1, #0xd108
    //     0xc24da8: movk            x1, #3, lsl #16
    //     0xc24dac: stur            x1, [x0, #-1]
    // 0xc24db0: StoreField: r0->field_7 = d2
    //     0xc24db0: stur            d2, [x0, #7]
    // 0xc24db4: LeaveFrame
    //     0xc24db4: mov             SP, fp
    //     0xc24db8: ldp             fp, lr, [SP], #0x10
    // 0xc24dbc: ret
    //     0xc24dbc: ret             
    // 0xc24dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc24dc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc24dc4: b               #0xc24d58
    // 0xc24dc8: SaveReg d2
    //     0xc24dc8: str             q2, [SP, #-0x10]!
    // 0xc24dcc: r0 = AllocateDouble()
    //     0xc24dcc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc24dd0: RestoreReg d2
    //     0xc24dd0: ldr             q2, [SP], #0x10
    // 0xc24dd4: b               #0xc24db0
  }
  get _ status(/* No info */) {
    // ** addr: 0xc647e0, size: 0xa8
    // 0xc647e0: EnterFrame
    //     0xc647e0: stp             fp, lr, [SP, #-0x10]!
    //     0xc647e4: mov             fp, SP
    // 0xc647e8: CheckStackOverflow
    //     0xc647e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc647ec: cmp             SP, x16
    //     0xc647f0: b.ls            #0xc64880
    // 0xc647f4: ldr             x0, [fp, #0x10]
    // 0xc647f8: LoadField: r1 = r0->field_17
    //     0xc647f8: ldur            w1, [x0, #0x17]
    // 0xc647fc: DecompressPointer r1
    //     0xc647fc: add             x1, x1, HEAP, lsl #32
    // 0xc64800: r0 = LoadClassIdInstr(r1)
    //     0xc64800: ldur            x0, [x1, #-1]
    //     0xc64804: ubfx            x0, x0, #0xc, #0x14
    // 0xc64808: SaveReg r1
    //     0xc64808: str             x1, [SP, #-8]!
    // 0xc6480c: r0 = GDT[cid_x0 + 0x376]()
    //     0xc6480c: add             lr, x0, #0x376
    //     0xc64810: ldr             lr, [x21, lr, lsl #3]
    //     0xc64814: blr             lr
    // 0xc64818: add             SP, SP, #8
    // 0xc6481c: cmp             w0, NULL
    // 0xc64820: b.eq            #0xc64870
    // 0xc64824: LoadField: r1 = r0->field_7
    //     0xc64824: ldur            x1, [x0, #7]
    // 0xc64828: cmp             x1, #1
    // 0xc6482c: b.gt            #0xc64850
    // 0xc64830: cmp             x1, #0
    // 0xc64834: b.gt            #0xc64844
    // 0xc64838: r0 = Instance_AnimationStatus
    //     0xc64838: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0xc6483c: ldr             x0, [x0, #0xba0]
    // 0xc64840: b               #0xc64874
    // 0xc64844: r0 = Instance_AnimationStatus
    //     0xc64844: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0xc64848: ldr             x0, [x0, #0xbc0]
    // 0xc6484c: b               #0xc64874
    // 0xc64850: cmp             x1, #2
    // 0xc64854: b.gt            #0xc64864
    // 0xc64858: r0 = Instance_AnimationStatus
    //     0xc64858: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0xc6485c: ldr             x0, [x0, #0xbb8]
    // 0xc64860: b               #0xc64874
    // 0xc64864: r0 = Instance_AnimationStatus
    //     0xc64864: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0xc64868: ldr             x0, [x0, #0xba8]
    // 0xc6486c: b               #0xc64874
    // 0xc64870: r0 = Null
    //     0xc64870: mov             x0, NULL
    // 0xc64874: LeaveFrame
    //     0xc64874: mov             SP, fp
    //     0xc64878: ldp             fp, lr, [SP], #0x10
    // 0xc6487c: ret
    //     0xc6487c: ret             
    // 0xc64880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc64880: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64884: b               #0xc647f4
  }
}

// class id: 4339, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin extends _ProxyAnimation&Animation&AnimationLazyListenerMixin
     with AnimationLocalListenersMixin {

  [closure] void notifyListeners(dynamic) {
    // ** addr: 0x6e8de4, size: 0x48
    // 0x6e8de4: EnterFrame
    //     0x6e8de4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8de8: mov             fp, SP
    // 0x6e8dec: ldr             x0, [fp, #0x10]
    // 0x6e8df0: LoadField: r1 = r0->field_17
    //     0x6e8df0: ldur            w1, [x0, #0x17]
    // 0x6e8df4: DecompressPointer r1
    //     0x6e8df4: add             x1, x1, HEAP, lsl #32
    // 0x6e8df8: CheckStackOverflow
    //     0x6e8df8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8dfc: cmp             SP, x16
    //     0x6e8e00: b.ls            #0x6e8e24
    // 0x6e8e04: LoadField: r0 = r1->field_f
    //     0x6e8e04: ldur            w0, [x1, #0xf]
    // 0x6e8e08: DecompressPointer r0
    //     0x6e8e08: add             x0, x0, HEAP, lsl #32
    // 0x6e8e0c: SaveReg r0
    //     0x6e8e0c: str             x0, [SP, #-8]!
    // 0x6e8e10: r0 = notifyListeners()
    //     0x6e8e10: bl              #0x6e8e2c  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x6e8e14: add             SP, SP, #8
    // 0x6e8e18: LeaveFrame
    //     0x6e8e18: mov             SP, fp
    //     0x6e8e1c: ldp             fp, lr, [SP], #0x10
    // 0x6e8e20: ret
    //     0x6e8e20: ret             
    // 0x6e8e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8e28: b               #0x6e8e04
  }
  _ notifyListeners(/* No info */) {
    // ** addr: 0x6e8e2c, size: 0x220
    // 0x6e8e2c: EnterFrame
    //     0x6e8e2c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8e30: mov             fp, SP
    // 0x6e8e34: AllocStack(0x88)
    //     0x6e8e34: sub             SP, SP, #0x88
    // 0x6e8e38: CheckStackOverflow
    //     0x6e8e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8e3c: cmp             SP, x16
    //     0x6e8e40: b.ls            #0x6e9038
    // 0x6e8e44: ldr             x0, [fp, #0x10]
    // 0x6e8e48: LoadField: r1 = r0->field_13
    //     0x6e8e48: ldur            w1, [x0, #0x13]
    // 0x6e8e4c: DecompressPointer r1
    //     0x6e8e4c: add             x1, x1, HEAP, lsl #32
    // 0x6e8e50: r16 = false
    //     0x6e8e50: add             x16, NULL, #0x30  ; false
    // 0x6e8e54: stp             x16, x1, [SP, #-0x10]!
    // 0x6e8e58: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0x6e8e58: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0x6e8e5c: r0 = toList()
    //     0x6e8e5c: bl              #0x6c0b5c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::toList
    // 0x6e8e60: add             SP, SP, #0x10
    // 0x6e8e64: r1 = LoadClassIdInstr(r0)
    //     0x6e8e64: ldur            x1, [x0, #-1]
    //     0x6e8e68: ubfx            x1, x1, #0xc, #0x14
    // 0x6e8e6c: SaveReg r0
    //     0x6e8e6c: str             x0, [SP, #-8]!
    // 0x6e8e70: mov             x0, x1
    // 0x6e8e74: r0 = GDT[cid_x0 + 0xb940]()
    //     0x6e8e74: mov             x17, #0xb940
    //     0x6e8e78: add             lr, x0, x17
    //     0x6e8e7c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8e80: blr             lr
    // 0x6e8e84: add             SP, SP, #8
    // 0x6e8e88: ldr             x2, [fp, #0x10]
    // 0x6e8e8c: mov             x1, x0
    // 0x6e8e90: b               #0x6e8f84
    // 0x6e8e94: sub             SP, fp, #0x88
    // 0x6e8e98: mov             x3, x0
    // 0x6e8e9c: stur            x0, [fp, #-0x70]
    // 0x6e8ea0: mov             x0, x1
    // 0x6e8ea4: stur            x1, [fp, #-0x78]
    // 0x6e8ea8: r1 = Null
    //     0x6e8ea8: mov             x1, NULL
    // 0x6e8eac: r2 = 4
    //     0x6e8eac: mov             x2, #4
    // 0x6e8eb0: r0 = AllocateArray()
    //     0x6e8eb0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6e8eb4: stur            x0, [fp, #-0x80]
    // 0x6e8eb8: r17 = "while notifying listeners for "
    //     0x6e8eb8: add             x17, PP, #0xd, lsl #12  ; [pp+0xdc10] "while notifying listeners for "
    //     0x6e8ebc: ldr             x17, [x17, #0xc10]
    // 0x6e8ec0: StoreField: r0->field_f = r17
    //     0x6e8ec0: stur            w17, [x0, #0xf]
    // 0x6e8ec4: ldr             x16, [fp, #0x10]
    // 0x6e8ec8: SaveReg r16
    //     0x6e8ec8: str             x16, [SP, #-8]!
    // 0x6e8ecc: r0 = runtimeType()
    //     0x6e8ecc: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0x6e8ed0: add             SP, SP, #8
    // 0x6e8ed4: ldur            x1, [fp, #-0x80]
    // 0x6e8ed8: ArrayStore: r1[1] = r0  ; List_4
    //     0x6e8ed8: add             x25, x1, #0x13
    //     0x6e8edc: str             w0, [x25]
    //     0x6e8ee0: tbz             w0, #0, #0x6e8efc
    //     0x6e8ee4: ldurb           w16, [x1, #-1]
    //     0x6e8ee8: ldurb           w17, [x0, #-1]
    //     0x6e8eec: and             x16, x17, x16, lsr #2
    //     0x6e8ef0: tst             x16, HEAP, lsr #32
    //     0x6e8ef4: b.eq            #0x6e8efc
    //     0x6e8ef8: bl              #0xd67e5c
    // 0x6e8efc: ldur            x16, [fp, #-0x80]
    // 0x6e8f00: SaveReg r16
    //     0x6e8f00: str             x16, [SP, #-8]!
    // 0x6e8f04: r0 = _interpolate()
    //     0x6e8f04: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x6e8f08: add             SP, SP, #8
    // 0x6e8f0c: r1 = <List<Object>>
    //     0x6e8f0c: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x6e8f10: stur            x0, [fp, #-0x80]
    // 0x6e8f14: r0 = ErrorDescription()
    //     0x6e8f14: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x6e8f18: stur            x0, [fp, #-0x88]
    // 0x6e8f1c: ldur            x16, [fp, #-0x80]
    // 0x6e8f20: stp             x16, x0, [SP, #-0x10]!
    // 0x6e8f24: r16 = Instance_DiagnosticLevel
    //     0x6e8f24: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x6e8f28: SaveReg r16
    //     0x6e8f28: str             x16, [SP, #-8]!
    // 0x6e8f2c: r0 = _ErrorDiagnostic()
    //     0x6e8f2c: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x6e8f30: add             SP, SP, #0x18
    // 0x6e8f34: r0 = FlutterErrorDetails()
    //     0x6e8f34: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x6e8f38: mov             x1, x0
    // 0x6e8f3c: ldur            x0, [fp, #-0x70]
    // 0x6e8f40: StoreField: r1->field_7 = r0
    //     0x6e8f40: stur            w0, [x1, #7]
    // 0x6e8f44: ldur            x0, [fp, #-0x78]
    // 0x6e8f48: StoreField: r1->field_b = r0
    //     0x6e8f48: stur            w0, [x1, #0xb]
    // 0x6e8f4c: r0 = "animation library"
    //     0x6e8f4c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbf0] "animation library"
    //     0x6e8f50: ldr             x0, [x0, #0xbf0]
    // 0x6e8f54: StoreField: r1->field_f = r0
    //     0x6e8f54: stur            w0, [x1, #0xf]
    // 0x6e8f58: ldur            x0, [fp, #-0x88]
    // 0x6e8f5c: StoreField: r1->field_13 = r0
    //     0x6e8f5c: stur            w0, [x1, #0x13]
    // 0x6e8f60: r0 = false
    //     0x6e8f60: add             x0, NULL, #0x30  ; false
    // 0x6e8f64: StoreField: r1->field_1f = r0
    //     0x6e8f64: stur            w0, [x1, #0x1f]
    // 0x6e8f68: SaveReg r1
    //     0x6e8f68: str             x1, [SP, #-8]!
    // 0x6e8f6c: r0 = reportError()
    //     0x6e8f6c: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x6e8f70: add             SP, SP, #8
    // 0x6e8f74: ldr             x1, [fp, #0x10]
    // 0x6e8f78: ldur            x0, [fp, #-0x38]
    // 0x6e8f7c: mov             x2, x1
    // 0x6e8f80: mov             x1, x0
    // 0x6e8f84: stur            x2, [fp, #-0x70]
    // 0x6e8f88: stur            x1, [fp, #-0x78]
    // 0x6e8f8c: CheckStackOverflow
    //     0x6e8f8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8f90: cmp             SP, x16
    //     0x6e8f94: b.ls            #0x6e9040
    // 0x6e8f98: r0 = LoadClassIdInstr(r1)
    //     0x6e8f98: ldur            x0, [x1, #-1]
    //     0x6e8f9c: ubfx            x0, x0, #0xc, #0x14
    // 0x6e8fa0: SaveReg r1
    //     0x6e8fa0: str             x1, [SP, #-8]!
    // 0x6e8fa4: r0 = GDT[cid_x0 + 0x541]()
    //     0x6e8fa4: add             lr, x0, #0x541
    //     0x6e8fa8: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8fac: blr             lr
    // 0x6e8fb0: add             SP, SP, #8
    // 0x6e8fb4: tbnz            w0, #4, #0x6e9028
    // 0x6e8fb8: ldur            x1, [fp, #-0x78]
    // 0x6e8fbc: r0 = LoadClassIdInstr(r1)
    //     0x6e8fbc: ldur            x0, [x1, #-1]
    //     0x6e8fc0: ubfx            x0, x0, #0xc, #0x14
    // 0x6e8fc4: SaveReg r1
    //     0x6e8fc4: str             x1, [SP, #-8]!
    // 0x6e8fc8: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x6e8fc8: add             lr, x0, #0x5ca
    //     0x6e8fcc: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8fd0: blr             lr
    // 0x6e8fd4: add             SP, SP, #8
    // 0x6e8fd8: stur            x0, [fp, #-0x80]
    // 0x6e8fdc: ldur            x1, [fp, #-0x70]
    // 0x6e8fe0: LoadField: r2 = r1->field_13
    //     0x6e8fe0: ldur            w2, [x1, #0x13]
    // 0x6e8fe4: DecompressPointer r2
    //     0x6e8fe4: add             x2, x2, HEAP, lsl #32
    // 0x6e8fe8: stp             x0, x2, [SP, #-0x10]!
    // 0x6e8fec: r0 = contains()
    //     0x6e8fec: bl              #0x6b9fe4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0x6e8ff0: add             SP, SP, #0x10
    // 0x6e8ff4: tbnz            w0, #4, #0x6e901c
    // 0x6e8ff8: ldur            x1, [fp, #-0x80]
    // 0x6e8ffc: cmp             w1, NULL
    // 0x6e9000: b.eq            #0x6e9048
    // 0x6e9004: SaveReg r1
    //     0x6e9004: str             x1, [SP, #-8]!
    // 0x6e9008: mov             x0, x1
    // 0x6e900c: ClosureCall
    //     0x6e900c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x6e9010: ldur            x2, [x0, #0x1f]
    //     0x6e9014: blr             x2
    // 0x6e9018: add             SP, SP, #8
    // 0x6e901c: ldur            x1, [fp, #-0x70]
    // 0x6e9020: ldur            x0, [fp, #-0x78]
    // 0x6e9024: b               #0x6e8f7c
    // 0x6e9028: r0 = Null
    //     0x6e9028: mov             x0, NULL
    // 0x6e902c: LeaveFrame
    //     0x6e902c: mov             SP, fp
    //     0x6e9030: ldp             fp, lr, [SP], #0x10
    // 0x6e9034: ret
    //     0x6e9034: ret             
    // 0x6e9038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9038: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e903c: b               #0x6e8e44
    // 0x6e9040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e9040: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e9044: b               #0x6e8f98
    // 0x6e9048: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6e9048: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 4340, size: 0x1c, field offset: 0x18
//   transformed mixin,
abstract class _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin extends _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin
     with AnimationLocalStatusListenersMixin {

  _ _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin(/* No info */) {
    // ** addr: 0x5a0cd8, size: 0x128
    // 0x5a0cd8: EnterFrame
    //     0x5a0cd8: stp             fp, lr, [SP, #-0x10]!
    //     0x5a0cdc: mov             fp, SP
    // 0x5a0ce0: AllocStack(0x8)
    //     0x5a0ce0: sub             SP, SP, #8
    // 0x5a0ce4: CheckStackOverflow
    //     0x5a0ce4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a0ce8: cmp             SP, x16
    //     0x5a0cec: b.ls            #0x5a0df8
    // 0x5a0cf0: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x5a0cf0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x5a0cf4: ldr             x1, [x1, #0x3d8]
    // 0x5a0cf8: r0 = ObserverList()
    //     0x5a0cf8: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x5a0cfc: mov             x1, x0
    // 0x5a0d00: r0 = false
    //     0x5a0d00: add             x0, NULL, #0x30  ; false
    // 0x5a0d04: stur            x1, [fp, #-8]
    // 0x5a0d08: StoreField: r1->field_f = r0
    //     0x5a0d08: stur            w0, [x1, #0xf]
    // 0x5a0d0c: r2 = Sentinel
    //     0x5a0d0c: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5a0d10: StoreField: r1->field_13 = r2
    //     0x5a0d10: stur            w2, [x1, #0x13]
    // 0x5a0d14: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x5a0d14: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x5a0d18: ldr             x16, [x16, #0x3d8]
    // 0x5a0d1c: stp             xzr, x16, [SP, #-0x10]!
    // 0x5a0d20: r0 = _GrowableList()
    //     0x5a0d20: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5a0d24: add             SP, SP, #0x10
    // 0x5a0d28: ldur            x1, [fp, #-8]
    // 0x5a0d2c: StoreField: r1->field_b = r0
    //     0x5a0d2c: stur            w0, [x1, #0xb]
    //     0x5a0d30: ldurb           w16, [x1, #-1]
    //     0x5a0d34: ldurb           w17, [x0, #-1]
    //     0x5a0d38: and             x16, x17, x16, lsr #2
    //     0x5a0d3c: tst             x16, HEAP, lsr #32
    //     0x5a0d40: b.eq            #0x5a0d48
    //     0x5a0d44: bl              #0xd6826c
    // 0x5a0d48: mov             x0, x1
    // 0x5a0d4c: ldr             x2, [fp, #0x10]
    // 0x5a0d50: StoreField: r2->field_17 = r0
    //     0x5a0d50: stur            w0, [x2, #0x17]
    //     0x5a0d54: ldurb           w16, [x2, #-1]
    //     0x5a0d58: ldurb           w17, [x0, #-1]
    //     0x5a0d5c: and             x16, x17, x16, lsr #2
    //     0x5a0d60: tst             x16, HEAP, lsr #32
    //     0x5a0d64: b.eq            #0x5a0d6c
    //     0x5a0d68: bl              #0xd6828c
    // 0x5a0d6c: r1 = <(dynamic this) => void?>
    //     0x5a0d6c: ldr             x1, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0x5a0d70: r0 = ObserverList()
    //     0x5a0d70: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x5a0d74: mov             x1, x0
    // 0x5a0d78: r0 = false
    //     0x5a0d78: add             x0, NULL, #0x30  ; false
    // 0x5a0d7c: stur            x1, [fp, #-8]
    // 0x5a0d80: StoreField: r1->field_f = r0
    //     0x5a0d80: stur            w0, [x1, #0xf]
    // 0x5a0d84: r0 = Sentinel
    //     0x5a0d84: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5a0d88: StoreField: r1->field_13 = r0
    //     0x5a0d88: stur            w0, [x1, #0x13]
    // 0x5a0d8c: r16 = <(dynamic this) => void?>
    //     0x5a0d8c: ldr             x16, [PP, #0x49f8]  ; [pp+0x49f8] TypeArguments: <(dynamic this) => void?>
    // 0x5a0d90: stp             xzr, x16, [SP, #-0x10]!
    // 0x5a0d94: r0 = _GrowableList()
    //     0x5a0d94: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x5a0d98: add             SP, SP, #0x10
    // 0x5a0d9c: ldur            x1, [fp, #-8]
    // 0x5a0da0: StoreField: r1->field_b = r0
    //     0x5a0da0: stur            w0, [x1, #0xb]
    //     0x5a0da4: ldurb           w16, [x1, #-1]
    //     0x5a0da8: ldurb           w17, [x0, #-1]
    //     0x5a0dac: and             x16, x17, x16, lsr #2
    //     0x5a0db0: tst             x16, HEAP, lsr #32
    //     0x5a0db4: b.eq            #0x5a0dbc
    //     0x5a0db8: bl              #0xd6826c
    // 0x5a0dbc: mov             x0, x1
    // 0x5a0dc0: ldr             x1, [fp, #0x10]
    // 0x5a0dc4: StoreField: r1->field_13 = r0
    //     0x5a0dc4: stur            w0, [x1, #0x13]
    //     0x5a0dc8: ldurb           w16, [x1, #-1]
    //     0x5a0dcc: ldurb           w17, [x0, #-1]
    //     0x5a0dd0: and             x16, x17, x16, lsr #2
    //     0x5a0dd4: tst             x16, HEAP, lsr #32
    //     0x5a0dd8: b.eq            #0x5a0de0
    //     0x5a0ddc: bl              #0xd6826c
    // 0x5a0de0: r2 = 0
    //     0x5a0de0: mov             x2, #0
    // 0x5a0de4: StoreField: r1->field_b = r2
    //     0x5a0de4: stur            x2, [x1, #0xb]
    // 0x5a0de8: r0 = Null
    //     0x5a0de8: mov             x0, NULL
    // 0x5a0dec: LeaveFrame
    //     0x5a0dec: mov             SP, fp
    //     0x5a0df0: ldp             fp, lr, [SP], #0x10
    // 0x5a0df4: ret
    //     0x5a0df4: ret             
    // 0x5a0df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a0df8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a0dfc: b               #0x5a0cf0
  }
  [closure] void notifyStatusListeners(dynamic, AnimationStatus) {
    // ** addr: 0x6e8b5c, size: 0x4c
    // 0x6e8b5c: EnterFrame
    //     0x6e8b5c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8b60: mov             fp, SP
    // 0x6e8b64: ldr             x0, [fp, #0x18]
    // 0x6e8b68: LoadField: r1 = r0->field_17
    //     0x6e8b68: ldur            w1, [x0, #0x17]
    // 0x6e8b6c: DecompressPointer r1
    //     0x6e8b6c: add             x1, x1, HEAP, lsl #32
    // 0x6e8b70: CheckStackOverflow
    //     0x6e8b70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8b74: cmp             SP, x16
    //     0x6e8b78: b.ls            #0x6e8ba0
    // 0x6e8b7c: LoadField: r0 = r1->field_f
    //     0x6e8b7c: ldur            w0, [x1, #0xf]
    // 0x6e8b80: DecompressPointer r0
    //     0x6e8b80: add             x0, x0, HEAP, lsl #32
    // 0x6e8b84: ldr             x16, [fp, #0x10]
    // 0x6e8b88: stp             x16, x0, [SP, #-0x10]!
    // 0x6e8b8c: r0 = notifyStatusListeners()
    //     0x6e8b8c: bl              #0x6e8ba8  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0x6e8b90: add             SP, SP, #0x10
    // 0x6e8b94: LeaveFrame
    //     0x6e8b94: mov             SP, fp
    //     0x6e8b98: ldp             fp, lr, [SP], #0x10
    // 0x6e8b9c: ret
    //     0x6e8b9c: ret             
    // 0x6e8ba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8ba0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8ba4: b               #0x6e8b7c
  }
  _ notifyStatusListeners(/* No info */) {
    // ** addr: 0x6e8ba8, size: 0x23c
    // 0x6e8ba8: EnterFrame
    //     0x6e8ba8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e8bac: mov             fp, SP
    // 0x6e8bb0: AllocStack(0x88)
    //     0x6e8bb0: sub             SP, SP, #0x88
    // 0x6e8bb4: CheckStackOverflow
    //     0x6e8bb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8bb8: cmp             SP, x16
    //     0x6e8bbc: b.ls            #0x6e8dd0
    // 0x6e8bc0: ldr             x0, [fp, #0x18]
    // 0x6e8bc4: LoadField: r1 = r0->field_17
    //     0x6e8bc4: ldur            w1, [x0, #0x17]
    // 0x6e8bc8: DecompressPointer r1
    //     0x6e8bc8: add             x1, x1, HEAP, lsl #32
    // 0x6e8bcc: r16 = false
    //     0x6e8bcc: add             x16, NULL, #0x30  ; false
    // 0x6e8bd0: stp             x16, x1, [SP, #-0x10]!
    // 0x6e8bd4: r4 = const [0, 0x2, 0x2, 0x1, growable, 0x1, null]
    //     0x6e8bd4: ldr             x4, [PP, #0x13a8]  ; [pp+0x13a8] List(7) [0, 0x2, 0x2, 0x1, "growable", 0x1, Null]
    // 0x6e8bd8: r0 = toList()
    //     0x6e8bd8: bl              #0x6c0b5c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::toList
    // 0x6e8bdc: add             SP, SP, #0x10
    // 0x6e8be0: r1 = LoadClassIdInstr(r0)
    //     0x6e8be0: ldur            x1, [x0, #-1]
    //     0x6e8be4: ubfx            x1, x1, #0xc, #0x14
    // 0x6e8be8: SaveReg r0
    //     0x6e8be8: str             x0, [SP, #-8]!
    // 0x6e8bec: mov             x0, x1
    // 0x6e8bf0: r0 = GDT[cid_x0 + 0xb940]()
    //     0x6e8bf0: mov             x17, #0xb940
    //     0x6e8bf4: add             lr, x0, x17
    //     0x6e8bf8: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8bfc: blr             lr
    // 0x6e8c00: add             SP, SP, #8
    // 0x6e8c04: mov             x1, x0
    // 0x6e8c08: ldr             x0, [fp, #0x10]
    // 0x6e8c0c: ldr             x3, [fp, #0x18]
    // 0x6e8c10: mov             x2, x0
    // 0x6e8c14: b               #0x6e8d10
    // 0x6e8c18: sub             SP, fp, #0x88
    // 0x6e8c1c: mov             x3, x0
    // 0x6e8c20: stur            x0, [fp, #-0x70]
    // 0x6e8c24: mov             x0, x1
    // 0x6e8c28: stur            x1, [fp, #-0x78]
    // 0x6e8c2c: r1 = Null
    //     0x6e8c2c: mov             x1, NULL
    // 0x6e8c30: r2 = 4
    //     0x6e8c30: mov             x2, #4
    // 0x6e8c34: r0 = AllocateArray()
    //     0x6e8c34: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6e8c38: stur            x0, [fp, #-0x80]
    // 0x6e8c3c: r17 = "while notifying status listeners for "
    //     0x6e8c3c: add             x17, PP, #0xd, lsl #12  ; [pp+0xdbe8] "while notifying status listeners for "
    //     0x6e8c40: ldr             x17, [x17, #0xbe8]
    // 0x6e8c44: StoreField: r0->field_f = r17
    //     0x6e8c44: stur            w17, [x0, #0xf]
    // 0x6e8c48: ldr             x16, [fp, #0x18]
    // 0x6e8c4c: SaveReg r16
    //     0x6e8c4c: str             x16, [SP, #-8]!
    // 0x6e8c50: r0 = runtimeType()
    //     0x6e8c50: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0x6e8c54: add             SP, SP, #8
    // 0x6e8c58: ldur            x1, [fp, #-0x80]
    // 0x6e8c5c: ArrayStore: r1[1] = r0  ; List_4
    //     0x6e8c5c: add             x25, x1, #0x13
    //     0x6e8c60: str             w0, [x25]
    //     0x6e8c64: tbz             w0, #0, #0x6e8c80
    //     0x6e8c68: ldurb           w16, [x1, #-1]
    //     0x6e8c6c: ldurb           w17, [x0, #-1]
    //     0x6e8c70: and             x16, x17, x16, lsr #2
    //     0x6e8c74: tst             x16, HEAP, lsr #32
    //     0x6e8c78: b.eq            #0x6e8c80
    //     0x6e8c7c: bl              #0xd67e5c
    // 0x6e8c80: ldur            x16, [fp, #-0x80]
    // 0x6e8c84: SaveReg r16
    //     0x6e8c84: str             x16, [SP, #-8]!
    // 0x6e8c88: r0 = _interpolate()
    //     0x6e8c88: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x6e8c8c: add             SP, SP, #8
    // 0x6e8c90: r1 = <List<Object>>
    //     0x6e8c90: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x6e8c94: stur            x0, [fp, #-0x80]
    // 0x6e8c98: r0 = ErrorDescription()
    //     0x6e8c98: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x6e8c9c: stur            x0, [fp, #-0x88]
    // 0x6e8ca0: ldur            x16, [fp, #-0x80]
    // 0x6e8ca4: stp             x16, x0, [SP, #-0x10]!
    // 0x6e8ca8: r16 = Instance_DiagnosticLevel
    //     0x6e8ca8: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x6e8cac: SaveReg r16
    //     0x6e8cac: str             x16, [SP, #-8]!
    // 0x6e8cb0: r0 = _ErrorDiagnostic()
    //     0x6e8cb0: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x6e8cb4: add             SP, SP, #0x18
    // 0x6e8cb8: r0 = FlutterErrorDetails()
    //     0x6e8cb8: bl              #0x500dc0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x24)
    // 0x6e8cbc: mov             x1, x0
    // 0x6e8cc0: ldur            x0, [fp, #-0x70]
    // 0x6e8cc4: StoreField: r1->field_7 = r0
    //     0x6e8cc4: stur            w0, [x1, #7]
    // 0x6e8cc8: ldur            x0, [fp, #-0x78]
    // 0x6e8ccc: StoreField: r1->field_b = r0
    //     0x6e8ccc: stur            w0, [x1, #0xb]
    // 0x6e8cd0: r0 = "animation library"
    //     0x6e8cd0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbf0] "animation library"
    //     0x6e8cd4: ldr             x0, [x0, #0xbf0]
    // 0x6e8cd8: StoreField: r1->field_f = r0
    //     0x6e8cd8: stur            w0, [x1, #0xf]
    // 0x6e8cdc: ldur            x0, [fp, #-0x88]
    // 0x6e8ce0: StoreField: r1->field_13 = r0
    //     0x6e8ce0: stur            w0, [x1, #0x13]
    // 0x6e8ce4: r0 = false
    //     0x6e8ce4: add             x0, NULL, #0x30  ; false
    // 0x6e8ce8: StoreField: r1->field_1f = r0
    //     0x6e8ce8: stur            w0, [x1, #0x1f]
    // 0x6e8cec: SaveReg r1
    //     0x6e8cec: str             x1, [SP, #-8]!
    // 0x6e8cf0: r0 = reportError()
    //     0x6e8cf0: bl              #0x4fc16c  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x6e8cf4: add             SP, SP, #8
    // 0x6e8cf8: ldr             x2, [fp, #0x18]
    // 0x6e8cfc: ldr             x1, [fp, #0x10]
    // 0x6e8d00: ldur            x0, [fp, #-0x38]
    // 0x6e8d04: mov             x3, x2
    // 0x6e8d08: mov             x2, x1
    // 0x6e8d0c: mov             x1, x0
    // 0x6e8d10: stur            x3, [fp, #-0x70]
    // 0x6e8d14: stur            x2, [fp, #-0x78]
    // 0x6e8d18: stur            x1, [fp, #-0x80]
    // 0x6e8d1c: CheckStackOverflow
    //     0x6e8d1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e8d20: cmp             SP, x16
    //     0x6e8d24: b.ls            #0x6e8dd8
    // 0x6e8d28: r0 = LoadClassIdInstr(r1)
    //     0x6e8d28: ldur            x0, [x1, #-1]
    //     0x6e8d2c: ubfx            x0, x0, #0xc, #0x14
    // 0x6e8d30: SaveReg r1
    //     0x6e8d30: str             x1, [SP, #-8]!
    // 0x6e8d34: r0 = GDT[cid_x0 + 0x541]()
    //     0x6e8d34: add             lr, x0, #0x541
    //     0x6e8d38: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8d3c: blr             lr
    // 0x6e8d40: add             SP, SP, #8
    // 0x6e8d44: tbnz            w0, #4, #0x6e8dc0
    // 0x6e8d48: ldur            x1, [fp, #-0x80]
    // 0x6e8d4c: r0 = LoadClassIdInstr(r1)
    //     0x6e8d4c: ldur            x0, [x1, #-1]
    //     0x6e8d50: ubfx            x0, x0, #0xc, #0x14
    // 0x6e8d54: SaveReg r1
    //     0x6e8d54: str             x1, [SP, #-8]!
    // 0x6e8d58: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x6e8d58: add             lr, x0, #0x5ca
    //     0x6e8d5c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8d60: blr             lr
    // 0x6e8d64: add             SP, SP, #8
    // 0x6e8d68: stur            x0, [fp, #-0x88]
    // 0x6e8d6c: ldur            x2, [fp, #-0x70]
    // 0x6e8d70: LoadField: r1 = r2->field_17
    //     0x6e8d70: ldur            w1, [x2, #0x17]
    // 0x6e8d74: DecompressPointer r1
    //     0x6e8d74: add             x1, x1, HEAP, lsl #32
    // 0x6e8d78: stp             x0, x1, [SP, #-0x10]!
    // 0x6e8d7c: r0 = contains()
    //     0x6e8d7c: bl              #0x6b9fe4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::contains
    // 0x6e8d80: add             SP, SP, #0x10
    // 0x6e8d84: tbnz            w0, #4, #0x6e8db0
    // 0x6e8d88: ldur            x1, [fp, #-0x88]
    // 0x6e8d8c: cmp             w1, NULL
    // 0x6e8d90: b.eq            #0x6e8de0
    // 0x6e8d94: ldur            x16, [fp, #-0x78]
    // 0x6e8d98: stp             x16, x1, [SP, #-0x10]!
    // 0x6e8d9c: mov             x0, x1
    // 0x6e8da0: ClosureCall
    //     0x6e8da0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6e8da4: ldur            x2, [x0, #0x1f]
    //     0x6e8da8: blr             x2
    // 0x6e8dac: add             SP, SP, #0x10
    // 0x6e8db0: ldur            x2, [fp, #-0x70]
    // 0x6e8db4: ldur            x1, [fp, #-0x78]
    // 0x6e8db8: ldur            x0, [fp, #-0x80]
    // 0x6e8dbc: b               #0x6e8d04
    // 0x6e8dc0: r0 = Null
    //     0x6e8dc0: mov             x0, NULL
    // 0x6e8dc4: LeaveFrame
    //     0x6e8dc4: mov             SP, fp
    //     0x6e8dc8: ldp             fp, lr, [SP], #0x10
    // 0x6e8dcc: ret
    //     0x6e8dcc: ret             
    // 0x6e8dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8dd4: b               #0x6e8bc0
    // 0x6e8dd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e8dd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8ddc: b               #0x6e8d28
    // 0x6e8de0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6e8de0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ addStatusListener(/* No info */) {
    // ** addr: 0xc52cd0, size: 0x58
    // 0xc52cd0: EnterFrame
    //     0xc52cd0: stp             fp, lr, [SP, #-0x10]!
    //     0xc52cd4: mov             fp, SP
    // 0xc52cd8: CheckStackOverflow
    //     0xc52cd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc52cdc: cmp             SP, x16
    //     0xc52ce0: b.ls            #0xc52d20
    // 0xc52ce4: ldr             x16, [fp, #0x18]
    // 0xc52ce8: SaveReg r16
    //     0xc52ce8: str             x16, [SP, #-8]!
    // 0xc52cec: r0 = didRegisterListener()
    //     0xc52cec: bl              #0x6e89d0  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin::didRegisterListener
    // 0xc52cf0: add             SP, SP, #8
    // 0xc52cf4: ldr             x0, [fp, #0x18]
    // 0xc52cf8: LoadField: r1 = r0->field_17
    //     0xc52cf8: ldur            w1, [x0, #0x17]
    // 0xc52cfc: DecompressPointer r1
    //     0xc52cfc: add             x1, x1, HEAP, lsl #32
    // 0xc52d00: ldr             x16, [fp, #0x10]
    // 0xc52d04: stp             x16, x1, [SP, #-0x10]!
    // 0xc52d08: r0 = add()
    //     0xc52d08: bl              #0x6e93b4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::add
    // 0xc52d0c: add             SP, SP, #0x10
    // 0xc52d10: r0 = Null
    //     0xc52d10: mov             x0, NULL
    // 0xc52d14: LeaveFrame
    //     0xc52d14: mov             SP, fp
    //     0xc52d18: ldp             fp, lr, [SP], #0x10
    // 0xc52d1c: ret
    //     0xc52d1c: ret             
    // 0xc52d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc52d20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc52d24: b               #0xc52ce4
  }
  _ removeStatusListener(/* No info */) {
    // ** addr: 0xc5df5c, size: 0x5c
    // 0xc5df5c: EnterFrame
    //     0xc5df5c: stp             fp, lr, [SP, #-0x10]!
    //     0xc5df60: mov             fp, SP
    // 0xc5df64: CheckStackOverflow
    //     0xc5df64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5df68: cmp             SP, x16
    //     0xc5df6c: b.ls            #0xc5dfb0
    // 0xc5df70: ldr             x0, [fp, #0x18]
    // 0xc5df74: LoadField: r1 = r0->field_17
    //     0xc5df74: ldur            w1, [x0, #0x17]
    // 0xc5df78: DecompressPointer r1
    //     0xc5df78: add             x1, x1, HEAP, lsl #32
    // 0xc5df7c: ldr             x16, [fp, #0x10]
    // 0xc5df80: stp             x16, x1, [SP, #-0x10]!
    // 0xc5df84: r0 = remove()
    //     0xc5df84: bl              #0x6f5e78  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0xc5df88: add             SP, SP, #0x10
    // 0xc5df8c: tbnz            w0, #4, #0xc5dfa0
    // 0xc5df90: ldr             x16, [fp, #0x18]
    // 0xc5df94: SaveReg r16
    //     0xc5df94: str             x16, [SP, #-8]!
    // 0xc5df98: r0 = didUnregisterListener()
    //     0xc5df98: bl              #0x6f5fa0  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin::didUnregisterListener
    // 0xc5df9c: add             SP, SP, #8
    // 0xc5dfa0: r0 = Null
    //     0xc5dfa0: mov             x0, NULL
    // 0xc5dfa4: LeaveFrame
    //     0xc5dfa4: mov             SP, fp
    //     0xc5dfa8: ldp             fp, lr, [SP], #0x10
    // 0xc5dfac: ret
    //     0xc5dfac: ret             
    // 0xc5dfb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5dfb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5dfb4: b               #0xc5df70
  }
}

// class id: 4341, size: 0x28, field offset: 0x1c
class ProxyAnimation extends _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin {

  _ ProxyAnimation(/* No info */) {
    // ** addr: 0x5a0c1c, size: 0xbc
    // 0x5a0c1c: EnterFrame
    //     0x5a0c1c: stp             fp, lr, [SP, #-0x10]!
    //     0x5a0c20: mov             fp, SP
    // 0x5a0c24: AllocStack(0x10)
    //     0x5a0c24: sub             SP, SP, #0x10
    // 0x5a0c28: SetupParameters(ProxyAnimation<double> this /* r1, fp-0x10 */, [dynamic _ = Null /* r0, fp-0x8 */])
    //     0x5a0c28: mov             x0, x4
    //     0x5a0c2c: ldur            w1, [x0, #0x13]
    //     0x5a0c30: add             x1, x1, HEAP, lsl #32
    //     0x5a0c34: sub             x0, x1, #2
    //     0x5a0c38: add             x1, fp, w0, sxtw #2
    //     0x5a0c3c: ldr             x1, [x1, #0x10]
    //     0x5a0c40: stur            x1, [fp, #-0x10]
    //     0x5a0c44: cmp             w0, #2
    //     0x5a0c48: b.lt            #0x5a0c5c
    //     0x5a0c4c: add             x2, fp, w0, sxtw #2
    //     0x5a0c50: ldr             x2, [x2, #8]
    //     0x5a0c54: mov             x0, x2
    //     0x5a0c58: b               #0x5a0c60
    //     0x5a0c5c: mov             x0, NULL
    //     0x5a0c60: stur            x0, [fp, #-8]
    // 0x5a0c64: CheckStackOverflow
    //     0x5a0c64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a0c68: cmp             SP, x16
    //     0x5a0c6c: b.ls            #0x5a0cd0
    // 0x5a0c70: SaveReg r1
    //     0x5a0c70: str             x1, [SP, #-8]!
    // 0x5a0c74: r0 = _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin()
    //     0x5a0c74: bl              #0x5a0cd8  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::_ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin
    // 0x5a0c78: add             SP, SP, #8
    // 0x5a0c7c: ldur            x0, [fp, #-8]
    // 0x5a0c80: ldur            x1, [fp, #-0x10]
    // 0x5a0c84: StoreField: r1->field_23 = r0
    //     0x5a0c84: stur            w0, [x1, #0x23]
    //     0x5a0c88: ldurb           w16, [x1, #-1]
    //     0x5a0c8c: ldurb           w17, [x0, #-1]
    //     0x5a0c90: and             x16, x17, x16, lsr #2
    //     0x5a0c94: tst             x16, HEAP, lsr #32
    //     0x5a0c98: b.eq            #0x5a0ca0
    //     0x5a0c9c: bl              #0xd6826c
    // 0x5a0ca0: ldur            x2, [fp, #-8]
    // 0x5a0ca4: cmp             w2, NULL
    // 0x5a0ca8: b.ne            #0x5a0cc0
    // 0x5a0cac: r3 = Instance_AnimationStatus
    //     0x5a0cac: add             x3, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x5a0cb0: ldr             x3, [x3, #0xba8]
    // 0x5a0cb4: r2 = 0.000000
    //     0x5a0cb4: ldr             x2, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x5a0cb8: StoreField: r1->field_1b = r3
    //     0x5a0cb8: stur            w3, [x1, #0x1b]
    // 0x5a0cbc: StoreField: r1->field_1f = r2
    //     0x5a0cbc: stur            w2, [x1, #0x1f]
    // 0x5a0cc0: r0 = Null
    //     0x5a0cc0: mov             x0, NULL
    // 0x5a0cc4: LeaveFrame
    //     0x5a0cc4: mov             SP, fp
    //     0x5a0cc8: ldp             fp, lr, [SP], #0x10
    // 0x5a0ccc: ret
    //     0x5a0ccc: ret             
    // 0x5a0cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a0cd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a0cd4: b               #0x5a0c70
  }
  set _ parent=(/* No info */) {
    // ** addr: 0x7c3688, size: 0x2a4
    // 0x7c3688: EnterFrame
    //     0x7c3688: stp             fp, lr, [SP, #-0x10]!
    //     0x7c368c: mov             fp, SP
    // 0x7c3690: AllocStack(0x8)
    //     0x7c3690: sub             SP, SP, #8
    // 0x7c3694: CheckStackOverflow
    //     0x7c3694: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7c3698: cmp             SP, x16
    //     0x7c369c: b.ls            #0x7c3914
    // 0x7c36a0: ldr             x1, [fp, #0x18]
    // 0x7c36a4: LoadField: r0 = r1->field_23
    //     0x7c36a4: ldur            w0, [x1, #0x23]
    // 0x7c36a8: DecompressPointer r0
    //     0x7c36a8: add             x0, x0, HEAP, lsl #32
    // 0x7c36ac: ldr             x2, [fp, #0x10]
    // 0x7c36b0: r3 = LoadClassIdInstr(r2)
    //     0x7c36b0: ldur            x3, [x2, #-1]
    //     0x7c36b4: ubfx            x3, x3, #0xc, #0x14
    // 0x7c36b8: stp             x0, x2, [SP, #-0x10]!
    // 0x7c36bc: mov             x0, x3
    // 0x7c36c0: mov             lr, x0
    // 0x7c36c4: ldr             lr, [x21, lr, lsl #3]
    // 0x7c36c8: blr             lr
    // 0x7c36cc: add             SP, SP, #0x10
    // 0x7c36d0: tbnz            w0, #4, #0x7c36e4
    // 0x7c36d4: r0 = Null
    //     0x7c36d4: mov             x0, NULL
    // 0x7c36d8: LeaveFrame
    //     0x7c36d8: mov             SP, fp
    //     0x7c36dc: ldp             fp, lr, [SP], #0x10
    // 0x7c36e0: ret
    //     0x7c36e0: ret             
    // 0x7c36e4: ldr             x1, [fp, #0x18]
    // 0x7c36e8: LoadField: r0 = r1->field_23
    //     0x7c36e8: ldur            w0, [x1, #0x23]
    // 0x7c36ec: DecompressPointer r0
    //     0x7c36ec: add             x0, x0, HEAP, lsl #32
    // 0x7c36f0: cmp             w0, NULL
    // 0x7c36f4: b.eq            #0x7c37a0
    // 0x7c36f8: r2 = LoadClassIdInstr(r0)
    //     0x7c36f8: ldur            x2, [x0, #-1]
    //     0x7c36fc: ubfx            x2, x2, #0xc, #0x14
    // 0x7c3700: SaveReg r0
    //     0x7c3700: str             x0, [SP, #-8]!
    // 0x7c3704: mov             x0, x2
    // 0x7c3708: r0 = GDT[cid_x0 + 0x376]()
    //     0x7c3708: add             lr, x0, #0x376
    //     0x7c370c: ldr             lr, [x21, lr, lsl #3]
    //     0x7c3710: blr             lr
    // 0x7c3714: add             SP, SP, #8
    // 0x7c3718: ldr             x1, [fp, #0x18]
    // 0x7c371c: StoreField: r1->field_1b = r0
    //     0x7c371c: stur            w0, [x1, #0x1b]
    //     0x7c3720: ldurb           w16, [x1, #-1]
    //     0x7c3724: ldurb           w17, [x0, #-1]
    //     0x7c3728: and             x16, x17, x16, lsr #2
    //     0x7c372c: tst             x16, HEAP, lsr #32
    //     0x7c3730: b.eq            #0x7c3738
    //     0x7c3734: bl              #0xd6826c
    // 0x7c3738: LoadField: r0 = r1->field_23
    //     0x7c3738: ldur            w0, [x1, #0x23]
    // 0x7c373c: DecompressPointer r0
    //     0x7c373c: add             x0, x0, HEAP, lsl #32
    // 0x7c3740: cmp             w0, NULL
    // 0x7c3744: b.eq            #0x7c391c
    // 0x7c3748: r2 = LoadClassIdInstr(r0)
    //     0x7c3748: ldur            x2, [x0, #-1]
    //     0x7c374c: ubfx            x2, x2, #0xc, #0x14
    // 0x7c3750: SaveReg r0
    //     0x7c3750: str             x0, [SP, #-8]!
    // 0x7c3754: mov             x0, x2
    // 0x7c3758: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7c3758: add             lr, x0, #0xb7c
    //     0x7c375c: ldr             lr, [x21, lr, lsl #3]
    //     0x7c3760: blr             lr
    // 0x7c3764: add             SP, SP, #8
    // 0x7c3768: ldr             x1, [fp, #0x18]
    // 0x7c376c: StoreField: r1->field_1f = r0
    //     0x7c376c: stur            w0, [x1, #0x1f]
    //     0x7c3770: ldurb           w16, [x1, #-1]
    //     0x7c3774: ldurb           w17, [x0, #-1]
    //     0x7c3778: and             x16, x17, x16, lsr #2
    //     0x7c377c: tst             x16, HEAP, lsr #32
    //     0x7c3780: b.eq            #0x7c3788
    //     0x7c3784: bl              #0xd6826c
    // 0x7c3788: LoadField: r0 = r1->field_b
    //     0x7c3788: ldur            x0, [x1, #0xb]
    // 0x7c378c: cmp             x0, #0
    // 0x7c3790: b.le            #0x7c37a0
    // 0x7c3794: SaveReg r1
    //     0x7c3794: str             x1, [SP, #-8]!
    // 0x7c3798: r0 = didStopListening()
    //     0x7c3798: bl              #0xc3d294  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::didStopListening
    // 0x7c379c: add             SP, SP, #8
    // 0x7c37a0: ldr             x1, [fp, #0x18]
    // 0x7c37a4: ldr             x2, [fp, #0x10]
    // 0x7c37a8: mov             x0, x2
    // 0x7c37ac: StoreField: r1->field_23 = r0
    //     0x7c37ac: stur            w0, [x1, #0x23]
    //     0x7c37b0: ldurb           w16, [x1, #-1]
    //     0x7c37b4: ldurb           w17, [x0, #-1]
    //     0x7c37b8: and             x16, x17, x16, lsr #2
    //     0x7c37bc: tst             x16, HEAP, lsr #32
    //     0x7c37c0: b.eq            #0x7c37c8
    //     0x7c37c4: bl              #0xd6826c
    // 0x7c37c8: cmp             w2, NULL
    // 0x7c37cc: b.eq            #0x7c3904
    // 0x7c37d0: LoadField: r0 = r1->field_b
    //     0x7c37d0: ldur            x0, [x1, #0xb]
    // 0x7c37d4: cmp             x0, #0
    // 0x7c37d8: b.le            #0x7c37e8
    // 0x7c37dc: SaveReg r1
    //     0x7c37dc: str             x1, [SP, #-8]!
    // 0x7c37e0: r0 = didStartListening()
    //     0x7c37e0: bl              #0xc69050  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::didStartListening
    // 0x7c37e4: add             SP, SP, #8
    // 0x7c37e8: ldr             x1, [fp, #0x18]
    // 0x7c37ec: LoadField: r2 = r1->field_1f
    //     0x7c37ec: ldur            w2, [x1, #0x1f]
    // 0x7c37f0: DecompressPointer r2
    //     0x7c37f0: add             x2, x2, HEAP, lsl #32
    // 0x7c37f4: stur            x2, [fp, #-8]
    // 0x7c37f8: LoadField: r0 = r1->field_23
    //     0x7c37f8: ldur            w0, [x1, #0x23]
    // 0x7c37fc: DecompressPointer r0
    //     0x7c37fc: add             x0, x0, HEAP, lsl #32
    // 0x7c3800: cmp             w0, NULL
    // 0x7c3804: b.eq            #0x7c3920
    // 0x7c3808: r3 = LoadClassIdInstr(r0)
    //     0x7c3808: ldur            x3, [x0, #-1]
    //     0x7c380c: ubfx            x3, x3, #0xc, #0x14
    // 0x7c3810: SaveReg r0
    //     0x7c3810: str             x0, [SP, #-8]!
    // 0x7c3814: mov             x0, x3
    // 0x7c3818: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7c3818: add             lr, x0, #0xb7c
    //     0x7c381c: ldr             lr, [x21, lr, lsl #3]
    //     0x7c3820: blr             lr
    // 0x7c3824: add             SP, SP, #8
    // 0x7c3828: mov             x1, x0
    // 0x7c382c: ldur            x0, [fp, #-8]
    // 0x7c3830: r2 = LoadClassIdInstr(r0)
    //     0x7c3830: ldur            x2, [x0, #-1]
    //     0x7c3834: ubfx            x2, x2, #0xc, #0x14
    // 0x7c3838: stp             x1, x0, [SP, #-0x10]!
    // 0x7c383c: mov             x0, x2
    // 0x7c3840: mov             lr, x0
    // 0x7c3844: ldr             lr, [x21, lr, lsl #3]
    // 0x7c3848: blr             lr
    // 0x7c384c: add             SP, SP, #0x10
    // 0x7c3850: tbz             w0, #4, #0x7c3864
    // 0x7c3854: ldr             x16, [fp, #0x18]
    // 0x7c3858: SaveReg r16
    //     0x7c3858: str             x16, [SP, #-8]!
    // 0x7c385c: r0 = notifyListeners()
    //     0x7c385c: bl              #0x6e8e2c  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0x7c3860: add             SP, SP, #8
    // 0x7c3864: ldr             x1, [fp, #0x18]
    // 0x7c3868: LoadField: r2 = r1->field_1b
    //     0x7c3868: ldur            w2, [x1, #0x1b]
    // 0x7c386c: DecompressPointer r2
    //     0x7c386c: add             x2, x2, HEAP, lsl #32
    // 0x7c3870: stur            x2, [fp, #-8]
    // 0x7c3874: LoadField: r0 = r1->field_23
    //     0x7c3874: ldur            w0, [x1, #0x23]
    // 0x7c3878: DecompressPointer r0
    //     0x7c3878: add             x0, x0, HEAP, lsl #32
    // 0x7c387c: cmp             w0, NULL
    // 0x7c3880: b.eq            #0x7c3924
    // 0x7c3884: r3 = LoadClassIdInstr(r0)
    //     0x7c3884: ldur            x3, [x0, #-1]
    //     0x7c3888: ubfx            x3, x3, #0xc, #0x14
    // 0x7c388c: SaveReg r0
    //     0x7c388c: str             x0, [SP, #-8]!
    // 0x7c3890: mov             x0, x3
    // 0x7c3894: r0 = GDT[cid_x0 + 0x376]()
    //     0x7c3894: add             lr, x0, #0x376
    //     0x7c3898: ldr             lr, [x21, lr, lsl #3]
    //     0x7c389c: blr             lr
    // 0x7c38a0: add             SP, SP, #8
    // 0x7c38a4: mov             x1, x0
    // 0x7c38a8: ldur            x0, [fp, #-8]
    // 0x7c38ac: cmp             w0, w1
    // 0x7c38b0: b.eq            #0x7c38f8
    // 0x7c38b4: ldr             x1, [fp, #0x18]
    // 0x7c38b8: LoadField: r0 = r1->field_23
    //     0x7c38b8: ldur            w0, [x1, #0x23]
    // 0x7c38bc: DecompressPointer r0
    //     0x7c38bc: add             x0, x0, HEAP, lsl #32
    // 0x7c38c0: cmp             w0, NULL
    // 0x7c38c4: b.eq            #0x7c3928
    // 0x7c38c8: r2 = LoadClassIdInstr(r0)
    //     0x7c38c8: ldur            x2, [x0, #-1]
    //     0x7c38cc: ubfx            x2, x2, #0xc, #0x14
    // 0x7c38d0: SaveReg r0
    //     0x7c38d0: str             x0, [SP, #-8]!
    // 0x7c38d4: mov             x0, x2
    // 0x7c38d8: r0 = GDT[cid_x0 + 0x376]()
    //     0x7c38d8: add             lr, x0, #0x376
    //     0x7c38dc: ldr             lr, [x21, lr, lsl #3]
    //     0x7c38e0: blr             lr
    // 0x7c38e4: add             SP, SP, #8
    // 0x7c38e8: ldr             x16, [fp, #0x18]
    // 0x7c38ec: stp             x0, x16, [SP, #-0x10]!
    // 0x7c38f0: r0 = notifyStatusListeners()
    //     0x7c38f0: bl              #0x6e8ba8  ; [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners
    // 0x7c38f4: add             SP, SP, #0x10
    // 0x7c38f8: ldr             x1, [fp, #0x18]
    // 0x7c38fc: StoreField: r1->field_1b = rNULL
    //     0x7c38fc: stur            NULL, [x1, #0x1b]
    // 0x7c3900: StoreField: r1->field_1f = rNULL
    //     0x7c3900: stur            NULL, [x1, #0x1f]
    // 0x7c3904: r0 = Null
    //     0x7c3904: mov             x0, NULL
    // 0x7c3908: LeaveFrame
    //     0x7c3908: mov             SP, fp
    //     0x7c390c: ldp             fp, lr, [SP], #0x10
    // 0x7c3910: ret
    //     0x7c3910: ret             
    // 0x7c3914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7c3914: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7c3918: b               #0x7c36a0
    // 0x7c391c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7c391c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7c3920: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7c3920: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7c3924: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7c3924: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7c3928: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7c3928: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4984, size: 0x15c
    // 0xad4984: EnterFrame
    //     0xad4984: stp             fp, lr, [SP, #-0x10]!
    //     0xad4988: mov             fp, SP
    // 0xad498c: AllocStack(0x10)
    //     0xad498c: sub             SP, SP, #0x10
    // 0xad4990: CheckStackOverflow
    //     0xad4990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4994: cmp             SP, x16
    //     0xad4998: b.ls            #0xad4ad8
    // 0xad499c: ldr             x0, [fp, #0x10]
    // 0xad49a0: LoadField: r3 = r0->field_23
    //     0xad49a0: ldur            w3, [x0, #0x23]
    // 0xad49a4: DecompressPointer r3
    //     0xad49a4: add             x3, x3, HEAP, lsl #32
    // 0xad49a8: stur            x3, [fp, #-0x10]
    // 0xad49ac: cmp             w3, NULL
    // 0xad49b0: b.ne            #0xad4a90
    // 0xad49b4: r1 = Null
    //     0xad49b4: mov             x1, NULL
    // 0xad49b8: r2 = 12
    //     0xad49b8: mov             x2, #0xc
    // 0xad49bc: r0 = AllocateArray()
    //     0xad49bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad49c0: stur            x0, [fp, #-8]
    // 0xad49c4: r17 = "ProxyAnimation"
    //     0xad49c4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d190] "ProxyAnimation"
    //     0xad49c8: ldr             x17, [x17, #0x190]
    // 0xad49cc: StoreField: r0->field_f = r17
    //     0xad49cc: stur            w17, [x0, #0xf]
    // 0xad49d0: r17 = "(null; "
    //     0xad49d0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d198] "(null; "
    //     0xad49d4: ldr             x17, [x17, #0x198]
    // 0xad49d8: StoreField: r0->field_13 = r17
    //     0xad49d8: stur            w17, [x0, #0x13]
    // 0xad49dc: ldr             x16, [fp, #0x10]
    // 0xad49e0: SaveReg r16
    //     0xad49e0: str             x16, [SP, #-8]!
    // 0xad49e4: r0 = toStringDetails()
    //     0xad49e4: bl              #0xbea25c  ; [package:flutter/src/animation/animation.dart] Animation::toStringDetails
    // 0xad49e8: add             SP, SP, #8
    // 0xad49ec: ldur            x1, [fp, #-8]
    // 0xad49f0: ArrayStore: r1[2] = r0  ; List_4
    //     0xad49f0: add             x25, x1, #0x17
    //     0xad49f4: str             w0, [x25]
    //     0xad49f8: tbz             w0, #0, #0xad4a14
    //     0xad49fc: ldurb           w16, [x1, #-1]
    //     0xad4a00: ldurb           w17, [x0, #-1]
    //     0xad4a04: and             x16, x17, x16, lsr #2
    //     0xad4a08: tst             x16, HEAP, lsr #32
    //     0xad4a0c: b.eq            #0xad4a14
    //     0xad4a10: bl              #0xd67e5c
    // 0xad4a14: ldur            x1, [fp, #-8]
    // 0xad4a18: r17 = " "
    //     0xad4a18: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xad4a1c: StoreField: r1->field_1b = r17
    //     0xad4a1c: stur            w17, [x1, #0x1b]
    // 0xad4a20: ldr             x16, [fp, #0x10]
    // 0xad4a24: SaveReg r16
    //     0xad4a24: str             x16, [SP, #-8]!
    // 0xad4a28: r0 = value()
    //     0xad4a28: bl              #0xc24c94  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::value
    // 0xad4a2c: add             SP, SP, #8
    // 0xad4a30: SaveReg r0
    //     0xad4a30: str             x0, [SP, #-8]!
    // 0xad4a34: r0 = 3
    //     0xad4a34: mov             x0, #3
    // 0xad4a38: SaveReg r0
    //     0xad4a38: str             x0, [SP, #-8]!
    // 0xad4a3c: r0 = toStringAsFixed()
    //     0xad4a3c: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad4a40: add             SP, SP, #0x10
    // 0xad4a44: ldur            x1, [fp, #-8]
    // 0xad4a48: ArrayStore: r1[4] = r0  ; List_4
    //     0xad4a48: add             x25, x1, #0x1f
    //     0xad4a4c: str             w0, [x25]
    //     0xad4a50: tbz             w0, #0, #0xad4a6c
    //     0xad4a54: ldurb           w16, [x1, #-1]
    //     0xad4a58: ldurb           w17, [x0, #-1]
    //     0xad4a5c: and             x16, x17, x16, lsr #2
    //     0xad4a60: tst             x16, HEAP, lsr #32
    //     0xad4a64: b.eq            #0xad4a6c
    //     0xad4a68: bl              #0xd67e5c
    // 0xad4a6c: ldur            x0, [fp, #-8]
    // 0xad4a70: r17 = ")"
    //     0xad4a70: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad4a74: StoreField: r0->field_23 = r17
    //     0xad4a74: stur            w17, [x0, #0x23]
    // 0xad4a78: SaveReg r0
    //     0xad4a78: str             x0, [SP, #-8]!
    // 0xad4a7c: r0 = _interpolate()
    //     0xad4a7c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4a80: add             SP, SP, #8
    // 0xad4a84: LeaveFrame
    //     0xad4a84: mov             SP, fp
    //     0xad4a88: ldp             fp, lr, [SP], #0x10
    // 0xad4a8c: ret
    //     0xad4a8c: ret             
    // 0xad4a90: r1 = Null
    //     0xad4a90: mov             x1, NULL
    // 0xad4a94: r2 = 6
    //     0xad4a94: mov             x2, #6
    // 0xad4a98: r0 = AllocateArray()
    //     0xad4a98: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4a9c: mov             x1, x0
    // 0xad4aa0: ldur            x0, [fp, #-0x10]
    // 0xad4aa4: StoreField: r1->field_f = r0
    //     0xad4aa4: stur            w0, [x1, #0xf]
    // 0xad4aa8: r17 = "➩"
    //     0xad4aa8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad4aac: ldr             x17, [x17, #0x1a0]
    // 0xad4ab0: StoreField: r1->field_13 = r17
    //     0xad4ab0: stur            w17, [x1, #0x13]
    // 0xad4ab4: r17 = "ProxyAnimation"
    //     0xad4ab4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d190] "ProxyAnimation"
    //     0xad4ab8: ldr             x17, [x17, #0x190]
    // 0xad4abc: StoreField: r1->field_17 = r17
    //     0xad4abc: stur            w17, [x1, #0x17]
    // 0xad4ac0: SaveReg r1
    //     0xad4ac0: str             x1, [SP, #-8]!
    // 0xad4ac4: r0 = _interpolate()
    //     0xad4ac4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4ac8: add             SP, SP, #8
    // 0xad4acc: LeaveFrame
    //     0xad4acc: mov             SP, fp
    //     0xad4ad0: ldp             fp, lr, [SP], #0x10
    // 0xad4ad4: ret
    //     0xad4ad4: ret             
    // 0xad4ad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4ad8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4adc: b               #0xad499c
  }
  get _ value(/* No info */) {
    // ** addr: 0xc24c94, size: 0xb0
    // 0xc24c94: EnterFrame
    //     0xc24c94: stp             fp, lr, [SP, #-0x10]!
    //     0xc24c98: mov             fp, SP
    // 0xc24c9c: CheckStackOverflow
    //     0xc24c9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc24ca0: cmp             SP, x16
    //     0xc24ca4: b.ls            #0xc24d28
    // 0xc24ca8: ldr             x0, [fp, #0x10]
    // 0xc24cac: LoadField: r1 = r0->field_23
    //     0xc24cac: ldur            w1, [x0, #0x23]
    // 0xc24cb0: DecompressPointer r1
    //     0xc24cb0: add             x1, x1, HEAP, lsl #32
    // 0xc24cb4: cmp             w1, NULL
    // 0xc24cb8: b.eq            #0xc24ce0
    // 0xc24cbc: r0 = LoadClassIdInstr(r1)
    //     0xc24cbc: ldur            x0, [x1, #-1]
    //     0xc24cc0: ubfx            x0, x0, #0xc, #0x14
    // 0xc24cc4: SaveReg r1
    //     0xc24cc4: str             x1, [SP, #-8]!
    // 0xc24cc8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc24cc8: add             lr, x0, #0xb7c
    //     0xc24ccc: ldr             lr, [x21, lr, lsl #3]
    //     0xc24cd0: blr             lr
    // 0xc24cd4: add             SP, SP, #8
    // 0xc24cd8: LoadField: d0 = r0->field_7
    //     0xc24cd8: ldur            d0, [x0, #7]
    // 0xc24cdc: b               #0xc24cf4
    // 0xc24ce0: LoadField: r1 = r0->field_1f
    //     0xc24ce0: ldur            w1, [x0, #0x1f]
    // 0xc24ce4: DecompressPointer r1
    //     0xc24ce4: add             x1, x1, HEAP, lsl #32
    // 0xc24ce8: cmp             w1, NULL
    // 0xc24cec: b.eq            #0xc24d30
    // 0xc24cf0: LoadField: d0 = r1->field_7
    //     0xc24cf0: ldur            d0, [x1, #7]
    // 0xc24cf4: r0 = inline_Allocate_Double()
    //     0xc24cf4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc24cf8: add             x0, x0, #0x10
    //     0xc24cfc: cmp             x1, x0
    //     0xc24d00: b.ls            #0xc24d34
    //     0xc24d04: str             x0, [THR, #0x60]  ; THR::top
    //     0xc24d08: sub             x0, x0, #0xf
    //     0xc24d0c: mov             x1, #0xd108
    //     0xc24d10: movk            x1, #3, lsl #16
    //     0xc24d14: stur            x1, [x0, #-1]
    // 0xc24d18: StoreField: r0->field_7 = d0
    //     0xc24d18: stur            d0, [x0, #7]
    // 0xc24d1c: LeaveFrame
    //     0xc24d1c: mov             SP, fp
    //     0xc24d20: ldp             fp, lr, [SP], #0x10
    // 0xc24d24: ret
    //     0xc24d24: ret             
    // 0xc24d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc24d28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc24d2c: b               #0xc24ca8
    // 0xc24d30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc24d30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc24d34: SaveReg d0
    //     0xc24d34: str             q0, [SP, #-0x10]!
    // 0xc24d38: r0 = AllocateDouble()
    //     0xc24d38: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc24d3c: RestoreReg d0
    //     0xc24d3c: ldr             q0, [SP], #0x10
    // 0xc24d40: b               #0xc24d18
  }
  _ didStopListening(/* No info */) {
    // ** addr: 0xc3d294, size: 0x100
    // 0xc3d294: EnterFrame
    //     0xc3d294: stp             fp, lr, [SP, #-0x10]!
    //     0xc3d298: mov             fp, SP
    // 0xc3d29c: AllocStack(0x8)
    //     0xc3d29c: sub             SP, SP, #8
    // 0xc3d2a0: CheckStackOverflow
    //     0xc3d2a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3d2a4: cmp             SP, x16
    //     0xc3d2a8: b.ls            #0xc3d388
    // 0xc3d2ac: ldr             x0, [fp, #0x10]
    // 0xc3d2b0: LoadField: r1 = r0->field_23
    //     0xc3d2b0: ldur            w1, [x0, #0x23]
    // 0xc3d2b4: DecompressPointer r1
    //     0xc3d2b4: add             x1, x1, HEAP, lsl #32
    // 0xc3d2b8: stur            x1, [fp, #-8]
    // 0xc3d2bc: cmp             w1, NULL
    // 0xc3d2c0: b.eq            #0xc3d378
    // 0xc3d2c4: r1 = 1
    //     0xc3d2c4: mov             x1, #1
    // 0xc3d2c8: r0 = AllocateContext()
    //     0xc3d2c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc3d2cc: mov             x1, x0
    // 0xc3d2d0: ldr             x0, [fp, #0x10]
    // 0xc3d2d4: StoreField: r1->field_f = r0
    //     0xc3d2d4: stur            w0, [x1, #0xf]
    // 0xc3d2d8: mov             x2, x1
    // 0xc3d2dc: r1 = Function 'notifyListeners':.
    //     0xc3d2dc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c8e8] AnonymousClosure: (0x6e8de4), in [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners (0x6e8e2c)
    //     0xc3d2e0: ldr             x1, [x1, #0x8e8]
    // 0xc3d2e4: r0 = AllocateClosure()
    //     0xc3d2e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc3d2e8: mov             x1, x0
    // 0xc3d2ec: ldur            x0, [fp, #-8]
    // 0xc3d2f0: r2 = LoadClassIdInstr(r0)
    //     0xc3d2f0: ldur            x2, [x0, #-1]
    //     0xc3d2f4: ubfx            x2, x2, #0xc, #0x14
    // 0xc3d2f8: stp             x1, x0, [SP, #-0x10]!
    // 0xc3d2fc: mov             x0, x2
    // 0xc3d300: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xc3d300: mov             x17, #0xc2d6
    //     0xc3d304: add             lr, x0, x17
    //     0xc3d308: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d30c: blr             lr
    // 0xc3d310: add             SP, SP, #0x10
    // 0xc3d314: ldr             x0, [fp, #0x10]
    // 0xc3d318: LoadField: r1 = r0->field_23
    //     0xc3d318: ldur            w1, [x0, #0x23]
    // 0xc3d31c: DecompressPointer r1
    //     0xc3d31c: add             x1, x1, HEAP, lsl #32
    // 0xc3d320: stur            x1, [fp, #-8]
    // 0xc3d324: cmp             w1, NULL
    // 0xc3d328: b.eq            #0xc3d390
    // 0xc3d32c: r1 = 1
    //     0xc3d32c: mov             x1, #1
    // 0xc3d330: r0 = AllocateContext()
    //     0xc3d330: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc3d334: mov             x1, x0
    // 0xc3d338: ldr             x0, [fp, #0x10]
    // 0xc3d33c: StoreField: r1->field_f = r0
    //     0xc3d33c: stur            w0, [x1, #0xf]
    // 0xc3d340: mov             x2, x1
    // 0xc3d344: r1 = Function 'notifyStatusListeners':.
    //     0xc3d344: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c8f0] AnonymousClosure: (0x6e8b5c), in [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners (0x6e8ba8)
    //     0xc3d348: ldr             x1, [x1, #0x8f0]
    // 0xc3d34c: r0 = AllocateClosure()
    //     0xc3d34c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc3d350: mov             x1, x0
    // 0xc3d354: ldur            x0, [fp, #-8]
    // 0xc3d358: r2 = LoadClassIdInstr(r0)
    //     0xc3d358: ldur            x2, [x0, #-1]
    //     0xc3d35c: ubfx            x2, x2, #0xc, #0x14
    // 0xc3d360: stp             x1, x0, [SP, #-0x10]!
    // 0xc3d364: mov             x0, x2
    // 0xc3d368: r0 = GDT[cid_x0 + 0x490]()
    //     0xc3d368: add             lr, x0, #0x490
    //     0xc3d36c: ldr             lr, [x21, lr, lsl #3]
    //     0xc3d370: blr             lr
    // 0xc3d374: add             SP, SP, #0x10
    // 0xc3d378: r0 = Null
    //     0xc3d378: mov             x0, NULL
    // 0xc3d37c: LeaveFrame
    //     0xc3d37c: mov             SP, fp
    //     0xc3d380: ldp             fp, lr, [SP], #0x10
    // 0xc3d384: ret
    //     0xc3d384: ret             
    // 0xc3d388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3d388: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3d38c: b               #0xc3d2ac
    // 0xc3d390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc3d390: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ status(/* No info */) {
    // ** addr: 0xc6476c, size: 0x74
    // 0xc6476c: EnterFrame
    //     0xc6476c: stp             fp, lr, [SP, #-0x10]!
    //     0xc64770: mov             fp, SP
    // 0xc64774: CheckStackOverflow
    //     0xc64774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc64778: cmp             SP, x16
    //     0xc6477c: b.ls            #0xc647d4
    // 0xc64780: ldr             x0, [fp, #0x10]
    // 0xc64784: LoadField: r1 = r0->field_23
    //     0xc64784: ldur            w1, [x0, #0x23]
    // 0xc64788: DecompressPointer r1
    //     0xc64788: add             x1, x1, HEAP, lsl #32
    // 0xc6478c: cmp             w1, NULL
    // 0xc64790: b.eq            #0xc647b4
    // 0xc64794: r0 = LoadClassIdInstr(r1)
    //     0xc64794: ldur            x0, [x1, #-1]
    //     0xc64798: ubfx            x0, x0, #0xc, #0x14
    // 0xc6479c: SaveReg r1
    //     0xc6479c: str             x1, [SP, #-8]!
    // 0xc647a0: r0 = GDT[cid_x0 + 0x376]()
    //     0xc647a0: add             lr, x0, #0x376
    //     0xc647a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc647a8: blr             lr
    // 0xc647ac: add             SP, SP, #8
    // 0xc647b0: b               #0xc647c8
    // 0xc647b4: LoadField: r1 = r0->field_1b
    //     0xc647b4: ldur            w1, [x0, #0x1b]
    // 0xc647b8: DecompressPointer r1
    //     0xc647b8: add             x1, x1, HEAP, lsl #32
    // 0xc647bc: cmp             w1, NULL
    // 0xc647c0: b.eq            #0xc647dc
    // 0xc647c4: mov             x0, x1
    // 0xc647c8: LeaveFrame
    //     0xc647c8: mov             SP, fp
    //     0xc647cc: ldp             fp, lr, [SP], #0x10
    // 0xc647d0: ret
    //     0xc647d0: ret             
    // 0xc647d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc647d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc647d8: b               #0xc64780
    // 0xc647dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc647dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didStartListening(/* No info */) {
    // ** addr: 0xc69050, size: 0x100
    // 0xc69050: EnterFrame
    //     0xc69050: stp             fp, lr, [SP, #-0x10]!
    //     0xc69054: mov             fp, SP
    // 0xc69058: AllocStack(0x8)
    //     0xc69058: sub             SP, SP, #8
    // 0xc6905c: CheckStackOverflow
    //     0xc6905c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc69060: cmp             SP, x16
    //     0xc69064: b.ls            #0xc69144
    // 0xc69068: ldr             x0, [fp, #0x10]
    // 0xc6906c: LoadField: r1 = r0->field_23
    //     0xc6906c: ldur            w1, [x0, #0x23]
    // 0xc69070: DecompressPointer r1
    //     0xc69070: add             x1, x1, HEAP, lsl #32
    // 0xc69074: stur            x1, [fp, #-8]
    // 0xc69078: cmp             w1, NULL
    // 0xc6907c: b.eq            #0xc69134
    // 0xc69080: r1 = 1
    //     0xc69080: mov             x1, #1
    // 0xc69084: r0 = AllocateContext()
    //     0xc69084: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc69088: mov             x1, x0
    // 0xc6908c: ldr             x0, [fp, #0x10]
    // 0xc69090: StoreField: r1->field_f = r0
    //     0xc69090: stur            w0, [x1, #0xf]
    // 0xc69094: mov             x2, x1
    // 0xc69098: r1 = Function 'notifyListeners':.
    //     0xc69098: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c8e8] AnonymousClosure: (0x6e8de4), in [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::notifyListeners (0x6e8e2c)
    //     0xc6909c: ldr             x1, [x1, #0x8e8]
    // 0xc690a0: r0 = AllocateClosure()
    //     0xc690a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc690a4: mov             x1, x0
    // 0xc690a8: ldur            x0, [fp, #-8]
    // 0xc690ac: r2 = LoadClassIdInstr(r0)
    //     0xc690ac: ldur            x2, [x0, #-1]
    //     0xc690b0: ubfx            x2, x2, #0xc, #0x14
    // 0xc690b4: stp             x1, x0, [SP, #-0x10]!
    // 0xc690b8: mov             x0, x2
    // 0xc690bc: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0xc690bc: mov             x17, #0xc3ab
    //     0xc690c0: add             lr, x0, x17
    //     0xc690c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc690c8: blr             lr
    // 0xc690cc: add             SP, SP, #0x10
    // 0xc690d0: ldr             x0, [fp, #0x10]
    // 0xc690d4: LoadField: r1 = r0->field_23
    //     0xc690d4: ldur            w1, [x0, #0x23]
    // 0xc690d8: DecompressPointer r1
    //     0xc690d8: add             x1, x1, HEAP, lsl #32
    // 0xc690dc: stur            x1, [fp, #-8]
    // 0xc690e0: cmp             w1, NULL
    // 0xc690e4: b.eq            #0xc6914c
    // 0xc690e8: r1 = 1
    //     0xc690e8: mov             x1, #1
    // 0xc690ec: r0 = AllocateContext()
    //     0xc690ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc690f0: mov             x1, x0
    // 0xc690f4: ldr             x0, [fp, #0x10]
    // 0xc690f8: StoreField: r1->field_f = r0
    //     0xc690f8: stur            w0, [x1, #0xf]
    // 0xc690fc: mov             x2, x1
    // 0xc69100: r1 = Function 'notifyStatusListeners':.
    //     0xc69100: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c8f0] AnonymousClosure: (0x6e8b5c), in [package:flutter/src/animation/animations.dart] _ProxyAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::notifyStatusListeners (0x6e8ba8)
    //     0xc69104: ldr             x1, [x1, #0x8f0]
    // 0xc69108: r0 = AllocateClosure()
    //     0xc69108: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6910c: mov             x1, x0
    // 0xc69110: ldur            x0, [fp, #-8]
    // 0xc69114: r2 = LoadClassIdInstr(r0)
    //     0xc69114: ldur            x2, [x0, #-1]
    //     0xc69118: ubfx            x2, x2, #0xc, #0x14
    // 0xc6911c: stp             x1, x0, [SP, #-0x10]!
    // 0xc69120: mov             x0, x2
    // 0xc69124: r0 = GDT[cid_x0 + 0x80c]()
    //     0xc69124: add             lr, x0, #0x80c
    //     0xc69128: ldr             lr, [x21, lr, lsl #3]
    //     0xc6912c: blr             lr
    // 0xc69130: add             SP, SP, #0x10
    // 0xc69134: r0 = Null
    //     0xc69134: mov             x0, NULL
    // 0xc69138: LeaveFrame
    //     0xc69138: mov             SP, fp
    //     0xc6913c: ldp             fp, lr, [SP], #0x10
    // 0xc69140: ret
    //     0xc69140: ret             
    // 0xc69144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc69144: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc69148: b               #0xc69068
    // 0xc6914c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc6914c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4342, size: 0x10, field offset: 0xc
//   const constructor, 
class AlwaysStoppedAnimation<X0> extends Animation<X0> {

  Color field_c;

  _ toStringDetails(/* No info */) {
    // ** addr: 0xbea1d4, size: 0x88
    // 0xbea1d4: EnterFrame
    //     0xbea1d4: stp             fp, lr, [SP, #-0x10]!
    //     0xbea1d8: mov             fp, SP
    // 0xbea1dc: AllocStack(0x8)
    //     0xbea1dc: sub             SP, SP, #8
    // 0xbea1e0: CheckStackOverflow
    //     0xbea1e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbea1e4: cmp             SP, x16
    //     0xbea1e8: b.ls            #0xbea254
    // 0xbea1ec: ldr             x16, [fp, #0x10]
    // 0xbea1f0: SaveReg r16
    //     0xbea1f0: str             x16, [SP, #-8]!
    // 0xbea1f4: r0 = toStringDetails()
    //     0xbea1f4: bl              #0xbea25c  ; [package:flutter/src/animation/animation.dart] Animation::toStringDetails
    // 0xbea1f8: add             SP, SP, #8
    // 0xbea1fc: r1 = Null
    //     0xbea1fc: mov             x1, NULL
    // 0xbea200: r2 = 8
    //     0xbea200: mov             x2, #8
    // 0xbea204: stur            x0, [fp, #-8]
    // 0xbea208: r0 = AllocateArray()
    //     0xbea208: bl              #0xd6987c  ; AllocateArrayStub
    // 0xbea20c: mov             x1, x0
    // 0xbea210: ldur            x0, [fp, #-8]
    // 0xbea214: StoreField: r1->field_f = r0
    //     0xbea214: stur            w0, [x1, #0xf]
    // 0xbea218: r17 = " "
    //     0xbea218: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xbea21c: StoreField: r1->field_13 = r17
    //     0xbea21c: stur            w17, [x1, #0x13]
    // 0xbea220: ldr             x0, [fp, #0x10]
    // 0xbea224: LoadField: r2 = r0->field_b
    //     0xbea224: ldur            w2, [x0, #0xb]
    // 0xbea228: DecompressPointer r2
    //     0xbea228: add             x2, x2, HEAP, lsl #32
    // 0xbea22c: StoreField: r1->field_17 = r2
    //     0xbea22c: stur            w2, [x1, #0x17]
    // 0xbea230: r17 = "; paused"
    //     0xbea230: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d188] "; paused"
    //     0xbea234: ldr             x17, [x17, #0x188]
    // 0xbea238: StoreField: r1->field_1b = r17
    //     0xbea238: stur            w17, [x1, #0x1b]
    // 0xbea23c: SaveReg r1
    //     0xbea23c: str             x1, [SP, #-8]!
    // 0xbea240: r0 = _interpolate()
    //     0xbea240: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xbea244: add             SP, SP, #8
    // 0xbea248: LeaveFrame
    //     0xbea248: mov             SP, fp
    //     0xbea24c: ldp             fp, lr, [SP], #0x10
    // 0xbea250: ret
    //     0xbea250: ret             
    // 0xbea254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbea254: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbea258: b               #0xbea1ec
  }
  get _ status(/* No info */) {
    // ** addr: 0xc64760, size: 0xc
    // 0xc64760: r0 = Instance_AnimationStatus
    //     0xc64760: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0xc64764: ldr             x0, [x0, #0xbb8]
    // 0xc64768: ret
    //     0xc64768: ret             
  }
}

// class id: 4343, size: 0xc, field offset: 0xc
//   const constructor, 
class _AlwaysDismissedAnimation extends Animation<double> {

  _ toString(/* No info */) {
    // ** addr: 0xad48b0, size: 0xc
    // 0xad48b0: r0 = "kAlwaysDismissedAnimation"
    //     0xad48b0: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d1a8] "kAlwaysDismissedAnimation"
    //     0xad48b4: ldr             x0, [x0, #0x1a8]
    // 0xad48b8: ret
    //     0xad48b8: ret             
  }
  get _ status(/* No info */) {
    // ** addr: 0xc64754, size: 0xc
    // 0xc64754: r0 = Instance_AnimationStatus
    //     0xc64754: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0xc64758: ldr             x0, [x0, #0xba8]
    // 0xc6475c: ret
    //     0xc6475c: ret             
  }
}

// class id: 4344, size: 0xc, field offset: 0xc
//   const constructor, 
class _AlwaysCompleteAnimation extends Animation<double> {

  _ toString(/* No info */) {
    // ** addr: 0xad48a4, size: 0xc
    // 0xad48a4: r0 = "kAlwaysCompleteAnimation"
    //     0xad48a4: add             x0, PP, #0x22, lsl #12  ; [pp+0x221e0] "kAlwaysCompleteAnimation"
    //     0xad48a8: ldr             x0, [x0, #0x1e0]
    // 0xad48ac: ret
    //     0xad48ac: ret             
  }
  get _ value(/* No info */) {
    // ** addr: 0xc24c84, size: 0x8
    // 0xc24c84: r0 = 1.000000
    //     0xc24c84: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xc24c88: ret
    //     0xc24c88: ret             
  }
  get _ status(/* No info */) {
    // ** addr: 0xc64748, size: 0xc
    // 0xc64748: r0 = Instance_AnimationStatus
    //     0xc64748: add             x0, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0xc6474c: ldr             x0, [x0, #0xba0]
    // 0xc64750: ret
    //     0xc64750: ret             
  }
}

// class id: 4348, size: 0x2c, field offset: 0x14
class TrainHoppingAnimation extends _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin {

  _ TrainHoppingAnimation(/* No info */) {
    // ** addr: 0x7b98e8, size: 0x3c4
    // 0x7b98e8: EnterFrame
    //     0x7b98e8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b98ec: mov             fp, SP
    // 0x7b98f0: AllocStack(0x10)
    //     0x7b98f0: sub             SP, SP, #0x10
    // 0x7b98f4: SetupParameters(TrainHoppingAnimation<double> this /* r3, fp-0x8 */, dynamic _ /* r4 */, dynamic _ /* r5 */, {dynamic onSwitchedTrain = Null /* r1 */})
    //     0x7b98f4: mov             x0, x4
    //     0x7b98f8: ldur            w1, [x0, #0x13]
    //     0x7b98fc: add             x1, x1, HEAP, lsl #32
    //     0x7b9900: sub             x2, x1, #6
    //     0x7b9904: add             x3, fp, w2, sxtw #2
    //     0x7b9908: ldr             x3, [x3, #0x20]
    //     0x7b990c: stur            x3, [fp, #-8]
    //     0x7b9910: add             x4, fp, w2, sxtw #2
    //     0x7b9914: ldr             x4, [x4, #0x18]
    //     0x7b9918: add             x5, fp, w2, sxtw #2
    //     0x7b991c: ldr             x5, [x5, #0x10]
    //     0x7b9920: ldur            w2, [x0, #0x1f]
    //     0x7b9924: add             x2, x2, HEAP, lsl #32
    //     0x7b9928: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1ce00] "onSwitchedTrain"
    //     0x7b992c: ldr             x16, [x16, #0xe00]
    //     0x7b9930: cmp             w2, w16
    //     0x7b9934: b.ne            #0x7b9950
    //     0x7b9938: ldur            w2, [x0, #0x23]
    //     0x7b993c: add             x2, x2, HEAP, lsl #32
    //     0x7b9940: sub             w0, w1, w2
    //     0x7b9944: add             x1, fp, w0, sxtw #2
    //     0x7b9948: ldr             x1, [x1, #8]
    //     0x7b994c: b               #0x7b9954
    //     0x7b9950: mov             x1, NULL
    // 0x7b9954: CheckStackOverflow
    //     0x7b9954: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b9958: cmp             SP, x16
    //     0x7b995c: b.ls            #0x7b9c8c
    // 0x7b9960: mov             x0, x4
    // 0x7b9964: StoreField: r3->field_13 = r0
    //     0x7b9964: stur            w0, [x3, #0x13]
    //     0x7b9968: ldurb           w16, [x3, #-1]
    //     0x7b996c: ldurb           w17, [x0, #-1]
    //     0x7b9970: and             x16, x17, x16, lsr #2
    //     0x7b9974: tst             x16, HEAP, lsr #32
    //     0x7b9978: b.eq            #0x7b9980
    //     0x7b997c: bl              #0xd682ac
    // 0x7b9980: mov             x0, x5
    // 0x7b9984: StoreField: r3->field_17 = r0
    //     0x7b9984: stur            w0, [x3, #0x17]
    //     0x7b9988: ldurb           w16, [x3, #-1]
    //     0x7b998c: ldurb           w17, [x0, #-1]
    //     0x7b9990: and             x16, x17, x16, lsr #2
    //     0x7b9994: tst             x16, HEAP, lsr #32
    //     0x7b9998: b.eq            #0x7b99a0
    //     0x7b999c: bl              #0xd682ac
    // 0x7b99a0: mov             x0, x1
    // 0x7b99a4: StoreField: r3->field_1f = r0
    //     0x7b99a4: stur            w0, [x3, #0x1f]
    //     0x7b99a8: ldurb           w16, [x3, #-1]
    //     0x7b99ac: ldurb           w17, [x0, #-1]
    //     0x7b99b0: and             x16, x17, x16, lsr #2
    //     0x7b99b4: tst             x16, HEAP, lsr #32
    //     0x7b99b8: b.eq            #0x7b99c0
    //     0x7b99bc: bl              #0xd682ac
    // 0x7b99c0: SaveReg r3
    //     0x7b99c0: str             x3, [SP, #-8]!
    // 0x7b99c4: r0 = _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin()
    //     0x7b99c4: bl              #0x6ea9d8  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::_AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin
    // 0x7b99c8: add             SP, SP, #8
    // 0x7b99cc: ldur            x1, [fp, #-8]
    // 0x7b99d0: LoadField: r0 = r1->field_17
    //     0x7b99d0: ldur            w0, [x1, #0x17]
    // 0x7b99d4: DecompressPointer r0
    //     0x7b99d4: add             x0, x0, HEAP, lsl #32
    // 0x7b99d8: cmp             w0, NULL
    // 0x7b99dc: b.eq            #0x7b9b48
    // 0x7b99e0: LoadField: r0 = r1->field_13
    //     0x7b99e0: ldur            w0, [x1, #0x13]
    // 0x7b99e4: DecompressPointer r0
    //     0x7b99e4: add             x0, x0, HEAP, lsl #32
    // 0x7b99e8: cmp             w0, NULL
    // 0x7b99ec: b.eq            #0x7b9c94
    // 0x7b99f0: r2 = LoadClassIdInstr(r0)
    //     0x7b99f0: ldur            x2, [x0, #-1]
    //     0x7b99f4: ubfx            x2, x2, #0xc, #0x14
    // 0x7b99f8: SaveReg r0
    //     0x7b99f8: str             x0, [SP, #-8]!
    // 0x7b99fc: mov             x0, x2
    // 0x7b9a00: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7b9a00: add             lr, x0, #0xb7c
    //     0x7b9a04: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9a08: blr             lr
    // 0x7b9a0c: add             SP, SP, #8
    // 0x7b9a10: mov             x2, x0
    // 0x7b9a14: ldur            x1, [fp, #-8]
    // 0x7b9a18: stur            x2, [fp, #-0x10]
    // 0x7b9a1c: LoadField: r0 = r1->field_17
    //     0x7b9a1c: ldur            w0, [x1, #0x17]
    // 0x7b9a20: DecompressPointer r0
    //     0x7b9a20: add             x0, x0, HEAP, lsl #32
    // 0x7b9a24: cmp             w0, NULL
    // 0x7b9a28: b.eq            #0x7b9c98
    // 0x7b9a2c: r3 = LoadClassIdInstr(r0)
    //     0x7b9a2c: ldur            x3, [x0, #-1]
    //     0x7b9a30: ubfx            x3, x3, #0xc, #0x14
    // 0x7b9a34: SaveReg r0
    //     0x7b9a34: str             x0, [SP, #-8]!
    // 0x7b9a38: mov             x0, x3
    // 0x7b9a3c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7b9a3c: add             lr, x0, #0xb7c
    //     0x7b9a40: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9a44: blr             lr
    // 0x7b9a48: add             SP, SP, #8
    // 0x7b9a4c: mov             x1, x0
    // 0x7b9a50: ldur            x0, [fp, #-0x10]
    // 0x7b9a54: LoadField: d0 = r0->field_7
    //     0x7b9a54: ldur            d0, [x0, #7]
    // 0x7b9a58: LoadField: d1 = r1->field_7
    //     0x7b9a58: ldur            d1, [x1, #7]
    // 0x7b9a5c: fcmp            d0, d1
    // 0x7b9a60: b.vs            #0x7b9a98
    // 0x7b9a64: b.ne            #0x7b9a98
    // 0x7b9a68: ldur            x1, [fp, #-8]
    // 0x7b9a6c: LoadField: r0 = r1->field_17
    //     0x7b9a6c: ldur            w0, [x1, #0x17]
    // 0x7b9a70: DecompressPointer r0
    //     0x7b9a70: add             x0, x0, HEAP, lsl #32
    // 0x7b9a74: StoreField: r1->field_13 = r0
    //     0x7b9a74: stur            w0, [x1, #0x13]
    //     0x7b9a78: ldurb           w16, [x1, #-1]
    //     0x7b9a7c: ldurb           w17, [x0, #-1]
    //     0x7b9a80: and             x16, x17, x16, lsr #2
    //     0x7b9a84: tst             x16, HEAP, lsr #32
    //     0x7b9a88: b.eq            #0x7b9a90
    //     0x7b9a8c: bl              #0xd6826c
    // 0x7b9a90: StoreField: r1->field_17 = rNULL
    //     0x7b9a90: stur            NULL, [x1, #0x17]
    // 0x7b9a94: b               #0x7b9b48
    // 0x7b9a98: ldur            x1, [fp, #-8]
    // 0x7b9a9c: LoadField: r0 = r1->field_13
    //     0x7b9a9c: ldur            w0, [x1, #0x13]
    // 0x7b9aa0: DecompressPointer r0
    //     0x7b9aa0: add             x0, x0, HEAP, lsl #32
    // 0x7b9aa4: cmp             w0, NULL
    // 0x7b9aa8: b.eq            #0x7b9c9c
    // 0x7b9aac: r2 = LoadClassIdInstr(r0)
    //     0x7b9aac: ldur            x2, [x0, #-1]
    //     0x7b9ab0: ubfx            x2, x2, #0xc, #0x14
    // 0x7b9ab4: SaveReg r0
    //     0x7b9ab4: str             x0, [SP, #-8]!
    // 0x7b9ab8: mov             x0, x2
    // 0x7b9abc: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7b9abc: add             lr, x0, #0xb7c
    //     0x7b9ac0: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9ac4: blr             lr
    // 0x7b9ac8: add             SP, SP, #8
    // 0x7b9acc: mov             x2, x0
    // 0x7b9ad0: ldur            x1, [fp, #-8]
    // 0x7b9ad4: stur            x2, [fp, #-0x10]
    // 0x7b9ad8: LoadField: r0 = r1->field_17
    //     0x7b9ad8: ldur            w0, [x1, #0x17]
    // 0x7b9adc: DecompressPointer r0
    //     0x7b9adc: add             x0, x0, HEAP, lsl #32
    // 0x7b9ae0: cmp             w0, NULL
    // 0x7b9ae4: b.eq            #0x7b9ca0
    // 0x7b9ae8: r3 = LoadClassIdInstr(r0)
    //     0x7b9ae8: ldur            x3, [x0, #-1]
    //     0x7b9aec: ubfx            x3, x3, #0xc, #0x14
    // 0x7b9af0: SaveReg r0
    //     0x7b9af0: str             x0, [SP, #-8]!
    // 0x7b9af4: mov             x0, x3
    // 0x7b9af8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7b9af8: add             lr, x0, #0xb7c
    //     0x7b9afc: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9b00: blr             lr
    // 0x7b9b04: add             SP, SP, #8
    // 0x7b9b08: mov             x1, x0
    // 0x7b9b0c: ldur            x0, [fp, #-0x10]
    // 0x7b9b10: LoadField: d0 = r0->field_7
    //     0x7b9b10: ldur            d0, [x0, #7]
    // 0x7b9b14: LoadField: d1 = r1->field_7
    //     0x7b9b14: ldur            d1, [x1, #7]
    // 0x7b9b18: fcmp            d0, d1
    // 0x7b9b1c: b.vs            #0x7b9b38
    // 0x7b9b20: b.le            #0x7b9b38
    // 0x7b9b24: ldur            x1, [fp, #-8]
    // 0x7b9b28: r0 = Instance__TrainHoppingMode
    //     0x7b9b28: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1ce08] Obj!_TrainHoppingMode@b65e71
    //     0x7b9b2c: ldr             x0, [x0, #0xe08]
    // 0x7b9b30: StoreField: r1->field_1b = r0
    //     0x7b9b30: stur            w0, [x1, #0x1b]
    // 0x7b9b34: b               #0x7b9b48
    // 0x7b9b38: ldur            x1, [fp, #-8]
    // 0x7b9b3c: r0 = Instance__TrainHoppingMode
    //     0x7b9b3c: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1ce10] Obj!_TrainHoppingMode@b65e51
    //     0x7b9b40: ldr             x0, [x0, #0xe10]
    // 0x7b9b44: StoreField: r1->field_1b = r0
    //     0x7b9b44: stur            w0, [x1, #0x1b]
    // 0x7b9b48: LoadField: r2 = r1->field_13
    //     0x7b9b48: ldur            w2, [x1, #0x13]
    // 0x7b9b4c: DecompressPointer r2
    //     0x7b9b4c: add             x2, x2, HEAP, lsl #32
    // 0x7b9b50: stur            x2, [fp, #-0x10]
    // 0x7b9b54: cmp             w2, NULL
    // 0x7b9b58: b.eq            #0x7b9ca4
    // 0x7b9b5c: r0 = 59
    //     0x7b9b5c: mov             x0, #0x3b
    // 0x7b9b60: branchIfSmi(r1, 0x7b9b6c)
    //     0x7b9b60: tbz             w1, #0, #0x7b9b6c
    // 0x7b9b64: r0 = LoadClassIdInstr(r1)
    //     0x7b9b64: ldur            x0, [x1, #-1]
    //     0x7b9b68: ubfx            x0, x0, #0xc, #0x14
    // 0x7b9b6c: SaveReg r1
    //     0x7b9b6c: str             x1, [SP, #-8]!
    // 0x7b9b70: r0 = GDT[cid_x0 + -0xffc]()
    //     0x7b9b70: sub             lr, x0, #0xffc
    //     0x7b9b74: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9b78: blr             lr
    // 0x7b9b7c: add             SP, SP, #8
    // 0x7b9b80: mov             x1, x0
    // 0x7b9b84: ldur            x0, [fp, #-0x10]
    // 0x7b9b88: r2 = LoadClassIdInstr(r0)
    //     0x7b9b88: ldur            x2, [x0, #-1]
    //     0x7b9b8c: ubfx            x2, x2, #0xc, #0x14
    // 0x7b9b90: stp             x1, x0, [SP, #-0x10]!
    // 0x7b9b94: mov             x0, x2
    // 0x7b9b98: r0 = GDT[cid_x0 + 0x80c]()
    //     0x7b9b98: add             lr, x0, #0x80c
    //     0x7b9b9c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9ba0: blr             lr
    // 0x7b9ba4: add             SP, SP, #0x10
    // 0x7b9ba8: ldur            x1, [fp, #-8]
    // 0x7b9bac: LoadField: r2 = r1->field_13
    //     0x7b9bac: ldur            w2, [x1, #0x13]
    // 0x7b9bb0: DecompressPointer r2
    //     0x7b9bb0: add             x2, x2, HEAP, lsl #32
    // 0x7b9bb4: stur            x2, [fp, #-0x10]
    // 0x7b9bb8: cmp             w2, NULL
    // 0x7b9bbc: b.eq            #0x7b9ca8
    // 0x7b9bc0: r0 = 59
    //     0x7b9bc0: mov             x0, #0x3b
    // 0x7b9bc4: branchIfSmi(r1, 0x7b9bd0)
    //     0x7b9bc4: tbz             w1, #0, #0x7b9bd0
    // 0x7b9bc8: r0 = LoadClassIdInstr(r1)
    //     0x7b9bc8: ldur            x0, [x1, #-1]
    //     0x7b9bcc: ubfx            x0, x0, #0xc, #0x14
    // 0x7b9bd0: SaveReg r1
    //     0x7b9bd0: str             x1, [SP, #-8]!
    // 0x7b9bd4: r0 = GDT[cid_x0 + -0xffd]()
    //     0x7b9bd4: sub             lr, x0, #0xffd
    //     0x7b9bd8: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9bdc: blr             lr
    // 0x7b9be0: add             SP, SP, #8
    // 0x7b9be4: mov             x1, x0
    // 0x7b9be8: ldur            x0, [fp, #-0x10]
    // 0x7b9bec: r2 = LoadClassIdInstr(r0)
    //     0x7b9bec: ldur            x2, [x0, #-1]
    //     0x7b9bf0: ubfx            x2, x2, #0xc, #0x14
    // 0x7b9bf4: stp             x1, x0, [SP, #-0x10]!
    // 0x7b9bf8: mov             x0, x2
    // 0x7b9bfc: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7b9bfc: mov             x17, #0xc3ab
    //     0x7b9c00: add             lr, x0, x17
    //     0x7b9c04: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9c08: blr             lr
    // 0x7b9c0c: add             SP, SP, #0x10
    // 0x7b9c10: ldur            x0, [fp, #-8]
    // 0x7b9c14: LoadField: r1 = r0->field_17
    //     0x7b9c14: ldur            w1, [x0, #0x17]
    // 0x7b9c18: DecompressPointer r1
    //     0x7b9c18: add             x1, x1, HEAP, lsl #32
    // 0x7b9c1c: stur            x1, [fp, #-0x10]
    // 0x7b9c20: cmp             w1, NULL
    // 0x7b9c24: b.eq            #0x7b9c7c
    // 0x7b9c28: r2 = 59
    //     0x7b9c28: mov             x2, #0x3b
    // 0x7b9c2c: branchIfSmi(r0, 0x7b9c38)
    //     0x7b9c2c: tbz             w0, #0, #0x7b9c38
    // 0x7b9c30: r2 = LoadClassIdInstr(r0)
    //     0x7b9c30: ldur            x2, [x0, #-1]
    //     0x7b9c34: ubfx            x2, x2, #0xc, #0x14
    // 0x7b9c38: SaveReg r0
    //     0x7b9c38: str             x0, [SP, #-8]!
    // 0x7b9c3c: mov             x0, x2
    // 0x7b9c40: r0 = GDT[cid_x0 + -0xffd]()
    //     0x7b9c40: sub             lr, x0, #0xffd
    //     0x7b9c44: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9c48: blr             lr
    // 0x7b9c4c: add             SP, SP, #8
    // 0x7b9c50: mov             x1, x0
    // 0x7b9c54: ldur            x0, [fp, #-0x10]
    // 0x7b9c58: r2 = LoadClassIdInstr(r0)
    //     0x7b9c58: ldur            x2, [x0, #-1]
    //     0x7b9c5c: ubfx            x2, x2, #0xc, #0x14
    // 0x7b9c60: stp             x1, x0, [SP, #-0x10]!
    // 0x7b9c64: mov             x0, x2
    // 0x7b9c68: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7b9c68: mov             x17, #0xc3ab
    //     0x7b9c6c: add             lr, x0, x17
    //     0x7b9c70: ldr             lr, [x21, lr, lsl #3]
    //     0x7b9c74: blr             lr
    // 0x7b9c78: add             SP, SP, #0x10
    // 0x7b9c7c: r0 = Null
    //     0x7b9c7c: mov             x0, NULL
    // 0x7b9c80: LeaveFrame
    //     0x7b9c80: mov             SP, fp
    //     0x7b9c84: ldp             fp, lr, [SP], #0x10
    // 0x7b9c88: ret
    //     0x7b9c88: ret             
    // 0x7b9c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b9c8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b9c90: b               #0x7b9960
    // 0x7b9c94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b9c94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b9c98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b9c98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b9c9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b9c9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b9ca0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b9ca0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b9ca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b9ca4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b9ca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b9ca8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xad479c, size: 0x108
    // 0xad479c: EnterFrame
    //     0xad479c: stp             fp, lr, [SP, #-0x10]!
    //     0xad47a0: mov             fp, SP
    // 0xad47a4: AllocStack(0x10)
    //     0xad47a4: sub             SP, SP, #0x10
    // 0xad47a8: CheckStackOverflow
    //     0xad47a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad47ac: cmp             SP, x16
    //     0xad47b0: b.ls            #0xad489c
    // 0xad47b4: ldr             x0, [fp, #0x10]
    // 0xad47b8: LoadField: r3 = r0->field_17
    //     0xad47b8: ldur            w3, [x0, #0x17]
    // 0xad47bc: DecompressPointer r3
    //     0xad47bc: add             x3, x3, HEAP, lsl #32
    // 0xad47c0: stur            x3, [fp, #-0x10]
    // 0xad47c4: cmp             w3, NULL
    // 0xad47c8: b.eq            #0xad483c
    // 0xad47cc: LoadField: r4 = r0->field_13
    //     0xad47cc: ldur            w4, [x0, #0x13]
    // 0xad47d0: DecompressPointer r4
    //     0xad47d0: add             x4, x4, HEAP, lsl #32
    // 0xad47d4: stur            x4, [fp, #-8]
    // 0xad47d8: r1 = Null
    //     0xad47d8: mov             x1, NULL
    // 0xad47dc: r2 = 12
    //     0xad47dc: mov             x2, #0xc
    // 0xad47e0: r0 = AllocateArray()
    //     0xad47e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad47e4: mov             x1, x0
    // 0xad47e8: ldur            x0, [fp, #-8]
    // 0xad47ec: StoreField: r1->field_f = r0
    //     0xad47ec: stur            w0, [x1, #0xf]
    // 0xad47f0: r17 = "➩"
    //     0xad47f0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad47f4: ldr             x17, [x17, #0x1a0]
    // 0xad47f8: StoreField: r1->field_13 = r17
    //     0xad47f8: stur            w17, [x1, #0x13]
    // 0xad47fc: r17 = "TrainHoppingAnimation"
    //     0xad47fc: add             x17, PP, #0x22, lsl #12  ; [pp+0x221c8] "TrainHoppingAnimation"
    //     0xad4800: ldr             x17, [x17, #0x1c8]
    // 0xad4804: StoreField: r1->field_17 = r17
    //     0xad4804: stur            w17, [x1, #0x17]
    // 0xad4808: r17 = "(next: "
    //     0xad4808: add             x17, PP, #0x22, lsl #12  ; [pp+0x221d0] "(next: "
    //     0xad480c: ldr             x17, [x17, #0x1d0]
    // 0xad4810: StoreField: r1->field_1b = r17
    //     0xad4810: stur            w17, [x1, #0x1b]
    // 0xad4814: ldur            x0, [fp, #-0x10]
    // 0xad4818: StoreField: r1->field_1f = r0
    //     0xad4818: stur            w0, [x1, #0x1f]
    // 0xad481c: r17 = ")"
    //     0xad481c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad4820: StoreField: r1->field_23 = r17
    //     0xad4820: stur            w17, [x1, #0x23]
    // 0xad4824: SaveReg r1
    //     0xad4824: str             x1, [SP, #-8]!
    // 0xad4828: r0 = _interpolate()
    //     0xad4828: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad482c: add             SP, SP, #8
    // 0xad4830: LeaveFrame
    //     0xad4830: mov             SP, fp
    //     0xad4834: ldp             fp, lr, [SP], #0x10
    // 0xad4838: ret
    //     0xad4838: ret             
    // 0xad483c: LoadField: r3 = r0->field_13
    //     0xad483c: ldur            w3, [x0, #0x13]
    // 0xad4840: DecompressPointer r3
    //     0xad4840: add             x3, x3, HEAP, lsl #32
    // 0xad4844: stur            x3, [fp, #-8]
    // 0xad4848: r1 = Null
    //     0xad4848: mov             x1, NULL
    // 0xad484c: r2 = 8
    //     0xad484c: mov             x2, #8
    // 0xad4850: r0 = AllocateArray()
    //     0xad4850: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4854: mov             x1, x0
    // 0xad4858: ldur            x0, [fp, #-8]
    // 0xad485c: StoreField: r1->field_f = r0
    //     0xad485c: stur            w0, [x1, #0xf]
    // 0xad4860: r17 = "➩"
    //     0xad4860: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad4864: ldr             x17, [x17, #0x1a0]
    // 0xad4868: StoreField: r1->field_13 = r17
    //     0xad4868: stur            w17, [x1, #0x13]
    // 0xad486c: r17 = "TrainHoppingAnimation"
    //     0xad486c: add             x17, PP, #0x22, lsl #12  ; [pp+0x221c8] "TrainHoppingAnimation"
    //     0xad4870: ldr             x17, [x17, #0x1c8]
    // 0xad4874: StoreField: r1->field_17 = r17
    //     0xad4874: stur            w17, [x1, #0x17]
    // 0xad4878: r17 = "(no next)"
    //     0xad4878: add             x17, PP, #0x22, lsl #12  ; [pp+0x221d8] "(no next)"
    //     0xad487c: ldr             x17, [x17, #0x1d8]
    // 0xad4880: StoreField: r1->field_1b = r17
    //     0xad4880: stur            w17, [x1, #0x1b]
    // 0xad4884: SaveReg r1
    //     0xad4884: str             x1, [SP, #-8]!
    // 0xad4888: r0 = _interpolate()
    //     0xad4888: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad488c: add             SP, SP, #8
    // 0xad4890: LeaveFrame
    //     0xad4890: mov             SP, fp
    //     0xad4894: ldp             fp, lr, [SP], #0x10
    // 0xad4898: ret
    //     0xad4898: ret             
    // 0xad489c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad489c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad48a0: b               #0xad47b4
  }
  _ dispose(/* No info */) {
    // ** addr: 0xad7e74, size: 0x194
    // 0xad7e74: EnterFrame
    //     0xad7e74: stp             fp, lr, [SP, #-0x10]!
    //     0xad7e78: mov             fp, SP
    // 0xad7e7c: AllocStack(0x8)
    //     0xad7e7c: sub             SP, SP, #8
    // 0xad7e80: CheckStackOverflow
    //     0xad7e80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad7e84: cmp             SP, x16
    //     0xad7e88: b.ls            #0xad7ff8
    // 0xad7e8c: ldr             x0, [fp, #0x10]
    // 0xad7e90: LoadField: r1 = r0->field_13
    //     0xad7e90: ldur            w1, [x0, #0x13]
    // 0xad7e94: DecompressPointer r1
    //     0xad7e94: add             x1, x1, HEAP, lsl #32
    // 0xad7e98: stur            x1, [fp, #-8]
    // 0xad7e9c: cmp             w1, NULL
    // 0xad7ea0: b.eq            #0xad8000
    // 0xad7ea4: r1 = 1
    //     0xad7ea4: mov             x1, #1
    // 0xad7ea8: r0 = AllocateContext()
    //     0xad7ea8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad7eac: mov             x1, x0
    // 0xad7eb0: ldr             x0, [fp, #0x10]
    // 0xad7eb4: StoreField: r1->field_f = r0
    //     0xad7eb4: stur            w0, [x1, #0xf]
    // 0xad7eb8: mov             x2, x1
    // 0xad7ebc: r1 = Function '_statusChangeHandler@576411118':.
    //     0xad7ebc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cdf0] AnonymousClosure: (0xad8478), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler (0xad8404)
    //     0xad7ec0: ldr             x1, [x1, #0xdf0]
    // 0xad7ec4: r0 = AllocateClosure()
    //     0xad7ec4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad7ec8: mov             x1, x0
    // 0xad7ecc: ldur            x0, [fp, #-8]
    // 0xad7ed0: r2 = LoadClassIdInstr(r0)
    //     0xad7ed0: ldur            x2, [x0, #-1]
    //     0xad7ed4: ubfx            x2, x2, #0xc, #0x14
    // 0xad7ed8: stp             x1, x0, [SP, #-0x10]!
    // 0xad7edc: mov             x0, x2
    // 0xad7ee0: r0 = GDT[cid_x0 + 0x490]()
    //     0xad7ee0: add             lr, x0, #0x490
    //     0xad7ee4: ldr             lr, [x21, lr, lsl #3]
    //     0xad7ee8: blr             lr
    // 0xad7eec: add             SP, SP, #0x10
    // 0xad7ef0: ldr             x0, [fp, #0x10]
    // 0xad7ef4: LoadField: r1 = r0->field_13
    //     0xad7ef4: ldur            w1, [x0, #0x13]
    // 0xad7ef8: DecompressPointer r1
    //     0xad7ef8: add             x1, x1, HEAP, lsl #32
    // 0xad7efc: stur            x1, [fp, #-8]
    // 0xad7f00: cmp             w1, NULL
    // 0xad7f04: b.eq            #0xad8004
    // 0xad7f08: r1 = 1
    //     0xad7f08: mov             x1, #1
    // 0xad7f0c: r0 = AllocateContext()
    //     0xad7f0c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad7f10: mov             x1, x0
    // 0xad7f14: ldr             x0, [fp, #0x10]
    // 0xad7f18: StoreField: r1->field_f = r0
    //     0xad7f18: stur            w0, [x1, #0xf]
    // 0xad7f1c: mov             x2, x1
    // 0xad7f20: r1 = Function '_valueChangeHandler@576411118':.
    //     0xad7f20: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cdf8] AnonymousClosure: (0xad8008), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler (0xad8050)
    //     0xad7f24: ldr             x1, [x1, #0xdf8]
    // 0xad7f28: r0 = AllocateClosure()
    //     0xad7f28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad7f2c: mov             x1, x0
    // 0xad7f30: ldur            x0, [fp, #-8]
    // 0xad7f34: r2 = LoadClassIdInstr(r0)
    //     0xad7f34: ldur            x2, [x0, #-1]
    //     0xad7f38: ubfx            x2, x2, #0xc, #0x14
    // 0xad7f3c: stp             x1, x0, [SP, #-0x10]!
    // 0xad7f40: mov             x0, x2
    // 0xad7f44: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xad7f44: mov             x17, #0xc2d6
    //     0xad7f48: add             lr, x0, x17
    //     0xad7f4c: ldr             lr, [x21, lr, lsl #3]
    //     0xad7f50: blr             lr
    // 0xad7f54: add             SP, SP, #0x10
    // 0xad7f58: ldr             x0, [fp, #0x10]
    // 0xad7f5c: StoreField: r0->field_13 = rNULL
    //     0xad7f5c: stur            NULL, [x0, #0x13]
    // 0xad7f60: LoadField: r1 = r0->field_17
    //     0xad7f60: ldur            w1, [x0, #0x17]
    // 0xad7f64: DecompressPointer r1
    //     0xad7f64: add             x1, x1, HEAP, lsl #32
    // 0xad7f68: stur            x1, [fp, #-8]
    // 0xad7f6c: cmp             w1, NULL
    // 0xad7f70: b.eq            #0xad7fc8
    // 0xad7f74: r1 = 1
    //     0xad7f74: mov             x1, #1
    // 0xad7f78: r0 = AllocateContext()
    //     0xad7f78: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad7f7c: mov             x1, x0
    // 0xad7f80: ldr             x0, [fp, #0x10]
    // 0xad7f84: StoreField: r1->field_f = r0
    //     0xad7f84: stur            w0, [x1, #0xf]
    // 0xad7f88: mov             x2, x1
    // 0xad7f8c: r1 = Function '_valueChangeHandler@576411118':.
    //     0xad7f8c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cdf8] AnonymousClosure: (0xad8008), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler (0xad8050)
    //     0xad7f90: ldr             x1, [x1, #0xdf8]
    // 0xad7f94: r0 = AllocateClosure()
    //     0xad7f94: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad7f98: mov             x1, x0
    // 0xad7f9c: ldur            x0, [fp, #-8]
    // 0xad7fa0: r2 = LoadClassIdInstr(r0)
    //     0xad7fa0: ldur            x2, [x0, #-1]
    //     0xad7fa4: ubfx            x2, x2, #0xc, #0x14
    // 0xad7fa8: stp             x1, x0, [SP, #-0x10]!
    // 0xad7fac: mov             x0, x2
    // 0xad7fb0: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xad7fb0: mov             x17, #0xc2d6
    //     0xad7fb4: add             lr, x0, x17
    //     0xad7fb8: ldr             lr, [x21, lr, lsl #3]
    //     0xad7fbc: blr             lr
    // 0xad7fc0: add             SP, SP, #0x10
    // 0xad7fc4: ldr             x0, [fp, #0x10]
    // 0xad7fc8: StoreField: r0->field_17 = rNULL
    //     0xad7fc8: stur            NULL, [x0, #0x17]
    // 0xad7fcc: SaveReg r0
    //     0xad7fcc: str             x0, [SP, #-8]!
    // 0xad7fd0: r0 = clearListeners()
    //     0xad7fd0: bl              #0x7014ac  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::clearListeners
    // 0xad7fd4: add             SP, SP, #8
    // 0xad7fd8: ldr             x16, [fp, #0x10]
    // 0xad7fdc: SaveReg r16
    //     0xad7fdc: str             x16, [SP, #-8]!
    // 0xad7fe0: r0 = clearStatusListeners()
    //     0xad7fe0: bl              #0x70156c  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::clearStatusListeners
    // 0xad7fe4: add             SP, SP, #8
    // 0xad7fe8: r0 = Null
    //     0xad7fe8: mov             x0, NULL
    // 0xad7fec: LeaveFrame
    //     0xad7fec: mov             SP, fp
    //     0xad7ff0: ldp             fp, lr, [SP], #0x10
    // 0xad7ff4: ret
    //     0xad7ff4: ret             
    // 0xad7ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad7ff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad7ffc: b               #0xad7e8c
    // 0xad8000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad8000: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad8004: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad8004: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _valueChangeHandler(dynamic) {
    // ** addr: 0xad8008, size: 0x48
    // 0xad8008: EnterFrame
    //     0xad8008: stp             fp, lr, [SP, #-0x10]!
    //     0xad800c: mov             fp, SP
    // 0xad8010: ldr             x0, [fp, #0x10]
    // 0xad8014: LoadField: r1 = r0->field_17
    //     0xad8014: ldur            w1, [x0, #0x17]
    // 0xad8018: DecompressPointer r1
    //     0xad8018: add             x1, x1, HEAP, lsl #32
    // 0xad801c: CheckStackOverflow
    //     0xad801c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8020: cmp             SP, x16
    //     0xad8024: b.ls            #0xad8048
    // 0xad8028: LoadField: r0 = r1->field_f
    //     0xad8028: ldur            w0, [x1, #0xf]
    // 0xad802c: DecompressPointer r0
    //     0xad802c: add             x0, x0, HEAP, lsl #32
    // 0xad8030: SaveReg r0
    //     0xad8030: str             x0, [SP, #-8]!
    // 0xad8034: r0 = _valueChangeHandler()
    //     0xad8034: bl              #0xad8050  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler
    // 0xad8038: add             SP, SP, #8
    // 0xad803c: LeaveFrame
    //     0xad803c: mov             SP, fp
    //     0xad8040: ldp             fp, lr, [SP], #0x10
    // 0xad8044: ret
    //     0xad8044: ret             
    // 0xad8048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad8048: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad804c: b               #0xad8028
  }
  _ _valueChangeHandler(/* No info */) {
    // ** addr: 0xad8050, size: 0x3b4
    // 0xad8050: EnterFrame
    //     0xad8050: stp             fp, lr, [SP, #-0x10]!
    //     0xad8054: mov             fp, SP
    // 0xad8058: AllocStack(0x10)
    //     0xad8058: sub             SP, SP, #0x10
    // 0xad805c: CheckStackOverflow
    //     0xad805c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8060: cmp             SP, x16
    //     0xad8064: b.ls            #0xad83e4
    // 0xad8068: ldr             x1, [fp, #0x10]
    // 0xad806c: LoadField: r0 = r1->field_17
    //     0xad806c: ldur            w0, [x1, #0x17]
    // 0xad8070: DecompressPointer r0
    //     0xad8070: add             x0, x0, HEAP, lsl #32
    // 0xad8074: cmp             w0, NULL
    // 0xad8078: b.eq            #0xad8330
    // 0xad807c: LoadField: r2 = r1->field_1b
    //     0xad807c: ldur            w2, [x1, #0x1b]
    // 0xad8080: DecompressPointer r2
    //     0xad8080: add             x2, x2, HEAP, lsl #32
    // 0xad8084: cmp             w2, NULL
    // 0xad8088: b.eq            #0xad83ec
    // 0xad808c: LoadField: r3 = r2->field_7
    //     0xad808c: ldur            x3, [x2, #7]
    // 0xad8090: cmp             x3, #0
    // 0xad8094: b.gt            #0xad8120
    // 0xad8098: r2 = LoadClassIdInstr(r0)
    //     0xad8098: ldur            x2, [x0, #-1]
    //     0xad809c: ubfx            x2, x2, #0xc, #0x14
    // 0xad80a0: SaveReg r0
    //     0xad80a0: str             x0, [SP, #-8]!
    // 0xad80a4: mov             x0, x2
    // 0xad80a8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xad80a8: add             lr, x0, #0xb7c
    //     0xad80ac: ldr             lr, [x21, lr, lsl #3]
    //     0xad80b0: blr             lr
    // 0xad80b4: add             SP, SP, #8
    // 0xad80b8: mov             x2, x0
    // 0xad80bc: ldr             x1, [fp, #0x10]
    // 0xad80c0: stur            x2, [fp, #-8]
    // 0xad80c4: LoadField: r0 = r1->field_13
    //     0xad80c4: ldur            w0, [x1, #0x13]
    // 0xad80c8: DecompressPointer r0
    //     0xad80c8: add             x0, x0, HEAP, lsl #32
    // 0xad80cc: cmp             w0, NULL
    // 0xad80d0: b.eq            #0xad83f0
    // 0xad80d4: r3 = LoadClassIdInstr(r0)
    //     0xad80d4: ldur            x3, [x0, #-1]
    //     0xad80d8: ubfx            x3, x3, #0xc, #0x14
    // 0xad80dc: SaveReg r0
    //     0xad80dc: str             x0, [SP, #-8]!
    // 0xad80e0: mov             x0, x3
    // 0xad80e4: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xad80e4: add             lr, x0, #0xb7c
    //     0xad80e8: ldr             lr, [x21, lr, lsl #3]
    //     0xad80ec: blr             lr
    // 0xad80f0: add             SP, SP, #8
    // 0xad80f4: mov             x1, x0
    // 0xad80f8: ldur            x0, [fp, #-8]
    // 0xad80fc: LoadField: d0 = r0->field_7
    //     0xad80fc: ldur            d0, [x0, #7]
    // 0xad8100: LoadField: d1 = r1->field_7
    //     0xad8100: ldur            d1, [x1, #7]
    // 0xad8104: fcmp            d0, d1
    // 0xad8108: b.vs            #0xad8110
    // 0xad810c: b.le            #0xad8118
    // 0xad8110: r0 = false
    //     0xad8110: add             x0, NULL, #0x30  ; false
    // 0xad8114: b               #0xad811c
    // 0xad8118: r0 = true
    //     0xad8118: add             x0, NULL, #0x20  ; true
    // 0xad811c: b               #0xad81a4
    // 0xad8120: r2 = LoadClassIdInstr(r0)
    //     0xad8120: ldur            x2, [x0, #-1]
    //     0xad8124: ubfx            x2, x2, #0xc, #0x14
    // 0xad8128: SaveReg r0
    //     0xad8128: str             x0, [SP, #-8]!
    // 0xad812c: mov             x0, x2
    // 0xad8130: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xad8130: add             lr, x0, #0xb7c
    //     0xad8134: ldr             lr, [x21, lr, lsl #3]
    //     0xad8138: blr             lr
    // 0xad813c: add             SP, SP, #8
    // 0xad8140: mov             x2, x0
    // 0xad8144: ldr             x1, [fp, #0x10]
    // 0xad8148: stur            x2, [fp, #-8]
    // 0xad814c: LoadField: r0 = r1->field_13
    //     0xad814c: ldur            w0, [x1, #0x13]
    // 0xad8150: DecompressPointer r0
    //     0xad8150: add             x0, x0, HEAP, lsl #32
    // 0xad8154: cmp             w0, NULL
    // 0xad8158: b.eq            #0xad83f4
    // 0xad815c: r3 = LoadClassIdInstr(r0)
    //     0xad815c: ldur            x3, [x0, #-1]
    //     0xad8160: ubfx            x3, x3, #0xc, #0x14
    // 0xad8164: SaveReg r0
    //     0xad8164: str             x0, [SP, #-8]!
    // 0xad8168: mov             x0, x3
    // 0xad816c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xad816c: add             lr, x0, #0xb7c
    //     0xad8170: ldr             lr, [x21, lr, lsl #3]
    //     0xad8174: blr             lr
    // 0xad8178: add             SP, SP, #8
    // 0xad817c: mov             x1, x0
    // 0xad8180: ldur            x0, [fp, #-8]
    // 0xad8184: LoadField: d0 = r0->field_7
    //     0xad8184: ldur            d0, [x0, #7]
    // 0xad8188: LoadField: d1 = r1->field_7
    //     0xad8188: ldur            d1, [x1, #7]
    // 0xad818c: fcmp            d0, d1
    // 0xad8190: b.vs            #0xad8198
    // 0xad8194: b.ge            #0xad81a0
    // 0xad8198: r0 = false
    //     0xad8198: add             x0, NULL, #0x30  ; false
    // 0xad819c: b               #0xad81a4
    // 0xad81a0: r0 = true
    //     0xad81a0: add             x0, NULL, #0x20  ; true
    // 0xad81a4: stur            x0, [fp, #-0x10]
    // 0xad81a8: tbnz            w0, #4, #0xad8328
    // 0xad81ac: ldr             x1, [fp, #0x10]
    // 0xad81b0: LoadField: r2 = r1->field_13
    //     0xad81b0: ldur            w2, [x1, #0x13]
    // 0xad81b4: DecompressPointer r2
    //     0xad81b4: add             x2, x2, HEAP, lsl #32
    // 0xad81b8: stur            x2, [fp, #-8]
    // 0xad81bc: cmp             w2, NULL
    // 0xad81c0: b.eq            #0xad83f8
    // 0xad81c4: r1 = 1
    //     0xad81c4: mov             x1, #1
    // 0xad81c8: r0 = AllocateContext()
    //     0xad81c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad81cc: mov             x1, x0
    // 0xad81d0: ldr             x0, [fp, #0x10]
    // 0xad81d4: StoreField: r1->field_f = r0
    //     0xad81d4: stur            w0, [x1, #0xf]
    // 0xad81d8: mov             x2, x1
    // 0xad81dc: r1 = Function '_statusChangeHandler@576411118':.
    //     0xad81dc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cdf0] AnonymousClosure: (0xad8478), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler (0xad8404)
    //     0xad81e0: ldr             x1, [x1, #0xdf0]
    // 0xad81e4: r0 = AllocateClosure()
    //     0xad81e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad81e8: ldur            x1, [fp, #-8]
    // 0xad81ec: r2 = LoadClassIdInstr(r1)
    //     0xad81ec: ldur            x2, [x1, #-1]
    //     0xad81f0: ubfx            x2, x2, #0xc, #0x14
    // 0xad81f4: stp             x0, x1, [SP, #-0x10]!
    // 0xad81f8: mov             x0, x2
    // 0xad81fc: r0 = GDT[cid_x0 + 0x490]()
    //     0xad81fc: add             lr, x0, #0x490
    //     0xad8200: ldr             lr, [x21, lr, lsl #3]
    //     0xad8204: blr             lr
    // 0xad8208: add             SP, SP, #0x10
    // 0xad820c: r1 = 1
    //     0xad820c: mov             x1, #1
    // 0xad8210: r0 = AllocateContext()
    //     0xad8210: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad8214: mov             x1, x0
    // 0xad8218: ldr             x0, [fp, #0x10]
    // 0xad821c: StoreField: r1->field_f = r0
    //     0xad821c: stur            w0, [x1, #0xf]
    // 0xad8220: mov             x2, x1
    // 0xad8224: r1 = Function '_valueChangeHandler@576411118':.
    //     0xad8224: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cdf8] AnonymousClosure: (0xad8008), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler (0xad8050)
    //     0xad8228: ldr             x1, [x1, #0xdf8]
    // 0xad822c: r0 = AllocateClosure()
    //     0xad822c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad8230: mov             x1, x0
    // 0xad8234: ldur            x0, [fp, #-8]
    // 0xad8238: r2 = LoadClassIdInstr(r0)
    //     0xad8238: ldur            x2, [x0, #-1]
    //     0xad823c: ubfx            x2, x2, #0xc, #0x14
    // 0xad8240: stp             x1, x0, [SP, #-0x10]!
    // 0xad8244: mov             x0, x2
    // 0xad8248: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xad8248: mov             x17, #0xc2d6
    //     0xad824c: add             lr, x0, x17
    //     0xad8250: ldr             lr, [x21, lr, lsl #3]
    //     0xad8254: blr             lr
    // 0xad8258: add             SP, SP, #0x10
    // 0xad825c: ldr             x1, [fp, #0x10]
    // 0xad8260: LoadField: r2 = r1->field_17
    //     0xad8260: ldur            w2, [x1, #0x17]
    // 0xad8264: DecompressPointer r2
    //     0xad8264: add             x2, x2, HEAP, lsl #32
    // 0xad8268: mov             x0, x2
    // 0xad826c: stur            x2, [fp, #-8]
    // 0xad8270: StoreField: r1->field_13 = r0
    //     0xad8270: stur            w0, [x1, #0x13]
    //     0xad8274: ldurb           w16, [x1, #-1]
    //     0xad8278: ldurb           w17, [x0, #-1]
    //     0xad827c: and             x16, x17, x16, lsr #2
    //     0xad8280: tst             x16, HEAP, lsr #32
    //     0xad8284: b.eq            #0xad828c
    //     0xad8288: bl              #0xd6826c
    // 0xad828c: StoreField: r1->field_17 = rNULL
    //     0xad828c: stur            NULL, [x1, #0x17]
    // 0xad8290: cmp             w2, NULL
    // 0xad8294: b.eq            #0xad83fc
    // 0xad8298: r1 = 1
    //     0xad8298: mov             x1, #1
    // 0xad829c: r0 = AllocateContext()
    //     0xad829c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad82a0: mov             x1, x0
    // 0xad82a4: ldr             x0, [fp, #0x10]
    // 0xad82a8: StoreField: r1->field_f = r0
    //     0xad82a8: stur            w0, [x1, #0xf]
    // 0xad82ac: mov             x2, x1
    // 0xad82b0: r1 = Function '_statusChangeHandler@576411118':.
    //     0xad82b0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cdf0] AnonymousClosure: (0xad8478), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler (0xad8404)
    //     0xad82b4: ldr             x1, [x1, #0xdf0]
    // 0xad82b8: r0 = AllocateClosure()
    //     0xad82b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad82bc: mov             x1, x0
    // 0xad82c0: ldur            x0, [fp, #-8]
    // 0xad82c4: r2 = LoadClassIdInstr(r0)
    //     0xad82c4: ldur            x2, [x0, #-1]
    //     0xad82c8: ubfx            x2, x2, #0xc, #0x14
    // 0xad82cc: stp             x1, x0, [SP, #-0x10]!
    // 0xad82d0: mov             x0, x2
    // 0xad82d4: r0 = GDT[cid_x0 + 0x80c]()
    //     0xad82d4: add             lr, x0, #0x80c
    //     0xad82d8: ldr             lr, [x21, lr, lsl #3]
    //     0xad82dc: blr             lr
    // 0xad82e0: add             SP, SP, #0x10
    // 0xad82e4: ldr             x1, [fp, #0x10]
    // 0xad82e8: LoadField: r0 = r1->field_13
    //     0xad82e8: ldur            w0, [x1, #0x13]
    // 0xad82ec: DecompressPointer r0
    //     0xad82ec: add             x0, x0, HEAP, lsl #32
    // 0xad82f0: cmp             w0, NULL
    // 0xad82f4: b.eq            #0xad8400
    // 0xad82f8: r2 = LoadClassIdInstr(r0)
    //     0xad82f8: ldur            x2, [x0, #-1]
    //     0xad82fc: ubfx            x2, x2, #0xc, #0x14
    // 0xad8300: SaveReg r0
    //     0xad8300: str             x0, [SP, #-8]!
    // 0xad8304: mov             x0, x2
    // 0xad8308: r0 = GDT[cid_x0 + 0x376]()
    //     0xad8308: add             lr, x0, #0x376
    //     0xad830c: ldr             lr, [x21, lr, lsl #3]
    //     0xad8310: blr             lr
    // 0xad8314: add             SP, SP, #8
    // 0xad8318: ldr             x16, [fp, #0x10]
    // 0xad831c: stp             x0, x16, [SP, #-0x10]!
    // 0xad8320: r0 = _statusChangeHandler()
    //     0xad8320: bl              #0xad8404  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler
    // 0xad8324: add             SP, SP, #0x10
    // 0xad8328: ldur            x1, [fp, #-0x10]
    // 0xad832c: b               #0xad8334
    // 0xad8330: r1 = false
    //     0xad8330: add             x1, NULL, #0x30  ; false
    // 0xad8334: ldr             x0, [fp, #0x10]
    // 0xad8338: stur            x1, [fp, #-8]
    // 0xad833c: SaveReg r0
    //     0xad833c: str             x0, [SP, #-8]!
    // 0xad8340: r0 = value()
    //     0xad8340: bl              #0xc24bc4  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::value
    // 0xad8344: add             SP, SP, #8
    // 0xad8348: mov             x1, x0
    // 0xad834c: ldr             x0, [fp, #0x10]
    // 0xad8350: stur            x1, [fp, #-0x10]
    // 0xad8354: LoadField: r2 = r0->field_27
    //     0xad8354: ldur            w2, [x0, #0x27]
    // 0xad8358: DecompressPointer r2
    //     0xad8358: add             x2, x2, HEAP, lsl #32
    // 0xad835c: stp             x2, x1, [SP, #-0x10]!
    // 0xad8360: r0 = ==()
    //     0xad8360: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0xad8364: add             SP, SP, #0x10
    // 0xad8368: tbz             w0, #4, #0xad83a4
    // 0xad836c: ldr             x0, [fp, #0x10]
    // 0xad8370: SaveReg r0
    //     0xad8370: str             x0, [SP, #-8]!
    // 0xad8374: r0 = notifyListeners()
    //     0xad8374: bl              #0x593248  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0xad8378: add             SP, SP, #8
    // 0xad837c: ldur            x0, [fp, #-0x10]
    // 0xad8380: ldr             x1, [fp, #0x10]
    // 0xad8384: StoreField: r1->field_27 = r0
    //     0xad8384: stur            w0, [x1, #0x27]
    //     0xad8388: ldurb           w16, [x1, #-1]
    //     0xad838c: ldurb           w17, [x0, #-1]
    //     0xad8390: and             x16, x17, x16, lsr #2
    //     0xad8394: tst             x16, HEAP, lsr #32
    //     0xad8398: b.eq            #0xad83a0
    //     0xad839c: bl              #0xd6826c
    // 0xad83a0: b               #0xad83a8
    // 0xad83a4: ldr             x1, [fp, #0x10]
    // 0xad83a8: ldur            x0, [fp, #-8]
    // 0xad83ac: tbnz            w0, #4, #0xad83d4
    // 0xad83b0: LoadField: r0 = r1->field_1f
    //     0xad83b0: ldur            w0, [x1, #0x1f]
    // 0xad83b4: DecompressPointer r0
    //     0xad83b4: add             x0, x0, HEAP, lsl #32
    // 0xad83b8: cmp             w0, NULL
    // 0xad83bc: b.eq            #0xad83d4
    // 0xad83c0: SaveReg r0
    //     0xad83c0: str             x0, [SP, #-8]!
    // 0xad83c4: ClosureCall
    //     0xad83c4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xad83c8: ldur            x2, [x0, #0x1f]
    //     0xad83cc: blr             x2
    // 0xad83d0: add             SP, SP, #8
    // 0xad83d4: r0 = Null
    //     0xad83d4: mov             x0, NULL
    // 0xad83d8: LeaveFrame
    //     0xad83d8: mov             SP, fp
    //     0xad83dc: ldp             fp, lr, [SP], #0x10
    // 0xad83e0: ret
    //     0xad83e0: ret             
    // 0xad83e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad83e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad83e8: b               #0xad8068
    // 0xad83ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad83ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad83f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad83f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad83f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad83f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad83f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad83f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad83fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad83fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad8400: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad8400: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _statusChangeHandler(/* No info */) {
    // ** addr: 0xad8404, size: 0x74
    // 0xad8404: EnterFrame
    //     0xad8404: stp             fp, lr, [SP, #-0x10]!
    //     0xad8408: mov             fp, SP
    // 0xad840c: CheckStackOverflow
    //     0xad840c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8410: cmp             SP, x16
    //     0xad8414: b.ls            #0xad8470
    // 0xad8418: ldr             x0, [fp, #0x18]
    // 0xad841c: LoadField: r1 = r0->field_23
    //     0xad841c: ldur            w1, [x0, #0x23]
    // 0xad8420: DecompressPointer r1
    //     0xad8420: add             x1, x1, HEAP, lsl #32
    // 0xad8424: ldr             x2, [fp, #0x10]
    // 0xad8428: cmp             w2, w1
    // 0xad842c: b.eq            #0xad8460
    // 0xad8430: SaveReg r0
    //     0xad8430: str             x0, [SP, #-8]!
    // 0xad8434: r0 = notifyListeners()
    //     0xad8434: bl              #0x593248  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::notifyListeners
    // 0xad8438: add             SP, SP, #8
    // 0xad843c: ldr             x0, [fp, #0x10]
    // 0xad8440: ldr             x1, [fp, #0x18]
    // 0xad8444: StoreField: r1->field_23 = r0
    //     0xad8444: stur            w0, [x1, #0x23]
    //     0xad8448: ldurb           w16, [x1, #-1]
    //     0xad844c: ldurb           w17, [x0, #-1]
    //     0xad8450: and             x16, x17, x16, lsr #2
    //     0xad8454: tst             x16, HEAP, lsr #32
    //     0xad8458: b.eq            #0xad8460
    //     0xad845c: bl              #0xd6826c
    // 0xad8460: r0 = Null
    //     0xad8460: mov             x0, NULL
    // 0xad8464: LeaveFrame
    //     0xad8464: mov             SP, fp
    //     0xad8468: ldp             fp, lr, [SP], #0x10
    // 0xad846c: ret
    //     0xad846c: ret             
    // 0xad8470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad8470: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad8474: b               #0xad8418
  }
  [closure] void _statusChangeHandler(dynamic, AnimationStatus) {
    // ** addr: 0xad8478, size: 0x4c
    // 0xad8478: EnterFrame
    //     0xad8478: stp             fp, lr, [SP, #-0x10]!
    //     0xad847c: mov             fp, SP
    // 0xad8480: ldr             x0, [fp, #0x18]
    // 0xad8484: LoadField: r1 = r0->field_17
    //     0xad8484: ldur            w1, [x0, #0x17]
    // 0xad8488: DecompressPointer r1
    //     0xad8488: add             x1, x1, HEAP, lsl #32
    // 0xad848c: CheckStackOverflow
    //     0xad848c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad8490: cmp             SP, x16
    //     0xad8494: b.ls            #0xad84bc
    // 0xad8498: LoadField: r0 = r1->field_f
    //     0xad8498: ldur            w0, [x1, #0xf]
    // 0xad849c: DecompressPointer r0
    //     0xad849c: add             x0, x0, HEAP, lsl #32
    // 0xad84a0: ldr             x16, [fp, #0x10]
    // 0xad84a4: stp             x16, x0, [SP, #-0x10]!
    // 0xad84a8: r0 = _statusChangeHandler()
    //     0xad84a8: bl              #0xad8404  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler
    // 0xad84ac: add             SP, SP, #0x10
    // 0xad84b0: LeaveFrame
    //     0xad84b0: mov             SP, fp
    //     0xad84b4: ldp             fp, lr, [SP], #0x10
    // 0xad84b8: ret
    //     0xad84b8: ret             
    // 0xad84bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad84bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad84c0: b               #0xad8498
  }
  get _ value(/* No info */) {
    // ** addr: 0xc24bc4, size: 0x5c
    // 0xc24bc4: EnterFrame
    //     0xc24bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xc24bc8: mov             fp, SP
    // 0xc24bcc: CheckStackOverflow
    //     0xc24bcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc24bd0: cmp             SP, x16
    //     0xc24bd4: b.ls            #0xc24c14
    // 0xc24bd8: ldr             x0, [fp, #0x10]
    // 0xc24bdc: LoadField: r1 = r0->field_13
    //     0xc24bdc: ldur            w1, [x0, #0x13]
    // 0xc24be0: DecompressPointer r1
    //     0xc24be0: add             x1, x1, HEAP, lsl #32
    // 0xc24be4: cmp             w1, NULL
    // 0xc24be8: b.eq            #0xc24c1c
    // 0xc24bec: r0 = LoadClassIdInstr(r1)
    //     0xc24bec: ldur            x0, [x1, #-1]
    //     0xc24bf0: ubfx            x0, x0, #0xc, #0x14
    // 0xc24bf4: SaveReg r1
    //     0xc24bf4: str             x1, [SP, #-8]!
    // 0xc24bf8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc24bf8: add             lr, x0, #0xb7c
    //     0xc24bfc: ldr             lr, [x21, lr, lsl #3]
    //     0xc24c00: blr             lr
    // 0xc24c04: add             SP, SP, #8
    // 0xc24c08: LeaveFrame
    //     0xc24c08: mov             SP, fp
    //     0xc24c0c: ldp             fp, lr, [SP], #0x10
    // 0xc24c10: ret
    //     0xc24c10: ret             
    // 0xc24c14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc24c14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc24c18: b               #0xc24bd8
    // 0xc24c1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc24c1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ status(/* No info */) {
    // ** addr: 0xc64494, size: 0x5c
    // 0xc64494: EnterFrame
    //     0xc64494: stp             fp, lr, [SP, #-0x10]!
    //     0xc64498: mov             fp, SP
    // 0xc6449c: CheckStackOverflow
    //     0xc6449c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc644a0: cmp             SP, x16
    //     0xc644a4: b.ls            #0xc644e4
    // 0xc644a8: ldr             x0, [fp, #0x10]
    // 0xc644ac: LoadField: r1 = r0->field_13
    //     0xc644ac: ldur            w1, [x0, #0x13]
    // 0xc644b0: DecompressPointer r1
    //     0xc644b0: add             x1, x1, HEAP, lsl #32
    // 0xc644b4: cmp             w1, NULL
    // 0xc644b8: b.eq            #0xc644ec
    // 0xc644bc: r0 = LoadClassIdInstr(r1)
    //     0xc644bc: ldur            x0, [x1, #-1]
    //     0xc644c0: ubfx            x0, x0, #0xc, #0x14
    // 0xc644c4: SaveReg r1
    //     0xc644c4: str             x1, [SP, #-8]!
    // 0xc644c8: r0 = GDT[cid_x0 + 0x376]()
    //     0xc644c8: add             lr, x0, #0x376
    //     0xc644cc: ldr             lr, [x21, lr, lsl #3]
    //     0xc644d0: blr             lr
    // 0xc644d4: add             SP, SP, #8
    // 0xc644d8: LeaveFrame
    //     0xc644d8: mov             SP, fp
    //     0xc644dc: ldp             fp, lr, [SP], #0x10
    // 0xc644e0: ret
    //     0xc644e0: ret             
    // 0xc644e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc644e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc644e8: b               #0xc644a8
    // 0xc644ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc644ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic _statusChangeHandler(dynamic) {
    // ** addr: 0xcb98c0, size: 0x18
    // 0xcb98c0: r4 = 7
    //     0xcb98c0: mov             x4, #7
    // 0xcb98c4: r1 = Function '_statusChangeHandler@576411118':.
    //     0xcb98c4: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1cdf0] AnonymousClosure: (0xad8478), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_statusChangeHandler (0xad8404)
    //     0xcb98c8: ldr             x1, [x17, #0xdf0]
    // 0xcb98cc: r24 = BuildNonGenericMethodExtractorStub
    //     0xcb98cc: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcb98d0: LoadField: r0 = r24->field_17
    //     0xcb98d0: ldur            x0, [x24, #0x17]
    // 0xcb98d4: br              x0
  }
  dynamic _valueChangeHandler(dynamic) {
    // ** addr: 0xcb98d8, size: 0x18
    // 0xcb98d8: r4 = 7
    //     0xcb98d8: mov             x4, #7
    // 0xcb98dc: r1 = Function '_valueChangeHandler@576411118':.
    //     0xcb98dc: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1cdf8] AnonymousClosure: (0xad8008), in [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::_valueChangeHandler (0xad8050)
    //     0xcb98e0: ldr             x1, [x17, #0xdf8]
    // 0xcb98e4: r24 = BuildNonGenericMethodExtractorStub
    //     0xcb98e4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcb98e8: LoadField: r0 = r24->field_17
    //     0xcb98e8: ldur            x0, [x24, #0x17]
    // 0xcb98ec: br              x0
  }
}

// class id: 4353, size: 0x1c, field offset: 0xc
class CurvedAnimation extends __ChangeAnimation&Animation&AnimationWithParentMixin {

  _ CurvedAnimation(/* No info */) {
    // ** addr: 0x5a12a0, size: 0x174
    // 0x5a12a0: EnterFrame
    //     0x5a12a0: stp             fp, lr, [SP, #-0x10]!
    //     0x5a12a4: mov             fp, SP
    // 0x5a12a8: AllocStack(0x10)
    //     0x5a12a8: sub             SP, SP, #0x10
    // 0x5a12ac: SetupParameters(CurvedAnimation<double> this /* r3, fp-0x10 */, dynamic _ /* r4 */, dynamic _ /* r5, fp-0x8 */, {dynamic reverseCurve = Null /* r1 */})
    //     0x5a12ac: mov             x0, x4
    //     0x5a12b0: ldur            w1, [x0, #0x13]
    //     0x5a12b4: add             x1, x1, HEAP, lsl #32
    //     0x5a12b8: sub             x2, x1, #6
    //     0x5a12bc: add             x3, fp, w2, sxtw #2
    //     0x5a12c0: ldr             x3, [x3, #0x20]
    //     0x5a12c4: stur            x3, [fp, #-0x10]
    //     0x5a12c8: add             x4, fp, w2, sxtw #2
    //     0x5a12cc: ldr             x4, [x4, #0x18]
    //     0x5a12d0: add             x5, fp, w2, sxtw #2
    //     0x5a12d4: ldr             x5, [x5, #0x10]
    //     0x5a12d8: stur            x5, [fp, #-8]
    //     0x5a12dc: ldur            w2, [x0, #0x1f]
    //     0x5a12e0: add             x2, x2, HEAP, lsl #32
    //     0x5a12e4: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cb48] "reverseCurve"
    //     0x5a12e8: ldr             x16, [x16, #0xb48]
    //     0x5a12ec: cmp             w2, w16
    //     0x5a12f0: b.ne            #0x5a130c
    //     0x5a12f4: ldur            w2, [x0, #0x23]
    //     0x5a12f8: add             x2, x2, HEAP, lsl #32
    //     0x5a12fc: sub             w0, w1, w2
    //     0x5a1300: add             x1, fp, w0, sxtw #2
    //     0x5a1304: ldr             x1, [x1, #8]
    //     0x5a1308: b               #0x5a1310
    //     0x5a130c: mov             x1, NULL
    // 0x5a1310: CheckStackOverflow
    //     0x5a1310: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a1314: cmp             SP, x16
    //     0x5a1318: b.ls            #0x5a140c
    // 0x5a131c: mov             x0, x5
    // 0x5a1320: StoreField: r3->field_b = r0
    //     0x5a1320: stur            w0, [x3, #0xb]
    //     0x5a1324: ldurb           w16, [x3, #-1]
    //     0x5a1328: ldurb           w17, [x0, #-1]
    //     0x5a132c: and             x16, x17, x16, lsr #2
    //     0x5a1330: tst             x16, HEAP, lsr #32
    //     0x5a1334: b.eq            #0x5a133c
    //     0x5a1338: bl              #0xd682ac
    // 0x5a133c: mov             x0, x4
    // 0x5a1340: StoreField: r3->field_f = r0
    //     0x5a1340: stur            w0, [x3, #0xf]
    //     0x5a1344: ldurb           w16, [x3, #-1]
    //     0x5a1348: ldurb           w17, [x0, #-1]
    //     0x5a134c: and             x16, x17, x16, lsr #2
    //     0x5a1350: tst             x16, HEAP, lsr #32
    //     0x5a1354: b.eq            #0x5a135c
    //     0x5a1358: bl              #0xd682ac
    // 0x5a135c: mov             x0, x1
    // 0x5a1360: StoreField: r3->field_13 = r0
    //     0x5a1360: stur            w0, [x3, #0x13]
    //     0x5a1364: ldurb           w16, [x3, #-1]
    //     0x5a1368: ldurb           w17, [x0, #-1]
    //     0x5a136c: and             x16, x17, x16, lsr #2
    //     0x5a1370: tst             x16, HEAP, lsr #32
    //     0x5a1374: b.eq            #0x5a137c
    //     0x5a1378: bl              #0xd682ac
    // 0x5a137c: r0 = LoadClassIdInstr(r5)
    //     0x5a137c: ldur            x0, [x5, #-1]
    //     0x5a1380: ubfx            x0, x0, #0xc, #0x14
    // 0x5a1384: SaveReg r5
    //     0x5a1384: str             x5, [SP, #-8]!
    // 0x5a1388: r0 = GDT[cid_x0 + 0x376]()
    //     0x5a1388: add             lr, x0, #0x376
    //     0x5a138c: ldr             lr, [x21, lr, lsl #3]
    //     0x5a1390: blr             lr
    // 0x5a1394: add             SP, SP, #8
    // 0x5a1398: ldur            x16, [fp, #-0x10]
    // 0x5a139c: stp             x0, x16, [SP, #-0x10]!
    // 0x5a13a0: r0 = _updateCurveDirection()
    //     0x5a13a0: bl              #0x5a1414  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection
    // 0x5a13a4: add             SP, SP, #0x10
    // 0x5a13a8: ldur            x0, [fp, #-0x10]
    // 0x5a13ac: r1 = 59
    //     0x5a13ac: mov             x1, #0x3b
    // 0x5a13b0: branchIfSmi(r0, 0x5a13bc)
    //     0x5a13b0: tbz             w0, #0, #0x5a13bc
    // 0x5a13b4: r1 = LoadClassIdInstr(r0)
    //     0x5a13b4: ldur            x1, [x0, #-1]
    //     0x5a13b8: ubfx            x1, x1, #0xc, #0x14
    // 0x5a13bc: SaveReg r0
    //     0x5a13bc: str             x0, [SP, #-8]!
    // 0x5a13c0: mov             x0, x1
    // 0x5a13c4: r0 = GDT[cid_x0 + -0xfe9]()
    //     0x5a13c4: sub             lr, x0, #0xfe9
    //     0x5a13c8: ldr             lr, [x21, lr, lsl #3]
    //     0x5a13cc: blr             lr
    // 0x5a13d0: add             SP, SP, #8
    // 0x5a13d4: mov             x1, x0
    // 0x5a13d8: ldur            x0, [fp, #-8]
    // 0x5a13dc: r2 = LoadClassIdInstr(r0)
    //     0x5a13dc: ldur            x2, [x0, #-1]
    //     0x5a13e0: ubfx            x2, x2, #0xc, #0x14
    // 0x5a13e4: stp             x1, x0, [SP, #-0x10]!
    // 0x5a13e8: mov             x0, x2
    // 0x5a13ec: r0 = GDT[cid_x0 + 0x80c]()
    //     0x5a13ec: add             lr, x0, #0x80c
    //     0x5a13f0: ldr             lr, [x21, lr, lsl #3]
    //     0x5a13f4: blr             lr
    // 0x5a13f8: add             SP, SP, #0x10
    // 0x5a13fc: r0 = Null
    //     0x5a13fc: mov             x0, NULL
    // 0x5a1400: LeaveFrame
    //     0x5a1400: mov             SP, fp
    //     0x5a1404: ldp             fp, lr, [SP], #0x10
    // 0x5a1408: ret
    //     0x5a1408: ret             
    // 0x5a140c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a140c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a1410: b               #0x5a131c
  }
  _ _updateCurveDirection(/* No info */) {
    // ** addr: 0x5a1414, size: 0x7c
    // 0x5a1414: ldr             x1, [SP]
    // 0x5a1418: LoadField: r2 = r1->field_7
    //     0x5a1418: ldur            x2, [x1, #7]
    // 0x5a141c: cmp             x2, #1
    // 0x5a1420: b.gt            #0x5a1458
    // 0x5a1424: cmp             x2, #0
    // 0x5a1428: b.gt            #0x5a1434
    // 0x5a142c: ldr             x1, [SP, #8]
    // 0x5a1430: b               #0x5a1484
    // 0x5a1434: ldr             x1, [SP, #8]
    // 0x5a1438: LoadField: r3 = r1->field_17
    //     0x5a1438: ldur            w3, [x1, #0x17]
    // 0x5a143c: DecompressPointer r3
    //     0x5a143c: add             x3, x3, HEAP, lsl #32
    // 0x5a1440: cmp             w3, NULL
    // 0x5a1444: b.ne            #0x5a1488
    // 0x5a1448: r3 = Instance_AnimationStatus
    //     0x5a1448: add             x3, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0x5a144c: ldr             x3, [x3, #0xbb8]
    // 0x5a1450: StoreField: r1->field_17 = r3
    //     0x5a1450: stur            w3, [x1, #0x17]
    // 0x5a1454: b               #0x5a1488
    // 0x5a1458: ldr             x1, [SP, #8]
    // 0x5a145c: cmp             x2, #2
    // 0x5a1460: b.gt            #0x5a1484
    // 0x5a1464: LoadField: r2 = r1->field_17
    //     0x5a1464: ldur            w2, [x1, #0x17]
    // 0x5a1468: DecompressPointer r2
    //     0x5a1468: add             x2, x2, HEAP, lsl #32
    // 0x5a146c: cmp             w2, NULL
    // 0x5a1470: b.ne            #0x5a1488
    // 0x5a1474: r2 = Instance_AnimationStatus
    //     0x5a1474: add             x2, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0x5a1478: ldr             x2, [x2, #0xbc0]
    // 0x5a147c: StoreField: r1->field_17 = r2
    //     0x5a147c: stur            w2, [x1, #0x17]
    // 0x5a1480: b               #0x5a1488
    // 0x5a1484: StoreField: r1->field_17 = rNULL
    //     0x5a1484: stur            NULL, [x1, #0x17]
    // 0x5a1488: r0 = Null
    //     0x5a1488: mov             x0, NULL
    // 0x5a148c: ret
    //     0x5a148c: ret             
  }
  [closure] void _updateCurveDirection(dynamic, AnimationStatus) {
    // ** addr: 0x5a1490, size: 0x4c
    // 0x5a1490: EnterFrame
    //     0x5a1490: stp             fp, lr, [SP, #-0x10]!
    //     0x5a1494: mov             fp, SP
    // 0x5a1498: ldr             x0, [fp, #0x18]
    // 0x5a149c: LoadField: r1 = r0->field_17
    //     0x5a149c: ldur            w1, [x0, #0x17]
    // 0x5a14a0: DecompressPointer r1
    //     0x5a14a0: add             x1, x1, HEAP, lsl #32
    // 0x5a14a4: CheckStackOverflow
    //     0x5a14a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a14a8: cmp             SP, x16
    //     0x5a14ac: b.ls            #0x5a14d4
    // 0x5a14b0: LoadField: r0 = r1->field_f
    //     0x5a14b0: ldur            w0, [x1, #0xf]
    // 0x5a14b4: DecompressPointer r0
    //     0x5a14b4: add             x0, x0, HEAP, lsl #32
    // 0x5a14b8: ldr             x16, [fp, #0x10]
    // 0x5a14bc: stp             x16, x0, [SP, #-0x10]!
    // 0x5a14c0: r0 = _updateCurveDirection()
    //     0x5a14c0: bl              #0x5a1414  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection
    // 0x5a14c4: add             SP, SP, #0x10
    // 0x5a14c8: LeaveFrame
    //     0x5a14c8: mov             SP, fp
    //     0x5a14cc: ldp             fp, lr, [SP], #0x10
    // 0x5a14d0: ret
    //     0x5a14d0: ret             
    // 0x5a14d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a14d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a14d8: b               #0x5a14b0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x7b6be4, size: 0x8c
    // 0x7b6be4: EnterFrame
    //     0x7b6be4: stp             fp, lr, [SP, #-0x10]!
    //     0x7b6be8: mov             fp, SP
    // 0x7b6bec: AllocStack(0x8)
    //     0x7b6bec: sub             SP, SP, #8
    // 0x7b6bf0: CheckStackOverflow
    //     0x7b6bf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b6bf4: cmp             SP, x16
    //     0x7b6bf8: b.ls            #0x7b6c68
    // 0x7b6bfc: ldr             x0, [fp, #0x10]
    // 0x7b6c00: LoadField: r1 = r0->field_b
    //     0x7b6c00: ldur            w1, [x0, #0xb]
    // 0x7b6c04: DecompressPointer r1
    //     0x7b6c04: add             x1, x1, HEAP, lsl #32
    // 0x7b6c08: stur            x1, [fp, #-8]
    // 0x7b6c0c: r1 = 1
    //     0x7b6c0c: mov             x1, #1
    // 0x7b6c10: r0 = AllocateContext()
    //     0x7b6c10: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b6c14: mov             x1, x0
    // 0x7b6c18: ldr             x0, [fp, #0x10]
    // 0x7b6c1c: StoreField: r1->field_f = r0
    //     0x7b6c1c: stur            w0, [x1, #0xf]
    // 0x7b6c20: mov             x2, x1
    // 0x7b6c24: r1 = Function '_updateCurveDirection@576411118':.
    //     0x7b6c24: add             x1, PP, #0x21, lsl #12  ; [pp+0x21858] AnonymousClosure: (0x5a1490), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x5a1414)
    //     0x7b6c28: ldr             x1, [x1, #0x858]
    // 0x7b6c2c: r0 = AllocateClosure()
    //     0x7b6c2c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b6c30: mov             x1, x0
    // 0x7b6c34: ldur            x0, [fp, #-8]
    // 0x7b6c38: r2 = LoadClassIdInstr(r0)
    //     0x7b6c38: ldur            x2, [x0, #-1]
    //     0x7b6c3c: ubfx            x2, x2, #0xc, #0x14
    // 0x7b6c40: stp             x1, x0, [SP, #-0x10]!
    // 0x7b6c44: mov             x0, x2
    // 0x7b6c48: r0 = GDT[cid_x0 + 0x490]()
    //     0x7b6c48: add             lr, x0, #0x490
    //     0x7b6c4c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b6c50: blr             lr
    // 0x7b6c54: add             SP, SP, #0x10
    // 0x7b6c58: r0 = Null
    //     0x7b6c58: mov             x0, NULL
    // 0x7b6c5c: LeaveFrame
    //     0x7b6c5c: mov             SP, fp
    //     0x7b6c60: ldp             fp, lr, [SP], #0x10
    // 0x7b6c64: ret
    //     0x7b6c64: ret             
    // 0x7b6c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b6c68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b6c6c: b               #0x7b6bfc
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4578, size: 0x18c
    // 0xad4578: EnterFrame
    //     0xad4578: stp             fp, lr, [SP, #-0x10]!
    //     0xad457c: mov             fp, SP
    // 0xad4580: AllocStack(0x8)
    //     0xad4580: sub             SP, SP, #8
    // 0xad4584: CheckStackOverflow
    //     0xad4584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4588: cmp             SP, x16
    //     0xad458c: b.ls            #0xad46fc
    // 0xad4590: ldr             x0, [fp, #0x10]
    // 0xad4594: LoadField: r1 = r0->field_13
    //     0xad4594: ldur            w1, [x0, #0x13]
    // 0xad4598: DecompressPointer r1
    //     0xad4598: add             x1, x1, HEAP, lsl #32
    // 0xad459c: cmp             w1, NULL
    // 0xad45a0: b.ne            #0xad45fc
    // 0xad45a4: LoadField: r3 = r0->field_b
    //     0xad45a4: ldur            w3, [x0, #0xb]
    // 0xad45a8: DecompressPointer r3
    //     0xad45a8: add             x3, x3, HEAP, lsl #32
    // 0xad45ac: stur            x3, [fp, #-8]
    // 0xad45b0: r1 = Null
    //     0xad45b0: mov             x1, NULL
    // 0xad45b4: r2 = 6
    //     0xad45b4: mov             x2, #6
    // 0xad45b8: r0 = AllocateArray()
    //     0xad45b8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad45bc: mov             x1, x0
    // 0xad45c0: ldur            x0, [fp, #-8]
    // 0xad45c4: StoreField: r1->field_f = r0
    //     0xad45c4: stur            w0, [x1, #0xf]
    // 0xad45c8: r17 = "➩"
    //     0xad45c8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad45cc: ldr             x17, [x17, #0x1a0]
    // 0xad45d0: StoreField: r1->field_13 = r17
    //     0xad45d0: stur            w17, [x1, #0x13]
    // 0xad45d4: ldr             x0, [fp, #0x10]
    // 0xad45d8: LoadField: r2 = r0->field_f
    //     0xad45d8: ldur            w2, [x0, #0xf]
    // 0xad45dc: DecompressPointer r2
    //     0xad45dc: add             x2, x2, HEAP, lsl #32
    // 0xad45e0: StoreField: r1->field_17 = r2
    //     0xad45e0: stur            w2, [x1, #0x17]
    // 0xad45e4: SaveReg r1
    //     0xad45e4: str             x1, [SP, #-8]!
    // 0xad45e8: r0 = _interpolate()
    //     0xad45e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad45ec: add             SP, SP, #8
    // 0xad45f0: LeaveFrame
    //     0xad45f0: mov             SP, fp
    //     0xad45f4: ldp             fp, lr, [SP], #0x10
    // 0xad45f8: ret
    //     0xad45f8: ret             
    // 0xad45fc: SaveReg r0
    //     0xad45fc: str             x0, [SP, #-8]!
    // 0xad4600: r0 = _useForwardCurve()
    //     0xad4600: bl              #0xad4704  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::_useForwardCurve
    // 0xad4604: add             SP, SP, #8
    // 0xad4608: tbnz            w0, #4, #0xad4680
    // 0xad460c: ldr             x0, [fp, #0x10]
    // 0xad4610: LoadField: r3 = r0->field_b
    //     0xad4610: ldur            w3, [x0, #0xb]
    // 0xad4614: DecompressPointer r3
    //     0xad4614: add             x3, x3, HEAP, lsl #32
    // 0xad4618: stur            x3, [fp, #-8]
    // 0xad461c: r1 = Null
    //     0xad461c: mov             x1, NULL
    // 0xad4620: r2 = 10
    //     0xad4620: mov             x2, #0xa
    // 0xad4624: r0 = AllocateArray()
    //     0xad4624: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4628: mov             x1, x0
    // 0xad462c: ldur            x0, [fp, #-8]
    // 0xad4630: StoreField: r1->field_f = r0
    //     0xad4630: stur            w0, [x1, #0xf]
    // 0xad4634: r17 = "➩"
    //     0xad4634: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad4638: ldr             x17, [x17, #0x1a0]
    // 0xad463c: StoreField: r1->field_13 = r17
    //     0xad463c: stur            w17, [x1, #0x13]
    // 0xad4640: ldr             x0, [fp, #0x10]
    // 0xad4644: LoadField: r2 = r0->field_f
    //     0xad4644: ldur            w2, [x0, #0xf]
    // 0xad4648: DecompressPointer r2
    //     0xad4648: add             x2, x2, HEAP, lsl #32
    // 0xad464c: StoreField: r1->field_17 = r2
    //     0xad464c: stur            w2, [x1, #0x17]
    // 0xad4650: r17 = "ₒₙ/"
    //     0xad4650: add             x17, PP, #0x22, lsl #12  ; [pp+0x221b0] "ₒₙ/"
    //     0xad4654: ldr             x17, [x17, #0x1b0]
    // 0xad4658: StoreField: r1->field_1b = r17
    //     0xad4658: stur            w17, [x1, #0x1b]
    // 0xad465c: LoadField: r2 = r0->field_13
    //     0xad465c: ldur            w2, [x0, #0x13]
    // 0xad4660: DecompressPointer r2
    //     0xad4660: add             x2, x2, HEAP, lsl #32
    // 0xad4664: StoreField: r1->field_1f = r2
    //     0xad4664: stur            w2, [x1, #0x1f]
    // 0xad4668: SaveReg r1
    //     0xad4668: str             x1, [SP, #-8]!
    // 0xad466c: r0 = _interpolate()
    //     0xad466c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4670: add             SP, SP, #8
    // 0xad4674: LeaveFrame
    //     0xad4674: mov             SP, fp
    //     0xad4678: ldp             fp, lr, [SP], #0x10
    // 0xad467c: ret
    //     0xad467c: ret             
    // 0xad4680: ldr             x0, [fp, #0x10]
    // 0xad4684: LoadField: r3 = r0->field_b
    //     0xad4684: ldur            w3, [x0, #0xb]
    // 0xad4688: DecompressPointer r3
    //     0xad4688: add             x3, x3, HEAP, lsl #32
    // 0xad468c: stur            x3, [fp, #-8]
    // 0xad4690: r1 = Null
    //     0xad4690: mov             x1, NULL
    // 0xad4694: r2 = 12
    //     0xad4694: mov             x2, #0xc
    // 0xad4698: r0 = AllocateArray()
    //     0xad4698: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad469c: mov             x1, x0
    // 0xad46a0: ldur            x0, [fp, #-8]
    // 0xad46a4: StoreField: r1->field_f = r0
    //     0xad46a4: stur            w0, [x1, #0xf]
    // 0xad46a8: r17 = "➩"
    //     0xad46a8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad46ac: ldr             x17, [x17, #0x1a0]
    // 0xad46b0: StoreField: r1->field_13 = r17
    //     0xad46b0: stur            w17, [x1, #0x13]
    // 0xad46b4: ldr             x0, [fp, #0x10]
    // 0xad46b8: LoadField: r2 = r0->field_f
    //     0xad46b8: ldur            w2, [x0, #0xf]
    // 0xad46bc: DecompressPointer r2
    //     0xad46bc: add             x2, x2, HEAP, lsl #32
    // 0xad46c0: StoreField: r1->field_17 = r2
    //     0xad46c0: stur            w2, [x1, #0x17]
    // 0xad46c4: r17 = "/"
    //     0xad46c4: ldr             x17, [PP, #0x768]  ; [pp+0x768] "/"
    // 0xad46c8: StoreField: r1->field_1b = r17
    //     0xad46c8: stur            w17, [x1, #0x1b]
    // 0xad46cc: LoadField: r2 = r0->field_13
    //     0xad46cc: ldur            w2, [x0, #0x13]
    // 0xad46d0: DecompressPointer r2
    //     0xad46d0: add             x2, x2, HEAP, lsl #32
    // 0xad46d4: StoreField: r1->field_1f = r2
    //     0xad46d4: stur            w2, [x1, #0x1f]
    // 0xad46d8: r17 = "ₒₙ"
    //     0xad46d8: add             x17, PP, #0x22, lsl #12  ; [pp+0x221b8] "ₒₙ"
    //     0xad46dc: ldr             x17, [x17, #0x1b8]
    // 0xad46e0: StoreField: r1->field_23 = r17
    //     0xad46e0: stur            w17, [x1, #0x23]
    // 0xad46e4: SaveReg r1
    //     0xad46e4: str             x1, [SP, #-8]!
    // 0xad46e8: r0 = _interpolate()
    //     0xad46e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad46ec: add             SP, SP, #8
    // 0xad46f0: LeaveFrame
    //     0xad46f0: mov             SP, fp
    //     0xad46f4: ldp             fp, lr, [SP], #0x10
    // 0xad46f8: ret
    //     0xad46f8: ret             
    // 0xad46fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad46fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4700: b               #0xad4590
  }
  get _ _useForwardCurve(/* No info */) {
    // ** addr: 0xad4704, size: 0x98
    // 0xad4704: EnterFrame
    //     0xad4704: stp             fp, lr, [SP, #-0x10]!
    //     0xad4708: mov             fp, SP
    // 0xad470c: CheckStackOverflow
    //     0xad470c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4710: cmp             SP, x16
    //     0xad4714: b.ls            #0xad4794
    // 0xad4718: ldr             x0, [fp, #0x10]
    // 0xad471c: LoadField: r1 = r0->field_13
    //     0xad471c: ldur            w1, [x0, #0x13]
    // 0xad4720: DecompressPointer r1
    //     0xad4720: add             x1, x1, HEAP, lsl #32
    // 0xad4724: cmp             w1, NULL
    // 0xad4728: b.ne            #0xad4734
    // 0xad472c: r0 = true
    //     0xad472c: add             x0, NULL, #0x20  ; true
    // 0xad4730: b               #0xad4788
    // 0xad4734: LoadField: r1 = r0->field_17
    //     0xad4734: ldur            w1, [x0, #0x17]
    // 0xad4738: DecompressPointer r1
    //     0xad4738: add             x1, x1, HEAP, lsl #32
    // 0xad473c: cmp             w1, NULL
    // 0xad4740: b.ne            #0xad476c
    // 0xad4744: LoadField: r1 = r0->field_b
    //     0xad4744: ldur            w1, [x0, #0xb]
    // 0xad4748: DecompressPointer r1
    //     0xad4748: add             x1, x1, HEAP, lsl #32
    // 0xad474c: r0 = LoadClassIdInstr(r1)
    //     0xad474c: ldur            x0, [x1, #-1]
    //     0xad4750: ubfx            x0, x0, #0xc, #0x14
    // 0xad4754: SaveReg r1
    //     0xad4754: str             x1, [SP, #-8]!
    // 0xad4758: r0 = GDT[cid_x0 + 0x376]()
    //     0xad4758: add             lr, x0, #0x376
    //     0xad475c: ldr             lr, [x21, lr, lsl #3]
    //     0xad4760: blr             lr
    // 0xad4764: add             SP, SP, #8
    // 0xad4768: mov             x1, x0
    // 0xad476c: r16 = Instance_AnimationStatus
    //     0xad476c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0xad4770: ldr             x16, [x16, #0xbc0]
    // 0xad4774: cmp             w1, w16
    // 0xad4778: r16 = true
    //     0xad4778: add             x16, NULL, #0x20  ; true
    // 0xad477c: r17 = false
    //     0xad477c: add             x17, NULL, #0x30  ; false
    // 0xad4780: csel            x2, x16, x17, ne
    // 0xad4784: mov             x0, x2
    // 0xad4788: LeaveFrame
    //     0xad4788: mov             SP, fp
    //     0xad478c: ldp             fp, lr, [SP], #0x10
    // 0xad4790: ret
    //     0xad4790: ret             
    // 0xad4794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4794: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4798: b               #0xad4718
  }
  get _ value(/* No info */) {
    // ** addr: 0xc24674, size: 0xe8
    // 0xc24674: EnterFrame
    //     0xc24674: stp             fp, lr, [SP, #-0x10]!
    //     0xc24678: mov             fp, SP
    // 0xc2467c: AllocStack(0x8)
    //     0xc2467c: sub             SP, SP, #8
    // 0xc24680: CheckStackOverflow
    //     0xc24680: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc24684: cmp             SP, x16
    //     0xc24688: b.ls            #0xc24754
    // 0xc2468c: ldr             x16, [fp, #0x10]
    // 0xc24690: SaveReg r16
    //     0xc24690: str             x16, [SP, #-8]!
    // 0xc24694: r0 = _useForwardCurve()
    //     0xc24694: bl              #0xad4704  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::_useForwardCurve
    // 0xc24698: add             SP, SP, #8
    // 0xc2469c: tbnz            w0, #4, #0xc246b0
    // 0xc246a0: ldr             x0, [fp, #0x10]
    // 0xc246a4: LoadField: r1 = r0->field_f
    //     0xc246a4: ldur            w1, [x0, #0xf]
    // 0xc246a8: DecompressPointer r1
    //     0xc246a8: add             x1, x1, HEAP, lsl #32
    // 0xc246ac: b               #0xc246bc
    // 0xc246b0: ldr             x0, [fp, #0x10]
    // 0xc246b4: LoadField: r1 = r0->field_13
    //     0xc246b4: ldur            w1, [x0, #0x13]
    // 0xc246b8: DecompressPointer r1
    //     0xc246b8: add             x1, x1, HEAP, lsl #32
    // 0xc246bc: stur            x1, [fp, #-8]
    // 0xc246c0: LoadField: r2 = r0->field_b
    //     0xc246c0: ldur            w2, [x0, #0xb]
    // 0xc246c4: DecompressPointer r2
    //     0xc246c4: add             x2, x2, HEAP, lsl #32
    // 0xc246c8: r0 = LoadClassIdInstr(r2)
    //     0xc246c8: ldur            x0, [x2, #-1]
    //     0xc246cc: ubfx            x0, x0, #0xc, #0x14
    // 0xc246d0: SaveReg r2
    //     0xc246d0: str             x2, [SP, #-8]!
    // 0xc246d4: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc246d4: add             lr, x0, #0xb7c
    //     0xc246d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc246dc: blr             lr
    // 0xc246e0: add             SP, SP, #8
    // 0xc246e4: mov             x1, x0
    // 0xc246e8: ldur            x0, [fp, #-8]
    // 0xc246ec: cmp             w0, NULL
    // 0xc246f0: b.ne            #0xc24704
    // 0xc246f4: mov             x0, x1
    // 0xc246f8: LeaveFrame
    //     0xc246f8: mov             SP, fp
    //     0xc246fc: ldp             fp, lr, [SP], #0x10
    // 0xc24700: ret
    //     0xc24700: ret             
    // 0xc24704: d0 = 0.000000
    //     0xc24704: eor             v0.16b, v0.16b, v0.16b
    // 0xc24708: LoadField: d1 = r1->field_7
    //     0xc24708: ldur            d1, [x1, #7]
    // 0xc2470c: fcmp            d1, d0
    // 0xc24710: b.vs            #0xc24718
    // 0xc24714: b.eq            #0xc24728
    // 0xc24718: d0 = 1.000000
    //     0xc24718: fmov            d0, #1.00000000
    // 0xc2471c: fcmp            d1, d0
    // 0xc24720: b.vs            #0xc24738
    // 0xc24724: b.ne            #0xc24738
    // 0xc24728: mov             x0, x1
    // 0xc2472c: LeaveFrame
    //     0xc2472c: mov             SP, fp
    //     0xc24730: ldp             fp, lr, [SP], #0x10
    // 0xc24734: ret
    //     0xc24734: ret             
    // 0xc24738: SaveReg r0
    //     0xc24738: str             x0, [SP, #-8]!
    // 0xc2473c: SaveReg d1
    //     0xc2473c: str             d1, [SP, #-8]!
    // 0xc24740: r0 = transform()
    //     0xc24740: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xc24744: add             SP, SP, #0x10
    // 0xc24748: LeaveFrame
    //     0xc24748: mov             SP, fp
    //     0xc2474c: ldp             fp, lr, [SP], #0x10
    // 0xc24750: ret
    //     0xc24750: ret             
    // 0xc24754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc24754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc24758: b               #0xc2468c
  }
  dynamic _updateCurveDirection(dynamic) {
    // ** addr: 0xcb9890, size: 0x18
    // 0xcb9890: r4 = 7
    //     0xcb9890: mov             x4, #7
    // 0xcb9894: r1 = Function '_updateCurveDirection@576411118':.
    //     0xcb9894: add             x17, PP, #0x21, lsl #12  ; [pp+0x21858] AnonymousClosure: (0x5a1490), in [package:flutter/src/animation/animations.dart] CurvedAnimation::_updateCurveDirection (0x5a1414)
    //     0xcb9898: ldr             x1, [x17, #0x858]
    // 0xcb989c: r24 = BuildNonGenericMethodExtractorStub
    //     0xcb989c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcb98a0: LoadField: r0 = r24->field_17
    //     0xcb98a0: ldur            x0, [x24, #0x17]
    // 0xcb98a4: br              x0
  }
}

// class id: 5988, size: 0x14, field offset: 0x14
enum _TrainHoppingMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15b1c, size: 0x5c
    // 0xb15b1c: EnterFrame
    //     0xb15b1c: stp             fp, lr, [SP, #-0x10]!
    //     0xb15b20: mov             fp, SP
    // 0xb15b24: CheckStackOverflow
    //     0xb15b24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15b28: cmp             SP, x16
    //     0xb15b2c: b.ls            #0xb15b70
    // 0xb15b30: r1 = Null
    //     0xb15b30: mov             x1, NULL
    // 0xb15b34: r2 = 4
    //     0xb15b34: mov             x2, #4
    // 0xb15b38: r0 = AllocateArray()
    //     0xb15b38: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15b3c: r17 = "_TrainHoppingMode."
    //     0xb15b3c: add             x17, PP, #0x22, lsl #12  ; [pp+0x221c0] "_TrainHoppingMode."
    //     0xb15b40: ldr             x17, [x17, #0x1c0]
    // 0xb15b44: StoreField: r0->field_f = r17
    //     0xb15b44: stur            w17, [x0, #0xf]
    // 0xb15b48: ldr             x1, [fp, #0x10]
    // 0xb15b4c: LoadField: r2 = r1->field_f
    //     0xb15b4c: ldur            w2, [x1, #0xf]
    // 0xb15b50: DecompressPointer r2
    //     0xb15b50: add             x2, x2, HEAP, lsl #32
    // 0xb15b54: StoreField: r0->field_13 = r2
    //     0xb15b54: stur            w2, [x0, #0x13]
    // 0xb15b58: SaveReg r0
    //     0xb15b58: str             x0, [SP, #-8]!
    // 0xb15b5c: r0 = _interpolate()
    //     0xb15b5c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15b60: add             SP, SP, #8
    // 0xb15b64: LeaveFrame
    //     0xb15b64: mov             SP, fp
    //     0xb15b68: ldp             fp, lr, [SP], #0x10
    // 0xb15b6c: ret
    //     0xb15b6c: ret             
    // 0xb15b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15b70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15b74: b               #0xb15b30
  }
}

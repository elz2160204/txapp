// lib: , url: package:flutter/src/animation/animation.dart

// class id: 1049066, size: 0x8
class :: {
}

// class id: 4327, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Animation<X0> extends Listenable
    implements ValueListenable<X0> {

  get _ isDismissed(/* No info */) {
    // ** addr: 0x66bb90, size: 0x68
    // 0x66bb90: EnterFrame
    //     0x66bb90: stp             fp, lr, [SP, #-0x10]!
    //     0x66bb94: mov             fp, SP
    // 0x66bb98: CheckStackOverflow
    //     0x66bb98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66bb9c: cmp             SP, x16
    //     0x66bba0: b.ls            #0x66bbf0
    // 0x66bba4: ldr             x0, [fp, #0x10]
    // 0x66bba8: r1 = LoadClassIdInstr(r0)
    //     0x66bba8: ldur            x1, [x0, #-1]
    //     0x66bbac: ubfx            x1, x1, #0xc, #0x14
    // 0x66bbb0: SaveReg r0
    //     0x66bbb0: str             x0, [SP, #-8]!
    // 0x66bbb4: mov             x0, x1
    // 0x66bbb8: r0 = GDT[cid_x0 + 0x376]()
    //     0x66bbb8: add             lr, x0, #0x376
    //     0x66bbbc: ldr             lr, [x21, lr, lsl #3]
    //     0x66bbc0: blr             lr
    // 0x66bbc4: add             SP, SP, #8
    // 0x66bbc8: r16 = Instance_AnimationStatus
    //     0x66bbc8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x66bbcc: ldr             x16, [x16, #0xba8]
    // 0x66bbd0: cmp             w0, w16
    // 0x66bbd4: r16 = true
    //     0x66bbd4: add             x16, NULL, #0x20  ; true
    // 0x66bbd8: r17 = false
    //     0x66bbd8: add             x17, NULL, #0x30  ; false
    // 0x66bbdc: csel            x1, x16, x17, eq
    // 0x66bbe0: mov             x0, x1
    // 0x66bbe4: LeaveFrame
    //     0x66bbe4: mov             SP, fp
    //     0x66bbe8: ldp             fp, lr, [SP], #0x10
    // 0x66bbec: ret
    //     0x66bbec: ret             
    // 0x66bbf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66bbf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66bbf4: b               #0x66bba4
  }
  get _ isCompleted(/* No info */) {
    // ** addr: 0x8620a8, size: 0x68
    // 0x8620a8: EnterFrame
    //     0x8620a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8620ac: mov             fp, SP
    // 0x8620b0: CheckStackOverflow
    //     0x8620b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8620b4: cmp             SP, x16
    //     0x8620b8: b.ls            #0x862108
    // 0x8620bc: ldr             x0, [fp, #0x10]
    // 0x8620c0: r1 = LoadClassIdInstr(r0)
    //     0x8620c0: ldur            x1, [x0, #-1]
    //     0x8620c4: ubfx            x1, x1, #0xc, #0x14
    // 0x8620c8: SaveReg r0
    //     0x8620c8: str             x0, [SP, #-8]!
    // 0x8620cc: mov             x0, x1
    // 0x8620d0: r0 = GDT[cid_x0 + 0x376]()
    //     0x8620d0: add             lr, x0, #0x376
    //     0x8620d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8620d8: blr             lr
    // 0x8620dc: add             SP, SP, #8
    // 0x8620e0: r16 = Instance_AnimationStatus
    //     0x8620e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x8620e4: ldr             x16, [x16, #0xba0]
    // 0x8620e8: cmp             w0, w16
    // 0x8620ec: r16 = true
    //     0x8620ec: add             x16, NULL, #0x20  ; true
    // 0x8620f0: r17 = false
    //     0x8620f0: add             x17, NULL, #0x30  ; false
    // 0x8620f4: csel            x1, x16, x17, eq
    // 0x8620f8: mov             x0, x1
    // 0x8620fc: LeaveFrame
    //     0x8620fc: mov             SP, fp
    //     0x862100: ldp             fp, lr, [SP], #0x10
    // 0x862104: ret
    //     0x862104: ret             
    // 0x862108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86210c: b               #0x8620bc
  }
  _ toString(/* No info */) {
    // ** addr: 0xad48bc, size: 0xc8
    // 0xad48bc: EnterFrame
    //     0xad48bc: stp             fp, lr, [SP, #-0x10]!
    //     0xad48c0: mov             fp, SP
    // 0xad48c4: AllocStack(0x10)
    //     0xad48c4: sub             SP, SP, #0x10
    // 0xad48c8: CheckStackOverflow
    //     0xad48c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad48cc: cmp             SP, x16
    //     0xad48d0: b.ls            #0xad497c
    // 0xad48d4: ldr             x16, [fp, #0x10]
    // 0xad48d8: SaveReg r16
    //     0xad48d8: str             x16, [SP, #-8]!
    // 0xad48dc: r0 = describeIdentity()
    //     0xad48dc: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xad48e0: add             SP, SP, #8
    // 0xad48e4: r1 = Null
    //     0xad48e4: mov             x1, NULL
    // 0xad48e8: r2 = 8
    //     0xad48e8: mov             x2, #8
    // 0xad48ec: stur            x0, [fp, #-8]
    // 0xad48f0: r0 = AllocateArray()
    //     0xad48f0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad48f4: mov             x1, x0
    // 0xad48f8: ldur            x0, [fp, #-8]
    // 0xad48fc: stur            x1, [fp, #-0x10]
    // 0xad4900: StoreField: r1->field_f = r0
    //     0xad4900: stur            w0, [x1, #0xf]
    // 0xad4904: r17 = "("
    //     0xad4904: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad4908: StoreField: r1->field_13 = r17
    //     0xad4908: stur            w17, [x1, #0x13]
    // 0xad490c: ldr             x0, [fp, #0x10]
    // 0xad4910: r2 = LoadClassIdInstr(r0)
    //     0xad4910: ldur            x2, [x0, #-1]
    //     0xad4914: ubfx            x2, x2, #0xc, #0x14
    // 0xad4918: SaveReg r0
    //     0xad4918: str             x0, [SP, #-8]!
    // 0xad491c: mov             x0, x2
    // 0xad4920: r0 = GDT[cid_x0 + 0xfee]()
    //     0xad4920: add             lr, x0, #0xfee
    //     0xad4924: ldr             lr, [x21, lr, lsl #3]
    //     0xad4928: blr             lr
    // 0xad492c: add             SP, SP, #8
    // 0xad4930: ldur            x1, [fp, #-0x10]
    // 0xad4934: ArrayStore: r1[2] = r0  ; List_4
    //     0xad4934: add             x25, x1, #0x17
    //     0xad4938: str             w0, [x25]
    //     0xad493c: tbz             w0, #0, #0xad4958
    //     0xad4940: ldurb           w16, [x1, #-1]
    //     0xad4944: ldurb           w17, [x0, #-1]
    //     0xad4948: and             x16, x17, x16, lsr #2
    //     0xad494c: tst             x16, HEAP, lsr #32
    //     0xad4950: b.eq            #0xad4958
    //     0xad4954: bl              #0xd67e5c
    // 0xad4958: ldur            x0, [fp, #-0x10]
    // 0xad495c: r17 = ")"
    //     0xad495c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad4960: StoreField: r0->field_1b = r17
    //     0xad4960: stur            w17, [x0, #0x1b]
    // 0xad4964: SaveReg r0
    //     0xad4964: str             x0, [SP, #-8]!
    // 0xad4968: r0 = _interpolate()
    //     0xad4968: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad496c: add             SP, SP, #8
    // 0xad4970: LeaveFrame
    //     0xad4970: mov             SP, fp
    //     0xad4974: ldp             fp, lr, [SP], #0x10
    // 0xad4978: ret
    //     0xad4978: ret             
    // 0xad497c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad497c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4980: b               #0xad48d4
  }
  _ toStringDetails(/* No info */) {
    // ** addr: 0xbea25c, size: 0xac
    // 0xbea25c: EnterFrame
    //     0xbea25c: stp             fp, lr, [SP, #-0x10]!
    //     0xbea260: mov             fp, SP
    // 0xbea264: CheckStackOverflow
    //     0xbea264: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbea268: cmp             SP, x16
    //     0xbea26c: b.ls            #0xbea300
    // 0xbea270: ldr             x0, [fp, #0x10]
    // 0xbea274: r1 = LoadClassIdInstr(r0)
    //     0xbea274: ldur            x1, [x0, #-1]
    //     0xbea278: ubfx            x1, x1, #0xc, #0x14
    // 0xbea27c: SaveReg r0
    //     0xbea27c: str             x0, [SP, #-8]!
    // 0xbea280: mov             x0, x1
    // 0xbea284: r0 = GDT[cid_x0 + 0x376]()
    //     0xbea284: add             lr, x0, #0x376
    //     0xbea288: ldr             lr, [x21, lr, lsl #3]
    //     0xbea28c: blr             lr
    // 0xbea290: add             SP, SP, #8
    // 0xbea294: LoadField: r1 = r0->field_7
    //     0xbea294: ldur            x1, [x0, #7]
    // 0xbea298: cmp             x1, #1
    // 0xbea29c: b.gt            #0xbea2d0
    // 0xbea2a0: cmp             x1, #0
    // 0xbea2a4: b.gt            #0xbea2bc
    // 0xbea2a8: r0 = "⏮"
    //     0xbea2a8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d1b0] "⏮"
    //     0xbea2ac: ldr             x0, [x0, #0x1b0]
    // 0xbea2b0: LeaveFrame
    //     0xbea2b0: mov             SP, fp
    //     0xbea2b4: ldp             fp, lr, [SP], #0x10
    // 0xbea2b8: ret
    //     0xbea2b8: ret             
    // 0xbea2bc: r0 = "▶"
    //     0xbea2bc: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d1b8] "▶"
    //     0xbea2c0: ldr             x0, [x0, #0x1b8]
    // 0xbea2c4: LeaveFrame
    //     0xbea2c4: mov             SP, fp
    //     0xbea2c8: ldp             fp, lr, [SP], #0x10
    // 0xbea2cc: ret
    //     0xbea2cc: ret             
    // 0xbea2d0: cmp             x1, #2
    // 0xbea2d4: b.gt            #0xbea2ec
    // 0xbea2d8: r0 = "◀"
    //     0xbea2d8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d1c0] "◀"
    //     0xbea2dc: ldr             x0, [x0, #0x1c0]
    // 0xbea2e0: LeaveFrame
    //     0xbea2e0: mov             SP, fp
    //     0xbea2e4: ldp             fp, lr, [SP], #0x10
    // 0xbea2e8: ret
    //     0xbea2e8: ret             
    // 0xbea2ec: r0 = "⏭"
    //     0xbea2ec: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d1c8] "⏭"
    //     0xbea2f0: ldr             x0, [x0, #0x1c8]
    // 0xbea2f4: LeaveFrame
    //     0xbea2f4: mov             SP, fp
    //     0xbea2f8: ldp             fp, lr, [SP], #0x10
    // 0xbea2fc: ret
    //     0xbea2fc: ret             
    // 0xbea300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbea300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbea304: b               #0xbea270
  }
}

// class id: 5991, size: 0x14, field offset: 0x14
enum AnimationStatus extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15a08, size: 0x5c
    // 0xb15a08: EnterFrame
    //     0xb15a08: stp             fp, lr, [SP, #-0x10]!
    //     0xb15a0c: mov             fp, SP
    // 0xb15a10: CheckStackOverflow
    //     0xb15a10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15a14: cmp             SP, x16
    //     0xb15a18: b.ls            #0xb15a5c
    // 0xb15a1c: r1 = Null
    //     0xb15a1c: mov             x1, NULL
    // 0xb15a20: r2 = 4
    //     0xb15a20: mov             x2, #4
    // 0xb15a24: r0 = AllocateArray()
    //     0xb15a24: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15a28: r17 = "AnimationStatus."
    //     0xb15a28: add             x17, PP, #0xe, lsl #12  ; [pp+0xe930] "AnimationStatus."
    //     0xb15a2c: ldr             x17, [x17, #0x930]
    // 0xb15a30: StoreField: r0->field_f = r17
    //     0xb15a30: stur            w17, [x0, #0xf]
    // 0xb15a34: ldr             x1, [fp, #0x10]
    // 0xb15a38: LoadField: r2 = r1->field_f
    //     0xb15a38: ldur            w2, [x1, #0xf]
    // 0xb15a3c: DecompressPointer r2
    //     0xb15a3c: add             x2, x2, HEAP, lsl #32
    // 0xb15a40: StoreField: r0->field_13 = r2
    //     0xb15a40: stur            w2, [x0, #0x13]
    // 0xb15a44: SaveReg r0
    //     0xb15a44: str             x0, [SP, #-8]!
    // 0xb15a48: r0 = _interpolate()
    //     0xb15a48: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15a4c: add             SP, SP, #8
    // 0xb15a50: LeaveFrame
    //     0xb15a50: mov             SP, fp
    //     0xb15a54: ldp             fp, lr, [SP], #0x10
    // 0xb15a58: ret
    //     0xb15a58: ret             
    // 0xb15a5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15a5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15a60: b               #0xb15a1c
  }
}

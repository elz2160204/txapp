// lib: , url: package:flutter/src/animation/tween.dart

// class id: 1049071, size: 0x8
class :: {
}

// class id: 4254, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Animatable<X0> extends Object {

  _ animate(/* No info */) {
    // ** addr: 0x5a1260, size: 0x34
    // 0x5a1260: EnterFrame
    //     0x5a1260: stp             fp, lr, [SP, #-0x10]!
    //     0x5a1264: mov             fp, SP
    // 0x5a1268: ldr             x0, [fp, #0x18]
    // 0x5a126c: LoadField: r1 = r0->field_7
    //     0x5a126c: ldur            w1, [x0, #7]
    // 0x5a1270: DecompressPointer r1
    //     0x5a1270: add             x1, x1, HEAP, lsl #32
    // 0x5a1274: r0 = _AnimatedEvaluation()
    //     0x5a1274: bl              #0x5a1294  ; Allocate_AnimatedEvaluationStub -> _AnimatedEvaluation<X0> (size=0x14)
    // 0x5a1278: ldr             x1, [fp, #0x10]
    // 0x5a127c: StoreField: r0->field_b = r1
    //     0x5a127c: stur            w1, [x0, #0xb]
    // 0x5a1280: ldr             x1, [fp, #0x18]
    // 0x5a1284: StoreField: r0->field_f = r1
    //     0x5a1284: stur            w1, [x0, #0xf]
    // 0x5a1288: LeaveFrame
    //     0x5a1288: mov             SP, fp
    //     0x5a128c: ldp             fp, lr, [SP], #0x10
    // 0x5a1290: ret
    //     0x5a1290: ret             
  }
  _ evaluate(/* No info */) {
    // ** addr: 0x66c4b0, size: 0x78
    // 0x66c4b0: EnterFrame
    //     0x66c4b0: stp             fp, lr, [SP, #-0x10]!
    //     0x66c4b4: mov             fp, SP
    // 0x66c4b8: CheckStackOverflow
    //     0x66c4b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66c4bc: cmp             SP, x16
    //     0x66c4c0: b.ls            #0x66c520
    // 0x66c4c4: ldr             x0, [fp, #0x10]
    // 0x66c4c8: r1 = LoadClassIdInstr(r0)
    //     0x66c4c8: ldur            x1, [x0, #-1]
    //     0x66c4cc: ubfx            x1, x1, #0xc, #0x14
    // 0x66c4d0: SaveReg r0
    //     0x66c4d0: str             x0, [SP, #-8]!
    // 0x66c4d4: mov             x0, x1
    // 0x66c4d8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x66c4d8: add             lr, x0, #0xb7c
    //     0x66c4dc: ldr             lr, [x21, lr, lsl #3]
    //     0x66c4e0: blr             lr
    // 0x66c4e4: add             SP, SP, #8
    // 0x66c4e8: LoadField: d0 = r0->field_7
    //     0x66c4e8: ldur            d0, [x0, #7]
    // 0x66c4ec: ldr             x0, [fp, #0x18]
    // 0x66c4f0: r1 = LoadClassIdInstr(r0)
    //     0x66c4f0: ldur            x1, [x0, #-1]
    //     0x66c4f4: ubfx            x1, x1, #0xc, #0x14
    // 0x66c4f8: SaveReg r0
    //     0x66c4f8: str             x0, [SP, #-8]!
    // 0x66c4fc: SaveReg d0
    //     0x66c4fc: str             d0, [SP, #-8]!
    // 0x66c500: mov             x0, x1
    // 0x66c504: r0 = GDT[cid_x0 + 0xd31]()
    //     0x66c504: add             lr, x0, #0xd31
    //     0x66c508: ldr             lr, [x21, lr, lsl #3]
    //     0x66c50c: blr             lr
    // 0x66c510: add             SP, SP, #0x10
    // 0x66c514: LeaveFrame
    //     0x66c514: mov             SP, fp
    //     0x66c518: ldp             fp, lr, [SP], #0x10
    // 0x66c51c: ret
    //     0x66c51c: ret             
    // 0x66c520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66c520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66c524: b               #0x66c4c4
  }
  _ chain(/* No info */) {
    // ** addr: 0x7b76c8, size: 0x34
    // 0x7b76c8: EnterFrame
    //     0x7b76c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b76cc: mov             fp, SP
    // 0x7b76d0: ldr             x0, [fp, #0x18]
    // 0x7b76d4: LoadField: r1 = r0->field_7
    //     0x7b76d4: ldur            w1, [x0, #7]
    // 0x7b76d8: DecompressPointer r1
    //     0x7b76d8: add             x1, x1, HEAP, lsl #32
    // 0x7b76dc: r0 = _ChainedEvaluation()
    //     0x7b76dc: bl              #0x7b76fc  ; Allocate_ChainedEvaluationStub -> _ChainedEvaluation<X0> (size=0x14)
    // 0x7b76e0: ldr             x1, [fp, #0x10]
    // 0x7b76e4: StoreField: r0->field_b = r1
    //     0x7b76e4: stur            w1, [x0, #0xb]
    // 0x7b76e8: ldr             x1, [fp, #0x18]
    // 0x7b76ec: StoreField: r0->field_f = r1
    //     0x7b76ec: stur            w1, [x0, #0xf]
    // 0x7b76f0: LeaveFrame
    //     0x7b76f0: mov             SP, fp
    //     0x7b76f4: ldp             fp, lr, [SP], #0x10
    // 0x7b76f8: ret
    //     0x7b76f8: ret             
  }
}

// class id: 4256, size: 0x10, field offset: 0xc
class CurveTween extends Animatable<double> {

  _ toString(/* No info */) {
    // ** addr: 0xad7388, size: 0x70
    // 0xad7388: EnterFrame
    //     0xad7388: stp             fp, lr, [SP, #-0x10]!
    //     0xad738c: mov             fp, SP
    // 0xad7390: CheckStackOverflow
    //     0xad7390: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad7394: cmp             SP, x16
    //     0xad7398: b.ls            #0xad73f0
    // 0xad739c: r1 = Null
    //     0xad739c: mov             x1, NULL
    // 0xad73a0: r2 = 8
    //     0xad73a0: mov             x2, #8
    // 0xad73a4: r0 = AllocateArray()
    //     0xad73a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad73a8: r17 = "CurveTween"
    //     0xad73a8: add             x17, PP, #0x22, lsl #12  ; [pp+0x22140] "CurveTween"
    //     0xad73ac: ldr             x17, [x17, #0x140]
    // 0xad73b0: StoreField: r0->field_f = r17
    //     0xad73b0: stur            w17, [x0, #0xf]
    // 0xad73b4: r17 = "(curve: "
    //     0xad73b4: add             x17, PP, #0x22, lsl #12  ; [pp+0x22148] "(curve: "
    //     0xad73b8: ldr             x17, [x17, #0x148]
    // 0xad73bc: StoreField: r0->field_13 = r17
    //     0xad73bc: stur            w17, [x0, #0x13]
    // 0xad73c0: ldr             x1, [fp, #0x10]
    // 0xad73c4: LoadField: r2 = r1->field_b
    //     0xad73c4: ldur            w2, [x1, #0xb]
    // 0xad73c8: DecompressPointer r2
    //     0xad73c8: add             x2, x2, HEAP, lsl #32
    // 0xad73cc: StoreField: r0->field_17 = r2
    //     0xad73cc: stur            w2, [x0, #0x17]
    // 0xad73d0: r17 = ")"
    //     0xad73d0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad73d4: StoreField: r0->field_1b = r17
    //     0xad73d4: stur            w17, [x0, #0x1b]
    // 0xad73d8: SaveReg r0
    //     0xad73d8: str             x0, [SP, #-8]!
    // 0xad73dc: r0 = _interpolate()
    //     0xad73dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad73e0: add             SP, SP, #8
    // 0xad73e4: LeaveFrame
    //     0xad73e4: mov             SP, fp
    //     0xad73e8: ldp             fp, lr, [SP], #0x10
    // 0xad73ec: ret
    //     0xad73ec: ret             
    // 0xad73f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad73f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad73f4: b               #0xad739c
  }
  _ transform(/* No info */) {
    // ** addr: 0xc09e58, size: 0xbc
    // 0xc09e58: EnterFrame
    //     0xc09e58: stp             fp, lr, [SP, #-0x10]!
    //     0xc09e5c: mov             fp, SP
    // 0xc09e60: d0 = 0.000000
    //     0xc09e60: eor             v0.16b, v0.16b, v0.16b
    // 0xc09e64: CheckStackOverflow
    //     0xc09e64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc09e68: cmp             SP, x16
    //     0xc09e6c: b.ls            #0xc09efc
    // 0xc09e70: ldr             d1, [fp, #0x10]
    // 0xc09e74: fcmp            d1, d0
    // 0xc09e78: b.vs            #0xc09e80
    // 0xc09e7c: b.eq            #0xc09e90
    // 0xc09e80: d0 = 1.000000
    //     0xc09e80: fmov            d0, #1.00000000
    // 0xc09e84: fcmp            d1, d0
    // 0xc09e88: b.vs            #0xc09ec4
    // 0xc09e8c: b.ne            #0xc09ec4
    // 0xc09e90: r0 = inline_Allocate_Double()
    //     0xc09e90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc09e94: add             x0, x0, #0x10
    //     0xc09e98: cmp             x1, x0
    //     0xc09e9c: b.ls            #0xc09f04
    //     0xc09ea0: str             x0, [THR, #0x60]  ; THR::top
    //     0xc09ea4: sub             x0, x0, #0xf
    //     0xc09ea8: mov             x1, #0xd108
    //     0xc09eac: movk            x1, #3, lsl #16
    //     0xc09eb0: stur            x1, [x0, #-1]
    // 0xc09eb4: StoreField: r0->field_7 = d1
    //     0xc09eb4: stur            d1, [x0, #7]
    // 0xc09eb8: LeaveFrame
    //     0xc09eb8: mov             SP, fp
    //     0xc09ebc: ldp             fp, lr, [SP], #0x10
    // 0xc09ec0: ret
    //     0xc09ec0: ret             
    // 0xc09ec4: ldr             x0, [fp, #0x18]
    // 0xc09ec8: LoadField: r1 = r0->field_b
    //     0xc09ec8: ldur            w1, [x0, #0xb]
    // 0xc09ecc: DecompressPointer r1
    //     0xc09ecc: add             x1, x1, HEAP, lsl #32
    // 0xc09ed0: r0 = LoadClassIdInstr(r1)
    //     0xc09ed0: ldur            x0, [x1, #-1]
    //     0xc09ed4: ubfx            x0, x0, #0xc, #0x14
    // 0xc09ed8: SaveReg r1
    //     0xc09ed8: str             x1, [SP, #-8]!
    // 0xc09edc: SaveReg d1
    //     0xc09edc: str             d1, [SP, #-8]!
    // 0xc09ee0: r0 = GDT[cid_x0 + 0x87f]()
    //     0xc09ee0: add             lr, x0, #0x87f
    //     0xc09ee4: ldr             lr, [x21, lr, lsl #3]
    //     0xc09ee8: blr             lr
    // 0xc09eec: add             SP, SP, #0x10
    // 0xc09ef0: LeaveFrame
    //     0xc09ef0: mov             SP, fp
    //     0xc09ef4: ldp             fp, lr, [SP], #0x10
    // 0xc09ef8: ret
    //     0xc09ef8: ret             
    // 0xc09efc: r0 = StackOverflowSharedWithFPURegs()
    //     0xc09efc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc09f00: b               #0xc09e70
    // 0xc09f04: SaveReg d1
    //     0xc09f04: str             q1, [SP, #-0x10]!
    // 0xc09f08: r0 = AllocateDouble()
    //     0xc09f08: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc09f0c: RestoreReg d1
    //     0xc09f0c: ldr             q1, [SP], #0x10
    // 0xc09f10: b               #0xc09eb4
  }
}

// class id: 4257, size: 0x14, field offset: 0xc
class Tween<X0> extends Animatable<X0> {

  _ toString(/* No info */) {
    // ** addr: 0xad7304, size: 0x84
    // 0xad7304: EnterFrame
    //     0xad7304: stp             fp, lr, [SP, #-0x10]!
    //     0xad7308: mov             fp, SP
    // 0xad730c: CheckStackOverflow
    //     0xad730c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad7310: cmp             SP, x16
    //     0xad7314: b.ls            #0xad7380
    // 0xad7318: r1 = Null
    //     0xad7318: mov             x1, NULL
    // 0xad731c: r2 = 12
    //     0xad731c: mov             x2, #0xc
    // 0xad7320: r0 = AllocateArray()
    //     0xad7320: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad7324: r17 = "Animatable"
    //     0xad7324: add             x17, PP, #0x22, lsl #12  ; [pp+0x22150] "Animatable"
    //     0xad7328: ldr             x17, [x17, #0x150]
    // 0xad732c: StoreField: r0->field_f = r17
    //     0xad732c: stur            w17, [x0, #0xf]
    // 0xad7330: r17 = "("
    //     0xad7330: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad7334: StoreField: r0->field_13 = r17
    //     0xad7334: stur            w17, [x0, #0x13]
    // 0xad7338: ldr             x1, [fp, #0x10]
    // 0xad733c: LoadField: r2 = r1->field_b
    //     0xad733c: ldur            w2, [x1, #0xb]
    // 0xad7340: DecompressPointer r2
    //     0xad7340: add             x2, x2, HEAP, lsl #32
    // 0xad7344: StoreField: r0->field_17 = r2
    //     0xad7344: stur            w2, [x0, #0x17]
    // 0xad7348: r17 = " → "
    //     0xad7348: add             x17, PP, #0x22, lsl #12  ; [pp+0x220c8] " → "
    //     0xad734c: ldr             x17, [x17, #0xc8]
    // 0xad7350: StoreField: r0->field_1b = r17
    //     0xad7350: stur            w17, [x0, #0x1b]
    // 0xad7354: LoadField: r2 = r1->field_f
    //     0xad7354: ldur            w2, [x1, #0xf]
    // 0xad7358: DecompressPointer r2
    //     0xad7358: add             x2, x2, HEAP, lsl #32
    // 0xad735c: StoreField: r0->field_1f = r2
    //     0xad735c: stur            w2, [x0, #0x1f]
    // 0xad7360: r17 = ")"
    //     0xad7360: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad7364: StoreField: r0->field_23 = r17
    //     0xad7364: stur            w17, [x0, #0x23]
    // 0xad7368: SaveReg r0
    //     0xad7368: str             x0, [SP, #-8]!
    // 0xad736c: r0 = _interpolate()
    //     0xad736c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad7370: add             SP, SP, #8
    // 0xad7374: LeaveFrame
    //     0xad7374: mov             SP, fp
    //     0xad7378: ldp             fp, lr, [SP], #0x10
    // 0xad737c: ret
    //     0xad737c: ret             
    // 0xad7380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad7380: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad7384: b               #0xad7318
  }
  _ lerp(/* No info */) {
    // ** addr: 0xbfa180, size: 0x134
    // 0xbfa180: EnterFrame
    //     0xbfa180: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa184: mov             fp, SP
    // 0xbfa188: AllocStack(0x8)
    //     0xbfa188: sub             SP, SP, #8
    // 0xbfa18c: CheckStackOverflow
    //     0xbfa18c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa190: cmp             SP, x16
    //     0xbfa194: b.ls            #0xbfa290
    // 0xbfa198: ldr             x0, [fp, #0x18]
    // 0xbfa19c: LoadField: r1 = r0->field_b
    //     0xbfa19c: ldur            w1, [x0, #0xb]
    // 0xbfa1a0: DecompressPointer r1
    //     0xbfa1a0: add             x1, x1, HEAP, lsl #32
    // 0xbfa1a4: stur            x1, [fp, #-8]
    // 0xbfa1a8: LoadField: r2 = r0->field_f
    //     0xbfa1a8: ldur            w2, [x0, #0xf]
    // 0xbfa1ac: DecompressPointer r2
    //     0xbfa1ac: add             x2, x2, HEAP, lsl #32
    // 0xbfa1b0: stp             x1, x2, [SP, #-0x10]!
    // 0xbfa1b4: r4 = 0
    //     0xbfa1b4: mov             x4, #0
    // 0xbfa1b8: ldr             x0, [SP, #8]
    // 0xbfa1bc: r16 = UnlinkedCall_0x4aeefc
    //     0xbfa1bc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fc8] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xbfa1c0: add             x16, x16, #0xfc8
    // 0xbfa1c4: ldp             x5, lr, [x16]
    // 0xbfa1c8: blr             lr
    // 0xbfa1cc: add             SP, SP, #0x10
    // 0xbfa1d0: ldr             d0, [fp, #0x10]
    // 0xbfa1d4: r1 = inline_Allocate_Double()
    //     0xbfa1d4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbfa1d8: add             x1, x1, #0x10
    //     0xbfa1dc: cmp             x2, x1
    //     0xbfa1e0: b.ls            #0xbfa298
    //     0xbfa1e4: str             x1, [THR, #0x60]  ; THR::top
    //     0xbfa1e8: sub             x1, x1, #0xf
    //     0xbfa1ec: mov             x2, #0xd108
    //     0xbfa1f0: movk            x2, #3, lsl #16
    //     0xbfa1f4: stur            x2, [x1, #-1]
    // 0xbfa1f8: StoreField: r1->field_7 = d0
    //     0xbfa1f8: stur            d0, [x1, #7]
    // 0xbfa1fc: stp             x1, x0, [SP, #-0x10]!
    // 0xbfa200: r4 = 0
    //     0xbfa200: mov             x4, #0
    // 0xbfa204: ldr             x0, [SP, #8]
    // 0xbfa208: r16 = UnlinkedCall_0x4aeefc
    //     0xbfa208: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fd8] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xbfa20c: add             x16, x16, #0xfd8
    // 0xbfa210: ldp             x5, lr, [x16]
    // 0xbfa214: blr             lr
    // 0xbfa218: add             SP, SP, #0x10
    // 0xbfa21c: ldur            x16, [fp, #-8]
    // 0xbfa220: stp             x0, x16, [SP, #-0x10]!
    // 0xbfa224: r4 = 0
    //     0xbfa224: mov             x4, #0
    // 0xbfa228: ldr             x0, [SP, #8]
    // 0xbfa22c: r16 = UnlinkedCall_0x4aeefc
    //     0xbfa22c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28fe8] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xbfa230: add             x16, x16, #0xfe8
    // 0xbfa234: ldp             x5, lr, [x16]
    // 0xbfa238: blr             lr
    // 0xbfa23c: add             SP, SP, #0x10
    // 0xbfa240: mov             x3, x0
    // 0xbfa244: ldr             x0, [fp, #0x18]
    // 0xbfa248: stur            x3, [fp, #-8]
    // 0xbfa24c: LoadField: r2 = r0->field_7
    //     0xbfa24c: ldur            w2, [x0, #7]
    // 0xbfa250: DecompressPointer r2
    //     0xbfa250: add             x2, x2, HEAP, lsl #32
    // 0xbfa254: mov             x0, x3
    // 0xbfa258: r1 = Null
    //     0xbfa258: mov             x1, NULL
    // 0xbfa25c: cmp             w2, NULL
    // 0xbfa260: b.eq            #0xbfa280
    // 0xbfa264: LoadField: r4 = r2->field_17
    //     0xbfa264: ldur            w4, [x2, #0x17]
    // 0xbfa268: DecompressPointer r4
    //     0xbfa268: add             x4, x4, HEAP, lsl #32
    // 0xbfa26c: r8 = X0
    //     0xbfa26c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbfa270: LoadField: r9 = r4->field_7
    //     0xbfa270: ldur            x9, [x4, #7]
    // 0xbfa274: r3 = Null
    //     0xbfa274: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ff8] Null
    //     0xbfa278: ldr             x3, [x3, #0xff8]
    // 0xbfa27c: blr             x9
    // 0xbfa280: ldur            x0, [fp, #-8]
    // 0xbfa284: LeaveFrame
    //     0xbfa284: mov             SP, fp
    //     0xbfa288: ldp             fp, lr, [SP], #0x10
    // 0xbfa28c: ret
    //     0xbfa28c: ret             
    // 0xbfa290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa290: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa294: b               #0xbfa198
    // 0xbfa298: SaveReg d0
    //     0xbfa298: str             q0, [SP, #-0x10]!
    // 0xbfa29c: SaveReg r0
    //     0xbfa29c: str             x0, [SP, #-8]!
    // 0xbfa2a0: r0 = AllocateDouble()
    //     0xbfa2a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbfa2a4: mov             x1, x0
    // 0xbfa2a8: RestoreReg r0
    //     0xbfa2a8: ldr             x0, [SP], #8
    // 0xbfa2ac: RestoreReg d0
    //     0xbfa2ac: ldr             q0, [SP], #0x10
    // 0xbfa2b0: b               #0xbfa1f8
  }
  set _ end=(/* No info */) {
    // ** addr: 0xbfa4cc, size: 0x80
    // 0xbfa4cc: EnterFrame
    //     0xbfa4cc: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa4d0: mov             fp, SP
    // 0xbfa4d4: ldr             x3, [fp, #0x18]
    // 0xbfa4d8: LoadField: r2 = r3->field_7
    //     0xbfa4d8: ldur            w2, [x3, #7]
    // 0xbfa4dc: DecompressPointer r2
    //     0xbfa4dc: add             x2, x2, HEAP, lsl #32
    // 0xbfa4e0: ldr             x0, [fp, #0x10]
    // 0xbfa4e4: r1 = Null
    //     0xbfa4e4: mov             x1, NULL
    // 0xbfa4e8: cmp             w0, NULL
    // 0xbfa4ec: b.eq            #0xbfa514
    // 0xbfa4f0: cmp             w2, NULL
    // 0xbfa4f4: b.eq            #0xbfa514
    // 0xbfa4f8: LoadField: r4 = r2->field_17
    //     0xbfa4f8: ldur            w4, [x2, #0x17]
    // 0xbfa4fc: DecompressPointer r4
    //     0xbfa4fc: add             x4, x4, HEAP, lsl #32
    // 0xbfa500: r8 = X0?
    //     0xbfa500: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xbfa504: LoadField: r9 = r4->field_7
    //     0xbfa504: ldur            x9, [x4, #7]
    // 0xbfa508: r3 = Null
    //     0xbfa508: add             x3, PP, #0x29, lsl #12  ; [pp+0x29008] Null
    //     0xbfa50c: ldr             x3, [x3, #8]
    // 0xbfa510: blr             x9
    // 0xbfa514: ldr             x0, [fp, #0x10]
    // 0xbfa518: ldr             x1, [fp, #0x18]
    // 0xbfa51c: StoreField: r1->field_f = r0
    //     0xbfa51c: stur            w0, [x1, #0xf]
    //     0xbfa520: tbz             w0, #0, #0xbfa53c
    //     0xbfa524: ldurb           w16, [x1, #-1]
    //     0xbfa528: ldurb           w17, [x0, #-1]
    //     0xbfa52c: and             x16, x17, x16, lsr #2
    //     0xbfa530: tst             x16, HEAP, lsr #32
    //     0xbfa534: b.eq            #0xbfa53c
    //     0xbfa538: bl              #0xd6826c
    // 0xbfa53c: r0 = Null
    //     0xbfa53c: mov             x0, NULL
    // 0xbfa540: LeaveFrame
    //     0xbfa540: mov             SP, fp
    //     0xbfa544: ldp             fp, lr, [SP], #0x10
    // 0xbfa548: ret
    //     0xbfa548: ret             
  }
  set _ begin=(/* No info */) {
    // ** addr: 0xbfa764, size: 0x80
    // 0xbfa764: EnterFrame
    //     0xbfa764: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa768: mov             fp, SP
    // 0xbfa76c: ldr             x3, [fp, #0x18]
    // 0xbfa770: LoadField: r2 = r3->field_7
    //     0xbfa770: ldur            w2, [x3, #7]
    // 0xbfa774: DecompressPointer r2
    //     0xbfa774: add             x2, x2, HEAP, lsl #32
    // 0xbfa778: ldr             x0, [fp, #0x10]
    // 0xbfa77c: r1 = Null
    //     0xbfa77c: mov             x1, NULL
    // 0xbfa780: cmp             w0, NULL
    // 0xbfa784: b.eq            #0xbfa7ac
    // 0xbfa788: cmp             w2, NULL
    // 0xbfa78c: b.eq            #0xbfa7ac
    // 0xbfa790: LoadField: r4 = r2->field_17
    //     0xbfa790: ldur            w4, [x2, #0x17]
    // 0xbfa794: DecompressPointer r4
    //     0xbfa794: add             x4, x4, HEAP, lsl #32
    // 0xbfa798: r8 = X0?
    //     0xbfa798: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xbfa79c: LoadField: r9 = r4->field_7
    //     0xbfa79c: ldur            x9, [x4, #7]
    // 0xbfa7a0: r3 = Null
    //     0xbfa7a0: add             x3, PP, #0x29, lsl #12  ; [pp+0x29018] Null
    //     0xbfa7a4: ldr             x3, [x3, #0x18]
    // 0xbfa7a8: blr             x9
    // 0xbfa7ac: ldr             x0, [fp, #0x10]
    // 0xbfa7b0: ldr             x1, [fp, #0x18]
    // 0xbfa7b4: StoreField: r1->field_b = r0
    //     0xbfa7b4: stur            w0, [x1, #0xb]
    //     0xbfa7b8: tbz             w0, #0, #0xbfa7d4
    //     0xbfa7bc: ldurb           w16, [x1, #-1]
    //     0xbfa7c0: ldurb           w17, [x0, #-1]
    //     0xbfa7c4: and             x16, x17, x16, lsr #2
    //     0xbfa7c8: tst             x16, HEAP, lsr #32
    //     0xbfa7cc: b.eq            #0xbfa7d4
    //     0xbfa7d0: bl              #0xd6826c
    // 0xbfa7d4: r0 = Null
    //     0xbfa7d4: mov             x0, NULL
    // 0xbfa7d8: LeaveFrame
    //     0xbfa7d8: mov             SP, fp
    //     0xbfa7dc: ldp             fp, lr, [SP], #0x10
    // 0xbfa7e0: ret
    //     0xbfa7e0: ret             
  }
  _ transform(/* No info */) {
    // ** addr: 0xc09d2c, size: 0x12c
    // 0xc09d2c: EnterFrame
    //     0xc09d2c: stp             fp, lr, [SP, #-0x10]!
    //     0xc09d30: mov             fp, SP
    // 0xc09d34: AllocStack(0x8)
    //     0xc09d34: sub             SP, SP, #8
    // 0xc09d38: d0 = 0.000000
    //     0xc09d38: eor             v0.16b, v0.16b, v0.16b
    // 0xc09d3c: CheckStackOverflow
    //     0xc09d3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc09d40: cmp             SP, x16
    //     0xc09d44: b.ls            #0xc09e50
    // 0xc09d48: ldr             d1, [fp, #0x10]
    // 0xc09d4c: fcmp            d1, d0
    // 0xc09d50: b.vs            #0xc09db4
    // 0xc09d54: b.ne            #0xc09db4
    // 0xc09d58: ldr             x0, [fp, #0x18]
    // 0xc09d5c: LoadField: r3 = r0->field_b
    //     0xc09d5c: ldur            w3, [x0, #0xb]
    // 0xc09d60: DecompressPointer r3
    //     0xc09d60: add             x3, x3, HEAP, lsl #32
    // 0xc09d64: stur            x3, [fp, #-8]
    // 0xc09d68: cmp             w3, NULL
    // 0xc09d6c: b.ne            #0xc09da4
    // 0xc09d70: LoadField: r2 = r0->field_7
    //     0xc09d70: ldur            w2, [x0, #7]
    // 0xc09d74: DecompressPointer r2
    //     0xc09d74: add             x2, x2, HEAP, lsl #32
    // 0xc09d78: mov             x0, x3
    // 0xc09d7c: r1 = Null
    //     0xc09d7c: mov             x1, NULL
    // 0xc09d80: cmp             w2, NULL
    // 0xc09d84: b.eq            #0xc09da4
    // 0xc09d88: LoadField: r4 = r2->field_17
    //     0xc09d88: ldur            w4, [x2, #0x17]
    // 0xc09d8c: DecompressPointer r4
    //     0xc09d8c: add             x4, x4, HEAP, lsl #32
    // 0xc09d90: r8 = X0
    //     0xc09d90: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc09d94: LoadField: r9 = r4->field_7
    //     0xc09d94: ldur            x9, [x4, #7]
    // 0xc09d98: r3 = Null
    //     0xc09d98: add             x3, PP, #0x22, lsl #12  ; [pp+0x22158] Null
    //     0xc09d9c: ldr             x3, [x3, #0x158]
    // 0xc09da0: blr             x9
    // 0xc09da4: ldur            x0, [fp, #-8]
    // 0xc09da8: LeaveFrame
    //     0xc09da8: mov             SP, fp
    //     0xc09dac: ldp             fp, lr, [SP], #0x10
    // 0xc09db0: ret
    //     0xc09db0: ret             
    // 0xc09db4: ldr             x0, [fp, #0x18]
    // 0xc09db8: d0 = 1.000000
    //     0xc09db8: fmov            d0, #1.00000000
    // 0xc09dbc: fcmp            d1, d0
    // 0xc09dc0: b.vs            #0xc09e20
    // 0xc09dc4: b.ne            #0xc09e20
    // 0xc09dc8: LoadField: r3 = r0->field_f
    //     0xc09dc8: ldur            w3, [x0, #0xf]
    // 0xc09dcc: DecompressPointer r3
    //     0xc09dcc: add             x3, x3, HEAP, lsl #32
    // 0xc09dd0: stur            x3, [fp, #-8]
    // 0xc09dd4: cmp             w3, NULL
    // 0xc09dd8: b.ne            #0xc09e10
    // 0xc09ddc: LoadField: r2 = r0->field_7
    //     0xc09ddc: ldur            w2, [x0, #7]
    // 0xc09de0: DecompressPointer r2
    //     0xc09de0: add             x2, x2, HEAP, lsl #32
    // 0xc09de4: mov             x0, x3
    // 0xc09de8: r1 = Null
    //     0xc09de8: mov             x1, NULL
    // 0xc09dec: cmp             w2, NULL
    // 0xc09df0: b.eq            #0xc09e10
    // 0xc09df4: LoadField: r4 = r2->field_17
    //     0xc09df4: ldur            w4, [x2, #0x17]
    // 0xc09df8: DecompressPointer r4
    //     0xc09df8: add             x4, x4, HEAP, lsl #32
    // 0xc09dfc: r8 = X0
    //     0xc09dfc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc09e00: LoadField: r9 = r4->field_7
    //     0xc09e00: ldur            x9, [x4, #7]
    // 0xc09e04: r3 = Null
    //     0xc09e04: add             x3, PP, #0x22, lsl #12  ; [pp+0x22168] Null
    //     0xc09e08: ldr             x3, [x3, #0x168]
    // 0xc09e0c: blr             x9
    // 0xc09e10: ldur            x0, [fp, #-8]
    // 0xc09e14: LeaveFrame
    //     0xc09e14: mov             SP, fp
    //     0xc09e18: ldp             fp, lr, [SP], #0x10
    // 0xc09e1c: ret
    //     0xc09e1c: ret             
    // 0xc09e20: r1 = LoadClassIdInstr(r0)
    //     0xc09e20: ldur            x1, [x0, #-1]
    //     0xc09e24: ubfx            x1, x1, #0xc, #0x14
    // 0xc09e28: SaveReg r0
    //     0xc09e28: str             x0, [SP, #-8]!
    // 0xc09e2c: SaveReg d1
    //     0xc09e2c: str             d1, [SP, #-8]!
    // 0xc09e30: mov             x0, x1
    // 0xc09e34: r0 = GDT[cid_x0 + 0xfcc]()
    //     0xc09e34: add             lr, x0, #0xfcc
    //     0xc09e38: ldr             lr, [x21, lr, lsl #3]
    //     0xc09e3c: blr             lr
    // 0xc09e40: add             SP, SP, #0x10
    // 0xc09e44: LeaveFrame
    //     0xc09e44: mov             SP, fp
    //     0xc09e48: ldp             fp, lr, [SP], #0x10
    // 0xc09e4c: ret
    //     0xc09e4c: ret             
    // 0xc09e50: r0 = StackOverflowSharedWithFPURegs()
    //     0xc09e50: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc09e54: b               #0xc09d48
  }
}

// class id: 4270, size: 0x14, field offset: 0x14
class ConstantTween<X0> extends Tween<X0> {

  _ toString(/* No info */) {
    // ** addr: 0xad6688, size: 0x70
    // 0xad6688: EnterFrame
    //     0xad6688: stp             fp, lr, [SP, #-0x10]!
    //     0xad668c: mov             fp, SP
    // 0xad6690: CheckStackOverflow
    //     0xad6690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad6694: cmp             SP, x16
    //     0xad6698: b.ls            #0xad66f0
    // 0xad669c: r1 = Null
    //     0xad669c: mov             x1, NULL
    // 0xad66a0: r2 = 8
    //     0xad66a0: mov             x2, #8
    // 0xad66a4: r0 = AllocateArray()
    //     0xad66a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad66a8: r17 = "ConstantTween"
    //     0xad66a8: add             x17, PP, #0x37, lsl #12  ; [pp+0x37d38] "ConstantTween"
    //     0xad66ac: ldr             x17, [x17, #0xd38]
    // 0xad66b0: StoreField: r0->field_f = r17
    //     0xad66b0: stur            w17, [x0, #0xf]
    // 0xad66b4: r17 = "(value: "
    //     0xad66b4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37d40] "(value: "
    //     0xad66b8: ldr             x17, [x17, #0xd40]
    // 0xad66bc: StoreField: r0->field_13 = r17
    //     0xad66bc: stur            w17, [x0, #0x13]
    // 0xad66c0: ldr             x1, [fp, #0x10]
    // 0xad66c4: LoadField: r2 = r1->field_b
    //     0xad66c4: ldur            w2, [x1, #0xb]
    // 0xad66c8: DecompressPointer r2
    //     0xad66c8: add             x2, x2, HEAP, lsl #32
    // 0xad66cc: StoreField: r0->field_17 = r2
    //     0xad66cc: stur            w2, [x0, #0x17]
    // 0xad66d0: r17 = ")"
    //     0xad66d0: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad66d4: StoreField: r0->field_1b = r17
    //     0xad66d4: stur            w17, [x0, #0x1b]
    // 0xad66d8: SaveReg r0
    //     0xad66d8: str             x0, [SP, #-8]!
    // 0xad66dc: r0 = _interpolate()
    //     0xad66dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad66e0: add             SP, SP, #8
    // 0xad66e4: LeaveFrame
    //     0xad66e4: mov             SP, fp
    //     0xad66e8: ldp             fp, lr, [SP], #0x10
    // 0xad66ec: ret
    //     0xad66ec: ret             
    // 0xad66f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad66f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad66f4: b               #0xad669c
  }
  _ lerp(/* No info */) {
    // ** addr: 0xbec848, size: 0x68
    // 0xbec848: EnterFrame
    //     0xbec848: stp             fp, lr, [SP, #-0x10]!
    //     0xbec84c: mov             fp, SP
    // 0xbec850: AllocStack(0x8)
    //     0xbec850: sub             SP, SP, #8
    // 0xbec854: ldr             x0, [fp, #0x18]
    // 0xbec858: LoadField: r3 = r0->field_b
    //     0xbec858: ldur            w3, [x0, #0xb]
    // 0xbec85c: DecompressPointer r3
    //     0xbec85c: add             x3, x3, HEAP, lsl #32
    // 0xbec860: stur            x3, [fp, #-8]
    // 0xbec864: cmp             w3, NULL
    // 0xbec868: b.ne            #0xbec8a0
    // 0xbec86c: LoadField: r2 = r0->field_7
    //     0xbec86c: ldur            w2, [x0, #7]
    // 0xbec870: DecompressPointer r2
    //     0xbec870: add             x2, x2, HEAP, lsl #32
    // 0xbec874: mov             x0, x3
    // 0xbec878: r1 = Null
    //     0xbec878: mov             x1, NULL
    // 0xbec87c: cmp             w2, NULL
    // 0xbec880: b.eq            #0xbec8a0
    // 0xbec884: LoadField: r4 = r2->field_17
    //     0xbec884: ldur            w4, [x2, #0x17]
    // 0xbec888: DecompressPointer r4
    //     0xbec888: add             x4, x4, HEAP, lsl #32
    // 0xbec88c: r8 = X0
    //     0xbec88c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbec890: LoadField: r9 = r4->field_7
    //     0xbec890: ldur            x9, [x4, #7]
    // 0xbec894: r3 = Null
    //     0xbec894: add             x3, PP, #0x37, lsl #12  ; [pp+0x37d48] Null
    //     0xbec898: ldr             x3, [x3, #0xd48]
    // 0xbec89c: blr             x9
    // 0xbec8a0: ldur            x0, [fp, #-8]
    // 0xbec8a4: LeaveFrame
    //     0xbec8a4: mov             SP, fp
    //     0xbec8a8: ldp             fp, lr, [SP], #0x10
    // 0xbec8ac: ret
    //     0xbec8ac: ret             
  }
}

// class id: 4271, size: 0x14, field offset: 0x14
class IntTween extends Tween<int> {

  _ lerp(/* No info */) {
    // ** addr: 0xbec6b8, size: 0x190
    // 0xbec6b8: EnterFrame
    //     0xbec6b8: stp             fp, lr, [SP, #-0x10]!
    //     0xbec6bc: mov             fp, SP
    // 0xbec6c0: AllocStack(0x8)
    //     0xbec6c0: sub             SP, SP, #8
    // 0xbec6c4: CheckStackOverflow
    //     0xbec6c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbec6c8: cmp             SP, x16
    //     0xbec6cc: b.ls            #0xbec800
    // 0xbec6d0: ldr             x0, [fp, #0x18]
    // 0xbec6d4: LoadField: r1 = r0->field_b
    //     0xbec6d4: ldur            w1, [x0, #0xb]
    // 0xbec6d8: DecompressPointer r1
    //     0xbec6d8: add             x1, x1, HEAP, lsl #32
    // 0xbec6dc: stur            x1, [fp, #-8]
    // 0xbec6e0: cmp             w1, NULL
    // 0xbec6e4: b.eq            #0xbec808
    // 0xbec6e8: LoadField: r2 = r0->field_f
    //     0xbec6e8: ldur            w2, [x0, #0xf]
    // 0xbec6ec: DecompressPointer r2
    //     0xbec6ec: add             x2, x2, HEAP, lsl #32
    // 0xbec6f0: cmp             w2, NULL
    // 0xbec6f4: b.eq            #0xbec80c
    // 0xbec6f8: r0 = 59
    //     0xbec6f8: mov             x0, #0x3b
    // 0xbec6fc: branchIfSmi(r2, 0xbec708)
    //     0xbec6fc: tbz             w2, #0, #0xbec708
    // 0xbec700: r0 = LoadClassIdInstr(r2)
    //     0xbec700: ldur            x0, [x2, #-1]
    //     0xbec704: ubfx            x0, x0, #0xc, #0x14
    // 0xbec708: stp             x1, x2, [SP, #-0x10]!
    // 0xbec70c: r0 = GDT[cid_x0 + -0xfea]()
    //     0xbec70c: sub             lr, x0, #0xfea
    //     0xbec710: ldr             lr, [x21, lr, lsl #3]
    //     0xbec714: blr             lr
    // 0xbec718: add             SP, SP, #0x10
    // 0xbec71c: ldr             d0, [fp, #0x10]
    // 0xbec720: r1 = inline_Allocate_Double()
    //     0xbec720: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbec724: add             x1, x1, #0x10
    //     0xbec728: cmp             x2, x1
    //     0xbec72c: b.ls            #0xbec810
    //     0xbec730: str             x1, [THR, #0x60]  ; THR::top
    //     0xbec734: sub             x1, x1, #0xf
    //     0xbec738: mov             x2, #0xd108
    //     0xbec73c: movk            x2, #3, lsl #16
    //     0xbec740: stur            x2, [x1, #-1]
    // 0xbec744: StoreField: r1->field_7 = d0
    //     0xbec744: stur            d0, [x1, #7]
    // 0xbec748: r2 = 59
    //     0xbec748: mov             x2, #0x3b
    // 0xbec74c: branchIfSmi(r0, 0xbec758)
    //     0xbec74c: tbz             w0, #0, #0xbec758
    // 0xbec750: r2 = LoadClassIdInstr(r0)
    //     0xbec750: ldur            x2, [x0, #-1]
    //     0xbec754: ubfx            x2, x2, #0xc, #0x14
    // 0xbec758: stp             x1, x0, [SP, #-0x10]!
    // 0xbec75c: mov             x0, x2
    // 0xbec760: r0 = GDT[cid_x0 + -0xff8]()
    //     0xbec760: sub             lr, x0, #0xff8
    //     0xbec764: ldr             lr, [x21, lr, lsl #3]
    //     0xbec768: blr             lr
    // 0xbec76c: add             SP, SP, #0x10
    // 0xbec770: mov             x1, x0
    // 0xbec774: ldur            x0, [fp, #-8]
    // 0xbec778: r2 = 59
    //     0xbec778: mov             x2, #0x3b
    // 0xbec77c: branchIfSmi(r0, 0xbec788)
    //     0xbec77c: tbz             w0, #0, #0xbec788
    // 0xbec780: r2 = LoadClassIdInstr(r0)
    //     0xbec780: ldur            x2, [x0, #-1]
    //     0xbec784: ubfx            x2, x2, #0xc, #0x14
    // 0xbec788: stp             x1, x0, [SP, #-0x10]!
    // 0xbec78c: mov             x0, x2
    // 0xbec790: r0 = GDT[cid_x0 + -0xff3]()
    //     0xbec790: sub             lr, x0, #0xff3
    //     0xbec794: ldr             lr, [x21, lr, lsl #3]
    //     0xbec798: blr             lr
    // 0xbec79c: add             SP, SP, #0x10
    // 0xbec7a0: LoadField: d0 = r0->field_7
    //     0xbec7a0: ldur            d0, [x0, #7]
    // 0xbec7a4: stp             fp, lr, [SP, #-0x10]!
    // 0xbec7a8: mov             fp, SP
    // 0xbec7ac: CallRuntime_LibcRound(double) -> double
    //     0xbec7ac: and             SP, SP, #0xfffffffffffffff0
    //     0xbec7b0: mov             sp, SP
    //     0xbec7b4: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xbec7b8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbec7bc: blr             x16
    //     0xbec7c0: mov             x16, #8
    //     0xbec7c4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbec7c8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbec7cc: sub             sp, x16, #1, lsl #12
    //     0xbec7d0: mov             SP, fp
    //     0xbec7d4: ldp             fp, lr, [SP], #0x10
    // 0xbec7d8: fcmp            d0, d0
    // 0xbec7dc: b.vs            #0xbec82c
    // 0xbec7e0: fcvtzs          x0, d0
    // 0xbec7e4: asr             x16, x0, #0x1e
    // 0xbec7e8: cmp             x16, x0, asr #63
    // 0xbec7ec: b.ne            #0xbec82c
    // 0xbec7f0: lsl             x0, x0, #1
    // 0xbec7f4: LeaveFrame
    //     0xbec7f4: mov             SP, fp
    //     0xbec7f8: ldp             fp, lr, [SP], #0x10
    // 0xbec7fc: ret
    //     0xbec7fc: ret             
    // 0xbec800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec800: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec804: b               #0xbec6d0
    // 0xbec808: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbec808: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbec80c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbec80c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbec810: SaveReg d0
    //     0xbec810: str             q0, [SP, #-0x10]!
    // 0xbec814: SaveReg r0
    //     0xbec814: str             x0, [SP, #-8]!
    // 0xbec818: r0 = AllocateDouble()
    //     0xbec818: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbec81c: mov             x1, x0
    // 0xbec820: RestoreReg r0
    //     0xbec820: ldr             x0, [SP], #8
    // 0xbec824: RestoreReg d0
    //     0xbec824: ldr             q0, [SP], #0x10
    // 0xbec828: b               #0xbec744
    // 0xbec82c: SaveReg d0
    //     0xbec82c: str             q0, [SP, #-0x10]!
    // 0xbec830: r0 = 218
    //     0xbec830: mov             x0, #0xda
    // 0xbec834: r24 = DoubleToIntegerStub
    //     0xbec834: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xbec838: LoadField: r30 = r24->field_7
    //     0xbec838: ldur            lr, [x24, #7]
    // 0xbec83c: blr             lr
    // 0xbec840: RestoreReg d0
    //     0xbec840: ldr             q0, [SP], #0x10
    // 0xbec844: b               #0xbec7f4
  }
}

// class id: 4272, size: 0x14, field offset: 0x14
class RectTween extends Tween<Rect?> {

  _ lerp(/* No info */) {
    // ** addr: 0xbec668, size: 0x50
    // 0xbec668: EnterFrame
    //     0xbec668: stp             fp, lr, [SP, #-0x10]!
    //     0xbec66c: mov             fp, SP
    // 0xbec670: CheckStackOverflow
    //     0xbec670: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbec674: cmp             SP, x16
    //     0xbec678: b.ls            #0xbec6b0
    // 0xbec67c: ldr             x0, [fp, #0x18]
    // 0xbec680: LoadField: r1 = r0->field_b
    //     0xbec680: ldur            w1, [x0, #0xb]
    // 0xbec684: DecompressPointer r1
    //     0xbec684: add             x1, x1, HEAP, lsl #32
    // 0xbec688: LoadField: r2 = r0->field_f
    //     0xbec688: ldur            w2, [x0, #0xf]
    // 0xbec68c: DecompressPointer r2
    //     0xbec68c: add             x2, x2, HEAP, lsl #32
    // 0xbec690: stp             x2, x1, [SP, #-0x10]!
    // 0xbec694: ldr             d0, [fp, #0x10]
    // 0xbec698: SaveReg d0
    //     0xbec698: str             d0, [SP, #-8]!
    // 0xbec69c: r0 = lerp()
    //     0xbec69c: bl              #0xa6dd78  ; [dart:ui] Rect::lerp
    // 0xbec6a0: add             SP, SP, #0x18
    // 0xbec6a4: LeaveFrame
    //     0xbec6a4: mov             SP, fp
    //     0xbec6a8: ldp             fp, lr, [SP], #0x10
    // 0xbec6ac: ret
    //     0xbec6ac: ret             
    // 0xbec6b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec6b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec6b4: b               #0xbec67c
  }
}

// class id: 4274, size: 0x14, field offset: 0x14
class SizeTween extends Tween<Size?> {

  _ lerp(/* No info */) {
    // ** addr: 0xbec30c, size: 0x90
    // 0xbec30c: EnterFrame
    //     0xbec30c: stp             fp, lr, [SP, #-0x10]!
    //     0xbec310: mov             fp, SP
    // 0xbec314: CheckStackOverflow
    //     0xbec314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbec318: cmp             SP, x16
    //     0xbec31c: b.ls            #0xbec37c
    // 0xbec320: ldr             x0, [fp, #0x18]
    // 0xbec324: LoadField: r1 = r0->field_b
    //     0xbec324: ldur            w1, [x0, #0xb]
    // 0xbec328: DecompressPointer r1
    //     0xbec328: add             x1, x1, HEAP, lsl #32
    // 0xbec32c: LoadField: r2 = r0->field_f
    //     0xbec32c: ldur            w2, [x0, #0xf]
    // 0xbec330: DecompressPointer r2
    //     0xbec330: add             x2, x2, HEAP, lsl #32
    // 0xbec334: ldr             d0, [fp, #0x10]
    // 0xbec338: r0 = inline_Allocate_Double()
    //     0xbec338: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xbec33c: add             x0, x0, #0x10
    //     0xbec340: cmp             x3, x0
    //     0xbec344: b.ls            #0xbec384
    //     0xbec348: str             x0, [THR, #0x60]  ; THR::top
    //     0xbec34c: sub             x0, x0, #0xf
    //     0xbec350: mov             x3, #0xd108
    //     0xbec354: movk            x3, #3, lsl #16
    //     0xbec358: stur            x3, [x0, #-1]
    // 0xbec35c: StoreField: r0->field_7 = d0
    //     0xbec35c: stur            d0, [x0, #7]
    // 0xbec360: stp             x2, x1, [SP, #-0x10]!
    // 0xbec364: SaveReg r0
    //     0xbec364: str             x0, [SP, #-8]!
    // 0xbec368: r0 = lerp()
    //     0xbec368: bl              #0xbec39c  ; [dart:ui] Size::lerp
    // 0xbec36c: add             SP, SP, #0x18
    // 0xbec370: LeaveFrame
    //     0xbec370: mov             SP, fp
    //     0xbec374: ldp             fp, lr, [SP], #0x10
    // 0xbec378: ret
    //     0xbec378: ret             
    // 0xbec37c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec37c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec380: b               #0xbec320
    // 0xbec384: SaveReg d0
    //     0xbec384: str             q0, [SP, #-0x10]!
    // 0xbec388: stp             x1, x2, [SP, #-0x10]!
    // 0xbec38c: r0 = AllocateDouble()
    //     0xbec38c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbec390: ldp             x1, x2, [SP], #0x10
    // 0xbec394: RestoreReg d0
    //     0xbec394: ldr             q0, [SP], #0x10
    // 0xbec398: b               #0xbec35c
  }
}

// class id: 4275, size: 0x14, field offset: 0x14
class ColorTween extends Tween<Color?> {

  _ lerp(/* No info */) {
    // ** addr: 0xbec27c, size: 0x90
    // 0xbec27c: EnterFrame
    //     0xbec27c: stp             fp, lr, [SP, #-0x10]!
    //     0xbec280: mov             fp, SP
    // 0xbec284: CheckStackOverflow
    //     0xbec284: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbec288: cmp             SP, x16
    //     0xbec28c: b.ls            #0xbec2ec
    // 0xbec290: ldr             x0, [fp, #0x18]
    // 0xbec294: LoadField: r1 = r0->field_b
    //     0xbec294: ldur            w1, [x0, #0xb]
    // 0xbec298: DecompressPointer r1
    //     0xbec298: add             x1, x1, HEAP, lsl #32
    // 0xbec29c: LoadField: r2 = r0->field_f
    //     0xbec29c: ldur            w2, [x0, #0xf]
    // 0xbec2a0: DecompressPointer r2
    //     0xbec2a0: add             x2, x2, HEAP, lsl #32
    // 0xbec2a4: ldr             d0, [fp, #0x10]
    // 0xbec2a8: r0 = inline_Allocate_Double()
    //     0xbec2a8: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xbec2ac: add             x0, x0, #0x10
    //     0xbec2b0: cmp             x3, x0
    //     0xbec2b4: b.ls            #0xbec2f4
    //     0xbec2b8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbec2bc: sub             x0, x0, #0xf
    //     0xbec2c0: mov             x3, #0xd108
    //     0xbec2c4: movk            x3, #3, lsl #16
    //     0xbec2c8: stur            x3, [x0, #-1]
    // 0xbec2cc: StoreField: r0->field_7 = d0
    //     0xbec2cc: stur            d0, [x0, #7]
    // 0xbec2d0: stp             x2, x1, [SP, #-0x10]!
    // 0xbec2d4: SaveReg r0
    //     0xbec2d4: str             x0, [SP, #-8]!
    // 0xbec2d8: r0 = lerp()
    //     0xbec2d8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbec2dc: add             SP, SP, #0x18
    // 0xbec2e0: LeaveFrame
    //     0xbec2e0: mov             SP, fp
    //     0xbec2e4: ldp             fp, lr, [SP], #0x10
    // 0xbec2e8: ret
    //     0xbec2e8: ret             
    // 0xbec2ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec2ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec2f0: b               #0xbec290
    // 0xbec2f4: SaveReg d0
    //     0xbec2f4: str             q0, [SP, #-0x10]!
    // 0xbec2f8: stp             x1, x2, [SP, #-0x10]!
    // 0xbec2fc: r0 = AllocateDouble()
    //     0xbec2fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbec300: ldp             x1, x2, [SP], #0x10
    // 0xbec304: RestoreReg d0
    //     0xbec304: ldr             q0, [SP], #0x10
    // 0xbec308: b               #0xbec2cc
  }
}

// class id: 4276, size: 0x18, field offset: 0x14
class ReverseTween<X0> extends Tween<X0> {

  _ lerp(/* No info */) {
    // ** addr: 0xbec21c, size: 0x60
    // 0xbec21c: EnterFrame
    //     0xbec21c: stp             fp, lr, [SP, #-0x10]!
    //     0xbec220: mov             fp, SP
    // 0xbec224: d0 = 1.000000
    //     0xbec224: fmov            d0, #1.00000000
    // 0xbec228: CheckStackOverflow
    //     0xbec228: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbec22c: cmp             SP, x16
    //     0xbec230: b.ls            #0xbec274
    // 0xbec234: ldr             x0, [fp, #0x18]
    // 0xbec238: LoadField: r1 = r0->field_13
    //     0xbec238: ldur            w1, [x0, #0x13]
    // 0xbec23c: DecompressPointer r1
    //     0xbec23c: add             x1, x1, HEAP, lsl #32
    // 0xbec240: ldr             d1, [fp, #0x10]
    // 0xbec244: fsub            d2, d0, d1
    // 0xbec248: r0 = LoadClassIdInstr(r1)
    //     0xbec248: ldur            x0, [x1, #-1]
    //     0xbec24c: ubfx            x0, x0, #0xc, #0x14
    // 0xbec250: SaveReg r1
    //     0xbec250: str             x1, [SP, #-8]!
    // 0xbec254: SaveReg d2
    //     0xbec254: str             d2, [SP, #-8]!
    // 0xbec258: r0 = GDT[cid_x0 + 0xfcc]()
    //     0xbec258: add             lr, x0, #0xfcc
    //     0xbec25c: ldr             lr, [x21, lr, lsl #3]
    //     0xbec260: blr             lr
    // 0xbec264: add             SP, SP, #0x10
    // 0xbec268: LeaveFrame
    //     0xbec268: mov             SP, fp
    //     0xbec26c: ldp             fp, lr, [SP], #0x10
    // 0xbec270: ret
    //     0xbec270: ret             
    // 0xbec274: r0 = StackOverflowSharedWithFPURegs()
    //     0xbec274: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbec278: b               #0xbec234
  }
}

// class id: 4277, size: 0x14, field offset: 0xc
class _ChainedEvaluation<X0> extends Animatable<X0> {

  _ toString(/* No info */) {
    // ** addr: 0xad5dac, size: 0x7c
    // 0xad5dac: EnterFrame
    //     0xad5dac: stp             fp, lr, [SP, #-0x10]!
    //     0xad5db0: mov             fp, SP
    // 0xad5db4: AllocStack(0x8)
    //     0xad5db4: sub             SP, SP, #8
    // 0xad5db8: CheckStackOverflow
    //     0xad5db8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5dbc: cmp             SP, x16
    //     0xad5dc0: b.ls            #0xad5e20
    // 0xad5dc4: ldr             x0, [fp, #0x10]
    // 0xad5dc8: LoadField: r3 = r0->field_b
    //     0xad5dc8: ldur            w3, [x0, #0xb]
    // 0xad5dcc: DecompressPointer r3
    //     0xad5dcc: add             x3, x3, HEAP, lsl #32
    // 0xad5dd0: stur            x3, [fp, #-8]
    // 0xad5dd4: r1 = Null
    //     0xad5dd4: mov             x1, NULL
    // 0xad5dd8: r2 = 6
    //     0xad5dd8: mov             x2, #6
    // 0xad5ddc: r0 = AllocateArray()
    //     0xad5ddc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5de0: mov             x1, x0
    // 0xad5de4: ldur            x0, [fp, #-8]
    // 0xad5de8: StoreField: r1->field_f = r0
    //     0xad5de8: stur            w0, [x1, #0xf]
    // 0xad5dec: r17 = "➩"
    //     0xad5dec: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad5df0: ldr             x17, [x17, #0x1a0]
    // 0xad5df4: StoreField: r1->field_13 = r17
    //     0xad5df4: stur            w17, [x1, #0x13]
    // 0xad5df8: ldr             x0, [fp, #0x10]
    // 0xad5dfc: LoadField: r2 = r0->field_f
    //     0xad5dfc: ldur            w2, [x0, #0xf]
    // 0xad5e00: DecompressPointer r2
    //     0xad5e00: add             x2, x2, HEAP, lsl #32
    // 0xad5e04: StoreField: r1->field_17 = r2
    //     0xad5e04: stur            w2, [x1, #0x17]
    // 0xad5e08: SaveReg r1
    //     0xad5e08: str             x1, [SP, #-8]!
    // 0xad5e0c: r0 = _interpolate()
    //     0xad5e0c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5e10: add             SP, SP, #8
    // 0xad5e14: LeaveFrame
    //     0xad5e14: mov             SP, fp
    //     0xad5e18: ldp             fp, lr, [SP], #0x10
    // 0xad5e1c: ret
    //     0xad5e1c: ret             
    // 0xad5e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5e20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5e24: b               #0xad5dc4
  }
  _ transform(/* No info */) {
    // ** addr: 0xc09c98, size: 0x94
    // 0xc09c98: EnterFrame
    //     0xc09c98: stp             fp, lr, [SP, #-0x10]!
    //     0xc09c9c: mov             fp, SP
    // 0xc09ca0: AllocStack(0x8)
    //     0xc09ca0: sub             SP, SP, #8
    // 0xc09ca4: CheckStackOverflow
    //     0xc09ca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc09ca8: cmp             SP, x16
    //     0xc09cac: b.ls            #0xc09d24
    // 0xc09cb0: ldr             x0, [fp, #0x18]
    // 0xc09cb4: LoadField: r1 = r0->field_f
    //     0xc09cb4: ldur            w1, [x0, #0xf]
    // 0xc09cb8: DecompressPointer r1
    //     0xc09cb8: add             x1, x1, HEAP, lsl #32
    // 0xc09cbc: stur            x1, [fp, #-8]
    // 0xc09cc0: LoadField: r2 = r0->field_b
    //     0xc09cc0: ldur            w2, [x0, #0xb]
    // 0xc09cc4: DecompressPointer r2
    //     0xc09cc4: add             x2, x2, HEAP, lsl #32
    // 0xc09cc8: r0 = LoadClassIdInstr(r2)
    //     0xc09cc8: ldur            x0, [x2, #-1]
    //     0xc09ccc: ubfx            x0, x0, #0xc, #0x14
    // 0xc09cd0: SaveReg r2
    //     0xc09cd0: str             x2, [SP, #-8]!
    // 0xc09cd4: ldr             d0, [fp, #0x10]
    // 0xc09cd8: SaveReg d0
    //     0xc09cd8: str             d0, [SP, #-8]!
    // 0xc09cdc: r0 = GDT[cid_x0 + 0xd31]()
    //     0xc09cdc: add             lr, x0, #0xd31
    //     0xc09ce0: ldr             lr, [x21, lr, lsl #3]
    //     0xc09ce4: blr             lr
    // 0xc09ce8: add             SP, SP, #0x10
    // 0xc09cec: LoadField: d0 = r0->field_7
    //     0xc09cec: ldur            d0, [x0, #7]
    // 0xc09cf0: ldur            x0, [fp, #-8]
    // 0xc09cf4: r1 = LoadClassIdInstr(r0)
    //     0xc09cf4: ldur            x1, [x0, #-1]
    //     0xc09cf8: ubfx            x1, x1, #0xc, #0x14
    // 0xc09cfc: SaveReg r0
    //     0xc09cfc: str             x0, [SP, #-8]!
    // 0xc09d00: SaveReg d0
    //     0xc09d00: str             d0, [SP, #-8]!
    // 0xc09d04: mov             x0, x1
    // 0xc09d08: r0 = GDT[cid_x0 + 0xd31]()
    //     0xc09d08: add             lr, x0, #0xd31
    //     0xc09d0c: ldr             lr, [x21, lr, lsl #3]
    //     0xc09d10: blr             lr
    // 0xc09d14: add             SP, SP, #0x10
    // 0xc09d18: LeaveFrame
    //     0xc09d18: mov             SP, fp
    //     0xc09d1c: ldp             fp, lr, [SP], #0x10
    // 0xc09d20: ret
    //     0xc09d20: ret             
    // 0xc09d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc09d24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc09d28: b               #0xc09cb0
  }
}

// class id: 4328, size: 0xc, field offset: 0xc
//   const constructor, transformed mixin,
abstract class __AnimatedEvaluation&Animation&AnimationWithParentMixin<X0> extends Animation<X0>
     with AnimationWithParentMixin<X0> {

  _ addListener(/* No info */) {
    // ** addr: 0x6e954c, size: 0x58
    // 0x6e954c: EnterFrame
    //     0x6e954c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9550: mov             fp, SP
    // 0x6e9554: CheckStackOverflow
    //     0x6e9554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9558: cmp             SP, x16
    //     0x6e955c: b.ls            #0x6e959c
    // 0x6e9560: ldr             x0, [fp, #0x18]
    // 0x6e9564: LoadField: r1 = r0->field_b
    //     0x6e9564: ldur            w1, [x0, #0xb]
    // 0x6e9568: DecompressPointer r1
    //     0x6e9568: add             x1, x1, HEAP, lsl #32
    // 0x6e956c: r0 = LoadClassIdInstr(r1)
    //     0x6e956c: ldur            x0, [x1, #-1]
    //     0x6e9570: ubfx            x0, x0, #0xc, #0x14
    // 0x6e9574: ldr             x16, [fp, #0x10]
    // 0x6e9578: stp             x16, x1, [SP, #-0x10]!
    // 0x6e957c: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6e957c: mov             x17, #0xc3ab
    //     0x6e9580: add             lr, x0, x17
    //     0x6e9584: ldr             lr, [x21, lr, lsl #3]
    //     0x6e9588: blr             lr
    // 0x6e958c: add             SP, SP, #0x10
    // 0x6e9590: LeaveFrame
    //     0x6e9590: mov             SP, fp
    //     0x6e9594: ldp             fp, lr, [SP], #0x10
    // 0x6e9598: ret
    //     0x6e9598: ret             
    // 0x6e959c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e959c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e95a0: b               #0x6e9560
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6f61cc, size: 0x58
    // 0x6f61cc: EnterFrame
    //     0x6f61cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6f61d0: mov             fp, SP
    // 0x6f61d4: CheckStackOverflow
    //     0x6f61d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f61d8: cmp             SP, x16
    //     0x6f61dc: b.ls            #0x6f621c
    // 0x6f61e0: ldr             x0, [fp, #0x18]
    // 0x6f61e4: LoadField: r1 = r0->field_b
    //     0x6f61e4: ldur            w1, [x0, #0xb]
    // 0x6f61e8: DecompressPointer r1
    //     0x6f61e8: add             x1, x1, HEAP, lsl #32
    // 0x6f61ec: r0 = LoadClassIdInstr(r1)
    //     0x6f61ec: ldur            x0, [x1, #-1]
    //     0x6f61f0: ubfx            x0, x0, #0xc, #0x14
    // 0x6f61f4: ldr             x16, [fp, #0x10]
    // 0x6f61f8: stp             x16, x1, [SP, #-0x10]!
    // 0x6f61fc: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6f61fc: mov             x17, #0xc2d6
    //     0x6f6200: add             lr, x0, x17
    //     0x6f6204: ldr             lr, [x21, lr, lsl #3]
    //     0x6f6208: blr             lr
    // 0x6f620c: add             SP, SP, #0x10
    // 0x6f6210: LeaveFrame
    //     0x6f6210: mov             SP, fp
    //     0x6f6214: ldp             fp, lr, [SP], #0x10
    // 0x6f6218: ret
    //     0x6f6218: ret             
    // 0x6f621c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f621c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f6220: b               #0x6f61e0
  }
  _ addStatusListener(/* No info */) {
    // ** addr: 0xc530f8, size: 0x54
    // 0xc530f8: EnterFrame
    //     0xc530f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc530fc: mov             fp, SP
    // 0xc53100: CheckStackOverflow
    //     0xc53100: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc53104: cmp             SP, x16
    //     0xc53108: b.ls            #0xc53144
    // 0xc5310c: ldr             x0, [fp, #0x18]
    // 0xc53110: LoadField: r1 = r0->field_b
    //     0xc53110: ldur            w1, [x0, #0xb]
    // 0xc53114: DecompressPointer r1
    //     0xc53114: add             x1, x1, HEAP, lsl #32
    // 0xc53118: r0 = LoadClassIdInstr(r1)
    //     0xc53118: ldur            x0, [x1, #-1]
    //     0xc5311c: ubfx            x0, x0, #0xc, #0x14
    // 0xc53120: ldr             x16, [fp, #0x10]
    // 0xc53124: stp             x16, x1, [SP, #-0x10]!
    // 0xc53128: r0 = GDT[cid_x0 + 0x80c]()
    //     0xc53128: add             lr, x0, #0x80c
    //     0xc5312c: ldr             lr, [x21, lr, lsl #3]
    //     0xc53130: blr             lr
    // 0xc53134: add             SP, SP, #0x10
    // 0xc53138: LeaveFrame
    //     0xc53138: mov             SP, fp
    //     0xc5313c: ldp             fp, lr, [SP], #0x10
    // 0xc53140: ret
    //     0xc53140: ret             
    // 0xc53144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc53144: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc53148: b               #0xc5310c
  }
  _ removeStatusListener(/* No info */) {
    // ** addr: 0xc5e070, size: 0x54
    // 0xc5e070: EnterFrame
    //     0xc5e070: stp             fp, lr, [SP, #-0x10]!
    //     0xc5e074: mov             fp, SP
    // 0xc5e078: CheckStackOverflow
    //     0xc5e078: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5e07c: cmp             SP, x16
    //     0xc5e080: b.ls            #0xc5e0bc
    // 0xc5e084: ldr             x0, [fp, #0x18]
    // 0xc5e088: LoadField: r1 = r0->field_b
    //     0xc5e088: ldur            w1, [x0, #0xb]
    // 0xc5e08c: DecompressPointer r1
    //     0xc5e08c: add             x1, x1, HEAP, lsl #32
    // 0xc5e090: r0 = LoadClassIdInstr(r1)
    //     0xc5e090: ldur            x0, [x1, #-1]
    //     0xc5e094: ubfx            x0, x0, #0xc, #0x14
    // 0xc5e098: ldr             x16, [fp, #0x10]
    // 0xc5e09c: stp             x16, x1, [SP, #-0x10]!
    // 0xc5e0a0: r0 = GDT[cid_x0 + 0x490]()
    //     0xc5e0a0: add             lr, x0, #0x490
    //     0xc5e0a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc5e0a8: blr             lr
    // 0xc5e0ac: add             SP, SP, #0x10
    // 0xc5e0b0: LeaveFrame
    //     0xc5e0b0: mov             SP, fp
    //     0xc5e0b4: ldp             fp, lr, [SP], #0x10
    // 0xc5e0b8: ret
    //     0xc5e0b8: ret             
    // 0xc5e0bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5e0bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5e0c0: b               #0xc5e084
  }
  get _ status(/* No info */) {
    // ** addr: 0xc649e4, size: 0x50
    // 0xc649e4: EnterFrame
    //     0xc649e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc649e8: mov             fp, SP
    // 0xc649ec: CheckStackOverflow
    //     0xc649ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc649f0: cmp             SP, x16
    //     0xc649f4: b.ls            #0xc64a2c
    // 0xc649f8: ldr             x0, [fp, #0x10]
    // 0xc649fc: LoadField: r1 = r0->field_b
    //     0xc649fc: ldur            w1, [x0, #0xb]
    // 0xc64a00: DecompressPointer r1
    //     0xc64a00: add             x1, x1, HEAP, lsl #32
    // 0xc64a04: r0 = LoadClassIdInstr(r1)
    //     0xc64a04: ldur            x0, [x1, #-1]
    //     0xc64a08: ubfx            x0, x0, #0xc, #0x14
    // 0xc64a0c: SaveReg r1
    //     0xc64a0c: str             x1, [SP, #-8]!
    // 0xc64a10: r0 = GDT[cid_x0 + 0x376]()
    //     0xc64a10: add             lr, x0, #0x376
    //     0xc64a14: ldr             lr, [x21, lr, lsl #3]
    //     0xc64a18: blr             lr
    // 0xc64a1c: add             SP, SP, #8
    // 0xc64a20: LeaveFrame
    //     0xc64a20: mov             SP, fp
    //     0xc64a24: ldp             fp, lr, [SP], #0x10
    // 0xc64a28: ret
    //     0xc64a28: ret             
    // 0xc64a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc64a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64a30: b               #0xc649f8
  }
}

// class id: 4329, size: 0x14, field offset: 0xc
class _AnimatedEvaluation<X0> extends __AnimatedEvaluation&Animation&AnimationWithParentMixin<X0> {

  _ toString(/* No info */) {
    // ** addr: 0xad4bd8, size: 0xc4
    // 0xad4bd8: EnterFrame
    //     0xad4bd8: stp             fp, lr, [SP, #-0x10]!
    //     0xad4bdc: mov             fp, SP
    // 0xad4be0: AllocStack(0x10)
    //     0xad4be0: sub             SP, SP, #0x10
    // 0xad4be4: CheckStackOverflow
    //     0xad4be4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4be8: cmp             SP, x16
    //     0xad4bec: b.ls            #0xad4c94
    // 0xad4bf0: ldr             x0, [fp, #0x10]
    // 0xad4bf4: LoadField: r3 = r0->field_b
    //     0xad4bf4: ldur            w3, [x0, #0xb]
    // 0xad4bf8: DecompressPointer r3
    //     0xad4bf8: add             x3, x3, HEAP, lsl #32
    // 0xad4bfc: stur            x3, [fp, #-8]
    // 0xad4c00: r1 = Null
    //     0xad4c00: mov             x1, NULL
    // 0xad4c04: r2 = 10
    //     0xad4c04: mov             x2, #0xa
    // 0xad4c08: r0 = AllocateArray()
    //     0xad4c08: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4c0c: mov             x1, x0
    // 0xad4c10: ldur            x0, [fp, #-8]
    // 0xad4c14: stur            x1, [fp, #-0x10]
    // 0xad4c18: StoreField: r1->field_f = r0
    //     0xad4c18: stur            w0, [x1, #0xf]
    // 0xad4c1c: r17 = "➩"
    //     0xad4c1c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad4c20: ldr             x17, [x17, #0x1a0]
    // 0xad4c24: StoreField: r1->field_13 = r17
    //     0xad4c24: stur            w17, [x1, #0x13]
    // 0xad4c28: ldr             x0, [fp, #0x10]
    // 0xad4c2c: LoadField: r2 = r0->field_f
    //     0xad4c2c: ldur            w2, [x0, #0xf]
    // 0xad4c30: DecompressPointer r2
    //     0xad4c30: add             x2, x2, HEAP, lsl #32
    // 0xad4c34: StoreField: r1->field_17 = r2
    //     0xad4c34: stur            w2, [x1, #0x17]
    // 0xad4c38: r17 = "➩"
    //     0xad4c38: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d1a0] "➩"
    //     0xad4c3c: ldr             x17, [x17, #0x1a0]
    // 0xad4c40: StoreField: r1->field_1b = r17
    //     0xad4c40: stur            w17, [x1, #0x1b]
    // 0xad4c44: SaveReg r0
    //     0xad4c44: str             x0, [SP, #-8]!
    // 0xad4c48: r0 = value()
    //     0xad4c48: bl              #0xc251f8  ; [package:flutter/src/animation/tween.dart] _AnimatedEvaluation::value
    // 0xad4c4c: add             SP, SP, #8
    // 0xad4c50: ldur            x1, [fp, #-0x10]
    // 0xad4c54: ArrayStore: r1[4] = r0  ; List_4
    //     0xad4c54: add             x25, x1, #0x1f
    //     0xad4c58: str             w0, [x25]
    //     0xad4c5c: tbz             w0, #0, #0xad4c78
    //     0xad4c60: ldurb           w16, [x1, #-1]
    //     0xad4c64: ldurb           w17, [x0, #-1]
    //     0xad4c68: and             x16, x17, x16, lsr #2
    //     0xad4c6c: tst             x16, HEAP, lsr #32
    //     0xad4c70: b.eq            #0xad4c78
    //     0xad4c74: bl              #0xd67e5c
    // 0xad4c78: ldur            x16, [fp, #-0x10]
    // 0xad4c7c: SaveReg r16
    //     0xad4c7c: str             x16, [SP, #-8]!
    // 0xad4c80: r0 = _interpolate()
    //     0xad4c80: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad4c84: add             SP, SP, #8
    // 0xad4c88: LeaveFrame
    //     0xad4c88: mov             SP, fp
    //     0xad4c8c: ldp             fp, lr, [SP], #0x10
    // 0xad4c90: ret
    //     0xad4c90: ret             
    // 0xad4c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad4c94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad4c98: b               #0xad4bf0
  }
  _ toStringDetails(/* No info */) {
    // ** addr: 0xbea308, size: 0x7c
    // 0xbea308: EnterFrame
    //     0xbea308: stp             fp, lr, [SP, #-0x10]!
    //     0xbea30c: mov             fp, SP
    // 0xbea310: AllocStack(0x8)
    //     0xbea310: sub             SP, SP, #8
    // 0xbea314: CheckStackOverflow
    //     0xbea314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbea318: cmp             SP, x16
    //     0xbea31c: b.ls            #0xbea37c
    // 0xbea320: ldr             x16, [fp, #0x10]
    // 0xbea324: SaveReg r16
    //     0xbea324: str             x16, [SP, #-8]!
    // 0xbea328: r0 = toStringDetails()
    //     0xbea328: bl              #0xbea25c  ; [package:flutter/src/animation/animation.dart] Animation::toStringDetails
    // 0xbea32c: add             SP, SP, #8
    // 0xbea330: r1 = Null
    //     0xbea330: mov             x1, NULL
    // 0xbea334: r2 = 6
    //     0xbea334: mov             x2, #6
    // 0xbea338: stur            x0, [fp, #-8]
    // 0xbea33c: r0 = AllocateArray()
    //     0xbea33c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xbea340: mov             x1, x0
    // 0xbea344: ldur            x0, [fp, #-8]
    // 0xbea348: StoreField: r1->field_f = r0
    //     0xbea348: stur            w0, [x1, #0xf]
    // 0xbea34c: r17 = " "
    //     0xbea34c: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xbea350: StoreField: r1->field_13 = r17
    //     0xbea350: stur            w17, [x1, #0x13]
    // 0xbea354: ldr             x0, [fp, #0x10]
    // 0xbea358: LoadField: r2 = r0->field_f
    //     0xbea358: ldur            w2, [x0, #0xf]
    // 0xbea35c: DecompressPointer r2
    //     0xbea35c: add             x2, x2, HEAP, lsl #32
    // 0xbea360: StoreField: r1->field_17 = r2
    //     0xbea360: stur            w2, [x1, #0x17]
    // 0xbea364: SaveReg r1
    //     0xbea364: str             x1, [SP, #-8]!
    // 0xbea368: r0 = _interpolate()
    //     0xbea368: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xbea36c: add             SP, SP, #8
    // 0xbea370: LeaveFrame
    //     0xbea370: mov             SP, fp
    //     0xbea374: ldp             fp, lr, [SP], #0x10
    // 0xbea378: ret
    //     0xbea378: ret             
    // 0xbea37c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbea37c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbea380: b               #0xbea320
  }
  get _ value(/* No info */) {
    // ** addr: 0xc251f8, size: 0x48
    // 0xc251f8: EnterFrame
    //     0xc251f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc251fc: mov             fp, SP
    // 0xc25200: CheckStackOverflow
    //     0xc25200: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc25204: cmp             SP, x16
    //     0xc25208: b.ls            #0xc25238
    // 0xc2520c: ldr             x0, [fp, #0x10]
    // 0xc25210: LoadField: r1 = r0->field_f
    //     0xc25210: ldur            w1, [x0, #0xf]
    // 0xc25214: DecompressPointer r1
    //     0xc25214: add             x1, x1, HEAP, lsl #32
    // 0xc25218: LoadField: r2 = r0->field_b
    //     0xc25218: ldur            w2, [x0, #0xb]
    // 0xc2521c: DecompressPointer r2
    //     0xc2521c: add             x2, x2, HEAP, lsl #32
    // 0xc25220: stp             x2, x1, [SP, #-0x10]!
    // 0xc25224: r0 = evaluate()
    //     0xc25224: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xc25228: add             SP, SP, #0x10
    // 0xc2522c: LeaveFrame
    //     0xc2522c: mov             SP, fp
    //     0xc25230: ldp             fp, lr, [SP], #0x10
    // 0xc25234: ret
    //     0xc25234: ret             
    // 0xc25238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc25238: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2523c: b               #0xc2520c
  }
}

// lib: , url: package:flutter/src/animation/curves.dart

// class id: 1049069, size: 0x8
class :: {
}

// class id: 4278, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ParametricCurve<X0> extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad5cc8, size: 0xc
    // 0xad5cc8: r0 = "ParametricCurve"
    //     0xad5cc8: add             x0, PP, #0xc, lsl #12  ; [pp+0xc798] "ParametricCurve"
    //     0xad5ccc: ldr             x0, [x0, #0x798]
    // 0xad5cd0: ret
    //     0xad5cd0: ret             
  }
  _ transform(/* No info */) {
    // ** addr: 0xc50550, size: 0x54
    // 0xc50550: EnterFrame
    //     0xc50550: stp             fp, lr, [SP, #-0x10]!
    //     0xc50554: mov             fp, SP
    // 0xc50558: CheckStackOverflow
    //     0xc50558: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5055c: cmp             SP, x16
    //     0xc50560: b.ls            #0xc5059c
    // 0xc50564: ldr             x0, [fp, #0x18]
    // 0xc50568: r1 = LoadClassIdInstr(r0)
    //     0xc50568: ldur            x1, [x0, #-1]
    //     0xc5056c: ubfx            x1, x1, #0xc, #0x14
    // 0xc50570: SaveReg r0
    //     0xc50570: str             x0, [SP, #-8]!
    // 0xc50574: ldr             d0, [fp, #0x10]
    // 0xc50578: SaveReg d0
    //     0xc50578: str             d0, [SP, #-8]!
    // 0xc5057c: mov             x0, x1
    // 0xc50580: r0 = GDT[cid_x0 + 0xfdd]()
    //     0xc50580: add             lr, x0, #0xfdd
    //     0xc50584: ldr             lr, [x21, lr, lsl #3]
    //     0xc50588: blr             lr
    // 0xc5058c: add             SP, SP, #0x10
    // 0xc50590: LeaveFrame
    //     0xc50590: mov             SP, fp
    //     0xc50594: ldp             fp, lr, [SP], #0x10
    // 0xc50598: ret
    //     0xc50598: ret             
    // 0xc5059c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5059c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc505a0: b               #0xc50564
  }
}

// class id: 4281, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class Curve extends ParametricCurve<double> {

  get _ flipped(/* No info */) {
    // ** addr: 0x7ba1c8, size: 0x24
    // 0x7ba1c8: EnterFrame
    //     0x7ba1c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba1cc: mov             fp, SP
    // 0x7ba1d0: r1 = <double>
    //     0x7ba1d0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba1d4: r0 = FlippedCurve()
    //     0x7ba1d4: bl              #0x7ba1ec  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0x7ba1d8: ldr             x1, [fp, #0x10]
    // 0x7ba1dc: StoreField: r0->field_b = r1
    //     0x7ba1dc: stur            w1, [x0, #0xb]
    // 0x7ba1e0: LeaveFrame
    //     0x7ba1e0: mov             SP, fp
    //     0x7ba1e4: ldp             fp, lr, [SP], #0x10
    // 0x7ba1e8: ret
    //     0x7ba1e8: ret             
  }
  _ transform(/* No info */) {
    // ** addr: 0xc504ac, size: 0xa4
    // 0xc504ac: EnterFrame
    //     0xc504ac: stp             fp, lr, [SP, #-0x10]!
    //     0xc504b0: mov             fp, SP
    // 0xc504b4: d0 = 0.000000
    //     0xc504b4: eor             v0.16b, v0.16b, v0.16b
    // 0xc504b8: CheckStackOverflow
    //     0xc504b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc504bc: cmp             SP, x16
    //     0xc504c0: b.ls            #0xc50538
    // 0xc504c4: ldr             d1, [fp, #0x10]
    // 0xc504c8: fcmp            d1, d0
    // 0xc504cc: b.vs            #0xc504d4
    // 0xc504d0: b.eq            #0xc504e4
    // 0xc504d4: d0 = 1.000000
    //     0xc504d4: fmov            d0, #1.00000000
    // 0xc504d8: fcmp            d1, d0
    // 0xc504dc: b.vs            #0xc50518
    // 0xc504e0: b.ne            #0xc50518
    // 0xc504e4: r0 = inline_Allocate_Double()
    //     0xc504e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc504e8: add             x0, x0, #0x10
    //     0xc504ec: cmp             x1, x0
    //     0xc504f0: b.ls            #0xc50540
    //     0xc504f4: str             x0, [THR, #0x60]  ; THR::top
    //     0xc504f8: sub             x0, x0, #0xf
    //     0xc504fc: mov             x1, #0xd108
    //     0xc50500: movk            x1, #3, lsl #16
    //     0xc50504: stur            x1, [x0, #-1]
    // 0xc50508: StoreField: r0->field_7 = d1
    //     0xc50508: stur            d1, [x0, #7]
    // 0xc5050c: LeaveFrame
    //     0xc5050c: mov             SP, fp
    //     0xc50510: ldp             fp, lr, [SP], #0x10
    // 0xc50514: ret
    //     0xc50514: ret             
    // 0xc50518: ldr             x16, [fp, #0x18]
    // 0xc5051c: SaveReg r16
    //     0xc5051c: str             x16, [SP, #-8]!
    // 0xc50520: SaveReg d1
    //     0xc50520: str             d1, [SP, #-8]!
    // 0xc50524: r0 = transform()
    //     0xc50524: bl              #0xc50550  ; [package:flutter/src/animation/curves.dart] ParametricCurve::transform
    // 0xc50528: add             SP, SP, #0x10
    // 0xc5052c: LeaveFrame
    //     0xc5052c: mov             SP, fp
    //     0xc50530: ldp             fp, lr, [SP], #0x10
    // 0xc50534: ret
    //     0xc50534: ret             
    // 0xc50538: r0 = StackOverflowSharedWithFPURegs()
    //     0xc50538: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc5053c: b               #0xc504c4
    // 0xc50540: SaveReg d1
    //     0xc50540: str             q1, [SP, #-0x10]!
    // 0xc50544: r0 = AllocateDouble()
    //     0xc50544: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc50548: RestoreReg d1
    //     0xc50548: ldr             q1, [SP], #0x10
    // 0xc5054c: b               #0xc50508
  }
}

// class id: 4284, size: 0x14, field offset: 0xc
//   const constructor, 
class ElasticOutCurve extends Curve {

  _Double field_c;

  _ toString(/* No info */) {
    // ** addr: 0xad5b70, size: 0xac
    // 0xad5b70: EnterFrame
    //     0xad5b70: stp             fp, lr, [SP, #-0x10]!
    //     0xad5b74: mov             fp, SP
    // 0xad5b78: CheckStackOverflow
    //     0xad5b78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5b7c: cmp             SP, x16
    //     0xad5b80: b.ls            #0xad5bf8
    // 0xad5b84: r1 = Null
    //     0xad5b84: mov             x1, NULL
    // 0xad5b88: r2 = 8
    //     0xad5b88: mov             x2, #8
    // 0xad5b8c: r0 = AllocateArray()
    //     0xad5b8c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5b90: r17 = "ElasticOutCurve"
    //     0xad5b90: add             x17, PP, #0x37, lsl #12  ; [pp+0x37d58] "ElasticOutCurve"
    //     0xad5b94: ldr             x17, [x17, #0xd58]
    // 0xad5b98: StoreField: r0->field_f = r17
    //     0xad5b98: stur            w17, [x0, #0xf]
    // 0xad5b9c: r17 = "("
    //     0xad5b9c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad5ba0: StoreField: r0->field_13 = r17
    //     0xad5ba0: stur            w17, [x0, #0x13]
    // 0xad5ba4: ldr             x1, [fp, #0x10]
    // 0xad5ba8: LoadField: d0 = r1->field_b
    //     0xad5ba8: ldur            d0, [x1, #0xb]
    // 0xad5bac: r1 = inline_Allocate_Double()
    //     0xad5bac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xad5bb0: add             x1, x1, #0x10
    //     0xad5bb4: cmp             x2, x1
    //     0xad5bb8: b.ls            #0xad5c00
    //     0xad5bbc: str             x1, [THR, #0x60]  ; THR::top
    //     0xad5bc0: sub             x1, x1, #0xf
    //     0xad5bc4: mov             x2, #0xd108
    //     0xad5bc8: movk            x2, #3, lsl #16
    //     0xad5bcc: stur            x2, [x1, #-1]
    // 0xad5bd0: StoreField: r1->field_7 = d0
    //     0xad5bd0: stur            d0, [x1, #7]
    // 0xad5bd4: StoreField: r0->field_17 = r1
    //     0xad5bd4: stur            w1, [x0, #0x17]
    // 0xad5bd8: r17 = ")"
    //     0xad5bd8: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad5bdc: StoreField: r0->field_1b = r17
    //     0xad5bdc: stur            w17, [x0, #0x1b]
    // 0xad5be0: SaveReg r0
    //     0xad5be0: str             x0, [SP, #-8]!
    // 0xad5be4: r0 = _interpolate()
    //     0xad5be4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5be8: add             SP, SP, #8
    // 0xad5bec: LeaveFrame
    //     0xad5bec: mov             SP, fp
    //     0xad5bf0: ldp             fp, lr, [SP], #0x10
    // 0xad5bf4: ret
    //     0xad5bf4: ret             
    // 0xad5bf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5bf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5bfc: b               #0xad5b84
    // 0xad5c00: SaveReg d0
    //     0xad5c00: str             q0, [SP, #-0x10]!
    // 0xad5c04: SaveReg r0
    //     0xad5c04: str             x0, [SP, #-8]!
    // 0xad5c08: r0 = AllocateDouble()
    //     0xad5c08: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad5c0c: mov             x1, x0
    // 0xad5c10: RestoreReg r0
    //     0xad5c10: ldr             x0, [SP], #8
    // 0xad5c14: RestoreReg d0
    //     0xad5c14: ldr             q0, [SP], #0x10
    // 0xad5c18: b               #0xad5bd0
  }
  _ transformInternal(/* No info */) {
    // ** addr: 0xbeb614, size: 0x1b0
    // 0xbeb614: EnterFrame
    //     0xbeb614: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb618: mov             fp, SP
    // 0xbeb61c: AllocStack(0x8)
    //     0xbeb61c: sub             SP, SP, #8
    // 0xbeb620: d0 = -10.000000
    //     0xbeb620: fmov            d0, #-10.00000000
    // 0xbeb624: ldr             d2, [fp, #0x10]
    // 0xbeb628: fmul            d1, d0, d2
    // 0xbeb62c: d0 = 2.000000
    //     0xbeb62c: fmov            d0, #2.00000000
    // 0xbeb630: d30 = 0.000000
    //     0xbeb630: fmov            d30, d0
    // 0xbeb634: d0 = 1.000000
    //     0xbeb634: fmov            d0, #1.00000000
    // 0xbeb638: fcmp            d1, #0.0
    // 0xbeb63c: b.vs            #0xbeb680
    // 0xbeb640: b.eq            #0xbeb708
    // 0xbeb644: fcmp            d1, d0
    // 0xbeb648: b.eq            #0xbeb670
    // 0xbeb64c: d31 = 2.000000
    //     0xbeb64c: fmov            d31, #2.00000000
    // 0xbeb650: fcmp            d1, d31
    // 0xbeb654: b.eq            #0xbeb678
    // 0xbeb658: d31 = 3.000000
    //     0xbeb658: fmov            d31, #3.00000000
    // 0xbeb65c: fcmp            d1, d31
    // 0xbeb660: b.ne            #0xbeb680
    // 0xbeb664: fmul            d0, d30, d30
    // 0xbeb668: fmul            d0, d0, d30
    // 0xbeb66c: b               #0xbeb708
    // 0xbeb670: d0 = 0.000000
    //     0xbeb670: fmov            d0, d30
    // 0xbeb674: b               #0xbeb708
    // 0xbeb678: fmul            d0, d30, d30
    // 0xbeb67c: b               #0xbeb708
    // 0xbeb680: fcmp            d30, d0
    // 0xbeb684: b.vs            #0xbeb694
    // 0xbeb688: b.eq            #0xbeb708
    // 0xbeb68c: fcmp            d30, d1
    // 0xbeb690: b.vc            #0xbeb6a0
    // 0xbeb694: d0 = nan
    //     0xbeb694: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xbeb698: ldr             d0, [x17, #0x240]
    // 0xbeb69c: b               #0xbeb708
    // 0xbeb6a0: d0 = -inf
    //     0xbeb6a0: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xbeb6a4: fcmp            d30, d0
    // 0xbeb6a8: b.eq            #0xbeb6d0
    // 0xbeb6ac: d0 = 0.500000
    //     0xbeb6ac: fmov            d0, #0.50000000
    // 0xbeb6b0: fcmp            d1, d0
    // 0xbeb6b4: b.ne            #0xbeb6d0
    // 0xbeb6b8: fcmp            d30, #0.0
    // 0xbeb6bc: b.eq            #0xbeb6c8
    // 0xbeb6c0: fsqrt           d0, d30
    // 0xbeb6c4: b               #0xbeb708
    // 0xbeb6c8: d0 = 0.000000
    //     0xbeb6c8: eor             v0.16b, v0.16b, v0.16b
    // 0xbeb6cc: b               #0xbeb708
    // 0xbeb6d0: d0 = 0.000000
    //     0xbeb6d0: fmov            d0, d30
    // 0xbeb6d4: stp             fp, lr, [SP, #-0x10]!
    // 0xbeb6d8: mov             fp, SP
    // 0xbeb6dc: CallRuntime_LibcPow(double, double) -> double
    //     0xbeb6dc: and             SP, SP, #0xfffffffffffffff0
    //     0xbeb6e0: mov             sp, SP
    //     0xbeb6e4: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xbeb6e8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeb6ec: blr             x16
    //     0xbeb6f0: mov             x16, #8
    //     0xbeb6f4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeb6f8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbeb6fc: sub             sp, x16, #1, lsl #12
    //     0xbeb700: mov             SP, fp
    //     0xbeb704: ldp             fp, lr, [SP], #0x10
    // 0xbeb708: mov             v2.16b, v0.16b
    // 0xbeb70c: ldr             d1, [fp, #0x10]
    // 0xbeb710: d0 = 0.100000
    //     0xbeb710: ldr             d0, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0xbeb714: stur            d2, [fp, #-8]
    // 0xbeb718: fsub            d3, d1, d0
    // 0xbeb71c: d0 = 6.283185
    //     0xbeb71c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37848] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0xbeb720: ldr             d0, [x17, #0x848]
    // 0xbeb724: fmul            d1, d3, d0
    // 0xbeb728: d0 = 0.400000
    //     0xbeb728: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0xbeb72c: ldr             d0, [x17, #0x148]
    // 0xbeb730: fdiv            d3, d1, d0
    // 0xbeb734: mov             v0.16b, v3.16b
    // 0xbeb738: stp             fp, lr, [SP, #-0x10]!
    // 0xbeb73c: mov             fp, SP
    // 0xbeb740: CallRuntime_LibcSin(double) -> double
    //     0xbeb740: and             SP, SP, #0xfffffffffffffff0
    //     0xbeb744: mov             sp, SP
    //     0xbeb748: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xbeb74c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeb750: blr             x16
    //     0xbeb754: mov             x16, #8
    //     0xbeb758: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeb75c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbeb760: sub             sp, x16, #1, lsl #12
    //     0xbeb764: mov             SP, fp
    //     0xbeb768: ldp             fp, lr, [SP], #0x10
    // 0xbeb76c: mov             v1.16b, v0.16b
    // 0xbeb770: ldur            d0, [fp, #-8]
    // 0xbeb774: fmul            d2, d0, d1
    // 0xbeb778: d0 = 1.000000
    //     0xbeb778: fmov            d0, #1.00000000
    // 0xbeb77c: fadd            d1, d2, d0
    // 0xbeb780: r0 = inline_Allocate_Double()
    //     0xbeb780: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeb784: add             x0, x0, #0x10
    //     0xbeb788: cmp             x1, x0
    //     0xbeb78c: b.ls            #0xbeb7b4
    //     0xbeb790: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeb794: sub             x0, x0, #0xf
    //     0xbeb798: mov             x1, #0xd108
    //     0xbeb79c: movk            x1, #3, lsl #16
    //     0xbeb7a0: stur            x1, [x0, #-1]
    // 0xbeb7a4: StoreField: r0->field_7 = d1
    //     0xbeb7a4: stur            d1, [x0, #7]
    // 0xbeb7a8: LeaveFrame
    //     0xbeb7a8: mov             SP, fp
    //     0xbeb7ac: ldp             fp, lr, [SP], #0x10
    // 0xbeb7b0: ret
    //     0xbeb7b0: ret             
    // 0xbeb7b4: SaveReg d1
    //     0xbeb7b4: str             q1, [SP, #-0x10]!
    // 0xbeb7b8: r0 = AllocateDouble()
    //     0xbeb7b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb7bc: RestoreReg d1
    //     0xbeb7bc: ldr             q1, [SP], #0x10
    // 0xbeb7c0: b               #0xbeb7a4
  }
}

// class id: 4285, size: 0xc, field offset: 0xc
//   const constructor, 
class _BounceOutCurve extends Curve {

  _ transformInternal(/* No info */) {
    // ** addr: 0xbeb4fc, size: 0x118
    // 0xbeb4fc: EnterFrame
    //     0xbeb4fc: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb500: mov             fp, SP
    // 0xbeb504: d0 = 0.363636
    //     0xbeb504: add             x17, PP, #0x40, lsl #12  ; [pp+0x405a8] IMM: double(0.36363636363636365) from 0x3fd745d1745d1746
    //     0xbeb508: ldr             d0, [x17, #0x5a8]
    // 0xbeb50c: ldr             d1, [fp, #0x10]
    // 0xbeb510: fcmp            d1, d0
    // 0xbeb514: b.vs            #0xbeb534
    // 0xbeb518: b.ge            #0xbeb534
    // 0xbeb51c: d0 = 7.562500
    //     0xbeb51c: add             x17, PP, #0x40, lsl #12  ; [pp+0x405b0] IMM: double(7.5625) from 0x401e400000000000
    //     0xbeb520: ldr             d0, [x17, #0x5b0]
    // 0xbeb524: fmul            d2, d0, d1
    // 0xbeb528: fmul            d3, d2, d1
    // 0xbeb52c: mov             v0.16b, v3.16b
    // 0xbeb530: b               #0xbeb5d0
    // 0xbeb534: d0 = 7.562500
    //     0xbeb534: add             x17, PP, #0x40, lsl #12  ; [pp+0x405b0] IMM: double(7.5625) from 0x401e400000000000
    //     0xbeb538: ldr             d0, [x17, #0x5b0]
    // 0xbeb53c: d2 = 0.727273
    //     0xbeb53c: add             x17, PP, #0x40, lsl #12  ; [pp+0x405b8] IMM: double(0.7272727272727273) from 0x3fe745d1745d1746
    //     0xbeb540: ldr             d2, [x17, #0x5b8]
    // 0xbeb544: fcmp            d1, d2
    // 0xbeb548: b.vs            #0xbeb574
    // 0xbeb54c: b.ge            #0xbeb574
    // 0xbeb550: d3 = 0.545455
    //     0xbeb550: add             x17, PP, #0x40, lsl #12  ; [pp+0x405c0] IMM: double(0.5454545454545454) from 0x3fe1745d1745d174
    //     0xbeb554: ldr             d3, [x17, #0x5c0]
    // 0xbeb558: d2 = 0.750000
    //     0xbeb558: fmov            d2, #0.75000000
    // 0xbeb55c: fsub            d4, d1, d3
    // 0xbeb560: fmul            d3, d0, d4
    // 0xbeb564: fmul            d5, d3, d4
    // 0xbeb568: fadd            d3, d5, d2
    // 0xbeb56c: mov             v0.16b, v3.16b
    // 0xbeb570: b               #0xbeb5d0
    // 0xbeb574: d2 = 0.909091
    //     0xbeb574: add             x17, PP, #0x40, lsl #12  ; [pp+0x405c8] IMM: double(0.9090909090909091) from 0x3fed1745d1745d17
    //     0xbeb578: ldr             d2, [x17, #0x5c8]
    // 0xbeb57c: fcmp            d1, d2
    // 0xbeb580: b.vs            #0xbeb5ac
    // 0xbeb584: b.ge            #0xbeb5ac
    // 0xbeb588: d3 = 0.818182
    //     0xbeb588: add             x17, PP, #0x40, lsl #12  ; [pp+0x405d0] IMM: double(0.8181818181818182) from 0x3fea2e8ba2e8ba2f
    //     0xbeb58c: ldr             d3, [x17, #0x5d0]
    // 0xbeb590: d2 = 0.937500
    //     0xbeb590: fmov            d2, #0.93750000
    // 0xbeb594: fsub            d4, d1, d3
    // 0xbeb598: fmul            d3, d0, d4
    // 0xbeb59c: fmul            d5, d3, d4
    // 0xbeb5a0: fadd            d3, d5, d2
    // 0xbeb5a4: mov             v0.16b, v3.16b
    // 0xbeb5a8: b               #0xbeb5d0
    // 0xbeb5ac: d3 = 0.954545
    //     0xbeb5ac: add             x17, PP, #0x40, lsl #12  ; [pp+0x405d8] IMM: double(0.9545454545454546) from 0x3fee8ba2e8ba2e8c
    //     0xbeb5b0: ldr             d3, [x17, #0x5d8]
    // 0xbeb5b4: d2 = 0.984375
    //     0xbeb5b4: add             x17, PP, #0x40, lsl #12  ; [pp+0x405e0] IMM: double(0.984375) from 0x3fef800000000000
    //     0xbeb5b8: ldr             d2, [x17, #0x5e0]
    // 0xbeb5bc: fsub            d4, d1, d3
    // 0xbeb5c0: fmul            d1, d0, d4
    // 0xbeb5c4: fmul            d0, d1, d4
    // 0xbeb5c8: fadd            d1, d0, d2
    // 0xbeb5cc: mov             v0.16b, v1.16b
    // 0xbeb5d0: r0 = inline_Allocate_Double()
    //     0xbeb5d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeb5d4: add             x0, x0, #0x10
    //     0xbeb5d8: cmp             x1, x0
    //     0xbeb5dc: b.ls            #0xbeb604
    //     0xbeb5e0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeb5e4: sub             x0, x0, #0xf
    //     0xbeb5e8: mov             x1, #0xd108
    //     0xbeb5ec: movk            x1, #3, lsl #16
    //     0xbeb5f0: stur            x1, [x0, #-1]
    // 0xbeb5f4: StoreField: r0->field_7 = d0
    //     0xbeb5f4: stur            d0, [x0, #7]
    // 0xbeb5f8: LeaveFrame
    //     0xbeb5f8: mov             SP, fp
    //     0xbeb5fc: ldp             fp, lr, [SP], #0x10
    // 0xbeb600: ret
    //     0xbeb600: ret             
    // 0xbeb604: SaveReg d0
    //     0xbeb604: str             q0, [SP, #-0x10]!
    // 0xbeb608: r0 = AllocateDouble()
    //     0xbeb608: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb60c: RestoreReg d0
    //     0xbeb60c: ldr             q0, [SP], #0x10
    // 0xbeb610: b               #0xbeb5f4
  }
}

// class id: 4286, size: 0xc, field offset: 0xc
//   const constructor, 
class _DecelerateCurve extends Curve {

  _ transformInternal(/* No info */) {
    // ** addr: 0xbeb49c, size: 0x60
    // 0xbeb49c: EnterFrame
    //     0xbeb49c: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb4a0: mov             fp, SP
    // 0xbeb4a4: d0 = 1.000000
    //     0xbeb4a4: fmov            d0, #1.00000000
    // 0xbeb4a8: ldr             d1, [fp, #0x10]
    // 0xbeb4ac: fsub            d2, d0, d1
    // 0xbeb4b0: fmul            d1, d2, d2
    // 0xbeb4b4: fsub            d2, d0, d1
    // 0xbeb4b8: r0 = inline_Allocate_Double()
    //     0xbeb4b8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeb4bc: add             x0, x0, #0x10
    //     0xbeb4c0: cmp             x1, x0
    //     0xbeb4c4: b.ls            #0xbeb4ec
    //     0xbeb4c8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeb4cc: sub             x0, x0, #0xf
    //     0xbeb4d0: mov             x1, #0xd108
    //     0xbeb4d4: movk            x1, #3, lsl #16
    //     0xbeb4d8: stur            x1, [x0, #-1]
    // 0xbeb4dc: StoreField: r0->field_7 = d2
    //     0xbeb4dc: stur            d2, [x0, #7]
    // 0xbeb4e0: LeaveFrame
    //     0xbeb4e0: mov             SP, fp
    //     0xbeb4e4: ldp             fp, lr, [SP], #0x10
    // 0xbeb4e8: ret
    //     0xbeb4e8: ret             
    // 0xbeb4ec: SaveReg d2
    //     0xbeb4ec: str             q2, [SP, #-0x10]!
    // 0xbeb4f0: r0 = AllocateDouble()
    //     0xbeb4f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb4f4: RestoreReg d2
    //     0xbeb4f4: ldr             q2, [SP], #0x10
    // 0xbeb4f8: b               #0xbeb4dc
  }
}

// class id: 4287, size: 0x10, field offset: 0xc
//   const constructor, 
class FlippedCurve extends Curve {

  _ toString(/* No info */) {
    // ** addr: 0xad5b04, size: 0x6c
    // 0xad5b04: EnterFrame
    //     0xad5b04: stp             fp, lr, [SP, #-0x10]!
    //     0xad5b08: mov             fp, SP
    // 0xad5b0c: CheckStackOverflow
    //     0xad5b0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5b10: cmp             SP, x16
    //     0xad5b14: b.ls            #0xad5b68
    // 0xad5b18: r1 = Null
    //     0xad5b18: mov             x1, NULL
    // 0xad5b1c: r2 = 8
    //     0xad5b1c: mov             x2, #8
    // 0xad5b20: r0 = AllocateArray()
    //     0xad5b20: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5b24: r17 = "FlippedCurve"
    //     0xad5b24: add             x17, PP, #0x22, lsl #12  ; [pp+0x22178] "FlippedCurve"
    //     0xad5b28: ldr             x17, [x17, #0x178]
    // 0xad5b2c: StoreField: r0->field_f = r17
    //     0xad5b2c: stur            w17, [x0, #0xf]
    // 0xad5b30: r17 = "("
    //     0xad5b30: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad5b34: StoreField: r0->field_13 = r17
    //     0xad5b34: stur            w17, [x0, #0x13]
    // 0xad5b38: ldr             x1, [fp, #0x10]
    // 0xad5b3c: LoadField: r2 = r1->field_b
    //     0xad5b3c: ldur            w2, [x1, #0xb]
    // 0xad5b40: DecompressPointer r2
    //     0xad5b40: add             x2, x2, HEAP, lsl #32
    // 0xad5b44: StoreField: r0->field_17 = r2
    //     0xad5b44: stur            w2, [x0, #0x17]
    // 0xad5b48: r17 = ")"
    //     0xad5b48: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad5b4c: StoreField: r0->field_1b = r17
    //     0xad5b4c: stur            w17, [x0, #0x1b]
    // 0xad5b50: SaveReg r0
    //     0xad5b50: str             x0, [SP, #-8]!
    // 0xad5b54: r0 = _interpolate()
    //     0xad5b54: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5b58: add             SP, SP, #8
    // 0xad5b5c: LeaveFrame
    //     0xad5b5c: mov             SP, fp
    //     0xad5b60: ldp             fp, lr, [SP], #0x10
    // 0xad5b64: ret
    //     0xad5b64: ret             
    // 0xad5b68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5b68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5b6c: b               #0xad5b18
  }
  _ transformInternal(/* No info */) {
    // ** addr: 0xbeb408, size: 0x94
    // 0xbeb408: EnterFrame
    //     0xbeb408: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb40c: mov             fp, SP
    // 0xbeb410: d0 = 1.000000
    //     0xbeb410: fmov            d0, #1.00000000
    // 0xbeb414: CheckStackOverflow
    //     0xbeb414: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbeb418: cmp             SP, x16
    //     0xbeb41c: b.ls            #0xbeb484
    // 0xbeb420: ldr             x0, [fp, #0x18]
    // 0xbeb424: LoadField: r1 = r0->field_b
    //     0xbeb424: ldur            w1, [x0, #0xb]
    // 0xbeb428: DecompressPointer r1
    //     0xbeb428: add             x1, x1, HEAP, lsl #32
    // 0xbeb42c: ldr             d1, [fp, #0x10]
    // 0xbeb430: fsub            d2, d0, d1
    // 0xbeb434: SaveReg r1
    //     0xbeb434: str             x1, [SP, #-8]!
    // 0xbeb438: SaveReg d2
    //     0xbeb438: str             d2, [SP, #-8]!
    // 0xbeb43c: r0 = transform()
    //     0xbeb43c: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xbeb440: add             SP, SP, #0x10
    // 0xbeb444: LoadField: d0 = r0->field_7
    //     0xbeb444: ldur            d0, [x0, #7]
    // 0xbeb448: d1 = 1.000000
    //     0xbeb448: fmov            d1, #1.00000000
    // 0xbeb44c: fsub            d2, d1, d0
    // 0xbeb450: r0 = inline_Allocate_Double()
    //     0xbeb450: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeb454: add             x0, x0, #0x10
    //     0xbeb458: cmp             x1, x0
    //     0xbeb45c: b.ls            #0xbeb48c
    //     0xbeb460: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeb464: sub             x0, x0, #0xf
    //     0xbeb468: mov             x1, #0xd108
    //     0xbeb46c: movk            x1, #3, lsl #16
    //     0xbeb470: stur            x1, [x0, #-1]
    // 0xbeb474: StoreField: r0->field_7 = d2
    //     0xbeb474: stur            d2, [x0, #7]
    // 0xbeb478: LeaveFrame
    //     0xbeb478: mov             SP, fp
    //     0xbeb47c: ldp             fp, lr, [SP], #0x10
    // 0xbeb480: ret
    //     0xbeb480: ret             
    // 0xbeb484: r0 = StackOverflowSharedWithFPURegs()
    //     0xbeb484: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbeb488: b               #0xbeb420
    // 0xbeb48c: SaveReg d2
    //     0xbeb48c: str             q2, [SP, #-0x10]!
    // 0xbeb490: r0 = AllocateDouble()
    //     0xbeb490: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb494: RestoreReg d2
    //     0xbeb494: ldr             q2, [SP], #0x10
    // 0xbeb498: b               #0xbeb474
  }
}

// class id: 4288, size: 0x20, field offset: 0xc
//   const constructor, 
class ThreePointCubic extends Curve {

  Offset field_c;
  Offset field_10;
  Offset field_14;
  Offset field_18;
  Offset field_1c;

  _ toString(/* No info */) {
    // ** addr: 0xad5a1c, size: 0xe8
    // 0xad5a1c: EnterFrame
    //     0xad5a1c: stp             fp, lr, [SP, #-0x10]!
    //     0xad5a20: mov             fp, SP
    // 0xad5a24: AllocStack(0x8)
    //     0xad5a24: sub             SP, SP, #8
    // 0xad5a28: CheckStackOverflow
    //     0xad5a28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5a2c: cmp             SP, x16
    //     0xad5a30: b.ls            #0xad5afc
    // 0xad5a34: r1 = Null
    //     0xad5a34: mov             x1, NULL
    // 0xad5a38: r2 = 22
    //     0xad5a38: mov             x2, #0x16
    // 0xad5a3c: r0 = AllocateArray()
    //     0xad5a3c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5a40: r17 = "ThreePointCubic("
    //     0xad5a40: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bb80] "ThreePointCubic("
    //     0xad5a44: ldr             x17, [x17, #0xb80]
    // 0xad5a48: StoreField: r0->field_f = r17
    //     0xad5a48: stur            w17, [x0, #0xf]
    // 0xad5a4c: ldr             x1, [fp, #0x10]
    // 0xad5a50: LoadField: r2 = r1->field_b
    //     0xad5a50: ldur            w2, [x1, #0xb]
    // 0xad5a54: DecompressPointer r2
    //     0xad5a54: add             x2, x2, HEAP, lsl #32
    // 0xad5a58: StoreField: r0->field_13 = r2
    //     0xad5a58: stur            w2, [x0, #0x13]
    // 0xad5a5c: r17 = ", "
    //     0xad5a5c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad5a60: StoreField: r0->field_17 = r17
    //     0xad5a60: stur            w17, [x0, #0x17]
    // 0xad5a64: LoadField: r2 = r1->field_f
    //     0xad5a64: ldur            w2, [x1, #0xf]
    // 0xad5a68: DecompressPointer r2
    //     0xad5a68: add             x2, x2, HEAP, lsl #32
    // 0xad5a6c: StoreField: r0->field_1b = r2
    //     0xad5a6c: stur            w2, [x0, #0x1b]
    // 0xad5a70: r17 = ", "
    //     0xad5a70: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad5a74: StoreField: r0->field_1f = r17
    //     0xad5a74: stur            w17, [x0, #0x1f]
    // 0xad5a78: LoadField: r2 = r1->field_13
    //     0xad5a78: ldur            w2, [x1, #0x13]
    // 0xad5a7c: DecompressPointer r2
    //     0xad5a7c: add             x2, x2, HEAP, lsl #32
    // 0xad5a80: StoreField: r0->field_23 = r2
    //     0xad5a80: stur            w2, [x0, #0x23]
    // 0xad5a84: r17 = ", "
    //     0xad5a84: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad5a88: StoreField: r0->field_27 = r17
    //     0xad5a88: stur            w17, [x0, #0x27]
    // 0xad5a8c: LoadField: r2 = r1->field_17
    //     0xad5a8c: ldur            w2, [x1, #0x17]
    // 0xad5a90: DecompressPointer r2
    //     0xad5a90: add             x2, x2, HEAP, lsl #32
    // 0xad5a94: StoreField: r0->field_2b = r2
    //     0xad5a94: stur            w2, [x0, #0x2b]
    // 0xad5a98: r17 = ", "
    //     0xad5a98: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad5a9c: StoreField: r0->field_2f = r17
    //     0xad5a9c: stur            w17, [x0, #0x2f]
    // 0xad5aa0: LoadField: r2 = r1->field_1b
    //     0xad5aa0: ldur            w2, [x1, #0x1b]
    // 0xad5aa4: DecompressPointer r2
    //     0xad5aa4: add             x2, x2, HEAP, lsl #32
    // 0xad5aa8: StoreField: r0->field_33 = r2
    //     0xad5aa8: stur            w2, [x0, #0x33]
    // 0xad5aac: r17 = ")"
    //     0xad5aac: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad5ab0: StoreField: r0->field_37 = r17
    //     0xad5ab0: stur            w17, [x0, #0x37]
    // 0xad5ab4: SaveReg r0
    //     0xad5ab4: str             x0, [SP, #-8]!
    // 0xad5ab8: r0 = _interpolate()
    //     0xad5ab8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5abc: add             SP, SP, #8
    // 0xad5ac0: r1 = Null
    //     0xad5ac0: mov             x1, NULL
    // 0xad5ac4: r2 = 4
    //     0xad5ac4: mov             x2, #4
    // 0xad5ac8: stur            x0, [fp, #-8]
    // 0xad5acc: r0 = AllocateArray()
    //     0xad5acc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5ad0: mov             x1, x0
    // 0xad5ad4: ldur            x0, [fp, #-8]
    // 0xad5ad8: StoreField: r1->field_f = r0
    //     0xad5ad8: stur            w0, [x1, #0xf]
    // 0xad5adc: r17 = " "
    //     0xad5adc: ldr             x17, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xad5ae0: StoreField: r1->field_13 = r17
    //     0xad5ae0: stur            w17, [x1, #0x13]
    // 0xad5ae4: SaveReg r1
    //     0xad5ae4: str             x1, [SP, #-8]!
    // 0xad5ae8: r0 = _interpolate()
    //     0xad5ae8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5aec: add             SP, SP, #8
    // 0xad5af0: LeaveFrame
    //     0xad5af0: mov             SP, fp
    //     0xad5af4: ldp             fp, lr, [SP], #0x10
    // 0xad5af8: ret
    //     0xad5af8: ret             
    // 0xad5afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5afc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5b00: b               #0xad5a34
  }
  _ transformInternal(/* No info */) {
    // ** addr: 0xbeb1c4, size: 0x238
    // 0xbeb1c4: EnterFrame
    //     0xbeb1c4: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb1c8: mov             fp, SP
    // 0xbeb1cc: AllocStack(0x30)
    //     0xbeb1cc: sub             SP, SP, #0x30
    // 0xbeb1d0: r0 = Instance_Offset
    //     0xbeb1d0: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4bb88] Obj!Offset@b5f091
    //     0xbeb1d4: ldr             x0, [x0, #0xb88]
    // 0xbeb1d8: CheckStackOverflow
    //     0xbeb1d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbeb1dc: cmp             SP, x16
    //     0xbeb1e0: b.ls            #0xbeb3d4
    // 0xbeb1e4: LoadField: d0 = r0->field_7
    //     0xbeb1e4: ldur            d0, [x0, #7]
    // 0xbeb1e8: ldr             d1, [fp, #0x10]
    // 0xbeb1ec: fcmp            d1, d0
    // 0xbeb1f0: b.vs            #0xbeb1f8
    // 0xbeb1f4: b.lt            #0xbeb200
    // 0xbeb1f8: r1 = false
    //     0xbeb1f8: add             x1, NULL, #0x30  ; false
    // 0xbeb1fc: b               #0xbeb204
    // 0xbeb200: r1 = true
    //     0xbeb200: add             x1, NULL, #0x20  ; true
    // 0xbeb204: tbnz            w1, #4, #0xbeb210
    // 0xbeb208: mov             v2.16b, v0.16b
    // 0xbeb20c: b               #0xbeb218
    // 0xbeb210: d2 = 0.833334
    //     0xbeb210: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b748] IMM: double(0.833334) from 0x3feaaaac1094a2ba
    //     0xbeb214: ldr             d2, [x17, #0x748]
    // 0xbeb218: tbnz            w1, #4, #0xbeb224
    // 0xbeb21c: LoadField: d3 = r0->field_f
    //     0xbeb21c: ldur            d3, [x0, #0xf]
    // 0xbeb220: b               #0xbeb22c
    // 0xbeb224: d3 = 0.600000
    //     0xbeb224: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0xbeb228: ldr             d3, [x17, #0xf90]
    // 0xbeb22c: stur            d3, [fp, #-0x30]
    // 0xbeb230: tbnz            w1, #4, #0xbeb238
    // 0xbeb234: d0 = 0.000000
    //     0xbeb234: eor             v0.16b, v0.16b, v0.16b
    // 0xbeb238: fsub            d4, d1, d0
    // 0xbeb23c: fdiv            d0, d4, d2
    // 0xbeb240: stur            d0, [fp, #-0x28]
    // 0xbeb244: tbnz            w1, #4, #0xbeb304
    // 0xbeb248: r1 = Instance_Offset
    //     0xbeb248: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bb90] Obj!Offset@b5f0d1
    //     0xbeb24c: ldr             x1, [x1, #0xb90]
    // 0xbeb250: r0 = Instance_Offset
    //     0xbeb250: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4bb98] Obj!Offset@b5f0b1
    //     0xbeb254: ldr             x0, [x0, #0xb98]
    // 0xbeb258: LoadField: d1 = r1->field_7
    //     0xbeb258: ldur            d1, [x1, #7]
    // 0xbeb25c: fdiv            d4, d1, d2
    // 0xbeb260: stur            d4, [fp, #-0x20]
    // 0xbeb264: LoadField: d1 = r1->field_f
    //     0xbeb264: ldur            d1, [x1, #0xf]
    // 0xbeb268: fdiv            d5, d1, d3
    // 0xbeb26c: stur            d5, [fp, #-0x18]
    // 0xbeb270: LoadField: d1 = r0->field_7
    //     0xbeb270: ldur            d1, [x0, #7]
    // 0xbeb274: fdiv            d6, d1, d2
    // 0xbeb278: stur            d6, [fp, #-0x10]
    // 0xbeb27c: LoadField: d1 = r0->field_f
    //     0xbeb27c: ldur            d1, [x0, #0xf]
    // 0xbeb280: fdiv            d2, d1, d3
    // 0xbeb284: stur            d2, [fp, #-8]
    // 0xbeb288: r1 = <double>
    //     0xbeb288: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xbeb28c: r0 = Cubic()
    //     0xbeb28c: bl              #0xbeb3fc  ; AllocateCubicStub -> Cubic (size=0x2c)
    // 0xbeb290: ldur            d0, [fp, #-0x20]
    // 0xbeb294: StoreField: r0->field_b = d0
    //     0xbeb294: stur            d0, [x0, #0xb]
    // 0xbeb298: ldur            d0, [fp, #-0x18]
    // 0xbeb29c: StoreField: r0->field_13 = d0
    //     0xbeb29c: stur            d0, [x0, #0x13]
    // 0xbeb2a0: ldur            d0, [fp, #-0x10]
    // 0xbeb2a4: StoreField: r0->field_1b = d0
    //     0xbeb2a4: stur            d0, [x0, #0x1b]
    // 0xbeb2a8: ldur            d0, [fp, #-8]
    // 0xbeb2ac: StoreField: r0->field_23 = d0
    //     0xbeb2ac: stur            d0, [x0, #0x23]
    // 0xbeb2b0: SaveReg r0
    //     0xbeb2b0: str             x0, [SP, #-8]!
    // 0xbeb2b4: ldur            d0, [fp, #-0x28]
    // 0xbeb2b8: SaveReg d0
    //     0xbeb2b8: str             d0, [SP, #-8]!
    // 0xbeb2bc: r0 = transform()
    //     0xbeb2bc: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xbeb2c0: add             SP, SP, #0x10
    // 0xbeb2c4: LoadField: d0 = r0->field_7
    //     0xbeb2c4: ldur            d0, [x0, #7]
    // 0xbeb2c8: ldur            d1, [fp, #-0x30]
    // 0xbeb2cc: fmul            d2, d0, d1
    // 0xbeb2d0: r0 = inline_Allocate_Double()
    //     0xbeb2d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeb2d4: add             x0, x0, #0x10
    //     0xbeb2d8: cmp             x1, x0
    //     0xbeb2dc: b.ls            #0xbeb3dc
    //     0xbeb2e0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeb2e4: sub             x0, x0, #0xf
    //     0xbeb2e8: mov             x1, #0xd108
    //     0xbeb2ec: movk            x1, #3, lsl #16
    //     0xbeb2f0: stur            x1, [x0, #-1]
    // 0xbeb2f4: StoreField: r0->field_7 = d2
    //     0xbeb2f4: stur            d2, [x0, #7]
    // 0xbeb2f8: LeaveFrame
    //     0xbeb2f8: mov             SP, fp
    //     0xbeb2fc: ldp             fp, lr, [SP], #0x10
    // 0xbeb300: ret
    //     0xbeb300: ret             
    // 0xbeb304: mov             v1.16b, v3.16b
    // 0xbeb308: d6 = 0.600000
    //     0xbeb308: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0xbeb30c: ldr             d6, [x17, #0xf90]
    // 0xbeb310: d5 = 0.041667
    //     0xbeb310: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bba0] IMM: double(0.04166699999999998) from 0x3fa5556084a515cc
    //     0xbeb314: ldr             d5, [x17, #0xba0]
    // 0xbeb318: d4 = 0.420000
    //     0xbeb318: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bba8] IMM: double(0.41999999999999993) from 0x3fdae147ae147ae0
    //     0xbeb31c: ldr             d4, [x17, #0xba8]
    // 0xbeb320: d3 = 0.083334
    //     0xbeb320: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bbb0] IMM: double(0.08333399999999999) from 0x3fb5556084a515ce
    //     0xbeb324: ldr             d3, [x17, #0xbb0]
    // 0xbeb328: fdiv            d7, d5, d2
    // 0xbeb32c: stur            d7, [fp, #-0x20]
    // 0xbeb330: fdiv            d5, d4, d1
    // 0xbeb334: stur            d5, [fp, #-0x18]
    // 0xbeb338: fdiv            d4, d3, d2
    // 0xbeb33c: stur            d4, [fp, #-0x10]
    // 0xbeb340: fdiv            d2, d6, d1
    // 0xbeb344: stur            d2, [fp, #-8]
    // 0xbeb348: r1 = <double>
    //     0xbeb348: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xbeb34c: r0 = Cubic()
    //     0xbeb34c: bl              #0xbeb3fc  ; AllocateCubicStub -> Cubic (size=0x2c)
    // 0xbeb350: ldur            d0, [fp, #-0x20]
    // 0xbeb354: StoreField: r0->field_b = d0
    //     0xbeb354: stur            d0, [x0, #0xb]
    // 0xbeb358: ldur            d0, [fp, #-0x18]
    // 0xbeb35c: StoreField: r0->field_13 = d0
    //     0xbeb35c: stur            d0, [x0, #0x13]
    // 0xbeb360: ldur            d0, [fp, #-0x10]
    // 0xbeb364: StoreField: r0->field_1b = d0
    //     0xbeb364: stur            d0, [x0, #0x1b]
    // 0xbeb368: ldur            d0, [fp, #-8]
    // 0xbeb36c: StoreField: r0->field_23 = d0
    //     0xbeb36c: stur            d0, [x0, #0x23]
    // 0xbeb370: SaveReg r0
    //     0xbeb370: str             x0, [SP, #-8]!
    // 0xbeb374: ldur            d0, [fp, #-0x28]
    // 0xbeb378: SaveReg d0
    //     0xbeb378: str             d0, [SP, #-8]!
    // 0xbeb37c: r0 = transform()
    //     0xbeb37c: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xbeb380: add             SP, SP, #0x10
    // 0xbeb384: LoadField: d0 = r0->field_7
    //     0xbeb384: ldur            d0, [x0, #7]
    // 0xbeb388: ldur            d1, [fp, #-0x30]
    // 0xbeb38c: fmul            d2, d0, d1
    // 0xbeb390: r1 = Instance_Offset
    //     0xbeb390: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bb88] Obj!Offset@b5f091
    //     0xbeb394: ldr             x1, [x1, #0xb88]
    // 0xbeb398: LoadField: d0 = r1->field_f
    //     0xbeb398: ldur            d0, [x1, #0xf]
    // 0xbeb39c: fadd            d1, d2, d0
    // 0xbeb3a0: r0 = inline_Allocate_Double()
    //     0xbeb3a0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeb3a4: add             x0, x0, #0x10
    //     0xbeb3a8: cmp             x1, x0
    //     0xbeb3ac: b.ls            #0xbeb3ec
    //     0xbeb3b0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeb3b4: sub             x0, x0, #0xf
    //     0xbeb3b8: mov             x1, #0xd108
    //     0xbeb3bc: movk            x1, #3, lsl #16
    //     0xbeb3c0: stur            x1, [x0, #-1]
    // 0xbeb3c4: StoreField: r0->field_7 = d1
    //     0xbeb3c4: stur            d1, [x0, #7]
    // 0xbeb3c8: LeaveFrame
    //     0xbeb3c8: mov             SP, fp
    //     0xbeb3cc: ldp             fp, lr, [SP], #0x10
    // 0xbeb3d0: ret
    //     0xbeb3d0: ret             
    // 0xbeb3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb3d8: b               #0xbeb1e4
    // 0xbeb3dc: SaveReg d2
    //     0xbeb3dc: str             q2, [SP, #-0x10]!
    // 0xbeb3e0: r0 = AllocateDouble()
    //     0xbeb3e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb3e4: RestoreReg d2
    //     0xbeb3e4: ldr             q2, [SP], #0x10
    // 0xbeb3e8: b               #0xbeb2f4
    // 0xbeb3ec: SaveReg d1
    //     0xbeb3ec: str             q1, [SP, #-0x10]!
    // 0xbeb3f0: r0 = AllocateDouble()
    //     0xbeb3f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb3f4: RestoreReg d1
    //     0xbeb3f4: ldr             q1, [SP], #0x10
    // 0xbeb3f8: b               #0xbeb3c4
  }
}

// class id: 4289, size: 0x2c, field offset: 0xc
//   const constructor, 
class Cubic extends Curve {

  _Double field_c;
  _Double field_14;
  _Double field_1c;
  _Double field_24;

  _ toString(/* No info */) {
    // ** addr: 0xad5774, size: 0x2a8
    // 0xad5774: EnterFrame
    //     0xad5774: stp             fp, lr, [SP, #-0x10]!
    //     0xad5778: mov             fp, SP
    // 0xad577c: AllocStack(0x8)
    //     0xad577c: sub             SP, SP, #8
    // 0xad5780: CheckStackOverflow
    //     0xad5780: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5784: cmp             SP, x16
    //     0xad5788: b.ls            #0xad59a8
    // 0xad578c: r1 = Null
    //     0xad578c: mov             x1, NULL
    // 0xad5790: r2 = 20
    //     0xad5790: mov             x2, #0x14
    // 0xad5794: r0 = AllocateArray()
    //     0xad5794: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5798: stur            x0, [fp, #-8]
    // 0xad579c: r17 = "Cubic"
    //     0xad579c: add             x17, PP, #0xc, lsl #12  ; [pp+0xc7a0] "Cubic"
    //     0xad57a0: ldr             x17, [x17, #0x7a0]
    // 0xad57a4: StoreField: r0->field_f = r17
    //     0xad57a4: stur            w17, [x0, #0xf]
    // 0xad57a8: r17 = "("
    //     0xad57a8: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad57ac: StoreField: r0->field_13 = r17
    //     0xad57ac: stur            w17, [x0, #0x13]
    // 0xad57b0: ldr             x1, [fp, #0x10]
    // 0xad57b4: LoadField: d0 = r1->field_b
    //     0xad57b4: ldur            d0, [x1, #0xb]
    // 0xad57b8: r2 = inline_Allocate_Double()
    //     0xad57b8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad57bc: add             x2, x2, #0x10
    //     0xad57c0: cmp             x3, x2
    //     0xad57c4: b.ls            #0xad59b0
    //     0xad57c8: str             x2, [THR, #0x60]  ; THR::top
    //     0xad57cc: sub             x2, x2, #0xf
    //     0xad57d0: mov             x3, #0xd108
    //     0xad57d4: movk            x3, #3, lsl #16
    //     0xad57d8: stur            x3, [x2, #-1]
    // 0xad57dc: StoreField: r2->field_7 = d0
    //     0xad57dc: stur            d0, [x2, #7]
    // 0xad57e0: SaveReg r2
    //     0xad57e0: str             x2, [SP, #-8]!
    // 0xad57e4: r2 = 2
    //     0xad57e4: mov             x2, #2
    // 0xad57e8: SaveReg r2
    //     0xad57e8: str             x2, [SP, #-8]!
    // 0xad57ec: r0 = toStringAsFixed()
    //     0xad57ec: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad57f0: add             SP, SP, #0x10
    // 0xad57f4: ldur            x1, [fp, #-8]
    // 0xad57f8: ArrayStore: r1[2] = r0  ; List_4
    //     0xad57f8: add             x25, x1, #0x17
    //     0xad57fc: str             w0, [x25]
    //     0xad5800: tbz             w0, #0, #0xad581c
    //     0xad5804: ldurb           w16, [x1, #-1]
    //     0xad5808: ldurb           w17, [x0, #-1]
    //     0xad580c: and             x16, x17, x16, lsr #2
    //     0xad5810: tst             x16, HEAP, lsr #32
    //     0xad5814: b.eq            #0xad581c
    //     0xad5818: bl              #0xd67e5c
    // 0xad581c: ldur            x1, [fp, #-8]
    // 0xad5820: r17 = ", "
    //     0xad5820: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad5824: StoreField: r1->field_1b = r17
    //     0xad5824: stur            w17, [x1, #0x1b]
    // 0xad5828: ldr             x0, [fp, #0x10]
    // 0xad582c: LoadField: d0 = r0->field_13
    //     0xad582c: ldur            d0, [x0, #0x13]
    // 0xad5830: r2 = inline_Allocate_Double()
    //     0xad5830: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad5834: add             x2, x2, #0x10
    //     0xad5838: cmp             x3, x2
    //     0xad583c: b.ls            #0xad59cc
    //     0xad5840: str             x2, [THR, #0x60]  ; THR::top
    //     0xad5844: sub             x2, x2, #0xf
    //     0xad5848: mov             x3, #0xd108
    //     0xad584c: movk            x3, #3, lsl #16
    //     0xad5850: stur            x3, [x2, #-1]
    // 0xad5854: StoreField: r2->field_7 = d0
    //     0xad5854: stur            d0, [x2, #7]
    // 0xad5858: SaveReg r2
    //     0xad5858: str             x2, [SP, #-8]!
    // 0xad585c: r2 = 2
    //     0xad585c: mov             x2, #2
    // 0xad5860: SaveReg r2
    //     0xad5860: str             x2, [SP, #-8]!
    // 0xad5864: r0 = toStringAsFixed()
    //     0xad5864: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad5868: add             SP, SP, #0x10
    // 0xad586c: ldur            x1, [fp, #-8]
    // 0xad5870: ArrayStore: r1[4] = r0  ; List_4
    //     0xad5870: add             x25, x1, #0x1f
    //     0xad5874: str             w0, [x25]
    //     0xad5878: tbz             w0, #0, #0xad5894
    //     0xad587c: ldurb           w16, [x1, #-1]
    //     0xad5880: ldurb           w17, [x0, #-1]
    //     0xad5884: and             x16, x17, x16, lsr #2
    //     0xad5888: tst             x16, HEAP, lsr #32
    //     0xad588c: b.eq            #0xad5894
    //     0xad5890: bl              #0xd67e5c
    // 0xad5894: ldur            x1, [fp, #-8]
    // 0xad5898: r17 = ", "
    //     0xad5898: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad589c: StoreField: r1->field_23 = r17
    //     0xad589c: stur            w17, [x1, #0x23]
    // 0xad58a0: ldr             x0, [fp, #0x10]
    // 0xad58a4: LoadField: d0 = r0->field_1b
    //     0xad58a4: ldur            d0, [x0, #0x1b]
    // 0xad58a8: r2 = inline_Allocate_Double()
    //     0xad58a8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad58ac: add             x2, x2, #0x10
    //     0xad58b0: cmp             x3, x2
    //     0xad58b4: b.ls            #0xad59e8
    //     0xad58b8: str             x2, [THR, #0x60]  ; THR::top
    //     0xad58bc: sub             x2, x2, #0xf
    //     0xad58c0: mov             x3, #0xd108
    //     0xad58c4: movk            x3, #3, lsl #16
    //     0xad58c8: stur            x3, [x2, #-1]
    // 0xad58cc: StoreField: r2->field_7 = d0
    //     0xad58cc: stur            d0, [x2, #7]
    // 0xad58d0: SaveReg r2
    //     0xad58d0: str             x2, [SP, #-8]!
    // 0xad58d4: r2 = 2
    //     0xad58d4: mov             x2, #2
    // 0xad58d8: SaveReg r2
    //     0xad58d8: str             x2, [SP, #-8]!
    // 0xad58dc: r0 = toStringAsFixed()
    //     0xad58dc: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad58e0: add             SP, SP, #0x10
    // 0xad58e4: ldur            x1, [fp, #-8]
    // 0xad58e8: ArrayStore: r1[6] = r0  ; List_4
    //     0xad58e8: add             x25, x1, #0x27
    //     0xad58ec: str             w0, [x25]
    //     0xad58f0: tbz             w0, #0, #0xad590c
    //     0xad58f4: ldurb           w16, [x1, #-1]
    //     0xad58f8: ldurb           w17, [x0, #-1]
    //     0xad58fc: and             x16, x17, x16, lsr #2
    //     0xad5900: tst             x16, HEAP, lsr #32
    //     0xad5904: b.eq            #0xad590c
    //     0xad5908: bl              #0xd67e5c
    // 0xad590c: ldur            x1, [fp, #-8]
    // 0xad5910: r17 = ", "
    //     0xad5910: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad5914: StoreField: r1->field_2b = r17
    //     0xad5914: stur            w17, [x1, #0x2b]
    // 0xad5918: ldr             x0, [fp, #0x10]
    // 0xad591c: LoadField: d0 = r0->field_23
    //     0xad591c: ldur            d0, [x0, #0x23]
    // 0xad5920: r0 = inline_Allocate_Double()
    //     0xad5920: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xad5924: add             x0, x0, #0x10
    //     0xad5928: cmp             x2, x0
    //     0xad592c: b.ls            #0xad5a04
    //     0xad5930: str             x0, [THR, #0x60]  ; THR::top
    //     0xad5934: sub             x0, x0, #0xf
    //     0xad5938: mov             x2, #0xd108
    //     0xad593c: movk            x2, #3, lsl #16
    //     0xad5940: stur            x2, [x0, #-1]
    // 0xad5944: StoreField: r0->field_7 = d0
    //     0xad5944: stur            d0, [x0, #7]
    // 0xad5948: SaveReg r0
    //     0xad5948: str             x0, [SP, #-8]!
    // 0xad594c: r0 = 2
    //     0xad594c: mov             x0, #2
    // 0xad5950: SaveReg r0
    //     0xad5950: str             x0, [SP, #-8]!
    // 0xad5954: r0 = toStringAsFixed()
    //     0xad5954: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad5958: add             SP, SP, #0x10
    // 0xad595c: ldur            x1, [fp, #-8]
    // 0xad5960: ArrayStore: r1[8] = r0  ; List_4
    //     0xad5960: add             x25, x1, #0x2f
    //     0xad5964: str             w0, [x25]
    //     0xad5968: tbz             w0, #0, #0xad5984
    //     0xad596c: ldurb           w16, [x1, #-1]
    //     0xad5970: ldurb           w17, [x0, #-1]
    //     0xad5974: and             x16, x17, x16, lsr #2
    //     0xad5978: tst             x16, HEAP, lsr #32
    //     0xad597c: b.eq            #0xad5984
    //     0xad5980: bl              #0xd67e5c
    // 0xad5984: ldur            x0, [fp, #-8]
    // 0xad5988: r17 = ")"
    //     0xad5988: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad598c: StoreField: r0->field_33 = r17
    //     0xad598c: stur            w17, [x0, #0x33]
    // 0xad5990: SaveReg r0
    //     0xad5990: str             x0, [SP, #-8]!
    // 0xad5994: r0 = _interpolate()
    //     0xad5994: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5998: add             SP, SP, #8
    // 0xad599c: LeaveFrame
    //     0xad599c: mov             SP, fp
    //     0xad59a0: ldp             fp, lr, [SP], #0x10
    // 0xad59a4: ret
    //     0xad59a4: ret             
    // 0xad59a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad59a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad59ac: b               #0xad578c
    // 0xad59b0: SaveReg d0
    //     0xad59b0: str             q0, [SP, #-0x10]!
    // 0xad59b4: stp             x0, x1, [SP, #-0x10]!
    // 0xad59b8: r0 = AllocateDouble()
    //     0xad59b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad59bc: mov             x2, x0
    // 0xad59c0: ldp             x0, x1, [SP], #0x10
    // 0xad59c4: RestoreReg d0
    //     0xad59c4: ldr             q0, [SP], #0x10
    // 0xad59c8: b               #0xad57dc
    // 0xad59cc: SaveReg d0
    //     0xad59cc: str             q0, [SP, #-0x10]!
    // 0xad59d0: stp             x0, x1, [SP, #-0x10]!
    // 0xad59d4: r0 = AllocateDouble()
    //     0xad59d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad59d8: mov             x2, x0
    // 0xad59dc: ldp             x0, x1, [SP], #0x10
    // 0xad59e0: RestoreReg d0
    //     0xad59e0: ldr             q0, [SP], #0x10
    // 0xad59e4: b               #0xad5854
    // 0xad59e8: SaveReg d0
    //     0xad59e8: str             q0, [SP, #-0x10]!
    // 0xad59ec: stp             x0, x1, [SP, #-0x10]!
    // 0xad59f0: r0 = AllocateDouble()
    //     0xad59f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad59f4: mov             x2, x0
    // 0xad59f8: ldp             x0, x1, [SP], #0x10
    // 0xad59fc: RestoreReg d0
    //     0xad59fc: ldr             q0, [SP], #0x10
    // 0xad5a00: b               #0xad58cc
    // 0xad5a04: SaveReg d0
    //     0xad5a04: str             q0, [SP, #-0x10]!
    // 0xad5a08: SaveReg r1
    //     0xad5a08: str             x1, [SP, #-8]!
    // 0xad5a0c: r0 = AllocateDouble()
    //     0xad5a0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad5a10: RestoreReg r1
    //     0xad5a10: ldr             x1, [SP], #8
    // 0xad5a14: RestoreReg d0
    //     0xad5a14: ldr             q0, [SP], #0x10
    // 0xad5a18: b               #0xad5944
  }
  _ transformInternal(/* No info */) {
    // ** addr: 0xbeb074, size: 0x150
    // 0xbeb074: EnterFrame
    //     0xbeb074: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb078: mov             fp, SP
    // 0xbeb07c: d0 = 3.000000
    //     0xbeb07c: fmov            d0, #3.00000000
    // 0xbeb080: ldr             x1, [fp, #0x18]
    // 0xbeb084: LoadField: d1 = r1->field_b
    //     0xbeb084: ldur            d1, [x1, #0xb]
    // 0xbeb088: LoadField: d2 = r1->field_1b
    //     0xbeb088: ldur            d2, [x1, #0x1b]
    // 0xbeb08c: fmul            d3, d0, d1
    // 0xbeb090: fmul            d1, d0, d2
    // 0xbeb094: ldr             d7, [fp, #0x10]
    // 0xbeb098: d9 = 0.000000
    //     0xbeb098: eor             v9.16b, v9.16b, v9.16b
    // 0xbeb09c: d8 = 1.000000
    //     0xbeb09c: fmov            d8, #1.00000000
    // 0xbeb0a0: d6 = 2.000000
    //     0xbeb0a0: fmov            d6, #2.00000000
    // 0xbeb0a4: d5 = 0.000000
    //     0xbeb0a4: eor             v5.16b, v5.16b, v5.16b
    // 0xbeb0a8: d4 = 1.000000
    //     0xbeb0a8: fmov            d4, #1.00000000
    // 0xbeb0ac: d2 = 0.001000
    //     0xbeb0ac: add             x17, PP, #8, lsl #12  ; [pp+0x8c38] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    //     0xbeb0b0: ldr             d2, [x17, #0xc38]
    // 0xbeb0b4: CheckStackOverflow
    //     0xbeb0b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbeb0b8: cmp             SP, x16
    //     0xbeb0bc: b.ls            #0xbeb1ac
    // 0xbeb0c0: fadd            d10, d9, d8
    // 0xbeb0c4: fdiv            d11, d10, d6
    // 0xbeb0c8: fsub            d10, d4, d11
    // 0xbeb0cc: fmul            d12, d3, d10
    // 0xbeb0d0: fmul            d13, d12, d10
    // 0xbeb0d4: fmul            d12, d13, d11
    // 0xbeb0d8: fmul            d13, d1, d10
    // 0xbeb0dc: fmul            d14, d13, d11
    // 0xbeb0e0: fmul            d13, d14, d11
    // 0xbeb0e4: fadd            d14, d12, d13
    // 0xbeb0e8: fmul            d12, d11, d11
    // 0xbeb0ec: fmul            d13, d12, d11
    // 0xbeb0f0: fadd            d12, d14, d13
    // 0xbeb0f4: fsub            d14, d7, d12
    // 0xbeb0f8: fcmp            d14, d5
    // 0xbeb0fc: b.vs            #0xbeb10c
    // 0xbeb100: b.ne            #0xbeb10c
    // 0xbeb104: d14 = 0.000000
    //     0xbeb104: eor             v14.16b, v14.16b, v14.16b
    // 0xbeb108: b               #0xbeb120
    // 0xbeb10c: fcmp            d14, d5
    // 0xbeb110: b.vs            #0xbeb120
    // 0xbeb114: b.ge            #0xbeb120
    // 0xbeb118: fneg            d15, d14
    // 0xbeb11c: mov             v14.16b, v15.16b
    // 0xbeb120: fcmp            d14, d2
    // 0xbeb124: b.vs            #0xbeb190
    // 0xbeb128: b.ge            #0xbeb190
    // 0xbeb12c: LoadField: d14 = r1->field_13
    //     0xbeb12c: ldur            d14, [x1, #0x13]
    // 0xbeb130: LoadField: d15 = r1->field_23
    //     0xbeb130: ldur            d15, [x1, #0x23]
    // 0xbeb134: fmul            d16, d0, d14
    // 0xbeb138: fmul            d14, d16, d10
    // 0xbeb13c: fmul            d16, d14, d10
    // 0xbeb140: fmul            d14, d16, d11
    // 0xbeb144: fmul            d16, d0, d15
    // 0xbeb148: fmul            d15, d16, d10
    // 0xbeb14c: fmul            d10, d15, d11
    // 0xbeb150: fmul            d15, d10, d11
    // 0xbeb154: fadd            d10, d14, d15
    // 0xbeb158: fadd            d14, d10, d13
    // 0xbeb15c: r0 = inline_Allocate_Double()
    //     0xbeb15c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbeb160: add             x0, x0, #0x10
    //     0xbeb164: cmp             x2, x0
    //     0xbeb168: b.ls            #0xbeb1b4
    //     0xbeb16c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeb170: sub             x0, x0, #0xf
    //     0xbeb174: mov             x2, #0xd108
    //     0xbeb178: movk            x2, #3, lsl #16
    //     0xbeb17c: stur            x2, [x0, #-1]
    // 0xbeb180: StoreField: r0->field_7 = d14
    //     0xbeb180: stur            d14, [x0, #7]
    // 0xbeb184: LeaveFrame
    //     0xbeb184: mov             SP, fp
    //     0xbeb188: ldp             fp, lr, [SP], #0x10
    // 0xbeb18c: ret
    //     0xbeb18c: ret             
    // 0xbeb190: fcmp            d12, d7
    // 0xbeb194: b.vs            #0xbeb1a4
    // 0xbeb198: b.ge            #0xbeb1a4
    // 0xbeb19c: mov             v9.16b, v11.16b
    // 0xbeb1a0: b               #0xbeb0b4
    // 0xbeb1a4: mov             v8.16b, v11.16b
    // 0xbeb1a8: b               #0xbeb0b4
    // 0xbeb1ac: r0 = StackOverflowSharedWithFPURegs()
    //     0xbeb1ac: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbeb1b0: b               #0xbeb0c0
    // 0xbeb1b4: SaveReg d14
    //     0xbeb1b4: str             q14, [SP, #-0x10]!
    // 0xbeb1b8: r0 = AllocateDouble()
    //     0xbeb1b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb1bc: RestoreReg d14
    //     0xbeb1bc: ldr             q14, [SP], #0x10
    // 0xbeb1c0: b               #0xbeb180
  }
}

// class id: 4290, size: 0x14, field offset: 0xc
//   const constructor, 
class Threshold extends Curve {

  _Double field_c;

  _ transformInternal(/* No info */) {
    // ** addr: 0xbeb008, size: 0x6c
    // 0xbeb008: EnterFrame
    //     0xbeb008: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb00c: mov             fp, SP
    // 0xbeb010: d0 = 0.500000
    //     0xbeb010: fmov            d0, #0.50000000
    // 0xbeb014: ldr             d1, [fp, #0x10]
    // 0xbeb018: fcmp            d1, d0
    // 0xbeb01c: b.vs            #0xbeb02c
    // 0xbeb020: b.ge            #0xbeb02c
    // 0xbeb024: d0 = 0.000000
    //     0xbeb024: eor             v0.16b, v0.16b, v0.16b
    // 0xbeb028: b               #0xbeb030
    // 0xbeb02c: d0 = 1.000000
    //     0xbeb02c: fmov            d0, #1.00000000
    // 0xbeb030: r0 = inline_Allocate_Double()
    //     0xbeb030: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeb034: add             x0, x0, #0x10
    //     0xbeb038: cmp             x1, x0
    //     0xbeb03c: b.ls            #0xbeb064
    //     0xbeb040: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeb044: sub             x0, x0, #0xf
    //     0xbeb048: mov             x1, #0xd108
    //     0xbeb04c: movk            x1, #3, lsl #16
    //     0xbeb050: stur            x1, [x0, #-1]
    // 0xbeb054: StoreField: r0->field_7 = d0
    //     0xbeb054: stur            d0, [x0, #7]
    // 0xbeb058: LeaveFrame
    //     0xbeb058: mov             SP, fp
    //     0xbeb05c: ldp             fp, lr, [SP], #0x10
    // 0xbeb060: ret
    //     0xbeb060: ret             
    // 0xbeb064: SaveReg d0
    //     0xbeb064: str             q0, [SP, #-0x10]!
    // 0xbeb068: r0 = AllocateDouble()
    //     0xbeb068: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb06c: RestoreReg d0
    //     0xbeb06c: ldr             q0, [SP], #0x10
    // 0xbeb070: b               #0xbeb054
  }
}

// class id: 4291, size: 0x20, field offset: 0xc
//   const constructor, 
class Interval extends Curve {

  _Double field_c;
  _Double field_14;
  Cubic<double> field_1c;

  _ toString(/* No info */) {
    // ** addr: 0xad554c, size: 0x228
    // 0xad554c: EnterFrame
    //     0xad554c: stp             fp, lr, [SP, #-0x10]!
    //     0xad5550: mov             fp, SP
    // 0xad5554: AllocStack(0x8)
    //     0xad5554: sub             SP, SP, #8
    // 0xad5558: CheckStackOverflow
    //     0xad5558: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad555c: cmp             SP, x16
    //     0xad5560: b.ls            #0xad56fc
    // 0xad5564: ldr             x0, [fp, #0x10]
    // 0xad5568: LoadField: r3 = r0->field_1b
    //     0xad5568: ldur            w3, [x0, #0x1b]
    // 0xad556c: DecompressPointer r3
    //     0xad556c: add             x3, x3, HEAP, lsl #32
    // 0xad5570: stur            x3, [fp, #-8]
    // 0xad5574: r1 = LoadClassIdInstr(r3)
    //     0xad5574: ldur            x1, [x3, #-1]
    //     0xad5578: ubfx            x1, x1, #0xc, #0x14
    // 0xad557c: lsl             x1, x1, #1
    // 0xad5580: r17 = 8586
    //     0xad5580: mov             x17, #0x218a
    // 0xad5584: cmp             w1, w17
    // 0xad5588: b.eq            #0xad5648
    // 0xad558c: r1 = Null
    //     0xad558c: mov             x1, NULL
    // 0xad5590: r2 = 14
    //     0xad5590: mov             x2, #0xe
    // 0xad5594: r0 = AllocateArray()
    //     0xad5594: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5598: r17 = "Interval"
    //     0xad5598: add             x17, PP, #0x22, lsl #12  ; [pp+0x22180] "Interval"
    //     0xad559c: ldr             x17, [x17, #0x180]
    // 0xad55a0: StoreField: r0->field_f = r17
    //     0xad55a0: stur            w17, [x0, #0xf]
    // 0xad55a4: r17 = "("
    //     0xad55a4: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad55a8: StoreField: r0->field_13 = r17
    //     0xad55a8: stur            w17, [x0, #0x13]
    // 0xad55ac: ldr             x3, [fp, #0x10]
    // 0xad55b0: LoadField: d0 = r3->field_b
    //     0xad55b0: ldur            d0, [x3, #0xb]
    // 0xad55b4: r1 = inline_Allocate_Double()
    //     0xad55b4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xad55b8: add             x1, x1, #0x10
    //     0xad55bc: cmp             x2, x1
    //     0xad55c0: b.ls            #0xad5704
    //     0xad55c4: str             x1, [THR, #0x60]  ; THR::top
    //     0xad55c8: sub             x1, x1, #0xf
    //     0xad55cc: mov             x2, #0xd108
    //     0xad55d0: movk            x2, #3, lsl #16
    //     0xad55d4: stur            x2, [x1, #-1]
    // 0xad55d8: StoreField: r1->field_7 = d0
    //     0xad55d8: stur            d0, [x1, #7]
    // 0xad55dc: StoreField: r0->field_17 = r1
    //     0xad55dc: stur            w1, [x0, #0x17]
    // 0xad55e0: r17 = "⋯"
    //     0xad55e0: add             x17, PP, #0x22, lsl #12  ; [pp+0x22188] "⋯"
    //     0xad55e4: ldr             x17, [x17, #0x188]
    // 0xad55e8: StoreField: r0->field_1b = r17
    //     0xad55e8: stur            w17, [x0, #0x1b]
    // 0xad55ec: LoadField: d0 = r3->field_13
    //     0xad55ec: ldur            d0, [x3, #0x13]
    // 0xad55f0: r1 = inline_Allocate_Double()
    //     0xad55f0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xad55f4: add             x1, x1, #0x10
    //     0xad55f8: cmp             x2, x1
    //     0xad55fc: b.ls            #0xad5720
    //     0xad5600: str             x1, [THR, #0x60]  ; THR::top
    //     0xad5604: sub             x1, x1, #0xf
    //     0xad5608: mov             x2, #0xd108
    //     0xad560c: movk            x2, #3, lsl #16
    //     0xad5610: stur            x2, [x1, #-1]
    // 0xad5614: StoreField: r1->field_7 = d0
    //     0xad5614: stur            d0, [x1, #7]
    // 0xad5618: StoreField: r0->field_1f = r1
    //     0xad5618: stur            w1, [x0, #0x1f]
    // 0xad561c: r17 = ")➩"
    //     0xad561c: add             x17, PP, #0x22, lsl #12  ; [pp+0x22190] ")➩"
    //     0xad5620: ldr             x17, [x17, #0x190]
    // 0xad5624: StoreField: r0->field_23 = r17
    //     0xad5624: stur            w17, [x0, #0x23]
    // 0xad5628: ldur            x1, [fp, #-8]
    // 0xad562c: StoreField: r0->field_27 = r1
    //     0xad562c: stur            w1, [x0, #0x27]
    // 0xad5630: SaveReg r0
    //     0xad5630: str             x0, [SP, #-8]!
    // 0xad5634: r0 = _interpolate()
    //     0xad5634: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5638: add             SP, SP, #8
    // 0xad563c: LeaveFrame
    //     0xad563c: mov             SP, fp
    //     0xad5640: ldp             fp, lr, [SP], #0x10
    // 0xad5644: ret
    //     0xad5644: ret             
    // 0xad5648: mov             x3, x0
    // 0xad564c: r1 = Null
    //     0xad564c: mov             x1, NULL
    // 0xad5650: r2 = 12
    //     0xad5650: mov             x2, #0xc
    // 0xad5654: r0 = AllocateArray()
    //     0xad5654: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5658: r17 = "Interval"
    //     0xad5658: add             x17, PP, #0x22, lsl #12  ; [pp+0x22180] "Interval"
    //     0xad565c: ldr             x17, [x17, #0x180]
    // 0xad5660: StoreField: r0->field_f = r17
    //     0xad5660: stur            w17, [x0, #0xf]
    // 0xad5664: r17 = "("
    //     0xad5664: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad5668: StoreField: r0->field_13 = r17
    //     0xad5668: stur            w17, [x0, #0x13]
    // 0xad566c: ldr             x1, [fp, #0x10]
    // 0xad5670: LoadField: d0 = r1->field_b
    //     0xad5670: ldur            d0, [x1, #0xb]
    // 0xad5674: r2 = inline_Allocate_Double()
    //     0xad5674: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad5678: add             x2, x2, #0x10
    //     0xad567c: cmp             x3, x2
    //     0xad5680: b.ls            #0xad573c
    //     0xad5684: str             x2, [THR, #0x60]  ; THR::top
    //     0xad5688: sub             x2, x2, #0xf
    //     0xad568c: mov             x3, #0xd108
    //     0xad5690: movk            x3, #3, lsl #16
    //     0xad5694: stur            x3, [x2, #-1]
    // 0xad5698: StoreField: r2->field_7 = d0
    //     0xad5698: stur            d0, [x2, #7]
    // 0xad569c: StoreField: r0->field_17 = r2
    //     0xad569c: stur            w2, [x0, #0x17]
    // 0xad56a0: r17 = "⋯"
    //     0xad56a0: add             x17, PP, #0x22, lsl #12  ; [pp+0x22188] "⋯"
    //     0xad56a4: ldr             x17, [x17, #0x188]
    // 0xad56a8: StoreField: r0->field_1b = r17
    //     0xad56a8: stur            w17, [x0, #0x1b]
    // 0xad56ac: LoadField: d0 = r1->field_13
    //     0xad56ac: ldur            d0, [x1, #0x13]
    // 0xad56b0: r1 = inline_Allocate_Double()
    //     0xad56b0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xad56b4: add             x1, x1, #0x10
    //     0xad56b8: cmp             x2, x1
    //     0xad56bc: b.ls            #0xad5758
    //     0xad56c0: str             x1, [THR, #0x60]  ; THR::top
    //     0xad56c4: sub             x1, x1, #0xf
    //     0xad56c8: mov             x2, #0xd108
    //     0xad56cc: movk            x2, #3, lsl #16
    //     0xad56d0: stur            x2, [x1, #-1]
    // 0xad56d4: StoreField: r1->field_7 = d0
    //     0xad56d4: stur            d0, [x1, #7]
    // 0xad56d8: StoreField: r0->field_1f = r1
    //     0xad56d8: stur            w1, [x0, #0x1f]
    // 0xad56dc: r17 = ")"
    //     0xad56dc: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad56e0: StoreField: r0->field_23 = r17
    //     0xad56e0: stur            w17, [x0, #0x23]
    // 0xad56e4: SaveReg r0
    //     0xad56e4: str             x0, [SP, #-8]!
    // 0xad56e8: r0 = _interpolate()
    //     0xad56e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad56ec: add             SP, SP, #8
    // 0xad56f0: LeaveFrame
    //     0xad56f0: mov             SP, fp
    //     0xad56f4: ldp             fp, lr, [SP], #0x10
    // 0xad56f8: ret
    //     0xad56f8: ret             
    // 0xad56fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad56fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5700: b               #0xad5564
    // 0xad5704: SaveReg d0
    //     0xad5704: str             q0, [SP, #-0x10]!
    // 0xad5708: stp             x0, x3, [SP, #-0x10]!
    // 0xad570c: r0 = AllocateDouble()
    //     0xad570c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad5710: mov             x1, x0
    // 0xad5714: ldp             x0, x3, [SP], #0x10
    // 0xad5718: RestoreReg d0
    //     0xad5718: ldr             q0, [SP], #0x10
    // 0xad571c: b               #0xad55d8
    // 0xad5720: SaveReg d0
    //     0xad5720: str             q0, [SP, #-0x10]!
    // 0xad5724: SaveReg r0
    //     0xad5724: str             x0, [SP, #-8]!
    // 0xad5728: r0 = AllocateDouble()
    //     0xad5728: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad572c: mov             x1, x0
    // 0xad5730: RestoreReg r0
    //     0xad5730: ldr             x0, [SP], #8
    // 0xad5734: RestoreReg d0
    //     0xad5734: ldr             q0, [SP], #0x10
    // 0xad5738: b               #0xad5614
    // 0xad573c: SaveReg d0
    //     0xad573c: str             q0, [SP, #-0x10]!
    // 0xad5740: stp             x0, x1, [SP, #-0x10]!
    // 0xad5744: r0 = AllocateDouble()
    //     0xad5744: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad5748: mov             x2, x0
    // 0xad574c: ldp             x0, x1, [SP], #0x10
    // 0xad5750: RestoreReg d0
    //     0xad5750: ldr             q0, [SP], #0x10
    // 0xad5754: b               #0xad5698
    // 0xad5758: SaveReg d0
    //     0xad5758: str             q0, [SP, #-0x10]!
    // 0xad575c: SaveReg r0
    //     0xad575c: str             x0, [SP, #-8]!
    // 0xad5760: r0 = AllocateDouble()
    //     0xad5760: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad5764: mov             x1, x0
    // 0xad5768: RestoreReg r0
    //     0xad5768: ldr             x0, [SP], #8
    // 0xad576c: RestoreReg d0
    //     0xad576c: ldr             q0, [SP], #0x10
    // 0xad5770: b               #0xad56d4
  }
  _ transformInternal(/* No info */) {
    // ** addr: 0xbeaf00, size: 0x108
    // 0xbeaf00: EnterFrame
    //     0xbeaf00: stp             fp, lr, [SP, #-0x10]!
    //     0xbeaf04: mov             fp, SP
    // 0xbeaf08: d0 = 0.000000
    //     0xbeaf08: eor             v0.16b, v0.16b, v0.16b
    // 0xbeaf0c: CheckStackOverflow
    //     0xbeaf0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbeaf10: cmp             SP, x16
    //     0xbeaf14: b.ls            #0xbeaff0
    // 0xbeaf18: ldr             x0, [fp, #0x18]
    // 0xbeaf1c: LoadField: d1 = r0->field_b
    //     0xbeaf1c: ldur            d1, [x0, #0xb]
    // 0xbeaf20: ldr             d2, [fp, #0x10]
    // 0xbeaf24: fsub            d3, d2, d1
    // 0xbeaf28: LoadField: d2 = r0->field_13
    //     0xbeaf28: ldur            d2, [x0, #0x13]
    // 0xbeaf2c: fsub            d4, d2, d1
    // 0xbeaf30: fdiv            d1, d3, d4
    // 0xbeaf34: fcmp            d1, d0
    // 0xbeaf38: b.vs            #0xbeaf4c
    // 0xbeaf3c: b.ge            #0xbeaf4c
    // 0xbeaf40: d1 = 0.000000
    //     0xbeaf40: eor             v1.16b, v1.16b, v1.16b
    // 0xbeaf44: d2 = 1.000000
    //     0xbeaf44: fmov            d2, #1.00000000
    // 0xbeaf48: b               #0xbeaf70
    // 0xbeaf4c: d2 = 1.000000
    //     0xbeaf4c: fmov            d2, #1.00000000
    // 0xbeaf50: fcmp            d1, d2
    // 0xbeaf54: b.vs            #0xbeaf64
    // 0xbeaf58: b.le            #0xbeaf64
    // 0xbeaf5c: d1 = 1.000000
    //     0xbeaf5c: fmov            d1, #1.00000000
    // 0xbeaf60: b               #0xbeaf70
    // 0xbeaf64: fcmp            d1, d1
    // 0xbeaf68: b.vc            #0xbeaf70
    // 0xbeaf6c: d1 = 1.000000
    //     0xbeaf6c: fmov            d1, #1.00000000
    // 0xbeaf70: fcmp            d1, d0
    // 0xbeaf74: b.vs            #0xbeaf7c
    // 0xbeaf78: b.eq            #0xbeaf88
    // 0xbeaf7c: fcmp            d1, d2
    // 0xbeaf80: b.vs            #0xbeafbc
    // 0xbeaf84: b.ne            #0xbeafbc
    // 0xbeaf88: r0 = inline_Allocate_Double()
    //     0xbeaf88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeaf8c: add             x0, x0, #0x10
    //     0xbeaf90: cmp             x1, x0
    //     0xbeaf94: b.ls            #0xbeaff8
    //     0xbeaf98: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeaf9c: sub             x0, x0, #0xf
    //     0xbeafa0: mov             x1, #0xd108
    //     0xbeafa4: movk            x1, #3, lsl #16
    //     0xbeafa8: stur            x1, [x0, #-1]
    // 0xbeafac: StoreField: r0->field_7 = d1
    //     0xbeafac: stur            d1, [x0, #7]
    // 0xbeafb0: LeaveFrame
    //     0xbeafb0: mov             SP, fp
    //     0xbeafb4: ldp             fp, lr, [SP], #0x10
    // 0xbeafb8: ret
    //     0xbeafb8: ret             
    // 0xbeafbc: LoadField: r1 = r0->field_1b
    //     0xbeafbc: ldur            w1, [x0, #0x1b]
    // 0xbeafc0: DecompressPointer r1
    //     0xbeafc0: add             x1, x1, HEAP, lsl #32
    // 0xbeafc4: r0 = LoadClassIdInstr(r1)
    //     0xbeafc4: ldur            x0, [x1, #-1]
    //     0xbeafc8: ubfx            x0, x0, #0xc, #0x14
    // 0xbeafcc: SaveReg r1
    //     0xbeafcc: str             x1, [SP, #-8]!
    // 0xbeafd0: SaveReg d1
    //     0xbeafd0: str             d1, [SP, #-8]!
    // 0xbeafd4: r0 = GDT[cid_x0 + 0x87f]()
    //     0xbeafd4: add             lr, x0, #0x87f
    //     0xbeafd8: ldr             lr, [x21, lr, lsl #3]
    //     0xbeafdc: blr             lr
    // 0xbeafe0: add             SP, SP, #0x10
    // 0xbeafe4: LeaveFrame
    //     0xbeafe4: mov             SP, fp
    //     0xbeafe8: ldp             fp, lr, [SP], #0x10
    // 0xbeafec: ret
    //     0xbeafec: ret             
    // 0xbeaff0: r0 = StackOverflowSharedWithFPURegs()
    //     0xbeaff0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbeaff4: b               #0xbeaf18
    // 0xbeaff8: SaveReg d1
    //     0xbeaff8: str             q1, [SP, #-0x10]!
    // 0xbeaffc: r0 = AllocateDouble()
    //     0xbeaffc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeb000: RestoreReg d1
    //     0xbeb000: ldr             q1, [SP], #0x10
    // 0xbeb004: b               #0xbeafac
  }
}

// class id: 4292, size: 0x14, field offset: 0xc
//   const constructor, 
class SawTooth extends Curve {

  _Mint field_c;

  _ toString(/* No info */) {
    // ** addr: 0xad54e0, size: 0x6c
    // 0xad54e0: EnterFrame
    //     0xad54e0: stp             fp, lr, [SP, #-0x10]!
    //     0xad54e4: mov             fp, SP
    // 0xad54e8: CheckStackOverflow
    //     0xad54e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad54ec: cmp             SP, x16
    //     0xad54f0: b.ls            #0xad5544
    // 0xad54f4: r1 = Null
    //     0xad54f4: mov             x1, NULL
    // 0xad54f8: r2 = 8
    //     0xad54f8: mov             x2, #8
    // 0xad54fc: r0 = AllocateArray()
    //     0xad54fc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5500: r17 = "SawTooth"
    //     0xad5500: add             x17, PP, #0x22, lsl #12  ; [pp+0x22198] "SawTooth"
    //     0xad5504: ldr             x17, [x17, #0x198]
    // 0xad5508: StoreField: r0->field_f = r17
    //     0xad5508: stur            w17, [x0, #0xf]
    // 0xad550c: r17 = "("
    //     0xad550c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad5510: StoreField: r0->field_13 = r17
    //     0xad5510: stur            w17, [x0, #0x13]
    // 0xad5514: ldr             x1, [fp, #0x10]
    // 0xad5518: LoadField: r2 = r1->field_b
    //     0xad5518: ldur            x2, [x1, #0xb]
    // 0xad551c: lsl             x1, x2, #1
    // 0xad5520: StoreField: r0->field_17 = r1
    //     0xad5520: stur            w1, [x0, #0x17]
    // 0xad5524: r17 = ")"
    //     0xad5524: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad5528: StoreField: r0->field_1b = r17
    //     0xad5528: stur            w17, [x0, #0x1b]
    // 0xad552c: SaveReg r0
    //     0xad552c: str             x0, [SP, #-8]!
    // 0xad5530: r0 = _interpolate()
    //     0xad5530: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5534: add             SP, SP, #8
    // 0xad5538: LeaveFrame
    //     0xad5538: mov             SP, fp
    //     0xad553c: ldp             fp, lr, [SP], #0x10
    // 0xad5540: ret
    //     0xad5540: ret             
    // 0xad5544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5544: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5548: b               #0xad54f4
  }
  _ transformInternal(/* No info */) {
    // ** addr: 0xbeae4c, size: 0xb4
    // 0xbeae4c: EnterFrame
    //     0xbeae4c: stp             fp, lr, [SP, #-0x10]!
    //     0xbeae50: mov             fp, SP
    // 0xbeae54: AllocStack(0x8)
    //     0xbeae54: sub             SP, SP, #8
    // 0xbeae58: ldr             x0, [fp, #0x18]
    // 0xbeae5c: LoadField: r1 = r0->field_b
    //     0xbeae5c: ldur            x1, [x0, #0xb]
    // 0xbeae60: lsl             x0, x1, #1
    // 0xbeae64: r16 = LoadInt32Instr(r0)
    //     0xbeae64: sbfx            x16, x0, #1, #0x1f
    // 0xbeae68: scvtf           d0, w16
    // 0xbeae6c: ldr             d1, [fp, #0x10]
    // 0xbeae70: fmul            d2, d1, d0
    // 0xbeae74: mov             v0.16b, v2.16b
    // 0xbeae78: stur            d2, [fp, #-8]
    // 0xbeae7c: stp             fp, lr, [SP, #-0x10]!
    // 0xbeae80: mov             fp, SP
    // 0xbeae84: CallRuntime_LibcTrunc(double) -> double
    //     0xbeae84: and             SP, SP, #0xfffffffffffffff0
    //     0xbeae88: mov             sp, SP
    //     0xbeae8c: ldr             x16, [THR, #0x570]  ; THR::LibcTrunc
    //     0xbeae90: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeae94: blr             x16
    //     0xbeae98: mov             x16, #8
    //     0xbeae9c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeaea0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbeaea4: sub             sp, x16, #1, lsl #12
    //     0xbeaea8: mov             SP, fp
    //     0xbeaeac: ldp             fp, lr, [SP], #0x10
    // 0xbeaeb0: mov             v1.16b, v0.16b
    // 0xbeaeb4: ldur            d0, [fp, #-8]
    // 0xbeaeb8: fsub            d2, d0, d1
    // 0xbeaebc: r0 = inline_Allocate_Double()
    //     0xbeaebc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeaec0: add             x0, x0, #0x10
    //     0xbeaec4: cmp             x1, x0
    //     0xbeaec8: b.ls            #0xbeaef0
    //     0xbeaecc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeaed0: sub             x0, x0, #0xf
    //     0xbeaed4: mov             x1, #0xd108
    //     0xbeaed8: movk            x1, #3, lsl #16
    //     0xbeaedc: stur            x1, [x0, #-1]
    // 0xbeaee0: StoreField: r0->field_7 = d2
    //     0xbeaee0: stur            d2, [x0, #7]
    // 0xbeaee4: LeaveFrame
    //     0xbeaee4: mov             SP, fp
    //     0xbeaee8: ldp             fp, lr, [SP], #0x10
    // 0xbeaeec: ret
    //     0xbeaeec: ret             
    // 0xbeaef0: SaveReg d2
    //     0xbeaef0: str             q2, [SP, #-0x10]!
    // 0xbeaef4: r0 = AllocateDouble()
    //     0xbeaef4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeaef8: RestoreReg d2
    //     0xbeaef8: ldr             q2, [SP], #0x10
    // 0xbeaefc: b               #0xbeaee0
  }
}

// class id: 4293, size: 0xc, field offset: 0xc
//   const constructor, 
class _Linear extends Curve {

  _ transformInternal(/* No info */) {
    // ** addr: 0xbeadfc, size: 0x50
    // 0xbeadfc: EnterFrame
    //     0xbeadfc: stp             fp, lr, [SP, #-0x10]!
    //     0xbeae00: mov             fp, SP
    // 0xbeae04: ldr             d0, [fp, #0x10]
    // 0xbeae08: r0 = inline_Allocate_Double()
    //     0xbeae08: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbeae0c: add             x0, x0, #0x10
    //     0xbeae10: cmp             x1, x0
    //     0xbeae14: b.ls            #0xbeae3c
    //     0xbeae18: str             x0, [THR, #0x60]  ; THR::top
    //     0xbeae1c: sub             x0, x0, #0xf
    //     0xbeae20: mov             x1, #0xd108
    //     0xbeae24: movk            x1, #3, lsl #16
    //     0xbeae28: stur            x1, [x0, #-1]
    // 0xbeae2c: StoreField: r0->field_7 = d0
    //     0xbeae2c: stur            d0, [x0, #7]
    // 0xbeae30: LeaveFrame
    //     0xbeae30: mov             SP, fp
    //     0xbeae34: ldp             fp, lr, [SP], #0x10
    // 0xbeae38: ret
    //     0xbeae38: ret             
    // 0xbeae3c: SaveReg d0
    //     0xbeae3c: str             q0, [SP, #-0x10]!
    // 0xbeae40: r0 = AllocateDouble()
    //     0xbeae40: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbeae44: RestoreReg d0
    //     0xbeae44: ldr             q0, [SP], #0x10
    // 0xbeae48: b               #0xbeae2c
  }
}

// lib: , url: package:flutter/src/animation/tween_sequence.dart

// class id: 1049072, size: 0x8
class :: {
}

// class id: 4252, size: 0x18, field offset: 0x8
//   const constructor, 
class _Interval extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad7468, size: 0xf4
    // 0xad7468: EnterFrame
    //     0xad7468: stp             fp, lr, [SP, #-0x10]!
    //     0xad746c: mov             fp, SP
    // 0xad7470: CheckStackOverflow
    //     0xad7470: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad7474: cmp             SP, x16
    //     0xad7478: b.ls            #0xad751c
    // 0xad747c: r1 = Null
    //     0xad747c: mov             x1, NULL
    // 0xad7480: r2 = 10
    //     0xad7480: mov             x2, #0xa
    // 0xad7484: r0 = AllocateArray()
    //     0xad7484: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad7488: r17 = "<"
    //     0xad7488: ldr             x17, [PP, #0x1100]  ; [pp+0x1100] "<"
    // 0xad748c: StoreField: r0->field_f = r17
    //     0xad748c: stur            w17, [x0, #0xf]
    // 0xad7490: ldr             x1, [fp, #0x10]
    // 0xad7494: LoadField: d0 = r1->field_7
    //     0xad7494: ldur            d0, [x1, #7]
    // 0xad7498: r2 = inline_Allocate_Double()
    //     0xad7498: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad749c: add             x2, x2, #0x10
    //     0xad74a0: cmp             x3, x2
    //     0xad74a4: b.ls            #0xad7524
    //     0xad74a8: str             x2, [THR, #0x60]  ; THR::top
    //     0xad74ac: sub             x2, x2, #0xf
    //     0xad74b0: mov             x3, #0xd108
    //     0xad74b4: movk            x3, #3, lsl #16
    //     0xad74b8: stur            x3, [x2, #-1]
    // 0xad74bc: StoreField: r2->field_7 = d0
    //     0xad74bc: stur            d0, [x2, #7]
    // 0xad74c0: StoreField: r0->field_13 = r2
    //     0xad74c0: stur            w2, [x0, #0x13]
    // 0xad74c4: r17 = ", "
    //     0xad74c4: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad74c8: StoreField: r0->field_17 = r17
    //     0xad74c8: stur            w17, [x0, #0x17]
    // 0xad74cc: LoadField: d0 = r1->field_f
    //     0xad74cc: ldur            d0, [x1, #0xf]
    // 0xad74d0: r1 = inline_Allocate_Double()
    //     0xad74d0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xad74d4: add             x1, x1, #0x10
    //     0xad74d8: cmp             x2, x1
    //     0xad74dc: b.ls            #0xad7540
    //     0xad74e0: str             x1, [THR, #0x60]  ; THR::top
    //     0xad74e4: sub             x1, x1, #0xf
    //     0xad74e8: mov             x2, #0xd108
    //     0xad74ec: movk            x2, #3, lsl #16
    //     0xad74f0: stur            x2, [x1, #-1]
    // 0xad74f4: StoreField: r1->field_7 = d0
    //     0xad74f4: stur            d0, [x1, #7]
    // 0xad74f8: StoreField: r0->field_1b = r1
    //     0xad74f8: stur            w1, [x0, #0x1b]
    // 0xad74fc: r17 = ">"
    //     0xad74fc: ldr             x17, [PP, #0x1068]  ; [pp+0x1068] ">"
    // 0xad7500: StoreField: r0->field_1f = r17
    //     0xad7500: stur            w17, [x0, #0x1f]
    // 0xad7504: SaveReg r0
    //     0xad7504: str             x0, [SP, #-8]!
    // 0xad7508: r0 = _interpolate()
    //     0xad7508: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad750c: add             SP, SP, #8
    // 0xad7510: LeaveFrame
    //     0xad7510: mov             SP, fp
    //     0xad7514: ldp             fp, lr, [SP], #0x10
    // 0xad7518: ret
    //     0xad7518: ret             
    // 0xad751c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad751c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad7520: b               #0xad747c
    // 0xad7524: SaveReg d0
    //     0xad7524: str             q0, [SP, #-0x10]!
    // 0xad7528: stp             x0, x1, [SP, #-0x10]!
    // 0xad752c: r0 = AllocateDouble()
    //     0xad752c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad7530: mov             x2, x0
    // 0xad7534: ldp             x0, x1, [SP], #0x10
    // 0xad7538: RestoreReg d0
    //     0xad7538: ldr             q0, [SP], #0x10
    // 0xad753c: b               #0xad74bc
    // 0xad7540: SaveReg d0
    //     0xad7540: str             q0, [SP, #-0x10]!
    // 0xad7544: SaveReg r0
    //     0xad7544: str             x0, [SP, #-8]!
    // 0xad7548: r0 = AllocateDouble()
    //     0xad7548: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad754c: mov             x1, x0
    // 0xad7550: RestoreReg r0
    //     0xad7550: ldr             x0, [SP], #8
    // 0xad7554: RestoreReg d0
    //     0xad7554: ldr             q0, [SP], #0x10
    // 0xad7558: b               #0xad74f4
  }
}

// class id: 4253, size: 0x18, field offset: 0x8
//   const constructor, 
class TweenSequenceItem<X0> extends Object {
}

// class id: 4255, size: 0x14, field offset: 0xc
class TweenSequence<X0> extends Animatable<X0> {

  _ TweenSequence(/* No info */) {
    // ** addr: 0x7b7778, size: 0x370
    // 0x7b7778: EnterFrame
    //     0x7b7778: stp             fp, lr, [SP, #-0x10]!
    //     0x7b777c: mov             fp, SP
    // 0x7b7780: AllocStack(0x58)
    //     0x7b7780: sub             SP, SP, #0x58
    // 0x7b7784: CheckStackOverflow
    //     0x7b7784: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7788: cmp             SP, x16
    //     0x7b778c: b.ls            #0x7b7ac8
    // 0x7b7790: ldr             x0, [fp, #0x18]
    // 0x7b7794: LoadField: r2 = r0->field_7
    //     0x7b7794: ldur            w2, [x0, #7]
    // 0x7b7798: DecompressPointer r2
    //     0x7b7798: add             x2, x2, HEAP, lsl #32
    // 0x7b779c: r1 = Null
    //     0x7b779c: mov             x1, NULL
    // 0x7b77a0: r3 = <TweenSequenceItem<X0>>
    //     0x7b77a0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e3f0] TypeArguments: <TweenSequenceItem<X0>>
    //     0x7b77a4: ldr             x3, [x3, #0x3f0]
    // 0x7b77a8: r24 = InstantiateTypeArgumentsStub
    //     0x7b77a8: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x7b77ac: LoadField: r30 = r24->field_7
    //     0x7b77ac: ldur            lr, [x24, #7]
    // 0x7b77b0: blr             lr
    // 0x7b77b4: stur            x0, [fp, #-8]
    // 0x7b77b8: stp             xzr, x0, [SP, #-0x10]!
    // 0x7b77bc: r0 = _GrowableList()
    //     0x7b77bc: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7b77c0: add             SP, SP, #0x10
    // 0x7b77c4: mov             x2, x0
    // 0x7b77c8: ldr             x1, [fp, #0x18]
    // 0x7b77cc: stur            x2, [fp, #-0x10]
    // 0x7b77d0: StoreField: r1->field_b = r0
    //     0x7b77d0: stur            w0, [x1, #0xb]
    //     0x7b77d4: ldurb           w16, [x1, #-1]
    //     0x7b77d8: ldurb           w17, [x0, #-1]
    //     0x7b77dc: and             x16, x17, x16, lsr #2
    //     0x7b77e0: tst             x16, HEAP, lsr #32
    //     0x7b77e4: b.eq            #0x7b77ec
    //     0x7b77e8: bl              #0xd6826c
    // 0x7b77ec: r16 = <_Interval>
    //     0x7b77ec: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e3f8] TypeArguments: <_Interval>
    //     0x7b77f0: ldr             x16, [x16, #0x3f8]
    // 0x7b77f4: stp             xzr, x16, [SP, #-0x10]!
    // 0x7b77f8: r0 = _GrowableList()
    //     0x7b77f8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7b77fc: add             SP, SP, #0x10
    // 0x7b7800: mov             x2, x0
    // 0x7b7804: ldr             x1, [fp, #0x18]
    // 0x7b7808: stur            x2, [fp, #-0x18]
    // 0x7b780c: StoreField: r1->field_f = r0
    //     0x7b780c: stur            w0, [x1, #0xf]
    //     0x7b7810: ldurb           w16, [x1, #-1]
    //     0x7b7814: ldurb           w17, [x0, #-1]
    //     0x7b7818: and             x16, x17, x16, lsr #2
    //     0x7b781c: tst             x16, HEAP, lsr #32
    //     0x7b7820: b.eq            #0x7b7828
    //     0x7b7824: bl              #0xd6826c
    // 0x7b7828: ldur            x16, [fp, #-0x10]
    // 0x7b782c: ldr             lr, [fp, #0x10]
    // 0x7b7830: stp             lr, x16, [SP, #-0x10]!
    // 0x7b7834: r0 = addAll()
    //     0x7b7834: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x7b7838: add             SP, SP, #0x10
    // 0x7b783c: ldur            x1, [fp, #-0x10]
    // 0x7b7840: LoadField: r0 = r1->field_b
    //     0x7b7840: ldur            w0, [x1, #0xb]
    // 0x7b7844: DecompressPointer r0
    //     0x7b7844: add             x0, x0, HEAP, lsl #32
    // 0x7b7848: r2 = LoadInt32Instr(r0)
    //     0x7b7848: sbfx            x2, x0, #1, #0x1f
    // 0x7b784c: stur            x2, [fp, #-0x28]
    // 0x7b7850: d0 = 0.000000
    //     0x7b7850: eor             v0.16b, v0.16b, v0.16b
    // 0x7b7854: r3 = 0
    //     0x7b7854: mov             x3, #0
    // 0x7b7858: stur            x3, [fp, #-0x20]
    // 0x7b785c: stur            d0, [fp, #-0x48]
    // 0x7b7860: CheckStackOverflow
    //     0x7b7860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7864: cmp             SP, x16
    //     0x7b7868: b.ls            #0x7b7ad0
    // 0x7b786c: r0 = LoadClassIdInstr(r1)
    //     0x7b786c: ldur            x0, [x1, #-1]
    //     0x7b7870: ubfx            x0, x0, #0xc, #0x14
    // 0x7b7874: SaveReg r1
    //     0x7b7874: str             x1, [SP, #-8]!
    // 0x7b7878: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7b7878: mov             x17, #0xb8ea
    //     0x7b787c: add             lr, x0, x17
    //     0x7b7880: ldr             lr, [x21, lr, lsl #3]
    //     0x7b7884: blr             lr
    // 0x7b7888: add             SP, SP, #8
    // 0x7b788c: r1 = LoadInt32Instr(r0)
    //     0x7b788c: sbfx            x1, x0, #1, #0x1f
    //     0x7b7890: tbz             w0, #0, #0x7b7898
    //     0x7b7894: ldur            x1, [x0, #7]
    // 0x7b7898: ldur            x2, [fp, #-0x28]
    // 0x7b789c: cmp             x2, x1
    // 0x7b78a0: b.ne            #0x7b7ab0
    // 0x7b78a4: ldur            x3, [fp, #-0x10]
    // 0x7b78a8: ldur            x4, [fp, #-0x20]
    // 0x7b78ac: cmp             x4, x1
    // 0x7b78b0: b.lt            #0x7b7a00
    // 0x7b78b4: ldur            x2, [fp, #-0x18]
    // 0x7b78b8: d1 = 0.000000
    //     0x7b78b8: eor             v1.16b, v1.16b, v1.16b
    // 0x7b78bc: r4 = 0
    //     0x7b78bc: mov             x4, #0
    // 0x7b78c0: ldur            d0, [fp, #-0x48]
    // 0x7b78c4: stur            x4, [fp, #-0x30]
    // 0x7b78c8: stur            d1, [fp, #-0x58]
    // 0x7b78cc: CheckStackOverflow
    //     0x7b78cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b78d0: cmp             SP, x16
    //     0x7b78d4: b.ls            #0x7b7ad8
    // 0x7b78d8: LoadField: r0 = r3->field_b
    //     0x7b78d8: ldur            w0, [x3, #0xb]
    // 0x7b78dc: DecompressPointer r0
    //     0x7b78dc: add             x0, x0, HEAP, lsl #32
    // 0x7b78e0: r1 = LoadInt32Instr(r0)
    //     0x7b78e0: sbfx            x1, x0, #1, #0x1f
    // 0x7b78e4: cmp             x4, x1
    // 0x7b78e8: b.ge            #0x7b79f0
    // 0x7b78ec: sub             x0, x1, #1
    // 0x7b78f0: cmp             x4, x0
    // 0x7b78f4: b.ne            #0x7b7900
    // 0x7b78f8: d2 = 1.000000
    //     0x7b78f8: fmov            d2, #1.00000000
    // 0x7b78fc: b               #0x7b7930
    // 0x7b7900: mov             x0, x1
    // 0x7b7904: mov             x1, x4
    // 0x7b7908: cmp             x1, x0
    // 0x7b790c: b.hs            #0x7b7ae0
    // 0x7b7910: LoadField: r0 = r3->field_f
    //     0x7b7910: ldur            w0, [x3, #0xf]
    // 0x7b7914: DecompressPointer r0
    //     0x7b7914: add             x0, x0, HEAP, lsl #32
    // 0x7b7918: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x7b7918: add             x16, x0, x4, lsl #2
    //     0x7b791c: ldur            w1, [x16, #0xf]
    // 0x7b7920: DecompressPointer r1
    //     0x7b7920: add             x1, x1, HEAP, lsl #32
    // 0x7b7924: LoadField: d2 = r1->field_f
    //     0x7b7924: ldur            d2, [x1, #0xf]
    // 0x7b7928: fdiv            d3, d2, d0
    // 0x7b792c: fadd            d2, d1, d3
    // 0x7b7930: stur            d2, [fp, #-0x50]
    // 0x7b7934: r0 = _Interval()
    //     0x7b7934: bl              #0x7b7ae8  ; Allocate_IntervalStub -> _Interval (size=0x18)
    // 0x7b7938: ldur            d0, [fp, #-0x58]
    // 0x7b793c: stur            x0, [fp, #-0x40]
    // 0x7b7940: StoreField: r0->field_7 = d0
    //     0x7b7940: stur            d0, [x0, #7]
    // 0x7b7944: ldur            d1, [fp, #-0x50]
    // 0x7b7948: StoreField: r0->field_f = d1
    //     0x7b7948: stur            d1, [x0, #0xf]
    // 0x7b794c: ldur            x1, [fp, #-0x18]
    // 0x7b7950: LoadField: r2 = r1->field_b
    //     0x7b7950: ldur            w2, [x1, #0xb]
    // 0x7b7954: DecompressPointer r2
    //     0x7b7954: add             x2, x2, HEAP, lsl #32
    // 0x7b7958: stur            x2, [fp, #-0x38]
    // 0x7b795c: LoadField: r3 = r1->field_f
    //     0x7b795c: ldur            w3, [x1, #0xf]
    // 0x7b7960: DecompressPointer r3
    //     0x7b7960: add             x3, x3, HEAP, lsl #32
    // 0x7b7964: LoadField: r4 = r3->field_b
    //     0x7b7964: ldur            w4, [x3, #0xb]
    // 0x7b7968: DecompressPointer r4
    //     0x7b7968: add             x4, x4, HEAP, lsl #32
    // 0x7b796c: cmp             w2, w4
    // 0x7b7970: b.ne            #0x7b7980
    // 0x7b7974: SaveReg r1
    //     0x7b7974: str             x1, [SP, #-8]!
    // 0x7b7978: r0 = _growToNextCapacity()
    //     0x7b7978: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7b797c: add             SP, SP, #8
    // 0x7b7980: ldur            x3, [fp, #-0x18]
    // 0x7b7984: ldur            x2, [fp, #-0x30]
    // 0x7b7988: ldur            x0, [fp, #-0x38]
    // 0x7b798c: r4 = LoadInt32Instr(r0)
    //     0x7b798c: sbfx            x4, x0, #1, #0x1f
    // 0x7b7990: add             x0, x4, #1
    // 0x7b7994: lsl             x1, x0, #1
    // 0x7b7998: StoreField: r3->field_b = r1
    //     0x7b7998: stur            w1, [x3, #0xb]
    // 0x7b799c: mov             x1, x4
    // 0x7b79a0: cmp             x1, x0
    // 0x7b79a4: b.hs            #0x7b7ae4
    // 0x7b79a8: LoadField: r1 = r3->field_f
    //     0x7b79a8: ldur            w1, [x3, #0xf]
    // 0x7b79ac: DecompressPointer r1
    //     0x7b79ac: add             x1, x1, HEAP, lsl #32
    // 0x7b79b0: ldur            x0, [fp, #-0x40]
    // 0x7b79b4: ArrayStore: r1[r4] = r0  ; List_4
    //     0x7b79b4: add             x25, x1, x4, lsl #2
    //     0x7b79b8: add             x25, x25, #0xf
    //     0x7b79bc: str             w0, [x25]
    //     0x7b79c0: tbz             w0, #0, #0x7b79dc
    //     0x7b79c4: ldurb           w16, [x1, #-1]
    //     0x7b79c8: ldurb           w17, [x0, #-1]
    //     0x7b79cc: and             x16, x17, x16, lsr #2
    //     0x7b79d0: tst             x16, HEAP, lsr #32
    //     0x7b79d4: b.eq            #0x7b79dc
    //     0x7b79d8: bl              #0xd67e5c
    // 0x7b79dc: add             x4, x2, #1
    // 0x7b79e0: ldur            d1, [fp, #-0x50]
    // 0x7b79e4: mov             x2, x3
    // 0x7b79e8: ldur            x3, [fp, #-0x10]
    // 0x7b79ec: b               #0x7b78c0
    // 0x7b79f0: r0 = Null
    //     0x7b79f0: mov             x0, NULL
    // 0x7b79f4: LeaveFrame
    //     0x7b79f4: mov             SP, fp
    //     0x7b79f8: ldp             fp, lr, [SP], #0x10
    // 0x7b79fc: ret
    //     0x7b79fc: ret             
    // 0x7b7a00: mov             x5, x3
    // 0x7b7a04: ldur            x3, [fp, #-0x18]
    // 0x7b7a08: r0 = BoxInt64Instr(r4)
    //     0x7b7a08: sbfiz           x0, x4, #1, #0x1f
    //     0x7b7a0c: cmp             x4, x0, asr #1
    //     0x7b7a10: b.eq            #0x7b7a1c
    //     0x7b7a14: bl              #0xd69bb8
    //     0x7b7a18: stur            x4, [x0, #7]
    // 0x7b7a1c: r1 = LoadClassIdInstr(r5)
    //     0x7b7a1c: ldur            x1, [x5, #-1]
    //     0x7b7a20: ubfx            x1, x1, #0xc, #0x14
    // 0x7b7a24: stp             x0, x5, [SP, #-0x10]!
    // 0x7b7a28: mov             x0, x1
    // 0x7b7a2c: r0 = GDT[cid_x0 + 0xd175]()
    //     0x7b7a2c: mov             x17, #0xd175
    //     0x7b7a30: add             lr, x0, x17
    //     0x7b7a34: ldr             lr, [x21, lr, lsl #3]
    //     0x7b7a38: blr             lr
    // 0x7b7a3c: add             SP, SP, #0x10
    // 0x7b7a40: mov             x3, x0
    // 0x7b7a44: ldur            x0, [fp, #-0x20]
    // 0x7b7a48: stur            x3, [fp, #-0x38]
    // 0x7b7a4c: add             x4, x0, #1
    // 0x7b7a50: stur            x4, [fp, #-0x30]
    // 0x7b7a54: cmp             w3, NULL
    // 0x7b7a58: b.ne            #0x7b7a8c
    // 0x7b7a5c: mov             x0, x3
    // 0x7b7a60: ldur            x2, [fp, #-8]
    // 0x7b7a64: r1 = Null
    //     0x7b7a64: mov             x1, NULL
    // 0x7b7a68: cmp             w2, NULL
    // 0x7b7a6c: b.eq            #0x7b7a8c
    // 0x7b7a70: LoadField: r4 = r2->field_17
    //     0x7b7a70: ldur            w4, [x2, #0x17]
    // 0x7b7a74: DecompressPointer r4
    //     0x7b7a74: add             x4, x4, HEAP, lsl #32
    // 0x7b7a78: r8 = X0
    //     0x7b7a78: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x7b7a7c: LoadField: r9 = r4->field_7
    //     0x7b7a7c: ldur            x9, [x4, #7]
    // 0x7b7a80: r3 = Null
    //     0x7b7a80: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e400] Null
    //     0x7b7a84: ldr             x3, [x3, #0x400]
    // 0x7b7a88: blr             x9
    // 0x7b7a8c: ldur            d0, [fp, #-0x48]
    // 0x7b7a90: ldur            x0, [fp, #-0x38]
    // 0x7b7a94: LoadField: d1 = r0->field_f
    //     0x7b7a94: ldur            d1, [x0, #0xf]
    // 0x7b7a98: fadd            d2, d0, d1
    // 0x7b7a9c: mov             v0.16b, v2.16b
    // 0x7b7aa0: ldur            x3, [fp, #-0x30]
    // 0x7b7aa4: ldur            x1, [fp, #-0x10]
    // 0x7b7aa8: ldur            x2, [fp, #-0x28]
    // 0x7b7aac: b               #0x7b7858
    // 0x7b7ab0: ldur            x0, [fp, #-0x10]
    // 0x7b7ab4: r0 = ConcurrentModificationError()
    //     0x7b7ab4: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x7b7ab8: ldur            x3, [fp, #-0x10]
    // 0x7b7abc: StoreField: r0->field_b = r3
    //     0x7b7abc: stur            w3, [x0, #0xb]
    // 0x7b7ac0: r0 = Throw()
    //     0x7b7ac0: bl              #0xd67e38  ; ThrowStub
    // 0x7b7ac4: brk             #0
    // 0x7b7ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7ac8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b7acc: b               #0x7b7790
    // 0x7b7ad0: r0 = StackOverflowSharedWithFPURegs()
    //     0x7b7ad0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x7b7ad4: b               #0x7b786c
    // 0x7b7ad8: r0 = StackOverflowSharedWithFPURegs()
    //     0x7b7ad8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x7b7adc: b               #0x7b78d8
    // 0x7b7ae0: r0 = RangeErrorSharedWithFPURegs()
    //     0x7b7ae0: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x7b7ae4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7b7ae4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0xad73f8, size: 0x70
    // 0xad73f8: EnterFrame
    //     0xad73f8: stp             fp, lr, [SP, #-0x10]!
    //     0xad73fc: mov             fp, SP
    // 0xad7400: CheckStackOverflow
    //     0xad7400: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad7404: cmp             SP, x16
    //     0xad7408: b.ls            #0xad7460
    // 0xad740c: r1 = Null
    //     0xad740c: mov             x1, NULL
    // 0xad7410: r2 = 6
    //     0xad7410: mov             x2, #6
    // 0xad7414: r0 = AllocateArray()
    //     0xad7414: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad7418: r17 = "TweenSequence("
    //     0xad7418: add             x17, PP, #0x37, lsl #12  ; [pp+0x37d20] "TweenSequence("
    //     0xad741c: ldr             x17, [x17, #0xd20]
    // 0xad7420: StoreField: r0->field_f = r17
    //     0xad7420: stur            w17, [x0, #0xf]
    // 0xad7424: ldr             x1, [fp, #0x10]
    // 0xad7428: LoadField: r2 = r1->field_b
    //     0xad7428: ldur            w2, [x1, #0xb]
    // 0xad742c: DecompressPointer r2
    //     0xad742c: add             x2, x2, HEAP, lsl #32
    // 0xad7430: LoadField: r1 = r2->field_b
    //     0xad7430: ldur            w1, [x2, #0xb]
    // 0xad7434: DecompressPointer r1
    //     0xad7434: add             x1, x1, HEAP, lsl #32
    // 0xad7438: StoreField: r0->field_13 = r1
    //     0xad7438: stur            w1, [x0, #0x13]
    // 0xad743c: r17 = " items)"
    //     0xad743c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37d28] " items)"
    //     0xad7440: ldr             x17, [x17, #0xd28]
    // 0xad7444: StoreField: r0->field_17 = r17
    //     0xad7444: stur            w17, [x0, #0x17]
    // 0xad7448: SaveReg r0
    //     0xad7448: str             x0, [SP, #-8]!
    // 0xad744c: r0 = _interpolate()
    //     0xad744c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad7450: add             SP, SP, #8
    // 0xad7454: LeaveFrame
    //     0xad7454: mov             SP, fp
    //     0xad7458: ldp             fp, lr, [SP], #0x10
    // 0xad745c: ret
    //     0xad745c: ret             
    // 0xad7460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad7460: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad7464: b               #0xad740c
  }
  _ transform(/* No info */) {
    // ** addr: 0xc09f14, size: 0x238
    // 0xc09f14: EnterFrame
    //     0xc09f14: stp             fp, lr, [SP, #-0x10]!
    //     0xc09f18: mov             fp, SP
    // 0xc09f1c: AllocStack(0x8)
    //     0xc09f1c: sub             SP, SP, #8
    // 0xc09f20: d0 = 1.000000
    //     0xc09f20: fmov            d0, #1.00000000
    // 0xc09f24: CheckStackOverflow
    //     0xc09f24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc09f28: cmp             SP, x16
    //     0xc09f2c: b.ls            #0xc0a0ec
    // 0xc09f30: ldr             d1, [fp, #0x10]
    // 0xc09f34: fcmp            d1, d0
    // 0xc09f38: b.vs            #0xc09fa0
    // 0xc09f3c: b.ne            #0xc09fa0
    // 0xc09f40: ldr             x2, [fp, #0x18]
    // 0xc09f44: LoadField: r0 = r2->field_b
    //     0xc09f44: ldur            w0, [x2, #0xb]
    // 0xc09f48: DecompressPointer r0
    //     0xc09f48: add             x0, x0, HEAP, lsl #32
    // 0xc09f4c: LoadField: r1 = r0->field_b
    //     0xc09f4c: ldur            w1, [x0, #0xb]
    // 0xc09f50: DecompressPointer r1
    //     0xc09f50: add             x1, x1, HEAP, lsl #32
    // 0xc09f54: r0 = LoadInt32Instr(r1)
    //     0xc09f54: sbfx            x0, x1, #1, #0x1f
    // 0xc09f58: sub             x1, x0, #1
    // 0xc09f5c: r0 = inline_Allocate_Double()
    //     0xc09f5c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xc09f60: add             x0, x0, #0x10
    //     0xc09f64: cmp             x3, x0
    //     0xc09f68: b.ls            #0xc0a0f4
    //     0xc09f6c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc09f70: sub             x0, x0, #0xf
    //     0xc09f74: mov             x3, #0xd108
    //     0xc09f78: movk            x3, #3, lsl #16
    //     0xc09f7c: stur            x3, [x0, #-1]
    // 0xc09f80: StoreField: r0->field_7 = d1
    //     0xc09f80: stur            d1, [x0, #7]
    // 0xc09f84: stp             x0, x2, [SP, #-0x10]!
    // 0xc09f88: SaveReg r1
    //     0xc09f88: str             x1, [SP, #-8]!
    // 0xc09f8c: r0 = _evaluateAt()
    //     0xc09f8c: bl              #0xc0a14c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::_evaluateAt
    // 0xc09f90: add             SP, SP, #0x18
    // 0xc09f94: LeaveFrame
    //     0xc09f94: mov             SP, fp
    //     0xc09f98: ldp             fp, lr, [SP], #0x10
    // 0xc09f9c: ret
    //     0xc09f9c: ret             
    // 0xc09fa0: ldr             x2, [fp, #0x18]
    // 0xc09fa4: LoadField: r0 = r2->field_b
    //     0xc09fa4: ldur            w0, [x2, #0xb]
    // 0xc09fa8: DecompressPointer r0
    //     0xc09fa8: add             x0, x0, HEAP, lsl #32
    // 0xc09fac: LoadField: r1 = r0->field_b
    //     0xc09fac: ldur            w1, [x0, #0xb]
    // 0xc09fb0: DecompressPointer r1
    //     0xc09fb0: add             x1, x1, HEAP, lsl #32
    // 0xc09fb4: r3 = LoadInt32Instr(r1)
    //     0xc09fb4: sbfx            x3, x1, #1, #0x1f
    // 0xc09fb8: LoadField: r0 = r2->field_f
    //     0xc09fb8: ldur            w0, [x2, #0xf]
    // 0xc09fbc: DecompressPointer r0
    //     0xc09fbc: add             x0, x0, HEAP, lsl #32
    // 0xc09fc0: LoadField: r1 = r0->field_b
    //     0xc09fc0: ldur            w1, [x0, #0xb]
    // 0xc09fc4: DecompressPointer r1
    //     0xc09fc4: add             x1, x1, HEAP, lsl #32
    // 0xc09fc8: r4 = LoadInt32Instr(r1)
    //     0xc09fc8: sbfx            x4, x1, #1, #0x1f
    // 0xc09fcc: LoadField: r5 = r0->field_f
    //     0xc09fcc: ldur            w5, [x0, #0xf]
    // 0xc09fd0: DecompressPointer r5
    //     0xc09fd0: add             x5, x5, HEAP, lsl #32
    // 0xc09fd4: r6 = 0
    //     0xc09fd4: mov             x6, #0
    // 0xc09fd8: CheckStackOverflow
    //     0xc09fd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc09fdc: cmp             SP, x16
    //     0xc09fe0: b.ls            #0xc0a10c
    // 0xc09fe4: cmp             x6, x3
    // 0xc09fe8: b.ge            #0xc0a078
    // 0xc09fec: mov             x0, x4
    // 0xc09ff0: mov             x1, x6
    // 0xc09ff4: cmp             x1, x0
    // 0xc09ff8: b.hs            #0xc0a114
    // 0xc09ffc: ArrayLoad: r0 = r5[r6]  ; Unknown_4
    //     0xc09ffc: add             x16, x5, x6, lsl #2
    //     0xc0a000: ldur            w0, [x16, #0xf]
    // 0xc0a004: DecompressPointer r0
    //     0xc0a004: add             x0, x0, HEAP, lsl #32
    // 0xc0a008: LoadField: d0 = r0->field_7
    //     0xc0a008: ldur            d0, [x0, #7]
    // 0xc0a00c: fcmp            d1, d0
    // 0xc0a010: b.vs            #0xc0a06c
    // 0xc0a014: b.lt            #0xc0a06c
    // 0xc0a018: LoadField: d0 = r0->field_f
    //     0xc0a018: ldur            d0, [x0, #0xf]
    // 0xc0a01c: fcmp            d1, d0
    // 0xc0a020: b.vs            #0xc0a06c
    // 0xc0a024: b.ge            #0xc0a06c
    // 0xc0a028: r0 = inline_Allocate_Double()
    //     0xc0a028: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc0a02c: add             x0, x0, #0x10
    //     0xc0a030: cmp             x1, x0
    //     0xc0a034: b.ls            #0xc0a118
    //     0xc0a038: str             x0, [THR, #0x60]  ; THR::top
    //     0xc0a03c: sub             x0, x0, #0xf
    //     0xc0a040: mov             x1, #0xd108
    //     0xc0a044: movk            x1, #3, lsl #16
    //     0xc0a048: stur            x1, [x0, #-1]
    // 0xc0a04c: StoreField: r0->field_7 = d1
    //     0xc0a04c: stur            d1, [x0, #7]
    // 0xc0a050: stp             x0, x2, [SP, #-0x10]!
    // 0xc0a054: SaveReg r6
    //     0xc0a054: str             x6, [SP, #-8]!
    // 0xc0a058: r0 = _evaluateAt()
    //     0xc0a058: bl              #0xc0a14c  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::_evaluateAt
    // 0xc0a05c: add             SP, SP, #0x18
    // 0xc0a060: LeaveFrame
    //     0xc0a060: mov             SP, fp
    //     0xc0a064: ldp             fp, lr, [SP], #0x10
    // 0xc0a068: ret
    //     0xc0a068: ret             
    // 0xc0a06c: add             x0, x6, #1
    // 0xc0a070: mov             x6, x0
    // 0xc0a074: b               #0xc09fd8
    // 0xc0a078: r1 = Null
    //     0xc0a078: mov             x1, NULL
    // 0xc0a07c: r2 = 4
    //     0xc0a07c: mov             x2, #4
    // 0xc0a080: r0 = AllocateArray()
    //     0xc0a080: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc0a084: r17 = "TweenSequence.evaluate() could not find an interval for "
    //     0xc0a084: add             x17, PP, #0x37, lsl #12  ; [pp+0x37d30] "TweenSequence.evaluate() could not find an interval for "
    //     0xc0a088: ldr             x17, [x17, #0xd30]
    // 0xc0a08c: StoreField: r0->field_f = r17
    //     0xc0a08c: stur            w17, [x0, #0xf]
    // 0xc0a090: ldr             d0, [fp, #0x10]
    // 0xc0a094: r1 = inline_Allocate_Double()
    //     0xc0a094: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc0a098: add             x1, x1, #0x10
    //     0xc0a09c: cmp             x2, x1
    //     0xc0a0a0: b.ls            #0xc0a130
    //     0xc0a0a4: str             x1, [THR, #0x60]  ; THR::top
    //     0xc0a0a8: sub             x1, x1, #0xf
    //     0xc0a0ac: mov             x2, #0xd108
    //     0xc0a0b0: movk            x2, #3, lsl #16
    //     0xc0a0b4: stur            x2, [x1, #-1]
    // 0xc0a0b8: StoreField: r1->field_7 = d0
    //     0xc0a0b8: stur            d0, [x1, #7]
    // 0xc0a0bc: StoreField: r0->field_13 = r1
    //     0xc0a0bc: stur            w1, [x0, #0x13]
    // 0xc0a0c0: SaveReg r0
    //     0xc0a0c0: str             x0, [SP, #-8]!
    // 0xc0a0c4: r0 = _interpolate()
    //     0xc0a0c4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc0a0c8: add             SP, SP, #8
    // 0xc0a0cc: stur            x0, [fp, #-8]
    // 0xc0a0d0: r0 = StateError()
    //     0xc0a0d0: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc0a0d4: mov             x1, x0
    // 0xc0a0d8: ldur            x0, [fp, #-8]
    // 0xc0a0dc: StoreField: r1->field_b = r0
    //     0xc0a0dc: stur            w0, [x1, #0xb]
    // 0xc0a0e0: mov             x0, x1
    // 0xc0a0e4: r0 = Throw()
    //     0xc0a0e4: bl              #0xd67e38  ; ThrowStub
    // 0xc0a0e8: brk             #0
    // 0xc0a0ec: r0 = StackOverflowSharedWithFPURegs()
    //     0xc0a0ec: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc0a0f0: b               #0xc09f30
    // 0xc0a0f4: SaveReg d1
    //     0xc0a0f4: str             q1, [SP, #-0x10]!
    // 0xc0a0f8: stp             x1, x2, [SP, #-0x10]!
    // 0xc0a0fc: r0 = AllocateDouble()
    //     0xc0a0fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc0a100: ldp             x1, x2, [SP], #0x10
    // 0xc0a104: RestoreReg d1
    //     0xc0a104: ldr             q1, [SP], #0x10
    // 0xc0a108: b               #0xc09f80
    // 0xc0a10c: r0 = StackOverflowSharedWithFPURegs()
    //     0xc0a10c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc0a110: b               #0xc09fe4
    // 0xc0a114: r0 = RangeErrorSharedWithFPURegs()
    //     0xc0a114: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0xc0a118: SaveReg d1
    //     0xc0a118: str             q1, [SP, #-0x10]!
    // 0xc0a11c: stp             x2, x6, [SP, #-0x10]!
    // 0xc0a120: r0 = AllocateDouble()
    //     0xc0a120: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc0a124: ldp             x2, x6, [SP], #0x10
    // 0xc0a128: RestoreReg d1
    //     0xc0a128: ldr             q1, [SP], #0x10
    // 0xc0a12c: b               #0xc0a04c
    // 0xc0a130: SaveReg d0
    //     0xc0a130: str             q0, [SP, #-0x10]!
    // 0xc0a134: SaveReg r0
    //     0xc0a134: str             x0, [SP, #-8]!
    // 0xc0a138: r0 = AllocateDouble()
    //     0xc0a138: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc0a13c: mov             x1, x0
    // 0xc0a140: RestoreReg r0
    //     0xc0a140: ldr             x0, [SP], #8
    // 0xc0a144: RestoreReg d0
    //     0xc0a144: ldr             q0, [SP], #0x10
    // 0xc0a148: b               #0xc0a0b8
  }
  _ _evaluateAt(/* No info */) {
    // ** addr: 0xc0a14c, size: 0xf0
    // 0xc0a14c: EnterFrame
    //     0xc0a14c: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a150: mov             fp, SP
    // 0xc0a154: CheckStackOverflow
    //     0xc0a154: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0a158: cmp             SP, x16
    //     0xc0a15c: b.ls            #0xc0a22c
    // 0xc0a160: ldr             x2, [fp, #0x20]
    // 0xc0a164: LoadField: r3 = r2->field_b
    //     0xc0a164: ldur            w3, [x2, #0xb]
    // 0xc0a168: DecompressPointer r3
    //     0xc0a168: add             x3, x3, HEAP, lsl #32
    // 0xc0a16c: LoadField: r0 = r3->field_b
    //     0xc0a16c: ldur            w0, [x3, #0xb]
    // 0xc0a170: DecompressPointer r0
    //     0xc0a170: add             x0, x0, HEAP, lsl #32
    // 0xc0a174: r1 = LoadInt32Instr(r0)
    //     0xc0a174: sbfx            x1, x0, #1, #0x1f
    // 0xc0a178: mov             x0, x1
    // 0xc0a17c: ldr             x1, [fp, #0x10]
    // 0xc0a180: cmp             x1, x0
    // 0xc0a184: b.hs            #0xc0a234
    // 0xc0a188: LoadField: r0 = r3->field_f
    //     0xc0a188: ldur            w0, [x3, #0xf]
    // 0xc0a18c: DecompressPointer r0
    //     0xc0a18c: add             x0, x0, HEAP, lsl #32
    // 0xc0a190: ldr             x3, [fp, #0x10]
    // 0xc0a194: ArrayLoad: r4 = r0[r3]  ; Unknown_4
    //     0xc0a194: add             x16, x0, x3, lsl #2
    //     0xc0a198: ldur            w4, [x16, #0xf]
    // 0xc0a19c: DecompressPointer r4
    //     0xc0a19c: add             x4, x4, HEAP, lsl #32
    // 0xc0a1a0: LoadField: r5 = r2->field_f
    //     0xc0a1a0: ldur            w5, [x2, #0xf]
    // 0xc0a1a4: DecompressPointer r5
    //     0xc0a1a4: add             x5, x5, HEAP, lsl #32
    // 0xc0a1a8: LoadField: r0 = r5->field_b
    //     0xc0a1a8: ldur            w0, [x5, #0xb]
    // 0xc0a1ac: DecompressPointer r0
    //     0xc0a1ac: add             x0, x0, HEAP, lsl #32
    // 0xc0a1b0: r1 = LoadInt32Instr(r0)
    //     0xc0a1b0: sbfx            x1, x0, #1, #0x1f
    // 0xc0a1b4: mov             x0, x1
    // 0xc0a1b8: mov             x1, x3
    // 0xc0a1bc: cmp             x1, x0
    // 0xc0a1c0: b.hs            #0xc0a238
    // 0xc0a1c4: LoadField: r0 = r5->field_f
    //     0xc0a1c4: ldur            w0, [x5, #0xf]
    // 0xc0a1c8: DecompressPointer r0
    //     0xc0a1c8: add             x0, x0, HEAP, lsl #32
    // 0xc0a1cc: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xc0a1cc: add             x16, x0, x3, lsl #2
    //     0xc0a1d0: ldur            w1, [x16, #0xf]
    // 0xc0a1d4: DecompressPointer r1
    //     0xc0a1d4: add             x1, x1, HEAP, lsl #32
    // 0xc0a1d8: LoadField: d0 = r1->field_7
    //     0xc0a1d8: ldur            d0, [x1, #7]
    // 0xc0a1dc: ldr             x0, [fp, #0x18]
    // 0xc0a1e0: LoadField: d1 = r0->field_7
    //     0xc0a1e0: ldur            d1, [x0, #7]
    // 0xc0a1e4: fsub            d2, d1, d0
    // 0xc0a1e8: LoadField: d1 = r1->field_f
    //     0xc0a1e8: ldur            d1, [x1, #0xf]
    // 0xc0a1ec: fsub            d3, d1, d0
    // 0xc0a1f0: fdiv            d0, d2, d3
    // 0xc0a1f4: LoadField: r0 = r4->field_b
    //     0xc0a1f4: ldur            w0, [x4, #0xb]
    // 0xc0a1f8: DecompressPointer r0
    //     0xc0a1f8: add             x0, x0, HEAP, lsl #32
    // 0xc0a1fc: r1 = LoadClassIdInstr(r0)
    //     0xc0a1fc: ldur            x1, [x0, #-1]
    //     0xc0a200: ubfx            x1, x1, #0xc, #0x14
    // 0xc0a204: SaveReg r0
    //     0xc0a204: str             x0, [SP, #-8]!
    // 0xc0a208: SaveReg d0
    //     0xc0a208: str             d0, [SP, #-8]!
    // 0xc0a20c: mov             x0, x1
    // 0xc0a210: r0 = GDT[cid_x0 + 0xd31]()
    //     0xc0a210: add             lr, x0, #0xd31
    //     0xc0a214: ldr             lr, [x21, lr, lsl #3]
    //     0xc0a218: blr             lr
    // 0xc0a21c: add             SP, SP, #0x10
    // 0xc0a220: LeaveFrame
    //     0xc0a220: mov             SP, fp
    //     0xc0a224: ldp             fp, lr, [SP], #0x10
    // 0xc0a228: ret
    //     0xc0a228: ret             
    // 0xc0a22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a22c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a230: b               #0xc0a160
    // 0xc0a234: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc0a234: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc0a238: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc0a238: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

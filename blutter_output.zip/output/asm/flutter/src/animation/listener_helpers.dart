// lib: , url: package:flutter/src/animation/listener_helpers.dart

// class id: 1049070, size: 0x8
class :: {
}

// class id: 4294, size: 0x8, field offset: 0x8
abstract class AnimationLazyListenerMixin extends Object {
}

// class id: 4308, size: 0x8, field offset: 0x8
abstract class AnimationLocalStatusListenersMixin extends Object {
}

// class id: 4309, size: 0x8, field offset: 0x8
abstract class AnimationLocalListenersMixin extends Object {
}

// class id: 4310, size: 0x8, field offset: 0x8
abstract class AnimationEagerListenerMixin extends Object {
}

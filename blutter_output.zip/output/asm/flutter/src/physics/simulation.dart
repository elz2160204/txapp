// lib: , url: package:flutter/src/physics/simulation.dart

// class id: 1049389, size: 0x8
class :: {
}

// class id: 4296, size: 0xc, field offset: 0x8
abstract class Simulation extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xad54d4, size: 0xc
    // 0xad54d4: r0 = "Simulation"
    //     0xad54d4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe7b0] "Simulation"
    //     0xad54d8: ldr             x0, [x0, #0x7b0]
    // 0xad54dc: ret
    //     0xad54dc: ret             
  }
}

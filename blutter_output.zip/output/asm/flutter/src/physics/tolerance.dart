// lib: , url: package:flutter/src/physics/tolerance.dart

// class id: 1049391, size: 0x8
class :: {
}

// class id: 2067, size: 0x20, field offset: 0x8
//   const constructor, 
class Tolerance extends Object {

  _Double field_8;
  _Double field_10;
  _Double field_18;

  _ toString(/* No info */) {
    // ** addr: 0xae34d0, size: 0x160
    // 0xae34d0: EnterFrame
    //     0xae34d0: stp             fp, lr, [SP, #-0x10]!
    //     0xae34d4: mov             fp, SP
    // 0xae34d8: CheckStackOverflow
    //     0xae34d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae34dc: cmp             SP, x16
    //     0xae34e0: b.ls            #0xae35d4
    // 0xae34e4: r1 = Null
    //     0xae34e4: mov             x1, NULL
    // 0xae34e8: r2 = 16
    //     0xae34e8: mov             x2, #0x10
    // 0xae34ec: r0 = AllocateArray()
    //     0xae34ec: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae34f0: r17 = "Tolerance"
    //     0xae34f0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe790] "Tolerance"
    //     0xae34f4: ldr             x17, [x17, #0x790]
    // 0xae34f8: StoreField: r0->field_f = r17
    //     0xae34f8: stur            w17, [x0, #0xf]
    // 0xae34fc: r17 = "(distance: ±"
    //     0xae34fc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe798] "(distance: ±"
    //     0xae3500: ldr             x17, [x17, #0x798]
    // 0xae3504: StoreField: r0->field_13 = r17
    //     0xae3504: stur            w17, [x0, #0x13]
    // 0xae3508: ldr             x1, [fp, #0x10]
    // 0xae350c: LoadField: d0 = r1->field_7
    //     0xae350c: ldur            d0, [x1, #7]
    // 0xae3510: r2 = inline_Allocate_Double()
    //     0xae3510: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae3514: add             x2, x2, #0x10
    //     0xae3518: cmp             x3, x2
    //     0xae351c: b.ls            #0xae35dc
    //     0xae3520: str             x2, [THR, #0x60]  ; THR::top
    //     0xae3524: sub             x2, x2, #0xf
    //     0xae3528: mov             x3, #0xd108
    //     0xae352c: movk            x3, #3, lsl #16
    //     0xae3530: stur            x3, [x2, #-1]
    // 0xae3534: StoreField: r2->field_7 = d0
    //     0xae3534: stur            d0, [x2, #7]
    // 0xae3538: StoreField: r0->field_17 = r2
    //     0xae3538: stur            w2, [x0, #0x17]
    // 0xae353c: r17 = ", time: ±"
    //     0xae353c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7a0] ", time: ±"
    //     0xae3540: ldr             x17, [x17, #0x7a0]
    // 0xae3544: StoreField: r0->field_1b = r17
    //     0xae3544: stur            w17, [x0, #0x1b]
    // 0xae3548: LoadField: d0 = r1->field_f
    //     0xae3548: ldur            d0, [x1, #0xf]
    // 0xae354c: r2 = inline_Allocate_Double()
    //     0xae354c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae3550: add             x2, x2, #0x10
    //     0xae3554: cmp             x3, x2
    //     0xae3558: b.ls            #0xae35f8
    //     0xae355c: str             x2, [THR, #0x60]  ; THR::top
    //     0xae3560: sub             x2, x2, #0xf
    //     0xae3564: mov             x3, #0xd108
    //     0xae3568: movk            x3, #3, lsl #16
    //     0xae356c: stur            x3, [x2, #-1]
    // 0xae3570: StoreField: r2->field_7 = d0
    //     0xae3570: stur            d0, [x2, #7]
    // 0xae3574: StoreField: r0->field_1f = r2
    //     0xae3574: stur            w2, [x0, #0x1f]
    // 0xae3578: r17 = ", velocity: ±"
    //     0xae3578: add             x17, PP, #0xe, lsl #12  ; [pp+0xe7a8] ", velocity: ±"
    //     0xae357c: ldr             x17, [x17, #0x7a8]
    // 0xae3580: StoreField: r0->field_23 = r17
    //     0xae3580: stur            w17, [x0, #0x23]
    // 0xae3584: LoadField: d0 = r1->field_17
    //     0xae3584: ldur            d0, [x1, #0x17]
    // 0xae3588: r1 = inline_Allocate_Double()
    //     0xae3588: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xae358c: add             x1, x1, #0x10
    //     0xae3590: cmp             x2, x1
    //     0xae3594: b.ls            #0xae3614
    //     0xae3598: str             x1, [THR, #0x60]  ; THR::top
    //     0xae359c: sub             x1, x1, #0xf
    //     0xae35a0: mov             x2, #0xd108
    //     0xae35a4: movk            x2, #3, lsl #16
    //     0xae35a8: stur            x2, [x1, #-1]
    // 0xae35ac: StoreField: r1->field_7 = d0
    //     0xae35ac: stur            d0, [x1, #7]
    // 0xae35b0: StoreField: r0->field_27 = r1
    //     0xae35b0: stur            w1, [x0, #0x27]
    // 0xae35b4: r17 = ")"
    //     0xae35b4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae35b8: StoreField: r0->field_2b = r17
    //     0xae35b8: stur            w17, [x0, #0x2b]
    // 0xae35bc: SaveReg r0
    //     0xae35bc: str             x0, [SP, #-8]!
    // 0xae35c0: r0 = _interpolate()
    //     0xae35c0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae35c4: add             SP, SP, #8
    // 0xae35c8: LeaveFrame
    //     0xae35c8: mov             SP, fp
    //     0xae35cc: ldp             fp, lr, [SP], #0x10
    // 0xae35d0: ret
    //     0xae35d0: ret             
    // 0xae35d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae35d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae35d8: b               #0xae34e4
    // 0xae35dc: SaveReg d0
    //     0xae35dc: str             q0, [SP, #-0x10]!
    // 0xae35e0: stp             x0, x1, [SP, #-0x10]!
    // 0xae35e4: r0 = AllocateDouble()
    //     0xae35e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae35e8: mov             x2, x0
    // 0xae35ec: ldp             x0, x1, [SP], #0x10
    // 0xae35f0: RestoreReg d0
    //     0xae35f0: ldr             q0, [SP], #0x10
    // 0xae35f4: b               #0xae3534
    // 0xae35f8: SaveReg d0
    //     0xae35f8: str             q0, [SP, #-0x10]!
    // 0xae35fc: stp             x0, x1, [SP, #-0x10]!
    // 0xae3600: r0 = AllocateDouble()
    //     0xae3600: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae3604: mov             x2, x0
    // 0xae3608: ldp             x0, x1, [SP], #0x10
    // 0xae360c: RestoreReg d0
    //     0xae360c: ldr             q0, [SP], #0x10
    // 0xae3610: b               #0xae3570
    // 0xae3614: SaveReg d0
    //     0xae3614: str             q0, [SP, #-0x10]!
    // 0xae3618: SaveReg r0
    //     0xae3618: str             x0, [SP, #-8]!
    // 0xae361c: r0 = AllocateDouble()
    //     0xae361c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae3620: mov             x1, x0
    // 0xae3624: RestoreReg r0
    //     0xae3624: ldr             x0, [SP], #8
    // 0xae3628: RestoreReg d0
    //     0xae3628: ldr             q0, [SP], #0x10
    // 0xae362c: b               #0xae35ac
  }
}

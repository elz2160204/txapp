// lib: , url: package:flutter/src/physics/friction_simulation.dart

// class id: 1049387, size: 0x8
class :: {

  static _ _newtonsMethod(/* No info */) {
    // ** addr: 0xc61d58, size: 0x170
    // 0xc61d58: EnterFrame
    //     0xc61d58: stp             fp, lr, [SP, #-0x10]!
    //     0xc61d5c: mov             fp, SP
    // 0xc61d60: AllocStack(0x20)
    //     0xc61d60: sub             SP, SP, #0x20
    // 0xc61d64: CheckStackOverflow
    //     0xc61d64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc61d68: cmp             SP, x16
    //     0xc61d6c: b.ls            #0xc61e7c
    // 0xc61d70: d1 = 0.000000
    //     0xc61d70: eor             v1.16b, v1.16b, v1.16b
    // 0xc61d74: r1 = 0
    //     0xc61d74: mov             x1, #0
    // 0xc61d78: ldr             d0, [fp, #0x10]
    // 0xc61d7c: stur            x1, [fp, #-0x10]
    // 0xc61d80: stur            d1, [fp, #-0x18]
    // 0xc61d84: CheckStackOverflow
    //     0xc61d84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc61d88: cmp             SP, x16
    //     0xc61d8c: b.ls            #0xc61e84
    // 0xc61d90: cmp             x1, #0xa
    // 0xc61d94: b.ge            #0xc61e6c
    // 0xc61d98: r2 = inline_Allocate_Double()
    //     0xc61d98: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xc61d9c: add             x2, x2, #0x10
    //     0xc61da0: cmp             x0, x2
    //     0xc61da4: b.ls            #0xc61e8c
    //     0xc61da8: str             x2, [THR, #0x60]  ; THR::top
    //     0xc61dac: sub             x2, x2, #0xf
    //     0xc61db0: mov             x0, #0xd108
    //     0xc61db4: movk            x0, #3, lsl #16
    //     0xc61db8: stur            x0, [x2, #-1]
    // 0xc61dbc: StoreField: r2->field_7 = d1
    //     0xc61dbc: stur            d1, [x2, #7]
    // 0xc61dc0: stur            x2, [fp, #-8]
    // 0xc61dc4: ldr             x16, [fp, #0x18]
    // 0xc61dc8: stp             x2, x16, [SP, #-0x10]!
    // 0xc61dcc: ldr             x0, [fp, #0x18]
    // 0xc61dd0: ClosureCall
    //     0xc61dd0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc61dd4: ldur            x2, [x0, #0x1f]
    //     0xc61dd8: blr             x2
    // 0xc61ddc: add             SP, SP, #0x10
    // 0xc61de0: cmp             w0, NULL
    // 0xc61de4: b.eq            #0xc61ea8
    // 0xc61de8: LoadField: d0 = r0->field_7
    //     0xc61de8: ldur            d0, [x0, #7]
    // 0xc61dec: ldr             d1, [fp, #0x10]
    // 0xc61df0: fsub            d2, d0, d1
    // 0xc61df4: stur            d2, [fp, #-0x20]
    // 0xc61df8: ldr             x16, [fp, #0x20]
    // 0xc61dfc: ldur            lr, [fp, #-8]
    // 0xc61e00: stp             lr, x16, [SP, #-0x10]!
    // 0xc61e04: ldr             x0, [fp, #0x20]
    // 0xc61e08: ClosureCall
    //     0xc61e08: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc61e0c: ldur            x2, [x0, #0x1f]
    //     0xc61e10: blr             x2
    // 0xc61e14: add             SP, SP, #0x10
    // 0xc61e18: ldur            d0, [fp, #-0x20]
    // 0xc61e1c: r1 = inline_Allocate_Double()
    //     0xc61e1c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc61e20: add             x1, x1, #0x10
    //     0xc61e24: cmp             x2, x1
    //     0xc61e28: b.ls            #0xc61eac
    //     0xc61e2c: str             x1, [THR, #0x60]  ; THR::top
    //     0xc61e30: sub             x1, x1, #0xf
    //     0xc61e34: mov             x2, #0xd108
    //     0xc61e38: movk            x2, #3, lsl #16
    //     0xc61e3c: stur            x2, [x1, #-1]
    // 0xc61e40: StoreField: r1->field_7 = d0
    //     0xc61e40: stur            d0, [x1, #7]
    // 0xc61e44: stp             x0, x1, [SP, #-0x10]!
    // 0xc61e48: r0 = /()
    //     0xc61e48: bl              #0xd66e78  ; [dart:core] _Double::/
    // 0xc61e4c: add             SP, SP, #0x10
    // 0xc61e50: LoadField: d1 = r0->field_7
    //     0xc61e50: ldur            d1, [x0, #7]
    // 0xc61e54: ldur            d0, [fp, #-0x18]
    // 0xc61e58: fsub            d2, d0, d1
    // 0xc61e5c: ldur            x0, [fp, #-0x10]
    // 0xc61e60: add             x1, x0, #1
    // 0xc61e64: mov             v1.16b, v2.16b
    // 0xc61e68: b               #0xc61d78
    // 0xc61e6c: mov             v0.16b, v1.16b
    // 0xc61e70: LeaveFrame
    //     0xc61e70: mov             SP, fp
    //     0xc61e74: ldp             fp, lr, [SP], #0x10
    // 0xc61e78: ret
    //     0xc61e78: ret             
    // 0xc61e7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc61e7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc61e80: b               #0xc61d70
    // 0xc61e84: r0 = StackOverflowSharedWithFPURegs()
    //     0xc61e84: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc61e88: b               #0xc61d90
    // 0xc61e8c: stp             q0, q1, [SP, #-0x20]!
    // 0xc61e90: SaveReg r1
    //     0xc61e90: str             x1, [SP, #-8]!
    // 0xc61e94: r0 = AllocateDouble()
    //     0xc61e94: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc61e98: mov             x2, x0
    // 0xc61e9c: RestoreReg r1
    //     0xc61e9c: ldr             x1, [SP], #8
    // 0xc61ea0: ldp             q0, q1, [SP], #0x20
    // 0xc61ea4: b               #0xc61dbc
    // 0xc61ea8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc61ea8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xc61eac: SaveReg d0
    //     0xc61eac: str             q0, [SP, #-0x10]!
    // 0xc61eb0: SaveReg r0
    //     0xc61eb0: str             x0, [SP, #-8]!
    // 0xc61eb4: r0 = AllocateDouble()
    //     0xc61eb4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc61eb8: mov             x1, x0
    // 0xc61ebc: RestoreReg r0
    //     0xc61ebc: ldr             x0, [SP], #8
    // 0xc61ec0: RestoreReg d0
    //     0xc61ec0: ldr             q0, [SP], #0x10
    // 0xc61ec4: b               #0xc61e40
  }
}

// class id: 4305, size: 0x3c, field offset: 0xc
class FrictionSimulation extends Simulation {

  _ toString(/* No info */) {
    // ** addr: 0xad4ee4, size: 0x1dc
    // 0xad4ee4: EnterFrame
    //     0xad4ee4: stp             fp, lr, [SP, #-0x10]!
    //     0xad4ee8: mov             fp, SP
    // 0xad4eec: AllocStack(0x8)
    //     0xad4eec: sub             SP, SP, #8
    // 0xad4ef0: CheckStackOverflow
    //     0xad4ef0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4ef4: cmp             SP, x16
    //     0xad4ef8: b.ls            #0xad5084
    // 0xad4efc: r1 = Null
    //     0xad4efc: mov             x1, NULL
    // 0xad4f00: r2 = 16
    //     0xad4f00: mov             x2, #0x10
    // 0xad4f04: r0 = AllocateArray()
    //     0xad4f04: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad4f08: stur            x0, [fp, #-8]
    // 0xad4f0c: r17 = "FrictionSimulation"
    //     0xad4f0c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3e8] "FrictionSimulation"
    //     0xad4f10: ldr             x17, [x17, #0x3e8]
    // 0xad4f14: StoreField: r0->field_f = r17
    //     0xad4f14: stur            w17, [x0, #0xf]
    // 0xad4f18: r17 = "(cₓ: "
    //     0xad4f18: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3f0] "(cₓ: "
    //     0xad4f1c: ldr             x17, [x17, #0x3f0]
    // 0xad4f20: StoreField: r0->field_13 = r17
    //     0xad4f20: stur            w17, [x0, #0x13]
    // 0xad4f24: r16 = 0.135000
    //     0xad4f24: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b3f8] 0.135
    //     0xad4f28: ldr             x16, [x16, #0x3f8]
    // 0xad4f2c: SaveReg r16
    //     0xad4f2c: str             x16, [SP, #-8]!
    // 0xad4f30: r1 = 1
    //     0xad4f30: mov             x1, #1
    // 0xad4f34: SaveReg r1
    //     0xad4f34: str             x1, [SP, #-8]!
    // 0xad4f38: r0 = toStringAsFixed()
    //     0xad4f38: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad4f3c: add             SP, SP, #0x10
    // 0xad4f40: ldur            x1, [fp, #-8]
    // 0xad4f44: ArrayStore: r1[2] = r0  ; List_4
    //     0xad4f44: add             x25, x1, #0x17
    //     0xad4f48: str             w0, [x25]
    //     0xad4f4c: tbz             w0, #0, #0xad4f68
    //     0xad4f50: ldurb           w16, [x1, #-1]
    //     0xad4f54: ldurb           w17, [x0, #-1]
    //     0xad4f58: and             x16, x17, x16, lsr #2
    //     0xad4f5c: tst             x16, HEAP, lsr #32
    //     0xad4f60: b.eq            #0xad4f68
    //     0xad4f64: bl              #0xd67e5c
    // 0xad4f68: ldur            x1, [fp, #-8]
    // 0xad4f6c: r17 = ", x₀: "
    //     0xad4f6c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b400] ", x₀: "
    //     0xad4f70: ldr             x17, [x17, #0x400]
    // 0xad4f74: StoreField: r1->field_1b = r17
    //     0xad4f74: stur            w17, [x1, #0x1b]
    // 0xad4f78: ldr             x0, [fp, #0x10]
    // 0xad4f7c: LoadField: d0 = r0->field_1b
    //     0xad4f7c: ldur            d0, [x0, #0x1b]
    // 0xad4f80: r2 = inline_Allocate_Double()
    //     0xad4f80: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad4f84: add             x2, x2, #0x10
    //     0xad4f88: cmp             x3, x2
    //     0xad4f8c: b.ls            #0xad508c
    //     0xad4f90: str             x2, [THR, #0x60]  ; THR::top
    //     0xad4f94: sub             x2, x2, #0xf
    //     0xad4f98: mov             x3, #0xd108
    //     0xad4f9c: movk            x3, #3, lsl #16
    //     0xad4fa0: stur            x3, [x2, #-1]
    // 0xad4fa4: StoreField: r2->field_7 = d0
    //     0xad4fa4: stur            d0, [x2, #7]
    // 0xad4fa8: SaveReg r2
    //     0xad4fa8: str             x2, [SP, #-8]!
    // 0xad4fac: r2 = 1
    //     0xad4fac: mov             x2, #1
    // 0xad4fb0: SaveReg r2
    //     0xad4fb0: str             x2, [SP, #-8]!
    // 0xad4fb4: r0 = toStringAsFixed()
    //     0xad4fb4: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad4fb8: add             SP, SP, #0x10
    // 0xad4fbc: ldur            x1, [fp, #-8]
    // 0xad4fc0: ArrayStore: r1[4] = r0  ; List_4
    //     0xad4fc0: add             x25, x1, #0x1f
    //     0xad4fc4: str             w0, [x25]
    //     0xad4fc8: tbz             w0, #0, #0xad4fe4
    //     0xad4fcc: ldurb           w16, [x1, #-1]
    //     0xad4fd0: ldurb           w17, [x0, #-1]
    //     0xad4fd4: and             x16, x17, x16, lsr #2
    //     0xad4fd8: tst             x16, HEAP, lsr #32
    //     0xad4fdc: b.eq            #0xad4fe4
    //     0xad4fe0: bl              #0xd67e5c
    // 0xad4fe4: ldur            x1, [fp, #-8]
    // 0xad4fe8: r17 = ", dx₀: "
    //     0xad4fe8: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b408] ", dx₀: "
    //     0xad4fec: ldr             x17, [x17, #0x408]
    // 0xad4ff0: StoreField: r1->field_23 = r17
    //     0xad4ff0: stur            w17, [x1, #0x23]
    // 0xad4ff4: ldr             x0, [fp, #0x10]
    // 0xad4ff8: LoadField: d0 = r0->field_23
    //     0xad4ff8: ldur            d0, [x0, #0x23]
    // 0xad4ffc: r0 = inline_Allocate_Double()
    //     0xad4ffc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xad5000: add             x0, x0, #0x10
    //     0xad5004: cmp             x2, x0
    //     0xad5008: b.ls            #0xad50a8
    //     0xad500c: str             x0, [THR, #0x60]  ; THR::top
    //     0xad5010: sub             x0, x0, #0xf
    //     0xad5014: mov             x2, #0xd108
    //     0xad5018: movk            x2, #3, lsl #16
    //     0xad501c: stur            x2, [x0, #-1]
    // 0xad5020: StoreField: r0->field_7 = d0
    //     0xad5020: stur            d0, [x0, #7]
    // 0xad5024: SaveReg r0
    //     0xad5024: str             x0, [SP, #-8]!
    // 0xad5028: r0 = 1
    //     0xad5028: mov             x0, #1
    // 0xad502c: SaveReg r0
    //     0xad502c: str             x0, [SP, #-8]!
    // 0xad5030: r0 = toStringAsFixed()
    //     0xad5030: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad5034: add             SP, SP, #0x10
    // 0xad5038: ldur            x1, [fp, #-8]
    // 0xad503c: ArrayStore: r1[6] = r0  ; List_4
    //     0xad503c: add             x25, x1, #0x27
    //     0xad5040: str             w0, [x25]
    //     0xad5044: tbz             w0, #0, #0xad5060
    //     0xad5048: ldurb           w16, [x1, #-1]
    //     0xad504c: ldurb           w17, [x0, #-1]
    //     0xad5050: and             x16, x17, x16, lsr #2
    //     0xad5054: tst             x16, HEAP, lsr #32
    //     0xad5058: b.eq            #0xad5060
    //     0xad505c: bl              #0xd67e5c
    // 0xad5060: ldur            x0, [fp, #-8]
    // 0xad5064: r17 = ")"
    //     0xad5064: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad5068: StoreField: r0->field_2b = r17
    //     0xad5068: stur            w17, [x0, #0x2b]
    // 0xad506c: SaveReg r0
    //     0xad506c: str             x0, [SP, #-8]!
    // 0xad5070: r0 = _interpolate()
    //     0xad5070: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5074: add             SP, SP, #8
    // 0xad5078: LeaveFrame
    //     0xad5078: mov             SP, fp
    //     0xad507c: ldp             fp, lr, [SP], #0x10
    // 0xad5080: ret
    //     0xad5080: ret             
    // 0xad5084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5084: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5088: b               #0xad4efc
    // 0xad508c: SaveReg d0
    //     0xad508c: str             q0, [SP, #-0x10]!
    // 0xad5090: stp             x0, x1, [SP, #-0x10]!
    // 0xad5094: r0 = AllocateDouble()
    //     0xad5094: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad5098: mov             x2, x0
    // 0xad509c: ldp             x0, x1, [SP], #0x10
    // 0xad50a0: RestoreReg d0
    //     0xad50a0: ldr             q0, [SP], #0x10
    // 0xad50a4: b               #0xad4fa4
    // 0xad50a8: SaveReg d0
    //     0xad50a8: str             q0, [SP, #-0x10]!
    // 0xad50ac: SaveReg r1
    //     0xad50ac: str             x1, [SP, #-8]!
    // 0xad50b0: r0 = AllocateDouble()
    //     0xad50b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad50b4: RestoreReg r1
    //     0xad50b4: ldr             x1, [SP], #8
    // 0xad50b8: RestoreReg d0
    //     0xad50b8: ldr             q0, [SP], #0x10
    // 0xad50bc: b               #0xad5020
  }
  _ dx(/* No info */) {
    // ** addr: 0xc2d920, size: 0x150
    // 0xc2d920: EnterFrame
    //     0xc2d920: stp             fp, lr, [SP, #-0x10]!
    //     0xc2d924: mov             fp, SP
    // 0xc2d928: AllocStack(0x10)
    //     0xc2d928: sub             SP, SP, #0x10
    // 0xc2d92c: ldr             x0, [fp, #0x18]
    // 0xc2d930: LoadField: d0 = r0->field_33
    //     0xc2d930: ldur            d0, [x0, #0x33]
    // 0xc2d934: ldr             x1, [fp, #0x10]
    // 0xc2d938: LoadField: d2 = r1->field_7
    //     0xc2d938: ldur            d2, [x1, #7]
    // 0xc2d93c: stur            d2, [fp, #-0x10]
    // 0xc2d940: fcmp            d2, d0
    // 0xc2d944: b.vs            #0xc2d95c
    // 0xc2d948: b.le            #0xc2d95c
    // 0xc2d94c: d0 = 0.000000
    //     0xc2d94c: eor             v0.16b, v0.16b, v0.16b
    // 0xc2d950: LeaveFrame
    //     0xc2d950: mov             SP, fp
    //     0xc2d954: ldp             fp, lr, [SP], #0x10
    // 0xc2d958: ret
    //     0xc2d958: ret             
    // 0xc2d95c: LoadField: d3 = r0->field_23
    //     0xc2d95c: ldur            d3, [x0, #0x23]
    // 0xc2d960: mov             v1.16b, v2.16b
    // 0xc2d964: stur            d3, [fp, #-8]
    // 0xc2d968: d0 = 0.135000
    //     0xc2d968: add             x17, PP, #0x39, lsl #12  ; [pp+0x39018] IMM: double(0.135) from 0x3fc147ae147ae148
    //     0xc2d96c: ldr             d0, [x17, #0x18]
    // 0xc2d970: d30 = 0.000000
    //     0xc2d970: fmov            d30, d0
    // 0xc2d974: d0 = 1.000000
    //     0xc2d974: fmov            d0, #1.00000000
    // 0xc2d978: fcmp            d1, #0.0
    // 0xc2d97c: b.vs            #0xc2d9c0
    // 0xc2d980: b.eq            #0xc2da48
    // 0xc2d984: fcmp            d1, d0
    // 0xc2d988: b.eq            #0xc2d9b0
    // 0xc2d98c: d31 = 2.000000
    //     0xc2d98c: fmov            d31, #2.00000000
    // 0xc2d990: fcmp            d1, d31
    // 0xc2d994: b.eq            #0xc2d9b8
    // 0xc2d998: d31 = 3.000000
    //     0xc2d998: fmov            d31, #3.00000000
    // 0xc2d99c: fcmp            d1, d31
    // 0xc2d9a0: b.ne            #0xc2d9c0
    // 0xc2d9a4: fmul            d0, d30, d30
    // 0xc2d9a8: fmul            d0, d0, d30
    // 0xc2d9ac: b               #0xc2da48
    // 0xc2d9b0: d0 = 0.000000
    //     0xc2d9b0: fmov            d0, d30
    // 0xc2d9b4: b               #0xc2da48
    // 0xc2d9b8: fmul            d0, d30, d30
    // 0xc2d9bc: b               #0xc2da48
    // 0xc2d9c0: fcmp            d30, d0
    // 0xc2d9c4: b.vs            #0xc2d9d4
    // 0xc2d9c8: b.eq            #0xc2da48
    // 0xc2d9cc: fcmp            d30, d1
    // 0xc2d9d0: b.vc            #0xc2d9e0
    // 0xc2d9d4: d0 = nan
    //     0xc2d9d4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xc2d9d8: ldr             d0, [x17, #0x240]
    // 0xc2d9dc: b               #0xc2da48
    // 0xc2d9e0: d0 = -inf
    //     0xc2d9e0: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xc2d9e4: fcmp            d30, d0
    // 0xc2d9e8: b.eq            #0xc2da10
    // 0xc2d9ec: d0 = 0.500000
    //     0xc2d9ec: fmov            d0, #0.50000000
    // 0xc2d9f0: fcmp            d1, d0
    // 0xc2d9f4: b.ne            #0xc2da10
    // 0xc2d9f8: fcmp            d30, #0.0
    // 0xc2d9fc: b.eq            #0xc2da08
    // 0xc2da00: fsqrt           d0, d30
    // 0xc2da04: b               #0xc2da48
    // 0xc2da08: d0 = 0.000000
    //     0xc2da08: eor             v0.16b, v0.16b, v0.16b
    // 0xc2da0c: b               #0xc2da48
    // 0xc2da10: d0 = 0.000000
    //     0xc2da10: fmov            d0, d30
    // 0xc2da14: stp             fp, lr, [SP, #-0x10]!
    // 0xc2da18: mov             fp, SP
    // 0xc2da1c: CallRuntime_LibcPow(double, double) -> double
    //     0xc2da1c: and             SP, SP, #0xfffffffffffffff0
    //     0xc2da20: mov             sp, SP
    //     0xc2da24: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xc2da28: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc2da2c: blr             x16
    //     0xc2da30: mov             x16, #8
    //     0xc2da34: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc2da38: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc2da3c: sub             sp, x16, #1, lsl #12
    //     0xc2da40: mov             SP, fp
    //     0xc2da44: ldp             fp, lr, [SP], #0x10
    // 0xc2da48: ldur            d1, [fp, #-8]
    // 0xc2da4c: fmul            d2, d1, d0
    // 0xc2da50: ldr             x0, [fp, #0x18]
    // 0xc2da54: LoadField: d1 = r0->field_2b
    //     0xc2da54: ldur            d1, [x0, #0x2b]
    // 0xc2da58: ldur            d3, [fp, #-0x10]
    // 0xc2da5c: fmul            d4, d1, d3
    // 0xc2da60: fsub            d0, d2, d4
    // 0xc2da64: LeaveFrame
    //     0xc2da64: mov             SP, fp
    //     0xc2da68: ldp             fp, lr, [SP], #0x10
    // 0xc2da6c: ret
    //     0xc2da6c: ret             
  }
  [closure] double dx(dynamic, double) {
    // ** addr: 0xc2da70, size: 0x198
    // 0xc2da70: EnterFrame
    //     0xc2da70: stp             fp, lr, [SP, #-0x10]!
    //     0xc2da74: mov             fp, SP
    // 0xc2da78: AllocStack(0x18)
    //     0xc2da78: sub             SP, SP, #0x18
    // 0xc2da7c: SetupParameters()
    //     0xc2da7c: ldr             x0, [fp, #0x18]
    //     0xc2da80: ldur            w1, [x0, #0x17]
    //     0xc2da84: add             x1, x1, HEAP, lsl #32
    // 0xc2da88: LoadField: r0 = r1->field_f
    //     0xc2da88: ldur            w0, [x1, #0xf]
    // 0xc2da8c: DecompressPointer r0
    //     0xc2da8c: add             x0, x0, HEAP, lsl #32
    // 0xc2da90: stur            x0, [fp, #-8]
    // 0xc2da94: LoadField: d0 = r0->field_33
    //     0xc2da94: ldur            d0, [x0, #0x33]
    // 0xc2da98: ldr             x1, [fp, #0x10]
    // 0xc2da9c: LoadField: d2 = r1->field_7
    //     0xc2da9c: ldur            d2, [x1, #7]
    // 0xc2daa0: stur            d2, [fp, #-0x18]
    // 0xc2daa4: fcmp            d2, d0
    // 0xc2daa8: b.vs            #0xc2dab8
    // 0xc2daac: b.le            #0xc2dab8
    // 0xc2dab0: d0 = 0.000000
    //     0xc2dab0: eor             v0.16b, v0.16b, v0.16b
    // 0xc2dab4: b               #0xc2dbc4
    // 0xc2dab8: LoadField: d3 = r0->field_23
    //     0xc2dab8: ldur            d3, [x0, #0x23]
    // 0xc2dabc: mov             v1.16b, v2.16b
    // 0xc2dac0: stur            d3, [fp, #-0x10]
    // 0xc2dac4: d0 = 0.135000
    //     0xc2dac4: add             x17, PP, #0x39, lsl #12  ; [pp+0x39018] IMM: double(0.135) from 0x3fc147ae147ae148
    //     0xc2dac8: ldr             d0, [x17, #0x18]
    // 0xc2dacc: d30 = 0.000000
    //     0xc2dacc: fmov            d30, d0
    // 0xc2dad0: d0 = 1.000000
    //     0xc2dad0: fmov            d0, #1.00000000
    // 0xc2dad4: fcmp            d1, #0.0
    // 0xc2dad8: b.vs            #0xc2db1c
    // 0xc2dadc: b.eq            #0xc2dba4
    // 0xc2dae0: fcmp            d1, d0
    // 0xc2dae4: b.eq            #0xc2db0c
    // 0xc2dae8: d31 = 2.000000
    //     0xc2dae8: fmov            d31, #2.00000000
    // 0xc2daec: fcmp            d1, d31
    // 0xc2daf0: b.eq            #0xc2db14
    // 0xc2daf4: d31 = 3.000000
    //     0xc2daf4: fmov            d31, #3.00000000
    // 0xc2daf8: fcmp            d1, d31
    // 0xc2dafc: b.ne            #0xc2db1c
    // 0xc2db00: fmul            d0, d30, d30
    // 0xc2db04: fmul            d0, d0, d30
    // 0xc2db08: b               #0xc2dba4
    // 0xc2db0c: d0 = 0.000000
    //     0xc2db0c: fmov            d0, d30
    // 0xc2db10: b               #0xc2dba4
    // 0xc2db14: fmul            d0, d30, d30
    // 0xc2db18: b               #0xc2dba4
    // 0xc2db1c: fcmp            d30, d0
    // 0xc2db20: b.vs            #0xc2db30
    // 0xc2db24: b.eq            #0xc2dba4
    // 0xc2db28: fcmp            d30, d1
    // 0xc2db2c: b.vc            #0xc2db3c
    // 0xc2db30: d0 = nan
    //     0xc2db30: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xc2db34: ldr             d0, [x17, #0x240]
    // 0xc2db38: b               #0xc2dba4
    // 0xc2db3c: d0 = -inf
    //     0xc2db3c: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xc2db40: fcmp            d30, d0
    // 0xc2db44: b.eq            #0xc2db6c
    // 0xc2db48: d0 = 0.500000
    //     0xc2db48: fmov            d0, #0.50000000
    // 0xc2db4c: fcmp            d1, d0
    // 0xc2db50: b.ne            #0xc2db6c
    // 0xc2db54: fcmp            d30, #0.0
    // 0xc2db58: b.eq            #0xc2db64
    // 0xc2db5c: fsqrt           d0, d30
    // 0xc2db60: b               #0xc2dba4
    // 0xc2db64: d0 = 0.000000
    //     0xc2db64: eor             v0.16b, v0.16b, v0.16b
    // 0xc2db68: b               #0xc2dba4
    // 0xc2db6c: d0 = 0.000000
    //     0xc2db6c: fmov            d0, d30
    // 0xc2db70: stp             fp, lr, [SP, #-0x10]!
    // 0xc2db74: mov             fp, SP
    // 0xc2db78: CallRuntime_LibcPow(double, double) -> double
    //     0xc2db78: and             SP, SP, #0xfffffffffffffff0
    //     0xc2db7c: mov             sp, SP
    //     0xc2db80: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xc2db84: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc2db88: blr             x16
    //     0xc2db8c: mov             x16, #8
    //     0xc2db90: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc2db94: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc2db98: sub             sp, x16, #1, lsl #12
    //     0xc2db9c: mov             SP, fp
    //     0xc2dba0: ldp             fp, lr, [SP], #0x10
    // 0xc2dba4: mov             v1.16b, v0.16b
    // 0xc2dba8: ldur            d0, [fp, #-0x10]
    // 0xc2dbac: fmul            d2, d0, d1
    // 0xc2dbb0: ldur            x1, [fp, #-8]
    // 0xc2dbb4: LoadField: d0 = r1->field_2b
    //     0xc2dbb4: ldur            d0, [x1, #0x2b]
    // 0xc2dbb8: ldur            d1, [fp, #-0x18]
    // 0xc2dbbc: fmul            d3, d0, d1
    // 0xc2dbc0: fsub            d0, d2, d3
    // 0xc2dbc4: r0 = inline_Allocate_Double()
    //     0xc2dbc4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc2dbc8: add             x0, x0, #0x10
    //     0xc2dbcc: cmp             x1, x0
    //     0xc2dbd0: b.ls            #0xc2dbf8
    //     0xc2dbd4: str             x0, [THR, #0x60]  ; THR::top
    //     0xc2dbd8: sub             x0, x0, #0xf
    //     0xc2dbdc: mov             x1, #0xd108
    //     0xc2dbe0: movk            x1, #3, lsl #16
    //     0xc2dbe4: stur            x1, [x0, #-1]
    // 0xc2dbe8: StoreField: r0->field_7 = d0
    //     0xc2dbe8: stur            d0, [x0, #7]
    // 0xc2dbec: LeaveFrame
    //     0xc2dbec: mov             SP, fp
    //     0xc2dbf0: ldp             fp, lr, [SP], #0x10
    // 0xc2dbf4: ret
    //     0xc2dbf4: ret             
    // 0xc2dbf8: SaveReg d0
    //     0xc2dbf8: str             q0, [SP, #-0x10]!
    // 0xc2dbfc: r0 = AllocateDouble()
    //     0xc2dbfc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc2dc00: RestoreReg d0
    //     0xc2dc00: ldr             q0, [SP], #0x10
    // 0xc2dc04: b               #0xc2dbe8
  }
  _ isDone(/* No info */) {
    // ** addr: 0xc3c7b8, size: 0x1a0
    // 0xc3c7b8: EnterFrame
    //     0xc3c7b8: stp             fp, lr, [SP, #-0x10]!
    //     0xc3c7bc: mov             fp, SP
    // 0xc3c7c0: AllocStack(0x8)
    //     0xc3c7c0: sub             SP, SP, #8
    // 0xc3c7c4: ldr             x0, [fp, #0x18]
    // 0xc3c7c8: LoadField: d0 = r0->field_33
    //     0xc3c7c8: ldur            d0, [x0, #0x33]
    // 0xc3c7cc: ldr             d2, [fp, #0x10]
    // 0xc3c7d0: fcmp            d2, d0
    // 0xc3c7d4: b.vs            #0xc3c7e8
    // 0xc3c7d8: b.le            #0xc3c7e8
    // 0xc3c7dc: mov             x1, x0
    // 0xc3c7e0: d1 = 0.000000
    //     0xc3c7e0: eor             v1.16b, v1.16b, v1.16b
    // 0xc3c7e4: b               #0xc3c8f8
    // 0xc3c7e8: LoadField: d3 = r0->field_23
    //     0xc3c7e8: ldur            d3, [x0, #0x23]
    // 0xc3c7ec: mov             v1.16b, v2.16b
    // 0xc3c7f0: stur            d3, [fp, #-8]
    // 0xc3c7f4: d0 = 0.135000
    //     0xc3c7f4: add             x17, PP, #0x39, lsl #12  ; [pp+0x39018] IMM: double(0.135) from 0x3fc147ae147ae148
    //     0xc3c7f8: ldr             d0, [x17, #0x18]
    // 0xc3c7fc: d30 = 0.000000
    //     0xc3c7fc: fmov            d30, d0
    // 0xc3c800: d0 = 1.000000
    //     0xc3c800: fmov            d0, #1.00000000
    // 0xc3c804: fcmp            d1, #0.0
    // 0xc3c808: b.vs            #0xc3c84c
    // 0xc3c80c: b.eq            #0xc3c8d4
    // 0xc3c810: fcmp            d1, d0
    // 0xc3c814: b.eq            #0xc3c83c
    // 0xc3c818: d31 = 2.000000
    //     0xc3c818: fmov            d31, #2.00000000
    // 0xc3c81c: fcmp            d1, d31
    // 0xc3c820: b.eq            #0xc3c844
    // 0xc3c824: d31 = 3.000000
    //     0xc3c824: fmov            d31, #3.00000000
    // 0xc3c828: fcmp            d1, d31
    // 0xc3c82c: b.ne            #0xc3c84c
    // 0xc3c830: fmul            d0, d30, d30
    // 0xc3c834: fmul            d0, d0, d30
    // 0xc3c838: b               #0xc3c8d4
    // 0xc3c83c: d0 = 0.000000
    //     0xc3c83c: fmov            d0, d30
    // 0xc3c840: b               #0xc3c8d4
    // 0xc3c844: fmul            d0, d30, d30
    // 0xc3c848: b               #0xc3c8d4
    // 0xc3c84c: fcmp            d30, d0
    // 0xc3c850: b.vs            #0xc3c860
    // 0xc3c854: b.eq            #0xc3c8d4
    // 0xc3c858: fcmp            d30, d1
    // 0xc3c85c: b.vc            #0xc3c86c
    // 0xc3c860: d0 = nan
    //     0xc3c860: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xc3c864: ldr             d0, [x17, #0x240]
    // 0xc3c868: b               #0xc3c8d4
    // 0xc3c86c: d0 = -inf
    //     0xc3c86c: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xc3c870: fcmp            d30, d0
    // 0xc3c874: b.eq            #0xc3c89c
    // 0xc3c878: d0 = 0.500000
    //     0xc3c878: fmov            d0, #0.50000000
    // 0xc3c87c: fcmp            d1, d0
    // 0xc3c880: b.ne            #0xc3c89c
    // 0xc3c884: fcmp            d30, #0.0
    // 0xc3c888: b.eq            #0xc3c894
    // 0xc3c88c: fsqrt           d0, d30
    // 0xc3c890: b               #0xc3c8d4
    // 0xc3c894: d0 = 0.000000
    //     0xc3c894: eor             v0.16b, v0.16b, v0.16b
    // 0xc3c898: b               #0xc3c8d4
    // 0xc3c89c: d0 = 0.000000
    //     0xc3c89c: fmov            d0, d30
    // 0xc3c8a0: stp             fp, lr, [SP, #-0x10]!
    // 0xc3c8a4: mov             fp, SP
    // 0xc3c8a8: CallRuntime_LibcPow(double, double) -> double
    //     0xc3c8a8: and             SP, SP, #0xfffffffffffffff0
    //     0xc3c8ac: mov             sp, SP
    //     0xc3c8b0: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xc3c8b4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc3c8b8: blr             x16
    //     0xc3c8bc: mov             x16, #8
    //     0xc3c8c0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc3c8c4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc3c8c8: sub             sp, x16, #1, lsl #12
    //     0xc3c8cc: mov             SP, fp
    //     0xc3c8d0: ldp             fp, lr, [SP], #0x10
    // 0xc3c8d4: mov             v1.16b, v0.16b
    // 0xc3c8d8: ldur            d0, [fp, #-8]
    // 0xc3c8dc: fmul            d2, d0, d1
    // 0xc3c8e0: ldr             x1, [fp, #0x18]
    // 0xc3c8e4: LoadField: d0 = r1->field_2b
    //     0xc3c8e4: ldur            d0, [x1, #0x2b]
    // 0xc3c8e8: ldr             d1, [fp, #0x10]
    // 0xc3c8ec: fmul            d3, d0, d1
    // 0xc3c8f0: fsub            d0, d2, d3
    // 0xc3c8f4: mov             v1.16b, v0.16b
    // 0xc3c8f8: d0 = 0.000000
    //     0xc3c8f8: eor             v0.16b, v0.16b, v0.16b
    // 0xc3c8fc: fcmp            d1, d0
    // 0xc3c900: b.vs            #0xc3c910
    // 0xc3c904: b.ne            #0xc3c910
    // 0xc3c908: d0 = 0.000000
    //     0xc3c908: eor             v0.16b, v0.16b, v0.16b
    // 0xc3c90c: b               #0xc3c928
    // 0xc3c910: fcmp            d1, d0
    // 0xc3c914: b.vs            #0xc3c924
    // 0xc3c918: b.ge            #0xc3c924
    // 0xc3c91c: fneg            d0, d1
    // 0xc3c920: b               #0xc3c928
    // 0xc3c924: mov             v0.16b, v1.16b
    // 0xc3c928: LoadField: r2 = r1->field_7
    //     0xc3c928: ldur            w2, [x1, #7]
    // 0xc3c92c: DecompressPointer r2
    //     0xc3c92c: add             x2, x2, HEAP, lsl #32
    // 0xc3c930: LoadField: d1 = r2->field_17
    //     0xc3c930: ldur            d1, [x2, #0x17]
    // 0xc3c934: fcmp            d0, d1
    // 0xc3c938: b.vs            #0xc3c940
    // 0xc3c93c: b.lt            #0xc3c948
    // 0xc3c940: r0 = false
    //     0xc3c940: add             x0, NULL, #0x30  ; false
    // 0xc3c944: b               #0xc3c94c
    // 0xc3c948: r0 = true
    //     0xc3c948: add             x0, NULL, #0x20  ; true
    // 0xc3c94c: LeaveFrame
    //     0xc3c94c: mov             SP, fp
    //     0xc3c950: ldp             fp, lr, [SP], #0x10
    // 0xc3c954: ret
    //     0xc3c954: ret             
  }
  _ timeAtX(/* No info */) {
    // ** addr: 0xc61c04, size: 0x154
    // 0xc61c04: EnterFrame
    //     0xc61c04: stp             fp, lr, [SP, #-0x10]!
    //     0xc61c08: mov             fp, SP
    // 0xc61c0c: AllocStack(0x10)
    //     0xc61c0c: sub             SP, SP, #0x10
    // 0xc61c10: CheckStackOverflow
    //     0xc61c10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc61c14: cmp             SP, x16
    //     0xc61c18: b.ls            #0xc61d50
    // 0xc61c1c: ldr             x0, [fp, #0x18]
    // 0xc61c20: LoadField: d0 = r0->field_1b
    //     0xc61c20: ldur            d0, [x0, #0x1b]
    // 0xc61c24: ldr             d1, [fp, #0x10]
    // 0xc61c28: fcmp            d1, d0
    // 0xc61c2c: b.vs            #0xc61c44
    // 0xc61c30: b.ne            #0xc61c44
    // 0xc61c34: d0 = 0.000000
    //     0xc61c34: eor             v0.16b, v0.16b, v0.16b
    // 0xc61c38: LeaveFrame
    //     0xc61c38: mov             SP, fp
    //     0xc61c3c: ldp             fp, lr, [SP], #0x10
    // 0xc61c40: ret
    //     0xc61c40: ret             
    // 0xc61c44: d2 = 0.000000
    //     0xc61c44: eor             v2.16b, v2.16b, v2.16b
    // 0xc61c48: LoadField: d3 = r0->field_23
    //     0xc61c48: ldur            d3, [x0, #0x23]
    // 0xc61c4c: fcmp            d3, d2
    // 0xc61c50: b.vs            #0xc61c58
    // 0xc61c54: b.eq            #0xc61cc4
    // 0xc61c58: fcmp            d3, d2
    // 0xc61c5c: b.vs            #0xc61c94
    // 0xc61c60: b.le            #0xc61c94
    // 0xc61c64: fcmp            d1, d0
    // 0xc61c68: b.vs            #0xc61c70
    // 0xc61c6c: b.lt            #0xc61cc4
    // 0xc61c70: SaveReg r0
    //     0xc61c70: str             x0, [SP, #-8]!
    // 0xc61c74: r0 = finalX()
    //     0xc61c74: bl              #0xc61f4c  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::finalX
    // 0xc61c78: add             SP, SP, #8
    // 0xc61c7c: ldr             d1, [fp, #0x10]
    // 0xc61c80: fcmp            d1, d0
    // 0xc61c84: b.vs            #0xc61c8c
    // 0xc61c88: b.gt            #0xc61cc4
    // 0xc61c8c: mov             v0.16b, v1.16b
    // 0xc61c90: b               #0xc61cd4
    // 0xc61c94: fcmp            d1, d0
    // 0xc61c98: b.vs            #0xc61ca0
    // 0xc61c9c: b.gt            #0xc61cc4
    // 0xc61ca0: ldr             x16, [fp, #0x18]
    // 0xc61ca4: SaveReg r16
    //     0xc61ca4: str             x16, [SP, #-8]!
    // 0xc61ca8: r0 = finalX()
    //     0xc61ca8: bl              #0xc61f4c  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::finalX
    // 0xc61cac: add             SP, SP, #8
    // 0xc61cb0: mov             v1.16b, v0.16b
    // 0xc61cb4: ldr             d0, [fp, #0x10]
    // 0xc61cb8: fcmp            d0, d1
    // 0xc61cbc: b.vs            #0xc61cd4
    // 0xc61cc0: b.ge            #0xc61cd4
    // 0xc61cc4: d0 = inf
    //     0xc61cc4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xc61cc8: LeaveFrame
    //     0xc61cc8: mov             SP, fp
    //     0xc61ccc: ldp             fp, lr, [SP], #0x10
    // 0xc61cd0: ret
    //     0xc61cd0: ret             
    // 0xc61cd4: ldr             x0, [fp, #0x18]
    // 0xc61cd8: r1 = 1
    //     0xc61cd8: mov             x1, #1
    // 0xc61cdc: r0 = AllocateContext()
    //     0xc61cdc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc61ce0: mov             x1, x0
    // 0xc61ce4: ldr             x0, [fp, #0x18]
    // 0xc61ce8: stur            x1, [fp, #-8]
    // 0xc61cec: StoreField: r1->field_f = r0
    //     0xc61cec: stur            w0, [x1, #0xf]
    // 0xc61cf0: r1 = 1
    //     0xc61cf0: mov             x1, #1
    // 0xc61cf4: r0 = AllocateContext()
    //     0xc61cf4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc61cf8: mov             x3, x0
    // 0xc61cfc: ldr             x0, [fp, #0x18]
    // 0xc61d00: stur            x3, [fp, #-0x10]
    // 0xc61d04: StoreField: r3->field_f = r0
    //     0xc61d04: stur            w0, [x3, #0xf]
    // 0xc61d08: ldur            x2, [fp, #-8]
    // 0xc61d0c: r1 = Function 'x':.
    //     0xc61d0c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39028] AnonymousClosure: (0xc61ec8), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::x (0xcba40c)
    //     0xc61d10: ldr             x1, [x1, #0x28]
    // 0xc61d14: r0 = AllocateClosure()
    //     0xc61d14: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc61d18: ldur            x2, [fp, #-0x10]
    // 0xc61d1c: r1 = Function 'dx':.
    //     0xc61d1c: add             x1, PP, #0x39, lsl #12  ; [pp+0x39030] AnonymousClosure: (0xc2da70), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::dx (0xc2d920)
    //     0xc61d20: ldr             x1, [x1, #0x30]
    // 0xc61d24: stur            x0, [fp, #-8]
    // 0xc61d28: r0 = AllocateClosure()
    //     0xc61d28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc61d2c: ldur            x16, [fp, #-8]
    // 0xc61d30: stp             x16, x0, [SP, #-0x10]!
    // 0xc61d34: ldr             d0, [fp, #0x10]
    // 0xc61d38: SaveReg d0
    //     0xc61d38: str             d0, [SP, #-8]!
    // 0xc61d3c: r0 = _newtonsMethod()
    //     0xc61d3c: bl              #0xc61d58  ; [package:flutter/src/physics/friction_simulation.dart] ::_newtonsMethod
    // 0xc61d40: add             SP, SP, #0x18
    // 0xc61d44: LeaveFrame
    //     0xc61d44: mov             SP, fp
    //     0xc61d48: ldp             fp, lr, [SP], #0x10
    // 0xc61d4c: ret
    //     0xc61d4c: ret             
    // 0xc61d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc61d50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc61d54: b               #0xc61c1c
  }
  [closure] double x(dynamic, double) {
    // ** addr: 0xc61ec8, size: 0x84
    // 0xc61ec8: EnterFrame
    //     0xc61ec8: stp             fp, lr, [SP, #-0x10]!
    //     0xc61ecc: mov             fp, SP
    // 0xc61ed0: ldr             x0, [fp, #0x18]
    // 0xc61ed4: LoadField: r1 = r0->field_17
    //     0xc61ed4: ldur            w1, [x0, #0x17]
    // 0xc61ed8: DecompressPointer r1
    //     0xc61ed8: add             x1, x1, HEAP, lsl #32
    // 0xc61edc: CheckStackOverflow
    //     0xc61edc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc61ee0: cmp             SP, x16
    //     0xc61ee4: b.ls            #0xc61f34
    // 0xc61ee8: LoadField: r0 = r1->field_f
    //     0xc61ee8: ldur            w0, [x1, #0xf]
    // 0xc61eec: DecompressPointer r0
    //     0xc61eec: add             x0, x0, HEAP, lsl #32
    // 0xc61ef0: ldr             x16, [fp, #0x10]
    // 0xc61ef4: stp             x16, x0, [SP, #-0x10]!
    // 0xc61ef8: r0 = x()
    //     0xc61ef8: bl              #0xcba40c  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::x
    // 0xc61efc: add             SP, SP, #0x10
    // 0xc61f00: r0 = inline_Allocate_Double()
    //     0xc61f00: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc61f04: add             x0, x0, #0x10
    //     0xc61f08: cmp             x1, x0
    //     0xc61f0c: b.ls            #0xc61f3c
    //     0xc61f10: str             x0, [THR, #0x60]  ; THR::top
    //     0xc61f14: sub             x0, x0, #0xf
    //     0xc61f18: mov             x1, #0xd108
    //     0xc61f1c: movk            x1, #3, lsl #16
    //     0xc61f20: stur            x1, [x0, #-1]
    // 0xc61f24: StoreField: r0->field_7 = d0
    //     0xc61f24: stur            d0, [x0, #7]
    // 0xc61f28: LeaveFrame
    //     0xc61f28: mov             SP, fp
    //     0xc61f2c: ldp             fp, lr, [SP], #0x10
    // 0xc61f30: ret
    //     0xc61f30: ret             
    // 0xc61f34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc61f34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc61f38: b               #0xc61ee8
    // 0xc61f3c: SaveReg d0
    //     0xc61f3c: str             q0, [SP, #-0x10]!
    // 0xc61f40: r0 = AllocateDouble()
    //     0xc61f40: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc61f44: RestoreReg d0
    //     0xc61f44: ldr             q0, [SP], #0x10
    // 0xc61f48: b               #0xc61f24
  }
  get _ finalX(/* No info */) {
    // ** addr: 0xc61f4c, size: 0xb8
    // 0xc61f4c: EnterFrame
    //     0xc61f4c: stp             fp, lr, [SP, #-0x10]!
    //     0xc61f50: mov             fp, SP
    // 0xc61f54: d0 = 0.000000
    //     0xc61f54: eor             v0.16b, v0.16b, v0.16b
    // 0xc61f58: CheckStackOverflow
    //     0xc61f58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc61f5c: cmp             SP, x16
    //     0xc61f60: b.ls            #0xc61fe0
    // 0xc61f64: ldr             x0, [fp, #0x10]
    // 0xc61f68: LoadField: d1 = r0->field_2b
    //     0xc61f68: ldur            d1, [x0, #0x2b]
    // 0xc61f6c: fcmp            d1, d0
    // 0xc61f70: b.vs            #0xc61f9c
    // 0xc61f74: b.ne            #0xc61f9c
    // 0xc61f78: LoadField: d0 = r0->field_1b
    //     0xc61f78: ldur            d0, [x0, #0x1b]
    // 0xc61f7c: LoadField: d1 = r0->field_23
    //     0xc61f7c: ldur            d1, [x0, #0x23]
    // 0xc61f80: LoadField: d2 = r0->field_13
    //     0xc61f80: ldur            d2, [x0, #0x13]
    // 0xc61f84: fdiv            d3, d1, d2
    // 0xc61f88: fsub            d1, d0, d3
    // 0xc61f8c: mov             v0.16b, v1.16b
    // 0xc61f90: LeaveFrame
    //     0xc61f90: mov             SP, fp
    //     0xc61f94: ldp             fp, lr, [SP], #0x10
    // 0xc61f98: ret
    //     0xc61f98: ret             
    // 0xc61f9c: LoadField: d0 = r0->field_33
    //     0xc61f9c: ldur            d0, [x0, #0x33]
    // 0xc61fa0: r1 = inline_Allocate_Double()
    //     0xc61fa0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc61fa4: add             x1, x1, #0x10
    //     0xc61fa8: cmp             x2, x1
    //     0xc61fac: b.ls            #0xc61fe8
    //     0xc61fb0: str             x1, [THR, #0x60]  ; THR::top
    //     0xc61fb4: sub             x1, x1, #0xf
    //     0xc61fb8: mov             x2, #0xd108
    //     0xc61fbc: movk            x2, #3, lsl #16
    //     0xc61fc0: stur            x2, [x1, #-1]
    // 0xc61fc4: StoreField: r1->field_7 = d0
    //     0xc61fc4: stur            d0, [x1, #7]
    // 0xc61fc8: stp             x1, x0, [SP, #-0x10]!
    // 0xc61fcc: r0 = x()
    //     0xc61fcc: bl              #0xcba40c  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::x
    // 0xc61fd0: add             SP, SP, #0x10
    // 0xc61fd4: LeaveFrame
    //     0xc61fd4: mov             SP, fp
    //     0xc61fd8: ldp             fp, lr, [SP], #0x10
    // 0xc61fdc: ret
    //     0xc61fdc: ret             
    // 0xc61fe0: r0 = StackOverflowSharedWithFPURegs()
    //     0xc61fe0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc61fe4: b               #0xc61f64
    // 0xc61fe8: SaveReg d0
    //     0xc61fe8: str             q0, [SP, #-0x10]!
    // 0xc61fec: SaveReg r0
    //     0xc61fec: str             x0, [SP, #-8]!
    // 0xc61ff0: r0 = AllocateDouble()
    //     0xc61ff0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc61ff4: mov             x1, x0
    // 0xc61ff8: RestoreReg r0
    //     0xc61ff8: ldr             x0, [SP], #8
    // 0xc61ffc: RestoreReg d0
    //     0xc61ffc: ldr             q0, [SP], #0x10
    // 0xc62000: b               #0xc61fc4
  }
  _ FrictionSimulation(/* No info */) {
    // ** addr: 0xc62004, size: 0x150
    // 0xc62004: EnterFrame
    //     0xc62004: stp             fp, lr, [SP, #-0x10]!
    //     0xc62008: mov             fp, SP
    // 0xc6200c: AllocStack(0x8)
    //     0xc6200c: sub             SP, SP, #8
    // 0xc62010: CheckStackOverflow
    //     0xc62010: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc62014: cmp             SP, x16
    //     0xc62018: b.ls            #0xc6214c
    // 0xc6201c: r1 = 1
    //     0xc6201c: mov             x1, #1
    // 0xc62020: r0 = AllocateContext()
    //     0xc62020: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc62024: mov             x1, x0
    // 0xc62028: ldr             x0, [fp, #0x28]
    // 0xc6202c: stur            x1, [fp, #-8]
    // 0xc62030: StoreField: r1->field_f = r0
    //     0xc62030: stur            w0, [x1, #0xf]
    // 0xc62034: d0 = inf
    //     0xc62034: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xc62038: StoreField: r0->field_33 = d0
    //     0xc62038: stur            d0, [x0, #0x33]
    // 0xc6203c: d0 = 0.135000
    //     0xc6203c: add             x17, PP, #0x39, lsl #12  ; [pp+0x39018] IMM: double(0.135) from 0x3fc147ae147ae148
    //     0xc62040: ldr             d0, [x17, #0x18]
    // 0xc62044: StoreField: r0->field_b = d0
    //     0xc62044: stur            d0, [x0, #0xb]
    // 0xc62048: stp             fp, lr, [SP, #-0x10]!
    // 0xc6204c: mov             fp, SP
    // 0xc62050: CallRuntime_LibcLog(double) -> double
    //     0xc62050: and             SP, SP, #0xfffffffffffffff0
    //     0xc62054: mov             sp, SP
    //     0xc62058: ldr             x16, [THR, #0x5c0]  ; THR::LibcLog
    //     0xc6205c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc62060: blr             x16
    //     0xc62064: mov             x16, #8
    //     0xc62068: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc6206c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc62070: sub             sp, x16, #1, lsl #12
    //     0xc62074: mov             SP, fp
    //     0xc62078: ldp             fp, lr, [SP], #0x10
    // 0xc6207c: ldr             x0, [fp, #0x28]
    // 0xc62080: StoreField: r0->field_13 = d0
    //     0xc62080: stur            d0, [x0, #0x13]
    // 0xc62084: ldr             x1, [fp, #0x20]
    // 0xc62088: LoadField: d0 = r1->field_7
    //     0xc62088: ldur            d0, [x1, #7]
    // 0xc6208c: StoreField: r0->field_1b = d0
    //     0xc6208c: stur            d0, [x0, #0x1b]
    // 0xc62090: ldr             x1, [fp, #0x18]
    // 0xc62094: LoadField: d0 = r1->field_7
    //     0xc62094: ldur            d0, [x1, #7]
    // 0xc62098: StoreField: r0->field_23 = d0
    //     0xc62098: stur            d0, [x0, #0x23]
    // 0xc6209c: d1 = 0.000000
    //     0xc6209c: eor             v1.16b, v1.16b, v1.16b
    // 0xc620a0: fcmp            d0, d1
    // 0xc620a4: b.vs            #0xc620b4
    // 0xc620a8: b.le            #0xc620b4
    // 0xc620ac: d1 = 1.000000
    //     0xc620ac: fmov            d1, #1.00000000
    // 0xc620b0: b               #0xc620d0
    // 0xc620b4: fcmp            d0, d1
    // 0xc620b8: b.vs            #0xc620cc
    // 0xc620bc: b.ge            #0xc620cc
    // 0xc620c0: d0 = 1.000000
    //     0xc620c0: fmov            d0, #1.00000000
    // 0xc620c4: fneg            d1, d0
    // 0xc620c8: b               #0xc620d0
    // 0xc620cc: mov             v1.16b, v0.16b
    // 0xc620d0: ldr             d0, [fp, #0x10]
    // 0xc620d4: r1 = Instance_Tolerance
    //     0xc620d4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdbd0] Obj!Tolerance@b35651
    //     0xc620d8: ldr             x1, [x1, #0xbd0]
    // 0xc620dc: fmul            d2, d0, d1
    // 0xc620e0: StoreField: r0->field_2b = d2
    //     0xc620e0: stur            d2, [x0, #0x2b]
    // 0xc620e4: StoreField: r0->field_7 = r1
    //     0xc620e4: stur            w1, [x0, #7]
    // 0xc620e8: r1 = 1
    //     0xc620e8: mov             x1, #1
    // 0xc620ec: r0 = AllocateContext()
    //     0xc620ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc620f0: mov             x1, x0
    // 0xc620f4: ldr             x0, [fp, #0x28]
    // 0xc620f8: StoreField: r1->field_f = r0
    //     0xc620f8: stur            w0, [x1, #0xf]
    // 0xc620fc: mov             x2, x1
    // 0xc62100: r1 = Function 'dx':.
    //     0xc62100: add             x1, PP, #0x39, lsl #12  ; [pp+0x39030] AnonymousClosure: (0xc2da70), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::dx (0xc2d920)
    //     0xc62104: ldr             x1, [x1, #0x30]
    // 0xc62108: r0 = AllocateClosure()
    //     0xc62108: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6210c: ldur            x2, [fp, #-8]
    // 0xc62110: r1 = Function '<anonymous closure>':.
    //     0xc62110: add             x1, PP, #0x39, lsl #12  ; [pp+0x39038] AnonymousClosure: (0xc62154), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::FrictionSimulation (0xc62004)
    //     0xc62114: ldr             x1, [x1, #0x38]
    // 0xc62118: stur            x0, [fp, #-8]
    // 0xc6211c: r0 = AllocateClosure()
    //     0xc6211c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc62120: ldur            x16, [fp, #-8]
    // 0xc62124: stp             x16, x0, [SP, #-0x10]!
    // 0xc62128: SaveReg rZR
    //     0xc62128: str             xzr, [SP, #-8]!
    // 0xc6212c: r0 = _newtonsMethod()
    //     0xc6212c: bl              #0xc61d58  ; [package:flutter/src/physics/friction_simulation.dart] ::_newtonsMethod
    // 0xc62130: add             SP, SP, #0x18
    // 0xc62134: ldr             x1, [fp, #0x28]
    // 0xc62138: StoreField: r1->field_33 = d0
    //     0xc62138: stur            d0, [x1, #0x33]
    // 0xc6213c: r0 = Null
    //     0xc6213c: mov             x0, NULL
    // 0xc62140: LeaveFrame
    //     0xc62140: mov             SP, fp
    //     0xc62144: ldp             fp, lr, [SP], #0x10
    // 0xc62148: ret
    //     0xc62148: ret             
    // 0xc6214c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6214c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc62150: b               #0xc6201c
  }
  [closure] double <anonymous closure>(dynamic, double) {
    // ** addr: 0xc62154, size: 0x178
    // 0xc62154: EnterFrame
    //     0xc62154: stp             fp, lr, [SP, #-0x10]!
    //     0xc62158: mov             fp, SP
    // 0xc6215c: AllocStack(0x10)
    //     0xc6215c: sub             SP, SP, #0x10
    // 0xc62160: SetupParameters()
    //     0xc62160: ldr             x0, [fp, #0x18]
    //     0xc62164: ldur            w1, [x0, #0x17]
    //     0xc62168: add             x1, x1, HEAP, lsl #32
    // 0xc6216c: LoadField: r0 = r1->field_f
    //     0xc6216c: ldur            w0, [x1, #0xf]
    // 0xc62170: DecompressPointer r0
    //     0xc62170: add             x0, x0, HEAP, lsl #32
    // 0xc62174: stur            x0, [fp, #-8]
    // 0xc62178: LoadField: d2 = r0->field_23
    //     0xc62178: ldur            d2, [x0, #0x23]
    // 0xc6217c: ldr             x1, [fp, #0x10]
    // 0xc62180: stur            d2, [fp, #-0x10]
    // 0xc62184: LoadField: d1 = r1->field_7
    //     0xc62184: ldur            d1, [x1, #7]
    // 0xc62188: d0 = 0.135000
    //     0xc62188: add             x17, PP, #0x39, lsl #12  ; [pp+0x39018] IMM: double(0.135) from 0x3fc147ae147ae148
    //     0xc6218c: ldr             d0, [x17, #0x18]
    // 0xc62190: d30 = 0.000000
    //     0xc62190: fmov            d30, d0
    // 0xc62194: d0 = 1.000000
    //     0xc62194: fmov            d0, #1.00000000
    // 0xc62198: fcmp            d1, #0.0
    // 0xc6219c: b.vs            #0xc621e0
    // 0xc621a0: b.eq            #0xc62268
    // 0xc621a4: fcmp            d1, d0
    // 0xc621a8: b.eq            #0xc621d0
    // 0xc621ac: d31 = 2.000000
    //     0xc621ac: fmov            d31, #2.00000000
    // 0xc621b0: fcmp            d1, d31
    // 0xc621b4: b.eq            #0xc621d8
    // 0xc621b8: d31 = 3.000000
    //     0xc621b8: fmov            d31, #3.00000000
    // 0xc621bc: fcmp            d1, d31
    // 0xc621c0: b.ne            #0xc621e0
    // 0xc621c4: fmul            d0, d30, d30
    // 0xc621c8: fmul            d0, d0, d30
    // 0xc621cc: b               #0xc62268
    // 0xc621d0: d0 = 0.000000
    //     0xc621d0: fmov            d0, d30
    // 0xc621d4: b               #0xc62268
    // 0xc621d8: fmul            d0, d30, d30
    // 0xc621dc: b               #0xc62268
    // 0xc621e0: fcmp            d30, d0
    // 0xc621e4: b.vs            #0xc621f4
    // 0xc621e8: b.eq            #0xc62268
    // 0xc621ec: fcmp            d30, d1
    // 0xc621f0: b.vc            #0xc62200
    // 0xc621f4: d0 = nan
    //     0xc621f4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xc621f8: ldr             d0, [x17, #0x240]
    // 0xc621fc: b               #0xc62268
    // 0xc62200: d0 = -inf
    //     0xc62200: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xc62204: fcmp            d30, d0
    // 0xc62208: b.eq            #0xc62230
    // 0xc6220c: d0 = 0.500000
    //     0xc6220c: fmov            d0, #0.50000000
    // 0xc62210: fcmp            d1, d0
    // 0xc62214: b.ne            #0xc62230
    // 0xc62218: fcmp            d30, #0.0
    // 0xc6221c: b.eq            #0xc62228
    // 0xc62220: fsqrt           d0, d30
    // 0xc62224: b               #0xc62268
    // 0xc62228: d0 = 0.000000
    //     0xc62228: eor             v0.16b, v0.16b, v0.16b
    // 0xc6222c: b               #0xc62268
    // 0xc62230: d0 = 0.000000
    //     0xc62230: fmov            d0, d30
    // 0xc62234: stp             fp, lr, [SP, #-0x10]!
    // 0xc62238: mov             fp, SP
    // 0xc6223c: CallRuntime_LibcPow(double, double) -> double
    //     0xc6223c: and             SP, SP, #0xfffffffffffffff0
    //     0xc62240: mov             sp, SP
    //     0xc62244: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xc62248: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc6224c: blr             x16
    //     0xc62250: mov             x16, #8
    //     0xc62254: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc62258: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc6225c: sub             sp, x16, #1, lsl #12
    //     0xc62260: mov             SP, fp
    //     0xc62264: ldp             fp, lr, [SP], #0x10
    // 0xc62268: mov             v1.16b, v0.16b
    // 0xc6226c: ldur            d0, [fp, #-0x10]
    // 0xc62270: fmul            d2, d0, d1
    // 0xc62274: ldur            x1, [fp, #-8]
    // 0xc62278: LoadField: d0 = r1->field_13
    //     0xc62278: ldur            d0, [x1, #0x13]
    // 0xc6227c: fmul            d1, d2, d0
    // 0xc62280: LoadField: d0 = r1->field_2b
    //     0xc62280: ldur            d0, [x1, #0x2b]
    // 0xc62284: fsub            d2, d1, d0
    // 0xc62288: r0 = inline_Allocate_Double()
    //     0xc62288: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc6228c: add             x0, x0, #0x10
    //     0xc62290: cmp             x1, x0
    //     0xc62294: b.ls            #0xc622bc
    //     0xc62298: str             x0, [THR, #0x60]  ; THR::top
    //     0xc6229c: sub             x0, x0, #0xf
    //     0xc622a0: mov             x1, #0xd108
    //     0xc622a4: movk            x1, #3, lsl #16
    //     0xc622a8: stur            x1, [x0, #-1]
    // 0xc622ac: StoreField: r0->field_7 = d2
    //     0xc622ac: stur            d2, [x0, #7]
    // 0xc622b0: LeaveFrame
    //     0xc622b0: mov             SP, fp
    //     0xc622b4: ldp             fp, lr, [SP], #0x10
    // 0xc622b8: ret
    //     0xc622b8: ret             
    // 0xc622bc: SaveReg d2
    //     0xc622bc: str             q2, [SP, #-0x10]!
    // 0xc622c0: r0 = AllocateDouble()
    //     0xc622c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc622c4: RestoreReg d2
    //     0xc622c4: ldr             q2, [SP], #0x10
    // 0xc622c8: b               #0xc622ac
  }
  _ x(/* No info */) {
    // ** addr: 0xcba40c, size: 0x198
    // 0xcba40c: EnterFrame
    //     0xcba40c: stp             fp, lr, [SP, #-0x10]!
    //     0xcba410: mov             fp, SP
    // 0xcba414: AllocStack(0x18)
    //     0xcba414: sub             SP, SP, #0x18
    // 0xcba418: CheckStackOverflow
    //     0xcba418: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcba41c: cmp             SP, x16
    //     0xcba420: b.ls            #0xcba59c
    // 0xcba424: ldr             x0, [fp, #0x18]
    // 0xcba428: LoadField: d0 = r0->field_33
    //     0xcba428: ldur            d0, [x0, #0x33]
    // 0xcba42c: ldr             x1, [fp, #0x10]
    // 0xcba430: LoadField: d2 = r1->field_7
    //     0xcba430: ldur            d2, [x1, #7]
    // 0xcba434: stur            d2, [fp, #-0x18]
    // 0xcba438: fcmp            d2, d0
    // 0xcba43c: b.vs            #0xcba45c
    // 0xcba440: b.le            #0xcba45c
    // 0xcba444: SaveReg r0
    //     0xcba444: str             x0, [SP, #-8]!
    // 0xcba448: r0 = finalX()
    //     0xcba448: bl              #0xc61f4c  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::finalX
    // 0xcba44c: add             SP, SP, #8
    // 0xcba450: LeaveFrame
    //     0xcba450: mov             SP, fp
    //     0xcba454: ldp             fp, lr, [SP], #0x10
    // 0xcba458: ret
    //     0xcba458: ret             
    // 0xcba45c: LoadField: d3 = r0->field_1b
    //     0xcba45c: ldur            d3, [x0, #0x1b]
    // 0xcba460: stur            d3, [fp, #-0x10]
    // 0xcba464: LoadField: d4 = r0->field_23
    //     0xcba464: ldur            d4, [x0, #0x23]
    // 0xcba468: mov             v1.16b, v2.16b
    // 0xcba46c: stur            d4, [fp, #-8]
    // 0xcba470: d0 = 0.135000
    //     0xcba470: add             x17, PP, #0x39, lsl #12  ; [pp+0x39018] IMM: double(0.135) from 0x3fc147ae147ae148
    //     0xcba474: ldr             d0, [x17, #0x18]
    // 0xcba478: d30 = 0.000000
    //     0xcba478: fmov            d30, d0
    // 0xcba47c: d0 = 1.000000
    //     0xcba47c: fmov            d0, #1.00000000
    // 0xcba480: fcmp            d1, #0.0
    // 0xcba484: b.vs            #0xcba4c8
    // 0xcba488: b.eq            #0xcba550
    // 0xcba48c: fcmp            d1, d0
    // 0xcba490: b.eq            #0xcba4b8
    // 0xcba494: d31 = 2.000000
    //     0xcba494: fmov            d31, #2.00000000
    // 0xcba498: fcmp            d1, d31
    // 0xcba49c: b.eq            #0xcba4c0
    // 0xcba4a0: d31 = 3.000000
    //     0xcba4a0: fmov            d31, #3.00000000
    // 0xcba4a4: fcmp            d1, d31
    // 0xcba4a8: b.ne            #0xcba4c8
    // 0xcba4ac: fmul            d0, d30, d30
    // 0xcba4b0: fmul            d0, d0, d30
    // 0xcba4b4: b               #0xcba550
    // 0xcba4b8: d0 = 0.000000
    //     0xcba4b8: fmov            d0, d30
    // 0xcba4bc: b               #0xcba550
    // 0xcba4c0: fmul            d0, d30, d30
    // 0xcba4c4: b               #0xcba550
    // 0xcba4c8: fcmp            d30, d0
    // 0xcba4cc: b.vs            #0xcba4dc
    // 0xcba4d0: b.eq            #0xcba550
    // 0xcba4d4: fcmp            d30, d1
    // 0xcba4d8: b.vc            #0xcba4e8
    // 0xcba4dc: d0 = nan
    //     0xcba4dc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcba4e0: ldr             d0, [x17, #0x240]
    // 0xcba4e4: b               #0xcba550
    // 0xcba4e8: d0 = -inf
    //     0xcba4e8: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcba4ec: fcmp            d30, d0
    // 0xcba4f0: b.eq            #0xcba518
    // 0xcba4f4: d0 = 0.500000
    //     0xcba4f4: fmov            d0, #0.50000000
    // 0xcba4f8: fcmp            d1, d0
    // 0xcba4fc: b.ne            #0xcba518
    // 0xcba500: fcmp            d30, #0.0
    // 0xcba504: b.eq            #0xcba510
    // 0xcba508: fsqrt           d0, d30
    // 0xcba50c: b               #0xcba550
    // 0xcba510: d0 = 0.000000
    //     0xcba510: eor             v0.16b, v0.16b, v0.16b
    // 0xcba514: b               #0xcba550
    // 0xcba518: d0 = 0.000000
    //     0xcba518: fmov            d0, d30
    // 0xcba51c: stp             fp, lr, [SP, #-0x10]!
    // 0xcba520: mov             fp, SP
    // 0xcba524: CallRuntime_LibcPow(double, double) -> double
    //     0xcba524: and             SP, SP, #0xfffffffffffffff0
    //     0xcba528: mov             sp, SP
    //     0xcba52c: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcba530: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcba534: blr             x16
    //     0xcba538: mov             x16, #8
    //     0xcba53c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcba540: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcba544: sub             sp, x16, #1, lsl #12
    //     0xcba548: mov             SP, fp
    //     0xcba54c: ldp             fp, lr, [SP], #0x10
    // 0xcba550: ldur            d1, [fp, #-8]
    // 0xcba554: fmul            d2, d1, d0
    // 0xcba558: ldr             x0, [fp, #0x18]
    // 0xcba55c: LoadField: d3 = r0->field_13
    //     0xcba55c: ldur            d3, [x0, #0x13]
    // 0xcba560: fdiv            d4, d2, d3
    // 0xcba564: ldur            d2, [fp, #-0x10]
    // 0xcba568: fadd            d5, d2, d4
    // 0xcba56c: fdiv            d2, d1, d3
    // 0xcba570: fsub            d1, d5, d2
    // 0xcba574: LoadField: d2 = r0->field_2b
    //     0xcba574: ldur            d2, [x0, #0x2b]
    // 0xcba578: d3 = 2.000000
    //     0xcba578: fmov            d3, #2.00000000
    // 0xcba57c: fdiv            d4, d2, d3
    // 0xcba580: ldur            d2, [fp, #-0x18]
    // 0xcba584: fmul            d3, d4, d2
    // 0xcba588: fmul            d4, d3, d2
    // 0xcba58c: fsub            d0, d1, d4
    // 0xcba590: LeaveFrame
    //     0xcba590: mov             SP, fp
    //     0xcba594: ldp             fp, lr, [SP], #0x10
    // 0xcba598: ret
    //     0xcba598: ret             
    // 0xcba59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcba59c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcba5a0: b               #0xcba424
  }
}

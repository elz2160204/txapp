// lib: , url: package:flutter/src/physics/utils.dart

// class id: 1049392, size: 0x8
class :: {

  static _ nearZero(/* No info */) {
    // ** addr: 0xc3cab0, size: 0x58
    // 0xc3cab0: d0 = 0.000000
    //     0xc3cab0: eor             v0.16b, v0.16b, v0.16b
    // 0xc3cab4: ldr             d1, [SP]
    // 0xc3cab8: fsub            d2, d0, d1
    // 0xc3cabc: ldr             x1, [SP, #8]
    // 0xc3cac0: LoadField: d3 = r1->field_7
    //     0xc3cac0: ldur            d3, [x1, #7]
    // 0xc3cac4: fcmp            d3, d2
    // 0xc3cac8: b.vs            #0xc3cae8
    // 0xc3cacc: b.le            #0xc3cae8
    // 0xc3cad0: fadd            d2, d0, d1
    // 0xc3cad4: fcmp            d3, d2
    // 0xc3cad8: b.vs            #0xc3cae8
    // 0xc3cadc: b.ge            #0xc3cae8
    // 0xc3cae0: r0 = true
    //     0xc3cae0: add             x0, NULL, #0x20  ; true
    // 0xc3cae4: b               #0xc3cb04
    // 0xc3cae8: fcmp            d3, d0
    // 0xc3caec: b.vs            #0xc3caf4
    // 0xc3caf0: b.eq            #0xc3cafc
    // 0xc3caf4: r1 = false
    //     0xc3caf4: add             x1, NULL, #0x30  ; false
    // 0xc3caf8: b               #0xc3cb00
    // 0xc3cafc: r1 = true
    //     0xc3cafc: add             x1, NULL, #0x20  ; true
    // 0xc3cb00: mov             x0, x1
    // 0xc3cb04: ret
    //     0xc3cb04: ret             
  }
  static _ nearEqual(/* No info */) {
    // ** addr: 0xc748e8, size: 0xb8
    // 0xc748e8: EnterFrame
    //     0xc748e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc748ec: mov             fp, SP
    // 0xc748f0: CheckStackOverflow
    //     0xc748f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc748f4: cmp             SP, x16
    //     0xc748f8: b.ls            #0xc74998
    // 0xc748fc: ldr             x0, [fp, #0x20]
    // 0xc74900: cmp             w0, NULL
    // 0xc74904: b.ne            #0xc74938
    // 0xc74908: r1 = LoadClassIdInstr(r0)
    //     0xc74908: ldur            x1, [x0, #-1]
    //     0xc7490c: ubfx            x1, x1, #0xc, #0x14
    // 0xc74910: ldr             x16, [fp, #0x18]
    // 0xc74914: stp             x16, x0, [SP, #-0x10]!
    // 0xc74918: mov             x0, x1
    // 0xc7491c: mov             lr, x0
    // 0xc74920: ldr             lr, [x21, lr, lsl #3]
    // 0xc74924: blr             lr
    // 0xc74928: add             SP, SP, #0x10
    // 0xc7492c: LeaveFrame
    //     0xc7492c: mov             SP, fp
    //     0xc74930: ldp             fp, lr, [SP], #0x10
    // 0xc74934: ret
    //     0xc74934: ret             
    // 0xc74938: ldr             x1, [fp, #0x18]
    // 0xc7493c: ldr             d0, [fp, #0x10]
    // 0xc74940: LoadField: d1 = r1->field_7
    //     0xc74940: ldur            d1, [x1, #7]
    // 0xc74944: fsub            d2, d1, d0
    // 0xc74948: LoadField: d3 = r0->field_7
    //     0xc74948: ldur            d3, [x0, #7]
    // 0xc7494c: fcmp            d3, d2
    // 0xc74950: b.vs            #0xc74970
    // 0xc74954: b.le            #0xc74970
    // 0xc74958: fadd            d2, d1, d0
    // 0xc7495c: fcmp            d3, d2
    // 0xc74960: b.vs            #0xc74970
    // 0xc74964: b.ge            #0xc74970
    // 0xc74968: r0 = true
    //     0xc74968: add             x0, NULL, #0x20  ; true
    // 0xc7496c: b               #0xc7498c
    // 0xc74970: fcmp            d3, d1
    // 0xc74974: b.vs            #0xc7497c
    // 0xc74978: b.eq            #0xc74984
    // 0xc7497c: r1 = false
    //     0xc7497c: add             x1, NULL, #0x30  ; false
    // 0xc74980: b               #0xc74988
    // 0xc74984: r1 = true
    //     0xc74984: add             x1, NULL, #0x20  ; true
    // 0xc74988: mov             x0, x1
    // 0xc7498c: LeaveFrame
    //     0xc7498c: mov             SP, fp
    //     0xc74990: ldp             fp, lr, [SP], #0x10
    // 0xc74994: ret
    //     0xc74994: ret             
    // 0xc74998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc74998: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7499c: b               #0xc748fc
  }
}

// lib: , url: package:flutter/src/physics/spring_simulation.dart

// class id: 1049390, size: 0x8
class :: {
}

// class id: 2068, size: 0x28, field offset: 0x8
class _UnderdampedSolution extends Object
    implements _SpringSolution {

  factory _ _UnderdampedSolution(/* No info */) {
    // ** addr: 0x82d818, size: 0xa4
    // 0x82d818: EnterFrame
    //     0x82d818: stp             fp, lr, [SP, #-0x10]!
    //     0x82d81c: mov             fp, SP
    // 0x82d820: AllocStack(0x20)
    //     0x82d820: sub             SP, SP, #0x20
    // 0x82d824: d1 = 4.000000
    //     0x82d824: fmov            d1, #4.00000000
    // 0x82d828: d0 = 2.000000
    //     0x82d828: fmov            d0, #2.00000000
    // 0x82d82c: ldr             x0, [fp, #0x20]
    // 0x82d830: LoadField: d2 = r0->field_7
    //     0x82d830: ldur            d2, [x0, #7]
    // 0x82d834: fmul            d3, d1, d2
    // 0x82d838: LoadField: d1 = r0->field_f
    //     0x82d838: ldur            d1, [x0, #0xf]
    // 0x82d83c: fmul            d4, d3, d1
    // 0x82d840: LoadField: d1 = r0->field_17
    //     0x82d840: ldur            d1, [x0, #0x17]
    // 0x82d844: fmul            d3, d1, d1
    // 0x82d848: fsub            d5, d4, d3
    // 0x82d84c: fsqrt           d3, d5
    // 0x82d850: fmul            d4, d0, d2
    // 0x82d854: fdiv            d5, d3, d4
    // 0x82d858: stur            d5, [fp, #-0x20]
    // 0x82d85c: fdiv            d3, d1, d0
    // 0x82d860: fmul            d0, d3, d2
    // 0x82d864: fneg            d1, d0
    // 0x82d868: ldr             x0, [fp, #0x18]
    // 0x82d86c: stur            d1, [fp, #-0x18]
    // 0x82d870: LoadField: d0 = r0->field_7
    //     0x82d870: ldur            d0, [x0, #7]
    // 0x82d874: stur            d0, [fp, #-0x10]
    // 0x82d878: fmul            d2, d1, d0
    // 0x82d87c: ldr             d3, [fp, #0x10]
    // 0x82d880: fsub            d4, d3, d2
    // 0x82d884: fdiv            d2, d4, d5
    // 0x82d888: stur            d2, [fp, #-8]
    // 0x82d88c: r0 = _UnderdampedSolution()
    //     0x82d88c: bl              #0x82d8bc  ; Allocate_UnderdampedSolutionStub -> _UnderdampedSolution (size=0x28)
    // 0x82d890: ldur            d0, [fp, #-0x20]
    // 0x82d894: StoreField: r0->field_7 = d0
    //     0x82d894: stur            d0, [x0, #7]
    // 0x82d898: ldur            d0, [fp, #-0x18]
    // 0x82d89c: StoreField: r0->field_f = d0
    //     0x82d89c: stur            d0, [x0, #0xf]
    // 0x82d8a0: ldur            d0, [fp, #-0x10]
    // 0x82d8a4: StoreField: r0->field_17 = d0
    //     0x82d8a4: stur            d0, [x0, #0x17]
    // 0x82d8a8: ldur            d0, [fp, #-8]
    // 0x82d8ac: StoreField: r0->field_1f = d0
    //     0x82d8ac: stur            d0, [x0, #0x1f]
    // 0x82d8b0: LeaveFrame
    //     0x82d8b0: mov             SP, fp
    //     0x82d8b4: ldp             fp, lr, [SP], #0x10
    // 0x82d8b8: ret
    //     0x82d8b8: ret             
  }
  get _ type(/* No info */) {
    // ** addr: 0xcfc8e0, size: 0xc
    // 0xcfc8e0: r0 = Instance_SpringType
    //     0xcfc8e0: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b3e0] Obj!SpringType@b64d11
    //     0xcfc8e4: ldr             x0, [x0, #0x3e0]
    // 0xcfc8e8: ret
    //     0xcfc8e8: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0xcfcc5c, size: 0x1f0
    // 0xcfcc5c: EnterFrame
    //     0xcfcc5c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfcc60: mov             fp, SP
    // 0xcfcc64: AllocStack(0x20)
    //     0xcfcc64: sub             SP, SP, #0x20
    // 0xcfcc68: ldr             x0, [fp, #0x18]
    // 0xcfcc6c: LoadField: d2 = r0->field_f
    //     0xcfcc6c: ldur            d2, [x0, #0xf]
    // 0xcfcc70: ldr             d3, [fp, #0x10]
    // 0xcfcc74: stur            d2, [fp, #-8]
    // 0xcfcc78: fmul            d1, d2, d3
    // 0xcfcc7c: d0 = 2.718282
    //     0xcfcc7c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3d0] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xcfcc80: ldr             d0, [x17, #0x3d0]
    // 0xcfcc84: d30 = 0.000000
    //     0xcfcc84: fmov            d30, d0
    // 0xcfcc88: d0 = 1.000000
    //     0xcfcc88: fmov            d0, #1.00000000
    // 0xcfcc8c: fcmp            d1, #0.0
    // 0xcfcc90: b.vs            #0xcfccd4
    // 0xcfcc94: b.eq            #0xcfcd5c
    // 0xcfcc98: fcmp            d1, d0
    // 0xcfcc9c: b.eq            #0xcfccc4
    // 0xcfcca0: d31 = 2.000000
    //     0xcfcca0: fmov            d31, #2.00000000
    // 0xcfcca4: fcmp            d1, d31
    // 0xcfcca8: b.eq            #0xcfcccc
    // 0xcfccac: d31 = 3.000000
    //     0xcfccac: fmov            d31, #3.00000000
    // 0xcfccb0: fcmp            d1, d31
    // 0xcfccb4: b.ne            #0xcfccd4
    // 0xcfccb8: fmul            d0, d30, d30
    // 0xcfccbc: fmul            d0, d0, d30
    // 0xcfccc0: b               #0xcfcd5c
    // 0xcfccc4: d0 = 0.000000
    //     0xcfccc4: fmov            d0, d30
    // 0xcfccc8: b               #0xcfcd5c
    // 0xcfcccc: fmul            d0, d30, d30
    // 0xcfccd0: b               #0xcfcd5c
    // 0xcfccd4: fcmp            d30, d0
    // 0xcfccd8: b.vs            #0xcfcce8
    // 0xcfccdc: b.eq            #0xcfcd5c
    // 0xcfcce0: fcmp            d30, d1
    // 0xcfcce4: b.vc            #0xcfccf4
    // 0xcfcce8: d0 = nan
    //     0xcfcce8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcfccec: ldr             d0, [x17, #0x240]
    // 0xcfccf0: b               #0xcfcd5c
    // 0xcfccf4: d0 = -inf
    //     0xcfccf4: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcfccf8: fcmp            d30, d0
    // 0xcfccfc: b.eq            #0xcfcd24
    // 0xcfcd00: d0 = 0.500000
    //     0xcfcd00: fmov            d0, #0.50000000
    // 0xcfcd04: fcmp            d1, d0
    // 0xcfcd08: b.ne            #0xcfcd24
    // 0xcfcd0c: fcmp            d30, #0.0
    // 0xcfcd10: b.eq            #0xcfcd1c
    // 0xcfcd14: fsqrt           d0, d30
    // 0xcfcd18: b               #0xcfcd5c
    // 0xcfcd1c: d0 = 0.000000
    //     0xcfcd1c: eor             v0.16b, v0.16b, v0.16b
    // 0xcfcd20: b               #0xcfcd5c
    // 0xcfcd24: d0 = 0.000000
    //     0xcfcd24: fmov            d0, d30
    // 0xcfcd28: stp             fp, lr, [SP, #-0x10]!
    // 0xcfcd2c: mov             fp, SP
    // 0xcfcd30: CallRuntime_LibcPow(double, double) -> double
    //     0xcfcd30: and             SP, SP, #0xfffffffffffffff0
    //     0xcfcd34: mov             sp, SP
    //     0xcfcd38: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcfcd3c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcd40: blr             x16
    //     0xcfcd44: mov             x16, #8
    //     0xcfcd48: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcd4c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfcd50: sub             sp, x16, #1, lsl #12
    //     0xcfcd54: mov             SP, fp
    //     0xcfcd58: ldp             fp, lr, [SP], #0x10
    // 0xcfcd5c: mov             v1.16b, v0.16b
    // 0xcfcd60: ldr             x0, [fp, #0x18]
    // 0xcfcd64: stur            d1, [fp, #-0x20]
    // 0xcfcd68: LoadField: d2 = r0->field_7
    //     0xcfcd68: ldur            d2, [x0, #7]
    // 0xcfcd6c: ldr             d0, [fp, #0x10]
    // 0xcfcd70: stur            d2, [fp, #-0x18]
    // 0xcfcd74: fmul            d3, d2, d0
    // 0xcfcd78: mov             v0.16b, v3.16b
    // 0xcfcd7c: stur            d3, [fp, #-0x10]
    // 0xcfcd80: stp             fp, lr, [SP, #-0x10]!
    // 0xcfcd84: mov             fp, SP
    // 0xcfcd88: CallRuntime_LibcCos(double) -> double
    //     0xcfcd88: and             SP, SP, #0xfffffffffffffff0
    //     0xcfcd8c: mov             sp, SP
    //     0xcfcd90: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xcfcd94: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcd98: blr             x16
    //     0xcfcd9c: mov             x16, #8
    //     0xcfcda0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcda4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfcda8: sub             sp, x16, #1, lsl #12
    //     0xcfcdac: mov             SP, fp
    //     0xcfcdb0: ldp             fp, lr, [SP], #0x10
    // 0xcfcdb4: mov             v1.16b, v0.16b
    // 0xcfcdb8: ldur            d0, [fp, #-0x10]
    // 0xcfcdbc: stur            d1, [fp, #-0x10]
    // 0xcfcdc0: stp             fp, lr, [SP, #-0x10]!
    // 0xcfcdc4: mov             fp, SP
    // 0xcfcdc8: CallRuntime_LibcSin(double) -> double
    //     0xcfcdc8: and             SP, SP, #0xfffffffffffffff0
    //     0xcfcdcc: mov             sp, SP
    //     0xcfcdd0: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xcfcdd4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcdd8: blr             x16
    //     0xcfcddc: mov             x16, #8
    //     0xcfcde0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcde4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfcde8: sub             sp, x16, #1, lsl #12
    //     0xcfcdec: mov             SP, fp
    //     0xcfcdf0: ldp             fp, lr, [SP], #0x10
    // 0xcfcdf4: ldr             x0, [fp, #0x18]
    // 0xcfcdf8: LoadField: d1 = r0->field_1f
    //     0xcfcdf8: ldur            d1, [x0, #0x1f]
    // 0xcfcdfc: ldur            d2, [fp, #-0x18]
    // 0xcfce00: fmul            d3, d1, d2
    // 0xcfce04: ldur            d4, [fp, #-0x10]
    // 0xcfce08: fmul            d5, d3, d4
    // 0xcfce0c: LoadField: d3 = r0->field_17
    //     0xcfce0c: ldur            d3, [x0, #0x17]
    // 0xcfce10: fmul            d6, d3, d2
    // 0xcfce14: fmul            d2, d6, d0
    // 0xcfce18: fsub            d6, d5, d2
    // 0xcfce1c: ldur            d2, [fp, #-0x20]
    // 0xcfce20: fmul            d5, d2, d6
    // 0xcfce24: ldur            d6, [fp, #-8]
    // 0xcfce28: fmul            d7, d6, d2
    // 0xcfce2c: fmul            d2, d1, d0
    // 0xcfce30: fmul            d1, d3, d4
    // 0xcfce34: fadd            d3, d2, d1
    // 0xcfce38: fmul            d1, d7, d3
    // 0xcfce3c: fadd            d0, d5, d1
    // 0xcfce40: LeaveFrame
    //     0xcfce40: mov             SP, fp
    //     0xcfce44: ldp             fp, lr, [SP], #0x10
    // 0xcfce48: ret
    //     0xcfce48: ret             
  }
  _ x(/* No info */) {
    // ** addr: 0xcfd1a0, size: 0x1d0
    // 0xcfd1a0: EnterFrame
    //     0xcfd1a0: stp             fp, lr, [SP, #-0x10]!
    //     0xcfd1a4: mov             fp, SP
    // 0xcfd1a8: AllocStack(0x20)
    //     0xcfd1a8: sub             SP, SP, #0x20
    // 0xcfd1ac: ldr             x0, [fp, #0x18]
    // 0xcfd1b0: LoadField: d0 = r0->field_f
    //     0xcfd1b0: ldur            d0, [x0, #0xf]
    // 0xcfd1b4: ldr             d2, [fp, #0x10]
    // 0xcfd1b8: fmul            d1, d0, d2
    // 0xcfd1bc: d0 = 2.718282
    //     0xcfd1bc: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3d0] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xcfd1c0: ldr             d0, [x17, #0x3d0]
    // 0xcfd1c4: d30 = 0.000000
    //     0xcfd1c4: fmov            d30, d0
    // 0xcfd1c8: d0 = 1.000000
    //     0xcfd1c8: fmov            d0, #1.00000000
    // 0xcfd1cc: fcmp            d1, #0.0
    // 0xcfd1d0: b.vs            #0xcfd214
    // 0xcfd1d4: b.eq            #0xcfd29c
    // 0xcfd1d8: fcmp            d1, d0
    // 0xcfd1dc: b.eq            #0xcfd204
    // 0xcfd1e0: d31 = 2.000000
    //     0xcfd1e0: fmov            d31, #2.00000000
    // 0xcfd1e4: fcmp            d1, d31
    // 0xcfd1e8: b.eq            #0xcfd20c
    // 0xcfd1ec: d31 = 3.000000
    //     0xcfd1ec: fmov            d31, #3.00000000
    // 0xcfd1f0: fcmp            d1, d31
    // 0xcfd1f4: b.ne            #0xcfd214
    // 0xcfd1f8: fmul            d0, d30, d30
    // 0xcfd1fc: fmul            d0, d0, d30
    // 0xcfd200: b               #0xcfd29c
    // 0xcfd204: d0 = 0.000000
    //     0xcfd204: fmov            d0, d30
    // 0xcfd208: b               #0xcfd29c
    // 0xcfd20c: fmul            d0, d30, d30
    // 0xcfd210: b               #0xcfd29c
    // 0xcfd214: fcmp            d30, d0
    // 0xcfd218: b.vs            #0xcfd228
    // 0xcfd21c: b.eq            #0xcfd29c
    // 0xcfd220: fcmp            d30, d1
    // 0xcfd224: b.vc            #0xcfd234
    // 0xcfd228: d0 = nan
    //     0xcfd228: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcfd22c: ldr             d0, [x17, #0x240]
    // 0xcfd230: b               #0xcfd29c
    // 0xcfd234: d0 = -inf
    //     0xcfd234: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcfd238: fcmp            d30, d0
    // 0xcfd23c: b.eq            #0xcfd264
    // 0xcfd240: d0 = 0.500000
    //     0xcfd240: fmov            d0, #0.50000000
    // 0xcfd244: fcmp            d1, d0
    // 0xcfd248: b.ne            #0xcfd264
    // 0xcfd24c: fcmp            d30, #0.0
    // 0xcfd250: b.eq            #0xcfd25c
    // 0xcfd254: fsqrt           d0, d30
    // 0xcfd258: b               #0xcfd29c
    // 0xcfd25c: d0 = 0.000000
    //     0xcfd25c: eor             v0.16b, v0.16b, v0.16b
    // 0xcfd260: b               #0xcfd29c
    // 0xcfd264: d0 = 0.000000
    //     0xcfd264: fmov            d0, d30
    // 0xcfd268: stp             fp, lr, [SP, #-0x10]!
    // 0xcfd26c: mov             fp, SP
    // 0xcfd270: CallRuntime_LibcPow(double, double) -> double
    //     0xcfd270: and             SP, SP, #0xfffffffffffffff0
    //     0xcfd274: mov             sp, SP
    //     0xcfd278: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcfd27c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd280: blr             x16
    //     0xcfd284: mov             x16, #8
    //     0xcfd288: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd28c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfd290: sub             sp, x16, #1, lsl #12
    //     0xcfd294: mov             SP, fp
    //     0xcfd298: ldp             fp, lr, [SP], #0x10
    // 0xcfd29c: mov             v1.16b, v0.16b
    // 0xcfd2a0: ldr             x0, [fp, #0x18]
    // 0xcfd2a4: stur            d1, [fp, #-0x18]
    // 0xcfd2a8: LoadField: d2 = r0->field_17
    //     0xcfd2a8: ldur            d2, [x0, #0x17]
    // 0xcfd2ac: stur            d2, [fp, #-0x10]
    // 0xcfd2b0: LoadField: d0 = r0->field_7
    //     0xcfd2b0: ldur            d0, [x0, #7]
    // 0xcfd2b4: ldr             d3, [fp, #0x10]
    // 0xcfd2b8: fmul            d4, d0, d3
    // 0xcfd2bc: mov             v0.16b, v4.16b
    // 0xcfd2c0: stur            d4, [fp, #-8]
    // 0xcfd2c4: stp             fp, lr, [SP, #-0x10]!
    // 0xcfd2c8: mov             fp, SP
    // 0xcfd2cc: CallRuntime_LibcCos(double) -> double
    //     0xcfd2cc: and             SP, SP, #0xfffffffffffffff0
    //     0xcfd2d0: mov             sp, SP
    //     0xcfd2d4: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xcfd2d8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd2dc: blr             x16
    //     0xcfd2e0: mov             x16, #8
    //     0xcfd2e4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd2e8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfd2ec: sub             sp, x16, #1, lsl #12
    //     0xcfd2f0: mov             SP, fp
    //     0xcfd2f4: ldp             fp, lr, [SP], #0x10
    // 0xcfd2f8: mov             v1.16b, v0.16b
    // 0xcfd2fc: ldur            d0, [fp, #-0x10]
    // 0xcfd300: fmul            d2, d0, d1
    // 0xcfd304: ldr             x0, [fp, #0x18]
    // 0xcfd308: stur            d2, [fp, #-0x20]
    // 0xcfd30c: LoadField: d1 = r0->field_1f
    //     0xcfd30c: ldur            d1, [x0, #0x1f]
    // 0xcfd310: ldur            d0, [fp, #-8]
    // 0xcfd314: stur            d1, [fp, #-0x10]
    // 0xcfd318: stp             fp, lr, [SP, #-0x10]!
    // 0xcfd31c: mov             fp, SP
    // 0xcfd320: CallRuntime_LibcSin(double) -> double
    //     0xcfd320: and             SP, SP, #0xfffffffffffffff0
    //     0xcfd324: mov             sp, SP
    //     0xcfd328: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xcfd32c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd330: blr             x16
    //     0xcfd334: mov             x16, #8
    //     0xcfd338: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd33c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfd340: sub             sp, x16, #1, lsl #12
    //     0xcfd344: mov             SP, fp
    //     0xcfd348: ldp             fp, lr, [SP], #0x10
    // 0xcfd34c: ldur            d1, [fp, #-0x10]
    // 0xcfd350: fmul            d2, d1, d0
    // 0xcfd354: ldur            d1, [fp, #-0x20]
    // 0xcfd358: fadd            d3, d1, d2
    // 0xcfd35c: ldur            d1, [fp, #-0x18]
    // 0xcfd360: fmul            d0, d1, d3
    // 0xcfd364: LeaveFrame
    //     0xcfd364: mov             SP, fp
    //     0xcfd368: ldp             fp, lr, [SP], #0x10
    // 0xcfd36c: ret
    //     0xcfd36c: ret             
  }
}

// class id: 2069, size: 0x28, field offset: 0x8
class _OverdampedSolution extends Object
    implements _SpringSolution {

  factory _ _OverdampedSolution(/* No info */) {
    // ** addr: 0x82d8c8, size: 0xb0
    // 0x82d8c8: EnterFrame
    //     0x82d8c8: stp             fp, lr, [SP, #-0x10]!
    //     0x82d8cc: mov             fp, SP
    // 0x82d8d0: AllocStack(0x20)
    //     0x82d8d0: sub             SP, SP, #0x20
    // 0x82d8d4: d1 = 4.000000
    //     0x82d8d4: fmov            d1, #4.00000000
    // 0x82d8d8: d0 = 2.000000
    //     0x82d8d8: fmov            d0, #2.00000000
    // 0x82d8dc: ldr             x0, [fp, #0x20]
    // 0x82d8e0: LoadField: d2 = r0->field_17
    //     0x82d8e0: ldur            d2, [x0, #0x17]
    // 0x82d8e4: fmul            d3, d2, d2
    // 0x82d8e8: LoadField: d4 = r0->field_7
    //     0x82d8e8: ldur            d4, [x0, #7]
    // 0x82d8ec: fmul            d5, d1, d4
    // 0x82d8f0: LoadField: d1 = r0->field_f
    //     0x82d8f0: ldur            d1, [x0, #0xf]
    // 0x82d8f4: fmul            d6, d5, d1
    // 0x82d8f8: fsub            d1, d3, d6
    // 0x82d8fc: fneg            d3, d2
    // 0x82d900: fsqrt           d2, d1
    // 0x82d904: fsub            d1, d3, d2
    // 0x82d908: fmul            d5, d0, d4
    // 0x82d90c: fdiv            d0, d1, d5
    // 0x82d910: stur            d0, [fp, #-0x20]
    // 0x82d914: fadd            d1, d3, d2
    // 0x82d918: fdiv            d2, d1, d5
    // 0x82d91c: ldr             x0, [fp, #0x18]
    // 0x82d920: stur            d2, [fp, #-0x18]
    // 0x82d924: LoadField: d1 = r0->field_7
    //     0x82d924: ldur            d1, [x0, #7]
    // 0x82d928: fmul            d3, d0, d1
    // 0x82d92c: ldr             d4, [fp, #0x10]
    // 0x82d930: fsub            d5, d4, d3
    // 0x82d934: fsub            d3, d2, d0
    // 0x82d938: fdiv            d4, d5, d3
    // 0x82d93c: stur            d4, [fp, #-0x10]
    // 0x82d940: fsub            d3, d1, d4
    // 0x82d944: stur            d3, [fp, #-8]
    // 0x82d948: r0 = _OverdampedSolution()
    //     0x82d948: bl              #0x82d978  ; Allocate_OverdampedSolutionStub -> _OverdampedSolution (size=0x28)
    // 0x82d94c: ldur            d0, [fp, #-0x20]
    // 0x82d950: StoreField: r0->field_7 = d0
    //     0x82d950: stur            d0, [x0, #7]
    // 0x82d954: ldur            d0, [fp, #-0x18]
    // 0x82d958: StoreField: r0->field_f = d0
    //     0x82d958: stur            d0, [x0, #0xf]
    // 0x82d95c: ldur            d0, [fp, #-8]
    // 0x82d960: StoreField: r0->field_17 = d0
    //     0x82d960: stur            d0, [x0, #0x17]
    // 0x82d964: ldur            d0, [fp, #-0x10]
    // 0x82d968: StoreField: r0->field_1f = d0
    //     0x82d968: stur            d0, [x0, #0x1f]
    // 0x82d96c: LeaveFrame
    //     0x82d96c: mov             SP, fp
    //     0x82d970: ldp             fp, lr, [SP], #0x10
    // 0x82d974: ret
    //     0x82d974: ret             
  }
  get _ type(/* No info */) {
    // ** addr: 0xcfc8d4, size: 0xc
    // 0xcfc8d4: r0 = Instance_SpringType
    //     0xcfc8d4: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b3c8] Obj!SpringType@b64cf1
    //     0xcfc8d8: ldr             x0, [x0, #0x3c8]
    // 0xcfc8dc: ret
    //     0xcfc8dc: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0xcfca24, size: 0x238
    // 0xcfca24: EnterFrame
    //     0xcfca24: stp             fp, lr, [SP, #-0x10]!
    //     0xcfca28: mov             fp, SP
    // 0xcfca2c: AllocStack(0x10)
    //     0xcfca2c: sub             SP, SP, #0x10
    // 0xcfca30: ldr             x0, [fp, #0x18]
    // 0xcfca34: LoadField: d0 = r0->field_17
    //     0xcfca34: ldur            d0, [x0, #0x17]
    // 0xcfca38: LoadField: d1 = r0->field_7
    //     0xcfca38: ldur            d1, [x0, #7]
    // 0xcfca3c: fmul            d2, d0, d1
    // 0xcfca40: ldr             d3, [fp, #0x10]
    // 0xcfca44: stur            d2, [fp, #-8]
    // 0xcfca48: fmul            d0, d1, d3
    // 0xcfca4c: mov             v1.16b, v0.16b
    // 0xcfca50: d0 = 2.718282
    //     0xcfca50: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3d0] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xcfca54: ldr             d0, [x17, #0x3d0]
    // 0xcfca58: d30 = 0.000000
    //     0xcfca58: fmov            d30, d0
    // 0xcfca5c: d0 = 1.000000
    //     0xcfca5c: fmov            d0, #1.00000000
    // 0xcfca60: fcmp            d1, #0.0
    // 0xcfca64: b.vs            #0xcfcaa8
    // 0xcfca68: b.eq            #0xcfcb30
    // 0xcfca6c: fcmp            d1, d0
    // 0xcfca70: b.eq            #0xcfca98
    // 0xcfca74: d31 = 2.000000
    //     0xcfca74: fmov            d31, #2.00000000
    // 0xcfca78: fcmp            d1, d31
    // 0xcfca7c: b.eq            #0xcfcaa0
    // 0xcfca80: d31 = 3.000000
    //     0xcfca80: fmov            d31, #3.00000000
    // 0xcfca84: fcmp            d1, d31
    // 0xcfca88: b.ne            #0xcfcaa8
    // 0xcfca8c: fmul            d0, d30, d30
    // 0xcfca90: fmul            d0, d0, d30
    // 0xcfca94: b               #0xcfcb30
    // 0xcfca98: d0 = 0.000000
    //     0xcfca98: fmov            d0, d30
    // 0xcfca9c: b               #0xcfcb30
    // 0xcfcaa0: fmul            d0, d30, d30
    // 0xcfcaa4: b               #0xcfcb30
    // 0xcfcaa8: fcmp            d30, d0
    // 0xcfcaac: b.vs            #0xcfcabc
    // 0xcfcab0: b.eq            #0xcfcb30
    // 0xcfcab4: fcmp            d30, d1
    // 0xcfcab8: b.vc            #0xcfcac8
    // 0xcfcabc: d0 = nan
    //     0xcfcabc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcfcac0: ldr             d0, [x17, #0x240]
    // 0xcfcac4: b               #0xcfcb30
    // 0xcfcac8: d0 = -inf
    //     0xcfcac8: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcfcacc: fcmp            d30, d0
    // 0xcfcad0: b.eq            #0xcfcaf8
    // 0xcfcad4: d0 = 0.500000
    //     0xcfcad4: fmov            d0, #0.50000000
    // 0xcfcad8: fcmp            d1, d0
    // 0xcfcadc: b.ne            #0xcfcaf8
    // 0xcfcae0: fcmp            d30, #0.0
    // 0xcfcae4: b.eq            #0xcfcaf0
    // 0xcfcae8: fsqrt           d0, d30
    // 0xcfcaec: b               #0xcfcb30
    // 0xcfcaf0: d0 = 0.000000
    //     0xcfcaf0: eor             v0.16b, v0.16b, v0.16b
    // 0xcfcaf4: b               #0xcfcb30
    // 0xcfcaf8: d0 = 0.000000
    //     0xcfcaf8: fmov            d0, d30
    // 0xcfcafc: stp             fp, lr, [SP, #-0x10]!
    // 0xcfcb00: mov             fp, SP
    // 0xcfcb04: CallRuntime_LibcPow(double, double) -> double
    //     0xcfcb04: and             SP, SP, #0xfffffffffffffff0
    //     0xcfcb08: mov             sp, SP
    //     0xcfcb0c: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcfcb10: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcb14: blr             x16
    //     0xcfcb18: mov             x16, #8
    //     0xcfcb1c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcb20: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfcb24: sub             sp, x16, #1, lsl #12
    //     0xcfcb28: mov             SP, fp
    //     0xcfcb2c: ldp             fp, lr, [SP], #0x10
    // 0xcfcb30: mov             v1.16b, v0.16b
    // 0xcfcb34: ldur            d0, [fp, #-8]
    // 0xcfcb38: fmul            d2, d0, d1
    // 0xcfcb3c: ldr             x0, [fp, #0x18]
    // 0xcfcb40: stur            d2, [fp, #-0x10]
    // 0xcfcb44: LoadField: d0 = r0->field_1f
    //     0xcfcb44: ldur            d0, [x0, #0x1f]
    // 0xcfcb48: LoadField: d1 = r0->field_f
    //     0xcfcb48: ldur            d1, [x0, #0xf]
    // 0xcfcb4c: fmul            d3, d0, d1
    // 0xcfcb50: ldr             d0, [fp, #0x10]
    // 0xcfcb54: stur            d3, [fp, #-8]
    // 0xcfcb58: fmul            d4, d1, d0
    // 0xcfcb5c: mov             v1.16b, v4.16b
    // 0xcfcb60: d0 = 2.718282
    //     0xcfcb60: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3d0] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xcfcb64: ldr             d0, [x17, #0x3d0]
    // 0xcfcb68: d30 = 0.000000
    //     0xcfcb68: fmov            d30, d0
    // 0xcfcb6c: d0 = 1.000000
    //     0xcfcb6c: fmov            d0, #1.00000000
    // 0xcfcb70: fcmp            d1, #0.0
    // 0xcfcb74: b.vs            #0xcfcbb8
    // 0xcfcb78: b.eq            #0xcfcc40
    // 0xcfcb7c: fcmp            d1, d0
    // 0xcfcb80: b.eq            #0xcfcba8
    // 0xcfcb84: d31 = 2.000000
    //     0xcfcb84: fmov            d31, #2.00000000
    // 0xcfcb88: fcmp            d1, d31
    // 0xcfcb8c: b.eq            #0xcfcbb0
    // 0xcfcb90: d31 = 3.000000
    //     0xcfcb90: fmov            d31, #3.00000000
    // 0xcfcb94: fcmp            d1, d31
    // 0xcfcb98: b.ne            #0xcfcbb8
    // 0xcfcb9c: fmul            d0, d30, d30
    // 0xcfcba0: fmul            d0, d0, d30
    // 0xcfcba4: b               #0xcfcc40
    // 0xcfcba8: d0 = 0.000000
    //     0xcfcba8: fmov            d0, d30
    // 0xcfcbac: b               #0xcfcc40
    // 0xcfcbb0: fmul            d0, d30, d30
    // 0xcfcbb4: b               #0xcfcc40
    // 0xcfcbb8: fcmp            d30, d0
    // 0xcfcbbc: b.vs            #0xcfcbcc
    // 0xcfcbc0: b.eq            #0xcfcc40
    // 0xcfcbc4: fcmp            d30, d1
    // 0xcfcbc8: b.vc            #0xcfcbd8
    // 0xcfcbcc: d0 = nan
    //     0xcfcbcc: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcfcbd0: ldr             d0, [x17, #0x240]
    // 0xcfcbd4: b               #0xcfcc40
    // 0xcfcbd8: d0 = -inf
    //     0xcfcbd8: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcfcbdc: fcmp            d30, d0
    // 0xcfcbe0: b.eq            #0xcfcc08
    // 0xcfcbe4: d0 = 0.500000
    //     0xcfcbe4: fmov            d0, #0.50000000
    // 0xcfcbe8: fcmp            d1, d0
    // 0xcfcbec: b.ne            #0xcfcc08
    // 0xcfcbf0: fcmp            d30, #0.0
    // 0xcfcbf4: b.eq            #0xcfcc00
    // 0xcfcbf8: fsqrt           d0, d30
    // 0xcfcbfc: b               #0xcfcc40
    // 0xcfcc00: d0 = 0.000000
    //     0xcfcc00: eor             v0.16b, v0.16b, v0.16b
    // 0xcfcc04: b               #0xcfcc40
    // 0xcfcc08: d0 = 0.000000
    //     0xcfcc08: fmov            d0, d30
    // 0xcfcc0c: stp             fp, lr, [SP, #-0x10]!
    // 0xcfcc10: mov             fp, SP
    // 0xcfcc14: CallRuntime_LibcPow(double, double) -> double
    //     0xcfcc14: and             SP, SP, #0xfffffffffffffff0
    //     0xcfcc18: mov             sp, SP
    //     0xcfcc1c: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcfcc20: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcc24: blr             x16
    //     0xcfcc28: mov             x16, #8
    //     0xcfcc2c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcc30: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfcc34: sub             sp, x16, #1, lsl #12
    //     0xcfcc38: mov             SP, fp
    //     0xcfcc3c: ldp             fp, lr, [SP], #0x10
    // 0xcfcc40: ldur            d1, [fp, #-8]
    // 0xcfcc44: fmul            d2, d1, d0
    // 0xcfcc48: ldur            d1, [fp, #-0x10]
    // 0xcfcc4c: fadd            d0, d1, d2
    // 0xcfcc50: LeaveFrame
    //     0xcfcc50: mov             SP, fp
    //     0xcfcc54: ldp             fp, lr, [SP], #0x10
    // 0xcfcc58: ret
    //     0xcfcc58: ret             
  }
  _ x(/* No info */) {
    // ** addr: 0xcfcf74, size: 0x22c
    // 0xcfcf74: EnterFrame
    //     0xcfcf74: stp             fp, lr, [SP, #-0x10]!
    //     0xcfcf78: mov             fp, SP
    // 0xcfcf7c: AllocStack(0x10)
    //     0xcfcf7c: sub             SP, SP, #0x10
    // 0xcfcf80: ldr             x0, [fp, #0x18]
    // 0xcfcf84: LoadField: d2 = r0->field_17
    //     0xcfcf84: ldur            d2, [x0, #0x17]
    // 0xcfcf88: stur            d2, [fp, #-8]
    // 0xcfcf8c: LoadField: d0 = r0->field_7
    //     0xcfcf8c: ldur            d0, [x0, #7]
    // 0xcfcf90: ldr             d3, [fp, #0x10]
    // 0xcfcf94: fmul            d1, d0, d3
    // 0xcfcf98: d0 = 2.718282
    //     0xcfcf98: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3d0] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xcfcf9c: ldr             d0, [x17, #0x3d0]
    // 0xcfcfa0: d30 = 0.000000
    //     0xcfcfa0: fmov            d30, d0
    // 0xcfcfa4: d0 = 1.000000
    //     0xcfcfa4: fmov            d0, #1.00000000
    // 0xcfcfa8: fcmp            d1, #0.0
    // 0xcfcfac: b.vs            #0xcfcff0
    // 0xcfcfb0: b.eq            #0xcfd078
    // 0xcfcfb4: fcmp            d1, d0
    // 0xcfcfb8: b.eq            #0xcfcfe0
    // 0xcfcfbc: d31 = 2.000000
    //     0xcfcfbc: fmov            d31, #2.00000000
    // 0xcfcfc0: fcmp            d1, d31
    // 0xcfcfc4: b.eq            #0xcfcfe8
    // 0xcfcfc8: d31 = 3.000000
    //     0xcfcfc8: fmov            d31, #3.00000000
    // 0xcfcfcc: fcmp            d1, d31
    // 0xcfcfd0: b.ne            #0xcfcff0
    // 0xcfcfd4: fmul            d0, d30, d30
    // 0xcfcfd8: fmul            d0, d0, d30
    // 0xcfcfdc: b               #0xcfd078
    // 0xcfcfe0: d0 = 0.000000
    //     0xcfcfe0: fmov            d0, d30
    // 0xcfcfe4: b               #0xcfd078
    // 0xcfcfe8: fmul            d0, d30, d30
    // 0xcfcfec: b               #0xcfd078
    // 0xcfcff0: fcmp            d30, d0
    // 0xcfcff4: b.vs            #0xcfd004
    // 0xcfcff8: b.eq            #0xcfd078
    // 0xcfcffc: fcmp            d30, d1
    // 0xcfd000: b.vc            #0xcfd010
    // 0xcfd004: d0 = nan
    //     0xcfd004: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcfd008: ldr             d0, [x17, #0x240]
    // 0xcfd00c: b               #0xcfd078
    // 0xcfd010: d0 = -inf
    //     0xcfd010: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcfd014: fcmp            d30, d0
    // 0xcfd018: b.eq            #0xcfd040
    // 0xcfd01c: d0 = 0.500000
    //     0xcfd01c: fmov            d0, #0.50000000
    // 0xcfd020: fcmp            d1, d0
    // 0xcfd024: b.ne            #0xcfd040
    // 0xcfd028: fcmp            d30, #0.0
    // 0xcfd02c: b.eq            #0xcfd038
    // 0xcfd030: fsqrt           d0, d30
    // 0xcfd034: b               #0xcfd078
    // 0xcfd038: d0 = 0.000000
    //     0xcfd038: eor             v0.16b, v0.16b, v0.16b
    // 0xcfd03c: b               #0xcfd078
    // 0xcfd040: d0 = 0.000000
    //     0xcfd040: fmov            d0, d30
    // 0xcfd044: stp             fp, lr, [SP, #-0x10]!
    // 0xcfd048: mov             fp, SP
    // 0xcfd04c: CallRuntime_LibcPow(double, double) -> double
    //     0xcfd04c: and             SP, SP, #0xfffffffffffffff0
    //     0xcfd050: mov             sp, SP
    //     0xcfd054: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcfd058: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd05c: blr             x16
    //     0xcfd060: mov             x16, #8
    //     0xcfd064: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd068: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfd06c: sub             sp, x16, #1, lsl #12
    //     0xcfd070: mov             SP, fp
    //     0xcfd074: ldp             fp, lr, [SP], #0x10
    // 0xcfd078: mov             v1.16b, v0.16b
    // 0xcfd07c: ldur            d0, [fp, #-8]
    // 0xcfd080: fmul            d2, d0, d1
    // 0xcfd084: ldr             x0, [fp, #0x18]
    // 0xcfd088: stur            d2, [fp, #-0x10]
    // 0xcfd08c: LoadField: d3 = r0->field_1f
    //     0xcfd08c: ldur            d3, [x0, #0x1f]
    // 0xcfd090: stur            d3, [fp, #-8]
    // 0xcfd094: LoadField: d0 = r0->field_f
    //     0xcfd094: ldur            d0, [x0, #0xf]
    // 0xcfd098: ldr             d1, [fp, #0x10]
    // 0xcfd09c: fmul            d4, d0, d1
    // 0xcfd0a0: mov             v1.16b, v4.16b
    // 0xcfd0a4: d0 = 2.718282
    //     0xcfd0a4: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3d0] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xcfd0a8: ldr             d0, [x17, #0x3d0]
    // 0xcfd0ac: d30 = 0.000000
    //     0xcfd0ac: fmov            d30, d0
    // 0xcfd0b0: d0 = 1.000000
    //     0xcfd0b0: fmov            d0, #1.00000000
    // 0xcfd0b4: fcmp            d1, #0.0
    // 0xcfd0b8: b.vs            #0xcfd0fc
    // 0xcfd0bc: b.eq            #0xcfd184
    // 0xcfd0c0: fcmp            d1, d0
    // 0xcfd0c4: b.eq            #0xcfd0ec
    // 0xcfd0c8: d31 = 2.000000
    //     0xcfd0c8: fmov            d31, #2.00000000
    // 0xcfd0cc: fcmp            d1, d31
    // 0xcfd0d0: b.eq            #0xcfd0f4
    // 0xcfd0d4: d31 = 3.000000
    //     0xcfd0d4: fmov            d31, #3.00000000
    // 0xcfd0d8: fcmp            d1, d31
    // 0xcfd0dc: b.ne            #0xcfd0fc
    // 0xcfd0e0: fmul            d0, d30, d30
    // 0xcfd0e4: fmul            d0, d0, d30
    // 0xcfd0e8: b               #0xcfd184
    // 0xcfd0ec: d0 = 0.000000
    //     0xcfd0ec: fmov            d0, d30
    // 0xcfd0f0: b               #0xcfd184
    // 0xcfd0f4: fmul            d0, d30, d30
    // 0xcfd0f8: b               #0xcfd184
    // 0xcfd0fc: fcmp            d30, d0
    // 0xcfd100: b.vs            #0xcfd110
    // 0xcfd104: b.eq            #0xcfd184
    // 0xcfd108: fcmp            d30, d1
    // 0xcfd10c: b.vc            #0xcfd11c
    // 0xcfd110: d0 = nan
    //     0xcfd110: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcfd114: ldr             d0, [x17, #0x240]
    // 0xcfd118: b               #0xcfd184
    // 0xcfd11c: d0 = -inf
    //     0xcfd11c: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcfd120: fcmp            d30, d0
    // 0xcfd124: b.eq            #0xcfd14c
    // 0xcfd128: d0 = 0.500000
    //     0xcfd128: fmov            d0, #0.50000000
    // 0xcfd12c: fcmp            d1, d0
    // 0xcfd130: b.ne            #0xcfd14c
    // 0xcfd134: fcmp            d30, #0.0
    // 0xcfd138: b.eq            #0xcfd144
    // 0xcfd13c: fsqrt           d0, d30
    // 0xcfd140: b               #0xcfd184
    // 0xcfd144: d0 = 0.000000
    //     0xcfd144: eor             v0.16b, v0.16b, v0.16b
    // 0xcfd148: b               #0xcfd184
    // 0xcfd14c: d0 = 0.000000
    //     0xcfd14c: fmov            d0, d30
    // 0xcfd150: stp             fp, lr, [SP, #-0x10]!
    // 0xcfd154: mov             fp, SP
    // 0xcfd158: CallRuntime_LibcPow(double, double) -> double
    //     0xcfd158: and             SP, SP, #0xfffffffffffffff0
    //     0xcfd15c: mov             sp, SP
    //     0xcfd160: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcfd164: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd168: blr             x16
    //     0xcfd16c: mov             x16, #8
    //     0xcfd170: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfd174: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfd178: sub             sp, x16, #1, lsl #12
    //     0xcfd17c: mov             SP, fp
    //     0xcfd180: ldp             fp, lr, [SP], #0x10
    // 0xcfd184: ldur            d1, [fp, #-8]
    // 0xcfd188: fmul            d2, d1, d0
    // 0xcfd18c: ldur            d1, [fp, #-0x10]
    // 0xcfd190: fadd            d0, d1, d2
    // 0xcfd194: LeaveFrame
    //     0xcfd194: mov             SP, fp
    //     0xcfd198: ldp             fp, lr, [SP], #0x10
    // 0xcfd19c: ret
    //     0xcfd19c: ret             
  }
}

// class id: 2070, size: 0x20, field offset: 0x8
class _CriticalSolution extends Object
    implements _SpringSolution {

  factory _ _CriticalSolution(/* No info */) {
    // ** addr: 0x82d984, size: 0x70
    // 0x82d984: EnterFrame
    //     0x82d984: stp             fp, lr, [SP, #-0x10]!
    //     0x82d988: mov             fp, SP
    // 0x82d98c: AllocStack(0x18)
    //     0x82d98c: sub             SP, SP, #0x18
    // 0x82d990: d0 = 2.000000
    //     0x82d990: fmov            d0, #2.00000000
    // 0x82d994: ldr             x0, [fp, #0x20]
    // 0x82d998: LoadField: d1 = r0->field_17
    //     0x82d998: ldur            d1, [x0, #0x17]
    // 0x82d99c: fneg            d2, d1
    // 0x82d9a0: LoadField: d1 = r0->field_7
    //     0x82d9a0: ldur            d1, [x0, #7]
    // 0x82d9a4: fmul            d3, d0, d1
    // 0x82d9a8: fdiv            d0, d2, d3
    // 0x82d9ac: ldr             x0, [fp, #0x18]
    // 0x82d9b0: stur            d0, [fp, #-0x18]
    // 0x82d9b4: LoadField: d1 = r0->field_7
    //     0x82d9b4: ldur            d1, [x0, #7]
    // 0x82d9b8: stur            d1, [fp, #-0x10]
    // 0x82d9bc: fmul            d2, d0, d1
    // 0x82d9c0: ldr             d3, [fp, #0x10]
    // 0x82d9c4: fdiv            d4, d3, d2
    // 0x82d9c8: stur            d4, [fp, #-8]
    // 0x82d9cc: r0 = _CriticalSolution()
    //     0x82d9cc: bl              #0x82d9f4  ; Allocate_CriticalSolutionStub -> _CriticalSolution (size=0x20)
    // 0x82d9d0: ldur            d0, [fp, #-0x18]
    // 0x82d9d4: StoreField: r0->field_7 = d0
    //     0x82d9d4: stur            d0, [x0, #7]
    // 0x82d9d8: ldur            d0, [fp, #-0x10]
    // 0x82d9dc: StoreField: r0->field_f = d0
    //     0x82d9dc: stur            d0, [x0, #0xf]
    // 0x82d9e0: ldur            d0, [fp, #-8]
    // 0x82d9e4: StoreField: r0->field_17 = d0
    //     0x82d9e4: stur            d0, [x0, #0x17]
    // 0x82d9e8: LeaveFrame
    //     0x82d9e8: mov             SP, fp
    //     0x82d9ec: ldp             fp, lr, [SP], #0x10
    // 0x82d9f0: ret
    //     0x82d9f0: ret             
  }
  get _ type(/* No info */) {
    // ** addr: 0xcfc8c8, size: 0xc
    // 0xcfc8c8: r0 = Instance_SpringType
    //     0xcfc8c8: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b3d8] Obj!SpringType@b64cd1
    //     0xcfc8cc: ldr             x0, [x0, #0x3d8]
    // 0xcfc8d0: ret
    //     0xcfc8d0: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0xcfc8ec, size: 0x138
    // 0xcfc8ec: EnterFrame
    //     0xcfc8ec: stp             fp, lr, [SP, #-0x10]!
    //     0xcfc8f0: mov             fp, SP
    // 0xcfc8f4: AllocStack(0x8)
    //     0xcfc8f4: sub             SP, SP, #8
    // 0xcfc8f8: ldr             x0, [fp, #0x18]
    // 0xcfc8fc: LoadField: d2 = r0->field_7
    //     0xcfc8fc: ldur            d2, [x0, #7]
    // 0xcfc900: ldr             d3, [fp, #0x10]
    // 0xcfc904: stur            d2, [fp, #-8]
    // 0xcfc908: fmul            d1, d2, d3
    // 0xcfc90c: d0 = 2.718282
    //     0xcfc90c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3d0] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xcfc910: ldr             d0, [x17, #0x3d0]
    // 0xcfc914: d30 = 0.000000
    //     0xcfc914: fmov            d30, d0
    // 0xcfc918: d0 = 1.000000
    //     0xcfc918: fmov            d0, #1.00000000
    // 0xcfc91c: fcmp            d1, #0.0
    // 0xcfc920: b.vs            #0xcfc964
    // 0xcfc924: b.eq            #0xcfc9ec
    // 0xcfc928: fcmp            d1, d0
    // 0xcfc92c: b.eq            #0xcfc954
    // 0xcfc930: d31 = 2.000000
    //     0xcfc930: fmov            d31, #2.00000000
    // 0xcfc934: fcmp            d1, d31
    // 0xcfc938: b.eq            #0xcfc95c
    // 0xcfc93c: d31 = 3.000000
    //     0xcfc93c: fmov            d31, #3.00000000
    // 0xcfc940: fcmp            d1, d31
    // 0xcfc944: b.ne            #0xcfc964
    // 0xcfc948: fmul            d0, d30, d30
    // 0xcfc94c: fmul            d0, d0, d30
    // 0xcfc950: b               #0xcfc9ec
    // 0xcfc954: d0 = 0.000000
    //     0xcfc954: fmov            d0, d30
    // 0xcfc958: b               #0xcfc9ec
    // 0xcfc95c: fmul            d0, d30, d30
    // 0xcfc960: b               #0xcfc9ec
    // 0xcfc964: fcmp            d30, d0
    // 0xcfc968: b.vs            #0xcfc978
    // 0xcfc96c: b.eq            #0xcfc9ec
    // 0xcfc970: fcmp            d30, d1
    // 0xcfc974: b.vc            #0xcfc984
    // 0xcfc978: d0 = nan
    //     0xcfc978: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcfc97c: ldr             d0, [x17, #0x240]
    // 0xcfc980: b               #0xcfc9ec
    // 0xcfc984: d0 = -inf
    //     0xcfc984: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcfc988: fcmp            d30, d0
    // 0xcfc98c: b.eq            #0xcfc9b4
    // 0xcfc990: d0 = 0.500000
    //     0xcfc990: fmov            d0, #0.50000000
    // 0xcfc994: fcmp            d1, d0
    // 0xcfc998: b.ne            #0xcfc9b4
    // 0xcfc99c: fcmp            d30, #0.0
    // 0xcfc9a0: b.eq            #0xcfc9ac
    // 0xcfc9a4: fsqrt           d0, d30
    // 0xcfc9a8: b               #0xcfc9ec
    // 0xcfc9ac: d0 = 0.000000
    //     0xcfc9ac: eor             v0.16b, v0.16b, v0.16b
    // 0xcfc9b0: b               #0xcfc9ec
    // 0xcfc9b4: d0 = 0.000000
    //     0xcfc9b4: fmov            d0, d30
    // 0xcfc9b8: stp             fp, lr, [SP, #-0x10]!
    // 0xcfc9bc: mov             fp, SP
    // 0xcfc9c0: CallRuntime_LibcPow(double, double) -> double
    //     0xcfc9c0: and             SP, SP, #0xfffffffffffffff0
    //     0xcfc9c4: mov             sp, SP
    //     0xcfc9c8: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcfc9cc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfc9d0: blr             x16
    //     0xcfc9d4: mov             x16, #8
    //     0xcfc9d8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfc9dc: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfc9e0: sub             sp, x16, #1, lsl #12
    //     0xcfc9e4: mov             SP, fp
    //     0xcfc9e8: ldp             fp, lr, [SP], #0x10
    // 0xcfc9ec: ldr             x0, [fp, #0x18]
    // 0xcfc9f0: LoadField: d1 = r0->field_f
    //     0xcfc9f0: ldur            d1, [x0, #0xf]
    // 0xcfc9f4: LoadField: d2 = r0->field_17
    //     0xcfc9f4: ldur            d2, [x0, #0x17]
    // 0xcfc9f8: ldr             d3, [fp, #0x10]
    // 0xcfc9fc: fmul            d4, d2, d3
    // 0xcfca00: fadd            d3, d1, d4
    // 0xcfca04: ldur            d1, [fp, #-8]
    // 0xcfca08: fmul            d4, d1, d3
    // 0xcfca0c: fmul            d1, d4, d0
    // 0xcfca10: fmul            d3, d2, d0
    // 0xcfca14: fadd            d0, d1, d3
    // 0xcfca18: LeaveFrame
    //     0xcfca18: mov             SP, fp
    //     0xcfca1c: ldp             fp, lr, [SP], #0x10
    // 0xcfca20: ret
    //     0xcfca20: ret             
  }
  _ x(/* No info */) {
    // ** addr: 0xcfce4c, size: 0x128
    // 0xcfce4c: EnterFrame
    //     0xcfce4c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfce50: mov             fp, SP
    // 0xcfce54: AllocStack(0x8)
    //     0xcfce54: sub             SP, SP, #8
    // 0xcfce58: ldr             x0, [fp, #0x18]
    // 0xcfce5c: LoadField: d0 = r0->field_f
    //     0xcfce5c: ldur            d0, [x0, #0xf]
    // 0xcfce60: LoadField: d1 = r0->field_17
    //     0xcfce60: ldur            d1, [x0, #0x17]
    // 0xcfce64: ldr             d2, [fp, #0x10]
    // 0xcfce68: fmul            d3, d1, d2
    // 0xcfce6c: fadd            d4, d0, d3
    // 0xcfce70: stur            d4, [fp, #-8]
    // 0xcfce74: LoadField: d0 = r0->field_7
    //     0xcfce74: ldur            d0, [x0, #7]
    // 0xcfce78: fmul            d1, d0, d2
    // 0xcfce7c: d0 = 2.718282
    //     0xcfce7c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b3d0] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xcfce80: ldr             d0, [x17, #0x3d0]
    // 0xcfce84: d30 = 0.000000
    //     0xcfce84: fmov            d30, d0
    // 0xcfce88: d0 = 1.000000
    //     0xcfce88: fmov            d0, #1.00000000
    // 0xcfce8c: fcmp            d1, #0.0
    // 0xcfce90: b.vs            #0xcfced4
    // 0xcfce94: b.eq            #0xcfcf5c
    // 0xcfce98: fcmp            d1, d0
    // 0xcfce9c: b.eq            #0xcfcec4
    // 0xcfcea0: d31 = 2.000000
    //     0xcfcea0: fmov            d31, #2.00000000
    // 0xcfcea4: fcmp            d1, d31
    // 0xcfcea8: b.eq            #0xcfcecc
    // 0xcfceac: d31 = 3.000000
    //     0xcfceac: fmov            d31, #3.00000000
    // 0xcfceb0: fcmp            d1, d31
    // 0xcfceb4: b.ne            #0xcfced4
    // 0xcfceb8: fmul            d0, d30, d30
    // 0xcfcebc: fmul            d0, d0, d30
    // 0xcfcec0: b               #0xcfcf5c
    // 0xcfcec4: d0 = 0.000000
    //     0xcfcec4: fmov            d0, d30
    // 0xcfcec8: b               #0xcfcf5c
    // 0xcfcecc: fmul            d0, d30, d30
    // 0xcfced0: b               #0xcfcf5c
    // 0xcfced4: fcmp            d30, d0
    // 0xcfced8: b.vs            #0xcfcee8
    // 0xcfcedc: b.eq            #0xcfcf5c
    // 0xcfcee0: fcmp            d30, d1
    // 0xcfcee4: b.vc            #0xcfcef4
    // 0xcfcee8: d0 = nan
    //     0xcfcee8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd240] IMM: double(nan) from 0x7ff8000000000000
    //     0xcfceec: ldr             d0, [x17, #0x240]
    // 0xcfcef0: b               #0xcfcf5c
    // 0xcfcef4: d0 = -inf
    //     0xcfcef4: ldr             d0, [PP, #0x22c8]  ; [pp+0x22c8] IMM: double(-inf) from 0xfff0000000000000
    // 0xcfcef8: fcmp            d30, d0
    // 0xcfcefc: b.eq            #0xcfcf24
    // 0xcfcf00: d0 = 0.500000
    //     0xcfcf00: fmov            d0, #0.50000000
    // 0xcfcf04: fcmp            d1, d0
    // 0xcfcf08: b.ne            #0xcfcf24
    // 0xcfcf0c: fcmp            d30, #0.0
    // 0xcfcf10: b.eq            #0xcfcf1c
    // 0xcfcf14: fsqrt           d0, d30
    // 0xcfcf18: b               #0xcfcf5c
    // 0xcfcf1c: d0 = 0.000000
    //     0xcfcf1c: eor             v0.16b, v0.16b, v0.16b
    // 0xcfcf20: b               #0xcfcf5c
    // 0xcfcf24: d0 = 0.000000
    //     0xcfcf24: fmov            d0, d30
    // 0xcfcf28: stp             fp, lr, [SP, #-0x10]!
    // 0xcfcf2c: mov             fp, SP
    // 0xcfcf30: CallRuntime_LibcPow(double, double) -> double
    //     0xcfcf30: and             SP, SP, #0xfffffffffffffff0
    //     0xcfcf34: mov             sp, SP
    //     0xcfcf38: ldr             x16, [THR, #0x550]  ; THR::LibcPow
    //     0xcfcf3c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcf40: blr             x16
    //     0xcfcf44: mov             x16, #8
    //     0xcfcf48: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcfcf4c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcfcf50: sub             sp, x16, #1, lsl #12
    //     0xcfcf54: mov             SP, fp
    //     0xcfcf58: ldp             fp, lr, [SP], #0x10
    // 0xcfcf5c: ldur            d1, [fp, #-8]
    // 0xcfcf60: fmul            d2, d1, d0
    // 0xcfcf64: mov             v0.16b, v2.16b
    // 0xcfcf68: LeaveFrame
    //     0xcfcf68: mov             SP, fp
    //     0xcfcf6c: ldp             fp, lr, [SP], #0x10
    // 0xcfcf70: ret
    //     0xcfcf70: ret             
  }
}

// class id: 2071, size: 0x8, field offset: 0x8
abstract class _SpringSolution extends Object {

  factory _ _SpringSolution(/* No info */) {
    // ** addr: 0x82d748, size: 0xd0
    // 0x82d748: EnterFrame
    //     0x82d748: stp             fp, lr, [SP, #-0x10]!
    //     0x82d74c: mov             fp, SP
    // 0x82d750: d1 = 4.000000
    //     0x82d750: fmov            d1, #4.00000000
    // 0x82d754: d0 = 0.000000
    //     0x82d754: eor             v0.16b, v0.16b, v0.16b
    // 0x82d758: CheckStackOverflow
    //     0x82d758: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82d75c: cmp             SP, x16
    //     0x82d760: b.ls            #0x82d810
    // 0x82d764: ldr             x0, [fp, #0x20]
    // 0x82d768: LoadField: d2 = r0->field_17
    //     0x82d768: ldur            d2, [x0, #0x17]
    // 0x82d76c: fmul            d3, d2, d2
    // 0x82d770: LoadField: d2 = r0->field_7
    //     0x82d770: ldur            d2, [x0, #7]
    // 0x82d774: fmul            d4, d1, d2
    // 0x82d778: LoadField: d1 = r0->field_f
    //     0x82d778: ldur            d1, [x0, #0xf]
    // 0x82d77c: fmul            d2, d4, d1
    // 0x82d780: fsub            d1, d3, d2
    // 0x82d784: fcmp            d1, d0
    // 0x82d788: b.vs            #0x82d7b8
    // 0x82d78c: b.ne            #0x82d7b8
    // 0x82d790: ldr             d2, [fp, #0x10]
    // 0x82d794: stp             x0, NULL, [SP, #-0x10]!
    // 0x82d798: ldr             x16, [fp, #0x18]
    // 0x82d79c: SaveReg r16
    //     0x82d79c: str             x16, [SP, #-8]!
    // 0x82d7a0: SaveReg d2
    //     0x82d7a0: str             d2, [SP, #-8]!
    // 0x82d7a4: r0 = _CriticalSolution()
    //     0x82d7a4: bl              #0x82d984  ; [package:flutter/src/physics/spring_simulation.dart] _CriticalSolution::_CriticalSolution
    // 0x82d7a8: add             SP, SP, #0x20
    // 0x82d7ac: LeaveFrame
    //     0x82d7ac: mov             SP, fp
    //     0x82d7b0: ldp             fp, lr, [SP], #0x10
    // 0x82d7b4: ret
    //     0x82d7b4: ret             
    // 0x82d7b8: ldr             d2, [fp, #0x10]
    // 0x82d7bc: fcmp            d1, d0
    // 0x82d7c0: b.vs            #0x82d7ec
    // 0x82d7c4: b.le            #0x82d7ec
    // 0x82d7c8: stp             x0, NULL, [SP, #-0x10]!
    // 0x82d7cc: ldr             x16, [fp, #0x18]
    // 0x82d7d0: SaveReg r16
    //     0x82d7d0: str             x16, [SP, #-8]!
    // 0x82d7d4: SaveReg d2
    //     0x82d7d4: str             d2, [SP, #-8]!
    // 0x82d7d8: r0 = _OverdampedSolution()
    //     0x82d7d8: bl              #0x82d8c8  ; [package:flutter/src/physics/spring_simulation.dart] _OverdampedSolution::_OverdampedSolution
    // 0x82d7dc: add             SP, SP, #0x20
    // 0x82d7e0: LeaveFrame
    //     0x82d7e0: mov             SP, fp
    //     0x82d7e4: ldp             fp, lr, [SP], #0x10
    // 0x82d7e8: ret
    //     0x82d7e8: ret             
    // 0x82d7ec: stp             x0, NULL, [SP, #-0x10]!
    // 0x82d7f0: ldr             x16, [fp, #0x18]
    // 0x82d7f4: SaveReg r16
    //     0x82d7f4: str             x16, [SP, #-8]!
    // 0x82d7f8: SaveReg d2
    //     0x82d7f8: str             d2, [SP, #-8]!
    // 0x82d7fc: r0 = _UnderdampedSolution()
    //     0x82d7fc: bl              #0x82d818  ; [package:flutter/src/physics/spring_simulation.dart] _UnderdampedSolution::_UnderdampedSolution
    // 0x82d800: add             SP, SP, #0x20
    // 0x82d804: LeaveFrame
    //     0x82d804: mov             SP, fp
    //     0x82d808: ldp             fp, lr, [SP], #0x10
    // 0x82d80c: ret
    //     0x82d80c: ret             
    // 0x82d810: r0 = StackOverflowSharedWithFPURegs()
    //     0x82d810: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x82d814: b               #0x82d764
  }
}

// class id: 2072, size: 0x20, field offset: 0x8
//   const constructor, 
class SpringDescription extends Object {

  _Double field_8;
  _Double field_10;
  _Double field_18;

  _ toString(/* No info */) {
    // ** addr: 0xae32b0, size: 0x220
    // 0xae32b0: EnterFrame
    //     0xae32b0: stp             fp, lr, [SP, #-0x10]!
    //     0xae32b4: mov             fp, SP
    // 0xae32b8: AllocStack(0x8)
    //     0xae32b8: sub             SP, SP, #8
    // 0xae32bc: CheckStackOverflow
    //     0xae32bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xae32c0: cmp             SP, x16
    //     0xae32c4: b.ls            #0xae3478
    // 0xae32c8: r1 = Null
    //     0xae32c8: mov             x1, NULL
    // 0xae32cc: r2 = 16
    //     0xae32cc: mov             x2, #0x10
    // 0xae32d0: r0 = AllocateArray()
    //     0xae32d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xae32d4: stur            x0, [fp, #-8]
    // 0xae32d8: r17 = "SpringDescription"
    //     0xae32d8: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fdd0] "SpringDescription"
    //     0xae32dc: ldr             x17, [x17, #0xdd0]
    // 0xae32e0: StoreField: r0->field_f = r17
    //     0xae32e0: stur            w17, [x0, #0xf]
    // 0xae32e4: r17 = "(mass: "
    //     0xae32e4: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fdd8] "(mass: "
    //     0xae32e8: ldr             x17, [x17, #0xdd8]
    // 0xae32ec: StoreField: r0->field_13 = r17
    //     0xae32ec: stur            w17, [x0, #0x13]
    // 0xae32f0: ldr             x1, [fp, #0x10]
    // 0xae32f4: LoadField: d0 = r1->field_7
    //     0xae32f4: ldur            d0, [x1, #7]
    // 0xae32f8: r2 = inline_Allocate_Double()
    //     0xae32f8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae32fc: add             x2, x2, #0x10
    //     0xae3300: cmp             x3, x2
    //     0xae3304: b.ls            #0xae3480
    //     0xae3308: str             x2, [THR, #0x60]  ; THR::top
    //     0xae330c: sub             x2, x2, #0xf
    //     0xae3310: mov             x3, #0xd108
    //     0xae3314: movk            x3, #3, lsl #16
    //     0xae3318: stur            x3, [x2, #-1]
    // 0xae331c: StoreField: r2->field_7 = d0
    //     0xae331c: stur            d0, [x2, #7]
    // 0xae3320: SaveReg r2
    //     0xae3320: str             x2, [SP, #-8]!
    // 0xae3324: r2 = 1
    //     0xae3324: mov             x2, #1
    // 0xae3328: SaveReg r2
    //     0xae3328: str             x2, [SP, #-8]!
    // 0xae332c: r0 = toStringAsFixed()
    //     0xae332c: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae3330: add             SP, SP, #0x10
    // 0xae3334: ldur            x1, [fp, #-8]
    // 0xae3338: ArrayStore: r1[2] = r0  ; List_4
    //     0xae3338: add             x25, x1, #0x17
    //     0xae333c: str             w0, [x25]
    //     0xae3340: tbz             w0, #0, #0xae335c
    //     0xae3344: ldurb           w16, [x1, #-1]
    //     0xae3348: ldurb           w17, [x0, #-1]
    //     0xae334c: and             x16, x17, x16, lsr #2
    //     0xae3350: tst             x16, HEAP, lsr #32
    //     0xae3354: b.eq            #0xae335c
    //     0xae3358: bl              #0xd67e5c
    // 0xae335c: ldur            x1, [fp, #-8]
    // 0xae3360: r17 = ", stiffness: "
    //     0xae3360: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fde0] ", stiffness: "
    //     0xae3364: ldr             x17, [x17, #0xde0]
    // 0xae3368: StoreField: r1->field_1b = r17
    //     0xae3368: stur            w17, [x1, #0x1b]
    // 0xae336c: ldr             x0, [fp, #0x10]
    // 0xae3370: LoadField: d0 = r0->field_f
    //     0xae3370: ldur            d0, [x0, #0xf]
    // 0xae3374: r2 = inline_Allocate_Double()
    //     0xae3374: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xae3378: add             x2, x2, #0x10
    //     0xae337c: cmp             x3, x2
    //     0xae3380: b.ls            #0xae349c
    //     0xae3384: str             x2, [THR, #0x60]  ; THR::top
    //     0xae3388: sub             x2, x2, #0xf
    //     0xae338c: mov             x3, #0xd108
    //     0xae3390: movk            x3, #3, lsl #16
    //     0xae3394: stur            x3, [x2, #-1]
    // 0xae3398: StoreField: r2->field_7 = d0
    //     0xae3398: stur            d0, [x2, #7]
    // 0xae339c: SaveReg r2
    //     0xae339c: str             x2, [SP, #-8]!
    // 0xae33a0: r2 = 1
    //     0xae33a0: mov             x2, #1
    // 0xae33a4: SaveReg r2
    //     0xae33a4: str             x2, [SP, #-8]!
    // 0xae33a8: r0 = toStringAsFixed()
    //     0xae33a8: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae33ac: add             SP, SP, #0x10
    // 0xae33b0: ldur            x1, [fp, #-8]
    // 0xae33b4: ArrayStore: r1[4] = r0  ; List_4
    //     0xae33b4: add             x25, x1, #0x1f
    //     0xae33b8: str             w0, [x25]
    //     0xae33bc: tbz             w0, #0, #0xae33d8
    //     0xae33c0: ldurb           w16, [x1, #-1]
    //     0xae33c4: ldurb           w17, [x0, #-1]
    //     0xae33c8: and             x16, x17, x16, lsr #2
    //     0xae33cc: tst             x16, HEAP, lsr #32
    //     0xae33d0: b.eq            #0xae33d8
    //     0xae33d4: bl              #0xd67e5c
    // 0xae33d8: ldur            x1, [fp, #-8]
    // 0xae33dc: r17 = ", damping: "
    //     0xae33dc: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fde8] ", damping: "
    //     0xae33e0: ldr             x17, [x17, #0xde8]
    // 0xae33e4: StoreField: r1->field_23 = r17
    //     0xae33e4: stur            w17, [x1, #0x23]
    // 0xae33e8: ldr             x0, [fp, #0x10]
    // 0xae33ec: LoadField: d0 = r0->field_17
    //     0xae33ec: ldur            d0, [x0, #0x17]
    // 0xae33f0: r0 = inline_Allocate_Double()
    //     0xae33f0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xae33f4: add             x0, x0, #0x10
    //     0xae33f8: cmp             x2, x0
    //     0xae33fc: b.ls            #0xae34b8
    //     0xae3400: str             x0, [THR, #0x60]  ; THR::top
    //     0xae3404: sub             x0, x0, #0xf
    //     0xae3408: mov             x2, #0xd108
    //     0xae340c: movk            x2, #3, lsl #16
    //     0xae3410: stur            x2, [x0, #-1]
    // 0xae3414: StoreField: r0->field_7 = d0
    //     0xae3414: stur            d0, [x0, #7]
    // 0xae3418: SaveReg r0
    //     0xae3418: str             x0, [SP, #-8]!
    // 0xae341c: r0 = 1
    //     0xae341c: mov             x0, #1
    // 0xae3420: SaveReg r0
    //     0xae3420: str             x0, [SP, #-8]!
    // 0xae3424: r0 = toStringAsFixed()
    //     0xae3424: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xae3428: add             SP, SP, #0x10
    // 0xae342c: ldur            x1, [fp, #-8]
    // 0xae3430: ArrayStore: r1[6] = r0  ; List_4
    //     0xae3430: add             x25, x1, #0x27
    //     0xae3434: str             w0, [x25]
    //     0xae3438: tbz             w0, #0, #0xae3454
    //     0xae343c: ldurb           w16, [x1, #-1]
    //     0xae3440: ldurb           w17, [x0, #-1]
    //     0xae3444: and             x16, x17, x16, lsr #2
    //     0xae3448: tst             x16, HEAP, lsr #32
    //     0xae344c: b.eq            #0xae3454
    //     0xae3450: bl              #0xd67e5c
    // 0xae3454: ldur            x0, [fp, #-8]
    // 0xae3458: r17 = ")"
    //     0xae3458: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xae345c: StoreField: r0->field_2b = r17
    //     0xae345c: stur            w17, [x0, #0x2b]
    // 0xae3460: SaveReg r0
    //     0xae3460: str             x0, [SP, #-8]!
    // 0xae3464: r0 = _interpolate()
    //     0xae3464: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xae3468: add             SP, SP, #8
    // 0xae346c: LeaveFrame
    //     0xae346c: mov             SP, fp
    //     0xae3470: ldp             fp, lr, [SP], #0x10
    // 0xae3474: ret
    //     0xae3474: ret             
    // 0xae3478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae3478: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae347c: b               #0xae32c8
    // 0xae3480: SaveReg d0
    //     0xae3480: str             q0, [SP, #-0x10]!
    // 0xae3484: stp             x0, x1, [SP, #-0x10]!
    // 0xae3488: r0 = AllocateDouble()
    //     0xae3488: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae348c: mov             x2, x0
    // 0xae3490: ldp             x0, x1, [SP], #0x10
    // 0xae3494: RestoreReg d0
    //     0xae3494: ldr             q0, [SP], #0x10
    // 0xae3498: b               #0xae331c
    // 0xae349c: SaveReg d0
    //     0xae349c: str             q0, [SP, #-0x10]!
    // 0xae34a0: stp             x0, x1, [SP, #-0x10]!
    // 0xae34a4: r0 = AllocateDouble()
    //     0xae34a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae34a8: mov             x2, x0
    // 0xae34ac: ldp             x0, x1, [SP], #0x10
    // 0xae34b0: RestoreReg d0
    //     0xae34b0: ldr             q0, [SP], #0x10
    // 0xae34b4: b               #0xae3398
    // 0xae34b8: SaveReg d0
    //     0xae34b8: str             q0, [SP, #-0x10]!
    // 0xae34bc: SaveReg r1
    //     0xae34bc: str             x1, [SP, #-8]!
    // 0xae34c0: r0 = AllocateDouble()
    //     0xae34c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xae34c4: RestoreReg r1
    //     0xae34c4: ldr             x1, [SP], #8
    // 0xae34c8: RestoreReg d0
    //     0xae34c8: ldr             q0, [SP], #0x10
    // 0xae34cc: b               #0xae3414
  }
}

// class id: 4303, size: 0x18, field offset: 0xc
class SpringSimulation extends Simulation {

  _ SpringSimulation(/* No info */) {
    // ** addr: 0x82d5ec, size: 0x15c
    // 0x82d5ec: EnterFrame
    //     0x82d5ec: stp             fp, lr, [SP, #-0x10]!
    //     0x82d5f0: mov             fp, SP
    // 0x82d5f4: AllocStack(0x10)
    //     0x82d5f4: sub             SP, SP, #0x10
    // 0x82d5f8: SetupParameters(SpringSimulation this /* r3, fp-0x10 */, dynamic _ /* r4 */, dynamic _ /* r5 */, dynamic _ /* r6 */, dynamic _ /* d0 */, {dynamic tolerance = Instance_Tolerance /* r0, fp-0x8 */})
    //     0x82d5f8: mov             x0, x4
    //     0x82d5fc: ldur            w1, [x0, #0x13]
    //     0x82d600: add             x1, x1, HEAP, lsl #32
    //     0x82d604: sub             x2, x1, #0xa
    //     0x82d608: add             x3, fp, w2, sxtw #2
    //     0x82d60c: ldr             x3, [x3, #0x30]
    //     0x82d610: stur            x3, [fp, #-0x10]
    //     0x82d614: add             x4, fp, w2, sxtw #2
    //     0x82d618: ldr             x4, [x4, #0x28]
    //     0x82d61c: add             x5, fp, w2, sxtw #2
    //     0x82d620: ldr             x5, [x5, #0x20]
    //     0x82d624: add             x6, fp, w2, sxtw #2
    //     0x82d628: ldr             x6, [x6, #0x18]
    //     0x82d62c: add             x7, fp, w2, sxtw #2
    //     0x82d630: ldr             d0, [x7, #0x10]
    //     0x82d634: ldur            w2, [x0, #0x1f]
    //     0x82d638: add             x2, x2, HEAP, lsl #32
    //     0x82d63c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a38] "tolerance"
    //     0x82d640: ldr             x16, [x16, #0xa38]
    //     0x82d644: cmp             w2, w16
    //     0x82d648: b.ne            #0x82d668
    //     0x82d64c: ldur            w2, [x0, #0x23]
    //     0x82d650: add             x2, x2, HEAP, lsl #32
    //     0x82d654: sub             w0, w1, w2
    //     0x82d658: add             x1, fp, w0, sxtw #2
    //     0x82d65c: ldr             x1, [x1, #8]
    //     0x82d660: mov             x0, x1
    //     0x82d664: b               #0x82d670
    //     0x82d668: add             x0, PP, #0xd, lsl #12  ; [pp+0xdbd0] Obj!Tolerance@b35651
    //     0x82d66c: ldr             x0, [x0, #0xbd0]
    //     0x82d670: stur            x0, [fp, #-8]
    // 0x82d674: CheckStackOverflow
    //     0x82d674: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82d678: cmp             SP, x16
    //     0x82d67c: b.ls            #0x82d71c
    // 0x82d680: LoadField: d1 = r6->field_7
    //     0x82d680: ldur            d1, [x6, #7]
    // 0x82d684: StoreField: r3->field_b = d1
    //     0x82d684: stur            d1, [x3, #0xb]
    // 0x82d688: LoadField: d2 = r5->field_7
    //     0x82d688: ldur            d2, [x5, #7]
    // 0x82d68c: fsub            d3, d2, d1
    // 0x82d690: r1 = inline_Allocate_Double()
    //     0x82d690: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x82d694: add             x1, x1, #0x10
    //     0x82d698: cmp             x2, x1
    //     0x82d69c: b.ls            #0x82d724
    //     0x82d6a0: str             x1, [THR, #0x60]  ; THR::top
    //     0x82d6a4: sub             x1, x1, #0xf
    //     0x82d6a8: mov             x2, #0xd108
    //     0x82d6ac: movk            x2, #3, lsl #16
    //     0x82d6b0: stur            x2, [x1, #-1]
    // 0x82d6b4: StoreField: r1->field_7 = d3
    //     0x82d6b4: stur            d3, [x1, #7]
    // 0x82d6b8: stp             x4, NULL, [SP, #-0x10]!
    // 0x82d6bc: SaveReg r1
    //     0x82d6bc: str             x1, [SP, #-8]!
    // 0x82d6c0: SaveReg d0
    //     0x82d6c0: str             d0, [SP, #-8]!
    // 0x82d6c4: r0 = _SpringSolution()
    //     0x82d6c4: bl              #0x82d748  ; [package:flutter/src/physics/spring_simulation.dart] _SpringSolution::_SpringSolution
    // 0x82d6c8: add             SP, SP, #0x20
    // 0x82d6cc: ldur            x1, [fp, #-0x10]
    // 0x82d6d0: StoreField: r1->field_13 = r0
    //     0x82d6d0: stur            w0, [x1, #0x13]
    //     0x82d6d4: ldurb           w16, [x1, #-1]
    //     0x82d6d8: ldurb           w17, [x0, #-1]
    //     0x82d6dc: and             x16, x17, x16, lsr #2
    //     0x82d6e0: tst             x16, HEAP, lsr #32
    //     0x82d6e4: b.eq            #0x82d6ec
    //     0x82d6e8: bl              #0xd6826c
    // 0x82d6ec: ldur            x0, [fp, #-8]
    // 0x82d6f0: StoreField: r1->field_7 = r0
    //     0x82d6f0: stur            w0, [x1, #7]
    //     0x82d6f4: ldurb           w16, [x1, #-1]
    //     0x82d6f8: ldurb           w17, [x0, #-1]
    //     0x82d6fc: and             x16, x17, x16, lsr #2
    //     0x82d700: tst             x16, HEAP, lsr #32
    //     0x82d704: b.eq            #0x82d70c
    //     0x82d708: bl              #0xd6826c
    // 0x82d70c: r0 = Null
    //     0x82d70c: mov             x0, NULL
    // 0x82d710: LeaveFrame
    //     0x82d710: mov             SP, fp
    //     0x82d714: ldp             fp, lr, [SP], #0x10
    // 0x82d718: ret
    //     0x82d718: ret             
    // 0x82d71c: r0 = StackOverflowSharedWithFPURegs()
    //     0x82d71c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x82d720: b               #0x82d680
    // 0x82d724: stp             q0, q3, [SP, #-0x20]!
    // 0x82d728: stp             x3, x4, [SP, #-0x10]!
    // 0x82d72c: SaveReg r0
    //     0x82d72c: str             x0, [SP, #-8]!
    // 0x82d730: r0 = AllocateDouble()
    //     0x82d730: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x82d734: mov             x1, x0
    // 0x82d738: RestoreReg r0
    //     0x82d738: ldr             x0, [SP], #8
    // 0x82d73c: ldp             x3, x4, [SP], #0x10
    // 0x82d740: ldp             q0, q3, [SP], #0x20
    // 0x82d744: b               #0x82d6b4
  }
  _ toString(/* No info */) {
    // ** addr: 0xad50c0, size: 0x138
    // 0xad50c0: EnterFrame
    //     0xad50c0: stp             fp, lr, [SP, #-0x10]!
    //     0xad50c4: mov             fp, SP
    // 0xad50c8: AllocStack(0x8)
    //     0xad50c8: sub             SP, SP, #8
    // 0xad50cc: CheckStackOverflow
    //     0xad50cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad50d0: cmp             SP, x16
    //     0xad50d4: b.ls            #0xad51d4
    // 0xad50d8: r1 = Null
    //     0xad50d8: mov             x1, NULL
    // 0xad50dc: r2 = 12
    //     0xad50dc: mov             x2, #0xc
    // 0xad50e0: r0 = AllocateArray()
    //     0xad50e0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad50e4: stur            x0, [fp, #-8]
    // 0xad50e8: r17 = "SpringSimulation"
    //     0xad50e8: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fdf0] "SpringSimulation"
    //     0xad50ec: ldr             x17, [x17, #0xdf0]
    // 0xad50f0: StoreField: r0->field_f = r17
    //     0xad50f0: stur            w17, [x0, #0xf]
    // 0xad50f4: r17 = "(end: "
    //     0xad50f4: add             x17, PP, #0x3f, lsl #12  ; [pp+0x3fdf8] "(end: "
    //     0xad50f8: ldr             x17, [x17, #0xdf8]
    // 0xad50fc: StoreField: r0->field_13 = r17
    //     0xad50fc: stur            w17, [x0, #0x13]
    // 0xad5100: ldr             x1, [fp, #0x10]
    // 0xad5104: LoadField: d0 = r1->field_b
    //     0xad5104: ldur            d0, [x1, #0xb]
    // 0xad5108: r2 = inline_Allocate_Double()
    //     0xad5108: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad510c: add             x2, x2, #0x10
    //     0xad5110: cmp             x3, x2
    //     0xad5114: b.ls            #0xad51dc
    //     0xad5118: str             x2, [THR, #0x60]  ; THR::top
    //     0xad511c: sub             x2, x2, #0xf
    //     0xad5120: mov             x3, #0xd108
    //     0xad5124: movk            x3, #3, lsl #16
    //     0xad5128: stur            x3, [x2, #-1]
    // 0xad512c: StoreField: r2->field_7 = d0
    //     0xad512c: stur            d0, [x2, #7]
    // 0xad5130: SaveReg r2
    //     0xad5130: str             x2, [SP, #-8]!
    // 0xad5134: r2 = 1
    //     0xad5134: mov             x2, #1
    // 0xad5138: SaveReg r2
    //     0xad5138: str             x2, [SP, #-8]!
    // 0xad513c: r0 = toStringAsFixed()
    //     0xad513c: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xad5140: add             SP, SP, #0x10
    // 0xad5144: ldur            x1, [fp, #-8]
    // 0xad5148: ArrayStore: r1[2] = r0  ; List_4
    //     0xad5148: add             x25, x1, #0x17
    //     0xad514c: str             w0, [x25]
    //     0xad5150: tbz             w0, #0, #0xad516c
    //     0xad5154: ldurb           w16, [x1, #-1]
    //     0xad5158: ldurb           w17, [x0, #-1]
    //     0xad515c: and             x16, x17, x16, lsr #2
    //     0xad5160: tst             x16, HEAP, lsr #32
    //     0xad5164: b.eq            #0xad516c
    //     0xad5168: bl              #0xd67e5c
    // 0xad516c: ldur            x1, [fp, #-8]
    // 0xad5170: r17 = ", "
    //     0xad5170: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad5174: StoreField: r1->field_1b = r17
    //     0xad5174: stur            w17, [x1, #0x1b]
    // 0xad5178: ldr             x16, [fp, #0x10]
    // 0xad517c: SaveReg r16
    //     0xad517c: str             x16, [SP, #-8]!
    // 0xad5180: r0 = type()
    //     0xad5180: bl              #0xad51f8  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::type
    // 0xad5184: add             SP, SP, #8
    // 0xad5188: ldur            x1, [fp, #-8]
    // 0xad518c: ArrayStore: r1[4] = r0  ; List_4
    //     0xad518c: add             x25, x1, #0x1f
    //     0xad5190: str             w0, [x25]
    //     0xad5194: tbz             w0, #0, #0xad51b0
    //     0xad5198: ldurb           w16, [x1, #-1]
    //     0xad519c: ldurb           w17, [x0, #-1]
    //     0xad51a0: and             x16, x17, x16, lsr #2
    //     0xad51a4: tst             x16, HEAP, lsr #32
    //     0xad51a8: b.eq            #0xad51b0
    //     0xad51ac: bl              #0xd67e5c
    // 0xad51b0: ldur            x0, [fp, #-8]
    // 0xad51b4: r17 = ")"
    //     0xad51b4: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad51b8: StoreField: r0->field_23 = r17
    //     0xad51b8: stur            w17, [x0, #0x23]
    // 0xad51bc: SaveReg r0
    //     0xad51bc: str             x0, [SP, #-8]!
    // 0xad51c0: r0 = _interpolate()
    //     0xad51c0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad51c4: add             SP, SP, #8
    // 0xad51c8: LeaveFrame
    //     0xad51c8: mov             SP, fp
    //     0xad51cc: ldp             fp, lr, [SP], #0x10
    // 0xad51d0: ret
    //     0xad51d0: ret             
    // 0xad51d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad51d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad51d8: b               #0xad50d8
    // 0xad51dc: SaveReg d0
    //     0xad51dc: str             q0, [SP, #-0x10]!
    // 0xad51e0: stp             x0, x1, [SP, #-0x10]!
    // 0xad51e4: r0 = AllocateDouble()
    //     0xad51e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad51e8: mov             x2, x0
    // 0xad51ec: ldp             x0, x1, [SP], #0x10
    // 0xad51f0: RestoreReg d0
    //     0xad51f0: ldr             q0, [SP], #0x10
    // 0xad51f4: b               #0xad512c
  }
  get _ type(/* No info */) {
    // ** addr: 0xad51f8, size: 0x50
    // 0xad51f8: EnterFrame
    //     0xad51f8: stp             fp, lr, [SP, #-0x10]!
    //     0xad51fc: mov             fp, SP
    // 0xad5200: CheckStackOverflow
    //     0xad5200: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5204: cmp             SP, x16
    //     0xad5208: b.ls            #0xad5240
    // 0xad520c: ldr             x0, [fp, #0x10]
    // 0xad5210: LoadField: r1 = r0->field_13
    //     0xad5210: ldur            w1, [x0, #0x13]
    // 0xad5214: DecompressPointer r1
    //     0xad5214: add             x1, x1, HEAP, lsl #32
    // 0xad5218: r0 = LoadClassIdInstr(r1)
    //     0xad5218: ldur            x0, [x1, #-1]
    //     0xad521c: ubfx            x0, x0, #0xc, #0x14
    // 0xad5220: SaveReg r1
    //     0xad5220: str             x1, [SP, #-8]!
    // 0xad5224: r0 = GDT[cid_x0 + -0xff9]()
    //     0xad5224: sub             lr, x0, #0xff9
    //     0xad5228: ldr             lr, [x21, lr, lsl #3]
    //     0xad522c: blr             lr
    // 0xad5230: add             SP, SP, #8
    // 0xad5234: LeaveFrame
    //     0xad5234: mov             SP, fp
    //     0xad5238: ldp             fp, lr, [SP], #0x10
    // 0xad523c: ret
    //     0xad523c: ret             
    // 0xad5240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5240: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5244: b               #0xad520c
  }
  _ dx(/* No info */) {
    // ** addr: 0xc2dc08, size: 0x5c
    // 0xc2dc08: EnterFrame
    //     0xc2dc08: stp             fp, lr, [SP, #-0x10]!
    //     0xc2dc0c: mov             fp, SP
    // 0xc2dc10: CheckStackOverflow
    //     0xc2dc10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2dc14: cmp             SP, x16
    //     0xc2dc18: b.ls            #0xc2dc5c
    // 0xc2dc1c: ldr             x0, [fp, #0x18]
    // 0xc2dc20: LoadField: r1 = r0->field_13
    //     0xc2dc20: ldur            w1, [x0, #0x13]
    // 0xc2dc24: DecompressPointer r1
    //     0xc2dc24: add             x1, x1, HEAP, lsl #32
    // 0xc2dc28: ldr             x0, [fp, #0x10]
    // 0xc2dc2c: LoadField: d0 = r0->field_7
    //     0xc2dc2c: ldur            d0, [x0, #7]
    // 0xc2dc30: r0 = LoadClassIdInstr(r1)
    //     0xc2dc30: ldur            x0, [x1, #-1]
    //     0xc2dc34: ubfx            x0, x0, #0xc, #0x14
    // 0xc2dc38: SaveReg r1
    //     0xc2dc38: str             x1, [SP, #-8]!
    // 0xc2dc3c: SaveReg d0
    //     0xc2dc3c: str             d0, [SP, #-8]!
    // 0xc2dc40: r0 = GDT[cid_x0 + -0xffd]()
    //     0xc2dc40: sub             lr, x0, #0xffd
    //     0xc2dc44: ldr             lr, [x21, lr, lsl #3]
    //     0xc2dc48: blr             lr
    // 0xc2dc4c: add             SP, SP, #0x10
    // 0xc2dc50: LeaveFrame
    //     0xc2dc50: mov             SP, fp
    //     0xc2dc54: ldp             fp, lr, [SP], #0x10
    // 0xc2dc58: ret
    //     0xc2dc58: ret             
    // 0xc2dc5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2dc5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2dc60: b               #0xc2dc1c
  }
  _ isDone(/* No info */) {
    // ** addr: 0xc3c958, size: 0x158
    // 0xc3c958: EnterFrame
    //     0xc3c958: stp             fp, lr, [SP, #-0x10]!
    //     0xc3c95c: mov             fp, SP
    // 0xc3c960: AllocStack(0x8)
    //     0xc3c960: sub             SP, SP, #8
    // 0xc3c964: CheckStackOverflow
    //     0xc3c964: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3c968: cmp             SP, x16
    //     0xc3c96c: b.ls            #0xc3ca7c
    // 0xc3c970: ldr             x1, [fp, #0x18]
    // 0xc3c974: LoadField: r2 = r1->field_13
    //     0xc3c974: ldur            w2, [x1, #0x13]
    // 0xc3c978: DecompressPointer r2
    //     0xc3c978: add             x2, x2, HEAP, lsl #32
    // 0xc3c97c: stur            x2, [fp, #-8]
    // 0xc3c980: r0 = LoadClassIdInstr(r2)
    //     0xc3c980: ldur            x0, [x2, #-1]
    //     0xc3c984: ubfx            x0, x0, #0xc, #0x14
    // 0xc3c988: SaveReg r2
    //     0xc3c988: str             x2, [SP, #-8]!
    // 0xc3c98c: ldr             d0, [fp, #0x10]
    // 0xc3c990: SaveReg d0
    //     0xc3c990: str             d0, [SP, #-8]!
    // 0xc3c994: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc3c994: sub             lr, x0, #1, lsl #12
    //     0xc3c998: ldr             lr, [x21, lr, lsl #3]
    //     0xc3c99c: blr             lr
    // 0xc3c9a0: add             SP, SP, #0x10
    // 0xc3c9a4: ldr             x0, [fp, #0x18]
    // 0xc3c9a8: LoadField: r1 = r0->field_7
    //     0xc3c9a8: ldur            w1, [x0, #7]
    // 0xc3c9ac: DecompressPointer r1
    //     0xc3c9ac: add             x1, x1, HEAP, lsl #32
    // 0xc3c9b0: LoadField: d1 = r1->field_7
    //     0xc3c9b0: ldur            d1, [x1, #7]
    // 0xc3c9b4: r1 = inline_Allocate_Double()
    //     0xc3c9b4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc3c9b8: add             x1, x1, #0x10
    //     0xc3c9bc: cmp             x2, x1
    //     0xc3c9c0: b.ls            #0xc3ca84
    //     0xc3c9c4: str             x1, [THR, #0x60]  ; THR::top
    //     0xc3c9c8: sub             x1, x1, #0xf
    //     0xc3c9cc: mov             x2, #0xd108
    //     0xc3c9d0: movk            x2, #3, lsl #16
    //     0xc3c9d4: stur            x2, [x1, #-1]
    // 0xc3c9d8: StoreField: r1->field_7 = d0
    //     0xc3c9d8: stur            d0, [x1, #7]
    // 0xc3c9dc: SaveReg r1
    //     0xc3c9dc: str             x1, [SP, #-8]!
    // 0xc3c9e0: SaveReg d1
    //     0xc3c9e0: str             d1, [SP, #-8]!
    // 0xc3c9e4: r0 = nearZero()
    //     0xc3c9e4: bl              #0xc3cab0  ; [package:flutter/src/physics/utils.dart] ::nearZero
    // 0xc3c9e8: add             SP, SP, #0x10
    // 0xc3c9ec: tbnz            w0, #4, #0xc3ca6c
    // 0xc3c9f0: ldr             x1, [fp, #0x18]
    // 0xc3c9f4: ldr             d0, [fp, #0x10]
    // 0xc3c9f8: ldur            x0, [fp, #-8]
    // 0xc3c9fc: r2 = LoadClassIdInstr(r0)
    //     0xc3c9fc: ldur            x2, [x0, #-1]
    //     0xc3ca00: ubfx            x2, x2, #0xc, #0x14
    // 0xc3ca04: SaveReg r0
    //     0xc3ca04: str             x0, [SP, #-8]!
    // 0xc3ca08: SaveReg d0
    //     0xc3ca08: str             d0, [SP, #-8]!
    // 0xc3ca0c: mov             x0, x2
    // 0xc3ca10: r0 = GDT[cid_x0 + -0xffd]()
    //     0xc3ca10: sub             lr, x0, #0xffd
    //     0xc3ca14: ldr             lr, [x21, lr, lsl #3]
    //     0xc3ca18: blr             lr
    // 0xc3ca1c: add             SP, SP, #0x10
    // 0xc3ca20: ldr             x0, [fp, #0x18]
    // 0xc3ca24: LoadField: r1 = r0->field_7
    //     0xc3ca24: ldur            w1, [x0, #7]
    // 0xc3ca28: DecompressPointer r1
    //     0xc3ca28: add             x1, x1, HEAP, lsl #32
    // 0xc3ca2c: LoadField: d1 = r1->field_17
    //     0xc3ca2c: ldur            d1, [x1, #0x17]
    // 0xc3ca30: r0 = inline_Allocate_Double()
    //     0xc3ca30: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc3ca34: add             x0, x0, #0x10
    //     0xc3ca38: cmp             x1, x0
    //     0xc3ca3c: b.ls            #0xc3caa0
    //     0xc3ca40: str             x0, [THR, #0x60]  ; THR::top
    //     0xc3ca44: sub             x0, x0, #0xf
    //     0xc3ca48: mov             x1, #0xd108
    //     0xc3ca4c: movk            x1, #3, lsl #16
    //     0xc3ca50: stur            x1, [x0, #-1]
    // 0xc3ca54: StoreField: r0->field_7 = d0
    //     0xc3ca54: stur            d0, [x0, #7]
    // 0xc3ca58: SaveReg r0
    //     0xc3ca58: str             x0, [SP, #-8]!
    // 0xc3ca5c: SaveReg d1
    //     0xc3ca5c: str             d1, [SP, #-8]!
    // 0xc3ca60: r0 = nearZero()
    //     0xc3ca60: bl              #0xc3cab0  ; [package:flutter/src/physics/utils.dart] ::nearZero
    // 0xc3ca64: add             SP, SP, #0x10
    // 0xc3ca68: b               #0xc3ca70
    // 0xc3ca6c: r0 = false
    //     0xc3ca6c: add             x0, NULL, #0x30  ; false
    // 0xc3ca70: LeaveFrame
    //     0xc3ca70: mov             SP, fp
    //     0xc3ca74: ldp             fp, lr, [SP], #0x10
    // 0xc3ca78: ret
    //     0xc3ca78: ret             
    // 0xc3ca7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3ca7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3ca80: b               #0xc3c970
    // 0xc3ca84: stp             q0, q1, [SP, #-0x20]!
    // 0xc3ca88: SaveReg r0
    //     0xc3ca88: str             x0, [SP, #-8]!
    // 0xc3ca8c: r0 = AllocateDouble()
    //     0xc3ca8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc3ca90: mov             x1, x0
    // 0xc3ca94: RestoreReg r0
    //     0xc3ca94: ldr             x0, [SP], #8
    // 0xc3ca98: ldp             q0, q1, [SP], #0x20
    // 0xc3ca9c: b               #0xc3c9d8
    // 0xc3caa0: stp             q0, q1, [SP, #-0x20]!
    // 0xc3caa4: r0 = AllocateDouble()
    //     0xc3caa4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc3caa8: ldp             q0, q1, [SP], #0x20
    // 0xc3caac: b               #0xc3ca54
  }
  _ x(/* No info */) {
    // ** addr: 0xcba60c, size: 0x74
    // 0xcba60c: EnterFrame
    //     0xcba60c: stp             fp, lr, [SP, #-0x10]!
    //     0xcba610: mov             fp, SP
    // 0xcba614: AllocStack(0x8)
    //     0xcba614: sub             SP, SP, #8
    // 0xcba618: CheckStackOverflow
    //     0xcba618: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcba61c: cmp             SP, x16
    //     0xcba620: b.ls            #0xcba678
    // 0xcba624: ldr             x0, [fp, #0x18]
    // 0xcba628: LoadField: d0 = r0->field_b
    //     0xcba628: ldur            d0, [x0, #0xb]
    // 0xcba62c: stur            d0, [fp, #-8]
    // 0xcba630: LoadField: r1 = r0->field_13
    //     0xcba630: ldur            w1, [x0, #0x13]
    // 0xcba634: DecompressPointer r1
    //     0xcba634: add             x1, x1, HEAP, lsl #32
    // 0xcba638: ldr             x0, [fp, #0x10]
    // 0xcba63c: LoadField: d1 = r0->field_7
    //     0xcba63c: ldur            d1, [x0, #7]
    // 0xcba640: r0 = LoadClassIdInstr(r1)
    //     0xcba640: ldur            x0, [x1, #-1]
    //     0xcba644: ubfx            x0, x0, #0xc, #0x14
    // 0xcba648: SaveReg r1
    //     0xcba648: str             x1, [SP, #-8]!
    // 0xcba64c: SaveReg d1
    //     0xcba64c: str             d1, [SP, #-8]!
    // 0xcba650: r0 = GDT[cid_x0 + -0x1000]()
    //     0xcba650: sub             lr, x0, #1, lsl #12
    //     0xcba654: ldr             lr, [x21, lr, lsl #3]
    //     0xcba658: blr             lr
    // 0xcba65c: add             SP, SP, #0x10
    // 0xcba660: ldur            d1, [fp, #-8]
    // 0xcba664: fadd            d2, d1, d0
    // 0xcba668: mov             v0.16b, v2.16b
    // 0xcba66c: LeaveFrame
    //     0xcba66c: mov             SP, fp
    //     0xcba670: ldp             fp, lr, [SP], #0x10
    // 0xcba674: ret
    //     0xcba674: ret             
    // 0xcba678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcba678: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcba67c: b               #0xcba624
  }
}

// class id: 4304, size: 0x18, field offset: 0x18
class ScrollSpringSimulation extends SpringSimulation {

  _ x(/* No info */) {
    // ** addr: 0xcba5a4, size: 0x68
    // 0xcba5a4: EnterFrame
    //     0xcba5a4: stp             fp, lr, [SP, #-0x10]!
    //     0xcba5a8: mov             fp, SP
    // 0xcba5ac: CheckStackOverflow
    //     0xcba5ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcba5b0: cmp             SP, x16
    //     0xcba5b4: b.ls            #0xcba604
    // 0xcba5b8: ldr             x0, [fp, #0x10]
    // 0xcba5bc: LoadField: d0 = r0->field_7
    //     0xcba5bc: ldur            d0, [x0, #7]
    // 0xcba5c0: ldr             x16, [fp, #0x18]
    // 0xcba5c4: SaveReg r16
    //     0xcba5c4: str             x16, [SP, #-8]!
    // 0xcba5c8: SaveReg d0
    //     0xcba5c8: str             d0, [SP, #-8]!
    // 0xcba5cc: r0 = isDone()
    //     0xcba5cc: bl              #0xc3c958  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::isDone
    // 0xcba5d0: add             SP, SP, #0x10
    // 0xcba5d4: tbnz            w0, #4, #0xcba5e4
    // 0xcba5d8: ldr             x0, [fp, #0x18]
    // 0xcba5dc: LoadField: d0 = r0->field_b
    //     0xcba5dc: ldur            d0, [x0, #0xb]
    // 0xcba5e0: b               #0xcba5f8
    // 0xcba5e4: ldr             x0, [fp, #0x18]
    // 0xcba5e8: ldr             x16, [fp, #0x10]
    // 0xcba5ec: stp             x16, x0, [SP, #-0x10]!
    // 0xcba5f0: r0 = x()
    //     0xcba5f0: bl              #0xcba60c  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::x
    // 0xcba5f4: add             SP, SP, #0x10
    // 0xcba5f8: LeaveFrame
    //     0xcba5f8: mov             SP, fp
    //     0xcba5fc: ldp             fp, lr, [SP], #0x10
    // 0xcba600: ret
    //     0xcba600: ret             
    // 0xcba604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcba604: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcba608: b               #0xcba5b8
  }
}

// class id: 5930, size: 0x14, field offset: 0x14
enum SpringType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16aec, size: 0x5c
    // 0xb16aec: EnterFrame
    //     0xb16aec: stp             fp, lr, [SP, #-0x10]!
    //     0xb16af0: mov             fp, SP
    // 0xb16af4: CheckStackOverflow
    //     0xb16af4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16af8: cmp             SP, x16
    //     0xb16afc: b.ls            #0xb16b40
    // 0xb16b00: r1 = Null
    //     0xb16b00: mov             x1, NULL
    // 0xb16b04: r2 = 4
    //     0xb16b04: mov             x2, #4
    // 0xb16b08: r0 = AllocateArray()
    //     0xb16b08: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16b0c: r17 = "SpringType."
    //     0xb16b0c: add             x17, PP, #0x50, lsl #12  ; [pp+0x50398] "SpringType."
    //     0xb16b10: ldr             x17, [x17, #0x398]
    // 0xb16b14: StoreField: r0->field_f = r17
    //     0xb16b14: stur            w17, [x0, #0xf]
    // 0xb16b18: ldr             x1, [fp, #0x10]
    // 0xb16b1c: LoadField: r2 = r1->field_f
    //     0xb16b1c: ldur            w2, [x1, #0xf]
    // 0xb16b20: DecompressPointer r2
    //     0xb16b20: add             x2, x2, HEAP, lsl #32
    // 0xb16b24: StoreField: r0->field_13 = r2
    //     0xb16b24: stur            w2, [x0, #0x13]
    // 0xb16b28: SaveReg r0
    //     0xb16b28: str             x0, [SP, #-8]!
    // 0xb16b2c: r0 = _interpolate()
    //     0xb16b2c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16b30: add             SP, SP, #8
    // 0xb16b34: LeaveFrame
    //     0xb16b34: mov             SP, fp
    //     0xb16b38: ldp             fp, lr, [SP], #0x10
    // 0xb16b3c: ret
    //     0xb16b3c: ret             
    // 0xb16b40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16b40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16b44: b               #0xb16b00
  }
}

// lib: , url: package:flutter/src/material/popup_menu_theme.dart

// class id: 1049291, size: 0x8
class :: {
}

// class id: 2777, size: 0x30, field offset: 0x8
//   const constructor, 
class PopupMenuThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00d34, size: 0x74
    // 0xb00d34: EnterFrame
    //     0xb00d34: stp             fp, lr, [SP, #-0x10]!
    //     0xb00d38: mov             fp, SP
    // 0xb00d3c: CheckStackOverflow
    //     0xb00d3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00d40: cmp             SP, x16
    //     0xb00d44: b.ls            #0xb00da0
    // 0xb00d48: ldr             x0, [fp, #0x10]
    // 0xb00d4c: LoadField: r1 = r0->field_f
    //     0xb00d4c: ldur            w1, [x0, #0xf]
    // 0xb00d50: DecompressPointer r1
    //     0xb00d50: add             x1, x1, HEAP, lsl #32
    // 0xb00d54: LoadField: r2 = r0->field_1f
    //     0xb00d54: ldur            w2, [x0, #0x1f]
    // 0xb00d58: DecompressPointer r2
    //     0xb00d58: add             x2, x2, HEAP, lsl #32
    // 0xb00d5c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00d60: stp             NULL, x1, [SP, #-0x10]!
    // 0xb00d64: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00d68: stp             NULL, x2, [SP, #-0x10]!
    // 0xb00d6c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00d70: r4 = const [0, 0xa, 0xa, 0xa, null]
    //     0xb00d70: ldr             x4, [PP, #0x2558]  ; [pp+0x2558] List(5) [0, 0xa, 0xa, 0xa, Null]
    // 0xb00d74: r0 = hash()
    //     0xb00d74: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00d78: add             SP, SP, #0x50
    // 0xb00d7c: mov             x2, x0
    // 0xb00d80: r0 = BoxInt64Instr(r2)
    //     0xb00d80: sbfiz           x0, x2, #1, #0x1f
    //     0xb00d84: cmp             x2, x0, asr #1
    //     0xb00d88: b.eq            #0xb00d94
    //     0xb00d8c: bl              #0xd69bb8
    //     0xb00d90: stur            x2, [x0, #7]
    // 0xb00d94: LeaveFrame
    //     0xb00d94: mov             SP, fp
    //     0xb00d98: ldp             fp, lr, [SP], #0x10
    // 0xb00d9c: ret
    //     0xb00d9c: ret             
    // 0xb00da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00da0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00da4: b               #0xb00d48
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf3400, size: 0x148
    // 0xbf3400: EnterFrame
    //     0xbf3400: stp             fp, lr, [SP, #-0x10]!
    //     0xbf3404: mov             fp, SP
    // 0xbf3408: AllocStack(0x10)
    //     0xbf3408: sub             SP, SP, #0x10
    // 0xbf340c: CheckStackOverflow
    //     0xbf340c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf3410: cmp             SP, x16
    //     0xbf3414: b.ls            #0xbf3530
    // 0xbf3418: ldr             d0, [fp, #0x10]
    // 0xbf341c: r0 = inline_Allocate_Double()
    //     0xbf341c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf3420: add             x0, x0, #0x10
    //     0xbf3424: cmp             x1, x0
    //     0xbf3428: b.ls            #0xbf3538
    //     0xbf342c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf3430: sub             x0, x0, #0xf
    //     0xbf3434: mov             x1, #0xd108
    //     0xbf3438: movk            x1, #3, lsl #16
    //     0xbf343c: stur            x1, [x0, #-1]
    // 0xbf3440: StoreField: r0->field_7 = d0
    //     0xbf3440: stur            d0, [x0, #7]
    // 0xbf3444: stur            x0, [fp, #-8]
    // 0xbf3448: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf344c: SaveReg r0
    //     0xbf344c: str             x0, [SP, #-8]!
    // 0xbf3450: r0 = lerp()
    //     0xbf3450: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3454: add             SP, SP, #0x18
    // 0xbf3458: ldr             x0, [fp, #0x20]
    // 0xbf345c: LoadField: r1 = r0->field_f
    //     0xbf345c: ldur            w1, [x0, #0xf]
    // 0xbf3460: DecompressPointer r1
    //     0xbf3460: add             x1, x1, HEAP, lsl #32
    // 0xbf3464: ldr             x2, [fp, #0x18]
    // 0xbf3468: LoadField: r3 = r2->field_f
    //     0xbf3468: ldur            w3, [x2, #0xf]
    // 0xbf346c: DecompressPointer r3
    //     0xbf346c: add             x3, x3, HEAP, lsl #32
    // 0xbf3470: stp             x3, x1, [SP, #-0x10]!
    // 0xbf3474: ldur            x16, [fp, #-8]
    // 0xbf3478: SaveReg r16
    //     0xbf3478: str             x16, [SP, #-8]!
    // 0xbf347c: r0 = lerpDouble()
    //     0xbf347c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3480: add             SP, SP, #0x18
    // 0xbf3484: stur            x0, [fp, #-0x10]
    // 0xbf3488: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf348c: ldur            x16, [fp, #-8]
    // 0xbf3490: SaveReg r16
    //     0xbf3490: str             x16, [SP, #-8]!
    // 0xbf3494: r0 = lerp()
    //     0xbf3494: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3498: add             SP, SP, #0x18
    // 0xbf349c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf34a0: ldur            x16, [fp, #-8]
    // 0xbf34a4: SaveReg r16
    //     0xbf34a4: str             x16, [SP, #-8]!
    // 0xbf34a8: r0 = lerp()
    //     0xbf34a8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf34ac: add             SP, SP, #0x18
    // 0xbf34b0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf34b4: ldur            x16, [fp, #-8]
    // 0xbf34b8: SaveReg r16
    //     0xbf34b8: str             x16, [SP, #-8]!
    // 0xbf34bc: r0 = lerp()
    //     0xbf34bc: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf34c0: add             SP, SP, #0x18
    // 0xbf34c4: ldr             x0, [fp, #0x20]
    // 0xbf34c8: LoadField: r1 = r0->field_1f
    //     0xbf34c8: ldur            w1, [x0, #0x1f]
    // 0xbf34cc: DecompressPointer r1
    //     0xbf34cc: add             x1, x1, HEAP, lsl #32
    // 0xbf34d0: ldr             x0, [fp, #0x18]
    // 0xbf34d4: LoadField: r2 = r0->field_1f
    //     0xbf34d4: ldur            w2, [x0, #0x1f]
    // 0xbf34d8: DecompressPointer r2
    //     0xbf34d8: add             x2, x2, HEAP, lsl #32
    // 0xbf34dc: r16 = <TextStyle?>
    //     0xbf34dc: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c0] TypeArguments: <TextStyle?>
    //     0xbf34e0: ldr             x16, [x16, #0x8c0]
    // 0xbf34e4: stp             x1, x16, [SP, #-0x10]!
    // 0xbf34e8: SaveReg r2
    //     0xbf34e8: str             x2, [SP, #-8]!
    // 0xbf34ec: ldr             d0, [fp, #0x10]
    // 0xbf34f0: SaveReg d0
    //     0xbf34f0: str             d0, [SP, #-8]!
    // 0xbf34f4: r16 = Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static.
    //     0xbf34f4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db78] Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static. (0x7fe6e22ec598)
    //     0xbf34f8: ldr             x16, [x16, #0xb78]
    // 0xbf34fc: SaveReg r16
    //     0xbf34fc: str             x16, [SP, #-8]!
    // 0xbf3500: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3500: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3504: r0 = lerp()
    //     0xbf3504: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3508: add             SP, SP, #0x28
    // 0xbf350c: stur            x0, [fp, #-8]
    // 0xbf3510: r0 = PopupMenuThemeData()
    //     0xbf3510: bl              #0xbf3548  ; AllocatePopupMenuThemeDataStub -> PopupMenuThemeData (size=0x30)
    // 0xbf3514: ldur            x1, [fp, #-0x10]
    // 0xbf3518: StoreField: r0->field_f = r1
    //     0xbf3518: stur            w1, [x0, #0xf]
    // 0xbf351c: ldur            x1, [fp, #-8]
    // 0xbf3520: StoreField: r0->field_1f = r1
    //     0xbf3520: stur            w1, [x0, #0x1f]
    // 0xbf3524: LeaveFrame
    //     0xbf3524: mov             SP, fp
    //     0xbf3528: ldp             fp, lr, [SP], #0x10
    // 0xbf352c: ret
    //     0xbf352c: ret             
    // 0xbf3530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf3530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf3534: b               #0xbf3418
    // 0xbf3538: SaveReg d0
    //     0xbf3538: str             q0, [SP, #-0x10]!
    // 0xbf353c: r0 = AllocateDouble()
    //     0xbf353c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf3540: RestoreReg d0
    //     0xbf3540: ldr             q0, [SP], #0x10
    // 0xbf3544: b               #0xbf3440
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8c75c, size: 0x14c
    // 0xc8c75c: EnterFrame
    //     0xc8c75c: stp             fp, lr, [SP, #-0x10]!
    //     0xc8c760: mov             fp, SP
    // 0xc8c764: CheckStackOverflow
    //     0xc8c764: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8c768: cmp             SP, x16
    //     0xc8c76c: b.ls            #0xc8c8a0
    // 0xc8c770: ldr             x1, [fp, #0x10]
    // 0xc8c774: cmp             w1, NULL
    // 0xc8c778: b.ne            #0xc8c78c
    // 0xc8c77c: r0 = false
    //     0xc8c77c: add             x0, NULL, #0x30  ; false
    // 0xc8c780: LeaveFrame
    //     0xc8c780: mov             SP, fp
    //     0xc8c784: ldp             fp, lr, [SP], #0x10
    // 0xc8c788: ret
    //     0xc8c788: ret             
    // 0xc8c78c: ldr             x2, [fp, #0x18]
    // 0xc8c790: cmp             w2, w1
    // 0xc8c794: b.ne            #0xc8c7a8
    // 0xc8c798: r0 = true
    //     0xc8c798: add             x0, NULL, #0x20  ; true
    // 0xc8c79c: LeaveFrame
    //     0xc8c79c: mov             SP, fp
    //     0xc8c7a0: ldp             fp, lr, [SP], #0x10
    // 0xc8c7a4: ret
    //     0xc8c7a4: ret             
    // 0xc8c7a8: r0 = 59
    //     0xc8c7a8: mov             x0, #0x3b
    // 0xc8c7ac: branchIfSmi(r1, 0xc8c7b8)
    //     0xc8c7ac: tbz             w1, #0, #0xc8c7b8
    // 0xc8c7b0: r0 = LoadClassIdInstr(r1)
    //     0xc8c7b0: ldur            x0, [x1, #-1]
    //     0xc8c7b4: ubfx            x0, x0, #0xc, #0x14
    // 0xc8c7b8: SaveReg r1
    //     0xc8c7b8: str             x1, [SP, #-8]!
    // 0xc8c7bc: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8c7bc: mov             x17, #0x57c5
    //     0xc8c7c0: add             lr, x0, x17
    //     0xc8c7c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc8c7c8: blr             lr
    // 0xc8c7cc: add             SP, SP, #8
    // 0xc8c7d0: r1 = LoadClassIdInstr(r0)
    //     0xc8c7d0: ldur            x1, [x0, #-1]
    //     0xc8c7d4: ubfx            x1, x1, #0xc, #0x14
    // 0xc8c7d8: r16 = PopupMenuThemeData
    //     0xc8c7d8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe198] Type: PopupMenuThemeData
    //     0xc8c7dc: ldr             x16, [x16, #0x198]
    // 0xc8c7e0: stp             x16, x0, [SP, #-0x10]!
    // 0xc8c7e4: mov             x0, x1
    // 0xc8c7e8: mov             lr, x0
    // 0xc8c7ec: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c7f0: blr             lr
    // 0xc8c7f4: add             SP, SP, #0x10
    // 0xc8c7f8: tbz             w0, #4, #0xc8c80c
    // 0xc8c7fc: r0 = false
    //     0xc8c7fc: add             x0, NULL, #0x30  ; false
    // 0xc8c800: LeaveFrame
    //     0xc8c800: mov             SP, fp
    //     0xc8c804: ldp             fp, lr, [SP], #0x10
    // 0xc8c808: ret
    //     0xc8c808: ret             
    // 0xc8c80c: ldr             x1, [fp, #0x10]
    // 0xc8c810: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8c810: mov             x0, #0x76
    //     0xc8c814: tbz             w1, #0, #0xc8c824
    //     0xc8c818: ldur            x0, [x1, #-1]
    //     0xc8c81c: ubfx            x0, x0, #0xc, #0x14
    //     0xc8c820: lsl             x0, x0, #1
    // 0xc8c824: r17 = 5554
    //     0xc8c824: mov             x17, #0x15b2
    // 0xc8c828: cmp             w0, w17
    // 0xc8c82c: b.ne            #0xc8c890
    // 0xc8c830: ldr             x2, [fp, #0x18]
    // 0xc8c834: LoadField: r0 = r1->field_f
    //     0xc8c834: ldur            w0, [x1, #0xf]
    // 0xc8c838: DecompressPointer r0
    //     0xc8c838: add             x0, x0, HEAP, lsl #32
    // 0xc8c83c: LoadField: r3 = r2->field_f
    //     0xc8c83c: ldur            w3, [x2, #0xf]
    // 0xc8c840: DecompressPointer r3
    //     0xc8c840: add             x3, x3, HEAP, lsl #32
    // 0xc8c844: r4 = LoadClassIdInstr(r0)
    //     0xc8c844: ldur            x4, [x0, #-1]
    //     0xc8c848: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c84c: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c850: mov             x0, x4
    // 0xc8c854: mov             lr, x0
    // 0xc8c858: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c85c: blr             lr
    // 0xc8c860: add             SP, SP, #0x10
    // 0xc8c864: tbnz            w0, #4, #0xc8c890
    // 0xc8c868: ldr             x2, [fp, #0x18]
    // 0xc8c86c: ldr             x1, [fp, #0x10]
    // 0xc8c870: LoadField: r3 = r1->field_1f
    //     0xc8c870: ldur            w3, [x1, #0x1f]
    // 0xc8c874: DecompressPointer r3
    //     0xc8c874: add             x3, x3, HEAP, lsl #32
    // 0xc8c878: LoadField: r1 = r2->field_1f
    //     0xc8c878: ldur            w1, [x2, #0x1f]
    // 0xc8c87c: DecompressPointer r1
    //     0xc8c87c: add             x1, x1, HEAP, lsl #32
    // 0xc8c880: cmp             w3, w1
    // 0xc8c884: b.ne            #0xc8c890
    // 0xc8c888: r0 = true
    //     0xc8c888: add             x0, NULL, #0x20  ; true
    // 0xc8c88c: b               #0xc8c894
    // 0xc8c890: r0 = false
    //     0xc8c890: add             x0, NULL, #0x30  ; false
    // 0xc8c894: LeaveFrame
    //     0xc8c894: mov             SP, fp
    //     0xc8c898: ldp             fp, lr, [SP], #0x10
    // 0xc8c89c: ret
    //     0xc8c89c: ret             
    // 0xc8c8a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8c8a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8c8a4: b               #0xc8c770
  }
}

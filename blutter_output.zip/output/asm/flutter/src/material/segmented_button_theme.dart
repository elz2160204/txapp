// lib: , url: package:flutter/src/material/segmented_button_theme.dart

// class id: 1049305, size: 0x8
class :: {
}

// class id: 2769, size: 0x10, field offset: 0x8
//   const constructor, 
class SegmentedButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00fac, size: 0x5c
    // 0xb00fac: EnterFrame
    //     0xb00fac: stp             fp, lr, [SP, #-0x10]!
    //     0xb00fb0: mov             fp, SP
    // 0xb00fb4: CheckStackOverflow
    //     0xb00fb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00fb8: cmp             SP, x16
    //     0xb00fbc: b.ls            #0xb01000
    // 0xb00fc0: ldr             x0, [fp, #0x10]
    // 0xb00fc4: LoadField: r1 = r0->field_7
    //     0xb00fc4: ldur            w1, [x0, #7]
    // 0xb00fc8: DecompressPointer r1
    //     0xb00fc8: add             x1, x1, HEAP, lsl #32
    // 0xb00fcc: stp             NULL, x1, [SP, #-0x10]!
    // 0xb00fd0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xb00fd0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xb00fd4: r0 = hash()
    //     0xb00fd4: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00fd8: add             SP, SP, #0x10
    // 0xb00fdc: mov             x2, x0
    // 0xb00fe0: r0 = BoxInt64Instr(r2)
    //     0xb00fe0: sbfiz           x0, x2, #1, #0x1f
    //     0xb00fe4: cmp             x2, x0, asr #1
    //     0xb00fe8: b.eq            #0xb00ff4
    //     0xb00fec: bl              #0xd69bb8
    //     0xb00ff0: stur            x2, [x0, #7]
    // 0xb00ff4: LeaveFrame
    //     0xb00ff4: mov             SP, fp
    //     0xb00ff8: ldp             fp, lr, [SP], #0x10
    // 0xb00ffc: ret
    //     0xb00ffc: ret             
    // 0xb01000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb01000: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb01004: b               #0xb00fc0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf3120, size: 0x68
    // 0xbf3120: EnterFrame
    //     0xbf3120: stp             fp, lr, [SP, #-0x10]!
    //     0xbf3124: mov             fp, SP
    // 0xbf3128: AllocStack(0x8)
    //     0xbf3128: sub             SP, SP, #8
    // 0xbf312c: CheckStackOverflow
    //     0xbf312c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf3130: cmp             SP, x16
    //     0xbf3134: b.ls            #0xbf3180
    // 0xbf3138: ldr             x0, [fp, #0x20]
    // 0xbf313c: LoadField: r1 = r0->field_7
    //     0xbf313c: ldur            w1, [x0, #7]
    // 0xbf3140: DecompressPointer r1
    //     0xbf3140: add             x1, x1, HEAP, lsl #32
    // 0xbf3144: ldr             x0, [fp, #0x18]
    // 0xbf3148: LoadField: r2 = r0->field_7
    //     0xbf3148: ldur            w2, [x0, #7]
    // 0xbf314c: DecompressPointer r2
    //     0xbf314c: add             x2, x2, HEAP, lsl #32
    // 0xbf3150: stp             x2, x1, [SP, #-0x10]!
    // 0xbf3154: ldr             d0, [fp, #0x10]
    // 0xbf3158: SaveReg d0
    //     0xbf3158: str             d0, [SP, #-8]!
    // 0xbf315c: r0 = lerp()
    //     0xbf315c: bl              #0xbef34c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0xbf3160: add             SP, SP, #0x18
    // 0xbf3164: stur            x0, [fp, #-8]
    // 0xbf3168: r0 = SegmentedButtonThemeData()
    //     0xbf3168: bl              #0xbf3188  ; AllocateSegmentedButtonThemeDataStub -> SegmentedButtonThemeData (size=0x10)
    // 0xbf316c: ldur            x1, [fp, #-8]
    // 0xbf3170: StoreField: r0->field_7 = r1
    //     0xbf3170: stur            w1, [x0, #7]
    // 0xbf3174: LeaveFrame
    //     0xbf3174: mov             SP, fp
    //     0xbf3178: ldp             fp, lr, [SP], #0x10
    // 0xbf317c: ret
    //     0xbf317c: ret             
    // 0xbf3180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf3180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf3184: b               #0xbf3138
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8ceb0, size: 0x12c
    // 0xc8ceb0: EnterFrame
    //     0xc8ceb0: stp             fp, lr, [SP, #-0x10]!
    //     0xc8ceb4: mov             fp, SP
    // 0xc8ceb8: CheckStackOverflow
    //     0xc8ceb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8cebc: cmp             SP, x16
    //     0xc8cec0: b.ls            #0xc8cfd4
    // 0xc8cec4: ldr             x1, [fp, #0x10]
    // 0xc8cec8: cmp             w1, NULL
    // 0xc8cecc: b.ne            #0xc8cee0
    // 0xc8ced0: r0 = false
    //     0xc8ced0: add             x0, NULL, #0x30  ; false
    // 0xc8ced4: LeaveFrame
    //     0xc8ced4: mov             SP, fp
    //     0xc8ced8: ldp             fp, lr, [SP], #0x10
    // 0xc8cedc: ret
    //     0xc8cedc: ret             
    // 0xc8cee0: ldr             x2, [fp, #0x18]
    // 0xc8cee4: cmp             w2, w1
    // 0xc8cee8: b.ne            #0xc8cefc
    // 0xc8ceec: r0 = true
    //     0xc8ceec: add             x0, NULL, #0x20  ; true
    // 0xc8cef0: LeaveFrame
    //     0xc8cef0: mov             SP, fp
    //     0xc8cef4: ldp             fp, lr, [SP], #0x10
    // 0xc8cef8: ret
    //     0xc8cef8: ret             
    // 0xc8cefc: r0 = 59
    //     0xc8cefc: mov             x0, #0x3b
    // 0xc8cf00: branchIfSmi(r1, 0xc8cf0c)
    //     0xc8cf00: tbz             w1, #0, #0xc8cf0c
    // 0xc8cf04: r0 = LoadClassIdInstr(r1)
    //     0xc8cf04: ldur            x0, [x1, #-1]
    //     0xc8cf08: ubfx            x0, x0, #0xc, #0x14
    // 0xc8cf0c: SaveReg r1
    //     0xc8cf0c: str             x1, [SP, #-8]!
    // 0xc8cf10: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8cf10: mov             x17, #0x57c5
    //     0xc8cf14: add             lr, x0, x17
    //     0xc8cf18: ldr             lr, [x21, lr, lsl #3]
    //     0xc8cf1c: blr             lr
    // 0xc8cf20: add             SP, SP, #8
    // 0xc8cf24: r1 = LoadClassIdInstr(r0)
    //     0xc8cf24: ldur            x1, [x0, #-1]
    //     0xc8cf28: ubfx            x1, x1, #0xc, #0x14
    // 0xc8cf2c: r16 = SegmentedButtonThemeData
    //     0xc8cf2c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe180] Type: SegmentedButtonThemeData
    //     0xc8cf30: ldr             x16, [x16, #0x180]
    // 0xc8cf34: stp             x16, x0, [SP, #-0x10]!
    // 0xc8cf38: mov             x0, x1
    // 0xc8cf3c: mov             lr, x0
    // 0xc8cf40: ldr             lr, [x21, lr, lsl #3]
    // 0xc8cf44: blr             lr
    // 0xc8cf48: add             SP, SP, #0x10
    // 0xc8cf4c: tbz             w0, #4, #0xc8cf60
    // 0xc8cf50: r0 = false
    //     0xc8cf50: add             x0, NULL, #0x30  ; false
    // 0xc8cf54: LeaveFrame
    //     0xc8cf54: mov             SP, fp
    //     0xc8cf58: ldp             fp, lr, [SP], #0x10
    // 0xc8cf5c: ret
    //     0xc8cf5c: ret             
    // 0xc8cf60: ldr             x0, [fp, #0x10]
    // 0xc8cf64: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8cf64: mov             x1, #0x76
    //     0xc8cf68: tbz             w0, #0, #0xc8cf78
    //     0xc8cf6c: ldur            x1, [x0, #-1]
    //     0xc8cf70: ubfx            x1, x1, #0xc, #0x14
    //     0xc8cf74: lsl             x1, x1, #1
    // 0xc8cf78: r17 = 5538
    //     0xc8cf78: mov             x17, #0x15a2
    // 0xc8cf7c: cmp             w1, w17
    // 0xc8cf80: b.ne            #0xc8cfc4
    // 0xc8cf84: ldr             x1, [fp, #0x18]
    // 0xc8cf88: LoadField: r2 = r0->field_7
    //     0xc8cf88: ldur            w2, [x0, #7]
    // 0xc8cf8c: DecompressPointer r2
    //     0xc8cf8c: add             x2, x2, HEAP, lsl #32
    // 0xc8cf90: LoadField: r0 = r1->field_7
    //     0xc8cf90: ldur            w0, [x1, #7]
    // 0xc8cf94: DecompressPointer r0
    //     0xc8cf94: add             x0, x0, HEAP, lsl #32
    // 0xc8cf98: r1 = LoadClassIdInstr(r2)
    //     0xc8cf98: ldur            x1, [x2, #-1]
    //     0xc8cf9c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8cfa0: stp             x0, x2, [SP, #-0x10]!
    // 0xc8cfa4: mov             x0, x1
    // 0xc8cfa8: mov             lr, x0
    // 0xc8cfac: ldr             lr, [x21, lr, lsl #3]
    // 0xc8cfb0: blr             lr
    // 0xc8cfb4: add             SP, SP, #0x10
    // 0xc8cfb8: tbnz            w0, #4, #0xc8cfc4
    // 0xc8cfbc: r0 = true
    //     0xc8cfbc: add             x0, NULL, #0x20  ; true
    // 0xc8cfc0: b               #0xc8cfc8
    // 0xc8cfc4: r0 = false
    //     0xc8cfc4: add             x0, NULL, #0x30  ; false
    // 0xc8cfc8: LeaveFrame
    //     0xc8cfc8: mov             SP, fp
    //     0xc8cfcc: ldp             fp, lr, [SP], #0x10
    // 0xc8cfd0: ret
    //     0xc8cfd0: ret             
    // 0xc8cfd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8cfd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8cfd8: b               #0xc8cec4
  }
}

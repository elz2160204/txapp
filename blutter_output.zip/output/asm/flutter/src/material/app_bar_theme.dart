// lib: , url: package:flutter/src/material/app_bar_theme.dart

// class id: 1049180, size: 0x8
class :: {
}

// class id: 2841, size: 0x50, field offset: 0x8
//   const constructor, 
class AppBarTheme extends _DiagnosticableTree&Object&Diagnosticable {

  _Double field_14;
  SystemUiOverlayStyle field_48;

  static _ of(/* No info */) {
    // ** addr: 0x848a3c, size: 0x44
    // 0x848a3c: EnterFrame
    //     0x848a3c: stp             fp, lr, [SP, #-0x10]!
    //     0x848a40: mov             fp, SP
    // 0x848a44: CheckStackOverflow
    //     0x848a44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848a48: cmp             SP, x16
    //     0x848a4c: b.ls            #0x848a78
    // 0x848a50: ldr             x16, [fp, #0x10]
    // 0x848a54: SaveReg r16
    //     0x848a54: str             x16, [SP, #-8]!
    // 0x848a58: r0 = of()
    //     0x848a58: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x848a5c: add             SP, SP, #8
    // 0x848a60: LoadField: r1 = r0->field_9b
    //     0x848a60: ldur            w1, [x0, #0x9b]
    // 0x848a64: DecompressPointer r1
    //     0x848a64: add             x1, x1, HEAP, lsl #32
    // 0x848a68: mov             x0, x1
    // 0x848a6c: LeaveFrame
    //     0x848a6c: mov             SP, fp
    //     0x848a70: ldp             fp, lr, [SP], #0x10
    // 0x848a74: ret
    //     0x848a74: ret             
    // 0x848a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848a78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848a7c: b               #0x848a50
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafd65c, size: 0x608
    // 0xafd65c: EnterFrame
    //     0xafd65c: stp             fp, lr, [SP, #-0x10]!
    //     0xafd660: mov             fp, SP
    // 0xafd664: AllocStack(0x68)
    //     0xafd664: sub             SP, SP, #0x68
    // 0xafd668: CheckStackOverflow
    //     0xafd668: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafd66c: cmp             SP, x16
    //     0xafd670: b.ls            #0xafdc5c
    // 0xafd674: ldr             x0, [fp, #0x10]
    // 0xafd678: r2 = LoadClassIdInstr(r0)
    //     0xafd678: ldur            x2, [x0, #-1]
    //     0xafd67c: ubfx            x2, x2, #0xc, #0x14
    // 0xafd680: lsl             x2, x2, #1
    // 0xafd684: stur            x2, [fp, #-8]
    // 0xafd688: r17 = 5682
    //     0xafd688: mov             x17, #0x1632
    // 0xafd68c: cmp             w2, w17
    // 0xafd690: b.ne            #0xafd6a8
    // 0xafd694: LoadField: r1 = r0->field_b
    //     0xafd694: ldur            w1, [x0, #0xb]
    // 0xafd698: DecompressPointer r1
    //     0xafd698: add             x1, x1, HEAP, lsl #32
    // 0xafd69c: mov             x0, x2
    // 0xafd6a0: mov             x2, x1
    // 0xafd6a4: b               #0xafd748
    // 0xafd6a8: r17 = 5684
    //     0xafd6a8: mov             x17, #0x1634
    // 0xafd6ac: cmp             w2, w17
    // 0xafd6b0: b.ne            #0xafd6ec
    // 0xafd6b4: mov             x1, x0
    // 0xafd6b8: LoadField: r0 = r1->field_57
    //     0xafd6b8: ldur            w0, [x1, #0x57]
    // 0xafd6bc: DecompressPointer r0
    //     0xafd6bc: add             x0, x0, HEAP, lsl #32
    // 0xafd6c0: r16 = Sentinel
    //     0xafd6c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafd6c4: cmp             w0, w16
    // 0xafd6c8: b.ne            #0xafd6d8
    // 0xafd6cc: r2 = _colors
    //     0xafd6cc: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xafd6d0: ldr             x2, [x2, #0x4b8]
    // 0xafd6d4: r0 = InitLateFinalInstanceField()
    //     0xafd6d4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafd6d8: LoadField: r1 = r0->field_53
    //     0xafd6d8: ldur            w1, [x0, #0x53]
    // 0xafd6dc: DecompressPointer r1
    //     0xafd6dc: add             x1, x1, HEAP, lsl #32
    // 0xafd6e0: mov             x2, x1
    // 0xafd6e4: ldur            x0, [fp, #-8]
    // 0xafd6e8: b               #0xafd748
    // 0xafd6ec: ldr             x1, [fp, #0x10]
    // 0xafd6f0: LoadField: r0 = r1->field_57
    //     0xafd6f0: ldur            w0, [x1, #0x57]
    // 0xafd6f4: DecompressPointer r0
    //     0xafd6f4: add             x0, x0, HEAP, lsl #32
    // 0xafd6f8: r16 = Sentinel
    //     0xafd6f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafd6fc: cmp             w0, w16
    // 0xafd700: b.ne            #0xafd710
    // 0xafd704: r2 = _colors
    //     0xafd704: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c0] Field <_AppBarDefaultsM2@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xafd708: ldr             x2, [x2, #0x4c0]
    // 0xafd70c: r0 = InitLateFinalInstanceField()
    //     0xafd70c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafd710: LoadField: r1 = r0->field_7
    //     0xafd710: ldur            w1, [x0, #7]
    // 0xafd714: DecompressPointer r1
    //     0xafd714: add             x1, x1, HEAP, lsl #32
    // 0xafd718: r16 = Instance_Brightness
    //     0xafd718: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xafd71c: cmp             w1, w16
    // 0xafd720: b.ne            #0xafd734
    // 0xafd724: LoadField: r1 = r0->field_53
    //     0xafd724: ldur            w1, [x0, #0x53]
    // 0xafd728: DecompressPointer r1
    //     0xafd728: add             x1, x1, HEAP, lsl #32
    // 0xafd72c: mov             x0, x1
    // 0xafd730: b               #0xafd740
    // 0xafd734: LoadField: r1 = r0->field_b
    //     0xafd734: ldur            w1, [x0, #0xb]
    // 0xafd738: DecompressPointer r1
    //     0xafd738: add             x1, x1, HEAP, lsl #32
    // 0xafd73c: mov             x0, x1
    // 0xafd740: mov             x2, x0
    // 0xafd744: ldur            x0, [fp, #-8]
    // 0xafd748: stur            x2, [fp, #-0x10]
    // 0xafd74c: r17 = 5682
    //     0xafd74c: mov             x17, #0x1632
    // 0xafd750: cmp             w0, w17
    // 0xafd754: b.ne            #0xafd770
    // 0xafd758: ldr             x3, [fp, #0x10]
    // 0xafd75c: LoadField: r1 = r3->field_f
    //     0xafd75c: ldur            w1, [x3, #0xf]
    // 0xafd760: DecompressPointer r1
    //     0xafd760: add             x1, x1, HEAP, lsl #32
    // 0xafd764: mov             x2, x3
    // 0xafd768: mov             x3, x1
    // 0xafd76c: b               #0xafd81c
    // 0xafd770: ldr             x3, [fp, #0x10]
    // 0xafd774: r17 = 5684
    //     0xafd774: mov             x17, #0x1634
    // 0xafd778: cmp             w0, w17
    // 0xafd77c: b.ne            #0xafd7bc
    // 0xafd780: mov             x1, x3
    // 0xafd784: LoadField: r0 = r1->field_57
    //     0xafd784: ldur            w0, [x1, #0x57]
    // 0xafd788: DecompressPointer r0
    //     0xafd788: add             x0, x0, HEAP, lsl #32
    // 0xafd78c: r16 = Sentinel
    //     0xafd78c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafd790: cmp             w0, w16
    // 0xafd794: b.ne            #0xafd7a4
    // 0xafd798: r2 = _colors
    //     0xafd798: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xafd79c: ldr             x2, [x2, #0x4b8]
    // 0xafd7a0: r0 = InitLateFinalInstanceField()
    //     0xafd7a0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafd7a4: LoadField: r1 = r0->field_57
    //     0xafd7a4: ldur            w1, [x0, #0x57]
    // 0xafd7a8: DecompressPointer r1
    //     0xafd7a8: add             x1, x1, HEAP, lsl #32
    // 0xafd7ac: mov             x3, x1
    // 0xafd7b0: ldr             x2, [fp, #0x10]
    // 0xafd7b4: ldur            x0, [fp, #-8]
    // 0xafd7b8: b               #0xafd81c
    // 0xafd7bc: ldr             x1, [fp, #0x10]
    // 0xafd7c0: LoadField: r0 = r1->field_57
    //     0xafd7c0: ldur            w0, [x1, #0x57]
    // 0xafd7c4: DecompressPointer r0
    //     0xafd7c4: add             x0, x0, HEAP, lsl #32
    // 0xafd7c8: r16 = Sentinel
    //     0xafd7c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafd7cc: cmp             w0, w16
    // 0xafd7d0: b.ne            #0xafd7e0
    // 0xafd7d4: r2 = _colors
    //     0xafd7d4: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c0] Field <_AppBarDefaultsM2@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xafd7d8: ldr             x2, [x2, #0x4c0]
    // 0xafd7dc: r0 = InitLateFinalInstanceField()
    //     0xafd7dc: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafd7e0: LoadField: r1 = r0->field_7
    //     0xafd7e0: ldur            w1, [x0, #7]
    // 0xafd7e4: DecompressPointer r1
    //     0xafd7e4: add             x1, x1, HEAP, lsl #32
    // 0xafd7e8: r16 = Instance_Brightness
    //     0xafd7e8: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xafd7ec: cmp             w1, w16
    // 0xafd7f0: b.ne            #0xafd804
    // 0xafd7f4: LoadField: r1 = r0->field_57
    //     0xafd7f4: ldur            w1, [x0, #0x57]
    // 0xafd7f8: DecompressPointer r1
    //     0xafd7f8: add             x1, x1, HEAP, lsl #32
    // 0xafd7fc: mov             x0, x1
    // 0xafd800: b               #0xafd810
    // 0xafd804: LoadField: r1 = r0->field_f
    //     0xafd804: ldur            w1, [x0, #0xf]
    // 0xafd808: DecompressPointer r1
    //     0xafd808: add             x1, x1, HEAP, lsl #32
    // 0xafd80c: mov             x0, x1
    // 0xafd810: mov             x3, x0
    // 0xafd814: ldr             x2, [fp, #0x10]
    // 0xafd818: ldur            x0, [fp, #-8]
    // 0xafd81c: stur            x3, [fp, #-0x30]
    // 0xafd820: LoadField: r4 = r2->field_13
    //     0xafd820: ldur            w4, [x2, #0x13]
    // 0xafd824: DecompressPointer r4
    //     0xafd824: add             x4, x4, HEAP, lsl #32
    // 0xafd828: stur            x4, [fp, #-0x28]
    // 0xafd82c: LoadField: r5 = r2->field_17
    //     0xafd82c: ldur            w5, [x2, #0x17]
    // 0xafd830: DecompressPointer r5
    //     0xafd830: add             x5, x5, HEAP, lsl #32
    // 0xafd834: stur            x5, [fp, #-0x20]
    // 0xafd838: r17 = 5682
    //     0xafd838: mov             x17, #0x1632
    // 0xafd83c: cmp             w0, w17
    // 0xafd840: b.eq            #0xafd85c
    // 0xafd844: r17 = 5684
    //     0xafd844: mov             x17, #0x1634
    // 0xafd848: cmp             w0, w17
    // 0xafd84c: b.ne            #0xafd85c
    // 0xafd850: r6 = Instance_Color
    //     0xafd850: add             x6, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xafd854: ldr             x6, [x6, #0xc08]
    // 0xafd858: b               #0xafd868
    // 0xafd85c: LoadField: r1 = r2->field_1b
    //     0xafd85c: ldur            w1, [x2, #0x1b]
    // 0xafd860: DecompressPointer r1
    //     0xafd860: add             x1, x1, HEAP, lsl #32
    // 0xafd864: mov             x6, x1
    // 0xafd868: stur            x6, [fp, #-0x18]
    // 0xafd86c: r17 = 5682
    //     0xafd86c: mov             x17, #0x1632
    // 0xafd870: cmp             w0, w17
    // 0xafd874: b.ne            #0xafd880
    // 0xafd878: mov             x0, x2
    // 0xafd87c: b               #0xafd8e4
    // 0xafd880: r17 = 5684
    //     0xafd880: mov             x17, #0x1634
    // 0xafd884: cmp             w0, w17
    // 0xafd888: b.ne            #0xafd8e0
    // 0xafd88c: mov             x1, x2
    // 0xafd890: LoadField: r0 = r1->field_57
    //     0xafd890: ldur            w0, [x1, #0x57]
    // 0xafd894: DecompressPointer r0
    //     0xafd894: add             x0, x0, HEAP, lsl #32
    // 0xafd898: r16 = Sentinel
    //     0xafd898: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafd89c: cmp             w0, w16
    // 0xafd8a0: b.ne            #0xafd8b0
    // 0xafd8a4: r2 = _colors
    //     0xafd8a4: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xafd8a8: ldr             x2, [x2, #0x4b8]
    // 0xafd8ac: r0 = InitLateFinalInstanceField()
    //     0xafd8ac: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafd8b0: LoadField: r1 = r0->field_7f
    //     0xafd8b0: ldur            w1, [x0, #0x7f]
    // 0xafd8b4: DecompressPointer r1
    //     0xafd8b4: add             x1, x1, HEAP, lsl #32
    // 0xafd8b8: cmp             w1, NULL
    // 0xafd8bc: b.ne            #0xafd8d0
    // 0xafd8c0: LoadField: r1 = r0->field_b
    //     0xafd8c0: ldur            w1, [x0, #0xb]
    // 0xafd8c4: DecompressPointer r1
    //     0xafd8c4: add             x1, x1, HEAP, lsl #32
    // 0xafd8c8: mov             x0, x1
    // 0xafd8cc: b               #0xafd8d4
    // 0xafd8d0: mov             x0, x1
    // 0xafd8d4: mov             x3, x0
    // 0xafd8d8: ldr             x0, [fp, #0x10]
    // 0xafd8dc: b               #0xafd8f0
    // 0xafd8e0: ldr             x0, [fp, #0x10]
    // 0xafd8e4: LoadField: r1 = r0->field_1f
    //     0xafd8e4: ldur            w1, [x0, #0x1f]
    // 0xafd8e8: DecompressPointer r1
    //     0xafd8e8: add             x1, x1, HEAP, lsl #32
    // 0xafd8ec: mov             x3, x1
    // 0xafd8f0: ldur            x2, [fp, #-8]
    // 0xafd8f4: stur            x3, [fp, #-0x38]
    // 0xafd8f8: r17 = 5682
    //     0xafd8f8: mov             x17, #0x1632
    // 0xafd8fc: cmp             w2, w17
    // 0xafd900: b.ne            #0xafd918
    // 0xafd904: LoadField: r1 = r0->field_27
    //     0xafd904: ldur            w1, [x0, #0x27]
    // 0xafd908: DecompressPointer r1
    //     0xafd908: add             x1, x1, HEAP, lsl #32
    // 0xafd90c: mov             x0, x2
    // 0xafd910: mov             x2, x1
    // 0xafd914: b               #0xafd9b8
    // 0xafd918: r17 = 5684
    //     0xafd918: mov             x17, #0x1634
    // 0xafd91c: cmp             w2, w17
    // 0xafd920: b.ne            #0xafd97c
    // 0xafd924: mov             x1, x0
    // 0xafd928: LoadField: r0 = r1->field_57
    //     0xafd928: ldur            w0, [x1, #0x57]
    // 0xafd92c: DecompressPointer r0
    //     0xafd92c: add             x0, x0, HEAP, lsl #32
    // 0xafd930: r16 = Sentinel
    //     0xafd930: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafd934: cmp             w0, w16
    // 0xafd938: b.ne            #0xafd948
    // 0xafd93c: r2 = _colors
    //     0xafd93c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xafd940: ldr             x2, [x2, #0x4b8]
    // 0xafd944: r0 = InitLateFinalInstanceField()
    //     0xafd944: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafd948: LoadField: r1 = r0->field_57
    //     0xafd948: ldur            w1, [x0, #0x57]
    // 0xafd94c: DecompressPointer r1
    //     0xafd94c: add             x1, x1, HEAP, lsl #32
    // 0xafd950: stur            x1, [fp, #-0x40]
    // 0xafd954: r0 = IconThemeData()
    //     0xafd954: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xafd958: mov             x1, x0
    // 0xafd95c: r0 = 24.000000
    //     0xafd95c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xafd960: ldr             x0, [x0, #0x360]
    // 0xafd964: StoreField: r1->field_7 = r0
    //     0xafd964: stur            w0, [x1, #7]
    // 0xafd968: ldur            x2, [fp, #-0x40]
    // 0xafd96c: StoreField: r1->field_1b = r2
    //     0xafd96c: stur            w2, [x1, #0x1b]
    // 0xafd970: mov             x2, x1
    // 0xafd974: ldur            x0, [fp, #-8]
    // 0xafd978: b               #0xafd9b8
    // 0xafd97c: r0 = 24.000000
    //     0xafd97c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xafd980: ldr             x0, [x0, #0x360]
    // 0xafd984: ldr             x1, [fp, #0x10]
    // 0xafd988: LoadField: r0 = r1->field_53
    //     0xafd988: ldur            w0, [x1, #0x53]
    // 0xafd98c: DecompressPointer r0
    //     0xafd98c: add             x0, x0, HEAP, lsl #32
    // 0xafd990: r16 = Sentinel
    //     0xafd990: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafd994: cmp             w0, w16
    // 0xafd998: b.ne            #0xafd9a8
    // 0xafd99c: r2 = _theme
    //     0xafd99c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xafd9a0: ldr             x2, [x2, #0x4c8]
    // 0xafd9a4: r0 = InitLateFinalInstanceField()
    //     0xafd9a4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafd9a8: LoadField: r1 = r0->field_87
    //     0xafd9a8: ldur            w1, [x0, #0x87]
    // 0xafd9ac: DecompressPointer r1
    //     0xafd9ac: add             x1, x1, HEAP, lsl #32
    // 0xafd9b0: mov             x2, x1
    // 0xafd9b4: ldur            x0, [fp, #-8]
    // 0xafd9b8: stur            x2, [fp, #-0x40]
    // 0xafd9bc: r17 = 5682
    //     0xafd9bc: mov             x17, #0x1632
    // 0xafd9c0: cmp             w0, w17
    // 0xafd9c4: b.eq            #0xafda48
    // 0xafd9c8: r17 = 5684
    //     0xafd9c8: mov             x17, #0x1634
    // 0xafd9cc: cmp             w0, w17
    // 0xafd9d0: b.ne            #0xafda48
    // 0xafd9d4: ldr             x1, [fp, #0x10]
    // 0xafd9d8: LoadField: r0 = r1->field_57
    //     0xafd9d8: ldur            w0, [x1, #0x57]
    // 0xafd9dc: DecompressPointer r0
    //     0xafd9dc: add             x0, x0, HEAP, lsl #32
    // 0xafd9e0: r16 = Sentinel
    //     0xafd9e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafd9e4: cmp             w0, w16
    // 0xafd9e8: b.ne            #0xafd9f8
    // 0xafd9ec: r2 = _colors
    //     0xafd9ec: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xafd9f0: ldr             x2, [x2, #0x4b8]
    // 0xafd9f4: r0 = InitLateFinalInstanceField()
    //     0xafd9f4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafd9f8: LoadField: r1 = r0->field_5f
    //     0xafd9f8: ldur            w1, [x0, #0x5f]
    // 0xafd9fc: DecompressPointer r1
    //     0xafd9fc: add             x1, x1, HEAP, lsl #32
    // 0xafda00: cmp             w1, NULL
    // 0xafda04: b.ne            #0xafda18
    // 0xafda08: LoadField: r1 = r0->field_57
    //     0xafda08: ldur            w1, [x0, #0x57]
    // 0xafda0c: DecompressPointer r1
    //     0xafda0c: add             x1, x1, HEAP, lsl #32
    // 0xafda10: mov             x0, x1
    // 0xafda14: b               #0xafda1c
    // 0xafda18: mov             x0, x1
    // 0xafda1c: stur            x0, [fp, #-0x48]
    // 0xafda20: r0 = IconThemeData()
    //     0xafda20: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xafda24: mov             x1, x0
    // 0xafda28: r0 = 24.000000
    //     0xafda28: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xafda2c: ldr             x0, [x0, #0x360]
    // 0xafda30: StoreField: r1->field_7 = r0
    //     0xafda30: stur            w0, [x1, #7]
    // 0xafda34: ldur            x0, [fp, #-0x48]
    // 0xafda38: StoreField: r1->field_1b = r0
    //     0xafda38: stur            w0, [x1, #0x1b]
    // 0xafda3c: mov             x3, x1
    // 0xafda40: ldr             x0, [fp, #0x10]
    // 0xafda44: b               #0xafda58
    // 0xafda48: ldr             x0, [fp, #0x10]
    // 0xafda4c: LoadField: r1 = r0->field_2b
    //     0xafda4c: ldur            w1, [x0, #0x2b]
    // 0xafda50: DecompressPointer r1
    //     0xafda50: add             x1, x1, HEAP, lsl #32
    // 0xafda54: mov             x3, x1
    // 0xafda58: ldur            x2, [fp, #-8]
    // 0xafda5c: stur            x3, [fp, #-0x60]
    // 0xafda60: LoadField: r4 = r0->field_2f
    //     0xafda60: ldur            w4, [x0, #0x2f]
    // 0xafda64: DecompressPointer r4
    //     0xafda64: add             x4, x4, HEAP, lsl #32
    // 0xafda68: stur            x4, [fp, #-0x58]
    // 0xafda6c: LoadField: r5 = r0->field_37
    //     0xafda6c: ldur            w5, [x0, #0x37]
    // 0xafda70: DecompressPointer r5
    //     0xafda70: add             x5, x5, HEAP, lsl #32
    // 0xafda74: stur            x5, [fp, #-0x50]
    // 0xafda78: LoadField: r6 = r0->field_3b
    //     0xafda78: ldur            w6, [x0, #0x3b]
    // 0xafda7c: DecompressPointer r6
    //     0xafda7c: add             x6, x6, HEAP, lsl #32
    // 0xafda80: stur            x6, [fp, #-0x48]
    // 0xafda84: r17 = 5682
    //     0xafda84: mov             x17, #0x1632
    // 0xafda88: cmp             w2, w17
    // 0xafda8c: b.ne            #0xafdaa4
    // 0xafda90: LoadField: r1 = r0->field_3f
    //     0xafda90: ldur            w1, [x0, #0x3f]
    // 0xafda94: DecompressPointer r1
    //     0xafda94: add             x1, x1, HEAP, lsl #32
    // 0xafda98: mov             x0, x2
    // 0xafda9c: mov             x2, x1
    // 0xafdaa0: b               #0xafdb24
    // 0xafdaa4: r17 = 5684
    //     0xafdaa4: mov             x17, #0x1634
    // 0xafdaa8: cmp             w2, w17
    // 0xafdaac: b.ne            #0xafdae8
    // 0xafdab0: mov             x1, x0
    // 0xafdab4: LoadField: r0 = r1->field_5b
    //     0xafdab4: ldur            w0, [x1, #0x5b]
    // 0xafdab8: DecompressPointer r0
    //     0xafdab8: add             x0, x0, HEAP, lsl #32
    // 0xafdabc: r16 = Sentinel
    //     0xafdabc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafdac0: cmp             w0, w16
    // 0xafdac4: b.ne            #0xafdad4
    // 0xafdac8: r2 = _textTheme
    //     0xafdac8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d0] Field <_AppBarDefaultsM3@680187611._textTheme@680187611>: late final (offset: 0x5c)
    //     0xafdacc: ldr             x2, [x2, #0x4d0]
    // 0xafdad0: r0 = InitLateFinalInstanceField()
    //     0xafdad0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafdad4: LoadField: r1 = r0->field_2f
    //     0xafdad4: ldur            w1, [x0, #0x2f]
    // 0xafdad8: DecompressPointer r1
    //     0xafdad8: add             x1, x1, HEAP, lsl #32
    // 0xafdadc: mov             x2, x1
    // 0xafdae0: ldur            x0, [fp, #-8]
    // 0xafdae4: b               #0xafdb24
    // 0xafdae8: ldr             x1, [fp, #0x10]
    // 0xafdaec: LoadField: r0 = r1->field_53
    //     0xafdaec: ldur            w0, [x1, #0x53]
    // 0xafdaf0: DecompressPointer r0
    //     0xafdaf0: add             x0, x0, HEAP, lsl #32
    // 0xafdaf4: r16 = Sentinel
    //     0xafdaf4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafdaf8: cmp             w0, w16
    // 0xafdafc: b.ne            #0xafdb0c
    // 0xafdb00: r2 = _theme
    //     0xafdb00: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xafdb04: ldr             x2, [x2, #0x4c8]
    // 0xafdb08: r0 = InitLateFinalInstanceField()
    //     0xafdb08: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafdb0c: LoadField: r1 = r0->field_93
    //     0xafdb0c: ldur            w1, [x0, #0x93]
    // 0xafdb10: DecompressPointer r1
    //     0xafdb10: add             x1, x1, HEAP, lsl #32
    // 0xafdb14: LoadField: r0 = r1->field_2f
    //     0xafdb14: ldur            w0, [x1, #0x2f]
    // 0xafdb18: DecompressPointer r0
    //     0xafdb18: add             x0, x0, HEAP, lsl #32
    // 0xafdb1c: mov             x2, x0
    // 0xafdb20: ldur            x0, [fp, #-8]
    // 0xafdb24: stur            x2, [fp, #-0x68]
    // 0xafdb28: r17 = 5682
    //     0xafdb28: mov             x17, #0x1632
    // 0xafdb2c: cmp             w0, w17
    // 0xafdb30: b.ne            #0xafdb4c
    // 0xafdb34: ldr             x3, [fp, #0x10]
    // 0xafdb38: LoadField: r0 = r3->field_43
    //     0xafdb38: ldur            w0, [x3, #0x43]
    // 0xafdb3c: DecompressPointer r0
    //     0xafdb3c: add             x0, x0, HEAP, lsl #32
    // 0xafdb40: mov             x1, x0
    // 0xafdb44: mov             x0, x3
    // 0xafdb48: b               #0xafdbcc
    // 0xafdb4c: ldr             x3, [fp, #0x10]
    // 0xafdb50: r17 = 5684
    //     0xafdb50: mov             x17, #0x1634
    // 0xafdb54: cmp             w0, w17
    // 0xafdb58: b.ne            #0xafdb90
    // 0xafdb5c: mov             x1, x3
    // 0xafdb60: LoadField: r0 = r1->field_5b
    //     0xafdb60: ldur            w0, [x1, #0x5b]
    // 0xafdb64: DecompressPointer r0
    //     0xafdb64: add             x0, x0, HEAP, lsl #32
    // 0xafdb68: r16 = Sentinel
    //     0xafdb68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafdb6c: cmp             w0, w16
    // 0xafdb70: b.ne            #0xafdb80
    // 0xafdb74: r2 = _textTheme
    //     0xafdb74: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d0] Field <_AppBarDefaultsM3@680187611._textTheme@680187611>: late final (offset: 0x5c)
    //     0xafdb78: ldr             x2, [x2, #0x4d0]
    // 0xafdb7c: r0 = InitLateFinalInstanceField()
    //     0xafdb7c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafdb80: LoadField: r1 = r0->field_1f
    //     0xafdb80: ldur            w1, [x0, #0x1f]
    // 0xafdb84: DecompressPointer r1
    //     0xafdb84: add             x1, x1, HEAP, lsl #32
    // 0xafdb88: ldr             x0, [fp, #0x10]
    // 0xafdb8c: b               #0xafdbcc
    // 0xafdb90: ldr             x1, [fp, #0x10]
    // 0xafdb94: LoadField: r0 = r1->field_53
    //     0xafdb94: ldur            w0, [x1, #0x53]
    // 0xafdb98: DecompressPointer r0
    //     0xafdb98: add             x0, x0, HEAP, lsl #32
    // 0xafdb9c: r16 = Sentinel
    //     0xafdb9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xafdba0: cmp             w0, w16
    // 0xafdba4: b.ne            #0xafdbb4
    // 0xafdba8: r2 = _theme
    //     0xafdba8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xafdbac: ldr             x2, [x2, #0x4c8]
    // 0xafdbb0: r0 = InitLateFinalInstanceField()
    //     0xafdbb0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xafdbb4: LoadField: r1 = r0->field_93
    //     0xafdbb4: ldur            w1, [x0, #0x93]
    // 0xafdbb8: DecompressPointer r1
    //     0xafdbb8: add             x1, x1, HEAP, lsl #32
    // 0xafdbbc: LoadField: r0 = r1->field_1f
    //     0xafdbbc: ldur            w0, [x1, #0x1f]
    // 0xafdbc0: DecompressPointer r0
    //     0xafdbc0: add             x0, x0, HEAP, lsl #32
    // 0xafdbc4: mov             x1, x0
    // 0xafdbc8: ldr             x0, [fp, #0x10]
    // 0xafdbcc: LoadField: r2 = r0->field_47
    //     0xafdbcc: ldur            w2, [x0, #0x47]
    // 0xafdbd0: DecompressPointer r2
    //     0xafdbd0: add             x2, x2, HEAP, lsl #32
    // 0xafdbd4: ldur            x16, [fp, #-0x10]
    // 0xafdbd8: stp             x16, NULL, [SP, #-0x10]!
    // 0xafdbdc: ldur            x16, [fp, #-0x30]
    // 0xafdbe0: ldur            lr, [fp, #-0x28]
    // 0xafdbe4: stp             lr, x16, [SP, #-0x10]!
    // 0xafdbe8: ldur            x16, [fp, #-0x20]
    // 0xafdbec: ldur            lr, [fp, #-0x18]
    // 0xafdbf0: stp             lr, x16, [SP, #-0x10]!
    // 0xafdbf4: ldur            x16, [fp, #-0x38]
    // 0xafdbf8: stp             NULL, x16, [SP, #-0x10]!
    // 0xafdbfc: ldur            x16, [fp, #-0x40]
    // 0xafdc00: ldur            lr, [fp, #-0x60]
    // 0xafdc04: stp             lr, x16, [SP, #-0x10]!
    // 0xafdc08: ldur            x16, [fp, #-0x58]
    // 0xafdc0c: stp             NULL, x16, [SP, #-0x10]!
    // 0xafdc10: ldur            x16, [fp, #-0x50]
    // 0xafdc14: ldur            lr, [fp, #-0x48]
    // 0xafdc18: stp             lr, x16, [SP, #-0x10]!
    // 0xafdc1c: ldur            x16, [fp, #-0x68]
    // 0xafdc20: stp             x1, x16, [SP, #-0x10]!
    // 0xafdc24: stp             NULL, x2, [SP, #-0x10]!
    // 0xafdc28: r4 = const [0, 0x12, 0x12, 0x12, null]
    //     0xafdc28: add             x4, PP, #0xe, lsl #12  ; [pp+0xe4e0] List(5) [0, 0x12, 0x12, 0x12, Null]
    //     0xafdc2c: ldr             x4, [x4, #0x4e0]
    // 0xafdc30: r0 = hash()
    //     0xafdc30: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafdc34: add             SP, SP, #0x90
    // 0xafdc38: mov             x2, x0
    // 0xafdc3c: r0 = BoxInt64Instr(r2)
    //     0xafdc3c: sbfiz           x0, x2, #1, #0x1f
    //     0xafdc40: cmp             x2, x0, asr #1
    //     0xafdc44: b.eq            #0xafdc50
    //     0xafdc48: bl              #0xd69bb8
    //     0xafdc4c: stur            x2, [x0, #7]
    // 0xafdc50: LeaveFrame
    //     0xafdc50: mov             SP, fp
    //     0xafdc54: ldp             fp, lr, [SP], #0x10
    // 0xafdc58: ret
    //     0xafdc58: ret             
    // 0xafdc5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafdc5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafdc60: b               #0xafd674
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf60e8, size: 0x354
    // 0xbf60e8: EnterFrame
    //     0xbf60e8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf60ec: mov             fp, SP
    // 0xbf60f0: AllocStack(0x50)
    //     0xbf60f0: sub             SP, SP, #0x50
    // 0xbf60f4: CheckStackOverflow
    //     0xbf60f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf60f8: cmp             SP, x16
    //     0xbf60fc: b.ls            #0xbf6410
    // 0xbf6100: ldr             x0, [fp, #0x20]
    // 0xbf6104: LoadField: r1 = r0->field_b
    //     0xbf6104: ldur            w1, [x0, #0xb]
    // 0xbf6108: DecompressPointer r1
    //     0xbf6108: add             x1, x1, HEAP, lsl #32
    // 0xbf610c: ldr             x2, [fp, #0x18]
    // 0xbf6110: LoadField: r3 = r2->field_b
    //     0xbf6110: ldur            w3, [x2, #0xb]
    // 0xbf6114: DecompressPointer r3
    //     0xbf6114: add             x3, x3, HEAP, lsl #32
    // 0xbf6118: ldr             d0, [fp, #0x10]
    // 0xbf611c: r4 = inline_Allocate_Double()
    //     0xbf611c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf6120: add             x4, x4, #0x10
    //     0xbf6124: cmp             x5, x4
    //     0xbf6128: b.ls            #0xbf6418
    //     0xbf612c: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf6130: sub             x4, x4, #0xf
    //     0xbf6134: mov             x5, #0xd108
    //     0xbf6138: movk            x5, #3, lsl #16
    //     0xbf613c: stur            x5, [x4, #-1]
    // 0xbf6140: StoreField: r4->field_7 = d0
    //     0xbf6140: stur            d0, [x4, #7]
    // 0xbf6144: stur            x4, [fp, #-8]
    // 0xbf6148: stp             x3, x1, [SP, #-0x10]!
    // 0xbf614c: SaveReg r4
    //     0xbf614c: str             x4, [SP, #-8]!
    // 0xbf6150: r0 = lerp()
    //     0xbf6150: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf6154: add             SP, SP, #0x18
    // 0xbf6158: stur            x0, [fp, #-0x10]
    // 0xbf615c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf6160: ldur            x16, [fp, #-8]
    // 0xbf6164: SaveReg r16
    //     0xbf6164: str             x16, [SP, #-8]!
    // 0xbf6168: r0 = lerp()
    //     0xbf6168: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf616c: add             SP, SP, #0x18
    // 0xbf6170: ldr             x0, [fp, #0x20]
    // 0xbf6174: LoadField: r1 = r0->field_13
    //     0xbf6174: ldur            w1, [x0, #0x13]
    // 0xbf6178: DecompressPointer r1
    //     0xbf6178: add             x1, x1, HEAP, lsl #32
    // 0xbf617c: ldr             x2, [fp, #0x18]
    // 0xbf6180: LoadField: r3 = r2->field_13
    //     0xbf6180: ldur            w3, [x2, #0x13]
    // 0xbf6184: DecompressPointer r3
    //     0xbf6184: add             x3, x3, HEAP, lsl #32
    // 0xbf6188: stp             x3, x1, [SP, #-0x10]!
    // 0xbf618c: ldur            x16, [fp, #-8]
    // 0xbf6190: SaveReg r16
    //     0xbf6190: str             x16, [SP, #-8]!
    // 0xbf6194: r0 = lerpDouble()
    //     0xbf6194: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf6198: add             SP, SP, #0x18
    // 0xbf619c: mov             x1, x0
    // 0xbf61a0: ldr             x0, [fp, #0x20]
    // 0xbf61a4: stur            x1, [fp, #-0x18]
    // 0xbf61a8: LoadField: r2 = r0->field_17
    //     0xbf61a8: ldur            w2, [x0, #0x17]
    // 0xbf61ac: DecompressPointer r2
    //     0xbf61ac: add             x2, x2, HEAP, lsl #32
    // 0xbf61b0: ldr             x3, [fp, #0x18]
    // 0xbf61b4: LoadField: r4 = r3->field_17
    //     0xbf61b4: ldur            w4, [x3, #0x17]
    // 0xbf61b8: DecompressPointer r4
    //     0xbf61b8: add             x4, x4, HEAP, lsl #32
    // 0xbf61bc: stp             x4, x2, [SP, #-0x10]!
    // 0xbf61c0: ldur            x16, [fp, #-8]
    // 0xbf61c4: SaveReg r16
    //     0xbf61c4: str             x16, [SP, #-8]!
    // 0xbf61c8: r0 = lerpDouble()
    //     0xbf61c8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf61cc: add             SP, SP, #0x18
    // 0xbf61d0: mov             x1, x0
    // 0xbf61d4: ldr             x0, [fp, #0x20]
    // 0xbf61d8: stur            x1, [fp, #-0x20]
    // 0xbf61dc: LoadField: r2 = r0->field_1b
    //     0xbf61dc: ldur            w2, [x0, #0x1b]
    // 0xbf61e0: DecompressPointer r2
    //     0xbf61e0: add             x2, x2, HEAP, lsl #32
    // 0xbf61e4: ldr             x3, [fp, #0x18]
    // 0xbf61e8: LoadField: r4 = r3->field_1b
    //     0xbf61e8: ldur            w4, [x3, #0x1b]
    // 0xbf61ec: DecompressPointer r4
    //     0xbf61ec: add             x4, x4, HEAP, lsl #32
    // 0xbf61f0: stp             x4, x2, [SP, #-0x10]!
    // 0xbf61f4: ldur            x16, [fp, #-8]
    // 0xbf61f8: SaveReg r16
    //     0xbf61f8: str             x16, [SP, #-8]!
    // 0xbf61fc: r0 = lerp()
    //     0xbf61fc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf6200: add             SP, SP, #0x18
    // 0xbf6204: stur            x0, [fp, #-0x28]
    // 0xbf6208: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf620c: ldur            x16, [fp, #-8]
    // 0xbf6210: SaveReg r16
    //     0xbf6210: str             x16, [SP, #-8]!
    // 0xbf6214: r0 = lerp()
    //     0xbf6214: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf6218: add             SP, SP, #0x18
    // 0xbf621c: ldr             x0, [fp, #0x20]
    // 0xbf6220: LoadField: r1 = r0->field_27
    //     0xbf6220: ldur            w1, [x0, #0x27]
    // 0xbf6224: DecompressPointer r1
    //     0xbf6224: add             x1, x1, HEAP, lsl #32
    // 0xbf6228: ldr             x2, [fp, #0x18]
    // 0xbf622c: LoadField: r3 = r2->field_27
    //     0xbf622c: ldur            w3, [x2, #0x27]
    // 0xbf6230: DecompressPointer r3
    //     0xbf6230: add             x3, x3, HEAP, lsl #32
    // 0xbf6234: stp             x3, x1, [SP, #-0x10]!
    // 0xbf6238: ldur            x16, [fp, #-8]
    // 0xbf623c: SaveReg r16
    //     0xbf623c: str             x16, [SP, #-8]!
    // 0xbf6240: r0 = lerp()
    //     0xbf6240: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbf6244: add             SP, SP, #0x18
    // 0xbf6248: mov             x1, x0
    // 0xbf624c: ldr             x0, [fp, #0x20]
    // 0xbf6250: stur            x1, [fp, #-0x30]
    // 0xbf6254: LoadField: r2 = r0->field_2b
    //     0xbf6254: ldur            w2, [x0, #0x2b]
    // 0xbf6258: DecompressPointer r2
    //     0xbf6258: add             x2, x2, HEAP, lsl #32
    // 0xbf625c: ldr             x3, [fp, #0x18]
    // 0xbf6260: LoadField: r4 = r3->field_2b
    //     0xbf6260: ldur            w4, [x3, #0x2b]
    // 0xbf6264: DecompressPointer r4
    //     0xbf6264: add             x4, x4, HEAP, lsl #32
    // 0xbf6268: stp             x4, x2, [SP, #-0x10]!
    // 0xbf626c: ldur            x16, [fp, #-8]
    // 0xbf6270: SaveReg r16
    //     0xbf6270: str             x16, [SP, #-8]!
    // 0xbf6274: r0 = lerp()
    //     0xbf6274: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbf6278: add             SP, SP, #0x18
    // 0xbf627c: mov             x1, x0
    // 0xbf6280: ldr             x0, [fp, #0x20]
    // 0xbf6284: stur            x1, [fp, #-0x38]
    // 0xbf6288: LoadField: r2 = r0->field_2f
    //     0xbf6288: ldur            w2, [x0, #0x2f]
    // 0xbf628c: DecompressPointer r2
    //     0xbf628c: add             x2, x2, HEAP, lsl #32
    // 0xbf6290: ldr             x3, [fp, #0x18]
    // 0xbf6294: LoadField: r4 = r3->field_2f
    //     0xbf6294: ldur            w4, [x3, #0x2f]
    // 0xbf6298: DecompressPointer r4
    //     0xbf6298: add             x4, x4, HEAP, lsl #32
    // 0xbf629c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf62a0: ldr             d0, [fp, #0x10]
    // 0xbf62a4: SaveReg d0
    //     0xbf62a4: str             d0, [SP, #-8]!
    // 0xbf62a8: r0 = lerp()
    //     0xbf62a8: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbf62ac: add             SP, SP, #0x18
    // 0xbf62b0: mov             x1, x0
    // 0xbf62b4: ldr             x0, [fp, #0x20]
    // 0xbf62b8: stur            x1, [fp, #-0x40]
    // 0xbf62bc: LoadField: r2 = r0->field_37
    //     0xbf62bc: ldur            w2, [x0, #0x37]
    // 0xbf62c0: DecompressPointer r2
    //     0xbf62c0: add             x2, x2, HEAP, lsl #32
    // 0xbf62c4: ldr             x3, [fp, #0x18]
    // 0xbf62c8: LoadField: r4 = r3->field_37
    //     0xbf62c8: ldur            w4, [x3, #0x37]
    // 0xbf62cc: DecompressPointer r4
    //     0xbf62cc: add             x4, x4, HEAP, lsl #32
    // 0xbf62d0: stp             x4, x2, [SP, #-0x10]!
    // 0xbf62d4: ldur            x16, [fp, #-8]
    // 0xbf62d8: SaveReg r16
    //     0xbf62d8: str             x16, [SP, #-8]!
    // 0xbf62dc: r0 = lerpDouble()
    //     0xbf62dc: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf62e0: add             SP, SP, #0x18
    // 0xbf62e4: mov             x1, x0
    // 0xbf62e8: ldr             x0, [fp, #0x20]
    // 0xbf62ec: stur            x1, [fp, #-0x48]
    // 0xbf62f0: LoadField: r2 = r0->field_3b
    //     0xbf62f0: ldur            w2, [x0, #0x3b]
    // 0xbf62f4: DecompressPointer r2
    //     0xbf62f4: add             x2, x2, HEAP, lsl #32
    // 0xbf62f8: ldr             x3, [fp, #0x18]
    // 0xbf62fc: LoadField: r4 = r3->field_3b
    //     0xbf62fc: ldur            w4, [x3, #0x3b]
    // 0xbf6300: DecompressPointer r4
    //     0xbf6300: add             x4, x4, HEAP, lsl #32
    // 0xbf6304: stp             x4, x2, [SP, #-0x10]!
    // 0xbf6308: ldur            x16, [fp, #-8]
    // 0xbf630c: SaveReg r16
    //     0xbf630c: str             x16, [SP, #-8]!
    // 0xbf6310: r0 = lerpDouble()
    //     0xbf6310: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf6314: add             SP, SP, #0x18
    // 0xbf6318: stur            x0, [fp, #-0x50]
    // 0xbf631c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf6320: ldur            x16, [fp, #-8]
    // 0xbf6324: SaveReg r16
    //     0xbf6324: str             x16, [SP, #-8]!
    // 0xbf6328: r0 = lerp()
    //     0xbf6328: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf632c: add             SP, SP, #0x18
    // 0xbf6330: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf6334: ldur            x16, [fp, #-8]
    // 0xbf6338: SaveReg r16
    //     0xbf6338: str             x16, [SP, #-8]!
    // 0xbf633c: r0 = lerp()
    //     0xbf633c: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf6340: add             SP, SP, #0x18
    // 0xbf6344: ldr             d0, [fp, #0x10]
    // 0xbf6348: d1 = 0.500000
    //     0xbf6348: fmov            d1, #0.50000000
    // 0xbf634c: fcmp            d0, d1
    // 0xbf6350: b.vs            #0xbf636c
    // 0xbf6354: b.ge            #0xbf636c
    // 0xbf6358: ldr             x0, [fp, #0x20]
    // 0xbf635c: LoadField: r1 = r0->field_47
    //     0xbf635c: ldur            w1, [x0, #0x47]
    // 0xbf6360: DecompressPointer r1
    //     0xbf6360: add             x1, x1, HEAP, lsl #32
    // 0xbf6364: mov             x9, x1
    // 0xbf6368: b               #0xbf637c
    // 0xbf636c: ldr             x0, [fp, #0x18]
    // 0xbf6370: LoadField: r1 = r0->field_47
    //     0xbf6370: ldur            w1, [x0, #0x47]
    // 0xbf6374: DecompressPointer r1
    //     0xbf6374: add             x1, x1, HEAP, lsl #32
    // 0xbf6378: mov             x9, x1
    // 0xbf637c: ldur            x8, [fp, #-0x10]
    // 0xbf6380: ldur            x7, [fp, #-0x18]
    // 0xbf6384: ldur            x6, [fp, #-0x20]
    // 0xbf6388: ldur            x5, [fp, #-0x28]
    // 0xbf638c: ldur            x4, [fp, #-0x30]
    // 0xbf6390: ldur            x3, [fp, #-0x38]
    // 0xbf6394: ldur            x2, [fp, #-0x40]
    // 0xbf6398: ldur            x1, [fp, #-0x48]
    // 0xbf639c: ldur            x0, [fp, #-0x50]
    // 0xbf63a0: stur            x9, [fp, #-8]
    // 0xbf63a4: r0 = AppBarTheme()
    //     0xbf63a4: bl              #0x89fc2c  ; AllocateAppBarThemeStub -> AppBarTheme (size=0x50)
    // 0xbf63a8: ldur            x1, [fp, #-0x18]
    // 0xbf63ac: StoreField: r0->field_13 = r1
    //     0xbf63ac: stur            w1, [x0, #0x13]
    // 0xbf63b0: ldur            x1, [fp, #-0x20]
    // 0xbf63b4: StoreField: r0->field_17 = r1
    //     0xbf63b4: stur            w1, [x0, #0x17]
    // 0xbf63b8: ldur            x1, [fp, #-0x28]
    // 0xbf63bc: StoreField: r0->field_1b = r1
    //     0xbf63bc: stur            w1, [x0, #0x1b]
    // 0xbf63c0: ldur            x1, [fp, #-0x30]
    // 0xbf63c4: StoreField: r0->field_27 = r1
    //     0xbf63c4: stur            w1, [x0, #0x27]
    // 0xbf63c8: ldur            x1, [fp, #-0x38]
    // 0xbf63cc: StoreField: r0->field_2b = r1
    //     0xbf63cc: stur            w1, [x0, #0x2b]
    // 0xbf63d0: ldur            x1, [fp, #-0x40]
    // 0xbf63d4: StoreField: r0->field_2f = r1
    //     0xbf63d4: stur            w1, [x0, #0x2f]
    // 0xbf63d8: ldur            x1, [fp, #-0x48]
    // 0xbf63dc: StoreField: r0->field_37 = r1
    //     0xbf63dc: stur            w1, [x0, #0x37]
    // 0xbf63e0: ldur            x1, [fp, #-0x50]
    // 0xbf63e4: StoreField: r0->field_3b = r1
    //     0xbf63e4: stur            w1, [x0, #0x3b]
    // 0xbf63e8: ldur            x1, [fp, #-8]
    // 0xbf63ec: StoreField: r0->field_47 = r1
    //     0xbf63ec: stur            w1, [x0, #0x47]
    // 0xbf63f0: ldur            x1, [fp, #-0x10]
    // 0xbf63f4: cmp             w1, NULL
    // 0xbf63f8: b.ne            #0xbf6400
    // 0xbf63fc: r1 = Null
    //     0xbf63fc: mov             x1, NULL
    // 0xbf6400: StoreField: r0->field_b = r1
    //     0xbf6400: stur            w1, [x0, #0xb]
    // 0xbf6404: LeaveFrame
    //     0xbf6404: mov             SP, fp
    //     0xbf6408: ldp             fp, lr, [SP], #0x10
    // 0xbf640c: ret
    //     0xbf640c: ret             
    // 0xbf6410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf6410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf6414: b               #0xbf6100
    // 0xbf6418: SaveReg d0
    //     0xbf6418: str             q0, [SP, #-0x10]!
    // 0xbf641c: stp             x2, x3, [SP, #-0x10]!
    // 0xbf6420: stp             x0, x1, [SP, #-0x10]!
    // 0xbf6424: r0 = AllocateDouble()
    //     0xbf6424: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf6428: mov             x4, x0
    // 0xbf642c: ldp             x0, x1, [SP], #0x10
    // 0xbf6430: ldp             x2, x3, [SP], #0x10
    // 0xbf6434: RestoreReg d0
    //     0xbf6434: ldr             q0, [SP], #0x10
    // 0xbf6438: b               #0xbf6140
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8262c, size: 0xd94
    // 0xc8262c: EnterFrame
    //     0xc8262c: stp             fp, lr, [SP, #-0x10]!
    //     0xc82630: mov             fp, SP
    // 0xc82634: AllocStack(0x20)
    //     0xc82634: sub             SP, SP, #0x20
    // 0xc82638: CheckStackOverflow
    //     0xc82638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8263c: cmp             SP, x16
    //     0xc82640: b.ls            #0xc833b8
    // 0xc82644: ldr             x1, [fp, #0x10]
    // 0xc82648: cmp             w1, NULL
    // 0xc8264c: b.ne            #0xc82660
    // 0xc82650: r0 = false
    //     0xc82650: add             x0, NULL, #0x30  ; false
    // 0xc82654: LeaveFrame
    //     0xc82654: mov             SP, fp
    //     0xc82658: ldp             fp, lr, [SP], #0x10
    // 0xc8265c: ret
    //     0xc8265c: ret             
    // 0xc82660: ldr             x2, [fp, #0x18]
    // 0xc82664: cmp             w2, w1
    // 0xc82668: b.ne            #0xc8267c
    // 0xc8266c: r0 = true
    //     0xc8266c: add             x0, NULL, #0x20  ; true
    // 0xc82670: LeaveFrame
    //     0xc82670: mov             SP, fp
    //     0xc82674: ldp             fp, lr, [SP], #0x10
    // 0xc82678: ret
    //     0xc82678: ret             
    // 0xc8267c: r0 = 59
    //     0xc8267c: mov             x0, #0x3b
    // 0xc82680: branchIfSmi(r1, 0xc8268c)
    //     0xc82680: tbz             w1, #0, #0xc8268c
    // 0xc82684: r0 = LoadClassIdInstr(r1)
    //     0xc82684: ldur            x0, [x1, #-1]
    //     0xc82688: ubfx            x0, x0, #0xc, #0x14
    // 0xc8268c: SaveReg r1
    //     0xc8268c: str             x1, [SP, #-8]!
    // 0xc82690: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc82690: mov             x17, #0x57c5
    //     0xc82694: add             lr, x0, x17
    //     0xc82698: ldr             lr, [x21, lr, lsl #3]
    //     0xc8269c: blr             lr
    // 0xc826a0: add             SP, SP, #8
    // 0xc826a4: stur            x0, [fp, #-8]
    // 0xc826a8: ldr             x16, [fp, #0x18]
    // 0xc826ac: SaveReg r16
    //     0xc826ac: str             x16, [SP, #-8]!
    // 0xc826b0: r0 = runtimeType()
    //     0xc826b0: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc826b4: add             SP, SP, #8
    // 0xc826b8: mov             x1, x0
    // 0xc826bc: ldur            x0, [fp, #-8]
    // 0xc826c0: r2 = LoadClassIdInstr(r0)
    //     0xc826c0: ldur            x2, [x0, #-1]
    //     0xc826c4: ubfx            x2, x2, #0xc, #0x14
    // 0xc826c8: stp             x1, x0, [SP, #-0x10]!
    // 0xc826cc: mov             x0, x2
    // 0xc826d0: mov             lr, x0
    // 0xc826d4: ldr             lr, [x21, lr, lsl #3]
    // 0xc826d8: blr             lr
    // 0xc826dc: add             SP, SP, #0x10
    // 0xc826e0: tbz             w0, #4, #0xc826f4
    // 0xc826e4: r0 = false
    //     0xc826e4: add             x0, NULL, #0x30  ; false
    // 0xc826e8: LeaveFrame
    //     0xc826e8: mov             SP, fp
    //     0xc826ec: ldp             fp, lr, [SP], #0x10
    // 0xc826f0: ret
    //     0xc826f0: ret             
    // 0xc826f4: ldr             x0, [fp, #0x10]
    // 0xc826f8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc826f8: mov             x2, #0x76
    //     0xc826fc: tbz             w0, #0, #0xc8270c
    //     0xc82700: ldur            x2, [x0, #-1]
    //     0xc82704: ubfx            x2, x2, #0xc, #0x14
    //     0xc82708: lsl             x2, x2, #1
    // 0xc8270c: stur            x2, [fp, #-8]
    // 0xc82710: r1 = LoadInt32Instr(r2)
    //     0xc82710: sbfx            x1, x2, #1, #0x1f
    // 0xc82714: cmp             x1, #0xb19
    // 0xc82718: b.lt            #0xc833a8
    // 0xc8271c: cmp             x1, #0xb1b
    // 0xc82720: b.gt            #0xc833a8
    // 0xc82724: r17 = 5682
    //     0xc82724: mov             x17, #0x1632
    // 0xc82728: cmp             w2, w17
    // 0xc8272c: b.ne            #0xc82740
    // 0xc82730: LoadField: r1 = r0->field_b
    //     0xc82730: ldur            w1, [x0, #0xb]
    // 0xc82734: DecompressPointer r1
    //     0xc82734: add             x1, x1, HEAP, lsl #32
    // 0xc82738: mov             x2, x1
    // 0xc8273c: b               #0xc827d8
    // 0xc82740: r17 = 5684
    //     0xc82740: mov             x17, #0x1634
    // 0xc82744: cmp             w2, w17
    // 0xc82748: b.ne            #0xc82780
    // 0xc8274c: mov             x1, x0
    // 0xc82750: LoadField: r0 = r1->field_57
    //     0xc82750: ldur            w0, [x1, #0x57]
    // 0xc82754: DecompressPointer r0
    //     0xc82754: add             x0, x0, HEAP, lsl #32
    // 0xc82758: r16 = Sentinel
    //     0xc82758: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8275c: cmp             w0, w16
    // 0xc82760: b.ne            #0xc82770
    // 0xc82764: r2 = _colors
    //     0xc82764: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82768: ldr             x2, [x2, #0x4b8]
    // 0xc8276c: r0 = InitLateFinalInstanceField()
    //     0xc8276c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82770: LoadField: r1 = r0->field_53
    //     0xc82770: ldur            w1, [x0, #0x53]
    // 0xc82774: DecompressPointer r1
    //     0xc82774: add             x1, x1, HEAP, lsl #32
    // 0xc82778: mov             x2, x1
    // 0xc8277c: b               #0xc827d8
    // 0xc82780: ldr             x1, [fp, #0x10]
    // 0xc82784: LoadField: r0 = r1->field_57
    //     0xc82784: ldur            w0, [x1, #0x57]
    // 0xc82788: DecompressPointer r0
    //     0xc82788: add             x0, x0, HEAP, lsl #32
    // 0xc8278c: r16 = Sentinel
    //     0xc8278c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82790: cmp             w0, w16
    // 0xc82794: b.ne            #0xc827a4
    // 0xc82798: r2 = _colors
    //     0xc82798: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c0] Field <_AppBarDefaultsM2@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc8279c: ldr             x2, [x2, #0x4c0]
    // 0xc827a0: r0 = InitLateFinalInstanceField()
    //     0xc827a0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc827a4: LoadField: r1 = r0->field_7
    //     0xc827a4: ldur            w1, [x0, #7]
    // 0xc827a8: DecompressPointer r1
    //     0xc827a8: add             x1, x1, HEAP, lsl #32
    // 0xc827ac: r16 = Instance_Brightness
    //     0xc827ac: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xc827b0: cmp             w1, w16
    // 0xc827b4: b.ne            #0xc827c8
    // 0xc827b8: LoadField: r1 = r0->field_53
    //     0xc827b8: ldur            w1, [x0, #0x53]
    // 0xc827bc: DecompressPointer r1
    //     0xc827bc: add             x1, x1, HEAP, lsl #32
    // 0xc827c0: mov             x0, x1
    // 0xc827c4: b               #0xc827d4
    // 0xc827c8: LoadField: r1 = r0->field_b
    //     0xc827c8: ldur            w1, [x0, #0xb]
    // 0xc827cc: DecompressPointer r1
    //     0xc827cc: add             x1, x1, HEAP, lsl #32
    // 0xc827d0: mov             x0, x1
    // 0xc827d4: mov             x2, x0
    // 0xc827d8: ldr             x0, [fp, #0x18]
    // 0xc827dc: stur            x2, [fp, #-0x18]
    // 0xc827e0: r3 = LoadClassIdInstr(r0)
    //     0xc827e0: ldur            x3, [x0, #-1]
    //     0xc827e4: ubfx            x3, x3, #0xc, #0x14
    // 0xc827e8: lsl             x3, x3, #1
    // 0xc827ec: stur            x3, [fp, #-0x10]
    // 0xc827f0: r17 = 5682
    //     0xc827f0: mov             x17, #0x1632
    // 0xc827f4: cmp             w3, w17
    // 0xc827f8: b.ne            #0xc8280c
    // 0xc827fc: LoadField: r1 = r0->field_b
    //     0xc827fc: ldur            w1, [x0, #0xb]
    // 0xc82800: DecompressPointer r1
    //     0xc82800: add             x1, x1, HEAP, lsl #32
    // 0xc82804: mov             x0, x2
    // 0xc82808: b               #0xc828a8
    // 0xc8280c: r17 = 5684
    //     0xc8280c: mov             x17, #0x1634
    // 0xc82810: cmp             w3, w17
    // 0xc82814: b.ne            #0xc8284c
    // 0xc82818: mov             x1, x0
    // 0xc8281c: LoadField: r0 = r1->field_57
    //     0xc8281c: ldur            w0, [x1, #0x57]
    // 0xc82820: DecompressPointer r0
    //     0xc82820: add             x0, x0, HEAP, lsl #32
    // 0xc82824: r16 = Sentinel
    //     0xc82824: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82828: cmp             w0, w16
    // 0xc8282c: b.ne            #0xc8283c
    // 0xc82830: r2 = _colors
    //     0xc82830: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82834: ldr             x2, [x2, #0x4b8]
    // 0xc82838: r0 = InitLateFinalInstanceField()
    //     0xc82838: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8283c: LoadField: r1 = r0->field_53
    //     0xc8283c: ldur            w1, [x0, #0x53]
    // 0xc82840: DecompressPointer r1
    //     0xc82840: add             x1, x1, HEAP, lsl #32
    // 0xc82844: ldur            x0, [fp, #-0x18]
    // 0xc82848: b               #0xc828a8
    // 0xc8284c: ldr             x1, [fp, #0x18]
    // 0xc82850: LoadField: r0 = r1->field_57
    //     0xc82850: ldur            w0, [x1, #0x57]
    // 0xc82854: DecompressPointer r0
    //     0xc82854: add             x0, x0, HEAP, lsl #32
    // 0xc82858: r16 = Sentinel
    //     0xc82858: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8285c: cmp             w0, w16
    // 0xc82860: b.ne            #0xc82870
    // 0xc82864: r2 = _colors
    //     0xc82864: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c0] Field <_AppBarDefaultsM2@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82868: ldr             x2, [x2, #0x4c0]
    // 0xc8286c: r0 = InitLateFinalInstanceField()
    //     0xc8286c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82870: LoadField: r1 = r0->field_7
    //     0xc82870: ldur            w1, [x0, #7]
    // 0xc82874: DecompressPointer r1
    //     0xc82874: add             x1, x1, HEAP, lsl #32
    // 0xc82878: r16 = Instance_Brightness
    //     0xc82878: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xc8287c: cmp             w1, w16
    // 0xc82880: b.ne            #0xc82894
    // 0xc82884: LoadField: r1 = r0->field_53
    //     0xc82884: ldur            w1, [x0, #0x53]
    // 0xc82888: DecompressPointer r1
    //     0xc82888: add             x1, x1, HEAP, lsl #32
    // 0xc8288c: mov             x0, x1
    // 0xc82890: b               #0xc828a0
    // 0xc82894: LoadField: r1 = r0->field_b
    //     0xc82894: ldur            w1, [x0, #0xb]
    // 0xc82898: DecompressPointer r1
    //     0xc82898: add             x1, x1, HEAP, lsl #32
    // 0xc8289c: mov             x0, x1
    // 0xc828a0: mov             x1, x0
    // 0xc828a4: ldur            x0, [fp, #-0x18]
    // 0xc828a8: r2 = LoadClassIdInstr(r0)
    //     0xc828a8: ldur            x2, [x0, #-1]
    //     0xc828ac: ubfx            x2, x2, #0xc, #0x14
    // 0xc828b0: stp             x1, x0, [SP, #-0x10]!
    // 0xc828b4: mov             x0, x2
    // 0xc828b8: mov             lr, x0
    // 0xc828bc: ldr             lr, [x21, lr, lsl #3]
    // 0xc828c0: blr             lr
    // 0xc828c4: add             SP, SP, #0x10
    // 0xc828c8: tbnz            w0, #4, #0xc833a8
    // 0xc828cc: ldur            x0, [fp, #-8]
    // 0xc828d0: r17 = 5682
    //     0xc828d0: mov             x17, #0x1632
    // 0xc828d4: cmp             w0, w17
    // 0xc828d8: b.ne            #0xc828f0
    // 0xc828dc: ldr             x2, [fp, #0x10]
    // 0xc828e0: LoadField: r1 = r2->field_f
    //     0xc828e0: ldur            w1, [x2, #0xf]
    // 0xc828e4: DecompressPointer r1
    //     0xc828e4: add             x1, x1, HEAP, lsl #32
    // 0xc828e8: mov             x2, x1
    // 0xc828ec: b               #0xc8298c
    // 0xc828f0: ldr             x2, [fp, #0x10]
    // 0xc828f4: r17 = 5684
    //     0xc828f4: mov             x17, #0x1634
    // 0xc828f8: cmp             w0, w17
    // 0xc828fc: b.ne            #0xc82934
    // 0xc82900: mov             x1, x2
    // 0xc82904: LoadField: r0 = r1->field_57
    //     0xc82904: ldur            w0, [x1, #0x57]
    // 0xc82908: DecompressPointer r0
    //     0xc82908: add             x0, x0, HEAP, lsl #32
    // 0xc8290c: r16 = Sentinel
    //     0xc8290c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82910: cmp             w0, w16
    // 0xc82914: b.ne            #0xc82924
    // 0xc82918: r2 = _colors
    //     0xc82918: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc8291c: ldr             x2, [x2, #0x4b8]
    // 0xc82920: r0 = InitLateFinalInstanceField()
    //     0xc82920: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82924: LoadField: r1 = r0->field_57
    //     0xc82924: ldur            w1, [x0, #0x57]
    // 0xc82928: DecompressPointer r1
    //     0xc82928: add             x1, x1, HEAP, lsl #32
    // 0xc8292c: mov             x2, x1
    // 0xc82930: b               #0xc8298c
    // 0xc82934: ldr             x1, [fp, #0x10]
    // 0xc82938: LoadField: r0 = r1->field_57
    //     0xc82938: ldur            w0, [x1, #0x57]
    // 0xc8293c: DecompressPointer r0
    //     0xc8293c: add             x0, x0, HEAP, lsl #32
    // 0xc82940: r16 = Sentinel
    //     0xc82940: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82944: cmp             w0, w16
    // 0xc82948: b.ne            #0xc82958
    // 0xc8294c: r2 = _colors
    //     0xc8294c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c0] Field <_AppBarDefaultsM2@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82950: ldr             x2, [x2, #0x4c0]
    // 0xc82954: r0 = InitLateFinalInstanceField()
    //     0xc82954: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82958: LoadField: r1 = r0->field_7
    //     0xc82958: ldur            w1, [x0, #7]
    // 0xc8295c: DecompressPointer r1
    //     0xc8295c: add             x1, x1, HEAP, lsl #32
    // 0xc82960: r16 = Instance_Brightness
    //     0xc82960: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xc82964: cmp             w1, w16
    // 0xc82968: b.ne            #0xc8297c
    // 0xc8296c: LoadField: r1 = r0->field_57
    //     0xc8296c: ldur            w1, [x0, #0x57]
    // 0xc82970: DecompressPointer r1
    //     0xc82970: add             x1, x1, HEAP, lsl #32
    // 0xc82974: mov             x0, x1
    // 0xc82978: b               #0xc82988
    // 0xc8297c: LoadField: r1 = r0->field_f
    //     0xc8297c: ldur            w1, [x0, #0xf]
    // 0xc82980: DecompressPointer r1
    //     0xc82980: add             x1, x1, HEAP, lsl #32
    // 0xc82984: mov             x0, x1
    // 0xc82988: mov             x2, x0
    // 0xc8298c: ldur            x0, [fp, #-0x10]
    // 0xc82990: stur            x2, [fp, #-0x18]
    // 0xc82994: r17 = 5682
    //     0xc82994: mov             x17, #0x1632
    // 0xc82998: cmp             w0, w17
    // 0xc8299c: b.ne            #0xc829b4
    // 0xc829a0: ldr             x3, [fp, #0x18]
    // 0xc829a4: LoadField: r1 = r3->field_f
    //     0xc829a4: ldur            w1, [x3, #0xf]
    // 0xc829a8: DecompressPointer r1
    //     0xc829a8: add             x1, x1, HEAP, lsl #32
    // 0xc829ac: mov             x0, x2
    // 0xc829b0: b               #0xc82a54
    // 0xc829b4: ldr             x3, [fp, #0x18]
    // 0xc829b8: r17 = 5684
    //     0xc829b8: mov             x17, #0x1634
    // 0xc829bc: cmp             w0, w17
    // 0xc829c0: b.ne            #0xc829f8
    // 0xc829c4: mov             x1, x3
    // 0xc829c8: LoadField: r0 = r1->field_57
    //     0xc829c8: ldur            w0, [x1, #0x57]
    // 0xc829cc: DecompressPointer r0
    //     0xc829cc: add             x0, x0, HEAP, lsl #32
    // 0xc829d0: r16 = Sentinel
    //     0xc829d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc829d4: cmp             w0, w16
    // 0xc829d8: b.ne            #0xc829e8
    // 0xc829dc: r2 = _colors
    //     0xc829dc: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc829e0: ldr             x2, [x2, #0x4b8]
    // 0xc829e4: r0 = InitLateFinalInstanceField()
    //     0xc829e4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc829e8: LoadField: r1 = r0->field_57
    //     0xc829e8: ldur            w1, [x0, #0x57]
    // 0xc829ec: DecompressPointer r1
    //     0xc829ec: add             x1, x1, HEAP, lsl #32
    // 0xc829f0: ldur            x0, [fp, #-0x18]
    // 0xc829f4: b               #0xc82a54
    // 0xc829f8: ldr             x1, [fp, #0x18]
    // 0xc829fc: LoadField: r0 = r1->field_57
    //     0xc829fc: ldur            w0, [x1, #0x57]
    // 0xc82a00: DecompressPointer r0
    //     0xc82a00: add             x0, x0, HEAP, lsl #32
    // 0xc82a04: r16 = Sentinel
    //     0xc82a04: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82a08: cmp             w0, w16
    // 0xc82a0c: b.ne            #0xc82a1c
    // 0xc82a10: r2 = _colors
    //     0xc82a10: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c0] Field <_AppBarDefaultsM2@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82a14: ldr             x2, [x2, #0x4c0]
    // 0xc82a18: r0 = InitLateFinalInstanceField()
    //     0xc82a18: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82a1c: LoadField: r1 = r0->field_7
    //     0xc82a1c: ldur            w1, [x0, #7]
    // 0xc82a20: DecompressPointer r1
    //     0xc82a20: add             x1, x1, HEAP, lsl #32
    // 0xc82a24: r16 = Instance_Brightness
    //     0xc82a24: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xc82a28: cmp             w1, w16
    // 0xc82a2c: b.ne            #0xc82a40
    // 0xc82a30: LoadField: r1 = r0->field_57
    //     0xc82a30: ldur            w1, [x0, #0x57]
    // 0xc82a34: DecompressPointer r1
    //     0xc82a34: add             x1, x1, HEAP, lsl #32
    // 0xc82a38: mov             x0, x1
    // 0xc82a3c: b               #0xc82a4c
    // 0xc82a40: LoadField: r1 = r0->field_f
    //     0xc82a40: ldur            w1, [x0, #0xf]
    // 0xc82a44: DecompressPointer r1
    //     0xc82a44: add             x1, x1, HEAP, lsl #32
    // 0xc82a48: mov             x0, x1
    // 0xc82a4c: mov             x1, x0
    // 0xc82a50: ldur            x0, [fp, #-0x18]
    // 0xc82a54: r2 = LoadClassIdInstr(r0)
    //     0xc82a54: ldur            x2, [x0, #-1]
    //     0xc82a58: ubfx            x2, x2, #0xc, #0x14
    // 0xc82a5c: stp             x1, x0, [SP, #-0x10]!
    // 0xc82a60: mov             x0, x2
    // 0xc82a64: mov             lr, x0
    // 0xc82a68: ldr             lr, [x21, lr, lsl #3]
    // 0xc82a6c: blr             lr
    // 0xc82a70: add             SP, SP, #0x10
    // 0xc82a74: tbnz            w0, #4, #0xc833a8
    // 0xc82a78: ldr             x1, [fp, #0x18]
    // 0xc82a7c: ldr             x2, [fp, #0x10]
    // 0xc82a80: LoadField: r0 = r2->field_13
    //     0xc82a80: ldur            w0, [x2, #0x13]
    // 0xc82a84: DecompressPointer r0
    //     0xc82a84: add             x0, x0, HEAP, lsl #32
    // 0xc82a88: LoadField: r3 = r1->field_13
    //     0xc82a88: ldur            w3, [x1, #0x13]
    // 0xc82a8c: DecompressPointer r3
    //     0xc82a8c: add             x3, x3, HEAP, lsl #32
    // 0xc82a90: r4 = LoadClassIdInstr(r0)
    //     0xc82a90: ldur            x4, [x0, #-1]
    //     0xc82a94: ubfx            x4, x4, #0xc, #0x14
    // 0xc82a98: stp             x3, x0, [SP, #-0x10]!
    // 0xc82a9c: mov             x0, x4
    // 0xc82aa0: mov             lr, x0
    // 0xc82aa4: ldr             lr, [x21, lr, lsl #3]
    // 0xc82aa8: blr             lr
    // 0xc82aac: add             SP, SP, #0x10
    // 0xc82ab0: tbnz            w0, #4, #0xc833a8
    // 0xc82ab4: ldr             x1, [fp, #0x18]
    // 0xc82ab8: ldr             x2, [fp, #0x10]
    // 0xc82abc: LoadField: r0 = r2->field_17
    //     0xc82abc: ldur            w0, [x2, #0x17]
    // 0xc82ac0: DecompressPointer r0
    //     0xc82ac0: add             x0, x0, HEAP, lsl #32
    // 0xc82ac4: LoadField: r3 = r1->field_17
    //     0xc82ac4: ldur            w3, [x1, #0x17]
    // 0xc82ac8: DecompressPointer r3
    //     0xc82ac8: add             x3, x3, HEAP, lsl #32
    // 0xc82acc: r4 = LoadClassIdInstr(r0)
    //     0xc82acc: ldur            x4, [x0, #-1]
    //     0xc82ad0: ubfx            x4, x4, #0xc, #0x14
    // 0xc82ad4: stp             x3, x0, [SP, #-0x10]!
    // 0xc82ad8: mov             x0, x4
    // 0xc82adc: mov             lr, x0
    // 0xc82ae0: ldr             lr, [x21, lr, lsl #3]
    // 0xc82ae4: blr             lr
    // 0xc82ae8: add             SP, SP, #0x10
    // 0xc82aec: tbnz            w0, #4, #0xc833a8
    // 0xc82af0: ldur            x1, [fp, #-8]
    // 0xc82af4: r17 = 5682
    //     0xc82af4: mov             x17, #0x1632
    // 0xc82af8: cmp             w1, w17
    // 0xc82afc: b.eq            #0xc82b1c
    // 0xc82b00: r17 = 5684
    //     0xc82b00: mov             x17, #0x1634
    // 0xc82b04: cmp             w1, w17
    // 0xc82b08: b.ne            #0xc82b1c
    // 0xc82b0c: ldr             x2, [fp, #0x10]
    // 0xc82b10: r0 = Instance_Color
    //     0xc82b10: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xc82b14: ldr             x0, [x0, #0xc08]
    // 0xc82b18: b               #0xc82b28
    // 0xc82b1c: ldr             x2, [fp, #0x10]
    // 0xc82b20: LoadField: r0 = r2->field_1b
    //     0xc82b20: ldur            w0, [x2, #0x1b]
    // 0xc82b24: DecompressPointer r0
    //     0xc82b24: add             x0, x0, HEAP, lsl #32
    // 0xc82b28: ldur            x3, [fp, #-0x10]
    // 0xc82b2c: r17 = 5682
    //     0xc82b2c: mov             x17, #0x1632
    // 0xc82b30: cmp             w3, w17
    // 0xc82b34: b.eq            #0xc82b54
    // 0xc82b38: r17 = 5684
    //     0xc82b38: mov             x17, #0x1634
    // 0xc82b3c: cmp             w3, w17
    // 0xc82b40: b.ne            #0xc82b54
    // 0xc82b44: ldr             x4, [fp, #0x18]
    // 0xc82b48: r5 = Instance_Color
    //     0xc82b48: add             x5, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xc82b4c: ldr             x5, [x5, #0xc08]
    // 0xc82b50: b               #0xc82b60
    // 0xc82b54: ldr             x4, [fp, #0x18]
    // 0xc82b58: LoadField: r5 = r4->field_1b
    //     0xc82b58: ldur            w5, [x4, #0x1b]
    // 0xc82b5c: DecompressPointer r5
    //     0xc82b5c: add             x5, x5, HEAP, lsl #32
    // 0xc82b60: r6 = LoadClassIdInstr(r0)
    //     0xc82b60: ldur            x6, [x0, #-1]
    //     0xc82b64: ubfx            x6, x6, #0xc, #0x14
    // 0xc82b68: stp             x5, x0, [SP, #-0x10]!
    // 0xc82b6c: mov             x0, x6
    // 0xc82b70: mov             lr, x0
    // 0xc82b74: ldr             lr, [x21, lr, lsl #3]
    // 0xc82b78: blr             lr
    // 0xc82b7c: add             SP, SP, #0x10
    // 0xc82b80: tbnz            w0, #4, #0xc833a8
    // 0xc82b84: ldur            x0, [fp, #-8]
    // 0xc82b88: r17 = 5682
    //     0xc82b88: mov             x17, #0x1632
    // 0xc82b8c: cmp             w0, w17
    // 0xc82b90: b.eq            #0xc82bf4
    // 0xc82b94: r17 = 5684
    //     0xc82b94: mov             x17, #0x1634
    // 0xc82b98: cmp             w0, w17
    // 0xc82b9c: b.ne            #0xc82bf4
    // 0xc82ba0: ldr             x1, [fp, #0x10]
    // 0xc82ba4: LoadField: r0 = r1->field_57
    //     0xc82ba4: ldur            w0, [x1, #0x57]
    // 0xc82ba8: DecompressPointer r0
    //     0xc82ba8: add             x0, x0, HEAP, lsl #32
    // 0xc82bac: r16 = Sentinel
    //     0xc82bac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82bb0: cmp             w0, w16
    // 0xc82bb4: b.ne            #0xc82bc4
    // 0xc82bb8: r2 = _colors
    //     0xc82bb8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82bbc: ldr             x2, [x2, #0x4b8]
    // 0xc82bc0: r0 = InitLateFinalInstanceField()
    //     0xc82bc0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82bc4: LoadField: r1 = r0->field_7f
    //     0xc82bc4: ldur            w1, [x0, #0x7f]
    // 0xc82bc8: DecompressPointer r1
    //     0xc82bc8: add             x1, x1, HEAP, lsl #32
    // 0xc82bcc: cmp             w1, NULL
    // 0xc82bd0: b.ne            #0xc82be4
    // 0xc82bd4: LoadField: r1 = r0->field_b
    //     0xc82bd4: ldur            w1, [x0, #0xb]
    // 0xc82bd8: DecompressPointer r1
    //     0xc82bd8: add             x1, x1, HEAP, lsl #32
    // 0xc82bdc: mov             x0, x1
    // 0xc82be0: b               #0xc82be8
    // 0xc82be4: mov             x0, x1
    // 0xc82be8: mov             x3, x0
    // 0xc82bec: ldr             x0, [fp, #0x10]
    // 0xc82bf0: b               #0xc82c04
    // 0xc82bf4: ldr             x0, [fp, #0x10]
    // 0xc82bf8: LoadField: r1 = r0->field_1f
    //     0xc82bf8: ldur            w1, [x0, #0x1f]
    // 0xc82bfc: DecompressPointer r1
    //     0xc82bfc: add             x1, x1, HEAP, lsl #32
    // 0xc82c00: mov             x3, x1
    // 0xc82c04: ldur            x2, [fp, #-0x10]
    // 0xc82c08: stur            x3, [fp, #-0x18]
    // 0xc82c0c: r17 = 5682
    //     0xc82c0c: mov             x17, #0x1632
    // 0xc82c10: cmp             w2, w17
    // 0xc82c14: b.eq            #0xc82c78
    // 0xc82c18: r17 = 5684
    //     0xc82c18: mov             x17, #0x1634
    // 0xc82c1c: cmp             w2, w17
    // 0xc82c20: b.ne            #0xc82c78
    // 0xc82c24: ldr             x1, [fp, #0x18]
    // 0xc82c28: LoadField: r0 = r1->field_57
    //     0xc82c28: ldur            w0, [x1, #0x57]
    // 0xc82c2c: DecompressPointer r0
    //     0xc82c2c: add             x0, x0, HEAP, lsl #32
    // 0xc82c30: r16 = Sentinel
    //     0xc82c30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82c34: cmp             w0, w16
    // 0xc82c38: b.ne            #0xc82c48
    // 0xc82c3c: r2 = _colors
    //     0xc82c3c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82c40: ldr             x2, [x2, #0x4b8]
    // 0xc82c44: r0 = InitLateFinalInstanceField()
    //     0xc82c44: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82c48: LoadField: r1 = r0->field_7f
    //     0xc82c48: ldur            w1, [x0, #0x7f]
    // 0xc82c4c: DecompressPointer r1
    //     0xc82c4c: add             x1, x1, HEAP, lsl #32
    // 0xc82c50: cmp             w1, NULL
    // 0xc82c54: b.ne            #0xc82c68
    // 0xc82c58: LoadField: r1 = r0->field_b
    //     0xc82c58: ldur            w1, [x0, #0xb]
    // 0xc82c5c: DecompressPointer r1
    //     0xc82c5c: add             x1, x1, HEAP, lsl #32
    // 0xc82c60: mov             x0, x1
    // 0xc82c64: b               #0xc82c6c
    // 0xc82c68: mov             x0, x1
    // 0xc82c6c: mov             x2, x0
    // 0xc82c70: ldr             x1, [fp, #0x18]
    // 0xc82c74: b               #0xc82c88
    // 0xc82c78: ldr             x1, [fp, #0x18]
    // 0xc82c7c: LoadField: r0 = r1->field_1f
    //     0xc82c7c: ldur            w0, [x1, #0x1f]
    // 0xc82c80: DecompressPointer r0
    //     0xc82c80: add             x0, x0, HEAP, lsl #32
    // 0xc82c84: mov             x2, x0
    // 0xc82c88: ldur            x0, [fp, #-0x18]
    // 0xc82c8c: r3 = LoadClassIdInstr(r0)
    //     0xc82c8c: ldur            x3, [x0, #-1]
    //     0xc82c90: ubfx            x3, x3, #0xc, #0x14
    // 0xc82c94: stp             x2, x0, [SP, #-0x10]!
    // 0xc82c98: mov             x0, x3
    // 0xc82c9c: mov             lr, x0
    // 0xc82ca0: ldr             lr, [x21, lr, lsl #3]
    // 0xc82ca4: blr             lr
    // 0xc82ca8: add             SP, SP, #0x10
    // 0xc82cac: tbnz            w0, #4, #0xc833a8
    // 0xc82cb0: ldur            x0, [fp, #-8]
    // 0xc82cb4: r17 = 5682
    //     0xc82cb4: mov             x17, #0x1632
    // 0xc82cb8: cmp             w0, w17
    // 0xc82cbc: b.ne            #0xc82cd4
    // 0xc82cc0: ldr             x2, [fp, #0x10]
    // 0xc82cc4: LoadField: r1 = r2->field_27
    //     0xc82cc4: ldur            w1, [x2, #0x27]
    // 0xc82cc8: DecompressPointer r1
    //     0xc82cc8: add             x1, x1, HEAP, lsl #32
    // 0xc82ccc: mov             x2, x1
    // 0xc82cd0: b               #0xc82d70
    // 0xc82cd4: ldr             x2, [fp, #0x10]
    // 0xc82cd8: r17 = 5684
    //     0xc82cd8: mov             x17, #0x1634
    // 0xc82cdc: cmp             w0, w17
    // 0xc82ce0: b.ne            #0xc82d38
    // 0xc82ce4: mov             x1, x2
    // 0xc82ce8: LoadField: r0 = r1->field_57
    //     0xc82ce8: ldur            w0, [x1, #0x57]
    // 0xc82cec: DecompressPointer r0
    //     0xc82cec: add             x0, x0, HEAP, lsl #32
    // 0xc82cf0: r16 = Sentinel
    //     0xc82cf0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82cf4: cmp             w0, w16
    // 0xc82cf8: b.ne            #0xc82d08
    // 0xc82cfc: r2 = _colors
    //     0xc82cfc: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82d00: ldr             x2, [x2, #0x4b8]
    // 0xc82d04: r0 = InitLateFinalInstanceField()
    //     0xc82d04: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82d08: LoadField: r1 = r0->field_57
    //     0xc82d08: ldur            w1, [x0, #0x57]
    // 0xc82d0c: DecompressPointer r1
    //     0xc82d0c: add             x1, x1, HEAP, lsl #32
    // 0xc82d10: stur            x1, [fp, #-0x18]
    // 0xc82d14: r0 = IconThemeData()
    //     0xc82d14: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xc82d18: mov             x1, x0
    // 0xc82d1c: r0 = 24.000000
    //     0xc82d1c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc82d20: ldr             x0, [x0, #0x360]
    // 0xc82d24: StoreField: r1->field_7 = r0
    //     0xc82d24: stur            w0, [x1, #7]
    // 0xc82d28: ldur            x2, [fp, #-0x18]
    // 0xc82d2c: StoreField: r1->field_1b = r2
    //     0xc82d2c: stur            w2, [x1, #0x1b]
    // 0xc82d30: mov             x2, x1
    // 0xc82d34: b               #0xc82d70
    // 0xc82d38: r0 = 24.000000
    //     0xc82d38: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc82d3c: ldr             x0, [x0, #0x360]
    // 0xc82d40: ldr             x1, [fp, #0x10]
    // 0xc82d44: LoadField: r0 = r1->field_53
    //     0xc82d44: ldur            w0, [x1, #0x53]
    // 0xc82d48: DecompressPointer r0
    //     0xc82d48: add             x0, x0, HEAP, lsl #32
    // 0xc82d4c: r16 = Sentinel
    //     0xc82d4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82d50: cmp             w0, w16
    // 0xc82d54: b.ne            #0xc82d64
    // 0xc82d58: r2 = _theme
    //     0xc82d58: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xc82d5c: ldr             x2, [x2, #0x4c8]
    // 0xc82d60: r0 = InitLateFinalInstanceField()
    //     0xc82d60: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82d64: LoadField: r1 = r0->field_87
    //     0xc82d64: ldur            w1, [x0, #0x87]
    // 0xc82d68: DecompressPointer r1
    //     0xc82d68: add             x1, x1, HEAP, lsl #32
    // 0xc82d6c: mov             x2, x1
    // 0xc82d70: ldur            x0, [fp, #-0x10]
    // 0xc82d74: stur            x2, [fp, #-0x18]
    // 0xc82d78: r17 = 5682
    //     0xc82d78: mov             x17, #0x1632
    // 0xc82d7c: cmp             w0, w17
    // 0xc82d80: b.ne            #0xc82d98
    // 0xc82d84: ldr             x3, [fp, #0x18]
    // 0xc82d88: LoadField: r1 = r3->field_27
    //     0xc82d88: ldur            w1, [x3, #0x27]
    // 0xc82d8c: DecompressPointer r1
    //     0xc82d8c: add             x1, x1, HEAP, lsl #32
    // 0xc82d90: mov             x0, x2
    // 0xc82d94: b               #0xc82e34
    // 0xc82d98: ldr             x3, [fp, #0x18]
    // 0xc82d9c: r17 = 5684
    //     0xc82d9c: mov             x17, #0x1634
    // 0xc82da0: cmp             w0, w17
    // 0xc82da4: b.ne            #0xc82dfc
    // 0xc82da8: mov             x1, x3
    // 0xc82dac: LoadField: r0 = r1->field_57
    //     0xc82dac: ldur            w0, [x1, #0x57]
    // 0xc82db0: DecompressPointer r0
    //     0xc82db0: add             x0, x0, HEAP, lsl #32
    // 0xc82db4: r16 = Sentinel
    //     0xc82db4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82db8: cmp             w0, w16
    // 0xc82dbc: b.ne            #0xc82dcc
    // 0xc82dc0: r2 = _colors
    //     0xc82dc0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82dc4: ldr             x2, [x2, #0x4b8]
    // 0xc82dc8: r0 = InitLateFinalInstanceField()
    //     0xc82dc8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82dcc: LoadField: r1 = r0->field_57
    //     0xc82dcc: ldur            w1, [x0, #0x57]
    // 0xc82dd0: DecompressPointer r1
    //     0xc82dd0: add             x1, x1, HEAP, lsl #32
    // 0xc82dd4: stur            x1, [fp, #-0x20]
    // 0xc82dd8: r0 = IconThemeData()
    //     0xc82dd8: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xc82ddc: mov             x1, x0
    // 0xc82de0: r0 = 24.000000
    //     0xc82de0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc82de4: ldr             x0, [x0, #0x360]
    // 0xc82de8: StoreField: r1->field_7 = r0
    //     0xc82de8: stur            w0, [x1, #7]
    // 0xc82dec: ldur            x2, [fp, #-0x20]
    // 0xc82df0: StoreField: r1->field_1b = r2
    //     0xc82df0: stur            w2, [x1, #0x1b]
    // 0xc82df4: ldur            x0, [fp, #-0x18]
    // 0xc82df8: b               #0xc82e34
    // 0xc82dfc: r0 = 24.000000
    //     0xc82dfc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc82e00: ldr             x0, [x0, #0x360]
    // 0xc82e04: ldr             x1, [fp, #0x18]
    // 0xc82e08: LoadField: r0 = r1->field_53
    //     0xc82e08: ldur            w0, [x1, #0x53]
    // 0xc82e0c: DecompressPointer r0
    //     0xc82e0c: add             x0, x0, HEAP, lsl #32
    // 0xc82e10: r16 = Sentinel
    //     0xc82e10: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82e14: cmp             w0, w16
    // 0xc82e18: b.ne            #0xc82e28
    // 0xc82e1c: r2 = _theme
    //     0xc82e1c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xc82e20: ldr             x2, [x2, #0x4c8]
    // 0xc82e24: r0 = InitLateFinalInstanceField()
    //     0xc82e24: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82e28: LoadField: r1 = r0->field_87
    //     0xc82e28: ldur            w1, [x0, #0x87]
    // 0xc82e2c: DecompressPointer r1
    //     0xc82e2c: add             x1, x1, HEAP, lsl #32
    // 0xc82e30: ldur            x0, [fp, #-0x18]
    // 0xc82e34: r2 = LoadClassIdInstr(r0)
    //     0xc82e34: ldur            x2, [x0, #-1]
    //     0xc82e38: ubfx            x2, x2, #0xc, #0x14
    // 0xc82e3c: stp             x1, x0, [SP, #-0x10]!
    // 0xc82e40: mov             x0, x2
    // 0xc82e44: mov             lr, x0
    // 0xc82e48: ldr             lr, [x21, lr, lsl #3]
    // 0xc82e4c: blr             lr
    // 0xc82e50: add             SP, SP, #0x10
    // 0xc82e54: tbnz            w0, #4, #0xc833a8
    // 0xc82e58: ldur            x0, [fp, #-8]
    // 0xc82e5c: r17 = 5682
    //     0xc82e5c: mov             x17, #0x1632
    // 0xc82e60: cmp             w0, w17
    // 0xc82e64: b.ne            #0xc82e74
    // 0xc82e68: r0 = 24.000000
    //     0xc82e68: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc82e6c: ldr             x0, [x0, #0x360]
    // 0xc82e70: b               #0xc82efc
    // 0xc82e74: r17 = 5684
    //     0xc82e74: mov             x17, #0x1634
    // 0xc82e78: cmp             w0, w17
    // 0xc82e7c: b.ne            #0xc82ef4
    // 0xc82e80: ldr             x1, [fp, #0x10]
    // 0xc82e84: LoadField: r0 = r1->field_57
    //     0xc82e84: ldur            w0, [x1, #0x57]
    // 0xc82e88: DecompressPointer r0
    //     0xc82e88: add             x0, x0, HEAP, lsl #32
    // 0xc82e8c: r16 = Sentinel
    //     0xc82e8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82e90: cmp             w0, w16
    // 0xc82e94: b.ne            #0xc82ea4
    // 0xc82e98: r2 = _colors
    //     0xc82e98: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82e9c: ldr             x2, [x2, #0x4b8]
    // 0xc82ea0: r0 = InitLateFinalInstanceField()
    //     0xc82ea0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82ea4: LoadField: r1 = r0->field_5f
    //     0xc82ea4: ldur            w1, [x0, #0x5f]
    // 0xc82ea8: DecompressPointer r1
    //     0xc82ea8: add             x1, x1, HEAP, lsl #32
    // 0xc82eac: cmp             w1, NULL
    // 0xc82eb0: b.ne            #0xc82ec4
    // 0xc82eb4: LoadField: r1 = r0->field_57
    //     0xc82eb4: ldur            w1, [x0, #0x57]
    // 0xc82eb8: DecompressPointer r1
    //     0xc82eb8: add             x1, x1, HEAP, lsl #32
    // 0xc82ebc: mov             x0, x1
    // 0xc82ec0: b               #0xc82ec8
    // 0xc82ec4: mov             x0, x1
    // 0xc82ec8: stur            x0, [fp, #-0x18]
    // 0xc82ecc: r0 = IconThemeData()
    //     0xc82ecc: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xc82ed0: mov             x1, x0
    // 0xc82ed4: r0 = 24.000000
    //     0xc82ed4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc82ed8: ldr             x0, [x0, #0x360]
    // 0xc82edc: StoreField: r1->field_7 = r0
    //     0xc82edc: stur            w0, [x1, #7]
    // 0xc82ee0: ldur            x2, [fp, #-0x18]
    // 0xc82ee4: StoreField: r1->field_1b = r2
    //     0xc82ee4: stur            w2, [x1, #0x1b]
    // 0xc82ee8: mov             x4, x1
    // 0xc82eec: ldr             x2, [fp, #0x10]
    // 0xc82ef0: b               #0xc82f0c
    // 0xc82ef4: r0 = 24.000000
    //     0xc82ef4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc82ef8: ldr             x0, [x0, #0x360]
    // 0xc82efc: ldr             x2, [fp, #0x10]
    // 0xc82f00: LoadField: r1 = r2->field_2b
    //     0xc82f00: ldur            w1, [x2, #0x2b]
    // 0xc82f04: DecompressPointer r1
    //     0xc82f04: add             x1, x1, HEAP, lsl #32
    // 0xc82f08: mov             x4, x1
    // 0xc82f0c: ldur            x3, [fp, #-0x10]
    // 0xc82f10: stur            x4, [fp, #-0x18]
    // 0xc82f14: r17 = 5682
    //     0xc82f14: mov             x17, #0x1632
    // 0xc82f18: cmp             w3, w17
    // 0xc82f1c: b.eq            #0xc82fa0
    // 0xc82f20: r17 = 5684
    //     0xc82f20: mov             x17, #0x1634
    // 0xc82f24: cmp             w3, w17
    // 0xc82f28: b.ne            #0xc82fa0
    // 0xc82f2c: ldr             x1, [fp, #0x18]
    // 0xc82f30: LoadField: r0 = r1->field_57
    //     0xc82f30: ldur            w0, [x1, #0x57]
    // 0xc82f34: DecompressPointer r0
    //     0xc82f34: add             x0, x0, HEAP, lsl #32
    // 0xc82f38: r16 = Sentinel
    //     0xc82f38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc82f3c: cmp             w0, w16
    // 0xc82f40: b.ne            #0xc82f50
    // 0xc82f44: r2 = _colors
    //     0xc82f44: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0xc82f48: ldr             x2, [x2, #0x4b8]
    // 0xc82f4c: r0 = InitLateFinalInstanceField()
    //     0xc82f4c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc82f50: LoadField: r1 = r0->field_5f
    //     0xc82f50: ldur            w1, [x0, #0x5f]
    // 0xc82f54: DecompressPointer r1
    //     0xc82f54: add             x1, x1, HEAP, lsl #32
    // 0xc82f58: cmp             w1, NULL
    // 0xc82f5c: b.ne            #0xc82f70
    // 0xc82f60: LoadField: r1 = r0->field_57
    //     0xc82f60: ldur            w1, [x0, #0x57]
    // 0xc82f64: DecompressPointer r1
    //     0xc82f64: add             x1, x1, HEAP, lsl #32
    // 0xc82f68: mov             x0, x1
    // 0xc82f6c: b               #0xc82f74
    // 0xc82f70: mov             x0, x1
    // 0xc82f74: stur            x0, [fp, #-0x20]
    // 0xc82f78: r0 = IconThemeData()
    //     0xc82f78: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xc82f7c: mov             x1, x0
    // 0xc82f80: r0 = 24.000000
    //     0xc82f80: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc82f84: ldr             x0, [x0, #0x360]
    // 0xc82f88: StoreField: r1->field_7 = r0
    //     0xc82f88: stur            w0, [x1, #7]
    // 0xc82f8c: ldur            x0, [fp, #-0x20]
    // 0xc82f90: StoreField: r1->field_1b = r0
    //     0xc82f90: stur            w0, [x1, #0x1b]
    // 0xc82f94: mov             x2, x1
    // 0xc82f98: ldr             x1, [fp, #0x18]
    // 0xc82f9c: b               #0xc82fb0
    // 0xc82fa0: ldr             x1, [fp, #0x18]
    // 0xc82fa4: LoadField: r0 = r1->field_2b
    //     0xc82fa4: ldur            w0, [x1, #0x2b]
    // 0xc82fa8: DecompressPointer r0
    //     0xc82fa8: add             x0, x0, HEAP, lsl #32
    // 0xc82fac: mov             x2, x0
    // 0xc82fb0: ldur            x0, [fp, #-0x18]
    // 0xc82fb4: r3 = LoadClassIdInstr(r0)
    //     0xc82fb4: ldur            x3, [x0, #-1]
    //     0xc82fb8: ubfx            x3, x3, #0xc, #0x14
    // 0xc82fbc: stp             x2, x0, [SP, #-0x10]!
    // 0xc82fc0: mov             x0, x3
    // 0xc82fc4: mov             lr, x0
    // 0xc82fc8: ldr             lr, [x21, lr, lsl #3]
    // 0xc82fcc: blr             lr
    // 0xc82fd0: add             SP, SP, #0x10
    // 0xc82fd4: tbnz            w0, #4, #0xc833a8
    // 0xc82fd8: ldr             x1, [fp, #0x18]
    // 0xc82fdc: ldr             x2, [fp, #0x10]
    // 0xc82fe0: LoadField: r0 = r2->field_2f
    //     0xc82fe0: ldur            w0, [x2, #0x2f]
    // 0xc82fe4: DecompressPointer r0
    //     0xc82fe4: add             x0, x0, HEAP, lsl #32
    // 0xc82fe8: LoadField: r3 = r1->field_2f
    //     0xc82fe8: ldur            w3, [x1, #0x2f]
    // 0xc82fec: DecompressPointer r3
    //     0xc82fec: add             x3, x3, HEAP, lsl #32
    // 0xc82ff0: r4 = LoadClassIdInstr(r0)
    //     0xc82ff0: ldur            x4, [x0, #-1]
    //     0xc82ff4: ubfx            x4, x4, #0xc, #0x14
    // 0xc82ff8: stp             x3, x0, [SP, #-0x10]!
    // 0xc82ffc: mov             x0, x4
    // 0xc83000: mov             lr, x0
    // 0xc83004: ldr             lr, [x21, lr, lsl #3]
    // 0xc83008: blr             lr
    // 0xc8300c: add             SP, SP, #0x10
    // 0xc83010: tbnz            w0, #4, #0xc833a8
    // 0xc83014: ldr             x1, [fp, #0x18]
    // 0xc83018: ldr             x2, [fp, #0x10]
    // 0xc8301c: LoadField: r0 = r2->field_37
    //     0xc8301c: ldur            w0, [x2, #0x37]
    // 0xc83020: DecompressPointer r0
    //     0xc83020: add             x0, x0, HEAP, lsl #32
    // 0xc83024: LoadField: r3 = r1->field_37
    //     0xc83024: ldur            w3, [x1, #0x37]
    // 0xc83028: DecompressPointer r3
    //     0xc83028: add             x3, x3, HEAP, lsl #32
    // 0xc8302c: r4 = LoadClassIdInstr(r0)
    //     0xc8302c: ldur            x4, [x0, #-1]
    //     0xc83030: ubfx            x4, x4, #0xc, #0x14
    // 0xc83034: stp             x3, x0, [SP, #-0x10]!
    // 0xc83038: mov             x0, x4
    // 0xc8303c: mov             lr, x0
    // 0xc83040: ldr             lr, [x21, lr, lsl #3]
    // 0xc83044: blr             lr
    // 0xc83048: add             SP, SP, #0x10
    // 0xc8304c: tbnz            w0, #4, #0xc833a8
    // 0xc83050: ldr             x1, [fp, #0x18]
    // 0xc83054: ldr             x2, [fp, #0x10]
    // 0xc83058: LoadField: r0 = r2->field_3b
    //     0xc83058: ldur            w0, [x2, #0x3b]
    // 0xc8305c: DecompressPointer r0
    //     0xc8305c: add             x0, x0, HEAP, lsl #32
    // 0xc83060: LoadField: r3 = r1->field_3b
    //     0xc83060: ldur            w3, [x1, #0x3b]
    // 0xc83064: DecompressPointer r3
    //     0xc83064: add             x3, x3, HEAP, lsl #32
    // 0xc83068: r4 = LoadClassIdInstr(r0)
    //     0xc83068: ldur            x4, [x0, #-1]
    //     0xc8306c: ubfx            x4, x4, #0xc, #0x14
    // 0xc83070: stp             x3, x0, [SP, #-0x10]!
    // 0xc83074: mov             x0, x4
    // 0xc83078: mov             lr, x0
    // 0xc8307c: ldr             lr, [x21, lr, lsl #3]
    // 0xc83080: blr             lr
    // 0xc83084: add             SP, SP, #0x10
    // 0xc83088: tbnz            w0, #4, #0xc833a8
    // 0xc8308c: ldur            x0, [fp, #-8]
    // 0xc83090: r17 = 5682
    //     0xc83090: mov             x17, #0x1632
    // 0xc83094: cmp             w0, w17
    // 0xc83098: b.ne            #0xc830b0
    // 0xc8309c: ldr             x2, [fp, #0x10]
    // 0xc830a0: LoadField: r1 = r2->field_3f
    //     0xc830a0: ldur            w1, [x2, #0x3f]
    // 0xc830a4: DecompressPointer r1
    //     0xc830a4: add             x1, x1, HEAP, lsl #32
    // 0xc830a8: mov             x2, x1
    // 0xc830ac: b               #0xc8312c
    // 0xc830b0: ldr             x2, [fp, #0x10]
    // 0xc830b4: r17 = 5684
    //     0xc830b4: mov             x17, #0x1634
    // 0xc830b8: cmp             w0, w17
    // 0xc830bc: b.ne            #0xc830f4
    // 0xc830c0: mov             x1, x2
    // 0xc830c4: LoadField: r0 = r1->field_5b
    //     0xc830c4: ldur            w0, [x1, #0x5b]
    // 0xc830c8: DecompressPointer r0
    //     0xc830c8: add             x0, x0, HEAP, lsl #32
    // 0xc830cc: r16 = Sentinel
    //     0xc830cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc830d0: cmp             w0, w16
    // 0xc830d4: b.ne            #0xc830e4
    // 0xc830d8: r2 = _textTheme
    //     0xc830d8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d0] Field <_AppBarDefaultsM3@680187611._textTheme@680187611>: late final (offset: 0x5c)
    //     0xc830dc: ldr             x2, [x2, #0x4d0]
    // 0xc830e0: r0 = InitLateFinalInstanceField()
    //     0xc830e0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc830e4: LoadField: r1 = r0->field_2f
    //     0xc830e4: ldur            w1, [x0, #0x2f]
    // 0xc830e8: DecompressPointer r1
    //     0xc830e8: add             x1, x1, HEAP, lsl #32
    // 0xc830ec: mov             x2, x1
    // 0xc830f0: b               #0xc8312c
    // 0xc830f4: ldr             x1, [fp, #0x10]
    // 0xc830f8: LoadField: r0 = r1->field_53
    //     0xc830f8: ldur            w0, [x1, #0x53]
    // 0xc830fc: DecompressPointer r0
    //     0xc830fc: add             x0, x0, HEAP, lsl #32
    // 0xc83100: r16 = Sentinel
    //     0xc83100: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc83104: cmp             w0, w16
    // 0xc83108: b.ne            #0xc83118
    // 0xc8310c: r2 = _theme
    //     0xc8310c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xc83110: ldr             x2, [x2, #0x4c8]
    // 0xc83114: r0 = InitLateFinalInstanceField()
    //     0xc83114: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc83118: LoadField: r1 = r0->field_93
    //     0xc83118: ldur            w1, [x0, #0x93]
    // 0xc8311c: DecompressPointer r1
    //     0xc8311c: add             x1, x1, HEAP, lsl #32
    // 0xc83120: LoadField: r0 = r1->field_2f
    //     0xc83120: ldur            w0, [x1, #0x2f]
    // 0xc83124: DecompressPointer r0
    //     0xc83124: add             x0, x0, HEAP, lsl #32
    // 0xc83128: mov             x2, x0
    // 0xc8312c: ldur            x0, [fp, #-0x10]
    // 0xc83130: stur            x2, [fp, #-0x18]
    // 0xc83134: r17 = 5682
    //     0xc83134: mov             x17, #0x1632
    // 0xc83138: cmp             w0, w17
    // 0xc8313c: b.ne            #0xc83154
    // 0xc83140: ldr             x3, [fp, #0x18]
    // 0xc83144: LoadField: r1 = r3->field_3f
    //     0xc83144: ldur            w1, [x3, #0x3f]
    // 0xc83148: DecompressPointer r1
    //     0xc83148: add             x1, x1, HEAP, lsl #32
    // 0xc8314c: mov             x0, x2
    // 0xc83150: b               #0xc831d4
    // 0xc83154: ldr             x3, [fp, #0x18]
    // 0xc83158: r17 = 5684
    //     0xc83158: mov             x17, #0x1634
    // 0xc8315c: cmp             w0, w17
    // 0xc83160: b.ne            #0xc83198
    // 0xc83164: mov             x1, x3
    // 0xc83168: LoadField: r0 = r1->field_5b
    //     0xc83168: ldur            w0, [x1, #0x5b]
    // 0xc8316c: DecompressPointer r0
    //     0xc8316c: add             x0, x0, HEAP, lsl #32
    // 0xc83170: r16 = Sentinel
    //     0xc83170: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc83174: cmp             w0, w16
    // 0xc83178: b.ne            #0xc83188
    // 0xc8317c: r2 = _textTheme
    //     0xc8317c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d0] Field <_AppBarDefaultsM3@680187611._textTheme@680187611>: late final (offset: 0x5c)
    //     0xc83180: ldr             x2, [x2, #0x4d0]
    // 0xc83184: r0 = InitLateFinalInstanceField()
    //     0xc83184: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc83188: LoadField: r1 = r0->field_2f
    //     0xc83188: ldur            w1, [x0, #0x2f]
    // 0xc8318c: DecompressPointer r1
    //     0xc8318c: add             x1, x1, HEAP, lsl #32
    // 0xc83190: ldur            x0, [fp, #-0x18]
    // 0xc83194: b               #0xc831d4
    // 0xc83198: ldr             x1, [fp, #0x18]
    // 0xc8319c: LoadField: r0 = r1->field_53
    //     0xc8319c: ldur            w0, [x1, #0x53]
    // 0xc831a0: DecompressPointer r0
    //     0xc831a0: add             x0, x0, HEAP, lsl #32
    // 0xc831a4: r16 = Sentinel
    //     0xc831a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc831a8: cmp             w0, w16
    // 0xc831ac: b.ne            #0xc831bc
    // 0xc831b0: r2 = _theme
    //     0xc831b0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xc831b4: ldr             x2, [x2, #0x4c8]
    // 0xc831b8: r0 = InitLateFinalInstanceField()
    //     0xc831b8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc831bc: LoadField: r1 = r0->field_93
    //     0xc831bc: ldur            w1, [x0, #0x93]
    // 0xc831c0: DecompressPointer r1
    //     0xc831c0: add             x1, x1, HEAP, lsl #32
    // 0xc831c4: LoadField: r0 = r1->field_2f
    //     0xc831c4: ldur            w0, [x1, #0x2f]
    // 0xc831c8: DecompressPointer r0
    //     0xc831c8: add             x0, x0, HEAP, lsl #32
    // 0xc831cc: mov             x1, x0
    // 0xc831d0: ldur            x0, [fp, #-0x18]
    // 0xc831d4: r2 = LoadClassIdInstr(r0)
    //     0xc831d4: ldur            x2, [x0, #-1]
    //     0xc831d8: ubfx            x2, x2, #0xc, #0x14
    // 0xc831dc: stp             x1, x0, [SP, #-0x10]!
    // 0xc831e0: mov             x0, x2
    // 0xc831e4: mov             lr, x0
    // 0xc831e8: ldr             lr, [x21, lr, lsl #3]
    // 0xc831ec: blr             lr
    // 0xc831f0: add             SP, SP, #0x10
    // 0xc831f4: tbnz            w0, #4, #0xc833a8
    // 0xc831f8: ldur            x0, [fp, #-8]
    // 0xc831fc: r17 = 5682
    //     0xc831fc: mov             x17, #0x1632
    // 0xc83200: cmp             w0, w17
    // 0xc83204: b.ne            #0xc8321c
    // 0xc83208: ldr             x2, [fp, #0x10]
    // 0xc8320c: LoadField: r0 = r2->field_43
    //     0xc8320c: ldur            w0, [x2, #0x43]
    // 0xc83210: DecompressPointer r0
    //     0xc83210: add             x0, x0, HEAP, lsl #32
    // 0xc83214: mov             x2, x0
    // 0xc83218: b               #0xc83298
    // 0xc8321c: ldr             x2, [fp, #0x10]
    // 0xc83220: r17 = 5684
    //     0xc83220: mov             x17, #0x1634
    // 0xc83224: cmp             w0, w17
    // 0xc83228: b.ne            #0xc83260
    // 0xc8322c: mov             x1, x2
    // 0xc83230: LoadField: r0 = r1->field_5b
    //     0xc83230: ldur            w0, [x1, #0x5b]
    // 0xc83234: DecompressPointer r0
    //     0xc83234: add             x0, x0, HEAP, lsl #32
    // 0xc83238: r16 = Sentinel
    //     0xc83238: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8323c: cmp             w0, w16
    // 0xc83240: b.ne            #0xc83250
    // 0xc83244: r2 = _textTheme
    //     0xc83244: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d0] Field <_AppBarDefaultsM3@680187611._textTheme@680187611>: late final (offset: 0x5c)
    //     0xc83248: ldr             x2, [x2, #0x4d0]
    // 0xc8324c: r0 = InitLateFinalInstanceField()
    //     0xc8324c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc83250: LoadField: r1 = r0->field_1f
    //     0xc83250: ldur            w1, [x0, #0x1f]
    // 0xc83254: DecompressPointer r1
    //     0xc83254: add             x1, x1, HEAP, lsl #32
    // 0xc83258: mov             x2, x1
    // 0xc8325c: b               #0xc83298
    // 0xc83260: ldr             x1, [fp, #0x10]
    // 0xc83264: LoadField: r0 = r1->field_53
    //     0xc83264: ldur            w0, [x1, #0x53]
    // 0xc83268: DecompressPointer r0
    //     0xc83268: add             x0, x0, HEAP, lsl #32
    // 0xc8326c: r16 = Sentinel
    //     0xc8326c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc83270: cmp             w0, w16
    // 0xc83274: b.ne            #0xc83284
    // 0xc83278: r2 = _theme
    //     0xc83278: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xc8327c: ldr             x2, [x2, #0x4c8]
    // 0xc83280: r0 = InitLateFinalInstanceField()
    //     0xc83280: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc83284: LoadField: r1 = r0->field_93
    //     0xc83284: ldur            w1, [x0, #0x93]
    // 0xc83288: DecompressPointer r1
    //     0xc83288: add             x1, x1, HEAP, lsl #32
    // 0xc8328c: LoadField: r0 = r1->field_1f
    //     0xc8328c: ldur            w0, [x1, #0x1f]
    // 0xc83290: DecompressPointer r0
    //     0xc83290: add             x0, x0, HEAP, lsl #32
    // 0xc83294: mov             x2, x0
    // 0xc83298: ldur            x0, [fp, #-0x10]
    // 0xc8329c: stur            x2, [fp, #-8]
    // 0xc832a0: r17 = 5682
    //     0xc832a0: mov             x17, #0x1632
    // 0xc832a4: cmp             w0, w17
    // 0xc832a8: b.ne            #0xc832c4
    // 0xc832ac: ldr             x3, [fp, #0x18]
    // 0xc832b0: LoadField: r0 = r3->field_43
    //     0xc832b0: ldur            w0, [x3, #0x43]
    // 0xc832b4: DecompressPointer r0
    //     0xc832b4: add             x0, x0, HEAP, lsl #32
    // 0xc832b8: mov             x1, x0
    // 0xc832bc: mov             x0, x2
    // 0xc832c0: b               #0xc83344
    // 0xc832c4: ldr             x3, [fp, #0x18]
    // 0xc832c8: r17 = 5684
    //     0xc832c8: mov             x17, #0x1634
    // 0xc832cc: cmp             w0, w17
    // 0xc832d0: b.ne            #0xc83308
    // 0xc832d4: mov             x1, x3
    // 0xc832d8: LoadField: r0 = r1->field_5b
    //     0xc832d8: ldur            w0, [x1, #0x5b]
    // 0xc832dc: DecompressPointer r0
    //     0xc832dc: add             x0, x0, HEAP, lsl #32
    // 0xc832e0: r16 = Sentinel
    //     0xc832e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc832e4: cmp             w0, w16
    // 0xc832e8: b.ne            #0xc832f8
    // 0xc832ec: r2 = _textTheme
    //     0xc832ec: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d0] Field <_AppBarDefaultsM3@680187611._textTheme@680187611>: late final (offset: 0x5c)
    //     0xc832f0: ldr             x2, [x2, #0x4d0]
    // 0xc832f4: r0 = InitLateFinalInstanceField()
    //     0xc832f4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc832f8: LoadField: r1 = r0->field_1f
    //     0xc832f8: ldur            w1, [x0, #0x1f]
    // 0xc832fc: DecompressPointer r1
    //     0xc832fc: add             x1, x1, HEAP, lsl #32
    // 0xc83300: ldur            x0, [fp, #-8]
    // 0xc83304: b               #0xc83344
    // 0xc83308: ldr             x1, [fp, #0x18]
    // 0xc8330c: LoadField: r0 = r1->field_53
    //     0xc8330c: ldur            w0, [x1, #0x53]
    // 0xc83310: DecompressPointer r0
    //     0xc83310: add             x0, x0, HEAP, lsl #32
    // 0xc83314: r16 = Sentinel
    //     0xc83314: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc83318: cmp             w0, w16
    // 0xc8331c: b.ne            #0xc8332c
    // 0xc83320: r2 = _theme
    //     0xc83320: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0xc83324: ldr             x2, [x2, #0x4c8]
    // 0xc83328: r0 = InitLateFinalInstanceField()
    //     0xc83328: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8332c: LoadField: r1 = r0->field_93
    //     0xc8332c: ldur            w1, [x0, #0x93]
    // 0xc83330: DecompressPointer r1
    //     0xc83330: add             x1, x1, HEAP, lsl #32
    // 0xc83334: LoadField: r0 = r1->field_1f
    //     0xc83334: ldur            w0, [x1, #0x1f]
    // 0xc83338: DecompressPointer r0
    //     0xc83338: add             x0, x0, HEAP, lsl #32
    // 0xc8333c: mov             x1, x0
    // 0xc83340: ldur            x0, [fp, #-8]
    // 0xc83344: r2 = LoadClassIdInstr(r0)
    //     0xc83344: ldur            x2, [x0, #-1]
    //     0xc83348: ubfx            x2, x2, #0xc, #0x14
    // 0xc8334c: stp             x1, x0, [SP, #-0x10]!
    // 0xc83350: mov             x0, x2
    // 0xc83354: mov             lr, x0
    // 0xc83358: ldr             lr, [x21, lr, lsl #3]
    // 0xc8335c: blr             lr
    // 0xc83360: add             SP, SP, #0x10
    // 0xc83364: tbnz            w0, #4, #0xc833a8
    // 0xc83368: ldr             x0, [fp, #0x18]
    // 0xc8336c: ldr             x1, [fp, #0x10]
    // 0xc83370: LoadField: r2 = r1->field_47
    //     0xc83370: ldur            w2, [x1, #0x47]
    // 0xc83374: DecompressPointer r2
    //     0xc83374: add             x2, x2, HEAP, lsl #32
    // 0xc83378: LoadField: r1 = r0->field_47
    //     0xc83378: ldur            w1, [x0, #0x47]
    // 0xc8337c: DecompressPointer r1
    //     0xc8337c: add             x1, x1, HEAP, lsl #32
    // 0xc83380: r0 = LoadClassIdInstr(r2)
    //     0xc83380: ldur            x0, [x2, #-1]
    //     0xc83384: ubfx            x0, x0, #0xc, #0x14
    // 0xc83388: stp             x1, x2, [SP, #-0x10]!
    // 0xc8338c: mov             lr, x0
    // 0xc83390: ldr             lr, [x21, lr, lsl #3]
    // 0xc83394: blr             lr
    // 0xc83398: add             SP, SP, #0x10
    // 0xc8339c: tbnz            w0, #4, #0xc833a8
    // 0xc833a0: r0 = true
    //     0xc833a0: add             x0, NULL, #0x20  ; true
    // 0xc833a4: b               #0xc833ac
    // 0xc833a8: r0 = false
    //     0xc833a8: add             x0, NULL, #0x30  ; false
    // 0xc833ac: LeaveFrame
    //     0xc833ac: mov             SP, fp
    //     0xc833b0: ldp             fp, lr, [SP], #0x10
    // 0xc833b4: ret
    //     0xc833b4: ret             
    // 0xc833b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc833b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc833bc: b               #0xc82644
  }
}

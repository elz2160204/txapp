// lib: , url: package:flutter/src/material/date.dart

// class id: 1049217, size: 0x8
class :: {
}

// class id: 2215, size: 0x10, field offset: 0x8
class DateTimeRange extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xada5a4, size: 0x7c
    // 0xada5a4: EnterFrame
    //     0xada5a4: stp             fp, lr, [SP, #-0x10]!
    //     0xada5a8: mov             fp, SP
    // 0xada5ac: AllocStack(0x8)
    //     0xada5ac: sub             SP, SP, #8
    // 0xada5b0: CheckStackOverflow
    //     0xada5b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xada5b4: cmp             SP, x16
    //     0xada5b8: b.ls            #0xada618
    // 0xada5bc: ldr             x0, [fp, #0x10]
    // 0xada5c0: LoadField: r3 = r0->field_7
    //     0xada5c0: ldur            w3, [x0, #7]
    // 0xada5c4: DecompressPointer r3
    //     0xada5c4: add             x3, x3, HEAP, lsl #32
    // 0xada5c8: stur            x3, [fp, #-8]
    // 0xada5cc: r1 = Null
    //     0xada5cc: mov             x1, NULL
    // 0xada5d0: r2 = 6
    //     0xada5d0: mov             x2, #6
    // 0xada5d4: r0 = AllocateArray()
    //     0xada5d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada5d8: mov             x1, x0
    // 0xada5dc: ldur            x0, [fp, #-8]
    // 0xada5e0: StoreField: r1->field_f = r0
    //     0xada5e0: stur            w0, [x1, #0xf]
    // 0xada5e4: r17 = " - "
    //     0xada5e4: add             x17, PP, #0x57, lsl #12  ; [pp+0x57318] " - "
    //     0xada5e8: ldr             x17, [x17, #0x318]
    // 0xada5ec: StoreField: r1->field_13 = r17
    //     0xada5ec: stur            w17, [x1, #0x13]
    // 0xada5f0: ldr             x0, [fp, #0x10]
    // 0xada5f4: LoadField: r2 = r0->field_b
    //     0xada5f4: ldur            w2, [x0, #0xb]
    // 0xada5f8: DecompressPointer r2
    //     0xada5f8: add             x2, x2, HEAP, lsl #32
    // 0xada5fc: StoreField: r1->field_17 = r2
    //     0xada5fc: stur            w2, [x1, #0x17]
    // 0xada600: SaveReg r1
    //     0xada600: str             x1, [SP, #-8]!
    // 0xada604: r0 = _interpolate()
    //     0xada604: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada608: add             SP, SP, #8
    // 0xada60c: LeaveFrame
    //     0xada60c: mov             SP, fp
    //     0xada610: ldp             fp, lr, [SP], #0x10
    // 0xada614: ret
    //     0xada614: ret             
    // 0xada618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xada618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xada61c: b               #0xada5bc
  }
  _ ==(/* No info */) {
    // ** addr: 0xc98f00, size: 0x11c
    // 0xc98f00: EnterFrame
    //     0xc98f00: stp             fp, lr, [SP, #-0x10]!
    //     0xc98f04: mov             fp, SP
    // 0xc98f08: CheckStackOverflow
    //     0xc98f08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc98f0c: cmp             SP, x16
    //     0xc98f10: b.ls            #0xc99014
    // 0xc98f14: ldr             x1, [fp, #0x10]
    // 0xc98f18: cmp             w1, NULL
    // 0xc98f1c: b.ne            #0xc98f30
    // 0xc98f20: r0 = false
    //     0xc98f20: add             x0, NULL, #0x30  ; false
    // 0xc98f24: LeaveFrame
    //     0xc98f24: mov             SP, fp
    //     0xc98f28: ldp             fp, lr, [SP], #0x10
    // 0xc98f2c: ret
    //     0xc98f2c: ret             
    // 0xc98f30: r0 = 59
    //     0xc98f30: mov             x0, #0x3b
    // 0xc98f34: branchIfSmi(r1, 0xc98f40)
    //     0xc98f34: tbz             w1, #0, #0xc98f40
    // 0xc98f38: r0 = LoadClassIdInstr(r1)
    //     0xc98f38: ldur            x0, [x1, #-1]
    //     0xc98f3c: ubfx            x0, x0, #0xc, #0x14
    // 0xc98f40: SaveReg r1
    //     0xc98f40: str             x1, [SP, #-8]!
    // 0xc98f44: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc98f44: mov             x17, #0x57c5
    //     0xc98f48: add             lr, x0, x17
    //     0xc98f4c: ldr             lr, [x21, lr, lsl #3]
    //     0xc98f50: blr             lr
    // 0xc98f54: add             SP, SP, #8
    // 0xc98f58: r1 = LoadClassIdInstr(r0)
    //     0xc98f58: ldur            x1, [x0, #-1]
    //     0xc98f5c: ubfx            x1, x1, #0xc, #0x14
    // 0xc98f60: r16 = DateTimeRange
    //     0xc98f60: add             x16, PP, #0x57, lsl #12  ; [pp+0x57320] Type: DateTimeRange
    //     0xc98f64: ldr             x16, [x16, #0x320]
    // 0xc98f68: stp             x16, x0, [SP, #-0x10]!
    // 0xc98f6c: mov             x0, x1
    // 0xc98f70: mov             lr, x0
    // 0xc98f74: ldr             lr, [x21, lr, lsl #3]
    // 0xc98f78: blr             lr
    // 0xc98f7c: add             SP, SP, #0x10
    // 0xc98f80: tbz             w0, #4, #0xc98f94
    // 0xc98f84: r0 = false
    //     0xc98f84: add             x0, NULL, #0x30  ; false
    // 0xc98f88: LeaveFrame
    //     0xc98f88: mov             SP, fp
    //     0xc98f8c: ldp             fp, lr, [SP], #0x10
    // 0xc98f90: ret
    //     0xc98f90: ret             
    // 0xc98f94: ldr             x0, [fp, #0x10]
    // 0xc98f98: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc98f98: mov             x1, #0x76
    //     0xc98f9c: tbz             w0, #0, #0xc98fac
    //     0xc98fa0: ldur            x1, [x0, #-1]
    //     0xc98fa4: ubfx            x1, x1, #0xc, #0x14
    //     0xc98fa8: lsl             x1, x1, #1
    // 0xc98fac: r17 = 4430
    //     0xc98fac: mov             x17, #0x114e
    // 0xc98fb0: cmp             w1, w17
    // 0xc98fb4: b.ne            #0xc99004
    // 0xc98fb8: ldr             x1, [fp, #0x18]
    // 0xc98fbc: LoadField: r2 = r0->field_7
    //     0xc98fbc: ldur            w2, [x0, #7]
    // 0xc98fc0: DecompressPointer r2
    //     0xc98fc0: add             x2, x2, HEAP, lsl #32
    // 0xc98fc4: LoadField: r3 = r1->field_7
    //     0xc98fc4: ldur            w3, [x1, #7]
    // 0xc98fc8: DecompressPointer r3
    //     0xc98fc8: add             x3, x3, HEAP, lsl #32
    // 0xc98fcc: stp             x3, x2, [SP, #-0x10]!
    // 0xc98fd0: r0 = ==()
    //     0xc98fd0: bl              #0xc5bc48  ; [dart:core] DateTime::==
    // 0xc98fd4: add             SP, SP, #0x10
    // 0xc98fd8: tbnz            w0, #4, #0xc99004
    // 0xc98fdc: ldr             x1, [fp, #0x18]
    // 0xc98fe0: ldr             x0, [fp, #0x10]
    // 0xc98fe4: LoadField: r2 = r0->field_b
    //     0xc98fe4: ldur            w2, [x0, #0xb]
    // 0xc98fe8: DecompressPointer r2
    //     0xc98fe8: add             x2, x2, HEAP, lsl #32
    // 0xc98fec: LoadField: r0 = r1->field_b
    //     0xc98fec: ldur            w0, [x1, #0xb]
    // 0xc98ff0: DecompressPointer r0
    //     0xc98ff0: add             x0, x0, HEAP, lsl #32
    // 0xc98ff4: stp             x0, x2, [SP, #-0x10]!
    // 0xc98ff8: r0 = ==()
    //     0xc98ff8: bl              #0xc5bc48  ; [dart:core] DateTime::==
    // 0xc98ffc: add             SP, SP, #0x10
    // 0xc99000: b               #0xc99008
    // 0xc99004: r0 = false
    //     0xc99004: add             x0, NULL, #0x30  ; false
    // 0xc99008: LeaveFrame
    //     0xc99008: mov             SP, fp
    //     0xc9900c: ldp             fp, lr, [SP], #0x10
    // 0xc99010: ret
    //     0xc99010: ret             
    // 0xc99014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc99014: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc99018: b               #0xc98f14
  }
}

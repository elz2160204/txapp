// lib: , url: package:flutter/src/material/tab_bar_theme.dart

// class id: 1049317, size: 0x8
class :: {
}

// class id: 2722, size: 0x38, field offset: 0x8
//   const constructor, 
class TabBarTheme extends _DiagnosticableTree&Object&Diagnosticable {

  static _ of(/* No info */) {
    // ** addr: 0x79f3a4, size: 0x48
    // 0x79f3a4: EnterFrame
    //     0x79f3a4: stp             fp, lr, [SP, #-0x10]!
    //     0x79f3a8: mov             fp, SP
    // 0x79f3ac: CheckStackOverflow
    //     0x79f3ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x79f3b0: cmp             SP, x16
    //     0x79f3b4: b.ls            #0x79f3e4
    // 0x79f3b8: ldr             x16, [fp, #0x10]
    // 0x79f3bc: SaveReg r16
    //     0x79f3bc: str             x16, [SP, #-8]!
    // 0x79f3c0: r0 = of()
    //     0x79f3c0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x79f3c4: add             SP, SP, #8
    // 0x79f3c8: r17 = 299
    //     0x79f3c8: mov             x17, #0x12b
    // 0x79f3cc: ldr             w1, [x0, x17]
    // 0x79f3d0: DecompressPointer r1
    //     0x79f3d0: add             x1, x1, HEAP, lsl #32
    // 0x79f3d4: mov             x0, x1
    // 0x79f3d8: LeaveFrame
    //     0x79f3d8: mov             SP, fp
    //     0x79f3dc: ldp             fp, lr, [SP], #0x10
    // 0x79f3e0: ret
    //     0x79f3e0: ret             
    // 0x79f3e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79f3e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79f3e8: b               #0x79f3b8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb01b70, size: 0x534
    // 0xb01b70: EnterFrame
    //     0xb01b70: stp             fp, lr, [SP, #-0x10]!
    //     0xb01b74: mov             fp, SP
    // 0xb01b78: AllocStack(0x58)
    //     0xb01b78: sub             SP, SP, #0x58
    // 0xb01b7c: CheckStackOverflow
    //     0xb01b7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb01b80: cmp             SP, x16
    //     0xb01b84: b.ls            #0xb02094
    // 0xb01b88: ldr             x0, [fp, #0x10]
    // 0xb01b8c: LoadField: r2 = r0->field_7
    //     0xb01b8c: ldur            w2, [x0, #7]
    // 0xb01b90: DecompressPointer r2
    //     0xb01b90: add             x2, x2, HEAP, lsl #32
    // 0xb01b94: stur            x2, [fp, #-0x10]
    // 0xb01b98: r3 = LoadClassIdInstr(r0)
    //     0xb01b98: ldur            x3, [x0, #-1]
    //     0xb01b9c: ubfx            x3, x3, #0xc, #0x14
    // 0xb01ba0: lsl             x3, x3, #1
    // 0xb01ba4: stur            x3, [fp, #-8]
    // 0xb01ba8: r17 = 5444
    //     0xb01ba8: mov             x17, #0x1544
    // 0xb01bac: cmp             w3, w17
    // 0xb01bb0: b.ne            #0xb01bc8
    // 0xb01bb4: LoadField: r1 = r0->field_b
    //     0xb01bb4: ldur            w1, [x0, #0xb]
    // 0xb01bb8: DecompressPointer r1
    //     0xb01bb8: add             x1, x1, HEAP, lsl #32
    // 0xb01bbc: mov             x2, x3
    // 0xb01bc0: mov             x3, x1
    // 0xb01bc4: b               #0xb01c3c
    // 0xb01bc8: r17 = 5446
    //     0xb01bc8: mov             x17, #0x1546
    // 0xb01bcc: cmp             w3, w17
    // 0xb01bd0: b.ne            #0xb01c10
    // 0xb01bd4: mov             x1, x0
    // 0xb01bd8: LoadField: r0 = r1->field_3b
    //     0xb01bd8: ldur            w0, [x1, #0x3b]
    // 0xb01bdc: DecompressPointer r0
    //     0xb01bdc: add             x0, x0, HEAP, lsl #32
    // 0xb01be0: r16 = Sentinel
    //     0xb01be0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb01be4: cmp             w0, w16
    // 0xb01be8: b.ne            #0xb01bf8
    // 0xb01bec: r2 = _colors
    //     0xb01bec: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb01bf0: ldr             x2, [x2, #0xf50]
    // 0xb01bf4: r0 = InitLateFinalInstanceField()
    //     0xb01bf4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb01bf8: LoadField: r1 = r0->field_b
    //     0xb01bf8: ldur            w1, [x0, #0xb]
    // 0xb01bfc: DecompressPointer r1
    //     0xb01bfc: add             x1, x1, HEAP, lsl #32
    // 0xb01c00: mov             x3, x1
    // 0xb01c04: ldr             x0, [fp, #0x10]
    // 0xb01c08: ldur            x2, [fp, #-8]
    // 0xb01c0c: b               #0xb01c3c
    // 0xb01c10: mov             x1, x0
    // 0xb01c14: LoadField: r0 = r1->field_37
    //     0xb01c14: ldur            w0, [x1, #0x37]
    // 0xb01c18: DecompressPointer r0
    //     0xb01c18: add             x0, x0, HEAP, lsl #32
    // 0xb01c1c: SaveReg r0
    //     0xb01c1c: str             x0, [SP, #-8]!
    // 0xb01c20: r0 = of()
    //     0xb01c20: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb01c24: add             SP, SP, #8
    // 0xb01c28: LoadField: r1 = r0->field_5f
    //     0xb01c28: ldur            w1, [x0, #0x5f]
    // 0xb01c2c: DecompressPointer r1
    //     0xb01c2c: add             x1, x1, HEAP, lsl #32
    // 0xb01c30: mov             x3, x1
    // 0xb01c34: ldr             x0, [fp, #0x10]
    // 0xb01c38: ldur            x2, [fp, #-8]
    // 0xb01c3c: stur            x3, [fp, #-0x20]
    // 0xb01c40: LoadField: r4 = r0->field_f
    //     0xb01c40: ldur            w4, [x0, #0xf]
    // 0xb01c44: DecompressPointer r4
    //     0xb01c44: add             x4, x4, HEAP, lsl #32
    // 0xb01c48: stur            x4, [fp, #-0x18]
    // 0xb01c4c: r17 = 5444
    //     0xb01c4c: mov             x17, #0x1544
    // 0xb01c50: cmp             w2, w17
    // 0xb01c54: b.eq            #0xb01cbc
    // 0xb01c58: r17 = 5446
    //     0xb01c58: mov             x17, #0x1546
    // 0xb01c5c: cmp             w2, w17
    // 0xb01c60: b.ne            #0xb01cb8
    // 0xb01c64: mov             x1, x0
    // 0xb01c68: LoadField: r0 = r1->field_3b
    //     0xb01c68: ldur            w0, [x1, #0x3b]
    // 0xb01c6c: DecompressPointer r0
    //     0xb01c6c: add             x0, x0, HEAP, lsl #32
    // 0xb01c70: r16 = Sentinel
    //     0xb01c70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb01c74: cmp             w0, w16
    // 0xb01c78: b.ne            #0xb01c88
    // 0xb01c7c: r2 = _colors
    //     0xb01c7c: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb01c80: ldr             x2, [x2, #0xf50]
    // 0xb01c84: r0 = InitLateFinalInstanceField()
    //     0xb01c84: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb01c88: LoadField: r1 = r0->field_5b
    //     0xb01c88: ldur            w1, [x0, #0x5b]
    // 0xb01c8c: DecompressPointer r1
    //     0xb01c8c: add             x1, x1, HEAP, lsl #32
    // 0xb01c90: cmp             w1, NULL
    // 0xb01c94: b.ne            #0xb01ca8
    // 0xb01c98: LoadField: r1 = r0->field_53
    //     0xb01c98: ldur            w1, [x0, #0x53]
    // 0xb01c9c: DecompressPointer r1
    //     0xb01c9c: add             x1, x1, HEAP, lsl #32
    // 0xb01ca0: mov             x0, x1
    // 0xb01ca4: b               #0xb01cac
    // 0xb01ca8: mov             x0, x1
    // 0xb01cac: mov             x3, x0
    // 0xb01cb0: ldr             x0, [fp, #0x10]
    // 0xb01cb4: b               #0xb01cc8
    // 0xb01cb8: ldr             x0, [fp, #0x10]
    // 0xb01cbc: LoadField: r1 = r0->field_13
    //     0xb01cbc: ldur            w1, [x0, #0x13]
    // 0xb01cc0: DecompressPointer r1
    //     0xb01cc0: add             x1, x1, HEAP, lsl #32
    // 0xb01cc4: mov             x3, x1
    // 0xb01cc8: ldur            x2, [fp, #-8]
    // 0xb01ccc: stur            x3, [fp, #-0x28]
    // 0xb01cd0: r17 = 5444
    //     0xb01cd0: mov             x17, #0x1544
    // 0xb01cd4: cmp             w2, w17
    // 0xb01cd8: b.ne            #0xb01cec
    // 0xb01cdc: LoadField: r1 = r0->field_17
    //     0xb01cdc: ldur            w1, [x0, #0x17]
    // 0xb01ce0: DecompressPointer r1
    //     0xb01ce0: add             x1, x1, HEAP, lsl #32
    // 0xb01ce4: mov             x3, x1
    // 0xb01ce8: b               #0xb01d80
    // 0xb01cec: r17 = 5446
    //     0xb01cec: mov             x17, #0x1546
    // 0xb01cf0: cmp             w2, w17
    // 0xb01cf4: b.ne            #0xb01d34
    // 0xb01cf8: mov             x1, x0
    // 0xb01cfc: LoadField: r0 = r1->field_3b
    //     0xb01cfc: ldur            w0, [x1, #0x3b]
    // 0xb01d00: DecompressPointer r0
    //     0xb01d00: add             x0, x0, HEAP, lsl #32
    // 0xb01d04: r16 = Sentinel
    //     0xb01d04: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb01d08: cmp             w0, w16
    // 0xb01d0c: b.ne            #0xb01d1c
    // 0xb01d10: r2 = _colors
    //     0xb01d10: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb01d14: ldr             x2, [x2, #0xf50]
    // 0xb01d18: r0 = InitLateFinalInstanceField()
    //     0xb01d18: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb01d1c: LoadField: r1 = r0->field_b
    //     0xb01d1c: ldur            w1, [x0, #0xb]
    // 0xb01d20: DecompressPointer r1
    //     0xb01d20: add             x1, x1, HEAP, lsl #32
    // 0xb01d24: mov             x3, x1
    // 0xb01d28: ldr             x0, [fp, #0x10]
    // 0xb01d2c: ldur            x2, [fp, #-8]
    // 0xb01d30: b               #0xb01d80
    // 0xb01d34: mov             x1, x0
    // 0xb01d38: LoadField: r0 = r1->field_37
    //     0xb01d38: ldur            w0, [x1, #0x37]
    // 0xb01d3c: DecompressPointer r0
    //     0xb01d3c: add             x0, x0, HEAP, lsl #32
    // 0xb01d40: SaveReg r0
    //     0xb01d40: str             x0, [SP, #-8]!
    // 0xb01d44: r0 = of()
    //     0xb01d44: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb01d48: add             SP, SP, #8
    // 0xb01d4c: LoadField: r1 = r0->field_8f
    //     0xb01d4c: ldur            w1, [x0, #0x8f]
    // 0xb01d50: DecompressPointer r1
    //     0xb01d50: add             x1, x1, HEAP, lsl #32
    // 0xb01d54: LoadField: r0 = r1->field_2b
    //     0xb01d54: ldur            w0, [x1, #0x2b]
    // 0xb01d58: DecompressPointer r0
    //     0xb01d58: add             x0, x0, HEAP, lsl #32
    // 0xb01d5c: cmp             w0, NULL
    // 0xb01d60: b.eq            #0xb0209c
    // 0xb01d64: LoadField: r1 = r0->field_b
    //     0xb01d64: ldur            w1, [x0, #0xb]
    // 0xb01d68: DecompressPointer r1
    //     0xb01d68: add             x1, x1, HEAP, lsl #32
    // 0xb01d6c: cmp             w1, NULL
    // 0xb01d70: b.eq            #0xb020a0
    // 0xb01d74: mov             x3, x1
    // 0xb01d78: ldr             x0, [fp, #0x10]
    // 0xb01d7c: ldur            x2, [fp, #-8]
    // 0xb01d80: stur            x3, [fp, #-0x38]
    // 0xb01d84: LoadField: r4 = r0->field_1b
    //     0xb01d84: ldur            w4, [x0, #0x1b]
    // 0xb01d88: DecompressPointer r4
    //     0xb01d88: add             x4, x4, HEAP, lsl #32
    // 0xb01d8c: stur            x4, [fp, #-0x30]
    // 0xb01d90: r17 = 5444
    //     0xb01d90: mov             x17, #0x1544
    // 0xb01d94: cmp             w2, w17
    // 0xb01d98: b.ne            #0xb01db0
    // 0xb01d9c: LoadField: r1 = r0->field_1f
    //     0xb01d9c: ldur            w1, [x0, #0x1f]
    // 0xb01da0: DecompressPointer r1
    //     0xb01da0: add             x1, x1, HEAP, lsl #32
    // 0xb01da4: mov             x0, x2
    // 0xb01da8: mov             x2, x1
    // 0xb01dac: b               #0xb01e24
    // 0xb01db0: r17 = 5446
    //     0xb01db0: mov             x17, #0x1546
    // 0xb01db4: cmp             w2, w17
    // 0xb01db8: b.ne            #0xb01df4
    // 0xb01dbc: mov             x1, x0
    // 0xb01dc0: LoadField: r0 = r1->field_3f
    //     0xb01dc0: ldur            w0, [x1, #0x3f]
    // 0xb01dc4: DecompressPointer r0
    //     0xb01dc4: add             x0, x0, HEAP, lsl #32
    // 0xb01dc8: r16 = Sentinel
    //     0xb01dc8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb01dcc: cmp             w0, w16
    // 0xb01dd0: b.ne            #0xb01de0
    // 0xb01dd4: r2 = _textTheme
    //     0xb01dd4: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf58] Field <_TabsDefaultsM3@472014024._textTheme@472014024>: late final (offset: 0x40)
    //     0xb01dd8: ldr             x2, [x2, #0xf58]
    // 0xb01ddc: r0 = InitLateFinalInstanceField()
    //     0xb01ddc: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb01de0: LoadField: r1 = r0->field_27
    //     0xb01de0: ldur            w1, [x0, #0x27]
    // 0xb01de4: DecompressPointer r1
    //     0xb01de4: add             x1, x1, HEAP, lsl #32
    // 0xb01de8: mov             x2, x1
    // 0xb01dec: ldur            x0, [fp, #-8]
    // 0xb01df0: b               #0xb01e24
    // 0xb01df4: mov             x1, x0
    // 0xb01df8: LoadField: r0 = r1->field_37
    //     0xb01df8: ldur            w0, [x1, #0x37]
    // 0xb01dfc: DecompressPointer r0
    //     0xb01dfc: add             x0, x0, HEAP, lsl #32
    // 0xb01e00: SaveReg r0
    //     0xb01e00: str             x0, [SP, #-8]!
    // 0xb01e04: r0 = of()
    //     0xb01e04: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb01e08: add             SP, SP, #8
    // 0xb01e0c: LoadField: r1 = r0->field_8f
    //     0xb01e0c: ldur            w1, [x0, #0x8f]
    // 0xb01e10: DecompressPointer r1
    //     0xb01e10: add             x1, x1, HEAP, lsl #32
    // 0xb01e14: LoadField: r0 = r1->field_2b
    //     0xb01e14: ldur            w0, [x1, #0x2b]
    // 0xb01e18: DecompressPointer r0
    //     0xb01e18: add             x0, x0, HEAP, lsl #32
    // 0xb01e1c: mov             x2, x0
    // 0xb01e20: ldur            x0, [fp, #-8]
    // 0xb01e24: stur            x2, [fp, #-0x40]
    // 0xb01e28: r17 = 5444
    //     0xb01e28: mov             x17, #0x1544
    // 0xb01e2c: cmp             w0, w17
    // 0xb01e30: b.eq            #0xb01e94
    // 0xb01e34: r17 = 5446
    //     0xb01e34: mov             x17, #0x1546
    // 0xb01e38: cmp             w0, w17
    // 0xb01e3c: b.ne            #0xb01e94
    // 0xb01e40: ldr             x1, [fp, #0x10]
    // 0xb01e44: LoadField: r0 = r1->field_3b
    //     0xb01e44: ldur            w0, [x1, #0x3b]
    // 0xb01e48: DecompressPointer r0
    //     0xb01e48: add             x0, x0, HEAP, lsl #32
    // 0xb01e4c: r16 = Sentinel
    //     0xb01e4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb01e50: cmp             w0, w16
    // 0xb01e54: b.ne            #0xb01e64
    // 0xb01e58: r2 = _colors
    //     0xb01e58: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb01e5c: ldr             x2, [x2, #0xf50]
    // 0xb01e60: r0 = InitLateFinalInstanceField()
    //     0xb01e60: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb01e64: LoadField: r1 = r0->field_5f
    //     0xb01e64: ldur            w1, [x0, #0x5f]
    // 0xb01e68: DecompressPointer r1
    //     0xb01e68: add             x1, x1, HEAP, lsl #32
    // 0xb01e6c: cmp             w1, NULL
    // 0xb01e70: b.ne            #0xb01e84
    // 0xb01e74: LoadField: r1 = r0->field_57
    //     0xb01e74: ldur            w1, [x0, #0x57]
    // 0xb01e78: DecompressPointer r1
    //     0xb01e78: add             x1, x1, HEAP, lsl #32
    // 0xb01e7c: mov             x0, x1
    // 0xb01e80: b               #0xb01e88
    // 0xb01e84: mov             x0, x1
    // 0xb01e88: mov             x3, x0
    // 0xb01e8c: ldr             x0, [fp, #0x10]
    // 0xb01e90: b               #0xb01ea4
    // 0xb01e94: ldr             x0, [fp, #0x10]
    // 0xb01e98: LoadField: r1 = r0->field_23
    //     0xb01e98: ldur            w1, [x0, #0x23]
    // 0xb01e9c: DecompressPointer r1
    //     0xb01e9c: add             x1, x1, HEAP, lsl #32
    // 0xb01ea0: mov             x3, x1
    // 0xb01ea4: ldur            x2, [fp, #-8]
    // 0xb01ea8: stur            x3, [fp, #-0x48]
    // 0xb01eac: r17 = 5444
    //     0xb01eac: mov             x17, #0x1544
    // 0xb01eb0: cmp             w2, w17
    // 0xb01eb4: b.ne            #0xb01ec8
    // 0xb01eb8: LoadField: r1 = r0->field_27
    //     0xb01eb8: ldur            w1, [x0, #0x27]
    // 0xb01ebc: DecompressPointer r1
    //     0xb01ebc: add             x1, x1, HEAP, lsl #32
    // 0xb01ec0: mov             x0, x2
    // 0xb01ec4: b               #0xb01f34
    // 0xb01ec8: r17 = 5446
    //     0xb01ec8: mov             x17, #0x1546
    // 0xb01ecc: cmp             w2, w17
    // 0xb01ed0: b.ne            #0xb01f08
    // 0xb01ed4: mov             x1, x0
    // 0xb01ed8: LoadField: r0 = r1->field_3f
    //     0xb01ed8: ldur            w0, [x1, #0x3f]
    // 0xb01edc: DecompressPointer r0
    //     0xb01edc: add             x0, x0, HEAP, lsl #32
    // 0xb01ee0: r16 = Sentinel
    //     0xb01ee0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb01ee4: cmp             w0, w16
    // 0xb01ee8: b.ne            #0xb01ef8
    // 0xb01eec: r2 = _textTheme
    //     0xb01eec: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf58] Field <_TabsDefaultsM3@472014024._textTheme@472014024>: late final (offset: 0x40)
    //     0xb01ef0: ldr             x2, [x2, #0xf58]
    // 0xb01ef4: r0 = InitLateFinalInstanceField()
    //     0xb01ef4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb01ef8: LoadField: r1 = r0->field_27
    //     0xb01ef8: ldur            w1, [x0, #0x27]
    // 0xb01efc: DecompressPointer r1
    //     0xb01efc: add             x1, x1, HEAP, lsl #32
    // 0xb01f00: ldur            x0, [fp, #-8]
    // 0xb01f04: b               #0xb01f34
    // 0xb01f08: LoadField: r1 = r0->field_37
    //     0xb01f08: ldur            w1, [x0, #0x37]
    // 0xb01f0c: DecompressPointer r1
    //     0xb01f0c: add             x1, x1, HEAP, lsl #32
    // 0xb01f10: SaveReg r1
    //     0xb01f10: str             x1, [SP, #-8]!
    // 0xb01f14: r0 = of()
    //     0xb01f14: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb01f18: add             SP, SP, #8
    // 0xb01f1c: LoadField: r1 = r0->field_8f
    //     0xb01f1c: ldur            w1, [x0, #0x8f]
    // 0xb01f20: DecompressPointer r1
    //     0xb01f20: add             x1, x1, HEAP, lsl #32
    // 0xb01f24: LoadField: r0 = r1->field_2b
    //     0xb01f24: ldur            w0, [x1, #0x2b]
    // 0xb01f28: DecompressPointer r0
    //     0xb01f28: add             x0, x0, HEAP, lsl #32
    // 0xb01f2c: mov             x1, x0
    // 0xb01f30: ldur            x0, [fp, #-8]
    // 0xb01f34: stur            x1, [fp, #-0x50]
    // 0xb01f38: r17 = 5444
    //     0xb01f38: mov             x17, #0x1544
    // 0xb01f3c: cmp             w0, w17
    // 0xb01f40: b.eq            #0xb01f9c
    // 0xb01f44: r17 = 5446
    //     0xb01f44: mov             x17, #0x1546
    // 0xb01f48: cmp             w0, w17
    // 0xb01f4c: b.ne            #0xb01f9c
    // 0xb01f50: ldr             x2, [fp, #0x10]
    // 0xb01f54: r1 = 1
    //     0xb01f54: mov             x1, #1
    // 0xb01f58: r0 = AllocateContext()
    //     0xb01f58: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb01f5c: mov             x1, x0
    // 0xb01f60: ldr             x0, [fp, #0x10]
    // 0xb01f64: StoreField: r1->field_f = r0
    //     0xb01f64: stur            w0, [x1, #0xf]
    // 0xb01f68: mov             x2, x1
    // 0xb01f6c: r1 = Function '<anonymous closure>':.
    //     0xb01f6c: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf60] AnonymousClosure: (0xb020a4), in [package:flutter/src/material/tabs.dart] _TabsDefaultsM3::overlayColor (0xcebcec)
    //     0xb01f70: ldr             x1, [x1, #0xf60]
    // 0xb01f74: r0 = AllocateClosure()
    //     0xb01f74: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb01f78: r16 = <Color?>
    //     0xb01f78: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xb01f7c: ldr             x16, [x16, #0xf68]
    // 0xb01f80: stp             x0, x16, [SP, #-0x10]!
    // 0xb01f84: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb01f84: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb01f88: r0 = resolveWith()
    //     0xb01f88: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xb01f8c: add             SP, SP, #0x10
    // 0xb01f90: mov             x2, x0
    // 0xb01f94: ldr             x0, [fp, #0x10]
    // 0xb01f98: b               #0xb01fac
    // 0xb01f9c: ldr             x0, [fp, #0x10]
    // 0xb01fa0: LoadField: r1 = r0->field_2b
    //     0xb01fa0: ldur            w1, [x0, #0x2b]
    // 0xb01fa4: DecompressPointer r1
    //     0xb01fa4: add             x1, x1, HEAP, lsl #32
    // 0xb01fa8: mov             x2, x1
    // 0xb01fac: ldur            x1, [fp, #-8]
    // 0xb01fb0: stur            x2, [fp, #-0x58]
    // 0xb01fb4: r17 = 5444
    //     0xb01fb4: mov             x17, #0x1544
    // 0xb01fb8: cmp             w1, w17
    // 0xb01fbc: b.ne            #0xb01fd0
    // 0xb01fc0: LoadField: r1 = r0->field_2f
    //     0xb01fc0: ldur            w1, [x0, #0x2f]
    // 0xb01fc4: DecompressPointer r1
    //     0xb01fc4: add             x1, x1, HEAP, lsl #32
    // 0xb01fc8: mov             x0, x1
    // 0xb01fcc: b               #0xb02020
    // 0xb01fd0: r17 = 5446
    //     0xb01fd0: mov             x17, #0x1546
    // 0xb01fd4: cmp             w1, w17
    // 0xb01fd8: b.ne            #0xb02000
    // 0xb01fdc: LoadField: r1 = r0->field_37
    //     0xb01fdc: ldur            w1, [x0, #0x37]
    // 0xb01fe0: DecompressPointer r1
    //     0xb01fe0: add             x1, x1, HEAP, lsl #32
    // 0xb01fe4: SaveReg r1
    //     0xb01fe4: str             x1, [SP, #-8]!
    // 0xb01fe8: r0 = of()
    //     0xb01fe8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb01fec: add             SP, SP, #8
    // 0xb01ff0: LoadField: r1 = r0->field_27
    //     0xb01ff0: ldur            w1, [x0, #0x27]
    // 0xb01ff4: DecompressPointer r1
    //     0xb01ff4: add             x1, x1, HEAP, lsl #32
    // 0xb01ff8: mov             x0, x1
    // 0xb01ffc: b               #0xb02020
    // 0xb02000: LoadField: r1 = r0->field_37
    //     0xb02000: ldur            w1, [x0, #0x37]
    // 0xb02004: DecompressPointer r1
    //     0xb02004: add             x1, x1, HEAP, lsl #32
    // 0xb02008: SaveReg r1
    //     0xb02008: str             x1, [SP, #-8]!
    // 0xb0200c: r0 = of()
    //     0xb0200c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb02010: add             SP, SP, #8
    // 0xb02014: LoadField: r1 = r0->field_27
    //     0xb02014: ldur            w1, [x0, #0x27]
    // 0xb02018: DecompressPointer r1
    //     0xb02018: add             x1, x1, HEAP, lsl #32
    // 0xb0201c: mov             x0, x1
    // 0xb02020: ldur            x16, [fp, #-0x10]
    // 0xb02024: ldur            lr, [fp, #-0x20]
    // 0xb02028: stp             lr, x16, [SP, #-0x10]!
    // 0xb0202c: ldur            x16, [fp, #-0x18]
    // 0xb02030: ldur            lr, [fp, #-0x28]
    // 0xb02034: stp             lr, x16, [SP, #-0x10]!
    // 0xb02038: ldur            x16, [fp, #-0x38]
    // 0xb0203c: ldur            lr, [fp, #-0x30]
    // 0xb02040: stp             lr, x16, [SP, #-0x10]!
    // 0xb02044: ldur            x16, [fp, #-0x40]
    // 0xb02048: ldur            lr, [fp, #-0x48]
    // 0xb0204c: stp             lr, x16, [SP, #-0x10]!
    // 0xb02050: ldur            x16, [fp, #-0x50]
    // 0xb02054: ldur            lr, [fp, #-0x58]
    // 0xb02058: stp             lr, x16, [SP, #-0x10]!
    // 0xb0205c: stp             NULL, x0, [SP, #-0x10]!
    // 0xb02060: r4 = const [0, 0xc, 0xc, 0xc, null]
    //     0xb02060: add             x4, PP, #0xe, lsl #12  ; [pp+0xe110] List(5) [0, 0xc, 0xc, 0xc, Null]
    //     0xb02064: ldr             x4, [x4, #0x110]
    // 0xb02068: r0 = hash()
    //     0xb02068: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0206c: add             SP, SP, #0x60
    // 0xb02070: mov             x2, x0
    // 0xb02074: r0 = BoxInt64Instr(r2)
    //     0xb02074: sbfiz           x0, x2, #1, #0x1f
    //     0xb02078: cmp             x2, x0, asr #1
    //     0xb0207c: b.eq            #0xb02088
    //     0xb02080: bl              #0xd69bb8
    //     0xb02084: stur            x2, [x0, #7]
    // 0xb02088: LeaveFrame
    //     0xb02088: mov             SP, fp
    //     0xb0208c: ldp             fp, lr, [SP], #0x10
    // 0xb02090: ret
    //     0xb02090: ret             
    // 0xb02094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb02094: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb02098: b               #0xb01b88
    // 0xb0209c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb0209c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb020a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb020a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf2370, size: 0x2a8
    // 0xbf2370: EnterFrame
    //     0xbf2370: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2374: mov             fp, SP
    // 0xbf2378: AllocStack(0x40)
    //     0xbf2378: sub             SP, SP, #0x40
    // 0xbf237c: CheckStackOverflow
    //     0xbf237c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf2380: cmp             SP, x16
    //     0xbf2384: b.ls            #0xbf25f4
    // 0xbf2388: ldr             x0, [fp, #0x20]
    // 0xbf238c: LoadField: r1 = r0->field_7
    //     0xbf238c: ldur            w1, [x0, #7]
    // 0xbf2390: DecompressPointer r1
    //     0xbf2390: add             x1, x1, HEAP, lsl #32
    // 0xbf2394: ldr             x2, [fp, #0x18]
    // 0xbf2398: LoadField: r3 = r2->field_7
    //     0xbf2398: ldur            w3, [x2, #7]
    // 0xbf239c: DecompressPointer r3
    //     0xbf239c: add             x3, x3, HEAP, lsl #32
    // 0xbf23a0: stp             x3, x1, [SP, #-0x10]!
    // 0xbf23a4: ldr             d0, [fp, #0x10]
    // 0xbf23a8: SaveReg d0
    //     0xbf23a8: str             d0, [SP, #-8]!
    // 0xbf23ac: r0 = lerp()
    //     0xbf23ac: bl              #0xbf2618  ; [package:flutter/src/painting/decoration.dart] Decoration::lerp
    // 0xbf23b0: add             SP, SP, #0x18
    // 0xbf23b4: ldr             d0, [fp, #0x10]
    // 0xbf23b8: stur            x0, [fp, #-0x10]
    // 0xbf23bc: r1 = inline_Allocate_Double()
    //     0xbf23bc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf23c0: add             x1, x1, #0x10
    //     0xbf23c4: cmp             x2, x1
    //     0xbf23c8: b.ls            #0xbf25fc
    //     0xbf23cc: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf23d0: sub             x1, x1, #0xf
    //     0xbf23d4: mov             x2, #0xd108
    //     0xbf23d8: movk            x2, #3, lsl #16
    //     0xbf23dc: stur            x2, [x1, #-1]
    // 0xbf23e0: StoreField: r1->field_7 = d0
    //     0xbf23e0: stur            d0, [x1, #7]
    // 0xbf23e4: stur            x1, [fp, #-8]
    // 0xbf23e8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf23ec: SaveReg r1
    //     0xbf23ec: str             x1, [SP, #-8]!
    // 0xbf23f0: r0 = lerp()
    //     0xbf23f0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf23f4: add             SP, SP, #0x18
    // 0xbf23f8: ldr             d0, [fp, #0x10]
    // 0xbf23fc: d1 = 0.500000
    //     0xbf23fc: fmov            d1, #0.50000000
    // 0xbf2400: fcmp            d0, d1
    // 0xbf2404: b.vs            #0xbf2424
    // 0xbf2408: b.ge            #0xbf2424
    // 0xbf240c: ldr             x0, [fp, #0x20]
    // 0xbf2410: LoadField: r1 = r0->field_f
    //     0xbf2410: ldur            w1, [x0, #0xf]
    // 0xbf2414: DecompressPointer r1
    //     0xbf2414: add             x1, x1, HEAP, lsl #32
    // 0xbf2418: mov             x3, x1
    // 0xbf241c: ldr             x1, [fp, #0x18]
    // 0xbf2420: b               #0xbf2438
    // 0xbf2424: ldr             x0, [fp, #0x20]
    // 0xbf2428: ldr             x1, [fp, #0x18]
    // 0xbf242c: LoadField: r2 = r1->field_f
    //     0xbf242c: ldur            w2, [x1, #0xf]
    // 0xbf2430: DecompressPointer r2
    //     0xbf2430: add             x2, x2, HEAP, lsl #32
    // 0xbf2434: mov             x3, x2
    // 0xbf2438: ldur            x2, [fp, #-0x10]
    // 0xbf243c: stur            x3, [fp, #-0x18]
    // 0xbf2440: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf2444: ldur            x16, [fp, #-8]
    // 0xbf2448: SaveReg r16
    //     0xbf2448: str             x16, [SP, #-8]!
    // 0xbf244c: r0 = lerp()
    //     0xbf244c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2450: add             SP, SP, #0x18
    // 0xbf2454: ldr             x0, [fp, #0x20]
    // 0xbf2458: LoadField: r1 = r0->field_17
    //     0xbf2458: ldur            w1, [x0, #0x17]
    // 0xbf245c: DecompressPointer r1
    //     0xbf245c: add             x1, x1, HEAP, lsl #32
    // 0xbf2460: ldr             x2, [fp, #0x18]
    // 0xbf2464: LoadField: r3 = r2->field_17
    //     0xbf2464: ldur            w3, [x2, #0x17]
    // 0xbf2468: DecompressPointer r3
    //     0xbf2468: add             x3, x3, HEAP, lsl #32
    // 0xbf246c: stp             x3, x1, [SP, #-0x10]!
    // 0xbf2470: ldur            x16, [fp, #-8]
    // 0xbf2474: SaveReg r16
    //     0xbf2474: str             x16, [SP, #-8]!
    // 0xbf2478: r0 = lerp()
    //     0xbf2478: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf247c: add             SP, SP, #0x18
    // 0xbf2480: mov             x1, x0
    // 0xbf2484: ldr             x0, [fp, #0x20]
    // 0xbf2488: stur            x1, [fp, #-0x20]
    // 0xbf248c: LoadField: r2 = r0->field_1b
    //     0xbf248c: ldur            w2, [x0, #0x1b]
    // 0xbf2490: DecompressPointer r2
    //     0xbf2490: add             x2, x2, HEAP, lsl #32
    // 0xbf2494: ldr             x3, [fp, #0x18]
    // 0xbf2498: LoadField: r4 = r3->field_1b
    //     0xbf2498: ldur            w4, [x3, #0x1b]
    // 0xbf249c: DecompressPointer r4
    //     0xbf249c: add             x4, x4, HEAP, lsl #32
    // 0xbf24a0: stp             x4, x2, [SP, #-0x10]!
    // 0xbf24a4: ldur            x16, [fp, #-8]
    // 0xbf24a8: SaveReg r16
    //     0xbf24a8: str             x16, [SP, #-8]!
    // 0xbf24ac: r0 = lerp()
    //     0xbf24ac: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf24b0: add             SP, SP, #0x18
    // 0xbf24b4: mov             x1, x0
    // 0xbf24b8: ldr             x0, [fp, #0x20]
    // 0xbf24bc: stur            x1, [fp, #-0x28]
    // 0xbf24c0: LoadField: r2 = r0->field_1f
    //     0xbf24c0: ldur            w2, [x0, #0x1f]
    // 0xbf24c4: DecompressPointer r2
    //     0xbf24c4: add             x2, x2, HEAP, lsl #32
    // 0xbf24c8: ldr             x3, [fp, #0x18]
    // 0xbf24cc: LoadField: r4 = r3->field_1f
    //     0xbf24cc: ldur            w4, [x3, #0x1f]
    // 0xbf24d0: DecompressPointer r4
    //     0xbf24d0: add             x4, x4, HEAP, lsl #32
    // 0xbf24d4: stp             x4, x2, [SP, #-0x10]!
    // 0xbf24d8: ldur            x16, [fp, #-8]
    // 0xbf24dc: SaveReg r16
    //     0xbf24dc: str             x16, [SP, #-8]!
    // 0xbf24e0: r0 = lerp()
    //     0xbf24e0: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf24e4: add             SP, SP, #0x18
    // 0xbf24e8: mov             x1, x0
    // 0xbf24ec: ldr             x0, [fp, #0x20]
    // 0xbf24f0: stur            x1, [fp, #-0x30]
    // 0xbf24f4: LoadField: r2 = r0->field_23
    //     0xbf24f4: ldur            w2, [x0, #0x23]
    // 0xbf24f8: DecompressPointer r2
    //     0xbf24f8: add             x2, x2, HEAP, lsl #32
    // 0xbf24fc: ldr             x3, [fp, #0x18]
    // 0xbf2500: LoadField: r4 = r3->field_23
    //     0xbf2500: ldur            w4, [x3, #0x23]
    // 0xbf2504: DecompressPointer r4
    //     0xbf2504: add             x4, x4, HEAP, lsl #32
    // 0xbf2508: stp             x4, x2, [SP, #-0x10]!
    // 0xbf250c: ldur            x16, [fp, #-8]
    // 0xbf2510: SaveReg r16
    //     0xbf2510: str             x16, [SP, #-8]!
    // 0xbf2514: r0 = lerp()
    //     0xbf2514: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2518: add             SP, SP, #0x18
    // 0xbf251c: mov             x1, x0
    // 0xbf2520: ldr             x0, [fp, #0x20]
    // 0xbf2524: stur            x1, [fp, #-0x38]
    // 0xbf2528: LoadField: r2 = r0->field_27
    //     0xbf2528: ldur            w2, [x0, #0x27]
    // 0xbf252c: DecompressPointer r2
    //     0xbf252c: add             x2, x2, HEAP, lsl #32
    // 0xbf2530: ldr             x3, [fp, #0x18]
    // 0xbf2534: LoadField: r4 = r3->field_27
    //     0xbf2534: ldur            w4, [x3, #0x27]
    // 0xbf2538: DecompressPointer r4
    //     0xbf2538: add             x4, x4, HEAP, lsl #32
    // 0xbf253c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2540: ldur            x16, [fp, #-8]
    // 0xbf2544: SaveReg r16
    //     0xbf2544: str             x16, [SP, #-8]!
    // 0xbf2548: r0 = lerp()
    //     0xbf2548: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf254c: add             SP, SP, #0x18
    // 0xbf2550: mov             x1, x0
    // 0xbf2554: ldr             x0, [fp, #0x20]
    // 0xbf2558: stur            x1, [fp, #-8]
    // 0xbf255c: LoadField: r2 = r0->field_2b
    //     0xbf255c: ldur            w2, [x0, #0x2b]
    // 0xbf2560: DecompressPointer r2
    //     0xbf2560: add             x2, x2, HEAP, lsl #32
    // 0xbf2564: ldr             x0, [fp, #0x18]
    // 0xbf2568: LoadField: r3 = r0->field_2b
    //     0xbf2568: ldur            w3, [x0, #0x2b]
    // 0xbf256c: DecompressPointer r3
    //     0xbf256c: add             x3, x3, HEAP, lsl #32
    // 0xbf2570: r16 = <Color?>
    //     0xbf2570: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf2574: ldr             x16, [x16, #0xf68]
    // 0xbf2578: stp             x2, x16, [SP, #-0x10]!
    // 0xbf257c: SaveReg r3
    //     0xbf257c: str             x3, [SP, #-8]!
    // 0xbf2580: ldr             d0, [fp, #0x10]
    // 0xbf2584: SaveReg d0
    //     0xbf2584: str             d0, [SP, #-8]!
    // 0xbf2588: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf2588: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf258c: ldr             x16, [x16, #0xb80]
    // 0xbf2590: SaveReg r16
    //     0xbf2590: str             x16, [SP, #-8]!
    // 0xbf2594: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf2594: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf2598: r0 = lerp()
    //     0xbf2598: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf259c: add             SP, SP, #0x28
    // 0xbf25a0: stur            x0, [fp, #-0x40]
    // 0xbf25a4: r0 = TabBarTheme()
    //     0xbf25a4: bl              #0x89fc20  ; AllocateTabBarThemeStub -> TabBarTheme (size=0x38)
    // 0xbf25a8: ldur            x1, [fp, #-0x10]
    // 0xbf25ac: StoreField: r0->field_7 = r1
    //     0xbf25ac: stur            w1, [x0, #7]
    // 0xbf25b0: ldur            x1, [fp, #-0x18]
    // 0xbf25b4: StoreField: r0->field_f = r1
    //     0xbf25b4: stur            w1, [x0, #0xf]
    // 0xbf25b8: ldur            x1, [fp, #-0x20]
    // 0xbf25bc: StoreField: r0->field_17 = r1
    //     0xbf25bc: stur            w1, [x0, #0x17]
    // 0xbf25c0: ldur            x1, [fp, #-0x28]
    // 0xbf25c4: StoreField: r0->field_1b = r1
    //     0xbf25c4: stur            w1, [x0, #0x1b]
    // 0xbf25c8: ldur            x1, [fp, #-0x30]
    // 0xbf25cc: StoreField: r0->field_1f = r1
    //     0xbf25cc: stur            w1, [x0, #0x1f]
    // 0xbf25d0: ldur            x1, [fp, #-0x38]
    // 0xbf25d4: StoreField: r0->field_23 = r1
    //     0xbf25d4: stur            w1, [x0, #0x23]
    // 0xbf25d8: ldur            x1, [fp, #-8]
    // 0xbf25dc: StoreField: r0->field_27 = r1
    //     0xbf25dc: stur            w1, [x0, #0x27]
    // 0xbf25e0: ldur            x1, [fp, #-0x40]
    // 0xbf25e4: StoreField: r0->field_2b = r1
    //     0xbf25e4: stur            w1, [x0, #0x2b]
    // 0xbf25e8: LeaveFrame
    //     0xbf25e8: mov             SP, fp
    //     0xbf25ec: ldp             fp, lr, [SP], #0x10
    // 0xbf25f0: ret
    //     0xbf25f0: ret             
    // 0xbf25f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf25f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf25f8: b               #0xbf2388
    // 0xbf25fc: SaveReg d0
    //     0xbf25fc: str             q0, [SP, #-0x10]!
    // 0xbf2600: SaveReg r0
    //     0xbf2600: str             x0, [SP, #-8]!
    // 0xbf2604: r0 = AllocateDouble()
    //     0xbf2604: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf2608: mov             x1, x0
    // 0xbf260c: RestoreReg r0
    //     0xbf260c: ldr             x0, [SP], #8
    // 0xbf2610: RestoreReg d0
    //     0xbf2610: ldr             q0, [SP], #0x10
    // 0xbf2614: b               #0xbf23e0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8f288, size: 0xba0
    // 0xc8f288: EnterFrame
    //     0xc8f288: stp             fp, lr, [SP, #-0x10]!
    //     0xc8f28c: mov             fp, SP
    // 0xc8f290: AllocStack(0x18)
    //     0xc8f290: sub             SP, SP, #0x18
    // 0xc8f294: CheckStackOverflow
    //     0xc8f294: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8f298: cmp             SP, x16
    //     0xc8f29c: b.ls            #0xc8fe10
    // 0xc8f2a0: ldr             x1, [fp, #0x10]
    // 0xc8f2a4: cmp             w1, NULL
    // 0xc8f2a8: b.ne            #0xc8f2bc
    // 0xc8f2ac: r0 = false
    //     0xc8f2ac: add             x0, NULL, #0x30  ; false
    // 0xc8f2b0: LeaveFrame
    //     0xc8f2b0: mov             SP, fp
    //     0xc8f2b4: ldp             fp, lr, [SP], #0x10
    // 0xc8f2b8: ret
    //     0xc8f2b8: ret             
    // 0xc8f2bc: ldr             x2, [fp, #0x18]
    // 0xc8f2c0: cmp             w2, w1
    // 0xc8f2c4: b.ne            #0xc8f2d8
    // 0xc8f2c8: r0 = true
    //     0xc8f2c8: add             x0, NULL, #0x20  ; true
    // 0xc8f2cc: LeaveFrame
    //     0xc8f2cc: mov             SP, fp
    //     0xc8f2d0: ldp             fp, lr, [SP], #0x10
    // 0xc8f2d4: ret
    //     0xc8f2d4: ret             
    // 0xc8f2d8: r0 = 59
    //     0xc8f2d8: mov             x0, #0x3b
    // 0xc8f2dc: branchIfSmi(r1, 0xc8f2e8)
    //     0xc8f2dc: tbz             w1, #0, #0xc8f2e8
    // 0xc8f2e0: r0 = LoadClassIdInstr(r1)
    //     0xc8f2e0: ldur            x0, [x1, #-1]
    //     0xc8f2e4: ubfx            x0, x0, #0xc, #0x14
    // 0xc8f2e8: SaveReg r1
    //     0xc8f2e8: str             x1, [SP, #-8]!
    // 0xc8f2ec: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8f2ec: mov             x17, #0x57c5
    //     0xc8f2f0: add             lr, x0, x17
    //     0xc8f2f4: ldr             lr, [x21, lr, lsl #3]
    //     0xc8f2f8: blr             lr
    // 0xc8f2fc: add             SP, SP, #8
    // 0xc8f300: stur            x0, [fp, #-8]
    // 0xc8f304: ldr             x16, [fp, #0x18]
    // 0xc8f308: SaveReg r16
    //     0xc8f308: str             x16, [SP, #-8]!
    // 0xc8f30c: r0 = runtimeType()
    //     0xc8f30c: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc8f310: add             SP, SP, #8
    // 0xc8f314: mov             x1, x0
    // 0xc8f318: ldur            x0, [fp, #-8]
    // 0xc8f31c: r2 = LoadClassIdInstr(r0)
    //     0xc8f31c: ldur            x2, [x0, #-1]
    //     0xc8f320: ubfx            x2, x2, #0xc, #0x14
    // 0xc8f324: stp             x1, x0, [SP, #-0x10]!
    // 0xc8f328: mov             x0, x2
    // 0xc8f32c: mov             lr, x0
    // 0xc8f330: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f334: blr             lr
    // 0xc8f338: add             SP, SP, #0x10
    // 0xc8f33c: tbz             w0, #4, #0xc8f350
    // 0xc8f340: r0 = false
    //     0xc8f340: add             x0, NULL, #0x30  ; false
    // 0xc8f344: LeaveFrame
    //     0xc8f344: mov             SP, fp
    //     0xc8f348: ldp             fp, lr, [SP], #0x10
    // 0xc8f34c: ret
    //     0xc8f34c: ret             
    // 0xc8f350: ldr             x0, [fp, #0x10]
    // 0xc8f354: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8f354: mov             x2, #0x76
    //     0xc8f358: tbz             w0, #0, #0xc8f368
    //     0xc8f35c: ldur            x2, [x0, #-1]
    //     0xc8f360: ubfx            x2, x2, #0xc, #0x14
    //     0xc8f364: lsl             x2, x2, #1
    // 0xc8f368: stur            x2, [fp, #-8]
    // 0xc8f36c: r1 = LoadInt32Instr(r2)
    //     0xc8f36c: sbfx            x1, x2, #1, #0x1f
    // 0xc8f370: cmp             x1, #0xaa2
    // 0xc8f374: b.lt            #0xc8fe00
    // 0xc8f378: cmp             x1, #0xaa4
    // 0xc8f37c: b.gt            #0xc8fe00
    // 0xc8f380: ldr             x3, [fp, #0x18]
    // 0xc8f384: LoadField: r1 = r0->field_7
    //     0xc8f384: ldur            w1, [x0, #7]
    // 0xc8f388: DecompressPointer r1
    //     0xc8f388: add             x1, x1, HEAP, lsl #32
    // 0xc8f38c: LoadField: r4 = r3->field_7
    //     0xc8f38c: ldur            w4, [x3, #7]
    // 0xc8f390: DecompressPointer r4
    //     0xc8f390: add             x4, x4, HEAP, lsl #32
    // 0xc8f394: cmp             w1, w4
    // 0xc8f398: b.ne            #0xc8fe00
    // 0xc8f39c: r17 = 5444
    //     0xc8f39c: mov             x17, #0x1544
    // 0xc8f3a0: cmp             w2, w17
    // 0xc8f3a4: b.ne            #0xc8f3bc
    // 0xc8f3a8: LoadField: r1 = r0->field_b
    //     0xc8f3a8: ldur            w1, [x0, #0xb]
    // 0xc8f3ac: DecompressPointer r1
    //     0xc8f3ac: add             x1, x1, HEAP, lsl #32
    // 0xc8f3b0: mov             x2, x1
    // 0xc8f3b4: mov             x0, x3
    // 0xc8f3b8: b               #0xc8f428
    // 0xc8f3bc: r17 = 5446
    //     0xc8f3bc: mov             x17, #0x1546
    // 0xc8f3c0: cmp             w2, w17
    // 0xc8f3c4: b.ne            #0xc8f400
    // 0xc8f3c8: mov             x1, x0
    // 0xc8f3cc: LoadField: r0 = r1->field_3b
    //     0xc8f3cc: ldur            w0, [x1, #0x3b]
    // 0xc8f3d0: DecompressPointer r0
    //     0xc8f3d0: add             x0, x0, HEAP, lsl #32
    // 0xc8f3d4: r16 = Sentinel
    //     0xc8f3d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f3d8: cmp             w0, w16
    // 0xc8f3dc: b.ne            #0xc8f3ec
    // 0xc8f3e0: r2 = _colors
    //     0xc8f3e0: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xc8f3e4: ldr             x2, [x2, #0xf50]
    // 0xc8f3e8: r0 = InitLateFinalInstanceField()
    //     0xc8f3e8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f3ec: LoadField: r1 = r0->field_b
    //     0xc8f3ec: ldur            w1, [x0, #0xb]
    // 0xc8f3f0: DecompressPointer r1
    //     0xc8f3f0: add             x1, x1, HEAP, lsl #32
    // 0xc8f3f4: mov             x2, x1
    // 0xc8f3f8: ldr             x0, [fp, #0x18]
    // 0xc8f3fc: b               #0xc8f428
    // 0xc8f400: mov             x1, x0
    // 0xc8f404: LoadField: r0 = r1->field_37
    //     0xc8f404: ldur            w0, [x1, #0x37]
    // 0xc8f408: DecompressPointer r0
    //     0xc8f408: add             x0, x0, HEAP, lsl #32
    // 0xc8f40c: SaveReg r0
    //     0xc8f40c: str             x0, [SP, #-8]!
    // 0xc8f410: r0 = of()
    //     0xc8f410: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8f414: add             SP, SP, #8
    // 0xc8f418: LoadField: r1 = r0->field_5f
    //     0xc8f418: ldur            w1, [x0, #0x5f]
    // 0xc8f41c: DecompressPointer r1
    //     0xc8f41c: add             x1, x1, HEAP, lsl #32
    // 0xc8f420: mov             x2, x1
    // 0xc8f424: ldr             x0, [fp, #0x18]
    // 0xc8f428: stur            x2, [fp, #-0x18]
    // 0xc8f42c: r3 = LoadClassIdInstr(r0)
    //     0xc8f42c: ldur            x3, [x0, #-1]
    //     0xc8f430: ubfx            x3, x3, #0xc, #0x14
    // 0xc8f434: lsl             x3, x3, #1
    // 0xc8f438: stur            x3, [fp, #-0x10]
    // 0xc8f43c: r17 = 5444
    //     0xc8f43c: mov             x17, #0x1544
    // 0xc8f440: cmp             w3, w17
    // 0xc8f444: b.ne            #0xc8f458
    // 0xc8f448: LoadField: r1 = r0->field_b
    //     0xc8f448: ldur            w1, [x0, #0xb]
    // 0xc8f44c: DecompressPointer r1
    //     0xc8f44c: add             x1, x1, HEAP, lsl #32
    // 0xc8f450: mov             x0, x2
    // 0xc8f454: b               #0xc8f4bc
    // 0xc8f458: r17 = 5446
    //     0xc8f458: mov             x17, #0x1546
    // 0xc8f45c: cmp             w3, w17
    // 0xc8f460: b.ne            #0xc8f498
    // 0xc8f464: mov             x1, x0
    // 0xc8f468: LoadField: r0 = r1->field_3b
    //     0xc8f468: ldur            w0, [x1, #0x3b]
    // 0xc8f46c: DecompressPointer r0
    //     0xc8f46c: add             x0, x0, HEAP, lsl #32
    // 0xc8f470: r16 = Sentinel
    //     0xc8f470: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f474: cmp             w0, w16
    // 0xc8f478: b.ne            #0xc8f488
    // 0xc8f47c: r2 = _colors
    //     0xc8f47c: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xc8f480: ldr             x2, [x2, #0xf50]
    // 0xc8f484: r0 = InitLateFinalInstanceField()
    //     0xc8f484: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f488: LoadField: r1 = r0->field_b
    //     0xc8f488: ldur            w1, [x0, #0xb]
    // 0xc8f48c: DecompressPointer r1
    //     0xc8f48c: add             x1, x1, HEAP, lsl #32
    // 0xc8f490: ldur            x0, [fp, #-0x18]
    // 0xc8f494: b               #0xc8f4bc
    // 0xc8f498: mov             x1, x0
    // 0xc8f49c: LoadField: r0 = r1->field_37
    //     0xc8f49c: ldur            w0, [x1, #0x37]
    // 0xc8f4a0: DecompressPointer r0
    //     0xc8f4a0: add             x0, x0, HEAP, lsl #32
    // 0xc8f4a4: SaveReg r0
    //     0xc8f4a4: str             x0, [SP, #-8]!
    // 0xc8f4a8: r0 = of()
    //     0xc8f4a8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8f4ac: add             SP, SP, #8
    // 0xc8f4b0: LoadField: r1 = r0->field_5f
    //     0xc8f4b0: ldur            w1, [x0, #0x5f]
    // 0xc8f4b4: DecompressPointer r1
    //     0xc8f4b4: add             x1, x1, HEAP, lsl #32
    // 0xc8f4b8: ldur            x0, [fp, #-0x18]
    // 0xc8f4bc: r2 = LoadClassIdInstr(r0)
    //     0xc8f4bc: ldur            x2, [x0, #-1]
    //     0xc8f4c0: ubfx            x2, x2, #0xc, #0x14
    // 0xc8f4c4: stp             x1, x0, [SP, #-0x10]!
    // 0xc8f4c8: mov             x0, x2
    // 0xc8f4cc: mov             lr, x0
    // 0xc8f4d0: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f4d4: blr             lr
    // 0xc8f4d8: add             SP, SP, #0x10
    // 0xc8f4dc: tbnz            w0, #4, #0xc8fe00
    // 0xc8f4e0: ldr             x0, [fp, #0x18]
    // 0xc8f4e4: ldr             x2, [fp, #0x10]
    // 0xc8f4e8: LoadField: r1 = r2->field_f
    //     0xc8f4e8: ldur            w1, [x2, #0xf]
    // 0xc8f4ec: DecompressPointer r1
    //     0xc8f4ec: add             x1, x1, HEAP, lsl #32
    // 0xc8f4f0: LoadField: r3 = r0->field_f
    //     0xc8f4f0: ldur            w3, [x0, #0xf]
    // 0xc8f4f4: DecompressPointer r3
    //     0xc8f4f4: add             x3, x3, HEAP, lsl #32
    // 0xc8f4f8: cmp             w1, w3
    // 0xc8f4fc: b.ne            #0xc8fe00
    // 0xc8f500: ldur            x3, [fp, #-8]
    // 0xc8f504: r17 = 5444
    //     0xc8f504: mov             x17, #0x1544
    // 0xc8f508: cmp             w3, w17
    // 0xc8f50c: b.ne            #0xc8f518
    // 0xc8f510: mov             x0, x2
    // 0xc8f514: b               #0xc8f57c
    // 0xc8f518: r17 = 5446
    //     0xc8f518: mov             x17, #0x1546
    // 0xc8f51c: cmp             w3, w17
    // 0xc8f520: b.ne            #0xc8f578
    // 0xc8f524: mov             x1, x2
    // 0xc8f528: LoadField: r0 = r1->field_3b
    //     0xc8f528: ldur            w0, [x1, #0x3b]
    // 0xc8f52c: DecompressPointer r0
    //     0xc8f52c: add             x0, x0, HEAP, lsl #32
    // 0xc8f530: r16 = Sentinel
    //     0xc8f530: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f534: cmp             w0, w16
    // 0xc8f538: b.ne            #0xc8f548
    // 0xc8f53c: r2 = _colors
    //     0xc8f53c: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xc8f540: ldr             x2, [x2, #0xf50]
    // 0xc8f544: r0 = InitLateFinalInstanceField()
    //     0xc8f544: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f548: LoadField: r1 = r0->field_5b
    //     0xc8f548: ldur            w1, [x0, #0x5b]
    // 0xc8f54c: DecompressPointer r1
    //     0xc8f54c: add             x1, x1, HEAP, lsl #32
    // 0xc8f550: cmp             w1, NULL
    // 0xc8f554: b.ne            #0xc8f568
    // 0xc8f558: LoadField: r1 = r0->field_53
    //     0xc8f558: ldur            w1, [x0, #0x53]
    // 0xc8f55c: DecompressPointer r1
    //     0xc8f55c: add             x1, x1, HEAP, lsl #32
    // 0xc8f560: mov             x0, x1
    // 0xc8f564: b               #0xc8f56c
    // 0xc8f568: mov             x0, x1
    // 0xc8f56c: mov             x3, x0
    // 0xc8f570: ldr             x0, [fp, #0x10]
    // 0xc8f574: b               #0xc8f588
    // 0xc8f578: ldr             x0, [fp, #0x10]
    // 0xc8f57c: LoadField: r1 = r0->field_13
    //     0xc8f57c: ldur            w1, [x0, #0x13]
    // 0xc8f580: DecompressPointer r1
    //     0xc8f580: add             x1, x1, HEAP, lsl #32
    // 0xc8f584: mov             x3, x1
    // 0xc8f588: ldur            x2, [fp, #-0x10]
    // 0xc8f58c: stur            x3, [fp, #-0x18]
    // 0xc8f590: r17 = 5444
    //     0xc8f590: mov             x17, #0x1544
    // 0xc8f594: cmp             w2, w17
    // 0xc8f598: b.eq            #0xc8f5fc
    // 0xc8f59c: r17 = 5446
    //     0xc8f59c: mov             x17, #0x1546
    // 0xc8f5a0: cmp             w2, w17
    // 0xc8f5a4: b.ne            #0xc8f5fc
    // 0xc8f5a8: ldr             x1, [fp, #0x18]
    // 0xc8f5ac: LoadField: r0 = r1->field_3b
    //     0xc8f5ac: ldur            w0, [x1, #0x3b]
    // 0xc8f5b0: DecompressPointer r0
    //     0xc8f5b0: add             x0, x0, HEAP, lsl #32
    // 0xc8f5b4: r16 = Sentinel
    //     0xc8f5b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f5b8: cmp             w0, w16
    // 0xc8f5bc: b.ne            #0xc8f5cc
    // 0xc8f5c0: r2 = _colors
    //     0xc8f5c0: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xc8f5c4: ldr             x2, [x2, #0xf50]
    // 0xc8f5c8: r0 = InitLateFinalInstanceField()
    //     0xc8f5c8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f5cc: LoadField: r1 = r0->field_5b
    //     0xc8f5cc: ldur            w1, [x0, #0x5b]
    // 0xc8f5d0: DecompressPointer r1
    //     0xc8f5d0: add             x1, x1, HEAP, lsl #32
    // 0xc8f5d4: cmp             w1, NULL
    // 0xc8f5d8: b.ne            #0xc8f5ec
    // 0xc8f5dc: LoadField: r1 = r0->field_53
    //     0xc8f5dc: ldur            w1, [x0, #0x53]
    // 0xc8f5e0: DecompressPointer r1
    //     0xc8f5e0: add             x1, x1, HEAP, lsl #32
    // 0xc8f5e4: mov             x0, x1
    // 0xc8f5e8: b               #0xc8f5f0
    // 0xc8f5ec: mov             x0, x1
    // 0xc8f5f0: mov             x2, x0
    // 0xc8f5f4: ldr             x1, [fp, #0x18]
    // 0xc8f5f8: b               #0xc8f60c
    // 0xc8f5fc: ldr             x1, [fp, #0x18]
    // 0xc8f600: LoadField: r0 = r1->field_13
    //     0xc8f600: ldur            w0, [x1, #0x13]
    // 0xc8f604: DecompressPointer r0
    //     0xc8f604: add             x0, x0, HEAP, lsl #32
    // 0xc8f608: mov             x2, x0
    // 0xc8f60c: ldur            x0, [fp, #-0x18]
    // 0xc8f610: r3 = LoadClassIdInstr(r0)
    //     0xc8f610: ldur            x3, [x0, #-1]
    //     0xc8f614: ubfx            x3, x3, #0xc, #0x14
    // 0xc8f618: stp             x2, x0, [SP, #-0x10]!
    // 0xc8f61c: mov             x0, x3
    // 0xc8f620: mov             lr, x0
    // 0xc8f624: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f628: blr             lr
    // 0xc8f62c: add             SP, SP, #0x10
    // 0xc8f630: tbnz            w0, #4, #0xc8fe00
    // 0xc8f634: ldur            x0, [fp, #-8]
    // 0xc8f638: r17 = 5444
    //     0xc8f638: mov             x17, #0x1544
    // 0xc8f63c: cmp             w0, w17
    // 0xc8f640: b.ne            #0xc8f658
    // 0xc8f644: ldr             x2, [fp, #0x10]
    // 0xc8f648: LoadField: r1 = r2->field_17
    //     0xc8f648: ldur            w1, [x2, #0x17]
    // 0xc8f64c: DecompressPointer r1
    //     0xc8f64c: add             x1, x1, HEAP, lsl #32
    // 0xc8f650: mov             x2, x1
    // 0xc8f654: b               #0xc8f6e0
    // 0xc8f658: ldr             x2, [fp, #0x10]
    // 0xc8f65c: r17 = 5446
    //     0xc8f65c: mov             x17, #0x1546
    // 0xc8f660: cmp             w0, w17
    // 0xc8f664: b.ne            #0xc8f69c
    // 0xc8f668: mov             x1, x2
    // 0xc8f66c: LoadField: r0 = r1->field_3b
    //     0xc8f66c: ldur            w0, [x1, #0x3b]
    // 0xc8f670: DecompressPointer r0
    //     0xc8f670: add             x0, x0, HEAP, lsl #32
    // 0xc8f674: r16 = Sentinel
    //     0xc8f674: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f678: cmp             w0, w16
    // 0xc8f67c: b.ne            #0xc8f68c
    // 0xc8f680: r2 = _colors
    //     0xc8f680: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xc8f684: ldr             x2, [x2, #0xf50]
    // 0xc8f688: r0 = InitLateFinalInstanceField()
    //     0xc8f688: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f68c: LoadField: r1 = r0->field_b
    //     0xc8f68c: ldur            w1, [x0, #0xb]
    // 0xc8f690: DecompressPointer r1
    //     0xc8f690: add             x1, x1, HEAP, lsl #32
    // 0xc8f694: mov             x2, x1
    // 0xc8f698: b               #0xc8f6e0
    // 0xc8f69c: mov             x1, x2
    // 0xc8f6a0: LoadField: r0 = r1->field_37
    //     0xc8f6a0: ldur            w0, [x1, #0x37]
    // 0xc8f6a4: DecompressPointer r0
    //     0xc8f6a4: add             x0, x0, HEAP, lsl #32
    // 0xc8f6a8: SaveReg r0
    //     0xc8f6a8: str             x0, [SP, #-8]!
    // 0xc8f6ac: r0 = of()
    //     0xc8f6ac: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8f6b0: add             SP, SP, #8
    // 0xc8f6b4: LoadField: r1 = r0->field_8f
    //     0xc8f6b4: ldur            w1, [x0, #0x8f]
    // 0xc8f6b8: DecompressPointer r1
    //     0xc8f6b8: add             x1, x1, HEAP, lsl #32
    // 0xc8f6bc: LoadField: r0 = r1->field_2b
    //     0xc8f6bc: ldur            w0, [x1, #0x2b]
    // 0xc8f6c0: DecompressPointer r0
    //     0xc8f6c0: add             x0, x0, HEAP, lsl #32
    // 0xc8f6c4: cmp             w0, NULL
    // 0xc8f6c8: b.eq            #0xc8fe18
    // 0xc8f6cc: LoadField: r1 = r0->field_b
    //     0xc8f6cc: ldur            w1, [x0, #0xb]
    // 0xc8f6d0: DecompressPointer r1
    //     0xc8f6d0: add             x1, x1, HEAP, lsl #32
    // 0xc8f6d4: cmp             w1, NULL
    // 0xc8f6d8: b.eq            #0xc8fe1c
    // 0xc8f6dc: mov             x2, x1
    // 0xc8f6e0: ldur            x0, [fp, #-0x10]
    // 0xc8f6e4: stur            x2, [fp, #-0x18]
    // 0xc8f6e8: r17 = 5444
    //     0xc8f6e8: mov             x17, #0x1544
    // 0xc8f6ec: cmp             w0, w17
    // 0xc8f6f0: b.ne            #0xc8f708
    // 0xc8f6f4: ldr             x3, [fp, #0x18]
    // 0xc8f6f8: LoadField: r1 = r3->field_17
    //     0xc8f6f8: ldur            w1, [x3, #0x17]
    // 0xc8f6fc: DecompressPointer r1
    //     0xc8f6fc: add             x1, x1, HEAP, lsl #32
    // 0xc8f700: mov             x0, x2
    // 0xc8f704: b               #0xc8f790
    // 0xc8f708: ldr             x3, [fp, #0x18]
    // 0xc8f70c: r17 = 5446
    //     0xc8f70c: mov             x17, #0x1546
    // 0xc8f710: cmp             w0, w17
    // 0xc8f714: b.ne            #0xc8f74c
    // 0xc8f718: mov             x1, x3
    // 0xc8f71c: LoadField: r0 = r1->field_3b
    //     0xc8f71c: ldur            w0, [x1, #0x3b]
    // 0xc8f720: DecompressPointer r0
    //     0xc8f720: add             x0, x0, HEAP, lsl #32
    // 0xc8f724: r16 = Sentinel
    //     0xc8f724: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f728: cmp             w0, w16
    // 0xc8f72c: b.ne            #0xc8f73c
    // 0xc8f730: r2 = _colors
    //     0xc8f730: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xc8f734: ldr             x2, [x2, #0xf50]
    // 0xc8f738: r0 = InitLateFinalInstanceField()
    //     0xc8f738: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f73c: LoadField: r1 = r0->field_b
    //     0xc8f73c: ldur            w1, [x0, #0xb]
    // 0xc8f740: DecompressPointer r1
    //     0xc8f740: add             x1, x1, HEAP, lsl #32
    // 0xc8f744: ldur            x0, [fp, #-0x18]
    // 0xc8f748: b               #0xc8f790
    // 0xc8f74c: mov             x1, x3
    // 0xc8f750: LoadField: r0 = r1->field_37
    //     0xc8f750: ldur            w0, [x1, #0x37]
    // 0xc8f754: DecompressPointer r0
    //     0xc8f754: add             x0, x0, HEAP, lsl #32
    // 0xc8f758: SaveReg r0
    //     0xc8f758: str             x0, [SP, #-8]!
    // 0xc8f75c: r0 = of()
    //     0xc8f75c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8f760: add             SP, SP, #8
    // 0xc8f764: LoadField: r1 = r0->field_8f
    //     0xc8f764: ldur            w1, [x0, #0x8f]
    // 0xc8f768: DecompressPointer r1
    //     0xc8f768: add             x1, x1, HEAP, lsl #32
    // 0xc8f76c: LoadField: r0 = r1->field_2b
    //     0xc8f76c: ldur            w0, [x1, #0x2b]
    // 0xc8f770: DecompressPointer r0
    //     0xc8f770: add             x0, x0, HEAP, lsl #32
    // 0xc8f774: cmp             w0, NULL
    // 0xc8f778: b.eq            #0xc8fe20
    // 0xc8f77c: LoadField: r1 = r0->field_b
    //     0xc8f77c: ldur            w1, [x0, #0xb]
    // 0xc8f780: DecompressPointer r1
    //     0xc8f780: add             x1, x1, HEAP, lsl #32
    // 0xc8f784: cmp             w1, NULL
    // 0xc8f788: b.eq            #0xc8fe24
    // 0xc8f78c: ldur            x0, [fp, #-0x18]
    // 0xc8f790: r2 = LoadClassIdInstr(r0)
    //     0xc8f790: ldur            x2, [x0, #-1]
    //     0xc8f794: ubfx            x2, x2, #0xc, #0x14
    // 0xc8f798: stp             x1, x0, [SP, #-0x10]!
    // 0xc8f79c: mov             x0, x2
    // 0xc8f7a0: mov             lr, x0
    // 0xc8f7a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f7a8: blr             lr
    // 0xc8f7ac: add             SP, SP, #0x10
    // 0xc8f7b0: tbnz            w0, #4, #0xc8fe00
    // 0xc8f7b4: ldr             x1, [fp, #0x18]
    // 0xc8f7b8: ldr             x2, [fp, #0x10]
    // 0xc8f7bc: LoadField: r0 = r2->field_1b
    //     0xc8f7bc: ldur            w0, [x2, #0x1b]
    // 0xc8f7c0: DecompressPointer r0
    //     0xc8f7c0: add             x0, x0, HEAP, lsl #32
    // 0xc8f7c4: LoadField: r3 = r1->field_1b
    //     0xc8f7c4: ldur            w3, [x1, #0x1b]
    // 0xc8f7c8: DecompressPointer r3
    //     0xc8f7c8: add             x3, x3, HEAP, lsl #32
    // 0xc8f7cc: r4 = LoadClassIdInstr(r0)
    //     0xc8f7cc: ldur            x4, [x0, #-1]
    //     0xc8f7d0: ubfx            x4, x4, #0xc, #0x14
    // 0xc8f7d4: stp             x3, x0, [SP, #-0x10]!
    // 0xc8f7d8: mov             x0, x4
    // 0xc8f7dc: mov             lr, x0
    // 0xc8f7e0: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f7e4: blr             lr
    // 0xc8f7e8: add             SP, SP, #0x10
    // 0xc8f7ec: tbnz            w0, #4, #0xc8fe00
    // 0xc8f7f0: ldur            x0, [fp, #-8]
    // 0xc8f7f4: r17 = 5444
    //     0xc8f7f4: mov             x17, #0x1544
    // 0xc8f7f8: cmp             w0, w17
    // 0xc8f7fc: b.ne            #0xc8f814
    // 0xc8f800: ldr             x2, [fp, #0x10]
    // 0xc8f804: LoadField: r1 = r2->field_1f
    //     0xc8f804: ldur            w1, [x2, #0x1f]
    // 0xc8f808: DecompressPointer r1
    //     0xc8f808: add             x1, x1, HEAP, lsl #32
    // 0xc8f80c: mov             x2, x1
    // 0xc8f810: b               #0xc8f884
    // 0xc8f814: ldr             x2, [fp, #0x10]
    // 0xc8f818: r17 = 5446
    //     0xc8f818: mov             x17, #0x1546
    // 0xc8f81c: cmp             w0, w17
    // 0xc8f820: b.ne            #0xc8f858
    // 0xc8f824: mov             x1, x2
    // 0xc8f828: LoadField: r0 = r1->field_3f
    //     0xc8f828: ldur            w0, [x1, #0x3f]
    // 0xc8f82c: DecompressPointer r0
    //     0xc8f82c: add             x0, x0, HEAP, lsl #32
    // 0xc8f830: r16 = Sentinel
    //     0xc8f830: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f834: cmp             w0, w16
    // 0xc8f838: b.ne            #0xc8f848
    // 0xc8f83c: r2 = _textTheme
    //     0xc8f83c: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf58] Field <_TabsDefaultsM3@472014024._textTheme@472014024>: late final (offset: 0x40)
    //     0xc8f840: ldr             x2, [x2, #0xf58]
    // 0xc8f844: r0 = InitLateFinalInstanceField()
    //     0xc8f844: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f848: LoadField: r1 = r0->field_27
    //     0xc8f848: ldur            w1, [x0, #0x27]
    // 0xc8f84c: DecompressPointer r1
    //     0xc8f84c: add             x1, x1, HEAP, lsl #32
    // 0xc8f850: mov             x2, x1
    // 0xc8f854: b               #0xc8f884
    // 0xc8f858: mov             x1, x2
    // 0xc8f85c: LoadField: r0 = r1->field_37
    //     0xc8f85c: ldur            w0, [x1, #0x37]
    // 0xc8f860: DecompressPointer r0
    //     0xc8f860: add             x0, x0, HEAP, lsl #32
    // 0xc8f864: SaveReg r0
    //     0xc8f864: str             x0, [SP, #-8]!
    // 0xc8f868: r0 = of()
    //     0xc8f868: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8f86c: add             SP, SP, #8
    // 0xc8f870: LoadField: r1 = r0->field_8f
    //     0xc8f870: ldur            w1, [x0, #0x8f]
    // 0xc8f874: DecompressPointer r1
    //     0xc8f874: add             x1, x1, HEAP, lsl #32
    // 0xc8f878: LoadField: r0 = r1->field_2b
    //     0xc8f878: ldur            w0, [x1, #0x2b]
    // 0xc8f87c: DecompressPointer r0
    //     0xc8f87c: add             x0, x0, HEAP, lsl #32
    // 0xc8f880: mov             x2, x0
    // 0xc8f884: ldur            x0, [fp, #-0x10]
    // 0xc8f888: stur            x2, [fp, #-0x18]
    // 0xc8f88c: r17 = 5444
    //     0xc8f88c: mov             x17, #0x1544
    // 0xc8f890: cmp             w0, w17
    // 0xc8f894: b.ne            #0xc8f8ac
    // 0xc8f898: ldr             x3, [fp, #0x18]
    // 0xc8f89c: LoadField: r1 = r3->field_1f
    //     0xc8f89c: ldur            w1, [x3, #0x1f]
    // 0xc8f8a0: DecompressPointer r1
    //     0xc8f8a0: add             x1, x1, HEAP, lsl #32
    // 0xc8f8a4: mov             x0, x2
    // 0xc8f8a8: b               #0xc8f920
    // 0xc8f8ac: ldr             x3, [fp, #0x18]
    // 0xc8f8b0: r17 = 5446
    //     0xc8f8b0: mov             x17, #0x1546
    // 0xc8f8b4: cmp             w0, w17
    // 0xc8f8b8: b.ne            #0xc8f8f0
    // 0xc8f8bc: mov             x1, x3
    // 0xc8f8c0: LoadField: r0 = r1->field_3f
    //     0xc8f8c0: ldur            w0, [x1, #0x3f]
    // 0xc8f8c4: DecompressPointer r0
    //     0xc8f8c4: add             x0, x0, HEAP, lsl #32
    // 0xc8f8c8: r16 = Sentinel
    //     0xc8f8c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f8cc: cmp             w0, w16
    // 0xc8f8d0: b.ne            #0xc8f8e0
    // 0xc8f8d4: r2 = _textTheme
    //     0xc8f8d4: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf58] Field <_TabsDefaultsM3@472014024._textTheme@472014024>: late final (offset: 0x40)
    //     0xc8f8d8: ldr             x2, [x2, #0xf58]
    // 0xc8f8dc: r0 = InitLateFinalInstanceField()
    //     0xc8f8dc: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f8e0: LoadField: r1 = r0->field_27
    //     0xc8f8e0: ldur            w1, [x0, #0x27]
    // 0xc8f8e4: DecompressPointer r1
    //     0xc8f8e4: add             x1, x1, HEAP, lsl #32
    // 0xc8f8e8: ldur            x0, [fp, #-0x18]
    // 0xc8f8ec: b               #0xc8f920
    // 0xc8f8f0: mov             x1, x3
    // 0xc8f8f4: LoadField: r0 = r1->field_37
    //     0xc8f8f4: ldur            w0, [x1, #0x37]
    // 0xc8f8f8: DecompressPointer r0
    //     0xc8f8f8: add             x0, x0, HEAP, lsl #32
    // 0xc8f8fc: SaveReg r0
    //     0xc8f8fc: str             x0, [SP, #-8]!
    // 0xc8f900: r0 = of()
    //     0xc8f900: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8f904: add             SP, SP, #8
    // 0xc8f908: LoadField: r1 = r0->field_8f
    //     0xc8f908: ldur            w1, [x0, #0x8f]
    // 0xc8f90c: DecompressPointer r1
    //     0xc8f90c: add             x1, x1, HEAP, lsl #32
    // 0xc8f910: LoadField: r0 = r1->field_2b
    //     0xc8f910: ldur            w0, [x1, #0x2b]
    // 0xc8f914: DecompressPointer r0
    //     0xc8f914: add             x0, x0, HEAP, lsl #32
    // 0xc8f918: mov             x1, x0
    // 0xc8f91c: ldur            x0, [fp, #-0x18]
    // 0xc8f920: r2 = LoadClassIdInstr(r0)
    //     0xc8f920: ldur            x2, [x0, #-1]
    //     0xc8f924: ubfx            x2, x2, #0xc, #0x14
    // 0xc8f928: stp             x1, x0, [SP, #-0x10]!
    // 0xc8f92c: mov             x0, x2
    // 0xc8f930: mov             lr, x0
    // 0xc8f934: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f938: blr             lr
    // 0xc8f93c: add             SP, SP, #0x10
    // 0xc8f940: tbnz            w0, #4, #0xc8fe00
    // 0xc8f944: ldur            x0, [fp, #-8]
    // 0xc8f948: r17 = 5444
    //     0xc8f948: mov             x17, #0x1544
    // 0xc8f94c: cmp             w0, w17
    // 0xc8f950: b.eq            #0xc8f9b4
    // 0xc8f954: r17 = 5446
    //     0xc8f954: mov             x17, #0x1546
    // 0xc8f958: cmp             w0, w17
    // 0xc8f95c: b.ne            #0xc8f9b4
    // 0xc8f960: ldr             x1, [fp, #0x10]
    // 0xc8f964: LoadField: r0 = r1->field_3b
    //     0xc8f964: ldur            w0, [x1, #0x3b]
    // 0xc8f968: DecompressPointer r0
    //     0xc8f968: add             x0, x0, HEAP, lsl #32
    // 0xc8f96c: r16 = Sentinel
    //     0xc8f96c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f970: cmp             w0, w16
    // 0xc8f974: b.ne            #0xc8f984
    // 0xc8f978: r2 = _colors
    //     0xc8f978: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xc8f97c: ldr             x2, [x2, #0xf50]
    // 0xc8f980: r0 = InitLateFinalInstanceField()
    //     0xc8f980: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8f984: LoadField: r1 = r0->field_5f
    //     0xc8f984: ldur            w1, [x0, #0x5f]
    // 0xc8f988: DecompressPointer r1
    //     0xc8f988: add             x1, x1, HEAP, lsl #32
    // 0xc8f98c: cmp             w1, NULL
    // 0xc8f990: b.ne            #0xc8f9a4
    // 0xc8f994: LoadField: r1 = r0->field_57
    //     0xc8f994: ldur            w1, [x0, #0x57]
    // 0xc8f998: DecompressPointer r1
    //     0xc8f998: add             x1, x1, HEAP, lsl #32
    // 0xc8f99c: mov             x0, x1
    // 0xc8f9a0: b               #0xc8f9a8
    // 0xc8f9a4: mov             x0, x1
    // 0xc8f9a8: mov             x3, x0
    // 0xc8f9ac: ldr             x0, [fp, #0x10]
    // 0xc8f9b0: b               #0xc8f9c4
    // 0xc8f9b4: ldr             x0, [fp, #0x10]
    // 0xc8f9b8: LoadField: r1 = r0->field_23
    //     0xc8f9b8: ldur            w1, [x0, #0x23]
    // 0xc8f9bc: DecompressPointer r1
    //     0xc8f9bc: add             x1, x1, HEAP, lsl #32
    // 0xc8f9c0: mov             x3, x1
    // 0xc8f9c4: ldur            x2, [fp, #-0x10]
    // 0xc8f9c8: stur            x3, [fp, #-0x18]
    // 0xc8f9cc: r17 = 5444
    //     0xc8f9cc: mov             x17, #0x1544
    // 0xc8f9d0: cmp             w2, w17
    // 0xc8f9d4: b.eq            #0xc8fa38
    // 0xc8f9d8: r17 = 5446
    //     0xc8f9d8: mov             x17, #0x1546
    // 0xc8f9dc: cmp             w2, w17
    // 0xc8f9e0: b.ne            #0xc8fa38
    // 0xc8f9e4: ldr             x1, [fp, #0x18]
    // 0xc8f9e8: LoadField: r0 = r1->field_3b
    //     0xc8f9e8: ldur            w0, [x1, #0x3b]
    // 0xc8f9ec: DecompressPointer r0
    //     0xc8f9ec: add             x0, x0, HEAP, lsl #32
    // 0xc8f9f0: r16 = Sentinel
    //     0xc8f9f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8f9f4: cmp             w0, w16
    // 0xc8f9f8: b.ne            #0xc8fa08
    // 0xc8f9fc: r2 = _colors
    //     0xc8f9fc: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xc8fa00: ldr             x2, [x2, #0xf50]
    // 0xc8fa04: r0 = InitLateFinalInstanceField()
    //     0xc8fa04: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8fa08: LoadField: r1 = r0->field_5f
    //     0xc8fa08: ldur            w1, [x0, #0x5f]
    // 0xc8fa0c: DecompressPointer r1
    //     0xc8fa0c: add             x1, x1, HEAP, lsl #32
    // 0xc8fa10: cmp             w1, NULL
    // 0xc8fa14: b.ne            #0xc8fa28
    // 0xc8fa18: LoadField: r1 = r0->field_57
    //     0xc8fa18: ldur            w1, [x0, #0x57]
    // 0xc8fa1c: DecompressPointer r1
    //     0xc8fa1c: add             x1, x1, HEAP, lsl #32
    // 0xc8fa20: mov             x0, x1
    // 0xc8fa24: b               #0xc8fa2c
    // 0xc8fa28: mov             x0, x1
    // 0xc8fa2c: mov             x2, x0
    // 0xc8fa30: ldr             x1, [fp, #0x18]
    // 0xc8fa34: b               #0xc8fa48
    // 0xc8fa38: ldr             x1, [fp, #0x18]
    // 0xc8fa3c: LoadField: r0 = r1->field_23
    //     0xc8fa3c: ldur            w0, [x1, #0x23]
    // 0xc8fa40: DecompressPointer r0
    //     0xc8fa40: add             x0, x0, HEAP, lsl #32
    // 0xc8fa44: mov             x2, x0
    // 0xc8fa48: ldur            x0, [fp, #-0x18]
    // 0xc8fa4c: r3 = LoadClassIdInstr(r0)
    //     0xc8fa4c: ldur            x3, [x0, #-1]
    //     0xc8fa50: ubfx            x3, x3, #0xc, #0x14
    // 0xc8fa54: stp             x2, x0, [SP, #-0x10]!
    // 0xc8fa58: mov             x0, x3
    // 0xc8fa5c: mov             lr, x0
    // 0xc8fa60: ldr             lr, [x21, lr, lsl #3]
    // 0xc8fa64: blr             lr
    // 0xc8fa68: add             SP, SP, #0x10
    // 0xc8fa6c: tbnz            w0, #4, #0xc8fe00
    // 0xc8fa70: ldur            x0, [fp, #-8]
    // 0xc8fa74: r17 = 5444
    //     0xc8fa74: mov             x17, #0x1544
    // 0xc8fa78: cmp             w0, w17
    // 0xc8fa7c: b.ne            #0xc8fa94
    // 0xc8fa80: ldr             x2, [fp, #0x10]
    // 0xc8fa84: LoadField: r1 = r2->field_27
    //     0xc8fa84: ldur            w1, [x2, #0x27]
    // 0xc8fa88: DecompressPointer r1
    //     0xc8fa88: add             x1, x1, HEAP, lsl #32
    // 0xc8fa8c: mov             x2, x1
    // 0xc8fa90: b               #0xc8fb04
    // 0xc8fa94: ldr             x2, [fp, #0x10]
    // 0xc8fa98: r17 = 5446
    //     0xc8fa98: mov             x17, #0x1546
    // 0xc8fa9c: cmp             w0, w17
    // 0xc8faa0: b.ne            #0xc8fad8
    // 0xc8faa4: mov             x1, x2
    // 0xc8faa8: LoadField: r0 = r1->field_3f
    //     0xc8faa8: ldur            w0, [x1, #0x3f]
    // 0xc8faac: DecompressPointer r0
    //     0xc8faac: add             x0, x0, HEAP, lsl #32
    // 0xc8fab0: r16 = Sentinel
    //     0xc8fab0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8fab4: cmp             w0, w16
    // 0xc8fab8: b.ne            #0xc8fac8
    // 0xc8fabc: r2 = _textTheme
    //     0xc8fabc: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf58] Field <_TabsDefaultsM3@472014024._textTheme@472014024>: late final (offset: 0x40)
    //     0xc8fac0: ldr             x2, [x2, #0xf58]
    // 0xc8fac4: r0 = InitLateFinalInstanceField()
    //     0xc8fac4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8fac8: LoadField: r1 = r0->field_27
    //     0xc8fac8: ldur            w1, [x0, #0x27]
    // 0xc8facc: DecompressPointer r1
    //     0xc8facc: add             x1, x1, HEAP, lsl #32
    // 0xc8fad0: mov             x2, x1
    // 0xc8fad4: b               #0xc8fb04
    // 0xc8fad8: mov             x0, x2
    // 0xc8fadc: LoadField: r1 = r0->field_37
    //     0xc8fadc: ldur            w1, [x0, #0x37]
    // 0xc8fae0: DecompressPointer r1
    //     0xc8fae0: add             x1, x1, HEAP, lsl #32
    // 0xc8fae4: SaveReg r1
    //     0xc8fae4: str             x1, [SP, #-8]!
    // 0xc8fae8: r0 = of()
    //     0xc8fae8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8faec: add             SP, SP, #8
    // 0xc8faf0: LoadField: r1 = r0->field_8f
    //     0xc8faf0: ldur            w1, [x0, #0x8f]
    // 0xc8faf4: DecompressPointer r1
    //     0xc8faf4: add             x1, x1, HEAP, lsl #32
    // 0xc8faf8: LoadField: r0 = r1->field_2b
    //     0xc8faf8: ldur            w0, [x1, #0x2b]
    // 0xc8fafc: DecompressPointer r0
    //     0xc8fafc: add             x0, x0, HEAP, lsl #32
    // 0xc8fb00: mov             x2, x0
    // 0xc8fb04: ldur            x0, [fp, #-0x10]
    // 0xc8fb08: stur            x2, [fp, #-0x18]
    // 0xc8fb0c: r17 = 5444
    //     0xc8fb0c: mov             x17, #0x1544
    // 0xc8fb10: cmp             w0, w17
    // 0xc8fb14: b.ne            #0xc8fb2c
    // 0xc8fb18: ldr             x3, [fp, #0x18]
    // 0xc8fb1c: LoadField: r1 = r3->field_27
    //     0xc8fb1c: ldur            w1, [x3, #0x27]
    // 0xc8fb20: DecompressPointer r1
    //     0xc8fb20: add             x1, x1, HEAP, lsl #32
    // 0xc8fb24: mov             x0, x2
    // 0xc8fb28: b               #0xc8fba0
    // 0xc8fb2c: ldr             x3, [fp, #0x18]
    // 0xc8fb30: r17 = 5446
    //     0xc8fb30: mov             x17, #0x1546
    // 0xc8fb34: cmp             w0, w17
    // 0xc8fb38: b.ne            #0xc8fb70
    // 0xc8fb3c: mov             x1, x3
    // 0xc8fb40: LoadField: r0 = r1->field_3f
    //     0xc8fb40: ldur            w0, [x1, #0x3f]
    // 0xc8fb44: DecompressPointer r0
    //     0xc8fb44: add             x0, x0, HEAP, lsl #32
    // 0xc8fb48: r16 = Sentinel
    //     0xc8fb48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8fb4c: cmp             w0, w16
    // 0xc8fb50: b.ne            #0xc8fb60
    // 0xc8fb54: r2 = _textTheme
    //     0xc8fb54: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf58] Field <_TabsDefaultsM3@472014024._textTheme@472014024>: late final (offset: 0x40)
    //     0xc8fb58: ldr             x2, [x2, #0xf58]
    // 0xc8fb5c: r0 = InitLateFinalInstanceField()
    //     0xc8fb5c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8fb60: LoadField: r1 = r0->field_27
    //     0xc8fb60: ldur            w1, [x0, #0x27]
    // 0xc8fb64: DecompressPointer r1
    //     0xc8fb64: add             x1, x1, HEAP, lsl #32
    // 0xc8fb68: ldur            x0, [fp, #-0x18]
    // 0xc8fb6c: b               #0xc8fba0
    // 0xc8fb70: mov             x0, x3
    // 0xc8fb74: LoadField: r1 = r0->field_37
    //     0xc8fb74: ldur            w1, [x0, #0x37]
    // 0xc8fb78: DecompressPointer r1
    //     0xc8fb78: add             x1, x1, HEAP, lsl #32
    // 0xc8fb7c: SaveReg r1
    //     0xc8fb7c: str             x1, [SP, #-8]!
    // 0xc8fb80: r0 = of()
    //     0xc8fb80: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8fb84: add             SP, SP, #8
    // 0xc8fb88: LoadField: r1 = r0->field_8f
    //     0xc8fb88: ldur            w1, [x0, #0x8f]
    // 0xc8fb8c: DecompressPointer r1
    //     0xc8fb8c: add             x1, x1, HEAP, lsl #32
    // 0xc8fb90: LoadField: r0 = r1->field_2b
    //     0xc8fb90: ldur            w0, [x1, #0x2b]
    // 0xc8fb94: DecompressPointer r0
    //     0xc8fb94: add             x0, x0, HEAP, lsl #32
    // 0xc8fb98: mov             x1, x0
    // 0xc8fb9c: ldur            x0, [fp, #-0x18]
    // 0xc8fba0: r2 = LoadClassIdInstr(r0)
    //     0xc8fba0: ldur            x2, [x0, #-1]
    //     0xc8fba4: ubfx            x2, x2, #0xc, #0x14
    // 0xc8fba8: stp             x1, x0, [SP, #-0x10]!
    // 0xc8fbac: mov             x0, x2
    // 0xc8fbb0: mov             lr, x0
    // 0xc8fbb4: ldr             lr, [x21, lr, lsl #3]
    // 0xc8fbb8: blr             lr
    // 0xc8fbbc: add             SP, SP, #0x10
    // 0xc8fbc0: tbnz            w0, #4, #0xc8fe00
    // 0xc8fbc4: ldur            x0, [fp, #-8]
    // 0xc8fbc8: r17 = 5444
    //     0xc8fbc8: mov             x17, #0x1544
    // 0xc8fbcc: cmp             w0, w17
    // 0xc8fbd0: b.eq            #0xc8fc2c
    // 0xc8fbd4: r17 = 5446
    //     0xc8fbd4: mov             x17, #0x1546
    // 0xc8fbd8: cmp             w0, w17
    // 0xc8fbdc: b.ne            #0xc8fc2c
    // 0xc8fbe0: ldr             x1, [fp, #0x10]
    // 0xc8fbe4: r1 = 1
    //     0xc8fbe4: mov             x1, #1
    // 0xc8fbe8: r0 = AllocateContext()
    //     0xc8fbe8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc8fbec: mov             x1, x0
    // 0xc8fbf0: ldr             x0, [fp, #0x10]
    // 0xc8fbf4: StoreField: r1->field_f = r0
    //     0xc8fbf4: stur            w0, [x1, #0xf]
    // 0xc8fbf8: mov             x2, x1
    // 0xc8fbfc: r1 = Function '<anonymous closure>':.
    //     0xc8fbfc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf60] AnonymousClosure: (0xb020a4), in [package:flutter/src/material/tabs.dart] _TabsDefaultsM3::overlayColor (0xcebcec)
    //     0xc8fc00: ldr             x1, [x1, #0xf60]
    // 0xc8fc04: r0 = AllocateClosure()
    //     0xc8fc04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc8fc08: r16 = <Color?>
    //     0xc8fc08: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xc8fc0c: ldr             x16, [x16, #0xf68]
    // 0xc8fc10: stp             x0, x16, [SP, #-0x10]!
    // 0xc8fc14: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc8fc14: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc8fc18: r0 = resolveWith()
    //     0xc8fc18: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc8fc1c: add             SP, SP, #0x10
    // 0xc8fc20: mov             x2, x0
    // 0xc8fc24: ldr             x0, [fp, #0x10]
    // 0xc8fc28: b               #0xc8fc3c
    // 0xc8fc2c: ldr             x0, [fp, #0x10]
    // 0xc8fc30: LoadField: r1 = r0->field_2b
    //     0xc8fc30: ldur            w1, [x0, #0x2b]
    // 0xc8fc34: DecompressPointer r1
    //     0xc8fc34: add             x1, x1, HEAP, lsl #32
    // 0xc8fc38: mov             x2, x1
    // 0xc8fc3c: ldur            x1, [fp, #-0x10]
    // 0xc8fc40: stur            x2, [fp, #-0x18]
    // 0xc8fc44: r17 = 5444
    //     0xc8fc44: mov             x17, #0x1544
    // 0xc8fc48: cmp             w1, w17
    // 0xc8fc4c: b.eq            #0xc8fca8
    // 0xc8fc50: r17 = 5446
    //     0xc8fc50: mov             x17, #0x1546
    // 0xc8fc54: cmp             w1, w17
    // 0xc8fc58: b.ne            #0xc8fca8
    // 0xc8fc5c: ldr             x3, [fp, #0x18]
    // 0xc8fc60: r1 = 1
    //     0xc8fc60: mov             x1, #1
    // 0xc8fc64: r0 = AllocateContext()
    //     0xc8fc64: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc8fc68: mov             x1, x0
    // 0xc8fc6c: ldr             x0, [fp, #0x18]
    // 0xc8fc70: StoreField: r1->field_f = r0
    //     0xc8fc70: stur            w0, [x1, #0xf]
    // 0xc8fc74: mov             x2, x1
    // 0xc8fc78: r1 = Function '<anonymous closure>':.
    //     0xc8fc78: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf60] AnonymousClosure: (0xb020a4), in [package:flutter/src/material/tabs.dart] _TabsDefaultsM3::overlayColor (0xcebcec)
    //     0xc8fc7c: ldr             x1, [x1, #0xf60]
    // 0xc8fc80: r0 = AllocateClosure()
    //     0xc8fc80: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc8fc84: r16 = <Color?>
    //     0xc8fc84: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xc8fc88: ldr             x16, [x16, #0xf68]
    // 0xc8fc8c: stp             x0, x16, [SP, #-0x10]!
    // 0xc8fc90: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc8fc90: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc8fc94: r0 = resolveWith()
    //     0xc8fc94: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc8fc98: add             SP, SP, #0x10
    // 0xc8fc9c: mov             x2, x0
    // 0xc8fca0: ldr             x1, [fp, #0x18]
    // 0xc8fca4: b               #0xc8fcb8
    // 0xc8fca8: ldr             x1, [fp, #0x18]
    // 0xc8fcac: LoadField: r0 = r1->field_2b
    //     0xc8fcac: ldur            w0, [x1, #0x2b]
    // 0xc8fcb0: DecompressPointer r0
    //     0xc8fcb0: add             x0, x0, HEAP, lsl #32
    // 0xc8fcb4: mov             x2, x0
    // 0xc8fcb8: ldur            x0, [fp, #-0x18]
    // 0xc8fcbc: r3 = LoadClassIdInstr(r0)
    //     0xc8fcbc: ldur            x3, [x0, #-1]
    //     0xc8fcc0: ubfx            x3, x3, #0xc, #0x14
    // 0xc8fcc4: stp             x2, x0, [SP, #-0x10]!
    // 0xc8fcc8: mov             x0, x3
    // 0xc8fccc: mov             lr, x0
    // 0xc8fcd0: ldr             lr, [x21, lr, lsl #3]
    // 0xc8fcd4: blr             lr
    // 0xc8fcd8: add             SP, SP, #0x10
    // 0xc8fcdc: tbnz            w0, #4, #0xc8fe00
    // 0xc8fce0: ldur            x0, [fp, #-8]
    // 0xc8fce4: r17 = 5444
    //     0xc8fce4: mov             x17, #0x1544
    // 0xc8fce8: cmp             w0, w17
    // 0xc8fcec: b.ne            #0xc8fd04
    // 0xc8fcf0: ldr             x1, [fp, #0x10]
    // 0xc8fcf4: LoadField: r0 = r1->field_2f
    //     0xc8fcf4: ldur            w0, [x1, #0x2f]
    // 0xc8fcf8: DecompressPointer r0
    //     0xc8fcf8: add             x0, x0, HEAP, lsl #32
    // 0xc8fcfc: mov             x1, x0
    // 0xc8fd00: b               #0xc8fd50
    // 0xc8fd04: ldr             x1, [fp, #0x10]
    // 0xc8fd08: r17 = 5446
    //     0xc8fd08: mov             x17, #0x1546
    // 0xc8fd0c: cmp             w0, w17
    // 0xc8fd10: b.ne            #0xc8fd34
    // 0xc8fd14: LoadField: r0 = r1->field_37
    //     0xc8fd14: ldur            w0, [x1, #0x37]
    // 0xc8fd18: DecompressPointer r0
    //     0xc8fd18: add             x0, x0, HEAP, lsl #32
    // 0xc8fd1c: SaveReg r0
    //     0xc8fd1c: str             x0, [SP, #-8]!
    // 0xc8fd20: r0 = of()
    //     0xc8fd20: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8fd24: add             SP, SP, #8
    // 0xc8fd28: LoadField: r1 = r0->field_27
    //     0xc8fd28: ldur            w1, [x0, #0x27]
    // 0xc8fd2c: DecompressPointer r1
    //     0xc8fd2c: add             x1, x1, HEAP, lsl #32
    // 0xc8fd30: b               #0xc8fd50
    // 0xc8fd34: LoadField: r0 = r1->field_37
    //     0xc8fd34: ldur            w0, [x1, #0x37]
    // 0xc8fd38: DecompressPointer r0
    //     0xc8fd38: add             x0, x0, HEAP, lsl #32
    // 0xc8fd3c: SaveReg r0
    //     0xc8fd3c: str             x0, [SP, #-8]!
    // 0xc8fd40: r0 = of()
    //     0xc8fd40: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8fd44: add             SP, SP, #8
    // 0xc8fd48: LoadField: r1 = r0->field_27
    //     0xc8fd48: ldur            w1, [x0, #0x27]
    // 0xc8fd4c: DecompressPointer r1
    //     0xc8fd4c: add             x1, x1, HEAP, lsl #32
    // 0xc8fd50: ldur            x0, [fp, #-0x10]
    // 0xc8fd54: stur            x1, [fp, #-8]
    // 0xc8fd58: r17 = 5444
    //     0xc8fd58: mov             x17, #0x1544
    // 0xc8fd5c: cmp             w0, w17
    // 0xc8fd60: b.ne            #0xc8fd80
    // 0xc8fd64: ldr             x2, [fp, #0x18]
    // 0xc8fd68: LoadField: r0 = r2->field_2f
    //     0xc8fd68: ldur            w0, [x2, #0x2f]
    // 0xc8fd6c: DecompressPointer r0
    //     0xc8fd6c: add             x0, x0, HEAP, lsl #32
    // 0xc8fd70: mov             x16, x1
    // 0xc8fd74: mov             x1, x0
    // 0xc8fd78: mov             x0, x16
    // 0xc8fd7c: b               #0xc8fdd4
    // 0xc8fd80: ldr             x2, [fp, #0x18]
    // 0xc8fd84: r17 = 5446
    //     0xc8fd84: mov             x17, #0x1546
    // 0xc8fd88: cmp             w0, w17
    // 0xc8fd8c: b.ne            #0xc8fdb4
    // 0xc8fd90: LoadField: r0 = r2->field_37
    //     0xc8fd90: ldur            w0, [x2, #0x37]
    // 0xc8fd94: DecompressPointer r0
    //     0xc8fd94: add             x0, x0, HEAP, lsl #32
    // 0xc8fd98: SaveReg r0
    //     0xc8fd98: str             x0, [SP, #-8]!
    // 0xc8fd9c: r0 = of()
    //     0xc8fd9c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8fda0: add             SP, SP, #8
    // 0xc8fda4: LoadField: r1 = r0->field_27
    //     0xc8fda4: ldur            w1, [x0, #0x27]
    // 0xc8fda8: DecompressPointer r1
    //     0xc8fda8: add             x1, x1, HEAP, lsl #32
    // 0xc8fdac: ldur            x0, [fp, #-8]
    // 0xc8fdb0: b               #0xc8fdd4
    // 0xc8fdb4: LoadField: r0 = r2->field_37
    //     0xc8fdb4: ldur            w0, [x2, #0x37]
    // 0xc8fdb8: DecompressPointer r0
    //     0xc8fdb8: add             x0, x0, HEAP, lsl #32
    // 0xc8fdbc: SaveReg r0
    //     0xc8fdbc: str             x0, [SP, #-8]!
    // 0xc8fdc0: r0 = of()
    //     0xc8fdc0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8fdc4: add             SP, SP, #8
    // 0xc8fdc8: LoadField: r1 = r0->field_27
    //     0xc8fdc8: ldur            w1, [x0, #0x27]
    // 0xc8fdcc: DecompressPointer r1
    //     0xc8fdcc: add             x1, x1, HEAP, lsl #32
    // 0xc8fdd0: ldur            x0, [fp, #-8]
    // 0xc8fdd4: r2 = LoadClassIdInstr(r0)
    //     0xc8fdd4: ldur            x2, [x0, #-1]
    //     0xc8fdd8: ubfx            x2, x2, #0xc, #0x14
    // 0xc8fddc: stp             x1, x0, [SP, #-0x10]!
    // 0xc8fde0: mov             x0, x2
    // 0xc8fde4: mov             lr, x0
    // 0xc8fde8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8fdec: blr             lr
    // 0xc8fdf0: add             SP, SP, #0x10
    // 0xc8fdf4: tbnz            w0, #4, #0xc8fe00
    // 0xc8fdf8: r0 = true
    //     0xc8fdf8: add             x0, NULL, #0x20  ; true
    // 0xc8fdfc: b               #0xc8fe04
    // 0xc8fe00: r0 = false
    //     0xc8fe00: add             x0, NULL, #0x30  ; false
    // 0xc8fe04: LeaveFrame
    //     0xc8fe04: mov             SP, fp
    //     0xc8fe08: ldp             fp, lr, [SP], #0x10
    // 0xc8fe0c: ret
    //     0xc8fe0c: ret             
    // 0xc8fe10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8fe10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8fe14: b               #0xc8f2a0
    // 0xc8fe18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc8fe18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc8fe1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc8fe1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc8fe20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc8fe20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc8fe24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc8fe24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

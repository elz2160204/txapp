// lib: , url: package:flutter/src/material/tab_controller.dart

// class id: 1049318, size: 0x8
class :: {
}

// class id: 3273, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __DefaultTabControllerState&State&SingleTickerProviderStateMixin extends State<DefaultTabController>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x619008, size: 0x98
    // 0x619008: EnterFrame
    //     0x619008: stp             fp, lr, [SP, #-0x10]!
    //     0x61900c: mov             fp, SP
    // 0x619010: CheckStackOverflow
    //     0x619010: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x619014: cmp             SP, x16
    //     0x619018: b.ls            #0x619094
    // 0x61901c: r0 = Ticker()
    //     0x61901c: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x619020: mov             x1, x0
    // 0x619024: r0 = false
    //     0x619024: add             x0, NULL, #0x30  ; false
    // 0x619028: StoreField: r1->field_b = r0
    //     0x619028: stur            w0, [x1, #0xb]
    // 0x61902c: ldr             x0, [fp, #0x10]
    // 0x619030: StoreField: r1->field_13 = r0
    //     0x619030: stur            w0, [x1, #0x13]
    // 0x619034: mov             x0, x1
    // 0x619038: ldr             x1, [fp, #0x18]
    // 0x61903c: StoreField: r1->field_13 = r0
    //     0x61903c: stur            w0, [x1, #0x13]
    //     0x619040: ldurb           w16, [x1, #-1]
    //     0x619044: ldurb           w17, [x0, #-1]
    //     0x619048: and             x16, x17, x16, lsr #2
    //     0x61904c: tst             x16, HEAP, lsr #32
    //     0x619050: b.eq            #0x619058
    //     0x619054: bl              #0xd6826c
    // 0x619058: SaveReg r1
    //     0x619058: str             x1, [SP, #-8]!
    // 0x61905c: r0 = _updateTickerModeNotifier()
    //     0x61905c: bl              #0x6190ec  ; [package:flutter/src/material/tab_controller.dart] __DefaultTabControllerState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x619060: add             SP, SP, #8
    // 0x619064: ldr             x16, [fp, #0x18]
    // 0x619068: SaveReg r16
    //     0x619068: str             x16, [SP, #-8]!
    // 0x61906c: r0 = _updateTicker()
    //     0x61906c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x619070: add             SP, SP, #8
    // 0x619074: ldr             x1, [fp, #0x18]
    // 0x619078: LoadField: r0 = r1->field_13
    //     0x619078: ldur            w0, [x1, #0x13]
    // 0x61907c: DecompressPointer r0
    //     0x61907c: add             x0, x0, HEAP, lsl #32
    // 0x619080: cmp             w0, NULL
    // 0x619084: b.eq            #0x61909c
    // 0x619088: LeaveFrame
    //     0x619088: mov             SP, fp
    //     0x61908c: ldp             fp, lr, [SP], #0x10
    // 0x619090: ret
    //     0x619090: ret             
    // 0x619094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x619094: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x619098: b               #0x61901c
    // 0x61909c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61909c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6190ec, size: 0x11c
    // 0x6190ec: EnterFrame
    //     0x6190ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6190f0: mov             fp, SP
    // 0x6190f4: AllocStack(0x10)
    //     0x6190f4: sub             SP, SP, #0x10
    // 0x6190f8: CheckStackOverflow
    //     0x6190f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6190fc: cmp             SP, x16
    //     0x619100: b.ls            #0x6191fc
    // 0x619104: ldr             x0, [fp, #0x10]
    // 0x619108: LoadField: r1 = r0->field_f
    //     0x619108: ldur            w1, [x0, #0xf]
    // 0x61910c: DecompressPointer r1
    //     0x61910c: add             x1, x1, HEAP, lsl #32
    // 0x619110: cmp             w1, NULL
    // 0x619114: b.eq            #0x619204
    // 0x619118: SaveReg r1
    //     0x619118: str             x1, [SP, #-8]!
    // 0x61911c: r0 = getNotifier()
    //     0x61911c: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x619120: add             SP, SP, #8
    // 0x619124: mov             x1, x0
    // 0x619128: ldr             x0, [fp, #0x10]
    // 0x61912c: stur            x1, [fp, #-0x10]
    // 0x619130: LoadField: r2 = r0->field_17
    //     0x619130: ldur            w2, [x0, #0x17]
    // 0x619134: DecompressPointer r2
    //     0x619134: add             x2, x2, HEAP, lsl #32
    // 0x619138: stur            x2, [fp, #-8]
    // 0x61913c: cmp             w1, w2
    // 0x619140: b.ne            #0x619154
    // 0x619144: r0 = Null
    //     0x619144: mov             x0, NULL
    // 0x619148: LeaveFrame
    //     0x619148: mov             SP, fp
    //     0x61914c: ldp             fp, lr, [SP], #0x10
    // 0x619150: ret
    //     0x619150: ret             
    // 0x619154: cmp             w2, NULL
    // 0x619158: b.eq            #0x619194
    // 0x61915c: r1 = 1
    //     0x61915c: mov             x1, #1
    // 0x619160: r0 = AllocateContext()
    //     0x619160: bl              #0xd68aa4  ; AllocateContextStub
    // 0x619164: mov             x1, x0
    // 0x619168: ldr             x0, [fp, #0x10]
    // 0x61916c: StoreField: r1->field_f = r0
    //     0x61916c: stur            w0, [x1, #0xf]
    // 0x619170: mov             x2, x1
    // 0x619174: r1 = Function '_updateTicker@156311458':.
    //     0x619174: add             x1, PP, #0x37, lsl #12  ; [pp+0x37750] AnonymousClosure: (0x619208), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x619178: ldr             x1, [x1, #0x750]
    // 0x61917c: r0 = AllocateClosure()
    //     0x61917c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x619180: ldur            x16, [fp, #-8]
    // 0x619184: stp             x0, x16, [SP, #-0x10]!
    // 0x619188: r0 = removeListener()
    //     0x619188: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x61918c: add             SP, SP, #0x10
    // 0x619190: ldr             x0, [fp, #0x10]
    // 0x619194: r1 = 1
    //     0x619194: mov             x1, #1
    // 0x619198: r0 = AllocateContext()
    //     0x619198: bl              #0xd68aa4  ; AllocateContextStub
    // 0x61919c: mov             x1, x0
    // 0x6191a0: ldr             x0, [fp, #0x10]
    // 0x6191a4: StoreField: r1->field_f = r0
    //     0x6191a4: stur            w0, [x1, #0xf]
    // 0x6191a8: mov             x2, x1
    // 0x6191ac: r1 = Function '_updateTicker@156311458':.
    //     0x6191ac: add             x1, PP, #0x37, lsl #12  ; [pp+0x37750] AnonymousClosure: (0x619208), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x6191b0: ldr             x1, [x1, #0x750]
    // 0x6191b4: r0 = AllocateClosure()
    //     0x6191b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6191b8: ldur            x16, [fp, #-0x10]
    // 0x6191bc: stp             x0, x16, [SP, #-0x10]!
    // 0x6191c0: r0 = addListener()
    //     0x6191c0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x6191c4: add             SP, SP, #0x10
    // 0x6191c8: ldur            x0, [fp, #-0x10]
    // 0x6191cc: ldr             x1, [fp, #0x10]
    // 0x6191d0: StoreField: r1->field_17 = r0
    //     0x6191d0: stur            w0, [x1, #0x17]
    //     0x6191d4: ldurb           w16, [x1, #-1]
    //     0x6191d8: ldurb           w17, [x0, #-1]
    //     0x6191dc: and             x16, x17, x16, lsr #2
    //     0x6191e0: tst             x16, HEAP, lsr #32
    //     0x6191e4: b.eq            #0x6191ec
    //     0x6191e8: bl              #0xd6826c
    // 0x6191ec: r0 = Null
    //     0x6191ec: mov             x0, NULL
    // 0x6191f0: LeaveFrame
    //     0x6191f0: mov             SP, fp
    //     0x6191f4: ldp             fp, lr, [SP], #0x10
    // 0x6191f8: ret
    //     0x6191f8: ret             
    // 0x6191fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6191fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x619200: b               #0x619104
    // 0x619204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x619204: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x619208, size: 0x48
    // 0x619208: EnterFrame
    //     0x619208: stp             fp, lr, [SP, #-0x10]!
    //     0x61920c: mov             fp, SP
    // 0x619210: ldr             x0, [fp, #0x10]
    // 0x619214: LoadField: r1 = r0->field_17
    //     0x619214: ldur            w1, [x0, #0x17]
    // 0x619218: DecompressPointer r1
    //     0x619218: add             x1, x1, HEAP, lsl #32
    // 0x61921c: CheckStackOverflow
    //     0x61921c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x619220: cmp             SP, x16
    //     0x619224: b.ls            #0x619248
    // 0x619228: LoadField: r0 = r1->field_f
    //     0x619228: ldur            w0, [x1, #0xf]
    // 0x61922c: DecompressPointer r0
    //     0x61922c: add             x0, x0, HEAP, lsl #32
    // 0x619230: SaveReg r0
    //     0x619230: str             x0, [SP, #-8]!
    // 0x619234: r0 = _updateTicker()
    //     0x619234: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x619238: add             SP, SP, #8
    // 0x61923c: LeaveFrame
    //     0x61923c: mov             SP, fp
    //     0x619240: ldp             fp, lr, [SP], #0x10
    // 0x619244: ret
    //     0x619244: ret             
    // 0x619248: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x619248: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61924c: b               #0x619228
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f838, size: 0x4c
    // 0x81f838: EnterFrame
    //     0x81f838: stp             fp, lr, [SP, #-0x10]!
    //     0x81f83c: mov             fp, SP
    // 0x81f840: CheckStackOverflow
    //     0x81f840: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f844: cmp             SP, x16
    //     0x81f848: b.ls            #0x81f87c
    // 0x81f84c: ldr             x16, [fp, #0x10]
    // 0x81f850: SaveReg r16
    //     0x81f850: str             x16, [SP, #-8]!
    // 0x81f854: r0 = _updateTickerModeNotifier()
    //     0x81f854: bl              #0x6190ec  ; [package:flutter/src/material/tab_controller.dart] __DefaultTabControllerState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f858: add             SP, SP, #8
    // 0x81f85c: ldr             x16, [fp, #0x10]
    // 0x81f860: SaveReg r16
    //     0x81f860: str             x16, [SP, #-8]!
    // 0x81f864: r0 = _updateTicker()
    //     0x81f864: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f868: add             SP, SP, #8
    // 0x81f86c: r0 = Null
    //     0x81f86c: mov             x0, NULL
    // 0x81f870: LeaveFrame
    //     0x81f870: mov             SP, fp
    //     0x81f874: ldp             fp, lr, [SP], #0x10
    // 0x81f878: ret
    //     0x81f878: ret             
    // 0x81f87c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f87c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f880: b               #0x81f84c
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52c30, size: 0x8c
    // 0xa52c30: EnterFrame
    //     0xa52c30: stp             fp, lr, [SP, #-0x10]!
    //     0xa52c34: mov             fp, SP
    // 0xa52c38: AllocStack(0x8)
    //     0xa52c38: sub             SP, SP, #8
    // 0xa52c3c: CheckStackOverflow
    //     0xa52c3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52c40: cmp             SP, x16
    //     0xa52c44: b.ls            #0xa52cb4
    // 0xa52c48: ldr             x0, [fp, #0x10]
    // 0xa52c4c: LoadField: r1 = r0->field_17
    //     0xa52c4c: ldur            w1, [x0, #0x17]
    // 0xa52c50: DecompressPointer r1
    //     0xa52c50: add             x1, x1, HEAP, lsl #32
    // 0xa52c54: stur            x1, [fp, #-8]
    // 0xa52c58: cmp             w1, NULL
    // 0xa52c5c: b.ne            #0xa52c68
    // 0xa52c60: mov             x1, x0
    // 0xa52c64: b               #0xa52ca0
    // 0xa52c68: r1 = 1
    //     0xa52c68: mov             x1, #1
    // 0xa52c6c: r0 = AllocateContext()
    //     0xa52c6c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52c70: mov             x1, x0
    // 0xa52c74: ldr             x0, [fp, #0x10]
    // 0xa52c78: StoreField: r1->field_f = r0
    //     0xa52c78: stur            w0, [x1, #0xf]
    // 0xa52c7c: mov             x2, x1
    // 0xa52c80: r1 = Function '_updateTicker@156311458':.
    //     0xa52c80: add             x1, PP, #0x37, lsl #12  ; [pp+0x37750] AnonymousClosure: (0x619208), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa52c84: ldr             x1, [x1, #0x750]
    // 0xa52c88: r0 = AllocateClosure()
    //     0xa52c88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52c8c: ldur            x16, [fp, #-8]
    // 0xa52c90: stp             x0, x16, [SP, #-0x10]!
    // 0xa52c94: r0 = removeListener()
    //     0xa52c94: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa52c98: add             SP, SP, #0x10
    // 0xa52c9c: ldr             x1, [fp, #0x10]
    // 0xa52ca0: StoreField: r1->field_17 = rNULL
    //     0xa52ca0: stur            NULL, [x1, #0x17]
    // 0xa52ca4: r0 = Null
    //     0xa52ca4: mov             x0, NULL
    // 0xa52ca8: LeaveFrame
    //     0xa52ca8: mov             SP, fp
    //     0xa52cac: ldp             fp, lr, [SP], #0x10
    // 0xa52cb0: ret
    //     0xa52cb0: ret             
    // 0xa52cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52cb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52cb8: b               #0xa52c48
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa52cbc, size: 0x48
    // 0xa52cbc: EnterFrame
    //     0xa52cbc: stp             fp, lr, [SP, #-0x10]!
    //     0xa52cc0: mov             fp, SP
    // 0xa52cc4: ldr             x0, [fp, #0x10]
    // 0xa52cc8: LoadField: r1 = r0->field_17
    //     0xa52cc8: ldur            w1, [x0, #0x17]
    // 0xa52ccc: DecompressPointer r1
    //     0xa52ccc: add             x1, x1, HEAP, lsl #32
    // 0xa52cd0: CheckStackOverflow
    //     0xa52cd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52cd4: cmp             SP, x16
    //     0xa52cd8: b.ls            #0xa52cfc
    // 0xa52cdc: LoadField: r0 = r1->field_f
    //     0xa52cdc: ldur            w0, [x1, #0xf]
    // 0xa52ce0: DecompressPointer r0
    //     0xa52ce0: add             x0, x0, HEAP, lsl #32
    // 0xa52ce4: SaveReg r0
    //     0xa52ce4: str             x0, [SP, #-8]!
    // 0xa52ce8: r0 = dispose()
    //     0xa52ce8: bl              #0xa52c30  ; [package:flutter/src/material/tab_controller.dart] __DefaultTabControllerState&State&SingleTickerProviderStateMixin::dispose
    // 0xa52cec: add             SP, SP, #8
    // 0xa52cf0: LeaveFrame
    //     0xa52cf0: mov             SP, fp
    //     0xa52cf4: ldp             fp, lr, [SP], #0x10
    // 0xa52cf8: ret
    //     0xa52cf8: ret             
    // 0xa52cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52cfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52d00: b               #0xa52cdc
  }
}

// class id: 3274, size: 0x20, field offset: 0x1c
class _DefaultTabControllerState extends __DefaultTabControllerState&State&SingleTickerProviderStateMixin {

  late TabController _controller; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bbcfc, size: 0x1dc
    // 0x7bbcfc: EnterFrame
    //     0x7bbcfc: stp             fp, lr, [SP, #-0x10]!
    //     0x7bbd00: mov             fp, SP
    // 0x7bbd04: CheckStackOverflow
    //     0x7bbd04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bbd08: cmp             SP, x16
    //     0x7bbd0c: b.ls            #0x7bbebc
    // 0x7bbd10: ldr             x0, [fp, #0x10]
    // 0x7bbd14: r2 = Null
    //     0x7bbd14: mov             x2, NULL
    // 0x7bbd18: r1 = Null
    //     0x7bbd18: mov             x1, NULL
    // 0x7bbd1c: r4 = 59
    //     0x7bbd1c: mov             x4, #0x3b
    // 0x7bbd20: branchIfSmi(r0, 0x7bbd2c)
    //     0x7bbd20: tbz             w0, #0, #0x7bbd2c
    // 0x7bbd24: r4 = LoadClassIdInstr(r0)
    //     0x7bbd24: ldur            x4, [x0, #-1]
    //     0x7bbd28: ubfx            x4, x4, #0xc, #0x14
    // 0x7bbd2c: r17 = 4118
    //     0x7bbd2c: mov             x17, #0x1016
    // 0x7bbd30: cmp             x4, x17
    // 0x7bbd34: b.eq            #0x7bbd4c
    // 0x7bbd38: r8 = DefaultTabController
    //     0x7bbd38: add             x8, PP, #0x37, lsl #12  ; [pp+0x37720] Type: DefaultTabController
    //     0x7bbd3c: ldr             x8, [x8, #0x720]
    // 0x7bbd40: r3 = Null
    //     0x7bbd40: add             x3, PP, #0x37, lsl #12  ; [pp+0x37728] Null
    //     0x7bbd44: ldr             x3, [x3, #0x728]
    // 0x7bbd48: r0 = DefaultTabController()
    //     0x7bbd48: bl              #0x6190c8  ; IsType_DefaultTabController_Stub
    // 0x7bbd4c: ldr             x3, [fp, #0x18]
    // 0x7bbd50: LoadField: r2 = r3->field_7
    //     0x7bbd50: ldur            w2, [x3, #7]
    // 0x7bbd54: DecompressPointer r2
    //     0x7bbd54: add             x2, x2, HEAP, lsl #32
    // 0x7bbd58: ldr             x0, [fp, #0x10]
    // 0x7bbd5c: r1 = Null
    //     0x7bbd5c: mov             x1, NULL
    // 0x7bbd60: cmp             w2, NULL
    // 0x7bbd64: b.eq            #0x7bbd88
    // 0x7bbd68: LoadField: r4 = r2->field_17
    //     0x7bbd68: ldur            w4, [x2, #0x17]
    // 0x7bbd6c: DecompressPointer r4
    //     0x7bbd6c: add             x4, x4, HEAP, lsl #32
    // 0x7bbd70: r8 = X0 bound StatefulWidget
    //     0x7bbd70: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7bbd74: ldr             x8, [x8, #0x858]
    // 0x7bbd78: LoadField: r9 = r4->field_7
    //     0x7bbd78: ldur            x9, [x4, #7]
    // 0x7bbd7c: r3 = Null
    //     0x7bbd7c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37738] Null
    //     0x7bbd80: ldr             x3, [x3, #0x738]
    // 0x7bbd84: blr             x9
    // 0x7bbd88: ldr             x0, [fp, #0x10]
    // 0x7bbd8c: LoadField: r1 = r0->field_b
    //     0x7bbd8c: ldur            x1, [x0, #0xb]
    // 0x7bbd90: ldr             x2, [fp, #0x18]
    // 0x7bbd94: LoadField: r0 = r2->field_b
    //     0x7bbd94: ldur            w0, [x2, #0xb]
    // 0x7bbd98: DecompressPointer r0
    //     0x7bbd98: add             x0, x0, HEAP, lsl #32
    // 0x7bbd9c: cmp             w0, NULL
    // 0x7bbda0: b.eq            #0x7bbec4
    // 0x7bbda4: LoadField: r3 = r0->field_b
    //     0x7bbda4: ldur            x3, [x0, #0xb]
    // 0x7bbda8: lsl             x0, x1, #1
    // 0x7bbdac: lsl             x4, x3, #1
    // 0x7bbdb0: cmp             w0, w4
    // 0x7bbdb4: b.eq            #0x7bbe98
    // 0x7bbdb8: LoadField: r5 = r2->field_1b
    //     0x7bbdb8: ldur            w5, [x2, #0x1b]
    // 0x7bbdbc: DecompressPointer r5
    //     0x7bbdbc: add             x5, x5, HEAP, lsl #32
    // 0x7bbdc0: r16 = Sentinel
    //     0x7bbdc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bbdc4: cmp             w5, w16
    // 0x7bbdc8: b.eq            #0x7bbec8
    // 0x7bbdcc: LoadField: r0 = r5->field_3b
    //     0x7bbdcc: ldur            x0, [x5, #0x3b]
    // 0x7bbdd0: LoadField: r6 = r5->field_33
    //     0x7bbdd0: ldur            x6, [x5, #0x33]
    // 0x7bbdd4: cmp             x6, x3
    // 0x7bbdd8: b.lt            #0x7bbe60
    // 0x7bbddc: sub             x7, x3, #1
    // 0x7bbde0: tbz             x7, #0x3f, #0x7bbdec
    // 0x7bbde4: r0 = 0
    //     0x7bbde4: mov             x0, #0
    // 0x7bbde8: b               #0x7bbe54
    // 0x7bbdec: cmp             x7, #0
    // 0x7bbdf0: b.le            #0x7bbe0c
    // 0x7bbdf4: r0 = BoxInt64Instr(r7)
    //     0x7bbdf4: sbfiz           x0, x7, #1, #0x1f
    //     0x7bbdf8: cmp             x7, x0, asr #1
    //     0x7bbdfc: b.eq            #0x7bbe08
    //     0x7bbe00: bl              #0xd69bb8
    //     0x7bbe04: stur            x7, [x0, #7]
    // 0x7bbe08: b               #0x7bbe54
    // 0x7bbe0c: r0 = BoxInt64Instr(r7)
    //     0x7bbe0c: sbfiz           x0, x7, #1, #0x1f
    //     0x7bbe10: cmp             x7, x0, asr #1
    //     0x7bbe14: b.eq            #0x7bbe20
    //     0x7bbe18: bl              #0xd69bb8
    //     0x7bbe1c: stur            x7, [x0, #7]
    // 0x7bbe20: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x7bbe20: mov             x1, #0x76
    //     0x7bbe24: tbz             w0, #0, #0x7bbe34
    //     0x7bbe28: ldur            x1, [x0, #-1]
    //     0x7bbe2c: ubfx            x1, x1, #0xc, #0x14
    //     0x7bbe30: lsl             x1, x1, #1
    // 0x7bbe34: cmp             w1, #0x7a
    // 0x7bbe38: b.ne            #0x7bbe50
    // 0x7bbe3c: LoadField: d0 = r0->field_7
    //     0x7bbe3c: ldur            d0, [x0, #7]
    // 0x7bbe40: fcmp            d0, d0
    // 0x7bbe44: b.vs            #0x7bbe54
    // 0x7bbe48: r0 = 0
    //     0x7bbe48: mov             x0, #0
    // 0x7bbe4c: b               #0x7bbe54
    // 0x7bbe50: r0 = 0
    //     0x7bbe50: mov             x0, #0
    // 0x7bbe54: mov             x1, x0
    // 0x7bbe58: mov             x0, x6
    // 0x7bbe5c: b               #0x7bbe64
    // 0x7bbe60: r1 = Null
    //     0x7bbe60: mov             x1, NULL
    // 0x7bbe64: stp             x1, x5, [SP, #-0x10]!
    // 0x7bbe68: stp             x0, x4, [SP, #-0x10]!
    // 0x7bbe6c: r0 = _copyWith()
    //     0x7bbe6c: bl              #0x7bbed8  ; [package:flutter/src/material/tab_controller.dart] TabController::_copyWith
    // 0x7bbe70: add             SP, SP, #0x20
    // 0x7bbe74: ldr             x1, [fp, #0x18]
    // 0x7bbe78: StoreField: r1->field_1b = r0
    //     0x7bbe78: stur            w0, [x1, #0x1b]
    //     0x7bbe7c: ldurb           w16, [x1, #-1]
    //     0x7bbe80: ldurb           w17, [x0, #-1]
    //     0x7bbe84: and             x16, x17, x16, lsr #2
    //     0x7bbe88: tst             x16, HEAP, lsr #32
    //     0x7bbe8c: b.eq            #0x7bbe94
    //     0x7bbe90: bl              #0xd6826c
    // 0x7bbe94: b               #0x7bbe9c
    // 0x7bbe98: mov             x1, x2
    // 0x7bbe9c: LoadField: r2 = r1->field_b
    //     0x7bbe9c: ldur            w2, [x1, #0xb]
    // 0x7bbea0: DecompressPointer r2
    //     0x7bbea0: add             x2, x2, HEAP, lsl #32
    // 0x7bbea4: cmp             w2, NULL
    // 0x7bbea8: b.eq            #0x7bbed4
    // 0x7bbeac: r0 = Null
    //     0x7bbeac: mov             x0, NULL
    // 0x7bbeb0: LeaveFrame
    //     0x7bbeb0: mov             SP, fp
    //     0x7bbeb4: ldp             fp, lr, [SP], #0x10
    // 0x7bbeb8: ret
    //     0x7bbeb8: ret             
    // 0x7bbebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bbebc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bbec0: b               #0x7bbd10
    // 0x7bbec4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bbec4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bbec8: r9 = _controller
    //     0x7bbec8: add             x9, PP, #0x37, lsl #12  ; [pp+0x37748] Field <_DefaultTabControllerState@819237367._controller@819237367>: late (offset: 0x1c)
    //     0x7bbecc: ldr             x9, [x9, #0x748]
    // 0x7bbed0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7bbed0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7bbed4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bbed4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x8688c4, size: 0xac
    // 0x8688c4: EnterFrame
    //     0x8688c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8688c8: mov             fp, SP
    // 0x8688cc: AllocStack(0x18)
    //     0x8688cc: sub             SP, SP, #0x18
    // 0x8688d0: CheckStackOverflow
    //     0x8688d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8688d4: cmp             SP, x16
    //     0x8688d8: b.ls            #0x868958
    // 0x8688dc: ldr             x0, [fp, #0x18]
    // 0x8688e0: LoadField: r1 = r0->field_1b
    //     0x8688e0: ldur            w1, [x0, #0x1b]
    // 0x8688e4: DecompressPointer r1
    //     0x8688e4: add             x1, x1, HEAP, lsl #32
    // 0x8688e8: r16 = Sentinel
    //     0x8688e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8688ec: cmp             w1, w16
    // 0x8688f0: b.eq            #0x868960
    // 0x8688f4: stur            x1, [fp, #-8]
    // 0x8688f8: ldr             x16, [fp, #0x10]
    // 0x8688fc: SaveReg r16
    //     0x8688fc: str             x16, [SP, #-8]!
    // 0x868900: r0 = of()
    //     0x868900: bl              #0x86897c  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::of
    // 0x868904: add             SP, SP, #8
    // 0x868908: mov             x1, x0
    // 0x86890c: ldr             x0, [fp, #0x18]
    // 0x868910: stur            x1, [fp, #-0x18]
    // 0x868914: LoadField: r2 = r0->field_b
    //     0x868914: ldur            w2, [x0, #0xb]
    // 0x868918: DecompressPointer r2
    //     0x868918: add             x2, x2, HEAP, lsl #32
    // 0x86891c: cmp             w2, NULL
    // 0x868920: b.eq            #0x86896c
    // 0x868924: LoadField: r0 = r2->field_1f
    //     0x868924: ldur            w0, [x2, #0x1f]
    // 0x868928: DecompressPointer r0
    //     0x868928: add             x0, x0, HEAP, lsl #32
    // 0x86892c: stur            x0, [fp, #-0x10]
    // 0x868930: r0 = _TabControllerScope()
    //     0x868930: bl              #0x868970  ; Allocate_TabControllerScopeStub -> _TabControllerScope (size=0x18)
    // 0x868934: ldur            x1, [fp, #-8]
    // 0x868938: StoreField: r0->field_f = r1
    //     0x868938: stur            w1, [x0, #0xf]
    // 0x86893c: ldur            x1, [fp, #-0x18]
    // 0x868940: StoreField: r0->field_13 = r1
    //     0x868940: stur            w1, [x0, #0x13]
    // 0x868944: ldur            x1, [fp, #-0x10]
    // 0x868948: StoreField: r0->field_b = r1
    //     0x868948: stur            w1, [x0, #0xb]
    // 0x86894c: LeaveFrame
    //     0x86894c: mov             SP, fp
    //     0x868950: ldp             fp, lr, [SP], #0x10
    // 0x868954: ret
    //     0x868954: ret             
    // 0x868958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x868958: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86895c: b               #0x8688dc
    // 0x868960: r9 = _controller
    //     0x868960: add             x9, PP, #0x37, lsl #12  ; [pp+0x37748] Field <_DefaultTabControllerState@819237367._controller@819237367>: late (offset: 0x1c)
    //     0x868964: ldr             x9, [x9, #0x748]
    // 0x868968: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x868968: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x86896c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86896c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9dbc90, size: 0xa0
    // 0x9dbc90: EnterFrame
    //     0x9dbc90: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbc94: mov             fp, SP
    // 0x9dbc98: AllocStack(0x10)
    //     0x9dbc98: sub             SP, SP, #0x10
    // 0x9dbc9c: CheckStackOverflow
    //     0x9dbc9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dbca0: cmp             SP, x16
    //     0x9dbca4: b.ls            #0x9dbd24
    // 0x9dbca8: ldr             x0, [fp, #0x10]
    // 0x9dbcac: LoadField: r1 = r0->field_b
    //     0x9dbcac: ldur            w1, [x0, #0xb]
    // 0x9dbcb0: DecompressPointer r1
    //     0x9dbcb0: add             x1, x1, HEAP, lsl #32
    // 0x9dbcb4: cmp             w1, NULL
    // 0x9dbcb8: b.eq            #0x9dbd2c
    // 0x9dbcbc: LoadField: r2 = r1->field_b
    //     0x9dbcbc: ldur            x2, [x1, #0xb]
    // 0x9dbcc0: stur            x2, [fp, #-8]
    // 0x9dbcc4: r0 = TabController()
    //     0x9dbcc4: bl              #0x7bc0ac  ; AllocateTabControllerStub -> TabController (size=0x4c)
    // 0x9dbcc8: stur            x0, [fp, #-0x10]
    // 0x9dbccc: SaveReg r0
    //     0x9dbccc: str             x0, [SP, #-8]!
    // 0x9dbcd0: ldur            x1, [fp, #-8]
    // 0x9dbcd4: ldr             x16, [fp, #0x10]
    // 0x9dbcd8: stp             x16, x1, [SP, #-0x10]!
    // 0x9dbcdc: SaveReg rZR
    //     0x9dbcdc: str             xzr, [SP, #-8]!
    // 0x9dbce0: r4 = const [0, 0x4, 0x4, 0x3, initialIndex, 0x3, null]
    //     0x9dbce0: add             x4, PP, #0x27, lsl #12  ; [pp+0x270c8] List(7) [0, 0x4, 0x4, 0x3, "initialIndex", 0x3, Null]
    //     0x9dbce4: ldr             x4, [x4, #0xc8]
    // 0x9dbce8: r0 = TabController()
    //     0x9dbce8: bl              #0x9d5af4  ; [package:flutter/src/material/tab_controller.dart] TabController::TabController
    // 0x9dbcec: add             SP, SP, #0x20
    // 0x9dbcf0: ldur            x0, [fp, #-0x10]
    // 0x9dbcf4: ldr             x1, [fp, #0x10]
    // 0x9dbcf8: StoreField: r1->field_1b = r0
    //     0x9dbcf8: stur            w0, [x1, #0x1b]
    //     0x9dbcfc: ldurb           w16, [x1, #-1]
    //     0x9dbd00: ldurb           w17, [x0, #-1]
    //     0x9dbd04: and             x16, x17, x16, lsr #2
    //     0x9dbd08: tst             x16, HEAP, lsr #32
    //     0x9dbd0c: b.eq            #0x9dbd14
    //     0x9dbd10: bl              #0xd6826c
    // 0x9dbd14: r0 = Null
    //     0x9dbd14: mov             x0, NULL
    // 0x9dbd18: LeaveFrame
    //     0x9dbd18: mov             SP, fp
    //     0x9dbd1c: ldp             fp, lr, [SP], #0x10
    // 0x9dbd20: ret
    //     0x9dbd20: ret             
    // 0x9dbd24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbd24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbd28: b               #0x9dbca8
    // 0x9dbd2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbd2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b1e8, size: 0x18
    // 0xa4b1e8: r4 = 7
    //     0xa4b1e8: mov             x4, #7
    // 0xa4b1ec: r1 = Function 'dispose':.
    //     0xa4b1ec: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b570] AnonymousClosure: (0xa4b200), in [package:flutter/src/material/tab_controller.dart] _DefaultTabControllerState::dispose (0xa52bc4)
    //     0xa4b1f0: ldr             x1, [x17, #0x570]
    // 0xa4b1f4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b1f4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b1f8: LoadField: r0 = r24->field_17
    //     0xa4b1f8: ldur            x0, [x24, #0x17]
    // 0xa4b1fc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b200, size: 0x48
    // 0xa4b200: EnterFrame
    //     0xa4b200: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b204: mov             fp, SP
    // 0xa4b208: ldr             x0, [fp, #0x10]
    // 0xa4b20c: LoadField: r1 = r0->field_17
    //     0xa4b20c: ldur            w1, [x0, #0x17]
    // 0xa4b210: DecompressPointer r1
    //     0xa4b210: add             x1, x1, HEAP, lsl #32
    // 0xa4b214: CheckStackOverflow
    //     0xa4b214: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b218: cmp             SP, x16
    //     0xa4b21c: b.ls            #0xa4b240
    // 0xa4b220: LoadField: r0 = r1->field_f
    //     0xa4b220: ldur            w0, [x1, #0xf]
    // 0xa4b224: DecompressPointer r0
    //     0xa4b224: add             x0, x0, HEAP, lsl #32
    // 0xa4b228: SaveReg r0
    //     0xa4b228: str             x0, [SP, #-8]!
    // 0xa4b22c: r0 = dispose()
    //     0xa4b22c: bl              #0xa52bc4  ; [package:flutter/src/material/tab_controller.dart] _DefaultTabControllerState::dispose
    // 0xa4b230: add             SP, SP, #8
    // 0xa4b234: LeaveFrame
    //     0xa4b234: mov             SP, fp
    //     0xa4b238: ldp             fp, lr, [SP], #0x10
    // 0xa4b23c: ret
    //     0xa4b23c: ret             
    // 0xa4b240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b240: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b244: b               #0xa4b220
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52bc4, size: 0x6c
    // 0xa52bc4: EnterFrame
    //     0xa52bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xa52bc8: mov             fp, SP
    // 0xa52bcc: CheckStackOverflow
    //     0xa52bcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52bd0: cmp             SP, x16
    //     0xa52bd4: b.ls            #0xa52c1c
    // 0xa52bd8: ldr             x0, [fp, #0x10]
    // 0xa52bdc: LoadField: r1 = r0->field_1b
    //     0xa52bdc: ldur            w1, [x0, #0x1b]
    // 0xa52be0: DecompressPointer r1
    //     0xa52be0: add             x1, x1, HEAP, lsl #32
    // 0xa52be4: r16 = Sentinel
    //     0xa52be4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa52be8: cmp             w1, w16
    // 0xa52bec: b.eq            #0xa52c24
    // 0xa52bf0: SaveReg r1
    //     0xa52bf0: str             x1, [SP, #-8]!
    // 0xa52bf4: r0 = dispose()
    //     0xa52bf4: bl              #0x9c2804  ; [package:flutter/src/material/tab_controller.dart] TabController::dispose
    // 0xa52bf8: add             SP, SP, #8
    // 0xa52bfc: ldr             x16, [fp, #0x10]
    // 0xa52c00: SaveReg r16
    //     0xa52c00: str             x16, [SP, #-8]!
    // 0xa52c04: r0 = dispose()
    //     0xa52c04: bl              #0xa52c30  ; [package:flutter/src/material/tab_controller.dart] __DefaultTabControllerState&State&SingleTickerProviderStateMixin::dispose
    // 0xa52c08: add             SP, SP, #8
    // 0xa52c0c: r0 = Null
    //     0xa52c0c: mov             x0, NULL
    // 0xa52c10: LeaveFrame
    //     0xa52c10: mov             SP, fp
    //     0xa52c14: ldp             fp, lr, [SP], #0x10
    // 0xa52c18: ret
    //     0xa52c18: ret             
    // 0xa52c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52c1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52c20: b               #0xa52bd8
    // 0xa52c24: r9 = _controller
    //     0xa52c24: add             x9, PP, #0x37, lsl #12  ; [pp+0x37748] Field <_DefaultTabControllerState@819237367._controller@819237367>: late (offset: 0x1c)
    //     0xa52c28: ldr             x9, [x9, #0x748]
    // 0xa52c2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa52c2c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3523, size: 0x18, field offset: 0x10
//   const constructor, 
class _TabControllerScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa87d3c, size: 0x98
    // 0xa87d3c: EnterFrame
    //     0xa87d3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa87d40: mov             fp, SP
    // 0xa87d44: ldr             x0, [fp, #0x10]
    // 0xa87d48: r2 = Null
    //     0xa87d48: mov             x2, NULL
    // 0xa87d4c: r1 = Null
    //     0xa87d4c: mov             x1, NULL
    // 0xa87d50: r4 = 59
    //     0xa87d50: mov             x4, #0x3b
    // 0xa87d54: branchIfSmi(r0, 0xa87d60)
    //     0xa87d54: tbz             w0, #0, #0xa87d60
    // 0xa87d58: r4 = LoadClassIdInstr(r0)
    //     0xa87d58: ldur            x4, [x0, #-1]
    //     0xa87d5c: ubfx            x4, x4, #0xc, #0x14
    // 0xa87d60: cmp             x4, #0xdc3
    // 0xa87d64: b.eq            #0xa87d7c
    // 0xa87d68: r8 = _TabControllerScope
    //     0xa87d68: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3ff88] Type: _TabControllerScope
    //     0xa87d6c: ldr             x8, [x8, #0xf88]
    // 0xa87d70: r3 = Null
    //     0xa87d70: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ff90] Null
    //     0xa87d74: ldr             x3, [x3, #0xf90]
    // 0xa87d78: r0 = DefaultTypeTest()
    //     0xa87d78: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa87d7c: ldr             x1, [fp, #0x18]
    // 0xa87d80: LoadField: r2 = r1->field_13
    //     0xa87d80: ldur            w2, [x1, #0x13]
    // 0xa87d84: DecompressPointer r2
    //     0xa87d84: add             x2, x2, HEAP, lsl #32
    // 0xa87d88: ldr             x3, [fp, #0x10]
    // 0xa87d8c: LoadField: r4 = r3->field_13
    //     0xa87d8c: ldur            w4, [x3, #0x13]
    // 0xa87d90: DecompressPointer r4
    //     0xa87d90: add             x4, x4, HEAP, lsl #32
    // 0xa87d94: cmp             w2, w4
    // 0xa87d98: b.eq            #0xa87da4
    // 0xa87d9c: r0 = true
    //     0xa87d9c: add             x0, NULL, #0x20  ; true
    // 0xa87da0: b               #0xa87dc8
    // 0xa87da4: LoadField: r2 = r1->field_f
    //     0xa87da4: ldur            w2, [x1, #0xf]
    // 0xa87da8: DecompressPointer r2
    //     0xa87da8: add             x2, x2, HEAP, lsl #32
    // 0xa87dac: LoadField: r1 = r3->field_f
    //     0xa87dac: ldur            w1, [x3, #0xf]
    // 0xa87db0: DecompressPointer r1
    //     0xa87db0: add             x1, x1, HEAP, lsl #32
    // 0xa87db4: cmp             w2, w1
    // 0xa87db8: r16 = true
    //     0xa87db8: add             x16, NULL, #0x20  ; true
    // 0xa87dbc: r17 = false
    //     0xa87dbc: add             x17, NULL, #0x30  ; false
    // 0xa87dc0: csel            x3, x16, x17, ne
    // 0xa87dc4: mov             x0, x3
    // 0xa87dc8: LeaveFrame
    //     0xa87dc8: mov             SP, fp
    //     0xa87dcc: ldp             fp, lr, [SP], #0x10
    // 0xa87dd0: ret
    //     0xa87dd0: ret             
  }
}

// class id: 4118, size: 0x24, field offset: 0xc
//   const constructor, 
class DefaultTabController extends StatefulWidget {

  static _ maybeOf(/* No info */) {
    // ** addr: 0x7bd23c, size: 0x60
    // 0x7bd23c: EnterFrame
    //     0x7bd23c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd240: mov             fp, SP
    // 0x7bd244: CheckStackOverflow
    //     0x7bd244: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd248: cmp             SP, x16
    //     0x7bd24c: b.ls            #0x7bd294
    // 0x7bd250: r16 = <_TabControllerScope>
    //     0x7bd250: add             x16, PP, #0x37, lsl #12  ; [pp+0x37fd8] TypeArguments: <_TabControllerScope>
    //     0x7bd254: ldr             x16, [x16, #0xfd8]
    // 0x7bd258: ldr             lr, [fp, #0x10]
    // 0x7bd25c: stp             lr, x16, [SP, #-0x10]!
    // 0x7bd260: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x7bd260: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x7bd264: r0 = dependOnInheritedWidgetOfExactType()
    //     0x7bd264: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x7bd268: add             SP, SP, #0x10
    // 0x7bd26c: cmp             w0, NULL
    // 0x7bd270: b.ne            #0x7bd27c
    // 0x7bd274: r0 = Null
    //     0x7bd274: mov             x0, NULL
    // 0x7bd278: b               #0x7bd288
    // 0x7bd27c: LoadField: r1 = r0->field_f
    //     0x7bd27c: ldur            w1, [x0, #0xf]
    // 0x7bd280: DecompressPointer r1
    //     0x7bd280: add             x1, x1, HEAP, lsl #32
    // 0x7bd284: mov             x0, x1
    // 0x7bd288: LeaveFrame
    //     0x7bd288: mov             SP, fp
    //     0x7bd28c: ldp             fp, lr, [SP], #0x10
    // 0x7bd290: ret
    //     0x7bd290: ret             
    // 0x7bd294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd294: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd298: b               #0x7bd250
  }
  _ createState(/* No info */) {
    // ** addr: 0xa416cc, size: 0x28
    // 0xa416cc: EnterFrame
    //     0xa416cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa416d0: mov             fp, SP
    // 0xa416d4: r1 = <DefaultTabController>
    //     0xa416d4: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dfe0] TypeArguments: <DefaultTabController>
    //     0xa416d8: ldr             x1, [x1, #0xfe0]
    // 0xa416dc: r0 = _DefaultTabControllerState()
    //     0xa416dc: bl              #0xa416f4  ; Allocate_DefaultTabControllerStateStub -> _DefaultTabControllerState (size=0x20)
    // 0xa416e0: r1 = Sentinel
    //     0xa416e0: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa416e4: StoreField: r0->field_1b = r1
    //     0xa416e4: stur            w1, [x0, #0x1b]
    // 0xa416e8: LeaveFrame
    //     0xa416e8: mov             SP, fp
    //     0xa416ec: ldp             fp, lr, [SP], #0x10
    // 0xa416f0: ret
    //     0xa416f0: ret             
  }
}

// class id: 4828, size: 0x4c, field offset: 0x24
class TabController extends ChangeNotifier {

  const int dyn:get:length(TabController) {
    // ** addr: 0x79f6b4, size: 0x28
    // 0x79f6b4: ldr             x1, [SP]
    // 0x79f6b8: LoadField: r2 = r1->field_2b
    //     0x79f6b8: ldur            x2, [x1, #0x2b]
    // 0x79f6bc: lsl             x0, x2, #1
    // 0x79f6c0: ret
    //     0x79f6c0: ret             
  }
  _ _copyWith(/* No info */) {
    // ** addr: 0x7bbed8, size: 0x100
    // 0x7bbed8: EnterFrame
    //     0x7bbed8: stp             fp, lr, [SP, #-0x10]!
    //     0x7bbedc: mov             fp, SP
    // 0x7bbee0: AllocStack(0x18)
    //     0x7bbee0: sub             SP, SP, #0x18
    // 0x7bbee4: CheckStackOverflow
    //     0x7bbee4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bbee8: cmp             SP, x16
    //     0x7bbeec: b.ls            #0x7bbfcc
    // 0x7bbef0: ldr             x0, [fp, #0x20]
    // 0x7bbef4: cmp             w0, NULL
    // 0x7bbef8: b.eq            #0x7bbf38
    // 0x7bbefc: ldr             x1, [fp, #0x28]
    // 0x7bbf00: LoadField: r2 = r1->field_23
    //     0x7bbf00: ldur            w2, [x1, #0x23]
    // 0x7bbf04: DecompressPointer r2
    //     0x7bbf04: add             x2, x2, HEAP, lsl #32
    // 0x7bbf08: stur            x2, [fp, #-8]
    // 0x7bbf0c: cmp             w2, NULL
    // 0x7bbf10: b.eq            #0x7bbfd4
    // 0x7bbf14: stp             x0, NULL, [SP, #-0x10]!
    // 0x7bbf18: r0 = _Double.fromInteger()
    //     0x7bbf18: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x7bbf1c: add             SP, SP, #0x10
    // 0x7bbf20: LoadField: d0 = r0->field_7
    //     0x7bbf20: ldur            d0, [x0, #7]
    // 0x7bbf24: ldur            x16, [fp, #-8]
    // 0x7bbf28: SaveReg r16
    //     0x7bbf28: str             x16, [SP, #-8]!
    // 0x7bbf2c: SaveReg d0
    //     0x7bbf2c: str             d0, [SP, #-8]!
    // 0x7bbf30: r0 = value=()
    //     0x7bbf30: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x7bbf34: add             SP, SP, #0x10
    // 0x7bbf38: ldr             x0, [fp, #0x20]
    // 0x7bbf3c: cmp             w0, NULL
    // 0x7bbf40: b.ne            #0x7bbf54
    // 0x7bbf44: ldr             x1, [fp, #0x28]
    // 0x7bbf48: LoadField: r0 = r1->field_33
    //     0x7bbf48: ldur            x0, [x1, #0x33]
    // 0x7bbf4c: mov             x3, x0
    // 0x7bbf50: b               #0x7bbf68
    // 0x7bbf54: ldr             x1, [fp, #0x28]
    // 0x7bbf58: r2 = LoadInt32Instr(r0)
    //     0x7bbf58: sbfx            x2, x0, #1, #0x1f
    //     0x7bbf5c: tbz             w0, #0, #0x7bbf64
    //     0x7bbf60: ldur            x2, [x0, #7]
    // 0x7bbf64: mov             x3, x2
    // 0x7bbf68: ldr             x2, [fp, #0x10]
    // 0x7bbf6c: LoadField: r4 = r1->field_23
    //     0x7bbf6c: ldur            w4, [x1, #0x23]
    // 0x7bbf70: DecompressPointer r4
    //     0x7bbf70: add             x4, x4, HEAP, lsl #32
    // 0x7bbf74: stur            x4, [fp, #-0x10]
    // 0x7bbf78: r0 = BoxInt64Instr(r3)
    //     0x7bbf78: sbfiz           x0, x3, #1, #0x1f
    //     0x7bbf7c: cmp             x3, x0, asr #1
    //     0x7bbf80: b.eq            #0x7bbf8c
    //     0x7bbf84: bl              #0xd69bb8
    //     0x7bbf88: stur            x3, [x0, #7]
    // 0x7bbf8c: stur            x0, [fp, #-8]
    // 0x7bbf90: r0 = TabController()
    //     0x7bbf90: bl              #0x7bc0ac  ; AllocateTabControllerStub -> TabController (size=0x4c)
    // 0x7bbf94: stur            x0, [fp, #-0x18]
    // 0x7bbf98: ldur            x16, [fp, #-0x10]
    // 0x7bbf9c: stp             x16, x0, [SP, #-0x10]!
    // 0x7bbfa0: ldur            x16, [fp, #-8]
    // 0x7bbfa4: ldr             lr, [fp, #0x18]
    // 0x7bbfa8: stp             lr, x16, [SP, #-0x10]!
    // 0x7bbfac: ldr             x1, [fp, #0x10]
    // 0x7bbfb0: SaveReg r1
    //     0x7bbfb0: str             x1, [SP, #-8]!
    // 0x7bbfb4: r0 = TabController._()
    //     0x7bbfb4: bl              #0x7bbfd8  ; [package:flutter/src/material/tab_controller.dart] TabController::TabController._
    // 0x7bbfb8: add             SP, SP, #0x28
    // 0x7bbfbc: ldur            x0, [fp, #-0x18]
    // 0x7bbfc0: LeaveFrame
    //     0x7bbfc0: mov             SP, fp
    //     0x7bbfc4: ldp             fp, lr, [SP], #0x10
    // 0x7bbfc8: ret
    //     0x7bbfc8: ret             
    // 0x7bbfcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bbfcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bbfd0: b               #0x7bbef0
    // 0x7bbfd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bbfd4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ TabController._(/* No info */) {
    // ** addr: 0x7bbfd8, size: 0xd4
    // 0x7bbfd8: EnterFrame
    //     0x7bbfd8: stp             fp, lr, [SP, #-0x10]!
    //     0x7bbfdc: mov             fp, SP
    // 0x7bbfe0: r2 = Instance_Duration
    //     0x7bbfe0: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x7bbfe4: ldr             x2, [x2, #0xc88]
    // 0x7bbfe8: r1 = 0
    //     0x7bbfe8: mov             x1, #0
    // 0x7bbfec: CheckStackOverflow
    //     0x7bbfec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bbff0: cmp             SP, x16
    //     0x7bbff4: b.ls            #0x7bc0a4
    // 0x7bbff8: ldr             x3, [fp, #0x30]
    // 0x7bbffc: StoreField: r3->field_43 = r1
    //     0x7bbffc: stur            x1, [x3, #0x43]
    // 0x7bc000: ldr             x0, [fp, #0x18]
    // 0x7bc004: r4 = LoadInt32Instr(r0)
    //     0x7bc004: sbfx            x4, x0, #1, #0x1f
    // 0x7bc008: StoreField: r3->field_2b = r4
    //     0x7bc008: stur            x4, [x3, #0x2b]
    // 0x7bc00c: ldr             x0, [fp, #0x20]
    // 0x7bc010: r4 = LoadInt32Instr(r0)
    //     0x7bc010: sbfx            x4, x0, #1, #0x1f
    //     0x7bc014: tbz             w0, #0, #0x7bc01c
    //     0x7bc018: ldur            x4, [x0, #7]
    // 0x7bc01c: StoreField: r3->field_33 = r4
    //     0x7bc01c: stur            x4, [x3, #0x33]
    // 0x7bc020: ldr             x0, [fp, #0x10]
    // 0x7bc024: StoreField: r3->field_3b = r0
    //     0x7bc024: stur            x0, [x3, #0x3b]
    // 0x7bc028: ldr             x0, [fp, #0x28]
    // 0x7bc02c: StoreField: r3->field_23 = r0
    //     0x7bc02c: stur            w0, [x3, #0x23]
    //     0x7bc030: ldurb           w16, [x3, #-1]
    //     0x7bc034: ldurb           w17, [x0, #-1]
    //     0x7bc038: and             x16, x17, x16, lsr #2
    //     0x7bc03c: tst             x16, HEAP, lsr #32
    //     0x7bc040: b.eq            #0x7bc048
    //     0x7bc044: bl              #0xd682ac
    // 0x7bc048: StoreField: r3->field_27 = r2
    //     0x7bc048: stur            w2, [x3, #0x27]
    // 0x7bc04c: StoreField: r3->field_7 = r1
    //     0x7bc04c: stur            x1, [x3, #7]
    // 0x7bc050: StoreField: r3->field_13 = r1
    //     0x7bc050: stur            x1, [x3, #0x13]
    // 0x7bc054: StoreField: r3->field_1b = r1
    //     0x7bc054: stur            x1, [x3, #0x1b]
    // 0x7bc058: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x7bc058: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7bc05c: ldr             x0, [x0, #0x1580]
    //     0x7bc060: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7bc064: cmp             w0, w16
    //     0x7bc068: b.ne            #0x7bc074
    //     0x7bc06c: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x7bc070: bl              #0xd67cdc
    // 0x7bc074: ldr             x1, [fp, #0x30]
    // 0x7bc078: StoreField: r1->field_f = r0
    //     0x7bc078: stur            w0, [x1, #0xf]
    //     0x7bc07c: ldurb           w16, [x1, #-1]
    //     0x7bc080: ldurb           w17, [x0, #-1]
    //     0x7bc084: and             x16, x17, x16, lsr #2
    //     0x7bc088: tst             x16, HEAP, lsr #32
    //     0x7bc08c: b.eq            #0x7bc094
    //     0x7bc090: bl              #0xd6826c
    // 0x7bc094: r0 = Null
    //     0x7bc094: mov             x0, NULL
    // 0x7bc098: LeaveFrame
    //     0x7bc098: mov             SP, fp
    //     0x7bc09c: ldp             fp, lr, [SP], #0x10
    // 0x7bc0a0: ret
    //     0x7bc0a0: ret             
    // 0x7bc0a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bc0a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bc0a8: b               #0x7bbff8
  }
  _ animateTo(/* No info */) {
    // ** addr: 0x8262c8, size: 0xb4
    // 0x8262c8: EnterFrame
    //     0x8262c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8262cc: mov             fp, SP
    // 0x8262d0: mov             x0, x4
    // 0x8262d4: LoadField: r1 = r0->field_13
    //     0x8262d4: ldur            w1, [x0, #0x13]
    // 0x8262d8: DecompressPointer r1
    //     0x8262d8: add             x1, x1, HEAP, lsl #32
    // 0x8262dc: sub             x2, x1, #4
    // 0x8262e0: add             x3, fp, w2, sxtw #2
    // 0x8262e4: ldr             x3, [x3, #0x18]
    // 0x8262e8: add             x4, fp, w2, sxtw #2
    // 0x8262ec: ldr             x4, [x4, #0x10]
    // 0x8262f0: LoadField: r2 = r0->field_1f
    //     0x8262f0: ldur            w2, [x0, #0x1f]
    // 0x8262f4: DecompressPointer r2
    //     0x8262f4: add             x2, x2, HEAP, lsl #32
    // 0x8262f8: r16 = "duration"
    //     0x8262f8: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x8262fc: ldr             x16, [x16, #0xfd8]
    // 0x826300: cmp             w2, w16
    // 0x826304: b.ne            #0x826324
    // 0x826308: LoadField: r2 = r0->field_23
    //     0x826308: ldur            w2, [x0, #0x23]
    // 0x82630c: DecompressPointer r2
    //     0x82630c: add             x2, x2, HEAP, lsl #32
    // 0x826310: sub             w0, w1, w2
    // 0x826314: add             x1, fp, w0, sxtw #2
    // 0x826318: ldr             x1, [x1, #8]
    // 0x82631c: mov             x0, x1
    // 0x826320: b               #0x826328
    // 0x826324: r0 = Null
    //     0x826324: mov             x0, NULL
    // 0x826328: CheckStackOverflow
    //     0x826328: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82632c: cmp             SP, x16
    //     0x826330: b.ls            #0x826374
    // 0x826334: cmp             w0, NULL
    // 0x826338: b.ne            #0x826344
    // 0x82633c: r0 = Instance_Duration
    //     0x82633c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x826340: ldr             x0, [x0, #0xc88]
    // 0x826344: stp             x4, x3, [SP, #-0x10]!
    // 0x826348: r16 = Instance_Cubic
    //     0x826348: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x82634c: ldr             x16, [x16, #0xfc8]
    // 0x826350: stp             x16, x0, [SP, #-0x10]!
    // 0x826354: r4 = const [0, 0x4, 0x4, 0x2, curve, 0x3, duration, 0x2, null]
    //     0x826354: add             x4, PP, #0x27, lsl #12  ; [pp+0x272a0] List(9) [0, 0x4, 0x4, 0x2, "curve", 0x3, "duration", 0x2, Null]
    //     0x826358: ldr             x4, [x4, #0x2a0]
    // 0x82635c: r0 = _changeIndex()
    //     0x82635c: bl              #0x82637c  ; [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex
    // 0x826360: add             SP, SP, #0x20
    // 0x826364: r0 = Null
    //     0x826364: mov             x0, NULL
    // 0x826368: LeaveFrame
    //     0x826368: mov             SP, fp
    //     0x82636c: ldp             fp, lr, [SP], #0x10
    // 0x826370: ret
    //     0x826370: ret             
    // 0x826374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826378: b               #0x826334
  }
  _ _changeIndex(/* No info */) {
    // ** addr: 0x82637c, size: 0x298
    // 0x82637c: EnterFrame
    //     0x82637c: stp             fp, lr, [SP, #-0x10]!
    //     0x826380: mov             fp, SP
    // 0x826384: AllocStack(0x30)
    //     0x826384: sub             SP, SP, #0x30
    // 0x826388: SetupParameters(TabController this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, {dynamic curve = Null /* r5, fp-0x10 */, dynamic duration = Null /* r0, fp-0x8 */})
    //     0x826388: mov             x0, x4
    //     0x82638c: ldur            w1, [x0, #0x13]
    //     0x826390: add             x1, x1, HEAP, lsl #32
    //     0x826394: sub             x2, x1, #4
    //     0x826398: add             x3, fp, w2, sxtw #2
    //     0x82639c: ldr             x3, [x3, #0x18]
    //     0x8263a0: stur            x3, [fp, #-0x20]
    //     0x8263a4: add             x4, fp, w2, sxtw #2
    //     0x8263a8: ldr             x4, [x4, #0x10]
    //     0x8263ac: stur            x4, [fp, #-0x18]
    //     0x8263b0: ldur            w2, [x0, #0x1f]
    //     0x8263b4: add             x2, x2, HEAP, lsl #32
    //     0x8263b8: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc0] "curve"
    //     0x8263bc: ldr             x16, [x16, #0xfc0]
    //     0x8263c0: cmp             w2, w16
    //     0x8263c4: b.ne            #0x8263e8
    //     0x8263c8: ldur            w2, [x0, #0x23]
    //     0x8263cc: add             x2, x2, HEAP, lsl #32
    //     0x8263d0: sub             w5, w1, w2
    //     0x8263d4: add             x2, fp, w5, sxtw #2
    //     0x8263d8: ldr             x2, [x2, #8]
    //     0x8263dc: mov             x5, x2
    //     0x8263e0: mov             x2, #1
    //     0x8263e4: b               #0x8263f0
    //     0x8263e8: mov             x5, NULL
    //     0x8263ec: mov             x2, #0
    //     0x8263f0: stur            x5, [fp, #-0x10]
    //     0x8263f4: lsl             x6, x2, #1
    //     0x8263f8: lsl             w2, w6, #1
    //     0x8263fc: add             w6, w2, #8
    //     0x826400: add             x16, x0, w6, sxtw #1
    //     0x826404: ldur            w7, [x16, #0xf]
    //     0x826408: add             x7, x7, HEAP, lsl #32
    //     0x82640c: add             x16, PP, #0xa, lsl #12  ; [pp+0xafd8] "duration"
    //     0x826410: ldr             x16, [x16, #0xfd8]
    //     0x826414: cmp             w7, w16
    //     0x826418: b.ne            #0x826440
    //     0x82641c: add             w6, w2, #0xa
    //     0x826420: add             x16, x0, w6, sxtw #1
    //     0x826424: ldur            w2, [x16, #0xf]
    //     0x826428: add             x2, x2, HEAP, lsl #32
    //     0x82642c: sub             w0, w1, w2
    //     0x826430: add             x1, fp, w0, sxtw #2
    //     0x826434: ldr             x1, [x1, #8]
    //     0x826438: mov             x0, x1
    //     0x82643c: b               #0x826444
    //     0x826440: mov             x0, NULL
    //     0x826444: stur            x0, [fp, #-8]
    // 0x826448: CheckStackOverflow
    //     0x826448: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82644c: cmp             SP, x16
    //     0x826450: b.ls            #0x826600
    // 0x826454: r1 = 1
    //     0x826454: mov             x1, #1
    // 0x826458: r0 = AllocateContext()
    //     0x826458: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82645c: mov             x1, x0
    // 0x826460: ldur            x0, [fp, #-0x20]
    // 0x826464: stur            x1, [fp, #-0x28]
    // 0x826468: StoreField: r1->field_f = r0
    //     0x826468: stur            w0, [x1, #0xf]
    // 0x82646c: LoadField: r2 = r0->field_33
    //     0x82646c: ldur            x2, [x0, #0x33]
    // 0x826470: ldur            x3, [fp, #-0x18]
    // 0x826474: cmp             x3, x2
    // 0x826478: b.eq            #0x826488
    // 0x82647c: LoadField: r4 = r0->field_2b
    //     0x82647c: ldur            x4, [x0, #0x2b]
    // 0x826480: cmp             x4, #2
    // 0x826484: b.ge            #0x826498
    // 0x826488: r0 = Null
    //     0x826488: mov             x0, NULL
    // 0x82648c: LeaveFrame
    //     0x82648c: mov             SP, fp
    //     0x826490: ldp             fp, lr, [SP], #0x10
    // 0x826494: ret
    //     0x826494: ret             
    // 0x826498: ldur            x4, [fp, #-8]
    // 0x82649c: StoreField: r0->field_3b = r2
    //     0x82649c: stur            x2, [x0, #0x3b]
    // 0x8264a0: StoreField: r0->field_33 = r3
    //     0x8264a0: stur            x3, [x0, #0x33]
    // 0x8264a4: cmp             w4, NULL
    // 0x8264a8: b.eq            #0x826578
    // 0x8264ac: LoadField: r2 = r4->field_7
    //     0x8264ac: ldur            x2, [x4, #7]
    // 0x8264b0: cmp             x2, #0
    // 0x8264b4: b.le            #0x826570
    // 0x8264b8: ldur            x2, [fp, #-0x10]
    // 0x8264bc: LoadField: r3 = r0->field_43
    //     0x8264bc: ldur            x3, [x0, #0x43]
    // 0x8264c0: add             x5, x3, #1
    // 0x8264c4: StoreField: r0->field_43 = r5
    //     0x8264c4: stur            x5, [x0, #0x43]
    // 0x8264c8: SaveReg r0
    //     0x8264c8: str             x0, [SP, #-8]!
    // 0x8264cc: r0 = notifyListeners()
    //     0x8264cc: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x8264d0: add             SP, SP, #8
    // 0x8264d4: ldur            x2, [fp, #-0x20]
    // 0x8264d8: LoadField: r3 = r2->field_23
    //     0x8264d8: ldur            w3, [x2, #0x23]
    // 0x8264dc: DecompressPointer r3
    //     0x8264dc: add             x3, x3, HEAP, lsl #32
    // 0x8264e0: stur            x3, [fp, #-0x30]
    // 0x8264e4: cmp             w3, NULL
    // 0x8264e8: b.eq            #0x826608
    // 0x8264ec: LoadField: r4 = r2->field_33
    //     0x8264ec: ldur            x4, [x2, #0x33]
    // 0x8264f0: r0 = BoxInt64Instr(r4)
    //     0x8264f0: sbfiz           x0, x4, #1, #0x1f
    //     0x8264f4: cmp             x4, x0, asr #1
    //     0x8264f8: b.eq            #0x826504
    //     0x8264fc: bl              #0xd69bb8
    //     0x826500: stur            x4, [x0, #7]
    // 0x826504: stp             x0, NULL, [SP, #-0x10]!
    // 0x826508: r0 = _Double.fromInteger()
    //     0x826508: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x82650c: add             SP, SP, #0x10
    // 0x826510: mov             x1, x0
    // 0x826514: ldur            x0, [fp, #-0x10]
    // 0x826518: cmp             w0, NULL
    // 0x82651c: b.eq            #0x82660c
    // 0x826520: LoadField: d0 = r1->field_7
    //     0x826520: ldur            d0, [x1, #7]
    // 0x826524: ldur            x16, [fp, #-0x30]
    // 0x826528: SaveReg r16
    //     0x826528: str             x16, [SP, #-8]!
    // 0x82652c: SaveReg d0
    //     0x82652c: str             d0, [SP, #-8]!
    // 0x826530: ldur            x16, [fp, #-8]
    // 0x826534: stp             x0, x16, [SP, #-0x10]!
    // 0x826538: r4 = const [0, 0x4, 0x4, 0x2, curve, 0x3, duration, 0x2, null]
    //     0x826538: add             x4, PP, #0x27, lsl #12  ; [pp+0x272a0] List(9) [0, 0x4, 0x4, 0x2, "curve", 0x3, "duration", 0x2, Null]
    //     0x82653c: ldr             x4, [x4, #0x2a0]
    // 0x826540: r0 = animateTo()
    //     0x826540: bl              #0x7a8100  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x826544: add             SP, SP, #0x20
    // 0x826548: ldur            x2, [fp, #-0x28]
    // 0x82654c: r1 = Function '<anonymous closure>':.
    //     0x82654c: add             x1, PP, #0x27, lsl #12  ; [pp+0x272a8] AnonymousClosure: (0x826614), in [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex (0x82637c)
    //     0x826550: ldr             x1, [x1, #0x2a8]
    // 0x826554: stur            x0, [fp, #-8]
    // 0x826558: r0 = AllocateClosure()
    //     0x826558: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x82655c: ldur            x16, [fp, #-8]
    // 0x826560: stp             x0, x16, [SP, #-0x10]!
    // 0x826564: r0 = whenCompleteOrCancel()
    //     0x826564: bl              #0x514a6c  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::whenCompleteOrCancel
    // 0x826568: add             SP, SP, #0x10
    // 0x82656c: b               #0x8265f0
    // 0x826570: mov             x2, x0
    // 0x826574: b               #0x82657c
    // 0x826578: mov             x2, x0
    // 0x82657c: LoadField: r0 = r2->field_43
    //     0x82657c: ldur            x0, [x2, #0x43]
    // 0x826580: add             x1, x0, #1
    // 0x826584: StoreField: r2->field_43 = r1
    //     0x826584: stur            x1, [x2, #0x43]
    // 0x826588: LoadField: r4 = r2->field_23
    //     0x826588: ldur            w4, [x2, #0x23]
    // 0x82658c: DecompressPointer r4
    //     0x82658c: add             x4, x4, HEAP, lsl #32
    // 0x826590: stur            x4, [fp, #-8]
    // 0x826594: cmp             w4, NULL
    // 0x826598: b.eq            #0x826610
    // 0x82659c: r0 = BoxInt64Instr(r3)
    //     0x82659c: sbfiz           x0, x3, #1, #0x1f
    //     0x8265a0: cmp             x3, x0, asr #1
    //     0x8265a4: b.eq            #0x8265b0
    //     0x8265a8: bl              #0xd69bb8
    //     0x8265ac: stur            x3, [x0, #7]
    // 0x8265b0: stp             x0, NULL, [SP, #-0x10]!
    // 0x8265b4: r0 = _Double.fromInteger()
    //     0x8265b4: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x8265b8: add             SP, SP, #0x10
    // 0x8265bc: LoadField: d0 = r0->field_7
    //     0x8265bc: ldur            d0, [x0, #7]
    // 0x8265c0: ldur            x16, [fp, #-8]
    // 0x8265c4: SaveReg r16
    //     0x8265c4: str             x16, [SP, #-8]!
    // 0x8265c8: SaveReg d0
    //     0x8265c8: str             d0, [SP, #-8]!
    // 0x8265cc: r0 = value=()
    //     0x8265cc: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x8265d0: add             SP, SP, #0x10
    // 0x8265d4: ldur            x0, [fp, #-0x20]
    // 0x8265d8: LoadField: r1 = r0->field_43
    //     0x8265d8: ldur            x1, [x0, #0x43]
    // 0x8265dc: sub             x2, x1, #1
    // 0x8265e0: StoreField: r0->field_43 = r2
    //     0x8265e0: stur            x2, [x0, #0x43]
    // 0x8265e4: SaveReg r0
    //     0x8265e4: str             x0, [SP, #-8]!
    // 0x8265e8: r0 = notifyListeners()
    //     0x8265e8: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x8265ec: add             SP, SP, #8
    // 0x8265f0: r0 = Null
    //     0x8265f0: mov             x0, NULL
    // 0x8265f4: LeaveFrame
    //     0x8265f4: mov             SP, fp
    //     0x8265f8: ldp             fp, lr, [SP], #0x10
    // 0x8265fc: ret
    //     0x8265fc: ret             
    // 0x826600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826600: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826604: b               #0x826454
    // 0x826608: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x826608: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82660c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82660c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x826610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x826610: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x826614, size: 0x68
    // 0x826614: EnterFrame
    //     0x826614: stp             fp, lr, [SP, #-0x10]!
    //     0x826618: mov             fp, SP
    // 0x82661c: ldr             x0, [fp, #0x10]
    // 0x826620: LoadField: r1 = r0->field_17
    //     0x826620: ldur            w1, [x0, #0x17]
    // 0x826624: DecompressPointer r1
    //     0x826624: add             x1, x1, HEAP, lsl #32
    // 0x826628: CheckStackOverflow
    //     0x826628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82662c: cmp             SP, x16
    //     0x826630: b.ls            #0x826674
    // 0x826634: LoadField: r0 = r1->field_f
    //     0x826634: ldur            w0, [x1, #0xf]
    // 0x826638: DecompressPointer r0
    //     0x826638: add             x0, x0, HEAP, lsl #32
    // 0x82663c: LoadField: r1 = r0->field_23
    //     0x82663c: ldur            w1, [x0, #0x23]
    // 0x826640: DecompressPointer r1
    //     0x826640: add             x1, x1, HEAP, lsl #32
    // 0x826644: cmp             w1, NULL
    // 0x826648: b.eq            #0x826664
    // 0x82664c: LoadField: r1 = r0->field_43
    //     0x82664c: ldur            x1, [x0, #0x43]
    // 0x826650: sub             x2, x1, #1
    // 0x826654: StoreField: r0->field_43 = r2
    //     0x826654: stur            x2, [x0, #0x43]
    // 0x826658: SaveReg r0
    //     0x826658: str             x0, [SP, #-8]!
    // 0x82665c: r0 = notifyListeners()
    //     0x82665c: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x826660: add             SP, SP, #8
    // 0x826664: r0 = Null
    //     0x826664: mov             x0, NULL
    // 0x826668: LeaveFrame
    //     0x826668: mov             SP, fp
    //     0x82666c: ldp             fp, lr, [SP], #0x10
    // 0x826670: ret
    //     0x826670: ret             
    // 0x826674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826678: b               #0x826634
  }
  set _ offset=(/* No info */) {
    // ** addr: 0x8341b8, size: 0xc4
    // 0x8341b8: EnterFrame
    //     0x8341b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8341bc: mov             fp, SP
    // 0x8341c0: AllocStack(0x8)
    //     0x8341c0: sub             SP, SP, #8
    // 0x8341c4: CheckStackOverflow
    //     0x8341c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8341c8: cmp             SP, x16
    //     0x8341cc: b.ls            #0x834270
    // 0x8341d0: ldr             x16, [fp, #0x18]
    // 0x8341d4: SaveReg r16
    //     0x8341d4: str             x16, [SP, #-8]!
    // 0x8341d8: r0 = offset()
    //     0x8341d8: bl              #0x83427c  ; [package:flutter/src/material/tab_controller.dart] TabController::offset
    // 0x8341dc: add             SP, SP, #8
    // 0x8341e0: mov             v1.16b, v0.16b
    // 0x8341e4: ldr             d0, [fp, #0x10]
    // 0x8341e8: fcmp            d0, d1
    // 0x8341ec: b.vs            #0x834204
    // 0x8341f0: b.ne            #0x834204
    // 0x8341f4: r0 = Null
    //     0x8341f4: mov             x0, NULL
    // 0x8341f8: LeaveFrame
    //     0x8341f8: mov             SP, fp
    //     0x8341fc: ldp             fp, lr, [SP], #0x10
    // 0x834200: ret
    //     0x834200: ret             
    // 0x834204: ldr             x0, [fp, #0x18]
    // 0x834208: LoadField: r2 = r0->field_23
    //     0x834208: ldur            w2, [x0, #0x23]
    // 0x83420c: DecompressPointer r2
    //     0x83420c: add             x2, x2, HEAP, lsl #32
    // 0x834210: stur            x2, [fp, #-8]
    // 0x834214: cmp             w2, NULL
    // 0x834218: b.eq            #0x834278
    // 0x83421c: LoadField: r3 = r0->field_33
    //     0x83421c: ldur            x3, [x0, #0x33]
    // 0x834220: r0 = BoxInt64Instr(r3)
    //     0x834220: sbfiz           x0, x3, #1, #0x1f
    //     0x834224: cmp             x3, x0, asr #1
    //     0x834228: b.eq            #0x834234
    //     0x83422c: bl              #0xd69c6c
    //     0x834230: stur            x3, [x0, #7]
    // 0x834234: stp             x0, NULL, [SP, #-0x10]!
    // 0x834238: r0 = _Double.fromInteger()
    //     0x834238: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x83423c: add             SP, SP, #0x10
    // 0x834240: LoadField: d0 = r0->field_7
    //     0x834240: ldur            d0, [x0, #7]
    // 0x834244: ldr             d1, [fp, #0x10]
    // 0x834248: fadd            d2, d1, d0
    // 0x83424c: ldur            x16, [fp, #-8]
    // 0x834250: SaveReg r16
    //     0x834250: str             x16, [SP, #-8]!
    // 0x834254: SaveReg d2
    //     0x834254: str             d2, [SP, #-8]!
    // 0x834258: r0 = value=()
    //     0x834258: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x83425c: add             SP, SP, #0x10
    // 0x834260: r0 = Null
    //     0x834260: mov             x0, NULL
    // 0x834264: LeaveFrame
    //     0x834264: mov             SP, fp
    //     0x834268: ldp             fp, lr, [SP], #0x10
    // 0x83426c: ret
    //     0x83426c: ret             
    // 0x834270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834270: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834274: b               #0x8341d0
    // 0x834278: r0 = NullCastErrorSharedWithFPURegs()
    //     0x834278: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ offset(/* No info */) {
    // ** addr: 0x83427c, size: 0xa0
    // 0x83427c: EnterFrame
    //     0x83427c: stp             fp, lr, [SP, #-0x10]!
    //     0x834280: mov             fp, SP
    // 0x834284: AllocStack(0x8)
    //     0x834284: sub             SP, SP, #8
    // 0x834288: CheckStackOverflow
    //     0x834288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83428c: cmp             SP, x16
    //     0x834290: b.ls            #0x834304
    // 0x834294: ldr             x0, [fp, #0x10]
    // 0x834298: LoadField: r1 = r0->field_23
    //     0x834298: ldur            w1, [x0, #0x23]
    // 0x83429c: DecompressPointer r1
    //     0x83429c: add             x1, x1, HEAP, lsl #32
    // 0x8342a0: cmp             w1, NULL
    // 0x8342a4: b.eq            #0x83430c
    // 0x8342a8: LoadField: r2 = r1->field_37
    //     0x8342a8: ldur            w2, [x1, #0x37]
    // 0x8342ac: DecompressPointer r2
    //     0x8342ac: add             x2, x2, HEAP, lsl #32
    // 0x8342b0: r16 = Sentinel
    //     0x8342b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8342b4: cmp             w2, w16
    // 0x8342b8: b.eq            #0x834310
    // 0x8342bc: stur            x2, [fp, #-8]
    // 0x8342c0: LoadField: r3 = r0->field_33
    //     0x8342c0: ldur            x3, [x0, #0x33]
    // 0x8342c4: r0 = BoxInt64Instr(r3)
    //     0x8342c4: sbfiz           x0, x3, #1, #0x1f
    //     0x8342c8: cmp             x3, x0, asr #1
    //     0x8342cc: b.eq            #0x8342d8
    //     0x8342d0: bl              #0xd69bb8
    //     0x8342d4: stur            x3, [x0, #7]
    // 0x8342d8: stp             x0, NULL, [SP, #-0x10]!
    // 0x8342dc: r0 = _Double.fromInteger()
    //     0x8342dc: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x8342e0: add             SP, SP, #0x10
    // 0x8342e4: mov             x1, x0
    // 0x8342e8: ldur            x0, [fp, #-8]
    // 0x8342ec: LoadField: d1 = r0->field_7
    //     0x8342ec: ldur            d1, [x0, #7]
    // 0x8342f0: LoadField: d2 = r1->field_7
    //     0x8342f0: ldur            d2, [x1, #7]
    // 0x8342f4: fsub            d0, d1, d2
    // 0x8342f8: LeaveFrame
    //     0x8342f8: mov             SP, fp
    //     0x8342fc: ldp             fp, lr, [SP], #0x10
    // 0x834300: ret
    //     0x834300: ret             
    // 0x834304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834304: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834308: b               #0x834294
    // 0x83430c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83430c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x834310: r9 = _value
    //     0x834310: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x834314: ldr             x9, [x9, #0xbb0]
    // 0x834318: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x834318: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0x9ba268, size: 0x18
    // 0x9ba268: r4 = 0
    //     0x9ba268: mov             x4, #0
    // 0x9ba26c: r1 = Function 'dispose':.
    //     0x9ba26c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b580] AnonymousClosure: (0x9ba280), in [package:flutter/src/material/tab_controller.dart] TabController::dispose (0x9c2804)
    //     0x9ba270: ldr             x1, [x17, #0x580]
    // 0x9ba274: r24 = BuildNonGenericMethodExtractorStub
    //     0x9ba274: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x9ba278: LoadField: r0 = r24->field_17
    //     0x9ba278: ldur            x0, [x24, #0x17]
    // 0x9ba27c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0x9ba280, size: 0x48
    // 0x9ba280: EnterFrame
    //     0x9ba280: stp             fp, lr, [SP, #-0x10]!
    //     0x9ba284: mov             fp, SP
    // 0x9ba288: ldr             x0, [fp, #0x10]
    // 0x9ba28c: LoadField: r1 = r0->field_17
    //     0x9ba28c: ldur            w1, [x0, #0x17]
    // 0x9ba290: DecompressPointer r1
    //     0x9ba290: add             x1, x1, HEAP, lsl #32
    // 0x9ba294: CheckStackOverflow
    //     0x9ba294: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ba298: cmp             SP, x16
    //     0x9ba29c: b.ls            #0x9ba2c0
    // 0x9ba2a0: LoadField: r0 = r1->field_f
    //     0x9ba2a0: ldur            w0, [x1, #0xf]
    // 0x9ba2a4: DecompressPointer r0
    //     0x9ba2a4: add             x0, x0, HEAP, lsl #32
    // 0x9ba2a8: SaveReg r0
    //     0x9ba2a8: str             x0, [SP, #-8]!
    // 0x9ba2ac: r0 = dispose()
    //     0x9ba2ac: bl              #0x9c2804  ; [package:flutter/src/material/tab_controller.dart] TabController::dispose
    // 0x9ba2b0: add             SP, SP, #8
    // 0x9ba2b4: LeaveFrame
    //     0x9ba2b4: mov             SP, fp
    //     0x9ba2b8: ldp             fp, lr, [SP], #0x10
    // 0x9ba2bc: ret
    //     0x9ba2bc: ret             
    // 0x9ba2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba2c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba2c4: b               #0x9ba2a0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9c2804, size: 0x60
    // 0x9c2804: EnterFrame
    //     0x9c2804: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2808: mov             fp, SP
    // 0x9c280c: CheckStackOverflow
    //     0x9c280c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9c2810: cmp             SP, x16
    //     0x9c2814: b.ls            #0x9c285c
    // 0x9c2818: ldr             x0, [fp, #0x10]
    // 0x9c281c: LoadField: r1 = r0->field_23
    //     0x9c281c: ldur            w1, [x0, #0x23]
    // 0x9c2820: DecompressPointer r1
    //     0x9c2820: add             x1, x1, HEAP, lsl #32
    // 0x9c2824: cmp             w1, NULL
    // 0x9c2828: b.eq            #0x9c283c
    // 0x9c282c: SaveReg r1
    //     0x9c282c: str             x1, [SP, #-8]!
    // 0x9c2830: r0 = dispose()
    //     0x9c2830: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x9c2834: add             SP, SP, #8
    // 0x9c2838: ldr             x0, [fp, #0x10]
    // 0x9c283c: StoreField: r0->field_23 = rNULL
    //     0x9c283c: stur            NULL, [x0, #0x23]
    // 0x9c2840: SaveReg r0
    //     0x9c2840: str             x0, [SP, #-8]!
    // 0x9c2844: r0 = dispose()
    //     0x9c2844: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x9c2848: add             SP, SP, #8
    // 0x9c284c: r0 = Null
    //     0x9c284c: mov             x0, NULL
    // 0x9c2850: LeaveFrame
    //     0x9c2850: mov             SP, fp
    //     0x9c2854: ldp             fp, lr, [SP], #0x10
    // 0x9c2858: ret
    //     0x9c2858: ret             
    // 0x9c285c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c285c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2860: b               #0x9c2818
  }
  _ TabController(/* No info */) {
    // ** addr: 0x9d5af4, size: 0x184
    // 0x9d5af4: EnterFrame
    //     0x9d5af4: stp             fp, lr, [SP, #-0x10]!
    //     0x9d5af8: mov             fp, SP
    // 0x9d5afc: AllocStack(0x20)
    //     0x9d5afc: sub             SP, SP, #0x20
    // 0x9d5b00: SetupParameters(TabController this /* r3, fp-0x10 */, dynamic _ /* r4 */, dynamic _ /* r5, fp-0x8 */, {int initialIndex = 0 /* r6 */})
    //     0x9d5b00: mov             x0, x4
    //     0x9d5b04: ldur            w1, [x0, #0x13]
    //     0x9d5b08: add             x1, x1, HEAP, lsl #32
    //     0x9d5b0c: sub             x2, x1, #6
    //     0x9d5b10: add             x3, fp, w2, sxtw #2
    //     0x9d5b14: ldr             x3, [x3, #0x20]
    //     0x9d5b18: stur            x3, [fp, #-0x10]
    //     0x9d5b1c: add             x4, fp, w2, sxtw #2
    //     0x9d5b20: ldr             x4, [x4, #0x18]
    //     0x9d5b24: add             x5, fp, w2, sxtw #2
    //     0x9d5b28: ldr             x5, [x5, #0x10]
    //     0x9d5b2c: stur            x5, [fp, #-8]
    //     0x9d5b30: ldur            w2, [x0, #0x1f]
    //     0x9d5b34: add             x2, x2, HEAP, lsl #32
    //     0x9d5b38: add             x16, PP, #0x27, lsl #12  ; [pp+0x270d0] "initialIndex"
    //     0x9d5b3c: ldr             x16, [x16, #0xd0]
    //     0x9d5b40: cmp             w2, w16
    //     0x9d5b44: b.ne            #0x9d5b70
    //     0x9d5b48: ldur            w2, [x0, #0x23]
    //     0x9d5b4c: add             x2, x2, HEAP, lsl #32
    //     0x9d5b50: sub             w0, w1, w2
    //     0x9d5b54: add             x1, fp, w0, sxtw #2
    //     0x9d5b58: ldr             x1, [x1, #8]
    //     0x9d5b5c: sbfx            x0, x1, #1, #0x1f
    //     0x9d5b60: tbz             w1, #0, #0x9d5b68
    //     0x9d5b64: ldur            x0, [x1, #7]
    //     0x9d5b68: mov             x6, x0
    //     0x9d5b6c: b               #0x9d5b74
    //     0x9d5b70: mov             x6, #0
    //     0x9d5b74: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x9d5b78: ldr             x0, [x0, #0xc88]
    //     0x9d5b7c: mov             x2, #0
    // 0x9d5b74: r0 = Instance_Duration
    // 0x9d5b7c: r2 = 0
    // 0x9d5b80: CheckStackOverflow
    //     0x9d5b80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d5b84: cmp             SP, x16
    //     0x9d5b88: b.ls            #0x9d5c70
    // 0x9d5b8c: StoreField: r3->field_43 = r2
    //     0x9d5b8c: stur            x2, [x3, #0x43]
    // 0x9d5b90: StoreField: r3->field_2b = r4
    //     0x9d5b90: stur            x4, [x3, #0x2b]
    // 0x9d5b94: StoreField: r3->field_33 = r6
    //     0x9d5b94: stur            x6, [x3, #0x33]
    // 0x9d5b98: StoreField: r3->field_3b = r6
    //     0x9d5b98: stur            x6, [x3, #0x3b]
    // 0x9d5b9c: StoreField: r3->field_27 = r0
    //     0x9d5b9c: stur            w0, [x3, #0x27]
    // 0x9d5ba0: r0 = BoxInt64Instr(r6)
    //     0x9d5ba0: sbfiz           x0, x6, #1, #0x1f
    //     0x9d5ba4: cmp             x6, x0, asr #1
    //     0x9d5ba8: b.eq            #0x9d5bb4
    //     0x9d5bac: bl              #0xd69bb8
    //     0x9d5bb0: stur            x6, [x0, #7]
    // 0x9d5bb4: stp             x0, NULL, [SP, #-0x10]!
    // 0x9d5bb8: r0 = _Double.fromInteger()
    //     0x9d5bb8: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x9d5bbc: add             SP, SP, #0x10
    // 0x9d5bc0: r1 = <double>
    //     0x9d5bc0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d5bc4: stur            x0, [fp, #-0x18]
    // 0x9d5bc8: r0 = AnimationController()
    //     0x9d5bc8: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d5bcc: stur            x0, [fp, #-0x20]
    // 0x9d5bd0: ldur            x16, [fp, #-8]
    // 0x9d5bd4: stp             x16, x0, [SP, #-0x10]!
    // 0x9d5bd8: ldur            x16, [fp, #-0x18]
    // 0x9d5bdc: SaveReg r16
    //     0x9d5bdc: str             x16, [SP, #-8]!
    // 0x9d5be0: r4 = const [0, 0x3, 0x3, 0x2, value, 0x2, null]
    //     0x9d5be0: add             x4, PP, #0x27, lsl #12  ; [pp+0x270d8] List(7) [0, 0x3, 0x3, 0x2, "value", 0x2, Null]
    //     0x9d5be4: ldr             x4, [x4, #0xd8]
    // 0x9d5be8: r0 = AnimationController.unbounded()
    //     0x9d5be8: bl              #0x9d5c78  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController.unbounded
    // 0x9d5bec: add             SP, SP, #0x18
    // 0x9d5bf0: ldur            x0, [fp, #-0x20]
    // 0x9d5bf4: ldur            x1, [fp, #-0x10]
    // 0x9d5bf8: StoreField: r1->field_23 = r0
    //     0x9d5bf8: stur            w0, [x1, #0x23]
    //     0x9d5bfc: ldurb           w16, [x1, #-1]
    //     0x9d5c00: ldurb           w17, [x0, #-1]
    //     0x9d5c04: and             x16, x17, x16, lsr #2
    //     0x9d5c08: tst             x16, HEAP, lsr #32
    //     0x9d5c0c: b.eq            #0x9d5c14
    //     0x9d5c10: bl              #0xd6826c
    // 0x9d5c14: r0 = 0
    //     0x9d5c14: mov             x0, #0
    // 0x9d5c18: StoreField: r1->field_7 = r0
    //     0x9d5c18: stur            x0, [x1, #7]
    // 0x9d5c1c: StoreField: r1->field_13 = r0
    //     0x9d5c1c: stur            x0, [x1, #0x13]
    // 0x9d5c20: StoreField: r1->field_1b = r0
    //     0x9d5c20: stur            x0, [x1, #0x1b]
    // 0x9d5c24: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x9d5c24: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9d5c28: ldr             x0, [x0, #0x1580]
    //     0x9d5c2c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9d5c30: cmp             w0, w16
    //     0x9d5c34: b.ne            #0x9d5c40
    //     0x9d5c38: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x9d5c3c: bl              #0xd67cdc
    // 0x9d5c40: ldur            x1, [fp, #-0x10]
    // 0x9d5c44: StoreField: r1->field_f = r0
    //     0x9d5c44: stur            w0, [x1, #0xf]
    //     0x9d5c48: ldurb           w16, [x1, #-1]
    //     0x9d5c4c: ldurb           w17, [x0, #-1]
    //     0x9d5c50: and             x16, x17, x16, lsr #2
    //     0x9d5c54: tst             x16, HEAP, lsr #32
    //     0x9d5c58: b.eq            #0x9d5c60
    //     0x9d5c5c: bl              #0xd6826c
    // 0x9d5c60: r0 = Null
    //     0x9d5c60: mov             x0, NULL
    // 0x9d5c64: LeaveFrame
    //     0x9d5c64: mov             SP, fp
    //     0x9d5c68: ldp             fp, lr, [SP], #0x10
    // 0x9d5c6c: ret
    //     0x9d5c6c: ret             
    // 0x9d5c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d5c70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d5c74: b               #0x9d5b8c
  }
}

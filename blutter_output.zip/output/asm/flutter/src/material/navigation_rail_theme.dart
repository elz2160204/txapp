// lib: , url: package:flutter/src/material/navigation_rail_theme.dart

// class id: 1049283, size: 0x8
class :: {
}

// class id: 2780, size: 0x3c, field offset: 0x8
//   const constructor, 
class NavigationRailThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00b8c, size: 0xa0
    // 0xb00b8c: EnterFrame
    //     0xb00b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb00b90: mov             fp, SP
    // 0xb00b94: CheckStackOverflow
    //     0xb00b94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00b98: cmp             SP, x16
    //     0xb00b9c: b.ls            #0xb00c24
    // 0xb00ba0: ldr             x0, [fp, #0x10]
    // 0xb00ba4: LoadField: r1 = r0->field_b
    //     0xb00ba4: ldur            w1, [x0, #0xb]
    // 0xb00ba8: DecompressPointer r1
    //     0xb00ba8: add             x1, x1, HEAP, lsl #32
    // 0xb00bac: LoadField: r2 = r0->field_17
    //     0xb00bac: ldur            w2, [x0, #0x17]
    // 0xb00bb0: DecompressPointer r2
    //     0xb00bb0: add             x2, x2, HEAP, lsl #32
    // 0xb00bb4: LoadField: r3 = r0->field_1b
    //     0xb00bb4: ldur            w3, [x0, #0x1b]
    // 0xb00bb8: DecompressPointer r3
    //     0xb00bb8: add             x3, x3, HEAP, lsl #32
    // 0xb00bbc: LoadField: r4 = r0->field_1f
    //     0xb00bbc: ldur            w4, [x0, #0x1f]
    // 0xb00bc0: DecompressPointer r4
    //     0xb00bc0: add             x4, x4, HEAP, lsl #32
    // 0xb00bc4: LoadField: r5 = r0->field_33
    //     0xb00bc4: ldur            w5, [x0, #0x33]
    // 0xb00bc8: DecompressPointer r5
    //     0xb00bc8: add             x5, x5, HEAP, lsl #32
    // 0xb00bcc: LoadField: r6 = r0->field_37
    //     0xb00bcc: ldur            w6, [x0, #0x37]
    // 0xb00bd0: DecompressPointer r6
    //     0xb00bd0: add             x6, x6, HEAP, lsl #32
    // 0xb00bd4: stp             x1, NULL, [SP, #-0x10]!
    // 0xb00bd8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00bdc: stp             x3, x2, [SP, #-0x10]!
    // 0xb00be0: stp             NULL, x4, [SP, #-0x10]!
    // 0xb00be4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00be8: stp             x5, NULL, [SP, #-0x10]!
    // 0xb00bec: SaveReg r6
    //     0xb00bec: str             x6, [SP, #-8]!
    // 0xb00bf0: r4 = const [0, 0xd, 0xd, 0xd, null]
    //     0xb00bf0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdee0] List(5) [0, 0xd, 0xd, 0xd, Null]
    //     0xb00bf4: ldr             x4, [x4, #0xee0]
    // 0xb00bf8: r0 = hash()
    //     0xb00bf8: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00bfc: add             SP, SP, #0x68
    // 0xb00c00: mov             x2, x0
    // 0xb00c04: r0 = BoxInt64Instr(r2)
    //     0xb00c04: sbfiz           x0, x2, #1, #0x1f
    //     0xb00c08: cmp             x2, x0, asr #1
    //     0xb00c0c: b.eq            #0xb00c18
    //     0xb00c10: bl              #0xd69bb8
    //     0xb00c14: stur            x2, [x0, #7]
    // 0xb00c18: LeaveFrame
    //     0xb00c18: mov             SP, fp
    //     0xb00c1c: ldp             fp, lr, [SP], #0x10
    // 0xb00c20: ret
    //     0xb00c20: ret             
    // 0xb00c24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00c24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00c28: b               #0xb00ba0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf35c8, size: 0x218
    // 0xbf35c8: EnterFrame
    //     0xbf35c8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf35cc: mov             fp, SP
    // 0xbf35d0: AllocStack(0x30)
    //     0xbf35d0: sub             SP, SP, #0x30
    // 0xbf35d4: CheckStackOverflow
    //     0xbf35d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf35d8: cmp             SP, x16
    //     0xbf35dc: b.ls            #0xbf37c8
    // 0xbf35e0: ldr             d0, [fp, #0x10]
    // 0xbf35e4: r0 = inline_Allocate_Double()
    //     0xbf35e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf35e8: add             x0, x0, #0x10
    //     0xbf35ec: cmp             x1, x0
    //     0xbf35f0: b.ls            #0xbf37d0
    //     0xbf35f4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf35f8: sub             x0, x0, #0xf
    //     0xbf35fc: mov             x1, #0xd108
    //     0xbf3600: movk            x1, #3, lsl #16
    //     0xbf3604: stur            x1, [x0, #-1]
    // 0xbf3608: StoreField: r0->field_7 = d0
    //     0xbf3608: stur            d0, [x0, #7]
    // 0xbf360c: stur            x0, [fp, #-8]
    // 0xbf3610: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3614: SaveReg r0
    //     0xbf3614: str             x0, [SP, #-8]!
    // 0xbf3618: r0 = lerp()
    //     0xbf3618: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf361c: add             SP, SP, #0x18
    // 0xbf3620: ldr             x0, [fp, #0x20]
    // 0xbf3624: LoadField: r1 = r0->field_b
    //     0xbf3624: ldur            w1, [x0, #0xb]
    // 0xbf3628: DecompressPointer r1
    //     0xbf3628: add             x1, x1, HEAP, lsl #32
    // 0xbf362c: ldr             x2, [fp, #0x18]
    // 0xbf3630: LoadField: r3 = r2->field_b
    //     0xbf3630: ldur            w3, [x2, #0xb]
    // 0xbf3634: DecompressPointer r3
    //     0xbf3634: add             x3, x3, HEAP, lsl #32
    // 0xbf3638: stp             x3, x1, [SP, #-0x10]!
    // 0xbf363c: ldur            x16, [fp, #-8]
    // 0xbf3640: SaveReg r16
    //     0xbf3640: str             x16, [SP, #-8]!
    // 0xbf3644: r0 = lerpDouble()
    //     0xbf3644: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3648: add             SP, SP, #0x18
    // 0xbf364c: stur            x0, [fp, #-0x10]
    // 0xbf3650: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3654: ldur            x16, [fp, #-8]
    // 0xbf3658: SaveReg r16
    //     0xbf3658: str             x16, [SP, #-8]!
    // 0xbf365c: r0 = lerp()
    //     0xbf365c: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf3660: add             SP, SP, #0x18
    // 0xbf3664: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3668: ldur            x16, [fp, #-8]
    // 0xbf366c: SaveReg r16
    //     0xbf366c: str             x16, [SP, #-8]!
    // 0xbf3670: r0 = lerp()
    //     0xbf3670: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf3674: add             SP, SP, #0x18
    // 0xbf3678: ldr             x0, [fp, #0x20]
    // 0xbf367c: LoadField: r1 = r0->field_17
    //     0xbf367c: ldur            w1, [x0, #0x17]
    // 0xbf3680: DecompressPointer r1
    //     0xbf3680: add             x1, x1, HEAP, lsl #32
    // 0xbf3684: ldr             x2, [fp, #0x18]
    // 0xbf3688: LoadField: r3 = r2->field_17
    //     0xbf3688: ldur            w3, [x2, #0x17]
    // 0xbf368c: DecompressPointer r3
    //     0xbf368c: add             x3, x3, HEAP, lsl #32
    // 0xbf3690: stp             x3, x1, [SP, #-0x10]!
    // 0xbf3694: ldur            x16, [fp, #-8]
    // 0xbf3698: SaveReg r16
    //     0xbf3698: str             x16, [SP, #-8]!
    // 0xbf369c: r0 = lerp()
    //     0xbf369c: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbf36a0: add             SP, SP, #0x18
    // 0xbf36a4: mov             x1, x0
    // 0xbf36a8: ldr             x0, [fp, #0x20]
    // 0xbf36ac: stur            x1, [fp, #-0x18]
    // 0xbf36b0: LoadField: r2 = r0->field_1b
    //     0xbf36b0: ldur            w2, [x0, #0x1b]
    // 0xbf36b4: DecompressPointer r2
    //     0xbf36b4: add             x2, x2, HEAP, lsl #32
    // 0xbf36b8: ldr             x3, [fp, #0x18]
    // 0xbf36bc: LoadField: r4 = r3->field_1b
    //     0xbf36bc: ldur            w4, [x3, #0x1b]
    // 0xbf36c0: DecompressPointer r4
    //     0xbf36c0: add             x4, x4, HEAP, lsl #32
    // 0xbf36c4: stp             x4, x2, [SP, #-0x10]!
    // 0xbf36c8: ldur            x16, [fp, #-8]
    // 0xbf36cc: SaveReg r16
    //     0xbf36cc: str             x16, [SP, #-8]!
    // 0xbf36d0: r0 = lerp()
    //     0xbf36d0: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbf36d4: add             SP, SP, #0x18
    // 0xbf36d8: mov             x1, x0
    // 0xbf36dc: ldr             x0, [fp, #0x20]
    // 0xbf36e0: stur            x1, [fp, #-0x20]
    // 0xbf36e4: LoadField: r2 = r0->field_1f
    //     0xbf36e4: ldur            w2, [x0, #0x1f]
    // 0xbf36e8: DecompressPointer r2
    //     0xbf36e8: add             x2, x2, HEAP, lsl #32
    // 0xbf36ec: ldr             x3, [fp, #0x18]
    // 0xbf36f0: LoadField: r4 = r3->field_1f
    //     0xbf36f0: ldur            w4, [x3, #0x1f]
    // 0xbf36f4: DecompressPointer r4
    //     0xbf36f4: add             x4, x4, HEAP, lsl #32
    // 0xbf36f8: stp             x4, x2, [SP, #-0x10]!
    // 0xbf36fc: ldur            x16, [fp, #-8]
    // 0xbf3700: SaveReg r16
    //     0xbf3700: str             x16, [SP, #-8]!
    // 0xbf3704: r0 = lerpDouble()
    //     0xbf3704: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3708: add             SP, SP, #0x18
    // 0xbf370c: stur            x0, [fp, #-0x28]
    // 0xbf3710: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3714: ldur            x16, [fp, #-8]
    // 0xbf3718: SaveReg r16
    //     0xbf3718: str             x16, [SP, #-8]!
    // 0xbf371c: r0 = lerp()
    //     0xbf371c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3720: add             SP, SP, #0x18
    // 0xbf3724: ldr             x0, [fp, #0x20]
    // 0xbf3728: LoadField: r1 = r0->field_33
    //     0xbf3728: ldur            w1, [x0, #0x33]
    // 0xbf372c: DecompressPointer r1
    //     0xbf372c: add             x1, x1, HEAP, lsl #32
    // 0xbf3730: ldr             x2, [fp, #0x18]
    // 0xbf3734: LoadField: r3 = r2->field_33
    //     0xbf3734: ldur            w3, [x2, #0x33]
    // 0xbf3738: DecompressPointer r3
    //     0xbf3738: add             x3, x3, HEAP, lsl #32
    // 0xbf373c: stp             x3, x1, [SP, #-0x10]!
    // 0xbf3740: ldur            x16, [fp, #-8]
    // 0xbf3744: SaveReg r16
    //     0xbf3744: str             x16, [SP, #-8]!
    // 0xbf3748: r0 = lerpDouble()
    //     0xbf3748: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf374c: add             SP, SP, #0x18
    // 0xbf3750: mov             x1, x0
    // 0xbf3754: ldr             x0, [fp, #0x20]
    // 0xbf3758: stur            x1, [fp, #-0x30]
    // 0xbf375c: LoadField: r2 = r0->field_37
    //     0xbf375c: ldur            w2, [x0, #0x37]
    // 0xbf3760: DecompressPointer r2
    //     0xbf3760: add             x2, x2, HEAP, lsl #32
    // 0xbf3764: ldr             x0, [fp, #0x18]
    // 0xbf3768: LoadField: r3 = r0->field_37
    //     0xbf3768: ldur            w3, [x0, #0x37]
    // 0xbf376c: DecompressPointer r3
    //     0xbf376c: add             x3, x3, HEAP, lsl #32
    // 0xbf3770: stp             x3, x2, [SP, #-0x10]!
    // 0xbf3774: ldur            x16, [fp, #-8]
    // 0xbf3778: SaveReg r16
    //     0xbf3778: str             x16, [SP, #-8]!
    // 0xbf377c: r0 = lerpDouble()
    //     0xbf377c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3780: add             SP, SP, #0x18
    // 0xbf3784: stur            x0, [fp, #-8]
    // 0xbf3788: r0 = NavigationRailThemeData()
    //     0xbf3788: bl              #0xbf37e0  ; AllocateNavigationRailThemeDataStub -> NavigationRailThemeData (size=0x3c)
    // 0xbf378c: ldur            x1, [fp, #-0x10]
    // 0xbf3790: StoreField: r0->field_b = r1
    //     0xbf3790: stur            w1, [x0, #0xb]
    // 0xbf3794: ldur            x1, [fp, #-0x18]
    // 0xbf3798: StoreField: r0->field_17 = r1
    //     0xbf3798: stur            w1, [x0, #0x17]
    // 0xbf379c: ldur            x1, [fp, #-0x20]
    // 0xbf37a0: StoreField: r0->field_1b = r1
    //     0xbf37a0: stur            w1, [x0, #0x1b]
    // 0xbf37a4: ldur            x1, [fp, #-0x28]
    // 0xbf37a8: StoreField: r0->field_1f = r1
    //     0xbf37a8: stur            w1, [x0, #0x1f]
    // 0xbf37ac: ldur            x1, [fp, #-0x30]
    // 0xbf37b0: StoreField: r0->field_33 = r1
    //     0xbf37b0: stur            w1, [x0, #0x33]
    // 0xbf37b4: ldur            x1, [fp, #-8]
    // 0xbf37b8: StoreField: r0->field_37 = r1
    //     0xbf37b8: stur            w1, [x0, #0x37]
    // 0xbf37bc: LeaveFrame
    //     0xbf37bc: mov             SP, fp
    //     0xbf37c0: ldp             fp, lr, [SP], #0x10
    // 0xbf37c4: ret
    //     0xbf37c4: ret             
    // 0xbf37c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf37c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf37cc: b               #0xbf35e0
    // 0xbf37d0: SaveReg d0
    //     0xbf37d0: str             q0, [SP, #-0x10]!
    // 0xbf37d4: r0 = AllocateDouble()
    //     0xbf37d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf37d8: RestoreReg d0
    //     0xbf37d8: ldr             q0, [SP], #0x10
    // 0xbf37dc: b               #0xbf3608
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8c294, size: 0x250
    // 0xc8c294: EnterFrame
    //     0xc8c294: stp             fp, lr, [SP, #-0x10]!
    //     0xc8c298: mov             fp, SP
    // 0xc8c29c: CheckStackOverflow
    //     0xc8c29c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8c2a0: cmp             SP, x16
    //     0xc8c2a4: b.ls            #0xc8c4dc
    // 0xc8c2a8: ldr             x1, [fp, #0x10]
    // 0xc8c2ac: cmp             w1, NULL
    // 0xc8c2b0: b.ne            #0xc8c2c4
    // 0xc8c2b4: r0 = false
    //     0xc8c2b4: add             x0, NULL, #0x30  ; false
    // 0xc8c2b8: LeaveFrame
    //     0xc8c2b8: mov             SP, fp
    //     0xc8c2bc: ldp             fp, lr, [SP], #0x10
    // 0xc8c2c0: ret
    //     0xc8c2c0: ret             
    // 0xc8c2c4: ldr             x2, [fp, #0x18]
    // 0xc8c2c8: cmp             w2, w1
    // 0xc8c2cc: b.ne            #0xc8c2e0
    // 0xc8c2d0: r0 = true
    //     0xc8c2d0: add             x0, NULL, #0x20  ; true
    // 0xc8c2d4: LeaveFrame
    //     0xc8c2d4: mov             SP, fp
    //     0xc8c2d8: ldp             fp, lr, [SP], #0x10
    // 0xc8c2dc: ret
    //     0xc8c2dc: ret             
    // 0xc8c2e0: r0 = 59
    //     0xc8c2e0: mov             x0, #0x3b
    // 0xc8c2e4: branchIfSmi(r1, 0xc8c2f0)
    //     0xc8c2e4: tbz             w1, #0, #0xc8c2f0
    // 0xc8c2e8: r0 = LoadClassIdInstr(r1)
    //     0xc8c2e8: ldur            x0, [x1, #-1]
    //     0xc8c2ec: ubfx            x0, x0, #0xc, #0x14
    // 0xc8c2f0: SaveReg r1
    //     0xc8c2f0: str             x1, [SP, #-8]!
    // 0xc8c2f4: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8c2f4: mov             x17, #0x57c5
    //     0xc8c2f8: add             lr, x0, x17
    //     0xc8c2fc: ldr             lr, [x21, lr, lsl #3]
    //     0xc8c300: blr             lr
    // 0xc8c304: add             SP, SP, #8
    // 0xc8c308: r1 = LoadClassIdInstr(r0)
    //     0xc8c308: ldur            x1, [x0, #-1]
    //     0xc8c30c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8c310: r16 = NavigationRailThemeData
    //     0xc8c310: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1d0] Type: NavigationRailThemeData
    //     0xc8c314: ldr             x16, [x16, #0x1d0]
    // 0xc8c318: stp             x16, x0, [SP, #-0x10]!
    // 0xc8c31c: mov             x0, x1
    // 0xc8c320: mov             lr, x0
    // 0xc8c324: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c328: blr             lr
    // 0xc8c32c: add             SP, SP, #0x10
    // 0xc8c330: tbz             w0, #4, #0xc8c344
    // 0xc8c334: r0 = false
    //     0xc8c334: add             x0, NULL, #0x30  ; false
    // 0xc8c338: LeaveFrame
    //     0xc8c338: mov             SP, fp
    //     0xc8c33c: ldp             fp, lr, [SP], #0x10
    // 0xc8c340: ret
    //     0xc8c340: ret             
    // 0xc8c344: ldr             x1, [fp, #0x10]
    // 0xc8c348: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8c348: mov             x0, #0x76
    //     0xc8c34c: tbz             w1, #0, #0xc8c35c
    //     0xc8c350: ldur            x0, [x1, #-1]
    //     0xc8c354: ubfx            x0, x0, #0xc, #0x14
    //     0xc8c358: lsl             x0, x0, #1
    // 0xc8c35c: r17 = 5560
    //     0xc8c35c: mov             x17, #0x15b8
    // 0xc8c360: cmp             w0, w17
    // 0xc8c364: b.ne            #0xc8c4cc
    // 0xc8c368: ldr             x2, [fp, #0x18]
    // 0xc8c36c: LoadField: r0 = r1->field_b
    //     0xc8c36c: ldur            w0, [x1, #0xb]
    // 0xc8c370: DecompressPointer r0
    //     0xc8c370: add             x0, x0, HEAP, lsl #32
    // 0xc8c374: LoadField: r3 = r2->field_b
    //     0xc8c374: ldur            w3, [x2, #0xb]
    // 0xc8c378: DecompressPointer r3
    //     0xc8c378: add             x3, x3, HEAP, lsl #32
    // 0xc8c37c: r4 = LoadClassIdInstr(r0)
    //     0xc8c37c: ldur            x4, [x0, #-1]
    //     0xc8c380: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c384: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c388: mov             x0, x4
    // 0xc8c38c: mov             lr, x0
    // 0xc8c390: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c394: blr             lr
    // 0xc8c398: add             SP, SP, #0x10
    // 0xc8c39c: tbnz            w0, #4, #0xc8c4cc
    // 0xc8c3a0: ldr             x2, [fp, #0x18]
    // 0xc8c3a4: ldr             x1, [fp, #0x10]
    // 0xc8c3a8: LoadField: r0 = r1->field_17
    //     0xc8c3a8: ldur            w0, [x1, #0x17]
    // 0xc8c3ac: DecompressPointer r0
    //     0xc8c3ac: add             x0, x0, HEAP, lsl #32
    // 0xc8c3b0: LoadField: r3 = r2->field_17
    //     0xc8c3b0: ldur            w3, [x2, #0x17]
    // 0xc8c3b4: DecompressPointer r3
    //     0xc8c3b4: add             x3, x3, HEAP, lsl #32
    // 0xc8c3b8: r4 = LoadClassIdInstr(r0)
    //     0xc8c3b8: ldur            x4, [x0, #-1]
    //     0xc8c3bc: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c3c0: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c3c4: mov             x0, x4
    // 0xc8c3c8: mov             lr, x0
    // 0xc8c3cc: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c3d0: blr             lr
    // 0xc8c3d4: add             SP, SP, #0x10
    // 0xc8c3d8: tbnz            w0, #4, #0xc8c4cc
    // 0xc8c3dc: ldr             x2, [fp, #0x18]
    // 0xc8c3e0: ldr             x1, [fp, #0x10]
    // 0xc8c3e4: LoadField: r0 = r1->field_1b
    //     0xc8c3e4: ldur            w0, [x1, #0x1b]
    // 0xc8c3e8: DecompressPointer r0
    //     0xc8c3e8: add             x0, x0, HEAP, lsl #32
    // 0xc8c3ec: LoadField: r3 = r2->field_1b
    //     0xc8c3ec: ldur            w3, [x2, #0x1b]
    // 0xc8c3f0: DecompressPointer r3
    //     0xc8c3f0: add             x3, x3, HEAP, lsl #32
    // 0xc8c3f4: r4 = LoadClassIdInstr(r0)
    //     0xc8c3f4: ldur            x4, [x0, #-1]
    //     0xc8c3f8: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c3fc: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c400: mov             x0, x4
    // 0xc8c404: mov             lr, x0
    // 0xc8c408: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c40c: blr             lr
    // 0xc8c410: add             SP, SP, #0x10
    // 0xc8c414: tbnz            w0, #4, #0xc8c4cc
    // 0xc8c418: ldr             x2, [fp, #0x18]
    // 0xc8c41c: ldr             x1, [fp, #0x10]
    // 0xc8c420: LoadField: r0 = r1->field_1f
    //     0xc8c420: ldur            w0, [x1, #0x1f]
    // 0xc8c424: DecompressPointer r0
    //     0xc8c424: add             x0, x0, HEAP, lsl #32
    // 0xc8c428: LoadField: r3 = r2->field_1f
    //     0xc8c428: ldur            w3, [x2, #0x1f]
    // 0xc8c42c: DecompressPointer r3
    //     0xc8c42c: add             x3, x3, HEAP, lsl #32
    // 0xc8c430: r4 = LoadClassIdInstr(r0)
    //     0xc8c430: ldur            x4, [x0, #-1]
    //     0xc8c434: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c438: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c43c: mov             x0, x4
    // 0xc8c440: mov             lr, x0
    // 0xc8c444: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c448: blr             lr
    // 0xc8c44c: add             SP, SP, #0x10
    // 0xc8c450: tbnz            w0, #4, #0xc8c4cc
    // 0xc8c454: ldr             x2, [fp, #0x18]
    // 0xc8c458: ldr             x1, [fp, #0x10]
    // 0xc8c45c: LoadField: r0 = r1->field_33
    //     0xc8c45c: ldur            w0, [x1, #0x33]
    // 0xc8c460: DecompressPointer r0
    //     0xc8c460: add             x0, x0, HEAP, lsl #32
    // 0xc8c464: LoadField: r3 = r2->field_33
    //     0xc8c464: ldur            w3, [x2, #0x33]
    // 0xc8c468: DecompressPointer r3
    //     0xc8c468: add             x3, x3, HEAP, lsl #32
    // 0xc8c46c: r4 = LoadClassIdInstr(r0)
    //     0xc8c46c: ldur            x4, [x0, #-1]
    //     0xc8c470: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c474: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c478: mov             x0, x4
    // 0xc8c47c: mov             lr, x0
    // 0xc8c480: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c484: blr             lr
    // 0xc8c488: add             SP, SP, #0x10
    // 0xc8c48c: tbnz            w0, #4, #0xc8c4cc
    // 0xc8c490: ldr             x1, [fp, #0x18]
    // 0xc8c494: ldr             x0, [fp, #0x10]
    // 0xc8c498: LoadField: r2 = r0->field_37
    //     0xc8c498: ldur            w2, [x0, #0x37]
    // 0xc8c49c: DecompressPointer r2
    //     0xc8c49c: add             x2, x2, HEAP, lsl #32
    // 0xc8c4a0: LoadField: r0 = r1->field_37
    //     0xc8c4a0: ldur            w0, [x1, #0x37]
    // 0xc8c4a4: DecompressPointer r0
    //     0xc8c4a4: add             x0, x0, HEAP, lsl #32
    // 0xc8c4a8: r1 = LoadClassIdInstr(r2)
    //     0xc8c4a8: ldur            x1, [x2, #-1]
    //     0xc8c4ac: ubfx            x1, x1, #0xc, #0x14
    // 0xc8c4b0: stp             x0, x2, [SP, #-0x10]!
    // 0xc8c4b4: mov             x0, x1
    // 0xc8c4b8: mov             lr, x0
    // 0xc8c4bc: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c4c0: blr             lr
    // 0xc8c4c4: add             SP, SP, #0x10
    // 0xc8c4c8: b               #0xc8c4d0
    // 0xc8c4cc: r0 = false
    //     0xc8c4cc: add             x0, NULL, #0x30  ; false
    // 0xc8c4d0: LeaveFrame
    //     0xc8c4d0: mov             SP, fp
    //     0xc8c4d4: ldp             fp, lr, [SP], #0x10
    // 0xc8c4d8: ret
    //     0xc8c4d8: ret             
    // 0xc8c4dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8c4dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8c4e0: b               #0xc8c2a8
  }
}

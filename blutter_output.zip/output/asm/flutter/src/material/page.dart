// lib: , url: package:flutter/src/material/page.dart

// class id: 1049287, size: 0x8
class :: {
}

// class id: 1775, size: 0x84, field offset: 0x84
//   transformed mixin,
abstract class _MaterialPageRoute&PageRoute&MaterialRouteTransitionMixin<X0> extends PageRoute<X0>
     with MaterialRouteTransitionMixin<X0> {

  _ buildTransitions(/* No info */) {
    // ** addr: 0xa88c08, size: 0x7c
    // 0xa88c08: EnterFrame
    //     0xa88c08: stp             fp, lr, [SP, #-0x10]!
    //     0xa88c0c: mov             fp, SP
    // 0xa88c10: CheckStackOverflow
    //     0xa88c10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa88c14: cmp             SP, x16
    //     0xa88c18: b.ls            #0xa88c7c
    // 0xa88c1c: ldr             x16, [fp, #0x28]
    // 0xa88c20: SaveReg r16
    //     0xa88c20: str             x16, [SP, #-8]!
    // 0xa88c24: r0 = of()
    //     0xa88c24: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xa88c28: add             SP, SP, #8
    // 0xa88c2c: ldr             x0, [fp, #0x30]
    // 0xa88c30: LoadField: r1 = r0->field_7
    //     0xa88c30: ldur            w1, [x0, #7]
    // 0xa88c34: DecompressPointer r1
    //     0xa88c34: add             x1, x1, HEAP, lsl #32
    // 0xa88c38: r16 = Instance_PageTransitionsTheme
    //     0xa88c38: add             x16, PP, #0xd, lsl #12  ; [pp+0xd010] Obj!PageTransitionsTheme@b3ceb1
    //     0xa88c3c: ldr             x16, [x16, #0x10]
    // 0xa88c40: stp             x16, x1, [SP, #-0x10]!
    // 0xa88c44: ldr             x16, [fp, #0x28]
    // 0xa88c48: stp             x16, x0, [SP, #-0x10]!
    // 0xa88c4c: ldr             x16, [fp, #0x20]
    // 0xa88c50: ldr             lr, [fp, #0x18]
    // 0xa88c54: stp             lr, x16, [SP, #-0x10]!
    // 0xa88c58: ldr             x16, [fp, #0x10]
    // 0xa88c5c: SaveReg r16
    //     0xa88c5c: str             x16, [SP, #-8]!
    // 0xa88c60: r4 = const [0x1, 0x6, 0x6, 0x6, null]
    //     0xa88c60: add             x4, PP, #0x12, lsl #12  ; [pp+0x12cb8] List(5) [0x1, 0x6, 0x6, 0x6, Null]
    //     0xa88c64: ldr             x4, [x4, #0xcb8]
    // 0xa88c68: r0 = buildTransitions()
    //     0xa88c68: bl              #0xa88c84  ; [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::buildTransitions
    // 0xa88c6c: add             SP, SP, #0x38
    // 0xa88c70: LeaveFrame
    //     0xa88c70: mov             SP, fp
    //     0xa88c74: ldp             fp, lr, [SP], #0x10
    // 0xa88c78: ret
    //     0xa88c78: ret             
    // 0xa88c7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa88c7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa88c80: b               #0xa88c1c
  }
  _ canTransitionTo(/* No info */) {
    // ** addr: 0xab2ff4, size: 0x28
    // 0xab2ff4: ldr             x1, [SP]
    // 0xab2ff8: r2 = LoadClassIdInstr(r1)
    //     0xab2ff8: ldur            x2, [x1, #-1]
    //     0xab2ffc: ubfx            x2, x2, #0xc, #0x14
    // 0xab3000: lsl             x2, x2, #1
    // 0xab3004: cmp             w2, #0xde0
    // 0xab3008: b.ne            #0xab3014
    // 0xab300c: r0 = true
    //     0xab300c: add             x0, NULL, #0x20  ; true
    // 0xab3010: b               #0xab3018
    // 0xab3014: r0 = false
    //     0xab3014: add             x0, NULL, #0x30  ; false
    // 0xab3018: ret
    //     0xab3018: ret             
  }
  _ buildPage(/* No info */) {
    // ** addr: 0xab3518, size: 0x74
    // 0xab3518: EnterFrame
    //     0xab3518: stp             fp, lr, [SP, #-0x10]!
    //     0xab351c: mov             fp, SP
    // 0xab3520: AllocStack(0x10)
    //     0xab3520: sub             SP, SP, #0x10
    // 0xab3524: CheckStackOverflow
    //     0xab3524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xab3528: cmp             SP, x16
    //     0xab352c: b.ls            #0xab3584
    // 0xab3530: ldr             x16, [fp, #0x28]
    // 0xab3534: ldr             lr, [fp, #0x20]
    // 0xab3538: stp             lr, x16, [SP, #-0x10]!
    // 0xab353c: r0 = buildContent()
    //     0xab353c: bl              #0xab358c  ; [package:flutter/src/material/page.dart] MaterialPageRoute::buildContent
    // 0xab3540: add             SP, SP, #0x10
    // 0xab3544: stur            x0, [fp, #-8]
    // 0xab3548: r0 = Semantics()
    //     0xab3548: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0xab354c: stur            x0, [fp, #-0x10]
    // 0xab3550: r16 = true
    //     0xab3550: add             x16, NULL, #0x20  ; true
    // 0xab3554: stp             x16, x0, [SP, #-0x10]!
    // 0xab3558: r16 = true
    //     0xab3558: add             x16, NULL, #0x20  ; true
    // 0xab355c: ldur            lr, [fp, #-8]
    // 0xab3560: stp             lr, x16, [SP, #-0x10]!
    // 0xab3564: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, explicitChildNodes, 0x2, scopesRoute, 0x1, null]
    //     0xab3564: add             x4, PP, #0x2a, lsl #12  ; [pp+0x2a958] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "explicitChildNodes", 0x2, "scopesRoute", 0x1, Null]
    //     0xab3568: ldr             x4, [x4, #0x958]
    // 0xab356c: r0 = Semantics()
    //     0xab356c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xab3570: add             SP, SP, #0x20
    // 0xab3574: ldur            x0, [fp, #-0x10]
    // 0xab3578: LeaveFrame
    //     0xab3578: mov             SP, fp
    //     0xab357c: ldp             fp, lr, [SP], #0x10
    // 0xab3580: ret
    //     0xab3580: ret             
    // 0xab3584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xab3584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xab3588: b               #0xab3530
  }
  get _ transitionDuration(/* No info */) {
    // ** addr: 0xd065e4, size: 0xc
    // 0xd065e4: r0 = Instance_Duration
    //     0xd065e4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0xd065e8: ldr             x0, [x0, #0xc88]
    // 0xd065ec: ret
    //     0xd065ec: ret             
  }
}

// class id: 1776, size: 0x8c, field offset: 0x84
class MaterialPageRoute<X0> extends _MaterialPageRoute&PageRoute&MaterialRouteTransitionMixin<X0> {

  _ buildContent(/* No info */) {
    // ** addr: 0xab358c, size: 0x50
    // 0xab358c: EnterFrame
    //     0xab358c: stp             fp, lr, [SP, #-0x10]!
    //     0xab3590: mov             fp, SP
    // 0xab3594: CheckStackOverflow
    //     0xab3594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xab3598: cmp             SP, x16
    //     0xab359c: b.ls            #0xab35d4
    // 0xab35a0: ldr             x0, [fp, #0x18]
    // 0xab35a4: LoadField: r1 = r0->field_83
    //     0xab35a4: ldur            w1, [x0, #0x83]
    // 0xab35a8: DecompressPointer r1
    //     0xab35a8: add             x1, x1, HEAP, lsl #32
    // 0xab35ac: ldr             x16, [fp, #0x10]
    // 0xab35b0: stp             x16, x1, [SP, #-0x10]!
    // 0xab35b4: mov             x0, x1
    // 0xab35b8: ClosureCall
    //     0xab35b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xab35bc: ldur            x2, [x0, #0x1f]
    //     0xab35c0: blr             x2
    // 0xab35c4: add             SP, SP, #0x10
    // 0xab35c8: LeaveFrame
    //     0xab35c8: mov             SP, fp
    //     0xab35cc: ldp             fp, lr, [SP], #0x10
    // 0xab35d0: ret
    //     0xab35d0: ret             
    // 0xab35d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xab35d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xab35d8: b               #0xab35a0
  }
}

// class id: 1777, size: 0x84, field offset: 0x84
abstract class MaterialRouteTransitionMixin<X0> extends PageRoute<X0> {
}

// lib: , url: package:flutter/src/material/menu_style.dart

// class id: 1049275, size: 0x8
class :: {
}

// class id: 2161, size: 0x18, field offset: 0x8
//   const constructor, 
class _LerpSides extends Object
    implements MaterialStateProperty<X0> {

  _ resolve(/* No info */) {
    // ** addr: 0x5b6194, size: 0x1e4
    // 0x5b6194: EnterFrame
    //     0x5b6194: stp             fp, lr, [SP, #-0x10]!
    //     0x5b6198: mov             fp, SP
    // 0x5b619c: AllocStack(0x18)
    //     0x5b619c: sub             SP, SP, #0x18
    // 0x5b61a0: CheckStackOverflow
    //     0x5b61a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b61a4: cmp             SP, x16
    //     0x5b61a8: b.ls            #0x5b636c
    // 0x5b61ac: ldr             x0, [fp, #0x18]
    // 0x5b61b0: LoadField: r1 = r0->field_7
    //     0x5b61b0: ldur            w1, [x0, #7]
    // 0x5b61b4: DecompressPointer r1
    //     0x5b61b4: add             x1, x1, HEAP, lsl #32
    // 0x5b61b8: cmp             w1, NULL
    // 0x5b61bc: b.ne            #0x5b61c8
    // 0x5b61c0: r1 = Null
    //     0x5b61c0: mov             x1, NULL
    // 0x5b61c4: b               #0x5b61e0
    // 0x5b61c8: ldr             x16, [fp, #0x10]
    // 0x5b61cc: stp             x16, x1, [SP, #-0x10]!
    // 0x5b61d0: r0 = resolve()
    //     0x5b61d0: bl              #0x5b6194  ; [package:flutter/src/material/menu_style.dart] _LerpSides::resolve
    // 0x5b61d4: add             SP, SP, #0x10
    // 0x5b61d8: mov             x1, x0
    // 0x5b61dc: ldr             x0, [fp, #0x18]
    // 0x5b61e0: stur            x1, [fp, #-8]
    // 0x5b61e4: LoadField: r2 = r0->field_b
    //     0x5b61e4: ldur            w2, [x0, #0xb]
    // 0x5b61e8: DecompressPointer r2
    //     0x5b61e8: add             x2, x2, HEAP, lsl #32
    // 0x5b61ec: cmp             w2, NULL
    // 0x5b61f0: b.ne            #0x5b6200
    // 0x5b61f4: mov             x0, x1
    // 0x5b61f8: r1 = Null
    //     0x5b61f8: mov             x1, NULL
    // 0x5b61fc: b               #0x5b6218
    // 0x5b6200: ldr             x16, [fp, #0x10]
    // 0x5b6204: stp             x16, x2, [SP, #-0x10]!
    // 0x5b6208: r0 = resolve()
    //     0x5b6208: bl              #0x5b6194  ; [package:flutter/src/material/menu_style.dart] _LerpSides::resolve
    // 0x5b620c: add             SP, SP, #0x10
    // 0x5b6210: mov             x1, x0
    // 0x5b6214: ldur            x0, [fp, #-8]
    // 0x5b6218: stur            x1, [fp, #-0x10]
    // 0x5b621c: cmp             w0, NULL
    // 0x5b6220: b.ne            #0x5b623c
    // 0x5b6224: cmp             w1, NULL
    // 0x5b6228: b.ne            #0x5b623c
    // 0x5b622c: r0 = Null
    //     0x5b622c: mov             x0, NULL
    // 0x5b6230: LeaveFrame
    //     0x5b6230: mov             SP, fp
    //     0x5b6234: ldp             fp, lr, [SP], #0x10
    // 0x5b6238: ret
    //     0x5b6238: ret             
    // 0x5b623c: cmp             w0, NULL
    // 0x5b6240: b.ne            #0x5b62bc
    // 0x5b6244: ldr             x0, [fp, #0x18]
    // 0x5b6248: cmp             w1, NULL
    // 0x5b624c: b.eq            #0x5b6374
    // 0x5b6250: LoadField: r2 = r1->field_7
    //     0x5b6250: ldur            w2, [x1, #7]
    // 0x5b6254: DecompressPointer r2
    //     0x5b6254: add             x2, x2, HEAP, lsl #32
    // 0x5b6258: stp             xzr, x2, [SP, #-0x10]!
    // 0x5b625c: r0 = withAlpha()
    //     0x5b625c: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x5b6260: add             SP, SP, #0x10
    // 0x5b6264: stur            x0, [fp, #-0x18]
    // 0x5b6268: r0 = BorderSide()
    //     0x5b6268: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x5b626c: mov             x1, x0
    // 0x5b6270: ldur            x0, [fp, #-0x18]
    // 0x5b6274: StoreField: r1->field_7 = r0
    //     0x5b6274: stur            w0, [x1, #7]
    // 0x5b6278: d0 = 0.000000
    //     0x5b6278: eor             v0.16b, v0.16b, v0.16b
    // 0x5b627c: StoreField: r1->field_b = d0
    //     0x5b627c: stur            d0, [x1, #0xb]
    // 0x5b6280: r2 = Instance_BorderStyle
    //     0x5b6280: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b6284: ldr             x2, [x2, #0xbd0]
    // 0x5b6288: StoreField: r1->field_13 = r2
    //     0x5b6288: stur            w2, [x1, #0x13]
    // 0x5b628c: d1 = -1.000000
    //     0x5b628c: fmov            d1, #-1.00000000
    // 0x5b6290: StoreField: r1->field_17 = d1
    //     0x5b6290: stur            d1, [x1, #0x17]
    // 0x5b6294: ldr             x3, [fp, #0x18]
    // 0x5b6298: LoadField: d0 = r3->field_f
    //     0x5b6298: ldur            d0, [x3, #0xf]
    // 0x5b629c: ldur            x16, [fp, #-0x10]
    // 0x5b62a0: stp             x16, x1, [SP, #-0x10]!
    // 0x5b62a4: SaveReg d0
    //     0x5b62a4: str             d0, [SP, #-8]!
    // 0x5b62a8: r0 = lerp()
    //     0x5b62a8: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x5b62ac: add             SP, SP, #0x18
    // 0x5b62b0: LeaveFrame
    //     0x5b62b0: mov             SP, fp
    //     0x5b62b4: ldp             fp, lr, [SP], #0x10
    // 0x5b62b8: ret
    //     0x5b62b8: ret             
    // 0x5b62bc: ldr             x3, [fp, #0x18]
    // 0x5b62c0: r2 = Instance_BorderStyle
    //     0x5b62c0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b62c4: ldr             x2, [x2, #0xbd0]
    // 0x5b62c8: d0 = 0.000000
    //     0x5b62c8: eor             v0.16b, v0.16b, v0.16b
    // 0x5b62cc: d1 = -1.000000
    //     0x5b62cc: fmov            d1, #-1.00000000
    // 0x5b62d0: cmp             w1, NULL
    // 0x5b62d4: b.ne            #0x5b6344
    // 0x5b62d8: LoadField: r1 = r0->field_7
    //     0x5b62d8: ldur            w1, [x0, #7]
    // 0x5b62dc: DecompressPointer r1
    //     0x5b62dc: add             x1, x1, HEAP, lsl #32
    // 0x5b62e0: stp             xzr, x1, [SP, #-0x10]!
    // 0x5b62e4: r0 = withAlpha()
    //     0x5b62e4: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x5b62e8: add             SP, SP, #0x10
    // 0x5b62ec: stur            x0, [fp, #-0x18]
    // 0x5b62f0: r0 = BorderSide()
    //     0x5b62f0: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x5b62f4: mov             x1, x0
    // 0x5b62f8: ldur            x0, [fp, #-0x18]
    // 0x5b62fc: StoreField: r1->field_7 = r0
    //     0x5b62fc: stur            w0, [x1, #7]
    // 0x5b6300: d0 = 0.000000
    //     0x5b6300: eor             v0.16b, v0.16b, v0.16b
    // 0x5b6304: StoreField: r1->field_b = d0
    //     0x5b6304: stur            d0, [x1, #0xb]
    // 0x5b6308: r0 = Instance_BorderStyle
    //     0x5b6308: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b630c: ldr             x0, [x0, #0xbd0]
    // 0x5b6310: StoreField: r1->field_13 = r0
    //     0x5b6310: stur            w0, [x1, #0x13]
    // 0x5b6314: d0 = -1.000000
    //     0x5b6314: fmov            d0, #-1.00000000
    // 0x5b6318: StoreField: r1->field_17 = d0
    //     0x5b6318: stur            d0, [x1, #0x17]
    // 0x5b631c: ldr             x0, [fp, #0x18]
    // 0x5b6320: LoadField: d0 = r0->field_f
    //     0x5b6320: ldur            d0, [x0, #0xf]
    // 0x5b6324: ldur            x16, [fp, #-8]
    // 0x5b6328: stp             x1, x16, [SP, #-0x10]!
    // 0x5b632c: SaveReg d0
    //     0x5b632c: str             d0, [SP, #-8]!
    // 0x5b6330: r0 = lerp()
    //     0x5b6330: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x5b6334: add             SP, SP, #0x18
    // 0x5b6338: LeaveFrame
    //     0x5b6338: mov             SP, fp
    //     0x5b633c: ldp             fp, lr, [SP], #0x10
    // 0x5b6340: ret
    //     0x5b6340: ret             
    // 0x5b6344: mov             x0, x3
    // 0x5b6348: LoadField: d0 = r0->field_f
    //     0x5b6348: ldur            d0, [x0, #0xf]
    // 0x5b634c: ldur            x16, [fp, #-8]
    // 0x5b6350: stp             x1, x16, [SP, #-0x10]!
    // 0x5b6354: SaveReg d0
    //     0x5b6354: str             d0, [SP, #-8]!
    // 0x5b6358: r0 = lerp()
    //     0x5b6358: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x5b635c: add             SP, SP, #0x18
    // 0x5b6360: LeaveFrame
    //     0x5b6360: mov             SP, fp
    //     0x5b6364: ldp             fp, lr, [SP], #0x10
    // 0x5b6368: ret
    //     0x5b6368: ret             
    // 0x5b636c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b636c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b6370: b               #0x5b61ac
    // 0x5b6374: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5b6374: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2783, size: 0x3c, field offset: 0x8
//   const constructor, 
class MenuStyle extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00954, size: 0x130
    // 0xb00954: EnterFrame
    //     0xb00954: stp             fp, lr, [SP, #-0x10]!
    //     0xb00958: mov             fp, SP
    // 0xb0095c: AllocStack(0x10)
    //     0xb0095c: sub             SP, SP, #0x10
    // 0xb00960: r0 = 26
    //     0xb00960: mov             x0, #0x1a
    // 0xb00964: CheckStackOverflow
    //     0xb00964: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00968: cmp             SP, x16
    //     0xb0096c: b.ls            #0xb00a7c
    // 0xb00970: ldr             x3, [fp, #0x10]
    // 0xb00974: LoadField: r4 = r3->field_7
    //     0xb00974: ldur            w4, [x3, #7]
    // 0xb00978: DecompressPointer r4
    //     0xb00978: add             x4, x4, HEAP, lsl #32
    // 0xb0097c: mov             x2, x0
    // 0xb00980: stur            x4, [fp, #-8]
    // 0xb00984: r1 = <Object?>
    //     0xb00984: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xb00988: r0 = AllocateArray()
    //     0xb00988: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb0098c: mov             x2, x0
    // 0xb00990: ldur            x0, [fp, #-8]
    // 0xb00994: stur            x2, [fp, #-0x10]
    // 0xb00998: StoreField: r2->field_f = r0
    //     0xb00998: stur            w0, [x2, #0xf]
    // 0xb0099c: ldr             x0, [fp, #0x10]
    // 0xb009a0: LoadField: r1 = r0->field_b
    //     0xb009a0: ldur            w1, [x0, #0xb]
    // 0xb009a4: DecompressPointer r1
    //     0xb009a4: add             x1, x1, HEAP, lsl #32
    // 0xb009a8: StoreField: r2->field_13 = r1
    //     0xb009a8: stur            w1, [x2, #0x13]
    // 0xb009ac: LoadField: r1 = r0->field_f
    //     0xb009ac: ldur            w1, [x0, #0xf]
    // 0xb009b0: DecompressPointer r1
    //     0xb009b0: add             x1, x1, HEAP, lsl #32
    // 0xb009b4: StoreField: r2->field_17 = r1
    //     0xb009b4: stur            w1, [x2, #0x17]
    // 0xb009b8: LoadField: r1 = r0->field_13
    //     0xb009b8: ldur            w1, [x0, #0x13]
    // 0xb009bc: DecompressPointer r1
    //     0xb009bc: add             x1, x1, HEAP, lsl #32
    // 0xb009c0: StoreField: r2->field_1b = r1
    //     0xb009c0: stur            w1, [x2, #0x1b]
    // 0xb009c4: LoadField: r1 = r0->field_17
    //     0xb009c4: ldur            w1, [x0, #0x17]
    // 0xb009c8: DecompressPointer r1
    //     0xb009c8: add             x1, x1, HEAP, lsl #32
    // 0xb009cc: StoreField: r2->field_1f = r1
    //     0xb009cc: stur            w1, [x2, #0x1f]
    // 0xb009d0: LoadField: r1 = r0->field_1b
    //     0xb009d0: ldur            w1, [x0, #0x1b]
    // 0xb009d4: DecompressPointer r1
    //     0xb009d4: add             x1, x1, HEAP, lsl #32
    // 0xb009d8: StoreField: r2->field_23 = r1
    //     0xb009d8: stur            w1, [x2, #0x23]
    // 0xb009dc: LoadField: r1 = r0->field_1f
    //     0xb009dc: ldur            w1, [x0, #0x1f]
    // 0xb009e0: DecompressPointer r1
    //     0xb009e0: add             x1, x1, HEAP, lsl #32
    // 0xb009e4: StoreField: r2->field_27 = r1
    //     0xb009e4: stur            w1, [x2, #0x27]
    // 0xb009e8: LoadField: r1 = r0->field_23
    //     0xb009e8: ldur            w1, [x0, #0x23]
    // 0xb009ec: DecompressPointer r1
    //     0xb009ec: add             x1, x1, HEAP, lsl #32
    // 0xb009f0: StoreField: r2->field_2b = r1
    //     0xb009f0: stur            w1, [x2, #0x2b]
    // 0xb009f4: LoadField: r1 = r0->field_27
    //     0xb009f4: ldur            w1, [x0, #0x27]
    // 0xb009f8: DecompressPointer r1
    //     0xb009f8: add             x1, x1, HEAP, lsl #32
    // 0xb009fc: StoreField: r2->field_2f = r1
    //     0xb009fc: stur            w1, [x2, #0x2f]
    // 0xb00a00: LoadField: r1 = r0->field_2b
    //     0xb00a00: ldur            w1, [x0, #0x2b]
    // 0xb00a04: DecompressPointer r1
    //     0xb00a04: add             x1, x1, HEAP, lsl #32
    // 0xb00a08: StoreField: r2->field_33 = r1
    //     0xb00a08: stur            w1, [x2, #0x33]
    // 0xb00a0c: LoadField: r1 = r0->field_2f
    //     0xb00a0c: ldur            w1, [x0, #0x2f]
    // 0xb00a10: DecompressPointer r1
    //     0xb00a10: add             x1, x1, HEAP, lsl #32
    // 0xb00a14: StoreField: r2->field_37 = r1
    //     0xb00a14: stur            w1, [x2, #0x37]
    // 0xb00a18: LoadField: r1 = r0->field_33
    //     0xb00a18: ldur            w1, [x0, #0x33]
    // 0xb00a1c: DecompressPointer r1
    //     0xb00a1c: add             x1, x1, HEAP, lsl #32
    // 0xb00a20: StoreField: r2->field_3b = r1
    //     0xb00a20: stur            w1, [x2, #0x3b]
    // 0xb00a24: LoadField: r1 = r0->field_37
    //     0xb00a24: ldur            w1, [x0, #0x37]
    // 0xb00a28: DecompressPointer r1
    //     0xb00a28: add             x1, x1, HEAP, lsl #32
    // 0xb00a2c: StoreField: r2->field_3f = r1
    //     0xb00a2c: stur            w1, [x2, #0x3f]
    // 0xb00a30: r1 = <Object?>
    //     0xb00a30: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xb00a34: r0 = AllocateGrowableArray()
    //     0xb00a34: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xb00a38: mov             x1, x0
    // 0xb00a3c: ldur            x0, [fp, #-0x10]
    // 0xb00a40: StoreField: r1->field_f = r0
    //     0xb00a40: stur            w0, [x1, #0xf]
    // 0xb00a44: r0 = 26
    //     0xb00a44: mov             x0, #0x1a
    // 0xb00a48: StoreField: r1->field_b = r0
    //     0xb00a48: stur            w0, [x1, #0xb]
    // 0xb00a4c: SaveReg r1
    //     0xb00a4c: str             x1, [SP, #-8]!
    // 0xb00a50: r0 = hashAll()
    //     0xb00a50: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb00a54: add             SP, SP, #8
    // 0xb00a58: mov             x2, x0
    // 0xb00a5c: r0 = BoxInt64Instr(r2)
    //     0xb00a5c: sbfiz           x0, x2, #1, #0x1f
    //     0xb00a60: cmp             x2, x0, asr #1
    //     0xb00a64: b.eq            #0xb00a70
    //     0xb00a68: bl              #0xd69bb8
    //     0xb00a6c: stur            x2, [x0, #7]
    // 0xb00a70: LeaveFrame
    //     0xb00a70: mov             SP, fp
    //     0xb00a74: ldp             fp, lr, [SP], #0x10
    // 0xb00a78: ret
    //     0xb00a78: ret             
    // 0xb00a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00a7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00a80: b               #0xb00970
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf3ca8, size: 0x54c
    // 0xbf3ca8: EnterFrame
    //     0xbf3ca8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf3cac: mov             fp, SP
    // 0xbf3cb0: AllocStack(0x58)
    //     0xbf3cb0: sub             SP, SP, #0x58
    // 0xbf3cb4: CheckStackOverflow
    //     0xbf3cb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf3cb8: cmp             SP, x16
    //     0xbf3cbc: b.ls            #0xbf41ec
    // 0xbf3cc0: ldr             x0, [fp, #0x20]
    // 0xbf3cc4: cmp             w0, NULL
    // 0xbf3cc8: b.ne            #0xbf3ce8
    // 0xbf3ccc: ldr             x1, [fp, #0x18]
    // 0xbf3cd0: cmp             w1, NULL
    // 0xbf3cd4: b.ne            #0xbf3cec
    // 0xbf3cd8: r0 = Null
    //     0xbf3cd8: mov             x0, NULL
    // 0xbf3cdc: LeaveFrame
    //     0xbf3cdc: mov             SP, fp
    //     0xbf3ce0: ldp             fp, lr, [SP], #0x10
    // 0xbf3ce4: ret
    //     0xbf3ce4: ret             
    // 0xbf3ce8: ldr             x1, [fp, #0x18]
    // 0xbf3cec: cmp             w0, NULL
    // 0xbf3cf0: b.ne            #0xbf3cfc
    // 0xbf3cf4: r2 = Null
    //     0xbf3cf4: mov             x2, NULL
    // 0xbf3cf8: b               #0xbf3d04
    // 0xbf3cfc: LoadField: r2 = r0->field_7
    //     0xbf3cfc: ldur            w2, [x0, #7]
    // 0xbf3d00: DecompressPointer r2
    //     0xbf3d00: add             x2, x2, HEAP, lsl #32
    // 0xbf3d04: cmp             w1, NULL
    // 0xbf3d08: b.ne            #0xbf3d14
    // 0xbf3d0c: r3 = Null
    //     0xbf3d0c: mov             x3, NULL
    // 0xbf3d10: b               #0xbf3d1c
    // 0xbf3d14: LoadField: r3 = r1->field_7
    //     0xbf3d14: ldur            w3, [x1, #7]
    // 0xbf3d18: DecompressPointer r3
    //     0xbf3d18: add             x3, x3, HEAP, lsl #32
    // 0xbf3d1c: ldr             d0, [fp, #0x10]
    // 0xbf3d20: r16 = <Color?>
    //     0xbf3d20: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf3d24: ldr             x16, [x16, #0xf68]
    // 0xbf3d28: stp             x2, x16, [SP, #-0x10]!
    // 0xbf3d2c: SaveReg r3
    //     0xbf3d2c: str             x3, [SP, #-8]!
    // 0xbf3d30: SaveReg d0
    //     0xbf3d30: str             d0, [SP, #-8]!
    // 0xbf3d34: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf3d34: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf3d38: ldr             x16, [x16, #0xb80]
    // 0xbf3d3c: SaveReg r16
    //     0xbf3d3c: str             x16, [SP, #-8]!
    // 0xbf3d40: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3d40: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3d44: r0 = lerp()
    //     0xbf3d44: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3d48: add             SP, SP, #0x28
    // 0xbf3d4c: mov             x1, x0
    // 0xbf3d50: ldr             x0, [fp, #0x20]
    // 0xbf3d54: stur            x1, [fp, #-8]
    // 0xbf3d58: cmp             w0, NULL
    // 0xbf3d5c: b.ne            #0xbf3d68
    // 0xbf3d60: r3 = Null
    //     0xbf3d60: mov             x3, NULL
    // 0xbf3d64: b               #0xbf3d74
    // 0xbf3d68: LoadField: r2 = r0->field_b
    //     0xbf3d68: ldur            w2, [x0, #0xb]
    // 0xbf3d6c: DecompressPointer r2
    //     0xbf3d6c: add             x2, x2, HEAP, lsl #32
    // 0xbf3d70: mov             x3, x2
    // 0xbf3d74: ldr             x2, [fp, #0x18]
    // 0xbf3d78: cmp             w2, NULL
    // 0xbf3d7c: b.ne            #0xbf3d88
    // 0xbf3d80: r4 = Null
    //     0xbf3d80: mov             x4, NULL
    // 0xbf3d84: b               #0xbf3d90
    // 0xbf3d88: LoadField: r4 = r2->field_b
    //     0xbf3d88: ldur            w4, [x2, #0xb]
    // 0xbf3d8c: DecompressPointer r4
    //     0xbf3d8c: add             x4, x4, HEAP, lsl #32
    // 0xbf3d90: ldr             d0, [fp, #0x10]
    // 0xbf3d94: r16 = <Color?>
    //     0xbf3d94: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf3d98: ldr             x16, [x16, #0xf68]
    // 0xbf3d9c: stp             x3, x16, [SP, #-0x10]!
    // 0xbf3da0: SaveReg r4
    //     0xbf3da0: str             x4, [SP, #-8]!
    // 0xbf3da4: SaveReg d0
    //     0xbf3da4: str             d0, [SP, #-8]!
    // 0xbf3da8: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf3da8: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf3dac: ldr             x16, [x16, #0xb80]
    // 0xbf3db0: SaveReg r16
    //     0xbf3db0: str             x16, [SP, #-8]!
    // 0xbf3db4: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3db4: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3db8: r0 = lerp()
    //     0xbf3db8: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3dbc: add             SP, SP, #0x28
    // 0xbf3dc0: mov             x1, x0
    // 0xbf3dc4: ldr             x0, [fp, #0x20]
    // 0xbf3dc8: stur            x1, [fp, #-0x10]
    // 0xbf3dcc: cmp             w0, NULL
    // 0xbf3dd0: b.ne            #0xbf3ddc
    // 0xbf3dd4: r3 = Null
    //     0xbf3dd4: mov             x3, NULL
    // 0xbf3dd8: b               #0xbf3de8
    // 0xbf3ddc: LoadField: r2 = r0->field_f
    //     0xbf3ddc: ldur            w2, [x0, #0xf]
    // 0xbf3de0: DecompressPointer r2
    //     0xbf3de0: add             x2, x2, HEAP, lsl #32
    // 0xbf3de4: mov             x3, x2
    // 0xbf3de8: ldr             x2, [fp, #0x18]
    // 0xbf3dec: cmp             w2, NULL
    // 0xbf3df0: b.ne            #0xbf3dfc
    // 0xbf3df4: r4 = Null
    //     0xbf3df4: mov             x4, NULL
    // 0xbf3df8: b               #0xbf3e04
    // 0xbf3dfc: LoadField: r4 = r2->field_f
    //     0xbf3dfc: ldur            w4, [x2, #0xf]
    // 0xbf3e00: DecompressPointer r4
    //     0xbf3e00: add             x4, x4, HEAP, lsl #32
    // 0xbf3e04: ldr             d0, [fp, #0x10]
    // 0xbf3e08: r16 = <Color?>
    //     0xbf3e08: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf3e0c: ldr             x16, [x16, #0xf68]
    // 0xbf3e10: stp             x3, x16, [SP, #-0x10]!
    // 0xbf3e14: SaveReg r4
    //     0xbf3e14: str             x4, [SP, #-8]!
    // 0xbf3e18: SaveReg d0
    //     0xbf3e18: str             d0, [SP, #-8]!
    // 0xbf3e1c: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf3e1c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf3e20: ldr             x16, [x16, #0xb80]
    // 0xbf3e24: SaveReg r16
    //     0xbf3e24: str             x16, [SP, #-8]!
    // 0xbf3e28: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3e28: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3e2c: r0 = lerp()
    //     0xbf3e2c: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3e30: add             SP, SP, #0x28
    // 0xbf3e34: mov             x1, x0
    // 0xbf3e38: ldr             x0, [fp, #0x20]
    // 0xbf3e3c: stur            x1, [fp, #-0x18]
    // 0xbf3e40: cmp             w0, NULL
    // 0xbf3e44: b.ne            #0xbf3e50
    // 0xbf3e48: r3 = Null
    //     0xbf3e48: mov             x3, NULL
    // 0xbf3e4c: b               #0xbf3e5c
    // 0xbf3e50: LoadField: r2 = r0->field_13
    //     0xbf3e50: ldur            w2, [x0, #0x13]
    // 0xbf3e54: DecompressPointer r2
    //     0xbf3e54: add             x2, x2, HEAP, lsl #32
    // 0xbf3e58: mov             x3, x2
    // 0xbf3e5c: ldr             x2, [fp, #0x18]
    // 0xbf3e60: cmp             w2, NULL
    // 0xbf3e64: b.ne            #0xbf3e70
    // 0xbf3e68: r4 = Null
    //     0xbf3e68: mov             x4, NULL
    // 0xbf3e6c: b               #0xbf3e78
    // 0xbf3e70: LoadField: r4 = r2->field_13
    //     0xbf3e70: ldur            w4, [x2, #0x13]
    // 0xbf3e74: DecompressPointer r4
    //     0xbf3e74: add             x4, x4, HEAP, lsl #32
    // 0xbf3e78: ldr             d0, [fp, #0x10]
    // 0xbf3e7c: r16 = <double?>
    //     0xbf3e7c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db88] TypeArguments: <double?>
    //     0xbf3e80: ldr             x16, [x16, #0xb88]
    // 0xbf3e84: stp             x3, x16, [SP, #-0x10]!
    // 0xbf3e88: SaveReg r4
    //     0xbf3e88: str             x4, [SP, #-8]!
    // 0xbf3e8c: SaveReg d0
    //     0xbf3e8c: str             d0, [SP, #-8]!
    // 0xbf3e90: r16 = Closure: (num?, num?, double) => double? from Function 'lerpDouble': static.
    //     0xbf3e90: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db90] Closure: (num?, num?, double) => double? from Function 'lerpDouble': static. (0x7fe6e1db558c)
    //     0xbf3e94: ldr             x16, [x16, #0xb90]
    // 0xbf3e98: SaveReg r16
    //     0xbf3e98: str             x16, [SP, #-8]!
    // 0xbf3e9c: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3e9c: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3ea0: r0 = lerp()
    //     0xbf3ea0: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3ea4: add             SP, SP, #0x28
    // 0xbf3ea8: mov             x1, x0
    // 0xbf3eac: ldr             x0, [fp, #0x20]
    // 0xbf3eb0: stur            x1, [fp, #-0x20]
    // 0xbf3eb4: cmp             w0, NULL
    // 0xbf3eb8: b.ne            #0xbf3ec4
    // 0xbf3ebc: r3 = Null
    //     0xbf3ebc: mov             x3, NULL
    // 0xbf3ec0: b               #0xbf3ed0
    // 0xbf3ec4: LoadField: r2 = r0->field_17
    //     0xbf3ec4: ldur            w2, [x0, #0x17]
    // 0xbf3ec8: DecompressPointer r2
    //     0xbf3ec8: add             x2, x2, HEAP, lsl #32
    // 0xbf3ecc: mov             x3, x2
    // 0xbf3ed0: ldr             x2, [fp, #0x18]
    // 0xbf3ed4: cmp             w2, NULL
    // 0xbf3ed8: b.ne            #0xbf3ee4
    // 0xbf3edc: r4 = Null
    //     0xbf3edc: mov             x4, NULL
    // 0xbf3ee0: b               #0xbf3eec
    // 0xbf3ee4: LoadField: r4 = r2->field_17
    //     0xbf3ee4: ldur            w4, [x2, #0x17]
    // 0xbf3ee8: DecompressPointer r4
    //     0xbf3ee8: add             x4, x4, HEAP, lsl #32
    // 0xbf3eec: ldr             d0, [fp, #0x10]
    // 0xbf3ef0: r16 = <EdgeInsetsGeometry?>
    //     0xbf3ef0: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db98] TypeArguments: <EdgeInsetsGeometry?>
    //     0xbf3ef4: ldr             x16, [x16, #0xb98]
    // 0xbf3ef8: stp             x3, x16, [SP, #-0x10]!
    // 0xbf3efc: SaveReg r4
    //     0xbf3efc: str             x4, [SP, #-8]!
    // 0xbf3f00: SaveReg d0
    //     0xbf3f00: str             d0, [SP, #-8]!
    // 0xbf3f04: r16 = Closure: (EdgeInsetsGeometry?, EdgeInsetsGeometry?, double) => EdgeInsetsGeometry? from Function 'lerp': static.
    //     0xbf3f04: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba0] Closure: (EdgeInsetsGeometry?, EdgeInsetsGeometry?, double) => EdgeInsetsGeometry? from Function 'lerp': static. (0x7fe6e23f0ed4)
    //     0xbf3f08: ldr             x16, [x16, #0xba0]
    // 0xbf3f0c: SaveReg r16
    //     0xbf3f0c: str             x16, [SP, #-8]!
    // 0xbf3f10: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3f10: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3f14: r0 = lerp()
    //     0xbf3f14: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3f18: add             SP, SP, #0x28
    // 0xbf3f1c: mov             x1, x0
    // 0xbf3f20: ldr             x0, [fp, #0x20]
    // 0xbf3f24: stur            x1, [fp, #-0x28]
    // 0xbf3f28: cmp             w0, NULL
    // 0xbf3f2c: b.ne            #0xbf3f38
    // 0xbf3f30: r3 = Null
    //     0xbf3f30: mov             x3, NULL
    // 0xbf3f34: b               #0xbf3f44
    // 0xbf3f38: LoadField: r2 = r0->field_1b
    //     0xbf3f38: ldur            w2, [x0, #0x1b]
    // 0xbf3f3c: DecompressPointer r2
    //     0xbf3f3c: add             x2, x2, HEAP, lsl #32
    // 0xbf3f40: mov             x3, x2
    // 0xbf3f44: ldr             x2, [fp, #0x18]
    // 0xbf3f48: cmp             w2, NULL
    // 0xbf3f4c: b.ne            #0xbf3f58
    // 0xbf3f50: r4 = Null
    //     0xbf3f50: mov             x4, NULL
    // 0xbf3f54: b               #0xbf3f60
    // 0xbf3f58: LoadField: r4 = r2->field_1b
    //     0xbf3f58: ldur            w4, [x2, #0x1b]
    // 0xbf3f5c: DecompressPointer r4
    //     0xbf3f5c: add             x4, x4, HEAP, lsl #32
    // 0xbf3f60: ldr             d0, [fp, #0x10]
    // 0xbf3f64: r16 = <Size?>
    //     0xbf3f64: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0xbf3f68: ldr             x16, [x16, #0xba8]
    // 0xbf3f6c: stp             x3, x16, [SP, #-0x10]!
    // 0xbf3f70: SaveReg r4
    //     0xbf3f70: str             x4, [SP, #-8]!
    // 0xbf3f74: SaveReg d0
    //     0xbf3f74: str             d0, [SP, #-8]!
    // 0xbf3f78: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0xbf3f78: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb0] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7fe6e23ec4d0)
    //     0xbf3f7c: ldr             x16, [x16, #0xbb0]
    // 0xbf3f80: SaveReg r16
    //     0xbf3f80: str             x16, [SP, #-8]!
    // 0xbf3f84: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3f84: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3f88: r0 = lerp()
    //     0xbf3f88: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3f8c: add             SP, SP, #0x28
    // 0xbf3f90: mov             x1, x0
    // 0xbf3f94: ldr             x0, [fp, #0x20]
    // 0xbf3f98: stur            x1, [fp, #-0x30]
    // 0xbf3f9c: cmp             w0, NULL
    // 0xbf3fa0: b.ne            #0xbf3fac
    // 0xbf3fa4: r3 = Null
    //     0xbf3fa4: mov             x3, NULL
    // 0xbf3fa8: b               #0xbf3fb8
    // 0xbf3fac: LoadField: r2 = r0->field_1f
    //     0xbf3fac: ldur            w2, [x0, #0x1f]
    // 0xbf3fb0: DecompressPointer r2
    //     0xbf3fb0: add             x2, x2, HEAP, lsl #32
    // 0xbf3fb4: mov             x3, x2
    // 0xbf3fb8: ldr             x2, [fp, #0x18]
    // 0xbf3fbc: cmp             w2, NULL
    // 0xbf3fc0: b.ne            #0xbf3fcc
    // 0xbf3fc4: r4 = Null
    //     0xbf3fc4: mov             x4, NULL
    // 0xbf3fc8: b               #0xbf3fd4
    // 0xbf3fcc: LoadField: r4 = r2->field_1f
    //     0xbf3fcc: ldur            w4, [x2, #0x1f]
    // 0xbf3fd0: DecompressPointer r4
    //     0xbf3fd0: add             x4, x4, HEAP, lsl #32
    // 0xbf3fd4: ldr             d0, [fp, #0x10]
    // 0xbf3fd8: r16 = <Size?>
    //     0xbf3fd8: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0xbf3fdc: ldr             x16, [x16, #0xba8]
    // 0xbf3fe0: stp             x3, x16, [SP, #-0x10]!
    // 0xbf3fe4: SaveReg r4
    //     0xbf3fe4: str             x4, [SP, #-8]!
    // 0xbf3fe8: SaveReg d0
    //     0xbf3fe8: str             d0, [SP, #-8]!
    // 0xbf3fec: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0xbf3fec: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb0] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7fe6e23ec4d0)
    //     0xbf3ff0: ldr             x16, [x16, #0xbb0]
    // 0xbf3ff4: SaveReg r16
    //     0xbf3ff4: str             x16, [SP, #-8]!
    // 0xbf3ff8: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3ff8: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3ffc: r0 = lerp()
    //     0xbf3ffc: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf4000: add             SP, SP, #0x28
    // 0xbf4004: mov             x1, x0
    // 0xbf4008: ldr             x0, [fp, #0x20]
    // 0xbf400c: stur            x1, [fp, #-0x38]
    // 0xbf4010: cmp             w0, NULL
    // 0xbf4014: b.ne            #0xbf4020
    // 0xbf4018: r3 = Null
    //     0xbf4018: mov             x3, NULL
    // 0xbf401c: b               #0xbf402c
    // 0xbf4020: LoadField: r2 = r0->field_23
    //     0xbf4020: ldur            w2, [x0, #0x23]
    // 0xbf4024: DecompressPointer r2
    //     0xbf4024: add             x2, x2, HEAP, lsl #32
    // 0xbf4028: mov             x3, x2
    // 0xbf402c: ldr             x2, [fp, #0x18]
    // 0xbf4030: cmp             w2, NULL
    // 0xbf4034: b.ne            #0xbf4040
    // 0xbf4038: r4 = Null
    //     0xbf4038: mov             x4, NULL
    // 0xbf403c: b               #0xbf4048
    // 0xbf4040: LoadField: r4 = r2->field_23
    //     0xbf4040: ldur            w4, [x2, #0x23]
    // 0xbf4044: DecompressPointer r4
    //     0xbf4044: add             x4, x4, HEAP, lsl #32
    // 0xbf4048: ldr             d0, [fp, #0x10]
    // 0xbf404c: r16 = <Size?>
    //     0xbf404c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0xbf4050: ldr             x16, [x16, #0xba8]
    // 0xbf4054: stp             x3, x16, [SP, #-0x10]!
    // 0xbf4058: SaveReg r4
    //     0xbf4058: str             x4, [SP, #-8]!
    // 0xbf405c: SaveReg d0
    //     0xbf405c: str             d0, [SP, #-8]!
    // 0xbf4060: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0xbf4060: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb0] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7fe6e23ec4d0)
    //     0xbf4064: ldr             x16, [x16, #0xbb0]
    // 0xbf4068: SaveReg r16
    //     0xbf4068: str             x16, [SP, #-8]!
    // 0xbf406c: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf406c: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf4070: r0 = lerp()
    //     0xbf4070: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf4074: add             SP, SP, #0x28
    // 0xbf4078: mov             x1, x0
    // 0xbf407c: ldr             x0, [fp, #0x20]
    // 0xbf4080: stur            x1, [fp, #-0x50]
    // 0xbf4084: cmp             w0, NULL
    // 0xbf4088: b.ne            #0xbf4094
    // 0xbf408c: r3 = Null
    //     0xbf408c: mov             x3, NULL
    // 0xbf4090: b               #0xbf40a0
    // 0xbf4094: LoadField: r2 = r0->field_27
    //     0xbf4094: ldur            w2, [x0, #0x27]
    // 0xbf4098: DecompressPointer r2
    //     0xbf4098: add             x2, x2, HEAP, lsl #32
    // 0xbf409c: mov             x3, x2
    // 0xbf40a0: ldr             x2, [fp, #0x18]
    // 0xbf40a4: stur            x3, [fp, #-0x48]
    // 0xbf40a8: cmp             w2, NULL
    // 0xbf40ac: b.ne            #0xbf40b8
    // 0xbf40b0: r4 = Null
    //     0xbf40b0: mov             x4, NULL
    // 0xbf40b4: b               #0xbf40c0
    // 0xbf40b8: LoadField: r4 = r2->field_27
    //     0xbf40b8: ldur            w4, [x2, #0x27]
    // 0xbf40bc: DecompressPointer r4
    //     0xbf40bc: add             x4, x4, HEAP, lsl #32
    // 0xbf40c0: ldr             d0, [fp, #0x10]
    // 0xbf40c4: stur            x4, [fp, #-0x40]
    // 0xbf40c8: r0 = _LerpSides()
    //     0xbf40c8: bl              #0xbf4200  ; Allocate_LerpSidesStub -> _LerpSides (size=0x18)
    // 0xbf40cc: mov             x1, x0
    // 0xbf40d0: ldur            x0, [fp, #-0x48]
    // 0xbf40d4: stur            x1, [fp, #-0x58]
    // 0xbf40d8: StoreField: r1->field_7 = r0
    //     0xbf40d8: stur            w0, [x1, #7]
    // 0xbf40dc: ldur            x0, [fp, #-0x40]
    // 0xbf40e0: StoreField: r1->field_b = r0
    //     0xbf40e0: stur            w0, [x1, #0xb]
    // 0xbf40e4: ldr             d0, [fp, #0x10]
    // 0xbf40e8: StoreField: r1->field_f = d0
    //     0xbf40e8: stur            d0, [x1, #0xf]
    // 0xbf40ec: ldr             x0, [fp, #0x20]
    // 0xbf40f0: cmp             w0, NULL
    // 0xbf40f4: b.ne            #0xbf4100
    // 0xbf40f8: r2 = Null
    //     0xbf40f8: mov             x2, NULL
    // 0xbf40fc: b               #0xbf4108
    // 0xbf4100: LoadField: r2 = r0->field_2b
    //     0xbf4100: ldur            w2, [x0, #0x2b]
    // 0xbf4104: DecompressPointer r2
    //     0xbf4104: add             x2, x2, HEAP, lsl #32
    // 0xbf4108: ldr             x0, [fp, #0x18]
    // 0xbf410c: cmp             w0, NULL
    // 0xbf4110: b.ne            #0xbf411c
    // 0xbf4114: r10 = Null
    //     0xbf4114: mov             x10, NULL
    // 0xbf4118: b               #0xbf4128
    // 0xbf411c: LoadField: r3 = r0->field_2b
    //     0xbf411c: ldur            w3, [x0, #0x2b]
    // 0xbf4120: DecompressPointer r3
    //     0xbf4120: add             x3, x3, HEAP, lsl #32
    // 0xbf4124: mov             x10, x3
    // 0xbf4128: ldur            x9, [fp, #-8]
    // 0xbf412c: ldur            x8, [fp, #-0x10]
    // 0xbf4130: ldur            x7, [fp, #-0x18]
    // 0xbf4134: ldur            x6, [fp, #-0x20]
    // 0xbf4138: ldur            x5, [fp, #-0x28]
    // 0xbf413c: ldur            x4, [fp, #-0x30]
    // 0xbf4140: ldur            x3, [fp, #-0x38]
    // 0xbf4144: ldur            x0, [fp, #-0x50]
    // 0xbf4148: r16 = <OutlinedBorder?>
    //     0xbf4148: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb8] TypeArguments: <OutlinedBorder?>
    //     0xbf414c: ldr             x16, [x16, #0xbb8]
    // 0xbf4150: stp             x2, x16, [SP, #-0x10]!
    // 0xbf4154: SaveReg r10
    //     0xbf4154: str             x10, [SP, #-8]!
    // 0xbf4158: SaveReg d0
    //     0xbf4158: str             d0, [SP, #-8]!
    // 0xbf415c: r16 = Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static.
    //     0xbf415c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbc0] Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static. (0x7fe6e23f0d9c)
    //     0xbf4160: ldr             x16, [x16, #0xbc0]
    // 0xbf4164: SaveReg r16
    //     0xbf4164: str             x16, [SP, #-8]!
    // 0xbf4168: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf4168: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf416c: r0 = lerp()
    //     0xbf416c: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf4170: add             SP, SP, #0x28
    // 0xbf4174: stur            x0, [fp, #-0x40]
    // 0xbf4178: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf417c: ldr             d0, [fp, #0x10]
    // 0xbf4180: SaveReg d0
    //     0xbf4180: str             d0, [SP, #-8]!
    // 0xbf4184: r0 = lerp()
    //     0xbf4184: bl              #0xbefd44  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0xbf4188: add             SP, SP, #0x18
    // 0xbf418c: r0 = MenuStyle()
    //     0xbf418c: bl              #0xbf41f4  ; AllocateMenuStyleStub -> MenuStyle (size=0x3c)
    // 0xbf4190: ldur            x1, [fp, #-8]
    // 0xbf4194: StoreField: r0->field_7 = r1
    //     0xbf4194: stur            w1, [x0, #7]
    // 0xbf4198: ldur            x1, [fp, #-0x10]
    // 0xbf419c: StoreField: r0->field_b = r1
    //     0xbf419c: stur            w1, [x0, #0xb]
    // 0xbf41a0: ldur            x1, [fp, #-0x18]
    // 0xbf41a4: StoreField: r0->field_f = r1
    //     0xbf41a4: stur            w1, [x0, #0xf]
    // 0xbf41a8: ldur            x1, [fp, #-0x20]
    // 0xbf41ac: StoreField: r0->field_13 = r1
    //     0xbf41ac: stur            w1, [x0, #0x13]
    // 0xbf41b0: ldur            x1, [fp, #-0x28]
    // 0xbf41b4: StoreField: r0->field_17 = r1
    //     0xbf41b4: stur            w1, [x0, #0x17]
    // 0xbf41b8: ldur            x1, [fp, #-0x30]
    // 0xbf41bc: StoreField: r0->field_1b = r1
    //     0xbf41bc: stur            w1, [x0, #0x1b]
    // 0xbf41c0: ldur            x1, [fp, #-0x38]
    // 0xbf41c4: StoreField: r0->field_1f = r1
    //     0xbf41c4: stur            w1, [x0, #0x1f]
    // 0xbf41c8: ldur            x1, [fp, #-0x50]
    // 0xbf41cc: StoreField: r0->field_23 = r1
    //     0xbf41cc: stur            w1, [x0, #0x23]
    // 0xbf41d0: ldur            x1, [fp, #-0x58]
    // 0xbf41d4: StoreField: r0->field_27 = r1
    //     0xbf41d4: stur            w1, [x0, #0x27]
    // 0xbf41d8: ldur            x1, [fp, #-0x40]
    // 0xbf41dc: StoreField: r0->field_2b = r1
    //     0xbf41dc: stur            w1, [x0, #0x2b]
    // 0xbf41e0: LeaveFrame
    //     0xbf41e0: mov             SP, fp
    //     0xbf41e4: ldp             fp, lr, [SP], #0x10
    // 0xbf41e8: ret
    //     0xbf41e8: ret             
    // 0xbf41ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf41ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf41f0: b               #0xbf3cc0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8bd64, size: 0x1e8
    // 0xc8bd64: EnterFrame
    //     0xc8bd64: stp             fp, lr, [SP, #-0x10]!
    //     0xc8bd68: mov             fp, SP
    // 0xc8bd6c: CheckStackOverflow
    //     0xc8bd6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8bd70: cmp             SP, x16
    //     0xc8bd74: b.ls            #0xc8bf44
    // 0xc8bd78: ldr             x1, [fp, #0x10]
    // 0xc8bd7c: cmp             w1, NULL
    // 0xc8bd80: b.ne            #0xc8bd94
    // 0xc8bd84: r0 = false
    //     0xc8bd84: add             x0, NULL, #0x30  ; false
    // 0xc8bd88: LeaveFrame
    //     0xc8bd88: mov             SP, fp
    //     0xc8bd8c: ldp             fp, lr, [SP], #0x10
    // 0xc8bd90: ret
    //     0xc8bd90: ret             
    // 0xc8bd94: ldr             x2, [fp, #0x18]
    // 0xc8bd98: cmp             w2, w1
    // 0xc8bd9c: b.ne            #0xc8bdb0
    // 0xc8bda0: r0 = true
    //     0xc8bda0: add             x0, NULL, #0x20  ; true
    // 0xc8bda4: LeaveFrame
    //     0xc8bda4: mov             SP, fp
    //     0xc8bda8: ldp             fp, lr, [SP], #0x10
    // 0xc8bdac: ret
    //     0xc8bdac: ret             
    // 0xc8bdb0: r0 = 59
    //     0xc8bdb0: mov             x0, #0x3b
    // 0xc8bdb4: branchIfSmi(r1, 0xc8bdc0)
    //     0xc8bdb4: tbz             w1, #0, #0xc8bdc0
    // 0xc8bdb8: r0 = LoadClassIdInstr(r1)
    //     0xc8bdb8: ldur            x0, [x1, #-1]
    //     0xc8bdbc: ubfx            x0, x0, #0xc, #0x14
    // 0xc8bdc0: SaveReg r1
    //     0xc8bdc0: str             x1, [SP, #-8]!
    // 0xc8bdc4: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8bdc4: mov             x17, #0x57c5
    //     0xc8bdc8: add             lr, x0, x17
    //     0xc8bdcc: ldr             lr, [x21, lr, lsl #3]
    //     0xc8bdd0: blr             lr
    // 0xc8bdd4: add             SP, SP, #8
    // 0xc8bdd8: r1 = LoadClassIdInstr(r0)
    //     0xc8bdd8: ldur            x1, [x0, #-1]
    //     0xc8bddc: ubfx            x1, x1, #0xc, #0x14
    // 0xc8bde0: r16 = MenuStyle
    //     0xc8bde0: add             x16, PP, #0x37, lsl #12  ; [pp+0x377c0] Type: MenuStyle
    //     0xc8bde4: ldr             x16, [x16, #0x7c0]
    // 0xc8bde8: stp             x16, x0, [SP, #-0x10]!
    // 0xc8bdec: mov             x0, x1
    // 0xc8bdf0: mov             lr, x0
    // 0xc8bdf4: ldr             lr, [x21, lr, lsl #3]
    // 0xc8bdf8: blr             lr
    // 0xc8bdfc: add             SP, SP, #0x10
    // 0xc8be00: tbz             w0, #4, #0xc8be14
    // 0xc8be04: r0 = false
    //     0xc8be04: add             x0, NULL, #0x30  ; false
    // 0xc8be08: LeaveFrame
    //     0xc8be08: mov             SP, fp
    //     0xc8be0c: ldp             fp, lr, [SP], #0x10
    // 0xc8be10: ret
    //     0xc8be10: ret             
    // 0xc8be14: ldr             x1, [fp, #0x10]
    // 0xc8be18: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8be18: mov             x2, #0x76
    //     0xc8be1c: tbz             w1, #0, #0xc8be2c
    //     0xc8be20: ldur            x2, [x1, #-1]
    //     0xc8be24: ubfx            x2, x2, #0xc, #0x14
    //     0xc8be28: lsl             x2, x2, #1
    // 0xc8be2c: r17 = 5566
    //     0xc8be2c: mov             x17, #0x15be
    // 0xc8be30: cmp             w2, w17
    // 0xc8be34: b.ne            #0xc8bf34
    // 0xc8be38: ldr             x2, [fp, #0x18]
    // 0xc8be3c: LoadField: r3 = r1->field_7
    //     0xc8be3c: ldur            w3, [x1, #7]
    // 0xc8be40: DecompressPointer r3
    //     0xc8be40: add             x3, x3, HEAP, lsl #32
    // 0xc8be44: LoadField: r4 = r2->field_7
    //     0xc8be44: ldur            w4, [x2, #7]
    // 0xc8be48: DecompressPointer r4
    //     0xc8be48: add             x4, x4, HEAP, lsl #32
    // 0xc8be4c: cmp             w3, w4
    // 0xc8be50: b.ne            #0xc8bf34
    // 0xc8be54: LoadField: r3 = r1->field_b
    //     0xc8be54: ldur            w3, [x1, #0xb]
    // 0xc8be58: DecompressPointer r3
    //     0xc8be58: add             x3, x3, HEAP, lsl #32
    // 0xc8be5c: LoadField: r4 = r2->field_b
    //     0xc8be5c: ldur            w4, [x2, #0xb]
    // 0xc8be60: DecompressPointer r4
    //     0xc8be60: add             x4, x4, HEAP, lsl #32
    // 0xc8be64: cmp             w3, w4
    // 0xc8be68: b.ne            #0xc8bf34
    // 0xc8be6c: LoadField: r3 = r1->field_f
    //     0xc8be6c: ldur            w3, [x1, #0xf]
    // 0xc8be70: DecompressPointer r3
    //     0xc8be70: add             x3, x3, HEAP, lsl #32
    // 0xc8be74: LoadField: r4 = r2->field_f
    //     0xc8be74: ldur            w4, [x2, #0xf]
    // 0xc8be78: DecompressPointer r4
    //     0xc8be78: add             x4, x4, HEAP, lsl #32
    // 0xc8be7c: cmp             w3, w4
    // 0xc8be80: b.ne            #0xc8bf34
    // 0xc8be84: LoadField: r3 = r1->field_13
    //     0xc8be84: ldur            w3, [x1, #0x13]
    // 0xc8be88: DecompressPointer r3
    //     0xc8be88: add             x3, x3, HEAP, lsl #32
    // 0xc8be8c: LoadField: r4 = r2->field_13
    //     0xc8be8c: ldur            w4, [x2, #0x13]
    // 0xc8be90: DecompressPointer r4
    //     0xc8be90: add             x4, x4, HEAP, lsl #32
    // 0xc8be94: cmp             w3, w4
    // 0xc8be98: b.ne            #0xc8bf34
    // 0xc8be9c: LoadField: r3 = r1->field_17
    //     0xc8be9c: ldur            w3, [x1, #0x17]
    // 0xc8bea0: DecompressPointer r3
    //     0xc8bea0: add             x3, x3, HEAP, lsl #32
    // 0xc8bea4: LoadField: r4 = r2->field_17
    //     0xc8bea4: ldur            w4, [x2, #0x17]
    // 0xc8bea8: DecompressPointer r4
    //     0xc8bea8: add             x4, x4, HEAP, lsl #32
    // 0xc8beac: cmp             w3, w4
    // 0xc8beb0: b.ne            #0xc8bf34
    // 0xc8beb4: LoadField: r3 = r1->field_1b
    //     0xc8beb4: ldur            w3, [x1, #0x1b]
    // 0xc8beb8: DecompressPointer r3
    //     0xc8beb8: add             x3, x3, HEAP, lsl #32
    // 0xc8bebc: LoadField: r4 = r2->field_1b
    //     0xc8bebc: ldur            w4, [x2, #0x1b]
    // 0xc8bec0: DecompressPointer r4
    //     0xc8bec0: add             x4, x4, HEAP, lsl #32
    // 0xc8bec4: cmp             w3, w4
    // 0xc8bec8: b.ne            #0xc8bf34
    // 0xc8becc: LoadField: r3 = r1->field_1f
    //     0xc8becc: ldur            w3, [x1, #0x1f]
    // 0xc8bed0: DecompressPointer r3
    //     0xc8bed0: add             x3, x3, HEAP, lsl #32
    // 0xc8bed4: LoadField: r4 = r2->field_1f
    //     0xc8bed4: ldur            w4, [x2, #0x1f]
    // 0xc8bed8: DecompressPointer r4
    //     0xc8bed8: add             x4, x4, HEAP, lsl #32
    // 0xc8bedc: cmp             w3, w4
    // 0xc8bee0: b.ne            #0xc8bf34
    // 0xc8bee4: LoadField: r3 = r1->field_23
    //     0xc8bee4: ldur            w3, [x1, #0x23]
    // 0xc8bee8: DecompressPointer r3
    //     0xc8bee8: add             x3, x3, HEAP, lsl #32
    // 0xc8beec: LoadField: r4 = r2->field_23
    //     0xc8beec: ldur            w4, [x2, #0x23]
    // 0xc8bef0: DecompressPointer r4
    //     0xc8bef0: add             x4, x4, HEAP, lsl #32
    // 0xc8bef4: cmp             w3, w4
    // 0xc8bef8: b.ne            #0xc8bf34
    // 0xc8befc: LoadField: r3 = r1->field_27
    //     0xc8befc: ldur            w3, [x1, #0x27]
    // 0xc8bf00: DecompressPointer r3
    //     0xc8bf00: add             x3, x3, HEAP, lsl #32
    // 0xc8bf04: LoadField: r4 = r2->field_27
    //     0xc8bf04: ldur            w4, [x2, #0x27]
    // 0xc8bf08: DecompressPointer r4
    //     0xc8bf08: add             x4, x4, HEAP, lsl #32
    // 0xc8bf0c: cmp             w3, w4
    // 0xc8bf10: b.ne            #0xc8bf34
    // 0xc8bf14: LoadField: r3 = r1->field_2b
    //     0xc8bf14: ldur            w3, [x1, #0x2b]
    // 0xc8bf18: DecompressPointer r3
    //     0xc8bf18: add             x3, x3, HEAP, lsl #32
    // 0xc8bf1c: LoadField: r1 = r2->field_2b
    //     0xc8bf1c: ldur            w1, [x2, #0x2b]
    // 0xc8bf20: DecompressPointer r1
    //     0xc8bf20: add             x1, x1, HEAP, lsl #32
    // 0xc8bf24: cmp             w3, w1
    // 0xc8bf28: b.ne            #0xc8bf34
    // 0xc8bf2c: r0 = true
    //     0xc8bf2c: add             x0, NULL, #0x20  ; true
    // 0xc8bf30: b               #0xc8bf38
    // 0xc8bf34: r0 = false
    //     0xc8bf34: add             x0, NULL, #0x30  ; false
    // 0xc8bf38: LeaveFrame
    //     0xc8bf38: mov             SP, fp
    //     0xc8bf3c: ldp             fp, lr, [SP], #0x10
    // 0xc8bf40: ret
    //     0xc8bf40: ret             
    // 0xc8bf44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8bf44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8bf48: b               #0xc8bd78
  }
}

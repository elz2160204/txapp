// lib: , url: package:flutter/src/material/app.dart

// class id: 1049178, size: 0x8
class :: {
}

// class id: 2250, size: 0x10, field offset: 0xc
//   const constructor, 
class MaterialScrollBehavior extends ScrollBehavior {

  _ buildOverscrollIndicator(/* No info */) {
    // ** addr: 0xcf7688, size: 0x1ac
    // 0xcf7688: EnterFrame
    //     0xcf7688: stp             fp, lr, [SP, #-0x10]!
    //     0xcf768c: mov             fp, SP
    // 0xcf7690: AllocStack(0x10)
    //     0xcf7690: sub             SP, SP, #0x10
    // 0xcf7694: CheckStackOverflow
    //     0xcf7694: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf7698: cmp             SP, x16
    //     0xcf769c: b.ls            #0xcf782c
    // 0xcf76a0: ldr             x16, [fp, #0x20]
    // 0xcf76a4: SaveReg r16
    //     0xcf76a4: str             x16, [SP, #-8]!
    // 0xcf76a8: r0 = of()
    //     0xcf76a8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcf76ac: add             SP, SP, #8
    // 0xcf76b0: LoadField: r1 = r0->field_2b
    //     0xcf76b0: ldur            w1, [x0, #0x2b]
    // 0xcf76b4: DecompressPointer r1
    //     0xcf76b4: add             x1, x1, HEAP, lsl #32
    // 0xcf76b8: tbnz            w1, #4, #0xcf76c8
    // 0xcf76bc: r0 = Instance_AndroidOverscrollIndicator
    //     0xcf76bc: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b9c8] Obj!AndroidOverscrollIndicator@b63651
    //     0xcf76c0: ldr             x0, [x0, #0x9c8]
    // 0xcf76c4: b               #0xcf76e0
    // 0xcf76c8: ldr             x16, [fp, #0x20]
    // 0xcf76cc: SaveReg r16
    //     0xcf76cc: str             x16, [SP, #-8]!
    // 0xcf76d0: r0 = of()
    //     0xcf76d0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcf76d4: add             SP, SP, #8
    // 0xcf76d8: r0 = Instance_AndroidOverscrollIndicator
    //     0xcf76d8: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b9d0] Obj!AndroidOverscrollIndicator@b63631
    //     0xcf76dc: ldr             x0, [x0, #0x9d0]
    // 0xcf76e0: stur            x0, [fp, #-8]
    // 0xcf76e4: ldr             x16, [fp, #0x20]
    // 0xcf76e8: SaveReg r16
    //     0xcf76e8: str             x16, [SP, #-8]!
    // 0xcf76ec: r0 = of()
    //     0xcf76ec: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcf76f0: add             SP, SP, #8
    // 0xcf76f4: LoadField: r1 = r0->field_1f
    //     0xcf76f4: ldur            w1, [x0, #0x1f]
    // 0xcf76f8: DecompressPointer r1
    //     0xcf76f8: add             x1, x1, HEAP, lsl #32
    // 0xcf76fc: LoadField: r0 = r1->field_7
    //     0xcf76fc: ldur            x0, [x1, #7]
    // 0xcf7700: cmp             x0, #2
    // 0xcf7704: b.gt            #0xcf7818
    // 0xcf7708: cmp             x0, #1
    // 0xcf770c: b.gt            #0xcf7810
    // 0xcf7710: cmp             x0, #0
    // 0xcf7714: b.gt            #0xcf7790
    // 0xcf7718: ldur            x0, [fp, #-8]
    // 0xcf771c: LoadField: r1 = r0->field_7
    //     0xcf771c: ldur            x1, [x0, #7]
    // 0xcf7720: cmp             x1, #0
    // 0xcf7724: b.gt            #0xcf777c
    // 0xcf7728: ldr             x1, [fp, #0x18]
    // 0xcf772c: ldr             x0, [fp, #0x10]
    // 0xcf7730: LoadField: r2 = r0->field_7
    //     0xcf7730: ldur            w2, [x0, #7]
    // 0xcf7734: DecompressPointer r2
    //     0xcf7734: add             x2, x2, HEAP, lsl #32
    // 0xcf7738: stur            x2, [fp, #-8]
    // 0xcf773c: r0 = StretchingOverscrollIndicator()
    //     0xcf773c: bl              #0xcf7840  ; AllocateStretchingOverscrollIndicatorStub -> StretchingOverscrollIndicator (size=0x1c)
    // 0xcf7740: mov             x1, x0
    // 0xcf7744: ldur            x0, [fp, #-8]
    // 0xcf7748: StoreField: r1->field_b = r0
    //     0xcf7748: stur            w0, [x1, #0xb]
    // 0xcf774c: r2 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xcf774c: add             x2, PP, #0x27, lsl #12  ; [pp+0x27358] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7fe6e20b793c)
    //     0xcf7750: ldr             x2, [x2, #0x358]
    // 0xcf7754: StoreField: r1->field_f = r2
    //     0xcf7754: stur            w2, [x1, #0xf]
    // 0xcf7758: r0 = Instance_Clip
    //     0xcf7758: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0xcf775c: ldr             x0, [x0, #0x678]
    // 0xcf7760: StoreField: r1->field_13 = r0
    //     0xcf7760: stur            w0, [x1, #0x13]
    // 0xcf7764: ldr             x3, [fp, #0x18]
    // 0xcf7768: StoreField: r1->field_17 = r3
    //     0xcf7768: stur            w3, [x1, #0x17]
    // 0xcf776c: mov             x0, x1
    // 0xcf7770: LeaveFrame
    //     0xcf7770: mov             SP, fp
    //     0xcf7774: ldp             fp, lr, [SP], #0x10
    // 0xcf7778: ret
    //     0xcf7778: ret             
    // 0xcf777c: ldr             x3, [fp, #0x18]
    // 0xcf7780: ldr             x0, [fp, #0x10]
    // 0xcf7784: r2 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xcf7784: add             x2, PP, #0x27, lsl #12  ; [pp+0x27358] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7fe6e20b793c)
    //     0xcf7788: ldr             x2, [x2, #0x358]
    // 0xcf778c: b               #0xcf77a0
    // 0xcf7790: ldr             x3, [fp, #0x18]
    // 0xcf7794: ldr             x0, [fp, #0x10]
    // 0xcf7798: r2 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xcf7798: add             x2, PP, #0x27, lsl #12  ; [pp+0x27358] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7fe6e20b793c)
    //     0xcf779c: ldr             x2, [x2, #0x358]
    // 0xcf77a0: LoadField: r1 = r0->field_7
    //     0xcf77a0: ldur            w1, [x0, #7]
    // 0xcf77a4: DecompressPointer r1
    //     0xcf77a4: add             x1, x1, HEAP, lsl #32
    // 0xcf77a8: stur            x1, [fp, #-8]
    // 0xcf77ac: ldr             x16, [fp, #0x20]
    // 0xcf77b0: SaveReg r16
    //     0xcf77b0: str             x16, [SP, #-8]!
    // 0xcf77b4: r0 = of()
    //     0xcf77b4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcf77b8: add             SP, SP, #8
    // 0xcf77bc: LoadField: r1 = r0->field_3f
    //     0xcf77bc: ldur            w1, [x0, #0x3f]
    // 0xcf77c0: DecompressPointer r1
    //     0xcf77c0: add             x1, x1, HEAP, lsl #32
    // 0xcf77c4: LoadField: r0 = r1->field_1b
    //     0xcf77c4: ldur            w0, [x1, #0x1b]
    // 0xcf77c8: DecompressPointer r0
    //     0xcf77c8: add             x0, x0, HEAP, lsl #32
    // 0xcf77cc: stur            x0, [fp, #-0x10]
    // 0xcf77d0: r0 = GlowingOverscrollIndicator()
    //     0xcf77d0: bl              #0xcf7834  ; AllocateGlowingOverscrollIndicatorStub -> GlowingOverscrollIndicator (size=0x24)
    // 0xcf77d4: r1 = true
    //     0xcf77d4: add             x1, NULL, #0x20  ; true
    // 0xcf77d8: StoreField: r0->field_b = r1
    //     0xcf77d8: stur            w1, [x0, #0xb]
    // 0xcf77dc: StoreField: r0->field_f = r1
    //     0xcf77dc: stur            w1, [x0, #0xf]
    // 0xcf77e0: ldur            x1, [fp, #-8]
    // 0xcf77e4: StoreField: r0->field_13 = r1
    //     0xcf77e4: stur            w1, [x0, #0x13]
    // 0xcf77e8: ldur            x1, [fp, #-0x10]
    // 0xcf77ec: StoreField: r0->field_17 = r1
    //     0xcf77ec: stur            w1, [x0, #0x17]
    // 0xcf77f0: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xcf77f0: add             x1, PP, #0x27, lsl #12  ; [pp+0x27358] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7fe6e20b793c)
    //     0xcf77f4: ldr             x1, [x1, #0x358]
    // 0xcf77f8: StoreField: r0->field_1b = r1
    //     0xcf77f8: stur            w1, [x0, #0x1b]
    // 0xcf77fc: ldr             x1, [fp, #0x18]
    // 0xcf7800: StoreField: r0->field_1f = r1
    //     0xcf7800: stur            w1, [x0, #0x1f]
    // 0xcf7804: LeaveFrame
    //     0xcf7804: mov             SP, fp
    //     0xcf7808: ldp             fp, lr, [SP], #0x10
    // 0xcf780c: ret
    //     0xcf780c: ret             
    // 0xcf7810: ldr             x1, [fp, #0x18]
    // 0xcf7814: b               #0xcf781c
    // 0xcf7818: ldr             x1, [fp, #0x18]
    // 0xcf781c: mov             x0, x1
    // 0xcf7820: LeaveFrame
    //     0xcf7820: mov             SP, fp
    //     0xcf7824: ldp             fp, lr, [SP], #0x10
    // 0xcf7828: ret
    //     0xcf7828: ret             
    // 0xcf782c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf782c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7830: b               #0xcf76a0
  }
  _ buildScrollbar(/* No info */) {
    // ** addr: 0xcf79d8, size: 0xe4
    // 0xcf79d8: EnterFrame
    //     0xcf79d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf79dc: mov             fp, SP
    // 0xcf79e0: AllocStack(0x8)
    //     0xcf79e0: sub             SP, SP, #8
    // 0xcf79e4: CheckStackOverflow
    //     0xcf79e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf79e8: cmp             SP, x16
    //     0xcf79ec: b.ls            #0xcf7ab4
    // 0xcf79f0: ldr             x0, [fp, #0x10]
    // 0xcf79f4: LoadField: r1 = r0->field_7
    //     0xcf79f4: ldur            w1, [x0, #7]
    // 0xcf79f8: DecompressPointer r1
    //     0xcf79f8: add             x1, x1, HEAP, lsl #32
    // 0xcf79fc: LoadField: r2 = r1->field_7
    //     0xcf79fc: ldur            x2, [x1, #7]
    // 0xcf7a00: cmp             x2, #1
    // 0xcf7a04: b.gt            #0xcf7a14
    // 0xcf7a08: cmp             x2, #0
    // 0xcf7a0c: b.gt            #0xcf7a28
    // 0xcf7a10: b               #0xcf7a1c
    // 0xcf7a14: cmp             x2, #2
    // 0xcf7a18: b.gt            #0xcf7a28
    // 0xcf7a1c: r1 = Instance_Axis
    //     0xcf7a1c: add             x1, PP, #0xe, lsl #12  ; [pp+0xef00] Obj!Axis@b64ff1
    //     0xcf7a20: ldr             x1, [x1, #0xf00]
    // 0xcf7a24: b               #0xcf7a30
    // 0xcf7a28: r1 = Instance_Axis
    //     0xcf7a28: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0xcf7a2c: ldr             x1, [x1, #0x440]
    // 0xcf7a30: LoadField: r2 = r1->field_7
    //     0xcf7a30: ldur            x2, [x1, #7]
    // 0xcf7a34: cmp             x2, #0
    // 0xcf7a38: b.gt            #0xcf7a4c
    // 0xcf7a3c: ldr             x0, [fp, #0x18]
    // 0xcf7a40: LeaveFrame
    //     0xcf7a40: mov             SP, fp
    //     0xcf7a44: ldp             fp, lr, [SP], #0x10
    // 0xcf7a48: ret
    //     0xcf7a48: ret             
    // 0xcf7a4c: ldr             x16, [fp, #0x20]
    // 0xcf7a50: SaveReg r16
    //     0xcf7a50: str             x16, [SP, #-8]!
    // 0xcf7a54: r0 = of()
    //     0xcf7a54: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcf7a58: add             SP, SP, #8
    // 0xcf7a5c: LoadField: r1 = r0->field_1f
    //     0xcf7a5c: ldur            w1, [x0, #0x1f]
    // 0xcf7a60: DecompressPointer r1
    //     0xcf7a60: add             x1, x1, HEAP, lsl #32
    // 0xcf7a64: LoadField: r0 = r1->field_7
    //     0xcf7a64: ldur            x0, [x1, #7]
    // 0xcf7a68: cmp             x0, #2
    // 0xcf7a6c: b.gt            #0xcf7a80
    // 0xcf7a70: ldr             x0, [fp, #0x18]
    // 0xcf7a74: LeaveFrame
    //     0xcf7a74: mov             SP, fp
    //     0xcf7a78: ldp             fp, lr, [SP], #0x10
    // 0xcf7a7c: ret
    //     0xcf7a7c: ret             
    // 0xcf7a80: ldr             x1, [fp, #0x18]
    // 0xcf7a84: ldr             x0, [fp, #0x10]
    // 0xcf7a88: LoadField: r2 = r0->field_b
    //     0xcf7a88: ldur            w2, [x0, #0xb]
    // 0xcf7a8c: DecompressPointer r2
    //     0xcf7a8c: add             x2, x2, HEAP, lsl #32
    // 0xcf7a90: stur            x2, [fp, #-8]
    // 0xcf7a94: r0 = Scrollbar()
    //     0xcf7a94: bl              #0x8a5b14  ; AllocateScrollbarStub -> Scrollbar (size=0x3c)
    // 0xcf7a98: ldr             x1, [fp, #0x18]
    // 0xcf7a9c: StoreField: r0->field_b = r1
    //     0xcf7a9c: stur            w1, [x0, #0xb]
    // 0xcf7aa0: ldur            x1, [fp, #-8]
    // 0xcf7aa4: StoreField: r0->field_f = r1
    //     0xcf7aa4: stur            w1, [x0, #0xf]
    // 0xcf7aa8: LeaveFrame
    //     0xcf7aa8: mov             SP, fp
    //     0xcf7aac: ldp             fp, lr, [SP], #0x10
    // 0xcf7ab0: ret
    //     0xcf7ab0: ret             
    // 0xcf7ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7ab4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7ab8: b               #0xcf79f0
  }
  _ getPlatform(/* No info */) {
    // ** addr: 0xcf9c2c, size: 0x44
    // 0xcf9c2c: EnterFrame
    //     0xcf9c2c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9c30: mov             fp, SP
    // 0xcf9c34: CheckStackOverflow
    //     0xcf9c34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf9c38: cmp             SP, x16
    //     0xcf9c3c: b.ls            #0xcf9c68
    // 0xcf9c40: ldr             x16, [fp, #0x10]
    // 0xcf9c44: SaveReg r16
    //     0xcf9c44: str             x16, [SP, #-8]!
    // 0xcf9c48: r0 = of()
    //     0xcf9c48: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcf9c4c: add             SP, SP, #8
    // 0xcf9c50: LoadField: r1 = r0->field_1f
    //     0xcf9c50: ldur            w1, [x0, #0x1f]
    // 0xcf9c54: DecompressPointer r1
    //     0xcf9c54: add             x1, x1, HEAP, lsl #32
    // 0xcf9c58: mov             x0, x1
    // 0xcf9c5c: LeaveFrame
    //     0xcf9c5c: mov             SP, fp
    //     0xcf9c60: ldp             fp, lr, [SP], #0x10
    // 0xcf9c64: ret
    //     0xcf9c64: ret             
    // 0xcf9c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9c68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9c6c: b               #0xcf9c40
  }
}

// class id: 3343, size: 0x18, field offset: 0x14
class _MaterialAppState extends State<MaterialApp> {

  late HeroController _heroController; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0x8453f8, size: 0xf8
    // 0x8453f8: EnterFrame
    //     0x8453f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8453fc: mov             fp, SP
    // 0x845400: AllocStack(0x18)
    //     0x845400: sub             SP, SP, #0x18
    // 0x845404: CheckStackOverflow
    //     0x845404: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x845408: cmp             SP, x16
    //     0x84540c: b.ls            #0x8454d8
    // 0x845410: ldr             x16, [fp, #0x18]
    // 0x845414: SaveReg r16
    //     0x845414: str             x16, [SP, #-8]!
    // 0x845418: r0 = _buildWidgetApp()
    //     0x845418: bl              #0x84552c  ; [package:flutter/src/material/app.dart] _MaterialAppState::_buildWidgetApp
    // 0x84541c: add             SP, SP, #8
    // 0x845420: stur            x0, [fp, #-8]
    // 0x845424: r0 = Focus()
    //     0x845424: bl              #0x834690  ; AllocateFocusStub -> Focus (size=0x40)
    // 0x845428: mov             x3, x0
    // 0x84542c: ldur            x0, [fp, #-8]
    // 0x845430: stur            x3, [fp, #-0x10]
    // 0x845434: StoreField: r3->field_f = r0
    //     0x845434: stur            w0, [x3, #0xf]
    // 0x845438: r0 = false
    //     0x845438: add             x0, NULL, #0x30  ; false
    // 0x84543c: StoreField: r3->field_17 = r0
    //     0x84543c: stur            w0, [x3, #0x17]
    // 0x845440: r1 = true
    //     0x845440: add             x1, NULL, #0x20  ; true
    // 0x845444: StoreField: r3->field_37 = r1
    //     0x845444: stur            w1, [x3, #0x37]
    // 0x845448: r1 = Function '<anonymous closure>':.
    //     0x845448: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d0d8] AnonymousClosure: (0x846168), in [package:flutter/src/material/app.dart] _MaterialAppState::build (0x8453f8)
    //     0x84544c: ldr             x1, [x1, #0xd8]
    // 0x845450: r2 = Null
    //     0x845450: mov             x2, NULL
    // 0x845454: r0 = AllocateClosure()
    //     0x845454: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x845458: mov             x1, x0
    // 0x84545c: ldur            x0, [fp, #-0x10]
    // 0x845460: StoreField: r0->field_23 = r1
    //     0x845460: stur            w1, [x0, #0x23]
    // 0x845464: r1 = false
    //     0x845464: add             x1, NULL, #0x30  ; false
    // 0x845468: StoreField: r0->field_27 = r1
    //     0x845468: stur            w1, [x0, #0x27]
    // 0x84546c: ldr             x1, [fp, #0x18]
    // 0x845470: LoadField: r2 = r1->field_b
    //     0x845470: ldur            w2, [x1, #0xb]
    // 0x845474: DecompressPointer r2
    //     0x845474: add             x2, x2, HEAP, lsl #32
    // 0x845478: cmp             w2, NULL
    // 0x84547c: b.eq            #0x8454e0
    // 0x845480: LoadField: r2 = r1->field_13
    //     0x845480: ldur            w2, [x1, #0x13]
    // 0x845484: DecompressPointer r2
    //     0x845484: add             x2, x2, HEAP, lsl #32
    // 0x845488: r16 = Sentinel
    //     0x845488: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84548c: cmp             w2, w16
    // 0x845490: b.eq            #0x8454e4
    // 0x845494: stur            x2, [fp, #-8]
    // 0x845498: r0 = HeroControllerScope()
    //     0x845498: bl              #0x845520  ; AllocateHeroControllerScopeStub -> HeroControllerScope (size=0x14)
    // 0x84549c: mov             x1, x0
    // 0x8454a0: ldur            x0, [fp, #-8]
    // 0x8454a4: stur            x1, [fp, #-0x18]
    // 0x8454a8: StoreField: r1->field_f = r0
    //     0x8454a8: stur            w0, [x1, #0xf]
    // 0x8454ac: ldur            x0, [fp, #-0x10]
    // 0x8454b0: StoreField: r1->field_b = r0
    //     0x8454b0: stur            w0, [x1, #0xb]
    // 0x8454b4: r0 = ScrollConfiguration()
    //     0x8454b4: bl              #0x845514  ; AllocateScrollConfigurationStub -> ScrollConfiguration (size=0x14)
    // 0x8454b8: r1 = Instance_MaterialScrollBehavior
    //     0x8454b8: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d0e0] Obj!MaterialScrollBehavior@b386d1
    //     0x8454bc: ldr             x1, [x1, #0xe0]
    // 0x8454c0: StoreField: r0->field_f = r1
    //     0x8454c0: stur            w1, [x0, #0xf]
    // 0x8454c4: ldur            x1, [fp, #-0x18]
    // 0x8454c8: StoreField: r0->field_b = r1
    //     0x8454c8: stur            w1, [x0, #0xb]
    // 0x8454cc: LeaveFrame
    //     0x8454cc: mov             SP, fp
    //     0x8454d0: ldp             fp, lr, [SP], #0x10
    // 0x8454d4: ret
    //     0x8454d4: ret             
    // 0x8454d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8454d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8454dc: b               #0x845410
    // 0x8454e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8454e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8454e4: r9 = _heroController
    //     0x8454e4: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d0e8] Field <_MaterialAppState@679125171._heroController@679125171>: late (offset: 0x14)
    //     0x8454e8: ldr             x9, [x9, #0xe8]
    // 0x8454ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8454ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildWidgetApp(/* No info */) {
    // ** addr: 0x84552c, size: 0x2ac
    // 0x84552c: EnterFrame
    //     0x84552c: stp             fp, lr, [SP, #-0x10]!
    //     0x845530: mov             fp, SP
    // 0x845534: AllocStack(0x60)
    //     0x845534: sub             SP, SP, #0x60
    // 0x845538: CheckStackOverflow
    //     0x845538: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84553c: cmp             SP, x16
    //     0x845540: b.ls            #0x8457bc
    // 0x845544: ldr             x0, [fp, #0x10]
    // 0x845548: LoadField: r1 = r0->field_b
    //     0x845548: ldur            w1, [x0, #0xb]
    // 0x84554c: DecompressPointer r1
    //     0x84554c: add             x1, x1, HEAP, lsl #32
    // 0x845550: cmp             w1, NULL
    // 0x845554: b.eq            #0x8457c4
    // 0x845558: LoadField: r2 = r1->field_4f
    //     0x845558: ldur            w2, [x1, #0x4f]
    // 0x84555c: DecompressPointer r2
    //     0x84555c: add             x2, x2, HEAP, lsl #32
    // 0x845560: LoadField: r1 = r2->field_63
    //     0x845560: ldur            w1, [x2, #0x63]
    // 0x845564: DecompressPointer r1
    //     0x845564: add             x1, x1, HEAP, lsl #32
    // 0x845568: stur            x1, [fp, #-8]
    // 0x84556c: SaveReg r0
    //     0x84556c: str             x0, [SP, #-8]!
    // 0x845570: r0 = _needsAutofill()
    //     0x845570: bl              #0x7a331c  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::_needsAutofill
    // 0x845574: add             SP, SP, #8
    // 0x845578: tbnz            w0, #4, #0x845664
    // 0x84557c: ldr             x0, [fp, #0x10]
    // 0x845580: r1 = <State<StatefulWidget>>
    //     0x845580: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0x845584: r0 = GlobalObjectKey()
    //     0x845584: bl              #0x7c1018  ; AllocateGlobalObjectKeyStub -> GlobalObjectKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0x845588: mov             x1, x0
    // 0x84558c: ldr             x0, [fp, #0x10]
    // 0x845590: stur            x1, [fp, #-0x18]
    // 0x845594: StoreField: r1->field_b = r0
    //     0x845594: stur            w0, [x1, #0xb]
    // 0x845598: LoadField: r2 = r0->field_b
    //     0x845598: ldur            w2, [x0, #0xb]
    // 0x84559c: DecompressPointer r2
    //     0x84559c: add             x2, x2, HEAP, lsl #32
    // 0x8455a0: stur            x2, [fp, #-0x10]
    // 0x8455a4: cmp             w2, NULL
    // 0x8455a8: b.eq            #0x8457c8
    // 0x8455ac: r1 = 1
    //     0x8455ac: mov             x1, #1
    // 0x8455b0: r0 = AllocateContext()
    //     0x8455b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8455b4: mov             x1, x0
    // 0x8455b8: ldr             x0, [fp, #0x10]
    // 0x8455bc: stur            x1, [fp, #-0x30]
    // 0x8455c0: StoreField: r1->field_f = r0
    //     0x8455c0: stur            w0, [x1, #0xf]
    // 0x8455c4: ldur            x2, [fp, #-0x10]
    // 0x8455c8: LoadField: r3 = r2->field_47
    //     0x8455c8: ldur            w3, [x2, #0x47]
    // 0x8455cc: DecompressPointer r3
    //     0x8455cc: add             x3, x3, HEAP, lsl #32
    // 0x8455d0: stur            x3, [fp, #-0x28]
    // 0x8455d4: LoadField: r4 = r2->field_6f
    //     0x8455d4: ldur            w4, [x2, #0x6f]
    // 0x8455d8: DecompressPointer r4
    //     0x8455d8: add             x4, x4, HEAP, lsl #32
    // 0x8455dc: stur            x4, [fp, #-0x20]
    // 0x8455e0: SaveReg r0
    //     0x8455e0: str             x0, [SP, #-8]!
    // 0x8455e4: r0 = _localizationsDelegates()
    //     0x8455e4: bl              #0x845ab4  ; [package:flutter/src/material/app.dart] _MaterialAppState::_localizationsDelegates
    // 0x8455e8: add             SP, SP, #8
    // 0x8455ec: mov             x3, x0
    // 0x8455f0: ldr             x0, [fp, #0x10]
    // 0x8455f4: stur            x3, [fp, #-0x10]
    // 0x8455f8: LoadField: r1 = r0->field_b
    //     0x8455f8: ldur            w1, [x0, #0xb]
    // 0x8455fc: DecompressPointer r1
    //     0x8455fc: add             x1, x1, HEAP, lsl #32
    // 0x845600: cmp             w1, NULL
    // 0x845604: b.eq            #0x8457cc
    // 0x845608: ldur            x2, [fp, #-0x30]
    // 0x84560c: r1 = Function '_materialBuilder@679125171':.
    //     0x84560c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d138] AnonymousClosure: (0x845ca8), in [package:flutter/src/material/app.dart] _MaterialAppState::_materialBuilder (0x845cfc)
    //     0x845610: ldr             x1, [x1, #0x138]
    // 0x845614: r0 = AllocateClosure()
    //     0x845614: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x845618: stur            x0, [fp, #-0x30]
    // 0x84561c: r0 = WidgetsApp()
    //     0x84561c: bl              #0x845aa8  ; AllocateWidgetsAppStub -> WidgetsApp (size=0x8c)
    // 0x845620: stur            x0, [fp, #-0x38]
    // 0x845624: ldur            x16, [fp, #-0x30]
    // 0x845628: stp             x16, x0, [SP, #-0x10]!
    // 0x84562c: ldur            x16, [fp, #-8]
    // 0x845630: ldur            lr, [fp, #-0x18]
    // 0x845634: stp             lr, x16, [SP, #-0x10]!
    // 0x845638: ldur            x16, [fp, #-0x20]
    // 0x84563c: ldur            lr, [fp, #-0x10]
    // 0x845640: stp             lr, x16, [SP, #-0x10]!
    // 0x845644: ldur            x16, [fp, #-0x28]
    // 0x845648: SaveReg r16
    //     0x845648: str             x16, [SP, #-8]!
    // 0x84564c: r0 = WidgetsApp.router()
    //     0x84564c: bl              #0x84599c  ; [package:flutter/src/widgets/app.dart] WidgetsApp::WidgetsApp.router
    // 0x845650: add             SP, SP, #0x38
    // 0x845654: ldur            x0, [fp, #-0x38]
    // 0x845658: LeaveFrame
    //     0x845658: mov             SP, fp
    //     0x84565c: ldp             fp, lr, [SP], #0x10
    // 0x845660: ret
    //     0x845660: ret             
    // 0x845664: ldr             x0, [fp, #0x10]
    // 0x845668: r1 = <State<StatefulWidget>>
    //     0x845668: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0x84566c: r0 = GlobalObjectKey()
    //     0x84566c: bl              #0x7c1018  ; AllocateGlobalObjectKeyStub -> GlobalObjectKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0x845670: mov             x3, x0
    // 0x845674: ldr             x0, [fp, #0x10]
    // 0x845678: stur            x3, [fp, #-0x28]
    // 0x84567c: StoreField: r3->field_b = r0
    //     0x84567c: stur            w0, [x3, #0xb]
    // 0x845680: LoadField: r4 = r0->field_b
    //     0x845680: ldur            w4, [x0, #0xb]
    // 0x845684: DecompressPointer r4
    //     0x845684: add             x4, x4, HEAP, lsl #32
    // 0x845688: stur            x4, [fp, #-0x20]
    // 0x84568c: cmp             w4, NULL
    // 0x845690: b.eq            #0x8457d0
    // 0x845694: LoadField: r5 = r4->field_b
    //     0x845694: ldur            w5, [x4, #0xb]
    // 0x845698: DecompressPointer r5
    //     0x845698: add             x5, x5, HEAP, lsl #32
    // 0x84569c: stur            x5, [fp, #-0x18]
    // 0x8456a0: LoadField: r6 = r4->field_2b
    //     0x8456a0: ldur            w6, [x4, #0x2b]
    // 0x8456a4: DecompressPointer r6
    //     0x8456a4: add             x6, x6, HEAP, lsl #32
    // 0x8456a8: stur            x6, [fp, #-0x10]
    // 0x8456ac: r1 = Function '<anonymous closure>':.
    //     0x8456ac: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d140] AnonymousClosure: (0x845be8), in [package:flutter/src/material/app.dart] _MaterialAppState::_buildWidgetApp (0x84552c)
    //     0x8456b0: ldr             x1, [x1, #0x140]
    // 0x8456b4: r2 = Null
    //     0x8456b4: mov             x2, NULL
    // 0x8456b8: r0 = AllocateClosure()
    //     0x8456b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8456bc: mov             x1, x0
    // 0x8456c0: r0 = 
    //     0x8456c0: ldr             x0, [PP, #0x50]  ; [pp+0x50] TypeArguments: 
    // 0x8456c4: stur            x1, [fp, #-0x40]
    // 0x8456c8: StoreField: r1->field_f = r0
    //     0x8456c8: stur            w0, [x1, #0xf]
    // 0x8456cc: ldur            x0, [fp, #-0x20]
    // 0x8456d0: LoadField: r2 = r0->field_1f
    //     0x8456d0: ldur            w2, [x0, #0x1f]
    // 0x8456d4: DecompressPointer r2
    //     0x8456d4: add             x2, x2, HEAP, lsl #32
    // 0x8456d8: stur            x2, [fp, #-0x38]
    // 0x8456dc: LoadField: r3 = r0->field_23
    //     0x8456dc: ldur            w3, [x0, #0x23]
    // 0x8456e0: DecompressPointer r3
    //     0x8456e0: add             x3, x3, HEAP, lsl #32
    // 0x8456e4: stur            x3, [fp, #-0x30]
    // 0x8456e8: r1 = 1
    //     0x8456e8: mov             x1, #1
    // 0x8456ec: r0 = AllocateContext()
    //     0x8456ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8456f0: mov             x1, x0
    // 0x8456f4: ldr             x0, [fp, #0x10]
    // 0x8456f8: stur            x1, [fp, #-0x58]
    // 0x8456fc: StoreField: r1->field_f = r0
    //     0x8456fc: stur            w0, [x1, #0xf]
    // 0x845700: ldur            x2, [fp, #-0x20]
    // 0x845704: LoadField: r3 = r2->field_47
    //     0x845704: ldur            w3, [x2, #0x47]
    // 0x845708: DecompressPointer r3
    //     0x845708: add             x3, x3, HEAP, lsl #32
    // 0x84570c: stur            x3, [fp, #-0x50]
    // 0x845710: LoadField: r4 = r2->field_6f
    //     0x845710: ldur            w4, [x2, #0x6f]
    // 0x845714: DecompressPointer r4
    //     0x845714: add             x4, x4, HEAP, lsl #32
    // 0x845718: stur            x4, [fp, #-0x48]
    // 0x84571c: SaveReg r0
    //     0x84571c: str             x0, [SP, #-8]!
    // 0x845720: r0 = _localizationsDelegates()
    //     0x845720: bl              #0x845ab4  ; [package:flutter/src/material/app.dart] _MaterialAppState::_localizationsDelegates
    // 0x845724: add             SP, SP, #8
    // 0x845728: mov             x3, x0
    // 0x84572c: ldr             x0, [fp, #0x10]
    // 0x845730: stur            x3, [fp, #-0x20]
    // 0x845734: LoadField: r1 = r0->field_b
    //     0x845734: ldur            w1, [x0, #0xb]
    // 0x845738: DecompressPointer r1
    //     0x845738: add             x1, x1, HEAP, lsl #32
    // 0x84573c: cmp             w1, NULL
    // 0x845740: b.eq            #0x8457d4
    // 0x845744: ldur            x2, [fp, #-0x58]
    // 0x845748: r1 = Function '_materialBuilder@679125171':.
    //     0x845748: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d138] AnonymousClosure: (0x845ca8), in [package:flutter/src/material/app.dart] _MaterialAppState::_materialBuilder (0x845cfc)
    //     0x84574c: ldr             x1, [x1, #0x138]
    // 0x845750: r0 = AllocateClosure()
    //     0x845750: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x845754: stur            x0, [fp, #-0x58]
    // 0x845758: r0 = WidgetsApp()
    //     0x845758: bl              #0x845aa8  ; AllocateWidgetsAppStub -> WidgetsApp (size=0x8c)
    // 0x84575c: stur            x0, [fp, #-0x60]
    // 0x845760: ldur            x16, [fp, #-0x58]
    // 0x845764: stp             x16, x0, [SP, #-0x10]!
    // 0x845768: ldur            x16, [fp, #-8]
    // 0x84576c: ldur            lr, [fp, #-0x28]
    // 0x845770: stp             lr, x16, [SP, #-0x10]!
    // 0x845774: ldur            x16, [fp, #-0x48]
    // 0x845778: ldur            lr, [fp, #-0x20]
    // 0x84577c: stp             lr, x16, [SP, #-0x10]!
    // 0x845780: ldur            x16, [fp, #-0x18]
    // 0x845784: ldur            lr, [fp, #-0x10]
    // 0x845788: stp             lr, x16, [SP, #-0x10]!
    // 0x84578c: ldur            x16, [fp, #-0x30]
    // 0x845790: ldur            lr, [fp, #-0x38]
    // 0x845794: stp             lr, x16, [SP, #-0x10]!
    // 0x845798: ldur            x16, [fp, #-0x40]
    // 0x84579c: ldur            lr, [fp, #-0x50]
    // 0x8457a0: stp             lr, x16, [SP, #-0x10]!
    // 0x8457a4: r0 = WidgetsApp()
    //     0x8457a4: bl              #0x8457d8  ; [package:flutter/src/widgets/app.dart] WidgetsApp::WidgetsApp
    // 0x8457a8: add             SP, SP, #0x60
    // 0x8457ac: ldur            x0, [fp, #-0x60]
    // 0x8457b0: LeaveFrame
    //     0x8457b0: mov             SP, fp
    //     0x8457b4: ldp             fp, lr, [SP], #0x10
    // 0x8457b8: ret
    //     0x8457b8: ret             
    // 0x8457bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8457bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8457c0: b               #0x845544
    // 0x8457c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8457c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8457c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8457c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8457cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8457cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8457d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8457d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8457d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8457d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _localizationsDelegates(/* No info */) {
    // ** addr: 0x845ab4, size: 0x134
    // 0x845ab4: EnterFrame
    //     0x845ab4: stp             fp, lr, [SP, #-0x10]!
    //     0x845ab8: mov             fp, SP
    // 0x845abc: AllocStack(0x18)
    //     0x845abc: sub             SP, SP, #0x18
    // 0x845ac0: CheckStackOverflow
    //     0x845ac0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x845ac4: cmp             SP, x16
    //     0x845ac8: b.ls            #0x845bd4
    // 0x845acc: r16 = <LocalizationsDelegate>
    //     0x845acc: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d160] TypeArguments: <LocalizationsDelegate>
    //     0x845ad0: ldr             x16, [x16, #0x160]
    // 0x845ad4: stp             xzr, x16, [SP, #-0x10]!
    // 0x845ad8: r0 = _GrowableList()
    //     0x845ad8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x845adc: add             SP, SP, #0x10
    // 0x845ae0: mov             x1, x0
    // 0x845ae4: ldr             x0, [fp, #0x10]
    // 0x845ae8: stur            x1, [fp, #-0x10]
    // 0x845aec: LoadField: r2 = r0->field_b
    //     0x845aec: ldur            w2, [x0, #0xb]
    // 0x845af0: DecompressPointer r2
    //     0x845af0: add             x2, x2, HEAP, lsl #32
    // 0x845af4: cmp             w2, NULL
    // 0x845af8: b.eq            #0x845bdc
    // 0x845afc: LoadField: r0 = r1->field_b
    //     0x845afc: ldur            w0, [x1, #0xb]
    // 0x845b00: DecompressPointer r0
    //     0x845b00: add             x0, x0, HEAP, lsl #32
    // 0x845b04: stur            x0, [fp, #-8]
    // 0x845b08: LoadField: r2 = r1->field_f
    //     0x845b08: ldur            w2, [x1, #0xf]
    // 0x845b0c: DecompressPointer r2
    //     0x845b0c: add             x2, x2, HEAP, lsl #32
    // 0x845b10: LoadField: r3 = r2->field_b
    //     0x845b10: ldur            w3, [x2, #0xb]
    // 0x845b14: DecompressPointer r3
    //     0x845b14: add             x3, x3, HEAP, lsl #32
    // 0x845b18: cmp             w0, w3
    // 0x845b1c: b.ne            #0x845b2c
    // 0x845b20: SaveReg r1
    //     0x845b20: str             x1, [SP, #-8]!
    // 0x845b24: r0 = _growToNextCapacity()
    //     0x845b24: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x845b28: add             SP, SP, #8
    // 0x845b2c: ldur            x2, [fp, #-0x10]
    // 0x845b30: ldur            x0, [fp, #-8]
    // 0x845b34: r3 = LoadInt32Instr(r0)
    //     0x845b34: sbfx            x3, x0, #1, #0x1f
    // 0x845b38: add             x4, x3, #1
    // 0x845b3c: stur            x4, [fp, #-0x18]
    // 0x845b40: lsl             x5, x4, #1
    // 0x845b44: StoreField: r2->field_b = r5
    //     0x845b44: stur            w5, [x2, #0xb]
    // 0x845b48: mov             x0, x4
    // 0x845b4c: mov             x1, x3
    // 0x845b50: cmp             x1, x0
    // 0x845b54: b.hs            #0x845be0
    // 0x845b58: LoadField: r0 = r2->field_f
    //     0x845b58: ldur            w0, [x2, #0xf]
    // 0x845b5c: DecompressPointer r0
    //     0x845b5c: add             x0, x0, HEAP, lsl #32
    // 0x845b60: add             x1, x0, x3, lsl #2
    // 0x845b64: r17 = Instance__MaterialLocalizationsDelegate
    //     0x845b64: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d168] Obj!_MaterialLocalizationsDelegate<MaterialLocalizations>@b4f271
    //     0x845b68: ldr             x17, [x17, #0x168]
    // 0x845b6c: StoreField: r1->field_f = r17
    //     0x845b6c: stur            w17, [x1, #0xf]
    // 0x845b70: LoadField: r1 = r0->field_b
    //     0x845b70: ldur            w1, [x0, #0xb]
    // 0x845b74: DecompressPointer r1
    //     0x845b74: add             x1, x1, HEAP, lsl #32
    // 0x845b78: cmp             w5, w1
    // 0x845b7c: b.ne            #0x845b8c
    // 0x845b80: SaveReg r2
    //     0x845b80: str             x2, [SP, #-8]!
    // 0x845b84: r0 = _growToNextCapacity()
    //     0x845b84: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x845b88: add             SP, SP, #8
    // 0x845b8c: ldur            x2, [fp, #-0x10]
    // 0x845b90: ldur            x3, [fp, #-0x18]
    // 0x845b94: add             x0, x3, #1
    // 0x845b98: lsl             x4, x0, #1
    // 0x845b9c: StoreField: r2->field_b = r4
    //     0x845b9c: stur            w4, [x2, #0xb]
    // 0x845ba0: mov             x1, x3
    // 0x845ba4: cmp             x1, x0
    // 0x845ba8: b.hs            #0x845be4
    // 0x845bac: LoadField: r1 = r2->field_f
    //     0x845bac: ldur            w1, [x2, #0xf]
    // 0x845bb0: DecompressPointer r1
    //     0x845bb0: add             x1, x1, HEAP, lsl #32
    // 0x845bb4: add             x4, x1, x3, lsl #2
    // 0x845bb8: r17 = Instance__CupertinoLocalizationsDelegate
    //     0x845bb8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d170] Obj!_CupertinoLocalizationsDelegate<CupertinoLocalizations>@b4f281
    //     0x845bbc: ldr             x17, [x17, #0x170]
    // 0x845bc0: StoreField: r4->field_f = r17
    //     0x845bc0: stur            w17, [x4, #0xf]
    // 0x845bc4: mov             x0, x2
    // 0x845bc8: LeaveFrame
    //     0x845bc8: mov             SP, fp
    //     0x845bcc: ldp             fp, lr, [SP], #0x10
    // 0x845bd0: ret
    //     0x845bd0: ret             
    // 0x845bd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845bd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845bd8: b               #0x845acc
    // 0x845bdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845bdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x845be0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x845be0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x845be4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x845be4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] MaterialPageRoute<Y0> <anonymous closure><Y0>(dynamic, RouteSettings, (dynamic, BuildContext) => Widget) {
    // ** addr: 0x845be8, size: 0xb4
    // 0x845be8: EnterFrame
    //     0x845be8: stp             fp, lr, [SP, #-0x10]!
    //     0x845bec: mov             fp, SP
    // 0x845bf0: AllocStack(0x8)
    //     0x845bf0: sub             SP, SP, #8
    // 0x845bf4: SetupParameters()
    //     0x845bf4: mov             x0, x4
    //     0x845bf8: ldur            w1, [x0, #0xf]
    //     0x845bfc: add             x1, x1, HEAP, lsl #32
    //     0x845c00: cbnz            w1, #0x845c0c
    //     0x845c04: mov             x1, NULL
    //     0x845c08: b               #0x845c20
    //     0x845c0c: ldur            w1, [x0, #0x17]
    //     0x845c10: add             x1, x1, HEAP, lsl #32
    //     0x845c14: add             x0, fp, w1, sxtw #2
    //     0x845c18: ldr             x0, [x0, #0x10]
    //     0x845c1c: mov             x1, x0
    //     0x845c20: ldr             x0, [fp, #0x20]
    //     0x845c24: ldur            w2, [x0, #0xf]
    //     0x845c28: add             x2, x2, HEAP, lsl #32
    //     0x845c2c: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: 
    //     0x845c30: cmp             w2, w16
    //     0x845c34: b.eq            #0x845c3c
    //     0x845c38: mov             x1, x2
    //     0x845c3c: ldr             x0, [fp, #0x10]
    // 0x845c40: CheckStackOverflow
    //     0x845c40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x845c44: cmp             SP, x16
    //     0x845c48: b.ls            #0x845c94
    // 0x845c4c: r0 = MaterialPageRoute()
    //     0x845c4c: bl              #0x845c9c  ; AllocateMaterialPageRouteStub -> MaterialPageRoute<X0> (size=0x8c)
    // 0x845c50: mov             x1, x0
    // 0x845c54: ldr             x0, [fp, #0x10]
    // 0x845c58: stur            x1, [fp, #-8]
    // 0x845c5c: StoreField: r1->field_83 = r0
    //     0x845c5c: stur            w0, [x1, #0x83]
    // 0x845c60: r0 = true
    //     0x845c60: add             x0, NULL, #0x20  ; true
    // 0x845c64: StoreField: r1->field_87 = r0
    //     0x845c64: stur            w0, [x1, #0x87]
    // 0x845c68: r2 = false
    //     0x845c68: add             x2, NULL, #0x30  ; false
    // 0x845c6c: StoreField: r1->field_7b = r2
    //     0x845c6c: stur            w2, [x1, #0x7b]
    // 0x845c70: StoreField: r1->field_7f = r0
    //     0x845c70: stur            w0, [x1, #0x7f]
    // 0x845c74: ldr             x16, [fp, #0x18]
    // 0x845c78: stp             x16, x1, [SP, #-0x10]!
    // 0x845c7c: r0 = ModalRoute()
    //     0x845c7c: bl              #0x5a097c  ; [package:flutter/src/widgets/routes.dart] ModalRoute::ModalRoute
    // 0x845c80: add             SP, SP, #0x10
    // 0x845c84: ldur            x0, [fp, #-8]
    // 0x845c88: LeaveFrame
    //     0x845c88: mov             SP, fp
    //     0x845c8c: ldp             fp, lr, [SP], #0x10
    // 0x845c90: ret
    //     0x845c90: ret             
    // 0x845c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845c94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845c98: b               #0x845c4c
  }
  [closure] Widget _materialBuilder(dynamic, BuildContext, Widget?) {
    // ** addr: 0x845ca8, size: 0x54
    // 0x845ca8: EnterFrame
    //     0x845ca8: stp             fp, lr, [SP, #-0x10]!
    //     0x845cac: mov             fp, SP
    // 0x845cb0: ldr             x0, [fp, #0x20]
    // 0x845cb4: LoadField: r1 = r0->field_17
    //     0x845cb4: ldur            w1, [x0, #0x17]
    // 0x845cb8: DecompressPointer r1
    //     0x845cb8: add             x1, x1, HEAP, lsl #32
    // 0x845cbc: CheckStackOverflow
    //     0x845cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x845cc0: cmp             SP, x16
    //     0x845cc4: b.ls            #0x845cf4
    // 0x845cc8: LoadField: r0 = r1->field_f
    //     0x845cc8: ldur            w0, [x1, #0xf]
    // 0x845ccc: DecompressPointer r0
    //     0x845ccc: add             x0, x0, HEAP, lsl #32
    // 0x845cd0: ldr             x16, [fp, #0x18]
    // 0x845cd4: stp             x16, x0, [SP, #-0x10]!
    // 0x845cd8: ldr             x16, [fp, #0x10]
    // 0x845cdc: SaveReg r16
    //     0x845cdc: str             x16, [SP, #-8]!
    // 0x845ce0: r0 = _materialBuilder()
    //     0x845ce0: bl              #0x845cfc  ; [package:flutter/src/material/app.dart] _MaterialAppState::_materialBuilder
    // 0x845ce4: add             SP, SP, #0x18
    // 0x845ce8: LeaveFrame
    //     0x845ce8: mov             SP, fp
    //     0x845cec: ldp             fp, lr, [SP], #0x10
    // 0x845cf0: ret
    //     0x845cf0: ret             
    // 0x845cf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845cf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845cf8: b               #0x845cc8
  }
  _ _materialBuilder(/* No info */) {
    // ** addr: 0x845cfc, size: 0x2d4
    // 0x845cfc: EnterFrame
    //     0x845cfc: stp             fp, lr, [SP, #-0x10]!
    //     0x845d00: mov             fp, SP
    // 0x845d04: AllocStack(0x30)
    //     0x845d04: sub             SP, SP, #0x30
    // 0x845d08: CheckStackOverflow
    //     0x845d08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x845d0c: cmp             SP, x16
    //     0x845d10: b.ls            #0x845fb0
    // 0x845d14: r1 = 2
    //     0x845d14: mov             x1, #2
    // 0x845d18: r0 = AllocateContext()
    //     0x845d18: bl              #0xd68aa4  ; AllocateContextStub
    // 0x845d1c: mov             x1, x0
    // 0x845d20: ldr             x0, [fp, #0x20]
    // 0x845d24: stur            x1, [fp, #-8]
    // 0x845d28: StoreField: r1->field_f = r0
    //     0x845d28: stur            w0, [x1, #0xf]
    // 0x845d2c: ldr             x2, [fp, #0x10]
    // 0x845d30: StoreField: r1->field_13 = r2
    //     0x845d30: stur            w2, [x1, #0x13]
    // 0x845d34: LoadField: r2 = r0->field_b
    //     0x845d34: ldur            w2, [x0, #0xb]
    // 0x845d38: DecompressPointer r2
    //     0x845d38: add             x2, x2, HEAP, lsl #32
    // 0x845d3c: cmp             w2, NULL
    // 0x845d40: b.eq            #0x845fb8
    // 0x845d44: ldr             x16, [fp, #0x18]
    // 0x845d48: SaveReg r16
    //     0x845d48: str             x16, [SP, #-8]!
    // 0x845d4c: r0 = platformBrightnessOf()
    //     0x845d4c: bl              #0x84607c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::platformBrightnessOf
    // 0x845d50: add             SP, SP, #8
    // 0x845d54: r16 = Instance_Brightness
    //     0x845d54: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x845d58: cmp             w0, w16
    // 0x845d5c: r16 = true
    //     0x845d5c: add             x16, NULL, #0x20  ; true
    // 0x845d60: r17 = false
    //     0x845d60: add             x17, NULL, #0x30  ; false
    // 0x845d64: csel            x1, x16, x17, eq
    // 0x845d68: stur            x1, [fp, #-0x10]
    // 0x845d6c: ldr             x16, [fp, #0x18]
    // 0x845d70: SaveReg r16
    //     0x845d70: str             x16, [SP, #-8]!
    // 0x845d74: r0 = highContrastOf()
    //     0x845d74: bl              #0x846018  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::highContrastOf
    // 0x845d78: add             SP, SP, #8
    // 0x845d7c: mov             x1, x0
    // 0x845d80: ldur            x0, [fp, #-0x10]
    // 0x845d84: tbnz            w0, #4, #0x845dac
    // 0x845d88: tbnz            w1, #4, #0x845da4
    // 0x845d8c: ldr             x2, [fp, #0x20]
    // 0x845d90: LoadField: r3 = r2->field_b
    //     0x845d90: ldur            w3, [x2, #0xb]
    // 0x845d94: DecompressPointer r3
    //     0x845d94: add             x3, x3, HEAP, lsl #32
    // 0x845d98: cmp             w3, NULL
    // 0x845d9c: b.eq            #0x845fbc
    // 0x845da0: b               #0x845db0
    // 0x845da4: ldr             x2, [fp, #0x20]
    // 0x845da8: b               #0x845db0
    // 0x845dac: ldr             x2, [fp, #0x20]
    // 0x845db0: tbnz            w0, #4, #0x845dd4
    // 0x845db4: LoadField: r0 = r2->field_b
    //     0x845db4: ldur            w0, [x2, #0xb]
    // 0x845db8: DecompressPointer r0
    //     0x845db8: add             x0, x0, HEAP, lsl #32
    // 0x845dbc: cmp             w0, NULL
    // 0x845dc0: b.eq            #0x845fc0
    // 0x845dc4: LoadField: r1 = r0->field_53
    //     0x845dc4: ldur            w1, [x0, #0x53]
    // 0x845dc8: DecompressPointer r1
    //     0x845dc8: add             x1, x1, HEAP, lsl #32
    // 0x845dcc: mov             x0, x1
    // 0x845dd0: b               #0x845dec
    // 0x845dd4: tbnz            w1, #4, #0x845de8
    // 0x845dd8: LoadField: r0 = r2->field_b
    //     0x845dd8: ldur            w0, [x2, #0xb]
    // 0x845ddc: DecompressPointer r0
    //     0x845ddc: add             x0, x0, HEAP, lsl #32
    // 0x845de0: cmp             w0, NULL
    // 0x845de4: b.eq            #0x845fc4
    // 0x845de8: r0 = Null
    //     0x845de8: mov             x0, NULL
    // 0x845dec: cmp             w0, NULL
    // 0x845df0: b.ne            #0x845e10
    // 0x845df4: LoadField: r0 = r2->field_b
    //     0x845df4: ldur            w0, [x2, #0xb]
    // 0x845df8: DecompressPointer r0
    //     0x845df8: add             x0, x0, HEAP, lsl #32
    // 0x845dfc: cmp             w0, NULL
    // 0x845e00: b.eq            #0x845fc8
    // 0x845e04: LoadField: r1 = r0->field_4f
    //     0x845e04: ldur            w1, [x0, #0x4f]
    // 0x845e08: DecompressPointer r1
    //     0x845e08: add             x1, x1, HEAP, lsl #32
    // 0x845e0c: mov             x0, x1
    // 0x845e10: stur            x0, [fp, #-0x18]
    // 0x845e14: r17 = 307
    //     0x845e14: mov             x17, #0x133
    // 0x845e18: ldr             w1, [x0, x17]
    // 0x845e1c: DecompressPointer r1
    //     0x845e1c: add             x1, x1, HEAP, lsl #32
    // 0x845e20: stur            x1, [fp, #-0x10]
    // 0x845e24: LoadField: r3 = r1->field_b
    //     0x845e24: ldur            w3, [x1, #0xb]
    // 0x845e28: DecompressPointer r3
    //     0x845e28: add             x3, x3, HEAP, lsl #32
    // 0x845e2c: cmp             w3, NULL
    // 0x845e30: b.ne            #0x845e60
    // 0x845e34: d0 = 0.400000
    //     0x845e34: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x845e38: ldr             d0, [x17, #0x148]
    // 0x845e3c: LoadField: r3 = r0->field_3f
    //     0x845e3c: ldur            w3, [x0, #0x3f]
    // 0x845e40: DecompressPointer r3
    //     0x845e40: add             x3, x3, HEAP, lsl #32
    // 0x845e44: LoadField: r4 = r3->field_b
    //     0x845e44: ldur            w4, [x3, #0xb]
    // 0x845e48: DecompressPointer r4
    //     0x845e48: add             x4, x4, HEAP, lsl #32
    // 0x845e4c: SaveReg r4
    //     0x845e4c: str             x4, [SP, #-8]!
    // 0x845e50: SaveReg d0
    //     0x845e50: str             d0, [SP, #-8]!
    // 0x845e54: r0 = withOpacity()
    //     0x845e54: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x845e58: add             SP, SP, #0x10
    // 0x845e5c: mov             x3, x0
    // 0x845e60: ldur            x0, [fp, #-0x10]
    // 0x845e64: stur            x3, [fp, #-0x28]
    // 0x845e68: LoadField: r1 = r0->field_7
    //     0x845e68: ldur            w1, [x0, #7]
    // 0x845e6c: DecompressPointer r1
    //     0x845e6c: add             x1, x1, HEAP, lsl #32
    // 0x845e70: cmp             w1, NULL
    // 0x845e74: b.ne            #0x845e94
    // 0x845e78: ldur            x0, [fp, #-0x18]
    // 0x845e7c: LoadField: r1 = r0->field_3f
    //     0x845e7c: ldur            w1, [x0, #0x3f]
    // 0x845e80: DecompressPointer r1
    //     0x845e80: add             x1, x1, HEAP, lsl #32
    // 0x845e84: LoadField: r2 = r1->field_b
    //     0x845e84: ldur            w2, [x1, #0xb]
    // 0x845e88: DecompressPointer r2
    //     0x845e88: add             x2, x2, HEAP, lsl #32
    // 0x845e8c: mov             x4, x2
    // 0x845e90: b               #0x845e9c
    // 0x845e94: ldur            x0, [fp, #-0x18]
    // 0x845e98: mov             x4, x1
    // 0x845e9c: ldr             x1, [fp, #0x20]
    // 0x845ea0: stur            x4, [fp, #-0x20]
    // 0x845ea4: LoadField: r2 = r1->field_b
    //     0x845ea4: ldur            w2, [x1, #0xb]
    // 0x845ea8: DecompressPointer r2
    //     0x845ea8: add             x2, x2, HEAP, lsl #32
    // 0x845eac: cmp             w2, NULL
    // 0x845eb0: b.eq            #0x845fcc
    // 0x845eb4: LoadField: r5 = r2->field_f
    //     0x845eb4: ldur            w5, [x2, #0xf]
    // 0x845eb8: DecompressPointer r5
    //     0x845eb8: add             x5, x5, HEAP, lsl #32
    // 0x845ebc: stur            x5, [fp, #-0x10]
    // 0x845ec0: LoadField: r1 = r2->field_43
    //     0x845ec0: ldur            w1, [x2, #0x43]
    // 0x845ec4: DecompressPointer r1
    //     0x845ec4: add             x1, x1, HEAP, lsl #32
    // 0x845ec8: cmp             w1, NULL
    // 0x845ecc: b.eq            #0x845efc
    // 0x845ed0: ldur            x2, [fp, #-8]
    // 0x845ed4: r1 = Function '<anonymous closure>':.
    //     0x845ed4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d150] AnonymousClosure: (0x8460e0), in [package:flutter/src/material/app.dart] _MaterialAppState::_materialBuilder (0x845cfc)
    //     0x845ed8: ldr             x1, [x1, #0x150]
    // 0x845edc: r0 = AllocateClosure()
    //     0x845edc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x845ee0: stur            x0, [fp, #-0x30]
    // 0x845ee4: r0 = Builder()
    //     0x845ee4: bl              #0x830cbc  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0x845ee8: mov             x1, x0
    // 0x845eec: ldur            x0, [fp, #-0x30]
    // 0x845ef0: StoreField: r1->field_b = r0
    //     0x845ef0: stur            w0, [x1, #0xb]
    // 0x845ef4: mov             x4, x1
    // 0x845ef8: b               #0x845f24
    // 0x845efc: ldur            x0, [fp, #-8]
    // 0x845f00: LoadField: r1 = r0->field_13
    //     0x845f00: ldur            w1, [x0, #0x13]
    // 0x845f04: DecompressPointer r1
    //     0x845f04: add             x1, x1, HEAP, lsl #32
    // 0x845f08: cmp             w1, NULL
    // 0x845f0c: b.ne            #0x845f1c
    // 0x845f10: r0 = Instance_SizedBox
    //     0x845f10: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x845f14: ldr             x0, [x0, #0x738]
    // 0x845f18: b               #0x845f20
    // 0x845f1c: mov             x0, x1
    // 0x845f20: mov             x4, x0
    // 0x845f24: ldur            x1, [fp, #-0x18]
    // 0x845f28: ldur            x0, [fp, #-0x28]
    // 0x845f2c: ldur            x2, [fp, #-0x20]
    // 0x845f30: ldur            x3, [fp, #-0x10]
    // 0x845f34: stur            x4, [fp, #-8]
    // 0x845f38: r0 = AnimatedTheme()
    //     0x845f38: bl              #0x845fe8  ; AllocateAnimatedThemeStub -> AnimatedTheme (size=0x20)
    // 0x845f3c: mov             x1, x0
    // 0x845f40: ldur            x0, [fp, #-0x18]
    // 0x845f44: stur            x1, [fp, #-0x30]
    // 0x845f48: StoreField: r1->field_17 = r0
    //     0x845f48: stur            w0, [x1, #0x17]
    // 0x845f4c: ldur            x0, [fp, #-8]
    // 0x845f50: StoreField: r1->field_1b = r0
    //     0x845f50: stur            w0, [x1, #0x1b]
    // 0x845f54: r0 = Instance__Linear
    //     0x845f54: add             x0, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x845f58: ldr             x0, [x0, #0x300]
    // 0x845f5c: StoreField: r1->field_b = r0
    //     0x845f5c: stur            w0, [x1, #0xb]
    // 0x845f60: r0 = Instance_Duration
    //     0x845f60: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x845f64: ldr             x0, [x0, #0x9e0]
    // 0x845f68: StoreField: r1->field_f = r0
    //     0x845f68: stur            w0, [x1, #0xf]
    // 0x845f6c: r0 = DefaultSelectionStyle()
    //     0x845f6c: bl              #0x845fdc  ; AllocateDefaultSelectionStyleStub -> DefaultSelectionStyle (size=0x18)
    // 0x845f70: mov             x1, x0
    // 0x845f74: ldur            x0, [fp, #-0x20]
    // 0x845f78: stur            x1, [fp, #-8]
    // 0x845f7c: StoreField: r1->field_f = r0
    //     0x845f7c: stur            w0, [x1, #0xf]
    // 0x845f80: ldur            x0, [fp, #-0x28]
    // 0x845f84: StoreField: r1->field_13 = r0
    //     0x845f84: stur            w0, [x1, #0x13]
    // 0x845f88: ldur            x0, [fp, #-0x30]
    // 0x845f8c: StoreField: r1->field_b = r0
    //     0x845f8c: stur            w0, [x1, #0xb]
    // 0x845f90: r0 = ScaffoldMessenger()
    //     0x845f90: bl              #0x845fd0  ; AllocateScaffoldMessengerStub -> ScaffoldMessenger (size=0x10)
    // 0x845f94: ldur            x1, [fp, #-8]
    // 0x845f98: StoreField: r0->field_b = r1
    //     0x845f98: stur            w1, [x0, #0xb]
    // 0x845f9c: ldur            x1, [fp, #-0x10]
    // 0x845fa0: StoreField: r0->field_7 = r1
    //     0x845fa0: stur            w1, [x0, #7]
    // 0x845fa4: LeaveFrame
    //     0x845fa4: mov             SP, fp
    //     0x845fa8: ldp             fp, lr, [SP], #0x10
    // 0x845fac: ret
    //     0x845fac: ret             
    // 0x845fb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845fb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845fb4: b               #0x845d14
    // 0x845fb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845fb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x845fbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845fbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x845fc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845fc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x845fc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845fc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x845fc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845fc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x845fcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845fcc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x8460e0, size: 0x88
    // 0x8460e0: EnterFrame
    //     0x8460e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8460e4: mov             fp, SP
    // 0x8460e8: ldr             x0, [fp, #0x18]
    // 0x8460ec: LoadField: r1 = r0->field_17
    //     0x8460ec: ldur            w1, [x0, #0x17]
    // 0x8460f0: DecompressPointer r1
    //     0x8460f0: add             x1, x1, HEAP, lsl #32
    // 0x8460f4: CheckStackOverflow
    //     0x8460f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8460f8: cmp             SP, x16
    //     0x8460fc: b.ls            #0x846158
    // 0x846100: LoadField: r0 = r1->field_f
    //     0x846100: ldur            w0, [x1, #0xf]
    // 0x846104: DecompressPointer r0
    //     0x846104: add             x0, x0, HEAP, lsl #32
    // 0x846108: LoadField: r2 = r0->field_b
    //     0x846108: ldur            w2, [x0, #0xb]
    // 0x84610c: DecompressPointer r2
    //     0x84610c: add             x2, x2, HEAP, lsl #32
    // 0x846110: cmp             w2, NULL
    // 0x846114: b.eq            #0x846160
    // 0x846118: LoadField: r0 = r2->field_43
    //     0x846118: ldur            w0, [x2, #0x43]
    // 0x84611c: DecompressPointer r0
    //     0x84611c: add             x0, x0, HEAP, lsl #32
    // 0x846120: cmp             w0, NULL
    // 0x846124: b.eq            #0x846164
    // 0x846128: LoadField: r2 = r1->field_13
    //     0x846128: ldur            w2, [x1, #0x13]
    // 0x84612c: DecompressPointer r2
    //     0x84612c: add             x2, x2, HEAP, lsl #32
    // 0x846130: ldr             x16, [fp, #0x10]
    // 0x846134: stp             x16, x0, [SP, #-0x10]!
    // 0x846138: SaveReg r2
    //     0x846138: str             x2, [SP, #-8]!
    // 0x84613c: ClosureCall
    //     0x84613c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x846140: ldur            x2, [x0, #0x1f]
    //     0x846144: blr             x2
    // 0x846148: add             SP, SP, #0x18
    // 0x84614c: LeaveFrame
    //     0x84614c: mov             SP, fp
    //     0x846150: ldp             fp, lr, [SP], #0x10
    // 0x846154: ret
    //     0x846154: ret             
    // 0x846158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84615c: b               #0x846100
    // 0x846160: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x846160: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x846164: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x846164: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] KeyEventResult <anonymous closure>(dynamic, FocusNode, RawKeyEvent) {
    // ** addr: 0x846168, size: 0xdc
    // 0x846168: EnterFrame
    //     0x846168: stp             fp, lr, [SP, #-0x10]!
    //     0x84616c: mov             fp, SP
    // 0x846170: AllocStack(0x8)
    //     0x846170: sub             SP, SP, #8
    // 0x846174: CheckStackOverflow
    //     0x846174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x846178: cmp             SP, x16
    //     0x84617c: b.ls            #0x84623c
    // 0x846180: ldr             x0, [fp, #0x10]
    // 0x846184: r1 = LoadClassIdInstr(r0)
    //     0x846184: ldur            x1, [x0, #-1]
    //     0x846188: ubfx            x1, x1, #0xc, #0x14
    // 0x84618c: lsl             x1, x1, #1
    // 0x846190: r17 = 5372
    //     0x846190: mov             x17, #0x14fc
    // 0x846194: cmp             w1, w17
    // 0x846198: b.ne            #0x84620c
    // 0x84619c: LoadField: r1 = r0->field_f
    //     0x84619c: ldur            w1, [x0, #0xf]
    // 0x8461a0: DecompressPointer r1
    //     0x8461a0: add             x1, x1, HEAP, lsl #32
    // 0x8461a4: r0 = LoadClassIdInstr(r1)
    //     0x8461a4: ldur            x0, [x1, #-1]
    //     0x8461a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8461ac: SaveReg r1
    //     0x8461ac: str             x1, [SP, #-8]!
    // 0x8461b0: r0 = GDT[cid_x0 + 0x1934]()
    //     0x8461b0: mov             x17, #0x1934
    //     0x8461b4: add             lr, x0, x17
    //     0x8461b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8461bc: blr             lr
    // 0x8461c0: add             SP, SP, #8
    // 0x8461c4: stur            x0, [fp, #-8]
    // 0x8461c8: r16 = Instance_LogicalKeyboardKey
    //     0x8461c8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d0f0] Obj!LogicalKeyboardKey@b3b9d1
    //     0x8461cc: ldr             x16, [x16, #0xf0]
    // 0x8461d0: cmp             w0, w16
    // 0x8461d4: b.eq            #0x84621c
    // 0x8461d8: r16 = LogicalKeyboardKey
    //     0x8461d8: ldr             x16, [PP, #0x6e30]  ; [pp+0x6e30] Type: LogicalKeyboardKey
    // 0x8461dc: r30 = LogicalKeyboardKey
    //     0x8461dc: ldr             lr, [PP, #0x6e30]  ; [pp+0x6e30] Type: LogicalKeyboardKey
    // 0x8461e0: stp             lr, x16, [SP, #-0x10]!
    // 0x8461e4: r0 = ==()
    //     0x8461e4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x8461e8: add             SP, SP, #0x10
    // 0x8461ec: tbnz            w0, #4, #0x84620c
    // 0x8461f0: ldur            x0, [fp, #-8]
    // 0x8461f4: r1 = Instance_LogicalKeyboardKey
    //     0x8461f4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d0f0] Obj!LogicalKeyboardKey@b3b9d1
    //     0x8461f8: ldr             x1, [x1, #0xf0]
    // 0x8461fc: LoadField: r2 = r1->field_7
    //     0x8461fc: ldur            x2, [x1, #7]
    // 0x846200: LoadField: r1 = r0->field_7
    //     0x846200: ldur            x1, [x0, #7]
    // 0x846204: cmp             x2, x1
    // 0x846208: b.eq            #0x84621c
    // 0x84620c: r0 = Instance_KeyEventResult
    //     0x84620c: ldr             x0, [PP, #0x4438]  ; [pp+0x4438] Obj!KeyEventResult@b63d31
    // 0x846210: LeaveFrame
    //     0x846210: mov             SP, fp
    //     0x846214: ldp             fp, lr, [SP], #0x10
    // 0x846218: ret
    //     0x846218: ret             
    // 0x84621c: r0 = dismissAllToolTips()
    //     0x84621c: bl              #0x846244  ; [package:flutter/src/material/tooltip.dart] Tooltip::dismissAllToolTips
    // 0x846220: tbnz            w0, #4, #0x84622c
    // 0x846224: r0 = Instance_KeyEventResult
    //     0x846224: ldr             x0, [PP, #0x4458]  ; [pp+0x4458] Obj!KeyEventResult@b63d11
    // 0x846228: b               #0x846230
    // 0x84622c: r0 = Instance_KeyEventResult
    //     0x84622c: ldr             x0, [PP, #0x4438]  ; [pp+0x4438] Obj!KeyEventResult@b63d31
    // 0x846230: LeaveFrame
    //     0x846230: mov             SP, fp
    //     0x846234: ldp             fp, lr, [SP], #0x10
    // 0x846238: ret
    //     0x846238: ret             
    // 0x84623c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84623c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846240: b               #0x846180
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d9248, size: 0x50
    // 0x9d9248: EnterFrame
    //     0x9d9248: stp             fp, lr, [SP, #-0x10]!
    //     0x9d924c: mov             fp, SP
    // 0x9d9250: CheckStackOverflow
    //     0x9d9250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9254: cmp             SP, x16
    //     0x9d9258: b.ls            #0x9d9290
    // 0x9d925c: r0 = createMaterialHeroController()
    //     0x9d925c: bl              #0x9d9298  ; [package:flutter/src/material/app.dart] MaterialApp::createMaterialHeroController
    // 0x9d9260: ldr             x1, [fp, #0x10]
    // 0x9d9264: StoreField: r1->field_13 = r0
    //     0x9d9264: stur            w0, [x1, #0x13]
    //     0x9d9268: ldurb           w16, [x1, #-1]
    //     0x9d926c: ldurb           w17, [x0, #-1]
    //     0x9d9270: and             x16, x17, x16, lsr #2
    //     0x9d9274: tst             x16, HEAP, lsr #32
    //     0x9d9278: b.eq            #0x9d9280
    //     0x9d927c: bl              #0xd6826c
    // 0x9d9280: r0 = Null
    //     0x9d9280: mov             x0, NULL
    // 0x9d9284: LeaveFrame
    //     0x9d9284: mov             SP, fp
    //     0x9d9288: ldp             fp, lr, [SP], #0x10
    // 0x9d928c: ret
    //     0x9d928c: ret             
    // 0x9d9290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d9290: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d9294: b               #0x9d925c
  }
}

// class id: 4172, size: 0xac, field offset: 0xc
//   const constructor, 
class MaterialApp extends StatefulWidget {

  static _ createMaterialHeroController(/* No info */) {
    // ** addr: 0x9d9298, size: 0x78
    // 0x9d9298: EnterFrame
    //     0x9d9298: stp             fp, lr, [SP, #-0x10]!
    //     0x9d929c: mov             fp, SP
    // 0x9d92a0: AllocStack(0x10)
    //     0x9d92a0: sub             SP, SP, #0x10
    // 0x9d92a4: CheckStackOverflow
    //     0x9d92a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d92a8: cmp             SP, x16
    //     0x9d92ac: b.ls            #0x9d9308
    // 0x9d92b0: r16 = <Object, _HeroFlight>
    //     0x9d92b0: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d178] TypeArguments: <Object, _HeroFlight>
    //     0x9d92b4: ldr             x16, [x16, #0x178]
    // 0x9d92b8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x9d92bc: stp             lr, x16, [SP, #-0x10]!
    // 0x9d92c0: r0 = Map._fromLiteral()
    //     0x9d92c0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9d92c4: add             SP, SP, #0x10
    // 0x9d92c8: stur            x0, [fp, #-8]
    // 0x9d92cc: r0 = HeroController()
    //     0x9d92cc: bl              #0x9d9310  ; AllocateHeroControllerStub -> HeroController (size=0x10)
    // 0x9d92d0: mov             x3, x0
    // 0x9d92d4: ldur            x0, [fp, #-8]
    // 0x9d92d8: stur            x3, [fp, #-0x10]
    // 0x9d92dc: StoreField: r3->field_b = r0
    //     0x9d92dc: stur            w0, [x3, #0xb]
    // 0x9d92e0: r1 = Function '<anonymous closure>': static.
    //     0x9d92e0: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d180] AnonymousClosure: static (0x9d931c), in [package:flutter/src/material/app.dart] MaterialApp::createMaterialHeroController (0x9d9298)
    //     0x9d92e4: ldr             x1, [x1, #0x180]
    // 0x9d92e8: r2 = Null
    //     0x9d92e8: mov             x2, NULL
    // 0x9d92ec: r0 = AllocateClosure()
    //     0x9d92ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d92f0: mov             x1, x0
    // 0x9d92f4: ldur            x0, [fp, #-0x10]
    // 0x9d92f8: StoreField: r0->field_7 = r1
    //     0x9d92f8: stur            w1, [x0, #7]
    // 0x9d92fc: LeaveFrame
    //     0x9d92fc: mov             SP, fp
    //     0x9d9300: ldp             fp, lr, [SP], #0x10
    // 0x9d9304: ret
    //     0x9d9304: ret             
    // 0x9d9308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d9308: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d930c: b               #0x9d92b0
  }
  [closure] static MaterialRectArcTween <anonymous closure>(dynamic, Rect?, Rect?) {
    // ** addr: 0x9d931c, size: 0x44
    // 0x9d931c: EnterFrame
    //     0x9d931c: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9320: mov             fp, SP
    // 0x9d9324: r1 = <Rect?>
    //     0x9d9324: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1ca20] TypeArguments: <Rect?>
    //     0x9d9328: ldr             x1, [x1, #0xa20]
    // 0x9d932c: r0 = MaterialRectArcTween()
    //     0x9d932c: bl              #0x9d9360  ; AllocateMaterialRectArcTweenStub -> MaterialRectArcTween (size=0x20)
    // 0x9d9330: r1 = true
    //     0x9d9330: add             x1, NULL, #0x20  ; true
    // 0x9d9334: StoreField: r0->field_13 = r1
    //     0x9d9334: stur            w1, [x0, #0x13]
    // 0x9d9338: r1 = Sentinel
    //     0x9d9338: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d933c: StoreField: r0->field_17 = r1
    //     0x9d933c: stur            w1, [x0, #0x17]
    // 0x9d9340: StoreField: r0->field_1b = r1
    //     0x9d9340: stur            w1, [x0, #0x1b]
    // 0x9d9344: ldr             x1, [fp, #0x18]
    // 0x9d9348: StoreField: r0->field_b = r1
    //     0x9d9348: stur            w1, [x0, #0xb]
    // 0x9d934c: ldr             x1, [fp, #0x10]
    // 0x9d9350: StoreField: r0->field_f = r1
    //     0x9d9350: stur            w1, [x0, #0xf]
    // 0x9d9354: LeaveFrame
    //     0x9d9354: mov             SP, fp
    //     0x9d9358: ldp             fp, lr, [SP], #0x10
    // 0x9d935c: ret
    //     0x9d935c: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xa400d4, size: 0x28
    // 0xa400d4: EnterFrame
    //     0xa400d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa400d8: mov             fp, SP
    // 0xa400dc: r1 = <MaterialApp>
    //     0xa400dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15320] TypeArguments: <MaterialApp>
    //     0xa400e0: ldr             x1, [x1, #0x320]
    // 0xa400e4: r0 = _MaterialAppState()
    //     0xa400e4: bl              #0xa400fc  ; Allocate_MaterialAppStateStub -> _MaterialAppState (size=0x18)
    // 0xa400e8: r1 = Sentinel
    //     0xa400e8: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa400ec: StoreField: r0->field_13 = r1
    //     0xa400ec: stur            w1, [x0, #0x13]
    // 0xa400f0: LeaveFrame
    //     0xa400f0: mov             SP, fp
    //     0xa400f4: ldp             fp, lr, [SP], #0x10
    // 0xa400f8: ret
    //     0xa400f8: ret             
  }
}

// class id: 5975, size: 0x14, field offset: 0x14
enum ThemeMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15f10, size: 0x5c
    // 0xb15f10: EnterFrame
    //     0xb15f10: stp             fp, lr, [SP, #-0x10]!
    //     0xb15f14: mov             fp, SP
    // 0xb15f18: CheckStackOverflow
    //     0xb15f18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15f1c: cmp             SP, x16
    //     0xb15f20: b.ls            #0xb15f64
    // 0xb15f24: r1 = Null
    //     0xb15f24: mov             x1, NULL
    // 0xb15f28: r2 = 4
    //     0xb15f28: mov             x2, #4
    // 0xb15f2c: r0 = AllocateArray()
    //     0xb15f2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15f30: r17 = "ThemeMode."
    //     0xb15f30: add             x17, PP, #0xe, lsl #12  ; [pp+0xe4e8] "ThemeMode."
    //     0xb15f34: ldr             x17, [x17, #0x4e8]
    // 0xb15f38: StoreField: r0->field_f = r17
    //     0xb15f38: stur            w17, [x0, #0xf]
    // 0xb15f3c: ldr             x1, [fp, #0x10]
    // 0xb15f40: LoadField: r2 = r1->field_f
    //     0xb15f40: ldur            w2, [x1, #0xf]
    // 0xb15f44: DecompressPointer r2
    //     0xb15f44: add             x2, x2, HEAP, lsl #32
    // 0xb15f48: StoreField: r0->field_13 = r2
    //     0xb15f48: stur            w2, [x0, #0x13]
    // 0xb15f4c: SaveReg r0
    //     0xb15f4c: str             x0, [SP, #-8]!
    // 0xb15f50: r0 = _interpolate()
    //     0xb15f50: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15f54: add             SP, SP, #8
    // 0xb15f58: LeaveFrame
    //     0xb15f58: mov             SP, fp
    //     0xb15f5c: ldp             fp, lr, [SP], #0x10
    // 0xb15f60: ret
    //     0xb15f60: ret             
    // 0xb15f64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15f64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15f68: b               #0xb15f24
  }
}

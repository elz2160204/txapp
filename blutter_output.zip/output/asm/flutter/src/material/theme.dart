// lib: , url: package:flutter/src/material/theme.dart

// class id: 1049330, size: 0x8
class :: {
}

// class id: 3309, size: 0x28, field offset: 0x24
class _AnimatedThemeState extends AnimatedWidgetBaseState<AnimatedTheme> {

  _ build(/* No info */) {
    // ** addr: 0x860f50, size: 0xbc
    // 0x860f50: EnterFrame
    //     0x860f50: stp             fp, lr, [SP, #-0x10]!
    //     0x860f54: mov             fp, SP
    // 0x860f58: AllocStack(0x10)
    //     0x860f58: sub             SP, SP, #0x10
    // 0x860f5c: CheckStackOverflow
    //     0x860f5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860f60: cmp             SP, x16
    //     0x860f64: b.ls            #0x860ffc
    // 0x860f68: ldr             x0, [fp, #0x18]
    // 0x860f6c: LoadField: r2 = r0->field_23
    //     0x860f6c: ldur            w2, [x0, #0x23]
    // 0x860f70: DecompressPointer r2
    //     0x860f70: add             x2, x2, HEAP, lsl #32
    // 0x860f74: stur            x2, [fp, #-8]
    // 0x860f78: cmp             w2, NULL
    // 0x860f7c: b.eq            #0x861004
    // 0x860f80: mov             x1, x0
    // 0x860f84: LoadField: r0 = r1->field_1f
    //     0x860f84: ldur            w0, [x1, #0x1f]
    // 0x860f88: DecompressPointer r0
    //     0x860f88: add             x0, x0, HEAP, lsl #32
    // 0x860f8c: r16 = Sentinel
    //     0x860f8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x860f90: cmp             w0, w16
    // 0x860f94: b.ne            #0x860fa4
    // 0x860f98: r2 = _animation
    //     0x860f98: add             x2, PP, #0x21, lsl #12  ; [pp+0x21838] Field <ImplicitlyAnimatedWidgetState._animation@988443363>: late (offset: 0x20)
    //     0x860f9c: ldr             x2, [x2, #0x838]
    // 0x860fa0: r0 = InitLateInstanceField()
    //     0x860fa0: bl              #0xd67c38  ; InitLateInstanceFieldStub
    // 0x860fa4: ldur            x16, [fp, #-8]
    // 0x860fa8: stp             x0, x16, [SP, #-0x10]!
    // 0x860fac: r0 = evaluate()
    //     0x860fac: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x860fb0: add             SP, SP, #0x10
    // 0x860fb4: mov             x1, x0
    // 0x860fb8: ldr             x0, [fp, #0x18]
    // 0x860fbc: stur            x1, [fp, #-0x10]
    // 0x860fc0: LoadField: r2 = r0->field_b
    //     0x860fc0: ldur            w2, [x0, #0xb]
    // 0x860fc4: DecompressPointer r2
    //     0x860fc4: add             x2, x2, HEAP, lsl #32
    // 0x860fc8: cmp             w2, NULL
    // 0x860fcc: b.eq            #0x861008
    // 0x860fd0: LoadField: r0 = r2->field_1b
    //     0x860fd0: ldur            w0, [x2, #0x1b]
    // 0x860fd4: DecompressPointer r0
    //     0x860fd4: add             x0, x0, HEAP, lsl #32
    // 0x860fd8: stur            x0, [fp, #-8]
    // 0x860fdc: r0 = Theme()
    //     0x860fdc: bl              #0x86100c  ; AllocateThemeStub -> Theme (size=0x14)
    // 0x860fe0: ldur            x1, [fp, #-0x10]
    // 0x860fe4: StoreField: r0->field_b = r1
    //     0x860fe4: stur            w1, [x0, #0xb]
    // 0x860fe8: ldur            x1, [fp, #-8]
    // 0x860fec: StoreField: r0->field_f = r1
    //     0x860fec: stur            w1, [x0, #0xf]
    // 0x860ff0: LeaveFrame
    //     0x860ff0: mov             SP, fp
    //     0x860ff4: ldp             fp, lr, [SP], #0x10
    // 0x860ff8: ret
    //     0x860ff8: ret             
    // 0x860ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860ffc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x861000: b               #0x860f68
    // 0x861004: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x861004: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x861008: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x861008: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ forEachTween(/* No info */) {
    // ** addr: 0xbe747c, size: 0x10c
    // 0xbe747c: EnterFrame
    //     0xbe747c: stp             fp, lr, [SP, #-0x10]!
    //     0xbe7480: mov             fp, SP
    // 0xbe7484: AllocStack(0x10)
    //     0xbe7484: sub             SP, SP, #0x10
    // 0xbe7488: CheckStackOverflow
    //     0xbe7488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe748c: cmp             SP, x16
    //     0xbe7490: b.ls            #0xbe7578
    // 0xbe7494: ldr             x0, [fp, #0x18]
    // 0xbe7498: LoadField: r3 = r0->field_23
    //     0xbe7498: ldur            w3, [x0, #0x23]
    // 0xbe749c: DecompressPointer r3
    //     0xbe749c: add             x3, x3, HEAP, lsl #32
    // 0xbe74a0: stur            x3, [fp, #-0x10]
    // 0xbe74a4: LoadField: r1 = r0->field_b
    //     0xbe74a4: ldur            w1, [x0, #0xb]
    // 0xbe74a8: DecompressPointer r1
    //     0xbe74a8: add             x1, x1, HEAP, lsl #32
    // 0xbe74ac: cmp             w1, NULL
    // 0xbe74b0: b.eq            #0xbe7580
    // 0xbe74b4: LoadField: r4 = r1->field_17
    //     0xbe74b4: ldur            w4, [x1, #0x17]
    // 0xbe74b8: DecompressPointer r4
    //     0xbe74b8: add             x4, x4, HEAP, lsl #32
    // 0xbe74bc: stur            x4, [fp, #-8]
    // 0xbe74c0: r1 = Function '<anonymous closure>':.
    //     0xbe74c0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28908] AnonymousClosure: (0xbe7588), in [package:flutter/src/material/theme.dart] _AnimatedThemeState::forEachTween (0xbe747c)
    //     0xbe74c4: ldr             x1, [x1, #0x908]
    // 0xbe74c8: r2 = Null
    //     0xbe74c8: mov             x2, NULL
    // 0xbe74cc: r0 = AllocateClosure()
    //     0xbe74cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbe74d0: ldr             x16, [fp, #0x10]
    // 0xbe74d4: ldur            lr, [fp, #-0x10]
    // 0xbe74d8: stp             lr, x16, [SP, #-0x10]!
    // 0xbe74dc: ldur            x16, [fp, #-8]
    // 0xbe74e0: stp             x0, x16, [SP, #-0x10]!
    // 0xbe74e4: ldr             x0, [fp, #0x10]
    // 0xbe74e8: ClosureCall
    //     0xbe74e8: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xbe74ec: ldur            x2, [x0, #0x1f]
    //     0xbe74f0: blr             x2
    // 0xbe74f4: add             SP, SP, #0x20
    // 0xbe74f8: mov             x3, x0
    // 0xbe74fc: stur            x3, [fp, #-8]
    // 0xbe7500: cmp             w3, NULL
    // 0xbe7504: b.eq            #0xbe7584
    // 0xbe7508: mov             x0, x3
    // 0xbe750c: r2 = Null
    //     0xbe750c: mov             x2, NULL
    // 0xbe7510: r1 = Null
    //     0xbe7510: mov             x1, NULL
    // 0xbe7514: r4 = 59
    //     0xbe7514: mov             x4, #0x3b
    // 0xbe7518: branchIfSmi(r0, 0xbe7524)
    //     0xbe7518: tbz             w0, #0, #0xbe7524
    // 0xbe751c: r4 = LoadClassIdInstr(r0)
    //     0xbe751c: ldur            x4, [x0, #-1]
    //     0xbe7520: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7524: r17 = 4266
    //     0xbe7524: mov             x17, #0x10aa
    // 0xbe7528: cmp             x4, x17
    // 0xbe752c: b.eq            #0xbe7544
    // 0xbe7530: r8 = ThemeDataTween<ThemeData>
    //     0xbe7530: add             x8, PP, #0x28, lsl #12  ; [pp+0x28910] Type: ThemeDataTween<ThemeData>
    //     0xbe7534: ldr             x8, [x8, #0x910]
    // 0xbe7538: r3 = Null
    //     0xbe7538: add             x3, PP, #0x28, lsl #12  ; [pp+0x28918] Null
    //     0xbe753c: ldr             x3, [x3, #0x918]
    // 0xbe7540: r0 = DefaultTypeTest()
    //     0xbe7540: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xbe7544: ldur            x0, [fp, #-8]
    // 0xbe7548: ldr             x1, [fp, #0x18]
    // 0xbe754c: StoreField: r1->field_23 = r0
    //     0xbe754c: stur            w0, [x1, #0x23]
    //     0xbe7550: ldurb           w16, [x1, #-1]
    //     0xbe7554: ldurb           w17, [x0, #-1]
    //     0xbe7558: and             x16, x17, x16, lsr #2
    //     0xbe755c: tst             x16, HEAP, lsr #32
    //     0xbe7560: b.eq            #0xbe7568
    //     0xbe7564: bl              #0xd6826c
    // 0xbe7568: r0 = Null
    //     0xbe7568: mov             x0, NULL
    // 0xbe756c: LeaveFrame
    //     0xbe756c: mov             SP, fp
    //     0xbe7570: ldp             fp, lr, [SP], #0x10
    // 0xbe7574: ret
    //     0xbe7574: ret             
    // 0xbe7578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe7578: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe757c: b               #0xbe7494
    // 0xbe7580: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe7580: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe7584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe7584: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ThemeDataTween <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xbe7588, size: 0x60
    // 0xbe7588: EnterFrame
    //     0xbe7588: stp             fp, lr, [SP, #-0x10]!
    //     0xbe758c: mov             fp, SP
    // 0xbe7590: ldr             x0, [fp, #0x10]
    // 0xbe7594: r2 = Null
    //     0xbe7594: mov             x2, NULL
    // 0xbe7598: r1 = Null
    //     0xbe7598: mov             x1, NULL
    // 0xbe759c: r4 = 59
    //     0xbe759c: mov             x4, #0x3b
    // 0xbe75a0: branchIfSmi(r0, 0xbe75ac)
    //     0xbe75a0: tbz             w0, #0, #0xbe75ac
    // 0xbe75a4: r4 = LoadClassIdInstr(r0)
    //     0xbe75a4: ldur            x4, [x0, #-1]
    //     0xbe75a8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe75ac: cmp             x4, #0xa9e
    // 0xbe75b0: b.eq            #0xbe75c8
    // 0xbe75b4: r8 = ThemeData
    //     0xbe75b4: add             x8, PP, #0xd, lsl #12  ; [pp+0xdf08] Type: ThemeData
    //     0xbe75b8: ldr             x8, [x8, #0xf08]
    // 0xbe75bc: r3 = Null
    //     0xbe75bc: add             x3, PP, #0x28, lsl #12  ; [pp+0x28928] Null
    //     0xbe75c0: ldr             x3, [x3, #0x928]
    // 0xbe75c4: r0 = ThemeData()
    //     0xbe75c4: bl              #0x6cbce4  ; IsType_ThemeData_Stub
    // 0xbe75c8: r1 = <ThemeData>
    //     0xbe75c8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28938] TypeArguments: <ThemeData>
    //     0xbe75cc: ldr             x1, [x1, #0x938]
    // 0xbe75d0: r0 = ThemeDataTween()
    //     0xbe75d0: bl              #0xbe75e8  ; AllocateThemeDataTweenStub -> ThemeDataTween (size=0x14)
    // 0xbe75d4: ldr             x1, [fp, #0x10]
    // 0xbe75d8: StoreField: r0->field_b = r1
    //     0xbe75d8: stur            w1, [x0, #0xb]
    // 0xbe75dc: LeaveFrame
    //     0xbe75dc: mov             SP, fp
    //     0xbe75e0: ldp             fp, lr, [SP], #0x10
    // 0xbe75e4: ret
    //     0xbe75e4: ret             
  }
}

// class id: 3537, size: 0x14, field offset: 0x10
//   const constructor, 
class _InheritedTheme extends InheritedTheme {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa87818, size: 0x9c
    // 0xa87818: EnterFrame
    //     0xa87818: stp             fp, lr, [SP, #-0x10]!
    //     0xa8781c: mov             fp, SP
    // 0xa87820: CheckStackOverflow
    //     0xa87820: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa87824: cmp             SP, x16
    //     0xa87828: b.ls            #0xa878ac
    // 0xa8782c: ldr             x0, [fp, #0x10]
    // 0xa87830: r2 = Null
    //     0xa87830: mov             x2, NULL
    // 0xa87834: r1 = Null
    //     0xa87834: mov             x1, NULL
    // 0xa87838: r4 = 59
    //     0xa87838: mov             x4, #0x3b
    // 0xa8783c: branchIfSmi(r0, 0xa87848)
    //     0xa8783c: tbz             w0, #0, #0xa87848
    // 0xa87840: r4 = LoadClassIdInstr(r0)
    //     0xa87840: ldur            x4, [x0, #-1]
    //     0xa87844: ubfx            x4, x4, #0xc, #0x14
    // 0xa87848: cmp             x4, #0xdd1
    // 0xa8784c: b.eq            #0xa87864
    // 0xa87850: r8 = _InheritedTheme
    //     0xa87850: add             x8, PP, #0x37, lsl #12  ; [pp+0x37298] Type: _InheritedTheme
    //     0xa87854: ldr             x8, [x8, #0x298]
    // 0xa87858: r3 = Null
    //     0xa87858: add             x3, PP, #0x37, lsl #12  ; [pp+0x372a0] Null
    //     0xa8785c: ldr             x3, [x3, #0x2a0]
    // 0xa87860: r0 = DefaultTypeTest()
    //     0xa87860: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa87864: ldr             x0, [fp, #0x18]
    // 0xa87868: LoadField: r1 = r0->field_f
    //     0xa87868: ldur            w1, [x0, #0xf]
    // 0xa8786c: DecompressPointer r1
    //     0xa8786c: add             x1, x1, HEAP, lsl #32
    // 0xa87870: LoadField: r0 = r1->field_b
    //     0xa87870: ldur            w0, [x1, #0xb]
    // 0xa87874: DecompressPointer r0
    //     0xa87874: add             x0, x0, HEAP, lsl #32
    // 0xa87878: ldr             x1, [fp, #0x10]
    // 0xa8787c: LoadField: r2 = r1->field_f
    //     0xa8787c: ldur            w2, [x1, #0xf]
    // 0xa87880: DecompressPointer r2
    //     0xa87880: add             x2, x2, HEAP, lsl #32
    // 0xa87884: LoadField: r1 = r2->field_b
    //     0xa87884: ldur            w1, [x2, #0xb]
    // 0xa87888: DecompressPointer r1
    //     0xa87888: add             x1, x1, HEAP, lsl #32
    // 0xa8788c: stp             x1, x0, [SP, #-0x10]!
    // 0xa87890: r0 = ==()
    //     0xa87890: bl              #0xc90550  ; [package:flutter/src/material/theme_data.dart] ThemeData::==
    // 0xa87894: add             SP, SP, #0x10
    // 0xa87898: eor             x1, x0, #0x10
    // 0xa8789c: mov             x0, x1
    // 0xa878a0: LeaveFrame
    //     0xa878a0: mov             SP, fp
    //     0xa878a4: ldp             fp, lr, [SP], #0x10
    // 0xa878a8: ret
    //     0xa878a8: ret             
    // 0xa878ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa878ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa878b0: b               #0xa8782c
  }
  _ wrap(/* No info */) {
    // ** addr: 0xc2fb98, size: 0x44
    // 0xc2fb98: EnterFrame
    //     0xc2fb98: stp             fp, lr, [SP, #-0x10]!
    //     0xc2fb9c: mov             fp, SP
    // 0xc2fba0: AllocStack(0x8)
    //     0xc2fba0: sub             SP, SP, #8
    // 0xc2fba4: ldr             x0, [fp, #0x18]
    // 0xc2fba8: LoadField: r1 = r0->field_f
    //     0xc2fba8: ldur            w1, [x0, #0xf]
    // 0xc2fbac: DecompressPointer r1
    //     0xc2fbac: add             x1, x1, HEAP, lsl #32
    // 0xc2fbb0: LoadField: r0 = r1->field_b
    //     0xc2fbb0: ldur            w0, [x1, #0xb]
    // 0xc2fbb4: DecompressPointer r0
    //     0xc2fbb4: add             x0, x0, HEAP, lsl #32
    // 0xc2fbb8: stur            x0, [fp, #-8]
    // 0xc2fbbc: r0 = Theme()
    //     0xc2fbbc: bl              #0x86100c  ; AllocateThemeStub -> Theme (size=0x14)
    // 0xc2fbc0: ldur            x1, [fp, #-8]
    // 0xc2fbc4: StoreField: r0->field_b = r1
    //     0xc2fbc4: stur            w1, [x0, #0xb]
    // 0xc2fbc8: ldr             x1, [fp, #0x10]
    // 0xc2fbcc: StoreField: r0->field_f = r1
    //     0xc2fbcc: stur            w1, [x0, #0xf]
    // 0xc2fbd0: LeaveFrame
    //     0xc2fbd0: mov             SP, fp
    //     0xc2fbd4: ldp             fp, lr, [SP], #0x10
    // 0xc2fbd8: ret
    //     0xc2fbd8: ret             
  }
}

// class id: 3837, size: 0x14, field offset: 0xc
//   const constructor, 
class Theme extends StatelessWidget {

  static late final ThemeData _kFallbackTheme; // offset: 0xe40

  static _ of(/* No info */) {
    // ** addr: 0x6cbb30, size: 0xe4
    // 0x6cbb30: EnterFrame
    //     0x6cbb30: stp             fp, lr, [SP, #-0x10]!
    //     0x6cbb34: mov             fp, SP
    // 0x6cbb38: AllocStack(0x8)
    //     0x6cbb38: sub             SP, SP, #8
    // 0x6cbb3c: CheckStackOverflow
    //     0x6cbb3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cbb40: cmp             SP, x16
    //     0x6cbb44: b.ls            #0x6cbc0c
    // 0x6cbb48: r16 = <_InheritedTheme>
    //     0x6cbb48: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf98] TypeArguments: <_InheritedTheme>
    //     0x6cbb4c: ldr             x16, [x16, #0xf98]
    // 0x6cbb50: ldr             lr, [fp, #0x10]
    // 0x6cbb54: stp             lr, x16, [SP, #-0x10]!
    // 0x6cbb58: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6cbb58: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6cbb5c: r0 = dependOnInheritedWidgetOfExactType()
    //     0x6cbb5c: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x6cbb60: add             SP, SP, #0x10
    // 0x6cbb64: stur            x0, [fp, #-8]
    // 0x6cbb68: r16 = <MaterialLocalizations>
    //     0x6cbb68: add             x16, PP, #0xd, lsl #12  ; [pp+0xdfa0] TypeArguments: <MaterialLocalizations>
    //     0x6cbb6c: ldr             x16, [x16, #0xfa0]
    // 0x6cbb70: ldr             lr, [fp, #0x10]
    // 0x6cbb74: stp             lr, x16, [SP, #-0x10]!
    // 0x6cbb78: r16 = MaterialLocalizations
    //     0x6cbb78: add             x16, PP, #0xd, lsl #12  ; [pp+0xdfa8] Type: MaterialLocalizations
    //     0x6cbb7c: ldr             x16, [x16, #0xfa8]
    // 0x6cbb80: SaveReg r16
    //     0x6cbb80: str             x16, [SP, #-8]!
    // 0x6cbb84: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6cbb84: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6cbb88: r0 = of()
    //     0x6cbb88: bl              #0x6ced68  ; [package:flutter/src/widgets/localizations.dart] Localizations::of
    // 0x6cbb8c: add             SP, SP, #0x18
    // 0x6cbb90: cmp             w0, NULL
    // 0x6cbb94: b.eq            #0x6cbb98
    // 0x6cbb98: ldur            x0, [fp, #-8]
    // 0x6cbb9c: cmp             w0, NULL
    // 0x6cbba0: b.ne            #0x6cbbac
    // 0x6cbba4: r0 = Null
    //     0x6cbba4: mov             x0, NULL
    // 0x6cbba8: b               #0x6cbbbc
    // 0x6cbbac: LoadField: r1 = r0->field_f
    //     0x6cbbac: ldur            w1, [x0, #0xf]
    // 0x6cbbb0: DecompressPointer r1
    //     0x6cbbb0: add             x1, x1, HEAP, lsl #32
    // 0x6cbbb4: LoadField: r0 = r1->field_b
    //     0x6cbbb4: ldur            w0, [x1, #0xb]
    // 0x6cbbb8: DecompressPointer r0
    //     0x6cbbb8: add             x0, x0, HEAP, lsl #32
    // 0x6cbbbc: cmp             w0, NULL
    // 0x6cbbc0: b.ne            #0x6cbbe4
    // 0x6cbbc4: r0 = InitLateStaticField(0xe40) // [package:flutter/src/material/theme.dart] Theme::_kFallbackTheme
    //     0x6cbbc4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6cbbc8: ldr             x0, [x0, #0x1c80]
    //     0x6cbbcc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6cbbd0: cmp             w0, w16
    //     0x6cbbd4: b.ne            #0x6cbbe4
    //     0x6cbbd8: add             x2, PP, #0xd, lsl #12  ; [pp+0xdfb0] Field <Theme._kFallbackTheme@830067045>: static late final (offset: 0xe40)
    //     0x6cbbdc: ldr             x2, [x2, #0xfb0]
    //     0x6cbbe0: bl              #0xd67cdc
    // 0x6cbbe4: LoadField: r1 = r0->field_97
    //     0x6cbbe4: ldur            w1, [x0, #0x97]
    // 0x6cbbe8: DecompressPointer r1
    //     0x6cbbe8: add             x1, x1, HEAP, lsl #32
    // 0x6cbbec: LoadField: r2 = r1->field_f
    //     0x6cbbec: ldur            w2, [x1, #0xf]
    // 0x6cbbf0: DecompressPointer r2
    //     0x6cbbf0: add             x2, x2, HEAP, lsl #32
    // 0x6cbbf4: stp             x2, x0, [SP, #-0x10]!
    // 0x6cbbf8: r0 = localize()
    //     0x6cbbf8: bl              #0x6cbc14  ; [package:flutter/src/material/theme_data.dart] ThemeData::localize
    // 0x6cbbfc: add             SP, SP, #0x10
    // 0x6cbc00: LeaveFrame
    //     0x6cbc00: mov             SP, fp
    //     0x6cbc04: ldp             fp, lr, [SP], #0x10
    // 0x6cbc08: ret
    //     0x6cbc08: ret             
    // 0x6cbc0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cbc0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cbc10: b               #0x6cbb48
  }
  static ThemeData _kFallbackTheme() {
    // ** addr: 0x6cef08, size: 0x34
    // 0x6cef08: EnterFrame
    //     0x6cef08: stp             fp, lr, [SP, #-0x10]!
    //     0x6cef0c: mov             fp, SP
    // 0x6cef10: CheckStackOverflow
    //     0x6cef10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cef14: cmp             SP, x16
    //     0x6cef18: b.ls            #0x6cef34
    // 0x6cef1c: SaveReg rNULL
    //     0x6cef1c: str             NULL, [SP, #-8]!
    // 0x6cef20: r0 = ThemeData.light()
    //     0x6cef20: bl              #0x6cef3c  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData.light
    // 0x6cef24: add             SP, SP, #8
    // 0x6cef28: LeaveFrame
    //     0x6cef28: mov             SP, fp
    //     0x6cef2c: ldp             fp, lr, [SP], #0x10
    // 0x6cef30: ret
    //     0x6cef30: ret             
    // 0x6cef34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cef34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cef38: b               #0x6cef1c
  }
  _ build(/* No info */) {
    // ** addr: 0xb2480c, size: 0xc8
    // 0xb2480c: EnterFrame
    //     0xb2480c: stp             fp, lr, [SP, #-0x10]!
    //     0xb24810: mov             fp, SP
    // 0xb24814: AllocStack(0x18)
    //     0xb24814: sub             SP, SP, #0x18
    // 0xb24818: CheckStackOverflow
    //     0xb24818: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2481c: cmp             SP, x16
    //     0xb24820: b.ls            #0xb248cc
    // 0xb24824: ldr             x0, [fp, #0x18]
    // 0xb24828: LoadField: r1 = r0->field_b
    //     0xb24828: ldur            w1, [x0, #0xb]
    // 0xb2482c: DecompressPointer r1
    //     0xb2482c: add             x1, x1, HEAP, lsl #32
    // 0xb24830: stur            x1, [fp, #-8]
    // 0xb24834: r16 = Instance_CupertinoThemeData
    //     0xb24834: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db68] Obj!CupertinoThemeData@b38831
    //     0xb24838: ldr             x16, [x16, #0xb68]
    // 0xb2483c: SaveReg r16
    //     0xb2483c: str             x16, [SP, #-8]!
    // 0xb24840: r0 = noDefault()
    //     0xb24840: bl              #0xb249cc  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::noDefault
    // 0xb24844: add             SP, SP, #8
    // 0xb24848: stur            x0, [fp, #-0x10]
    // 0xb2484c: r0 = MaterialBasedCupertinoThemeData()
    //     0xb2484c: bl              #0x83d4a0  ; AllocateMaterialBasedCupertinoThemeDataStub -> MaterialBasedCupertinoThemeData (size=0x2c)
    // 0xb24850: stur            x0, [fp, #-0x18]
    // 0xb24854: ldur            x16, [fp, #-8]
    // 0xb24858: stp             x16, x0, [SP, #-0x10]!
    // 0xb2485c: ldur            x16, [fp, #-0x10]
    // 0xb24860: SaveReg r16
    //     0xb24860: str             x16, [SP, #-8]!
    // 0xb24864: r0 = MaterialBasedCupertinoThemeData._()
    //     0xb24864: bl              #0x83d370  ; [package:flutter/src/material/theme_data.dart] MaterialBasedCupertinoThemeData::MaterialBasedCupertinoThemeData._
    // 0xb24868: add             SP, SP, #0x18
    // 0xb2486c: ldr             x0, [fp, #0x18]
    // 0xb24870: LoadField: r1 = r0->field_f
    //     0xb24870: ldur            w1, [x0, #0xf]
    // 0xb24874: DecompressPointer r1
    //     0xb24874: add             x1, x1, HEAP, lsl #32
    // 0xb24878: ldr             x16, [fp, #0x10]
    // 0xb2487c: stp             x16, x0, [SP, #-0x10]!
    // 0xb24880: SaveReg r1
    //     0xb24880: str             x1, [SP, #-8]!
    // 0xb24884: r0 = _wrapsWidgetThemes()
    //     0xb24884: bl              #0xb248ec  ; [package:flutter/src/material/theme.dart] Theme::_wrapsWidgetThemes
    // 0xb24888: add             SP, SP, #0x18
    // 0xb2488c: stur            x0, [fp, #-8]
    // 0xb24890: r0 = CupertinoTheme()
    //     0xb24890: bl              #0xb248e0  ; AllocateCupertinoThemeStub -> CupertinoTheme (size=0x14)
    // 0xb24894: mov             x1, x0
    // 0xb24898: ldur            x0, [fp, #-0x18]
    // 0xb2489c: stur            x1, [fp, #-0x10]
    // 0xb248a0: StoreField: r1->field_b = r0
    //     0xb248a0: stur            w0, [x1, #0xb]
    // 0xb248a4: ldur            x0, [fp, #-8]
    // 0xb248a8: StoreField: r1->field_f = r0
    //     0xb248a8: stur            w0, [x1, #0xf]
    // 0xb248ac: r0 = _InheritedTheme()
    //     0xb248ac: bl              #0xb248d4  ; Allocate_InheritedThemeStub -> _InheritedTheme (size=0x14)
    // 0xb248b0: ldr             x1, [fp, #0x18]
    // 0xb248b4: StoreField: r0->field_f = r1
    //     0xb248b4: stur            w1, [x0, #0xf]
    // 0xb248b8: ldur            x1, [fp, #-0x10]
    // 0xb248bc: StoreField: r0->field_b = r1
    //     0xb248bc: stur            w1, [x0, #0xb]
    // 0xb248c0: LeaveFrame
    //     0xb248c0: mov             SP, fp
    //     0xb248c4: ldp             fp, lr, [SP], #0x10
    // 0xb248c8: ret
    //     0xb248c8: ret             
    // 0xb248cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb248cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb248d0: b               #0xb24824
  }
  _ _wrapsWidgetThemes(/* No info */) {
    // ** addr: 0xb248ec, size: 0xe0
    // 0xb248ec: EnterFrame
    //     0xb248ec: stp             fp, lr, [SP, #-0x10]!
    //     0xb248f0: mov             fp, SP
    // 0xb248f4: AllocStack(0x20)
    //     0xb248f4: sub             SP, SP, #0x20
    // 0xb248f8: CheckStackOverflow
    //     0xb248f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb248fc: cmp             SP, x16
    //     0xb24900: b.ls            #0xb249c4
    // 0xb24904: ldr             x16, [fp, #0x18]
    // 0xb24908: SaveReg r16
    //     0xb24908: str             x16, [SP, #-8]!
    // 0xb2490c: r0 = of()
    //     0xb2490c: bl              #0x872148  ; [package:flutter/src/widgets/default_selection_style.dart] DefaultSelectionStyle::of
    // 0xb24910: add             SP, SP, #8
    // 0xb24914: mov             x1, x0
    // 0xb24918: ldr             x0, [fp, #0x20]
    // 0xb2491c: LoadField: r2 = r0->field_b
    //     0xb2491c: ldur            w2, [x0, #0xb]
    // 0xb24920: DecompressPointer r2
    //     0xb24920: add             x2, x2, HEAP, lsl #32
    // 0xb24924: LoadField: r0 = r2->field_87
    //     0xb24924: ldur            w0, [x2, #0x87]
    // 0xb24928: DecompressPointer r0
    //     0xb24928: add             x0, x0, HEAP, lsl #32
    // 0xb2492c: stur            x0, [fp, #-0x18]
    // 0xb24930: r17 = 307
    //     0xb24930: mov             x17, #0x133
    // 0xb24934: ldr             w3, [x2, x17]
    // 0xb24938: DecompressPointer r3
    //     0xb24938: add             x3, x3, HEAP, lsl #32
    // 0xb2493c: LoadField: r2 = r3->field_b
    //     0xb2493c: ldur            w2, [x3, #0xb]
    // 0xb24940: DecompressPointer r2
    //     0xb24940: add             x2, x2, HEAP, lsl #32
    // 0xb24944: cmp             w2, NULL
    // 0xb24948: b.ne            #0xb24954
    // 0xb2494c: LoadField: r2 = r1->field_13
    //     0xb2494c: ldur            w2, [x1, #0x13]
    // 0xb24950: DecompressPointer r2
    //     0xb24950: add             x2, x2, HEAP, lsl #32
    // 0xb24954: stur            x2, [fp, #-0x10]
    // 0xb24958: LoadField: r4 = r3->field_7
    //     0xb24958: ldur            w4, [x3, #7]
    // 0xb2495c: DecompressPointer r4
    //     0xb2495c: add             x4, x4, HEAP, lsl #32
    // 0xb24960: cmp             w4, NULL
    // 0xb24964: b.ne            #0xb24974
    // 0xb24968: LoadField: r3 = r1->field_f
    //     0xb24968: ldur            w3, [x1, #0xf]
    // 0xb2496c: DecompressPointer r3
    //     0xb2496c: add             x3, x3, HEAP, lsl #32
    // 0xb24970: b               #0xb24978
    // 0xb24974: mov             x3, x4
    // 0xb24978: ldr             x1, [fp, #0x10]
    // 0xb2497c: stur            x3, [fp, #-8]
    // 0xb24980: r0 = DefaultSelectionStyle()
    //     0xb24980: bl              #0x845fdc  ; AllocateDefaultSelectionStyleStub -> DefaultSelectionStyle (size=0x18)
    // 0xb24984: mov             x1, x0
    // 0xb24988: ldur            x0, [fp, #-8]
    // 0xb2498c: stur            x1, [fp, #-0x20]
    // 0xb24990: StoreField: r1->field_f = r0
    //     0xb24990: stur            w0, [x1, #0xf]
    // 0xb24994: ldur            x0, [fp, #-0x10]
    // 0xb24998: StoreField: r1->field_13 = r0
    //     0xb24998: stur            w0, [x1, #0x13]
    // 0xb2499c: ldr             x0, [fp, #0x10]
    // 0xb249a0: StoreField: r1->field_b = r0
    //     0xb249a0: stur            w0, [x1, #0xb]
    // 0xb249a4: r0 = IconTheme()
    //     0xb249a4: bl              #0x83fd30  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0xb249a8: ldur            x1, [fp, #-0x18]
    // 0xb249ac: StoreField: r0->field_f = r1
    //     0xb249ac: stur            w1, [x0, #0xf]
    // 0xb249b0: ldur            x1, [fp, #-0x20]
    // 0xb249b4: StoreField: r0->field_b = r1
    //     0xb249b4: stur            w1, [x0, #0xb]
    // 0xb249b8: LeaveFrame
    //     0xb249b8: mov             SP, fp
    //     0xb249bc: ldp             fp, lr, [SP], #0x10
    // 0xb249c0: ret
    //     0xb249c0: ret             
    // 0xb249c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb249c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb249c8: b               #0xb24904
  }
}

// class id: 4145, size: 0x20, field offset: 0x18
//   const constructor, 
class AnimatedTheme extends ImplicitlyAnimatedWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa40a0c, size: 0x2c
    // 0xa40a0c: EnterFrame
    //     0xa40a0c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40a10: mov             fp, SP
    // 0xa40a14: r1 = <AnimatedTheme>
    //     0xa40a14: add             x1, PP, #0x21, lsl #12  ; [pp+0x21d40] TypeArguments: <AnimatedTheme>
    //     0xa40a18: ldr             x1, [x1, #0xd40]
    // 0xa40a1c: r0 = _AnimatedThemeState()
    //     0xa40a1c: bl              #0xa40a38  ; Allocate_AnimatedThemeStateStub -> _AnimatedThemeState (size=0x28)
    // 0xa40a20: r1 = Sentinel
    //     0xa40a20: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40a24: StoreField: r0->field_1b = r1
    //     0xa40a24: stur            w1, [x0, #0x1b]
    // 0xa40a28: StoreField: r0->field_1f = r1
    //     0xa40a28: stur            w1, [x0, #0x1f]
    // 0xa40a2c: LeaveFrame
    //     0xa40a2c: mov             SP, fp
    //     0xa40a30: ldp             fp, lr, [SP], #0x10
    // 0xa40a34: ret
    //     0xa40a34: ret             
  }
}

// class id: 4266, size: 0x14, field offset: 0x14
class ThemeDataTween extends Tween<ThemeData> {

  _ lerp(/* No info */) {
    // ** addr: 0xbeccf4, size: 0x68
    // 0xbeccf4: EnterFrame
    //     0xbeccf4: stp             fp, lr, [SP, #-0x10]!
    //     0xbeccf8: mov             fp, SP
    // 0xbeccfc: CheckStackOverflow
    //     0xbeccfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbecd00: cmp             SP, x16
    //     0xbecd04: b.ls            #0xbecd4c
    // 0xbecd08: ldr             x0, [fp, #0x18]
    // 0xbecd0c: LoadField: r1 = r0->field_b
    //     0xbecd0c: ldur            w1, [x0, #0xb]
    // 0xbecd10: DecompressPointer r1
    //     0xbecd10: add             x1, x1, HEAP, lsl #32
    // 0xbecd14: cmp             w1, NULL
    // 0xbecd18: b.eq            #0xbecd54
    // 0xbecd1c: LoadField: r2 = r0->field_f
    //     0xbecd1c: ldur            w2, [x0, #0xf]
    // 0xbecd20: DecompressPointer r2
    //     0xbecd20: add             x2, x2, HEAP, lsl #32
    // 0xbecd24: cmp             w2, NULL
    // 0xbecd28: b.eq            #0xbecd58
    // 0xbecd2c: stp             x2, x1, [SP, #-0x10]!
    // 0xbecd30: ldr             d0, [fp, #0x10]
    // 0xbecd34: SaveReg d0
    //     0xbecd34: str             d0, [SP, #-8]!
    // 0xbecd38: r0 = lerp()
    //     0xbecd38: bl              #0xbecd5c  ; [package:flutter/src/material/theme_data.dart] ThemeData::lerp
    // 0xbecd3c: add             SP, SP, #0x18
    // 0xbecd40: LeaveFrame
    //     0xbecd40: mov             SP, fp
    //     0xbecd44: ldp             fp, lr, [SP], #0x10
    // 0xbecd48: ret
    //     0xbecd48: ret             
    // 0xbecd4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbecd4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbecd50: b               #0xbecd08
    // 0xbecd54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbecd54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbecd58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbecd58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

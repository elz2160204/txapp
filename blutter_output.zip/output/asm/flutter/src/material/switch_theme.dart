// lib: , url: package:flutter/src/material/switch_theme.dart

// class id: 1049316, size: 0x8
class :: {
}

// class id: 2725, size: 0x24, field offset: 0x8
//   const constructor, 
class SwitchThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb01af0, size: 0x80
    // 0xb01af0: EnterFrame
    //     0xb01af0: stp             fp, lr, [SP, #-0x10]!
    //     0xb01af4: mov             fp, SP
    // 0xb01af8: CheckStackOverflow
    //     0xb01af8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb01afc: cmp             SP, x16
    //     0xb01b00: b.ls            #0xb01b68
    // 0xb01b04: ldr             x0, [fp, #0x10]
    // 0xb01b08: LoadField: r1 = r0->field_7
    //     0xb01b08: ldur            w1, [x0, #7]
    // 0xb01b0c: DecompressPointer r1
    //     0xb01b0c: add             x1, x1, HEAP, lsl #32
    // 0xb01b10: LoadField: r2 = r0->field_b
    //     0xb01b10: ldur            w2, [x0, #0xb]
    // 0xb01b14: DecompressPointer r2
    //     0xb01b14: add             x2, x2, HEAP, lsl #32
    // 0xb01b18: LoadField: r3 = r0->field_17
    //     0xb01b18: ldur            w3, [x0, #0x17]
    // 0xb01b1c: DecompressPointer r3
    //     0xb01b1c: add             x3, x3, HEAP, lsl #32
    // 0xb01b20: LoadField: r4 = r0->field_1b
    //     0xb01b20: ldur            w4, [x0, #0x1b]
    // 0xb01b24: DecompressPointer r4
    //     0xb01b24: add             x4, x4, HEAP, lsl #32
    // 0xb01b28: stp             x2, x1, [SP, #-0x10]!
    // 0xb01b2c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb01b30: stp             x4, x3, [SP, #-0x10]!
    // 0xb01b34: SaveReg rNULL
    //     0xb01b34: str             NULL, [SP, #-8]!
    // 0xb01b38: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0xb01b38: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0xb01b3c: r0 = hash()
    //     0xb01b3c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb01b40: add             SP, SP, #0x38
    // 0xb01b44: mov             x2, x0
    // 0xb01b48: r0 = BoxInt64Instr(r2)
    //     0xb01b48: sbfiz           x0, x2, #1, #0x1f
    //     0xb01b4c: cmp             x2, x0, asr #1
    //     0xb01b50: b.eq            #0xb01b5c
    //     0xb01b54: bl              #0xd69bb8
    //     0xb01b58: stur            x2, [x0, #7]
    // 0xb01b5c: LeaveFrame
    //     0xb01b5c: mov             SP, fp
    //     0xb01b60: ldp             fp, lr, [SP], #0x10
    // 0xb01b64: ret
    //     0xb01b64: ret             
    // 0xb01b68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb01b68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb01b6c: b               #0xb01b04
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf283c, size: 0x1b8
    // 0xbf283c: EnterFrame
    //     0xbf283c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2840: mov             fp, SP
    // 0xbf2844: AllocStack(0x20)
    //     0xbf2844: sub             SP, SP, #0x20
    // 0xbf2848: CheckStackOverflow
    //     0xbf2848: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf284c: cmp             SP, x16
    //     0xbf2850: b.ls            #0xbf29cc
    // 0xbf2854: ldr             x0, [fp, #0x20]
    // 0xbf2858: LoadField: r1 = r0->field_7
    //     0xbf2858: ldur            w1, [x0, #7]
    // 0xbf285c: DecompressPointer r1
    //     0xbf285c: add             x1, x1, HEAP, lsl #32
    // 0xbf2860: ldr             x2, [fp, #0x18]
    // 0xbf2864: LoadField: r3 = r2->field_7
    //     0xbf2864: ldur            w3, [x2, #7]
    // 0xbf2868: DecompressPointer r3
    //     0xbf2868: add             x3, x3, HEAP, lsl #32
    // 0xbf286c: r16 = <Color?>
    //     0xbf286c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf2870: ldr             x16, [x16, #0xf68]
    // 0xbf2874: stp             x1, x16, [SP, #-0x10]!
    // 0xbf2878: SaveReg r3
    //     0xbf2878: str             x3, [SP, #-8]!
    // 0xbf287c: ldr             d0, [fp, #0x10]
    // 0xbf2880: SaveReg d0
    //     0xbf2880: str             d0, [SP, #-8]!
    // 0xbf2884: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf2884: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf2888: ldr             x16, [x16, #0xb80]
    // 0xbf288c: SaveReg r16
    //     0xbf288c: str             x16, [SP, #-8]!
    // 0xbf2890: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf2890: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf2894: r0 = lerp()
    //     0xbf2894: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf2898: add             SP, SP, #0x28
    // 0xbf289c: mov             x1, x0
    // 0xbf28a0: ldr             x0, [fp, #0x20]
    // 0xbf28a4: stur            x1, [fp, #-8]
    // 0xbf28a8: LoadField: r2 = r0->field_b
    //     0xbf28a8: ldur            w2, [x0, #0xb]
    // 0xbf28ac: DecompressPointer r2
    //     0xbf28ac: add             x2, x2, HEAP, lsl #32
    // 0xbf28b0: ldr             x3, [fp, #0x18]
    // 0xbf28b4: LoadField: r4 = r3->field_b
    //     0xbf28b4: ldur            w4, [x3, #0xb]
    // 0xbf28b8: DecompressPointer r4
    //     0xbf28b8: add             x4, x4, HEAP, lsl #32
    // 0xbf28bc: r16 = <Color?>
    //     0xbf28bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf28c0: ldr             x16, [x16, #0xf68]
    // 0xbf28c4: stp             x2, x16, [SP, #-0x10]!
    // 0xbf28c8: SaveReg r4
    //     0xbf28c8: str             x4, [SP, #-8]!
    // 0xbf28cc: ldr             d0, [fp, #0x10]
    // 0xbf28d0: SaveReg d0
    //     0xbf28d0: str             d0, [SP, #-8]!
    // 0xbf28d4: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf28d4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf28d8: ldr             x16, [x16, #0xb80]
    // 0xbf28dc: SaveReg r16
    //     0xbf28dc: str             x16, [SP, #-8]!
    // 0xbf28e0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf28e0: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf28e4: r0 = lerp()
    //     0xbf28e4: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf28e8: add             SP, SP, #0x28
    // 0xbf28ec: mov             x1, x0
    // 0xbf28f0: ldr             x0, [fp, #0x20]
    // 0xbf28f4: stur            x1, [fp, #-0x10]
    // 0xbf28f8: LoadField: r2 = r0->field_17
    //     0xbf28f8: ldur            w2, [x0, #0x17]
    // 0xbf28fc: DecompressPointer r2
    //     0xbf28fc: add             x2, x2, HEAP, lsl #32
    // 0xbf2900: ldr             x3, [fp, #0x18]
    // 0xbf2904: LoadField: r4 = r3->field_17
    //     0xbf2904: ldur            w4, [x3, #0x17]
    // 0xbf2908: DecompressPointer r4
    //     0xbf2908: add             x4, x4, HEAP, lsl #32
    // 0xbf290c: r16 = <Color?>
    //     0xbf290c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf2910: ldr             x16, [x16, #0xf68]
    // 0xbf2914: stp             x2, x16, [SP, #-0x10]!
    // 0xbf2918: SaveReg r4
    //     0xbf2918: str             x4, [SP, #-8]!
    // 0xbf291c: ldr             d0, [fp, #0x10]
    // 0xbf2920: SaveReg d0
    //     0xbf2920: str             d0, [SP, #-8]!
    // 0xbf2924: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf2924: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf2928: ldr             x16, [x16, #0xb80]
    // 0xbf292c: SaveReg r16
    //     0xbf292c: str             x16, [SP, #-8]!
    // 0xbf2930: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf2930: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf2934: r0 = lerp()
    //     0xbf2934: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf2938: add             SP, SP, #0x28
    // 0xbf293c: mov             x1, x0
    // 0xbf2940: ldr             x0, [fp, #0x20]
    // 0xbf2944: stur            x1, [fp, #-0x18]
    // 0xbf2948: LoadField: r2 = r0->field_1b
    //     0xbf2948: ldur            w2, [x0, #0x1b]
    // 0xbf294c: DecompressPointer r2
    //     0xbf294c: add             x2, x2, HEAP, lsl #32
    // 0xbf2950: ldr             x0, [fp, #0x18]
    // 0xbf2954: LoadField: r3 = r0->field_1b
    //     0xbf2954: ldur            w3, [x0, #0x1b]
    // 0xbf2958: DecompressPointer r3
    //     0xbf2958: add             x3, x3, HEAP, lsl #32
    // 0xbf295c: ldr             d0, [fp, #0x10]
    // 0xbf2960: r0 = inline_Allocate_Double()
    //     0xbf2960: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbf2964: add             x0, x0, #0x10
    //     0xbf2968: cmp             x4, x0
    //     0xbf296c: b.ls            #0xbf29d4
    //     0xbf2970: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf2974: sub             x0, x0, #0xf
    //     0xbf2978: mov             x4, #0xd108
    //     0xbf297c: movk            x4, #3, lsl #16
    //     0xbf2980: stur            x4, [x0, #-1]
    // 0xbf2984: StoreField: r0->field_7 = d0
    //     0xbf2984: stur            d0, [x0, #7]
    // 0xbf2988: stp             x3, x2, [SP, #-0x10]!
    // 0xbf298c: SaveReg r0
    //     0xbf298c: str             x0, [SP, #-8]!
    // 0xbf2990: r0 = lerpDouble()
    //     0xbf2990: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf2994: add             SP, SP, #0x18
    // 0xbf2998: stur            x0, [fp, #-0x20]
    // 0xbf299c: r0 = SwitchThemeData()
    //     0xbf299c: bl              #0xbf29f4  ; AllocateSwitchThemeDataStub -> SwitchThemeData (size=0x24)
    // 0xbf29a0: ldur            x1, [fp, #-8]
    // 0xbf29a4: StoreField: r0->field_7 = r1
    //     0xbf29a4: stur            w1, [x0, #7]
    // 0xbf29a8: ldur            x1, [fp, #-0x10]
    // 0xbf29ac: StoreField: r0->field_b = r1
    //     0xbf29ac: stur            w1, [x0, #0xb]
    // 0xbf29b0: ldur            x1, [fp, #-0x18]
    // 0xbf29b4: StoreField: r0->field_17 = r1
    //     0xbf29b4: stur            w1, [x0, #0x17]
    // 0xbf29b8: ldur            x1, [fp, #-0x20]
    // 0xbf29bc: StoreField: r0->field_1b = r1
    //     0xbf29bc: stur            w1, [x0, #0x1b]
    // 0xbf29c0: LeaveFrame
    //     0xbf29c0: mov             SP, fp
    //     0xbf29c4: ldp             fp, lr, [SP], #0x10
    // 0xbf29c8: ret
    //     0xbf29c8: ret             
    // 0xbf29cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf29cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf29d0: b               #0xbf2854
    // 0xbf29d4: SaveReg d0
    //     0xbf29d4: str             q0, [SP, #-0x10]!
    // 0xbf29d8: stp             x2, x3, [SP, #-0x10]!
    // 0xbf29dc: SaveReg r1
    //     0xbf29dc: str             x1, [SP, #-8]!
    // 0xbf29e0: r0 = AllocateDouble()
    //     0xbf29e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf29e4: RestoreReg r1
    //     0xbf29e4: ldr             x1, [SP], #8
    // 0xbf29e8: ldp             x2, x3, [SP], #0x10
    // 0xbf29ec: RestoreReg d0
    //     0xbf29ec: ldr             q0, [SP], #0x10
    // 0xbf29f0: b               #0xbf2984
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8f114, size: 0x174
    // 0xc8f114: EnterFrame
    //     0xc8f114: stp             fp, lr, [SP, #-0x10]!
    //     0xc8f118: mov             fp, SP
    // 0xc8f11c: CheckStackOverflow
    //     0xc8f11c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8f120: cmp             SP, x16
    //     0xc8f124: b.ls            #0xc8f280
    // 0xc8f128: ldr             x1, [fp, #0x10]
    // 0xc8f12c: cmp             w1, NULL
    // 0xc8f130: b.ne            #0xc8f144
    // 0xc8f134: r0 = false
    //     0xc8f134: add             x0, NULL, #0x30  ; false
    // 0xc8f138: LeaveFrame
    //     0xc8f138: mov             SP, fp
    //     0xc8f13c: ldp             fp, lr, [SP], #0x10
    // 0xc8f140: ret
    //     0xc8f140: ret             
    // 0xc8f144: ldr             x2, [fp, #0x18]
    // 0xc8f148: cmp             w2, w1
    // 0xc8f14c: b.ne            #0xc8f160
    // 0xc8f150: r0 = true
    //     0xc8f150: add             x0, NULL, #0x20  ; true
    // 0xc8f154: LeaveFrame
    //     0xc8f154: mov             SP, fp
    //     0xc8f158: ldp             fp, lr, [SP], #0x10
    // 0xc8f15c: ret
    //     0xc8f15c: ret             
    // 0xc8f160: r0 = 59
    //     0xc8f160: mov             x0, #0x3b
    // 0xc8f164: branchIfSmi(r1, 0xc8f170)
    //     0xc8f164: tbz             w1, #0, #0xc8f170
    // 0xc8f168: r0 = LoadClassIdInstr(r1)
    //     0xc8f168: ldur            x0, [x1, #-1]
    //     0xc8f16c: ubfx            x0, x0, #0xc, #0x14
    // 0xc8f170: SaveReg r1
    //     0xc8f170: str             x1, [SP, #-8]!
    // 0xc8f174: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8f174: mov             x17, #0x57c5
    //     0xc8f178: add             lr, x0, x17
    //     0xc8f17c: ldr             lr, [x21, lr, lsl #3]
    //     0xc8f180: blr             lr
    // 0xc8f184: add             SP, SP, #8
    // 0xc8f188: r1 = LoadClassIdInstr(r0)
    //     0xc8f188: ldur            x1, [x0, #-1]
    //     0xc8f18c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8f190: r16 = SwitchThemeData
    //     0xc8f190: add             x16, PP, #0xe, lsl #12  ; [pp+0xe118] Type: SwitchThemeData
    //     0xc8f194: ldr             x16, [x16, #0x118]
    // 0xc8f198: stp             x16, x0, [SP, #-0x10]!
    // 0xc8f19c: mov             x0, x1
    // 0xc8f1a0: mov             lr, x0
    // 0xc8f1a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f1a8: blr             lr
    // 0xc8f1ac: add             SP, SP, #0x10
    // 0xc8f1b0: tbz             w0, #4, #0xc8f1c4
    // 0xc8f1b4: r0 = false
    //     0xc8f1b4: add             x0, NULL, #0x30  ; false
    // 0xc8f1b8: LeaveFrame
    //     0xc8f1b8: mov             SP, fp
    //     0xc8f1bc: ldp             fp, lr, [SP], #0x10
    // 0xc8f1c0: ret
    //     0xc8f1c0: ret             
    // 0xc8f1c4: ldr             x0, [fp, #0x10]
    // 0xc8f1c8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8f1c8: mov             x1, #0x76
    //     0xc8f1cc: tbz             w0, #0, #0xc8f1dc
    //     0xc8f1d0: ldur            x1, [x0, #-1]
    //     0xc8f1d4: ubfx            x1, x1, #0xc, #0x14
    //     0xc8f1d8: lsl             x1, x1, #1
    // 0xc8f1dc: r17 = 5450
    //     0xc8f1dc: mov             x17, #0x154a
    // 0xc8f1e0: cmp             w1, w17
    // 0xc8f1e4: b.ne            #0xc8f270
    // 0xc8f1e8: ldr             x1, [fp, #0x18]
    // 0xc8f1ec: LoadField: r2 = r0->field_7
    //     0xc8f1ec: ldur            w2, [x0, #7]
    // 0xc8f1f0: DecompressPointer r2
    //     0xc8f1f0: add             x2, x2, HEAP, lsl #32
    // 0xc8f1f4: LoadField: r3 = r1->field_7
    //     0xc8f1f4: ldur            w3, [x1, #7]
    // 0xc8f1f8: DecompressPointer r3
    //     0xc8f1f8: add             x3, x3, HEAP, lsl #32
    // 0xc8f1fc: cmp             w2, w3
    // 0xc8f200: b.ne            #0xc8f270
    // 0xc8f204: LoadField: r2 = r0->field_b
    //     0xc8f204: ldur            w2, [x0, #0xb]
    // 0xc8f208: DecompressPointer r2
    //     0xc8f208: add             x2, x2, HEAP, lsl #32
    // 0xc8f20c: LoadField: r3 = r1->field_b
    //     0xc8f20c: ldur            w3, [x1, #0xb]
    // 0xc8f210: DecompressPointer r3
    //     0xc8f210: add             x3, x3, HEAP, lsl #32
    // 0xc8f214: cmp             w2, w3
    // 0xc8f218: b.ne            #0xc8f270
    // 0xc8f21c: LoadField: r2 = r0->field_17
    //     0xc8f21c: ldur            w2, [x0, #0x17]
    // 0xc8f220: DecompressPointer r2
    //     0xc8f220: add             x2, x2, HEAP, lsl #32
    // 0xc8f224: LoadField: r3 = r1->field_17
    //     0xc8f224: ldur            w3, [x1, #0x17]
    // 0xc8f228: DecompressPointer r3
    //     0xc8f228: add             x3, x3, HEAP, lsl #32
    // 0xc8f22c: cmp             w2, w3
    // 0xc8f230: b.ne            #0xc8f270
    // 0xc8f234: LoadField: r2 = r0->field_1b
    //     0xc8f234: ldur            w2, [x0, #0x1b]
    // 0xc8f238: DecompressPointer r2
    //     0xc8f238: add             x2, x2, HEAP, lsl #32
    // 0xc8f23c: LoadField: r0 = r1->field_1b
    //     0xc8f23c: ldur            w0, [x1, #0x1b]
    // 0xc8f240: DecompressPointer r0
    //     0xc8f240: add             x0, x0, HEAP, lsl #32
    // 0xc8f244: r1 = LoadClassIdInstr(r2)
    //     0xc8f244: ldur            x1, [x2, #-1]
    //     0xc8f248: ubfx            x1, x1, #0xc, #0x14
    // 0xc8f24c: stp             x0, x2, [SP, #-0x10]!
    // 0xc8f250: mov             x0, x1
    // 0xc8f254: mov             lr, x0
    // 0xc8f258: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f25c: blr             lr
    // 0xc8f260: add             SP, SP, #0x10
    // 0xc8f264: tbnz            w0, #4, #0xc8f270
    // 0xc8f268: r0 = true
    //     0xc8f268: add             x0, NULL, #0x20  ; true
    // 0xc8f26c: b               #0xc8f274
    // 0xc8f270: r0 = false
    //     0xc8f270: add             x0, NULL, #0x30  ; false
    // 0xc8f274: LeaveFrame
    //     0xc8f274: mov             SP, fp
    //     0xc8f278: ldp             fp, lr, [SP], #0x10
    // 0xc8f27c: ret
    //     0xc8f27c: ret             
    // 0xc8f280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8f280: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8f284: b               #0xc8f128
  }
}

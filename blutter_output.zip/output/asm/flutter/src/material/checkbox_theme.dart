// lib: , url: package:flutter/src/material/checkbox_theme.dart

// class id: 1049205, size: 0x8
class :: {
}

// class id: 2816, size: 0x2c, field offset: 0x8
//   const constructor, 
class CheckboxThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafe84c, size: 0x37c
    // 0xafe84c: EnterFrame
    //     0xafe84c: stp             fp, lr, [SP, #-0x10]!
    //     0xafe850: mov             fp, SP
    // 0xafe854: AllocStack(0x18)
    //     0xafe854: sub             SP, SP, #0x18
    // 0xafe858: CheckStackOverflow
    //     0xafe858: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafe85c: cmp             SP, x16
    //     0xafe860: b.ls            #0xafebc0
    // 0xafe864: ldr             x0, [fp, #0x10]
    // 0xafe868: r1 = LoadClassIdInstr(r0)
    //     0xafe868: ldur            x1, [x0, #-1]
    //     0xafe86c: ubfx            x1, x1, #0xc, #0x14
    // 0xafe870: lsl             x1, x1, #1
    // 0xafe874: stur            x1, [fp, #-8]
    // 0xafe878: r17 = 5632
    //     0xafe878: mov             x17, #0x1600
    // 0xafe87c: cmp             w1, w17
    // 0xafe880: b.ne            #0xafe898
    // 0xafe884: LoadField: r2 = r0->field_b
    //     0xafe884: ldur            w2, [x0, #0xb]
    // 0xafe888: DecompressPointer r2
    //     0xafe888: add             x2, x2, HEAP, lsl #32
    // 0xafe88c: mov             x0, x1
    // 0xafe890: mov             x1, x2
    // 0xafe894: b               #0xafe930
    // 0xafe898: r17 = 5634
    //     0xafe898: mov             x17, #0x1602
    // 0xafe89c: cmp             w1, w17
    // 0xafe8a0: b.ne            #0xafe8ec
    // 0xafe8a4: r1 = 1
    //     0xafe8a4: mov             x1, #1
    // 0xafe8a8: r0 = AllocateContext()
    //     0xafe8a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xafe8ac: mov             x1, x0
    // 0xafe8b0: ldr             x0, [fp, #0x10]
    // 0xafe8b4: StoreField: r1->field_f = r0
    //     0xafe8b4: stur            w0, [x1, #0xf]
    // 0xafe8b8: mov             x2, x1
    // 0xafe8bc: r1 = Function '<anonymous closure>':.
    //     0xafe8bc: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f0] AnonymousClosure: (0x851d40), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xafe8c0: ldr             x1, [x1, #0x3f0]
    // 0xafe8c4: r0 = AllocateClosure()
    //     0xafe8c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xafe8c8: r16 = <Color>
    //     0xafe8c8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xafe8cc: ldr             x16, [x16, #0x3f8]
    // 0xafe8d0: stp             x0, x16, [SP, #-0x10]!
    // 0xafe8d4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xafe8d4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xafe8d8: r0 = resolveWith()
    //     0xafe8d8: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xafe8dc: add             SP, SP, #0x10
    // 0xafe8e0: mov             x1, x0
    // 0xafe8e4: ldur            x0, [fp, #-8]
    // 0xafe8e8: b               #0xafe930
    // 0xafe8ec: r1 = 1
    //     0xafe8ec: mov             x1, #1
    // 0xafe8f0: r0 = AllocateContext()
    //     0xafe8f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xafe8f4: mov             x1, x0
    // 0xafe8f8: ldr             x0, [fp, #0x10]
    // 0xafe8fc: StoreField: r1->field_f = r0
    //     0xafe8fc: stur            w0, [x1, #0xf]
    // 0xafe900: mov             x2, x1
    // 0xafe904: r1 = Function '<anonymous closure>':.
    //     0xafe904: add             x1, PP, #0xe, lsl #12  ; [pp+0xe400] AnonymousClosure: (0x851c30), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xafe908: ldr             x1, [x1, #0x400]
    // 0xafe90c: r0 = AllocateClosure()
    //     0xafe90c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xafe910: r16 = <Color>
    //     0xafe910: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xafe914: ldr             x16, [x16, #0x3f8]
    // 0xafe918: stp             x0, x16, [SP, #-0x10]!
    // 0xafe91c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xafe91c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xafe920: r0 = resolveWith()
    //     0xafe920: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xafe924: add             SP, SP, #0x10
    // 0xafe928: mov             x1, x0
    // 0xafe92c: ldur            x0, [fp, #-8]
    // 0xafe930: stur            x1, [fp, #-0x10]
    // 0xafe934: r17 = 5632
    //     0xafe934: mov             x17, #0x1600
    // 0xafe938: cmp             w0, w17
    // 0xafe93c: b.ne            #0xafe954
    // 0xafe940: ldr             x2, [fp, #0x10]
    // 0xafe944: LoadField: r3 = r2->field_f
    //     0xafe944: ldur            w3, [x2, #0xf]
    // 0xafe948: DecompressPointer r3
    //     0xafe948: add             x3, x3, HEAP, lsl #32
    // 0xafe94c: mov             x1, x3
    // 0xafe950: b               #0xafe9cc
    // 0xafe954: ldr             x2, [fp, #0x10]
    // 0xafe958: r17 = 5634
    //     0xafe958: mov             x17, #0x1602
    // 0xafe95c: cmp             w0, w17
    // 0xafe960: b.ne            #0xafe9ac
    // 0xafe964: r1 = 1
    //     0xafe964: mov             x1, #1
    // 0xafe968: r0 = AllocateContext()
    //     0xafe968: bl              #0xd68aa4  ; AllocateContextStub
    // 0xafe96c: mov             x1, x0
    // 0xafe970: ldr             x0, [fp, #0x10]
    // 0xafe974: StoreField: r1->field_f = r0
    //     0xafe974: stur            w0, [x1, #0xf]
    // 0xafe978: mov             x2, x1
    // 0xafe97c: r1 = Function '<anonymous closure>':.
    //     0xafe97c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe408] AnonymousClosure: (0x8513d8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xafe980: ldr             x1, [x1, #0x408]
    // 0xafe984: r0 = AllocateClosure()
    //     0xafe984: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xafe988: r16 = <Color>
    //     0xafe988: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xafe98c: ldr             x16, [x16, #0x3f8]
    // 0xafe990: stp             x0, x16, [SP, #-0x10]!
    // 0xafe994: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xafe994: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xafe998: r0 = resolveWith()
    //     0xafe998: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xafe99c: add             SP, SP, #0x10
    // 0xafe9a0: mov             x1, x0
    // 0xafe9a4: ldur            x0, [fp, #-8]
    // 0xafe9a8: b               #0xafe9cc
    // 0xafe9ac: r16 = <Color>
    //     0xafe9ac: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xafe9b0: ldr             x16, [x16, #0x3f8]
    // 0xafe9b4: SaveReg r16
    //     0xafe9b4: str             x16, [SP, #-8]!
    // 0xafe9b8: r4 = const [0x1, 0, 0, 0, null]
    //     0xafe9b8: ldr             x4, [PP, #0x38]  ; [pp+0x38] List(5) [0x1, 0, 0, 0, Null]
    // 0xafe9bc: r0 = all()
    //     0xafe9bc: bl              #0x850ff4  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::all
    // 0xafe9c0: add             SP, SP, #8
    // 0xafe9c4: mov             x1, x0
    // 0xafe9c8: ldur            x0, [fp, #-8]
    // 0xafe9cc: stur            x1, [fp, #-0x18]
    // 0xafe9d0: r17 = 5632
    //     0xafe9d0: mov             x17, #0x1600
    // 0xafe9d4: cmp             w0, w17
    // 0xafe9d8: b.ne            #0xafe9f0
    // 0xafe9dc: ldr             x2, [fp, #0x10]
    // 0xafe9e0: LoadField: r3 = r2->field_13
    //     0xafe9e0: ldur            w3, [x2, #0x13]
    // 0xafe9e4: DecompressPointer r3
    //     0xafe9e4: add             x3, x3, HEAP, lsl #32
    // 0xafe9e8: mov             x1, x3
    // 0xafe9ec: b               #0xafea90
    // 0xafe9f0: ldr             x2, [fp, #0x10]
    // 0xafe9f4: r17 = 5634
    //     0xafe9f4: mov             x17, #0x1602
    // 0xafe9f8: cmp             w0, w17
    // 0xafe9fc: b.ne            #0xafea48
    // 0xafea00: r1 = 1
    //     0xafea00: mov             x1, #1
    // 0xafea04: r0 = AllocateContext()
    //     0xafea04: bl              #0xd68aa4  ; AllocateContextStub
    // 0xafea08: mov             x1, x0
    // 0xafea0c: ldr             x0, [fp, #0x10]
    // 0xafea10: StoreField: r1->field_f = r0
    //     0xafea10: stur            w0, [x1, #0xf]
    // 0xafea14: mov             x2, x1
    // 0xafea18: r1 = Function '<anonymous closure>':.
    //     0xafea18: add             x1, PP, #0xe, lsl #12  ; [pp+0xe410] AnonymousClosure: (0x85171c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xafea1c: ldr             x1, [x1, #0x410]
    // 0xafea20: r0 = AllocateClosure()
    //     0xafea20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xafea24: r16 = <Color>
    //     0xafea24: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xafea28: ldr             x16, [x16, #0x3f8]
    // 0xafea2c: stp             x0, x16, [SP, #-0x10]!
    // 0xafea30: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xafea30: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xafea34: r0 = resolveWith()
    //     0xafea34: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xafea38: add             SP, SP, #0x10
    // 0xafea3c: mov             x1, x0
    // 0xafea40: ldur            x0, [fp, #-8]
    // 0xafea44: b               #0xafea90
    // 0xafea48: mov             x0, x2
    // 0xafea4c: r1 = 1
    //     0xafea4c: mov             x1, #1
    // 0xafea50: r0 = AllocateContext()
    //     0xafea50: bl              #0xd68aa4  ; AllocateContextStub
    // 0xafea54: mov             x1, x0
    // 0xafea58: ldr             x0, [fp, #0x10]
    // 0xafea5c: StoreField: r1->field_f = r0
    //     0xafea5c: stur            w0, [x1, #0xf]
    // 0xafea60: mov             x2, x1
    // 0xafea64: r1 = Function '<anonymous closure>':.
    //     0xafea64: add             x1, PP, #0xe, lsl #12  ; [pp+0xe418] AnonymousClosure: (0x851570), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xafea68: ldr             x1, [x1, #0x418]
    // 0xafea6c: r0 = AllocateClosure()
    //     0xafea6c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xafea70: r16 = <Color?>
    //     0xafea70: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xafea74: ldr             x16, [x16, #0xf68]
    // 0xafea78: stp             x0, x16, [SP, #-0x10]!
    // 0xafea7c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xafea7c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xafea80: r0 = resolveWith()
    //     0xafea80: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xafea84: add             SP, SP, #0x10
    // 0xafea88: mov             x1, x0
    // 0xafea8c: ldur            x0, [fp, #-8]
    // 0xafea90: r17 = 5632
    //     0xafea90: mov             x17, #0x1600
    // 0xafea94: cmp             w0, w17
    // 0xafea98: b.ne            #0xafeaac
    // 0xafea9c: ldr             x2, [fp, #0x10]
    // 0xafeaa0: LoadField: r3 = r2->field_17
    //     0xafeaa0: ldur            w3, [x2, #0x17]
    // 0xafeaa4: DecompressPointer r3
    //     0xafeaa4: add             x3, x3, HEAP, lsl #32
    // 0xafeaa8: b               #0xafead0
    // 0xafeaac: ldr             x2, [fp, #0x10]
    // 0xafeab0: r17 = 5634
    //     0xafeab0: mov             x17, #0x1602
    // 0xafeab4: cmp             w0, w17
    // 0xafeab8: b.ne            #0xafeac8
    // 0xafeabc: r3 = 20.000000
    //     0xafeabc: add             x3, PP, #0xe, lsl #12  ; [pp+0xe420] 20
    //     0xafeac0: ldr             x3, [x3, #0x420]
    // 0xafeac4: b               #0xafead0
    // 0xafeac8: r3 = 20.000000
    //     0xafeac8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe420] 20
    //     0xafeacc: ldr             x3, [x3, #0x420]
    // 0xafead0: r17 = 5632
    //     0xafead0: mov             x17, #0x1600
    // 0xafead4: cmp             w0, w17
    // 0xafead8: b.ne            #0xafeae8
    // 0xafeadc: LoadField: r4 = r2->field_1b
    //     0xafeadc: ldur            w4, [x2, #0x1b]
    // 0xafeae0: DecompressPointer r4
    //     0xafeae0: add             x4, x4, HEAP, lsl #32
    // 0xafeae4: b               #0xafeb20
    // 0xafeae8: r17 = 5634
    //     0xafeae8: mov             x17, #0x1602
    // 0xafeaec: cmp             w0, w17
    // 0xafeaf0: b.ne            #0xafeb0c
    // 0xafeaf4: LoadField: r4 = r2->field_2b
    //     0xafeaf4: ldur            w4, [x2, #0x2b]
    // 0xafeaf8: DecompressPointer r4
    //     0xafeaf8: add             x4, x4, HEAP, lsl #32
    // 0xafeafc: LoadField: r5 = r4->field_17
    //     0xafeafc: ldur            w5, [x4, #0x17]
    // 0xafeb00: DecompressPointer r5
    //     0xafeb00: add             x5, x5, HEAP, lsl #32
    // 0xafeb04: mov             x4, x5
    // 0xafeb08: b               #0xafeb20
    // 0xafeb0c: LoadField: r4 = r2->field_2b
    //     0xafeb0c: ldur            w4, [x2, #0x2b]
    // 0xafeb10: DecompressPointer r4
    //     0xafeb10: add             x4, x4, HEAP, lsl #32
    // 0xafeb14: LoadField: r5 = r4->field_17
    //     0xafeb14: ldur            w5, [x4, #0x17]
    // 0xafeb18: DecompressPointer r5
    //     0xafeb18: add             x5, x5, HEAP, lsl #32
    // 0xafeb1c: mov             x4, x5
    // 0xafeb20: r17 = 5632
    //     0xafeb20: mov             x17, #0x1600
    // 0xafeb24: cmp             w0, w17
    // 0xafeb28: b.ne            #0xafeb38
    // 0xafeb2c: LoadField: r0 = r2->field_1f
    //     0xafeb2c: ldur            w0, [x2, #0x1f]
    // 0xafeb30: DecompressPointer r0
    //     0xafeb30: add             x0, x0, HEAP, lsl #32
    // 0xafeb34: b               #0xafeb70
    // 0xafeb38: r17 = 5634
    //     0xafeb38: mov             x17, #0x1602
    // 0xafeb3c: cmp             w0, w17
    // 0xafeb40: b.ne            #0xafeb5c
    // 0xafeb44: LoadField: r0 = r2->field_2b
    //     0xafeb44: ldur            w0, [x2, #0x2b]
    // 0xafeb48: DecompressPointer r0
    //     0xafeb48: add             x0, x0, HEAP, lsl #32
    // 0xafeb4c: LoadField: r2 = r0->field_2f
    //     0xafeb4c: ldur            w2, [x0, #0x2f]
    // 0xafeb50: DecompressPointer r2
    //     0xafeb50: add             x2, x2, HEAP, lsl #32
    // 0xafeb54: mov             x0, x2
    // 0xafeb58: b               #0xafeb70
    // 0xafeb5c: LoadField: r0 = r2->field_2b
    //     0xafeb5c: ldur            w0, [x2, #0x2b]
    // 0xafeb60: DecompressPointer r0
    //     0xafeb60: add             x0, x0, HEAP, lsl #32
    // 0xafeb64: LoadField: r2 = r0->field_2f
    //     0xafeb64: ldur            w2, [x0, #0x2f]
    // 0xafeb68: DecompressPointer r2
    //     0xafeb68: add             x2, x2, HEAP, lsl #32
    // 0xafeb6c: mov             x0, x2
    // 0xafeb70: ldur            x16, [fp, #-0x10]
    // 0xafeb74: stp             x16, NULL, [SP, #-0x10]!
    // 0xafeb78: ldur            x16, [fp, #-0x18]
    // 0xafeb7c: stp             x1, x16, [SP, #-0x10]!
    // 0xafeb80: stp             x4, x3, [SP, #-0x10]!
    // 0xafeb84: stp             NULL, x0, [SP, #-0x10]!
    // 0xafeb88: SaveReg rNULL
    //     0xafeb88: str             NULL, [SP, #-8]!
    // 0xafeb8c: r4 = const [0, 0x9, 0x9, 0x9, null]
    //     0xafeb8c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe428] List(5) [0, 0x9, 0x9, 0x9, Null]
    //     0xafeb90: ldr             x4, [x4, #0x428]
    // 0xafeb94: r0 = hash()
    //     0xafeb94: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafeb98: add             SP, SP, #0x48
    // 0xafeb9c: mov             x2, x0
    // 0xafeba0: r0 = BoxInt64Instr(r2)
    //     0xafeba0: sbfiz           x0, x2, #1, #0x1f
    //     0xafeba4: cmp             x2, x0, asr #1
    //     0xafeba8: b.eq            #0xafebb4
    //     0xafebac: bl              #0xd69bb8
    //     0xafebb0: stur            x2, [x0, #7]
    // 0xafebb4: LeaveFrame
    //     0xafebb4: mov             SP, fp
    //     0xafebb8: ldp             fp, lr, [SP], #0x10
    // 0xafebbc: ret
    //     0xafebbc: ret             
    // 0xafebc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafebc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafebc4: b               #0xafe864
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf5634, size: 0x1b8
    // 0xbf5634: EnterFrame
    //     0xbf5634: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5638: mov             fp, SP
    // 0xbf563c: AllocStack(0x20)
    //     0xbf563c: sub             SP, SP, #0x20
    // 0xbf5640: CheckStackOverflow
    //     0xbf5640: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf5644: cmp             SP, x16
    //     0xbf5648: b.ls            #0xbf57c4
    // 0xbf564c: ldr             x0, [fp, #0x20]
    // 0xbf5650: LoadField: r1 = r0->field_b
    //     0xbf5650: ldur            w1, [x0, #0xb]
    // 0xbf5654: DecompressPointer r1
    //     0xbf5654: add             x1, x1, HEAP, lsl #32
    // 0xbf5658: ldr             x2, [fp, #0x18]
    // 0xbf565c: LoadField: r3 = r2->field_b
    //     0xbf565c: ldur            w3, [x2, #0xb]
    // 0xbf5660: DecompressPointer r3
    //     0xbf5660: add             x3, x3, HEAP, lsl #32
    // 0xbf5664: r16 = <Color?>
    //     0xbf5664: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf5668: ldr             x16, [x16, #0xf68]
    // 0xbf566c: stp             x1, x16, [SP, #-0x10]!
    // 0xbf5670: SaveReg r3
    //     0xbf5670: str             x3, [SP, #-8]!
    // 0xbf5674: ldr             d0, [fp, #0x10]
    // 0xbf5678: SaveReg d0
    //     0xbf5678: str             d0, [SP, #-8]!
    // 0xbf567c: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf567c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf5680: ldr             x16, [x16, #0xb80]
    // 0xbf5684: SaveReg r16
    //     0xbf5684: str             x16, [SP, #-8]!
    // 0xbf5688: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf5688: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf568c: r0 = lerp()
    //     0xbf568c: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf5690: add             SP, SP, #0x28
    // 0xbf5694: mov             x1, x0
    // 0xbf5698: ldr             x0, [fp, #0x20]
    // 0xbf569c: stur            x1, [fp, #-8]
    // 0xbf56a0: LoadField: r2 = r0->field_f
    //     0xbf56a0: ldur            w2, [x0, #0xf]
    // 0xbf56a4: DecompressPointer r2
    //     0xbf56a4: add             x2, x2, HEAP, lsl #32
    // 0xbf56a8: ldr             x3, [fp, #0x18]
    // 0xbf56ac: LoadField: r4 = r3->field_f
    //     0xbf56ac: ldur            w4, [x3, #0xf]
    // 0xbf56b0: DecompressPointer r4
    //     0xbf56b0: add             x4, x4, HEAP, lsl #32
    // 0xbf56b4: r16 = <Color?>
    //     0xbf56b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf56b8: ldr             x16, [x16, #0xf68]
    // 0xbf56bc: stp             x2, x16, [SP, #-0x10]!
    // 0xbf56c0: SaveReg r4
    //     0xbf56c0: str             x4, [SP, #-8]!
    // 0xbf56c4: ldr             d0, [fp, #0x10]
    // 0xbf56c8: SaveReg d0
    //     0xbf56c8: str             d0, [SP, #-8]!
    // 0xbf56cc: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf56cc: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf56d0: ldr             x16, [x16, #0xb80]
    // 0xbf56d4: SaveReg r16
    //     0xbf56d4: str             x16, [SP, #-8]!
    // 0xbf56d8: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf56d8: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf56dc: r0 = lerp()
    //     0xbf56dc: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf56e0: add             SP, SP, #0x28
    // 0xbf56e4: mov             x1, x0
    // 0xbf56e8: ldr             x0, [fp, #0x20]
    // 0xbf56ec: stur            x1, [fp, #-0x10]
    // 0xbf56f0: LoadField: r2 = r0->field_13
    //     0xbf56f0: ldur            w2, [x0, #0x13]
    // 0xbf56f4: DecompressPointer r2
    //     0xbf56f4: add             x2, x2, HEAP, lsl #32
    // 0xbf56f8: ldr             x3, [fp, #0x18]
    // 0xbf56fc: LoadField: r4 = r3->field_13
    //     0xbf56fc: ldur            w4, [x3, #0x13]
    // 0xbf5700: DecompressPointer r4
    //     0xbf5700: add             x4, x4, HEAP, lsl #32
    // 0xbf5704: r16 = <Color?>
    //     0xbf5704: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf5708: ldr             x16, [x16, #0xf68]
    // 0xbf570c: stp             x2, x16, [SP, #-0x10]!
    // 0xbf5710: SaveReg r4
    //     0xbf5710: str             x4, [SP, #-8]!
    // 0xbf5714: ldr             d0, [fp, #0x10]
    // 0xbf5718: SaveReg d0
    //     0xbf5718: str             d0, [SP, #-8]!
    // 0xbf571c: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf571c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf5720: ldr             x16, [x16, #0xb80]
    // 0xbf5724: SaveReg r16
    //     0xbf5724: str             x16, [SP, #-8]!
    // 0xbf5728: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf5728: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf572c: r0 = lerp()
    //     0xbf572c: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf5730: add             SP, SP, #0x28
    // 0xbf5734: mov             x1, x0
    // 0xbf5738: ldr             x0, [fp, #0x20]
    // 0xbf573c: stur            x1, [fp, #-0x18]
    // 0xbf5740: LoadField: r2 = r0->field_17
    //     0xbf5740: ldur            w2, [x0, #0x17]
    // 0xbf5744: DecompressPointer r2
    //     0xbf5744: add             x2, x2, HEAP, lsl #32
    // 0xbf5748: ldr             x0, [fp, #0x18]
    // 0xbf574c: LoadField: r3 = r0->field_17
    //     0xbf574c: ldur            w3, [x0, #0x17]
    // 0xbf5750: DecompressPointer r3
    //     0xbf5750: add             x3, x3, HEAP, lsl #32
    // 0xbf5754: ldr             d0, [fp, #0x10]
    // 0xbf5758: r0 = inline_Allocate_Double()
    //     0xbf5758: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbf575c: add             x0, x0, #0x10
    //     0xbf5760: cmp             x4, x0
    //     0xbf5764: b.ls            #0xbf57cc
    //     0xbf5768: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf576c: sub             x0, x0, #0xf
    //     0xbf5770: mov             x4, #0xd108
    //     0xbf5774: movk            x4, #3, lsl #16
    //     0xbf5778: stur            x4, [x0, #-1]
    // 0xbf577c: StoreField: r0->field_7 = d0
    //     0xbf577c: stur            d0, [x0, #7]
    // 0xbf5780: stp             x3, x2, [SP, #-0x10]!
    // 0xbf5784: SaveReg r0
    //     0xbf5784: str             x0, [SP, #-8]!
    // 0xbf5788: r0 = lerpDouble()
    //     0xbf5788: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf578c: add             SP, SP, #0x18
    // 0xbf5790: stur            x0, [fp, #-0x20]
    // 0xbf5794: r0 = CheckboxThemeData()
    //     0xbf5794: bl              #0xbf57ec  ; AllocateCheckboxThemeDataStub -> CheckboxThemeData (size=0x2c)
    // 0xbf5798: ldur            x1, [fp, #-8]
    // 0xbf579c: StoreField: r0->field_b = r1
    //     0xbf579c: stur            w1, [x0, #0xb]
    // 0xbf57a0: ldur            x1, [fp, #-0x10]
    // 0xbf57a4: StoreField: r0->field_f = r1
    //     0xbf57a4: stur            w1, [x0, #0xf]
    // 0xbf57a8: ldur            x1, [fp, #-0x18]
    // 0xbf57ac: StoreField: r0->field_13 = r1
    //     0xbf57ac: stur            w1, [x0, #0x13]
    // 0xbf57b0: ldur            x1, [fp, #-0x20]
    // 0xbf57b4: StoreField: r0->field_17 = r1
    //     0xbf57b4: stur            w1, [x0, #0x17]
    // 0xbf57b8: LeaveFrame
    //     0xbf57b8: mov             SP, fp
    //     0xbf57bc: ldp             fp, lr, [SP], #0x10
    // 0xbf57c0: ret
    //     0xbf57c0: ret             
    // 0xbf57c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf57c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf57c8: b               #0xbf564c
    // 0xbf57cc: SaveReg d0
    //     0xbf57cc: str             q0, [SP, #-0x10]!
    // 0xbf57d0: stp             x2, x3, [SP, #-0x10]!
    // 0xbf57d4: SaveReg r1
    //     0xbf57d4: str             x1, [SP, #-8]!
    // 0xbf57d8: r0 = AllocateDouble()
    //     0xbf57d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf57dc: RestoreReg r1
    //     0xbf57dc: ldr             x1, [SP], #8
    // 0xbf57e0: ldp             x2, x3, [SP], #0x10
    // 0xbf57e4: RestoreReg d0
    //     0xbf57e4: ldr             q0, [SP], #0x10
    // 0xbf57e8: b               #0xbf577c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc84ecc, size: 0x7ec
    // 0xc84ecc: EnterFrame
    //     0xc84ecc: stp             fp, lr, [SP, #-0x10]!
    //     0xc84ed0: mov             fp, SP
    // 0xc84ed4: AllocStack(0x18)
    //     0xc84ed4: sub             SP, SP, #0x18
    // 0xc84ed8: CheckStackOverflow
    //     0xc84ed8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc84edc: cmp             SP, x16
    //     0xc84ee0: b.ls            #0xc856b0
    // 0xc84ee4: ldr             x1, [fp, #0x10]
    // 0xc84ee8: cmp             w1, NULL
    // 0xc84eec: b.ne            #0xc84f00
    // 0xc84ef0: r0 = false
    //     0xc84ef0: add             x0, NULL, #0x30  ; false
    // 0xc84ef4: LeaveFrame
    //     0xc84ef4: mov             SP, fp
    //     0xc84ef8: ldp             fp, lr, [SP], #0x10
    // 0xc84efc: ret
    //     0xc84efc: ret             
    // 0xc84f00: ldr             x2, [fp, #0x18]
    // 0xc84f04: cmp             w2, w1
    // 0xc84f08: b.ne            #0xc84f1c
    // 0xc84f0c: r0 = true
    //     0xc84f0c: add             x0, NULL, #0x20  ; true
    // 0xc84f10: LeaveFrame
    //     0xc84f10: mov             SP, fp
    //     0xc84f14: ldp             fp, lr, [SP], #0x10
    // 0xc84f18: ret
    //     0xc84f18: ret             
    // 0xc84f1c: r0 = 59
    //     0xc84f1c: mov             x0, #0x3b
    // 0xc84f20: branchIfSmi(r1, 0xc84f2c)
    //     0xc84f20: tbz             w1, #0, #0xc84f2c
    // 0xc84f24: r0 = LoadClassIdInstr(r1)
    //     0xc84f24: ldur            x0, [x1, #-1]
    //     0xc84f28: ubfx            x0, x0, #0xc, #0x14
    // 0xc84f2c: SaveReg r1
    //     0xc84f2c: str             x1, [SP, #-8]!
    // 0xc84f30: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc84f30: mov             x17, #0x57c5
    //     0xc84f34: add             lr, x0, x17
    //     0xc84f38: ldr             lr, [x21, lr, lsl #3]
    //     0xc84f3c: blr             lr
    // 0xc84f40: add             SP, SP, #8
    // 0xc84f44: stur            x0, [fp, #-8]
    // 0xc84f48: ldr             x16, [fp, #0x18]
    // 0xc84f4c: SaveReg r16
    //     0xc84f4c: str             x16, [SP, #-8]!
    // 0xc84f50: r0 = runtimeType()
    //     0xc84f50: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc84f54: add             SP, SP, #8
    // 0xc84f58: mov             x1, x0
    // 0xc84f5c: ldur            x0, [fp, #-8]
    // 0xc84f60: r2 = LoadClassIdInstr(r0)
    //     0xc84f60: ldur            x2, [x0, #-1]
    //     0xc84f64: ubfx            x2, x2, #0xc, #0x14
    // 0xc84f68: stp             x1, x0, [SP, #-0x10]!
    // 0xc84f6c: mov             x0, x2
    // 0xc84f70: mov             lr, x0
    // 0xc84f74: ldr             lr, [x21, lr, lsl #3]
    // 0xc84f78: blr             lr
    // 0xc84f7c: add             SP, SP, #0x10
    // 0xc84f80: tbz             w0, #4, #0xc84f94
    // 0xc84f84: r0 = false
    //     0xc84f84: add             x0, NULL, #0x30  ; false
    // 0xc84f88: LeaveFrame
    //     0xc84f88: mov             SP, fp
    //     0xc84f8c: ldp             fp, lr, [SP], #0x10
    // 0xc84f90: ret
    //     0xc84f90: ret             
    // 0xc84f94: ldr             x0, [fp, #0x10]
    // 0xc84f98: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc84f98: mov             x1, #0x76
    //     0xc84f9c: tbz             w0, #0, #0xc84fac
    //     0xc84fa0: ldur            x1, [x0, #-1]
    //     0xc84fa4: ubfx            x1, x1, #0xc, #0x14
    //     0xc84fa8: lsl             x1, x1, #1
    // 0xc84fac: stur            x1, [fp, #-8]
    // 0xc84fb0: r2 = LoadInt32Instr(r1)
    //     0xc84fb0: sbfx            x2, x1, #1, #0x1f
    // 0xc84fb4: cmp             x2, #0xb00
    // 0xc84fb8: b.lt            #0xc856a0
    // 0xc84fbc: cmp             x2, #0xb02
    // 0xc84fc0: b.gt            #0xc856a0
    // 0xc84fc4: r17 = 5632
    //     0xc84fc4: mov             x17, #0x1600
    // 0xc84fc8: cmp             w1, w17
    // 0xc84fcc: b.ne            #0xc84fe0
    // 0xc84fd0: LoadField: r2 = r0->field_b
    //     0xc84fd0: ldur            w2, [x0, #0xb]
    // 0xc84fd4: DecompressPointer r2
    //     0xc84fd4: add             x2, x2, HEAP, lsl #32
    // 0xc84fd8: mov             x1, x2
    // 0xc84fdc: b               #0xc85070
    // 0xc84fe0: r17 = 5634
    //     0xc84fe0: mov             x17, #0x1602
    // 0xc84fe4: cmp             w1, w17
    // 0xc84fe8: b.ne            #0xc85030
    // 0xc84fec: r1 = 1
    //     0xc84fec: mov             x1, #1
    // 0xc84ff0: r0 = AllocateContext()
    //     0xc84ff0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc84ff4: mov             x1, x0
    // 0xc84ff8: ldr             x0, [fp, #0x10]
    // 0xc84ffc: StoreField: r1->field_f = r0
    //     0xc84ffc: stur            w0, [x1, #0xf]
    // 0xc85000: mov             x2, x1
    // 0xc85004: r1 = Function '<anonymous closure>':.
    //     0xc85004: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f0] AnonymousClosure: (0x851d40), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xc85008: ldr             x1, [x1, #0x3f0]
    // 0xc8500c: r0 = AllocateClosure()
    //     0xc8500c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc85010: r16 = <Color>
    //     0xc85010: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc85014: ldr             x16, [x16, #0x3f8]
    // 0xc85018: stp             x0, x16, [SP, #-0x10]!
    // 0xc8501c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc8501c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc85020: r0 = resolveWith()
    //     0xc85020: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc85024: add             SP, SP, #0x10
    // 0xc85028: mov             x1, x0
    // 0xc8502c: b               #0xc85070
    // 0xc85030: r1 = 1
    //     0xc85030: mov             x1, #1
    // 0xc85034: r0 = AllocateContext()
    //     0xc85034: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc85038: mov             x1, x0
    // 0xc8503c: ldr             x0, [fp, #0x10]
    // 0xc85040: StoreField: r1->field_f = r0
    //     0xc85040: stur            w0, [x1, #0xf]
    // 0xc85044: mov             x2, x1
    // 0xc85048: r1 = Function '<anonymous closure>':.
    //     0xc85048: add             x1, PP, #0xe, lsl #12  ; [pp+0xe400] AnonymousClosure: (0x851c30), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xc8504c: ldr             x1, [x1, #0x400]
    // 0xc85050: r0 = AllocateClosure()
    //     0xc85050: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc85054: r16 = <Color>
    //     0xc85054: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc85058: ldr             x16, [x16, #0x3f8]
    // 0xc8505c: stp             x0, x16, [SP, #-0x10]!
    // 0xc85060: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc85060: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc85064: r0 = resolveWith()
    //     0xc85064: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc85068: add             SP, SP, #0x10
    // 0xc8506c: mov             x1, x0
    // 0xc85070: ldr             x0, [fp, #0x18]
    // 0xc85074: stur            x1, [fp, #-0x18]
    // 0xc85078: r2 = LoadClassIdInstr(r0)
    //     0xc85078: ldur            x2, [x0, #-1]
    //     0xc8507c: ubfx            x2, x2, #0xc, #0x14
    // 0xc85080: lsl             x2, x2, #1
    // 0xc85084: stur            x2, [fp, #-0x10]
    // 0xc85088: r17 = 5632
    //     0xc85088: mov             x17, #0x1600
    // 0xc8508c: cmp             w2, w17
    // 0xc85090: b.ne            #0xc850a8
    // 0xc85094: LoadField: r3 = r0->field_b
    //     0xc85094: ldur            w3, [x0, #0xb]
    // 0xc85098: DecompressPointer r3
    //     0xc85098: add             x3, x3, HEAP, lsl #32
    // 0xc8509c: mov             x0, x1
    // 0xc850a0: mov             x1, x3
    // 0xc850a4: b               #0xc85140
    // 0xc850a8: r17 = 5634
    //     0xc850a8: mov             x17, #0x1602
    // 0xc850ac: cmp             w2, w17
    // 0xc850b0: b.ne            #0xc850fc
    // 0xc850b4: r1 = 1
    //     0xc850b4: mov             x1, #1
    // 0xc850b8: r0 = AllocateContext()
    //     0xc850b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc850bc: mov             x1, x0
    // 0xc850c0: ldr             x0, [fp, #0x18]
    // 0xc850c4: StoreField: r1->field_f = r0
    //     0xc850c4: stur            w0, [x1, #0xf]
    // 0xc850c8: mov             x2, x1
    // 0xc850cc: r1 = Function '<anonymous closure>':.
    //     0xc850cc: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f0] AnonymousClosure: (0x851d40), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xc850d0: ldr             x1, [x1, #0x3f0]
    // 0xc850d4: r0 = AllocateClosure()
    //     0xc850d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc850d8: r16 = <Color>
    //     0xc850d8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc850dc: ldr             x16, [x16, #0x3f8]
    // 0xc850e0: stp             x0, x16, [SP, #-0x10]!
    // 0xc850e4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc850e4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc850e8: r0 = resolveWith()
    //     0xc850e8: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc850ec: add             SP, SP, #0x10
    // 0xc850f0: mov             x1, x0
    // 0xc850f4: ldur            x0, [fp, #-0x18]
    // 0xc850f8: b               #0xc85140
    // 0xc850fc: r1 = 1
    //     0xc850fc: mov             x1, #1
    // 0xc85100: r0 = AllocateContext()
    //     0xc85100: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc85104: mov             x1, x0
    // 0xc85108: ldr             x0, [fp, #0x18]
    // 0xc8510c: StoreField: r1->field_f = r0
    //     0xc8510c: stur            w0, [x1, #0xf]
    // 0xc85110: mov             x2, x1
    // 0xc85114: r1 = Function '<anonymous closure>':.
    //     0xc85114: add             x1, PP, #0xe, lsl #12  ; [pp+0xe400] AnonymousClosure: (0x851c30), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xc85118: ldr             x1, [x1, #0x400]
    // 0xc8511c: r0 = AllocateClosure()
    //     0xc8511c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc85120: r16 = <Color>
    //     0xc85120: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc85124: ldr             x16, [x16, #0x3f8]
    // 0xc85128: stp             x0, x16, [SP, #-0x10]!
    // 0xc8512c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc8512c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc85130: r0 = resolveWith()
    //     0xc85130: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc85134: add             SP, SP, #0x10
    // 0xc85138: mov             x1, x0
    // 0xc8513c: ldur            x0, [fp, #-0x18]
    // 0xc85140: r2 = LoadClassIdInstr(r0)
    //     0xc85140: ldur            x2, [x0, #-1]
    //     0xc85144: ubfx            x2, x2, #0xc, #0x14
    // 0xc85148: stp             x1, x0, [SP, #-0x10]!
    // 0xc8514c: mov             x0, x2
    // 0xc85150: mov             lr, x0
    // 0xc85154: ldr             lr, [x21, lr, lsl #3]
    // 0xc85158: blr             lr
    // 0xc8515c: add             SP, SP, #0x10
    // 0xc85160: tbnz            w0, #4, #0xc856a0
    // 0xc85164: ldur            x0, [fp, #-8]
    // 0xc85168: r17 = 5632
    //     0xc85168: mov             x17, #0x1600
    // 0xc8516c: cmp             w0, w17
    // 0xc85170: b.ne            #0xc85188
    // 0xc85174: ldr             x1, [fp, #0x10]
    // 0xc85178: LoadField: r2 = r1->field_f
    //     0xc85178: ldur            w2, [x1, #0xf]
    // 0xc8517c: DecompressPointer r2
    //     0xc8517c: add             x2, x2, HEAP, lsl #32
    // 0xc85180: mov             x1, x2
    // 0xc85184: b               #0xc851f8
    // 0xc85188: ldr             x1, [fp, #0x10]
    // 0xc8518c: r17 = 5634
    //     0xc8518c: mov             x17, #0x1602
    // 0xc85190: cmp             w0, w17
    // 0xc85194: b.ne            #0xc851dc
    // 0xc85198: r1 = 1
    //     0xc85198: mov             x1, #1
    // 0xc8519c: r0 = AllocateContext()
    //     0xc8519c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc851a0: mov             x1, x0
    // 0xc851a4: ldr             x0, [fp, #0x10]
    // 0xc851a8: StoreField: r1->field_f = r0
    //     0xc851a8: stur            w0, [x1, #0xf]
    // 0xc851ac: mov             x2, x1
    // 0xc851b0: r1 = Function '<anonymous closure>':.
    //     0xc851b0: add             x1, PP, #0xe, lsl #12  ; [pp+0xe408] AnonymousClosure: (0x8513d8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xc851b4: ldr             x1, [x1, #0x408]
    // 0xc851b8: r0 = AllocateClosure()
    //     0xc851b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc851bc: r16 = <Color>
    //     0xc851bc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc851c0: ldr             x16, [x16, #0x3f8]
    // 0xc851c4: stp             x0, x16, [SP, #-0x10]!
    // 0xc851c8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc851c8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc851cc: r0 = resolveWith()
    //     0xc851cc: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc851d0: add             SP, SP, #0x10
    // 0xc851d4: mov             x1, x0
    // 0xc851d8: b               #0xc851f8
    // 0xc851dc: r16 = <Color>
    //     0xc851dc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc851e0: ldr             x16, [x16, #0x3f8]
    // 0xc851e4: SaveReg r16
    //     0xc851e4: str             x16, [SP, #-8]!
    // 0xc851e8: r4 = const [0x1, 0, 0, 0, null]
    //     0xc851e8: ldr             x4, [PP, #0x38]  ; [pp+0x38] List(5) [0x1, 0, 0, 0, Null]
    // 0xc851ec: r0 = all()
    //     0xc851ec: bl              #0x850ff4  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::all
    // 0xc851f0: add             SP, SP, #8
    // 0xc851f4: mov             x1, x0
    // 0xc851f8: ldur            x0, [fp, #-0x10]
    // 0xc851fc: stur            x1, [fp, #-0x18]
    // 0xc85200: r17 = 5632
    //     0xc85200: mov             x17, #0x1600
    // 0xc85204: cmp             w0, w17
    // 0xc85208: b.ne            #0xc85224
    // 0xc8520c: ldr             x2, [fp, #0x18]
    // 0xc85210: LoadField: r3 = r2->field_f
    //     0xc85210: ldur            w3, [x2, #0xf]
    // 0xc85214: DecompressPointer r3
    //     0xc85214: add             x3, x3, HEAP, lsl #32
    // 0xc85218: mov             x0, x1
    // 0xc8521c: mov             x1, x3
    // 0xc85220: b               #0xc8529c
    // 0xc85224: ldr             x2, [fp, #0x18]
    // 0xc85228: r17 = 5634
    //     0xc85228: mov             x17, #0x1602
    // 0xc8522c: cmp             w0, w17
    // 0xc85230: b.ne            #0xc8527c
    // 0xc85234: r1 = 1
    //     0xc85234: mov             x1, #1
    // 0xc85238: r0 = AllocateContext()
    //     0xc85238: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc8523c: mov             x1, x0
    // 0xc85240: ldr             x0, [fp, #0x18]
    // 0xc85244: StoreField: r1->field_f = r0
    //     0xc85244: stur            w0, [x1, #0xf]
    // 0xc85248: mov             x2, x1
    // 0xc8524c: r1 = Function '<anonymous closure>':.
    //     0xc8524c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe408] AnonymousClosure: (0x8513d8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xc85250: ldr             x1, [x1, #0x408]
    // 0xc85254: r0 = AllocateClosure()
    //     0xc85254: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc85258: r16 = <Color>
    //     0xc85258: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc8525c: ldr             x16, [x16, #0x3f8]
    // 0xc85260: stp             x0, x16, [SP, #-0x10]!
    // 0xc85264: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc85264: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc85268: r0 = resolveWith()
    //     0xc85268: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc8526c: add             SP, SP, #0x10
    // 0xc85270: mov             x1, x0
    // 0xc85274: ldur            x0, [fp, #-0x18]
    // 0xc85278: b               #0xc8529c
    // 0xc8527c: r16 = <Color>
    //     0xc8527c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc85280: ldr             x16, [x16, #0x3f8]
    // 0xc85284: SaveReg r16
    //     0xc85284: str             x16, [SP, #-8]!
    // 0xc85288: r4 = const [0x1, 0, 0, 0, null]
    //     0xc85288: ldr             x4, [PP, #0x38]  ; [pp+0x38] List(5) [0x1, 0, 0, 0, Null]
    // 0xc8528c: r0 = all()
    //     0xc8528c: bl              #0x850ff4  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::all
    // 0xc85290: add             SP, SP, #8
    // 0xc85294: mov             x1, x0
    // 0xc85298: ldur            x0, [fp, #-0x18]
    // 0xc8529c: r2 = LoadClassIdInstr(r0)
    //     0xc8529c: ldur            x2, [x0, #-1]
    //     0xc852a0: ubfx            x2, x2, #0xc, #0x14
    // 0xc852a4: stp             x1, x0, [SP, #-0x10]!
    // 0xc852a8: mov             x0, x2
    // 0xc852ac: mov             lr, x0
    // 0xc852b0: ldr             lr, [x21, lr, lsl #3]
    // 0xc852b4: blr             lr
    // 0xc852b8: add             SP, SP, #0x10
    // 0xc852bc: tbnz            w0, #4, #0xc856a0
    // 0xc852c0: ldur            x0, [fp, #-8]
    // 0xc852c4: r17 = 5632
    //     0xc852c4: mov             x17, #0x1600
    // 0xc852c8: cmp             w0, w17
    // 0xc852cc: b.ne            #0xc852e4
    // 0xc852d0: ldr             x1, [fp, #0x10]
    // 0xc852d4: LoadField: r2 = r1->field_13
    //     0xc852d4: ldur            w2, [x1, #0x13]
    // 0xc852d8: DecompressPointer r2
    //     0xc852d8: add             x2, x2, HEAP, lsl #32
    // 0xc852dc: mov             x1, x2
    // 0xc852e0: b               #0xc8537c
    // 0xc852e4: ldr             x1, [fp, #0x10]
    // 0xc852e8: r17 = 5634
    //     0xc852e8: mov             x17, #0x1602
    // 0xc852ec: cmp             w0, w17
    // 0xc852f0: b.ne            #0xc85338
    // 0xc852f4: r1 = 1
    //     0xc852f4: mov             x1, #1
    // 0xc852f8: r0 = AllocateContext()
    //     0xc852f8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc852fc: mov             x1, x0
    // 0xc85300: ldr             x0, [fp, #0x10]
    // 0xc85304: StoreField: r1->field_f = r0
    //     0xc85304: stur            w0, [x1, #0xf]
    // 0xc85308: mov             x2, x1
    // 0xc8530c: r1 = Function '<anonymous closure>':.
    //     0xc8530c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe410] AnonymousClosure: (0x85171c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xc85310: ldr             x1, [x1, #0x410]
    // 0xc85314: r0 = AllocateClosure()
    //     0xc85314: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc85318: r16 = <Color>
    //     0xc85318: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc8531c: ldr             x16, [x16, #0x3f8]
    // 0xc85320: stp             x0, x16, [SP, #-0x10]!
    // 0xc85324: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc85324: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc85328: r0 = resolveWith()
    //     0xc85328: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc8532c: add             SP, SP, #0x10
    // 0xc85330: mov             x1, x0
    // 0xc85334: b               #0xc8537c
    // 0xc85338: mov             x0, x1
    // 0xc8533c: r1 = 1
    //     0xc8533c: mov             x1, #1
    // 0xc85340: r0 = AllocateContext()
    //     0xc85340: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc85344: mov             x1, x0
    // 0xc85348: ldr             x0, [fp, #0x10]
    // 0xc8534c: StoreField: r1->field_f = r0
    //     0xc8534c: stur            w0, [x1, #0xf]
    // 0xc85350: mov             x2, x1
    // 0xc85354: r1 = Function '<anonymous closure>':.
    //     0xc85354: add             x1, PP, #0xe, lsl #12  ; [pp+0xe418] AnonymousClosure: (0x851570), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xc85358: ldr             x1, [x1, #0x418]
    // 0xc8535c: r0 = AllocateClosure()
    //     0xc8535c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc85360: r16 = <Color?>
    //     0xc85360: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xc85364: ldr             x16, [x16, #0xf68]
    // 0xc85368: stp             x0, x16, [SP, #-0x10]!
    // 0xc8536c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc8536c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc85370: r0 = resolveWith()
    //     0xc85370: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc85374: add             SP, SP, #0x10
    // 0xc85378: mov             x1, x0
    // 0xc8537c: ldur            x0, [fp, #-0x10]
    // 0xc85380: stur            x1, [fp, #-0x18]
    // 0xc85384: r17 = 5632
    //     0xc85384: mov             x17, #0x1600
    // 0xc85388: cmp             w0, w17
    // 0xc8538c: b.ne            #0xc853a8
    // 0xc85390: ldr             x2, [fp, #0x18]
    // 0xc85394: LoadField: r3 = r2->field_13
    //     0xc85394: ldur            w3, [x2, #0x13]
    // 0xc85398: DecompressPointer r3
    //     0xc85398: add             x3, x3, HEAP, lsl #32
    // 0xc8539c: mov             x0, x1
    // 0xc853a0: mov             x1, x3
    // 0xc853a4: b               #0xc85448
    // 0xc853a8: ldr             x2, [fp, #0x18]
    // 0xc853ac: r17 = 5634
    //     0xc853ac: mov             x17, #0x1602
    // 0xc853b0: cmp             w0, w17
    // 0xc853b4: b.ne            #0xc85400
    // 0xc853b8: r1 = 1
    //     0xc853b8: mov             x1, #1
    // 0xc853bc: r0 = AllocateContext()
    //     0xc853bc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc853c0: mov             x1, x0
    // 0xc853c4: ldr             x0, [fp, #0x18]
    // 0xc853c8: StoreField: r1->field_f = r0
    //     0xc853c8: stur            w0, [x1, #0xf]
    // 0xc853cc: mov             x2, x1
    // 0xc853d0: r1 = Function '<anonymous closure>':.
    //     0xc853d0: add             x1, PP, #0xe, lsl #12  ; [pp+0xe410] AnonymousClosure: (0x85171c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0xc853d4: ldr             x1, [x1, #0x410]
    // 0xc853d8: r0 = AllocateClosure()
    //     0xc853d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc853dc: r16 = <Color>
    //     0xc853dc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc853e0: ldr             x16, [x16, #0x3f8]
    // 0xc853e4: stp             x0, x16, [SP, #-0x10]!
    // 0xc853e8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc853e8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc853ec: r0 = resolveWith()
    //     0xc853ec: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc853f0: add             SP, SP, #0x10
    // 0xc853f4: mov             x1, x0
    // 0xc853f8: ldur            x0, [fp, #-0x18]
    // 0xc853fc: b               #0xc85448
    // 0xc85400: mov             x0, x2
    // 0xc85404: r1 = 1
    //     0xc85404: mov             x1, #1
    // 0xc85408: r0 = AllocateContext()
    //     0xc85408: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc8540c: mov             x1, x0
    // 0xc85410: ldr             x0, [fp, #0x18]
    // 0xc85414: StoreField: r1->field_f = r0
    //     0xc85414: stur            w0, [x1, #0xf]
    // 0xc85418: mov             x2, x1
    // 0xc8541c: r1 = Function '<anonymous closure>':.
    //     0xc8541c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe418] AnonymousClosure: (0x851570), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0xc85420: ldr             x1, [x1, #0x418]
    // 0xc85424: r0 = AllocateClosure()
    //     0xc85424: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc85428: r16 = <Color?>
    //     0xc85428: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xc8542c: ldr             x16, [x16, #0xf68]
    // 0xc85430: stp             x0, x16, [SP, #-0x10]!
    // 0xc85434: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc85434: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc85438: r0 = resolveWith()
    //     0xc85438: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc8543c: add             SP, SP, #0x10
    // 0xc85440: mov             x1, x0
    // 0xc85444: ldur            x0, [fp, #-0x18]
    // 0xc85448: r2 = LoadClassIdInstr(r0)
    //     0xc85448: ldur            x2, [x0, #-1]
    //     0xc8544c: ubfx            x2, x2, #0xc, #0x14
    // 0xc85450: stp             x1, x0, [SP, #-0x10]!
    // 0xc85454: mov             x0, x2
    // 0xc85458: mov             lr, x0
    // 0xc8545c: ldr             lr, [x21, lr, lsl #3]
    // 0xc85460: blr             lr
    // 0xc85464: add             SP, SP, #0x10
    // 0xc85468: tbnz            w0, #4, #0xc856a0
    // 0xc8546c: ldur            x1, [fp, #-8]
    // 0xc85470: r17 = 5632
    //     0xc85470: mov             x17, #0x1600
    // 0xc85474: cmp             w1, w17
    // 0xc85478: b.ne            #0xc8548c
    // 0xc8547c: ldr             x2, [fp, #0x10]
    // 0xc85480: LoadField: r0 = r2->field_17
    //     0xc85480: ldur            w0, [x2, #0x17]
    // 0xc85484: DecompressPointer r0
    //     0xc85484: add             x0, x0, HEAP, lsl #32
    // 0xc85488: b               #0xc854b0
    // 0xc8548c: ldr             x2, [fp, #0x10]
    // 0xc85490: r17 = 5634
    //     0xc85490: mov             x17, #0x1602
    // 0xc85494: cmp             w1, w17
    // 0xc85498: b.ne            #0xc854a8
    // 0xc8549c: r0 = 20.000000
    //     0xc8549c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe420] 20
    //     0xc854a0: ldr             x0, [x0, #0x420]
    // 0xc854a4: b               #0xc854b0
    // 0xc854a8: r0 = 20.000000
    //     0xc854a8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe420] 20
    //     0xc854ac: ldr             x0, [x0, #0x420]
    // 0xc854b0: ldur            x3, [fp, #-0x10]
    // 0xc854b4: r17 = 5632
    //     0xc854b4: mov             x17, #0x1600
    // 0xc854b8: cmp             w3, w17
    // 0xc854bc: b.ne            #0xc854d0
    // 0xc854c0: ldr             x4, [fp, #0x18]
    // 0xc854c4: LoadField: r5 = r4->field_17
    //     0xc854c4: ldur            w5, [x4, #0x17]
    // 0xc854c8: DecompressPointer r5
    //     0xc854c8: add             x5, x5, HEAP, lsl #32
    // 0xc854cc: b               #0xc854f4
    // 0xc854d0: ldr             x4, [fp, #0x18]
    // 0xc854d4: r17 = 5634
    //     0xc854d4: mov             x17, #0x1602
    // 0xc854d8: cmp             w3, w17
    // 0xc854dc: b.ne            #0xc854ec
    // 0xc854e0: r5 = 20.000000
    //     0xc854e0: add             x5, PP, #0xe, lsl #12  ; [pp+0xe420] 20
    //     0xc854e4: ldr             x5, [x5, #0x420]
    // 0xc854e8: b               #0xc854f4
    // 0xc854ec: r5 = 20.000000
    //     0xc854ec: add             x5, PP, #0xe, lsl #12  ; [pp+0xe420] 20
    //     0xc854f0: ldr             x5, [x5, #0x420]
    // 0xc854f4: r6 = LoadClassIdInstr(r0)
    //     0xc854f4: ldur            x6, [x0, #-1]
    //     0xc854f8: ubfx            x6, x6, #0xc, #0x14
    // 0xc854fc: stp             x5, x0, [SP, #-0x10]!
    // 0xc85500: mov             x0, x6
    // 0xc85504: mov             lr, x0
    // 0xc85508: ldr             lr, [x21, lr, lsl #3]
    // 0xc8550c: blr             lr
    // 0xc85510: add             SP, SP, #0x10
    // 0xc85514: tbnz            w0, #4, #0xc856a0
    // 0xc85518: ldur            x0, [fp, #-8]
    // 0xc8551c: r17 = 5632
    //     0xc8551c: mov             x17, #0x1600
    // 0xc85520: cmp             w0, w17
    // 0xc85524: b.ne            #0xc8553c
    // 0xc85528: ldr             x1, [fp, #0x10]
    // 0xc8552c: LoadField: r2 = r1->field_1b
    //     0xc8552c: ldur            w2, [x1, #0x1b]
    // 0xc85530: DecompressPointer r2
    //     0xc85530: add             x2, x2, HEAP, lsl #32
    // 0xc85534: mov             x3, x2
    // 0xc85538: b               #0xc85570
    // 0xc8553c: ldr             x1, [fp, #0x10]
    // 0xc85540: r17 = 5634
    //     0xc85540: mov             x17, #0x1602
    // 0xc85544: cmp             w0, w17
    // 0xc85548: b.ne            #0xc85560
    // 0xc8554c: LoadField: r2 = r1->field_2b
    //     0xc8554c: ldur            w2, [x1, #0x2b]
    // 0xc85550: DecompressPointer r2
    //     0xc85550: add             x2, x2, HEAP, lsl #32
    // 0xc85554: LoadField: r3 = r2->field_17
    //     0xc85554: ldur            w3, [x2, #0x17]
    // 0xc85558: DecompressPointer r3
    //     0xc85558: add             x3, x3, HEAP, lsl #32
    // 0xc8555c: b               #0xc85570
    // 0xc85560: LoadField: r2 = r1->field_2b
    //     0xc85560: ldur            w2, [x1, #0x2b]
    // 0xc85564: DecompressPointer r2
    //     0xc85564: add             x2, x2, HEAP, lsl #32
    // 0xc85568: LoadField: r3 = r2->field_17
    //     0xc85568: ldur            w3, [x2, #0x17]
    // 0xc8556c: DecompressPointer r3
    //     0xc8556c: add             x3, x3, HEAP, lsl #32
    // 0xc85570: ldur            x2, [fp, #-0x10]
    // 0xc85574: r17 = 5632
    //     0xc85574: mov             x17, #0x1600
    // 0xc85578: cmp             w2, w17
    // 0xc8557c: b.ne            #0xc85590
    // 0xc85580: ldr             x4, [fp, #0x18]
    // 0xc85584: LoadField: r5 = r4->field_1b
    //     0xc85584: ldur            w5, [x4, #0x1b]
    // 0xc85588: DecompressPointer r5
    //     0xc85588: add             x5, x5, HEAP, lsl #32
    // 0xc8558c: b               #0xc855cc
    // 0xc85590: ldr             x4, [fp, #0x18]
    // 0xc85594: r17 = 5634
    //     0xc85594: mov             x17, #0x1602
    // 0xc85598: cmp             w2, w17
    // 0xc8559c: b.ne            #0xc855b8
    // 0xc855a0: LoadField: r5 = r4->field_2b
    //     0xc855a0: ldur            w5, [x4, #0x2b]
    // 0xc855a4: DecompressPointer r5
    //     0xc855a4: add             x5, x5, HEAP, lsl #32
    // 0xc855a8: LoadField: r6 = r5->field_17
    //     0xc855a8: ldur            w6, [x5, #0x17]
    // 0xc855ac: DecompressPointer r6
    //     0xc855ac: add             x6, x6, HEAP, lsl #32
    // 0xc855b0: mov             x5, x6
    // 0xc855b4: b               #0xc855cc
    // 0xc855b8: LoadField: r5 = r4->field_2b
    //     0xc855b8: ldur            w5, [x4, #0x2b]
    // 0xc855bc: DecompressPointer r5
    //     0xc855bc: add             x5, x5, HEAP, lsl #32
    // 0xc855c0: LoadField: r6 = r5->field_17
    //     0xc855c0: ldur            w6, [x5, #0x17]
    // 0xc855c4: DecompressPointer r6
    //     0xc855c4: add             x6, x6, HEAP, lsl #32
    // 0xc855c8: mov             x5, x6
    // 0xc855cc: cmp             w3, w5
    // 0xc855d0: b.ne            #0xc856a0
    // 0xc855d4: r17 = 5632
    //     0xc855d4: mov             x17, #0x1600
    // 0xc855d8: cmp             w0, w17
    // 0xc855dc: b.ne            #0xc855ec
    // 0xc855e0: LoadField: r0 = r1->field_1f
    //     0xc855e0: ldur            w0, [x1, #0x1f]
    // 0xc855e4: DecompressPointer r0
    //     0xc855e4: add             x0, x0, HEAP, lsl #32
    // 0xc855e8: b               #0xc85624
    // 0xc855ec: r17 = 5634
    //     0xc855ec: mov             x17, #0x1602
    // 0xc855f0: cmp             w0, w17
    // 0xc855f4: b.ne            #0xc85610
    // 0xc855f8: LoadField: r0 = r1->field_2b
    //     0xc855f8: ldur            w0, [x1, #0x2b]
    // 0xc855fc: DecompressPointer r0
    //     0xc855fc: add             x0, x0, HEAP, lsl #32
    // 0xc85600: LoadField: r1 = r0->field_2f
    //     0xc85600: ldur            w1, [x0, #0x2f]
    // 0xc85604: DecompressPointer r1
    //     0xc85604: add             x1, x1, HEAP, lsl #32
    // 0xc85608: mov             x0, x1
    // 0xc8560c: b               #0xc85624
    // 0xc85610: LoadField: r0 = r1->field_2b
    //     0xc85610: ldur            w0, [x1, #0x2b]
    // 0xc85614: DecompressPointer r0
    //     0xc85614: add             x0, x0, HEAP, lsl #32
    // 0xc85618: LoadField: r1 = r0->field_2f
    //     0xc85618: ldur            w1, [x0, #0x2f]
    // 0xc8561c: DecompressPointer r1
    //     0xc8561c: add             x1, x1, HEAP, lsl #32
    // 0xc85620: mov             x0, x1
    // 0xc85624: r17 = 5632
    //     0xc85624: mov             x17, #0x1600
    // 0xc85628: cmp             w2, w17
    // 0xc8562c: b.ne            #0xc8563c
    // 0xc85630: LoadField: r1 = r4->field_1f
    //     0xc85630: ldur            w1, [x4, #0x1f]
    // 0xc85634: DecompressPointer r1
    //     0xc85634: add             x1, x1, HEAP, lsl #32
    // 0xc85638: b               #0xc85674
    // 0xc8563c: r17 = 5634
    //     0xc8563c: mov             x17, #0x1602
    // 0xc85640: cmp             w2, w17
    // 0xc85644: b.ne            #0xc85660
    // 0xc85648: LoadField: r1 = r4->field_2b
    //     0xc85648: ldur            w1, [x4, #0x2b]
    // 0xc8564c: DecompressPointer r1
    //     0xc8564c: add             x1, x1, HEAP, lsl #32
    // 0xc85650: LoadField: r2 = r1->field_2f
    //     0xc85650: ldur            w2, [x1, #0x2f]
    // 0xc85654: DecompressPointer r2
    //     0xc85654: add             x2, x2, HEAP, lsl #32
    // 0xc85658: mov             x1, x2
    // 0xc8565c: b               #0xc85674
    // 0xc85660: LoadField: r1 = r4->field_2b
    //     0xc85660: ldur            w1, [x4, #0x2b]
    // 0xc85664: DecompressPointer r1
    //     0xc85664: add             x1, x1, HEAP, lsl #32
    // 0xc85668: LoadField: r2 = r1->field_2f
    //     0xc85668: ldur            w2, [x1, #0x2f]
    // 0xc8566c: DecompressPointer r2
    //     0xc8566c: add             x2, x2, HEAP, lsl #32
    // 0xc85670: mov             x1, x2
    // 0xc85674: r2 = LoadClassIdInstr(r0)
    //     0xc85674: ldur            x2, [x0, #-1]
    //     0xc85678: ubfx            x2, x2, #0xc, #0x14
    // 0xc8567c: stp             x1, x0, [SP, #-0x10]!
    // 0xc85680: mov             x0, x2
    // 0xc85684: mov             lr, x0
    // 0xc85688: ldr             lr, [x21, lr, lsl #3]
    // 0xc8568c: blr             lr
    // 0xc85690: add             SP, SP, #0x10
    // 0xc85694: tbnz            w0, #4, #0xc856a0
    // 0xc85698: r0 = true
    //     0xc85698: add             x0, NULL, #0x20  ; true
    // 0xc8569c: b               #0xc856a4
    // 0xc856a0: r0 = false
    //     0xc856a0: add             x0, NULL, #0x30  ; false
    // 0xc856a4: LeaveFrame
    //     0xc856a4: mov             SP, fp
    //     0xc856a8: ldp             fp, lr, [SP], #0x10
    // 0xc856ac: ret
    //     0xc856ac: ret             
    // 0xc856b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc856b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc856b4: b               #0xc84ee4
  }
}

// class id: 3530, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class CheckboxTheme extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0x851208, size: 0x60
    // 0x851208: EnterFrame
    //     0x851208: stp             fp, lr, [SP, #-0x10]!
    //     0x85120c: mov             fp, SP
    // 0x851210: CheckStackOverflow
    //     0x851210: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x851214: cmp             SP, x16
    //     0x851218: b.ls            #0x851260
    // 0x85121c: r16 = <CheckboxTheme>
    //     0x85121c: add             x16, PP, #0x56, lsl #12  ; [pp+0x565e0] TypeArguments: <CheckboxTheme>
    //     0x851220: ldr             x16, [x16, #0x5e0]
    // 0x851224: ldr             lr, [fp, #0x10]
    // 0x851228: stp             lr, x16, [SP, #-0x10]!
    // 0x85122c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x85122c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x851230: r0 = dependOnInheritedWidgetOfExactType()
    //     0x851230: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x851234: add             SP, SP, #0x10
    // 0x851238: ldr             x16, [fp, #0x10]
    // 0x85123c: SaveReg r16
    //     0x85123c: str             x16, [SP, #-8]!
    // 0x851240: r0 = of()
    //     0x851240: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x851244: add             SP, SP, #8
    // 0x851248: LoadField: r1 = r0->field_bf
    //     0x851248: ldur            w1, [x0, #0xbf]
    // 0x85124c: DecompressPointer r1
    //     0x85124c: add             x1, x1, HEAP, lsl #32
    // 0x851250: mov             x0, x1
    // 0x851254: LeaveFrame
    //     0x851254: mov             SP, fp
    //     0x851258: ldp             fp, lr, [SP], #0x10
    // 0x85125c: ret
    //     0x85125c: ret             
    // 0x851260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851260: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851264: b               #0x85121c
  }
}

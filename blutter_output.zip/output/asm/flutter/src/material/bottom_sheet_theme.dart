// lib: , url: package:flutter/src/material/bottom_sheet_theme.dart

// class id: 1049193, size: 0x8
class :: {
}

// class id: 2835, size: 0x2c, field offset: 0x8
//   const constructor, 
class BottomSheetThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafde30, size: 0x150
    // 0xafde30: EnterFrame
    //     0xafde30: stp             fp, lr, [SP, #-0x10]!
    //     0xafde34: mov             fp, SP
    // 0xafde38: AllocStack(0x10)
    //     0xafde38: sub             SP, SP, #0x10
    // 0xafde3c: CheckStackOverflow
    //     0xafde3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafde40: cmp             SP, x16
    //     0xafde44: b.ls            #0xafdf78
    // 0xafde48: ldr             x0, [fp, #0x10]
    // 0xafde4c: r1 = LoadClassIdInstr(r0)
    //     0xafde4c: ldur            x1, [x0, #-1]
    //     0xafde50: ubfx            x1, x1, #0xc, #0x14
    // 0xafde54: lsl             x1, x1, #1
    // 0xafde58: stur            x1, [fp, #-8]
    // 0xafde5c: r17 = 5670
    //     0xafde5c: mov             x17, #0x1626
    // 0xafde60: cmp             w1, w17
    // 0xafde64: b.ne            #0xafde7c
    // 0xafde68: LoadField: r2 = r0->field_7
    //     0xafde68: ldur            w2, [x0, #7]
    // 0xafde6c: DecompressPointer r2
    //     0xafde6c: add             x2, x2, HEAP, lsl #32
    // 0xafde70: mov             x0, x1
    // 0xafde74: mov             x1, x2
    // 0xafde78: b               #0xafdea8
    // 0xafde7c: LoadField: r2 = r0->field_2b
    //     0xafde7c: ldur            w2, [x0, #0x2b]
    // 0xafde80: DecompressPointer r2
    //     0xafde80: add             x2, x2, HEAP, lsl #32
    // 0xafde84: SaveReg r2
    //     0xafde84: str             x2, [SP, #-8]!
    // 0xafde88: r0 = of()
    //     0xafde88: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xafde8c: add             SP, SP, #8
    // 0xafde90: LoadField: r1 = r0->field_3f
    //     0xafde90: ldur            w1, [x0, #0x3f]
    // 0xafde94: DecompressPointer r1
    //     0xafde94: add             x1, x1, HEAP, lsl #32
    // 0xafde98: LoadField: r0 = r1->field_53
    //     0xafde98: ldur            w0, [x1, #0x53]
    // 0xafde9c: DecompressPointer r0
    //     0xafde9c: add             x0, x0, HEAP, lsl #32
    // 0xafdea0: mov             x1, x0
    // 0xafdea4: ldur            x0, [fp, #-8]
    // 0xafdea8: stur            x1, [fp, #-0x10]
    // 0xafdeac: r17 = 5670
    //     0xafdeac: mov             x17, #0x1626
    // 0xafdeb0: cmp             w0, w17
    // 0xafdeb4: b.ne            #0xafdecc
    // 0xafdeb8: ldr             x0, [fp, #0x10]
    // 0xafdebc: LoadField: r2 = r0->field_b
    //     0xafdebc: ldur            w2, [x0, #0xb]
    // 0xafdec0: DecompressPointer r2
    //     0xafdec0: add             x2, x2, HEAP, lsl #32
    // 0xafdec4: mov             x1, x2
    // 0xafdec8: b               #0xafdf0c
    // 0xafdecc: ldr             x0, [fp, #0x10]
    // 0xafded0: LoadField: r2 = r0->field_2b
    //     0xafded0: ldur            w2, [x0, #0x2b]
    // 0xafded4: DecompressPointer r2
    //     0xafded4: add             x2, x2, HEAP, lsl #32
    // 0xafded8: SaveReg r2
    //     0xafded8: str             x2, [SP, #-8]!
    // 0xafdedc: r0 = of()
    //     0xafdedc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xafdee0: add             SP, SP, #8
    // 0xafdee4: LoadField: r1 = r0->field_3f
    //     0xafdee4: ldur            w1, [x0, #0x3f]
    // 0xafdee8: DecompressPointer r1
    //     0xafdee8: add             x1, x1, HEAP, lsl #32
    // 0xafdeec: LoadField: r0 = r1->field_7f
    //     0xafdeec: ldur            w0, [x1, #0x7f]
    // 0xafdef0: DecompressPointer r0
    //     0xafdef0: add             x0, x0, HEAP, lsl #32
    // 0xafdef4: cmp             w0, NULL
    // 0xafdef8: b.ne            #0xafdf04
    // 0xafdefc: LoadField: r0 = r1->field_b
    //     0xafdefc: ldur            w0, [x1, #0xb]
    // 0xafdf00: DecompressPointer r0
    //     0xafdf00: add             x0, x0, HEAP, lsl #32
    // 0xafdf04: mov             x1, x0
    // 0xafdf08: ldr             x0, [fp, #0x10]
    // 0xafdf0c: LoadField: r2 = r0->field_f
    //     0xafdf0c: ldur            w2, [x0, #0xf]
    // 0xafdf10: DecompressPointer r2
    //     0xafdf10: add             x2, x2, HEAP, lsl #32
    // 0xafdf14: LoadField: r3 = r0->field_1b
    //     0xafdf14: ldur            w3, [x0, #0x1b]
    // 0xafdf18: DecompressPointer r3
    //     0xafdf18: add             x3, x3, HEAP, lsl #32
    // 0xafdf1c: LoadField: r4 = r0->field_1f
    //     0xafdf1c: ldur            w4, [x0, #0x1f]
    // 0xafdf20: DecompressPointer r4
    //     0xafdf20: add             x4, x4, HEAP, lsl #32
    // 0xafdf24: LoadField: r5 = r0->field_27
    //     0xafdf24: ldur            w5, [x0, #0x27]
    // 0xafdf28: DecompressPointer r5
    //     0xafdf28: add             x5, x5, HEAP, lsl #32
    // 0xafdf2c: ldur            x16, [fp, #-0x10]
    // 0xafdf30: stp             x1, x16, [SP, #-0x10]!
    // 0xafdf34: stp             NULL, x2, [SP, #-0x10]!
    // 0xafdf38: stp             x3, NULL, [SP, #-0x10]!
    // 0xafdf3c: stp             NULL, x4, [SP, #-0x10]!
    // 0xafdf40: SaveReg r5
    //     0xafdf40: str             x5, [SP, #-8]!
    // 0xafdf44: r4 = const [0, 0x9, 0x9, 0x9, null]
    //     0xafdf44: add             x4, PP, #0xe, lsl #12  ; [pp+0xe428] List(5) [0, 0x9, 0x9, 0x9, Null]
    //     0xafdf48: ldr             x4, [x4, #0x428]
    // 0xafdf4c: r0 = hash()
    //     0xafdf4c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafdf50: add             SP, SP, #0x48
    // 0xafdf54: mov             x2, x0
    // 0xafdf58: r0 = BoxInt64Instr(r2)
    //     0xafdf58: sbfiz           x0, x2, #1, #0x1f
    //     0xafdf5c: cmp             x2, x0, asr #1
    //     0xafdf60: b.eq            #0xafdf6c
    //     0xafdf64: bl              #0xd69bb8
    //     0xafdf68: stur            x2, [x0, #7]
    // 0xafdf6c: LeaveFrame
    //     0xafdf6c: mov             SP, fp
    //     0xafdf70: ldp             fp, lr, [SP], #0x10
    // 0xafdf74: ret
    //     0xafdf74: ret             
    // 0xafdf78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafdf78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafdf7c: b               #0xafde48
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf5a0c, size: 0x1a4
    // 0xbf5a0c: EnterFrame
    //     0xbf5a0c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5a10: mov             fp, SP
    // 0xbf5a14: AllocStack(0x20)
    //     0xbf5a14: sub             SP, SP, #0x20
    // 0xbf5a18: CheckStackOverflow
    //     0xbf5a18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf5a1c: cmp             SP, x16
    //     0xbf5a20: b.ls            #0xbf5b98
    // 0xbf5a24: ldr             d0, [fp, #0x10]
    // 0xbf5a28: r0 = inline_Allocate_Double()
    //     0xbf5a28: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf5a2c: add             x0, x0, #0x10
    //     0xbf5a30: cmp             x1, x0
    //     0xbf5a34: b.ls            #0xbf5ba0
    //     0xbf5a38: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf5a3c: sub             x0, x0, #0xf
    //     0xbf5a40: mov             x1, #0xd108
    //     0xbf5a44: movk            x1, #3, lsl #16
    //     0xbf5a48: stur            x1, [x0, #-1]
    // 0xbf5a4c: StoreField: r0->field_7 = d0
    //     0xbf5a4c: stur            d0, [x0, #7]
    // 0xbf5a50: stur            x0, [fp, #-8]
    // 0xbf5a54: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5a58: SaveReg r0
    //     0xbf5a58: str             x0, [SP, #-8]!
    // 0xbf5a5c: r0 = lerp()
    //     0xbf5a5c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5a60: add             SP, SP, #0x18
    // 0xbf5a64: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5a68: ldur            x16, [fp, #-8]
    // 0xbf5a6c: SaveReg r16
    //     0xbf5a6c: str             x16, [SP, #-8]!
    // 0xbf5a70: r0 = lerp()
    //     0xbf5a70: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5a74: add             SP, SP, #0x18
    // 0xbf5a78: ldr             x0, [fp, #0x20]
    // 0xbf5a7c: LoadField: r1 = r0->field_f
    //     0xbf5a7c: ldur            w1, [x0, #0xf]
    // 0xbf5a80: DecompressPointer r1
    //     0xbf5a80: add             x1, x1, HEAP, lsl #32
    // 0xbf5a84: ldr             x2, [fp, #0x18]
    // 0xbf5a88: LoadField: r3 = r2->field_f
    //     0xbf5a88: ldur            w3, [x2, #0xf]
    // 0xbf5a8c: DecompressPointer r3
    //     0xbf5a8c: add             x3, x3, HEAP, lsl #32
    // 0xbf5a90: stp             x3, x1, [SP, #-0x10]!
    // 0xbf5a94: ldur            x16, [fp, #-8]
    // 0xbf5a98: SaveReg r16
    //     0xbf5a98: str             x16, [SP, #-8]!
    // 0xbf5a9c: r0 = lerpDouble()
    //     0xbf5a9c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5aa0: add             SP, SP, #0x18
    // 0xbf5aa4: stur            x0, [fp, #-0x10]
    // 0xbf5aa8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5aac: ldur            x16, [fp, #-8]
    // 0xbf5ab0: SaveReg r16
    //     0xbf5ab0: str             x16, [SP, #-8]!
    // 0xbf5ab4: r0 = lerp()
    //     0xbf5ab4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5ab8: add             SP, SP, #0x18
    // 0xbf5abc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5ac0: ldur            x16, [fp, #-8]
    // 0xbf5ac4: SaveReg r16
    //     0xbf5ac4: str             x16, [SP, #-8]!
    // 0xbf5ac8: r0 = lerp()
    //     0xbf5ac8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5acc: add             SP, SP, #0x18
    // 0xbf5ad0: ldr             x0, [fp, #0x20]
    // 0xbf5ad4: LoadField: r1 = r0->field_1b
    //     0xbf5ad4: ldur            w1, [x0, #0x1b]
    // 0xbf5ad8: DecompressPointer r1
    //     0xbf5ad8: add             x1, x1, HEAP, lsl #32
    // 0xbf5adc: ldr             x2, [fp, #0x18]
    // 0xbf5ae0: LoadField: r3 = r2->field_1b
    //     0xbf5ae0: ldur            w3, [x2, #0x1b]
    // 0xbf5ae4: DecompressPointer r3
    //     0xbf5ae4: add             x3, x3, HEAP, lsl #32
    // 0xbf5ae8: stp             x3, x1, [SP, #-0x10]!
    // 0xbf5aec: ldur            x16, [fp, #-8]
    // 0xbf5af0: SaveReg r16
    //     0xbf5af0: str             x16, [SP, #-8]!
    // 0xbf5af4: r0 = lerpDouble()
    //     0xbf5af4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5af8: add             SP, SP, #0x18
    // 0xbf5afc: mov             x1, x0
    // 0xbf5b00: ldr             x0, [fp, #0x20]
    // 0xbf5b04: stur            x1, [fp, #-8]
    // 0xbf5b08: LoadField: r2 = r0->field_1f
    //     0xbf5b08: ldur            w2, [x0, #0x1f]
    // 0xbf5b0c: DecompressPointer r2
    //     0xbf5b0c: add             x2, x2, HEAP, lsl #32
    // 0xbf5b10: ldr             x3, [fp, #0x18]
    // 0xbf5b14: LoadField: r4 = r3->field_1f
    //     0xbf5b14: ldur            w4, [x3, #0x1f]
    // 0xbf5b18: DecompressPointer r4
    //     0xbf5b18: add             x4, x4, HEAP, lsl #32
    // 0xbf5b1c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf5b20: ldr             d0, [fp, #0x10]
    // 0xbf5b24: SaveReg d0
    //     0xbf5b24: str             d0, [SP, #-8]!
    // 0xbf5b28: r0 = lerp()
    //     0xbf5b28: bl              #0xbecbbc  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0xbf5b2c: add             SP, SP, #0x18
    // 0xbf5b30: mov             x1, x0
    // 0xbf5b34: ldr             x0, [fp, #0x20]
    // 0xbf5b38: stur            x1, [fp, #-0x18]
    // 0xbf5b3c: LoadField: r2 = r0->field_27
    //     0xbf5b3c: ldur            w2, [x0, #0x27]
    // 0xbf5b40: DecompressPointer r2
    //     0xbf5b40: add             x2, x2, HEAP, lsl #32
    // 0xbf5b44: ldr             x0, [fp, #0x18]
    // 0xbf5b48: LoadField: r3 = r0->field_27
    //     0xbf5b48: ldur            w3, [x0, #0x27]
    // 0xbf5b4c: DecompressPointer r3
    //     0xbf5b4c: add             x3, x3, HEAP, lsl #32
    // 0xbf5b50: stp             x3, x2, [SP, #-0x10]!
    // 0xbf5b54: ldr             d0, [fp, #0x10]
    // 0xbf5b58: SaveReg d0
    //     0xbf5b58: str             d0, [SP, #-8]!
    // 0xbf5b5c: r0 = lerp()
    //     0xbf5b5c: bl              #0xbee9cc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0xbf5b60: add             SP, SP, #0x18
    // 0xbf5b64: stur            x0, [fp, #-0x20]
    // 0xbf5b68: r0 = BottomSheetThemeData()
    //     0xbf5b68: bl              #0xbf5bb0  ; AllocateBottomSheetThemeDataStub -> BottomSheetThemeData (size=0x2c)
    // 0xbf5b6c: ldur            x1, [fp, #-0x10]
    // 0xbf5b70: StoreField: r0->field_f = r1
    //     0xbf5b70: stur            w1, [x0, #0xf]
    // 0xbf5b74: ldur            x1, [fp, #-8]
    // 0xbf5b78: StoreField: r0->field_1b = r1
    //     0xbf5b78: stur            w1, [x0, #0x1b]
    // 0xbf5b7c: ldur            x1, [fp, #-0x18]
    // 0xbf5b80: StoreField: r0->field_1f = r1
    //     0xbf5b80: stur            w1, [x0, #0x1f]
    // 0xbf5b84: ldur            x1, [fp, #-0x20]
    // 0xbf5b88: StoreField: r0->field_27 = r1
    //     0xbf5b88: stur            w1, [x0, #0x27]
    // 0xbf5b8c: LeaveFrame
    //     0xbf5b8c: mov             SP, fp
    //     0xbf5b90: ldp             fp, lr, [SP], #0x10
    // 0xbf5b94: ret
    //     0xbf5b94: ret             
    // 0xbf5b98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5b98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5b9c: b               #0xbf5a24
    // 0xbf5ba0: SaveReg d0
    //     0xbf5ba0: str             q0, [SP, #-0x10]!
    // 0xbf5ba4: r0 = AllocateDouble()
    //     0xbf5ba4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf5ba8: RestoreReg d0
    //     0xbf5ba8: ldr             q0, [SP], #0x10
    // 0xbf5bac: b               #0xbf5a4c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc83960, size: 0x3b4
    // 0xc83960: EnterFrame
    //     0xc83960: stp             fp, lr, [SP, #-0x10]!
    //     0xc83964: mov             fp, SP
    // 0xc83968: AllocStack(0x18)
    //     0xc83968: sub             SP, SP, #0x18
    // 0xc8396c: CheckStackOverflow
    //     0xc8396c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc83970: cmp             SP, x16
    //     0xc83974: b.ls            #0xc83d0c
    // 0xc83978: ldr             x1, [fp, #0x10]
    // 0xc8397c: cmp             w1, NULL
    // 0xc83980: b.ne            #0xc83994
    // 0xc83984: r0 = false
    //     0xc83984: add             x0, NULL, #0x30  ; false
    // 0xc83988: LeaveFrame
    //     0xc83988: mov             SP, fp
    //     0xc8398c: ldp             fp, lr, [SP], #0x10
    // 0xc83990: ret
    //     0xc83990: ret             
    // 0xc83994: ldr             x2, [fp, #0x18]
    // 0xc83998: cmp             w2, w1
    // 0xc8399c: b.ne            #0xc839b0
    // 0xc839a0: r0 = true
    //     0xc839a0: add             x0, NULL, #0x20  ; true
    // 0xc839a4: LeaveFrame
    //     0xc839a4: mov             SP, fp
    //     0xc839a8: ldp             fp, lr, [SP], #0x10
    // 0xc839ac: ret
    //     0xc839ac: ret             
    // 0xc839b0: r0 = 59
    //     0xc839b0: mov             x0, #0x3b
    // 0xc839b4: branchIfSmi(r1, 0xc839c0)
    //     0xc839b4: tbz             w1, #0, #0xc839c0
    // 0xc839b8: r0 = LoadClassIdInstr(r1)
    //     0xc839b8: ldur            x0, [x1, #-1]
    //     0xc839bc: ubfx            x0, x0, #0xc, #0x14
    // 0xc839c0: SaveReg r1
    //     0xc839c0: str             x1, [SP, #-8]!
    // 0xc839c4: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc839c4: mov             x17, #0x57c5
    //     0xc839c8: add             lr, x0, x17
    //     0xc839cc: ldr             lr, [x21, lr, lsl #3]
    //     0xc839d0: blr             lr
    // 0xc839d4: add             SP, SP, #8
    // 0xc839d8: stur            x0, [fp, #-8]
    // 0xc839dc: ldr             x16, [fp, #0x18]
    // 0xc839e0: SaveReg r16
    //     0xc839e0: str             x16, [SP, #-8]!
    // 0xc839e4: r0 = runtimeType()
    //     0xc839e4: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc839e8: add             SP, SP, #8
    // 0xc839ec: mov             x1, x0
    // 0xc839f0: ldur            x0, [fp, #-8]
    // 0xc839f4: r2 = LoadClassIdInstr(r0)
    //     0xc839f4: ldur            x2, [x0, #-1]
    //     0xc839f8: ubfx            x2, x2, #0xc, #0x14
    // 0xc839fc: stp             x1, x0, [SP, #-0x10]!
    // 0xc83a00: mov             x0, x2
    // 0xc83a04: mov             lr, x0
    // 0xc83a08: ldr             lr, [x21, lr, lsl #3]
    // 0xc83a0c: blr             lr
    // 0xc83a10: add             SP, SP, #0x10
    // 0xc83a14: tbz             w0, #4, #0xc83a28
    // 0xc83a18: r0 = false
    //     0xc83a18: add             x0, NULL, #0x30  ; false
    // 0xc83a1c: LeaveFrame
    //     0xc83a1c: mov             SP, fp
    //     0xc83a20: ldp             fp, lr, [SP], #0x10
    // 0xc83a24: ret
    //     0xc83a24: ret             
    // 0xc83a28: ldr             x0, [fp, #0x10]
    // 0xc83a2c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc83a2c: mov             x1, #0x76
    //     0xc83a30: tbz             w0, #0, #0xc83a40
    //     0xc83a34: ldur            x1, [x0, #-1]
    //     0xc83a38: ubfx            x1, x1, #0xc, #0x14
    //     0xc83a3c: lsl             x1, x1, #1
    // 0xc83a40: stur            x1, [fp, #-8]
    // 0xc83a44: r2 = LoadInt32Instr(r1)
    //     0xc83a44: sbfx            x2, x1, #1, #0x1f
    // 0xc83a48: cmp             x2, #0xb13
    // 0xc83a4c: b.lt            #0xc83cfc
    // 0xc83a50: cmp             x2, #0xb14
    // 0xc83a54: b.gt            #0xc83cfc
    // 0xc83a58: r17 = 5670
    //     0xc83a58: mov             x17, #0x1626
    // 0xc83a5c: cmp             w1, w17
    // 0xc83a60: b.ne            #0xc83a74
    // 0xc83a64: LoadField: r2 = r0->field_7
    //     0xc83a64: ldur            w2, [x0, #7]
    // 0xc83a68: DecompressPointer r2
    //     0xc83a68: add             x2, x2, HEAP, lsl #32
    // 0xc83a6c: mov             x1, x2
    // 0xc83a70: b               #0xc83a9c
    // 0xc83a74: LoadField: r2 = r0->field_2b
    //     0xc83a74: ldur            w2, [x0, #0x2b]
    // 0xc83a78: DecompressPointer r2
    //     0xc83a78: add             x2, x2, HEAP, lsl #32
    // 0xc83a7c: SaveReg r2
    //     0xc83a7c: str             x2, [SP, #-8]!
    // 0xc83a80: r0 = of()
    //     0xc83a80: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc83a84: add             SP, SP, #8
    // 0xc83a88: LoadField: r1 = r0->field_3f
    //     0xc83a88: ldur            w1, [x0, #0x3f]
    // 0xc83a8c: DecompressPointer r1
    //     0xc83a8c: add             x1, x1, HEAP, lsl #32
    // 0xc83a90: LoadField: r0 = r1->field_53
    //     0xc83a90: ldur            w0, [x1, #0x53]
    // 0xc83a94: DecompressPointer r0
    //     0xc83a94: add             x0, x0, HEAP, lsl #32
    // 0xc83a98: mov             x1, x0
    // 0xc83a9c: ldr             x0, [fp, #0x18]
    // 0xc83aa0: stur            x1, [fp, #-0x18]
    // 0xc83aa4: r2 = LoadClassIdInstr(r0)
    //     0xc83aa4: ldur            x2, [x0, #-1]
    //     0xc83aa8: ubfx            x2, x2, #0xc, #0x14
    // 0xc83aac: lsl             x2, x2, #1
    // 0xc83ab0: stur            x2, [fp, #-0x10]
    // 0xc83ab4: r17 = 5670
    //     0xc83ab4: mov             x17, #0x1626
    // 0xc83ab8: cmp             w2, w17
    // 0xc83abc: b.ne            #0xc83ad4
    // 0xc83ac0: LoadField: r3 = r0->field_7
    //     0xc83ac0: ldur            w3, [x0, #7]
    // 0xc83ac4: DecompressPointer r3
    //     0xc83ac4: add             x3, x3, HEAP, lsl #32
    // 0xc83ac8: mov             x0, x1
    // 0xc83acc: mov             x1, x3
    // 0xc83ad0: b               #0xc83b00
    // 0xc83ad4: LoadField: r3 = r0->field_2b
    //     0xc83ad4: ldur            w3, [x0, #0x2b]
    // 0xc83ad8: DecompressPointer r3
    //     0xc83ad8: add             x3, x3, HEAP, lsl #32
    // 0xc83adc: SaveReg r3
    //     0xc83adc: str             x3, [SP, #-8]!
    // 0xc83ae0: r0 = of()
    //     0xc83ae0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc83ae4: add             SP, SP, #8
    // 0xc83ae8: LoadField: r1 = r0->field_3f
    //     0xc83ae8: ldur            w1, [x0, #0x3f]
    // 0xc83aec: DecompressPointer r1
    //     0xc83aec: add             x1, x1, HEAP, lsl #32
    // 0xc83af0: LoadField: r0 = r1->field_53
    //     0xc83af0: ldur            w0, [x1, #0x53]
    // 0xc83af4: DecompressPointer r0
    //     0xc83af4: add             x0, x0, HEAP, lsl #32
    // 0xc83af8: mov             x1, x0
    // 0xc83afc: ldur            x0, [fp, #-0x18]
    // 0xc83b00: r2 = LoadClassIdInstr(r0)
    //     0xc83b00: ldur            x2, [x0, #-1]
    //     0xc83b04: ubfx            x2, x2, #0xc, #0x14
    // 0xc83b08: stp             x1, x0, [SP, #-0x10]!
    // 0xc83b0c: mov             x0, x2
    // 0xc83b10: mov             lr, x0
    // 0xc83b14: ldr             lr, [x21, lr, lsl #3]
    // 0xc83b18: blr             lr
    // 0xc83b1c: add             SP, SP, #0x10
    // 0xc83b20: tbnz            w0, #4, #0xc83cfc
    // 0xc83b24: ldur            x0, [fp, #-8]
    // 0xc83b28: r17 = 5670
    //     0xc83b28: mov             x17, #0x1626
    // 0xc83b2c: cmp             w0, w17
    // 0xc83b30: b.ne            #0xc83b44
    // 0xc83b34: ldr             x0, [fp, #0x10]
    // 0xc83b38: LoadField: r1 = r0->field_b
    //     0xc83b38: ldur            w1, [x0, #0xb]
    // 0xc83b3c: DecompressPointer r1
    //     0xc83b3c: add             x1, x1, HEAP, lsl #32
    // 0xc83b40: b               #0xc83b80
    // 0xc83b44: ldr             x0, [fp, #0x10]
    // 0xc83b48: LoadField: r1 = r0->field_2b
    //     0xc83b48: ldur            w1, [x0, #0x2b]
    // 0xc83b4c: DecompressPointer r1
    //     0xc83b4c: add             x1, x1, HEAP, lsl #32
    // 0xc83b50: SaveReg r1
    //     0xc83b50: str             x1, [SP, #-8]!
    // 0xc83b54: r0 = of()
    //     0xc83b54: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc83b58: add             SP, SP, #8
    // 0xc83b5c: LoadField: r1 = r0->field_3f
    //     0xc83b5c: ldur            w1, [x0, #0x3f]
    // 0xc83b60: DecompressPointer r1
    //     0xc83b60: add             x1, x1, HEAP, lsl #32
    // 0xc83b64: LoadField: r0 = r1->field_7f
    //     0xc83b64: ldur            w0, [x1, #0x7f]
    // 0xc83b68: DecompressPointer r0
    //     0xc83b68: add             x0, x0, HEAP, lsl #32
    // 0xc83b6c: cmp             w0, NULL
    // 0xc83b70: b.ne            #0xc83b7c
    // 0xc83b74: LoadField: r0 = r1->field_b
    //     0xc83b74: ldur            w0, [x1, #0xb]
    // 0xc83b78: DecompressPointer r0
    //     0xc83b78: add             x0, x0, HEAP, lsl #32
    // 0xc83b7c: mov             x1, x0
    // 0xc83b80: ldur            x0, [fp, #-0x10]
    // 0xc83b84: stur            x1, [fp, #-8]
    // 0xc83b88: r17 = 5670
    //     0xc83b88: mov             x17, #0x1626
    // 0xc83b8c: cmp             w0, w17
    // 0xc83b90: b.ne            #0xc83bac
    // 0xc83b94: ldr             x0, [fp, #0x18]
    // 0xc83b98: LoadField: r2 = r0->field_b
    //     0xc83b98: ldur            w2, [x0, #0xb]
    // 0xc83b9c: DecompressPointer r2
    //     0xc83b9c: add             x2, x2, HEAP, lsl #32
    // 0xc83ba0: mov             x0, x1
    // 0xc83ba4: mov             x1, x2
    // 0xc83ba8: b               #0xc83bec
    // 0xc83bac: ldr             x0, [fp, #0x18]
    // 0xc83bb0: LoadField: r2 = r0->field_2b
    //     0xc83bb0: ldur            w2, [x0, #0x2b]
    // 0xc83bb4: DecompressPointer r2
    //     0xc83bb4: add             x2, x2, HEAP, lsl #32
    // 0xc83bb8: SaveReg r2
    //     0xc83bb8: str             x2, [SP, #-8]!
    // 0xc83bbc: r0 = of()
    //     0xc83bbc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc83bc0: add             SP, SP, #8
    // 0xc83bc4: LoadField: r1 = r0->field_3f
    //     0xc83bc4: ldur            w1, [x0, #0x3f]
    // 0xc83bc8: DecompressPointer r1
    //     0xc83bc8: add             x1, x1, HEAP, lsl #32
    // 0xc83bcc: LoadField: r0 = r1->field_7f
    //     0xc83bcc: ldur            w0, [x1, #0x7f]
    // 0xc83bd0: DecompressPointer r0
    //     0xc83bd0: add             x0, x0, HEAP, lsl #32
    // 0xc83bd4: cmp             w0, NULL
    // 0xc83bd8: b.ne            #0xc83be4
    // 0xc83bdc: LoadField: r0 = r1->field_b
    //     0xc83bdc: ldur            w0, [x1, #0xb]
    // 0xc83be0: DecompressPointer r0
    //     0xc83be0: add             x0, x0, HEAP, lsl #32
    // 0xc83be4: mov             x1, x0
    // 0xc83be8: ldur            x0, [fp, #-8]
    // 0xc83bec: r2 = LoadClassIdInstr(r0)
    //     0xc83bec: ldur            x2, [x0, #-1]
    //     0xc83bf0: ubfx            x2, x2, #0xc, #0x14
    // 0xc83bf4: stp             x1, x0, [SP, #-0x10]!
    // 0xc83bf8: mov             x0, x2
    // 0xc83bfc: mov             lr, x0
    // 0xc83c00: ldr             lr, [x21, lr, lsl #3]
    // 0xc83c04: blr             lr
    // 0xc83c08: add             SP, SP, #0x10
    // 0xc83c0c: tbnz            w0, #4, #0xc83cfc
    // 0xc83c10: ldr             x1, [fp, #0x18]
    // 0xc83c14: ldr             x2, [fp, #0x10]
    // 0xc83c18: LoadField: r0 = r2->field_f
    //     0xc83c18: ldur            w0, [x2, #0xf]
    // 0xc83c1c: DecompressPointer r0
    //     0xc83c1c: add             x0, x0, HEAP, lsl #32
    // 0xc83c20: LoadField: r3 = r1->field_f
    //     0xc83c20: ldur            w3, [x1, #0xf]
    // 0xc83c24: DecompressPointer r3
    //     0xc83c24: add             x3, x3, HEAP, lsl #32
    // 0xc83c28: r4 = LoadClassIdInstr(r0)
    //     0xc83c28: ldur            x4, [x0, #-1]
    //     0xc83c2c: ubfx            x4, x4, #0xc, #0x14
    // 0xc83c30: stp             x3, x0, [SP, #-0x10]!
    // 0xc83c34: mov             x0, x4
    // 0xc83c38: mov             lr, x0
    // 0xc83c3c: ldr             lr, [x21, lr, lsl #3]
    // 0xc83c40: blr             lr
    // 0xc83c44: add             SP, SP, #0x10
    // 0xc83c48: tbnz            w0, #4, #0xc83cfc
    // 0xc83c4c: ldr             x1, [fp, #0x18]
    // 0xc83c50: ldr             x2, [fp, #0x10]
    // 0xc83c54: LoadField: r0 = r2->field_1b
    //     0xc83c54: ldur            w0, [x2, #0x1b]
    // 0xc83c58: DecompressPointer r0
    //     0xc83c58: add             x0, x0, HEAP, lsl #32
    // 0xc83c5c: LoadField: r3 = r1->field_1b
    //     0xc83c5c: ldur            w3, [x1, #0x1b]
    // 0xc83c60: DecompressPointer r3
    //     0xc83c60: add             x3, x3, HEAP, lsl #32
    // 0xc83c64: r4 = LoadClassIdInstr(r0)
    //     0xc83c64: ldur            x4, [x0, #-1]
    //     0xc83c68: ubfx            x4, x4, #0xc, #0x14
    // 0xc83c6c: stp             x3, x0, [SP, #-0x10]!
    // 0xc83c70: mov             x0, x4
    // 0xc83c74: mov             lr, x0
    // 0xc83c78: ldr             lr, [x21, lr, lsl #3]
    // 0xc83c7c: blr             lr
    // 0xc83c80: add             SP, SP, #0x10
    // 0xc83c84: tbnz            w0, #4, #0xc83cfc
    // 0xc83c88: ldr             x1, [fp, #0x18]
    // 0xc83c8c: ldr             x2, [fp, #0x10]
    // 0xc83c90: LoadField: r0 = r2->field_1f
    //     0xc83c90: ldur            w0, [x2, #0x1f]
    // 0xc83c94: DecompressPointer r0
    //     0xc83c94: add             x0, x0, HEAP, lsl #32
    // 0xc83c98: LoadField: r3 = r1->field_1f
    //     0xc83c98: ldur            w3, [x1, #0x1f]
    // 0xc83c9c: DecompressPointer r3
    //     0xc83c9c: add             x3, x3, HEAP, lsl #32
    // 0xc83ca0: r4 = LoadClassIdInstr(r0)
    //     0xc83ca0: ldur            x4, [x0, #-1]
    //     0xc83ca4: ubfx            x4, x4, #0xc, #0x14
    // 0xc83ca8: stp             x3, x0, [SP, #-0x10]!
    // 0xc83cac: mov             x0, x4
    // 0xc83cb0: mov             lr, x0
    // 0xc83cb4: ldr             lr, [x21, lr, lsl #3]
    // 0xc83cb8: blr             lr
    // 0xc83cbc: add             SP, SP, #0x10
    // 0xc83cc0: tbnz            w0, #4, #0xc83cfc
    // 0xc83cc4: ldr             x0, [fp, #0x18]
    // 0xc83cc8: ldr             x1, [fp, #0x10]
    // 0xc83ccc: LoadField: r2 = r1->field_27
    //     0xc83ccc: ldur            w2, [x1, #0x27]
    // 0xc83cd0: DecompressPointer r2
    //     0xc83cd0: add             x2, x2, HEAP, lsl #32
    // 0xc83cd4: LoadField: r1 = r0->field_27
    //     0xc83cd4: ldur            w1, [x0, #0x27]
    // 0xc83cd8: DecompressPointer r1
    //     0xc83cd8: add             x1, x1, HEAP, lsl #32
    // 0xc83cdc: r0 = LoadClassIdInstr(r2)
    //     0xc83cdc: ldur            x0, [x2, #-1]
    //     0xc83ce0: ubfx            x0, x0, #0xc, #0x14
    // 0xc83ce4: stp             x1, x2, [SP, #-0x10]!
    // 0xc83ce8: mov             lr, x0
    // 0xc83cec: ldr             lr, [x21, lr, lsl #3]
    // 0xc83cf0: blr             lr
    // 0xc83cf4: add             SP, SP, #0x10
    // 0xc83cf8: b               #0xc83d00
    // 0xc83cfc: r0 = false
    //     0xc83cfc: add             x0, NULL, #0x30  ; false
    // 0xc83d00: LeaveFrame
    //     0xc83d00: mov             SP, fp
    //     0xc83d04: ldp             fp, lr, [SP], #0x10
    // 0xc83d08: ret
    //     0xc83d08: ret             
    // 0xc83d0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc83d0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc83d10: b               #0xc83978
  }
}

// lib: , url: package:flutter/src/material/app_bar.dart

// class id: 1049179, size: 0x8
class :: {
}

// class id: 2240, size: 0xb4, field offset: 0x8
class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {

  _ _SliverAppBarDelegate(/* No info */) {
    // ** addr: 0x849a18, size: 0x110
    // 0x849a18: EnterFrame
    //     0x849a18: stp             fp, lr, [SP, #-0x10]!
    //     0x849a1c: mov             fp, SP
    // 0x849a20: r2 = false
    //     0x849a20: add             x2, NULL, #0x30  ; false
    // 0x849a24: r1 = true
    //     0x849a24: add             x1, NULL, #0x20  ; true
    // 0x849a28: d1 = 56.000000
    //     0x849a28: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x849a2c: ldr             d1, [x17, #0xe88]
    // 0x849a30: d0 = 0.000000
    //     0x849a30: eor             v0.16b, v0.16b, v0.16b
    // 0x849a34: ldr             x3, [fp, #0x50]
    // 0x849a38: StoreField: r3->field_b = r2
    //     0x849a38: stur            w2, [x3, #0xb]
    // 0x849a3c: ldr             x0, [fp, #0x38]
    // 0x849a40: StoreField: r3->field_17 = r0
    //     0x849a40: stur            w0, [x3, #0x17]
    //     0x849a44: ldurb           w16, [x3, #-1]
    //     0x849a48: ldurb           w17, [x0, #-1]
    //     0x849a4c: and             x16, x17, x16, lsr #2
    //     0x849a50: tst             x16, HEAP, lsr #32
    //     0x849a54: b.eq            #0x849a5c
    //     0x849a58: bl              #0xd682ac
    // 0x849a5c: StoreField: r3->field_2f = r2
    //     0x849a5c: stur            w2, [x3, #0x2f]
    // 0x849a60: StoreField: r3->field_4b = r1
    //     0x849a60: stur            w1, [x3, #0x4b]
    // 0x849a64: StoreField: r3->field_53 = r2
    //     0x849a64: stur            w2, [x3, #0x53]
    // 0x849a68: ldr             x4, [fp, #0x40]
    // 0x849a6c: LoadField: d2 = r4->field_7
    //     0x849a6c: ldur            d2, [x4, #7]
    // 0x849a70: StoreField: r3->field_5b = d2
    //     0x849a70: stur            d2, [x3, #0x5b]
    // 0x849a74: ldr             x4, [fp, #0x48]
    // 0x849a78: LoadField: d2 = r4->field_7
    //     0x849a78: ldur            d2, [x4, #7]
    // 0x849a7c: StoreField: r3->field_63 = d2
    //     0x849a7c: stur            d2, [x3, #0x63]
    // 0x849a80: ldr             d2, [fp, #0x18]
    // 0x849a84: StoreField: r3->field_6b = d2
    //     0x849a84: stur            d2, [x3, #0x6b]
    // 0x849a88: StoreField: r3->field_73 = r2
    //     0x849a88: stur            w2, [x3, #0x73]
    // 0x849a8c: StoreField: r3->field_77 = r1
    //     0x849a8c: stur            w1, [x3, #0x77]
    // 0x849a90: ldr             x0, [fp, #0x10]
    // 0x849a94: StoreField: r3->field_a3 = r0
    //     0x849a94: stur            w0, [x3, #0xa3]
    //     0x849a98: ldurb           w16, [x3, #-1]
    //     0x849a9c: ldurb           w17, [x0, #-1]
    //     0x849aa0: and             x16, x17, x16, lsr #2
    //     0x849aa4: tst             x16, HEAP, lsr #32
    //     0x849aa8: b.eq            #0x849ab0
    //     0x849aac: bl              #0xd682ac
    // 0x849ab0: ldr             x0, [fp, #0x28]
    // 0x849ab4: StoreField: r3->field_a7 = r0
    //     0x849ab4: stur            w0, [x3, #0xa7]
    //     0x849ab8: ldurb           w16, [x3, #-1]
    //     0x849abc: ldurb           w17, [x0, #-1]
    //     0x849ac0: and             x16, x17, x16, lsr #2
    //     0x849ac4: tst             x16, HEAP, lsr #32
    //     0x849ac8: b.eq            #0x849ad0
    //     0x849acc: bl              #0xd682ac
    // 0x849ad0: ldr             x0, [fp, #0x20]
    // 0x849ad4: StoreField: r3->field_ab = r0
    //     0x849ad4: stur            w0, [x3, #0xab]
    //     0x849ad8: ldurb           w16, [x3, #-1]
    //     0x849adc: ldurb           w17, [x0, #-1]
    //     0x849ae0: and             x16, x17, x16, lsr #2
    //     0x849ae4: tst             x16, HEAP, lsr #32
    //     0x849ae8: b.eq            #0x849af0
    //     0x849aec: bl              #0xd682ac
    // 0x849af0: ldr             x0, [fp, #0x30]
    // 0x849af4: StoreField: r3->field_af = r0
    //     0x849af4: stur            w0, [x3, #0xaf]
    //     0x849af8: ldurb           w16, [x3, #-1]
    //     0x849afc: ldurb           w17, [x0, #-1]
    //     0x849b00: and             x16, x17, x16, lsr #2
    //     0x849b04: tst             x16, HEAP, lsr #32
    //     0x849b08: b.eq            #0x849b10
    //     0x849b0c: bl              #0xd682ac
    // 0x849b10: StoreField: r3->field_7f = d1
    //     0x849b10: stur            d1, [x3, #0x7f]
    // 0x849b14: StoreField: r3->field_9b = d0
    //     0x849b14: stur            d0, [x3, #0x9b]
    // 0x849b18: r0 = Null
    //     0x849b18: mov             x0, NULL
    // 0x849b1c: LeaveFrame
    //     0x849b1c: mov             SP, fp
    //     0x849b20: ldp             fp, lr, [SP], #0x10
    // 0x849b24: ret
    //     0x849b24: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0xada1e4, size: 0x158
    // 0xada1e4: EnterFrame
    //     0xada1e4: stp             fp, lr, [SP, #-0x10]!
    //     0xada1e8: mov             fp, SP
    // 0xada1ec: AllocStack(0x10)
    //     0xada1ec: sub             SP, SP, #0x10
    // 0xada1f0: CheckStackOverflow
    //     0xada1f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xada1f4: cmp             SP, x16
    //     0xada1f8: b.ls            #0xada31c
    // 0xada1fc: ldr             x16, [fp, #0x10]
    // 0xada200: SaveReg r16
    //     0xada200: str             x16, [SP, #-8]!
    // 0xada204: r0 = describeIdentity()
    //     0xada204: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xada208: add             SP, SP, #8
    // 0xada20c: r1 = Null
    //     0xada20c: mov             x1, NULL
    // 0xada210: r2 = 12
    //     0xada210: mov             x2, #0xc
    // 0xada214: stur            x0, [fp, #-8]
    // 0xada218: r0 = AllocateArray()
    //     0xada218: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada21c: mov             x1, x0
    // 0xada220: ldur            x0, [fp, #-8]
    // 0xada224: stur            x1, [fp, #-0x10]
    // 0xada228: StoreField: r1->field_f = r0
    //     0xada228: stur            w0, [x1, #0xf]
    // 0xada22c: r17 = "(topPadding: "
    //     0xada22c: add             x17, PP, #0x50, lsl #12  ; [pp+0x50d20] "(topPadding: "
    //     0xada230: ldr             x17, [x17, #0xd20]
    // 0xada234: StoreField: r1->field_13 = r17
    //     0xada234: stur            w17, [x1, #0x13]
    // 0xada238: ldr             x0, [fp, #0x10]
    // 0xada23c: LoadField: d0 = r0->field_6b
    //     0xada23c: ldur            d0, [x0, #0x6b]
    // 0xada240: r0 = inline_Allocate_Double()
    //     0xada240: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xada244: add             x0, x0, #0x10
    //     0xada248: cmp             x2, x0
    //     0xada24c: b.ls            #0xada324
    //     0xada250: str             x0, [THR, #0x60]  ; THR::top
    //     0xada254: sub             x0, x0, #0xf
    //     0xada258: mov             x2, #0xd108
    //     0xada25c: movk            x2, #3, lsl #16
    //     0xada260: stur            x2, [x0, #-1]
    // 0xada264: StoreField: r0->field_7 = d0
    //     0xada264: stur            d0, [x0, #7]
    // 0xada268: SaveReg r0
    //     0xada268: str             x0, [SP, #-8]!
    // 0xada26c: r0 = 1
    //     0xada26c: mov             x0, #1
    // 0xada270: SaveReg r0
    //     0xada270: str             x0, [SP, #-8]!
    // 0xada274: r0 = toStringAsFixed()
    //     0xada274: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xada278: add             SP, SP, #0x10
    // 0xada27c: ldur            x1, [fp, #-0x10]
    // 0xada280: ArrayStore: r1[2] = r0  ; List_4
    //     0xada280: add             x25, x1, #0x17
    //     0xada284: str             w0, [x25]
    //     0xada288: tbz             w0, #0, #0xada2a4
    //     0xada28c: ldurb           w16, [x1, #-1]
    //     0xada290: ldurb           w17, [x0, #-1]
    //     0xada294: and             x16, x17, x16, lsr #2
    //     0xada298: tst             x16, HEAP, lsr #32
    //     0xada29c: b.eq            #0xada2a4
    //     0xada2a0: bl              #0xd67e5c
    // 0xada2a4: ldur            x1, [fp, #-0x10]
    // 0xada2a8: r17 = ", bottomHeight: "
    //     0xada2a8: add             x17, PP, #0x50, lsl #12  ; [pp+0x50d28] ", bottomHeight: "
    //     0xada2ac: ldr             x17, [x17, #0xd28]
    // 0xada2b0: StoreField: r1->field_1b = r17
    //     0xada2b0: stur            w17, [x1, #0x1b]
    // 0xada2b4: r16 = 0.000000
    //     0xada2b4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xada2b8: SaveReg r16
    //     0xada2b8: str             x16, [SP, #-8]!
    // 0xada2bc: r0 = 1
    //     0xada2bc: mov             x0, #1
    // 0xada2c0: SaveReg r0
    //     0xada2c0: str             x0, [SP, #-8]!
    // 0xada2c4: r0 = toStringAsFixed()
    //     0xada2c4: bl              #0x8a9f40  ; [dart:core] _Double::toStringAsFixed
    // 0xada2c8: add             SP, SP, #0x10
    // 0xada2cc: ldur            x1, [fp, #-0x10]
    // 0xada2d0: ArrayStore: r1[4] = r0  ; List_4
    //     0xada2d0: add             x25, x1, #0x1f
    //     0xada2d4: str             w0, [x25]
    //     0xada2d8: tbz             w0, #0, #0xada2f4
    //     0xada2dc: ldurb           w16, [x1, #-1]
    //     0xada2e0: ldurb           w17, [x0, #-1]
    //     0xada2e4: and             x16, x17, x16, lsr #2
    //     0xada2e8: tst             x16, HEAP, lsr #32
    //     0xada2ec: b.eq            #0xada2f4
    //     0xada2f0: bl              #0xd67e5c
    // 0xada2f4: ldur            x0, [fp, #-0x10]
    // 0xada2f8: r17 = ", ...)"
    //     0xada2f8: add             x17, PP, #0x50, lsl #12  ; [pp+0x50d30] ", ...)"
    //     0xada2fc: ldr             x17, [x17, #0xd30]
    // 0xada300: StoreField: r0->field_23 = r17
    //     0xada300: stur            w17, [x0, #0x23]
    // 0xada304: SaveReg r0
    //     0xada304: str             x0, [SP, #-8]!
    // 0xada308: r0 = _interpolate()
    //     0xada308: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada30c: add             SP, SP, #8
    // 0xada310: LeaveFrame
    //     0xada310: mov             SP, fp
    //     0xada314: ldp             fp, lr, [SP], #0x10
    // 0xada318: ret
    //     0xada318: ret             
    // 0xada31c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xada31c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xada320: b               #0xada1fc
    // 0xada324: SaveReg d0
    //     0xada324: str             q0, [SP, #-0x10]!
    // 0xada328: SaveReg r1
    //     0xada328: str             x1, [SP, #-8]!
    // 0xada32c: r0 = AllocateDouble()
    //     0xada32c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xada330: RestoreReg r1
    //     0xada330: ldr             x1, [SP], #8
    // 0xada334: RestoreReg d0
    //     0xada334: ldr             q0, [SP], #0x10
    // 0xada338: b               #0xada264
  }
  _ shouldRebuild(/* No info */) {
    // ** addr: 0xcf9640, size: 0x114
    // 0xcf9640: EnterFrame
    //     0xcf9640: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9644: mov             fp, SP
    // 0xcf9648: ldr             x0, [fp, #0x10]
    // 0xcf964c: r2 = Null
    //     0xcf964c: mov             x2, NULL
    // 0xcf9650: r1 = Null
    //     0xcf9650: mov             x1, NULL
    // 0xcf9654: r4 = 59
    //     0xcf9654: mov             x4, #0x3b
    // 0xcf9658: branchIfSmi(r0, 0xcf9664)
    //     0xcf9658: tbz             w0, #0, #0xcf9664
    // 0xcf965c: r4 = LoadClassIdInstr(r0)
    //     0xcf965c: ldur            x4, [x0, #-1]
    //     0xcf9660: ubfx            x4, x4, #0xc, #0x14
    // 0xcf9664: cmp             x4, #0x8c0
    // 0xcf9668: b.eq            #0xcf9680
    // 0xcf966c: r8 = _SliverAppBarDelegate
    //     0xcf966c: add             x8, PP, #0x53, lsl #12  ; [pp+0x532c0] Type: _SliverAppBarDelegate
    //     0xcf9670: ldr             x8, [x8, #0x2c0]
    // 0xcf9674: r3 = Null
    //     0xcf9674: add             x3, PP, #0x53, lsl #12  ; [pp+0x532c8] Null
    //     0xcf9678: ldr             x3, [x3, #0x2c8]
    // 0xcf967c: r0 = DefaultTypeTest()
    //     0xcf967c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcf9680: ldr             x1, [fp, #0x18]
    // 0xcf9684: LoadField: r2 = r1->field_17
    //     0xcf9684: ldur            w2, [x1, #0x17]
    // 0xcf9688: DecompressPointer r2
    //     0xcf9688: add             x2, x2, HEAP, lsl #32
    // 0xcf968c: ldr             x3, [fp, #0x10]
    // 0xcf9690: LoadField: r4 = r3->field_17
    //     0xcf9690: ldur            w4, [x3, #0x17]
    // 0xcf9694: DecompressPointer r4
    //     0xcf9694: add             x4, x4, HEAP, lsl #32
    // 0xcf9698: cmp             w2, w4
    // 0xcf969c: b.ne            #0xcf973c
    // 0xcf96a0: d0 = 0.000000
    //     0xcf96a0: eor             v0.16b, v0.16b, v0.16b
    // 0xcf96a4: fcmp            d0, d0
    // 0xcf96a8: b.ne            #0xcf973c
    // 0xcf96ac: LoadField: d0 = r1->field_5b
    //     0xcf96ac: ldur            d0, [x1, #0x5b]
    // 0xcf96b0: LoadField: d1 = r3->field_5b
    //     0xcf96b0: ldur            d1, [x3, #0x5b]
    // 0xcf96b4: fcmp            d0, d1
    // 0xcf96b8: b.ne            #0xcf973c
    // 0xcf96bc: LoadField: d0 = r1->field_6b
    //     0xcf96bc: ldur            d0, [x1, #0x6b]
    // 0xcf96c0: LoadField: d1 = r3->field_6b
    //     0xcf96c0: ldur            d1, [x3, #0x6b]
    // 0xcf96c4: fcmp            d0, d1
    // 0xcf96c8: b.ne            #0xcf973c
    // 0xcf96cc: LoadField: r2 = r1->field_a3
    //     0xcf96cc: ldur            w2, [x1, #0xa3]
    // 0xcf96d0: DecompressPointer r2
    //     0xcf96d0: add             x2, x2, HEAP, lsl #32
    // 0xcf96d4: LoadField: r4 = r3->field_a3
    //     0xcf96d4: ldur            w4, [x3, #0xa3]
    // 0xcf96d8: DecompressPointer r4
    //     0xcf96d8: add             x4, x4, HEAP, lsl #32
    // 0xcf96dc: cmp             w2, w4
    // 0xcf96e0: b.ne            #0xcf973c
    // 0xcf96e4: LoadField: r2 = r1->field_a7
    //     0xcf96e4: ldur            w2, [x1, #0xa7]
    // 0xcf96e8: DecompressPointer r2
    //     0xcf96e8: add             x2, x2, HEAP, lsl #32
    // 0xcf96ec: LoadField: r4 = r3->field_a7
    //     0xcf96ec: ldur            w4, [x3, #0xa7]
    // 0xcf96f0: DecompressPointer r4
    //     0xcf96f0: add             x4, x4, HEAP, lsl #32
    // 0xcf96f4: cmp             w2, w4
    // 0xcf96f8: b.ne            #0xcf973c
    // 0xcf96fc: LoadField: r2 = r1->field_ab
    //     0xcf96fc: ldur            w2, [x1, #0xab]
    // 0xcf9700: DecompressPointer r2
    //     0xcf9700: add             x2, x2, HEAP, lsl #32
    // 0xcf9704: LoadField: r4 = r3->field_ab
    //     0xcf9704: ldur            w4, [x3, #0xab]
    // 0xcf9708: DecompressPointer r4
    //     0xcf9708: add             x4, x4, HEAP, lsl #32
    // 0xcf970c: cmp             w2, w4
    // 0xcf9710: b.ne            #0xcf973c
    // 0xcf9714: LoadField: r2 = r1->field_af
    //     0xcf9714: ldur            w2, [x1, #0xaf]
    // 0xcf9718: DecompressPointer r2
    //     0xcf9718: add             x2, x2, HEAP, lsl #32
    // 0xcf971c: LoadField: r1 = r3->field_af
    //     0xcf971c: ldur            w1, [x3, #0xaf]
    // 0xcf9720: DecompressPointer r1
    //     0xcf9720: add             x1, x1, HEAP, lsl #32
    // 0xcf9724: cmp             w2, w1
    // 0xcf9728: b.ne            #0xcf973c
    // 0xcf972c: d0 = 56.000000
    //     0xcf972c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0xcf9730: ldr             d0, [x17, #0xe88]
    // 0xcf9734: fcmp            d0, d0
    // 0xcf9738: b.eq            #0xcf9744
    // 0xcf973c: r0 = true
    //     0xcf973c: add             x0, NULL, #0x20  ; true
    // 0xcf9740: b               #0xcf9748
    // 0xcf9744: r0 = false
    //     0xcf9744: add             x0, NULL, #0x30  ; false
    // 0xcf9748: LeaveFrame
    //     0xcf9748: mov             SP, fp
    //     0xcf974c: ldp             fp, lr, [SP], #0x10
    // 0xcf9750: ret
    //     0xcf9750: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xcf990c, size: 0x284
    // 0xcf990c: EnterFrame
    //     0xcf990c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf9910: mov             fp, SP
    // 0xcf9914: AllocStack(0x38)
    //     0xcf9914: sub             SP, SP, #0x38
    // 0xcf9918: CheckStackOverflow
    //     0xcf9918: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf991c: cmp             SP, x16
    //     0xcf9920: b.ls            #0xcf9b5c
    // 0xcf9924: ldr             x16, [fp, #0x28]
    // 0xcf9928: SaveReg r16
    //     0xcf9928: str             x16, [SP, #-8]!
    // 0xcf992c: r0 = maxExtent()
    //     0xcf992c: bl              #0xcf9c9c  ; [package:flutter/src/material/app_bar.dart] _SliverAppBarDelegate::maxExtent
    // 0xcf9930: add             SP, SP, #8
    // 0xcf9934: ldr             x0, [fp, #0x28]
    // 0xcf9938: LoadField: d0 = r0->field_63
    //     0xcf9938: ldur            d0, [x0, #0x63]
    // 0xcf993c: ldr             x1, [fp, #0x10]
    // 0xcf9940: stur            d0, [fp, #-0x28]
    // 0xcf9944: tbnz            w1, #4, #0xcf9954
    // 0xcf9948: ldr             d1, [fp, #0x18]
    // 0xcf994c: r0 = true
    //     0xcf994c: add             x0, NULL, #0x20  ; true
    // 0xcf9950: b               #0xcf998c
    // 0xcf9954: ldr             d1, [fp, #0x18]
    // 0xcf9958: SaveReg r0
    //     0xcf9958: str             x0, [SP, #-8]!
    // 0xcf995c: r0 = maxExtent()
    //     0xcf995c: bl              #0xcf9c9c  ; [package:flutter/src/material/app_bar.dart] _SliverAppBarDelegate::maxExtent
    // 0xcf9960: add             SP, SP, #8
    // 0xcf9964: mov             v1.16b, v0.16b
    // 0xcf9968: ldur            d0, [fp, #-0x28]
    // 0xcf996c: fsub            d2, d1, d0
    // 0xcf9970: ldr             d1, [fp, #0x18]
    // 0xcf9974: fcmp            d1, d2
    // 0xcf9978: b.vs            #0xcf9980
    // 0xcf997c: b.gt            #0xcf9988
    // 0xcf9980: r0 = false
    //     0xcf9980: add             x0, NULL, #0x30  ; false
    // 0xcf9984: b               #0xcf998c
    // 0xcf9988: r0 = true
    //     0xcf9988: add             x0, NULL, #0x20  ; true
    // 0xcf998c: stur            x0, [fp, #-8]
    // 0xcf9990: ldr             x16, [fp, #0x28]
    // 0xcf9994: SaveReg r16
    //     0xcf9994: str             x16, [SP, #-8]!
    // 0xcf9998: r0 = maxExtent()
    //     0xcf9998: bl              #0xcf9c9c  ; [package:flutter/src/material/app_bar.dart] _SliverAppBarDelegate::maxExtent
    // 0xcf999c: add             SP, SP, #8
    // 0xcf99a0: stur            d0, [fp, #-0x30]
    // 0xcf99a4: ldr             x16, [fp, #0x28]
    // 0xcf99a8: SaveReg r16
    //     0xcf99a8: str             x16, [SP, #-8]!
    // 0xcf99ac: r0 = maxExtent()
    //     0xcf99ac: bl              #0xcf9c9c  ; [package:flutter/src/material/app_bar.dart] _SliverAppBarDelegate::maxExtent
    // 0xcf99b0: add             SP, SP, #8
    // 0xcf99b4: mov             v1.16b, v0.16b
    // 0xcf99b8: ldr             d0, [fp, #0x18]
    // 0xcf99bc: fsub            d2, d1, d0
    // 0xcf99c0: ldur            d0, [fp, #-0x28]
    // 0xcf99c4: fcmp            d0, d2
    // 0xcf99c8: b.vs            #0xcf99d8
    // 0xcf99cc: b.le            #0xcf99d8
    // 0xcf99d0: mov             v1.16b, v0.16b
    // 0xcf99d4: b               #0xcf9a18
    // 0xcf99d8: fcmp            d0, d2
    // 0xcf99dc: b.vs            #0xcf99ec
    // 0xcf99e0: b.ge            #0xcf99ec
    // 0xcf99e4: mov             v1.16b, v2.16b
    // 0xcf99e8: b               #0xcf9a18
    // 0xcf99ec: d1 = 0.000000
    //     0xcf99ec: eor             v1.16b, v1.16b, v1.16b
    // 0xcf99f0: fcmp            d0, d1
    // 0xcf99f4: b.vs            #0xcf9a04
    // 0xcf99f8: b.ne            #0xcf9a04
    // 0xcf99fc: fadd            d1, d0, d2
    // 0xcf9a00: b               #0xcf9a18
    // 0xcf9a04: fcmp            d2, d2
    // 0xcf9a08: b.vc            #0xcf9a14
    // 0xcf9a0c: mov             v1.16b, v2.16b
    // 0xcf9a10: b               #0xcf9a18
    // 0xcf9a14: mov             v1.16b, v0.16b
    // 0xcf9a18: ldr             x1, [fp, #0x28]
    // 0xcf9a1c: ldur            x0, [fp, #-8]
    // 0xcf9a20: stur            d1, [fp, #-0x38]
    // 0xcf9a24: LoadField: r2 = r1->field_17
    //     0xcf9a24: ldur            w2, [x1, #0x17]
    // 0xcf9a28: DecompressPointer r2
    //     0xcf9a28: add             x2, x2, HEAP, lsl #32
    // 0xcf9a2c: stur            x2, [fp, #-0x10]
    // 0xcf9a30: r0 = Semantics()
    //     0xcf9a30: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0xcf9a34: stur            x0, [fp, #-0x18]
    // 0xcf9a38: r16 = true
    //     0xcf9a38: add             x16, NULL, #0x20  ; true
    // 0xcf9a3c: stp             x16, x0, [SP, #-0x10]!
    // 0xcf9a40: ldur            x16, [fp, #-0x10]
    // 0xcf9a44: SaveReg r16
    //     0xcf9a44: str             x16, [SP, #-8]!
    // 0xcf9a48: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, header, 0x1, null]
    //     0xcf9a48: add             x4, PP, #0x55, lsl #12  ; [pp+0x558f8] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "header", 0x1, Null]
    //     0xcf9a4c: ldr             x4, [x4, #0x8f8]
    // 0xcf9a50: r0 = Semantics()
    //     0xcf9a50: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xcf9a54: add             SP, SP, #0x18
    // 0xcf9a58: ldur            x0, [fp, #-8]
    // 0xcf9a5c: tbnz            w0, #4, #0xcf9a68
    // 0xcf9a60: r1 = Null
    //     0xcf9a60: mov             x1, NULL
    // 0xcf9a64: b               #0xcf9a6c
    // 0xcf9a68: r1 = 0.000000
    //     0xcf9a68: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xcf9a6c: ldur            d2, [fp, #-0x30]
    // 0xcf9a70: ldur            d1, [fp, #-0x38]
    // 0xcf9a74: ldur            d0, [fp, #-0x28]
    // 0xcf9a78: stur            x1, [fp, #-0x10]
    // 0xcf9a7c: r0 = AppBar()
    //     0xcf9a7c: bl              #0x8b7990  ; AllocateAppBarStub -> AppBar (size=0x90)
    // 0xcf9a80: stur            x0, [fp, #-0x20]
    // 0xcf9a84: r16 = false
    //     0xcf9a84: add             x16, NULL, #0x30  ; false
    // 0xcf9a88: stp             x16, x0, [SP, #-0x10]!
    // 0xcf9a8c: ldur            x16, [fp, #-0x18]
    // 0xcf9a90: stp             x16, NULL, [SP, #-0x10]!
    // 0xcf9a94: ldur            x16, [fp, #-0x10]
    // 0xcf9a98: stp             NULL, x16, [SP, #-0x10]!
    // 0xcf9a9c: r16 = 1.000000
    //     0xcf9a9c: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xcf9aa0: stp             x16, NULL, [SP, #-0x10]!
    // 0xcf9aa4: r16 = 1.000000
    //     0xcf9aa4: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xcf9aa8: r30 = 56.000000
    //     0xcf9aa8: add             lr, PP, #0x2c, lsl #12  ; [pp+0x2c7c8] 56
    //     0xcf9aac: ldr             lr, [lr, #0x7c8]
    // 0xcf9ab0: stp             lr, x16, [SP, #-0x10]!
    // 0xcf9ab4: SaveReg rNULL
    //     0xcf9ab4: str             NULL, [SP, #-8]!
    // 0xcf9ab8: r4 = const [0, 0xb, 0xb, 0x1, automaticallyImplyLeading, 0x1, backgroundColor, 0x5, bottomOpacity, 0x8, centerTitle, 0x6, elevation, 0x4, flexibleSpace, 0x3, leadingWidth, 0xa, title, 0x2, toolbarHeight, 0x9, toolbarOpacity, 0x7, null]
    //     0xcf9ab8: add             x4, PP, #0x55, lsl #12  ; [pp+0x55900] List(25) [0, 0xb, 0xb, 0x1, "automaticallyImplyLeading", 0x1, "backgroundColor", 0x5, "bottomOpacity", 0x8, "centerTitle", 0x6, "elevation", 0x4, "flexibleSpace", 0x3, "leadingWidth", 0xa, "title", 0x2, "toolbarHeight", 0x9, "toolbarOpacity", 0x7, Null]
    //     0xcf9abc: ldr             x4, [x4, #0x900]
    // 0xcf9ac0: r0 = AppBar()
    //     0xcf9ac0: bl              #0x8b743c  ; [package:flutter/src/material/app_bar.dart] AppBar::AppBar
    // 0xcf9ac4: add             SP, SP, #0x58
    // 0xcf9ac8: ldur            d0, [fp, #-0x28]
    // 0xcf9acc: r0 = inline_Allocate_Double()
    //     0xcf9acc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcf9ad0: add             x0, x0, #0x10
    //     0xcf9ad4: cmp             x1, x0
    //     0xcf9ad8: b.ls            #0xcf9b64
    //     0xcf9adc: str             x0, [THR, #0x60]  ; THR::top
    //     0xcf9ae0: sub             x0, x0, #0xf
    //     0xcf9ae4: mov             x1, #0xd108
    //     0xcf9ae8: movk            x1, #3, lsl #16
    //     0xcf9aec: stur            x1, [x0, #-1]
    // 0xcf9af0: StoreField: r0->field_7 = d0
    //     0xcf9af0: stur            d0, [x0, #7]
    // 0xcf9af4: ldur            d0, [fp, #-0x30]
    // 0xcf9af8: r1 = inline_Allocate_Double()
    //     0xcf9af8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcf9afc: add             x1, x1, #0x10
    //     0xcf9b00: cmp             x2, x1
    //     0xcf9b04: b.ls            #0xcf9b74
    //     0xcf9b08: str             x1, [THR, #0x60]  ; THR::top
    //     0xcf9b0c: sub             x1, x1, #0xf
    //     0xcf9b10: mov             x2, #0xd108
    //     0xcf9b14: movk            x2, #3, lsl #16
    //     0xcf9b18: stur            x2, [x1, #-1]
    // 0xcf9b1c: StoreField: r1->field_7 = d0
    //     0xcf9b1c: stur            d0, [x1, #7]
    // 0xcf9b20: ldur            x16, [fp, #-0x20]
    // 0xcf9b24: SaveReg r16
    //     0xcf9b24: str             x16, [SP, #-8]!
    // 0xcf9b28: ldur            d0, [fp, #-0x38]
    // 0xcf9b2c: SaveReg d0
    //     0xcf9b2c: str             d0, [SP, #-8]!
    // 0xcf9b30: stp             x1, x0, [SP, #-0x10]!
    // 0xcf9b34: r16 = 1.000000
    //     0xcf9b34: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xcf9b38: ldur            lr, [fp, #-8]
    // 0xcf9b3c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf9b40: r4 = const [0, 0x6, 0x6, 0x2, isScrolledUnder, 0x5, maxExtent, 0x3, minExtent, 0x2, toolbarOpacity, 0x4, null]
    //     0xcf9b40: add             x4, PP, #0x55, lsl #12  ; [pp+0x55908] List(13) [0, 0x6, 0x6, 0x2, "isScrolledUnder", 0x5, "maxExtent", 0x3, "minExtent", 0x2, "toolbarOpacity", 0x4, Null]
    //     0xcf9b44: ldr             x4, [x4, #0x908]
    // 0xcf9b48: r0 = createSettings()
    //     0xcf9b48: bl              #0x8656ac  ; [package:flutter/src/material/flexible_space_bar.dart] FlexibleSpaceBar::createSettings
    // 0xcf9b4c: add             SP, SP, #0x30
    // 0xcf9b50: LeaveFrame
    //     0xcf9b50: mov             SP, fp
    //     0xcf9b54: ldp             fp, lr, [SP], #0x10
    // 0xcf9b58: ret
    //     0xcf9b58: ret             
    // 0xcf9b5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf9b5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf9b60: b               #0xcf9924
    // 0xcf9b64: SaveReg d0
    //     0xcf9b64: str             q0, [SP, #-0x10]!
    // 0xcf9b68: r0 = AllocateDouble()
    //     0xcf9b68: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf9b6c: RestoreReg d0
    //     0xcf9b6c: ldr             q0, [SP], #0x10
    // 0xcf9b70: b               #0xcf9af0
    // 0xcf9b74: SaveReg d0
    //     0xcf9b74: str             q0, [SP, #-0x10]!
    // 0xcf9b78: SaveReg r0
    //     0xcf9b78: str             x0, [SP, #-8]!
    // 0xcf9b7c: r0 = AllocateDouble()
    //     0xcf9b7c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf9b80: mov             x1, x0
    // 0xcf9b84: RestoreReg r0
    //     0xcf9b84: ldr             x0, [SP], #8
    // 0xcf9b88: RestoreReg d0
    //     0xcf9b88: ldr             q0, [SP], #0x10
    // 0xcf9b8c: b               #0xcf9b1c
  }
  get _ maxExtent(/* No info */) {
    // ** addr: 0xcf9c9c, size: 0x70
    // 0xcf9c9c: ldr             x0, [SP]
    // 0xcf9ca0: LoadField: d1 = r0->field_6b
    //     0xcf9ca0: ldur            d1, [x0, #0x6b]
    // 0xcf9ca4: LoadField: d2 = r0->field_5b
    //     0xcf9ca4: ldur            d2, [x0, #0x5b]
    // 0xcf9ca8: fadd            d3, d1, d2
    // 0xcf9cac: LoadField: d1 = r0->field_63
    //     0xcf9cac: ldur            d1, [x0, #0x63]
    // 0xcf9cb0: fcmp            d3, d1
    // 0xcf9cb4: b.vs            #0xcf9cc4
    // 0xcf9cb8: b.le            #0xcf9cc4
    // 0xcf9cbc: mov             v0.16b, v3.16b
    // 0xcf9cc0: b               #0xcf9d08
    // 0xcf9cc4: fcmp            d3, d1
    // 0xcf9cc8: b.vs            #0xcf9cd8
    // 0xcf9ccc: b.ge            #0xcf9cd8
    // 0xcf9cd0: mov             v0.16b, v1.16b
    // 0xcf9cd4: b               #0xcf9d08
    // 0xcf9cd8: d2 = 0.000000
    //     0xcf9cd8: eor             v2.16b, v2.16b, v2.16b
    // 0xcf9cdc: fcmp            d3, d2
    // 0xcf9ce0: b.vs            #0xcf9cf4
    // 0xcf9ce4: b.ne            #0xcf9cf4
    // 0xcf9ce8: fadd            d2, d3, d1
    // 0xcf9cec: mov             v0.16b, v2.16b
    // 0xcf9cf0: b               #0xcf9d08
    // 0xcf9cf4: fcmp            d1, d1
    // 0xcf9cf8: b.vc            #0xcf9d04
    // 0xcf9cfc: mov             v0.16b, v1.16b
    // 0xcf9d00: b               #0xcf9d08
    // 0xcf9d04: mov             v0.16b, v3.16b
    // 0xcf9d08: ret
    //     0xcf9d08: ret             
  }
  get _ minExtent(/* No info */) {
    // ** addr: 0xcf9d0c, size: 0xc
    // 0xcf9d0c: ldr             x0, [SP]
    // 0xcf9d10: LoadField: d0 = r0->field_63
    //     0xcf9d10: ldur            d0, [x0, #0x63]
    // 0xcf9d14: ret
    //     0xcf9d14: ret             
  }
}

// class id: 2247, size: 0x14, field offset: 0xc
//   const constructor, 
class _ToolbarContainerLayout extends SingleChildLayoutDelegate {

  _ shouldRelayout(/* No info */) {
    // ** addr: 0xb1017c, size: 0x6c
    // 0xb1017c: EnterFrame
    //     0xb1017c: stp             fp, lr, [SP, #-0x10]!
    //     0xb10180: mov             fp, SP
    // 0xb10184: ldr             x0, [fp, #0x10]
    // 0xb10188: r2 = Null
    //     0xb10188: mov             x2, NULL
    // 0xb1018c: r1 = Null
    //     0xb1018c: mov             x1, NULL
    // 0xb10190: r4 = 59
    //     0xb10190: mov             x4, #0x3b
    // 0xb10194: branchIfSmi(r0, 0xb101a0)
    //     0xb10194: tbz             w0, #0, #0xb101a0
    // 0xb10198: r4 = LoadClassIdInstr(r0)
    //     0xb10198: ldur            x4, [x0, #-1]
    //     0xb1019c: ubfx            x4, x4, #0xc, #0x14
    // 0xb101a0: cmp             x4, #0x8c7
    // 0xb101a4: b.eq            #0xb101bc
    // 0xb101a8: r8 = _ToolbarContainerLayout
    //     0xb101a8: add             x8, PP, #0x40, lsl #12  ; [pp+0x402f0] Type: _ToolbarContainerLayout
    //     0xb101ac: ldr             x8, [x8, #0x2f0]
    // 0xb101b0: r3 = Null
    //     0xb101b0: add             x3, PP, #0x40, lsl #12  ; [pp+0x402f8] Null
    //     0xb101b4: ldr             x3, [x3, #0x2f8]
    // 0xb101b8: r0 = DefaultTypeTest()
    //     0xb101b8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xb101bc: ldr             x1, [fp, #0x18]
    // 0xb101c0: LoadField: d0 = r1->field_b
    //     0xb101c0: ldur            d0, [x1, #0xb]
    // 0xb101c4: ldr             x1, [fp, #0x10]
    // 0xb101c8: LoadField: d1 = r1->field_b
    //     0xb101c8: ldur            d1, [x1, #0xb]
    // 0xb101cc: fcmp            d0, d1
    // 0xb101d0: r16 = true
    //     0xb101d0: add             x16, NULL, #0x20  ; true
    // 0xb101d4: r17 = false
    //     0xb101d4: add             x17, NULL, #0x30  ; false
    // 0xb101d8: csel            x0, x16, x17, ne
    // 0xb101dc: LeaveFrame
    //     0xb101dc: mov             SP, fp
    //     0xb101e0: ldp             fp, lr, [SP], #0x10
    // 0xb101e4: ret
    //     0xb101e4: ret             
  }
  _ getPositionForChild(/* No info */) {
    // ** addr: 0xb10d64, size: 0x44
    // 0xb10d64: EnterFrame
    //     0xb10d64: stp             fp, lr, [SP, #-0x10]!
    //     0xb10d68: mov             fp, SP
    // 0xb10d6c: AllocStack(0x8)
    //     0xb10d6c: sub             SP, SP, #8
    // 0xb10d70: ldr             x0, [fp, #0x18]
    // 0xb10d74: LoadField: d0 = r0->field_f
    //     0xb10d74: ldur            d0, [x0, #0xf]
    // 0xb10d78: ldr             x0, [fp, #0x10]
    // 0xb10d7c: LoadField: d1 = r0->field_f
    //     0xb10d7c: ldur            d1, [x0, #0xf]
    // 0xb10d80: fsub            d2, d0, d1
    // 0xb10d84: stur            d2, [fp, #-8]
    // 0xb10d88: r0 = Offset()
    //     0xb10d88: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb10d8c: d0 = 0.000000
    //     0xb10d8c: eor             v0.16b, v0.16b, v0.16b
    // 0xb10d90: StoreField: r0->field_7 = d0
    //     0xb10d90: stur            d0, [x0, #7]
    // 0xb10d94: ldur            d0, [fp, #-8]
    // 0xb10d98: StoreField: r0->field_f = d0
    //     0xb10d98: stur            d0, [x0, #0xf]
    // 0xb10d9c: LeaveFrame
    //     0xb10d9c: mov             SP, fp
    //     0xb10da0: ldp             fp, lr, [SP], #0x10
    // 0xb10da4: ret
    //     0xb10da4: ret             
  }
  _ getSize(/* No info */) {
    // ** addr: 0xbd7868, size: 0x44
    // 0xbd7868: EnterFrame
    //     0xbd7868: stp             fp, lr, [SP, #-0x10]!
    //     0xbd786c: mov             fp, SP
    // 0xbd7870: AllocStack(0x10)
    //     0xbd7870: sub             SP, SP, #0x10
    // 0xbd7874: ldr             x0, [fp, #0x10]
    // 0xbd7878: LoadField: d0 = r0->field_f
    //     0xbd7878: ldur            d0, [x0, #0xf]
    // 0xbd787c: ldr             x0, [fp, #0x18]
    // 0xbd7880: stur            d0, [fp, #-0x10]
    // 0xbd7884: LoadField: d1 = r0->field_b
    //     0xbd7884: ldur            d1, [x0, #0xb]
    // 0xbd7888: stur            d1, [fp, #-8]
    // 0xbd788c: r0 = Size()
    //     0xbd788c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbd7890: ldur            d0, [fp, #-0x10]
    // 0xbd7894: StoreField: r0->field_7 = d0
    //     0xbd7894: stur            d0, [x0, #7]
    // 0xbd7898: ldur            d0, [fp, #-8]
    // 0xbd789c: StoreField: r0->field_f = d0
    //     0xbd789c: stur            d0, [x0, #0xf]
    // 0xbd78a0: LeaveFrame
    //     0xbd78a0: mov             SP, fp
    //     0xbd78a4: ldp             fp, lr, [SP], #0x10
    // 0xbd78a8: ret
    //     0xbd78a8: ret             
  }
  _ getConstraintsForChild(/* No info */) {
    // ** addr: 0xbd9714, size: 0x80
    // 0xbd9714: EnterFrame
    //     0xbd9714: stp             fp, lr, [SP, #-0x10]!
    //     0xbd9718: mov             fp, SP
    // 0xbd971c: CheckStackOverflow
    //     0xbd971c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd9720: cmp             SP, x16
    //     0xbd9724: b.ls            #0xbd977c
    // 0xbd9728: ldr             x0, [fp, #0x18]
    // 0xbd972c: LoadField: d0 = r0->field_b
    //     0xbd972c: ldur            d0, [x0, #0xb]
    // 0xbd9730: r0 = inline_Allocate_Double()
    //     0xbd9730: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbd9734: add             x0, x0, #0x10
    //     0xbd9738: cmp             x1, x0
    //     0xbd973c: b.ls            #0xbd9784
    //     0xbd9740: str             x0, [THR, #0x60]  ; THR::top
    //     0xbd9744: sub             x0, x0, #0xf
    //     0xbd9748: mov             x1, #0xd108
    //     0xbd974c: movk            x1, #3, lsl #16
    //     0xbd9750: stur            x1, [x0, #-1]
    // 0xbd9754: StoreField: r0->field_7 = d0
    //     0xbd9754: stur            d0, [x0, #7]
    // 0xbd9758: ldr             x16, [fp, #0x10]
    // 0xbd975c: stp             x0, x16, [SP, #-0x10]!
    // 0xbd9760: r4 = const [0, 0x2, 0x2, 0x1, height, 0x1, null]
    //     0xbd9760: add             x4, PP, #0x21, lsl #12  ; [pp+0x21620] List(7) [0, 0x2, 0x2, 0x1, "height", 0x1, Null]
    //     0xbd9764: ldr             x4, [x4, #0x620]
    // 0xbd9768: r0 = tighten()
    //     0xbd9768: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0xbd976c: add             SP, SP, #0x10
    // 0xbd9770: LeaveFrame
    //     0xbd9770: mov             SP, fp
    //     0xbd9774: ldp             fp, lr, [SP], #0x10
    // 0xbd9778: ret
    //     0xbd9778: ret             
    // 0xbd977c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd977c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd9780: b               #0xbd9728
    // 0xbd9784: SaveReg d0
    //     0xbd9784: str             q0, [SP, #-0x10]!
    // 0xbd9788: r0 = AllocateDouble()
    //     0xbd9788: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbd978c: RestoreReg d0
    //     0xbd978c: ldr             q0, [SP], #0x10
    // 0xbd9790: b               #0xbd9754
  }
}

// class id: 2471, size: 0x70, field offset: 0x70
class _RenderAppBarTitleBox extends RenderAligningShiftedBox {

  _ performLayout(/* No info */) {
    // ** addr: 0x690470, size: 0x1dc
    // 0x690470: EnterFrame
    //     0x690470: stp             fp, lr, [SP, #-0x10]!
    //     0x690474: mov             fp, SP
    // 0x690478: AllocStack(0x8)
    //     0x690478: sub             SP, SP, #8
    // 0x69047c: CheckStackOverflow
    //     0x69047c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x690480: cmp             SP, x16
    //     0x690484: b.ls            #0x690638
    // 0x690488: ldr             x3, [fp, #0x10]
    // 0x69048c: LoadField: r4 = r3->field_27
    //     0x69048c: ldur            w4, [x3, #0x27]
    // 0x690490: DecompressPointer r4
    //     0x690490: add             x4, x4, HEAP, lsl #32
    // 0x690494: stur            x4, [fp, #-8]
    // 0x690498: cmp             w4, NULL
    // 0x69049c: b.eq            #0x690600
    // 0x6904a0: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6904a0: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6904a4: ldr             x5, [x5, #0x1e8]
    // 0x6904a8: mov             x0, x4
    // 0x6904ac: r2 = Null
    //     0x6904ac: mov             x2, NULL
    // 0x6904b0: r1 = Null
    //     0x6904b0: mov             x1, NULL
    // 0x6904b4: r4 = LoadClassIdInstr(r0)
    //     0x6904b4: ldur            x4, [x0, #-1]
    //     0x6904b8: ubfx            x4, x4, #0xc, #0x14
    // 0x6904bc: sub             x4, x4, #0x80d
    // 0x6904c0: cmp             x4, #1
    // 0x6904c4: b.ls            #0x6904dc
    // 0x6904c8: r8 = BoxConstraints
    //     0x6904c8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6904cc: ldr             x8, [x8, #0x1d0]
    // 0x6904d0: r3 = Null
    //     0x6904d0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b948] Null
    //     0x6904d4: ldr             x3, [x3, #0x948]
    // 0x6904d8: r0 = BoxConstraints()
    //     0x6904d8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6904dc: ldur            x16, [fp, #-8]
    // 0x6904e0: r30 = inf
    //     0x6904e0: add             lr, PP, #0xf, lsl #12  ; [pp+0xf218] inf
    //     0x6904e4: ldr             lr, [lr, #0x218]
    // 0x6904e8: stp             lr, x16, [SP, #-0x10]!
    // 0x6904ec: r4 = const [0, 0x2, 0x2, 0x1, maxHeight, 0x1, null]
    //     0x6904ec: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4b958] List(7) [0, 0x2, 0x2, 0x1, "maxHeight", 0x1, Null]
    //     0x6904f0: ldr             x4, [x4, #0x958]
    // 0x6904f4: r0 = copyWith()
    //     0x6904f4: bl              #0x690914  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0x6904f8: add             SP, SP, #0x10
    // 0x6904fc: ldr             x1, [fp, #0x10]
    // 0x690500: LoadField: r2 = r1->field_5f
    //     0x690500: ldur            w2, [x1, #0x5f]
    // 0x690504: DecompressPointer r2
    //     0x690504: add             x2, x2, HEAP, lsl #32
    // 0x690508: cmp             w2, NULL
    // 0x69050c: b.eq            #0x690640
    // 0x690510: r3 = LoadClassIdInstr(r2)
    //     0x690510: ldur            x3, [x2, #-1]
    //     0x690514: ubfx            x3, x3, #0xc, #0x14
    // 0x690518: stp             x0, x2, [SP, #-0x10]!
    // 0x69051c: r16 = true
    //     0x69051c: add             x16, NULL, #0x20  ; true
    // 0x690520: SaveReg r16
    //     0x690520: str             x16, [SP, #-8]!
    // 0x690524: mov             x0, x3
    // 0x690528: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x690528: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x69052c: ldr             x4, [x4, #0x1c8]
    // 0x690530: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x690530: mov             x17, #0xcdfb
    //     0x690534: add             lr, x0, x17
    //     0x690538: ldr             lr, [x21, lr, lsl #3]
    //     0x69053c: blr             lr
    // 0x690540: add             SP, SP, #0x18
    // 0x690544: ldr             x3, [fp, #0x10]
    // 0x690548: LoadField: r4 = r3->field_27
    //     0x690548: ldur            w4, [x3, #0x27]
    // 0x69054c: DecompressPointer r4
    //     0x69054c: add             x4, x4, HEAP, lsl #32
    // 0x690550: stur            x4, [fp, #-8]
    // 0x690554: cmp             w4, NULL
    // 0x690558: b.eq            #0x690618
    // 0x69055c: mov             x0, x4
    // 0x690560: r2 = Null
    //     0x690560: mov             x2, NULL
    // 0x690564: r1 = Null
    //     0x690564: mov             x1, NULL
    // 0x690568: r4 = LoadClassIdInstr(r0)
    //     0x690568: ldur            x4, [x0, #-1]
    //     0x69056c: ubfx            x4, x4, #0xc, #0x14
    // 0x690570: sub             x4, x4, #0x80d
    // 0x690574: cmp             x4, #1
    // 0x690578: b.ls            #0x690590
    // 0x69057c: r8 = BoxConstraints
    //     0x69057c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x690580: ldr             x8, [x8, #0x1d0]
    // 0x690584: r3 = Null
    //     0x690584: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b960] Null
    //     0x690588: ldr             x3, [x3, #0x960]
    // 0x69058c: r0 = BoxConstraints()
    //     0x69058c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x690590: ldr             x0, [fp, #0x10]
    // 0x690594: LoadField: r1 = r0->field_5f
    //     0x690594: ldur            w1, [x0, #0x5f]
    // 0x690598: DecompressPointer r1
    //     0x690598: add             x1, x1, HEAP, lsl #32
    // 0x69059c: cmp             w1, NULL
    // 0x6905a0: b.eq            #0x690644
    // 0x6905a4: LoadField: r2 = r1->field_57
    //     0x6905a4: ldur            w2, [x1, #0x57]
    // 0x6905a8: DecompressPointer r2
    //     0x6905a8: add             x2, x2, HEAP, lsl #32
    // 0x6905ac: cmp             w2, NULL
    // 0x6905b0: b.eq            #0x690648
    // 0x6905b4: ldur            x16, [fp, #-8]
    // 0x6905b8: stp             x2, x16, [SP, #-0x10]!
    // 0x6905bc: r0 = constrain()
    //     0x6905bc: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x6905c0: add             SP, SP, #0x10
    // 0x6905c4: ldr             x1, [fp, #0x10]
    // 0x6905c8: StoreField: r1->field_57 = r0
    //     0x6905c8: stur            w0, [x1, #0x57]
    //     0x6905cc: ldurb           w16, [x1, #-1]
    //     0x6905d0: ldurb           w17, [x0, #-1]
    //     0x6905d4: and             x16, x17, x16, lsr #2
    //     0x6905d8: tst             x16, HEAP, lsr #32
    //     0x6905dc: b.eq            #0x6905e4
    //     0x6905e0: bl              #0xd6826c
    // 0x6905e4: SaveReg r1
    //     0x6905e4: str             x1, [SP, #-8]!
    // 0x6905e8: r0 = alignChild()
    //     0x6905e8: bl              #0x69064c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0x6905ec: add             SP, SP, #8
    // 0x6905f0: r0 = Null
    //     0x6905f0: mov             x0, NULL
    // 0x6905f4: LeaveFrame
    //     0x6905f4: mov             SP, fp
    //     0x6905f8: ldp             fp, lr, [SP], #0x10
    // 0x6905fc: ret
    //     0x6905fc: ret             
    // 0x690600: r0 = StateError()
    //     0x690600: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x690604: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x690604: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x690608: ldr             x5, [x5, #0x1e8]
    // 0x69060c: StoreField: r0->field_b = r5
    //     0x69060c: stur            w5, [x0, #0xb]
    // 0x690610: r0 = Throw()
    //     0x690610: bl              #0xd67e38  ; ThrowStub
    // 0x690614: brk             #0
    // 0x690618: r0 = StateError()
    //     0x690618: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x69061c: mov             x1, x0
    // 0x690620: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x690620: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x690624: ldr             x0, [x0, #0x1e8]
    // 0x690628: StoreField: r1->field_b = r0
    //     0x690628: stur            w0, [x1, #0xb]
    // 0x69062c: mov             x0, x1
    // 0x690630: r0 = Throw()
    //     0x690630: bl              #0xd67e38  ; ThrowStub
    // 0x690634: brk             #0
    // 0x690638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x690638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69063c: b               #0x690488
    // 0x690640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690640: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x690644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690644: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x690648: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690648: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5d9e8, size: 0x80
    // 0xa5d9e8: EnterFrame
    //     0xa5d9e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa5d9ec: mov             fp, SP
    // 0xa5d9f0: CheckStackOverflow
    //     0xa5d9f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5d9f4: cmp             SP, x16
    //     0xa5d9f8: b.ls            #0xa5da5c
    // 0xa5d9fc: ldr             x16, [fp, #0x10]
    // 0xa5da00: r30 = inf
    //     0xa5da00: add             lr, PP, #0xf, lsl #12  ; [pp+0xf218] inf
    //     0xa5da04: ldr             lr, [lr, #0x218]
    // 0xa5da08: stp             lr, x16, [SP, #-0x10]!
    // 0xa5da0c: r4 = const [0, 0x2, 0x2, 0x1, maxHeight, 0x1, null]
    //     0xa5da0c: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4b958] List(7) [0, 0x2, 0x2, 0x1, "maxHeight", 0x1, Null]
    //     0xa5da10: ldr             x4, [x4, #0x958]
    // 0xa5da14: r0 = copyWith()
    //     0xa5da14: bl              #0x690914  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0xa5da18: add             SP, SP, #0x10
    // 0xa5da1c: mov             x1, x0
    // 0xa5da20: ldr             x0, [fp, #0x18]
    // 0xa5da24: LoadField: r2 = r0->field_5f
    //     0xa5da24: ldur            w2, [x0, #0x5f]
    // 0xa5da28: DecompressPointer r2
    //     0xa5da28: add             x2, x2, HEAP, lsl #32
    // 0xa5da2c: cmp             w2, NULL
    // 0xa5da30: b.eq            #0xa5da64
    // 0xa5da34: stp             x1, x2, [SP, #-0x10]!
    // 0xa5da38: r0 = getDryLayout()
    //     0xa5da38: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5da3c: add             SP, SP, #0x10
    // 0xa5da40: ldr             x16, [fp, #0x10]
    // 0xa5da44: stp             x0, x16, [SP, #-0x10]!
    // 0xa5da48: r0 = constrain()
    //     0xa5da48: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xa5da4c: add             SP, SP, #0x10
    // 0xa5da50: LeaveFrame
    //     0xa5da50: mov             SP, fp
    //     0xa5da54: ldp             fp, lr, [SP], #0x10
    // 0xa5da58: ret
    //     0xa5da58: ret             
    // 0xa5da5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5da5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5da60: b               #0xa5d9fc
    // 0xa5da64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5da64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2842, size: 0x60, field offset: 0x50
class _AppBarDefaultsM3 extends AppBarTheme {

  late final ColorScheme _colors; // offset: 0x58
  late final TextTheme _textTheme; // offset: 0x5c
  late final ThemeData _theme; // offset: 0x54

  TextTheme _textTheme(_AppBarDefaultsM3) {
    // ** addr: 0x849084, size: 0x58
    // 0x849084: EnterFrame
    //     0x849084: stp             fp, lr, [SP, #-0x10]!
    //     0x849088: mov             fp, SP
    // 0x84908c: CheckStackOverflow
    //     0x84908c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x849090: cmp             SP, x16
    //     0x849094: b.ls            #0x8490d4
    // 0x849098: ldr             x1, [fp, #0x10]
    // 0x84909c: LoadField: r0 = r1->field_53
    //     0x84909c: ldur            w0, [x1, #0x53]
    // 0x8490a0: DecompressPointer r0
    //     0x8490a0: add             x0, x0, HEAP, lsl #32
    // 0x8490a4: r16 = Sentinel
    //     0x8490a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8490a8: cmp             w0, w16
    // 0x8490ac: b.ne            #0x8490bc
    // 0x8490b0: r2 = _theme
    //     0x8490b0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d8] Field <_AppBarDefaultsM3@680187611._theme@680187611>: late final (offset: 0x54)
    //     0x8490b4: ldr             x2, [x2, #0x4d8]
    // 0x8490b8: r0 = InitLateFinalInstanceField()
    //     0x8490b8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x8490bc: LoadField: r1 = r0->field_93
    //     0x8490bc: ldur            w1, [x0, #0x93]
    // 0x8490c0: DecompressPointer r1
    //     0x8490c0: add             x1, x1, HEAP, lsl #32
    // 0x8490c4: mov             x0, x1
    // 0x8490c8: LeaveFrame
    //     0x8490c8: mov             SP, fp
    //     0x8490cc: ldp             fp, lr, [SP], #0x10
    // 0x8490d0: ret
    //     0x8490d0: ret             
    // 0x8490d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8490d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8490d8: b               #0x849098
  }
  ColorScheme _colors(_AppBarDefaultsM3) {
    // ** addr: 0x849174, size: 0x58
    // 0x849174: EnterFrame
    //     0x849174: stp             fp, lr, [SP, #-0x10]!
    //     0x849178: mov             fp, SP
    // 0x84917c: CheckStackOverflow
    //     0x84917c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x849180: cmp             SP, x16
    //     0x849184: b.ls            #0x8491c4
    // 0x849188: ldr             x1, [fp, #0x10]
    // 0x84918c: LoadField: r0 = r1->field_53
    //     0x84918c: ldur            w0, [x1, #0x53]
    // 0x849190: DecompressPointer r0
    //     0x849190: add             x0, x0, HEAP, lsl #32
    // 0x849194: r16 = Sentinel
    //     0x849194: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x849198: cmp             w0, w16
    // 0x84919c: b.ne            #0x8491ac
    // 0x8491a0: r2 = _theme
    //     0x8491a0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d8] Field <_AppBarDefaultsM3@680187611._theme@680187611>: late final (offset: 0x54)
    //     0x8491a4: ldr             x2, [x2, #0x4d8]
    // 0x8491a8: r0 = InitLateFinalInstanceField()
    //     0x8491a8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x8491ac: LoadField: r1 = r0->field_3f
    //     0x8491ac: ldur            w1, [x0, #0x3f]
    // 0x8491b0: DecompressPointer r1
    //     0x8491b0: add             x1, x1, HEAP, lsl #32
    // 0x8491b4: mov             x0, x1
    // 0x8491b8: LeaveFrame
    //     0x8491b8: mov             SP, fp
    //     0x8491bc: ldp             fp, lr, [SP], #0x10
    // 0x8491c0: ret
    //     0x8491c0: ret             
    // 0x8491c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8491c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8491c8: b               #0x849188
  }
}

// class id: 2843, size: 0x5c, field offset: 0x50
class _AppBarDefaultsM2 extends AppBarTheme {

  late final ColorScheme _colors; // offset: 0x58
  late final ThemeData _theme; // offset: 0x54

  ThemeData _theme(_AppBarDefaultsM2) {
    // ** addr: 0x8490dc, size: 0x40
    // 0x8490dc: EnterFrame
    //     0x8490dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8490e0: mov             fp, SP
    // 0x8490e4: CheckStackOverflow
    //     0x8490e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8490e8: cmp             SP, x16
    //     0x8490ec: b.ls            #0x849114
    // 0x8490f0: ldr             x0, [fp, #0x10]
    // 0x8490f4: LoadField: r1 = r0->field_4f
    //     0x8490f4: ldur            w1, [x0, #0x4f]
    // 0x8490f8: DecompressPointer r1
    //     0x8490f8: add             x1, x1, HEAP, lsl #32
    // 0x8490fc: SaveReg r1
    //     0x8490fc: str             x1, [SP, #-8]!
    // 0x849100: r0 = of()
    //     0x849100: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x849104: add             SP, SP, #8
    // 0x849108: LeaveFrame
    //     0x849108: mov             SP, fp
    //     0x84910c: ldp             fp, lr, [SP], #0x10
    // 0x849110: ret
    //     0x849110: ret             
    // 0x849114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849114: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849118: b               #0x8490f0
  }
  ColorScheme _colors(_AppBarDefaultsM2) {
    // ** addr: 0x84911c, size: 0x58
    // 0x84911c: EnterFrame
    //     0x84911c: stp             fp, lr, [SP, #-0x10]!
    //     0x849120: mov             fp, SP
    // 0x849124: CheckStackOverflow
    //     0x849124: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x849128: cmp             SP, x16
    //     0x84912c: b.ls            #0x84916c
    // 0x849130: ldr             x1, [fp, #0x10]
    // 0x849134: LoadField: r0 = r1->field_53
    //     0x849134: ldur            w0, [x1, #0x53]
    // 0x849138: DecompressPointer r0
    //     0x849138: add             x0, x0, HEAP, lsl #32
    // 0x84913c: r16 = Sentinel
    //     0x84913c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x849140: cmp             w0, w16
    // 0x849144: b.ne            #0x849154
    // 0x849148: r2 = _theme
    //     0x849148: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0x84914c: ldr             x2, [x2, #0x4c8]
    // 0x849150: r0 = InitLateFinalInstanceField()
    //     0x849150: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x849154: LoadField: r1 = r0->field_3f
    //     0x849154: ldur            w1, [x0, #0x3f]
    // 0x849158: DecompressPointer r1
    //     0x849158: add             x1, x1, HEAP, lsl #32
    // 0x84915c: mov             x0, x1
    // 0x849160: LeaveFrame
    //     0x849160: mov             SP, fp
    //     0x849164: ldp             fp, lr, [SP], #0x10
    // 0x849168: ret
    //     0x849168: ret             
    // 0x84916c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84916c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849170: b               #0x849130
  }
}

// class id: 3340, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __SliverAppBarState&State&TickerProviderStateMixin extends State<SliverAppBar>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x615e8c, size: 0x178
    // 0x615e8c: EnterFrame
    //     0x615e8c: stp             fp, lr, [SP, #-0x10]!
    //     0x615e90: mov             fp, SP
    // 0x615e94: AllocStack(0x10)
    //     0x615e94: sub             SP, SP, #0x10
    // 0x615e98: CheckStackOverflow
    //     0x615e98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615e9c: cmp             SP, x16
    //     0x615ea0: b.ls            #0x615ff4
    // 0x615ea4: ldr             x0, [fp, #0x18]
    // 0x615ea8: LoadField: r1 = r0->field_17
    //     0x615ea8: ldur            w1, [x0, #0x17]
    // 0x615eac: DecompressPointer r1
    //     0x615eac: add             x1, x1, HEAP, lsl #32
    // 0x615eb0: cmp             w1, NULL
    // 0x615eb4: b.ne            #0x615ec4
    // 0x615eb8: SaveReg r0
    //     0x615eb8: str             x0, [SP, #-8]!
    // 0x615ebc: r0 = _updateTickerModeNotifier()
    //     0x615ebc: bl              #0x616028  ; [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x615ec0: add             SP, SP, #8
    // 0x615ec4: ldr             x0, [fp, #0x18]
    // 0x615ec8: LoadField: r1 = r0->field_13
    //     0x615ec8: ldur            w1, [x0, #0x13]
    // 0x615ecc: DecompressPointer r1
    //     0x615ecc: add             x1, x1, HEAP, lsl #32
    // 0x615ed0: cmp             w1, NULL
    // 0x615ed4: b.ne            #0x615f6c
    // 0x615ed8: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x615ed8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x615edc: ldr             x0, [x0, #0x598]
    //     0x615ee0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x615ee4: cmp             w0, w16
    //     0x615ee8: b.ne            #0x615ef4
    //     0x615eec: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x615ef0: bl              #0xd67cdc
    // 0x615ef4: r1 = <_WidgetTicker>
    //     0x615ef4: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x615ef8: ldr             x1, [x1, #0x210]
    // 0x615efc: stur            x0, [fp, #-8]
    // 0x615f00: r0 = _Set()
    //     0x615f00: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x615f04: mov             x1, x0
    // 0x615f08: ldur            x0, [fp, #-8]
    // 0x615f0c: stur            x1, [fp, #-0x10]
    // 0x615f10: StoreField: r1->field_1b = r0
    //     0x615f10: stur            w0, [x1, #0x1b]
    // 0x615f14: StoreField: r1->field_b = rZR
    //     0x615f14: stur            wzr, [x1, #0xb]
    // 0x615f18: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x615f18: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x615f1c: ldr             x0, [x0, #0x5a0]
    //     0x615f20: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x615f24: cmp             w0, w16
    //     0x615f28: b.ne            #0x615f34
    //     0x615f2c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x615f30: bl              #0xd67cdc
    // 0x615f34: mov             x1, x0
    // 0x615f38: ldur            x0, [fp, #-0x10]
    // 0x615f3c: StoreField: r0->field_f = r1
    //     0x615f3c: stur            w1, [x0, #0xf]
    // 0x615f40: StoreField: r0->field_13 = rZR
    //     0x615f40: stur            wzr, [x0, #0x13]
    // 0x615f44: StoreField: r0->field_17 = rZR
    //     0x615f44: stur            wzr, [x0, #0x17]
    // 0x615f48: ldr             x1, [fp, #0x18]
    // 0x615f4c: StoreField: r1->field_13 = r0
    //     0x615f4c: stur            w0, [x1, #0x13]
    //     0x615f50: ldurb           w16, [x1, #-1]
    //     0x615f54: ldurb           w17, [x0, #-1]
    //     0x615f58: and             x16, x17, x16, lsr #2
    //     0x615f5c: tst             x16, HEAP, lsr #32
    //     0x615f60: b.eq            #0x615f68
    //     0x615f64: bl              #0xd6826c
    // 0x615f68: b               #0x615f70
    // 0x615f6c: mov             x1, x0
    // 0x615f70: ldr             x0, [fp, #0x10]
    // 0x615f74: r0 = _WidgetTicker()
    //     0x615f74: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x615f78: mov             x1, x0
    // 0x615f7c: ldr             x0, [fp, #0x18]
    // 0x615f80: stur            x1, [fp, #-8]
    // 0x615f84: StoreField: r1->field_1b = r0
    //     0x615f84: stur            w0, [x1, #0x1b]
    // 0x615f88: r2 = false
    //     0x615f88: add             x2, NULL, #0x30  ; false
    // 0x615f8c: StoreField: r1->field_b = r2
    //     0x615f8c: stur            w2, [x1, #0xb]
    // 0x615f90: ldr             x2, [fp, #0x10]
    // 0x615f94: StoreField: r1->field_13 = r2
    //     0x615f94: stur            w2, [x1, #0x13]
    // 0x615f98: LoadField: r2 = r0->field_17
    //     0x615f98: ldur            w2, [x0, #0x17]
    // 0x615f9c: DecompressPointer r2
    //     0x615f9c: add             x2, x2, HEAP, lsl #32
    // 0x615fa0: cmp             w2, NULL
    // 0x615fa4: b.eq            #0x615ffc
    // 0x615fa8: LoadField: r3 = r2->field_27
    //     0x615fa8: ldur            w3, [x2, #0x27]
    // 0x615fac: DecompressPointer r3
    //     0x615fac: add             x3, x3, HEAP, lsl #32
    // 0x615fb0: eor             x2, x3, #0x10
    // 0x615fb4: stp             x2, x1, [SP, #-0x10]!
    // 0x615fb8: r0 = muted=()
    //     0x615fb8: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x615fbc: add             SP, SP, #0x10
    // 0x615fc0: ldr             x0, [fp, #0x18]
    // 0x615fc4: LoadField: r1 = r0->field_13
    //     0x615fc4: ldur            w1, [x0, #0x13]
    // 0x615fc8: DecompressPointer r1
    //     0x615fc8: add             x1, x1, HEAP, lsl #32
    // 0x615fcc: cmp             w1, NULL
    // 0x615fd0: b.eq            #0x616000
    // 0x615fd4: ldur            x16, [fp, #-8]
    // 0x615fd8: stp             x16, x1, [SP, #-0x10]!
    // 0x615fdc: r0 = add()
    //     0x615fdc: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x615fe0: add             SP, SP, #0x10
    // 0x615fe4: ldur            x0, [fp, #-8]
    // 0x615fe8: LeaveFrame
    //     0x615fe8: mov             SP, fp
    //     0x615fec: ldp             fp, lr, [SP], #0x10
    // 0x615ff0: ret
    //     0x615ff0: ret             
    // 0x615ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615ff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615ff8: b               #0x615ea4
    // 0x615ffc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x615ffc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x616000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616000: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x616028, size: 0x11c
    // 0x616028: EnterFrame
    //     0x616028: stp             fp, lr, [SP, #-0x10]!
    //     0x61602c: mov             fp, SP
    // 0x616030: AllocStack(0x10)
    //     0x616030: sub             SP, SP, #0x10
    // 0x616034: CheckStackOverflow
    //     0x616034: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616038: cmp             SP, x16
    //     0x61603c: b.ls            #0x616138
    // 0x616040: ldr             x0, [fp, #0x10]
    // 0x616044: LoadField: r1 = r0->field_f
    //     0x616044: ldur            w1, [x0, #0xf]
    // 0x616048: DecompressPointer r1
    //     0x616048: add             x1, x1, HEAP, lsl #32
    // 0x61604c: cmp             w1, NULL
    // 0x616050: b.eq            #0x616140
    // 0x616054: SaveReg r1
    //     0x616054: str             x1, [SP, #-8]!
    // 0x616058: r0 = getNotifier()
    //     0x616058: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x61605c: add             SP, SP, #8
    // 0x616060: mov             x1, x0
    // 0x616064: ldr             x0, [fp, #0x10]
    // 0x616068: stur            x1, [fp, #-0x10]
    // 0x61606c: LoadField: r2 = r0->field_17
    //     0x61606c: ldur            w2, [x0, #0x17]
    // 0x616070: DecompressPointer r2
    //     0x616070: add             x2, x2, HEAP, lsl #32
    // 0x616074: stur            x2, [fp, #-8]
    // 0x616078: cmp             w1, w2
    // 0x61607c: b.ne            #0x616090
    // 0x616080: r0 = Null
    //     0x616080: mov             x0, NULL
    // 0x616084: LeaveFrame
    //     0x616084: mov             SP, fp
    //     0x616088: ldp             fp, lr, [SP], #0x10
    // 0x61608c: ret
    //     0x61608c: ret             
    // 0x616090: cmp             w2, NULL
    // 0x616094: b.eq            #0x6160d0
    // 0x616098: r1 = 1
    //     0x616098: mov             x1, #1
    // 0x61609c: r0 = AllocateContext()
    //     0x61609c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6160a0: mov             x1, x0
    // 0x6160a4: ldr             x0, [fp, #0x10]
    // 0x6160a8: StoreField: r1->field_f = r0
    //     0x6160a8: stur            w0, [x1, #0xf]
    // 0x6160ac: mov             x2, x1
    // 0x6160b0: r1 = Function '_updateTickers@156311458':.
    //     0x6160b0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b978] AnonymousClosure: (0x616144), in [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::_updateTickers (0x61618c)
    //     0x6160b4: ldr             x1, [x1, #0x978]
    // 0x6160b8: r0 = AllocateClosure()
    //     0x6160b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6160bc: ldur            x16, [fp, #-8]
    // 0x6160c0: stp             x0, x16, [SP, #-0x10]!
    // 0x6160c4: r0 = removeListener()
    //     0x6160c4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x6160c8: add             SP, SP, #0x10
    // 0x6160cc: ldr             x0, [fp, #0x10]
    // 0x6160d0: r1 = 1
    //     0x6160d0: mov             x1, #1
    // 0x6160d4: r0 = AllocateContext()
    //     0x6160d4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6160d8: mov             x1, x0
    // 0x6160dc: ldr             x0, [fp, #0x10]
    // 0x6160e0: StoreField: r1->field_f = r0
    //     0x6160e0: stur            w0, [x1, #0xf]
    // 0x6160e4: mov             x2, x1
    // 0x6160e8: r1 = Function '_updateTickers@156311458':.
    //     0x6160e8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b978] AnonymousClosure: (0x616144), in [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::_updateTickers (0x61618c)
    //     0x6160ec: ldr             x1, [x1, #0x978]
    // 0x6160f0: r0 = AllocateClosure()
    //     0x6160f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6160f4: ldur            x16, [fp, #-0x10]
    // 0x6160f8: stp             x0, x16, [SP, #-0x10]!
    // 0x6160fc: r0 = addListener()
    //     0x6160fc: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x616100: add             SP, SP, #0x10
    // 0x616104: ldur            x0, [fp, #-0x10]
    // 0x616108: ldr             x1, [fp, #0x10]
    // 0x61610c: StoreField: r1->field_17 = r0
    //     0x61610c: stur            w0, [x1, #0x17]
    //     0x616110: ldurb           w16, [x1, #-1]
    //     0x616114: ldurb           w17, [x0, #-1]
    //     0x616118: and             x16, x17, x16, lsr #2
    //     0x61611c: tst             x16, HEAP, lsr #32
    //     0x616120: b.eq            #0x616128
    //     0x616124: bl              #0xd6826c
    // 0x616128: r0 = Null
    //     0x616128: mov             x0, NULL
    // 0x61612c: LeaveFrame
    //     0x61612c: mov             SP, fp
    //     0x616130: ldp             fp, lr, [SP], #0x10
    // 0x616134: ret
    //     0x616134: ret             
    // 0x616138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616138: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61613c: b               #0x616040
    // 0x616140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616140: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x616144, size: 0x48
    // 0x616144: EnterFrame
    //     0x616144: stp             fp, lr, [SP, #-0x10]!
    //     0x616148: mov             fp, SP
    // 0x61614c: ldr             x0, [fp, #0x10]
    // 0x616150: LoadField: r1 = r0->field_17
    //     0x616150: ldur            w1, [x0, #0x17]
    // 0x616154: DecompressPointer r1
    //     0x616154: add             x1, x1, HEAP, lsl #32
    // 0x616158: CheckStackOverflow
    //     0x616158: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x61615c: cmp             SP, x16
    //     0x616160: b.ls            #0x616184
    // 0x616164: LoadField: r0 = r1->field_f
    //     0x616164: ldur            w0, [x1, #0xf]
    // 0x616168: DecompressPointer r0
    //     0x616168: add             x0, x0, HEAP, lsl #32
    // 0x61616c: SaveReg r0
    //     0x61616c: str             x0, [SP, #-8]!
    // 0x616170: r0 = _updateTickers()
    //     0x616170: bl              #0x61618c  ; [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::_updateTickers
    // 0x616174: add             SP, SP, #8
    // 0x616178: LeaveFrame
    //     0x616178: mov             SP, fp
    //     0x61617c: ldp             fp, lr, [SP], #0x10
    // 0x616180: ret
    //     0x616180: ret             
    // 0x616184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616184: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616188: b               #0x616164
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x61618c, size: 0x150
    // 0x61618c: EnterFrame
    //     0x61618c: stp             fp, lr, [SP, #-0x10]!
    //     0x616190: mov             fp, SP
    // 0x616194: AllocStack(0x20)
    //     0x616194: sub             SP, SP, #0x20
    // 0x616198: CheckStackOverflow
    //     0x616198: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x61619c: cmp             SP, x16
    //     0x6161a0: b.ls            #0x6162c8
    // 0x6161a4: ldr             x0, [fp, #0x10]
    // 0x6161a8: LoadField: r1 = r0->field_13
    //     0x6161a8: ldur            w1, [x0, #0x13]
    // 0x6161ac: DecompressPointer r1
    //     0x6161ac: add             x1, x1, HEAP, lsl #32
    // 0x6161b0: cmp             w1, NULL
    // 0x6161b4: b.eq            #0x6162b8
    // 0x6161b8: LoadField: r2 = r0->field_17
    //     0x6161b8: ldur            w2, [x0, #0x17]
    // 0x6161bc: DecompressPointer r2
    //     0x6161bc: add             x2, x2, HEAP, lsl #32
    // 0x6161c0: cmp             w2, NULL
    // 0x6161c4: b.eq            #0x6162d0
    // 0x6161c8: LoadField: r0 = r2->field_27
    //     0x6161c8: ldur            w0, [x2, #0x27]
    // 0x6161cc: DecompressPointer r0
    //     0x6161cc: add             x0, x0, HEAP, lsl #32
    // 0x6161d0: eor             x2, x0, #0x10
    // 0x6161d4: stur            x2, [fp, #-8]
    // 0x6161d8: SaveReg r1
    //     0x6161d8: str             x1, [SP, #-8]!
    // 0x6161dc: r0 = iterator()
    //     0x6161dc: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x6161e0: add             SP, SP, #8
    // 0x6161e4: stur            x0, [fp, #-0x18]
    // 0x6161e8: LoadField: r2 = r0->field_7
    //     0x6161e8: ldur            w2, [x0, #7]
    // 0x6161ec: DecompressPointer r2
    //     0x6161ec: add             x2, x2, HEAP, lsl #32
    // 0x6161f0: stur            x2, [fp, #-0x10]
    // 0x6161f4: ldur            x1, [fp, #-8]
    // 0x6161f8: CheckStackOverflow
    //     0x6161f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6161fc: cmp             SP, x16
    //     0x616200: b.ls            #0x6162d4
    // 0x616204: SaveReg r0
    //     0x616204: str             x0, [SP, #-8]!
    // 0x616208: r0 = moveNext()
    //     0x616208: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x61620c: add             SP, SP, #8
    // 0x616210: tbnz            w0, #4, #0x6162b8
    // 0x616214: ldur            x3, [fp, #-0x18]
    // 0x616218: LoadField: r4 = r3->field_33
    //     0x616218: ldur            w4, [x3, #0x33]
    // 0x61621c: DecompressPointer r4
    //     0x61621c: add             x4, x4, HEAP, lsl #32
    // 0x616220: stur            x4, [fp, #-0x20]
    // 0x616224: cmp             w4, NULL
    // 0x616228: b.ne            #0x61625c
    // 0x61622c: mov             x0, x4
    // 0x616230: ldur            x2, [fp, #-0x10]
    // 0x616234: r1 = Null
    //     0x616234: mov             x1, NULL
    // 0x616238: cmp             w2, NULL
    // 0x61623c: b.eq            #0x61625c
    // 0x616240: LoadField: r4 = r2->field_17
    //     0x616240: ldur            w4, [x2, #0x17]
    // 0x616244: DecompressPointer r4
    //     0x616244: add             x4, x4, HEAP, lsl #32
    // 0x616248: r8 = X0
    //     0x616248: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x61624c: LoadField: r9 = r4->field_7
    //     0x61624c: ldur            x9, [x4, #7]
    // 0x616250: r3 = Null
    //     0x616250: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b980] Null
    //     0x616254: ldr             x3, [x3, #0x980]
    // 0x616258: blr             x9
    // 0x61625c: ldur            x1, [fp, #-8]
    // 0x616260: ldur            x0, [fp, #-0x20]
    // 0x616264: LoadField: r2 = r0->field_b
    //     0x616264: ldur            w2, [x0, #0xb]
    // 0x616268: DecompressPointer r2
    //     0x616268: add             x2, x2, HEAP, lsl #32
    // 0x61626c: cmp             w1, w2
    // 0x616270: b.eq            #0x6162ac
    // 0x616274: StoreField: r0->field_b = r1
    //     0x616274: stur            w1, [x0, #0xb]
    // 0x616278: tbnz            w1, #4, #0x61628c
    // 0x61627c: SaveReg r0
    //     0x61627c: str             x0, [SP, #-8]!
    // 0x616280: r0 = unscheduleTick()
    //     0x616280: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x616284: add             SP, SP, #8
    // 0x616288: b               #0x6162ac
    // 0x61628c: SaveReg r0
    //     0x61628c: str             x0, [SP, #-8]!
    // 0x616290: r0 = shouldScheduleTick()
    //     0x616290: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x616294: add             SP, SP, #8
    // 0x616298: tbnz            w0, #4, #0x6162ac
    // 0x61629c: ldur            x16, [fp, #-0x20]
    // 0x6162a0: SaveReg r16
    //     0x6162a0: str             x16, [SP, #-8]!
    // 0x6162a4: r0 = scheduleTick()
    //     0x6162a4: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x6162a8: add             SP, SP, #8
    // 0x6162ac: ldur            x0, [fp, #-0x18]
    // 0x6162b0: ldur            x2, [fp, #-0x10]
    // 0x6162b4: b               #0x6161f4
    // 0x6162b8: r0 = Null
    //     0x6162b8: mov             x0, NULL
    // 0x6162bc: LeaveFrame
    //     0x6162bc: mov             SP, fp
    //     0x6162c0: ldp             fp, lr, [SP], #0x10
    // 0x6162c4: ret
    //     0x6162c4: ret             
    // 0x6162c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6162c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6162cc: b               #0x6161a4
    // 0x6162d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6162d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6162d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6162d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6162d8: b               #0x616204
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f294, size: 0x4c
    // 0x81f294: EnterFrame
    //     0x81f294: stp             fp, lr, [SP, #-0x10]!
    //     0x81f298: mov             fp, SP
    // 0x81f29c: CheckStackOverflow
    //     0x81f29c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f2a0: cmp             SP, x16
    //     0x81f2a4: b.ls            #0x81f2d8
    // 0x81f2a8: ldr             x16, [fp, #0x10]
    // 0x81f2ac: SaveReg r16
    //     0x81f2ac: str             x16, [SP, #-8]!
    // 0x81f2b0: r0 = _updateTickerModeNotifier()
    //     0x81f2b0: bl              #0x616028  ; [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f2b4: add             SP, SP, #8
    // 0x81f2b8: ldr             x16, [fp, #0x10]
    // 0x81f2bc: SaveReg r16
    //     0x81f2bc: str             x16, [SP, #-8]!
    // 0x81f2c0: r0 = _updateTickers()
    //     0x81f2c0: bl              #0x61618c  ; [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f2c4: add             SP, SP, #8
    // 0x81f2c8: r0 = Null
    //     0x81f2c8: mov             x0, NULL
    // 0x81f2cc: LeaveFrame
    //     0x81f2cc: mov             SP, fp
    //     0x81f2d0: ldp             fp, lr, [SP], #0x10
    // 0x81f2d4: ret
    //     0x81f2d4: ret             
    // 0x81f2d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f2d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f2dc: b               #0x81f2a8
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4aa08, size: 0x18
    // 0xa4aa08: r4 = 7
    //     0xa4aa08: mov             x4, #7
    // 0xa4aa0c: r1 = Function 'dispose':.
    //     0xa4aa0c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b970] AnonymousClosure: (0xa4aa20), in [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::dispose (0xa51068)
    //     0xa4aa10: ldr             x1, [x17, #0x970]
    // 0xa4aa14: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4aa14: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4aa18: LoadField: r0 = r24->field_17
    //     0xa4aa18: ldur            x0, [x24, #0x17]
    // 0xa4aa1c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4aa20, size: 0x48
    // 0xa4aa20: EnterFrame
    //     0xa4aa20: stp             fp, lr, [SP, #-0x10]!
    //     0xa4aa24: mov             fp, SP
    // 0xa4aa28: ldr             x0, [fp, #0x10]
    // 0xa4aa2c: LoadField: r1 = r0->field_17
    //     0xa4aa2c: ldur            w1, [x0, #0x17]
    // 0xa4aa30: DecompressPointer r1
    //     0xa4aa30: add             x1, x1, HEAP, lsl #32
    // 0xa4aa34: CheckStackOverflow
    //     0xa4aa34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4aa38: cmp             SP, x16
    //     0xa4aa3c: b.ls            #0xa4aa60
    // 0xa4aa40: LoadField: r0 = r1->field_f
    //     0xa4aa40: ldur            w0, [x1, #0xf]
    // 0xa4aa44: DecompressPointer r0
    //     0xa4aa44: add             x0, x0, HEAP, lsl #32
    // 0xa4aa48: SaveReg r0
    //     0xa4aa48: str             x0, [SP, #-8]!
    // 0xa4aa4c: r0 = dispose()
    //     0xa4aa4c: bl              #0xa51068  ; [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::dispose
    // 0xa4aa50: add             SP, SP, #8
    // 0xa4aa54: LeaveFrame
    //     0xa4aa54: mov             SP, fp
    //     0xa4aa58: ldp             fp, lr, [SP], #0x10
    // 0xa4aa5c: ret
    //     0xa4aa5c: ret             
    // 0xa4aa60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4aa60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4aa64: b               #0xa4aa40
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa51068, size: 0x8c
    // 0xa51068: EnterFrame
    //     0xa51068: stp             fp, lr, [SP, #-0x10]!
    //     0xa5106c: mov             fp, SP
    // 0xa51070: AllocStack(0x8)
    //     0xa51070: sub             SP, SP, #8
    // 0xa51074: CheckStackOverflow
    //     0xa51074: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51078: cmp             SP, x16
    //     0xa5107c: b.ls            #0xa510ec
    // 0xa51080: ldr             x0, [fp, #0x10]
    // 0xa51084: LoadField: r1 = r0->field_17
    //     0xa51084: ldur            w1, [x0, #0x17]
    // 0xa51088: DecompressPointer r1
    //     0xa51088: add             x1, x1, HEAP, lsl #32
    // 0xa5108c: stur            x1, [fp, #-8]
    // 0xa51090: cmp             w1, NULL
    // 0xa51094: b.ne            #0xa510a0
    // 0xa51098: mov             x1, x0
    // 0xa5109c: b               #0xa510d8
    // 0xa510a0: r1 = 1
    //     0xa510a0: mov             x1, #1
    // 0xa510a4: r0 = AllocateContext()
    //     0xa510a4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa510a8: mov             x1, x0
    // 0xa510ac: ldr             x0, [fp, #0x10]
    // 0xa510b0: StoreField: r1->field_f = r0
    //     0xa510b0: stur            w0, [x1, #0xf]
    // 0xa510b4: mov             x2, x1
    // 0xa510b8: r1 = Function '_updateTickers@156311458':.
    //     0xa510b8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b978] AnonymousClosure: (0x616144), in [package:flutter/src/material/app_bar.dart] __SliverAppBarState&State&TickerProviderStateMixin::_updateTickers (0x61618c)
    //     0xa510bc: ldr             x1, [x1, #0x978]
    // 0xa510c0: r0 = AllocateClosure()
    //     0xa510c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa510c4: ldur            x16, [fp, #-8]
    // 0xa510c8: stp             x0, x16, [SP, #-0x10]!
    // 0xa510cc: r0 = removeListener()
    //     0xa510cc: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa510d0: add             SP, SP, #0x10
    // 0xa510d4: ldr             x1, [fp, #0x10]
    // 0xa510d8: StoreField: r1->field_17 = rNULL
    //     0xa510d8: stur            NULL, [x1, #0x17]
    // 0xa510dc: r0 = Null
    //     0xa510dc: mov             x0, NULL
    // 0xa510e0: LeaveFrame
    //     0xa510e0: mov             SP, fp
    //     0xa510e4: ldp             fp, lr, [SP], #0x10
    // 0xa510e8: ret
    //     0xa510e8: ret             
    // 0xa510ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa510ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa510f0: b               #0xa51080
  }
}

// class id: 3341, size: 0x28, field offset: 0x1c
class _SliverAppBarState extends __SliverAppBarState&State&TickerProviderStateMixin {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b0198, size: 0xa8
    // 0x7b0198: EnterFrame
    //     0x7b0198: stp             fp, lr, [SP, #-0x10]!
    //     0x7b019c: mov             fp, SP
    // 0x7b01a0: ldr             x0, [fp, #0x10]
    // 0x7b01a4: r2 = Null
    //     0x7b01a4: mov             x2, NULL
    // 0x7b01a8: r1 = Null
    //     0x7b01a8: mov             x1, NULL
    // 0x7b01ac: r4 = 59
    //     0x7b01ac: mov             x4, #0x3b
    // 0x7b01b0: branchIfSmi(r0, 0x7b01bc)
    //     0x7b01b0: tbz             w0, #0, #0x7b01bc
    // 0x7b01b4: r4 = LoadClassIdInstr(r0)
    //     0x7b01b4: ldur            x4, [x0, #-1]
    //     0x7b01b8: ubfx            x4, x4, #0xc, #0x14
    // 0x7b01bc: r17 = 4170
    //     0x7b01bc: mov             x17, #0x104a
    // 0x7b01c0: cmp             x4, x17
    // 0x7b01c4: b.eq            #0x7b01dc
    // 0x7b01c8: r8 = SliverAppBar
    //     0x7b01c8: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b9a0] Type: SliverAppBar
    //     0x7b01cc: ldr             x8, [x8, #0x9a0]
    // 0x7b01d0: r3 = Null
    //     0x7b01d0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b9a8] Null
    //     0x7b01d4: ldr             x3, [x3, #0x9a8]
    // 0x7b01d8: r0 = SliverAppBar()
    //     0x7b01d8: bl              #0x616004  ; IsType_SliverAppBar_Stub
    // 0x7b01dc: ldr             x3, [fp, #0x18]
    // 0x7b01e0: LoadField: r2 = r3->field_7
    //     0x7b01e0: ldur            w2, [x3, #7]
    // 0x7b01e4: DecompressPointer r2
    //     0x7b01e4: add             x2, x2, HEAP, lsl #32
    // 0x7b01e8: ldr             x0, [fp, #0x10]
    // 0x7b01ec: r1 = Null
    //     0x7b01ec: mov             x1, NULL
    // 0x7b01f0: cmp             w2, NULL
    // 0x7b01f4: b.eq            #0x7b0218
    // 0x7b01f8: LoadField: r4 = r2->field_17
    //     0x7b01f8: ldur            w4, [x2, #0x17]
    // 0x7b01fc: DecompressPointer r4
    //     0x7b01fc: add             x4, x4, HEAP, lsl #32
    // 0x7b0200: r8 = X0 bound StatefulWidget
    //     0x7b0200: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b0204: ldr             x8, [x8, #0x858]
    // 0x7b0208: LoadField: r9 = r4->field_7
    //     0x7b0208: ldur            x9, [x4, #7]
    // 0x7b020c: r3 = Null
    //     0x7b020c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b9b8] Null
    //     0x7b0210: ldr             x3, [x3, #0x9b8]
    // 0x7b0214: blr             x9
    // 0x7b0218: ldr             x1, [fp, #0x18]
    // 0x7b021c: LoadField: r2 = r1->field_b
    //     0x7b021c: ldur            w2, [x1, #0xb]
    // 0x7b0220: DecompressPointer r2
    //     0x7b0220: add             x2, x2, HEAP, lsl #32
    // 0x7b0224: cmp             w2, NULL
    // 0x7b0228: b.eq            #0x7b023c
    // 0x7b022c: r0 = Null
    //     0x7b022c: mov             x0, NULL
    // 0x7b0230: LeaveFrame
    //     0x7b0230: mov             SP, fp
    //     0x7b0234: ldp             fp, lr, [SP], #0x10
    // 0x7b0238: ret
    //     0x7b0238: ret             
    // 0x7b023c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b023c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x8491cc, size: 0x1fc
    // 0x8491cc: EnterFrame
    //     0x8491cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8491d0: mov             fp, SP
    // 0x8491d4: AllocStack(0x40)
    //     0x8491d4: sub             SP, SP, #0x40
    // 0x8491d8: CheckStackOverflow
    //     0x8491d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8491dc: cmp             SP, x16
    //     0x8491e0: b.ls            #0x849358
    // 0x8491e4: ldr             x0, [fp, #0x18]
    // 0x8491e8: LoadField: r1 = r0->field_b
    //     0x8491e8: ldur            w1, [x0, #0xb]
    // 0x8491ec: DecompressPointer r1
    //     0x8491ec: add             x1, x1, HEAP, lsl #32
    // 0x8491f0: cmp             w1, NULL
    // 0x8491f4: b.eq            #0x849360
    // 0x8491f8: ldr             x16, [fp, #0x10]
    // 0x8491fc: SaveReg r16
    //     0x8491fc: str             x16, [SP, #-8]!
    // 0x849200: r0 = of()
    //     0x849200: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x849204: add             SP, SP, #8
    // 0x849208: LoadField: r1 = r0->field_23
    //     0x849208: ldur            w1, [x0, #0x23]
    // 0x84920c: DecompressPointer r1
    //     0x84920c: add             x1, x1, HEAP, lsl #32
    // 0x849210: LoadField: d0 = r1->field_f
    //     0x849210: ldur            d0, [x1, #0xf]
    // 0x849214: ldr             x0, [fp, #0x18]
    // 0x849218: stur            d0, [fp, #-0x40]
    // 0x84921c: LoadField: r1 = r0->field_b
    //     0x84921c: ldur            w1, [x0, #0xb]
    // 0x849220: DecompressPointer r1
    //     0x849220: add             x1, x1, HEAP, lsl #32
    // 0x849224: cmp             w1, NULL
    // 0x849228: b.eq            #0x849364
    // 0x84922c: d1 = 56.000000
    //     0x84922c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x849230: ldr             d1, [x17, #0xe88]
    // 0x849234: fadd            d2, d1, d0
    // 0x849238: LoadField: r2 = r1->field_1b
    //     0x849238: ldur            w2, [x1, #0x1b]
    // 0x84923c: DecompressPointer r2
    //     0x84923c: add             x2, x2, HEAP, lsl #32
    // 0x849240: stur            x2, [fp, #-0x30]
    // 0x849244: LoadField: d1 = r1->field_63
    //     0x849244: ldur            d1, [x1, #0x63]
    // 0x849248: LoadField: r1 = r0->field_1b
    //     0x849248: ldur            w1, [x0, #0x1b]
    // 0x84924c: DecompressPointer r1
    //     0x84924c: add             x1, x1, HEAP, lsl #32
    // 0x849250: stur            x1, [fp, #-0x28]
    // 0x849254: LoadField: r3 = r0->field_1f
    //     0x849254: ldur            w3, [x0, #0x1f]
    // 0x849258: DecompressPointer r3
    //     0x849258: add             x3, x3, HEAP, lsl #32
    // 0x84925c: stur            x3, [fp, #-0x20]
    // 0x849260: LoadField: r4 = r0->field_23
    //     0x849260: ldur            w4, [x0, #0x23]
    // 0x849264: DecompressPointer r4
    //     0x849264: add             x4, x4, HEAP, lsl #32
    // 0x849268: stur            x4, [fp, #-0x18]
    // 0x84926c: r5 = inline_Allocate_Double()
    //     0x84926c: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x849270: add             x5, x5, #0x10
    //     0x849274: cmp             x6, x5
    //     0x849278: b.ls            #0x849368
    //     0x84927c: str             x5, [THR, #0x60]  ; THR::top
    //     0x849280: sub             x5, x5, #0xf
    //     0x849284: mov             x6, #0xd108
    //     0x849288: movk            x6, #3, lsl #16
    //     0x84928c: stur            x6, [x5, #-1]
    // 0x849290: StoreField: r5->field_7 = d2
    //     0x849290: stur            d2, [x5, #7]
    // 0x849294: stur            x5, [fp, #-0x10]
    // 0x849298: r6 = inline_Allocate_Double()
    //     0x849298: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x84929c: add             x6, x6, #0x10
    //     0x8492a0: cmp             x7, x6
    //     0x8492a4: b.ls            #0x84939c
    //     0x8492a8: str             x6, [THR, #0x60]  ; THR::top
    //     0x8492ac: sub             x6, x6, #0xf
    //     0x8492b0: mov             x7, #0xd108
    //     0x8492b4: movk            x7, #3, lsl #16
    //     0x8492b8: stur            x7, [x6, #-1]
    // 0x8492bc: StoreField: r6->field_7 = d1
    //     0x8492bc: stur            d1, [x6, #7]
    // 0x8492c0: stur            x6, [fp, #-8]
    // 0x8492c4: r0 = _SliverAppBarDelegate()
    //     0x8492c4: bl              #0x849b28  ; Allocate_SliverAppBarDelegateStub -> _SliverAppBarDelegate (size=0xb4)
    // 0x8492c8: stur            x0, [fp, #-0x38]
    // 0x8492cc: ldur            x16, [fp, #-0x10]
    // 0x8492d0: stp             x16, x0, [SP, #-0x10]!
    // 0x8492d4: ldur            x16, [fp, #-8]
    // 0x8492d8: ldur            lr, [fp, #-0x30]
    // 0x8492dc: stp             lr, x16, [SP, #-0x10]!
    // 0x8492e0: ldur            x16, [fp, #-0x18]
    // 0x8492e4: ldur            lr, [fp, #-0x28]
    // 0x8492e8: stp             lr, x16, [SP, #-0x10]!
    // 0x8492ec: ldur            x16, [fp, #-0x20]
    // 0x8492f0: SaveReg r16
    //     0x8492f0: str             x16, [SP, #-8]!
    // 0x8492f4: ldur            d0, [fp, #-0x40]
    // 0x8492f8: SaveReg d0
    //     0x8492f8: str             d0, [SP, #-8]!
    // 0x8492fc: ldr             x16, [fp, #0x18]
    // 0x849300: SaveReg r16
    //     0x849300: str             x16, [SP, #-8]!
    // 0x849304: r0 = _SliverAppBarDelegate()
    //     0x849304: bl              #0x849a18  ; [package:flutter/src/material/app_bar.dart] _SliverAppBarDelegate::_SliverAppBarDelegate
    // 0x849308: add             SP, SP, #0x48
    // 0x84930c: r0 = SliverPersistentHeader()
    //     0x84930c: bl              #0x849a0c  ; AllocateSliverPersistentHeaderStub -> SliverPersistentHeader (size=0x18)
    // 0x849310: mov             x1, x0
    // 0x849314: ldur            x0, [fp, #-0x38]
    // 0x849318: StoreField: r1->field_b = r0
    //     0x849318: stur            w0, [x1, #0xb]
    // 0x84931c: r0 = true
    //     0x84931c: add             x0, NULL, #0x20  ; true
    // 0x849320: StoreField: r1->field_f = r0
    //     0x849320: stur            w0, [x1, #0xf]
    // 0x849324: r0 = false
    //     0x849324: add             x0, NULL, #0x30  ; false
    // 0x849328: StoreField: r1->field_13 = r0
    //     0x849328: stur            w0, [x1, #0x13]
    // 0x84932c: stp             x1, NULL, [SP, #-0x10]!
    // 0x849330: ldr             x16, [fp, #0x10]
    // 0x849334: r30 = true
    //     0x849334: add             lr, NULL, #0x20  ; true
    // 0x849338: stp             lr, x16, [SP, #-0x10]!
    // 0x84933c: r4 = const [0, 0x4, 0x4, 0x3, removeBottom, 0x3, null]
    //     0x84933c: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4b998] List(7) [0, 0x4, 0x4, 0x3, "removeBottom", 0x3, Null]
    //     0x849340: ldr             x4, [x4, #0x998]
    // 0x849344: r0 = MediaQuery.removePadding()
    //     0x849344: bl              #0x8493c8  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removePadding
    // 0x849348: add             SP, SP, #0x20
    // 0x84934c: LeaveFrame
    //     0x84934c: mov             SP, fp
    //     0x849350: ldp             fp, lr, [SP], #0x10
    // 0x849354: ret
    //     0x849354: ret             
    // 0x849358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849358: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84935c: b               #0x8491e4
    // 0x849360: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x849360: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x849364: r0 = NullCastErrorSharedWithFPURegs()
    //     0x849364: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x849368: stp             q1, q2, [SP, #-0x20]!
    // 0x84936c: SaveReg d0
    //     0x84936c: str             q0, [SP, #-0x10]!
    // 0x849370: stp             x3, x4, [SP, #-0x10]!
    // 0x849374: stp             x1, x2, [SP, #-0x10]!
    // 0x849378: SaveReg r0
    //     0x849378: str             x0, [SP, #-8]!
    // 0x84937c: r0 = AllocateDouble()
    //     0x84937c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x849380: mov             x5, x0
    // 0x849384: RestoreReg r0
    //     0x849384: ldr             x0, [SP], #8
    // 0x849388: ldp             x1, x2, [SP], #0x10
    // 0x84938c: ldp             x3, x4, [SP], #0x10
    // 0x849390: RestoreReg d0
    //     0x849390: ldr             q0, [SP], #0x10
    // 0x849394: ldp             q1, q2, [SP], #0x20
    // 0x849398: b               #0x849290
    // 0x84939c: stp             q0, q1, [SP, #-0x20]!
    // 0x8493a0: stp             x4, x5, [SP, #-0x10]!
    // 0x8493a4: stp             x2, x3, [SP, #-0x10]!
    // 0x8493a8: stp             x0, x1, [SP, #-0x10]!
    // 0x8493ac: r0 = AllocateDouble()
    //     0x8493ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8493b0: mov             x6, x0
    // 0x8493b4: ldp             x0, x1, [SP], #0x10
    // 0x8493b8: ldp             x2, x3, [SP], #0x10
    // 0x8493bc: ldp             x4, x5, [SP], #0x10
    // 0x8493c0: ldp             q0, q1, [SP], #0x20
    // 0x8493c4: b               #0x8492bc
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d938c, size: 0x4c
    // 0x9d938c: EnterFrame
    //     0x9d938c: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9390: mov             fp, SP
    // 0x9d9394: CheckStackOverflow
    //     0x9d9394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9398: cmp             SP, x16
    //     0x9d939c: b.ls            #0x9d93d0
    // 0x9d93a0: ldr             x16, [fp, #0x10]
    // 0x9d93a4: SaveReg r16
    //     0x9d93a4: str             x16, [SP, #-8]!
    // 0x9d93a8: r0 = _updateSnapConfiguration()
    //     0x9d93a8: bl              #0x9d940c  ; [package:flutter/src/material/app_bar.dart] _SliverAppBarState::_updateSnapConfiguration
    // 0x9d93ac: add             SP, SP, #8
    // 0x9d93b0: ldr             x16, [fp, #0x10]
    // 0x9d93b4: SaveReg r16
    //     0x9d93b4: str             x16, [SP, #-8]!
    // 0x9d93b8: r0 = _updateStretchConfiguration()
    //     0x9d93b8: bl              #0x9d93d8  ; [package:flutter/src/material/app_bar.dart] _SliverAppBarState::_updateStretchConfiguration
    // 0x9d93bc: add             SP, SP, #8
    // 0x9d93c0: r0 = Null
    //     0x9d93c0: mov             x0, NULL
    // 0x9d93c4: LeaveFrame
    //     0x9d93c4: mov             SP, fp
    //     0x9d93c8: ldp             fp, lr, [SP], #0x10
    // 0x9d93cc: ret
    //     0x9d93cc: ret             
    // 0x9d93d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d93d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d93d4: b               #0x9d93a0
  }
  _ _updateStretchConfiguration(/* No info */) {
    // ** addr: 0x9d93d8, size: 0x34
    // 0x9d93d8: EnterFrame
    //     0x9d93d8: stp             fp, lr, [SP, #-0x10]!
    //     0x9d93dc: mov             fp, SP
    // 0x9d93e0: ldr             x1, [fp, #0x10]
    // 0x9d93e4: LoadField: r2 = r1->field_b
    //     0x9d93e4: ldur            w2, [x1, #0xb]
    // 0x9d93e8: DecompressPointer r2
    //     0x9d93e8: add             x2, x2, HEAP, lsl #32
    // 0x9d93ec: cmp             w2, NULL
    // 0x9d93f0: b.eq            #0x9d9408
    // 0x9d93f4: StoreField: r1->field_1f = rNULL
    //     0x9d93f4: stur            NULL, [x1, #0x1f]
    // 0x9d93f8: r0 = Null
    //     0x9d93f8: mov             x0, NULL
    // 0x9d93fc: LeaveFrame
    //     0x9d93fc: mov             SP, fp
    //     0x9d9400: ldp             fp, lr, [SP], #0x10
    // 0x9d9404: ret
    //     0x9d9404: ret             
    // 0x9d9408: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d9408: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateSnapConfiguration(/* No info */) {
    // ** addr: 0x9d940c, size: 0x38
    // 0x9d940c: EnterFrame
    //     0x9d940c: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9410: mov             fp, SP
    // 0x9d9414: ldr             x1, [fp, #0x10]
    // 0x9d9418: LoadField: r2 = r1->field_b
    //     0x9d9418: ldur            w2, [x1, #0xb]
    // 0x9d941c: DecompressPointer r2
    //     0x9d941c: add             x2, x2, HEAP, lsl #32
    // 0x9d9420: cmp             w2, NULL
    // 0x9d9424: b.eq            #0x9d9440
    // 0x9d9428: StoreField: r1->field_1b = rNULL
    //     0x9d9428: stur            NULL, [x1, #0x1b]
    // 0x9d942c: StoreField: r1->field_23 = rNULL
    //     0x9d942c: stur            NULL, [x1, #0x23]
    // 0x9d9430: r0 = Null
    //     0x9d9430: mov             x0, NULL
    // 0x9d9434: LeaveFrame
    //     0x9d9434: mov             SP, fp
    //     0x9d9438: ldp             fp, lr, [SP], #0x10
    // 0x9d943c: ret
    //     0x9d943c: ret             
    // 0x9d9440: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d9440: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3342, size: 0x1c, field offset: 0x14
class _AppBarState extends State<AppBar> {

  _ build(/* No info */) {
    // ** addr: 0x84637c, size: 0x189c
    // 0x84637c: EnterFrame
    //     0x84637c: stp             fp, lr, [SP, #-0x10]!
    //     0x846380: mov             fp, SP
    // 0x846384: AllocStack(0xa0)
    //     0x846384: sub             SP, SP, #0xa0
    // 0x846388: CheckStackOverflow
    //     0x846388: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84638c: cmp             SP, x16
    //     0x846390: b.ls            #0x847b54
    // 0x846394: ldr             x16, [fp, #0x10]
    // 0x846398: SaveReg r16
    //     0x846398: str             x16, [SP, #-8]!
    // 0x84639c: r0 = of()
    //     0x84639c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8463a0: add             SP, SP, #8
    // 0x8463a4: stur            x0, [fp, #-8]
    // 0x8463a8: ldr             x16, [fp, #0x10]
    // 0x8463ac: SaveReg r16
    //     0x8463ac: str             x16, [SP, #-8]!
    // 0x8463b0: r0 = of()
    //     0x8463b0: bl              #0x848a3c  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::of
    // 0x8463b4: add             SP, SP, #8
    // 0x8463b8: mov             x1, x0
    // 0x8463bc: ldur            x0, [fp, #-8]
    // 0x8463c0: stur            x1, [fp, #-0x18]
    // 0x8463c4: LoadField: r2 = r0->field_2b
    //     0x8463c4: ldur            w2, [x0, #0x2b]
    // 0x8463c8: DecompressPointer r2
    //     0x8463c8: add             x2, x2, HEAP, lsl #32
    // 0x8463cc: stur            x2, [fp, #-0x10]
    // 0x8463d0: tbnz            w2, #4, #0x846430
    // 0x8463d4: ldr             x3, [fp, #0x10]
    // 0x8463d8: r0 = _AppBarDefaultsM3()
    //     0x8463d8: bl              #0x848a30  ; Allocate_AppBarDefaultsM3Stub -> _AppBarDefaultsM3 (size=0x60)
    // 0x8463dc: mov             x1, x0
    // 0x8463e0: r0 = Sentinel
    //     0x8463e0: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8463e4: StoreField: r1->field_53 = r0
    //     0x8463e4: stur            w0, [x1, #0x53]
    // 0x8463e8: StoreField: r1->field_57 = r0
    //     0x8463e8: stur            w0, [x1, #0x57]
    // 0x8463ec: StoreField: r1->field_5b = r0
    //     0x8463ec: stur            w0, [x1, #0x5b]
    // 0x8463f0: ldr             x2, [fp, #0x10]
    // 0x8463f4: StoreField: r1->field_4f = r2
    //     0x8463f4: stur            w2, [x1, #0x4f]
    // 0x8463f8: r0 = 0.000000
    //     0x8463f8: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x8463fc: StoreField: r1->field_13 = r0
    //     0x8463fc: stur            w0, [x1, #0x13]
    // 0x846400: r0 = 3.000000
    //     0x846400: add             x0, PP, #0xc, lsl #12  ; [pp+0xcaf0] 3
    //     0x846404: ldr             x0, [x0, #0xaf0]
    // 0x846408: StoreField: r1->field_17 = r0
    //     0x846408: stur            w0, [x1, #0x17]
    // 0x84640c: r3 = 16.000000
    //     0x84640c: add             x3, PP, #0x25, lsl #12  ; [pp+0x25da8] 16
    //     0x846410: ldr             x3, [x3, #0xda8]
    // 0x846414: StoreField: r1->field_37 = r3
    //     0x846414: stur            w3, [x1, #0x37]
    // 0x846418: r0 = 64.000000
    //     0x846418: add             x0, PP, #0x31, lsl #12  ; [pp+0x31060] 64
    //     0x84641c: ldr             x0, [x0, #0x60]
    // 0x846420: StoreField: r1->field_3b = r0
    //     0x846420: stur            w0, [x1, #0x3b]
    // 0x846424: mov             x0, x2
    // 0x846428: d0 = 0.000000
    //     0x846428: eor             v0.16b, v0.16b, v0.16b
    // 0x84642c: b               #0x846490
    // 0x846430: ldr             x2, [fp, #0x10]
    // 0x846434: r3 = 16.000000
    //     0x846434: add             x3, PP, #0x25, lsl #12  ; [pp+0x25da8] 16
    //     0x846438: ldr             x3, [x3, #0xda8]
    // 0x84643c: r0 = Sentinel
    //     0x84643c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846440: r0 = _AppBarDefaultsM2()
    //     0x846440: bl              #0x848a24  ; Allocate_AppBarDefaultsM2Stub -> _AppBarDefaultsM2 (size=0x5c)
    // 0x846444: mov             x1, x0
    // 0x846448: r0 = Sentinel
    //     0x846448: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84644c: StoreField: r1->field_53 = r0
    //     0x84644c: stur            w0, [x1, #0x53]
    // 0x846450: StoreField: r1->field_57 = r0
    //     0x846450: stur            w0, [x1, #0x57]
    // 0x846454: ldr             x0, [fp, #0x10]
    // 0x846458: StoreField: r1->field_4f = r0
    //     0x846458: stur            w0, [x1, #0x4f]
    // 0x84645c: r2 = 4.000000
    //     0x84645c: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e718] 4
    //     0x846460: ldr             x2, [x2, #0x718]
    // 0x846464: StoreField: r1->field_13 = r2
    //     0x846464: stur            w2, [x1, #0x13]
    // 0x846468: r2 = Instance_Color
    //     0x846468: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x84646c: ldr             x2, [x2, #0xf38]
    // 0x846470: StoreField: r1->field_1b = r2
    //     0x846470: stur            w2, [x1, #0x1b]
    // 0x846474: r2 = 16.000000
    //     0x846474: add             x2, PP, #0x25, lsl #12  ; [pp+0x25da8] 16
    //     0x846478: ldr             x2, [x2, #0xda8]
    // 0x84647c: StoreField: r1->field_37 = r2
    //     0x84647c: stur            w2, [x1, #0x37]
    // 0x846480: r2 = 56.000000
    //     0x846480: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c7c8] 56
    //     0x846484: ldr             x2, [x2, #0x7c8]
    // 0x846488: StoreField: r1->field_3b = r2
    //     0x846488: stur            w2, [x1, #0x3b]
    // 0x84648c: d0 = 4.000000
    //     0x84648c: fmov            d0, #4.00000000
    // 0x846490: stur            x1, [fp, #-0x20]
    // 0x846494: stur            d0, [fp, #-0x90]
    // 0x846498: SaveReg r0
    //     0x846498: str             x0, [SP, #-8]!
    // 0x84649c: r0 = maybeOf()
    //     0x84649c: bl              #0x8489e0  ; [package:flutter/src/material/scaffold.dart] Scaffold::maybeOf
    // 0x8464a0: add             SP, SP, #8
    // 0x8464a4: stur            x0, [fp, #-0x28]
    // 0x8464a8: r16 = <Object?>
    //     0x8464a8: ldr             x16, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0x8464ac: ldr             lr, [fp, #0x10]
    // 0x8464b0: stp             lr, x16, [SP, #-0x10]!
    // 0x8464b4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8464b4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8464b8: r0 = of()
    //     0x8464b8: bl              #0x8487f8  ; [package:flutter/src/widgets/routes.dart] ModalRoute::of
    // 0x8464bc: add             SP, SP, #0x10
    // 0x8464c0: stur            x0, [fp, #-0x30]
    // 0x8464c4: r16 = <FlexibleSpaceBarSettings>
    //     0x8464c4: add             x16, PP, #0x37, lsl #12  ; [pp+0x37990] TypeArguments: <FlexibleSpaceBarSettings>
    //     0x8464c8: ldr             x16, [x16, #0x990]
    // 0x8464cc: ldr             lr, [fp, #0x10]
    // 0x8464d0: stp             lr, x16, [SP, #-0x10]!
    // 0x8464d4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8464d4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8464d8: r0 = dependOnInheritedWidgetOfExactType()
    //     0x8464d8: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x8464dc: add             SP, SP, #0x10
    // 0x8464e0: stur            x0, [fp, #-0x38]
    // 0x8464e4: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x8464e4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8464e8: ldr             x0, [x0, #0x598]
    //     0x8464ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8464f0: cmp             w0, w16
    //     0x8464f4: b.ne            #0x846500
    //     0x8464f8: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x8464fc: bl              #0xd67cdc
    // 0x846500: r1 = <MaterialState>
    //     0x846500: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0x846504: ldr             x1, [x1, #0xcf0]
    // 0x846508: stur            x0, [fp, #-0x40]
    // 0x84650c: r0 = _Set()
    //     0x84650c: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x846510: mov             x1, x0
    // 0x846514: ldur            x0, [fp, #-0x40]
    // 0x846518: stur            x1, [fp, #-0x48]
    // 0x84651c: StoreField: r1->field_1b = r0
    //     0x84651c: stur            w0, [x1, #0x1b]
    // 0x846520: StoreField: r1->field_b = rZR
    //     0x846520: stur            wzr, [x1, #0xb]
    // 0x846524: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x846524: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x846528: ldr             x0, [x0, #0x5a0]
    //     0x84652c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x846530: cmp             w0, w16
    //     0x846534: b.ne            #0x846540
    //     0x846538: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x84653c: bl              #0xd67cdc
    // 0x846540: mov             x1, x0
    // 0x846544: ldur            x0, [fp, #-0x48]
    // 0x846548: StoreField: r0->field_f = r1
    //     0x846548: stur            w1, [x0, #0xf]
    // 0x84654c: StoreField: r0->field_13 = rZR
    //     0x84654c: stur            wzr, [x0, #0x13]
    // 0x846550: StoreField: r0->field_17 = rZR
    //     0x846550: stur            wzr, [x0, #0x17]
    // 0x846554: ldur            x1, [fp, #-0x38]
    // 0x846558: cmp             w1, NULL
    // 0x84655c: b.ne            #0x846568
    // 0x846560: r1 = Null
    //     0x846560: mov             x1, NULL
    // 0x846564: b               #0x846574
    // 0x846568: LoadField: r2 = r1->field_2f
    //     0x846568: ldur            w2, [x1, #0x2f]
    // 0x84656c: DecompressPointer r2
    //     0x84656c: add             x2, x2, HEAP, lsl #32
    // 0x846570: mov             x1, x2
    // 0x846574: cmp             w1, NULL
    // 0x846578: b.ne            #0x846590
    // 0x84657c: ldr             x2, [fp, #0x18]
    // 0x846580: LoadField: r1 = r2->field_17
    //     0x846580: ldur            w1, [x2, #0x17]
    // 0x846584: DecompressPointer r1
    //     0x846584: add             x1, x1, HEAP, lsl #32
    // 0x846588: tbnz            w1, #4, #0x8465ac
    // 0x84658c: b               #0x846598
    // 0x846590: ldr             x2, [fp, #0x18]
    // 0x846594: tbnz            w1, #4, #0x8465ac
    // 0x846598: r16 = Instance_MaterialState
    //     0x846598: add             x16, PP, #0x37, lsl #12  ; [pp+0x37998] Obj!MaterialState@b654d1
    //     0x84659c: ldr             x16, [x16, #0x998]
    // 0x8465a0: stp             x16, x0, [SP, #-0x10]!
    // 0x8465a4: r0 = add()
    //     0x8465a4: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x8465a8: add             SP, SP, #0x10
    // 0x8465ac: ldur            x0, [fp, #-0x28]
    // 0x8465b0: cmp             w0, NULL
    // 0x8465b4: b.ne            #0x8465c0
    // 0x8465b8: r1 = Null
    //     0x8465b8: mov             x1, NULL
    // 0x8465bc: b               #0x8465d4
    // 0x8465c0: LoadField: r1 = r0->field_b
    //     0x8465c0: ldur            w1, [x0, #0xb]
    // 0x8465c4: DecompressPointer r1
    //     0x8465c4: add             x1, x1, HEAP, lsl #32
    // 0x8465c8: cmp             w1, NULL
    // 0x8465cc: b.eq            #0x847b5c
    // 0x8465d0: r1 = false
    //     0x8465d0: add             x1, NULL, #0x30  ; false
    // 0x8465d4: cmp             w1, NULL
    // 0x8465d8: b.ne            #0x8465e0
    // 0x8465dc: r1 = false
    //     0x8465dc: add             x1, NULL, #0x30  ; false
    // 0x8465e0: stur            x1, [fp, #-0x38]
    // 0x8465e4: cmp             w0, NULL
    // 0x8465e8: b.ne            #0x8465f4
    // 0x8465ec: r0 = Null
    //     0x8465ec: mov             x0, NULL
    // 0x8465f0: b               #0x846608
    // 0x8465f4: LoadField: r2 = r0->field_b
    //     0x8465f4: ldur            w2, [x0, #0xb]
    // 0x8465f8: DecompressPointer r2
    //     0x8465f8: add             x2, x2, HEAP, lsl #32
    // 0x8465fc: cmp             w2, NULL
    // 0x846600: b.eq            #0x847b60
    // 0x846604: r0 = false
    //     0x846604: add             x0, NULL, #0x30  ; false
    // 0x846608: cmp             w0, NULL
    // 0x84660c: b.ne            #0x846618
    // 0x846610: r2 = false
    //     0x846610: add             x2, NULL, #0x30  ; false
    // 0x846614: b               #0x84661c
    // 0x846618: mov             x2, x0
    // 0x84661c: ldur            x0, [fp, #-0x30]
    // 0x846620: stur            x2, [fp, #-0x28]
    // 0x846624: cmp             w0, NULL
    // 0x846628: b.ne            #0x846634
    // 0x84662c: r0 = Null
    //     0x84662c: mov             x0, NULL
    // 0x846630: b               #0x846640
    // 0x846634: SaveReg r0
    //     0x846634: str             x0, [SP, #-8]!
    // 0x846638: r0 = canPop()
    //     0x846638: bl              #0x848778  ; [package:flutter/src/widgets/routes.dart] ModalRoute::canPop
    // 0x84663c: add             SP, SP, #8
    // 0x846640: cmp             w0, NULL
    // 0x846644: b.ne            #0x846650
    // 0x846648: r2 = false
    //     0x846648: add             x2, NULL, #0x30  ; false
    // 0x84664c: b               #0x846654
    // 0x846650: mov             x2, x0
    // 0x846654: ldur            x0, [fp, #-0x30]
    // 0x846658: stur            x2, [fp, #-0x60]
    // 0x84665c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x84665c: mov             x1, #0x76
    //     0x846660: tbz             w0, #0, #0x846670
    //     0x846664: ldur            x1, [x0, #-1]
    //     0x846668: ubfx            x1, x1, #0xc, #0x14
    //     0x84666c: lsl             x1, x1, #1
    // 0x846670: r3 = LoadInt32Instr(r1)
    //     0x846670: sbfx            x3, x1, #1, #0x1f
    // 0x846674: cmp             x3, #0x6e8
    // 0x846678: b.lt            #0x846684
    // 0x84667c: cmp             x3, #0x6f0
    // 0x846680: b.le            #0x846684
    // 0x846684: ldr             x3, [fp, #0x18]
    // 0x846688: LoadField: r1 = r3->field_b
    //     0x846688: ldur            w1, [x3, #0xb]
    // 0x84668c: DecompressPointer r1
    //     0x84668c: add             x1, x1, HEAP, lsl #32
    // 0x846690: cmp             w1, NULL
    // 0x846694: b.eq            #0x847b64
    // 0x846698: LoadField: r4 = r1->field_77
    //     0x846698: ldur            w4, [x1, #0x77]
    // 0x84669c: DecompressPointer r4
    //     0x84669c: add             x4, x4, HEAP, lsl #32
    // 0x8466a0: cmp             w4, NULL
    // 0x8466a4: b.ne            #0x8466b8
    // 0x8466a8: ldur            x5, [fp, #-0x18]
    // 0x8466ac: LoadField: r4 = r5->field_3b
    //     0x8466ac: ldur            w4, [x5, #0x3b]
    // 0x8466b0: DecompressPointer r4
    //     0x8466b0: add             x4, x4, HEAP, lsl #32
    // 0x8466b4: b               #0x8466bc
    // 0x8466b8: ldur            x5, [fp, #-0x18]
    // 0x8466bc: cmp             w4, NULL
    // 0x8466c0: b.ne            #0x8466d0
    // 0x8466c4: d0 = 56.000000
    //     0x8466c4: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x8466c8: ldr             d0, [x17, #0xe88]
    // 0x8466cc: b               #0x8466d4
    // 0x8466d0: LoadField: d0 = r4->field_7
    //     0x8466d0: ldur            d0, [x4, #7]
    // 0x8466d4: ldur            x4, [fp, #-0x20]
    // 0x8466d8: stur            d0, [fp, #-0x98]
    // 0x8466dc: LoadField: r6 = r1->field_3b
    //     0x8466dc: ldur            w6, [x1, #0x3b]
    // 0x8466e0: DecompressPointer r6
    //     0x8466e0: add             x6, x6, HEAP, lsl #32
    // 0x8466e4: stur            x6, [fp, #-0x58]
    // 0x8466e8: LoadField: r7 = r5->field_b
    //     0x8466e8: ldur            w7, [x5, #0xb]
    // 0x8466ec: DecompressPointer r7
    //     0x8466ec: add             x7, x7, HEAP, lsl #32
    // 0x8466f0: stur            x7, [fp, #-0x50]
    // 0x8466f4: r8 = LoadClassIdInstr(r4)
    //     0x8466f4: ldur            x8, [x4, #-1]
    //     0x8466f8: ubfx            x8, x8, #0xc, #0x14
    // 0x8466fc: lsl             x8, x8, #1
    // 0x846700: stur            x8, [fp, #-0x40]
    // 0x846704: r17 = 5682
    //     0x846704: mov             x17, #0x1632
    // 0x846708: cmp             w8, w17
    // 0x84670c: b.ne            #0x846728
    // 0x846710: LoadField: r1 = r4->field_b
    //     0x846710: ldur            w1, [x4, #0xb]
    // 0x846714: DecompressPointer r1
    //     0x846714: add             x1, x1, HEAP, lsl #32
    // 0x846718: mov             x2, x1
    // 0x84671c: mov             x0, x3
    // 0x846720: mov             x1, x8
    // 0x846724: b               #0x8467d0
    // 0x846728: r17 = 5684
    //     0x846728: mov             x17, #0x1634
    // 0x84672c: cmp             w8, w17
    // 0x846730: b.ne            #0x846770
    // 0x846734: mov             x1, x4
    // 0x846738: LoadField: r0 = r1->field_57
    //     0x846738: ldur            w0, [x1, #0x57]
    // 0x84673c: DecompressPointer r0
    //     0x84673c: add             x0, x0, HEAP, lsl #32
    // 0x846740: r16 = Sentinel
    //     0x846740: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846744: cmp             w0, w16
    // 0x846748: b.ne            #0x846758
    // 0x84674c: r2 = _colors
    //     0x84674c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0x846750: ldr             x2, [x2, #0x4b8]
    // 0x846754: r0 = InitLateFinalInstanceField()
    //     0x846754: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846758: LoadField: r1 = r0->field_53
    //     0x846758: ldur            w1, [x0, #0x53]
    // 0x84675c: DecompressPointer r1
    //     0x84675c: add             x1, x1, HEAP, lsl #32
    // 0x846760: mov             x2, x1
    // 0x846764: ldr             x0, [fp, #0x18]
    // 0x846768: ldur            x1, [fp, #-0x40]
    // 0x84676c: b               #0x8467d0
    // 0x846770: ldur            x1, [fp, #-0x20]
    // 0x846774: LoadField: r0 = r1->field_57
    //     0x846774: ldur            w0, [x1, #0x57]
    // 0x846778: DecompressPointer r0
    //     0x846778: add             x0, x0, HEAP, lsl #32
    // 0x84677c: r16 = Sentinel
    //     0x84677c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846780: cmp             w0, w16
    // 0x846784: b.ne            #0x846794
    // 0x846788: r2 = _colors
    //     0x846788: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c0] Field <_AppBarDefaultsM2@680187611._colors@680187611>: late final (offset: 0x58)
    //     0x84678c: ldr             x2, [x2, #0x4c0]
    // 0x846790: r0 = InitLateFinalInstanceField()
    //     0x846790: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846794: LoadField: r1 = r0->field_7
    //     0x846794: ldur            w1, [x0, #7]
    // 0x846798: DecompressPointer r1
    //     0x846798: add             x1, x1, HEAP, lsl #32
    // 0x84679c: r16 = Instance_Brightness
    //     0x84679c: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x8467a0: cmp             w1, w16
    // 0x8467a4: b.ne            #0x8467b8
    // 0x8467a8: LoadField: r1 = r0->field_53
    //     0x8467a8: ldur            w1, [x0, #0x53]
    // 0x8467ac: DecompressPointer r1
    //     0x8467ac: add             x1, x1, HEAP, lsl #32
    // 0x8467b0: mov             x0, x1
    // 0x8467b4: b               #0x8467c4
    // 0x8467b8: LoadField: r1 = r0->field_b
    //     0x8467b8: ldur            w1, [x0, #0xb]
    // 0x8467bc: DecompressPointer r1
    //     0x8467bc: add             x1, x1, HEAP, lsl #32
    // 0x8467c0: mov             x0, x1
    // 0x8467c4: mov             x2, x0
    // 0x8467c8: ldr             x0, [fp, #0x18]
    // 0x8467cc: ldur            x1, [fp, #-0x40]
    // 0x8467d0: ldur            x16, [fp, #-0x48]
    // 0x8467d4: stp             x16, x0, [SP, #-0x10]!
    // 0x8467d8: ldur            x16, [fp, #-0x58]
    // 0x8467dc: ldur            lr, [fp, #-0x50]
    // 0x8467e0: stp             lr, x16, [SP, #-0x10]!
    // 0x8467e4: SaveReg r2
    //     0x8467e4: str             x2, [SP, #-8]!
    // 0x8467e8: r0 = _resolveColor()
    //     0x8467e8: bl              #0x8486d4  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_resolveColor
    // 0x8467ec: add             SP, SP, #0x28
    // 0x8467f0: mov             x2, x0
    // 0x8467f4: ldr             x0, [fp, #0x18]
    // 0x8467f8: stur            x2, [fp, #-0x50]
    // 0x8467fc: LoadField: r1 = r0->field_b
    //     0x8467fc: ldur            w1, [x0, #0xb]
    // 0x846800: DecompressPointer r1
    //     0x846800: add             x1, x1, HEAP, lsl #32
    // 0x846804: cmp             w1, NULL
    // 0x846808: b.eq            #0x847b68
    // 0x84680c: ldur            x3, [fp, #-0x40]
    // 0x846810: r17 = 5682
    //     0x846810: mov             x17, #0x1632
    // 0x846814: cmp             w3, w17
    // 0x846818: b.ne            #0x84682c
    // 0x84681c: ldur            x4, [fp, #-0x20]
    // 0x846820: LoadField: r1 = r4->field_f
    //     0x846820: ldur            w1, [x4, #0xf]
    // 0x846824: DecompressPointer r1
    //     0x846824: add             x1, x1, HEAP, lsl #32
    // 0x846828: b               #0x8468cc
    // 0x84682c: ldur            x4, [fp, #-0x20]
    // 0x846830: r17 = 5684
    //     0x846830: mov             x17, #0x1634
    // 0x846834: cmp             w3, w17
    // 0x846838: b.ne            #0x846870
    // 0x84683c: mov             x1, x4
    // 0x846840: LoadField: r0 = r1->field_57
    //     0x846840: ldur            w0, [x1, #0x57]
    // 0x846844: DecompressPointer r0
    //     0x846844: add             x0, x0, HEAP, lsl #32
    // 0x846848: r16 = Sentinel
    //     0x846848: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84684c: cmp             w0, w16
    // 0x846850: b.ne            #0x846860
    // 0x846854: r2 = _colors
    //     0x846854: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0x846858: ldr             x2, [x2, #0x4b8]
    // 0x84685c: r0 = InitLateFinalInstanceField()
    //     0x84685c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846860: LoadField: r1 = r0->field_57
    //     0x846860: ldur            w1, [x0, #0x57]
    // 0x846864: DecompressPointer r1
    //     0x846864: add             x1, x1, HEAP, lsl #32
    // 0x846868: ldr             x0, [fp, #0x18]
    // 0x84686c: b               #0x8468cc
    // 0x846870: ldur            x1, [fp, #-0x20]
    // 0x846874: LoadField: r0 = r1->field_57
    //     0x846874: ldur            w0, [x1, #0x57]
    // 0x846878: DecompressPointer r0
    //     0x846878: add             x0, x0, HEAP, lsl #32
    // 0x84687c: r16 = Sentinel
    //     0x84687c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846880: cmp             w0, w16
    // 0x846884: b.ne            #0x846894
    // 0x846888: r2 = _colors
    //     0x846888: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c0] Field <_AppBarDefaultsM2@680187611._colors@680187611>: late final (offset: 0x58)
    //     0x84688c: ldr             x2, [x2, #0x4c0]
    // 0x846890: r0 = InitLateFinalInstanceField()
    //     0x846890: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846894: LoadField: r1 = r0->field_7
    //     0x846894: ldur            w1, [x0, #7]
    // 0x846898: DecompressPointer r1
    //     0x846898: add             x1, x1, HEAP, lsl #32
    // 0x84689c: r16 = Instance_Brightness
    //     0x84689c: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x8468a0: cmp             w1, w16
    // 0x8468a4: b.ne            #0x8468b8
    // 0x8468a8: LoadField: r1 = r0->field_57
    //     0x8468a8: ldur            w1, [x0, #0x57]
    // 0x8468ac: DecompressPointer r1
    //     0x8468ac: add             x1, x1, HEAP, lsl #32
    // 0x8468b0: mov             x0, x1
    // 0x8468b4: b               #0x8468c4
    // 0x8468b8: LoadField: r1 = r0->field_f
    //     0x8468b8: ldur            w1, [x0, #0xf]
    // 0x8468bc: DecompressPointer r1
    //     0x8468bc: add             x1, x1, HEAP, lsl #32
    // 0x8468c0: mov             x0, x1
    // 0x8468c4: mov             x1, x0
    // 0x8468c8: ldr             x0, [fp, #0x18]
    // 0x8468cc: stur            x1, [fp, #-0x58]
    // 0x8468d0: LoadField: r2 = r0->field_b
    //     0x8468d0: ldur            w2, [x0, #0xb]
    // 0x8468d4: DecompressPointer r2
    //     0x8468d4: add             x2, x2, HEAP, lsl #32
    // 0x8468d8: cmp             w2, NULL
    // 0x8468dc: b.eq            #0x847b6c
    // 0x8468e0: LoadField: r3 = r2->field_23
    //     0x8468e0: ldur            w3, [x2, #0x23]
    // 0x8468e4: DecompressPointer r3
    //     0x8468e4: add             x3, x3, HEAP, lsl #32
    // 0x8468e8: cmp             w3, NULL
    // 0x8468ec: b.ne            #0x846900
    // 0x8468f0: ldur            x2, [fp, #-0x18]
    // 0x8468f4: LoadField: r3 = r2->field_13
    //     0x8468f4: ldur            w3, [x2, #0x13]
    // 0x8468f8: DecompressPointer r3
    //     0x8468f8: add             x3, x3, HEAP, lsl #32
    // 0x8468fc: b               #0x846904
    // 0x846900: ldur            x2, [fp, #-0x18]
    // 0x846904: cmp             w3, NULL
    // 0x846908: b.ne            #0x846914
    // 0x84690c: ldur            d0, [fp, #-0x90]
    // 0x846910: b               #0x846918
    // 0x846914: LoadField: d0 = r3->field_7
    //     0x846914: ldur            d0, [x3, #7]
    // 0x846918: stur            d0, [fp, #-0x90]
    // 0x84691c: ldur            x16, [fp, #-0x48]
    // 0x846920: r30 = Instance_MaterialState
    //     0x846920: add             lr, PP, #0x37, lsl #12  ; [pp+0x37998] Obj!MaterialState@b654d1
    //     0x846924: ldr             lr, [lr, #0x998]
    // 0x846928: stp             lr, x16, [SP, #-0x10]!
    // 0x84692c: r0 = contains()
    //     0x84692c: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x846930: add             SP, SP, #0x10
    // 0x846934: tbnz            w0, #4, #0x84698c
    // 0x846938: ldr             x0, [fp, #0x18]
    // 0x84693c: ldur            x2, [fp, #-0x18]
    // 0x846940: LoadField: r1 = r0->field_b
    //     0x846940: ldur            w1, [x0, #0xb]
    // 0x846944: DecompressPointer r1
    //     0x846944: add             x1, x1, HEAP, lsl #32
    // 0x846948: cmp             w1, NULL
    // 0x84694c: b.eq            #0x847b70
    // 0x846950: LoadField: r1 = r2->field_17
    //     0x846950: ldur            w1, [x2, #0x17]
    // 0x846954: DecompressPointer r1
    //     0x846954: add             x1, x1, HEAP, lsl #32
    // 0x846958: cmp             w1, NULL
    // 0x84695c: b.ne            #0x846970
    // 0x846960: ldur            x3, [fp, #-0x20]
    // 0x846964: LoadField: r1 = r3->field_17
    //     0x846964: ldur            w1, [x3, #0x17]
    // 0x846968: DecompressPointer r1
    //     0x846968: add             x1, x1, HEAP, lsl #32
    // 0x84696c: b               #0x846974
    // 0x846970: ldur            x3, [fp, #-0x20]
    // 0x846974: cmp             w1, NULL
    // 0x846978: b.ne            #0x846984
    // 0x84697c: ldur            d0, [fp, #-0x90]
    // 0x846980: b               #0x84699c
    // 0x846984: LoadField: d0 = r1->field_7
    //     0x846984: ldur            d0, [x1, #7]
    // 0x846988: b               #0x84699c
    // 0x84698c: ldr             x0, [fp, #0x18]
    // 0x846990: ldur            x2, [fp, #-0x18]
    // 0x846994: ldur            x3, [fp, #-0x20]
    // 0x846998: ldur            d0, [fp, #-0x90]
    // 0x84699c: stur            d0, [fp, #-0x90]
    // 0x8469a0: LoadField: r1 = r0->field_b
    //     0x8469a0: ldur            w1, [x0, #0xb]
    // 0x8469a4: DecompressPointer r1
    //     0x8469a4: add             x1, x1, HEAP, lsl #32
    // 0x8469a8: cmp             w1, NULL
    // 0x8469ac: b.eq            #0x847b74
    // 0x8469b0: LoadField: r4 = r2->field_27
    //     0x8469b0: ldur            w4, [x2, #0x27]
    // 0x8469b4: DecompressPointer r4
    //     0x8469b4: add             x4, x4, HEAP, lsl #32
    // 0x8469b8: stur            x4, [fp, #-0x48]
    // 0x8469bc: cmp             w4, NULL
    // 0x8469c0: b.ne            #0x846a9c
    // 0x8469c4: ldur            x5, [fp, #-0x40]
    // 0x8469c8: r17 = 5682
    //     0x8469c8: mov             x17, #0x1632
    // 0x8469cc: cmp             w5, w17
    // 0x8469d0: b.ne            #0x8469e4
    // 0x8469d4: LoadField: r1 = r3->field_27
    //     0x8469d4: ldur            w1, [x3, #0x27]
    // 0x8469d8: DecompressPointer r1
    //     0x8469d8: add             x1, x1, HEAP, lsl #32
    // 0x8469dc: mov             x0, x1
    // 0x8469e0: b               #0x846a7c
    // 0x8469e4: r17 = 5684
    //     0x8469e4: mov             x17, #0x1634
    // 0x8469e8: cmp             w5, w17
    // 0x8469ec: b.ne            #0x846a44
    // 0x8469f0: mov             x1, x3
    // 0x8469f4: LoadField: r0 = r1->field_57
    //     0x8469f4: ldur            w0, [x1, #0x57]
    // 0x8469f8: DecompressPointer r0
    //     0x8469f8: add             x0, x0, HEAP, lsl #32
    // 0x8469fc: r16 = Sentinel
    //     0x8469fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846a00: cmp             w0, w16
    // 0x846a04: b.ne            #0x846a14
    // 0x846a08: r2 = _colors
    //     0x846a08: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0x846a0c: ldr             x2, [x2, #0x4b8]
    // 0x846a10: r0 = InitLateFinalInstanceField()
    //     0x846a10: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846a14: LoadField: r1 = r0->field_57
    //     0x846a14: ldur            w1, [x0, #0x57]
    // 0x846a18: DecompressPointer r1
    //     0x846a18: add             x1, x1, HEAP, lsl #32
    // 0x846a1c: stur            x1, [fp, #-0x68]
    // 0x846a20: r0 = IconThemeData()
    //     0x846a20: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0x846a24: mov             x1, x0
    // 0x846a28: r0 = 24.000000
    //     0x846a28: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0x846a2c: ldr             x0, [x0, #0x360]
    // 0x846a30: StoreField: r1->field_7 = r0
    //     0x846a30: stur            w0, [x1, #7]
    // 0x846a34: ldur            x2, [fp, #-0x68]
    // 0x846a38: StoreField: r1->field_1b = r2
    //     0x846a38: stur            w2, [x1, #0x1b]
    // 0x846a3c: mov             x0, x1
    // 0x846a40: b               #0x846a7c
    // 0x846a44: r0 = 24.000000
    //     0x846a44: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0x846a48: ldr             x0, [x0, #0x360]
    // 0x846a4c: ldur            x1, [fp, #-0x20]
    // 0x846a50: LoadField: r0 = r1->field_53
    //     0x846a50: ldur            w0, [x1, #0x53]
    // 0x846a54: DecompressPointer r0
    //     0x846a54: add             x0, x0, HEAP, lsl #32
    // 0x846a58: r16 = Sentinel
    //     0x846a58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846a5c: cmp             w0, w16
    // 0x846a60: b.ne            #0x846a70
    // 0x846a64: r2 = _theme
    //     0x846a64: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0x846a68: ldr             x2, [x2, #0x4c8]
    // 0x846a6c: r0 = InitLateFinalInstanceField()
    //     0x846a6c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846a70: LoadField: r1 = r0->field_87
    //     0x846a70: ldur            w1, [x0, #0x87]
    // 0x846a74: DecompressPointer r1
    //     0x846a74: add             x1, x1, HEAP, lsl #32
    // 0x846a78: mov             x0, x1
    // 0x846a7c: ldur            x16, [fp, #-0x58]
    // 0x846a80: stp             x16, x0, [SP, #-0x10]!
    // 0x846a84: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x846a84: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x846a88: ldr             x4, [x4, #0x168]
    // 0x846a8c: r0 = copyWith()
    //     0x846a8c: bl              #0xceb824  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::copyWith
    // 0x846a90: add             SP, SP, #0x10
    // 0x846a94: mov             x3, x0
    // 0x846a98: b               #0x846aa0
    // 0x846a9c: ldur            x3, [fp, #-0x48]
    // 0x846aa0: ldr             x0, [fp, #0x18]
    // 0x846aa4: ldur            x2, [fp, #-0x18]
    // 0x846aa8: stur            x3, [fp, #-0x68]
    // 0x846aac: LoadField: r1 = r0->field_b
    //     0x846aac: ldur            w1, [x0, #0xb]
    // 0x846ab0: DecompressPointer r1
    //     0x846ab0: add             x1, x1, HEAP, lsl #32
    // 0x846ab4: cmp             w1, NULL
    // 0x846ab8: b.eq            #0x847b78
    // 0x846abc: LoadField: r1 = r2->field_2b
    //     0x846abc: ldur            w1, [x2, #0x2b]
    // 0x846ac0: DecompressPointer r1
    //     0x846ac0: add             x1, x1, HEAP, lsl #32
    // 0x846ac4: cmp             w1, NULL
    // 0x846ac8: b.ne            #0x846ad0
    // 0x846acc: r1 = Null
    //     0x846acc: mov             x1, NULL
    // 0x846ad0: cmp             w1, NULL
    // 0x846ad4: b.ne            #0x846adc
    // 0x846ad8: ldur            x1, [fp, #-0x48]
    // 0x846adc: cmp             w1, NULL
    // 0x846ae0: b.ne            #0x846ba8
    // 0x846ae4: ldur            x4, [fp, #-0x40]
    // 0x846ae8: r17 = 5682
    //     0x846ae8: mov             x17, #0x1632
    // 0x846aec: cmp             w4, w17
    // 0x846af0: b.eq            #0x846b74
    // 0x846af4: r17 = 5684
    //     0x846af4: mov             x17, #0x1634
    // 0x846af8: cmp             w4, w17
    // 0x846afc: b.ne            #0x846b74
    // 0x846b00: ldur            x1, [fp, #-0x20]
    // 0x846b04: LoadField: r0 = r1->field_57
    //     0x846b04: ldur            w0, [x1, #0x57]
    // 0x846b08: DecompressPointer r0
    //     0x846b08: add             x0, x0, HEAP, lsl #32
    // 0x846b0c: r16 = Sentinel
    //     0x846b0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846b10: cmp             w0, w16
    // 0x846b14: b.ne            #0x846b24
    // 0x846b18: r2 = _colors
    //     0x846b18: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0x846b1c: ldr             x2, [x2, #0x4b8]
    // 0x846b20: r0 = InitLateFinalInstanceField()
    //     0x846b20: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846b24: LoadField: r1 = r0->field_5f
    //     0x846b24: ldur            w1, [x0, #0x5f]
    // 0x846b28: DecompressPointer r1
    //     0x846b28: add             x1, x1, HEAP, lsl #32
    // 0x846b2c: cmp             w1, NULL
    // 0x846b30: b.ne            #0x846b44
    // 0x846b34: LoadField: r1 = r0->field_57
    //     0x846b34: ldur            w1, [x0, #0x57]
    // 0x846b38: DecompressPointer r1
    //     0x846b38: add             x1, x1, HEAP, lsl #32
    // 0x846b3c: mov             x0, x1
    // 0x846b40: b               #0x846b48
    // 0x846b44: mov             x0, x1
    // 0x846b48: stur            x0, [fp, #-0x48]
    // 0x846b4c: r0 = IconThemeData()
    //     0x846b4c: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0x846b50: mov             x1, x0
    // 0x846b54: r0 = 24.000000
    //     0x846b54: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0x846b58: ldr             x0, [x0, #0x360]
    // 0x846b5c: StoreField: r1->field_7 = r0
    //     0x846b5c: stur            w0, [x1, #7]
    // 0x846b60: ldur            x0, [fp, #-0x48]
    // 0x846b64: StoreField: r1->field_1b = r0
    //     0x846b64: stur            w0, [x1, #0x1b]
    // 0x846b68: mov             x0, x1
    // 0x846b6c: ldur            x1, [fp, #-0x20]
    // 0x846b70: b               #0x846b80
    // 0x846b74: ldur            x1, [fp, #-0x20]
    // 0x846b78: LoadField: r0 = r1->field_2b
    //     0x846b78: ldur            w0, [x1, #0x2b]
    // 0x846b7c: DecompressPointer r0
    //     0x846b7c: add             x0, x0, HEAP, lsl #32
    // 0x846b80: cmp             w0, NULL
    // 0x846b84: b.ne            #0x846b90
    // 0x846b88: r0 = Null
    //     0x846b88: mov             x0, NULL
    // 0x846b8c: b               #0x846bac
    // 0x846b90: stp             NULL, x0, [SP, #-0x10]!
    // 0x846b94: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x846b94: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x846b98: ldr             x4, [x4, #0x168]
    // 0x846b9c: r0 = copyWith()
    //     0x846b9c: bl              #0xceb824  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::copyWith
    // 0x846ba0: add             SP, SP, #0x10
    // 0x846ba4: b               #0x846bac
    // 0x846ba8: mov             x0, x1
    // 0x846bac: cmp             w0, NULL
    // 0x846bb0: b.ne            #0x846bbc
    // 0x846bb4: ldur            x3, [fp, #-0x68]
    // 0x846bb8: b               #0x846bc0
    // 0x846bbc: mov             x3, x0
    // 0x846bc0: ldr             x0, [fp, #0x18]
    // 0x846bc4: ldur            x2, [fp, #-0x40]
    // 0x846bc8: stur            x3, [fp, #-0x48]
    // 0x846bcc: LoadField: r1 = r0->field_b
    //     0x846bcc: ldur            w1, [x0, #0xb]
    // 0x846bd0: DecompressPointer r1
    //     0x846bd0: add             x1, x1, HEAP, lsl #32
    // 0x846bd4: cmp             w1, NULL
    // 0x846bd8: b.eq            #0x847b7c
    // 0x846bdc: r17 = 5682
    //     0x846bdc: mov             x17, #0x1632
    // 0x846be0: cmp             w2, w17
    // 0x846be4: b.ne            #0x846bfc
    // 0x846be8: ldur            x4, [fp, #-0x20]
    // 0x846bec: LoadField: r1 = r4->field_3f
    //     0x846bec: ldur            w1, [x4, #0x3f]
    // 0x846bf0: DecompressPointer r1
    //     0x846bf0: add             x1, x1, HEAP, lsl #32
    // 0x846bf4: mov             x0, x1
    // 0x846bf8: b               #0x846c74
    // 0x846bfc: ldur            x4, [fp, #-0x20]
    // 0x846c00: r17 = 5684
    //     0x846c00: mov             x17, #0x1634
    // 0x846c04: cmp             w2, w17
    // 0x846c08: b.ne            #0x846c40
    // 0x846c0c: mov             x1, x4
    // 0x846c10: LoadField: r0 = r1->field_5b
    //     0x846c10: ldur            w0, [x1, #0x5b]
    // 0x846c14: DecompressPointer r0
    //     0x846c14: add             x0, x0, HEAP, lsl #32
    // 0x846c18: r16 = Sentinel
    //     0x846c18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846c1c: cmp             w0, w16
    // 0x846c20: b.ne            #0x846c30
    // 0x846c24: r2 = _textTheme
    //     0x846c24: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d0] Field <_AppBarDefaultsM3@680187611._textTheme@680187611>: late final (offset: 0x5c)
    //     0x846c28: ldr             x2, [x2, #0x4d0]
    // 0x846c2c: r0 = InitLateFinalInstanceField()
    //     0x846c2c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846c30: LoadField: r1 = r0->field_2f
    //     0x846c30: ldur            w1, [x0, #0x2f]
    // 0x846c34: DecompressPointer r1
    //     0x846c34: add             x1, x1, HEAP, lsl #32
    // 0x846c38: mov             x0, x1
    // 0x846c3c: b               #0x846c74
    // 0x846c40: ldur            x1, [fp, #-0x20]
    // 0x846c44: LoadField: r0 = r1->field_53
    //     0x846c44: ldur            w0, [x1, #0x53]
    // 0x846c48: DecompressPointer r0
    //     0x846c48: add             x0, x0, HEAP, lsl #32
    // 0x846c4c: r16 = Sentinel
    //     0x846c4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846c50: cmp             w0, w16
    // 0x846c54: b.ne            #0x846c64
    // 0x846c58: r2 = _theme
    //     0x846c58: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0x846c5c: ldr             x2, [x2, #0x4c8]
    // 0x846c60: r0 = InitLateFinalInstanceField()
    //     0x846c60: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846c64: LoadField: r1 = r0->field_93
    //     0x846c64: ldur            w1, [x0, #0x93]
    // 0x846c68: DecompressPointer r1
    //     0x846c68: add             x1, x1, HEAP, lsl #32
    // 0x846c6c: LoadField: r0 = r1->field_2f
    //     0x846c6c: ldur            w0, [x1, #0x2f]
    // 0x846c70: DecompressPointer r0
    //     0x846c70: add             x0, x0, HEAP, lsl #32
    // 0x846c74: cmp             w0, NULL
    // 0x846c78: b.ne            #0x846c84
    // 0x846c7c: r3 = Null
    //     0x846c7c: mov             x3, NULL
    // 0x846c80: b               #0x846ca0
    // 0x846c84: ldur            x16, [fp, #-0x58]
    // 0x846c88: stp             x16, x0, [SP, #-0x10]!
    // 0x846c8c: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x846c8c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x846c90: ldr             x4, [x4, #0x168]
    // 0x846c94: r0 = copyWith()
    //     0x846c94: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x846c98: add             SP, SP, #0x10
    // 0x846c9c: mov             x3, x0
    // 0x846ca0: ldr             x0, [fp, #0x18]
    // 0x846ca4: ldur            x2, [fp, #-0x40]
    // 0x846ca8: stur            x3, [fp, #-0x70]
    // 0x846cac: LoadField: r1 = r0->field_b
    //     0x846cac: ldur            w1, [x0, #0xb]
    // 0x846cb0: DecompressPointer r1
    //     0x846cb0: add             x1, x1, HEAP, lsl #32
    // 0x846cb4: cmp             w1, NULL
    // 0x846cb8: b.eq            #0x847b80
    // 0x846cbc: r17 = 5682
    //     0x846cbc: mov             x17, #0x1632
    // 0x846cc0: cmp             w2, w17
    // 0x846cc4: b.ne            #0x846cdc
    // 0x846cc8: ldur            x4, [fp, #-0x20]
    // 0x846ccc: LoadField: r1 = r4->field_43
    //     0x846ccc: ldur            w1, [x4, #0x43]
    // 0x846cd0: DecompressPointer r1
    //     0x846cd0: add             x1, x1, HEAP, lsl #32
    // 0x846cd4: mov             x0, x1
    // 0x846cd8: b               #0x846d54
    // 0x846cdc: ldur            x4, [fp, #-0x20]
    // 0x846ce0: r17 = 5684
    //     0x846ce0: mov             x17, #0x1634
    // 0x846ce4: cmp             w2, w17
    // 0x846ce8: b.ne            #0x846d20
    // 0x846cec: mov             x1, x4
    // 0x846cf0: LoadField: r0 = r1->field_5b
    //     0x846cf0: ldur            w0, [x1, #0x5b]
    // 0x846cf4: DecompressPointer r0
    //     0x846cf4: add             x0, x0, HEAP, lsl #32
    // 0x846cf8: r16 = Sentinel
    //     0x846cf8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846cfc: cmp             w0, w16
    // 0x846d00: b.ne            #0x846d10
    // 0x846d04: r2 = _textTheme
    //     0x846d04: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4d0] Field <_AppBarDefaultsM3@680187611._textTheme@680187611>: late final (offset: 0x5c)
    //     0x846d08: ldr             x2, [x2, #0x4d0]
    // 0x846d0c: r0 = InitLateFinalInstanceField()
    //     0x846d0c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846d10: LoadField: r1 = r0->field_1f
    //     0x846d10: ldur            w1, [x0, #0x1f]
    // 0x846d14: DecompressPointer r1
    //     0x846d14: add             x1, x1, HEAP, lsl #32
    // 0x846d18: mov             x0, x1
    // 0x846d1c: b               #0x846d54
    // 0x846d20: ldur            x1, [fp, #-0x20]
    // 0x846d24: LoadField: r0 = r1->field_53
    //     0x846d24: ldur            w0, [x1, #0x53]
    // 0x846d28: DecompressPointer r0
    //     0x846d28: add             x0, x0, HEAP, lsl #32
    // 0x846d2c: r16 = Sentinel
    //     0x846d2c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x846d30: cmp             w0, w16
    // 0x846d34: b.ne            #0x846d44
    // 0x846d38: r2 = _theme
    //     0x846d38: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4c8] Field <_AppBarDefaultsM2@680187611._theme@680187611>: late final (offset: 0x54)
    //     0x846d3c: ldr             x2, [x2, #0x4c8]
    // 0x846d40: r0 = InitLateFinalInstanceField()
    //     0x846d40: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x846d44: LoadField: r1 = r0->field_93
    //     0x846d44: ldur            w1, [x0, #0x93]
    // 0x846d48: DecompressPointer r1
    //     0x846d48: add             x1, x1, HEAP, lsl #32
    // 0x846d4c: LoadField: r0 = r1->field_1f
    //     0x846d4c: ldur            w0, [x1, #0x1f]
    // 0x846d50: DecompressPointer r0
    //     0x846d50: add             x0, x0, HEAP, lsl #32
    // 0x846d54: cmp             w0, NULL
    // 0x846d58: b.ne            #0x846d64
    // 0x846d5c: r1 = Null
    //     0x846d5c: mov             x1, NULL
    // 0x846d60: b               #0x846d80
    // 0x846d64: ldur            x16, [fp, #-0x58]
    // 0x846d68: stp             x16, x0, [SP, #-0x10]!
    // 0x846d6c: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x846d6c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x846d70: ldr             x4, [x4, #0x168]
    // 0x846d74: r0 = copyWith()
    //     0x846d74: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x846d78: add             SP, SP, #0x10
    // 0x846d7c: mov             x1, x0
    // 0x846d80: ldr             x0, [fp, #0x18]
    // 0x846d84: d0 = 1.000000
    //     0x846d84: fmov            d0, #1.00000000
    // 0x846d88: stur            x1, [fp, #-0x58]
    // 0x846d8c: LoadField: r2 = r0->field_b
    //     0x846d8c: ldur            w2, [x0, #0xb]
    // 0x846d90: DecompressPointer r2
    //     0x846d90: add             x2, x2, HEAP, lsl #32
    // 0x846d94: cmp             w2, NULL
    // 0x846d98: b.eq            #0x847b84
    // 0x846d9c: LoadField: d1 = r2->field_63
    //     0x846d9c: ldur            d1, [x2, #0x63]
    // 0x846da0: fcmp            d1, d0
    // 0x846da4: b.eq            #0x846f74
    // 0x846da8: r16 = Instance_Interval
    //     0x846da8: add             x16, PP, #0x37, lsl #12  ; [pp+0x379a0] Obj!Interval<double>@b4f821
    //     0x846dac: ldr             x16, [x16, #0x9a0]
    // 0x846db0: SaveReg r16
    //     0x846db0: str             x16, [SP, #-8]!
    // 0x846db4: SaveReg d1
    //     0x846db4: str             d1, [SP, #-8]!
    // 0x846db8: r0 = transform()
    //     0x846db8: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x846dbc: add             SP, SP, #0x10
    // 0x846dc0: mov             x1, x0
    // 0x846dc4: ldur            x0, [fp, #-0x58]
    // 0x846dc8: stur            x1, [fp, #-0x78]
    // 0x846dcc: cmp             w0, NULL
    // 0x846dd0: b.eq            #0x846e18
    // 0x846dd4: LoadField: r2 = r0->field_b
    //     0x846dd4: ldur            w2, [x0, #0xb]
    // 0x846dd8: DecompressPointer r2
    //     0x846dd8: add             x2, x2, HEAP, lsl #32
    // 0x846ddc: cmp             w2, NULL
    // 0x846de0: b.eq            #0x846e18
    // 0x846de4: LoadField: d0 = r1->field_7
    //     0x846de4: ldur            d0, [x1, #7]
    // 0x846de8: SaveReg r2
    //     0x846de8: str             x2, [SP, #-8]!
    // 0x846dec: SaveReg d0
    //     0x846dec: str             d0, [SP, #-8]!
    // 0x846df0: r0 = withOpacity()
    //     0x846df0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x846df4: add             SP, SP, #0x10
    // 0x846df8: ldur            x16, [fp, #-0x58]
    // 0x846dfc: stp             x0, x16, [SP, #-0x10]!
    // 0x846e00: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x846e00: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x846e04: ldr             x4, [x4, #0x168]
    // 0x846e08: r0 = copyWith()
    //     0x846e08: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x846e0c: add             SP, SP, #0x10
    // 0x846e10: mov             x1, x0
    // 0x846e14: b               #0x846e1c
    // 0x846e18: ldur            x1, [fp, #-0x58]
    // 0x846e1c: ldur            x0, [fp, #-0x70]
    // 0x846e20: stur            x1, [fp, #-0x80]
    // 0x846e24: cmp             w0, NULL
    // 0x846e28: b.eq            #0x846e70
    // 0x846e2c: LoadField: r2 = r0->field_b
    //     0x846e2c: ldur            w2, [x0, #0xb]
    // 0x846e30: DecompressPointer r2
    //     0x846e30: add             x2, x2, HEAP, lsl #32
    // 0x846e34: cmp             w2, NULL
    // 0x846e38: b.eq            #0x846e70
    // 0x846e3c: ldur            x3, [fp, #-0x78]
    // 0x846e40: LoadField: d0 = r3->field_7
    //     0x846e40: ldur            d0, [x3, #7]
    // 0x846e44: SaveReg r2
    //     0x846e44: str             x2, [SP, #-8]!
    // 0x846e48: SaveReg d0
    //     0x846e48: str             d0, [SP, #-8]!
    // 0x846e4c: r0 = withOpacity()
    //     0x846e4c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x846e50: add             SP, SP, #0x10
    // 0x846e54: ldur            x16, [fp, #-0x70]
    // 0x846e58: stp             x0, x16, [SP, #-0x10]!
    // 0x846e5c: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x846e5c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x846e60: ldr             x4, [x4, #0x168]
    // 0x846e64: r0 = copyWith()
    //     0x846e64: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x846e68: add             SP, SP, #0x10
    // 0x846e6c: b               #0x846e74
    // 0x846e70: ldur            x0, [fp, #-0x70]
    // 0x846e74: stur            x0, [fp, #-0x88]
    // 0x846e78: ldur            x16, [fp, #-0x68]
    // 0x846e7c: SaveReg r16
    //     0x846e7c: str             x16, [SP, #-8]!
    // 0x846e80: r0 = opacity()
    //     0x846e80: bl              #0x848618  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::opacity
    // 0x846e84: add             SP, SP, #8
    // 0x846e88: cmp             w0, NULL
    // 0x846e8c: b.ne            #0x846e98
    // 0x846e90: d0 = 1.000000
    //     0x846e90: fmov            d0, #1.00000000
    // 0x846e94: b               #0x846e9c
    // 0x846e98: LoadField: d0 = r0->field_7
    //     0x846e98: ldur            d0, [x0, #7]
    // 0x846e9c: ldur            x0, [fp, #-0x78]
    // 0x846ea0: LoadField: d1 = r0->field_7
    //     0x846ea0: ldur            d1, [x0, #7]
    // 0x846ea4: stur            d1, [fp, #-0xa0]
    // 0x846ea8: fmul            d2, d1, d0
    // 0x846eac: r0 = inline_Allocate_Double()
    //     0x846eac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x846eb0: add             x0, x0, #0x10
    //     0x846eb4: cmp             x1, x0
    //     0x846eb8: b.ls            #0x847b88
    //     0x846ebc: str             x0, [THR, #0x60]  ; THR::top
    //     0x846ec0: sub             x0, x0, #0xf
    //     0x846ec4: mov             x1, #0xd108
    //     0x846ec8: movk            x1, #3, lsl #16
    //     0x846ecc: stur            x1, [x0, #-1]
    // 0x846ed0: StoreField: r0->field_7 = d2
    //     0x846ed0: stur            d2, [x0, #7]
    // 0x846ed4: ldur            x16, [fp, #-0x68]
    // 0x846ed8: stp             x0, x16, [SP, #-0x10]!
    // 0x846edc: r4 = const [0, 0x2, 0x2, 0x1, opacity, 0x1, null]
    //     0x846edc: add             x4, PP, #0x37, lsl #12  ; [pp+0x379a8] List(7) [0, 0x2, 0x2, 0x1, "opacity", 0x1, Null]
    //     0x846ee0: ldr             x4, [x4, #0x9a8]
    // 0x846ee4: r0 = copyWith()
    //     0x846ee4: bl              #0xceb824  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::copyWith
    // 0x846ee8: add             SP, SP, #0x10
    // 0x846eec: stur            x0, [fp, #-0x78]
    // 0x846ef0: ldur            x16, [fp, #-0x48]
    // 0x846ef4: SaveReg r16
    //     0x846ef4: str             x16, [SP, #-8]!
    // 0x846ef8: r0 = opacity()
    //     0x846ef8: bl              #0x848618  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::opacity
    // 0x846efc: add             SP, SP, #8
    // 0x846f00: cmp             w0, NULL
    // 0x846f04: b.ne            #0x846f10
    // 0x846f08: d1 = 1.000000
    //     0x846f08: fmov            d1, #1.00000000
    // 0x846f0c: b               #0x846f18
    // 0x846f10: LoadField: d0 = r0->field_7
    //     0x846f10: ldur            d0, [x0, #7]
    // 0x846f14: mov             v1.16b, v0.16b
    // 0x846f18: ldur            d0, [fp, #-0xa0]
    // 0x846f1c: fmul            d2, d0, d1
    // 0x846f20: r0 = inline_Allocate_Double()
    //     0x846f20: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x846f24: add             x0, x0, #0x10
    //     0x846f28: cmp             x1, x0
    //     0x846f2c: b.ls            #0x847b98
    //     0x846f30: str             x0, [THR, #0x60]  ; THR::top
    //     0x846f34: sub             x0, x0, #0xf
    //     0x846f38: mov             x1, #0xd108
    //     0x846f3c: movk            x1, #3, lsl #16
    //     0x846f40: stur            x1, [x0, #-1]
    // 0x846f44: StoreField: r0->field_7 = d2
    //     0x846f44: stur            d2, [x0, #7]
    // 0x846f48: ldur            x16, [fp, #-0x48]
    // 0x846f4c: stp             x0, x16, [SP, #-0x10]!
    // 0x846f50: r4 = const [0, 0x2, 0x2, 0x1, opacity, 0x1, null]
    //     0x846f50: add             x4, PP, #0x37, lsl #12  ; [pp+0x379a8] List(7) [0, 0x2, 0x2, 0x1, "opacity", 0x1, Null]
    //     0x846f54: ldr             x4, [x4, #0x9a8]
    // 0x846f58: r0 = copyWith()
    //     0x846f58: bl              #0xceb824  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::copyWith
    // 0x846f5c: add             SP, SP, #0x10
    // 0x846f60: ldur            x4, [fp, #-0x78]
    // 0x846f64: mov             x3, x0
    // 0x846f68: ldur            x2, [fp, #-0x88]
    // 0x846f6c: ldur            x1, [fp, #-0x80]
    // 0x846f70: b               #0x846f84
    // 0x846f74: ldur            x4, [fp, #-0x68]
    // 0x846f78: ldur            x3, [fp, #-0x48]
    // 0x846f7c: ldur            x2, [fp, #-0x70]
    // 0x846f80: ldur            x1, [fp, #-0x58]
    // 0x846f84: ldr             x0, [fp, #0x18]
    // 0x846f88: stur            x4, [fp, #-0x48]
    // 0x846f8c: stur            x3, [fp, #-0x58]
    // 0x846f90: stur            x2, [fp, #-0x68]
    // 0x846f94: stur            x1, [fp, #-0x70]
    // 0x846f98: LoadField: r5 = r0->field_b
    //     0x846f98: ldur            w5, [x0, #0xb]
    // 0x846f9c: DecompressPointer r5
    //     0x846f9c: add             x5, x5, HEAP, lsl #32
    // 0x846fa0: cmp             w5, NULL
    // 0x846fa4: b.eq            #0x847ba8
    // 0x846fa8: LoadField: r6 = r5->field_f
    //     0x846fa8: ldur            w6, [x5, #0xf]
    // 0x846fac: DecompressPointer r6
    //     0x846fac: add             x6, x6, HEAP, lsl #32
    // 0x846fb0: tbnz            w6, #4, #0x847110
    // 0x846fb4: ldur            x5, [fp, #-0x38]
    // 0x846fb8: tbnz            w5, #4, #0x847088
    // 0x846fbc: LoadField: r5 = r4->field_7
    //     0x846fbc: ldur            w5, [x4, #7]
    // 0x846fc0: DecompressPointer r5
    //     0x846fc0: add             x5, x5, HEAP, lsl #32
    // 0x846fc4: cmp             w5, NULL
    // 0x846fc8: b.ne            #0x846fd4
    // 0x846fcc: d0 = 24.000000
    //     0x846fcc: fmov            d0, #24.00000000
    // 0x846fd0: b               #0x846fd8
    // 0x846fd4: LoadField: d0 = r5->field_7
    //     0x846fd4: ldur            d0, [x5, #7]
    // 0x846fd8: stur            d0, [fp, #-0xa0]
    // 0x846fdc: r1 = 1
    //     0x846fdc: mov             x1, #1
    // 0x846fe0: r0 = AllocateContext()
    //     0x846fe0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x846fe4: mov             x1, x0
    // 0x846fe8: ldr             x0, [fp, #0x18]
    // 0x846fec: stur            x1, [fp, #-0x38]
    // 0x846ff0: StoreField: r1->field_f = r0
    //     0x846ff0: stur            w0, [x1, #0xf]
    // 0x846ff4: ldr             x16, [fp, #0x10]
    // 0x846ff8: SaveReg r16
    //     0x846ff8: str             x16, [SP, #-8]!
    // 0x846ffc: r0 = of()
    //     0x846ffc: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x847000: add             SP, SP, #8
    // 0x847004: ldur            d0, [fp, #-0xa0]
    // 0x847008: r0 = inline_Allocate_Double()
    //     0x847008: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x84700c: add             x0, x0, #0x10
    //     0x847010: cmp             x1, x0
    //     0x847014: b.ls            #0x847bac
    //     0x847018: str             x0, [THR, #0x60]  ; THR::top
    //     0x84701c: sub             x0, x0, #0xf
    //     0x847020: mov             x1, #0xd108
    //     0x847024: movk            x1, #3, lsl #16
    //     0x847028: stur            x1, [x0, #-1]
    // 0x84702c: StoreField: r0->field_7 = d0
    //     0x84702c: stur            d0, [x0, #7]
    // 0x847030: stur            x0, [fp, #-0x78]
    // 0x847034: r0 = IconButton()
    //     0x847034: bl              #0x825364  ; AllocateIconButtonStub -> IconButton (size=0x64)
    // 0x847038: mov             x3, x0
    // 0x84703c: ldur            x0, [fp, #-0x78]
    // 0x847040: stur            x3, [fp, #-0x80]
    // 0x847044: StoreField: r3->field_b = r0
    //     0x847044: stur            w0, [x3, #0xb]
    // 0x847048: ldur            x2, [fp, #-0x38]
    // 0x84704c: r1 = Function '_handleDrawerButton@680187611':.
    //     0x84704c: add             x1, PP, #0x37, lsl #12  ; [pp+0x379b0] AnonymousClosure: (0x848edc), in [package:flutter/src/material/app_bar.dart] _AppBarState::_handleDrawerButton (0x848f24)
    //     0x847050: ldr             x1, [x1, #0x9b0]
    // 0x847054: r0 = AllocateClosure()
    //     0x847054: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x847058: mov             x1, x0
    // 0x84705c: ldur            x0, [fp, #-0x80]
    // 0x847060: StoreField: r0->field_3b = r1
    //     0x847060: stur            w1, [x0, #0x3b]
    // 0x847064: r1 = false
    //     0x847064: add             x1, NULL, #0x30  ; false
    // 0x847068: StoreField: r0->field_47 = r1
    //     0x847068: stur            w1, [x0, #0x47]
    // 0x84706c: r2 = "Open navigation menu"
    //     0x84706c: add             x2, PP, #0x37, lsl #12  ; [pp+0x379b8] "Open navigation menu"
    //     0x847070: ldr             x2, [x2, #0x9b8]
    // 0x847074: StoreField: r0->field_4b = r2
    //     0x847074: stur            w2, [x0, #0x4b]
    // 0x847078: r3 = Instance_Icon
    //     0x847078: add             x3, PP, #0x37, lsl #12  ; [pp+0x379c0] Obj!Icon@b4e111
    //     0x84707c: ldr             x3, [x3, #0x9c0]
    // 0x847080: StoreField: r0->field_1f = r3
    //     0x847080: stur            w3, [x0, #0x1f]
    // 0x847084: b               #0x847114
    // 0x847088: ldur            x0, [fp, #-0x28]
    // 0x84708c: r1 = false
    //     0x84708c: add             x1, NULL, #0x30  ; false
    // 0x847090: r2 = "Open navigation menu"
    //     0x847090: add             x2, PP, #0x37, lsl #12  ; [pp+0x379b8] "Open navigation menu"
    //     0x847094: ldr             x2, [x2, #0x9b8]
    // 0x847098: r3 = Instance_Icon
    //     0x847098: add             x3, PP, #0x37, lsl #12  ; [pp+0x379c0] Obj!Icon@b4e111
    //     0x84709c: ldr             x3, [x3, #0x9c0]
    // 0x8470a0: tbz             w0, #4, #0x8470ac
    // 0x8470a4: ldur            x4, [fp, #-0x60]
    // 0x8470a8: tbz             w4, #4, #0x8470fc
    // 0x8470ac: ldur            x4, [fp, #-0x30]
    // 0x8470b0: cmp             w4, NULL
    // 0x8470b4: b.ne            #0x8470c0
    // 0x8470b8: r0 = Null
    //     0x8470b8: mov             x0, NULL
    // 0x8470bc: b               #0x8470f0
    // 0x8470c0: SaveReg r4
    //     0x8470c0: str             x4, [SP, #-8]!
    // 0x8470c4: r0 = hasActiveRouteBelow()
    //     0x8470c4: bl              #0x848430  ; [package:flutter/src/widgets/navigator.dart] Route::hasActiveRouteBelow
    // 0x8470c8: add             SP, SP, #8
    // 0x8470cc: tbnz            w0, #4, #0x8470d8
    // 0x8470d0: r0 = true
    //     0x8470d0: add             x0, NULL, #0x20  ; true
    // 0x8470d4: b               #0x8470f0
    // 0x8470d8: ldur            x0, [fp, #-0x30]
    // 0x8470dc: LoadField: r1 = r0->field_47
    //     0x8470dc: ldur            x1, [x0, #0x47]
    // 0x8470e0: cmp             x1, #0
    // 0x8470e4: r16 = true
    //     0x8470e4: add             x16, NULL, #0x20  ; true
    // 0x8470e8: r17 = false
    //     0x8470e8: add             x17, NULL, #0x30  ; false
    // 0x8470ec: csel            x0, x16, x17, gt
    // 0x8470f0: cmp             w0, NULL
    // 0x8470f4: b.eq            #0x847108
    // 0x8470f8: tbnz            w0, #4, #0x847108
    // 0x8470fc: r0 = Instance_BackButton
    //     0x8470fc: add             x0, PP, #0x37, lsl #12  ; [pp+0x379c8] Obj!BackButton@b4ee21
    //     0x847100: ldr             x0, [x0, #0x9c8]
    // 0x847104: b               #0x847114
    // 0x847108: r0 = Null
    //     0x847108: mov             x0, NULL
    // 0x84710c: b               #0x847114
    // 0x847110: r0 = Null
    //     0x847110: mov             x0, NULL
    // 0x847114: stur            x0, [fp, #-0x30]
    // 0x847118: cmp             w0, NULL
    // 0x84711c: b.eq            #0x847274
    // 0x847120: ldur            x1, [fp, #-0x10]
    // 0x847124: tbnz            w1, #4, #0x8471f0
    // 0x847128: ldr             x2, [fp, #0x18]
    // 0x84712c: LoadField: r3 = r2->field_b
    //     0x84712c: ldur            w3, [x2, #0xb]
    // 0x847130: DecompressPointer r3
    //     0x847130: add             x3, x3, HEAP, lsl #32
    // 0x847134: cmp             w3, NULL
    // 0x847138: b.eq            #0x847bbc
    // 0x84713c: LoadField: r4 = r3->field_7b
    //     0x84713c: ldur            w4, [x3, #0x7b]
    // 0x847140: DecompressPointer r4
    //     0x847140: add             x4, x4, HEAP, lsl #32
    // 0x847144: cmp             w4, NULL
    // 0x847148: b.ne            #0x847158
    // 0x84714c: d0 = 56.000000
    //     0x84714c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x847150: ldr             d0, [x17, #0xe88]
    // 0x847154: b               #0x84715c
    // 0x847158: LoadField: d0 = r4->field_7
    //     0x847158: ldur            d0, [x4, #7]
    // 0x84715c: stur            d0, [fp, #-0xa0]
    // 0x847160: r0 = BoxConstraints()
    //     0x847160: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x847164: ldur            d0, [fp, #-0xa0]
    // 0x847168: stur            x0, [fp, #-0x38]
    // 0x84716c: StoreField: r0->field_7 = d0
    //     0x84716c: stur            d0, [x0, #7]
    // 0x847170: StoreField: r0->field_f = d0
    //     0x847170: stur            d0, [x0, #0xf]
    // 0x847174: d0 = 0.000000
    //     0x847174: eor             v0.16b, v0.16b, v0.16b
    // 0x847178: StoreField: r0->field_17 = d0
    //     0x847178: stur            d0, [x0, #0x17]
    // 0x84717c: d1 = inf
    //     0x84717c: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x847180: StoreField: r0->field_1f = d1
    //     0x847180: stur            d1, [x0, #0x1f]
    // 0x847184: ldur            x1, [fp, #-0x30]
    // 0x847188: r2 = LoadClassIdInstr(r1)
    //     0x847188: ldur            x2, [x1, #-1]
    //     0x84718c: ubfx            x2, x2, #0xc, #0x14
    // 0x847190: lsl             x2, x2, #1
    // 0x847194: r17 = 7710
    //     0x847194: mov             x17, #0x1e1e
    // 0x847198: cmp             w2, w17
    // 0x84719c: b.ne            #0x8471c0
    // 0x8471a0: r0 = Center()
    //     0x8471a0: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x8471a4: mov             x1, x0
    // 0x8471a8: r0 = Instance_Alignment
    //     0x8471a8: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x8471ac: ldr             x0, [x0, #0xc70]
    // 0x8471b0: StoreField: r1->field_f = r0
    //     0x8471b0: stur            w0, [x1, #0xf]
    // 0x8471b4: ldur            x0, [fp, #-0x30]
    // 0x8471b8: StoreField: r1->field_b = r0
    //     0x8471b8: stur            w0, [x1, #0xb]
    // 0x8471bc: b               #0x8471c8
    // 0x8471c0: mov             x0, x1
    // 0x8471c4: mov             x1, x0
    // 0x8471c8: ldur            x0, [fp, #-0x38]
    // 0x8471cc: stur            x1, [fp, #-0x60]
    // 0x8471d0: r0 = ConstrainedBox()
    //     0x8471d0: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x8471d4: mov             x1, x0
    // 0x8471d8: ldur            x0, [fp, #-0x38]
    // 0x8471dc: StoreField: r1->field_f = r0
    //     0x8471dc: stur            w0, [x1, #0xf]
    // 0x8471e0: ldur            x0, [fp, #-0x60]
    // 0x8471e4: StoreField: r1->field_b = r0
    //     0x8471e4: stur            w0, [x1, #0xb]
    // 0x8471e8: mov             x0, x1
    // 0x8471ec: b               #0x84726c
    // 0x8471f0: ldr             x1, [fp, #0x18]
    // 0x8471f4: d1 = inf
    //     0x8471f4: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x8471f8: LoadField: r2 = r1->field_b
    //     0x8471f8: ldur            w2, [x1, #0xb]
    // 0x8471fc: DecompressPointer r2
    //     0x8471fc: add             x2, x2, HEAP, lsl #32
    // 0x847200: cmp             w2, NULL
    // 0x847204: b.eq            #0x847bc0
    // 0x847208: LoadField: r3 = r2->field_7b
    //     0x847208: ldur            w3, [x2, #0x7b]
    // 0x84720c: DecompressPointer r3
    //     0x84720c: add             x3, x3, HEAP, lsl #32
    // 0x847210: cmp             w3, NULL
    // 0x847214: b.ne            #0x847224
    // 0x847218: d0 = 56.000000
    //     0x847218: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x84721c: ldr             d0, [x17, #0xe88]
    // 0x847220: b               #0x847228
    // 0x847224: LoadField: d0 = r3->field_7
    //     0x847224: ldur            d0, [x3, #7]
    // 0x847228: stur            d0, [fp, #-0xa0]
    // 0x84722c: r0 = BoxConstraints()
    //     0x84722c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x847230: ldur            d0, [fp, #-0xa0]
    // 0x847234: stur            x0, [fp, #-0x38]
    // 0x847238: StoreField: r0->field_7 = d0
    //     0x847238: stur            d0, [x0, #7]
    // 0x84723c: StoreField: r0->field_f = d0
    //     0x84723c: stur            d0, [x0, #0xf]
    // 0x847240: d0 = 0.000000
    //     0x847240: eor             v0.16b, v0.16b, v0.16b
    // 0x847244: StoreField: r0->field_17 = d0
    //     0x847244: stur            d0, [x0, #0x17]
    // 0x847248: d1 = inf
    //     0x847248: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x84724c: StoreField: r0->field_1f = d1
    //     0x84724c: stur            d1, [x0, #0x1f]
    // 0x847250: r0 = ConstrainedBox()
    //     0x847250: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x847254: mov             x1, x0
    // 0x847258: ldur            x0, [fp, #-0x38]
    // 0x84725c: StoreField: r1->field_f = r0
    //     0x84725c: stur            w0, [x1, #0xf]
    // 0x847260: ldur            x0, [fp, #-0x30]
    // 0x847264: StoreField: r1->field_b = r0
    //     0x847264: stur            w0, [x1, #0xb]
    // 0x847268: mov             x0, x1
    // 0x84726c: mov             x1, x0
    // 0x847270: b               #0x847278
    // 0x847274: mov             x1, x0
    // 0x847278: ldr             x0, [fp, #0x18]
    // 0x84727c: stur            x1, [fp, #-0x60]
    // 0x847280: LoadField: r2 = r0->field_b
    //     0x847280: ldur            w2, [x0, #0xb]
    // 0x847284: DecompressPointer r2
    //     0x847284: add             x2, x2, HEAP, lsl #32
    // 0x847288: cmp             w2, NULL
    // 0x84728c: b.eq            #0x847bc4
    // 0x847290: LoadField: r3 = r2->field_13
    //     0x847290: ldur            w3, [x2, #0x13]
    // 0x847294: DecompressPointer r3
    //     0x847294: add             x3, x3, HEAP, lsl #32
    // 0x847298: stur            x3, [fp, #-0x38]
    // 0x84729c: cmp             w3, NULL
    // 0x8472a0: b.eq            #0x847480
    // 0x8472a4: ldur            x2, [fp, #-8]
    // 0x8472a8: LoadField: r4 = r2->field_1f
    //     0x8472a8: ldur            w4, [x2, #0x1f]
    // 0x8472ac: DecompressPointer r4
    //     0x8472ac: add             x4, x4, HEAP, lsl #32
    // 0x8472b0: LoadField: r5 = r4->field_7
    //     0x8472b0: ldur            x5, [x4, #7]
    // 0x8472b4: cmp             x5, #2
    // 0x8472b8: b.gt            #0x8472c8
    // 0x8472bc: cmp             x5, #1
    // 0x8472c0: b.gt            #0x8472d8
    // 0x8472c4: b               #0x8472e0
    // 0x8472c8: cmp             x5, #4
    // 0x8472cc: b.gt            #0x8472e0
    // 0x8472d0: cmp             x5, #3
    // 0x8472d4: b.le            #0x8472e0
    // 0x8472d8: r5 = Null
    //     0x8472d8: mov             x5, NULL
    // 0x8472dc: b               #0x8472e4
    // 0x8472e0: r5 = true
    //     0x8472e0: add             x5, NULL, #0x20  ; true
    // 0x8472e4: ldur            x4, [fp, #-0x70]
    // 0x8472e8: stur            x5, [fp, #-0x30]
    // 0x8472ec: r0 = _AppBarTitleBox()
    //     0x8472ec: bl              #0x848424  ; Allocate_AppBarTitleBoxStub -> _AppBarTitleBox (size=0x10)
    // 0x8472f0: mov             x1, x0
    // 0x8472f4: ldur            x0, [fp, #-0x38]
    // 0x8472f8: stur            x1, [fp, #-0x78]
    // 0x8472fc: StoreField: r1->field_b = r0
    //     0x8472fc: stur            w0, [x1, #0xb]
    // 0x847300: r0 = Semantics()
    //     0x847300: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x847304: stur            x0, [fp, #-0x80]
    // 0x847308: ldur            x16, [fp, #-0x30]
    // 0x84730c: stp             x16, x0, [SP, #-0x10]!
    // 0x847310: r16 = true
    //     0x847310: add             x16, NULL, #0x20  ; true
    // 0x847314: ldur            lr, [fp, #-0x78]
    // 0x847318: stp             lr, x16, [SP, #-0x10]!
    // 0x84731c: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, header, 0x2, namesRoute, 0x1, null]
    //     0x84731c: add             x4, PP, #0x37, lsl #12  ; [pp+0x379d0] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "header", 0x2, "namesRoute", 0x1, Null]
    //     0x847320: ldr             x4, [x4, #0x9d0]
    // 0x847324: r0 = Semantics()
    //     0x847324: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x847328: add             SP, SP, #0x20
    // 0x84732c: ldur            x0, [fp, #-0x70]
    // 0x847330: cmp             w0, NULL
    // 0x847334: b.eq            #0x847bc8
    // 0x847338: r0 = DefaultTextStyle()
    //     0x847338: bl              #0x83fd24  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0x84733c: mov             x1, x0
    // 0x847340: ldur            x0, [fp, #-0x70]
    // 0x847344: stur            x1, [fp, #-0x30]
    // 0x847348: StoreField: r1->field_f = r0
    //     0x847348: stur            w0, [x1, #0xf]
    // 0x84734c: r0 = false
    //     0x84734c: add             x0, NULL, #0x30  ; false
    // 0x847350: StoreField: r1->field_17 = r0
    //     0x847350: stur            w0, [x1, #0x17]
    // 0x847354: r2 = Instance_TextOverflow
    //     0x847354: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d428] Obj!TextOverflow@b64d51
    //     0x847358: ldr             x2, [x2, #0x428]
    // 0x84735c: StoreField: r1->field_1b = r2
    //     0x84735c: stur            w2, [x1, #0x1b]
    // 0x847360: r2 = Instance_TextWidthBasis
    //     0x847360: add             x2, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x847364: ldr             x2, [x2, #0x148]
    // 0x847368: StoreField: r1->field_23 = r2
    //     0x847368: stur            w2, [x1, #0x23]
    // 0x84736c: ldur            x3, [fp, #-0x80]
    // 0x847370: StoreField: r1->field_b = r3
    //     0x847370: stur            w3, [x1, #0xb]
    // 0x847374: ldr             x16, [fp, #0x10]
    // 0x847378: SaveReg r16
    //     0x847378: str             x16, [SP, #-8]!
    // 0x84737c: r0 = of()
    //     0x84737c: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x847380: add             SP, SP, #8
    // 0x847384: stur            x0, [fp, #-0x70]
    // 0x847388: LoadField: d0 = r0->field_13
    //     0x847388: ldur            d0, [x0, #0x13]
    // 0x84738c: stur            d0, [fp, #-0xa0]
    // 0x847390: d1 = 1.340000
    //     0x847390: add             x17, PP, #0x37, lsl #12  ; [pp+0x379d8] IMM: double(1.34) from 0x3ff570a3d70a3d71
    //     0x847394: ldr             d1, [x17, #0x9d8]
    // 0x847398: fcmp            d0, d1
    // 0x84739c: b.vs            #0x8473b0
    // 0x8473a0: b.le            #0x8473b0
    // 0x8473a4: d0 = 1.340000
    //     0x8473a4: add             x17, PP, #0x37, lsl #12  ; [pp+0x379d8] IMM: double(1.34) from 0x3ff570a3d70a3d71
    //     0x8473a8: ldr             d0, [x17, #0x9d8]
    // 0x8473ac: b               #0x847418
    // 0x8473b0: fcmp            d0, d1
    // 0x8473b4: b.vs            #0x8473bc
    // 0x8473b8: b.lt            #0x847418
    // 0x8473bc: d2 = 0.000000
    //     0x8473bc: eor             v2.16b, v2.16b, v2.16b
    // 0x8473c0: fcmp            d0, d2
    // 0x8473c4: b.vs            #0x8473cc
    // 0x8473c8: b.eq            #0x8473d4
    // 0x8473cc: r1 = false
    //     0x8473cc: add             x1, NULL, #0x30  ; false
    // 0x8473d0: b               #0x8473d8
    // 0x8473d4: r1 = true
    //     0x8473d4: add             x1, NULL, #0x20  ; true
    // 0x8473d8: tbnz            w1, #4, #0x8473ec
    // 0x8473dc: fadd            d3, d0, d1
    // 0x8473e0: fmul            d4, d3, d0
    // 0x8473e4: fmul            d0, d4, d1
    // 0x8473e8: b               #0x847418
    // 0x8473ec: tbnz            w1, #4, #0x847414
    // 0x8473f0: r16 = 1.340000
    //     0x8473f0: add             x16, PP, #0x37, lsl #12  ; [pp+0x379e0] 1.34
    //     0x8473f4: ldr             x16, [x16, #0x9e0]
    // 0x8473f8: SaveReg r16
    //     0x8473f8: str             x16, [SP, #-8]!
    // 0x8473fc: r0 = isNegative()
    //     0x8473fc: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x847400: add             SP, SP, #8
    // 0x847404: tbnz            w0, #4, #0x847414
    // 0x847408: d0 = 1.340000
    //     0x847408: add             x17, PP, #0x37, lsl #12  ; [pp+0x379d8] IMM: double(1.34) from 0x3ff570a3d70a3d71
    //     0x84740c: ldr             d0, [x17, #0x9d8]
    // 0x847410: b               #0x847418
    // 0x847414: ldur            d0, [fp, #-0xa0]
    // 0x847418: ldur            x0, [fp, #-0x30]
    // 0x84741c: r1 = inline_Allocate_Double()
    //     0x84741c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x847420: add             x1, x1, #0x10
    //     0x847424: cmp             x2, x1
    //     0x847428: b.ls            #0x847bcc
    //     0x84742c: str             x1, [THR, #0x60]  ; THR::top
    //     0x847430: sub             x1, x1, #0xf
    //     0x847434: mov             x2, #0xd108
    //     0x847438: movk            x2, #3, lsl #16
    //     0x84743c: stur            x2, [x1, #-1]
    // 0x847440: StoreField: r1->field_7 = d0
    //     0x847440: stur            d0, [x1, #7]
    // 0x847444: ldur            x16, [fp, #-0x70]
    // 0x847448: stp             x1, x16, [SP, #-0x10]!
    // 0x84744c: r4 = const [0, 0x2, 0x2, 0x1, textScaleFactor, 0x1, null]
    //     0x84744c: add             x4, PP, #0x37, lsl #12  ; [pp+0x379e8] List(7) [0, 0x2, 0x2, 0x1, "textScaleFactor", 0x1, Null]
    //     0x847450: ldr             x4, [x4, #0x9e8]
    // 0x847454: r0 = copyWith()
    //     0x847454: bl              #0x848050  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::copyWith
    // 0x847458: add             SP, SP, #0x10
    // 0x84745c: stur            x0, [fp, #-0x70]
    // 0x847460: r0 = MediaQuery()
    //     0x847460: bl              #0x848044  ; AllocateMediaQueryStub -> MediaQuery (size=0x14)
    // 0x847464: mov             x1, x0
    // 0x847468: ldur            x0, [fp, #-0x70]
    // 0x84746c: StoreField: r1->field_f = r0
    //     0x84746c: stur            w0, [x1, #0xf]
    // 0x847470: ldur            x0, [fp, #-0x30]
    // 0x847474: StoreField: r1->field_b = r0
    //     0x847474: stur            w0, [x1, #0xb]
    // 0x847478: mov             x2, x1
    // 0x84747c: b               #0x847488
    // 0x847480: mov             x0, x3
    // 0x847484: mov             x2, x0
    // 0x847488: ldr             x0, [fp, #0x18]
    // 0x84748c: ldur            x1, [fp, #-0x28]
    // 0x847490: stur            x2, [fp, #-0x30]
    // 0x847494: LoadField: r3 = r0->field_b
    //     0x847494: ldur            w3, [x0, #0xb]
    // 0x847498: DecompressPointer r3
    //     0x847498: add             x3, x3, HEAP, lsl #32
    // 0x84749c: cmp             w3, NULL
    // 0x8474a0: b.eq            #0x847be8
    // 0x8474a4: tbnz            w1, #4, #0x847578
    // 0x8474a8: ldur            x1, [fp, #-0x48]
    // 0x8474ac: LoadField: r3 = r1->field_7
    //     0x8474ac: ldur            w3, [x1, #7]
    // 0x8474b0: DecompressPointer r3
    //     0x8474b0: add             x3, x3, HEAP, lsl #32
    // 0x8474b4: cmp             w3, NULL
    // 0x8474b8: b.ne            #0x8474c4
    // 0x8474bc: d0 = 24.000000
    //     0x8474bc: fmov            d0, #24.00000000
    // 0x8474c0: b               #0x8474c8
    // 0x8474c4: LoadField: d0 = r3->field_7
    //     0x8474c4: ldur            d0, [x3, #7]
    // 0x8474c8: stur            d0, [fp, #-0xa0]
    // 0x8474cc: r1 = 1
    //     0x8474cc: mov             x1, #1
    // 0x8474d0: r0 = AllocateContext()
    //     0x8474d0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8474d4: mov             x1, x0
    // 0x8474d8: ldr             x0, [fp, #0x18]
    // 0x8474dc: stur            x1, [fp, #-0x28]
    // 0x8474e0: StoreField: r1->field_f = r0
    //     0x8474e0: stur            w0, [x1, #0xf]
    // 0x8474e4: ldr             x16, [fp, #0x10]
    // 0x8474e8: SaveReg r16
    //     0x8474e8: str             x16, [SP, #-8]!
    // 0x8474ec: r0 = of()
    //     0x8474ec: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x8474f0: add             SP, SP, #8
    // 0x8474f4: ldur            d0, [fp, #-0xa0]
    // 0x8474f8: r0 = inline_Allocate_Double()
    //     0x8474f8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8474fc: add             x0, x0, #0x10
    //     0x847500: cmp             x1, x0
    //     0x847504: b.ls            #0x847bec
    //     0x847508: str             x0, [THR, #0x60]  ; THR::top
    //     0x84750c: sub             x0, x0, #0xf
    //     0x847510: mov             x1, #0xd108
    //     0x847514: movk            x1, #3, lsl #16
    //     0x847518: stur            x1, [x0, #-1]
    // 0x84751c: StoreField: r0->field_7 = d0
    //     0x84751c: stur            d0, [x0, #7]
    // 0x847520: stur            x0, [fp, #-0x38]
    // 0x847524: r0 = IconButton()
    //     0x847524: bl              #0x825364  ; AllocateIconButtonStub -> IconButton (size=0x64)
    // 0x847528: mov             x3, x0
    // 0x84752c: ldur            x0, [fp, #-0x38]
    // 0x847530: stur            x3, [fp, #-0x70]
    // 0x847534: StoreField: r3->field_b = r0
    //     0x847534: stur            w0, [x3, #0xb]
    // 0x847538: ldur            x2, [fp, #-0x28]
    // 0x84753c: r1 = Function '_handleDrawerButtonEnd@680187611':.
    //     0x84753c: add             x1, PP, #0x37, lsl #12  ; [pp+0x379f0] AnonymousClosure: (0x848a80), in [package:flutter/src/material/app_bar.dart] _AppBarState::_handleDrawerButtonEnd (0x848ac8)
    //     0x847540: ldr             x1, [x1, #0x9f0]
    // 0x847544: r0 = AllocateClosure()
    //     0x847544: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x847548: mov             x1, x0
    // 0x84754c: ldur            x0, [fp, #-0x70]
    // 0x847550: StoreField: r0->field_3b = r1
    //     0x847550: stur            w1, [x0, #0x3b]
    // 0x847554: r1 = false
    //     0x847554: add             x1, NULL, #0x30  ; false
    // 0x847558: StoreField: r0->field_47 = r1
    //     0x847558: stur            w1, [x0, #0x47]
    // 0x84755c: r2 = "Open navigation menu"
    //     0x84755c: add             x2, PP, #0x37, lsl #12  ; [pp+0x379b8] "Open navigation menu"
    //     0x847560: ldr             x2, [x2, #0x9b8]
    // 0x847564: StoreField: r0->field_4b = r2
    //     0x847564: stur            w2, [x0, #0x4b]
    // 0x847568: r2 = Instance_Icon
    //     0x847568: add             x2, PP, #0x37, lsl #12  ; [pp+0x379c0] Obj!Icon@b4e111
    //     0x84756c: ldr             x2, [x2, #0x9c0]
    // 0x847570: StoreField: r0->field_1f = r2
    //     0x847570: stur            w2, [x0, #0x1f]
    // 0x847574: b               #0x847580
    // 0x847578: r1 = false
    //     0x847578: add             x1, NULL, #0x30  ; false
    // 0x84757c: r0 = Null
    //     0x84757c: mov             x0, NULL
    // 0x847580: cmp             w0, NULL
    // 0x847584: b.eq            #0x8475a0
    // 0x847588: ldur            x16, [fp, #-0x58]
    // 0x84758c: stp             x16, x0, [SP, #-0x10]!
    // 0x847590: r0 = merge()
    //     0x847590: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0x847594: add             SP, SP, #0x10
    // 0x847598: mov             x2, x0
    // 0x84759c: b               #0x8475a4
    // 0x8475a0: mov             x2, x0
    // 0x8475a4: ldr             x0, [fp, #0x18]
    // 0x8475a8: ldur            x1, [fp, #-0x18]
    // 0x8475ac: stur            x2, [fp, #-0x28]
    // 0x8475b0: LoadField: r3 = r0->field_b
    //     0x8475b0: ldur            w3, [x0, #0xb]
    // 0x8475b4: DecompressPointer r3
    //     0x8475b4: add             x3, x3, HEAP, lsl #32
    // 0x8475b8: cmp             w3, NULL
    // 0x8475bc: b.eq            #0x847bfc
    // 0x8475c0: ldur            x16, [fp, #-8]
    // 0x8475c4: stp             x16, x3, [SP, #-0x10]!
    // 0x8475c8: r0 = _getEffectiveCenterTitle()
    //     0x8475c8: bl              #0x847d88  ; [package:flutter/src/material/app_bar.dart] AppBar::_getEffectiveCenterTitle
    // 0x8475cc: add             SP, SP, #0x10
    // 0x8475d0: mov             x1, x0
    // 0x8475d4: ldr             x0, [fp, #0x18]
    // 0x8475d8: stur            x1, [fp, #-8]
    // 0x8475dc: LoadField: r2 = r0->field_b
    //     0x8475dc: ldur            w2, [x0, #0xb]
    // 0x8475e0: DecompressPointer r2
    //     0x8475e0: add             x2, x2, HEAP, lsl #32
    // 0x8475e4: cmp             w2, NULL
    // 0x8475e8: b.eq            #0x847c00
    // 0x8475ec: ldur            x2, [fp, #-0x18]
    // 0x8475f0: LoadField: r3 = r2->field_37
    //     0x8475f0: ldur            w3, [x2, #0x37]
    // 0x8475f4: DecompressPointer r3
    //     0x8475f4: add             x3, x3, HEAP, lsl #32
    // 0x8475f8: cmp             w3, NULL
    // 0x8475fc: b.ne            #0x847608
    // 0x847600: d1 = 16.000000
    //     0x847600: fmov            d1, #16.00000000
    // 0x847604: b               #0x847610
    // 0x847608: LoadField: d0 = r3->field_7
    //     0x847608: ldur            d0, [x3, #7]
    // 0x84760c: mov             v1.16b, v0.16b
    // 0x847610: ldur            d0, [fp, #-0x98]
    // 0x847614: ldur            x6, [fp, #-0x68]
    // 0x847618: ldur            x5, [fp, #-0x60]
    // 0x84761c: ldur            x4, [fp, #-0x30]
    // 0x847620: ldur            x3, [fp, #-0x28]
    // 0x847624: stur            d1, [fp, #-0xa0]
    // 0x847628: r0 = NavigationToolbar()
    //     0x847628: bl              #0x847d7c  ; AllocateNavigationToolbarStub -> NavigationToolbar (size=0x24)
    // 0x84762c: mov             x1, x0
    // 0x847630: ldur            x0, [fp, #-0x60]
    // 0x847634: stur            x1, [fp, #-0x38]
    // 0x847638: StoreField: r1->field_b = r0
    //     0x847638: stur            w0, [x1, #0xb]
    // 0x84763c: ldur            x0, [fp, #-0x30]
    // 0x847640: StoreField: r1->field_f = r0
    //     0x847640: stur            w0, [x1, #0xf]
    // 0x847644: ldur            x0, [fp, #-0x28]
    // 0x847648: StoreField: r1->field_13 = r0
    //     0x847648: stur            w0, [x1, #0x13]
    // 0x84764c: ldur            x0, [fp, #-8]
    // 0x847650: StoreField: r1->field_17 = r0
    //     0x847650: stur            w0, [x1, #0x17]
    // 0x847654: ldur            d0, [fp, #-0xa0]
    // 0x847658: StoreField: r1->field_1b = d0
    //     0x847658: stur            d0, [x1, #0x1b]
    // 0x84765c: r0 = _ToolbarContainerLayout()
    //     0x84765c: bl              #0x847d70  ; Allocate_ToolbarContainerLayoutStub -> _ToolbarContainerLayout (size=0x14)
    // 0x847660: ldur            d0, [fp, #-0x98]
    // 0x847664: stur            x0, [fp, #-8]
    // 0x847668: StoreField: r0->field_b = d0
    //     0x847668: stur            d0, [x0, #0xb]
    // 0x84766c: ldur            x1, [fp, #-0x68]
    // 0x847670: cmp             w1, NULL
    // 0x847674: b.eq            #0x847c04
    // 0x847678: r0 = DefaultTextStyle()
    //     0x847678: bl              #0x83fd24  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0x84767c: mov             x1, x0
    // 0x847680: ldur            x0, [fp, #-0x68]
    // 0x847684: StoreField: r1->field_f = r0
    //     0x847684: stur            w0, [x1, #0xf]
    // 0x847688: r0 = true
    //     0x847688: add             x0, NULL, #0x20  ; true
    // 0x84768c: StoreField: r1->field_17 = r0
    //     0x84768c: stur            w0, [x1, #0x17]
    // 0x847690: r2 = Instance_TextOverflow
    //     0x847690: add             x2, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0x847694: ldr             x2, [x2, #0x118]
    // 0x847698: StoreField: r1->field_1b = r2
    //     0x847698: stur            w2, [x1, #0x1b]
    // 0x84769c: r2 = Instance_TextWidthBasis
    //     0x84769c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x8476a0: ldr             x2, [x2, #0x148]
    // 0x8476a4: StoreField: r1->field_23 = r2
    //     0x8476a4: stur            w2, [x1, #0x23]
    // 0x8476a8: ldur            x2, [fp, #-0x38]
    // 0x8476ac: StoreField: r1->field_b = r2
    //     0x8476ac: stur            w2, [x1, #0xb]
    // 0x8476b0: ldur            x16, [fp, #-0x48]
    // 0x8476b4: stp             x16, x1, [SP, #-0x10]!
    // 0x8476b8: r0 = merge()
    //     0x8476b8: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0x8476bc: add             SP, SP, #0x10
    // 0x8476c0: stur            x0, [fp, #-0x28]
    // 0x8476c4: r0 = CustomSingleChildLayout()
    //     0x8476c4: bl              #0x847d64  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0x8476c8: mov             x1, x0
    // 0x8476cc: ldur            x0, [fp, #-8]
    // 0x8476d0: stur            x1, [fp, #-0x30]
    // 0x8476d4: StoreField: r1->field_f = r0
    //     0x8476d4: stur            w0, [x1, #0xf]
    // 0x8476d8: ldur            x0, [fp, #-0x28]
    // 0x8476dc: StoreField: r1->field_b = r0
    //     0x8476dc: stur            w0, [x1, #0xb]
    // 0x8476e0: r0 = ClipRect()
    //     0x8476e0: bl              #0x847d58  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0x8476e4: mov             x1, x0
    // 0x8476e8: r0 = Instance_Clip
    //     0x8476e8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x8476ec: ldr             x0, [x0, #0x678]
    // 0x8476f0: stur            x1, [fp, #-0x28]
    // 0x8476f4: StoreField: r1->field_13 = r0
    //     0x8476f4: stur            w0, [x1, #0x13]
    // 0x8476f8: ldur            x2, [fp, #-0x30]
    // 0x8476fc: StoreField: r1->field_b = r2
    //     0x8476fc: stur            w2, [x1, #0xb]
    // 0x847700: ldr             x2, [fp, #0x18]
    // 0x847704: LoadField: r3 = r2->field_b
    //     0x847704: ldur            w3, [x2, #0xb]
    // 0x847708: DecompressPointer r3
    //     0x847708: add             x3, x3, HEAP, lsl #32
    // 0x84770c: stur            x3, [fp, #-8]
    // 0x847710: cmp             w3, NULL
    // 0x847714: b.eq            #0x847c08
    // 0x847718: r0 = SafeArea()
    //     0x847718: bl              #0x847d4c  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x84771c: mov             x1, x0
    // 0x847720: r0 = true
    //     0x847720: add             x0, NULL, #0x20  ; true
    // 0x847724: stur            x1, [fp, #-0x30]
    // 0x847728: StoreField: r1->field_b = r0
    //     0x847728: stur            w0, [x1, #0xb]
    // 0x84772c: StoreField: r1->field_f = r0
    //     0x84772c: stur            w0, [x1, #0xf]
    // 0x847730: StoreField: r1->field_13 = r0
    //     0x847730: stur            w0, [x1, #0x13]
    // 0x847734: r2 = false
    //     0x847734: add             x2, NULL, #0x30  ; false
    // 0x847738: StoreField: r1->field_17 = r2
    //     0x847738: stur            w2, [x1, #0x17]
    // 0x84773c: r3 = Instance_EdgeInsets
    //     0x84773c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x847740: ldr             x3, [x3, #0xbd8]
    // 0x847744: StoreField: r1->field_1b = r3
    //     0x847744: stur            w3, [x1, #0x1b]
    // 0x847748: StoreField: r1->field_1f = r2
    //     0x847748: stur            w2, [x1, #0x1f]
    // 0x84774c: ldur            x2, [fp, #-0x28]
    // 0x847750: StoreField: r1->field_23 = r2
    //     0x847750: stur            w2, [x1, #0x23]
    // 0x847754: r0 = Align()
    //     0x847754: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x847758: mov             x1, x0
    // 0x84775c: r0 = Instance_Alignment
    //     0x84775c: add             x0, PP, #0x27, lsl #12  ; [pp+0x27098] Obj!Alignment@b37b71
    //     0x847760: ldr             x0, [x0, #0x98]
    // 0x847764: stur            x1, [fp, #-0x38]
    // 0x847768: StoreField: r1->field_f = r0
    //     0x847768: stur            w0, [x1, #0xf]
    // 0x84776c: ldur            x0, [fp, #-0x30]
    // 0x847770: StoreField: r1->field_b = r0
    //     0x847770: stur            w0, [x1, #0xb]
    // 0x847774: ldur            x0, [fp, #-8]
    // 0x847778: LoadField: r2 = r0->field_1b
    //     0x847778: ldur            w2, [x0, #0x1b]
    // 0x84777c: DecompressPointer r2
    //     0x84777c: add             x2, x2, HEAP, lsl #32
    // 0x847780: stur            x2, [fp, #-0x28]
    // 0x847784: cmp             w2, NULL
    // 0x847788: b.eq            #0x8478b8
    // 0x84778c: r0 = Semantics()
    //     0x84778c: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x847790: stur            x0, [fp, #-8]
    // 0x847794: r16 = Instance_OrdinalSortKey
    //     0x847794: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cd50] Obj!OrdinalSortKey@b3be91
    //     0x847798: ldr             x16, [x16, #0xd50]
    // 0x84779c: stp             x16, x0, [SP, #-0x10]!
    // 0x8477a0: r16 = true
    //     0x8477a0: add             x16, NULL, #0x20  ; true
    // 0x8477a4: ldur            lr, [fp, #-0x28]
    // 0x8477a8: stp             lr, x16, [SP, #-0x10]!
    // 0x8477ac: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, explicitChildNodes, 0x2, sortKey, 0x1, null]
    //     0x8477ac: add             x4, PP, #0x37, lsl #12  ; [pp+0x379f8] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "explicitChildNodes", 0x2, "sortKey", 0x1, Null]
    //     0x8477b0: ldr             x4, [x4, #0x9f8]
    // 0x8477b4: r0 = Semantics()
    //     0x8477b4: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x8477b8: add             SP, SP, #0x20
    // 0x8477bc: r0 = Material()
    //     0x8477bc: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x8477c0: mov             x1, x0
    // 0x8477c4: r0 = Instance_MaterialType
    //     0x8477c4: add             x0, PP, #0x15, lsl #12  ; [pp+0x152a8] Obj!MaterialType@b65511
    //     0x8477c8: ldr             x0, [x0, #0x2a8]
    // 0x8477cc: stur            x1, [fp, #-0x28]
    // 0x8477d0: StoreField: r1->field_f = r0
    //     0x8477d0: stur            w0, [x1, #0xf]
    // 0x8477d4: d0 = 0.000000
    //     0x8477d4: eor             v0.16b, v0.16b, v0.16b
    // 0x8477d8: StoreField: r1->field_13 = d0
    //     0x8477d8: stur            d0, [x1, #0x13]
    // 0x8477dc: r0 = true
    //     0x8477dc: add             x0, NULL, #0x20  ; true
    // 0x8477e0: StoreField: r1->field_2f = r0
    //     0x8477e0: stur            w0, [x1, #0x2f]
    // 0x8477e4: r2 = Instance_Clip
    //     0x8477e4: add             x2, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x8477e8: ldr             x2, [x2, #0xb38]
    // 0x8477ec: StoreField: r1->field_33 = r2
    //     0x8477ec: stur            w2, [x1, #0x33]
    // 0x8477f0: r3 = Instance_Duration
    //     0x8477f0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x8477f4: ldr             x3, [x3, #0x9e0]
    // 0x8477f8: StoreField: r1->field_37 = r3
    //     0x8477f8: stur            w3, [x1, #0x37]
    // 0x8477fc: ldur            x4, [fp, #-0x38]
    // 0x847800: StoreField: r1->field_b = r4
    //     0x847800: stur            w4, [x1, #0xb]
    // 0x847804: r0 = Semantics()
    //     0x847804: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x847808: stur            x0, [fp, #-0x30]
    // 0x84780c: r16 = Instance_OrdinalSortKey
    //     0x84780c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cd40] Obj!OrdinalSortKey@b3be71
    //     0x847810: ldr             x16, [x16, #0xd40]
    // 0x847814: stp             x16, x0, [SP, #-0x10]!
    // 0x847818: r16 = true
    //     0x847818: add             x16, NULL, #0x20  ; true
    // 0x84781c: ldur            lr, [fp, #-0x28]
    // 0x847820: stp             lr, x16, [SP, #-0x10]!
    // 0x847824: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, explicitChildNodes, 0x2, sortKey, 0x1, null]
    //     0x847824: add             x4, PP, #0x37, lsl #12  ; [pp+0x379f8] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "explicitChildNodes", 0x2, "sortKey", 0x1, Null]
    //     0x847828: ldr             x4, [x4, #0x9f8]
    // 0x84782c: r0 = Semantics()
    //     0x84782c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x847830: add             SP, SP, #0x20
    // 0x847834: r1 = Null
    //     0x847834: mov             x1, NULL
    // 0x847838: r2 = 4
    //     0x847838: mov             x2, #4
    // 0x84783c: r0 = AllocateArray()
    //     0x84783c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x847840: mov             x2, x0
    // 0x847844: ldur            x0, [fp, #-8]
    // 0x847848: stur            x2, [fp, #-0x28]
    // 0x84784c: StoreField: r2->field_f = r0
    //     0x84784c: stur            w0, [x2, #0xf]
    // 0x847850: ldur            x0, [fp, #-0x30]
    // 0x847854: StoreField: r2->field_13 = r0
    //     0x847854: stur            w0, [x2, #0x13]
    // 0x847858: r1 = <Widget>
    //     0x847858: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x84785c: ldr             x1, [x1, #0xea8]
    // 0x847860: r0 = AllocateGrowableArray()
    //     0x847860: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x847864: mov             x1, x0
    // 0x847868: ldur            x0, [fp, #-0x28]
    // 0x84786c: stur            x1, [fp, #-8]
    // 0x847870: StoreField: r1->field_f = r0
    //     0x847870: stur            w0, [x1, #0xf]
    // 0x847874: r0 = 4
    //     0x847874: mov             x0, #4
    // 0x847878: StoreField: r1->field_b = r0
    //     0x847878: stur            w0, [x1, #0xb]
    // 0x84787c: r0 = Stack()
    //     0x84787c: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x847880: mov             x1, x0
    // 0x847884: r0 = Instance_AlignmentDirectional
    //     0x847884: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x847888: ldr             x0, [x0, #0xf70]
    // 0x84788c: StoreField: r1->field_f = r0
    //     0x84788c: stur            w0, [x1, #0xf]
    // 0x847890: r0 = Instance_StackFit
    //     0x847890: add             x0, PP, #0x2f, lsl #12  ; [pp+0x2f8f0] Obj!StackFit@b64791
    //     0x847894: ldr             x0, [x0, #0x8f0]
    // 0x847898: StoreField: r1->field_17 = r0
    //     0x847898: stur            w0, [x1, #0x17]
    // 0x84789c: r0 = Instance_Clip
    //     0x84789c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x8478a0: ldr             x0, [x0, #0x678]
    // 0x8478a4: StoreField: r1->field_1b = r0
    //     0x8478a4: stur            w0, [x1, #0x1b]
    // 0x8478a8: ldur            x0, [fp, #-8]
    // 0x8478ac: StoreField: r1->field_b = r0
    //     0x8478ac: stur            w0, [x1, #0xb]
    // 0x8478b0: mov             x2, x1
    // 0x8478b4: b               #0x8478c0
    // 0x8478b8: mov             x4, x1
    // 0x8478bc: mov             x2, x4
    // 0x8478c0: ldr             x0, [fp, #0x18]
    // 0x8478c4: ldur            x1, [fp, #-0x18]
    // 0x8478c8: stur            x2, [fp, #-8]
    // 0x8478cc: LoadField: r3 = r0->field_b
    //     0x8478cc: ldur            w3, [x0, #0xb]
    // 0x8478d0: DecompressPointer r3
    //     0x8478d0: add             x3, x3, HEAP, lsl #32
    // 0x8478d4: cmp             w3, NULL
    // 0x8478d8: b.eq            #0x847c0c
    // 0x8478dc: LoadField: r3 = r1->field_47
    //     0x8478dc: ldur            w3, [x1, #0x47]
    // 0x8478e0: DecompressPointer r3
    //     0x8478e0: add             x3, x3, HEAP, lsl #32
    // 0x8478e4: cmp             w3, NULL
    // 0x8478e8: b.ne            #0x8478fc
    // 0x8478ec: ldur            x4, [fp, #-0x20]
    // 0x8478f0: LoadField: r3 = r4->field_47
    //     0x8478f0: ldur            w3, [x4, #0x47]
    // 0x8478f4: DecompressPointer r3
    //     0x8478f4: add             x3, x3, HEAP, lsl #32
    // 0x8478f8: b               #0x847900
    // 0x8478fc: ldur            x4, [fp, #-0x20]
    // 0x847900: cmp             w3, NULL
    // 0x847904: b.ne            #0x847958
    // 0x847908: ldur            x3, [fp, #-0x10]
    // 0x84790c: ldur            x16, [fp, #-0x50]
    // 0x847910: SaveReg r16
    //     0x847910: str             x16, [SP, #-8]!
    // 0x847914: r0 = estimateBrightnessForColor()
    //     0x847914: bl              #0x6d295c  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x847918: add             SP, SP, #8
    // 0x84791c: mov             x1, x0
    // 0x847920: ldur            x0, [fp, #-0x10]
    // 0x847924: tbnz            w0, #4, #0x847934
    // 0x847928: r0 = Instance_Color
    //     0x847928: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x84792c: ldr             x0, [x0, #0xc08]
    // 0x847930: b               #0x847938
    // 0x847934: r0 = Null
    //     0x847934: mov             x0, NULL
    // 0x847938: ldr             x16, [fp, #0x18]
    // 0x84793c: stp             x1, x16, [SP, #-0x10]!
    // 0x847940: SaveReg r0
    //     0x847940: str             x0, [SP, #-8]!
    // 0x847944: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x847944: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x847948: r0 = _systemOverlayStyleForBrightness()
    //     0x847948: bl              #0x847ca8  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_systemOverlayStyleForBrightness
    // 0x84794c: add             SP, SP, #0x18
    // 0x847950: mov             x2, x0
    // 0x847954: b               #0x84795c
    // 0x847958: mov             x2, x3
    // 0x84795c: ldr             x0, [fp, #0x18]
    // 0x847960: ldur            x1, [fp, #-0x18]
    // 0x847964: stur            x2, [fp, #-0x28]
    // 0x847968: LoadField: r3 = r0->field_b
    //     0x847968: ldur            w3, [x0, #0xb]
    // 0x84796c: DecompressPointer r3
    //     0x84796c: add             x3, x3, HEAP, lsl #32
    // 0x847970: cmp             w3, NULL
    // 0x847974: b.eq            #0x847c10
    // 0x847978: LoadField: r3 = r1->field_1b
    //     0x847978: ldur            w3, [x1, #0x1b]
    // 0x84797c: DecompressPointer r3
    //     0x84797c: add             x3, x3, HEAP, lsl #32
    // 0x847980: cmp             w3, NULL
    // 0x847984: b.ne            #0x8479c4
    // 0x847988: ldur            x1, [fp, #-0x40]
    // 0x84798c: r17 = 5682
    //     0x84798c: mov             x17, #0x1632
    // 0x847990: cmp             w1, w17
    // 0x847994: b.eq            #0x8479b4
    // 0x847998: r17 = 5684
    //     0x847998: mov             x17, #0x1634
    // 0x84799c: cmp             w1, w17
    // 0x8479a0: b.ne            #0x8479b4
    // 0x8479a4: ldur            x4, [fp, #-0x20]
    // 0x8479a8: r3 = Instance_Color
    //     0x8479a8: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x8479ac: ldr             x3, [x3, #0xc08]
    // 0x8479b0: b               #0x8479cc
    // 0x8479b4: ldur            x4, [fp, #-0x20]
    // 0x8479b8: LoadField: r3 = r4->field_1b
    //     0x8479b8: ldur            w3, [x4, #0x1b]
    // 0x8479bc: DecompressPointer r3
    //     0x8479bc: add             x3, x3, HEAP, lsl #32
    // 0x8479c0: b               #0x8479cc
    // 0x8479c4: ldur            x4, [fp, #-0x20]
    // 0x8479c8: ldur            x1, [fp, #-0x40]
    // 0x8479cc: stur            x3, [fp, #-0x10]
    // 0x8479d0: r17 = 5682
    //     0x8479d0: mov             x17, #0x1632
    // 0x8479d4: cmp             w1, w17
    // 0x8479d8: b.eq            #0x847a38
    // 0x8479dc: r17 = 5684
    //     0x8479dc: mov             x17, #0x1634
    // 0x8479e0: cmp             w1, w17
    // 0x8479e4: b.ne            #0x847a38
    // 0x8479e8: mov             x1, x4
    // 0x8479ec: LoadField: r0 = r1->field_57
    //     0x8479ec: ldur            w0, [x1, #0x57]
    // 0x8479f0: DecompressPointer r0
    //     0x8479f0: add             x0, x0, HEAP, lsl #32
    // 0x8479f4: r16 = Sentinel
    //     0x8479f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8479f8: cmp             w0, w16
    // 0x8479fc: b.ne            #0x847a0c
    // 0x847a00: r2 = _colors
    //     0x847a00: add             x2, PP, #0xe, lsl #12  ; [pp+0xe4b8] Field <_AppBarDefaultsM3@680187611._colors@680187611>: late final (offset: 0x58)
    //     0x847a04: ldr             x2, [x2, #0x4b8]
    // 0x847a08: r0 = InitLateFinalInstanceField()
    //     0x847a08: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x847a0c: LoadField: r1 = r0->field_7f
    //     0x847a0c: ldur            w1, [x0, #0x7f]
    // 0x847a10: DecompressPointer r1
    //     0x847a10: add             x1, x1, HEAP, lsl #32
    // 0x847a14: cmp             w1, NULL
    // 0x847a18: b.ne            #0x847a2c
    // 0x847a1c: LoadField: r1 = r0->field_b
    //     0x847a1c: ldur            w1, [x0, #0xb]
    // 0x847a20: DecompressPointer r1
    //     0x847a20: add             x1, x1, HEAP, lsl #32
    // 0x847a24: mov             x0, x1
    // 0x847a28: b               #0x847a30
    // 0x847a2c: mov             x0, x1
    // 0x847a30: mov             x4, x0
    // 0x847a34: b               #0x847a44
    // 0x847a38: LoadField: r0 = r4->field_1f
    //     0x847a38: ldur            w0, [x4, #0x1f]
    // 0x847a3c: DecompressPointer r0
    //     0x847a3c: add             x0, x0, HEAP, lsl #32
    // 0x847a40: mov             x4, x0
    // 0x847a44: ldr             x0, [fp, #0x18]
    // 0x847a48: ldur            x3, [fp, #-0x50]
    // 0x847a4c: ldur            d0, [fp, #-0x90]
    // 0x847a50: ldur            x1, [fp, #-0x28]
    // 0x847a54: ldur            x2, [fp, #-0x10]
    // 0x847a58: stur            x4, [fp, #-0x18]
    // 0x847a5c: LoadField: r5 = r0->field_b
    //     0x847a5c: ldur            w5, [x0, #0xb]
    // 0x847a60: DecompressPointer r5
    //     0x847a60: add             x5, x5, HEAP, lsl #32
    // 0x847a64: cmp             w5, NULL
    // 0x847a68: b.eq            #0x847c14
    // 0x847a6c: r0 = Semantics()
    //     0x847a6c: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x847a70: stur            x0, [fp, #-0x20]
    // 0x847a74: r16 = true
    //     0x847a74: add             x16, NULL, #0x20  ; true
    // 0x847a78: stp             x16, x0, [SP, #-0x10]!
    // 0x847a7c: ldur            x16, [fp, #-8]
    // 0x847a80: SaveReg r16
    //     0x847a80: str             x16, [SP, #-8]!
    // 0x847a84: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, explicitChildNodes, 0x1, null]
    //     0x847a84: add             x4, PP, #0x36, lsl #12  ; [pp+0x36e48] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "explicitChildNodes", 0x1, Null]
    //     0x847a88: ldr             x4, [x4, #0xe48]
    // 0x847a8c: r0 = Semantics()
    //     0x847a8c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x847a90: add             SP, SP, #0x18
    // 0x847a94: r0 = Material()
    //     0x847a94: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x847a98: mov             x2, x0
    // 0x847a9c: r0 = Instance_MaterialType
    //     0x847a9c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe6f8] Obj!MaterialType@b65531
    //     0x847aa0: ldr             x0, [x0, #0x6f8]
    // 0x847aa4: stur            x2, [fp, #-8]
    // 0x847aa8: StoreField: r2->field_f = r0
    //     0x847aa8: stur            w0, [x2, #0xf]
    // 0x847aac: ldur            d0, [fp, #-0x90]
    // 0x847ab0: StoreField: r2->field_13 = d0
    //     0x847ab0: stur            d0, [x2, #0x13]
    // 0x847ab4: ldur            x0, [fp, #-0x50]
    // 0x847ab8: StoreField: r2->field_1b = r0
    //     0x847ab8: stur            w0, [x2, #0x1b]
    // 0x847abc: ldur            x0, [fp, #-0x10]
    // 0x847ac0: StoreField: r2->field_1f = r0
    //     0x847ac0: stur            w0, [x2, #0x1f]
    // 0x847ac4: ldur            x0, [fp, #-0x18]
    // 0x847ac8: StoreField: r2->field_23 = r0
    //     0x847ac8: stur            w0, [x2, #0x23]
    // 0x847acc: r0 = true
    //     0x847acc: add             x0, NULL, #0x20  ; true
    // 0x847ad0: StoreField: r2->field_2f = r0
    //     0x847ad0: stur            w0, [x2, #0x2f]
    // 0x847ad4: r1 = Instance_Clip
    //     0x847ad4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x847ad8: ldr             x1, [x1, #0xb38]
    // 0x847adc: StoreField: r2->field_33 = r1
    //     0x847adc: stur            w1, [x2, #0x33]
    // 0x847ae0: r1 = Instance_Duration
    //     0x847ae0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x847ae4: ldr             x1, [x1, #0x9e0]
    // 0x847ae8: StoreField: r2->field_37 = r1
    //     0x847ae8: stur            w1, [x2, #0x37]
    // 0x847aec: ldur            x1, [fp, #-0x20]
    // 0x847af0: StoreField: r2->field_b = r1
    //     0x847af0: stur            w1, [x2, #0xb]
    // 0x847af4: r1 = <SystemUiOverlayStyle>
    //     0x847af4: ldr             x1, [PP, #0x49d0]  ; [pp+0x49d0] TypeArguments: <SystemUiOverlayStyle>
    // 0x847af8: r0 = AnnotatedRegion()
    //     0x847af8: bl              #0x847c9c  ; AllocateAnnotatedRegionStub -> AnnotatedRegion<X0> (size=0x1c)
    // 0x847afc: mov             x1, x0
    // 0x847b00: ldur            x0, [fp, #-0x28]
    // 0x847b04: stur            x1, [fp, #-0x10]
    // 0x847b08: StoreField: r1->field_13 = r0
    //     0x847b08: stur            w0, [x1, #0x13]
    // 0x847b0c: r0 = true
    //     0x847b0c: add             x0, NULL, #0x20  ; true
    // 0x847b10: StoreField: r1->field_17 = r0
    //     0x847b10: stur            w0, [x1, #0x17]
    // 0x847b14: ldur            x0, [fp, #-8]
    // 0x847b18: StoreField: r1->field_b = r0
    //     0x847b18: stur            w0, [x1, #0xb]
    // 0x847b1c: r0 = Semantics()
    //     0x847b1c: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x847b20: stur            x0, [fp, #-8]
    // 0x847b24: r16 = true
    //     0x847b24: add             x16, NULL, #0x20  ; true
    // 0x847b28: stp             x16, x0, [SP, #-0x10]!
    // 0x847b2c: ldur            x16, [fp, #-0x10]
    // 0x847b30: SaveReg r16
    //     0x847b30: str             x16, [SP, #-8]!
    // 0x847b34: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, container, 0x1, null]
    //     0x847b34: add             x4, PP, #0x28, lsl #12  ; [pp+0x28c38] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0x847b38: ldr             x4, [x4, #0xc38]
    // 0x847b3c: r0 = Semantics()
    //     0x847b3c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x847b40: add             SP, SP, #0x18
    // 0x847b44: ldur            x0, [fp, #-8]
    // 0x847b48: LeaveFrame
    //     0x847b48: mov             SP, fp
    //     0x847b4c: ldp             fp, lr, [SP], #0x10
    // 0x847b50: ret
    //     0x847b50: ret             
    // 0x847b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x847b54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x847b58: b               #0x846394
    // 0x847b5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b74: r0 = NullCastErrorSharedWithFPURegs()
    //     0x847b74: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x847b78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847b80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847b84: r0 = NullCastErrorSharedWithFPURegs()
    //     0x847b84: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x847b88: stp             q1, q2, [SP, #-0x20]!
    // 0x847b8c: r0 = AllocateDouble()
    //     0x847b8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x847b90: ldp             q1, q2, [SP], #0x20
    // 0x847b94: b               #0x846ed0
    // 0x847b98: SaveReg d2
    //     0x847b98: str             q2, [SP, #-0x10]!
    // 0x847b9c: r0 = AllocateDouble()
    //     0x847b9c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x847ba0: RestoreReg d2
    //     0x847ba0: ldr             q2, [SP], #0x10
    // 0x847ba4: b               #0x846f44
    // 0x847ba8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847ba8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847bac: SaveReg d0
    //     0x847bac: str             q0, [SP, #-0x10]!
    // 0x847bb0: r0 = AllocateDouble()
    //     0x847bb0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x847bb4: RestoreReg d0
    //     0x847bb4: ldr             q0, [SP], #0x10
    // 0x847bb8: b               #0x84702c
    // 0x847bbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847bbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847bc0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x847bc0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x847bc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847bc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847bc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847bc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847bcc: SaveReg d0
    //     0x847bcc: str             q0, [SP, #-0x10]!
    // 0x847bd0: SaveReg r0
    //     0x847bd0: str             x0, [SP, #-8]!
    // 0x847bd4: r0 = AllocateDouble()
    //     0x847bd4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x847bd8: mov             x1, x0
    // 0x847bdc: RestoreReg r0
    //     0x847bdc: ldr             x0, [SP], #8
    // 0x847be0: RestoreReg d0
    //     0x847be0: ldr             q0, [SP], #0x10
    // 0x847be4: b               #0x847440
    // 0x847be8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847be8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847bec: SaveReg d0
    //     0x847bec: str             q0, [SP, #-0x10]!
    // 0x847bf0: r0 = AllocateDouble()
    //     0x847bf0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x847bf4: RestoreReg d0
    //     0x847bf4: ldr             q0, [SP], #0x10
    // 0x847bf8: b               #0x84751c
    // 0x847bfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847bfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847c00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847c00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847c04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847c04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847c08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847c08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847c0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847c0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847c10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x847c10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x847c14: r0 = NullCastErrorSharedWithFPURegs()
    //     0x847c14: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _systemOverlayStyleForBrightness(/* No info */) {
    // ** addr: 0x847ca8, size: 0xa4
    // 0x847ca8: EnterFrame
    //     0x847ca8: stp             fp, lr, [SP, #-0x10]!
    //     0x847cac: mov             fp, SP
    // 0x847cb0: AllocStack(0x18)
    //     0x847cb0: sub             SP, SP, #0x18
    // 0x847cb4: SetupParameters(_AppBarState<AppBar> this /* r1 */, [dynamic _ = Null /* r0, fp-0x18 */])
    //     0x847cb4: mov             x0, x4
    //     0x847cb8: ldur            w1, [x0, #0x13]
    //     0x847cbc: add             x1, x1, HEAP, lsl #32
    //     0x847cc0: sub             x0, x1, #4
    //     0x847cc4: add             x1, fp, w0, sxtw #2
    //     0x847cc8: ldr             x1, [x1, #0x10]
    //     0x847ccc: cmp             w0, #2
    //     0x847cd0: b.lt            #0x847ce4
    //     0x847cd4: add             x2, fp, w0, sxtw #2
    //     0x847cd8: ldr             x2, [x2, #8]
    //     0x847cdc: mov             x0, x2
    //     0x847ce0: b               #0x847ce8
    //     0x847ce4: mov             x0, NULL
    //     0x847ce8: stur            x0, [fp, #-0x18]
    // 0x847cec: r16 = Instance_Brightness
    //     0x847cec: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x847cf0: cmp             w1, w16
    // 0x847cf4: b.ne            #0x847d04
    // 0x847cf8: r1 = Instance_SystemUiOverlayStyle
    //     0x847cf8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a78] Obj!SystemUiOverlayStyle@b34841
    //     0x847cfc: ldr             x1, [x1, #0xa78]
    // 0x847d00: b               #0x847d0c
    // 0x847d04: r1 = Instance_SystemUiOverlayStyle
    //     0x847d04: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a80] Obj!SystemUiOverlayStyle@b34811
    //     0x847d08: ldr             x1, [x1, #0xa80]
    // 0x847d0c: LoadField: r2 = r1->field_1b
    //     0x847d0c: ldur            w2, [x1, #0x1b]
    // 0x847d10: DecompressPointer r2
    //     0x847d10: add             x2, x2, HEAP, lsl #32
    // 0x847d14: stur            x2, [fp, #-0x10]
    // 0x847d18: LoadField: r3 = r1->field_1f
    //     0x847d18: ldur            w3, [x1, #0x1f]
    // 0x847d1c: DecompressPointer r3
    //     0x847d1c: add             x3, x3, HEAP, lsl #32
    // 0x847d20: stur            x3, [fp, #-8]
    // 0x847d24: r0 = SystemUiOverlayStyle()
    //     0x847d24: bl              #0x5ddcf8  ; AllocateSystemUiOverlayStyleStub -> SystemUiOverlayStyle (size=0x28)
    // 0x847d28: ldur            x1, [fp, #-0x18]
    // 0x847d2c: StoreField: r0->field_17 = r1
    //     0x847d2c: stur            w1, [x0, #0x17]
    // 0x847d30: ldur            x1, [fp, #-0x10]
    // 0x847d34: StoreField: r0->field_1b = r1
    //     0x847d34: stur            w1, [x0, #0x1b]
    // 0x847d38: ldur            x1, [fp, #-8]
    // 0x847d3c: StoreField: r0->field_1f = r1
    //     0x847d3c: stur            w1, [x0, #0x1f]
    // 0x847d40: LeaveFrame
    //     0x847d40: mov             SP, fp
    //     0x847d44: ldp             fp, lr, [SP], #0x10
    // 0x847d48: ret
    //     0x847d48: ret             
  }
  _ _resolveColor(/* No info */) {
    // ** addr: 0x8486d4, size: 0xa4
    // 0x8486d4: EnterFrame
    //     0x8486d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8486d8: mov             fp, SP
    // 0x8486dc: CheckStackOverflow
    //     0x8486dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8486e0: cmp             SP, x16
    //     0x8486e4: b.ls            #0x848770
    // 0x8486e8: r16 = <Color?>
    //     0x8486e8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x8486ec: ldr             x16, [x16, #0xf68]
    // 0x8486f0: ldr             lr, [fp, #0x20]
    // 0x8486f4: stp             lr, x16, [SP, #-0x10]!
    // 0x8486f8: ldr             x16, [fp, #0x28]
    // 0x8486fc: SaveReg r16
    //     0x8486fc: str             x16, [SP, #-8]!
    // 0x848700: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x848700: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x848704: r0 = resolveAs()
    //     0x848704: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x848708: add             SP, SP, #0x18
    // 0x84870c: cmp             w0, NULL
    // 0x848710: b.ne            #0x848738
    // 0x848714: r16 = <Color?>
    //     0x848714: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x848718: ldr             x16, [x16, #0xf68]
    // 0x84871c: ldr             lr, [fp, #0x18]
    // 0x848720: stp             lr, x16, [SP, #-0x10]!
    // 0x848724: ldr             x16, [fp, #0x28]
    // 0x848728: SaveReg r16
    //     0x848728: str             x16, [SP, #-8]!
    // 0x84872c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x84872c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x848730: r0 = resolveAs()
    //     0x848730: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x848734: add             SP, SP, #0x18
    // 0x848738: cmp             w0, NULL
    // 0x84873c: b.ne            #0x848764
    // 0x848740: r16 = <Color>
    //     0x848740: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x848744: ldr             x16, [x16, #0x3f8]
    // 0x848748: ldr             lr, [fp, #0x10]
    // 0x84874c: stp             lr, x16, [SP, #-0x10]!
    // 0x848750: ldr             x16, [fp, #0x28]
    // 0x848754: SaveReg r16
    //     0x848754: str             x16, [SP, #-8]!
    // 0x848758: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x848758: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x84875c: r0 = resolveAs()
    //     0x84875c: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x848760: add             SP, SP, #0x18
    // 0x848764: LeaveFrame
    //     0x848764: mov             SP, fp
    //     0x848768: ldp             fp, lr, [SP], #0x10
    // 0x84876c: ret
    //     0x84876c: ret             
    // 0x848770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848770: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848774: b               #0x8486e8
  }
  [closure] void _handleDrawerButtonEnd(dynamic) {
    // ** addr: 0x848a80, size: 0x48
    // 0x848a80: EnterFrame
    //     0x848a80: stp             fp, lr, [SP, #-0x10]!
    //     0x848a84: mov             fp, SP
    // 0x848a88: ldr             x0, [fp, #0x10]
    // 0x848a8c: LoadField: r1 = r0->field_17
    //     0x848a8c: ldur            w1, [x0, #0x17]
    // 0x848a90: DecompressPointer r1
    //     0x848a90: add             x1, x1, HEAP, lsl #32
    // 0x848a94: CheckStackOverflow
    //     0x848a94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848a98: cmp             SP, x16
    //     0x848a9c: b.ls            #0x848ac0
    // 0x848aa0: LoadField: r0 = r1->field_f
    //     0x848aa0: ldur            w0, [x1, #0xf]
    // 0x848aa4: DecompressPointer r0
    //     0x848aa4: add             x0, x0, HEAP, lsl #32
    // 0x848aa8: SaveReg r0
    //     0x848aa8: str             x0, [SP, #-8]!
    // 0x848aac: r0 = _handleDrawerButtonEnd()
    //     0x848aac: bl              #0x848ac8  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_handleDrawerButtonEnd
    // 0x848ab0: add             SP, SP, #8
    // 0x848ab4: LeaveFrame
    //     0x848ab4: mov             SP, fp
    //     0x848ab8: ldp             fp, lr, [SP], #0x10
    // 0x848abc: ret
    //     0x848abc: ret             
    // 0x848ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848ac0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848ac4: b               #0x848aa0
  }
  _ _handleDrawerButtonEnd(/* No info */) {
    // ** addr: 0x848ac8, size: 0x5c
    // 0x848ac8: EnterFrame
    //     0x848ac8: stp             fp, lr, [SP, #-0x10]!
    //     0x848acc: mov             fp, SP
    // 0x848ad0: CheckStackOverflow
    //     0x848ad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848ad4: cmp             SP, x16
    //     0x848ad8: b.ls            #0x848b18
    // 0x848adc: ldr             x0, [fp, #0x10]
    // 0x848ae0: LoadField: r1 = r0->field_f
    //     0x848ae0: ldur            w1, [x0, #0xf]
    // 0x848ae4: DecompressPointer r1
    //     0x848ae4: add             x1, x1, HEAP, lsl #32
    // 0x848ae8: cmp             w1, NULL
    // 0x848aec: b.eq            #0x848b20
    // 0x848af0: SaveReg r1
    //     0x848af0: str             x1, [SP, #-8]!
    // 0x848af4: r0 = of()
    //     0x848af4: bl              #0x848d60  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0x848af8: add             SP, SP, #8
    // 0x848afc: SaveReg r0
    //     0x848afc: str             x0, [SP, #-8]!
    // 0x848b00: r0 = openEndDrawer()
    //     0x848b00: bl              #0x848b24  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::openEndDrawer
    // 0x848b04: add             SP, SP, #8
    // 0x848b08: r0 = Null
    //     0x848b08: mov             x0, NULL
    // 0x848b0c: LeaveFrame
    //     0x848b0c: mov             SP, fp
    //     0x848b10: ldp             fp, lr, [SP], #0x10
    // 0x848b14: ret
    //     0x848b14: ret             
    // 0x848b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848b18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848b1c: b               #0x848adc
    // 0x848b20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x848b20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDrawerButton(dynamic) {
    // ** addr: 0x848edc, size: 0x48
    // 0x848edc: EnterFrame
    //     0x848edc: stp             fp, lr, [SP, #-0x10]!
    //     0x848ee0: mov             fp, SP
    // 0x848ee4: ldr             x0, [fp, #0x10]
    // 0x848ee8: LoadField: r1 = r0->field_17
    //     0x848ee8: ldur            w1, [x0, #0x17]
    // 0x848eec: DecompressPointer r1
    //     0x848eec: add             x1, x1, HEAP, lsl #32
    // 0x848ef0: CheckStackOverflow
    //     0x848ef0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848ef4: cmp             SP, x16
    //     0x848ef8: b.ls            #0x848f1c
    // 0x848efc: LoadField: r0 = r1->field_f
    //     0x848efc: ldur            w0, [x1, #0xf]
    // 0x848f00: DecompressPointer r0
    //     0x848f00: add             x0, x0, HEAP, lsl #32
    // 0x848f04: SaveReg r0
    //     0x848f04: str             x0, [SP, #-8]!
    // 0x848f08: r0 = _handleDrawerButton()
    //     0x848f08: bl              #0x848f24  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_handleDrawerButton
    // 0x848f0c: add             SP, SP, #8
    // 0x848f10: LeaveFrame
    //     0x848f10: mov             SP, fp
    //     0x848f14: ldp             fp, lr, [SP], #0x10
    // 0x848f18: ret
    //     0x848f18: ret             
    // 0x848f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848f1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848f20: b               #0x848efc
  }
  _ _handleDrawerButton(/* No info */) {
    // ** addr: 0x848f24, size: 0x5c
    // 0x848f24: EnterFrame
    //     0x848f24: stp             fp, lr, [SP, #-0x10]!
    //     0x848f28: mov             fp, SP
    // 0x848f2c: CheckStackOverflow
    //     0x848f2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848f30: cmp             SP, x16
    //     0x848f34: b.ls            #0x848f74
    // 0x848f38: ldr             x0, [fp, #0x10]
    // 0x848f3c: LoadField: r1 = r0->field_f
    //     0x848f3c: ldur            w1, [x0, #0xf]
    // 0x848f40: DecompressPointer r1
    //     0x848f40: add             x1, x1, HEAP, lsl #32
    // 0x848f44: cmp             w1, NULL
    // 0x848f48: b.eq            #0x848f7c
    // 0x848f4c: SaveReg r1
    //     0x848f4c: str             x1, [SP, #-8]!
    // 0x848f50: r0 = of()
    //     0x848f50: bl              #0x848d60  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0x848f54: add             SP, SP, #8
    // 0x848f58: SaveReg r0
    //     0x848f58: str             x0, [SP, #-8]!
    // 0x848f5c: r0 = openDrawer()
    //     0x848f5c: bl              #0x848f80  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::openDrawer
    // 0x848f60: add             SP, SP, #8
    // 0x848f64: r0 = Null
    //     0x848f64: mov             x0, NULL
    // 0x848f68: LeaveFrame
    //     0x848f68: mov             SP, fp
    //     0x848f6c: ldp             fp, lr, [SP], #0x10
    // 0x848f70: ret
    //     0x848f70: ret             
    // 0x848f74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848f74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848f78: b               #0x848f38
    // 0x848f7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x848f7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a9a8, size: 0x18
    // 0xa4a9a8: r4 = 7
    //     0xa4a9a8: mov             x4, #7
    // 0xa4a9ac: r1 = Function 'dispose':.
    //     0xa4a9ac: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b990] AnonymousClosure: (0xa4a9c0), in [package:flutter/src/material/app_bar.dart] _AppBarState::dispose (0xa50bfc)
    //     0xa4a9b0: ldr             x1, [x17, #0x990]
    // 0xa4a9b4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a9b4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a9b8: LoadField: r0 = r24->field_17
    //     0xa4a9b8: ldur            x0, [x24, #0x17]
    // 0xa4a9bc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a9c0, size: 0x48
    // 0xa4a9c0: EnterFrame
    //     0xa4a9c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a9c4: mov             fp, SP
    // 0xa4a9c8: ldr             x0, [fp, #0x10]
    // 0xa4a9cc: LoadField: r1 = r0->field_17
    //     0xa4a9cc: ldur            w1, [x0, #0x17]
    // 0xa4a9d0: DecompressPointer r1
    //     0xa4a9d0: add             x1, x1, HEAP, lsl #32
    // 0xa4a9d4: CheckStackOverflow
    //     0xa4a9d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a9d8: cmp             SP, x16
    //     0xa4a9dc: b.ls            #0xa4aa00
    // 0xa4a9e0: LoadField: r0 = r1->field_f
    //     0xa4a9e0: ldur            w0, [x1, #0xf]
    // 0xa4a9e4: DecompressPointer r0
    //     0xa4a9e4: add             x0, x0, HEAP, lsl #32
    // 0xa4a9e8: SaveReg r0
    //     0xa4a9e8: str             x0, [SP, #-8]!
    // 0xa4a9ec: r0 = dispose()
    //     0xa4a9ec: bl              #0xa50bfc  ; [package:flutter/src/material/app_bar.dart] _AppBarState::dispose
    // 0xa4a9f0: add             SP, SP, #8
    // 0xa4a9f4: LeaveFrame
    //     0xa4a9f4: mov             SP, fp
    //     0xa4a9f8: ldp             fp, lr, [SP], #0x10
    // 0xa4a9fc: ret
    //     0xa4a9fc: ret             
    // 0xa4aa00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4aa00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4aa04: b               #0xa4a9e0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50bfc, size: 0x84
    // 0xa50bfc: EnterFrame
    //     0xa50bfc: stp             fp, lr, [SP, #-0x10]!
    //     0xa50c00: mov             fp, SP
    // 0xa50c04: AllocStack(0x8)
    //     0xa50c04: sub             SP, SP, #8
    // 0xa50c08: CheckStackOverflow
    //     0xa50c08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50c0c: cmp             SP, x16
    //     0xa50c10: b.ls            #0xa50c78
    // 0xa50c14: ldr             x0, [fp, #0x10]
    // 0xa50c18: LoadField: r1 = r0->field_13
    //     0xa50c18: ldur            w1, [x0, #0x13]
    // 0xa50c1c: DecompressPointer r1
    //     0xa50c1c: add             x1, x1, HEAP, lsl #32
    // 0xa50c20: stur            x1, [fp, #-8]
    // 0xa50c24: cmp             w1, NULL
    // 0xa50c28: b.eq            #0xa50c68
    // 0xa50c2c: r1 = 1
    //     0xa50c2c: mov             x1, #1
    // 0xa50c30: r0 = AllocateContext()
    //     0xa50c30: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa50c34: mov             x1, x0
    // 0xa50c38: ldr             x0, [fp, #0x10]
    // 0xa50c3c: StoreField: r1->field_f = r0
    //     0xa50c3c: stur            w0, [x1, #0xf]
    // 0xa50c40: mov             x2, x1
    // 0xa50c44: r1 = Function '_handleScrollNotification@680187611':.
    //     0xa50c44: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a88] AnonymousClosure: (0xa50e74), in [package:flutter/src/material/app_bar.dart] _AppBarState::_handleScrollNotification (0xa50ec0)
    //     0xa50c48: ldr             x1, [x1, #0xa88]
    // 0xa50c4c: r0 = AllocateClosure()
    //     0xa50c4c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa50c50: ldur            x16, [fp, #-8]
    // 0xa50c54: stp             x0, x16, [SP, #-0x10]!
    // 0xa50c58: r0 = removeListener()
    //     0xa50c58: bl              #0xa50c80  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserverState::removeListener
    // 0xa50c5c: add             SP, SP, #0x10
    // 0xa50c60: ldr             x1, [fp, #0x10]
    // 0xa50c64: StoreField: r1->field_13 = rNULL
    //     0xa50c64: stur            NULL, [x1, #0x13]
    // 0xa50c68: r0 = Null
    //     0xa50c68: mov             x0, NULL
    // 0xa50c6c: LeaveFrame
    //     0xa50c6c: mov             SP, fp
    //     0xa50c70: ldp             fp, lr, [SP], #0x10
    // 0xa50c74: ret
    //     0xa50c74: ret             
    // 0xa50c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50c78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50c7c: b               #0xa50c14
  }
  [closure] void _handleScrollNotification(dynamic, ScrollNotification) {
    // ** addr: 0xa50e74, size: 0x4c
    // 0xa50e74: EnterFrame
    //     0xa50e74: stp             fp, lr, [SP, #-0x10]!
    //     0xa50e78: mov             fp, SP
    // 0xa50e7c: ldr             x0, [fp, #0x18]
    // 0xa50e80: LoadField: r1 = r0->field_17
    //     0xa50e80: ldur            w1, [x0, #0x17]
    // 0xa50e84: DecompressPointer r1
    //     0xa50e84: add             x1, x1, HEAP, lsl #32
    // 0xa50e88: CheckStackOverflow
    //     0xa50e88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50e8c: cmp             SP, x16
    //     0xa50e90: b.ls            #0xa50eb8
    // 0xa50e94: LoadField: r0 = r1->field_f
    //     0xa50e94: ldur            w0, [x1, #0xf]
    // 0xa50e98: DecompressPointer r0
    //     0xa50e98: add             x0, x0, HEAP, lsl #32
    // 0xa50e9c: ldr             x16, [fp, #0x10]
    // 0xa50ea0: stp             x16, x0, [SP, #-0x10]!
    // 0xa50ea4: r0 = _handleScrollNotification()
    //     0xa50ea4: bl              #0xa50ec0  ; [package:flutter/src/material/app_bar.dart] _AppBarState::_handleScrollNotification
    // 0xa50ea8: add             SP, SP, #0x10
    // 0xa50eac: LeaveFrame
    //     0xa50eac: mov             SP, fp
    //     0xa50eb0: ldp             fp, lr, [SP], #0x10
    // 0xa50eb4: ret
    //     0xa50eb4: ret             
    // 0xa50eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50eb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50ebc: b               #0xa50e94
  }
  _ _handleScrollNotification(/* No info */) {
    // ** addr: 0xa50ec0, size: 0x1a8
    // 0xa50ec0: EnterFrame
    //     0xa50ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xa50ec4: mov             fp, SP
    // 0xa50ec8: AllocStack(0x8)
    //     0xa50ec8: sub             SP, SP, #8
    // 0xa50ecc: CheckStackOverflow
    //     0xa50ecc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50ed0: cmp             SP, x16
    //     0xa50ed4: b.ls            #0xa5105c
    // 0xa50ed8: ldr             x1, [fp, #0x10]
    // 0xa50edc: r0 = LoadClassIdInstr(r1)
    //     0xa50edc: ldur            x0, [x1, #-1]
    //     0xa50ee0: ubfx            x0, x0, #0xc, #0x14
    // 0xa50ee4: lsl             x0, x0, #1
    // 0xa50ee8: r2 = LoadInt32Instr(r0)
    //     0xa50ee8: sbfx            x2, x0, #1, #0x1f
    // 0xa50eec: cmp             x2, #0x731
    // 0xa50ef0: b.lt            #0xa5104c
    // 0xa50ef4: cmp             x2, #0x732
    // 0xa50ef8: b.gt            #0xa5104c
    // 0xa50efc: ldr             x2, [fp, #0x18]
    // 0xa50f00: LoadField: r0 = r2->field_b
    //     0xa50f00: ldur            w0, [x2, #0xb]
    // 0xa50f04: DecompressPointer r0
    //     0xa50f04: add             x0, x0, HEAP, lsl #32
    // 0xa50f08: cmp             w0, NULL
    // 0xa50f0c: b.eq            #0xa51064
    // 0xa50f10: LoadField: r3 = r0->field_2b
    //     0xa50f10: ldur            w3, [x0, #0x2b]
    // 0xa50f14: DecompressPointer r3
    //     0xa50f14: add             x3, x3, HEAP, lsl #32
    // 0xa50f18: stp             x1, x3, [SP, #-0x10]!
    // 0xa50f1c: mov             x0, x3
    // 0xa50f20: ClosureCall
    //     0xa50f20: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xa50f24: ldur            x2, [x0, #0x1f]
    //     0xa50f28: blr             x2
    // 0xa50f2c: add             SP, SP, #0x10
    // 0xa50f30: mov             x1, x0
    // 0xa50f34: stur            x1, [fp, #-8]
    // 0xa50f38: tbnz            w0, #5, #0xa50f40
    // 0xa50f3c: r0 = AssertBoolean()
    //     0xa50f3c: bl              #0xd67df0  ; AssertBooleanStub
    // 0xa50f40: ldur            x0, [fp, #-8]
    // 0xa50f44: tbnz            w0, #4, #0xa5104c
    // 0xa50f48: ldr             x1, [fp, #0x18]
    // 0xa50f4c: ldr             x0, [fp, #0x10]
    // 0xa50f50: LoadField: r2 = r1->field_17
    //     0xa50f50: ldur            w2, [x1, #0x17]
    // 0xa50f54: DecompressPointer r2
    //     0xa50f54: add             x2, x2, HEAP, lsl #32
    // 0xa50f58: stur            x2, [fp, #-8]
    // 0xa50f5c: LoadField: r3 = r0->field_f
    //     0xa50f5c: ldur            w3, [x0, #0xf]
    // 0xa50f60: DecompressPointer r3
    //     0xa50f60: add             x3, x3, HEAP, lsl #32
    // 0xa50f64: LoadField: r0 = r3->field_17
    //     0xa50f64: ldur            w0, [x3, #0x17]
    // 0xa50f68: DecompressPointer r0
    //     0xa50f68: add             x0, x0, HEAP, lsl #32
    // 0xa50f6c: LoadField: r4 = r0->field_7
    //     0xa50f6c: ldur            x4, [x0, #7]
    // 0xa50f70: cmp             x4, #1
    // 0xa50f74: b.gt            #0xa50fc8
    // 0xa50f78: cmp             x4, #0
    // 0xa50f7c: b.gt            #0xa50fc0
    // 0xa50f80: SaveReg r3
    //     0xa50f80: str             x3, [SP, #-8]!
    // 0xa50f84: r0 = extentAfter()
    //     0xa50f84: bl              #0xa82b60  ; [package:flutter/src/widgets/scroll_metrics.dart] _FixedScrollMetrics&Object&ScrollMetrics::extentAfter
    // 0xa50f88: add             SP, SP, #8
    // 0xa50f8c: mov             v1.16b, v0.16b
    // 0xa50f90: d0 = 0.000000
    //     0xa50f90: eor             v0.16b, v0.16b, v0.16b
    // 0xa50f94: fcmp            d1, d0
    // 0xa50f98: b.vs            #0xa50fa0
    // 0xa50f9c: b.gt            #0xa50fa8
    // 0xa50fa0: r0 = false
    //     0xa50fa0: add             x0, NULL, #0x30  ; false
    // 0xa50fa4: b               #0xa50fac
    // 0xa50fa8: r0 = true
    //     0xa50fa8: add             x0, NULL, #0x20  ; true
    // 0xa50fac: ldr             x1, [fp, #0x18]
    // 0xa50fb0: StoreField: r1->field_17 = r0
    //     0xa50fb0: stur            w0, [x1, #0x17]
    // 0xa50fb4: mov             x3, x1
    // 0xa50fb8: mov             x1, x0
    // 0xa50fbc: b               #0xa51020
    // 0xa50fc0: mov             x3, x1
    // 0xa50fc4: b               #0xa51014
    // 0xa50fc8: d0 = 0.000000
    //     0xa50fc8: eor             v0.16b, v0.16b, v0.16b
    // 0xa50fcc: cmp             x4, #2
    // 0xa50fd0: b.gt            #0xa51010
    // 0xa50fd4: SaveReg r3
    //     0xa50fd4: str             x3, [SP, #-8]!
    // 0xa50fd8: r0 = extentBefore()
    //     0xa50fd8: bl              #0xbfc890  ; [package:flutter/src/widgets/scroll_metrics.dart] _FixedScrollMetrics&Object&ScrollMetrics::extentBefore
    // 0xa50fdc: add             SP, SP, #8
    // 0xa50fe0: mov             v1.16b, v0.16b
    // 0xa50fe4: d0 = 0.000000
    //     0xa50fe4: eor             v0.16b, v0.16b, v0.16b
    // 0xa50fe8: fcmp            d1, d0
    // 0xa50fec: b.vs            #0xa50ff4
    // 0xa50ff0: b.gt            #0xa50ffc
    // 0xa50ff4: r0 = false
    //     0xa50ff4: add             x0, NULL, #0x30  ; false
    // 0xa50ff8: b               #0xa51000
    // 0xa50ffc: r0 = true
    //     0xa50ffc: add             x0, NULL, #0x20  ; true
    // 0xa51000: ldr             x3, [fp, #0x18]
    // 0xa51004: StoreField: r3->field_17 = r0
    //     0xa51004: stur            w0, [x3, #0x17]
    // 0xa51008: mov             x1, x0
    // 0xa5100c: b               #0xa51020
    // 0xa51010: mov             x3, x1
    // 0xa51014: r0 = false
    //     0xa51014: add             x0, NULL, #0x30  ; false
    // 0xa51018: StoreField: r3->field_17 = r0
    //     0xa51018: stur            w0, [x3, #0x17]
    // 0xa5101c: r1 = false
    //     0xa5101c: add             x1, NULL, #0x30  ; false
    // 0xa51020: ldur            x0, [fp, #-8]
    // 0xa51024: cmp             w1, w0
    // 0xa51028: b.eq            #0xa5104c
    // 0xa5102c: r1 = Function '<anonymous closure>':.
    //     0xa5102c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a90] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xa51030: ldr             x1, [x1, #0xa90]
    // 0xa51034: r2 = Null
    //     0xa51034: mov             x2, NULL
    // 0xa51038: r0 = AllocateClosure()
    //     0xa51038: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa5103c: ldr             x16, [fp, #0x18]
    // 0xa51040: stp             x0, x16, [SP, #-0x10]!
    // 0xa51044: r0 = setState()
    //     0xa51044: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xa51048: add             SP, SP, #0x10
    // 0xa5104c: r0 = Null
    //     0xa5104c: mov             x0, NULL
    // 0xa51050: LeaveFrame
    //     0xa51050: mov             SP, fp
    //     0xa51054: ldp             fp, lr, [SP], #0x10
    // 0xa51058: ret
    //     0xa51058: ret             
    // 0xa5105c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5105c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa51060: b               #0xa50ed8
    // 0xa51064: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa51064: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa60f8c, size: 0x104
    // 0xa60f8c: EnterFrame
    //     0xa60f8c: stp             fp, lr, [SP, #-0x10]!
    //     0xa60f90: mov             fp, SP
    // 0xa60f94: AllocStack(0x8)
    //     0xa60f94: sub             SP, SP, #8
    // 0xa60f98: CheckStackOverflow
    //     0xa60f98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60f9c: cmp             SP, x16
    //     0xa60fa0: b.ls            #0xa61084
    // 0xa60fa4: ldr             x0, [fp, #0x10]
    // 0xa60fa8: LoadField: r1 = r0->field_13
    //     0xa60fa8: ldur            w1, [x0, #0x13]
    // 0xa60fac: DecompressPointer r1
    //     0xa60fac: add             x1, x1, HEAP, lsl #32
    // 0xa60fb0: stur            x1, [fp, #-8]
    // 0xa60fb4: cmp             w1, NULL
    // 0xa60fb8: b.eq            #0xa60ff4
    // 0xa60fbc: r1 = 1
    //     0xa60fbc: mov             x1, #1
    // 0xa60fc0: r0 = AllocateContext()
    //     0xa60fc0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa60fc4: mov             x1, x0
    // 0xa60fc8: ldr             x0, [fp, #0x10]
    // 0xa60fcc: StoreField: r1->field_f = r0
    //     0xa60fcc: stur            w0, [x1, #0xf]
    // 0xa60fd0: mov             x2, x1
    // 0xa60fd4: r1 = Function '_handleScrollNotification@680187611':.
    //     0xa60fd4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a88] AnonymousClosure: (0xa50e74), in [package:flutter/src/material/app_bar.dart] _AppBarState::_handleScrollNotification (0xa50ec0)
    //     0xa60fd8: ldr             x1, [x1, #0xa88]
    // 0xa60fdc: r0 = AllocateClosure()
    //     0xa60fdc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa60fe0: ldur            x16, [fp, #-8]
    // 0xa60fe4: stp             x0, x16, [SP, #-0x10]!
    // 0xa60fe8: r0 = removeListener()
    //     0xa60fe8: bl              #0xa50c80  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserverState::removeListener
    // 0xa60fec: add             SP, SP, #0x10
    // 0xa60ff0: ldr             x0, [fp, #0x10]
    // 0xa60ff4: LoadField: r1 = r0->field_f
    //     0xa60ff4: ldur            w1, [x0, #0xf]
    // 0xa60ff8: DecompressPointer r1
    //     0xa60ff8: add             x1, x1, HEAP, lsl #32
    // 0xa60ffc: cmp             w1, NULL
    // 0xa61000: b.eq            #0xa6108c
    // 0xa61004: SaveReg r1
    //     0xa61004: str             x1, [SP, #-8]!
    // 0xa61008: r0 = maybeOf()
    //     0xa61008: bl              #0xa61160  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserver::maybeOf
    // 0xa6100c: add             SP, SP, #8
    // 0xa61010: mov             x2, x0
    // 0xa61014: ldr             x1, [fp, #0x10]
    // 0xa61018: stur            x2, [fp, #-8]
    // 0xa6101c: StoreField: r1->field_13 = r0
    //     0xa6101c: stur            w0, [x1, #0x13]
    //     0xa61020: ldurb           w16, [x1, #-1]
    //     0xa61024: ldurb           w17, [x0, #-1]
    //     0xa61028: and             x16, x17, x16, lsr #2
    //     0xa6102c: tst             x16, HEAP, lsr #32
    //     0xa61030: b.eq            #0xa61038
    //     0xa61034: bl              #0xd6826c
    // 0xa61038: cmp             w2, NULL
    // 0xa6103c: b.eq            #0xa61074
    // 0xa61040: r1 = 1
    //     0xa61040: mov             x1, #1
    // 0xa61044: r0 = AllocateContext()
    //     0xa61044: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa61048: mov             x1, x0
    // 0xa6104c: ldr             x0, [fp, #0x10]
    // 0xa61050: StoreField: r1->field_f = r0
    //     0xa61050: stur            w0, [x1, #0xf]
    // 0xa61054: mov             x2, x1
    // 0xa61058: r1 = Function '_handleScrollNotification@680187611':.
    //     0xa61058: add             x1, PP, #0x37, lsl #12  ; [pp+0x37a88] AnonymousClosure: (0xa50e74), in [package:flutter/src/material/app_bar.dart] _AppBarState::_handleScrollNotification (0xa50ec0)
    //     0xa6105c: ldr             x1, [x1, #0xa88]
    // 0xa61060: r0 = AllocateClosure()
    //     0xa61060: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa61064: ldur            x16, [fp, #-8]
    // 0xa61068: stp             x0, x16, [SP, #-0x10]!
    // 0xa6106c: r0 = addListener()
    //     0xa6106c: bl              #0xa61090  ; [package:flutter/src/widgets/scroll_notification_observer.dart] ScrollNotificationObserverState::addListener
    // 0xa61070: add             SP, SP, #0x10
    // 0xa61074: r0 = Null
    //     0xa61074: mov             x0, NULL
    // 0xa61078: LeaveFrame
    //     0xa61078: mov             SP, fp
    //     0xa6107c: ldp             fp, lr, [SP], #0x10
    // 0xa61080: ret
    //     0xa61080: ret             
    // 0xa61084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61084: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61088: b               #0xa60fa4
    // 0xa6108c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6108c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3676, size: 0x10, field offset: 0x10
//   const constructor, 
class _AppBarTitleBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c24cc, size: 0xb0
    // 0x6c24cc: EnterFrame
    //     0x6c24cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c24d0: mov             fp, SP
    // 0x6c24d4: CheckStackOverflow
    //     0x6c24d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c24d8: cmp             SP, x16
    //     0x6c24dc: b.ls            #0x6c2574
    // 0x6c24e0: ldr             x0, [fp, #0x10]
    // 0x6c24e4: r2 = Null
    //     0x6c24e4: mov             x2, NULL
    // 0x6c24e8: r1 = Null
    //     0x6c24e8: mov             x1, NULL
    // 0x6c24ec: r4 = 59
    //     0x6c24ec: mov             x4, #0x3b
    // 0x6c24f0: branchIfSmi(r0, 0x6c24fc)
    //     0x6c24f0: tbz             w0, #0, #0x6c24fc
    // 0x6c24f4: r4 = LoadClassIdInstr(r0)
    //     0x6c24f4: ldur            x4, [x0, #-1]
    //     0x6c24f8: ubfx            x4, x4, #0xc, #0x14
    // 0x6c24fc: cmp             x4, #0x9a7
    // 0x6c2500: b.eq            #0x6c2518
    // 0x6c2504: r8 = _RenderAppBarTitleBox
    //     0x6c2504: add             x8, PP, #0x40, lsl #12  ; [pp+0x40308] Type: _RenderAppBarTitleBox
    //     0x6c2508: ldr             x8, [x8, #0x308]
    // 0x6c250c: r3 = Null
    //     0x6c250c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40310] Null
    //     0x6c2510: ldr             x3, [x3, #0x310]
    // 0x6c2514: r0 = DefaultTypeTest()
    //     0x6c2514: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c2518: ldr             x16, [fp, #0x18]
    // 0x6c251c: SaveReg r16
    //     0x6c251c: str             x16, [SP, #-8]!
    // 0x6c2520: r0 = of()
    //     0x6c2520: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x6c2524: add             SP, SP, #8
    // 0x6c2528: ldr             x1, [fp, #0x10]
    // 0x6c252c: LoadField: r2 = r1->field_6b
    //     0x6c252c: ldur            w2, [x1, #0x6b]
    // 0x6c2530: DecompressPointer r2
    //     0x6c2530: add             x2, x2, HEAP, lsl #32
    // 0x6c2534: cmp             w2, w0
    // 0x6c2538: b.eq            #0x6c2564
    // 0x6c253c: StoreField: r1->field_6b = r0
    //     0x6c253c: stur            w0, [x1, #0x6b]
    //     0x6c2540: ldurb           w16, [x1, #-1]
    //     0x6c2544: ldurb           w17, [x0, #-1]
    //     0x6c2548: and             x16, x17, x16, lsr #2
    //     0x6c254c: tst             x16, HEAP, lsr #32
    //     0x6c2550: b.eq            #0x6c2558
    //     0x6c2554: bl              #0xd6826c
    // 0x6c2558: SaveReg r1
    //     0x6c2558: str             x1, [SP, #-8]!
    // 0x6c255c: r0 = _markNeedResolution()
    //     0x6c255c: bl              #0x6c25fc  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0x6c2560: add             SP, SP, #8
    // 0x6c2564: r0 = Null
    //     0x6c2564: mov             x0, NULL
    // 0x6c2568: LeaveFrame
    //     0x6c2568: mov             SP, fp
    //     0x6c256c: ldp             fp, lr, [SP], #0x10
    // 0x6c2570: ret
    //     0x6c2570: ret             
    // 0x6c2574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2574: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2578: b               #0x6c24e0
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6ea118, size: 0x80
    // 0x6ea118: EnterFrame
    //     0x6ea118: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea11c: mov             fp, SP
    // 0x6ea120: AllocStack(0x10)
    //     0x6ea120: sub             SP, SP, #0x10
    // 0x6ea124: CheckStackOverflow
    //     0x6ea124: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea128: cmp             SP, x16
    //     0x6ea12c: b.ls            #0x6ea190
    // 0x6ea130: ldr             x16, [fp, #0x10]
    // 0x6ea134: SaveReg r16
    //     0x6ea134: str             x16, [SP, #-8]!
    // 0x6ea138: r0 = of()
    //     0x6ea138: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x6ea13c: add             SP, SP, #8
    // 0x6ea140: stur            x0, [fp, #-8]
    // 0x6ea144: r0 = _RenderAppBarTitleBox()
    //     0x6ea144: bl              #0x6ea198  ; Allocate_RenderAppBarTitleBoxStub -> _RenderAppBarTitleBox (size=0x70)
    // 0x6ea148: mov             x1, x0
    // 0x6ea14c: r0 = Instance_Alignment
    //     0x6ea14c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6ea150: ldr             x0, [x0, #0xc70]
    // 0x6ea154: stur            x1, [fp, #-0x10]
    // 0x6ea158: StoreField: r1->field_67 = r0
    //     0x6ea158: stur            w0, [x1, #0x67]
    // 0x6ea15c: ldur            x0, [fp, #-8]
    // 0x6ea160: StoreField: r1->field_6b = r0
    //     0x6ea160: stur            w0, [x1, #0x6b]
    // 0x6ea164: SaveReg r1
    //     0x6ea164: str             x1, [SP, #-8]!
    // 0x6ea168: r0 = RenderObject()
    //     0x6ea168: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ea16c: add             SP, SP, #8
    // 0x6ea170: ldur            x16, [fp, #-0x10]
    // 0x6ea174: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea178: r0 = child=()
    //     0x6ea178: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ea17c: add             SP, SP, #0x10
    // 0x6ea180: ldur            x0, [fp, #-0x10]
    // 0x6ea184: LeaveFrame
    //     0x6ea184: mov             SP, fp
    //     0x6ea188: ldp             fp, lr, [SP], #0x10
    // 0x6ea18c: ret
    //     0x6ea18c: ret             
    // 0x6ea190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea190: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea194: b               #0x6ea130
  }
}

// class id: 4170, size: 0xa8, field offset: 0xc
//   const constructor, 
class SliverAppBar extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa4013c, size: 0x20
    // 0xa4013c: EnterFrame
    //     0xa4013c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40140: mov             fp, SP
    // 0xa40144: r1 = <SliverAppBar>
    //     0xa40144: add             x1, PP, #0x40, lsl #12  ; [pp+0x40320] TypeArguments: <SliverAppBar>
    //     0xa40148: ldr             x1, [x1, #0x320]
    // 0xa4014c: r0 = _SliverAppBarState()
    //     0xa4014c: bl              #0xa4015c  ; Allocate_SliverAppBarStateStub -> _SliverAppBarState (size=0x28)
    // 0xa40150: LeaveFrame
    //     0xa40150: mov             SP, fp
    //     0xa40154: ldp             fp, lr, [SP], #0x10
    // 0xa40158: ret
    //     0xa40158: ret             
  }
}

// class id: 4171, size: 0x90, field offset: 0xc
class AppBar extends StatefulWidget
    implements PreferredSizeWidget {

  _ _getEffectiveCenterTitle(/* No info */) {
    // ** addr: 0x847d88, size: 0x78
    // 0x847d88: ldr             x1, [SP, #8]
    // 0x847d8c: LoadField: r2 = r1->field_57
    //     0x847d8c: ldur            w2, [x1, #0x57]
    // 0x847d90: DecompressPointer r2
    //     0x847d90: add             x2, x2, HEAP, lsl #32
    // 0x847d94: cmp             w2, NULL
    // 0x847d98: b.ne            #0x847da4
    // 0x847d9c: r1 = Null
    //     0x847d9c: mov             x1, NULL
    // 0x847da0: b               #0x847da8
    // 0x847da4: mov             x1, x2
    // 0x847da8: cmp             w1, NULL
    // 0x847dac: b.ne            #0x847df8
    // 0x847db0: ldr             x2, [SP]
    // 0x847db4: LoadField: r3 = r2->field_1f
    //     0x847db4: ldur            w3, [x2, #0x1f]
    // 0x847db8: DecompressPointer r3
    //     0x847db8: add             x3, x3, HEAP, lsl #32
    // 0x847dbc: LoadField: r2 = r3->field_7
    //     0x847dbc: ldur            x2, [x3, #7]
    // 0x847dc0: cmp             x2, #2
    // 0x847dc4: b.gt            #0x847dd4
    // 0x847dc8: cmp             x2, #1
    // 0x847dcc: b.gt            #0x847de4
    // 0x847dd0: b               #0x847dec
    // 0x847dd4: cmp             x2, #4
    // 0x847dd8: b.gt            #0x847dec
    // 0x847ddc: cmp             x2, #3
    // 0x847de0: b.le            #0x847dec
    // 0x847de4: r2 = true
    //     0x847de4: add             x2, NULL, #0x20  ; true
    // 0x847de8: b               #0x847df0
    // 0x847dec: r2 = false
    //     0x847dec: add             x2, NULL, #0x30  ; false
    // 0x847df0: mov             x0, x2
    // 0x847df4: b               #0x847dfc
    // 0x847df8: mov             x0, x1
    // 0x847dfc: ret
    //     0x847dfc: ret             
  }
  static _ preferredHeightFor(/* No info */) {
    // ** addr: 0x8658c0, size: 0xa0
    // 0x8658c0: EnterFrame
    //     0x8658c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8658c4: mov             fp, SP
    // 0x8658c8: CheckStackOverflow
    //     0x8658c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8658cc: cmp             SP, x16
    //     0x8658d0: b.ls            #0x865958
    // 0x8658d4: ldr             x0, [fp, #0x10]
    // 0x8658d8: r1 = LoadClassIdInstr(r0)
    //     0x8658d8: ldur            x1, [x0, #-1]
    //     0x8658dc: ubfx            x1, x1, #0xc, #0x14
    // 0x8658e0: lsl             x1, x1, #1
    // 0x8658e4: r17 = 10148
    //     0x8658e4: mov             x17, #0x27a4
    // 0x8658e8: cmp             w1, w17
    // 0x8658ec: b.ne            #0x865948
    // 0x8658f0: LoadField: r1 = r0->field_17
    //     0x8658f0: ldur            w1, [x0, #0x17]
    // 0x8658f4: DecompressPointer r1
    //     0x8658f4: add             x1, x1, HEAP, lsl #32
    // 0x8658f8: cmp             w1, NULL
    // 0x8658fc: b.ne            #0x865948
    // 0x865900: ldr             x16, [fp, #0x18]
    // 0x865904: SaveReg r16
    //     0x865904: str             x16, [SP, #-8]!
    // 0x865908: r0 = of()
    //     0x865908: bl              #0x848a3c  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::of
    // 0x86590c: add             SP, SP, #8
    // 0x865910: LoadField: r1 = r0->field_3b
    //     0x865910: ldur            w1, [x0, #0x3b]
    // 0x865914: DecompressPointer r1
    //     0x865914: add             x1, x1, HEAP, lsl #32
    // 0x865918: cmp             w1, NULL
    // 0x86591c: b.ne            #0x86592c
    // 0x865920: d2 = 56.000000
    //     0x865920: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x865924: ldr             d2, [x17, #0xe88]
    // 0x865928: b               #0x865934
    // 0x86592c: LoadField: d1 = r1->field_7
    //     0x86592c: ldur            d1, [x1, #7]
    // 0x865930: mov             v2.16b, v1.16b
    // 0x865934: d1 = 0.000000
    //     0x865934: eor             v1.16b, v1.16b, v1.16b
    // 0x865938: fadd            d0, d2, d1
    // 0x86593c: LeaveFrame
    //     0x86593c: mov             SP, fp
    //     0x865940: ldp             fp, lr, [SP], #0x10
    // 0x865944: ret
    //     0x865944: ret             
    // 0x865948: LoadField: d0 = r0->field_f
    //     0x865948: ldur            d0, [x0, #0xf]
    // 0x86594c: LeaveFrame
    //     0x86594c: mov             SP, fp
    //     0x865950: ldp             fp, lr, [SP], #0x10
    // 0x865954: ret
    //     0x865954: ret             
    // 0x865958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x865958: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86595c: b               #0x8658d4
  }
  _ AppBar(/* No info */) {
    // ** addr: 0x8b743c, size: 0x4f4
    // 0x8b743c: EnterFrame
    //     0x8b743c: stp             fp, lr, [SP, #-0x10]!
    //     0x8b7440: mov             fp, SP
    // 0x8b7444: AllocStack(0x10)
    //     0x8b7444: sub             SP, SP, #0x10
    // 0x8b7448: SetupParameters(AppBar this /* r3, fp-0x10 */, {dynamic automaticallyImplyLeading = true /* r4 */, dynamic backgroundColor = Null /* r5 */, _Double bottomOpacity = 1.000000 /* d0 */, dynamic centerTitle = Null /* r6 */, dynamic elevation = Null /* r7 */, dynamic flexibleSpace = Null /* r8 */, dynamic leadingWidth = Null /* r9 */, dynamic title = Null /* r10 */, dynamic toolbarHeight = Null /* r11, fp-0x8 */, _Double toolbarOpacity = 1.000000 /* d1 */})
    //     0x8b7448: mov             x0, x4
    //     0x8b744c: ldur            w1, [x0, #0x13]
    //     0x8b7450: add             x1, x1, HEAP, lsl #32
    //     0x8b7454: sub             x2, x1, #2
    //     0x8b7458: add             x3, fp, w2, sxtw #2
    //     0x8b745c: ldr             x3, [x3, #0x10]
    //     0x8b7460: stur            x3, [fp, #-0x10]
    //     0x8b7464: ldur            w2, [x0, #0x1f]
    //     0x8b7468: add             x2, x2, HEAP, lsl #32
    //     0x8b746c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27328] "automaticallyImplyLeading"
    //     0x8b7470: ldr             x16, [x16, #0x328]
    //     0x8b7474: cmp             w2, w16
    //     0x8b7478: b.ne            #0x8b749c
    //     0x8b747c: ldur            w2, [x0, #0x23]
    //     0x8b7480: add             x2, x2, HEAP, lsl #32
    //     0x8b7484: sub             w4, w1, w2
    //     0x8b7488: add             x2, fp, w4, sxtw #2
    //     0x8b748c: ldr             x2, [x2, #8]
    //     0x8b7490: mov             x4, x2
    //     0x8b7494: mov             x2, #1
    //     0x8b7498: b               #0x8b74a4
    //     0x8b749c: add             x4, NULL, #0x20  ; true
    //     0x8b74a0: mov             x2, #0
    //     0x8b74a4: lsl             x5, x2, #1
    //     0x8b74a8: lsl             w6, w5, #1
    //     0x8b74ac: add             w7, w6, #8
    //     0x8b74b0: add             x16, x0, w7, sxtw #1
    //     0x8b74b4: ldur            w8, [x16, #0xf]
    //     0x8b74b8: add             x8, x8, HEAP, lsl #32
    //     0x8b74bc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc48] "backgroundColor"
    //     0x8b74c0: ldr             x16, [x16, #0xc48]
    //     0x8b74c4: cmp             w8, w16
    //     0x8b74c8: b.ne            #0x8b74fc
    //     0x8b74cc: add             w2, w6, #0xa
    //     0x8b74d0: add             x16, x0, w2, sxtw #1
    //     0x8b74d4: ldur            w6, [x16, #0xf]
    //     0x8b74d8: add             x6, x6, HEAP, lsl #32
    //     0x8b74dc: sub             w2, w1, w6
    //     0x8b74e0: add             x6, fp, w2, sxtw #2
    //     0x8b74e4: ldr             x6, [x6, #8]
    //     0x8b74e8: add             w2, w5, #2
    //     0x8b74ec: sbfx            x5, x2, #1, #0x1f
    //     0x8b74f0: mov             x2, x5
    //     0x8b74f4: mov             x5, x6
    //     0x8b74f8: b               #0x8b7500
    //     0x8b74fc: mov             x5, NULL
    //     0x8b7500: lsl             x6, x2, #1
    //     0x8b7504: lsl             w7, w6, #1
    //     0x8b7508: add             w8, w7, #8
    //     0x8b750c: add             x16, x0, w8, sxtw #1
    //     0x8b7510: ldur            w9, [x16, #0xf]
    //     0x8b7514: add             x9, x9, HEAP, lsl #32
    //     0x8b7518: add             x16, PP, #0x27, lsl #12  ; [pp+0x27330] "bottomOpacity"
    //     0x8b751c: ldr             x16, [x16, #0x330]
    //     0x8b7520: cmp             w9, w16
    //     0x8b7524: b.ne            #0x8b7558
    //     0x8b7528: add             w2, w7, #0xa
    //     0x8b752c: add             x16, x0, w2, sxtw #1
    //     0x8b7530: ldur            w7, [x16, #0xf]
    //     0x8b7534: add             x7, x7, HEAP, lsl #32
    //     0x8b7538: sub             w2, w1, w7
    //     0x8b753c: add             x7, fp, w2, sxtw #2
    //     0x8b7540: ldr             x7, [x7, #8]
    //     0x8b7544: add             w2, w6, #2
    //     0x8b7548: ldur            d0, [x7, #7]
    //     0x8b754c: sbfx            x6, x2, #1, #0x1f
    //     0x8b7550: mov             x2, x6
    //     0x8b7554: b               #0x8b755c
    //     0x8b7558: fmov            d0, #1.00000000
    //     0x8b755c: lsl             x6, x2, #1
    //     0x8b7560: lsl             w7, w6, #1
    //     0x8b7564: add             w8, w7, #8
    //     0x8b7568: add             x16, x0, w8, sxtw #1
    //     0x8b756c: ldur            w9, [x16, #0xf]
    //     0x8b7570: add             x9, x9, HEAP, lsl #32
    //     0x8b7574: add             x16, PP, #0x27, lsl #12  ; [pp+0x27338] "centerTitle"
    //     0x8b7578: ldr             x16, [x16, #0x338]
    //     0x8b757c: cmp             w9, w16
    //     0x8b7580: b.ne            #0x8b75b4
    //     0x8b7584: add             w2, w7, #0xa
    //     0x8b7588: add             x16, x0, w2, sxtw #1
    //     0x8b758c: ldur            w7, [x16, #0xf]
    //     0x8b7590: add             x7, x7, HEAP, lsl #32
    //     0x8b7594: sub             w2, w1, w7
    //     0x8b7598: add             x7, fp, w2, sxtw #2
    //     0x8b759c: ldr             x7, [x7, #8]
    //     0x8b75a0: add             w2, w6, #2
    //     0x8b75a4: sbfx            x6, x2, #1, #0x1f
    //     0x8b75a8: mov             x2, x6
    //     0x8b75ac: mov             x6, x7
    //     0x8b75b0: b               #0x8b75b8
    //     0x8b75b4: mov             x6, NULL
    //     0x8b75b8: lsl             x7, x2, #1
    //     0x8b75bc: lsl             w8, w7, #1
    //     0x8b75c0: add             w9, w8, #8
    //     0x8b75c4: add             x16, x0, w9, sxtw #1
    //     0x8b75c8: ldur            w10, [x16, #0xf]
    //     0x8b75cc: add             x10, x10, HEAP, lsl #32
    //     0x8b75d0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26870] "elevation"
    //     0x8b75d4: ldr             x16, [x16, #0x870]
    //     0x8b75d8: cmp             w10, w16
    //     0x8b75dc: b.ne            #0x8b7610
    //     0x8b75e0: add             w2, w8, #0xa
    //     0x8b75e4: add             x16, x0, w2, sxtw #1
    //     0x8b75e8: ldur            w8, [x16, #0xf]
    //     0x8b75ec: add             x8, x8, HEAP, lsl #32
    //     0x8b75f0: sub             w2, w1, w8
    //     0x8b75f4: add             x8, fp, w2, sxtw #2
    //     0x8b75f8: ldr             x8, [x8, #8]
    //     0x8b75fc: add             w2, w7, #2
    //     0x8b7600: sbfx            x7, x2, #1, #0x1f
    //     0x8b7604: mov             x2, x7
    //     0x8b7608: mov             x7, x8
    //     0x8b760c: b               #0x8b7614
    //     0x8b7610: mov             x7, NULL
    //     0x8b7614: lsl             x8, x2, #1
    //     0x8b7618: lsl             w9, w8, #1
    //     0x8b761c: add             w10, w9, #8
    //     0x8b7620: add             x16, x0, w10, sxtw #1
    //     0x8b7624: ldur            w11, [x16, #0xf]
    //     0x8b7628: add             x11, x11, HEAP, lsl #32
    //     0x8b762c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27340] "flexibleSpace"
    //     0x8b7630: ldr             x16, [x16, #0x340]
    //     0x8b7634: cmp             w11, w16
    //     0x8b7638: b.ne            #0x8b766c
    //     0x8b763c: add             w2, w9, #0xa
    //     0x8b7640: add             x16, x0, w2, sxtw #1
    //     0x8b7644: ldur            w9, [x16, #0xf]
    //     0x8b7648: add             x9, x9, HEAP, lsl #32
    //     0x8b764c: sub             w2, w1, w9
    //     0x8b7650: add             x9, fp, w2, sxtw #2
    //     0x8b7654: ldr             x9, [x9, #8]
    //     0x8b7658: add             w2, w8, #2
    //     0x8b765c: sbfx            x8, x2, #1, #0x1f
    //     0x8b7660: mov             x2, x8
    //     0x8b7664: mov             x8, x9
    //     0x8b7668: b               #0x8b7670
    //     0x8b766c: mov             x8, NULL
    //     0x8b7670: lsl             x9, x2, #1
    //     0x8b7674: lsl             w10, w9, #1
    //     0x8b7678: add             w11, w10, #8
    //     0x8b767c: add             x16, x0, w11, sxtw #1
    //     0x8b7680: ldur            w12, [x16, #0xf]
    //     0x8b7684: add             x12, x12, HEAP, lsl #32
    //     0x8b7688: add             x16, PP, #0x27, lsl #12  ; [pp+0x27348] "leadingWidth"
    //     0x8b768c: ldr             x16, [x16, #0x348]
    //     0x8b7690: cmp             w12, w16
    //     0x8b7694: b.ne            #0x8b76c8
    //     0x8b7698: add             w2, w10, #0xa
    //     0x8b769c: add             x16, x0, w2, sxtw #1
    //     0x8b76a0: ldur            w10, [x16, #0xf]
    //     0x8b76a4: add             x10, x10, HEAP, lsl #32
    //     0x8b76a8: sub             w2, w1, w10
    //     0x8b76ac: add             x10, fp, w2, sxtw #2
    //     0x8b76b0: ldr             x10, [x10, #8]
    //     0x8b76b4: add             w2, w9, #2
    //     0x8b76b8: sbfx            x9, x2, #1, #0x1f
    //     0x8b76bc: mov             x2, x9
    //     0x8b76c0: mov             x9, x10
    //     0x8b76c4: b               #0x8b76cc
    //     0x8b76c8: mov             x9, NULL
    //     0x8b76cc: lsl             x10, x2, #1
    //     0x8b76d0: lsl             w11, w10, #1
    //     0x8b76d4: add             w12, w11, #8
    //     0x8b76d8: add             x16, x0, w12, sxtw #1
    //     0x8b76dc: ldur            w13, [x16, #0xf]
    //     0x8b76e0: add             x13, x13, HEAP, lsl #32
    //     0x8b76e4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b98] "title"
    //     0x8b76e8: ldr             x16, [x16, #0xb98]
    //     0x8b76ec: cmp             w13, w16
    //     0x8b76f0: b.ne            #0x8b7724
    //     0x8b76f4: add             w2, w11, #0xa
    //     0x8b76f8: add             x16, x0, w2, sxtw #1
    //     0x8b76fc: ldur            w11, [x16, #0xf]
    //     0x8b7700: add             x11, x11, HEAP, lsl #32
    //     0x8b7704: sub             w2, w1, w11
    //     0x8b7708: add             x11, fp, w2, sxtw #2
    //     0x8b770c: ldr             x11, [x11, #8]
    //     0x8b7710: add             w2, w10, #2
    //     0x8b7714: sbfx            x10, x2, #1, #0x1f
    //     0x8b7718: mov             x2, x10
    //     0x8b771c: mov             x10, x11
    //     0x8b7720: b               #0x8b7728
    //     0x8b7724: mov             x10, NULL
    //     0x8b7728: lsl             x11, x2, #1
    //     0x8b772c: lsl             w12, w11, #1
    //     0x8b7730: add             w13, w12, #8
    //     0x8b7734: add             x16, x0, w13, sxtw #1
    //     0x8b7738: ldur            w14, [x16, #0xf]
    //     0x8b773c: add             x14, x14, HEAP, lsl #32
    //     0x8b7740: add             x16, PP, #0x27, lsl #12  ; [pp+0x27350] "toolbarHeight"
    //     0x8b7744: ldr             x16, [x16, #0x350]
    //     0x8b7748: cmp             w14, w16
    //     0x8b774c: b.ne            #0x8b7780
    //     0x8b7750: add             w2, w12, #0xa
    //     0x8b7754: add             x16, x0, w2, sxtw #1
    //     0x8b7758: ldur            w12, [x16, #0xf]
    //     0x8b775c: add             x12, x12, HEAP, lsl #32
    //     0x8b7760: sub             w2, w1, w12
    //     0x8b7764: add             x12, fp, w2, sxtw #2
    //     0x8b7768: ldr             x12, [x12, #8]
    //     0x8b776c: add             w2, w11, #2
    //     0x8b7770: sbfx            x11, x2, #1, #0x1f
    //     0x8b7774: mov             x2, x11
    //     0x8b7778: mov             x11, x12
    //     0x8b777c: b               #0x8b7784
    //     0x8b7780: mov             x11, NULL
    //     0x8b7784: stur            x11, [fp, #-8]
    //     0x8b7788: lsl             x12, x2, #1
    //     0x8b778c: lsl             w2, w12, #1
    //     0x8b7790: add             w12, w2, #8
    //     0x8b7794: add             x16, x0, w12, sxtw #1
    //     0x8b7798: ldur            w13, [x16, #0xf]
    //     0x8b779c: add             x13, x13, HEAP, lsl #32
    //     0x8b77a0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e80] "toolbarOpacity"
    //     0x8b77a4: ldr             x16, [x16, #0xe80]
    //     0x8b77a8: cmp             w13, w16
    //     0x8b77ac: b.ne            #0x8b77d4
    //     0x8b77b0: add             w12, w2, #0xa
    //     0x8b77b4: add             x16, x0, w12, sxtw #1
    //     0x8b77b8: ldur            w2, [x16, #0xf]
    //     0x8b77bc: add             x2, x2, HEAP, lsl #32
    //     0x8b77c0: sub             w0, w1, w2
    //     0x8b77c4: add             x1, fp, w0, sxtw #2
    //     0x8b77c8: ldr             x1, [x1, #8]
    //     0x8b77cc: ldur            d1, [x1, #7]
    //     0x8b77d0: b               #0x8b77d8
    //     0x8b77d4: fmov            d1, #1.00000000
    // 0x8b77d8: r12 = true
    //     0x8b77d8: add             x12, NULL, #0x20  ; true
    // 0x8b77dc: r2 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0x8b77dc: add             x2, PP, #0x27, lsl #12  ; [pp+0x27358] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7fe6e20b793c)
    //     0x8b77e0: ldr             x2, [x2, #0x358]
    // 0x8b77e4: r1 = false
    //     0x8b77e4: add             x1, NULL, #0x30  ; false
    // 0x8b77e8: StoreField: r3->field_f = r4
    //     0x8b77e8: stur            w4, [x3, #0xf]
    // 0x8b77ec: mov             x0, x10
    // 0x8b77f0: StoreField: r3->field_13 = r0
    //     0x8b77f0: stur            w0, [x3, #0x13]
    //     0x8b77f4: ldurb           w16, [x3, #-1]
    //     0x8b77f8: ldurb           w17, [x0, #-1]
    //     0x8b77fc: and             x16, x17, x16, lsr #2
    //     0x8b7800: tst             x16, HEAP, lsr #32
    //     0x8b7804: b.eq            #0x8b780c
    //     0x8b7808: bl              #0xd682ac
    // 0x8b780c: mov             x0, x8
    // 0x8b7810: StoreField: r3->field_1b = r0
    //     0x8b7810: stur            w0, [x3, #0x1b]
    //     0x8b7814: ldurb           w16, [x3, #-1]
    //     0x8b7818: ldurb           w17, [x0, #-1]
    //     0x8b781c: and             x16, x17, x16, lsr #2
    //     0x8b7820: tst             x16, HEAP, lsr #32
    //     0x8b7824: b.eq            #0x8b782c
    //     0x8b7828: bl              #0xd682ac
    // 0x8b782c: mov             x0, x7
    // 0x8b7830: StoreField: r3->field_23 = r0
    //     0x8b7830: stur            w0, [x3, #0x23]
    //     0x8b7834: ldurb           w16, [x3, #-1]
    //     0x8b7838: ldurb           w17, [x0, #-1]
    //     0x8b783c: and             x16, x17, x16, lsr #2
    //     0x8b7840: tst             x16, HEAP, lsr #32
    //     0x8b7844: b.eq            #0x8b784c
    //     0x8b7848: bl              #0xd682ac
    // 0x8b784c: StoreField: r3->field_2b = r2
    //     0x8b784c: stur            w2, [x3, #0x2b]
    // 0x8b7850: mov             x0, x5
    // 0x8b7854: StoreField: r3->field_3b = r0
    //     0x8b7854: stur            w0, [x3, #0x3b]
    //     0x8b7858: ldurb           w16, [x3, #-1]
    //     0x8b785c: ldurb           w17, [x0, #-1]
    //     0x8b7860: and             x16, x17, x16, lsr #2
    //     0x8b7864: tst             x16, HEAP, lsr #32
    //     0x8b7868: b.eq            #0x8b7870
    //     0x8b786c: bl              #0xd682ac
    // 0x8b7870: StoreField: r3->field_53 = r12
    //     0x8b7870: stur            w12, [x3, #0x53]
    // 0x8b7874: StoreField: r3->field_57 = r6
    //     0x8b7874: stur            w6, [x3, #0x57]
    // 0x8b7878: StoreField: r3->field_5b = r1
    //     0x8b7878: stur            w1, [x3, #0x5b]
    // 0x8b787c: StoreField: r3->field_63 = d1
    //     0x8b787c: stur            d1, [x3, #0x63]
    // 0x8b7880: StoreField: r3->field_6b = d0
    //     0x8b7880: stur            d0, [x3, #0x6b]
    // 0x8b7884: mov             x0, x11
    // 0x8b7888: StoreField: r3->field_77 = r0
    //     0x8b7888: stur            w0, [x3, #0x77]
    //     0x8b788c: ldurb           w16, [x3, #-1]
    //     0x8b7890: ldurb           w17, [x0, #-1]
    //     0x8b7894: and             x16, x17, x16, lsr #2
    //     0x8b7898: tst             x16, HEAP, lsr #32
    //     0x8b789c: b.eq            #0x8b78a4
    //     0x8b78a0: bl              #0xd682ac
    // 0x8b78a4: mov             x0, x9
    // 0x8b78a8: StoreField: r3->field_7b = r0
    //     0x8b78a8: stur            w0, [x3, #0x7b]
    //     0x8b78ac: ldurb           w16, [x3, #-1]
    //     0x8b78b0: ldurb           w17, [x0, #-1]
    //     0x8b78b4: and             x16, x17, x16, lsr #2
    //     0x8b78b8: tst             x16, HEAP, lsr #32
    //     0x8b78bc: b.eq            #0x8b78c4
    //     0x8b78c0: bl              #0xd682ac
    // 0x8b78c4: r0 = _PreferredAppBarSize()
    //     0x8b78c4: bl              #0x8b7930  ; Allocate_PreferredAppBarSizeStub -> _PreferredAppBarSize (size=0x20)
    // 0x8b78c8: ldur            x1, [fp, #-8]
    // 0x8b78cc: StoreField: r0->field_17 = r1
    //     0x8b78cc: stur            w1, [x0, #0x17]
    // 0x8b78d0: cmp             w1, NULL
    // 0x8b78d4: b.ne            #0x8b78e4
    // 0x8b78d8: d2 = 56.000000
    //     0x8b78d8: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x8b78dc: ldr             d2, [x17, #0xe88]
    // 0x8b78e0: b               #0x8b78ec
    // 0x8b78e4: LoadField: d0 = r1->field_7
    //     0x8b78e4: ldur            d0, [x1, #7]
    // 0x8b78e8: mov             v2.16b, v0.16b
    // 0x8b78ec: ldur            x1, [fp, #-0x10]
    // 0x8b78f0: d1 = 0.000000
    //     0x8b78f0: eor             v1.16b, v1.16b, v1.16b
    // 0x8b78f4: d0 = inf
    //     0x8b78f4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x8b78f8: fadd            d3, d2, d1
    // 0x8b78fc: StoreField: r0->field_7 = d0
    //     0x8b78fc: stur            d0, [x0, #7]
    // 0x8b7900: StoreField: r0->field_f = d3
    //     0x8b7900: stur            d3, [x0, #0xf]
    // 0x8b7904: StoreField: r1->field_73 = r0
    //     0x8b7904: stur            w0, [x1, #0x73]
    //     0x8b7908: ldurb           w16, [x1, #-1]
    //     0x8b790c: ldurb           w17, [x0, #-1]
    //     0x8b7910: and             x16, x17, x16, lsr #2
    //     0x8b7914: tst             x16, HEAP, lsr #32
    //     0x8b7918: b.eq            #0x8b7920
    //     0x8b791c: bl              #0xd6826c
    // 0x8b7920: r0 = Null
    //     0x8b7920: mov             x0, NULL
    // 0x8b7924: LeaveFrame
    //     0x8b7924: mov             SP, fp
    //     0x8b7928: ldp             fp, lr, [SP], #0x10
    // 0x8b792c: ret
    //     0x8b792c: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xa40108, size: 0x28
    // 0xa40108: EnterFrame
    //     0xa40108: stp             fp, lr, [SP, #-0x10]!
    //     0xa4010c: mov             fp, SP
    // 0xa40110: r1 = <AppBar>
    //     0xa40110: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e780] TypeArguments: <AppBar>
    //     0xa40114: ldr             x1, [x1, #0x780]
    // 0xa40118: r0 = _AppBarState()
    //     0xa40118: bl              #0xa40130  ; Allocate_AppBarStateStub -> _AppBarState (size=0x1c)
    // 0xa4011c: r1 = false
    //     0xa4011c: add             x1, NULL, #0x30  ; false
    // 0xa40120: StoreField: r0->field_17 = r1
    //     0xa40120: stur            w1, [x0, #0x17]
    // 0xa40124: LeaveFrame
    //     0xa40124: mov             SP, fp
    //     0xa40128: ldp             fp, lr, [SP], #0x10
    // 0xa4012c: ret
    //     0xa4012c: ret             
  }
  const get _ preferredSize(/* No info */) {
    // ** addr: 0xcb9880, size: 0x10
    // 0xcb9880: ldr             x1, [SP]
    // 0xcb9884: LoadField: r0 = r1->field_73
    //     0xcb9884: ldur            w0, [x1, #0x73]
    // 0xcb9888: DecompressPointer r0
    //     0xcb9888: add             x0, x0, HEAP, lsl #32
    // 0xcb988c: ret
    //     0xcb988c: ret             
  }
}

// class id: 5074, size: 0x20, field offset: 0x18
class _PreferredAppBarSize extends Size {
}

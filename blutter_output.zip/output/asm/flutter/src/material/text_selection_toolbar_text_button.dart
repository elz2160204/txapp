// lib: , url: package:flutter/src/material/text_selection_toolbar_text_button.dart

// class id: 1049328, size: 0x8
class :: {
}

// class id: 3838, size: 0x18, field offset: 0xc
//   const constructor, 
class TextSelectionToolbarTextButton extends StatelessWidget {

  static _ getPadding(/* No info */) {
    // ** addr: 0x873a44, size: 0xf8
    // 0x873a44: EnterFrame
    //     0x873a44: stp             fp, lr, [SP, #-0x10]!
    //     0x873a48: mov             fp, SP
    // 0x873a4c: AllocStack(0x10)
    //     0x873a4c: sub             SP, SP, #0x10
    // 0x873a50: ldr             x0, [fp, #0x18]
    // 0x873a54: r1 = LoadInt32Instr(r0)
    //     0x873a54: sbfx            x1, x0, #1, #0x1f
    //     0x873a58: tbz             w0, #0, #0x873a60
    //     0x873a5c: ldur            x1, [x0, #7]
    // 0x873a60: cbnz            x1, #0x873a8c
    // 0x873a64: ldr             x0, [fp, #0x10]
    // 0x873a68: lsl             x1, x0, #1
    // 0x873a6c: cmp             w1, #2
    // 0x873a70: b.ne            #0x873a80
    // 0x873a74: r0 = Instance__TextSelectionToolbarItemPosition
    //     0x873a74: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d68] Obj!_TextSelectionToolbarItemPosition@b65151
    //     0x873a78: ldr             x0, [x0, #0xd68]
    // 0x873a7c: b               #0x873ab0
    // 0x873a80: r0 = Instance__TextSelectionToolbarItemPosition
    //     0x873a80: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d70] Obj!_TextSelectionToolbarItemPosition@b65131
    //     0x873a84: ldr             x0, [x0, #0xd70]
    // 0x873a88: b               #0x873ab0
    // 0x873a8c: ldr             x0, [fp, #0x10]
    // 0x873a90: sub             x2, x0, #1
    // 0x873a94: cmp             x1, x2
    // 0x873a98: b.ne            #0x873aa8
    // 0x873a9c: r0 = Instance__TextSelectionToolbarItemPosition
    //     0x873a9c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d78] Obj!_TextSelectionToolbarItemPosition@b65111
    //     0x873aa0: ldr             x0, [x0, #0xd78]
    // 0x873aa4: b               #0x873ab0
    // 0x873aa8: r0 = Instance__TextSelectionToolbarItemPosition
    //     0x873aa8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d80] Obj!_TextSelectionToolbarItemPosition@b650f1
    //     0x873aac: ldr             x0, [x0, #0xd80]
    // 0x873ab0: r16 = Instance__TextSelectionToolbarItemPosition
    //     0x873ab0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d70] Obj!_TextSelectionToolbarItemPosition@b65131
    //     0x873ab4: ldr             x16, [x16, #0xd70]
    // 0x873ab8: cmp             w0, w16
    // 0x873abc: b.eq            #0x873ad0
    // 0x873ac0: r16 = Instance__TextSelectionToolbarItemPosition
    //     0x873ac0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d68] Obj!_TextSelectionToolbarItemPosition@b65151
    //     0x873ac4: ldr             x16, [x16, #0xd68]
    // 0x873ac8: cmp             w0, w16
    // 0x873acc: b.ne            #0x873ad8
    // 0x873ad0: d0 = 14.500000
    //     0x873ad0: fmov            d0, #14.50000000
    // 0x873ad4: b               #0x873adc
    // 0x873ad8: d0 = 9.500000
    //     0x873ad8: fmov            d0, #9.50000000
    // 0x873adc: stur            d0, [fp, #-0x10]
    // 0x873ae0: r16 = Instance__TextSelectionToolbarItemPosition
    //     0x873ae0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d78] Obj!_TextSelectionToolbarItemPosition@b65111
    //     0x873ae4: ldr             x16, [x16, #0xd78]
    // 0x873ae8: cmp             w0, w16
    // 0x873aec: b.eq            #0x873b00
    // 0x873af0: r16 = Instance__TextSelectionToolbarItemPosition
    //     0x873af0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d68] Obj!_TextSelectionToolbarItemPosition@b65151
    //     0x873af4: ldr             x16, [x16, #0xd68]
    // 0x873af8: cmp             w0, w16
    // 0x873afc: b.ne            #0x873b08
    // 0x873b00: d1 = 14.500000
    //     0x873b00: fmov            d1, #14.50000000
    // 0x873b04: b               #0x873b0c
    // 0x873b08: d1 = 9.500000
    //     0x873b08: fmov            d1, #9.50000000
    // 0x873b0c: stur            d1, [fp, #-8]
    // 0x873b10: r0 = EdgeInsets()
    //     0x873b10: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x873b14: ldur            d0, [fp, #-0x10]
    // 0x873b18: StoreField: r0->field_7 = d0
    //     0x873b18: stur            d0, [x0, #7]
    // 0x873b1c: d0 = 0.000000
    //     0x873b1c: eor             v0.16b, v0.16b, v0.16b
    // 0x873b20: StoreField: r0->field_f = d0
    //     0x873b20: stur            d0, [x0, #0xf]
    // 0x873b24: ldur            d1, [fp, #-8]
    // 0x873b28: StoreField: r0->field_17 = d1
    //     0x873b28: stur            d1, [x0, #0x17]
    // 0x873b2c: StoreField: r0->field_1f = d0
    //     0x873b2c: stur            d0, [x0, #0x1f]
    // 0x873b30: LeaveFrame
    //     0x873b30: mov             SP, fp
    //     0x873b34: ldp             fp, lr, [SP], #0x10
    // 0x873b38: ret
    //     0x873b38: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xb2471c, size: 0xf0
    // 0xb2471c: EnterFrame
    //     0xb2471c: stp             fp, lr, [SP, #-0x10]!
    //     0xb24720: mov             fp, SP
    // 0xb24724: AllocStack(0x18)
    //     0xb24724: sub             SP, SP, #0x18
    // 0xb24728: CheckStackOverflow
    //     0xb24728: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2472c: cmp             SP, x16
    //     0xb24730: b.ls            #0xb24804
    // 0xb24734: ldr             x16, [fp, #0x10]
    // 0xb24738: SaveReg r16
    //     0xb24738: str             x16, [SP, #-8]!
    // 0xb2473c: r0 = of()
    //     0xb2473c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb24740: add             SP, SP, #8
    // 0xb24744: LoadField: r1 = r0->field_3f
    //     0xb24744: ldur            w1, [x0, #0x3f]
    // 0xb24748: DecompressPointer r1
    //     0xb24748: add             x1, x1, HEAP, lsl #32
    // 0xb2474c: LoadField: r0 = r1->field_7
    //     0xb2474c: ldur            w0, [x1, #7]
    // 0xb24750: DecompressPointer r0
    //     0xb24750: add             x0, x0, HEAP, lsl #32
    // 0xb24754: r16 = Instance_Brightness
    //     0xb24754: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xb24758: cmp             w0, w16
    // 0xb2475c: b.ne            #0xb2476c
    // 0xb24760: r1 = Instance_Color
    //     0xb24760: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xb24764: ldr             x1, [x1, #0xbe8]
    // 0xb24768: b               #0xb24774
    // 0xb2476c: r1 = Instance_Color
    //     0xb2476c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28da0] Obj!Color@b5d1e1
    //     0xb24770: ldr             x1, [x1, #0xda0]
    // 0xb24774: ldr             x0, [fp, #0x18]
    // 0xb24778: LoadField: r2 = r0->field_13
    //     0xb24778: ldur            w2, [x0, #0x13]
    // 0xb2477c: DecompressPointer r2
    //     0xb2477c: add             x2, x2, HEAP, lsl #32
    // 0xb24780: r16 = Instance_Size
    //     0xb24780: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dc00] Obj!Size@b5ee31
    //     0xb24784: ldr             x16, [x16, #0xc00]
    // 0xb24788: stp             x16, x1, [SP, #-0x10]!
    // 0xb2478c: r16 = Instance_RoundedRectangleBorder
    //     0xb2478c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15300] Obj!RoundedRectangleBorder@b383d1
    //     0xb24790: ldr             x16, [x16, #0x300]
    // 0xb24794: stp             x16, x2, [SP, #-0x10]!
    // 0xb24798: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xb24798: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xb2479c: r0 = styleFrom()
    //     0xb2479c: bl              #0xb1e558  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xb247a0: add             SP, SP, #0x20
    // 0xb247a4: mov             x1, x0
    // 0xb247a8: ldr             x0, [fp, #0x18]
    // 0xb247ac: stur            x1, [fp, #-0x18]
    // 0xb247b0: LoadField: r2 = r0->field_f
    //     0xb247b0: ldur            w2, [x0, #0xf]
    // 0xb247b4: DecompressPointer r2
    //     0xb247b4: add             x2, x2, HEAP, lsl #32
    // 0xb247b8: stur            x2, [fp, #-0x10]
    // 0xb247bc: LoadField: r3 = r0->field_b
    //     0xb247bc: ldur            w3, [x0, #0xb]
    // 0xb247c0: DecompressPointer r3
    //     0xb247c0: add             x3, x3, HEAP, lsl #32
    // 0xb247c4: stur            x3, [fp, #-8]
    // 0xb247c8: r0 = TextButton()
    //     0xb247c8: bl              #0x916a68  ; AllocateTextButtonStub -> TextButton (size=0x34)
    // 0xb247cc: ldur            x1, [fp, #-0x10]
    // 0xb247d0: StoreField: r0->field_b = r1
    //     0xb247d0: stur            w1, [x0, #0xb]
    // 0xb247d4: ldur            x1, [fp, #-0x18]
    // 0xb247d8: StoreField: r0->field_1b = r1
    //     0xb247d8: stur            w1, [x0, #0x1b]
    // 0xb247dc: r1 = false
    //     0xb247dc: add             x1, NULL, #0x30  ; false
    // 0xb247e0: StoreField: r0->field_27 = r1
    //     0xb247e0: stur            w1, [x0, #0x27]
    // 0xb247e4: r1 = Instance_Clip
    //     0xb247e4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb247e8: ldr             x1, [x1, #0xb38]
    // 0xb247ec: StoreField: r0->field_1f = r1
    //     0xb247ec: stur            w1, [x0, #0x1f]
    // 0xb247f0: ldur            x1, [fp, #-8]
    // 0xb247f4: StoreField: r0->field_2f = r1
    //     0xb247f4: stur            w1, [x0, #0x2f]
    // 0xb247f8: LeaveFrame
    //     0xb247f8: mov             SP, fp
    //     0xb247fc: ldp             fp, lr, [SP], #0x10
    // 0xb24800: ret
    //     0xb24800: ret             
    // 0xb24804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24808: b               #0xb24734
  }
}

// class id: 5944, size: 0x14, field offset: 0x14
enum _TextSelectionToolbarItemPosition extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16640, size: 0x5c
    // 0xb16640: EnterFrame
    //     0xb16640: stp             fp, lr, [SP, #-0x10]!
    //     0xb16644: mov             fp, SP
    // 0xb16648: CheckStackOverflow
    //     0xb16648: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1664c: cmp             SP, x16
    //     0xb16650: b.ls            #0xb16694
    // 0xb16654: r1 = Null
    //     0xb16654: mov             x1, NULL
    // 0xb16658: r2 = 4
    //     0xb16658: mov             x2, #4
    // 0xb1665c: r0 = AllocateArray()
    //     0xb1665c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16660: r17 = "_TextSelectionToolbarItemPosition."
    //     0xb16660: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dc08] "_TextSelectionToolbarItemPosition."
    //     0xb16664: ldr             x17, [x17, #0xc08]
    // 0xb16668: StoreField: r0->field_f = r17
    //     0xb16668: stur            w17, [x0, #0xf]
    // 0xb1666c: ldr             x1, [fp, #0x10]
    // 0xb16670: LoadField: r2 = r1->field_f
    //     0xb16670: ldur            w2, [x1, #0xf]
    // 0xb16674: DecompressPointer r2
    //     0xb16674: add             x2, x2, HEAP, lsl #32
    // 0xb16678: StoreField: r0->field_13 = r2
    //     0xb16678: stur            w2, [x0, #0x13]
    // 0xb1667c: SaveReg r0
    //     0xb1667c: str             x0, [SP, #-8]!
    // 0xb16680: r0 = _interpolate()
    //     0xb16680: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16684: add             SP, SP, #8
    // 0xb16688: LeaveFrame
    //     0xb16688: mov             SP, fp
    //     0xb1668c: ldp             fp, lr, [SP], #0x10
    // 0xb16690: ret
    //     0xb16690: ret             
    // 0xb16694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16694: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16698: b               #0xb16654
  }
}

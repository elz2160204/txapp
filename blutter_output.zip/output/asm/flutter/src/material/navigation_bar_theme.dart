// lib: , url: package:flutter/src/material/navigation_bar_theme.dart

// class id: 1049279, size: 0x8
class :: {
}

// class id: 2782, size: 0x30, field offset: 0x8
//   const constructor, 
class NavigationBarThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00a84, size: 0x84
    // 0xb00a84: EnterFrame
    //     0xb00a84: stp             fp, lr, [SP, #-0x10]!
    //     0xb00a88: mov             fp, SP
    // 0xb00a8c: CheckStackOverflow
    //     0xb00a8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00a90: cmp             SP, x16
    //     0xb00a94: b.ls            #0xb00b00
    // 0xb00a98: ldr             x0, [fp, #0x10]
    // 0xb00a9c: LoadField: r1 = r0->field_7
    //     0xb00a9c: ldur            w1, [x0, #7]
    // 0xb00aa0: DecompressPointer r1
    //     0xb00aa0: add             x1, x1, HEAP, lsl #32
    // 0xb00aa4: LoadField: r2 = r0->field_f
    //     0xb00aa4: ldur            w2, [x0, #0xf]
    // 0xb00aa8: DecompressPointer r2
    //     0xb00aa8: add             x2, x2, HEAP, lsl #32
    // 0xb00aac: LoadField: r3 = r0->field_23
    //     0xb00aac: ldur            w3, [x0, #0x23]
    // 0xb00ab0: DecompressPointer r3
    //     0xb00ab0: add             x3, x3, HEAP, lsl #32
    // 0xb00ab4: LoadField: r4 = r0->field_27
    //     0xb00ab4: ldur            w4, [x0, #0x27]
    // 0xb00ab8: DecompressPointer r4
    //     0xb00ab8: add             x4, x4, HEAP, lsl #32
    // 0xb00abc: stp             NULL, x1, [SP, #-0x10]!
    // 0xb00ac0: stp             NULL, x2, [SP, #-0x10]!
    // 0xb00ac4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00ac8: stp             x3, NULL, [SP, #-0x10]!
    // 0xb00acc: stp             NULL, x4, [SP, #-0x10]!
    // 0xb00ad0: r4 = const [0, 0xa, 0xa, 0xa, null]
    //     0xb00ad0: ldr             x4, [PP, #0x2558]  ; [pp+0x2558] List(5) [0, 0xa, 0xa, 0xa, Null]
    // 0xb00ad4: r0 = hash()
    //     0xb00ad4: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00ad8: add             SP, SP, #0x50
    // 0xb00adc: mov             x2, x0
    // 0xb00ae0: r0 = BoxInt64Instr(r2)
    //     0xb00ae0: sbfiz           x0, x2, #1, #0x1f
    //     0xb00ae4: cmp             x2, x0, asr #1
    //     0xb00ae8: b.eq            #0xb00af4
    //     0xb00aec: bl              #0xd69bb8
    //     0xb00af0: stur            x2, [x0, #7]
    // 0xb00af4: LeaveFrame
    //     0xb00af4: mov             SP, fp
    //     0xb00af8: ldp             fp, lr, [SP], #0x10
    // 0xb00afc: ret
    //     0xb00afc: ret             
    // 0xb00b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00b00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00b04: b               #0xb00a98
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf3a3c, size: 0x1ec
    // 0xbf3a3c: EnterFrame
    //     0xbf3a3c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf3a40: mov             fp, SP
    // 0xbf3a44: AllocStack(0x20)
    //     0xbf3a44: sub             SP, SP, #0x20
    // 0xbf3a48: CheckStackOverflow
    //     0xbf3a48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf3a4c: cmp             SP, x16
    //     0xbf3a50: b.ls            #0xbf3bfc
    // 0xbf3a54: ldr             x0, [fp, #0x20]
    // 0xbf3a58: LoadField: r1 = r0->field_7
    //     0xbf3a58: ldur            w1, [x0, #7]
    // 0xbf3a5c: DecompressPointer r1
    //     0xbf3a5c: add             x1, x1, HEAP, lsl #32
    // 0xbf3a60: ldr             x2, [fp, #0x18]
    // 0xbf3a64: LoadField: r3 = r2->field_7
    //     0xbf3a64: ldur            w3, [x2, #7]
    // 0xbf3a68: DecompressPointer r3
    //     0xbf3a68: add             x3, x3, HEAP, lsl #32
    // 0xbf3a6c: ldr             d0, [fp, #0x10]
    // 0xbf3a70: r4 = inline_Allocate_Double()
    //     0xbf3a70: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf3a74: add             x4, x4, #0x10
    //     0xbf3a78: cmp             x5, x4
    //     0xbf3a7c: b.ls            #0xbf3c04
    //     0xbf3a80: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf3a84: sub             x4, x4, #0xf
    //     0xbf3a88: mov             x5, #0xd108
    //     0xbf3a8c: movk            x5, #3, lsl #16
    //     0xbf3a90: stur            x5, [x4, #-1]
    // 0xbf3a94: StoreField: r4->field_7 = d0
    //     0xbf3a94: stur            d0, [x4, #7]
    // 0xbf3a98: stur            x4, [fp, #-8]
    // 0xbf3a9c: stp             x3, x1, [SP, #-0x10]!
    // 0xbf3aa0: SaveReg r4
    //     0xbf3aa0: str             x4, [SP, #-8]!
    // 0xbf3aa4: r0 = lerpDouble()
    //     0xbf3aa4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3aa8: add             SP, SP, #0x18
    // 0xbf3aac: stur            x0, [fp, #-0x10]
    // 0xbf3ab0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3ab4: ldur            x16, [fp, #-8]
    // 0xbf3ab8: SaveReg r16
    //     0xbf3ab8: str             x16, [SP, #-8]!
    // 0xbf3abc: r0 = lerp()
    //     0xbf3abc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3ac0: add             SP, SP, #0x18
    // 0xbf3ac4: ldr             x0, [fp, #0x20]
    // 0xbf3ac8: LoadField: r1 = r0->field_f
    //     0xbf3ac8: ldur            w1, [x0, #0xf]
    // 0xbf3acc: DecompressPointer r1
    //     0xbf3acc: add             x1, x1, HEAP, lsl #32
    // 0xbf3ad0: ldr             x2, [fp, #0x18]
    // 0xbf3ad4: LoadField: r3 = r2->field_f
    //     0xbf3ad4: ldur            w3, [x2, #0xf]
    // 0xbf3ad8: DecompressPointer r3
    //     0xbf3ad8: add             x3, x3, HEAP, lsl #32
    // 0xbf3adc: stp             x3, x1, [SP, #-0x10]!
    // 0xbf3ae0: ldur            x16, [fp, #-8]
    // 0xbf3ae4: SaveReg r16
    //     0xbf3ae4: str             x16, [SP, #-8]!
    // 0xbf3ae8: r0 = lerpDouble()
    //     0xbf3ae8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3aec: add             SP, SP, #0x18
    // 0xbf3af0: stur            x0, [fp, #-0x18]
    // 0xbf3af4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3af8: ldur            x16, [fp, #-8]
    // 0xbf3afc: SaveReg r16
    //     0xbf3afc: str             x16, [SP, #-8]!
    // 0xbf3b00: r0 = lerp()
    //     0xbf3b00: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3b04: add             SP, SP, #0x18
    // 0xbf3b08: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3b0c: ldur            x16, [fp, #-8]
    // 0xbf3b10: SaveReg r16
    //     0xbf3b10: str             x16, [SP, #-8]!
    // 0xbf3b14: r0 = lerp()
    //     0xbf3b14: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3b18: add             SP, SP, #0x18
    // 0xbf3b1c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3b20: ldur            x16, [fp, #-8]
    // 0xbf3b24: SaveReg r16
    //     0xbf3b24: str             x16, [SP, #-8]!
    // 0xbf3b28: r0 = lerp()
    //     0xbf3b28: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3b2c: add             SP, SP, #0x18
    // 0xbf3b30: ldr             x0, [fp, #0x20]
    // 0xbf3b34: LoadField: r1 = r0->field_23
    //     0xbf3b34: ldur            w1, [x0, #0x23]
    // 0xbf3b38: DecompressPointer r1
    //     0xbf3b38: add             x1, x1, HEAP, lsl #32
    // 0xbf3b3c: ldr             x2, [fp, #0x18]
    // 0xbf3b40: LoadField: r3 = r2->field_23
    //     0xbf3b40: ldur            w3, [x2, #0x23]
    // 0xbf3b44: DecompressPointer r3
    //     0xbf3b44: add             x3, x3, HEAP, lsl #32
    // 0xbf3b48: r16 = <TextStyle?>
    //     0xbf3b48: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c0] TypeArguments: <TextStyle?>
    //     0xbf3b4c: ldr             x16, [x16, #0x8c0]
    // 0xbf3b50: stp             x1, x16, [SP, #-0x10]!
    // 0xbf3b54: SaveReg r3
    //     0xbf3b54: str             x3, [SP, #-8]!
    // 0xbf3b58: ldr             d0, [fp, #0x10]
    // 0xbf3b5c: SaveReg d0
    //     0xbf3b5c: str             d0, [SP, #-8]!
    // 0xbf3b60: r16 = Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static.
    //     0xbf3b60: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db78] Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static. (0x7fe6e22ec598)
    //     0xbf3b64: ldr             x16, [x16, #0xb78]
    // 0xbf3b68: SaveReg r16
    //     0xbf3b68: str             x16, [SP, #-8]!
    // 0xbf3b6c: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3b6c: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3b70: r0 = lerp()
    //     0xbf3b70: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3b74: add             SP, SP, #0x28
    // 0xbf3b78: mov             x1, x0
    // 0xbf3b7c: ldr             x0, [fp, #0x20]
    // 0xbf3b80: stur            x1, [fp, #-8]
    // 0xbf3b84: LoadField: r2 = r0->field_27
    //     0xbf3b84: ldur            w2, [x0, #0x27]
    // 0xbf3b88: DecompressPointer r2
    //     0xbf3b88: add             x2, x2, HEAP, lsl #32
    // 0xbf3b8c: ldr             x0, [fp, #0x18]
    // 0xbf3b90: LoadField: r3 = r0->field_27
    //     0xbf3b90: ldur            w3, [x0, #0x27]
    // 0xbf3b94: DecompressPointer r3
    //     0xbf3b94: add             x3, x3, HEAP, lsl #32
    // 0xbf3b98: r16 = <IconThemeData?>
    //     0xbf3b98: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbc8] TypeArguments: <IconThemeData?>
    //     0xbf3b9c: ldr             x16, [x16, #0xbc8]
    // 0xbf3ba0: stp             x2, x16, [SP, #-0x10]!
    // 0xbf3ba4: SaveReg r3
    //     0xbf3ba4: str             x3, [SP, #-8]!
    // 0xbf3ba8: ldr             d0, [fp, #0x10]
    // 0xbf3bac: SaveReg d0
    //     0xbf3bac: str             d0, [SP, #-8]!
    // 0xbf3bb0: r16 = Closure: (IconThemeData?, IconThemeData?, double) => IconThemeData from Function 'lerp': static.
    //     0xbf3bb0: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbd0] Closure: (IconThemeData?, IconThemeData?, double) => IconThemeData from Function 'lerp': static. (0x7fe6e23f39f8)
    //     0xbf3bb4: ldr             x16, [x16, #0xbd0]
    // 0xbf3bb8: SaveReg r16
    //     0xbf3bb8: str             x16, [SP, #-8]!
    // 0xbf3bbc: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3bbc: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3bc0: r0 = lerp()
    //     0xbf3bc0: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3bc4: add             SP, SP, #0x28
    // 0xbf3bc8: stur            x0, [fp, #-0x20]
    // 0xbf3bcc: r0 = NavigationBarThemeData()
    //     0xbf3bcc: bl              #0xbf3c28  ; AllocateNavigationBarThemeDataStub -> NavigationBarThemeData (size=0x30)
    // 0xbf3bd0: ldur            x1, [fp, #-0x10]
    // 0xbf3bd4: StoreField: r0->field_7 = r1
    //     0xbf3bd4: stur            w1, [x0, #7]
    // 0xbf3bd8: ldur            x1, [fp, #-0x18]
    // 0xbf3bdc: StoreField: r0->field_f = r1
    //     0xbf3bdc: stur            w1, [x0, #0xf]
    // 0xbf3be0: ldur            x1, [fp, #-8]
    // 0xbf3be4: StoreField: r0->field_23 = r1
    //     0xbf3be4: stur            w1, [x0, #0x23]
    // 0xbf3be8: ldur            x1, [fp, #-0x20]
    // 0xbf3bec: StoreField: r0->field_27 = r1
    //     0xbf3bec: stur            w1, [x0, #0x27]
    // 0xbf3bf0: LeaveFrame
    //     0xbf3bf0: mov             SP, fp
    //     0xbf3bf4: ldp             fp, lr, [SP], #0x10
    // 0xbf3bf8: ret
    //     0xbf3bf8: ret             
    // 0xbf3bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf3bfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf3c00: b               #0xbf3a54
    // 0xbf3c04: SaveReg d0
    //     0xbf3c04: str             q0, [SP, #-0x10]!
    // 0xbf3c08: stp             x2, x3, [SP, #-0x10]!
    // 0xbf3c0c: stp             x0, x1, [SP, #-0x10]!
    // 0xbf3c10: r0 = AllocateDouble()
    //     0xbf3c10: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf3c14: mov             x4, x0
    // 0xbf3c18: ldp             x0, x1, [SP], #0x10
    // 0xbf3c1c: ldp             x2, x3, [SP], #0x10
    // 0xbf3c20: RestoreReg d0
    //     0xbf3c20: ldr             q0, [SP], #0x10
    // 0xbf3c24: b               #0xbf3a94
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8bf4c, size: 0x1a0
    // 0xc8bf4c: EnterFrame
    //     0xc8bf4c: stp             fp, lr, [SP, #-0x10]!
    //     0xc8bf50: mov             fp, SP
    // 0xc8bf54: CheckStackOverflow
    //     0xc8bf54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8bf58: cmp             SP, x16
    //     0xc8bf5c: b.ls            #0xc8c0e4
    // 0xc8bf60: ldr             x1, [fp, #0x10]
    // 0xc8bf64: cmp             w1, NULL
    // 0xc8bf68: b.ne            #0xc8bf7c
    // 0xc8bf6c: r0 = false
    //     0xc8bf6c: add             x0, NULL, #0x30  ; false
    // 0xc8bf70: LeaveFrame
    //     0xc8bf70: mov             SP, fp
    //     0xc8bf74: ldp             fp, lr, [SP], #0x10
    // 0xc8bf78: ret
    //     0xc8bf78: ret             
    // 0xc8bf7c: ldr             x2, [fp, #0x18]
    // 0xc8bf80: cmp             w2, w1
    // 0xc8bf84: b.ne            #0xc8bf98
    // 0xc8bf88: r0 = true
    //     0xc8bf88: add             x0, NULL, #0x20  ; true
    // 0xc8bf8c: LeaveFrame
    //     0xc8bf8c: mov             SP, fp
    //     0xc8bf90: ldp             fp, lr, [SP], #0x10
    // 0xc8bf94: ret
    //     0xc8bf94: ret             
    // 0xc8bf98: r0 = 59
    //     0xc8bf98: mov             x0, #0x3b
    // 0xc8bf9c: branchIfSmi(r1, 0xc8bfa8)
    //     0xc8bf9c: tbz             w1, #0, #0xc8bfa8
    // 0xc8bfa0: r0 = LoadClassIdInstr(r1)
    //     0xc8bfa0: ldur            x0, [x1, #-1]
    //     0xc8bfa4: ubfx            x0, x0, #0xc, #0x14
    // 0xc8bfa8: SaveReg r1
    //     0xc8bfa8: str             x1, [SP, #-8]!
    // 0xc8bfac: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8bfac: mov             x17, #0x57c5
    //     0xc8bfb0: add             lr, x0, x17
    //     0xc8bfb4: ldr             lr, [x21, lr, lsl #3]
    //     0xc8bfb8: blr             lr
    // 0xc8bfbc: add             SP, SP, #8
    // 0xc8bfc0: r1 = LoadClassIdInstr(r0)
    //     0xc8bfc0: ldur            x1, [x0, #-1]
    //     0xc8bfc4: ubfx            x1, x1, #0xc, #0x14
    // 0xc8bfc8: r16 = NavigationBarThemeData
    //     0xc8bfc8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1e0] Type: NavigationBarThemeData
    //     0xc8bfcc: ldr             x16, [x16, #0x1e0]
    // 0xc8bfd0: stp             x16, x0, [SP, #-0x10]!
    // 0xc8bfd4: mov             x0, x1
    // 0xc8bfd8: mov             lr, x0
    // 0xc8bfdc: ldr             lr, [x21, lr, lsl #3]
    // 0xc8bfe0: blr             lr
    // 0xc8bfe4: add             SP, SP, #0x10
    // 0xc8bfe8: tbz             w0, #4, #0xc8bffc
    // 0xc8bfec: r0 = false
    //     0xc8bfec: add             x0, NULL, #0x30  ; false
    // 0xc8bff0: LeaveFrame
    //     0xc8bff0: mov             SP, fp
    //     0xc8bff4: ldp             fp, lr, [SP], #0x10
    // 0xc8bff8: ret
    //     0xc8bff8: ret             
    // 0xc8bffc: ldr             x1, [fp, #0x10]
    // 0xc8c000: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8c000: mov             x0, #0x76
    //     0xc8c004: tbz             w1, #0, #0xc8c014
    //     0xc8c008: ldur            x0, [x1, #-1]
    //     0xc8c00c: ubfx            x0, x0, #0xc, #0x14
    //     0xc8c010: lsl             x0, x0, #1
    // 0xc8c014: r17 = 5564
    //     0xc8c014: mov             x17, #0x15bc
    // 0xc8c018: cmp             w0, w17
    // 0xc8c01c: b.ne            #0xc8c0d4
    // 0xc8c020: ldr             x2, [fp, #0x18]
    // 0xc8c024: LoadField: r0 = r1->field_7
    //     0xc8c024: ldur            w0, [x1, #7]
    // 0xc8c028: DecompressPointer r0
    //     0xc8c028: add             x0, x0, HEAP, lsl #32
    // 0xc8c02c: LoadField: r3 = r2->field_7
    //     0xc8c02c: ldur            w3, [x2, #7]
    // 0xc8c030: DecompressPointer r3
    //     0xc8c030: add             x3, x3, HEAP, lsl #32
    // 0xc8c034: r4 = LoadClassIdInstr(r0)
    //     0xc8c034: ldur            x4, [x0, #-1]
    //     0xc8c038: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c03c: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c040: mov             x0, x4
    // 0xc8c044: mov             lr, x0
    // 0xc8c048: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c04c: blr             lr
    // 0xc8c050: add             SP, SP, #0x10
    // 0xc8c054: tbnz            w0, #4, #0xc8c0d4
    // 0xc8c058: ldr             x2, [fp, #0x18]
    // 0xc8c05c: ldr             x1, [fp, #0x10]
    // 0xc8c060: LoadField: r0 = r1->field_f
    //     0xc8c060: ldur            w0, [x1, #0xf]
    // 0xc8c064: DecompressPointer r0
    //     0xc8c064: add             x0, x0, HEAP, lsl #32
    // 0xc8c068: LoadField: r3 = r2->field_f
    //     0xc8c068: ldur            w3, [x2, #0xf]
    // 0xc8c06c: DecompressPointer r3
    //     0xc8c06c: add             x3, x3, HEAP, lsl #32
    // 0xc8c070: r4 = LoadClassIdInstr(r0)
    //     0xc8c070: ldur            x4, [x0, #-1]
    //     0xc8c074: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c078: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c07c: mov             x0, x4
    // 0xc8c080: mov             lr, x0
    // 0xc8c084: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c088: blr             lr
    // 0xc8c08c: add             SP, SP, #0x10
    // 0xc8c090: tbnz            w0, #4, #0xc8c0d4
    // 0xc8c094: ldr             x2, [fp, #0x18]
    // 0xc8c098: ldr             x1, [fp, #0x10]
    // 0xc8c09c: LoadField: r3 = r1->field_23
    //     0xc8c09c: ldur            w3, [x1, #0x23]
    // 0xc8c0a0: DecompressPointer r3
    //     0xc8c0a0: add             x3, x3, HEAP, lsl #32
    // 0xc8c0a4: LoadField: r4 = r2->field_23
    //     0xc8c0a4: ldur            w4, [x2, #0x23]
    // 0xc8c0a8: DecompressPointer r4
    //     0xc8c0a8: add             x4, x4, HEAP, lsl #32
    // 0xc8c0ac: cmp             w3, w4
    // 0xc8c0b0: b.ne            #0xc8c0d4
    // 0xc8c0b4: LoadField: r3 = r1->field_27
    //     0xc8c0b4: ldur            w3, [x1, #0x27]
    // 0xc8c0b8: DecompressPointer r3
    //     0xc8c0b8: add             x3, x3, HEAP, lsl #32
    // 0xc8c0bc: LoadField: r1 = r2->field_27
    //     0xc8c0bc: ldur            w1, [x2, #0x27]
    // 0xc8c0c0: DecompressPointer r1
    //     0xc8c0c0: add             x1, x1, HEAP, lsl #32
    // 0xc8c0c4: cmp             w3, w1
    // 0xc8c0c8: b.ne            #0xc8c0d4
    // 0xc8c0cc: r0 = true
    //     0xc8c0cc: add             x0, NULL, #0x20  ; true
    // 0xc8c0d0: b               #0xc8c0d8
    // 0xc8c0d4: r0 = false
    //     0xc8c0d4: add             x0, NULL, #0x30  ; false
    // 0xc8c0d8: LeaveFrame
    //     0xc8c0d8: mov             SP, fp
    //     0xc8c0dc: ldp             fp, lr, [SP], #0x10
    // 0xc8c0e0: ret
    //     0xc8c0e0: ret             
    // 0xc8c0e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8c0e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8c0e8: b               #0xc8bf60
  }
}

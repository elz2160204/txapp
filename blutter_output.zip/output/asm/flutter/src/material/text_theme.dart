// lib: , url: package:flutter/src/material/text_theme.dart

// class id: 1049329, size: 0x8
class :: {
}

// class id: 2719, size: 0x44, field offset: 0x8
//   const constructor, 
class TextTheme extends _DiagnosticableTree&Object&Diagnosticable {

  TextStyle field_8;
  TextStyle field_c;
  TextStyle field_10;
  TextStyle field_14;
  TextStyle field_18;
  TextStyle field_1c;
  TextStyle field_20;
  TextStyle field_24;
  TextStyle field_28;
  TextStyle field_2c;
  TextStyle field_30;
  TextStyle field_34;
  TextStyle field_38;
  TextStyle field_3c;
  TextStyle field_40;

  _ merge(/* No info */) {
    // ** addr: 0x6cd5cc, size: 0x5c4
    // 0x6cd5cc: EnterFrame
    //     0x6cd5cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6cd5d0: mov             fp, SP
    // 0x6cd5d4: AllocStack(0x70)
    //     0x6cd5d4: sub             SP, SP, #0x70
    // 0x6cd5d8: CheckStackOverflow
    //     0x6cd5d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cd5dc: cmp             SP, x16
    //     0x6cd5e0: b.ls            #0x6cdb88
    // 0x6cd5e4: ldr             x0, [fp, #0x10]
    // 0x6cd5e8: cmp             w0, NULL
    // 0x6cd5ec: b.ne            #0x6cd600
    // 0x6cd5f0: ldr             x0, [fp, #0x18]
    // 0x6cd5f4: LeaveFrame
    //     0x6cd5f4: mov             SP, fp
    //     0x6cd5f8: ldp             fp, lr, [SP], #0x10
    // 0x6cd5fc: ret
    //     0x6cd5fc: ret             
    // 0x6cd600: ldr             x1, [fp, #0x18]
    // 0x6cd604: LoadField: r2 = r1->field_7
    //     0x6cd604: ldur            w2, [x1, #7]
    // 0x6cd608: DecompressPointer r2
    //     0x6cd608: add             x2, x2, HEAP, lsl #32
    // 0x6cd60c: cmp             w2, NULL
    // 0x6cd610: b.ne            #0x6cd61c
    // 0x6cd614: r0 = Null
    //     0x6cd614: mov             x0, NULL
    // 0x6cd618: b               #0x6cd630
    // 0x6cd61c: LoadField: r3 = r0->field_7
    //     0x6cd61c: ldur            w3, [x0, #7]
    // 0x6cd620: DecompressPointer r3
    //     0x6cd620: add             x3, x3, HEAP, lsl #32
    // 0x6cd624: stp             x3, x2, [SP, #-0x10]!
    // 0x6cd628: r0 = merge()
    //     0x6cd628: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd62c: add             SP, SP, #0x10
    // 0x6cd630: cmp             w0, NULL
    // 0x6cd634: b.ne            #0x6cd64c
    // 0x6cd638: ldr             x1, [fp, #0x10]
    // 0x6cd63c: LoadField: r0 = r1->field_7
    //     0x6cd63c: ldur            w0, [x1, #7]
    // 0x6cd640: DecompressPointer r0
    //     0x6cd640: add             x0, x0, HEAP, lsl #32
    // 0x6cd644: mov             x2, x0
    // 0x6cd648: b               #0x6cd654
    // 0x6cd64c: ldr             x1, [fp, #0x10]
    // 0x6cd650: mov             x2, x0
    // 0x6cd654: ldr             x0, [fp, #0x18]
    // 0x6cd658: stur            x2, [fp, #-8]
    // 0x6cd65c: LoadField: r3 = r0->field_b
    //     0x6cd65c: ldur            w3, [x0, #0xb]
    // 0x6cd660: DecompressPointer r3
    //     0x6cd660: add             x3, x3, HEAP, lsl #32
    // 0x6cd664: cmp             w3, NULL
    // 0x6cd668: b.ne            #0x6cd674
    // 0x6cd66c: r0 = Null
    //     0x6cd66c: mov             x0, NULL
    // 0x6cd670: b               #0x6cd688
    // 0x6cd674: LoadField: r4 = r1->field_b
    //     0x6cd674: ldur            w4, [x1, #0xb]
    // 0x6cd678: DecompressPointer r4
    //     0x6cd678: add             x4, x4, HEAP, lsl #32
    // 0x6cd67c: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd680: r0 = merge()
    //     0x6cd680: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd684: add             SP, SP, #0x10
    // 0x6cd688: cmp             w0, NULL
    // 0x6cd68c: b.ne            #0x6cd6a4
    // 0x6cd690: ldr             x1, [fp, #0x10]
    // 0x6cd694: LoadField: r0 = r1->field_b
    //     0x6cd694: ldur            w0, [x1, #0xb]
    // 0x6cd698: DecompressPointer r0
    //     0x6cd698: add             x0, x0, HEAP, lsl #32
    // 0x6cd69c: mov             x2, x0
    // 0x6cd6a0: b               #0x6cd6ac
    // 0x6cd6a4: ldr             x1, [fp, #0x10]
    // 0x6cd6a8: mov             x2, x0
    // 0x6cd6ac: ldr             x0, [fp, #0x18]
    // 0x6cd6b0: stur            x2, [fp, #-0x10]
    // 0x6cd6b4: LoadField: r3 = r0->field_f
    //     0x6cd6b4: ldur            w3, [x0, #0xf]
    // 0x6cd6b8: DecompressPointer r3
    //     0x6cd6b8: add             x3, x3, HEAP, lsl #32
    // 0x6cd6bc: cmp             w3, NULL
    // 0x6cd6c0: b.ne            #0x6cd6cc
    // 0x6cd6c4: r0 = Null
    //     0x6cd6c4: mov             x0, NULL
    // 0x6cd6c8: b               #0x6cd6e0
    // 0x6cd6cc: LoadField: r4 = r1->field_f
    //     0x6cd6cc: ldur            w4, [x1, #0xf]
    // 0x6cd6d0: DecompressPointer r4
    //     0x6cd6d0: add             x4, x4, HEAP, lsl #32
    // 0x6cd6d4: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd6d8: r0 = merge()
    //     0x6cd6d8: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd6dc: add             SP, SP, #0x10
    // 0x6cd6e0: cmp             w0, NULL
    // 0x6cd6e4: b.ne            #0x6cd6fc
    // 0x6cd6e8: ldr             x1, [fp, #0x10]
    // 0x6cd6ec: LoadField: r0 = r1->field_f
    //     0x6cd6ec: ldur            w0, [x1, #0xf]
    // 0x6cd6f0: DecompressPointer r0
    //     0x6cd6f0: add             x0, x0, HEAP, lsl #32
    // 0x6cd6f4: mov             x2, x0
    // 0x6cd6f8: b               #0x6cd704
    // 0x6cd6fc: ldr             x1, [fp, #0x10]
    // 0x6cd700: mov             x2, x0
    // 0x6cd704: ldr             x0, [fp, #0x18]
    // 0x6cd708: stur            x2, [fp, #-0x18]
    // 0x6cd70c: LoadField: r3 = r0->field_13
    //     0x6cd70c: ldur            w3, [x0, #0x13]
    // 0x6cd710: DecompressPointer r3
    //     0x6cd710: add             x3, x3, HEAP, lsl #32
    // 0x6cd714: cmp             w3, NULL
    // 0x6cd718: b.ne            #0x6cd724
    // 0x6cd71c: r0 = Null
    //     0x6cd71c: mov             x0, NULL
    // 0x6cd720: b               #0x6cd738
    // 0x6cd724: LoadField: r4 = r1->field_13
    //     0x6cd724: ldur            w4, [x1, #0x13]
    // 0x6cd728: DecompressPointer r4
    //     0x6cd728: add             x4, x4, HEAP, lsl #32
    // 0x6cd72c: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd730: r0 = merge()
    //     0x6cd730: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd734: add             SP, SP, #0x10
    // 0x6cd738: cmp             w0, NULL
    // 0x6cd73c: b.ne            #0x6cd754
    // 0x6cd740: ldr             x1, [fp, #0x10]
    // 0x6cd744: LoadField: r0 = r1->field_13
    //     0x6cd744: ldur            w0, [x1, #0x13]
    // 0x6cd748: DecompressPointer r0
    //     0x6cd748: add             x0, x0, HEAP, lsl #32
    // 0x6cd74c: mov             x2, x0
    // 0x6cd750: b               #0x6cd75c
    // 0x6cd754: ldr             x1, [fp, #0x10]
    // 0x6cd758: mov             x2, x0
    // 0x6cd75c: ldr             x0, [fp, #0x18]
    // 0x6cd760: stur            x2, [fp, #-0x20]
    // 0x6cd764: LoadField: r3 = r0->field_17
    //     0x6cd764: ldur            w3, [x0, #0x17]
    // 0x6cd768: DecompressPointer r3
    //     0x6cd768: add             x3, x3, HEAP, lsl #32
    // 0x6cd76c: cmp             w3, NULL
    // 0x6cd770: b.ne            #0x6cd77c
    // 0x6cd774: r0 = Null
    //     0x6cd774: mov             x0, NULL
    // 0x6cd778: b               #0x6cd790
    // 0x6cd77c: LoadField: r4 = r1->field_17
    //     0x6cd77c: ldur            w4, [x1, #0x17]
    // 0x6cd780: DecompressPointer r4
    //     0x6cd780: add             x4, x4, HEAP, lsl #32
    // 0x6cd784: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd788: r0 = merge()
    //     0x6cd788: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd78c: add             SP, SP, #0x10
    // 0x6cd790: cmp             w0, NULL
    // 0x6cd794: b.ne            #0x6cd7ac
    // 0x6cd798: ldr             x1, [fp, #0x10]
    // 0x6cd79c: LoadField: r0 = r1->field_17
    //     0x6cd79c: ldur            w0, [x1, #0x17]
    // 0x6cd7a0: DecompressPointer r0
    //     0x6cd7a0: add             x0, x0, HEAP, lsl #32
    // 0x6cd7a4: mov             x2, x0
    // 0x6cd7a8: b               #0x6cd7b4
    // 0x6cd7ac: ldr             x1, [fp, #0x10]
    // 0x6cd7b0: mov             x2, x0
    // 0x6cd7b4: ldr             x0, [fp, #0x18]
    // 0x6cd7b8: stur            x2, [fp, #-0x28]
    // 0x6cd7bc: LoadField: r3 = r0->field_1b
    //     0x6cd7bc: ldur            w3, [x0, #0x1b]
    // 0x6cd7c0: DecompressPointer r3
    //     0x6cd7c0: add             x3, x3, HEAP, lsl #32
    // 0x6cd7c4: cmp             w3, NULL
    // 0x6cd7c8: b.ne            #0x6cd7d4
    // 0x6cd7cc: r0 = Null
    //     0x6cd7cc: mov             x0, NULL
    // 0x6cd7d0: b               #0x6cd7e8
    // 0x6cd7d4: LoadField: r4 = r1->field_1b
    //     0x6cd7d4: ldur            w4, [x1, #0x1b]
    // 0x6cd7d8: DecompressPointer r4
    //     0x6cd7d8: add             x4, x4, HEAP, lsl #32
    // 0x6cd7dc: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd7e0: r0 = merge()
    //     0x6cd7e0: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd7e4: add             SP, SP, #0x10
    // 0x6cd7e8: cmp             w0, NULL
    // 0x6cd7ec: b.ne            #0x6cd804
    // 0x6cd7f0: ldr             x1, [fp, #0x10]
    // 0x6cd7f4: LoadField: r0 = r1->field_1b
    //     0x6cd7f4: ldur            w0, [x1, #0x1b]
    // 0x6cd7f8: DecompressPointer r0
    //     0x6cd7f8: add             x0, x0, HEAP, lsl #32
    // 0x6cd7fc: mov             x2, x0
    // 0x6cd800: b               #0x6cd80c
    // 0x6cd804: ldr             x1, [fp, #0x10]
    // 0x6cd808: mov             x2, x0
    // 0x6cd80c: ldr             x0, [fp, #0x18]
    // 0x6cd810: stur            x2, [fp, #-0x30]
    // 0x6cd814: LoadField: r3 = r0->field_1f
    //     0x6cd814: ldur            w3, [x0, #0x1f]
    // 0x6cd818: DecompressPointer r3
    //     0x6cd818: add             x3, x3, HEAP, lsl #32
    // 0x6cd81c: cmp             w3, NULL
    // 0x6cd820: b.ne            #0x6cd82c
    // 0x6cd824: r0 = Null
    //     0x6cd824: mov             x0, NULL
    // 0x6cd828: b               #0x6cd840
    // 0x6cd82c: LoadField: r4 = r1->field_1f
    //     0x6cd82c: ldur            w4, [x1, #0x1f]
    // 0x6cd830: DecompressPointer r4
    //     0x6cd830: add             x4, x4, HEAP, lsl #32
    // 0x6cd834: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd838: r0 = merge()
    //     0x6cd838: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd83c: add             SP, SP, #0x10
    // 0x6cd840: cmp             w0, NULL
    // 0x6cd844: b.ne            #0x6cd85c
    // 0x6cd848: ldr             x1, [fp, #0x10]
    // 0x6cd84c: LoadField: r0 = r1->field_1f
    //     0x6cd84c: ldur            w0, [x1, #0x1f]
    // 0x6cd850: DecompressPointer r0
    //     0x6cd850: add             x0, x0, HEAP, lsl #32
    // 0x6cd854: mov             x2, x0
    // 0x6cd858: b               #0x6cd864
    // 0x6cd85c: ldr             x1, [fp, #0x10]
    // 0x6cd860: mov             x2, x0
    // 0x6cd864: ldr             x0, [fp, #0x18]
    // 0x6cd868: stur            x2, [fp, #-0x38]
    // 0x6cd86c: LoadField: r3 = r0->field_23
    //     0x6cd86c: ldur            w3, [x0, #0x23]
    // 0x6cd870: DecompressPointer r3
    //     0x6cd870: add             x3, x3, HEAP, lsl #32
    // 0x6cd874: cmp             w3, NULL
    // 0x6cd878: b.ne            #0x6cd884
    // 0x6cd87c: r0 = Null
    //     0x6cd87c: mov             x0, NULL
    // 0x6cd880: b               #0x6cd898
    // 0x6cd884: LoadField: r4 = r1->field_23
    //     0x6cd884: ldur            w4, [x1, #0x23]
    // 0x6cd888: DecompressPointer r4
    //     0x6cd888: add             x4, x4, HEAP, lsl #32
    // 0x6cd88c: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd890: r0 = merge()
    //     0x6cd890: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd894: add             SP, SP, #0x10
    // 0x6cd898: cmp             w0, NULL
    // 0x6cd89c: b.ne            #0x6cd8b4
    // 0x6cd8a0: ldr             x1, [fp, #0x10]
    // 0x6cd8a4: LoadField: r0 = r1->field_23
    //     0x6cd8a4: ldur            w0, [x1, #0x23]
    // 0x6cd8a8: DecompressPointer r0
    //     0x6cd8a8: add             x0, x0, HEAP, lsl #32
    // 0x6cd8ac: mov             x2, x0
    // 0x6cd8b0: b               #0x6cd8bc
    // 0x6cd8b4: ldr             x1, [fp, #0x10]
    // 0x6cd8b8: mov             x2, x0
    // 0x6cd8bc: ldr             x0, [fp, #0x18]
    // 0x6cd8c0: stur            x2, [fp, #-0x40]
    // 0x6cd8c4: LoadField: r3 = r0->field_27
    //     0x6cd8c4: ldur            w3, [x0, #0x27]
    // 0x6cd8c8: DecompressPointer r3
    //     0x6cd8c8: add             x3, x3, HEAP, lsl #32
    // 0x6cd8cc: cmp             w3, NULL
    // 0x6cd8d0: b.ne            #0x6cd8dc
    // 0x6cd8d4: r0 = Null
    //     0x6cd8d4: mov             x0, NULL
    // 0x6cd8d8: b               #0x6cd8f0
    // 0x6cd8dc: LoadField: r4 = r1->field_27
    //     0x6cd8dc: ldur            w4, [x1, #0x27]
    // 0x6cd8e0: DecompressPointer r4
    //     0x6cd8e0: add             x4, x4, HEAP, lsl #32
    // 0x6cd8e4: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd8e8: r0 = merge()
    //     0x6cd8e8: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd8ec: add             SP, SP, #0x10
    // 0x6cd8f0: cmp             w0, NULL
    // 0x6cd8f4: b.ne            #0x6cd90c
    // 0x6cd8f8: ldr             x1, [fp, #0x10]
    // 0x6cd8fc: LoadField: r0 = r1->field_27
    //     0x6cd8fc: ldur            w0, [x1, #0x27]
    // 0x6cd900: DecompressPointer r0
    //     0x6cd900: add             x0, x0, HEAP, lsl #32
    // 0x6cd904: mov             x2, x0
    // 0x6cd908: b               #0x6cd914
    // 0x6cd90c: ldr             x1, [fp, #0x10]
    // 0x6cd910: mov             x2, x0
    // 0x6cd914: ldr             x0, [fp, #0x18]
    // 0x6cd918: stur            x2, [fp, #-0x48]
    // 0x6cd91c: LoadField: r3 = r0->field_2b
    //     0x6cd91c: ldur            w3, [x0, #0x2b]
    // 0x6cd920: DecompressPointer r3
    //     0x6cd920: add             x3, x3, HEAP, lsl #32
    // 0x6cd924: cmp             w3, NULL
    // 0x6cd928: b.ne            #0x6cd934
    // 0x6cd92c: r0 = Null
    //     0x6cd92c: mov             x0, NULL
    // 0x6cd930: b               #0x6cd948
    // 0x6cd934: LoadField: r4 = r1->field_2b
    //     0x6cd934: ldur            w4, [x1, #0x2b]
    // 0x6cd938: DecompressPointer r4
    //     0x6cd938: add             x4, x4, HEAP, lsl #32
    // 0x6cd93c: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd940: r0 = merge()
    //     0x6cd940: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd944: add             SP, SP, #0x10
    // 0x6cd948: cmp             w0, NULL
    // 0x6cd94c: b.ne            #0x6cd964
    // 0x6cd950: ldr             x1, [fp, #0x10]
    // 0x6cd954: LoadField: r0 = r1->field_2b
    //     0x6cd954: ldur            w0, [x1, #0x2b]
    // 0x6cd958: DecompressPointer r0
    //     0x6cd958: add             x0, x0, HEAP, lsl #32
    // 0x6cd95c: mov             x2, x0
    // 0x6cd960: b               #0x6cd96c
    // 0x6cd964: ldr             x1, [fp, #0x10]
    // 0x6cd968: mov             x2, x0
    // 0x6cd96c: ldr             x0, [fp, #0x18]
    // 0x6cd970: stur            x2, [fp, #-0x50]
    // 0x6cd974: LoadField: r3 = r0->field_2f
    //     0x6cd974: ldur            w3, [x0, #0x2f]
    // 0x6cd978: DecompressPointer r3
    //     0x6cd978: add             x3, x3, HEAP, lsl #32
    // 0x6cd97c: cmp             w3, NULL
    // 0x6cd980: b.ne            #0x6cd98c
    // 0x6cd984: r0 = Null
    //     0x6cd984: mov             x0, NULL
    // 0x6cd988: b               #0x6cd9a0
    // 0x6cd98c: LoadField: r4 = r1->field_2f
    //     0x6cd98c: ldur            w4, [x1, #0x2f]
    // 0x6cd990: DecompressPointer r4
    //     0x6cd990: add             x4, x4, HEAP, lsl #32
    // 0x6cd994: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd998: r0 = merge()
    //     0x6cd998: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd99c: add             SP, SP, #0x10
    // 0x6cd9a0: cmp             w0, NULL
    // 0x6cd9a4: b.ne            #0x6cd9bc
    // 0x6cd9a8: ldr             x1, [fp, #0x10]
    // 0x6cd9ac: LoadField: r0 = r1->field_2f
    //     0x6cd9ac: ldur            w0, [x1, #0x2f]
    // 0x6cd9b0: DecompressPointer r0
    //     0x6cd9b0: add             x0, x0, HEAP, lsl #32
    // 0x6cd9b4: mov             x2, x0
    // 0x6cd9b8: b               #0x6cd9c4
    // 0x6cd9bc: ldr             x1, [fp, #0x10]
    // 0x6cd9c0: mov             x2, x0
    // 0x6cd9c4: ldr             x0, [fp, #0x18]
    // 0x6cd9c8: stur            x2, [fp, #-0x58]
    // 0x6cd9cc: LoadField: r3 = r0->field_33
    //     0x6cd9cc: ldur            w3, [x0, #0x33]
    // 0x6cd9d0: DecompressPointer r3
    //     0x6cd9d0: add             x3, x3, HEAP, lsl #32
    // 0x6cd9d4: cmp             w3, NULL
    // 0x6cd9d8: b.ne            #0x6cd9e4
    // 0x6cd9dc: r0 = Null
    //     0x6cd9dc: mov             x0, NULL
    // 0x6cd9e0: b               #0x6cd9f8
    // 0x6cd9e4: LoadField: r4 = r1->field_33
    //     0x6cd9e4: ldur            w4, [x1, #0x33]
    // 0x6cd9e8: DecompressPointer r4
    //     0x6cd9e8: add             x4, x4, HEAP, lsl #32
    // 0x6cd9ec: stp             x4, x3, [SP, #-0x10]!
    // 0x6cd9f0: r0 = merge()
    //     0x6cd9f0: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cd9f4: add             SP, SP, #0x10
    // 0x6cd9f8: cmp             w0, NULL
    // 0x6cd9fc: b.ne            #0x6cda14
    // 0x6cda00: ldr             x1, [fp, #0x10]
    // 0x6cda04: LoadField: r0 = r1->field_33
    //     0x6cda04: ldur            w0, [x1, #0x33]
    // 0x6cda08: DecompressPointer r0
    //     0x6cda08: add             x0, x0, HEAP, lsl #32
    // 0x6cda0c: mov             x2, x0
    // 0x6cda10: b               #0x6cda1c
    // 0x6cda14: ldr             x1, [fp, #0x10]
    // 0x6cda18: mov             x2, x0
    // 0x6cda1c: ldr             x0, [fp, #0x18]
    // 0x6cda20: stur            x2, [fp, #-0x60]
    // 0x6cda24: LoadField: r3 = r0->field_37
    //     0x6cda24: ldur            w3, [x0, #0x37]
    // 0x6cda28: DecompressPointer r3
    //     0x6cda28: add             x3, x3, HEAP, lsl #32
    // 0x6cda2c: cmp             w3, NULL
    // 0x6cda30: b.ne            #0x6cda3c
    // 0x6cda34: r0 = Null
    //     0x6cda34: mov             x0, NULL
    // 0x6cda38: b               #0x6cda50
    // 0x6cda3c: LoadField: r4 = r1->field_37
    //     0x6cda3c: ldur            w4, [x1, #0x37]
    // 0x6cda40: DecompressPointer r4
    //     0x6cda40: add             x4, x4, HEAP, lsl #32
    // 0x6cda44: stp             x4, x3, [SP, #-0x10]!
    // 0x6cda48: r0 = merge()
    //     0x6cda48: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cda4c: add             SP, SP, #0x10
    // 0x6cda50: cmp             w0, NULL
    // 0x6cda54: b.ne            #0x6cda6c
    // 0x6cda58: ldr             x1, [fp, #0x10]
    // 0x6cda5c: LoadField: r0 = r1->field_37
    //     0x6cda5c: ldur            w0, [x1, #0x37]
    // 0x6cda60: DecompressPointer r0
    //     0x6cda60: add             x0, x0, HEAP, lsl #32
    // 0x6cda64: mov             x2, x0
    // 0x6cda68: b               #0x6cda74
    // 0x6cda6c: ldr             x1, [fp, #0x10]
    // 0x6cda70: mov             x2, x0
    // 0x6cda74: ldr             x0, [fp, #0x18]
    // 0x6cda78: stur            x2, [fp, #-0x68]
    // 0x6cda7c: LoadField: r3 = r0->field_3b
    //     0x6cda7c: ldur            w3, [x0, #0x3b]
    // 0x6cda80: DecompressPointer r3
    //     0x6cda80: add             x3, x3, HEAP, lsl #32
    // 0x6cda84: cmp             w3, NULL
    // 0x6cda88: b.ne            #0x6cda94
    // 0x6cda8c: r0 = Null
    //     0x6cda8c: mov             x0, NULL
    // 0x6cda90: b               #0x6cdaa8
    // 0x6cda94: LoadField: r4 = r1->field_3b
    //     0x6cda94: ldur            w4, [x1, #0x3b]
    // 0x6cda98: DecompressPointer r4
    //     0x6cda98: add             x4, x4, HEAP, lsl #32
    // 0x6cda9c: stp             x4, x3, [SP, #-0x10]!
    // 0x6cdaa0: r0 = merge()
    //     0x6cdaa0: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cdaa4: add             SP, SP, #0x10
    // 0x6cdaa8: cmp             w0, NULL
    // 0x6cdaac: b.ne            #0x6cdac4
    // 0x6cdab0: ldr             x1, [fp, #0x10]
    // 0x6cdab4: LoadField: r0 = r1->field_3b
    //     0x6cdab4: ldur            w0, [x1, #0x3b]
    // 0x6cdab8: DecompressPointer r0
    //     0x6cdab8: add             x0, x0, HEAP, lsl #32
    // 0x6cdabc: mov             x2, x0
    // 0x6cdac0: b               #0x6cdacc
    // 0x6cdac4: ldr             x1, [fp, #0x10]
    // 0x6cdac8: mov             x2, x0
    // 0x6cdacc: ldr             x0, [fp, #0x18]
    // 0x6cdad0: stur            x2, [fp, #-0x70]
    // 0x6cdad4: LoadField: r3 = r0->field_3f
    //     0x6cdad4: ldur            w3, [x0, #0x3f]
    // 0x6cdad8: DecompressPointer r3
    //     0x6cdad8: add             x3, x3, HEAP, lsl #32
    // 0x6cdadc: cmp             w3, NULL
    // 0x6cdae0: b.ne            #0x6cdaec
    // 0x6cdae4: r0 = Null
    //     0x6cdae4: mov             x0, NULL
    // 0x6cdae8: b               #0x6cdb00
    // 0x6cdaec: LoadField: r4 = r1->field_3f
    //     0x6cdaec: ldur            w4, [x1, #0x3f]
    // 0x6cdaf0: DecompressPointer r4
    //     0x6cdaf0: add             x4, x4, HEAP, lsl #32
    // 0x6cdaf4: stp             x4, x3, [SP, #-0x10]!
    // 0x6cdaf8: r0 = merge()
    //     0x6cdaf8: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x6cdafc: add             SP, SP, #0x10
    // 0x6cdb00: cmp             w0, NULL
    // 0x6cdb04: b.ne            #0x6cdb18
    // 0x6cdb08: ldr             x0, [fp, #0x10]
    // 0x6cdb0c: LoadField: r1 = r0->field_3f
    //     0x6cdb0c: ldur            w1, [x0, #0x3f]
    // 0x6cdb10: DecompressPointer r1
    //     0x6cdb10: add             x1, x1, HEAP, lsl #32
    // 0x6cdb14: mov             x0, x1
    // 0x6cdb18: ldr             x16, [fp, #0x18]
    // 0x6cdb1c: ldur            lr, [fp, #-0x50]
    // 0x6cdb20: stp             lr, x16, [SP, #-0x10]!
    // 0x6cdb24: ldur            x16, [fp, #-0x58]
    // 0x6cdb28: ldur            lr, [fp, #-0x60]
    // 0x6cdb2c: stp             lr, x16, [SP, #-0x10]!
    // 0x6cdb30: ldur            x16, [fp, #-8]
    // 0x6cdb34: ldur            lr, [fp, #-0x10]
    // 0x6cdb38: stp             lr, x16, [SP, #-0x10]!
    // 0x6cdb3c: ldur            x16, [fp, #-0x18]
    // 0x6cdb40: ldur            lr, [fp, #-0x20]
    // 0x6cdb44: stp             lr, x16, [SP, #-0x10]!
    // 0x6cdb48: ldur            x16, [fp, #-0x28]
    // 0x6cdb4c: ldur            lr, [fp, #-0x30]
    // 0x6cdb50: stp             lr, x16, [SP, #-0x10]!
    // 0x6cdb54: ldur            x16, [fp, #-0x68]
    // 0x6cdb58: ldur            lr, [fp, #-0x70]
    // 0x6cdb5c: stp             lr, x16, [SP, #-0x10]!
    // 0x6cdb60: ldur            x16, [fp, #-0x38]
    // 0x6cdb64: stp             x16, x0, [SP, #-0x10]!
    // 0x6cdb68: ldur            x16, [fp, #-0x40]
    // 0x6cdb6c: ldur            lr, [fp, #-0x48]
    // 0x6cdb70: stp             lr, x16, [SP, #-0x10]!
    // 0x6cdb74: r0 = copyWith()
    //     0x6cdb74: bl              #0x6cdb90  ; [package:flutter/src/material/text_theme.dart] TextTheme::copyWith
    // 0x6cdb78: add             SP, SP, #0x80
    // 0x6cdb7c: LeaveFrame
    //     0x6cdb7c: mov             SP, fp
    //     0x6cdb80: ldp             fp, lr, [SP], #0x10
    // 0x6cdb84: ret
    //     0x6cdb84: ret             
    // 0x6cdb88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cdb88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cdb8c: b               #0x6cd5e4
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x6cdb90, size: 0x444
    // 0x6cdb90: EnterFrame
    //     0x6cdb90: stp             fp, lr, [SP, #-0x10]!
    //     0x6cdb94: mov             fp, SP
    // 0x6cdb98: AllocStack(0x78)
    //     0x6cdb98: sub             SP, SP, #0x78
    // 0x6cdb9c: ldr             x0, [fp, #0x68]
    // 0x6cdba0: cmp             w0, NULL
    // 0x6cdba4: b.ne            #0x6cdbac
    // 0x6cdba8: r0 = Null
    //     0x6cdba8: mov             x0, NULL
    // 0x6cdbac: cmp             w0, NULL
    // 0x6cdbb0: b.ne            #0x6cdbc8
    // 0x6cdbb4: ldr             x1, [fp, #0x88]
    // 0x6cdbb8: LoadField: r0 = r1->field_7
    //     0x6cdbb8: ldur            w0, [x1, #7]
    // 0x6cdbbc: DecompressPointer r0
    //     0x6cdbbc: add             x0, x0, HEAP, lsl #32
    // 0x6cdbc0: mov             x2, x0
    // 0x6cdbc4: b               #0x6cdbd0
    // 0x6cdbc8: ldr             x1, [fp, #0x88]
    // 0x6cdbcc: mov             x2, x0
    // 0x6cdbd0: ldr             x0, [fp, #0x60]
    // 0x6cdbd4: stur            x2, [fp, #-0x78]
    // 0x6cdbd8: cmp             w0, NULL
    // 0x6cdbdc: b.ne            #0x6cdbe4
    // 0x6cdbe0: r0 = Null
    //     0x6cdbe0: mov             x0, NULL
    // 0x6cdbe4: cmp             w0, NULL
    // 0x6cdbe8: b.ne            #0x6cdbfc
    // 0x6cdbec: LoadField: r0 = r1->field_b
    //     0x6cdbec: ldur            w0, [x1, #0xb]
    // 0x6cdbf0: DecompressPointer r0
    //     0x6cdbf0: add             x0, x0, HEAP, lsl #32
    // 0x6cdbf4: mov             x3, x0
    // 0x6cdbf8: b               #0x6cdc00
    // 0x6cdbfc: mov             x3, x0
    // 0x6cdc00: ldr             x0, [fp, #0x58]
    // 0x6cdc04: stur            x3, [fp, #-0x70]
    // 0x6cdc08: cmp             w0, NULL
    // 0x6cdc0c: b.ne            #0x6cdc14
    // 0x6cdc10: r0 = Null
    //     0x6cdc10: mov             x0, NULL
    // 0x6cdc14: cmp             w0, NULL
    // 0x6cdc18: b.ne            #0x6cdc2c
    // 0x6cdc1c: LoadField: r0 = r1->field_f
    //     0x6cdc1c: ldur            w0, [x1, #0xf]
    // 0x6cdc20: DecompressPointer r0
    //     0x6cdc20: add             x0, x0, HEAP, lsl #32
    // 0x6cdc24: mov             x4, x0
    // 0x6cdc28: b               #0x6cdc30
    // 0x6cdc2c: mov             x4, x0
    // 0x6cdc30: ldr             x0, [fp, #0x50]
    // 0x6cdc34: stur            x4, [fp, #-0x68]
    // 0x6cdc38: cmp             w0, NULL
    // 0x6cdc3c: b.ne            #0x6cdc50
    // 0x6cdc40: LoadField: r0 = r1->field_13
    //     0x6cdc40: ldur            w0, [x1, #0x13]
    // 0x6cdc44: DecompressPointer r0
    //     0x6cdc44: add             x0, x0, HEAP, lsl #32
    // 0x6cdc48: mov             x5, x0
    // 0x6cdc4c: b               #0x6cdc54
    // 0x6cdc50: mov             x5, x0
    // 0x6cdc54: ldr             x0, [fp, #0x48]
    // 0x6cdc58: stur            x5, [fp, #-0x60]
    // 0x6cdc5c: cmp             w0, NULL
    // 0x6cdc60: b.ne            #0x6cdc68
    // 0x6cdc64: r0 = Null
    //     0x6cdc64: mov             x0, NULL
    // 0x6cdc68: cmp             w0, NULL
    // 0x6cdc6c: b.ne            #0x6cdc80
    // 0x6cdc70: LoadField: r0 = r1->field_17
    //     0x6cdc70: ldur            w0, [x1, #0x17]
    // 0x6cdc74: DecompressPointer r0
    //     0x6cdc74: add             x0, x0, HEAP, lsl #32
    // 0x6cdc78: mov             x6, x0
    // 0x6cdc7c: b               #0x6cdc84
    // 0x6cdc80: mov             x6, x0
    // 0x6cdc84: ldr             x0, [fp, #0x40]
    // 0x6cdc88: stur            x6, [fp, #-0x58]
    // 0x6cdc8c: cmp             w0, NULL
    // 0x6cdc90: b.ne            #0x6cdc98
    // 0x6cdc94: r0 = Null
    //     0x6cdc94: mov             x0, NULL
    // 0x6cdc98: cmp             w0, NULL
    // 0x6cdc9c: b.ne            #0x6cdcb0
    // 0x6cdca0: LoadField: r0 = r1->field_1b
    //     0x6cdca0: ldur            w0, [x1, #0x1b]
    // 0x6cdca4: DecompressPointer r0
    //     0x6cdca4: add             x0, x0, HEAP, lsl #32
    // 0x6cdca8: mov             x7, x0
    // 0x6cdcac: b               #0x6cdcb4
    // 0x6cdcb0: mov             x7, x0
    // 0x6cdcb4: ldr             x0, [fp, #0x20]
    // 0x6cdcb8: stur            x7, [fp, #-0x50]
    // 0x6cdcbc: cmp             w0, NULL
    // 0x6cdcc0: b.ne            #0x6cdcc8
    // 0x6cdcc4: r0 = Null
    //     0x6cdcc4: mov             x0, NULL
    // 0x6cdcc8: cmp             w0, NULL
    // 0x6cdccc: b.ne            #0x6cdce0
    // 0x6cdcd0: LoadField: r0 = r1->field_1f
    //     0x6cdcd0: ldur            w0, [x1, #0x1f]
    // 0x6cdcd4: DecompressPointer r0
    //     0x6cdcd4: add             x0, x0, HEAP, lsl #32
    // 0x6cdcd8: mov             x8, x0
    // 0x6cdcdc: b               #0x6cdce4
    // 0x6cdce0: mov             x8, x0
    // 0x6cdce4: ldr             x0, [fp, #0x18]
    // 0x6cdce8: stur            x8, [fp, #-0x48]
    // 0x6cdcec: cmp             w0, NULL
    // 0x6cdcf0: b.ne            #0x6cdcf8
    // 0x6cdcf4: r0 = Null
    //     0x6cdcf4: mov             x0, NULL
    // 0x6cdcf8: cmp             w0, NULL
    // 0x6cdcfc: b.ne            #0x6cdd10
    // 0x6cdd00: LoadField: r0 = r1->field_23
    //     0x6cdd00: ldur            w0, [x1, #0x23]
    // 0x6cdd04: DecompressPointer r0
    //     0x6cdd04: add             x0, x0, HEAP, lsl #32
    // 0x6cdd08: mov             x9, x0
    // 0x6cdd0c: b               #0x6cdd14
    // 0x6cdd10: mov             x9, x0
    // 0x6cdd14: ldr             x0, [fp, #0x10]
    // 0x6cdd18: stur            x9, [fp, #-0x40]
    // 0x6cdd1c: cmp             w0, NULL
    // 0x6cdd20: b.ne            #0x6cdd28
    // 0x6cdd24: r0 = Null
    //     0x6cdd24: mov             x0, NULL
    // 0x6cdd28: cmp             w0, NULL
    // 0x6cdd2c: b.ne            #0x6cdd40
    // 0x6cdd30: LoadField: r0 = r1->field_27
    //     0x6cdd30: ldur            w0, [x1, #0x27]
    // 0x6cdd34: DecompressPointer r0
    //     0x6cdd34: add             x0, x0, HEAP, lsl #32
    // 0x6cdd38: mov             x10, x0
    // 0x6cdd3c: b               #0x6cdd44
    // 0x6cdd40: mov             x10, x0
    // 0x6cdd44: ldr             x0, [fp, #0x80]
    // 0x6cdd48: stur            x10, [fp, #-0x38]
    // 0x6cdd4c: cmp             w0, NULL
    // 0x6cdd50: b.ne            #0x6cdd58
    // 0x6cdd54: r0 = Null
    //     0x6cdd54: mov             x0, NULL
    // 0x6cdd58: cmp             w0, NULL
    // 0x6cdd5c: b.ne            #0x6cdd70
    // 0x6cdd60: LoadField: r0 = r1->field_2b
    //     0x6cdd60: ldur            w0, [x1, #0x2b]
    // 0x6cdd64: DecompressPointer r0
    //     0x6cdd64: add             x0, x0, HEAP, lsl #32
    // 0x6cdd68: mov             x11, x0
    // 0x6cdd6c: b               #0x6cdd74
    // 0x6cdd70: mov             x11, x0
    // 0x6cdd74: ldr             x0, [fp, #0x78]
    // 0x6cdd78: stur            x11, [fp, #-0x30]
    // 0x6cdd7c: cmp             w0, NULL
    // 0x6cdd80: b.ne            #0x6cdd88
    // 0x6cdd84: r0 = Null
    //     0x6cdd84: mov             x0, NULL
    // 0x6cdd88: cmp             w0, NULL
    // 0x6cdd8c: b.ne            #0x6cdda0
    // 0x6cdd90: LoadField: r0 = r1->field_2f
    //     0x6cdd90: ldur            w0, [x1, #0x2f]
    // 0x6cdd94: DecompressPointer r0
    //     0x6cdd94: add             x0, x0, HEAP, lsl #32
    // 0x6cdd98: mov             x12, x0
    // 0x6cdd9c: b               #0x6cdda4
    // 0x6cdda0: mov             x12, x0
    // 0x6cdda4: ldr             x0, [fp, #0x70]
    // 0x6cdda8: stur            x12, [fp, #-0x28]
    // 0x6cddac: cmp             w0, NULL
    // 0x6cddb0: b.ne            #0x6cddb8
    // 0x6cddb4: r0 = Null
    //     0x6cddb4: mov             x0, NULL
    // 0x6cddb8: cmp             w0, NULL
    // 0x6cddbc: b.ne            #0x6cddd0
    // 0x6cddc0: LoadField: r0 = r1->field_33
    //     0x6cddc0: ldur            w0, [x1, #0x33]
    // 0x6cddc4: DecompressPointer r0
    //     0x6cddc4: add             x0, x0, HEAP, lsl #32
    // 0x6cddc8: mov             x13, x0
    // 0x6cddcc: b               #0x6cddd4
    // 0x6cddd0: mov             x13, x0
    // 0x6cddd4: ldr             x0, [fp, #0x38]
    // 0x6cddd8: stur            x13, [fp, #-0x20]
    // 0x6cdddc: cmp             w0, NULL
    // 0x6cdde0: b.ne            #0x6cdde8
    // 0x6cdde4: r0 = Null
    //     0x6cdde4: mov             x0, NULL
    // 0x6cdde8: cmp             w0, NULL
    // 0x6cddec: b.ne            #0x6cde00
    // 0x6cddf0: LoadField: r0 = r1->field_37
    //     0x6cddf0: ldur            w0, [x1, #0x37]
    // 0x6cddf4: DecompressPointer r0
    //     0x6cddf4: add             x0, x0, HEAP, lsl #32
    // 0x6cddf8: mov             x14, x0
    // 0x6cddfc: b               #0x6cde04
    // 0x6cde00: mov             x14, x0
    // 0x6cde04: ldr             x0, [fp, #0x30]
    // 0x6cde08: stur            x14, [fp, #-0x18]
    // 0x6cde0c: cmp             w0, NULL
    // 0x6cde10: b.ne            #0x6cde24
    // 0x6cde14: LoadField: r0 = r1->field_3b
    //     0x6cde14: ldur            w0, [x1, #0x3b]
    // 0x6cde18: DecompressPointer r0
    //     0x6cde18: add             x0, x0, HEAP, lsl #32
    // 0x6cde1c: mov             x19, x0
    // 0x6cde20: b               #0x6cde28
    // 0x6cde24: mov             x19, x0
    // 0x6cde28: ldr             x0, [fp, #0x28]
    // 0x6cde2c: stur            x19, [fp, #-0x10]
    // 0x6cde30: cmp             w0, NULL
    // 0x6cde34: b.ne            #0x6cde3c
    // 0x6cde38: r0 = Null
    //     0x6cde38: mov             x0, NULL
    // 0x6cde3c: cmp             w0, NULL
    // 0x6cde40: b.ne            #0x6cde4c
    // 0x6cde44: LoadField: r0 = r1->field_3f
    //     0x6cde44: ldur            w0, [x1, #0x3f]
    // 0x6cde48: DecompressPointer r0
    //     0x6cde48: add             x0, x0, HEAP, lsl #32
    // 0x6cde4c: stur            x0, [fp, #-8]
    // 0x6cde50: r0 = TextTheme()
    //     0x6cde50: bl              #0x6cdfd4  ; AllocateTextThemeStub -> TextTheme (size=0x44)
    // 0x6cde54: ldur            x1, [fp, #-0x60]
    // 0x6cde58: StoreField: r0->field_13 = r1
    //     0x6cde58: stur            w1, [x0, #0x13]
    // 0x6cde5c: ldur            x1, [fp, #-0x10]
    // 0x6cde60: StoreField: r0->field_3b = r1
    //     0x6cde60: stur            w1, [x0, #0x3b]
    // 0x6cde64: ldur            x1, [fp, #-0x78]
    // 0x6cde68: cmp             w1, NULL
    // 0x6cde6c: b.ne            #0x6cde78
    // 0x6cde70: r2 = Null
    //     0x6cde70: mov             x2, NULL
    // 0x6cde74: b               #0x6cde7c
    // 0x6cde78: mov             x2, x1
    // 0x6cde7c: ldur            x1, [fp, #-0x70]
    // 0x6cde80: StoreField: r0->field_7 = r2
    //     0x6cde80: stur            w2, [x0, #7]
    // 0x6cde84: cmp             w1, NULL
    // 0x6cde88: b.ne            #0x6cde94
    // 0x6cde8c: r2 = Null
    //     0x6cde8c: mov             x2, NULL
    // 0x6cde90: b               #0x6cde98
    // 0x6cde94: mov             x2, x1
    // 0x6cde98: ldur            x1, [fp, #-0x68]
    // 0x6cde9c: StoreField: r0->field_b = r2
    //     0x6cde9c: stur            w2, [x0, #0xb]
    // 0x6cdea0: cmp             w1, NULL
    // 0x6cdea4: b.ne            #0x6cdeb0
    // 0x6cdea8: r2 = Null
    //     0x6cdea8: mov             x2, NULL
    // 0x6cdeac: b               #0x6cdeb4
    // 0x6cdeb0: mov             x2, x1
    // 0x6cdeb4: ldur            x1, [fp, #-0x58]
    // 0x6cdeb8: StoreField: r0->field_f = r2
    //     0x6cdeb8: stur            w2, [x0, #0xf]
    // 0x6cdebc: cmp             w1, NULL
    // 0x6cdec0: b.ne            #0x6cdecc
    // 0x6cdec4: r2 = Null
    //     0x6cdec4: mov             x2, NULL
    // 0x6cdec8: b               #0x6cded0
    // 0x6cdecc: mov             x2, x1
    // 0x6cded0: ldur            x1, [fp, #-0x50]
    // 0x6cded4: StoreField: r0->field_17 = r2
    //     0x6cded4: stur            w2, [x0, #0x17]
    // 0x6cded8: cmp             w1, NULL
    // 0x6cdedc: b.ne            #0x6cdee8
    // 0x6cdee0: r2 = Null
    //     0x6cdee0: mov             x2, NULL
    // 0x6cdee4: b               #0x6cdeec
    // 0x6cdee8: mov             x2, x1
    // 0x6cdeec: ldur            x1, [fp, #-0x48]
    // 0x6cdef0: StoreField: r0->field_1b = r2
    //     0x6cdef0: stur            w2, [x0, #0x1b]
    // 0x6cdef4: cmp             w1, NULL
    // 0x6cdef8: b.ne            #0x6cdf04
    // 0x6cdefc: r2 = Null
    //     0x6cdefc: mov             x2, NULL
    // 0x6cdf00: b               #0x6cdf08
    // 0x6cdf04: mov             x2, x1
    // 0x6cdf08: ldur            x1, [fp, #-0x40]
    // 0x6cdf0c: StoreField: r0->field_1f = r2
    //     0x6cdf0c: stur            w2, [x0, #0x1f]
    // 0x6cdf10: cmp             w1, NULL
    // 0x6cdf14: b.ne            #0x6cdf20
    // 0x6cdf18: r2 = Null
    //     0x6cdf18: mov             x2, NULL
    // 0x6cdf1c: b               #0x6cdf24
    // 0x6cdf20: mov             x2, x1
    // 0x6cdf24: ldur            x1, [fp, #-0x38]
    // 0x6cdf28: StoreField: r0->field_23 = r2
    //     0x6cdf28: stur            w2, [x0, #0x23]
    // 0x6cdf2c: cmp             w1, NULL
    // 0x6cdf30: b.ne            #0x6cdf3c
    // 0x6cdf34: r2 = Null
    //     0x6cdf34: mov             x2, NULL
    // 0x6cdf38: b               #0x6cdf40
    // 0x6cdf3c: mov             x2, x1
    // 0x6cdf40: ldur            x1, [fp, #-0x30]
    // 0x6cdf44: StoreField: r0->field_27 = r2
    //     0x6cdf44: stur            w2, [x0, #0x27]
    // 0x6cdf48: cmp             w1, NULL
    // 0x6cdf4c: b.ne            #0x6cdf58
    // 0x6cdf50: r2 = Null
    //     0x6cdf50: mov             x2, NULL
    // 0x6cdf54: b               #0x6cdf5c
    // 0x6cdf58: mov             x2, x1
    // 0x6cdf5c: ldur            x1, [fp, #-0x28]
    // 0x6cdf60: StoreField: r0->field_2b = r2
    //     0x6cdf60: stur            w2, [x0, #0x2b]
    // 0x6cdf64: cmp             w1, NULL
    // 0x6cdf68: b.ne            #0x6cdf74
    // 0x6cdf6c: r2 = Null
    //     0x6cdf6c: mov             x2, NULL
    // 0x6cdf70: b               #0x6cdf78
    // 0x6cdf74: mov             x2, x1
    // 0x6cdf78: ldur            x1, [fp, #-0x20]
    // 0x6cdf7c: StoreField: r0->field_2f = r2
    //     0x6cdf7c: stur            w2, [x0, #0x2f]
    // 0x6cdf80: cmp             w1, NULL
    // 0x6cdf84: b.ne            #0x6cdf90
    // 0x6cdf88: r2 = Null
    //     0x6cdf88: mov             x2, NULL
    // 0x6cdf8c: b               #0x6cdf94
    // 0x6cdf90: mov             x2, x1
    // 0x6cdf94: ldur            x1, [fp, #-0x18]
    // 0x6cdf98: StoreField: r0->field_33 = r2
    //     0x6cdf98: stur            w2, [x0, #0x33]
    // 0x6cdf9c: cmp             w1, NULL
    // 0x6cdfa0: b.ne            #0x6cdfac
    // 0x6cdfa4: r2 = Null
    //     0x6cdfa4: mov             x2, NULL
    // 0x6cdfa8: b               #0x6cdfb0
    // 0x6cdfac: mov             x2, x1
    // 0x6cdfb0: ldur            x1, [fp, #-8]
    // 0x6cdfb4: StoreField: r0->field_37 = r2
    //     0x6cdfb4: stur            w2, [x0, #0x37]
    // 0x6cdfb8: cmp             w1, NULL
    // 0x6cdfbc: b.ne            #0x6cdfc4
    // 0x6cdfc0: r1 = Null
    //     0x6cdfc0: mov             x1, NULL
    // 0x6cdfc4: StoreField: r0->field_3f = r1
    //     0x6cdfc4: stur            w1, [x0, #0x3f]
    // 0x6cdfc8: LeaveFrame
    //     0x6cdfc8: mov             SP, fp
    //     0x6cdfcc: ldp             fp, lr, [SP], #0x10
    // 0x6cdfd0: ret
    //     0x6cdfd0: ret             
  }
  _ apply(/* No info */) {
    // ** addr: 0x6d1b14, size: 0x538
    // 0x6d1b14: EnterFrame
    //     0x6d1b14: stp             fp, lr, [SP, #-0x10]!
    //     0x6d1b18: mov             fp, SP
    // 0x6d1b1c: AllocStack(0x78)
    //     0x6d1b1c: sub             SP, SP, #0x78
    // 0x6d1b20: CheckStackOverflow
    //     0x6d1b20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d1b24: cmp             SP, x16
    //     0x6d1b28: b.ls            #0x6d2044
    // 0x6d1b2c: ldr             x0, [fp, #0x28]
    // 0x6d1b30: LoadField: r1 = r0->field_7
    //     0x6d1b30: ldur            w1, [x0, #7]
    // 0x6d1b34: DecompressPointer r1
    //     0x6d1b34: add             x1, x1, HEAP, lsl #32
    // 0x6d1b38: cmp             w1, NULL
    // 0x6d1b3c: b.ne            #0x6d1b48
    // 0x6d1b40: r1 = Null
    //     0x6d1b40: mov             x1, NULL
    // 0x6d1b44: b               #0x6d1b68
    // 0x6d1b48: ldr             x16, [fp, #0x10]
    // 0x6d1b4c: stp             x16, x1, [SP, #-0x10]!
    // 0x6d1b50: ldr             x16, [fp, #0x18]
    // 0x6d1b54: SaveReg r16
    //     0x6d1b54: str             x16, [SP, #-8]!
    // 0x6d1b58: r0 = apply()
    //     0x6d1b58: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1b5c: add             SP, SP, #0x18
    // 0x6d1b60: mov             x1, x0
    // 0x6d1b64: ldr             x0, [fp, #0x28]
    // 0x6d1b68: stur            x1, [fp, #-8]
    // 0x6d1b6c: LoadField: r2 = r0->field_b
    //     0x6d1b6c: ldur            w2, [x0, #0xb]
    // 0x6d1b70: DecompressPointer r2
    //     0x6d1b70: add             x2, x2, HEAP, lsl #32
    // 0x6d1b74: cmp             w2, NULL
    // 0x6d1b78: b.ne            #0x6d1b84
    // 0x6d1b7c: r1 = Null
    //     0x6d1b7c: mov             x1, NULL
    // 0x6d1b80: b               #0x6d1ba4
    // 0x6d1b84: ldr             x16, [fp, #0x10]
    // 0x6d1b88: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1b8c: ldr             x16, [fp, #0x18]
    // 0x6d1b90: SaveReg r16
    //     0x6d1b90: str             x16, [SP, #-8]!
    // 0x6d1b94: r0 = apply()
    //     0x6d1b94: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1b98: add             SP, SP, #0x18
    // 0x6d1b9c: mov             x1, x0
    // 0x6d1ba0: ldr             x0, [fp, #0x28]
    // 0x6d1ba4: stur            x1, [fp, #-0x10]
    // 0x6d1ba8: LoadField: r2 = r0->field_f
    //     0x6d1ba8: ldur            w2, [x0, #0xf]
    // 0x6d1bac: DecompressPointer r2
    //     0x6d1bac: add             x2, x2, HEAP, lsl #32
    // 0x6d1bb0: cmp             w2, NULL
    // 0x6d1bb4: b.ne            #0x6d1bc0
    // 0x6d1bb8: r1 = Null
    //     0x6d1bb8: mov             x1, NULL
    // 0x6d1bbc: b               #0x6d1be0
    // 0x6d1bc0: ldr             x16, [fp, #0x10]
    // 0x6d1bc4: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1bc8: ldr             x16, [fp, #0x18]
    // 0x6d1bcc: SaveReg r16
    //     0x6d1bcc: str             x16, [SP, #-8]!
    // 0x6d1bd0: r0 = apply()
    //     0x6d1bd0: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1bd4: add             SP, SP, #0x18
    // 0x6d1bd8: mov             x1, x0
    // 0x6d1bdc: ldr             x0, [fp, #0x28]
    // 0x6d1be0: stur            x1, [fp, #-0x18]
    // 0x6d1be4: LoadField: r2 = r0->field_13
    //     0x6d1be4: ldur            w2, [x0, #0x13]
    // 0x6d1be8: DecompressPointer r2
    //     0x6d1be8: add             x2, x2, HEAP, lsl #32
    // 0x6d1bec: cmp             w2, NULL
    // 0x6d1bf0: b.ne            #0x6d1bfc
    // 0x6d1bf4: r1 = Null
    //     0x6d1bf4: mov             x1, NULL
    // 0x6d1bf8: b               #0x6d1c1c
    // 0x6d1bfc: ldr             x16, [fp, #0x10]
    // 0x6d1c00: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1c04: ldr             x16, [fp, #0x18]
    // 0x6d1c08: SaveReg r16
    //     0x6d1c08: str             x16, [SP, #-8]!
    // 0x6d1c0c: r0 = apply()
    //     0x6d1c0c: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1c10: add             SP, SP, #0x18
    // 0x6d1c14: mov             x1, x0
    // 0x6d1c18: ldr             x0, [fp, #0x28]
    // 0x6d1c1c: stur            x1, [fp, #-0x20]
    // 0x6d1c20: LoadField: r2 = r0->field_17
    //     0x6d1c20: ldur            w2, [x0, #0x17]
    // 0x6d1c24: DecompressPointer r2
    //     0x6d1c24: add             x2, x2, HEAP, lsl #32
    // 0x6d1c28: cmp             w2, NULL
    // 0x6d1c2c: b.ne            #0x6d1c38
    // 0x6d1c30: r1 = Null
    //     0x6d1c30: mov             x1, NULL
    // 0x6d1c34: b               #0x6d1c58
    // 0x6d1c38: ldr             x16, [fp, #0x10]
    // 0x6d1c3c: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1c40: ldr             x16, [fp, #0x18]
    // 0x6d1c44: SaveReg r16
    //     0x6d1c44: str             x16, [SP, #-8]!
    // 0x6d1c48: r0 = apply()
    //     0x6d1c48: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1c4c: add             SP, SP, #0x18
    // 0x6d1c50: mov             x1, x0
    // 0x6d1c54: ldr             x0, [fp, #0x28]
    // 0x6d1c58: stur            x1, [fp, #-0x28]
    // 0x6d1c5c: LoadField: r2 = r0->field_1b
    //     0x6d1c5c: ldur            w2, [x0, #0x1b]
    // 0x6d1c60: DecompressPointer r2
    //     0x6d1c60: add             x2, x2, HEAP, lsl #32
    // 0x6d1c64: cmp             w2, NULL
    // 0x6d1c68: b.ne            #0x6d1c74
    // 0x6d1c6c: r1 = Null
    //     0x6d1c6c: mov             x1, NULL
    // 0x6d1c70: b               #0x6d1c94
    // 0x6d1c74: ldr             x16, [fp, #0x20]
    // 0x6d1c78: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1c7c: ldr             x16, [fp, #0x18]
    // 0x6d1c80: SaveReg r16
    //     0x6d1c80: str             x16, [SP, #-8]!
    // 0x6d1c84: r0 = apply()
    //     0x6d1c84: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1c88: add             SP, SP, #0x18
    // 0x6d1c8c: mov             x1, x0
    // 0x6d1c90: ldr             x0, [fp, #0x28]
    // 0x6d1c94: stur            x1, [fp, #-0x30]
    // 0x6d1c98: LoadField: r2 = r0->field_1f
    //     0x6d1c98: ldur            w2, [x0, #0x1f]
    // 0x6d1c9c: DecompressPointer r2
    //     0x6d1c9c: add             x2, x2, HEAP, lsl #32
    // 0x6d1ca0: cmp             w2, NULL
    // 0x6d1ca4: b.ne            #0x6d1cb0
    // 0x6d1ca8: r1 = Null
    //     0x6d1ca8: mov             x1, NULL
    // 0x6d1cac: b               #0x6d1cd0
    // 0x6d1cb0: ldr             x16, [fp, #0x20]
    // 0x6d1cb4: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1cb8: ldr             x16, [fp, #0x18]
    // 0x6d1cbc: SaveReg r16
    //     0x6d1cbc: str             x16, [SP, #-8]!
    // 0x6d1cc0: r0 = apply()
    //     0x6d1cc0: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1cc4: add             SP, SP, #0x18
    // 0x6d1cc8: mov             x1, x0
    // 0x6d1ccc: ldr             x0, [fp, #0x28]
    // 0x6d1cd0: stur            x1, [fp, #-0x38]
    // 0x6d1cd4: LoadField: r2 = r0->field_23
    //     0x6d1cd4: ldur            w2, [x0, #0x23]
    // 0x6d1cd8: DecompressPointer r2
    //     0x6d1cd8: add             x2, x2, HEAP, lsl #32
    // 0x6d1cdc: cmp             w2, NULL
    // 0x6d1ce0: b.ne            #0x6d1cec
    // 0x6d1ce4: r1 = Null
    //     0x6d1ce4: mov             x1, NULL
    // 0x6d1ce8: b               #0x6d1d0c
    // 0x6d1cec: ldr             x16, [fp, #0x20]
    // 0x6d1cf0: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1cf4: ldr             x16, [fp, #0x18]
    // 0x6d1cf8: SaveReg r16
    //     0x6d1cf8: str             x16, [SP, #-8]!
    // 0x6d1cfc: r0 = apply()
    //     0x6d1cfc: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1d00: add             SP, SP, #0x18
    // 0x6d1d04: mov             x1, x0
    // 0x6d1d08: ldr             x0, [fp, #0x28]
    // 0x6d1d0c: stur            x1, [fp, #-0x40]
    // 0x6d1d10: LoadField: r2 = r0->field_27
    //     0x6d1d10: ldur            w2, [x0, #0x27]
    // 0x6d1d14: DecompressPointer r2
    //     0x6d1d14: add             x2, x2, HEAP, lsl #32
    // 0x6d1d18: cmp             w2, NULL
    // 0x6d1d1c: b.ne            #0x6d1d28
    // 0x6d1d20: r1 = Null
    //     0x6d1d20: mov             x1, NULL
    // 0x6d1d24: b               #0x6d1d48
    // 0x6d1d28: ldr             x16, [fp, #0x20]
    // 0x6d1d2c: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1d30: ldr             x16, [fp, #0x18]
    // 0x6d1d34: SaveReg r16
    //     0x6d1d34: str             x16, [SP, #-8]!
    // 0x6d1d38: r0 = apply()
    //     0x6d1d38: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1d3c: add             SP, SP, #0x18
    // 0x6d1d40: mov             x1, x0
    // 0x6d1d44: ldr             x0, [fp, #0x28]
    // 0x6d1d48: stur            x1, [fp, #-0x48]
    // 0x6d1d4c: LoadField: r2 = r0->field_2b
    //     0x6d1d4c: ldur            w2, [x0, #0x2b]
    // 0x6d1d50: DecompressPointer r2
    //     0x6d1d50: add             x2, x2, HEAP, lsl #32
    // 0x6d1d54: cmp             w2, NULL
    // 0x6d1d58: b.ne            #0x6d1d64
    // 0x6d1d5c: r1 = Null
    //     0x6d1d5c: mov             x1, NULL
    // 0x6d1d60: b               #0x6d1d84
    // 0x6d1d64: ldr             x16, [fp, #0x20]
    // 0x6d1d68: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1d6c: ldr             x16, [fp, #0x18]
    // 0x6d1d70: SaveReg r16
    //     0x6d1d70: str             x16, [SP, #-8]!
    // 0x6d1d74: r0 = apply()
    //     0x6d1d74: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1d78: add             SP, SP, #0x18
    // 0x6d1d7c: mov             x1, x0
    // 0x6d1d80: ldr             x0, [fp, #0x28]
    // 0x6d1d84: stur            x1, [fp, #-0x50]
    // 0x6d1d88: LoadField: r2 = r0->field_2f
    //     0x6d1d88: ldur            w2, [x0, #0x2f]
    // 0x6d1d8c: DecompressPointer r2
    //     0x6d1d8c: add             x2, x2, HEAP, lsl #32
    // 0x6d1d90: cmp             w2, NULL
    // 0x6d1d94: b.ne            #0x6d1da0
    // 0x6d1d98: r1 = Null
    //     0x6d1d98: mov             x1, NULL
    // 0x6d1d9c: b               #0x6d1dc0
    // 0x6d1da0: ldr             x16, [fp, #0x20]
    // 0x6d1da4: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1da8: ldr             x16, [fp, #0x18]
    // 0x6d1dac: SaveReg r16
    //     0x6d1dac: str             x16, [SP, #-8]!
    // 0x6d1db0: r0 = apply()
    //     0x6d1db0: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1db4: add             SP, SP, #0x18
    // 0x6d1db8: mov             x1, x0
    // 0x6d1dbc: ldr             x0, [fp, #0x28]
    // 0x6d1dc0: stur            x1, [fp, #-0x58]
    // 0x6d1dc4: LoadField: r2 = r0->field_33
    //     0x6d1dc4: ldur            w2, [x0, #0x33]
    // 0x6d1dc8: DecompressPointer r2
    //     0x6d1dc8: add             x2, x2, HEAP, lsl #32
    // 0x6d1dcc: cmp             w2, NULL
    // 0x6d1dd0: b.ne            #0x6d1ddc
    // 0x6d1dd4: r1 = Null
    //     0x6d1dd4: mov             x1, NULL
    // 0x6d1dd8: b               #0x6d1dfc
    // 0x6d1ddc: ldr             x16, [fp, #0x10]
    // 0x6d1de0: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1de4: ldr             x16, [fp, #0x18]
    // 0x6d1de8: SaveReg r16
    //     0x6d1de8: str             x16, [SP, #-8]!
    // 0x6d1dec: r0 = apply()
    //     0x6d1dec: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1df0: add             SP, SP, #0x18
    // 0x6d1df4: mov             x1, x0
    // 0x6d1df8: ldr             x0, [fp, #0x28]
    // 0x6d1dfc: stur            x1, [fp, #-0x60]
    // 0x6d1e00: LoadField: r2 = r0->field_37
    //     0x6d1e00: ldur            w2, [x0, #0x37]
    // 0x6d1e04: DecompressPointer r2
    //     0x6d1e04: add             x2, x2, HEAP, lsl #32
    // 0x6d1e08: cmp             w2, NULL
    // 0x6d1e0c: b.ne            #0x6d1e18
    // 0x6d1e10: r1 = Null
    //     0x6d1e10: mov             x1, NULL
    // 0x6d1e14: b               #0x6d1e38
    // 0x6d1e18: ldr             x16, [fp, #0x20]
    // 0x6d1e1c: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1e20: ldr             x16, [fp, #0x18]
    // 0x6d1e24: SaveReg r16
    //     0x6d1e24: str             x16, [SP, #-8]!
    // 0x6d1e28: r0 = apply()
    //     0x6d1e28: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1e2c: add             SP, SP, #0x18
    // 0x6d1e30: mov             x1, x0
    // 0x6d1e34: ldr             x0, [fp, #0x28]
    // 0x6d1e38: stur            x1, [fp, #-0x68]
    // 0x6d1e3c: LoadField: r2 = r0->field_3b
    //     0x6d1e3c: ldur            w2, [x0, #0x3b]
    // 0x6d1e40: DecompressPointer r2
    //     0x6d1e40: add             x2, x2, HEAP, lsl #32
    // 0x6d1e44: cmp             w2, NULL
    // 0x6d1e48: b.ne            #0x6d1e54
    // 0x6d1e4c: r1 = Null
    //     0x6d1e4c: mov             x1, NULL
    // 0x6d1e50: b               #0x6d1e74
    // 0x6d1e54: ldr             x16, [fp, #0x20]
    // 0x6d1e58: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1e5c: ldr             x16, [fp, #0x18]
    // 0x6d1e60: SaveReg r16
    //     0x6d1e60: str             x16, [SP, #-8]!
    // 0x6d1e64: r0 = apply()
    //     0x6d1e64: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1e68: add             SP, SP, #0x18
    // 0x6d1e6c: mov             x1, x0
    // 0x6d1e70: ldr             x0, [fp, #0x28]
    // 0x6d1e74: stur            x1, [fp, #-0x70]
    // 0x6d1e78: LoadField: r2 = r0->field_3f
    //     0x6d1e78: ldur            w2, [x0, #0x3f]
    // 0x6d1e7c: DecompressPointer r2
    //     0x6d1e7c: add             x2, x2, HEAP, lsl #32
    // 0x6d1e80: cmp             w2, NULL
    // 0x6d1e84: b.ne            #0x6d1e94
    // 0x6d1e88: mov             x0, x1
    // 0x6d1e8c: r3 = Null
    //     0x6d1e8c: mov             x3, NULL
    // 0x6d1e90: b               #0x6d1eb4
    // 0x6d1e94: ldr             x16, [fp, #0x20]
    // 0x6d1e98: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1e9c: ldr             x16, [fp, #0x18]
    // 0x6d1ea0: SaveReg r16
    //     0x6d1ea0: str             x16, [SP, #-8]!
    // 0x6d1ea4: r0 = apply()
    //     0x6d1ea4: bl              #0x6d204c  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x6d1ea8: add             SP, SP, #0x18
    // 0x6d1eac: mov             x3, x0
    // 0x6d1eb0: ldur            x0, [fp, #-0x70]
    // 0x6d1eb4: ldur            x2, [fp, #-8]
    // 0x6d1eb8: ldur            x1, [fp, #-0x20]
    // 0x6d1ebc: stur            x3, [fp, #-0x78]
    // 0x6d1ec0: r0 = TextTheme()
    //     0x6d1ec0: bl              #0x6cdfd4  ; AllocateTextThemeStub -> TextTheme (size=0x44)
    // 0x6d1ec4: ldur            x1, [fp, #-0x20]
    // 0x6d1ec8: StoreField: r0->field_13 = r1
    //     0x6d1ec8: stur            w1, [x0, #0x13]
    // 0x6d1ecc: ldur            x1, [fp, #-0x70]
    // 0x6d1ed0: StoreField: r0->field_3b = r1
    //     0x6d1ed0: stur            w1, [x0, #0x3b]
    // 0x6d1ed4: ldur            x1, [fp, #-8]
    // 0x6d1ed8: cmp             w1, NULL
    // 0x6d1edc: b.ne            #0x6d1ee8
    // 0x6d1ee0: r2 = Null
    //     0x6d1ee0: mov             x2, NULL
    // 0x6d1ee4: b               #0x6d1eec
    // 0x6d1ee8: mov             x2, x1
    // 0x6d1eec: ldur            x1, [fp, #-0x10]
    // 0x6d1ef0: StoreField: r0->field_7 = r2
    //     0x6d1ef0: stur            w2, [x0, #7]
    // 0x6d1ef4: cmp             w1, NULL
    // 0x6d1ef8: b.ne            #0x6d1f04
    // 0x6d1efc: r2 = Null
    //     0x6d1efc: mov             x2, NULL
    // 0x6d1f00: b               #0x6d1f08
    // 0x6d1f04: mov             x2, x1
    // 0x6d1f08: ldur            x1, [fp, #-0x18]
    // 0x6d1f0c: StoreField: r0->field_b = r2
    //     0x6d1f0c: stur            w2, [x0, #0xb]
    // 0x6d1f10: cmp             w1, NULL
    // 0x6d1f14: b.ne            #0x6d1f20
    // 0x6d1f18: r2 = Null
    //     0x6d1f18: mov             x2, NULL
    // 0x6d1f1c: b               #0x6d1f24
    // 0x6d1f20: mov             x2, x1
    // 0x6d1f24: ldur            x1, [fp, #-0x28]
    // 0x6d1f28: StoreField: r0->field_f = r2
    //     0x6d1f28: stur            w2, [x0, #0xf]
    // 0x6d1f2c: cmp             w1, NULL
    // 0x6d1f30: b.ne            #0x6d1f3c
    // 0x6d1f34: r2 = Null
    //     0x6d1f34: mov             x2, NULL
    // 0x6d1f38: b               #0x6d1f40
    // 0x6d1f3c: mov             x2, x1
    // 0x6d1f40: ldur            x1, [fp, #-0x30]
    // 0x6d1f44: StoreField: r0->field_17 = r2
    //     0x6d1f44: stur            w2, [x0, #0x17]
    // 0x6d1f48: cmp             w1, NULL
    // 0x6d1f4c: b.ne            #0x6d1f58
    // 0x6d1f50: r2 = Null
    //     0x6d1f50: mov             x2, NULL
    // 0x6d1f54: b               #0x6d1f5c
    // 0x6d1f58: mov             x2, x1
    // 0x6d1f5c: ldur            x1, [fp, #-0x38]
    // 0x6d1f60: StoreField: r0->field_1b = r2
    //     0x6d1f60: stur            w2, [x0, #0x1b]
    // 0x6d1f64: cmp             w1, NULL
    // 0x6d1f68: b.ne            #0x6d1f74
    // 0x6d1f6c: r2 = Null
    //     0x6d1f6c: mov             x2, NULL
    // 0x6d1f70: b               #0x6d1f78
    // 0x6d1f74: mov             x2, x1
    // 0x6d1f78: ldur            x1, [fp, #-0x40]
    // 0x6d1f7c: StoreField: r0->field_1f = r2
    //     0x6d1f7c: stur            w2, [x0, #0x1f]
    // 0x6d1f80: cmp             w1, NULL
    // 0x6d1f84: b.ne            #0x6d1f90
    // 0x6d1f88: r2 = Null
    //     0x6d1f88: mov             x2, NULL
    // 0x6d1f8c: b               #0x6d1f94
    // 0x6d1f90: mov             x2, x1
    // 0x6d1f94: ldur            x1, [fp, #-0x48]
    // 0x6d1f98: StoreField: r0->field_23 = r2
    //     0x6d1f98: stur            w2, [x0, #0x23]
    // 0x6d1f9c: cmp             w1, NULL
    // 0x6d1fa0: b.ne            #0x6d1fac
    // 0x6d1fa4: r2 = Null
    //     0x6d1fa4: mov             x2, NULL
    // 0x6d1fa8: b               #0x6d1fb0
    // 0x6d1fac: mov             x2, x1
    // 0x6d1fb0: ldur            x1, [fp, #-0x50]
    // 0x6d1fb4: StoreField: r0->field_27 = r2
    //     0x6d1fb4: stur            w2, [x0, #0x27]
    // 0x6d1fb8: cmp             w1, NULL
    // 0x6d1fbc: b.ne            #0x6d1fc8
    // 0x6d1fc0: r2 = Null
    //     0x6d1fc0: mov             x2, NULL
    // 0x6d1fc4: b               #0x6d1fcc
    // 0x6d1fc8: mov             x2, x1
    // 0x6d1fcc: ldur            x1, [fp, #-0x58]
    // 0x6d1fd0: StoreField: r0->field_2b = r2
    //     0x6d1fd0: stur            w2, [x0, #0x2b]
    // 0x6d1fd4: cmp             w1, NULL
    // 0x6d1fd8: b.ne            #0x6d1fe4
    // 0x6d1fdc: r2 = Null
    //     0x6d1fdc: mov             x2, NULL
    // 0x6d1fe0: b               #0x6d1fe8
    // 0x6d1fe4: mov             x2, x1
    // 0x6d1fe8: ldur            x1, [fp, #-0x60]
    // 0x6d1fec: StoreField: r0->field_2f = r2
    //     0x6d1fec: stur            w2, [x0, #0x2f]
    // 0x6d1ff0: cmp             w1, NULL
    // 0x6d1ff4: b.ne            #0x6d2000
    // 0x6d1ff8: r2 = Null
    //     0x6d1ff8: mov             x2, NULL
    // 0x6d1ffc: b               #0x6d2004
    // 0x6d2000: mov             x2, x1
    // 0x6d2004: ldur            x1, [fp, #-0x68]
    // 0x6d2008: StoreField: r0->field_33 = r2
    //     0x6d2008: stur            w2, [x0, #0x33]
    // 0x6d200c: cmp             w1, NULL
    // 0x6d2010: b.ne            #0x6d201c
    // 0x6d2014: r2 = Null
    //     0x6d2014: mov             x2, NULL
    // 0x6d2018: b               #0x6d2020
    // 0x6d201c: mov             x2, x1
    // 0x6d2020: ldur            x1, [fp, #-0x78]
    // 0x6d2024: StoreField: r0->field_37 = r2
    //     0x6d2024: stur            w2, [x0, #0x37]
    // 0x6d2028: cmp             w1, NULL
    // 0x6d202c: b.ne            #0x6d2034
    // 0x6d2030: r1 = Null
    //     0x6d2030: mov             x1, NULL
    // 0x6d2034: StoreField: r0->field_3f = r1
    //     0x6d2034: stur            w1, [x0, #0x3f]
    // 0x6d2038: LeaveFrame
    //     0x6d2038: mov             SP, fp
    //     0x6d203c: ldp             fp, lr, [SP], #0x10
    // 0x6d2040: ret
    //     0x6d2040: ret             
    // 0x6d2044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d2044: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d2048: b               #0x6d1b2c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb024a0, size: 0xec
    // 0xb024a0: EnterFrame
    //     0xb024a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb024a4: mov             fp, SP
    // 0xb024a8: CheckStackOverflow
    //     0xb024a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb024ac: cmp             SP, x16
    //     0xb024b0: b.ls            #0xb02584
    // 0xb024b4: ldr             x0, [fp, #0x10]
    // 0xb024b8: LoadField: r1 = r0->field_7
    //     0xb024b8: ldur            w1, [x0, #7]
    // 0xb024bc: DecompressPointer r1
    //     0xb024bc: add             x1, x1, HEAP, lsl #32
    // 0xb024c0: LoadField: r2 = r0->field_b
    //     0xb024c0: ldur            w2, [x0, #0xb]
    // 0xb024c4: DecompressPointer r2
    //     0xb024c4: add             x2, x2, HEAP, lsl #32
    // 0xb024c8: LoadField: r3 = r0->field_f
    //     0xb024c8: ldur            w3, [x0, #0xf]
    // 0xb024cc: DecompressPointer r3
    //     0xb024cc: add             x3, x3, HEAP, lsl #32
    // 0xb024d0: LoadField: r4 = r0->field_13
    //     0xb024d0: ldur            w4, [x0, #0x13]
    // 0xb024d4: DecompressPointer r4
    //     0xb024d4: add             x4, x4, HEAP, lsl #32
    // 0xb024d8: LoadField: r5 = r0->field_17
    //     0xb024d8: ldur            w5, [x0, #0x17]
    // 0xb024dc: DecompressPointer r5
    //     0xb024dc: add             x5, x5, HEAP, lsl #32
    // 0xb024e0: LoadField: r6 = r0->field_1b
    //     0xb024e0: ldur            w6, [x0, #0x1b]
    // 0xb024e4: DecompressPointer r6
    //     0xb024e4: add             x6, x6, HEAP, lsl #32
    // 0xb024e8: LoadField: r7 = r0->field_1f
    //     0xb024e8: ldur            w7, [x0, #0x1f]
    // 0xb024ec: DecompressPointer r7
    //     0xb024ec: add             x7, x7, HEAP, lsl #32
    // 0xb024f0: LoadField: r8 = r0->field_23
    //     0xb024f0: ldur            w8, [x0, #0x23]
    // 0xb024f4: DecompressPointer r8
    //     0xb024f4: add             x8, x8, HEAP, lsl #32
    // 0xb024f8: LoadField: r9 = r0->field_27
    //     0xb024f8: ldur            w9, [x0, #0x27]
    // 0xb024fc: DecompressPointer r9
    //     0xb024fc: add             x9, x9, HEAP, lsl #32
    // 0xb02500: LoadField: r10 = r0->field_2b
    //     0xb02500: ldur            w10, [x0, #0x2b]
    // 0xb02504: DecompressPointer r10
    //     0xb02504: add             x10, x10, HEAP, lsl #32
    // 0xb02508: LoadField: r11 = r0->field_2f
    //     0xb02508: ldur            w11, [x0, #0x2f]
    // 0xb0250c: DecompressPointer r11
    //     0xb0250c: add             x11, x11, HEAP, lsl #32
    // 0xb02510: LoadField: r12 = r0->field_33
    //     0xb02510: ldur            w12, [x0, #0x33]
    // 0xb02514: DecompressPointer r12
    //     0xb02514: add             x12, x12, HEAP, lsl #32
    // 0xb02518: LoadField: r13 = r0->field_37
    //     0xb02518: ldur            w13, [x0, #0x37]
    // 0xb0251c: DecompressPointer r13
    //     0xb0251c: add             x13, x13, HEAP, lsl #32
    // 0xb02520: LoadField: r14 = r0->field_3b
    //     0xb02520: ldur            w14, [x0, #0x3b]
    // 0xb02524: DecompressPointer r14
    //     0xb02524: add             x14, x14, HEAP, lsl #32
    // 0xb02528: LoadField: r19 = r0->field_3f
    //     0xb02528: ldur            w19, [x0, #0x3f]
    // 0xb0252c: DecompressPointer r19
    //     0xb0252c: add             x19, x19, HEAP, lsl #32
    // 0xb02530: stp             x2, x1, [SP, #-0x10]!
    // 0xb02534: stp             x4, x3, [SP, #-0x10]!
    // 0xb02538: stp             x6, x5, [SP, #-0x10]!
    // 0xb0253c: stp             x8, x7, [SP, #-0x10]!
    // 0xb02540: stp             x10, x9, [SP, #-0x10]!
    // 0xb02544: stp             x12, x11, [SP, #-0x10]!
    // 0xb02548: stp             x14, x13, [SP, #-0x10]!
    // 0xb0254c: SaveReg r19
    //     0xb0254c: str             x19, [SP, #-8]!
    // 0xb02550: r4 = const [0, 0xf, 0xf, 0xf, null]
    //     0xb02550: add             x4, PP, #0xd, lsl #12  ; [pp+0xdef0] List(5) [0, 0xf, 0xf, 0xf, Null]
    //     0xb02554: ldr             x4, [x4, #0xef0]
    // 0xb02558: r0 = hash()
    //     0xb02558: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0255c: add             SP, SP, #0x78
    // 0xb02560: mov             x2, x0
    // 0xb02564: r0 = BoxInt64Instr(r2)
    //     0xb02564: sbfiz           x0, x2, #1, #0x1f
    //     0xb02568: cmp             x2, x0, asr #1
    //     0xb0256c: b.eq            #0xb02578
    //     0xb02570: bl              #0xd69bb8
    //     0xb02574: stur            x2, [x0, #7]
    // 0xb02578: LeaveFrame
    //     0xb02578: mov             SP, fp
    //     0xb0257c: ldp             fp, lr, [SP], #0x10
    // 0xb02580: ret
    //     0xb02580: ret             
    // 0xb02584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb02584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb02588: b               #0xb024b4
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf6594, size: 0x720
    // 0xbf6594: EnterFrame
    //     0xbf6594: stp             fp, lr, [SP, #-0x10]!
    //     0xbf6598: mov             fp, SP
    // 0xbf659c: AllocStack(0x78)
    //     0xbf659c: sub             SP, SP, #0x78
    // 0xbf65a0: CheckStackOverflow
    //     0xbf65a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf65a4: cmp             SP, x16
    //     0xbf65a8: b.ls            #0xbf6c88
    // 0xbf65ac: ldr             x0, [fp, #0x20]
    // 0xbf65b0: cmp             w0, NULL
    // 0xbf65b4: b.ne            #0xbf65c0
    // 0xbf65b8: r2 = Null
    //     0xbf65b8: mov             x2, NULL
    // 0xbf65bc: b               #0xbf65cc
    // 0xbf65c0: LoadField: r1 = r0->field_7
    //     0xbf65c0: ldur            w1, [x0, #7]
    // 0xbf65c4: DecompressPointer r1
    //     0xbf65c4: add             x1, x1, HEAP, lsl #32
    // 0xbf65c8: mov             x2, x1
    // 0xbf65cc: ldr             x1, [fp, #0x18]
    // 0xbf65d0: cmp             w1, NULL
    // 0xbf65d4: b.ne            #0xbf65e0
    // 0xbf65d8: r3 = Null
    //     0xbf65d8: mov             x3, NULL
    // 0xbf65dc: b               #0xbf65e8
    // 0xbf65e0: LoadField: r3 = r1->field_7
    //     0xbf65e0: ldur            w3, [x1, #7]
    // 0xbf65e4: DecompressPointer r3
    //     0xbf65e4: add             x3, x3, HEAP, lsl #32
    // 0xbf65e8: ldr             d0, [fp, #0x10]
    // 0xbf65ec: r4 = inline_Allocate_Double()
    //     0xbf65ec: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf65f0: add             x4, x4, #0x10
    //     0xbf65f4: cmp             x5, x4
    //     0xbf65f8: b.ls            #0xbf6c90
    //     0xbf65fc: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf6600: sub             x4, x4, #0xf
    //     0xbf6604: mov             x5, #0xd108
    //     0xbf6608: movk            x5, #3, lsl #16
    //     0xbf660c: stur            x5, [x4, #-1]
    // 0xbf6610: StoreField: r4->field_7 = d0
    //     0xbf6610: stur            d0, [x4, #7]
    // 0xbf6614: stur            x4, [fp, #-8]
    // 0xbf6618: stp             x3, x2, [SP, #-0x10]!
    // 0xbf661c: SaveReg r4
    //     0xbf661c: str             x4, [SP, #-8]!
    // 0xbf6620: r0 = lerp()
    //     0xbf6620: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf6624: add             SP, SP, #0x18
    // 0xbf6628: mov             x1, x0
    // 0xbf662c: ldr             x0, [fp, #0x20]
    // 0xbf6630: stur            x1, [fp, #-0x10]
    // 0xbf6634: cmp             w0, NULL
    // 0xbf6638: b.ne            #0xbf6644
    // 0xbf663c: r3 = Null
    //     0xbf663c: mov             x3, NULL
    // 0xbf6640: b               #0xbf6650
    // 0xbf6644: LoadField: r2 = r0->field_b
    //     0xbf6644: ldur            w2, [x0, #0xb]
    // 0xbf6648: DecompressPointer r2
    //     0xbf6648: add             x2, x2, HEAP, lsl #32
    // 0xbf664c: mov             x3, x2
    // 0xbf6650: ldr             x2, [fp, #0x18]
    // 0xbf6654: cmp             w2, NULL
    // 0xbf6658: b.ne            #0xbf6664
    // 0xbf665c: r4 = Null
    //     0xbf665c: mov             x4, NULL
    // 0xbf6660: b               #0xbf666c
    // 0xbf6664: LoadField: r4 = r2->field_b
    //     0xbf6664: ldur            w4, [x2, #0xb]
    // 0xbf6668: DecompressPointer r4
    //     0xbf6668: add             x4, x4, HEAP, lsl #32
    // 0xbf666c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6670: ldur            x16, [fp, #-8]
    // 0xbf6674: SaveReg r16
    //     0xbf6674: str             x16, [SP, #-8]!
    // 0xbf6678: r0 = lerp()
    //     0xbf6678: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf667c: add             SP, SP, #0x18
    // 0xbf6680: mov             x1, x0
    // 0xbf6684: ldr             x0, [fp, #0x20]
    // 0xbf6688: stur            x1, [fp, #-0x18]
    // 0xbf668c: cmp             w0, NULL
    // 0xbf6690: b.ne            #0xbf669c
    // 0xbf6694: r3 = Null
    //     0xbf6694: mov             x3, NULL
    // 0xbf6698: b               #0xbf66a8
    // 0xbf669c: LoadField: r2 = r0->field_f
    //     0xbf669c: ldur            w2, [x0, #0xf]
    // 0xbf66a0: DecompressPointer r2
    //     0xbf66a0: add             x2, x2, HEAP, lsl #32
    // 0xbf66a4: mov             x3, x2
    // 0xbf66a8: ldr             x2, [fp, #0x18]
    // 0xbf66ac: cmp             w2, NULL
    // 0xbf66b0: b.ne            #0xbf66bc
    // 0xbf66b4: r4 = Null
    //     0xbf66b4: mov             x4, NULL
    // 0xbf66b8: b               #0xbf66c4
    // 0xbf66bc: LoadField: r4 = r2->field_f
    //     0xbf66bc: ldur            w4, [x2, #0xf]
    // 0xbf66c0: DecompressPointer r4
    //     0xbf66c0: add             x4, x4, HEAP, lsl #32
    // 0xbf66c4: stp             x4, x3, [SP, #-0x10]!
    // 0xbf66c8: ldur            x16, [fp, #-8]
    // 0xbf66cc: SaveReg r16
    //     0xbf66cc: str             x16, [SP, #-8]!
    // 0xbf66d0: r0 = lerp()
    //     0xbf66d0: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf66d4: add             SP, SP, #0x18
    // 0xbf66d8: mov             x1, x0
    // 0xbf66dc: ldr             x0, [fp, #0x20]
    // 0xbf66e0: stur            x1, [fp, #-0x20]
    // 0xbf66e4: cmp             w0, NULL
    // 0xbf66e8: b.ne            #0xbf66f4
    // 0xbf66ec: r3 = Null
    //     0xbf66ec: mov             x3, NULL
    // 0xbf66f0: b               #0xbf6700
    // 0xbf66f4: LoadField: r2 = r0->field_13
    //     0xbf66f4: ldur            w2, [x0, #0x13]
    // 0xbf66f8: DecompressPointer r2
    //     0xbf66f8: add             x2, x2, HEAP, lsl #32
    // 0xbf66fc: mov             x3, x2
    // 0xbf6700: ldr             x2, [fp, #0x18]
    // 0xbf6704: cmp             w2, NULL
    // 0xbf6708: b.ne            #0xbf6714
    // 0xbf670c: r4 = Null
    //     0xbf670c: mov             x4, NULL
    // 0xbf6710: b               #0xbf671c
    // 0xbf6714: LoadField: r4 = r2->field_13
    //     0xbf6714: ldur            w4, [x2, #0x13]
    // 0xbf6718: DecompressPointer r4
    //     0xbf6718: add             x4, x4, HEAP, lsl #32
    // 0xbf671c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6720: ldur            x16, [fp, #-8]
    // 0xbf6724: SaveReg r16
    //     0xbf6724: str             x16, [SP, #-8]!
    // 0xbf6728: r0 = lerp()
    //     0xbf6728: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf672c: add             SP, SP, #0x18
    // 0xbf6730: mov             x1, x0
    // 0xbf6734: ldr             x0, [fp, #0x20]
    // 0xbf6738: stur            x1, [fp, #-0x28]
    // 0xbf673c: cmp             w0, NULL
    // 0xbf6740: b.ne            #0xbf674c
    // 0xbf6744: r3 = Null
    //     0xbf6744: mov             x3, NULL
    // 0xbf6748: b               #0xbf6758
    // 0xbf674c: LoadField: r2 = r0->field_17
    //     0xbf674c: ldur            w2, [x0, #0x17]
    // 0xbf6750: DecompressPointer r2
    //     0xbf6750: add             x2, x2, HEAP, lsl #32
    // 0xbf6754: mov             x3, x2
    // 0xbf6758: ldr             x2, [fp, #0x18]
    // 0xbf675c: cmp             w2, NULL
    // 0xbf6760: b.ne            #0xbf676c
    // 0xbf6764: r4 = Null
    //     0xbf6764: mov             x4, NULL
    // 0xbf6768: b               #0xbf6774
    // 0xbf676c: LoadField: r4 = r2->field_17
    //     0xbf676c: ldur            w4, [x2, #0x17]
    // 0xbf6770: DecompressPointer r4
    //     0xbf6770: add             x4, x4, HEAP, lsl #32
    // 0xbf6774: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6778: ldur            x16, [fp, #-8]
    // 0xbf677c: SaveReg r16
    //     0xbf677c: str             x16, [SP, #-8]!
    // 0xbf6780: r0 = lerp()
    //     0xbf6780: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf6784: add             SP, SP, #0x18
    // 0xbf6788: mov             x1, x0
    // 0xbf678c: ldr             x0, [fp, #0x20]
    // 0xbf6790: stur            x1, [fp, #-0x30]
    // 0xbf6794: cmp             w0, NULL
    // 0xbf6798: b.ne            #0xbf67a4
    // 0xbf679c: r3 = Null
    //     0xbf679c: mov             x3, NULL
    // 0xbf67a0: b               #0xbf67b0
    // 0xbf67a4: LoadField: r2 = r0->field_1b
    //     0xbf67a4: ldur            w2, [x0, #0x1b]
    // 0xbf67a8: DecompressPointer r2
    //     0xbf67a8: add             x2, x2, HEAP, lsl #32
    // 0xbf67ac: mov             x3, x2
    // 0xbf67b0: ldr             x2, [fp, #0x18]
    // 0xbf67b4: cmp             w2, NULL
    // 0xbf67b8: b.ne            #0xbf67c4
    // 0xbf67bc: r4 = Null
    //     0xbf67bc: mov             x4, NULL
    // 0xbf67c0: b               #0xbf67cc
    // 0xbf67c4: LoadField: r4 = r2->field_1b
    //     0xbf67c4: ldur            w4, [x2, #0x1b]
    // 0xbf67c8: DecompressPointer r4
    //     0xbf67c8: add             x4, x4, HEAP, lsl #32
    // 0xbf67cc: stp             x4, x3, [SP, #-0x10]!
    // 0xbf67d0: ldur            x16, [fp, #-8]
    // 0xbf67d4: SaveReg r16
    //     0xbf67d4: str             x16, [SP, #-8]!
    // 0xbf67d8: r0 = lerp()
    //     0xbf67d8: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf67dc: add             SP, SP, #0x18
    // 0xbf67e0: mov             x1, x0
    // 0xbf67e4: ldr             x0, [fp, #0x20]
    // 0xbf67e8: stur            x1, [fp, #-0x38]
    // 0xbf67ec: cmp             w0, NULL
    // 0xbf67f0: b.ne            #0xbf67fc
    // 0xbf67f4: r3 = Null
    //     0xbf67f4: mov             x3, NULL
    // 0xbf67f8: b               #0xbf6808
    // 0xbf67fc: LoadField: r2 = r0->field_1f
    //     0xbf67fc: ldur            w2, [x0, #0x1f]
    // 0xbf6800: DecompressPointer r2
    //     0xbf6800: add             x2, x2, HEAP, lsl #32
    // 0xbf6804: mov             x3, x2
    // 0xbf6808: ldr             x2, [fp, #0x18]
    // 0xbf680c: cmp             w2, NULL
    // 0xbf6810: b.ne            #0xbf681c
    // 0xbf6814: r4 = Null
    //     0xbf6814: mov             x4, NULL
    // 0xbf6818: b               #0xbf6824
    // 0xbf681c: LoadField: r4 = r2->field_1f
    //     0xbf681c: ldur            w4, [x2, #0x1f]
    // 0xbf6820: DecompressPointer r4
    //     0xbf6820: add             x4, x4, HEAP, lsl #32
    // 0xbf6824: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6828: ldur            x16, [fp, #-8]
    // 0xbf682c: SaveReg r16
    //     0xbf682c: str             x16, [SP, #-8]!
    // 0xbf6830: r0 = lerp()
    //     0xbf6830: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf6834: add             SP, SP, #0x18
    // 0xbf6838: mov             x1, x0
    // 0xbf683c: ldr             x0, [fp, #0x20]
    // 0xbf6840: stur            x1, [fp, #-0x40]
    // 0xbf6844: cmp             w0, NULL
    // 0xbf6848: b.ne            #0xbf6854
    // 0xbf684c: r3 = Null
    //     0xbf684c: mov             x3, NULL
    // 0xbf6850: b               #0xbf6860
    // 0xbf6854: LoadField: r2 = r0->field_23
    //     0xbf6854: ldur            w2, [x0, #0x23]
    // 0xbf6858: DecompressPointer r2
    //     0xbf6858: add             x2, x2, HEAP, lsl #32
    // 0xbf685c: mov             x3, x2
    // 0xbf6860: ldr             x2, [fp, #0x18]
    // 0xbf6864: cmp             w2, NULL
    // 0xbf6868: b.ne            #0xbf6874
    // 0xbf686c: r4 = Null
    //     0xbf686c: mov             x4, NULL
    // 0xbf6870: b               #0xbf687c
    // 0xbf6874: LoadField: r4 = r2->field_23
    //     0xbf6874: ldur            w4, [x2, #0x23]
    // 0xbf6878: DecompressPointer r4
    //     0xbf6878: add             x4, x4, HEAP, lsl #32
    // 0xbf687c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6880: ldur            x16, [fp, #-8]
    // 0xbf6884: SaveReg r16
    //     0xbf6884: str             x16, [SP, #-8]!
    // 0xbf6888: r0 = lerp()
    //     0xbf6888: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf688c: add             SP, SP, #0x18
    // 0xbf6890: mov             x1, x0
    // 0xbf6894: ldr             x0, [fp, #0x20]
    // 0xbf6898: stur            x1, [fp, #-0x48]
    // 0xbf689c: cmp             w0, NULL
    // 0xbf68a0: b.ne            #0xbf68ac
    // 0xbf68a4: r3 = Null
    //     0xbf68a4: mov             x3, NULL
    // 0xbf68a8: b               #0xbf68b8
    // 0xbf68ac: LoadField: r2 = r0->field_27
    //     0xbf68ac: ldur            w2, [x0, #0x27]
    // 0xbf68b0: DecompressPointer r2
    //     0xbf68b0: add             x2, x2, HEAP, lsl #32
    // 0xbf68b4: mov             x3, x2
    // 0xbf68b8: ldr             x2, [fp, #0x18]
    // 0xbf68bc: cmp             w2, NULL
    // 0xbf68c0: b.ne            #0xbf68cc
    // 0xbf68c4: r4 = Null
    //     0xbf68c4: mov             x4, NULL
    // 0xbf68c8: b               #0xbf68d4
    // 0xbf68cc: LoadField: r4 = r2->field_27
    //     0xbf68cc: ldur            w4, [x2, #0x27]
    // 0xbf68d0: DecompressPointer r4
    //     0xbf68d0: add             x4, x4, HEAP, lsl #32
    // 0xbf68d4: stp             x4, x3, [SP, #-0x10]!
    // 0xbf68d8: ldur            x16, [fp, #-8]
    // 0xbf68dc: SaveReg r16
    //     0xbf68dc: str             x16, [SP, #-8]!
    // 0xbf68e0: r0 = lerp()
    //     0xbf68e0: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf68e4: add             SP, SP, #0x18
    // 0xbf68e8: mov             x1, x0
    // 0xbf68ec: ldr             x0, [fp, #0x20]
    // 0xbf68f0: stur            x1, [fp, #-0x50]
    // 0xbf68f4: cmp             w0, NULL
    // 0xbf68f8: b.ne            #0xbf6904
    // 0xbf68fc: r3 = Null
    //     0xbf68fc: mov             x3, NULL
    // 0xbf6900: b               #0xbf6910
    // 0xbf6904: LoadField: r2 = r0->field_2b
    //     0xbf6904: ldur            w2, [x0, #0x2b]
    // 0xbf6908: DecompressPointer r2
    //     0xbf6908: add             x2, x2, HEAP, lsl #32
    // 0xbf690c: mov             x3, x2
    // 0xbf6910: ldr             x2, [fp, #0x18]
    // 0xbf6914: cmp             w2, NULL
    // 0xbf6918: b.ne            #0xbf6924
    // 0xbf691c: r4 = Null
    //     0xbf691c: mov             x4, NULL
    // 0xbf6920: b               #0xbf692c
    // 0xbf6924: LoadField: r4 = r2->field_2b
    //     0xbf6924: ldur            w4, [x2, #0x2b]
    // 0xbf6928: DecompressPointer r4
    //     0xbf6928: add             x4, x4, HEAP, lsl #32
    // 0xbf692c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6930: ldur            x16, [fp, #-8]
    // 0xbf6934: SaveReg r16
    //     0xbf6934: str             x16, [SP, #-8]!
    // 0xbf6938: r0 = lerp()
    //     0xbf6938: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf693c: add             SP, SP, #0x18
    // 0xbf6940: mov             x1, x0
    // 0xbf6944: ldr             x0, [fp, #0x20]
    // 0xbf6948: stur            x1, [fp, #-0x58]
    // 0xbf694c: cmp             w0, NULL
    // 0xbf6950: b.ne            #0xbf695c
    // 0xbf6954: r3 = Null
    //     0xbf6954: mov             x3, NULL
    // 0xbf6958: b               #0xbf6968
    // 0xbf695c: LoadField: r2 = r0->field_2f
    //     0xbf695c: ldur            w2, [x0, #0x2f]
    // 0xbf6960: DecompressPointer r2
    //     0xbf6960: add             x2, x2, HEAP, lsl #32
    // 0xbf6964: mov             x3, x2
    // 0xbf6968: ldr             x2, [fp, #0x18]
    // 0xbf696c: cmp             w2, NULL
    // 0xbf6970: b.ne            #0xbf697c
    // 0xbf6974: r4 = Null
    //     0xbf6974: mov             x4, NULL
    // 0xbf6978: b               #0xbf6984
    // 0xbf697c: LoadField: r4 = r2->field_2f
    //     0xbf697c: ldur            w4, [x2, #0x2f]
    // 0xbf6980: DecompressPointer r4
    //     0xbf6980: add             x4, x4, HEAP, lsl #32
    // 0xbf6984: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6988: ldur            x16, [fp, #-8]
    // 0xbf698c: SaveReg r16
    //     0xbf698c: str             x16, [SP, #-8]!
    // 0xbf6990: r0 = lerp()
    //     0xbf6990: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf6994: add             SP, SP, #0x18
    // 0xbf6998: mov             x1, x0
    // 0xbf699c: ldr             x0, [fp, #0x20]
    // 0xbf69a0: stur            x1, [fp, #-0x60]
    // 0xbf69a4: cmp             w0, NULL
    // 0xbf69a8: b.ne            #0xbf69b4
    // 0xbf69ac: r3 = Null
    //     0xbf69ac: mov             x3, NULL
    // 0xbf69b0: b               #0xbf69c0
    // 0xbf69b4: LoadField: r2 = r0->field_33
    //     0xbf69b4: ldur            w2, [x0, #0x33]
    // 0xbf69b8: DecompressPointer r2
    //     0xbf69b8: add             x2, x2, HEAP, lsl #32
    // 0xbf69bc: mov             x3, x2
    // 0xbf69c0: ldr             x2, [fp, #0x18]
    // 0xbf69c4: cmp             w2, NULL
    // 0xbf69c8: b.ne            #0xbf69d4
    // 0xbf69cc: r4 = Null
    //     0xbf69cc: mov             x4, NULL
    // 0xbf69d0: b               #0xbf69dc
    // 0xbf69d4: LoadField: r4 = r2->field_33
    //     0xbf69d4: ldur            w4, [x2, #0x33]
    // 0xbf69d8: DecompressPointer r4
    //     0xbf69d8: add             x4, x4, HEAP, lsl #32
    // 0xbf69dc: stp             x4, x3, [SP, #-0x10]!
    // 0xbf69e0: ldur            x16, [fp, #-8]
    // 0xbf69e4: SaveReg r16
    //     0xbf69e4: str             x16, [SP, #-8]!
    // 0xbf69e8: r0 = lerp()
    //     0xbf69e8: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf69ec: add             SP, SP, #0x18
    // 0xbf69f0: mov             x1, x0
    // 0xbf69f4: ldr             x0, [fp, #0x20]
    // 0xbf69f8: stur            x1, [fp, #-0x68]
    // 0xbf69fc: cmp             w0, NULL
    // 0xbf6a00: b.ne            #0xbf6a0c
    // 0xbf6a04: r3 = Null
    //     0xbf6a04: mov             x3, NULL
    // 0xbf6a08: b               #0xbf6a18
    // 0xbf6a0c: LoadField: r2 = r0->field_37
    //     0xbf6a0c: ldur            w2, [x0, #0x37]
    // 0xbf6a10: DecompressPointer r2
    //     0xbf6a10: add             x2, x2, HEAP, lsl #32
    // 0xbf6a14: mov             x3, x2
    // 0xbf6a18: ldr             x2, [fp, #0x18]
    // 0xbf6a1c: cmp             w2, NULL
    // 0xbf6a20: b.ne            #0xbf6a2c
    // 0xbf6a24: r4 = Null
    //     0xbf6a24: mov             x4, NULL
    // 0xbf6a28: b               #0xbf6a34
    // 0xbf6a2c: LoadField: r4 = r2->field_37
    //     0xbf6a2c: ldur            w4, [x2, #0x37]
    // 0xbf6a30: DecompressPointer r4
    //     0xbf6a30: add             x4, x4, HEAP, lsl #32
    // 0xbf6a34: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6a38: ldur            x16, [fp, #-8]
    // 0xbf6a3c: SaveReg r16
    //     0xbf6a3c: str             x16, [SP, #-8]!
    // 0xbf6a40: r0 = lerp()
    //     0xbf6a40: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf6a44: add             SP, SP, #0x18
    // 0xbf6a48: mov             x1, x0
    // 0xbf6a4c: ldr             x0, [fp, #0x20]
    // 0xbf6a50: stur            x1, [fp, #-0x70]
    // 0xbf6a54: cmp             w0, NULL
    // 0xbf6a58: b.ne            #0xbf6a64
    // 0xbf6a5c: r3 = Null
    //     0xbf6a5c: mov             x3, NULL
    // 0xbf6a60: b               #0xbf6a70
    // 0xbf6a64: LoadField: r2 = r0->field_3b
    //     0xbf6a64: ldur            w2, [x0, #0x3b]
    // 0xbf6a68: DecompressPointer r2
    //     0xbf6a68: add             x2, x2, HEAP, lsl #32
    // 0xbf6a6c: mov             x3, x2
    // 0xbf6a70: ldr             x2, [fp, #0x18]
    // 0xbf6a74: cmp             w2, NULL
    // 0xbf6a78: b.ne            #0xbf6a84
    // 0xbf6a7c: r4 = Null
    //     0xbf6a7c: mov             x4, NULL
    // 0xbf6a80: b               #0xbf6a8c
    // 0xbf6a84: LoadField: r4 = r2->field_3b
    //     0xbf6a84: ldur            w4, [x2, #0x3b]
    // 0xbf6a88: DecompressPointer r4
    //     0xbf6a88: add             x4, x4, HEAP, lsl #32
    // 0xbf6a8c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf6a90: ldur            x16, [fp, #-8]
    // 0xbf6a94: SaveReg r16
    //     0xbf6a94: str             x16, [SP, #-8]!
    // 0xbf6a98: r0 = lerp()
    //     0xbf6a98: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf6a9c: add             SP, SP, #0x18
    // 0xbf6aa0: mov             x1, x0
    // 0xbf6aa4: ldr             x0, [fp, #0x20]
    // 0xbf6aa8: stur            x1, [fp, #-0x78]
    // 0xbf6aac: cmp             w0, NULL
    // 0xbf6ab0: b.ne            #0xbf6abc
    // 0xbf6ab4: r2 = Null
    //     0xbf6ab4: mov             x2, NULL
    // 0xbf6ab8: b               #0xbf6ac4
    // 0xbf6abc: LoadField: r2 = r0->field_3f
    //     0xbf6abc: ldur            w2, [x0, #0x3f]
    // 0xbf6ac0: DecompressPointer r2
    //     0xbf6ac0: add             x2, x2, HEAP, lsl #32
    // 0xbf6ac4: ldr             x0, [fp, #0x18]
    // 0xbf6ac8: cmp             w0, NULL
    // 0xbf6acc: b.ne            #0xbf6ad8
    // 0xbf6ad0: r4 = Null
    //     0xbf6ad0: mov             x4, NULL
    // 0xbf6ad4: b               #0xbf6ae4
    // 0xbf6ad8: LoadField: r3 = r0->field_3f
    //     0xbf6ad8: ldur            w3, [x0, #0x3f]
    // 0xbf6adc: DecompressPointer r3
    //     0xbf6adc: add             x3, x3, HEAP, lsl #32
    // 0xbf6ae0: mov             x4, x3
    // 0xbf6ae4: ldur            x3, [fp, #-0x10]
    // 0xbf6ae8: ldur            x0, [fp, #-0x28]
    // 0xbf6aec: stp             x4, x2, [SP, #-0x10]!
    // 0xbf6af0: ldur            x16, [fp, #-8]
    // 0xbf6af4: SaveReg r16
    //     0xbf6af4: str             x16, [SP, #-8]!
    // 0xbf6af8: r0 = lerp()
    //     0xbf6af8: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf6afc: add             SP, SP, #0x18
    // 0xbf6b00: stur            x0, [fp, #-8]
    // 0xbf6b04: r0 = TextTheme()
    //     0xbf6b04: bl              #0x6cdfd4  ; AllocateTextThemeStub -> TextTheme (size=0x44)
    // 0xbf6b08: ldur            x1, [fp, #-0x28]
    // 0xbf6b0c: StoreField: r0->field_13 = r1
    //     0xbf6b0c: stur            w1, [x0, #0x13]
    // 0xbf6b10: ldur            x1, [fp, #-0x78]
    // 0xbf6b14: StoreField: r0->field_3b = r1
    //     0xbf6b14: stur            w1, [x0, #0x3b]
    // 0xbf6b18: ldur            x1, [fp, #-0x10]
    // 0xbf6b1c: cmp             w1, NULL
    // 0xbf6b20: b.ne            #0xbf6b2c
    // 0xbf6b24: r2 = Null
    //     0xbf6b24: mov             x2, NULL
    // 0xbf6b28: b               #0xbf6b30
    // 0xbf6b2c: mov             x2, x1
    // 0xbf6b30: ldur            x1, [fp, #-0x18]
    // 0xbf6b34: StoreField: r0->field_7 = r2
    //     0xbf6b34: stur            w2, [x0, #7]
    // 0xbf6b38: cmp             w1, NULL
    // 0xbf6b3c: b.ne            #0xbf6b48
    // 0xbf6b40: r2 = Null
    //     0xbf6b40: mov             x2, NULL
    // 0xbf6b44: b               #0xbf6b4c
    // 0xbf6b48: mov             x2, x1
    // 0xbf6b4c: ldur            x1, [fp, #-0x20]
    // 0xbf6b50: StoreField: r0->field_b = r2
    //     0xbf6b50: stur            w2, [x0, #0xb]
    // 0xbf6b54: cmp             w1, NULL
    // 0xbf6b58: b.ne            #0xbf6b64
    // 0xbf6b5c: r2 = Null
    //     0xbf6b5c: mov             x2, NULL
    // 0xbf6b60: b               #0xbf6b68
    // 0xbf6b64: mov             x2, x1
    // 0xbf6b68: ldur            x1, [fp, #-0x30]
    // 0xbf6b6c: StoreField: r0->field_f = r2
    //     0xbf6b6c: stur            w2, [x0, #0xf]
    // 0xbf6b70: cmp             w1, NULL
    // 0xbf6b74: b.ne            #0xbf6b80
    // 0xbf6b78: r2 = Null
    //     0xbf6b78: mov             x2, NULL
    // 0xbf6b7c: b               #0xbf6b84
    // 0xbf6b80: mov             x2, x1
    // 0xbf6b84: ldur            x1, [fp, #-0x38]
    // 0xbf6b88: StoreField: r0->field_17 = r2
    //     0xbf6b88: stur            w2, [x0, #0x17]
    // 0xbf6b8c: cmp             w1, NULL
    // 0xbf6b90: b.ne            #0xbf6b9c
    // 0xbf6b94: r2 = Null
    //     0xbf6b94: mov             x2, NULL
    // 0xbf6b98: b               #0xbf6ba0
    // 0xbf6b9c: mov             x2, x1
    // 0xbf6ba0: ldur            x1, [fp, #-0x40]
    // 0xbf6ba4: StoreField: r0->field_1b = r2
    //     0xbf6ba4: stur            w2, [x0, #0x1b]
    // 0xbf6ba8: cmp             w1, NULL
    // 0xbf6bac: b.ne            #0xbf6bb8
    // 0xbf6bb0: r2 = Null
    //     0xbf6bb0: mov             x2, NULL
    // 0xbf6bb4: b               #0xbf6bbc
    // 0xbf6bb8: mov             x2, x1
    // 0xbf6bbc: ldur            x1, [fp, #-0x48]
    // 0xbf6bc0: StoreField: r0->field_1f = r2
    //     0xbf6bc0: stur            w2, [x0, #0x1f]
    // 0xbf6bc4: cmp             w1, NULL
    // 0xbf6bc8: b.ne            #0xbf6bd4
    // 0xbf6bcc: r2 = Null
    //     0xbf6bcc: mov             x2, NULL
    // 0xbf6bd0: b               #0xbf6bd8
    // 0xbf6bd4: mov             x2, x1
    // 0xbf6bd8: ldur            x1, [fp, #-0x50]
    // 0xbf6bdc: StoreField: r0->field_23 = r2
    //     0xbf6bdc: stur            w2, [x0, #0x23]
    // 0xbf6be0: cmp             w1, NULL
    // 0xbf6be4: b.ne            #0xbf6bf0
    // 0xbf6be8: r2 = Null
    //     0xbf6be8: mov             x2, NULL
    // 0xbf6bec: b               #0xbf6bf4
    // 0xbf6bf0: mov             x2, x1
    // 0xbf6bf4: ldur            x1, [fp, #-0x58]
    // 0xbf6bf8: StoreField: r0->field_27 = r2
    //     0xbf6bf8: stur            w2, [x0, #0x27]
    // 0xbf6bfc: cmp             w1, NULL
    // 0xbf6c00: b.ne            #0xbf6c0c
    // 0xbf6c04: r2 = Null
    //     0xbf6c04: mov             x2, NULL
    // 0xbf6c08: b               #0xbf6c10
    // 0xbf6c0c: mov             x2, x1
    // 0xbf6c10: ldur            x1, [fp, #-0x60]
    // 0xbf6c14: StoreField: r0->field_2b = r2
    //     0xbf6c14: stur            w2, [x0, #0x2b]
    // 0xbf6c18: cmp             w1, NULL
    // 0xbf6c1c: b.ne            #0xbf6c28
    // 0xbf6c20: r2 = Null
    //     0xbf6c20: mov             x2, NULL
    // 0xbf6c24: b               #0xbf6c2c
    // 0xbf6c28: mov             x2, x1
    // 0xbf6c2c: ldur            x1, [fp, #-0x68]
    // 0xbf6c30: StoreField: r0->field_2f = r2
    //     0xbf6c30: stur            w2, [x0, #0x2f]
    // 0xbf6c34: cmp             w1, NULL
    // 0xbf6c38: b.ne            #0xbf6c44
    // 0xbf6c3c: r2 = Null
    //     0xbf6c3c: mov             x2, NULL
    // 0xbf6c40: b               #0xbf6c48
    // 0xbf6c44: mov             x2, x1
    // 0xbf6c48: ldur            x1, [fp, #-0x70]
    // 0xbf6c4c: StoreField: r0->field_33 = r2
    //     0xbf6c4c: stur            w2, [x0, #0x33]
    // 0xbf6c50: cmp             w1, NULL
    // 0xbf6c54: b.ne            #0xbf6c60
    // 0xbf6c58: r2 = Null
    //     0xbf6c58: mov             x2, NULL
    // 0xbf6c5c: b               #0xbf6c64
    // 0xbf6c60: mov             x2, x1
    // 0xbf6c64: ldur            x1, [fp, #-8]
    // 0xbf6c68: StoreField: r0->field_37 = r2
    //     0xbf6c68: stur            w2, [x0, #0x37]
    // 0xbf6c6c: cmp             w1, NULL
    // 0xbf6c70: b.ne            #0xbf6c78
    // 0xbf6c74: r1 = Null
    //     0xbf6c74: mov             x1, NULL
    // 0xbf6c78: StoreField: r0->field_3f = r1
    //     0xbf6c78: stur            w1, [x0, #0x3f]
    // 0xbf6c7c: LeaveFrame
    //     0xbf6c7c: mov             SP, fp
    //     0xbf6c80: ldp             fp, lr, [SP], #0x10
    // 0xbf6c84: ret
    //     0xbf6c84: ret             
    // 0xbf6c88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf6c88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf6c8c: b               #0xbf65ac
    // 0xbf6c90: SaveReg d0
    //     0xbf6c90: str             q0, [SP, #-0x10]!
    // 0xbf6c94: stp             x2, x3, [SP, #-0x10]!
    // 0xbf6c98: stp             x0, x1, [SP, #-0x10]!
    // 0xbf6c9c: r0 = AllocateDouble()
    //     0xbf6c9c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf6ca0: mov             x4, x0
    // 0xbf6ca4: ldp             x0, x1, [SP], #0x10
    // 0xbf6ca8: ldp             x2, x3, [SP], #0x10
    // 0xbf6cac: RestoreReg d0
    //     0xbf6cac: ldr             q0, [SP], #0x10
    // 0xbf6cb0: b               #0xbf6610
  }
  _ ==(/* No info */) {
    // ** addr: 0xc900e8, size: 0x468
    // 0xc900e8: EnterFrame
    //     0xc900e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc900ec: mov             fp, SP
    // 0xc900f0: CheckStackOverflow
    //     0xc900f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc900f4: cmp             SP, x16
    //     0xc900f8: b.ls            #0xc90548
    // 0xc900fc: ldr             x1, [fp, #0x10]
    // 0xc90100: cmp             w1, NULL
    // 0xc90104: b.ne            #0xc90118
    // 0xc90108: r0 = false
    //     0xc90108: add             x0, NULL, #0x30  ; false
    // 0xc9010c: LeaveFrame
    //     0xc9010c: mov             SP, fp
    //     0xc90110: ldp             fp, lr, [SP], #0x10
    // 0xc90114: ret
    //     0xc90114: ret             
    // 0xc90118: ldr             x2, [fp, #0x18]
    // 0xc9011c: cmp             w2, w1
    // 0xc90120: b.ne            #0xc90134
    // 0xc90124: r0 = true
    //     0xc90124: add             x0, NULL, #0x20  ; true
    // 0xc90128: LeaveFrame
    //     0xc90128: mov             SP, fp
    //     0xc9012c: ldp             fp, lr, [SP], #0x10
    // 0xc90130: ret
    //     0xc90130: ret             
    // 0xc90134: r0 = 59
    //     0xc90134: mov             x0, #0x3b
    // 0xc90138: branchIfSmi(r1, 0xc90144)
    //     0xc90138: tbz             w1, #0, #0xc90144
    // 0xc9013c: r0 = LoadClassIdInstr(r1)
    //     0xc9013c: ldur            x0, [x1, #-1]
    //     0xc90140: ubfx            x0, x0, #0xc, #0x14
    // 0xc90144: SaveReg r1
    //     0xc90144: str             x1, [SP, #-8]!
    // 0xc90148: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc90148: mov             x17, #0x57c5
    //     0xc9014c: add             lr, x0, x17
    //     0xc90150: ldr             lr, [x21, lr, lsl #3]
    //     0xc90154: blr             lr
    // 0xc90158: add             SP, SP, #8
    // 0xc9015c: r1 = LoadClassIdInstr(r0)
    //     0xc9015c: ldur            x1, [x0, #-1]
    //     0xc90160: ubfx            x1, x1, #0xc, #0x14
    // 0xc90164: r16 = TextTheme
    //     0xc90164: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf38] Type: TextTheme
    //     0xc90168: ldr             x16, [x16, #0xf38]
    // 0xc9016c: stp             x16, x0, [SP, #-0x10]!
    // 0xc90170: mov             x0, x1
    // 0xc90174: mov             lr, x0
    // 0xc90178: ldr             lr, [x21, lr, lsl #3]
    // 0xc9017c: blr             lr
    // 0xc90180: add             SP, SP, #0x10
    // 0xc90184: tbz             w0, #4, #0xc90198
    // 0xc90188: r0 = false
    //     0xc90188: add             x0, NULL, #0x30  ; false
    // 0xc9018c: LeaveFrame
    //     0xc9018c: mov             SP, fp
    //     0xc90190: ldp             fp, lr, [SP], #0x10
    // 0xc90194: ret
    //     0xc90194: ret             
    // 0xc90198: ldr             x1, [fp, #0x10]
    // 0xc9019c: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9019c: mov             x0, #0x76
    //     0xc901a0: tbz             w1, #0, #0xc901b0
    //     0xc901a4: ldur            x0, [x1, #-1]
    //     0xc901a8: ubfx            x0, x0, #0xc, #0x14
    //     0xc901ac: lsl             x0, x0, #1
    // 0xc901b0: r17 = 5438
    //     0xc901b0: mov             x17, #0x153e
    // 0xc901b4: cmp             w0, w17
    // 0xc901b8: b.ne            #0xc90538
    // 0xc901bc: ldr             x2, [fp, #0x18]
    // 0xc901c0: LoadField: r0 = r2->field_7
    //     0xc901c0: ldur            w0, [x2, #7]
    // 0xc901c4: DecompressPointer r0
    //     0xc901c4: add             x0, x0, HEAP, lsl #32
    // 0xc901c8: LoadField: r3 = r1->field_7
    //     0xc901c8: ldur            w3, [x1, #7]
    // 0xc901cc: DecompressPointer r3
    //     0xc901cc: add             x3, x3, HEAP, lsl #32
    // 0xc901d0: r4 = LoadClassIdInstr(r0)
    //     0xc901d0: ldur            x4, [x0, #-1]
    //     0xc901d4: ubfx            x4, x4, #0xc, #0x14
    // 0xc901d8: stp             x3, x0, [SP, #-0x10]!
    // 0xc901dc: mov             x0, x4
    // 0xc901e0: mov             lr, x0
    // 0xc901e4: ldr             lr, [x21, lr, lsl #3]
    // 0xc901e8: blr             lr
    // 0xc901ec: add             SP, SP, #0x10
    // 0xc901f0: tbnz            w0, #4, #0xc90538
    // 0xc901f4: ldr             x2, [fp, #0x18]
    // 0xc901f8: ldr             x1, [fp, #0x10]
    // 0xc901fc: LoadField: r0 = r2->field_b
    //     0xc901fc: ldur            w0, [x2, #0xb]
    // 0xc90200: DecompressPointer r0
    //     0xc90200: add             x0, x0, HEAP, lsl #32
    // 0xc90204: LoadField: r3 = r1->field_b
    //     0xc90204: ldur            w3, [x1, #0xb]
    // 0xc90208: DecompressPointer r3
    //     0xc90208: add             x3, x3, HEAP, lsl #32
    // 0xc9020c: r4 = LoadClassIdInstr(r0)
    //     0xc9020c: ldur            x4, [x0, #-1]
    //     0xc90210: ubfx            x4, x4, #0xc, #0x14
    // 0xc90214: stp             x3, x0, [SP, #-0x10]!
    // 0xc90218: mov             x0, x4
    // 0xc9021c: mov             lr, x0
    // 0xc90220: ldr             lr, [x21, lr, lsl #3]
    // 0xc90224: blr             lr
    // 0xc90228: add             SP, SP, #0x10
    // 0xc9022c: tbnz            w0, #4, #0xc90538
    // 0xc90230: ldr             x2, [fp, #0x18]
    // 0xc90234: ldr             x1, [fp, #0x10]
    // 0xc90238: LoadField: r0 = r2->field_f
    //     0xc90238: ldur            w0, [x2, #0xf]
    // 0xc9023c: DecompressPointer r0
    //     0xc9023c: add             x0, x0, HEAP, lsl #32
    // 0xc90240: LoadField: r3 = r1->field_f
    //     0xc90240: ldur            w3, [x1, #0xf]
    // 0xc90244: DecompressPointer r3
    //     0xc90244: add             x3, x3, HEAP, lsl #32
    // 0xc90248: r4 = LoadClassIdInstr(r0)
    //     0xc90248: ldur            x4, [x0, #-1]
    //     0xc9024c: ubfx            x4, x4, #0xc, #0x14
    // 0xc90250: stp             x3, x0, [SP, #-0x10]!
    // 0xc90254: mov             x0, x4
    // 0xc90258: mov             lr, x0
    // 0xc9025c: ldr             lr, [x21, lr, lsl #3]
    // 0xc90260: blr             lr
    // 0xc90264: add             SP, SP, #0x10
    // 0xc90268: tbnz            w0, #4, #0xc90538
    // 0xc9026c: ldr             x2, [fp, #0x18]
    // 0xc90270: ldr             x1, [fp, #0x10]
    // 0xc90274: LoadField: r0 = r2->field_13
    //     0xc90274: ldur            w0, [x2, #0x13]
    // 0xc90278: DecompressPointer r0
    //     0xc90278: add             x0, x0, HEAP, lsl #32
    // 0xc9027c: LoadField: r3 = r1->field_13
    //     0xc9027c: ldur            w3, [x1, #0x13]
    // 0xc90280: DecompressPointer r3
    //     0xc90280: add             x3, x3, HEAP, lsl #32
    // 0xc90284: r4 = LoadClassIdInstr(r0)
    //     0xc90284: ldur            x4, [x0, #-1]
    //     0xc90288: ubfx            x4, x4, #0xc, #0x14
    // 0xc9028c: stp             x3, x0, [SP, #-0x10]!
    // 0xc90290: mov             x0, x4
    // 0xc90294: mov             lr, x0
    // 0xc90298: ldr             lr, [x21, lr, lsl #3]
    // 0xc9029c: blr             lr
    // 0xc902a0: add             SP, SP, #0x10
    // 0xc902a4: tbnz            w0, #4, #0xc90538
    // 0xc902a8: ldr             x2, [fp, #0x18]
    // 0xc902ac: ldr             x1, [fp, #0x10]
    // 0xc902b0: LoadField: r0 = r2->field_17
    //     0xc902b0: ldur            w0, [x2, #0x17]
    // 0xc902b4: DecompressPointer r0
    //     0xc902b4: add             x0, x0, HEAP, lsl #32
    // 0xc902b8: LoadField: r3 = r1->field_17
    //     0xc902b8: ldur            w3, [x1, #0x17]
    // 0xc902bc: DecompressPointer r3
    //     0xc902bc: add             x3, x3, HEAP, lsl #32
    // 0xc902c0: r4 = LoadClassIdInstr(r0)
    //     0xc902c0: ldur            x4, [x0, #-1]
    //     0xc902c4: ubfx            x4, x4, #0xc, #0x14
    // 0xc902c8: stp             x3, x0, [SP, #-0x10]!
    // 0xc902cc: mov             x0, x4
    // 0xc902d0: mov             lr, x0
    // 0xc902d4: ldr             lr, [x21, lr, lsl #3]
    // 0xc902d8: blr             lr
    // 0xc902dc: add             SP, SP, #0x10
    // 0xc902e0: tbnz            w0, #4, #0xc90538
    // 0xc902e4: ldr             x2, [fp, #0x18]
    // 0xc902e8: ldr             x1, [fp, #0x10]
    // 0xc902ec: LoadField: r0 = r2->field_1b
    //     0xc902ec: ldur            w0, [x2, #0x1b]
    // 0xc902f0: DecompressPointer r0
    //     0xc902f0: add             x0, x0, HEAP, lsl #32
    // 0xc902f4: LoadField: r3 = r1->field_1b
    //     0xc902f4: ldur            w3, [x1, #0x1b]
    // 0xc902f8: DecompressPointer r3
    //     0xc902f8: add             x3, x3, HEAP, lsl #32
    // 0xc902fc: r4 = LoadClassIdInstr(r0)
    //     0xc902fc: ldur            x4, [x0, #-1]
    //     0xc90300: ubfx            x4, x4, #0xc, #0x14
    // 0xc90304: stp             x3, x0, [SP, #-0x10]!
    // 0xc90308: mov             x0, x4
    // 0xc9030c: mov             lr, x0
    // 0xc90310: ldr             lr, [x21, lr, lsl #3]
    // 0xc90314: blr             lr
    // 0xc90318: add             SP, SP, #0x10
    // 0xc9031c: tbnz            w0, #4, #0xc90538
    // 0xc90320: ldr             x2, [fp, #0x18]
    // 0xc90324: ldr             x1, [fp, #0x10]
    // 0xc90328: LoadField: r0 = r2->field_1f
    //     0xc90328: ldur            w0, [x2, #0x1f]
    // 0xc9032c: DecompressPointer r0
    //     0xc9032c: add             x0, x0, HEAP, lsl #32
    // 0xc90330: LoadField: r3 = r1->field_1f
    //     0xc90330: ldur            w3, [x1, #0x1f]
    // 0xc90334: DecompressPointer r3
    //     0xc90334: add             x3, x3, HEAP, lsl #32
    // 0xc90338: r4 = LoadClassIdInstr(r0)
    //     0xc90338: ldur            x4, [x0, #-1]
    //     0xc9033c: ubfx            x4, x4, #0xc, #0x14
    // 0xc90340: stp             x3, x0, [SP, #-0x10]!
    // 0xc90344: mov             x0, x4
    // 0xc90348: mov             lr, x0
    // 0xc9034c: ldr             lr, [x21, lr, lsl #3]
    // 0xc90350: blr             lr
    // 0xc90354: add             SP, SP, #0x10
    // 0xc90358: tbnz            w0, #4, #0xc90538
    // 0xc9035c: ldr             x2, [fp, #0x18]
    // 0xc90360: ldr             x1, [fp, #0x10]
    // 0xc90364: LoadField: r0 = r2->field_23
    //     0xc90364: ldur            w0, [x2, #0x23]
    // 0xc90368: DecompressPointer r0
    //     0xc90368: add             x0, x0, HEAP, lsl #32
    // 0xc9036c: LoadField: r3 = r1->field_23
    //     0xc9036c: ldur            w3, [x1, #0x23]
    // 0xc90370: DecompressPointer r3
    //     0xc90370: add             x3, x3, HEAP, lsl #32
    // 0xc90374: r4 = LoadClassIdInstr(r0)
    //     0xc90374: ldur            x4, [x0, #-1]
    //     0xc90378: ubfx            x4, x4, #0xc, #0x14
    // 0xc9037c: stp             x3, x0, [SP, #-0x10]!
    // 0xc90380: mov             x0, x4
    // 0xc90384: mov             lr, x0
    // 0xc90388: ldr             lr, [x21, lr, lsl #3]
    // 0xc9038c: blr             lr
    // 0xc90390: add             SP, SP, #0x10
    // 0xc90394: tbnz            w0, #4, #0xc90538
    // 0xc90398: ldr             x2, [fp, #0x18]
    // 0xc9039c: ldr             x1, [fp, #0x10]
    // 0xc903a0: LoadField: r0 = r2->field_27
    //     0xc903a0: ldur            w0, [x2, #0x27]
    // 0xc903a4: DecompressPointer r0
    //     0xc903a4: add             x0, x0, HEAP, lsl #32
    // 0xc903a8: LoadField: r3 = r1->field_27
    //     0xc903a8: ldur            w3, [x1, #0x27]
    // 0xc903ac: DecompressPointer r3
    //     0xc903ac: add             x3, x3, HEAP, lsl #32
    // 0xc903b0: r4 = LoadClassIdInstr(r0)
    //     0xc903b0: ldur            x4, [x0, #-1]
    //     0xc903b4: ubfx            x4, x4, #0xc, #0x14
    // 0xc903b8: stp             x3, x0, [SP, #-0x10]!
    // 0xc903bc: mov             x0, x4
    // 0xc903c0: mov             lr, x0
    // 0xc903c4: ldr             lr, [x21, lr, lsl #3]
    // 0xc903c8: blr             lr
    // 0xc903cc: add             SP, SP, #0x10
    // 0xc903d0: tbnz            w0, #4, #0xc90538
    // 0xc903d4: ldr             x2, [fp, #0x18]
    // 0xc903d8: ldr             x1, [fp, #0x10]
    // 0xc903dc: LoadField: r0 = r2->field_2b
    //     0xc903dc: ldur            w0, [x2, #0x2b]
    // 0xc903e0: DecompressPointer r0
    //     0xc903e0: add             x0, x0, HEAP, lsl #32
    // 0xc903e4: LoadField: r3 = r1->field_2b
    //     0xc903e4: ldur            w3, [x1, #0x2b]
    // 0xc903e8: DecompressPointer r3
    //     0xc903e8: add             x3, x3, HEAP, lsl #32
    // 0xc903ec: r4 = LoadClassIdInstr(r0)
    //     0xc903ec: ldur            x4, [x0, #-1]
    //     0xc903f0: ubfx            x4, x4, #0xc, #0x14
    // 0xc903f4: stp             x3, x0, [SP, #-0x10]!
    // 0xc903f8: mov             x0, x4
    // 0xc903fc: mov             lr, x0
    // 0xc90400: ldr             lr, [x21, lr, lsl #3]
    // 0xc90404: blr             lr
    // 0xc90408: add             SP, SP, #0x10
    // 0xc9040c: tbnz            w0, #4, #0xc90538
    // 0xc90410: ldr             x2, [fp, #0x18]
    // 0xc90414: ldr             x1, [fp, #0x10]
    // 0xc90418: LoadField: r0 = r2->field_2f
    //     0xc90418: ldur            w0, [x2, #0x2f]
    // 0xc9041c: DecompressPointer r0
    //     0xc9041c: add             x0, x0, HEAP, lsl #32
    // 0xc90420: LoadField: r3 = r1->field_2f
    //     0xc90420: ldur            w3, [x1, #0x2f]
    // 0xc90424: DecompressPointer r3
    //     0xc90424: add             x3, x3, HEAP, lsl #32
    // 0xc90428: r4 = LoadClassIdInstr(r0)
    //     0xc90428: ldur            x4, [x0, #-1]
    //     0xc9042c: ubfx            x4, x4, #0xc, #0x14
    // 0xc90430: stp             x3, x0, [SP, #-0x10]!
    // 0xc90434: mov             x0, x4
    // 0xc90438: mov             lr, x0
    // 0xc9043c: ldr             lr, [x21, lr, lsl #3]
    // 0xc90440: blr             lr
    // 0xc90444: add             SP, SP, #0x10
    // 0xc90448: tbnz            w0, #4, #0xc90538
    // 0xc9044c: ldr             x2, [fp, #0x18]
    // 0xc90450: ldr             x1, [fp, #0x10]
    // 0xc90454: LoadField: r0 = r2->field_33
    //     0xc90454: ldur            w0, [x2, #0x33]
    // 0xc90458: DecompressPointer r0
    //     0xc90458: add             x0, x0, HEAP, lsl #32
    // 0xc9045c: LoadField: r3 = r1->field_33
    //     0xc9045c: ldur            w3, [x1, #0x33]
    // 0xc90460: DecompressPointer r3
    //     0xc90460: add             x3, x3, HEAP, lsl #32
    // 0xc90464: r4 = LoadClassIdInstr(r0)
    //     0xc90464: ldur            x4, [x0, #-1]
    //     0xc90468: ubfx            x4, x4, #0xc, #0x14
    // 0xc9046c: stp             x3, x0, [SP, #-0x10]!
    // 0xc90470: mov             x0, x4
    // 0xc90474: mov             lr, x0
    // 0xc90478: ldr             lr, [x21, lr, lsl #3]
    // 0xc9047c: blr             lr
    // 0xc90480: add             SP, SP, #0x10
    // 0xc90484: tbnz            w0, #4, #0xc90538
    // 0xc90488: ldr             x2, [fp, #0x18]
    // 0xc9048c: ldr             x1, [fp, #0x10]
    // 0xc90490: LoadField: r0 = r2->field_37
    //     0xc90490: ldur            w0, [x2, #0x37]
    // 0xc90494: DecompressPointer r0
    //     0xc90494: add             x0, x0, HEAP, lsl #32
    // 0xc90498: LoadField: r3 = r1->field_37
    //     0xc90498: ldur            w3, [x1, #0x37]
    // 0xc9049c: DecompressPointer r3
    //     0xc9049c: add             x3, x3, HEAP, lsl #32
    // 0xc904a0: r4 = LoadClassIdInstr(r0)
    //     0xc904a0: ldur            x4, [x0, #-1]
    //     0xc904a4: ubfx            x4, x4, #0xc, #0x14
    // 0xc904a8: stp             x3, x0, [SP, #-0x10]!
    // 0xc904ac: mov             x0, x4
    // 0xc904b0: mov             lr, x0
    // 0xc904b4: ldr             lr, [x21, lr, lsl #3]
    // 0xc904b8: blr             lr
    // 0xc904bc: add             SP, SP, #0x10
    // 0xc904c0: tbnz            w0, #4, #0xc90538
    // 0xc904c4: ldr             x2, [fp, #0x18]
    // 0xc904c8: ldr             x1, [fp, #0x10]
    // 0xc904cc: LoadField: r0 = r2->field_3b
    //     0xc904cc: ldur            w0, [x2, #0x3b]
    // 0xc904d0: DecompressPointer r0
    //     0xc904d0: add             x0, x0, HEAP, lsl #32
    // 0xc904d4: LoadField: r3 = r1->field_3b
    //     0xc904d4: ldur            w3, [x1, #0x3b]
    // 0xc904d8: DecompressPointer r3
    //     0xc904d8: add             x3, x3, HEAP, lsl #32
    // 0xc904dc: r4 = LoadClassIdInstr(r0)
    //     0xc904dc: ldur            x4, [x0, #-1]
    //     0xc904e0: ubfx            x4, x4, #0xc, #0x14
    // 0xc904e4: stp             x3, x0, [SP, #-0x10]!
    // 0xc904e8: mov             x0, x4
    // 0xc904ec: mov             lr, x0
    // 0xc904f0: ldr             lr, [x21, lr, lsl #3]
    // 0xc904f4: blr             lr
    // 0xc904f8: add             SP, SP, #0x10
    // 0xc904fc: tbnz            w0, #4, #0xc90538
    // 0xc90500: ldr             x1, [fp, #0x18]
    // 0xc90504: ldr             x0, [fp, #0x10]
    // 0xc90508: LoadField: r2 = r1->field_3f
    //     0xc90508: ldur            w2, [x1, #0x3f]
    // 0xc9050c: DecompressPointer r2
    //     0xc9050c: add             x2, x2, HEAP, lsl #32
    // 0xc90510: LoadField: r1 = r0->field_3f
    //     0xc90510: ldur            w1, [x0, #0x3f]
    // 0xc90514: DecompressPointer r1
    //     0xc90514: add             x1, x1, HEAP, lsl #32
    // 0xc90518: r0 = LoadClassIdInstr(r2)
    //     0xc90518: ldur            x0, [x2, #-1]
    //     0xc9051c: ubfx            x0, x0, #0xc, #0x14
    // 0xc90520: stp             x1, x2, [SP, #-0x10]!
    // 0xc90524: mov             lr, x0
    // 0xc90528: ldr             lr, [x21, lr, lsl #3]
    // 0xc9052c: blr             lr
    // 0xc90530: add             SP, SP, #0x10
    // 0xc90534: b               #0xc9053c
    // 0xc90538: r0 = false
    //     0xc90538: add             x0, NULL, #0x30  ; false
    // 0xc9053c: LeaveFrame
    //     0xc9053c: mov             SP, fp
    //     0xc90540: ldp             fp, lr, [SP], #0x10
    // 0xc90544: ret
    //     0xc90544: ret             
    // 0xc90548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc90548: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9054c: b               #0xc900fc
  }
}

// lib: , url: package:flutter/src/material/colors.dart

// class id: 1049211, size: 0x8
class :: {
}

// class id: 5061, size: 0x18, field offset: 0x18
//   const constructor, 
class MaterialAccentColor extends ColorSwatch<int> {

  _Mint field_8;
  _ConstMap<int, Color> field_14;
}

// class id: 5062, size: 0x18, field offset: 0x18
//   const constructor, 
class MaterialColor extends ColorSwatch<int> {

  _Mint field_8;
  _ConstMap<int, Color> field_14;
}

// lib: , url: package:flutter/src/material/magnifier.dart

// class id: 1049266, size: 0x8
class :: {
}

// class id: 3313, size: 0x20, field offset: 0x14
class _TextMagnifierState extends State<TextMagnifier> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b5fcc, size: 0x1a4
    // 0x7b5fcc: EnterFrame
    //     0x7b5fcc: stp             fp, lr, [SP, #-0x10]!
    //     0x7b5fd0: mov             fp, SP
    // 0x7b5fd4: AllocStack(0x8)
    //     0x7b5fd4: sub             SP, SP, #8
    // 0x7b5fd8: CheckStackOverflow
    //     0x7b5fd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b5fdc: cmp             SP, x16
    //     0x7b5fe0: b.ls            #0x7b6160
    // 0x7b5fe4: ldr             x0, [fp, #0x10]
    // 0x7b5fe8: r2 = Null
    //     0x7b5fe8: mov             x2, NULL
    // 0x7b5fec: r1 = Null
    //     0x7b5fec: mov             x1, NULL
    // 0x7b5ff0: r4 = 59
    //     0x7b5ff0: mov             x4, #0x3b
    // 0x7b5ff4: branchIfSmi(r0, 0x7b6000)
    //     0x7b5ff4: tbz             w0, #0, #0x7b6000
    // 0x7b5ff8: r4 = LoadClassIdInstr(r0)
    //     0x7b5ff8: ldur            x4, [x0, #-1]
    //     0x7b5ffc: ubfx            x4, x4, #0xc, #0x14
    // 0x7b6000: r17 = 4148
    //     0x7b6000: mov             x17, #0x1034
    // 0x7b6004: cmp             x4, x17
    // 0x7b6008: b.eq            #0x7b6020
    // 0x7b600c: r8 = TextMagnifier
    //     0x7b600c: add             x8, PP, #0x40, lsl #12  ; [pp+0x40050] Type: TextMagnifier
    //     0x7b6010: ldr             x8, [x8, #0x50]
    // 0x7b6014: r3 = Null
    //     0x7b6014: add             x3, PP, #0x40, lsl #12  ; [pp+0x40058] Null
    //     0x7b6018: ldr             x3, [x3, #0x58]
    // 0x7b601c: r0 = TextMagnifier()
    //     0x7b601c: bl              #0x7b66ac  ; IsType_TextMagnifier_Stub
    // 0x7b6020: ldr             x0, [fp, #0x10]
    // 0x7b6024: LoadField: r1 = r0->field_b
    //     0x7b6024: ldur            w1, [x0, #0xb]
    // 0x7b6028: DecompressPointer r1
    //     0x7b6028: add             x1, x1, HEAP, lsl #32
    // 0x7b602c: ldr             x2, [fp, #0x18]
    // 0x7b6030: stur            x1, [fp, #-8]
    // 0x7b6034: LoadField: r3 = r2->field_b
    //     0x7b6034: ldur            w3, [x2, #0xb]
    // 0x7b6038: DecompressPointer r3
    //     0x7b6038: add             x3, x3, HEAP, lsl #32
    // 0x7b603c: cmp             w3, NULL
    // 0x7b6040: b.eq            #0x7b6168
    // 0x7b6044: LoadField: r4 = r3->field_b
    //     0x7b6044: ldur            w4, [x3, #0xb]
    // 0x7b6048: DecompressPointer r4
    //     0x7b6048: add             x4, x4, HEAP, lsl #32
    // 0x7b604c: cmp             w1, w4
    // 0x7b6050: b.eq            #0x7b6114
    // 0x7b6054: r1 = 1
    //     0x7b6054: mov             x1, #1
    // 0x7b6058: r0 = AllocateContext()
    //     0x7b6058: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b605c: mov             x1, x0
    // 0x7b6060: ldr             x0, [fp, #0x18]
    // 0x7b6064: StoreField: r1->field_f = r0
    //     0x7b6064: stur            w0, [x1, #0xf]
    // 0x7b6068: mov             x2, x1
    // 0x7b606c: r1 = Function '_determineMagnifierPositionAndFocalPoint@767515283':.
    //     0x7b606c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40068] AnonymousClosure: (0x7b6170), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7b61b8)
    //     0x7b6070: ldr             x1, [x1, #0x68]
    // 0x7b6074: r0 = AllocateClosure()
    //     0x7b6074: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b6078: mov             x1, x0
    // 0x7b607c: ldur            x0, [fp, #-8]
    // 0x7b6080: r2 = LoadClassIdInstr(r0)
    //     0x7b6080: ldur            x2, [x0, #-1]
    //     0x7b6084: ubfx            x2, x2, #0xc, #0x14
    // 0x7b6088: stp             x1, x0, [SP, #-0x10]!
    // 0x7b608c: mov             x0, x2
    // 0x7b6090: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x7b6090: mov             x17, #0xc2d6
    //     0x7b6094: add             lr, x0, x17
    //     0x7b6098: ldr             lr, [x21, lr, lsl #3]
    //     0x7b609c: blr             lr
    // 0x7b60a0: add             SP, SP, #0x10
    // 0x7b60a4: ldr             x0, [fp, #0x18]
    // 0x7b60a8: LoadField: r1 = r0->field_b
    //     0x7b60a8: ldur            w1, [x0, #0xb]
    // 0x7b60ac: DecompressPointer r1
    //     0x7b60ac: add             x1, x1, HEAP, lsl #32
    // 0x7b60b0: cmp             w1, NULL
    // 0x7b60b4: b.eq            #0x7b616c
    // 0x7b60b8: LoadField: r2 = r1->field_b
    //     0x7b60b8: ldur            w2, [x1, #0xb]
    // 0x7b60bc: DecompressPointer r2
    //     0x7b60bc: add             x2, x2, HEAP, lsl #32
    // 0x7b60c0: stur            x2, [fp, #-8]
    // 0x7b60c4: r1 = 1
    //     0x7b60c4: mov             x1, #1
    // 0x7b60c8: r0 = AllocateContext()
    //     0x7b60c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b60cc: mov             x1, x0
    // 0x7b60d0: ldr             x0, [fp, #0x18]
    // 0x7b60d4: StoreField: r1->field_f = r0
    //     0x7b60d4: stur            w0, [x1, #0xf]
    // 0x7b60d8: mov             x2, x1
    // 0x7b60dc: r1 = Function '_determineMagnifierPositionAndFocalPoint@767515283':.
    //     0x7b60dc: add             x1, PP, #0x40, lsl #12  ; [pp+0x40068] AnonymousClosure: (0x7b6170), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7b61b8)
    //     0x7b60e0: ldr             x1, [x1, #0x68]
    // 0x7b60e4: r0 = AllocateClosure()
    //     0x7b60e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b60e8: mov             x1, x0
    // 0x7b60ec: ldur            x0, [fp, #-8]
    // 0x7b60f0: r2 = LoadClassIdInstr(r0)
    //     0x7b60f0: ldur            x2, [x0, #-1]
    //     0x7b60f4: ubfx            x2, x2, #0xc, #0x14
    // 0x7b60f8: stp             x1, x0, [SP, #-0x10]!
    // 0x7b60fc: mov             x0, x2
    // 0x7b6100: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7b6100: mov             x17, #0xc3ab
    //     0x7b6104: add             lr, x0, x17
    //     0x7b6108: ldr             lr, [x21, lr, lsl #3]
    //     0x7b610c: blr             lr
    // 0x7b6110: add             SP, SP, #0x10
    // 0x7b6114: ldr             x0, [fp, #0x18]
    // 0x7b6118: LoadField: r2 = r0->field_7
    //     0x7b6118: ldur            w2, [x0, #7]
    // 0x7b611c: DecompressPointer r2
    //     0x7b611c: add             x2, x2, HEAP, lsl #32
    // 0x7b6120: ldr             x0, [fp, #0x10]
    // 0x7b6124: r1 = Null
    //     0x7b6124: mov             x1, NULL
    // 0x7b6128: cmp             w2, NULL
    // 0x7b612c: b.eq            #0x7b6150
    // 0x7b6130: LoadField: r4 = r2->field_17
    //     0x7b6130: ldur            w4, [x2, #0x17]
    // 0x7b6134: DecompressPointer r4
    //     0x7b6134: add             x4, x4, HEAP, lsl #32
    // 0x7b6138: r8 = X0 bound StatefulWidget
    //     0x7b6138: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b613c: ldr             x8, [x8, #0x858]
    // 0x7b6140: LoadField: r9 = r4->field_7
    //     0x7b6140: ldur            x9, [x4, #7]
    // 0x7b6144: r3 = Null
    //     0x7b6144: add             x3, PP, #0x40, lsl #12  ; [pp+0x40070] Null
    //     0x7b6148: ldr             x3, [x3, #0x70]
    // 0x7b614c: blr             x9
    // 0x7b6150: r0 = Null
    //     0x7b6150: mov             x0, NULL
    // 0x7b6154: LeaveFrame
    //     0x7b6154: mov             SP, fp
    //     0x7b6158: ldp             fp, lr, [SP], #0x10
    // 0x7b615c: ret
    //     0x7b615c: ret             
    // 0x7b6160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b6160: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b6164: b               #0x7b5fe4
    // 0x7b6168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b6168: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b616c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b616c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _determineMagnifierPositionAndFocalPoint(dynamic) {
    // ** addr: 0x7b6170, size: 0x48
    // 0x7b6170: EnterFrame
    //     0x7b6170: stp             fp, lr, [SP, #-0x10]!
    //     0x7b6174: mov             fp, SP
    // 0x7b6178: ldr             x0, [fp, #0x10]
    // 0x7b617c: LoadField: r1 = r0->field_17
    //     0x7b617c: ldur            w1, [x0, #0x17]
    // 0x7b6180: DecompressPointer r1
    //     0x7b6180: add             x1, x1, HEAP, lsl #32
    // 0x7b6184: CheckStackOverflow
    //     0x7b6184: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b6188: cmp             SP, x16
    //     0x7b618c: b.ls            #0x7b61b0
    // 0x7b6190: LoadField: r0 = r1->field_f
    //     0x7b6190: ldur            w0, [x1, #0xf]
    // 0x7b6194: DecompressPointer r0
    //     0x7b6194: add             x0, x0, HEAP, lsl #32
    // 0x7b6198: SaveReg r0
    //     0x7b6198: str             x0, [SP, #-8]!
    // 0x7b619c: r0 = _determineMagnifierPositionAndFocalPoint()
    //     0x7b619c: bl              #0x7b61b8  ; [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint
    // 0x7b61a0: add             SP, SP, #8
    // 0x7b61a4: LeaveFrame
    //     0x7b61a4: mov             SP, fp
    //     0x7b61a8: ldp             fp, lr, [SP], #0x10
    // 0x7b61ac: ret
    //     0x7b61ac: ret             
    // 0x7b61b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b61b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b61b4: b               #0x7b6190
  }
  _ _determineMagnifierPositionAndFocalPoint(/* No info */) {
    // ** addr: 0x7b61b8, size: 0x3dc
    // 0x7b61b8: EnterFrame
    //     0x7b61b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b61bc: mov             fp, SP
    // 0x7b61c0: AllocStack(0x38)
    //     0x7b61c0: sub             SP, SP, #0x38
    // 0x7b61c4: CheckStackOverflow
    //     0x7b61c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b61c8: cmp             SP, x16
    //     0x7b61cc: b.ls            #0x7b6584
    // 0x7b61d0: r1 = 4
    //     0x7b61d0: mov             x1, #4
    // 0x7b61d4: r0 = AllocateContext()
    //     0x7b61d4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b61d8: mov             x1, x0
    // 0x7b61dc: ldr             x0, [fp, #0x10]
    // 0x7b61e0: stur            x1, [fp, #-0x10]
    // 0x7b61e4: StoreField: r1->field_f = r0
    //     0x7b61e4: stur            w0, [x1, #0xf]
    // 0x7b61e8: LoadField: r2 = r0->field_b
    //     0x7b61e8: ldur            w2, [x0, #0xb]
    // 0x7b61ec: DecompressPointer r2
    //     0x7b61ec: add             x2, x2, HEAP, lsl #32
    // 0x7b61f0: cmp             w2, NULL
    // 0x7b61f4: b.eq            #0x7b658c
    // 0x7b61f8: LoadField: r3 = r2->field_b
    //     0x7b61f8: ldur            w3, [x2, #0xb]
    // 0x7b61fc: DecompressPointer r3
    //     0x7b61fc: add             x3, x3, HEAP, lsl #32
    // 0x7b6200: LoadField: r2 = r3->field_27
    //     0x7b6200: ldur            w2, [x3, #0x27]
    // 0x7b6204: DecompressPointer r2
    //     0x7b6204: add             x2, x2, HEAP, lsl #32
    // 0x7b6208: stur            x2, [fp, #-8]
    // 0x7b620c: LoadField: r3 = r0->field_f
    //     0x7b620c: ldur            w3, [x0, #0xf]
    // 0x7b6210: DecompressPointer r3
    //     0x7b6210: add             x3, x3, HEAP, lsl #32
    // 0x7b6214: cmp             w3, NULL
    // 0x7b6218: b.eq            #0x7b6590
    // 0x7b621c: SaveReg r3
    //     0x7b621c: str             x3, [SP, #-8]!
    // 0x7b6220: r0 = of()
    //     0x7b6220: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x7b6224: add             SP, SP, #8
    // 0x7b6228: LoadField: r1 = r0->field_7
    //     0x7b6228: ldur            w1, [x0, #7]
    // 0x7b622c: DecompressPointer r1
    //     0x7b622c: add             x1, x1, HEAP, lsl #32
    // 0x7b6230: r16 = Instance_Offset
    //     0x7b6230: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x7b6234: stp             x1, x16, [SP, #-0x10]!
    // 0x7b6238: r0 = &()
    //     0x7b6238: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x7b623c: add             SP, SP, #0x10
    // 0x7b6240: stur            x0, [fp, #-0x18]
    // 0x7b6244: r0 = Offset()
    //     0x7b6244: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7b6248: d0 = 38.685000
    //     0x7b6248: add             x17, PP, #0x40, lsl #12  ; [pp+0x40080] IMM: double(38.685) from 0x404357ae147ae148
    //     0x7b624c: ldr             d0, [x17, #0x80]
    // 0x7b6250: stur            x0, [fp, #-0x20]
    // 0x7b6254: StoreField: r0->field_7 = d0
    //     0x7b6254: stur            d0, [x0, #7]
    // 0x7b6258: d0 = 59.900000
    //     0x7b6258: add             x17, PP, #0x40, lsl #12  ; [pp+0x40088] IMM: double(59.9) from 0x404df33333333333
    //     0x7b625c: ldr             d0, [x17, #0x88]
    // 0x7b6260: StoreField: r0->field_f = d0
    //     0x7b6260: stur            d0, [x0, #0xf]
    // 0x7b6264: ldur            x1, [fp, #-8]
    // 0x7b6268: LoadField: r2 = r1->field_7
    //     0x7b6268: ldur            w2, [x1, #7]
    // 0x7b626c: DecompressPointer r2
    //     0x7b626c: add             x2, x2, HEAP, lsl #32
    // 0x7b6270: LoadField: d0 = r2->field_7
    //     0x7b6270: ldur            d0, [x2, #7]
    // 0x7b6274: LoadField: r2 = r1->field_b
    //     0x7b6274: ldur            w2, [x1, #0xb]
    // 0x7b6278: DecompressPointer r2
    //     0x7b6278: add             x2, x2, HEAP, lsl #32
    // 0x7b627c: LoadField: d1 = r2->field_7
    //     0x7b627c: ldur            d1, [x2, #7]
    // 0x7b6280: LoadField: d2 = r2->field_17
    //     0x7b6280: ldur            d2, [x2, #0x17]
    // 0x7b6284: fcmp            d0, d1
    // 0x7b6288: b.vs            #0x7b6298
    // 0x7b628c: b.ge            #0x7b6298
    // 0x7b6290: mov             v0.16b, v1.16b
    // 0x7b6294: b               #0x7b62b8
    // 0x7b6298: fcmp            d0, d2
    // 0x7b629c: b.vs            #0x7b62ac
    // 0x7b62a0: b.le            #0x7b62ac
    // 0x7b62a4: mov             v0.16b, v2.16b
    // 0x7b62a8: b               #0x7b62b8
    // 0x7b62ac: fcmp            d0, d0
    // 0x7b62b0: b.vc            #0x7b62b8
    // 0x7b62b4: mov             v0.16b, v2.16b
    // 0x7b62b8: ldur            x2, [fp, #-0x10]
    // 0x7b62bc: stur            d0, [fp, #-0x28]
    // 0x7b62c0: LoadField: r3 = r1->field_f
    //     0x7b62c0: ldur            w3, [x1, #0xf]
    // 0x7b62c4: DecompressPointer r3
    //     0x7b62c4: add             x3, x3, HEAP, lsl #32
    // 0x7b62c8: SaveReg r3
    //     0x7b62c8: str             x3, [SP, #-8]!
    // 0x7b62cc: r0 = center()
    //     0x7b62cc: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x7b62d0: add             SP, SP, #8
    // 0x7b62d4: LoadField: d0 = r0->field_f
    //     0x7b62d4: ldur            d0, [x0, #0xf]
    // 0x7b62d8: stur            d0, [fp, #-0x30]
    // 0x7b62dc: r0 = Offset()
    //     0x7b62dc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7b62e0: ldur            d0, [fp, #-0x28]
    // 0x7b62e4: StoreField: r0->field_7 = d0
    //     0x7b62e4: stur            d0, [x0, #7]
    // 0x7b62e8: ldur            d0, [fp, #-0x30]
    // 0x7b62ec: StoreField: r0->field_f = d0
    //     0x7b62ec: stur            d0, [x0, #0xf]
    // 0x7b62f0: ldur            x16, [fp, #-0x20]
    // 0x7b62f4: stp             x16, x0, [SP, #-0x10]!
    // 0x7b62f8: r0 = -()
    //     0x7b62f8: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x7b62fc: add             SP, SP, #0x10
    // 0x7b6300: r16 = Instance_Size
    //     0x7b6300: add             x16, PP, #0x40, lsl #12  ; [pp+0x40048] Obj!Size@b5ecf1
    //     0x7b6304: ldr             x16, [x16, #0x48]
    // 0x7b6308: stp             x16, x0, [SP, #-0x10]!
    // 0x7b630c: r0 = &()
    //     0x7b630c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x7b6310: add             SP, SP, #0x10
    // 0x7b6314: stur            x0, [fp, #-0x20]
    // 0x7b6318: ldur            x16, [fp, #-0x18]
    // 0x7b631c: stp             x0, x16, [SP, #-0x10]!
    // 0x7b6320: r0 = shiftWithinBounds()
    //     0x7b6320: bl              #0x7af708  ; [package:flutter/src/widgets/magnifier.dart] MagnifierController::shiftWithinBounds
    // 0x7b6324: add             SP, SP, #0x10
    // 0x7b6328: stur            x0, [fp, #-0x18]
    // 0x7b632c: LoadField: d0 = r0->field_7
    //     0x7b632c: ldur            d0, [x0, #7]
    // 0x7b6330: stur            d0, [fp, #-0x30]
    // 0x7b6334: LoadField: d1 = r0->field_f
    //     0x7b6334: ldur            d1, [x0, #0xf]
    // 0x7b6338: stur            d1, [fp, #-0x28]
    // 0x7b633c: r0 = Offset()
    //     0x7b633c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7b6340: ldur            d0, [fp, #-0x30]
    // 0x7b6344: StoreField: r0->field_7 = d0
    //     0x7b6344: stur            d0, [x0, #7]
    // 0x7b6348: ldur            d0, [fp, #-0x28]
    // 0x7b634c: StoreField: r0->field_f = d0
    //     0x7b634c: stur            d0, [x0, #0xf]
    // 0x7b6350: ldur            x2, [fp, #-0x10]
    // 0x7b6354: StoreField: r2->field_13 = r0
    //     0x7b6354: stur            w0, [x2, #0x13]
    //     0x7b6358: ldurb           w16, [x2, #-1]
    //     0x7b635c: ldurb           w17, [x0, #-1]
    //     0x7b6360: and             x16, x17, x16, lsr #2
    //     0x7b6364: tst             x16, HEAP, lsr #32
    //     0x7b6368: b.eq            #0x7b6370
    //     0x7b636c: bl              #0xd6828c
    // 0x7b6370: ldur            x0, [fp, #-8]
    // 0x7b6374: LoadField: r1 = r0->field_13
    //     0x7b6374: ldur            w1, [x0, #0x13]
    // 0x7b6378: DecompressPointer r1
    //     0x7b6378: add             x1, x1, HEAP, lsl #32
    // 0x7b637c: LoadField: d1 = r1->field_17
    //     0x7b637c: ldur            d1, [x1, #0x17]
    // 0x7b6380: stur            d1, [fp, #-0x38]
    // 0x7b6384: LoadField: d2 = r1->field_7
    //     0x7b6384: ldur            d2, [x1, #7]
    // 0x7b6388: stur            d2, [fp, #-0x30]
    // 0x7b638c: fsub            d3, d1, d2
    // 0x7b6390: d4 = 61.896000
    //     0x7b6390: add             x17, PP, #0x40, lsl #12  ; [pp+0x40090] IMM: double(61.896) from 0x404ef2b020c49ba6
    //     0x7b6394: ldr             d4, [x17, #0x90]
    // 0x7b6398: fcmp            d3, d4
    // 0x7b639c: b.vs            #0x7b63bc
    // 0x7b63a0: b.ge            #0x7b63bc
    // 0x7b63a4: SaveReg r1
    //     0x7b63a4: str             x1, [SP, #-8]!
    // 0x7b63a8: r0 = center()
    //     0x7b63a8: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x7b63ac: add             SP, SP, #8
    // 0x7b63b0: LoadField: d0 = r0->field_7
    //     0x7b63b0: ldur            d0, [x0, #7]
    // 0x7b63b4: mov             v1.16b, v0.16b
    // 0x7b63b8: b               #0x7b6420
    // 0x7b63bc: ldur            x16, [fp, #-0x18]
    // 0x7b63c0: SaveReg r16
    //     0x7b63c0: str             x16, [SP, #-8]!
    // 0x7b63c4: r0 = center()
    //     0x7b63c4: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x7b63c8: add             SP, SP, #8
    // 0x7b63cc: LoadField: d0 = r0->field_7
    //     0x7b63cc: ldur            d0, [x0, #7]
    // 0x7b63d0: ldur            d1, [fp, #-0x30]
    // 0x7b63d4: d2 = 30.948000
    //     0x7b63d4: add             x17, PP, #0x40, lsl #12  ; [pp+0x40098] IMM: double(30.948) from 0x403ef2b020c49ba6
    //     0x7b63d8: ldr             d2, [x17, #0x98]
    // 0x7b63dc: fadd            d3, d1, d2
    // 0x7b63e0: ldur            d1, [fp, #-0x38]
    // 0x7b63e4: fsub            d4, d1, d2
    // 0x7b63e8: fcmp            d0, d3
    // 0x7b63ec: b.vs            #0x7b63fc
    // 0x7b63f0: b.ge            #0x7b63fc
    // 0x7b63f4: mov             v0.16b, v3.16b
    // 0x7b63f8: b               #0x7b641c
    // 0x7b63fc: fcmp            d0, d4
    // 0x7b6400: b.vs            #0x7b6410
    // 0x7b6404: b.le            #0x7b6410
    // 0x7b6408: mov             v0.16b, v4.16b
    // 0x7b640c: b               #0x7b641c
    // 0x7b6410: fcmp            d0, d0
    // 0x7b6414: b.vc            #0x7b641c
    // 0x7b6418: mov             v0.16b, v4.16b
    // 0x7b641c: mov             v1.16b, v0.16b
    // 0x7b6420: ldr             x1, [fp, #0x10]
    // 0x7b6424: ldur            x2, [fp, #-0x10]
    // 0x7b6428: ldur            x0, [fp, #-0x20]
    // 0x7b642c: ldur            d0, [fp, #-0x28]
    // 0x7b6430: stur            d1, [fp, #-0x30]
    // 0x7b6434: ldur            x16, [fp, #-0x18]
    // 0x7b6438: SaveReg r16
    //     0x7b6438: str             x16, [SP, #-8]!
    // 0x7b643c: r0 = center()
    //     0x7b643c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x7b6440: add             SP, SP, #8
    // 0x7b6444: LoadField: d0 = r0->field_7
    //     0x7b6444: ldur            d0, [x0, #7]
    // 0x7b6448: ldur            d1, [fp, #-0x30]
    // 0x7b644c: fsub            d2, d1, d0
    // 0x7b6450: ldur            x0, [fp, #-0x20]
    // 0x7b6454: stur            d2, [fp, #-0x38]
    // 0x7b6458: LoadField: d0 = r0->field_f
    //     0x7b6458: ldur            d0, [x0, #0xf]
    // 0x7b645c: ldur            d1, [fp, #-0x28]
    // 0x7b6460: fsub            d3, d0, d1
    // 0x7b6464: stur            d3, [fp, #-0x30]
    // 0x7b6468: r0 = Offset()
    //     0x7b6468: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7b646c: ldur            d0, [fp, #-0x38]
    // 0x7b6470: StoreField: r0->field_7 = d0
    //     0x7b6470: stur            d0, [x0, #7]
    // 0x7b6474: ldur            d0, [fp, #-0x30]
    // 0x7b6478: StoreField: r0->field_f = d0
    //     0x7b6478: stur            d0, [x0, #0xf]
    // 0x7b647c: ldur            x2, [fp, #-0x10]
    // 0x7b6480: StoreField: r2->field_17 = r0
    //     0x7b6480: stur            w0, [x2, #0x17]
    //     0x7b6484: ldurb           w16, [x2, #-1]
    //     0x7b6488: ldurb           w17, [x0, #-1]
    //     0x7b648c: and             x16, x17, x16, lsr #2
    //     0x7b6490: tst             x16, HEAP, lsr #32
    //     0x7b6494: b.eq            #0x7b649c
    //     0x7b6498: bl              #0xd6828c
    // 0x7b649c: ldr             x1, [fp, #0x10]
    // 0x7b64a0: LoadField: r3 = r1->field_17
    //     0x7b64a0: ldur            w3, [x1, #0x17]
    // 0x7b64a4: DecompressPointer r3
    //     0x7b64a4: add             x3, x3, HEAP, lsl #32
    // 0x7b64a8: mov             x0, x3
    // 0x7b64ac: StoreField: r2->field_1b = r0
    //     0x7b64ac: stur            w0, [x2, #0x1b]
    //     0x7b64b0: ldurb           w16, [x2, #-1]
    //     0x7b64b4: ldurb           w17, [x0, #-1]
    //     0x7b64b8: and             x16, x17, x16, lsr #2
    //     0x7b64bc: tst             x16, HEAP, lsr #32
    //     0x7b64c0: b.eq            #0x7b64c8
    //     0x7b64c4: bl              #0xd6828c
    // 0x7b64c8: LoadField: r0 = r1->field_13
    //     0x7b64c8: ldur            w0, [x1, #0x13]
    // 0x7b64cc: DecompressPointer r0
    //     0x7b64cc: add             x0, x0, HEAP, lsl #32
    // 0x7b64d0: cmp             w0, NULL
    // 0x7b64d4: b.eq            #0x7b6558
    // 0x7b64d8: ldur            d0, [fp, #-0x28]
    // 0x7b64dc: LoadField: d1 = r0->field_f
    //     0x7b64dc: ldur            d1, [x0, #0xf]
    // 0x7b64e0: fcmp            d0, d1
    // 0x7b64e4: b.eq            #0x7b6558
    // 0x7b64e8: cmp             w3, NULL
    // 0x7b64ec: b.eq            #0x7b650c
    // 0x7b64f0: LoadField: r0 = r3->field_7
    //     0x7b64f0: ldur            w0, [x3, #7]
    // 0x7b64f4: DecompressPointer r0
    //     0x7b64f4: add             x0, x0, HEAP, lsl #32
    // 0x7b64f8: cmp             w0, NULL
    // 0x7b64fc: b.eq            #0x7b650c
    // 0x7b6500: SaveReg r3
    //     0x7b6500: str             x3, [SP, #-8]!
    // 0x7b6504: r0 = cancel()
    //     0x7b6504: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x7b6508: add             SP, SP, #8
    // 0x7b650c: ldur            x0, [fp, #-0x10]
    // 0x7b6510: mov             x2, x0
    // 0x7b6514: r1 = Function '<anonymous closure>':.
    //     0x7b6514: add             x1, PP, #0x40, lsl #12  ; [pp+0x400a0] AnonymousClosure: (0x7b662c), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7b61b8)
    //     0x7b6518: ldr             x1, [x1, #0xa0]
    // 0x7b651c: r0 = AllocateClosure()
    //     0x7b651c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b6520: r16 = Instance_Duration
    //     0x7b6520: add             x16, PP, #0x40, lsl #12  ; [pp+0x40030] Obj!Duration@b67b51
    //     0x7b6524: ldr             x16, [x16, #0x30]
    // 0x7b6528: stp             x16, NULL, [SP, #-0x10]!
    // 0x7b652c: SaveReg r0
    //     0x7b652c: str             x0, [SP, #-8]!
    // 0x7b6530: r0 = Timer()
    //     0x7b6530: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x7b6534: add             SP, SP, #0x18
    // 0x7b6538: ldur            x2, [fp, #-0x10]
    // 0x7b653c: StoreField: r2->field_1b = r0
    //     0x7b653c: stur            w0, [x2, #0x1b]
    //     0x7b6540: ldurb           w16, [x2, #-1]
    //     0x7b6544: ldurb           w17, [x0, #-1]
    //     0x7b6548: and             x16, x17, x16, lsr #2
    //     0x7b654c: tst             x16, HEAP, lsr #32
    //     0x7b6550: b.eq            #0x7b6558
    //     0x7b6554: bl              #0xd6828c
    // 0x7b6558: r1 = Function '<anonymous closure>':.
    //     0x7b6558: add             x1, PP, #0x40, lsl #12  ; [pp+0x400a8] AnonymousClosure: (0x7b6594), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7b61b8)
    //     0x7b655c: ldr             x1, [x1, #0xa8]
    // 0x7b6560: r0 = AllocateClosure()
    //     0x7b6560: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b6564: ldr             x16, [fp, #0x10]
    // 0x7b6568: stp             x0, x16, [SP, #-0x10]!
    // 0x7b656c: r0 = setState()
    //     0x7b656c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7b6570: add             SP, SP, #0x10
    // 0x7b6574: r0 = Null
    //     0x7b6574: mov             x0, NULL
    // 0x7b6578: LeaveFrame
    //     0x7b6578: mov             SP, fp
    //     0x7b657c: ldp             fp, lr, [SP], #0x10
    // 0x7b6580: ret
    //     0x7b6580: ret             
    // 0x7b6584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b6584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b6588: b               #0x7b61d0
    // 0x7b658c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b658c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b6590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b6590: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7b6594, size: 0x98
    // 0x7b6594: EnterFrame
    //     0x7b6594: stp             fp, lr, [SP, #-0x10]!
    //     0x7b6598: mov             fp, SP
    // 0x7b659c: ldr             x1, [fp, #0x10]
    // 0x7b65a0: LoadField: r2 = r1->field_17
    //     0x7b65a0: ldur            w2, [x1, #0x17]
    // 0x7b65a4: DecompressPointer r2
    //     0x7b65a4: add             x2, x2, HEAP, lsl #32
    // 0x7b65a8: LoadField: r1 = r2->field_f
    //     0x7b65a8: ldur            w1, [x2, #0xf]
    // 0x7b65ac: DecompressPointer r1
    //     0x7b65ac: add             x1, x1, HEAP, lsl #32
    // 0x7b65b0: LoadField: r0 = r2->field_13
    //     0x7b65b0: ldur            w0, [x2, #0x13]
    // 0x7b65b4: DecompressPointer r0
    //     0x7b65b4: add             x0, x0, HEAP, lsl #32
    // 0x7b65b8: StoreField: r1->field_13 = r0
    //     0x7b65b8: stur            w0, [x1, #0x13]
    //     0x7b65bc: ldurb           w16, [x1, #-1]
    //     0x7b65c0: ldurb           w17, [x0, #-1]
    //     0x7b65c4: and             x16, x17, x16, lsr #2
    //     0x7b65c8: tst             x16, HEAP, lsr #32
    //     0x7b65cc: b.eq            #0x7b65d4
    //     0x7b65d0: bl              #0xd6826c
    // 0x7b65d4: LoadField: r0 = r2->field_1b
    //     0x7b65d4: ldur            w0, [x2, #0x1b]
    // 0x7b65d8: DecompressPointer r0
    //     0x7b65d8: add             x0, x0, HEAP, lsl #32
    // 0x7b65dc: StoreField: r1->field_17 = r0
    //     0x7b65dc: stur            w0, [x1, #0x17]
    //     0x7b65e0: ldurb           w16, [x1, #-1]
    //     0x7b65e4: ldurb           w17, [x0, #-1]
    //     0x7b65e8: and             x16, x17, x16, lsr #2
    //     0x7b65ec: tst             x16, HEAP, lsr #32
    //     0x7b65f0: b.eq            #0x7b65f8
    //     0x7b65f4: bl              #0xd6826c
    // 0x7b65f8: LoadField: r0 = r2->field_17
    //     0x7b65f8: ldur            w0, [x2, #0x17]
    // 0x7b65fc: DecompressPointer r0
    //     0x7b65fc: add             x0, x0, HEAP, lsl #32
    // 0x7b6600: StoreField: r1->field_1b = r0
    //     0x7b6600: stur            w0, [x1, #0x1b]
    //     0x7b6604: ldurb           w16, [x1, #-1]
    //     0x7b6608: ldurb           w17, [x0, #-1]
    //     0x7b660c: and             x16, x17, x16, lsr #2
    //     0x7b6610: tst             x16, HEAP, lsr #32
    //     0x7b6614: b.eq            #0x7b661c
    //     0x7b6618: bl              #0xd6826c
    // 0x7b661c: r0 = Null
    //     0x7b661c: mov             x0, NULL
    // 0x7b6620: LeaveFrame
    //     0x7b6620: mov             SP, fp
    //     0x7b6624: ldp             fp, lr, [SP], #0x10
    // 0x7b6628: ret
    //     0x7b6628: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7b662c, size: 0x60
    // 0x7b662c: EnterFrame
    //     0x7b662c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b6630: mov             fp, SP
    // 0x7b6634: AllocStack(0x8)
    //     0x7b6634: sub             SP, SP, #8
    // 0x7b6638: SetupParameters()
    //     0x7b6638: ldr             x0, [fp, #0x10]
    //     0x7b663c: ldur            w2, [x0, #0x17]
    //     0x7b6640: add             x2, x2, HEAP, lsl #32
    // 0x7b6644: CheckStackOverflow
    //     0x7b6644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b6648: cmp             SP, x16
    //     0x7b664c: b.ls            #0x7b6684
    // 0x7b6650: LoadField: r0 = r2->field_f
    //     0x7b6650: ldur            w0, [x2, #0xf]
    // 0x7b6654: DecompressPointer r0
    //     0x7b6654: add             x0, x0, HEAP, lsl #32
    // 0x7b6658: stur            x0, [fp, #-8]
    // 0x7b665c: r1 = Function '<anonymous closure>':.
    //     0x7b665c: add             x1, PP, #0x40, lsl #12  ; [pp+0x400b0] AnonymousClosure: (0x7b668c), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7b61b8)
    //     0x7b6660: ldr             x1, [x1, #0xb0]
    // 0x7b6664: r0 = AllocateClosure()
    //     0x7b6664: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b6668: ldur            x16, [fp, #-8]
    // 0x7b666c: stp             x0, x16, [SP, #-0x10]!
    // 0x7b6670: r0 = setState()
    //     0x7b6670: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7b6674: add             SP, SP, #0x10
    // 0x7b6678: LeaveFrame
    //     0x7b6678: mov             SP, fp
    //     0x7b667c: ldp             fp, lr, [SP], #0x10
    // 0x7b6680: ret
    //     0x7b6680: ret             
    // 0x7b6684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b6684: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b6688: b               #0x7b6650
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7b668c, size: 0x20
    // 0x7b668c: ldr             x1, [SP]
    // 0x7b6690: LoadField: r2 = r1->field_17
    //     0x7b6690: ldur            w2, [x1, #0x17]
    // 0x7b6694: DecompressPointer r2
    //     0x7b6694: add             x2, x2, HEAP, lsl #32
    // 0x7b6698: LoadField: r1 = r2->field_f
    //     0x7b6698: ldur            w1, [x2, #0xf]
    // 0x7b669c: DecompressPointer r1
    //     0x7b669c: add             x1, x1, HEAP, lsl #32
    // 0x7b66a0: StoreField: r1->field_17 = rNULL
    //     0x7b66a0: stur            NULL, [x1, #0x17]
    // 0x7b66a4: r0 = Null
    //     0x7b66a4: mov             x0, NULL
    // 0x7b66a8: ret
    //     0x7b66a8: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0x85fbf4, size: 0x16c
    // 0x85fbf4: EnterFrame
    //     0x85fbf4: stp             fp, lr, [SP, #-0x10]!
    //     0x85fbf8: mov             fp, SP
    // 0x85fbfc: AllocStack(0x28)
    //     0x85fbfc: sub             SP, SP, #0x28
    // 0x85fc00: ldr             x0, [fp, #0x18]
    // 0x85fc04: LoadField: r1 = r0->field_13
    //     0x85fc04: ldur            w1, [x0, #0x13]
    // 0x85fc08: DecompressPointer r1
    //     0x85fc08: add             x1, x1, HEAP, lsl #32
    // 0x85fc0c: cmp             w1, NULL
    // 0x85fc10: b.eq            #0x85fd24
    // 0x85fc14: LoadField: d0 = r1->field_f
    //     0x85fc14: ldur            d0, [x1, #0xf]
    // 0x85fc18: stur            d0, [fp, #-0x28]
    // 0x85fc1c: LoadField: d1 = r1->field_7
    //     0x85fc1c: ldur            d1, [x1, #7]
    // 0x85fc20: stur            d1, [fp, #-0x20]
    // 0x85fc24: LoadField: r1 = r0->field_17
    //     0x85fc24: ldur            w1, [x0, #0x17]
    // 0x85fc28: DecompressPointer r1
    //     0x85fc28: add             x1, x1, HEAP, lsl #32
    // 0x85fc2c: cmp             w1, NULL
    // 0x85fc30: b.eq            #0x85fc40
    // 0x85fc34: r1 = Instance_Duration
    //     0x85fc34: add             x1, PP, #0x40, lsl #12  ; [pp+0x40030] Obj!Duration@b67b51
    //     0x85fc38: ldr             x1, [x1, #0x30]
    // 0x85fc3c: b               #0x85fc44
    // 0x85fc40: r1 = Instance_Duration
    //     0x85fc40: ldr             x1, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x85fc44: stur            x1, [fp, #-0x10]
    // 0x85fc48: LoadField: r2 = r0->field_1b
    //     0x85fc48: ldur            w2, [x0, #0x1b]
    // 0x85fc4c: DecompressPointer r2
    //     0x85fc4c: add             x2, x2, HEAP, lsl #32
    // 0x85fc50: stur            x2, [fp, #-8]
    // 0x85fc54: r0 = Magnifier()
    //     0x85fc54: bl              #0x85fd60  ; AllocateMagnifierStub -> Magnifier (size=0x20)
    // 0x85fc58: mov             x1, x0
    // 0x85fc5c: ldur            x0, [fp, #-8]
    // 0x85fc60: stur            x1, [fp, #-0x18]
    // 0x85fc64: StoreField: r1->field_b = r0
    //     0x85fc64: stur            w0, [x1, #0xb]
    // 0x85fc68: r0 = Instance_BorderRadius
    //     0x85fc68: add             x0, PP, #0x27, lsl #12  ; [pp+0x271a0] Obj!BorderRadius@b37511
    //     0x85fc6c: ldr             x0, [x0, #0x1a0]
    // 0x85fc70: StoreField: r1->field_f = r0
    //     0x85fc70: stur            w0, [x1, #0xf]
    // 0x85fc74: r0 = Instance_Color
    //     0x85fc74: add             x0, PP, #0x40, lsl #12  ; [pp+0x40038] Obj!Color@b5d871
    //     0x85fc78: ldr             x0, [x0, #0x38]
    // 0x85fc7c: StoreField: r1->field_13 = r0
    //     0x85fc7c: stur            w0, [x1, #0x13]
    // 0x85fc80: r0 = const [Instance of 'BoxShadow']
    //     0x85fc80: add             x0, PP, #0x40, lsl #12  ; [pp+0x40040] List<BoxShadow>(1)
    //     0x85fc84: ldr             x0, [x0, #0x40]
    // 0x85fc88: StoreField: r1->field_17 = r0
    //     0x85fc88: stur            w0, [x1, #0x17]
    // 0x85fc8c: r0 = Instance_Size
    //     0x85fc8c: add             x0, PP, #0x40, lsl #12  ; [pp+0x40048] Obj!Size@b5ecf1
    //     0x85fc90: ldr             x0, [x0, #0x48]
    // 0x85fc94: StoreField: r1->field_1b = r0
    //     0x85fc94: stur            w0, [x1, #0x1b]
    // 0x85fc98: r0 = AnimatedPositioned()
    //     0x85fc98: bl              #0x841220  ; AllocateAnimatedPositionedStub -> AnimatedPositioned (size=0x34)
    // 0x85fc9c: ldur            x1, [fp, #-0x18]
    // 0x85fca0: StoreField: r0->field_17 = r1
    //     0x85fca0: stur            w1, [x0, #0x17]
    // 0x85fca4: ldur            d0, [fp, #-0x20]
    // 0x85fca8: r1 = inline_Allocate_Double()
    //     0x85fca8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x85fcac: add             x1, x1, #0x10
    //     0x85fcb0: cmp             x2, x1
    //     0x85fcb4: b.ls            #0x85fd28
    //     0x85fcb8: str             x1, [THR, #0x60]  ; THR::top
    //     0x85fcbc: sub             x1, x1, #0xf
    //     0x85fcc0: mov             x2, #0xd108
    //     0x85fcc4: movk            x2, #3, lsl #16
    //     0x85fcc8: stur            x2, [x1, #-1]
    // 0x85fccc: StoreField: r1->field_7 = d0
    //     0x85fccc: stur            d0, [x1, #7]
    // 0x85fcd0: StoreField: r0->field_1b = r1
    //     0x85fcd0: stur            w1, [x0, #0x1b]
    // 0x85fcd4: ldur            d0, [fp, #-0x28]
    // 0x85fcd8: r1 = inline_Allocate_Double()
    //     0x85fcd8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x85fcdc: add             x1, x1, #0x10
    //     0x85fce0: cmp             x2, x1
    //     0x85fce4: b.ls            #0x85fd44
    //     0x85fce8: str             x1, [THR, #0x60]  ; THR::top
    //     0x85fcec: sub             x1, x1, #0xf
    //     0x85fcf0: mov             x2, #0xd108
    //     0x85fcf4: movk            x2, #3, lsl #16
    //     0x85fcf8: stur            x2, [x1, #-1]
    // 0x85fcfc: StoreField: r1->field_7 = d0
    //     0x85fcfc: stur            d0, [x1, #7]
    // 0x85fd00: StoreField: r0->field_1f = r1
    //     0x85fd00: stur            w1, [x0, #0x1f]
    // 0x85fd04: r1 = Instance__Linear
    //     0x85fd04: add             x1, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x85fd08: ldr             x1, [x1, #0x300]
    // 0x85fd0c: StoreField: r0->field_b = r1
    //     0x85fd0c: stur            w1, [x0, #0xb]
    // 0x85fd10: ldur            x1, [fp, #-0x10]
    // 0x85fd14: StoreField: r0->field_f = r1
    //     0x85fd14: stur            w1, [x0, #0xf]
    // 0x85fd18: LeaveFrame
    //     0x85fd18: mov             SP, fp
    //     0x85fd1c: ldp             fp, lr, [SP], #0x10
    // 0x85fd20: ret
    //     0x85fd20: ret             
    // 0x85fd24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85fd24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85fd28: SaveReg d0
    //     0x85fd28: str             q0, [SP, #-0x10]!
    // 0x85fd2c: SaveReg r0
    //     0x85fd2c: str             x0, [SP, #-8]!
    // 0x85fd30: r0 = AllocateDouble()
    //     0x85fd30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x85fd34: mov             x1, x0
    // 0x85fd38: RestoreReg r0
    //     0x85fd38: ldr             x0, [SP], #8
    // 0x85fd3c: RestoreReg d0
    //     0x85fd3c: ldr             q0, [SP], #0x10
    // 0x85fd40: b               #0x85fccc
    // 0x85fd44: SaveReg d0
    //     0x85fd44: str             q0, [SP, #-0x10]!
    // 0x85fd48: SaveReg r0
    //     0x85fd48: str             x0, [SP, #-8]!
    // 0x85fd4c: r0 = AllocateDouble()
    //     0x85fd4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x85fd50: mov             x1, x0
    // 0x85fd54: RestoreReg r0
    //     0x85fd54: ldr             x0, [SP], #8
    // 0x85fd58: RestoreReg d0
    //     0x85fd58: ldr             q0, [SP], #0x10
    // 0x85fd5c: b               #0x85fcfc
  }
  _ initState(/* No info */) {
    // ** addr: 0x9daa54, size: 0xa4
    // 0x9daa54: EnterFrame
    //     0x9daa54: stp             fp, lr, [SP, #-0x10]!
    //     0x9daa58: mov             fp, SP
    // 0x9daa5c: AllocStack(0x8)
    //     0x9daa5c: sub             SP, SP, #8
    // 0x9daa60: CheckStackOverflow
    //     0x9daa60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9daa64: cmp             SP, x16
    //     0x9daa68: b.ls            #0x9daaec
    // 0x9daa6c: ldr             x0, [fp, #0x10]
    // 0x9daa70: LoadField: r1 = r0->field_b
    //     0x9daa70: ldur            w1, [x0, #0xb]
    // 0x9daa74: DecompressPointer r1
    //     0x9daa74: add             x1, x1, HEAP, lsl #32
    // 0x9daa78: cmp             w1, NULL
    // 0x9daa7c: b.eq            #0x9daaf4
    // 0x9daa80: LoadField: r2 = r1->field_b
    //     0x9daa80: ldur            w2, [x1, #0xb]
    // 0x9daa84: DecompressPointer r2
    //     0x9daa84: add             x2, x2, HEAP, lsl #32
    // 0x9daa88: stur            x2, [fp, #-8]
    // 0x9daa8c: r1 = 1
    //     0x9daa8c: mov             x1, #1
    // 0x9daa90: r0 = AllocateContext()
    //     0x9daa90: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9daa94: mov             x1, x0
    // 0x9daa98: ldr             x0, [fp, #0x10]
    // 0x9daa9c: StoreField: r1->field_f = r0
    //     0x9daa9c: stur            w0, [x1, #0xf]
    // 0x9daaa0: mov             x2, x1
    // 0x9daaa4: r1 = Function '_determineMagnifierPositionAndFocalPoint@767515283':.
    //     0x9daaa4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40068] AnonymousClosure: (0x7b6170), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7b61b8)
    //     0x9daaa8: ldr             x1, [x1, #0x68]
    // 0x9daaac: r0 = AllocateClosure()
    //     0x9daaac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9daab0: mov             x1, x0
    // 0x9daab4: ldur            x0, [fp, #-8]
    // 0x9daab8: r2 = LoadClassIdInstr(r0)
    //     0x9daab8: ldur            x2, [x0, #-1]
    //     0x9daabc: ubfx            x2, x2, #0xc, #0x14
    // 0x9daac0: stp             x1, x0, [SP, #-0x10]!
    // 0x9daac4: mov             x0, x2
    // 0x9daac8: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x9daac8: mov             x17, #0xc3ab
    //     0x9daacc: add             lr, x0, x17
    //     0x9daad0: ldr             lr, [x21, lr, lsl #3]
    //     0x9daad4: blr             lr
    // 0x9daad8: add             SP, SP, #0x10
    // 0x9daadc: r0 = Null
    //     0x9daadc: mov             x0, NULL
    // 0x9daae0: LeaveFrame
    //     0x9daae0: mov             SP, fp
    //     0x9daae4: ldp             fp, lr, [SP], #0x10
    // 0x9daae8: ret
    //     0x9daae8: ret             
    // 0x9daaec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9daaec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9daaf0: b               #0x9daa6c
    // 0x9daaf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9daaf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4ad68, size: 0x18
    // 0xa4ad68: r4 = 7
    //     0xa4ad68: mov             x4, #7
    // 0xa4ad6c: r1 = Function 'dispose':.
    //     0xa4ad6c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b800] AnonymousClosure: (0xa4ad80), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::dispose (0xa51da4)
    //     0xa4ad70: ldr             x1, [x17, #0x800]
    // 0xa4ad74: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4ad74: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4ad78: LoadField: r0 = r24->field_17
    //     0xa4ad78: ldur            x0, [x24, #0x17]
    // 0xa4ad7c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4ad80, size: 0x48
    // 0xa4ad80: EnterFrame
    //     0xa4ad80: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ad84: mov             fp, SP
    // 0xa4ad88: ldr             x0, [fp, #0x10]
    // 0xa4ad8c: LoadField: r1 = r0->field_17
    //     0xa4ad8c: ldur            w1, [x0, #0x17]
    // 0xa4ad90: DecompressPointer r1
    //     0xa4ad90: add             x1, x1, HEAP, lsl #32
    // 0xa4ad94: CheckStackOverflow
    //     0xa4ad94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ad98: cmp             SP, x16
    //     0xa4ad9c: b.ls            #0xa4adc0
    // 0xa4ada0: LoadField: r0 = r1->field_f
    //     0xa4ada0: ldur            w0, [x1, #0xf]
    // 0xa4ada4: DecompressPointer r0
    //     0xa4ada4: add             x0, x0, HEAP, lsl #32
    // 0xa4ada8: SaveReg r0
    //     0xa4ada8: str             x0, [SP, #-8]!
    // 0xa4adac: r0 = dispose()
    //     0xa4adac: bl              #0xa51da4  ; [package:flutter/src/material/magnifier.dart] _TextMagnifierState::dispose
    // 0xa4adb0: add             SP, SP, #8
    // 0xa4adb4: LeaveFrame
    //     0xa4adb4: mov             SP, fp
    //     0xa4adb8: ldp             fp, lr, [SP], #0x10
    // 0xa4adbc: ret
    //     0xa4adbc: ret             
    // 0xa4adc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4adc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4adc4: b               #0xa4ada0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa51da4, size: 0xc4
    // 0xa51da4: EnterFrame
    //     0xa51da4: stp             fp, lr, [SP, #-0x10]!
    //     0xa51da8: mov             fp, SP
    // 0xa51dac: AllocStack(0x8)
    //     0xa51dac: sub             SP, SP, #8
    // 0xa51db0: CheckStackOverflow
    //     0xa51db0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51db4: cmp             SP, x16
    //     0xa51db8: b.ls            #0xa51e5c
    // 0xa51dbc: ldr             x0, [fp, #0x10]
    // 0xa51dc0: LoadField: r1 = r0->field_b
    //     0xa51dc0: ldur            w1, [x0, #0xb]
    // 0xa51dc4: DecompressPointer r1
    //     0xa51dc4: add             x1, x1, HEAP, lsl #32
    // 0xa51dc8: cmp             w1, NULL
    // 0xa51dcc: b.eq            #0xa51e64
    // 0xa51dd0: LoadField: r2 = r1->field_b
    //     0xa51dd0: ldur            w2, [x1, #0xb]
    // 0xa51dd4: DecompressPointer r2
    //     0xa51dd4: add             x2, x2, HEAP, lsl #32
    // 0xa51dd8: stur            x2, [fp, #-8]
    // 0xa51ddc: r1 = 1
    //     0xa51ddc: mov             x1, #1
    // 0xa51de0: r0 = AllocateContext()
    //     0xa51de0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa51de4: mov             x1, x0
    // 0xa51de8: ldr             x0, [fp, #0x10]
    // 0xa51dec: StoreField: r1->field_f = r0
    //     0xa51dec: stur            w0, [x1, #0xf]
    // 0xa51df0: mov             x2, x1
    // 0xa51df4: r1 = Function '_determineMagnifierPositionAndFocalPoint@767515283':.
    //     0xa51df4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40068] AnonymousClosure: (0x7b6170), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7b61b8)
    //     0xa51df8: ldr             x1, [x1, #0x68]
    // 0xa51dfc: r0 = AllocateClosure()
    //     0xa51dfc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa51e00: mov             x1, x0
    // 0xa51e04: ldur            x0, [fp, #-8]
    // 0xa51e08: r2 = LoadClassIdInstr(r0)
    //     0xa51e08: ldur            x2, [x0, #-1]
    //     0xa51e0c: ubfx            x2, x2, #0xc, #0x14
    // 0xa51e10: stp             x1, x0, [SP, #-0x10]!
    // 0xa51e14: mov             x0, x2
    // 0xa51e18: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xa51e18: mov             x17, #0xc2d6
    //     0xa51e1c: add             lr, x0, x17
    //     0xa51e20: ldr             lr, [x21, lr, lsl #3]
    //     0xa51e24: blr             lr
    // 0xa51e28: add             SP, SP, #0x10
    // 0xa51e2c: ldr             x0, [fp, #0x10]
    // 0xa51e30: LoadField: r1 = r0->field_17
    //     0xa51e30: ldur            w1, [x0, #0x17]
    // 0xa51e34: DecompressPointer r1
    //     0xa51e34: add             x1, x1, HEAP, lsl #32
    // 0xa51e38: cmp             w1, NULL
    // 0xa51e3c: b.eq            #0xa51e4c
    // 0xa51e40: SaveReg r1
    //     0xa51e40: str             x1, [SP, #-8]!
    // 0xa51e44: r0 = cancel()
    //     0xa51e44: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0xa51e48: add             SP, SP, #8
    // 0xa51e4c: r0 = Null
    //     0xa51e4c: mov             x0, NULL
    // 0xa51e50: LeaveFrame
    //     0xa51e50: mov             SP, fp
    //     0xa51e54: ldp             fp, lr, [SP], #0x10
    // 0xa51e58: ret
    //     0xa51e58: ret             
    // 0xa51e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa51e5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa51e60: b               #0xa51dbc
    // 0xa51e64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa51e64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa61620, size: 0x3c
    // 0xa61620: EnterFrame
    //     0xa61620: stp             fp, lr, [SP, #-0x10]!
    //     0xa61624: mov             fp, SP
    // 0xa61628: CheckStackOverflow
    //     0xa61628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6162c: cmp             SP, x16
    //     0xa61630: b.ls            #0xa61654
    // 0xa61634: ldr             x16, [fp, #0x10]
    // 0xa61638: SaveReg r16
    //     0xa61638: str             x16, [SP, #-8]!
    // 0xa6163c: r0 = _determineMagnifierPositionAndFocalPoint()
    //     0xa6163c: bl              #0x7b61b8  ; [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint
    // 0xa61640: add             SP, SP, #8
    // 0xa61644: r0 = Null
    //     0xa61644: mov             x0, NULL
    // 0xa61648: LeaveFrame
    //     0xa61648: mov             SP, fp
    //     0xa6164c: ldp             fp, lr, [SP], #0x10
    // 0xa61650: ret
    //     0xa61650: ret             
    // 0xa61654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61654: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61658: b               #0xa61634
  }
}

// class id: 3850, size: 0x20, field offset: 0xc
//   const constructor, 
class Magnifier extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb23014, size: 0xf8
    // 0xb23014: EnterFrame
    //     0xb23014: stp             fp, lr, [SP, #-0x10]!
    //     0xb23018: mov             fp, SP
    // 0xb2301c: AllocStack(0x18)
    //     0xb2301c: sub             SP, SP, #0x18
    // 0xb23020: CheckStackOverflow
    //     0xb23020: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb23024: cmp             SP, x16
    //     0xb23028: b.ls            #0xb23104
    // 0xb2302c: r0 = RoundedRectangleBorder()
    //     0xb2302c: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xb23030: mov             x1, x0
    // 0xb23034: r0 = Instance_BorderRadius
    //     0xb23034: add             x0, PP, #0x27, lsl #12  ; [pp+0x271a0] Obj!BorderRadius@b37511
    //     0xb23038: ldr             x0, [x0, #0x1a0]
    // 0xb2303c: stur            x1, [fp, #-8]
    // 0xb23040: StoreField: r1->field_b = r0
    //     0xb23040: stur            w0, [x1, #0xb]
    // 0xb23044: r0 = Instance_BorderSide
    //     0xb23044: add             x0, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xb23048: ldr             x0, [x0, #0x2f0]
    // 0xb2304c: StoreField: r1->field_7 = r0
    //     0xb2304c: stur            w0, [x1, #7]
    // 0xb23050: r0 = MagnifierDecoration()
    //     0xb23050: bl              #0xb1cef4  ; AllocateMagnifierDecorationStub -> MagnifierDecoration (size=0x24)
    // 0xb23054: d0 = 1.000000
    //     0xb23054: fmov            d0, #1.00000000
    // 0xb23058: stur            x0, [fp, #-0x10]
    // 0xb2305c: StoreField: r0->field_1b = d0
    //     0xb2305c: stur            d0, [x0, #0x1b]
    // 0xb23060: r1 = const [Instance of 'BoxShadow']
    //     0xb23060: add             x1, PP, #0x40, lsl #12  ; [pp+0x40040] List<BoxShadow>(1)
    //     0xb23064: ldr             x1, [x1, #0x40]
    // 0xb23068: StoreField: r0->field_13 = r1
    //     0xb23068: stur            w1, [x0, #0x13]
    // 0xb2306c: ldur            x1, [fp, #-8]
    // 0xb23070: StoreField: r0->field_17 = r1
    //     0xb23070: stur            w1, [x0, #0x17]
    // 0xb23074: ldr             x1, [fp, #0x18]
    // 0xb23078: LoadField: r2 = r1->field_b
    //     0xb23078: ldur            w2, [x1, #0xb]
    // 0xb2307c: DecompressPointer r2
    //     0xb2307c: add             x2, x2, HEAP, lsl #32
    // 0xb23080: stur            x2, [fp, #-8]
    // 0xb23084: r0 = Offset()
    //     0xb23084: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb23088: d0 = 0.000000
    //     0xb23088: eor             v0.16b, v0.16b, v0.16b
    // 0xb2308c: StoreField: r0->field_7 = d0
    //     0xb2308c: stur            d0, [x0, #7]
    // 0xb23090: d0 = 40.950000
    //     0xb23090: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b7f8] IMM: double(40.95) from 0x404479999999999a
    //     0xb23094: ldr             d0, [x17, #0x7f8]
    // 0xb23098: StoreField: r0->field_f = d0
    //     0xb23098: stur            d0, [x0, #0xf]
    // 0xb2309c: ldur            x16, [fp, #-8]
    // 0xb230a0: stp             x0, x16, [SP, #-0x10]!
    // 0xb230a4: r0 = +()
    //     0xb230a4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xb230a8: add             SP, SP, #0x10
    // 0xb230ac: stur            x0, [fp, #-8]
    // 0xb230b0: r0 = ColoredBox()
    //     0xb230b0: bl              #0x99f588  ; AllocateColoredBoxStub -> ColoredBox (size=0x14)
    // 0xb230b4: mov             x1, x0
    // 0xb230b8: r0 = Instance_Color
    //     0xb230b8: add             x0, PP, #0x40, lsl #12  ; [pp+0x40038] Obj!Color@b5d871
    //     0xb230bc: ldr             x0, [x0, #0x38]
    // 0xb230c0: stur            x1, [fp, #-0x18]
    // 0xb230c4: StoreField: r1->field_f = r0
    //     0xb230c4: stur            w0, [x1, #0xf]
    // 0xb230c8: r0 = RawMagnifier()
    //     0xb230c8: bl              #0xb1cee8  ; AllocateRawMagnifierStub -> RawMagnifier (size=0x24)
    // 0xb230cc: ldur            x1, [fp, #-0x18]
    // 0xb230d0: StoreField: r0->field_b = r1
    //     0xb230d0: stur            w1, [x0, #0xb]
    // 0xb230d4: ldur            x1, [fp, #-0x10]
    // 0xb230d8: StoreField: r0->field_f = r1
    //     0xb230d8: stur            w1, [x0, #0xf]
    // 0xb230dc: ldur            x1, [fp, #-8]
    // 0xb230e0: StoreField: r0->field_13 = r1
    //     0xb230e0: stur            w1, [x0, #0x13]
    // 0xb230e4: d0 = 1.250000
    //     0xb230e4: fmov            d0, #1.25000000
    // 0xb230e8: StoreField: r0->field_17 = d0
    //     0xb230e8: stur            d0, [x0, #0x17]
    // 0xb230ec: r1 = Instance_Size
    //     0xb230ec: add             x1, PP, #0x40, lsl #12  ; [pp+0x40048] Obj!Size@b5ecf1
    //     0xb230f0: ldr             x1, [x1, #0x48]
    // 0xb230f4: StoreField: r0->field_1f = r1
    //     0xb230f4: stur            w1, [x0, #0x1f]
    // 0xb230f8: LeaveFrame
    //     0xb230f8: mov             SP, fp
    //     0xb230fc: ldp             fp, lr, [SP], #0x10
    // 0xb23100: ret
    //     0xb23100: ret             
    // 0xb23104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23104: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23108: b               #0xb2302c
  }
}

// class id: 4148, size: 0x10, field offset: 0xc
//   const constructor, 
class TextMagnifier extends StatefulWidget {

  static late TextMagnifierConfiguration adaptiveMagnifierConfiguration; // offset: 0xdc8

  static TextMagnifierConfiguration adaptiveMagnifierConfiguration() {
    // ** addr: 0x872ba0, size: 0x78
    // 0x872ba0: EnterFrame
    //     0x872ba0: stp             fp, lr, [SP, #-0x10]!
    //     0x872ba4: mov             fp, SP
    // 0x872ba8: AllocStack(0x10)
    //     0x872ba8: sub             SP, SP, #0x10
    // 0x872bac: CheckStackOverflow
    //     0x872bac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872bb0: cmp             SP, x16
    //     0x872bb4: b.ls            #0x872c10
    // 0x872bb8: r0 = defaultTargetPlatform()
    //     0x872bb8: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0x872bbc: r16 = Instance_TargetPlatform
    //     0x872bbc: ldr             x16, [PP, #0x43b0]  ; [pp+0x43b0] Obj!TargetPlatform@b65d51
    // 0x872bc0: cmp             w0, w16
    // 0x872bc4: r16 = true
    //     0x872bc4: add             x16, NULL, #0x20  ; true
    // 0x872bc8: r17 = false
    //     0x872bc8: add             x17, NULL, #0x30  ; false
    // 0x872bcc: csel            x1, x16, x17, eq
    // 0x872bd0: stur            x1, [fp, #-8]
    // 0x872bd4: r0 = TextMagnifierConfiguration()
    //     0x872bd4: bl              #0x872c18  ; AllocateTextMagnifierConfigurationStub -> TextMagnifierConfiguration (size=0x10)
    // 0x872bd8: mov             x3, x0
    // 0x872bdc: ldur            x0, [fp, #-8]
    // 0x872be0: stur            x3, [fp, #-0x10]
    // 0x872be4: StoreField: r3->field_b = r0
    //     0x872be4: stur            w0, [x3, #0xb]
    // 0x872be8: r1 = Function '<anonymous closure>': static.
    //     0x872be8: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2df80] AnonymousClosure: static (0x872c24), in [package:flutter/src/material/magnifier.dart] TextMagnifier::adaptiveMagnifierConfiguration (0x872ba0)
    //     0x872bec: ldr             x1, [x1, #0xf80]
    // 0x872bf0: r2 = Null
    //     0x872bf0: mov             x2, NULL
    // 0x872bf4: r0 = AllocateClosure()
    //     0x872bf4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x872bf8: mov             x1, x0
    // 0x872bfc: ldur            x0, [fp, #-0x10]
    // 0x872c00: StoreField: r0->field_7 = r1
    //     0x872c00: stur            w1, [x0, #7]
    // 0x872c04: LeaveFrame
    //     0x872c04: mov             SP, fp
    //     0x872c08: ldp             fp, lr, [SP], #0x10
    // 0x872c0c: ret
    //     0x872c0c: ret             
    // 0x872c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872c10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872c14: b               #0x872bb8
  }
  [closure] static StatefulWidget? <anonymous closure>(dynamic, BuildContext, MagnifierController, ValueNotifier<MagnifierInfo>) {
    // ** addr: 0x872c24, size: 0xbc
    // 0x872c24: EnterFrame
    //     0x872c24: stp             fp, lr, [SP, #-0x10]!
    //     0x872c28: mov             fp, SP
    // 0x872c2c: CheckStackOverflow
    //     0x872c2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872c30: cmp             SP, x16
    //     0x872c34: b.ls            #0x872cd8
    // 0x872c38: r0 = defaultTargetPlatform()
    //     0x872c38: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0x872c3c: LoadField: r1 = r0->field_7
    //     0x872c3c: ldur            x1, [x0, #7]
    // 0x872c40: cmp             x1, #2
    // 0x872c44: b.gt            #0x872cc8
    // 0x872c48: cmp             x1, #1
    // 0x872c4c: b.gt            #0x872c7c
    // 0x872c50: cmp             x1, #0
    // 0x872c54: b.gt            #0x872cc8
    // 0x872c58: ldr             x0, [fp, #0x10]
    // 0x872c5c: r0 = TextMagnifier()
    //     0x872c5c: bl              #0x872cec  ; AllocateTextMagnifierStub -> TextMagnifier (size=0x10)
    // 0x872c60: mov             x1, x0
    // 0x872c64: ldr             x0, [fp, #0x10]
    // 0x872c68: StoreField: r1->field_b = r0
    //     0x872c68: stur            w0, [x1, #0xb]
    // 0x872c6c: mov             x0, x1
    // 0x872c70: LeaveFrame
    //     0x872c70: mov             SP, fp
    //     0x872c74: ldp             fp, lr, [SP], #0x10
    // 0x872c78: ret
    //     0x872c78: ret             
    // 0x872c7c: ldr             x1, [fp, #0x18]
    // 0x872c80: ldr             x0, [fp, #0x10]
    // 0x872c84: r0 = CupertinoTextMagnifier()
    //     0x872c84: bl              #0x872ce0  ; AllocateCupertinoTextMagnifierStub -> CupertinoTextMagnifier (size=0x30)
    // 0x872c88: r1 = Instance_Cubic
    //     0x872c88: add             x1, PP, #0x20, lsl #12  ; [pp+0x20970] Obj!Cubic<double>@b4f3a1
    //     0x872c8c: ldr             x1, [x1, #0x970]
    // 0x872c90: StoreField: r0->field_b = r1
    //     0x872c90: stur            w1, [x0, #0xb]
    // 0x872c94: ldr             x1, [fp, #0x18]
    // 0x872c98: StoreField: r0->field_f = r1
    //     0x872c98: stur            w1, [x0, #0xf]
    // 0x872c9c: d0 = 10.000000
    //     0x872c9c: fmov            d0, #10.00000000
    // 0x872ca0: StoreField: r0->field_13 = d0
    //     0x872ca0: stur            d0, [x0, #0x13]
    // 0x872ca4: d1 = 48.000000
    //     0x872ca4: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fbd0] IMM: double(48) from 0x4048000000000000
    //     0x872ca8: ldr             d1, [x17, #0xbd0]
    // 0x872cac: StoreField: r0->field_1b = d1
    //     0x872cac: stur            d1, [x0, #0x1b]
    // 0x872cb0: StoreField: r0->field_23 = d0
    //     0x872cb0: stur            d0, [x0, #0x23]
    // 0x872cb4: ldr             x1, [fp, #0x10]
    // 0x872cb8: StoreField: r0->field_2b = r1
    //     0x872cb8: stur            w1, [x0, #0x2b]
    // 0x872cbc: LeaveFrame
    //     0x872cbc: mov             SP, fp
    //     0x872cc0: ldp             fp, lr, [SP], #0x10
    // 0x872cc4: ret
    //     0x872cc4: ret             
    // 0x872cc8: r0 = Null
    //     0x872cc8: mov             x0, NULL
    // 0x872ccc: LeaveFrame
    //     0x872ccc: mov             SP, fp
    //     0x872cd0: ldp             fp, lr, [SP], #0x10
    // 0x872cd4: ret
    //     0x872cd4: ret             
    // 0x872cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872cd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872cdc: b               #0x872c38
  }
  _ createState(/* No info */) {
    // ** addr: 0xa4094c, size: 0x28
    // 0xa4094c: EnterFrame
    //     0xa4094c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40950: mov             fp, SP
    // 0xa40954: r1 = <TextMagnifier>
    //     0xa40954: add             x1, PP, #0x37, lsl #12  ; [pp+0x377d0] TypeArguments: <TextMagnifier>
    //     0xa40958: ldr             x1, [x1, #0x7d0]
    // 0xa4095c: r0 = _TextMagnifierState()
    //     0xa4095c: bl              #0xa40974  ; Allocate_TextMagnifierStateStub -> _TextMagnifierState (size=0x20)
    // 0xa40960: r1 = Instance_Offset
    //     0xa40960: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa40964: StoreField: r0->field_1b = r1
    //     0xa40964: stur            w1, [x0, #0x1b]
    // 0xa40968: LeaveFrame
    //     0xa40968: mov             SP, fp
    //     0xa4096c: ldp             fp, lr, [SP], #0x10
    // 0xa40970: ret
    //     0xa40970: ret             
  }
}

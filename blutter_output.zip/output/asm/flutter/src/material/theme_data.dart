// lib: , url: package:flutter/src/material/theme_data.dart

// class id: 1049331, size: 0x8
class :: {
}

// class id: 2122, size: 0x18, field offset: 0x8
class _FifoCache<X0, X1> extends Object {

  _ putIfAbsent(/* No info */) {
    // ** addr: 0x6cbd04, size: 0x134
    // 0x6cbd04: EnterFrame
    //     0x6cbd04: stp             fp, lr, [SP, #-0x10]!
    //     0x6cbd08: mov             fp, SP
    // 0x6cbd0c: AllocStack(0x10)
    //     0x6cbd0c: sub             SP, SP, #0x10
    // 0x6cbd10: CheckStackOverflow
    //     0x6cbd10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cbd14: cmp             SP, x16
    //     0x6cbd18: b.ls            #0x6cbe30
    // 0x6cbd1c: ldr             x3, [fp, #0x20]
    // 0x6cbd20: LoadField: r2 = r3->field_7
    //     0x6cbd20: ldur            w2, [x3, #7]
    // 0x6cbd24: DecompressPointer r2
    //     0x6cbd24: add             x2, x2, HEAP, lsl #32
    // 0x6cbd28: ldr             x0, [fp, #0x10]
    // 0x6cbd2c: r1 = Null
    //     0x6cbd2c: mov             x1, NULL
    // 0x6cbd30: r8 = (dynamic this) => X1
    //     0x6cbd30: ldr             x8, [PP, #0x1c80]  ; [pp+0x1c80] FunctionType: (dynamic this) => X1
    // 0x6cbd34: LoadField: r9 = r8->field_7
    //     0x6cbd34: ldur            x9, [x8, #7]
    // 0x6cbd38: r3 = Null
    //     0x6cbd38: add             x3, PP, #0xe, lsl #12  ; [pp+0xe068] Null
    //     0x6cbd3c: ldr             x3, [x3, #0x68]
    // 0x6cbd40: blr             x9
    // 0x6cbd44: ldr             x0, [fp, #0x20]
    // 0x6cbd48: LoadField: r1 = r0->field_b
    //     0x6cbd48: ldur            w1, [x0, #0xb]
    // 0x6cbd4c: DecompressPointer r1
    //     0x6cbd4c: add             x1, x1, HEAP, lsl #32
    // 0x6cbd50: stur            x1, [fp, #-8]
    // 0x6cbd54: ldr             x16, [fp, #0x18]
    // 0x6cbd58: stp             x16, x1, [SP, #-0x10]!
    // 0x6cbd5c: r0 = _getValueOrData()
    //     0x6cbd5c: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6cbd60: add             SP, SP, #0x10
    // 0x6cbd64: mov             x1, x0
    // 0x6cbd68: ldur            x0, [fp, #-8]
    // 0x6cbd6c: LoadField: r2 = r0->field_f
    //     0x6cbd6c: ldur            w2, [x0, #0xf]
    // 0x6cbd70: DecompressPointer r2
    //     0x6cbd70: add             x2, x2, HEAP, lsl #32
    // 0x6cbd74: cmp             w2, w1
    // 0x6cbd78: b.ne            #0x6cbd80
    // 0x6cbd7c: r1 = Null
    //     0x6cbd7c: mov             x1, NULL
    // 0x6cbd80: cmp             w1, NULL
    // 0x6cbd84: b.eq            #0x6cbd98
    // 0x6cbd88: mov             x0, x1
    // 0x6cbd8c: LeaveFrame
    //     0x6cbd8c: mov             SP, fp
    //     0x6cbd90: ldp             fp, lr, [SP], #0x10
    // 0x6cbd94: ret
    //     0x6cbd94: ret             
    // 0x6cbd98: LoadField: r1 = r0->field_13
    //     0x6cbd98: ldur            w1, [x0, #0x13]
    // 0x6cbd9c: DecompressPointer r1
    //     0x6cbd9c: add             x1, x1, HEAP, lsl #32
    // 0x6cbda0: r2 = LoadInt32Instr(r1)
    //     0x6cbda0: sbfx            x2, x1, #1, #0x1f
    // 0x6cbda4: asr             x1, x2, #1
    // 0x6cbda8: LoadField: r2 = r0->field_17
    //     0x6cbda8: ldur            w2, [x0, #0x17]
    // 0x6cbdac: DecompressPointer r2
    //     0x6cbdac: add             x2, x2, HEAP, lsl #32
    // 0x6cbdb0: r3 = LoadInt32Instr(r2)
    //     0x6cbdb0: sbfx            x3, x2, #1, #0x1f
    // 0x6cbdb4: sub             x2, x1, x3
    // 0x6cbdb8: cmp             x2, #5
    // 0x6cbdbc: b.ne            #0x6cbde8
    // 0x6cbdc0: SaveReg r0
    //     0x6cbdc0: str             x0, [SP, #-8]!
    // 0x6cbdc4: r0 = keys()
    //     0x6cbdc4: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x6cbdc8: add             SP, SP, #8
    // 0x6cbdcc: SaveReg r0
    //     0x6cbdcc: str             x0, [SP, #-8]!
    // 0x6cbdd0: r0 = first()
    //     0x6cbdd0: bl              #0x6b8208  ; [dart:core] Iterable::first
    // 0x6cbdd4: add             SP, SP, #8
    // 0x6cbdd8: ldur            x16, [fp, #-8]
    // 0x6cbddc: stp             x0, x16, [SP, #-0x10]!
    // 0x6cbde0: r0 = remove()
    //     0x6cbde0: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6cbde4: add             SP, SP, #0x10
    // 0x6cbde8: ldr             x16, [fp, #0x10]
    // 0x6cbdec: SaveReg r16
    //     0x6cbdec: str             x16, [SP, #-8]!
    // 0x6cbdf0: ldr             x0, [fp, #0x10]
    // 0x6cbdf4: ClosureCall
    //     0x6cbdf4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x6cbdf8: ldur            x2, [x0, #0x1f]
    //     0x6cbdfc: blr             x2
    // 0x6cbe00: add             SP, SP, #8
    // 0x6cbe04: stur            x0, [fp, #-0x10]
    // 0x6cbe08: ldur            x16, [fp, #-8]
    // 0x6cbe0c: ldr             lr, [fp, #0x18]
    // 0x6cbe10: stp             lr, x16, [SP, #-0x10]!
    // 0x6cbe14: SaveReg r0
    //     0x6cbe14: str             x0, [SP, #-8]!
    // 0x6cbe18: r0 = []=()
    //     0x6cbe18: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6cbe1c: add             SP, SP, #0x18
    // 0x6cbe20: ldur            x0, [fp, #-0x10]
    // 0x6cbe24: LeaveFrame
    //     0x6cbe24: mov             SP, fp
    //     0x6cbe28: ldp             fp, lr, [SP], #0x10
    // 0x6cbe2c: ret
    //     0x6cbe2c: ret             
    // 0x6cbe30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cbe30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cbe34: b               #0x6cbd1c
  }
}

// class id: 2123, size: 0x10, field offset: 0x8
//   const constructor, 
class _IdentityThemeDataCacheKey extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb0dff4, size: 0x78
    // 0xb0dff4: EnterFrame
    //     0xb0dff4: stp             fp, lr, [SP, #-0x10]!
    //     0xb0dff8: mov             fp, SP
    // 0xb0dffc: AllocStack(0x8)
    //     0xb0dffc: sub             SP, SP, #8
    // 0xb0e000: CheckStackOverflow
    //     0xb0e000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0e004: cmp             SP, x16
    //     0xb0e008: b.ls            #0xb0e064
    // 0xb0e00c: ldr             x0, [fp, #0x10]
    // 0xb0e010: LoadField: r1 = r0->field_7
    //     0xb0e010: ldur            w1, [x0, #7]
    // 0xb0e014: DecompressPointer r1
    //     0xb0e014: add             x1, x1, HEAP, lsl #32
    // 0xb0e018: SaveReg r1
    //     0xb0e018: str             x1, [SP, #-8]!
    // 0xb0e01c: r0 = _getHash()
    //     0xb0e01c: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xb0e020: add             SP, SP, #8
    // 0xb0e024: mov             x1, x0
    // 0xb0e028: ldr             x0, [fp, #0x10]
    // 0xb0e02c: stur            x1, [fp, #-8]
    // 0xb0e030: LoadField: r2 = r0->field_b
    //     0xb0e030: ldur            w2, [x0, #0xb]
    // 0xb0e034: DecompressPointer r2
    //     0xb0e034: add             x2, x2, HEAP, lsl #32
    // 0xb0e038: SaveReg r2
    //     0xb0e038: str             x2, [SP, #-8]!
    // 0xb0e03c: r0 = _getHash()
    //     0xb0e03c: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0xb0e040: add             SP, SP, #8
    // 0xb0e044: ldur            x1, [fp, #-8]
    // 0xb0e048: r2 = LoadInt32Instr(r1)
    //     0xb0e048: sbfx            x2, x1, #1, #0x1f
    // 0xb0e04c: r1 = LoadInt32Instr(r0)
    //     0xb0e04c: sbfx            x1, x0, #1, #0x1f
    // 0xb0e050: eor             x3, x2, x1
    // 0xb0e054: lsl             x0, x3, #1
    // 0xb0e058: LeaveFrame
    //     0xb0e058: mov             SP, fp
    //     0xb0e05c: ldp             fp, lr, [SP], #0x10
    // 0xb0e060: ret
    //     0xb0e060: ret             
    // 0xb0e064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0e064: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0e068: b               #0xb0e00c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9c6a0, size: 0x80
    // 0xc9c6a0: ldr             x1, [SP]
    // 0xc9c6a4: cmp             w1, NULL
    // 0xc9c6a8: b.ne            #0xc9c6b4
    // 0xc9c6ac: r0 = false
    //     0xc9c6ac: add             x0, NULL, #0x30  ; false
    // 0xc9c6b0: ret
    //     0xc9c6b0: ret             
    // 0xc9c6b4: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9c6b4: mov             x2, #0x76
    //     0xc9c6b8: tbz             w1, #0, #0xc9c6c8
    //     0xc9c6bc: ldur            x2, [x1, #-1]
    //     0xc9c6c0: ubfx            x2, x2, #0xc, #0x14
    //     0xc9c6c4: lsl             x2, x2, #1
    // 0xc9c6c8: r17 = 4246
    //     0xc9c6c8: mov             x17, #0x1096
    // 0xc9c6cc: cmp             w2, w17
    // 0xc9c6d0: b.ne            #0xc9c718
    // 0xc9c6d4: ldr             x2, [SP, #8]
    // 0xc9c6d8: LoadField: r3 = r1->field_7
    //     0xc9c6d8: ldur            w3, [x1, #7]
    // 0xc9c6dc: DecompressPointer r3
    //     0xc9c6dc: add             x3, x3, HEAP, lsl #32
    // 0xc9c6e0: LoadField: r4 = r2->field_7
    //     0xc9c6e0: ldur            w4, [x2, #7]
    // 0xc9c6e4: DecompressPointer r4
    //     0xc9c6e4: add             x4, x4, HEAP, lsl #32
    // 0xc9c6e8: cmp             w3, w4
    // 0xc9c6ec: b.ne            #0xc9c718
    // 0xc9c6f0: LoadField: r3 = r1->field_b
    //     0xc9c6f0: ldur            w3, [x1, #0xb]
    // 0xc9c6f4: DecompressPointer r3
    //     0xc9c6f4: add             x3, x3, HEAP, lsl #32
    // 0xc9c6f8: LoadField: r1 = r2->field_b
    //     0xc9c6f8: ldur            w1, [x2, #0xb]
    // 0xc9c6fc: DecompressPointer r1
    //     0xc9c6fc: add             x1, x1, HEAP, lsl #32
    // 0xc9c700: cmp             w3, w1
    // 0xc9c704: r16 = true
    //     0xc9c704: add             x16, NULL, #0x20  ; true
    // 0xc9c708: r17 = false
    //     0xc9c708: add             x17, NULL, #0x30  ; false
    // 0xc9c70c: csel            x2, x16, x17, eq
    // 0xc9c710: mov             x0, x2
    // 0xc9c714: b               #0xc9c71c
    // 0xc9c718: r0 = false
    //     0xc9c718: add             x0, NULL, #0x30  ; false
    // 0xc9c71c: ret
    //     0xc9c71c: ret             
  }
}

// class id: 2124, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ThemeExtension<X0> extends Object {
}

// class id: 2662, size: 0x2c, field offset: 0x24
class MaterialBasedCupertinoThemeData extends CupertinoThemeData {

  _ MaterialBasedCupertinoThemeData._(/* No info */) {
    // ** addr: 0x83d370, size: 0x130
    // 0x83d370: EnterFrame
    //     0x83d370: stp             fp, lr, [SP, #-0x10]!
    //     0x83d374: mov             fp, SP
    // 0x83d378: r1 = Instance__CupertinoThemeDefaults
    //     0x83d378: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2db70] Obj!_CupertinoThemeDefaults@b38811
    //     0x83d37c: ldr             x1, [x1, #0xb70]
    // 0x83d380: ldr             x0, [fp, #0x18]
    // 0x83d384: ldr             x2, [fp, #0x20]
    // 0x83d388: StoreField: r2->field_23 = r0
    //     0x83d388: stur            w0, [x2, #0x23]
    //     0x83d38c: ldurb           w16, [x2, #-1]
    //     0x83d390: ldurb           w17, [x0, #-1]
    //     0x83d394: and             x16, x17, x16, lsr #2
    //     0x83d398: tst             x16, HEAP, lsr #32
    //     0x83d39c: b.eq            #0x83d3a4
    //     0x83d3a0: bl              #0xd6828c
    // 0x83d3a4: ldr             x0, [fp, #0x10]
    // 0x83d3a8: StoreField: r2->field_27 = r0
    //     0x83d3a8: stur            w0, [x2, #0x27]
    //     0x83d3ac: ldurb           w16, [x2, #-1]
    //     0x83d3b0: ldurb           w17, [x0, #-1]
    //     0x83d3b4: and             x16, x17, x16, lsr #2
    //     0x83d3b8: tst             x16, HEAP, lsr #32
    //     0x83d3bc: b.eq            #0x83d3c4
    //     0x83d3c0: bl              #0xd6828c
    // 0x83d3c4: ldr             x3, [fp, #0x10]
    // 0x83d3c8: LoadField: r0 = r3->field_7
    //     0x83d3c8: ldur            w0, [x3, #7]
    // 0x83d3cc: DecompressPointer r0
    //     0x83d3cc: add             x0, x0, HEAP, lsl #32
    // 0x83d3d0: LoadField: r4 = r3->field_b
    //     0x83d3d0: ldur            w4, [x3, #0xb]
    // 0x83d3d4: DecompressPointer r4
    //     0x83d3d4: add             x4, x4, HEAP, lsl #32
    // 0x83d3d8: LoadField: r5 = r3->field_f
    //     0x83d3d8: ldur            w5, [x3, #0xf]
    // 0x83d3dc: DecompressPointer r5
    //     0x83d3dc: add             x5, x5, HEAP, lsl #32
    // 0x83d3e0: LoadField: r6 = r3->field_17
    //     0x83d3e0: ldur            w6, [x3, #0x17]
    // 0x83d3e4: DecompressPointer r6
    //     0x83d3e4: add             x6, x6, HEAP, lsl #32
    // 0x83d3e8: LoadField: r7 = r3->field_1b
    //     0x83d3e8: ldur            w7, [x3, #0x1b]
    // 0x83d3ec: DecompressPointer r7
    //     0x83d3ec: add             x7, x7, HEAP, lsl #32
    // 0x83d3f0: StoreField: r2->field_1f = r1
    //     0x83d3f0: stur            w1, [x2, #0x1f]
    // 0x83d3f4: StoreField: r2->field_7 = r0
    //     0x83d3f4: stur            w0, [x2, #7]
    //     0x83d3f8: ldurb           w16, [x2, #-1]
    //     0x83d3fc: ldurb           w17, [x0, #-1]
    //     0x83d400: and             x16, x17, x16, lsr #2
    //     0x83d404: tst             x16, HEAP, lsr #32
    //     0x83d408: b.eq            #0x83d410
    //     0x83d40c: bl              #0xd6828c
    // 0x83d410: mov             x0, x4
    // 0x83d414: StoreField: r2->field_b = r0
    //     0x83d414: stur            w0, [x2, #0xb]
    //     0x83d418: ldurb           w16, [x2, #-1]
    //     0x83d41c: ldurb           w17, [x0, #-1]
    //     0x83d420: and             x16, x17, x16, lsr #2
    //     0x83d424: tst             x16, HEAP, lsr #32
    //     0x83d428: b.eq            #0x83d430
    //     0x83d42c: bl              #0xd6828c
    // 0x83d430: mov             x0, x5
    // 0x83d434: StoreField: r2->field_f = r0
    //     0x83d434: stur            w0, [x2, #0xf]
    //     0x83d438: ldurb           w16, [x2, #-1]
    //     0x83d43c: ldurb           w17, [x0, #-1]
    //     0x83d440: and             x16, x17, x16, lsr #2
    //     0x83d444: tst             x16, HEAP, lsr #32
    //     0x83d448: b.eq            #0x83d450
    //     0x83d44c: bl              #0xd6828c
    // 0x83d450: mov             x0, x6
    // 0x83d454: StoreField: r2->field_17 = r0
    //     0x83d454: stur            w0, [x2, #0x17]
    //     0x83d458: ldurb           w16, [x2, #-1]
    //     0x83d45c: ldurb           w17, [x0, #-1]
    //     0x83d460: and             x16, x17, x16, lsr #2
    //     0x83d464: tst             x16, HEAP, lsr #32
    //     0x83d468: b.eq            #0x83d470
    //     0x83d46c: bl              #0xd6828c
    // 0x83d470: mov             x0, x7
    // 0x83d474: StoreField: r2->field_1b = r0
    //     0x83d474: stur            w0, [x2, #0x1b]
    //     0x83d478: ldurb           w16, [x2, #-1]
    //     0x83d47c: ldurb           w17, [x0, #-1]
    //     0x83d480: and             x16, x17, x16, lsr #2
    //     0x83d484: tst             x16, HEAP, lsr #32
    //     0x83d488: b.eq            #0x83d490
    //     0x83d48c: bl              #0xd6828c
    // 0x83d490: r0 = Null
    //     0x83d490: mov             x0, NULL
    // 0x83d494: LeaveFrame
    //     0x83d494: mov             SP, fp
    //     0x83d498: ldp             fp, lr, [SP], #0x10
    // 0x83d49c: ret
    //     0x83d49c: ret             
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0xccc904, size: 0x7c
    // 0xccc904: EnterFrame
    //     0xccc904: stp             fp, lr, [SP, #-0x10]!
    //     0xccc908: mov             fp, SP
    // 0xccc90c: AllocStack(0x18)
    //     0xccc90c: sub             SP, SP, #0x18
    // 0xccc910: CheckStackOverflow
    //     0xccc910: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccc914: cmp             SP, x16
    //     0xccc918: b.ls            #0xccc978
    // 0xccc91c: ldr             x0, [fp, #0x18]
    // 0xccc920: LoadField: r1 = r0->field_23
    //     0xccc920: ldur            w1, [x0, #0x23]
    // 0xccc924: DecompressPointer r1
    //     0xccc924: add             x1, x1, HEAP, lsl #32
    // 0xccc928: stur            x1, [fp, #-8]
    // 0xccc92c: LoadField: r2 = r0->field_27
    //     0xccc92c: ldur            w2, [x0, #0x27]
    // 0xccc930: DecompressPointer r2
    //     0xccc930: add             x2, x2, HEAP, lsl #32
    // 0xccc934: ldr             x16, [fp, #0x10]
    // 0xccc938: stp             x16, x2, [SP, #-0x10]!
    // 0xccc93c: r0 = resolveFrom()
    //     0xccc93c: bl              #0xcccc78  ; [package:flutter/src/cupertino/theme.dart] NoDefaultCupertinoThemeData::resolveFrom
    // 0xccc940: add             SP, SP, #0x10
    // 0xccc944: stur            x0, [fp, #-0x10]
    // 0xccc948: r0 = MaterialBasedCupertinoThemeData()
    //     0xccc948: bl              #0x83d4a0  ; AllocateMaterialBasedCupertinoThemeDataStub -> MaterialBasedCupertinoThemeData (size=0x2c)
    // 0xccc94c: stur            x0, [fp, #-0x18]
    // 0xccc950: ldur            x16, [fp, #-8]
    // 0xccc954: stp             x16, x0, [SP, #-0x10]!
    // 0xccc958: ldur            x16, [fp, #-0x10]
    // 0xccc95c: SaveReg r16
    //     0xccc95c: str             x16, [SP, #-8]!
    // 0xccc960: r0 = MaterialBasedCupertinoThemeData._()
    //     0xccc960: bl              #0x83d370  ; [package:flutter/src/material/theme_data.dart] MaterialBasedCupertinoThemeData::MaterialBasedCupertinoThemeData._
    // 0xccc964: add             SP, SP, #0x18
    // 0xccc968: ldur            x0, [fp, #-0x18]
    // 0xccc96c: LeaveFrame
    //     0xccc96c: mov             SP, fp
    //     0xccc970: ldp             fp, lr, [SP], #0x10
    // 0xccc974: ret
    //     0xccc974: ret             
    // 0xccc978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccc978: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccc97c: b               #0xccc91c
  }
}

// class id: 2717, size: 0x18, field offset: 0x8
//   const constructor, 
class VisualDensity extends _DiagnosticableTree&Object&Diagnosticable {

  _Mint field_8;
  _Mint field_10;

  get _ baseSizeAdjustment(/* No info */) {
    // ** addr: 0x630630, size: 0x68
    // 0x630630: EnterFrame
    //     0x630630: stp             fp, lr, [SP, #-0x10]!
    //     0x630634: mov             fp, SP
    // 0x630638: AllocStack(0x10)
    //     0x630638: sub             SP, SP, #0x10
    // 0x63063c: CheckStackOverflow
    //     0x63063c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630640: cmp             SP, x16
    //     0x630644: b.ls            #0x630690
    // 0x630648: ldr             x0, [fp, #0x10]
    // 0x63064c: LoadField: d0 = r0->field_7
    //     0x63064c: ldur            d0, [x0, #7]
    // 0x630650: stur            d0, [fp, #-0x10]
    // 0x630654: LoadField: d1 = r0->field_f
    //     0x630654: ldur            d1, [x0, #0xf]
    // 0x630658: stur            d1, [fp, #-8]
    // 0x63065c: r0 = Offset()
    //     0x63065c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x630660: ldur            d0, [fp, #-0x10]
    // 0x630664: StoreField: r0->field_7 = d0
    //     0x630664: stur            d0, [x0, #7]
    // 0x630668: ldur            d0, [fp, #-8]
    // 0x63066c: StoreField: r0->field_f = d0
    //     0x63066c: stur            d0, [x0, #0xf]
    // 0x630670: r16 = 4.000000
    //     0x630670: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e718] 4
    //     0x630674: ldr             x16, [x16, #0x718]
    // 0x630678: stp             x16, x0, [SP, #-0x10]!
    // 0x63067c: r0 = *()
    //     0x63067c: bl              #0x50e62c  ; [dart:ui] Offset::*
    // 0x630680: add             SP, SP, #0x10
    // 0x630684: LeaveFrame
    //     0x630684: mov             SP, fp
    //     0x630688: ldp             fp, lr, [SP], #0x10
    // 0x63068c: ret
    //     0x63068c: ret             
    // 0x630690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x630690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x630694: b               #0x630648
  }
  get _ adaptivePlatformDensity(/* No info */) {
    // ** addr: 0x6d2e10, size: 0x54
    // 0x6d2e10: EnterFrame
    //     0x6d2e10: stp             fp, lr, [SP, #-0x10]!
    //     0x6d2e14: mov             fp, SP
    // 0x6d2e18: CheckStackOverflow
    //     0x6d2e18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d2e1c: cmp             SP, x16
    //     0x6d2e20: b.ls            #0x6d2e5c
    // 0x6d2e24: r0 = defaultTargetPlatform()
    //     0x6d2e24: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0x6d2e28: LoadField: r1 = r0->field_7
    //     0x6d2e28: ldur            x1, [x0, #7]
    // 0x6d2e2c: cmp             x1, #2
    // 0x6d2e30: b.gt            #0x6d2e48
    // 0x6d2e34: r0 = Instance_VisualDensity
    //     0x6d2e34: add             x0, PP, #0xd, lsl #12  ; [pp+0xd260] Obj!VisualDensity@b3c131
    //     0x6d2e38: ldr             x0, [x0, #0x260]
    // 0x6d2e3c: LeaveFrame
    //     0x6d2e3c: mov             SP, fp
    //     0x6d2e40: ldp             fp, lr, [SP], #0x10
    // 0x6d2e44: ret
    //     0x6d2e44: ret             
    // 0x6d2e48: r0 = Instance_VisualDensity
    //     0x6d2e48: add             x0, PP, #0xd, lsl #12  ; [pp+0xd268] Obj!VisualDensity@b3c111
    //     0x6d2e4c: ldr             x0, [x0, #0x268]
    // 0x6d2e50: LeaveFrame
    //     0x6d2e50: mov             SP, fp
    //     0x6d2e54: ldp             fp, lr, [SP], #0x10
    // 0x6d2e58: ret
    //     0x6d2e58: ret             
    // 0x6d2e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d2e5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d2e60: b               #0x6d2e24
  }
  _ effectiveConstraints(/* No info */) {
    // ** addr: 0x84bb78, size: 0x1a0
    // 0x84bb78: EnterFrame
    //     0x84bb78: stp             fp, lr, [SP, #-0x10]!
    //     0x84bb7c: mov             fp, SP
    // 0x84bb80: AllocStack(0x10)
    //     0x84bb80: sub             SP, SP, #0x10
    // 0x84bb84: CheckStackOverflow
    //     0x84bb84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84bb88: cmp             SP, x16
    //     0x84bb8c: b.ls            #0x84bcd8
    // 0x84bb90: ldr             x0, [fp, #0x10]
    // 0x84bb94: LoadField: d0 = r0->field_7
    //     0x84bb94: ldur            d0, [x0, #7]
    // 0x84bb98: stur            d0, [fp, #-8]
    // 0x84bb9c: ldr             x16, [fp, #0x18]
    // 0x84bba0: SaveReg r16
    //     0x84bba0: str             x16, [SP, #-8]!
    // 0x84bba4: r0 = baseSizeAdjustment()
    //     0x84bba4: bl              #0x630630  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0x84bba8: add             SP, SP, #8
    // 0x84bbac: LoadField: d0 = r0->field_7
    //     0x84bbac: ldur            d0, [x0, #7]
    // 0x84bbb0: ldur            d1, [fp, #-8]
    // 0x84bbb4: fadd            d2, d1, d0
    // 0x84bbb8: ldr             x0, [fp, #0x10]
    // 0x84bbbc: LoadField: d0 = r0->field_f
    //     0x84bbbc: ldur            d0, [x0, #0xf]
    // 0x84bbc0: d1 = 0.000000
    //     0x84bbc0: eor             v1.16b, v1.16b, v1.16b
    // 0x84bbc4: fcmp            d2, d1
    // 0x84bbc8: b.vs            #0x84bbd8
    // 0x84bbcc: b.ge            #0x84bbd8
    // 0x84bbd0: d0 = 0.000000
    //     0x84bbd0: eor             v0.16b, v0.16b, v0.16b
    // 0x84bbd4: b               #0x84bbf0
    // 0x84bbd8: fcmp            d2, d0
    // 0x84bbdc: b.vs            #0x84bbe4
    // 0x84bbe0: b.gt            #0x84bbf0
    // 0x84bbe4: fcmp            d2, d2
    // 0x84bbe8: b.vs            #0x84bbf0
    // 0x84bbec: mov             v0.16b, v2.16b
    // 0x84bbf0: stur            d0, [fp, #-0x10]
    // 0x84bbf4: LoadField: d2 = r0->field_17
    //     0x84bbf4: ldur            d2, [x0, #0x17]
    // 0x84bbf8: stur            d2, [fp, #-8]
    // 0x84bbfc: ldr             x16, [fp, #0x18]
    // 0x84bc00: SaveReg r16
    //     0x84bc00: str             x16, [SP, #-8]!
    // 0x84bc04: r0 = baseSizeAdjustment()
    //     0x84bc04: bl              #0x630630  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0x84bc08: add             SP, SP, #8
    // 0x84bc0c: LoadField: d0 = r0->field_f
    //     0x84bc0c: ldur            d0, [x0, #0xf]
    // 0x84bc10: ldur            d1, [fp, #-8]
    // 0x84bc14: fadd            d2, d1, d0
    // 0x84bc18: ldr             x0, [fp, #0x10]
    // 0x84bc1c: LoadField: d0 = r0->field_1f
    //     0x84bc1c: ldur            d0, [x0, #0x1f]
    // 0x84bc20: d1 = 0.000000
    //     0x84bc20: eor             v1.16b, v1.16b, v1.16b
    // 0x84bc24: fcmp            d2, d1
    // 0x84bc28: b.vs            #0x84bc38
    // 0x84bc2c: b.ge            #0x84bc38
    // 0x84bc30: d1 = 0.000000
    //     0x84bc30: eor             v1.16b, v1.16b, v1.16b
    // 0x84bc34: b               #0x84bc60
    // 0x84bc38: fcmp            d2, d0
    // 0x84bc3c: b.vs            #0x84bc4c
    // 0x84bc40: b.le            #0x84bc4c
    // 0x84bc44: mov             v1.16b, v0.16b
    // 0x84bc48: b               #0x84bc60
    // 0x84bc4c: fcmp            d2, d2
    // 0x84bc50: b.vc            #0x84bc5c
    // 0x84bc54: mov             v1.16b, v0.16b
    // 0x84bc58: b               #0x84bc60
    // 0x84bc5c: mov             v1.16b, v2.16b
    // 0x84bc60: ldur            d0, [fp, #-0x10]
    // 0x84bc64: r1 = inline_Allocate_Double()
    //     0x84bc64: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x84bc68: add             x1, x1, #0x10
    //     0x84bc6c: cmp             x2, x1
    //     0x84bc70: b.ls            #0x84bce0
    //     0x84bc74: str             x1, [THR, #0x60]  ; THR::top
    //     0x84bc78: sub             x1, x1, #0xf
    //     0x84bc7c: mov             x2, #0xd108
    //     0x84bc80: movk            x2, #3, lsl #16
    //     0x84bc84: stur            x2, [x1, #-1]
    // 0x84bc88: StoreField: r1->field_7 = d0
    //     0x84bc88: stur            d0, [x1, #7]
    // 0x84bc8c: r2 = inline_Allocate_Double()
    //     0x84bc8c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x84bc90: add             x2, x2, #0x10
    //     0x84bc94: cmp             x3, x2
    //     0x84bc98: b.ls            #0x84bcfc
    //     0x84bc9c: str             x2, [THR, #0x60]  ; THR::top
    //     0x84bca0: sub             x2, x2, #0xf
    //     0x84bca4: mov             x3, #0xd108
    //     0x84bca8: movk            x3, #3, lsl #16
    //     0x84bcac: stur            x3, [x2, #-1]
    // 0x84bcb0: StoreField: r2->field_7 = d1
    //     0x84bcb0: stur            d1, [x2, #7]
    // 0x84bcb4: stp             x1, x0, [SP, #-0x10]!
    // 0x84bcb8: SaveReg r2
    //     0x84bcb8: str             x2, [SP, #-8]!
    // 0x84bcbc: r4 = const [0, 0x3, 0x3, 0x1, minHeight, 0x2, minWidth, 0x1, null]
    //     0x84bcbc: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e710] List(9) [0, 0x3, 0x3, 0x1, "minHeight", 0x2, "minWidth", 0x1, Null]
    //     0x84bcc0: ldr             x4, [x4, #0x710]
    // 0x84bcc4: r0 = copyWith()
    //     0x84bcc4: bl              #0x690914  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0x84bcc8: add             SP, SP, #0x18
    // 0x84bccc: LeaveFrame
    //     0x84bccc: mov             SP, fp
    //     0x84bcd0: ldp             fp, lr, [SP], #0x10
    // 0x84bcd4: ret
    //     0x84bcd4: ret             
    // 0x84bcd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bcd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bcdc: b               #0x84bb90
    // 0x84bce0: stp             q0, q1, [SP, #-0x20]!
    // 0x84bce4: SaveReg r0
    //     0x84bce4: str             x0, [SP, #-8]!
    // 0x84bce8: r0 = AllocateDouble()
    //     0x84bce8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x84bcec: mov             x1, x0
    // 0x84bcf0: RestoreReg r0
    //     0x84bcf0: ldr             x0, [SP], #8
    // 0x84bcf4: ldp             q0, q1, [SP], #0x20
    // 0x84bcf8: b               #0x84bc88
    // 0x84bcfc: SaveReg d1
    //     0x84bcfc: str             q1, [SP, #-0x10]!
    // 0x84bd00: stp             x0, x1, [SP, #-0x10]!
    // 0x84bd04: r0 = AllocateDouble()
    //     0x84bd04: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x84bd08: mov             x2, x0
    // 0x84bd0c: ldp             x0, x1, [SP], #0x10
    // 0x84bd10: RestoreReg d1
    //     0x84bd10: ldr             q1, [SP], #0x10
    // 0x84bd14: b               #0x84bcb0
  }
  _ toStringShort(/* No info */) {
    // ** addr: 0xa77e28, size: 0x18c
    // 0xa77e28: EnterFrame
    //     0xa77e28: stp             fp, lr, [SP, #-0x10]!
    //     0xa77e2c: mov             fp, SP
    // 0xa77e30: AllocStack(0x10)
    //     0xa77e30: sub             SP, SP, #0x10
    // 0xa77e34: CheckStackOverflow
    //     0xa77e34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa77e38: cmp             SP, x16
    //     0xa77e3c: b.ls            #0xa77f78
    // 0xa77e40: ldr             x16, [fp, #0x10]
    // 0xa77e44: SaveReg r16
    //     0xa77e44: str             x16, [SP, #-8]!
    // 0xa77e48: r0 = describeIdentity()
    //     0xa77e48: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xa77e4c: add             SP, SP, #8
    // 0xa77e50: r1 = Null
    //     0xa77e50: mov             x1, NULL
    // 0xa77e54: r2 = 12
    //     0xa77e54: mov             x2, #0xc
    // 0xa77e58: stur            x0, [fp, #-8]
    // 0xa77e5c: r0 = AllocateArray()
    //     0xa77e5c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa77e60: mov             x1, x0
    // 0xa77e64: ldur            x0, [fp, #-8]
    // 0xa77e68: stur            x1, [fp, #-0x10]
    // 0xa77e6c: StoreField: r1->field_f = r0
    //     0xa77e6c: stur            w0, [x1, #0xf]
    // 0xa77e70: r17 = "(h: "
    //     0xa77e70: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf28] "(h: "
    //     0xa77e74: ldr             x17, [x17, #0xf28]
    // 0xa77e78: StoreField: r1->field_13 = r17
    //     0xa77e78: stur            w17, [x1, #0x13]
    // 0xa77e7c: ldr             x0, [fp, #0x10]
    // 0xa77e80: LoadField: d0 = r0->field_7
    //     0xa77e80: ldur            d0, [x0, #7]
    // 0xa77e84: r2 = inline_Allocate_Double()
    //     0xa77e84: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xa77e88: add             x2, x2, #0x10
    //     0xa77e8c: cmp             x3, x2
    //     0xa77e90: b.ls            #0xa77f80
    //     0xa77e94: str             x2, [THR, #0x60]  ; THR::top
    //     0xa77e98: sub             x2, x2, #0xf
    //     0xa77e9c: mov             x3, #0xd108
    //     0xa77ea0: movk            x3, #3, lsl #16
    //     0xa77ea4: stur            x3, [x2, #-1]
    // 0xa77ea8: StoreField: r2->field_7 = d0
    //     0xa77ea8: stur            d0, [x2, #7]
    // 0xa77eac: SaveReg r2
    //     0xa77eac: str             x2, [SP, #-8]!
    // 0xa77eb0: r0 = debugFormatDouble()
    //     0xa77eb0: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xa77eb4: add             SP, SP, #8
    // 0xa77eb8: ldur            x1, [fp, #-0x10]
    // 0xa77ebc: ArrayStore: r1[2] = r0  ; List_4
    //     0xa77ebc: add             x25, x1, #0x17
    //     0xa77ec0: str             w0, [x25]
    //     0xa77ec4: tbz             w0, #0, #0xa77ee0
    //     0xa77ec8: ldurb           w16, [x1, #-1]
    //     0xa77ecc: ldurb           w17, [x0, #-1]
    //     0xa77ed0: and             x16, x17, x16, lsr #2
    //     0xa77ed4: tst             x16, HEAP, lsr #32
    //     0xa77ed8: b.eq            #0xa77ee0
    //     0xa77edc: bl              #0xd67e5c
    // 0xa77ee0: ldur            x1, [fp, #-0x10]
    // 0xa77ee4: r17 = ", v: "
    //     0xa77ee4: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf30] ", v: "
    //     0xa77ee8: ldr             x17, [x17, #0xf30]
    // 0xa77eec: StoreField: r1->field_1b = r17
    //     0xa77eec: stur            w17, [x1, #0x1b]
    // 0xa77ef0: ldr             x0, [fp, #0x10]
    // 0xa77ef4: LoadField: d0 = r0->field_f
    //     0xa77ef4: ldur            d0, [x0, #0xf]
    // 0xa77ef8: r0 = inline_Allocate_Double()
    //     0xa77ef8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xa77efc: add             x0, x0, #0x10
    //     0xa77f00: cmp             x2, x0
    //     0xa77f04: b.ls            #0xa77f9c
    //     0xa77f08: str             x0, [THR, #0x60]  ; THR::top
    //     0xa77f0c: sub             x0, x0, #0xf
    //     0xa77f10: mov             x2, #0xd108
    //     0xa77f14: movk            x2, #3, lsl #16
    //     0xa77f18: stur            x2, [x0, #-1]
    // 0xa77f1c: StoreField: r0->field_7 = d0
    //     0xa77f1c: stur            d0, [x0, #7]
    // 0xa77f20: SaveReg r0
    //     0xa77f20: str             x0, [SP, #-8]!
    // 0xa77f24: r0 = debugFormatDouble()
    //     0xa77f24: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xa77f28: add             SP, SP, #8
    // 0xa77f2c: ldur            x1, [fp, #-0x10]
    // 0xa77f30: ArrayStore: r1[4] = r0  ; List_4
    //     0xa77f30: add             x25, x1, #0x1f
    //     0xa77f34: str             w0, [x25]
    //     0xa77f38: tbz             w0, #0, #0xa77f54
    //     0xa77f3c: ldurb           w16, [x1, #-1]
    //     0xa77f40: ldurb           w17, [x0, #-1]
    //     0xa77f44: and             x16, x17, x16, lsr #2
    //     0xa77f48: tst             x16, HEAP, lsr #32
    //     0xa77f4c: b.eq            #0xa77f54
    //     0xa77f50: bl              #0xd67e5c
    // 0xa77f54: ldur            x0, [fp, #-0x10]
    // 0xa77f58: r17 = ")"
    //     0xa77f58: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xa77f5c: StoreField: r0->field_23 = r17
    //     0xa77f5c: stur            w17, [x0, #0x23]
    // 0xa77f60: SaveReg r0
    //     0xa77f60: str             x0, [SP, #-8]!
    // 0xa77f64: r0 = _interpolate()
    //     0xa77f64: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa77f68: add             SP, SP, #8
    // 0xa77f6c: LeaveFrame
    //     0xa77f6c: mov             SP, fp
    //     0xa77f70: ldp             fp, lr, [SP], #0x10
    // 0xa77f74: ret
    //     0xa77f74: ret             
    // 0xa77f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa77f78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa77f7c: b               #0xa77e40
    // 0xa77f80: SaveReg d0
    //     0xa77f80: str             q0, [SP, #-0x10]!
    // 0xa77f84: stp             x0, x1, [SP, #-0x10]!
    // 0xa77f88: r0 = AllocateDouble()
    //     0xa77f88: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa77f8c: mov             x2, x0
    // 0xa77f90: ldp             x0, x1, [SP], #0x10
    // 0xa77f94: RestoreReg d0
    //     0xa77f94: ldr             q0, [SP], #0x10
    // 0xa77f98: b               #0xa77ea8
    // 0xa77f9c: SaveReg d0
    //     0xa77f9c: str             q0, [SP, #-0x10]!
    // 0xa77fa0: SaveReg r1
    //     0xa77fa0: str             x1, [SP, #-8]!
    // 0xa77fa4: r0 = AllocateDouble()
    //     0xa77fa4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa77fa8: RestoreReg r1
    //     0xa77fa8: ldr             x1, [SP], #8
    // 0xa77fac: RestoreReg d0
    //     0xa77fac: ldr             q0, [SP], #0x10
    // 0xa77fb0: b               #0xa77f1c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb05768, size: 0xd8
    // 0xb05768: EnterFrame
    //     0xb05768: stp             fp, lr, [SP, #-0x10]!
    //     0xb0576c: mov             fp, SP
    // 0xb05770: CheckStackOverflow
    //     0xb05770: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb05774: cmp             SP, x16
    //     0xb05778: b.ls            #0xb0580c
    // 0xb0577c: ldr             x0, [fp, #0x10]
    // 0xb05780: LoadField: d0 = r0->field_7
    //     0xb05780: ldur            d0, [x0, #7]
    // 0xb05784: LoadField: d1 = r0->field_f
    //     0xb05784: ldur            d1, [x0, #0xf]
    // 0xb05788: r0 = inline_Allocate_Double()
    //     0xb05788: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb0578c: add             x0, x0, #0x10
    //     0xb05790: cmp             x1, x0
    //     0xb05794: b.ls            #0xb05814
    //     0xb05798: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0579c: sub             x0, x0, #0xf
    //     0xb057a0: mov             x1, #0xd108
    //     0xb057a4: movk            x1, #3, lsl #16
    //     0xb057a8: stur            x1, [x0, #-1]
    // 0xb057ac: StoreField: r0->field_7 = d0
    //     0xb057ac: stur            d0, [x0, #7]
    // 0xb057b0: r1 = inline_Allocate_Double()
    //     0xb057b0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb057b4: add             x1, x1, #0x10
    //     0xb057b8: cmp             x2, x1
    //     0xb057bc: b.ls            #0xb05824
    //     0xb057c0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb057c4: sub             x1, x1, #0xf
    //     0xb057c8: mov             x2, #0xd108
    //     0xb057cc: movk            x2, #3, lsl #16
    //     0xb057d0: stur            x2, [x1, #-1]
    // 0xb057d4: StoreField: r1->field_7 = d1
    //     0xb057d4: stur            d1, [x1, #7]
    // 0xb057d8: stp             x1, x0, [SP, #-0x10]!
    // 0xb057dc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xb057dc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xb057e0: r0 = hash()
    //     0xb057e0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb057e4: add             SP, SP, #0x10
    // 0xb057e8: mov             x2, x0
    // 0xb057ec: r0 = BoxInt64Instr(r2)
    //     0xb057ec: sbfiz           x0, x2, #1, #0x1f
    //     0xb057f0: cmp             x2, x0, asr #1
    //     0xb057f4: b.eq            #0xb05800
    //     0xb057f8: bl              #0xd69bb8
    //     0xb057fc: stur            x2, [x0, #7]
    // 0xb05800: LeaveFrame
    //     0xb05800: mov             SP, fp
    //     0xb05804: ldp             fp, lr, [SP], #0x10
    // 0xb05808: ret
    //     0xb05808: ret             
    // 0xb0580c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0580c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb05810: b               #0xb0577c
    // 0xb05814: stp             q0, q1, [SP, #-0x20]!
    // 0xb05818: r0 = AllocateDouble()
    //     0xb05818: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0581c: ldp             q0, q1, [SP], #0x20
    // 0xb05820: b               #0xb057ac
    // 0xb05824: SaveReg d1
    //     0xb05824: str             q1, [SP, #-0x10]!
    // 0xb05828: SaveReg r0
    //     0xb05828: str             x0, [SP, #-8]!
    // 0xb0582c: r0 = AllocateDouble()
    //     0xb0582c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb05830: mov             x1, x0
    // 0xb05834: RestoreReg r0
    //     0xb05834: ldr             x0, [SP], #8
    // 0xb05838: RestoreReg d1
    //     0xb05838: ldr             q1, [SP], #0x10
    // 0xb0583c: b               #0xb057d4
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf8228, size: 0x228
    // 0xbf8228: EnterFrame
    //     0xbf8228: stp             fp, lr, [SP, #-0x10]!
    //     0xbf822c: mov             fp, SP
    // 0xbf8230: AllocStack(0x18)
    //     0xbf8230: sub             SP, SP, #0x18
    // 0xbf8234: CheckStackOverflow
    //     0xbf8234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf8238: cmp             SP, x16
    //     0xbf823c: b.ls            #0xbf839c
    // 0xbf8240: ldr             x0, [fp, #0x20]
    // 0xbf8244: LoadField: d0 = r0->field_7
    //     0xbf8244: ldur            d0, [x0, #7]
    // 0xbf8248: ldr             x1, [fp, #0x18]
    // 0xbf824c: LoadField: d1 = r1->field_7
    //     0xbf824c: ldur            d1, [x1, #7]
    // 0xbf8250: ldr             d2, [fp, #0x10]
    // 0xbf8254: r2 = inline_Allocate_Double()
    //     0xbf8254: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf8258: add             x2, x2, #0x10
    //     0xbf825c: cmp             x3, x2
    //     0xbf8260: b.ls            #0xbf83a4
    //     0xbf8264: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf8268: sub             x2, x2, #0xf
    //     0xbf826c: mov             x3, #0xd108
    //     0xbf8270: movk            x3, #3, lsl #16
    //     0xbf8274: stur            x3, [x2, #-1]
    // 0xbf8278: StoreField: r2->field_7 = d2
    //     0xbf8278: stur            d2, [x2, #7]
    // 0xbf827c: stur            x2, [fp, #-8]
    // 0xbf8280: r3 = inline_Allocate_Double()
    //     0xbf8280: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf8284: add             x3, x3, #0x10
    //     0xbf8288: cmp             x4, x3
    //     0xbf828c: b.ls            #0xbf83c8
    //     0xbf8290: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf8294: sub             x3, x3, #0xf
    //     0xbf8298: mov             x4, #0xd108
    //     0xbf829c: movk            x4, #3, lsl #16
    //     0xbf82a0: stur            x4, [x3, #-1]
    // 0xbf82a4: StoreField: r3->field_7 = d0
    //     0xbf82a4: stur            d0, [x3, #7]
    // 0xbf82a8: r4 = inline_Allocate_Double()
    //     0xbf82a8: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf82ac: add             x4, x4, #0x10
    //     0xbf82b0: cmp             x5, x4
    //     0xbf82b4: b.ls            #0xbf83ec
    //     0xbf82b8: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf82bc: sub             x4, x4, #0xf
    //     0xbf82c0: mov             x5, #0xd108
    //     0xbf82c4: movk            x5, #3, lsl #16
    //     0xbf82c8: stur            x5, [x4, #-1]
    // 0xbf82cc: StoreField: r4->field_7 = d1
    //     0xbf82cc: stur            d1, [x4, #7]
    // 0xbf82d0: stp             x4, x3, [SP, #-0x10]!
    // 0xbf82d4: SaveReg r2
    //     0xbf82d4: str             x2, [SP, #-8]!
    // 0xbf82d8: r0 = lerpDouble()
    //     0xbf82d8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf82dc: add             SP, SP, #0x18
    // 0xbf82e0: stur            x0, [fp, #-0x10]
    // 0xbf82e4: cmp             w0, NULL
    // 0xbf82e8: b.eq            #0xbf8410
    // 0xbf82ec: ldr             x1, [fp, #0x20]
    // 0xbf82f0: LoadField: d0 = r1->field_f
    //     0xbf82f0: ldur            d0, [x1, #0xf]
    // 0xbf82f4: ldr             x1, [fp, #0x18]
    // 0xbf82f8: LoadField: d1 = r1->field_f
    //     0xbf82f8: ldur            d1, [x1, #0xf]
    // 0xbf82fc: r1 = inline_Allocate_Double()
    //     0xbf82fc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbf8300: add             x1, x1, #0x10
    //     0xbf8304: cmp             x2, x1
    //     0xbf8308: b.ls            #0xbf8414
    //     0xbf830c: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf8310: sub             x1, x1, #0xf
    //     0xbf8314: mov             x2, #0xd108
    //     0xbf8318: movk            x2, #3, lsl #16
    //     0xbf831c: stur            x2, [x1, #-1]
    // 0xbf8320: StoreField: r1->field_7 = d0
    //     0xbf8320: stur            d0, [x1, #7]
    // 0xbf8324: r2 = inline_Allocate_Double()
    //     0xbf8324: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf8328: add             x2, x2, #0x10
    //     0xbf832c: cmp             x3, x2
    //     0xbf8330: b.ls            #0xbf8430
    //     0xbf8334: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf8338: sub             x2, x2, #0xf
    //     0xbf833c: mov             x3, #0xd108
    //     0xbf8340: movk            x3, #3, lsl #16
    //     0xbf8344: stur            x3, [x2, #-1]
    // 0xbf8348: StoreField: r2->field_7 = d1
    //     0xbf8348: stur            d1, [x2, #7]
    // 0xbf834c: stp             x2, x1, [SP, #-0x10]!
    // 0xbf8350: ldur            x16, [fp, #-8]
    // 0xbf8354: SaveReg r16
    //     0xbf8354: str             x16, [SP, #-8]!
    // 0xbf8358: r0 = lerpDouble()
    //     0xbf8358: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf835c: add             SP, SP, #0x18
    // 0xbf8360: stur            x0, [fp, #-8]
    // 0xbf8364: cmp             w0, NULL
    // 0xbf8368: b.eq            #0xbf844c
    // 0xbf836c: ldur            x1, [fp, #-0x10]
    // 0xbf8370: LoadField: d0 = r1->field_7
    //     0xbf8370: ldur            d0, [x1, #7]
    // 0xbf8374: stur            d0, [fp, #-0x18]
    // 0xbf8378: r0 = VisualDensity()
    //     0xbf8378: bl              #0xbf8450  ; AllocateVisualDensityStub -> VisualDensity (size=0x18)
    // 0xbf837c: ldur            d0, [fp, #-0x18]
    // 0xbf8380: StoreField: r0->field_7 = d0
    //     0xbf8380: stur            d0, [x0, #7]
    // 0xbf8384: ldur            x1, [fp, #-8]
    // 0xbf8388: LoadField: d0 = r1->field_7
    //     0xbf8388: ldur            d0, [x1, #7]
    // 0xbf838c: StoreField: r0->field_f = d0
    //     0xbf838c: stur            d0, [x0, #0xf]
    // 0xbf8390: LeaveFrame
    //     0xbf8390: mov             SP, fp
    //     0xbf8394: ldp             fp, lr, [SP], #0x10
    // 0xbf8398: ret
    //     0xbf8398: ret             
    // 0xbf839c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf839c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf83a0: b               #0xbf8240
    // 0xbf83a4: stp             q1, q2, [SP, #-0x20]!
    // 0xbf83a8: SaveReg d0
    //     0xbf83a8: str             q0, [SP, #-0x10]!
    // 0xbf83ac: stp             x0, x1, [SP, #-0x10]!
    // 0xbf83b0: r0 = AllocateDouble()
    //     0xbf83b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf83b4: mov             x2, x0
    // 0xbf83b8: ldp             x0, x1, [SP], #0x10
    // 0xbf83bc: RestoreReg d0
    //     0xbf83bc: ldr             q0, [SP], #0x10
    // 0xbf83c0: ldp             q1, q2, [SP], #0x20
    // 0xbf83c4: b               #0xbf8278
    // 0xbf83c8: stp             q0, q1, [SP, #-0x20]!
    // 0xbf83cc: stp             x1, x2, [SP, #-0x10]!
    // 0xbf83d0: SaveReg r0
    //     0xbf83d0: str             x0, [SP, #-8]!
    // 0xbf83d4: r0 = AllocateDouble()
    //     0xbf83d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf83d8: mov             x3, x0
    // 0xbf83dc: RestoreReg r0
    //     0xbf83dc: ldr             x0, [SP], #8
    // 0xbf83e0: ldp             x1, x2, [SP], #0x10
    // 0xbf83e4: ldp             q0, q1, [SP], #0x20
    // 0xbf83e8: b               #0xbf82a4
    // 0xbf83ec: SaveReg d1
    //     0xbf83ec: str             q1, [SP, #-0x10]!
    // 0xbf83f0: stp             x2, x3, [SP, #-0x10]!
    // 0xbf83f4: stp             x0, x1, [SP, #-0x10]!
    // 0xbf83f8: r0 = AllocateDouble()
    //     0xbf83f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf83fc: mov             x4, x0
    // 0xbf8400: ldp             x0, x1, [SP], #0x10
    // 0xbf8404: ldp             x2, x3, [SP], #0x10
    // 0xbf8408: RestoreReg d1
    //     0xbf8408: ldr             q1, [SP], #0x10
    // 0xbf840c: b               #0xbf82cc
    // 0xbf8410: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8410: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf8414: stp             q0, q1, [SP, #-0x20]!
    // 0xbf8418: SaveReg r0
    //     0xbf8418: str             x0, [SP, #-8]!
    // 0xbf841c: r0 = AllocateDouble()
    //     0xbf841c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf8420: mov             x1, x0
    // 0xbf8424: RestoreReg r0
    //     0xbf8424: ldr             x0, [SP], #8
    // 0xbf8428: ldp             q0, q1, [SP], #0x20
    // 0xbf842c: b               #0xbf8320
    // 0xbf8430: SaveReg d1
    //     0xbf8430: str             q1, [SP, #-0x10]!
    // 0xbf8434: stp             x0, x1, [SP, #-0x10]!
    // 0xbf8438: r0 = AllocateDouble()
    //     0xbf8438: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf843c: mov             x2, x0
    // 0xbf8440: ldp             x0, x1, [SP], #0x10
    // 0xbf8444: RestoreReg d1
    //     0xbf8444: ldr             q1, [SP], #0x10
    // 0xbf8448: b               #0xbf8348
    // 0xbf844c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf844c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc928d4, size: 0x110
    // 0xc928d4: EnterFrame
    //     0xc928d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc928d8: mov             fp, SP
    // 0xc928dc: CheckStackOverflow
    //     0xc928dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc928e0: cmp             SP, x16
    //     0xc928e4: b.ls            #0xc929dc
    // 0xc928e8: ldr             x1, [fp, #0x10]
    // 0xc928ec: cmp             w1, NULL
    // 0xc928f0: b.ne            #0xc92904
    // 0xc928f4: r0 = false
    //     0xc928f4: add             x0, NULL, #0x30  ; false
    // 0xc928f8: LeaveFrame
    //     0xc928f8: mov             SP, fp
    //     0xc928fc: ldp             fp, lr, [SP], #0x10
    // 0xc92900: ret
    //     0xc92900: ret             
    // 0xc92904: r0 = 59
    //     0xc92904: mov             x0, #0x3b
    // 0xc92908: branchIfSmi(r1, 0xc92914)
    //     0xc92908: tbz             w1, #0, #0xc92914
    // 0xc9290c: r0 = LoadClassIdInstr(r1)
    //     0xc9290c: ldur            x0, [x1, #-1]
    //     0xc92910: ubfx            x0, x0, #0xc, #0x14
    // 0xc92914: SaveReg r1
    //     0xc92914: str             x1, [SP, #-8]!
    // 0xc92918: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc92918: mov             x17, #0x57c5
    //     0xc9291c: add             lr, x0, x17
    //     0xc92920: ldr             lr, [x21, lr, lsl #3]
    //     0xc92924: blr             lr
    // 0xc92928: add             SP, SP, #8
    // 0xc9292c: r1 = LoadClassIdInstr(r0)
    //     0xc9292c: ldur            x1, [x0, #-1]
    //     0xc92930: ubfx            x1, x1, #0xc, #0x14
    // 0xc92934: r16 = VisualDensity
    //     0xc92934: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf10] Type: VisualDensity
    //     0xc92938: ldr             x16, [x16, #0xf10]
    // 0xc9293c: stp             x16, x0, [SP, #-0x10]!
    // 0xc92940: mov             x0, x1
    // 0xc92944: mov             lr, x0
    // 0xc92948: ldr             lr, [x21, lr, lsl #3]
    // 0xc9294c: blr             lr
    // 0xc92950: add             SP, SP, #0x10
    // 0xc92954: tbz             w0, #4, #0xc92968
    // 0xc92958: r0 = false
    //     0xc92958: add             x0, NULL, #0x30  ; false
    // 0xc9295c: LeaveFrame
    //     0xc9295c: mov             SP, fp
    //     0xc92960: ldp             fp, lr, [SP], #0x10
    // 0xc92964: ret
    //     0xc92964: ret             
    // 0xc92968: ldr             x1, [fp, #0x10]
    // 0xc9296c: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9296c: mov             x2, #0x76
    //     0xc92970: tbz             w1, #0, #0xc92980
    //     0xc92974: ldur            x2, [x1, #-1]
    //     0xc92978: ubfx            x2, x2, #0xc, #0x14
    //     0xc9297c: lsl             x2, x2, #1
    // 0xc92980: r17 = 5434
    //     0xc92980: mov             x17, #0x153a
    // 0xc92984: cmp             w2, w17
    // 0xc92988: b.ne            #0xc929cc
    // 0xc9298c: ldr             x2, [fp, #0x18]
    // 0xc92990: LoadField: d0 = r1->field_7
    //     0xc92990: ldur            d0, [x1, #7]
    // 0xc92994: LoadField: d1 = r2->field_7
    //     0xc92994: ldur            d1, [x2, #7]
    // 0xc92998: fcmp            d0, d1
    // 0xc9299c: b.vs            #0xc929cc
    // 0xc929a0: b.ne            #0xc929cc
    // 0xc929a4: LoadField: d0 = r1->field_f
    //     0xc929a4: ldur            d0, [x1, #0xf]
    // 0xc929a8: LoadField: d1 = r2->field_f
    //     0xc929a8: ldur            d1, [x2, #0xf]
    // 0xc929ac: fcmp            d0, d1
    // 0xc929b0: b.vs            #0xc929b8
    // 0xc929b4: b.eq            #0xc929c0
    // 0xc929b8: r1 = false
    //     0xc929b8: add             x1, NULL, #0x30  ; false
    // 0xc929bc: b               #0xc929c4
    // 0xc929c0: r1 = true
    //     0xc929c0: add             x1, NULL, #0x20  ; true
    // 0xc929c4: mov             x0, x1
    // 0xc929c8: b               #0xc929d0
    // 0xc929cc: r0 = false
    //     0xc929cc: add             x0, NULL, #0x30  ; false
    // 0xc929d0: LeaveFrame
    //     0xc929d0: mov             SP, fp
    //     0xc929d4: ldp             fp, lr, [SP], #0x10
    // 0xc929d8: ret
    //     0xc929d8: ret             
    // 0xc929dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc929dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc929e0: b               #0xc928e8
  }
}

// class id: 2718, size: 0x170, field offset: 0x8
//   const constructor, 
class ThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static late final _FifoCache<_IdentityThemeDataCacheKey, ThemeData> _localizedThemeDataCache; // offset: 0xe48

  static _ localize(/* No info */) {
    // ** addr: 0x6cbc14, size: 0xd0
    // 0x6cbc14: EnterFrame
    //     0x6cbc14: stp             fp, lr, [SP, #-0x10]!
    //     0x6cbc18: mov             fp, SP
    // 0x6cbc1c: AllocStack(0x28)
    //     0x6cbc1c: sub             SP, SP, #0x28
    // 0x6cbc20: CheckStackOverflow
    //     0x6cbc20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cbc24: cmp             SP, x16
    //     0x6cbc28: b.ls            #0x6cbcdc
    // 0x6cbc2c: r1 = 2
    //     0x6cbc2c: mov             x1, #2
    // 0x6cbc30: r0 = AllocateContext()
    //     0x6cbc30: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6cbc34: mov             x1, x0
    // 0x6cbc38: ldr             x0, [fp, #0x18]
    // 0x6cbc3c: stur            x1, [fp, #-8]
    // 0x6cbc40: StoreField: r1->field_f = r0
    //     0x6cbc40: stur            w0, [x1, #0xf]
    // 0x6cbc44: ldr             x0, [fp, #0x10]
    // 0x6cbc48: StoreField: r1->field_13 = r0
    //     0x6cbc48: stur            w0, [x1, #0x13]
    // 0x6cbc4c: r0 = InitLateStaticField(0xe48) // [package:flutter/src/material/theme_data.dart] ThemeData::_localizedThemeDataCache
    //     0x6cbc4c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6cbc50: ldr             x0, [x0, #0x1c90]
    //     0x6cbc54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6cbc58: cmp             w0, w16
    //     0x6cbc5c: b.ne            #0x6cbc6c
    //     0x6cbc60: add             x2, PP, #0xd, lsl #12  ; [pp+0xdfb8] Field <ThemeData._localizedThemeDataCache@831408314>: static late final (offset: 0xe48)
    //     0x6cbc64: ldr             x2, [x2, #0xfb8]
    //     0x6cbc68: bl              #0xd67cdc
    // 0x6cbc6c: ldur            x2, [fp, #-8]
    // 0x6cbc70: stur            x0, [fp, #-0x20]
    // 0x6cbc74: LoadField: r1 = r2->field_f
    //     0x6cbc74: ldur            w1, [x2, #0xf]
    // 0x6cbc78: DecompressPointer r1
    //     0x6cbc78: add             x1, x1, HEAP, lsl #32
    // 0x6cbc7c: stur            x1, [fp, #-0x18]
    // 0x6cbc80: LoadField: r3 = r2->field_13
    //     0x6cbc80: ldur            w3, [x2, #0x13]
    // 0x6cbc84: DecompressPointer r3
    //     0x6cbc84: add             x3, x3, HEAP, lsl #32
    // 0x6cbc88: stur            x3, [fp, #-0x10]
    // 0x6cbc8c: r0 = _IdentityThemeDataCacheKey()
    //     0x6cbc8c: bl              #0x6cbe38  ; Allocate_IdentityThemeDataCacheKeyStub -> _IdentityThemeDataCacheKey (size=0x10)
    // 0x6cbc90: mov             x3, x0
    // 0x6cbc94: ldur            x0, [fp, #-0x18]
    // 0x6cbc98: stur            x3, [fp, #-0x28]
    // 0x6cbc9c: StoreField: r3->field_7 = r0
    //     0x6cbc9c: stur            w0, [x3, #7]
    // 0x6cbca0: ldur            x0, [fp, #-0x10]
    // 0x6cbca4: StoreField: r3->field_b = r0
    //     0x6cbca4: stur            w0, [x3, #0xb]
    // 0x6cbca8: ldur            x2, [fp, #-8]
    // 0x6cbcac: r1 = Function '<anonymous closure>': static.
    //     0x6cbcac: add             x1, PP, #0xd, lsl #12  ; [pp+0xdfc0] AnonymousClosure: static (0x6cbe64), in [package:flutter/src/material/theme_data.dart] ThemeData::localize (0x6cbc14)
    //     0x6cbcb0: ldr             x1, [x1, #0xfc0]
    // 0x6cbcb4: r0 = AllocateClosure()
    //     0x6cbcb4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6cbcb8: ldur            x16, [fp, #-0x20]
    // 0x6cbcbc: ldur            lr, [fp, #-0x28]
    // 0x6cbcc0: stp             lr, x16, [SP, #-0x10]!
    // 0x6cbcc4: SaveReg r0
    //     0x6cbcc4: str             x0, [SP, #-8]!
    // 0x6cbcc8: r0 = putIfAbsent()
    //     0x6cbcc8: bl              #0x6cbd04  ; [package:flutter/src/material/theme_data.dart] _FifoCache::putIfAbsent
    // 0x6cbccc: add             SP, SP, #0x18
    // 0x6cbcd0: LeaveFrame
    //     0x6cbcd0: mov             SP, fp
    //     0x6cbcd4: ldp             fp, lr, [SP], #0x10
    // 0x6cbcd8: ret
    //     0x6cbcd8: ret             
    // 0x6cbcdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cbcdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cbce0: b               #0x6cbc2c
  }
  [closure] static ThemeData <anonymous closure>(dynamic) {
    // ** addr: 0x6cbe64, size: 0xec
    // 0x6cbe64: EnterFrame
    //     0x6cbe64: stp             fp, lr, [SP, #-0x10]!
    //     0x6cbe68: mov             fp, SP
    // 0x6cbe6c: AllocStack(0x20)
    //     0x6cbe6c: sub             SP, SP, #0x20
    // 0x6cbe70: SetupParameters()
    //     0x6cbe70: ldr             x0, [fp, #0x10]
    //     0x6cbe74: ldur            w1, [x0, #0x17]
    //     0x6cbe78: add             x1, x1, HEAP, lsl #32
    //     0x6cbe7c: stur            x1, [fp, #-0x10]
    // 0x6cbe80: CheckStackOverflow
    //     0x6cbe80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cbe84: cmp             SP, x16
    //     0x6cbe88: b.ls            #0x6cbf48
    // 0x6cbe8c: LoadField: r0 = r1->field_f
    //     0x6cbe8c: ldur            w0, [x1, #0xf]
    // 0x6cbe90: DecompressPointer r0
    //     0x6cbe90: add             x0, x0, HEAP, lsl #32
    // 0x6cbe94: stur            x0, [fp, #-8]
    // 0x6cbe98: LoadField: r2 = r1->field_13
    //     0x6cbe98: ldur            w2, [x1, #0x13]
    // 0x6cbe9c: DecompressPointer r2
    //     0x6cbe9c: add             x2, x2, HEAP, lsl #32
    // 0x6cbea0: LoadField: r3 = r0->field_8f
    //     0x6cbea0: ldur            w3, [x0, #0x8f]
    // 0x6cbea4: DecompressPointer r3
    //     0x6cbea4: add             x3, x3, HEAP, lsl #32
    // 0x6cbea8: stp             x3, x2, [SP, #-0x10]!
    // 0x6cbeac: r0 = merge()
    //     0x6cbeac: bl              #0x6cd5cc  ; [package:flutter/src/material/text_theme.dart] TextTheme::merge
    // 0x6cbeb0: add             SP, SP, #0x10
    // 0x6cbeb4: mov             x1, x0
    // 0x6cbeb8: ldur            x0, [fp, #-0x10]
    // 0x6cbebc: stur            x1, [fp, #-0x18]
    // 0x6cbec0: LoadField: r2 = r0->field_13
    //     0x6cbec0: ldur            w2, [x0, #0x13]
    // 0x6cbec4: DecompressPointer r2
    //     0x6cbec4: add             x2, x2, HEAP, lsl #32
    // 0x6cbec8: LoadField: r3 = r0->field_f
    //     0x6cbec8: ldur            w3, [x0, #0xf]
    // 0x6cbecc: DecompressPointer r3
    //     0x6cbecc: add             x3, x3, HEAP, lsl #32
    // 0x6cbed0: r17 = 331
    //     0x6cbed0: mov             x17, #0x14b
    // 0x6cbed4: ldr             w4, [x3, x17]
    // 0x6cbed8: DecompressPointer r4
    //     0x6cbed8: add             x4, x4, HEAP, lsl #32
    // 0x6cbedc: stp             x4, x2, [SP, #-0x10]!
    // 0x6cbee0: r0 = merge()
    //     0x6cbee0: bl              #0x6cd5cc  ; [package:flutter/src/material/text_theme.dart] TextTheme::merge
    // 0x6cbee4: add             SP, SP, #0x10
    // 0x6cbee8: mov             x1, x0
    // 0x6cbeec: ldur            x0, [fp, #-0x10]
    // 0x6cbef0: stur            x1, [fp, #-0x20]
    // 0x6cbef4: LoadField: r2 = r0->field_13
    //     0x6cbef4: ldur            w2, [x0, #0x13]
    // 0x6cbef8: DecompressPointer r2
    //     0x6cbef8: add             x2, x2, HEAP, lsl #32
    // 0x6cbefc: LoadField: r3 = r0->field_f
    //     0x6cbefc: ldur            w3, [x0, #0xf]
    // 0x6cbf00: DecompressPointer r3
    //     0x6cbf00: add             x3, x3, HEAP, lsl #32
    // 0x6cbf04: LoadField: r0 = r3->field_93
    //     0x6cbf04: ldur            w0, [x3, #0x93]
    // 0x6cbf08: DecompressPointer r0
    //     0x6cbf08: add             x0, x0, HEAP, lsl #32
    // 0x6cbf0c: stp             x0, x2, [SP, #-0x10]!
    // 0x6cbf10: r0 = merge()
    //     0x6cbf10: bl              #0x6cd5cc  ; [package:flutter/src/material/text_theme.dart] TextTheme::merge
    // 0x6cbf14: add             SP, SP, #0x10
    // 0x6cbf18: ldur            x16, [fp, #-8]
    // 0x6cbf1c: ldur            lr, [fp, #-0x18]
    // 0x6cbf20: stp             lr, x16, [SP, #-0x10]!
    // 0x6cbf24: ldur            x16, [fp, #-0x20]
    // 0x6cbf28: stp             x0, x16, [SP, #-0x10]!
    // 0x6cbf2c: r4 = const [0, 0x4, 0x4, 0x1, accentTextTheme, 0x2, primaryTextTheme, 0x1, textTheme, 0x3, null]
    //     0x6cbf2c: add             x4, PP, #0xd, lsl #12  ; [pp+0xdfc8] List(11) [0, 0x4, 0x4, 0x1, "accentTextTheme", 0x2, "primaryTextTheme", 0x1, "textTheme", 0x3, Null]
    //     0x6cbf30: ldr             x4, [x4, #0xfc8]
    // 0x6cbf34: r0 = copyWith()
    //     0x6cbf34: bl              #0x6cbf50  ; [package:flutter/src/material/theme_data.dart] ThemeData::copyWith
    // 0x6cbf38: add             SP, SP, #0x20
    // 0x6cbf3c: LeaveFrame
    //     0x6cbf3c: mov             SP, fp
    //     0x6cbf40: ldp             fp, lr, [SP], #0x10
    // 0x6cbf44: ret
    //     0x6cbf44: ret             
    // 0x6cbf48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cbf48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cbf4c: b               #0x6cbe8c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x6cbf50, size: 0x11d8
    // 0x6cbf50: EnterFrame
    //     0x6cbf50: stp             fp, lr, [SP, #-0x10]!
    //     0x6cbf54: mov             fp, SP
    // 0x6cbf58: AllocStack(0x2b0)
    //     0x6cbf58: sub             SP, SP, #0x2b0
    // 0x6cbf5c: SetupParameters(ThemeData this /* r3, fp-0xc8 */, {dynamic accentTextTheme = Null /* fp-0x8 */, dynamic appBarTheme = Null /* r5, fp-0xc0 */, dynamic bottomAppBarColor = Null /* r6, fp-0xb8 */, dynamic buttonTheme = Null /* r7, fp-0xb0 */, dynamic canvasColor = Null /* r8 */, dynamic cardColor = Null /* r9 */, dynamic colorScheme = Null /* r10 */, dynamic cupertinoOverrideTheme, dynamic highlightColor = Null /* r11, fp-0xa8 */, dynamic indicatorColor = Null /* r12, fp-0xa0 */, dynamic primaryColor = Null /* r13, fp-0x98 */, dynamic primaryColorDark = Null /* r14, fp-0x90 */, dynamic primaryColorLight = Null /* r19, fp-0x88 */, dynamic primaryTextTheme = Null /* r20, fp-0x80 */, dynamic scaffoldBackgroundColor = Null /* fp-0x10 */, dynamic textSelectionTheme = Null /* fp-0x18 */, dynamic textTheme = Null /* r4, fp-0x78 */, dynamic toggleableActiveColor = Null /* r0, fp-0x20 */})
    //     0x6cbf5c: mov             x0, x4
    //     0x6cbf60: ldur            w1, [x0, #0x13]
    //     0x6cbf64: add             x1, x1, HEAP, lsl #32
    //     0x6cbf68: sub             x2, x1, #2
    //     0x6cbf6c: add             x3, fp, w2, sxtw #2
    //     0x6cbf70: ldr             x3, [x3, #0x10]
    //     0x6cbf74: stur            x3, [fp, #-0xc8]
    //     0x6cbf78: ldur            w2, [x0, #0x1f]
    //     0x6cbf7c: add             x2, x2, HEAP, lsl #32
    //     0x6cbf80: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc30] "accentTextTheme"
    //     0x6cbf84: ldr             x16, [x16, #0xc30]
    //     0x6cbf88: cmp             w2, w16
    //     0x6cbf8c: b.ne            #0x6cbfb0
    //     0x6cbf90: ldur            w2, [x0, #0x23]
    //     0x6cbf94: add             x2, x2, HEAP, lsl #32
    //     0x6cbf98: sub             w4, w1, w2
    //     0x6cbf9c: add             x2, fp, w4, sxtw #2
    //     0x6cbfa0: ldr             x2, [x2, #8]
    //     0x6cbfa4: mov             x4, x2
    //     0x6cbfa8: mov             x2, #1
    //     0x6cbfac: b               #0x6cbfb8
    //     0x6cbfb0: mov             x4, NULL
    //     0x6cbfb4: mov             x2, #0
    //     0x6cbfb8: stur            x4, [fp, #-8]
    //     0x6cbfbc: lsl             x5, x2, #1
    //     0x6cbfc0: lsl             w6, w5, #1
    //     0x6cbfc4: add             w7, w6, #8
    //     0x6cbfc8: add             x16, x0, w7, sxtw #1
    //     0x6cbfcc: ldur            w8, [x16, #0xf]
    //     0x6cbfd0: add             x8, x8, HEAP, lsl #32
    //     0x6cbfd4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc38] "appBarTheme"
    //     0x6cbfd8: ldr             x16, [x16, #0xc38]
    //     0x6cbfdc: cmp             w8, w16
    //     0x6cbfe0: b.ne            #0x6cc014
    //     0x6cbfe4: add             w2, w6, #0xa
    //     0x6cbfe8: add             x16, x0, w2, sxtw #1
    //     0x6cbfec: ldur            w6, [x16, #0xf]
    //     0x6cbff0: add             x6, x6, HEAP, lsl #32
    //     0x6cbff4: sub             w2, w1, w6
    //     0x6cbff8: add             x6, fp, w2, sxtw #2
    //     0x6cbffc: ldr             x6, [x6, #8]
    //     0x6cc000: add             w2, w5, #2
    //     0x6cc004: sbfx            x5, x2, #1, #0x1f
    //     0x6cc008: mov             x2, x5
    //     0x6cc00c: mov             x5, x6
    //     0x6cc010: b               #0x6cc018
    //     0x6cc014: mov             x5, NULL
    //     0x6cc018: stur            x5, [fp, #-0xc0]
    //     0x6cc01c: lsl             x6, x2, #1
    //     0x6cc020: lsl             w7, w6, #1
    //     0x6cc024: add             w8, w7, #8
    //     0x6cc028: add             x16, x0, w8, sxtw #1
    //     0x6cc02c: ldur            w9, [x16, #0xf]
    //     0x6cc030: add             x9, x9, HEAP, lsl #32
    //     0x6cc034: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc60] "bottomAppBarColor"
    //     0x6cc038: ldr             x16, [x16, #0xc60]
    //     0x6cc03c: cmp             w9, w16
    //     0x6cc040: b.ne            #0x6cc074
    //     0x6cc044: add             w2, w7, #0xa
    //     0x6cc048: add             x16, x0, w2, sxtw #1
    //     0x6cc04c: ldur            w7, [x16, #0xf]
    //     0x6cc050: add             x7, x7, HEAP, lsl #32
    //     0x6cc054: sub             w2, w1, w7
    //     0x6cc058: add             x7, fp, w2, sxtw #2
    //     0x6cc05c: ldr             x7, [x7, #8]
    //     0x6cc060: add             w2, w6, #2
    //     0x6cc064: sbfx            x6, x2, #1, #0x1f
    //     0x6cc068: mov             x2, x6
    //     0x6cc06c: mov             x6, x7
    //     0x6cc070: b               #0x6cc078
    //     0x6cc074: mov             x6, NULL
    //     0x6cc078: stur            x6, [fp, #-0xb8]
    //     0x6cc07c: lsl             x7, x2, #1
    //     0x6cc080: lsl             w8, w7, #1
    //     0x6cc084: add             w9, w8, #8
    //     0x6cc088: add             x16, x0, w9, sxtw #1
    //     0x6cc08c: ldur            w10, [x16, #0xf]
    //     0x6cc090: add             x10, x10, HEAP, lsl #32
    //     0x6cc094: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc98] "buttonTheme"
    //     0x6cc098: ldr             x16, [x16, #0xc98]
    //     0x6cc09c: cmp             w10, w16
    //     0x6cc0a0: b.ne            #0x6cc0d4
    //     0x6cc0a4: add             w2, w8, #0xa
    //     0x6cc0a8: add             x16, x0, w2, sxtw #1
    //     0x6cc0ac: ldur            w8, [x16, #0xf]
    //     0x6cc0b0: add             x8, x8, HEAP, lsl #32
    //     0x6cc0b4: sub             w2, w1, w8
    //     0x6cc0b8: add             x8, fp, w2, sxtw #2
    //     0x6cc0bc: ldr             x8, [x8, #8]
    //     0x6cc0c0: add             w2, w7, #2
    //     0x6cc0c4: sbfx            x7, x2, #1, #0x1f
    //     0x6cc0c8: mov             x2, x7
    //     0x6cc0cc: mov             x7, x8
    //     0x6cc0d0: b               #0x6cc0d8
    //     0x6cc0d4: mov             x7, NULL
    //     0x6cc0d8: stur            x7, [fp, #-0xb0]
    //     0x6cc0dc: lsl             x8, x2, #1
    //     0x6cc0e0: lsl             w9, w8, #1
    //     0x6cc0e4: add             w10, w9, #8
    //     0x6cc0e8: add             x16, x0, w10, sxtw #1
    //     0x6cc0ec: ldur            w11, [x16, #0xf]
    //     0x6cc0f0: add             x11, x11, HEAP, lsl #32
    //     0x6cc0f4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcca0] "canvasColor"
    //     0x6cc0f8: ldr             x16, [x16, #0xca0]
    //     0x6cc0fc: cmp             w11, w16
    //     0x6cc100: b.ne            #0x6cc134
    //     0x6cc104: add             w2, w9, #0xa
    //     0x6cc108: add             x16, x0, w2, sxtw #1
    //     0x6cc10c: ldur            w9, [x16, #0xf]
    //     0x6cc110: add             x9, x9, HEAP, lsl #32
    //     0x6cc114: sub             w2, w1, w9
    //     0x6cc118: add             x9, fp, w2, sxtw #2
    //     0x6cc11c: ldr             x9, [x9, #8]
    //     0x6cc120: add             w2, w8, #2
    //     0x6cc124: sbfx            x8, x2, #1, #0x1f
    //     0x6cc128: mov             x2, x8
    //     0x6cc12c: mov             x8, x9
    //     0x6cc130: b               #0x6cc138
    //     0x6cc134: mov             x8, NULL
    //     0x6cc138: lsl             x9, x2, #1
    //     0x6cc13c: lsl             w10, w9, #1
    //     0x6cc140: add             w11, w10, #8
    //     0x6cc144: add             x16, x0, w11, sxtw #1
    //     0x6cc148: ldur            w12, [x16, #0xf]
    //     0x6cc14c: add             x12, x12, HEAP, lsl #32
    //     0x6cc150: add             x16, PP, #0xc, lsl #12  ; [pp+0xcca8] "cardColor"
    //     0x6cc154: ldr             x16, [x16, #0xca8]
    //     0x6cc158: cmp             w12, w16
    //     0x6cc15c: b.ne            #0x6cc190
    //     0x6cc160: add             w2, w10, #0xa
    //     0x6cc164: add             x16, x0, w2, sxtw #1
    //     0x6cc168: ldur            w10, [x16, #0xf]
    //     0x6cc16c: add             x10, x10, HEAP, lsl #32
    //     0x6cc170: sub             w2, w1, w10
    //     0x6cc174: add             x10, fp, w2, sxtw #2
    //     0x6cc178: ldr             x10, [x10, #8]
    //     0x6cc17c: add             w2, w9, #2
    //     0x6cc180: sbfx            x9, x2, #1, #0x1f
    //     0x6cc184: mov             x2, x9
    //     0x6cc188: mov             x9, x10
    //     0x6cc18c: b               #0x6cc194
    //     0x6cc190: mov             x9, NULL
    //     0x6cc194: lsl             x10, x2, #1
    //     0x6cc198: lsl             w11, w10, #1
    //     0x6cc19c: add             w12, w11, #8
    //     0x6cc1a0: add             x16, x0, w12, sxtw #1
    //     0x6cc1a4: ldur            w13, [x16, #0xf]
    //     0x6cc1a8: add             x13, x13, HEAP, lsl #32
    //     0x6cc1ac: add             x16, PP, #0xc, lsl #12  ; [pp+0xccc8] "colorScheme"
    //     0x6cc1b0: ldr             x16, [x16, #0xcc8]
    //     0x6cc1b4: cmp             w13, w16
    //     0x6cc1b8: b.ne            #0x6cc1ec
    //     0x6cc1bc: add             w2, w11, #0xa
    //     0x6cc1c0: add             x16, x0, w2, sxtw #1
    //     0x6cc1c4: ldur            w11, [x16, #0xf]
    //     0x6cc1c8: add             x11, x11, HEAP, lsl #32
    //     0x6cc1cc: sub             w2, w1, w11
    //     0x6cc1d0: add             x11, fp, w2, sxtw #2
    //     0x6cc1d4: ldr             x11, [x11, #8]
    //     0x6cc1d8: add             w2, w10, #2
    //     0x6cc1dc: sbfx            x10, x2, #1, #0x1f
    //     0x6cc1e0: mov             x2, x10
    //     0x6cc1e4: mov             x10, x11
    //     0x6cc1e8: b               #0x6cc1f0
    //     0x6cc1ec: mov             x10, NULL
    //     0x6cc1f0: lsl             x11, x2, #1
    //     0x6cc1f4: lsl             w12, w11, #1
    //     0x6cc1f8: add             w13, w12, #8
    //     0x6cc1fc: add             x16, x0, w13, sxtw #1
    //     0x6cc200: ldur            w12, [x16, #0xf]
    //     0x6cc204: add             x12, x12, HEAP, lsl #32
    //     0x6cc208: add             x16, PP, #0xc, lsl #12  ; [pp+0xccd0] "cupertinoOverrideTheme"
    //     0x6cc20c: ldr             x16, [x16, #0xcd0]
    //     0x6cc210: cmp             w12, w16
    //     0x6cc214: b.ne            #0x6cc224
    //     0x6cc218: add             w2, w11, #2
    //     0x6cc21c: sbfx            x11, x2, #1, #0x1f
    //     0x6cc220: mov             x2, x11
    //     0x6cc224: lsl             x11, x2, #1
    //     0x6cc228: lsl             w12, w11, #1
    //     0x6cc22c: add             w13, w12, #8
    //     0x6cc230: add             x16, x0, w13, sxtw #1
    //     0x6cc234: ldur            w14, [x16, #0xf]
    //     0x6cc238: add             x14, x14, HEAP, lsl #32
    //     0x6cc23c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd58] "highlightColor"
    //     0x6cc240: ldr             x16, [x16, #0xd58]
    //     0x6cc244: cmp             w14, w16
    //     0x6cc248: b.ne            #0x6cc27c
    //     0x6cc24c: add             w2, w12, #0xa
    //     0x6cc250: add             x16, x0, w2, sxtw #1
    //     0x6cc254: ldur            w12, [x16, #0xf]
    //     0x6cc258: add             x12, x12, HEAP, lsl #32
    //     0x6cc25c: sub             w2, w1, w12
    //     0x6cc260: add             x12, fp, w2, sxtw #2
    //     0x6cc264: ldr             x12, [x12, #8]
    //     0x6cc268: add             w2, w11, #2
    //     0x6cc26c: sbfx            x11, x2, #1, #0x1f
    //     0x6cc270: mov             x2, x11
    //     0x6cc274: mov             x11, x12
    //     0x6cc278: b               #0x6cc280
    //     0x6cc27c: mov             x11, NULL
    //     0x6cc280: stur            x11, [fp, #-0xa8]
    //     0x6cc284: lsl             x12, x2, #1
    //     0x6cc288: lsl             w13, w12, #1
    //     0x6cc28c: add             w14, w13, #8
    //     0x6cc290: add             x16, x0, w14, sxtw #1
    //     0x6cc294: ldur            w19, [x16, #0xf]
    //     0x6cc298: add             x19, x19, HEAP, lsl #32
    //     0x6cc29c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd80] "indicatorColor"
    //     0x6cc2a0: ldr             x16, [x16, #0xd80]
    //     0x6cc2a4: cmp             w19, w16
    //     0x6cc2a8: b.ne            #0x6cc2dc
    //     0x6cc2ac: add             w2, w13, #0xa
    //     0x6cc2b0: add             x16, x0, w2, sxtw #1
    //     0x6cc2b4: ldur            w13, [x16, #0xf]
    //     0x6cc2b8: add             x13, x13, HEAP, lsl #32
    //     0x6cc2bc: sub             w2, w1, w13
    //     0x6cc2c0: add             x13, fp, w2, sxtw #2
    //     0x6cc2c4: ldr             x13, [x13, #8]
    //     0x6cc2c8: add             w2, w12, #2
    //     0x6cc2cc: sbfx            x12, x2, #1, #0x1f
    //     0x6cc2d0: mov             x2, x12
    //     0x6cc2d4: mov             x12, x13
    //     0x6cc2d8: b               #0x6cc2e0
    //     0x6cc2dc: mov             x12, NULL
    //     0x6cc2e0: stur            x12, [fp, #-0xa0]
    //     0x6cc2e4: lsl             x13, x2, #1
    //     0x6cc2e8: lsl             w14, w13, #1
    //     0x6cc2ec: add             w19, w14, #8
    //     0x6cc2f0: add             x16, x0, w19, sxtw #1
    //     0x6cc2f4: ldur            w20, [x16, #0xf]
    //     0x6cc2f8: add             x20, x20, HEAP, lsl #32
    //     0x6cc2fc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdf0] "primaryColor"
    //     0x6cc300: ldr             x16, [x16, #0xdf0]
    //     0x6cc304: cmp             w20, w16
    //     0x6cc308: b.ne            #0x6cc33c
    //     0x6cc30c: add             w2, w14, #0xa
    //     0x6cc310: add             x16, x0, w2, sxtw #1
    //     0x6cc314: ldur            w14, [x16, #0xf]
    //     0x6cc318: add             x14, x14, HEAP, lsl #32
    //     0x6cc31c: sub             w2, w1, w14
    //     0x6cc320: add             x14, fp, w2, sxtw #2
    //     0x6cc324: ldr             x14, [x14, #8]
    //     0x6cc328: add             w2, w13, #2
    //     0x6cc32c: sbfx            x13, x2, #1, #0x1f
    //     0x6cc330: mov             x2, x13
    //     0x6cc334: mov             x13, x14
    //     0x6cc338: b               #0x6cc340
    //     0x6cc33c: mov             x13, NULL
    //     0x6cc340: stur            x13, [fp, #-0x98]
    //     0x6cc344: lsl             x14, x2, #1
    //     0x6cc348: lsl             w19, w14, #1
    //     0x6cc34c: add             w20, w19, #8
    //     0x6cc350: add             x16, x0, w20, sxtw #1
    //     0x6cc354: ldur            w23, [x16, #0xf]
    //     0x6cc358: add             x23, x23, HEAP, lsl #32
    //     0x6cc35c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce00] "primaryColorDark"
    //     0x6cc360: ldr             x16, [x16, #0xe00]
    //     0x6cc364: cmp             w23, w16
    //     0x6cc368: b.ne            #0x6cc39c
    //     0x6cc36c: add             w2, w19, #0xa
    //     0x6cc370: add             x16, x0, w2, sxtw #1
    //     0x6cc374: ldur            w19, [x16, #0xf]
    //     0x6cc378: add             x19, x19, HEAP, lsl #32
    //     0x6cc37c: sub             w2, w1, w19
    //     0x6cc380: add             x19, fp, w2, sxtw #2
    //     0x6cc384: ldr             x19, [x19, #8]
    //     0x6cc388: add             w2, w14, #2
    //     0x6cc38c: sbfx            x14, x2, #1, #0x1f
    //     0x6cc390: mov             x2, x14
    //     0x6cc394: mov             x14, x19
    //     0x6cc398: b               #0x6cc3a0
    //     0x6cc39c: mov             x14, NULL
    //     0x6cc3a0: stur            x14, [fp, #-0x90]
    //     0x6cc3a4: lsl             x19, x2, #1
    //     0x6cc3a8: lsl             w20, w19, #1
    //     0x6cc3ac: add             w23, w20, #8
    //     0x6cc3b0: add             x16, x0, w23, sxtw #1
    //     0x6cc3b4: ldur            w24, [x16, #0xf]
    //     0x6cc3b8: add             x24, x24, HEAP, lsl #32
    //     0x6cc3bc: add             x16, PP, #0xc, lsl #12  ; [pp+0xce08] "primaryColorLight"
    //     0x6cc3c0: ldr             x16, [x16, #0xe08]
    //     0x6cc3c4: cmp             w24, w16
    //     0x6cc3c8: b.ne            #0x6cc3fc
    //     0x6cc3cc: add             w2, w20, #0xa
    //     0x6cc3d0: add             x16, x0, w2, sxtw #1
    //     0x6cc3d4: ldur            w20, [x16, #0xf]
    //     0x6cc3d8: add             x20, x20, HEAP, lsl #32
    //     0x6cc3dc: sub             w2, w1, w20
    //     0x6cc3e0: add             x20, fp, w2, sxtw #2
    //     0x6cc3e4: ldr             x20, [x20, #8]
    //     0x6cc3e8: add             w2, w19, #2
    //     0x6cc3ec: sbfx            x19, x2, #1, #0x1f
    //     0x6cc3f0: mov             x2, x19
    //     0x6cc3f4: mov             x19, x20
    //     0x6cc3f8: b               #0x6cc400
    //     0x6cc3fc: mov             x19, NULL
    //     0x6cc400: stur            x19, [fp, #-0x88]
    //     0x6cc404: lsl             x20, x2, #1
    //     0x6cc408: lsl             w23, w20, #1
    //     0x6cc40c: add             w24, w23, #8
    //     0x6cc410: add             x16, x0, w24, sxtw #1
    //     0x6cc414: ldur            w25, [x16, #0xf]
    //     0x6cc418: add             x25, x25, HEAP, lsl #32
    //     0x6cc41c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] "primaryTextTheme"
    //     0x6cc420: ldr             x16, [x16, #0xe20]
    //     0x6cc424: cmp             w25, w16
    //     0x6cc428: b.ne            #0x6cc45c
    //     0x6cc42c: add             w2, w23, #0xa
    //     0x6cc430: add             x16, x0, w2, sxtw #1
    //     0x6cc434: ldur            w23, [x16, #0xf]
    //     0x6cc438: add             x23, x23, HEAP, lsl #32
    //     0x6cc43c: sub             w2, w1, w23
    //     0x6cc440: add             x23, fp, w2, sxtw #2
    //     0x6cc444: ldr             x23, [x23, #8]
    //     0x6cc448: add             w2, w20, #2
    //     0x6cc44c: sbfx            x20, x2, #1, #0x1f
    //     0x6cc450: mov             x2, x20
    //     0x6cc454: mov             x20, x23
    //     0x6cc458: b               #0x6cc460
    //     0x6cc45c: mov             x20, NULL
    //     0x6cc460: stur            x20, [fp, #-0x80]
    //     0x6cc464: lsl             x23, x2, #1
    //     0x6cc468: lsl             w24, w23, #1
    //     0x6cc46c: add             w25, w24, #8
    //     0x6cc470: add             x16, x0, w25, sxtw #1
    //     0x6cc474: ldur            w4, [x16, #0xf]
    //     0x6cc478: add             x4, x4, HEAP, lsl #32
    //     0x6cc47c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce38] "scaffoldBackgroundColor"
    //     0x6cc480: ldr             x16, [x16, #0xe38]
    //     0x6cc484: cmp             w4, w16
    //     0x6cc488: b.ne            #0x6cc4b8
    //     0x6cc48c: add             w2, w24, #0xa
    //     0x6cc490: add             x16, x0, w2, sxtw #1
    //     0x6cc494: ldur            w4, [x16, #0xf]
    //     0x6cc498: add             x4, x4, HEAP, lsl #32
    //     0x6cc49c: sub             w2, w1, w4
    //     0x6cc4a0: add             x4, fp, w2, sxtw #2
    //     0x6cc4a4: ldr             x4, [x4, #8]
    //     0x6cc4a8: add             w2, w23, #2
    //     0x6cc4ac: sbfx            x23, x2, #1, #0x1f
    //     0x6cc4b0: mov             x2, x23
    //     0x6cc4b4: b               #0x6cc4bc
    //     0x6cc4b8: mov             x4, NULL
    //     0x6cc4bc: stur            x4, [fp, #-0x10]
    //     0x6cc4c0: lsl             x23, x2, #1
    //     0x6cc4c4: lsl             w24, w23, #1
    //     0x6cc4c8: add             w25, w24, #8
    //     0x6cc4cc: add             x16, x0, w25, sxtw #1
    //     0x6cc4d0: ldur            w4, [x16, #0xf]
    //     0x6cc4d4: add             x4, x4, HEAP, lsl #32
    //     0x6cc4d8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcea0] "textSelectionTheme"
    //     0x6cc4dc: ldr             x16, [x16, #0xea0]
    //     0x6cc4e0: cmp             w4, w16
    //     0x6cc4e4: b.ne            #0x6cc514
    //     0x6cc4e8: add             w2, w24, #0xa
    //     0x6cc4ec: add             x16, x0, w2, sxtw #1
    //     0x6cc4f0: ldur            w4, [x16, #0xf]
    //     0x6cc4f4: add             x4, x4, HEAP, lsl #32
    //     0x6cc4f8: sub             w2, w1, w4
    //     0x6cc4fc: add             x4, fp, w2, sxtw #2
    //     0x6cc500: ldr             x4, [x4, #8]
    //     0x6cc504: add             w2, w23, #2
    //     0x6cc508: sbfx            x23, x2, #1, #0x1f
    //     0x6cc50c: mov             x2, x23
    //     0x6cc510: b               #0x6cc518
    //     0x6cc514: mov             x4, NULL
    //     0x6cc518: stur            x4, [fp, #-0x18]
    //     0x6cc51c: lsl             x23, x2, #1
    //     0x6cc520: lsl             w24, w23, #1
    //     0x6cc524: add             w25, w24, #8
    //     0x6cc528: add             x16, x0, w25, sxtw #1
    //     0x6cc52c: ldur            w4, [x16, #0xf]
    //     0x6cc530: add             x4, x4, HEAP, lsl #32
    //     0x6cc534: add             x16, PP, #0xc, lsl #12  ; [pp+0xcea8] "textTheme"
    //     0x6cc538: ldr             x16, [x16, #0xea8]
    //     0x6cc53c: cmp             w4, w16
    //     0x6cc540: b.ne            #0x6cc570
    //     0x6cc544: add             w2, w24, #0xa
    //     0x6cc548: add             x16, x0, w2, sxtw #1
    //     0x6cc54c: ldur            w4, [x16, #0xf]
    //     0x6cc550: add             x4, x4, HEAP, lsl #32
    //     0x6cc554: sub             w2, w1, w4
    //     0x6cc558: add             x4, fp, w2, sxtw #2
    //     0x6cc55c: ldr             x4, [x4, #8]
    //     0x6cc560: add             w2, w23, #2
    //     0x6cc564: sbfx            x23, x2, #1, #0x1f
    //     0x6cc568: mov             x2, x23
    //     0x6cc56c: b               #0x6cc574
    //     0x6cc570: mov             x4, NULL
    //     0x6cc574: stur            x4, [fp, #-0x78]
    //     0x6cc578: lsl             x23, x2, #1
    //     0x6cc57c: lsl             w2, w23, #1
    //     0x6cc580: add             w23, w2, #8
    //     0x6cc584: add             x16, x0, w23, sxtw #1
    //     0x6cc588: ldur            w24, [x16, #0xf]
    //     0x6cc58c: add             x24, x24, HEAP, lsl #32
    //     0x6cc590: add             x16, PP, #0xc, lsl #12  ; [pp+0xcec0] "toggleableActiveColor"
    //     0x6cc594: ldr             x16, [x16, #0xec0]
    //     0x6cc598: cmp             w24, w16
    //     0x6cc59c: b.ne            #0x6cc5c4
    //     0x6cc5a0: add             w23, w2, #0xa
    //     0x6cc5a4: add             x16, x0, w23, sxtw #1
    //     0x6cc5a8: ldur            w2, [x16, #0xf]
    //     0x6cc5ac: add             x2, x2, HEAP, lsl #32
    //     0x6cc5b0: sub             w0, w1, w2
    //     0x6cc5b4: add             x1, fp, w0, sxtw #2
    //     0x6cc5b8: ldr             x1, [x1, #8]
    //     0x6cc5bc: mov             x0, x1
    //     0x6cc5c0: b               #0x6cc5c8
    //     0x6cc5c4: mov             x0, NULL
    //     0x6cc5c8: stur            x0, [fp, #-0x20]
    // 0x6cc5cc: CheckStackOverflow
    //     0x6cc5cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cc5d0: cmp             SP, x16
    //     0x6cc5d4: b.ls            #0x6cd120
    // 0x6cc5d8: LoadField: r1 = r3->field_7
    //     0x6cc5d8: ldur            w1, [x3, #7]
    // 0x6cc5dc: DecompressPointer r1
    //     0x6cc5dc: add             x1, x1, HEAP, lsl #32
    // 0x6cc5e0: stur            x1, [fp, #-0x28]
    // 0x6cc5e4: LoadField: r2 = r3->field_f
    //     0x6cc5e4: ldur            w2, [x3, #0xf]
    // 0x6cc5e8: DecompressPointer r2
    //     0x6cc5e8: add             x2, x2, HEAP, lsl #32
    // 0x6cc5ec: stur            x2, [fp, #-0x30]
    // 0x6cc5f0: LoadField: r23 = r3->field_17
    //     0x6cc5f0: ldur            w23, [x3, #0x17]
    // 0x6cc5f4: DecompressPointer r23
    //     0x6cc5f4: add             x23, x23, HEAP, lsl #32
    // 0x6cc5f8: stur            x23, [fp, #-0x70]
    // 0x6cc5fc: LoadField: r24 = r3->field_1f
    //     0x6cc5fc: ldur            w24, [x3, #0x1f]
    // 0x6cc600: DecompressPointer r24
    //     0x6cc600: add             x24, x24, HEAP, lsl #32
    // 0x6cc604: stur            x24, [fp, #-0x68]
    // 0x6cc608: LoadField: r25 = r3->field_23
    //     0x6cc608: ldur            w25, [x3, #0x23]
    // 0x6cc60c: DecompressPointer r25
    //     0x6cc60c: add             x25, x25, HEAP, lsl #32
    // 0x6cc610: stur            x25, [fp, #-0x60]
    // 0x6cc614: LoadField: r0 = r3->field_27
    //     0x6cc614: ldur            w0, [x3, #0x27]
    // 0x6cc618: DecompressPointer r0
    //     0x6cc618: add             x0, x0, HEAP, lsl #32
    // 0x6cc61c: stur            x0, [fp, #-0x38]
    // 0x6cc620: LoadField: r1 = r3->field_2b
    //     0x6cc620: ldur            w1, [x3, #0x2b]
    // 0x6cc624: DecompressPointer r1
    //     0x6cc624: add             x1, x1, HEAP, lsl #32
    // 0x6cc628: stur            x1, [fp, #-0x40]
    // 0x6cc62c: LoadField: r2 = r3->field_2f
    //     0x6cc62c: ldur            w2, [x3, #0x2f]
    // 0x6cc630: DecompressPointer r2
    //     0x6cc630: add             x2, x2, HEAP, lsl #32
    // 0x6cc634: stur            x2, [fp, #-0x48]
    // 0x6cc638: cmp             w8, NULL
    // 0x6cc63c: b.ne            #0x6cc648
    // 0x6cc640: LoadField: r8 = r3->field_37
    //     0x6cc640: ldur            w8, [x3, #0x37]
    // 0x6cc644: DecompressPointer r8
    //     0x6cc644: add             x8, x8, HEAP, lsl #32
    // 0x6cc648: stur            x8, [fp, #-0x58]
    // 0x6cc64c: cmp             w9, NULL
    // 0x6cc650: b.ne            #0x6cc65c
    // 0x6cc654: LoadField: r9 = r3->field_3b
    //     0x6cc654: ldur            w9, [x3, #0x3b]
    // 0x6cc658: DecompressPointer r9
    //     0x6cc658: add             x9, x9, HEAP, lsl #32
    // 0x6cc65c: stur            x9, [fp, #-0x50]
    // 0x6cc660: cmp             w10, NULL
    // 0x6cc664: b.ne            #0x6cc670
    // 0x6cc668: LoadField: r10 = r3->field_3f
    //     0x6cc668: ldur            w10, [x3, #0x3f]
    // 0x6cc66c: DecompressPointer r10
    //     0x6cc66c: add             x10, x10, HEAP, lsl #32
    // 0x6cc670: mov             x16, x2
    // 0x6cc674: mov             x2, x0
    // 0x6cc678: mov             x0, x16
    // 0x6cc67c: SaveReg r10
    //     0x6cc67c: str             x10, [SP, #-8]!
    // 0x6cc680: r0 = copyWith()
    //     0x6cc680: bl              #0x6cd13c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::copyWith
    // 0x6cc684: add             SP, SP, #8
    // 0x6cc688: mov             x1, x0
    // 0x6cc68c: ldur            x0, [fp, #-0xc8]
    // 0x6cc690: stur            x1, [fp, #-0xd0]
    // 0x6cc694: LoadField: r2 = r0->field_43
    //     0x6cc694: ldur            w2, [x0, #0x43]
    // 0x6cc698: DecompressPointer r2
    //     0x6cc698: add             x2, x2, HEAP, lsl #32
    // 0x6cc69c: stur            x2, [fp, #-0xd8]
    // 0x6cc6a0: LoadField: r3 = r0->field_47
    //     0x6cc6a0: ldur            w3, [x0, #0x47]
    // 0x6cc6a4: DecompressPointer r3
    //     0x6cc6a4: add             x3, x3, HEAP, lsl #32
    // 0x6cc6a8: stur            x3, [fp, #-0xe0]
    // 0x6cc6ac: LoadField: r4 = r0->field_4b
    //     0x6cc6ac: ldur            w4, [x0, #0x4b]
    // 0x6cc6b0: DecompressPointer r4
    //     0x6cc6b0: add             x4, x4, HEAP, lsl #32
    // 0x6cc6b4: stur            x4, [fp, #-0xe8]
    // 0x6cc6b8: LoadField: r5 = r0->field_4f
    //     0x6cc6b8: ldur            w5, [x0, #0x4f]
    // 0x6cc6bc: DecompressPointer r5
    //     0x6cc6bc: add             x5, x5, HEAP, lsl #32
    // 0x6cc6c0: ldur            x6, [fp, #-0xa8]
    // 0x6cc6c4: stur            x5, [fp, #-0xf0]
    // 0x6cc6c8: cmp             w6, NULL
    // 0x6cc6cc: b.ne            #0x6cc6e0
    // 0x6cc6d0: LoadField: r6 = r0->field_53
    //     0x6cc6d0: ldur            w6, [x0, #0x53]
    // 0x6cc6d4: DecompressPointer r6
    //     0x6cc6d4: add             x6, x6, HEAP, lsl #32
    // 0x6cc6d8: mov             x7, x6
    // 0x6cc6dc: b               #0x6cc6e4
    // 0x6cc6e0: mov             x7, x6
    // 0x6cc6e4: ldur            x6, [fp, #-0xa0]
    // 0x6cc6e8: stur            x7, [fp, #-0xa8]
    // 0x6cc6ec: LoadField: r8 = r0->field_57
    //     0x6cc6ec: ldur            w8, [x0, #0x57]
    // 0x6cc6f0: DecompressPointer r8
    //     0x6cc6f0: add             x8, x8, HEAP, lsl #32
    // 0x6cc6f4: stur            x8, [fp, #-0xf8]
    // 0x6cc6f8: LoadField: r9 = r0->field_5b
    //     0x6cc6f8: ldur            w9, [x0, #0x5b]
    // 0x6cc6fc: DecompressPointer r9
    //     0x6cc6fc: add             x9, x9, HEAP, lsl #32
    // 0x6cc700: stur            x9, [fp, #-0x100]
    // 0x6cc704: cmp             w6, NULL
    // 0x6cc708: b.ne            #0x6cc71c
    // 0x6cc70c: LoadField: r6 = r0->field_5f
    //     0x6cc70c: ldur            w6, [x0, #0x5f]
    // 0x6cc710: DecompressPointer r6
    //     0x6cc710: add             x6, x6, HEAP, lsl #32
    // 0x6cc714: mov             x10, x6
    // 0x6cc718: b               #0x6cc720
    // 0x6cc71c: mov             x10, x6
    // 0x6cc720: ldur            x6, [fp, #-0x98]
    // 0x6cc724: stur            x10, [fp, #-0xa0]
    // 0x6cc728: cmp             w6, NULL
    // 0x6cc72c: b.ne            #0x6cc740
    // 0x6cc730: LoadField: r6 = r0->field_63
    //     0x6cc730: ldur            w6, [x0, #0x63]
    // 0x6cc734: DecompressPointer r6
    //     0x6cc734: add             x6, x6, HEAP, lsl #32
    // 0x6cc738: mov             x11, x6
    // 0x6cc73c: b               #0x6cc744
    // 0x6cc740: mov             x11, x6
    // 0x6cc744: ldur            x6, [fp, #-0x90]
    // 0x6cc748: stur            x11, [fp, #-0x98]
    // 0x6cc74c: cmp             w6, NULL
    // 0x6cc750: b.ne            #0x6cc764
    // 0x6cc754: LoadField: r6 = r0->field_67
    //     0x6cc754: ldur            w6, [x0, #0x67]
    // 0x6cc758: DecompressPointer r6
    //     0x6cc758: add             x6, x6, HEAP, lsl #32
    // 0x6cc75c: mov             x12, x6
    // 0x6cc760: b               #0x6cc768
    // 0x6cc764: mov             x12, x6
    // 0x6cc768: ldur            x6, [fp, #-0x88]
    // 0x6cc76c: stur            x12, [fp, #-0x90]
    // 0x6cc770: cmp             w6, NULL
    // 0x6cc774: b.ne            #0x6cc788
    // 0x6cc778: LoadField: r6 = r0->field_6b
    //     0x6cc778: ldur            w6, [x0, #0x6b]
    // 0x6cc77c: DecompressPointer r6
    //     0x6cc77c: add             x6, x6, HEAP, lsl #32
    // 0x6cc780: mov             x13, x6
    // 0x6cc784: b               #0x6cc78c
    // 0x6cc788: mov             x13, x6
    // 0x6cc78c: ldur            x6, [fp, #-0x10]
    // 0x6cc790: r17 = -264
    //     0x6cc790: mov             x17, #-0x108
    // 0x6cc794: str             x13, [fp, x17]
    // 0x6cc798: cmp             w6, NULL
    // 0x6cc79c: b.ne            #0x6cc7b0
    // 0x6cc7a0: LoadField: r6 = r0->field_6f
    //     0x6cc7a0: ldur            w6, [x0, #0x6f]
    // 0x6cc7a4: DecompressPointer r6
    //     0x6cc7a4: add             x6, x6, HEAP, lsl #32
    // 0x6cc7a8: mov             x14, x6
    // 0x6cc7ac: b               #0x6cc7b4
    // 0x6cc7b0: mov             x14, x6
    // 0x6cc7b4: ldur            x6, [fp, #-0x80]
    // 0x6cc7b8: r17 = -272
    //     0x6cc7b8: mov             x17, #-0x110
    // 0x6cc7bc: str             x14, [fp, x17]
    // 0x6cc7c0: LoadField: r19 = r0->field_73
    //     0x6cc7c0: ldur            w19, [x0, #0x73]
    // 0x6cc7c4: DecompressPointer r19
    //     0x6cc7c4: add             x19, x19, HEAP, lsl #32
    // 0x6cc7c8: r17 = -280
    //     0x6cc7c8: mov             x17, #-0x118
    // 0x6cc7cc: str             x19, [fp, x17]
    // 0x6cc7d0: LoadField: r20 = r0->field_7b
    //     0x6cc7d0: ldur            w20, [x0, #0x7b]
    // 0x6cc7d4: DecompressPointer r20
    //     0x6cc7d4: add             x20, x20, HEAP, lsl #32
    // 0x6cc7d8: r17 = -288
    //     0x6cc7d8: mov             x17, #-0x120
    // 0x6cc7dc: str             x20, [fp, x17]
    // 0x6cc7e0: LoadField: r23 = r0->field_7f
    //     0x6cc7e0: ldur            w23, [x0, #0x7f]
    // 0x6cc7e4: DecompressPointer r23
    //     0x6cc7e4: add             x23, x23, HEAP, lsl #32
    // 0x6cc7e8: r17 = -296
    //     0x6cc7e8: mov             x17, #-0x128
    // 0x6cc7ec: str             x23, [fp, x17]
    // 0x6cc7f0: LoadField: r24 = r0->field_83
    //     0x6cc7f0: ldur            w24, [x0, #0x83]
    // 0x6cc7f4: DecompressPointer r24
    //     0x6cc7f4: add             x24, x24, HEAP, lsl #32
    // 0x6cc7f8: r17 = -304
    //     0x6cc7f8: mov             x17, #-0x130
    // 0x6cc7fc: str             x24, [fp, x17]
    // 0x6cc800: LoadField: r25 = r0->field_87
    //     0x6cc800: ldur            w25, [x0, #0x87]
    // 0x6cc804: DecompressPointer r25
    //     0x6cc804: add             x25, x25, HEAP, lsl #32
    // 0x6cc808: r17 = -312
    //     0x6cc808: mov             x17, #-0x138
    // 0x6cc80c: str             x25, [fp, x17]
    // 0x6cc810: LoadField: r1 = r0->field_8b
    //     0x6cc810: ldur            w1, [x0, #0x8b]
    // 0x6cc814: DecompressPointer r1
    //     0x6cc814: add             x1, x1, HEAP, lsl #32
    // 0x6cc818: r17 = -320
    //     0x6cc818: mov             x17, #-0x140
    // 0x6cc81c: str             x1, [fp, x17]
    // 0x6cc820: cmp             w6, NULL
    // 0x6cc824: b.ne            #0x6cc838
    // 0x6cc828: LoadField: r6 = r0->field_8f
    //     0x6cc828: ldur            w6, [x0, #0x8f]
    // 0x6cc82c: DecompressPointer r6
    //     0x6cc82c: add             x6, x6, HEAP, lsl #32
    // 0x6cc830: stur            x6, [fp, #-0x10]
    // 0x6cc834: b               #0x6cc83c
    // 0x6cc838: stur            x6, [fp, #-0x10]
    // 0x6cc83c: ldur            x6, [fp, #-0x78]
    // 0x6cc840: cmp             w6, NULL
    // 0x6cc844: b.ne            #0x6cc858
    // 0x6cc848: LoadField: r6 = r0->field_93
    //     0x6cc848: ldur            w6, [x0, #0x93]
    // 0x6cc84c: DecompressPointer r6
    //     0x6cc84c: add             x6, x6, HEAP, lsl #32
    // 0x6cc850: stur            x6, [fp, #-0x78]
    // 0x6cc854: b               #0x6cc85c
    // 0x6cc858: stur            x6, [fp, #-0x78]
    // 0x6cc85c: ldur            x6, [fp, #-0xc0]
    // 0x6cc860: LoadField: r2 = r0->field_97
    //     0x6cc860: ldur            w2, [x0, #0x97]
    // 0x6cc864: DecompressPointer r2
    //     0x6cc864: add             x2, x2, HEAP, lsl #32
    // 0x6cc868: r17 = -680
    //     0x6cc868: mov             x17, #-0x2a8
    // 0x6cc86c: str             x2, [fp, x17]
    // 0x6cc870: cmp             w6, NULL
    // 0x6cc874: b.ne            #0x6cc888
    // 0x6cc878: LoadField: r6 = r0->field_9b
    //     0x6cc878: ldur            w6, [x0, #0x9b]
    // 0x6cc87c: DecompressPointer r6
    //     0x6cc87c: add             x6, x6, HEAP, lsl #32
    // 0x6cc880: stur            x6, [fp, #-0x80]
    // 0x6cc884: b               #0x6cc88c
    // 0x6cc888: stur            x6, [fp, #-0x80]
    // 0x6cc88c: ldur            x6, [fp, #-0xb0]
    // 0x6cc890: LoadField: r3 = r0->field_9f
    //     0x6cc890: ldur            w3, [x0, #0x9f]
    // 0x6cc894: DecompressPointer r3
    //     0x6cc894: add             x3, x3, HEAP, lsl #32
    // 0x6cc898: r17 = -672
    //     0x6cc898: mov             x17, #-0x2a0
    // 0x6cc89c: str             x3, [fp, x17]
    // 0x6cc8a0: LoadField: r4 = r0->field_a3
    //     0x6cc8a0: ldur            w4, [x0, #0xa3]
    // 0x6cc8a4: DecompressPointer r4
    //     0x6cc8a4: add             x4, x4, HEAP, lsl #32
    // 0x6cc8a8: r17 = -664
    //     0x6cc8a8: mov             x17, #-0x298
    // 0x6cc8ac: str             x4, [fp, x17]
    // 0x6cc8b0: LoadField: r5 = r0->field_a7
    //     0x6cc8b0: ldur            w5, [x0, #0xa7]
    // 0x6cc8b4: DecompressPointer r5
    //     0x6cc8b4: add             x5, x5, HEAP, lsl #32
    // 0x6cc8b8: r17 = -656
    //     0x6cc8b8: mov             x17, #-0x290
    // 0x6cc8bc: str             x5, [fp, x17]
    // 0x6cc8c0: LoadField: r7 = r0->field_ab
    //     0x6cc8c0: ldur            w7, [x0, #0xab]
    // 0x6cc8c4: DecompressPointer r7
    //     0x6cc8c4: add             x7, x7, HEAP, lsl #32
    // 0x6cc8c8: r17 = -648
    //     0x6cc8c8: mov             x17, #-0x288
    // 0x6cc8cc: str             x7, [fp, x17]
    // 0x6cc8d0: LoadField: r8 = r0->field_af
    //     0x6cc8d0: ldur            w8, [x0, #0xaf]
    // 0x6cc8d4: DecompressPointer r8
    //     0x6cc8d4: add             x8, x8, HEAP, lsl #32
    // 0x6cc8d8: r17 = -640
    //     0x6cc8d8: mov             x17, #-0x280
    // 0x6cc8dc: str             x8, [fp, x17]
    // 0x6cc8e0: LoadField: r9 = r0->field_b3
    //     0x6cc8e0: ldur            w9, [x0, #0xb3]
    // 0x6cc8e4: DecompressPointer r9
    //     0x6cc8e4: add             x9, x9, HEAP, lsl #32
    // 0x6cc8e8: r17 = -632
    //     0x6cc8e8: mov             x17, #-0x278
    // 0x6cc8ec: str             x9, [fp, x17]
    // 0x6cc8f0: cmp             w6, NULL
    // 0x6cc8f4: b.ne            #0x6cc908
    // 0x6cc8f8: LoadField: r6 = r0->field_b7
    //     0x6cc8f8: ldur            w6, [x0, #0xb7]
    // 0x6cc8fc: DecompressPointer r6
    //     0x6cc8fc: add             x6, x6, HEAP, lsl #32
    // 0x6cc900: stur            x6, [fp, #-0x88]
    // 0x6cc904: b               #0x6cc90c
    // 0x6cc908: stur            x6, [fp, #-0x88]
    // 0x6cc90c: ldur            x6, [fp, #-0x18]
    // 0x6cc910: LoadField: r10 = r0->field_bb
    //     0x6cc910: ldur            w10, [x0, #0xbb]
    // 0x6cc914: DecompressPointer r10
    //     0x6cc914: add             x10, x10, HEAP, lsl #32
    // 0x6cc918: r17 = -624
    //     0x6cc918: mov             x17, #-0x270
    // 0x6cc91c: str             x10, [fp, x17]
    // 0x6cc920: LoadField: r11 = r0->field_bf
    //     0x6cc920: ldur            w11, [x0, #0xbf]
    // 0x6cc924: DecompressPointer r11
    //     0x6cc924: add             x11, x11, HEAP, lsl #32
    // 0x6cc928: r17 = -616
    //     0x6cc928: mov             x17, #-0x268
    // 0x6cc92c: str             x11, [fp, x17]
    // 0x6cc930: LoadField: r12 = r0->field_c3
    //     0x6cc930: ldur            w12, [x0, #0xc3]
    // 0x6cc934: DecompressPointer r12
    //     0x6cc934: add             x12, x12, HEAP, lsl #32
    // 0x6cc938: r17 = -608
    //     0x6cc938: mov             x17, #-0x260
    // 0x6cc93c: str             x12, [fp, x17]
    // 0x6cc940: LoadField: r13 = r0->field_c7
    //     0x6cc940: ldur            w13, [x0, #0xc7]
    // 0x6cc944: DecompressPointer r13
    //     0x6cc944: add             x13, x13, HEAP, lsl #32
    // 0x6cc948: r17 = -600
    //     0x6cc948: mov             x17, #-0x258
    // 0x6cc94c: str             x13, [fp, x17]
    // 0x6cc950: LoadField: r14 = r0->field_cb
    //     0x6cc950: ldur            w14, [x0, #0xcb]
    // 0x6cc954: DecompressPointer r14
    //     0x6cc954: add             x14, x14, HEAP, lsl #32
    // 0x6cc958: r17 = -592
    //     0x6cc958: mov             x17, #-0x250
    // 0x6cc95c: str             x14, [fp, x17]
    // 0x6cc960: LoadField: r19 = r0->field_cf
    //     0x6cc960: ldur            w19, [x0, #0xcf]
    // 0x6cc964: DecompressPointer r19
    //     0x6cc964: add             x19, x19, HEAP, lsl #32
    // 0x6cc968: r17 = -584
    //     0x6cc968: mov             x17, #-0x248
    // 0x6cc96c: str             x19, [fp, x17]
    // 0x6cc970: LoadField: r20 = r0->field_d3
    //     0x6cc970: ldur            w20, [x0, #0xd3]
    // 0x6cc974: DecompressPointer r20
    //     0x6cc974: add             x20, x20, HEAP, lsl #32
    // 0x6cc978: r17 = -576
    //     0x6cc978: mov             x17, #-0x240
    // 0x6cc97c: str             x20, [fp, x17]
    // 0x6cc980: LoadField: r23 = r0->field_d7
    //     0x6cc980: ldur            w23, [x0, #0xd7]
    // 0x6cc984: DecompressPointer r23
    //     0x6cc984: add             x23, x23, HEAP, lsl #32
    // 0x6cc988: r17 = -568
    //     0x6cc988: mov             x17, #-0x238
    // 0x6cc98c: str             x23, [fp, x17]
    // 0x6cc990: LoadField: r24 = r0->field_db
    //     0x6cc990: ldur            w24, [x0, #0xdb]
    // 0x6cc994: DecompressPointer r24
    //     0x6cc994: add             x24, x24, HEAP, lsl #32
    // 0x6cc998: r17 = -560
    //     0x6cc998: mov             x17, #-0x230
    // 0x6cc99c: str             x24, [fp, x17]
    // 0x6cc9a0: LoadField: r25 = r0->field_df
    //     0x6cc9a0: ldur            w25, [x0, #0xdf]
    // 0x6cc9a4: DecompressPointer r25
    //     0x6cc9a4: add             x25, x25, HEAP, lsl #32
    // 0x6cc9a8: r17 = -552
    //     0x6cc9a8: mov             x17, #-0x228
    // 0x6cc9ac: str             x25, [fp, x17]
    // 0x6cc9b0: LoadField: r1 = r0->field_e3
    //     0x6cc9b0: ldur            w1, [x0, #0xe3]
    // 0x6cc9b4: DecompressPointer r1
    //     0x6cc9b4: add             x1, x1, HEAP, lsl #32
    // 0x6cc9b8: stur            x1, [fp, #-0xb0]
    // 0x6cc9bc: LoadField: r1 = r0->field_e7
    //     0x6cc9bc: ldur            w1, [x0, #0xe7]
    // 0x6cc9c0: DecompressPointer r1
    //     0x6cc9c0: add             x1, x1, HEAP, lsl #32
    // 0x6cc9c4: stur            x1, [fp, #-0xc0]
    // 0x6cc9c8: LoadField: r1 = r0->field_eb
    //     0x6cc9c8: ldur            w1, [x0, #0xeb]
    // 0x6cc9cc: DecompressPointer r1
    //     0x6cc9cc: add             x1, x1, HEAP, lsl #32
    // 0x6cc9d0: r17 = -328
    //     0x6cc9d0: mov             x17, #-0x148
    // 0x6cc9d4: str             x1, [fp, x17]
    // 0x6cc9d8: LoadField: r1 = r0->field_ef
    //     0x6cc9d8: ldur            w1, [x0, #0xef]
    // 0x6cc9dc: DecompressPointer r1
    //     0x6cc9dc: add             x1, x1, HEAP, lsl #32
    // 0x6cc9e0: r17 = -336
    //     0x6cc9e0: mov             x17, #-0x150
    // 0x6cc9e4: str             x1, [fp, x17]
    // 0x6cc9e8: LoadField: r1 = r0->field_f3
    //     0x6cc9e8: ldur            w1, [x0, #0xf3]
    // 0x6cc9ec: DecompressPointer r1
    //     0x6cc9ec: add             x1, x1, HEAP, lsl #32
    // 0x6cc9f0: r17 = -344
    //     0x6cc9f0: mov             x17, #-0x158
    // 0x6cc9f4: str             x1, [fp, x17]
    // 0x6cc9f8: LoadField: r1 = r0->field_f7
    //     0x6cc9f8: ldur            w1, [x0, #0xf7]
    // 0x6cc9fc: DecompressPointer r1
    //     0x6cc9fc: add             x1, x1, HEAP, lsl #32
    // 0x6cca00: r17 = -352
    //     0x6cca00: mov             x17, #-0x160
    // 0x6cca04: str             x1, [fp, x17]
    // 0x6cca08: LoadField: r1 = r0->field_fb
    //     0x6cca08: ldur            w1, [x0, #0xfb]
    // 0x6cca0c: DecompressPointer r1
    //     0x6cca0c: add             x1, x1, HEAP, lsl #32
    // 0x6cca10: r17 = -360
    //     0x6cca10: mov             x17, #-0x168
    // 0x6cca14: str             x1, [fp, x17]
    // 0x6cca18: LoadField: r1 = r0->field_ff
    //     0x6cca18: ldur            w1, [x0, #0xff]
    // 0x6cca1c: DecompressPointer r1
    //     0x6cca1c: add             x1, x1, HEAP, lsl #32
    // 0x6cca20: r17 = -368
    //     0x6cca20: mov             x17, #-0x170
    // 0x6cca24: str             x1, [fp, x17]
    // 0x6cca28: r17 = 259
    //     0x6cca28: mov             x17, #0x103
    // 0x6cca2c: ldr             w1, [x0, x17]
    // 0x6cca30: DecompressPointer r1
    //     0x6cca30: add             x1, x1, HEAP, lsl #32
    // 0x6cca34: r17 = -376
    //     0x6cca34: mov             x17, #-0x178
    // 0x6cca38: str             x1, [fp, x17]
    // 0x6cca3c: r17 = 263
    //     0x6cca3c: mov             x17, #0x107
    // 0x6cca40: ldr             w1, [x0, x17]
    // 0x6cca44: DecompressPointer r1
    //     0x6cca44: add             x1, x1, HEAP, lsl #32
    // 0x6cca48: r17 = -384
    //     0x6cca48: mov             x17, #-0x180
    // 0x6cca4c: str             x1, [fp, x17]
    // 0x6cca50: r17 = 267
    //     0x6cca50: mov             x17, #0x10b
    // 0x6cca54: ldr             w1, [x0, x17]
    // 0x6cca58: DecompressPointer r1
    //     0x6cca58: add             x1, x1, HEAP, lsl #32
    // 0x6cca5c: r17 = -392
    //     0x6cca5c: mov             x17, #-0x188
    // 0x6cca60: str             x1, [fp, x17]
    // 0x6cca64: r17 = 271
    //     0x6cca64: mov             x17, #0x10f
    // 0x6cca68: ldr             w1, [x0, x17]
    // 0x6cca6c: DecompressPointer r1
    //     0x6cca6c: add             x1, x1, HEAP, lsl #32
    // 0x6cca70: r17 = -400
    //     0x6cca70: mov             x17, #-0x190
    // 0x6cca74: str             x1, [fp, x17]
    // 0x6cca78: r17 = 275
    //     0x6cca78: mov             x17, #0x113
    // 0x6cca7c: ldr             w1, [x0, x17]
    // 0x6cca80: DecompressPointer r1
    //     0x6cca80: add             x1, x1, HEAP, lsl #32
    // 0x6cca84: r17 = -408
    //     0x6cca84: mov             x17, #-0x198
    // 0x6cca88: str             x1, [fp, x17]
    // 0x6cca8c: r17 = 279
    //     0x6cca8c: mov             x17, #0x117
    // 0x6cca90: ldr             w1, [x0, x17]
    // 0x6cca94: DecompressPointer r1
    //     0x6cca94: add             x1, x1, HEAP, lsl #32
    // 0x6cca98: r17 = -416
    //     0x6cca98: mov             x17, #-0x1a0
    // 0x6cca9c: str             x1, [fp, x17]
    // 0x6ccaa0: r17 = 283
    //     0x6ccaa0: mov             x17, #0x11b
    // 0x6ccaa4: ldr             w1, [x0, x17]
    // 0x6ccaa8: DecompressPointer r1
    //     0x6ccaa8: add             x1, x1, HEAP, lsl #32
    // 0x6ccaac: r17 = -424
    //     0x6ccaac: mov             x17, #-0x1a8
    // 0x6ccab0: str             x1, [fp, x17]
    // 0x6ccab4: r17 = 287
    //     0x6ccab4: mov             x17, #0x11f
    // 0x6ccab8: ldr             w1, [x0, x17]
    // 0x6ccabc: DecompressPointer r1
    //     0x6ccabc: add             x1, x1, HEAP, lsl #32
    // 0x6ccac0: r17 = -432
    //     0x6ccac0: mov             x17, #-0x1b0
    // 0x6ccac4: str             x1, [fp, x17]
    // 0x6ccac8: r17 = 291
    //     0x6ccac8: mov             x17, #0x123
    // 0x6ccacc: ldr             w1, [x0, x17]
    // 0x6ccad0: DecompressPointer r1
    //     0x6ccad0: add             x1, x1, HEAP, lsl #32
    // 0x6ccad4: r17 = -440
    //     0x6ccad4: mov             x17, #-0x1b8
    // 0x6ccad8: str             x1, [fp, x17]
    // 0x6ccadc: r17 = 295
    //     0x6ccadc: mov             x17, #0x127
    // 0x6ccae0: ldr             w1, [x0, x17]
    // 0x6ccae4: DecompressPointer r1
    //     0x6ccae4: add             x1, x1, HEAP, lsl #32
    // 0x6ccae8: r17 = -448
    //     0x6ccae8: mov             x17, #-0x1c0
    // 0x6ccaec: str             x1, [fp, x17]
    // 0x6ccaf0: r17 = 299
    //     0x6ccaf0: mov             x17, #0x12b
    // 0x6ccaf4: ldr             w1, [x0, x17]
    // 0x6ccaf8: DecompressPointer r1
    //     0x6ccaf8: add             x1, x1, HEAP, lsl #32
    // 0x6ccafc: r17 = -456
    //     0x6ccafc: mov             x17, #-0x1c8
    // 0x6ccb00: str             x1, [fp, x17]
    // 0x6ccb04: r17 = 303
    //     0x6ccb04: mov             x17, #0x12f
    // 0x6ccb08: ldr             w1, [x0, x17]
    // 0x6ccb0c: DecompressPointer r1
    //     0x6ccb0c: add             x1, x1, HEAP, lsl #32
    // 0x6ccb10: r17 = -464
    //     0x6ccb10: mov             x17, #-0x1d0
    // 0x6ccb14: str             x1, [fp, x17]
    // 0x6ccb18: cmp             w6, NULL
    // 0x6ccb1c: b.ne            #0x6ccb34
    // 0x6ccb20: r17 = 307
    //     0x6ccb20: mov             x17, #0x133
    // 0x6ccb24: ldr             w6, [x0, x17]
    // 0x6ccb28: DecompressPointer r6
    //     0x6ccb28: add             x6, x6, HEAP, lsl #32
    // 0x6ccb2c: stur            x6, [fp, #-0x18]
    // 0x6ccb30: b               #0x6ccb38
    // 0x6ccb34: stur            x6, [fp, #-0x18]
    // 0x6ccb38: ldur            x6, [fp, #-8]
    // 0x6ccb3c: r17 = 311
    //     0x6ccb3c: mov             x17, #0x137
    // 0x6ccb40: ldr             w1, [x0, x17]
    // 0x6ccb44: DecompressPointer r1
    //     0x6ccb44: add             x1, x1, HEAP, lsl #32
    // 0x6ccb48: r17 = -472
    //     0x6ccb48: mov             x17, #-0x1d8
    // 0x6ccb4c: str             x1, [fp, x17]
    // 0x6ccb50: r17 = 315
    //     0x6ccb50: mov             x17, #0x13b
    // 0x6ccb54: ldr             w1, [x0, x17]
    // 0x6ccb58: DecompressPointer r1
    //     0x6ccb58: add             x1, x1, HEAP, lsl #32
    // 0x6ccb5c: r17 = -480
    //     0x6ccb5c: mov             x17, #-0x1e0
    // 0x6ccb60: str             x1, [fp, x17]
    // 0x6ccb64: r17 = 319
    //     0x6ccb64: mov             x17, #0x13f
    // 0x6ccb68: ldr             w1, [x0, x17]
    // 0x6ccb6c: DecompressPointer r1
    //     0x6ccb6c: add             x1, x1, HEAP, lsl #32
    // 0x6ccb70: r17 = -488
    //     0x6ccb70: mov             x17, #-0x1e8
    // 0x6ccb74: str             x1, [fp, x17]
    // 0x6ccb78: r17 = 323
    //     0x6ccb78: mov             x17, #0x143
    // 0x6ccb7c: ldr             w1, [x0, x17]
    // 0x6ccb80: DecompressPointer r1
    //     0x6ccb80: add             x1, x1, HEAP, lsl #32
    // 0x6ccb84: r17 = -496
    //     0x6ccb84: mov             x17, #-0x1f0
    // 0x6ccb88: str             x1, [fp, x17]
    // 0x6ccb8c: r17 = 327
    //     0x6ccb8c: mov             x17, #0x147
    // 0x6ccb90: ldr             w1, [x0, x17]
    // 0x6ccb94: DecompressPointer r1
    //     0x6ccb94: add             x1, x1, HEAP, lsl #32
    // 0x6ccb98: r17 = -504
    //     0x6ccb98: mov             x17, #-0x1f8
    // 0x6ccb9c: str             x1, [fp, x17]
    // 0x6ccba0: cmp             w6, NULL
    // 0x6ccba4: b.ne            #0x6ccbbc
    // 0x6ccba8: r17 = 331
    //     0x6ccba8: mov             x17, #0x14b
    // 0x6ccbac: ldr             w6, [x0, x17]
    // 0x6ccbb0: DecompressPointer r6
    //     0x6ccbb0: add             x6, x6, HEAP, lsl #32
    // 0x6ccbb4: stur            x6, [fp, #-8]
    // 0x6ccbb8: b               #0x6ccbc0
    // 0x6ccbbc: stur            x6, [fp, #-8]
    // 0x6ccbc0: ldur            x6, [fp, #-0x20]
    // 0x6ccbc4: r17 = 335
    //     0x6ccbc4: mov             x17, #0x14f
    // 0x6ccbc8: ldr             w1, [x0, x17]
    // 0x6ccbcc: DecompressPointer r1
    //     0x6ccbcc: add             x1, x1, HEAP, lsl #32
    // 0x6ccbd0: r17 = -512
    //     0x6ccbd0: mov             x17, #-0x200
    // 0x6ccbd4: str             x1, [fp, x17]
    // 0x6ccbd8: r17 = 339
    //     0x6ccbd8: mov             x17, #0x153
    // 0x6ccbdc: ldr             w1, [x0, x17]
    // 0x6ccbe0: DecompressPointer r1
    //     0x6ccbe0: add             x1, x1, HEAP, lsl #32
    // 0x6ccbe4: r17 = -520
    //     0x6ccbe4: mov             x17, #-0x208
    // 0x6ccbe8: str             x1, [fp, x17]
    // 0x6ccbec: r17 = 347
    //     0x6ccbec: mov             x17, #0x15b
    // 0x6ccbf0: ldr             w1, [x0, x17]
    // 0x6ccbf4: DecompressPointer r1
    //     0x6ccbf4: add             x1, x1, HEAP, lsl #32
    // 0x6ccbf8: r17 = -528
    //     0x6ccbf8: mov             x17, #-0x210
    // 0x6ccbfc: str             x1, [fp, x17]
    // 0x6ccc00: cmp             w6, NULL
    // 0x6ccc04: b.ne            #0x6ccc1c
    // 0x6ccc08: r17 = 363
    //     0x6ccc08: mov             x17, #0x16b
    // 0x6ccc0c: ldr             w6, [x0, x17]
    // 0x6ccc10: DecompressPointer r6
    //     0x6ccc10: add             x6, x6, HEAP, lsl #32
    // 0x6ccc14: stur            x6, [fp, #-0x20]
    // 0x6ccc18: b               #0x6ccc20
    // 0x6ccc1c: stur            x6, [fp, #-0x20]
    // 0x6ccc20: ldur            x6, [fp, #-0xb8]
    // 0x6ccc24: LoadField: r1 = r0->field_77
    //     0x6ccc24: ldur            w1, [x0, #0x77]
    // 0x6ccc28: DecompressPointer r1
    //     0x6ccc28: add             x1, x1, HEAP, lsl #32
    // 0x6ccc2c: r17 = -536
    //     0x6ccc2c: mov             x17, #-0x218
    // 0x6ccc30: str             x1, [fp, x17]
    // 0x6ccc34: r17 = 355
    //     0x6ccc34: mov             x17, #0x163
    // 0x6ccc38: ldr             w1, [x0, x17]
    // 0x6ccc3c: DecompressPointer r1
    //     0x6ccc3c: add             x1, x1, HEAP, lsl #32
    // 0x6ccc40: r17 = -544
    //     0x6ccc40: mov             x17, #-0x220
    // 0x6ccc44: str             x1, [fp, x17]
    // 0x6ccc48: r17 = 359
    //     0x6ccc48: mov             x17, #0x167
    // 0x6ccc4c: ldr             w1, [x0, x17]
    // 0x6ccc50: DecompressPointer r1
    //     0x6ccc50: add             x1, x1, HEAP, lsl #32
    // 0x6ccc54: r17 = -688
    //     0x6ccc54: mov             x17, #-0x2b0
    // 0x6ccc58: str             x1, [fp, x17]
    // 0x6ccc5c: cmp             w6, NULL
    // 0x6ccc60: b.ne            #0x6ccc74
    // 0x6ccc64: LoadField: r6 = r0->field_33
    //     0x6ccc64: ldur            w6, [x0, #0x33]
    // 0x6ccc68: DecompressPointer r6
    //     0x6ccc68: add             x6, x6, HEAP, lsl #32
    // 0x6ccc6c: stur            x6, [fp, #-0xb8]
    // 0x6ccc70: b               #0x6ccc78
    // 0x6ccc74: stur            x6, [fp, #-0xb8]
    // 0x6ccc78: r17 = -424
    //     0x6ccc78: mov             x17, #-0x1a8
    // 0x6ccc7c: ldr             x25, [fp, x17]
    // 0x6ccc80: r17 = -432
    //     0x6ccc80: mov             x17, #-0x1b0
    // 0x6ccc84: ldr             x24, [fp, x17]
    // 0x6ccc88: r17 = -440
    //     0x6ccc88: mov             x17, #-0x1b8
    // 0x6ccc8c: ldr             x23, [fp, x17]
    // 0x6ccc90: r17 = -448
    //     0x6ccc90: mov             x17, #-0x1c0
    // 0x6ccc94: ldr             x20, [fp, x17]
    // 0x6ccc98: r17 = -456
    //     0x6ccc98: mov             x17, #-0x1c8
    // 0x6ccc9c: ldr             x19, [fp, x17]
    // 0x6ccca0: r17 = -464
    //     0x6ccca0: mov             x17, #-0x1d0
    // 0x6ccca4: ldr             x14, [fp, x17]
    // 0x6ccca8: ldur            x13, [fp, #-0x18]
    // 0x6cccac: r17 = -472
    //     0x6cccac: mov             x17, #-0x1d8
    // 0x6cccb0: ldr             x12, [fp, x17]
    // 0x6cccb4: r17 = -480
    //     0x6cccb4: mov             x17, #-0x1e0
    // 0x6cccb8: ldr             x11, [fp, x17]
    // 0x6cccbc: r17 = -488
    //     0x6cccbc: mov             x17, #-0x1e8
    // 0x6cccc0: ldr             x10, [fp, x17]
    // 0x6cccc4: r17 = -496
    //     0x6cccc4: mov             x17, #-0x1f0
    // 0x6cccc8: ldr             x9, [fp, x17]
    // 0x6ccccc: r17 = -504
    //     0x6ccccc: mov             x17, #-0x1f8
    // 0x6cccd0: ldr             x8, [fp, x17]
    // 0x6cccd4: ldur            x7, [fp, #-8]
    // 0x6cccd8: r17 = -512
    //     0x6cccd8: mov             x17, #-0x200
    // 0x6cccdc: ldr             x6, [fp, x17]
    // 0x6ccce0: r17 = -520
    //     0x6ccce0: mov             x17, #-0x208
    // 0x6ccce4: ldr             x5, [fp, x17]
    // 0x6ccce8: r17 = -528
    //     0x6ccce8: mov             x17, #-0x210
    // 0x6cccec: ldr             x4, [fp, x17]
    // 0x6cccf0: ldur            x3, [fp, #-0x20]
    // 0x6cccf4: r17 = -536
    //     0x6cccf4: mov             x17, #-0x218
    // 0x6cccf8: ldr             x2, [fp, x17]
    // 0x6cccfc: mov             x0, x1
    // 0x6ccd00: r17 = -544
    //     0x6ccd00: mov             x17, #-0x220
    // 0x6ccd04: ldr             x1, [fp, x17]
    // 0x6ccd08: r0 = ThemeData()
    //     0x6ccd08: bl              #0x6cd128  ; AllocateThemeDataStub -> ThemeData (size=0x170)
    // 0x6ccd0c: ldur            x1, [fp, #-0x28]
    // 0x6ccd10: StoreField: r0->field_7 = r1
    //     0x6ccd10: stur            w1, [x0, #7]
    // 0x6ccd14: ldur            x1, [fp, #-0x30]
    // 0x6ccd18: StoreField: r0->field_f = r1
    //     0x6ccd18: stur            w1, [x0, #0xf]
    // 0x6ccd1c: r1 = Instance_InputDecorationTheme
    //     0x6ccd1c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd008] Obj!InputDecorationTheme@b48581
    //     0x6ccd20: ldr             x1, [x1, #8]
    // 0x6ccd24: StoreField: r0->field_13 = r1
    //     0x6ccd24: stur            w1, [x0, #0x13]
    // 0x6ccd28: ldur            x1, [fp, #-0x70]
    // 0x6ccd2c: StoreField: r0->field_17 = r1
    //     0x6ccd2c: stur            w1, [x0, #0x17]
    // 0x6ccd30: r1 = Instance_PageTransitionsTheme
    //     0x6ccd30: add             x1, PP, #0xd, lsl #12  ; [pp+0xd010] Obj!PageTransitionsTheme@b3ceb1
    //     0x6ccd34: ldr             x1, [x1, #0x10]
    // 0x6ccd38: StoreField: r0->field_1b = r1
    //     0x6ccd38: stur            w1, [x0, #0x1b]
    // 0x6ccd3c: ldur            x1, [fp, #-0x68]
    // 0x6ccd40: StoreField: r0->field_1f = r1
    //     0x6ccd40: stur            w1, [x0, #0x1f]
    // 0x6ccd44: ldur            x1, [fp, #-0x60]
    // 0x6ccd48: StoreField: r0->field_23 = r1
    //     0x6ccd48: stur            w1, [x0, #0x23]
    // 0x6ccd4c: ldur            x1, [fp, #-0x38]
    // 0x6ccd50: StoreField: r0->field_27 = r1
    //     0x6ccd50: stur            w1, [x0, #0x27]
    // 0x6ccd54: ldur            x1, [fp, #-0x40]
    // 0x6ccd58: StoreField: r0->field_2b = r1
    //     0x6ccd58: stur            w1, [x0, #0x2b]
    // 0x6ccd5c: ldur            x1, [fp, #-0x48]
    // 0x6ccd60: StoreField: r0->field_2f = r1
    //     0x6ccd60: stur            w1, [x0, #0x2f]
    // 0x6ccd64: ldur            x1, [fp, #-0x58]
    // 0x6ccd68: StoreField: r0->field_37 = r1
    //     0x6ccd68: stur            w1, [x0, #0x37]
    // 0x6ccd6c: ldur            x1, [fp, #-0x50]
    // 0x6ccd70: StoreField: r0->field_3b = r1
    //     0x6ccd70: stur            w1, [x0, #0x3b]
    // 0x6ccd74: ldur            x1, [fp, #-0xd0]
    // 0x6ccd78: StoreField: r0->field_3f = r1
    //     0x6ccd78: stur            w1, [x0, #0x3f]
    // 0x6ccd7c: ldur            x1, [fp, #-0xd8]
    // 0x6ccd80: StoreField: r0->field_43 = r1
    //     0x6ccd80: stur            w1, [x0, #0x43]
    // 0x6ccd84: ldur            x1, [fp, #-0xe0]
    // 0x6ccd88: StoreField: r0->field_47 = r1
    //     0x6ccd88: stur            w1, [x0, #0x47]
    // 0x6ccd8c: ldur            x1, [fp, #-0xe8]
    // 0x6ccd90: StoreField: r0->field_4b = r1
    //     0x6ccd90: stur            w1, [x0, #0x4b]
    // 0x6ccd94: ldur            x1, [fp, #-0xf0]
    // 0x6ccd98: StoreField: r0->field_4f = r1
    //     0x6ccd98: stur            w1, [x0, #0x4f]
    // 0x6ccd9c: ldur            x1, [fp, #-0xa8]
    // 0x6ccda0: StoreField: r0->field_53 = r1
    //     0x6ccda0: stur            w1, [x0, #0x53]
    // 0x6ccda4: ldur            x1, [fp, #-0xf8]
    // 0x6ccda8: StoreField: r0->field_57 = r1
    //     0x6ccda8: stur            w1, [x0, #0x57]
    // 0x6ccdac: ldur            x1, [fp, #-0x100]
    // 0x6ccdb0: StoreField: r0->field_5b = r1
    //     0x6ccdb0: stur            w1, [x0, #0x5b]
    // 0x6ccdb4: ldur            x1, [fp, #-0xa0]
    // 0x6ccdb8: StoreField: r0->field_5f = r1
    //     0x6ccdb8: stur            w1, [x0, #0x5f]
    // 0x6ccdbc: ldur            x1, [fp, #-0x98]
    // 0x6ccdc0: StoreField: r0->field_63 = r1
    //     0x6ccdc0: stur            w1, [x0, #0x63]
    // 0x6ccdc4: ldur            x1, [fp, #-0x90]
    // 0x6ccdc8: StoreField: r0->field_67 = r1
    //     0x6ccdc8: stur            w1, [x0, #0x67]
    // 0x6ccdcc: r17 = -264
    //     0x6ccdcc: mov             x17, #-0x108
    // 0x6ccdd0: ldr             x1, [fp, x17]
    // 0x6ccdd4: StoreField: r0->field_6b = r1
    //     0x6ccdd4: stur            w1, [x0, #0x6b]
    // 0x6ccdd8: r17 = -272
    //     0x6ccdd8: mov             x17, #-0x110
    // 0x6ccddc: ldr             x1, [fp, x17]
    // 0x6ccde0: StoreField: r0->field_6f = r1
    //     0x6ccde0: stur            w1, [x0, #0x6f]
    // 0x6ccde4: r17 = -280
    //     0x6ccde4: mov             x17, #-0x118
    // 0x6ccde8: ldr             x1, [fp, x17]
    // 0x6ccdec: StoreField: r0->field_73 = r1
    //     0x6ccdec: stur            w1, [x0, #0x73]
    // 0x6ccdf0: r17 = -288
    //     0x6ccdf0: mov             x17, #-0x120
    // 0x6ccdf4: ldr             x1, [fp, x17]
    // 0x6ccdf8: StoreField: r0->field_7b = r1
    //     0x6ccdf8: stur            w1, [x0, #0x7b]
    // 0x6ccdfc: r17 = -296
    //     0x6ccdfc: mov             x17, #-0x128
    // 0x6cce00: ldr             x1, [fp, x17]
    // 0x6cce04: StoreField: r0->field_7f = r1
    //     0x6cce04: stur            w1, [x0, #0x7f]
    // 0x6cce08: r17 = -304
    //     0x6cce08: mov             x17, #-0x130
    // 0x6cce0c: ldr             x1, [fp, x17]
    // 0x6cce10: StoreField: r0->field_83 = r1
    //     0x6cce10: stur            w1, [x0, #0x83]
    // 0x6cce14: r17 = -312
    //     0x6cce14: mov             x17, #-0x138
    // 0x6cce18: ldr             x1, [fp, x17]
    // 0x6cce1c: StoreField: r0->field_87 = r1
    //     0x6cce1c: stur            w1, [x0, #0x87]
    // 0x6cce20: r17 = -320
    //     0x6cce20: mov             x17, #-0x140
    // 0x6cce24: ldr             x1, [fp, x17]
    // 0x6cce28: StoreField: r0->field_8b = r1
    //     0x6cce28: stur            w1, [x0, #0x8b]
    // 0x6cce2c: ldur            x1, [fp, #-0x10]
    // 0x6cce30: StoreField: r0->field_8f = r1
    //     0x6cce30: stur            w1, [x0, #0x8f]
    // 0x6cce34: ldur            x1, [fp, #-0x78]
    // 0x6cce38: StoreField: r0->field_93 = r1
    //     0x6cce38: stur            w1, [x0, #0x93]
    // 0x6cce3c: r17 = -680
    //     0x6cce3c: mov             x17, #-0x2a8
    // 0x6cce40: ldr             x1, [fp, x17]
    // 0x6cce44: StoreField: r0->field_97 = r1
    //     0x6cce44: stur            w1, [x0, #0x97]
    // 0x6cce48: ldur            x1, [fp, #-0x80]
    // 0x6cce4c: StoreField: r0->field_9b = r1
    //     0x6cce4c: stur            w1, [x0, #0x9b]
    // 0x6cce50: r17 = -672
    //     0x6cce50: mov             x17, #-0x2a0
    // 0x6cce54: ldr             x1, [fp, x17]
    // 0x6cce58: StoreField: r0->field_9f = r1
    //     0x6cce58: stur            w1, [x0, #0x9f]
    // 0x6cce5c: r17 = -664
    //     0x6cce5c: mov             x17, #-0x298
    // 0x6cce60: ldr             x1, [fp, x17]
    // 0x6cce64: StoreField: r0->field_a3 = r1
    //     0x6cce64: stur            w1, [x0, #0xa3]
    // 0x6cce68: r17 = -656
    //     0x6cce68: mov             x17, #-0x290
    // 0x6cce6c: ldr             x1, [fp, x17]
    // 0x6cce70: StoreField: r0->field_a7 = r1
    //     0x6cce70: stur            w1, [x0, #0xa7]
    // 0x6cce74: r17 = -648
    //     0x6cce74: mov             x17, #-0x288
    // 0x6cce78: ldr             x1, [fp, x17]
    // 0x6cce7c: StoreField: r0->field_ab = r1
    //     0x6cce7c: stur            w1, [x0, #0xab]
    // 0x6cce80: r17 = -640
    //     0x6cce80: mov             x17, #-0x280
    // 0x6cce84: ldr             x1, [fp, x17]
    // 0x6cce88: StoreField: r0->field_af = r1
    //     0x6cce88: stur            w1, [x0, #0xaf]
    // 0x6cce8c: r17 = -632
    //     0x6cce8c: mov             x17, #-0x278
    // 0x6cce90: ldr             x1, [fp, x17]
    // 0x6cce94: StoreField: r0->field_b3 = r1
    //     0x6cce94: stur            w1, [x0, #0xb3]
    // 0x6cce98: ldur            x1, [fp, #-0x88]
    // 0x6cce9c: StoreField: r0->field_b7 = r1
    //     0x6cce9c: stur            w1, [x0, #0xb7]
    // 0x6ccea0: r17 = -624
    //     0x6ccea0: mov             x17, #-0x270
    // 0x6ccea4: ldr             x1, [fp, x17]
    // 0x6ccea8: StoreField: r0->field_bb = r1
    //     0x6ccea8: stur            w1, [x0, #0xbb]
    // 0x6cceac: r17 = -616
    //     0x6cceac: mov             x17, #-0x268
    // 0x6cceb0: ldr             x1, [fp, x17]
    // 0x6cceb4: StoreField: r0->field_bf = r1
    //     0x6cceb4: stur            w1, [x0, #0xbf]
    // 0x6cceb8: r17 = -608
    //     0x6cceb8: mov             x17, #-0x260
    // 0x6ccebc: ldr             x1, [fp, x17]
    // 0x6ccec0: StoreField: r0->field_c3 = r1
    //     0x6ccec0: stur            w1, [x0, #0xc3]
    // 0x6ccec4: r17 = -600
    //     0x6ccec4: mov             x17, #-0x258
    // 0x6ccec8: ldr             x1, [fp, x17]
    // 0x6ccecc: StoreField: r0->field_c7 = r1
    //     0x6ccecc: stur            w1, [x0, #0xc7]
    // 0x6cced0: r17 = -592
    //     0x6cced0: mov             x17, #-0x250
    // 0x6cced4: ldr             x1, [fp, x17]
    // 0x6cced8: StoreField: r0->field_cb = r1
    //     0x6cced8: stur            w1, [x0, #0xcb]
    // 0x6ccedc: r17 = -584
    //     0x6ccedc: mov             x17, #-0x248
    // 0x6ccee0: ldr             x1, [fp, x17]
    // 0x6ccee4: StoreField: r0->field_cf = r1
    //     0x6ccee4: stur            w1, [x0, #0xcf]
    // 0x6ccee8: r17 = -576
    //     0x6ccee8: mov             x17, #-0x240
    // 0x6cceec: ldr             x1, [fp, x17]
    // 0x6ccef0: StoreField: r0->field_d3 = r1
    //     0x6ccef0: stur            w1, [x0, #0xd3]
    // 0x6ccef4: r17 = -568
    //     0x6ccef4: mov             x17, #-0x238
    // 0x6ccef8: ldr             x1, [fp, x17]
    // 0x6ccefc: StoreField: r0->field_d7 = r1
    //     0x6ccefc: stur            w1, [x0, #0xd7]
    // 0x6ccf00: r17 = -560
    //     0x6ccf00: mov             x17, #-0x230
    // 0x6ccf04: ldr             x1, [fp, x17]
    // 0x6ccf08: StoreField: r0->field_db = r1
    //     0x6ccf08: stur            w1, [x0, #0xdb]
    // 0x6ccf0c: r17 = -552
    //     0x6ccf0c: mov             x17, #-0x228
    // 0x6ccf10: ldr             x1, [fp, x17]
    // 0x6ccf14: StoreField: r0->field_df = r1
    //     0x6ccf14: stur            w1, [x0, #0xdf]
    // 0x6ccf18: ldur            x1, [fp, #-0xb0]
    // 0x6ccf1c: StoreField: r0->field_e3 = r1
    //     0x6ccf1c: stur            w1, [x0, #0xe3]
    // 0x6ccf20: ldur            x1, [fp, #-0xc0]
    // 0x6ccf24: StoreField: r0->field_e7 = r1
    //     0x6ccf24: stur            w1, [x0, #0xe7]
    // 0x6ccf28: r17 = -328
    //     0x6ccf28: mov             x17, #-0x148
    // 0x6ccf2c: ldr             x1, [fp, x17]
    // 0x6ccf30: StoreField: r0->field_eb = r1
    //     0x6ccf30: stur            w1, [x0, #0xeb]
    // 0x6ccf34: r17 = -336
    //     0x6ccf34: mov             x17, #-0x150
    // 0x6ccf38: ldr             x1, [fp, x17]
    // 0x6ccf3c: StoreField: r0->field_ef = r1
    //     0x6ccf3c: stur            w1, [x0, #0xef]
    // 0x6ccf40: r17 = -344
    //     0x6ccf40: mov             x17, #-0x158
    // 0x6ccf44: ldr             x1, [fp, x17]
    // 0x6ccf48: StoreField: r0->field_f3 = r1
    //     0x6ccf48: stur            w1, [x0, #0xf3]
    // 0x6ccf4c: r17 = -352
    //     0x6ccf4c: mov             x17, #-0x160
    // 0x6ccf50: ldr             x1, [fp, x17]
    // 0x6ccf54: StoreField: r0->field_f7 = r1
    //     0x6ccf54: stur            w1, [x0, #0xf7]
    // 0x6ccf58: r17 = -360
    //     0x6ccf58: mov             x17, #-0x168
    // 0x6ccf5c: ldr             x1, [fp, x17]
    // 0x6ccf60: StoreField: r0->field_fb = r1
    //     0x6ccf60: stur            w1, [x0, #0xfb]
    // 0x6ccf64: r17 = -368
    //     0x6ccf64: mov             x17, #-0x170
    // 0x6ccf68: ldr             x1, [fp, x17]
    // 0x6ccf6c: StoreField: r0->field_ff = r1
    //     0x6ccf6c: stur            w1, [x0, #0xff]
    // 0x6ccf70: r17 = -376
    //     0x6ccf70: mov             x17, #-0x178
    // 0x6ccf74: ldr             x1, [fp, x17]
    // 0x6ccf78: add             x16, x0, #0x103
    // 0x6ccf7c: str             w1, [x16]
    // 0x6ccf80: r17 = -384
    //     0x6ccf80: mov             x17, #-0x180
    // 0x6ccf84: ldr             x1, [fp, x17]
    // 0x6ccf88: add             x16, x0, #0x107
    // 0x6ccf8c: str             w1, [x16]
    // 0x6ccf90: r17 = -392
    //     0x6ccf90: mov             x17, #-0x188
    // 0x6ccf94: ldr             x1, [fp, x17]
    // 0x6ccf98: add             x16, x0, #0x10b
    // 0x6ccf9c: str             w1, [x16]
    // 0x6ccfa0: r17 = -400
    //     0x6ccfa0: mov             x17, #-0x190
    // 0x6ccfa4: ldr             x1, [fp, x17]
    // 0x6ccfa8: add             x16, x0, #0x10f
    // 0x6ccfac: str             w1, [x16]
    // 0x6ccfb0: r17 = -408
    //     0x6ccfb0: mov             x17, #-0x198
    // 0x6ccfb4: ldr             x1, [fp, x17]
    // 0x6ccfb8: add             x16, x0, #0x113
    // 0x6ccfbc: str             w1, [x16]
    // 0x6ccfc0: r17 = -416
    //     0x6ccfc0: mov             x17, #-0x1a0
    // 0x6ccfc4: ldr             x1, [fp, x17]
    // 0x6ccfc8: add             x16, x0, #0x117
    // 0x6ccfcc: str             w1, [x16]
    // 0x6ccfd0: r17 = -424
    //     0x6ccfd0: mov             x17, #-0x1a8
    // 0x6ccfd4: ldr             x1, [fp, x17]
    // 0x6ccfd8: add             x16, x0, #0x11b
    // 0x6ccfdc: str             w1, [x16]
    // 0x6ccfe0: r17 = -432
    //     0x6ccfe0: mov             x17, #-0x1b0
    // 0x6ccfe4: ldr             x1, [fp, x17]
    // 0x6ccfe8: add             x16, x0, #0x11f
    // 0x6ccfec: str             w1, [x16]
    // 0x6ccff0: r17 = -440
    //     0x6ccff0: mov             x17, #-0x1b8
    // 0x6ccff4: ldr             x1, [fp, x17]
    // 0x6ccff8: add             x16, x0, #0x123
    // 0x6ccffc: str             w1, [x16]
    // 0x6cd000: r17 = -448
    //     0x6cd000: mov             x17, #-0x1c0
    // 0x6cd004: ldr             x1, [fp, x17]
    // 0x6cd008: add             x16, x0, #0x127
    // 0x6cd00c: str             w1, [x16]
    // 0x6cd010: r17 = -456
    //     0x6cd010: mov             x17, #-0x1c8
    // 0x6cd014: ldr             x1, [fp, x17]
    // 0x6cd018: add             x16, x0, #0x12b
    // 0x6cd01c: str             w1, [x16]
    // 0x6cd020: r17 = -464
    //     0x6cd020: mov             x17, #-0x1d0
    // 0x6cd024: ldr             x1, [fp, x17]
    // 0x6cd028: add             x16, x0, #0x12f
    // 0x6cd02c: str             w1, [x16]
    // 0x6cd030: ldur            x1, [fp, #-0x18]
    // 0x6cd034: add             x16, x0, #0x133
    // 0x6cd038: str             w1, [x16]
    // 0x6cd03c: r17 = -472
    //     0x6cd03c: mov             x17, #-0x1d8
    // 0x6cd040: ldr             x1, [fp, x17]
    // 0x6cd044: add             x16, x0, #0x137
    // 0x6cd048: str             w1, [x16]
    // 0x6cd04c: r17 = -480
    //     0x6cd04c: mov             x17, #-0x1e0
    // 0x6cd050: ldr             x1, [fp, x17]
    // 0x6cd054: add             x16, x0, #0x13b
    // 0x6cd058: str             w1, [x16]
    // 0x6cd05c: r17 = -488
    //     0x6cd05c: mov             x17, #-0x1e8
    // 0x6cd060: ldr             x1, [fp, x17]
    // 0x6cd064: add             x16, x0, #0x13f
    // 0x6cd068: str             w1, [x16]
    // 0x6cd06c: r17 = -496
    //     0x6cd06c: mov             x17, #-0x1f0
    // 0x6cd070: ldr             x1, [fp, x17]
    // 0x6cd074: add             x16, x0, #0x143
    // 0x6cd078: str             w1, [x16]
    // 0x6cd07c: r17 = -504
    //     0x6cd07c: mov             x17, #-0x1f8
    // 0x6cd080: ldr             x1, [fp, x17]
    // 0x6cd084: add             x16, x0, #0x147
    // 0x6cd088: str             w1, [x16]
    // 0x6cd08c: ldur            x1, [fp, #-8]
    // 0x6cd090: add             x16, x0, #0x14b
    // 0x6cd094: str             w1, [x16]
    // 0x6cd098: r17 = -512
    //     0x6cd098: mov             x17, #-0x200
    // 0x6cd09c: ldr             x1, [fp, x17]
    // 0x6cd0a0: add             x16, x0, #0x14f
    // 0x6cd0a4: str             w1, [x16]
    // 0x6cd0a8: r17 = -520
    //     0x6cd0a8: mov             x17, #-0x208
    // 0x6cd0ac: ldr             x1, [fp, x17]
    // 0x6cd0b0: add             x16, x0, #0x153
    // 0x6cd0b4: str             w1, [x16]
    // 0x6cd0b8: r1 = true
    //     0x6cd0b8: add             x1, NULL, #0x20  ; true
    // 0x6cd0bc: add             x16, x0, #0x157
    // 0x6cd0c0: str             w1, [x16]
    // 0x6cd0c4: r17 = -528
    //     0x6cd0c4: mov             x17, #-0x210
    // 0x6cd0c8: ldr             x1, [fp, x17]
    // 0x6cd0cc: add             x16, x0, #0x15b
    // 0x6cd0d0: str             w1, [x16]
    // 0x6cd0d4: ldur            x1, [fp, #-0x20]
    // 0x6cd0d8: add             x16, x0, #0x16b
    // 0x6cd0dc: str             w1, [x16]
    // 0x6cd0e0: r17 = -536
    //     0x6cd0e0: mov             x17, #-0x218
    // 0x6cd0e4: ldr             x1, [fp, x17]
    // 0x6cd0e8: StoreField: r0->field_77 = r1
    //     0x6cd0e8: stur            w1, [x0, #0x77]
    // 0x6cd0ec: r17 = -544
    //     0x6cd0ec: mov             x17, #-0x220
    // 0x6cd0f0: ldr             x1, [fp, x17]
    // 0x6cd0f4: add             x16, x0, #0x163
    // 0x6cd0f8: str             w1, [x16]
    // 0x6cd0fc: r17 = -688
    //     0x6cd0fc: mov             x17, #-0x2b0
    // 0x6cd100: ldr             x1, [fp, x17]
    // 0x6cd104: add             x16, x0, #0x167
    // 0x6cd108: str             w1, [x16]
    // 0x6cd10c: ldur            x1, [fp, #-0xb8]
    // 0x6cd110: StoreField: r0->field_33 = r1
    //     0x6cd110: stur            w1, [x0, #0x33]
    // 0x6cd114: LeaveFrame
    //     0x6cd114: mov             SP, fp
    //     0x6cd118: ldp             fp, lr, [SP], #0x10
    // 0x6cd11c: ret
    //     0x6cd11c: ret             
    // 0x6cd120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cd120: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cd124: b               #0x6cc5d8
  }
  static _FifoCache<_IdentityThemeDataCacheKey, ThemeData> _localizedThemeDataCache() {
    // ** addr: 0x6cecf8, size: 0x64
    // 0x6cecf8: EnterFrame
    //     0x6cecf8: stp             fp, lr, [SP, #-0x10]!
    //     0x6cecfc: mov             fp, SP
    // 0x6ced00: AllocStack(0x8)
    //     0x6ced00: sub             SP, SP, #8
    // 0x6ced04: CheckStackOverflow
    //     0x6ced04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ced08: cmp             SP, x16
    //     0x6ced0c: b.ls            #0x6ced54
    // 0x6ced10: r16 = <_IdentityThemeDataCacheKey, ThemeData>
    //     0x6ced10: add             x16, PP, #0xe, lsl #12  ; [pp+0xe078] TypeArguments: <_IdentityThemeDataCacheKey, ThemeData>
    //     0x6ced14: ldr             x16, [x16, #0x78]
    // 0x6ced18: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6ced1c: stp             lr, x16, [SP, #-0x10]!
    // 0x6ced20: r0 = Map._fromLiteral()
    //     0x6ced20: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6ced24: add             SP, SP, #0x10
    // 0x6ced28: r1 = <_IdentityThemeDataCacheKey, ThemeData>
    //     0x6ced28: add             x1, PP, #0xe, lsl #12  ; [pp+0xe078] TypeArguments: <_IdentityThemeDataCacheKey, ThemeData>
    //     0x6ced2c: ldr             x1, [x1, #0x78]
    // 0x6ced30: stur            x0, [fp, #-8]
    // 0x6ced34: r0 = _FifoCache()
    //     0x6ced34: bl              #0x6ced5c  ; Allocate_FifoCacheStub -> _FifoCache<X0, X1> (size=0x18)
    // 0x6ced38: ldur            x1, [fp, #-8]
    // 0x6ced3c: StoreField: r0->field_b = r1
    //     0x6ced3c: stur            w1, [x0, #0xb]
    // 0x6ced40: r1 = 5
    //     0x6ced40: mov             x1, #5
    // 0x6ced44: StoreField: r0->field_f = r1
    //     0x6ced44: stur            x1, [x0, #0xf]
    // 0x6ced48: LeaveFrame
    //     0x6ced48: mov             SP, fp
    //     0x6ced4c: ldp             fp, lr, [SP], #0x10
    // 0x6ced50: ret
    //     0x6ced50: ret             
    // 0x6ced54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ced54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ced58: b               #0x6ced10
  }
  factory ThemeData ThemeData.light(dynamic) {
    // ** addr: 0x6cef3c, size: 0x44
    // 0x6cef3c: EnterFrame
    //     0x6cef3c: stp             fp, lr, [SP, #-0x10]!
    //     0x6cef40: mov             fp, SP
    // 0x6cef44: CheckStackOverflow
    //     0x6cef44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cef48: cmp             SP, x16
    //     0x6cef4c: b.ls            #0x6cef78
    // 0x6cef50: stp             NULL, NULL, [SP, #-0x10]!
    // 0x6cef54: r16 = Instance_Brightness
    //     0x6cef54: ldr             x16, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0x6cef58: SaveReg r16
    //     0x6cef58: str             x16, [SP, #-8]!
    // 0x6cef5c: r4 = const [0, 0x3, 0x3, 0x2, brightness, 0x2, null]
    //     0x6cef5c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe108] List(7) [0, 0x3, 0x3, 0x2, "brightness", 0x2, Null]
    //     0x6cef60: ldr             x4, [x4, #0x108]
    // 0x6cef64: r0 = ThemeData()
    //     0x6cef64: bl              #0x6cef80  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x6cef68: add             SP, SP, #0x18
    // 0x6cef6c: LeaveFrame
    //     0x6cef6c: mov             SP, fp
    //     0x6cef70: ldp             fp, lr, [SP], #0x10
    // 0x6cef74: ret
    //     0x6cef74: ret             
    // 0x6cef78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cef78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cef7c: b               #0x6cef50
  }
  factory _ ThemeData(/* No info */) {
    // ** addr: 0x6cef80, size: 0x266c
    // 0x6cef80: EnterFrame
    //     0x6cef80: stp             fp, lr, [SP, #-0x10]!
    //     0x6cef84: mov             fp, SP
    // 0x6cef88: AllocStack(0x168)
    //     0x6cef88: sub             SP, SP, #0x168
    // 0x6cef8c: SetupParameters(dynamic _ /* r3, fp-0x38 */, {dynamic accentColor, dynamic accentColorBrightness, dynamic accentIconTheme, dynamic accentTextTheme, dynamic appBarTheme = Null /* r4, fp-0x30 */, dynamic applyElevationOverlayColor, dynamic backgroundColor, dynamic badgeTheme, dynamic bannerTheme, dynamic bottomAppBarColor, dynamic bottomAppBarTheme, dynamic bottomNavigationBarTheme, dynamic bottomSheetTheme, dynamic brightness = Null /* r5, fp-0x28 */, dynamic buttonBarTheme, dynamic buttonColor, dynamic buttonTheme, dynamic canvasColor, dynamic cardColor, dynamic cardTheme, dynamic checkboxTheme, dynamic chipTheme, dynamic colorScheme = Null /* r6, fp-0x20 */, dynamic cupertinoOverrideTheme, dynamic dataTableTheme, dynamic dialogBackgroundColor, dynamic dialogTheme, dynamic disabledColor, dynamic dividerColor, dynamic dividerTheme, dynamic drawerTheme, dynamic dropdownMenuTheme, dynamic elevatedButtonTheme, dynamic errorColor, dynamic expansionTileTheme, dynamic extensions, dynamic filledButtonTheme, dynamic fixTextFieldOutlineLabel, dynamic floatingActionButtonTheme, dynamic focusColor, dynamic highlightColor, dynamic hintColor, dynamic hoverColor, dynamic iconButtonTheme, dynamic iconTheme, dynamic indicatorColor, dynamic inputDecorationTheme, dynamic listTileTheme, dynamic materialTapTargetSize, dynamic menuBarTheme, dynamic menuButtonTheme, dynamic menuTheme, dynamic navigationBarTheme, dynamic navigationDrawerTheme, dynamic navigationRailTheme, dynamic outlinedButtonTheme, dynamic pageTransitionsTheme, dynamic platform, dynamic popupMenuTheme, dynamic primaryColor, dynamic primaryColorBrightness, dynamic primaryColorDark, dynamic primaryColorLight, dynamic primaryIconTheme, dynamic primarySwatch, dynamic primaryTextTheme, dynamic progressIndicatorTheme, dynamic radioTheme, dynamic scaffoldBackgroundColor = Null /* r7, fp-0x18 */, dynamic scrollbarTheme, dynamic secondaryHeaderColor, dynamic segmentedButtonTheme, dynamic selectedRowColor, dynamic shadowColor, dynamic sliderTheme, dynamic snackBarTheme, dynamic splashColor = Null /* r8, fp-0x10 */, dynamic splashFactory, dynamic switchTheme, dynamic tabBarTheme = Null /* r2, fp-0x8 */, dynamic textButtonTheme, dynamic textSelectionTheme, dynamic textTheme, dynamic timePickerTheme, dynamic toggleButtonsTheme, dynamic toggleableActiveColor, dynamic tooltipTheme, dynamic typography, dynamic unselectedWidgetColor})
    //     0x6cef8c: mov             x0, x4
    //     0x6cef90: ldur            w1, [x0, #0x13]
    //     0x6cef94: add             x1, x1, HEAP, lsl #32
    //     0x6cef98: sub             x2, x1, #4
    //     0x6cef9c: add             x3, fp, w2, sxtw #2
    //     0x6cefa0: ldr             x3, [x3, #0x10]
    //     0x6cefa4: stur            x3, [fp, #-0x38]
    //     0x6cefa8: ldur            w2, [x0, #0x1f]
    //     0x6cefac: add             x2, x2, HEAP, lsl #32
    //     0x6cefb0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc18] "accentColor"
    //     0x6cefb4: ldr             x16, [x16, #0xc18]
    //     0x6cefb8: cmp             w2, w16
    //     0x6cefbc: b.ne            #0x6cefc8
    //     0x6cefc0: mov             x2, #1
    //     0x6cefc4: b               #0x6cefcc
    //     0x6cefc8: mov             x2, #0
    //     0x6cefcc: lsl             x4, x2, #1
    //     0x6cefd0: lsl             w5, w4, #1
    //     0x6cefd4: add             w6, w5, #8
    //     0x6cefd8: add             x16, x0, w6, sxtw #1
    //     0x6cefdc: ldur            w5, [x16, #0xf]
    //     0x6cefe0: add             x5, x5, HEAP, lsl #32
    //     0x6cefe4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc20] "accentColorBrightness"
    //     0x6cefe8: ldr             x16, [x16, #0xc20]
    //     0x6cefec: cmp             w5, w16
    //     0x6ceff0: b.ne            #0x6cf000
    //     0x6ceff4: add             w2, w4, #2
    //     0x6ceff8: sbfx            x4, x2, #1, #0x1f
    //     0x6ceffc: mov             x2, x4
    //     0x6cf000: lsl             x4, x2, #1
    //     0x6cf004: lsl             w5, w4, #1
    //     0x6cf008: add             w6, w5, #8
    //     0x6cf00c: add             x16, x0, w6, sxtw #1
    //     0x6cf010: ldur            w5, [x16, #0xf]
    //     0x6cf014: add             x5, x5, HEAP, lsl #32
    //     0x6cf018: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc28] "accentIconTheme"
    //     0x6cf01c: ldr             x16, [x16, #0xc28]
    //     0x6cf020: cmp             w5, w16
    //     0x6cf024: b.ne            #0x6cf034
    //     0x6cf028: add             w2, w4, #2
    //     0x6cf02c: sbfx            x4, x2, #1, #0x1f
    //     0x6cf030: mov             x2, x4
    //     0x6cf034: lsl             x4, x2, #1
    //     0x6cf038: lsl             w5, w4, #1
    //     0x6cf03c: add             w6, w5, #8
    //     0x6cf040: add             x16, x0, w6, sxtw #1
    //     0x6cf044: ldur            w5, [x16, #0xf]
    //     0x6cf048: add             x5, x5, HEAP, lsl #32
    //     0x6cf04c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc30] "accentTextTheme"
    //     0x6cf050: ldr             x16, [x16, #0xc30]
    //     0x6cf054: cmp             w5, w16
    //     0x6cf058: b.ne            #0x6cf068
    //     0x6cf05c: add             w2, w4, #2
    //     0x6cf060: sbfx            x4, x2, #1, #0x1f
    //     0x6cf064: mov             x2, x4
    //     0x6cf068: lsl             x4, x2, #1
    //     0x6cf06c: lsl             w5, w4, #1
    //     0x6cf070: add             w6, w5, #8
    //     0x6cf074: add             x16, x0, w6, sxtw #1
    //     0x6cf078: ldur            w7, [x16, #0xf]
    //     0x6cf07c: add             x7, x7, HEAP, lsl #32
    //     0x6cf080: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc38] "appBarTheme"
    //     0x6cf084: ldr             x16, [x16, #0xc38]
    //     0x6cf088: cmp             w7, w16
    //     0x6cf08c: b.ne            #0x6cf0c0
    //     0x6cf090: add             w2, w5, #0xa
    //     0x6cf094: add             x16, x0, w2, sxtw #1
    //     0x6cf098: ldur            w5, [x16, #0xf]
    //     0x6cf09c: add             x5, x5, HEAP, lsl #32
    //     0x6cf0a0: sub             w2, w1, w5
    //     0x6cf0a4: add             x5, fp, w2, sxtw #2
    //     0x6cf0a8: ldr             x5, [x5, #8]
    //     0x6cf0ac: add             w2, w4, #2
    //     0x6cf0b0: sbfx            x4, x2, #1, #0x1f
    //     0x6cf0b4: mov             x2, x4
    //     0x6cf0b8: mov             x4, x5
    //     0x6cf0bc: b               #0x6cf0c4
    //     0x6cf0c0: mov             x4, NULL
    //     0x6cf0c4: stur            x4, [fp, #-0x30]
    //     0x6cf0c8: lsl             x5, x2, #1
    //     0x6cf0cc: lsl             w6, w5, #1
    //     0x6cf0d0: add             w7, w6, #8
    //     0x6cf0d4: add             x16, x0, w7, sxtw #1
    //     0x6cf0d8: ldur            w6, [x16, #0xf]
    //     0x6cf0dc: add             x6, x6, HEAP, lsl #32
    //     0x6cf0e0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc40] "applyElevationOverlayColor"
    //     0x6cf0e4: ldr             x16, [x16, #0xc40]
    //     0x6cf0e8: cmp             w6, w16
    //     0x6cf0ec: b.ne            #0x6cf0fc
    //     0x6cf0f0: add             w2, w5, #2
    //     0x6cf0f4: sbfx            x5, x2, #1, #0x1f
    //     0x6cf0f8: mov             x2, x5
    //     0x6cf0fc: lsl             x5, x2, #1
    //     0x6cf100: lsl             w6, w5, #1
    //     0x6cf104: add             w7, w6, #8
    //     0x6cf108: add             x16, x0, w7, sxtw #1
    //     0x6cf10c: ldur            w6, [x16, #0xf]
    //     0x6cf110: add             x6, x6, HEAP, lsl #32
    //     0x6cf114: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc48] "backgroundColor"
    //     0x6cf118: ldr             x16, [x16, #0xc48]
    //     0x6cf11c: cmp             w6, w16
    //     0x6cf120: b.ne            #0x6cf130
    //     0x6cf124: add             w2, w5, #2
    //     0x6cf128: sbfx            x5, x2, #1, #0x1f
    //     0x6cf12c: mov             x2, x5
    //     0x6cf130: lsl             x5, x2, #1
    //     0x6cf134: lsl             w6, w5, #1
    //     0x6cf138: add             w7, w6, #8
    //     0x6cf13c: add             x16, x0, w7, sxtw #1
    //     0x6cf140: ldur            w6, [x16, #0xf]
    //     0x6cf144: add             x6, x6, HEAP, lsl #32
    //     0x6cf148: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc50] "badgeTheme"
    //     0x6cf14c: ldr             x16, [x16, #0xc50]
    //     0x6cf150: cmp             w6, w16
    //     0x6cf154: b.ne            #0x6cf164
    //     0x6cf158: add             w2, w5, #2
    //     0x6cf15c: sbfx            x5, x2, #1, #0x1f
    //     0x6cf160: mov             x2, x5
    //     0x6cf164: lsl             x5, x2, #1
    //     0x6cf168: lsl             w6, w5, #1
    //     0x6cf16c: add             w7, w6, #8
    //     0x6cf170: add             x16, x0, w7, sxtw #1
    //     0x6cf174: ldur            w6, [x16, #0xf]
    //     0x6cf178: add             x6, x6, HEAP, lsl #32
    //     0x6cf17c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc58] "bannerTheme"
    //     0x6cf180: ldr             x16, [x16, #0xc58]
    //     0x6cf184: cmp             w6, w16
    //     0x6cf188: b.ne            #0x6cf198
    //     0x6cf18c: add             w2, w5, #2
    //     0x6cf190: sbfx            x5, x2, #1, #0x1f
    //     0x6cf194: mov             x2, x5
    //     0x6cf198: lsl             x5, x2, #1
    //     0x6cf19c: lsl             w6, w5, #1
    //     0x6cf1a0: add             w7, w6, #8
    //     0x6cf1a4: add             x16, x0, w7, sxtw #1
    //     0x6cf1a8: ldur            w6, [x16, #0xf]
    //     0x6cf1ac: add             x6, x6, HEAP, lsl #32
    //     0x6cf1b0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc60] "bottomAppBarColor"
    //     0x6cf1b4: ldr             x16, [x16, #0xc60]
    //     0x6cf1b8: cmp             w6, w16
    //     0x6cf1bc: b.ne            #0x6cf1cc
    //     0x6cf1c0: add             w2, w5, #2
    //     0x6cf1c4: sbfx            x5, x2, #1, #0x1f
    //     0x6cf1c8: mov             x2, x5
    //     0x6cf1cc: lsl             x5, x2, #1
    //     0x6cf1d0: lsl             w6, w5, #1
    //     0x6cf1d4: add             w7, w6, #8
    //     0x6cf1d8: add             x16, x0, w7, sxtw #1
    //     0x6cf1dc: ldur            w6, [x16, #0xf]
    //     0x6cf1e0: add             x6, x6, HEAP, lsl #32
    //     0x6cf1e4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc68] "bottomAppBarTheme"
    //     0x6cf1e8: ldr             x16, [x16, #0xc68]
    //     0x6cf1ec: cmp             w6, w16
    //     0x6cf1f0: b.ne            #0x6cf200
    //     0x6cf1f4: add             w2, w5, #2
    //     0x6cf1f8: sbfx            x5, x2, #1, #0x1f
    //     0x6cf1fc: mov             x2, x5
    //     0x6cf200: lsl             x5, x2, #1
    //     0x6cf204: lsl             w6, w5, #1
    //     0x6cf208: add             w7, w6, #8
    //     0x6cf20c: add             x16, x0, w7, sxtw #1
    //     0x6cf210: ldur            w6, [x16, #0xf]
    //     0x6cf214: add             x6, x6, HEAP, lsl #32
    //     0x6cf218: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc70] "bottomNavigationBarTheme"
    //     0x6cf21c: ldr             x16, [x16, #0xc70]
    //     0x6cf220: cmp             w6, w16
    //     0x6cf224: b.ne            #0x6cf234
    //     0x6cf228: add             w2, w5, #2
    //     0x6cf22c: sbfx            x5, x2, #1, #0x1f
    //     0x6cf230: mov             x2, x5
    //     0x6cf234: lsl             x5, x2, #1
    //     0x6cf238: lsl             w6, w5, #1
    //     0x6cf23c: add             w7, w6, #8
    //     0x6cf240: add             x16, x0, w7, sxtw #1
    //     0x6cf244: ldur            w6, [x16, #0xf]
    //     0x6cf248: add             x6, x6, HEAP, lsl #32
    //     0x6cf24c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc78] "bottomSheetTheme"
    //     0x6cf250: ldr             x16, [x16, #0xc78]
    //     0x6cf254: cmp             w6, w16
    //     0x6cf258: b.ne            #0x6cf268
    //     0x6cf25c: add             w2, w5, #2
    //     0x6cf260: sbfx            x5, x2, #1, #0x1f
    //     0x6cf264: mov             x2, x5
    //     0x6cf268: lsl             x5, x2, #1
    //     0x6cf26c: lsl             w6, w5, #1
    //     0x6cf270: add             w7, w6, #8
    //     0x6cf274: add             x16, x0, w7, sxtw #1
    //     0x6cf278: ldur            w8, [x16, #0xf]
    //     0x6cf27c: add             x8, x8, HEAP, lsl #32
    //     0x6cf280: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc80] "brightness"
    //     0x6cf284: ldr             x16, [x16, #0xc80]
    //     0x6cf288: cmp             w8, w16
    //     0x6cf28c: b.ne            #0x6cf2c0
    //     0x6cf290: add             w2, w6, #0xa
    //     0x6cf294: add             x16, x0, w2, sxtw #1
    //     0x6cf298: ldur            w6, [x16, #0xf]
    //     0x6cf29c: add             x6, x6, HEAP, lsl #32
    //     0x6cf2a0: sub             w2, w1, w6
    //     0x6cf2a4: add             x6, fp, w2, sxtw #2
    //     0x6cf2a8: ldr             x6, [x6, #8]
    //     0x6cf2ac: add             w2, w5, #2
    //     0x6cf2b0: sbfx            x5, x2, #1, #0x1f
    //     0x6cf2b4: mov             x2, x5
    //     0x6cf2b8: mov             x5, x6
    //     0x6cf2bc: b               #0x6cf2c4
    //     0x6cf2c0: mov             x5, NULL
    //     0x6cf2c4: stur            x5, [fp, #-0x28]
    //     0x6cf2c8: lsl             x6, x2, #1
    //     0x6cf2cc: lsl             w7, w6, #1
    //     0x6cf2d0: add             w8, w7, #8
    //     0x6cf2d4: add             x16, x0, w8, sxtw #1
    //     0x6cf2d8: ldur            w7, [x16, #0xf]
    //     0x6cf2dc: add             x7, x7, HEAP, lsl #32
    //     0x6cf2e0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc88] "buttonBarTheme"
    //     0x6cf2e4: ldr             x16, [x16, #0xc88]
    //     0x6cf2e8: cmp             w7, w16
    //     0x6cf2ec: b.ne            #0x6cf2fc
    //     0x6cf2f0: add             w2, w6, #2
    //     0x6cf2f4: sbfx            x6, x2, #1, #0x1f
    //     0x6cf2f8: mov             x2, x6
    //     0x6cf2fc: lsl             x6, x2, #1
    //     0x6cf300: lsl             w7, w6, #1
    //     0x6cf304: add             w8, w7, #8
    //     0x6cf308: add             x16, x0, w8, sxtw #1
    //     0x6cf30c: ldur            w7, [x16, #0xf]
    //     0x6cf310: add             x7, x7, HEAP, lsl #32
    //     0x6cf314: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc90] "buttonColor"
    //     0x6cf318: ldr             x16, [x16, #0xc90]
    //     0x6cf31c: cmp             w7, w16
    //     0x6cf320: b.ne            #0x6cf330
    //     0x6cf324: add             w2, w6, #2
    //     0x6cf328: sbfx            x6, x2, #1, #0x1f
    //     0x6cf32c: mov             x2, x6
    //     0x6cf330: lsl             x6, x2, #1
    //     0x6cf334: lsl             w7, w6, #1
    //     0x6cf338: add             w8, w7, #8
    //     0x6cf33c: add             x16, x0, w8, sxtw #1
    //     0x6cf340: ldur            w7, [x16, #0xf]
    //     0x6cf344: add             x7, x7, HEAP, lsl #32
    //     0x6cf348: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc98] "buttonTheme"
    //     0x6cf34c: ldr             x16, [x16, #0xc98]
    //     0x6cf350: cmp             w7, w16
    //     0x6cf354: b.ne            #0x6cf364
    //     0x6cf358: add             w2, w6, #2
    //     0x6cf35c: sbfx            x6, x2, #1, #0x1f
    //     0x6cf360: mov             x2, x6
    //     0x6cf364: lsl             x6, x2, #1
    //     0x6cf368: lsl             w7, w6, #1
    //     0x6cf36c: add             w8, w7, #8
    //     0x6cf370: add             x16, x0, w8, sxtw #1
    //     0x6cf374: ldur            w7, [x16, #0xf]
    //     0x6cf378: add             x7, x7, HEAP, lsl #32
    //     0x6cf37c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcca0] "canvasColor"
    //     0x6cf380: ldr             x16, [x16, #0xca0]
    //     0x6cf384: cmp             w7, w16
    //     0x6cf388: b.ne            #0x6cf398
    //     0x6cf38c: add             w2, w6, #2
    //     0x6cf390: sbfx            x6, x2, #1, #0x1f
    //     0x6cf394: mov             x2, x6
    //     0x6cf398: lsl             x6, x2, #1
    //     0x6cf39c: lsl             w7, w6, #1
    //     0x6cf3a0: add             w8, w7, #8
    //     0x6cf3a4: add             x16, x0, w8, sxtw #1
    //     0x6cf3a8: ldur            w7, [x16, #0xf]
    //     0x6cf3ac: add             x7, x7, HEAP, lsl #32
    //     0x6cf3b0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcca8] "cardColor"
    //     0x6cf3b4: ldr             x16, [x16, #0xca8]
    //     0x6cf3b8: cmp             w7, w16
    //     0x6cf3bc: b.ne            #0x6cf3cc
    //     0x6cf3c0: add             w2, w6, #2
    //     0x6cf3c4: sbfx            x6, x2, #1, #0x1f
    //     0x6cf3c8: mov             x2, x6
    //     0x6cf3cc: lsl             x6, x2, #1
    //     0x6cf3d0: lsl             w7, w6, #1
    //     0x6cf3d4: add             w8, w7, #8
    //     0x6cf3d8: add             x16, x0, w8, sxtw #1
    //     0x6cf3dc: ldur            w7, [x16, #0xf]
    //     0x6cf3e0: add             x7, x7, HEAP, lsl #32
    //     0x6cf3e4: add             x16, PP, #0xc, lsl #12  ; [pp+0xccb0] "cardTheme"
    //     0x6cf3e8: ldr             x16, [x16, #0xcb0]
    //     0x6cf3ec: cmp             w7, w16
    //     0x6cf3f0: b.ne            #0x6cf400
    //     0x6cf3f4: add             w2, w6, #2
    //     0x6cf3f8: sbfx            x6, x2, #1, #0x1f
    //     0x6cf3fc: mov             x2, x6
    //     0x6cf400: lsl             x6, x2, #1
    //     0x6cf404: lsl             w7, w6, #1
    //     0x6cf408: add             w8, w7, #8
    //     0x6cf40c: add             x16, x0, w8, sxtw #1
    //     0x6cf410: ldur            w7, [x16, #0xf]
    //     0x6cf414: add             x7, x7, HEAP, lsl #32
    //     0x6cf418: add             x16, PP, #0xc, lsl #12  ; [pp+0xccb8] "checkboxTheme"
    //     0x6cf41c: ldr             x16, [x16, #0xcb8]
    //     0x6cf420: cmp             w7, w16
    //     0x6cf424: b.ne            #0x6cf434
    //     0x6cf428: add             w2, w6, #2
    //     0x6cf42c: sbfx            x6, x2, #1, #0x1f
    //     0x6cf430: mov             x2, x6
    //     0x6cf434: lsl             x6, x2, #1
    //     0x6cf438: lsl             w7, w6, #1
    //     0x6cf43c: add             w8, w7, #8
    //     0x6cf440: add             x16, x0, w8, sxtw #1
    //     0x6cf444: ldur            w7, [x16, #0xf]
    //     0x6cf448: add             x7, x7, HEAP, lsl #32
    //     0x6cf44c: add             x16, PP, #0xc, lsl #12  ; [pp+0xccc0] "chipTheme"
    //     0x6cf450: ldr             x16, [x16, #0xcc0]
    //     0x6cf454: cmp             w7, w16
    //     0x6cf458: b.ne            #0x6cf468
    //     0x6cf45c: add             w2, w6, #2
    //     0x6cf460: sbfx            x6, x2, #1, #0x1f
    //     0x6cf464: mov             x2, x6
    //     0x6cf468: lsl             x6, x2, #1
    //     0x6cf46c: lsl             w7, w6, #1
    //     0x6cf470: add             w8, w7, #8
    //     0x6cf474: add             x16, x0, w8, sxtw #1
    //     0x6cf478: ldur            w9, [x16, #0xf]
    //     0x6cf47c: add             x9, x9, HEAP, lsl #32
    //     0x6cf480: add             x16, PP, #0xc, lsl #12  ; [pp+0xccc8] "colorScheme"
    //     0x6cf484: ldr             x16, [x16, #0xcc8]
    //     0x6cf488: cmp             w9, w16
    //     0x6cf48c: b.ne            #0x6cf4c0
    //     0x6cf490: add             w2, w7, #0xa
    //     0x6cf494: add             x16, x0, w2, sxtw #1
    //     0x6cf498: ldur            w7, [x16, #0xf]
    //     0x6cf49c: add             x7, x7, HEAP, lsl #32
    //     0x6cf4a0: sub             w2, w1, w7
    //     0x6cf4a4: add             x7, fp, w2, sxtw #2
    //     0x6cf4a8: ldr             x7, [x7, #8]
    //     0x6cf4ac: add             w2, w6, #2
    //     0x6cf4b0: sbfx            x6, x2, #1, #0x1f
    //     0x6cf4b4: mov             x2, x6
    //     0x6cf4b8: mov             x6, x7
    //     0x6cf4bc: b               #0x6cf4c4
    //     0x6cf4c0: mov             x6, NULL
    //     0x6cf4c4: stur            x6, [fp, #-0x20]
    //     0x6cf4c8: lsl             x7, x2, #1
    //     0x6cf4cc: lsl             w8, w7, #1
    //     0x6cf4d0: add             w9, w8, #8
    //     0x6cf4d4: add             x16, x0, w9, sxtw #1
    //     0x6cf4d8: ldur            w8, [x16, #0xf]
    //     0x6cf4dc: add             x8, x8, HEAP, lsl #32
    //     0x6cf4e0: add             x16, PP, #0xc, lsl #12  ; [pp+0xccd0] "cupertinoOverrideTheme"
    //     0x6cf4e4: ldr             x16, [x16, #0xcd0]
    //     0x6cf4e8: cmp             w8, w16
    //     0x6cf4ec: b.ne            #0x6cf4fc
    //     0x6cf4f0: add             w2, w7, #2
    //     0x6cf4f4: sbfx            x7, x2, #1, #0x1f
    //     0x6cf4f8: mov             x2, x7
    //     0x6cf4fc: lsl             x7, x2, #1
    //     0x6cf500: lsl             w8, w7, #1
    //     0x6cf504: add             w9, w8, #8
    //     0x6cf508: add             x16, x0, w9, sxtw #1
    //     0x6cf50c: ldur            w8, [x16, #0xf]
    //     0x6cf510: add             x8, x8, HEAP, lsl #32
    //     0x6cf514: add             x16, PP, #0xc, lsl #12  ; [pp+0xccd8] "dataTableTheme"
    //     0x6cf518: ldr             x16, [x16, #0xcd8]
    //     0x6cf51c: cmp             w8, w16
    //     0x6cf520: b.ne            #0x6cf530
    //     0x6cf524: add             w2, w7, #2
    //     0x6cf528: sbfx            x7, x2, #1, #0x1f
    //     0x6cf52c: mov             x2, x7
    //     0x6cf530: lsl             x7, x2, #1
    //     0x6cf534: lsl             w8, w7, #1
    //     0x6cf538: add             w9, w8, #8
    //     0x6cf53c: add             x16, x0, w9, sxtw #1
    //     0x6cf540: ldur            w8, [x16, #0xf]
    //     0x6cf544: add             x8, x8, HEAP, lsl #32
    //     0x6cf548: add             x16, PP, #0xc, lsl #12  ; [pp+0xcce0] "dialogBackgroundColor"
    //     0x6cf54c: ldr             x16, [x16, #0xce0]
    //     0x6cf550: cmp             w8, w16
    //     0x6cf554: b.ne            #0x6cf564
    //     0x6cf558: add             w2, w7, #2
    //     0x6cf55c: sbfx            x7, x2, #1, #0x1f
    //     0x6cf560: mov             x2, x7
    //     0x6cf564: lsl             x7, x2, #1
    //     0x6cf568: lsl             w8, w7, #1
    //     0x6cf56c: add             w9, w8, #8
    //     0x6cf570: add             x16, x0, w9, sxtw #1
    //     0x6cf574: ldur            w8, [x16, #0xf]
    //     0x6cf578: add             x8, x8, HEAP, lsl #32
    //     0x6cf57c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcce8] "dialogTheme"
    //     0x6cf580: ldr             x16, [x16, #0xce8]
    //     0x6cf584: cmp             w8, w16
    //     0x6cf588: b.ne            #0x6cf598
    //     0x6cf58c: add             w2, w7, #2
    //     0x6cf590: sbfx            x7, x2, #1, #0x1f
    //     0x6cf594: mov             x2, x7
    //     0x6cf598: lsl             x7, x2, #1
    //     0x6cf59c: lsl             w8, w7, #1
    //     0x6cf5a0: add             w9, w8, #8
    //     0x6cf5a4: add             x16, x0, w9, sxtw #1
    //     0x6cf5a8: ldur            w8, [x16, #0xf]
    //     0x6cf5ac: add             x8, x8, HEAP, lsl #32
    //     0x6cf5b0: add             x16, PP, #0xc, lsl #12  ; [pp+0xccf0] "disabledColor"
    //     0x6cf5b4: ldr             x16, [x16, #0xcf0]
    //     0x6cf5b8: cmp             w8, w16
    //     0x6cf5bc: b.ne            #0x6cf5cc
    //     0x6cf5c0: add             w2, w7, #2
    //     0x6cf5c4: sbfx            x7, x2, #1, #0x1f
    //     0x6cf5c8: mov             x2, x7
    //     0x6cf5cc: lsl             x7, x2, #1
    //     0x6cf5d0: lsl             w8, w7, #1
    //     0x6cf5d4: add             w9, w8, #8
    //     0x6cf5d8: add             x16, x0, w9, sxtw #1
    //     0x6cf5dc: ldur            w8, [x16, #0xf]
    //     0x6cf5e0: add             x8, x8, HEAP, lsl #32
    //     0x6cf5e4: add             x16, PP, #0xc, lsl #12  ; [pp+0xccf8] "dividerColor"
    //     0x6cf5e8: ldr             x16, [x16, #0xcf8]
    //     0x6cf5ec: cmp             w8, w16
    //     0x6cf5f0: b.ne            #0x6cf600
    //     0x6cf5f4: add             w2, w7, #2
    //     0x6cf5f8: sbfx            x7, x2, #1, #0x1f
    //     0x6cf5fc: mov             x2, x7
    //     0x6cf600: lsl             x7, x2, #1
    //     0x6cf604: lsl             w8, w7, #1
    //     0x6cf608: add             w9, w8, #8
    //     0x6cf60c: add             x16, x0, w9, sxtw #1
    //     0x6cf610: ldur            w8, [x16, #0xf]
    //     0x6cf614: add             x8, x8, HEAP, lsl #32
    //     0x6cf618: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd00] "dividerTheme"
    //     0x6cf61c: ldr             x16, [x16, #0xd00]
    //     0x6cf620: cmp             w8, w16
    //     0x6cf624: b.ne            #0x6cf634
    //     0x6cf628: add             w2, w7, #2
    //     0x6cf62c: sbfx            x7, x2, #1, #0x1f
    //     0x6cf630: mov             x2, x7
    //     0x6cf634: lsl             x7, x2, #1
    //     0x6cf638: lsl             w8, w7, #1
    //     0x6cf63c: add             w9, w8, #8
    //     0x6cf640: add             x16, x0, w9, sxtw #1
    //     0x6cf644: ldur            w8, [x16, #0xf]
    //     0x6cf648: add             x8, x8, HEAP, lsl #32
    //     0x6cf64c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd08] "drawerTheme"
    //     0x6cf650: ldr             x16, [x16, #0xd08]
    //     0x6cf654: cmp             w8, w16
    //     0x6cf658: b.ne            #0x6cf668
    //     0x6cf65c: add             w2, w7, #2
    //     0x6cf660: sbfx            x7, x2, #1, #0x1f
    //     0x6cf664: mov             x2, x7
    //     0x6cf668: lsl             x7, x2, #1
    //     0x6cf66c: lsl             w8, w7, #1
    //     0x6cf670: add             w9, w8, #8
    //     0x6cf674: add             x16, x0, w9, sxtw #1
    //     0x6cf678: ldur            w8, [x16, #0xf]
    //     0x6cf67c: add             x8, x8, HEAP, lsl #32
    //     0x6cf680: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd10] "dropdownMenuTheme"
    //     0x6cf684: ldr             x16, [x16, #0xd10]
    //     0x6cf688: cmp             w8, w16
    //     0x6cf68c: b.ne            #0x6cf69c
    //     0x6cf690: add             w2, w7, #2
    //     0x6cf694: sbfx            x7, x2, #1, #0x1f
    //     0x6cf698: mov             x2, x7
    //     0x6cf69c: lsl             x7, x2, #1
    //     0x6cf6a0: lsl             w8, w7, #1
    //     0x6cf6a4: add             w9, w8, #8
    //     0x6cf6a8: add             x16, x0, w9, sxtw #1
    //     0x6cf6ac: ldur            w8, [x16, #0xf]
    //     0x6cf6b0: add             x8, x8, HEAP, lsl #32
    //     0x6cf6b4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd18] "elevatedButtonTheme"
    //     0x6cf6b8: ldr             x16, [x16, #0xd18]
    //     0x6cf6bc: cmp             w8, w16
    //     0x6cf6c0: b.ne            #0x6cf6d0
    //     0x6cf6c4: add             w2, w7, #2
    //     0x6cf6c8: sbfx            x7, x2, #1, #0x1f
    //     0x6cf6cc: mov             x2, x7
    //     0x6cf6d0: lsl             x7, x2, #1
    //     0x6cf6d4: lsl             w8, w7, #1
    //     0x6cf6d8: add             w9, w8, #8
    //     0x6cf6dc: add             x16, x0, w9, sxtw #1
    //     0x6cf6e0: ldur            w8, [x16, #0xf]
    //     0x6cf6e4: add             x8, x8, HEAP, lsl #32
    //     0x6cf6e8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd20] "errorColor"
    //     0x6cf6ec: ldr             x16, [x16, #0xd20]
    //     0x6cf6f0: cmp             w8, w16
    //     0x6cf6f4: b.ne            #0x6cf704
    //     0x6cf6f8: add             w2, w7, #2
    //     0x6cf6fc: sbfx            x7, x2, #1, #0x1f
    //     0x6cf700: mov             x2, x7
    //     0x6cf704: lsl             x7, x2, #1
    //     0x6cf708: lsl             w8, w7, #1
    //     0x6cf70c: add             w9, w8, #8
    //     0x6cf710: add             x16, x0, w9, sxtw #1
    //     0x6cf714: ldur            w8, [x16, #0xf]
    //     0x6cf718: add             x8, x8, HEAP, lsl #32
    //     0x6cf71c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd28] "expansionTileTheme"
    //     0x6cf720: ldr             x16, [x16, #0xd28]
    //     0x6cf724: cmp             w8, w16
    //     0x6cf728: b.ne            #0x6cf738
    //     0x6cf72c: add             w2, w7, #2
    //     0x6cf730: sbfx            x7, x2, #1, #0x1f
    //     0x6cf734: mov             x2, x7
    //     0x6cf738: lsl             x7, x2, #1
    //     0x6cf73c: lsl             w8, w7, #1
    //     0x6cf740: add             w9, w8, #8
    //     0x6cf744: add             x16, x0, w9, sxtw #1
    //     0x6cf748: ldur            w8, [x16, #0xf]
    //     0x6cf74c: add             x8, x8, HEAP, lsl #32
    //     0x6cf750: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd30] "extensions"
    //     0x6cf754: ldr             x16, [x16, #0xd30]
    //     0x6cf758: cmp             w8, w16
    //     0x6cf75c: b.ne            #0x6cf76c
    //     0x6cf760: add             w2, w7, #2
    //     0x6cf764: sbfx            x7, x2, #1, #0x1f
    //     0x6cf768: mov             x2, x7
    //     0x6cf76c: lsl             x7, x2, #1
    //     0x6cf770: lsl             w8, w7, #1
    //     0x6cf774: add             w9, w8, #8
    //     0x6cf778: add             x16, x0, w9, sxtw #1
    //     0x6cf77c: ldur            w8, [x16, #0xf]
    //     0x6cf780: add             x8, x8, HEAP, lsl #32
    //     0x6cf784: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd38] "filledButtonTheme"
    //     0x6cf788: ldr             x16, [x16, #0xd38]
    //     0x6cf78c: cmp             w8, w16
    //     0x6cf790: b.ne            #0x6cf7a0
    //     0x6cf794: add             w2, w7, #2
    //     0x6cf798: sbfx            x7, x2, #1, #0x1f
    //     0x6cf79c: mov             x2, x7
    //     0x6cf7a0: lsl             x7, x2, #1
    //     0x6cf7a4: lsl             w8, w7, #1
    //     0x6cf7a8: add             w9, w8, #8
    //     0x6cf7ac: add             x16, x0, w9, sxtw #1
    //     0x6cf7b0: ldur            w8, [x16, #0xf]
    //     0x6cf7b4: add             x8, x8, HEAP, lsl #32
    //     0x6cf7b8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd40] "fixTextFieldOutlineLabel"
    //     0x6cf7bc: ldr             x16, [x16, #0xd40]
    //     0x6cf7c0: cmp             w8, w16
    //     0x6cf7c4: b.ne            #0x6cf7d4
    //     0x6cf7c8: add             w2, w7, #2
    //     0x6cf7cc: sbfx            x7, x2, #1, #0x1f
    //     0x6cf7d0: mov             x2, x7
    //     0x6cf7d4: lsl             x7, x2, #1
    //     0x6cf7d8: lsl             w8, w7, #1
    //     0x6cf7dc: add             w9, w8, #8
    //     0x6cf7e0: add             x16, x0, w9, sxtw #1
    //     0x6cf7e4: ldur            w8, [x16, #0xf]
    //     0x6cf7e8: add             x8, x8, HEAP, lsl #32
    //     0x6cf7ec: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd48] "floatingActionButtonTheme"
    //     0x6cf7f0: ldr             x16, [x16, #0xd48]
    //     0x6cf7f4: cmp             w8, w16
    //     0x6cf7f8: b.ne            #0x6cf808
    //     0x6cf7fc: add             w2, w7, #2
    //     0x6cf800: sbfx            x7, x2, #1, #0x1f
    //     0x6cf804: mov             x2, x7
    //     0x6cf808: lsl             x7, x2, #1
    //     0x6cf80c: lsl             w8, w7, #1
    //     0x6cf810: add             w9, w8, #8
    //     0x6cf814: add             x16, x0, w9, sxtw #1
    //     0x6cf818: ldur            w8, [x16, #0xf]
    //     0x6cf81c: add             x8, x8, HEAP, lsl #32
    //     0x6cf820: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd50] "focusColor"
    //     0x6cf824: ldr             x16, [x16, #0xd50]
    //     0x6cf828: cmp             w8, w16
    //     0x6cf82c: b.ne            #0x6cf83c
    //     0x6cf830: add             w2, w7, #2
    //     0x6cf834: sbfx            x7, x2, #1, #0x1f
    //     0x6cf838: mov             x2, x7
    //     0x6cf83c: lsl             x7, x2, #1
    //     0x6cf840: lsl             w8, w7, #1
    //     0x6cf844: add             w9, w8, #8
    //     0x6cf848: add             x16, x0, w9, sxtw #1
    //     0x6cf84c: ldur            w8, [x16, #0xf]
    //     0x6cf850: add             x8, x8, HEAP, lsl #32
    //     0x6cf854: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd58] "highlightColor"
    //     0x6cf858: ldr             x16, [x16, #0xd58]
    //     0x6cf85c: cmp             w8, w16
    //     0x6cf860: b.ne            #0x6cf870
    //     0x6cf864: add             w2, w7, #2
    //     0x6cf868: sbfx            x7, x2, #1, #0x1f
    //     0x6cf86c: mov             x2, x7
    //     0x6cf870: lsl             x7, x2, #1
    //     0x6cf874: lsl             w8, w7, #1
    //     0x6cf878: add             w9, w8, #8
    //     0x6cf87c: add             x16, x0, w9, sxtw #1
    //     0x6cf880: ldur            w8, [x16, #0xf]
    //     0x6cf884: add             x8, x8, HEAP, lsl #32
    //     0x6cf888: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd60] "hintColor"
    //     0x6cf88c: ldr             x16, [x16, #0xd60]
    //     0x6cf890: cmp             w8, w16
    //     0x6cf894: b.ne            #0x6cf8a4
    //     0x6cf898: add             w2, w7, #2
    //     0x6cf89c: sbfx            x7, x2, #1, #0x1f
    //     0x6cf8a0: mov             x2, x7
    //     0x6cf8a4: lsl             x7, x2, #1
    //     0x6cf8a8: lsl             w8, w7, #1
    //     0x6cf8ac: add             w9, w8, #8
    //     0x6cf8b0: add             x16, x0, w9, sxtw #1
    //     0x6cf8b4: ldur            w8, [x16, #0xf]
    //     0x6cf8b8: add             x8, x8, HEAP, lsl #32
    //     0x6cf8bc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd68] "hoverColor"
    //     0x6cf8c0: ldr             x16, [x16, #0xd68]
    //     0x6cf8c4: cmp             w8, w16
    //     0x6cf8c8: b.ne            #0x6cf8d8
    //     0x6cf8cc: add             w2, w7, #2
    //     0x6cf8d0: sbfx            x7, x2, #1, #0x1f
    //     0x6cf8d4: mov             x2, x7
    //     0x6cf8d8: lsl             x7, x2, #1
    //     0x6cf8dc: lsl             w8, w7, #1
    //     0x6cf8e0: add             w9, w8, #8
    //     0x6cf8e4: add             x16, x0, w9, sxtw #1
    //     0x6cf8e8: ldur            w8, [x16, #0xf]
    //     0x6cf8ec: add             x8, x8, HEAP, lsl #32
    //     0x6cf8f0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd70] "iconButtonTheme"
    //     0x6cf8f4: ldr             x16, [x16, #0xd70]
    //     0x6cf8f8: cmp             w8, w16
    //     0x6cf8fc: b.ne            #0x6cf90c
    //     0x6cf900: add             w2, w7, #2
    //     0x6cf904: sbfx            x7, x2, #1, #0x1f
    //     0x6cf908: mov             x2, x7
    //     0x6cf90c: lsl             x7, x2, #1
    //     0x6cf910: lsl             w8, w7, #1
    //     0x6cf914: add             w9, w8, #8
    //     0x6cf918: add             x16, x0, w9, sxtw #1
    //     0x6cf91c: ldur            w8, [x16, #0xf]
    //     0x6cf920: add             x8, x8, HEAP, lsl #32
    //     0x6cf924: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd78] "iconTheme"
    //     0x6cf928: ldr             x16, [x16, #0xd78]
    //     0x6cf92c: cmp             w8, w16
    //     0x6cf930: b.ne            #0x6cf940
    //     0x6cf934: add             w2, w7, #2
    //     0x6cf938: sbfx            x7, x2, #1, #0x1f
    //     0x6cf93c: mov             x2, x7
    //     0x6cf940: lsl             x7, x2, #1
    //     0x6cf944: lsl             w8, w7, #1
    //     0x6cf948: add             w9, w8, #8
    //     0x6cf94c: add             x16, x0, w9, sxtw #1
    //     0x6cf950: ldur            w8, [x16, #0xf]
    //     0x6cf954: add             x8, x8, HEAP, lsl #32
    //     0x6cf958: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd80] "indicatorColor"
    //     0x6cf95c: ldr             x16, [x16, #0xd80]
    //     0x6cf960: cmp             w8, w16
    //     0x6cf964: b.ne            #0x6cf974
    //     0x6cf968: add             w2, w7, #2
    //     0x6cf96c: sbfx            x7, x2, #1, #0x1f
    //     0x6cf970: mov             x2, x7
    //     0x6cf974: lsl             x7, x2, #1
    //     0x6cf978: lsl             w8, w7, #1
    //     0x6cf97c: add             w9, w8, #8
    //     0x6cf980: add             x16, x0, w9, sxtw #1
    //     0x6cf984: ldur            w8, [x16, #0xf]
    //     0x6cf988: add             x8, x8, HEAP, lsl #32
    //     0x6cf98c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd88] "inputDecorationTheme"
    //     0x6cf990: ldr             x16, [x16, #0xd88]
    //     0x6cf994: cmp             w8, w16
    //     0x6cf998: b.ne            #0x6cf9a8
    //     0x6cf99c: add             w2, w7, #2
    //     0x6cf9a0: sbfx            x7, x2, #1, #0x1f
    //     0x6cf9a4: mov             x2, x7
    //     0x6cf9a8: lsl             x7, x2, #1
    //     0x6cf9ac: lsl             w8, w7, #1
    //     0x6cf9b0: add             w9, w8, #8
    //     0x6cf9b4: add             x16, x0, w9, sxtw #1
    //     0x6cf9b8: ldur            w8, [x16, #0xf]
    //     0x6cf9bc: add             x8, x8, HEAP, lsl #32
    //     0x6cf9c0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd90] "listTileTheme"
    //     0x6cf9c4: ldr             x16, [x16, #0xd90]
    //     0x6cf9c8: cmp             w8, w16
    //     0x6cf9cc: b.ne            #0x6cf9dc
    //     0x6cf9d0: add             w2, w7, #2
    //     0x6cf9d4: sbfx            x7, x2, #1, #0x1f
    //     0x6cf9d8: mov             x2, x7
    //     0x6cf9dc: lsl             x7, x2, #1
    //     0x6cf9e0: lsl             w8, w7, #1
    //     0x6cf9e4: add             w9, w8, #8
    //     0x6cf9e8: add             x16, x0, w9, sxtw #1
    //     0x6cf9ec: ldur            w8, [x16, #0xf]
    //     0x6cf9f0: add             x8, x8, HEAP, lsl #32
    //     0x6cf9f4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd98] "materialTapTargetSize"
    //     0x6cf9f8: ldr             x16, [x16, #0xd98]
    //     0x6cf9fc: cmp             w8, w16
    //     0x6cfa00: b.ne            #0x6cfa10
    //     0x6cfa04: add             w2, w7, #2
    //     0x6cfa08: sbfx            x7, x2, #1, #0x1f
    //     0x6cfa0c: mov             x2, x7
    //     0x6cfa10: lsl             x7, x2, #1
    //     0x6cfa14: lsl             w8, w7, #1
    //     0x6cfa18: add             w9, w8, #8
    //     0x6cfa1c: add             x16, x0, w9, sxtw #1
    //     0x6cfa20: ldur            w8, [x16, #0xf]
    //     0x6cfa24: add             x8, x8, HEAP, lsl #32
    //     0x6cfa28: add             x16, PP, #0xc, lsl #12  ; [pp+0xcda0] "menuBarTheme"
    //     0x6cfa2c: ldr             x16, [x16, #0xda0]
    //     0x6cfa30: cmp             w8, w16
    //     0x6cfa34: b.ne            #0x6cfa44
    //     0x6cfa38: add             w2, w7, #2
    //     0x6cfa3c: sbfx            x7, x2, #1, #0x1f
    //     0x6cfa40: mov             x2, x7
    //     0x6cfa44: lsl             x7, x2, #1
    //     0x6cfa48: lsl             w8, w7, #1
    //     0x6cfa4c: add             w9, w8, #8
    //     0x6cfa50: add             x16, x0, w9, sxtw #1
    //     0x6cfa54: ldur            w8, [x16, #0xf]
    //     0x6cfa58: add             x8, x8, HEAP, lsl #32
    //     0x6cfa5c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcda8] "menuButtonTheme"
    //     0x6cfa60: ldr             x16, [x16, #0xda8]
    //     0x6cfa64: cmp             w8, w16
    //     0x6cfa68: b.ne            #0x6cfa78
    //     0x6cfa6c: add             w2, w7, #2
    //     0x6cfa70: sbfx            x7, x2, #1, #0x1f
    //     0x6cfa74: mov             x2, x7
    //     0x6cfa78: lsl             x7, x2, #1
    //     0x6cfa7c: lsl             w8, w7, #1
    //     0x6cfa80: add             w9, w8, #8
    //     0x6cfa84: add             x16, x0, w9, sxtw #1
    //     0x6cfa88: ldur            w8, [x16, #0xf]
    //     0x6cfa8c: add             x8, x8, HEAP, lsl #32
    //     0x6cfa90: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdb0] "menuTheme"
    //     0x6cfa94: ldr             x16, [x16, #0xdb0]
    //     0x6cfa98: cmp             w8, w16
    //     0x6cfa9c: b.ne            #0x6cfaac
    //     0x6cfaa0: add             w2, w7, #2
    //     0x6cfaa4: sbfx            x7, x2, #1, #0x1f
    //     0x6cfaa8: mov             x2, x7
    //     0x6cfaac: lsl             x7, x2, #1
    //     0x6cfab0: lsl             w8, w7, #1
    //     0x6cfab4: add             w9, w8, #8
    //     0x6cfab8: add             x16, x0, w9, sxtw #1
    //     0x6cfabc: ldur            w8, [x16, #0xf]
    //     0x6cfac0: add             x8, x8, HEAP, lsl #32
    //     0x6cfac4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdb8] "navigationBarTheme"
    //     0x6cfac8: ldr             x16, [x16, #0xdb8]
    //     0x6cfacc: cmp             w8, w16
    //     0x6cfad0: b.ne            #0x6cfae0
    //     0x6cfad4: add             w2, w7, #2
    //     0x6cfad8: sbfx            x7, x2, #1, #0x1f
    //     0x6cfadc: mov             x2, x7
    //     0x6cfae0: lsl             x7, x2, #1
    //     0x6cfae4: lsl             w8, w7, #1
    //     0x6cfae8: add             w9, w8, #8
    //     0x6cfaec: add             x16, x0, w9, sxtw #1
    //     0x6cfaf0: ldur            w8, [x16, #0xf]
    //     0x6cfaf4: add             x8, x8, HEAP, lsl #32
    //     0x6cfaf8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdc0] "navigationDrawerTheme"
    //     0x6cfafc: ldr             x16, [x16, #0xdc0]
    //     0x6cfb00: cmp             w8, w16
    //     0x6cfb04: b.ne            #0x6cfb14
    //     0x6cfb08: add             w2, w7, #2
    //     0x6cfb0c: sbfx            x7, x2, #1, #0x1f
    //     0x6cfb10: mov             x2, x7
    //     0x6cfb14: lsl             x7, x2, #1
    //     0x6cfb18: lsl             w8, w7, #1
    //     0x6cfb1c: add             w9, w8, #8
    //     0x6cfb20: add             x16, x0, w9, sxtw #1
    //     0x6cfb24: ldur            w8, [x16, #0xf]
    //     0x6cfb28: add             x8, x8, HEAP, lsl #32
    //     0x6cfb2c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdc8] "navigationRailTheme"
    //     0x6cfb30: ldr             x16, [x16, #0xdc8]
    //     0x6cfb34: cmp             w8, w16
    //     0x6cfb38: b.ne            #0x6cfb48
    //     0x6cfb3c: add             w2, w7, #2
    //     0x6cfb40: sbfx            x7, x2, #1, #0x1f
    //     0x6cfb44: mov             x2, x7
    //     0x6cfb48: lsl             x7, x2, #1
    //     0x6cfb4c: lsl             w8, w7, #1
    //     0x6cfb50: add             w9, w8, #8
    //     0x6cfb54: add             x16, x0, w9, sxtw #1
    //     0x6cfb58: ldur            w8, [x16, #0xf]
    //     0x6cfb5c: add             x8, x8, HEAP, lsl #32
    //     0x6cfb60: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdd0] "outlinedButtonTheme"
    //     0x6cfb64: ldr             x16, [x16, #0xdd0]
    //     0x6cfb68: cmp             w8, w16
    //     0x6cfb6c: b.ne            #0x6cfb7c
    //     0x6cfb70: add             w2, w7, #2
    //     0x6cfb74: sbfx            x7, x2, #1, #0x1f
    //     0x6cfb78: mov             x2, x7
    //     0x6cfb7c: lsl             x7, x2, #1
    //     0x6cfb80: lsl             w8, w7, #1
    //     0x6cfb84: add             w9, w8, #8
    //     0x6cfb88: add             x16, x0, w9, sxtw #1
    //     0x6cfb8c: ldur            w8, [x16, #0xf]
    //     0x6cfb90: add             x8, x8, HEAP, lsl #32
    //     0x6cfb94: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdd8] "pageTransitionsTheme"
    //     0x6cfb98: ldr             x16, [x16, #0xdd8]
    //     0x6cfb9c: cmp             w8, w16
    //     0x6cfba0: b.ne            #0x6cfbb0
    //     0x6cfba4: add             w2, w7, #2
    //     0x6cfba8: sbfx            x7, x2, #1, #0x1f
    //     0x6cfbac: mov             x2, x7
    //     0x6cfbb0: lsl             x7, x2, #1
    //     0x6cfbb4: lsl             w8, w7, #1
    //     0x6cfbb8: add             w9, w8, #8
    //     0x6cfbbc: add             x16, x0, w9, sxtw #1
    //     0x6cfbc0: ldur            w8, [x16, #0xf]
    //     0x6cfbc4: add             x8, x8, HEAP, lsl #32
    //     0x6cfbc8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcde0] "platform"
    //     0x6cfbcc: ldr             x16, [x16, #0xde0]
    //     0x6cfbd0: cmp             w8, w16
    //     0x6cfbd4: b.ne            #0x6cfbe4
    //     0x6cfbd8: add             w2, w7, #2
    //     0x6cfbdc: sbfx            x7, x2, #1, #0x1f
    //     0x6cfbe0: mov             x2, x7
    //     0x6cfbe4: lsl             x7, x2, #1
    //     0x6cfbe8: lsl             w8, w7, #1
    //     0x6cfbec: add             w9, w8, #8
    //     0x6cfbf0: add             x16, x0, w9, sxtw #1
    //     0x6cfbf4: ldur            w8, [x16, #0xf]
    //     0x6cfbf8: add             x8, x8, HEAP, lsl #32
    //     0x6cfbfc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcde8] "popupMenuTheme"
    //     0x6cfc00: ldr             x16, [x16, #0xde8]
    //     0x6cfc04: cmp             w8, w16
    //     0x6cfc08: b.ne            #0x6cfc18
    //     0x6cfc0c: add             w2, w7, #2
    //     0x6cfc10: sbfx            x7, x2, #1, #0x1f
    //     0x6cfc14: mov             x2, x7
    //     0x6cfc18: lsl             x7, x2, #1
    //     0x6cfc1c: lsl             w8, w7, #1
    //     0x6cfc20: add             w9, w8, #8
    //     0x6cfc24: add             x16, x0, w9, sxtw #1
    //     0x6cfc28: ldur            w8, [x16, #0xf]
    //     0x6cfc2c: add             x8, x8, HEAP, lsl #32
    //     0x6cfc30: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdf0] "primaryColor"
    //     0x6cfc34: ldr             x16, [x16, #0xdf0]
    //     0x6cfc38: cmp             w8, w16
    //     0x6cfc3c: b.ne            #0x6cfc4c
    //     0x6cfc40: add             w2, w7, #2
    //     0x6cfc44: sbfx            x7, x2, #1, #0x1f
    //     0x6cfc48: mov             x2, x7
    //     0x6cfc4c: lsl             x7, x2, #1
    //     0x6cfc50: lsl             w8, w7, #1
    //     0x6cfc54: add             w9, w8, #8
    //     0x6cfc58: add             x16, x0, w9, sxtw #1
    //     0x6cfc5c: ldur            w8, [x16, #0xf]
    //     0x6cfc60: add             x8, x8, HEAP, lsl #32
    //     0x6cfc64: add             x16, PP, #0xc, lsl #12  ; [pp+0xcdf8] "primaryColorBrightness"
    //     0x6cfc68: ldr             x16, [x16, #0xdf8]
    //     0x6cfc6c: cmp             w8, w16
    //     0x6cfc70: b.ne            #0x6cfc80
    //     0x6cfc74: add             w2, w7, #2
    //     0x6cfc78: sbfx            x7, x2, #1, #0x1f
    //     0x6cfc7c: mov             x2, x7
    //     0x6cfc80: lsl             x7, x2, #1
    //     0x6cfc84: lsl             w8, w7, #1
    //     0x6cfc88: add             w9, w8, #8
    //     0x6cfc8c: add             x16, x0, w9, sxtw #1
    //     0x6cfc90: ldur            w8, [x16, #0xf]
    //     0x6cfc94: add             x8, x8, HEAP, lsl #32
    //     0x6cfc98: add             x16, PP, #0xc, lsl #12  ; [pp+0xce00] "primaryColorDark"
    //     0x6cfc9c: ldr             x16, [x16, #0xe00]
    //     0x6cfca0: cmp             w8, w16
    //     0x6cfca4: b.ne            #0x6cfcb4
    //     0x6cfca8: add             w2, w7, #2
    //     0x6cfcac: sbfx            x7, x2, #1, #0x1f
    //     0x6cfcb0: mov             x2, x7
    //     0x6cfcb4: lsl             x7, x2, #1
    //     0x6cfcb8: lsl             w8, w7, #1
    //     0x6cfcbc: add             w9, w8, #8
    //     0x6cfcc0: add             x16, x0, w9, sxtw #1
    //     0x6cfcc4: ldur            w8, [x16, #0xf]
    //     0x6cfcc8: add             x8, x8, HEAP, lsl #32
    //     0x6cfccc: add             x16, PP, #0xc, lsl #12  ; [pp+0xce08] "primaryColorLight"
    //     0x6cfcd0: ldr             x16, [x16, #0xe08]
    //     0x6cfcd4: cmp             w8, w16
    //     0x6cfcd8: b.ne            #0x6cfce8
    //     0x6cfcdc: add             w2, w7, #2
    //     0x6cfce0: sbfx            x7, x2, #1, #0x1f
    //     0x6cfce4: mov             x2, x7
    //     0x6cfce8: lsl             x7, x2, #1
    //     0x6cfcec: lsl             w8, w7, #1
    //     0x6cfcf0: add             w9, w8, #8
    //     0x6cfcf4: add             x16, x0, w9, sxtw #1
    //     0x6cfcf8: ldur            w8, [x16, #0xf]
    //     0x6cfcfc: add             x8, x8, HEAP, lsl #32
    //     0x6cfd00: add             x16, PP, #0xc, lsl #12  ; [pp+0xce10] "primaryIconTheme"
    //     0x6cfd04: ldr             x16, [x16, #0xe10]
    //     0x6cfd08: cmp             w8, w16
    //     0x6cfd0c: b.ne            #0x6cfd1c
    //     0x6cfd10: add             w2, w7, #2
    //     0x6cfd14: sbfx            x7, x2, #1, #0x1f
    //     0x6cfd18: mov             x2, x7
    //     0x6cfd1c: lsl             x7, x2, #1
    //     0x6cfd20: lsl             w8, w7, #1
    //     0x6cfd24: add             w9, w8, #8
    //     0x6cfd28: add             x16, x0, w9, sxtw #1
    //     0x6cfd2c: ldur            w8, [x16, #0xf]
    //     0x6cfd30: add             x8, x8, HEAP, lsl #32
    //     0x6cfd34: add             x16, PP, #0xc, lsl #12  ; [pp+0xce18] "primarySwatch"
    //     0x6cfd38: ldr             x16, [x16, #0xe18]
    //     0x6cfd3c: cmp             w8, w16
    //     0x6cfd40: b.ne            #0x6cfd50
    //     0x6cfd44: add             w2, w7, #2
    //     0x6cfd48: sbfx            x7, x2, #1, #0x1f
    //     0x6cfd4c: mov             x2, x7
    //     0x6cfd50: lsl             x7, x2, #1
    //     0x6cfd54: lsl             w8, w7, #1
    //     0x6cfd58: add             w9, w8, #8
    //     0x6cfd5c: add             x16, x0, w9, sxtw #1
    //     0x6cfd60: ldur            w8, [x16, #0xf]
    //     0x6cfd64: add             x8, x8, HEAP, lsl #32
    //     0x6cfd68: add             x16, PP, #0xc, lsl #12  ; [pp+0xce20] "primaryTextTheme"
    //     0x6cfd6c: ldr             x16, [x16, #0xe20]
    //     0x6cfd70: cmp             w8, w16
    //     0x6cfd74: b.ne            #0x6cfd84
    //     0x6cfd78: add             w2, w7, #2
    //     0x6cfd7c: sbfx            x7, x2, #1, #0x1f
    //     0x6cfd80: mov             x2, x7
    //     0x6cfd84: lsl             x7, x2, #1
    //     0x6cfd88: lsl             w8, w7, #1
    //     0x6cfd8c: add             w9, w8, #8
    //     0x6cfd90: add             x16, x0, w9, sxtw #1
    //     0x6cfd94: ldur            w8, [x16, #0xf]
    //     0x6cfd98: add             x8, x8, HEAP, lsl #32
    //     0x6cfd9c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce28] "progressIndicatorTheme"
    //     0x6cfda0: ldr             x16, [x16, #0xe28]
    //     0x6cfda4: cmp             w8, w16
    //     0x6cfda8: b.ne            #0x6cfdb8
    //     0x6cfdac: add             w2, w7, #2
    //     0x6cfdb0: sbfx            x7, x2, #1, #0x1f
    //     0x6cfdb4: mov             x2, x7
    //     0x6cfdb8: lsl             x7, x2, #1
    //     0x6cfdbc: lsl             w8, w7, #1
    //     0x6cfdc0: add             w9, w8, #8
    //     0x6cfdc4: add             x16, x0, w9, sxtw #1
    //     0x6cfdc8: ldur            w8, [x16, #0xf]
    //     0x6cfdcc: add             x8, x8, HEAP, lsl #32
    //     0x6cfdd0: add             x16, PP, #0xc, lsl #12  ; [pp+0xce30] "radioTheme"
    //     0x6cfdd4: ldr             x16, [x16, #0xe30]
    //     0x6cfdd8: cmp             w8, w16
    //     0x6cfddc: b.ne            #0x6cfdec
    //     0x6cfde0: add             w2, w7, #2
    //     0x6cfde4: sbfx            x7, x2, #1, #0x1f
    //     0x6cfde8: mov             x2, x7
    //     0x6cfdec: lsl             x7, x2, #1
    //     0x6cfdf0: lsl             w8, w7, #1
    //     0x6cfdf4: add             w9, w8, #8
    //     0x6cfdf8: add             x16, x0, w9, sxtw #1
    //     0x6cfdfc: ldur            w10, [x16, #0xf]
    //     0x6cfe00: add             x10, x10, HEAP, lsl #32
    //     0x6cfe04: add             x16, PP, #0xc, lsl #12  ; [pp+0xce38] "scaffoldBackgroundColor"
    //     0x6cfe08: ldr             x16, [x16, #0xe38]
    //     0x6cfe0c: cmp             w10, w16
    //     0x6cfe10: b.ne            #0x6cfe44
    //     0x6cfe14: add             w2, w8, #0xa
    //     0x6cfe18: add             x16, x0, w2, sxtw #1
    //     0x6cfe1c: ldur            w8, [x16, #0xf]
    //     0x6cfe20: add             x8, x8, HEAP, lsl #32
    //     0x6cfe24: sub             w2, w1, w8
    //     0x6cfe28: add             x8, fp, w2, sxtw #2
    //     0x6cfe2c: ldr             x8, [x8, #8]
    //     0x6cfe30: add             w2, w7, #2
    //     0x6cfe34: sbfx            x7, x2, #1, #0x1f
    //     0x6cfe38: mov             x2, x7
    //     0x6cfe3c: mov             x7, x8
    //     0x6cfe40: b               #0x6cfe48
    //     0x6cfe44: mov             x7, NULL
    //     0x6cfe48: stur            x7, [fp, #-0x18]
    //     0x6cfe4c: lsl             x8, x2, #1
    //     0x6cfe50: lsl             w9, w8, #1
    //     0x6cfe54: add             w10, w9, #8
    //     0x6cfe58: add             x16, x0, w10, sxtw #1
    //     0x6cfe5c: ldur            w9, [x16, #0xf]
    //     0x6cfe60: add             x9, x9, HEAP, lsl #32
    //     0x6cfe64: add             x16, PP, #0xc, lsl #12  ; [pp+0xce40] "scrollbarTheme"
    //     0x6cfe68: ldr             x16, [x16, #0xe40]
    //     0x6cfe6c: cmp             w9, w16
    //     0x6cfe70: b.ne            #0x6cfe80
    //     0x6cfe74: add             w2, w8, #2
    //     0x6cfe78: sbfx            x8, x2, #1, #0x1f
    //     0x6cfe7c: mov             x2, x8
    //     0x6cfe80: lsl             x8, x2, #1
    //     0x6cfe84: lsl             w9, w8, #1
    //     0x6cfe88: add             w10, w9, #8
    //     0x6cfe8c: add             x16, x0, w10, sxtw #1
    //     0x6cfe90: ldur            w9, [x16, #0xf]
    //     0x6cfe94: add             x9, x9, HEAP, lsl #32
    //     0x6cfe98: add             x16, PP, #0xc, lsl #12  ; [pp+0xce48] "secondaryHeaderColor"
    //     0x6cfe9c: ldr             x16, [x16, #0xe48]
    //     0x6cfea0: cmp             w9, w16
    //     0x6cfea4: b.ne            #0x6cfeb4
    //     0x6cfea8: add             w2, w8, #2
    //     0x6cfeac: sbfx            x8, x2, #1, #0x1f
    //     0x6cfeb0: mov             x2, x8
    //     0x6cfeb4: lsl             x8, x2, #1
    //     0x6cfeb8: lsl             w9, w8, #1
    //     0x6cfebc: add             w10, w9, #8
    //     0x6cfec0: add             x16, x0, w10, sxtw #1
    //     0x6cfec4: ldur            w9, [x16, #0xf]
    //     0x6cfec8: add             x9, x9, HEAP, lsl #32
    //     0x6cfecc: add             x16, PP, #0xc, lsl #12  ; [pp+0xce50] "segmentedButtonTheme"
    //     0x6cfed0: ldr             x16, [x16, #0xe50]
    //     0x6cfed4: cmp             w9, w16
    //     0x6cfed8: b.ne            #0x6cfee8
    //     0x6cfedc: add             w2, w8, #2
    //     0x6cfee0: sbfx            x8, x2, #1, #0x1f
    //     0x6cfee4: mov             x2, x8
    //     0x6cfee8: lsl             x8, x2, #1
    //     0x6cfeec: lsl             w9, w8, #1
    //     0x6cfef0: add             w10, w9, #8
    //     0x6cfef4: add             x16, x0, w10, sxtw #1
    //     0x6cfef8: ldur            w9, [x16, #0xf]
    //     0x6cfefc: add             x9, x9, HEAP, lsl #32
    //     0x6cff00: add             x16, PP, #0xc, lsl #12  ; [pp+0xce58] "selectedRowColor"
    //     0x6cff04: ldr             x16, [x16, #0xe58]
    //     0x6cff08: cmp             w9, w16
    //     0x6cff0c: b.ne            #0x6cff1c
    //     0x6cff10: add             w2, w8, #2
    //     0x6cff14: sbfx            x8, x2, #1, #0x1f
    //     0x6cff18: mov             x2, x8
    //     0x6cff1c: lsl             x8, x2, #1
    //     0x6cff20: lsl             w9, w8, #1
    //     0x6cff24: add             w10, w9, #8
    //     0x6cff28: add             x16, x0, w10, sxtw #1
    //     0x6cff2c: ldur            w9, [x16, #0xf]
    //     0x6cff30: add             x9, x9, HEAP, lsl #32
    //     0x6cff34: add             x16, PP, #0xc, lsl #12  ; [pp+0xce60] "shadowColor"
    //     0x6cff38: ldr             x16, [x16, #0xe60]
    //     0x6cff3c: cmp             w9, w16
    //     0x6cff40: b.ne            #0x6cff50
    //     0x6cff44: add             w2, w8, #2
    //     0x6cff48: sbfx            x8, x2, #1, #0x1f
    //     0x6cff4c: mov             x2, x8
    //     0x6cff50: lsl             x8, x2, #1
    //     0x6cff54: lsl             w9, w8, #1
    //     0x6cff58: add             w10, w9, #8
    //     0x6cff5c: add             x16, x0, w10, sxtw #1
    //     0x6cff60: ldur            w9, [x16, #0xf]
    //     0x6cff64: add             x9, x9, HEAP, lsl #32
    //     0x6cff68: add             x16, PP, #0xc, lsl #12  ; [pp+0xce68] "sliderTheme"
    //     0x6cff6c: ldr             x16, [x16, #0xe68]
    //     0x6cff70: cmp             w9, w16
    //     0x6cff74: b.ne            #0x6cff84
    //     0x6cff78: add             w2, w8, #2
    //     0x6cff7c: sbfx            x8, x2, #1, #0x1f
    //     0x6cff80: mov             x2, x8
    //     0x6cff84: lsl             x8, x2, #1
    //     0x6cff88: lsl             w9, w8, #1
    //     0x6cff8c: add             w10, w9, #8
    //     0x6cff90: add             x16, x0, w10, sxtw #1
    //     0x6cff94: ldur            w9, [x16, #0xf]
    //     0x6cff98: add             x9, x9, HEAP, lsl #32
    //     0x6cff9c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce70] "snackBarTheme"
    //     0x6cffa0: ldr             x16, [x16, #0xe70]
    //     0x6cffa4: cmp             w9, w16
    //     0x6cffa8: b.ne            #0x6cffb8
    //     0x6cffac: add             w2, w8, #2
    //     0x6cffb0: sbfx            x8, x2, #1, #0x1f
    //     0x6cffb4: mov             x2, x8
    //     0x6cffb8: lsl             x8, x2, #1
    //     0x6cffbc: lsl             w9, w8, #1
    //     0x6cffc0: add             w10, w9, #8
    //     0x6cffc4: add             x16, x0, w10, sxtw #1
    //     0x6cffc8: ldur            w11, [x16, #0xf]
    //     0x6cffcc: add             x11, x11, HEAP, lsl #32
    //     0x6cffd0: add             x16, PP, #0xc, lsl #12  ; [pp+0xce78] "splashColor"
    //     0x6cffd4: ldr             x16, [x16, #0xe78]
    //     0x6cffd8: cmp             w11, w16
    //     0x6cffdc: b.ne            #0x6d0010
    //     0x6cffe0: add             w2, w9, #0xa
    //     0x6cffe4: add             x16, x0, w2, sxtw #1
    //     0x6cffe8: ldur            w9, [x16, #0xf]
    //     0x6cffec: add             x9, x9, HEAP, lsl #32
    //     0x6cfff0: sub             w2, w1, w9
    //     0x6cfff4: add             x9, fp, w2, sxtw #2
    //     0x6cfff8: ldr             x9, [x9, #8]
    //     0x6cfffc: add             w2, w8, #2
    //     0x6d0000: sbfx            x8, x2, #1, #0x1f
    //     0x6d0004: mov             x2, x8
    //     0x6d0008: mov             x8, x9
    //     0x6d000c: b               #0x6d0014
    //     0x6d0010: mov             x8, NULL
    //     0x6d0014: stur            x8, [fp, #-0x10]
    //     0x6d0018: lsl             x9, x2, #1
    //     0x6d001c: lsl             w10, w9, #1
    //     0x6d0020: add             w11, w10, #8
    //     0x6d0024: add             x16, x0, w11, sxtw #1
    //     0x6d0028: ldur            w10, [x16, #0xf]
    //     0x6d002c: add             x10, x10, HEAP, lsl #32
    //     0x6d0030: add             x16, PP, #0xc, lsl #12  ; [pp+0xce80] "splashFactory"
    //     0x6d0034: ldr             x16, [x16, #0xe80]
    //     0x6d0038: cmp             w10, w16
    //     0x6d003c: b.ne            #0x6d004c
    //     0x6d0040: add             w2, w9, #2
    //     0x6d0044: sbfx            x9, x2, #1, #0x1f
    //     0x6d0048: mov             x2, x9
    //     0x6d004c: lsl             x9, x2, #1
    //     0x6d0050: lsl             w10, w9, #1
    //     0x6d0054: add             w11, w10, #8
    //     0x6d0058: add             x16, x0, w11, sxtw #1
    //     0x6d005c: ldur            w10, [x16, #0xf]
    //     0x6d0060: add             x10, x10, HEAP, lsl #32
    //     0x6d0064: add             x16, PP, #0xc, lsl #12  ; [pp+0xce88] "switchTheme"
    //     0x6d0068: ldr             x16, [x16, #0xe88]
    //     0x6d006c: cmp             w10, w16
    //     0x6d0070: b.ne            #0x6d0080
    //     0x6d0074: add             w2, w9, #2
    //     0x6d0078: sbfx            x9, x2, #1, #0x1f
    //     0x6d007c: mov             x2, x9
    //     0x6d0080: lsl             x9, x2, #1
    //     0x6d0084: lsl             w10, w9, #1
    //     0x6d0088: add             w11, w10, #8
    //     0x6d008c: add             x16, x0, w11, sxtw #1
    //     0x6d0090: ldur            w12, [x16, #0xf]
    //     0x6d0094: add             x12, x12, HEAP, lsl #32
    //     0x6d0098: add             x16, PP, #0xc, lsl #12  ; [pp+0xce90] "tabBarTheme"
    //     0x6d009c: ldr             x16, [x16, #0xe90]
    //     0x6d00a0: cmp             w12, w16
    //     0x6d00a4: b.ne            #0x6d00d8
    //     0x6d00a8: add             w2, w10, #0xa
    //     0x6d00ac: add             x16, x0, w2, sxtw #1
    //     0x6d00b0: ldur            w10, [x16, #0xf]
    //     0x6d00b4: add             x10, x10, HEAP, lsl #32
    //     0x6d00b8: sub             w2, w1, w10
    //     0x6d00bc: add             x1, fp, w2, sxtw #2
    //     0x6d00c0: ldr             x1, [x1, #8]
    //     0x6d00c4: add             w2, w9, #2
    //     0x6d00c8: sbfx            x9, x2, #1, #0x1f
    //     0x6d00cc: mov             x2, x1
    //     0x6d00d0: mov             x1, x9
    //     0x6d00d4: b               #0x6d00e0
    //     0x6d00d8: mov             x1, x2
    //     0x6d00dc: mov             x2, NULL
    //     0x6d00e0: stur            x2, [fp, #-8]
    //     0x6d00e4: lsl             x9, x1, #1
    //     0x6d00e8: lsl             w10, w9, #1
    //     0x6d00ec: add             w11, w10, #8
    //     0x6d00f0: add             x16, x0, w11, sxtw #1
    //     0x6d00f4: ldur            w10, [x16, #0xf]
    //     0x6d00f8: add             x10, x10, HEAP, lsl #32
    //     0x6d00fc: add             x16, PP, #0xc, lsl #12  ; [pp+0xce98] "textButtonTheme"
    //     0x6d0100: ldr             x16, [x16, #0xe98]
    //     0x6d0104: cmp             w10, w16
    //     0x6d0108: b.ne            #0x6d0118
    //     0x6d010c: add             w1, w9, #2
    //     0x6d0110: sbfx            x9, x1, #1, #0x1f
    //     0x6d0114: mov             x1, x9
    //     0x6d0118: lsl             x9, x1, #1
    //     0x6d011c: lsl             w10, w9, #1
    //     0x6d0120: add             w11, w10, #8
    //     0x6d0124: add             x16, x0, w11, sxtw #1
    //     0x6d0128: ldur            w10, [x16, #0xf]
    //     0x6d012c: add             x10, x10, HEAP, lsl #32
    //     0x6d0130: add             x16, PP, #0xc, lsl #12  ; [pp+0xcea0] "textSelectionTheme"
    //     0x6d0134: ldr             x16, [x16, #0xea0]
    //     0x6d0138: cmp             w10, w16
    //     0x6d013c: b.ne            #0x6d014c
    //     0x6d0140: add             w1, w9, #2
    //     0x6d0144: sbfx            x9, x1, #1, #0x1f
    //     0x6d0148: mov             x1, x9
    //     0x6d014c: lsl             x9, x1, #1
    //     0x6d0150: lsl             w10, w9, #1
    //     0x6d0154: add             w11, w10, #8
    //     0x6d0158: add             x16, x0, w11, sxtw #1
    //     0x6d015c: ldur            w10, [x16, #0xf]
    //     0x6d0160: add             x10, x10, HEAP, lsl #32
    //     0x6d0164: add             x16, PP, #0xc, lsl #12  ; [pp+0xcea8] "textTheme"
    //     0x6d0168: ldr             x16, [x16, #0xea8]
    //     0x6d016c: cmp             w10, w16
    //     0x6d0170: b.ne            #0x6d0180
    //     0x6d0174: add             w1, w9, #2
    //     0x6d0178: sbfx            x9, x1, #1, #0x1f
    //     0x6d017c: mov             x1, x9
    //     0x6d0180: lsl             x9, x1, #1
    //     0x6d0184: lsl             w10, w9, #1
    //     0x6d0188: add             w11, w10, #8
    //     0x6d018c: add             x16, x0, w11, sxtw #1
    //     0x6d0190: ldur            w10, [x16, #0xf]
    //     0x6d0194: add             x10, x10, HEAP, lsl #32
    //     0x6d0198: add             x16, PP, #0xc, lsl #12  ; [pp+0xceb0] "timePickerTheme"
    //     0x6d019c: ldr             x16, [x16, #0xeb0]
    //     0x6d01a0: cmp             w10, w16
    //     0x6d01a4: b.ne            #0x6d01b4
    //     0x6d01a8: add             w1, w9, #2
    //     0x6d01ac: sbfx            x9, x1, #1, #0x1f
    //     0x6d01b0: mov             x1, x9
    //     0x6d01b4: lsl             x9, x1, #1
    //     0x6d01b8: lsl             w10, w9, #1
    //     0x6d01bc: add             w11, w10, #8
    //     0x6d01c0: add             x16, x0, w11, sxtw #1
    //     0x6d01c4: ldur            w10, [x16, #0xf]
    //     0x6d01c8: add             x10, x10, HEAP, lsl #32
    //     0x6d01cc: add             x16, PP, #0xc, lsl #12  ; [pp+0xceb8] "toggleButtonsTheme"
    //     0x6d01d0: ldr             x16, [x16, #0xeb8]
    //     0x6d01d4: cmp             w10, w16
    //     0x6d01d8: b.ne            #0x6d01e8
    //     0x6d01dc: add             w1, w9, #2
    //     0x6d01e0: sbfx            x9, x1, #1, #0x1f
    //     0x6d01e4: mov             x1, x9
    //     0x6d01e8: lsl             x9, x1, #1
    //     0x6d01ec: lsl             w10, w9, #1
    //     0x6d01f0: add             w11, w10, #8
    //     0x6d01f4: add             x16, x0, w11, sxtw #1
    //     0x6d01f8: ldur            w10, [x16, #0xf]
    //     0x6d01fc: add             x10, x10, HEAP, lsl #32
    //     0x6d0200: add             x16, PP, #0xc, lsl #12  ; [pp+0xcec0] "toggleableActiveColor"
    //     0x6d0204: ldr             x16, [x16, #0xec0]
    //     0x6d0208: cmp             w10, w16
    //     0x6d020c: b.ne            #0x6d021c
    //     0x6d0210: add             w1, w9, #2
    //     0x6d0214: sbfx            x9, x1, #1, #0x1f
    //     0x6d0218: mov             x1, x9
    //     0x6d021c: lsl             x9, x1, #1
    //     0x6d0220: lsl             w10, w9, #1
    //     0x6d0224: add             w11, w10, #8
    //     0x6d0228: add             x16, x0, w11, sxtw #1
    //     0x6d022c: ldur            w10, [x16, #0xf]
    //     0x6d0230: add             x10, x10, HEAP, lsl #32
    //     0x6d0234: add             x16, PP, #0xc, lsl #12  ; [pp+0xcec8] "tooltipTheme"
    //     0x6d0238: ldr             x16, [x16, #0xec8]
    //     0x6d023c: cmp             w10, w16
    //     0x6d0240: b.ne            #0x6d0250
    //     0x6d0244: add             w1, w9, #2
    //     0x6d0248: sbfx            x9, x1, #1, #0x1f
    //     0x6d024c: mov             x1, x9
    //     0x6d0250: lsl             x9, x1, #1
    //     0x6d0254: lsl             w10, w9, #1
    //     0x6d0258: add             w11, w10, #8
    //     0x6d025c: add             x16, x0, w11, sxtw #1
    //     0x6d0260: ldur            w10, [x16, #0xf]
    //     0x6d0264: add             x10, x10, HEAP, lsl #32
    //     0x6d0268: add             x16, PP, #0xc, lsl #12  ; [pp+0xced0] "typography"
    //     0x6d026c: ldr             x16, [x16, #0xed0]
    //     0x6d0270: cmp             w10, w16
    //     0x6d0274: b.ne            #0x6d0284
    //     0x6d0278: add             w1, w9, #2
    //     0x6d027c: sbfx            x9, x1, #1, #0x1f
    //     0x6d0280: mov             x1, x9
    //     0x6d0284: lsl             x9, x1, #1
    //     0x6d0288: lsl             w1, w9, #1
    //     0x6d028c: add             w9, w1, #8
    //     0x6d0290: add             x16, x0, w9, sxtw #1
    //     0x6d0294: ldur            w1, [x16, #0xf]
    //     0x6d0298: add             x1, x1, HEAP, lsl #32
    //     0x6d029c: add             x16, PP, #0xc, lsl #12  ; [pp+0xced8] "unselectedWidgetColor"
    //     0x6d02a0: ldr             x16, [x16, #0xed8]
    //     0x6d02a4: cmp             w1, w16
    //     0x6d02a8: b.eq            #0x6d02ac
    // 0x6d02ac: CheckStackOverflow
    //     0x6d02ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d02b0: cmp             SP, x16
    //     0x6d02b4: b.ls            #0x6d1580
    // 0x6d02b8: r16 = <ThemeExtension<ThemeExtension>>
    //     0x6d02b8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcee0] TypeArguments: <ThemeExtension<ThemeExtension>>
    //     0x6d02bc: ldr             x16, [x16, #0xee0]
    // 0x6d02c0: stp             xzr, x16, [SP, #-0x10]!
    // 0x6d02c4: r0 = _GrowableList()
    //     0x6d02c4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6d02c8: add             SP, SP, #0x10
    // 0x6d02cc: stur            x0, [fp, #-0x40]
    // 0x6d02d0: r0 = defaultTargetPlatform()
    //     0x6d02d0: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0x6d02d4: stur            x0, [fp, #-0x50]
    // 0x6d02d8: LoadField: r1 = r0->field_7
    //     0x6d02d8: ldur            x1, [x0, #7]
    // 0x6d02dc: cmp             x1, #2
    // 0x6d02e0: b.gt            #0x6d02f0
    // 0x6d02e4: r2 = Instance_MaterialTapTargetSize
    //     0x6d02e4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcee8] Obj!MaterialTapTargetSize@b650d1
    //     0x6d02e8: ldr             x2, [x2, #0xee8]
    // 0x6d02ec: b               #0x6d02f8
    // 0x6d02f0: r2 = Instance_MaterialTapTargetSize
    //     0x6d02f0: add             x2, PP, #0xc, lsl #12  ; [pp+0xcef0] Obj!MaterialTapTargetSize@b650b1
    //     0x6d02f4: ldr             x2, [x2, #0xef0]
    // 0x6d02f8: ldur            x1, [fp, #-0x38]
    // 0x6d02fc: stur            x2, [fp, #-0x48]
    // 0x6d0300: r0 = adaptivePlatformDensity()
    //     0x6d0300: bl              #0x6d2e10  ; [package:flutter/src/material/theme_data.dart] VisualDensity::adaptivePlatformDensity
    // 0x6d0304: mov             x1, x0
    // 0x6d0308: ldur            x0, [fp, #-0x38]
    // 0x6d030c: stur            x1, [fp, #-0x88]
    // 0x6d0310: cmp             w0, NULL
    // 0x6d0314: b.ne            #0x6d0320
    // 0x6d0318: r2 = false
    //     0x6d0318: add             x2, NULL, #0x30  ; false
    // 0x6d031c: b               #0x6d0324
    // 0x6d0320: mov             x2, x0
    // 0x6d0324: ldur            x0, [fp, #-0x50]
    // 0x6d0328: stur            x2, [fp, #-0x80]
    // 0x6d032c: r16 = Instance_TargetPlatform
    //     0x6d032c: ldr             x16, [PP, #0x43a8]  ; [pp+0x43a8] Obj!TargetPlatform@b65d71
    // 0x6d0330: cmp             w0, w16
    // 0x6d0334: b.ne            #0x6d0340
    // 0x6d0338: r3 = true
    //     0x6d0338: add             x3, NULL, #0x20  ; true
    // 0x6d033c: b               #0x6d0344
    // 0x6d0340: r3 = false
    //     0x6d0340: add             x3, NULL, #0x30  ; false
    // 0x6d0344: tbnz            w2, #4, #0x6d0368
    // 0x6d0348: tbnz            w3, #4, #0x6d0358
    // 0x6d034c: r3 = Instance__InkSparkleFactory
    //     0x6d034c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcef8] Obj!_InkSparkleFactory@b38561
    //     0x6d0350: ldr             x3, [x3, #0xef8]
    // 0x6d0354: b               #0x6d0360
    // 0x6d0358: r3 = Instance__InkRippleFactory
    //     0x6d0358: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf00] Obj!_InkRippleFactory@b38571
    //     0x6d035c: ldr             x3, [x3, #0xf00]
    // 0x6d0360: mov             x4, x3
    // 0x6d0364: b               #0x6d0370
    // 0x6d0368: r4 = Instance__InkSplashFactory
    //     0x6d0368: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf08] Obj!_InkSplashFactory@b38551
    //     0x6d036c: ldr             x4, [x4, #0xf08]
    // 0x6d0370: ldur            x3, [fp, #-0x28]
    // 0x6d0374: stur            x4, [fp, #-0x78]
    // 0x6d0378: cmp             w3, NULL
    // 0x6d037c: b.ne            #0x6d03a0
    // 0x6d0380: ldur            x5, [fp, #-0x20]
    // 0x6d0384: cmp             w5, NULL
    // 0x6d0388: b.ne            #0x6d0394
    // 0x6d038c: r6 = Null
    //     0x6d038c: mov             x6, NULL
    // 0x6d0390: b               #0x6d03a8
    // 0x6d0394: LoadField: r6 = r5->field_7
    //     0x6d0394: ldur            w6, [x5, #7]
    // 0x6d0398: DecompressPointer r6
    //     0x6d0398: add             x6, x6, HEAP, lsl #32
    // 0x6d039c: b               #0x6d03a8
    // 0x6d03a0: ldur            x5, [fp, #-0x20]
    // 0x6d03a4: mov             x6, x3
    // 0x6d03a8: cmp             w6, NULL
    // 0x6d03ac: b.ne            #0x6d03b4
    // 0x6d03b0: r6 = Instance_Brightness
    //     0x6d03b0: ldr             x6, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0x6d03b4: stur            x6, [fp, #-0x70]
    // 0x6d03b8: r16 = Instance_Brightness
    //     0x6d03b8: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x6d03bc: cmp             w6, w16
    // 0x6d03c0: r16 = true
    //     0x6d03c0: add             x16, NULL, #0x20  ; true
    // 0x6d03c4: r17 = false
    //     0x6d03c4: add             x17, NULL, #0x30  ; false
    // 0x6d03c8: csel            x7, x16, x17, eq
    // 0x6d03cc: stur            x7, [fp, #-0x68]
    // 0x6d03d0: tbnz            w2, #4, #0x6d0518
    // 0x6d03d4: cmp             w5, NULL
    // 0x6d03d8: b.ne            #0x6d03f4
    // 0x6d03dc: tbnz            w7, #4, #0x6d03ec
    // 0x6d03e0: r5 = Instance_ColorScheme
    //     0x6d03e0: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf10] Obj!ColorScheme@b48851
    //     0x6d03e4: ldr             x5, [x5, #0xf10]
    // 0x6d03e8: b               #0x6d03f4
    // 0x6d03ec: r5 = Instance_ColorScheme
    //     0x6d03ec: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf18] Obj!ColorScheme@b487c1
    //     0x6d03f0: ldr             x5, [x5, #0xf18]
    // 0x6d03f4: stur            x5, [fp, #-0x60]
    // 0x6d03f8: tbnz            w7, #4, #0x6d0408
    // 0x6d03fc: LoadField: r8 = r5->field_53
    //     0x6d03fc: ldur            w8, [x5, #0x53]
    // 0x6d0400: DecompressPointer r8
    //     0x6d0400: add             x8, x8, HEAP, lsl #32
    // 0x6d0404: b               #0x6d0410
    // 0x6d0408: LoadField: r8 = r5->field_b
    //     0x6d0408: ldur            w8, [x5, #0xb]
    // 0x6d040c: DecompressPointer r8
    //     0x6d040c: add             x8, x8, HEAP, lsl #32
    // 0x6d0410: stur            x8, [fp, #-0x58]
    // 0x6d0414: tbnz            w7, #4, #0x6d0428
    // 0x6d0418: LoadField: r9 = r5->field_57
    //     0x6d0418: ldur            w9, [x5, #0x57]
    // 0x6d041c: DecompressPointer r9
    //     0x6d041c: add             x9, x9, HEAP, lsl #32
    // 0x6d0420: mov             x10, x9
    // 0x6d0424: b               #0x6d0434
    // 0x6d0428: LoadField: r9 = r5->field_f
    //     0x6d0428: ldur            w9, [x5, #0xf]
    // 0x6d042c: DecompressPointer r9
    //     0x6d042c: add             x9, x9, HEAP, lsl #32
    // 0x6d0430: mov             x10, x9
    // 0x6d0434: ldur            x9, [fp, #-0x18]
    // 0x6d0438: stur            x10, [fp, #-0x38]
    // 0x6d043c: SaveReg r8
    //     0x6d043c: str             x8, [SP, #-8]!
    // 0x6d0440: r0 = estimateBrightnessForColor()
    //     0x6d0440: bl              #0x6d295c  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x6d0444: add             SP, SP, #8
    // 0x6d0448: ldur            x0, [fp, #-0x60]
    // 0x6d044c: LoadField: r1 = r0->field_4b
    //     0x6d044c: ldur            w1, [x0, #0x4b]
    // 0x6d0450: DecompressPointer r1
    //     0x6d0450: add             x1, x1, HEAP, lsl #32
    // 0x6d0454: stur            x1, [fp, #-0x98]
    // 0x6d0458: LoadField: r2 = r0->field_1b
    //     0x6d0458: ldur            w2, [x0, #0x1b]
    // 0x6d045c: DecompressPointer r2
    //     0x6d045c: add             x2, x2, HEAP, lsl #32
    // 0x6d0460: stur            x2, [fp, #-0x90]
    // 0x6d0464: SaveReg r2
    //     0x6d0464: str             x2, [SP, #-8]!
    // 0x6d0468: r0 = estimateBrightnessForColor()
    //     0x6d0468: bl              #0x6d295c  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x6d046c: add             SP, SP, #8
    // 0x6d0470: mov             x1, x0
    // 0x6d0474: ldur            x0, [fp, #-0x18]
    // 0x6d0478: cmp             w0, NULL
    // 0x6d047c: b.ne            #0x6d0488
    // 0x6d0480: ldur            x2, [fp, #-0x98]
    // 0x6d0484: b               #0x6d048c
    // 0x6d0488: mov             x2, x0
    // 0x6d048c: ldur            x0, [fp, #-0x60]
    // 0x6d0490: LoadField: r3 = r0->field_53
    //     0x6d0490: ldur            w3, [x0, #0x53]
    // 0x6d0494: DecompressPointer r3
    //     0x6d0494: add             x3, x3, HEAP, lsl #32
    // 0x6d0498: LoadField: r4 = r0->field_63
    //     0x6d0498: ldur            w4, [x0, #0x63]
    // 0x6d049c: DecompressPointer r4
    //     0x6d049c: add             x4, x4, HEAP, lsl #32
    // 0x6d04a0: cmp             w4, NULL
    // 0x6d04a4: b.ne            #0x6d04b8
    // 0x6d04a8: LoadField: r4 = r0->field_4f
    //     0x6d04a8: ldur            w4, [x0, #0x4f]
    // 0x6d04ac: DecompressPointer r4
    //     0x6d04ac: add             x4, x4, HEAP, lsl #32
    // 0x6d04b0: mov             x5, x4
    // 0x6d04b4: b               #0x6d04bc
    // 0x6d04b8: mov             x5, x4
    // 0x6d04bc: ldur            x4, [fp, #-0x28]
    // 0x6d04c0: LoadField: r6 = r0->field_3b
    //     0x6d04c0: ldur            w6, [x0, #0x3b]
    // 0x6d04c4: DecompressPointer r6
    //     0x6d04c4: add             x6, x6, HEAP, lsl #32
    // 0x6d04c8: r16 = Instance_Brightness
    //     0x6d04c8: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x6d04cc: cmp             w4, w16
    // 0x6d04d0: r16 = true
    //     0x6d04d0: add             x16, NULL, #0x20  ; true
    // 0x6d04d4: r17 = false
    //     0x6d04d4: add             x17, NULL, #0x30  ; false
    // 0x6d04d8: csel            x7, x16, x17, eq
    // 0x6d04dc: ldur            x13, [fp, #-0x90]
    // 0x6d04e0: mov             x12, x1
    // 0x6d04e4: mov             x11, x7
    // 0x6d04e8: ldur            x10, [fp, #-0x98]
    // 0x6d04ec: mov             x9, x3
    // 0x6d04f0: ldur            x8, [fp, #-0x98]
    // 0x6d04f4: mov             x7, x3
    // 0x6d04f8: mov             x3, x6
    // 0x6d04fc: mov             x6, x0
    // 0x6d0500: mov             x4, x5
    // 0x6d0504: ldur            x5, [fp, #-0x98]
    // 0x6d0508: mov             x0, x2
    // 0x6d050c: ldur            x2, [fp, #-0x38]
    // 0x6d0510: ldur            x1, [fp, #-0x58]
    // 0x6d0514: b               #0x6d0550
    // 0x6d0518: ldur            x0, [fp, #-0x18]
    // 0x6d051c: mov             x6, x5
    // 0x6d0520: r13 = Null
    //     0x6d0520: mov             x13, NULL
    // 0x6d0524: r12 = Null
    //     0x6d0524: mov             x12, NULL
    // 0x6d0528: r11 = Null
    //     0x6d0528: mov             x11, NULL
    // 0x6d052c: r10 = Null
    //     0x6d052c: mov             x10, NULL
    // 0x6d0530: r9 = Null
    //     0x6d0530: mov             x9, NULL
    // 0x6d0534: r8 = Null
    //     0x6d0534: mov             x8, NULL
    // 0x6d0538: r7 = Null
    //     0x6d0538: mov             x7, NULL
    // 0x6d053c: r5 = Null
    //     0x6d053c: mov             x5, NULL
    // 0x6d0540: r4 = Null
    //     0x6d0540: mov             x4, NULL
    // 0x6d0544: r3 = Null
    //     0x6d0544: mov             x3, NULL
    // 0x6d0548: r2 = Null
    //     0x6d0548: mov             x2, NULL
    // 0x6d054c: r1 = Null
    //     0x6d054c: mov             x1, NULL
    // 0x6d0550: stur            x13, [fp, #-0x20]
    // 0x6d0554: stur            x12, [fp, #-0x28]
    // 0x6d0558: stur            x10, [fp, #-0x38]
    // 0x6d055c: stur            x9, [fp, #-0x58]
    // 0x6d0560: stur            x8, [fp, #-0x60]
    // 0x6d0564: stur            x7, [fp, #-0x90]
    // 0x6d0568: stur            x6, [fp, #-0x98]
    // 0x6d056c: stur            x5, [fp, #-0xa0]
    // 0x6d0570: stur            x4, [fp, #-0xa8]
    // 0x6d0574: stur            x3, [fp, #-0xb0]
    // 0x6d0578: stur            x2, [fp, #-0xb8]
    // 0x6d057c: stur            x0, [fp, #-0xc0]
    // 0x6d0580: cmp             w11, NULL
    // 0x6d0584: b.ne            #0x6d058c
    // 0x6d0588: r11 = false
    //     0x6d0588: add             x11, NULL, #0x30  ; false
    // 0x6d058c: stur            x11, [fp, #-0x18]
    // 0x6d0590: cmp             w1, NULL
    // 0x6d0594: b.ne            #0x6d05d0
    // 0x6d0598: ldur            x1, [fp, #-0x68]
    // 0x6d059c: tbnz            w1, #4, #0x6d05c4
    // 0x6d05a0: r16 = _ConstMap len:12
    //     0x6d05a0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d05a4: ldr             x16, [x16, #0xf20]
    // 0x6d05a8: r30 = 1800
    //     0x6d05a8: mov             lr, #0x708
    // 0x6d05ac: stp             lr, x16, [SP, #-0x10]!
    // 0x6d05b0: r0 = []()
    //     0x6d05b0: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d05b4: add             SP, SP, #0x10
    // 0x6d05b8: cmp             w0, NULL
    // 0x6d05bc: b.eq            #0x6d1588
    // 0x6d05c0: b               #0x6d05cc
    // 0x6d05c4: r0 = Instance_MaterialColor
    //     0x6d05c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0x6d05c8: ldr             x0, [x0, #0xf28]
    // 0x6d05cc: mov             x1, x0
    // 0x6d05d0: ldur            x0, [fp, #-0x68]
    // 0x6d05d4: stur            x1, [fp, #-0xc8]
    // 0x6d05d8: SaveReg r1
    //     0x6d05d8: str             x1, [SP, #-8]!
    // 0x6d05dc: r0 = estimateBrightnessForColor()
    //     0x6d05dc: bl              #0x6d295c  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x6d05e0: add             SP, SP, #8
    // 0x6d05e4: mov             x1, x0
    // 0x6d05e8: ldur            x0, [fp, #-0x68]
    // 0x6d05ec: stur            x1, [fp, #-0xd0]
    // 0x6d05f0: tbnz            w0, #4, #0x6d061c
    // 0x6d05f4: r16 = _ConstMap len:12
    //     0x6d05f4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d05f8: ldr             x16, [x16, #0xf20]
    // 0x6d05fc: r30 = 1000
    //     0x6d05fc: mov             lr, #0x3e8
    // 0x6d0600: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0604: r0 = []()
    //     0x6d0604: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0608: add             SP, SP, #0x10
    // 0x6d060c: cmp             w0, NULL
    // 0x6d0610: b.eq            #0x6d158c
    // 0x6d0614: mov             x1, x0
    // 0x6d0618: b               #0x6d0640
    // 0x6d061c: r16 = _ConstMap len:10
    //     0x6d061c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d0620: ldr             x16, [x16, #0xf30]
    // 0x6d0624: r30 = 200
    //     0x6d0624: mov             lr, #0xc8
    // 0x6d0628: stp             lr, x16, [SP, #-0x10]!
    // 0x6d062c: r0 = []()
    //     0x6d062c: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0630: add             SP, SP, #0x10
    // 0x6d0634: cmp             w0, NULL
    // 0x6d0638: b.eq            #0x6d1590
    // 0x6d063c: mov             x1, x0
    // 0x6d0640: ldur            x0, [fp, #-0x68]
    // 0x6d0644: stur            x1, [fp, #-0xd8]
    // 0x6d0648: tbnz            w0, #4, #0x6d0658
    // 0x6d064c: r2 = Instance_Color
    //     0x6d064c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d0650: ldr             x2, [x2, #0xf38]
    // 0x6d0654: b               #0x6d0680
    // 0x6d0658: r16 = _ConstMap len:10
    //     0x6d0658: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d065c: ldr             x16, [x16, #0xf30]
    // 0x6d0660: r30 = 1400
    //     0x6d0660: mov             lr, #0x578
    // 0x6d0664: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0668: r0 = []()
    //     0x6d0668: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d066c: add             SP, SP, #0x10
    // 0x6d0670: cmp             w0, NULL
    // 0x6d0674: b.eq            #0x6d1594
    // 0x6d0678: mov             x2, x0
    // 0x6d067c: ldur            x0, [fp, #-0x68]
    // 0x6d0680: ldur            x1, [fp, #-0xd0]
    // 0x6d0684: stur            x2, [fp, #-0xe8]
    // 0x6d0688: r16 = Instance_Brightness
    //     0x6d0688: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x6d068c: cmp             w1, w16
    // 0x6d0690: r16 = true
    //     0x6d0690: add             x16, NULL, #0x20  ; true
    // 0x6d0694: r17 = false
    //     0x6d0694: add             x17, NULL, #0x30  ; false
    // 0x6d0698: csel            x3, x16, x17, eq
    // 0x6d069c: stur            x3, [fp, #-0xe0]
    // 0x6d06a0: tbnz            w0, #4, #0x6d06cc
    // 0x6d06a4: r16 = _ConstMap len:4
    //     0x6d06a4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf40] Map<int, Color>(4)
    //     0x6d06a8: ldr             x16, [x16, #0xf40]
    // 0x6d06ac: r30 = 400
    //     0x6d06ac: mov             lr, #0x190
    // 0x6d06b0: stp             lr, x16, [SP, #-0x10]!
    // 0x6d06b4: r0 = []()
    //     0x6d06b4: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d06b8: add             SP, SP, #0x10
    // 0x6d06bc: cmp             w0, NULL
    // 0x6d06c0: b.eq            #0x6d1598
    // 0x6d06c4: mov             x1, x0
    // 0x6d06c8: b               #0x6d0704
    // 0x6d06cc: ldur            x0, [fp, #-0x20]
    // 0x6d06d0: cmp             w0, NULL
    // 0x6d06d4: b.ne            #0x6d06fc
    // 0x6d06d8: r16 = _ConstMap len:10
    //     0x6d06d8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d06dc: ldr             x16, [x16, #0xf30]
    // 0x6d06e0: r30 = 1200
    //     0x6d06e0: mov             lr, #0x4b0
    // 0x6d06e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6d06e8: r0 = []()
    //     0x6d06e8: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d06ec: add             SP, SP, #0x10
    // 0x6d06f0: cmp             w0, NULL
    // 0x6d06f4: b.eq            #0x6d159c
    // 0x6d06f8: b               #0x6d0700
    // 0x6d06fc: ldur            x0, [fp, #-0x20]
    // 0x6d0700: mov             x1, x0
    // 0x6d0704: ldur            x0, [fp, #-0x20]
    // 0x6d0708: stur            x1, [fp, #-0xf0]
    // 0x6d070c: cmp             w0, NULL
    // 0x6d0710: b.ne            #0x6d0768
    // 0x6d0714: ldur            x0, [fp, #-0x68]
    // 0x6d0718: tbnz            w0, #4, #0x6d0740
    // 0x6d071c: r16 = _ConstMap len:4
    //     0x6d071c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf40] Map<int, Color>(4)
    //     0x6d0720: ldr             x16, [x16, #0xf40]
    // 0x6d0724: r30 = 400
    //     0x6d0724: mov             lr, #0x190
    // 0x6d0728: stp             lr, x16, [SP, #-0x10]!
    // 0x6d072c: r0 = []()
    //     0x6d072c: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0730: add             SP, SP, #0x10
    // 0x6d0734: cmp             w0, NULL
    // 0x6d0738: b.eq            #0x6d15a0
    // 0x6d073c: b               #0x6d0760
    // 0x6d0740: r16 = _ConstMap len:10
    //     0x6d0740: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d0744: ldr             x16, [x16, #0xf30]
    // 0x6d0748: r30 = 1000
    //     0x6d0748: mov             lr, #0x3e8
    // 0x6d074c: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0750: r0 = []()
    //     0x6d0750: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0754: add             SP, SP, #0x10
    // 0x6d0758: cmp             w0, NULL
    // 0x6d075c: b.eq            #0x6d15a4
    // 0x6d0760: mov             x1, x0
    // 0x6d0764: b               #0x6d076c
    // 0x6d0768: mov             x1, x0
    // 0x6d076c: ldur            x0, [fp, #-0x28]
    // 0x6d0770: stur            x1, [fp, #-0x20]
    // 0x6d0774: cmp             w0, NULL
    // 0x6d0778: b.ne            #0x6d0790
    // 0x6d077c: SaveReg r1
    //     0x6d077c: str             x1, [SP, #-8]!
    // 0x6d0780: r0 = estimateBrightnessForColor()
    //     0x6d0780: bl              #0x6d295c  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x6d0784: add             SP, SP, #8
    // 0x6d0788: mov             x1, x0
    // 0x6d078c: b               #0x6d0794
    // 0x6d0790: mov             x1, x0
    // 0x6d0794: ldur            x0, [fp, #-0x68]
    // 0x6d0798: stur            x1, [fp, #-0xf8]
    // 0x6d079c: r16 = Instance_Brightness
    //     0x6d079c: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x6d07a0: cmp             w1, w16
    // 0x6d07a4: r16 = true
    //     0x6d07a4: add             x16, NULL, #0x20  ; true
    // 0x6d07a8: r17 = false
    //     0x6d07a8: add             x17, NULL, #0x30  ; false
    // 0x6d07ac: csel            x2, x16, x17, eq
    // 0x6d07b0: stur            x2, [fp, #-0x28]
    // 0x6d07b4: tbnz            w0, #4, #0x6d07e0
    // 0x6d07b8: d0 = 0.120000
    //     0x6d07b8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x6d07bc: ldr             d0, [x17, #0xf48]
    // 0x6d07c0: r16 = Instance_Color
    //     0x6d07c0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d07c4: ldr             x16, [x16, #0xbe8]
    // 0x6d07c8: SaveReg r16
    //     0x6d07c8: str             x16, [SP, #-8]!
    // 0x6d07cc: SaveReg d0
    //     0x6d07cc: str             d0, [SP, #-8]!
    // 0x6d07d0: r0 = withOpacity()
    //     0x6d07d0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x6d07d4: add             SP, SP, #0x10
    // 0x6d07d8: mov             x1, x0
    // 0x6d07dc: b               #0x6d0804
    // 0x6d07e0: d0 = 0.120000
    //     0x6d07e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x6d07e4: ldr             d0, [x17, #0xf48]
    // 0x6d07e8: r16 = Instance_Color
    //     0x6d07e8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d07ec: ldr             x16, [x16, #0xf38]
    // 0x6d07f0: SaveReg r16
    //     0x6d07f0: str             x16, [SP, #-8]!
    // 0x6d07f4: SaveReg d0
    //     0x6d07f4: str             d0, [SP, #-8]!
    // 0x6d07f8: r0 = withOpacity()
    //     0x6d07f8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x6d07fc: add             SP, SP, #0x10
    // 0x6d0800: mov             x1, x0
    // 0x6d0804: ldur            x0, [fp, #-0x68]
    // 0x6d0808: stur            x1, [fp, #-0x100]
    // 0x6d080c: tbnz            w0, #4, #0x6d0838
    // 0x6d0810: d0 = 0.040000
    //     0x6d0810: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf50] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x6d0814: ldr             d0, [x17, #0xf50]
    // 0x6d0818: r16 = Instance_Color
    //     0x6d0818: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d081c: ldr             x16, [x16, #0xbe8]
    // 0x6d0820: SaveReg r16
    //     0x6d0820: str             x16, [SP, #-8]!
    // 0x6d0824: SaveReg d0
    //     0x6d0824: str             d0, [SP, #-8]!
    // 0x6d0828: r0 = withOpacity()
    //     0x6d0828: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x6d082c: add             SP, SP, #0x10
    // 0x6d0830: mov             x1, x0
    // 0x6d0834: b               #0x6d085c
    // 0x6d0838: d0 = 0.040000
    //     0x6d0838: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf50] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x6d083c: ldr             d0, [x17, #0xf50]
    // 0x6d0840: r16 = Instance_Color
    //     0x6d0840: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d0844: ldr             x16, [x16, #0xf38]
    // 0x6d0848: SaveReg r16
    //     0x6d0848: str             x16, [SP, #-8]!
    // 0x6d084c: SaveReg d0
    //     0x6d084c: str             d0, [SP, #-8]!
    // 0x6d0850: r0 = withOpacity()
    //     0x6d0850: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x6d0854: add             SP, SP, #0x10
    // 0x6d0858: mov             x1, x0
    // 0x6d085c: ldur            x0, [fp, #-0x60]
    // 0x6d0860: r17 = -264
    //     0x6d0860: mov             x17, #-0x108
    // 0x6d0864: str             x1, [fp, x17]
    // 0x6d0868: cmp             w0, NULL
    // 0x6d086c: b.ne            #0x6d08c4
    // 0x6d0870: ldur            x0, [fp, #-0x68]
    // 0x6d0874: tbnz            w0, #4, #0x6d089c
    // 0x6d0878: r16 = _ConstMap len:12
    //     0x6d0878: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d087c: ldr             x16, [x16, #0xf20]
    // 0x6d0880: r30 = 1700
    //     0x6d0880: mov             lr, #0x6a4
    // 0x6d0884: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0888: r0 = []()
    //     0x6d0888: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d088c: add             SP, SP, #0x10
    // 0x6d0890: cmp             w0, NULL
    // 0x6d0894: b.eq            #0x6d15a8
    // 0x6d0898: b               #0x6d08bc
    // 0x6d089c: r16 = _ConstMap len:12
    //     0x6d089c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d08a0: ldr             x16, [x16, #0xf20]
    // 0x6d08a4: r30 = 100
    //     0x6d08a4: mov             lr, #0x64
    // 0x6d08a8: stp             lr, x16, [SP, #-0x10]!
    // 0x6d08ac: r0 = []()
    //     0x6d08ac: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d08b0: add             SP, SP, #0x10
    // 0x6d08b4: cmp             w0, NULL
    // 0x6d08b8: b.eq            #0x6d15ac
    // 0x6d08bc: mov             x1, x0
    // 0x6d08c0: b               #0x6d08c8
    // 0x6d08c4: mov             x1, x0
    // 0x6d08c8: ldur            x0, [fp, #-0xc0]
    // 0x6d08cc: r17 = -272
    //     0x6d08cc: mov             x17, #-0x110
    // 0x6d08d0: str             x1, [fp, x17]
    // 0x6d08d4: cmp             w0, NULL
    // 0x6d08d8: b.ne            #0x6d08e4
    // 0x6d08dc: mov             x2, x1
    // 0x6d08e0: b               #0x6d08e8
    // 0x6d08e4: mov             x2, x0
    // 0x6d08e8: ldur            x0, [fp, #-0x90]
    // 0x6d08ec: stur            x2, [fp, #-0x60]
    // 0x6d08f0: cmp             w0, NULL
    // 0x6d08f4: b.ne            #0x6d0934
    // 0x6d08f8: ldur            x0, [fp, #-0x68]
    // 0x6d08fc: tbnz            w0, #4, #0x6d0924
    // 0x6d0900: r16 = _ConstMap len:12
    //     0x6d0900: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d0904: ldr             x16, [x16, #0xf20]
    // 0x6d0908: r30 = 1600
    //     0x6d0908: mov             lr, #0x640
    // 0x6d090c: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0910: r0 = []()
    //     0x6d0910: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0914: add             SP, SP, #0x10
    // 0x6d0918: cmp             w0, NULL
    // 0x6d091c: b.eq            #0x6d15b0
    // 0x6d0920: b               #0x6d092c
    // 0x6d0924: r0 = Instance_Color
    //     0x6d0924: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d0928: ldr             x0, [x0, #0xbe8]
    // 0x6d092c: mov             x1, x0
    // 0x6d0930: b               #0x6d0938
    // 0x6d0934: mov             x1, x0
    // 0x6d0938: ldur            x0, [fp, #-0xa8]
    // 0x6d093c: stur            x1, [fp, #-0xc0]
    // 0x6d0940: cmp             w0, NULL
    // 0x6d0944: b.ne            #0x6d096c
    // 0x6d0948: ldur            x2, [fp, #-0x68]
    // 0x6d094c: tbnz            w2, #4, #0x6d095c
    // 0x6d0950: r0 = Instance_Color
    //     0x6d0950: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf58] Obj!Color@b5d281
    //     0x6d0954: ldr             x0, [x0, #0xf58]
    // 0x6d0958: b               #0x6d0964
    // 0x6d095c: r0 = Instance_Color
    //     0x6d095c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf60] Obj!Color@b5d271
    //     0x6d0960: ldr             x0, [x0, #0xf60]
    // 0x6d0964: mov             x3, x0
    // 0x6d0968: b               #0x6d0974
    // 0x6d096c: ldur            x2, [fp, #-0x68]
    // 0x6d0970: mov             x3, x0
    // 0x6d0974: ldur            x0, [fp, #-0x98]
    // 0x6d0978: stur            x3, [fp, #-0x90]
    // 0x6d097c: cmp             w0, NULL
    // 0x6d0980: b.ne            #0x6d0a24
    // 0x6d0984: tbnz            w2, #4, #0x6d09ac
    // 0x6d0988: r16 = _ConstMap len:12
    //     0x6d0988: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d098c: ldr             x16, [x16, #0xf20]
    // 0x6d0990: r30 = 1400
    //     0x6d0990: mov             lr, #0x578
    // 0x6d0994: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0998: r0 = []()
    //     0x6d0998: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d099c: add             SP, SP, #0x10
    // 0x6d09a0: cmp             w0, NULL
    // 0x6d09a4: b.eq            #0x6d15b4
    // 0x6d09a8: b               #0x6d09cc
    // 0x6d09ac: r16 = _ConstMap len:10
    //     0x6d09ac: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d09b0: ldr             x16, [x16, #0xf30]
    // 0x6d09b4: r30 = 400
    //     0x6d09b4: mov             lr, #0x190
    // 0x6d09b8: stp             lr, x16, [SP, #-0x10]!
    // 0x6d09bc: r0 = []()
    //     0x6d09bc: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d09c0: add             SP, SP, #0x10
    // 0x6d09c4: cmp             w0, NULL
    // 0x6d09c8: b.eq            #0x6d15b8
    // 0x6d09cc: stur            x0, [fp, #-0xa8]
    // 0x6d09d0: r16 = _ConstMap len:10
    //     0x6d09d0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf68] Map<int, Color>(10)
    //     0x6d09d4: ldr             x16, [x16, #0xf68]
    // 0x6d09d8: r30 = 1400
    //     0x6d09d8: mov             lr, #0x578
    // 0x6d09dc: stp             lr, x16, [SP, #-0x10]!
    // 0x6d09e0: r0 = []()
    //     0x6d09e0: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d09e4: add             SP, SP, #0x10
    // 0x6d09e8: ldur            x16, [fp, #-0x20]
    // 0x6d09ec: stp             x16, NULL, [SP, #-0x10]!
    // 0x6d09f0: ldur            x16, [fp, #-0xa8]
    // 0x6d09f4: ldur            lr, [fp, #-0x70]
    // 0x6d09f8: stp             lr, x16, [SP, #-0x10]!
    // 0x6d09fc: ldur            x16, [fp, #-0xe8]
    // 0x6d0a00: ldur            lr, [fp, #-0xc0]
    // 0x6d0a04: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0a08: SaveReg r0
    //     0x6d0a08: str             x0, [SP, #-8]!
    // 0x6d0a0c: r4 = const [0, 0x7, 0x7, 0x4, cardColor, 0x5, errorColor, 0x6, primaryColorDark, 0x4, null]
    //     0x6d0a0c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf70] List(11) [0, 0x7, 0x7, 0x4, "cardColor", 0x5, "errorColor", 0x6, "primaryColorDark", 0x4, Null]
    //     0x6d0a10: ldr             x4, [x4, #0xf70]
    // 0x6d0a14: r0 = ColorScheme.fromSwatch()
    //     0x6d0a14: bl              #0x6d2538  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::ColorScheme.fromSwatch
    // 0x6d0a18: add             SP, SP, #0x38
    // 0x6d0a1c: mov             x1, x0
    // 0x6d0a20: b               #0x6d0a28
    // 0x6d0a24: mov             x1, x0
    // 0x6d0a28: ldur            x0, [fp, #-0x68]
    // 0x6d0a2c: stur            x1, [fp, #-0x70]
    // 0x6d0a30: r16 = _ConstMap len:12
    //     0x6d0a30: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d0a34: ldr             x16, [x16, #0xf20]
    // 0x6d0a38: r30 = 200
    //     0x6d0a38: mov             lr, #0xc8
    // 0x6d0a3c: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0a40: r0 = []()
    //     0x6d0a40: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0a44: add             SP, SP, #0x10
    // 0x6d0a48: stur            x0, [fp, #-0xa8]
    // 0x6d0a4c: cmp             w0, NULL
    // 0x6d0a50: b.eq            #0x6d15bc
    // 0x6d0a54: ldur            x1, [fp, #-0x68]
    // 0x6d0a58: tbnz            w1, #4, #0x6d0a68
    // 0x6d0a5c: r2 = Instance_Color
    //     0x6d0a5c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf78] Obj!Color@b5d261
    //     0x6d0a60: ldr             x2, [x2, #0xf78]
    // 0x6d0a64: b               #0x6d0a70
    // 0x6d0a68: r2 = Instance_Color
    //     0x6d0a68: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf80] Obj!Color@b5d251
    //     0x6d0a6c: ldr             x2, [x2, #0xf80]
    // 0x6d0a70: stur            x2, [fp, #-0x98]
    // 0x6d0a74: tbnz            w1, #4, #0x6d0aa0
    // 0x6d0a78: r16 = _ConstMap len:12
    //     0x6d0a78: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d0a7c: ldr             x16, [x16, #0xf20]
    // 0x6d0a80: r30 = 1400
    //     0x6d0a80: mov             lr, #0x578
    // 0x6d0a84: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0a88: r0 = []()
    //     0x6d0a88: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0a8c: add             SP, SP, #0x10
    // 0x6d0a90: cmp             w0, NULL
    // 0x6d0a94: b.eq            #0x6d15c0
    // 0x6d0a98: mov             x1, x0
    // 0x6d0a9c: b               #0x6d0ac4
    // 0x6d0aa0: r16 = _ConstMap len:10
    //     0x6d0aa0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d0aa4: ldr             x16, [x16, #0xf30]
    // 0x6d0aa8: r30 = 100
    //     0x6d0aa8: mov             lr, #0x64
    // 0x6d0aac: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0ab0: r0 = []()
    //     0x6d0ab0: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0ab4: add             SP, SP, #0x10
    // 0x6d0ab8: cmp             w0, NULL
    // 0x6d0abc: b.eq            #0x6d15c4
    // 0x6d0ac0: mov             x1, x0
    // 0x6d0ac4: ldur            x0, [fp, #-0xa0]
    // 0x6d0ac8: r17 = -280
    //     0x6d0ac8: mov             x17, #-0x118
    // 0x6d0acc: str             x1, [fp, x17]
    // 0x6d0ad0: cmp             w0, NULL
    // 0x6d0ad4: b.ne            #0x6d0b14
    // 0x6d0ad8: ldur            x0, [fp, #-0x68]
    // 0x6d0adc: tbnz            w0, #4, #0x6d0b04
    // 0x6d0ae0: r16 = _ConstMap len:12
    //     0x6d0ae0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d0ae4: ldr             x16, [x16, #0xf20]
    // 0x6d0ae8: r30 = 1600
    //     0x6d0ae8: mov             lr, #0x640
    // 0x6d0aec: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0af0: r0 = []()
    //     0x6d0af0: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0af4: add             SP, SP, #0x10
    // 0x6d0af8: cmp             w0, NULL
    // 0x6d0afc: b.eq            #0x6d15c8
    // 0x6d0b00: b               #0x6d0b0c
    // 0x6d0b04: r0 = Instance_Color
    //     0x6d0b04: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d0b08: ldr             x0, [x0, #0xbe8]
    // 0x6d0b0c: mov             x1, x0
    // 0x6d0b10: b               #0x6d0b18
    // 0x6d0b14: mov             x1, x0
    // 0x6d0b18: ldur            x0, [fp, #-0xb8]
    // 0x6d0b1c: r17 = -288
    //     0x6d0b1c: mov             x17, #-0x120
    // 0x6d0b20: str             x1, [fp, x17]
    // 0x6d0b24: cmp             w0, NULL
    // 0x6d0b28: b.ne            #0x6d0c98
    // 0x6d0b2c: ldur            x0, [fp, #-0x20]
    // 0x6d0b30: r2 = LoadClassIdInstr(r0)
    //     0x6d0b30: ldur            x2, [x0, #-1]
    //     0x6d0b34: ubfx            x2, x2, #0xc, #0x14
    // 0x6d0b38: lsl             x2, x2, #1
    // 0x6d0b3c: stur            x2, [fp, #-0xa0]
    // 0x6d0b40: r17 = 10114
    //     0x6d0b40: mov             x17, #0x2782
    // 0x6d0b44: cmp             w2, w17
    // 0x6d0b48: b.eq            #0x6d0b58
    // 0x6d0b4c: r17 = 10118
    //     0x6d0b4c: mov             x17, #0x2786
    // 0x6d0b50: cmp             w2, w17
    // 0x6d0b54: b.ne            #0x6d0c58
    // 0x6d0b58: ldur            x3, [fp, #-0xc8]
    // 0x6d0b5c: cmp             w0, w3
    // 0x6d0b60: b.eq            #0x6d0c80
    // 0x6d0b64: stp             x0, x3, [SP, #-0x10]!
    // 0x6d0b68: r0 = _haveSameRuntimeType()
    //     0x6d0b68: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6d0b6c: add             SP, SP, #0x10
    // 0x6d0b70: tbnz            w0, #4, #0x6d0c8c
    // 0x6d0b74: ldur            x1, [fp, #-0xc8]
    // 0x6d0b78: r0 = LoadClassIdInstr(r1)
    //     0x6d0b78: ldur            x0, [x1, #-1]
    //     0x6d0b7c: ubfx            x0, x0, #0xc, #0x14
    // 0x6d0b80: lsl             x0, x0, #1
    // 0x6d0b84: r2 = LoadInt32Instr(r0)
    //     0x6d0b84: sbfx            x2, x0, #1, #0x1f
    // 0x6d0b88: r17 = 5057
    //     0x6d0b88: mov             x17, #0x13c1
    // 0x6d0b8c: cmp             x2, x17
    // 0x6d0b90: b.lt            #0x6d0c50
    // 0x6d0b94: r17 = 5064
    //     0x6d0b94: mov             x17, #0x13c8
    // 0x6d0b98: cmp             x2, x17
    // 0x6d0b9c: b.gt            #0x6d0c48
    // 0x6d0ba0: r17 = 10124
    //     0x6d0ba0: mov             x17, #0x278c
    // 0x6d0ba4: cmp             w0, w17
    // 0x6d0ba8: b.gt            #0x6d0bb8
    // 0x6d0bac: r17 = 10122
    //     0x6d0bac: mov             x17, #0x278a
    // 0x6d0bb0: cmp             w0, w17
    // 0x6d0bb4: b.ge            #0x6d0bd0
    // 0x6d0bb8: r17 = 10114
    //     0x6d0bb8: mov             x17, #0x2782
    // 0x6d0bbc: cmp             w0, w17
    // 0x6d0bc0: b.eq            #0x6d0bd0
    // 0x6d0bc4: r17 = 10118
    //     0x6d0bc4: mov             x17, #0x2786
    // 0x6d0bc8: cmp             w0, w17
    // 0x6d0bcc: b.ne            #0x6d0bdc
    // 0x6d0bd0: LoadField: r0 = r1->field_7
    //     0x6d0bd0: ldur            x0, [x1, #7]
    // 0x6d0bd4: mov             x2, x0
    // 0x6d0bd8: b               #0x6d0be8
    // 0x6d0bdc: LoadField: r0 = r1->field_f
    //     0x6d0bdc: ldur            w0, [x1, #0xf]
    // 0x6d0be0: DecompressPointer r0
    //     0x6d0be0: add             x0, x0, HEAP, lsl #32
    // 0x6d0be4: LoadField: r2 = r0->field_7
    //     0x6d0be4: ldur            x2, [x0, #7]
    // 0x6d0be8: ldur            x0, [fp, #-0xa0]
    // 0x6d0bec: r17 = 10124
    //     0x6d0bec: mov             x17, #0x278c
    // 0x6d0bf0: cmp             w0, w17
    // 0x6d0bf4: b.gt            #0x6d0c04
    // 0x6d0bf8: r17 = 10122
    //     0x6d0bf8: mov             x17, #0x278a
    // 0x6d0bfc: cmp             w0, w17
    // 0x6d0c00: b.ge            #0x6d0c1c
    // 0x6d0c04: r17 = 10114
    //     0x6d0c04: mov             x17, #0x2782
    // 0x6d0c08: cmp             w0, w17
    // 0x6d0c0c: b.eq            #0x6d0c1c
    // 0x6d0c10: r17 = 10118
    //     0x6d0c10: mov             x17, #0x2786
    // 0x6d0c14: cmp             w0, w17
    // 0x6d0c18: b.ne            #0x6d0c28
    // 0x6d0c1c: ldur            x3, [fp, #-0x20]
    // 0x6d0c20: LoadField: r0 = r3->field_7
    //     0x6d0c20: ldur            x0, [x3, #7]
    // 0x6d0c24: b               #0x6d0c3c
    // 0x6d0c28: ldur            x3, [fp, #-0x20]
    // 0x6d0c2c: LoadField: r0 = r3->field_f
    //     0x6d0c2c: ldur            w0, [x3, #0xf]
    // 0x6d0c30: DecompressPointer r0
    //     0x6d0c30: add             x0, x0, HEAP, lsl #32
    // 0x6d0c34: LoadField: r4 = r0->field_7
    //     0x6d0c34: ldur            x4, [x0, #7]
    // 0x6d0c38: mov             x0, x4
    // 0x6d0c3c: cmp             x2, x0
    // 0x6d0c40: b.ne            #0x6d0c8c
    // 0x6d0c44: b               #0x6d0c80
    // 0x6d0c48: ldur            x3, [fp, #-0x20]
    // 0x6d0c4c: b               #0x6d0c8c
    // 0x6d0c50: ldur            x3, [fp, #-0x20]
    // 0x6d0c54: b               #0x6d0c8c
    // 0x6d0c58: ldur            x1, [fp, #-0xc8]
    // 0x6d0c5c: mov             x3, x0
    // 0x6d0c60: r0 = LoadClassIdInstr(r3)
    //     0x6d0c60: ldur            x0, [x3, #-1]
    //     0x6d0c64: ubfx            x0, x0, #0xc, #0x14
    // 0x6d0c68: stp             x1, x3, [SP, #-0x10]!
    // 0x6d0c6c: mov             lr, x0
    // 0x6d0c70: ldr             lr, [x21, lr, lsl #3]
    // 0x6d0c74: blr             lr
    // 0x6d0c78: add             SP, SP, #0x10
    // 0x6d0c7c: tbnz            w0, #4, #0x6d0c8c
    // 0x6d0c80: r0 = Instance_Color
    //     0x6d0c80: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d0c84: ldr             x0, [x0, #0xbe8]
    // 0x6d0c88: b               #0x6d0c90
    // 0x6d0c8c: ldur            x0, [fp, #-0x20]
    // 0x6d0c90: mov             x1, x0
    // 0x6d0c94: b               #0x6d0c9c
    // 0x6d0c98: mov             x1, x0
    // 0x6d0c9c: ldur            x0, [fp, #-0x68]
    // 0x6d0ca0: stur            x1, [fp, #-0xa0]
    // 0x6d0ca4: tbnz            w0, #4, #0x6d0cb4
    // 0x6d0ca8: r1 = Instance_Color
    //     0x6d0ca8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf88] Obj!Color@b5d241
    //     0x6d0cac: ldr             x1, [x1, #0xf88]
    // 0x6d0cb0: b               #0x6d0cdc
    // 0x6d0cb4: d0 = 0.600000
    //     0x6d0cb4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0x6d0cb8: ldr             d0, [x17, #0xf90]
    // 0x6d0cbc: r16 = Instance_Color
    //     0x6d0cbc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d0cc0: ldr             x16, [x16, #0xf38]
    // 0x6d0cc4: SaveReg r16
    //     0x6d0cc4: str             x16, [SP, #-8]!
    // 0x6d0cc8: SaveReg d0
    //     0x6d0cc8: str             d0, [SP, #-8]!
    // 0x6d0ccc: r0 = withOpacity()
    //     0x6d0ccc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x6d0cd0: add             SP, SP, #0x10
    // 0x6d0cd4: mov             x1, x0
    // 0x6d0cd8: ldur            x0, [fp, #-0x68]
    // 0x6d0cdc: stur            x1, [fp, #-0xb8]
    // 0x6d0ce0: tbnz            w0, #4, #0x6d0d0c
    // 0x6d0ce4: r16 = _ConstMap len:10
    //     0x6d0ce4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d0ce8: ldr             x16, [x16, #0xf30]
    // 0x6d0cec: r30 = 1200
    //     0x6d0cec: mov             lr, #0x4b0
    // 0x6d0cf0: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0cf4: r0 = []()
    //     0x6d0cf4: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0cf8: add             SP, SP, #0x10
    // 0x6d0cfc: cmp             w0, NULL
    // 0x6d0d00: b.eq            #0x6d15cc
    // 0x6d0d04: mov             x6, x0
    // 0x6d0d08: b               #0x6d0d30
    // 0x6d0d0c: r16 = _ConstMap len:12
    //     0x6d0d0c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d0d10: ldr             x16, [x16, #0xf20]
    // 0x6d0d14: r30 = 600
    //     0x6d0d14: mov             lr, #0x258
    // 0x6d0d18: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0d1c: r0 = []()
    //     0x6d0d1c: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0d20: add             SP, SP, #0x10
    // 0x6d0d24: cmp             w0, NULL
    // 0x6d0d28: b.eq            #0x6d15d0
    // 0x6d0d2c: mov             x6, x0
    // 0x6d0d30: ldur            x5, [fp, #-0x10]
    // 0x6d0d34: ldur            x4, [fp, #-0x48]
    // 0x6d0d38: ldur            x3, [fp, #-0x100]
    // 0x6d0d3c: r17 = -264
    //     0x6d0d3c: mov             x17, #-0x108
    // 0x6d0d40: ldr             x2, [fp, x17]
    // 0x6d0d44: ldur            x1, [fp, #-0x70]
    // 0x6d0d48: ldur            x0, [fp, #-0x68]
    // 0x6d0d4c: r17 = -296
    //     0x6d0d4c: mov             x17, #-0x128
    // 0x6d0d50: str             x6, [fp, x17]
    // 0x6d0d54: r0 = ButtonThemeData()
    //     0x6d0d54: bl              #0x6d252c  ; AllocateButtonThemeDataStub -> ButtonThemeData (size=0x4c)
    // 0x6d0d58: mov             x1, x0
    // 0x6d0d5c: r0 = Instance_ButtonTextTheme
    //     0x6d0d5c: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf98] Obj!ButtonTextTheme@b65951
    //     0x6d0d60: ldr             x0, [x0, #0xf98]
    // 0x6d0d64: r17 = -312
    //     0x6d0d64: mov             x17, #-0x138
    // 0x6d0d68: str             x1, [fp, x17]
    // 0x6d0d6c: StoreField: r1->field_17 = r0
    //     0x6d0d6c: stur            w0, [x1, #0x17]
    // 0x6d0d70: d0 = 88.000000
    //     0x6d0d70: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa0] IMM: double(88) from 0x4056000000000000
    //     0x6d0d74: ldr             d0, [x17, #0xfa0]
    // 0x6d0d78: StoreField: r1->field_7 = d0
    //     0x6d0d78: stur            d0, [x1, #7]
    // 0x6d0d7c: d0 = 36.000000
    //     0x6d0d7c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0x6d0d80: ldr             d0, [x17, #0xfa8]
    // 0x6d0d84: StoreField: r1->field_f = d0
    //     0x6d0d84: stur            d0, [x1, #0xf]
    // 0x6d0d88: r0 = Instance_ButtonBarLayoutBehavior
    //     0x6d0d88: add             x0, PP, #0xc, lsl #12  ; [pp+0xcfb0] Obj!ButtonBarLayoutBehavior@b65931
    //     0x6d0d8c: ldr             x0, [x0, #0xfb0]
    // 0x6d0d90: StoreField: r1->field_1b = r0
    //     0x6d0d90: stur            w0, [x1, #0x1b]
    // 0x6d0d94: r0 = false
    //     0x6d0d94: add             x0, NULL, #0x30  ; false
    // 0x6d0d98: StoreField: r1->field_27 = r0
    //     0x6d0d98: stur            w0, [x1, #0x27]
    // 0x6d0d9c: ldur            x0, [fp, #-0x70]
    // 0x6d0da0: StoreField: r1->field_43 = r0
    //     0x6d0da0: stur            w0, [x1, #0x43]
    // 0x6d0da4: r17 = -296
    //     0x6d0da4: mov             x17, #-0x128
    // 0x6d0da8: ldr             x2, [fp, x17]
    // 0x6d0dac: StoreField: r1->field_2b = r2
    //     0x6d0dac: stur            w2, [x1, #0x2b]
    // 0x6d0db0: ldur            x2, [fp, #-0x100]
    // 0x6d0db4: StoreField: r1->field_33 = r2
    //     0x6d0db4: stur            w2, [x1, #0x33]
    // 0x6d0db8: r17 = -264
    //     0x6d0db8: mov             x17, #-0x108
    // 0x6d0dbc: ldr             x3, [fp, x17]
    // 0x6d0dc0: StoreField: r1->field_37 = r3
    //     0x6d0dc0: stur            w3, [x1, #0x37]
    // 0x6d0dc4: ldur            x4, [fp, #-0x10]
    // 0x6d0dc8: StoreField: r1->field_3f = r4
    //     0x6d0dc8: stur            w4, [x1, #0x3f]
    // 0x6d0dcc: ldur            x5, [fp, #-0x48]
    // 0x6d0dd0: StoreField: r1->field_47 = r5
    //     0x6d0dd0: stur            w5, [x1, #0x47]
    // 0x6d0dd4: ldur            x6, [fp, #-0x68]
    // 0x6d0dd8: tbnz            w6, #4, #0x6d0de8
    // 0x6d0ddc: r7 = Instance_Color
    //     0x6d0ddc: add             x7, PP, #0xc, lsl #12  ; [pp+0xcfb8] Obj!Color@b5d231
    //     0x6d0de0: ldr             x7, [x7, #0xfb8]
    // 0x6d0de4: b               #0x6d0df0
    // 0x6d0de8: r7 = Instance_Color
    //     0x6d0de8: add             x7, PP, #0xc, lsl #12  ; [pp+0xcfc0] Obj!Color@b5d221
    //     0x6d0dec: ldr             x7, [x7, #0xfc0]
    // 0x6d0df0: r17 = -304
    //     0x6d0df0: mov             x17, #-0x130
    // 0x6d0df4: str             x7, [fp, x17]
    // 0x6d0df8: tbnz            w6, #4, #0x6d0e08
    // 0x6d0dfc: r8 = Instance_Color
    //     0x6d0dfc: add             x8, PP, #0xc, lsl #12  ; [pp+0xcfc8] Obj!Color@b5d211
    //     0x6d0e00: ldr             x8, [x8, #0xfc8]
    // 0x6d0e04: b               #0x6d0e10
    // 0x6d0e08: r8 = Instance_Color
    //     0x6d0e08: add             x8, PP, #0xc, lsl #12  ; [pp+0xcfd0] Obj!Color@b5d201
    //     0x6d0e0c: ldr             x8, [x8, #0xfd0]
    // 0x6d0e10: r17 = -296
    //     0x6d0e10: mov             x17, #-0x128
    // 0x6d0e14: str             x8, [fp, x17]
    // 0x6d0e18: cmp             w4, NULL
    // 0x6d0e1c: b.ne            #0x6d0e40
    // 0x6d0e20: tbnz            w6, #4, #0x6d0e30
    // 0x6d0e24: r4 = Instance_Color
    //     0x6d0e24: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfc8] Obj!Color@b5d211
    //     0x6d0e28: ldr             x4, [x4, #0xfc8]
    // 0x6d0e2c: b               #0x6d0e38
    // 0x6d0e30: r4 = Instance_Color
    //     0x6d0e30: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfd8] Obj!Color@b5d1f1
    //     0x6d0e34: ldr             x4, [x4, #0xfd8]
    // 0x6d0e38: mov             x9, x4
    // 0x6d0e3c: b               #0x6d0e44
    // 0x6d0e40: mov             x9, x4
    // 0x6d0e44: ldur            x4, [fp, #-0x80]
    // 0x6d0e48: stur            x9, [fp, #-0x10]
    // 0x6d0e4c: tbnz            w4, #4, #0x6d0e6c
    // 0x6d0e50: stp             x0, NULL, [SP, #-0x10]!
    // 0x6d0e54: ldur            x16, [fp, #-0x50]
    // 0x6d0e58: SaveReg r16
    //     0x6d0e58: str             x16, [SP, #-8]!
    // 0x6d0e5c: r0 = Typography.material2021()
    //     0x6d0e5c: bl              #0x6d1988  ; [package:flutter/src/material/typography.dart] Typography::Typography.material2021
    // 0x6d0e60: add             SP, SP, #0x18
    // 0x6d0e64: mov             x1, x0
    // 0x6d0e68: b               #0x6d0e80
    // 0x6d0e6c: ldur            x16, [fp, #-0x50]
    // 0x6d0e70: stp             x16, NULL, [SP, #-0x10]!
    // 0x6d0e74: r0 = Typography.material2014()
    //     0x6d0e74: bl              #0x6d17d4  ; [package:flutter/src/material/typography.dart] Typography::Typography.material2014
    // 0x6d0e78: add             SP, SP, #0x10
    // 0x6d0e7c: mov             x1, x0
    // 0x6d0e80: ldur            x0, [fp, #-0x68]
    // 0x6d0e84: r17 = -360
    //     0x6d0e84: mov             x17, #-0x168
    // 0x6d0e88: str             x1, [fp, x17]
    // 0x6d0e8c: tbnz            w0, #4, #0x6d0ea0
    // 0x6d0e90: LoadField: r2 = r1->field_b
    //     0x6d0e90: ldur            w2, [x1, #0xb]
    // 0x6d0e94: DecompressPointer r2
    //     0x6d0e94: add             x2, x2, HEAP, lsl #32
    // 0x6d0e98: mov             x3, x2
    // 0x6d0e9c: b               #0x6d0eac
    // 0x6d0ea0: LoadField: r2 = r1->field_7
    //     0x6d0ea0: ldur            w2, [x1, #7]
    // 0x6d0ea4: DecompressPointer r2
    //     0x6d0ea4: add             x2, x2, HEAP, lsl #32
    // 0x6d0ea8: mov             x3, x2
    // 0x6d0eac: ldur            x2, [fp, #-0xe0]
    // 0x6d0eb0: r17 = -352
    //     0x6d0eb0: mov             x17, #-0x160
    // 0x6d0eb4: str             x3, [fp, x17]
    // 0x6d0eb8: tbnz            w2, #4, #0x6d0ecc
    // 0x6d0ebc: LoadField: r4 = r1->field_b
    //     0x6d0ebc: ldur            w4, [x1, #0xb]
    // 0x6d0ec0: DecompressPointer r4
    //     0x6d0ec0: add             x4, x4, HEAP, lsl #32
    // 0x6d0ec4: mov             x5, x4
    // 0x6d0ec8: b               #0x6d0ed8
    // 0x6d0ecc: LoadField: r4 = r1->field_7
    //     0x6d0ecc: ldur            w4, [x1, #7]
    // 0x6d0ed0: DecompressPointer r4
    //     0x6d0ed0: add             x4, x4, HEAP, lsl #32
    // 0x6d0ed4: mov             x5, x4
    // 0x6d0ed8: ldur            x4, [fp, #-0x28]
    // 0x6d0edc: r17 = -344
    //     0x6d0edc: mov             x17, #-0x158
    // 0x6d0ee0: str             x5, [fp, x17]
    // 0x6d0ee4: tbnz            w4, #4, #0x6d0ef4
    // 0x6d0ee8: LoadField: r6 = r1->field_b
    //     0x6d0ee8: ldur            w6, [x1, #0xb]
    // 0x6d0eec: DecompressPointer r6
    //     0x6d0eec: add             x6, x6, HEAP, lsl #32
    // 0x6d0ef0: b               #0x6d0efc
    // 0x6d0ef4: LoadField: r6 = r1->field_7
    //     0x6d0ef4: ldur            w6, [x1, #7]
    // 0x6d0ef8: DecompressPointer r6
    //     0x6d0ef8: add             x6, x6, HEAP, lsl #32
    // 0x6d0efc: r17 = -336
    //     0x6d0efc: mov             x17, #-0x150
    // 0x6d0f00: str             x6, [fp, x17]
    // 0x6d0f04: tbnz            w0, #4, #0x6d0f14
    // 0x6d0f08: r7 = Instance_IconThemeData
    //     0x6d0f08: add             x7, PP, #0xc, lsl #12  ; [pp+0xcfe0] Obj!IconThemeData@b48c51
    //     0x6d0f0c: ldr             x7, [x7, #0xfe0]
    // 0x6d0f10: b               #0x6d0f1c
    // 0x6d0f14: r7 = Instance_IconThemeData
    //     0x6d0f14: add             x7, PP, #0xc, lsl #12  ; [pp+0xcfe8] Obj!IconThemeData@b48c21
    //     0x6d0f18: ldr             x7, [x7, #0xfe8]
    // 0x6d0f1c: r17 = -328
    //     0x6d0f1c: mov             x17, #-0x148
    // 0x6d0f20: str             x7, [fp, x17]
    // 0x6d0f24: tbnz            w2, #4, #0x6d0f34
    // 0x6d0f28: r8 = Instance_IconThemeData
    //     0x6d0f28: add             x8, PP, #0xc, lsl #12  ; [pp+0xcfe0] Obj!IconThemeData@b48c51
    //     0x6d0f2c: ldr             x8, [x8, #0xfe0]
    // 0x6d0f30: b               #0x6d0f3c
    // 0x6d0f34: r8 = Instance_IconThemeData
    //     0x6d0f34: add             x8, PP, #0xc, lsl #12  ; [pp+0xcff0] Obj!IconThemeData@b48bf1
    //     0x6d0f38: ldr             x8, [x8, #0xff0]
    // 0x6d0f3c: ldur            x2, [fp, #-0x30]
    // 0x6d0f40: r17 = -320
    //     0x6d0f40: mov             x17, #-0x140
    // 0x6d0f44: str             x8, [fp, x17]
    // 0x6d0f48: cmp             w2, NULL
    // 0x6d0f4c: b.ne            #0x6d0f5c
    // 0x6d0f50: r9 = Instance_AppBarTheme
    //     0x6d0f50: add             x9, PP, #0xc, lsl #12  ; [pp+0xcff8] Obj!AppBarTheme@b48b51
    //     0x6d0f54: ldr             x9, [x9, #0xff8]
    // 0x6d0f58: b               #0x6d0f60
    // 0x6d0f5c: mov             x9, x2
    // 0x6d0f60: ldur            x2, [fp, #-8]
    // 0x6d0f64: stur            x9, [fp, #-0xe0]
    // 0x6d0f68: cmp             w2, NULL
    // 0x6d0f6c: b.ne            #0x6d0f78
    // 0x6d0f70: r2 = Instance_TabBarTheme
    //     0x6d0f70: add             x2, PP, #0xd, lsl #12  ; [pp+0xd000] Obj!TabBarTheme@b3c681
    //     0x6d0f74: ldr             x2, [x2]
    // 0x6d0f78: stur            x2, [fp, #-0x30]
    // 0x6d0f7c: tbnz            w4, #4, #0x6d0f8c
    // 0x6d0f80: r4 = Instance_IconThemeData
    //     0x6d0f80: add             x4, PP, #0xc, lsl #12  ; [pp+0xcfe0] Obj!IconThemeData@b48c51
    //     0x6d0f84: ldr             x4, [x4, #0xfe0]
    // 0x6d0f88: b               #0x6d0f94
    // 0x6d0f8c: r4 = Instance_IconThemeData
    //     0x6d0f8c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcff0] Obj!IconThemeData@b48bf1
    //     0x6d0f90: ldr             x4, [x4, #0xff0]
    // 0x6d0f94: stur            x4, [fp, #-8]
    // 0x6d0f98: tbnz            w0, #4, #0x6d0fc4
    // 0x6d0f9c: r16 = _ConstMap len:10
    //     0x6d0f9c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d0fa0: ldr             x16, [x16, #0xf30]
    // 0x6d0fa4: r30 = 1200
    //     0x6d0fa4: mov             lr, #0x4b0
    // 0x6d0fa8: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0fac: r0 = []()
    //     0x6d0fac: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0fb0: add             SP, SP, #0x10
    // 0x6d0fb4: cmp             w0, NULL
    // 0x6d0fb8: b.eq            #0x6d15d4
    // 0x6d0fbc: mov             x1, x0
    // 0x6d0fc0: b               #0x6d0fe8
    // 0x6d0fc4: r16 = _ConstMap len:12
    //     0x6d0fc4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d0fc8: ldr             x16, [x16, #0xf20]
    // 0x6d0fcc: r30 = 600
    //     0x6d0fcc: mov             lr, #0x258
    // 0x6d0fd0: stp             lr, x16, [SP, #-0x10]!
    // 0x6d0fd4: r0 = []()
    //     0x6d0fd4: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d0fd8: add             SP, SP, #0x10
    // 0x6d0fdc: cmp             w0, NULL
    // 0x6d0fe0: b.eq            #0x6d15d8
    // 0x6d0fe4: mov             x1, x0
    // 0x6d0fe8: ldur            x0, [fp, #-0xb0]
    // 0x6d0fec: stur            x1, [fp, #-0x28]
    // 0x6d0ff0: cmp             w0, NULL
    // 0x6d0ff4: b.ne            #0x6d1020
    // 0x6d0ff8: r16 = _ConstMap len:10
    //     0x6d0ff8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf68] Map<int, Color>(10)
    //     0x6d0ffc: ldr             x16, [x16, #0xf68]
    // 0x6d1000: r30 = 1400
    //     0x6d1000: mov             lr, #0x578
    // 0x6d1004: stp             lr, x16, [SP, #-0x10]!
    // 0x6d1008: r0 = []()
    //     0x6d1008: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d100c: add             SP, SP, #0x10
    // 0x6d1010: cmp             w0, NULL
    // 0x6d1014: b.eq            #0x6d15dc
    // 0x6d1018: mov             x1, x0
    // 0x6d101c: b               #0x6d1024
    // 0x6d1020: mov             x1, x0
    // 0x6d1024: ldur            x0, [fp, #-0x38]
    // 0x6d1028: stur            x1, [fp, #-0xb0]
    // 0x6d102c: cmp             w0, NULL
    // 0x6d1030: b.ne            #0x6d1088
    // 0x6d1034: ldur            x0, [fp, #-0x68]
    // 0x6d1038: tbnz            w0, #4, #0x6d1060
    // 0x6d103c: r16 = _ConstMap len:12
    //     0x6d103c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d1040: ldr             x16, [x16, #0xf20]
    // 0x6d1044: r30 = 1400
    //     0x6d1044: mov             lr, #0x578
    // 0x6d1048: stp             lr, x16, [SP, #-0x10]!
    // 0x6d104c: r0 = []()
    //     0x6d104c: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d1050: add             SP, SP, #0x10
    // 0x6d1054: cmp             w0, NULL
    // 0x6d1058: b.eq            #0x6d15e0
    // 0x6d105c: b               #0x6d1080
    // 0x6d1060: r16 = _ConstMap len:10
    //     0x6d1060: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf30] Map<int, Color>(10)
    //     0x6d1064: ldr             x16, [x16, #0xf30]
    // 0x6d1068: r30 = 400
    //     0x6d1068: mov             lr, #0x190
    // 0x6d106c: stp             lr, x16, [SP, #-0x10]!
    // 0x6d1070: r0 = []()
    //     0x6d1070: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d1074: add             SP, SP, #0x10
    // 0x6d1078: cmp             w0, NULL
    // 0x6d107c: b.eq            #0x6d15e4
    // 0x6d1080: mov             x1, x0
    // 0x6d1084: b               #0x6d108c
    // 0x6d1088: mov             x1, x0
    // 0x6d108c: ldur            x0, [fp, #-0x58]
    // 0x6d1090: stur            x1, [fp, #-0x38]
    // 0x6d1094: cmp             w0, NULL
    // 0x6d1098: b.ne            #0x6d10d8
    // 0x6d109c: ldur            x0, [fp, #-0x68]
    // 0x6d10a0: tbnz            w0, #4, #0x6d10c8
    // 0x6d10a4: r16 = _ConstMap len:12
    //     0x6d10a4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d10a8: ldr             x16, [x16, #0xf20]
    // 0x6d10ac: r30 = 1600
    //     0x6d10ac: mov             lr, #0x640
    // 0x6d10b0: stp             lr, x16, [SP, #-0x10]!
    // 0x6d10b4: r0 = []()
    //     0x6d10b4: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d10b8: add             SP, SP, #0x10
    // 0x6d10bc: cmp             w0, NULL
    // 0x6d10c0: b.eq            #0x6d15e8
    // 0x6d10c4: b               #0x6d10d0
    // 0x6d10c8: r0 = Instance_Color
    //     0x6d10c8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d10cc: ldr             x0, [x0, #0xbe8]
    // 0x6d10d0: stur            x0, [fp, #-0x58]
    // 0x6d10d4: b               #0x6d10dc
    // 0x6d10d8: stur            x0, [fp, #-0x58]
    // 0x6d10dc: ldur            x20, [fp, #-0x48]
    // 0x6d10e0: ldur            x25, [fp, #-0x80]
    // 0x6d10e4: ldur            x14, [fp, #-0x100]
    // 0x6d10e8: r17 = -264
    //     0x6d10e8: mov             x17, #-0x108
    // 0x6d10ec: ldr             x19, [fp, x17]
    // 0x6d10f0: ldur            x13, [fp, #-0x70]
    // 0x6d10f4: r17 = -312
    //     0x6d10f4: mov             x17, #-0x138
    // 0x6d10f8: ldr             x12, [fp, x17]
    // 0x6d10fc: r17 = -304
    //     0x6d10fc: mov             x17, #-0x130
    // 0x6d1100: ldr             x23, [fp, x17]
    // 0x6d1104: r17 = -296
    //     0x6d1104: mov             x17, #-0x128
    // 0x6d1108: ldr             x24, [fp, x17]
    // 0x6d110c: r17 = -360
    //     0x6d110c: mov             x17, #-0x168
    // 0x6d1110: ldr             x3, [fp, x17]
    // 0x6d1114: r17 = -352
    //     0x6d1114: mov             x17, #-0x160
    // 0x6d1118: ldr             x4, [fp, x17]
    // 0x6d111c: r17 = -344
    //     0x6d111c: mov             x17, #-0x158
    // 0x6d1120: ldr             x5, [fp, x17]
    // 0x6d1124: r17 = -336
    //     0x6d1124: mov             x17, #-0x150
    // 0x6d1128: ldr             x6, [fp, x17]
    // 0x6d112c: r17 = -328
    //     0x6d112c: mov             x17, #-0x148
    // 0x6d1130: ldr             x7, [fp, x17]
    // 0x6d1134: r17 = -320
    //     0x6d1134: mov             x17, #-0x140
    // 0x6d1138: ldr             x8, [fp, x17]
    // 0x6d113c: ldur            x9, [fp, #-0xe0]
    // 0x6d1140: ldur            x10, [fp, #-0x30]
    // 0x6d1144: ldur            x11, [fp, #-8]
    // 0x6d1148: ldur            x2, [fp, #-0x28]
    // 0x6d114c: ldur            x1, [fp, #-0xb0]
    // 0x6d1150: ldur            x0, [fp, #-0x38]
    // 0x6d1154: ldur            x16, [fp, #-0x40]
    // 0x6d1158: SaveReg r16
    //     0x6d1158: str             x16, [SP, #-8]!
    // 0x6d115c: r0 = _themeExtensionIterableToMap()
    //     0x6d115c: bl              #0x6d15ec  ; [package:flutter/src/material/theme_data.dart] ThemeData::_themeExtensionIterableToMap
    // 0x6d1160: add             SP, SP, #8
    // 0x6d1164: stur            x0, [fp, #-0x40]
    // 0x6d1168: r0 = ThemeData()
    //     0x6d1168: bl              #0x6cd128  ; AllocateThemeDataStub -> ThemeData (size=0x170)
    // 0x6d116c: ldur            x1, [fp, #-0x18]
    // 0x6d1170: StoreField: r0->field_7 = r1
    //     0x6d1170: stur            w1, [x0, #7]
    // 0x6d1174: ldur            x1, [fp, #-0x40]
    // 0x6d1178: StoreField: r0->field_f = r1
    //     0x6d1178: stur            w1, [x0, #0xf]
    // 0x6d117c: r1 = Instance_InputDecorationTheme
    //     0x6d117c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd008] Obj!InputDecorationTheme@b48581
    //     0x6d1180: ldr             x1, [x1, #8]
    // 0x6d1184: StoreField: r0->field_13 = r1
    //     0x6d1184: stur            w1, [x0, #0x13]
    // 0x6d1188: ldur            x1, [fp, #-0x48]
    // 0x6d118c: StoreField: r0->field_17 = r1
    //     0x6d118c: stur            w1, [x0, #0x17]
    // 0x6d1190: r1 = Instance_PageTransitionsTheme
    //     0x6d1190: add             x1, PP, #0xd, lsl #12  ; [pp+0xd010] Obj!PageTransitionsTheme@b3ceb1
    //     0x6d1194: ldr             x1, [x1, #0x10]
    // 0x6d1198: StoreField: r0->field_1b = r1
    //     0x6d1198: stur            w1, [x0, #0x1b]
    // 0x6d119c: ldur            x1, [fp, #-0x50]
    // 0x6d11a0: StoreField: r0->field_1f = r1
    //     0x6d11a0: stur            w1, [x0, #0x1f]
    // 0x6d11a4: r1 = Instance_ScrollbarThemeData
    //     0x6d11a4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd018] Obj!ScrollbarThemeData@b3ce01
    //     0x6d11a8: ldr             x1, [x1, #0x18]
    // 0x6d11ac: StoreField: r0->field_23 = r1
    //     0x6d11ac: stur            w1, [x0, #0x23]
    // 0x6d11b0: ldur            x1, [fp, #-0x78]
    // 0x6d11b4: StoreField: r0->field_27 = r1
    //     0x6d11b4: stur            w1, [x0, #0x27]
    // 0x6d11b8: ldur            x1, [fp, #-0x80]
    // 0x6d11bc: StoreField: r0->field_2b = r1
    //     0x6d11bc: stur            w1, [x0, #0x2b]
    // 0x6d11c0: ldur            x1, [fp, #-0x88]
    // 0x6d11c4: StoreField: r0->field_2f = r1
    //     0x6d11c4: stur            w1, [x0, #0x2f]
    // 0x6d11c8: r17 = -272
    //     0x6d11c8: mov             x17, #-0x110
    // 0x6d11cc: ldr             x1, [fp, x17]
    // 0x6d11d0: StoreField: r0->field_37 = r1
    //     0x6d11d0: stur            w1, [x0, #0x37]
    // 0x6d11d4: ldur            x1, [fp, #-0xc0]
    // 0x6d11d8: StoreField: r0->field_3b = r1
    //     0x6d11d8: stur            w1, [x0, #0x3b]
    // 0x6d11dc: ldur            x1, [fp, #-0x70]
    // 0x6d11e0: StoreField: r0->field_3f = r1
    //     0x6d11e0: stur            w1, [x0, #0x3f]
    // 0x6d11e4: r17 = -288
    //     0x6d11e4: mov             x17, #-0x120
    // 0x6d11e8: ldr             x1, [fp, x17]
    // 0x6d11ec: StoreField: r0->field_43 = r1
    //     0x6d11ec: stur            w1, [x0, #0x43]
    // 0x6d11f0: r17 = -304
    //     0x6d11f0: mov             x17, #-0x130
    // 0x6d11f4: ldr             x1, [fp, x17]
    // 0x6d11f8: StoreField: r0->field_47 = r1
    //     0x6d11f8: stur            w1, [x0, #0x47]
    // 0x6d11fc: ldur            x1, [fp, #-0x90]
    // 0x6d1200: StoreField: r0->field_4b = r1
    //     0x6d1200: stur            w1, [x0, #0x4b]
    // 0x6d1204: ldur            x1, [fp, #-0x100]
    // 0x6d1208: StoreField: r0->field_4f = r1
    //     0x6d1208: stur            w1, [x0, #0x4f]
    // 0x6d120c: r17 = -296
    //     0x6d120c: mov             x17, #-0x128
    // 0x6d1210: ldr             x1, [fp, x17]
    // 0x6d1214: StoreField: r0->field_53 = r1
    //     0x6d1214: stur            w1, [x0, #0x53]
    // 0x6d1218: ldur            x1, [fp, #-0xb8]
    // 0x6d121c: StoreField: r0->field_57 = r1
    //     0x6d121c: stur            w1, [x0, #0x57]
    // 0x6d1220: r17 = -264
    //     0x6d1220: mov             x17, #-0x108
    // 0x6d1224: ldr             x1, [fp, x17]
    // 0x6d1228: StoreField: r0->field_5b = r1
    //     0x6d1228: stur            w1, [x0, #0x5b]
    // 0x6d122c: ldur            x1, [fp, #-0xa0]
    // 0x6d1230: StoreField: r0->field_5f = r1
    //     0x6d1230: stur            w1, [x0, #0x5f]
    // 0x6d1234: ldur            x1, [fp, #-0xc8]
    // 0x6d1238: StoreField: r0->field_63 = r1
    //     0x6d1238: stur            w1, [x0, #0x63]
    // 0x6d123c: ldur            x1, [fp, #-0xe8]
    // 0x6d1240: StoreField: r0->field_67 = r1
    //     0x6d1240: stur            w1, [x0, #0x67]
    // 0x6d1244: ldur            x1, [fp, #-0xd8]
    // 0x6d1248: StoreField: r0->field_6b = r1
    //     0x6d1248: stur            w1, [x0, #0x6b]
    // 0x6d124c: ldur            x1, [fp, #-0x60]
    // 0x6d1250: StoreField: r0->field_6f = r1
    //     0x6d1250: stur            w1, [x0, #0x6f]
    // 0x6d1254: r17 = -280
    //     0x6d1254: mov             x17, #-0x118
    // 0x6d1258: ldr             x1, [fp, x17]
    // 0x6d125c: StoreField: r0->field_73 = r1
    //     0x6d125c: stur            w1, [x0, #0x73]
    // 0x6d1260: r1 = Instance_Color
    //     0x6d1260: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d1264: ldr             x1, [x1, #0xf38]
    // 0x6d1268: StoreField: r0->field_7b = r1
    //     0x6d1268: stur            w1, [x0, #0x7b]
    // 0x6d126c: ldur            x1, [fp, #-0x10]
    // 0x6d1270: StoreField: r0->field_7f = r1
    //     0x6d1270: stur            w1, [x0, #0x7f]
    // 0x6d1274: ldur            x1, [fp, #-0x98]
    // 0x6d1278: StoreField: r0->field_83 = r1
    //     0x6d1278: stur            w1, [x0, #0x83]
    // 0x6d127c: r17 = -328
    //     0x6d127c: mov             x17, #-0x148
    // 0x6d1280: ldr             x1, [fp, x17]
    // 0x6d1284: StoreField: r0->field_87 = r1
    //     0x6d1284: stur            w1, [x0, #0x87]
    // 0x6d1288: r17 = -320
    //     0x6d1288: mov             x17, #-0x140
    // 0x6d128c: ldr             x1, [fp, x17]
    // 0x6d1290: StoreField: r0->field_8b = r1
    //     0x6d1290: stur            w1, [x0, #0x8b]
    // 0x6d1294: r17 = -344
    //     0x6d1294: mov             x17, #-0x158
    // 0x6d1298: ldr             x1, [fp, x17]
    // 0x6d129c: StoreField: r0->field_8f = r1
    //     0x6d129c: stur            w1, [x0, #0x8f]
    // 0x6d12a0: r17 = -352
    //     0x6d12a0: mov             x17, #-0x160
    // 0x6d12a4: ldr             x1, [fp, x17]
    // 0x6d12a8: StoreField: r0->field_93 = r1
    //     0x6d12a8: stur            w1, [x0, #0x93]
    // 0x6d12ac: r17 = -360
    //     0x6d12ac: mov             x17, #-0x168
    // 0x6d12b0: ldr             x1, [fp, x17]
    // 0x6d12b4: StoreField: r0->field_97 = r1
    //     0x6d12b4: stur            w1, [x0, #0x97]
    // 0x6d12b8: ldur            x1, [fp, #-0xe0]
    // 0x6d12bc: StoreField: r0->field_9b = r1
    //     0x6d12bc: stur            w1, [x0, #0x9b]
    // 0x6d12c0: r1 = Instance_BadgeThemeData
    //     0x6d12c0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd020] Obj!BadgeThemeData@b48b21
    //     0x6d12c4: ldr             x1, [x1, #0x20]
    // 0x6d12c8: StoreField: r0->field_9f = r1
    //     0x6d12c8: stur            w1, [x0, #0x9f]
    // 0x6d12cc: r1 = Instance_MaterialBannerThemeData
    //     0x6d12cc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd028] Obj!MaterialBannerThemeData@b48af1
    //     0x6d12d0: ldr             x1, [x1, #0x28]
    // 0x6d12d4: StoreField: r0->field_a3 = r1
    //     0x6d12d4: stur            w1, [x0, #0xa3]
    // 0x6d12d8: r1 = Instance_BottomAppBarTheme
    //     0x6d12d8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd030] Obj!BottomAppBarTheme@b48ad1
    //     0x6d12dc: ldr             x1, [x1, #0x30]
    // 0x6d12e0: StoreField: r0->field_a7 = r1
    //     0x6d12e0: stur            w1, [x0, #0xa7]
    // 0x6d12e4: r1 = Instance_BottomNavigationBarThemeData
    //     0x6d12e4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd038] Obj!BottomNavigationBarThemeData@b48a91
    //     0x6d12e8: ldr             x1, [x1, #0x38]
    // 0x6d12ec: StoreField: r0->field_ab = r1
    //     0x6d12ec: stur            w1, [x0, #0xab]
    // 0x6d12f0: r1 = Instance_BottomSheetThemeData
    //     0x6d12f0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd040] Obj!BottomSheetThemeData@b48a61
    //     0x6d12f4: ldr             x1, [x1, #0x40]
    // 0x6d12f8: StoreField: r0->field_af = r1
    //     0x6d12f8: stur            w1, [x0, #0xaf]
    // 0x6d12fc: r1 = Instance_ButtonBarThemeData
    //     0x6d12fc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd048] Obj!ButtonBarThemeData@b48a31
    //     0x6d1300: ldr             x1, [x1, #0x48]
    // 0x6d1304: StoreField: r0->field_b3 = r1
    //     0x6d1304: stur            w1, [x0, #0xb3]
    // 0x6d1308: r17 = -312
    //     0x6d1308: mov             x17, #-0x138
    // 0x6d130c: ldr             x1, [fp, x17]
    // 0x6d1310: StoreField: r0->field_b7 = r1
    //     0x6d1310: stur            w1, [x0, #0xb7]
    // 0x6d1314: r1 = Instance_CardTheme
    //     0x6d1314: add             x1, PP, #0xd, lsl #12  ; [pp+0xd050] Obj!CardTheme@b48971
    //     0x6d1318: ldr             x1, [x1, #0x50]
    // 0x6d131c: StoreField: r0->field_bb = r1
    //     0x6d131c: stur            w1, [x0, #0xbb]
    // 0x6d1320: r1 = Instance_CheckboxThemeData
    //     0x6d1320: add             x1, PP, #0xd, lsl #12  ; [pp+0xd058] Obj!CheckboxThemeData@b48941
    //     0x6d1324: ldr             x1, [x1, #0x58]
    // 0x6d1328: StoreField: r0->field_bf = r1
    //     0x6d1328: stur            w1, [x0, #0xbf]
    // 0x6d132c: r1 = Instance_ChipThemeData
    //     0x6d132c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd060] Obj!ChipThemeData@b488e1
    //     0x6d1330: ldr             x1, [x1, #0x60]
    // 0x6d1334: StoreField: r0->field_c3 = r1
    //     0x6d1334: stur            w1, [x0, #0xc3]
    // 0x6d1338: r1 = Instance_DataTableThemeData
    //     0x6d1338: add             x1, PP, #0xd, lsl #12  ; [pp+0xd068] Obj!DataTableThemeData@b48781
    //     0x6d133c: ldr             x1, [x1, #0x68]
    // 0x6d1340: StoreField: r0->field_c7 = r1
    //     0x6d1340: stur            w1, [x0, #0xc7]
    // 0x6d1344: r1 = Instance_DialogTheme
    //     0x6d1344: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] Obj!DialogTheme@b48751
    //     0x6d1348: ldr             x1, [x1, #0x70]
    // 0x6d134c: StoreField: r0->field_cb = r1
    //     0x6d134c: stur            w1, [x0, #0xcb]
    // 0x6d1350: r1 = Instance_DividerThemeData
    //     0x6d1350: add             x1, PP, #0xd, lsl #12  ; [pp+0xd078] Obj!DividerThemeData@b48731
    //     0x6d1354: ldr             x1, [x1, #0x78]
    // 0x6d1358: StoreField: r0->field_cf = r1
    //     0x6d1358: stur            w1, [x0, #0xcf]
    // 0x6d135c: r1 = Instance_DrawerThemeData
    //     0x6d135c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd080] Obj!DrawerThemeData@b48701
    //     0x6d1360: ldr             x1, [x1, #0x80]
    // 0x6d1364: StoreField: r0->field_d3 = r1
    //     0x6d1364: stur            w1, [x0, #0xd3]
    // 0x6d1368: r1 = Instance_DropdownMenuThemeData
    //     0x6d1368: add             x1, PP, #0xd, lsl #12  ; [pp+0xd088] Obj!DropdownMenuThemeData@b486e1
    //     0x6d136c: ldr             x1, [x1, #0x88]
    // 0x6d1370: StoreField: r0->field_d7 = r1
    //     0x6d1370: stur            w1, [x0, #0xd7]
    // 0x6d1374: r1 = Instance_ElevatedButtonThemeData
    //     0x6d1374: add             x1, PP, #0xd, lsl #12  ; [pp+0xd090] Obj!ElevatedButtonThemeData@b486d1
    //     0x6d1378: ldr             x1, [x1, #0x90]
    // 0x6d137c: StoreField: r0->field_db = r1
    //     0x6d137c: stur            w1, [x0, #0xdb]
    // 0x6d1380: r1 = Instance_ExpansionTileThemeData
    //     0x6d1380: add             x1, PP, #0xd, lsl #12  ; [pp+0xd098] Obj!ExpansionTileThemeData@b48691
    //     0x6d1384: ldr             x1, [x1, #0x98]
    // 0x6d1388: StoreField: r0->field_df = r1
    //     0x6d1388: stur            w1, [x0, #0xdf]
    // 0x6d138c: r1 = Instance_FilledButtonThemeData
    //     0x6d138c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0a0] Obj!FilledButtonThemeData@b48681
    //     0x6d1390: ldr             x1, [x1, #0xa0]
    // 0x6d1394: StoreField: r0->field_e3 = r1
    //     0x6d1394: stur            w1, [x0, #0xe3]
    // 0x6d1398: r1 = Instance_FloatingActionButtonThemeData
    //     0x6d1398: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0a8] Obj!FloatingActionButtonThemeData@b48621
    //     0x6d139c: ldr             x1, [x1, #0xa8]
    // 0x6d13a0: StoreField: r0->field_e7 = r1
    //     0x6d13a0: stur            w1, [x0, #0xe7]
    // 0x6d13a4: r1 = Instance_IconButtonThemeData
    //     0x6d13a4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0b0] Obj!IconButtonThemeData@b48611
    //     0x6d13a8: ldr             x1, [x1, #0xb0]
    // 0x6d13ac: StoreField: r0->field_eb = r1
    //     0x6d13ac: stur            w1, [x0, #0xeb]
    // 0x6d13b0: r1 = Instance_ListTileThemeData
    //     0x6d13b0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0b8] Obj!ListTileThemeData@b48531
    //     0x6d13b4: ldr             x1, [x1, #0xb8]
    // 0x6d13b8: StoreField: r0->field_ef = r1
    //     0x6d13b8: stur            w1, [x0, #0xef]
    // 0x6d13bc: r1 = Instance_MenuBarThemeData
    //     0x6d13bc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0c0] Obj!MenuBarThemeData@b3cf91
    //     0x6d13c0: ldr             x1, [x1, #0xc0]
    // 0x6d13c4: StoreField: r0->field_f3 = r1
    //     0x6d13c4: stur            w1, [x0, #0xf3]
    // 0x6d13c8: r1 = Instance_MenuButtonThemeData
    //     0x6d13c8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0c8] Obj!MenuButtonThemeData@b3cf71
    //     0x6d13cc: ldr             x1, [x1, #0xc8]
    // 0x6d13d0: StoreField: r0->field_f7 = r1
    //     0x6d13d0: stur            w1, [x0, #0xf7]
    // 0x6d13d4: r1 = Instance_MenuThemeData
    //     0x6d13d4: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0d0] Obj!MenuThemeData@b3cf81
    //     0x6d13d8: ldr             x1, [x1, #0xd0]
    // 0x6d13dc: StoreField: r0->field_fb = r1
    //     0x6d13dc: stur            w1, [x0, #0xfb]
    // 0x6d13e0: r1 = Instance_NavigationBarThemeData
    //     0x6d13e0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0d8] Obj!NavigationBarThemeData@b3cf41
    //     0x6d13e4: ldr             x1, [x1, #0xd8]
    // 0x6d13e8: StoreField: r0->field_ff = r1
    //     0x6d13e8: stur            w1, [x0, #0xff]
    // 0x6d13ec: r1 = Instance_NavigationDrawerThemeData
    //     0x6d13ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0e0] Obj!NavigationDrawerThemeData@b3cf11
    //     0x6d13f0: ldr             x1, [x1, #0xe0]
    // 0x6d13f4: add             x16, x0, #0x103
    // 0x6d13f8: str             w1, [x16]
    // 0x6d13fc: r1 = Instance_NavigationRailThemeData
    //     0x6d13fc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0e8] Obj!NavigationRailThemeData@b3ced1
    //     0x6d1400: ldr             x1, [x1, #0xe8]
    // 0x6d1404: add             x16, x0, #0x107
    // 0x6d1408: str             w1, [x16]
    // 0x6d140c: r1 = Instance_OutlinedButtonThemeData
    //     0x6d140c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0f0] Obj!OutlinedButtonThemeData@b3cec1
    //     0x6d1410: ldr             x1, [x1, #0xf0]
    // 0x6d1414: add             x16, x0, #0x10b
    // 0x6d1418: str             w1, [x16]
    // 0x6d141c: r1 = Instance_PopupMenuThemeData
    //     0x6d141c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd0f8] Obj!PopupMenuThemeData@b3ce81
    //     0x6d1420: ldr             x1, [x1, #0xf8]
    // 0x6d1424: add             x16, x0, #0x10f
    // 0x6d1428: str             w1, [x16]
    // 0x6d142c: r1 = Instance_ProgressIndicatorThemeData
    //     0x6d142c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd100] Obj!ProgressIndicatorThemeData@b3ce61
    //     0x6d1430: ldr             x1, [x1, #0x100]
    // 0x6d1434: add             x16, x0, #0x113
    // 0x6d1438: str             w1, [x16]
    // 0x6d143c: r1 = Instance_RadioThemeData
    //     0x6d143c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd108] Obj!RadioThemeData@b3ce41
    //     0x6d1440: ldr             x1, [x1, #0x108]
    // 0x6d1444: add             x16, x0, #0x117
    // 0x6d1448: str             w1, [x16]
    // 0x6d144c: r1 = Instance_SegmentedButtonThemeData
    //     0x6d144c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd110] Obj!SegmentedButtonThemeData@b3cdf1
    //     0x6d1450: ldr             x1, [x1, #0x110]
    // 0x6d1454: add             x16, x0, #0x11b
    // 0x6d1458: str             w1, [x16]
    // 0x6d145c: r1 = Instance_SliderThemeData
    //     0x6d145c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd118] Obj!SliderThemeData@b3c731
    //     0x6d1460: ldr             x1, [x1, #0x118]
    // 0x6d1464: add             x16, x0, #0x11f
    // 0x6d1468: str             w1, [x16]
    // 0x6d146c: r1 = Instance_SnackBarThemeData
    //     0x6d146c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd120] Obj!SnackBarThemeData@b3c6f1
    //     0x6d1470: ldr             x1, [x1, #0x120]
    // 0x6d1474: add             x16, x0, #0x123
    // 0x6d1478: str             w1, [x16]
    // 0x6d147c: r1 = Instance_SwitchThemeData
    //     0x6d147c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd128] Obj!SwitchThemeData@b3c6c1
    //     0x6d1480: ldr             x1, [x1, #0x128]
    // 0x6d1484: add             x16, x0, #0x127
    // 0x6d1488: str             w1, [x16]
    // 0x6d148c: ldur            x1, [fp, #-0x30]
    // 0x6d1490: add             x16, x0, #0x12b
    // 0x6d1494: str             w1, [x16]
    // 0x6d1498: r1 = Instance_TextButtonThemeData
    //     0x6d1498: add             x1, PP, #0xd, lsl #12  ; [pp+0xd130] Obj!TextButtonThemeData@b3c671
    //     0x6d149c: ldr             x1, [x1, #0x130]
    // 0x6d14a0: add             x16, x0, #0x12f
    // 0x6d14a4: str             w1, [x16]
    // 0x6d14a8: r1 = Instance_TextSelectionThemeData
    //     0x6d14a8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd138] Obj!TextSelectionThemeData@b3c651
    //     0x6d14ac: ldr             x1, [x1, #0x138]
    // 0x6d14b0: add             x16, x0, #0x133
    // 0x6d14b4: str             w1, [x16]
    // 0x6d14b8: r1 = Instance_TimePickerThemeData
    //     0x6d14b8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd140] Obj!TimePickerThemeData@b3c0c1
    //     0x6d14bc: ldr             x1, [x1, #0x140]
    // 0x6d14c0: add             x16, x0, #0x137
    // 0x6d14c4: str             w1, [x16]
    // 0x6d14c8: r1 = Instance_ToggleButtonsThemeData
    //     0x6d14c8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd148] Obj!ToggleButtonsThemeData@b3c071
    //     0x6d14cc: ldr             x1, [x1, #0x148]
    // 0x6d14d0: add             x16, x0, #0x13b
    // 0x6d14d4: str             w1, [x16]
    // 0x6d14d8: r1 = Instance_TooltipThemeData
    //     0x6d14d8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd150] Obj!TooltipThemeData@b3c031
    //     0x6d14dc: ldr             x1, [x1, #0x150]
    // 0x6d14e0: add             x16, x0, #0x13f
    // 0x6d14e4: str             w1, [x16]
    // 0x6d14e8: ldur            x1, [fp, #-0x20]
    // 0x6d14ec: add             x16, x0, #0x143
    // 0x6d14f0: str             w1, [x16]
    // 0x6d14f4: ldur            x1, [fp, #-0xf8]
    // 0x6d14f8: add             x16, x0, #0x147
    // 0x6d14fc: str             w1, [x16]
    // 0x6d1500: r17 = -336
    //     0x6d1500: mov             x17, #-0x150
    // 0x6d1504: ldr             x1, [fp, x17]
    // 0x6d1508: add             x16, x0, #0x14b
    // 0x6d150c: str             w1, [x16]
    // 0x6d1510: ldur            x1, [fp, #-8]
    // 0x6d1514: add             x16, x0, #0x14f
    // 0x6d1518: str             w1, [x16]
    // 0x6d151c: ldur            x1, [fp, #-0x28]
    // 0x6d1520: add             x16, x0, #0x153
    // 0x6d1524: str             w1, [x16]
    // 0x6d1528: r1 = true
    //     0x6d1528: add             x1, NULL, #0x20  ; true
    // 0x6d152c: add             x16, x0, #0x157
    // 0x6d1530: str             w1, [x16]
    // 0x6d1534: ldur            x1, [fp, #-0xd0]
    // 0x6d1538: add             x16, x0, #0x15b
    // 0x6d153c: str             w1, [x16]
    // 0x6d1540: ldur            x1, [fp, #-0xf0]
    // 0x6d1544: add             x16, x0, #0x16b
    // 0x6d1548: str             w1, [x16]
    // 0x6d154c: ldur            x1, [fp, #-0xa8]
    // 0x6d1550: StoreField: r0->field_77 = r1
    //     0x6d1550: stur            w1, [x0, #0x77]
    // 0x6d1554: ldur            x1, [fp, #-0xb0]
    // 0x6d1558: add             x16, x0, #0x163
    // 0x6d155c: str             w1, [x16]
    // 0x6d1560: ldur            x1, [fp, #-0x38]
    // 0x6d1564: add             x16, x0, #0x167
    // 0x6d1568: str             w1, [x16]
    // 0x6d156c: ldur            x1, [fp, #-0x58]
    // 0x6d1570: StoreField: r0->field_33 = r1
    //     0x6d1570: stur            w1, [x0, #0x33]
    // 0x6d1574: LeaveFrame
    //     0x6d1574: mov             SP, fp
    //     0x6d1578: ldp             fp, lr, [SP], #0x10
    // 0x6d157c: ret
    //     0x6d157c: ret             
    // 0x6d1580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d1580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d1584: b               #0x6d02b8
    // 0x6d1588: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d1588: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d158c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d158c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d1590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d1590: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d1594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d1594: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d1598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d1598: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d159c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d159c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d15e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d15e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _themeExtensionIterableToMap(/* No info */) {
    // ** addr: 0x6d15ec, size: 0x170
    // 0x6d15ec: EnterFrame
    //     0x6d15ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6d15f0: mov             fp, SP
    // 0x6d15f4: AllocStack(0x18)
    //     0x6d15f4: sub             SP, SP, #0x18
    // 0x6d15f8: CheckStackOverflow
    //     0x6d15f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d15fc: cmp             SP, x16
    //     0x6d1600: b.ls            #0x6d1754
    // 0x6d1604: r16 = <Object, ThemeExtension<ThemeExtension>>
    //     0x6d1604: add             x16, PP, #0xd, lsl #12  ; [pp+0xd158] TypeArguments: <Object, ThemeExtension<ThemeExtension>>
    //     0x6d1608: ldr             x16, [x16, #0x158]
    // 0x6d160c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6d1610: stp             lr, x16, [SP, #-0x10]!
    // 0x6d1614: r0 = Map._fromLiteral()
    //     0x6d1614: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6d1618: add             SP, SP, #0x10
    // 0x6d161c: mov             x2, x0
    // 0x6d1620: ldr             x1, [fp, #0x10]
    // 0x6d1624: stur            x2, [fp, #-0x18]
    // 0x6d1628: LoadField: r3 = r1->field_7
    //     0x6d1628: ldur            w3, [x1, #7]
    // 0x6d162c: DecompressPointer r3
    //     0x6d162c: add             x3, x3, HEAP, lsl #32
    // 0x6d1630: stur            x3, [fp, #-0x10]
    // 0x6d1634: LoadField: r0 = r1->field_b
    //     0x6d1634: ldur            w0, [x1, #0xb]
    // 0x6d1638: DecompressPointer r0
    //     0x6d1638: add             x0, x0, HEAP, lsl #32
    // 0x6d163c: r4 = LoadInt32Instr(r0)
    //     0x6d163c: sbfx            x4, x0, #1, #0x1f
    // 0x6d1640: stur            x4, [fp, #-8]
    // 0x6d1644: r0 = LoadClassIdInstr(r1)
    //     0x6d1644: ldur            x0, [x1, #-1]
    //     0x6d1648: ubfx            x0, x0, #0xc, #0x14
    // 0x6d164c: SaveReg r1
    //     0x6d164c: str             x1, [SP, #-8]!
    // 0x6d1650: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6d1650: mov             x17, #0xb8ea
    //     0x6d1654: add             lr, x0, x17
    //     0x6d1658: ldr             lr, [x21, lr, lsl #3]
    //     0x6d165c: blr             lr
    // 0x6d1660: add             SP, SP, #8
    // 0x6d1664: r1 = LoadInt32Instr(r0)
    //     0x6d1664: sbfx            x1, x0, #1, #0x1f
    //     0x6d1668: tbz             w0, #0, #0x6d1670
    //     0x6d166c: ldur            x1, [x0, #7]
    // 0x6d1670: ldur            x0, [fp, #-8]
    // 0x6d1674: cmp             x0, x1
    // 0x6d1678: b.ne            #0x6d16fc
    // 0x6d167c: ldr             x0, [fp, #0x10]
    // 0x6d1680: cmp             x1, #0
    // 0x6d1684: b.gt            #0x6d16cc
    // 0x6d1688: r16 = <Object, ThemeExtension>
    //     0x6d1688: add             x16, PP, #0xd, lsl #12  ; [pp+0xd160] TypeArguments: <Object, ThemeExtension>
    //     0x6d168c: ldr             x16, [x16, #0x160]
    // 0x6d1690: ldur            lr, [fp, #-0x18]
    // 0x6d1694: stp             lr, x16, [SP, #-0x10]!
    // 0x6d1698: r0 = LinkedHashMap.from()
    //     0x6d1698: bl              #0x5428b8  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x6d169c: add             SP, SP, #0x10
    // 0x6d16a0: r1 = <Object, ThemeExtension>
    //     0x6d16a0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd160] TypeArguments: <Object, ThemeExtension>
    //     0x6d16a4: ldr             x1, [x1, #0x160]
    // 0x6d16a8: stur            x0, [fp, #-0x18]
    // 0x6d16ac: r0 = UnmodifiableMapView()
    //     0x6d16ac: bl              #0x52c824  ; AllocateUnmodifiableMapViewStub -> UnmodifiableMapView<X0, X1> (size=0x10)
    // 0x6d16b0: mov             x1, x0
    // 0x6d16b4: ldur            x0, [fp, #-0x18]
    // 0x6d16b8: StoreField: r1->field_b = r0
    //     0x6d16b8: stur            w0, [x1, #0xb]
    // 0x6d16bc: mov             x0, x1
    // 0x6d16c0: LeaveFrame
    //     0x6d16c0: mov             SP, fp
    //     0x6d16c4: ldp             fp, lr, [SP], #0x10
    // 0x6d16c8: ret
    //     0x6d16c8: ret             
    // 0x6d16cc: r1 = LoadClassIdInstr(r0)
    //     0x6d16cc: ldur            x1, [x0, #-1]
    //     0x6d16d0: ubfx            x1, x1, #0xc, #0x14
    // 0x6d16d4: stp             xzr, x0, [SP, #-0x10]!
    // 0x6d16d8: mov             x0, x1
    // 0x6d16dc: r0 = GDT[cid_x0 + 0xd175]()
    //     0x6d16dc: mov             x17, #0xd175
    //     0x6d16e0: add             lr, x0, x17
    //     0x6d16e4: ldr             lr, [x21, lr, lsl #3]
    //     0x6d16e8: blr             lr
    // 0x6d16ec: add             SP, SP, #0x10
    // 0x6d16f0: cmp             w0, NULL
    // 0x6d16f4: b.ne            #0x6d1748
    // 0x6d16f8: b               #0x6d171c
    // 0x6d16fc: ldr             x0, [fp, #0x10]
    // 0x6d1700: r0 = ConcurrentModificationError()
    //     0x6d1700: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6d1704: mov             x1, x0
    // 0x6d1708: ldr             x0, [fp, #0x10]
    // 0x6d170c: StoreField: r1->field_b = r0
    //     0x6d170c: stur            w0, [x1, #0xb]
    // 0x6d1710: mov             x0, x1
    // 0x6d1714: r0 = Throw()
    //     0x6d1714: bl              #0xd67e38  ; ThrowStub
    // 0x6d1718: brk             #0
    // 0x6d171c: ldur            x2, [fp, #-0x10]
    // 0x6d1720: r1 = Null
    //     0x6d1720: mov             x1, NULL
    // 0x6d1724: cmp             w2, NULL
    // 0x6d1728: b.eq            #0x6d1748
    // 0x6d172c: LoadField: r4 = r2->field_17
    //     0x6d172c: ldur            w4, [x2, #0x17]
    // 0x6d1730: DecompressPointer r4
    //     0x6d1730: add             x4, x4, HEAP, lsl #32
    // 0x6d1734: r8 = X0
    //     0x6d1734: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6d1738: LoadField: r9 = r4->field_7
    //     0x6d1738: ldur            x9, [x4, #7]
    // 0x6d173c: r3 = Null
    //     0x6d173c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd168] Null
    //     0x6d1740: ldr             x3, [x3, #0x168]
    // 0x6d1744: blr             x9
    // 0x6d1748: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x6d1748: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x6d174c: r0 = Throw()
    //     0x6d174c: bl              #0xd67e38  ; ThrowStub
    // 0x6d1750: brk             #0
    // 0x6d1754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d1754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d1758: b               #0x6d1604
  }
  static _ estimateBrightnessForColor(/* No info */) {
    // ** addr: 0x6d295c, size: 0x74
    // 0x6d295c: EnterFrame
    //     0x6d295c: stp             fp, lr, [SP, #-0x10]!
    //     0x6d2960: mov             fp, SP
    // 0x6d2964: CheckStackOverflow
    //     0x6d2964: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d2968: cmp             SP, x16
    //     0x6d296c: b.ls            #0x6d29c8
    // 0x6d2970: ldr             x16, [fp, #0x10]
    // 0x6d2974: SaveReg r16
    //     0x6d2974: str             x16, [SP, #-8]!
    // 0x6d2978: r0 = computeLuminance()
    //     0x6d2978: bl              #0x6d29d0  ; [dart:ui] Color::computeLuminance
    // 0x6d297c: add             SP, SP, #8
    // 0x6d2980: mov             v1.16b, v0.16b
    // 0x6d2984: d0 = 0.050000
    //     0x6d2984: add             x17, PP, #0xd, lsl #12  ; [pp+0xd208] IMM: double(0.05) from 0x3fa999999999999a
    //     0x6d2988: ldr             d0, [x17, #0x208]
    // 0x6d298c: fadd            d2, d1, d0
    // 0x6d2990: fmul            d0, d2, d2
    // 0x6d2994: d1 = 0.150000
    //     0x6d2994: add             x17, PP, #0xd, lsl #12  ; [pp+0xd210] IMM: double(0.15) from 0x3fc3333333333333
    //     0x6d2998: ldr             d1, [x17, #0x210]
    // 0x6d299c: fcmp            d0, d1
    // 0x6d29a0: b.vs            #0x6d29b8
    // 0x6d29a4: b.le            #0x6d29b8
    // 0x6d29a8: r0 = Instance_Brightness
    //     0x6d29a8: ldr             x0, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0x6d29ac: LeaveFrame
    //     0x6d29ac: mov             SP, fp
    //     0x6d29b0: ldp             fp, lr, [SP], #0x10
    // 0x6d29b4: ret
    //     0x6d29b4: ret             
    // 0x6d29b8: r0 = Instance_Brightness
    //     0x6d29b8: ldr             x0, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x6d29bc: LeaveFrame
    //     0x6d29bc: mov             SP, fp
    //     0x6d29c0: ldp             fp, lr, [SP], #0x10
    // 0x6d29c4: ret
    //     0x6d29c4: ret             
    // 0x6d29c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d29c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d29cc: b               #0x6d2970
  }
  factory ThemeData ThemeData.dark(dynamic) {
    // ** addr: 0x999e08, size: 0x44
    // 0x999e08: EnterFrame
    //     0x999e08: stp             fp, lr, [SP, #-0x10]!
    //     0x999e0c: mov             fp, SP
    // 0x999e10: CheckStackOverflow
    //     0x999e10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x999e14: cmp             SP, x16
    //     0x999e18: b.ls            #0x999e44
    // 0x999e1c: stp             NULL, NULL, [SP, #-0x10]!
    // 0x999e20: r16 = Instance_Brightness
    //     0x999e20: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x999e24: SaveReg r16
    //     0x999e24: str             x16, [SP, #-8]!
    // 0x999e28: r4 = const [0, 0x3, 0x3, 0x2, brightness, 0x2, null]
    //     0x999e28: add             x4, PP, #0xe, lsl #12  ; [pp+0xe108] List(7) [0, 0x3, 0x3, 0x2, "brightness", 0x2, Null]
    //     0x999e2c: ldr             x4, [x4, #0x108]
    // 0x999e30: r0 = ThemeData()
    //     0x999e30: bl              #0x6cef80  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0x999e34: add             SP, SP, #0x18
    // 0x999e38: LeaveFrame
    //     0x999e38: mov             SP, fp
    //     0x999e3c: ldp             fp, lr, [SP], #0x10
    // 0x999e40: ret
    //     0x999e40: ret             
    // 0x999e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x999e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x999e48: b               #0x999e1c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb0258c, size: 0x31dc
    // 0xb0258c: EnterFrame
    //     0xb0258c: stp             fp, lr, [SP, #-0x10]!
    //     0xb02590: mov             fp, SP
    // 0xb02594: AllocStack(0x28)
    //     0xb02594: sub             SP, SP, #0x28
    // 0xb02598: r0 = 4
    //     0xb02598: mov             x0, #4
    // 0xb0259c: CheckStackOverflow
    //     0xb0259c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb025a0: cmp             SP, x16
    //     0xb025a4: b.ls            #0xb055e8
    // 0xb025a8: ldr             x3, [fp, #0x10]
    // 0xb025ac: LoadField: r4 = r3->field_7
    //     0xb025ac: ldur            w4, [x3, #7]
    // 0xb025b0: DecompressPointer r4
    //     0xb025b0: add             x4, x4, HEAP, lsl #32
    // 0xb025b4: mov             x2, x0
    // 0xb025b8: stur            x4, [fp, #-8]
    // 0xb025bc: r1 = Null
    //     0xb025bc: mov             x1, NULL
    // 0xb025c0: r0 = AllocateArray()
    //     0xb025c0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb025c4: mov             x2, x0
    // 0xb025c8: ldur            x0, [fp, #-8]
    // 0xb025cc: stur            x2, [fp, #-0x10]
    // 0xb025d0: StoreField: r2->field_f = r0
    //     0xb025d0: stur            w0, [x2, #0xf]
    // 0xb025d4: StoreField: r2->field_13 = rNULL
    //     0xb025d4: stur            NULL, [x2, #0x13]
    // 0xb025d8: r1 = <Object?>
    //     0xb025d8: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xb025dc: r0 = AllocateGrowableArray()
    //     0xb025dc: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xb025e0: mov             x1, x0
    // 0xb025e4: ldur            x0, [fp, #-0x10]
    // 0xb025e8: stur            x1, [fp, #-0x18]
    // 0xb025ec: StoreField: r1->field_f = r0
    //     0xb025ec: stur            w0, [x1, #0xf]
    // 0xb025f0: r0 = 4
    //     0xb025f0: mov             x0, #4
    // 0xb025f4: StoreField: r1->field_b = r0
    //     0xb025f4: stur            w0, [x1, #0xb]
    // 0xb025f8: ldr             x2, [fp, #0x10]
    // 0xb025fc: LoadField: r3 = r2->field_f
    //     0xb025fc: ldur            w3, [x2, #0xf]
    // 0xb02600: DecompressPointer r3
    //     0xb02600: add             x3, x3, HEAP, lsl #32
    // 0xb02604: stur            x3, [fp, #-8]
    // 0xb02608: r0 = LoadClassIdInstr(r3)
    //     0xb02608: ldur            x0, [x3, #-1]
    //     0xb0260c: ubfx            x0, x0, #0xc, #0x14
    // 0xb02610: SaveReg r3
    //     0xb02610: str             x3, [SP, #-8]!
    // 0xb02614: r0 = GDT[cid_x0 + 0x6d7]()
    //     0xb02614: add             lr, x0, #0x6d7
    //     0xb02618: ldr             lr, [x21, lr, lsl #3]
    //     0xb0261c: blr             lr
    // 0xb02620: add             SP, SP, #8
    // 0xb02624: ldur            x16, [fp, #-0x18]
    // 0xb02628: stp             x0, x16, [SP, #-0x10]!
    // 0xb0262c: r0 = addAll()
    //     0xb0262c: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xb02630: add             SP, SP, #0x10
    // 0xb02634: ldur            x0, [fp, #-8]
    // 0xb02638: r1 = LoadClassIdInstr(r0)
    //     0xb02638: ldur            x1, [x0, #-1]
    //     0xb0263c: ubfx            x1, x1, #0xc, #0x14
    // 0xb02640: SaveReg r0
    //     0xb02640: str             x0, [SP, #-8]!
    // 0xb02644: mov             x0, x1
    // 0xb02648: r0 = GDT[cid_x0 + 0x7ba]()
    //     0xb02648: add             lr, x0, #0x7ba
    //     0xb0264c: ldr             lr, [x21, lr, lsl #3]
    //     0xb02650: blr             lr
    // 0xb02654: add             SP, SP, #8
    // 0xb02658: ldur            x16, [fp, #-0x18]
    // 0xb0265c: stp             x0, x16, [SP, #-0x10]!
    // 0xb02660: r0 = addAll()
    //     0xb02660: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0xb02664: add             SP, SP, #0x10
    // 0xb02668: ldur            x0, [fp, #-0x18]
    // 0xb0266c: LoadField: r1 = r0->field_b
    //     0xb0266c: ldur            w1, [x0, #0xb]
    // 0xb02670: DecompressPointer r1
    //     0xb02670: add             x1, x1, HEAP, lsl #32
    // 0xb02674: stur            x1, [fp, #-8]
    // 0xb02678: LoadField: r2 = r0->field_f
    //     0xb02678: ldur            w2, [x0, #0xf]
    // 0xb0267c: DecompressPointer r2
    //     0xb0267c: add             x2, x2, HEAP, lsl #32
    // 0xb02680: LoadField: r3 = r2->field_b
    //     0xb02680: ldur            w3, [x2, #0xb]
    // 0xb02684: DecompressPointer r3
    //     0xb02684: add             x3, x3, HEAP, lsl #32
    // 0xb02688: cmp             w1, w3
    // 0xb0268c: b.ne            #0xb0269c
    // 0xb02690: SaveReg r0
    //     0xb02690: str             x0, [SP, #-8]!
    // 0xb02694: r0 = _growToNextCapacity()
    //     0xb02694: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02698: add             SP, SP, #8
    // 0xb0269c: ldr             x3, [fp, #0x10]
    // 0xb026a0: ldur            x2, [fp, #-0x18]
    // 0xb026a4: ldur            x0, [fp, #-8]
    // 0xb026a8: r4 = LoadInt32Instr(r0)
    //     0xb026a8: sbfx            x4, x0, #1, #0x1f
    // 0xb026ac: add             x5, x4, #1
    // 0xb026b0: stur            x5, [fp, #-0x20]
    // 0xb026b4: lsl             x6, x5, #1
    // 0xb026b8: StoreField: r2->field_b = r6
    //     0xb026b8: stur            w6, [x2, #0xb]
    // 0xb026bc: mov             x0, x5
    // 0xb026c0: mov             x1, x4
    // 0xb026c4: cmp             x1, x0
    // 0xb026c8: b.hs            #0xb055f0
    // 0xb026cc: LoadField: r0 = r2->field_f
    //     0xb026cc: ldur            w0, [x2, #0xf]
    // 0xb026d0: DecompressPointer r0
    //     0xb026d0: add             x0, x0, HEAP, lsl #32
    // 0xb026d4: add             x1, x0, x4, lsl #2
    // 0xb026d8: r17 = Instance_InputDecorationTheme
    //     0xb026d8: add             x17, PP, #0xd, lsl #12  ; [pp+0xd008] Obj!InputDecorationTheme@b48581
    //     0xb026dc: ldr             x17, [x17, #8]
    // 0xb026e0: StoreField: r1->field_f = r17
    //     0xb026e0: stur            w17, [x1, #0xf]
    // 0xb026e4: LoadField: r1 = r3->field_17
    //     0xb026e4: ldur            w1, [x3, #0x17]
    // 0xb026e8: DecompressPointer r1
    //     0xb026e8: add             x1, x1, HEAP, lsl #32
    // 0xb026ec: stur            x1, [fp, #-8]
    // 0xb026f0: LoadField: r4 = r0->field_b
    //     0xb026f0: ldur            w4, [x0, #0xb]
    // 0xb026f4: DecompressPointer r4
    //     0xb026f4: add             x4, x4, HEAP, lsl #32
    // 0xb026f8: cmp             w6, w4
    // 0xb026fc: b.ne            #0xb0270c
    // 0xb02700: SaveReg r2
    //     0xb02700: str             x2, [SP, #-8]!
    // 0xb02704: r0 = _growToNextCapacity()
    //     0xb02704: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02708: add             SP, SP, #8
    // 0xb0270c: ldur            x3, [fp, #-0x20]
    // 0xb02710: ldur            x2, [fp, #-0x18]
    // 0xb02714: add             x4, x3, #1
    // 0xb02718: stur            x4, [fp, #-0x28]
    // 0xb0271c: lsl             x5, x4, #1
    // 0xb02720: StoreField: r2->field_b = r5
    //     0xb02720: stur            w5, [x2, #0xb]
    // 0xb02724: mov             x0, x4
    // 0xb02728: mov             x1, x3
    // 0xb0272c: cmp             x1, x0
    // 0xb02730: b.hs            #0xb055f4
    // 0xb02734: LoadField: r6 = r2->field_f
    //     0xb02734: ldur            w6, [x2, #0xf]
    // 0xb02738: DecompressPointer r6
    //     0xb02738: add             x6, x6, HEAP, lsl #32
    // 0xb0273c: mov             x1, x6
    // 0xb02740: ldur            x0, [fp, #-8]
    // 0xb02744: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb02744: add             x25, x1, x3, lsl #2
    //     0xb02748: add             x25, x25, #0xf
    //     0xb0274c: str             w0, [x25]
    //     0xb02750: tbz             w0, #0, #0xb0276c
    //     0xb02754: ldurb           w16, [x1, #-1]
    //     0xb02758: ldurb           w17, [x0, #-1]
    //     0xb0275c: and             x16, x17, x16, lsr #2
    //     0xb02760: tst             x16, HEAP, lsr #32
    //     0xb02764: b.eq            #0xb0276c
    //     0xb02768: bl              #0xd67e5c
    // 0xb0276c: LoadField: r0 = r6->field_b
    //     0xb0276c: ldur            w0, [x6, #0xb]
    // 0xb02770: DecompressPointer r0
    //     0xb02770: add             x0, x0, HEAP, lsl #32
    // 0xb02774: cmp             w5, w0
    // 0xb02778: b.ne            #0xb02788
    // 0xb0277c: SaveReg r2
    //     0xb0277c: str             x2, [SP, #-8]!
    // 0xb02780: r0 = _growToNextCapacity()
    //     0xb02780: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02784: add             SP, SP, #8
    // 0xb02788: ldr             x4, [fp, #0x10]
    // 0xb0278c: ldur            x3, [fp, #-0x28]
    // 0xb02790: ldur            x2, [fp, #-0x18]
    // 0xb02794: add             x5, x3, #1
    // 0xb02798: stur            x5, [fp, #-0x20]
    // 0xb0279c: lsl             x6, x5, #1
    // 0xb027a0: StoreField: r2->field_b = r6
    //     0xb027a0: stur            w6, [x2, #0xb]
    // 0xb027a4: mov             x0, x5
    // 0xb027a8: mov             x1, x3
    // 0xb027ac: cmp             x1, x0
    // 0xb027b0: b.hs            #0xb055f8
    // 0xb027b4: LoadField: r0 = r2->field_f
    //     0xb027b4: ldur            w0, [x2, #0xf]
    // 0xb027b8: DecompressPointer r0
    //     0xb027b8: add             x0, x0, HEAP, lsl #32
    // 0xb027bc: add             x1, x0, x3, lsl #2
    // 0xb027c0: r17 = Instance_PageTransitionsTheme
    //     0xb027c0: add             x17, PP, #0xd, lsl #12  ; [pp+0xd010] Obj!PageTransitionsTheme@b3ceb1
    //     0xb027c4: ldr             x17, [x17, #0x10]
    // 0xb027c8: StoreField: r1->field_f = r17
    //     0xb027c8: stur            w17, [x1, #0xf]
    // 0xb027cc: LoadField: r1 = r4->field_1f
    //     0xb027cc: ldur            w1, [x4, #0x1f]
    // 0xb027d0: DecompressPointer r1
    //     0xb027d0: add             x1, x1, HEAP, lsl #32
    // 0xb027d4: stur            x1, [fp, #-8]
    // 0xb027d8: LoadField: r3 = r0->field_b
    //     0xb027d8: ldur            w3, [x0, #0xb]
    // 0xb027dc: DecompressPointer r3
    //     0xb027dc: add             x3, x3, HEAP, lsl #32
    // 0xb027e0: cmp             w6, w3
    // 0xb027e4: b.ne            #0xb027f4
    // 0xb027e8: SaveReg r2
    //     0xb027e8: str             x2, [SP, #-8]!
    // 0xb027ec: r0 = _growToNextCapacity()
    //     0xb027ec: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb027f0: add             SP, SP, #8
    // 0xb027f4: ldr             x3, [fp, #0x10]
    // 0xb027f8: ldur            x4, [fp, #-0x20]
    // 0xb027fc: ldur            x2, [fp, #-0x18]
    // 0xb02800: add             x5, x4, #1
    // 0xb02804: stur            x5, [fp, #-0x28]
    // 0xb02808: lsl             x6, x5, #1
    // 0xb0280c: StoreField: r2->field_b = r6
    //     0xb0280c: stur            w6, [x2, #0xb]
    // 0xb02810: mov             x0, x5
    // 0xb02814: mov             x1, x4
    // 0xb02818: cmp             x1, x0
    // 0xb0281c: b.hs            #0xb055fc
    // 0xb02820: LoadField: r7 = r2->field_f
    //     0xb02820: ldur            w7, [x2, #0xf]
    // 0xb02824: DecompressPointer r7
    //     0xb02824: add             x7, x7, HEAP, lsl #32
    // 0xb02828: mov             x1, x7
    // 0xb0282c: ldur            x0, [fp, #-8]
    // 0xb02830: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02830: add             x25, x1, x4, lsl #2
    //     0xb02834: add             x25, x25, #0xf
    //     0xb02838: str             w0, [x25]
    //     0xb0283c: tbz             w0, #0, #0xb02858
    //     0xb02840: ldurb           w16, [x1, #-1]
    //     0xb02844: ldurb           w17, [x0, #-1]
    //     0xb02848: and             x16, x17, x16, lsr #2
    //     0xb0284c: tst             x16, HEAP, lsr #32
    //     0xb02850: b.eq            #0xb02858
    //     0xb02854: bl              #0xd67e5c
    // 0xb02858: LoadField: r0 = r3->field_23
    //     0xb02858: ldur            w0, [x3, #0x23]
    // 0xb0285c: DecompressPointer r0
    //     0xb0285c: add             x0, x0, HEAP, lsl #32
    // 0xb02860: stur            x0, [fp, #-8]
    // 0xb02864: LoadField: r1 = r7->field_b
    //     0xb02864: ldur            w1, [x7, #0xb]
    // 0xb02868: DecompressPointer r1
    //     0xb02868: add             x1, x1, HEAP, lsl #32
    // 0xb0286c: cmp             w6, w1
    // 0xb02870: b.ne            #0xb02880
    // 0xb02874: SaveReg r2
    //     0xb02874: str             x2, [SP, #-8]!
    // 0xb02878: r0 = _growToNextCapacity()
    //     0xb02878: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0287c: add             SP, SP, #8
    // 0xb02880: ldr             x3, [fp, #0x10]
    // 0xb02884: ldur            x4, [fp, #-0x28]
    // 0xb02888: ldur            x2, [fp, #-0x18]
    // 0xb0288c: add             x5, x4, #1
    // 0xb02890: stur            x5, [fp, #-0x20]
    // 0xb02894: lsl             x6, x5, #1
    // 0xb02898: StoreField: r2->field_b = r6
    //     0xb02898: stur            w6, [x2, #0xb]
    // 0xb0289c: mov             x0, x5
    // 0xb028a0: mov             x1, x4
    // 0xb028a4: cmp             x1, x0
    // 0xb028a8: b.hs            #0xb05600
    // 0xb028ac: LoadField: r7 = r2->field_f
    //     0xb028ac: ldur            w7, [x2, #0xf]
    // 0xb028b0: DecompressPointer r7
    //     0xb028b0: add             x7, x7, HEAP, lsl #32
    // 0xb028b4: mov             x1, x7
    // 0xb028b8: ldur            x0, [fp, #-8]
    // 0xb028bc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb028bc: add             x25, x1, x4, lsl #2
    //     0xb028c0: add             x25, x25, #0xf
    //     0xb028c4: str             w0, [x25]
    //     0xb028c8: tbz             w0, #0, #0xb028e4
    //     0xb028cc: ldurb           w16, [x1, #-1]
    //     0xb028d0: ldurb           w17, [x0, #-1]
    //     0xb028d4: and             x16, x17, x16, lsr #2
    //     0xb028d8: tst             x16, HEAP, lsr #32
    //     0xb028dc: b.eq            #0xb028e4
    //     0xb028e0: bl              #0xd67e5c
    // 0xb028e4: LoadField: r0 = r3->field_27
    //     0xb028e4: ldur            w0, [x3, #0x27]
    // 0xb028e8: DecompressPointer r0
    //     0xb028e8: add             x0, x0, HEAP, lsl #32
    // 0xb028ec: stur            x0, [fp, #-8]
    // 0xb028f0: LoadField: r1 = r7->field_b
    //     0xb028f0: ldur            w1, [x7, #0xb]
    // 0xb028f4: DecompressPointer r1
    //     0xb028f4: add             x1, x1, HEAP, lsl #32
    // 0xb028f8: cmp             w6, w1
    // 0xb028fc: b.ne            #0xb0290c
    // 0xb02900: SaveReg r2
    //     0xb02900: str             x2, [SP, #-8]!
    // 0xb02904: r0 = _growToNextCapacity()
    //     0xb02904: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02908: add             SP, SP, #8
    // 0xb0290c: ldr             x3, [fp, #0x10]
    // 0xb02910: ldur            x4, [fp, #-0x20]
    // 0xb02914: ldur            x2, [fp, #-0x18]
    // 0xb02918: add             x5, x4, #1
    // 0xb0291c: stur            x5, [fp, #-0x28]
    // 0xb02920: lsl             x6, x5, #1
    // 0xb02924: StoreField: r2->field_b = r6
    //     0xb02924: stur            w6, [x2, #0xb]
    // 0xb02928: mov             x0, x5
    // 0xb0292c: mov             x1, x4
    // 0xb02930: cmp             x1, x0
    // 0xb02934: b.hs            #0xb05604
    // 0xb02938: LoadField: r7 = r2->field_f
    //     0xb02938: ldur            w7, [x2, #0xf]
    // 0xb0293c: DecompressPointer r7
    //     0xb0293c: add             x7, x7, HEAP, lsl #32
    // 0xb02940: mov             x1, x7
    // 0xb02944: ldur            x0, [fp, #-8]
    // 0xb02948: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02948: add             x25, x1, x4, lsl #2
    //     0xb0294c: add             x25, x25, #0xf
    //     0xb02950: str             w0, [x25]
    //     0xb02954: tbz             w0, #0, #0xb02970
    //     0xb02958: ldurb           w16, [x1, #-1]
    //     0xb0295c: ldurb           w17, [x0, #-1]
    //     0xb02960: and             x16, x17, x16, lsr #2
    //     0xb02964: tst             x16, HEAP, lsr #32
    //     0xb02968: b.eq            #0xb02970
    //     0xb0296c: bl              #0xd67e5c
    // 0xb02970: LoadField: r0 = r3->field_2b
    //     0xb02970: ldur            w0, [x3, #0x2b]
    // 0xb02974: DecompressPointer r0
    //     0xb02974: add             x0, x0, HEAP, lsl #32
    // 0xb02978: stur            x0, [fp, #-8]
    // 0xb0297c: LoadField: r1 = r7->field_b
    //     0xb0297c: ldur            w1, [x7, #0xb]
    // 0xb02980: DecompressPointer r1
    //     0xb02980: add             x1, x1, HEAP, lsl #32
    // 0xb02984: cmp             w6, w1
    // 0xb02988: b.ne            #0xb02998
    // 0xb0298c: SaveReg r2
    //     0xb0298c: str             x2, [SP, #-8]!
    // 0xb02990: r0 = _growToNextCapacity()
    //     0xb02990: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02994: add             SP, SP, #8
    // 0xb02998: ldr             x3, [fp, #0x10]
    // 0xb0299c: ldur            x5, [fp, #-8]
    // 0xb029a0: ldur            x4, [fp, #-0x28]
    // 0xb029a4: ldur            x2, [fp, #-0x18]
    // 0xb029a8: add             x6, x4, #1
    // 0xb029ac: stur            x6, [fp, #-0x20]
    // 0xb029b0: lsl             x7, x6, #1
    // 0xb029b4: StoreField: r2->field_b = r7
    //     0xb029b4: stur            w7, [x2, #0xb]
    // 0xb029b8: mov             x0, x6
    // 0xb029bc: mov             x1, x4
    // 0xb029c0: cmp             x1, x0
    // 0xb029c4: b.hs            #0xb05608
    // 0xb029c8: LoadField: r0 = r2->field_f
    //     0xb029c8: ldur            w0, [x2, #0xf]
    // 0xb029cc: DecompressPointer r0
    //     0xb029cc: add             x0, x0, HEAP, lsl #32
    // 0xb029d0: ArrayStore: r0[r4] = r5  ; Unknown_4
    //     0xb029d0: add             x1, x0, x4, lsl #2
    //     0xb029d4: stur            w5, [x1, #0xf]
    // 0xb029d8: LoadField: r1 = r3->field_2f
    //     0xb029d8: ldur            w1, [x3, #0x2f]
    // 0xb029dc: DecompressPointer r1
    //     0xb029dc: add             x1, x1, HEAP, lsl #32
    // 0xb029e0: stur            x1, [fp, #-8]
    // 0xb029e4: LoadField: r4 = r0->field_b
    //     0xb029e4: ldur            w4, [x0, #0xb]
    // 0xb029e8: DecompressPointer r4
    //     0xb029e8: add             x4, x4, HEAP, lsl #32
    // 0xb029ec: cmp             w7, w4
    // 0xb029f0: b.ne            #0xb02a00
    // 0xb029f4: SaveReg r2
    //     0xb029f4: str             x2, [SP, #-8]!
    // 0xb029f8: r0 = _growToNextCapacity()
    //     0xb029f8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb029fc: add             SP, SP, #8
    // 0xb02a00: ldr             x3, [fp, #0x10]
    // 0xb02a04: ldur            x4, [fp, #-0x20]
    // 0xb02a08: ldur            x2, [fp, #-0x18]
    // 0xb02a0c: add             x5, x4, #1
    // 0xb02a10: stur            x5, [fp, #-0x28]
    // 0xb02a14: lsl             x6, x5, #1
    // 0xb02a18: StoreField: r2->field_b = r6
    //     0xb02a18: stur            w6, [x2, #0xb]
    // 0xb02a1c: mov             x0, x5
    // 0xb02a20: mov             x1, x4
    // 0xb02a24: cmp             x1, x0
    // 0xb02a28: b.hs            #0xb0560c
    // 0xb02a2c: LoadField: r7 = r2->field_f
    //     0xb02a2c: ldur            w7, [x2, #0xf]
    // 0xb02a30: DecompressPointer r7
    //     0xb02a30: add             x7, x7, HEAP, lsl #32
    // 0xb02a34: mov             x1, x7
    // 0xb02a38: ldur            x0, [fp, #-8]
    // 0xb02a3c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02a3c: add             x25, x1, x4, lsl #2
    //     0xb02a40: add             x25, x25, #0xf
    //     0xb02a44: str             w0, [x25]
    //     0xb02a48: tbz             w0, #0, #0xb02a64
    //     0xb02a4c: ldurb           w16, [x1, #-1]
    //     0xb02a50: ldurb           w17, [x0, #-1]
    //     0xb02a54: and             x16, x17, x16, lsr #2
    //     0xb02a58: tst             x16, HEAP, lsr #32
    //     0xb02a5c: b.eq            #0xb02a64
    //     0xb02a60: bl              #0xd67e5c
    // 0xb02a64: LoadField: r0 = r3->field_37
    //     0xb02a64: ldur            w0, [x3, #0x37]
    // 0xb02a68: DecompressPointer r0
    //     0xb02a68: add             x0, x0, HEAP, lsl #32
    // 0xb02a6c: stur            x0, [fp, #-8]
    // 0xb02a70: LoadField: r1 = r7->field_b
    //     0xb02a70: ldur            w1, [x7, #0xb]
    // 0xb02a74: DecompressPointer r1
    //     0xb02a74: add             x1, x1, HEAP, lsl #32
    // 0xb02a78: cmp             w6, w1
    // 0xb02a7c: b.ne            #0xb02a8c
    // 0xb02a80: SaveReg r2
    //     0xb02a80: str             x2, [SP, #-8]!
    // 0xb02a84: r0 = _growToNextCapacity()
    //     0xb02a84: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02a88: add             SP, SP, #8
    // 0xb02a8c: ldr             x3, [fp, #0x10]
    // 0xb02a90: ldur            x4, [fp, #-0x28]
    // 0xb02a94: ldur            x2, [fp, #-0x18]
    // 0xb02a98: add             x5, x4, #1
    // 0xb02a9c: stur            x5, [fp, #-0x20]
    // 0xb02aa0: lsl             x6, x5, #1
    // 0xb02aa4: StoreField: r2->field_b = r6
    //     0xb02aa4: stur            w6, [x2, #0xb]
    // 0xb02aa8: mov             x0, x5
    // 0xb02aac: mov             x1, x4
    // 0xb02ab0: cmp             x1, x0
    // 0xb02ab4: b.hs            #0xb05610
    // 0xb02ab8: LoadField: r7 = r2->field_f
    //     0xb02ab8: ldur            w7, [x2, #0xf]
    // 0xb02abc: DecompressPointer r7
    //     0xb02abc: add             x7, x7, HEAP, lsl #32
    // 0xb02ac0: mov             x1, x7
    // 0xb02ac4: ldur            x0, [fp, #-8]
    // 0xb02ac8: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02ac8: add             x25, x1, x4, lsl #2
    //     0xb02acc: add             x25, x25, #0xf
    //     0xb02ad0: str             w0, [x25]
    //     0xb02ad4: tbz             w0, #0, #0xb02af0
    //     0xb02ad8: ldurb           w16, [x1, #-1]
    //     0xb02adc: ldurb           w17, [x0, #-1]
    //     0xb02ae0: and             x16, x17, x16, lsr #2
    //     0xb02ae4: tst             x16, HEAP, lsr #32
    //     0xb02ae8: b.eq            #0xb02af0
    //     0xb02aec: bl              #0xd67e5c
    // 0xb02af0: LoadField: r0 = r3->field_3b
    //     0xb02af0: ldur            w0, [x3, #0x3b]
    // 0xb02af4: DecompressPointer r0
    //     0xb02af4: add             x0, x0, HEAP, lsl #32
    // 0xb02af8: stur            x0, [fp, #-8]
    // 0xb02afc: LoadField: r1 = r7->field_b
    //     0xb02afc: ldur            w1, [x7, #0xb]
    // 0xb02b00: DecompressPointer r1
    //     0xb02b00: add             x1, x1, HEAP, lsl #32
    // 0xb02b04: cmp             w6, w1
    // 0xb02b08: b.ne            #0xb02b18
    // 0xb02b0c: SaveReg r2
    //     0xb02b0c: str             x2, [SP, #-8]!
    // 0xb02b10: r0 = _growToNextCapacity()
    //     0xb02b10: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02b14: add             SP, SP, #8
    // 0xb02b18: ldr             x3, [fp, #0x10]
    // 0xb02b1c: ldur            x4, [fp, #-0x20]
    // 0xb02b20: ldur            x2, [fp, #-0x18]
    // 0xb02b24: add             x5, x4, #1
    // 0xb02b28: stur            x5, [fp, #-0x28]
    // 0xb02b2c: lsl             x6, x5, #1
    // 0xb02b30: StoreField: r2->field_b = r6
    //     0xb02b30: stur            w6, [x2, #0xb]
    // 0xb02b34: mov             x0, x5
    // 0xb02b38: mov             x1, x4
    // 0xb02b3c: cmp             x1, x0
    // 0xb02b40: b.hs            #0xb05614
    // 0xb02b44: LoadField: r7 = r2->field_f
    //     0xb02b44: ldur            w7, [x2, #0xf]
    // 0xb02b48: DecompressPointer r7
    //     0xb02b48: add             x7, x7, HEAP, lsl #32
    // 0xb02b4c: mov             x1, x7
    // 0xb02b50: ldur            x0, [fp, #-8]
    // 0xb02b54: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02b54: add             x25, x1, x4, lsl #2
    //     0xb02b58: add             x25, x25, #0xf
    //     0xb02b5c: str             w0, [x25]
    //     0xb02b60: tbz             w0, #0, #0xb02b7c
    //     0xb02b64: ldurb           w16, [x1, #-1]
    //     0xb02b68: ldurb           w17, [x0, #-1]
    //     0xb02b6c: and             x16, x17, x16, lsr #2
    //     0xb02b70: tst             x16, HEAP, lsr #32
    //     0xb02b74: b.eq            #0xb02b7c
    //     0xb02b78: bl              #0xd67e5c
    // 0xb02b7c: LoadField: r0 = r3->field_3f
    //     0xb02b7c: ldur            w0, [x3, #0x3f]
    // 0xb02b80: DecompressPointer r0
    //     0xb02b80: add             x0, x0, HEAP, lsl #32
    // 0xb02b84: stur            x0, [fp, #-8]
    // 0xb02b88: LoadField: r1 = r7->field_b
    //     0xb02b88: ldur            w1, [x7, #0xb]
    // 0xb02b8c: DecompressPointer r1
    //     0xb02b8c: add             x1, x1, HEAP, lsl #32
    // 0xb02b90: cmp             w6, w1
    // 0xb02b94: b.ne            #0xb02ba4
    // 0xb02b98: SaveReg r2
    //     0xb02b98: str             x2, [SP, #-8]!
    // 0xb02b9c: r0 = _growToNextCapacity()
    //     0xb02b9c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02ba0: add             SP, SP, #8
    // 0xb02ba4: ldr             x3, [fp, #0x10]
    // 0xb02ba8: ldur            x4, [fp, #-0x28]
    // 0xb02bac: ldur            x2, [fp, #-0x18]
    // 0xb02bb0: add             x5, x4, #1
    // 0xb02bb4: stur            x5, [fp, #-0x20]
    // 0xb02bb8: lsl             x6, x5, #1
    // 0xb02bbc: StoreField: r2->field_b = r6
    //     0xb02bbc: stur            w6, [x2, #0xb]
    // 0xb02bc0: mov             x0, x5
    // 0xb02bc4: mov             x1, x4
    // 0xb02bc8: cmp             x1, x0
    // 0xb02bcc: b.hs            #0xb05618
    // 0xb02bd0: LoadField: r7 = r2->field_f
    //     0xb02bd0: ldur            w7, [x2, #0xf]
    // 0xb02bd4: DecompressPointer r7
    //     0xb02bd4: add             x7, x7, HEAP, lsl #32
    // 0xb02bd8: mov             x1, x7
    // 0xb02bdc: ldur            x0, [fp, #-8]
    // 0xb02be0: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02be0: add             x25, x1, x4, lsl #2
    //     0xb02be4: add             x25, x25, #0xf
    //     0xb02be8: str             w0, [x25]
    //     0xb02bec: tbz             w0, #0, #0xb02c08
    //     0xb02bf0: ldurb           w16, [x1, #-1]
    //     0xb02bf4: ldurb           w17, [x0, #-1]
    //     0xb02bf8: and             x16, x17, x16, lsr #2
    //     0xb02bfc: tst             x16, HEAP, lsr #32
    //     0xb02c00: b.eq            #0xb02c08
    //     0xb02c04: bl              #0xd67e5c
    // 0xb02c08: LoadField: r0 = r3->field_43
    //     0xb02c08: ldur            w0, [x3, #0x43]
    // 0xb02c0c: DecompressPointer r0
    //     0xb02c0c: add             x0, x0, HEAP, lsl #32
    // 0xb02c10: stur            x0, [fp, #-8]
    // 0xb02c14: LoadField: r1 = r7->field_b
    //     0xb02c14: ldur            w1, [x7, #0xb]
    // 0xb02c18: DecompressPointer r1
    //     0xb02c18: add             x1, x1, HEAP, lsl #32
    // 0xb02c1c: cmp             w6, w1
    // 0xb02c20: b.ne            #0xb02c30
    // 0xb02c24: SaveReg r2
    //     0xb02c24: str             x2, [SP, #-8]!
    // 0xb02c28: r0 = _growToNextCapacity()
    //     0xb02c28: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02c2c: add             SP, SP, #8
    // 0xb02c30: ldr             x3, [fp, #0x10]
    // 0xb02c34: ldur            x4, [fp, #-0x20]
    // 0xb02c38: ldur            x2, [fp, #-0x18]
    // 0xb02c3c: add             x5, x4, #1
    // 0xb02c40: stur            x5, [fp, #-0x28]
    // 0xb02c44: lsl             x6, x5, #1
    // 0xb02c48: StoreField: r2->field_b = r6
    //     0xb02c48: stur            w6, [x2, #0xb]
    // 0xb02c4c: mov             x0, x5
    // 0xb02c50: mov             x1, x4
    // 0xb02c54: cmp             x1, x0
    // 0xb02c58: b.hs            #0xb0561c
    // 0xb02c5c: LoadField: r7 = r2->field_f
    //     0xb02c5c: ldur            w7, [x2, #0xf]
    // 0xb02c60: DecompressPointer r7
    //     0xb02c60: add             x7, x7, HEAP, lsl #32
    // 0xb02c64: mov             x1, x7
    // 0xb02c68: ldur            x0, [fp, #-8]
    // 0xb02c6c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02c6c: add             x25, x1, x4, lsl #2
    //     0xb02c70: add             x25, x25, #0xf
    //     0xb02c74: str             w0, [x25]
    //     0xb02c78: tbz             w0, #0, #0xb02c94
    //     0xb02c7c: ldurb           w16, [x1, #-1]
    //     0xb02c80: ldurb           w17, [x0, #-1]
    //     0xb02c84: and             x16, x17, x16, lsr #2
    //     0xb02c88: tst             x16, HEAP, lsr #32
    //     0xb02c8c: b.eq            #0xb02c94
    //     0xb02c90: bl              #0xd67e5c
    // 0xb02c94: LoadField: r0 = r3->field_47
    //     0xb02c94: ldur            w0, [x3, #0x47]
    // 0xb02c98: DecompressPointer r0
    //     0xb02c98: add             x0, x0, HEAP, lsl #32
    // 0xb02c9c: stur            x0, [fp, #-8]
    // 0xb02ca0: LoadField: r1 = r7->field_b
    //     0xb02ca0: ldur            w1, [x7, #0xb]
    // 0xb02ca4: DecompressPointer r1
    //     0xb02ca4: add             x1, x1, HEAP, lsl #32
    // 0xb02ca8: cmp             w6, w1
    // 0xb02cac: b.ne            #0xb02cbc
    // 0xb02cb0: SaveReg r2
    //     0xb02cb0: str             x2, [SP, #-8]!
    // 0xb02cb4: r0 = _growToNextCapacity()
    //     0xb02cb4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02cb8: add             SP, SP, #8
    // 0xb02cbc: ldr             x3, [fp, #0x10]
    // 0xb02cc0: ldur            x4, [fp, #-0x28]
    // 0xb02cc4: ldur            x2, [fp, #-0x18]
    // 0xb02cc8: add             x5, x4, #1
    // 0xb02ccc: stur            x5, [fp, #-0x20]
    // 0xb02cd0: lsl             x6, x5, #1
    // 0xb02cd4: StoreField: r2->field_b = r6
    //     0xb02cd4: stur            w6, [x2, #0xb]
    // 0xb02cd8: mov             x0, x5
    // 0xb02cdc: mov             x1, x4
    // 0xb02ce0: cmp             x1, x0
    // 0xb02ce4: b.hs            #0xb05620
    // 0xb02ce8: LoadField: r7 = r2->field_f
    //     0xb02ce8: ldur            w7, [x2, #0xf]
    // 0xb02cec: DecompressPointer r7
    //     0xb02cec: add             x7, x7, HEAP, lsl #32
    // 0xb02cf0: mov             x1, x7
    // 0xb02cf4: ldur            x0, [fp, #-8]
    // 0xb02cf8: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02cf8: add             x25, x1, x4, lsl #2
    //     0xb02cfc: add             x25, x25, #0xf
    //     0xb02d00: str             w0, [x25]
    //     0xb02d04: tbz             w0, #0, #0xb02d20
    //     0xb02d08: ldurb           w16, [x1, #-1]
    //     0xb02d0c: ldurb           w17, [x0, #-1]
    //     0xb02d10: and             x16, x17, x16, lsr #2
    //     0xb02d14: tst             x16, HEAP, lsr #32
    //     0xb02d18: b.eq            #0xb02d20
    //     0xb02d1c: bl              #0xd67e5c
    // 0xb02d20: LoadField: r0 = r3->field_4b
    //     0xb02d20: ldur            w0, [x3, #0x4b]
    // 0xb02d24: DecompressPointer r0
    //     0xb02d24: add             x0, x0, HEAP, lsl #32
    // 0xb02d28: stur            x0, [fp, #-8]
    // 0xb02d2c: LoadField: r1 = r7->field_b
    //     0xb02d2c: ldur            w1, [x7, #0xb]
    // 0xb02d30: DecompressPointer r1
    //     0xb02d30: add             x1, x1, HEAP, lsl #32
    // 0xb02d34: cmp             w6, w1
    // 0xb02d38: b.ne            #0xb02d48
    // 0xb02d3c: SaveReg r2
    //     0xb02d3c: str             x2, [SP, #-8]!
    // 0xb02d40: r0 = _growToNextCapacity()
    //     0xb02d40: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02d44: add             SP, SP, #8
    // 0xb02d48: ldr             x3, [fp, #0x10]
    // 0xb02d4c: ldur            x4, [fp, #-0x20]
    // 0xb02d50: ldur            x2, [fp, #-0x18]
    // 0xb02d54: add             x5, x4, #1
    // 0xb02d58: stur            x5, [fp, #-0x28]
    // 0xb02d5c: lsl             x6, x5, #1
    // 0xb02d60: StoreField: r2->field_b = r6
    //     0xb02d60: stur            w6, [x2, #0xb]
    // 0xb02d64: mov             x0, x5
    // 0xb02d68: mov             x1, x4
    // 0xb02d6c: cmp             x1, x0
    // 0xb02d70: b.hs            #0xb05624
    // 0xb02d74: LoadField: r7 = r2->field_f
    //     0xb02d74: ldur            w7, [x2, #0xf]
    // 0xb02d78: DecompressPointer r7
    //     0xb02d78: add             x7, x7, HEAP, lsl #32
    // 0xb02d7c: mov             x1, x7
    // 0xb02d80: ldur            x0, [fp, #-8]
    // 0xb02d84: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02d84: add             x25, x1, x4, lsl #2
    //     0xb02d88: add             x25, x25, #0xf
    //     0xb02d8c: str             w0, [x25]
    //     0xb02d90: tbz             w0, #0, #0xb02dac
    //     0xb02d94: ldurb           w16, [x1, #-1]
    //     0xb02d98: ldurb           w17, [x0, #-1]
    //     0xb02d9c: and             x16, x17, x16, lsr #2
    //     0xb02da0: tst             x16, HEAP, lsr #32
    //     0xb02da4: b.eq            #0xb02dac
    //     0xb02da8: bl              #0xd67e5c
    // 0xb02dac: LoadField: r0 = r3->field_4f
    //     0xb02dac: ldur            w0, [x3, #0x4f]
    // 0xb02db0: DecompressPointer r0
    //     0xb02db0: add             x0, x0, HEAP, lsl #32
    // 0xb02db4: stur            x0, [fp, #-8]
    // 0xb02db8: LoadField: r1 = r7->field_b
    //     0xb02db8: ldur            w1, [x7, #0xb]
    // 0xb02dbc: DecompressPointer r1
    //     0xb02dbc: add             x1, x1, HEAP, lsl #32
    // 0xb02dc0: cmp             w6, w1
    // 0xb02dc4: b.ne            #0xb02dd4
    // 0xb02dc8: SaveReg r2
    //     0xb02dc8: str             x2, [SP, #-8]!
    // 0xb02dcc: r0 = _growToNextCapacity()
    //     0xb02dcc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02dd0: add             SP, SP, #8
    // 0xb02dd4: ldr             x3, [fp, #0x10]
    // 0xb02dd8: ldur            x4, [fp, #-0x28]
    // 0xb02ddc: ldur            x2, [fp, #-0x18]
    // 0xb02de0: add             x5, x4, #1
    // 0xb02de4: stur            x5, [fp, #-0x20]
    // 0xb02de8: lsl             x6, x5, #1
    // 0xb02dec: StoreField: r2->field_b = r6
    //     0xb02dec: stur            w6, [x2, #0xb]
    // 0xb02df0: mov             x0, x5
    // 0xb02df4: mov             x1, x4
    // 0xb02df8: cmp             x1, x0
    // 0xb02dfc: b.hs            #0xb05628
    // 0xb02e00: LoadField: r7 = r2->field_f
    //     0xb02e00: ldur            w7, [x2, #0xf]
    // 0xb02e04: DecompressPointer r7
    //     0xb02e04: add             x7, x7, HEAP, lsl #32
    // 0xb02e08: mov             x1, x7
    // 0xb02e0c: ldur            x0, [fp, #-8]
    // 0xb02e10: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02e10: add             x25, x1, x4, lsl #2
    //     0xb02e14: add             x25, x25, #0xf
    //     0xb02e18: str             w0, [x25]
    //     0xb02e1c: tbz             w0, #0, #0xb02e38
    //     0xb02e20: ldurb           w16, [x1, #-1]
    //     0xb02e24: ldurb           w17, [x0, #-1]
    //     0xb02e28: and             x16, x17, x16, lsr #2
    //     0xb02e2c: tst             x16, HEAP, lsr #32
    //     0xb02e30: b.eq            #0xb02e38
    //     0xb02e34: bl              #0xd67e5c
    // 0xb02e38: LoadField: r0 = r3->field_53
    //     0xb02e38: ldur            w0, [x3, #0x53]
    // 0xb02e3c: DecompressPointer r0
    //     0xb02e3c: add             x0, x0, HEAP, lsl #32
    // 0xb02e40: stur            x0, [fp, #-8]
    // 0xb02e44: LoadField: r1 = r7->field_b
    //     0xb02e44: ldur            w1, [x7, #0xb]
    // 0xb02e48: DecompressPointer r1
    //     0xb02e48: add             x1, x1, HEAP, lsl #32
    // 0xb02e4c: cmp             w6, w1
    // 0xb02e50: b.ne            #0xb02e60
    // 0xb02e54: SaveReg r2
    //     0xb02e54: str             x2, [SP, #-8]!
    // 0xb02e58: r0 = _growToNextCapacity()
    //     0xb02e58: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02e5c: add             SP, SP, #8
    // 0xb02e60: ldr             x3, [fp, #0x10]
    // 0xb02e64: ldur            x4, [fp, #-0x20]
    // 0xb02e68: ldur            x2, [fp, #-0x18]
    // 0xb02e6c: add             x5, x4, #1
    // 0xb02e70: stur            x5, [fp, #-0x28]
    // 0xb02e74: lsl             x6, x5, #1
    // 0xb02e78: StoreField: r2->field_b = r6
    //     0xb02e78: stur            w6, [x2, #0xb]
    // 0xb02e7c: mov             x0, x5
    // 0xb02e80: mov             x1, x4
    // 0xb02e84: cmp             x1, x0
    // 0xb02e88: b.hs            #0xb0562c
    // 0xb02e8c: LoadField: r7 = r2->field_f
    //     0xb02e8c: ldur            w7, [x2, #0xf]
    // 0xb02e90: DecompressPointer r7
    //     0xb02e90: add             x7, x7, HEAP, lsl #32
    // 0xb02e94: mov             x1, x7
    // 0xb02e98: ldur            x0, [fp, #-8]
    // 0xb02e9c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02e9c: add             x25, x1, x4, lsl #2
    //     0xb02ea0: add             x25, x25, #0xf
    //     0xb02ea4: str             w0, [x25]
    //     0xb02ea8: tbz             w0, #0, #0xb02ec4
    //     0xb02eac: ldurb           w16, [x1, #-1]
    //     0xb02eb0: ldurb           w17, [x0, #-1]
    //     0xb02eb4: and             x16, x17, x16, lsr #2
    //     0xb02eb8: tst             x16, HEAP, lsr #32
    //     0xb02ebc: b.eq            #0xb02ec4
    //     0xb02ec0: bl              #0xd67e5c
    // 0xb02ec4: LoadField: r0 = r3->field_57
    //     0xb02ec4: ldur            w0, [x3, #0x57]
    // 0xb02ec8: DecompressPointer r0
    //     0xb02ec8: add             x0, x0, HEAP, lsl #32
    // 0xb02ecc: stur            x0, [fp, #-8]
    // 0xb02ed0: LoadField: r1 = r7->field_b
    //     0xb02ed0: ldur            w1, [x7, #0xb]
    // 0xb02ed4: DecompressPointer r1
    //     0xb02ed4: add             x1, x1, HEAP, lsl #32
    // 0xb02ed8: cmp             w6, w1
    // 0xb02edc: b.ne            #0xb02eec
    // 0xb02ee0: SaveReg r2
    //     0xb02ee0: str             x2, [SP, #-8]!
    // 0xb02ee4: r0 = _growToNextCapacity()
    //     0xb02ee4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02ee8: add             SP, SP, #8
    // 0xb02eec: ldr             x3, [fp, #0x10]
    // 0xb02ef0: ldur            x4, [fp, #-0x28]
    // 0xb02ef4: ldur            x2, [fp, #-0x18]
    // 0xb02ef8: add             x5, x4, #1
    // 0xb02efc: stur            x5, [fp, #-0x20]
    // 0xb02f00: lsl             x6, x5, #1
    // 0xb02f04: StoreField: r2->field_b = r6
    //     0xb02f04: stur            w6, [x2, #0xb]
    // 0xb02f08: mov             x0, x5
    // 0xb02f0c: mov             x1, x4
    // 0xb02f10: cmp             x1, x0
    // 0xb02f14: b.hs            #0xb05630
    // 0xb02f18: LoadField: r7 = r2->field_f
    //     0xb02f18: ldur            w7, [x2, #0xf]
    // 0xb02f1c: DecompressPointer r7
    //     0xb02f1c: add             x7, x7, HEAP, lsl #32
    // 0xb02f20: mov             x1, x7
    // 0xb02f24: ldur            x0, [fp, #-8]
    // 0xb02f28: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02f28: add             x25, x1, x4, lsl #2
    //     0xb02f2c: add             x25, x25, #0xf
    //     0xb02f30: str             w0, [x25]
    //     0xb02f34: tbz             w0, #0, #0xb02f50
    //     0xb02f38: ldurb           w16, [x1, #-1]
    //     0xb02f3c: ldurb           w17, [x0, #-1]
    //     0xb02f40: and             x16, x17, x16, lsr #2
    //     0xb02f44: tst             x16, HEAP, lsr #32
    //     0xb02f48: b.eq            #0xb02f50
    //     0xb02f4c: bl              #0xd67e5c
    // 0xb02f50: LoadField: r0 = r3->field_5b
    //     0xb02f50: ldur            w0, [x3, #0x5b]
    // 0xb02f54: DecompressPointer r0
    //     0xb02f54: add             x0, x0, HEAP, lsl #32
    // 0xb02f58: stur            x0, [fp, #-8]
    // 0xb02f5c: LoadField: r1 = r7->field_b
    //     0xb02f5c: ldur            w1, [x7, #0xb]
    // 0xb02f60: DecompressPointer r1
    //     0xb02f60: add             x1, x1, HEAP, lsl #32
    // 0xb02f64: cmp             w6, w1
    // 0xb02f68: b.ne            #0xb02f78
    // 0xb02f6c: SaveReg r2
    //     0xb02f6c: str             x2, [SP, #-8]!
    // 0xb02f70: r0 = _growToNextCapacity()
    //     0xb02f70: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb02f74: add             SP, SP, #8
    // 0xb02f78: ldr             x3, [fp, #0x10]
    // 0xb02f7c: ldur            x4, [fp, #-0x20]
    // 0xb02f80: ldur            x2, [fp, #-0x18]
    // 0xb02f84: add             x5, x4, #1
    // 0xb02f88: stur            x5, [fp, #-0x28]
    // 0xb02f8c: lsl             x6, x5, #1
    // 0xb02f90: StoreField: r2->field_b = r6
    //     0xb02f90: stur            w6, [x2, #0xb]
    // 0xb02f94: mov             x0, x5
    // 0xb02f98: mov             x1, x4
    // 0xb02f9c: cmp             x1, x0
    // 0xb02fa0: b.hs            #0xb05634
    // 0xb02fa4: LoadField: r7 = r2->field_f
    //     0xb02fa4: ldur            w7, [x2, #0xf]
    // 0xb02fa8: DecompressPointer r7
    //     0xb02fa8: add             x7, x7, HEAP, lsl #32
    // 0xb02fac: mov             x1, x7
    // 0xb02fb0: ldur            x0, [fp, #-8]
    // 0xb02fb4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb02fb4: add             x25, x1, x4, lsl #2
    //     0xb02fb8: add             x25, x25, #0xf
    //     0xb02fbc: str             w0, [x25]
    //     0xb02fc0: tbz             w0, #0, #0xb02fdc
    //     0xb02fc4: ldurb           w16, [x1, #-1]
    //     0xb02fc8: ldurb           w17, [x0, #-1]
    //     0xb02fcc: and             x16, x17, x16, lsr #2
    //     0xb02fd0: tst             x16, HEAP, lsr #32
    //     0xb02fd4: b.eq            #0xb02fdc
    //     0xb02fd8: bl              #0xd67e5c
    // 0xb02fdc: LoadField: r0 = r3->field_5f
    //     0xb02fdc: ldur            w0, [x3, #0x5f]
    // 0xb02fe0: DecompressPointer r0
    //     0xb02fe0: add             x0, x0, HEAP, lsl #32
    // 0xb02fe4: stur            x0, [fp, #-8]
    // 0xb02fe8: LoadField: r1 = r7->field_b
    //     0xb02fe8: ldur            w1, [x7, #0xb]
    // 0xb02fec: DecompressPointer r1
    //     0xb02fec: add             x1, x1, HEAP, lsl #32
    // 0xb02ff0: cmp             w6, w1
    // 0xb02ff4: b.ne            #0xb03004
    // 0xb02ff8: SaveReg r2
    //     0xb02ff8: str             x2, [SP, #-8]!
    // 0xb02ffc: r0 = _growToNextCapacity()
    //     0xb02ffc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03000: add             SP, SP, #8
    // 0xb03004: ldr             x3, [fp, #0x10]
    // 0xb03008: ldur            x4, [fp, #-0x28]
    // 0xb0300c: ldur            x2, [fp, #-0x18]
    // 0xb03010: add             x5, x4, #1
    // 0xb03014: stur            x5, [fp, #-0x20]
    // 0xb03018: lsl             x6, x5, #1
    // 0xb0301c: StoreField: r2->field_b = r6
    //     0xb0301c: stur            w6, [x2, #0xb]
    // 0xb03020: mov             x0, x5
    // 0xb03024: mov             x1, x4
    // 0xb03028: cmp             x1, x0
    // 0xb0302c: b.hs            #0xb05638
    // 0xb03030: LoadField: r7 = r2->field_f
    //     0xb03030: ldur            w7, [x2, #0xf]
    // 0xb03034: DecompressPointer r7
    //     0xb03034: add             x7, x7, HEAP, lsl #32
    // 0xb03038: mov             x1, x7
    // 0xb0303c: ldur            x0, [fp, #-8]
    // 0xb03040: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03040: add             x25, x1, x4, lsl #2
    //     0xb03044: add             x25, x25, #0xf
    //     0xb03048: str             w0, [x25]
    //     0xb0304c: tbz             w0, #0, #0xb03068
    //     0xb03050: ldurb           w16, [x1, #-1]
    //     0xb03054: ldurb           w17, [x0, #-1]
    //     0xb03058: and             x16, x17, x16, lsr #2
    //     0xb0305c: tst             x16, HEAP, lsr #32
    //     0xb03060: b.eq            #0xb03068
    //     0xb03064: bl              #0xd67e5c
    // 0xb03068: LoadField: r0 = r3->field_63
    //     0xb03068: ldur            w0, [x3, #0x63]
    // 0xb0306c: DecompressPointer r0
    //     0xb0306c: add             x0, x0, HEAP, lsl #32
    // 0xb03070: stur            x0, [fp, #-8]
    // 0xb03074: LoadField: r1 = r7->field_b
    //     0xb03074: ldur            w1, [x7, #0xb]
    // 0xb03078: DecompressPointer r1
    //     0xb03078: add             x1, x1, HEAP, lsl #32
    // 0xb0307c: cmp             w6, w1
    // 0xb03080: b.ne            #0xb03090
    // 0xb03084: SaveReg r2
    //     0xb03084: str             x2, [SP, #-8]!
    // 0xb03088: r0 = _growToNextCapacity()
    //     0xb03088: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0308c: add             SP, SP, #8
    // 0xb03090: ldr             x3, [fp, #0x10]
    // 0xb03094: ldur            x4, [fp, #-0x20]
    // 0xb03098: ldur            x2, [fp, #-0x18]
    // 0xb0309c: add             x5, x4, #1
    // 0xb030a0: stur            x5, [fp, #-0x28]
    // 0xb030a4: lsl             x6, x5, #1
    // 0xb030a8: StoreField: r2->field_b = r6
    //     0xb030a8: stur            w6, [x2, #0xb]
    // 0xb030ac: mov             x0, x5
    // 0xb030b0: mov             x1, x4
    // 0xb030b4: cmp             x1, x0
    // 0xb030b8: b.hs            #0xb0563c
    // 0xb030bc: LoadField: r7 = r2->field_f
    //     0xb030bc: ldur            w7, [x2, #0xf]
    // 0xb030c0: DecompressPointer r7
    //     0xb030c0: add             x7, x7, HEAP, lsl #32
    // 0xb030c4: mov             x1, x7
    // 0xb030c8: ldur            x0, [fp, #-8]
    // 0xb030cc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb030cc: add             x25, x1, x4, lsl #2
    //     0xb030d0: add             x25, x25, #0xf
    //     0xb030d4: str             w0, [x25]
    //     0xb030d8: tbz             w0, #0, #0xb030f4
    //     0xb030dc: ldurb           w16, [x1, #-1]
    //     0xb030e0: ldurb           w17, [x0, #-1]
    //     0xb030e4: and             x16, x17, x16, lsr #2
    //     0xb030e8: tst             x16, HEAP, lsr #32
    //     0xb030ec: b.eq            #0xb030f4
    //     0xb030f0: bl              #0xd67e5c
    // 0xb030f4: LoadField: r0 = r3->field_67
    //     0xb030f4: ldur            w0, [x3, #0x67]
    // 0xb030f8: DecompressPointer r0
    //     0xb030f8: add             x0, x0, HEAP, lsl #32
    // 0xb030fc: stur            x0, [fp, #-8]
    // 0xb03100: LoadField: r1 = r7->field_b
    //     0xb03100: ldur            w1, [x7, #0xb]
    // 0xb03104: DecompressPointer r1
    //     0xb03104: add             x1, x1, HEAP, lsl #32
    // 0xb03108: cmp             w6, w1
    // 0xb0310c: b.ne            #0xb0311c
    // 0xb03110: SaveReg r2
    //     0xb03110: str             x2, [SP, #-8]!
    // 0xb03114: r0 = _growToNextCapacity()
    //     0xb03114: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03118: add             SP, SP, #8
    // 0xb0311c: ldr             x3, [fp, #0x10]
    // 0xb03120: ldur            x4, [fp, #-0x28]
    // 0xb03124: ldur            x2, [fp, #-0x18]
    // 0xb03128: add             x5, x4, #1
    // 0xb0312c: stur            x5, [fp, #-0x20]
    // 0xb03130: lsl             x6, x5, #1
    // 0xb03134: StoreField: r2->field_b = r6
    //     0xb03134: stur            w6, [x2, #0xb]
    // 0xb03138: mov             x0, x5
    // 0xb0313c: mov             x1, x4
    // 0xb03140: cmp             x1, x0
    // 0xb03144: b.hs            #0xb05640
    // 0xb03148: LoadField: r7 = r2->field_f
    //     0xb03148: ldur            w7, [x2, #0xf]
    // 0xb0314c: DecompressPointer r7
    //     0xb0314c: add             x7, x7, HEAP, lsl #32
    // 0xb03150: mov             x1, x7
    // 0xb03154: ldur            x0, [fp, #-8]
    // 0xb03158: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03158: add             x25, x1, x4, lsl #2
    //     0xb0315c: add             x25, x25, #0xf
    //     0xb03160: str             w0, [x25]
    //     0xb03164: tbz             w0, #0, #0xb03180
    //     0xb03168: ldurb           w16, [x1, #-1]
    //     0xb0316c: ldurb           w17, [x0, #-1]
    //     0xb03170: and             x16, x17, x16, lsr #2
    //     0xb03174: tst             x16, HEAP, lsr #32
    //     0xb03178: b.eq            #0xb03180
    //     0xb0317c: bl              #0xd67e5c
    // 0xb03180: LoadField: r0 = r3->field_6b
    //     0xb03180: ldur            w0, [x3, #0x6b]
    // 0xb03184: DecompressPointer r0
    //     0xb03184: add             x0, x0, HEAP, lsl #32
    // 0xb03188: stur            x0, [fp, #-8]
    // 0xb0318c: LoadField: r1 = r7->field_b
    //     0xb0318c: ldur            w1, [x7, #0xb]
    // 0xb03190: DecompressPointer r1
    //     0xb03190: add             x1, x1, HEAP, lsl #32
    // 0xb03194: cmp             w6, w1
    // 0xb03198: b.ne            #0xb031a8
    // 0xb0319c: SaveReg r2
    //     0xb0319c: str             x2, [SP, #-8]!
    // 0xb031a0: r0 = _growToNextCapacity()
    //     0xb031a0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb031a4: add             SP, SP, #8
    // 0xb031a8: ldr             x3, [fp, #0x10]
    // 0xb031ac: ldur            x4, [fp, #-0x20]
    // 0xb031b0: ldur            x2, [fp, #-0x18]
    // 0xb031b4: add             x5, x4, #1
    // 0xb031b8: stur            x5, [fp, #-0x28]
    // 0xb031bc: lsl             x6, x5, #1
    // 0xb031c0: StoreField: r2->field_b = r6
    //     0xb031c0: stur            w6, [x2, #0xb]
    // 0xb031c4: mov             x0, x5
    // 0xb031c8: mov             x1, x4
    // 0xb031cc: cmp             x1, x0
    // 0xb031d0: b.hs            #0xb05644
    // 0xb031d4: LoadField: r7 = r2->field_f
    //     0xb031d4: ldur            w7, [x2, #0xf]
    // 0xb031d8: DecompressPointer r7
    //     0xb031d8: add             x7, x7, HEAP, lsl #32
    // 0xb031dc: mov             x1, x7
    // 0xb031e0: ldur            x0, [fp, #-8]
    // 0xb031e4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb031e4: add             x25, x1, x4, lsl #2
    //     0xb031e8: add             x25, x25, #0xf
    //     0xb031ec: str             w0, [x25]
    //     0xb031f0: tbz             w0, #0, #0xb0320c
    //     0xb031f4: ldurb           w16, [x1, #-1]
    //     0xb031f8: ldurb           w17, [x0, #-1]
    //     0xb031fc: and             x16, x17, x16, lsr #2
    //     0xb03200: tst             x16, HEAP, lsr #32
    //     0xb03204: b.eq            #0xb0320c
    //     0xb03208: bl              #0xd67e5c
    // 0xb0320c: LoadField: r0 = r3->field_6f
    //     0xb0320c: ldur            w0, [x3, #0x6f]
    // 0xb03210: DecompressPointer r0
    //     0xb03210: add             x0, x0, HEAP, lsl #32
    // 0xb03214: stur            x0, [fp, #-8]
    // 0xb03218: LoadField: r1 = r7->field_b
    //     0xb03218: ldur            w1, [x7, #0xb]
    // 0xb0321c: DecompressPointer r1
    //     0xb0321c: add             x1, x1, HEAP, lsl #32
    // 0xb03220: cmp             w6, w1
    // 0xb03224: b.ne            #0xb03234
    // 0xb03228: SaveReg r2
    //     0xb03228: str             x2, [SP, #-8]!
    // 0xb0322c: r0 = _growToNextCapacity()
    //     0xb0322c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03230: add             SP, SP, #8
    // 0xb03234: ldr             x3, [fp, #0x10]
    // 0xb03238: ldur            x4, [fp, #-0x28]
    // 0xb0323c: ldur            x2, [fp, #-0x18]
    // 0xb03240: add             x5, x4, #1
    // 0xb03244: stur            x5, [fp, #-0x20]
    // 0xb03248: lsl             x6, x5, #1
    // 0xb0324c: StoreField: r2->field_b = r6
    //     0xb0324c: stur            w6, [x2, #0xb]
    // 0xb03250: mov             x0, x5
    // 0xb03254: mov             x1, x4
    // 0xb03258: cmp             x1, x0
    // 0xb0325c: b.hs            #0xb05648
    // 0xb03260: LoadField: r7 = r2->field_f
    //     0xb03260: ldur            w7, [x2, #0xf]
    // 0xb03264: DecompressPointer r7
    //     0xb03264: add             x7, x7, HEAP, lsl #32
    // 0xb03268: mov             x1, x7
    // 0xb0326c: ldur            x0, [fp, #-8]
    // 0xb03270: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03270: add             x25, x1, x4, lsl #2
    //     0xb03274: add             x25, x25, #0xf
    //     0xb03278: str             w0, [x25]
    //     0xb0327c: tbz             w0, #0, #0xb03298
    //     0xb03280: ldurb           w16, [x1, #-1]
    //     0xb03284: ldurb           w17, [x0, #-1]
    //     0xb03288: and             x16, x17, x16, lsr #2
    //     0xb0328c: tst             x16, HEAP, lsr #32
    //     0xb03290: b.eq            #0xb03298
    //     0xb03294: bl              #0xd67e5c
    // 0xb03298: LoadField: r0 = r3->field_73
    //     0xb03298: ldur            w0, [x3, #0x73]
    // 0xb0329c: DecompressPointer r0
    //     0xb0329c: add             x0, x0, HEAP, lsl #32
    // 0xb032a0: stur            x0, [fp, #-8]
    // 0xb032a4: LoadField: r1 = r7->field_b
    //     0xb032a4: ldur            w1, [x7, #0xb]
    // 0xb032a8: DecompressPointer r1
    //     0xb032a8: add             x1, x1, HEAP, lsl #32
    // 0xb032ac: cmp             w6, w1
    // 0xb032b0: b.ne            #0xb032c0
    // 0xb032b4: SaveReg r2
    //     0xb032b4: str             x2, [SP, #-8]!
    // 0xb032b8: r0 = _growToNextCapacity()
    //     0xb032b8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb032bc: add             SP, SP, #8
    // 0xb032c0: ldr             x3, [fp, #0x10]
    // 0xb032c4: ldur            x4, [fp, #-0x20]
    // 0xb032c8: ldur            x2, [fp, #-0x18]
    // 0xb032cc: add             x5, x4, #1
    // 0xb032d0: stur            x5, [fp, #-0x28]
    // 0xb032d4: lsl             x6, x5, #1
    // 0xb032d8: StoreField: r2->field_b = r6
    //     0xb032d8: stur            w6, [x2, #0xb]
    // 0xb032dc: mov             x0, x5
    // 0xb032e0: mov             x1, x4
    // 0xb032e4: cmp             x1, x0
    // 0xb032e8: b.hs            #0xb0564c
    // 0xb032ec: LoadField: r7 = r2->field_f
    //     0xb032ec: ldur            w7, [x2, #0xf]
    // 0xb032f0: DecompressPointer r7
    //     0xb032f0: add             x7, x7, HEAP, lsl #32
    // 0xb032f4: mov             x1, x7
    // 0xb032f8: ldur            x0, [fp, #-8]
    // 0xb032fc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb032fc: add             x25, x1, x4, lsl #2
    //     0xb03300: add             x25, x25, #0xf
    //     0xb03304: str             w0, [x25]
    //     0xb03308: tbz             w0, #0, #0xb03324
    //     0xb0330c: ldurb           w16, [x1, #-1]
    //     0xb03310: ldurb           w17, [x0, #-1]
    //     0xb03314: and             x16, x17, x16, lsr #2
    //     0xb03318: tst             x16, HEAP, lsr #32
    //     0xb0331c: b.eq            #0xb03324
    //     0xb03320: bl              #0xd67e5c
    // 0xb03324: LoadField: r0 = r3->field_7b
    //     0xb03324: ldur            w0, [x3, #0x7b]
    // 0xb03328: DecompressPointer r0
    //     0xb03328: add             x0, x0, HEAP, lsl #32
    // 0xb0332c: stur            x0, [fp, #-8]
    // 0xb03330: LoadField: r1 = r7->field_b
    //     0xb03330: ldur            w1, [x7, #0xb]
    // 0xb03334: DecompressPointer r1
    //     0xb03334: add             x1, x1, HEAP, lsl #32
    // 0xb03338: cmp             w6, w1
    // 0xb0333c: b.ne            #0xb0334c
    // 0xb03340: SaveReg r2
    //     0xb03340: str             x2, [SP, #-8]!
    // 0xb03344: r0 = _growToNextCapacity()
    //     0xb03344: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03348: add             SP, SP, #8
    // 0xb0334c: ldr             x3, [fp, #0x10]
    // 0xb03350: ldur            x4, [fp, #-0x28]
    // 0xb03354: ldur            x2, [fp, #-0x18]
    // 0xb03358: add             x5, x4, #1
    // 0xb0335c: stur            x5, [fp, #-0x20]
    // 0xb03360: lsl             x6, x5, #1
    // 0xb03364: StoreField: r2->field_b = r6
    //     0xb03364: stur            w6, [x2, #0xb]
    // 0xb03368: mov             x0, x5
    // 0xb0336c: mov             x1, x4
    // 0xb03370: cmp             x1, x0
    // 0xb03374: b.hs            #0xb05650
    // 0xb03378: LoadField: r7 = r2->field_f
    //     0xb03378: ldur            w7, [x2, #0xf]
    // 0xb0337c: DecompressPointer r7
    //     0xb0337c: add             x7, x7, HEAP, lsl #32
    // 0xb03380: mov             x1, x7
    // 0xb03384: ldur            x0, [fp, #-8]
    // 0xb03388: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03388: add             x25, x1, x4, lsl #2
    //     0xb0338c: add             x25, x25, #0xf
    //     0xb03390: str             w0, [x25]
    //     0xb03394: tbz             w0, #0, #0xb033b0
    //     0xb03398: ldurb           w16, [x1, #-1]
    //     0xb0339c: ldurb           w17, [x0, #-1]
    //     0xb033a0: and             x16, x17, x16, lsr #2
    //     0xb033a4: tst             x16, HEAP, lsr #32
    //     0xb033a8: b.eq            #0xb033b0
    //     0xb033ac: bl              #0xd67e5c
    // 0xb033b0: LoadField: r0 = r3->field_7f
    //     0xb033b0: ldur            w0, [x3, #0x7f]
    // 0xb033b4: DecompressPointer r0
    //     0xb033b4: add             x0, x0, HEAP, lsl #32
    // 0xb033b8: stur            x0, [fp, #-8]
    // 0xb033bc: LoadField: r1 = r7->field_b
    //     0xb033bc: ldur            w1, [x7, #0xb]
    // 0xb033c0: DecompressPointer r1
    //     0xb033c0: add             x1, x1, HEAP, lsl #32
    // 0xb033c4: cmp             w6, w1
    // 0xb033c8: b.ne            #0xb033d8
    // 0xb033cc: SaveReg r2
    //     0xb033cc: str             x2, [SP, #-8]!
    // 0xb033d0: r0 = _growToNextCapacity()
    //     0xb033d0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb033d4: add             SP, SP, #8
    // 0xb033d8: ldr             x3, [fp, #0x10]
    // 0xb033dc: ldur            x4, [fp, #-0x20]
    // 0xb033e0: ldur            x2, [fp, #-0x18]
    // 0xb033e4: add             x5, x4, #1
    // 0xb033e8: stur            x5, [fp, #-0x28]
    // 0xb033ec: lsl             x6, x5, #1
    // 0xb033f0: StoreField: r2->field_b = r6
    //     0xb033f0: stur            w6, [x2, #0xb]
    // 0xb033f4: mov             x0, x5
    // 0xb033f8: mov             x1, x4
    // 0xb033fc: cmp             x1, x0
    // 0xb03400: b.hs            #0xb05654
    // 0xb03404: LoadField: r7 = r2->field_f
    //     0xb03404: ldur            w7, [x2, #0xf]
    // 0xb03408: DecompressPointer r7
    //     0xb03408: add             x7, x7, HEAP, lsl #32
    // 0xb0340c: mov             x1, x7
    // 0xb03410: ldur            x0, [fp, #-8]
    // 0xb03414: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03414: add             x25, x1, x4, lsl #2
    //     0xb03418: add             x25, x25, #0xf
    //     0xb0341c: str             w0, [x25]
    //     0xb03420: tbz             w0, #0, #0xb0343c
    //     0xb03424: ldurb           w16, [x1, #-1]
    //     0xb03428: ldurb           w17, [x0, #-1]
    //     0xb0342c: and             x16, x17, x16, lsr #2
    //     0xb03430: tst             x16, HEAP, lsr #32
    //     0xb03434: b.eq            #0xb0343c
    //     0xb03438: bl              #0xd67e5c
    // 0xb0343c: LoadField: r0 = r3->field_83
    //     0xb0343c: ldur            w0, [x3, #0x83]
    // 0xb03440: DecompressPointer r0
    //     0xb03440: add             x0, x0, HEAP, lsl #32
    // 0xb03444: stur            x0, [fp, #-8]
    // 0xb03448: LoadField: r1 = r7->field_b
    //     0xb03448: ldur            w1, [x7, #0xb]
    // 0xb0344c: DecompressPointer r1
    //     0xb0344c: add             x1, x1, HEAP, lsl #32
    // 0xb03450: cmp             w6, w1
    // 0xb03454: b.ne            #0xb03464
    // 0xb03458: SaveReg r2
    //     0xb03458: str             x2, [SP, #-8]!
    // 0xb0345c: r0 = _growToNextCapacity()
    //     0xb0345c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03460: add             SP, SP, #8
    // 0xb03464: ldr             x3, [fp, #0x10]
    // 0xb03468: ldur            x4, [fp, #-0x28]
    // 0xb0346c: ldur            x2, [fp, #-0x18]
    // 0xb03470: add             x5, x4, #1
    // 0xb03474: stur            x5, [fp, #-0x20]
    // 0xb03478: lsl             x6, x5, #1
    // 0xb0347c: StoreField: r2->field_b = r6
    //     0xb0347c: stur            w6, [x2, #0xb]
    // 0xb03480: mov             x0, x5
    // 0xb03484: mov             x1, x4
    // 0xb03488: cmp             x1, x0
    // 0xb0348c: b.hs            #0xb05658
    // 0xb03490: LoadField: r7 = r2->field_f
    //     0xb03490: ldur            w7, [x2, #0xf]
    // 0xb03494: DecompressPointer r7
    //     0xb03494: add             x7, x7, HEAP, lsl #32
    // 0xb03498: mov             x1, x7
    // 0xb0349c: ldur            x0, [fp, #-8]
    // 0xb034a0: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb034a0: add             x25, x1, x4, lsl #2
    //     0xb034a4: add             x25, x25, #0xf
    //     0xb034a8: str             w0, [x25]
    //     0xb034ac: tbz             w0, #0, #0xb034c8
    //     0xb034b0: ldurb           w16, [x1, #-1]
    //     0xb034b4: ldurb           w17, [x0, #-1]
    //     0xb034b8: and             x16, x17, x16, lsr #2
    //     0xb034bc: tst             x16, HEAP, lsr #32
    //     0xb034c0: b.eq            #0xb034c8
    //     0xb034c4: bl              #0xd67e5c
    // 0xb034c8: LoadField: r0 = r3->field_87
    //     0xb034c8: ldur            w0, [x3, #0x87]
    // 0xb034cc: DecompressPointer r0
    //     0xb034cc: add             x0, x0, HEAP, lsl #32
    // 0xb034d0: stur            x0, [fp, #-8]
    // 0xb034d4: LoadField: r1 = r7->field_b
    //     0xb034d4: ldur            w1, [x7, #0xb]
    // 0xb034d8: DecompressPointer r1
    //     0xb034d8: add             x1, x1, HEAP, lsl #32
    // 0xb034dc: cmp             w6, w1
    // 0xb034e0: b.ne            #0xb034f0
    // 0xb034e4: SaveReg r2
    //     0xb034e4: str             x2, [SP, #-8]!
    // 0xb034e8: r0 = _growToNextCapacity()
    //     0xb034e8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb034ec: add             SP, SP, #8
    // 0xb034f0: ldr             x3, [fp, #0x10]
    // 0xb034f4: ldur            x4, [fp, #-0x20]
    // 0xb034f8: ldur            x2, [fp, #-0x18]
    // 0xb034fc: add             x5, x4, #1
    // 0xb03500: stur            x5, [fp, #-0x28]
    // 0xb03504: lsl             x6, x5, #1
    // 0xb03508: StoreField: r2->field_b = r6
    //     0xb03508: stur            w6, [x2, #0xb]
    // 0xb0350c: mov             x0, x5
    // 0xb03510: mov             x1, x4
    // 0xb03514: cmp             x1, x0
    // 0xb03518: b.hs            #0xb0565c
    // 0xb0351c: LoadField: r7 = r2->field_f
    //     0xb0351c: ldur            w7, [x2, #0xf]
    // 0xb03520: DecompressPointer r7
    //     0xb03520: add             x7, x7, HEAP, lsl #32
    // 0xb03524: mov             x1, x7
    // 0xb03528: ldur            x0, [fp, #-8]
    // 0xb0352c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb0352c: add             x25, x1, x4, lsl #2
    //     0xb03530: add             x25, x25, #0xf
    //     0xb03534: str             w0, [x25]
    //     0xb03538: tbz             w0, #0, #0xb03554
    //     0xb0353c: ldurb           w16, [x1, #-1]
    //     0xb03540: ldurb           w17, [x0, #-1]
    //     0xb03544: and             x16, x17, x16, lsr #2
    //     0xb03548: tst             x16, HEAP, lsr #32
    //     0xb0354c: b.eq            #0xb03554
    //     0xb03550: bl              #0xd67e5c
    // 0xb03554: LoadField: r0 = r3->field_8b
    //     0xb03554: ldur            w0, [x3, #0x8b]
    // 0xb03558: DecompressPointer r0
    //     0xb03558: add             x0, x0, HEAP, lsl #32
    // 0xb0355c: stur            x0, [fp, #-8]
    // 0xb03560: LoadField: r1 = r7->field_b
    //     0xb03560: ldur            w1, [x7, #0xb]
    // 0xb03564: DecompressPointer r1
    //     0xb03564: add             x1, x1, HEAP, lsl #32
    // 0xb03568: cmp             w6, w1
    // 0xb0356c: b.ne            #0xb0357c
    // 0xb03570: SaveReg r2
    //     0xb03570: str             x2, [SP, #-8]!
    // 0xb03574: r0 = _growToNextCapacity()
    //     0xb03574: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03578: add             SP, SP, #8
    // 0xb0357c: ldr             x3, [fp, #0x10]
    // 0xb03580: ldur            x4, [fp, #-0x28]
    // 0xb03584: ldur            x2, [fp, #-0x18]
    // 0xb03588: add             x5, x4, #1
    // 0xb0358c: stur            x5, [fp, #-0x20]
    // 0xb03590: lsl             x6, x5, #1
    // 0xb03594: StoreField: r2->field_b = r6
    //     0xb03594: stur            w6, [x2, #0xb]
    // 0xb03598: mov             x0, x5
    // 0xb0359c: mov             x1, x4
    // 0xb035a0: cmp             x1, x0
    // 0xb035a4: b.hs            #0xb05660
    // 0xb035a8: LoadField: r7 = r2->field_f
    //     0xb035a8: ldur            w7, [x2, #0xf]
    // 0xb035ac: DecompressPointer r7
    //     0xb035ac: add             x7, x7, HEAP, lsl #32
    // 0xb035b0: mov             x1, x7
    // 0xb035b4: ldur            x0, [fp, #-8]
    // 0xb035b8: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb035b8: add             x25, x1, x4, lsl #2
    //     0xb035bc: add             x25, x25, #0xf
    //     0xb035c0: str             w0, [x25]
    //     0xb035c4: tbz             w0, #0, #0xb035e0
    //     0xb035c8: ldurb           w16, [x1, #-1]
    //     0xb035cc: ldurb           w17, [x0, #-1]
    //     0xb035d0: and             x16, x17, x16, lsr #2
    //     0xb035d4: tst             x16, HEAP, lsr #32
    //     0xb035d8: b.eq            #0xb035e0
    //     0xb035dc: bl              #0xd67e5c
    // 0xb035e0: LoadField: r0 = r3->field_8f
    //     0xb035e0: ldur            w0, [x3, #0x8f]
    // 0xb035e4: DecompressPointer r0
    //     0xb035e4: add             x0, x0, HEAP, lsl #32
    // 0xb035e8: stur            x0, [fp, #-8]
    // 0xb035ec: LoadField: r1 = r7->field_b
    //     0xb035ec: ldur            w1, [x7, #0xb]
    // 0xb035f0: DecompressPointer r1
    //     0xb035f0: add             x1, x1, HEAP, lsl #32
    // 0xb035f4: cmp             w6, w1
    // 0xb035f8: b.ne            #0xb03608
    // 0xb035fc: SaveReg r2
    //     0xb035fc: str             x2, [SP, #-8]!
    // 0xb03600: r0 = _growToNextCapacity()
    //     0xb03600: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03604: add             SP, SP, #8
    // 0xb03608: ldr             x3, [fp, #0x10]
    // 0xb0360c: ldur            x4, [fp, #-0x20]
    // 0xb03610: ldur            x2, [fp, #-0x18]
    // 0xb03614: add             x5, x4, #1
    // 0xb03618: stur            x5, [fp, #-0x28]
    // 0xb0361c: lsl             x6, x5, #1
    // 0xb03620: StoreField: r2->field_b = r6
    //     0xb03620: stur            w6, [x2, #0xb]
    // 0xb03624: mov             x0, x5
    // 0xb03628: mov             x1, x4
    // 0xb0362c: cmp             x1, x0
    // 0xb03630: b.hs            #0xb05664
    // 0xb03634: LoadField: r7 = r2->field_f
    //     0xb03634: ldur            w7, [x2, #0xf]
    // 0xb03638: DecompressPointer r7
    //     0xb03638: add             x7, x7, HEAP, lsl #32
    // 0xb0363c: mov             x1, x7
    // 0xb03640: ldur            x0, [fp, #-8]
    // 0xb03644: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03644: add             x25, x1, x4, lsl #2
    //     0xb03648: add             x25, x25, #0xf
    //     0xb0364c: str             w0, [x25]
    //     0xb03650: tbz             w0, #0, #0xb0366c
    //     0xb03654: ldurb           w16, [x1, #-1]
    //     0xb03658: ldurb           w17, [x0, #-1]
    //     0xb0365c: and             x16, x17, x16, lsr #2
    //     0xb03660: tst             x16, HEAP, lsr #32
    //     0xb03664: b.eq            #0xb0366c
    //     0xb03668: bl              #0xd67e5c
    // 0xb0366c: LoadField: r0 = r3->field_93
    //     0xb0366c: ldur            w0, [x3, #0x93]
    // 0xb03670: DecompressPointer r0
    //     0xb03670: add             x0, x0, HEAP, lsl #32
    // 0xb03674: stur            x0, [fp, #-8]
    // 0xb03678: LoadField: r1 = r7->field_b
    //     0xb03678: ldur            w1, [x7, #0xb]
    // 0xb0367c: DecompressPointer r1
    //     0xb0367c: add             x1, x1, HEAP, lsl #32
    // 0xb03680: cmp             w6, w1
    // 0xb03684: b.ne            #0xb03694
    // 0xb03688: SaveReg r2
    //     0xb03688: str             x2, [SP, #-8]!
    // 0xb0368c: r0 = _growToNextCapacity()
    //     0xb0368c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03690: add             SP, SP, #8
    // 0xb03694: ldr             x3, [fp, #0x10]
    // 0xb03698: ldur            x4, [fp, #-0x28]
    // 0xb0369c: ldur            x2, [fp, #-0x18]
    // 0xb036a0: add             x5, x4, #1
    // 0xb036a4: stur            x5, [fp, #-0x20]
    // 0xb036a8: lsl             x6, x5, #1
    // 0xb036ac: StoreField: r2->field_b = r6
    //     0xb036ac: stur            w6, [x2, #0xb]
    // 0xb036b0: mov             x0, x5
    // 0xb036b4: mov             x1, x4
    // 0xb036b8: cmp             x1, x0
    // 0xb036bc: b.hs            #0xb05668
    // 0xb036c0: LoadField: r7 = r2->field_f
    //     0xb036c0: ldur            w7, [x2, #0xf]
    // 0xb036c4: DecompressPointer r7
    //     0xb036c4: add             x7, x7, HEAP, lsl #32
    // 0xb036c8: mov             x1, x7
    // 0xb036cc: ldur            x0, [fp, #-8]
    // 0xb036d0: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb036d0: add             x25, x1, x4, lsl #2
    //     0xb036d4: add             x25, x25, #0xf
    //     0xb036d8: str             w0, [x25]
    //     0xb036dc: tbz             w0, #0, #0xb036f8
    //     0xb036e0: ldurb           w16, [x1, #-1]
    //     0xb036e4: ldurb           w17, [x0, #-1]
    //     0xb036e8: and             x16, x17, x16, lsr #2
    //     0xb036ec: tst             x16, HEAP, lsr #32
    //     0xb036f0: b.eq            #0xb036f8
    //     0xb036f4: bl              #0xd67e5c
    // 0xb036f8: LoadField: r0 = r3->field_97
    //     0xb036f8: ldur            w0, [x3, #0x97]
    // 0xb036fc: DecompressPointer r0
    //     0xb036fc: add             x0, x0, HEAP, lsl #32
    // 0xb03700: stur            x0, [fp, #-8]
    // 0xb03704: LoadField: r1 = r7->field_b
    //     0xb03704: ldur            w1, [x7, #0xb]
    // 0xb03708: DecompressPointer r1
    //     0xb03708: add             x1, x1, HEAP, lsl #32
    // 0xb0370c: cmp             w6, w1
    // 0xb03710: b.ne            #0xb03720
    // 0xb03714: SaveReg r2
    //     0xb03714: str             x2, [SP, #-8]!
    // 0xb03718: r0 = _growToNextCapacity()
    //     0xb03718: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0371c: add             SP, SP, #8
    // 0xb03720: ldr             x3, [fp, #0x10]
    // 0xb03724: ldur            x4, [fp, #-0x20]
    // 0xb03728: ldur            x2, [fp, #-0x18]
    // 0xb0372c: add             x5, x4, #1
    // 0xb03730: stur            x5, [fp, #-0x28]
    // 0xb03734: lsl             x6, x5, #1
    // 0xb03738: StoreField: r2->field_b = r6
    //     0xb03738: stur            w6, [x2, #0xb]
    // 0xb0373c: mov             x0, x5
    // 0xb03740: mov             x1, x4
    // 0xb03744: cmp             x1, x0
    // 0xb03748: b.hs            #0xb0566c
    // 0xb0374c: LoadField: r7 = r2->field_f
    //     0xb0374c: ldur            w7, [x2, #0xf]
    // 0xb03750: DecompressPointer r7
    //     0xb03750: add             x7, x7, HEAP, lsl #32
    // 0xb03754: mov             x1, x7
    // 0xb03758: ldur            x0, [fp, #-8]
    // 0xb0375c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb0375c: add             x25, x1, x4, lsl #2
    //     0xb03760: add             x25, x25, #0xf
    //     0xb03764: str             w0, [x25]
    //     0xb03768: tbz             w0, #0, #0xb03784
    //     0xb0376c: ldurb           w16, [x1, #-1]
    //     0xb03770: ldurb           w17, [x0, #-1]
    //     0xb03774: and             x16, x17, x16, lsr #2
    //     0xb03778: tst             x16, HEAP, lsr #32
    //     0xb0377c: b.eq            #0xb03784
    //     0xb03780: bl              #0xd67e5c
    // 0xb03784: LoadField: r0 = r3->field_9b
    //     0xb03784: ldur            w0, [x3, #0x9b]
    // 0xb03788: DecompressPointer r0
    //     0xb03788: add             x0, x0, HEAP, lsl #32
    // 0xb0378c: stur            x0, [fp, #-8]
    // 0xb03790: LoadField: r1 = r7->field_b
    //     0xb03790: ldur            w1, [x7, #0xb]
    // 0xb03794: DecompressPointer r1
    //     0xb03794: add             x1, x1, HEAP, lsl #32
    // 0xb03798: cmp             w6, w1
    // 0xb0379c: b.ne            #0xb037ac
    // 0xb037a0: SaveReg r2
    //     0xb037a0: str             x2, [SP, #-8]!
    // 0xb037a4: r0 = _growToNextCapacity()
    //     0xb037a4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb037a8: add             SP, SP, #8
    // 0xb037ac: ldr             x3, [fp, #0x10]
    // 0xb037b0: ldur            x4, [fp, #-0x28]
    // 0xb037b4: ldur            x2, [fp, #-0x18]
    // 0xb037b8: add             x5, x4, #1
    // 0xb037bc: stur            x5, [fp, #-0x20]
    // 0xb037c0: lsl             x6, x5, #1
    // 0xb037c4: StoreField: r2->field_b = r6
    //     0xb037c4: stur            w6, [x2, #0xb]
    // 0xb037c8: mov             x0, x5
    // 0xb037cc: mov             x1, x4
    // 0xb037d0: cmp             x1, x0
    // 0xb037d4: b.hs            #0xb05670
    // 0xb037d8: LoadField: r7 = r2->field_f
    //     0xb037d8: ldur            w7, [x2, #0xf]
    // 0xb037dc: DecompressPointer r7
    //     0xb037dc: add             x7, x7, HEAP, lsl #32
    // 0xb037e0: mov             x1, x7
    // 0xb037e4: ldur            x0, [fp, #-8]
    // 0xb037e8: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb037e8: add             x25, x1, x4, lsl #2
    //     0xb037ec: add             x25, x25, #0xf
    //     0xb037f0: str             w0, [x25]
    //     0xb037f4: tbz             w0, #0, #0xb03810
    //     0xb037f8: ldurb           w16, [x1, #-1]
    //     0xb037fc: ldurb           w17, [x0, #-1]
    //     0xb03800: and             x16, x17, x16, lsr #2
    //     0xb03804: tst             x16, HEAP, lsr #32
    //     0xb03808: b.eq            #0xb03810
    //     0xb0380c: bl              #0xd67e5c
    // 0xb03810: LoadField: r0 = r3->field_9f
    //     0xb03810: ldur            w0, [x3, #0x9f]
    // 0xb03814: DecompressPointer r0
    //     0xb03814: add             x0, x0, HEAP, lsl #32
    // 0xb03818: stur            x0, [fp, #-8]
    // 0xb0381c: LoadField: r1 = r7->field_b
    //     0xb0381c: ldur            w1, [x7, #0xb]
    // 0xb03820: DecompressPointer r1
    //     0xb03820: add             x1, x1, HEAP, lsl #32
    // 0xb03824: cmp             w6, w1
    // 0xb03828: b.ne            #0xb03838
    // 0xb0382c: SaveReg r2
    //     0xb0382c: str             x2, [SP, #-8]!
    // 0xb03830: r0 = _growToNextCapacity()
    //     0xb03830: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03834: add             SP, SP, #8
    // 0xb03838: ldr             x3, [fp, #0x10]
    // 0xb0383c: ldur            x4, [fp, #-0x20]
    // 0xb03840: ldur            x2, [fp, #-0x18]
    // 0xb03844: add             x5, x4, #1
    // 0xb03848: stur            x5, [fp, #-0x28]
    // 0xb0384c: lsl             x6, x5, #1
    // 0xb03850: StoreField: r2->field_b = r6
    //     0xb03850: stur            w6, [x2, #0xb]
    // 0xb03854: mov             x0, x5
    // 0xb03858: mov             x1, x4
    // 0xb0385c: cmp             x1, x0
    // 0xb03860: b.hs            #0xb05674
    // 0xb03864: LoadField: r7 = r2->field_f
    //     0xb03864: ldur            w7, [x2, #0xf]
    // 0xb03868: DecompressPointer r7
    //     0xb03868: add             x7, x7, HEAP, lsl #32
    // 0xb0386c: mov             x1, x7
    // 0xb03870: ldur            x0, [fp, #-8]
    // 0xb03874: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03874: add             x25, x1, x4, lsl #2
    //     0xb03878: add             x25, x25, #0xf
    //     0xb0387c: str             w0, [x25]
    //     0xb03880: tbz             w0, #0, #0xb0389c
    //     0xb03884: ldurb           w16, [x1, #-1]
    //     0xb03888: ldurb           w17, [x0, #-1]
    //     0xb0388c: and             x16, x17, x16, lsr #2
    //     0xb03890: tst             x16, HEAP, lsr #32
    //     0xb03894: b.eq            #0xb0389c
    //     0xb03898: bl              #0xd67e5c
    // 0xb0389c: LoadField: r0 = r3->field_a3
    //     0xb0389c: ldur            w0, [x3, #0xa3]
    // 0xb038a0: DecompressPointer r0
    //     0xb038a0: add             x0, x0, HEAP, lsl #32
    // 0xb038a4: stur            x0, [fp, #-8]
    // 0xb038a8: LoadField: r1 = r7->field_b
    //     0xb038a8: ldur            w1, [x7, #0xb]
    // 0xb038ac: DecompressPointer r1
    //     0xb038ac: add             x1, x1, HEAP, lsl #32
    // 0xb038b0: cmp             w6, w1
    // 0xb038b4: b.ne            #0xb038c4
    // 0xb038b8: SaveReg r2
    //     0xb038b8: str             x2, [SP, #-8]!
    // 0xb038bc: r0 = _growToNextCapacity()
    //     0xb038bc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb038c0: add             SP, SP, #8
    // 0xb038c4: ldr             x3, [fp, #0x10]
    // 0xb038c8: ldur            x4, [fp, #-0x28]
    // 0xb038cc: ldur            x2, [fp, #-0x18]
    // 0xb038d0: add             x5, x4, #1
    // 0xb038d4: stur            x5, [fp, #-0x20]
    // 0xb038d8: lsl             x6, x5, #1
    // 0xb038dc: StoreField: r2->field_b = r6
    //     0xb038dc: stur            w6, [x2, #0xb]
    // 0xb038e0: mov             x0, x5
    // 0xb038e4: mov             x1, x4
    // 0xb038e8: cmp             x1, x0
    // 0xb038ec: b.hs            #0xb05678
    // 0xb038f0: LoadField: r7 = r2->field_f
    //     0xb038f0: ldur            w7, [x2, #0xf]
    // 0xb038f4: DecompressPointer r7
    //     0xb038f4: add             x7, x7, HEAP, lsl #32
    // 0xb038f8: mov             x1, x7
    // 0xb038fc: ldur            x0, [fp, #-8]
    // 0xb03900: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03900: add             x25, x1, x4, lsl #2
    //     0xb03904: add             x25, x25, #0xf
    //     0xb03908: str             w0, [x25]
    //     0xb0390c: tbz             w0, #0, #0xb03928
    //     0xb03910: ldurb           w16, [x1, #-1]
    //     0xb03914: ldurb           w17, [x0, #-1]
    //     0xb03918: and             x16, x17, x16, lsr #2
    //     0xb0391c: tst             x16, HEAP, lsr #32
    //     0xb03920: b.eq            #0xb03928
    //     0xb03924: bl              #0xd67e5c
    // 0xb03928: LoadField: r0 = r3->field_a7
    //     0xb03928: ldur            w0, [x3, #0xa7]
    // 0xb0392c: DecompressPointer r0
    //     0xb0392c: add             x0, x0, HEAP, lsl #32
    // 0xb03930: stur            x0, [fp, #-8]
    // 0xb03934: LoadField: r1 = r7->field_b
    //     0xb03934: ldur            w1, [x7, #0xb]
    // 0xb03938: DecompressPointer r1
    //     0xb03938: add             x1, x1, HEAP, lsl #32
    // 0xb0393c: cmp             w6, w1
    // 0xb03940: b.ne            #0xb03950
    // 0xb03944: SaveReg r2
    //     0xb03944: str             x2, [SP, #-8]!
    // 0xb03948: r0 = _growToNextCapacity()
    //     0xb03948: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0394c: add             SP, SP, #8
    // 0xb03950: ldr             x3, [fp, #0x10]
    // 0xb03954: ldur            x4, [fp, #-0x20]
    // 0xb03958: ldur            x2, [fp, #-0x18]
    // 0xb0395c: add             x5, x4, #1
    // 0xb03960: stur            x5, [fp, #-0x28]
    // 0xb03964: lsl             x6, x5, #1
    // 0xb03968: StoreField: r2->field_b = r6
    //     0xb03968: stur            w6, [x2, #0xb]
    // 0xb0396c: mov             x0, x5
    // 0xb03970: mov             x1, x4
    // 0xb03974: cmp             x1, x0
    // 0xb03978: b.hs            #0xb0567c
    // 0xb0397c: LoadField: r7 = r2->field_f
    //     0xb0397c: ldur            w7, [x2, #0xf]
    // 0xb03980: DecompressPointer r7
    //     0xb03980: add             x7, x7, HEAP, lsl #32
    // 0xb03984: mov             x1, x7
    // 0xb03988: ldur            x0, [fp, #-8]
    // 0xb0398c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb0398c: add             x25, x1, x4, lsl #2
    //     0xb03990: add             x25, x25, #0xf
    //     0xb03994: str             w0, [x25]
    //     0xb03998: tbz             w0, #0, #0xb039b4
    //     0xb0399c: ldurb           w16, [x1, #-1]
    //     0xb039a0: ldurb           w17, [x0, #-1]
    //     0xb039a4: and             x16, x17, x16, lsr #2
    //     0xb039a8: tst             x16, HEAP, lsr #32
    //     0xb039ac: b.eq            #0xb039b4
    //     0xb039b0: bl              #0xd67e5c
    // 0xb039b4: LoadField: r0 = r3->field_ab
    //     0xb039b4: ldur            w0, [x3, #0xab]
    // 0xb039b8: DecompressPointer r0
    //     0xb039b8: add             x0, x0, HEAP, lsl #32
    // 0xb039bc: stur            x0, [fp, #-8]
    // 0xb039c0: LoadField: r1 = r7->field_b
    //     0xb039c0: ldur            w1, [x7, #0xb]
    // 0xb039c4: DecompressPointer r1
    //     0xb039c4: add             x1, x1, HEAP, lsl #32
    // 0xb039c8: cmp             w6, w1
    // 0xb039cc: b.ne            #0xb039dc
    // 0xb039d0: SaveReg r2
    //     0xb039d0: str             x2, [SP, #-8]!
    // 0xb039d4: r0 = _growToNextCapacity()
    //     0xb039d4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb039d8: add             SP, SP, #8
    // 0xb039dc: ldr             x3, [fp, #0x10]
    // 0xb039e0: ldur            x4, [fp, #-0x28]
    // 0xb039e4: ldur            x2, [fp, #-0x18]
    // 0xb039e8: add             x5, x4, #1
    // 0xb039ec: stur            x5, [fp, #-0x20]
    // 0xb039f0: lsl             x6, x5, #1
    // 0xb039f4: StoreField: r2->field_b = r6
    //     0xb039f4: stur            w6, [x2, #0xb]
    // 0xb039f8: mov             x0, x5
    // 0xb039fc: mov             x1, x4
    // 0xb03a00: cmp             x1, x0
    // 0xb03a04: b.hs            #0xb05680
    // 0xb03a08: LoadField: r7 = r2->field_f
    //     0xb03a08: ldur            w7, [x2, #0xf]
    // 0xb03a0c: DecompressPointer r7
    //     0xb03a0c: add             x7, x7, HEAP, lsl #32
    // 0xb03a10: mov             x1, x7
    // 0xb03a14: ldur            x0, [fp, #-8]
    // 0xb03a18: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03a18: add             x25, x1, x4, lsl #2
    //     0xb03a1c: add             x25, x25, #0xf
    //     0xb03a20: str             w0, [x25]
    //     0xb03a24: tbz             w0, #0, #0xb03a40
    //     0xb03a28: ldurb           w16, [x1, #-1]
    //     0xb03a2c: ldurb           w17, [x0, #-1]
    //     0xb03a30: and             x16, x17, x16, lsr #2
    //     0xb03a34: tst             x16, HEAP, lsr #32
    //     0xb03a38: b.eq            #0xb03a40
    //     0xb03a3c: bl              #0xd67e5c
    // 0xb03a40: LoadField: r0 = r3->field_af
    //     0xb03a40: ldur            w0, [x3, #0xaf]
    // 0xb03a44: DecompressPointer r0
    //     0xb03a44: add             x0, x0, HEAP, lsl #32
    // 0xb03a48: stur            x0, [fp, #-8]
    // 0xb03a4c: LoadField: r1 = r7->field_b
    //     0xb03a4c: ldur            w1, [x7, #0xb]
    // 0xb03a50: DecompressPointer r1
    //     0xb03a50: add             x1, x1, HEAP, lsl #32
    // 0xb03a54: cmp             w6, w1
    // 0xb03a58: b.ne            #0xb03a68
    // 0xb03a5c: SaveReg r2
    //     0xb03a5c: str             x2, [SP, #-8]!
    // 0xb03a60: r0 = _growToNextCapacity()
    //     0xb03a60: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03a64: add             SP, SP, #8
    // 0xb03a68: ldr             x3, [fp, #0x10]
    // 0xb03a6c: ldur            x4, [fp, #-0x20]
    // 0xb03a70: ldur            x2, [fp, #-0x18]
    // 0xb03a74: add             x5, x4, #1
    // 0xb03a78: stur            x5, [fp, #-0x28]
    // 0xb03a7c: lsl             x6, x5, #1
    // 0xb03a80: StoreField: r2->field_b = r6
    //     0xb03a80: stur            w6, [x2, #0xb]
    // 0xb03a84: mov             x0, x5
    // 0xb03a88: mov             x1, x4
    // 0xb03a8c: cmp             x1, x0
    // 0xb03a90: b.hs            #0xb05684
    // 0xb03a94: LoadField: r7 = r2->field_f
    //     0xb03a94: ldur            w7, [x2, #0xf]
    // 0xb03a98: DecompressPointer r7
    //     0xb03a98: add             x7, x7, HEAP, lsl #32
    // 0xb03a9c: mov             x1, x7
    // 0xb03aa0: ldur            x0, [fp, #-8]
    // 0xb03aa4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03aa4: add             x25, x1, x4, lsl #2
    //     0xb03aa8: add             x25, x25, #0xf
    //     0xb03aac: str             w0, [x25]
    //     0xb03ab0: tbz             w0, #0, #0xb03acc
    //     0xb03ab4: ldurb           w16, [x1, #-1]
    //     0xb03ab8: ldurb           w17, [x0, #-1]
    //     0xb03abc: and             x16, x17, x16, lsr #2
    //     0xb03ac0: tst             x16, HEAP, lsr #32
    //     0xb03ac4: b.eq            #0xb03acc
    //     0xb03ac8: bl              #0xd67e5c
    // 0xb03acc: LoadField: r0 = r3->field_b3
    //     0xb03acc: ldur            w0, [x3, #0xb3]
    // 0xb03ad0: DecompressPointer r0
    //     0xb03ad0: add             x0, x0, HEAP, lsl #32
    // 0xb03ad4: stur            x0, [fp, #-8]
    // 0xb03ad8: LoadField: r1 = r7->field_b
    //     0xb03ad8: ldur            w1, [x7, #0xb]
    // 0xb03adc: DecompressPointer r1
    //     0xb03adc: add             x1, x1, HEAP, lsl #32
    // 0xb03ae0: cmp             w6, w1
    // 0xb03ae4: b.ne            #0xb03af4
    // 0xb03ae8: SaveReg r2
    //     0xb03ae8: str             x2, [SP, #-8]!
    // 0xb03aec: r0 = _growToNextCapacity()
    //     0xb03aec: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03af0: add             SP, SP, #8
    // 0xb03af4: ldr             x3, [fp, #0x10]
    // 0xb03af8: ldur            x4, [fp, #-0x28]
    // 0xb03afc: ldur            x2, [fp, #-0x18]
    // 0xb03b00: add             x5, x4, #1
    // 0xb03b04: stur            x5, [fp, #-0x20]
    // 0xb03b08: lsl             x6, x5, #1
    // 0xb03b0c: StoreField: r2->field_b = r6
    //     0xb03b0c: stur            w6, [x2, #0xb]
    // 0xb03b10: mov             x0, x5
    // 0xb03b14: mov             x1, x4
    // 0xb03b18: cmp             x1, x0
    // 0xb03b1c: b.hs            #0xb05688
    // 0xb03b20: LoadField: r7 = r2->field_f
    //     0xb03b20: ldur            w7, [x2, #0xf]
    // 0xb03b24: DecompressPointer r7
    //     0xb03b24: add             x7, x7, HEAP, lsl #32
    // 0xb03b28: mov             x1, x7
    // 0xb03b2c: ldur            x0, [fp, #-8]
    // 0xb03b30: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03b30: add             x25, x1, x4, lsl #2
    //     0xb03b34: add             x25, x25, #0xf
    //     0xb03b38: str             w0, [x25]
    //     0xb03b3c: tbz             w0, #0, #0xb03b58
    //     0xb03b40: ldurb           w16, [x1, #-1]
    //     0xb03b44: ldurb           w17, [x0, #-1]
    //     0xb03b48: and             x16, x17, x16, lsr #2
    //     0xb03b4c: tst             x16, HEAP, lsr #32
    //     0xb03b50: b.eq            #0xb03b58
    //     0xb03b54: bl              #0xd67e5c
    // 0xb03b58: LoadField: r0 = r3->field_b7
    //     0xb03b58: ldur            w0, [x3, #0xb7]
    // 0xb03b5c: DecompressPointer r0
    //     0xb03b5c: add             x0, x0, HEAP, lsl #32
    // 0xb03b60: stur            x0, [fp, #-8]
    // 0xb03b64: LoadField: r1 = r7->field_b
    //     0xb03b64: ldur            w1, [x7, #0xb]
    // 0xb03b68: DecompressPointer r1
    //     0xb03b68: add             x1, x1, HEAP, lsl #32
    // 0xb03b6c: cmp             w6, w1
    // 0xb03b70: b.ne            #0xb03b80
    // 0xb03b74: SaveReg r2
    //     0xb03b74: str             x2, [SP, #-8]!
    // 0xb03b78: r0 = _growToNextCapacity()
    //     0xb03b78: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03b7c: add             SP, SP, #8
    // 0xb03b80: ldr             x3, [fp, #0x10]
    // 0xb03b84: ldur            x4, [fp, #-0x20]
    // 0xb03b88: ldur            x2, [fp, #-0x18]
    // 0xb03b8c: add             x5, x4, #1
    // 0xb03b90: stur            x5, [fp, #-0x28]
    // 0xb03b94: lsl             x6, x5, #1
    // 0xb03b98: StoreField: r2->field_b = r6
    //     0xb03b98: stur            w6, [x2, #0xb]
    // 0xb03b9c: mov             x0, x5
    // 0xb03ba0: mov             x1, x4
    // 0xb03ba4: cmp             x1, x0
    // 0xb03ba8: b.hs            #0xb0568c
    // 0xb03bac: LoadField: r7 = r2->field_f
    //     0xb03bac: ldur            w7, [x2, #0xf]
    // 0xb03bb0: DecompressPointer r7
    //     0xb03bb0: add             x7, x7, HEAP, lsl #32
    // 0xb03bb4: mov             x1, x7
    // 0xb03bb8: ldur            x0, [fp, #-8]
    // 0xb03bbc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03bbc: add             x25, x1, x4, lsl #2
    //     0xb03bc0: add             x25, x25, #0xf
    //     0xb03bc4: str             w0, [x25]
    //     0xb03bc8: tbz             w0, #0, #0xb03be4
    //     0xb03bcc: ldurb           w16, [x1, #-1]
    //     0xb03bd0: ldurb           w17, [x0, #-1]
    //     0xb03bd4: and             x16, x17, x16, lsr #2
    //     0xb03bd8: tst             x16, HEAP, lsr #32
    //     0xb03bdc: b.eq            #0xb03be4
    //     0xb03be0: bl              #0xd67e5c
    // 0xb03be4: LoadField: r0 = r3->field_bb
    //     0xb03be4: ldur            w0, [x3, #0xbb]
    // 0xb03be8: DecompressPointer r0
    //     0xb03be8: add             x0, x0, HEAP, lsl #32
    // 0xb03bec: stur            x0, [fp, #-8]
    // 0xb03bf0: LoadField: r1 = r7->field_b
    //     0xb03bf0: ldur            w1, [x7, #0xb]
    // 0xb03bf4: DecompressPointer r1
    //     0xb03bf4: add             x1, x1, HEAP, lsl #32
    // 0xb03bf8: cmp             w6, w1
    // 0xb03bfc: b.ne            #0xb03c0c
    // 0xb03c00: SaveReg r2
    //     0xb03c00: str             x2, [SP, #-8]!
    // 0xb03c04: r0 = _growToNextCapacity()
    //     0xb03c04: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03c08: add             SP, SP, #8
    // 0xb03c0c: ldr             x3, [fp, #0x10]
    // 0xb03c10: ldur            x4, [fp, #-0x28]
    // 0xb03c14: ldur            x2, [fp, #-0x18]
    // 0xb03c18: add             x5, x4, #1
    // 0xb03c1c: stur            x5, [fp, #-0x20]
    // 0xb03c20: lsl             x6, x5, #1
    // 0xb03c24: StoreField: r2->field_b = r6
    //     0xb03c24: stur            w6, [x2, #0xb]
    // 0xb03c28: mov             x0, x5
    // 0xb03c2c: mov             x1, x4
    // 0xb03c30: cmp             x1, x0
    // 0xb03c34: b.hs            #0xb05690
    // 0xb03c38: LoadField: r7 = r2->field_f
    //     0xb03c38: ldur            w7, [x2, #0xf]
    // 0xb03c3c: DecompressPointer r7
    //     0xb03c3c: add             x7, x7, HEAP, lsl #32
    // 0xb03c40: mov             x1, x7
    // 0xb03c44: ldur            x0, [fp, #-8]
    // 0xb03c48: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03c48: add             x25, x1, x4, lsl #2
    //     0xb03c4c: add             x25, x25, #0xf
    //     0xb03c50: str             w0, [x25]
    //     0xb03c54: tbz             w0, #0, #0xb03c70
    //     0xb03c58: ldurb           w16, [x1, #-1]
    //     0xb03c5c: ldurb           w17, [x0, #-1]
    //     0xb03c60: and             x16, x17, x16, lsr #2
    //     0xb03c64: tst             x16, HEAP, lsr #32
    //     0xb03c68: b.eq            #0xb03c70
    //     0xb03c6c: bl              #0xd67e5c
    // 0xb03c70: LoadField: r0 = r3->field_bf
    //     0xb03c70: ldur            w0, [x3, #0xbf]
    // 0xb03c74: DecompressPointer r0
    //     0xb03c74: add             x0, x0, HEAP, lsl #32
    // 0xb03c78: stur            x0, [fp, #-8]
    // 0xb03c7c: LoadField: r1 = r7->field_b
    //     0xb03c7c: ldur            w1, [x7, #0xb]
    // 0xb03c80: DecompressPointer r1
    //     0xb03c80: add             x1, x1, HEAP, lsl #32
    // 0xb03c84: cmp             w6, w1
    // 0xb03c88: b.ne            #0xb03c98
    // 0xb03c8c: SaveReg r2
    //     0xb03c8c: str             x2, [SP, #-8]!
    // 0xb03c90: r0 = _growToNextCapacity()
    //     0xb03c90: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03c94: add             SP, SP, #8
    // 0xb03c98: ldr             x3, [fp, #0x10]
    // 0xb03c9c: ldur            x4, [fp, #-0x20]
    // 0xb03ca0: ldur            x2, [fp, #-0x18]
    // 0xb03ca4: add             x5, x4, #1
    // 0xb03ca8: stur            x5, [fp, #-0x28]
    // 0xb03cac: lsl             x6, x5, #1
    // 0xb03cb0: StoreField: r2->field_b = r6
    //     0xb03cb0: stur            w6, [x2, #0xb]
    // 0xb03cb4: mov             x0, x5
    // 0xb03cb8: mov             x1, x4
    // 0xb03cbc: cmp             x1, x0
    // 0xb03cc0: b.hs            #0xb05694
    // 0xb03cc4: LoadField: r7 = r2->field_f
    //     0xb03cc4: ldur            w7, [x2, #0xf]
    // 0xb03cc8: DecompressPointer r7
    //     0xb03cc8: add             x7, x7, HEAP, lsl #32
    // 0xb03ccc: mov             x1, x7
    // 0xb03cd0: ldur            x0, [fp, #-8]
    // 0xb03cd4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03cd4: add             x25, x1, x4, lsl #2
    //     0xb03cd8: add             x25, x25, #0xf
    //     0xb03cdc: str             w0, [x25]
    //     0xb03ce0: tbz             w0, #0, #0xb03cfc
    //     0xb03ce4: ldurb           w16, [x1, #-1]
    //     0xb03ce8: ldurb           w17, [x0, #-1]
    //     0xb03cec: and             x16, x17, x16, lsr #2
    //     0xb03cf0: tst             x16, HEAP, lsr #32
    //     0xb03cf4: b.eq            #0xb03cfc
    //     0xb03cf8: bl              #0xd67e5c
    // 0xb03cfc: LoadField: r0 = r3->field_c3
    //     0xb03cfc: ldur            w0, [x3, #0xc3]
    // 0xb03d00: DecompressPointer r0
    //     0xb03d00: add             x0, x0, HEAP, lsl #32
    // 0xb03d04: stur            x0, [fp, #-8]
    // 0xb03d08: LoadField: r1 = r7->field_b
    //     0xb03d08: ldur            w1, [x7, #0xb]
    // 0xb03d0c: DecompressPointer r1
    //     0xb03d0c: add             x1, x1, HEAP, lsl #32
    // 0xb03d10: cmp             w6, w1
    // 0xb03d14: b.ne            #0xb03d24
    // 0xb03d18: SaveReg r2
    //     0xb03d18: str             x2, [SP, #-8]!
    // 0xb03d1c: r0 = _growToNextCapacity()
    //     0xb03d1c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03d20: add             SP, SP, #8
    // 0xb03d24: ldr             x3, [fp, #0x10]
    // 0xb03d28: ldur            x4, [fp, #-0x28]
    // 0xb03d2c: ldur            x2, [fp, #-0x18]
    // 0xb03d30: add             x5, x4, #1
    // 0xb03d34: stur            x5, [fp, #-0x20]
    // 0xb03d38: lsl             x6, x5, #1
    // 0xb03d3c: StoreField: r2->field_b = r6
    //     0xb03d3c: stur            w6, [x2, #0xb]
    // 0xb03d40: mov             x0, x5
    // 0xb03d44: mov             x1, x4
    // 0xb03d48: cmp             x1, x0
    // 0xb03d4c: b.hs            #0xb05698
    // 0xb03d50: LoadField: r7 = r2->field_f
    //     0xb03d50: ldur            w7, [x2, #0xf]
    // 0xb03d54: DecompressPointer r7
    //     0xb03d54: add             x7, x7, HEAP, lsl #32
    // 0xb03d58: mov             x1, x7
    // 0xb03d5c: ldur            x0, [fp, #-8]
    // 0xb03d60: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03d60: add             x25, x1, x4, lsl #2
    //     0xb03d64: add             x25, x25, #0xf
    //     0xb03d68: str             w0, [x25]
    //     0xb03d6c: tbz             w0, #0, #0xb03d88
    //     0xb03d70: ldurb           w16, [x1, #-1]
    //     0xb03d74: ldurb           w17, [x0, #-1]
    //     0xb03d78: and             x16, x17, x16, lsr #2
    //     0xb03d7c: tst             x16, HEAP, lsr #32
    //     0xb03d80: b.eq            #0xb03d88
    //     0xb03d84: bl              #0xd67e5c
    // 0xb03d88: LoadField: r0 = r3->field_c7
    //     0xb03d88: ldur            w0, [x3, #0xc7]
    // 0xb03d8c: DecompressPointer r0
    //     0xb03d8c: add             x0, x0, HEAP, lsl #32
    // 0xb03d90: stur            x0, [fp, #-8]
    // 0xb03d94: LoadField: r1 = r7->field_b
    //     0xb03d94: ldur            w1, [x7, #0xb]
    // 0xb03d98: DecompressPointer r1
    //     0xb03d98: add             x1, x1, HEAP, lsl #32
    // 0xb03d9c: cmp             w6, w1
    // 0xb03da0: b.ne            #0xb03db0
    // 0xb03da4: SaveReg r2
    //     0xb03da4: str             x2, [SP, #-8]!
    // 0xb03da8: r0 = _growToNextCapacity()
    //     0xb03da8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03dac: add             SP, SP, #8
    // 0xb03db0: ldr             x3, [fp, #0x10]
    // 0xb03db4: ldur            x4, [fp, #-0x20]
    // 0xb03db8: ldur            x2, [fp, #-0x18]
    // 0xb03dbc: add             x5, x4, #1
    // 0xb03dc0: stur            x5, [fp, #-0x28]
    // 0xb03dc4: lsl             x6, x5, #1
    // 0xb03dc8: StoreField: r2->field_b = r6
    //     0xb03dc8: stur            w6, [x2, #0xb]
    // 0xb03dcc: mov             x0, x5
    // 0xb03dd0: mov             x1, x4
    // 0xb03dd4: cmp             x1, x0
    // 0xb03dd8: b.hs            #0xb0569c
    // 0xb03ddc: LoadField: r7 = r2->field_f
    //     0xb03ddc: ldur            w7, [x2, #0xf]
    // 0xb03de0: DecompressPointer r7
    //     0xb03de0: add             x7, x7, HEAP, lsl #32
    // 0xb03de4: mov             x1, x7
    // 0xb03de8: ldur            x0, [fp, #-8]
    // 0xb03dec: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03dec: add             x25, x1, x4, lsl #2
    //     0xb03df0: add             x25, x25, #0xf
    //     0xb03df4: str             w0, [x25]
    //     0xb03df8: tbz             w0, #0, #0xb03e14
    //     0xb03dfc: ldurb           w16, [x1, #-1]
    //     0xb03e00: ldurb           w17, [x0, #-1]
    //     0xb03e04: and             x16, x17, x16, lsr #2
    //     0xb03e08: tst             x16, HEAP, lsr #32
    //     0xb03e0c: b.eq            #0xb03e14
    //     0xb03e10: bl              #0xd67e5c
    // 0xb03e14: LoadField: r0 = r3->field_cb
    //     0xb03e14: ldur            w0, [x3, #0xcb]
    // 0xb03e18: DecompressPointer r0
    //     0xb03e18: add             x0, x0, HEAP, lsl #32
    // 0xb03e1c: stur            x0, [fp, #-8]
    // 0xb03e20: LoadField: r1 = r7->field_b
    //     0xb03e20: ldur            w1, [x7, #0xb]
    // 0xb03e24: DecompressPointer r1
    //     0xb03e24: add             x1, x1, HEAP, lsl #32
    // 0xb03e28: cmp             w6, w1
    // 0xb03e2c: b.ne            #0xb03e3c
    // 0xb03e30: SaveReg r2
    //     0xb03e30: str             x2, [SP, #-8]!
    // 0xb03e34: r0 = _growToNextCapacity()
    //     0xb03e34: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03e38: add             SP, SP, #8
    // 0xb03e3c: ldr             x3, [fp, #0x10]
    // 0xb03e40: ldur            x4, [fp, #-0x28]
    // 0xb03e44: ldur            x2, [fp, #-0x18]
    // 0xb03e48: add             x5, x4, #1
    // 0xb03e4c: stur            x5, [fp, #-0x20]
    // 0xb03e50: lsl             x6, x5, #1
    // 0xb03e54: StoreField: r2->field_b = r6
    //     0xb03e54: stur            w6, [x2, #0xb]
    // 0xb03e58: mov             x0, x5
    // 0xb03e5c: mov             x1, x4
    // 0xb03e60: cmp             x1, x0
    // 0xb03e64: b.hs            #0xb056a0
    // 0xb03e68: LoadField: r7 = r2->field_f
    //     0xb03e68: ldur            w7, [x2, #0xf]
    // 0xb03e6c: DecompressPointer r7
    //     0xb03e6c: add             x7, x7, HEAP, lsl #32
    // 0xb03e70: mov             x1, x7
    // 0xb03e74: ldur            x0, [fp, #-8]
    // 0xb03e78: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03e78: add             x25, x1, x4, lsl #2
    //     0xb03e7c: add             x25, x25, #0xf
    //     0xb03e80: str             w0, [x25]
    //     0xb03e84: tbz             w0, #0, #0xb03ea0
    //     0xb03e88: ldurb           w16, [x1, #-1]
    //     0xb03e8c: ldurb           w17, [x0, #-1]
    //     0xb03e90: and             x16, x17, x16, lsr #2
    //     0xb03e94: tst             x16, HEAP, lsr #32
    //     0xb03e98: b.eq            #0xb03ea0
    //     0xb03e9c: bl              #0xd67e5c
    // 0xb03ea0: LoadField: r0 = r3->field_cf
    //     0xb03ea0: ldur            w0, [x3, #0xcf]
    // 0xb03ea4: DecompressPointer r0
    //     0xb03ea4: add             x0, x0, HEAP, lsl #32
    // 0xb03ea8: stur            x0, [fp, #-8]
    // 0xb03eac: LoadField: r1 = r7->field_b
    //     0xb03eac: ldur            w1, [x7, #0xb]
    // 0xb03eb0: DecompressPointer r1
    //     0xb03eb0: add             x1, x1, HEAP, lsl #32
    // 0xb03eb4: cmp             w6, w1
    // 0xb03eb8: b.ne            #0xb03ec8
    // 0xb03ebc: SaveReg r2
    //     0xb03ebc: str             x2, [SP, #-8]!
    // 0xb03ec0: r0 = _growToNextCapacity()
    //     0xb03ec0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03ec4: add             SP, SP, #8
    // 0xb03ec8: ldr             x3, [fp, #0x10]
    // 0xb03ecc: ldur            x4, [fp, #-0x20]
    // 0xb03ed0: ldur            x2, [fp, #-0x18]
    // 0xb03ed4: add             x5, x4, #1
    // 0xb03ed8: stur            x5, [fp, #-0x28]
    // 0xb03edc: lsl             x6, x5, #1
    // 0xb03ee0: StoreField: r2->field_b = r6
    //     0xb03ee0: stur            w6, [x2, #0xb]
    // 0xb03ee4: mov             x0, x5
    // 0xb03ee8: mov             x1, x4
    // 0xb03eec: cmp             x1, x0
    // 0xb03ef0: b.hs            #0xb056a4
    // 0xb03ef4: LoadField: r7 = r2->field_f
    //     0xb03ef4: ldur            w7, [x2, #0xf]
    // 0xb03ef8: DecompressPointer r7
    //     0xb03ef8: add             x7, x7, HEAP, lsl #32
    // 0xb03efc: mov             x1, x7
    // 0xb03f00: ldur            x0, [fp, #-8]
    // 0xb03f04: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03f04: add             x25, x1, x4, lsl #2
    //     0xb03f08: add             x25, x25, #0xf
    //     0xb03f0c: str             w0, [x25]
    //     0xb03f10: tbz             w0, #0, #0xb03f2c
    //     0xb03f14: ldurb           w16, [x1, #-1]
    //     0xb03f18: ldurb           w17, [x0, #-1]
    //     0xb03f1c: and             x16, x17, x16, lsr #2
    //     0xb03f20: tst             x16, HEAP, lsr #32
    //     0xb03f24: b.eq            #0xb03f2c
    //     0xb03f28: bl              #0xd67e5c
    // 0xb03f2c: LoadField: r0 = r3->field_d3
    //     0xb03f2c: ldur            w0, [x3, #0xd3]
    // 0xb03f30: DecompressPointer r0
    //     0xb03f30: add             x0, x0, HEAP, lsl #32
    // 0xb03f34: stur            x0, [fp, #-8]
    // 0xb03f38: LoadField: r1 = r7->field_b
    //     0xb03f38: ldur            w1, [x7, #0xb]
    // 0xb03f3c: DecompressPointer r1
    //     0xb03f3c: add             x1, x1, HEAP, lsl #32
    // 0xb03f40: cmp             w6, w1
    // 0xb03f44: b.ne            #0xb03f54
    // 0xb03f48: SaveReg r2
    //     0xb03f48: str             x2, [SP, #-8]!
    // 0xb03f4c: r0 = _growToNextCapacity()
    //     0xb03f4c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03f50: add             SP, SP, #8
    // 0xb03f54: ldr             x3, [fp, #0x10]
    // 0xb03f58: ldur            x4, [fp, #-0x28]
    // 0xb03f5c: ldur            x2, [fp, #-0x18]
    // 0xb03f60: add             x5, x4, #1
    // 0xb03f64: stur            x5, [fp, #-0x20]
    // 0xb03f68: lsl             x6, x5, #1
    // 0xb03f6c: StoreField: r2->field_b = r6
    //     0xb03f6c: stur            w6, [x2, #0xb]
    // 0xb03f70: mov             x0, x5
    // 0xb03f74: mov             x1, x4
    // 0xb03f78: cmp             x1, x0
    // 0xb03f7c: b.hs            #0xb056a8
    // 0xb03f80: LoadField: r7 = r2->field_f
    //     0xb03f80: ldur            w7, [x2, #0xf]
    // 0xb03f84: DecompressPointer r7
    //     0xb03f84: add             x7, x7, HEAP, lsl #32
    // 0xb03f88: mov             x1, x7
    // 0xb03f8c: ldur            x0, [fp, #-8]
    // 0xb03f90: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb03f90: add             x25, x1, x4, lsl #2
    //     0xb03f94: add             x25, x25, #0xf
    //     0xb03f98: str             w0, [x25]
    //     0xb03f9c: tbz             w0, #0, #0xb03fb8
    //     0xb03fa0: ldurb           w16, [x1, #-1]
    //     0xb03fa4: ldurb           w17, [x0, #-1]
    //     0xb03fa8: and             x16, x17, x16, lsr #2
    //     0xb03fac: tst             x16, HEAP, lsr #32
    //     0xb03fb0: b.eq            #0xb03fb8
    //     0xb03fb4: bl              #0xd67e5c
    // 0xb03fb8: LoadField: r0 = r3->field_d7
    //     0xb03fb8: ldur            w0, [x3, #0xd7]
    // 0xb03fbc: DecompressPointer r0
    //     0xb03fbc: add             x0, x0, HEAP, lsl #32
    // 0xb03fc0: stur            x0, [fp, #-8]
    // 0xb03fc4: LoadField: r1 = r7->field_b
    //     0xb03fc4: ldur            w1, [x7, #0xb]
    // 0xb03fc8: DecompressPointer r1
    //     0xb03fc8: add             x1, x1, HEAP, lsl #32
    // 0xb03fcc: cmp             w6, w1
    // 0xb03fd0: b.ne            #0xb03fe0
    // 0xb03fd4: SaveReg r2
    //     0xb03fd4: str             x2, [SP, #-8]!
    // 0xb03fd8: r0 = _growToNextCapacity()
    //     0xb03fd8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb03fdc: add             SP, SP, #8
    // 0xb03fe0: ldr             x3, [fp, #0x10]
    // 0xb03fe4: ldur            x4, [fp, #-0x20]
    // 0xb03fe8: ldur            x2, [fp, #-0x18]
    // 0xb03fec: add             x5, x4, #1
    // 0xb03ff0: stur            x5, [fp, #-0x28]
    // 0xb03ff4: lsl             x6, x5, #1
    // 0xb03ff8: StoreField: r2->field_b = r6
    //     0xb03ff8: stur            w6, [x2, #0xb]
    // 0xb03ffc: mov             x0, x5
    // 0xb04000: mov             x1, x4
    // 0xb04004: cmp             x1, x0
    // 0xb04008: b.hs            #0xb056ac
    // 0xb0400c: LoadField: r7 = r2->field_f
    //     0xb0400c: ldur            w7, [x2, #0xf]
    // 0xb04010: DecompressPointer r7
    //     0xb04010: add             x7, x7, HEAP, lsl #32
    // 0xb04014: mov             x1, x7
    // 0xb04018: ldur            x0, [fp, #-8]
    // 0xb0401c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb0401c: add             x25, x1, x4, lsl #2
    //     0xb04020: add             x25, x25, #0xf
    //     0xb04024: str             w0, [x25]
    //     0xb04028: tbz             w0, #0, #0xb04044
    //     0xb0402c: ldurb           w16, [x1, #-1]
    //     0xb04030: ldurb           w17, [x0, #-1]
    //     0xb04034: and             x16, x17, x16, lsr #2
    //     0xb04038: tst             x16, HEAP, lsr #32
    //     0xb0403c: b.eq            #0xb04044
    //     0xb04040: bl              #0xd67e5c
    // 0xb04044: LoadField: r0 = r3->field_db
    //     0xb04044: ldur            w0, [x3, #0xdb]
    // 0xb04048: DecompressPointer r0
    //     0xb04048: add             x0, x0, HEAP, lsl #32
    // 0xb0404c: stur            x0, [fp, #-8]
    // 0xb04050: LoadField: r1 = r7->field_b
    //     0xb04050: ldur            w1, [x7, #0xb]
    // 0xb04054: DecompressPointer r1
    //     0xb04054: add             x1, x1, HEAP, lsl #32
    // 0xb04058: cmp             w6, w1
    // 0xb0405c: b.ne            #0xb0406c
    // 0xb04060: SaveReg r2
    //     0xb04060: str             x2, [SP, #-8]!
    // 0xb04064: r0 = _growToNextCapacity()
    //     0xb04064: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04068: add             SP, SP, #8
    // 0xb0406c: ldr             x3, [fp, #0x10]
    // 0xb04070: ldur            x4, [fp, #-0x28]
    // 0xb04074: ldur            x2, [fp, #-0x18]
    // 0xb04078: add             x5, x4, #1
    // 0xb0407c: stur            x5, [fp, #-0x20]
    // 0xb04080: lsl             x6, x5, #1
    // 0xb04084: StoreField: r2->field_b = r6
    //     0xb04084: stur            w6, [x2, #0xb]
    // 0xb04088: mov             x0, x5
    // 0xb0408c: mov             x1, x4
    // 0xb04090: cmp             x1, x0
    // 0xb04094: b.hs            #0xb056b0
    // 0xb04098: LoadField: r7 = r2->field_f
    //     0xb04098: ldur            w7, [x2, #0xf]
    // 0xb0409c: DecompressPointer r7
    //     0xb0409c: add             x7, x7, HEAP, lsl #32
    // 0xb040a0: mov             x1, x7
    // 0xb040a4: ldur            x0, [fp, #-8]
    // 0xb040a8: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb040a8: add             x25, x1, x4, lsl #2
    //     0xb040ac: add             x25, x25, #0xf
    //     0xb040b0: str             w0, [x25]
    //     0xb040b4: tbz             w0, #0, #0xb040d0
    //     0xb040b8: ldurb           w16, [x1, #-1]
    //     0xb040bc: ldurb           w17, [x0, #-1]
    //     0xb040c0: and             x16, x17, x16, lsr #2
    //     0xb040c4: tst             x16, HEAP, lsr #32
    //     0xb040c8: b.eq            #0xb040d0
    //     0xb040cc: bl              #0xd67e5c
    // 0xb040d0: LoadField: r0 = r3->field_df
    //     0xb040d0: ldur            w0, [x3, #0xdf]
    // 0xb040d4: DecompressPointer r0
    //     0xb040d4: add             x0, x0, HEAP, lsl #32
    // 0xb040d8: stur            x0, [fp, #-8]
    // 0xb040dc: LoadField: r1 = r7->field_b
    //     0xb040dc: ldur            w1, [x7, #0xb]
    // 0xb040e0: DecompressPointer r1
    //     0xb040e0: add             x1, x1, HEAP, lsl #32
    // 0xb040e4: cmp             w6, w1
    // 0xb040e8: b.ne            #0xb040f8
    // 0xb040ec: SaveReg r2
    //     0xb040ec: str             x2, [SP, #-8]!
    // 0xb040f0: r0 = _growToNextCapacity()
    //     0xb040f0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb040f4: add             SP, SP, #8
    // 0xb040f8: ldr             x3, [fp, #0x10]
    // 0xb040fc: ldur            x4, [fp, #-0x20]
    // 0xb04100: ldur            x2, [fp, #-0x18]
    // 0xb04104: add             x5, x4, #1
    // 0xb04108: stur            x5, [fp, #-0x28]
    // 0xb0410c: lsl             x6, x5, #1
    // 0xb04110: StoreField: r2->field_b = r6
    //     0xb04110: stur            w6, [x2, #0xb]
    // 0xb04114: mov             x0, x5
    // 0xb04118: mov             x1, x4
    // 0xb0411c: cmp             x1, x0
    // 0xb04120: b.hs            #0xb056b4
    // 0xb04124: LoadField: r7 = r2->field_f
    //     0xb04124: ldur            w7, [x2, #0xf]
    // 0xb04128: DecompressPointer r7
    //     0xb04128: add             x7, x7, HEAP, lsl #32
    // 0xb0412c: mov             x1, x7
    // 0xb04130: ldur            x0, [fp, #-8]
    // 0xb04134: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04134: add             x25, x1, x4, lsl #2
    //     0xb04138: add             x25, x25, #0xf
    //     0xb0413c: str             w0, [x25]
    //     0xb04140: tbz             w0, #0, #0xb0415c
    //     0xb04144: ldurb           w16, [x1, #-1]
    //     0xb04148: ldurb           w17, [x0, #-1]
    //     0xb0414c: and             x16, x17, x16, lsr #2
    //     0xb04150: tst             x16, HEAP, lsr #32
    //     0xb04154: b.eq            #0xb0415c
    //     0xb04158: bl              #0xd67e5c
    // 0xb0415c: LoadField: r0 = r3->field_e3
    //     0xb0415c: ldur            w0, [x3, #0xe3]
    // 0xb04160: DecompressPointer r0
    //     0xb04160: add             x0, x0, HEAP, lsl #32
    // 0xb04164: stur            x0, [fp, #-8]
    // 0xb04168: LoadField: r1 = r7->field_b
    //     0xb04168: ldur            w1, [x7, #0xb]
    // 0xb0416c: DecompressPointer r1
    //     0xb0416c: add             x1, x1, HEAP, lsl #32
    // 0xb04170: cmp             w6, w1
    // 0xb04174: b.ne            #0xb04184
    // 0xb04178: SaveReg r2
    //     0xb04178: str             x2, [SP, #-8]!
    // 0xb0417c: r0 = _growToNextCapacity()
    //     0xb0417c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04180: add             SP, SP, #8
    // 0xb04184: ldr             x3, [fp, #0x10]
    // 0xb04188: ldur            x4, [fp, #-0x28]
    // 0xb0418c: ldur            x2, [fp, #-0x18]
    // 0xb04190: add             x5, x4, #1
    // 0xb04194: stur            x5, [fp, #-0x20]
    // 0xb04198: lsl             x6, x5, #1
    // 0xb0419c: StoreField: r2->field_b = r6
    //     0xb0419c: stur            w6, [x2, #0xb]
    // 0xb041a0: mov             x0, x5
    // 0xb041a4: mov             x1, x4
    // 0xb041a8: cmp             x1, x0
    // 0xb041ac: b.hs            #0xb056b8
    // 0xb041b0: LoadField: r7 = r2->field_f
    //     0xb041b0: ldur            w7, [x2, #0xf]
    // 0xb041b4: DecompressPointer r7
    //     0xb041b4: add             x7, x7, HEAP, lsl #32
    // 0xb041b8: mov             x1, x7
    // 0xb041bc: ldur            x0, [fp, #-8]
    // 0xb041c0: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb041c0: add             x25, x1, x4, lsl #2
    //     0xb041c4: add             x25, x25, #0xf
    //     0xb041c8: str             w0, [x25]
    //     0xb041cc: tbz             w0, #0, #0xb041e8
    //     0xb041d0: ldurb           w16, [x1, #-1]
    //     0xb041d4: ldurb           w17, [x0, #-1]
    //     0xb041d8: and             x16, x17, x16, lsr #2
    //     0xb041dc: tst             x16, HEAP, lsr #32
    //     0xb041e0: b.eq            #0xb041e8
    //     0xb041e4: bl              #0xd67e5c
    // 0xb041e8: LoadField: r0 = r3->field_e7
    //     0xb041e8: ldur            w0, [x3, #0xe7]
    // 0xb041ec: DecompressPointer r0
    //     0xb041ec: add             x0, x0, HEAP, lsl #32
    // 0xb041f0: stur            x0, [fp, #-8]
    // 0xb041f4: LoadField: r1 = r7->field_b
    //     0xb041f4: ldur            w1, [x7, #0xb]
    // 0xb041f8: DecompressPointer r1
    //     0xb041f8: add             x1, x1, HEAP, lsl #32
    // 0xb041fc: cmp             w6, w1
    // 0xb04200: b.ne            #0xb04210
    // 0xb04204: SaveReg r2
    //     0xb04204: str             x2, [SP, #-8]!
    // 0xb04208: r0 = _growToNextCapacity()
    //     0xb04208: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0420c: add             SP, SP, #8
    // 0xb04210: ldr             x3, [fp, #0x10]
    // 0xb04214: ldur            x4, [fp, #-0x20]
    // 0xb04218: ldur            x2, [fp, #-0x18]
    // 0xb0421c: add             x5, x4, #1
    // 0xb04220: stur            x5, [fp, #-0x28]
    // 0xb04224: lsl             x6, x5, #1
    // 0xb04228: StoreField: r2->field_b = r6
    //     0xb04228: stur            w6, [x2, #0xb]
    // 0xb0422c: mov             x0, x5
    // 0xb04230: mov             x1, x4
    // 0xb04234: cmp             x1, x0
    // 0xb04238: b.hs            #0xb056bc
    // 0xb0423c: LoadField: r7 = r2->field_f
    //     0xb0423c: ldur            w7, [x2, #0xf]
    // 0xb04240: DecompressPointer r7
    //     0xb04240: add             x7, x7, HEAP, lsl #32
    // 0xb04244: mov             x1, x7
    // 0xb04248: ldur            x0, [fp, #-8]
    // 0xb0424c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb0424c: add             x25, x1, x4, lsl #2
    //     0xb04250: add             x25, x25, #0xf
    //     0xb04254: str             w0, [x25]
    //     0xb04258: tbz             w0, #0, #0xb04274
    //     0xb0425c: ldurb           w16, [x1, #-1]
    //     0xb04260: ldurb           w17, [x0, #-1]
    //     0xb04264: and             x16, x17, x16, lsr #2
    //     0xb04268: tst             x16, HEAP, lsr #32
    //     0xb0426c: b.eq            #0xb04274
    //     0xb04270: bl              #0xd67e5c
    // 0xb04274: LoadField: r0 = r3->field_eb
    //     0xb04274: ldur            w0, [x3, #0xeb]
    // 0xb04278: DecompressPointer r0
    //     0xb04278: add             x0, x0, HEAP, lsl #32
    // 0xb0427c: stur            x0, [fp, #-8]
    // 0xb04280: LoadField: r1 = r7->field_b
    //     0xb04280: ldur            w1, [x7, #0xb]
    // 0xb04284: DecompressPointer r1
    //     0xb04284: add             x1, x1, HEAP, lsl #32
    // 0xb04288: cmp             w6, w1
    // 0xb0428c: b.ne            #0xb0429c
    // 0xb04290: SaveReg r2
    //     0xb04290: str             x2, [SP, #-8]!
    // 0xb04294: r0 = _growToNextCapacity()
    //     0xb04294: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04298: add             SP, SP, #8
    // 0xb0429c: ldr             x3, [fp, #0x10]
    // 0xb042a0: ldur            x4, [fp, #-0x28]
    // 0xb042a4: ldur            x2, [fp, #-0x18]
    // 0xb042a8: add             x5, x4, #1
    // 0xb042ac: stur            x5, [fp, #-0x20]
    // 0xb042b0: lsl             x6, x5, #1
    // 0xb042b4: StoreField: r2->field_b = r6
    //     0xb042b4: stur            w6, [x2, #0xb]
    // 0xb042b8: mov             x0, x5
    // 0xb042bc: mov             x1, x4
    // 0xb042c0: cmp             x1, x0
    // 0xb042c4: b.hs            #0xb056c0
    // 0xb042c8: LoadField: r7 = r2->field_f
    //     0xb042c8: ldur            w7, [x2, #0xf]
    // 0xb042cc: DecompressPointer r7
    //     0xb042cc: add             x7, x7, HEAP, lsl #32
    // 0xb042d0: mov             x1, x7
    // 0xb042d4: ldur            x0, [fp, #-8]
    // 0xb042d8: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb042d8: add             x25, x1, x4, lsl #2
    //     0xb042dc: add             x25, x25, #0xf
    //     0xb042e0: str             w0, [x25]
    //     0xb042e4: tbz             w0, #0, #0xb04300
    //     0xb042e8: ldurb           w16, [x1, #-1]
    //     0xb042ec: ldurb           w17, [x0, #-1]
    //     0xb042f0: and             x16, x17, x16, lsr #2
    //     0xb042f4: tst             x16, HEAP, lsr #32
    //     0xb042f8: b.eq            #0xb04300
    //     0xb042fc: bl              #0xd67e5c
    // 0xb04300: LoadField: r0 = r3->field_ef
    //     0xb04300: ldur            w0, [x3, #0xef]
    // 0xb04304: DecompressPointer r0
    //     0xb04304: add             x0, x0, HEAP, lsl #32
    // 0xb04308: stur            x0, [fp, #-8]
    // 0xb0430c: LoadField: r1 = r7->field_b
    //     0xb0430c: ldur            w1, [x7, #0xb]
    // 0xb04310: DecompressPointer r1
    //     0xb04310: add             x1, x1, HEAP, lsl #32
    // 0xb04314: cmp             w6, w1
    // 0xb04318: b.ne            #0xb04328
    // 0xb0431c: SaveReg r2
    //     0xb0431c: str             x2, [SP, #-8]!
    // 0xb04320: r0 = _growToNextCapacity()
    //     0xb04320: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04324: add             SP, SP, #8
    // 0xb04328: ldr             x3, [fp, #0x10]
    // 0xb0432c: ldur            x4, [fp, #-0x20]
    // 0xb04330: ldur            x2, [fp, #-0x18]
    // 0xb04334: add             x5, x4, #1
    // 0xb04338: stur            x5, [fp, #-0x28]
    // 0xb0433c: lsl             x6, x5, #1
    // 0xb04340: StoreField: r2->field_b = r6
    //     0xb04340: stur            w6, [x2, #0xb]
    // 0xb04344: mov             x0, x5
    // 0xb04348: mov             x1, x4
    // 0xb0434c: cmp             x1, x0
    // 0xb04350: b.hs            #0xb056c4
    // 0xb04354: LoadField: r7 = r2->field_f
    //     0xb04354: ldur            w7, [x2, #0xf]
    // 0xb04358: DecompressPointer r7
    //     0xb04358: add             x7, x7, HEAP, lsl #32
    // 0xb0435c: mov             x1, x7
    // 0xb04360: ldur            x0, [fp, #-8]
    // 0xb04364: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04364: add             x25, x1, x4, lsl #2
    //     0xb04368: add             x25, x25, #0xf
    //     0xb0436c: str             w0, [x25]
    //     0xb04370: tbz             w0, #0, #0xb0438c
    //     0xb04374: ldurb           w16, [x1, #-1]
    //     0xb04378: ldurb           w17, [x0, #-1]
    //     0xb0437c: and             x16, x17, x16, lsr #2
    //     0xb04380: tst             x16, HEAP, lsr #32
    //     0xb04384: b.eq            #0xb0438c
    //     0xb04388: bl              #0xd67e5c
    // 0xb0438c: LoadField: r0 = r3->field_f3
    //     0xb0438c: ldur            w0, [x3, #0xf3]
    // 0xb04390: DecompressPointer r0
    //     0xb04390: add             x0, x0, HEAP, lsl #32
    // 0xb04394: stur            x0, [fp, #-8]
    // 0xb04398: LoadField: r1 = r7->field_b
    //     0xb04398: ldur            w1, [x7, #0xb]
    // 0xb0439c: DecompressPointer r1
    //     0xb0439c: add             x1, x1, HEAP, lsl #32
    // 0xb043a0: cmp             w6, w1
    // 0xb043a4: b.ne            #0xb043b4
    // 0xb043a8: SaveReg r2
    //     0xb043a8: str             x2, [SP, #-8]!
    // 0xb043ac: r0 = _growToNextCapacity()
    //     0xb043ac: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb043b0: add             SP, SP, #8
    // 0xb043b4: ldr             x3, [fp, #0x10]
    // 0xb043b8: ldur            x4, [fp, #-0x28]
    // 0xb043bc: ldur            x2, [fp, #-0x18]
    // 0xb043c0: add             x5, x4, #1
    // 0xb043c4: stur            x5, [fp, #-0x20]
    // 0xb043c8: lsl             x6, x5, #1
    // 0xb043cc: StoreField: r2->field_b = r6
    //     0xb043cc: stur            w6, [x2, #0xb]
    // 0xb043d0: mov             x0, x5
    // 0xb043d4: mov             x1, x4
    // 0xb043d8: cmp             x1, x0
    // 0xb043dc: b.hs            #0xb056c8
    // 0xb043e0: LoadField: r7 = r2->field_f
    //     0xb043e0: ldur            w7, [x2, #0xf]
    // 0xb043e4: DecompressPointer r7
    //     0xb043e4: add             x7, x7, HEAP, lsl #32
    // 0xb043e8: mov             x1, x7
    // 0xb043ec: ldur            x0, [fp, #-8]
    // 0xb043f0: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb043f0: add             x25, x1, x4, lsl #2
    //     0xb043f4: add             x25, x25, #0xf
    //     0xb043f8: str             w0, [x25]
    //     0xb043fc: tbz             w0, #0, #0xb04418
    //     0xb04400: ldurb           w16, [x1, #-1]
    //     0xb04404: ldurb           w17, [x0, #-1]
    //     0xb04408: and             x16, x17, x16, lsr #2
    //     0xb0440c: tst             x16, HEAP, lsr #32
    //     0xb04410: b.eq            #0xb04418
    //     0xb04414: bl              #0xd67e5c
    // 0xb04418: LoadField: r0 = r3->field_f7
    //     0xb04418: ldur            w0, [x3, #0xf7]
    // 0xb0441c: DecompressPointer r0
    //     0xb0441c: add             x0, x0, HEAP, lsl #32
    // 0xb04420: stur            x0, [fp, #-8]
    // 0xb04424: LoadField: r1 = r7->field_b
    //     0xb04424: ldur            w1, [x7, #0xb]
    // 0xb04428: DecompressPointer r1
    //     0xb04428: add             x1, x1, HEAP, lsl #32
    // 0xb0442c: cmp             w6, w1
    // 0xb04430: b.ne            #0xb04440
    // 0xb04434: SaveReg r2
    //     0xb04434: str             x2, [SP, #-8]!
    // 0xb04438: r0 = _growToNextCapacity()
    //     0xb04438: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0443c: add             SP, SP, #8
    // 0xb04440: ldr             x3, [fp, #0x10]
    // 0xb04444: ldur            x4, [fp, #-0x20]
    // 0xb04448: ldur            x2, [fp, #-0x18]
    // 0xb0444c: add             x5, x4, #1
    // 0xb04450: stur            x5, [fp, #-0x28]
    // 0xb04454: lsl             x6, x5, #1
    // 0xb04458: StoreField: r2->field_b = r6
    //     0xb04458: stur            w6, [x2, #0xb]
    // 0xb0445c: mov             x0, x5
    // 0xb04460: mov             x1, x4
    // 0xb04464: cmp             x1, x0
    // 0xb04468: b.hs            #0xb056cc
    // 0xb0446c: LoadField: r7 = r2->field_f
    //     0xb0446c: ldur            w7, [x2, #0xf]
    // 0xb04470: DecompressPointer r7
    //     0xb04470: add             x7, x7, HEAP, lsl #32
    // 0xb04474: mov             x1, x7
    // 0xb04478: ldur            x0, [fp, #-8]
    // 0xb0447c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb0447c: add             x25, x1, x4, lsl #2
    //     0xb04480: add             x25, x25, #0xf
    //     0xb04484: str             w0, [x25]
    //     0xb04488: tbz             w0, #0, #0xb044a4
    //     0xb0448c: ldurb           w16, [x1, #-1]
    //     0xb04490: ldurb           w17, [x0, #-1]
    //     0xb04494: and             x16, x17, x16, lsr #2
    //     0xb04498: tst             x16, HEAP, lsr #32
    //     0xb0449c: b.eq            #0xb044a4
    //     0xb044a0: bl              #0xd67e5c
    // 0xb044a4: LoadField: r0 = r3->field_fb
    //     0xb044a4: ldur            w0, [x3, #0xfb]
    // 0xb044a8: DecompressPointer r0
    //     0xb044a8: add             x0, x0, HEAP, lsl #32
    // 0xb044ac: stur            x0, [fp, #-8]
    // 0xb044b0: LoadField: r1 = r7->field_b
    //     0xb044b0: ldur            w1, [x7, #0xb]
    // 0xb044b4: DecompressPointer r1
    //     0xb044b4: add             x1, x1, HEAP, lsl #32
    // 0xb044b8: cmp             w6, w1
    // 0xb044bc: b.ne            #0xb044cc
    // 0xb044c0: SaveReg r2
    //     0xb044c0: str             x2, [SP, #-8]!
    // 0xb044c4: r0 = _growToNextCapacity()
    //     0xb044c4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb044c8: add             SP, SP, #8
    // 0xb044cc: ldr             x3, [fp, #0x10]
    // 0xb044d0: ldur            x4, [fp, #-0x28]
    // 0xb044d4: ldur            x2, [fp, #-0x18]
    // 0xb044d8: add             x5, x4, #1
    // 0xb044dc: stur            x5, [fp, #-0x20]
    // 0xb044e0: lsl             x6, x5, #1
    // 0xb044e4: StoreField: r2->field_b = r6
    //     0xb044e4: stur            w6, [x2, #0xb]
    // 0xb044e8: mov             x0, x5
    // 0xb044ec: mov             x1, x4
    // 0xb044f0: cmp             x1, x0
    // 0xb044f4: b.hs            #0xb056d0
    // 0xb044f8: LoadField: r7 = r2->field_f
    //     0xb044f8: ldur            w7, [x2, #0xf]
    // 0xb044fc: DecompressPointer r7
    //     0xb044fc: add             x7, x7, HEAP, lsl #32
    // 0xb04500: mov             x1, x7
    // 0xb04504: ldur            x0, [fp, #-8]
    // 0xb04508: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04508: add             x25, x1, x4, lsl #2
    //     0xb0450c: add             x25, x25, #0xf
    //     0xb04510: str             w0, [x25]
    //     0xb04514: tbz             w0, #0, #0xb04530
    //     0xb04518: ldurb           w16, [x1, #-1]
    //     0xb0451c: ldurb           w17, [x0, #-1]
    //     0xb04520: and             x16, x17, x16, lsr #2
    //     0xb04524: tst             x16, HEAP, lsr #32
    //     0xb04528: b.eq            #0xb04530
    //     0xb0452c: bl              #0xd67e5c
    // 0xb04530: LoadField: r0 = r3->field_ff
    //     0xb04530: ldur            w0, [x3, #0xff]
    // 0xb04534: DecompressPointer r0
    //     0xb04534: add             x0, x0, HEAP, lsl #32
    // 0xb04538: stur            x0, [fp, #-8]
    // 0xb0453c: LoadField: r1 = r7->field_b
    //     0xb0453c: ldur            w1, [x7, #0xb]
    // 0xb04540: DecompressPointer r1
    //     0xb04540: add             x1, x1, HEAP, lsl #32
    // 0xb04544: cmp             w6, w1
    // 0xb04548: b.ne            #0xb04558
    // 0xb0454c: SaveReg r2
    //     0xb0454c: str             x2, [SP, #-8]!
    // 0xb04550: r0 = _growToNextCapacity()
    //     0xb04550: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04554: add             SP, SP, #8
    // 0xb04558: ldr             x3, [fp, #0x10]
    // 0xb0455c: ldur            x4, [fp, #-0x20]
    // 0xb04560: ldur            x2, [fp, #-0x18]
    // 0xb04564: add             x5, x4, #1
    // 0xb04568: stur            x5, [fp, #-0x28]
    // 0xb0456c: lsl             x6, x5, #1
    // 0xb04570: StoreField: r2->field_b = r6
    //     0xb04570: stur            w6, [x2, #0xb]
    // 0xb04574: mov             x0, x5
    // 0xb04578: mov             x1, x4
    // 0xb0457c: cmp             x1, x0
    // 0xb04580: b.hs            #0xb056d4
    // 0xb04584: LoadField: r7 = r2->field_f
    //     0xb04584: ldur            w7, [x2, #0xf]
    // 0xb04588: DecompressPointer r7
    //     0xb04588: add             x7, x7, HEAP, lsl #32
    // 0xb0458c: mov             x1, x7
    // 0xb04590: ldur            x0, [fp, #-8]
    // 0xb04594: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04594: add             x25, x1, x4, lsl #2
    //     0xb04598: add             x25, x25, #0xf
    //     0xb0459c: str             w0, [x25]
    //     0xb045a0: tbz             w0, #0, #0xb045bc
    //     0xb045a4: ldurb           w16, [x1, #-1]
    //     0xb045a8: ldurb           w17, [x0, #-1]
    //     0xb045ac: and             x16, x17, x16, lsr #2
    //     0xb045b0: tst             x16, HEAP, lsr #32
    //     0xb045b4: b.eq            #0xb045bc
    //     0xb045b8: bl              #0xd67e5c
    // 0xb045bc: r17 = 259
    //     0xb045bc: mov             x17, #0x103
    // 0xb045c0: ldr             w0, [x3, x17]
    // 0xb045c4: DecompressPointer r0
    //     0xb045c4: add             x0, x0, HEAP, lsl #32
    // 0xb045c8: stur            x0, [fp, #-8]
    // 0xb045cc: LoadField: r1 = r7->field_b
    //     0xb045cc: ldur            w1, [x7, #0xb]
    // 0xb045d0: DecompressPointer r1
    //     0xb045d0: add             x1, x1, HEAP, lsl #32
    // 0xb045d4: cmp             w6, w1
    // 0xb045d8: b.ne            #0xb045e8
    // 0xb045dc: SaveReg r2
    //     0xb045dc: str             x2, [SP, #-8]!
    // 0xb045e0: r0 = _growToNextCapacity()
    //     0xb045e0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb045e4: add             SP, SP, #8
    // 0xb045e8: ldr             x3, [fp, #0x10]
    // 0xb045ec: ldur            x4, [fp, #-0x28]
    // 0xb045f0: ldur            x2, [fp, #-0x18]
    // 0xb045f4: add             x5, x4, #1
    // 0xb045f8: stur            x5, [fp, #-0x20]
    // 0xb045fc: lsl             x6, x5, #1
    // 0xb04600: StoreField: r2->field_b = r6
    //     0xb04600: stur            w6, [x2, #0xb]
    // 0xb04604: mov             x0, x5
    // 0xb04608: mov             x1, x4
    // 0xb0460c: cmp             x1, x0
    // 0xb04610: b.hs            #0xb056d8
    // 0xb04614: LoadField: r7 = r2->field_f
    //     0xb04614: ldur            w7, [x2, #0xf]
    // 0xb04618: DecompressPointer r7
    //     0xb04618: add             x7, x7, HEAP, lsl #32
    // 0xb0461c: mov             x1, x7
    // 0xb04620: ldur            x0, [fp, #-8]
    // 0xb04624: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04624: add             x25, x1, x4, lsl #2
    //     0xb04628: add             x25, x25, #0xf
    //     0xb0462c: str             w0, [x25]
    //     0xb04630: tbz             w0, #0, #0xb0464c
    //     0xb04634: ldurb           w16, [x1, #-1]
    //     0xb04638: ldurb           w17, [x0, #-1]
    //     0xb0463c: and             x16, x17, x16, lsr #2
    //     0xb04640: tst             x16, HEAP, lsr #32
    //     0xb04644: b.eq            #0xb0464c
    //     0xb04648: bl              #0xd67e5c
    // 0xb0464c: r17 = 263
    //     0xb0464c: mov             x17, #0x107
    // 0xb04650: ldr             w0, [x3, x17]
    // 0xb04654: DecompressPointer r0
    //     0xb04654: add             x0, x0, HEAP, lsl #32
    // 0xb04658: stur            x0, [fp, #-8]
    // 0xb0465c: LoadField: r1 = r7->field_b
    //     0xb0465c: ldur            w1, [x7, #0xb]
    // 0xb04660: DecompressPointer r1
    //     0xb04660: add             x1, x1, HEAP, lsl #32
    // 0xb04664: cmp             w6, w1
    // 0xb04668: b.ne            #0xb04678
    // 0xb0466c: SaveReg r2
    //     0xb0466c: str             x2, [SP, #-8]!
    // 0xb04670: r0 = _growToNextCapacity()
    //     0xb04670: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04674: add             SP, SP, #8
    // 0xb04678: ldr             x3, [fp, #0x10]
    // 0xb0467c: ldur            x4, [fp, #-0x20]
    // 0xb04680: ldur            x2, [fp, #-0x18]
    // 0xb04684: add             x5, x4, #1
    // 0xb04688: stur            x5, [fp, #-0x28]
    // 0xb0468c: lsl             x6, x5, #1
    // 0xb04690: StoreField: r2->field_b = r6
    //     0xb04690: stur            w6, [x2, #0xb]
    // 0xb04694: mov             x0, x5
    // 0xb04698: mov             x1, x4
    // 0xb0469c: cmp             x1, x0
    // 0xb046a0: b.hs            #0xb056dc
    // 0xb046a4: LoadField: r7 = r2->field_f
    //     0xb046a4: ldur            w7, [x2, #0xf]
    // 0xb046a8: DecompressPointer r7
    //     0xb046a8: add             x7, x7, HEAP, lsl #32
    // 0xb046ac: mov             x1, x7
    // 0xb046b0: ldur            x0, [fp, #-8]
    // 0xb046b4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb046b4: add             x25, x1, x4, lsl #2
    //     0xb046b8: add             x25, x25, #0xf
    //     0xb046bc: str             w0, [x25]
    //     0xb046c0: tbz             w0, #0, #0xb046dc
    //     0xb046c4: ldurb           w16, [x1, #-1]
    //     0xb046c8: ldurb           w17, [x0, #-1]
    //     0xb046cc: and             x16, x17, x16, lsr #2
    //     0xb046d0: tst             x16, HEAP, lsr #32
    //     0xb046d4: b.eq            #0xb046dc
    //     0xb046d8: bl              #0xd67e5c
    // 0xb046dc: r17 = 267
    //     0xb046dc: mov             x17, #0x10b
    // 0xb046e0: ldr             w0, [x3, x17]
    // 0xb046e4: DecompressPointer r0
    //     0xb046e4: add             x0, x0, HEAP, lsl #32
    // 0xb046e8: stur            x0, [fp, #-8]
    // 0xb046ec: LoadField: r1 = r7->field_b
    //     0xb046ec: ldur            w1, [x7, #0xb]
    // 0xb046f0: DecompressPointer r1
    //     0xb046f0: add             x1, x1, HEAP, lsl #32
    // 0xb046f4: cmp             w6, w1
    // 0xb046f8: b.ne            #0xb04708
    // 0xb046fc: SaveReg r2
    //     0xb046fc: str             x2, [SP, #-8]!
    // 0xb04700: r0 = _growToNextCapacity()
    //     0xb04700: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04704: add             SP, SP, #8
    // 0xb04708: ldr             x3, [fp, #0x10]
    // 0xb0470c: ldur            x4, [fp, #-0x28]
    // 0xb04710: ldur            x2, [fp, #-0x18]
    // 0xb04714: add             x5, x4, #1
    // 0xb04718: stur            x5, [fp, #-0x20]
    // 0xb0471c: lsl             x6, x5, #1
    // 0xb04720: StoreField: r2->field_b = r6
    //     0xb04720: stur            w6, [x2, #0xb]
    // 0xb04724: mov             x0, x5
    // 0xb04728: mov             x1, x4
    // 0xb0472c: cmp             x1, x0
    // 0xb04730: b.hs            #0xb056e0
    // 0xb04734: LoadField: r7 = r2->field_f
    //     0xb04734: ldur            w7, [x2, #0xf]
    // 0xb04738: DecompressPointer r7
    //     0xb04738: add             x7, x7, HEAP, lsl #32
    // 0xb0473c: mov             x1, x7
    // 0xb04740: ldur            x0, [fp, #-8]
    // 0xb04744: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04744: add             x25, x1, x4, lsl #2
    //     0xb04748: add             x25, x25, #0xf
    //     0xb0474c: str             w0, [x25]
    //     0xb04750: tbz             w0, #0, #0xb0476c
    //     0xb04754: ldurb           w16, [x1, #-1]
    //     0xb04758: ldurb           w17, [x0, #-1]
    //     0xb0475c: and             x16, x17, x16, lsr #2
    //     0xb04760: tst             x16, HEAP, lsr #32
    //     0xb04764: b.eq            #0xb0476c
    //     0xb04768: bl              #0xd67e5c
    // 0xb0476c: r17 = 271
    //     0xb0476c: mov             x17, #0x10f
    // 0xb04770: ldr             w0, [x3, x17]
    // 0xb04774: DecompressPointer r0
    //     0xb04774: add             x0, x0, HEAP, lsl #32
    // 0xb04778: stur            x0, [fp, #-8]
    // 0xb0477c: LoadField: r1 = r7->field_b
    //     0xb0477c: ldur            w1, [x7, #0xb]
    // 0xb04780: DecompressPointer r1
    //     0xb04780: add             x1, x1, HEAP, lsl #32
    // 0xb04784: cmp             w6, w1
    // 0xb04788: b.ne            #0xb04798
    // 0xb0478c: SaveReg r2
    //     0xb0478c: str             x2, [SP, #-8]!
    // 0xb04790: r0 = _growToNextCapacity()
    //     0xb04790: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04794: add             SP, SP, #8
    // 0xb04798: ldr             x3, [fp, #0x10]
    // 0xb0479c: ldur            x4, [fp, #-0x20]
    // 0xb047a0: ldur            x2, [fp, #-0x18]
    // 0xb047a4: add             x5, x4, #1
    // 0xb047a8: stur            x5, [fp, #-0x28]
    // 0xb047ac: lsl             x6, x5, #1
    // 0xb047b0: StoreField: r2->field_b = r6
    //     0xb047b0: stur            w6, [x2, #0xb]
    // 0xb047b4: mov             x0, x5
    // 0xb047b8: mov             x1, x4
    // 0xb047bc: cmp             x1, x0
    // 0xb047c0: b.hs            #0xb056e4
    // 0xb047c4: LoadField: r7 = r2->field_f
    //     0xb047c4: ldur            w7, [x2, #0xf]
    // 0xb047c8: DecompressPointer r7
    //     0xb047c8: add             x7, x7, HEAP, lsl #32
    // 0xb047cc: mov             x1, x7
    // 0xb047d0: ldur            x0, [fp, #-8]
    // 0xb047d4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb047d4: add             x25, x1, x4, lsl #2
    //     0xb047d8: add             x25, x25, #0xf
    //     0xb047dc: str             w0, [x25]
    //     0xb047e0: tbz             w0, #0, #0xb047fc
    //     0xb047e4: ldurb           w16, [x1, #-1]
    //     0xb047e8: ldurb           w17, [x0, #-1]
    //     0xb047ec: and             x16, x17, x16, lsr #2
    //     0xb047f0: tst             x16, HEAP, lsr #32
    //     0xb047f4: b.eq            #0xb047fc
    //     0xb047f8: bl              #0xd67e5c
    // 0xb047fc: r17 = 275
    //     0xb047fc: mov             x17, #0x113
    // 0xb04800: ldr             w0, [x3, x17]
    // 0xb04804: DecompressPointer r0
    //     0xb04804: add             x0, x0, HEAP, lsl #32
    // 0xb04808: stur            x0, [fp, #-8]
    // 0xb0480c: LoadField: r1 = r7->field_b
    //     0xb0480c: ldur            w1, [x7, #0xb]
    // 0xb04810: DecompressPointer r1
    //     0xb04810: add             x1, x1, HEAP, lsl #32
    // 0xb04814: cmp             w6, w1
    // 0xb04818: b.ne            #0xb04828
    // 0xb0481c: SaveReg r2
    //     0xb0481c: str             x2, [SP, #-8]!
    // 0xb04820: r0 = _growToNextCapacity()
    //     0xb04820: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04824: add             SP, SP, #8
    // 0xb04828: ldr             x3, [fp, #0x10]
    // 0xb0482c: ldur            x4, [fp, #-0x28]
    // 0xb04830: ldur            x2, [fp, #-0x18]
    // 0xb04834: add             x5, x4, #1
    // 0xb04838: stur            x5, [fp, #-0x20]
    // 0xb0483c: lsl             x6, x5, #1
    // 0xb04840: StoreField: r2->field_b = r6
    //     0xb04840: stur            w6, [x2, #0xb]
    // 0xb04844: mov             x0, x5
    // 0xb04848: mov             x1, x4
    // 0xb0484c: cmp             x1, x0
    // 0xb04850: b.hs            #0xb056e8
    // 0xb04854: LoadField: r7 = r2->field_f
    //     0xb04854: ldur            w7, [x2, #0xf]
    // 0xb04858: DecompressPointer r7
    //     0xb04858: add             x7, x7, HEAP, lsl #32
    // 0xb0485c: mov             x1, x7
    // 0xb04860: ldur            x0, [fp, #-8]
    // 0xb04864: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04864: add             x25, x1, x4, lsl #2
    //     0xb04868: add             x25, x25, #0xf
    //     0xb0486c: str             w0, [x25]
    //     0xb04870: tbz             w0, #0, #0xb0488c
    //     0xb04874: ldurb           w16, [x1, #-1]
    //     0xb04878: ldurb           w17, [x0, #-1]
    //     0xb0487c: and             x16, x17, x16, lsr #2
    //     0xb04880: tst             x16, HEAP, lsr #32
    //     0xb04884: b.eq            #0xb0488c
    //     0xb04888: bl              #0xd67e5c
    // 0xb0488c: r17 = 279
    //     0xb0488c: mov             x17, #0x117
    // 0xb04890: ldr             w0, [x3, x17]
    // 0xb04894: DecompressPointer r0
    //     0xb04894: add             x0, x0, HEAP, lsl #32
    // 0xb04898: stur            x0, [fp, #-8]
    // 0xb0489c: LoadField: r1 = r7->field_b
    //     0xb0489c: ldur            w1, [x7, #0xb]
    // 0xb048a0: DecompressPointer r1
    //     0xb048a0: add             x1, x1, HEAP, lsl #32
    // 0xb048a4: cmp             w6, w1
    // 0xb048a8: b.ne            #0xb048b8
    // 0xb048ac: SaveReg r2
    //     0xb048ac: str             x2, [SP, #-8]!
    // 0xb048b0: r0 = _growToNextCapacity()
    //     0xb048b0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb048b4: add             SP, SP, #8
    // 0xb048b8: ldr             x3, [fp, #0x10]
    // 0xb048bc: ldur            x4, [fp, #-0x20]
    // 0xb048c0: ldur            x2, [fp, #-0x18]
    // 0xb048c4: add             x5, x4, #1
    // 0xb048c8: stur            x5, [fp, #-0x28]
    // 0xb048cc: lsl             x6, x5, #1
    // 0xb048d0: StoreField: r2->field_b = r6
    //     0xb048d0: stur            w6, [x2, #0xb]
    // 0xb048d4: mov             x0, x5
    // 0xb048d8: mov             x1, x4
    // 0xb048dc: cmp             x1, x0
    // 0xb048e0: b.hs            #0xb056ec
    // 0xb048e4: LoadField: r7 = r2->field_f
    //     0xb048e4: ldur            w7, [x2, #0xf]
    // 0xb048e8: DecompressPointer r7
    //     0xb048e8: add             x7, x7, HEAP, lsl #32
    // 0xb048ec: mov             x1, x7
    // 0xb048f0: ldur            x0, [fp, #-8]
    // 0xb048f4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb048f4: add             x25, x1, x4, lsl #2
    //     0xb048f8: add             x25, x25, #0xf
    //     0xb048fc: str             w0, [x25]
    //     0xb04900: tbz             w0, #0, #0xb0491c
    //     0xb04904: ldurb           w16, [x1, #-1]
    //     0xb04908: ldurb           w17, [x0, #-1]
    //     0xb0490c: and             x16, x17, x16, lsr #2
    //     0xb04910: tst             x16, HEAP, lsr #32
    //     0xb04914: b.eq            #0xb0491c
    //     0xb04918: bl              #0xd67e5c
    // 0xb0491c: r17 = 283
    //     0xb0491c: mov             x17, #0x11b
    // 0xb04920: ldr             w0, [x3, x17]
    // 0xb04924: DecompressPointer r0
    //     0xb04924: add             x0, x0, HEAP, lsl #32
    // 0xb04928: stur            x0, [fp, #-8]
    // 0xb0492c: LoadField: r1 = r7->field_b
    //     0xb0492c: ldur            w1, [x7, #0xb]
    // 0xb04930: DecompressPointer r1
    //     0xb04930: add             x1, x1, HEAP, lsl #32
    // 0xb04934: cmp             w6, w1
    // 0xb04938: b.ne            #0xb04948
    // 0xb0493c: SaveReg r2
    //     0xb0493c: str             x2, [SP, #-8]!
    // 0xb04940: r0 = _growToNextCapacity()
    //     0xb04940: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04944: add             SP, SP, #8
    // 0xb04948: ldr             x3, [fp, #0x10]
    // 0xb0494c: ldur            x4, [fp, #-0x28]
    // 0xb04950: ldur            x2, [fp, #-0x18]
    // 0xb04954: add             x5, x4, #1
    // 0xb04958: stur            x5, [fp, #-0x20]
    // 0xb0495c: lsl             x6, x5, #1
    // 0xb04960: StoreField: r2->field_b = r6
    //     0xb04960: stur            w6, [x2, #0xb]
    // 0xb04964: mov             x0, x5
    // 0xb04968: mov             x1, x4
    // 0xb0496c: cmp             x1, x0
    // 0xb04970: b.hs            #0xb056f0
    // 0xb04974: LoadField: r7 = r2->field_f
    //     0xb04974: ldur            w7, [x2, #0xf]
    // 0xb04978: DecompressPointer r7
    //     0xb04978: add             x7, x7, HEAP, lsl #32
    // 0xb0497c: mov             x1, x7
    // 0xb04980: ldur            x0, [fp, #-8]
    // 0xb04984: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04984: add             x25, x1, x4, lsl #2
    //     0xb04988: add             x25, x25, #0xf
    //     0xb0498c: str             w0, [x25]
    //     0xb04990: tbz             w0, #0, #0xb049ac
    //     0xb04994: ldurb           w16, [x1, #-1]
    //     0xb04998: ldurb           w17, [x0, #-1]
    //     0xb0499c: and             x16, x17, x16, lsr #2
    //     0xb049a0: tst             x16, HEAP, lsr #32
    //     0xb049a4: b.eq            #0xb049ac
    //     0xb049a8: bl              #0xd67e5c
    // 0xb049ac: r17 = 287
    //     0xb049ac: mov             x17, #0x11f
    // 0xb049b0: ldr             w0, [x3, x17]
    // 0xb049b4: DecompressPointer r0
    //     0xb049b4: add             x0, x0, HEAP, lsl #32
    // 0xb049b8: stur            x0, [fp, #-8]
    // 0xb049bc: LoadField: r1 = r7->field_b
    //     0xb049bc: ldur            w1, [x7, #0xb]
    // 0xb049c0: DecompressPointer r1
    //     0xb049c0: add             x1, x1, HEAP, lsl #32
    // 0xb049c4: cmp             w6, w1
    // 0xb049c8: b.ne            #0xb049d8
    // 0xb049cc: SaveReg r2
    //     0xb049cc: str             x2, [SP, #-8]!
    // 0xb049d0: r0 = _growToNextCapacity()
    //     0xb049d0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb049d4: add             SP, SP, #8
    // 0xb049d8: ldr             x3, [fp, #0x10]
    // 0xb049dc: ldur            x4, [fp, #-0x20]
    // 0xb049e0: ldur            x2, [fp, #-0x18]
    // 0xb049e4: add             x5, x4, #1
    // 0xb049e8: stur            x5, [fp, #-0x28]
    // 0xb049ec: lsl             x6, x5, #1
    // 0xb049f0: StoreField: r2->field_b = r6
    //     0xb049f0: stur            w6, [x2, #0xb]
    // 0xb049f4: mov             x0, x5
    // 0xb049f8: mov             x1, x4
    // 0xb049fc: cmp             x1, x0
    // 0xb04a00: b.hs            #0xb056f4
    // 0xb04a04: LoadField: r7 = r2->field_f
    //     0xb04a04: ldur            w7, [x2, #0xf]
    // 0xb04a08: DecompressPointer r7
    //     0xb04a08: add             x7, x7, HEAP, lsl #32
    // 0xb04a0c: mov             x1, x7
    // 0xb04a10: ldur            x0, [fp, #-8]
    // 0xb04a14: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04a14: add             x25, x1, x4, lsl #2
    //     0xb04a18: add             x25, x25, #0xf
    //     0xb04a1c: str             w0, [x25]
    //     0xb04a20: tbz             w0, #0, #0xb04a3c
    //     0xb04a24: ldurb           w16, [x1, #-1]
    //     0xb04a28: ldurb           w17, [x0, #-1]
    //     0xb04a2c: and             x16, x17, x16, lsr #2
    //     0xb04a30: tst             x16, HEAP, lsr #32
    //     0xb04a34: b.eq            #0xb04a3c
    //     0xb04a38: bl              #0xd67e5c
    // 0xb04a3c: r17 = 291
    //     0xb04a3c: mov             x17, #0x123
    // 0xb04a40: ldr             w0, [x3, x17]
    // 0xb04a44: DecompressPointer r0
    //     0xb04a44: add             x0, x0, HEAP, lsl #32
    // 0xb04a48: stur            x0, [fp, #-8]
    // 0xb04a4c: LoadField: r1 = r7->field_b
    //     0xb04a4c: ldur            w1, [x7, #0xb]
    // 0xb04a50: DecompressPointer r1
    //     0xb04a50: add             x1, x1, HEAP, lsl #32
    // 0xb04a54: cmp             w6, w1
    // 0xb04a58: b.ne            #0xb04a68
    // 0xb04a5c: SaveReg r2
    //     0xb04a5c: str             x2, [SP, #-8]!
    // 0xb04a60: r0 = _growToNextCapacity()
    //     0xb04a60: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04a64: add             SP, SP, #8
    // 0xb04a68: ldr             x3, [fp, #0x10]
    // 0xb04a6c: ldur            x4, [fp, #-0x28]
    // 0xb04a70: ldur            x2, [fp, #-0x18]
    // 0xb04a74: add             x5, x4, #1
    // 0xb04a78: stur            x5, [fp, #-0x20]
    // 0xb04a7c: lsl             x6, x5, #1
    // 0xb04a80: StoreField: r2->field_b = r6
    //     0xb04a80: stur            w6, [x2, #0xb]
    // 0xb04a84: mov             x0, x5
    // 0xb04a88: mov             x1, x4
    // 0xb04a8c: cmp             x1, x0
    // 0xb04a90: b.hs            #0xb056f8
    // 0xb04a94: LoadField: r7 = r2->field_f
    //     0xb04a94: ldur            w7, [x2, #0xf]
    // 0xb04a98: DecompressPointer r7
    //     0xb04a98: add             x7, x7, HEAP, lsl #32
    // 0xb04a9c: mov             x1, x7
    // 0xb04aa0: ldur            x0, [fp, #-8]
    // 0xb04aa4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04aa4: add             x25, x1, x4, lsl #2
    //     0xb04aa8: add             x25, x25, #0xf
    //     0xb04aac: str             w0, [x25]
    //     0xb04ab0: tbz             w0, #0, #0xb04acc
    //     0xb04ab4: ldurb           w16, [x1, #-1]
    //     0xb04ab8: ldurb           w17, [x0, #-1]
    //     0xb04abc: and             x16, x17, x16, lsr #2
    //     0xb04ac0: tst             x16, HEAP, lsr #32
    //     0xb04ac4: b.eq            #0xb04acc
    //     0xb04ac8: bl              #0xd67e5c
    // 0xb04acc: r17 = 295
    //     0xb04acc: mov             x17, #0x127
    // 0xb04ad0: ldr             w0, [x3, x17]
    // 0xb04ad4: DecompressPointer r0
    //     0xb04ad4: add             x0, x0, HEAP, lsl #32
    // 0xb04ad8: stur            x0, [fp, #-8]
    // 0xb04adc: LoadField: r1 = r7->field_b
    //     0xb04adc: ldur            w1, [x7, #0xb]
    // 0xb04ae0: DecompressPointer r1
    //     0xb04ae0: add             x1, x1, HEAP, lsl #32
    // 0xb04ae4: cmp             w6, w1
    // 0xb04ae8: b.ne            #0xb04af8
    // 0xb04aec: SaveReg r2
    //     0xb04aec: str             x2, [SP, #-8]!
    // 0xb04af0: r0 = _growToNextCapacity()
    //     0xb04af0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04af4: add             SP, SP, #8
    // 0xb04af8: ldr             x3, [fp, #0x10]
    // 0xb04afc: ldur            x4, [fp, #-0x20]
    // 0xb04b00: ldur            x2, [fp, #-0x18]
    // 0xb04b04: add             x5, x4, #1
    // 0xb04b08: stur            x5, [fp, #-0x28]
    // 0xb04b0c: lsl             x6, x5, #1
    // 0xb04b10: StoreField: r2->field_b = r6
    //     0xb04b10: stur            w6, [x2, #0xb]
    // 0xb04b14: mov             x0, x5
    // 0xb04b18: mov             x1, x4
    // 0xb04b1c: cmp             x1, x0
    // 0xb04b20: b.hs            #0xb056fc
    // 0xb04b24: LoadField: r7 = r2->field_f
    //     0xb04b24: ldur            w7, [x2, #0xf]
    // 0xb04b28: DecompressPointer r7
    //     0xb04b28: add             x7, x7, HEAP, lsl #32
    // 0xb04b2c: mov             x1, x7
    // 0xb04b30: ldur            x0, [fp, #-8]
    // 0xb04b34: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04b34: add             x25, x1, x4, lsl #2
    //     0xb04b38: add             x25, x25, #0xf
    //     0xb04b3c: str             w0, [x25]
    //     0xb04b40: tbz             w0, #0, #0xb04b5c
    //     0xb04b44: ldurb           w16, [x1, #-1]
    //     0xb04b48: ldurb           w17, [x0, #-1]
    //     0xb04b4c: and             x16, x17, x16, lsr #2
    //     0xb04b50: tst             x16, HEAP, lsr #32
    //     0xb04b54: b.eq            #0xb04b5c
    //     0xb04b58: bl              #0xd67e5c
    // 0xb04b5c: r17 = 299
    //     0xb04b5c: mov             x17, #0x12b
    // 0xb04b60: ldr             w0, [x3, x17]
    // 0xb04b64: DecompressPointer r0
    //     0xb04b64: add             x0, x0, HEAP, lsl #32
    // 0xb04b68: stur            x0, [fp, #-8]
    // 0xb04b6c: LoadField: r1 = r7->field_b
    //     0xb04b6c: ldur            w1, [x7, #0xb]
    // 0xb04b70: DecompressPointer r1
    //     0xb04b70: add             x1, x1, HEAP, lsl #32
    // 0xb04b74: cmp             w6, w1
    // 0xb04b78: b.ne            #0xb04b88
    // 0xb04b7c: SaveReg r2
    //     0xb04b7c: str             x2, [SP, #-8]!
    // 0xb04b80: r0 = _growToNextCapacity()
    //     0xb04b80: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04b84: add             SP, SP, #8
    // 0xb04b88: ldr             x3, [fp, #0x10]
    // 0xb04b8c: ldur            x4, [fp, #-0x28]
    // 0xb04b90: ldur            x2, [fp, #-0x18]
    // 0xb04b94: add             x5, x4, #1
    // 0xb04b98: stur            x5, [fp, #-0x20]
    // 0xb04b9c: lsl             x6, x5, #1
    // 0xb04ba0: StoreField: r2->field_b = r6
    //     0xb04ba0: stur            w6, [x2, #0xb]
    // 0xb04ba4: mov             x0, x5
    // 0xb04ba8: mov             x1, x4
    // 0xb04bac: cmp             x1, x0
    // 0xb04bb0: b.hs            #0xb05700
    // 0xb04bb4: LoadField: r7 = r2->field_f
    //     0xb04bb4: ldur            w7, [x2, #0xf]
    // 0xb04bb8: DecompressPointer r7
    //     0xb04bb8: add             x7, x7, HEAP, lsl #32
    // 0xb04bbc: mov             x1, x7
    // 0xb04bc0: ldur            x0, [fp, #-8]
    // 0xb04bc4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04bc4: add             x25, x1, x4, lsl #2
    //     0xb04bc8: add             x25, x25, #0xf
    //     0xb04bcc: str             w0, [x25]
    //     0xb04bd0: tbz             w0, #0, #0xb04bec
    //     0xb04bd4: ldurb           w16, [x1, #-1]
    //     0xb04bd8: ldurb           w17, [x0, #-1]
    //     0xb04bdc: and             x16, x17, x16, lsr #2
    //     0xb04be0: tst             x16, HEAP, lsr #32
    //     0xb04be4: b.eq            #0xb04bec
    //     0xb04be8: bl              #0xd67e5c
    // 0xb04bec: r17 = 303
    //     0xb04bec: mov             x17, #0x12f
    // 0xb04bf0: ldr             w0, [x3, x17]
    // 0xb04bf4: DecompressPointer r0
    //     0xb04bf4: add             x0, x0, HEAP, lsl #32
    // 0xb04bf8: stur            x0, [fp, #-8]
    // 0xb04bfc: LoadField: r1 = r7->field_b
    //     0xb04bfc: ldur            w1, [x7, #0xb]
    // 0xb04c00: DecompressPointer r1
    //     0xb04c00: add             x1, x1, HEAP, lsl #32
    // 0xb04c04: cmp             w6, w1
    // 0xb04c08: b.ne            #0xb04c18
    // 0xb04c0c: SaveReg r2
    //     0xb04c0c: str             x2, [SP, #-8]!
    // 0xb04c10: r0 = _growToNextCapacity()
    //     0xb04c10: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04c14: add             SP, SP, #8
    // 0xb04c18: ldr             x3, [fp, #0x10]
    // 0xb04c1c: ldur            x4, [fp, #-0x20]
    // 0xb04c20: ldur            x2, [fp, #-0x18]
    // 0xb04c24: add             x5, x4, #1
    // 0xb04c28: stur            x5, [fp, #-0x28]
    // 0xb04c2c: lsl             x6, x5, #1
    // 0xb04c30: StoreField: r2->field_b = r6
    //     0xb04c30: stur            w6, [x2, #0xb]
    // 0xb04c34: mov             x0, x5
    // 0xb04c38: mov             x1, x4
    // 0xb04c3c: cmp             x1, x0
    // 0xb04c40: b.hs            #0xb05704
    // 0xb04c44: LoadField: r7 = r2->field_f
    //     0xb04c44: ldur            w7, [x2, #0xf]
    // 0xb04c48: DecompressPointer r7
    //     0xb04c48: add             x7, x7, HEAP, lsl #32
    // 0xb04c4c: mov             x1, x7
    // 0xb04c50: ldur            x0, [fp, #-8]
    // 0xb04c54: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04c54: add             x25, x1, x4, lsl #2
    //     0xb04c58: add             x25, x25, #0xf
    //     0xb04c5c: str             w0, [x25]
    //     0xb04c60: tbz             w0, #0, #0xb04c7c
    //     0xb04c64: ldurb           w16, [x1, #-1]
    //     0xb04c68: ldurb           w17, [x0, #-1]
    //     0xb04c6c: and             x16, x17, x16, lsr #2
    //     0xb04c70: tst             x16, HEAP, lsr #32
    //     0xb04c74: b.eq            #0xb04c7c
    //     0xb04c78: bl              #0xd67e5c
    // 0xb04c7c: r17 = 307
    //     0xb04c7c: mov             x17, #0x133
    // 0xb04c80: ldr             w0, [x3, x17]
    // 0xb04c84: DecompressPointer r0
    //     0xb04c84: add             x0, x0, HEAP, lsl #32
    // 0xb04c88: stur            x0, [fp, #-8]
    // 0xb04c8c: LoadField: r1 = r7->field_b
    //     0xb04c8c: ldur            w1, [x7, #0xb]
    // 0xb04c90: DecompressPointer r1
    //     0xb04c90: add             x1, x1, HEAP, lsl #32
    // 0xb04c94: cmp             w6, w1
    // 0xb04c98: b.ne            #0xb04ca8
    // 0xb04c9c: SaveReg r2
    //     0xb04c9c: str             x2, [SP, #-8]!
    // 0xb04ca0: r0 = _growToNextCapacity()
    //     0xb04ca0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04ca4: add             SP, SP, #8
    // 0xb04ca8: ldr             x3, [fp, #0x10]
    // 0xb04cac: ldur            x4, [fp, #-0x28]
    // 0xb04cb0: ldur            x2, [fp, #-0x18]
    // 0xb04cb4: add             x5, x4, #1
    // 0xb04cb8: stur            x5, [fp, #-0x20]
    // 0xb04cbc: lsl             x6, x5, #1
    // 0xb04cc0: StoreField: r2->field_b = r6
    //     0xb04cc0: stur            w6, [x2, #0xb]
    // 0xb04cc4: mov             x0, x5
    // 0xb04cc8: mov             x1, x4
    // 0xb04ccc: cmp             x1, x0
    // 0xb04cd0: b.hs            #0xb05708
    // 0xb04cd4: LoadField: r7 = r2->field_f
    //     0xb04cd4: ldur            w7, [x2, #0xf]
    // 0xb04cd8: DecompressPointer r7
    //     0xb04cd8: add             x7, x7, HEAP, lsl #32
    // 0xb04cdc: mov             x1, x7
    // 0xb04ce0: ldur            x0, [fp, #-8]
    // 0xb04ce4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04ce4: add             x25, x1, x4, lsl #2
    //     0xb04ce8: add             x25, x25, #0xf
    //     0xb04cec: str             w0, [x25]
    //     0xb04cf0: tbz             w0, #0, #0xb04d0c
    //     0xb04cf4: ldurb           w16, [x1, #-1]
    //     0xb04cf8: ldurb           w17, [x0, #-1]
    //     0xb04cfc: and             x16, x17, x16, lsr #2
    //     0xb04d00: tst             x16, HEAP, lsr #32
    //     0xb04d04: b.eq            #0xb04d0c
    //     0xb04d08: bl              #0xd67e5c
    // 0xb04d0c: r17 = 311
    //     0xb04d0c: mov             x17, #0x137
    // 0xb04d10: ldr             w0, [x3, x17]
    // 0xb04d14: DecompressPointer r0
    //     0xb04d14: add             x0, x0, HEAP, lsl #32
    // 0xb04d18: stur            x0, [fp, #-8]
    // 0xb04d1c: LoadField: r1 = r7->field_b
    //     0xb04d1c: ldur            w1, [x7, #0xb]
    // 0xb04d20: DecompressPointer r1
    //     0xb04d20: add             x1, x1, HEAP, lsl #32
    // 0xb04d24: cmp             w6, w1
    // 0xb04d28: b.ne            #0xb04d38
    // 0xb04d2c: SaveReg r2
    //     0xb04d2c: str             x2, [SP, #-8]!
    // 0xb04d30: r0 = _growToNextCapacity()
    //     0xb04d30: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04d34: add             SP, SP, #8
    // 0xb04d38: ldr             x3, [fp, #0x10]
    // 0xb04d3c: ldur            x4, [fp, #-0x20]
    // 0xb04d40: ldur            x2, [fp, #-0x18]
    // 0xb04d44: add             x5, x4, #1
    // 0xb04d48: stur            x5, [fp, #-0x28]
    // 0xb04d4c: lsl             x6, x5, #1
    // 0xb04d50: StoreField: r2->field_b = r6
    //     0xb04d50: stur            w6, [x2, #0xb]
    // 0xb04d54: mov             x0, x5
    // 0xb04d58: mov             x1, x4
    // 0xb04d5c: cmp             x1, x0
    // 0xb04d60: b.hs            #0xb0570c
    // 0xb04d64: LoadField: r7 = r2->field_f
    //     0xb04d64: ldur            w7, [x2, #0xf]
    // 0xb04d68: DecompressPointer r7
    //     0xb04d68: add             x7, x7, HEAP, lsl #32
    // 0xb04d6c: mov             x1, x7
    // 0xb04d70: ldur            x0, [fp, #-8]
    // 0xb04d74: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04d74: add             x25, x1, x4, lsl #2
    //     0xb04d78: add             x25, x25, #0xf
    //     0xb04d7c: str             w0, [x25]
    //     0xb04d80: tbz             w0, #0, #0xb04d9c
    //     0xb04d84: ldurb           w16, [x1, #-1]
    //     0xb04d88: ldurb           w17, [x0, #-1]
    //     0xb04d8c: and             x16, x17, x16, lsr #2
    //     0xb04d90: tst             x16, HEAP, lsr #32
    //     0xb04d94: b.eq            #0xb04d9c
    //     0xb04d98: bl              #0xd67e5c
    // 0xb04d9c: r17 = 315
    //     0xb04d9c: mov             x17, #0x13b
    // 0xb04da0: ldr             w0, [x3, x17]
    // 0xb04da4: DecompressPointer r0
    //     0xb04da4: add             x0, x0, HEAP, lsl #32
    // 0xb04da8: stur            x0, [fp, #-8]
    // 0xb04dac: LoadField: r1 = r7->field_b
    //     0xb04dac: ldur            w1, [x7, #0xb]
    // 0xb04db0: DecompressPointer r1
    //     0xb04db0: add             x1, x1, HEAP, lsl #32
    // 0xb04db4: cmp             w6, w1
    // 0xb04db8: b.ne            #0xb04dc8
    // 0xb04dbc: SaveReg r2
    //     0xb04dbc: str             x2, [SP, #-8]!
    // 0xb04dc0: r0 = _growToNextCapacity()
    //     0xb04dc0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04dc4: add             SP, SP, #8
    // 0xb04dc8: ldr             x3, [fp, #0x10]
    // 0xb04dcc: ldur            x4, [fp, #-0x28]
    // 0xb04dd0: ldur            x2, [fp, #-0x18]
    // 0xb04dd4: add             x5, x4, #1
    // 0xb04dd8: stur            x5, [fp, #-0x20]
    // 0xb04ddc: lsl             x6, x5, #1
    // 0xb04de0: StoreField: r2->field_b = r6
    //     0xb04de0: stur            w6, [x2, #0xb]
    // 0xb04de4: mov             x0, x5
    // 0xb04de8: mov             x1, x4
    // 0xb04dec: cmp             x1, x0
    // 0xb04df0: b.hs            #0xb05710
    // 0xb04df4: LoadField: r7 = r2->field_f
    //     0xb04df4: ldur            w7, [x2, #0xf]
    // 0xb04df8: DecompressPointer r7
    //     0xb04df8: add             x7, x7, HEAP, lsl #32
    // 0xb04dfc: mov             x1, x7
    // 0xb04e00: ldur            x0, [fp, #-8]
    // 0xb04e04: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04e04: add             x25, x1, x4, lsl #2
    //     0xb04e08: add             x25, x25, #0xf
    //     0xb04e0c: str             w0, [x25]
    //     0xb04e10: tbz             w0, #0, #0xb04e2c
    //     0xb04e14: ldurb           w16, [x1, #-1]
    //     0xb04e18: ldurb           w17, [x0, #-1]
    //     0xb04e1c: and             x16, x17, x16, lsr #2
    //     0xb04e20: tst             x16, HEAP, lsr #32
    //     0xb04e24: b.eq            #0xb04e2c
    //     0xb04e28: bl              #0xd67e5c
    // 0xb04e2c: r17 = 319
    //     0xb04e2c: mov             x17, #0x13f
    // 0xb04e30: ldr             w0, [x3, x17]
    // 0xb04e34: DecompressPointer r0
    //     0xb04e34: add             x0, x0, HEAP, lsl #32
    // 0xb04e38: stur            x0, [fp, #-8]
    // 0xb04e3c: LoadField: r1 = r7->field_b
    //     0xb04e3c: ldur            w1, [x7, #0xb]
    // 0xb04e40: DecompressPointer r1
    //     0xb04e40: add             x1, x1, HEAP, lsl #32
    // 0xb04e44: cmp             w6, w1
    // 0xb04e48: b.ne            #0xb04e58
    // 0xb04e4c: SaveReg r2
    //     0xb04e4c: str             x2, [SP, #-8]!
    // 0xb04e50: r0 = _growToNextCapacity()
    //     0xb04e50: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04e54: add             SP, SP, #8
    // 0xb04e58: ldr             x3, [fp, #0x10]
    // 0xb04e5c: ldur            x4, [fp, #-0x20]
    // 0xb04e60: ldur            x2, [fp, #-0x18]
    // 0xb04e64: add             x5, x4, #1
    // 0xb04e68: stur            x5, [fp, #-0x28]
    // 0xb04e6c: lsl             x6, x5, #1
    // 0xb04e70: StoreField: r2->field_b = r6
    //     0xb04e70: stur            w6, [x2, #0xb]
    // 0xb04e74: mov             x0, x5
    // 0xb04e78: mov             x1, x4
    // 0xb04e7c: cmp             x1, x0
    // 0xb04e80: b.hs            #0xb05714
    // 0xb04e84: LoadField: r7 = r2->field_f
    //     0xb04e84: ldur            w7, [x2, #0xf]
    // 0xb04e88: DecompressPointer r7
    //     0xb04e88: add             x7, x7, HEAP, lsl #32
    // 0xb04e8c: mov             x1, x7
    // 0xb04e90: ldur            x0, [fp, #-8]
    // 0xb04e94: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04e94: add             x25, x1, x4, lsl #2
    //     0xb04e98: add             x25, x25, #0xf
    //     0xb04e9c: str             w0, [x25]
    //     0xb04ea0: tbz             w0, #0, #0xb04ebc
    //     0xb04ea4: ldurb           w16, [x1, #-1]
    //     0xb04ea8: ldurb           w17, [x0, #-1]
    //     0xb04eac: and             x16, x17, x16, lsr #2
    //     0xb04eb0: tst             x16, HEAP, lsr #32
    //     0xb04eb4: b.eq            #0xb04ebc
    //     0xb04eb8: bl              #0xd67e5c
    // 0xb04ebc: r17 = 323
    //     0xb04ebc: mov             x17, #0x143
    // 0xb04ec0: ldr             w0, [x3, x17]
    // 0xb04ec4: DecompressPointer r0
    //     0xb04ec4: add             x0, x0, HEAP, lsl #32
    // 0xb04ec8: stur            x0, [fp, #-8]
    // 0xb04ecc: cmp             w0, NULL
    // 0xb04ed0: b.eq            #0xb05718
    // 0xb04ed4: LoadField: r1 = r7->field_b
    //     0xb04ed4: ldur            w1, [x7, #0xb]
    // 0xb04ed8: DecompressPointer r1
    //     0xb04ed8: add             x1, x1, HEAP, lsl #32
    // 0xb04edc: cmp             w6, w1
    // 0xb04ee0: b.ne            #0xb04ef0
    // 0xb04ee4: SaveReg r2
    //     0xb04ee4: str             x2, [SP, #-8]!
    // 0xb04ee8: r0 = _growToNextCapacity()
    //     0xb04ee8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04eec: add             SP, SP, #8
    // 0xb04ef0: ldr             x3, [fp, #0x10]
    // 0xb04ef4: ldur            x4, [fp, #-0x28]
    // 0xb04ef8: ldur            x2, [fp, #-0x18]
    // 0xb04efc: add             x5, x4, #1
    // 0xb04f00: stur            x5, [fp, #-0x20]
    // 0xb04f04: lsl             x6, x5, #1
    // 0xb04f08: StoreField: r2->field_b = r6
    //     0xb04f08: stur            w6, [x2, #0xb]
    // 0xb04f0c: mov             x0, x5
    // 0xb04f10: mov             x1, x4
    // 0xb04f14: cmp             x1, x0
    // 0xb04f18: b.hs            #0xb0571c
    // 0xb04f1c: LoadField: r7 = r2->field_f
    //     0xb04f1c: ldur            w7, [x2, #0xf]
    // 0xb04f20: DecompressPointer r7
    //     0xb04f20: add             x7, x7, HEAP, lsl #32
    // 0xb04f24: mov             x1, x7
    // 0xb04f28: ldur            x0, [fp, #-8]
    // 0xb04f2c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04f2c: add             x25, x1, x4, lsl #2
    //     0xb04f30: add             x25, x25, #0xf
    //     0xb04f34: str             w0, [x25]
    //     0xb04f38: tbz             w0, #0, #0xb04f54
    //     0xb04f3c: ldurb           w16, [x1, #-1]
    //     0xb04f40: ldurb           w17, [x0, #-1]
    //     0xb04f44: and             x16, x17, x16, lsr #2
    //     0xb04f48: tst             x16, HEAP, lsr #32
    //     0xb04f4c: b.eq            #0xb04f54
    //     0xb04f50: bl              #0xd67e5c
    // 0xb04f54: r17 = 327
    //     0xb04f54: mov             x17, #0x147
    // 0xb04f58: ldr             w0, [x3, x17]
    // 0xb04f5c: DecompressPointer r0
    //     0xb04f5c: add             x0, x0, HEAP, lsl #32
    // 0xb04f60: stur            x0, [fp, #-8]
    // 0xb04f64: LoadField: r1 = r7->field_b
    //     0xb04f64: ldur            w1, [x7, #0xb]
    // 0xb04f68: DecompressPointer r1
    //     0xb04f68: add             x1, x1, HEAP, lsl #32
    // 0xb04f6c: cmp             w6, w1
    // 0xb04f70: b.ne            #0xb04f80
    // 0xb04f74: SaveReg r2
    //     0xb04f74: str             x2, [SP, #-8]!
    // 0xb04f78: r0 = _growToNextCapacity()
    //     0xb04f78: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb04f7c: add             SP, SP, #8
    // 0xb04f80: ldr             x3, [fp, #0x10]
    // 0xb04f84: ldur            x4, [fp, #-0x20]
    // 0xb04f88: ldur            x2, [fp, #-0x18]
    // 0xb04f8c: add             x5, x4, #1
    // 0xb04f90: stur            x5, [fp, #-0x28]
    // 0xb04f94: lsl             x6, x5, #1
    // 0xb04f98: StoreField: r2->field_b = r6
    //     0xb04f98: stur            w6, [x2, #0xb]
    // 0xb04f9c: mov             x0, x5
    // 0xb04fa0: mov             x1, x4
    // 0xb04fa4: cmp             x1, x0
    // 0xb04fa8: b.hs            #0xb05720
    // 0xb04fac: LoadField: r7 = r2->field_f
    //     0xb04fac: ldur            w7, [x2, #0xf]
    // 0xb04fb0: DecompressPointer r7
    //     0xb04fb0: add             x7, x7, HEAP, lsl #32
    // 0xb04fb4: mov             x1, x7
    // 0xb04fb8: ldur            x0, [fp, #-8]
    // 0xb04fbc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb04fbc: add             x25, x1, x4, lsl #2
    //     0xb04fc0: add             x25, x25, #0xf
    //     0xb04fc4: str             w0, [x25]
    //     0xb04fc8: tbz             w0, #0, #0xb04fe4
    //     0xb04fcc: ldurb           w16, [x1, #-1]
    //     0xb04fd0: ldurb           w17, [x0, #-1]
    //     0xb04fd4: and             x16, x17, x16, lsr #2
    //     0xb04fd8: tst             x16, HEAP, lsr #32
    //     0xb04fdc: b.eq            #0xb04fe4
    //     0xb04fe0: bl              #0xd67e5c
    // 0xb04fe4: r17 = 331
    //     0xb04fe4: mov             x17, #0x14b
    // 0xb04fe8: ldr             w0, [x3, x17]
    // 0xb04fec: DecompressPointer r0
    //     0xb04fec: add             x0, x0, HEAP, lsl #32
    // 0xb04ff0: stur            x0, [fp, #-8]
    // 0xb04ff4: LoadField: r1 = r7->field_b
    //     0xb04ff4: ldur            w1, [x7, #0xb]
    // 0xb04ff8: DecompressPointer r1
    //     0xb04ff8: add             x1, x1, HEAP, lsl #32
    // 0xb04ffc: cmp             w6, w1
    // 0xb05000: b.ne            #0xb05010
    // 0xb05004: SaveReg r2
    //     0xb05004: str             x2, [SP, #-8]!
    // 0xb05008: r0 = _growToNextCapacity()
    //     0xb05008: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0500c: add             SP, SP, #8
    // 0xb05010: ldr             x3, [fp, #0x10]
    // 0xb05014: ldur            x4, [fp, #-0x28]
    // 0xb05018: ldur            x2, [fp, #-0x18]
    // 0xb0501c: add             x5, x4, #1
    // 0xb05020: stur            x5, [fp, #-0x20]
    // 0xb05024: lsl             x6, x5, #1
    // 0xb05028: StoreField: r2->field_b = r6
    //     0xb05028: stur            w6, [x2, #0xb]
    // 0xb0502c: mov             x0, x5
    // 0xb05030: mov             x1, x4
    // 0xb05034: cmp             x1, x0
    // 0xb05038: b.hs            #0xb05724
    // 0xb0503c: LoadField: r7 = r2->field_f
    //     0xb0503c: ldur            w7, [x2, #0xf]
    // 0xb05040: DecompressPointer r7
    //     0xb05040: add             x7, x7, HEAP, lsl #32
    // 0xb05044: mov             x1, x7
    // 0xb05048: ldur            x0, [fp, #-8]
    // 0xb0504c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb0504c: add             x25, x1, x4, lsl #2
    //     0xb05050: add             x25, x25, #0xf
    //     0xb05054: str             w0, [x25]
    //     0xb05058: tbz             w0, #0, #0xb05074
    //     0xb0505c: ldurb           w16, [x1, #-1]
    //     0xb05060: ldurb           w17, [x0, #-1]
    //     0xb05064: and             x16, x17, x16, lsr #2
    //     0xb05068: tst             x16, HEAP, lsr #32
    //     0xb0506c: b.eq            #0xb05074
    //     0xb05070: bl              #0xd67e5c
    // 0xb05074: r17 = 335
    //     0xb05074: mov             x17, #0x14f
    // 0xb05078: ldr             w0, [x3, x17]
    // 0xb0507c: DecompressPointer r0
    //     0xb0507c: add             x0, x0, HEAP, lsl #32
    // 0xb05080: stur            x0, [fp, #-8]
    // 0xb05084: LoadField: r1 = r7->field_b
    //     0xb05084: ldur            w1, [x7, #0xb]
    // 0xb05088: DecompressPointer r1
    //     0xb05088: add             x1, x1, HEAP, lsl #32
    // 0xb0508c: cmp             w6, w1
    // 0xb05090: b.ne            #0xb050a0
    // 0xb05094: SaveReg r2
    //     0xb05094: str             x2, [SP, #-8]!
    // 0xb05098: r0 = _growToNextCapacity()
    //     0xb05098: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0509c: add             SP, SP, #8
    // 0xb050a0: ldr             x3, [fp, #0x10]
    // 0xb050a4: ldur            x4, [fp, #-0x20]
    // 0xb050a8: ldur            x2, [fp, #-0x18]
    // 0xb050ac: add             x5, x4, #1
    // 0xb050b0: stur            x5, [fp, #-0x28]
    // 0xb050b4: lsl             x6, x5, #1
    // 0xb050b8: StoreField: r2->field_b = r6
    //     0xb050b8: stur            w6, [x2, #0xb]
    // 0xb050bc: mov             x0, x5
    // 0xb050c0: mov             x1, x4
    // 0xb050c4: cmp             x1, x0
    // 0xb050c8: b.hs            #0xb05728
    // 0xb050cc: LoadField: r7 = r2->field_f
    //     0xb050cc: ldur            w7, [x2, #0xf]
    // 0xb050d0: DecompressPointer r7
    //     0xb050d0: add             x7, x7, HEAP, lsl #32
    // 0xb050d4: mov             x1, x7
    // 0xb050d8: ldur            x0, [fp, #-8]
    // 0xb050dc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb050dc: add             x25, x1, x4, lsl #2
    //     0xb050e0: add             x25, x25, #0xf
    //     0xb050e4: str             w0, [x25]
    //     0xb050e8: tbz             w0, #0, #0xb05104
    //     0xb050ec: ldurb           w16, [x1, #-1]
    //     0xb050f0: ldurb           w17, [x0, #-1]
    //     0xb050f4: and             x16, x17, x16, lsr #2
    //     0xb050f8: tst             x16, HEAP, lsr #32
    //     0xb050fc: b.eq            #0xb05104
    //     0xb05100: bl              #0xd67e5c
    // 0xb05104: r17 = 339
    //     0xb05104: mov             x17, #0x153
    // 0xb05108: ldr             w0, [x3, x17]
    // 0xb0510c: DecompressPointer r0
    //     0xb0510c: add             x0, x0, HEAP, lsl #32
    // 0xb05110: stur            x0, [fp, #-8]
    // 0xb05114: cmp             w0, NULL
    // 0xb05118: b.eq            #0xb0572c
    // 0xb0511c: LoadField: r1 = r7->field_b
    //     0xb0511c: ldur            w1, [x7, #0xb]
    // 0xb05120: DecompressPointer r1
    //     0xb05120: add             x1, x1, HEAP, lsl #32
    // 0xb05124: cmp             w6, w1
    // 0xb05128: b.ne            #0xb05138
    // 0xb0512c: SaveReg r2
    //     0xb0512c: str             x2, [SP, #-8]!
    // 0xb05130: r0 = _growToNextCapacity()
    //     0xb05130: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb05134: add             SP, SP, #8
    // 0xb05138: ldur            x3, [fp, #-0x28]
    // 0xb0513c: ldur            x2, [fp, #-0x18]
    // 0xb05140: add             x4, x3, #1
    // 0xb05144: stur            x4, [fp, #-0x20]
    // 0xb05148: lsl             x5, x4, #1
    // 0xb0514c: StoreField: r2->field_b = r5
    //     0xb0514c: stur            w5, [x2, #0xb]
    // 0xb05150: mov             x0, x4
    // 0xb05154: mov             x1, x3
    // 0xb05158: cmp             x1, x0
    // 0xb0515c: b.hs            #0xb05730
    // 0xb05160: LoadField: r6 = r2->field_f
    //     0xb05160: ldur            w6, [x2, #0xf]
    // 0xb05164: DecompressPointer r6
    //     0xb05164: add             x6, x6, HEAP, lsl #32
    // 0xb05168: mov             x1, x6
    // 0xb0516c: ldur            x0, [fp, #-8]
    // 0xb05170: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb05170: add             x25, x1, x3, lsl #2
    //     0xb05174: add             x25, x25, #0xf
    //     0xb05178: str             w0, [x25]
    //     0xb0517c: tbz             w0, #0, #0xb05198
    //     0xb05180: ldurb           w16, [x1, #-1]
    //     0xb05184: ldurb           w17, [x0, #-1]
    //     0xb05188: and             x16, x17, x16, lsr #2
    //     0xb0518c: tst             x16, HEAP, lsr #32
    //     0xb05190: b.eq            #0xb05198
    //     0xb05194: bl              #0xd67e5c
    // 0xb05198: LoadField: r0 = r6->field_b
    //     0xb05198: ldur            w0, [x6, #0xb]
    // 0xb0519c: DecompressPointer r0
    //     0xb0519c: add             x0, x0, HEAP, lsl #32
    // 0xb051a0: cmp             w5, w0
    // 0xb051a4: b.ne            #0xb051b4
    // 0xb051a8: SaveReg r2
    //     0xb051a8: str             x2, [SP, #-8]!
    // 0xb051ac: r0 = _growToNextCapacity()
    //     0xb051ac: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb051b0: add             SP, SP, #8
    // 0xb051b4: ldr             x4, [fp, #0x10]
    // 0xb051b8: ldur            x3, [fp, #-0x20]
    // 0xb051bc: ldur            x2, [fp, #-0x18]
    // 0xb051c0: add             x5, x3, #1
    // 0xb051c4: stur            x5, [fp, #-0x28]
    // 0xb051c8: lsl             x6, x5, #1
    // 0xb051cc: StoreField: r2->field_b = r6
    //     0xb051cc: stur            w6, [x2, #0xb]
    // 0xb051d0: mov             x0, x5
    // 0xb051d4: mov             x1, x3
    // 0xb051d8: cmp             x1, x0
    // 0xb051dc: b.hs            #0xb05734
    // 0xb051e0: LoadField: r0 = r2->field_f
    //     0xb051e0: ldur            w0, [x2, #0xf]
    // 0xb051e4: DecompressPointer r0
    //     0xb051e4: add             x0, x0, HEAP, lsl #32
    // 0xb051e8: add             x1, x0, x3, lsl #2
    // 0xb051ec: r17 = true
    //     0xb051ec: add             x17, NULL, #0x20  ; true
    // 0xb051f0: StoreField: r1->field_f = r17
    //     0xb051f0: stur            w17, [x1, #0xf]
    // 0xb051f4: r17 = 347
    //     0xb051f4: mov             x17, #0x15b
    // 0xb051f8: ldr             w1, [x4, x17]
    // 0xb051fc: DecompressPointer r1
    //     0xb051fc: add             x1, x1, HEAP, lsl #32
    // 0xb05200: stur            x1, [fp, #-8]
    // 0xb05204: LoadField: r3 = r0->field_b
    //     0xb05204: ldur            w3, [x0, #0xb]
    // 0xb05208: DecompressPointer r3
    //     0xb05208: add             x3, x3, HEAP, lsl #32
    // 0xb0520c: cmp             w6, w3
    // 0xb05210: b.ne            #0xb05220
    // 0xb05214: SaveReg r2
    //     0xb05214: str             x2, [SP, #-8]!
    // 0xb05218: r0 = _growToNextCapacity()
    //     0xb05218: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0521c: add             SP, SP, #8
    // 0xb05220: ldur            x3, [fp, #-0x28]
    // 0xb05224: ldur            x2, [fp, #-0x18]
    // 0xb05228: add             x4, x3, #1
    // 0xb0522c: stur            x4, [fp, #-0x20]
    // 0xb05230: lsl             x5, x4, #1
    // 0xb05234: StoreField: r2->field_b = r5
    //     0xb05234: stur            w5, [x2, #0xb]
    // 0xb05238: mov             x0, x4
    // 0xb0523c: mov             x1, x3
    // 0xb05240: cmp             x1, x0
    // 0xb05244: b.hs            #0xb05738
    // 0xb05248: LoadField: r6 = r2->field_f
    //     0xb05248: ldur            w6, [x2, #0xf]
    // 0xb0524c: DecompressPointer r6
    //     0xb0524c: add             x6, x6, HEAP, lsl #32
    // 0xb05250: mov             x1, x6
    // 0xb05254: ldur            x0, [fp, #-8]
    // 0xb05258: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb05258: add             x25, x1, x3, lsl #2
    //     0xb0525c: add             x25, x25, #0xf
    //     0xb05260: str             w0, [x25]
    //     0xb05264: tbz             w0, #0, #0xb05280
    //     0xb05268: ldurb           w16, [x1, #-1]
    //     0xb0526c: ldurb           w17, [x0, #-1]
    //     0xb05270: and             x16, x17, x16, lsr #2
    //     0xb05274: tst             x16, HEAP, lsr #32
    //     0xb05278: b.eq            #0xb05280
    //     0xb0527c: bl              #0xd67e5c
    // 0xb05280: LoadField: r0 = r6->field_b
    //     0xb05280: ldur            w0, [x6, #0xb]
    // 0xb05284: DecompressPointer r0
    //     0xb05284: add             x0, x0, HEAP, lsl #32
    // 0xb05288: cmp             w5, w0
    // 0xb0528c: b.ne            #0xb0529c
    // 0xb05290: SaveReg r2
    //     0xb05290: str             x2, [SP, #-8]!
    // 0xb05294: r0 = _growToNextCapacity()
    //     0xb05294: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb05298: add             SP, SP, #8
    // 0xb0529c: ldr             x4, [fp, #0x10]
    // 0xb052a0: ldur            x3, [fp, #-0x20]
    // 0xb052a4: ldur            x2, [fp, #-0x18]
    // 0xb052a8: add             x5, x3, #1
    // 0xb052ac: stur            x5, [fp, #-0x28]
    // 0xb052b0: lsl             x6, x5, #1
    // 0xb052b4: StoreField: r2->field_b = r6
    //     0xb052b4: stur            w6, [x2, #0xb]
    // 0xb052b8: mov             x0, x5
    // 0xb052bc: mov             x1, x3
    // 0xb052c0: cmp             x1, x0
    // 0xb052c4: b.hs            #0xb0573c
    // 0xb052c8: LoadField: r0 = r2->field_f
    //     0xb052c8: ldur            w0, [x2, #0xf]
    // 0xb052cc: DecompressPointer r0
    //     0xb052cc: add             x0, x0, HEAP, lsl #32
    // 0xb052d0: ArrayStore: r0[r3] = rNULL  ; Unknown_4
    //     0xb052d0: add             x1, x0, x3, lsl #2
    //     0xb052d4: stur            NULL, [x1, #0xf]
    // 0xb052d8: r17 = 363
    //     0xb052d8: mov             x17, #0x16b
    // 0xb052dc: ldr             w1, [x4, x17]
    // 0xb052e0: DecompressPointer r1
    //     0xb052e0: add             x1, x1, HEAP, lsl #32
    // 0xb052e4: stur            x1, [fp, #-8]
    // 0xb052e8: cmp             w1, NULL
    // 0xb052ec: b.eq            #0xb05740
    // 0xb052f0: LoadField: r3 = r0->field_b
    //     0xb052f0: ldur            w3, [x0, #0xb]
    // 0xb052f4: DecompressPointer r3
    //     0xb052f4: add             x3, x3, HEAP, lsl #32
    // 0xb052f8: cmp             w6, w3
    // 0xb052fc: b.ne            #0xb0530c
    // 0xb05300: SaveReg r2
    //     0xb05300: str             x2, [SP, #-8]!
    // 0xb05304: r0 = _growToNextCapacity()
    //     0xb05304: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb05308: add             SP, SP, #8
    // 0xb0530c: ldr             x3, [fp, #0x10]
    // 0xb05310: ldur            x4, [fp, #-0x28]
    // 0xb05314: ldur            x2, [fp, #-0x18]
    // 0xb05318: add             x5, x4, #1
    // 0xb0531c: stur            x5, [fp, #-0x20]
    // 0xb05320: lsl             x6, x5, #1
    // 0xb05324: StoreField: r2->field_b = r6
    //     0xb05324: stur            w6, [x2, #0xb]
    // 0xb05328: mov             x0, x5
    // 0xb0532c: mov             x1, x4
    // 0xb05330: cmp             x1, x0
    // 0xb05334: b.hs            #0xb05744
    // 0xb05338: LoadField: r7 = r2->field_f
    //     0xb05338: ldur            w7, [x2, #0xf]
    // 0xb0533c: DecompressPointer r7
    //     0xb0533c: add             x7, x7, HEAP, lsl #32
    // 0xb05340: mov             x1, x7
    // 0xb05344: ldur            x0, [fp, #-8]
    // 0xb05348: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb05348: add             x25, x1, x4, lsl #2
    //     0xb0534c: add             x25, x25, #0xf
    //     0xb05350: str             w0, [x25]
    //     0xb05354: tbz             w0, #0, #0xb05370
    //     0xb05358: ldurb           w16, [x1, #-1]
    //     0xb0535c: ldurb           w17, [x0, #-1]
    //     0xb05360: and             x16, x17, x16, lsr #2
    //     0xb05364: tst             x16, HEAP, lsr #32
    //     0xb05368: b.eq            #0xb05370
    //     0xb0536c: bl              #0xd67e5c
    // 0xb05370: LoadField: r0 = r3->field_77
    //     0xb05370: ldur            w0, [x3, #0x77]
    // 0xb05374: DecompressPointer r0
    //     0xb05374: add             x0, x0, HEAP, lsl #32
    // 0xb05378: stur            x0, [fp, #-8]
    // 0xb0537c: cmp             w0, NULL
    // 0xb05380: b.eq            #0xb05748
    // 0xb05384: LoadField: r1 = r7->field_b
    //     0xb05384: ldur            w1, [x7, #0xb]
    // 0xb05388: DecompressPointer r1
    //     0xb05388: add             x1, x1, HEAP, lsl #32
    // 0xb0538c: cmp             w6, w1
    // 0xb05390: b.ne            #0xb053a0
    // 0xb05394: SaveReg r2
    //     0xb05394: str             x2, [SP, #-8]!
    // 0xb05398: r0 = _growToNextCapacity()
    //     0xb05398: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb0539c: add             SP, SP, #8
    // 0xb053a0: ldr             x3, [fp, #0x10]
    // 0xb053a4: ldur            x4, [fp, #-0x20]
    // 0xb053a8: ldur            x2, [fp, #-0x18]
    // 0xb053ac: add             x5, x4, #1
    // 0xb053b0: stur            x5, [fp, #-0x28]
    // 0xb053b4: lsl             x6, x5, #1
    // 0xb053b8: StoreField: r2->field_b = r6
    //     0xb053b8: stur            w6, [x2, #0xb]
    // 0xb053bc: mov             x0, x5
    // 0xb053c0: mov             x1, x4
    // 0xb053c4: cmp             x1, x0
    // 0xb053c8: b.hs            #0xb0574c
    // 0xb053cc: LoadField: r7 = r2->field_f
    //     0xb053cc: ldur            w7, [x2, #0xf]
    // 0xb053d0: DecompressPointer r7
    //     0xb053d0: add             x7, x7, HEAP, lsl #32
    // 0xb053d4: mov             x1, x7
    // 0xb053d8: ldur            x0, [fp, #-8]
    // 0xb053dc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb053dc: add             x25, x1, x4, lsl #2
    //     0xb053e0: add             x25, x25, #0xf
    //     0xb053e4: str             w0, [x25]
    //     0xb053e8: tbz             w0, #0, #0xb05404
    //     0xb053ec: ldurb           w16, [x1, #-1]
    //     0xb053f0: ldurb           w17, [x0, #-1]
    //     0xb053f4: and             x16, x17, x16, lsr #2
    //     0xb053f8: tst             x16, HEAP, lsr #32
    //     0xb053fc: b.eq            #0xb05404
    //     0xb05400: bl              #0xd67e5c
    // 0xb05404: r17 = 355
    //     0xb05404: mov             x17, #0x163
    // 0xb05408: ldr             w0, [x3, x17]
    // 0xb0540c: DecompressPointer r0
    //     0xb0540c: add             x0, x0, HEAP, lsl #32
    // 0xb05410: stur            x0, [fp, #-8]
    // 0xb05414: cmp             w0, NULL
    // 0xb05418: b.eq            #0xb05750
    // 0xb0541c: LoadField: r1 = r7->field_b
    //     0xb0541c: ldur            w1, [x7, #0xb]
    // 0xb05420: DecompressPointer r1
    //     0xb05420: add             x1, x1, HEAP, lsl #32
    // 0xb05424: cmp             w6, w1
    // 0xb05428: b.ne            #0xb05438
    // 0xb0542c: SaveReg r2
    //     0xb0542c: str             x2, [SP, #-8]!
    // 0xb05430: r0 = _growToNextCapacity()
    //     0xb05430: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb05434: add             SP, SP, #8
    // 0xb05438: ldr             x3, [fp, #0x10]
    // 0xb0543c: ldur            x4, [fp, #-0x28]
    // 0xb05440: ldur            x2, [fp, #-0x18]
    // 0xb05444: add             x5, x4, #1
    // 0xb05448: stur            x5, [fp, #-0x20]
    // 0xb0544c: lsl             x6, x5, #1
    // 0xb05450: StoreField: r2->field_b = r6
    //     0xb05450: stur            w6, [x2, #0xb]
    // 0xb05454: mov             x0, x5
    // 0xb05458: mov             x1, x4
    // 0xb0545c: cmp             x1, x0
    // 0xb05460: b.hs            #0xb05754
    // 0xb05464: LoadField: r7 = r2->field_f
    //     0xb05464: ldur            w7, [x2, #0xf]
    // 0xb05468: DecompressPointer r7
    //     0xb05468: add             x7, x7, HEAP, lsl #32
    // 0xb0546c: mov             x1, x7
    // 0xb05470: ldur            x0, [fp, #-8]
    // 0xb05474: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb05474: add             x25, x1, x4, lsl #2
    //     0xb05478: add             x25, x25, #0xf
    //     0xb0547c: str             w0, [x25]
    //     0xb05480: tbz             w0, #0, #0xb0549c
    //     0xb05484: ldurb           w16, [x1, #-1]
    //     0xb05488: ldurb           w17, [x0, #-1]
    //     0xb0548c: and             x16, x17, x16, lsr #2
    //     0xb05490: tst             x16, HEAP, lsr #32
    //     0xb05494: b.eq            #0xb0549c
    //     0xb05498: bl              #0xd67e5c
    // 0xb0549c: r17 = 359
    //     0xb0549c: mov             x17, #0x167
    // 0xb054a0: ldr             w0, [x3, x17]
    // 0xb054a4: DecompressPointer r0
    //     0xb054a4: add             x0, x0, HEAP, lsl #32
    // 0xb054a8: stur            x0, [fp, #-8]
    // 0xb054ac: cmp             w0, NULL
    // 0xb054b0: b.eq            #0xb05758
    // 0xb054b4: LoadField: r1 = r7->field_b
    //     0xb054b4: ldur            w1, [x7, #0xb]
    // 0xb054b8: DecompressPointer r1
    //     0xb054b8: add             x1, x1, HEAP, lsl #32
    // 0xb054bc: cmp             w6, w1
    // 0xb054c0: b.ne            #0xb054d0
    // 0xb054c4: SaveReg r2
    //     0xb054c4: str             x2, [SP, #-8]!
    // 0xb054c8: r0 = _growToNextCapacity()
    //     0xb054c8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb054cc: add             SP, SP, #8
    // 0xb054d0: ldr             x3, [fp, #0x10]
    // 0xb054d4: ldur            x4, [fp, #-0x20]
    // 0xb054d8: ldur            x2, [fp, #-0x18]
    // 0xb054dc: add             x5, x4, #1
    // 0xb054e0: stur            x5, [fp, #-0x28]
    // 0xb054e4: lsl             x6, x5, #1
    // 0xb054e8: StoreField: r2->field_b = r6
    //     0xb054e8: stur            w6, [x2, #0xb]
    // 0xb054ec: mov             x0, x5
    // 0xb054f0: mov             x1, x4
    // 0xb054f4: cmp             x1, x0
    // 0xb054f8: b.hs            #0xb0575c
    // 0xb054fc: LoadField: r7 = r2->field_f
    //     0xb054fc: ldur            w7, [x2, #0xf]
    // 0xb05500: DecompressPointer r7
    //     0xb05500: add             x7, x7, HEAP, lsl #32
    // 0xb05504: mov             x1, x7
    // 0xb05508: ldur            x0, [fp, #-8]
    // 0xb0550c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb0550c: add             x25, x1, x4, lsl #2
    //     0xb05510: add             x25, x25, #0xf
    //     0xb05514: str             w0, [x25]
    //     0xb05518: tbz             w0, #0, #0xb05534
    //     0xb0551c: ldurb           w16, [x1, #-1]
    //     0xb05520: ldurb           w17, [x0, #-1]
    //     0xb05524: and             x16, x17, x16, lsr #2
    //     0xb05528: tst             x16, HEAP, lsr #32
    //     0xb0552c: b.eq            #0xb05534
    //     0xb05530: bl              #0xd67e5c
    // 0xb05534: LoadField: r0 = r3->field_33
    //     0xb05534: ldur            w0, [x3, #0x33]
    // 0xb05538: DecompressPointer r0
    //     0xb05538: add             x0, x0, HEAP, lsl #32
    // 0xb0553c: stur            x0, [fp, #-8]
    // 0xb05540: cmp             w0, NULL
    // 0xb05544: b.eq            #0xb05760
    // 0xb05548: LoadField: r1 = r7->field_b
    //     0xb05548: ldur            w1, [x7, #0xb]
    // 0xb0554c: DecompressPointer r1
    //     0xb0554c: add             x1, x1, HEAP, lsl #32
    // 0xb05550: cmp             w6, w1
    // 0xb05554: b.ne            #0xb05564
    // 0xb05558: SaveReg r2
    //     0xb05558: str             x2, [SP, #-8]!
    // 0xb0555c: r0 = _growToNextCapacity()
    //     0xb0555c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb05560: add             SP, SP, #8
    // 0xb05564: ldur            x3, [fp, #-0x28]
    // 0xb05568: ldur            x2, [fp, #-0x18]
    // 0xb0556c: add             x0, x3, #1
    // 0xb05570: lsl             x1, x0, #1
    // 0xb05574: StoreField: r2->field_b = r1
    //     0xb05574: stur            w1, [x2, #0xb]
    // 0xb05578: mov             x1, x3
    // 0xb0557c: cmp             x1, x0
    // 0xb05580: b.hs            #0xb05764
    // 0xb05584: LoadField: r1 = r2->field_f
    //     0xb05584: ldur            w1, [x2, #0xf]
    // 0xb05588: DecompressPointer r1
    //     0xb05588: add             x1, x1, HEAP, lsl #32
    // 0xb0558c: ldur            x0, [fp, #-8]
    // 0xb05590: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb05590: add             x25, x1, x3, lsl #2
    //     0xb05594: add             x25, x25, #0xf
    //     0xb05598: str             w0, [x25]
    //     0xb0559c: tbz             w0, #0, #0xb055b8
    //     0xb055a0: ldurb           w16, [x1, #-1]
    //     0xb055a4: ldurb           w17, [x0, #-1]
    //     0xb055a8: and             x16, x17, x16, lsr #2
    //     0xb055ac: tst             x16, HEAP, lsr #32
    //     0xb055b0: b.eq            #0xb055b8
    //     0xb055b4: bl              #0xd67e5c
    // 0xb055b8: SaveReg r2
    //     0xb055b8: str             x2, [SP, #-8]!
    // 0xb055bc: r0 = hashAll()
    //     0xb055bc: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb055c0: add             SP, SP, #8
    // 0xb055c4: mov             x2, x0
    // 0xb055c8: r0 = BoxInt64Instr(r2)
    //     0xb055c8: sbfiz           x0, x2, #1, #0x1f
    //     0xb055cc: cmp             x2, x0, asr #1
    //     0xb055d0: b.eq            #0xb055dc
    //     0xb055d4: bl              #0xd69bb8
    //     0xb055d8: stur            x2, [x0, #7]
    // 0xb055dc: LeaveFrame
    //     0xb055dc: mov             SP, fp
    //     0xb055e0: ldp             fp, lr, [SP], #0x10
    // 0xb055e4: ret
    //     0xb055e4: ret             
    // 0xb055e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb055e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb055ec: b               #0xb025a8
    // 0xb055f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb055f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb055f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb055f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb055f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb055f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb055fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb055fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05600: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05600: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05604: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05604: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05608: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05608: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0560c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0560c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05610: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05610: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05614: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05614: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05618: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05618: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0561c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0561c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05620: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05620: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05624: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05624: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05628: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05628: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0562c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0562c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05630: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05630: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05634: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05634: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05638: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05638: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0563c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0563c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05640: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05640: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05644: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05644: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05648: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05648: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0564c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0564c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05650: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05650: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05654: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05654: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05658: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05658: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0565c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0565c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05660: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05660: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05664: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05664: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05668: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05668: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0566c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0566c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05670: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05670: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05674: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05674: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05678: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05678: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0567c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0567c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05680: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05680: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05684: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05684: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05688: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05688: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0568c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0568c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05690: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05690: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05694: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05694: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05698: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05698: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0569c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0569c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056a0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056a4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056a8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056ac: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056b0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056bc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056c0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056c4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056c8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056cc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056d0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056d4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056d8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056dc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056e0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056e4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056e8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056f4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056f8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056f8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb056fc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb056fc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05700: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05700: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05704: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05704: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05708: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05708: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0570c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0570c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05710: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05710: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05714: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05714: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05718: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb05718: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb0571c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0571c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05720: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05720: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05724: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05724: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05728: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05728: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0572c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb0572c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb05730: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05730: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05734: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05734: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05738: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05738: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb0573c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0573c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05740: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb05740: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb05744: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05744: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05748: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb05748: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb0574c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0574c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05750: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb05750: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb05754: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05754: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05758: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb05758: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb0575c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb0575c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb05760: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb05760: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb05764: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb05764: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbecd5c, size: 0x1970
    // 0xbecd5c: EnterFrame
    //     0xbecd5c: stp             fp, lr, [SP, #-0x10]!
    //     0xbecd60: mov             fp, SP
    // 0xbecd64: AllocStack(0x2a8)
    //     0xbecd64: sub             SP, SP, #0x2a8
    // 0xbecd68: d0 = 0.500000
    //     0xbecd68: fmov            d0, #0.50000000
    // 0xbecd6c: CheckStackOverflow
    //     0xbecd6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbecd70: cmp             SP, x16
    //     0xbecd74: b.ls            #0xbee5c8
    // 0xbecd78: ldr             d1, [fp, #0x10]
    // 0xbecd7c: fcmp            d1, d0
    // 0xbecd80: b.vs            #0xbecd88
    // 0xbecd84: b.lt            #0xbecd90
    // 0xbecd88: r0 = false
    //     0xbecd88: add             x0, NULL, #0x30  ; false
    // 0xbecd8c: b               #0xbecd94
    // 0xbecd90: r0 = true
    //     0xbecd90: add             x0, NULL, #0x20  ; true
    // 0xbecd94: stur            x0, [fp, #-0x10]
    // 0xbecd98: tbnz            w0, #4, #0xbecdb4
    // 0xbecd9c: ldr             x1, [fp, #0x20]
    // 0xbecda0: LoadField: r2 = r1->field_7
    //     0xbecda0: ldur            w2, [x1, #7]
    // 0xbecda4: DecompressPointer r2
    //     0xbecda4: add             x2, x2, HEAP, lsl #32
    // 0xbecda8: mov             x3, x2
    // 0xbecdac: ldr             x2, [fp, #0x18]
    // 0xbecdb0: b               #0xbecdc4
    // 0xbecdb4: ldr             x1, [fp, #0x20]
    // 0xbecdb8: ldr             x2, [fp, #0x18]
    // 0xbecdbc: LoadField: r3 = r2->field_7
    //     0xbecdbc: ldur            w3, [x2, #7]
    // 0xbecdc0: DecompressPointer r3
    //     0xbecdc0: add             x3, x3, HEAP, lsl #32
    // 0xbecdc4: stur            x3, [fp, #-8]
    // 0xbecdc8: stp             x2, x1, [SP, #-0x10]!
    // 0xbecdcc: r0 = _lerpThemeExtensions()
    //     0xbecdcc: bl              #0xbf87e0  ; [package:flutter/src/material/theme_data.dart] ThemeData::_lerpThemeExtensions
    // 0xbecdd0: add             SP, SP, #0x10
    // 0xbecdd4: mov             x1, x0
    // 0xbecdd8: ldur            x0, [fp, #-0x10]
    // 0xbecddc: stur            x1, [fp, #-0x28]
    // 0xbecde0: tbnz            w0, #4, #0xbecdfc
    // 0xbecde4: ldr             x2, [fp, #0x20]
    // 0xbecde8: LoadField: r3 = r2->field_17
    //     0xbecde8: ldur            w3, [x2, #0x17]
    // 0xbecdec: DecompressPointer r3
    //     0xbecdec: add             x3, x3, HEAP, lsl #32
    // 0xbecdf0: mov             x4, x3
    // 0xbecdf4: ldr             x3, [fp, #0x18]
    // 0xbecdf8: b               #0xbece0c
    // 0xbecdfc: ldr             x2, [fp, #0x20]
    // 0xbece00: ldr             x3, [fp, #0x18]
    // 0xbece04: LoadField: r4 = r3->field_17
    //     0xbece04: ldur            w4, [x3, #0x17]
    // 0xbece08: DecompressPointer r4
    //     0xbece08: add             x4, x4, HEAP, lsl #32
    // 0xbece0c: stur            x4, [fp, #-0x20]
    // 0xbece10: tbnz            w0, #4, #0xbece20
    // 0xbece14: LoadField: r5 = r2->field_1f
    //     0xbece14: ldur            w5, [x2, #0x1f]
    // 0xbece18: DecompressPointer r5
    //     0xbece18: add             x5, x5, HEAP, lsl #32
    // 0xbece1c: b               #0xbece28
    // 0xbece20: LoadField: r5 = r3->field_1f
    //     0xbece20: ldur            w5, [x3, #0x1f]
    // 0xbece24: DecompressPointer r5
    //     0xbece24: add             x5, x5, HEAP, lsl #32
    // 0xbece28: ldr             d0, [fp, #0x10]
    // 0xbece2c: stur            x5, [fp, #-0x18]
    // 0xbece30: LoadField: r6 = r2->field_23
    //     0xbece30: ldur            w6, [x2, #0x23]
    // 0xbece34: DecompressPointer r6
    //     0xbece34: add             x6, x6, HEAP, lsl #32
    // 0xbece38: LoadField: r7 = r3->field_23
    //     0xbece38: ldur            w7, [x3, #0x23]
    // 0xbece3c: DecompressPointer r7
    //     0xbece3c: add             x7, x7, HEAP, lsl #32
    // 0xbece40: stp             x7, x6, [SP, #-0x10]!
    // 0xbece44: SaveReg d0
    //     0xbece44: str             d0, [SP, #-8]!
    // 0xbece48: r0 = lerp()
    //     0xbece48: bl              #0xbf845c  ; [package:flutter/src/material/scrollbar_theme.dart] ScrollbarThemeData::lerp
    // 0xbece4c: add             SP, SP, #0x18
    // 0xbece50: mov             x1, x0
    // 0xbece54: ldur            x0, [fp, #-0x10]
    // 0xbece58: stur            x1, [fp, #-0x40]
    // 0xbece5c: tbnz            w0, #4, #0xbece78
    // 0xbece60: ldr             x2, [fp, #0x20]
    // 0xbece64: LoadField: r3 = r2->field_27
    //     0xbece64: ldur            w3, [x2, #0x27]
    // 0xbece68: DecompressPointer r3
    //     0xbece68: add             x3, x3, HEAP, lsl #32
    // 0xbece6c: mov             x4, x3
    // 0xbece70: ldr             x3, [fp, #0x18]
    // 0xbece74: b               #0xbece88
    // 0xbece78: ldr             x2, [fp, #0x20]
    // 0xbece7c: ldr             x3, [fp, #0x18]
    // 0xbece80: LoadField: r4 = r3->field_27
    //     0xbece80: ldur            w4, [x3, #0x27]
    // 0xbece84: DecompressPointer r4
    //     0xbece84: add             x4, x4, HEAP, lsl #32
    // 0xbece88: stur            x4, [fp, #-0x38]
    // 0xbece8c: tbnz            w0, #4, #0xbece9c
    // 0xbece90: LoadField: r5 = r2->field_2b
    //     0xbece90: ldur            w5, [x2, #0x2b]
    // 0xbece94: DecompressPointer r5
    //     0xbece94: add             x5, x5, HEAP, lsl #32
    // 0xbece98: b               #0xbecea4
    // 0xbece9c: LoadField: r5 = r3->field_2b
    //     0xbece9c: ldur            w5, [x3, #0x2b]
    // 0xbecea0: DecompressPointer r5
    //     0xbecea0: add             x5, x5, HEAP, lsl #32
    // 0xbecea4: ldr             d0, [fp, #0x10]
    // 0xbecea8: stur            x5, [fp, #-0x30]
    // 0xbeceac: LoadField: r6 = r2->field_2f
    //     0xbeceac: ldur            w6, [x2, #0x2f]
    // 0xbeceb0: DecompressPointer r6
    //     0xbeceb0: add             x6, x6, HEAP, lsl #32
    // 0xbeceb4: LoadField: r7 = r3->field_2f
    //     0xbeceb4: ldur            w7, [x3, #0x2f]
    // 0xbeceb8: DecompressPointer r7
    //     0xbeceb8: add             x7, x7, HEAP, lsl #32
    // 0xbecebc: stp             x7, x6, [SP, #-0x10]!
    // 0xbecec0: SaveReg d0
    //     0xbecec0: str             d0, [SP, #-8]!
    // 0xbecec4: r0 = lerp()
    //     0xbecec4: bl              #0xbf8228  ; [package:flutter/src/material/theme_data.dart] VisualDensity::lerp
    // 0xbecec8: add             SP, SP, #0x18
    // 0xbececc: mov             x1, x0
    // 0xbeced0: ldr             x0, [fp, #0x20]
    // 0xbeced4: stur            x1, [fp, #-0x50]
    // 0xbeced8: LoadField: r2 = r0->field_37
    //     0xbeced8: ldur            w2, [x0, #0x37]
    // 0xbecedc: DecompressPointer r2
    //     0xbecedc: add             x2, x2, HEAP, lsl #32
    // 0xbecee0: ldr             x3, [fp, #0x18]
    // 0xbecee4: LoadField: r4 = r3->field_37
    //     0xbecee4: ldur            w4, [x3, #0x37]
    // 0xbecee8: DecompressPointer r4
    //     0xbecee8: add             x4, x4, HEAP, lsl #32
    // 0xbeceec: ldr             d0, [fp, #0x10]
    // 0xbecef0: r5 = inline_Allocate_Double()
    //     0xbecef0: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbecef4: add             x5, x5, #0x10
    //     0xbecef8: cmp             x6, x5
    //     0xbecefc: b.ls            #0xbee5d0
    //     0xbecf00: str             x5, [THR, #0x60]  ; THR::top
    //     0xbecf04: sub             x5, x5, #0xf
    //     0xbecf08: mov             x6, #0xd108
    //     0xbecf0c: movk            x6, #3, lsl #16
    //     0xbecf10: stur            x6, [x5, #-1]
    // 0xbecf14: StoreField: r5->field_7 = d0
    //     0xbecf14: stur            d0, [x5, #7]
    // 0xbecf18: stur            x5, [fp, #-0x48]
    // 0xbecf1c: stp             x4, x2, [SP, #-0x10]!
    // 0xbecf20: SaveReg r5
    //     0xbecf20: str             x5, [SP, #-8]!
    // 0xbecf24: r0 = lerp()
    //     0xbecf24: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbecf28: add             SP, SP, #0x18
    // 0xbecf2c: stur            x0, [fp, #-0x58]
    // 0xbecf30: cmp             w0, NULL
    // 0xbecf34: b.eq            #0xbee5fc
    // 0xbecf38: ldr             x1, [fp, #0x20]
    // 0xbecf3c: LoadField: r2 = r1->field_3b
    //     0xbecf3c: ldur            w2, [x1, #0x3b]
    // 0xbecf40: DecompressPointer r2
    //     0xbecf40: add             x2, x2, HEAP, lsl #32
    // 0xbecf44: ldr             x3, [fp, #0x18]
    // 0xbecf48: LoadField: r4 = r3->field_3b
    //     0xbecf48: ldur            w4, [x3, #0x3b]
    // 0xbecf4c: DecompressPointer r4
    //     0xbecf4c: add             x4, x4, HEAP, lsl #32
    // 0xbecf50: stp             x4, x2, [SP, #-0x10]!
    // 0xbecf54: ldur            x16, [fp, #-0x48]
    // 0xbecf58: SaveReg r16
    //     0xbecf58: str             x16, [SP, #-8]!
    // 0xbecf5c: r0 = lerp()
    //     0xbecf5c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbecf60: add             SP, SP, #0x18
    // 0xbecf64: stur            x0, [fp, #-0x60]
    // 0xbecf68: cmp             w0, NULL
    // 0xbecf6c: b.eq            #0xbee600
    // 0xbecf70: ldr             x1, [fp, #0x20]
    // 0xbecf74: LoadField: r2 = r1->field_3f
    //     0xbecf74: ldur            w2, [x1, #0x3f]
    // 0xbecf78: DecompressPointer r2
    //     0xbecf78: add             x2, x2, HEAP, lsl #32
    // 0xbecf7c: ldr             x3, [fp, #0x18]
    // 0xbecf80: LoadField: r4 = r3->field_3f
    //     0xbecf80: ldur            w4, [x3, #0x3f]
    // 0xbecf84: DecompressPointer r4
    //     0xbecf84: add             x4, x4, HEAP, lsl #32
    // 0xbecf88: stp             x4, x2, [SP, #-0x10]!
    // 0xbecf8c: ldr             d0, [fp, #0x10]
    // 0xbecf90: SaveReg d0
    //     0xbecf90: str             d0, [SP, #-8]!
    // 0xbecf94: r0 = lerp()
    //     0xbecf94: bl              #0xbf761c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::lerp
    // 0xbecf98: add             SP, SP, #0x18
    // 0xbecf9c: mov             x1, x0
    // 0xbecfa0: ldr             x0, [fp, #0x20]
    // 0xbecfa4: stur            x1, [fp, #-0x68]
    // 0xbecfa8: LoadField: r2 = r0->field_43
    //     0xbecfa8: ldur            w2, [x0, #0x43]
    // 0xbecfac: DecompressPointer r2
    //     0xbecfac: add             x2, x2, HEAP, lsl #32
    // 0xbecfb0: ldr             x3, [fp, #0x18]
    // 0xbecfb4: LoadField: r4 = r3->field_43
    //     0xbecfb4: ldur            w4, [x3, #0x43]
    // 0xbecfb8: DecompressPointer r4
    //     0xbecfb8: add             x4, x4, HEAP, lsl #32
    // 0xbecfbc: stp             x4, x2, [SP, #-0x10]!
    // 0xbecfc0: ldur            x16, [fp, #-0x48]
    // 0xbecfc4: SaveReg r16
    //     0xbecfc4: str             x16, [SP, #-8]!
    // 0xbecfc8: r0 = lerp()
    //     0xbecfc8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbecfcc: add             SP, SP, #0x18
    // 0xbecfd0: stur            x0, [fp, #-0x70]
    // 0xbecfd4: cmp             w0, NULL
    // 0xbecfd8: b.eq            #0xbee604
    // 0xbecfdc: ldr             x1, [fp, #0x20]
    // 0xbecfe0: LoadField: r2 = r1->field_47
    //     0xbecfe0: ldur            w2, [x1, #0x47]
    // 0xbecfe4: DecompressPointer r2
    //     0xbecfe4: add             x2, x2, HEAP, lsl #32
    // 0xbecfe8: ldr             x3, [fp, #0x18]
    // 0xbecfec: LoadField: r4 = r3->field_47
    //     0xbecfec: ldur            w4, [x3, #0x47]
    // 0xbecff0: DecompressPointer r4
    //     0xbecff0: add             x4, x4, HEAP, lsl #32
    // 0xbecff4: stp             x4, x2, [SP, #-0x10]!
    // 0xbecff8: ldur            x16, [fp, #-0x48]
    // 0xbecffc: SaveReg r16
    //     0xbecffc: str             x16, [SP, #-8]!
    // 0xbed000: r0 = lerp()
    //     0xbed000: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed004: add             SP, SP, #0x18
    // 0xbed008: stur            x0, [fp, #-0x78]
    // 0xbed00c: cmp             w0, NULL
    // 0xbed010: b.eq            #0xbee608
    // 0xbed014: ldr             x1, [fp, #0x20]
    // 0xbed018: LoadField: r2 = r1->field_4b
    //     0xbed018: ldur            w2, [x1, #0x4b]
    // 0xbed01c: DecompressPointer r2
    //     0xbed01c: add             x2, x2, HEAP, lsl #32
    // 0xbed020: ldr             x3, [fp, #0x18]
    // 0xbed024: LoadField: r4 = r3->field_4b
    //     0xbed024: ldur            w4, [x3, #0x4b]
    // 0xbed028: DecompressPointer r4
    //     0xbed028: add             x4, x4, HEAP, lsl #32
    // 0xbed02c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed030: ldur            x16, [fp, #-0x48]
    // 0xbed034: SaveReg r16
    //     0xbed034: str             x16, [SP, #-8]!
    // 0xbed038: r0 = lerp()
    //     0xbed038: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed03c: add             SP, SP, #0x18
    // 0xbed040: stur            x0, [fp, #-0x80]
    // 0xbed044: cmp             w0, NULL
    // 0xbed048: b.eq            #0xbee60c
    // 0xbed04c: ldr             x1, [fp, #0x20]
    // 0xbed050: LoadField: r2 = r1->field_4f
    //     0xbed050: ldur            w2, [x1, #0x4f]
    // 0xbed054: DecompressPointer r2
    //     0xbed054: add             x2, x2, HEAP, lsl #32
    // 0xbed058: ldr             x3, [fp, #0x18]
    // 0xbed05c: LoadField: r4 = r3->field_4f
    //     0xbed05c: ldur            w4, [x3, #0x4f]
    // 0xbed060: DecompressPointer r4
    //     0xbed060: add             x4, x4, HEAP, lsl #32
    // 0xbed064: stp             x4, x2, [SP, #-0x10]!
    // 0xbed068: ldur            x16, [fp, #-0x48]
    // 0xbed06c: SaveReg r16
    //     0xbed06c: str             x16, [SP, #-8]!
    // 0xbed070: r0 = lerp()
    //     0xbed070: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed074: add             SP, SP, #0x18
    // 0xbed078: stur            x0, [fp, #-0x88]
    // 0xbed07c: cmp             w0, NULL
    // 0xbed080: b.eq            #0xbee610
    // 0xbed084: ldr             x1, [fp, #0x20]
    // 0xbed088: LoadField: r2 = r1->field_53
    //     0xbed088: ldur            w2, [x1, #0x53]
    // 0xbed08c: DecompressPointer r2
    //     0xbed08c: add             x2, x2, HEAP, lsl #32
    // 0xbed090: ldr             x3, [fp, #0x18]
    // 0xbed094: LoadField: r4 = r3->field_53
    //     0xbed094: ldur            w4, [x3, #0x53]
    // 0xbed098: DecompressPointer r4
    //     0xbed098: add             x4, x4, HEAP, lsl #32
    // 0xbed09c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed0a0: ldur            x16, [fp, #-0x48]
    // 0xbed0a4: SaveReg r16
    //     0xbed0a4: str             x16, [SP, #-8]!
    // 0xbed0a8: r0 = lerp()
    //     0xbed0a8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed0ac: add             SP, SP, #0x18
    // 0xbed0b0: stur            x0, [fp, #-0x90]
    // 0xbed0b4: cmp             w0, NULL
    // 0xbed0b8: b.eq            #0xbee614
    // 0xbed0bc: ldr             x1, [fp, #0x20]
    // 0xbed0c0: LoadField: r2 = r1->field_57
    //     0xbed0c0: ldur            w2, [x1, #0x57]
    // 0xbed0c4: DecompressPointer r2
    //     0xbed0c4: add             x2, x2, HEAP, lsl #32
    // 0xbed0c8: ldr             x3, [fp, #0x18]
    // 0xbed0cc: LoadField: r4 = r3->field_57
    //     0xbed0cc: ldur            w4, [x3, #0x57]
    // 0xbed0d0: DecompressPointer r4
    //     0xbed0d0: add             x4, x4, HEAP, lsl #32
    // 0xbed0d4: stp             x4, x2, [SP, #-0x10]!
    // 0xbed0d8: ldur            x16, [fp, #-0x48]
    // 0xbed0dc: SaveReg r16
    //     0xbed0dc: str             x16, [SP, #-8]!
    // 0xbed0e0: r0 = lerp()
    //     0xbed0e0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed0e4: add             SP, SP, #0x18
    // 0xbed0e8: stur            x0, [fp, #-0x98]
    // 0xbed0ec: cmp             w0, NULL
    // 0xbed0f0: b.eq            #0xbee618
    // 0xbed0f4: ldr             x1, [fp, #0x20]
    // 0xbed0f8: LoadField: r2 = r1->field_5b
    //     0xbed0f8: ldur            w2, [x1, #0x5b]
    // 0xbed0fc: DecompressPointer r2
    //     0xbed0fc: add             x2, x2, HEAP, lsl #32
    // 0xbed100: ldr             x3, [fp, #0x18]
    // 0xbed104: LoadField: r4 = r3->field_5b
    //     0xbed104: ldur            w4, [x3, #0x5b]
    // 0xbed108: DecompressPointer r4
    //     0xbed108: add             x4, x4, HEAP, lsl #32
    // 0xbed10c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed110: ldur            x16, [fp, #-0x48]
    // 0xbed114: SaveReg r16
    //     0xbed114: str             x16, [SP, #-8]!
    // 0xbed118: r0 = lerp()
    //     0xbed118: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed11c: add             SP, SP, #0x18
    // 0xbed120: stur            x0, [fp, #-0xa0]
    // 0xbed124: cmp             w0, NULL
    // 0xbed128: b.eq            #0xbee61c
    // 0xbed12c: ldr             x1, [fp, #0x20]
    // 0xbed130: LoadField: r2 = r1->field_5f
    //     0xbed130: ldur            w2, [x1, #0x5f]
    // 0xbed134: DecompressPointer r2
    //     0xbed134: add             x2, x2, HEAP, lsl #32
    // 0xbed138: ldr             x3, [fp, #0x18]
    // 0xbed13c: LoadField: r4 = r3->field_5f
    //     0xbed13c: ldur            w4, [x3, #0x5f]
    // 0xbed140: DecompressPointer r4
    //     0xbed140: add             x4, x4, HEAP, lsl #32
    // 0xbed144: stp             x4, x2, [SP, #-0x10]!
    // 0xbed148: ldur            x16, [fp, #-0x48]
    // 0xbed14c: SaveReg r16
    //     0xbed14c: str             x16, [SP, #-8]!
    // 0xbed150: r0 = lerp()
    //     0xbed150: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed154: add             SP, SP, #0x18
    // 0xbed158: stur            x0, [fp, #-0xa8]
    // 0xbed15c: cmp             w0, NULL
    // 0xbed160: b.eq            #0xbee620
    // 0xbed164: ldr             x1, [fp, #0x20]
    // 0xbed168: LoadField: r2 = r1->field_63
    //     0xbed168: ldur            w2, [x1, #0x63]
    // 0xbed16c: DecompressPointer r2
    //     0xbed16c: add             x2, x2, HEAP, lsl #32
    // 0xbed170: ldr             x3, [fp, #0x18]
    // 0xbed174: LoadField: r4 = r3->field_63
    //     0xbed174: ldur            w4, [x3, #0x63]
    // 0xbed178: DecompressPointer r4
    //     0xbed178: add             x4, x4, HEAP, lsl #32
    // 0xbed17c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed180: ldur            x16, [fp, #-0x48]
    // 0xbed184: SaveReg r16
    //     0xbed184: str             x16, [SP, #-8]!
    // 0xbed188: r0 = lerp()
    //     0xbed188: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed18c: add             SP, SP, #0x18
    // 0xbed190: stur            x0, [fp, #-0xb0]
    // 0xbed194: cmp             w0, NULL
    // 0xbed198: b.eq            #0xbee624
    // 0xbed19c: ldr             x1, [fp, #0x20]
    // 0xbed1a0: LoadField: r2 = r1->field_67
    //     0xbed1a0: ldur            w2, [x1, #0x67]
    // 0xbed1a4: DecompressPointer r2
    //     0xbed1a4: add             x2, x2, HEAP, lsl #32
    // 0xbed1a8: ldr             x3, [fp, #0x18]
    // 0xbed1ac: LoadField: r4 = r3->field_67
    //     0xbed1ac: ldur            w4, [x3, #0x67]
    // 0xbed1b0: DecompressPointer r4
    //     0xbed1b0: add             x4, x4, HEAP, lsl #32
    // 0xbed1b4: stp             x4, x2, [SP, #-0x10]!
    // 0xbed1b8: ldur            x16, [fp, #-0x48]
    // 0xbed1bc: SaveReg r16
    //     0xbed1bc: str             x16, [SP, #-8]!
    // 0xbed1c0: r0 = lerp()
    //     0xbed1c0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed1c4: add             SP, SP, #0x18
    // 0xbed1c8: stur            x0, [fp, #-0xb8]
    // 0xbed1cc: cmp             w0, NULL
    // 0xbed1d0: b.eq            #0xbee628
    // 0xbed1d4: ldr             x1, [fp, #0x20]
    // 0xbed1d8: LoadField: r2 = r1->field_6b
    //     0xbed1d8: ldur            w2, [x1, #0x6b]
    // 0xbed1dc: DecompressPointer r2
    //     0xbed1dc: add             x2, x2, HEAP, lsl #32
    // 0xbed1e0: ldr             x3, [fp, #0x18]
    // 0xbed1e4: LoadField: r4 = r3->field_6b
    //     0xbed1e4: ldur            w4, [x3, #0x6b]
    // 0xbed1e8: DecompressPointer r4
    //     0xbed1e8: add             x4, x4, HEAP, lsl #32
    // 0xbed1ec: stp             x4, x2, [SP, #-0x10]!
    // 0xbed1f0: ldur            x16, [fp, #-0x48]
    // 0xbed1f4: SaveReg r16
    //     0xbed1f4: str             x16, [SP, #-8]!
    // 0xbed1f8: r0 = lerp()
    //     0xbed1f8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed1fc: add             SP, SP, #0x18
    // 0xbed200: stur            x0, [fp, #-0xc0]
    // 0xbed204: cmp             w0, NULL
    // 0xbed208: b.eq            #0xbee62c
    // 0xbed20c: ldr             x1, [fp, #0x20]
    // 0xbed210: LoadField: r2 = r1->field_6f
    //     0xbed210: ldur            w2, [x1, #0x6f]
    // 0xbed214: DecompressPointer r2
    //     0xbed214: add             x2, x2, HEAP, lsl #32
    // 0xbed218: ldr             x3, [fp, #0x18]
    // 0xbed21c: LoadField: r4 = r3->field_6f
    //     0xbed21c: ldur            w4, [x3, #0x6f]
    // 0xbed220: DecompressPointer r4
    //     0xbed220: add             x4, x4, HEAP, lsl #32
    // 0xbed224: stp             x4, x2, [SP, #-0x10]!
    // 0xbed228: ldur            x16, [fp, #-0x48]
    // 0xbed22c: SaveReg r16
    //     0xbed22c: str             x16, [SP, #-8]!
    // 0xbed230: r0 = lerp()
    //     0xbed230: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed234: add             SP, SP, #0x18
    // 0xbed238: stur            x0, [fp, #-0xc8]
    // 0xbed23c: cmp             w0, NULL
    // 0xbed240: b.eq            #0xbee630
    // 0xbed244: ldr             x1, [fp, #0x20]
    // 0xbed248: LoadField: r2 = r1->field_73
    //     0xbed248: ldur            w2, [x1, #0x73]
    // 0xbed24c: DecompressPointer r2
    //     0xbed24c: add             x2, x2, HEAP, lsl #32
    // 0xbed250: ldr             x3, [fp, #0x18]
    // 0xbed254: LoadField: r4 = r3->field_73
    //     0xbed254: ldur            w4, [x3, #0x73]
    // 0xbed258: DecompressPointer r4
    //     0xbed258: add             x4, x4, HEAP, lsl #32
    // 0xbed25c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed260: ldur            x16, [fp, #-0x48]
    // 0xbed264: SaveReg r16
    //     0xbed264: str             x16, [SP, #-8]!
    // 0xbed268: r0 = lerp()
    //     0xbed268: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed26c: add             SP, SP, #0x18
    // 0xbed270: stur            x0, [fp, #-0xd0]
    // 0xbed274: cmp             w0, NULL
    // 0xbed278: b.eq            #0xbee634
    // 0xbed27c: ldr             x1, [fp, #0x20]
    // 0xbed280: LoadField: r2 = r1->field_7b
    //     0xbed280: ldur            w2, [x1, #0x7b]
    // 0xbed284: DecompressPointer r2
    //     0xbed284: add             x2, x2, HEAP, lsl #32
    // 0xbed288: ldr             x3, [fp, #0x18]
    // 0xbed28c: LoadField: r4 = r3->field_7b
    //     0xbed28c: ldur            w4, [x3, #0x7b]
    // 0xbed290: DecompressPointer r4
    //     0xbed290: add             x4, x4, HEAP, lsl #32
    // 0xbed294: stp             x4, x2, [SP, #-0x10]!
    // 0xbed298: ldur            x16, [fp, #-0x48]
    // 0xbed29c: SaveReg r16
    //     0xbed29c: str             x16, [SP, #-8]!
    // 0xbed2a0: r0 = lerp()
    //     0xbed2a0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed2a4: add             SP, SP, #0x18
    // 0xbed2a8: stur            x0, [fp, #-0xd8]
    // 0xbed2ac: cmp             w0, NULL
    // 0xbed2b0: b.eq            #0xbee638
    // 0xbed2b4: ldr             x1, [fp, #0x20]
    // 0xbed2b8: LoadField: r2 = r1->field_7f
    //     0xbed2b8: ldur            w2, [x1, #0x7f]
    // 0xbed2bc: DecompressPointer r2
    //     0xbed2bc: add             x2, x2, HEAP, lsl #32
    // 0xbed2c0: ldr             x3, [fp, #0x18]
    // 0xbed2c4: LoadField: r4 = r3->field_7f
    //     0xbed2c4: ldur            w4, [x3, #0x7f]
    // 0xbed2c8: DecompressPointer r4
    //     0xbed2c8: add             x4, x4, HEAP, lsl #32
    // 0xbed2cc: stp             x4, x2, [SP, #-0x10]!
    // 0xbed2d0: ldur            x16, [fp, #-0x48]
    // 0xbed2d4: SaveReg r16
    //     0xbed2d4: str             x16, [SP, #-8]!
    // 0xbed2d8: r0 = lerp()
    //     0xbed2d8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed2dc: add             SP, SP, #0x18
    // 0xbed2e0: stur            x0, [fp, #-0xe0]
    // 0xbed2e4: cmp             w0, NULL
    // 0xbed2e8: b.eq            #0xbee63c
    // 0xbed2ec: ldr             x1, [fp, #0x20]
    // 0xbed2f0: LoadField: r2 = r1->field_83
    //     0xbed2f0: ldur            w2, [x1, #0x83]
    // 0xbed2f4: DecompressPointer r2
    //     0xbed2f4: add             x2, x2, HEAP, lsl #32
    // 0xbed2f8: ldr             x3, [fp, #0x18]
    // 0xbed2fc: LoadField: r4 = r3->field_83
    //     0xbed2fc: ldur            w4, [x3, #0x83]
    // 0xbed300: DecompressPointer r4
    //     0xbed300: add             x4, x4, HEAP, lsl #32
    // 0xbed304: stp             x4, x2, [SP, #-0x10]!
    // 0xbed308: ldur            x16, [fp, #-0x48]
    // 0xbed30c: SaveReg r16
    //     0xbed30c: str             x16, [SP, #-8]!
    // 0xbed310: r0 = lerp()
    //     0xbed310: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbed314: add             SP, SP, #0x18
    // 0xbed318: stur            x0, [fp, #-0xe8]
    // 0xbed31c: cmp             w0, NULL
    // 0xbed320: b.eq            #0xbee640
    // 0xbed324: ldr             x1, [fp, #0x20]
    // 0xbed328: LoadField: r2 = r1->field_87
    //     0xbed328: ldur            w2, [x1, #0x87]
    // 0xbed32c: DecompressPointer r2
    //     0xbed32c: add             x2, x2, HEAP, lsl #32
    // 0xbed330: ldr             x3, [fp, #0x18]
    // 0xbed334: LoadField: r4 = r3->field_87
    //     0xbed334: ldur            w4, [x3, #0x87]
    // 0xbed338: DecompressPointer r4
    //     0xbed338: add             x4, x4, HEAP, lsl #32
    // 0xbed33c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed340: ldur            x16, [fp, #-0x48]
    // 0xbed344: SaveReg r16
    //     0xbed344: str             x16, [SP, #-8]!
    // 0xbed348: r0 = lerp()
    //     0xbed348: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbed34c: add             SP, SP, #0x18
    // 0xbed350: mov             x1, x0
    // 0xbed354: ldr             x0, [fp, #0x20]
    // 0xbed358: stur            x1, [fp, #-0xf0]
    // 0xbed35c: LoadField: r2 = r0->field_8b
    //     0xbed35c: ldur            w2, [x0, #0x8b]
    // 0xbed360: DecompressPointer r2
    //     0xbed360: add             x2, x2, HEAP, lsl #32
    // 0xbed364: ldr             x3, [fp, #0x18]
    // 0xbed368: LoadField: r4 = r3->field_8b
    //     0xbed368: ldur            w4, [x3, #0x8b]
    // 0xbed36c: DecompressPointer r4
    //     0xbed36c: add             x4, x4, HEAP, lsl #32
    // 0xbed370: stp             x4, x2, [SP, #-0x10]!
    // 0xbed374: ldur            x16, [fp, #-0x48]
    // 0xbed378: SaveReg r16
    //     0xbed378: str             x16, [SP, #-8]!
    // 0xbed37c: r0 = lerp()
    //     0xbed37c: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbed380: add             SP, SP, #0x18
    // 0xbed384: mov             x1, x0
    // 0xbed388: ldr             x0, [fp, #0x20]
    // 0xbed38c: stur            x1, [fp, #-0xf8]
    // 0xbed390: LoadField: r2 = r0->field_8f
    //     0xbed390: ldur            w2, [x0, #0x8f]
    // 0xbed394: DecompressPointer r2
    //     0xbed394: add             x2, x2, HEAP, lsl #32
    // 0xbed398: ldr             x3, [fp, #0x18]
    // 0xbed39c: LoadField: r4 = r3->field_8f
    //     0xbed39c: ldur            w4, [x3, #0x8f]
    // 0xbed3a0: DecompressPointer r4
    //     0xbed3a0: add             x4, x4, HEAP, lsl #32
    // 0xbed3a4: stp             x4, x2, [SP, #-0x10]!
    // 0xbed3a8: ldr             d0, [fp, #0x10]
    // 0xbed3ac: SaveReg d0
    //     0xbed3ac: str             d0, [SP, #-8]!
    // 0xbed3b0: r0 = lerp()
    //     0xbed3b0: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbed3b4: add             SP, SP, #0x18
    // 0xbed3b8: mov             x1, x0
    // 0xbed3bc: ldr             x0, [fp, #0x20]
    // 0xbed3c0: stur            x1, [fp, #-0x100]
    // 0xbed3c4: LoadField: r2 = r0->field_93
    //     0xbed3c4: ldur            w2, [x0, #0x93]
    // 0xbed3c8: DecompressPointer r2
    //     0xbed3c8: add             x2, x2, HEAP, lsl #32
    // 0xbed3cc: ldr             x3, [fp, #0x18]
    // 0xbed3d0: LoadField: r4 = r3->field_93
    //     0xbed3d0: ldur            w4, [x3, #0x93]
    // 0xbed3d4: DecompressPointer r4
    //     0xbed3d4: add             x4, x4, HEAP, lsl #32
    // 0xbed3d8: stp             x4, x2, [SP, #-0x10]!
    // 0xbed3dc: ldr             d0, [fp, #0x10]
    // 0xbed3e0: SaveReg d0
    //     0xbed3e0: str             d0, [SP, #-8]!
    // 0xbed3e4: r0 = lerp()
    //     0xbed3e4: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbed3e8: add             SP, SP, #0x18
    // 0xbed3ec: mov             x1, x0
    // 0xbed3f0: ldr             x0, [fp, #0x20]
    // 0xbed3f4: r17 = -264
    //     0xbed3f4: mov             x17, #-0x108
    // 0xbed3f8: str             x1, [fp, x17]
    // 0xbed3fc: LoadField: r2 = r0->field_97
    //     0xbed3fc: ldur            w2, [x0, #0x97]
    // 0xbed400: DecompressPointer r2
    //     0xbed400: add             x2, x2, HEAP, lsl #32
    // 0xbed404: ldr             x3, [fp, #0x18]
    // 0xbed408: LoadField: r4 = r3->field_97
    //     0xbed408: ldur            w4, [x3, #0x97]
    // 0xbed40c: DecompressPointer r4
    //     0xbed40c: add             x4, x4, HEAP, lsl #32
    // 0xbed410: stp             x4, x2, [SP, #-0x10]!
    // 0xbed414: ldr             d0, [fp, #0x10]
    // 0xbed418: SaveReg d0
    //     0xbed418: str             d0, [SP, #-8]!
    // 0xbed41c: r0 = lerp()
    //     0xbed41c: bl              #0xbf643c  ; [package:flutter/src/material/typography.dart] Typography::lerp
    // 0xbed420: add             SP, SP, #0x18
    // 0xbed424: mov             x1, x0
    // 0xbed428: ldr             x0, [fp, #0x20]
    // 0xbed42c: r17 = -272
    //     0xbed42c: mov             x17, #-0x110
    // 0xbed430: str             x1, [fp, x17]
    // 0xbed434: LoadField: r2 = r0->field_9b
    //     0xbed434: ldur            w2, [x0, #0x9b]
    // 0xbed438: DecompressPointer r2
    //     0xbed438: add             x2, x2, HEAP, lsl #32
    // 0xbed43c: ldr             x3, [fp, #0x18]
    // 0xbed440: LoadField: r4 = r3->field_9b
    //     0xbed440: ldur            w4, [x3, #0x9b]
    // 0xbed444: DecompressPointer r4
    //     0xbed444: add             x4, x4, HEAP, lsl #32
    // 0xbed448: stp             x4, x2, [SP, #-0x10]!
    // 0xbed44c: ldr             d0, [fp, #0x10]
    // 0xbed450: SaveReg d0
    //     0xbed450: str             d0, [SP, #-8]!
    // 0xbed454: r0 = lerp()
    //     0xbed454: bl              #0xbf60e8  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::lerp
    // 0xbed458: add             SP, SP, #0x18
    // 0xbed45c: mov             x1, x0
    // 0xbed460: ldr             x0, [fp, #0x20]
    // 0xbed464: r17 = -280
    //     0xbed464: mov             x17, #-0x118
    // 0xbed468: str             x1, [fp, x17]
    // 0xbed46c: LoadField: r2 = r0->field_9f
    //     0xbed46c: ldur            w2, [x0, #0x9f]
    // 0xbed470: DecompressPointer r2
    //     0xbed470: add             x2, x2, HEAP, lsl #32
    // 0xbed474: ldr             x3, [fp, #0x18]
    // 0xbed478: LoadField: r4 = r3->field_9f
    //     0xbed478: ldur            w4, [x3, #0x9f]
    // 0xbed47c: DecompressPointer r4
    //     0xbed47c: add             x4, x4, HEAP, lsl #32
    // 0xbed480: stp             x4, x2, [SP, #-0x10]!
    // 0xbed484: ldr             d0, [fp, #0x10]
    // 0xbed488: SaveReg d0
    //     0xbed488: str             d0, [SP, #-8]!
    // 0xbed48c: r0 = lerp()
    //     0xbed48c: bl              #0xbf5fac  ; [package:flutter/src/material/badge_theme.dart] BadgeThemeData::lerp
    // 0xbed490: add             SP, SP, #0x18
    // 0xbed494: mov             x1, x0
    // 0xbed498: ldr             x0, [fp, #0x20]
    // 0xbed49c: r17 = -288
    //     0xbed49c: mov             x17, #-0x120
    // 0xbed4a0: str             x1, [fp, x17]
    // 0xbed4a4: LoadField: r2 = r0->field_a3
    //     0xbed4a4: ldur            w2, [x0, #0xa3]
    // 0xbed4a8: DecompressPointer r2
    //     0xbed4a8: add             x2, x2, HEAP, lsl #32
    // 0xbed4ac: ldr             x3, [fp, #0x18]
    // 0xbed4b0: LoadField: r4 = r3->field_a3
    //     0xbed4b0: ldur            w4, [x3, #0xa3]
    // 0xbed4b4: DecompressPointer r4
    //     0xbed4b4: add             x4, x4, HEAP, lsl #32
    // 0xbed4b8: stp             x4, x2, [SP, #-0x10]!
    // 0xbed4bc: ldr             d0, [fp, #0x10]
    // 0xbed4c0: SaveReg d0
    //     0xbed4c0: str             d0, [SP, #-8]!
    // 0xbed4c4: r0 = lerp()
    //     0xbed4c4: bl              #0xbf5e70  ; [package:flutter/src/material/banner_theme.dart] MaterialBannerThemeData::lerp
    // 0xbed4c8: add             SP, SP, #0x18
    // 0xbed4cc: mov             x1, x0
    // 0xbed4d0: ldr             x0, [fp, #0x20]
    // 0xbed4d4: r17 = -296
    //     0xbed4d4: mov             x17, #-0x128
    // 0xbed4d8: str             x1, [fp, x17]
    // 0xbed4dc: LoadField: r2 = r0->field_a7
    //     0xbed4dc: ldur            w2, [x0, #0xa7]
    // 0xbed4e0: DecompressPointer r2
    //     0xbed4e0: add             x2, x2, HEAP, lsl #32
    // 0xbed4e4: ldr             x3, [fp, #0x18]
    // 0xbed4e8: LoadField: r4 = r3->field_a7
    //     0xbed4e8: ldur            w4, [x3, #0xa7]
    // 0xbed4ec: DecompressPointer r4
    //     0xbed4ec: add             x4, x4, HEAP, lsl #32
    // 0xbed4f0: stp             x4, x2, [SP, #-0x10]!
    // 0xbed4f4: ldr             d0, [fp, #0x10]
    // 0xbed4f8: SaveReg d0
    //     0xbed4f8: str             d0, [SP, #-8]!
    // 0xbed4fc: r0 = lerp()
    //     0xbed4fc: bl              #0xbf5d48  ; [package:flutter/src/material/bottom_app_bar_theme.dart] BottomAppBarTheme::lerp
    // 0xbed500: add             SP, SP, #0x18
    // 0xbed504: mov             x1, x0
    // 0xbed508: ldr             x0, [fp, #0x20]
    // 0xbed50c: r17 = -304
    //     0xbed50c: mov             x17, #-0x130
    // 0xbed510: str             x1, [fp, x17]
    // 0xbed514: LoadField: r2 = r0->field_ab
    //     0xbed514: ldur            w2, [x0, #0xab]
    // 0xbed518: DecompressPointer r2
    //     0xbed518: add             x2, x2, HEAP, lsl #32
    // 0xbed51c: ldr             x3, [fp, #0x18]
    // 0xbed520: LoadField: r4 = r3->field_ab
    //     0xbed520: ldur            w4, [x3, #0xab]
    // 0xbed524: DecompressPointer r4
    //     0xbed524: add             x4, x4, HEAP, lsl #32
    // 0xbed528: stp             x4, x2, [SP, #-0x10]!
    // 0xbed52c: ldr             d0, [fp, #0x10]
    // 0xbed530: SaveReg d0
    //     0xbed530: str             d0, [SP, #-8]!
    // 0xbed534: r0 = lerp()
    //     0xbed534: bl              #0xbf5bbc  ; [package:flutter/src/material/bottom_navigation_bar_theme.dart] BottomNavigationBarThemeData::lerp
    // 0xbed538: add             SP, SP, #0x18
    // 0xbed53c: mov             x1, x0
    // 0xbed540: ldr             x0, [fp, #0x20]
    // 0xbed544: r17 = -312
    //     0xbed544: mov             x17, #-0x138
    // 0xbed548: str             x1, [fp, x17]
    // 0xbed54c: LoadField: r2 = r0->field_af
    //     0xbed54c: ldur            w2, [x0, #0xaf]
    // 0xbed550: DecompressPointer r2
    //     0xbed550: add             x2, x2, HEAP, lsl #32
    // 0xbed554: ldr             x3, [fp, #0x18]
    // 0xbed558: LoadField: r4 = r3->field_af
    //     0xbed558: ldur            w4, [x3, #0xaf]
    // 0xbed55c: DecompressPointer r4
    //     0xbed55c: add             x4, x4, HEAP, lsl #32
    // 0xbed560: stp             x4, x2, [SP, #-0x10]!
    // 0xbed564: ldr             d0, [fp, #0x10]
    // 0xbed568: SaveReg d0
    //     0xbed568: str             d0, [SP, #-8]!
    // 0xbed56c: r0 = lerp()
    //     0xbed56c: bl              #0xbf5a0c  ; [package:flutter/src/material/bottom_sheet_theme.dart] BottomSheetThemeData::lerp
    // 0xbed570: add             SP, SP, #0x18
    // 0xbed574: r17 = -320
    //     0xbed574: mov             x17, #-0x140
    // 0xbed578: str             x0, [fp, x17]
    // 0xbed57c: cmp             w0, NULL
    // 0xbed580: b.eq            #0xbee644
    // 0xbed584: ldr             x1, [fp, #0x20]
    // 0xbed588: LoadField: r2 = r1->field_b3
    //     0xbed588: ldur            w2, [x1, #0xb3]
    // 0xbed58c: DecompressPointer r2
    //     0xbed58c: add             x2, x2, HEAP, lsl #32
    // 0xbed590: ldr             x3, [fp, #0x18]
    // 0xbed594: LoadField: r4 = r3->field_b3
    //     0xbed594: ldur            w4, [x3, #0xb3]
    // 0xbed598: DecompressPointer r4
    //     0xbed598: add             x4, x4, HEAP, lsl #32
    // 0xbed59c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed5a0: ldr             d0, [fp, #0x10]
    // 0xbed5a4: SaveReg d0
    //     0xbed5a4: str             d0, [SP, #-8]!
    // 0xbed5a8: r0 = lerp()
    //     0xbed5a8: bl              #0xbf58f8  ; [package:flutter/src/material/button_bar_theme.dart] ButtonBarThemeData::lerp
    // 0xbed5ac: add             SP, SP, #0x18
    // 0xbed5b0: r17 = -336
    //     0xbed5b0: mov             x17, #-0x150
    // 0xbed5b4: str             x0, [fp, x17]
    // 0xbed5b8: cmp             w0, NULL
    // 0xbed5bc: b.eq            #0xbee648
    // 0xbed5c0: ldur            x1, [fp, #-0x10]
    // 0xbed5c4: tbnz            w1, #4, #0xbed5e0
    // 0xbed5c8: ldr             x2, [fp, #0x20]
    // 0xbed5cc: LoadField: r3 = r2->field_b7
    //     0xbed5cc: ldur            w3, [x2, #0xb7]
    // 0xbed5d0: DecompressPointer r3
    //     0xbed5d0: add             x3, x3, HEAP, lsl #32
    // 0xbed5d4: mov             x4, x3
    // 0xbed5d8: ldr             x3, [fp, #0x18]
    // 0xbed5dc: b               #0xbed5f0
    // 0xbed5e0: ldr             x2, [fp, #0x20]
    // 0xbed5e4: ldr             x3, [fp, #0x18]
    // 0xbed5e8: LoadField: r4 = r3->field_b7
    //     0xbed5e8: ldur            w4, [x3, #0xb7]
    // 0xbed5ec: DecompressPointer r4
    //     0xbed5ec: add             x4, x4, HEAP, lsl #32
    // 0xbed5f0: ldr             d0, [fp, #0x10]
    // 0xbed5f4: r17 = -328
    //     0xbed5f4: mov             x17, #-0x148
    // 0xbed5f8: str             x4, [fp, x17]
    // 0xbed5fc: LoadField: r5 = r2->field_bb
    //     0xbed5fc: ldur            w5, [x2, #0xbb]
    // 0xbed600: DecompressPointer r5
    //     0xbed600: add             x5, x5, HEAP, lsl #32
    // 0xbed604: LoadField: r6 = r3->field_bb
    //     0xbed604: ldur            w6, [x3, #0xbb]
    // 0xbed608: DecompressPointer r6
    //     0xbed608: add             x6, x6, HEAP, lsl #32
    // 0xbed60c: stp             x6, x5, [SP, #-0x10]!
    // 0xbed610: SaveReg d0
    //     0xbed610: str             d0, [SP, #-8]!
    // 0xbed614: r0 = lerp()
    //     0xbed614: bl              #0xbf57f8  ; [package:flutter/src/material/card_theme.dart] CardTheme::lerp
    // 0xbed618: add             SP, SP, #0x18
    // 0xbed61c: mov             x1, x0
    // 0xbed620: ldr             x0, [fp, #0x20]
    // 0xbed624: r17 = -344
    //     0xbed624: mov             x17, #-0x158
    // 0xbed628: str             x1, [fp, x17]
    // 0xbed62c: LoadField: r2 = r0->field_bf
    //     0xbed62c: ldur            w2, [x0, #0xbf]
    // 0xbed630: DecompressPointer r2
    //     0xbed630: add             x2, x2, HEAP, lsl #32
    // 0xbed634: ldr             x3, [fp, #0x18]
    // 0xbed638: LoadField: r4 = r3->field_bf
    //     0xbed638: ldur            w4, [x3, #0xbf]
    // 0xbed63c: DecompressPointer r4
    //     0xbed63c: add             x4, x4, HEAP, lsl #32
    // 0xbed640: stp             x4, x2, [SP, #-0x10]!
    // 0xbed644: ldr             d0, [fp, #0x10]
    // 0xbed648: SaveReg d0
    //     0xbed648: str             d0, [SP, #-8]!
    // 0xbed64c: r0 = lerp()
    //     0xbed64c: bl              #0xbf5634  ; [package:flutter/src/material/checkbox_theme.dart] CheckboxThemeData::lerp
    // 0xbed650: add             SP, SP, #0x18
    // 0xbed654: mov             x1, x0
    // 0xbed658: ldr             x0, [fp, #0x20]
    // 0xbed65c: r17 = -352
    //     0xbed65c: mov             x17, #-0x160
    // 0xbed660: str             x1, [fp, x17]
    // 0xbed664: LoadField: r2 = r0->field_c3
    //     0xbed664: ldur            w2, [x0, #0xc3]
    // 0xbed668: DecompressPointer r2
    //     0xbed668: add             x2, x2, HEAP, lsl #32
    // 0xbed66c: ldr             x3, [fp, #0x18]
    // 0xbed670: LoadField: r4 = r3->field_c3
    //     0xbed670: ldur            w4, [x3, #0xc3]
    // 0xbed674: DecompressPointer r4
    //     0xbed674: add             x4, x4, HEAP, lsl #32
    // 0xbed678: stp             x4, x2, [SP, #-0x10]!
    // 0xbed67c: ldr             d0, [fp, #0x10]
    // 0xbed680: SaveReg d0
    //     0xbed680: str             d0, [SP, #-8]!
    // 0xbed684: r0 = lerp()
    //     0xbed684: bl              #0xbf5394  ; [package:flutter/src/material/chip_theme.dart] ChipThemeData::lerp
    // 0xbed688: add             SP, SP, #0x18
    // 0xbed68c: r17 = -360
    //     0xbed68c: mov             x17, #-0x168
    // 0xbed690: str             x0, [fp, x17]
    // 0xbed694: cmp             w0, NULL
    // 0xbed698: b.eq            #0xbee64c
    // 0xbed69c: ldr             x1, [fp, #0x20]
    // 0xbed6a0: LoadField: r2 = r1->field_c7
    //     0xbed6a0: ldur            w2, [x1, #0xc7]
    // 0xbed6a4: DecompressPointer r2
    //     0xbed6a4: add             x2, x2, HEAP, lsl #32
    // 0xbed6a8: ldr             x3, [fp, #0x18]
    // 0xbed6ac: LoadField: r4 = r3->field_c7
    //     0xbed6ac: ldur            w4, [x3, #0xc7]
    // 0xbed6b0: DecompressPointer r4
    //     0xbed6b0: add             x4, x4, HEAP, lsl #32
    // 0xbed6b4: stp             x4, x2, [SP, #-0x10]!
    // 0xbed6b8: ldr             d0, [fp, #0x10]
    // 0xbed6bc: SaveReg d0
    //     0xbed6bc: str             d0, [SP, #-8]!
    // 0xbed6c0: r0 = lerp()
    //     0xbed6c0: bl              #0xbf50b8  ; [package:flutter/src/material/data_table_theme.dart] DataTableThemeData::lerp
    // 0xbed6c4: add             SP, SP, #0x18
    // 0xbed6c8: mov             x1, x0
    // 0xbed6cc: ldr             x0, [fp, #0x20]
    // 0xbed6d0: r17 = -368
    //     0xbed6d0: mov             x17, #-0x170
    // 0xbed6d4: str             x1, [fp, x17]
    // 0xbed6d8: LoadField: r2 = r0->field_cb
    //     0xbed6d8: ldur            w2, [x0, #0xcb]
    // 0xbed6dc: DecompressPointer r2
    //     0xbed6dc: add             x2, x2, HEAP, lsl #32
    // 0xbed6e0: ldr             x3, [fp, #0x18]
    // 0xbed6e4: LoadField: r4 = r3->field_cb
    //     0xbed6e4: ldur            w4, [x3, #0xcb]
    // 0xbed6e8: DecompressPointer r4
    //     0xbed6e8: add             x4, x4, HEAP, lsl #32
    // 0xbed6ec: stp             x4, x2, [SP, #-0x10]!
    // 0xbed6f0: ldr             d0, [fp, #0x10]
    // 0xbed6f4: SaveReg d0
    //     0xbed6f4: str             d0, [SP, #-8]!
    // 0xbed6f8: r0 = lerp()
    //     0xbed6f8: bl              #0xbf4f08  ; [package:flutter/src/material/dialog_theme.dart] DialogTheme::lerp
    // 0xbed6fc: add             SP, SP, #0x18
    // 0xbed700: mov             x1, x0
    // 0xbed704: ldr             x0, [fp, #0x20]
    // 0xbed708: r17 = -376
    //     0xbed708: mov             x17, #-0x178
    // 0xbed70c: str             x1, [fp, x17]
    // 0xbed710: LoadField: r2 = r0->field_cf
    //     0xbed710: ldur            w2, [x0, #0xcf]
    // 0xbed714: DecompressPointer r2
    //     0xbed714: add             x2, x2, HEAP, lsl #32
    // 0xbed718: ldr             x3, [fp, #0x18]
    // 0xbed71c: LoadField: r4 = r3->field_cf
    //     0xbed71c: ldur            w4, [x3, #0xcf]
    // 0xbed720: DecompressPointer r4
    //     0xbed720: add             x4, x4, HEAP, lsl #32
    // 0xbed724: stp             x4, x2, [SP, #-0x10]!
    // 0xbed728: ldr             d0, [fp, #0x10]
    // 0xbed72c: SaveReg d0
    //     0xbed72c: str             d0, [SP, #-8]!
    // 0xbed730: r0 = lerp()
    //     0xbed730: bl              #0xbf4d90  ; [package:flutter/src/material/divider_theme.dart] DividerThemeData::lerp
    // 0xbed734: add             SP, SP, #0x18
    // 0xbed738: mov             x1, x0
    // 0xbed73c: ldr             x0, [fp, #0x20]
    // 0xbed740: r17 = -384
    //     0xbed740: mov             x17, #-0x180
    // 0xbed744: str             x1, [fp, x17]
    // 0xbed748: LoadField: r2 = r0->field_d3
    //     0xbed748: ldur            w2, [x0, #0xd3]
    // 0xbed74c: DecompressPointer r2
    //     0xbed74c: add             x2, x2, HEAP, lsl #32
    // 0xbed750: ldr             x3, [fp, #0x18]
    // 0xbed754: LoadField: r4 = r3->field_d3
    //     0xbed754: ldur            w4, [x3, #0xd3]
    // 0xbed758: DecompressPointer r4
    //     0xbed758: add             x4, x4, HEAP, lsl #32
    // 0xbed75c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed760: ldr             d0, [fp, #0x10]
    // 0xbed764: SaveReg d0
    //     0xbed764: str             d0, [SP, #-8]!
    // 0xbed768: r0 = lerp()
    //     0xbed768: bl              #0xbf4c58  ; [package:flutter/src/material/drawer_theme.dart] DrawerThemeData::lerp
    // 0xbed76c: add             SP, SP, #0x18
    // 0xbed770: r17 = -392
    //     0xbed770: mov             x17, #-0x188
    // 0xbed774: str             x0, [fp, x17]
    // 0xbed778: cmp             w0, NULL
    // 0xbed77c: b.eq            #0xbee650
    // 0xbed780: ldr             x1, [fp, #0x20]
    // 0xbed784: LoadField: r2 = r1->field_d7
    //     0xbed784: ldur            w2, [x1, #0xd7]
    // 0xbed788: DecompressPointer r2
    //     0xbed788: add             x2, x2, HEAP, lsl #32
    // 0xbed78c: ldr             x3, [fp, #0x18]
    // 0xbed790: LoadField: r4 = r3->field_d7
    //     0xbed790: ldur            w4, [x3, #0xd7]
    // 0xbed794: DecompressPointer r4
    //     0xbed794: add             x4, x4, HEAP, lsl #32
    // 0xbed798: stp             x4, x2, [SP, #-0x10]!
    // 0xbed79c: ldr             d0, [fp, #0x10]
    // 0xbed7a0: SaveReg d0
    //     0xbed7a0: str             d0, [SP, #-8]!
    // 0xbed7a4: r0 = lerp()
    //     0xbed7a4: bl              #0xbf4b98  ; [package:flutter/src/material/dropdown_menu_theme.dart] DropdownMenuThemeData::lerp
    // 0xbed7a8: add             SP, SP, #0x18
    // 0xbed7ac: mov             x1, x0
    // 0xbed7b0: ldr             x0, [fp, #0x20]
    // 0xbed7b4: r17 = -400
    //     0xbed7b4: mov             x17, #-0x190
    // 0xbed7b8: str             x1, [fp, x17]
    // 0xbed7bc: LoadField: r2 = r0->field_db
    //     0xbed7bc: ldur            w2, [x0, #0xdb]
    // 0xbed7c0: DecompressPointer r2
    //     0xbed7c0: add             x2, x2, HEAP, lsl #32
    // 0xbed7c4: ldr             x3, [fp, #0x18]
    // 0xbed7c8: LoadField: r4 = r3->field_db
    //     0xbed7c8: ldur            w4, [x3, #0xdb]
    // 0xbed7cc: DecompressPointer r4
    //     0xbed7cc: add             x4, x4, HEAP, lsl #32
    // 0xbed7d0: stp             x4, x2, [SP, #-0x10]!
    // 0xbed7d4: ldr             d0, [fp, #0x10]
    // 0xbed7d8: SaveReg d0
    //     0xbed7d8: str             d0, [SP, #-8]!
    // 0xbed7dc: r0 = lerp()
    //     0xbed7dc: bl              #0xbf4b24  ; [package:flutter/src/material/elevated_button_theme.dart] ElevatedButtonThemeData::lerp
    // 0xbed7e0: add             SP, SP, #0x18
    // 0xbed7e4: r17 = -408
    //     0xbed7e4: mov             x17, #-0x198
    // 0xbed7e8: str             x0, [fp, x17]
    // 0xbed7ec: cmp             w0, NULL
    // 0xbed7f0: b.eq            #0xbee654
    // 0xbed7f4: ldr             x1, [fp, #0x20]
    // 0xbed7f8: LoadField: r2 = r1->field_df
    //     0xbed7f8: ldur            w2, [x1, #0xdf]
    // 0xbed7fc: DecompressPointer r2
    //     0xbed7fc: add             x2, x2, HEAP, lsl #32
    // 0xbed800: ldr             x3, [fp, #0x18]
    // 0xbed804: LoadField: r4 = r3->field_df
    //     0xbed804: ldur            w4, [x3, #0xdf]
    // 0xbed808: DecompressPointer r4
    //     0xbed808: add             x4, x4, HEAP, lsl #32
    // 0xbed80c: stp             x4, x2, [SP, #-0x10]!
    // 0xbed810: ldr             d0, [fp, #0x10]
    // 0xbed814: SaveReg d0
    //     0xbed814: str             d0, [SP, #-8]!
    // 0xbed818: r0 = lerp()
    //     0xbed818: bl              #0xbf49f8  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileThemeData::lerp
    // 0xbed81c: add             SP, SP, #0x18
    // 0xbed820: r17 = -416
    //     0xbed820: mov             x17, #-0x1a0
    // 0xbed824: str             x0, [fp, x17]
    // 0xbed828: cmp             w0, NULL
    // 0xbed82c: b.eq            #0xbee658
    // 0xbed830: ldr             x1, [fp, #0x20]
    // 0xbed834: LoadField: r2 = r1->field_e3
    //     0xbed834: ldur            w2, [x1, #0xe3]
    // 0xbed838: DecompressPointer r2
    //     0xbed838: add             x2, x2, HEAP, lsl #32
    // 0xbed83c: ldr             x3, [fp, #0x18]
    // 0xbed840: LoadField: r4 = r3->field_e3
    //     0xbed840: ldur            w4, [x3, #0xe3]
    // 0xbed844: DecompressPointer r4
    //     0xbed844: add             x4, x4, HEAP, lsl #32
    // 0xbed848: stp             x4, x2, [SP, #-0x10]!
    // 0xbed84c: ldr             d0, [fp, #0x10]
    // 0xbed850: SaveReg d0
    //     0xbed850: str             d0, [SP, #-8]!
    // 0xbed854: r0 = lerp()
    //     0xbed854: bl              #0xbf4984  ; [package:flutter/src/material/filled_button_theme.dart] FilledButtonThemeData::lerp
    // 0xbed858: add             SP, SP, #0x18
    // 0xbed85c: r17 = -424
    //     0xbed85c: mov             x17, #-0x1a8
    // 0xbed860: str             x0, [fp, x17]
    // 0xbed864: cmp             w0, NULL
    // 0xbed868: b.eq            #0xbee65c
    // 0xbed86c: ldr             x1, [fp, #0x20]
    // 0xbed870: LoadField: r2 = r1->field_e7
    //     0xbed870: ldur            w2, [x1, #0xe7]
    // 0xbed874: DecompressPointer r2
    //     0xbed874: add             x2, x2, HEAP, lsl #32
    // 0xbed878: ldr             x3, [fp, #0x18]
    // 0xbed87c: LoadField: r4 = r3->field_e7
    //     0xbed87c: ldur            w4, [x3, #0xe7]
    // 0xbed880: DecompressPointer r4
    //     0xbed880: add             x4, x4, HEAP, lsl #32
    // 0xbed884: stp             x4, x2, [SP, #-0x10]!
    // 0xbed888: ldr             d0, [fp, #0x10]
    // 0xbed88c: SaveReg d0
    //     0xbed88c: str             d0, [SP, #-8]!
    // 0xbed890: r0 = lerp()
    //     0xbed890: bl              #0xbf45a0  ; [package:flutter/src/material/floating_action_button_theme.dart] FloatingActionButtonThemeData::lerp
    // 0xbed894: add             SP, SP, #0x18
    // 0xbed898: r17 = -432
    //     0xbed898: mov             x17, #-0x1b0
    // 0xbed89c: str             x0, [fp, x17]
    // 0xbed8a0: cmp             w0, NULL
    // 0xbed8a4: b.eq            #0xbee660
    // 0xbed8a8: ldr             x1, [fp, #0x20]
    // 0xbed8ac: LoadField: r2 = r1->field_eb
    //     0xbed8ac: ldur            w2, [x1, #0xeb]
    // 0xbed8b0: DecompressPointer r2
    //     0xbed8b0: add             x2, x2, HEAP, lsl #32
    // 0xbed8b4: ldr             x3, [fp, #0x18]
    // 0xbed8b8: LoadField: r4 = r3->field_eb
    //     0xbed8b8: ldur            w4, [x3, #0xeb]
    // 0xbed8bc: DecompressPointer r4
    //     0xbed8bc: add             x4, x4, HEAP, lsl #32
    // 0xbed8c0: stp             x4, x2, [SP, #-0x10]!
    // 0xbed8c4: ldr             d0, [fp, #0x10]
    // 0xbed8c8: SaveReg d0
    //     0xbed8c8: str             d0, [SP, #-8]!
    // 0xbed8cc: r0 = lerp()
    //     0xbed8cc: bl              #0xbf452c  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonThemeData::lerp
    // 0xbed8d0: add             SP, SP, #0x18
    // 0xbed8d4: r17 = -440
    //     0xbed8d4: mov             x17, #-0x1b8
    // 0xbed8d8: str             x0, [fp, x17]
    // 0xbed8dc: cmp             w0, NULL
    // 0xbed8e0: b.eq            #0xbee664
    // 0xbed8e4: ldr             x1, [fp, #0x20]
    // 0xbed8e8: LoadField: r2 = r1->field_ef
    //     0xbed8e8: ldur            w2, [x1, #0xef]
    // 0xbed8ec: DecompressPointer r2
    //     0xbed8ec: add             x2, x2, HEAP, lsl #32
    // 0xbed8f0: ldr             x3, [fp, #0x18]
    // 0xbed8f4: LoadField: r4 = r3->field_ef
    //     0xbed8f4: ldur            w4, [x3, #0xef]
    // 0xbed8f8: DecompressPointer r4
    //     0xbed8f8: add             x4, x4, HEAP, lsl #32
    // 0xbed8fc: stp             x4, x2, [SP, #-0x10]!
    // 0xbed900: ldr             d0, [fp, #0x10]
    // 0xbed904: SaveReg d0
    //     0xbed904: str             d0, [SP, #-8]!
    // 0xbed908: r0 = lerp()
    //     0xbed908: bl              #0xbf42f4  ; [package:flutter/src/material/list_tile_theme.dart] ListTileThemeData::lerp
    // 0xbed90c: add             SP, SP, #0x18
    // 0xbed910: r17 = -448
    //     0xbed910: mov             x17, #-0x1c0
    // 0xbed914: str             x0, [fp, x17]
    // 0xbed918: cmp             w0, NULL
    // 0xbed91c: b.eq            #0xbee668
    // 0xbed920: ldr             x1, [fp, #0x20]
    // 0xbed924: LoadField: r2 = r1->field_f3
    //     0xbed924: ldur            w2, [x1, #0xf3]
    // 0xbed928: DecompressPointer r2
    //     0xbed928: add             x2, x2, HEAP, lsl #32
    // 0xbed92c: ldr             x3, [fp, #0x18]
    // 0xbed930: LoadField: r4 = r3->field_f3
    //     0xbed930: ldur            w4, [x3, #0xf3]
    // 0xbed934: DecompressPointer r4
    //     0xbed934: add             x4, x4, HEAP, lsl #32
    // 0xbed938: stp             x4, x2, [SP, #-0x10]!
    // 0xbed93c: ldr             d0, [fp, #0x10]
    // 0xbed940: SaveReg d0
    //     0xbed940: str             d0, [SP, #-8]!
    // 0xbed944: r0 = lerp()
    //     0xbed944: bl              #0xbf4280  ; [package:flutter/src/material/menu_bar_theme.dart] MenuBarThemeData::lerp
    // 0xbed948: add             SP, SP, #0x18
    // 0xbed94c: mov             x1, x0
    // 0xbed950: ldr             x0, [fp, #0x20]
    // 0xbed954: r17 = -456
    //     0xbed954: mov             x17, #-0x1c8
    // 0xbed958: str             x1, [fp, x17]
    // 0xbed95c: LoadField: r2 = r0->field_f7
    //     0xbed95c: ldur            w2, [x0, #0xf7]
    // 0xbed960: DecompressPointer r2
    //     0xbed960: add             x2, x2, HEAP, lsl #32
    // 0xbed964: ldr             x3, [fp, #0x18]
    // 0xbed968: LoadField: r4 = r3->field_f7
    //     0xbed968: ldur            w4, [x3, #0xf7]
    // 0xbed96c: DecompressPointer r4
    //     0xbed96c: add             x4, x4, HEAP, lsl #32
    // 0xbed970: stp             x4, x2, [SP, #-0x10]!
    // 0xbed974: ldr             d0, [fp, #0x10]
    // 0xbed978: SaveReg d0
    //     0xbed978: str             d0, [SP, #-8]!
    // 0xbed97c: r0 = lerp()
    //     0xbed97c: bl              #0xbf420c  ; [package:flutter/src/material/menu_button_theme.dart] MenuButtonThemeData::lerp
    // 0xbed980: add             SP, SP, #0x18
    // 0xbed984: mov             x1, x0
    // 0xbed988: ldr             x0, [fp, #0x20]
    // 0xbed98c: r17 = -464
    //     0xbed98c: mov             x17, #-0x1d0
    // 0xbed990: str             x1, [fp, x17]
    // 0xbed994: LoadField: r2 = r0->field_fb
    //     0xbed994: ldur            w2, [x0, #0xfb]
    // 0xbed998: DecompressPointer r2
    //     0xbed998: add             x2, x2, HEAP, lsl #32
    // 0xbed99c: ldr             x3, [fp, #0x18]
    // 0xbed9a0: LoadField: r4 = r3->field_fb
    //     0xbed9a0: ldur            w4, [x3, #0xfb]
    // 0xbed9a4: DecompressPointer r4
    //     0xbed9a4: add             x4, x4, HEAP, lsl #32
    // 0xbed9a8: stp             x4, x2, [SP, #-0x10]!
    // 0xbed9ac: ldr             d0, [fp, #0x10]
    // 0xbed9b0: SaveReg d0
    //     0xbed9b0: str             d0, [SP, #-8]!
    // 0xbed9b4: r0 = lerp()
    //     0xbed9b4: bl              #0xbf3c34  ; [package:flutter/src/material/menu_theme.dart] MenuThemeData::lerp
    // 0xbed9b8: add             SP, SP, #0x18
    // 0xbed9bc: mov             x1, x0
    // 0xbed9c0: ldr             x0, [fp, #0x20]
    // 0xbed9c4: r17 = -472
    //     0xbed9c4: mov             x17, #-0x1d8
    // 0xbed9c8: str             x1, [fp, x17]
    // 0xbed9cc: LoadField: r2 = r0->field_ff
    //     0xbed9cc: ldur            w2, [x0, #0xff]
    // 0xbed9d0: DecompressPointer r2
    //     0xbed9d0: add             x2, x2, HEAP, lsl #32
    // 0xbed9d4: ldr             x3, [fp, #0x18]
    // 0xbed9d8: LoadField: r4 = r3->field_ff
    //     0xbed9d8: ldur            w4, [x3, #0xff]
    // 0xbed9dc: DecompressPointer r4
    //     0xbed9dc: add             x4, x4, HEAP, lsl #32
    // 0xbed9e0: stp             x4, x2, [SP, #-0x10]!
    // 0xbed9e4: ldr             d0, [fp, #0x10]
    // 0xbed9e8: SaveReg d0
    //     0xbed9e8: str             d0, [SP, #-8]!
    // 0xbed9ec: r0 = lerp()
    //     0xbed9ec: bl              #0xbf3a3c  ; [package:flutter/src/material/navigation_bar_theme.dart] NavigationBarThemeData::lerp
    // 0xbed9f0: add             SP, SP, #0x18
    // 0xbed9f4: r17 = -480
    //     0xbed9f4: mov             x17, #-0x1e0
    // 0xbed9f8: str             x0, [fp, x17]
    // 0xbed9fc: cmp             w0, NULL
    // 0xbeda00: b.eq            #0xbee66c
    // 0xbeda04: ldr             x1, [fp, #0x20]
    // 0xbeda08: r17 = 259
    //     0xbeda08: mov             x17, #0x103
    // 0xbeda0c: ldr             w2, [x1, x17]
    // 0xbeda10: DecompressPointer r2
    //     0xbeda10: add             x2, x2, HEAP, lsl #32
    // 0xbeda14: ldr             x3, [fp, #0x18]
    // 0xbeda18: r17 = 259
    //     0xbeda18: mov             x17, #0x103
    // 0xbeda1c: ldr             w4, [x3, x17]
    // 0xbeda20: DecompressPointer r4
    //     0xbeda20: add             x4, x4, HEAP, lsl #32
    // 0xbeda24: stp             x4, x2, [SP, #-0x10]!
    // 0xbeda28: ldr             d0, [fp, #0x10]
    // 0xbeda2c: SaveReg d0
    //     0xbeda2c: str             d0, [SP, #-8]!
    // 0xbeda30: r0 = lerp()
    //     0xbeda30: bl              #0xbf37ec  ; [package:flutter/src/material/navigation_drawer_theme.dart] NavigationDrawerThemeData::lerp
    // 0xbeda34: add             SP, SP, #0x18
    // 0xbeda38: r17 = -488
    //     0xbeda38: mov             x17, #-0x1e8
    // 0xbeda3c: str             x0, [fp, x17]
    // 0xbeda40: cmp             w0, NULL
    // 0xbeda44: b.eq            #0xbee670
    // 0xbeda48: ldr             x1, [fp, #0x20]
    // 0xbeda4c: r17 = 263
    //     0xbeda4c: mov             x17, #0x107
    // 0xbeda50: ldr             w2, [x1, x17]
    // 0xbeda54: DecompressPointer r2
    //     0xbeda54: add             x2, x2, HEAP, lsl #32
    // 0xbeda58: ldr             x3, [fp, #0x18]
    // 0xbeda5c: r17 = 263
    //     0xbeda5c: mov             x17, #0x107
    // 0xbeda60: ldr             w4, [x3, x17]
    // 0xbeda64: DecompressPointer r4
    //     0xbeda64: add             x4, x4, HEAP, lsl #32
    // 0xbeda68: stp             x4, x2, [SP, #-0x10]!
    // 0xbeda6c: ldr             d0, [fp, #0x10]
    // 0xbeda70: SaveReg d0
    //     0xbeda70: str             d0, [SP, #-8]!
    // 0xbeda74: r0 = lerp()
    //     0xbeda74: bl              #0xbf35c8  ; [package:flutter/src/material/navigation_rail_theme.dart] NavigationRailThemeData::lerp
    // 0xbeda78: add             SP, SP, #0x18
    // 0xbeda7c: r17 = -496
    //     0xbeda7c: mov             x17, #-0x1f0
    // 0xbeda80: str             x0, [fp, x17]
    // 0xbeda84: cmp             w0, NULL
    // 0xbeda88: b.eq            #0xbee674
    // 0xbeda8c: ldr             x1, [fp, #0x20]
    // 0xbeda90: r17 = 267
    //     0xbeda90: mov             x17, #0x10b
    // 0xbeda94: ldr             w2, [x1, x17]
    // 0xbeda98: DecompressPointer r2
    //     0xbeda98: add             x2, x2, HEAP, lsl #32
    // 0xbeda9c: ldr             x3, [fp, #0x18]
    // 0xbedaa0: r17 = 267
    //     0xbedaa0: mov             x17, #0x10b
    // 0xbedaa4: ldr             w4, [x3, x17]
    // 0xbedaa8: DecompressPointer r4
    //     0xbedaa8: add             x4, x4, HEAP, lsl #32
    // 0xbedaac: stp             x4, x2, [SP, #-0x10]!
    // 0xbedab0: ldr             d0, [fp, #0x10]
    // 0xbedab4: SaveReg d0
    //     0xbedab4: str             d0, [SP, #-8]!
    // 0xbedab8: r0 = lerp()
    //     0xbedab8: bl              #0xbf3554  ; [package:flutter/src/material/outlined_button_theme.dart] OutlinedButtonThemeData::lerp
    // 0xbedabc: add             SP, SP, #0x18
    // 0xbedac0: r17 = -504
    //     0xbedac0: mov             x17, #-0x1f8
    // 0xbedac4: str             x0, [fp, x17]
    // 0xbedac8: cmp             w0, NULL
    // 0xbedacc: b.eq            #0xbee678
    // 0xbedad0: ldr             x1, [fp, #0x20]
    // 0xbedad4: r17 = 271
    //     0xbedad4: mov             x17, #0x10f
    // 0xbedad8: ldr             w2, [x1, x17]
    // 0xbedadc: DecompressPointer r2
    //     0xbedadc: add             x2, x2, HEAP, lsl #32
    // 0xbedae0: ldr             x3, [fp, #0x18]
    // 0xbedae4: r17 = 271
    //     0xbedae4: mov             x17, #0x10f
    // 0xbedae8: ldr             w4, [x3, x17]
    // 0xbedaec: DecompressPointer r4
    //     0xbedaec: add             x4, x4, HEAP, lsl #32
    // 0xbedaf0: stp             x4, x2, [SP, #-0x10]!
    // 0xbedaf4: ldr             d0, [fp, #0x10]
    // 0xbedaf8: SaveReg d0
    //     0xbedaf8: str             d0, [SP, #-8]!
    // 0xbedafc: r0 = lerp()
    //     0xbedafc: bl              #0xbf3400  ; [package:flutter/src/material/popup_menu_theme.dart] PopupMenuThemeData::lerp
    // 0xbedb00: add             SP, SP, #0x18
    // 0xbedb04: r17 = -512
    //     0xbedb04: mov             x17, #-0x200
    // 0xbedb08: str             x0, [fp, x17]
    // 0xbedb0c: cmp             w0, NULL
    // 0xbedb10: b.eq            #0xbee67c
    // 0xbedb14: ldr             x1, [fp, #0x20]
    // 0xbedb18: r17 = 275
    //     0xbedb18: mov             x17, #0x113
    // 0xbedb1c: ldr             w2, [x1, x17]
    // 0xbedb20: DecompressPointer r2
    //     0xbedb20: add             x2, x2, HEAP, lsl #32
    // 0xbedb24: ldr             x3, [fp, #0x18]
    // 0xbedb28: r17 = 275
    //     0xbedb28: mov             x17, #0x113
    // 0xbedb2c: ldr             w4, [x3, x17]
    // 0xbedb30: DecompressPointer r4
    //     0xbedb30: add             x4, x4, HEAP, lsl #32
    // 0xbedb34: stp             x4, x2, [SP, #-0x10]!
    // 0xbedb38: ldr             d0, [fp, #0x10]
    // 0xbedb3c: SaveReg d0
    //     0xbedb3c: str             d0, [SP, #-8]!
    // 0xbedb40: r0 = lerp()
    //     0xbedb40: bl              #0xbf3300  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorThemeData::lerp
    // 0xbedb44: add             SP, SP, #0x18
    // 0xbedb48: r17 = -520
    //     0xbedb48: mov             x17, #-0x208
    // 0xbedb4c: str             x0, [fp, x17]
    // 0xbedb50: cmp             w0, NULL
    // 0xbedb54: b.eq            #0xbee680
    // 0xbedb58: ldr             x1, [fp, #0x20]
    // 0xbedb5c: r17 = 279
    //     0xbedb5c: mov             x17, #0x117
    // 0xbedb60: ldr             w2, [x1, x17]
    // 0xbedb64: DecompressPointer r2
    //     0xbedb64: add             x2, x2, HEAP, lsl #32
    // 0xbedb68: ldr             x3, [fp, #0x18]
    // 0xbedb6c: r17 = 279
    //     0xbedb6c: mov             x17, #0x117
    // 0xbedb70: ldr             w4, [x3, x17]
    // 0xbedb74: DecompressPointer r4
    //     0xbedb74: add             x4, x4, HEAP, lsl #32
    // 0xbedb78: stp             x4, x2, [SP, #-0x10]!
    // 0xbedb7c: ldr             d0, [fp, #0x10]
    // 0xbedb80: SaveReg d0
    //     0xbedb80: str             d0, [SP, #-8]!
    // 0xbedb84: r0 = lerp()
    //     0xbedb84: bl              #0xbf3194  ; [package:flutter/src/material/radio_theme.dart] RadioThemeData::lerp
    // 0xbedb88: add             SP, SP, #0x18
    // 0xbedb8c: mov             x1, x0
    // 0xbedb90: ldr             x0, [fp, #0x20]
    // 0xbedb94: r17 = -528
    //     0xbedb94: mov             x17, #-0x210
    // 0xbedb98: str             x1, [fp, x17]
    // 0xbedb9c: r17 = 283
    //     0xbedb9c: mov             x17, #0x11b
    // 0xbedba0: ldr             w2, [x0, x17]
    // 0xbedba4: DecompressPointer r2
    //     0xbedba4: add             x2, x2, HEAP, lsl #32
    // 0xbedba8: ldr             x3, [fp, #0x18]
    // 0xbedbac: r17 = 283
    //     0xbedbac: mov             x17, #0x11b
    // 0xbedbb0: ldr             w4, [x3, x17]
    // 0xbedbb4: DecompressPointer r4
    //     0xbedbb4: add             x4, x4, HEAP, lsl #32
    // 0xbedbb8: stp             x4, x2, [SP, #-0x10]!
    // 0xbedbbc: ldr             d0, [fp, #0x10]
    // 0xbedbc0: SaveReg d0
    //     0xbedbc0: str             d0, [SP, #-8]!
    // 0xbedbc4: r0 = lerp()
    //     0xbedbc4: bl              #0xbf3120  ; [package:flutter/src/material/segmented_button_theme.dart] SegmentedButtonThemeData::lerp
    // 0xbedbc8: add             SP, SP, #0x18
    // 0xbedbcc: mov             x1, x0
    // 0xbedbd0: ldr             x0, [fp, #0x20]
    // 0xbedbd4: r17 = -536
    //     0xbedbd4: mov             x17, #-0x218
    // 0xbedbd8: str             x1, [fp, x17]
    // 0xbedbdc: r17 = 287
    //     0xbedbdc: mov             x17, #0x11f
    // 0xbedbe0: ldr             w2, [x0, x17]
    // 0xbedbe4: DecompressPointer r2
    //     0xbedbe4: add             x2, x2, HEAP, lsl #32
    // 0xbedbe8: ldr             x3, [fp, #0x18]
    // 0xbedbec: r17 = 287
    //     0xbedbec: mov             x17, #0x11f
    // 0xbedbf0: ldr             w4, [x3, x17]
    // 0xbedbf4: DecompressPointer r4
    //     0xbedbf4: add             x4, x4, HEAP, lsl #32
    // 0xbedbf8: stp             x4, x2, [SP, #-0x10]!
    // 0xbedbfc: ldr             d0, [fp, #0x10]
    // 0xbedc00: SaveReg d0
    //     0xbedc00: str             d0, [SP, #-8]!
    // 0xbedc04: r0 = lerp()
    //     0xbedc04: bl              #0xbf2b64  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::lerp
    // 0xbedc08: add             SP, SP, #0x18
    // 0xbedc0c: mov             x1, x0
    // 0xbedc10: ldr             x0, [fp, #0x20]
    // 0xbedc14: r17 = -544
    //     0xbedc14: mov             x17, #-0x220
    // 0xbedc18: str             x1, [fp, x17]
    // 0xbedc1c: r17 = 291
    //     0xbedc1c: mov             x17, #0x123
    // 0xbedc20: ldr             w2, [x0, x17]
    // 0xbedc24: DecompressPointer r2
    //     0xbedc24: add             x2, x2, HEAP, lsl #32
    // 0xbedc28: ldr             x3, [fp, #0x18]
    // 0xbedc2c: r17 = 291
    //     0xbedc2c: mov             x17, #0x123
    // 0xbedc30: ldr             w4, [x3, x17]
    // 0xbedc34: DecompressPointer r4
    //     0xbedc34: add             x4, x4, HEAP, lsl #32
    // 0xbedc38: stp             x4, x2, [SP, #-0x10]!
    // 0xbedc3c: ldr             d0, [fp, #0x10]
    // 0xbedc40: SaveReg d0
    //     0xbedc40: str             d0, [SP, #-8]!
    // 0xbedc44: r0 = lerp()
    //     0xbedc44: bl              #0xbf2a00  ; [package:flutter/src/material/snack_bar_theme.dart] SnackBarThemeData::lerp
    // 0xbedc48: add             SP, SP, #0x18
    // 0xbedc4c: mov             x1, x0
    // 0xbedc50: ldr             x0, [fp, #0x20]
    // 0xbedc54: r17 = -552
    //     0xbedc54: mov             x17, #-0x228
    // 0xbedc58: str             x1, [fp, x17]
    // 0xbedc5c: r17 = 295
    //     0xbedc5c: mov             x17, #0x127
    // 0xbedc60: ldr             w2, [x0, x17]
    // 0xbedc64: DecompressPointer r2
    //     0xbedc64: add             x2, x2, HEAP, lsl #32
    // 0xbedc68: ldr             x3, [fp, #0x18]
    // 0xbedc6c: r17 = 295
    //     0xbedc6c: mov             x17, #0x127
    // 0xbedc70: ldr             w4, [x3, x17]
    // 0xbedc74: DecompressPointer r4
    //     0xbedc74: add             x4, x4, HEAP, lsl #32
    // 0xbedc78: stp             x4, x2, [SP, #-0x10]!
    // 0xbedc7c: ldr             d0, [fp, #0x10]
    // 0xbedc80: SaveReg d0
    //     0xbedc80: str             d0, [SP, #-8]!
    // 0xbedc84: r0 = lerp()
    //     0xbedc84: bl              #0xbf283c  ; [package:flutter/src/material/switch_theme.dart] SwitchThemeData::lerp
    // 0xbedc88: add             SP, SP, #0x18
    // 0xbedc8c: mov             x1, x0
    // 0xbedc90: ldr             x0, [fp, #0x20]
    // 0xbedc94: r17 = -560
    //     0xbedc94: mov             x17, #-0x230
    // 0xbedc98: str             x1, [fp, x17]
    // 0xbedc9c: r17 = 299
    //     0xbedc9c: mov             x17, #0x12b
    // 0xbedca0: ldr             w2, [x0, x17]
    // 0xbedca4: DecompressPointer r2
    //     0xbedca4: add             x2, x2, HEAP, lsl #32
    // 0xbedca8: ldr             x3, [fp, #0x18]
    // 0xbedcac: r17 = 299
    //     0xbedcac: mov             x17, #0x12b
    // 0xbedcb0: ldr             w4, [x3, x17]
    // 0xbedcb4: DecompressPointer r4
    //     0xbedcb4: add             x4, x4, HEAP, lsl #32
    // 0xbedcb8: stp             x4, x2, [SP, #-0x10]!
    // 0xbedcbc: ldr             d0, [fp, #0x10]
    // 0xbedcc0: SaveReg d0
    //     0xbedcc0: str             d0, [SP, #-8]!
    // 0xbedcc4: r0 = lerp()
    //     0xbedcc4: bl              #0xbf2370  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::lerp
    // 0xbedcc8: add             SP, SP, #0x18
    // 0xbedccc: mov             x1, x0
    // 0xbedcd0: ldr             x0, [fp, #0x20]
    // 0xbedcd4: r17 = -568
    //     0xbedcd4: mov             x17, #-0x238
    // 0xbedcd8: str             x1, [fp, x17]
    // 0xbedcdc: r17 = 303
    //     0xbedcdc: mov             x17, #0x12f
    // 0xbedce0: ldr             w2, [x0, x17]
    // 0xbedce4: DecompressPointer r2
    //     0xbedce4: add             x2, x2, HEAP, lsl #32
    // 0xbedce8: ldr             x3, [fp, #0x18]
    // 0xbedcec: r17 = 303
    //     0xbedcec: mov             x17, #0x12f
    // 0xbedcf0: ldr             w4, [x3, x17]
    // 0xbedcf4: DecompressPointer r4
    //     0xbedcf4: add             x4, x4, HEAP, lsl #32
    // 0xbedcf8: stp             x4, x2, [SP, #-0x10]!
    // 0xbedcfc: ldr             d0, [fp, #0x10]
    // 0xbedd00: SaveReg d0
    //     0xbedd00: str             d0, [SP, #-8]!
    // 0xbedd04: r0 = lerp()
    //     0xbedd04: bl              #0xbef2d8  ; [package:flutter/src/material/text_button_theme.dart] TextButtonThemeData::lerp
    // 0xbedd08: add             SP, SP, #0x18
    // 0xbedd0c: r17 = -576
    //     0xbedd0c: mov             x17, #-0x240
    // 0xbedd10: str             x0, [fp, x17]
    // 0xbedd14: cmp             w0, NULL
    // 0xbedd18: b.eq            #0xbee684
    // 0xbedd1c: ldr             x1, [fp, #0x20]
    // 0xbedd20: r17 = 307
    //     0xbedd20: mov             x17, #0x133
    // 0xbedd24: ldr             w2, [x1, x17]
    // 0xbedd28: DecompressPointer r2
    //     0xbedd28: add             x2, x2, HEAP, lsl #32
    // 0xbedd2c: ldr             x3, [fp, #0x18]
    // 0xbedd30: r17 = 307
    //     0xbedd30: mov             x17, #0x133
    // 0xbedd34: ldr             w4, [x3, x17]
    // 0xbedd38: DecompressPointer r4
    //     0xbedd38: add             x4, x4, HEAP, lsl #32
    // 0xbedd3c: stp             x4, x2, [SP, #-0x10]!
    // 0xbedd40: ldr             d0, [fp, #0x10]
    // 0xbedd44: SaveReg d0
    //     0xbedd44: str             d0, [SP, #-8]!
    // 0xbedd48: r0 = lerp()
    //     0xbedd48: bl              #0xbef1a8  ; [package:flutter/src/material/text_selection_theme.dart] TextSelectionThemeData::lerp
    // 0xbedd4c: add             SP, SP, #0x18
    // 0xbedd50: r17 = -584
    //     0xbedd50: mov             x17, #-0x248
    // 0xbedd54: str             x0, [fp, x17]
    // 0xbedd58: cmp             w0, NULL
    // 0xbedd5c: b.eq            #0xbee688
    // 0xbedd60: ldr             x1, [fp, #0x20]
    // 0xbedd64: r17 = 311
    //     0xbedd64: mov             x17, #0x137
    // 0xbedd68: ldr             w2, [x1, x17]
    // 0xbedd6c: DecompressPointer r2
    //     0xbedd6c: add             x2, x2, HEAP, lsl #32
    // 0xbedd70: ldr             x3, [fp, #0x18]
    // 0xbedd74: r17 = 311
    //     0xbedd74: mov             x17, #0x137
    // 0xbedd78: ldr             w4, [x3, x17]
    // 0xbedd7c: DecompressPointer r4
    //     0xbedd7c: add             x4, x4, HEAP, lsl #32
    // 0xbedd80: stp             x4, x2, [SP, #-0x10]!
    // 0xbedd84: ldr             d0, [fp, #0x10]
    // 0xbedd88: SaveReg d0
    //     0xbedd88: str             d0, [SP, #-8]!
    // 0xbedd8c: r0 = lerp()
    //     0xbedd8c: bl              #0xbef040  ; [package:flutter/src/material/time_picker_theme.dart] TimePickerThemeData::lerp
    // 0xbedd90: add             SP, SP, #0x18
    // 0xbedd94: mov             x1, x0
    // 0xbedd98: ldr             x0, [fp, #0x20]
    // 0xbedd9c: r17 = -592
    //     0xbedd9c: mov             x17, #-0x250
    // 0xbedda0: str             x1, [fp, x17]
    // 0xbedda4: r17 = 315
    //     0xbedda4: mov             x17, #0x13b
    // 0xbedda8: ldr             w2, [x0, x17]
    // 0xbeddac: DecompressPointer r2
    //     0xbeddac: add             x2, x2, HEAP, lsl #32
    // 0xbeddb0: ldr             x3, [fp, #0x18]
    // 0xbeddb4: r17 = 315
    //     0xbeddb4: mov             x17, #0x13b
    // 0xbeddb8: ldr             w4, [x3, x17]
    // 0xbeddbc: DecompressPointer r4
    //     0xbeddbc: add             x4, x4, HEAP, lsl #32
    // 0xbeddc0: stp             x4, x2, [SP, #-0x10]!
    // 0xbeddc4: ldr             d0, [fp, #0x10]
    // 0xbeddc8: SaveReg d0
    //     0xbeddc8: str             d0, [SP, #-8]!
    // 0xbeddcc: r0 = lerp()
    //     0xbeddcc: bl              #0xbee7e0  ; [package:flutter/src/material/toggle_buttons_theme.dart] ToggleButtonsThemeData::lerp
    // 0xbeddd0: add             SP, SP, #0x18
    // 0xbeddd4: r17 = -600
    //     0xbeddd4: mov             x17, #-0x258
    // 0xbeddd8: str             x0, [fp, x17]
    // 0xbedddc: cmp             w0, NULL
    // 0xbedde0: b.eq            #0xbee68c
    // 0xbedde4: ldr             x1, [fp, #0x20]
    // 0xbedde8: r17 = 319
    //     0xbedde8: mov             x17, #0x13f
    // 0xbeddec: ldr             w2, [x1, x17]
    // 0xbeddf0: DecompressPointer r2
    //     0xbeddf0: add             x2, x2, HEAP, lsl #32
    // 0xbeddf4: ldr             x3, [fp, #0x18]
    // 0xbeddf8: r17 = 319
    //     0xbeddf8: mov             x17, #0x13f
    // 0xbeddfc: ldr             w4, [x3, x17]
    // 0xbede00: DecompressPointer r4
    //     0xbede00: add             x4, x4, HEAP, lsl #32
    // 0xbede04: stp             x4, x2, [SP, #-0x10]!
    // 0xbede08: ldr             d0, [fp, #0x10]
    // 0xbede0c: SaveReg d0
    //     0xbede0c: str             d0, [SP, #-8]!
    // 0xbede10: r0 = lerp()
    //     0xbede10: bl              #0xbee6cc  ; [package:flutter/src/material/tooltip_theme.dart] TooltipThemeData::lerp
    // 0xbede14: add             SP, SP, #0x18
    // 0xbede18: r17 = -608
    //     0xbede18: mov             x17, #-0x260
    // 0xbede1c: str             x0, [fp, x17]
    // 0xbede20: cmp             w0, NULL
    // 0xbede24: b.eq            #0xbee690
    // 0xbede28: ldr             x1, [fp, #0x20]
    // 0xbede2c: r17 = 323
    //     0xbede2c: mov             x17, #0x143
    // 0xbede30: ldr             w2, [x1, x17]
    // 0xbede34: DecompressPointer r2
    //     0xbede34: add             x2, x2, HEAP, lsl #32
    // 0xbede38: cmp             w2, NULL
    // 0xbede3c: b.eq            #0xbee694
    // 0xbede40: ldr             x3, [fp, #0x18]
    // 0xbede44: r17 = 323
    //     0xbede44: mov             x17, #0x143
    // 0xbede48: ldr             w4, [x3, x17]
    // 0xbede4c: DecompressPointer r4
    //     0xbede4c: add             x4, x4, HEAP, lsl #32
    // 0xbede50: cmp             w4, NULL
    // 0xbede54: b.eq            #0xbee698
    // 0xbede58: stp             x4, x2, [SP, #-0x10]!
    // 0xbede5c: ldur            x16, [fp, #-0x48]
    // 0xbede60: SaveReg r16
    //     0xbede60: str             x16, [SP, #-8]!
    // 0xbede64: r0 = lerp()
    //     0xbede64: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbede68: add             SP, SP, #0x18
    // 0xbede6c: mov             x1, x0
    // 0xbede70: ldur            x0, [fp, #-0x10]
    // 0xbede74: r17 = -624
    //     0xbede74: mov             x17, #-0x270
    // 0xbede78: str             x1, [fp, x17]
    // 0xbede7c: tbnz            w0, #4, #0xbede9c
    // 0xbede80: ldr             x2, [fp, #0x20]
    // 0xbede84: r17 = 327
    //     0xbede84: mov             x17, #0x147
    // 0xbede88: ldr             w3, [x2, x17]
    // 0xbede8c: DecompressPointer r3
    //     0xbede8c: add             x3, x3, HEAP, lsl #32
    // 0xbede90: mov             x4, x3
    // 0xbede94: ldr             x3, [fp, #0x18]
    // 0xbede98: b               #0xbedeb0
    // 0xbede9c: ldr             x2, [fp, #0x20]
    // 0xbedea0: ldr             x3, [fp, #0x18]
    // 0xbedea4: r17 = 327
    //     0xbedea4: mov             x17, #0x147
    // 0xbedea8: ldr             w4, [x3, x17]
    // 0xbedeac: DecompressPointer r4
    //     0xbedeac: add             x4, x4, HEAP, lsl #32
    // 0xbedeb0: ldr             d0, [fp, #0x10]
    // 0xbedeb4: r17 = -616
    //     0xbedeb4: mov             x17, #-0x268
    // 0xbedeb8: str             x4, [fp, x17]
    // 0xbedebc: r17 = 331
    //     0xbedebc: mov             x17, #0x14b
    // 0xbedec0: ldr             w5, [x2, x17]
    // 0xbedec4: DecompressPointer r5
    //     0xbedec4: add             x5, x5, HEAP, lsl #32
    // 0xbedec8: r17 = 331
    //     0xbedec8: mov             x17, #0x14b
    // 0xbedecc: ldr             w6, [x3, x17]
    // 0xbeded0: DecompressPointer r6
    //     0xbeded0: add             x6, x6, HEAP, lsl #32
    // 0xbeded4: stp             x6, x5, [SP, #-0x10]!
    // 0xbeded8: SaveReg d0
    //     0xbeded8: str             d0, [SP, #-8]!
    // 0xbededc: r0 = lerp()
    //     0xbededc: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbedee0: add             SP, SP, #0x18
    // 0xbedee4: mov             x1, x0
    // 0xbedee8: ldr             x0, [fp, #0x20]
    // 0xbedeec: r17 = -632
    //     0xbedeec: mov             x17, #-0x278
    // 0xbedef0: str             x1, [fp, x17]
    // 0xbedef4: r17 = 335
    //     0xbedef4: mov             x17, #0x14f
    // 0xbedef8: ldr             w2, [x0, x17]
    // 0xbedefc: DecompressPointer r2
    //     0xbedefc: add             x2, x2, HEAP, lsl #32
    // 0xbedf00: ldr             x3, [fp, #0x18]
    // 0xbedf04: r17 = 335
    //     0xbedf04: mov             x17, #0x14f
    // 0xbedf08: ldr             w4, [x3, x17]
    // 0xbedf0c: DecompressPointer r4
    //     0xbedf0c: add             x4, x4, HEAP, lsl #32
    // 0xbedf10: stp             x4, x2, [SP, #-0x10]!
    // 0xbedf14: ldur            x16, [fp, #-0x48]
    // 0xbedf18: SaveReg r16
    //     0xbedf18: str             x16, [SP, #-8]!
    // 0xbedf1c: r0 = lerp()
    //     0xbedf1c: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbedf20: add             SP, SP, #0x18
    // 0xbedf24: mov             x1, x0
    // 0xbedf28: ldr             x0, [fp, #0x20]
    // 0xbedf2c: r17 = -640
    //     0xbedf2c: mov             x17, #-0x280
    // 0xbedf30: str             x1, [fp, x17]
    // 0xbedf34: r17 = 339
    //     0xbedf34: mov             x17, #0x153
    // 0xbedf38: ldr             w2, [x0, x17]
    // 0xbedf3c: DecompressPointer r2
    //     0xbedf3c: add             x2, x2, HEAP, lsl #32
    // 0xbedf40: cmp             w2, NULL
    // 0xbedf44: b.eq            #0xbee69c
    // 0xbedf48: ldr             x3, [fp, #0x18]
    // 0xbedf4c: r17 = 339
    //     0xbedf4c: mov             x17, #0x153
    // 0xbedf50: ldr             w4, [x3, x17]
    // 0xbedf54: DecompressPointer r4
    //     0xbedf54: add             x4, x4, HEAP, lsl #32
    // 0xbedf58: cmp             w4, NULL
    // 0xbedf5c: b.eq            #0xbee6a0
    // 0xbedf60: stp             x4, x2, [SP, #-0x10]!
    // 0xbedf64: ldur            x16, [fp, #-0x48]
    // 0xbedf68: SaveReg r16
    //     0xbedf68: str             x16, [SP, #-8]!
    // 0xbedf6c: r0 = lerp()
    //     0xbedf6c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbedf70: add             SP, SP, #0x18
    // 0xbedf74: mov             x1, x0
    // 0xbedf78: ldur            x0, [fp, #-0x10]
    // 0xbedf7c: r17 = -648
    //     0xbedf7c: mov             x17, #-0x288
    // 0xbedf80: str             x1, [fp, x17]
    // 0xbedf84: tbnz            w0, #4, #0xbedfa4
    // 0xbedf88: ldr             x0, [fp, #0x20]
    // 0xbedf8c: r17 = 347
    //     0xbedf8c: mov             x17, #0x15b
    // 0xbedf90: ldr             w2, [x0, x17]
    // 0xbedf94: DecompressPointer r2
    //     0xbedf94: add             x2, x2, HEAP, lsl #32
    // 0xbedf98: stur            x2, [fp, #-0x10]
    // 0xbedf9c: ldr             x2, [fp, #0x18]
    // 0xbedfa0: b               #0xbedfbc
    // 0xbedfa4: ldr             x0, [fp, #0x20]
    // 0xbedfa8: ldr             x2, [fp, #0x18]
    // 0xbedfac: r17 = 347
    //     0xbedfac: mov             x17, #0x15b
    // 0xbedfb0: ldr             w3, [x2, x17]
    // 0xbedfb4: DecompressPointer r3
    //     0xbedfb4: add             x3, x3, HEAP, lsl #32
    // 0xbedfb8: stur            x3, [fp, #-0x10]
    // 0xbedfbc: r17 = -512
    //     0xbedfbc: mov             x17, #-0x200
    // 0xbedfc0: ldr             x25, [fp, x17]
    // 0xbedfc4: r17 = -520
    //     0xbedfc4: mov             x17, #-0x208
    // 0xbedfc8: ldr             x24, [fp, x17]
    // 0xbedfcc: r17 = -528
    //     0xbedfcc: mov             x17, #-0x210
    // 0xbedfd0: ldr             x23, [fp, x17]
    // 0xbedfd4: r17 = -536
    //     0xbedfd4: mov             x17, #-0x218
    // 0xbedfd8: ldr             x20, [fp, x17]
    // 0xbedfdc: r17 = -544
    //     0xbedfdc: mov             x17, #-0x220
    // 0xbedfe0: ldr             x19, [fp, x17]
    // 0xbedfe4: r17 = -552
    //     0xbedfe4: mov             x17, #-0x228
    // 0xbedfe8: ldr             x14, [fp, x17]
    // 0xbedfec: r17 = -560
    //     0xbedfec: mov             x17, #-0x230
    // 0xbedff0: ldr             x13, [fp, x17]
    // 0xbedff4: r17 = -568
    //     0xbedff4: mov             x17, #-0x238
    // 0xbedff8: ldr             x12, [fp, x17]
    // 0xbedffc: r17 = -576
    //     0xbedffc: mov             x17, #-0x240
    // 0xbee000: ldr             x11, [fp, x17]
    // 0xbee004: r17 = -584
    //     0xbee004: mov             x17, #-0x248
    // 0xbee008: ldr             x10, [fp, x17]
    // 0xbee00c: r17 = -592
    //     0xbee00c: mov             x17, #-0x250
    // 0xbee010: ldr             x9, [fp, x17]
    // 0xbee014: r17 = -600
    //     0xbee014: mov             x17, #-0x258
    // 0xbee018: ldr             x8, [fp, x17]
    // 0xbee01c: r17 = -608
    //     0xbee01c: mov             x17, #-0x260
    // 0xbee020: ldr             x7, [fp, x17]
    // 0xbee024: r17 = -624
    //     0xbee024: mov             x17, #-0x270
    // 0xbee028: ldr             x5, [fp, x17]
    // 0xbee02c: r17 = -616
    //     0xbee02c: mov             x17, #-0x268
    // 0xbee030: ldr             x6, [fp, x17]
    // 0xbee034: r17 = -632
    //     0xbee034: mov             x17, #-0x278
    // 0xbee038: ldr             x4, [fp, x17]
    // 0xbee03c: r17 = -640
    //     0xbee03c: mov             x17, #-0x280
    // 0xbee040: ldr             x3, [fp, x17]
    // 0xbee044: r17 = 363
    //     0xbee044: mov             x17, #0x16b
    // 0xbee048: ldr             w1, [x0, x17]
    // 0xbee04c: DecompressPointer r1
    //     0xbee04c: add             x1, x1, HEAP, lsl #32
    // 0xbee050: cmp             w1, NULL
    // 0xbee054: b.eq            #0xbee6a4
    // 0xbee058: r17 = 363
    //     0xbee058: mov             x17, #0x16b
    // 0xbee05c: ldr             w0, [x2, x17]
    // 0xbee060: DecompressPointer r0
    //     0xbee060: add             x0, x0, HEAP, lsl #32
    // 0xbee064: cmp             w0, NULL
    // 0xbee068: b.eq            #0xbee6a8
    // 0xbee06c: stp             x0, x1, [SP, #-0x10]!
    // 0xbee070: ldur            x16, [fp, #-0x48]
    // 0xbee074: SaveReg r16
    //     0xbee074: str             x16, [SP, #-8]!
    // 0xbee078: r0 = lerp()
    //     0xbee078: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee07c: add             SP, SP, #0x18
    // 0xbee080: mov             x1, x0
    // 0xbee084: ldr             x0, [fp, #0x20]
    // 0xbee088: r17 = -656
    //     0xbee088: mov             x17, #-0x290
    // 0xbee08c: str             x1, [fp, x17]
    // 0xbee090: LoadField: r2 = r0->field_77
    //     0xbee090: ldur            w2, [x0, #0x77]
    // 0xbee094: DecompressPointer r2
    //     0xbee094: add             x2, x2, HEAP, lsl #32
    // 0xbee098: cmp             w2, NULL
    // 0xbee09c: b.eq            #0xbee6ac
    // 0xbee0a0: ldr             x3, [fp, #0x18]
    // 0xbee0a4: LoadField: r4 = r3->field_77
    //     0xbee0a4: ldur            w4, [x3, #0x77]
    // 0xbee0a8: DecompressPointer r4
    //     0xbee0a8: add             x4, x4, HEAP, lsl #32
    // 0xbee0ac: cmp             w4, NULL
    // 0xbee0b0: b.eq            #0xbee6b0
    // 0xbee0b4: stp             x4, x2, [SP, #-0x10]!
    // 0xbee0b8: ldur            x16, [fp, #-0x48]
    // 0xbee0bc: SaveReg r16
    //     0xbee0bc: str             x16, [SP, #-8]!
    // 0xbee0c0: r0 = lerp()
    //     0xbee0c0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee0c4: add             SP, SP, #0x18
    // 0xbee0c8: mov             x1, x0
    // 0xbee0cc: ldr             x0, [fp, #0x20]
    // 0xbee0d0: r17 = -664
    //     0xbee0d0: mov             x17, #-0x298
    // 0xbee0d4: str             x1, [fp, x17]
    // 0xbee0d8: r17 = 355
    //     0xbee0d8: mov             x17, #0x163
    // 0xbee0dc: ldr             w2, [x0, x17]
    // 0xbee0e0: DecompressPointer r2
    //     0xbee0e0: add             x2, x2, HEAP, lsl #32
    // 0xbee0e4: cmp             w2, NULL
    // 0xbee0e8: b.eq            #0xbee6b4
    // 0xbee0ec: ldr             x3, [fp, #0x18]
    // 0xbee0f0: r17 = 355
    //     0xbee0f0: mov             x17, #0x163
    // 0xbee0f4: ldr             w4, [x3, x17]
    // 0xbee0f8: DecompressPointer r4
    //     0xbee0f8: add             x4, x4, HEAP, lsl #32
    // 0xbee0fc: cmp             w4, NULL
    // 0xbee100: b.eq            #0xbee6b8
    // 0xbee104: stp             x4, x2, [SP, #-0x10]!
    // 0xbee108: ldur            x16, [fp, #-0x48]
    // 0xbee10c: SaveReg r16
    //     0xbee10c: str             x16, [SP, #-8]!
    // 0xbee110: r0 = lerp()
    //     0xbee110: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee114: add             SP, SP, #0x18
    // 0xbee118: mov             x1, x0
    // 0xbee11c: ldr             x0, [fp, #0x20]
    // 0xbee120: r17 = -672
    //     0xbee120: mov             x17, #-0x2a0
    // 0xbee124: str             x1, [fp, x17]
    // 0xbee128: r17 = 359
    //     0xbee128: mov             x17, #0x167
    // 0xbee12c: ldr             w2, [x0, x17]
    // 0xbee130: DecompressPointer r2
    //     0xbee130: add             x2, x2, HEAP, lsl #32
    // 0xbee134: cmp             w2, NULL
    // 0xbee138: b.eq            #0xbee6bc
    // 0xbee13c: ldr             x3, [fp, #0x18]
    // 0xbee140: r17 = 359
    //     0xbee140: mov             x17, #0x167
    // 0xbee144: ldr             w4, [x3, x17]
    // 0xbee148: DecompressPointer r4
    //     0xbee148: add             x4, x4, HEAP, lsl #32
    // 0xbee14c: cmp             w4, NULL
    // 0xbee150: b.eq            #0xbee6c0
    // 0xbee154: stp             x4, x2, [SP, #-0x10]!
    // 0xbee158: ldur            x16, [fp, #-0x48]
    // 0xbee15c: SaveReg r16
    //     0xbee15c: str             x16, [SP, #-8]!
    // 0xbee160: r0 = lerp()
    //     0xbee160: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee164: add             SP, SP, #0x18
    // 0xbee168: mov             x1, x0
    // 0xbee16c: ldr             x0, [fp, #0x20]
    // 0xbee170: r17 = -680
    //     0xbee170: mov             x17, #-0x2a8
    // 0xbee174: str             x1, [fp, x17]
    // 0xbee178: LoadField: r2 = r0->field_33
    //     0xbee178: ldur            w2, [x0, #0x33]
    // 0xbee17c: DecompressPointer r2
    //     0xbee17c: add             x2, x2, HEAP, lsl #32
    // 0xbee180: cmp             w2, NULL
    // 0xbee184: b.eq            #0xbee6c4
    // 0xbee188: ldr             x0, [fp, #0x18]
    // 0xbee18c: LoadField: r3 = r0->field_33
    //     0xbee18c: ldur            w3, [x0, #0x33]
    // 0xbee190: DecompressPointer r3
    //     0xbee190: add             x3, x3, HEAP, lsl #32
    // 0xbee194: cmp             w3, NULL
    // 0xbee198: b.eq            #0xbee6c8
    // 0xbee19c: stp             x3, x2, [SP, #-0x10]!
    // 0xbee1a0: ldur            x16, [fp, #-0x48]
    // 0xbee1a4: SaveReg r16
    //     0xbee1a4: str             x16, [SP, #-8]!
    // 0xbee1a8: r0 = lerp()
    //     0xbee1a8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee1ac: add             SP, SP, #0x18
    // 0xbee1b0: stur            x0, [fp, #-0x48]
    // 0xbee1b4: r0 = ThemeData()
    //     0xbee1b4: bl              #0x6cd128  ; AllocateThemeDataStub -> ThemeData (size=0x170)
    // 0xbee1b8: ldur            x1, [fp, #-8]
    // 0xbee1bc: StoreField: r0->field_7 = r1
    //     0xbee1bc: stur            w1, [x0, #7]
    // 0xbee1c0: ldur            x1, [fp, #-0x28]
    // 0xbee1c4: StoreField: r0->field_f = r1
    //     0xbee1c4: stur            w1, [x0, #0xf]
    // 0xbee1c8: r1 = Instance_InputDecorationTheme
    //     0xbee1c8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd008] Obj!InputDecorationTheme@b48581
    //     0xbee1cc: ldr             x1, [x1, #8]
    // 0xbee1d0: StoreField: r0->field_13 = r1
    //     0xbee1d0: stur            w1, [x0, #0x13]
    // 0xbee1d4: ldur            x1, [fp, #-0x20]
    // 0xbee1d8: StoreField: r0->field_17 = r1
    //     0xbee1d8: stur            w1, [x0, #0x17]
    // 0xbee1dc: r1 = Instance_PageTransitionsTheme
    //     0xbee1dc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd010] Obj!PageTransitionsTheme@b3ceb1
    //     0xbee1e0: ldr             x1, [x1, #0x10]
    // 0xbee1e4: StoreField: r0->field_1b = r1
    //     0xbee1e4: stur            w1, [x0, #0x1b]
    // 0xbee1e8: ldur            x1, [fp, #-0x18]
    // 0xbee1ec: StoreField: r0->field_1f = r1
    //     0xbee1ec: stur            w1, [x0, #0x1f]
    // 0xbee1f0: ldur            x1, [fp, #-0x40]
    // 0xbee1f4: StoreField: r0->field_23 = r1
    //     0xbee1f4: stur            w1, [x0, #0x23]
    // 0xbee1f8: ldur            x1, [fp, #-0x38]
    // 0xbee1fc: StoreField: r0->field_27 = r1
    //     0xbee1fc: stur            w1, [x0, #0x27]
    // 0xbee200: ldur            x1, [fp, #-0x30]
    // 0xbee204: StoreField: r0->field_2b = r1
    //     0xbee204: stur            w1, [x0, #0x2b]
    // 0xbee208: ldur            x1, [fp, #-0x50]
    // 0xbee20c: StoreField: r0->field_2f = r1
    //     0xbee20c: stur            w1, [x0, #0x2f]
    // 0xbee210: ldur            x1, [fp, #-0x58]
    // 0xbee214: StoreField: r0->field_37 = r1
    //     0xbee214: stur            w1, [x0, #0x37]
    // 0xbee218: ldur            x1, [fp, #-0x60]
    // 0xbee21c: StoreField: r0->field_3b = r1
    //     0xbee21c: stur            w1, [x0, #0x3b]
    // 0xbee220: ldur            x1, [fp, #-0x68]
    // 0xbee224: StoreField: r0->field_3f = r1
    //     0xbee224: stur            w1, [x0, #0x3f]
    // 0xbee228: ldur            x1, [fp, #-0x70]
    // 0xbee22c: StoreField: r0->field_43 = r1
    //     0xbee22c: stur            w1, [x0, #0x43]
    // 0xbee230: ldur            x1, [fp, #-0x78]
    // 0xbee234: StoreField: r0->field_47 = r1
    //     0xbee234: stur            w1, [x0, #0x47]
    // 0xbee238: ldur            x1, [fp, #-0x80]
    // 0xbee23c: StoreField: r0->field_4b = r1
    //     0xbee23c: stur            w1, [x0, #0x4b]
    // 0xbee240: ldur            x1, [fp, #-0x88]
    // 0xbee244: StoreField: r0->field_4f = r1
    //     0xbee244: stur            w1, [x0, #0x4f]
    // 0xbee248: ldur            x1, [fp, #-0x90]
    // 0xbee24c: StoreField: r0->field_53 = r1
    //     0xbee24c: stur            w1, [x0, #0x53]
    // 0xbee250: ldur            x1, [fp, #-0x98]
    // 0xbee254: StoreField: r0->field_57 = r1
    //     0xbee254: stur            w1, [x0, #0x57]
    // 0xbee258: ldur            x1, [fp, #-0xa0]
    // 0xbee25c: StoreField: r0->field_5b = r1
    //     0xbee25c: stur            w1, [x0, #0x5b]
    // 0xbee260: ldur            x1, [fp, #-0xa8]
    // 0xbee264: StoreField: r0->field_5f = r1
    //     0xbee264: stur            w1, [x0, #0x5f]
    // 0xbee268: ldur            x1, [fp, #-0xb0]
    // 0xbee26c: StoreField: r0->field_63 = r1
    //     0xbee26c: stur            w1, [x0, #0x63]
    // 0xbee270: ldur            x1, [fp, #-0xb8]
    // 0xbee274: StoreField: r0->field_67 = r1
    //     0xbee274: stur            w1, [x0, #0x67]
    // 0xbee278: ldur            x1, [fp, #-0xc0]
    // 0xbee27c: StoreField: r0->field_6b = r1
    //     0xbee27c: stur            w1, [x0, #0x6b]
    // 0xbee280: ldur            x1, [fp, #-0xc8]
    // 0xbee284: StoreField: r0->field_6f = r1
    //     0xbee284: stur            w1, [x0, #0x6f]
    // 0xbee288: ldur            x1, [fp, #-0xd0]
    // 0xbee28c: StoreField: r0->field_73 = r1
    //     0xbee28c: stur            w1, [x0, #0x73]
    // 0xbee290: ldur            x1, [fp, #-0xd8]
    // 0xbee294: StoreField: r0->field_7b = r1
    //     0xbee294: stur            w1, [x0, #0x7b]
    // 0xbee298: ldur            x1, [fp, #-0xe0]
    // 0xbee29c: StoreField: r0->field_7f = r1
    //     0xbee29c: stur            w1, [x0, #0x7f]
    // 0xbee2a0: ldur            x1, [fp, #-0xe8]
    // 0xbee2a4: StoreField: r0->field_83 = r1
    //     0xbee2a4: stur            w1, [x0, #0x83]
    // 0xbee2a8: ldur            x1, [fp, #-0xf0]
    // 0xbee2ac: StoreField: r0->field_87 = r1
    //     0xbee2ac: stur            w1, [x0, #0x87]
    // 0xbee2b0: ldur            x1, [fp, #-0xf8]
    // 0xbee2b4: StoreField: r0->field_8b = r1
    //     0xbee2b4: stur            w1, [x0, #0x8b]
    // 0xbee2b8: ldur            x1, [fp, #-0x100]
    // 0xbee2bc: StoreField: r0->field_8f = r1
    //     0xbee2bc: stur            w1, [x0, #0x8f]
    // 0xbee2c0: r17 = -264
    //     0xbee2c0: mov             x17, #-0x108
    // 0xbee2c4: ldr             x1, [fp, x17]
    // 0xbee2c8: StoreField: r0->field_93 = r1
    //     0xbee2c8: stur            w1, [x0, #0x93]
    // 0xbee2cc: r17 = -272
    //     0xbee2cc: mov             x17, #-0x110
    // 0xbee2d0: ldr             x1, [fp, x17]
    // 0xbee2d4: StoreField: r0->field_97 = r1
    //     0xbee2d4: stur            w1, [x0, #0x97]
    // 0xbee2d8: r17 = -280
    //     0xbee2d8: mov             x17, #-0x118
    // 0xbee2dc: ldr             x1, [fp, x17]
    // 0xbee2e0: StoreField: r0->field_9b = r1
    //     0xbee2e0: stur            w1, [x0, #0x9b]
    // 0xbee2e4: r17 = -288
    //     0xbee2e4: mov             x17, #-0x120
    // 0xbee2e8: ldr             x1, [fp, x17]
    // 0xbee2ec: StoreField: r0->field_9f = r1
    //     0xbee2ec: stur            w1, [x0, #0x9f]
    // 0xbee2f0: r17 = -296
    //     0xbee2f0: mov             x17, #-0x128
    // 0xbee2f4: ldr             x1, [fp, x17]
    // 0xbee2f8: StoreField: r0->field_a3 = r1
    //     0xbee2f8: stur            w1, [x0, #0xa3]
    // 0xbee2fc: r17 = -304
    //     0xbee2fc: mov             x17, #-0x130
    // 0xbee300: ldr             x1, [fp, x17]
    // 0xbee304: StoreField: r0->field_a7 = r1
    //     0xbee304: stur            w1, [x0, #0xa7]
    // 0xbee308: r17 = -312
    //     0xbee308: mov             x17, #-0x138
    // 0xbee30c: ldr             x1, [fp, x17]
    // 0xbee310: StoreField: r0->field_ab = r1
    //     0xbee310: stur            w1, [x0, #0xab]
    // 0xbee314: r17 = -320
    //     0xbee314: mov             x17, #-0x140
    // 0xbee318: ldr             x1, [fp, x17]
    // 0xbee31c: StoreField: r0->field_af = r1
    //     0xbee31c: stur            w1, [x0, #0xaf]
    // 0xbee320: r17 = -336
    //     0xbee320: mov             x17, #-0x150
    // 0xbee324: ldr             x1, [fp, x17]
    // 0xbee328: StoreField: r0->field_b3 = r1
    //     0xbee328: stur            w1, [x0, #0xb3]
    // 0xbee32c: r17 = -328
    //     0xbee32c: mov             x17, #-0x148
    // 0xbee330: ldr             x1, [fp, x17]
    // 0xbee334: StoreField: r0->field_b7 = r1
    //     0xbee334: stur            w1, [x0, #0xb7]
    // 0xbee338: r17 = -344
    //     0xbee338: mov             x17, #-0x158
    // 0xbee33c: ldr             x1, [fp, x17]
    // 0xbee340: StoreField: r0->field_bb = r1
    //     0xbee340: stur            w1, [x0, #0xbb]
    // 0xbee344: r17 = -352
    //     0xbee344: mov             x17, #-0x160
    // 0xbee348: ldr             x1, [fp, x17]
    // 0xbee34c: StoreField: r0->field_bf = r1
    //     0xbee34c: stur            w1, [x0, #0xbf]
    // 0xbee350: r17 = -360
    //     0xbee350: mov             x17, #-0x168
    // 0xbee354: ldr             x1, [fp, x17]
    // 0xbee358: StoreField: r0->field_c3 = r1
    //     0xbee358: stur            w1, [x0, #0xc3]
    // 0xbee35c: r17 = -368
    //     0xbee35c: mov             x17, #-0x170
    // 0xbee360: ldr             x1, [fp, x17]
    // 0xbee364: StoreField: r0->field_c7 = r1
    //     0xbee364: stur            w1, [x0, #0xc7]
    // 0xbee368: r17 = -376
    //     0xbee368: mov             x17, #-0x178
    // 0xbee36c: ldr             x1, [fp, x17]
    // 0xbee370: StoreField: r0->field_cb = r1
    //     0xbee370: stur            w1, [x0, #0xcb]
    // 0xbee374: r17 = -384
    //     0xbee374: mov             x17, #-0x180
    // 0xbee378: ldr             x1, [fp, x17]
    // 0xbee37c: StoreField: r0->field_cf = r1
    //     0xbee37c: stur            w1, [x0, #0xcf]
    // 0xbee380: r17 = -392
    //     0xbee380: mov             x17, #-0x188
    // 0xbee384: ldr             x1, [fp, x17]
    // 0xbee388: StoreField: r0->field_d3 = r1
    //     0xbee388: stur            w1, [x0, #0xd3]
    // 0xbee38c: r17 = -400
    //     0xbee38c: mov             x17, #-0x190
    // 0xbee390: ldr             x1, [fp, x17]
    // 0xbee394: StoreField: r0->field_d7 = r1
    //     0xbee394: stur            w1, [x0, #0xd7]
    // 0xbee398: r17 = -408
    //     0xbee398: mov             x17, #-0x198
    // 0xbee39c: ldr             x1, [fp, x17]
    // 0xbee3a0: StoreField: r0->field_db = r1
    //     0xbee3a0: stur            w1, [x0, #0xdb]
    // 0xbee3a4: r17 = -416
    //     0xbee3a4: mov             x17, #-0x1a0
    // 0xbee3a8: ldr             x1, [fp, x17]
    // 0xbee3ac: StoreField: r0->field_df = r1
    //     0xbee3ac: stur            w1, [x0, #0xdf]
    // 0xbee3b0: r17 = -424
    //     0xbee3b0: mov             x17, #-0x1a8
    // 0xbee3b4: ldr             x1, [fp, x17]
    // 0xbee3b8: StoreField: r0->field_e3 = r1
    //     0xbee3b8: stur            w1, [x0, #0xe3]
    // 0xbee3bc: r17 = -432
    //     0xbee3bc: mov             x17, #-0x1b0
    // 0xbee3c0: ldr             x1, [fp, x17]
    // 0xbee3c4: StoreField: r0->field_e7 = r1
    //     0xbee3c4: stur            w1, [x0, #0xe7]
    // 0xbee3c8: r17 = -440
    //     0xbee3c8: mov             x17, #-0x1b8
    // 0xbee3cc: ldr             x1, [fp, x17]
    // 0xbee3d0: StoreField: r0->field_eb = r1
    //     0xbee3d0: stur            w1, [x0, #0xeb]
    // 0xbee3d4: r17 = -448
    //     0xbee3d4: mov             x17, #-0x1c0
    // 0xbee3d8: ldr             x1, [fp, x17]
    // 0xbee3dc: StoreField: r0->field_ef = r1
    //     0xbee3dc: stur            w1, [x0, #0xef]
    // 0xbee3e0: r17 = -456
    //     0xbee3e0: mov             x17, #-0x1c8
    // 0xbee3e4: ldr             x1, [fp, x17]
    // 0xbee3e8: StoreField: r0->field_f3 = r1
    //     0xbee3e8: stur            w1, [x0, #0xf3]
    // 0xbee3ec: r17 = -464
    //     0xbee3ec: mov             x17, #-0x1d0
    // 0xbee3f0: ldr             x1, [fp, x17]
    // 0xbee3f4: StoreField: r0->field_f7 = r1
    //     0xbee3f4: stur            w1, [x0, #0xf7]
    // 0xbee3f8: r17 = -472
    //     0xbee3f8: mov             x17, #-0x1d8
    // 0xbee3fc: ldr             x1, [fp, x17]
    // 0xbee400: StoreField: r0->field_fb = r1
    //     0xbee400: stur            w1, [x0, #0xfb]
    // 0xbee404: r17 = -480
    //     0xbee404: mov             x17, #-0x1e0
    // 0xbee408: ldr             x1, [fp, x17]
    // 0xbee40c: StoreField: r0->field_ff = r1
    //     0xbee40c: stur            w1, [x0, #0xff]
    // 0xbee410: r17 = -488
    //     0xbee410: mov             x17, #-0x1e8
    // 0xbee414: ldr             x1, [fp, x17]
    // 0xbee418: add             x16, x0, #0x103
    // 0xbee41c: str             w1, [x16]
    // 0xbee420: r17 = -496
    //     0xbee420: mov             x17, #-0x1f0
    // 0xbee424: ldr             x1, [fp, x17]
    // 0xbee428: add             x16, x0, #0x107
    // 0xbee42c: str             w1, [x16]
    // 0xbee430: r17 = -504
    //     0xbee430: mov             x17, #-0x1f8
    // 0xbee434: ldr             x1, [fp, x17]
    // 0xbee438: add             x16, x0, #0x10b
    // 0xbee43c: str             w1, [x16]
    // 0xbee440: r17 = -512
    //     0xbee440: mov             x17, #-0x200
    // 0xbee444: ldr             x1, [fp, x17]
    // 0xbee448: add             x16, x0, #0x10f
    // 0xbee44c: str             w1, [x16]
    // 0xbee450: r17 = -520
    //     0xbee450: mov             x17, #-0x208
    // 0xbee454: ldr             x1, [fp, x17]
    // 0xbee458: add             x16, x0, #0x113
    // 0xbee45c: str             w1, [x16]
    // 0xbee460: r17 = -528
    //     0xbee460: mov             x17, #-0x210
    // 0xbee464: ldr             x1, [fp, x17]
    // 0xbee468: add             x16, x0, #0x117
    // 0xbee46c: str             w1, [x16]
    // 0xbee470: r17 = -536
    //     0xbee470: mov             x17, #-0x218
    // 0xbee474: ldr             x1, [fp, x17]
    // 0xbee478: add             x16, x0, #0x11b
    // 0xbee47c: str             w1, [x16]
    // 0xbee480: r17 = -544
    //     0xbee480: mov             x17, #-0x220
    // 0xbee484: ldr             x1, [fp, x17]
    // 0xbee488: add             x16, x0, #0x11f
    // 0xbee48c: str             w1, [x16]
    // 0xbee490: r17 = -552
    //     0xbee490: mov             x17, #-0x228
    // 0xbee494: ldr             x1, [fp, x17]
    // 0xbee498: add             x16, x0, #0x123
    // 0xbee49c: str             w1, [x16]
    // 0xbee4a0: r17 = -560
    //     0xbee4a0: mov             x17, #-0x230
    // 0xbee4a4: ldr             x1, [fp, x17]
    // 0xbee4a8: add             x16, x0, #0x127
    // 0xbee4ac: str             w1, [x16]
    // 0xbee4b0: r17 = -568
    //     0xbee4b0: mov             x17, #-0x238
    // 0xbee4b4: ldr             x1, [fp, x17]
    // 0xbee4b8: add             x16, x0, #0x12b
    // 0xbee4bc: str             w1, [x16]
    // 0xbee4c0: r17 = -576
    //     0xbee4c0: mov             x17, #-0x240
    // 0xbee4c4: ldr             x1, [fp, x17]
    // 0xbee4c8: add             x16, x0, #0x12f
    // 0xbee4cc: str             w1, [x16]
    // 0xbee4d0: r17 = -584
    //     0xbee4d0: mov             x17, #-0x248
    // 0xbee4d4: ldr             x1, [fp, x17]
    // 0xbee4d8: add             x16, x0, #0x133
    // 0xbee4dc: str             w1, [x16]
    // 0xbee4e0: r17 = -592
    //     0xbee4e0: mov             x17, #-0x250
    // 0xbee4e4: ldr             x1, [fp, x17]
    // 0xbee4e8: add             x16, x0, #0x137
    // 0xbee4ec: str             w1, [x16]
    // 0xbee4f0: r17 = -600
    //     0xbee4f0: mov             x17, #-0x258
    // 0xbee4f4: ldr             x1, [fp, x17]
    // 0xbee4f8: add             x16, x0, #0x13b
    // 0xbee4fc: str             w1, [x16]
    // 0xbee500: r17 = -608
    //     0xbee500: mov             x17, #-0x260
    // 0xbee504: ldr             x1, [fp, x17]
    // 0xbee508: add             x16, x0, #0x13f
    // 0xbee50c: str             w1, [x16]
    // 0xbee510: r17 = -624
    //     0xbee510: mov             x17, #-0x270
    // 0xbee514: ldr             x1, [fp, x17]
    // 0xbee518: add             x16, x0, #0x143
    // 0xbee51c: str             w1, [x16]
    // 0xbee520: r17 = -616
    //     0xbee520: mov             x17, #-0x268
    // 0xbee524: ldr             x1, [fp, x17]
    // 0xbee528: add             x16, x0, #0x147
    // 0xbee52c: str             w1, [x16]
    // 0xbee530: r17 = -632
    //     0xbee530: mov             x17, #-0x278
    // 0xbee534: ldr             x1, [fp, x17]
    // 0xbee538: add             x16, x0, #0x14b
    // 0xbee53c: str             w1, [x16]
    // 0xbee540: r17 = -640
    //     0xbee540: mov             x17, #-0x280
    // 0xbee544: ldr             x1, [fp, x17]
    // 0xbee548: add             x16, x0, #0x14f
    // 0xbee54c: str             w1, [x16]
    // 0xbee550: r17 = -648
    //     0xbee550: mov             x17, #-0x288
    // 0xbee554: ldr             x1, [fp, x17]
    // 0xbee558: add             x16, x0, #0x153
    // 0xbee55c: str             w1, [x16]
    // 0xbee560: r1 = true
    //     0xbee560: add             x1, NULL, #0x20  ; true
    // 0xbee564: add             x16, x0, #0x157
    // 0xbee568: str             w1, [x16]
    // 0xbee56c: ldur            x1, [fp, #-0x10]
    // 0xbee570: add             x16, x0, #0x15b
    // 0xbee574: str             w1, [x16]
    // 0xbee578: r17 = -656
    //     0xbee578: mov             x17, #-0x290
    // 0xbee57c: ldr             x1, [fp, x17]
    // 0xbee580: add             x16, x0, #0x16b
    // 0xbee584: str             w1, [x16]
    // 0xbee588: r17 = -664
    //     0xbee588: mov             x17, #-0x298
    // 0xbee58c: ldr             x1, [fp, x17]
    // 0xbee590: StoreField: r0->field_77 = r1
    //     0xbee590: stur            w1, [x0, #0x77]
    // 0xbee594: r17 = -672
    //     0xbee594: mov             x17, #-0x2a0
    // 0xbee598: ldr             x1, [fp, x17]
    // 0xbee59c: add             x16, x0, #0x163
    // 0xbee5a0: str             w1, [x16]
    // 0xbee5a4: r17 = -680
    //     0xbee5a4: mov             x17, #-0x2a8
    // 0xbee5a8: ldr             x1, [fp, x17]
    // 0xbee5ac: add             x16, x0, #0x167
    // 0xbee5b0: str             w1, [x16]
    // 0xbee5b4: ldur            x1, [fp, #-0x48]
    // 0xbee5b8: StoreField: r0->field_33 = r1
    //     0xbee5b8: stur            w1, [x0, #0x33]
    // 0xbee5bc: LeaveFrame
    //     0xbee5bc: mov             SP, fp
    //     0xbee5c0: ldp             fp, lr, [SP], #0x10
    // 0xbee5c4: ret
    //     0xbee5c4: ret             
    // 0xbee5c8: r0 = StackOverflowSharedWithFPURegs()
    //     0xbee5c8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbee5cc: b               #0xbecd78
    // 0xbee5d0: SaveReg d0
    //     0xbee5d0: str             q0, [SP, #-0x10]!
    // 0xbee5d4: stp             x3, x4, [SP, #-0x10]!
    // 0xbee5d8: stp             x1, x2, [SP, #-0x10]!
    // 0xbee5dc: SaveReg r0
    //     0xbee5dc: str             x0, [SP, #-8]!
    // 0xbee5e0: r0 = AllocateDouble()
    //     0xbee5e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbee5e4: mov             x5, x0
    // 0xbee5e8: RestoreReg r0
    //     0xbee5e8: ldr             x0, [SP], #8
    // 0xbee5ec: ldp             x1, x2, [SP], #0x10
    // 0xbee5f0: ldp             x3, x4, [SP], #0x10
    // 0xbee5f4: RestoreReg d0
    //     0xbee5f4: ldr             q0, [SP], #0x10
    // 0xbee5f8: b               #0xbecf14
    // 0xbee5fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee5fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee600: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee604: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee608: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee608: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee60c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee60c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee610: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee614: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee614: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee618: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee618: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee61c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee61c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee620: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee624: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee624: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee628: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee628: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee62c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee62c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee630: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee634: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee634: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee638: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee638: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee63c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee63c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee640: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee644: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee648: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee648: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee64c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee64c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee650: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee650: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee654: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee654: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee658: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee658: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee65c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee65c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee660: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee660: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee664: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee664: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee668: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee668: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee66c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee66c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee670: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee670: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee674: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee674: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee678: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee678: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee67c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee67c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee680: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee680: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee684: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee688: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee688: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee68c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee68c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee690: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee694: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee698: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee698: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee69c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee69c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbee6c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee6c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _lerpThemeExtensions(/* No info */) {
    // ** addr: 0xbf87e0, size: 0x130
    // 0xbf87e0: EnterFrame
    //     0xbf87e0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf87e4: mov             fp, SP
    // 0xbf87e8: AllocStack(0x10)
    //     0xbf87e8: sub             SP, SP, #0x10
    // 0xbf87ec: CheckStackOverflow
    //     0xbf87ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf87f0: cmp             SP, x16
    //     0xbf87f4: b.ls            #0xbf8908
    // 0xbf87f8: r1 = 2
    //     0xbf87f8: mov             x1, #2
    // 0xbf87fc: r0 = AllocateContext()
    //     0xbf87fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xbf8800: mov             x3, x0
    // 0xbf8804: ldr             x0, [fp, #0x18]
    // 0xbf8808: stur            x3, [fp, #-0x10]
    // 0xbf880c: StoreField: r3->field_f = r0
    //     0xbf880c: stur            w0, [x3, #0xf]
    // 0xbf8810: ldr             x1, [fp, #0x10]
    // 0xbf8814: StoreField: r3->field_13 = r1
    //     0xbf8814: stur            w1, [x3, #0x13]
    // 0xbf8818: LoadField: r4 = r0->field_f
    //     0xbf8818: ldur            w4, [x0, #0xf]
    // 0xbf881c: DecompressPointer r4
    //     0xbf881c: add             x4, x4, HEAP, lsl #32
    // 0xbf8820: mov             x2, x3
    // 0xbf8824: stur            x4, [fp, #-8]
    // 0xbf8828: r1 = Function '<anonymous closure>': static.
    //     0xbf8828: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dbe0] AnonymousClosure: static (0xbf8b1c), in [package:flutter/src/material/theme_data.dart] ThemeData::_lerpThemeExtensions (0xbf87e0)
    //     0xbf882c: ldr             x1, [x1, #0xbe0]
    // 0xbf8830: r0 = AllocateClosure()
    //     0xbf8830: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbf8834: mov             x1, x0
    // 0xbf8838: ldur            x0, [fp, #-8]
    // 0xbf883c: r2 = LoadClassIdInstr(r0)
    //     0xbf883c: ldur            x2, [x0, #-1]
    //     0xbf8840: ubfx            x2, x2, #0xc, #0x14
    // 0xbf8844: r16 = <Object, ThemeExtension>
    //     0xbf8844: add             x16, PP, #0xd, lsl #12  ; [pp+0xd160] TypeArguments: <Object, ThemeExtension>
    //     0xbf8848: ldr             x16, [x16, #0x160]
    // 0xbf884c: stp             x0, x16, [SP, #-0x10]!
    // 0xbf8850: SaveReg r1
    //     0xbf8850: str             x1, [SP, #-8]!
    // 0xbf8854: mov             x0, x2
    // 0xbf8858: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xbf8858: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xbf885c: ldr             x4, [x4, #0x4d8]
    // 0xbf8860: r0 = GDT[cid_x0 + 0xc7a]()
    //     0xbf8860: add             lr, x0, #0xc7a
    //     0xbf8864: ldr             lr, [x21, lr, lsl #3]
    //     0xbf8868: blr             lr
    // 0xbf886c: add             SP, SP, #0x18
    // 0xbf8870: mov             x1, x0
    // 0xbf8874: ldur            x2, [fp, #-0x10]
    // 0xbf8878: stur            x1, [fp, #-8]
    // 0xbf887c: LoadField: r0 = r2->field_13
    //     0xbf887c: ldur            w0, [x2, #0x13]
    // 0xbf8880: DecompressPointer r0
    //     0xbf8880: add             x0, x0, HEAP, lsl #32
    // 0xbf8884: LoadField: r3 = r0->field_f
    //     0xbf8884: ldur            w3, [x0, #0xf]
    // 0xbf8888: DecompressPointer r3
    //     0xbf8888: add             x3, x3, HEAP, lsl #32
    // 0xbf888c: r0 = LoadClassIdInstr(r3)
    //     0xbf888c: ldur            x0, [x3, #-1]
    //     0xbf8890: ubfx            x0, x0, #0xc, #0x14
    // 0xbf8894: SaveReg r3
    //     0xbf8894: str             x3, [SP, #-8]!
    // 0xbf8898: r0 = GDT[cid_x0 + 0xd30]()
    //     0xbf8898: add             lr, x0, #0xd30
    //     0xbf889c: ldr             lr, [x21, lr, lsl #3]
    //     0xbf88a0: blr             lr
    // 0xbf88a4: add             SP, SP, #8
    // 0xbf88a8: ldur            x2, [fp, #-0x10]
    // 0xbf88ac: r1 = Function '<anonymous closure>': static.
    //     0xbf88ac: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dbe8] AnonymousClosure: static (0xbf8a7c), in [package:flutter/src/material/theme_data.dart] ThemeData::_lerpThemeExtensions (0xbf87e0)
    //     0xbf88b0: ldr             x1, [x1, #0xbe8]
    // 0xbf88b4: stur            x0, [fp, #-0x10]
    // 0xbf88b8: r0 = AllocateClosure()
    //     0xbf88b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbf88bc: mov             x1, x0
    // 0xbf88c0: ldur            x0, [fp, #-0x10]
    // 0xbf88c4: r2 = LoadClassIdInstr(r0)
    //     0xbf88c4: ldur            x2, [x0, #-1]
    //     0xbf88c8: ubfx            x2, x2, #0xc, #0x14
    // 0xbf88cc: stp             x1, x0, [SP, #-0x10]!
    // 0xbf88d0: mov             x0, x2
    // 0xbf88d4: r0 = GDT[cid_x0 + 0xd1da]()
    //     0xbf88d4: mov             x17, #0xd1da
    //     0xbf88d8: add             lr, x0, x17
    //     0xbf88dc: ldr             lr, [x21, lr, lsl #3]
    //     0xbf88e0: blr             lr
    // 0xbf88e4: add             SP, SP, #0x10
    // 0xbf88e8: ldur            x16, [fp, #-8]
    // 0xbf88ec: stp             x0, x16, [SP, #-0x10]!
    // 0xbf88f0: r0 = addEntries()
    //     0xbf88f0: bl              #0xbf8910  ; [dart:collection] __Map&_HashVMBase&MapMixin::addEntries
    // 0xbf88f4: add             SP, SP, #0x10
    // 0xbf88f8: ldur            x0, [fp, #-8]
    // 0xbf88fc: LeaveFrame
    //     0xbf88fc: mov             SP, fp
    //     0xbf8900: ldp             fp, lr, [SP], #0x10
    // 0xbf8904: ret
    //     0xbf8904: ret             
    // 0xbf8908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8908: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf890c: b               #0xbf87f8
  }
  [closure] static bool <anonymous closure>(dynamic, MapEntry<Object, ThemeExtension<dynamic>>) {
    // ** addr: 0xbf8a7c, size: 0xa0
    // 0xbf8a7c: EnterFrame
    //     0xbf8a7c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8a80: mov             fp, SP
    // 0xbf8a84: AllocStack(0x8)
    //     0xbf8a84: sub             SP, SP, #8
    // 0xbf8a88: SetupParameters()
    //     0xbf8a88: ldr             x0, [fp, #0x18]
    //     0xbf8a8c: ldur            w1, [x0, #0x17]
    //     0xbf8a90: add             x1, x1, HEAP, lsl #32
    // 0xbf8a94: CheckStackOverflow
    //     0xbf8a94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf8a98: cmp             SP, x16
    //     0xbf8a9c: b.ls            #0xbf8b14
    // 0xbf8aa0: LoadField: r0 = r1->field_f
    //     0xbf8aa0: ldur            w0, [x1, #0xf]
    // 0xbf8aa4: DecompressPointer r0
    //     0xbf8aa4: add             x0, x0, HEAP, lsl #32
    // 0xbf8aa8: LoadField: r1 = r0->field_f
    //     0xbf8aa8: ldur            w1, [x0, #0xf]
    // 0xbf8aac: DecompressPointer r1
    //     0xbf8aac: add             x1, x1, HEAP, lsl #32
    // 0xbf8ab0: ldr             x0, [fp, #0x10]
    // 0xbf8ab4: stur            x1, [fp, #-8]
    // 0xbf8ab8: r2 = LoadClassIdInstr(r0)
    //     0xbf8ab8: ldur            x2, [x0, #-1]
    //     0xbf8abc: ubfx            x2, x2, #0xc, #0x14
    // 0xbf8ac0: SaveReg r0
    //     0xbf8ac0: str             x0, [SP, #-8]!
    // 0xbf8ac4: mov             x0, x2
    // 0xbf8ac8: r0 = GDT[cid_x0 + -0xfba]()
    //     0xbf8ac8: sub             lr, x0, #0xfba
    //     0xbf8acc: ldr             lr, [x21, lr, lsl #3]
    //     0xbf8ad0: blr             lr
    // 0xbf8ad4: add             SP, SP, #8
    // 0xbf8ad8: mov             x1, x0
    // 0xbf8adc: ldur            x0, [fp, #-8]
    // 0xbf8ae0: r2 = LoadClassIdInstr(r0)
    //     0xbf8ae0: ldur            x2, [x0, #-1]
    //     0xbf8ae4: ubfx            x2, x2, #0xc, #0x14
    // 0xbf8ae8: stp             x1, x0, [SP, #-0x10]!
    // 0xbf8aec: mov             x0, x2
    // 0xbf8af0: r0 = GDT[cid_x0 + 0x579]()
    //     0xbf8af0: add             lr, x0, #0x579
    //     0xbf8af4: ldr             lr, [x21, lr, lsl #3]
    //     0xbf8af8: blr             lr
    // 0xbf8afc: add             SP, SP, #0x10
    // 0xbf8b00: eor             x1, x0, #0x10
    // 0xbf8b04: mov             x0, x1
    // 0xbf8b08: LeaveFrame
    //     0xbf8b08: mov             SP, fp
    //     0xbf8b0c: ldp             fp, lr, [SP], #0x10
    // 0xbf8b10: ret
    //     0xbf8b10: ret             
    // 0xbf8b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8b14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8b18: b               #0xbf8aa0
  }
  [closure] static MapEntry<Object, ThemeExtension<dynamic>> <anonymous closure>(dynamic, Object, ThemeExtension<dynamic>) {
    // ** addr: 0xbf8b1c, size: 0x88
    // 0xbf8b1c: EnterFrame
    //     0xbf8b1c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8b20: mov             fp, SP
    // 0xbf8b24: ldr             x0, [fp, #0x20]
    // 0xbf8b28: LoadField: r1 = r0->field_17
    //     0xbf8b28: ldur            w1, [x0, #0x17]
    // 0xbf8b2c: DecompressPointer r1
    //     0xbf8b2c: add             x1, x1, HEAP, lsl #32
    // 0xbf8b30: CheckStackOverflow
    //     0xbf8b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf8b34: cmp             SP, x16
    //     0xbf8b38: b.ls            #0xbf8b9c
    // 0xbf8b3c: LoadField: r0 = r1->field_13
    //     0xbf8b3c: ldur            w0, [x1, #0x13]
    // 0xbf8b40: DecompressPointer r0
    //     0xbf8b40: add             x0, x0, HEAP, lsl #32
    // 0xbf8b44: LoadField: r1 = r0->field_f
    //     0xbf8b44: ldur            w1, [x0, #0xf]
    // 0xbf8b48: DecompressPointer r1
    //     0xbf8b48: add             x1, x1, HEAP, lsl #32
    // 0xbf8b4c: r0 = LoadClassIdInstr(r1)
    //     0xbf8b4c: ldur            x0, [x1, #-1]
    //     0xbf8b50: ubfx            x0, x0, #0xc, #0x14
    // 0xbf8b54: ldr             x16, [fp, #0x18]
    // 0xbf8b58: stp             x16, x1, [SP, #-0x10]!
    // 0xbf8b5c: r0 = GDT[cid_x0 + -0xef]()
    //     0xbf8b5c: sub             lr, x0, #0xef
    //     0xbf8b60: ldr             lr, [x21, lr, lsl #3]
    //     0xbf8b64: blr             lr
    // 0xbf8b68: add             SP, SP, #0x10
    // 0xbf8b6c: ldr             x16, [fp, #0x10]
    // 0xbf8b70: stp             NULL, x16, [SP, #-0x10]!
    // 0xbf8b74: r4 = 0
    //     0xbf8b74: mov             x4, #0
    // 0xbf8b78: ldr             x0, [SP, #8]
    // 0xbf8b7c: r16 = UnlinkedCall_0x4aeefc
    //     0xbf8b7c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbf0] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0xbf8b80: add             x16, x16, #0xbf0
    // 0xbf8b84: ldp             x5, lr, [x16]
    // 0xbf8b88: blr             lr
    // 0xbf8b8c: add             SP, SP, #0x10
    // 0xbf8b90: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xbf8b90: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xbf8b94: r0 = Throw()
    //     0xbf8b94: bl              #0xd67e38  ; ThrowStub
    // 0xbf8b98: brk             #0
    // 0xbf8b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8b9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8ba0: b               #0xbf8b3c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc90550, size: 0x2384
    // 0xc90550: EnterFrame
    //     0xc90550: stp             fp, lr, [SP, #-0x10]!
    //     0xc90554: mov             fp, SP
    // 0xc90558: AllocStack(0x18)
    //     0xc90558: sub             SP, SP, #0x18
    // 0xc9055c: CheckStackOverflow
    //     0xc9055c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc90560: cmp             SP, x16
    //     0xc90564: b.ls            #0xc92894
    // 0xc90568: ldr             x1, [fp, #0x10]
    // 0xc9056c: cmp             w1, NULL
    // 0xc90570: b.ne            #0xc90584
    // 0xc90574: r0 = false
    //     0xc90574: add             x0, NULL, #0x30  ; false
    // 0xc90578: LeaveFrame
    //     0xc90578: mov             SP, fp
    //     0xc9057c: ldp             fp, lr, [SP], #0x10
    // 0xc90580: ret
    //     0xc90580: ret             
    // 0xc90584: r0 = 59
    //     0xc90584: mov             x0, #0x3b
    // 0xc90588: branchIfSmi(r1, 0xc90594)
    //     0xc90588: tbz             w1, #0, #0xc90594
    // 0xc9058c: r0 = LoadClassIdInstr(r1)
    //     0xc9058c: ldur            x0, [x1, #-1]
    //     0xc90590: ubfx            x0, x0, #0xc, #0x14
    // 0xc90594: SaveReg r1
    //     0xc90594: str             x1, [SP, #-8]!
    // 0xc90598: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc90598: mov             x17, #0x57c5
    //     0xc9059c: add             lr, x0, x17
    //     0xc905a0: ldr             lr, [x21, lr, lsl #3]
    //     0xc905a4: blr             lr
    // 0xc905a8: add             SP, SP, #8
    // 0xc905ac: r1 = LoadClassIdInstr(r0)
    //     0xc905ac: ldur            x1, [x0, #-1]
    //     0xc905b0: ubfx            x1, x1, #0xc, #0x14
    // 0xc905b4: r16 = ThemeData
    //     0xc905b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf08] Type: ThemeData
    //     0xc905b8: ldr             x16, [x16, #0xf08]
    // 0xc905bc: stp             x16, x0, [SP, #-0x10]!
    // 0xc905c0: mov             x0, x1
    // 0xc905c4: mov             lr, x0
    // 0xc905c8: ldr             lr, [x21, lr, lsl #3]
    // 0xc905cc: blr             lr
    // 0xc905d0: add             SP, SP, #0x10
    // 0xc905d4: tbz             w0, #4, #0xc905e8
    // 0xc905d8: r0 = false
    //     0xc905d8: add             x0, NULL, #0x30  ; false
    // 0xc905dc: LeaveFrame
    //     0xc905dc: mov             SP, fp
    //     0xc905e0: ldp             fp, lr, [SP], #0x10
    // 0xc905e4: ret
    //     0xc905e4: ret             
    // 0xc905e8: ldr             x0, [fp, #0x10]
    // 0xc905ec: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc905ec: mov             x1, #0x76
    //     0xc905f0: tbz             w0, #0, #0xc90600
    //     0xc905f4: ldur            x1, [x0, #-1]
    //     0xc905f8: ubfx            x1, x1, #0xc, #0x14
    //     0xc905fc: lsl             x1, x1, #1
    // 0xc90600: r17 = 5436
    //     0xc90600: mov             x17, #0x153c
    // 0xc90604: cmp             w1, w17
    // 0xc90608: b.ne            #0xc92884
    // 0xc9060c: ldr             x1, [fp, #0x18]
    // 0xc90610: LoadField: r2 = r0->field_7
    //     0xc90610: ldur            w2, [x0, #7]
    // 0xc90614: DecompressPointer r2
    //     0xc90614: add             x2, x2, HEAP, lsl #32
    // 0xc90618: LoadField: r3 = r1->field_7
    //     0xc90618: ldur            w3, [x1, #7]
    // 0xc9061c: DecompressPointer r3
    //     0xc9061c: add             x3, x3, HEAP, lsl #32
    // 0xc90620: cmp             w2, w3
    // 0xc90624: b.ne            #0xc92884
    // 0xc90628: LoadField: r2 = r0->field_f
    //     0xc90628: ldur            w2, [x0, #0xf]
    // 0xc9062c: DecompressPointer r2
    //     0xc9062c: add             x2, x2, HEAP, lsl #32
    // 0xc90630: LoadField: r3 = r1->field_f
    //     0xc90630: ldur            w3, [x1, #0xf]
    // 0xc90634: DecompressPointer r3
    //     0xc90634: add             x3, x3, HEAP, lsl #32
    // 0xc90638: r16 = <Object, ThemeExtension>
    //     0xc90638: add             x16, PP, #0xd, lsl #12  ; [pp+0xd160] TypeArguments: <Object, ThemeExtension>
    //     0xc9063c: ldr             x16, [x16, #0x160]
    // 0xc90640: stp             x2, x16, [SP, #-0x10]!
    // 0xc90644: SaveReg r3
    //     0xc90644: str             x3, [SP, #-8]!
    // 0xc90648: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xc90648: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0xc9064c: ldr             x4, [x4, #0x4d8]
    // 0xc90650: r0 = mapEquals()
    //     0xc90650: bl              #0x7d6da4  ; [package:flutter/src/foundation/collections.dart] ::mapEquals
    // 0xc90654: add             SP, SP, #0x18
    // 0xc90658: tbnz            w0, #4, #0xc92884
    // 0xc9065c: ldr             x1, [fp, #0x18]
    // 0xc90660: ldr             x0, [fp, #0x10]
    // 0xc90664: LoadField: r2 = r0->field_17
    //     0xc90664: ldur            w2, [x0, #0x17]
    // 0xc90668: DecompressPointer r2
    //     0xc90668: add             x2, x2, HEAP, lsl #32
    // 0xc9066c: LoadField: r3 = r1->field_17
    //     0xc9066c: ldur            w3, [x1, #0x17]
    // 0xc90670: DecompressPointer r3
    //     0xc90670: add             x3, x3, HEAP, lsl #32
    // 0xc90674: cmp             w2, w3
    // 0xc90678: b.ne            #0xc92884
    // 0xc9067c: LoadField: r2 = r0->field_1f
    //     0xc9067c: ldur            w2, [x0, #0x1f]
    // 0xc90680: DecompressPointer r2
    //     0xc90680: add             x2, x2, HEAP, lsl #32
    // 0xc90684: LoadField: r3 = r1->field_1f
    //     0xc90684: ldur            w3, [x1, #0x1f]
    // 0xc90688: DecompressPointer r3
    //     0xc90688: add             x3, x3, HEAP, lsl #32
    // 0xc9068c: cmp             w2, w3
    // 0xc90690: b.ne            #0xc92884
    // 0xc90694: LoadField: r2 = r0->field_23
    //     0xc90694: ldur            w2, [x0, #0x23]
    // 0xc90698: DecompressPointer r2
    //     0xc90698: add             x2, x2, HEAP, lsl #32
    // 0xc9069c: LoadField: r3 = r1->field_23
    //     0xc9069c: ldur            w3, [x1, #0x23]
    // 0xc906a0: DecompressPointer r3
    //     0xc906a0: add             x3, x3, HEAP, lsl #32
    // 0xc906a4: stp             x3, x2, [SP, #-0x10]!
    // 0xc906a8: r0 = ==()
    //     0xc906a8: bl              #0xc8cc84  ; [package:flutter/src/material/scrollbar_theme.dart] ScrollbarThemeData::==
    // 0xc906ac: add             SP, SP, #0x10
    // 0xc906b0: tbnz            w0, #4, #0xc92884
    // 0xc906b4: ldr             x1, [fp, #0x18]
    // 0xc906b8: ldr             x0, [fp, #0x10]
    // 0xc906bc: LoadField: r2 = r0->field_27
    //     0xc906bc: ldur            w2, [x0, #0x27]
    // 0xc906c0: DecompressPointer r2
    //     0xc906c0: add             x2, x2, HEAP, lsl #32
    // 0xc906c4: LoadField: r3 = r1->field_27
    //     0xc906c4: ldur            w3, [x1, #0x27]
    // 0xc906c8: DecompressPointer r3
    //     0xc906c8: add             x3, x3, HEAP, lsl #32
    // 0xc906cc: cmp             w2, w3
    // 0xc906d0: b.ne            #0xc92884
    // 0xc906d4: LoadField: r2 = r0->field_2b
    //     0xc906d4: ldur            w2, [x0, #0x2b]
    // 0xc906d8: DecompressPointer r2
    //     0xc906d8: add             x2, x2, HEAP, lsl #32
    // 0xc906dc: LoadField: r3 = r1->field_2b
    //     0xc906dc: ldur            w3, [x1, #0x2b]
    // 0xc906e0: DecompressPointer r3
    //     0xc906e0: add             x3, x3, HEAP, lsl #32
    // 0xc906e4: cmp             w2, w3
    // 0xc906e8: b.ne            #0xc92884
    // 0xc906ec: LoadField: r2 = r0->field_2f
    //     0xc906ec: ldur            w2, [x0, #0x2f]
    // 0xc906f0: DecompressPointer r2
    //     0xc906f0: add             x2, x2, HEAP, lsl #32
    // 0xc906f4: stur            x2, [fp, #-0x10]
    // 0xc906f8: LoadField: r3 = r1->field_2f
    //     0xc906f8: ldur            w3, [x1, #0x2f]
    // 0xc906fc: DecompressPointer r3
    //     0xc906fc: add             x3, x3, HEAP, lsl #32
    // 0xc90700: stur            x3, [fp, #-8]
    // 0xc90704: r16 = VisualDensity
    //     0xc90704: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf10] Type: VisualDensity
    //     0xc90708: ldr             x16, [x16, #0xf10]
    // 0xc9070c: r30 = VisualDensity
    //     0xc9070c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf10] Type: VisualDensity
    //     0xc90710: ldr             lr, [lr, #0xf10]
    // 0xc90714: stp             lr, x16, [SP, #-0x10]!
    // 0xc90718: r0 = ==()
    //     0xc90718: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc9071c: add             SP, SP, #0x10
    // 0xc90720: tbnz            w0, #4, #0xc92884
    // 0xc90724: ldur            x0, [fp, #-0x10]
    // 0xc90728: ldur            x1, [fp, #-8]
    // 0xc9072c: LoadField: d0 = r1->field_7
    //     0xc9072c: ldur            d0, [x1, #7]
    // 0xc90730: LoadField: d1 = r0->field_7
    //     0xc90730: ldur            d1, [x0, #7]
    // 0xc90734: fcmp            d0, d1
    // 0xc90738: b.vs            #0xc92884
    // 0xc9073c: b.ne            #0xc92884
    // 0xc90740: LoadField: d0 = r1->field_f
    //     0xc90740: ldur            d0, [x1, #0xf]
    // 0xc90744: LoadField: d1 = r0->field_f
    //     0xc90744: ldur            d1, [x0, #0xf]
    // 0xc90748: fcmp            d0, d1
    // 0xc9074c: b.vs            #0xc92884
    // 0xc90750: b.ne            #0xc92884
    // 0xc90754: ldr             x1, [fp, #0x18]
    // 0xc90758: ldr             x0, [fp, #0x10]
    // 0xc9075c: LoadField: r2 = r0->field_37
    //     0xc9075c: ldur            w2, [x0, #0x37]
    // 0xc90760: DecompressPointer r2
    //     0xc90760: add             x2, x2, HEAP, lsl #32
    // 0xc90764: stur            x2, [fp, #-0x18]
    // 0xc90768: LoadField: r3 = r1->field_37
    //     0xc90768: ldur            w3, [x1, #0x37]
    // 0xc9076c: DecompressPointer r3
    //     0xc9076c: add             x3, x3, HEAP, lsl #32
    // 0xc90770: stur            x3, [fp, #-0x10]
    // 0xc90774: r4 = LoadClassIdInstr(r2)
    //     0xc90774: ldur            x4, [x2, #-1]
    //     0xc90778: ubfx            x4, x4, #0xc, #0x14
    // 0xc9077c: lsl             x4, x4, #1
    // 0xc90780: stur            x4, [fp, #-8]
    // 0xc90784: r17 = 10114
    //     0xc90784: mov             x17, #0x2782
    // 0xc90788: cmp             w4, w17
    // 0xc9078c: b.eq            #0xc9079c
    // 0xc90790: r17 = 10118
    //     0xc90790: mov             x17, #0x2786
    // 0xc90794: cmp             w4, w17
    // 0xc90798: b.ne            #0xc90874
    // 0xc9079c: cmp             w2, w3
    // 0xc907a0: b.eq            #0xc908a4
    // 0xc907a4: stp             x2, x3, [SP, #-0x10]!
    // 0xc907a8: r0 = _haveSameRuntimeType()
    //     0xc907a8: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc907ac: add             SP, SP, #0x10
    // 0xc907b0: tbnz            w0, #4, #0xc92884
    // 0xc907b4: ldur            x0, [fp, #-0x10]
    // 0xc907b8: r1 = LoadClassIdInstr(r0)
    //     0xc907b8: ldur            x1, [x0, #-1]
    //     0xc907bc: ubfx            x1, x1, #0xc, #0x14
    // 0xc907c0: lsl             x1, x1, #1
    // 0xc907c4: r17 = 10124
    //     0xc907c4: mov             x17, #0x278c
    // 0xc907c8: cmp             w1, w17
    // 0xc907cc: b.gt            #0xc907dc
    // 0xc907d0: r17 = 10122
    //     0xc907d0: mov             x17, #0x278a
    // 0xc907d4: cmp             w1, w17
    // 0xc907d8: b.ge            #0xc907f4
    // 0xc907dc: r17 = 10114
    //     0xc907dc: mov             x17, #0x2782
    // 0xc907e0: cmp             w1, w17
    // 0xc907e4: b.eq            #0xc907f4
    // 0xc907e8: r17 = 10118
    //     0xc907e8: mov             x17, #0x2786
    // 0xc907ec: cmp             w1, w17
    // 0xc907f0: b.ne            #0xc907fc
    // 0xc907f4: LoadField: r1 = r0->field_7
    //     0xc907f4: ldur            x1, [x0, #7]
    // 0xc907f8: b               #0xc9080c
    // 0xc907fc: LoadField: r1 = r0->field_f
    //     0xc907fc: ldur            w1, [x0, #0xf]
    // 0xc90800: DecompressPointer r1
    //     0xc90800: add             x1, x1, HEAP, lsl #32
    // 0xc90804: LoadField: r0 = r1->field_7
    //     0xc90804: ldur            x0, [x1, #7]
    // 0xc90808: mov             x1, x0
    // 0xc9080c: ldur            x0, [fp, #-8]
    // 0xc90810: r17 = 10124
    //     0xc90810: mov             x17, #0x278c
    // 0xc90814: cmp             w0, w17
    // 0xc90818: b.gt            #0xc90828
    // 0xc9081c: r17 = 10122
    //     0xc9081c: mov             x17, #0x278a
    // 0xc90820: cmp             w0, w17
    // 0xc90824: b.ge            #0xc90840
    // 0xc90828: r17 = 10114
    //     0xc90828: mov             x17, #0x2782
    // 0xc9082c: cmp             w0, w17
    // 0xc90830: b.eq            #0xc90840
    // 0xc90834: r17 = 10118
    //     0xc90834: mov             x17, #0x2786
    // 0xc90838: cmp             w0, w17
    // 0xc9083c: b.ne            #0xc9084c
    // 0xc90840: ldur            x2, [fp, #-0x18]
    // 0xc90844: LoadField: r0 = r2->field_7
    //     0xc90844: ldur            x0, [x2, #7]
    // 0xc90848: b               #0xc90860
    // 0xc9084c: ldur            x2, [fp, #-0x18]
    // 0xc90850: LoadField: r0 = r2->field_f
    //     0xc90850: ldur            w0, [x2, #0xf]
    // 0xc90854: DecompressPointer r0
    //     0xc90854: add             x0, x0, HEAP, lsl #32
    // 0xc90858: LoadField: r2 = r0->field_7
    //     0xc90858: ldur            x2, [x0, #7]
    // 0xc9085c: mov             x0, x2
    // 0xc90860: cmp             x1, x0
    // 0xc90864: b.ne            #0xc92884
    // 0xc90868: ldr             x1, [fp, #0x18]
    // 0xc9086c: ldr             x0, [fp, #0x10]
    // 0xc90870: b               #0xc908a4
    // 0xc90874: mov             x0, x3
    // 0xc90878: r1 = LoadClassIdInstr(r2)
    //     0xc90878: ldur            x1, [x2, #-1]
    //     0xc9087c: ubfx            x1, x1, #0xc, #0x14
    // 0xc90880: stp             x0, x2, [SP, #-0x10]!
    // 0xc90884: mov             x0, x1
    // 0xc90888: mov             lr, x0
    // 0xc9088c: ldr             lr, [x21, lr, lsl #3]
    // 0xc90890: blr             lr
    // 0xc90894: add             SP, SP, #0x10
    // 0xc90898: tbnz            w0, #4, #0xc92884
    // 0xc9089c: ldr             x1, [fp, #0x18]
    // 0xc908a0: ldr             x0, [fp, #0x10]
    // 0xc908a4: LoadField: r2 = r0->field_3b
    //     0xc908a4: ldur            w2, [x0, #0x3b]
    // 0xc908a8: DecompressPointer r2
    //     0xc908a8: add             x2, x2, HEAP, lsl #32
    // 0xc908ac: stur            x2, [fp, #-0x18]
    // 0xc908b0: LoadField: r3 = r1->field_3b
    //     0xc908b0: ldur            w3, [x1, #0x3b]
    // 0xc908b4: DecompressPointer r3
    //     0xc908b4: add             x3, x3, HEAP, lsl #32
    // 0xc908b8: stur            x3, [fp, #-0x10]
    // 0xc908bc: r4 = LoadClassIdInstr(r2)
    //     0xc908bc: ldur            x4, [x2, #-1]
    //     0xc908c0: ubfx            x4, x4, #0xc, #0x14
    // 0xc908c4: lsl             x4, x4, #1
    // 0xc908c8: stur            x4, [fp, #-8]
    // 0xc908cc: r17 = 10114
    //     0xc908cc: mov             x17, #0x2782
    // 0xc908d0: cmp             w4, w17
    // 0xc908d4: b.eq            #0xc908e4
    // 0xc908d8: r17 = 10118
    //     0xc908d8: mov             x17, #0x2786
    // 0xc908dc: cmp             w4, w17
    // 0xc908e0: b.ne            #0xc909bc
    // 0xc908e4: cmp             w2, w3
    // 0xc908e8: b.eq            #0xc909ec
    // 0xc908ec: stp             x2, x3, [SP, #-0x10]!
    // 0xc908f0: r0 = _haveSameRuntimeType()
    //     0xc908f0: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc908f4: add             SP, SP, #0x10
    // 0xc908f8: tbnz            w0, #4, #0xc92884
    // 0xc908fc: ldur            x0, [fp, #-0x10]
    // 0xc90900: r1 = LoadClassIdInstr(r0)
    //     0xc90900: ldur            x1, [x0, #-1]
    //     0xc90904: ubfx            x1, x1, #0xc, #0x14
    // 0xc90908: lsl             x1, x1, #1
    // 0xc9090c: r17 = 10124
    //     0xc9090c: mov             x17, #0x278c
    // 0xc90910: cmp             w1, w17
    // 0xc90914: b.gt            #0xc90924
    // 0xc90918: r17 = 10122
    //     0xc90918: mov             x17, #0x278a
    // 0xc9091c: cmp             w1, w17
    // 0xc90920: b.ge            #0xc9093c
    // 0xc90924: r17 = 10114
    //     0xc90924: mov             x17, #0x2782
    // 0xc90928: cmp             w1, w17
    // 0xc9092c: b.eq            #0xc9093c
    // 0xc90930: r17 = 10118
    //     0xc90930: mov             x17, #0x2786
    // 0xc90934: cmp             w1, w17
    // 0xc90938: b.ne            #0xc90944
    // 0xc9093c: LoadField: r1 = r0->field_7
    //     0xc9093c: ldur            x1, [x0, #7]
    // 0xc90940: b               #0xc90954
    // 0xc90944: LoadField: r1 = r0->field_f
    //     0xc90944: ldur            w1, [x0, #0xf]
    // 0xc90948: DecompressPointer r1
    //     0xc90948: add             x1, x1, HEAP, lsl #32
    // 0xc9094c: LoadField: r0 = r1->field_7
    //     0xc9094c: ldur            x0, [x1, #7]
    // 0xc90950: mov             x1, x0
    // 0xc90954: ldur            x0, [fp, #-8]
    // 0xc90958: r17 = 10124
    //     0xc90958: mov             x17, #0x278c
    // 0xc9095c: cmp             w0, w17
    // 0xc90960: b.gt            #0xc90970
    // 0xc90964: r17 = 10122
    //     0xc90964: mov             x17, #0x278a
    // 0xc90968: cmp             w0, w17
    // 0xc9096c: b.ge            #0xc90988
    // 0xc90970: r17 = 10114
    //     0xc90970: mov             x17, #0x2782
    // 0xc90974: cmp             w0, w17
    // 0xc90978: b.eq            #0xc90988
    // 0xc9097c: r17 = 10118
    //     0xc9097c: mov             x17, #0x2786
    // 0xc90980: cmp             w0, w17
    // 0xc90984: b.ne            #0xc90994
    // 0xc90988: ldur            x2, [fp, #-0x18]
    // 0xc9098c: LoadField: r0 = r2->field_7
    //     0xc9098c: ldur            x0, [x2, #7]
    // 0xc90990: b               #0xc909a8
    // 0xc90994: ldur            x2, [fp, #-0x18]
    // 0xc90998: LoadField: r0 = r2->field_f
    //     0xc90998: ldur            w0, [x2, #0xf]
    // 0xc9099c: DecompressPointer r0
    //     0xc9099c: add             x0, x0, HEAP, lsl #32
    // 0xc909a0: LoadField: r2 = r0->field_7
    //     0xc909a0: ldur            x2, [x0, #7]
    // 0xc909a4: mov             x0, x2
    // 0xc909a8: cmp             x1, x0
    // 0xc909ac: b.ne            #0xc92884
    // 0xc909b0: ldr             x1, [fp, #0x18]
    // 0xc909b4: ldr             x0, [fp, #0x10]
    // 0xc909b8: b               #0xc909ec
    // 0xc909bc: mov             x0, x3
    // 0xc909c0: r1 = LoadClassIdInstr(r2)
    //     0xc909c0: ldur            x1, [x2, #-1]
    //     0xc909c4: ubfx            x1, x1, #0xc, #0x14
    // 0xc909c8: stp             x0, x2, [SP, #-0x10]!
    // 0xc909cc: mov             x0, x1
    // 0xc909d0: mov             lr, x0
    // 0xc909d4: ldr             lr, [x21, lr, lsl #3]
    // 0xc909d8: blr             lr
    // 0xc909dc: add             SP, SP, #0x10
    // 0xc909e0: tbnz            w0, #4, #0xc92884
    // 0xc909e4: ldr             x1, [fp, #0x18]
    // 0xc909e8: ldr             x0, [fp, #0x10]
    // 0xc909ec: LoadField: r2 = r0->field_3f
    //     0xc909ec: ldur            w2, [x0, #0x3f]
    // 0xc909f0: DecompressPointer r2
    //     0xc909f0: add             x2, x2, HEAP, lsl #32
    // 0xc909f4: LoadField: r3 = r1->field_3f
    //     0xc909f4: ldur            w3, [x1, #0x3f]
    // 0xc909f8: DecompressPointer r3
    //     0xc909f8: add             x3, x3, HEAP, lsl #32
    // 0xc909fc: stp             x3, x2, [SP, #-0x10]!
    // 0xc90a00: r0 = ==()
    //     0xc90a00: bl              #0xc85884  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::==
    // 0xc90a04: add             SP, SP, #0x10
    // 0xc90a08: tbnz            w0, #4, #0xc92884
    // 0xc90a0c: ldr             x1, [fp, #0x18]
    // 0xc90a10: ldr             x0, [fp, #0x10]
    // 0xc90a14: LoadField: r2 = r0->field_43
    //     0xc90a14: ldur            w2, [x0, #0x43]
    // 0xc90a18: DecompressPointer r2
    //     0xc90a18: add             x2, x2, HEAP, lsl #32
    // 0xc90a1c: stur            x2, [fp, #-0x18]
    // 0xc90a20: LoadField: r3 = r1->field_43
    //     0xc90a20: ldur            w3, [x1, #0x43]
    // 0xc90a24: DecompressPointer r3
    //     0xc90a24: add             x3, x3, HEAP, lsl #32
    // 0xc90a28: stur            x3, [fp, #-0x10]
    // 0xc90a2c: r4 = LoadClassIdInstr(r2)
    //     0xc90a2c: ldur            x4, [x2, #-1]
    //     0xc90a30: ubfx            x4, x4, #0xc, #0x14
    // 0xc90a34: lsl             x4, x4, #1
    // 0xc90a38: stur            x4, [fp, #-8]
    // 0xc90a3c: r17 = 10114
    //     0xc90a3c: mov             x17, #0x2782
    // 0xc90a40: cmp             w4, w17
    // 0xc90a44: b.eq            #0xc90a54
    // 0xc90a48: r17 = 10118
    //     0xc90a48: mov             x17, #0x2786
    // 0xc90a4c: cmp             w4, w17
    // 0xc90a50: b.ne            #0xc90b2c
    // 0xc90a54: cmp             w2, w3
    // 0xc90a58: b.eq            #0xc90b5c
    // 0xc90a5c: stp             x2, x3, [SP, #-0x10]!
    // 0xc90a60: r0 = _haveSameRuntimeType()
    //     0xc90a60: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc90a64: add             SP, SP, #0x10
    // 0xc90a68: tbnz            w0, #4, #0xc92884
    // 0xc90a6c: ldur            x0, [fp, #-0x10]
    // 0xc90a70: r1 = LoadClassIdInstr(r0)
    //     0xc90a70: ldur            x1, [x0, #-1]
    //     0xc90a74: ubfx            x1, x1, #0xc, #0x14
    // 0xc90a78: lsl             x1, x1, #1
    // 0xc90a7c: r17 = 10124
    //     0xc90a7c: mov             x17, #0x278c
    // 0xc90a80: cmp             w1, w17
    // 0xc90a84: b.gt            #0xc90a94
    // 0xc90a88: r17 = 10122
    //     0xc90a88: mov             x17, #0x278a
    // 0xc90a8c: cmp             w1, w17
    // 0xc90a90: b.ge            #0xc90aac
    // 0xc90a94: r17 = 10114
    //     0xc90a94: mov             x17, #0x2782
    // 0xc90a98: cmp             w1, w17
    // 0xc90a9c: b.eq            #0xc90aac
    // 0xc90aa0: r17 = 10118
    //     0xc90aa0: mov             x17, #0x2786
    // 0xc90aa4: cmp             w1, w17
    // 0xc90aa8: b.ne            #0xc90ab4
    // 0xc90aac: LoadField: r1 = r0->field_7
    //     0xc90aac: ldur            x1, [x0, #7]
    // 0xc90ab0: b               #0xc90ac4
    // 0xc90ab4: LoadField: r1 = r0->field_f
    //     0xc90ab4: ldur            w1, [x0, #0xf]
    // 0xc90ab8: DecompressPointer r1
    //     0xc90ab8: add             x1, x1, HEAP, lsl #32
    // 0xc90abc: LoadField: r0 = r1->field_7
    //     0xc90abc: ldur            x0, [x1, #7]
    // 0xc90ac0: mov             x1, x0
    // 0xc90ac4: ldur            x0, [fp, #-8]
    // 0xc90ac8: r17 = 10124
    //     0xc90ac8: mov             x17, #0x278c
    // 0xc90acc: cmp             w0, w17
    // 0xc90ad0: b.gt            #0xc90ae0
    // 0xc90ad4: r17 = 10122
    //     0xc90ad4: mov             x17, #0x278a
    // 0xc90ad8: cmp             w0, w17
    // 0xc90adc: b.ge            #0xc90af8
    // 0xc90ae0: r17 = 10114
    //     0xc90ae0: mov             x17, #0x2782
    // 0xc90ae4: cmp             w0, w17
    // 0xc90ae8: b.eq            #0xc90af8
    // 0xc90aec: r17 = 10118
    //     0xc90aec: mov             x17, #0x2786
    // 0xc90af0: cmp             w0, w17
    // 0xc90af4: b.ne            #0xc90b04
    // 0xc90af8: ldur            x2, [fp, #-0x18]
    // 0xc90afc: LoadField: r0 = r2->field_7
    //     0xc90afc: ldur            x0, [x2, #7]
    // 0xc90b00: b               #0xc90b18
    // 0xc90b04: ldur            x2, [fp, #-0x18]
    // 0xc90b08: LoadField: r0 = r2->field_f
    //     0xc90b08: ldur            w0, [x2, #0xf]
    // 0xc90b0c: DecompressPointer r0
    //     0xc90b0c: add             x0, x0, HEAP, lsl #32
    // 0xc90b10: LoadField: r2 = r0->field_7
    //     0xc90b10: ldur            x2, [x0, #7]
    // 0xc90b14: mov             x0, x2
    // 0xc90b18: cmp             x1, x0
    // 0xc90b1c: b.ne            #0xc92884
    // 0xc90b20: ldr             x1, [fp, #0x18]
    // 0xc90b24: ldr             x0, [fp, #0x10]
    // 0xc90b28: b               #0xc90b5c
    // 0xc90b2c: mov             x0, x3
    // 0xc90b30: r1 = LoadClassIdInstr(r2)
    //     0xc90b30: ldur            x1, [x2, #-1]
    //     0xc90b34: ubfx            x1, x1, #0xc, #0x14
    // 0xc90b38: stp             x0, x2, [SP, #-0x10]!
    // 0xc90b3c: mov             x0, x1
    // 0xc90b40: mov             lr, x0
    // 0xc90b44: ldr             lr, [x21, lr, lsl #3]
    // 0xc90b48: blr             lr
    // 0xc90b4c: add             SP, SP, #0x10
    // 0xc90b50: tbnz            w0, #4, #0xc92884
    // 0xc90b54: ldr             x1, [fp, #0x18]
    // 0xc90b58: ldr             x0, [fp, #0x10]
    // 0xc90b5c: LoadField: r2 = r0->field_47
    //     0xc90b5c: ldur            w2, [x0, #0x47]
    // 0xc90b60: DecompressPointer r2
    //     0xc90b60: add             x2, x2, HEAP, lsl #32
    // 0xc90b64: stur            x2, [fp, #-0x10]
    // 0xc90b68: LoadField: r3 = r1->field_47
    //     0xc90b68: ldur            w3, [x1, #0x47]
    // 0xc90b6c: DecompressPointer r3
    //     0xc90b6c: add             x3, x3, HEAP, lsl #32
    // 0xc90b70: stur            x3, [fp, #-8]
    // 0xc90b74: cmp             w2, w3
    // 0xc90b78: b.eq            #0xc90bbc
    // 0xc90b7c: r16 = Color
    //     0xc90b7c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90b80: ldr             x16, [x16, #0xf18]
    // 0xc90b84: r30 = Color
    //     0xc90b84: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90b88: ldr             lr, [lr, #0xf18]
    // 0xc90b8c: stp             lr, x16, [SP, #-0x10]!
    // 0xc90b90: r0 = ==()
    //     0xc90b90: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc90b94: add             SP, SP, #0x10
    // 0xc90b98: tbnz            w0, #4, #0xc92884
    // 0xc90b9c: ldur            x0, [fp, #-0x10]
    // 0xc90ba0: ldur            x1, [fp, #-8]
    // 0xc90ba4: LoadField: r2 = r1->field_7
    //     0xc90ba4: ldur            x2, [x1, #7]
    // 0xc90ba8: LoadField: r1 = r0->field_7
    //     0xc90ba8: ldur            x1, [x0, #7]
    // 0xc90bac: cmp             x2, x1
    // 0xc90bb0: b.ne            #0xc92884
    // 0xc90bb4: ldr             x1, [fp, #0x18]
    // 0xc90bb8: ldr             x0, [fp, #0x10]
    // 0xc90bbc: LoadField: r2 = r0->field_4b
    //     0xc90bbc: ldur            w2, [x0, #0x4b]
    // 0xc90bc0: DecompressPointer r2
    //     0xc90bc0: add             x2, x2, HEAP, lsl #32
    // 0xc90bc4: stur            x2, [fp, #-0x10]
    // 0xc90bc8: LoadField: r3 = r1->field_4b
    //     0xc90bc8: ldur            w3, [x1, #0x4b]
    // 0xc90bcc: DecompressPointer r3
    //     0xc90bcc: add             x3, x3, HEAP, lsl #32
    // 0xc90bd0: stur            x3, [fp, #-8]
    // 0xc90bd4: cmp             w2, w3
    // 0xc90bd8: b.eq            #0xc90c1c
    // 0xc90bdc: r16 = Color
    //     0xc90bdc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90be0: ldr             x16, [x16, #0xf18]
    // 0xc90be4: r30 = Color
    //     0xc90be4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90be8: ldr             lr, [lr, #0xf18]
    // 0xc90bec: stp             lr, x16, [SP, #-0x10]!
    // 0xc90bf0: r0 = ==()
    //     0xc90bf0: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc90bf4: add             SP, SP, #0x10
    // 0xc90bf8: tbnz            w0, #4, #0xc92884
    // 0xc90bfc: ldur            x0, [fp, #-0x10]
    // 0xc90c00: ldur            x1, [fp, #-8]
    // 0xc90c04: LoadField: r2 = r1->field_7
    //     0xc90c04: ldur            x2, [x1, #7]
    // 0xc90c08: LoadField: r1 = r0->field_7
    //     0xc90c08: ldur            x1, [x0, #7]
    // 0xc90c0c: cmp             x2, x1
    // 0xc90c10: b.ne            #0xc92884
    // 0xc90c14: ldr             x1, [fp, #0x18]
    // 0xc90c18: ldr             x0, [fp, #0x10]
    // 0xc90c1c: LoadField: r2 = r0->field_4f
    //     0xc90c1c: ldur            w2, [x0, #0x4f]
    // 0xc90c20: DecompressPointer r2
    //     0xc90c20: add             x2, x2, HEAP, lsl #32
    // 0xc90c24: stur            x2, [fp, #-0x10]
    // 0xc90c28: LoadField: r3 = r1->field_4f
    //     0xc90c28: ldur            w3, [x1, #0x4f]
    // 0xc90c2c: DecompressPointer r3
    //     0xc90c2c: add             x3, x3, HEAP, lsl #32
    // 0xc90c30: stur            x3, [fp, #-8]
    // 0xc90c34: cmp             w2, w3
    // 0xc90c38: b.eq            #0xc90c7c
    // 0xc90c3c: r16 = Color
    //     0xc90c3c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90c40: ldr             x16, [x16, #0xf18]
    // 0xc90c44: r30 = Color
    //     0xc90c44: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90c48: ldr             lr, [lr, #0xf18]
    // 0xc90c4c: stp             lr, x16, [SP, #-0x10]!
    // 0xc90c50: r0 = ==()
    //     0xc90c50: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc90c54: add             SP, SP, #0x10
    // 0xc90c58: tbnz            w0, #4, #0xc92884
    // 0xc90c5c: ldur            x0, [fp, #-0x10]
    // 0xc90c60: ldur            x1, [fp, #-8]
    // 0xc90c64: LoadField: r2 = r1->field_7
    //     0xc90c64: ldur            x2, [x1, #7]
    // 0xc90c68: LoadField: r1 = r0->field_7
    //     0xc90c68: ldur            x1, [x0, #7]
    // 0xc90c6c: cmp             x2, x1
    // 0xc90c70: b.ne            #0xc92884
    // 0xc90c74: ldr             x1, [fp, #0x18]
    // 0xc90c78: ldr             x0, [fp, #0x10]
    // 0xc90c7c: LoadField: r2 = r0->field_53
    //     0xc90c7c: ldur            w2, [x0, #0x53]
    // 0xc90c80: DecompressPointer r2
    //     0xc90c80: add             x2, x2, HEAP, lsl #32
    // 0xc90c84: stur            x2, [fp, #-0x10]
    // 0xc90c88: LoadField: r3 = r1->field_53
    //     0xc90c88: ldur            w3, [x1, #0x53]
    // 0xc90c8c: DecompressPointer r3
    //     0xc90c8c: add             x3, x3, HEAP, lsl #32
    // 0xc90c90: stur            x3, [fp, #-8]
    // 0xc90c94: cmp             w2, w3
    // 0xc90c98: b.eq            #0xc90cdc
    // 0xc90c9c: r16 = Color
    //     0xc90c9c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90ca0: ldr             x16, [x16, #0xf18]
    // 0xc90ca4: r30 = Color
    //     0xc90ca4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90ca8: ldr             lr, [lr, #0xf18]
    // 0xc90cac: stp             lr, x16, [SP, #-0x10]!
    // 0xc90cb0: r0 = ==()
    //     0xc90cb0: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc90cb4: add             SP, SP, #0x10
    // 0xc90cb8: tbnz            w0, #4, #0xc92884
    // 0xc90cbc: ldur            x0, [fp, #-0x10]
    // 0xc90cc0: ldur            x1, [fp, #-8]
    // 0xc90cc4: LoadField: r2 = r1->field_7
    //     0xc90cc4: ldur            x2, [x1, #7]
    // 0xc90cc8: LoadField: r1 = r0->field_7
    //     0xc90cc8: ldur            x1, [x0, #7]
    // 0xc90ccc: cmp             x2, x1
    // 0xc90cd0: b.ne            #0xc92884
    // 0xc90cd4: ldr             x1, [fp, #0x18]
    // 0xc90cd8: ldr             x0, [fp, #0x10]
    // 0xc90cdc: LoadField: r2 = r0->field_57
    //     0xc90cdc: ldur            w2, [x0, #0x57]
    // 0xc90ce0: DecompressPointer r2
    //     0xc90ce0: add             x2, x2, HEAP, lsl #32
    // 0xc90ce4: stur            x2, [fp, #-0x10]
    // 0xc90ce8: LoadField: r3 = r1->field_57
    //     0xc90ce8: ldur            w3, [x1, #0x57]
    // 0xc90cec: DecompressPointer r3
    //     0xc90cec: add             x3, x3, HEAP, lsl #32
    // 0xc90cf0: stur            x3, [fp, #-8]
    // 0xc90cf4: cmp             w2, w3
    // 0xc90cf8: b.eq            #0xc90d3c
    // 0xc90cfc: r16 = Color
    //     0xc90cfc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90d00: ldr             x16, [x16, #0xf18]
    // 0xc90d04: r30 = Color
    //     0xc90d04: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90d08: ldr             lr, [lr, #0xf18]
    // 0xc90d0c: stp             lr, x16, [SP, #-0x10]!
    // 0xc90d10: r0 = ==()
    //     0xc90d10: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc90d14: add             SP, SP, #0x10
    // 0xc90d18: tbnz            w0, #4, #0xc92884
    // 0xc90d1c: ldur            x0, [fp, #-0x10]
    // 0xc90d20: ldur            x1, [fp, #-8]
    // 0xc90d24: LoadField: r2 = r1->field_7
    //     0xc90d24: ldur            x2, [x1, #7]
    // 0xc90d28: LoadField: r1 = r0->field_7
    //     0xc90d28: ldur            x1, [x0, #7]
    // 0xc90d2c: cmp             x2, x1
    // 0xc90d30: b.ne            #0xc92884
    // 0xc90d34: ldr             x1, [fp, #0x18]
    // 0xc90d38: ldr             x0, [fp, #0x10]
    // 0xc90d3c: LoadField: r2 = r0->field_5b
    //     0xc90d3c: ldur            w2, [x0, #0x5b]
    // 0xc90d40: DecompressPointer r2
    //     0xc90d40: add             x2, x2, HEAP, lsl #32
    // 0xc90d44: stur            x2, [fp, #-0x10]
    // 0xc90d48: LoadField: r3 = r1->field_5b
    //     0xc90d48: ldur            w3, [x1, #0x5b]
    // 0xc90d4c: DecompressPointer r3
    //     0xc90d4c: add             x3, x3, HEAP, lsl #32
    // 0xc90d50: stur            x3, [fp, #-8]
    // 0xc90d54: cmp             w2, w3
    // 0xc90d58: b.eq            #0xc90d9c
    // 0xc90d5c: r16 = Color
    //     0xc90d5c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90d60: ldr             x16, [x16, #0xf18]
    // 0xc90d64: r30 = Color
    //     0xc90d64: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc90d68: ldr             lr, [lr, #0xf18]
    // 0xc90d6c: stp             lr, x16, [SP, #-0x10]!
    // 0xc90d70: r0 = ==()
    //     0xc90d70: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc90d74: add             SP, SP, #0x10
    // 0xc90d78: tbnz            w0, #4, #0xc92884
    // 0xc90d7c: ldur            x0, [fp, #-0x10]
    // 0xc90d80: ldur            x1, [fp, #-8]
    // 0xc90d84: LoadField: r2 = r1->field_7
    //     0xc90d84: ldur            x2, [x1, #7]
    // 0xc90d88: LoadField: r1 = r0->field_7
    //     0xc90d88: ldur            x1, [x0, #7]
    // 0xc90d8c: cmp             x2, x1
    // 0xc90d90: b.ne            #0xc92884
    // 0xc90d94: ldr             x1, [fp, #0x18]
    // 0xc90d98: ldr             x0, [fp, #0x10]
    // 0xc90d9c: LoadField: r2 = r0->field_5f
    //     0xc90d9c: ldur            w2, [x0, #0x5f]
    // 0xc90da0: DecompressPointer r2
    //     0xc90da0: add             x2, x2, HEAP, lsl #32
    // 0xc90da4: stur            x2, [fp, #-0x18]
    // 0xc90da8: LoadField: r3 = r1->field_5f
    //     0xc90da8: ldur            w3, [x1, #0x5f]
    // 0xc90dac: DecompressPointer r3
    //     0xc90dac: add             x3, x3, HEAP, lsl #32
    // 0xc90db0: stur            x3, [fp, #-0x10]
    // 0xc90db4: r4 = LoadClassIdInstr(r2)
    //     0xc90db4: ldur            x4, [x2, #-1]
    //     0xc90db8: ubfx            x4, x4, #0xc, #0x14
    // 0xc90dbc: lsl             x4, x4, #1
    // 0xc90dc0: stur            x4, [fp, #-8]
    // 0xc90dc4: r17 = 10114
    //     0xc90dc4: mov             x17, #0x2782
    // 0xc90dc8: cmp             w4, w17
    // 0xc90dcc: b.eq            #0xc90ddc
    // 0xc90dd0: r17 = 10118
    //     0xc90dd0: mov             x17, #0x2786
    // 0xc90dd4: cmp             w4, w17
    // 0xc90dd8: b.ne            #0xc90eb4
    // 0xc90ddc: cmp             w2, w3
    // 0xc90de0: b.eq            #0xc90ee4
    // 0xc90de4: stp             x2, x3, [SP, #-0x10]!
    // 0xc90de8: r0 = _haveSameRuntimeType()
    //     0xc90de8: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc90dec: add             SP, SP, #0x10
    // 0xc90df0: tbnz            w0, #4, #0xc92884
    // 0xc90df4: ldur            x0, [fp, #-0x10]
    // 0xc90df8: r1 = LoadClassIdInstr(r0)
    //     0xc90df8: ldur            x1, [x0, #-1]
    //     0xc90dfc: ubfx            x1, x1, #0xc, #0x14
    // 0xc90e00: lsl             x1, x1, #1
    // 0xc90e04: r17 = 10124
    //     0xc90e04: mov             x17, #0x278c
    // 0xc90e08: cmp             w1, w17
    // 0xc90e0c: b.gt            #0xc90e1c
    // 0xc90e10: r17 = 10122
    //     0xc90e10: mov             x17, #0x278a
    // 0xc90e14: cmp             w1, w17
    // 0xc90e18: b.ge            #0xc90e34
    // 0xc90e1c: r17 = 10114
    //     0xc90e1c: mov             x17, #0x2782
    // 0xc90e20: cmp             w1, w17
    // 0xc90e24: b.eq            #0xc90e34
    // 0xc90e28: r17 = 10118
    //     0xc90e28: mov             x17, #0x2786
    // 0xc90e2c: cmp             w1, w17
    // 0xc90e30: b.ne            #0xc90e3c
    // 0xc90e34: LoadField: r1 = r0->field_7
    //     0xc90e34: ldur            x1, [x0, #7]
    // 0xc90e38: b               #0xc90e4c
    // 0xc90e3c: LoadField: r1 = r0->field_f
    //     0xc90e3c: ldur            w1, [x0, #0xf]
    // 0xc90e40: DecompressPointer r1
    //     0xc90e40: add             x1, x1, HEAP, lsl #32
    // 0xc90e44: LoadField: r0 = r1->field_7
    //     0xc90e44: ldur            x0, [x1, #7]
    // 0xc90e48: mov             x1, x0
    // 0xc90e4c: ldur            x0, [fp, #-8]
    // 0xc90e50: r17 = 10124
    //     0xc90e50: mov             x17, #0x278c
    // 0xc90e54: cmp             w0, w17
    // 0xc90e58: b.gt            #0xc90e68
    // 0xc90e5c: r17 = 10122
    //     0xc90e5c: mov             x17, #0x278a
    // 0xc90e60: cmp             w0, w17
    // 0xc90e64: b.ge            #0xc90e80
    // 0xc90e68: r17 = 10114
    //     0xc90e68: mov             x17, #0x2782
    // 0xc90e6c: cmp             w0, w17
    // 0xc90e70: b.eq            #0xc90e80
    // 0xc90e74: r17 = 10118
    //     0xc90e74: mov             x17, #0x2786
    // 0xc90e78: cmp             w0, w17
    // 0xc90e7c: b.ne            #0xc90e8c
    // 0xc90e80: ldur            x2, [fp, #-0x18]
    // 0xc90e84: LoadField: r0 = r2->field_7
    //     0xc90e84: ldur            x0, [x2, #7]
    // 0xc90e88: b               #0xc90ea0
    // 0xc90e8c: ldur            x2, [fp, #-0x18]
    // 0xc90e90: LoadField: r0 = r2->field_f
    //     0xc90e90: ldur            w0, [x2, #0xf]
    // 0xc90e94: DecompressPointer r0
    //     0xc90e94: add             x0, x0, HEAP, lsl #32
    // 0xc90e98: LoadField: r2 = r0->field_7
    //     0xc90e98: ldur            x2, [x0, #7]
    // 0xc90e9c: mov             x0, x2
    // 0xc90ea0: cmp             x1, x0
    // 0xc90ea4: b.ne            #0xc92884
    // 0xc90ea8: ldr             x1, [fp, #0x18]
    // 0xc90eac: ldr             x0, [fp, #0x10]
    // 0xc90eb0: b               #0xc90ee4
    // 0xc90eb4: mov             x0, x3
    // 0xc90eb8: r1 = LoadClassIdInstr(r2)
    //     0xc90eb8: ldur            x1, [x2, #-1]
    //     0xc90ebc: ubfx            x1, x1, #0xc, #0x14
    // 0xc90ec0: stp             x0, x2, [SP, #-0x10]!
    // 0xc90ec4: mov             x0, x1
    // 0xc90ec8: mov             lr, x0
    // 0xc90ecc: ldr             lr, [x21, lr, lsl #3]
    // 0xc90ed0: blr             lr
    // 0xc90ed4: add             SP, SP, #0x10
    // 0xc90ed8: tbnz            w0, #4, #0xc92884
    // 0xc90edc: ldr             x1, [fp, #0x18]
    // 0xc90ee0: ldr             x0, [fp, #0x10]
    // 0xc90ee4: LoadField: r2 = r0->field_63
    //     0xc90ee4: ldur            w2, [x0, #0x63]
    // 0xc90ee8: DecompressPointer r2
    //     0xc90ee8: add             x2, x2, HEAP, lsl #32
    // 0xc90eec: stur            x2, [fp, #-0x18]
    // 0xc90ef0: LoadField: r3 = r1->field_63
    //     0xc90ef0: ldur            w3, [x1, #0x63]
    // 0xc90ef4: DecompressPointer r3
    //     0xc90ef4: add             x3, x3, HEAP, lsl #32
    // 0xc90ef8: stur            x3, [fp, #-0x10]
    // 0xc90efc: r4 = LoadClassIdInstr(r2)
    //     0xc90efc: ldur            x4, [x2, #-1]
    //     0xc90f00: ubfx            x4, x4, #0xc, #0x14
    // 0xc90f04: lsl             x4, x4, #1
    // 0xc90f08: stur            x4, [fp, #-8]
    // 0xc90f0c: r17 = 10114
    //     0xc90f0c: mov             x17, #0x2782
    // 0xc90f10: cmp             w4, w17
    // 0xc90f14: b.eq            #0xc90f24
    // 0xc90f18: r17 = 10118
    //     0xc90f18: mov             x17, #0x2786
    // 0xc90f1c: cmp             w4, w17
    // 0xc90f20: b.ne            #0xc90ffc
    // 0xc90f24: cmp             w2, w3
    // 0xc90f28: b.eq            #0xc9102c
    // 0xc90f2c: stp             x2, x3, [SP, #-0x10]!
    // 0xc90f30: r0 = _haveSameRuntimeType()
    //     0xc90f30: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc90f34: add             SP, SP, #0x10
    // 0xc90f38: tbnz            w0, #4, #0xc92884
    // 0xc90f3c: ldur            x0, [fp, #-0x10]
    // 0xc90f40: r1 = LoadClassIdInstr(r0)
    //     0xc90f40: ldur            x1, [x0, #-1]
    //     0xc90f44: ubfx            x1, x1, #0xc, #0x14
    // 0xc90f48: lsl             x1, x1, #1
    // 0xc90f4c: r17 = 10124
    //     0xc90f4c: mov             x17, #0x278c
    // 0xc90f50: cmp             w1, w17
    // 0xc90f54: b.gt            #0xc90f64
    // 0xc90f58: r17 = 10122
    //     0xc90f58: mov             x17, #0x278a
    // 0xc90f5c: cmp             w1, w17
    // 0xc90f60: b.ge            #0xc90f7c
    // 0xc90f64: r17 = 10114
    //     0xc90f64: mov             x17, #0x2782
    // 0xc90f68: cmp             w1, w17
    // 0xc90f6c: b.eq            #0xc90f7c
    // 0xc90f70: r17 = 10118
    //     0xc90f70: mov             x17, #0x2786
    // 0xc90f74: cmp             w1, w17
    // 0xc90f78: b.ne            #0xc90f84
    // 0xc90f7c: LoadField: r1 = r0->field_7
    //     0xc90f7c: ldur            x1, [x0, #7]
    // 0xc90f80: b               #0xc90f94
    // 0xc90f84: LoadField: r1 = r0->field_f
    //     0xc90f84: ldur            w1, [x0, #0xf]
    // 0xc90f88: DecompressPointer r1
    //     0xc90f88: add             x1, x1, HEAP, lsl #32
    // 0xc90f8c: LoadField: r0 = r1->field_7
    //     0xc90f8c: ldur            x0, [x1, #7]
    // 0xc90f90: mov             x1, x0
    // 0xc90f94: ldur            x0, [fp, #-8]
    // 0xc90f98: r17 = 10124
    //     0xc90f98: mov             x17, #0x278c
    // 0xc90f9c: cmp             w0, w17
    // 0xc90fa0: b.gt            #0xc90fb0
    // 0xc90fa4: r17 = 10122
    //     0xc90fa4: mov             x17, #0x278a
    // 0xc90fa8: cmp             w0, w17
    // 0xc90fac: b.ge            #0xc90fc8
    // 0xc90fb0: r17 = 10114
    //     0xc90fb0: mov             x17, #0x2782
    // 0xc90fb4: cmp             w0, w17
    // 0xc90fb8: b.eq            #0xc90fc8
    // 0xc90fbc: r17 = 10118
    //     0xc90fbc: mov             x17, #0x2786
    // 0xc90fc0: cmp             w0, w17
    // 0xc90fc4: b.ne            #0xc90fd4
    // 0xc90fc8: ldur            x2, [fp, #-0x18]
    // 0xc90fcc: LoadField: r0 = r2->field_7
    //     0xc90fcc: ldur            x0, [x2, #7]
    // 0xc90fd0: b               #0xc90fe8
    // 0xc90fd4: ldur            x2, [fp, #-0x18]
    // 0xc90fd8: LoadField: r0 = r2->field_f
    //     0xc90fd8: ldur            w0, [x2, #0xf]
    // 0xc90fdc: DecompressPointer r0
    //     0xc90fdc: add             x0, x0, HEAP, lsl #32
    // 0xc90fe0: LoadField: r2 = r0->field_7
    //     0xc90fe0: ldur            x2, [x0, #7]
    // 0xc90fe4: mov             x0, x2
    // 0xc90fe8: cmp             x1, x0
    // 0xc90fec: b.ne            #0xc92884
    // 0xc90ff0: ldr             x1, [fp, #0x18]
    // 0xc90ff4: ldr             x0, [fp, #0x10]
    // 0xc90ff8: b               #0xc9102c
    // 0xc90ffc: mov             x0, x3
    // 0xc91000: r1 = LoadClassIdInstr(r2)
    //     0xc91000: ldur            x1, [x2, #-1]
    //     0xc91004: ubfx            x1, x1, #0xc, #0x14
    // 0xc91008: stp             x0, x2, [SP, #-0x10]!
    // 0xc9100c: mov             x0, x1
    // 0xc91010: mov             lr, x0
    // 0xc91014: ldr             lr, [x21, lr, lsl #3]
    // 0xc91018: blr             lr
    // 0xc9101c: add             SP, SP, #0x10
    // 0xc91020: tbnz            w0, #4, #0xc92884
    // 0xc91024: ldr             x1, [fp, #0x18]
    // 0xc91028: ldr             x0, [fp, #0x10]
    // 0xc9102c: LoadField: r2 = r0->field_67
    //     0xc9102c: ldur            w2, [x0, #0x67]
    // 0xc91030: DecompressPointer r2
    //     0xc91030: add             x2, x2, HEAP, lsl #32
    // 0xc91034: stur            x2, [fp, #-0x18]
    // 0xc91038: LoadField: r3 = r1->field_67
    //     0xc91038: ldur            w3, [x1, #0x67]
    // 0xc9103c: DecompressPointer r3
    //     0xc9103c: add             x3, x3, HEAP, lsl #32
    // 0xc91040: stur            x3, [fp, #-0x10]
    // 0xc91044: r4 = LoadClassIdInstr(r2)
    //     0xc91044: ldur            x4, [x2, #-1]
    //     0xc91048: ubfx            x4, x4, #0xc, #0x14
    // 0xc9104c: lsl             x4, x4, #1
    // 0xc91050: stur            x4, [fp, #-8]
    // 0xc91054: r17 = 10114
    //     0xc91054: mov             x17, #0x2782
    // 0xc91058: cmp             w4, w17
    // 0xc9105c: b.eq            #0xc9106c
    // 0xc91060: r17 = 10118
    //     0xc91060: mov             x17, #0x2786
    // 0xc91064: cmp             w4, w17
    // 0xc91068: b.ne            #0xc91144
    // 0xc9106c: cmp             w2, w3
    // 0xc91070: b.eq            #0xc91174
    // 0xc91074: stp             x2, x3, [SP, #-0x10]!
    // 0xc91078: r0 = _haveSameRuntimeType()
    //     0xc91078: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc9107c: add             SP, SP, #0x10
    // 0xc91080: tbnz            w0, #4, #0xc92884
    // 0xc91084: ldur            x0, [fp, #-0x10]
    // 0xc91088: r1 = LoadClassIdInstr(r0)
    //     0xc91088: ldur            x1, [x0, #-1]
    //     0xc9108c: ubfx            x1, x1, #0xc, #0x14
    // 0xc91090: lsl             x1, x1, #1
    // 0xc91094: r17 = 10124
    //     0xc91094: mov             x17, #0x278c
    // 0xc91098: cmp             w1, w17
    // 0xc9109c: b.gt            #0xc910ac
    // 0xc910a0: r17 = 10122
    //     0xc910a0: mov             x17, #0x278a
    // 0xc910a4: cmp             w1, w17
    // 0xc910a8: b.ge            #0xc910c4
    // 0xc910ac: r17 = 10114
    //     0xc910ac: mov             x17, #0x2782
    // 0xc910b0: cmp             w1, w17
    // 0xc910b4: b.eq            #0xc910c4
    // 0xc910b8: r17 = 10118
    //     0xc910b8: mov             x17, #0x2786
    // 0xc910bc: cmp             w1, w17
    // 0xc910c0: b.ne            #0xc910cc
    // 0xc910c4: LoadField: r1 = r0->field_7
    //     0xc910c4: ldur            x1, [x0, #7]
    // 0xc910c8: b               #0xc910dc
    // 0xc910cc: LoadField: r1 = r0->field_f
    //     0xc910cc: ldur            w1, [x0, #0xf]
    // 0xc910d0: DecompressPointer r1
    //     0xc910d0: add             x1, x1, HEAP, lsl #32
    // 0xc910d4: LoadField: r0 = r1->field_7
    //     0xc910d4: ldur            x0, [x1, #7]
    // 0xc910d8: mov             x1, x0
    // 0xc910dc: ldur            x0, [fp, #-8]
    // 0xc910e0: r17 = 10124
    //     0xc910e0: mov             x17, #0x278c
    // 0xc910e4: cmp             w0, w17
    // 0xc910e8: b.gt            #0xc910f8
    // 0xc910ec: r17 = 10122
    //     0xc910ec: mov             x17, #0x278a
    // 0xc910f0: cmp             w0, w17
    // 0xc910f4: b.ge            #0xc91110
    // 0xc910f8: r17 = 10114
    //     0xc910f8: mov             x17, #0x2782
    // 0xc910fc: cmp             w0, w17
    // 0xc91100: b.eq            #0xc91110
    // 0xc91104: r17 = 10118
    //     0xc91104: mov             x17, #0x2786
    // 0xc91108: cmp             w0, w17
    // 0xc9110c: b.ne            #0xc9111c
    // 0xc91110: ldur            x2, [fp, #-0x18]
    // 0xc91114: LoadField: r0 = r2->field_7
    //     0xc91114: ldur            x0, [x2, #7]
    // 0xc91118: b               #0xc91130
    // 0xc9111c: ldur            x2, [fp, #-0x18]
    // 0xc91120: LoadField: r0 = r2->field_f
    //     0xc91120: ldur            w0, [x2, #0xf]
    // 0xc91124: DecompressPointer r0
    //     0xc91124: add             x0, x0, HEAP, lsl #32
    // 0xc91128: LoadField: r2 = r0->field_7
    //     0xc91128: ldur            x2, [x0, #7]
    // 0xc9112c: mov             x0, x2
    // 0xc91130: cmp             x1, x0
    // 0xc91134: b.ne            #0xc92884
    // 0xc91138: ldr             x1, [fp, #0x18]
    // 0xc9113c: ldr             x0, [fp, #0x10]
    // 0xc91140: b               #0xc91174
    // 0xc91144: mov             x0, x3
    // 0xc91148: r1 = LoadClassIdInstr(r2)
    //     0xc91148: ldur            x1, [x2, #-1]
    //     0xc9114c: ubfx            x1, x1, #0xc, #0x14
    // 0xc91150: stp             x0, x2, [SP, #-0x10]!
    // 0xc91154: mov             x0, x1
    // 0xc91158: mov             lr, x0
    // 0xc9115c: ldr             lr, [x21, lr, lsl #3]
    // 0xc91160: blr             lr
    // 0xc91164: add             SP, SP, #0x10
    // 0xc91168: tbnz            w0, #4, #0xc92884
    // 0xc9116c: ldr             x1, [fp, #0x18]
    // 0xc91170: ldr             x0, [fp, #0x10]
    // 0xc91174: LoadField: r2 = r0->field_6b
    //     0xc91174: ldur            w2, [x0, #0x6b]
    // 0xc91178: DecompressPointer r2
    //     0xc91178: add             x2, x2, HEAP, lsl #32
    // 0xc9117c: stur            x2, [fp, #-0x18]
    // 0xc91180: LoadField: r3 = r1->field_6b
    //     0xc91180: ldur            w3, [x1, #0x6b]
    // 0xc91184: DecompressPointer r3
    //     0xc91184: add             x3, x3, HEAP, lsl #32
    // 0xc91188: stur            x3, [fp, #-0x10]
    // 0xc9118c: r4 = LoadClassIdInstr(r2)
    //     0xc9118c: ldur            x4, [x2, #-1]
    //     0xc91190: ubfx            x4, x4, #0xc, #0x14
    // 0xc91194: lsl             x4, x4, #1
    // 0xc91198: stur            x4, [fp, #-8]
    // 0xc9119c: r17 = 10114
    //     0xc9119c: mov             x17, #0x2782
    // 0xc911a0: cmp             w4, w17
    // 0xc911a4: b.eq            #0xc911b4
    // 0xc911a8: r17 = 10118
    //     0xc911a8: mov             x17, #0x2786
    // 0xc911ac: cmp             w4, w17
    // 0xc911b0: b.ne            #0xc9128c
    // 0xc911b4: cmp             w2, w3
    // 0xc911b8: b.eq            #0xc912bc
    // 0xc911bc: stp             x2, x3, [SP, #-0x10]!
    // 0xc911c0: r0 = _haveSameRuntimeType()
    //     0xc911c0: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc911c4: add             SP, SP, #0x10
    // 0xc911c8: tbnz            w0, #4, #0xc92884
    // 0xc911cc: ldur            x0, [fp, #-0x10]
    // 0xc911d0: r1 = LoadClassIdInstr(r0)
    //     0xc911d0: ldur            x1, [x0, #-1]
    //     0xc911d4: ubfx            x1, x1, #0xc, #0x14
    // 0xc911d8: lsl             x1, x1, #1
    // 0xc911dc: r17 = 10124
    //     0xc911dc: mov             x17, #0x278c
    // 0xc911e0: cmp             w1, w17
    // 0xc911e4: b.gt            #0xc911f4
    // 0xc911e8: r17 = 10122
    //     0xc911e8: mov             x17, #0x278a
    // 0xc911ec: cmp             w1, w17
    // 0xc911f0: b.ge            #0xc9120c
    // 0xc911f4: r17 = 10114
    //     0xc911f4: mov             x17, #0x2782
    // 0xc911f8: cmp             w1, w17
    // 0xc911fc: b.eq            #0xc9120c
    // 0xc91200: r17 = 10118
    //     0xc91200: mov             x17, #0x2786
    // 0xc91204: cmp             w1, w17
    // 0xc91208: b.ne            #0xc91214
    // 0xc9120c: LoadField: r1 = r0->field_7
    //     0xc9120c: ldur            x1, [x0, #7]
    // 0xc91210: b               #0xc91224
    // 0xc91214: LoadField: r1 = r0->field_f
    //     0xc91214: ldur            w1, [x0, #0xf]
    // 0xc91218: DecompressPointer r1
    //     0xc91218: add             x1, x1, HEAP, lsl #32
    // 0xc9121c: LoadField: r0 = r1->field_7
    //     0xc9121c: ldur            x0, [x1, #7]
    // 0xc91220: mov             x1, x0
    // 0xc91224: ldur            x0, [fp, #-8]
    // 0xc91228: r17 = 10124
    //     0xc91228: mov             x17, #0x278c
    // 0xc9122c: cmp             w0, w17
    // 0xc91230: b.gt            #0xc91240
    // 0xc91234: r17 = 10122
    //     0xc91234: mov             x17, #0x278a
    // 0xc91238: cmp             w0, w17
    // 0xc9123c: b.ge            #0xc91258
    // 0xc91240: r17 = 10114
    //     0xc91240: mov             x17, #0x2782
    // 0xc91244: cmp             w0, w17
    // 0xc91248: b.eq            #0xc91258
    // 0xc9124c: r17 = 10118
    //     0xc9124c: mov             x17, #0x2786
    // 0xc91250: cmp             w0, w17
    // 0xc91254: b.ne            #0xc91264
    // 0xc91258: ldur            x2, [fp, #-0x18]
    // 0xc9125c: LoadField: r0 = r2->field_7
    //     0xc9125c: ldur            x0, [x2, #7]
    // 0xc91260: b               #0xc91278
    // 0xc91264: ldur            x2, [fp, #-0x18]
    // 0xc91268: LoadField: r0 = r2->field_f
    //     0xc91268: ldur            w0, [x2, #0xf]
    // 0xc9126c: DecompressPointer r0
    //     0xc9126c: add             x0, x0, HEAP, lsl #32
    // 0xc91270: LoadField: r2 = r0->field_7
    //     0xc91270: ldur            x2, [x0, #7]
    // 0xc91274: mov             x0, x2
    // 0xc91278: cmp             x1, x0
    // 0xc9127c: b.ne            #0xc92884
    // 0xc91280: ldr             x1, [fp, #0x18]
    // 0xc91284: ldr             x0, [fp, #0x10]
    // 0xc91288: b               #0xc912bc
    // 0xc9128c: mov             x0, x3
    // 0xc91290: r1 = LoadClassIdInstr(r2)
    //     0xc91290: ldur            x1, [x2, #-1]
    //     0xc91294: ubfx            x1, x1, #0xc, #0x14
    // 0xc91298: stp             x0, x2, [SP, #-0x10]!
    // 0xc9129c: mov             x0, x1
    // 0xc912a0: mov             lr, x0
    // 0xc912a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc912a8: blr             lr
    // 0xc912ac: add             SP, SP, #0x10
    // 0xc912b0: tbnz            w0, #4, #0xc92884
    // 0xc912b4: ldr             x1, [fp, #0x18]
    // 0xc912b8: ldr             x0, [fp, #0x10]
    // 0xc912bc: LoadField: r2 = r0->field_6f
    //     0xc912bc: ldur            w2, [x0, #0x6f]
    // 0xc912c0: DecompressPointer r2
    //     0xc912c0: add             x2, x2, HEAP, lsl #32
    // 0xc912c4: stur            x2, [fp, #-0x18]
    // 0xc912c8: LoadField: r3 = r1->field_6f
    //     0xc912c8: ldur            w3, [x1, #0x6f]
    // 0xc912cc: DecompressPointer r3
    //     0xc912cc: add             x3, x3, HEAP, lsl #32
    // 0xc912d0: stur            x3, [fp, #-0x10]
    // 0xc912d4: r4 = LoadClassIdInstr(r2)
    //     0xc912d4: ldur            x4, [x2, #-1]
    //     0xc912d8: ubfx            x4, x4, #0xc, #0x14
    // 0xc912dc: lsl             x4, x4, #1
    // 0xc912e0: stur            x4, [fp, #-8]
    // 0xc912e4: r17 = 10114
    //     0xc912e4: mov             x17, #0x2782
    // 0xc912e8: cmp             w4, w17
    // 0xc912ec: b.eq            #0xc912fc
    // 0xc912f0: r17 = 10118
    //     0xc912f0: mov             x17, #0x2786
    // 0xc912f4: cmp             w4, w17
    // 0xc912f8: b.ne            #0xc913d4
    // 0xc912fc: cmp             w2, w3
    // 0xc91300: b.eq            #0xc91404
    // 0xc91304: stp             x2, x3, [SP, #-0x10]!
    // 0xc91308: r0 = _haveSameRuntimeType()
    //     0xc91308: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc9130c: add             SP, SP, #0x10
    // 0xc91310: tbnz            w0, #4, #0xc92884
    // 0xc91314: ldur            x0, [fp, #-0x10]
    // 0xc91318: r1 = LoadClassIdInstr(r0)
    //     0xc91318: ldur            x1, [x0, #-1]
    //     0xc9131c: ubfx            x1, x1, #0xc, #0x14
    // 0xc91320: lsl             x1, x1, #1
    // 0xc91324: r17 = 10124
    //     0xc91324: mov             x17, #0x278c
    // 0xc91328: cmp             w1, w17
    // 0xc9132c: b.gt            #0xc9133c
    // 0xc91330: r17 = 10122
    //     0xc91330: mov             x17, #0x278a
    // 0xc91334: cmp             w1, w17
    // 0xc91338: b.ge            #0xc91354
    // 0xc9133c: r17 = 10114
    //     0xc9133c: mov             x17, #0x2782
    // 0xc91340: cmp             w1, w17
    // 0xc91344: b.eq            #0xc91354
    // 0xc91348: r17 = 10118
    //     0xc91348: mov             x17, #0x2786
    // 0xc9134c: cmp             w1, w17
    // 0xc91350: b.ne            #0xc9135c
    // 0xc91354: LoadField: r1 = r0->field_7
    //     0xc91354: ldur            x1, [x0, #7]
    // 0xc91358: b               #0xc9136c
    // 0xc9135c: LoadField: r1 = r0->field_f
    //     0xc9135c: ldur            w1, [x0, #0xf]
    // 0xc91360: DecompressPointer r1
    //     0xc91360: add             x1, x1, HEAP, lsl #32
    // 0xc91364: LoadField: r0 = r1->field_7
    //     0xc91364: ldur            x0, [x1, #7]
    // 0xc91368: mov             x1, x0
    // 0xc9136c: ldur            x0, [fp, #-8]
    // 0xc91370: r17 = 10124
    //     0xc91370: mov             x17, #0x278c
    // 0xc91374: cmp             w0, w17
    // 0xc91378: b.gt            #0xc91388
    // 0xc9137c: r17 = 10122
    //     0xc9137c: mov             x17, #0x278a
    // 0xc91380: cmp             w0, w17
    // 0xc91384: b.ge            #0xc913a0
    // 0xc91388: r17 = 10114
    //     0xc91388: mov             x17, #0x2782
    // 0xc9138c: cmp             w0, w17
    // 0xc91390: b.eq            #0xc913a0
    // 0xc91394: r17 = 10118
    //     0xc91394: mov             x17, #0x2786
    // 0xc91398: cmp             w0, w17
    // 0xc9139c: b.ne            #0xc913ac
    // 0xc913a0: ldur            x2, [fp, #-0x18]
    // 0xc913a4: LoadField: r0 = r2->field_7
    //     0xc913a4: ldur            x0, [x2, #7]
    // 0xc913a8: b               #0xc913c0
    // 0xc913ac: ldur            x2, [fp, #-0x18]
    // 0xc913b0: LoadField: r0 = r2->field_f
    //     0xc913b0: ldur            w0, [x2, #0xf]
    // 0xc913b4: DecompressPointer r0
    //     0xc913b4: add             x0, x0, HEAP, lsl #32
    // 0xc913b8: LoadField: r2 = r0->field_7
    //     0xc913b8: ldur            x2, [x0, #7]
    // 0xc913bc: mov             x0, x2
    // 0xc913c0: cmp             x1, x0
    // 0xc913c4: b.ne            #0xc92884
    // 0xc913c8: ldr             x1, [fp, #0x18]
    // 0xc913cc: ldr             x0, [fp, #0x10]
    // 0xc913d0: b               #0xc91404
    // 0xc913d4: mov             x0, x3
    // 0xc913d8: r1 = LoadClassIdInstr(r2)
    //     0xc913d8: ldur            x1, [x2, #-1]
    //     0xc913dc: ubfx            x1, x1, #0xc, #0x14
    // 0xc913e0: stp             x0, x2, [SP, #-0x10]!
    // 0xc913e4: mov             x0, x1
    // 0xc913e8: mov             lr, x0
    // 0xc913ec: ldr             lr, [x21, lr, lsl #3]
    // 0xc913f0: blr             lr
    // 0xc913f4: add             SP, SP, #0x10
    // 0xc913f8: tbnz            w0, #4, #0xc92884
    // 0xc913fc: ldr             x1, [fp, #0x18]
    // 0xc91400: ldr             x0, [fp, #0x10]
    // 0xc91404: LoadField: r2 = r0->field_73
    //     0xc91404: ldur            w2, [x0, #0x73]
    // 0xc91408: DecompressPointer r2
    //     0xc91408: add             x2, x2, HEAP, lsl #32
    // 0xc9140c: stur            x2, [fp, #-0x18]
    // 0xc91410: LoadField: r3 = r1->field_73
    //     0xc91410: ldur            w3, [x1, #0x73]
    // 0xc91414: DecompressPointer r3
    //     0xc91414: add             x3, x3, HEAP, lsl #32
    // 0xc91418: stur            x3, [fp, #-0x10]
    // 0xc9141c: r4 = LoadClassIdInstr(r2)
    //     0xc9141c: ldur            x4, [x2, #-1]
    //     0xc91420: ubfx            x4, x4, #0xc, #0x14
    // 0xc91424: lsl             x4, x4, #1
    // 0xc91428: stur            x4, [fp, #-8]
    // 0xc9142c: r17 = 10114
    //     0xc9142c: mov             x17, #0x2782
    // 0xc91430: cmp             w4, w17
    // 0xc91434: b.eq            #0xc91444
    // 0xc91438: r17 = 10118
    //     0xc91438: mov             x17, #0x2786
    // 0xc9143c: cmp             w4, w17
    // 0xc91440: b.ne            #0xc9151c
    // 0xc91444: cmp             w2, w3
    // 0xc91448: b.eq            #0xc9154c
    // 0xc9144c: stp             x2, x3, [SP, #-0x10]!
    // 0xc91450: r0 = _haveSameRuntimeType()
    //     0xc91450: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc91454: add             SP, SP, #0x10
    // 0xc91458: tbnz            w0, #4, #0xc92884
    // 0xc9145c: ldur            x0, [fp, #-0x10]
    // 0xc91460: r1 = LoadClassIdInstr(r0)
    //     0xc91460: ldur            x1, [x0, #-1]
    //     0xc91464: ubfx            x1, x1, #0xc, #0x14
    // 0xc91468: lsl             x1, x1, #1
    // 0xc9146c: r17 = 10124
    //     0xc9146c: mov             x17, #0x278c
    // 0xc91470: cmp             w1, w17
    // 0xc91474: b.gt            #0xc91484
    // 0xc91478: r17 = 10122
    //     0xc91478: mov             x17, #0x278a
    // 0xc9147c: cmp             w1, w17
    // 0xc91480: b.ge            #0xc9149c
    // 0xc91484: r17 = 10114
    //     0xc91484: mov             x17, #0x2782
    // 0xc91488: cmp             w1, w17
    // 0xc9148c: b.eq            #0xc9149c
    // 0xc91490: r17 = 10118
    //     0xc91490: mov             x17, #0x2786
    // 0xc91494: cmp             w1, w17
    // 0xc91498: b.ne            #0xc914a4
    // 0xc9149c: LoadField: r1 = r0->field_7
    //     0xc9149c: ldur            x1, [x0, #7]
    // 0xc914a0: b               #0xc914b4
    // 0xc914a4: LoadField: r1 = r0->field_f
    //     0xc914a4: ldur            w1, [x0, #0xf]
    // 0xc914a8: DecompressPointer r1
    //     0xc914a8: add             x1, x1, HEAP, lsl #32
    // 0xc914ac: LoadField: r0 = r1->field_7
    //     0xc914ac: ldur            x0, [x1, #7]
    // 0xc914b0: mov             x1, x0
    // 0xc914b4: ldur            x0, [fp, #-8]
    // 0xc914b8: r17 = 10124
    //     0xc914b8: mov             x17, #0x278c
    // 0xc914bc: cmp             w0, w17
    // 0xc914c0: b.gt            #0xc914d0
    // 0xc914c4: r17 = 10122
    //     0xc914c4: mov             x17, #0x278a
    // 0xc914c8: cmp             w0, w17
    // 0xc914cc: b.ge            #0xc914e8
    // 0xc914d0: r17 = 10114
    //     0xc914d0: mov             x17, #0x2782
    // 0xc914d4: cmp             w0, w17
    // 0xc914d8: b.eq            #0xc914e8
    // 0xc914dc: r17 = 10118
    //     0xc914dc: mov             x17, #0x2786
    // 0xc914e0: cmp             w0, w17
    // 0xc914e4: b.ne            #0xc914f4
    // 0xc914e8: ldur            x2, [fp, #-0x18]
    // 0xc914ec: LoadField: r0 = r2->field_7
    //     0xc914ec: ldur            x0, [x2, #7]
    // 0xc914f0: b               #0xc91508
    // 0xc914f4: ldur            x2, [fp, #-0x18]
    // 0xc914f8: LoadField: r0 = r2->field_f
    //     0xc914f8: ldur            w0, [x2, #0xf]
    // 0xc914fc: DecompressPointer r0
    //     0xc914fc: add             x0, x0, HEAP, lsl #32
    // 0xc91500: LoadField: r2 = r0->field_7
    //     0xc91500: ldur            x2, [x0, #7]
    // 0xc91504: mov             x0, x2
    // 0xc91508: cmp             x1, x0
    // 0xc9150c: b.ne            #0xc92884
    // 0xc91510: ldr             x1, [fp, #0x18]
    // 0xc91514: ldr             x0, [fp, #0x10]
    // 0xc91518: b               #0xc9154c
    // 0xc9151c: mov             x0, x3
    // 0xc91520: r1 = LoadClassIdInstr(r2)
    //     0xc91520: ldur            x1, [x2, #-1]
    //     0xc91524: ubfx            x1, x1, #0xc, #0x14
    // 0xc91528: stp             x0, x2, [SP, #-0x10]!
    // 0xc9152c: mov             x0, x1
    // 0xc91530: mov             lr, x0
    // 0xc91534: ldr             lr, [x21, lr, lsl #3]
    // 0xc91538: blr             lr
    // 0xc9153c: add             SP, SP, #0x10
    // 0xc91540: tbnz            w0, #4, #0xc92884
    // 0xc91544: ldr             x1, [fp, #0x18]
    // 0xc91548: ldr             x0, [fp, #0x10]
    // 0xc9154c: LoadField: r2 = r0->field_7b
    //     0xc9154c: ldur            w2, [x0, #0x7b]
    // 0xc91550: DecompressPointer r2
    //     0xc91550: add             x2, x2, HEAP, lsl #32
    // 0xc91554: stur            x2, [fp, #-0x10]
    // 0xc91558: LoadField: r3 = r1->field_7b
    //     0xc91558: ldur            w3, [x1, #0x7b]
    // 0xc9155c: DecompressPointer r3
    //     0xc9155c: add             x3, x3, HEAP, lsl #32
    // 0xc91560: stur            x3, [fp, #-8]
    // 0xc91564: cmp             w2, w3
    // 0xc91568: b.eq            #0xc915ac
    // 0xc9156c: r16 = Color
    //     0xc9156c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc91570: ldr             x16, [x16, #0xf18]
    // 0xc91574: r30 = Color
    //     0xc91574: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc91578: ldr             lr, [lr, #0xf18]
    // 0xc9157c: stp             lr, x16, [SP, #-0x10]!
    // 0xc91580: r0 = ==()
    //     0xc91580: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc91584: add             SP, SP, #0x10
    // 0xc91588: tbnz            w0, #4, #0xc92884
    // 0xc9158c: ldur            x0, [fp, #-0x10]
    // 0xc91590: ldur            x1, [fp, #-8]
    // 0xc91594: LoadField: r2 = r1->field_7
    //     0xc91594: ldur            x2, [x1, #7]
    // 0xc91598: LoadField: r1 = r0->field_7
    //     0xc91598: ldur            x1, [x0, #7]
    // 0xc9159c: cmp             x2, x1
    // 0xc915a0: b.ne            #0xc92884
    // 0xc915a4: ldr             x1, [fp, #0x18]
    // 0xc915a8: ldr             x0, [fp, #0x10]
    // 0xc915ac: LoadField: r2 = r0->field_7f
    //     0xc915ac: ldur            w2, [x0, #0x7f]
    // 0xc915b0: DecompressPointer r2
    //     0xc915b0: add             x2, x2, HEAP, lsl #32
    // 0xc915b4: stur            x2, [fp, #-0x10]
    // 0xc915b8: LoadField: r3 = r1->field_7f
    //     0xc915b8: ldur            w3, [x1, #0x7f]
    // 0xc915bc: DecompressPointer r3
    //     0xc915bc: add             x3, x3, HEAP, lsl #32
    // 0xc915c0: stur            x3, [fp, #-8]
    // 0xc915c4: cmp             w2, w3
    // 0xc915c8: b.eq            #0xc9160c
    // 0xc915cc: r16 = Color
    //     0xc915cc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc915d0: ldr             x16, [x16, #0xf18]
    // 0xc915d4: r30 = Color
    //     0xc915d4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc915d8: ldr             lr, [lr, #0xf18]
    // 0xc915dc: stp             lr, x16, [SP, #-0x10]!
    // 0xc915e0: r0 = ==()
    //     0xc915e0: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc915e4: add             SP, SP, #0x10
    // 0xc915e8: tbnz            w0, #4, #0xc92884
    // 0xc915ec: ldur            x0, [fp, #-0x10]
    // 0xc915f0: ldur            x1, [fp, #-8]
    // 0xc915f4: LoadField: r2 = r1->field_7
    //     0xc915f4: ldur            x2, [x1, #7]
    // 0xc915f8: LoadField: r1 = r0->field_7
    //     0xc915f8: ldur            x1, [x0, #7]
    // 0xc915fc: cmp             x2, x1
    // 0xc91600: b.ne            #0xc92884
    // 0xc91604: ldr             x1, [fp, #0x18]
    // 0xc91608: ldr             x0, [fp, #0x10]
    // 0xc9160c: LoadField: r2 = r0->field_83
    //     0xc9160c: ldur            w2, [x0, #0x83]
    // 0xc91610: DecompressPointer r2
    //     0xc91610: add             x2, x2, HEAP, lsl #32
    // 0xc91614: stur            x2, [fp, #-0x10]
    // 0xc91618: LoadField: r3 = r1->field_83
    //     0xc91618: ldur            w3, [x1, #0x83]
    // 0xc9161c: DecompressPointer r3
    //     0xc9161c: add             x3, x3, HEAP, lsl #32
    // 0xc91620: stur            x3, [fp, #-8]
    // 0xc91624: cmp             w2, w3
    // 0xc91628: b.eq            #0xc9166c
    // 0xc9162c: r16 = Color
    //     0xc9162c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc91630: ldr             x16, [x16, #0xf18]
    // 0xc91634: r30 = Color
    //     0xc91634: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc91638: ldr             lr, [lr, #0xf18]
    // 0xc9163c: stp             lr, x16, [SP, #-0x10]!
    // 0xc91640: r0 = ==()
    //     0xc91640: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc91644: add             SP, SP, #0x10
    // 0xc91648: tbnz            w0, #4, #0xc92884
    // 0xc9164c: ldur            x0, [fp, #-0x10]
    // 0xc91650: ldur            x1, [fp, #-8]
    // 0xc91654: LoadField: r2 = r1->field_7
    //     0xc91654: ldur            x2, [x1, #7]
    // 0xc91658: LoadField: r1 = r0->field_7
    //     0xc91658: ldur            x1, [x0, #7]
    // 0xc9165c: cmp             x2, x1
    // 0xc91660: b.ne            #0xc92884
    // 0xc91664: ldr             x1, [fp, #0x18]
    // 0xc91668: ldr             x0, [fp, #0x10]
    // 0xc9166c: LoadField: r2 = r0->field_87
    //     0xc9166c: ldur            w2, [x0, #0x87]
    // 0xc91670: DecompressPointer r2
    //     0xc91670: add             x2, x2, HEAP, lsl #32
    // 0xc91674: LoadField: r3 = r1->field_87
    //     0xc91674: ldur            w3, [x1, #0x87]
    // 0xc91678: DecompressPointer r3
    //     0xc91678: add             x3, x3, HEAP, lsl #32
    // 0xc9167c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91680: r0 = ==()
    //     0xc91680: bl              #0xc811ec  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::==
    // 0xc91684: add             SP, SP, #0x10
    // 0xc91688: tbnz            w0, #4, #0xc92884
    // 0xc9168c: ldr             x1, [fp, #0x18]
    // 0xc91690: ldr             x0, [fp, #0x10]
    // 0xc91694: LoadField: r2 = r0->field_8b
    //     0xc91694: ldur            w2, [x0, #0x8b]
    // 0xc91698: DecompressPointer r2
    //     0xc91698: add             x2, x2, HEAP, lsl #32
    // 0xc9169c: LoadField: r3 = r1->field_8b
    //     0xc9169c: ldur            w3, [x1, #0x8b]
    // 0xc916a0: DecompressPointer r3
    //     0xc916a0: add             x3, x3, HEAP, lsl #32
    // 0xc916a4: stp             x3, x2, [SP, #-0x10]!
    // 0xc916a8: r0 = ==()
    //     0xc916a8: bl              #0xc811ec  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::==
    // 0xc916ac: add             SP, SP, #0x10
    // 0xc916b0: tbnz            w0, #4, #0xc92884
    // 0xc916b4: ldr             x1, [fp, #0x18]
    // 0xc916b8: ldr             x0, [fp, #0x10]
    // 0xc916bc: LoadField: r2 = r0->field_8f
    //     0xc916bc: ldur            w2, [x0, #0x8f]
    // 0xc916c0: DecompressPointer r2
    //     0xc916c0: add             x2, x2, HEAP, lsl #32
    // 0xc916c4: LoadField: r3 = r1->field_8f
    //     0xc916c4: ldur            w3, [x1, #0x8f]
    // 0xc916c8: DecompressPointer r3
    //     0xc916c8: add             x3, x3, HEAP, lsl #32
    // 0xc916cc: stp             x3, x2, [SP, #-0x10]!
    // 0xc916d0: r0 = ==()
    //     0xc916d0: bl              #0xc900e8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0xc916d4: add             SP, SP, #0x10
    // 0xc916d8: tbnz            w0, #4, #0xc92884
    // 0xc916dc: ldr             x1, [fp, #0x18]
    // 0xc916e0: ldr             x0, [fp, #0x10]
    // 0xc916e4: LoadField: r2 = r0->field_93
    //     0xc916e4: ldur            w2, [x0, #0x93]
    // 0xc916e8: DecompressPointer r2
    //     0xc916e8: add             x2, x2, HEAP, lsl #32
    // 0xc916ec: LoadField: r3 = r1->field_93
    //     0xc916ec: ldur            w3, [x1, #0x93]
    // 0xc916f0: DecompressPointer r3
    //     0xc916f0: add             x3, x3, HEAP, lsl #32
    // 0xc916f4: stp             x3, x2, [SP, #-0x10]!
    // 0xc916f8: r0 = ==()
    //     0xc916f8: bl              #0xc900e8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0xc916fc: add             SP, SP, #0x10
    // 0xc91700: tbnz            w0, #4, #0xc92884
    // 0xc91704: ldr             x1, [fp, #0x18]
    // 0xc91708: ldr             x0, [fp, #0x10]
    // 0xc9170c: LoadField: r2 = r0->field_97
    //     0xc9170c: ldur            w2, [x0, #0x97]
    // 0xc91710: DecompressPointer r2
    //     0xc91710: add             x2, x2, HEAP, lsl #32
    // 0xc91714: LoadField: r3 = r1->field_97
    //     0xc91714: ldur            w3, [x1, #0x97]
    // 0xc91718: DecompressPointer r3
    //     0xc91718: add             x3, x3, HEAP, lsl #32
    // 0xc9171c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91720: r0 = ==()
    //     0xc91720: bl              #0xc92da0  ; [package:flutter/src/material/typography.dart] Typography::==
    // 0xc91724: add             SP, SP, #0x10
    // 0xc91728: tbnz            w0, #4, #0xc92884
    // 0xc9172c: ldr             x1, [fp, #0x18]
    // 0xc91730: ldr             x0, [fp, #0x10]
    // 0xc91734: LoadField: r2 = r0->field_9b
    //     0xc91734: ldur            w2, [x0, #0x9b]
    // 0xc91738: DecompressPointer r2
    //     0xc91738: add             x2, x2, HEAP, lsl #32
    // 0xc9173c: LoadField: r3 = r1->field_9b
    //     0xc9173c: ldur            w3, [x1, #0x9b]
    // 0xc91740: DecompressPointer r3
    //     0xc91740: add             x3, x3, HEAP, lsl #32
    // 0xc91744: stp             x3, x2, [SP, #-0x10]!
    // 0xc91748: r0 = ==()
    //     0xc91748: bl              #0xc8262c  ; [package:flutter/src/material/app_bar_theme.dart] AppBarTheme::==
    // 0xc9174c: add             SP, SP, #0x10
    // 0xc91750: tbnz            w0, #4, #0xc92884
    // 0xc91754: ldr             x1, [fp, #0x18]
    // 0xc91758: ldr             x0, [fp, #0x10]
    // 0xc9175c: LoadField: r2 = r0->field_9f
    //     0xc9175c: ldur            w2, [x0, #0x9f]
    // 0xc91760: DecompressPointer r2
    //     0xc91760: add             x2, x2, HEAP, lsl #32
    // 0xc91764: LoadField: r3 = r1->field_9f
    //     0xc91764: ldur            w3, [x1, #0x9f]
    // 0xc91768: DecompressPointer r3
    //     0xc91768: add             x3, x3, HEAP, lsl #32
    // 0xc9176c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91770: r0 = ==()
    //     0xc91770: bl              #0xc833c0  ; [package:flutter/src/material/badge_theme.dart] BadgeThemeData::==
    // 0xc91774: add             SP, SP, #0x10
    // 0xc91778: tbnz            w0, #4, #0xc92884
    // 0xc9177c: ldr             x1, [fp, #0x18]
    // 0xc91780: ldr             x0, [fp, #0x10]
    // 0xc91784: LoadField: r2 = r0->field_a3
    //     0xc91784: ldur            w2, [x0, #0xa3]
    // 0xc91788: DecompressPointer r2
    //     0xc91788: add             x2, x2, HEAP, lsl #32
    // 0xc9178c: LoadField: r3 = r1->field_a3
    //     0xc9178c: ldur            w3, [x1, #0xa3]
    // 0xc91790: DecompressPointer r3
    //     0xc91790: add             x3, x3, HEAP, lsl #32
    // 0xc91794: stp             x3, x2, [SP, #-0x10]!
    // 0xc91798: r0 = ==()
    //     0xc91798: bl              #0xc83528  ; [package:flutter/src/material/banner_theme.dart] MaterialBannerThemeData::==
    // 0xc9179c: add             SP, SP, #0x10
    // 0xc917a0: tbnz            w0, #4, #0xc92884
    // 0xc917a4: ldr             x1, [fp, #0x18]
    // 0xc917a8: ldr             x0, [fp, #0x10]
    // 0xc917ac: LoadField: r2 = r0->field_a7
    //     0xc917ac: ldur            w2, [x0, #0xa7]
    // 0xc917b0: DecompressPointer r2
    //     0xc917b0: add             x2, x2, HEAP, lsl #32
    // 0xc917b4: LoadField: r3 = r1->field_a7
    //     0xc917b4: ldur            w3, [x1, #0xa7]
    // 0xc917b8: DecompressPointer r3
    //     0xc917b8: add             x3, x3, HEAP, lsl #32
    // 0xc917bc: stp             x3, x2, [SP, #-0x10]!
    // 0xc917c0: r0 = ==()
    //     0xc917c0: bl              #0xc83654  ; [package:flutter/src/material/bottom_app_bar_theme.dart] BottomAppBarTheme::==
    // 0xc917c4: add             SP, SP, #0x10
    // 0xc917c8: tbnz            w0, #4, #0xc92884
    // 0xc917cc: ldr             x1, [fp, #0x18]
    // 0xc917d0: ldr             x0, [fp, #0x10]
    // 0xc917d4: LoadField: r2 = r0->field_ab
    //     0xc917d4: ldur            w2, [x0, #0xab]
    // 0xc917d8: DecompressPointer r2
    //     0xc917d8: add             x2, x2, HEAP, lsl #32
    // 0xc917dc: LoadField: r3 = r1->field_ab
    //     0xc917dc: ldur            w3, [x1, #0xab]
    // 0xc917e0: DecompressPointer r3
    //     0xc917e0: add             x3, x3, HEAP, lsl #32
    // 0xc917e4: stp             x3, x2, [SP, #-0x10]!
    // 0xc917e8: r0 = ==()
    //     0xc917e8: bl              #0xc837bc  ; [package:flutter/src/material/bottom_navigation_bar_theme.dart] BottomNavigationBarThemeData::==
    // 0xc917ec: add             SP, SP, #0x10
    // 0xc917f0: tbnz            w0, #4, #0xc92884
    // 0xc917f4: ldr             x1, [fp, #0x18]
    // 0xc917f8: ldr             x0, [fp, #0x10]
    // 0xc917fc: LoadField: r2 = r0->field_af
    //     0xc917fc: ldur            w2, [x0, #0xaf]
    // 0xc91800: DecompressPointer r2
    //     0xc91800: add             x2, x2, HEAP, lsl #32
    // 0xc91804: LoadField: r3 = r1->field_af
    //     0xc91804: ldur            w3, [x1, #0xaf]
    // 0xc91808: DecompressPointer r3
    //     0xc91808: add             x3, x3, HEAP, lsl #32
    // 0xc9180c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91810: r0 = ==()
    //     0xc91810: bl              #0xc83960  ; [package:flutter/src/material/bottom_sheet_theme.dart] BottomSheetThemeData::==
    // 0xc91814: add             SP, SP, #0x10
    // 0xc91818: tbnz            w0, #4, #0xc92884
    // 0xc9181c: ldr             x1, [fp, #0x18]
    // 0xc91820: ldr             x0, [fp, #0x10]
    // 0xc91824: LoadField: r2 = r0->field_b3
    //     0xc91824: ldur            w2, [x0, #0xb3]
    // 0xc91828: DecompressPointer r2
    //     0xc91828: add             x2, x2, HEAP, lsl #32
    // 0xc9182c: LoadField: r3 = r1->field_b3
    //     0xc9182c: ldur            w3, [x1, #0xb3]
    // 0xc91830: DecompressPointer r3
    //     0xc91830: add             x3, x3, HEAP, lsl #32
    // 0xc91834: stp             x3, x2, [SP, #-0x10]!
    // 0xc91838: r0 = ==()
    //     0xc91838: bl              #0xc83d14  ; [package:flutter/src/material/button_bar_theme.dart] ButtonBarThemeData::==
    // 0xc9183c: add             SP, SP, #0x10
    // 0xc91840: tbnz            w0, #4, #0xc92884
    // 0xc91844: ldr             x1, [fp, #0x18]
    // 0xc91848: ldr             x0, [fp, #0x10]
    // 0xc9184c: LoadField: r2 = r0->field_b7
    //     0xc9184c: ldur            w2, [x0, #0xb7]
    // 0xc91850: DecompressPointer r2
    //     0xc91850: add             x2, x2, HEAP, lsl #32
    // 0xc91854: LoadField: r3 = r1->field_b7
    //     0xc91854: ldur            w3, [x1, #0xb7]
    // 0xc91858: DecompressPointer r3
    //     0xc91858: add             x3, x3, HEAP, lsl #32
    // 0xc9185c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91860: r0 = ==()
    //     0xc91860: bl              #0xc84a30  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::==
    // 0xc91864: add             SP, SP, #0x10
    // 0xc91868: tbnz            w0, #4, #0xc92884
    // 0xc9186c: ldr             x1, [fp, #0x18]
    // 0xc91870: ldr             x0, [fp, #0x10]
    // 0xc91874: LoadField: r2 = r0->field_bb
    //     0xc91874: ldur            w2, [x0, #0xbb]
    // 0xc91878: DecompressPointer r2
    //     0xc91878: add             x2, x2, HEAP, lsl #32
    // 0xc9187c: LoadField: r3 = r1->field_bb
    //     0xc9187c: ldur            w3, [x1, #0xbb]
    // 0xc91880: DecompressPointer r3
    //     0xc91880: add             x3, x3, HEAP, lsl #32
    // 0xc91884: stp             x3, x2, [SP, #-0x10]!
    // 0xc91888: r0 = ==()
    //     0xc91888: bl              #0xc84da0  ; [package:flutter/src/material/card_theme.dart] CardTheme::==
    // 0xc9188c: add             SP, SP, #0x10
    // 0xc91890: tbnz            w0, #4, #0xc92884
    // 0xc91894: ldr             x1, [fp, #0x18]
    // 0xc91898: ldr             x0, [fp, #0x10]
    // 0xc9189c: LoadField: r2 = r0->field_bf
    //     0xc9189c: ldur            w2, [x0, #0xbf]
    // 0xc918a0: DecompressPointer r2
    //     0xc918a0: add             x2, x2, HEAP, lsl #32
    // 0xc918a4: LoadField: r3 = r1->field_bf
    //     0xc918a4: ldur            w3, [x1, #0xbf]
    // 0xc918a8: DecompressPointer r3
    //     0xc918a8: add             x3, x3, HEAP, lsl #32
    // 0xc918ac: stp             x3, x2, [SP, #-0x10]!
    // 0xc918b0: r0 = ==()
    //     0xc918b0: bl              #0xc84ecc  ; [package:flutter/src/material/checkbox_theme.dart] CheckboxThemeData::==
    // 0xc918b4: add             SP, SP, #0x10
    // 0xc918b8: tbnz            w0, #4, #0xc92884
    // 0xc918bc: ldr             x1, [fp, #0x18]
    // 0xc918c0: ldr             x0, [fp, #0x10]
    // 0xc918c4: LoadField: r2 = r0->field_c3
    //     0xc918c4: ldur            w2, [x0, #0xc3]
    // 0xc918c8: DecompressPointer r2
    //     0xc918c8: add             x2, x2, HEAP, lsl #32
    // 0xc918cc: LoadField: r3 = r1->field_c3
    //     0xc918cc: ldur            w3, [x1, #0xc3]
    // 0xc918d0: DecompressPointer r3
    //     0xc918d0: add             x3, x3, HEAP, lsl #32
    // 0xc918d4: stp             x3, x2, [SP, #-0x10]!
    // 0xc918d8: r0 = ==()
    //     0xc918d8: bl              #0xc856b8  ; [package:flutter/src/material/chip_theme.dart] ChipThemeData::==
    // 0xc918dc: add             SP, SP, #0x10
    // 0xc918e0: tbnz            w0, #4, #0xc92884
    // 0xc918e4: ldr             x1, [fp, #0x18]
    // 0xc918e8: ldr             x0, [fp, #0x10]
    // 0xc918ec: LoadField: r2 = r0->field_c7
    //     0xc918ec: ldur            w2, [x0, #0xc7]
    // 0xc918f0: DecompressPointer r2
    //     0xc918f0: add             x2, x2, HEAP, lsl #32
    // 0xc918f4: LoadField: r3 = r1->field_c7
    //     0xc918f4: ldur            w3, [x1, #0xc7]
    // 0xc918f8: DecompressPointer r3
    //     0xc918f8: add             x3, x3, HEAP, lsl #32
    // 0xc918fc: stp             x3, x2, [SP, #-0x10]!
    // 0xc91900: r0 = ==()
    //     0xc91900: bl              #0xc87670  ; [package:flutter/src/material/data_table_theme.dart] DataTableThemeData::==
    // 0xc91904: add             SP, SP, #0x10
    // 0xc91908: tbnz            w0, #4, #0xc92884
    // 0xc9190c: ldr             x1, [fp, #0x18]
    // 0xc91910: ldr             x0, [fp, #0x10]
    // 0xc91914: LoadField: r2 = r0->field_cb
    //     0xc91914: ldur            w2, [x0, #0xcb]
    // 0xc91918: DecompressPointer r2
    //     0xc91918: add             x2, x2, HEAP, lsl #32
    // 0xc9191c: LoadField: r3 = r1->field_cb
    //     0xc9191c: ldur            w3, [x1, #0xcb]
    // 0xc91920: DecompressPointer r3
    //     0xc91920: add             x3, x3, HEAP, lsl #32
    // 0xc91924: stp             x3, x2, [SP, #-0x10]!
    // 0xc91928: r0 = ==()
    //     0xc91928: bl              #0xc878f0  ; [package:flutter/src/material/dialog_theme.dart] DialogTheme::==
    // 0xc9192c: add             SP, SP, #0x10
    // 0xc91930: tbnz            w0, #4, #0xc92884
    // 0xc91934: ldr             x1, [fp, #0x18]
    // 0xc91938: ldr             x0, [fp, #0x10]
    // 0xc9193c: LoadField: r2 = r0->field_cf
    //     0xc9193c: ldur            w2, [x0, #0xcf]
    // 0xc91940: DecompressPointer r2
    //     0xc91940: add             x2, x2, HEAP, lsl #32
    // 0xc91944: LoadField: r3 = r1->field_cf
    //     0xc91944: ldur            w3, [x1, #0xcf]
    // 0xc91948: DecompressPointer r3
    //     0xc91948: add             x3, x3, HEAP, lsl #32
    // 0xc9194c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91950: r0 = ==()
    //     0xc91950: bl              #0xc883b4  ; [package:flutter/src/material/divider_theme.dart] DividerThemeData::==
    // 0xc91954: add             SP, SP, #0x10
    // 0xc91958: tbnz            w0, #4, #0xc92884
    // 0xc9195c: ldr             x1, [fp, #0x18]
    // 0xc91960: ldr             x0, [fp, #0x10]
    // 0xc91964: LoadField: r2 = r0->field_d3
    //     0xc91964: ldur            w2, [x0, #0xd3]
    // 0xc91968: DecompressPointer r2
    //     0xc91968: add             x2, x2, HEAP, lsl #32
    // 0xc9196c: LoadField: r3 = r1->field_d3
    //     0xc9196c: ldur            w3, [x1, #0xd3]
    // 0xc91970: DecompressPointer r3
    //     0xc91970: add             x3, x3, HEAP, lsl #32
    // 0xc91974: stp             x3, x2, [SP, #-0x10]!
    // 0xc91978: r0 = ==()
    //     0xc91978: bl              #0xc886ec  ; [package:flutter/src/material/drawer_theme.dart] DrawerThemeData::==
    // 0xc9197c: add             SP, SP, #0x10
    // 0xc91980: tbnz            w0, #4, #0xc92884
    // 0xc91984: ldr             x1, [fp, #0x18]
    // 0xc91988: ldr             x0, [fp, #0x10]
    // 0xc9198c: LoadField: r2 = r0->field_d7
    //     0xc9198c: ldur            w2, [x0, #0xd7]
    // 0xc91990: DecompressPointer r2
    //     0xc91990: add             x2, x2, HEAP, lsl #32
    // 0xc91994: LoadField: r3 = r1->field_d7
    //     0xc91994: ldur            w3, [x1, #0xd7]
    // 0xc91998: DecompressPointer r3
    //     0xc91998: add             x3, x3, HEAP, lsl #32
    // 0xc9199c: stp             x3, x2, [SP, #-0x10]!
    // 0xc919a0: r0 = ==()
    //     0xc919a0: bl              #0xc8884c  ; [package:flutter/src/material/dropdown_menu_theme.dart] DropdownMenuThemeData::==
    // 0xc919a4: add             SP, SP, #0x10
    // 0xc919a8: tbnz            w0, #4, #0xc92884
    // 0xc919ac: ldr             x1, [fp, #0x18]
    // 0xc919b0: ldr             x0, [fp, #0x10]
    // 0xc919b4: LoadField: r2 = r0->field_db
    //     0xc919b4: ldur            w2, [x0, #0xdb]
    // 0xc919b8: DecompressPointer r2
    //     0xc919b8: add             x2, x2, HEAP, lsl #32
    // 0xc919bc: LoadField: r3 = r1->field_db
    //     0xc919bc: ldur            w3, [x1, #0xdb]
    // 0xc919c0: DecompressPointer r3
    //     0xc919c0: add             x3, x3, HEAP, lsl #32
    // 0xc919c4: stp             x3, x2, [SP, #-0x10]!
    // 0xc919c8: r0 = ==()
    //     0xc919c8: bl              #0xc88970  ; [package:flutter/src/material/elevated_button_theme.dart] ElevatedButtonThemeData::==
    // 0xc919cc: add             SP, SP, #0x10
    // 0xc919d0: tbnz            w0, #4, #0xc92884
    // 0xc919d4: ldr             x1, [fp, #0x18]
    // 0xc919d8: ldr             x0, [fp, #0x10]
    // 0xc919dc: LoadField: r2 = r0->field_df
    //     0xc919dc: ldur            w2, [x0, #0xdf]
    // 0xc919e0: DecompressPointer r2
    //     0xc919e0: add             x2, x2, HEAP, lsl #32
    // 0xc919e4: LoadField: r3 = r1->field_df
    //     0xc919e4: ldur            w3, [x1, #0xdf]
    // 0xc919e8: DecompressPointer r3
    //     0xc919e8: add             x3, x3, HEAP, lsl #32
    // 0xc919ec: stp             x3, x2, [SP, #-0x10]!
    // 0xc919f0: r0 = ==()
    //     0xc919f0: bl              #0xc88a94  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileThemeData::==
    // 0xc919f4: add             SP, SP, #0x10
    // 0xc919f8: tbnz            w0, #4, #0xc92884
    // 0xc919fc: ldr             x1, [fp, #0x18]
    // 0xc91a00: ldr             x0, [fp, #0x10]
    // 0xc91a04: LoadField: r2 = r0->field_e3
    //     0xc91a04: ldur            w2, [x0, #0xe3]
    // 0xc91a08: DecompressPointer r2
    //     0xc91a08: add             x2, x2, HEAP, lsl #32
    // 0xc91a0c: LoadField: r3 = r1->field_e3
    //     0xc91a0c: ldur            w3, [x1, #0xe3]
    // 0xc91a10: DecompressPointer r3
    //     0xc91a10: add             x3, x3, HEAP, lsl #32
    // 0xc91a14: stp             x3, x2, [SP, #-0x10]!
    // 0xc91a18: r0 = ==()
    //     0xc91a18: bl              #0xc88b88  ; [package:flutter/src/material/filled_button_theme.dart] FilledButtonThemeData::==
    // 0xc91a1c: add             SP, SP, #0x10
    // 0xc91a20: tbnz            w0, #4, #0xc92884
    // 0xc91a24: ldr             x1, [fp, #0x18]
    // 0xc91a28: ldr             x0, [fp, #0x10]
    // 0xc91a2c: LoadField: r2 = r0->field_e7
    //     0xc91a2c: ldur            w2, [x0, #0xe7]
    // 0xc91a30: DecompressPointer r2
    //     0xc91a30: add             x2, x2, HEAP, lsl #32
    // 0xc91a34: LoadField: r3 = r1->field_e7
    //     0xc91a34: ldur            w3, [x1, #0xe7]
    // 0xc91a38: DecompressPointer r3
    //     0xc91a38: add             x3, x3, HEAP, lsl #32
    // 0xc91a3c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91a40: r0 = ==()
    //     0xc91a40: bl              #0xc88cac  ; [package:flutter/src/material/floating_action_button_theme.dart] FloatingActionButtonThemeData::==
    // 0xc91a44: add             SP, SP, #0x10
    // 0xc91a48: tbnz            w0, #4, #0xc92884
    // 0xc91a4c: ldr             x1, [fp, #0x18]
    // 0xc91a50: ldr             x0, [fp, #0x10]
    // 0xc91a54: LoadField: r2 = r0->field_eb
    //     0xc91a54: ldur            w2, [x0, #0xeb]
    // 0xc91a58: DecompressPointer r2
    //     0xc91a58: add             x2, x2, HEAP, lsl #32
    // 0xc91a5c: LoadField: r3 = r1->field_eb
    //     0xc91a5c: ldur            w3, [x1, #0xeb]
    // 0xc91a60: DecompressPointer r3
    //     0xc91a60: add             x3, x3, HEAP, lsl #32
    // 0xc91a64: stp             x3, x2, [SP, #-0x10]!
    // 0xc91a68: r0 = ==()
    //     0xc91a68: bl              #0xc89f40  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonThemeData::==
    // 0xc91a6c: add             SP, SP, #0x10
    // 0xc91a70: tbnz            w0, #4, #0xc92884
    // 0xc91a74: ldr             x1, [fp, #0x18]
    // 0xc91a78: ldr             x0, [fp, #0x10]
    // 0xc91a7c: LoadField: r2 = r0->field_ef
    //     0xc91a7c: ldur            w2, [x0, #0xef]
    // 0xc91a80: DecompressPointer r2
    //     0xc91a80: add             x2, x2, HEAP, lsl #32
    // 0xc91a84: LoadField: r3 = r1->field_ef
    //     0xc91a84: ldur            w3, [x1, #0xef]
    // 0xc91a88: DecompressPointer r3
    //     0xc91a88: add             x3, x3, HEAP, lsl #32
    // 0xc91a8c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91a90: r0 = ==()
    //     0xc91a90: bl              #0xc8b0e4  ; [package:flutter/src/material/list_tile_theme.dart] ListTileThemeData::==
    // 0xc91a94: add             SP, SP, #0x10
    // 0xc91a98: tbnz            w0, #4, #0xc92884
    // 0xc91a9c: ldr             x1, [fp, #0x18]
    // 0xc91aa0: ldr             x0, [fp, #0x10]
    // 0xc91aa4: LoadField: r2 = r0->field_f3
    //     0xc91aa4: ldur            w2, [x0, #0xf3]
    // 0xc91aa8: DecompressPointer r2
    //     0xc91aa8: add             x2, x2, HEAP, lsl #32
    // 0xc91aac: LoadField: r3 = r1->field_f3
    //     0xc91aac: ldur            w3, [x1, #0xf3]
    // 0xc91ab0: DecompressPointer r3
    //     0xc91ab0: add             x3, x3, HEAP, lsl #32
    // 0xc91ab4: stp             x3, x2, [SP, #-0x10]!
    // 0xc91ab8: r0 = ==()
    //     0xc91ab8: bl              #0xc8bafc  ; [package:flutter/src/material/menu_theme.dart] MenuThemeData::==
    // 0xc91abc: add             SP, SP, #0x10
    // 0xc91ac0: tbnz            w0, #4, #0xc92884
    // 0xc91ac4: ldr             x1, [fp, #0x18]
    // 0xc91ac8: ldr             x0, [fp, #0x10]
    // 0xc91acc: LoadField: r2 = r0->field_f7
    //     0xc91acc: ldur            w2, [x0, #0xf7]
    // 0xc91ad0: DecompressPointer r2
    //     0xc91ad0: add             x2, x2, HEAP, lsl #32
    // 0xc91ad4: LoadField: r3 = r1->field_f7
    //     0xc91ad4: ldur            w3, [x1, #0xf7]
    // 0xc91ad8: DecompressPointer r3
    //     0xc91ad8: add             x3, x3, HEAP, lsl #32
    // 0xc91adc: stp             x3, x2, [SP, #-0x10]!
    // 0xc91ae0: r0 = ==()
    //     0xc91ae0: bl              #0xc8bc40  ; [package:flutter/src/material/menu_button_theme.dart] MenuButtonThemeData::==
    // 0xc91ae4: add             SP, SP, #0x10
    // 0xc91ae8: tbnz            w0, #4, #0xc92884
    // 0xc91aec: ldr             x1, [fp, #0x18]
    // 0xc91af0: ldr             x0, [fp, #0x10]
    // 0xc91af4: LoadField: r2 = r0->field_fb
    //     0xc91af4: ldur            w2, [x0, #0xfb]
    // 0xc91af8: DecompressPointer r2
    //     0xc91af8: add             x2, x2, HEAP, lsl #32
    // 0xc91afc: LoadField: r3 = r1->field_fb
    //     0xc91afc: ldur            w3, [x1, #0xfb]
    // 0xc91b00: DecompressPointer r3
    //     0xc91b00: add             x3, x3, HEAP, lsl #32
    // 0xc91b04: stp             x3, x2, [SP, #-0x10]!
    // 0xc91b08: r0 = ==()
    //     0xc91b08: bl              #0xc8bafc  ; [package:flutter/src/material/menu_theme.dart] MenuThemeData::==
    // 0xc91b0c: add             SP, SP, #0x10
    // 0xc91b10: tbnz            w0, #4, #0xc92884
    // 0xc91b14: ldr             x1, [fp, #0x18]
    // 0xc91b18: ldr             x0, [fp, #0x10]
    // 0xc91b1c: LoadField: r2 = r0->field_ff
    //     0xc91b1c: ldur            w2, [x0, #0xff]
    // 0xc91b20: DecompressPointer r2
    //     0xc91b20: add             x2, x2, HEAP, lsl #32
    // 0xc91b24: LoadField: r3 = r1->field_ff
    //     0xc91b24: ldur            w3, [x1, #0xff]
    // 0xc91b28: DecompressPointer r3
    //     0xc91b28: add             x3, x3, HEAP, lsl #32
    // 0xc91b2c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91b30: r0 = ==()
    //     0xc91b30: bl              #0xc8bf4c  ; [package:flutter/src/material/navigation_bar_theme.dart] NavigationBarThemeData::==
    // 0xc91b34: add             SP, SP, #0x10
    // 0xc91b38: tbnz            w0, #4, #0xc92884
    // 0xc91b3c: ldr             x1, [fp, #0x18]
    // 0xc91b40: ldr             x0, [fp, #0x10]
    // 0xc91b44: r17 = 259
    //     0xc91b44: mov             x17, #0x103
    // 0xc91b48: ldr             w2, [x0, x17]
    // 0xc91b4c: DecompressPointer r2
    //     0xc91b4c: add             x2, x2, HEAP, lsl #32
    // 0xc91b50: r17 = 259
    //     0xc91b50: mov             x17, #0x103
    // 0xc91b54: ldr             w3, [x1, x17]
    // 0xc91b58: DecompressPointer r3
    //     0xc91b58: add             x3, x3, HEAP, lsl #32
    // 0xc91b5c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91b60: r0 = ==()
    //     0xc91b60: bl              #0xc8c0ec  ; [package:flutter/src/material/navigation_drawer_theme.dart] NavigationDrawerThemeData::==
    // 0xc91b64: add             SP, SP, #0x10
    // 0xc91b68: tbnz            w0, #4, #0xc92884
    // 0xc91b6c: ldr             x1, [fp, #0x18]
    // 0xc91b70: ldr             x0, [fp, #0x10]
    // 0xc91b74: r17 = 263
    //     0xc91b74: mov             x17, #0x107
    // 0xc91b78: ldr             w2, [x0, x17]
    // 0xc91b7c: DecompressPointer r2
    //     0xc91b7c: add             x2, x2, HEAP, lsl #32
    // 0xc91b80: r17 = 263
    //     0xc91b80: mov             x17, #0x107
    // 0xc91b84: ldr             w3, [x1, x17]
    // 0xc91b88: DecompressPointer r3
    //     0xc91b88: add             x3, x3, HEAP, lsl #32
    // 0xc91b8c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91b90: r0 = ==()
    //     0xc91b90: bl              #0xc8c294  ; [package:flutter/src/material/navigation_rail_theme.dart] NavigationRailThemeData::==
    // 0xc91b94: add             SP, SP, #0x10
    // 0xc91b98: tbnz            w0, #4, #0xc92884
    // 0xc91b9c: ldr             x1, [fp, #0x18]
    // 0xc91ba0: ldr             x0, [fp, #0x10]
    // 0xc91ba4: r17 = 267
    //     0xc91ba4: mov             x17, #0x10b
    // 0xc91ba8: ldr             w2, [x0, x17]
    // 0xc91bac: DecompressPointer r2
    //     0xc91bac: add             x2, x2, HEAP, lsl #32
    // 0xc91bb0: r17 = 267
    //     0xc91bb0: mov             x17, #0x10b
    // 0xc91bb4: ldr             w3, [x1, x17]
    // 0xc91bb8: DecompressPointer r3
    //     0xc91bb8: add             x3, x3, HEAP, lsl #32
    // 0xc91bbc: stp             x3, x2, [SP, #-0x10]!
    // 0xc91bc0: r0 = ==()
    //     0xc91bc0: bl              #0xc8c4e4  ; [package:flutter/src/material/outlined_button_theme.dart] OutlinedButtonThemeData::==
    // 0xc91bc4: add             SP, SP, #0x10
    // 0xc91bc8: tbnz            w0, #4, #0xc92884
    // 0xc91bcc: ldr             x1, [fp, #0x18]
    // 0xc91bd0: ldr             x0, [fp, #0x10]
    // 0xc91bd4: r17 = 271
    //     0xc91bd4: mov             x17, #0x10f
    // 0xc91bd8: ldr             w2, [x0, x17]
    // 0xc91bdc: DecompressPointer r2
    //     0xc91bdc: add             x2, x2, HEAP, lsl #32
    // 0xc91be0: r17 = 271
    //     0xc91be0: mov             x17, #0x10f
    // 0xc91be4: ldr             w3, [x1, x17]
    // 0xc91be8: DecompressPointer r3
    //     0xc91be8: add             x3, x3, HEAP, lsl #32
    // 0xc91bec: stp             x3, x2, [SP, #-0x10]!
    // 0xc91bf0: r0 = ==()
    //     0xc91bf0: bl              #0xc8c75c  ; [package:flutter/src/material/popup_menu_theme.dart] PopupMenuThemeData::==
    // 0xc91bf4: add             SP, SP, #0x10
    // 0xc91bf8: tbnz            w0, #4, #0xc92884
    // 0xc91bfc: ldr             x1, [fp, #0x18]
    // 0xc91c00: ldr             x0, [fp, #0x10]
    // 0xc91c04: r17 = 275
    //     0xc91c04: mov             x17, #0x113
    // 0xc91c08: ldr             w2, [x0, x17]
    // 0xc91c0c: DecompressPointer r2
    //     0xc91c0c: add             x2, x2, HEAP, lsl #32
    // 0xc91c10: r17 = 275
    //     0xc91c10: mov             x17, #0x113
    // 0xc91c14: ldr             w3, [x1, x17]
    // 0xc91c18: DecompressPointer r3
    //     0xc91c18: add             x3, x3, HEAP, lsl #32
    // 0xc91c1c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91c20: r0 = ==()
    //     0xc91c20: bl              #0xc8c8a8  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorThemeData::==
    // 0xc91c24: add             SP, SP, #0x10
    // 0xc91c28: tbnz            w0, #4, #0xc92884
    // 0xc91c2c: ldr             x1, [fp, #0x18]
    // 0xc91c30: ldr             x0, [fp, #0x10]
    // 0xc91c34: r17 = 279
    //     0xc91c34: mov             x17, #0x117
    // 0xc91c38: ldr             w2, [x0, x17]
    // 0xc91c3c: DecompressPointer r2
    //     0xc91c3c: add             x2, x2, HEAP, lsl #32
    // 0xc91c40: r17 = 279
    //     0xc91c40: mov             x17, #0x117
    // 0xc91c44: ldr             w3, [x1, x17]
    // 0xc91c48: DecompressPointer r3
    //     0xc91c48: add             x3, x3, HEAP, lsl #32
    // 0xc91c4c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91c50: r0 = ==()
    //     0xc91c50: bl              #0xc8cb28  ; [package:flutter/src/material/radio_theme.dart] RadioThemeData::==
    // 0xc91c54: add             SP, SP, #0x10
    // 0xc91c58: tbnz            w0, #4, #0xc92884
    // 0xc91c5c: ldr             x1, [fp, #0x18]
    // 0xc91c60: ldr             x0, [fp, #0x10]
    // 0xc91c64: r17 = 283
    //     0xc91c64: mov             x17, #0x11b
    // 0xc91c68: ldr             w2, [x0, x17]
    // 0xc91c6c: DecompressPointer r2
    //     0xc91c6c: add             x2, x2, HEAP, lsl #32
    // 0xc91c70: r17 = 283
    //     0xc91c70: mov             x17, #0x11b
    // 0xc91c74: ldr             w3, [x1, x17]
    // 0xc91c78: DecompressPointer r3
    //     0xc91c78: add             x3, x3, HEAP, lsl #32
    // 0xc91c7c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91c80: r0 = ==()
    //     0xc91c80: bl              #0xc8ceb0  ; [package:flutter/src/material/segmented_button_theme.dart] SegmentedButtonThemeData::==
    // 0xc91c84: add             SP, SP, #0x10
    // 0xc91c88: tbnz            w0, #4, #0xc92884
    // 0xc91c8c: ldr             x1, [fp, #0x18]
    // 0xc91c90: ldr             x0, [fp, #0x10]
    // 0xc91c94: r17 = 287
    //     0xc91c94: mov             x17, #0x11f
    // 0xc91c98: ldr             w2, [x0, x17]
    // 0xc91c9c: DecompressPointer r2
    //     0xc91c9c: add             x2, x2, HEAP, lsl #32
    // 0xc91ca0: r17 = 287
    //     0xc91ca0: mov             x17, #0x11f
    // 0xc91ca4: ldr             w3, [x1, x17]
    // 0xc91ca8: DecompressPointer r3
    //     0xc91ca8: add             x3, x3, HEAP, lsl #32
    // 0xc91cac: stp             x3, x2, [SP, #-0x10]!
    // 0xc91cb0: r0 = ==()
    //     0xc91cb0: bl              #0xc8d930  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::==
    // 0xc91cb4: add             SP, SP, #0x10
    // 0xc91cb8: tbnz            w0, #4, #0xc92884
    // 0xc91cbc: ldr             x1, [fp, #0x18]
    // 0xc91cc0: ldr             x0, [fp, #0x10]
    // 0xc91cc4: r17 = 291
    //     0xc91cc4: mov             x17, #0x123
    // 0xc91cc8: ldr             w2, [x0, x17]
    // 0xc91ccc: DecompressPointer r2
    //     0xc91ccc: add             x2, x2, HEAP, lsl #32
    // 0xc91cd0: r17 = 291
    //     0xc91cd0: mov             x17, #0x123
    // 0xc91cd4: ldr             w3, [x1, x17]
    // 0xc91cd8: DecompressPointer r3
    //     0xc91cd8: add             x3, x3, HEAP, lsl #32
    // 0xc91cdc: stp             x3, x2, [SP, #-0x10]!
    // 0xc91ce0: r0 = ==()
    //     0xc91ce0: bl              #0xc8efac  ; [package:flutter/src/material/snack_bar_theme.dart] SnackBarThemeData::==
    // 0xc91ce4: add             SP, SP, #0x10
    // 0xc91ce8: tbnz            w0, #4, #0xc92884
    // 0xc91cec: ldr             x1, [fp, #0x18]
    // 0xc91cf0: ldr             x0, [fp, #0x10]
    // 0xc91cf4: r17 = 295
    //     0xc91cf4: mov             x17, #0x127
    // 0xc91cf8: ldr             w2, [x0, x17]
    // 0xc91cfc: DecompressPointer r2
    //     0xc91cfc: add             x2, x2, HEAP, lsl #32
    // 0xc91d00: r17 = 295
    //     0xc91d00: mov             x17, #0x127
    // 0xc91d04: ldr             w3, [x1, x17]
    // 0xc91d08: DecompressPointer r3
    //     0xc91d08: add             x3, x3, HEAP, lsl #32
    // 0xc91d0c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91d10: r0 = ==()
    //     0xc91d10: bl              #0xc8f114  ; [package:flutter/src/material/switch_theme.dart] SwitchThemeData::==
    // 0xc91d14: add             SP, SP, #0x10
    // 0xc91d18: tbnz            w0, #4, #0xc92884
    // 0xc91d1c: ldr             x1, [fp, #0x18]
    // 0xc91d20: ldr             x0, [fp, #0x10]
    // 0xc91d24: r17 = 299
    //     0xc91d24: mov             x17, #0x12b
    // 0xc91d28: ldr             w2, [x0, x17]
    // 0xc91d2c: DecompressPointer r2
    //     0xc91d2c: add             x2, x2, HEAP, lsl #32
    // 0xc91d30: r17 = 299
    //     0xc91d30: mov             x17, #0x12b
    // 0xc91d34: ldr             w3, [x1, x17]
    // 0xc91d38: DecompressPointer r3
    //     0xc91d38: add             x3, x3, HEAP, lsl #32
    // 0xc91d3c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91d40: r0 = ==()
    //     0xc91d40: bl              #0xc8f288  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::==
    // 0xc91d44: add             SP, SP, #0x10
    // 0xc91d48: tbnz            w0, #4, #0xc92884
    // 0xc91d4c: ldr             x1, [fp, #0x18]
    // 0xc91d50: ldr             x0, [fp, #0x10]
    // 0xc91d54: r17 = 303
    //     0xc91d54: mov             x17, #0x12f
    // 0xc91d58: ldr             w2, [x0, x17]
    // 0xc91d5c: DecompressPointer r2
    //     0xc91d5c: add             x2, x2, HEAP, lsl #32
    // 0xc91d60: r17 = 303
    //     0xc91d60: mov             x17, #0x12f
    // 0xc91d64: ldr             w3, [x1, x17]
    // 0xc91d68: DecompressPointer r3
    //     0xc91d68: add             x3, x3, HEAP, lsl #32
    // 0xc91d6c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91d70: r0 = ==()
    //     0xc91d70: bl              #0xc8fe28  ; [package:flutter/src/material/text_button_theme.dart] TextButtonThemeData::==
    // 0xc91d74: add             SP, SP, #0x10
    // 0xc91d78: tbnz            w0, #4, #0xc92884
    // 0xc91d7c: ldr             x1, [fp, #0x18]
    // 0xc91d80: ldr             x0, [fp, #0x10]
    // 0xc91d84: r17 = 307
    //     0xc91d84: mov             x17, #0x133
    // 0xc91d88: ldr             w2, [x0, x17]
    // 0xc91d8c: DecompressPointer r2
    //     0xc91d8c: add             x2, x2, HEAP, lsl #32
    // 0xc91d90: r17 = 307
    //     0xc91d90: mov             x17, #0x133
    // 0xc91d94: ldr             w3, [x1, x17]
    // 0xc91d98: DecompressPointer r3
    //     0xc91d98: add             x3, x3, HEAP, lsl #32
    // 0xc91d9c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91da0: r0 = ==()
    //     0xc91da0: bl              #0xc8ff4c  ; [package:flutter/src/material/text_selection_theme.dart] TextSelectionThemeData::==
    // 0xc91da4: add             SP, SP, #0x10
    // 0xc91da8: tbnz            w0, #4, #0xc92884
    // 0xc91dac: ldr             x1, [fp, #0x18]
    // 0xc91db0: ldr             x0, [fp, #0x10]
    // 0xc91db4: r17 = 311
    //     0xc91db4: mov             x17, #0x137
    // 0xc91db8: ldr             w2, [x0, x17]
    // 0xc91dbc: DecompressPointer r2
    //     0xc91dbc: add             x2, x2, HEAP, lsl #32
    // 0xc91dc0: r17 = 311
    //     0xc91dc0: mov             x17, #0x137
    // 0xc91dc4: ldr             w3, [x1, x17]
    // 0xc91dc8: DecompressPointer r3
    //     0xc91dc8: add             x3, x3, HEAP, lsl #32
    // 0xc91dcc: stp             x3, x2, [SP, #-0x10]!
    // 0xc91dd0: r0 = ==()
    //     0xc91dd0: bl              #0xc929e4  ; [package:flutter/src/material/time_picker_theme.dart] TimePickerThemeData::==
    // 0xc91dd4: add             SP, SP, #0x10
    // 0xc91dd8: tbnz            w0, #4, #0xc92884
    // 0xc91ddc: ldr             x1, [fp, #0x18]
    // 0xc91de0: ldr             x0, [fp, #0x10]
    // 0xc91de4: r17 = 315
    //     0xc91de4: mov             x17, #0x13b
    // 0xc91de8: ldr             w2, [x0, x17]
    // 0xc91dec: DecompressPointer r2
    //     0xc91dec: add             x2, x2, HEAP, lsl #32
    // 0xc91df0: r17 = 315
    //     0xc91df0: mov             x17, #0x13b
    // 0xc91df4: ldr             w3, [x1, x17]
    // 0xc91df8: DecompressPointer r3
    //     0xc91df8: add             x3, x3, HEAP, lsl #32
    // 0xc91dfc: stp             x3, x2, [SP, #-0x10]!
    // 0xc91e00: r0 = ==()
    //     0xc91e00: bl              #0xc92ad8  ; [package:flutter/src/material/toggle_buttons_theme.dart] ToggleButtonsThemeData::==
    // 0xc91e04: add             SP, SP, #0x10
    // 0xc91e08: tbnz            w0, #4, #0xc92884
    // 0xc91e0c: ldr             x1, [fp, #0x18]
    // 0xc91e10: ldr             x0, [fp, #0x10]
    // 0xc91e14: r17 = 319
    //     0xc91e14: mov             x17, #0x13f
    // 0xc91e18: ldr             w2, [x0, x17]
    // 0xc91e1c: DecompressPointer r2
    //     0xc91e1c: add             x2, x2, HEAP, lsl #32
    // 0xc91e20: r17 = 319
    //     0xc91e20: mov             x17, #0x13f
    // 0xc91e24: ldr             w3, [x1, x17]
    // 0xc91e28: DecompressPointer r3
    //     0xc91e28: add             x3, x3, HEAP, lsl #32
    // 0xc91e2c: stp             x3, x2, [SP, #-0x10]!
    // 0xc91e30: r0 = ==()
    //     0xc91e30: bl              #0xc92c38  ; [package:flutter/src/material/tooltip_theme.dart] TooltipThemeData::==
    // 0xc91e34: add             SP, SP, #0x10
    // 0xc91e38: tbnz            w0, #4, #0xc92884
    // 0xc91e3c: ldr             x1, [fp, #0x18]
    // 0xc91e40: ldr             x0, [fp, #0x10]
    // 0xc91e44: r17 = 323
    //     0xc91e44: mov             x17, #0x143
    // 0xc91e48: ldr             w2, [x0, x17]
    // 0xc91e4c: DecompressPointer r2
    //     0xc91e4c: add             x2, x2, HEAP, lsl #32
    // 0xc91e50: stur            x2, [fp, #-0x18]
    // 0xc91e54: cmp             w2, NULL
    // 0xc91e58: b.eq            #0xc9289c
    // 0xc91e5c: r17 = 323
    //     0xc91e5c: mov             x17, #0x143
    // 0xc91e60: ldr             w3, [x1, x17]
    // 0xc91e64: DecompressPointer r3
    //     0xc91e64: add             x3, x3, HEAP, lsl #32
    // 0xc91e68: stur            x3, [fp, #-0x10]
    // 0xc91e6c: cmp             w3, NULL
    // 0xc91e70: b.eq            #0xc928a0
    // 0xc91e74: r4 = LoadClassIdInstr(r2)
    //     0xc91e74: ldur            x4, [x2, #-1]
    //     0xc91e78: ubfx            x4, x4, #0xc, #0x14
    // 0xc91e7c: lsl             x4, x4, #1
    // 0xc91e80: stur            x4, [fp, #-8]
    // 0xc91e84: r17 = 10114
    //     0xc91e84: mov             x17, #0x2782
    // 0xc91e88: cmp             w4, w17
    // 0xc91e8c: b.eq            #0xc91e9c
    // 0xc91e90: r17 = 10118
    //     0xc91e90: mov             x17, #0x2786
    // 0xc91e94: cmp             w4, w17
    // 0xc91e98: b.ne            #0xc91f74
    // 0xc91e9c: cmp             w2, w3
    // 0xc91ea0: b.eq            #0xc91fa4
    // 0xc91ea4: stp             x2, x3, [SP, #-0x10]!
    // 0xc91ea8: r0 = _haveSameRuntimeType()
    //     0xc91ea8: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc91eac: add             SP, SP, #0x10
    // 0xc91eb0: tbnz            w0, #4, #0xc92884
    // 0xc91eb4: ldur            x0, [fp, #-0x10]
    // 0xc91eb8: r1 = LoadClassIdInstr(r0)
    //     0xc91eb8: ldur            x1, [x0, #-1]
    //     0xc91ebc: ubfx            x1, x1, #0xc, #0x14
    // 0xc91ec0: lsl             x1, x1, #1
    // 0xc91ec4: r17 = 10124
    //     0xc91ec4: mov             x17, #0x278c
    // 0xc91ec8: cmp             w1, w17
    // 0xc91ecc: b.gt            #0xc91edc
    // 0xc91ed0: r17 = 10122
    //     0xc91ed0: mov             x17, #0x278a
    // 0xc91ed4: cmp             w1, w17
    // 0xc91ed8: b.ge            #0xc91ef4
    // 0xc91edc: r17 = 10114
    //     0xc91edc: mov             x17, #0x2782
    // 0xc91ee0: cmp             w1, w17
    // 0xc91ee4: b.eq            #0xc91ef4
    // 0xc91ee8: r17 = 10118
    //     0xc91ee8: mov             x17, #0x2786
    // 0xc91eec: cmp             w1, w17
    // 0xc91ef0: b.ne            #0xc91efc
    // 0xc91ef4: LoadField: r1 = r0->field_7
    //     0xc91ef4: ldur            x1, [x0, #7]
    // 0xc91ef8: b               #0xc91f0c
    // 0xc91efc: LoadField: r1 = r0->field_f
    //     0xc91efc: ldur            w1, [x0, #0xf]
    // 0xc91f00: DecompressPointer r1
    //     0xc91f00: add             x1, x1, HEAP, lsl #32
    // 0xc91f04: LoadField: r0 = r1->field_7
    //     0xc91f04: ldur            x0, [x1, #7]
    // 0xc91f08: mov             x1, x0
    // 0xc91f0c: ldur            x0, [fp, #-8]
    // 0xc91f10: r17 = 10124
    //     0xc91f10: mov             x17, #0x278c
    // 0xc91f14: cmp             w0, w17
    // 0xc91f18: b.gt            #0xc91f28
    // 0xc91f1c: r17 = 10122
    //     0xc91f1c: mov             x17, #0x278a
    // 0xc91f20: cmp             w0, w17
    // 0xc91f24: b.ge            #0xc91f40
    // 0xc91f28: r17 = 10114
    //     0xc91f28: mov             x17, #0x2782
    // 0xc91f2c: cmp             w0, w17
    // 0xc91f30: b.eq            #0xc91f40
    // 0xc91f34: r17 = 10118
    //     0xc91f34: mov             x17, #0x2786
    // 0xc91f38: cmp             w0, w17
    // 0xc91f3c: b.ne            #0xc91f4c
    // 0xc91f40: ldur            x2, [fp, #-0x18]
    // 0xc91f44: LoadField: r0 = r2->field_7
    //     0xc91f44: ldur            x0, [x2, #7]
    // 0xc91f48: b               #0xc91f60
    // 0xc91f4c: ldur            x2, [fp, #-0x18]
    // 0xc91f50: LoadField: r0 = r2->field_f
    //     0xc91f50: ldur            w0, [x2, #0xf]
    // 0xc91f54: DecompressPointer r0
    //     0xc91f54: add             x0, x0, HEAP, lsl #32
    // 0xc91f58: LoadField: r2 = r0->field_7
    //     0xc91f58: ldur            x2, [x0, #7]
    // 0xc91f5c: mov             x0, x2
    // 0xc91f60: cmp             x1, x0
    // 0xc91f64: b.ne            #0xc92884
    // 0xc91f68: ldr             x1, [fp, #0x18]
    // 0xc91f6c: ldr             x0, [fp, #0x10]
    // 0xc91f70: b               #0xc91fa4
    // 0xc91f74: mov             x0, x3
    // 0xc91f78: r1 = LoadClassIdInstr(r2)
    //     0xc91f78: ldur            x1, [x2, #-1]
    //     0xc91f7c: ubfx            x1, x1, #0xc, #0x14
    // 0xc91f80: stp             x0, x2, [SP, #-0x10]!
    // 0xc91f84: mov             x0, x1
    // 0xc91f88: mov             lr, x0
    // 0xc91f8c: ldr             lr, [x21, lr, lsl #3]
    // 0xc91f90: blr             lr
    // 0xc91f94: add             SP, SP, #0x10
    // 0xc91f98: tbnz            w0, #4, #0xc92884
    // 0xc91f9c: ldr             x1, [fp, #0x18]
    // 0xc91fa0: ldr             x0, [fp, #0x10]
    // 0xc91fa4: r17 = 327
    //     0xc91fa4: mov             x17, #0x147
    // 0xc91fa8: ldr             w2, [x0, x17]
    // 0xc91fac: DecompressPointer r2
    //     0xc91fac: add             x2, x2, HEAP, lsl #32
    // 0xc91fb0: r17 = 327
    //     0xc91fb0: mov             x17, #0x147
    // 0xc91fb4: ldr             w3, [x1, x17]
    // 0xc91fb8: DecompressPointer r3
    //     0xc91fb8: add             x3, x3, HEAP, lsl #32
    // 0xc91fbc: cmp             w2, w3
    // 0xc91fc0: b.ne            #0xc92884
    // 0xc91fc4: r17 = 331
    //     0xc91fc4: mov             x17, #0x14b
    // 0xc91fc8: ldr             w2, [x0, x17]
    // 0xc91fcc: DecompressPointer r2
    //     0xc91fcc: add             x2, x2, HEAP, lsl #32
    // 0xc91fd0: r17 = 331
    //     0xc91fd0: mov             x17, #0x14b
    // 0xc91fd4: ldr             w3, [x1, x17]
    // 0xc91fd8: DecompressPointer r3
    //     0xc91fd8: add             x3, x3, HEAP, lsl #32
    // 0xc91fdc: stp             x3, x2, [SP, #-0x10]!
    // 0xc91fe0: r0 = ==()
    //     0xc91fe0: bl              #0xc900e8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0xc91fe4: add             SP, SP, #0x10
    // 0xc91fe8: tbnz            w0, #4, #0xc92884
    // 0xc91fec: ldr             x1, [fp, #0x18]
    // 0xc91ff0: ldr             x0, [fp, #0x10]
    // 0xc91ff4: r17 = 335
    //     0xc91ff4: mov             x17, #0x14f
    // 0xc91ff8: ldr             w2, [x0, x17]
    // 0xc91ffc: DecompressPointer r2
    //     0xc91ffc: add             x2, x2, HEAP, lsl #32
    // 0xc92000: r17 = 335
    //     0xc92000: mov             x17, #0x14f
    // 0xc92004: ldr             w3, [x1, x17]
    // 0xc92008: DecompressPointer r3
    //     0xc92008: add             x3, x3, HEAP, lsl #32
    // 0xc9200c: stp             x3, x2, [SP, #-0x10]!
    // 0xc92010: r0 = ==()
    //     0xc92010: bl              #0xc811ec  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::==
    // 0xc92014: add             SP, SP, #0x10
    // 0xc92018: tbnz            w0, #4, #0xc92884
    // 0xc9201c: ldr             x1, [fp, #0x18]
    // 0xc92020: ldr             x0, [fp, #0x10]
    // 0xc92024: r17 = 339
    //     0xc92024: mov             x17, #0x153
    // 0xc92028: ldr             w2, [x0, x17]
    // 0xc9202c: DecompressPointer r2
    //     0xc9202c: add             x2, x2, HEAP, lsl #32
    // 0xc92030: stur            x2, [fp, #-0x18]
    // 0xc92034: cmp             w2, NULL
    // 0xc92038: b.eq            #0xc928a4
    // 0xc9203c: r17 = 339
    //     0xc9203c: mov             x17, #0x153
    // 0xc92040: ldr             w3, [x1, x17]
    // 0xc92044: DecompressPointer r3
    //     0xc92044: add             x3, x3, HEAP, lsl #32
    // 0xc92048: stur            x3, [fp, #-0x10]
    // 0xc9204c: cmp             w3, NULL
    // 0xc92050: b.eq            #0xc928a8
    // 0xc92054: r4 = LoadClassIdInstr(r2)
    //     0xc92054: ldur            x4, [x2, #-1]
    //     0xc92058: ubfx            x4, x4, #0xc, #0x14
    // 0xc9205c: lsl             x4, x4, #1
    // 0xc92060: stur            x4, [fp, #-8]
    // 0xc92064: r17 = 10114
    //     0xc92064: mov             x17, #0x2782
    // 0xc92068: cmp             w4, w17
    // 0xc9206c: b.eq            #0xc9207c
    // 0xc92070: r17 = 10118
    //     0xc92070: mov             x17, #0x2786
    // 0xc92074: cmp             w4, w17
    // 0xc92078: b.ne            #0xc92154
    // 0xc9207c: cmp             w2, w3
    // 0xc92080: b.eq            #0xc92184
    // 0xc92084: stp             x2, x3, [SP, #-0x10]!
    // 0xc92088: r0 = _haveSameRuntimeType()
    //     0xc92088: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc9208c: add             SP, SP, #0x10
    // 0xc92090: tbnz            w0, #4, #0xc92884
    // 0xc92094: ldur            x0, [fp, #-0x10]
    // 0xc92098: r1 = LoadClassIdInstr(r0)
    //     0xc92098: ldur            x1, [x0, #-1]
    //     0xc9209c: ubfx            x1, x1, #0xc, #0x14
    // 0xc920a0: lsl             x1, x1, #1
    // 0xc920a4: r17 = 10124
    //     0xc920a4: mov             x17, #0x278c
    // 0xc920a8: cmp             w1, w17
    // 0xc920ac: b.gt            #0xc920bc
    // 0xc920b0: r17 = 10122
    //     0xc920b0: mov             x17, #0x278a
    // 0xc920b4: cmp             w1, w17
    // 0xc920b8: b.ge            #0xc920d4
    // 0xc920bc: r17 = 10114
    //     0xc920bc: mov             x17, #0x2782
    // 0xc920c0: cmp             w1, w17
    // 0xc920c4: b.eq            #0xc920d4
    // 0xc920c8: r17 = 10118
    //     0xc920c8: mov             x17, #0x2786
    // 0xc920cc: cmp             w1, w17
    // 0xc920d0: b.ne            #0xc920dc
    // 0xc920d4: LoadField: r1 = r0->field_7
    //     0xc920d4: ldur            x1, [x0, #7]
    // 0xc920d8: b               #0xc920ec
    // 0xc920dc: LoadField: r1 = r0->field_f
    //     0xc920dc: ldur            w1, [x0, #0xf]
    // 0xc920e0: DecompressPointer r1
    //     0xc920e0: add             x1, x1, HEAP, lsl #32
    // 0xc920e4: LoadField: r0 = r1->field_7
    //     0xc920e4: ldur            x0, [x1, #7]
    // 0xc920e8: mov             x1, x0
    // 0xc920ec: ldur            x0, [fp, #-8]
    // 0xc920f0: r17 = 10124
    //     0xc920f0: mov             x17, #0x278c
    // 0xc920f4: cmp             w0, w17
    // 0xc920f8: b.gt            #0xc92108
    // 0xc920fc: r17 = 10122
    //     0xc920fc: mov             x17, #0x278a
    // 0xc92100: cmp             w0, w17
    // 0xc92104: b.ge            #0xc92120
    // 0xc92108: r17 = 10114
    //     0xc92108: mov             x17, #0x2782
    // 0xc9210c: cmp             w0, w17
    // 0xc92110: b.eq            #0xc92120
    // 0xc92114: r17 = 10118
    //     0xc92114: mov             x17, #0x2786
    // 0xc92118: cmp             w0, w17
    // 0xc9211c: b.ne            #0xc9212c
    // 0xc92120: ldur            x2, [fp, #-0x18]
    // 0xc92124: LoadField: r0 = r2->field_7
    //     0xc92124: ldur            x0, [x2, #7]
    // 0xc92128: b               #0xc92140
    // 0xc9212c: ldur            x2, [fp, #-0x18]
    // 0xc92130: LoadField: r0 = r2->field_f
    //     0xc92130: ldur            w0, [x2, #0xf]
    // 0xc92134: DecompressPointer r0
    //     0xc92134: add             x0, x0, HEAP, lsl #32
    // 0xc92138: LoadField: r2 = r0->field_7
    //     0xc92138: ldur            x2, [x0, #7]
    // 0xc9213c: mov             x0, x2
    // 0xc92140: cmp             x1, x0
    // 0xc92144: b.ne            #0xc92884
    // 0xc92148: ldr             x1, [fp, #0x18]
    // 0xc9214c: ldr             x0, [fp, #0x10]
    // 0xc92150: b               #0xc92184
    // 0xc92154: mov             x0, x3
    // 0xc92158: r1 = LoadClassIdInstr(r2)
    //     0xc92158: ldur            x1, [x2, #-1]
    //     0xc9215c: ubfx            x1, x1, #0xc, #0x14
    // 0xc92160: stp             x0, x2, [SP, #-0x10]!
    // 0xc92164: mov             x0, x1
    // 0xc92168: mov             lr, x0
    // 0xc9216c: ldr             lr, [x21, lr, lsl #3]
    // 0xc92170: blr             lr
    // 0xc92174: add             SP, SP, #0x10
    // 0xc92178: tbnz            w0, #4, #0xc92884
    // 0xc9217c: ldr             x1, [fp, #0x18]
    // 0xc92180: ldr             x0, [fp, #0x10]
    // 0xc92184: r17 = 347
    //     0xc92184: mov             x17, #0x15b
    // 0xc92188: ldr             w2, [x0, x17]
    // 0xc9218c: DecompressPointer r2
    //     0xc9218c: add             x2, x2, HEAP, lsl #32
    // 0xc92190: r17 = 347
    //     0xc92190: mov             x17, #0x15b
    // 0xc92194: ldr             w3, [x1, x17]
    // 0xc92198: DecompressPointer r3
    //     0xc92198: add             x3, x3, HEAP, lsl #32
    // 0xc9219c: cmp             w2, w3
    // 0xc921a0: b.ne            #0xc92884
    // 0xc921a4: r17 = 363
    //     0xc921a4: mov             x17, #0x16b
    // 0xc921a8: ldr             w2, [x0, x17]
    // 0xc921ac: DecompressPointer r2
    //     0xc921ac: add             x2, x2, HEAP, lsl #32
    // 0xc921b0: stur            x2, [fp, #-0x18]
    // 0xc921b4: cmp             w2, NULL
    // 0xc921b8: b.eq            #0xc928ac
    // 0xc921bc: r17 = 363
    //     0xc921bc: mov             x17, #0x16b
    // 0xc921c0: ldr             w3, [x1, x17]
    // 0xc921c4: DecompressPointer r3
    //     0xc921c4: add             x3, x3, HEAP, lsl #32
    // 0xc921c8: stur            x3, [fp, #-0x10]
    // 0xc921cc: cmp             w3, NULL
    // 0xc921d0: b.eq            #0xc928b0
    // 0xc921d4: r4 = LoadClassIdInstr(r2)
    //     0xc921d4: ldur            x4, [x2, #-1]
    //     0xc921d8: ubfx            x4, x4, #0xc, #0x14
    // 0xc921dc: lsl             x4, x4, #1
    // 0xc921e0: stur            x4, [fp, #-8]
    // 0xc921e4: r17 = 10114
    //     0xc921e4: mov             x17, #0x2782
    // 0xc921e8: cmp             w4, w17
    // 0xc921ec: b.eq            #0xc921fc
    // 0xc921f0: r17 = 10118
    //     0xc921f0: mov             x17, #0x2786
    // 0xc921f4: cmp             w4, w17
    // 0xc921f8: b.ne            #0xc922d4
    // 0xc921fc: cmp             w2, w3
    // 0xc92200: b.eq            #0xc92304
    // 0xc92204: stp             x2, x3, [SP, #-0x10]!
    // 0xc92208: r0 = _haveSameRuntimeType()
    //     0xc92208: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc9220c: add             SP, SP, #0x10
    // 0xc92210: tbnz            w0, #4, #0xc92884
    // 0xc92214: ldur            x0, [fp, #-0x10]
    // 0xc92218: r1 = LoadClassIdInstr(r0)
    //     0xc92218: ldur            x1, [x0, #-1]
    //     0xc9221c: ubfx            x1, x1, #0xc, #0x14
    // 0xc92220: lsl             x1, x1, #1
    // 0xc92224: r17 = 10124
    //     0xc92224: mov             x17, #0x278c
    // 0xc92228: cmp             w1, w17
    // 0xc9222c: b.gt            #0xc9223c
    // 0xc92230: r17 = 10122
    //     0xc92230: mov             x17, #0x278a
    // 0xc92234: cmp             w1, w17
    // 0xc92238: b.ge            #0xc92254
    // 0xc9223c: r17 = 10114
    //     0xc9223c: mov             x17, #0x2782
    // 0xc92240: cmp             w1, w17
    // 0xc92244: b.eq            #0xc92254
    // 0xc92248: r17 = 10118
    //     0xc92248: mov             x17, #0x2786
    // 0xc9224c: cmp             w1, w17
    // 0xc92250: b.ne            #0xc9225c
    // 0xc92254: LoadField: r1 = r0->field_7
    //     0xc92254: ldur            x1, [x0, #7]
    // 0xc92258: b               #0xc9226c
    // 0xc9225c: LoadField: r1 = r0->field_f
    //     0xc9225c: ldur            w1, [x0, #0xf]
    // 0xc92260: DecompressPointer r1
    //     0xc92260: add             x1, x1, HEAP, lsl #32
    // 0xc92264: LoadField: r0 = r1->field_7
    //     0xc92264: ldur            x0, [x1, #7]
    // 0xc92268: mov             x1, x0
    // 0xc9226c: ldur            x0, [fp, #-8]
    // 0xc92270: r17 = 10124
    //     0xc92270: mov             x17, #0x278c
    // 0xc92274: cmp             w0, w17
    // 0xc92278: b.gt            #0xc92288
    // 0xc9227c: r17 = 10122
    //     0xc9227c: mov             x17, #0x278a
    // 0xc92280: cmp             w0, w17
    // 0xc92284: b.ge            #0xc922a0
    // 0xc92288: r17 = 10114
    //     0xc92288: mov             x17, #0x2782
    // 0xc9228c: cmp             w0, w17
    // 0xc92290: b.eq            #0xc922a0
    // 0xc92294: r17 = 10118
    //     0xc92294: mov             x17, #0x2786
    // 0xc92298: cmp             w0, w17
    // 0xc9229c: b.ne            #0xc922ac
    // 0xc922a0: ldur            x2, [fp, #-0x18]
    // 0xc922a4: LoadField: r0 = r2->field_7
    //     0xc922a4: ldur            x0, [x2, #7]
    // 0xc922a8: b               #0xc922c0
    // 0xc922ac: ldur            x2, [fp, #-0x18]
    // 0xc922b0: LoadField: r0 = r2->field_f
    //     0xc922b0: ldur            w0, [x2, #0xf]
    // 0xc922b4: DecompressPointer r0
    //     0xc922b4: add             x0, x0, HEAP, lsl #32
    // 0xc922b8: LoadField: r2 = r0->field_7
    //     0xc922b8: ldur            x2, [x0, #7]
    // 0xc922bc: mov             x0, x2
    // 0xc922c0: cmp             x1, x0
    // 0xc922c4: b.ne            #0xc92884
    // 0xc922c8: ldr             x1, [fp, #0x18]
    // 0xc922cc: ldr             x0, [fp, #0x10]
    // 0xc922d0: b               #0xc92304
    // 0xc922d4: mov             x0, x3
    // 0xc922d8: r1 = LoadClassIdInstr(r2)
    //     0xc922d8: ldur            x1, [x2, #-1]
    //     0xc922dc: ubfx            x1, x1, #0xc, #0x14
    // 0xc922e0: stp             x0, x2, [SP, #-0x10]!
    // 0xc922e4: mov             x0, x1
    // 0xc922e8: mov             lr, x0
    // 0xc922ec: ldr             lr, [x21, lr, lsl #3]
    // 0xc922f0: blr             lr
    // 0xc922f4: add             SP, SP, #0x10
    // 0xc922f8: tbnz            w0, #4, #0xc92884
    // 0xc922fc: ldr             x1, [fp, #0x18]
    // 0xc92300: ldr             x0, [fp, #0x10]
    // 0xc92304: LoadField: r2 = r0->field_77
    //     0xc92304: ldur            w2, [x0, #0x77]
    // 0xc92308: DecompressPointer r2
    //     0xc92308: add             x2, x2, HEAP, lsl #32
    // 0xc9230c: stur            x2, [fp, #-0x18]
    // 0xc92310: cmp             w2, NULL
    // 0xc92314: b.eq            #0xc928b4
    // 0xc92318: LoadField: r3 = r1->field_77
    //     0xc92318: ldur            w3, [x1, #0x77]
    // 0xc9231c: DecompressPointer r3
    //     0xc9231c: add             x3, x3, HEAP, lsl #32
    // 0xc92320: stur            x3, [fp, #-0x10]
    // 0xc92324: cmp             w3, NULL
    // 0xc92328: b.eq            #0xc928b8
    // 0xc9232c: r4 = LoadClassIdInstr(r2)
    //     0xc9232c: ldur            x4, [x2, #-1]
    //     0xc92330: ubfx            x4, x4, #0xc, #0x14
    // 0xc92334: lsl             x4, x4, #1
    // 0xc92338: stur            x4, [fp, #-8]
    // 0xc9233c: r17 = 10114
    //     0xc9233c: mov             x17, #0x2782
    // 0xc92340: cmp             w4, w17
    // 0xc92344: b.eq            #0xc92354
    // 0xc92348: r17 = 10118
    //     0xc92348: mov             x17, #0x2786
    // 0xc9234c: cmp             w4, w17
    // 0xc92350: b.ne            #0xc9242c
    // 0xc92354: cmp             w2, w3
    // 0xc92358: b.eq            #0xc9245c
    // 0xc9235c: stp             x2, x3, [SP, #-0x10]!
    // 0xc92360: r0 = _haveSameRuntimeType()
    //     0xc92360: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc92364: add             SP, SP, #0x10
    // 0xc92368: tbnz            w0, #4, #0xc92884
    // 0xc9236c: ldur            x0, [fp, #-0x10]
    // 0xc92370: r1 = LoadClassIdInstr(r0)
    //     0xc92370: ldur            x1, [x0, #-1]
    //     0xc92374: ubfx            x1, x1, #0xc, #0x14
    // 0xc92378: lsl             x1, x1, #1
    // 0xc9237c: r17 = 10124
    //     0xc9237c: mov             x17, #0x278c
    // 0xc92380: cmp             w1, w17
    // 0xc92384: b.gt            #0xc92394
    // 0xc92388: r17 = 10122
    //     0xc92388: mov             x17, #0x278a
    // 0xc9238c: cmp             w1, w17
    // 0xc92390: b.ge            #0xc923ac
    // 0xc92394: r17 = 10114
    //     0xc92394: mov             x17, #0x2782
    // 0xc92398: cmp             w1, w17
    // 0xc9239c: b.eq            #0xc923ac
    // 0xc923a0: r17 = 10118
    //     0xc923a0: mov             x17, #0x2786
    // 0xc923a4: cmp             w1, w17
    // 0xc923a8: b.ne            #0xc923b4
    // 0xc923ac: LoadField: r1 = r0->field_7
    //     0xc923ac: ldur            x1, [x0, #7]
    // 0xc923b0: b               #0xc923c4
    // 0xc923b4: LoadField: r1 = r0->field_f
    //     0xc923b4: ldur            w1, [x0, #0xf]
    // 0xc923b8: DecompressPointer r1
    //     0xc923b8: add             x1, x1, HEAP, lsl #32
    // 0xc923bc: LoadField: r0 = r1->field_7
    //     0xc923bc: ldur            x0, [x1, #7]
    // 0xc923c0: mov             x1, x0
    // 0xc923c4: ldur            x0, [fp, #-8]
    // 0xc923c8: r17 = 10124
    //     0xc923c8: mov             x17, #0x278c
    // 0xc923cc: cmp             w0, w17
    // 0xc923d0: b.gt            #0xc923e0
    // 0xc923d4: r17 = 10122
    //     0xc923d4: mov             x17, #0x278a
    // 0xc923d8: cmp             w0, w17
    // 0xc923dc: b.ge            #0xc923f8
    // 0xc923e0: r17 = 10114
    //     0xc923e0: mov             x17, #0x2782
    // 0xc923e4: cmp             w0, w17
    // 0xc923e8: b.eq            #0xc923f8
    // 0xc923ec: r17 = 10118
    //     0xc923ec: mov             x17, #0x2786
    // 0xc923f0: cmp             w0, w17
    // 0xc923f4: b.ne            #0xc92404
    // 0xc923f8: ldur            x2, [fp, #-0x18]
    // 0xc923fc: LoadField: r0 = r2->field_7
    //     0xc923fc: ldur            x0, [x2, #7]
    // 0xc92400: b               #0xc92418
    // 0xc92404: ldur            x2, [fp, #-0x18]
    // 0xc92408: LoadField: r0 = r2->field_f
    //     0xc92408: ldur            w0, [x2, #0xf]
    // 0xc9240c: DecompressPointer r0
    //     0xc9240c: add             x0, x0, HEAP, lsl #32
    // 0xc92410: LoadField: r2 = r0->field_7
    //     0xc92410: ldur            x2, [x0, #7]
    // 0xc92414: mov             x0, x2
    // 0xc92418: cmp             x1, x0
    // 0xc9241c: b.ne            #0xc92884
    // 0xc92420: ldr             x1, [fp, #0x18]
    // 0xc92424: ldr             x0, [fp, #0x10]
    // 0xc92428: b               #0xc9245c
    // 0xc9242c: mov             x0, x3
    // 0xc92430: r1 = LoadClassIdInstr(r2)
    //     0xc92430: ldur            x1, [x2, #-1]
    //     0xc92434: ubfx            x1, x1, #0xc, #0x14
    // 0xc92438: stp             x0, x2, [SP, #-0x10]!
    // 0xc9243c: mov             x0, x1
    // 0xc92440: mov             lr, x0
    // 0xc92444: ldr             lr, [x21, lr, lsl #3]
    // 0xc92448: blr             lr
    // 0xc9244c: add             SP, SP, #0x10
    // 0xc92450: tbnz            w0, #4, #0xc92884
    // 0xc92454: ldr             x1, [fp, #0x18]
    // 0xc92458: ldr             x0, [fp, #0x10]
    // 0xc9245c: r17 = 355
    //     0xc9245c: mov             x17, #0x163
    // 0xc92460: ldr             w2, [x0, x17]
    // 0xc92464: DecompressPointer r2
    //     0xc92464: add             x2, x2, HEAP, lsl #32
    // 0xc92468: stur            x2, [fp, #-0x18]
    // 0xc9246c: cmp             w2, NULL
    // 0xc92470: b.eq            #0xc928bc
    // 0xc92474: r17 = 355
    //     0xc92474: mov             x17, #0x163
    // 0xc92478: ldr             w3, [x1, x17]
    // 0xc9247c: DecompressPointer r3
    //     0xc9247c: add             x3, x3, HEAP, lsl #32
    // 0xc92480: stur            x3, [fp, #-0x10]
    // 0xc92484: cmp             w3, NULL
    // 0xc92488: b.eq            #0xc928c0
    // 0xc9248c: r4 = LoadClassIdInstr(r2)
    //     0xc9248c: ldur            x4, [x2, #-1]
    //     0xc92490: ubfx            x4, x4, #0xc, #0x14
    // 0xc92494: lsl             x4, x4, #1
    // 0xc92498: stur            x4, [fp, #-8]
    // 0xc9249c: r17 = 10114
    //     0xc9249c: mov             x17, #0x2782
    // 0xc924a0: cmp             w4, w17
    // 0xc924a4: b.eq            #0xc924b4
    // 0xc924a8: r17 = 10118
    //     0xc924a8: mov             x17, #0x2786
    // 0xc924ac: cmp             w4, w17
    // 0xc924b0: b.ne            #0xc9258c
    // 0xc924b4: cmp             w2, w3
    // 0xc924b8: b.eq            #0xc925bc
    // 0xc924bc: stp             x2, x3, [SP, #-0x10]!
    // 0xc924c0: r0 = _haveSameRuntimeType()
    //     0xc924c0: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc924c4: add             SP, SP, #0x10
    // 0xc924c8: tbnz            w0, #4, #0xc92884
    // 0xc924cc: ldur            x0, [fp, #-0x10]
    // 0xc924d0: r1 = LoadClassIdInstr(r0)
    //     0xc924d0: ldur            x1, [x0, #-1]
    //     0xc924d4: ubfx            x1, x1, #0xc, #0x14
    // 0xc924d8: lsl             x1, x1, #1
    // 0xc924dc: r17 = 10124
    //     0xc924dc: mov             x17, #0x278c
    // 0xc924e0: cmp             w1, w17
    // 0xc924e4: b.gt            #0xc924f4
    // 0xc924e8: r17 = 10122
    //     0xc924e8: mov             x17, #0x278a
    // 0xc924ec: cmp             w1, w17
    // 0xc924f0: b.ge            #0xc9250c
    // 0xc924f4: r17 = 10114
    //     0xc924f4: mov             x17, #0x2782
    // 0xc924f8: cmp             w1, w17
    // 0xc924fc: b.eq            #0xc9250c
    // 0xc92500: r17 = 10118
    //     0xc92500: mov             x17, #0x2786
    // 0xc92504: cmp             w1, w17
    // 0xc92508: b.ne            #0xc92514
    // 0xc9250c: LoadField: r1 = r0->field_7
    //     0xc9250c: ldur            x1, [x0, #7]
    // 0xc92510: b               #0xc92524
    // 0xc92514: LoadField: r1 = r0->field_f
    //     0xc92514: ldur            w1, [x0, #0xf]
    // 0xc92518: DecompressPointer r1
    //     0xc92518: add             x1, x1, HEAP, lsl #32
    // 0xc9251c: LoadField: r0 = r1->field_7
    //     0xc9251c: ldur            x0, [x1, #7]
    // 0xc92520: mov             x1, x0
    // 0xc92524: ldur            x0, [fp, #-8]
    // 0xc92528: r17 = 10124
    //     0xc92528: mov             x17, #0x278c
    // 0xc9252c: cmp             w0, w17
    // 0xc92530: b.gt            #0xc92540
    // 0xc92534: r17 = 10122
    //     0xc92534: mov             x17, #0x278a
    // 0xc92538: cmp             w0, w17
    // 0xc9253c: b.ge            #0xc92558
    // 0xc92540: r17 = 10114
    //     0xc92540: mov             x17, #0x2782
    // 0xc92544: cmp             w0, w17
    // 0xc92548: b.eq            #0xc92558
    // 0xc9254c: r17 = 10118
    //     0xc9254c: mov             x17, #0x2786
    // 0xc92550: cmp             w0, w17
    // 0xc92554: b.ne            #0xc92564
    // 0xc92558: ldur            x2, [fp, #-0x18]
    // 0xc9255c: LoadField: r0 = r2->field_7
    //     0xc9255c: ldur            x0, [x2, #7]
    // 0xc92560: b               #0xc92578
    // 0xc92564: ldur            x2, [fp, #-0x18]
    // 0xc92568: LoadField: r0 = r2->field_f
    //     0xc92568: ldur            w0, [x2, #0xf]
    // 0xc9256c: DecompressPointer r0
    //     0xc9256c: add             x0, x0, HEAP, lsl #32
    // 0xc92570: LoadField: r2 = r0->field_7
    //     0xc92570: ldur            x2, [x0, #7]
    // 0xc92574: mov             x0, x2
    // 0xc92578: cmp             x1, x0
    // 0xc9257c: b.ne            #0xc92884
    // 0xc92580: ldr             x1, [fp, #0x18]
    // 0xc92584: ldr             x0, [fp, #0x10]
    // 0xc92588: b               #0xc925bc
    // 0xc9258c: mov             x0, x3
    // 0xc92590: r1 = LoadClassIdInstr(r2)
    //     0xc92590: ldur            x1, [x2, #-1]
    //     0xc92594: ubfx            x1, x1, #0xc, #0x14
    // 0xc92598: stp             x0, x2, [SP, #-0x10]!
    // 0xc9259c: mov             x0, x1
    // 0xc925a0: mov             lr, x0
    // 0xc925a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc925a8: blr             lr
    // 0xc925ac: add             SP, SP, #0x10
    // 0xc925b0: tbnz            w0, #4, #0xc92884
    // 0xc925b4: ldr             x1, [fp, #0x18]
    // 0xc925b8: ldr             x0, [fp, #0x10]
    // 0xc925bc: r17 = 359
    //     0xc925bc: mov             x17, #0x167
    // 0xc925c0: ldr             w2, [x0, x17]
    // 0xc925c4: DecompressPointer r2
    //     0xc925c4: add             x2, x2, HEAP, lsl #32
    // 0xc925c8: stur            x2, [fp, #-0x18]
    // 0xc925cc: cmp             w2, NULL
    // 0xc925d0: b.eq            #0xc928c4
    // 0xc925d4: r17 = 359
    //     0xc925d4: mov             x17, #0x167
    // 0xc925d8: ldr             w3, [x1, x17]
    // 0xc925dc: DecompressPointer r3
    //     0xc925dc: add             x3, x3, HEAP, lsl #32
    // 0xc925e0: stur            x3, [fp, #-0x10]
    // 0xc925e4: cmp             w3, NULL
    // 0xc925e8: b.eq            #0xc928c8
    // 0xc925ec: r4 = LoadClassIdInstr(r2)
    //     0xc925ec: ldur            x4, [x2, #-1]
    //     0xc925f0: ubfx            x4, x4, #0xc, #0x14
    // 0xc925f4: lsl             x4, x4, #1
    // 0xc925f8: stur            x4, [fp, #-8]
    // 0xc925fc: r17 = 10114
    //     0xc925fc: mov             x17, #0x2782
    // 0xc92600: cmp             w4, w17
    // 0xc92604: b.eq            #0xc92614
    // 0xc92608: r17 = 10118
    //     0xc92608: mov             x17, #0x2786
    // 0xc9260c: cmp             w4, w17
    // 0xc92610: b.ne            #0xc926ec
    // 0xc92614: cmp             w2, w3
    // 0xc92618: b.eq            #0xc9271c
    // 0xc9261c: stp             x2, x3, [SP, #-0x10]!
    // 0xc92620: r0 = _haveSameRuntimeType()
    //     0xc92620: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc92624: add             SP, SP, #0x10
    // 0xc92628: tbnz            w0, #4, #0xc92884
    // 0xc9262c: ldur            x0, [fp, #-0x10]
    // 0xc92630: r1 = LoadClassIdInstr(r0)
    //     0xc92630: ldur            x1, [x0, #-1]
    //     0xc92634: ubfx            x1, x1, #0xc, #0x14
    // 0xc92638: lsl             x1, x1, #1
    // 0xc9263c: r17 = 10124
    //     0xc9263c: mov             x17, #0x278c
    // 0xc92640: cmp             w1, w17
    // 0xc92644: b.gt            #0xc92654
    // 0xc92648: r17 = 10122
    //     0xc92648: mov             x17, #0x278a
    // 0xc9264c: cmp             w1, w17
    // 0xc92650: b.ge            #0xc9266c
    // 0xc92654: r17 = 10114
    //     0xc92654: mov             x17, #0x2782
    // 0xc92658: cmp             w1, w17
    // 0xc9265c: b.eq            #0xc9266c
    // 0xc92660: r17 = 10118
    //     0xc92660: mov             x17, #0x2786
    // 0xc92664: cmp             w1, w17
    // 0xc92668: b.ne            #0xc92674
    // 0xc9266c: LoadField: r1 = r0->field_7
    //     0xc9266c: ldur            x1, [x0, #7]
    // 0xc92670: b               #0xc92684
    // 0xc92674: LoadField: r1 = r0->field_f
    //     0xc92674: ldur            w1, [x0, #0xf]
    // 0xc92678: DecompressPointer r1
    //     0xc92678: add             x1, x1, HEAP, lsl #32
    // 0xc9267c: LoadField: r0 = r1->field_7
    //     0xc9267c: ldur            x0, [x1, #7]
    // 0xc92680: mov             x1, x0
    // 0xc92684: ldur            x0, [fp, #-8]
    // 0xc92688: r17 = 10124
    //     0xc92688: mov             x17, #0x278c
    // 0xc9268c: cmp             w0, w17
    // 0xc92690: b.gt            #0xc926a0
    // 0xc92694: r17 = 10122
    //     0xc92694: mov             x17, #0x278a
    // 0xc92698: cmp             w0, w17
    // 0xc9269c: b.ge            #0xc926b8
    // 0xc926a0: r17 = 10114
    //     0xc926a0: mov             x17, #0x2782
    // 0xc926a4: cmp             w0, w17
    // 0xc926a8: b.eq            #0xc926b8
    // 0xc926ac: r17 = 10118
    //     0xc926ac: mov             x17, #0x2786
    // 0xc926b0: cmp             w0, w17
    // 0xc926b4: b.ne            #0xc926c4
    // 0xc926b8: ldur            x2, [fp, #-0x18]
    // 0xc926bc: LoadField: r0 = r2->field_7
    //     0xc926bc: ldur            x0, [x2, #7]
    // 0xc926c0: b               #0xc926d8
    // 0xc926c4: ldur            x2, [fp, #-0x18]
    // 0xc926c8: LoadField: r0 = r2->field_f
    //     0xc926c8: ldur            w0, [x2, #0xf]
    // 0xc926cc: DecompressPointer r0
    //     0xc926cc: add             x0, x0, HEAP, lsl #32
    // 0xc926d0: LoadField: r2 = r0->field_7
    //     0xc926d0: ldur            x2, [x0, #7]
    // 0xc926d4: mov             x0, x2
    // 0xc926d8: cmp             x1, x0
    // 0xc926dc: b.ne            #0xc92884
    // 0xc926e0: ldr             x1, [fp, #0x18]
    // 0xc926e4: ldr             x0, [fp, #0x10]
    // 0xc926e8: b               #0xc9271c
    // 0xc926ec: mov             x0, x3
    // 0xc926f0: r1 = LoadClassIdInstr(r2)
    //     0xc926f0: ldur            x1, [x2, #-1]
    //     0xc926f4: ubfx            x1, x1, #0xc, #0x14
    // 0xc926f8: stp             x0, x2, [SP, #-0x10]!
    // 0xc926fc: mov             x0, x1
    // 0xc92700: mov             lr, x0
    // 0xc92704: ldr             lr, [x21, lr, lsl #3]
    // 0xc92708: blr             lr
    // 0xc9270c: add             SP, SP, #0x10
    // 0xc92710: tbnz            w0, #4, #0xc92884
    // 0xc92714: ldr             x1, [fp, #0x18]
    // 0xc92718: ldr             x0, [fp, #0x10]
    // 0xc9271c: LoadField: r2 = r0->field_33
    //     0xc9271c: ldur            w2, [x0, #0x33]
    // 0xc92720: DecompressPointer r2
    //     0xc92720: add             x2, x2, HEAP, lsl #32
    // 0xc92724: stur            x2, [fp, #-0x18]
    // 0xc92728: cmp             w2, NULL
    // 0xc9272c: b.eq            #0xc928cc
    // 0xc92730: LoadField: r0 = r1->field_33
    //     0xc92730: ldur            w0, [x1, #0x33]
    // 0xc92734: DecompressPointer r0
    //     0xc92734: add             x0, x0, HEAP, lsl #32
    // 0xc92738: stur            x0, [fp, #-0x10]
    // 0xc9273c: cmp             w0, NULL
    // 0xc92740: b.eq            #0xc928d0
    // 0xc92744: r1 = LoadClassIdInstr(r2)
    //     0xc92744: ldur            x1, [x2, #-1]
    //     0xc92748: ubfx            x1, x1, #0xc, #0x14
    // 0xc9274c: lsl             x1, x1, #1
    // 0xc92750: stur            x1, [fp, #-8]
    // 0xc92754: r17 = 10114
    //     0xc92754: mov             x17, #0x2782
    // 0xc92758: cmp             w1, w17
    // 0xc9275c: b.eq            #0xc9276c
    // 0xc92760: r17 = 10118
    //     0xc92760: mov             x17, #0x2786
    // 0xc92764: cmp             w1, w17
    // 0xc92768: b.ne            #0xc92858
    // 0xc9276c: cmp             w2, w0
    // 0xc92770: b.ne            #0xc9277c
    // 0xc92774: r1 = true
    //     0xc92774: add             x1, NULL, #0x20  ; true
    // 0xc92778: b               #0xc9287c
    // 0xc9277c: stp             x2, x0, [SP, #-0x10]!
    // 0xc92780: r0 = _haveSameRuntimeType()
    //     0xc92780: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc92784: add             SP, SP, #0x10
    // 0xc92788: tbz             w0, #4, #0xc92794
    // 0xc9278c: r1 = false
    //     0xc9278c: add             x1, NULL, #0x30  ; false
    // 0xc92790: b               #0xc9287c
    // 0xc92794: ldur            x0, [fp, #-0x10]
    // 0xc92798: r1 = LoadClassIdInstr(r0)
    //     0xc92798: ldur            x1, [x0, #-1]
    //     0xc9279c: ubfx            x1, x1, #0xc, #0x14
    // 0xc927a0: lsl             x1, x1, #1
    // 0xc927a4: r17 = 10124
    //     0xc927a4: mov             x17, #0x278c
    // 0xc927a8: cmp             w1, w17
    // 0xc927ac: b.gt            #0xc927bc
    // 0xc927b0: r17 = 10122
    //     0xc927b0: mov             x17, #0x278a
    // 0xc927b4: cmp             w1, w17
    // 0xc927b8: b.ge            #0xc927d4
    // 0xc927bc: r17 = 10114
    //     0xc927bc: mov             x17, #0x2782
    // 0xc927c0: cmp             w1, w17
    // 0xc927c4: b.eq            #0xc927d4
    // 0xc927c8: r17 = 10118
    //     0xc927c8: mov             x17, #0x2786
    // 0xc927cc: cmp             w1, w17
    // 0xc927d0: b.ne            #0xc927dc
    // 0xc927d4: LoadField: r1 = r0->field_7
    //     0xc927d4: ldur            x1, [x0, #7]
    // 0xc927d8: b               #0xc927ec
    // 0xc927dc: LoadField: r1 = r0->field_f
    //     0xc927dc: ldur            w1, [x0, #0xf]
    // 0xc927e0: DecompressPointer r1
    //     0xc927e0: add             x1, x1, HEAP, lsl #32
    // 0xc927e4: LoadField: r0 = r1->field_7
    //     0xc927e4: ldur            x0, [x1, #7]
    // 0xc927e8: mov             x1, x0
    // 0xc927ec: ldur            x0, [fp, #-8]
    // 0xc927f0: r17 = 10124
    //     0xc927f0: mov             x17, #0x278c
    // 0xc927f4: cmp             w0, w17
    // 0xc927f8: b.gt            #0xc92808
    // 0xc927fc: r17 = 10122
    //     0xc927fc: mov             x17, #0x278a
    // 0xc92800: cmp             w0, w17
    // 0xc92804: b.ge            #0xc92820
    // 0xc92808: r17 = 10114
    //     0xc92808: mov             x17, #0x2782
    // 0xc9280c: cmp             w0, w17
    // 0xc92810: b.eq            #0xc92820
    // 0xc92814: r17 = 10118
    //     0xc92814: mov             x17, #0x2786
    // 0xc92818: cmp             w0, w17
    // 0xc9281c: b.ne            #0xc9282c
    // 0xc92820: ldur            x2, [fp, #-0x18]
    // 0xc92824: LoadField: r0 = r2->field_7
    //     0xc92824: ldur            x0, [x2, #7]
    // 0xc92828: b               #0xc92840
    // 0xc9282c: ldur            x2, [fp, #-0x18]
    // 0xc92830: LoadField: r0 = r2->field_f
    //     0xc92830: ldur            w0, [x2, #0xf]
    // 0xc92834: DecompressPointer r0
    //     0xc92834: add             x0, x0, HEAP, lsl #32
    // 0xc92838: LoadField: r2 = r0->field_7
    //     0xc92838: ldur            x2, [x0, #7]
    // 0xc9283c: mov             x0, x2
    // 0xc92840: cmp             x1, x0
    // 0xc92844: r16 = true
    //     0xc92844: add             x16, NULL, #0x20  ; true
    // 0xc92848: r17 = false
    //     0xc92848: add             x17, NULL, #0x30  ; false
    // 0xc9284c: csel            x2, x16, x17, eq
    // 0xc92850: mov             x1, x2
    // 0xc92854: b               #0xc9287c
    // 0xc92858: r1 = LoadClassIdInstr(r2)
    //     0xc92858: ldur            x1, [x2, #-1]
    //     0xc9285c: ubfx            x1, x1, #0xc, #0x14
    // 0xc92860: stp             x0, x2, [SP, #-0x10]!
    // 0xc92864: mov             x0, x1
    // 0xc92868: mov             lr, x0
    // 0xc9286c: ldr             lr, [x21, lr, lsl #3]
    // 0xc92870: blr             lr
    // 0xc92874: add             SP, SP, #0x10
    // 0xc92878: mov             x1, x0
    // 0xc9287c: mov             x0, x1
    // 0xc92880: b               #0xc92888
    // 0xc92884: r0 = false
    //     0xc92884: add             x0, NULL, #0x30  ; false
    // 0xc92888: LeaveFrame
    //     0xc92888: mov             SP, fp
    //     0xc9288c: ldp             fp, lr, [SP], #0x10
    // 0xc92890: ret
    //     0xc92890: ret             
    // 0xc92894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc92894: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc92898: b               #0xc90568
    // 0xc9289c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc9289c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc928d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc928d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5943, size: 0x14, field offset: 0x14
enum MaterialTapTargetSize extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb1669c, size: 0x5c
    // 0xb1669c: EnterFrame
    //     0xb1669c: stp             fp, lr, [SP, #-0x10]!
    //     0xb166a0: mov             fp, SP
    // 0xb166a4: CheckStackOverflow
    //     0xb166a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb166a8: cmp             SP, x16
    //     0xb166ac: b.ls            #0xb166f0
    // 0xb166b0: r1 = Null
    //     0xb166b0: mov             x1, NULL
    // 0xb166b4: r2 = 4
    //     0xb166b4: mov             x2, #4
    // 0xb166b8: r0 = AllocateArray()
    //     0xb166b8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb166bc: r17 = "MaterialTapTargetSize."
    //     0xb166bc: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf20] "MaterialTapTargetSize."
    //     0xb166c0: ldr             x17, [x17, #0xf20]
    // 0xb166c4: StoreField: r0->field_f = r17
    //     0xb166c4: stur            w17, [x0, #0xf]
    // 0xb166c8: ldr             x1, [fp, #0x10]
    // 0xb166cc: LoadField: r2 = r1->field_f
    //     0xb166cc: ldur            w2, [x1, #0xf]
    // 0xb166d0: DecompressPointer r2
    //     0xb166d0: add             x2, x2, HEAP, lsl #32
    // 0xb166d4: StoreField: r0->field_13 = r2
    //     0xb166d4: stur            w2, [x0, #0x13]
    // 0xb166d8: SaveReg r0
    //     0xb166d8: str             x0, [SP, #-8]!
    // 0xb166dc: r0 = _interpolate()
    //     0xb166dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb166e0: add             SP, SP, #8
    // 0xb166e4: LeaveFrame
    //     0xb166e4: mov             SP, fp
    //     0xb166e8: ldp             fp, lr, [SP], #0x10
    // 0xb166ec: ret
    //     0xb166ec: ret             
    // 0xb166f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb166f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb166f4: b               #0xb166b0
  }
}

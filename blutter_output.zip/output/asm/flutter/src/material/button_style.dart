// lib: , url: package:flutter/src/material/button_style.dart

// class id: 1049197, size: 0x8
class :: {
}

// class id: 2236, size: 0x18, field offset: 0x8
//   const constructor, 
class _LerpSides extends Object
    implements MaterialStateProperty<X0> {

  _ resolve(/* No info */) {
    // ** addr: 0x5b4654, size: 0x21c
    // 0x5b4654: EnterFrame
    //     0x5b4654: stp             fp, lr, [SP, #-0x10]!
    //     0x5b4658: mov             fp, SP
    // 0x5b465c: AllocStack(0x18)
    //     0x5b465c: sub             SP, SP, #0x18
    // 0x5b4660: CheckStackOverflow
    //     0x5b4660: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b4664: cmp             SP, x16
    //     0x5b4668: b.ls            #0x5b4864
    // 0x5b466c: ldr             x1, [fp, #0x18]
    // 0x5b4670: LoadField: r0 = r1->field_7
    //     0x5b4670: ldur            w0, [x1, #7]
    // 0x5b4674: DecompressPointer r0
    //     0x5b4674: add             x0, x0, HEAP, lsl #32
    // 0x5b4678: cmp             w0, NULL
    // 0x5b467c: b.ne            #0x5b4688
    // 0x5b4680: r2 = Null
    //     0x5b4680: mov             x2, NULL
    // 0x5b4684: b               #0x5b46bc
    // 0x5b4688: r2 = LoadClassIdInstr(r0)
    //     0x5b4688: ldur            x2, [x0, #-1]
    //     0x5b468c: ubfx            x2, x2, #0xc, #0x14
    // 0x5b4690: ldr             x16, [fp, #0x10]
    // 0x5b4694: stp             x16, x0, [SP, #-0x10]!
    // 0x5b4698: mov             x0, x2
    // 0x5b469c: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x5b469c: mov             x17, #0x5e7
    //     0x5b46a0: movk            x17, #1, lsl #16
    //     0x5b46a4: add             lr, x0, x17
    //     0x5b46a8: ldr             lr, [x21, lr, lsl #3]
    //     0x5b46ac: blr             lr
    // 0x5b46b0: add             SP, SP, #0x10
    // 0x5b46b4: mov             x2, x0
    // 0x5b46b8: ldr             x1, [fp, #0x18]
    // 0x5b46bc: stur            x2, [fp, #-8]
    // 0x5b46c0: LoadField: r0 = r1->field_b
    //     0x5b46c0: ldur            w0, [x1, #0xb]
    // 0x5b46c4: DecompressPointer r0
    //     0x5b46c4: add             x0, x0, HEAP, lsl #32
    // 0x5b46c8: cmp             w0, NULL
    // 0x5b46cc: b.ne            #0x5b46dc
    // 0x5b46d0: mov             x0, x2
    // 0x5b46d4: r1 = Null
    //     0x5b46d4: mov             x1, NULL
    // 0x5b46d8: b               #0x5b4710
    // 0x5b46dc: r3 = LoadClassIdInstr(r0)
    //     0x5b46dc: ldur            x3, [x0, #-1]
    //     0x5b46e0: ubfx            x3, x3, #0xc, #0x14
    // 0x5b46e4: ldr             x16, [fp, #0x10]
    // 0x5b46e8: stp             x16, x0, [SP, #-0x10]!
    // 0x5b46ec: mov             x0, x3
    // 0x5b46f0: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x5b46f0: mov             x17, #0x5e7
    //     0x5b46f4: movk            x17, #1, lsl #16
    //     0x5b46f8: add             lr, x0, x17
    //     0x5b46fc: ldr             lr, [x21, lr, lsl #3]
    //     0x5b4700: blr             lr
    // 0x5b4704: add             SP, SP, #0x10
    // 0x5b4708: mov             x1, x0
    // 0x5b470c: ldur            x0, [fp, #-8]
    // 0x5b4710: stur            x1, [fp, #-0x10]
    // 0x5b4714: cmp             w0, NULL
    // 0x5b4718: b.ne            #0x5b4734
    // 0x5b471c: cmp             w1, NULL
    // 0x5b4720: b.ne            #0x5b4734
    // 0x5b4724: r0 = Null
    //     0x5b4724: mov             x0, NULL
    // 0x5b4728: LeaveFrame
    //     0x5b4728: mov             SP, fp
    //     0x5b472c: ldp             fp, lr, [SP], #0x10
    // 0x5b4730: ret
    //     0x5b4730: ret             
    // 0x5b4734: cmp             w0, NULL
    // 0x5b4738: b.ne            #0x5b47b4
    // 0x5b473c: ldr             x0, [fp, #0x18]
    // 0x5b4740: cmp             w1, NULL
    // 0x5b4744: b.eq            #0x5b486c
    // 0x5b4748: LoadField: r2 = r1->field_7
    //     0x5b4748: ldur            w2, [x1, #7]
    // 0x5b474c: DecompressPointer r2
    //     0x5b474c: add             x2, x2, HEAP, lsl #32
    // 0x5b4750: stp             xzr, x2, [SP, #-0x10]!
    // 0x5b4754: r0 = withAlpha()
    //     0x5b4754: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x5b4758: add             SP, SP, #0x10
    // 0x5b475c: stur            x0, [fp, #-0x18]
    // 0x5b4760: r0 = BorderSide()
    //     0x5b4760: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x5b4764: mov             x1, x0
    // 0x5b4768: ldur            x0, [fp, #-0x18]
    // 0x5b476c: StoreField: r1->field_7 = r0
    //     0x5b476c: stur            w0, [x1, #7]
    // 0x5b4770: d0 = 0.000000
    //     0x5b4770: eor             v0.16b, v0.16b, v0.16b
    // 0x5b4774: StoreField: r1->field_b = d0
    //     0x5b4774: stur            d0, [x1, #0xb]
    // 0x5b4778: r2 = Instance_BorderStyle
    //     0x5b4778: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b477c: ldr             x2, [x2, #0xbd0]
    // 0x5b4780: StoreField: r1->field_13 = r2
    //     0x5b4780: stur            w2, [x1, #0x13]
    // 0x5b4784: d1 = -1.000000
    //     0x5b4784: fmov            d1, #-1.00000000
    // 0x5b4788: StoreField: r1->field_17 = d1
    //     0x5b4788: stur            d1, [x1, #0x17]
    // 0x5b478c: ldr             x3, [fp, #0x18]
    // 0x5b4790: LoadField: d0 = r3->field_f
    //     0x5b4790: ldur            d0, [x3, #0xf]
    // 0x5b4794: ldur            x16, [fp, #-0x10]
    // 0x5b4798: stp             x16, x1, [SP, #-0x10]!
    // 0x5b479c: SaveReg d0
    //     0x5b479c: str             d0, [SP, #-8]!
    // 0x5b47a0: r0 = lerp()
    //     0x5b47a0: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x5b47a4: add             SP, SP, #0x18
    // 0x5b47a8: LeaveFrame
    //     0x5b47a8: mov             SP, fp
    //     0x5b47ac: ldp             fp, lr, [SP], #0x10
    // 0x5b47b0: ret
    //     0x5b47b0: ret             
    // 0x5b47b4: ldr             x3, [fp, #0x18]
    // 0x5b47b8: r2 = Instance_BorderStyle
    //     0x5b47b8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b47bc: ldr             x2, [x2, #0xbd0]
    // 0x5b47c0: d0 = 0.000000
    //     0x5b47c0: eor             v0.16b, v0.16b, v0.16b
    // 0x5b47c4: d1 = -1.000000
    //     0x5b47c4: fmov            d1, #-1.00000000
    // 0x5b47c8: cmp             w1, NULL
    // 0x5b47cc: b.ne            #0x5b483c
    // 0x5b47d0: LoadField: r1 = r0->field_7
    //     0x5b47d0: ldur            w1, [x0, #7]
    // 0x5b47d4: DecompressPointer r1
    //     0x5b47d4: add             x1, x1, HEAP, lsl #32
    // 0x5b47d8: stp             xzr, x1, [SP, #-0x10]!
    // 0x5b47dc: r0 = withAlpha()
    //     0x5b47dc: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x5b47e0: add             SP, SP, #0x10
    // 0x5b47e4: stur            x0, [fp, #-0x18]
    // 0x5b47e8: r0 = BorderSide()
    //     0x5b47e8: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x5b47ec: mov             x1, x0
    // 0x5b47f0: ldur            x0, [fp, #-0x18]
    // 0x5b47f4: StoreField: r1->field_7 = r0
    //     0x5b47f4: stur            w0, [x1, #7]
    // 0x5b47f8: d0 = 0.000000
    //     0x5b47f8: eor             v0.16b, v0.16b, v0.16b
    // 0x5b47fc: StoreField: r1->field_b = d0
    //     0x5b47fc: stur            d0, [x1, #0xb]
    // 0x5b4800: r0 = Instance_BorderStyle
    //     0x5b4800: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x5b4804: ldr             x0, [x0, #0xbd0]
    // 0x5b4808: StoreField: r1->field_13 = r0
    //     0x5b4808: stur            w0, [x1, #0x13]
    // 0x5b480c: d0 = -1.000000
    //     0x5b480c: fmov            d0, #-1.00000000
    // 0x5b4810: StoreField: r1->field_17 = d0
    //     0x5b4810: stur            d0, [x1, #0x17]
    // 0x5b4814: ldr             x0, [fp, #0x18]
    // 0x5b4818: LoadField: d0 = r0->field_f
    //     0x5b4818: ldur            d0, [x0, #0xf]
    // 0x5b481c: ldur            x16, [fp, #-8]
    // 0x5b4820: stp             x1, x16, [SP, #-0x10]!
    // 0x5b4824: SaveReg d0
    //     0x5b4824: str             d0, [SP, #-8]!
    // 0x5b4828: r0 = lerp()
    //     0x5b4828: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x5b482c: add             SP, SP, #0x18
    // 0x5b4830: LeaveFrame
    //     0x5b4830: mov             SP, fp
    //     0x5b4834: ldp             fp, lr, [SP], #0x10
    // 0x5b4838: ret
    //     0x5b4838: ret             
    // 0x5b483c: mov             x0, x3
    // 0x5b4840: LoadField: d0 = r0->field_f
    //     0x5b4840: ldur            d0, [x0, #0xf]
    // 0x5b4844: ldur            x16, [fp, #-8]
    // 0x5b4848: stp             x1, x16, [SP, #-0x10]!
    // 0x5b484c: SaveReg d0
    //     0x5b484c: str             d0, [SP, #-8]!
    // 0x5b4850: r0 = lerp()
    //     0x5b4850: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x5b4854: add             SP, SP, #0x18
    // 0x5b4858: LeaveFrame
    //     0x5b4858: mov             SP, fp
    //     0x5b485c: ldp             fp, lr, [SP], #0x10
    // 0x5b4860: ret
    //     0x5b4860: ret             
    // 0x5b4864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b4864: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b4868: b               #0x5b466c
    // 0x5b486c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5b486c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2829, size: 0x60, field offset: 0x8
//   const constructor, 
class ButtonStyle extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafdff8, size: 0x680
    // 0xafdff8: EnterFrame
    //     0xafdff8: stp             fp, lr, [SP, #-0x10]!
    //     0xafdffc: mov             fp, SP
    // 0xafe000: AllocStack(0x10)
    //     0xafe000: sub             SP, SP, #0x10
    // 0xafe004: CheckStackOverflow
    //     0xafe004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafe008: cmp             SP, x16
    //     0xafe00c: b.ls            #0xafe670
    // 0xafe010: ldr             x1, [fp, #0x10]
    // 0xafe014: r0 = LoadClassIdInstr(r1)
    //     0xafe014: ldur            x0, [x1, #-1]
    //     0xafe018: ubfx            x0, x0, #0xc, #0x14
    // 0xafe01c: SaveReg r1
    //     0xafe01c: str             x1, [SP, #-8]!
    // 0xafe020: r0 = GDT[cid_x0 + -0xf5d]()
    //     0xafe020: sub             lr, x0, #0xf5d
    //     0xafe024: ldr             lr, [x21, lr, lsl #3]
    //     0xafe028: blr             lr
    // 0xafe02c: add             SP, SP, #8
    // 0xafe030: r1 = <Object?>
    //     0xafe030: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xafe034: r2 = 44
    //     0xafe034: mov             x2, #0x2c
    // 0xafe038: stur            x0, [fp, #-8]
    // 0xafe03c: r0 = AllocateArray()
    //     0xafe03c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xafe040: mov             x1, x0
    // 0xafe044: ldur            x0, [fp, #-8]
    // 0xafe048: stur            x1, [fp, #-0x10]
    // 0xafe04c: StoreField: r1->field_f = r0
    //     0xafe04c: stur            w0, [x1, #0xf]
    // 0xafe050: ldr             x2, [fp, #0x10]
    // 0xafe054: r0 = LoadClassIdInstr(r2)
    //     0xafe054: ldur            x0, [x2, #-1]
    //     0xafe058: ubfx            x0, x0, #0xc, #0x14
    // 0xafe05c: SaveReg r2
    //     0xafe05c: str             x2, [SP, #-8]!
    // 0xafe060: r0 = GDT[cid_x0 + -0xf54]()
    //     0xafe060: sub             lr, x0, #0xf54
    //     0xafe064: ldr             lr, [x21, lr, lsl #3]
    //     0xafe068: blr             lr
    // 0xafe06c: add             SP, SP, #8
    // 0xafe070: ldur            x1, [fp, #-0x10]
    // 0xafe074: ArrayStore: r1[1] = r0  ; List_4
    //     0xafe074: add             x25, x1, #0x13
    //     0xafe078: str             w0, [x25]
    //     0xafe07c: tbz             w0, #0, #0xafe098
    //     0xafe080: ldurb           w16, [x1, #-1]
    //     0xafe084: ldurb           w17, [x0, #-1]
    //     0xafe088: and             x16, x17, x16, lsr #2
    //     0xafe08c: tst             x16, HEAP, lsr #32
    //     0xafe090: b.eq            #0xafe098
    //     0xafe094: bl              #0xd67e5c
    // 0xafe098: ldr             x1, [fp, #0x10]
    // 0xafe09c: r0 = LoadClassIdInstr(r1)
    //     0xafe09c: ldur            x0, [x1, #-1]
    //     0xafe0a0: ubfx            x0, x0, #0xc, #0x14
    // 0xafe0a4: SaveReg r1
    //     0xafe0a4: str             x1, [SP, #-8]!
    // 0xafe0a8: r0 = GDT[cid_x0 + -0xf4f]()
    //     0xafe0a8: sub             lr, x0, #0xf4f
    //     0xafe0ac: ldr             lr, [x21, lr, lsl #3]
    //     0xafe0b0: blr             lr
    // 0xafe0b4: add             SP, SP, #8
    // 0xafe0b8: ldur            x1, [fp, #-0x10]
    // 0xafe0bc: ArrayStore: r1[2] = r0  ; List_4
    //     0xafe0bc: add             x25, x1, #0x17
    //     0xafe0c0: str             w0, [x25]
    //     0xafe0c4: tbz             w0, #0, #0xafe0e0
    //     0xafe0c8: ldurb           w16, [x1, #-1]
    //     0xafe0cc: ldurb           w17, [x0, #-1]
    //     0xafe0d0: and             x16, x17, x16, lsr #2
    //     0xafe0d4: tst             x16, HEAP, lsr #32
    //     0xafe0d8: b.eq            #0xafe0e0
    //     0xafe0dc: bl              #0xd67e5c
    // 0xafe0e0: ldr             x1, [fp, #0x10]
    // 0xafe0e4: r0 = LoadClassIdInstr(r1)
    //     0xafe0e4: ldur            x0, [x1, #-1]
    //     0xafe0e8: ubfx            x0, x0, #0xc, #0x14
    // 0xafe0ec: SaveReg r1
    //     0xafe0ec: str             x1, [SP, #-8]!
    // 0xafe0f0: r0 = GDT[cid_x0 + -0xf1b]()
    //     0xafe0f0: sub             lr, x0, #0xf1b
    //     0xafe0f4: ldr             lr, [x21, lr, lsl #3]
    //     0xafe0f8: blr             lr
    // 0xafe0fc: add             SP, SP, #8
    // 0xafe100: ldur            x1, [fp, #-0x10]
    // 0xafe104: ArrayStore: r1[3] = r0  ; List_4
    //     0xafe104: add             x25, x1, #0x1b
    //     0xafe108: str             w0, [x25]
    //     0xafe10c: tbz             w0, #0, #0xafe128
    //     0xafe110: ldurb           w16, [x1, #-1]
    //     0xafe114: ldurb           w17, [x0, #-1]
    //     0xafe118: and             x16, x17, x16, lsr #2
    //     0xafe11c: tst             x16, HEAP, lsr #32
    //     0xafe120: b.eq            #0xafe128
    //     0xafe124: bl              #0xd67e5c
    // 0xafe128: ldr             x1, [fp, #0x10]
    // 0xafe12c: r0 = LoadClassIdInstr(r1)
    //     0xafe12c: ldur            x0, [x1, #-1]
    //     0xafe130: ubfx            x0, x0, #0xc, #0x14
    // 0xafe134: SaveReg r1
    //     0xafe134: str             x1, [SP, #-8]!
    // 0xafe138: r0 = GDT[cid_x0 + -0xefb]()
    //     0xafe138: sub             lr, x0, #0xefb
    //     0xafe13c: ldr             lr, [x21, lr, lsl #3]
    //     0xafe140: blr             lr
    // 0xafe144: add             SP, SP, #8
    // 0xafe148: ldur            x1, [fp, #-0x10]
    // 0xafe14c: ArrayStore: r1[4] = r0  ; List_4
    //     0xafe14c: add             x25, x1, #0x1f
    //     0xafe150: str             w0, [x25]
    //     0xafe154: tbz             w0, #0, #0xafe170
    //     0xafe158: ldurb           w16, [x1, #-1]
    //     0xafe15c: ldurb           w17, [x0, #-1]
    //     0xafe160: and             x16, x17, x16, lsr #2
    //     0xafe164: tst             x16, HEAP, lsr #32
    //     0xafe168: b.eq            #0xafe170
    //     0xafe16c: bl              #0xd67e5c
    // 0xafe170: ldr             x1, [fp, #0x10]
    // 0xafe174: r0 = LoadClassIdInstr(r1)
    //     0xafe174: ldur            x0, [x1, #-1]
    //     0xafe178: ubfx            x0, x0, #0xc, #0x14
    // 0xafe17c: SaveReg r1
    //     0xafe17c: str             x1, [SP, #-8]!
    // 0xafe180: r0 = GDT[cid_x0 + -0xef6]()
    //     0xafe180: sub             lr, x0, #0xef6
    //     0xafe184: ldr             lr, [x21, lr, lsl #3]
    //     0xafe188: blr             lr
    // 0xafe18c: add             SP, SP, #8
    // 0xafe190: ldur            x1, [fp, #-0x10]
    // 0xafe194: ArrayStore: r1[5] = r0  ; List_4
    //     0xafe194: add             x25, x1, #0x23
    //     0xafe198: str             w0, [x25]
    //     0xafe19c: tbz             w0, #0, #0xafe1b8
    //     0xafe1a0: ldurb           w16, [x1, #-1]
    //     0xafe1a4: ldurb           w17, [x0, #-1]
    //     0xafe1a8: and             x16, x17, x16, lsr #2
    //     0xafe1ac: tst             x16, HEAP, lsr #32
    //     0xafe1b0: b.eq            #0xafe1b8
    //     0xafe1b4: bl              #0xd67e5c
    // 0xafe1b8: ldr             x1, [fp, #0x10]
    // 0xafe1bc: r0 = LoadClassIdInstr(r1)
    //     0xafe1bc: ldur            x0, [x1, #-1]
    //     0xafe1c0: ubfx            x0, x0, #0xc, #0x14
    // 0xafe1c4: SaveReg r1
    //     0xafe1c4: str             x1, [SP, #-8]!
    // 0xafe1c8: r0 = GDT[cid_x0 + -0xee9]()
    //     0xafe1c8: sub             lr, x0, #0xee9
    //     0xafe1cc: ldr             lr, [x21, lr, lsl #3]
    //     0xafe1d0: blr             lr
    // 0xafe1d4: add             SP, SP, #8
    // 0xafe1d8: ldur            x1, [fp, #-0x10]
    // 0xafe1dc: ArrayStore: r1[6] = r0  ; List_4
    //     0xafe1dc: add             x25, x1, #0x27
    //     0xafe1e0: str             w0, [x25]
    //     0xafe1e4: tbz             w0, #0, #0xafe200
    //     0xafe1e8: ldurb           w16, [x1, #-1]
    //     0xafe1ec: ldurb           w17, [x0, #-1]
    //     0xafe1f0: and             x16, x17, x16, lsr #2
    //     0xafe1f4: tst             x16, HEAP, lsr #32
    //     0xafe1f8: b.eq            #0xafe200
    //     0xafe1fc: bl              #0xd67e5c
    // 0xafe200: ldr             x1, [fp, #0x10]
    // 0xafe204: r0 = LoadClassIdInstr(r1)
    //     0xafe204: ldur            x0, [x1, #-1]
    //     0xafe208: ubfx            x0, x0, #0xc, #0x14
    // 0xafe20c: SaveReg r1
    //     0xafe20c: str             x1, [SP, #-8]!
    // 0xafe210: r0 = GDT[cid_x0 + -0xee0]()
    //     0xafe210: sub             lr, x0, #0xee0
    //     0xafe214: ldr             lr, [x21, lr, lsl #3]
    //     0xafe218: blr             lr
    // 0xafe21c: add             SP, SP, #8
    // 0xafe220: ldur            x1, [fp, #-0x10]
    // 0xafe224: ArrayStore: r1[7] = r0  ; List_4
    //     0xafe224: add             x25, x1, #0x2b
    //     0xafe228: str             w0, [x25]
    //     0xafe22c: tbz             w0, #0, #0xafe248
    //     0xafe230: ldurb           w16, [x1, #-1]
    //     0xafe234: ldurb           w17, [x0, #-1]
    //     0xafe238: and             x16, x17, x16, lsr #2
    //     0xafe23c: tst             x16, HEAP, lsr #32
    //     0xafe240: b.eq            #0xafe248
    //     0xafe244: bl              #0xd67e5c
    // 0xafe248: ldr             x1, [fp, #0x10]
    // 0xafe24c: r0 = LoadClassIdInstr(r1)
    //     0xafe24c: ldur            x0, [x1, #-1]
    //     0xafe250: ubfx            x0, x0, #0xc, #0x14
    // 0xafe254: SaveReg r1
    //     0xafe254: str             x1, [SP, #-8]!
    // 0xafe258: r0 = GDT[cid_x0 + -0xedb]()
    //     0xafe258: sub             lr, x0, #0xedb
    //     0xafe25c: ldr             lr, [x21, lr, lsl #3]
    //     0xafe260: blr             lr
    // 0xafe264: add             SP, SP, #8
    // 0xafe268: ldur            x1, [fp, #-0x10]
    // 0xafe26c: ArrayStore: r1[8] = r0  ; List_4
    //     0xafe26c: add             x25, x1, #0x2f
    //     0xafe270: str             w0, [x25]
    //     0xafe274: tbz             w0, #0, #0xafe290
    //     0xafe278: ldurb           w16, [x1, #-1]
    //     0xafe27c: ldurb           w17, [x0, #-1]
    //     0xafe280: and             x16, x17, x16, lsr #2
    //     0xafe284: tst             x16, HEAP, lsr #32
    //     0xafe288: b.eq            #0xafe290
    //     0xafe28c: bl              #0xd67e5c
    // 0xafe290: ldr             x2, [fp, #0x10]
    // 0xafe294: LoadField: r0 = r2->field_2b
    //     0xafe294: ldur            w0, [x2, #0x2b]
    // 0xafe298: DecompressPointer r0
    //     0xafe298: add             x0, x0, HEAP, lsl #32
    // 0xafe29c: ldur            x1, [fp, #-0x10]
    // 0xafe2a0: ArrayStore: r1[9] = r0  ; List_4
    //     0xafe2a0: add             x25, x1, #0x33
    //     0xafe2a4: str             w0, [x25]
    //     0xafe2a8: tbz             w0, #0, #0xafe2c4
    //     0xafe2ac: ldurb           w16, [x1, #-1]
    //     0xafe2b0: ldurb           w17, [x0, #-1]
    //     0xafe2b4: and             x16, x17, x16, lsr #2
    //     0xafe2b8: tst             x16, HEAP, lsr #32
    //     0xafe2bc: b.eq            #0xafe2c4
    //     0xafe2c0: bl              #0xd67e5c
    // 0xafe2c4: r0 = LoadClassIdInstr(r2)
    //     0xafe2c4: ldur            x0, [x2, #-1]
    //     0xafe2c8: ubfx            x0, x0, #0xc, #0x14
    // 0xafe2cc: SaveReg r2
    //     0xafe2cc: str             x2, [SP, #-8]!
    // 0xafe2d0: r0 = GDT[cid_x0 + -0xed4]()
    //     0xafe2d0: sub             lr, x0, #0xed4
    //     0xafe2d4: ldr             lr, [x21, lr, lsl #3]
    //     0xafe2d8: blr             lr
    // 0xafe2dc: add             SP, SP, #8
    // 0xafe2e0: ldur            x1, [fp, #-0x10]
    // 0xafe2e4: ArrayStore: r1[10] = r0  ; List_4
    //     0xafe2e4: add             x25, x1, #0x37
    //     0xafe2e8: str             w0, [x25]
    //     0xafe2ec: tbz             w0, #0, #0xafe308
    //     0xafe2f0: ldurb           w16, [x1, #-1]
    //     0xafe2f4: ldurb           w17, [x0, #-1]
    //     0xafe2f8: and             x16, x17, x16, lsr #2
    //     0xafe2fc: tst             x16, HEAP, lsr #32
    //     0xafe300: b.eq            #0xafe308
    //     0xafe304: bl              #0xd67e5c
    // 0xafe308: ldr             x2, [fp, #0x10]
    // 0xafe30c: LoadField: r0 = r2->field_33
    //     0xafe30c: ldur            w0, [x2, #0x33]
    // 0xafe310: DecompressPointer r0
    //     0xafe310: add             x0, x0, HEAP, lsl #32
    // 0xafe314: ldur            x1, [fp, #-0x10]
    // 0xafe318: ArrayStore: r1[11] = r0  ; List_4
    //     0xafe318: add             x25, x1, #0x3b
    //     0xafe31c: str             w0, [x25]
    //     0xafe320: tbz             w0, #0, #0xafe33c
    //     0xafe324: ldurb           w16, [x1, #-1]
    //     0xafe328: ldurb           w17, [x0, #-1]
    //     0xafe32c: and             x16, x17, x16, lsr #2
    //     0xafe330: tst             x16, HEAP, lsr #32
    //     0xafe334: b.eq            #0xafe33c
    //     0xafe338: bl              #0xd67e5c
    // 0xafe33c: r3 = LoadClassIdInstr(r2)
    //     0xafe33c: ldur            x3, [x2, #-1]
    //     0xafe340: ubfx            x3, x3, #0xc, #0x14
    // 0xafe344: lsl             x3, x3, #1
    // 0xafe348: r17 = 5662
    //     0xafe348: mov             x17, #0x161e
    // 0xafe34c: cmp             w3, w17
    // 0xafe350: b.gt            #0xafe360
    // 0xafe354: r17 = 5658
    //     0xafe354: mov             x17, #0x161a
    // 0xafe358: cmp             w3, w17
    // 0xafe35c: b.ge            #0xafe378
    // 0xafe360: r17 = 5664
    //     0xafe360: mov             x17, #0x1620
    // 0xafe364: cmp             w3, w17
    // 0xafe368: b.ne            #0xafe378
    // 0xafe36c: r0 = Instance_MaterialStatePropertyAll
    //     0xafe36c: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e6f0] Obj!MaterialStatePropertyAll<double>@b37c81
    //     0xafe370: ldr             x0, [x0, #0x6f0]
    // 0xafe374: b               #0xafe380
    // 0xafe378: LoadField: r0 = r2->field_37
    //     0xafe378: ldur            w0, [x2, #0x37]
    // 0xafe37c: DecompressPointer r0
    //     0xafe37c: add             x0, x0, HEAP, lsl #32
    // 0xafe380: ldur            x1, [fp, #-0x10]
    // 0xafe384: ArrayStore: r1[12] = r0  ; List_4
    //     0xafe384: add             x25, x1, #0x3f
    //     0xafe388: str             w0, [x25]
    //     0xafe38c: tbz             w0, #0, #0xafe3a8
    //     0xafe390: ldurb           w16, [x1, #-1]
    //     0xafe394: ldurb           w17, [x0, #-1]
    //     0xafe398: and             x16, x17, x16, lsr #2
    //     0xafe39c: tst             x16, HEAP, lsr #32
    //     0xafe3a0: b.eq            #0xafe3a8
    //     0xafe3a4: bl              #0xd67e5c
    // 0xafe3a8: r17 = 5660
    //     0xafe3a8: mov             x17, #0x161c
    // 0xafe3ac: cmp             w3, w17
    // 0xafe3b0: b.gt            #0xafe3c0
    // 0xafe3b4: r17 = 5658
    //     0xafe3b4: mov             x17, #0x161a
    // 0xafe3b8: cmp             w3, w17
    // 0xafe3bc: b.ge            #0xafe3d8
    // 0xafe3c0: r17 = 5666
    //     0xafe3c0: mov             x17, #0x1622
    // 0xafe3c4: cmp             w3, w17
    // 0xafe3c8: b.gt            #0xafe3e4
    // 0xafe3cc: r17 = 5664
    //     0xafe3cc: mov             x17, #0x1620
    // 0xafe3d0: cmp             w3, w17
    // 0xafe3d4: b.lt            #0xafe3e4
    // 0xafe3d8: LoadField: r0 = r2->field_3b
    //     0xafe3d8: ldur            w0, [x2, #0x3b]
    // 0xafe3dc: DecompressPointer r0
    //     0xafe3dc: add             x0, x0, HEAP, lsl #32
    // 0xafe3e0: b               #0xafe424
    // 0xafe3e4: r1 = 1
    //     0xafe3e4: mov             x1, #1
    // 0xafe3e8: r0 = AllocateContext()
    //     0xafe3e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xafe3ec: mov             x1, x0
    // 0xafe3f0: ldr             x0, [fp, #0x10]
    // 0xafe3f4: StoreField: r1->field_f = r0
    //     0xafe3f4: stur            w0, [x1, #0xf]
    // 0xafe3f8: mov             x2, x1
    // 0xafe3fc: r1 = Function '<anonymous closure>':.
    //     0xafe3fc: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6d8] AnonymousClosure: (0x84d7a0), of [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3
    //     0xafe400: ldr             x1, [x1, #0x6d8]
    // 0xafe404: r0 = AllocateClosure()
    //     0xafe404: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xafe408: r16 = <BorderSide>
    //     0xafe408: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e6e0] TypeArguments: <BorderSide>
    //     0xafe40c: ldr             x16, [x16, #0x6e0]
    // 0xafe410: stp             x0, x16, [SP, #-0x10]!
    // 0xafe414: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xafe414: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xafe418: r0 = resolveWith()
    //     0xafe418: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xafe41c: add             SP, SP, #0x10
    // 0xafe420: ldr             x2, [fp, #0x10]
    // 0xafe424: ldur            x3, [fp, #-0x10]
    // 0xafe428: mov             x1, x3
    // 0xafe42c: ArrayStore: r1[13] = r0  ; List_4
    //     0xafe42c: add             x25, x1, #0x43
    //     0xafe430: str             w0, [x25]
    //     0xafe434: tbz             w0, #0, #0xafe450
    //     0xafe438: ldurb           w16, [x1, #-1]
    //     0xafe43c: ldurb           w17, [x0, #-1]
    //     0xafe440: and             x16, x17, x16, lsr #2
    //     0xafe444: tst             x16, HEAP, lsr #32
    //     0xafe448: b.eq            #0xafe450
    //     0xafe44c: bl              #0xd67e5c
    // 0xafe450: r0 = LoadClassIdInstr(r2)
    //     0xafe450: ldur            x0, [x2, #-1]
    //     0xafe454: ubfx            x0, x0, #0xc, #0x14
    // 0xafe458: SaveReg r2
    //     0xafe458: str             x2, [SP, #-8]!
    // 0xafe45c: r0 = GDT[cid_x0 + -0xec3]()
    //     0xafe45c: sub             lr, x0, #0xec3
    //     0xafe460: ldr             lr, [x21, lr, lsl #3]
    //     0xafe464: blr             lr
    // 0xafe468: add             SP, SP, #8
    // 0xafe46c: ldur            x1, [fp, #-0x10]
    // 0xafe470: ArrayStore: r1[14] = r0  ; List_4
    //     0xafe470: add             x25, x1, #0x47
    //     0xafe474: str             w0, [x25]
    //     0xafe478: tbz             w0, #0, #0xafe494
    //     0xafe47c: ldurb           w16, [x1, #-1]
    //     0xafe480: ldurb           w17, [x0, #-1]
    //     0xafe484: and             x16, x17, x16, lsr #2
    //     0xafe488: tst             x16, HEAP, lsr #32
    //     0xafe48c: b.eq            #0xafe494
    //     0xafe490: bl              #0xd67e5c
    // 0xafe494: ldr             x1, [fp, #0x10]
    // 0xafe498: r0 = LoadClassIdInstr(r1)
    //     0xafe498: ldur            x0, [x1, #-1]
    //     0xafe49c: ubfx            x0, x0, #0xc, #0x14
    // 0xafe4a0: SaveReg r1
    //     0xafe4a0: str             x1, [SP, #-8]!
    // 0xafe4a4: r0 = GDT[cid_x0 + -0xebb]()
    //     0xafe4a4: sub             lr, x0, #0xebb
    //     0xafe4a8: ldr             lr, [x21, lr, lsl #3]
    //     0xafe4ac: blr             lr
    // 0xafe4b0: add             SP, SP, #8
    // 0xafe4b4: ldur            x1, [fp, #-0x10]
    // 0xafe4b8: ArrayStore: r1[15] = r0  ; List_4
    //     0xafe4b8: add             x25, x1, #0x4b
    //     0xafe4bc: str             w0, [x25]
    //     0xafe4c0: tbz             w0, #0, #0xafe4dc
    //     0xafe4c4: ldurb           w16, [x1, #-1]
    //     0xafe4c8: ldurb           w17, [x0, #-1]
    //     0xafe4cc: and             x16, x17, x16, lsr #2
    //     0xafe4d0: tst             x16, HEAP, lsr #32
    //     0xafe4d4: b.eq            #0xafe4dc
    //     0xafe4d8: bl              #0xd67e5c
    // 0xafe4dc: ldr             x1, [fp, #0x10]
    // 0xafe4e0: r0 = LoadClassIdInstr(r1)
    //     0xafe4e0: ldur            x0, [x1, #-1]
    //     0xafe4e4: ubfx            x0, x0, #0xc, #0x14
    // 0xafe4e8: SaveReg r1
    //     0xafe4e8: str             x1, [SP, #-8]!
    // 0xafe4ec: r0 = GDT[cid_x0 + -0xeb5]()
    //     0xafe4ec: sub             lr, x0, #0xeb5
    //     0xafe4f0: ldr             lr, [x21, lr, lsl #3]
    //     0xafe4f4: blr             lr
    // 0xafe4f8: add             SP, SP, #8
    // 0xafe4fc: ldur            x1, [fp, #-0x10]
    // 0xafe500: ArrayStore: r1[16] = r0  ; List_4
    //     0xafe500: add             x25, x1, #0x4f
    //     0xafe504: str             w0, [x25]
    //     0xafe508: tbz             w0, #0, #0xafe524
    //     0xafe50c: ldurb           w16, [x1, #-1]
    //     0xafe510: ldurb           w17, [x0, #-1]
    //     0xafe514: and             x16, x17, x16, lsr #2
    //     0xafe518: tst             x16, HEAP, lsr #32
    //     0xafe51c: b.eq            #0xafe524
    //     0xafe520: bl              #0xd67e5c
    // 0xafe524: ldr             x1, [fp, #0x10]
    // 0xafe528: r0 = LoadClassIdInstr(r1)
    //     0xafe528: ldur            x0, [x1, #-1]
    //     0xafe52c: ubfx            x0, x0, #0xc, #0x14
    // 0xafe530: SaveReg r1
    //     0xafe530: str             x1, [SP, #-8]!
    // 0xafe534: r0 = GDT[cid_x0 + -0xeb0]()
    //     0xafe534: sub             lr, x0, #0xeb0
    //     0xafe538: ldr             lr, [x21, lr, lsl #3]
    //     0xafe53c: blr             lr
    // 0xafe540: add             SP, SP, #8
    // 0xafe544: ldur            x1, [fp, #-0x10]
    // 0xafe548: ArrayStore: r1[17] = r0  ; List_4
    //     0xafe548: add             x25, x1, #0x53
    //     0xafe54c: str             w0, [x25]
    //     0xafe550: tbz             w0, #0, #0xafe56c
    //     0xafe554: ldurb           w16, [x1, #-1]
    //     0xafe558: ldurb           w17, [x0, #-1]
    //     0xafe55c: and             x16, x17, x16, lsr #2
    //     0xafe560: tst             x16, HEAP, lsr #32
    //     0xafe564: b.eq            #0xafe56c
    //     0xafe568: bl              #0xd67e5c
    // 0xafe56c: ldr             x2, [fp, #0x10]
    // 0xafe570: LoadField: r0 = r2->field_4f
    //     0xafe570: ldur            w0, [x2, #0x4f]
    // 0xafe574: DecompressPointer r0
    //     0xafe574: add             x0, x0, HEAP, lsl #32
    // 0xafe578: ldur            x1, [fp, #-0x10]
    // 0xafe57c: ArrayStore: r1[18] = r0  ; List_4
    //     0xafe57c: add             x25, x1, #0x57
    //     0xafe580: str             w0, [x25]
    //     0xafe584: tbz             w0, #0, #0xafe5a0
    //     0xafe588: ldurb           w16, [x1, #-1]
    //     0xafe58c: ldurb           w17, [x0, #-1]
    //     0xafe590: and             x16, x17, x16, lsr #2
    //     0xafe594: tst             x16, HEAP, lsr #32
    //     0xafe598: b.eq            #0xafe5a0
    //     0xafe59c: bl              #0xd67e5c
    // 0xafe5a0: LoadField: r0 = r2->field_53
    //     0xafe5a0: ldur            w0, [x2, #0x53]
    // 0xafe5a4: DecompressPointer r0
    //     0xafe5a4: add             x0, x0, HEAP, lsl #32
    // 0xafe5a8: ldur            x3, [fp, #-0x10]
    // 0xafe5ac: StoreField: r3->field_5b = r0
    //     0xafe5ac: stur            w0, [x3, #0x5b]
    // 0xafe5b0: LoadField: r0 = r2->field_57
    //     0xafe5b0: ldur            w0, [x2, #0x57]
    // 0xafe5b4: DecompressPointer r0
    //     0xafe5b4: add             x0, x0, HEAP, lsl #32
    // 0xafe5b8: mov             x1, x3
    // 0xafe5bc: ArrayStore: r1[20] = r0  ; List_4
    //     0xafe5bc: add             x25, x1, #0x5f
    //     0xafe5c0: str             w0, [x25]
    //     0xafe5c4: tbz             w0, #0, #0xafe5e0
    //     0xafe5c8: ldurb           w16, [x1, #-1]
    //     0xafe5cc: ldurb           w17, [x0, #-1]
    //     0xafe5d0: and             x16, x17, x16, lsr #2
    //     0xafe5d4: tst             x16, HEAP, lsr #32
    //     0xafe5d8: b.eq            #0xafe5e0
    //     0xafe5dc: bl              #0xd67e5c
    // 0xafe5e0: r0 = LoadClassIdInstr(r2)
    //     0xafe5e0: ldur            x0, [x2, #-1]
    //     0xafe5e4: ubfx            x0, x0, #0xc, #0x14
    // 0xafe5e8: SaveReg r2
    //     0xafe5e8: str             x2, [SP, #-8]!
    // 0xafe5ec: r0 = GDT[cid_x0 + -0xe82]()
    //     0xafe5ec: sub             lr, x0, #0xe82
    //     0xafe5f0: ldr             lr, [x21, lr, lsl #3]
    //     0xafe5f4: blr             lr
    // 0xafe5f8: add             SP, SP, #8
    // 0xafe5fc: ldur            x1, [fp, #-0x10]
    // 0xafe600: ArrayStore: r1[21] = r0  ; List_4
    //     0xafe600: add             x25, x1, #0x63
    //     0xafe604: str             w0, [x25]
    //     0xafe608: tbz             w0, #0, #0xafe624
    //     0xafe60c: ldurb           w16, [x1, #-1]
    //     0xafe610: ldurb           w17, [x0, #-1]
    //     0xafe614: and             x16, x17, x16, lsr #2
    //     0xafe618: tst             x16, HEAP, lsr #32
    //     0xafe61c: b.eq            #0xafe624
    //     0xafe620: bl              #0xd67e5c
    // 0xafe624: r1 = <Object?>
    //     0xafe624: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xafe628: r0 = AllocateGrowableArray()
    //     0xafe628: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xafe62c: mov             x1, x0
    // 0xafe630: ldur            x0, [fp, #-0x10]
    // 0xafe634: StoreField: r1->field_f = r0
    //     0xafe634: stur            w0, [x1, #0xf]
    // 0xafe638: r0 = 44
    //     0xafe638: mov             x0, #0x2c
    // 0xafe63c: StoreField: r1->field_b = r0
    //     0xafe63c: stur            w0, [x1, #0xb]
    // 0xafe640: SaveReg r1
    //     0xafe640: str             x1, [SP, #-8]!
    // 0xafe644: r0 = hashAll()
    //     0xafe644: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xafe648: add             SP, SP, #8
    // 0xafe64c: mov             x2, x0
    // 0xafe650: r0 = BoxInt64Instr(r2)
    //     0xafe650: sbfiz           x0, x2, #1, #0x1f
    //     0xafe654: cmp             x2, x0, asr #1
    //     0xafe658: b.eq            #0xafe664
    //     0xafe65c: bl              #0xd69bb8
    //     0xafe660: stur            x2, [x0, #7]
    // 0xafe664: LeaveFrame
    //     0xafe664: mov             SP, fp
    //     0xafe668: ldp             fp, lr, [SP], #0x10
    // 0xafe66c: ret
    //     0xafe66c: ret             
    // 0xafe670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafe670: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafe674: b               #0xafe010
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbef34c, size: 0x9f8
    // 0xbef34c: EnterFrame
    //     0xbef34c: stp             fp, lr, [SP, #-0x10]!
    //     0xbef350: mov             fp, SP
    // 0xbef354: AllocStack(0xb0)
    //     0xbef354: sub             SP, SP, #0xb0
    // 0xbef358: CheckStackOverflow
    //     0xbef358: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbef35c: cmp             SP, x16
    //     0xbef360: b.ls            #0xbefd3c
    // 0xbef364: ldr             x0, [fp, #0x20]
    // 0xbef368: cmp             w0, NULL
    // 0xbef36c: b.ne            #0xbef38c
    // 0xbef370: ldr             x1, [fp, #0x18]
    // 0xbef374: cmp             w1, NULL
    // 0xbef378: b.ne            #0xbef390
    // 0xbef37c: r0 = Null
    //     0xbef37c: mov             x0, NULL
    // 0xbef380: LeaveFrame
    //     0xbef380: mov             SP, fp
    //     0xbef384: ldp             fp, lr, [SP], #0x10
    // 0xbef388: ret
    //     0xbef388: ret             
    // 0xbef38c: ldr             x1, [fp, #0x18]
    // 0xbef390: cmp             w0, NULL
    // 0xbef394: b.ne            #0xbef3a0
    // 0xbef398: r2 = Null
    //     0xbef398: mov             x2, NULL
    // 0xbef39c: b               #0xbef3a8
    // 0xbef3a0: LoadField: r2 = r0->field_7
    //     0xbef3a0: ldur            w2, [x0, #7]
    // 0xbef3a4: DecompressPointer r2
    //     0xbef3a4: add             x2, x2, HEAP, lsl #32
    // 0xbef3a8: cmp             w1, NULL
    // 0xbef3ac: b.ne            #0xbef3b8
    // 0xbef3b0: r3 = Null
    //     0xbef3b0: mov             x3, NULL
    // 0xbef3b4: b               #0xbef3c0
    // 0xbef3b8: LoadField: r3 = r1->field_7
    //     0xbef3b8: ldur            w3, [x1, #7]
    // 0xbef3bc: DecompressPointer r3
    //     0xbef3bc: add             x3, x3, HEAP, lsl #32
    // 0xbef3c0: ldr             d0, [fp, #0x10]
    // 0xbef3c4: r16 = <TextStyle?>
    //     0xbef3c4: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c0] TypeArguments: <TextStyle?>
    //     0xbef3c8: ldr             x16, [x16, #0x8c0]
    // 0xbef3cc: stp             x2, x16, [SP, #-0x10]!
    // 0xbef3d0: SaveReg r3
    //     0xbef3d0: str             x3, [SP, #-8]!
    // 0xbef3d4: SaveReg d0
    //     0xbef3d4: str             d0, [SP, #-8]!
    // 0xbef3d8: r16 = Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static.
    //     0xbef3d8: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db78] Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static. (0x7fe6e22ec598)
    //     0xbef3dc: ldr             x16, [x16, #0xb78]
    // 0xbef3e0: SaveReg r16
    //     0xbef3e0: str             x16, [SP, #-8]!
    // 0xbef3e4: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef3e4: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef3e8: r0 = lerp()
    //     0xbef3e8: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef3ec: add             SP, SP, #0x28
    // 0xbef3f0: mov             x1, x0
    // 0xbef3f4: ldr             x0, [fp, #0x20]
    // 0xbef3f8: stur            x1, [fp, #-8]
    // 0xbef3fc: cmp             w0, NULL
    // 0xbef400: b.ne            #0xbef40c
    // 0xbef404: r3 = Null
    //     0xbef404: mov             x3, NULL
    // 0xbef408: b               #0xbef418
    // 0xbef40c: LoadField: r2 = r0->field_b
    //     0xbef40c: ldur            w2, [x0, #0xb]
    // 0xbef410: DecompressPointer r2
    //     0xbef410: add             x2, x2, HEAP, lsl #32
    // 0xbef414: mov             x3, x2
    // 0xbef418: ldr             x2, [fp, #0x18]
    // 0xbef41c: cmp             w2, NULL
    // 0xbef420: b.ne            #0xbef42c
    // 0xbef424: r4 = Null
    //     0xbef424: mov             x4, NULL
    // 0xbef428: b               #0xbef434
    // 0xbef42c: LoadField: r4 = r2->field_b
    //     0xbef42c: ldur            w4, [x2, #0xb]
    // 0xbef430: DecompressPointer r4
    //     0xbef430: add             x4, x4, HEAP, lsl #32
    // 0xbef434: ldr             d0, [fp, #0x10]
    // 0xbef438: r16 = <Color?>
    //     0xbef438: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbef43c: ldr             x16, [x16, #0xf68]
    // 0xbef440: stp             x3, x16, [SP, #-0x10]!
    // 0xbef444: SaveReg r4
    //     0xbef444: str             x4, [SP, #-8]!
    // 0xbef448: SaveReg d0
    //     0xbef448: str             d0, [SP, #-8]!
    // 0xbef44c: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbef44c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbef450: ldr             x16, [x16, #0xb80]
    // 0xbef454: SaveReg r16
    //     0xbef454: str             x16, [SP, #-8]!
    // 0xbef458: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef458: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef45c: r0 = lerp()
    //     0xbef45c: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef460: add             SP, SP, #0x28
    // 0xbef464: mov             x1, x0
    // 0xbef468: ldr             x0, [fp, #0x20]
    // 0xbef46c: stur            x1, [fp, #-0x10]
    // 0xbef470: cmp             w0, NULL
    // 0xbef474: b.ne            #0xbef480
    // 0xbef478: r3 = Null
    //     0xbef478: mov             x3, NULL
    // 0xbef47c: b               #0xbef48c
    // 0xbef480: LoadField: r2 = r0->field_f
    //     0xbef480: ldur            w2, [x0, #0xf]
    // 0xbef484: DecompressPointer r2
    //     0xbef484: add             x2, x2, HEAP, lsl #32
    // 0xbef488: mov             x3, x2
    // 0xbef48c: ldr             x2, [fp, #0x18]
    // 0xbef490: cmp             w2, NULL
    // 0xbef494: b.ne            #0xbef4a0
    // 0xbef498: r4 = Null
    //     0xbef498: mov             x4, NULL
    // 0xbef49c: b               #0xbef4a8
    // 0xbef4a0: LoadField: r4 = r2->field_f
    //     0xbef4a0: ldur            w4, [x2, #0xf]
    // 0xbef4a4: DecompressPointer r4
    //     0xbef4a4: add             x4, x4, HEAP, lsl #32
    // 0xbef4a8: ldr             d0, [fp, #0x10]
    // 0xbef4ac: r16 = <Color?>
    //     0xbef4ac: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbef4b0: ldr             x16, [x16, #0xf68]
    // 0xbef4b4: stp             x3, x16, [SP, #-0x10]!
    // 0xbef4b8: SaveReg r4
    //     0xbef4b8: str             x4, [SP, #-8]!
    // 0xbef4bc: SaveReg d0
    //     0xbef4bc: str             d0, [SP, #-8]!
    // 0xbef4c0: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbef4c0: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbef4c4: ldr             x16, [x16, #0xb80]
    // 0xbef4c8: SaveReg r16
    //     0xbef4c8: str             x16, [SP, #-8]!
    // 0xbef4cc: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef4cc: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef4d0: r0 = lerp()
    //     0xbef4d0: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef4d4: add             SP, SP, #0x28
    // 0xbef4d8: mov             x1, x0
    // 0xbef4dc: ldr             x0, [fp, #0x20]
    // 0xbef4e0: stur            x1, [fp, #-0x18]
    // 0xbef4e4: cmp             w0, NULL
    // 0xbef4e8: b.ne            #0xbef4f4
    // 0xbef4ec: r3 = Null
    //     0xbef4ec: mov             x3, NULL
    // 0xbef4f0: b               #0xbef500
    // 0xbef4f4: LoadField: r2 = r0->field_13
    //     0xbef4f4: ldur            w2, [x0, #0x13]
    // 0xbef4f8: DecompressPointer r2
    //     0xbef4f8: add             x2, x2, HEAP, lsl #32
    // 0xbef4fc: mov             x3, x2
    // 0xbef500: ldr             x2, [fp, #0x18]
    // 0xbef504: cmp             w2, NULL
    // 0xbef508: b.ne            #0xbef514
    // 0xbef50c: r4 = Null
    //     0xbef50c: mov             x4, NULL
    // 0xbef510: b               #0xbef51c
    // 0xbef514: LoadField: r4 = r2->field_13
    //     0xbef514: ldur            w4, [x2, #0x13]
    // 0xbef518: DecompressPointer r4
    //     0xbef518: add             x4, x4, HEAP, lsl #32
    // 0xbef51c: ldr             d0, [fp, #0x10]
    // 0xbef520: r16 = <Color?>
    //     0xbef520: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbef524: ldr             x16, [x16, #0xf68]
    // 0xbef528: stp             x3, x16, [SP, #-0x10]!
    // 0xbef52c: SaveReg r4
    //     0xbef52c: str             x4, [SP, #-8]!
    // 0xbef530: SaveReg d0
    //     0xbef530: str             d0, [SP, #-8]!
    // 0xbef534: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbef534: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbef538: ldr             x16, [x16, #0xb80]
    // 0xbef53c: SaveReg r16
    //     0xbef53c: str             x16, [SP, #-8]!
    // 0xbef540: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef540: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef544: r0 = lerp()
    //     0xbef544: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef548: add             SP, SP, #0x28
    // 0xbef54c: mov             x1, x0
    // 0xbef550: ldr             x0, [fp, #0x20]
    // 0xbef554: stur            x1, [fp, #-0x20]
    // 0xbef558: cmp             w0, NULL
    // 0xbef55c: b.ne            #0xbef568
    // 0xbef560: r3 = Null
    //     0xbef560: mov             x3, NULL
    // 0xbef564: b               #0xbef574
    // 0xbef568: LoadField: r2 = r0->field_17
    //     0xbef568: ldur            w2, [x0, #0x17]
    // 0xbef56c: DecompressPointer r2
    //     0xbef56c: add             x2, x2, HEAP, lsl #32
    // 0xbef570: mov             x3, x2
    // 0xbef574: ldr             x2, [fp, #0x18]
    // 0xbef578: cmp             w2, NULL
    // 0xbef57c: b.ne            #0xbef588
    // 0xbef580: r4 = Null
    //     0xbef580: mov             x4, NULL
    // 0xbef584: b               #0xbef590
    // 0xbef588: LoadField: r4 = r2->field_17
    //     0xbef588: ldur            w4, [x2, #0x17]
    // 0xbef58c: DecompressPointer r4
    //     0xbef58c: add             x4, x4, HEAP, lsl #32
    // 0xbef590: ldr             d0, [fp, #0x10]
    // 0xbef594: r16 = <Color?>
    //     0xbef594: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbef598: ldr             x16, [x16, #0xf68]
    // 0xbef59c: stp             x3, x16, [SP, #-0x10]!
    // 0xbef5a0: SaveReg r4
    //     0xbef5a0: str             x4, [SP, #-8]!
    // 0xbef5a4: SaveReg d0
    //     0xbef5a4: str             d0, [SP, #-8]!
    // 0xbef5a8: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbef5a8: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbef5ac: ldr             x16, [x16, #0xb80]
    // 0xbef5b0: SaveReg r16
    //     0xbef5b0: str             x16, [SP, #-8]!
    // 0xbef5b4: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef5b4: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef5b8: r0 = lerp()
    //     0xbef5b8: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef5bc: add             SP, SP, #0x28
    // 0xbef5c0: mov             x1, x0
    // 0xbef5c4: ldr             x0, [fp, #0x20]
    // 0xbef5c8: stur            x1, [fp, #-0x28]
    // 0xbef5cc: cmp             w0, NULL
    // 0xbef5d0: b.ne            #0xbef5dc
    // 0xbef5d4: r3 = Null
    //     0xbef5d4: mov             x3, NULL
    // 0xbef5d8: b               #0xbef5e8
    // 0xbef5dc: LoadField: r2 = r0->field_1b
    //     0xbef5dc: ldur            w2, [x0, #0x1b]
    // 0xbef5e0: DecompressPointer r2
    //     0xbef5e0: add             x2, x2, HEAP, lsl #32
    // 0xbef5e4: mov             x3, x2
    // 0xbef5e8: ldr             x2, [fp, #0x18]
    // 0xbef5ec: cmp             w2, NULL
    // 0xbef5f0: b.ne            #0xbef5fc
    // 0xbef5f4: r4 = Null
    //     0xbef5f4: mov             x4, NULL
    // 0xbef5f8: b               #0xbef604
    // 0xbef5fc: LoadField: r4 = r2->field_1b
    //     0xbef5fc: ldur            w4, [x2, #0x1b]
    // 0xbef600: DecompressPointer r4
    //     0xbef600: add             x4, x4, HEAP, lsl #32
    // 0xbef604: ldr             d0, [fp, #0x10]
    // 0xbef608: r16 = <Color?>
    //     0xbef608: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbef60c: ldr             x16, [x16, #0xf68]
    // 0xbef610: stp             x3, x16, [SP, #-0x10]!
    // 0xbef614: SaveReg r4
    //     0xbef614: str             x4, [SP, #-8]!
    // 0xbef618: SaveReg d0
    //     0xbef618: str             d0, [SP, #-8]!
    // 0xbef61c: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbef61c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbef620: ldr             x16, [x16, #0xb80]
    // 0xbef624: SaveReg r16
    //     0xbef624: str             x16, [SP, #-8]!
    // 0xbef628: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef628: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef62c: r0 = lerp()
    //     0xbef62c: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef630: add             SP, SP, #0x28
    // 0xbef634: mov             x1, x0
    // 0xbef638: ldr             x0, [fp, #0x20]
    // 0xbef63c: stur            x1, [fp, #-0x30]
    // 0xbef640: cmp             w0, NULL
    // 0xbef644: b.ne            #0xbef650
    // 0xbef648: r3 = Null
    //     0xbef648: mov             x3, NULL
    // 0xbef64c: b               #0xbef65c
    // 0xbef650: LoadField: r2 = r0->field_1f
    //     0xbef650: ldur            w2, [x0, #0x1f]
    // 0xbef654: DecompressPointer r2
    //     0xbef654: add             x2, x2, HEAP, lsl #32
    // 0xbef658: mov             x3, x2
    // 0xbef65c: ldr             x2, [fp, #0x18]
    // 0xbef660: cmp             w2, NULL
    // 0xbef664: b.ne            #0xbef670
    // 0xbef668: r4 = Null
    //     0xbef668: mov             x4, NULL
    // 0xbef66c: b               #0xbef678
    // 0xbef670: LoadField: r4 = r2->field_1f
    //     0xbef670: ldur            w4, [x2, #0x1f]
    // 0xbef674: DecompressPointer r4
    //     0xbef674: add             x4, x4, HEAP, lsl #32
    // 0xbef678: ldr             d0, [fp, #0x10]
    // 0xbef67c: r16 = <double?>
    //     0xbef67c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db88] TypeArguments: <double?>
    //     0xbef680: ldr             x16, [x16, #0xb88]
    // 0xbef684: stp             x3, x16, [SP, #-0x10]!
    // 0xbef688: SaveReg r4
    //     0xbef688: str             x4, [SP, #-8]!
    // 0xbef68c: SaveReg d0
    //     0xbef68c: str             d0, [SP, #-8]!
    // 0xbef690: r16 = Closure: (num?, num?, double) => double? from Function 'lerpDouble': static.
    //     0xbef690: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db90] Closure: (num?, num?, double) => double? from Function 'lerpDouble': static. (0x7fe6e1db558c)
    //     0xbef694: ldr             x16, [x16, #0xb90]
    // 0xbef698: SaveReg r16
    //     0xbef698: str             x16, [SP, #-8]!
    // 0xbef69c: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef69c: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef6a0: r0 = lerp()
    //     0xbef6a0: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef6a4: add             SP, SP, #0x28
    // 0xbef6a8: mov             x1, x0
    // 0xbef6ac: ldr             x0, [fp, #0x20]
    // 0xbef6b0: stur            x1, [fp, #-0x38]
    // 0xbef6b4: cmp             w0, NULL
    // 0xbef6b8: b.ne            #0xbef6c4
    // 0xbef6bc: r3 = Null
    //     0xbef6bc: mov             x3, NULL
    // 0xbef6c0: b               #0xbef6d0
    // 0xbef6c4: LoadField: r2 = r0->field_23
    //     0xbef6c4: ldur            w2, [x0, #0x23]
    // 0xbef6c8: DecompressPointer r2
    //     0xbef6c8: add             x2, x2, HEAP, lsl #32
    // 0xbef6cc: mov             x3, x2
    // 0xbef6d0: ldr             x2, [fp, #0x18]
    // 0xbef6d4: cmp             w2, NULL
    // 0xbef6d8: b.ne            #0xbef6e4
    // 0xbef6dc: r4 = Null
    //     0xbef6dc: mov             x4, NULL
    // 0xbef6e0: b               #0xbef6ec
    // 0xbef6e4: LoadField: r4 = r2->field_23
    //     0xbef6e4: ldur            w4, [x2, #0x23]
    // 0xbef6e8: DecompressPointer r4
    //     0xbef6e8: add             x4, x4, HEAP, lsl #32
    // 0xbef6ec: ldr             d0, [fp, #0x10]
    // 0xbef6f0: r16 = <EdgeInsetsGeometry?>
    //     0xbef6f0: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db98] TypeArguments: <EdgeInsetsGeometry?>
    //     0xbef6f4: ldr             x16, [x16, #0xb98]
    // 0xbef6f8: stp             x3, x16, [SP, #-0x10]!
    // 0xbef6fc: SaveReg r4
    //     0xbef6fc: str             x4, [SP, #-8]!
    // 0xbef700: SaveReg d0
    //     0xbef700: str             d0, [SP, #-8]!
    // 0xbef704: r16 = Closure: (EdgeInsetsGeometry?, EdgeInsetsGeometry?, double) => EdgeInsetsGeometry? from Function 'lerp': static.
    //     0xbef704: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba0] Closure: (EdgeInsetsGeometry?, EdgeInsetsGeometry?, double) => EdgeInsetsGeometry? from Function 'lerp': static. (0x7fe6e23f0ed4)
    //     0xbef708: ldr             x16, [x16, #0xba0]
    // 0xbef70c: SaveReg r16
    //     0xbef70c: str             x16, [SP, #-8]!
    // 0xbef710: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef710: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef714: r0 = lerp()
    //     0xbef714: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef718: add             SP, SP, #0x28
    // 0xbef71c: mov             x1, x0
    // 0xbef720: ldr             x0, [fp, #0x20]
    // 0xbef724: stur            x1, [fp, #-0x40]
    // 0xbef728: cmp             w0, NULL
    // 0xbef72c: b.ne            #0xbef738
    // 0xbef730: r3 = Null
    //     0xbef730: mov             x3, NULL
    // 0xbef734: b               #0xbef744
    // 0xbef738: LoadField: r2 = r0->field_27
    //     0xbef738: ldur            w2, [x0, #0x27]
    // 0xbef73c: DecompressPointer r2
    //     0xbef73c: add             x2, x2, HEAP, lsl #32
    // 0xbef740: mov             x3, x2
    // 0xbef744: ldr             x2, [fp, #0x18]
    // 0xbef748: cmp             w2, NULL
    // 0xbef74c: b.ne            #0xbef758
    // 0xbef750: r4 = Null
    //     0xbef750: mov             x4, NULL
    // 0xbef754: b               #0xbef760
    // 0xbef758: LoadField: r4 = r2->field_27
    //     0xbef758: ldur            w4, [x2, #0x27]
    // 0xbef75c: DecompressPointer r4
    //     0xbef75c: add             x4, x4, HEAP, lsl #32
    // 0xbef760: ldr             d0, [fp, #0x10]
    // 0xbef764: r16 = <Size?>
    //     0xbef764: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0xbef768: ldr             x16, [x16, #0xba8]
    // 0xbef76c: stp             x3, x16, [SP, #-0x10]!
    // 0xbef770: SaveReg r4
    //     0xbef770: str             x4, [SP, #-8]!
    // 0xbef774: SaveReg d0
    //     0xbef774: str             d0, [SP, #-8]!
    // 0xbef778: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0xbef778: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb0] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7fe6e23ec4d0)
    //     0xbef77c: ldr             x16, [x16, #0xbb0]
    // 0xbef780: SaveReg r16
    //     0xbef780: str             x16, [SP, #-8]!
    // 0xbef784: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef784: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef788: r0 = lerp()
    //     0xbef788: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef78c: add             SP, SP, #0x28
    // 0xbef790: mov             x1, x0
    // 0xbef794: ldr             x0, [fp, #0x20]
    // 0xbef798: stur            x1, [fp, #-0x48]
    // 0xbef79c: cmp             w0, NULL
    // 0xbef7a0: b.ne            #0xbef7ac
    // 0xbef7a4: r3 = Null
    //     0xbef7a4: mov             x3, NULL
    // 0xbef7a8: b               #0xbef7b8
    // 0xbef7ac: LoadField: r2 = r0->field_2b
    //     0xbef7ac: ldur            w2, [x0, #0x2b]
    // 0xbef7b0: DecompressPointer r2
    //     0xbef7b0: add             x2, x2, HEAP, lsl #32
    // 0xbef7b4: mov             x3, x2
    // 0xbef7b8: ldr             x2, [fp, #0x18]
    // 0xbef7bc: cmp             w2, NULL
    // 0xbef7c0: b.ne            #0xbef7cc
    // 0xbef7c4: r4 = Null
    //     0xbef7c4: mov             x4, NULL
    // 0xbef7c8: b               #0xbef7d4
    // 0xbef7cc: LoadField: r4 = r2->field_2b
    //     0xbef7cc: ldur            w4, [x2, #0x2b]
    // 0xbef7d0: DecompressPointer r4
    //     0xbef7d0: add             x4, x4, HEAP, lsl #32
    // 0xbef7d4: ldr             d0, [fp, #0x10]
    // 0xbef7d8: r16 = <Size?>
    //     0xbef7d8: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0xbef7dc: ldr             x16, [x16, #0xba8]
    // 0xbef7e0: stp             x3, x16, [SP, #-0x10]!
    // 0xbef7e4: SaveReg r4
    //     0xbef7e4: str             x4, [SP, #-8]!
    // 0xbef7e8: SaveReg d0
    //     0xbef7e8: str             d0, [SP, #-8]!
    // 0xbef7ec: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0xbef7ec: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb0] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7fe6e23ec4d0)
    //     0xbef7f0: ldr             x16, [x16, #0xbb0]
    // 0xbef7f4: SaveReg r16
    //     0xbef7f4: str             x16, [SP, #-8]!
    // 0xbef7f8: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef7f8: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef7fc: r0 = lerp()
    //     0xbef7fc: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef800: add             SP, SP, #0x28
    // 0xbef804: mov             x1, x0
    // 0xbef808: ldr             x0, [fp, #0x20]
    // 0xbef80c: stur            x1, [fp, #-0x50]
    // 0xbef810: cmp             w0, NULL
    // 0xbef814: b.ne            #0xbef820
    // 0xbef818: r3 = Null
    //     0xbef818: mov             x3, NULL
    // 0xbef81c: b               #0xbef82c
    // 0xbef820: LoadField: r2 = r0->field_2f
    //     0xbef820: ldur            w2, [x0, #0x2f]
    // 0xbef824: DecompressPointer r2
    //     0xbef824: add             x2, x2, HEAP, lsl #32
    // 0xbef828: mov             x3, x2
    // 0xbef82c: ldr             x2, [fp, #0x18]
    // 0xbef830: cmp             w2, NULL
    // 0xbef834: b.ne            #0xbef840
    // 0xbef838: r4 = Null
    //     0xbef838: mov             x4, NULL
    // 0xbef83c: b               #0xbef848
    // 0xbef840: LoadField: r4 = r2->field_2f
    //     0xbef840: ldur            w4, [x2, #0x2f]
    // 0xbef844: DecompressPointer r4
    //     0xbef844: add             x4, x4, HEAP, lsl #32
    // 0xbef848: ldr             d0, [fp, #0x10]
    // 0xbef84c: r16 = <Size?>
    //     0xbef84c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0xbef850: ldr             x16, [x16, #0xba8]
    // 0xbef854: stp             x3, x16, [SP, #-0x10]!
    // 0xbef858: SaveReg r4
    //     0xbef858: str             x4, [SP, #-8]!
    // 0xbef85c: SaveReg d0
    //     0xbef85c: str             d0, [SP, #-8]!
    // 0xbef860: r16 = Closure: (Size?, Size?, double) => Size? from Function 'lerp': static.
    //     0xbef860: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb0] Closure: (Size?, Size?, double) => Size? from Function 'lerp': static. (0x7fe6e23ec4d0)
    //     0xbef864: ldr             x16, [x16, #0xbb0]
    // 0xbef868: SaveReg r16
    //     0xbef868: str             x16, [SP, #-8]!
    // 0xbef86c: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef86c: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef870: r0 = lerp()
    //     0xbef870: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef874: add             SP, SP, #0x28
    // 0xbef878: mov             x1, x0
    // 0xbef87c: ldr             x0, [fp, #0x20]
    // 0xbef880: stur            x1, [fp, #-0x58]
    // 0xbef884: cmp             w0, NULL
    // 0xbef888: b.ne            #0xbef894
    // 0xbef88c: r3 = Null
    //     0xbef88c: mov             x3, NULL
    // 0xbef890: b               #0xbef8a0
    // 0xbef894: LoadField: r2 = r0->field_33
    //     0xbef894: ldur            w2, [x0, #0x33]
    // 0xbef898: DecompressPointer r2
    //     0xbef898: add             x2, x2, HEAP, lsl #32
    // 0xbef89c: mov             x3, x2
    // 0xbef8a0: ldr             x2, [fp, #0x18]
    // 0xbef8a4: cmp             w2, NULL
    // 0xbef8a8: b.ne            #0xbef8b4
    // 0xbef8ac: r4 = Null
    //     0xbef8ac: mov             x4, NULL
    // 0xbef8b0: b               #0xbef8bc
    // 0xbef8b4: LoadField: r4 = r2->field_33
    //     0xbef8b4: ldur            w4, [x2, #0x33]
    // 0xbef8b8: DecompressPointer r4
    //     0xbef8b8: add             x4, x4, HEAP, lsl #32
    // 0xbef8bc: ldr             d0, [fp, #0x10]
    // 0xbef8c0: r16 = <Color?>
    //     0xbef8c0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbef8c4: ldr             x16, [x16, #0xf68]
    // 0xbef8c8: stp             x3, x16, [SP, #-0x10]!
    // 0xbef8cc: SaveReg r4
    //     0xbef8cc: str             x4, [SP, #-8]!
    // 0xbef8d0: SaveReg d0
    //     0xbef8d0: str             d0, [SP, #-8]!
    // 0xbef8d4: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbef8d4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbef8d8: ldr             x16, [x16, #0xb80]
    // 0xbef8dc: SaveReg r16
    //     0xbef8dc: str             x16, [SP, #-8]!
    // 0xbef8e0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef8e0: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef8e4: r0 = lerp()
    //     0xbef8e4: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef8e8: add             SP, SP, #0x28
    // 0xbef8ec: mov             x1, x0
    // 0xbef8f0: ldr             x0, [fp, #0x20]
    // 0xbef8f4: stur            x1, [fp, #-0x60]
    // 0xbef8f8: cmp             w0, NULL
    // 0xbef8fc: b.ne            #0xbef908
    // 0xbef900: r3 = Null
    //     0xbef900: mov             x3, NULL
    // 0xbef904: b               #0xbef914
    // 0xbef908: LoadField: r2 = r0->field_37
    //     0xbef908: ldur            w2, [x0, #0x37]
    // 0xbef90c: DecompressPointer r2
    //     0xbef90c: add             x2, x2, HEAP, lsl #32
    // 0xbef910: mov             x3, x2
    // 0xbef914: ldr             x2, [fp, #0x18]
    // 0xbef918: cmp             w2, NULL
    // 0xbef91c: b.ne            #0xbef928
    // 0xbef920: r4 = Null
    //     0xbef920: mov             x4, NULL
    // 0xbef924: b               #0xbef930
    // 0xbef928: LoadField: r4 = r2->field_37
    //     0xbef928: ldur            w4, [x2, #0x37]
    // 0xbef92c: DecompressPointer r4
    //     0xbef92c: add             x4, x4, HEAP, lsl #32
    // 0xbef930: ldr             d0, [fp, #0x10]
    // 0xbef934: r16 = <double?>
    //     0xbef934: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db88] TypeArguments: <double?>
    //     0xbef938: ldr             x16, [x16, #0xb88]
    // 0xbef93c: stp             x3, x16, [SP, #-0x10]!
    // 0xbef940: SaveReg r4
    //     0xbef940: str             x4, [SP, #-8]!
    // 0xbef944: SaveReg d0
    //     0xbef944: str             d0, [SP, #-8]!
    // 0xbef948: r16 = Closure: (num?, num?, double) => double? from Function 'lerpDouble': static.
    //     0xbef948: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db90] Closure: (num?, num?, double) => double? from Function 'lerpDouble': static. (0x7fe6e1db558c)
    //     0xbef94c: ldr             x16, [x16, #0xb90]
    // 0xbef950: SaveReg r16
    //     0xbef950: str             x16, [SP, #-8]!
    // 0xbef954: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbef954: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbef958: r0 = lerp()
    //     0xbef958: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbef95c: add             SP, SP, #0x28
    // 0xbef960: mov             x1, x0
    // 0xbef964: ldr             x0, [fp, #0x20]
    // 0xbef968: stur            x1, [fp, #-0x68]
    // 0xbef96c: cmp             w0, NULL
    // 0xbef970: b.ne            #0xbef97c
    // 0xbef974: r3 = Null
    //     0xbef974: mov             x3, NULL
    // 0xbef978: b               #0xbef988
    // 0xbef97c: LoadField: r2 = r0->field_3b
    //     0xbef97c: ldur            w2, [x0, #0x3b]
    // 0xbef980: DecompressPointer r2
    //     0xbef980: add             x2, x2, HEAP, lsl #32
    // 0xbef984: mov             x3, x2
    // 0xbef988: ldr             x2, [fp, #0x18]
    // 0xbef98c: cmp             w2, NULL
    // 0xbef990: b.ne            #0xbef99c
    // 0xbef994: r4 = Null
    //     0xbef994: mov             x4, NULL
    // 0xbef998: b               #0xbef9a4
    // 0xbef99c: LoadField: r4 = r2->field_3b
    //     0xbef99c: ldur            w4, [x2, #0x3b]
    // 0xbef9a0: DecompressPointer r4
    //     0xbef9a0: add             x4, x4, HEAP, lsl #32
    // 0xbef9a4: ldr             d0, [fp, #0x10]
    // 0xbef9a8: stp             x4, x3, [SP, #-0x10]!
    // 0xbef9ac: SaveReg d0
    //     0xbef9ac: str             d0, [SP, #-8]!
    // 0xbef9b0: r0 = _lerpSides()
    //     0xbef9b0: bl              #0xbf0c8c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::_lerpSides
    // 0xbef9b4: add             SP, SP, #0x18
    // 0xbef9b8: mov             x1, x0
    // 0xbef9bc: ldr             x0, [fp, #0x20]
    // 0xbef9c0: stur            x1, [fp, #-0x70]
    // 0xbef9c4: cmp             w0, NULL
    // 0xbef9c8: b.ne            #0xbef9d4
    // 0xbef9cc: r3 = Null
    //     0xbef9cc: mov             x3, NULL
    // 0xbef9d0: b               #0xbef9e0
    // 0xbef9d4: LoadField: r2 = r0->field_3f
    //     0xbef9d4: ldur            w2, [x0, #0x3f]
    // 0xbef9d8: DecompressPointer r2
    //     0xbef9d8: add             x2, x2, HEAP, lsl #32
    // 0xbef9dc: mov             x3, x2
    // 0xbef9e0: ldr             x2, [fp, #0x18]
    // 0xbef9e4: cmp             w2, NULL
    // 0xbef9e8: b.ne            #0xbef9f4
    // 0xbef9ec: r4 = Null
    //     0xbef9ec: mov             x4, NULL
    // 0xbef9f0: b               #0xbef9fc
    // 0xbef9f4: LoadField: r4 = r2->field_3f
    //     0xbef9f4: ldur            w4, [x2, #0x3f]
    // 0xbef9f8: DecompressPointer r4
    //     0xbef9f8: add             x4, x4, HEAP, lsl #32
    // 0xbef9fc: ldr             d0, [fp, #0x10]
    // 0xbefa00: r16 = <OutlinedBorder?>
    //     0xbefa00: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb8] TypeArguments: <OutlinedBorder?>
    //     0xbefa04: ldr             x16, [x16, #0xbb8]
    // 0xbefa08: stp             x3, x16, [SP, #-0x10]!
    // 0xbefa0c: SaveReg r4
    //     0xbefa0c: str             x4, [SP, #-8]!
    // 0xbefa10: SaveReg d0
    //     0xbefa10: str             d0, [SP, #-8]!
    // 0xbefa14: r16 = Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static.
    //     0xbefa14: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbc0] Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static. (0x7fe6e23f0d9c)
    //     0xbefa18: ldr             x16, [x16, #0xbc0]
    // 0xbefa1c: SaveReg r16
    //     0xbefa1c: str             x16, [SP, #-8]!
    // 0xbefa20: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbefa20: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbefa24: r0 = lerp()
    //     0xbefa24: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbefa28: add             SP, SP, #0x28
    // 0xbefa2c: ldr             d0, [fp, #0x10]
    // 0xbefa30: d1 = 0.500000
    //     0xbefa30: fmov            d1, #0.50000000
    // 0xbefa34: stur            x0, [fp, #-0xa8]
    // 0xbefa38: fcmp            d0, d1
    // 0xbefa3c: b.vs            #0xbefa44
    // 0xbefa40: b.lt            #0xbefa4c
    // 0xbefa44: r1 = false
    //     0xbefa44: add             x1, NULL, #0x30  ; false
    // 0xbefa48: b               #0xbefa50
    // 0xbefa4c: r1 = true
    //     0xbefa4c: add             x1, NULL, #0x20  ; true
    // 0xbefa50: stur            x1, [fp, #-0xa0]
    // 0xbefa54: tbnz            w1, #4, #0xbefa80
    // 0xbefa58: ldr             x2, [fp, #0x20]
    // 0xbefa5c: cmp             w2, NULL
    // 0xbefa60: b.ne            #0xbefa6c
    // 0xbefa64: r3 = Null
    //     0xbefa64: mov             x3, NULL
    // 0xbefa68: b               #0xbefa74
    // 0xbefa6c: LoadField: r3 = r2->field_43
    //     0xbefa6c: ldur            w3, [x2, #0x43]
    // 0xbefa70: DecompressPointer r3
    //     0xbefa70: add             x3, x3, HEAP, lsl #32
    // 0xbefa74: mov             x4, x3
    // 0xbefa78: ldr             x3, [fp, #0x18]
    // 0xbefa7c: b               #0xbefaa0
    // 0xbefa80: ldr             x2, [fp, #0x20]
    // 0xbefa84: ldr             x3, [fp, #0x18]
    // 0xbefa88: cmp             w3, NULL
    // 0xbefa8c: b.ne            #0xbefa98
    // 0xbefa90: r4 = Null
    //     0xbefa90: mov             x4, NULL
    // 0xbefa94: b               #0xbefaa0
    // 0xbefa98: LoadField: r4 = r3->field_43
    //     0xbefa98: ldur            w4, [x3, #0x43]
    // 0xbefa9c: DecompressPointer r4
    //     0xbefa9c: add             x4, x4, HEAP, lsl #32
    // 0xbefaa0: stur            x4, [fp, #-0x98]
    // 0xbefaa4: tbnz            w1, #4, #0xbefac4
    // 0xbefaa8: cmp             w2, NULL
    // 0xbefaac: b.ne            #0xbefab8
    // 0xbefab0: r5 = Null
    //     0xbefab0: mov             x5, NULL
    // 0xbefab4: b               #0xbefadc
    // 0xbefab8: LoadField: r5 = r2->field_47
    //     0xbefab8: ldur            w5, [x2, #0x47]
    // 0xbefabc: DecompressPointer r5
    //     0xbefabc: add             x5, x5, HEAP, lsl #32
    // 0xbefac0: b               #0xbefadc
    // 0xbefac4: cmp             w3, NULL
    // 0xbefac8: b.ne            #0xbefad4
    // 0xbefacc: r5 = Null
    //     0xbefacc: mov             x5, NULL
    // 0xbefad0: b               #0xbefadc
    // 0xbefad4: LoadField: r5 = r3->field_47
    //     0xbefad4: ldur            w5, [x3, #0x47]
    // 0xbefad8: DecompressPointer r5
    //     0xbefad8: add             x5, x5, HEAP, lsl #32
    // 0xbefadc: stur            x5, [fp, #-0x90]
    // 0xbefae0: tbnz            w1, #4, #0xbefb00
    // 0xbefae4: cmp             w2, NULL
    // 0xbefae8: b.ne            #0xbefaf4
    // 0xbefaec: r6 = Null
    //     0xbefaec: mov             x6, NULL
    // 0xbefaf0: b               #0xbefb18
    // 0xbefaf4: LoadField: r6 = r2->field_4b
    //     0xbefaf4: ldur            w6, [x2, #0x4b]
    // 0xbefaf8: DecompressPointer r6
    //     0xbefaf8: add             x6, x6, HEAP, lsl #32
    // 0xbefafc: b               #0xbefb18
    // 0xbefb00: cmp             w3, NULL
    // 0xbefb04: b.ne            #0xbefb10
    // 0xbefb08: r6 = Null
    //     0xbefb08: mov             x6, NULL
    // 0xbefb0c: b               #0xbefb18
    // 0xbefb10: LoadField: r6 = r3->field_4b
    //     0xbefb10: ldur            w6, [x3, #0x4b]
    // 0xbefb14: DecompressPointer r6
    //     0xbefb14: add             x6, x6, HEAP, lsl #32
    // 0xbefb18: stur            x6, [fp, #-0x88]
    // 0xbefb1c: tbnz            w1, #4, #0xbefb3c
    // 0xbefb20: cmp             w2, NULL
    // 0xbefb24: b.ne            #0xbefb30
    // 0xbefb28: r7 = Null
    //     0xbefb28: mov             x7, NULL
    // 0xbefb2c: b               #0xbefb54
    // 0xbefb30: LoadField: r7 = r2->field_4f
    //     0xbefb30: ldur            w7, [x2, #0x4f]
    // 0xbefb34: DecompressPointer r7
    //     0xbefb34: add             x7, x7, HEAP, lsl #32
    // 0xbefb38: b               #0xbefb54
    // 0xbefb3c: cmp             w3, NULL
    // 0xbefb40: b.ne            #0xbefb4c
    // 0xbefb44: r7 = Null
    //     0xbefb44: mov             x7, NULL
    // 0xbefb48: b               #0xbefb54
    // 0xbefb4c: LoadField: r7 = r3->field_4f
    //     0xbefb4c: ldur            w7, [x3, #0x4f]
    // 0xbefb50: DecompressPointer r7
    //     0xbefb50: add             x7, x7, HEAP, lsl #32
    // 0xbefb54: stur            x7, [fp, #-0x80]
    // 0xbefb58: tbnz            w1, #4, #0xbefb78
    // 0xbefb5c: cmp             w2, NULL
    // 0xbefb60: b.ne            #0xbefb6c
    // 0xbefb64: r8 = Null
    //     0xbefb64: mov             x8, NULL
    // 0xbefb68: b               #0xbefb90
    // 0xbefb6c: LoadField: r8 = r2->field_53
    //     0xbefb6c: ldur            w8, [x2, #0x53]
    // 0xbefb70: DecompressPointer r8
    //     0xbefb70: add             x8, x8, HEAP, lsl #32
    // 0xbefb74: b               #0xbefb90
    // 0xbefb78: cmp             w3, NULL
    // 0xbefb7c: b.ne            #0xbefb88
    // 0xbefb80: r8 = Null
    //     0xbefb80: mov             x8, NULL
    // 0xbefb84: b               #0xbefb90
    // 0xbefb88: LoadField: r8 = r3->field_53
    //     0xbefb88: ldur            w8, [x3, #0x53]
    // 0xbefb8c: DecompressPointer r8
    //     0xbefb8c: add             x8, x8, HEAP, lsl #32
    // 0xbefb90: stur            x8, [fp, #-0x78]
    // 0xbefb94: cmp             w2, NULL
    // 0xbefb98: b.ne            #0xbefba4
    // 0xbefb9c: r9 = Null
    //     0xbefb9c: mov             x9, NULL
    // 0xbefba0: b               #0xbefbac
    // 0xbefba4: LoadField: r9 = r2->field_57
    //     0xbefba4: ldur            w9, [x2, #0x57]
    // 0xbefba8: DecompressPointer r9
    //     0xbefba8: add             x9, x9, HEAP, lsl #32
    // 0xbefbac: cmp             w3, NULL
    // 0xbefbb0: b.ne            #0xbefbbc
    // 0xbefbb4: r10 = Null
    //     0xbefbb4: mov             x10, NULL
    // 0xbefbb8: b               #0xbefbc4
    // 0xbefbbc: LoadField: r10 = r3->field_57
    //     0xbefbbc: ldur            w10, [x3, #0x57]
    // 0xbefbc0: DecompressPointer r10
    //     0xbefbc0: add             x10, x10, HEAP, lsl #32
    // 0xbefbc4: stp             x10, x9, [SP, #-0x10]!
    // 0xbefbc8: SaveReg d0
    //     0xbefbc8: str             d0, [SP, #-8]!
    // 0xbefbcc: r0 = lerp()
    //     0xbefbcc: bl              #0xbefd44  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0xbefbd0: add             SP, SP, #0x18
    // 0xbefbd4: mov             x1, x0
    // 0xbefbd8: ldur            x0, [fp, #-0xa0]
    // 0xbefbdc: stur            x1, [fp, #-0xb0]
    // 0xbefbe0: tbnz            w0, #4, #0xbefc0c
    // 0xbefbe4: ldr             x0, [fp, #0x20]
    // 0xbefbe8: cmp             w0, NULL
    // 0xbefbec: b.ne            #0xbefbf8
    // 0xbefbf0: r0 = Null
    //     0xbefbf0: mov             x0, NULL
    // 0xbefbf4: b               #0xbefc04
    // 0xbefbf8: LoadField: r2 = r0->field_5b
    //     0xbefbf8: ldur            w2, [x0, #0x5b]
    // 0xbefbfc: DecompressPointer r2
    //     0xbefbfc: add             x2, x2, HEAP, lsl #32
    // 0xbefc00: mov             x0, x2
    // 0xbefc04: stur            x0, [fp, #-0xa0]
    // 0xbefc08: b               #0xbefc30
    // 0xbefc0c: ldr             x0, [fp, #0x18]
    // 0xbefc10: cmp             w0, NULL
    // 0xbefc14: b.ne            #0xbefc20
    // 0xbefc18: r0 = Null
    //     0xbefc18: mov             x0, NULL
    // 0xbefc1c: b               #0xbefc2c
    // 0xbefc20: LoadField: r2 = r0->field_5b
    //     0xbefc20: ldur            w2, [x0, #0x5b]
    // 0xbefc24: DecompressPointer r2
    //     0xbefc24: add             x2, x2, HEAP, lsl #32
    // 0xbefc28: mov             x0, x2
    // 0xbefc2c: stur            x0, [fp, #-0xa0]
    // 0xbefc30: ldur            x25, [fp, #-0x10]
    // 0xbefc34: ldur            x24, [fp, #-0x18]
    // 0xbefc38: ldur            x23, [fp, #-0x20]
    // 0xbefc3c: ldur            x20, [fp, #-0x28]
    // 0xbefc40: ldur            x19, [fp, #-0x30]
    // 0xbefc44: ldur            x14, [fp, #-0x38]
    // 0xbefc48: ldur            x13, [fp, #-0x40]
    // 0xbefc4c: ldur            x12, [fp, #-0x48]
    // 0xbefc50: ldur            x11, [fp, #-0x50]
    // 0xbefc54: ldur            x10, [fp, #-0x58]
    // 0xbefc58: ldur            x9, [fp, #-0x60]
    // 0xbefc5c: ldur            x8, [fp, #-0x68]
    // 0xbefc60: ldur            x7, [fp, #-0x70]
    // 0xbefc64: ldur            x0, [fp, #-0xa8]
    // 0xbefc68: ldur            x2, [fp, #-0x98]
    // 0xbefc6c: ldur            x3, [fp, #-0x90]
    // 0xbefc70: ldur            x4, [fp, #-0x88]
    // 0xbefc74: ldur            x5, [fp, #-0x80]
    // 0xbefc78: ldur            x6, [fp, #-0x78]
    // 0xbefc7c: r0 = ButtonStyle()
    //     0xbefc7c: bl              #0x9173f0  ; AllocateButtonStyleStub -> ButtonStyle (size=0x60)
    // 0xbefc80: ldur            x1, [fp, #-8]
    // 0xbefc84: StoreField: r0->field_7 = r1
    //     0xbefc84: stur            w1, [x0, #7]
    // 0xbefc88: ldur            x1, [fp, #-0x10]
    // 0xbefc8c: StoreField: r0->field_b = r1
    //     0xbefc8c: stur            w1, [x0, #0xb]
    // 0xbefc90: ldur            x1, [fp, #-0x18]
    // 0xbefc94: StoreField: r0->field_f = r1
    //     0xbefc94: stur            w1, [x0, #0xf]
    // 0xbefc98: ldur            x1, [fp, #-0x20]
    // 0xbefc9c: StoreField: r0->field_13 = r1
    //     0xbefc9c: stur            w1, [x0, #0x13]
    // 0xbefca0: ldur            x1, [fp, #-0x28]
    // 0xbefca4: StoreField: r0->field_17 = r1
    //     0xbefca4: stur            w1, [x0, #0x17]
    // 0xbefca8: ldur            x1, [fp, #-0x30]
    // 0xbefcac: StoreField: r0->field_1b = r1
    //     0xbefcac: stur            w1, [x0, #0x1b]
    // 0xbefcb0: ldur            x1, [fp, #-0x38]
    // 0xbefcb4: StoreField: r0->field_1f = r1
    //     0xbefcb4: stur            w1, [x0, #0x1f]
    // 0xbefcb8: ldur            x1, [fp, #-0x40]
    // 0xbefcbc: StoreField: r0->field_23 = r1
    //     0xbefcbc: stur            w1, [x0, #0x23]
    // 0xbefcc0: ldur            x1, [fp, #-0x48]
    // 0xbefcc4: StoreField: r0->field_27 = r1
    //     0xbefcc4: stur            w1, [x0, #0x27]
    // 0xbefcc8: ldur            x1, [fp, #-0x50]
    // 0xbefccc: StoreField: r0->field_2b = r1
    //     0xbefccc: stur            w1, [x0, #0x2b]
    // 0xbefcd0: ldur            x1, [fp, #-0x58]
    // 0xbefcd4: StoreField: r0->field_2f = r1
    //     0xbefcd4: stur            w1, [x0, #0x2f]
    // 0xbefcd8: ldur            x1, [fp, #-0x60]
    // 0xbefcdc: StoreField: r0->field_33 = r1
    //     0xbefcdc: stur            w1, [x0, #0x33]
    // 0xbefce0: ldur            x1, [fp, #-0x68]
    // 0xbefce4: StoreField: r0->field_37 = r1
    //     0xbefce4: stur            w1, [x0, #0x37]
    // 0xbefce8: ldur            x1, [fp, #-0x70]
    // 0xbefcec: StoreField: r0->field_3b = r1
    //     0xbefcec: stur            w1, [x0, #0x3b]
    // 0xbefcf0: ldur            x1, [fp, #-0xa8]
    // 0xbefcf4: StoreField: r0->field_3f = r1
    //     0xbefcf4: stur            w1, [x0, #0x3f]
    // 0xbefcf8: ldur            x1, [fp, #-0x98]
    // 0xbefcfc: StoreField: r0->field_43 = r1
    //     0xbefcfc: stur            w1, [x0, #0x43]
    // 0xbefd00: ldur            x1, [fp, #-0x90]
    // 0xbefd04: StoreField: r0->field_47 = r1
    //     0xbefd04: stur            w1, [x0, #0x47]
    // 0xbefd08: ldur            x1, [fp, #-0x88]
    // 0xbefd0c: StoreField: r0->field_4b = r1
    //     0xbefd0c: stur            w1, [x0, #0x4b]
    // 0xbefd10: ldur            x1, [fp, #-0x80]
    // 0xbefd14: StoreField: r0->field_4f = r1
    //     0xbefd14: stur            w1, [x0, #0x4f]
    // 0xbefd18: ldur            x1, [fp, #-0x78]
    // 0xbefd1c: StoreField: r0->field_53 = r1
    //     0xbefd1c: stur            w1, [x0, #0x53]
    // 0xbefd20: ldur            x1, [fp, #-0xb0]
    // 0xbefd24: StoreField: r0->field_57 = r1
    //     0xbefd24: stur            w1, [x0, #0x57]
    // 0xbefd28: ldur            x1, [fp, #-0xa0]
    // 0xbefd2c: StoreField: r0->field_5b = r1
    //     0xbefd2c: stur            w1, [x0, #0x5b]
    // 0xbefd30: LeaveFrame
    //     0xbefd30: mov             SP, fp
    //     0xbefd34: ldp             fp, lr, [SP], #0x10
    // 0xbefd38: ret
    //     0xbefd38: ret             
    // 0xbefd3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbefd3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbefd40: b               #0xbef364
  }
  static _ _lerpSides(/* No info */) {
    // ** addr: 0xbf0c8c, size: 0x60
    // 0xbf0c8c: EnterFrame
    //     0xbf0c8c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0c90: mov             fp, SP
    // 0xbf0c94: ldr             x0, [fp, #0x20]
    // 0xbf0c98: cmp             w0, NULL
    // 0xbf0c9c: b.ne            #0xbf0cbc
    // 0xbf0ca0: ldr             x1, [fp, #0x18]
    // 0xbf0ca4: cmp             w1, NULL
    // 0xbf0ca8: b.ne            #0xbf0cc0
    // 0xbf0cac: r0 = Null
    //     0xbf0cac: mov             x0, NULL
    // 0xbf0cb0: LeaveFrame
    //     0xbf0cb0: mov             SP, fp
    //     0xbf0cb4: ldp             fp, lr, [SP], #0x10
    // 0xbf0cb8: ret
    //     0xbf0cb8: ret             
    // 0xbf0cbc: ldr             x1, [fp, #0x18]
    // 0xbf0cc0: ldr             d0, [fp, #0x10]
    // 0xbf0cc4: r0 = _LerpSides()
    //     0xbf0cc4: bl              #0xbf0cec  ; Allocate_LerpSidesStub -> _LerpSides (size=0x18)
    // 0xbf0cc8: ldr             x1, [fp, #0x20]
    // 0xbf0ccc: StoreField: r0->field_7 = r1
    //     0xbf0ccc: stur            w1, [x0, #7]
    // 0xbf0cd0: ldr             x1, [fp, #0x18]
    // 0xbf0cd4: StoreField: r0->field_b = r1
    //     0xbf0cd4: stur            w1, [x0, #0xb]
    // 0xbf0cd8: ldr             d0, [fp, #0x10]
    // 0xbf0cdc: StoreField: r0->field_f = d0
    //     0xbf0cdc: stur            d0, [x0, #0xf]
    // 0xbf0ce0: LeaveFrame
    //     0xbf0ce0: mov             SP, fp
    //     0xbf0ce4: ldp             fp, lr, [SP], #0x10
    // 0xbf0ce8: ret
    //     0xbf0ce8: ret             
  }
  _ merge(/* No info */) {
    // ** addr: 0xc123c0, size: 0x2b8
    // 0xc123c0: EnterFrame
    //     0xc123c0: stp             fp, lr, [SP, #-0x10]!
    //     0xc123c4: mov             fp, SP
    // 0xc123c8: AllocStack(0x20)
    //     0xc123c8: sub             SP, SP, #0x20
    // 0xc123cc: CheckStackOverflow
    //     0xc123cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc123d0: cmp             SP, x16
    //     0xc123d4: b.ls            #0xc12670
    // 0xc123d8: ldr             x0, [fp, #0x18]
    // 0xc123dc: LoadField: r1 = r0->field_7
    //     0xc123dc: ldur            w1, [x0, #7]
    // 0xc123e0: DecompressPointer r1
    //     0xc123e0: add             x1, x1, HEAP, lsl #32
    // 0xc123e4: cmp             w1, NULL
    // 0xc123e8: b.ne            #0xc123fc
    // 0xc123ec: ldr             x2, [fp, #0x10]
    // 0xc123f0: LoadField: r1 = r2->field_7
    //     0xc123f0: ldur            w1, [x2, #7]
    // 0xc123f4: DecompressPointer r1
    //     0xc123f4: add             x1, x1, HEAP, lsl #32
    // 0xc123f8: b               #0xc12400
    // 0xc123fc: ldr             x2, [fp, #0x10]
    // 0xc12400: LoadField: r3 = r0->field_b
    //     0xc12400: ldur            w3, [x0, #0xb]
    // 0xc12404: DecompressPointer r3
    //     0xc12404: add             x3, x3, HEAP, lsl #32
    // 0xc12408: cmp             w3, NULL
    // 0xc1240c: b.ne            #0xc12418
    // 0xc12410: LoadField: r3 = r2->field_b
    //     0xc12410: ldur            w3, [x2, #0xb]
    // 0xc12414: DecompressPointer r3
    //     0xc12414: add             x3, x3, HEAP, lsl #32
    // 0xc12418: LoadField: r4 = r0->field_f
    //     0xc12418: ldur            w4, [x0, #0xf]
    // 0xc1241c: DecompressPointer r4
    //     0xc1241c: add             x4, x4, HEAP, lsl #32
    // 0xc12420: cmp             w4, NULL
    // 0xc12424: b.ne            #0xc12430
    // 0xc12428: LoadField: r4 = r2->field_f
    //     0xc12428: ldur            w4, [x2, #0xf]
    // 0xc1242c: DecompressPointer r4
    //     0xc1242c: add             x4, x4, HEAP, lsl #32
    // 0xc12430: LoadField: r5 = r0->field_13
    //     0xc12430: ldur            w5, [x0, #0x13]
    // 0xc12434: DecompressPointer r5
    //     0xc12434: add             x5, x5, HEAP, lsl #32
    // 0xc12438: cmp             w5, NULL
    // 0xc1243c: b.ne            #0xc12448
    // 0xc12440: LoadField: r5 = r2->field_13
    //     0xc12440: ldur            w5, [x2, #0x13]
    // 0xc12444: DecompressPointer r5
    //     0xc12444: add             x5, x5, HEAP, lsl #32
    // 0xc12448: LoadField: r6 = r0->field_17
    //     0xc12448: ldur            w6, [x0, #0x17]
    // 0xc1244c: DecompressPointer r6
    //     0xc1244c: add             x6, x6, HEAP, lsl #32
    // 0xc12450: cmp             w6, NULL
    // 0xc12454: b.ne            #0xc12460
    // 0xc12458: LoadField: r6 = r2->field_17
    //     0xc12458: ldur            w6, [x2, #0x17]
    // 0xc1245c: DecompressPointer r6
    //     0xc1245c: add             x6, x6, HEAP, lsl #32
    // 0xc12460: LoadField: r7 = r0->field_1b
    //     0xc12460: ldur            w7, [x0, #0x1b]
    // 0xc12464: DecompressPointer r7
    //     0xc12464: add             x7, x7, HEAP, lsl #32
    // 0xc12468: cmp             w7, NULL
    // 0xc1246c: b.ne            #0xc12478
    // 0xc12470: LoadField: r7 = r2->field_1b
    //     0xc12470: ldur            w7, [x2, #0x1b]
    // 0xc12474: DecompressPointer r7
    //     0xc12474: add             x7, x7, HEAP, lsl #32
    // 0xc12478: LoadField: r8 = r0->field_1f
    //     0xc12478: ldur            w8, [x0, #0x1f]
    // 0xc1247c: DecompressPointer r8
    //     0xc1247c: add             x8, x8, HEAP, lsl #32
    // 0xc12480: cmp             w8, NULL
    // 0xc12484: b.ne            #0xc12490
    // 0xc12488: LoadField: r8 = r2->field_1f
    //     0xc12488: ldur            w8, [x2, #0x1f]
    // 0xc1248c: DecompressPointer r8
    //     0xc1248c: add             x8, x8, HEAP, lsl #32
    // 0xc12490: LoadField: r9 = r0->field_23
    //     0xc12490: ldur            w9, [x0, #0x23]
    // 0xc12494: DecompressPointer r9
    //     0xc12494: add             x9, x9, HEAP, lsl #32
    // 0xc12498: cmp             w9, NULL
    // 0xc1249c: b.ne            #0xc124a8
    // 0xc124a0: LoadField: r9 = r2->field_23
    //     0xc124a0: ldur            w9, [x2, #0x23]
    // 0xc124a4: DecompressPointer r9
    //     0xc124a4: add             x9, x9, HEAP, lsl #32
    // 0xc124a8: LoadField: r10 = r0->field_27
    //     0xc124a8: ldur            w10, [x0, #0x27]
    // 0xc124ac: DecompressPointer r10
    //     0xc124ac: add             x10, x10, HEAP, lsl #32
    // 0xc124b0: cmp             w10, NULL
    // 0xc124b4: b.ne            #0xc124c0
    // 0xc124b8: LoadField: r10 = r2->field_27
    //     0xc124b8: ldur            w10, [x2, #0x27]
    // 0xc124bc: DecompressPointer r10
    //     0xc124bc: add             x10, x10, HEAP, lsl #32
    // 0xc124c0: LoadField: r11 = r0->field_2b
    //     0xc124c0: ldur            w11, [x0, #0x2b]
    // 0xc124c4: DecompressPointer r11
    //     0xc124c4: add             x11, x11, HEAP, lsl #32
    // 0xc124c8: cmp             w11, NULL
    // 0xc124cc: b.ne            #0xc124d8
    // 0xc124d0: LoadField: r11 = r2->field_2b
    //     0xc124d0: ldur            w11, [x2, #0x2b]
    // 0xc124d4: DecompressPointer r11
    //     0xc124d4: add             x11, x11, HEAP, lsl #32
    // 0xc124d8: LoadField: r12 = r0->field_2f
    //     0xc124d8: ldur            w12, [x0, #0x2f]
    // 0xc124dc: DecompressPointer r12
    //     0xc124dc: add             x12, x12, HEAP, lsl #32
    // 0xc124e0: cmp             w12, NULL
    // 0xc124e4: b.ne            #0xc124f0
    // 0xc124e8: LoadField: r12 = r2->field_2f
    //     0xc124e8: ldur            w12, [x2, #0x2f]
    // 0xc124ec: DecompressPointer r12
    //     0xc124ec: add             x12, x12, HEAP, lsl #32
    // 0xc124f0: LoadField: r13 = r0->field_33
    //     0xc124f0: ldur            w13, [x0, #0x33]
    // 0xc124f4: DecompressPointer r13
    //     0xc124f4: add             x13, x13, HEAP, lsl #32
    // 0xc124f8: cmp             w13, NULL
    // 0xc124fc: b.ne            #0xc12508
    // 0xc12500: LoadField: r13 = r2->field_33
    //     0xc12500: ldur            w13, [x2, #0x33]
    // 0xc12504: DecompressPointer r13
    //     0xc12504: add             x13, x13, HEAP, lsl #32
    // 0xc12508: LoadField: r14 = r0->field_37
    //     0xc12508: ldur            w14, [x0, #0x37]
    // 0xc1250c: DecompressPointer r14
    //     0xc1250c: add             x14, x14, HEAP, lsl #32
    // 0xc12510: cmp             w14, NULL
    // 0xc12514: b.ne            #0xc12520
    // 0xc12518: LoadField: r14 = r2->field_37
    //     0xc12518: ldur            w14, [x2, #0x37]
    // 0xc1251c: DecompressPointer r14
    //     0xc1251c: add             x14, x14, HEAP, lsl #32
    // 0xc12520: LoadField: r19 = r0->field_3b
    //     0xc12520: ldur            w19, [x0, #0x3b]
    // 0xc12524: DecompressPointer r19
    //     0xc12524: add             x19, x19, HEAP, lsl #32
    // 0xc12528: cmp             w19, NULL
    // 0xc1252c: b.ne            #0xc12538
    // 0xc12530: LoadField: r19 = r2->field_3b
    //     0xc12530: ldur            w19, [x2, #0x3b]
    // 0xc12534: DecompressPointer r19
    //     0xc12534: add             x19, x19, HEAP, lsl #32
    // 0xc12538: LoadField: r20 = r0->field_3f
    //     0xc12538: ldur            w20, [x0, #0x3f]
    // 0xc1253c: DecompressPointer r20
    //     0xc1253c: add             x20, x20, HEAP, lsl #32
    // 0xc12540: cmp             w20, NULL
    // 0xc12544: b.ne            #0xc12550
    // 0xc12548: LoadField: r20 = r2->field_3f
    //     0xc12548: ldur            w20, [x2, #0x3f]
    // 0xc1254c: DecompressPointer r20
    //     0xc1254c: add             x20, x20, HEAP, lsl #32
    // 0xc12550: LoadField: r23 = r0->field_43
    //     0xc12550: ldur            w23, [x0, #0x43]
    // 0xc12554: DecompressPointer r23
    //     0xc12554: add             x23, x23, HEAP, lsl #32
    // 0xc12558: cmp             w23, NULL
    // 0xc1255c: b.ne            #0xc12568
    // 0xc12560: LoadField: r23 = r2->field_43
    //     0xc12560: ldur            w23, [x2, #0x43]
    // 0xc12564: DecompressPointer r23
    //     0xc12564: add             x23, x23, HEAP, lsl #32
    // 0xc12568: LoadField: r24 = r0->field_47
    //     0xc12568: ldur            w24, [x0, #0x47]
    // 0xc1256c: DecompressPointer r24
    //     0xc1256c: add             x24, x24, HEAP, lsl #32
    // 0xc12570: cmp             w24, NULL
    // 0xc12574: b.ne            #0xc12580
    // 0xc12578: LoadField: r24 = r2->field_47
    //     0xc12578: ldur            w24, [x2, #0x47]
    // 0xc1257c: DecompressPointer r24
    //     0xc1257c: add             x24, x24, HEAP, lsl #32
    // 0xc12580: LoadField: r25 = r0->field_4b
    //     0xc12580: ldur            w25, [x0, #0x4b]
    // 0xc12584: DecompressPointer r25
    //     0xc12584: add             x25, x25, HEAP, lsl #32
    // 0xc12588: cmp             w25, NULL
    // 0xc1258c: b.ne            #0xc12598
    // 0xc12590: LoadField: r25 = r2->field_4b
    //     0xc12590: ldur            w25, [x2, #0x4b]
    // 0xc12594: DecompressPointer r25
    //     0xc12594: add             x25, x25, HEAP, lsl #32
    // 0xc12598: stur            x25, [fp, #-8]
    // 0xc1259c: LoadField: r25 = r0->field_4f
    //     0xc1259c: ldur            w25, [x0, #0x4f]
    // 0xc125a0: DecompressPointer r25
    //     0xc125a0: add             x25, x25, HEAP, lsl #32
    // 0xc125a4: cmp             w25, NULL
    // 0xc125a8: b.ne            #0xc125b4
    // 0xc125ac: LoadField: r25 = r2->field_4f
    //     0xc125ac: ldur            w25, [x2, #0x4f]
    // 0xc125b0: DecompressPointer r25
    //     0xc125b0: add             x25, x25, HEAP, lsl #32
    // 0xc125b4: stur            x25, [fp, #-0x10]
    // 0xc125b8: LoadField: r25 = r0->field_53
    //     0xc125b8: ldur            w25, [x0, #0x53]
    // 0xc125bc: DecompressPointer r25
    //     0xc125bc: add             x25, x25, HEAP, lsl #32
    // 0xc125c0: cmp             w25, NULL
    // 0xc125c4: b.ne            #0xc125d0
    // 0xc125c8: LoadField: r25 = r2->field_53
    //     0xc125c8: ldur            w25, [x2, #0x53]
    // 0xc125cc: DecompressPointer r25
    //     0xc125cc: add             x25, x25, HEAP, lsl #32
    // 0xc125d0: stur            x25, [fp, #-0x18]
    // 0xc125d4: LoadField: r25 = r0->field_57
    //     0xc125d4: ldur            w25, [x0, #0x57]
    // 0xc125d8: DecompressPointer r25
    //     0xc125d8: add             x25, x25, HEAP, lsl #32
    // 0xc125dc: cmp             w25, NULL
    // 0xc125e0: b.ne            #0xc125ec
    // 0xc125e4: LoadField: r25 = r2->field_57
    //     0xc125e4: ldur            w25, [x2, #0x57]
    // 0xc125e8: DecompressPointer r25
    //     0xc125e8: add             x25, x25, HEAP, lsl #32
    // 0xc125ec: stur            x25, [fp, #-0x20]
    // 0xc125f0: LoadField: r25 = r0->field_5b
    //     0xc125f0: ldur            w25, [x0, #0x5b]
    // 0xc125f4: DecompressPointer r25
    //     0xc125f4: add             x25, x25, HEAP, lsl #32
    // 0xc125f8: cmp             w25, NULL
    // 0xc125fc: b.ne            #0xc12610
    // 0xc12600: LoadField: r25 = r2->field_5b
    //     0xc12600: ldur            w25, [x2, #0x5b]
    // 0xc12604: DecompressPointer r25
    //     0xc12604: add             x25, x25, HEAP, lsl #32
    // 0xc12608: mov             x2, x25
    // 0xc1260c: b               #0xc12614
    // 0xc12610: mov             x2, x25
    // 0xc12614: stp             x9, x0, [SP, #-0x10]!
    // 0xc12618: stp             x3, x1, [SP, #-0x10]!
    // 0xc1261c: stp             x5, x4, [SP, #-0x10]!
    // 0xc12620: stp             x7, x6, [SP, #-0x10]!
    // 0xc12624: stp             x10, x8, [SP, #-0x10]!
    // 0xc12628: stp             x12, x11, [SP, #-0x10]!
    // 0xc1262c: stp             x14, x13, [SP, #-0x10]!
    // 0xc12630: stp             x20, x19, [SP, #-0x10]!
    // 0xc12634: stp             x24, x23, [SP, #-0x10]!
    // 0xc12638: ldur            x16, [fp, #-8]
    // 0xc1263c: ldur            lr, [fp, #-0x10]
    // 0xc12640: stp             lr, x16, [SP, #-0x10]!
    // 0xc12644: ldur            x16, [fp, #-0x18]
    // 0xc12648: ldur            lr, [fp, #-0x20]
    // 0xc1264c: stp             lr, x16, [SP, #-0x10]!
    // 0xc12650: SaveReg r2
    //     0xc12650: str             x2, [SP, #-8]!
    // 0xc12654: r4 = const [0, 0x17, 0x17, 0x2, alignment, 0x15, animationDuration, 0x13, backgroundColor, 0x3, elevation, 0x8, enableFeedback, 0x14, fixedSize, 0xa, foregroundColor, 0x4, iconColor, 0xc, iconSize, 0xd, maximumSize, 0xb, minimumSize, 0x9, mouseCursor, 0x10, overlayColor, 0x5, shadowColor, 0x6, shape, 0xf, side, 0xe, splashFactory, 0x16, surfaceTintColor, 0x7, tapTargetSize, 0x12, textStyle, 0x2, visualDensity, 0x11, null]
    //     0xc12654: add             x4, PP, #0x53, lsl #12  ; [pp+0x53150] List(47) [0, 0x17, 0x17, 0x2, "alignment", 0x15, "animationDuration", 0x13, "backgroundColor", 0x3, "elevation", 0x8, "enableFeedback", 0x14, "fixedSize", 0xa, "foregroundColor", 0x4, "iconColor", 0xc, "iconSize", 0xd, "maximumSize", 0xb, "minimumSize", 0x9, "mouseCursor", 0x10, "overlayColor", 0x5, "shadowColor", 0x6, "shape", 0xf, "side", 0xe, "splashFactory", 0x16, "surfaceTintColor", 0x7, "tapTargetSize", 0x12, "textStyle", 0x2, "visualDensity", 0x11, Null]
    //     0xc12658: ldr             x4, [x4, #0x150]
    // 0xc1265c: r0 = copyWith()
    //     0xc1265c: bl              #0xc12678  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0xc12660: add             SP, SP, #0xb8
    // 0xc12664: LeaveFrame
    //     0xc12664: mov             SP, fp
    //     0xc12668: ldp             fp, lr, [SP], #0x10
    // 0xc1266c: ret
    //     0xc1266c: ret             
    // 0xc12670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12670: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc12674: b               #0xc123d8
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xc12678, size: 0xd68
    // 0xc12678: EnterFrame
    //     0xc12678: stp             fp, lr, [SP, #-0x10]!
    //     0xc1267c: mov             fp, SP
    // 0xc12680: AllocStack(0xc8)
    //     0xc12680: sub             SP, SP, #0xc8
    // 0xc12684: SetupParameters(ButtonStyle this /* r3, fp-0xb0 */, dynamic _ /* fp-0x8 */, {dynamic alignment = Null /* r5, fp-0xa8 */, dynamic animationDuration = Null /* r6, fp-0xa0 */, dynamic backgroundColor = Null /* r7, fp-0x98 */, dynamic elevation = Null /* r8, fp-0x90 */, dynamic enableFeedback = Null /* r9, fp-0x88 */, dynamic fixedSize = Null /* r10, fp-0x80 */, dynamic foregroundColor = Null /* r11, fp-0x78 */, dynamic iconColor = Null /* r12, fp-0x70 */, dynamic iconSize = Null /* r13, fp-0x68 */, dynamic maximumSize = Null /* r14, fp-0x60 */, dynamic minimumSize = Null /* r19, fp-0x58 */, dynamic mouseCursor = Null /* r20, fp-0x50 */, dynamic overlayColor = Null /* fp-0x10 */, dynamic shadowColor = Null /* fp-0x18 */, dynamic shape = Null /* fp-0x20 */, dynamic side = Null /* fp-0x28 */, dynamic splashFactory = Null /* fp-0x30 */, dynamic surfaceTintColor = Null /* fp-0x38 */, dynamic tapTargetSize = Null /* fp-0x40 */, dynamic textStyle = Null /* r4 */, dynamic visualDensity = Null /* r1, fp-0x48 */})
    //     0xc12684: mov             x0, x4
    //     0xc12688: ldur            w1, [x0, #0x13]
    //     0xc1268c: add             x1, x1, HEAP, lsl #32
    //     0xc12690: sub             x2, x1, #4
    //     0xc12694: add             x3, fp, w2, sxtw #2
    //     0xc12698: ldr             x3, [x3, #0x18]
    //     0xc1269c: stur            x3, [fp, #-0xb0]
    //     0xc126a0: add             x4, fp, w2, sxtw #2
    //     0xc126a4: ldr             x4, [x4, #0x10]
    //     0xc126a8: stur            x4, [fp, #-8]
    //     0xc126ac: ldur            w2, [x0, #0x1f]
    //     0xc126b0: add             x2, x2, HEAP, lsl #32
    //     0xc126b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdad8] "alignment"
    //     0xc126b8: ldr             x16, [x16, #0xad8]
    //     0xc126bc: cmp             w2, w16
    //     0xc126c0: b.ne            #0xc126e4
    //     0xc126c4: ldur            w2, [x0, #0x23]
    //     0xc126c8: add             x2, x2, HEAP, lsl #32
    //     0xc126cc: sub             w5, w1, w2
    //     0xc126d0: add             x2, fp, w5, sxtw #2
    //     0xc126d4: ldr             x2, [x2, #8]
    //     0xc126d8: mov             x5, x2
    //     0xc126dc: mov             x2, #1
    //     0xc126e0: b               #0xc126ec
    //     0xc126e4: mov             x5, NULL
    //     0xc126e8: mov             x2, #0
    //     0xc126ec: stur            x5, [fp, #-0xa8]
    //     0xc126f0: lsl             x6, x2, #1
    //     0xc126f4: lsl             w7, w6, #1
    //     0xc126f8: add             w8, w7, #8
    //     0xc126fc: add             x16, x0, w8, sxtw #1
    //     0xc12700: ldur            w9, [x16, #0xf]
    //     0xc12704: add             x9, x9, HEAP, lsl #32
    //     0xc12708: add             x16, PP, #0x26, lsl #12  ; [pp+0x26850] "animationDuration"
    //     0xc1270c: ldr             x16, [x16, #0x850]
    //     0xc12710: cmp             w9, w16
    //     0xc12714: b.ne            #0xc12748
    //     0xc12718: add             w2, w7, #0xa
    //     0xc1271c: add             x16, x0, w2, sxtw #1
    //     0xc12720: ldur            w7, [x16, #0xf]
    //     0xc12724: add             x7, x7, HEAP, lsl #32
    //     0xc12728: sub             w2, w1, w7
    //     0xc1272c: add             x7, fp, w2, sxtw #2
    //     0xc12730: ldr             x7, [x7, #8]
    //     0xc12734: add             w2, w6, #2
    //     0xc12738: sbfx            x6, x2, #1, #0x1f
    //     0xc1273c: mov             x2, x6
    //     0xc12740: mov             x6, x7
    //     0xc12744: b               #0xc1274c
    //     0xc12748: mov             x6, NULL
    //     0xc1274c: stur            x6, [fp, #-0xa0]
    //     0xc12750: lsl             x7, x2, #1
    //     0xc12754: lsl             w8, w7, #1
    //     0xc12758: add             w9, w8, #8
    //     0xc1275c: add             x16, x0, w9, sxtw #1
    //     0xc12760: ldur            w10, [x16, #0xf]
    //     0xc12764: add             x10, x10, HEAP, lsl #32
    //     0xc12768: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc48] "backgroundColor"
    //     0xc1276c: ldr             x16, [x16, #0xc48]
    //     0xc12770: cmp             w10, w16
    //     0xc12774: b.ne            #0xc127a8
    //     0xc12778: add             w2, w8, #0xa
    //     0xc1277c: add             x16, x0, w2, sxtw #1
    //     0xc12780: ldur            w8, [x16, #0xf]
    //     0xc12784: add             x8, x8, HEAP, lsl #32
    //     0xc12788: sub             w2, w1, w8
    //     0xc1278c: add             x8, fp, w2, sxtw #2
    //     0xc12790: ldr             x8, [x8, #8]
    //     0xc12794: add             w2, w7, #2
    //     0xc12798: sbfx            x7, x2, #1, #0x1f
    //     0xc1279c: mov             x2, x7
    //     0xc127a0: mov             x7, x8
    //     0xc127a4: b               #0xc127ac
    //     0xc127a8: mov             x7, NULL
    //     0xc127ac: stur            x7, [fp, #-0x98]
    //     0xc127b0: lsl             x8, x2, #1
    //     0xc127b4: lsl             w9, w8, #1
    //     0xc127b8: add             w10, w9, #8
    //     0xc127bc: add             x16, x0, w10, sxtw #1
    //     0xc127c0: ldur            w11, [x16, #0xf]
    //     0xc127c4: add             x11, x11, HEAP, lsl #32
    //     0xc127c8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26870] "elevation"
    //     0xc127cc: ldr             x16, [x16, #0x870]
    //     0xc127d0: cmp             w11, w16
    //     0xc127d4: b.ne            #0xc12808
    //     0xc127d8: add             w2, w9, #0xa
    //     0xc127dc: add             x16, x0, w2, sxtw #1
    //     0xc127e0: ldur            w9, [x16, #0xf]
    //     0xc127e4: add             x9, x9, HEAP, lsl #32
    //     0xc127e8: sub             w2, w1, w9
    //     0xc127ec: add             x9, fp, w2, sxtw #2
    //     0xc127f0: ldr             x9, [x9, #8]
    //     0xc127f4: add             w2, w8, #2
    //     0xc127f8: sbfx            x8, x2, #1, #0x1f
    //     0xc127fc: mov             x2, x8
    //     0xc12800: mov             x8, x9
    //     0xc12804: b               #0xc1280c
    //     0xc12808: mov             x8, NULL
    //     0xc1280c: stur            x8, [fp, #-0x90]
    //     0xc12810: lsl             x9, x2, #1
    //     0xc12814: lsl             w10, w9, #1
    //     0xc12818: add             w11, w10, #8
    //     0xc1281c: add             x16, x0, w11, sxtw #1
    //     0xc12820: ldur            w12, [x16, #0xf]
    //     0xc12824: add             x12, x12, HEAP, lsl #32
    //     0xc12828: add             x16, PP, #0x26, lsl #12  ; [pp+0x26878] "enableFeedback"
    //     0xc1282c: ldr             x16, [x16, #0x878]
    //     0xc12830: cmp             w12, w16
    //     0xc12834: b.ne            #0xc12868
    //     0xc12838: add             w2, w10, #0xa
    //     0xc1283c: add             x16, x0, w2, sxtw #1
    //     0xc12840: ldur            w10, [x16, #0xf]
    //     0xc12844: add             x10, x10, HEAP, lsl #32
    //     0xc12848: sub             w2, w1, w10
    //     0xc1284c: add             x10, fp, w2, sxtw #2
    //     0xc12850: ldr             x10, [x10, #8]
    //     0xc12854: add             w2, w9, #2
    //     0xc12858: sbfx            x9, x2, #1, #0x1f
    //     0xc1285c: mov             x2, x9
    //     0xc12860: mov             x9, x10
    //     0xc12864: b               #0xc1286c
    //     0xc12868: mov             x9, NULL
    //     0xc1286c: stur            x9, [fp, #-0x88]
    //     0xc12870: lsl             x10, x2, #1
    //     0xc12874: lsl             w11, w10, #1
    //     0xc12878: add             w12, w11, #8
    //     0xc1287c: add             x16, x0, w12, sxtw #1
    //     0xc12880: ldur            w13, [x16, #0xf]
    //     0xc12884: add             x13, x13, HEAP, lsl #32
    //     0xc12888: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff58] "fixedSize"
    //     0xc1288c: ldr             x16, [x16, #0xf58]
    //     0xc12890: cmp             w13, w16
    //     0xc12894: b.ne            #0xc128c8
    //     0xc12898: add             w2, w11, #0xa
    //     0xc1289c: add             x16, x0, w2, sxtw #1
    //     0xc128a0: ldur            w11, [x16, #0xf]
    //     0xc128a4: add             x11, x11, HEAP, lsl #32
    //     0xc128a8: sub             w2, w1, w11
    //     0xc128ac: add             x11, fp, w2, sxtw #2
    //     0xc128b0: ldr             x11, [x11, #8]
    //     0xc128b4: add             w2, w10, #2
    //     0xc128b8: sbfx            x10, x2, #1, #0x1f
    //     0xc128bc: mov             x2, x10
    //     0xc128c0: mov             x10, x11
    //     0xc128c4: b               #0xc128cc
    //     0xc128c8: mov             x10, NULL
    //     0xc128cc: stur            x10, [fp, #-0x80]
    //     0xc128d0: lsl             x11, x2, #1
    //     0xc128d4: lsl             w12, w11, #1
    //     0xc128d8: add             w13, w12, #8
    //     0xc128dc: add             x16, x0, w13, sxtw #1
    //     0xc128e0: ldur            w14, [x16, #0xf]
    //     0xc128e4: add             x14, x14, HEAP, lsl #32
    //     0xc128e8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26888] "foregroundColor"
    //     0xc128ec: ldr             x16, [x16, #0x888]
    //     0xc128f0: cmp             w14, w16
    //     0xc128f4: b.ne            #0xc12928
    //     0xc128f8: add             w2, w12, #0xa
    //     0xc128fc: add             x16, x0, w2, sxtw #1
    //     0xc12900: ldur            w12, [x16, #0xf]
    //     0xc12904: add             x12, x12, HEAP, lsl #32
    //     0xc12908: sub             w2, w1, w12
    //     0xc1290c: add             x12, fp, w2, sxtw #2
    //     0xc12910: ldr             x12, [x12, #8]
    //     0xc12914: add             w2, w11, #2
    //     0xc12918: sbfx            x11, x2, #1, #0x1f
    //     0xc1291c: mov             x2, x11
    //     0xc12920: mov             x11, x12
    //     0xc12924: b               #0xc1292c
    //     0xc12928: mov             x11, NULL
    //     0xc1292c: stur            x11, [fp, #-0x78]
    //     0xc12930: lsl             x12, x2, #1
    //     0xc12934: lsl             w13, w12, #1
    //     0xc12938: add             w14, w13, #8
    //     0xc1293c: add             x16, x0, w14, sxtw #1
    //     0xc12940: ldur            w19, [x16, #0xf]
    //     0xc12944: add             x19, x19, HEAP, lsl #32
    //     0xc12948: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff60] "iconColor"
    //     0xc1294c: ldr             x16, [x16, #0xf60]
    //     0xc12950: cmp             w19, w16
    //     0xc12954: b.ne            #0xc12988
    //     0xc12958: add             w2, w13, #0xa
    //     0xc1295c: add             x16, x0, w2, sxtw #1
    //     0xc12960: ldur            w13, [x16, #0xf]
    //     0xc12964: add             x13, x13, HEAP, lsl #32
    //     0xc12968: sub             w2, w1, w13
    //     0xc1296c: add             x13, fp, w2, sxtw #2
    //     0xc12970: ldr             x13, [x13, #8]
    //     0xc12974: add             w2, w12, #2
    //     0xc12978: sbfx            x12, x2, #1, #0x1f
    //     0xc1297c: mov             x2, x12
    //     0xc12980: mov             x12, x13
    //     0xc12984: b               #0xc1298c
    //     0xc12988: mov             x12, NULL
    //     0xc1298c: stur            x12, [fp, #-0x70]
    //     0xc12990: lsl             x13, x2, #1
    //     0xc12994: lsl             w14, w13, #1
    //     0xc12998: add             w19, w14, #8
    //     0xc1299c: add             x16, x0, w19, sxtw #1
    //     0xc129a0: ldur            w20, [x16, #0xf]
    //     0xc129a4: add             x20, x20, HEAP, lsl #32
    //     0xc129a8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff68] "iconSize"
    //     0xc129ac: ldr             x16, [x16, #0xf68]
    //     0xc129b0: cmp             w20, w16
    //     0xc129b4: b.ne            #0xc129e8
    //     0xc129b8: add             w2, w14, #0xa
    //     0xc129bc: add             x16, x0, w2, sxtw #1
    //     0xc129c0: ldur            w14, [x16, #0xf]
    //     0xc129c4: add             x14, x14, HEAP, lsl #32
    //     0xc129c8: sub             w2, w1, w14
    //     0xc129cc: add             x14, fp, w2, sxtw #2
    //     0xc129d0: ldr             x14, [x14, #8]
    //     0xc129d4: add             w2, w13, #2
    //     0xc129d8: sbfx            x13, x2, #1, #0x1f
    //     0xc129dc: mov             x2, x13
    //     0xc129e0: mov             x13, x14
    //     0xc129e4: b               #0xc129ec
    //     0xc129e8: mov             x13, NULL
    //     0xc129ec: stur            x13, [fp, #-0x68]
    //     0xc129f0: lsl             x14, x2, #1
    //     0xc129f4: lsl             w19, w14, #1
    //     0xc129f8: add             w20, w19, #8
    //     0xc129fc: add             x16, x0, w20, sxtw #1
    //     0xc12a00: ldur            w23, [x16, #0xf]
    //     0xc12a04: add             x23, x23, HEAP, lsl #32
    //     0xc12a08: add             x16, PP, #0x26, lsl #12  ; [pp+0x26890] "maximumSize"
    //     0xc12a0c: ldr             x16, [x16, #0x890]
    //     0xc12a10: cmp             w23, w16
    //     0xc12a14: b.ne            #0xc12a48
    //     0xc12a18: add             w2, w19, #0xa
    //     0xc12a1c: add             x16, x0, w2, sxtw #1
    //     0xc12a20: ldur            w19, [x16, #0xf]
    //     0xc12a24: add             x19, x19, HEAP, lsl #32
    //     0xc12a28: sub             w2, w1, w19
    //     0xc12a2c: add             x19, fp, w2, sxtw #2
    //     0xc12a30: ldr             x19, [x19, #8]
    //     0xc12a34: add             w2, w14, #2
    //     0xc12a38: sbfx            x14, x2, #1, #0x1f
    //     0xc12a3c: mov             x2, x14
    //     0xc12a40: mov             x14, x19
    //     0xc12a44: b               #0xc12a4c
    //     0xc12a48: mov             x14, NULL
    //     0xc12a4c: stur            x14, [fp, #-0x60]
    //     0xc12a50: lsl             x19, x2, #1
    //     0xc12a54: lsl             w20, w19, #1
    //     0xc12a58: add             w23, w20, #8
    //     0xc12a5c: add             x16, x0, w23, sxtw #1
    //     0xc12a60: ldur            w24, [x16, #0xf]
    //     0xc12a64: add             x24, x24, HEAP, lsl #32
    //     0xc12a68: add             x16, PP, #0x26, lsl #12  ; [pp+0x26898] "minimumSize"
    //     0xc12a6c: ldr             x16, [x16, #0x898]
    //     0xc12a70: cmp             w24, w16
    //     0xc12a74: b.ne            #0xc12aa8
    //     0xc12a78: add             w2, w20, #0xa
    //     0xc12a7c: add             x16, x0, w2, sxtw #1
    //     0xc12a80: ldur            w20, [x16, #0xf]
    //     0xc12a84: add             x20, x20, HEAP, lsl #32
    //     0xc12a88: sub             w2, w1, w20
    //     0xc12a8c: add             x20, fp, w2, sxtw #2
    //     0xc12a90: ldr             x20, [x20, #8]
    //     0xc12a94: add             w2, w19, #2
    //     0xc12a98: sbfx            x19, x2, #1, #0x1f
    //     0xc12a9c: mov             x2, x19
    //     0xc12aa0: mov             x19, x20
    //     0xc12aa4: b               #0xc12aac
    //     0xc12aa8: mov             x19, NULL
    //     0xc12aac: stur            x19, [fp, #-0x58]
    //     0xc12ab0: lsl             x20, x2, #1
    //     0xc12ab4: lsl             w23, w20, #1
    //     0xc12ab8: add             w24, w23, #8
    //     0xc12abc: add             x16, x0, w24, sxtw #1
    //     0xc12ac0: ldur            w25, [x16, #0xf]
    //     0xc12ac4: add             x25, x25, HEAP, lsl #32
    //     0xc12ac8: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2df08] "mouseCursor"
    //     0xc12acc: ldr             x16, [x16, #0xf08]
    //     0xc12ad0: cmp             w25, w16
    //     0xc12ad4: b.ne            #0xc12b08
    //     0xc12ad8: add             w2, w23, #0xa
    //     0xc12adc: add             x16, x0, w2, sxtw #1
    //     0xc12ae0: ldur            w23, [x16, #0xf]
    //     0xc12ae4: add             x23, x23, HEAP, lsl #32
    //     0xc12ae8: sub             w2, w1, w23
    //     0xc12aec: add             x23, fp, w2, sxtw #2
    //     0xc12af0: ldr             x23, [x23, #8]
    //     0xc12af4: add             w2, w20, #2
    //     0xc12af8: sbfx            x20, x2, #1, #0x1f
    //     0xc12afc: mov             x2, x20
    //     0xc12b00: mov             x20, x23
    //     0xc12b04: b               #0xc12b0c
    //     0xc12b08: mov             x20, NULL
    //     0xc12b0c: stur            x20, [fp, #-0x50]
    //     0xc12b10: lsl             x23, x2, #1
    //     0xc12b14: lsl             w24, w23, #1
    //     0xc12b18: add             w25, w24, #8
    //     0xc12b1c: add             x16, x0, w25, sxtw #1
    //     0xc12b20: ldur            w4, [x16, #0xf]
    //     0xc12b24: add             x4, x4, HEAP, lsl #32
    //     0xc12b28: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff70] "overlayColor"
    //     0xc12b2c: ldr             x16, [x16, #0xf70]
    //     0xc12b30: cmp             w4, w16
    //     0xc12b34: b.ne            #0xc12b64
    //     0xc12b38: add             w2, w24, #0xa
    //     0xc12b3c: add             x16, x0, w2, sxtw #1
    //     0xc12b40: ldur            w4, [x16, #0xf]
    //     0xc12b44: add             x4, x4, HEAP, lsl #32
    //     0xc12b48: sub             w2, w1, w4
    //     0xc12b4c: add             x4, fp, w2, sxtw #2
    //     0xc12b50: ldr             x4, [x4, #8]
    //     0xc12b54: add             w2, w23, #2
    //     0xc12b58: sbfx            x23, x2, #1, #0x1f
    //     0xc12b5c: mov             x2, x23
    //     0xc12b60: b               #0xc12b68
    //     0xc12b64: mov             x4, NULL
    //     0xc12b68: stur            x4, [fp, #-0x10]
    //     0xc12b6c: lsl             x23, x2, #1
    //     0xc12b70: lsl             w24, w23, #1
    //     0xc12b74: add             w25, w24, #8
    //     0xc12b78: add             x16, x0, w25, sxtw #1
    //     0xc12b7c: ldur            w4, [x16, #0xf]
    //     0xc12b80: add             x4, x4, HEAP, lsl #32
    //     0xc12b84: add             x16, PP, #0xc, lsl #12  ; [pp+0xce60] "shadowColor"
    //     0xc12b88: ldr             x16, [x16, #0xe60]
    //     0xc12b8c: cmp             w4, w16
    //     0xc12b90: b.ne            #0xc12bc0
    //     0xc12b94: add             w2, w24, #0xa
    //     0xc12b98: add             x16, x0, w2, sxtw #1
    //     0xc12b9c: ldur            w4, [x16, #0xf]
    //     0xc12ba0: add             x4, x4, HEAP, lsl #32
    //     0xc12ba4: sub             w2, w1, w4
    //     0xc12ba8: add             x4, fp, w2, sxtw #2
    //     0xc12bac: ldr             x4, [x4, #8]
    //     0xc12bb0: add             w2, w23, #2
    //     0xc12bb4: sbfx            x23, x2, #1, #0x1f
    //     0xc12bb8: mov             x2, x23
    //     0xc12bbc: b               #0xc12bc4
    //     0xc12bc0: mov             x4, NULL
    //     0xc12bc4: stur            x4, [fp, #-0x18]
    //     0xc12bc8: lsl             x23, x2, #1
    //     0xc12bcc: lsl             w24, w23, #1
    //     0xc12bd0: add             w25, w24, #8
    //     0xc12bd4: add             x16, x0, w25, sxtw #1
    //     0xc12bd8: ldur            w4, [x16, #0xf]
    //     0xc12bdc: add             x4, x4, HEAP, lsl #32
    //     0xc12be0: add             x16, PP, #0x28, lsl #12  ; [pp+0x286f0] "shape"
    //     0xc12be4: ldr             x16, [x16, #0x6f0]
    //     0xc12be8: cmp             w4, w16
    //     0xc12bec: b.ne            #0xc12c1c
    //     0xc12bf0: add             w2, w24, #0xa
    //     0xc12bf4: add             x16, x0, w2, sxtw #1
    //     0xc12bf8: ldur            w4, [x16, #0xf]
    //     0xc12bfc: add             x4, x4, HEAP, lsl #32
    //     0xc12c00: sub             w2, w1, w4
    //     0xc12c04: add             x4, fp, w2, sxtw #2
    //     0xc12c08: ldr             x4, [x4, #8]
    //     0xc12c0c: add             w2, w23, #2
    //     0xc12c10: sbfx            x23, x2, #1, #0x1f
    //     0xc12c14: mov             x2, x23
    //     0xc12c18: b               #0xc12c20
    //     0xc12c1c: mov             x4, NULL
    //     0xc12c20: stur            x4, [fp, #-0x20]
    //     0xc12c24: lsl             x23, x2, #1
    //     0xc12c28: lsl             w24, w23, #1
    //     0xc12c2c: add             w25, w24, #8
    //     0xc12c30: add             x16, x0, w25, sxtw #1
    //     0xc12c34: ldur            w4, [x16, #0xf]
    //     0xc12c38: add             x4, x4, HEAP, lsl #32
    //     0xc12c3c: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff78] "side"
    //     0xc12c40: ldr             x16, [x16, #0xf78]
    //     0xc12c44: cmp             w4, w16
    //     0xc12c48: b.ne            #0xc12c78
    //     0xc12c4c: add             w2, w24, #0xa
    //     0xc12c50: add             x16, x0, w2, sxtw #1
    //     0xc12c54: ldur            w4, [x16, #0xf]
    //     0xc12c58: add             x4, x4, HEAP, lsl #32
    //     0xc12c5c: sub             w2, w1, w4
    //     0xc12c60: add             x4, fp, w2, sxtw #2
    //     0xc12c64: ldr             x4, [x4, #8]
    //     0xc12c68: add             w2, w23, #2
    //     0xc12c6c: sbfx            x23, x2, #1, #0x1f
    //     0xc12c70: mov             x2, x23
    //     0xc12c74: b               #0xc12c7c
    //     0xc12c78: mov             x4, NULL
    //     0xc12c7c: stur            x4, [fp, #-0x28]
    //     0xc12c80: lsl             x23, x2, #1
    //     0xc12c84: lsl             w24, w23, #1
    //     0xc12c88: add             w25, w24, #8
    //     0xc12c8c: add             x16, x0, w25, sxtw #1
    //     0xc12c90: ldur            w4, [x16, #0xf]
    //     0xc12c94: add             x4, x4, HEAP, lsl #32
    //     0xc12c98: add             x16, PP, #0xc, lsl #12  ; [pp+0xce80] "splashFactory"
    //     0xc12c9c: ldr             x16, [x16, #0xe80]
    //     0xc12ca0: cmp             w4, w16
    //     0xc12ca4: b.ne            #0xc12cd4
    //     0xc12ca8: add             w2, w24, #0xa
    //     0xc12cac: add             x16, x0, w2, sxtw #1
    //     0xc12cb0: ldur            w4, [x16, #0xf]
    //     0xc12cb4: add             x4, x4, HEAP, lsl #32
    //     0xc12cb8: sub             w2, w1, w4
    //     0xc12cbc: add             x4, fp, w2, sxtw #2
    //     0xc12cc0: ldr             x4, [x4, #8]
    //     0xc12cc4: add             w2, w23, #2
    //     0xc12cc8: sbfx            x23, x2, #1, #0x1f
    //     0xc12ccc: mov             x2, x23
    //     0xc12cd0: b               #0xc12cd8
    //     0xc12cd4: mov             x4, NULL
    //     0xc12cd8: stur            x4, [fp, #-0x30]
    //     0xc12cdc: lsl             x23, x2, #1
    //     0xc12ce0: lsl             w24, w23, #1
    //     0xc12ce4: add             w25, w24, #8
    //     0xc12ce8: add             x16, x0, w25, sxtw #1
    //     0xc12cec: ldur            w4, [x16, #0xf]
    //     0xc12cf0: add             x4, x4, HEAP, lsl #32
    //     0xc12cf4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff80] "surfaceTintColor"
    //     0xc12cf8: ldr             x16, [x16, #0xf80]
    //     0xc12cfc: cmp             w4, w16
    //     0xc12d00: b.ne            #0xc12d30
    //     0xc12d04: add             w2, w24, #0xa
    //     0xc12d08: add             x16, x0, w2, sxtw #1
    //     0xc12d0c: ldur            w4, [x16, #0xf]
    //     0xc12d10: add             x4, x4, HEAP, lsl #32
    //     0xc12d14: sub             w2, w1, w4
    //     0xc12d18: add             x4, fp, w2, sxtw #2
    //     0xc12d1c: ldr             x4, [x4, #8]
    //     0xc12d20: add             w2, w23, #2
    //     0xc12d24: sbfx            x23, x2, #1, #0x1f
    //     0xc12d28: mov             x2, x23
    //     0xc12d2c: b               #0xc12d34
    //     0xc12d30: mov             x4, NULL
    //     0xc12d34: stur            x4, [fp, #-0x38]
    //     0xc12d38: lsl             x23, x2, #1
    //     0xc12d3c: lsl             w24, w23, #1
    //     0xc12d40: add             w25, w24, #8
    //     0xc12d44: add             x16, x0, w25, sxtw #1
    //     0xc12d48: ldur            w4, [x16, #0xf]
    //     0xc12d4c: add             x4, x4, HEAP, lsl #32
    //     0xc12d50: add             x16, PP, #0x26, lsl #12  ; [pp+0x268a0] "tapTargetSize"
    //     0xc12d54: ldr             x16, [x16, #0x8a0]
    //     0xc12d58: cmp             w4, w16
    //     0xc12d5c: b.ne            #0xc12d8c
    //     0xc12d60: add             w2, w24, #0xa
    //     0xc12d64: add             x16, x0, w2, sxtw #1
    //     0xc12d68: ldur            w4, [x16, #0xf]
    //     0xc12d6c: add             x4, x4, HEAP, lsl #32
    //     0xc12d70: sub             w2, w1, w4
    //     0xc12d74: add             x4, fp, w2, sxtw #2
    //     0xc12d78: ldr             x4, [x4, #8]
    //     0xc12d7c: add             w2, w23, #2
    //     0xc12d80: sbfx            x23, x2, #1, #0x1f
    //     0xc12d84: mov             x2, x23
    //     0xc12d88: b               #0xc12d90
    //     0xc12d8c: mov             x4, NULL
    //     0xc12d90: stur            x4, [fp, #-0x40]
    //     0xc12d94: lsl             x23, x2, #1
    //     0xc12d98: lsl             w24, w23, #1
    //     0xc12d9c: add             w25, w24, #8
    //     0xc12da0: add             x16, x0, w25, sxtw #1
    //     0xc12da4: ldur            w4, [x16, #0xf]
    //     0xc12da8: add             x4, x4, HEAP, lsl #32
    //     0xc12dac: add             x16, PP, #0x26, lsl #12  ; [pp+0x268a8] "textStyle"
    //     0xc12db0: ldr             x16, [x16, #0x8a8]
    //     0xc12db4: cmp             w4, w16
    //     0xc12db8: b.ne            #0xc12de8
    //     0xc12dbc: add             w2, w24, #0xa
    //     0xc12dc0: add             x16, x0, w2, sxtw #1
    //     0xc12dc4: ldur            w4, [x16, #0xf]
    //     0xc12dc8: add             x4, x4, HEAP, lsl #32
    //     0xc12dcc: sub             w2, w1, w4
    //     0xc12dd0: add             x4, fp, w2, sxtw #2
    //     0xc12dd4: ldr             x4, [x4, #8]
    //     0xc12dd8: add             w2, w23, #2
    //     0xc12ddc: sbfx            x23, x2, #1, #0x1f
    //     0xc12de0: mov             x2, x23
    //     0xc12de4: b               #0xc12dec
    //     0xc12de8: mov             x4, NULL
    //     0xc12dec: lsl             x23, x2, #1
    //     0xc12df0: lsl             w2, w23, #1
    //     0xc12df4: add             w23, w2, #8
    //     0xc12df8: add             x16, x0, w23, sxtw #1
    //     0xc12dfc: ldur            w24, [x16, #0xf]
    //     0xc12e00: add             x24, x24, HEAP, lsl #32
    //     0xc12e04: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b0] "visualDensity"
    //     0xc12e08: ldr             x16, [x16, #0x8b0]
    //     0xc12e0c: cmp             w24, w16
    //     0xc12e10: b.ne            #0xc12e34
    //     0xc12e14: add             w23, w2, #0xa
    //     0xc12e18: add             x16, x0, w23, sxtw #1
    //     0xc12e1c: ldur            w2, [x16, #0xf]
    //     0xc12e20: add             x2, x2, HEAP, lsl #32
    //     0xc12e24: sub             w0, w1, w2
    //     0xc12e28: add             x1, fp, w0, sxtw #2
    //     0xc12e2c: ldr             x1, [x1, #8]
    //     0xc12e30: b               #0xc12e38
    //     0xc12e34: mov             x1, NULL
    //     0xc12e38: stur            x1, [fp, #-0x48]
    // 0xc12e3c: CheckStackOverflow
    //     0xc12e3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc12e40: cmp             SP, x16
    //     0xc12e44: b.ls            #0xc133d8
    // 0xc12e48: cmp             w4, NULL
    // 0xc12e4c: b.ne            #0xc12e74
    // 0xc12e50: r0 = LoadClassIdInstr(r3)
    //     0xc12e50: ldur            x0, [x3, #-1]
    //     0xc12e54: ubfx            x0, x0, #0xc, #0x14
    // 0xc12e58: SaveReg r3
    //     0xc12e58: str             x3, [SP, #-8]!
    // 0xc12e5c: r0 = GDT[cid_x0 + -0xf5d]()
    //     0xc12e5c: sub             lr, x0, #0xf5d
    //     0xc12e60: ldr             lr, [x21, lr, lsl #3]
    //     0xc12e64: blr             lr
    // 0xc12e68: add             SP, SP, #8
    // 0xc12e6c: mov             x1, x0
    // 0xc12e70: b               #0xc12e78
    // 0xc12e74: mov             x1, x4
    // 0xc12e78: ldur            x0, [fp, #-0x98]
    // 0xc12e7c: stur            x1, [fp, #-0xb8]
    // 0xc12e80: cmp             w0, NULL
    // 0xc12e84: b.ne            #0xc12eb0
    // 0xc12e88: ldur            x2, [fp, #-0xb0]
    // 0xc12e8c: r0 = LoadClassIdInstr(r2)
    //     0xc12e8c: ldur            x0, [x2, #-1]
    //     0xc12e90: ubfx            x0, x0, #0xc, #0x14
    // 0xc12e94: SaveReg r2
    //     0xc12e94: str             x2, [SP, #-8]!
    // 0xc12e98: r0 = GDT[cid_x0 + -0xf54]()
    //     0xc12e98: sub             lr, x0, #0xf54
    //     0xc12e9c: ldr             lr, [x21, lr, lsl #3]
    //     0xc12ea0: blr             lr
    // 0xc12ea4: add             SP, SP, #8
    // 0xc12ea8: mov             x1, x0
    // 0xc12eac: b               #0xc12eb4
    // 0xc12eb0: mov             x1, x0
    // 0xc12eb4: ldur            x0, [fp, #-0x78]
    // 0xc12eb8: stur            x1, [fp, #-0x98]
    // 0xc12ebc: cmp             w0, NULL
    // 0xc12ec0: b.ne            #0xc12eec
    // 0xc12ec4: ldur            x2, [fp, #-0xb0]
    // 0xc12ec8: r0 = LoadClassIdInstr(r2)
    //     0xc12ec8: ldur            x0, [x2, #-1]
    //     0xc12ecc: ubfx            x0, x0, #0xc, #0x14
    // 0xc12ed0: SaveReg r2
    //     0xc12ed0: str             x2, [SP, #-8]!
    // 0xc12ed4: r0 = GDT[cid_x0 + -0xf4f]()
    //     0xc12ed4: sub             lr, x0, #0xf4f
    //     0xc12ed8: ldr             lr, [x21, lr, lsl #3]
    //     0xc12edc: blr             lr
    // 0xc12ee0: add             SP, SP, #8
    // 0xc12ee4: mov             x1, x0
    // 0xc12ee8: b               #0xc12ef0
    // 0xc12eec: mov             x1, x0
    // 0xc12ef0: ldur            x0, [fp, #-0x10]
    // 0xc12ef4: stur            x1, [fp, #-0x78]
    // 0xc12ef8: cmp             w0, NULL
    // 0xc12efc: b.ne            #0xc12f28
    // 0xc12f00: ldur            x2, [fp, #-0xb0]
    // 0xc12f04: r0 = LoadClassIdInstr(r2)
    //     0xc12f04: ldur            x0, [x2, #-1]
    //     0xc12f08: ubfx            x0, x0, #0xc, #0x14
    // 0xc12f0c: SaveReg r2
    //     0xc12f0c: str             x2, [SP, #-8]!
    // 0xc12f10: r0 = GDT[cid_x0 + -0xf1b]()
    //     0xc12f10: sub             lr, x0, #0xf1b
    //     0xc12f14: ldr             lr, [x21, lr, lsl #3]
    //     0xc12f18: blr             lr
    // 0xc12f1c: add             SP, SP, #8
    // 0xc12f20: mov             x1, x0
    // 0xc12f24: b               #0xc12f2c
    // 0xc12f28: mov             x1, x0
    // 0xc12f2c: ldur            x0, [fp, #-0x18]
    // 0xc12f30: stur            x1, [fp, #-0x10]
    // 0xc12f34: cmp             w0, NULL
    // 0xc12f38: b.ne            #0xc12f64
    // 0xc12f3c: ldur            x2, [fp, #-0xb0]
    // 0xc12f40: r0 = LoadClassIdInstr(r2)
    //     0xc12f40: ldur            x0, [x2, #-1]
    //     0xc12f44: ubfx            x0, x0, #0xc, #0x14
    // 0xc12f48: SaveReg r2
    //     0xc12f48: str             x2, [SP, #-8]!
    // 0xc12f4c: r0 = GDT[cid_x0 + -0xefb]()
    //     0xc12f4c: sub             lr, x0, #0xefb
    //     0xc12f50: ldr             lr, [x21, lr, lsl #3]
    //     0xc12f54: blr             lr
    // 0xc12f58: add             SP, SP, #8
    // 0xc12f5c: mov             x1, x0
    // 0xc12f60: b               #0xc12f68
    // 0xc12f64: mov             x1, x0
    // 0xc12f68: ldur            x0, [fp, #-0x38]
    // 0xc12f6c: stur            x1, [fp, #-0x18]
    // 0xc12f70: cmp             w0, NULL
    // 0xc12f74: b.ne            #0xc12fa0
    // 0xc12f78: ldur            x2, [fp, #-0xb0]
    // 0xc12f7c: r0 = LoadClassIdInstr(r2)
    //     0xc12f7c: ldur            x0, [x2, #-1]
    //     0xc12f80: ubfx            x0, x0, #0xc, #0x14
    // 0xc12f84: SaveReg r2
    //     0xc12f84: str             x2, [SP, #-8]!
    // 0xc12f88: r0 = GDT[cid_x0 + -0xef6]()
    //     0xc12f88: sub             lr, x0, #0xef6
    //     0xc12f8c: ldr             lr, [x21, lr, lsl #3]
    //     0xc12f90: blr             lr
    // 0xc12f94: add             SP, SP, #8
    // 0xc12f98: mov             x1, x0
    // 0xc12f9c: b               #0xc12fa4
    // 0xc12fa0: mov             x1, x0
    // 0xc12fa4: ldur            x0, [fp, #-0x90]
    // 0xc12fa8: stur            x1, [fp, #-0x38]
    // 0xc12fac: cmp             w0, NULL
    // 0xc12fb0: b.ne            #0xc12fdc
    // 0xc12fb4: ldur            x2, [fp, #-0xb0]
    // 0xc12fb8: r0 = LoadClassIdInstr(r2)
    //     0xc12fb8: ldur            x0, [x2, #-1]
    //     0xc12fbc: ubfx            x0, x0, #0xc, #0x14
    // 0xc12fc0: SaveReg r2
    //     0xc12fc0: str             x2, [SP, #-8]!
    // 0xc12fc4: r0 = GDT[cid_x0 + -0xee9]()
    //     0xc12fc4: sub             lr, x0, #0xee9
    //     0xc12fc8: ldr             lr, [x21, lr, lsl #3]
    //     0xc12fcc: blr             lr
    // 0xc12fd0: add             SP, SP, #8
    // 0xc12fd4: mov             x1, x0
    // 0xc12fd8: b               #0xc12fe0
    // 0xc12fdc: mov             x1, x0
    // 0xc12fe0: ldur            x0, [fp, #-8]
    // 0xc12fe4: stur            x1, [fp, #-0x90]
    // 0xc12fe8: cmp             w0, NULL
    // 0xc12fec: b.ne            #0xc13018
    // 0xc12ff0: ldur            x2, [fp, #-0xb0]
    // 0xc12ff4: r0 = LoadClassIdInstr(r2)
    //     0xc12ff4: ldur            x0, [x2, #-1]
    //     0xc12ff8: ubfx            x0, x0, #0xc, #0x14
    // 0xc12ffc: SaveReg r2
    //     0xc12ffc: str             x2, [SP, #-8]!
    // 0xc13000: r0 = GDT[cid_x0 + -0xee0]()
    //     0xc13000: sub             lr, x0, #0xee0
    //     0xc13004: ldr             lr, [x21, lr, lsl #3]
    //     0xc13008: blr             lr
    // 0xc1300c: add             SP, SP, #8
    // 0xc13010: mov             x1, x0
    // 0xc13014: b               #0xc1301c
    // 0xc13018: mov             x1, x0
    // 0xc1301c: ldur            x0, [fp, #-0x58]
    // 0xc13020: stur            x1, [fp, #-8]
    // 0xc13024: cmp             w0, NULL
    // 0xc13028: b.ne            #0xc13054
    // 0xc1302c: ldur            x2, [fp, #-0xb0]
    // 0xc13030: r0 = LoadClassIdInstr(r2)
    //     0xc13030: ldur            x0, [x2, #-1]
    //     0xc13034: ubfx            x0, x0, #0xc, #0x14
    // 0xc13038: SaveReg r2
    //     0xc13038: str             x2, [SP, #-8]!
    // 0xc1303c: r0 = GDT[cid_x0 + -0xedb]()
    //     0xc1303c: sub             lr, x0, #0xedb
    //     0xc13040: ldr             lr, [x21, lr, lsl #3]
    //     0xc13044: blr             lr
    // 0xc13048: add             SP, SP, #8
    // 0xc1304c: mov             x1, x0
    // 0xc13050: b               #0xc13058
    // 0xc13054: mov             x1, x0
    // 0xc13058: ldur            x0, [fp, #-0x80]
    // 0xc1305c: stur            x1, [fp, #-0xc0]
    // 0xc13060: cmp             w0, NULL
    // 0xc13064: b.ne            #0xc1307c
    // 0xc13068: ldur            x2, [fp, #-0xb0]
    // 0xc1306c: LoadField: r0 = r2->field_2b
    //     0xc1306c: ldur            w0, [x2, #0x2b]
    // 0xc13070: DecompressPointer r0
    //     0xc13070: add             x0, x0, HEAP, lsl #32
    // 0xc13074: mov             x3, x0
    // 0xc13078: b               #0xc13084
    // 0xc1307c: ldur            x2, [fp, #-0xb0]
    // 0xc13080: mov             x3, x0
    // 0xc13084: ldur            x0, [fp, #-0x60]
    // 0xc13088: stur            x3, [fp, #-0x58]
    // 0xc1308c: cmp             w0, NULL
    // 0xc13090: b.ne            #0xc130b8
    // 0xc13094: r0 = LoadClassIdInstr(r2)
    //     0xc13094: ldur            x0, [x2, #-1]
    //     0xc13098: ubfx            x0, x0, #0xc, #0x14
    // 0xc1309c: SaveReg r2
    //     0xc1309c: str             x2, [SP, #-8]!
    // 0xc130a0: r0 = GDT[cid_x0 + -0xed4]()
    //     0xc130a0: sub             lr, x0, #0xed4
    //     0xc130a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc130a8: blr             lr
    // 0xc130ac: add             SP, SP, #8
    // 0xc130b0: mov             x1, x0
    // 0xc130b4: b               #0xc130bc
    // 0xc130b8: mov             x1, x0
    // 0xc130bc: ldur            x0, [fp, #-0x70]
    // 0xc130c0: stur            x1, [fp, #-0x80]
    // 0xc130c4: cmp             w0, NULL
    // 0xc130c8: b.ne            #0xc130e0
    // 0xc130cc: ldur            x2, [fp, #-0xb0]
    // 0xc130d0: LoadField: r0 = r2->field_33
    //     0xc130d0: ldur            w0, [x2, #0x33]
    // 0xc130d4: DecompressPointer r0
    //     0xc130d4: add             x0, x0, HEAP, lsl #32
    // 0xc130d8: mov             x3, x0
    // 0xc130dc: b               #0xc130e8
    // 0xc130e0: ldur            x2, [fp, #-0xb0]
    // 0xc130e4: mov             x3, x0
    // 0xc130e8: ldur            x0, [fp, #-0x68]
    // 0xc130ec: stur            x3, [fp, #-0x70]
    // 0xc130f0: cmp             w0, NULL
    // 0xc130f4: b.ne            #0xc13108
    // 0xc130f8: LoadField: r0 = r2->field_37
    //     0xc130f8: ldur            w0, [x2, #0x37]
    // 0xc130fc: DecompressPointer r0
    //     0xc130fc: add             x0, x0, HEAP, lsl #32
    // 0xc13100: mov             x4, x0
    // 0xc13104: b               #0xc1310c
    // 0xc13108: mov             x4, x0
    // 0xc1310c: ldur            x0, [fp, #-0x28]
    // 0xc13110: stur            x4, [fp, #-0x60]
    // 0xc13114: cmp             w0, NULL
    // 0xc13118: b.ne            #0xc1312c
    // 0xc1311c: LoadField: r0 = r2->field_3b
    //     0xc1311c: ldur            w0, [x2, #0x3b]
    // 0xc13120: DecompressPointer r0
    //     0xc13120: add             x0, x0, HEAP, lsl #32
    // 0xc13124: mov             x5, x0
    // 0xc13128: b               #0xc13130
    // 0xc1312c: mov             x5, x0
    // 0xc13130: ldur            x0, [fp, #-0x20]
    // 0xc13134: stur            x5, [fp, #-0x28]
    // 0xc13138: cmp             w0, NULL
    // 0xc1313c: b.ne            #0xc13164
    // 0xc13140: r0 = LoadClassIdInstr(r2)
    //     0xc13140: ldur            x0, [x2, #-1]
    //     0xc13144: ubfx            x0, x0, #0xc, #0x14
    // 0xc13148: SaveReg r2
    //     0xc13148: str             x2, [SP, #-8]!
    // 0xc1314c: r0 = GDT[cid_x0 + -0xec3]()
    //     0xc1314c: sub             lr, x0, #0xec3
    //     0xc13150: ldr             lr, [x21, lr, lsl #3]
    //     0xc13154: blr             lr
    // 0xc13158: add             SP, SP, #8
    // 0xc1315c: mov             x1, x0
    // 0xc13160: b               #0xc13168
    // 0xc13164: mov             x1, x0
    // 0xc13168: ldur            x0, [fp, #-0x50]
    // 0xc1316c: stur            x1, [fp, #-0x20]
    // 0xc13170: cmp             w0, NULL
    // 0xc13174: b.ne            #0xc131a0
    // 0xc13178: ldur            x2, [fp, #-0xb0]
    // 0xc1317c: r0 = LoadClassIdInstr(r2)
    //     0xc1317c: ldur            x0, [x2, #-1]
    //     0xc13180: ubfx            x0, x0, #0xc, #0x14
    // 0xc13184: SaveReg r2
    //     0xc13184: str             x2, [SP, #-8]!
    // 0xc13188: r0 = GDT[cid_x0 + -0xebb]()
    //     0xc13188: sub             lr, x0, #0xebb
    //     0xc1318c: ldr             lr, [x21, lr, lsl #3]
    //     0xc13190: blr             lr
    // 0xc13194: add             SP, SP, #8
    // 0xc13198: mov             x1, x0
    // 0xc1319c: b               #0xc131a4
    // 0xc131a0: mov             x1, x0
    // 0xc131a4: ldur            x0, [fp, #-0x48]
    // 0xc131a8: stur            x1, [fp, #-0x50]
    // 0xc131ac: cmp             w0, NULL
    // 0xc131b0: b.ne            #0xc131dc
    // 0xc131b4: ldur            x2, [fp, #-0xb0]
    // 0xc131b8: r0 = LoadClassIdInstr(r2)
    //     0xc131b8: ldur            x0, [x2, #-1]
    //     0xc131bc: ubfx            x0, x0, #0xc, #0x14
    // 0xc131c0: SaveReg r2
    //     0xc131c0: str             x2, [SP, #-8]!
    // 0xc131c4: r0 = GDT[cid_x0 + -0xeb5]()
    //     0xc131c4: sub             lr, x0, #0xeb5
    //     0xc131c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc131cc: blr             lr
    // 0xc131d0: add             SP, SP, #8
    // 0xc131d4: mov             x1, x0
    // 0xc131d8: b               #0xc131e0
    // 0xc131dc: mov             x1, x0
    // 0xc131e0: ldur            x0, [fp, #-0x40]
    // 0xc131e4: stur            x1, [fp, #-0x48]
    // 0xc131e8: cmp             w0, NULL
    // 0xc131ec: b.ne            #0xc13218
    // 0xc131f0: ldur            x2, [fp, #-0xb0]
    // 0xc131f4: r0 = LoadClassIdInstr(r2)
    //     0xc131f4: ldur            x0, [x2, #-1]
    //     0xc131f8: ubfx            x0, x0, #0xc, #0x14
    // 0xc131fc: SaveReg r2
    //     0xc131fc: str             x2, [SP, #-8]!
    // 0xc13200: r0 = GDT[cid_x0 + -0xeb0]()
    //     0xc13200: sub             lr, x0, #0xeb0
    //     0xc13204: ldr             lr, [x21, lr, lsl #3]
    //     0xc13208: blr             lr
    // 0xc1320c: add             SP, SP, #8
    // 0xc13210: mov             x1, x0
    // 0xc13214: b               #0xc1321c
    // 0xc13218: mov             x1, x0
    // 0xc1321c: ldur            x0, [fp, #-0xa0]
    // 0xc13220: stur            x1, [fp, #-0xc8]
    // 0xc13224: cmp             w0, NULL
    // 0xc13228: b.ne            #0xc13240
    // 0xc1322c: ldur            x2, [fp, #-0xb0]
    // 0xc13230: LoadField: r0 = r2->field_4f
    //     0xc13230: ldur            w0, [x2, #0x4f]
    // 0xc13234: DecompressPointer r0
    //     0xc13234: add             x0, x0, HEAP, lsl #32
    // 0xc13238: mov             x3, x0
    // 0xc1323c: b               #0xc13248
    // 0xc13240: ldur            x2, [fp, #-0xb0]
    // 0xc13244: mov             x3, x0
    // 0xc13248: ldur            x0, [fp, #-0x88]
    // 0xc1324c: stur            x3, [fp, #-0xa0]
    // 0xc13250: cmp             w0, NULL
    // 0xc13254: b.ne            #0xc13268
    // 0xc13258: LoadField: r0 = r2->field_53
    //     0xc13258: ldur            w0, [x2, #0x53]
    // 0xc1325c: DecompressPointer r0
    //     0xc1325c: add             x0, x0, HEAP, lsl #32
    // 0xc13260: mov             x4, x0
    // 0xc13264: b               #0xc1326c
    // 0xc13268: mov             x4, x0
    // 0xc1326c: ldur            x0, [fp, #-0xa8]
    // 0xc13270: stur            x4, [fp, #-0x68]
    // 0xc13274: cmp             w0, NULL
    // 0xc13278: b.ne            #0xc1328c
    // 0xc1327c: LoadField: r0 = r2->field_57
    //     0xc1327c: ldur            w0, [x2, #0x57]
    // 0xc13280: DecompressPointer r0
    //     0xc13280: add             x0, x0, HEAP, lsl #32
    // 0xc13284: mov             x5, x0
    // 0xc13288: b               #0xc13290
    // 0xc1328c: mov             x5, x0
    // 0xc13290: ldur            x0, [fp, #-0x30]
    // 0xc13294: stur            x5, [fp, #-0x40]
    // 0xc13298: cmp             w0, NULL
    // 0xc1329c: b.ne            #0xc132c4
    // 0xc132a0: r0 = LoadClassIdInstr(r2)
    //     0xc132a0: ldur            x0, [x2, #-1]
    //     0xc132a4: ubfx            x0, x0, #0xc, #0x14
    // 0xc132a8: SaveReg r2
    //     0xc132a8: str             x2, [SP, #-8]!
    // 0xc132ac: r0 = GDT[cid_x0 + -0xe82]()
    //     0xc132ac: sub             lr, x0, #0xe82
    //     0xc132b0: ldr             lr, [x21, lr, lsl #3]
    //     0xc132b4: blr             lr
    // 0xc132b8: add             SP, SP, #8
    // 0xc132bc: stur            x0, [fp, #-0x30]
    // 0xc132c0: b               #0xc132c8
    // 0xc132c4: stur            x0, [fp, #-0x30]
    // 0xc132c8: ldur            x25, [fp, #-0x98]
    // 0xc132cc: ldur            x24, [fp, #-0x78]
    // 0xc132d0: ldur            x23, [fp, #-0x10]
    // 0xc132d4: ldur            x20, [fp, #-0x18]
    // 0xc132d8: ldur            x19, [fp, #-0x38]
    // 0xc132dc: ldur            x14, [fp, #-0x90]
    // 0xc132e0: ldur            x13, [fp, #-8]
    // 0xc132e4: ldur            x11, [fp, #-0xc0]
    // 0xc132e8: ldur            x12, [fp, #-0x58]
    // 0xc132ec: ldur            x7, [fp, #-0x80]
    // 0xc132f0: ldur            x8, [fp, #-0x70]
    // 0xc132f4: ldur            x9, [fp, #-0x60]
    // 0xc132f8: ldur            x10, [fp, #-0x28]
    // 0xc132fc: ldur            x6, [fp, #-0x20]
    // 0xc13300: ldur            x5, [fp, #-0x50]
    // 0xc13304: ldur            x4, [fp, #-0x48]
    // 0xc13308: ldur            x0, [fp, #-0xc8]
    // 0xc1330c: ldur            x1, [fp, #-0xa0]
    // 0xc13310: ldur            x2, [fp, #-0x68]
    // 0xc13314: ldur            x3, [fp, #-0x40]
    // 0xc13318: r0 = ButtonStyle()
    //     0xc13318: bl              #0x9173f0  ; AllocateButtonStyleStub -> ButtonStyle (size=0x60)
    // 0xc1331c: ldur            x1, [fp, #-0xb8]
    // 0xc13320: StoreField: r0->field_7 = r1
    //     0xc13320: stur            w1, [x0, #7]
    // 0xc13324: ldur            x1, [fp, #-0x98]
    // 0xc13328: StoreField: r0->field_b = r1
    //     0xc13328: stur            w1, [x0, #0xb]
    // 0xc1332c: ldur            x1, [fp, #-0x78]
    // 0xc13330: StoreField: r0->field_f = r1
    //     0xc13330: stur            w1, [x0, #0xf]
    // 0xc13334: ldur            x1, [fp, #-0x10]
    // 0xc13338: StoreField: r0->field_13 = r1
    //     0xc13338: stur            w1, [x0, #0x13]
    // 0xc1333c: ldur            x1, [fp, #-0x18]
    // 0xc13340: StoreField: r0->field_17 = r1
    //     0xc13340: stur            w1, [x0, #0x17]
    // 0xc13344: ldur            x1, [fp, #-0x38]
    // 0xc13348: StoreField: r0->field_1b = r1
    //     0xc13348: stur            w1, [x0, #0x1b]
    // 0xc1334c: ldur            x1, [fp, #-0x90]
    // 0xc13350: StoreField: r0->field_1f = r1
    //     0xc13350: stur            w1, [x0, #0x1f]
    // 0xc13354: ldur            x1, [fp, #-8]
    // 0xc13358: StoreField: r0->field_23 = r1
    //     0xc13358: stur            w1, [x0, #0x23]
    // 0xc1335c: ldur            x1, [fp, #-0xc0]
    // 0xc13360: StoreField: r0->field_27 = r1
    //     0xc13360: stur            w1, [x0, #0x27]
    // 0xc13364: ldur            x1, [fp, #-0x58]
    // 0xc13368: StoreField: r0->field_2b = r1
    //     0xc13368: stur            w1, [x0, #0x2b]
    // 0xc1336c: ldur            x1, [fp, #-0x80]
    // 0xc13370: StoreField: r0->field_2f = r1
    //     0xc13370: stur            w1, [x0, #0x2f]
    // 0xc13374: ldur            x1, [fp, #-0x70]
    // 0xc13378: StoreField: r0->field_33 = r1
    //     0xc13378: stur            w1, [x0, #0x33]
    // 0xc1337c: ldur            x1, [fp, #-0x60]
    // 0xc13380: StoreField: r0->field_37 = r1
    //     0xc13380: stur            w1, [x0, #0x37]
    // 0xc13384: ldur            x1, [fp, #-0x28]
    // 0xc13388: StoreField: r0->field_3b = r1
    //     0xc13388: stur            w1, [x0, #0x3b]
    // 0xc1338c: ldur            x1, [fp, #-0x20]
    // 0xc13390: StoreField: r0->field_3f = r1
    //     0xc13390: stur            w1, [x0, #0x3f]
    // 0xc13394: ldur            x1, [fp, #-0x50]
    // 0xc13398: StoreField: r0->field_43 = r1
    //     0xc13398: stur            w1, [x0, #0x43]
    // 0xc1339c: ldur            x1, [fp, #-0x48]
    // 0xc133a0: StoreField: r0->field_47 = r1
    //     0xc133a0: stur            w1, [x0, #0x47]
    // 0xc133a4: ldur            x1, [fp, #-0xc8]
    // 0xc133a8: StoreField: r0->field_4b = r1
    //     0xc133a8: stur            w1, [x0, #0x4b]
    // 0xc133ac: ldur            x1, [fp, #-0xa0]
    // 0xc133b0: StoreField: r0->field_4f = r1
    //     0xc133b0: stur            w1, [x0, #0x4f]
    // 0xc133b4: ldur            x1, [fp, #-0x68]
    // 0xc133b8: StoreField: r0->field_53 = r1
    //     0xc133b8: stur            w1, [x0, #0x53]
    // 0xc133bc: ldur            x1, [fp, #-0x40]
    // 0xc133c0: StoreField: r0->field_57 = r1
    //     0xc133c0: stur            w1, [x0, #0x57]
    // 0xc133c4: ldur            x1, [fp, #-0x30]
    // 0xc133c8: StoreField: r0->field_5b = r1
    //     0xc133c8: stur            w1, [x0, #0x5b]
    // 0xc133cc: LeaveFrame
    //     0xc133cc: mov             SP, fp
    //     0xc133d0: ldp             fp, lr, [SP], #0x10
    // 0xc133d4: ret
    //     0xc133d4: ret             
    // 0xc133d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc133d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc133dc: b               #0xc12e48
  }
  _ ==(/* No info */) {
    // ** addr: 0xc83e7c, size: 0xac4
    // 0xc83e7c: EnterFrame
    //     0xc83e7c: stp             fp, lr, [SP, #-0x10]!
    //     0xc83e80: mov             fp, SP
    // 0xc83e84: AllocStack(0x10)
    //     0xc83e84: sub             SP, SP, #0x10
    // 0xc83e88: CheckStackOverflow
    //     0xc83e88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc83e8c: cmp             SP, x16
    //     0xc83e90: b.ls            #0xc84938
    // 0xc83e94: ldr             x1, [fp, #0x10]
    // 0xc83e98: cmp             w1, NULL
    // 0xc83e9c: b.ne            #0xc83eb0
    // 0xc83ea0: r0 = false
    //     0xc83ea0: add             x0, NULL, #0x30  ; false
    // 0xc83ea4: LeaveFrame
    //     0xc83ea4: mov             SP, fp
    //     0xc83ea8: ldp             fp, lr, [SP], #0x10
    // 0xc83eac: ret
    //     0xc83eac: ret             
    // 0xc83eb0: ldr             x2, [fp, #0x18]
    // 0xc83eb4: cmp             w2, w1
    // 0xc83eb8: b.ne            #0xc83ecc
    // 0xc83ebc: r0 = true
    //     0xc83ebc: add             x0, NULL, #0x20  ; true
    // 0xc83ec0: LeaveFrame
    //     0xc83ec0: mov             SP, fp
    //     0xc83ec4: ldp             fp, lr, [SP], #0x10
    // 0xc83ec8: ret
    //     0xc83ec8: ret             
    // 0xc83ecc: r0 = 59
    //     0xc83ecc: mov             x0, #0x3b
    // 0xc83ed0: branchIfSmi(r1, 0xc83edc)
    //     0xc83ed0: tbz             w1, #0, #0xc83edc
    // 0xc83ed4: r0 = LoadClassIdInstr(r1)
    //     0xc83ed4: ldur            x0, [x1, #-1]
    //     0xc83ed8: ubfx            x0, x0, #0xc, #0x14
    // 0xc83edc: SaveReg r1
    //     0xc83edc: str             x1, [SP, #-8]!
    // 0xc83ee0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc83ee0: mov             x17, #0x57c5
    //     0xc83ee4: add             lr, x0, x17
    //     0xc83ee8: ldr             lr, [x21, lr, lsl #3]
    //     0xc83eec: blr             lr
    // 0xc83ef0: add             SP, SP, #8
    // 0xc83ef4: stur            x0, [fp, #-8]
    // 0xc83ef8: ldr             x16, [fp, #0x18]
    // 0xc83efc: SaveReg r16
    //     0xc83efc: str             x16, [SP, #-8]!
    // 0xc83f00: r0 = runtimeType()
    //     0xc83f00: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc83f04: add             SP, SP, #8
    // 0xc83f08: mov             x1, x0
    // 0xc83f0c: ldur            x0, [fp, #-8]
    // 0xc83f10: r2 = LoadClassIdInstr(r0)
    //     0xc83f10: ldur            x2, [x0, #-1]
    //     0xc83f14: ubfx            x2, x2, #0xc, #0x14
    // 0xc83f18: stp             x1, x0, [SP, #-0x10]!
    // 0xc83f1c: mov             x0, x2
    // 0xc83f20: mov             lr, x0
    // 0xc83f24: ldr             lr, [x21, lr, lsl #3]
    // 0xc83f28: blr             lr
    // 0xc83f2c: add             SP, SP, #0x10
    // 0xc83f30: tbz             w0, #4, #0xc83f44
    // 0xc83f34: r0 = false
    //     0xc83f34: add             x0, NULL, #0x30  ; false
    // 0xc83f38: LeaveFrame
    //     0xc83f38: mov             SP, fp
    //     0xc83f3c: ldp             fp, lr, [SP], #0x10
    // 0xc83f40: ret
    //     0xc83f40: ret             
    // 0xc83f44: ldr             x1, [fp, #0x10]
    // 0xc83f48: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc83f48: mov             x2, #0x76
    //     0xc83f4c: tbz             w1, #0, #0xc83f5c
    //     0xc83f50: ldur            x2, [x1, #-1]
    //     0xc83f54: ubfx            x2, x2, #0xc, #0x14
    //     0xc83f58: lsl             x2, x2, #1
    // 0xc83f5c: stur            x2, [fp, #-8]
    // 0xc83f60: r0 = LoadInt32Instr(r2)
    //     0xc83f60: sbfx            x0, x2, #1, #0x1f
    // 0xc83f64: cmp             x0, #0xb0d
    // 0xc83f68: b.lt            #0xc84928
    // 0xc83f6c: cmp             x0, #0xb11
    // 0xc83f70: b.gt            #0xc84928
    // 0xc83f74: ldr             x3, [fp, #0x18]
    // 0xc83f78: r0 = LoadClassIdInstr(r1)
    //     0xc83f78: ldur            x0, [x1, #-1]
    //     0xc83f7c: ubfx            x0, x0, #0xc, #0x14
    // 0xc83f80: SaveReg r1
    //     0xc83f80: str             x1, [SP, #-8]!
    // 0xc83f84: r0 = GDT[cid_x0 + -0xf5d]()
    //     0xc83f84: sub             lr, x0, #0xf5d
    //     0xc83f88: ldr             lr, [x21, lr, lsl #3]
    //     0xc83f8c: blr             lr
    // 0xc83f90: add             SP, SP, #8
    // 0xc83f94: mov             x2, x0
    // 0xc83f98: ldr             x1, [fp, #0x18]
    // 0xc83f9c: stur            x2, [fp, #-0x10]
    // 0xc83fa0: r0 = LoadClassIdInstr(r1)
    //     0xc83fa0: ldur            x0, [x1, #-1]
    //     0xc83fa4: ubfx            x0, x0, #0xc, #0x14
    // 0xc83fa8: SaveReg r1
    //     0xc83fa8: str             x1, [SP, #-8]!
    // 0xc83fac: r0 = GDT[cid_x0 + -0xf5d]()
    //     0xc83fac: sub             lr, x0, #0xf5d
    //     0xc83fb0: ldr             lr, [x21, lr, lsl #3]
    //     0xc83fb4: blr             lr
    // 0xc83fb8: add             SP, SP, #8
    // 0xc83fbc: mov             x1, x0
    // 0xc83fc0: ldur            x0, [fp, #-0x10]
    // 0xc83fc4: r2 = LoadClassIdInstr(r0)
    //     0xc83fc4: ldur            x2, [x0, #-1]
    //     0xc83fc8: ubfx            x2, x2, #0xc, #0x14
    // 0xc83fcc: stp             x1, x0, [SP, #-0x10]!
    // 0xc83fd0: mov             x0, x2
    // 0xc83fd4: mov             lr, x0
    // 0xc83fd8: ldr             lr, [x21, lr, lsl #3]
    // 0xc83fdc: blr             lr
    // 0xc83fe0: add             SP, SP, #0x10
    // 0xc83fe4: tbnz            w0, #4, #0xc84928
    // 0xc83fe8: ldr             x1, [fp, #0x18]
    // 0xc83fec: ldr             x2, [fp, #0x10]
    // 0xc83ff0: r0 = LoadClassIdInstr(r2)
    //     0xc83ff0: ldur            x0, [x2, #-1]
    //     0xc83ff4: ubfx            x0, x0, #0xc, #0x14
    // 0xc83ff8: SaveReg r2
    //     0xc83ff8: str             x2, [SP, #-8]!
    // 0xc83ffc: r0 = GDT[cid_x0 + -0xf54]()
    //     0xc83ffc: sub             lr, x0, #0xf54
    //     0xc84000: ldr             lr, [x21, lr, lsl #3]
    //     0xc84004: blr             lr
    // 0xc84008: add             SP, SP, #8
    // 0xc8400c: mov             x2, x0
    // 0xc84010: ldr             x1, [fp, #0x18]
    // 0xc84014: stur            x2, [fp, #-0x10]
    // 0xc84018: r0 = LoadClassIdInstr(r1)
    //     0xc84018: ldur            x0, [x1, #-1]
    //     0xc8401c: ubfx            x0, x0, #0xc, #0x14
    // 0xc84020: SaveReg r1
    //     0xc84020: str             x1, [SP, #-8]!
    // 0xc84024: r0 = GDT[cid_x0 + -0xf54]()
    //     0xc84024: sub             lr, x0, #0xf54
    //     0xc84028: ldr             lr, [x21, lr, lsl #3]
    //     0xc8402c: blr             lr
    // 0xc84030: add             SP, SP, #8
    // 0xc84034: mov             x1, x0
    // 0xc84038: ldur            x0, [fp, #-0x10]
    // 0xc8403c: r2 = LoadClassIdInstr(r0)
    //     0xc8403c: ldur            x2, [x0, #-1]
    //     0xc84040: ubfx            x2, x2, #0xc, #0x14
    // 0xc84044: stp             x1, x0, [SP, #-0x10]!
    // 0xc84048: mov             x0, x2
    // 0xc8404c: mov             lr, x0
    // 0xc84050: ldr             lr, [x21, lr, lsl #3]
    // 0xc84054: blr             lr
    // 0xc84058: add             SP, SP, #0x10
    // 0xc8405c: tbnz            w0, #4, #0xc84928
    // 0xc84060: ldr             x1, [fp, #0x18]
    // 0xc84064: ldr             x2, [fp, #0x10]
    // 0xc84068: r0 = LoadClassIdInstr(r2)
    //     0xc84068: ldur            x0, [x2, #-1]
    //     0xc8406c: ubfx            x0, x0, #0xc, #0x14
    // 0xc84070: SaveReg r2
    //     0xc84070: str             x2, [SP, #-8]!
    // 0xc84074: r0 = GDT[cid_x0 + -0xf4f]()
    //     0xc84074: sub             lr, x0, #0xf4f
    //     0xc84078: ldr             lr, [x21, lr, lsl #3]
    //     0xc8407c: blr             lr
    // 0xc84080: add             SP, SP, #8
    // 0xc84084: mov             x2, x0
    // 0xc84088: ldr             x1, [fp, #0x18]
    // 0xc8408c: stur            x2, [fp, #-0x10]
    // 0xc84090: r0 = LoadClassIdInstr(r1)
    //     0xc84090: ldur            x0, [x1, #-1]
    //     0xc84094: ubfx            x0, x0, #0xc, #0x14
    // 0xc84098: SaveReg r1
    //     0xc84098: str             x1, [SP, #-8]!
    // 0xc8409c: r0 = GDT[cid_x0 + -0xf4f]()
    //     0xc8409c: sub             lr, x0, #0xf4f
    //     0xc840a0: ldr             lr, [x21, lr, lsl #3]
    //     0xc840a4: blr             lr
    // 0xc840a8: add             SP, SP, #8
    // 0xc840ac: mov             x1, x0
    // 0xc840b0: ldur            x0, [fp, #-0x10]
    // 0xc840b4: r2 = LoadClassIdInstr(r0)
    //     0xc840b4: ldur            x2, [x0, #-1]
    //     0xc840b8: ubfx            x2, x2, #0xc, #0x14
    // 0xc840bc: stp             x1, x0, [SP, #-0x10]!
    // 0xc840c0: mov             x0, x2
    // 0xc840c4: mov             lr, x0
    // 0xc840c8: ldr             lr, [x21, lr, lsl #3]
    // 0xc840cc: blr             lr
    // 0xc840d0: add             SP, SP, #0x10
    // 0xc840d4: tbnz            w0, #4, #0xc84928
    // 0xc840d8: ldr             x1, [fp, #0x18]
    // 0xc840dc: ldr             x2, [fp, #0x10]
    // 0xc840e0: r0 = LoadClassIdInstr(r2)
    //     0xc840e0: ldur            x0, [x2, #-1]
    //     0xc840e4: ubfx            x0, x0, #0xc, #0x14
    // 0xc840e8: SaveReg r2
    //     0xc840e8: str             x2, [SP, #-8]!
    // 0xc840ec: r0 = GDT[cid_x0 + -0xf1b]()
    //     0xc840ec: sub             lr, x0, #0xf1b
    //     0xc840f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc840f4: blr             lr
    // 0xc840f8: add             SP, SP, #8
    // 0xc840fc: mov             x2, x0
    // 0xc84100: ldr             x1, [fp, #0x18]
    // 0xc84104: stur            x2, [fp, #-0x10]
    // 0xc84108: r0 = LoadClassIdInstr(r1)
    //     0xc84108: ldur            x0, [x1, #-1]
    //     0xc8410c: ubfx            x0, x0, #0xc, #0x14
    // 0xc84110: SaveReg r1
    //     0xc84110: str             x1, [SP, #-8]!
    // 0xc84114: r0 = GDT[cid_x0 + -0xf1b]()
    //     0xc84114: sub             lr, x0, #0xf1b
    //     0xc84118: ldr             lr, [x21, lr, lsl #3]
    //     0xc8411c: blr             lr
    // 0xc84120: add             SP, SP, #8
    // 0xc84124: mov             x1, x0
    // 0xc84128: ldur            x0, [fp, #-0x10]
    // 0xc8412c: r2 = LoadClassIdInstr(r0)
    //     0xc8412c: ldur            x2, [x0, #-1]
    //     0xc84130: ubfx            x2, x2, #0xc, #0x14
    // 0xc84134: stp             x1, x0, [SP, #-0x10]!
    // 0xc84138: mov             x0, x2
    // 0xc8413c: mov             lr, x0
    // 0xc84140: ldr             lr, [x21, lr, lsl #3]
    // 0xc84144: blr             lr
    // 0xc84148: add             SP, SP, #0x10
    // 0xc8414c: tbnz            w0, #4, #0xc84928
    // 0xc84150: ldr             x1, [fp, #0x18]
    // 0xc84154: ldr             x2, [fp, #0x10]
    // 0xc84158: r0 = LoadClassIdInstr(r2)
    //     0xc84158: ldur            x0, [x2, #-1]
    //     0xc8415c: ubfx            x0, x0, #0xc, #0x14
    // 0xc84160: SaveReg r2
    //     0xc84160: str             x2, [SP, #-8]!
    // 0xc84164: r0 = GDT[cid_x0 + -0xefb]()
    //     0xc84164: sub             lr, x0, #0xefb
    //     0xc84168: ldr             lr, [x21, lr, lsl #3]
    //     0xc8416c: blr             lr
    // 0xc84170: add             SP, SP, #8
    // 0xc84174: mov             x2, x0
    // 0xc84178: ldr             x1, [fp, #0x18]
    // 0xc8417c: stur            x2, [fp, #-0x10]
    // 0xc84180: r0 = LoadClassIdInstr(r1)
    //     0xc84180: ldur            x0, [x1, #-1]
    //     0xc84184: ubfx            x0, x0, #0xc, #0x14
    // 0xc84188: SaveReg r1
    //     0xc84188: str             x1, [SP, #-8]!
    // 0xc8418c: r0 = GDT[cid_x0 + -0xefb]()
    //     0xc8418c: sub             lr, x0, #0xefb
    //     0xc84190: ldr             lr, [x21, lr, lsl #3]
    //     0xc84194: blr             lr
    // 0xc84198: add             SP, SP, #8
    // 0xc8419c: mov             x1, x0
    // 0xc841a0: ldur            x0, [fp, #-0x10]
    // 0xc841a4: r2 = LoadClassIdInstr(r0)
    //     0xc841a4: ldur            x2, [x0, #-1]
    //     0xc841a8: ubfx            x2, x2, #0xc, #0x14
    // 0xc841ac: stp             x1, x0, [SP, #-0x10]!
    // 0xc841b0: mov             x0, x2
    // 0xc841b4: mov             lr, x0
    // 0xc841b8: ldr             lr, [x21, lr, lsl #3]
    // 0xc841bc: blr             lr
    // 0xc841c0: add             SP, SP, #0x10
    // 0xc841c4: tbnz            w0, #4, #0xc84928
    // 0xc841c8: ldr             x1, [fp, #0x18]
    // 0xc841cc: ldr             x2, [fp, #0x10]
    // 0xc841d0: r0 = LoadClassIdInstr(r2)
    //     0xc841d0: ldur            x0, [x2, #-1]
    //     0xc841d4: ubfx            x0, x0, #0xc, #0x14
    // 0xc841d8: SaveReg r2
    //     0xc841d8: str             x2, [SP, #-8]!
    // 0xc841dc: r0 = GDT[cid_x0 + -0xef6]()
    //     0xc841dc: sub             lr, x0, #0xef6
    //     0xc841e0: ldr             lr, [x21, lr, lsl #3]
    //     0xc841e4: blr             lr
    // 0xc841e8: add             SP, SP, #8
    // 0xc841ec: mov             x2, x0
    // 0xc841f0: ldr             x1, [fp, #0x18]
    // 0xc841f4: stur            x2, [fp, #-0x10]
    // 0xc841f8: r0 = LoadClassIdInstr(r1)
    //     0xc841f8: ldur            x0, [x1, #-1]
    //     0xc841fc: ubfx            x0, x0, #0xc, #0x14
    // 0xc84200: SaveReg r1
    //     0xc84200: str             x1, [SP, #-8]!
    // 0xc84204: r0 = GDT[cid_x0 + -0xef6]()
    //     0xc84204: sub             lr, x0, #0xef6
    //     0xc84208: ldr             lr, [x21, lr, lsl #3]
    //     0xc8420c: blr             lr
    // 0xc84210: add             SP, SP, #8
    // 0xc84214: mov             x1, x0
    // 0xc84218: ldur            x0, [fp, #-0x10]
    // 0xc8421c: r2 = LoadClassIdInstr(r0)
    //     0xc8421c: ldur            x2, [x0, #-1]
    //     0xc84220: ubfx            x2, x2, #0xc, #0x14
    // 0xc84224: stp             x1, x0, [SP, #-0x10]!
    // 0xc84228: mov             x0, x2
    // 0xc8422c: mov             lr, x0
    // 0xc84230: ldr             lr, [x21, lr, lsl #3]
    // 0xc84234: blr             lr
    // 0xc84238: add             SP, SP, #0x10
    // 0xc8423c: tbnz            w0, #4, #0xc84928
    // 0xc84240: ldr             x1, [fp, #0x18]
    // 0xc84244: ldr             x2, [fp, #0x10]
    // 0xc84248: r0 = LoadClassIdInstr(r2)
    //     0xc84248: ldur            x0, [x2, #-1]
    //     0xc8424c: ubfx            x0, x0, #0xc, #0x14
    // 0xc84250: SaveReg r2
    //     0xc84250: str             x2, [SP, #-8]!
    // 0xc84254: r0 = GDT[cid_x0 + -0xee9]()
    //     0xc84254: sub             lr, x0, #0xee9
    //     0xc84258: ldr             lr, [x21, lr, lsl #3]
    //     0xc8425c: blr             lr
    // 0xc84260: add             SP, SP, #8
    // 0xc84264: mov             x2, x0
    // 0xc84268: ldr             x1, [fp, #0x18]
    // 0xc8426c: stur            x2, [fp, #-0x10]
    // 0xc84270: r0 = LoadClassIdInstr(r1)
    //     0xc84270: ldur            x0, [x1, #-1]
    //     0xc84274: ubfx            x0, x0, #0xc, #0x14
    // 0xc84278: SaveReg r1
    //     0xc84278: str             x1, [SP, #-8]!
    // 0xc8427c: r0 = GDT[cid_x0 + -0xee9]()
    //     0xc8427c: sub             lr, x0, #0xee9
    //     0xc84280: ldr             lr, [x21, lr, lsl #3]
    //     0xc84284: blr             lr
    // 0xc84288: add             SP, SP, #8
    // 0xc8428c: mov             x1, x0
    // 0xc84290: ldur            x0, [fp, #-0x10]
    // 0xc84294: r2 = LoadClassIdInstr(r0)
    //     0xc84294: ldur            x2, [x0, #-1]
    //     0xc84298: ubfx            x2, x2, #0xc, #0x14
    // 0xc8429c: stp             x1, x0, [SP, #-0x10]!
    // 0xc842a0: mov             x0, x2
    // 0xc842a4: mov             lr, x0
    // 0xc842a8: ldr             lr, [x21, lr, lsl #3]
    // 0xc842ac: blr             lr
    // 0xc842b0: add             SP, SP, #0x10
    // 0xc842b4: tbnz            w0, #4, #0xc84928
    // 0xc842b8: ldr             x1, [fp, #0x18]
    // 0xc842bc: ldr             x2, [fp, #0x10]
    // 0xc842c0: r0 = LoadClassIdInstr(r2)
    //     0xc842c0: ldur            x0, [x2, #-1]
    //     0xc842c4: ubfx            x0, x0, #0xc, #0x14
    // 0xc842c8: SaveReg r2
    //     0xc842c8: str             x2, [SP, #-8]!
    // 0xc842cc: r0 = GDT[cid_x0 + -0xee0]()
    //     0xc842cc: sub             lr, x0, #0xee0
    //     0xc842d0: ldr             lr, [x21, lr, lsl #3]
    //     0xc842d4: blr             lr
    // 0xc842d8: add             SP, SP, #8
    // 0xc842dc: mov             x2, x0
    // 0xc842e0: ldr             x1, [fp, #0x18]
    // 0xc842e4: stur            x2, [fp, #-0x10]
    // 0xc842e8: r0 = LoadClassIdInstr(r1)
    //     0xc842e8: ldur            x0, [x1, #-1]
    //     0xc842ec: ubfx            x0, x0, #0xc, #0x14
    // 0xc842f0: SaveReg r1
    //     0xc842f0: str             x1, [SP, #-8]!
    // 0xc842f4: r0 = GDT[cid_x0 + -0xee0]()
    //     0xc842f4: sub             lr, x0, #0xee0
    //     0xc842f8: ldr             lr, [x21, lr, lsl #3]
    //     0xc842fc: blr             lr
    // 0xc84300: add             SP, SP, #8
    // 0xc84304: mov             x1, x0
    // 0xc84308: ldur            x0, [fp, #-0x10]
    // 0xc8430c: r2 = LoadClassIdInstr(r0)
    //     0xc8430c: ldur            x2, [x0, #-1]
    //     0xc84310: ubfx            x2, x2, #0xc, #0x14
    // 0xc84314: stp             x1, x0, [SP, #-0x10]!
    // 0xc84318: mov             x0, x2
    // 0xc8431c: mov             lr, x0
    // 0xc84320: ldr             lr, [x21, lr, lsl #3]
    // 0xc84324: blr             lr
    // 0xc84328: add             SP, SP, #0x10
    // 0xc8432c: tbnz            w0, #4, #0xc84928
    // 0xc84330: ldr             x1, [fp, #0x18]
    // 0xc84334: ldr             x2, [fp, #0x10]
    // 0xc84338: r0 = LoadClassIdInstr(r2)
    //     0xc84338: ldur            x0, [x2, #-1]
    //     0xc8433c: ubfx            x0, x0, #0xc, #0x14
    // 0xc84340: SaveReg r2
    //     0xc84340: str             x2, [SP, #-8]!
    // 0xc84344: r0 = GDT[cid_x0 + -0xedb]()
    //     0xc84344: sub             lr, x0, #0xedb
    //     0xc84348: ldr             lr, [x21, lr, lsl #3]
    //     0xc8434c: blr             lr
    // 0xc84350: add             SP, SP, #8
    // 0xc84354: mov             x2, x0
    // 0xc84358: ldr             x1, [fp, #0x18]
    // 0xc8435c: stur            x2, [fp, #-0x10]
    // 0xc84360: r0 = LoadClassIdInstr(r1)
    //     0xc84360: ldur            x0, [x1, #-1]
    //     0xc84364: ubfx            x0, x0, #0xc, #0x14
    // 0xc84368: SaveReg r1
    //     0xc84368: str             x1, [SP, #-8]!
    // 0xc8436c: r0 = GDT[cid_x0 + -0xedb]()
    //     0xc8436c: sub             lr, x0, #0xedb
    //     0xc84370: ldr             lr, [x21, lr, lsl #3]
    //     0xc84374: blr             lr
    // 0xc84378: add             SP, SP, #8
    // 0xc8437c: mov             x1, x0
    // 0xc84380: ldur            x0, [fp, #-0x10]
    // 0xc84384: r2 = LoadClassIdInstr(r0)
    //     0xc84384: ldur            x2, [x0, #-1]
    //     0xc84388: ubfx            x2, x2, #0xc, #0x14
    // 0xc8438c: stp             x1, x0, [SP, #-0x10]!
    // 0xc84390: mov             x0, x2
    // 0xc84394: mov             lr, x0
    // 0xc84398: ldr             lr, [x21, lr, lsl #3]
    // 0xc8439c: blr             lr
    // 0xc843a0: add             SP, SP, #0x10
    // 0xc843a4: tbnz            w0, #4, #0xc84928
    // 0xc843a8: ldr             x1, [fp, #0x18]
    // 0xc843ac: ldr             x2, [fp, #0x10]
    // 0xc843b0: LoadField: r0 = r2->field_2b
    //     0xc843b0: ldur            w0, [x2, #0x2b]
    // 0xc843b4: DecompressPointer r0
    //     0xc843b4: add             x0, x0, HEAP, lsl #32
    // 0xc843b8: LoadField: r3 = r1->field_2b
    //     0xc843b8: ldur            w3, [x1, #0x2b]
    // 0xc843bc: DecompressPointer r3
    //     0xc843bc: add             x3, x3, HEAP, lsl #32
    // 0xc843c0: cmp             w0, w3
    // 0xc843c4: b.ne            #0xc84928
    // 0xc843c8: r0 = LoadClassIdInstr(r2)
    //     0xc843c8: ldur            x0, [x2, #-1]
    //     0xc843cc: ubfx            x0, x0, #0xc, #0x14
    // 0xc843d0: SaveReg r2
    //     0xc843d0: str             x2, [SP, #-8]!
    // 0xc843d4: r0 = GDT[cid_x0 + -0xed4]()
    //     0xc843d4: sub             lr, x0, #0xed4
    //     0xc843d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc843dc: blr             lr
    // 0xc843e0: add             SP, SP, #8
    // 0xc843e4: mov             x2, x0
    // 0xc843e8: ldr             x1, [fp, #0x18]
    // 0xc843ec: stur            x2, [fp, #-0x10]
    // 0xc843f0: r0 = LoadClassIdInstr(r1)
    //     0xc843f0: ldur            x0, [x1, #-1]
    //     0xc843f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc843f8: SaveReg r1
    //     0xc843f8: str             x1, [SP, #-8]!
    // 0xc843fc: r0 = GDT[cid_x0 + -0xed4]()
    //     0xc843fc: sub             lr, x0, #0xed4
    //     0xc84400: ldr             lr, [x21, lr, lsl #3]
    //     0xc84404: blr             lr
    // 0xc84408: add             SP, SP, #8
    // 0xc8440c: mov             x1, x0
    // 0xc84410: ldur            x0, [fp, #-0x10]
    // 0xc84414: r2 = LoadClassIdInstr(r0)
    //     0xc84414: ldur            x2, [x0, #-1]
    //     0xc84418: ubfx            x2, x2, #0xc, #0x14
    // 0xc8441c: stp             x1, x0, [SP, #-0x10]!
    // 0xc84420: mov             x0, x2
    // 0xc84424: mov             lr, x0
    // 0xc84428: ldr             lr, [x21, lr, lsl #3]
    // 0xc8442c: blr             lr
    // 0xc84430: add             SP, SP, #0x10
    // 0xc84434: tbnz            w0, #4, #0xc84928
    // 0xc84438: ldr             x1, [fp, #0x18]
    // 0xc8443c: ldr             x2, [fp, #0x10]
    // 0xc84440: LoadField: r0 = r2->field_33
    //     0xc84440: ldur            w0, [x2, #0x33]
    // 0xc84444: DecompressPointer r0
    //     0xc84444: add             x0, x0, HEAP, lsl #32
    // 0xc84448: LoadField: r3 = r1->field_33
    //     0xc84448: ldur            w3, [x1, #0x33]
    // 0xc8444c: DecompressPointer r3
    //     0xc8444c: add             x3, x3, HEAP, lsl #32
    // 0xc84450: cmp             w0, w3
    // 0xc84454: b.ne            #0xc84928
    // 0xc84458: ldur            x3, [fp, #-8]
    // 0xc8445c: r17 = 5662
    //     0xc8445c: mov             x17, #0x161e
    // 0xc84460: cmp             w3, w17
    // 0xc84464: b.gt            #0xc84474
    // 0xc84468: r17 = 5658
    //     0xc84468: mov             x17, #0x161a
    // 0xc8446c: cmp             w3, w17
    // 0xc84470: b.ge            #0xc8448c
    // 0xc84474: r17 = 5664
    //     0xc84474: mov             x17, #0x1620
    // 0xc84478: cmp             w3, w17
    // 0xc8447c: b.ne            #0xc8448c
    // 0xc84480: r0 = Instance_MaterialStatePropertyAll
    //     0xc84480: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e6f0] Obj!MaterialStatePropertyAll<double>@b37c81
    //     0xc84484: ldr             x0, [x0, #0x6f0]
    // 0xc84488: b               #0xc84494
    // 0xc8448c: LoadField: r0 = r2->field_37
    //     0xc8448c: ldur            w0, [x2, #0x37]
    // 0xc84490: DecompressPointer r0
    //     0xc84490: add             x0, x0, HEAP, lsl #32
    // 0xc84494: r4 = LoadClassIdInstr(r1)
    //     0xc84494: ldur            x4, [x1, #-1]
    //     0xc84498: ubfx            x4, x4, #0xc, #0x14
    // 0xc8449c: lsl             x4, x4, #1
    // 0xc844a0: stur            x4, [fp, #-0x10]
    // 0xc844a4: r17 = 5662
    //     0xc844a4: mov             x17, #0x161e
    // 0xc844a8: cmp             w4, w17
    // 0xc844ac: b.gt            #0xc844bc
    // 0xc844b0: r17 = 5658
    //     0xc844b0: mov             x17, #0x161a
    // 0xc844b4: cmp             w4, w17
    // 0xc844b8: b.ge            #0xc844d4
    // 0xc844bc: r17 = 5664
    //     0xc844bc: mov             x17, #0x1620
    // 0xc844c0: cmp             w4, w17
    // 0xc844c4: b.ne            #0xc844d4
    // 0xc844c8: r5 = Instance_MaterialStatePropertyAll
    //     0xc844c8: add             x5, PP, #0x2e, lsl #12  ; [pp+0x2e6f0] Obj!MaterialStatePropertyAll<double>@b37c81
    //     0xc844cc: ldr             x5, [x5, #0x6f0]
    // 0xc844d0: b               #0xc844dc
    // 0xc844d4: LoadField: r5 = r1->field_37
    //     0xc844d4: ldur            w5, [x1, #0x37]
    // 0xc844d8: DecompressPointer r5
    //     0xc844d8: add             x5, x5, HEAP, lsl #32
    // 0xc844dc: r6 = LoadClassIdInstr(r0)
    //     0xc844dc: ldur            x6, [x0, #-1]
    //     0xc844e0: ubfx            x6, x6, #0xc, #0x14
    // 0xc844e4: stp             x5, x0, [SP, #-0x10]!
    // 0xc844e8: mov             x0, x6
    // 0xc844ec: mov             lr, x0
    // 0xc844f0: ldr             lr, [x21, lr, lsl #3]
    // 0xc844f4: blr             lr
    // 0xc844f8: add             SP, SP, #0x10
    // 0xc844fc: tbnz            w0, #4, #0xc84928
    // 0xc84500: ldur            x0, [fp, #-8]
    // 0xc84504: r17 = 5660
    //     0xc84504: mov             x17, #0x161c
    // 0xc84508: cmp             w0, w17
    // 0xc8450c: b.gt            #0xc8451c
    // 0xc84510: r17 = 5658
    //     0xc84510: mov             x17, #0x161a
    // 0xc84514: cmp             w0, w17
    // 0xc84518: b.ge            #0xc84534
    // 0xc8451c: r17 = 5666
    //     0xc8451c: mov             x17, #0x1622
    // 0xc84520: cmp             w0, w17
    // 0xc84524: b.gt            #0xc8454c
    // 0xc84528: r17 = 5664
    //     0xc84528: mov             x17, #0x1620
    // 0xc8452c: cmp             w0, w17
    // 0xc84530: b.lt            #0xc84544
    // 0xc84534: ldr             x0, [fp, #0x10]
    // 0xc84538: LoadField: r1 = r0->field_3b
    //     0xc84538: ldur            w1, [x0, #0x3b]
    // 0xc8453c: DecompressPointer r1
    //     0xc8453c: add             x1, x1, HEAP, lsl #32
    // 0xc84540: b               #0xc84590
    // 0xc84544: ldr             x0, [fp, #0x10]
    // 0xc84548: b               #0xc84550
    // 0xc8454c: ldr             x0, [fp, #0x10]
    // 0xc84550: r1 = 1
    //     0xc84550: mov             x1, #1
    // 0xc84554: r0 = AllocateContext()
    //     0xc84554: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc84558: mov             x1, x0
    // 0xc8455c: ldr             x0, [fp, #0x10]
    // 0xc84560: StoreField: r1->field_f = r0
    //     0xc84560: stur            w0, [x1, #0xf]
    // 0xc84564: mov             x2, x1
    // 0xc84568: r1 = Function '<anonymous closure>':.
    //     0xc84568: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6d8] AnonymousClosure: (0x84d7a0), of [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3
    //     0xc8456c: ldr             x1, [x1, #0x6d8]
    // 0xc84570: r0 = AllocateClosure()
    //     0xc84570: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc84574: r16 = <BorderSide>
    //     0xc84574: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e6e0] TypeArguments: <BorderSide>
    //     0xc84578: ldr             x16, [x16, #0x6e0]
    // 0xc8457c: stp             x0, x16, [SP, #-0x10]!
    // 0xc84580: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc84580: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc84584: r0 = resolveWith()
    //     0xc84584: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc84588: add             SP, SP, #0x10
    // 0xc8458c: mov             x1, x0
    // 0xc84590: ldur            x0, [fp, #-0x10]
    // 0xc84594: stur            x1, [fp, #-8]
    // 0xc84598: r17 = 5660
    //     0xc84598: mov             x17, #0x161c
    // 0xc8459c: cmp             w0, w17
    // 0xc845a0: b.gt            #0xc845b0
    // 0xc845a4: r17 = 5658
    //     0xc845a4: mov             x17, #0x161a
    // 0xc845a8: cmp             w0, w17
    // 0xc845ac: b.ge            #0xc845c8
    // 0xc845b0: r17 = 5666
    //     0xc845b0: mov             x17, #0x1622
    // 0xc845b4: cmp             w0, w17
    // 0xc845b8: b.gt            #0xc845e8
    // 0xc845bc: r17 = 5664
    //     0xc845bc: mov             x17, #0x1620
    // 0xc845c0: cmp             w0, w17
    // 0xc845c4: b.lt            #0xc845e0
    // 0xc845c8: ldr             x0, [fp, #0x18]
    // 0xc845cc: LoadField: r2 = r0->field_3b
    //     0xc845cc: ldur            w2, [x0, #0x3b]
    // 0xc845d0: DecompressPointer r2
    //     0xc845d0: add             x2, x2, HEAP, lsl #32
    // 0xc845d4: mov             x0, x1
    // 0xc845d8: mov             x1, x2
    // 0xc845dc: b               #0xc84630
    // 0xc845e0: ldr             x0, [fp, #0x18]
    // 0xc845e4: b               #0xc845ec
    // 0xc845e8: ldr             x0, [fp, #0x18]
    // 0xc845ec: r1 = 1
    //     0xc845ec: mov             x1, #1
    // 0xc845f0: r0 = AllocateContext()
    //     0xc845f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc845f4: mov             x1, x0
    // 0xc845f8: ldr             x0, [fp, #0x18]
    // 0xc845fc: StoreField: r1->field_f = r0
    //     0xc845fc: stur            w0, [x1, #0xf]
    // 0xc84600: mov             x2, x1
    // 0xc84604: r1 = Function '<anonymous closure>':.
    //     0xc84604: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6d8] AnonymousClosure: (0x84d7a0), of [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3
    //     0xc84608: ldr             x1, [x1, #0x6d8]
    // 0xc8460c: r0 = AllocateClosure()
    //     0xc8460c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc84610: r16 = <BorderSide>
    //     0xc84610: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e6e0] TypeArguments: <BorderSide>
    //     0xc84614: ldr             x16, [x16, #0x6e0]
    // 0xc84618: stp             x0, x16, [SP, #-0x10]!
    // 0xc8461c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc8461c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc84620: r0 = resolveWith()
    //     0xc84620: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xc84624: add             SP, SP, #0x10
    // 0xc84628: mov             x1, x0
    // 0xc8462c: ldur            x0, [fp, #-8]
    // 0xc84630: r2 = LoadClassIdInstr(r0)
    //     0xc84630: ldur            x2, [x0, #-1]
    //     0xc84634: ubfx            x2, x2, #0xc, #0x14
    // 0xc84638: stp             x1, x0, [SP, #-0x10]!
    // 0xc8463c: mov             x0, x2
    // 0xc84640: mov             lr, x0
    // 0xc84644: ldr             lr, [x21, lr, lsl #3]
    // 0xc84648: blr             lr
    // 0xc8464c: add             SP, SP, #0x10
    // 0xc84650: tbnz            w0, #4, #0xc84928
    // 0xc84654: ldr             x1, [fp, #0x18]
    // 0xc84658: ldr             x2, [fp, #0x10]
    // 0xc8465c: r0 = LoadClassIdInstr(r2)
    //     0xc8465c: ldur            x0, [x2, #-1]
    //     0xc84660: ubfx            x0, x0, #0xc, #0x14
    // 0xc84664: SaveReg r2
    //     0xc84664: str             x2, [SP, #-8]!
    // 0xc84668: r0 = GDT[cid_x0 + -0xec3]()
    //     0xc84668: sub             lr, x0, #0xec3
    //     0xc8466c: ldr             lr, [x21, lr, lsl #3]
    //     0xc84670: blr             lr
    // 0xc84674: add             SP, SP, #8
    // 0xc84678: mov             x2, x0
    // 0xc8467c: ldr             x1, [fp, #0x18]
    // 0xc84680: stur            x2, [fp, #-8]
    // 0xc84684: r0 = LoadClassIdInstr(r1)
    //     0xc84684: ldur            x0, [x1, #-1]
    //     0xc84688: ubfx            x0, x0, #0xc, #0x14
    // 0xc8468c: SaveReg r1
    //     0xc8468c: str             x1, [SP, #-8]!
    // 0xc84690: r0 = GDT[cid_x0 + -0xec3]()
    //     0xc84690: sub             lr, x0, #0xec3
    //     0xc84694: ldr             lr, [x21, lr, lsl #3]
    //     0xc84698: blr             lr
    // 0xc8469c: add             SP, SP, #8
    // 0xc846a0: mov             x1, x0
    // 0xc846a4: ldur            x0, [fp, #-8]
    // 0xc846a8: r2 = LoadClassIdInstr(r0)
    //     0xc846a8: ldur            x2, [x0, #-1]
    //     0xc846ac: ubfx            x2, x2, #0xc, #0x14
    // 0xc846b0: stp             x1, x0, [SP, #-0x10]!
    // 0xc846b4: mov             x0, x2
    // 0xc846b8: mov             lr, x0
    // 0xc846bc: ldr             lr, [x21, lr, lsl #3]
    // 0xc846c0: blr             lr
    // 0xc846c4: add             SP, SP, #0x10
    // 0xc846c8: tbnz            w0, #4, #0xc84928
    // 0xc846cc: ldr             x1, [fp, #0x18]
    // 0xc846d0: ldr             x2, [fp, #0x10]
    // 0xc846d4: r0 = LoadClassIdInstr(r2)
    //     0xc846d4: ldur            x0, [x2, #-1]
    //     0xc846d8: ubfx            x0, x0, #0xc, #0x14
    // 0xc846dc: SaveReg r2
    //     0xc846dc: str             x2, [SP, #-8]!
    // 0xc846e0: r0 = GDT[cid_x0 + -0xebb]()
    //     0xc846e0: sub             lr, x0, #0xebb
    //     0xc846e4: ldr             lr, [x21, lr, lsl #3]
    //     0xc846e8: blr             lr
    // 0xc846ec: add             SP, SP, #8
    // 0xc846f0: mov             x2, x0
    // 0xc846f4: ldr             x1, [fp, #0x18]
    // 0xc846f8: stur            x2, [fp, #-8]
    // 0xc846fc: r0 = LoadClassIdInstr(r1)
    //     0xc846fc: ldur            x0, [x1, #-1]
    //     0xc84700: ubfx            x0, x0, #0xc, #0x14
    // 0xc84704: SaveReg r1
    //     0xc84704: str             x1, [SP, #-8]!
    // 0xc84708: r0 = GDT[cid_x0 + -0xebb]()
    //     0xc84708: sub             lr, x0, #0xebb
    //     0xc8470c: ldr             lr, [x21, lr, lsl #3]
    //     0xc84710: blr             lr
    // 0xc84714: add             SP, SP, #8
    // 0xc84718: mov             x1, x0
    // 0xc8471c: ldur            x0, [fp, #-8]
    // 0xc84720: r2 = LoadClassIdInstr(r0)
    //     0xc84720: ldur            x2, [x0, #-1]
    //     0xc84724: ubfx            x2, x2, #0xc, #0x14
    // 0xc84728: stp             x1, x0, [SP, #-0x10]!
    // 0xc8472c: mov             x0, x2
    // 0xc84730: mov             lr, x0
    // 0xc84734: ldr             lr, [x21, lr, lsl #3]
    // 0xc84738: blr             lr
    // 0xc8473c: add             SP, SP, #0x10
    // 0xc84740: tbnz            w0, #4, #0xc84928
    // 0xc84744: ldr             x1, [fp, #0x18]
    // 0xc84748: ldr             x2, [fp, #0x10]
    // 0xc8474c: r0 = LoadClassIdInstr(r2)
    //     0xc8474c: ldur            x0, [x2, #-1]
    //     0xc84750: ubfx            x0, x0, #0xc, #0x14
    // 0xc84754: SaveReg r2
    //     0xc84754: str             x2, [SP, #-8]!
    // 0xc84758: r0 = GDT[cid_x0 + -0xeb5]()
    //     0xc84758: sub             lr, x0, #0xeb5
    //     0xc8475c: ldr             lr, [x21, lr, lsl #3]
    //     0xc84760: blr             lr
    // 0xc84764: add             SP, SP, #8
    // 0xc84768: mov             x2, x0
    // 0xc8476c: ldr             x1, [fp, #0x18]
    // 0xc84770: stur            x2, [fp, #-8]
    // 0xc84774: r0 = LoadClassIdInstr(r1)
    //     0xc84774: ldur            x0, [x1, #-1]
    //     0xc84778: ubfx            x0, x0, #0xc, #0x14
    // 0xc8477c: SaveReg r1
    //     0xc8477c: str             x1, [SP, #-8]!
    // 0xc84780: r0 = GDT[cid_x0 + -0xeb5]()
    //     0xc84780: sub             lr, x0, #0xeb5
    //     0xc84784: ldr             lr, [x21, lr, lsl #3]
    //     0xc84788: blr             lr
    // 0xc8478c: add             SP, SP, #8
    // 0xc84790: mov             x1, x0
    // 0xc84794: ldur            x0, [fp, #-8]
    // 0xc84798: r2 = LoadClassIdInstr(r0)
    //     0xc84798: ldur            x2, [x0, #-1]
    //     0xc8479c: ubfx            x2, x2, #0xc, #0x14
    // 0xc847a0: stp             x1, x0, [SP, #-0x10]!
    // 0xc847a4: mov             x0, x2
    // 0xc847a8: mov             lr, x0
    // 0xc847ac: ldr             lr, [x21, lr, lsl #3]
    // 0xc847b0: blr             lr
    // 0xc847b4: add             SP, SP, #0x10
    // 0xc847b8: tbnz            w0, #4, #0xc84928
    // 0xc847bc: ldr             x1, [fp, #0x18]
    // 0xc847c0: ldr             x2, [fp, #0x10]
    // 0xc847c4: r0 = LoadClassIdInstr(r2)
    //     0xc847c4: ldur            x0, [x2, #-1]
    //     0xc847c8: ubfx            x0, x0, #0xc, #0x14
    // 0xc847cc: SaveReg r2
    //     0xc847cc: str             x2, [SP, #-8]!
    // 0xc847d0: r0 = GDT[cid_x0 + -0xeb0]()
    //     0xc847d0: sub             lr, x0, #0xeb0
    //     0xc847d4: ldr             lr, [x21, lr, lsl #3]
    //     0xc847d8: blr             lr
    // 0xc847dc: add             SP, SP, #8
    // 0xc847e0: mov             x2, x0
    // 0xc847e4: ldr             x1, [fp, #0x18]
    // 0xc847e8: stur            x2, [fp, #-8]
    // 0xc847ec: r0 = LoadClassIdInstr(r1)
    //     0xc847ec: ldur            x0, [x1, #-1]
    //     0xc847f0: ubfx            x0, x0, #0xc, #0x14
    // 0xc847f4: SaveReg r1
    //     0xc847f4: str             x1, [SP, #-8]!
    // 0xc847f8: r0 = GDT[cid_x0 + -0xeb0]()
    //     0xc847f8: sub             lr, x0, #0xeb0
    //     0xc847fc: ldr             lr, [x21, lr, lsl #3]
    //     0xc84800: blr             lr
    // 0xc84804: add             SP, SP, #8
    // 0xc84808: mov             x1, x0
    // 0xc8480c: ldur            x0, [fp, #-8]
    // 0xc84810: cmp             w0, w1
    // 0xc84814: b.ne            #0xc84928
    // 0xc84818: ldr             x1, [fp, #0x18]
    // 0xc8481c: ldr             x2, [fp, #0x10]
    // 0xc84820: LoadField: r0 = r2->field_4f
    //     0xc84820: ldur            w0, [x2, #0x4f]
    // 0xc84824: DecompressPointer r0
    //     0xc84824: add             x0, x0, HEAP, lsl #32
    // 0xc84828: LoadField: r3 = r1->field_4f
    //     0xc84828: ldur            w3, [x1, #0x4f]
    // 0xc8482c: DecompressPointer r3
    //     0xc8482c: add             x3, x3, HEAP, lsl #32
    // 0xc84830: r4 = LoadClassIdInstr(r0)
    //     0xc84830: ldur            x4, [x0, #-1]
    //     0xc84834: ubfx            x4, x4, #0xc, #0x14
    // 0xc84838: stp             x3, x0, [SP, #-0x10]!
    // 0xc8483c: mov             x0, x4
    // 0xc84840: mov             lr, x0
    // 0xc84844: ldr             lr, [x21, lr, lsl #3]
    // 0xc84848: blr             lr
    // 0xc8484c: add             SP, SP, #0x10
    // 0xc84850: tbnz            w0, #4, #0xc84928
    // 0xc84854: ldr             x1, [fp, #0x18]
    // 0xc84858: ldr             x2, [fp, #0x10]
    // 0xc8485c: LoadField: r0 = r2->field_53
    //     0xc8485c: ldur            w0, [x2, #0x53]
    // 0xc84860: DecompressPointer r0
    //     0xc84860: add             x0, x0, HEAP, lsl #32
    // 0xc84864: LoadField: r3 = r1->field_53
    //     0xc84864: ldur            w3, [x1, #0x53]
    // 0xc84868: DecompressPointer r3
    //     0xc84868: add             x3, x3, HEAP, lsl #32
    // 0xc8486c: cmp             w0, w3
    // 0xc84870: b.ne            #0xc84928
    // 0xc84874: LoadField: r0 = r2->field_57
    //     0xc84874: ldur            w0, [x2, #0x57]
    // 0xc84878: DecompressPointer r0
    //     0xc84878: add             x0, x0, HEAP, lsl #32
    // 0xc8487c: LoadField: r3 = r1->field_57
    //     0xc8487c: ldur            w3, [x1, #0x57]
    // 0xc84880: DecompressPointer r3
    //     0xc84880: add             x3, x3, HEAP, lsl #32
    // 0xc84884: r4 = LoadClassIdInstr(r0)
    //     0xc84884: ldur            x4, [x0, #-1]
    //     0xc84888: ubfx            x4, x4, #0xc, #0x14
    // 0xc8488c: stp             x3, x0, [SP, #-0x10]!
    // 0xc84890: mov             x0, x4
    // 0xc84894: mov             lr, x0
    // 0xc84898: ldr             lr, [x21, lr, lsl #3]
    // 0xc8489c: blr             lr
    // 0xc848a0: add             SP, SP, #0x10
    // 0xc848a4: tbnz            w0, #4, #0xc84928
    // 0xc848a8: ldr             x1, [fp, #0x18]
    // 0xc848ac: ldr             x0, [fp, #0x10]
    // 0xc848b0: r2 = LoadClassIdInstr(r0)
    //     0xc848b0: ldur            x2, [x0, #-1]
    //     0xc848b4: ubfx            x2, x2, #0xc, #0x14
    // 0xc848b8: SaveReg r0
    //     0xc848b8: str             x0, [SP, #-8]!
    // 0xc848bc: mov             x0, x2
    // 0xc848c0: r0 = GDT[cid_x0 + -0xe82]()
    //     0xc848c0: sub             lr, x0, #0xe82
    //     0xc848c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc848c8: blr             lr
    // 0xc848cc: add             SP, SP, #8
    // 0xc848d0: mov             x1, x0
    // 0xc848d4: ldr             x0, [fp, #0x18]
    // 0xc848d8: stur            x1, [fp, #-8]
    // 0xc848dc: r2 = LoadClassIdInstr(r0)
    //     0xc848dc: ldur            x2, [x0, #-1]
    //     0xc848e0: ubfx            x2, x2, #0xc, #0x14
    // 0xc848e4: SaveReg r0
    //     0xc848e4: str             x0, [SP, #-8]!
    // 0xc848e8: mov             x0, x2
    // 0xc848ec: r0 = GDT[cid_x0 + -0xe82]()
    //     0xc848ec: sub             lr, x0, #0xe82
    //     0xc848f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc848f4: blr             lr
    // 0xc848f8: add             SP, SP, #8
    // 0xc848fc: mov             x1, x0
    // 0xc84900: ldur            x0, [fp, #-8]
    // 0xc84904: r2 = LoadClassIdInstr(r0)
    //     0xc84904: ldur            x2, [x0, #-1]
    //     0xc84908: ubfx            x2, x2, #0xc, #0x14
    // 0xc8490c: stp             x1, x0, [SP, #-0x10]!
    // 0xc84910: mov             x0, x2
    // 0xc84914: mov             lr, x0
    // 0xc84918: ldr             lr, [x21, lr, lsl #3]
    // 0xc8491c: blr             lr
    // 0xc84920: add             SP, SP, #0x10
    // 0xc84924: b               #0xc8492c
    // 0xc84928: r0 = false
    //     0xc84928: add             x0, NULL, #0x30  ; false
    // 0xc8492c: LeaveFrame
    //     0xc8492c: mov             SP, fp
    //     0xc84930: ldp             fp, lr, [SP], #0x10
    // 0xc84934: ret
    //     0xc84934: ret             
    // 0xc84938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc84938: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8493c: b               #0xc83e94
  }
  const get _ splashFactory(/* No info */) {
    // ** addr: 0xce4be4, size: 0x10
    // 0xce4be4: ldr             x1, [SP]
    // 0xce4be8: LoadField: r0 = r1->field_5b
    //     0xce4be8: ldur            w0, [x1, #0x5b]
    // 0xce4bec: DecompressPointer r0
    //     0xce4bec: add             x0, x0, HEAP, lsl #32
    // 0xce4bf0: ret
    //     0xce4bf0: ret             
  }
  const get _ mouseCursor(/* No info */) {
    // ** addr: 0xce5ad4, size: 0x10
    // 0xce5ad4: ldr             x1, [SP]
    // 0xce5ad8: LoadField: r0 = r1->field_43
    //     0xce5ad8: ldur            w0, [x1, #0x43]
    // 0xce5adc: DecompressPointer r0
    //     0xce5adc: add             x0, x0, HEAP, lsl #32
    // 0xce5ae0: ret
    //     0xce5ae0: ret             
  }
}

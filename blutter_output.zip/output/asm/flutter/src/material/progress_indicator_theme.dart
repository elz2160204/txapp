// lib: , url: package:flutter/src/material/progress_indicator_theme.dart

// class id: 1049293, size: 0x8
class :: {
}

// class id: 2772, size: 0x1c, field offset: 0x8
//   const constructor, 
class ProgressIndicatorThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00da8, size: 0xd8
    // 0xb00da8: EnterFrame
    //     0xb00da8: stp             fp, lr, [SP, #-0x10]!
    //     0xb00dac: mov             fp, SP
    // 0xb00db0: AllocStack(0x10)
    //     0xb00db0: sub             SP, SP, #0x10
    // 0xb00db4: CheckStackOverflow
    //     0xb00db4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00db8: cmp             SP, x16
    //     0xb00dbc: b.ls            #0xb00e78
    // 0xb00dc0: ldr             x1, [fp, #0x10]
    // 0xb00dc4: r0 = LoadClassIdInstr(r1)
    //     0xb00dc4: ldur            x0, [x1, #-1]
    //     0xb00dc8: ubfx            x0, x0, #0xc, #0x14
    // 0xb00dcc: SaveReg r1
    //     0xb00dcc: str             x1, [SP, #-8]!
    // 0xb00dd0: r0 = GDT[cid_x0 + -0xe43]()
    //     0xb00dd0: sub             lr, x0, #0xe43
    //     0xb00dd4: ldr             lr, [x21, lr, lsl #3]
    //     0xb00dd8: blr             lr
    // 0xb00ddc: add             SP, SP, #8
    // 0xb00de0: mov             x2, x0
    // 0xb00de4: ldr             x1, [fp, #0x10]
    // 0xb00de8: stur            x2, [fp, #-8]
    // 0xb00dec: r0 = LoadClassIdInstr(r1)
    //     0xb00dec: ldur            x0, [x1, #-1]
    //     0xb00df0: ubfx            x0, x0, #0xc, #0x14
    // 0xb00df4: SaveReg r1
    //     0xb00df4: str             x1, [SP, #-8]!
    // 0xb00df8: r0 = GDT[cid_x0 + -0xc71]()
    //     0xb00df8: sub             lr, x0, #0xc71
    //     0xb00dfc: ldr             lr, [x21, lr, lsl #3]
    //     0xb00e00: blr             lr
    // 0xb00e04: add             SP, SP, #8
    // 0xb00e08: mov             x1, x0
    // 0xb00e0c: ldr             x0, [fp, #0x10]
    // 0xb00e10: stur            x1, [fp, #-0x10]
    // 0xb00e14: r2 = LoadClassIdInstr(r0)
    //     0xb00e14: ldur            x2, [x0, #-1]
    //     0xb00e18: ubfx            x2, x2, #0xc, #0x14
    // 0xb00e1c: SaveReg r0
    //     0xb00e1c: str             x0, [SP, #-8]!
    // 0xb00e20: mov             x0, x2
    // 0xb00e24: r0 = GDT[cid_x0 + -0xc6c]()
    //     0xb00e24: sub             lr, x0, #0xc6c
    //     0xb00e28: ldr             lr, [x21, lr, lsl #3]
    //     0xb00e2c: blr             lr
    // 0xb00e30: add             SP, SP, #8
    // 0xb00e34: ldur            x16, [fp, #-8]
    // 0xb00e38: ldur            lr, [fp, #-0x10]
    // 0xb00e3c: stp             lr, x16, [SP, #-0x10]!
    // 0xb00e40: stp             NULL, x0, [SP, #-0x10]!
    // 0xb00e44: SaveReg rNULL
    //     0xb00e44: str             NULL, [SP, #-8]!
    // 0xb00e48: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xb00e48: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xb00e4c: r0 = hash()
    //     0xb00e4c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00e50: add             SP, SP, #0x28
    // 0xb00e54: mov             x2, x0
    // 0xb00e58: r0 = BoxInt64Instr(r2)
    //     0xb00e58: sbfiz           x0, x2, #1, #0x1f
    //     0xb00e5c: cmp             x2, x0, asr #1
    //     0xb00e60: b.eq            #0xb00e6c
    //     0xb00e64: bl              #0xd69bb8
    //     0xb00e68: stur            x2, [x0, #7]
    // 0xb00e6c: LeaveFrame
    //     0xb00e6c: mov             SP, fp
    //     0xb00e70: ldp             fp, lr, [SP], #0x10
    // 0xb00e74: ret
    //     0xb00e74: ret             
    // 0xb00e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00e78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00e7c: b               #0xb00dc0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf3300, size: 0xf4
    // 0xbf3300: EnterFrame
    //     0xbf3300: stp             fp, lr, [SP, #-0x10]!
    //     0xbf3304: mov             fp, SP
    // 0xbf3308: AllocStack(0x10)
    //     0xbf3308: sub             SP, SP, #0x10
    // 0xbf330c: CheckStackOverflow
    //     0xbf330c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf3310: cmp             SP, x16
    //     0xbf3314: b.ls            #0xbf33dc
    // 0xbf3318: ldr             d0, [fp, #0x10]
    // 0xbf331c: r0 = inline_Allocate_Double()
    //     0xbf331c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf3320: add             x0, x0, #0x10
    //     0xbf3324: cmp             x1, x0
    //     0xbf3328: b.ls            #0xbf33e4
    //     0xbf332c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf3330: sub             x0, x0, #0xf
    //     0xbf3334: mov             x1, #0xd108
    //     0xbf3338: movk            x1, #3, lsl #16
    //     0xbf333c: stur            x1, [x0, #-1]
    // 0xbf3340: StoreField: r0->field_7 = d0
    //     0xbf3340: stur            d0, [x0, #7]
    // 0xbf3344: stur            x0, [fp, #-8]
    // 0xbf3348: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf334c: SaveReg r0
    //     0xbf334c: str             x0, [SP, #-8]!
    // 0xbf3350: r0 = lerp()
    //     0xbf3350: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3354: add             SP, SP, #0x18
    // 0xbf3358: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf335c: ldur            x16, [fp, #-8]
    // 0xbf3360: SaveReg r16
    //     0xbf3360: str             x16, [SP, #-8]!
    // 0xbf3364: r0 = lerp()
    //     0xbf3364: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3368: add             SP, SP, #0x18
    // 0xbf336c: ldr             x0, [fp, #0x20]
    // 0xbf3370: LoadField: r1 = r0->field_f
    //     0xbf3370: ldur            w1, [x0, #0xf]
    // 0xbf3374: DecompressPointer r1
    //     0xbf3374: add             x1, x1, HEAP, lsl #32
    // 0xbf3378: ldr             x0, [fp, #0x18]
    // 0xbf337c: LoadField: r2 = r0->field_f
    //     0xbf337c: ldur            w2, [x0, #0xf]
    // 0xbf3380: DecompressPointer r2
    //     0xbf3380: add             x2, x2, HEAP, lsl #32
    // 0xbf3384: stp             x2, x1, [SP, #-0x10]!
    // 0xbf3388: ldur            x16, [fp, #-8]
    // 0xbf338c: SaveReg r16
    //     0xbf338c: str             x16, [SP, #-8]!
    // 0xbf3390: r0 = lerpDouble()
    //     0xbf3390: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3394: add             SP, SP, #0x18
    // 0xbf3398: stur            x0, [fp, #-0x10]
    // 0xbf339c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf33a0: ldur            x16, [fp, #-8]
    // 0xbf33a4: SaveReg r16
    //     0xbf33a4: str             x16, [SP, #-8]!
    // 0xbf33a8: r0 = lerp()
    //     0xbf33a8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf33ac: add             SP, SP, #0x18
    // 0xbf33b0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf33b4: ldur            x16, [fp, #-8]
    // 0xbf33b8: SaveReg r16
    //     0xbf33b8: str             x16, [SP, #-8]!
    // 0xbf33bc: r0 = lerp()
    //     0xbf33bc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf33c0: add             SP, SP, #0x18
    // 0xbf33c4: r0 = ProgressIndicatorThemeData()
    //     0xbf33c4: bl              #0xbf33f4  ; AllocateProgressIndicatorThemeDataStub -> ProgressIndicatorThemeData (size=0x1c)
    // 0xbf33c8: ldur            x1, [fp, #-0x10]
    // 0xbf33cc: StoreField: r0->field_f = r1
    //     0xbf33cc: stur            w1, [x0, #0xf]
    // 0xbf33d0: LeaveFrame
    //     0xbf33d0: mov             SP, fp
    //     0xbf33d4: ldp             fp, lr, [SP], #0x10
    // 0xbf33d8: ret
    //     0xbf33d8: ret             
    // 0xbf33dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf33dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf33e0: b               #0xbf3318
    // 0xbf33e4: SaveReg d0
    //     0xbf33e4: str             q0, [SP, #-0x10]!
    // 0xbf33e8: r0 = AllocateDouble()
    //     0xbf33e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf33ec: RestoreReg d0
    //     0xbf33ec: ldr             q0, [SP], #0x10
    // 0xbf33f0: b               #0xbf3340
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8c8a8, size: 0x280
    // 0xc8c8a8: EnterFrame
    //     0xc8c8a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc8c8ac: mov             fp, SP
    // 0xc8c8b0: AllocStack(0x8)
    //     0xc8c8b0: sub             SP, SP, #8
    // 0xc8c8b4: CheckStackOverflow
    //     0xc8c8b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8c8b8: cmp             SP, x16
    //     0xc8c8bc: b.ls            #0xc8cb20
    // 0xc8c8c0: ldr             x1, [fp, #0x10]
    // 0xc8c8c4: cmp             w1, NULL
    // 0xc8c8c8: b.ne            #0xc8c8dc
    // 0xc8c8cc: r0 = false
    //     0xc8c8cc: add             x0, NULL, #0x30  ; false
    // 0xc8c8d0: LeaveFrame
    //     0xc8c8d0: mov             SP, fp
    //     0xc8c8d4: ldp             fp, lr, [SP], #0x10
    // 0xc8c8d8: ret
    //     0xc8c8d8: ret             
    // 0xc8c8dc: ldr             x2, [fp, #0x18]
    // 0xc8c8e0: cmp             w2, w1
    // 0xc8c8e4: b.ne            #0xc8c8f8
    // 0xc8c8e8: r0 = true
    //     0xc8c8e8: add             x0, NULL, #0x20  ; true
    // 0xc8c8ec: LeaveFrame
    //     0xc8c8ec: mov             SP, fp
    //     0xc8c8f0: ldp             fp, lr, [SP], #0x10
    // 0xc8c8f4: ret
    //     0xc8c8f4: ret             
    // 0xc8c8f8: r0 = 59
    //     0xc8c8f8: mov             x0, #0x3b
    // 0xc8c8fc: branchIfSmi(r1, 0xc8c908)
    //     0xc8c8fc: tbz             w1, #0, #0xc8c908
    // 0xc8c900: r0 = LoadClassIdInstr(r1)
    //     0xc8c900: ldur            x0, [x1, #-1]
    //     0xc8c904: ubfx            x0, x0, #0xc, #0x14
    // 0xc8c908: SaveReg r1
    //     0xc8c908: str             x1, [SP, #-8]!
    // 0xc8c90c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8c90c: mov             x17, #0x57c5
    //     0xc8c910: add             lr, x0, x17
    //     0xc8c914: ldr             lr, [x21, lr, lsl #3]
    //     0xc8c918: blr             lr
    // 0xc8c91c: add             SP, SP, #8
    // 0xc8c920: stur            x0, [fp, #-8]
    // 0xc8c924: ldr             x16, [fp, #0x18]
    // 0xc8c928: SaveReg r16
    //     0xc8c928: str             x16, [SP, #-8]!
    // 0xc8c92c: r0 = runtimeType()
    //     0xc8c92c: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc8c930: add             SP, SP, #8
    // 0xc8c934: mov             x1, x0
    // 0xc8c938: ldur            x0, [fp, #-8]
    // 0xc8c93c: r2 = LoadClassIdInstr(r0)
    //     0xc8c93c: ldur            x2, [x0, #-1]
    //     0xc8c940: ubfx            x2, x2, #0xc, #0x14
    // 0xc8c944: stp             x1, x0, [SP, #-0x10]!
    // 0xc8c948: mov             x0, x2
    // 0xc8c94c: mov             lr, x0
    // 0xc8c950: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c954: blr             lr
    // 0xc8c958: add             SP, SP, #0x10
    // 0xc8c95c: tbz             w0, #4, #0xc8c970
    // 0xc8c960: r0 = false
    //     0xc8c960: add             x0, NULL, #0x30  ; false
    // 0xc8c964: LeaveFrame
    //     0xc8c964: mov             SP, fp
    //     0xc8c968: ldp             fp, lr, [SP], #0x10
    // 0xc8c96c: ret
    //     0xc8c96c: ret             
    // 0xc8c970: ldr             x1, [fp, #0x10]
    // 0xc8c974: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8c974: mov             x0, #0x76
    //     0xc8c978: tbz             w1, #0, #0xc8c988
    //     0xc8c97c: ldur            x0, [x1, #-1]
    //     0xc8c980: ubfx            x0, x0, #0xc, #0x14
    //     0xc8c984: lsl             x0, x0, #1
    // 0xc8c988: r2 = LoadInt32Instr(r0)
    //     0xc8c988: sbfx            x2, x0, #1, #0x1f
    // 0xc8c98c: cmp             x2, #0xad4
    // 0xc8c990: b.lt            #0xc8cb10
    // 0xc8c994: cmp             x2, #0xad8
    // 0xc8c998: b.gt            #0xc8cb10
    // 0xc8c99c: ldr             x2, [fp, #0x18]
    // 0xc8c9a0: r0 = LoadClassIdInstr(r1)
    //     0xc8c9a0: ldur            x0, [x1, #-1]
    //     0xc8c9a4: ubfx            x0, x0, #0xc, #0x14
    // 0xc8c9a8: SaveReg r1
    //     0xc8c9a8: str             x1, [SP, #-8]!
    // 0xc8c9ac: r0 = GDT[cid_x0 + -0xe43]()
    //     0xc8c9ac: sub             lr, x0, #0xe43
    //     0xc8c9b0: ldr             lr, [x21, lr, lsl #3]
    //     0xc8c9b4: blr             lr
    // 0xc8c9b8: add             SP, SP, #8
    // 0xc8c9bc: mov             x2, x0
    // 0xc8c9c0: ldr             x1, [fp, #0x18]
    // 0xc8c9c4: stur            x2, [fp, #-8]
    // 0xc8c9c8: r0 = LoadClassIdInstr(r1)
    //     0xc8c9c8: ldur            x0, [x1, #-1]
    //     0xc8c9cc: ubfx            x0, x0, #0xc, #0x14
    // 0xc8c9d0: SaveReg r1
    //     0xc8c9d0: str             x1, [SP, #-8]!
    // 0xc8c9d4: r0 = GDT[cid_x0 + -0xe43]()
    //     0xc8c9d4: sub             lr, x0, #0xe43
    //     0xc8c9d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc8c9dc: blr             lr
    // 0xc8c9e0: add             SP, SP, #8
    // 0xc8c9e4: mov             x1, x0
    // 0xc8c9e8: ldur            x0, [fp, #-8]
    // 0xc8c9ec: r2 = LoadClassIdInstr(r0)
    //     0xc8c9ec: ldur            x2, [x0, #-1]
    //     0xc8c9f0: ubfx            x2, x2, #0xc, #0x14
    // 0xc8c9f4: stp             x1, x0, [SP, #-0x10]!
    // 0xc8c9f8: mov             x0, x2
    // 0xc8c9fc: mov             lr, x0
    // 0xc8ca00: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ca04: blr             lr
    // 0xc8ca08: add             SP, SP, #0x10
    // 0xc8ca0c: tbnz            w0, #4, #0xc8cb10
    // 0xc8ca10: ldr             x1, [fp, #0x18]
    // 0xc8ca14: ldr             x2, [fp, #0x10]
    // 0xc8ca18: r0 = LoadClassIdInstr(r2)
    //     0xc8ca18: ldur            x0, [x2, #-1]
    //     0xc8ca1c: ubfx            x0, x0, #0xc, #0x14
    // 0xc8ca20: SaveReg r2
    //     0xc8ca20: str             x2, [SP, #-8]!
    // 0xc8ca24: r0 = GDT[cid_x0 + -0xc71]()
    //     0xc8ca24: sub             lr, x0, #0xc71
    //     0xc8ca28: ldr             lr, [x21, lr, lsl #3]
    //     0xc8ca2c: blr             lr
    // 0xc8ca30: add             SP, SP, #8
    // 0xc8ca34: mov             x2, x0
    // 0xc8ca38: ldr             x1, [fp, #0x18]
    // 0xc8ca3c: stur            x2, [fp, #-8]
    // 0xc8ca40: r0 = LoadClassIdInstr(r1)
    //     0xc8ca40: ldur            x0, [x1, #-1]
    //     0xc8ca44: ubfx            x0, x0, #0xc, #0x14
    // 0xc8ca48: SaveReg r1
    //     0xc8ca48: str             x1, [SP, #-8]!
    // 0xc8ca4c: r0 = GDT[cid_x0 + -0xc71]()
    //     0xc8ca4c: sub             lr, x0, #0xc71
    //     0xc8ca50: ldr             lr, [x21, lr, lsl #3]
    //     0xc8ca54: blr             lr
    // 0xc8ca58: add             SP, SP, #8
    // 0xc8ca5c: mov             x1, x0
    // 0xc8ca60: ldur            x0, [fp, #-8]
    // 0xc8ca64: r2 = LoadClassIdInstr(r0)
    //     0xc8ca64: ldur            x2, [x0, #-1]
    //     0xc8ca68: ubfx            x2, x2, #0xc, #0x14
    // 0xc8ca6c: stp             x1, x0, [SP, #-0x10]!
    // 0xc8ca70: mov             x0, x2
    // 0xc8ca74: mov             lr, x0
    // 0xc8ca78: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ca7c: blr             lr
    // 0xc8ca80: add             SP, SP, #0x10
    // 0xc8ca84: tbnz            w0, #4, #0xc8cb10
    // 0xc8ca88: ldr             x1, [fp, #0x18]
    // 0xc8ca8c: ldr             x0, [fp, #0x10]
    // 0xc8ca90: r2 = LoadClassIdInstr(r0)
    //     0xc8ca90: ldur            x2, [x0, #-1]
    //     0xc8ca94: ubfx            x2, x2, #0xc, #0x14
    // 0xc8ca98: SaveReg r0
    //     0xc8ca98: str             x0, [SP, #-8]!
    // 0xc8ca9c: mov             x0, x2
    // 0xc8caa0: r0 = GDT[cid_x0 + -0xc6c]()
    //     0xc8caa0: sub             lr, x0, #0xc6c
    //     0xc8caa4: ldr             lr, [x21, lr, lsl #3]
    //     0xc8caa8: blr             lr
    // 0xc8caac: add             SP, SP, #8
    // 0xc8cab0: mov             x1, x0
    // 0xc8cab4: ldr             x0, [fp, #0x18]
    // 0xc8cab8: stur            x1, [fp, #-8]
    // 0xc8cabc: r2 = LoadClassIdInstr(r0)
    //     0xc8cabc: ldur            x2, [x0, #-1]
    //     0xc8cac0: ubfx            x2, x2, #0xc, #0x14
    // 0xc8cac4: SaveReg r0
    //     0xc8cac4: str             x0, [SP, #-8]!
    // 0xc8cac8: mov             x0, x2
    // 0xc8cacc: r0 = GDT[cid_x0 + -0xc6c]()
    //     0xc8cacc: sub             lr, x0, #0xc6c
    //     0xc8cad0: ldr             lr, [x21, lr, lsl #3]
    //     0xc8cad4: blr             lr
    // 0xc8cad8: add             SP, SP, #8
    // 0xc8cadc: mov             x1, x0
    // 0xc8cae0: ldur            x0, [fp, #-8]
    // 0xc8cae4: r2 = LoadClassIdInstr(r0)
    //     0xc8cae4: ldur            x2, [x0, #-1]
    //     0xc8cae8: ubfx            x2, x2, #0xc, #0x14
    // 0xc8caec: stp             x1, x0, [SP, #-0x10]!
    // 0xc8caf0: mov             x0, x2
    // 0xc8caf4: mov             lr, x0
    // 0xc8caf8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8cafc: blr             lr
    // 0xc8cb00: add             SP, SP, #0x10
    // 0xc8cb04: tbnz            w0, #4, #0xc8cb10
    // 0xc8cb08: r0 = true
    //     0xc8cb08: add             x0, NULL, #0x20  ; true
    // 0xc8cb0c: b               #0xc8cb14
    // 0xc8cb10: r0 = false
    //     0xc8cb10: add             x0, NULL, #0x30  ; false
    // 0xc8cb14: LeaveFrame
    //     0xc8cb14: mov             SP, fp
    //     0xc8cb18: ldp             fp, lr, [SP], #0x10
    // 0xc8cb1c: ret
    //     0xc8cb1c: ret             
    // 0xc8cb20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8cb20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8cb24: b               #0xc8c8c0
  }
}

// class id: 3541, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ProgressIndicatorTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0x862a5c, size: 0x64
    // 0x862a5c: EnterFrame
    //     0x862a5c: stp             fp, lr, [SP, #-0x10]!
    //     0x862a60: mov             fp, SP
    // 0x862a64: CheckStackOverflow
    //     0x862a64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x862a68: cmp             SP, x16
    //     0x862a6c: b.ls            #0x862ab8
    // 0x862a70: r16 = <ProgressIndicatorTheme>
    //     0x862a70: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d050] TypeArguments: <ProgressIndicatorTheme>
    //     0x862a74: ldr             x16, [x16, #0x50]
    // 0x862a78: ldr             lr, [fp, #0x10]
    // 0x862a7c: stp             lr, x16, [SP, #-0x10]!
    // 0x862a80: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x862a80: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x862a84: r0 = dependOnInheritedWidgetOfExactType()
    //     0x862a84: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x862a88: add             SP, SP, #0x10
    // 0x862a8c: ldr             x16, [fp, #0x10]
    // 0x862a90: SaveReg r16
    //     0x862a90: str             x16, [SP, #-8]!
    // 0x862a94: r0 = of()
    //     0x862a94: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x862a98: add             SP, SP, #8
    // 0x862a9c: r17 = 275
    //     0x862a9c: mov             x17, #0x113
    // 0x862aa0: ldr             w1, [x0, x17]
    // 0x862aa4: DecompressPointer r1
    //     0x862aa4: add             x1, x1, HEAP, lsl #32
    // 0x862aa8: mov             x0, x1
    // 0x862aac: LeaveFrame
    //     0x862aac: mov             SP, fp
    //     0x862ab0: ldp             fp, lr, [SP], #0x10
    // 0x862ab4: ret
    //     0x862ab4: ret             
    // 0x862ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862ab8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862abc: b               #0x862a70
  }
}

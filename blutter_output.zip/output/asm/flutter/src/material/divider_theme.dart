// lib: , url: package:flutter/src/material/divider_theme.dart

// class id: 1049226, size: 0x8
class :: {
}

// class id: 2806, size: 0x1c, field offset: 0x8
//   const constructor, 
class DividerThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xaff1c0, size: 0x10c
    // 0xaff1c0: EnterFrame
    //     0xaff1c0: stp             fp, lr, [SP, #-0x10]!
    //     0xaff1c4: mov             fp, SP
    // 0xaff1c8: CheckStackOverflow
    //     0xaff1c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaff1cc: cmp             SP, x16
    //     0xaff1d0: b.ls            #0xaff2c4
    // 0xaff1d4: ldr             x0, [fp, #0x10]
    // 0xaff1d8: r1 = LoadClassIdInstr(r0)
    //     0xaff1d8: ldur            x1, [x0, #-1]
    //     0xaff1dc: ubfx            x1, x1, #0xc, #0x14
    // 0xaff1e0: lsl             x1, x1, #1
    // 0xaff1e4: r17 = 5612
    //     0xaff1e4: mov             x17, #0x15ec
    // 0xaff1e8: cmp             w1, w17
    // 0xaff1ec: b.ne            #0xaff1fc
    // 0xaff1f0: LoadField: r1 = r0->field_7
    //     0xaff1f0: ldur            w1, [x0, #7]
    // 0xaff1f4: DecompressPointer r1
    //     0xaff1f4: add             x1, x1, HEAP, lsl #32
    // 0xaff1f8: b               #0xaff268
    // 0xaff1fc: r17 = 5614
    //     0xaff1fc: mov             x17, #0x15ee
    // 0xaff200: cmp             w1, w17
    // 0xaff204: b.ne            #0xaff248
    // 0xaff208: LoadField: r1 = r0->field_1b
    //     0xaff208: ldur            w1, [x0, #0x1b]
    // 0xaff20c: DecompressPointer r1
    //     0xaff20c: add             x1, x1, HEAP, lsl #32
    // 0xaff210: SaveReg r1
    //     0xaff210: str             x1, [SP, #-8]!
    // 0xaff214: r0 = of()
    //     0xaff214: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaff218: add             SP, SP, #8
    // 0xaff21c: LoadField: r1 = r0->field_3f
    //     0xaff21c: ldur            w1, [x0, #0x3f]
    // 0xaff220: DecompressPointer r1
    //     0xaff220: add             x1, x1, HEAP, lsl #32
    // 0xaff224: LoadField: r0 = r1->field_67
    //     0xaff224: ldur            w0, [x1, #0x67]
    // 0xaff228: DecompressPointer r0
    //     0xaff228: add             x0, x0, HEAP, lsl #32
    // 0xaff22c: cmp             w0, NULL
    // 0xaff230: b.ne            #0xaff23c
    // 0xaff234: LoadField: r0 = r1->field_4f
    //     0xaff234: ldur            w0, [x1, #0x4f]
    // 0xaff238: DecompressPointer r0
    //     0xaff238: add             x0, x0, HEAP, lsl #32
    // 0xaff23c: mov             x1, x0
    // 0xaff240: ldr             x0, [fp, #0x10]
    // 0xaff244: b               #0xaff268
    // 0xaff248: LoadField: r1 = r0->field_1b
    //     0xaff248: ldur            w1, [x0, #0x1b]
    // 0xaff24c: DecompressPointer r1
    //     0xaff24c: add             x1, x1, HEAP, lsl #32
    // 0xaff250: SaveReg r1
    //     0xaff250: str             x1, [SP, #-8]!
    // 0xaff254: r0 = of()
    //     0xaff254: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaff258: add             SP, SP, #8
    // 0xaff25c: LoadField: r1 = r0->field_4b
    //     0xaff25c: ldur            w1, [x0, #0x4b]
    // 0xaff260: DecompressPointer r1
    //     0xaff260: add             x1, x1, HEAP, lsl #32
    // 0xaff264: ldr             x0, [fp, #0x10]
    // 0xaff268: LoadField: r2 = r0->field_b
    //     0xaff268: ldur            w2, [x0, #0xb]
    // 0xaff26c: DecompressPointer r2
    //     0xaff26c: add             x2, x2, HEAP, lsl #32
    // 0xaff270: LoadField: r3 = r0->field_f
    //     0xaff270: ldur            w3, [x0, #0xf]
    // 0xaff274: DecompressPointer r3
    //     0xaff274: add             x3, x3, HEAP, lsl #32
    // 0xaff278: LoadField: r4 = r0->field_13
    //     0xaff278: ldur            w4, [x0, #0x13]
    // 0xaff27c: DecompressPointer r4
    //     0xaff27c: add             x4, x4, HEAP, lsl #32
    // 0xaff280: LoadField: r5 = r0->field_17
    //     0xaff280: ldur            w5, [x0, #0x17]
    // 0xaff284: DecompressPointer r5
    //     0xaff284: add             x5, x5, HEAP, lsl #32
    // 0xaff288: stp             x2, x1, [SP, #-0x10]!
    // 0xaff28c: stp             x4, x3, [SP, #-0x10]!
    // 0xaff290: SaveReg r5
    //     0xaff290: str             x5, [SP, #-8]!
    // 0xaff294: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xaff294: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xaff298: r0 = hash()
    //     0xaff298: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaff29c: add             SP, SP, #0x28
    // 0xaff2a0: mov             x2, x0
    // 0xaff2a4: r0 = BoxInt64Instr(r2)
    //     0xaff2a4: sbfiz           x0, x2, #1, #0x1f
    //     0xaff2a8: cmp             x2, x0, asr #1
    //     0xaff2ac: b.eq            #0xaff2b8
    //     0xaff2b0: bl              #0xd69bb8
    //     0xaff2b4: stur            x2, [x0, #7]
    // 0xaff2b8: LeaveFrame
    //     0xaff2b8: mov             SP, fp
    //     0xaff2bc: ldp             fp, lr, [SP], #0x10
    // 0xaff2c0: ret
    //     0xaff2c0: ret             
    // 0xaff2c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaff2c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaff2c8: b               #0xaff1d4
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf4d90, size: 0x16c
    // 0xbf4d90: EnterFrame
    //     0xbf4d90: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4d94: mov             fp, SP
    // 0xbf4d98: AllocStack(0x20)
    //     0xbf4d98: sub             SP, SP, #0x20
    // 0xbf4d9c: CheckStackOverflow
    //     0xbf4d9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4da0: cmp             SP, x16
    //     0xbf4da4: b.ls            #0xbf4ee4
    // 0xbf4da8: ldr             d0, [fp, #0x10]
    // 0xbf4dac: r0 = inline_Allocate_Double()
    //     0xbf4dac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf4db0: add             x0, x0, #0x10
    //     0xbf4db4: cmp             x1, x0
    //     0xbf4db8: b.ls            #0xbf4eec
    //     0xbf4dbc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf4dc0: sub             x0, x0, #0xf
    //     0xbf4dc4: mov             x1, #0xd108
    //     0xbf4dc8: movk            x1, #3, lsl #16
    //     0xbf4dcc: stur            x1, [x0, #-1]
    // 0xbf4dd0: StoreField: r0->field_7 = d0
    //     0xbf4dd0: stur            d0, [x0, #7]
    // 0xbf4dd4: stur            x0, [fp, #-8]
    // 0xbf4dd8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4ddc: SaveReg r0
    //     0xbf4ddc: str             x0, [SP, #-8]!
    // 0xbf4de0: r0 = lerp()
    //     0xbf4de0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4de4: add             SP, SP, #0x18
    // 0xbf4de8: ldr             x0, [fp, #0x20]
    // 0xbf4dec: LoadField: r1 = r0->field_b
    //     0xbf4dec: ldur            w1, [x0, #0xb]
    // 0xbf4df0: DecompressPointer r1
    //     0xbf4df0: add             x1, x1, HEAP, lsl #32
    // 0xbf4df4: ldr             x2, [fp, #0x18]
    // 0xbf4df8: LoadField: r3 = r2->field_b
    //     0xbf4df8: ldur            w3, [x2, #0xb]
    // 0xbf4dfc: DecompressPointer r3
    //     0xbf4dfc: add             x3, x3, HEAP, lsl #32
    // 0xbf4e00: stp             x3, x1, [SP, #-0x10]!
    // 0xbf4e04: ldur            x16, [fp, #-8]
    // 0xbf4e08: SaveReg r16
    //     0xbf4e08: str             x16, [SP, #-8]!
    // 0xbf4e0c: r0 = lerpDouble()
    //     0xbf4e0c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4e10: add             SP, SP, #0x18
    // 0xbf4e14: mov             x1, x0
    // 0xbf4e18: ldr             x0, [fp, #0x20]
    // 0xbf4e1c: stur            x1, [fp, #-0x10]
    // 0xbf4e20: LoadField: r2 = r0->field_f
    //     0xbf4e20: ldur            w2, [x0, #0xf]
    // 0xbf4e24: DecompressPointer r2
    //     0xbf4e24: add             x2, x2, HEAP, lsl #32
    // 0xbf4e28: ldr             x3, [fp, #0x18]
    // 0xbf4e2c: LoadField: r4 = r3->field_f
    //     0xbf4e2c: ldur            w4, [x3, #0xf]
    // 0xbf4e30: DecompressPointer r4
    //     0xbf4e30: add             x4, x4, HEAP, lsl #32
    // 0xbf4e34: stp             x4, x2, [SP, #-0x10]!
    // 0xbf4e38: ldur            x16, [fp, #-8]
    // 0xbf4e3c: SaveReg r16
    //     0xbf4e3c: str             x16, [SP, #-8]!
    // 0xbf4e40: r0 = lerpDouble()
    //     0xbf4e40: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4e44: add             SP, SP, #0x18
    // 0xbf4e48: mov             x1, x0
    // 0xbf4e4c: ldr             x0, [fp, #0x20]
    // 0xbf4e50: stur            x1, [fp, #-0x18]
    // 0xbf4e54: LoadField: r2 = r0->field_13
    //     0xbf4e54: ldur            w2, [x0, #0x13]
    // 0xbf4e58: DecompressPointer r2
    //     0xbf4e58: add             x2, x2, HEAP, lsl #32
    // 0xbf4e5c: ldr             x3, [fp, #0x18]
    // 0xbf4e60: LoadField: r4 = r3->field_13
    //     0xbf4e60: ldur            w4, [x3, #0x13]
    // 0xbf4e64: DecompressPointer r4
    //     0xbf4e64: add             x4, x4, HEAP, lsl #32
    // 0xbf4e68: stp             x4, x2, [SP, #-0x10]!
    // 0xbf4e6c: ldur            x16, [fp, #-8]
    // 0xbf4e70: SaveReg r16
    //     0xbf4e70: str             x16, [SP, #-8]!
    // 0xbf4e74: r0 = lerpDouble()
    //     0xbf4e74: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4e78: add             SP, SP, #0x18
    // 0xbf4e7c: mov             x1, x0
    // 0xbf4e80: ldr             x0, [fp, #0x20]
    // 0xbf4e84: stur            x1, [fp, #-0x20]
    // 0xbf4e88: LoadField: r2 = r0->field_17
    //     0xbf4e88: ldur            w2, [x0, #0x17]
    // 0xbf4e8c: DecompressPointer r2
    //     0xbf4e8c: add             x2, x2, HEAP, lsl #32
    // 0xbf4e90: ldr             x0, [fp, #0x18]
    // 0xbf4e94: LoadField: r3 = r0->field_17
    //     0xbf4e94: ldur            w3, [x0, #0x17]
    // 0xbf4e98: DecompressPointer r3
    //     0xbf4e98: add             x3, x3, HEAP, lsl #32
    // 0xbf4e9c: stp             x3, x2, [SP, #-0x10]!
    // 0xbf4ea0: ldur            x16, [fp, #-8]
    // 0xbf4ea4: SaveReg r16
    //     0xbf4ea4: str             x16, [SP, #-8]!
    // 0xbf4ea8: r0 = lerpDouble()
    //     0xbf4ea8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4eac: add             SP, SP, #0x18
    // 0xbf4eb0: stur            x0, [fp, #-8]
    // 0xbf4eb4: r0 = DividerThemeData()
    //     0xbf4eb4: bl              #0xbf4efc  ; AllocateDividerThemeDataStub -> DividerThemeData (size=0x1c)
    // 0xbf4eb8: ldur            x1, [fp, #-0x10]
    // 0xbf4ebc: StoreField: r0->field_b = r1
    //     0xbf4ebc: stur            w1, [x0, #0xb]
    // 0xbf4ec0: ldur            x1, [fp, #-0x18]
    // 0xbf4ec4: StoreField: r0->field_f = r1
    //     0xbf4ec4: stur            w1, [x0, #0xf]
    // 0xbf4ec8: ldur            x1, [fp, #-0x20]
    // 0xbf4ecc: StoreField: r0->field_13 = r1
    //     0xbf4ecc: stur            w1, [x0, #0x13]
    // 0xbf4ed0: ldur            x1, [fp, #-8]
    // 0xbf4ed4: StoreField: r0->field_17 = r1
    //     0xbf4ed4: stur            w1, [x0, #0x17]
    // 0xbf4ed8: LeaveFrame
    //     0xbf4ed8: mov             SP, fp
    //     0xbf4edc: ldp             fp, lr, [SP], #0x10
    // 0xbf4ee0: ret
    //     0xbf4ee0: ret             
    // 0xbf4ee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf4ee4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf4ee8: b               #0xbf4da8
    // 0xbf4eec: SaveReg d0
    //     0xbf4eec: str             q0, [SP, #-0x10]!
    // 0xbf4ef0: r0 = AllocateDouble()
    //     0xbf4ef0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf4ef4: RestoreReg d0
    //     0xbf4ef4: ldr             q0, [SP], #0x10
    // 0xbf4ef8: b               #0xbf4dd0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc883b4, size: 0x338
    // 0xc883b4: EnterFrame
    //     0xc883b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc883b8: mov             fp, SP
    // 0xc883bc: AllocStack(0x8)
    //     0xc883bc: sub             SP, SP, #8
    // 0xc883c0: CheckStackOverflow
    //     0xc883c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc883c4: cmp             SP, x16
    //     0xc883c8: b.ls            #0xc886e4
    // 0xc883cc: ldr             x1, [fp, #0x10]
    // 0xc883d0: cmp             w1, NULL
    // 0xc883d4: b.ne            #0xc883e8
    // 0xc883d8: r0 = false
    //     0xc883d8: add             x0, NULL, #0x30  ; false
    // 0xc883dc: LeaveFrame
    //     0xc883dc: mov             SP, fp
    //     0xc883e0: ldp             fp, lr, [SP], #0x10
    // 0xc883e4: ret
    //     0xc883e4: ret             
    // 0xc883e8: ldr             x2, [fp, #0x18]
    // 0xc883ec: cmp             w2, w1
    // 0xc883f0: b.ne            #0xc88404
    // 0xc883f4: r0 = true
    //     0xc883f4: add             x0, NULL, #0x20  ; true
    // 0xc883f8: LeaveFrame
    //     0xc883f8: mov             SP, fp
    //     0xc883fc: ldp             fp, lr, [SP], #0x10
    // 0xc88400: ret
    //     0xc88400: ret             
    // 0xc88404: r0 = 59
    //     0xc88404: mov             x0, #0x3b
    // 0xc88408: branchIfSmi(r1, 0xc88414)
    //     0xc88408: tbz             w1, #0, #0xc88414
    // 0xc8840c: r0 = LoadClassIdInstr(r1)
    //     0xc8840c: ldur            x0, [x1, #-1]
    //     0xc88410: ubfx            x0, x0, #0xc, #0x14
    // 0xc88414: SaveReg r1
    //     0xc88414: str             x1, [SP, #-8]!
    // 0xc88418: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc88418: mov             x17, #0x57c5
    //     0xc8841c: add             lr, x0, x17
    //     0xc88420: ldr             lr, [x21, lr, lsl #3]
    //     0xc88424: blr             lr
    // 0xc88428: add             SP, SP, #8
    // 0xc8842c: stur            x0, [fp, #-8]
    // 0xc88430: ldr             x16, [fp, #0x18]
    // 0xc88434: SaveReg r16
    //     0xc88434: str             x16, [SP, #-8]!
    // 0xc88438: r0 = runtimeType()
    //     0xc88438: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc8843c: add             SP, SP, #8
    // 0xc88440: mov             x1, x0
    // 0xc88444: ldur            x0, [fp, #-8]
    // 0xc88448: r2 = LoadClassIdInstr(r0)
    //     0xc88448: ldur            x2, [x0, #-1]
    //     0xc8844c: ubfx            x2, x2, #0xc, #0x14
    // 0xc88450: stp             x1, x0, [SP, #-0x10]!
    // 0xc88454: mov             x0, x2
    // 0xc88458: mov             lr, x0
    // 0xc8845c: ldr             lr, [x21, lr, lsl #3]
    // 0xc88460: blr             lr
    // 0xc88464: add             SP, SP, #0x10
    // 0xc88468: tbz             w0, #4, #0xc8847c
    // 0xc8846c: r0 = false
    //     0xc8846c: add             x0, NULL, #0x30  ; false
    // 0xc88470: LeaveFrame
    //     0xc88470: mov             SP, fp
    //     0xc88474: ldp             fp, lr, [SP], #0x10
    // 0xc88478: ret
    //     0xc88478: ret             
    // 0xc8847c: ldr             x0, [fp, #0x10]
    // 0xc88480: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc88480: mov             x1, #0x76
    //     0xc88484: tbz             w0, #0, #0xc88494
    //     0xc88488: ldur            x1, [x0, #-1]
    //     0xc8848c: ubfx            x1, x1, #0xc, #0x14
    //     0xc88490: lsl             x1, x1, #1
    // 0xc88494: r2 = LoadInt32Instr(r1)
    //     0xc88494: sbfx            x2, x1, #1, #0x1f
    // 0xc88498: cmp             x2, #0xaf6
    // 0xc8849c: b.lt            #0xc886d4
    // 0xc884a0: cmp             x2, #0xaf8
    // 0xc884a4: b.gt            #0xc886d4
    // 0xc884a8: r17 = 5612
    //     0xc884a8: mov             x17, #0x15ec
    // 0xc884ac: cmp             w1, w17
    // 0xc884b0: b.ne            #0xc884c0
    // 0xc884b4: LoadField: r1 = r0->field_7
    //     0xc884b4: ldur            w1, [x0, #7]
    // 0xc884b8: DecompressPointer r1
    //     0xc884b8: add             x1, x1, HEAP, lsl #32
    // 0xc884bc: b               #0xc88524
    // 0xc884c0: r17 = 5614
    //     0xc884c0: mov             x17, #0x15ee
    // 0xc884c4: cmp             w1, w17
    // 0xc884c8: b.ne            #0xc88508
    // 0xc884cc: LoadField: r1 = r0->field_1b
    //     0xc884cc: ldur            w1, [x0, #0x1b]
    // 0xc884d0: DecompressPointer r1
    //     0xc884d0: add             x1, x1, HEAP, lsl #32
    // 0xc884d4: SaveReg r1
    //     0xc884d4: str             x1, [SP, #-8]!
    // 0xc884d8: r0 = of()
    //     0xc884d8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc884dc: add             SP, SP, #8
    // 0xc884e0: LoadField: r1 = r0->field_3f
    //     0xc884e0: ldur            w1, [x0, #0x3f]
    // 0xc884e4: DecompressPointer r1
    //     0xc884e4: add             x1, x1, HEAP, lsl #32
    // 0xc884e8: LoadField: r0 = r1->field_67
    //     0xc884e8: ldur            w0, [x1, #0x67]
    // 0xc884ec: DecompressPointer r0
    //     0xc884ec: add             x0, x0, HEAP, lsl #32
    // 0xc884f0: cmp             w0, NULL
    // 0xc884f4: b.ne            #0xc88500
    // 0xc884f8: LoadField: r0 = r1->field_4f
    //     0xc884f8: ldur            w0, [x1, #0x4f]
    // 0xc884fc: DecompressPointer r0
    //     0xc884fc: add             x0, x0, HEAP, lsl #32
    // 0xc88500: mov             x1, x0
    // 0xc88504: b               #0xc88524
    // 0xc88508: LoadField: r1 = r0->field_1b
    //     0xc88508: ldur            w1, [x0, #0x1b]
    // 0xc8850c: DecompressPointer r1
    //     0xc8850c: add             x1, x1, HEAP, lsl #32
    // 0xc88510: SaveReg r1
    //     0xc88510: str             x1, [SP, #-8]!
    // 0xc88514: r0 = of()
    //     0xc88514: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc88518: add             SP, SP, #8
    // 0xc8851c: LoadField: r1 = r0->field_4b
    //     0xc8851c: ldur            w1, [x0, #0x4b]
    // 0xc88520: DecompressPointer r1
    //     0xc88520: add             x1, x1, HEAP, lsl #32
    // 0xc88524: ldr             x0, [fp, #0x18]
    // 0xc88528: stur            x1, [fp, #-8]
    // 0xc8852c: r2 = LoadClassIdInstr(r0)
    //     0xc8852c: ldur            x2, [x0, #-1]
    //     0xc88530: ubfx            x2, x2, #0xc, #0x14
    // 0xc88534: lsl             x2, x2, #1
    // 0xc88538: r17 = 5612
    //     0xc88538: mov             x17, #0x15ec
    // 0xc8853c: cmp             w2, w17
    // 0xc88540: b.ne            #0xc88558
    // 0xc88544: LoadField: r2 = r0->field_7
    //     0xc88544: ldur            w2, [x0, #7]
    // 0xc88548: DecompressPointer r2
    //     0xc88548: add             x2, x2, HEAP, lsl #32
    // 0xc8854c: mov             x0, x1
    // 0xc88550: mov             x1, x2
    // 0xc88554: b               #0xc885c4
    // 0xc88558: r17 = 5614
    //     0xc88558: mov             x17, #0x15ee
    // 0xc8855c: cmp             w2, w17
    // 0xc88560: b.ne            #0xc885a4
    // 0xc88564: LoadField: r2 = r0->field_1b
    //     0xc88564: ldur            w2, [x0, #0x1b]
    // 0xc88568: DecompressPointer r2
    //     0xc88568: add             x2, x2, HEAP, lsl #32
    // 0xc8856c: SaveReg r2
    //     0xc8856c: str             x2, [SP, #-8]!
    // 0xc88570: r0 = of()
    //     0xc88570: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc88574: add             SP, SP, #8
    // 0xc88578: LoadField: r1 = r0->field_3f
    //     0xc88578: ldur            w1, [x0, #0x3f]
    // 0xc8857c: DecompressPointer r1
    //     0xc8857c: add             x1, x1, HEAP, lsl #32
    // 0xc88580: LoadField: r0 = r1->field_67
    //     0xc88580: ldur            w0, [x1, #0x67]
    // 0xc88584: DecompressPointer r0
    //     0xc88584: add             x0, x0, HEAP, lsl #32
    // 0xc88588: cmp             w0, NULL
    // 0xc8858c: b.ne            #0xc88598
    // 0xc88590: LoadField: r0 = r1->field_4f
    //     0xc88590: ldur            w0, [x1, #0x4f]
    // 0xc88594: DecompressPointer r0
    //     0xc88594: add             x0, x0, HEAP, lsl #32
    // 0xc88598: mov             x1, x0
    // 0xc8859c: ldur            x0, [fp, #-8]
    // 0xc885a0: b               #0xc885c4
    // 0xc885a4: LoadField: r1 = r0->field_1b
    //     0xc885a4: ldur            w1, [x0, #0x1b]
    // 0xc885a8: DecompressPointer r1
    //     0xc885a8: add             x1, x1, HEAP, lsl #32
    // 0xc885ac: SaveReg r1
    //     0xc885ac: str             x1, [SP, #-8]!
    // 0xc885b0: r0 = of()
    //     0xc885b0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc885b4: add             SP, SP, #8
    // 0xc885b8: LoadField: r1 = r0->field_4b
    //     0xc885b8: ldur            w1, [x0, #0x4b]
    // 0xc885bc: DecompressPointer r1
    //     0xc885bc: add             x1, x1, HEAP, lsl #32
    // 0xc885c0: ldur            x0, [fp, #-8]
    // 0xc885c4: r2 = LoadClassIdInstr(r0)
    //     0xc885c4: ldur            x2, [x0, #-1]
    //     0xc885c8: ubfx            x2, x2, #0xc, #0x14
    // 0xc885cc: stp             x1, x0, [SP, #-0x10]!
    // 0xc885d0: mov             x0, x2
    // 0xc885d4: mov             lr, x0
    // 0xc885d8: ldr             lr, [x21, lr, lsl #3]
    // 0xc885dc: blr             lr
    // 0xc885e0: add             SP, SP, #0x10
    // 0xc885e4: tbnz            w0, #4, #0xc886d4
    // 0xc885e8: ldr             x1, [fp, #0x18]
    // 0xc885ec: ldr             x2, [fp, #0x10]
    // 0xc885f0: LoadField: r0 = r2->field_b
    //     0xc885f0: ldur            w0, [x2, #0xb]
    // 0xc885f4: DecompressPointer r0
    //     0xc885f4: add             x0, x0, HEAP, lsl #32
    // 0xc885f8: LoadField: r3 = r1->field_b
    //     0xc885f8: ldur            w3, [x1, #0xb]
    // 0xc885fc: DecompressPointer r3
    //     0xc885fc: add             x3, x3, HEAP, lsl #32
    // 0xc88600: r4 = LoadClassIdInstr(r0)
    //     0xc88600: ldur            x4, [x0, #-1]
    //     0xc88604: ubfx            x4, x4, #0xc, #0x14
    // 0xc88608: stp             x3, x0, [SP, #-0x10]!
    // 0xc8860c: mov             x0, x4
    // 0xc88610: mov             lr, x0
    // 0xc88614: ldr             lr, [x21, lr, lsl #3]
    // 0xc88618: blr             lr
    // 0xc8861c: add             SP, SP, #0x10
    // 0xc88620: tbnz            w0, #4, #0xc886d4
    // 0xc88624: ldr             x1, [fp, #0x18]
    // 0xc88628: ldr             x2, [fp, #0x10]
    // 0xc8862c: LoadField: r0 = r2->field_f
    //     0xc8862c: ldur            w0, [x2, #0xf]
    // 0xc88630: DecompressPointer r0
    //     0xc88630: add             x0, x0, HEAP, lsl #32
    // 0xc88634: LoadField: r3 = r1->field_f
    //     0xc88634: ldur            w3, [x1, #0xf]
    // 0xc88638: DecompressPointer r3
    //     0xc88638: add             x3, x3, HEAP, lsl #32
    // 0xc8863c: r4 = LoadClassIdInstr(r0)
    //     0xc8863c: ldur            x4, [x0, #-1]
    //     0xc88640: ubfx            x4, x4, #0xc, #0x14
    // 0xc88644: stp             x3, x0, [SP, #-0x10]!
    // 0xc88648: mov             x0, x4
    // 0xc8864c: mov             lr, x0
    // 0xc88650: ldr             lr, [x21, lr, lsl #3]
    // 0xc88654: blr             lr
    // 0xc88658: add             SP, SP, #0x10
    // 0xc8865c: tbnz            w0, #4, #0xc886d4
    // 0xc88660: ldr             x1, [fp, #0x18]
    // 0xc88664: ldr             x2, [fp, #0x10]
    // 0xc88668: LoadField: r0 = r2->field_13
    //     0xc88668: ldur            w0, [x2, #0x13]
    // 0xc8866c: DecompressPointer r0
    //     0xc8866c: add             x0, x0, HEAP, lsl #32
    // 0xc88670: LoadField: r3 = r1->field_13
    //     0xc88670: ldur            w3, [x1, #0x13]
    // 0xc88674: DecompressPointer r3
    //     0xc88674: add             x3, x3, HEAP, lsl #32
    // 0xc88678: r4 = LoadClassIdInstr(r0)
    //     0xc88678: ldur            x4, [x0, #-1]
    //     0xc8867c: ubfx            x4, x4, #0xc, #0x14
    // 0xc88680: stp             x3, x0, [SP, #-0x10]!
    // 0xc88684: mov             x0, x4
    // 0xc88688: mov             lr, x0
    // 0xc8868c: ldr             lr, [x21, lr, lsl #3]
    // 0xc88690: blr             lr
    // 0xc88694: add             SP, SP, #0x10
    // 0xc88698: tbnz            w0, #4, #0xc886d4
    // 0xc8869c: ldr             x0, [fp, #0x18]
    // 0xc886a0: ldr             x1, [fp, #0x10]
    // 0xc886a4: LoadField: r2 = r1->field_17
    //     0xc886a4: ldur            w2, [x1, #0x17]
    // 0xc886a8: DecompressPointer r2
    //     0xc886a8: add             x2, x2, HEAP, lsl #32
    // 0xc886ac: LoadField: r1 = r0->field_17
    //     0xc886ac: ldur            w1, [x0, #0x17]
    // 0xc886b0: DecompressPointer r1
    //     0xc886b0: add             x1, x1, HEAP, lsl #32
    // 0xc886b4: r0 = LoadClassIdInstr(r2)
    //     0xc886b4: ldur            x0, [x2, #-1]
    //     0xc886b8: ubfx            x0, x0, #0xc, #0x14
    // 0xc886bc: stp             x1, x2, [SP, #-0x10]!
    // 0xc886c0: mov             lr, x0
    // 0xc886c4: ldr             lr, [x21, lr, lsl #3]
    // 0xc886c8: blr             lr
    // 0xc886cc: add             SP, SP, #0x10
    // 0xc886d0: b               #0xc886d8
    // 0xc886d4: r0 = false
    //     0xc886d4: add             x0, NULL, #0x30  ; false
    // 0xc886d8: LeaveFrame
    //     0xc886d8: mov             SP, fp
    //     0xc886dc: ldp             fp, lr, [SP], #0x10
    // 0xc886e0: ret
    //     0xc886e0: ret             
    // 0xc886e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc886e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc886e8: b               #0xc883cc
  }
}

// class id: 3548, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class DividerTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xb2031c, size: 0x60
    // 0xb2031c: EnterFrame
    //     0xb2031c: stp             fp, lr, [SP, #-0x10]!
    //     0xb20320: mov             fp, SP
    // 0xb20324: CheckStackOverflow
    //     0xb20324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb20328: cmp             SP, x16
    //     0xb2032c: b.ls            #0xb20374
    // 0xb20330: r16 = <DividerTheme>
    //     0xb20330: add             x16, PP, #0x37, lsl #12  ; [pp+0x37920] TypeArguments: <DividerTheme>
    //     0xb20334: ldr             x16, [x16, #0x920]
    // 0xb20338: ldr             lr, [fp, #0x10]
    // 0xb2033c: stp             lr, x16, [SP, #-0x10]!
    // 0xb20340: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb20340: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb20344: r0 = dependOnInheritedWidgetOfExactType()
    //     0xb20344: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xb20348: add             SP, SP, #0x10
    // 0xb2034c: ldr             x16, [fp, #0x10]
    // 0xb20350: SaveReg r16
    //     0xb20350: str             x16, [SP, #-8]!
    // 0xb20354: r0 = of()
    //     0xb20354: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb20358: add             SP, SP, #8
    // 0xb2035c: LoadField: r1 = r0->field_cf
    //     0xb2035c: ldur            w1, [x0, #0xcf]
    // 0xb20360: DecompressPointer r1
    //     0xb20360: add             x1, x1, HEAP, lsl #32
    // 0xb20364: mov             x0, x1
    // 0xb20368: LeaveFrame
    //     0xb20368: mov             SP, fp
    //     0xb2036c: ldp             fp, lr, [SP], #0x10
    // 0xb20370: ret
    //     0xb20370: ret             
    // 0xb20374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb20374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb20378: b               #0xb20330
  }
}

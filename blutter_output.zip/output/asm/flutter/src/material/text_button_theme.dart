// lib: , url: package:flutter/src/material/text_button_theme.dart

// class id: 1049322, size: 0x8
class :: {
}

// class id: 2721, size: 0xc, field offset: 0x8
//   const constructor, 
class TextButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0xbef2d8, size: 0x68
    // 0xbef2d8: EnterFrame
    //     0xbef2d8: stp             fp, lr, [SP, #-0x10]!
    //     0xbef2dc: mov             fp, SP
    // 0xbef2e0: AllocStack(0x8)
    //     0xbef2e0: sub             SP, SP, #8
    // 0xbef2e4: CheckStackOverflow
    //     0xbef2e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbef2e8: cmp             SP, x16
    //     0xbef2ec: b.ls            #0xbef338
    // 0xbef2f0: ldr             x0, [fp, #0x20]
    // 0xbef2f4: LoadField: r1 = r0->field_7
    //     0xbef2f4: ldur            w1, [x0, #7]
    // 0xbef2f8: DecompressPointer r1
    //     0xbef2f8: add             x1, x1, HEAP, lsl #32
    // 0xbef2fc: ldr             x0, [fp, #0x18]
    // 0xbef300: LoadField: r2 = r0->field_7
    //     0xbef300: ldur            w2, [x0, #7]
    // 0xbef304: DecompressPointer r2
    //     0xbef304: add             x2, x2, HEAP, lsl #32
    // 0xbef308: stp             x2, x1, [SP, #-0x10]!
    // 0xbef30c: ldr             d0, [fp, #0x10]
    // 0xbef310: SaveReg d0
    //     0xbef310: str             d0, [SP, #-8]!
    // 0xbef314: r0 = lerp()
    //     0xbef314: bl              #0xbef34c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0xbef318: add             SP, SP, #0x18
    // 0xbef31c: stur            x0, [fp, #-8]
    // 0xbef320: r0 = TextButtonThemeData()
    //     0xbef320: bl              #0xbef340  ; AllocateTextButtonThemeDataStub -> TextButtonThemeData (size=0xc)
    // 0xbef324: ldur            x1, [fp, #-8]
    // 0xbef328: StoreField: r0->field_7 = r1
    //     0xbef328: stur            w1, [x0, #7]
    // 0xbef32c: LeaveFrame
    //     0xbef32c: mov             SP, fp
    //     0xbef330: ldp             fp, lr, [SP], #0x10
    // 0xbef334: ret
    //     0xbef334: ret             
    // 0xbef338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbef338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbef33c: b               #0xbef2f0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8fe28, size: 0x124
    // 0xc8fe28: EnterFrame
    //     0xc8fe28: stp             fp, lr, [SP, #-0x10]!
    //     0xc8fe2c: mov             fp, SP
    // 0xc8fe30: CheckStackOverflow
    //     0xc8fe30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8fe34: cmp             SP, x16
    //     0xc8fe38: b.ls            #0xc8ff44
    // 0xc8fe3c: ldr             x1, [fp, #0x10]
    // 0xc8fe40: cmp             w1, NULL
    // 0xc8fe44: b.ne            #0xc8fe58
    // 0xc8fe48: r0 = false
    //     0xc8fe48: add             x0, NULL, #0x30  ; false
    // 0xc8fe4c: LeaveFrame
    //     0xc8fe4c: mov             SP, fp
    //     0xc8fe50: ldp             fp, lr, [SP], #0x10
    // 0xc8fe54: ret
    //     0xc8fe54: ret             
    // 0xc8fe58: ldr             x2, [fp, #0x18]
    // 0xc8fe5c: cmp             w2, w1
    // 0xc8fe60: b.ne            #0xc8fe74
    // 0xc8fe64: r0 = true
    //     0xc8fe64: add             x0, NULL, #0x20  ; true
    // 0xc8fe68: LeaveFrame
    //     0xc8fe68: mov             SP, fp
    //     0xc8fe6c: ldp             fp, lr, [SP], #0x10
    // 0xc8fe70: ret
    //     0xc8fe70: ret             
    // 0xc8fe74: r0 = 59
    //     0xc8fe74: mov             x0, #0x3b
    // 0xc8fe78: branchIfSmi(r1, 0xc8fe84)
    //     0xc8fe78: tbz             w1, #0, #0xc8fe84
    // 0xc8fe7c: r0 = LoadClassIdInstr(r1)
    //     0xc8fe7c: ldur            x0, [x1, #-1]
    //     0xc8fe80: ubfx            x0, x0, #0xc, #0x14
    // 0xc8fe84: SaveReg r1
    //     0xc8fe84: str             x1, [SP, #-8]!
    // 0xc8fe88: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8fe88: mov             x17, #0x57c5
    //     0xc8fe8c: add             lr, x0, x17
    //     0xc8fe90: ldr             lr, [x21, lr, lsl #3]
    //     0xc8fe94: blr             lr
    // 0xc8fe98: add             SP, SP, #8
    // 0xc8fe9c: r1 = LoadClassIdInstr(r0)
    //     0xc8fe9c: ldur            x1, [x0, #-1]
    //     0xc8fea0: ubfx            x1, x1, #0xc, #0x14
    // 0xc8fea4: r16 = TextButtonThemeData
    //     0xc8fea4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf48] Type: TextButtonThemeData
    //     0xc8fea8: ldr             x16, [x16, #0xf48]
    // 0xc8feac: stp             x16, x0, [SP, #-0x10]!
    // 0xc8feb0: mov             x0, x1
    // 0xc8feb4: mov             lr, x0
    // 0xc8feb8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8febc: blr             lr
    // 0xc8fec0: add             SP, SP, #0x10
    // 0xc8fec4: tbz             w0, #4, #0xc8fed8
    // 0xc8fec8: r0 = false
    //     0xc8fec8: add             x0, NULL, #0x30  ; false
    // 0xc8fecc: LeaveFrame
    //     0xc8fecc: mov             SP, fp
    //     0xc8fed0: ldp             fp, lr, [SP], #0x10
    // 0xc8fed4: ret
    //     0xc8fed4: ret             
    // 0xc8fed8: ldr             x0, [fp, #0x10]
    // 0xc8fedc: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8fedc: mov             x1, #0x76
    //     0xc8fee0: tbz             w0, #0, #0xc8fef0
    //     0xc8fee4: ldur            x1, [x0, #-1]
    //     0xc8fee8: ubfx            x1, x1, #0xc, #0x14
    //     0xc8feec: lsl             x1, x1, #1
    // 0xc8fef0: r17 = 5442
    //     0xc8fef0: mov             x17, #0x1542
    // 0xc8fef4: cmp             w1, w17
    // 0xc8fef8: b.ne            #0xc8ff34
    // 0xc8fefc: ldr             x1, [fp, #0x18]
    // 0xc8ff00: LoadField: r2 = r0->field_7
    //     0xc8ff00: ldur            w2, [x0, #7]
    // 0xc8ff04: DecompressPointer r2
    //     0xc8ff04: add             x2, x2, HEAP, lsl #32
    // 0xc8ff08: LoadField: r0 = r1->field_7
    //     0xc8ff08: ldur            w0, [x1, #7]
    // 0xc8ff0c: DecompressPointer r0
    //     0xc8ff0c: add             x0, x0, HEAP, lsl #32
    // 0xc8ff10: r1 = LoadClassIdInstr(r2)
    //     0xc8ff10: ldur            x1, [x2, #-1]
    //     0xc8ff14: ubfx            x1, x1, #0xc, #0x14
    // 0xc8ff18: stp             x0, x2, [SP, #-0x10]!
    // 0xc8ff1c: mov             x0, x1
    // 0xc8ff20: mov             lr, x0
    // 0xc8ff24: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ff28: blr             lr
    // 0xc8ff2c: add             SP, SP, #0x10
    // 0xc8ff30: b               #0xc8ff38
    // 0xc8ff34: r0 = false
    //     0xc8ff34: add             x0, NULL, #0x30  ; false
    // 0xc8ff38: LeaveFrame
    //     0xc8ff38: mov             SP, fp
    //     0xc8ff3c: ldp             fp, lr, [SP], #0x10
    // 0xc8ff40: ret
    //     0xc8ff40: ret             
    // 0xc8ff44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8ff44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8ff48: b               #0xc8fe3c
  }
}

// class id: 3539, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class TextButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xc1352c, size: 0x64
    // 0xc1352c: EnterFrame
    //     0xc1352c: stp             fp, lr, [SP, #-0x10]!
    //     0xc13530: mov             fp, SP
    // 0xc13534: CheckStackOverflow
    //     0xc13534: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc13538: cmp             SP, x16
    //     0xc1353c: b.ls            #0xc13588
    // 0xc13540: r16 = <TextButtonTheme>
    //     0xc13540: add             x16, PP, #0x37, lsl #12  ; [pp+0x376e0] TypeArguments: <TextButtonTheme>
    //     0xc13544: ldr             x16, [x16, #0x6e0]
    // 0xc13548: ldr             lr, [fp, #0x10]
    // 0xc1354c: stp             lr, x16, [SP, #-0x10]!
    // 0xc13550: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc13550: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc13554: r0 = dependOnInheritedWidgetOfExactType()
    //     0xc13554: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xc13558: add             SP, SP, #0x10
    // 0xc1355c: ldr             x16, [fp, #0x10]
    // 0xc13560: SaveReg r16
    //     0xc13560: str             x16, [SP, #-8]!
    // 0xc13564: r0 = of()
    //     0xc13564: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc13568: add             SP, SP, #8
    // 0xc1356c: r17 = 303
    //     0xc1356c: mov             x17, #0x12f
    // 0xc13570: ldr             w1, [x0, x17]
    // 0xc13574: DecompressPointer r1
    //     0xc13574: add             x1, x1, HEAP, lsl #32
    // 0xc13578: mov             x0, x1
    // 0xc1357c: LeaveFrame
    //     0xc1357c: mov             SP, fp
    //     0xc13580: ldp             fp, lr, [SP], #0x10
    // 0xc13584: ret
    //     0xc13584: ret             
    // 0xc13588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc13588: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1358c: b               #0xc13540
  }
}

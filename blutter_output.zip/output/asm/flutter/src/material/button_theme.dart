// lib: , url: package:flutter/src/material/button_theme.dart

// class id: 1049199, size: 0x8
class :: {
}

// class id: 2820, size: 0x4c, field offset: 0x8
//   const constructor, 
class ButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafe6b8, size: 0x12c
    // 0xafe6b8: EnterFrame
    //     0xafe6b8: stp             fp, lr, [SP, #-0x10]!
    //     0xafe6bc: mov             fp, SP
    // 0xafe6c0: CheckStackOverflow
    //     0xafe6c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafe6c4: cmp             SP, x16
    //     0xafe6c8: b.ls            #0xafe7dc
    // 0xafe6cc: ldr             x0, [fp, #0x10]
    // 0xafe6d0: LoadField: r1 = r0->field_1f
    //     0xafe6d0: ldur            w1, [x0, #0x1f]
    // 0xafe6d4: DecompressPointer r1
    //     0xafe6d4: add             x1, x1, HEAP, lsl #32
    // 0xafe6d8: cmp             w1, NULL
    // 0xafe6dc: b.ne            #0xafe708
    // 0xafe6e0: LoadField: r1 = r0->field_17
    //     0xafe6e0: ldur            w1, [x0, #0x17]
    // 0xafe6e4: DecompressPointer r1
    //     0xafe6e4: add             x1, x1, HEAP, lsl #32
    // 0xafe6e8: LoadField: r2 = r1->field_7
    //     0xafe6e8: ldur            x2, [x1, #7]
    // 0xafe6ec: cmp             x2, #1
    // 0xafe6f0: b.gt            #0xafe700
    // 0xafe6f4: r1 = Instance_EdgeInsets
    //     0xafe6f4: add             x1, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0xafe6f8: ldr             x1, [x1, #0x438]
    // 0xafe6fc: b               #0xafe708
    // 0xafe700: r1 = Instance_EdgeInsets
    //     0xafe700: add             x1, PP, #0xe, lsl #12  ; [pp+0xe440] Obj!EdgeInsets@b36ec1
    //     0xafe704: ldr             x1, [x1, #0x440]
    // 0xafe708: LoadField: r2 = r0->field_23
    //     0xafe708: ldur            w2, [x0, #0x23]
    // 0xafe70c: DecompressPointer r2
    //     0xafe70c: add             x2, x2, HEAP, lsl #32
    // 0xafe710: cmp             w2, NULL
    // 0xafe714: b.ne            #0xafe740
    // 0xafe718: LoadField: r2 = r0->field_17
    //     0xafe718: ldur            w2, [x0, #0x17]
    // 0xafe71c: DecompressPointer r2
    //     0xafe71c: add             x2, x2, HEAP, lsl #32
    // 0xafe720: LoadField: r3 = r2->field_7
    //     0xafe720: ldur            x3, [x2, #7]
    // 0xafe724: cmp             x3, #1
    // 0xafe728: b.gt            #0xafe738
    // 0xafe72c: r2 = Instance_RoundedRectangleBorder
    //     0xafe72c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe448] Obj!RoundedRectangleBorder@b38401
    //     0xafe730: ldr             x2, [x2, #0x448]
    // 0xafe734: b               #0xafe740
    // 0xafe738: r2 = Instance_RoundedRectangleBorder
    //     0xafe738: add             x2, PP, #0xe, lsl #12  ; [pp+0xe450] Obj!RoundedRectangleBorder@b383f1
    //     0xafe73c: ldr             x2, [x2, #0x450]
    // 0xafe740: LoadField: r3 = r0->field_2b
    //     0xafe740: ldur            w3, [x0, #0x2b]
    // 0xafe744: DecompressPointer r3
    //     0xafe744: add             x3, x3, HEAP, lsl #32
    // 0xafe748: LoadField: r4 = r0->field_33
    //     0xafe748: ldur            w4, [x0, #0x33]
    // 0xafe74c: DecompressPointer r4
    //     0xafe74c: add             x4, x4, HEAP, lsl #32
    // 0xafe750: LoadField: r5 = r0->field_37
    //     0xafe750: ldur            w5, [x0, #0x37]
    // 0xafe754: DecompressPointer r5
    //     0xafe754: add             x5, x5, HEAP, lsl #32
    // 0xafe758: LoadField: r6 = r0->field_3f
    //     0xafe758: ldur            w6, [x0, #0x3f]
    // 0xafe75c: DecompressPointer r6
    //     0xafe75c: add             x6, x6, HEAP, lsl #32
    // 0xafe760: LoadField: r7 = r0->field_43
    //     0xafe760: ldur            w7, [x0, #0x43]
    // 0xafe764: DecompressPointer r7
    //     0xafe764: add             x7, x7, HEAP, lsl #32
    // 0xafe768: LoadField: r8 = r0->field_47
    //     0xafe768: ldur            w8, [x0, #0x47]
    // 0xafe76c: DecompressPointer r8
    //     0xafe76c: add             x8, x8, HEAP, lsl #32
    // 0xafe770: r16 = Instance_ButtonTextTheme
    //     0xafe770: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf98] Obj!ButtonTextTheme@b65951
    //     0xafe774: ldr             x16, [x16, #0xf98]
    // 0xafe778: r30 = 88.000000
    //     0xafe778: add             lr, PP, #0xe, lsl #12  ; [pp+0xe458] 88
    //     0xafe77c: ldr             lr, [lr, #0x458]
    // 0xafe780: stp             lr, x16, [SP, #-0x10]!
    // 0xafe784: r16 = 36.000000
    //     0xafe784: add             x16, PP, #0xe, lsl #12  ; [pp+0xe368] 36
    //     0xafe788: ldr             x16, [x16, #0x368]
    // 0xafe78c: stp             x1, x16, [SP, #-0x10]!
    // 0xafe790: r16 = false
    //     0xafe790: add             x16, NULL, #0x30  ; false
    // 0xafe794: stp             x16, x2, [SP, #-0x10]!
    // 0xafe798: stp             NULL, x3, [SP, #-0x10]!
    // 0xafe79c: stp             x5, x4, [SP, #-0x10]!
    // 0xafe7a0: stp             x6, NULL, [SP, #-0x10]!
    // 0xafe7a4: stp             x8, x7, [SP, #-0x10]!
    // 0xafe7a8: r4 = const [0, 0xe, 0xe, 0xe, null]
    //     0xafe7a8: add             x4, PP, #0xe, lsl #12  ; [pp+0xe3d8] List(5) [0, 0xe, 0xe, 0xe, Null]
    //     0xafe7ac: ldr             x4, [x4, #0x3d8]
    // 0xafe7b0: r0 = hash()
    //     0xafe7b0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafe7b4: add             SP, SP, #0x70
    // 0xafe7b8: mov             x2, x0
    // 0xafe7bc: r0 = BoxInt64Instr(r2)
    //     0xafe7bc: sbfiz           x0, x2, #1, #0x1f
    //     0xafe7c0: cmp             x2, x0, asr #1
    //     0xafe7c4: b.eq            #0xafe7d0
    //     0xafe7c8: bl              #0xd69bb8
    //     0xafe7cc: stur            x2, [x0, #7]
    // 0xafe7d0: LeaveFrame
    //     0xafe7d0: mov             SP, fp
    //     0xafe7d4: ldp             fp, lr, [SP], #0x10
    // 0xafe7d8: ret
    //     0xafe7d8: ret             
    // 0xafe7dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafe7dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafe7e0: b               #0xafe6cc
  }
  get _ constraints(/* No info */) {
    // ** addr: 0xb234e0, size: 0x3c
    // 0xb234e0: EnterFrame
    //     0xb234e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb234e4: mov             fp, SP
    // 0xb234e8: r0 = BoxConstraints()
    //     0xb234e8: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb234ec: d0 = 88.000000
    //     0xb234ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa0] IMM: double(88) from 0x4056000000000000
    //     0xb234f0: ldr             d0, [x17, #0xfa0]
    // 0xb234f4: StoreField: r0->field_7 = d0
    //     0xb234f4: stur            d0, [x0, #7]
    // 0xb234f8: d0 = inf
    //     0xb234f8: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xb234fc: StoreField: r0->field_f = d0
    //     0xb234fc: stur            d0, [x0, #0xf]
    // 0xb23500: d1 = 36.000000
    //     0xb23500: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0xb23504: ldr             d1, [x17, #0xfa8]
    // 0xb23508: StoreField: r0->field_17 = d1
    //     0xb23508: stur            d1, [x0, #0x17]
    // 0xb2350c: StoreField: r0->field_1f = d0
    //     0xb2350c: stur            d0, [x0, #0x1f]
    // 0xb23510: LeaveFrame
    //     0xb23510: mov             SP, fp
    //     0xb23514: ldp             fp, lr, [SP], #0x10
    // 0xb23518: ret
    //     0xb23518: ret             
  }
  _ getPadding(/* No info */) {
    // ** addr: 0xb2351c, size: 0x3c
    // 0xb2351c: ldr             x1, [SP]
    // 0xb23520: LoadField: r0 = r1->field_5b
    //     0xb23520: ldur            w0, [x1, #0x5b]
    // 0xb23524: DecompressPointer r0
    //     0xb23524: add             x0, x0, HEAP, lsl #32
    // 0xb23528: cmp             w0, NULL
    // 0xb2352c: b.eq            #0xb23534
    // 0xb23530: ret
    //     0xb23530: ret             
    // 0xb23534: ldr             x1, [SP, #8]
    // 0xb23538: LoadField: r0 = r1->field_1f
    //     0xb23538: ldur            w0, [x1, #0x1f]
    // 0xb2353c: DecompressPointer r0
    //     0xb2353c: add             x0, x0, HEAP, lsl #32
    // 0xb23540: cmp             w0, NULL
    // 0xb23544: b.eq            #0xb2354c
    // 0xb23548: ret
    //     0xb23548: ret             
    // 0xb2354c: r0 = Instance_EdgeInsets
    //     0xb2354c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0xb23550: ldr             x0, [x0, #0x438]
    // 0xb23554: ret
    //     0xb23554: ret             
  }
  _ getHoverColor(/* No info */) {
    // ** addr: 0xb23558, size: 0x6c
    // 0xb23558: EnterFrame
    //     0xb23558: stp             fp, lr, [SP, #-0x10]!
    //     0xb2355c: mov             fp, SP
    // 0xb23560: CheckStackOverflow
    //     0xb23560: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb23564: cmp             SP, x16
    //     0xb23568: b.ls            #0xb235bc
    // 0xb2356c: ldr             x0, [fp, #0x18]
    // 0xb23570: LoadField: r1 = r0->field_37
    //     0xb23570: ldur            w1, [x0, #0x37]
    // 0xb23574: DecompressPointer r1
    //     0xb23574: add             x1, x1, HEAP, lsl #32
    // 0xb23578: cmp             w1, NULL
    // 0xb2357c: b.ne            #0xb235ac
    // 0xb23580: ldr             x16, [fp, #0x10]
    // 0xb23584: stp             x16, x0, [SP, #-0x10]!
    // 0xb23588: r0 = getTextColor()
    //     0xb23588: bl              #0xb23630  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getTextColor
    // 0xb2358c: add             SP, SP, #0x10
    // 0xb23590: SaveReg r0
    //     0xb23590: str             x0, [SP, #-8]!
    // 0xb23594: d0 = 0.040000
    //     0xb23594: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf50] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0xb23598: ldr             d0, [x17, #0xf50]
    // 0xb2359c: SaveReg d0
    //     0xb2359c: str             d0, [SP, #-8]!
    // 0xb235a0: r0 = withOpacity()
    //     0xb235a0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb235a4: add             SP, SP, #0x10
    // 0xb235a8: b               #0xb235b0
    // 0xb235ac: mov             x0, x1
    // 0xb235b0: LeaveFrame
    //     0xb235b0: mov             SP, fp
    //     0xb235b4: ldp             fp, lr, [SP], #0x10
    // 0xb235b8: ret
    //     0xb235b8: ret             
    // 0xb235bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb235bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb235c0: b               #0xb2356c
  }
  _ getFocusColor(/* No info */) {
    // ** addr: 0xb235c4, size: 0x6c
    // 0xb235c4: EnterFrame
    //     0xb235c4: stp             fp, lr, [SP, #-0x10]!
    //     0xb235c8: mov             fp, SP
    // 0xb235cc: CheckStackOverflow
    //     0xb235cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb235d0: cmp             SP, x16
    //     0xb235d4: b.ls            #0xb23628
    // 0xb235d8: ldr             x0, [fp, #0x18]
    // 0xb235dc: LoadField: r1 = r0->field_33
    //     0xb235dc: ldur            w1, [x0, #0x33]
    // 0xb235e0: DecompressPointer r1
    //     0xb235e0: add             x1, x1, HEAP, lsl #32
    // 0xb235e4: cmp             w1, NULL
    // 0xb235e8: b.ne            #0xb23618
    // 0xb235ec: ldr             x16, [fp, #0x10]
    // 0xb235f0: stp             x16, x0, [SP, #-0x10]!
    // 0xb235f4: r0 = getTextColor()
    //     0xb235f4: bl              #0xb23630  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getTextColor
    // 0xb235f8: add             SP, SP, #0x10
    // 0xb235fc: SaveReg r0
    //     0xb235fc: str             x0, [SP, #-8]!
    // 0xb23600: d0 = 0.120000
    //     0xb23600: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb23604: ldr             d0, [x17, #0xf48]
    // 0xb23608: SaveReg d0
    //     0xb23608: str             d0, [SP, #-8]!
    // 0xb2360c: r0 = withOpacity()
    //     0xb2360c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb23610: add             SP, SP, #0x10
    // 0xb23614: b               #0xb2361c
    // 0xb23618: mov             x0, x1
    // 0xb2361c: LeaveFrame
    //     0xb2361c: mov             SP, fp
    //     0xb23620: ldp             fp, lr, [SP], #0x10
    // 0xb23624: ret
    //     0xb23624: ret             
    // 0xb23628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2362c: b               #0xb235d8
  }
  _ getTextColor(/* No info */) {
    // ** addr: 0xb23630, size: 0x98
    // 0xb23630: EnterFrame
    //     0xb23630: stp             fp, lr, [SP, #-0x10]!
    //     0xb23634: mov             fp, SP
    // 0xb23638: CheckStackOverflow
    //     0xb23638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2363c: cmp             SP, x16
    //     0xb23640: b.ls            #0xb236bc
    // 0xb23644: ldr             x0, [fp, #0x10]
    // 0xb23648: LoadField: r1 = r0->field_b
    //     0xb23648: ldur            w1, [x0, #0xb]
    // 0xb2364c: DecompressPointer r1
    //     0xb2364c: add             x1, x1, HEAP, lsl #32
    // 0xb23650: cmp             w1, NULL
    // 0xb23654: b.eq            #0xb236a0
    // 0xb23658: ldr             x1, [fp, #0x18]
    // 0xb2365c: LoadField: r0 = r1->field_43
    //     0xb2365c: ldur            w0, [x1, #0x43]
    // 0xb23660: DecompressPointer r0
    //     0xb23660: add             x0, x0, HEAP, lsl #32
    // 0xb23664: cmp             w0, NULL
    // 0xb23668: b.eq            #0xb236c4
    // 0xb2366c: LoadField: r1 = r0->field_7
    //     0xb2366c: ldur            w1, [x0, #7]
    // 0xb23670: DecompressPointer r1
    //     0xb23670: add             x1, x1, HEAP, lsl #32
    // 0xb23674: r16 = Instance_Brightness
    //     0xb23674: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xb23678: cmp             w1, w16
    // 0xb2367c: b.ne            #0xb2368c
    // 0xb23680: r0 = Instance_Color
    //     0xb23680: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xb23684: ldr             x0, [x0, #0xbe8]
    // 0xb23688: b               #0xb23694
    // 0xb2368c: r0 = Instance_Color
    //     0xb2368c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28da0] Obj!Color@b5d1e1
    //     0xb23690: ldr             x0, [x0, #0xda0]
    // 0xb23694: LeaveFrame
    //     0xb23694: mov             SP, fp
    //     0xb23698: ldp             fp, lr, [SP], #0x10
    // 0xb2369c: ret
    //     0xb2369c: ret             
    // 0xb236a0: ldr             x1, [fp, #0x18]
    // 0xb236a4: stp             x0, x1, [SP, #-0x10]!
    // 0xb236a8: r0 = getDisabledTextColor()
    //     0xb236a8: bl              #0xb236c8  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getDisabledTextColor
    // 0xb236ac: add             SP, SP, #0x10
    // 0xb236b0: LeaveFrame
    //     0xb236b0: mov             SP, fp
    //     0xb236b4: ldp             fp, lr, [SP], #0x10
    // 0xb236b8: ret
    //     0xb236b8: ret             
    // 0xb236bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb236bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb236c0: b               #0xb23644
    // 0xb236c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb236c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getDisabledTextColor(/* No info */) {
    // ** addr: 0xb236c8, size: 0x60
    // 0xb236c8: EnterFrame
    //     0xb236c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb236cc: mov             fp, SP
    // 0xb236d0: d0 = 0.380000
    //     0xb236d0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb236d4: ldr             d0, [x17, #0x140]
    // 0xb236d8: CheckStackOverflow
    //     0xb236d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb236dc: cmp             SP, x16
    //     0xb236e0: b.ls            #0xb2371c
    // 0xb236e4: ldr             x0, [fp, #0x18]
    // 0xb236e8: LoadField: r1 = r0->field_43
    //     0xb236e8: ldur            w1, [x0, #0x43]
    // 0xb236ec: DecompressPointer r1
    //     0xb236ec: add             x1, x1, HEAP, lsl #32
    // 0xb236f0: cmp             w1, NULL
    // 0xb236f4: b.eq            #0xb23724
    // 0xb236f8: LoadField: r0 = r1->field_57
    //     0xb236f8: ldur            w0, [x1, #0x57]
    // 0xb236fc: DecompressPointer r0
    //     0xb236fc: add             x0, x0, HEAP, lsl #32
    // 0xb23700: SaveReg r0
    //     0xb23700: str             x0, [SP, #-8]!
    // 0xb23704: SaveReg d0
    //     0xb23704: str             d0, [SP, #-8]!
    // 0xb23708: r0 = withOpacity()
    //     0xb23708: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb2370c: add             SP, SP, #0x10
    // 0xb23710: LeaveFrame
    //     0xb23710: mov             SP, fp
    //     0xb23714: ldp             fp, lr, [SP], #0x10
    // 0xb23718: ret
    //     0xb23718: ret             
    // 0xb2371c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2371c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xb23720: b               #0xb236e4
    // 0xb23724: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb23724: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ getFillColor(/* No info */) {
    // ** addr: 0xb23728, size: 0x104
    // 0xb23728: EnterFrame
    //     0xb23728: stp             fp, lr, [SP, #-0x10]!
    //     0xb2372c: mov             fp, SP
    // 0xb23730: AllocStack(0x8)
    //     0xb23730: sub             SP, SP, #8
    // 0xb23734: CheckStackOverflow
    //     0xb23734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb23738: cmp             SP, x16
    //     0xb2373c: b.ls            #0xb23820
    // 0xb23740: ldr             x0, [fp, #0x10]
    // 0xb23744: LoadField: r1 = r0->field_b
    //     0xb23744: ldur            w1, [x0, #0xb]
    // 0xb23748: DecompressPointer r1
    //     0xb23748: add             x1, x1, HEAP, lsl #32
    // 0xb2374c: stur            x1, [fp, #-8]
    // 0xb23750: cmp             w1, NULL
    // 0xb23754: b.eq            #0xb23764
    // 0xb23758: LoadField: r2 = r0->field_27
    //     0xb23758: ldur            w2, [x0, #0x27]
    // 0xb2375c: DecompressPointer r2
    //     0xb2375c: add             x2, x2, HEAP, lsl #32
    // 0xb23760: b               #0xb2376c
    // 0xb23764: LoadField: r2 = r0->field_2b
    //     0xb23764: ldur            w2, [x0, #0x2b]
    // 0xb23768: DecompressPointer r2
    //     0xb23768: add             x2, x2, HEAP, lsl #32
    // 0xb2376c: cmp             w2, NULL
    // 0xb23770: b.eq            #0xb23784
    // 0xb23774: mov             x0, x2
    // 0xb23778: LeaveFrame
    //     0xb23778: mov             SP, fp
    //     0xb2377c: ldp             fp, lr, [SP], #0x10
    // 0xb23780: ret
    //     0xb23780: ret             
    // 0xb23784: r16 = MaterialButton
    //     0xb23784: add             x16, PP, #0x50, lsl #12  ; [pp+0x50920] Type: MaterialButton
    //     0xb23788: ldr             x16, [x16, #0x920]
    // 0xb2378c: r30 = MaterialButton
    //     0xb2378c: add             lr, PP, #0x50, lsl #12  ; [pp+0x50920] Type: MaterialButton
    //     0xb23790: ldr             lr, [lr, #0x920]
    // 0xb23794: stp             lr, x16, [SP, #-0x10]!
    // 0xb23798: r0 = ==()
    //     0xb23798: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xb2379c: add             SP, SP, #0x10
    // 0xb237a0: tbnz            w0, #4, #0xb237b4
    // 0xb237a4: r0 = Null
    //     0xb237a4: mov             x0, NULL
    // 0xb237a8: LeaveFrame
    //     0xb237a8: mov             SP, fp
    //     0xb237ac: ldp             fp, lr, [SP], #0x10
    // 0xb237b0: ret
    //     0xb237b0: ret             
    // 0xb237b4: ldur            x0, [fp, #-8]
    // 0xb237b8: cmp             w0, NULL
    // 0xb237bc: b.eq            #0xb237d8
    // 0xb237c0: ldr             x1, [fp, #0x18]
    // 0xb237c4: LoadField: r0 = r1->field_2b
    //     0xb237c4: ldur            w0, [x1, #0x2b]
    // 0xb237c8: DecompressPointer r0
    //     0xb237c8: add             x0, x0, HEAP, lsl #32
    // 0xb237cc: LeaveFrame
    //     0xb237cc: mov             SP, fp
    //     0xb237d0: ldp             fp, lr, [SP], #0x10
    // 0xb237d4: ret
    //     0xb237d4: ret             
    // 0xb237d8: ldr             x1, [fp, #0x18]
    // 0xb237dc: cmp             w0, NULL
    // 0xb237e0: b.eq            #0xb23804
    // 0xb237e4: LoadField: r0 = r1->field_43
    //     0xb237e4: ldur            w0, [x1, #0x43]
    // 0xb237e8: DecompressPointer r0
    //     0xb237e8: add             x0, x0, HEAP, lsl #32
    // 0xb237ec: cmp             w0, NULL
    // 0xb237f0: b.eq            #0xb23828
    // 0xb237f4: LoadField: r1 = r0->field_b
    //     0xb237f4: ldur            w1, [x0, #0xb]
    // 0xb237f8: DecompressPointer r1
    //     0xb237f8: add             x1, x1, HEAP, lsl #32
    // 0xb237fc: mov             x0, x1
    // 0xb23800: b               #0xb23814
    // 0xb23804: ldr             x16, [fp, #0x10]
    // 0xb23808: stp             x16, x1, [SP, #-0x10]!
    // 0xb2380c: r0 = getDisabledFillColor()
    //     0xb2380c: bl              #0xb2382c  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getDisabledFillColor
    // 0xb23810: add             SP, SP, #0x10
    // 0xb23814: LeaveFrame
    //     0xb23814: mov             SP, fp
    //     0xb23818: ldp             fp, lr, [SP], #0x10
    // 0xb2381c: ret
    //     0xb2381c: ret             
    // 0xb23820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23824: b               #0xb23740
    // 0xb23828: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb23828: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getDisabledFillColor(/* No info */) {
    // ** addr: 0xb2382c, size: 0x88
    // 0xb2382c: EnterFrame
    //     0xb2382c: stp             fp, lr, [SP, #-0x10]!
    //     0xb23830: mov             fp, SP
    // 0xb23834: CheckStackOverflow
    //     0xb23834: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb23838: cmp             SP, x16
    //     0xb2383c: b.ls            #0xb238a8
    // 0xb23840: ldr             x0, [fp, #0x10]
    // 0xb23844: LoadField: r1 = r0->field_2b
    //     0xb23844: ldur            w1, [x0, #0x2b]
    // 0xb23848: DecompressPointer r1
    //     0xb23848: add             x1, x1, HEAP, lsl #32
    // 0xb2384c: cmp             w1, NULL
    // 0xb23850: b.ne            #0xb2385c
    // 0xb23854: r0 = Null
    //     0xb23854: mov             x0, NULL
    // 0xb23858: b               #0xb23860
    // 0xb2385c: mov             x0, x1
    // 0xb23860: cmp             w0, NULL
    // 0xb23864: b.ne            #0xb2389c
    // 0xb23868: ldr             x0, [fp, #0x18]
    // 0xb2386c: d0 = 0.380000
    //     0xb2386c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb23870: ldr             d0, [x17, #0x140]
    // 0xb23874: LoadField: r1 = r0->field_43
    //     0xb23874: ldur            w1, [x0, #0x43]
    // 0xb23878: DecompressPointer r1
    //     0xb23878: add             x1, x1, HEAP, lsl #32
    // 0xb2387c: cmp             w1, NULL
    // 0xb23880: b.eq            #0xb238b0
    // 0xb23884: LoadField: r0 = r1->field_57
    //     0xb23884: ldur            w0, [x1, #0x57]
    // 0xb23888: DecompressPointer r0
    //     0xb23888: add             x0, x0, HEAP, lsl #32
    // 0xb2388c: SaveReg r0
    //     0xb2388c: str             x0, [SP, #-8]!
    // 0xb23890: SaveReg d0
    //     0xb23890: str             d0, [SP, #-8]!
    // 0xb23894: r0 = withOpacity()
    //     0xb23894: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb23898: add             SP, SP, #0x10
    // 0xb2389c: LeaveFrame
    //     0xb2389c: mov             SP, fp
    //     0xb238a0: ldp             fp, lr, [SP], #0x10
    // 0xb238a4: ret
    //     0xb238a4: ret             
    // 0xb238a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb238a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb238ac: b               #0xb23840
    // 0xb238b0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb238b0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xb23950, size: 0x158
    // 0xb23950: EnterFrame
    //     0xb23950: stp             fp, lr, [SP, #-0x10]!
    //     0xb23954: mov             fp, SP
    // 0xb23958: AllocStack(0x38)
    //     0xb23958: sub             SP, SP, #0x38
    // 0xb2395c: ldr             x0, [fp, #0x18]
    // 0xb23960: LoadField: r1 = r0->field_1f
    //     0xb23960: ldur            w1, [x0, #0x1f]
    // 0xb23964: DecompressPointer r1
    //     0xb23964: add             x1, x1, HEAP, lsl #32
    // 0xb23968: cmp             w1, NULL
    // 0xb2396c: b.ne            #0xb23998
    // 0xb23970: LoadField: r1 = r0->field_17
    //     0xb23970: ldur            w1, [x0, #0x17]
    // 0xb23974: DecompressPointer r1
    //     0xb23974: add             x1, x1, HEAP, lsl #32
    // 0xb23978: LoadField: r2 = r1->field_7
    //     0xb23978: ldur            x2, [x1, #7]
    // 0xb2397c: cmp             x2, #1
    // 0xb23980: b.gt            #0xb23990
    // 0xb23984: r1 = Instance_EdgeInsets
    //     0xb23984: add             x1, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0xb23988: ldr             x1, [x1, #0x438]
    // 0xb2398c: b               #0xb23998
    // 0xb23990: r1 = Instance_EdgeInsets
    //     0xb23990: add             x1, PP, #0xe, lsl #12  ; [pp+0xe440] Obj!EdgeInsets@b36ec1
    //     0xb23994: ldr             x1, [x1, #0x440]
    // 0xb23998: stur            x1, [fp, #-0x38]
    // 0xb2399c: LoadField: r2 = r0->field_23
    //     0xb2399c: ldur            w2, [x0, #0x23]
    // 0xb239a0: DecompressPointer r2
    //     0xb239a0: add             x2, x2, HEAP, lsl #32
    // 0xb239a4: cmp             w2, NULL
    // 0xb239a8: b.eq            #0xb239b4
    // 0xb239ac: mov             x3, x2
    // 0xb239b0: b               #0xb239dc
    // 0xb239b4: LoadField: r2 = r0->field_17
    //     0xb239b4: ldur            w2, [x0, #0x17]
    // 0xb239b8: DecompressPointer r2
    //     0xb239b8: add             x2, x2, HEAP, lsl #32
    // 0xb239bc: LoadField: r3 = r2->field_7
    //     0xb239bc: ldur            x3, [x2, #7]
    // 0xb239c0: cmp             x3, #1
    // 0xb239c4: b.gt            #0xb239d4
    // 0xb239c8: r3 = Instance_RoundedRectangleBorder
    //     0xb239c8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe448] Obj!RoundedRectangleBorder@b38401
    //     0xb239cc: ldr             x3, [x3, #0x448]
    // 0xb239d0: b               #0xb239dc
    // 0xb239d4: r3 = Instance_RoundedRectangleBorder
    //     0xb239d4: add             x3, PP, #0xe, lsl #12  ; [pp+0xe450] Obj!RoundedRectangleBorder@b383f1
    //     0xb239d8: ldr             x3, [x3, #0x450]
    // 0xb239dc: ldr             x2, [fp, #0x10]
    // 0xb239e0: stur            x3, [fp, #-0x30]
    // 0xb239e4: LoadField: r4 = r0->field_2b
    //     0xb239e4: ldur            w4, [x0, #0x2b]
    // 0xb239e8: DecompressPointer r4
    //     0xb239e8: add             x4, x4, HEAP, lsl #32
    // 0xb239ec: stur            x4, [fp, #-0x28]
    // 0xb239f0: LoadField: r5 = r0->field_33
    //     0xb239f0: ldur            w5, [x0, #0x33]
    // 0xb239f4: DecompressPointer r5
    //     0xb239f4: add             x5, x5, HEAP, lsl #32
    // 0xb239f8: stur            x5, [fp, #-0x20]
    // 0xb239fc: LoadField: r6 = r0->field_37
    //     0xb239fc: ldur            w6, [x0, #0x37]
    // 0xb23a00: DecompressPointer r6
    //     0xb23a00: add             x6, x6, HEAP, lsl #32
    // 0xb23a04: stur            x6, [fp, #-0x18]
    // 0xb23a08: LoadField: r7 = r0->field_3f
    //     0xb23a08: ldur            w7, [x0, #0x3f]
    // 0xb23a0c: DecompressPointer r7
    //     0xb23a0c: add             x7, x7, HEAP, lsl #32
    // 0xb23a10: stur            x7, [fp, #-0x10]
    // 0xb23a14: LoadField: r8 = r0->field_47
    //     0xb23a14: ldur            w8, [x0, #0x47]
    // 0xb23a18: DecompressPointer r8
    //     0xb23a18: add             x8, x8, HEAP, lsl #32
    // 0xb23a1c: stur            x8, [fp, #-8]
    // 0xb23a20: r0 = ButtonThemeData()
    //     0xb23a20: bl              #0x6d252c  ; AllocateButtonThemeDataStub -> ButtonThemeData (size=0x4c)
    // 0xb23a24: r1 = Instance_ButtonTextTheme
    //     0xb23a24: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf98] Obj!ButtonTextTheme@b65951
    //     0xb23a28: ldr             x1, [x1, #0xf98]
    // 0xb23a2c: StoreField: r0->field_17 = r1
    //     0xb23a2c: stur            w1, [x0, #0x17]
    // 0xb23a30: d0 = 88.000000
    //     0xb23a30: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa0] IMM: double(88) from 0x4056000000000000
    //     0xb23a34: ldr             d0, [x17, #0xfa0]
    // 0xb23a38: StoreField: r0->field_7 = d0
    //     0xb23a38: stur            d0, [x0, #7]
    // 0xb23a3c: d0 = 36.000000
    //     0xb23a3c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0xb23a40: ldr             d0, [x17, #0xfa8]
    // 0xb23a44: StoreField: r0->field_f = d0
    //     0xb23a44: stur            d0, [x0, #0xf]
    // 0xb23a48: r1 = Instance_ButtonBarLayoutBehavior
    //     0xb23a48: add             x1, PP, #0xc, lsl #12  ; [pp+0xcfb0] Obj!ButtonBarLayoutBehavior@b65931
    //     0xb23a4c: ldr             x1, [x1, #0xfb0]
    // 0xb23a50: StoreField: r0->field_1b = r1
    //     0xb23a50: stur            w1, [x0, #0x1b]
    // 0xb23a54: r1 = false
    //     0xb23a54: add             x1, NULL, #0x30  ; false
    // 0xb23a58: StoreField: r0->field_27 = r1
    //     0xb23a58: stur            w1, [x0, #0x27]
    // 0xb23a5c: ldr             x1, [fp, #0x10]
    // 0xb23a60: StoreField: r0->field_43 = r1
    //     0xb23a60: stur            w1, [x0, #0x43]
    // 0xb23a64: ldur            x1, [fp, #-0x28]
    // 0xb23a68: StoreField: r0->field_2b = r1
    //     0xb23a68: stur            w1, [x0, #0x2b]
    // 0xb23a6c: ldur            x1, [fp, #-0x20]
    // 0xb23a70: StoreField: r0->field_33 = r1
    //     0xb23a70: stur            w1, [x0, #0x33]
    // 0xb23a74: ldur            x1, [fp, #-0x18]
    // 0xb23a78: StoreField: r0->field_37 = r1
    //     0xb23a78: stur            w1, [x0, #0x37]
    // 0xb23a7c: ldur            x1, [fp, #-0x10]
    // 0xb23a80: StoreField: r0->field_3f = r1
    //     0xb23a80: stur            w1, [x0, #0x3f]
    // 0xb23a84: ldur            x1, [fp, #-0x38]
    // 0xb23a88: StoreField: r0->field_1f = r1
    //     0xb23a88: stur            w1, [x0, #0x1f]
    // 0xb23a8c: ldur            x1, [fp, #-0x30]
    // 0xb23a90: StoreField: r0->field_23 = r1
    //     0xb23a90: stur            w1, [x0, #0x23]
    // 0xb23a94: ldur            x1, [fp, #-8]
    // 0xb23a98: StoreField: r0->field_47 = r1
    //     0xb23a98: stur            w1, [x0, #0x47]
    // 0xb23a9c: LeaveFrame
    //     0xb23a9c: mov             SP, fp
    //     0xb23aa0: ldp             fp, lr, [SP], #0x10
    // 0xb23aa4: ret
    //     0xb23aa4: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0xc84a30, size: 0x370
    // 0xc84a30: EnterFrame
    //     0xc84a30: stp             fp, lr, [SP, #-0x10]!
    //     0xc84a34: mov             fp, SP
    // 0xc84a38: CheckStackOverflow
    //     0xc84a38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc84a3c: cmp             SP, x16
    //     0xc84a40: b.ls            #0xc84d98
    // 0xc84a44: ldr             x1, [fp, #0x10]
    // 0xc84a48: cmp             w1, NULL
    // 0xc84a4c: b.ne            #0xc84a60
    // 0xc84a50: r0 = false
    //     0xc84a50: add             x0, NULL, #0x30  ; false
    // 0xc84a54: LeaveFrame
    //     0xc84a54: mov             SP, fp
    //     0xc84a58: ldp             fp, lr, [SP], #0x10
    // 0xc84a5c: ret
    //     0xc84a5c: ret             
    // 0xc84a60: r0 = 59
    //     0xc84a60: mov             x0, #0x3b
    // 0xc84a64: branchIfSmi(r1, 0xc84a70)
    //     0xc84a64: tbz             w1, #0, #0xc84a70
    // 0xc84a68: r0 = LoadClassIdInstr(r1)
    //     0xc84a68: ldur            x0, [x1, #-1]
    //     0xc84a6c: ubfx            x0, x0, #0xc, #0x14
    // 0xc84a70: SaveReg r1
    //     0xc84a70: str             x1, [SP, #-8]!
    // 0xc84a74: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc84a74: mov             x17, #0x57c5
    //     0xc84a78: add             lr, x0, x17
    //     0xc84a7c: ldr             lr, [x21, lr, lsl #3]
    //     0xc84a80: blr             lr
    // 0xc84a84: add             SP, SP, #8
    // 0xc84a88: r1 = LoadClassIdInstr(r0)
    //     0xc84a88: ldur            x1, [x0, #-1]
    //     0xc84a8c: ubfx            x1, x1, #0xc, #0x14
    // 0xc84a90: r16 = ButtonThemeData
    //     0xc84a90: add             x16, PP, #0xe, lsl #12  ; [pp+0xe460] Type: ButtonThemeData
    //     0xc84a94: ldr             x16, [x16, #0x460]
    // 0xc84a98: stp             x16, x0, [SP, #-0x10]!
    // 0xc84a9c: mov             x0, x1
    // 0xc84aa0: mov             lr, x0
    // 0xc84aa4: ldr             lr, [x21, lr, lsl #3]
    // 0xc84aa8: blr             lr
    // 0xc84aac: add             SP, SP, #0x10
    // 0xc84ab0: tbz             w0, #4, #0xc84ac4
    // 0xc84ab4: r0 = false
    //     0xc84ab4: add             x0, NULL, #0x30  ; false
    // 0xc84ab8: LeaveFrame
    //     0xc84ab8: mov             SP, fp
    //     0xc84abc: ldp             fp, lr, [SP], #0x10
    // 0xc84ac0: ret
    //     0xc84ac0: ret             
    // 0xc84ac4: ldr             x0, [fp, #0x10]
    // 0xc84ac8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc84ac8: mov             x1, #0x76
    //     0xc84acc: tbz             w0, #0, #0xc84adc
    //     0xc84ad0: ldur            x1, [x0, #-1]
    //     0xc84ad4: ubfx            x1, x1, #0xc, #0x14
    //     0xc84ad8: lsl             x1, x1, #1
    // 0xc84adc: r17 = 5640
    //     0xc84adc: mov             x17, #0x1608
    // 0xc84ae0: cmp             w1, w17
    // 0xc84ae4: b.ne            #0xc84d88
    // 0xc84ae8: d0 = 88.000000
    //     0xc84ae8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa0] IMM: double(88) from 0x4056000000000000
    //     0xc84aec: ldr             d0, [x17, #0xfa0]
    // 0xc84af0: fcmp            d0, d0
    // 0xc84af4: b.vs            #0xc84d88
    // 0xc84af8: b.ne            #0xc84d88
    // 0xc84afc: d0 = 36.000000
    //     0xc84afc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0xc84b00: ldr             d0, [x17, #0xfa8]
    // 0xc84b04: fcmp            d0, d0
    // 0xc84b08: b.vs            #0xc84d88
    // 0xc84b0c: b.ne            #0xc84d88
    // 0xc84b10: LoadField: r1 = r0->field_1f
    //     0xc84b10: ldur            w1, [x0, #0x1f]
    // 0xc84b14: DecompressPointer r1
    //     0xc84b14: add             x1, x1, HEAP, lsl #32
    // 0xc84b18: cmp             w1, NULL
    // 0xc84b1c: b.eq            #0xc84b28
    // 0xc84b20: mov             x2, x1
    // 0xc84b24: b               #0xc84b50
    // 0xc84b28: LoadField: r1 = r0->field_17
    //     0xc84b28: ldur            w1, [x0, #0x17]
    // 0xc84b2c: DecompressPointer r1
    //     0xc84b2c: add             x1, x1, HEAP, lsl #32
    // 0xc84b30: LoadField: r2 = r1->field_7
    //     0xc84b30: ldur            x2, [x1, #7]
    // 0xc84b34: cmp             x2, #1
    // 0xc84b38: b.gt            #0xc84b48
    // 0xc84b3c: r2 = Instance_EdgeInsets
    //     0xc84b3c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0xc84b40: ldr             x2, [x2, #0x438]
    // 0xc84b44: b               #0xc84b50
    // 0xc84b48: r2 = Instance_EdgeInsets
    //     0xc84b48: add             x2, PP, #0xe, lsl #12  ; [pp+0xe440] Obj!EdgeInsets@b36ec1
    //     0xc84b4c: ldr             x2, [x2, #0x440]
    // 0xc84b50: ldr             x1, [fp, #0x18]
    // 0xc84b54: LoadField: r3 = r1->field_1f
    //     0xc84b54: ldur            w3, [x1, #0x1f]
    // 0xc84b58: DecompressPointer r3
    //     0xc84b58: add             x3, x3, HEAP, lsl #32
    // 0xc84b5c: cmp             w3, NULL
    // 0xc84b60: b.ne            #0xc84b8c
    // 0xc84b64: LoadField: r3 = r1->field_17
    //     0xc84b64: ldur            w3, [x1, #0x17]
    // 0xc84b68: DecompressPointer r3
    //     0xc84b68: add             x3, x3, HEAP, lsl #32
    // 0xc84b6c: LoadField: r4 = r3->field_7
    //     0xc84b6c: ldur            x4, [x3, #7]
    // 0xc84b70: cmp             x4, #1
    // 0xc84b74: b.gt            #0xc84b84
    // 0xc84b78: r3 = Instance_EdgeInsets
    //     0xc84b78: add             x3, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0xc84b7c: ldr             x3, [x3, #0x438]
    // 0xc84b80: b               #0xc84b8c
    // 0xc84b84: r3 = Instance_EdgeInsets
    //     0xc84b84: add             x3, PP, #0xe, lsl #12  ; [pp+0xe440] Obj!EdgeInsets@b36ec1
    //     0xc84b88: ldr             x3, [x3, #0x440]
    // 0xc84b8c: stp             x3, x2, [SP, #-0x10]!
    // 0xc84b90: r0 = ==()
    //     0xc84b90: bl              #0xc9d2f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0xc84b94: add             SP, SP, #0x10
    // 0xc84b98: tbnz            w0, #4, #0xc84d88
    // 0xc84b9c: ldr             x0, [fp, #0x10]
    // 0xc84ba0: LoadField: r1 = r0->field_23
    //     0xc84ba0: ldur            w1, [x0, #0x23]
    // 0xc84ba4: DecompressPointer r1
    //     0xc84ba4: add             x1, x1, HEAP, lsl #32
    // 0xc84ba8: cmp             w1, NULL
    // 0xc84bac: b.eq            #0xc84bb8
    // 0xc84bb0: mov             x2, x1
    // 0xc84bb4: b               #0xc84be0
    // 0xc84bb8: LoadField: r1 = r0->field_17
    //     0xc84bb8: ldur            w1, [x0, #0x17]
    // 0xc84bbc: DecompressPointer r1
    //     0xc84bbc: add             x1, x1, HEAP, lsl #32
    // 0xc84bc0: LoadField: r2 = r1->field_7
    //     0xc84bc0: ldur            x2, [x1, #7]
    // 0xc84bc4: cmp             x2, #1
    // 0xc84bc8: b.gt            #0xc84bd8
    // 0xc84bcc: r2 = Instance_RoundedRectangleBorder
    //     0xc84bcc: add             x2, PP, #0xe, lsl #12  ; [pp+0xe448] Obj!RoundedRectangleBorder@b38401
    //     0xc84bd0: ldr             x2, [x2, #0x448]
    // 0xc84bd4: b               #0xc84be0
    // 0xc84bd8: r2 = Instance_RoundedRectangleBorder
    //     0xc84bd8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe450] Obj!RoundedRectangleBorder@b383f1
    //     0xc84bdc: ldr             x2, [x2, #0x450]
    // 0xc84be0: ldr             x1, [fp, #0x18]
    // 0xc84be4: LoadField: r3 = r1->field_23
    //     0xc84be4: ldur            w3, [x1, #0x23]
    // 0xc84be8: DecompressPointer r3
    //     0xc84be8: add             x3, x3, HEAP, lsl #32
    // 0xc84bec: cmp             w3, NULL
    // 0xc84bf0: b.ne            #0xc84c1c
    // 0xc84bf4: LoadField: r3 = r1->field_17
    //     0xc84bf4: ldur            w3, [x1, #0x17]
    // 0xc84bf8: DecompressPointer r3
    //     0xc84bf8: add             x3, x3, HEAP, lsl #32
    // 0xc84bfc: LoadField: r4 = r3->field_7
    //     0xc84bfc: ldur            x4, [x3, #7]
    // 0xc84c00: cmp             x4, #1
    // 0xc84c04: b.gt            #0xc84c14
    // 0xc84c08: r3 = Instance_RoundedRectangleBorder
    //     0xc84c08: add             x3, PP, #0xe, lsl #12  ; [pp+0xe448] Obj!RoundedRectangleBorder@b38401
    //     0xc84c0c: ldr             x3, [x3, #0x448]
    // 0xc84c10: b               #0xc84c1c
    // 0xc84c14: r3 = Instance_RoundedRectangleBorder
    //     0xc84c14: add             x3, PP, #0xe, lsl #12  ; [pp+0xe450] Obj!RoundedRectangleBorder@b383f1
    //     0xc84c18: ldr             x3, [x3, #0x450]
    // 0xc84c1c: stp             x3, x2, [SP, #-0x10]!
    // 0xc84c20: r0 = ==()
    //     0xc84c20: bl              #0xc99a40  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::==
    // 0xc84c24: add             SP, SP, #0x10
    // 0xc84c28: tbnz            w0, #4, #0xc84d88
    // 0xc84c2c: ldr             x2, [fp, #0x18]
    // 0xc84c30: ldr             x1, [fp, #0x10]
    // 0xc84c34: LoadField: r0 = r1->field_2b
    //     0xc84c34: ldur            w0, [x1, #0x2b]
    // 0xc84c38: DecompressPointer r0
    //     0xc84c38: add             x0, x0, HEAP, lsl #32
    // 0xc84c3c: LoadField: r3 = r2->field_2b
    //     0xc84c3c: ldur            w3, [x2, #0x2b]
    // 0xc84c40: DecompressPointer r3
    //     0xc84c40: add             x3, x3, HEAP, lsl #32
    // 0xc84c44: r4 = LoadClassIdInstr(r0)
    //     0xc84c44: ldur            x4, [x0, #-1]
    //     0xc84c48: ubfx            x4, x4, #0xc, #0x14
    // 0xc84c4c: stp             x3, x0, [SP, #-0x10]!
    // 0xc84c50: mov             x0, x4
    // 0xc84c54: mov             lr, x0
    // 0xc84c58: ldr             lr, [x21, lr, lsl #3]
    // 0xc84c5c: blr             lr
    // 0xc84c60: add             SP, SP, #0x10
    // 0xc84c64: tbnz            w0, #4, #0xc84d88
    // 0xc84c68: ldr             x2, [fp, #0x18]
    // 0xc84c6c: ldr             x1, [fp, #0x10]
    // 0xc84c70: LoadField: r0 = r1->field_33
    //     0xc84c70: ldur            w0, [x1, #0x33]
    // 0xc84c74: DecompressPointer r0
    //     0xc84c74: add             x0, x0, HEAP, lsl #32
    // 0xc84c78: LoadField: r3 = r2->field_33
    //     0xc84c78: ldur            w3, [x2, #0x33]
    // 0xc84c7c: DecompressPointer r3
    //     0xc84c7c: add             x3, x3, HEAP, lsl #32
    // 0xc84c80: r4 = LoadClassIdInstr(r0)
    //     0xc84c80: ldur            x4, [x0, #-1]
    //     0xc84c84: ubfx            x4, x4, #0xc, #0x14
    // 0xc84c88: stp             x3, x0, [SP, #-0x10]!
    // 0xc84c8c: mov             x0, x4
    // 0xc84c90: mov             lr, x0
    // 0xc84c94: ldr             lr, [x21, lr, lsl #3]
    // 0xc84c98: blr             lr
    // 0xc84c9c: add             SP, SP, #0x10
    // 0xc84ca0: tbnz            w0, #4, #0xc84d88
    // 0xc84ca4: ldr             x2, [fp, #0x18]
    // 0xc84ca8: ldr             x1, [fp, #0x10]
    // 0xc84cac: LoadField: r0 = r1->field_37
    //     0xc84cac: ldur            w0, [x1, #0x37]
    // 0xc84cb0: DecompressPointer r0
    //     0xc84cb0: add             x0, x0, HEAP, lsl #32
    // 0xc84cb4: LoadField: r3 = r2->field_37
    //     0xc84cb4: ldur            w3, [x2, #0x37]
    // 0xc84cb8: DecompressPointer r3
    //     0xc84cb8: add             x3, x3, HEAP, lsl #32
    // 0xc84cbc: r4 = LoadClassIdInstr(r0)
    //     0xc84cbc: ldur            x4, [x0, #-1]
    //     0xc84cc0: ubfx            x4, x4, #0xc, #0x14
    // 0xc84cc4: stp             x3, x0, [SP, #-0x10]!
    // 0xc84cc8: mov             x0, x4
    // 0xc84ccc: mov             lr, x0
    // 0xc84cd0: ldr             lr, [x21, lr, lsl #3]
    // 0xc84cd4: blr             lr
    // 0xc84cd8: add             SP, SP, #0x10
    // 0xc84cdc: tbnz            w0, #4, #0xc84d88
    // 0xc84ce0: ldr             x2, [fp, #0x18]
    // 0xc84ce4: ldr             x1, [fp, #0x10]
    // 0xc84ce8: LoadField: r0 = r1->field_3f
    //     0xc84ce8: ldur            w0, [x1, #0x3f]
    // 0xc84cec: DecompressPointer r0
    //     0xc84cec: add             x0, x0, HEAP, lsl #32
    // 0xc84cf0: LoadField: r3 = r2->field_3f
    //     0xc84cf0: ldur            w3, [x2, #0x3f]
    // 0xc84cf4: DecompressPointer r3
    //     0xc84cf4: add             x3, x3, HEAP, lsl #32
    // 0xc84cf8: r4 = LoadClassIdInstr(r0)
    //     0xc84cf8: ldur            x4, [x0, #-1]
    //     0xc84cfc: ubfx            x4, x4, #0xc, #0x14
    // 0xc84d00: stp             x3, x0, [SP, #-0x10]!
    // 0xc84d04: mov             x0, x4
    // 0xc84d08: mov             lr, x0
    // 0xc84d0c: ldr             lr, [x21, lr, lsl #3]
    // 0xc84d10: blr             lr
    // 0xc84d14: add             SP, SP, #0x10
    // 0xc84d18: tbnz            w0, #4, #0xc84d88
    // 0xc84d1c: ldr             x2, [fp, #0x18]
    // 0xc84d20: ldr             x1, [fp, #0x10]
    // 0xc84d24: LoadField: r0 = r1->field_43
    //     0xc84d24: ldur            w0, [x1, #0x43]
    // 0xc84d28: DecompressPointer r0
    //     0xc84d28: add             x0, x0, HEAP, lsl #32
    // 0xc84d2c: LoadField: r3 = r2->field_43
    //     0xc84d2c: ldur            w3, [x2, #0x43]
    // 0xc84d30: DecompressPointer r3
    //     0xc84d30: add             x3, x3, HEAP, lsl #32
    // 0xc84d34: r4 = LoadClassIdInstr(r0)
    //     0xc84d34: ldur            x4, [x0, #-1]
    //     0xc84d38: ubfx            x4, x4, #0xc, #0x14
    // 0xc84d3c: stp             x3, x0, [SP, #-0x10]!
    // 0xc84d40: mov             x0, x4
    // 0xc84d44: mov             lr, x0
    // 0xc84d48: ldr             lr, [x21, lr, lsl #3]
    // 0xc84d4c: blr             lr
    // 0xc84d50: add             SP, SP, #0x10
    // 0xc84d54: tbnz            w0, #4, #0xc84d88
    // 0xc84d58: ldr             x2, [fp, #0x18]
    // 0xc84d5c: ldr             x1, [fp, #0x10]
    // 0xc84d60: LoadField: r3 = r1->field_47
    //     0xc84d60: ldur            w3, [x1, #0x47]
    // 0xc84d64: DecompressPointer r3
    //     0xc84d64: add             x3, x3, HEAP, lsl #32
    // 0xc84d68: LoadField: r1 = r2->field_47
    //     0xc84d68: ldur            w1, [x2, #0x47]
    // 0xc84d6c: DecompressPointer r1
    //     0xc84d6c: add             x1, x1, HEAP, lsl #32
    // 0xc84d70: cmp             w3, w1
    // 0xc84d74: r16 = true
    //     0xc84d74: add             x16, NULL, #0x20  ; true
    // 0xc84d78: r17 = false
    //     0xc84d78: add             x17, NULL, #0x30  ; false
    // 0xc84d7c: csel            x2, x16, x17, eq
    // 0xc84d80: mov             x0, x2
    // 0xc84d84: b               #0xc84d8c
    // 0xc84d88: r0 = false
    //     0xc84d88: add             x0, NULL, #0x30  ; false
    // 0xc84d8c: LeaveFrame
    //     0xc84d8c: mov             SP, fp
    //     0xc84d90: ldp             fp, lr, [SP], #0x10
    // 0xc84d94: ret
    //     0xc84d94: ret             
    // 0xc84d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc84d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc84d9c: b               #0xc84a44
  }
}

// class id: 3549, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xb238b4, size: 0x9c
    // 0xb238b4: EnterFrame
    //     0xb238b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb238b8: mov             fp, SP
    // 0xb238bc: CheckStackOverflow
    //     0xb238bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb238c0: cmp             SP, x16
    //     0xb238c4: b.ls            #0xb23948
    // 0xb238c8: r16 = <ButtonTheme>
    //     0xb238c8: add             x16, PP, #0x50, lsl #12  ; [pp+0x50928] TypeArguments: <ButtonTheme>
    //     0xb238cc: ldr             x16, [x16, #0x928]
    // 0xb238d0: ldr             lr, [fp, #0x10]
    // 0xb238d4: stp             lr, x16, [SP, #-0x10]!
    // 0xb238d8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb238d8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb238dc: r0 = dependOnInheritedWidgetOfExactType()
    //     0xb238dc: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xb238e0: add             SP, SP, #0x10
    // 0xb238e4: ldr             x16, [fp, #0x10]
    // 0xb238e8: SaveReg r16
    //     0xb238e8: str             x16, [SP, #-8]!
    // 0xb238ec: r0 = of()
    //     0xb238ec: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb238f0: add             SP, SP, #8
    // 0xb238f4: LoadField: r1 = r0->field_b7
    //     0xb238f4: ldur            w1, [x0, #0xb7]
    // 0xb238f8: DecompressPointer r1
    //     0xb238f8: add             x1, x1, HEAP, lsl #32
    // 0xb238fc: LoadField: r2 = r1->field_43
    //     0xb238fc: ldur            w2, [x1, #0x43]
    // 0xb23900: DecompressPointer r2
    //     0xb23900: add             x2, x2, HEAP, lsl #32
    // 0xb23904: cmp             w2, NULL
    // 0xb23908: b.ne            #0xb23938
    // 0xb2390c: cmp             w2, NULL
    // 0xb23910: b.ne            #0xb23924
    // 0xb23914: LoadField: r2 = r0->field_3f
    //     0xb23914: ldur            w2, [x0, #0x3f]
    // 0xb23918: DecompressPointer r2
    //     0xb23918: add             x2, x2, HEAP, lsl #32
    // 0xb2391c: mov             x0, x2
    // 0xb23920: b               #0xb23928
    // 0xb23924: mov             x0, x2
    // 0xb23928: stp             x0, x1, [SP, #-0x10]!
    // 0xb2392c: r0 = copyWith()
    //     0xb2392c: bl              #0xb23950  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::copyWith
    // 0xb23930: add             SP, SP, #0x10
    // 0xb23934: b               #0xb2393c
    // 0xb23938: mov             x0, x1
    // 0xb2393c: LeaveFrame
    //     0xb2393c: mov             SP, fp
    //     0xb23940: ldp             fp, lr, [SP], #0x10
    // 0xb23944: ret
    //     0xb23944: ret             
    // 0xb23948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23948: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2394c: b               #0xb238c8
  }
}

// class id: 5969, size: 0x14, field offset: 0x14
enum ButtonBarLayoutBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16024, size: 0x5c
    // 0xb16024: EnterFrame
    //     0xb16024: stp             fp, lr, [SP, #-0x10]!
    //     0xb16028: mov             fp, SP
    // 0xb1602c: CheckStackOverflow
    //     0xb1602c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16030: cmp             SP, x16
    //     0xb16034: b.ls            #0xb16078
    // 0xb16038: r1 = Null
    //     0xb16038: mov             x1, NULL
    // 0xb1603c: r2 = 4
    //     0xb1603c: mov             x2, #4
    // 0xb16040: r0 = AllocateArray()
    //     0xb16040: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16044: r17 = "ButtonBarLayoutBehavior."
    //     0xb16044: add             x17, PP, #0xe, lsl #12  ; [pp+0xe488] "ButtonBarLayoutBehavior."
    //     0xb16048: ldr             x17, [x17, #0x488]
    // 0xb1604c: StoreField: r0->field_f = r17
    //     0xb1604c: stur            w17, [x0, #0xf]
    // 0xb16050: ldr             x1, [fp, #0x10]
    // 0xb16054: LoadField: r2 = r1->field_f
    //     0xb16054: ldur            w2, [x1, #0xf]
    // 0xb16058: DecompressPointer r2
    //     0xb16058: add             x2, x2, HEAP, lsl #32
    // 0xb1605c: StoreField: r0->field_13 = r2
    //     0xb1605c: stur            w2, [x0, #0x13]
    // 0xb16060: SaveReg r0
    //     0xb16060: str             x0, [SP, #-8]!
    // 0xb16064: r0 = _interpolate()
    //     0xb16064: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16068: add             SP, SP, #8
    // 0xb1606c: LeaveFrame
    //     0xb1606c: mov             SP, fp
    //     0xb16070: ldp             fp, lr, [SP], #0x10
    // 0xb16074: ret
    //     0xb16074: ret             
    // 0xb16078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1607c: b               #0xb16038
  }
}

// class id: 5970, size: 0x14, field offset: 0x14
enum ButtonTextTheme extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15fc8, size: 0x5c
    // 0xb15fc8: EnterFrame
    //     0xb15fc8: stp             fp, lr, [SP, #-0x10]!
    //     0xb15fcc: mov             fp, SP
    // 0xb15fd0: CheckStackOverflow
    //     0xb15fd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15fd4: cmp             SP, x16
    //     0xb15fd8: b.ls            #0xb1601c
    // 0xb15fdc: r1 = Null
    //     0xb15fdc: mov             x1, NULL
    // 0xb15fe0: r2 = 4
    //     0xb15fe0: mov             x2, #4
    // 0xb15fe4: r0 = AllocateArray()
    //     0xb15fe4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15fe8: r17 = "ButtonTextTheme."
    //     0xb15fe8: add             x17, PP, #0xe, lsl #12  ; [pp+0xe480] "ButtonTextTheme."
    //     0xb15fec: ldr             x17, [x17, #0x480]
    // 0xb15ff0: StoreField: r0->field_f = r17
    //     0xb15ff0: stur            w17, [x0, #0xf]
    // 0xb15ff4: ldr             x1, [fp, #0x10]
    // 0xb15ff8: LoadField: r2 = r1->field_f
    //     0xb15ff8: ldur            w2, [x1, #0xf]
    // 0xb15ffc: DecompressPointer r2
    //     0xb15ffc: add             x2, x2, HEAP, lsl #32
    // 0xb16000: StoreField: r0->field_13 = r2
    //     0xb16000: stur            w2, [x0, #0x13]
    // 0xb16004: SaveReg r0
    //     0xb16004: str             x0, [SP, #-8]!
    // 0xb16008: r0 = _interpolate()
    //     0xb16008: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb1600c: add             SP, SP, #8
    // 0xb16010: LeaveFrame
    //     0xb16010: mov             SP, fp
    //     0xb16014: ldp             fp, lr, [SP], #0x10
    // 0xb16018: ret
    //     0xb16018: ret             
    // 0xb1601c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1601c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16020: b               #0xb15fdc
  }
}

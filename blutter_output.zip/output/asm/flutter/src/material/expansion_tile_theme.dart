// lib: , url: package:flutter/src/material/expansion_tile_theme.dart

// class id: 1049239, size: 0x8
class :: {
}

// class id: 2802, size: 0x38, field offset: 0x8
//   const constructor, 
class ExpansionTileThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xaff39c, size: 0x68
    // 0xaff39c: EnterFrame
    //     0xaff39c: stp             fp, lr, [SP, #-0x10]!
    //     0xaff3a0: mov             fp, SP
    // 0xaff3a4: CheckStackOverflow
    //     0xaff3a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaff3a8: cmp             SP, x16
    //     0xaff3ac: b.ls            #0xaff3fc
    // 0xaff3b0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff3b4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff3b8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff3bc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff3c0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff3c4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff3c8: r4 = const [0, 0xc, 0xc, 0xc, null]
    //     0xaff3c8: add             x4, PP, #0xe, lsl #12  ; [pp+0xe110] List(5) [0, 0xc, 0xc, 0xc, Null]
    //     0xaff3cc: ldr             x4, [x4, #0x110]
    // 0xaff3d0: r0 = hash()
    //     0xaff3d0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaff3d4: add             SP, SP, #0x60
    // 0xaff3d8: mov             x2, x0
    // 0xaff3dc: r0 = BoxInt64Instr(r2)
    //     0xaff3dc: sbfiz           x0, x2, #1, #0x1f
    //     0xaff3e0: cmp             x2, x0, asr #1
    //     0xaff3e4: b.eq            #0xaff3f0
    //     0xaff3e8: bl              #0xd69bb8
    //     0xaff3ec: stur            x2, [x0, #7]
    // 0xaff3f0: LeaveFrame
    //     0xaff3f0: mov             SP, fp
    //     0xaff3f4: ldp             fp, lr, [SP], #0x10
    // 0xaff3f8: ret
    //     0xaff3f8: ret             
    // 0xaff3fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaff3fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaff400: b               #0xaff3b0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf49f8, size: 0x120
    // 0xbf49f8: EnterFrame
    //     0xbf49f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf49fc: mov             fp, SP
    // 0xbf4a00: AllocStack(0x8)
    //     0xbf4a00: sub             SP, SP, #8
    // 0xbf4a04: CheckStackOverflow
    //     0xbf4a04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4a08: cmp             SP, x16
    //     0xbf4a0c: b.ls            #0xbf4b00
    // 0xbf4a10: ldr             d0, [fp, #0x10]
    // 0xbf4a14: r0 = inline_Allocate_Double()
    //     0xbf4a14: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf4a18: add             x0, x0, #0x10
    //     0xbf4a1c: cmp             x1, x0
    //     0xbf4a20: b.ls            #0xbf4b08
    //     0xbf4a24: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf4a28: sub             x0, x0, #0xf
    //     0xbf4a2c: mov             x1, #0xd108
    //     0xbf4a30: movk            x1, #3, lsl #16
    //     0xbf4a34: stur            x1, [x0, #-1]
    // 0xbf4a38: StoreField: r0->field_7 = d0
    //     0xbf4a38: stur            d0, [x0, #7]
    // 0xbf4a3c: stur            x0, [fp, #-8]
    // 0xbf4a40: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4a44: SaveReg r0
    //     0xbf4a44: str             x0, [SP, #-8]!
    // 0xbf4a48: r0 = lerp()
    //     0xbf4a48: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4a4c: add             SP, SP, #0x18
    // 0xbf4a50: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4a54: ldur            x16, [fp, #-8]
    // 0xbf4a58: SaveReg r16
    //     0xbf4a58: str             x16, [SP, #-8]!
    // 0xbf4a5c: r0 = lerp()
    //     0xbf4a5c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4a60: add             SP, SP, #0x18
    // 0xbf4a64: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4a68: ldur            x16, [fp, #-8]
    // 0xbf4a6c: SaveReg r16
    //     0xbf4a6c: str             x16, [SP, #-8]!
    // 0xbf4a70: r0 = lerp()
    //     0xbf4a70: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf4a74: add             SP, SP, #0x18
    // 0xbf4a78: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4a7c: ldr             d0, [fp, #0x10]
    // 0xbf4a80: SaveReg d0
    //     0xbf4a80: str             d0, [SP, #-8]!
    // 0xbf4a84: r0 = lerp()
    //     0xbf4a84: bl              #0xbefd44  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0xbf4a88: add             SP, SP, #0x18
    // 0xbf4a8c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4a90: ldur            x16, [fp, #-8]
    // 0xbf4a94: SaveReg r16
    //     0xbf4a94: str             x16, [SP, #-8]!
    // 0xbf4a98: r0 = lerp()
    //     0xbf4a98: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf4a9c: add             SP, SP, #0x18
    // 0xbf4aa0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4aa4: ldur            x16, [fp, #-8]
    // 0xbf4aa8: SaveReg r16
    //     0xbf4aa8: str             x16, [SP, #-8]!
    // 0xbf4aac: r0 = lerp()
    //     0xbf4aac: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4ab0: add             SP, SP, #0x18
    // 0xbf4ab4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4ab8: ldur            x16, [fp, #-8]
    // 0xbf4abc: SaveReg r16
    //     0xbf4abc: str             x16, [SP, #-8]!
    // 0xbf4ac0: r0 = lerp()
    //     0xbf4ac0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4ac4: add             SP, SP, #0x18
    // 0xbf4ac8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4acc: ldur            x16, [fp, #-8]
    // 0xbf4ad0: SaveReg r16
    //     0xbf4ad0: str             x16, [SP, #-8]!
    // 0xbf4ad4: r0 = lerp()
    //     0xbf4ad4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4ad8: add             SP, SP, #0x18
    // 0xbf4adc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4ae0: ldur            x16, [fp, #-8]
    // 0xbf4ae4: SaveReg r16
    //     0xbf4ae4: str             x16, [SP, #-8]!
    // 0xbf4ae8: r0 = lerp()
    //     0xbf4ae8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4aec: add             SP, SP, #0x18
    // 0xbf4af0: r0 = ExpansionTileThemeData()
    //     0xbf4af0: bl              #0xbf4b18  ; AllocateExpansionTileThemeDataStub -> ExpansionTileThemeData (size=0x38)
    // 0xbf4af4: LeaveFrame
    //     0xbf4af4: mov             SP, fp
    //     0xbf4af8: ldp             fp, lr, [SP], #0x10
    // 0xbf4afc: ret
    //     0xbf4afc: ret             
    // 0xbf4b00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf4b00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf4b04: b               #0xbf4a10
    // 0xbf4b08: SaveReg d0
    //     0xbf4b08: str             q0, [SP, #-0x10]!
    // 0xbf4b0c: r0 = AllocateDouble()
    //     0xbf4b0c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf4b10: RestoreReg d0
    //     0xbf4b10: ldr             q0, [SP], #0x10
    // 0xbf4b14: b               #0xbf4a38
  }
  _ ==(/* No info */) {
    // ** addr: 0xc88a94, size: 0xf4
    // 0xc88a94: EnterFrame
    //     0xc88a94: stp             fp, lr, [SP, #-0x10]!
    //     0xc88a98: mov             fp, SP
    // 0xc88a9c: CheckStackOverflow
    //     0xc88a9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc88aa0: cmp             SP, x16
    //     0xc88aa4: b.ls            #0xc88b80
    // 0xc88aa8: ldr             x1, [fp, #0x10]
    // 0xc88aac: cmp             w1, NULL
    // 0xc88ab0: b.ne            #0xc88ac4
    // 0xc88ab4: r0 = false
    //     0xc88ab4: add             x0, NULL, #0x30  ; false
    // 0xc88ab8: LeaveFrame
    //     0xc88ab8: mov             SP, fp
    //     0xc88abc: ldp             fp, lr, [SP], #0x10
    // 0xc88ac0: ret
    //     0xc88ac0: ret             
    // 0xc88ac4: ldr             x0, [fp, #0x18]
    // 0xc88ac8: cmp             w0, w1
    // 0xc88acc: b.ne            #0xc88ae0
    // 0xc88ad0: r0 = true
    //     0xc88ad0: add             x0, NULL, #0x20  ; true
    // 0xc88ad4: LeaveFrame
    //     0xc88ad4: mov             SP, fp
    //     0xc88ad8: ldp             fp, lr, [SP], #0x10
    // 0xc88adc: ret
    //     0xc88adc: ret             
    // 0xc88ae0: r0 = 59
    //     0xc88ae0: mov             x0, #0x3b
    // 0xc88ae4: branchIfSmi(r1, 0xc88af0)
    //     0xc88ae4: tbz             w1, #0, #0xc88af0
    // 0xc88ae8: r0 = LoadClassIdInstr(r1)
    //     0xc88ae8: ldur            x0, [x1, #-1]
    //     0xc88aec: ubfx            x0, x0, #0xc, #0x14
    // 0xc88af0: SaveReg r1
    //     0xc88af0: str             x1, [SP, #-8]!
    // 0xc88af4: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc88af4: mov             x17, #0x57c5
    //     0xc88af8: add             lr, x0, x17
    //     0xc88afc: ldr             lr, [x21, lr, lsl #3]
    //     0xc88b00: blr             lr
    // 0xc88b04: add             SP, SP, #8
    // 0xc88b08: r1 = LoadClassIdInstr(r0)
    //     0xc88b08: ldur            x1, [x0, #-1]
    //     0xc88b0c: ubfx            x1, x1, #0xc, #0x14
    // 0xc88b10: r16 = ExpansionTileThemeData
    //     0xc88b10: add             x16, PP, #0xe, lsl #12  ; [pp+0xe398] Type: ExpansionTileThemeData
    //     0xc88b14: ldr             x16, [x16, #0x398]
    // 0xc88b18: stp             x16, x0, [SP, #-0x10]!
    // 0xc88b1c: mov             x0, x1
    // 0xc88b20: mov             lr, x0
    // 0xc88b24: ldr             lr, [x21, lr, lsl #3]
    // 0xc88b28: blr             lr
    // 0xc88b2c: add             SP, SP, #0x10
    // 0xc88b30: tbz             w0, #4, #0xc88b44
    // 0xc88b34: r0 = false
    //     0xc88b34: add             x0, NULL, #0x30  ; false
    // 0xc88b38: LeaveFrame
    //     0xc88b38: mov             SP, fp
    //     0xc88b3c: ldp             fp, lr, [SP], #0x10
    // 0xc88b40: ret
    //     0xc88b40: ret             
    // 0xc88b44: ldr             x1, [fp, #0x10]
    // 0xc88b48: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc88b48: mov             x2, #0x76
    //     0xc88b4c: tbz             w1, #0, #0xc88b5c
    //     0xc88b50: ldur            x2, [x1, #-1]
    //     0xc88b54: ubfx            x2, x2, #0xc, #0x14
    //     0xc88b58: lsl             x2, x2, #1
    // 0xc88b5c: r17 = 5604
    //     0xc88b5c: mov             x17, #0x15e4
    // 0xc88b60: cmp             w2, w17
    // 0xc88b64: b.ne            #0xc88b70
    // 0xc88b68: r0 = true
    //     0xc88b68: add             x0, NULL, #0x20  ; true
    // 0xc88b6c: b               #0xc88b74
    // 0xc88b70: r0 = false
    //     0xc88b70: add             x0, NULL, #0x30  ; false
    // 0xc88b74: LeaveFrame
    //     0xc88b74: mov             SP, fp
    //     0xc88b78: ldp             fp, lr, [SP], #0x10
    // 0xc88b7c: ret
    //     0xc88b7c: ret             
    // 0xc88b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc88b80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc88b84: b               #0xc88aa8
  }
}

// class id: 3545, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ExpansionTileTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0x8528c8, size: 0x60
    // 0x8528c8: EnterFrame
    //     0x8528c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8528cc: mov             fp, SP
    // 0x8528d0: CheckStackOverflow
    //     0x8528d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8528d4: cmp             SP, x16
    //     0x8528d8: b.ls            #0x852920
    // 0x8528dc: r16 = <ExpansionTileTheme>
    //     0x8528dc: add             x16, PP, #0x53, lsl #12  ; [pp+0x53210] TypeArguments: <ExpansionTileTheme>
    //     0x8528e0: ldr             x16, [x16, #0x210]
    // 0x8528e4: ldr             lr, [fp, #0x10]
    // 0x8528e8: stp             lr, x16, [SP, #-0x10]!
    // 0x8528ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8528ec: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8528f0: r0 = dependOnInheritedWidgetOfExactType()
    //     0x8528f0: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x8528f4: add             SP, SP, #0x10
    // 0x8528f8: ldr             x16, [fp, #0x10]
    // 0x8528fc: SaveReg r16
    //     0x8528fc: str             x16, [SP, #-8]!
    // 0x852900: r0 = of()
    //     0x852900: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x852904: add             SP, SP, #8
    // 0x852908: LoadField: r1 = r0->field_df
    //     0x852908: ldur            w1, [x0, #0xdf]
    // 0x85290c: DecompressPointer r1
    //     0x85290c: add             x1, x1, HEAP, lsl #32
    // 0x852910: mov             x0, x1
    // 0x852914: LeaveFrame
    //     0x852914: mov             SP, fp
    //     0x852918: ldp             fp, lr, [SP], #0x10
    // 0x85291c: ret
    //     0x85291c: ret             
    // 0x852920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852920: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852924: b               #0x8528dc
  }
}

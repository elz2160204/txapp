// lib: , url: package:flutter/src/material/flexible_space_bar.dart

// class id: 1049244, size: 0x8
class :: {
}

// class id: 3324, size: 0x14, field offset: 0x14
class _FlexibleSpaceBarState extends State<FlexibleSpaceBar> {

  _ build(/* No info */) {
    // ** addr: 0x8537e4, size: 0x54
    // 0x8537e4: EnterFrame
    //     0x8537e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8537e8: mov             fp, SP
    // 0x8537ec: AllocStack(0x8)
    //     0x8537ec: sub             SP, SP, #8
    // 0x8537f0: r1 = 1
    //     0x8537f0: mov             x1, #1
    // 0x8537f4: r0 = AllocateContext()
    //     0x8537f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8537f8: mov             x1, x0
    // 0x8537fc: ldr             x0, [fp, #0x18]
    // 0x853800: StoreField: r1->field_f = r0
    //     0x853800: stur            w0, [x1, #0xf]
    // 0x853804: mov             x2, x1
    // 0x853808: r1 = Function '<anonymous closure>':.
    //     0x853808: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b8a0] AnonymousClosure: (0x85385c), in [package:flutter/src/material/flexible_space_bar.dart] _FlexibleSpaceBarState::build (0x8537e4)
    //     0x85380c: ldr             x1, [x1, #0x8a0]
    // 0x853810: r0 = AllocateClosure()
    //     0x853810: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x853814: r1 = <BoxConstraints>
    //     0x853814: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f420] TypeArguments: <BoxConstraints>
    //     0x853818: ldr             x1, [x1, #0x420]
    // 0x85381c: stur            x0, [fp, #-8]
    // 0x853820: r0 = LayoutBuilder()
    //     0x853820: bl              #0x824c90  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x853824: ldur            x1, [fp, #-8]
    // 0x853828: StoreField: r0->field_f = r1
    //     0x853828: stur            w1, [x0, #0xf]
    // 0x85382c: LeaveFrame
    //     0x85382c: mov             SP, fp
    //     0x853830: ldp             fp, lr, [SP], #0x10
    // 0x853834: ret
    //     0x853834: ret             
  }
  [closure] ClipRect <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x85385c, size: 0x5f0
    // 0x85385c: EnterFrame
    //     0x85385c: stp             fp, lr, [SP, #-0x10]!
    //     0x853860: mov             fp, SP
    // 0x853864: AllocStack(0x50)
    //     0x853864: sub             SP, SP, #0x50
    // 0x853868: SetupParameters()
    //     0x853868: ldr             x0, [fp, #0x20]
    //     0x85386c: ldur            w1, [x0, #0x17]
    //     0x853870: add             x1, x1, HEAP, lsl #32
    //     0x853874: stur            x1, [fp, #-8]
    // 0x853878: CheckStackOverflow
    //     0x853878: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85387c: cmp             SP, x16
    //     0x853880: b.ls            #0x853e08
    // 0x853884: r16 = <FlexibleSpaceBarSettings>
    //     0x853884: add             x16, PP, #0x37, lsl #12  ; [pp+0x37990] TypeArguments: <FlexibleSpaceBarSettings>
    //     0x853888: ldr             x16, [x16, #0x990]
    // 0x85388c: ldr             lr, [fp, #0x18]
    // 0x853890: stp             lr, x16, [SP, #-0x10]!
    // 0x853894: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x853894: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x853898: r0 = dependOnInheritedWidgetOfExactType()
    //     0x853898: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x85389c: add             SP, SP, #0x10
    // 0x8538a0: stur            x0, [fp, #-0x10]
    // 0x8538a4: cmp             w0, NULL
    // 0x8538a8: b.eq            #0x853e10
    // 0x8538ac: r16 = <Widget>
    //     0x8538ac: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x8538b0: ldr             x16, [x16, #0xea8]
    // 0x8538b4: stp             xzr, x16, [SP, #-0x10]!
    // 0x8538b8: r0 = _GrowableList()
    //     0x8538b8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8538bc: add             SP, SP, #0x10
    // 0x8538c0: mov             x2, x0
    // 0x8538c4: ldur            x0, [fp, #-0x10]
    // 0x8538c8: stur            x2, [fp, #-0x18]
    // 0x8538cc: LoadField: d0 = r0->field_1f
    //     0x8538cc: ldur            d0, [x0, #0x1f]
    // 0x8538d0: stur            d0, [fp, #-0x48]
    // 0x8538d4: LoadField: d1 = r0->field_17
    //     0x8538d4: ldur            d1, [x0, #0x17]
    // 0x8538d8: fsub            d2, d0, d1
    // 0x8538dc: LoadField: d3 = r0->field_27
    //     0x8538dc: ldur            d3, [x0, #0x27]
    // 0x8538e0: fsub            d4, d3, d1
    // 0x8538e4: fdiv            d3, d4, d2
    // 0x8538e8: d4 = 1.000000
    //     0x8538e8: fmov            d4, #1.00000000
    // 0x8538ec: fsub            d5, d4, d3
    // 0x8538f0: d3 = 0.000000
    //     0x8538f0: eor             v3.16b, v3.16b, v3.16b
    // 0x8538f4: fcmp            d5, d3
    // 0x8538f8: b.vs            #0x853908
    // 0x8538fc: b.ge            #0x853908
    // 0x853900: d6 = 0.000000
    //     0x853900: eor             v6.16b, v6.16b, v6.16b
    // 0x853904: b               #0x853930
    // 0x853908: fcmp            d5, d4
    // 0x85390c: b.vs            #0x85391c
    // 0x853910: b.le            #0x85391c
    // 0x853914: d6 = 1.000000
    //     0x853914: fmov            d6, #1.00000000
    // 0x853918: b               #0x853930
    // 0x85391c: fcmp            d5, d5
    // 0x853920: b.vc            #0x85392c
    // 0x853924: d6 = 1.000000
    //     0x853924: fmov            d6, #1.00000000
    // 0x853928: b               #0x853930
    // 0x85392c: mov             v6.16b, v5.16b
    // 0x853930: ldur            x3, [fp, #-8]
    // 0x853934: d5 = 56.000000
    //     0x853934: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x853938: ldr             d5, [x17, #0xe88]
    // 0x85393c: stur            d6, [fp, #-0x40]
    // 0x853940: LoadField: r1 = r3->field_f
    //     0x853940: ldur            w1, [x3, #0xf]
    // 0x853944: DecompressPointer r1
    //     0x853944: add             x1, x1, HEAP, lsl #32
    // 0x853948: LoadField: r4 = r1->field_b
    //     0x853948: ldur            w4, [x1, #0xb]
    // 0x85394c: DecompressPointer r4
    //     0x85394c: add             x4, x4, HEAP, lsl #32
    // 0x853950: cmp             w4, NULL
    // 0x853954: b.eq            #0x853e14
    // 0x853958: fdiv            d7, d5, d2
    // 0x85395c: fsub            d2, d4, d7
    // 0x853960: fcmp            d3, d2
    // 0x853964: b.vs            #0x853974
    // 0x853968: b.le            #0x853974
    // 0x85396c: d2 = 0.000000
    //     0x85396c: eor             v2.16b, v2.16b, v2.16b
    // 0x853970: b               #0x8539a4
    // 0x853974: fcmp            d3, d2
    // 0x853978: b.vs            #0x853980
    // 0x85397c: b.lt            #0x8539a4
    // 0x853980: fcmp            d3, d3
    // 0x853984: b.vs            #0x853998
    // 0x853988: b.ne            #0x853998
    // 0x85398c: fadd            d5, d3, d2
    // 0x853990: mov             v2.16b, v5.16b
    // 0x853994: b               #0x8539a4
    // 0x853998: fcmp            d2, d2
    // 0x85399c: b.vs            #0x8539a4
    // 0x8539a0: d2 = 0.000000
    //     0x8539a0: eor             v2.16b, v2.16b, v2.16b
    // 0x8539a4: stur            d2, [fp, #-0x38]
    // 0x8539a8: fcmp            d0, d1
    // 0x8539ac: b.vs            #0x8539c0
    // 0x8539b0: b.ne            #0x8539c0
    // 0x8539b4: mov             x0, x3
    // 0x8539b8: d0 = 1.000000
    //     0x8539b8: fmov            d0, #1.00000000
    // 0x8539bc: b               #0x853a0c
    // 0x8539c0: r1 = <double>
    //     0x8539c0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8539c4: r0 = Interval()
    //     0x8539c4: bl              #0x85403c  ; AllocateIntervalStub -> Interval (size=0x20)
    // 0x8539c8: ldur            d0, [fp, #-0x38]
    // 0x8539cc: StoreField: r0->field_b = d0
    //     0x8539cc: stur            d0, [x0, #0xb]
    // 0x8539d0: d0 = 1.000000
    //     0x8539d0: fmov            d0, #1.00000000
    // 0x8539d4: StoreField: r0->field_13 = d0
    //     0x8539d4: stur            d0, [x0, #0x13]
    // 0x8539d8: r1 = Instance__Linear
    //     0x8539d8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x8539dc: ldr             x1, [x1, #0x300]
    // 0x8539e0: StoreField: r0->field_1b = r1
    //     0x8539e0: stur            w1, [x0, #0x1b]
    // 0x8539e4: SaveReg r0
    //     0x8539e4: str             x0, [SP, #-8]!
    // 0x8539e8: ldur            d1, [fp, #-0x40]
    // 0x8539ec: SaveReg d1
    //     0x8539ec: str             d1, [SP, #-8]!
    // 0x8539f0: r0 = transform()
    //     0x8539f0: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x8539f4: add             SP, SP, #0x10
    // 0x8539f8: LoadField: d0 = r0->field_7
    //     0x8539f8: ldur            d0, [x0, #7]
    // 0x8539fc: d1 = 1.000000
    //     0x8539fc: fmov            d1, #1.00000000
    // 0x853a00: fsub            d2, d1, d0
    // 0x853a04: mov             v0.16b, v2.16b
    // 0x853a08: ldur            x0, [fp, #-8]
    // 0x853a0c: stur            d0, [fp, #-0x38]
    // 0x853a10: LoadField: r1 = r0->field_f
    //     0x853a10: ldur            w1, [x0, #0xf]
    // 0x853a14: DecompressPointer r1
    //     0x853a14: add             x1, x1, HEAP, lsl #32
    // 0x853a18: LoadField: r2 = r1->field_b
    //     0x853a18: ldur            w2, [x1, #0xb]
    // 0x853a1c: DecompressPointer r2
    //     0x853a1c: add             x2, x2, HEAP, lsl #32
    // 0x853a20: cmp             w2, NULL
    // 0x853a24: b.eq            #0x853e18
    // 0x853a28: r16 = const [Instance of 'StretchMode']
    //     0x853a28: add             x16, PP, #0x34, lsl #12  ; [pp+0x34798] List<StretchMode>(1)
    //     0x853a2c: ldr             x16, [x16, #0x798]
    // 0x853a30: r30 = Instance_StretchMode
    //     0x853a30: add             lr, PP, #0x4b, lsl #12  ; [pp+0x4b8a8] Obj!StretchMode@b658f1
    //     0x853a34: ldr             lr, [lr, #0x8a8]
    // 0x853a38: stp             lr, x16, [SP, #-0x10]!
    // 0x853a3c: r0 = contains()
    //     0x853a3c: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0x853a40: add             SP, SP, #0x10
    // 0x853a44: tbnz            w0, #4, #0x853a68
    // 0x853a48: ldr             x0, [fp, #0x10]
    // 0x853a4c: ldur            d0, [fp, #-0x48]
    // 0x853a50: LoadField: d1 = r0->field_1f
    //     0x853a50: ldur            d1, [x0, #0x1f]
    // 0x853a54: fcmp            d1, d0
    // 0x853a58: b.vs            #0x853a70
    // 0x853a5c: b.le            #0x853a70
    // 0x853a60: mov             v3.16b, v1.16b
    // 0x853a64: b               #0x853a74
    // 0x853a68: ldr             x0, [fp, #0x10]
    // 0x853a6c: ldur            d0, [fp, #-0x48]
    // 0x853a70: mov             v3.16b, v0.16b
    // 0x853a74: ldur            x1, [fp, #-8]
    // 0x853a78: ldur            x2, [fp, #-0x18]
    // 0x853a7c: ldur            d1, [fp, #-0x38]
    // 0x853a80: ldur            d2, [fp, #-0x40]
    // 0x853a84: stur            d3, [fp, #-0x50]
    // 0x853a88: LoadField: r3 = r1->field_f
    //     0x853a88: ldur            w3, [x1, #0xf]
    // 0x853a8c: DecompressPointer r3
    //     0x853a8c: add             x3, x3, HEAP, lsl #32
    // 0x853a90: SaveReg r3
    //     0x853a90: str             x3, [SP, #-8]!
    // 0x853a94: SaveReg d2
    //     0x853a94: str             d2, [SP, #-8]!
    // 0x853a98: ldur            x16, [fp, #-0x10]
    // 0x853a9c: SaveReg r16
    //     0x853a9c: str             x16, [SP, #-8]!
    // 0x853aa0: r0 = _getCollapsePadding()
    //     0x853aa0: bl              #0x853ea4  ; [package:flutter/src/material/flexible_space_bar.dart] _FlexibleSpaceBarState::_getCollapsePadding
    // 0x853aa4: add             SP, SP, #0x18
    // 0x853aa8: mov             x1, x0
    // 0x853aac: ldur            x0, [fp, #-8]
    // 0x853ab0: stur            x1, [fp, #-0x20]
    // 0x853ab4: LoadField: r2 = r0->field_f
    //     0x853ab4: ldur            w2, [x0, #0xf]
    // 0x853ab8: DecompressPointer r2
    //     0x853ab8: add             x2, x2, HEAP, lsl #32
    // 0x853abc: LoadField: r3 = r2->field_b
    //     0x853abc: ldur            w3, [x2, #0xb]
    // 0x853ac0: DecompressPointer r3
    //     0x853ac0: add             x3, x3, HEAP, lsl #32
    // 0x853ac4: cmp             w3, NULL
    // 0x853ac8: b.eq            #0x853e1c
    // 0x853acc: LoadField: r2 = r3->field_f
    //     0x853acc: ldur            w2, [x3, #0xf]
    // 0x853ad0: DecompressPointer r2
    //     0x853ad0: add             x2, x2, HEAP, lsl #32
    // 0x853ad4: stur            x2, [fp, #-0x10]
    // 0x853ad8: r0 = Opacity()
    //     0x853ad8: bl              #0x822694  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x853adc: ldur            d0, [fp, #-0x38]
    // 0x853ae0: stur            x0, [fp, #-0x28]
    // 0x853ae4: StoreField: r0->field_f = d0
    //     0x853ae4: stur            d0, [x0, #0xf]
    // 0x853ae8: r1 = true
    //     0x853ae8: add             x1, NULL, #0x20  ; true
    // 0x853aec: StoreField: r0->field_17 = r1
    //     0x853aec: stur            w1, [x0, #0x17]
    // 0x853af0: ldur            x1, [fp, #-0x10]
    // 0x853af4: StoreField: r0->field_b = r1
    //     0x853af4: stur            w1, [x0, #0xb]
    // 0x853af8: r1 = <StackParentData<RenderBox>>
    //     0x853af8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x853afc: ldr             x1, [x1, #0x5a8]
    // 0x853b00: r0 = Positioned()
    //     0x853b00: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x853b04: mov             x1, x0
    // 0x853b08: r0 = 0.000000
    //     0x853b08: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x853b0c: stur            x1, [fp, #-0x30]
    // 0x853b10: StoreField: r1->field_13 = r0
    //     0x853b10: stur            w0, [x1, #0x13]
    // 0x853b14: ldur            x2, [fp, #-0x20]
    // 0x853b18: StoreField: r1->field_17 = r2
    //     0x853b18: stur            w2, [x1, #0x17]
    // 0x853b1c: StoreField: r1->field_1b = r0
    //     0x853b1c: stur            w0, [x1, #0x1b]
    // 0x853b20: ldur            d0, [fp, #-0x50]
    // 0x853b24: r2 = inline_Allocate_Double()
    //     0x853b24: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x853b28: add             x2, x2, #0x10
    //     0x853b2c: cmp             x3, x2
    //     0x853b30: b.ls            #0x853e20
    //     0x853b34: str             x2, [THR, #0x60]  ; THR::top
    //     0x853b38: sub             x2, x2, #0xf
    //     0x853b3c: mov             x3, #0xd108
    //     0x853b40: movk            x3, #3, lsl #16
    //     0x853b44: stur            x3, [x2, #-1]
    // 0x853b48: StoreField: r2->field_7 = d0
    //     0x853b48: stur            d0, [x2, #7]
    // 0x853b4c: StoreField: r1->field_27 = r2
    //     0x853b4c: stur            w2, [x1, #0x27]
    // 0x853b50: ldur            x2, [fp, #-0x28]
    // 0x853b54: StoreField: r1->field_b = r2
    //     0x853b54: stur            w2, [x1, #0xb]
    // 0x853b58: ldur            x2, [fp, #-0x18]
    // 0x853b5c: LoadField: r3 = r2->field_b
    //     0x853b5c: ldur            w3, [x2, #0xb]
    // 0x853b60: DecompressPointer r3
    //     0x853b60: add             x3, x3, HEAP, lsl #32
    // 0x853b64: stur            x3, [fp, #-0x10]
    // 0x853b68: LoadField: r4 = r2->field_f
    //     0x853b68: ldur            w4, [x2, #0xf]
    // 0x853b6c: DecompressPointer r4
    //     0x853b6c: add             x4, x4, HEAP, lsl #32
    // 0x853b70: LoadField: r5 = r4->field_b
    //     0x853b70: ldur            w5, [x4, #0xb]
    // 0x853b74: DecompressPointer r5
    //     0x853b74: add             x5, x5, HEAP, lsl #32
    // 0x853b78: cmp             w3, w5
    // 0x853b7c: b.ne            #0x853b8c
    // 0x853b80: SaveReg r2
    //     0x853b80: str             x2, [SP, #-8]!
    // 0x853b84: r0 = _growToNextCapacity()
    //     0x853b84: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x853b88: add             SP, SP, #8
    // 0x853b8c: ldur            x3, [fp, #-8]
    // 0x853b90: ldur            x2, [fp, #-0x18]
    // 0x853b94: ldur            x0, [fp, #-0x10]
    // 0x853b98: r4 = LoadInt32Instr(r0)
    //     0x853b98: sbfx            x4, x0, #1, #0x1f
    // 0x853b9c: add             x0, x4, #1
    // 0x853ba0: lsl             x1, x0, #1
    // 0x853ba4: StoreField: r2->field_b = r1
    //     0x853ba4: stur            w1, [x2, #0xb]
    // 0x853ba8: mov             x1, x4
    // 0x853bac: cmp             x1, x0
    // 0x853bb0: b.hs            #0x853e3c
    // 0x853bb4: LoadField: r1 = r2->field_f
    //     0x853bb4: ldur            w1, [x2, #0xf]
    // 0x853bb8: DecompressPointer r1
    //     0x853bb8: add             x1, x1, HEAP, lsl #32
    // 0x853bbc: ldur            x0, [fp, #-0x30]
    // 0x853bc0: ArrayStore: r1[r4] = r0  ; List_4
    //     0x853bc0: add             x25, x1, x4, lsl #2
    //     0x853bc4: add             x25, x25, #0xf
    //     0x853bc8: str             w0, [x25]
    //     0x853bcc: tbz             w0, #0, #0x853be8
    //     0x853bd0: ldurb           w16, [x1, #-1]
    //     0x853bd4: ldurb           w17, [x0, #-1]
    //     0x853bd8: and             x16, x17, x16, lsr #2
    //     0x853bdc: tst             x16, HEAP, lsr #32
    //     0x853be0: b.eq            #0x853be8
    //     0x853be4: bl              #0xd67e5c
    // 0x853be8: LoadField: r0 = r3->field_f
    //     0x853be8: ldur            w0, [x3, #0xf]
    // 0x853bec: DecompressPointer r0
    //     0x853bec: add             x0, x0, HEAP, lsl #32
    // 0x853bf0: LoadField: r1 = r0->field_b
    //     0x853bf0: ldur            w1, [x0, #0xb]
    // 0x853bf4: DecompressPointer r1
    //     0x853bf4: add             x1, x1, HEAP, lsl #32
    // 0x853bf8: cmp             w1, NULL
    // 0x853bfc: b.eq            #0x853e40
    // 0x853c00: r16 = const [Instance of 'StretchMode']
    //     0x853c00: add             x16, PP, #0x34, lsl #12  ; [pp+0x34798] List<StretchMode>(1)
    //     0x853c04: ldr             x16, [x16, #0x798]
    // 0x853c08: r30 = Instance_StretchMode
    //     0x853c08: add             lr, PP, #0x4b, lsl #12  ; [pp+0x4b8b0] Obj!StretchMode@b658d1
    //     0x853c0c: ldr             lr, [lr, #0x8b0]
    // 0x853c10: stp             lr, x16, [SP, #-0x10]!
    // 0x853c14: r0 = contains()
    //     0x853c14: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0x853c18: add             SP, SP, #0x10
    // 0x853c1c: tbnz            w0, #4, #0x853d8c
    // 0x853c20: ldr             x0, [fp, #0x10]
    // 0x853c24: ldur            d0, [fp, #-0x48]
    // 0x853c28: LoadField: d1 = r0->field_1f
    //     0x853c28: ldur            d1, [x0, #0x1f]
    // 0x853c2c: fcmp            d1, d0
    // 0x853c30: b.vs            #0x853d84
    // 0x853c34: b.le            #0x853d84
    // 0x853c38: ldur            x0, [fp, #-0x18]
    // 0x853c3c: d2 = 10.000000
    //     0x853c3c: fmov            d2, #10.00000000
    // 0x853c40: fsub            d3, d1, d0
    // 0x853c44: fdiv            d0, d3, d2
    // 0x853c48: stur            d0, [fp, #-0x38]
    // 0x853c4c: r0 = _GaussianBlurImageFilter()
    //     0x853c4c: bl              #0x853e98  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x20)
    // 0x853c50: mov             x1, x0
    // 0x853c54: r0 = Sentinel
    //     0x853c54: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x853c58: stur            x1, [fp, #-0x10]
    // 0x853c5c: StoreField: r1->field_1b = r0
    //     0x853c5c: stur            w0, [x1, #0x1b]
    // 0x853c60: ldur            d0, [fp, #-0x38]
    // 0x853c64: StoreField: r1->field_7 = d0
    //     0x853c64: stur            d0, [x1, #7]
    // 0x853c68: StoreField: r1->field_f = d0
    //     0x853c68: stur            d0, [x1, #0xf]
    // 0x853c6c: r0 = Instance_TileMode
    //     0x853c6c: add             x0, PP, #0x27, lsl #12  ; [pp+0x271d8] Obj!TileMode@b675b1
    //     0x853c70: ldr             x0, [x0, #0x1d8]
    // 0x853c74: StoreField: r1->field_17 = r0
    //     0x853c74: stur            w0, [x1, #0x17]
    // 0x853c78: r0 = Container()
    //     0x853c78: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x853c7c: stur            x0, [fp, #-0x20]
    // 0x853c80: r16 = Instance_Color
    //     0x853c80: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x853c84: ldr             x16, [x16, #0xc08]
    // 0x853c88: stp             x16, x0, [SP, #-0x10]!
    // 0x853c8c: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x853c8c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x853c90: ldr             x4, [x4, #0x168]
    // 0x853c94: r0 = Container()
    //     0x853c94: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x853c98: add             SP, SP, #0x10
    // 0x853c9c: r0 = BackdropFilter()
    //     0x853c9c: bl              #0x853e8c  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x18)
    // 0x853ca0: mov             x2, x0
    // 0x853ca4: ldur            x0, [fp, #-0x10]
    // 0x853ca8: stur            x2, [fp, #-0x28]
    // 0x853cac: StoreField: r2->field_f = r0
    //     0x853cac: stur            w0, [x2, #0xf]
    // 0x853cb0: r0 = Instance_BlendMode
    //     0x853cb0: add             x0, PP, #0x27, lsl #12  ; [pp+0x271c0] Obj!BlendMode@b67871
    //     0x853cb4: ldr             x0, [x0, #0x1c0]
    // 0x853cb8: StoreField: r2->field_13 = r0
    //     0x853cb8: stur            w0, [x2, #0x13]
    // 0x853cbc: ldur            x0, [fp, #-0x20]
    // 0x853cc0: StoreField: r2->field_b = r0
    //     0x853cc0: stur            w0, [x2, #0xb]
    // 0x853cc4: r1 = <StackParentData<RenderBox>>
    //     0x853cc4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0x853cc8: ldr             x1, [x1, #0x5a8]
    // 0x853ccc: r0 = Positioned()
    //     0x853ccc: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0x853cd0: mov             x1, x0
    // 0x853cd4: r0 = 0.000000
    //     0x853cd4: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x853cd8: stur            x1, [fp, #-0x20]
    // 0x853cdc: StoreField: r1->field_13 = r0
    //     0x853cdc: stur            w0, [x1, #0x13]
    // 0x853ce0: StoreField: r1->field_17 = r0
    //     0x853ce0: stur            w0, [x1, #0x17]
    // 0x853ce4: StoreField: r1->field_1b = r0
    //     0x853ce4: stur            w0, [x1, #0x1b]
    // 0x853ce8: StoreField: r1->field_1f = r0
    //     0x853ce8: stur            w0, [x1, #0x1f]
    // 0x853cec: ldur            x0, [fp, #-0x28]
    // 0x853cf0: StoreField: r1->field_b = r0
    //     0x853cf0: stur            w0, [x1, #0xb]
    // 0x853cf4: ldur            x0, [fp, #-0x18]
    // 0x853cf8: LoadField: r2 = r0->field_b
    //     0x853cf8: ldur            w2, [x0, #0xb]
    // 0x853cfc: DecompressPointer r2
    //     0x853cfc: add             x2, x2, HEAP, lsl #32
    // 0x853d00: stur            x2, [fp, #-0x10]
    // 0x853d04: LoadField: r3 = r0->field_f
    //     0x853d04: ldur            w3, [x0, #0xf]
    // 0x853d08: DecompressPointer r3
    //     0x853d08: add             x3, x3, HEAP, lsl #32
    // 0x853d0c: LoadField: r4 = r3->field_b
    //     0x853d0c: ldur            w4, [x3, #0xb]
    // 0x853d10: DecompressPointer r4
    //     0x853d10: add             x4, x4, HEAP, lsl #32
    // 0x853d14: cmp             w2, w4
    // 0x853d18: b.ne            #0x853d28
    // 0x853d1c: SaveReg r0
    //     0x853d1c: str             x0, [SP, #-8]!
    // 0x853d20: r0 = _growToNextCapacity()
    //     0x853d20: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x853d24: add             SP, SP, #8
    // 0x853d28: ldur            x2, [fp, #-0x18]
    // 0x853d2c: ldur            x0, [fp, #-0x10]
    // 0x853d30: r3 = LoadInt32Instr(r0)
    //     0x853d30: sbfx            x3, x0, #1, #0x1f
    // 0x853d34: add             x0, x3, #1
    // 0x853d38: lsl             x1, x0, #1
    // 0x853d3c: StoreField: r2->field_b = r1
    //     0x853d3c: stur            w1, [x2, #0xb]
    // 0x853d40: mov             x1, x3
    // 0x853d44: cmp             x1, x0
    // 0x853d48: b.hs            #0x853e44
    // 0x853d4c: LoadField: r1 = r2->field_f
    //     0x853d4c: ldur            w1, [x2, #0xf]
    // 0x853d50: DecompressPointer r1
    //     0x853d50: add             x1, x1, HEAP, lsl #32
    // 0x853d54: ldur            x0, [fp, #-0x20]
    // 0x853d58: ArrayStore: r1[r3] = r0  ; List_4
    //     0x853d58: add             x25, x1, x3, lsl #2
    //     0x853d5c: add             x25, x25, #0xf
    //     0x853d60: str             w0, [x25]
    //     0x853d64: tbz             w0, #0, #0x853d80
    //     0x853d68: ldurb           w16, [x1, #-1]
    //     0x853d6c: ldurb           w17, [x0, #-1]
    //     0x853d70: and             x16, x17, x16, lsr #2
    //     0x853d74: tst             x16, HEAP, lsr #32
    //     0x853d78: b.eq            #0x853d80
    //     0x853d7c: bl              #0xd67e5c
    // 0x853d80: b               #0x853d90
    // 0x853d84: ldur            x2, [fp, #-0x18]
    // 0x853d88: b               #0x853d90
    // 0x853d8c: ldur            x2, [fp, #-0x18]
    // 0x853d90: ldur            x0, [fp, #-8]
    // 0x853d94: LoadField: r1 = r0->field_f
    //     0x853d94: ldur            w1, [x0, #0xf]
    // 0x853d98: DecompressPointer r1
    //     0x853d98: add             x1, x1, HEAP, lsl #32
    // 0x853d9c: LoadField: r0 = r1->field_b
    //     0x853d9c: ldur            w0, [x1, #0xb]
    // 0x853da0: DecompressPointer r0
    //     0x853da0: add             x0, x0, HEAP, lsl #32
    // 0x853da4: cmp             w0, NULL
    // 0x853da8: b.eq            #0x853e48
    // 0x853dac: r0 = Stack()
    //     0x853dac: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x853db0: mov             x1, x0
    // 0x853db4: r0 = Instance_AlignmentDirectional
    //     0x853db4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x853db8: ldr             x0, [x0, #0xf70]
    // 0x853dbc: stur            x1, [fp, #-8]
    // 0x853dc0: StoreField: r1->field_f = r0
    //     0x853dc0: stur            w0, [x1, #0xf]
    // 0x853dc4: r0 = Instance_StackFit
    //     0x853dc4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x853dc8: ldr             x0, [x0, #0xf78]
    // 0x853dcc: StoreField: r1->field_17 = r0
    //     0x853dcc: stur            w0, [x1, #0x17]
    // 0x853dd0: r0 = Instance_Clip
    //     0x853dd0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x853dd4: ldr             x0, [x0, #0x678]
    // 0x853dd8: StoreField: r1->field_1b = r0
    //     0x853dd8: stur            w0, [x1, #0x1b]
    // 0x853ddc: ldur            x2, [fp, #-0x18]
    // 0x853de0: StoreField: r1->field_b = r2
    //     0x853de0: stur            w2, [x1, #0xb]
    // 0x853de4: r0 = ClipRect()
    //     0x853de4: bl              #0x847d58  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0x853de8: r1 = Instance_Clip
    //     0x853de8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x853dec: ldr             x1, [x1, #0x678]
    // 0x853df0: StoreField: r0->field_13 = r1
    //     0x853df0: stur            w1, [x0, #0x13]
    // 0x853df4: ldur            x1, [fp, #-8]
    // 0x853df8: StoreField: r0->field_b = r1
    //     0x853df8: stur            w1, [x0, #0xb]
    // 0x853dfc: LeaveFrame
    //     0x853dfc: mov             SP, fp
    //     0x853e00: ldp             fp, lr, [SP], #0x10
    // 0x853e04: ret
    //     0x853e04: ret             
    // 0x853e08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853e08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853e0c: b               #0x853884
    // 0x853e10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x853e10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x853e14: r0 = NullCastErrorSharedWithFPURegs()
    //     0x853e14: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x853e18: r0 = NullCastErrorSharedWithFPURegs()
    //     0x853e18: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x853e1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x853e1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x853e20: SaveReg d0
    //     0x853e20: str             q0, [SP, #-0x10]!
    // 0x853e24: stp             x0, x1, [SP, #-0x10]!
    // 0x853e28: r0 = AllocateDouble()
    //     0x853e28: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x853e2c: mov             x2, x0
    // 0x853e30: ldp             x0, x1, [SP], #0x10
    // 0x853e34: RestoreReg d0
    //     0x853e34: ldr             q0, [SP], #0x10
    // 0x853e38: b               #0x853b48
    // 0x853e3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x853e3c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x853e40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x853e40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x853e44: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x853e44: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x853e48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x853e48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getCollapsePadding(/* No info */) {
    // ** addr: 0x853ea4, size: 0x198
    // 0x853ea4: EnterFrame
    //     0x853ea4: stp             fp, lr, [SP, #-0x10]!
    //     0x853ea8: mov             fp, SP
    // 0x853eac: AllocStack(0x8)
    //     0x853eac: sub             SP, SP, #8
    // 0x853eb0: CheckStackOverflow
    //     0x853eb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x853eb4: cmp             SP, x16
    //     0x853eb8: b.ls            #0x853ff8
    // 0x853ebc: ldr             x0, [fp, #0x20]
    // 0x853ec0: LoadField: r1 = r0->field_b
    //     0x853ec0: ldur            w1, [x0, #0xb]
    // 0x853ec4: DecompressPointer r1
    //     0x853ec4: add             x1, x1, HEAP, lsl #32
    // 0x853ec8: cmp             w1, NULL
    // 0x853ecc: b.eq            #0x854000
    // 0x853ed0: LoadField: r0 = r1->field_17
    //     0x853ed0: ldur            w0, [x1, #0x17]
    // 0x853ed4: DecompressPointer r0
    //     0x853ed4: add             x0, x0, HEAP, lsl #32
    // 0x853ed8: LoadField: r1 = r0->field_7
    //     0x853ed8: ldur            x1, [x0, #7]
    // 0x853edc: cmp             x1, #1
    // 0x853ee0: b.gt            #0x853fe8
    // 0x853ee4: cmp             x1, #0
    // 0x853ee8: b.gt            #0x853fa0
    // 0x853eec: ldr             d1, [fp, #0x18]
    // 0x853ef0: ldr             x0, [fp, #0x10]
    // 0x853ef4: d0 = 4.000000
    //     0x853ef4: fmov            d0, #4.00000000
    // 0x853ef8: LoadField: d2 = r0->field_1f
    //     0x853ef8: ldur            d2, [x0, #0x1f]
    // 0x853efc: LoadField: d3 = r0->field_17
    //     0x853efc: ldur            d3, [x0, #0x17]
    // 0x853f00: fsub            d4, d2, d3
    // 0x853f04: fdiv            d2, d4, d0
    // 0x853f08: stur            d2, [fp, #-8]
    // 0x853f0c: r1 = <double>
    //     0x853f0c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x853f10: r0 = Tween()
    //     0x853f10: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x853f14: mov             x1, x0
    // 0x853f18: r0 = 0.000000
    //     0x853f18: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x853f1c: StoreField: r1->field_b = r0
    //     0x853f1c: stur            w0, [x1, #0xb]
    // 0x853f20: ldur            d0, [fp, #-8]
    // 0x853f24: r0 = inline_Allocate_Double()
    //     0x853f24: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x853f28: add             x0, x0, #0x10
    //     0x853f2c: cmp             x2, x0
    //     0x853f30: b.ls            #0x854004
    //     0x853f34: str             x0, [THR, #0x60]  ; THR::top
    //     0x853f38: sub             x0, x0, #0xf
    //     0x853f3c: mov             x2, #0xd108
    //     0x853f40: movk            x2, #3, lsl #16
    //     0x853f44: stur            x2, [x0, #-1]
    // 0x853f48: StoreField: r0->field_7 = d0
    //     0x853f48: stur            d0, [x0, #7]
    // 0x853f4c: StoreField: r1->field_f = r0
    //     0x853f4c: stur            w0, [x1, #0xf]
    // 0x853f50: SaveReg r1
    //     0x853f50: str             x1, [SP, #-8]!
    // 0x853f54: ldr             d0, [fp, #0x18]
    // 0x853f58: SaveReg d0
    //     0x853f58: str             d0, [SP, #-8]!
    // 0x853f5c: r0 = transform()
    //     0x853f5c: bl              #0xc09d2c  ; [package:flutter/src/animation/tween.dart] Tween::transform
    // 0x853f60: add             SP, SP, #0x10
    // 0x853f64: LoadField: d0 = r0->field_7
    //     0x853f64: ldur            d0, [x0, #7]
    // 0x853f68: fneg            d1, d0
    // 0x853f6c: r0 = inline_Allocate_Double()
    //     0x853f6c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x853f70: add             x0, x0, #0x10
    //     0x853f74: cmp             x1, x0
    //     0x853f78: b.ls            #0x85401c
    //     0x853f7c: str             x0, [THR, #0x60]  ; THR::top
    //     0x853f80: sub             x0, x0, #0xf
    //     0x853f84: mov             x1, #0xd108
    //     0x853f88: movk            x1, #3, lsl #16
    //     0x853f8c: stur            x1, [x0, #-1]
    // 0x853f90: StoreField: r0->field_7 = d1
    //     0x853f90: stur            d1, [x0, #7]
    // 0x853f94: LeaveFrame
    //     0x853f94: mov             SP, fp
    //     0x853f98: ldp             fp, lr, [SP], #0x10
    // 0x853f9c: ret
    //     0x853f9c: ret             
    // 0x853fa0: ldr             x0, [fp, #0x10]
    // 0x853fa4: LoadField: d0 = r0->field_1f
    //     0x853fa4: ldur            d0, [x0, #0x1f]
    // 0x853fa8: LoadField: d1 = r0->field_27
    //     0x853fa8: ldur            d1, [x0, #0x27]
    // 0x853fac: fsub            d2, d0, d1
    // 0x853fb0: fneg            d0, d2
    // 0x853fb4: r0 = inline_Allocate_Double()
    //     0x853fb4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x853fb8: add             x0, x0, #0x10
    //     0x853fbc: cmp             x1, x0
    //     0x853fc0: b.ls            #0x85402c
    //     0x853fc4: str             x0, [THR, #0x60]  ; THR::top
    //     0x853fc8: sub             x0, x0, #0xf
    //     0x853fcc: mov             x1, #0xd108
    //     0x853fd0: movk            x1, #3, lsl #16
    //     0x853fd4: stur            x1, [x0, #-1]
    // 0x853fd8: StoreField: r0->field_7 = d0
    //     0x853fd8: stur            d0, [x0, #7]
    // 0x853fdc: LeaveFrame
    //     0x853fdc: mov             SP, fp
    //     0x853fe0: ldp             fp, lr, [SP], #0x10
    // 0x853fe4: ret
    //     0x853fe4: ret             
    // 0x853fe8: r0 = 0.000000
    //     0x853fe8: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x853fec: LeaveFrame
    //     0x853fec: mov             SP, fp
    //     0x853ff0: ldp             fp, lr, [SP], #0x10
    // 0x853ff4: ret
    //     0x853ff4: ret             
    // 0x853ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853ff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853ffc: b               #0x853ebc
    // 0x854000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x854000: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x854004: SaveReg d0
    //     0x854004: str             q0, [SP, #-0x10]!
    // 0x854008: SaveReg r1
    //     0x854008: str             x1, [SP, #-8]!
    // 0x85400c: r0 = AllocateDouble()
    //     0x85400c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x854010: RestoreReg r1
    //     0x854010: ldr             x1, [SP], #8
    // 0x854014: RestoreReg d0
    //     0x854014: ldr             q0, [SP], #0x10
    // 0x854018: b               #0x853f48
    // 0x85401c: SaveReg d1
    //     0x85401c: str             q1, [SP, #-0x10]!
    // 0x854020: r0 = AllocateDouble()
    //     0x854020: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x854024: RestoreReg d1
    //     0x854024: ldr             q1, [SP], #0x10
    // 0x854028: b               #0x853f90
    // 0x85402c: SaveReg d0
    //     0x85402c: str             q0, [SP, #-0x10]!
    // 0x854030: r0 = AllocateDouble()
    //     0x854030: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x854034: RestoreReg d0
    //     0x854034: ldr             q0, [SP], #0x10
    // 0x854038: b               #0x853fd8
  }
}

// class id: 3528, size: 0x34, field offset: 0x10
//   const constructor, 
class FlexibleSpaceBarSettings extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa87b20, size: 0xc0
    // 0xa87b20: EnterFrame
    //     0xa87b20: stp             fp, lr, [SP, #-0x10]!
    //     0xa87b24: mov             fp, SP
    // 0xa87b28: ldr             x0, [fp, #0x10]
    // 0xa87b2c: r2 = Null
    //     0xa87b2c: mov             x2, NULL
    // 0xa87b30: r1 = Null
    //     0xa87b30: mov             x1, NULL
    // 0xa87b34: r4 = 59
    //     0xa87b34: mov             x4, #0x3b
    // 0xa87b38: branchIfSmi(r0, 0xa87b44)
    //     0xa87b38: tbz             w0, #0, #0xa87b44
    // 0xa87b3c: r4 = LoadClassIdInstr(r0)
    //     0xa87b3c: ldur            x4, [x0, #-1]
    //     0xa87b40: ubfx            x4, x4, #0xc, #0x14
    // 0xa87b44: cmp             x4, #0xdc8
    // 0xa87b48: b.eq            #0xa87b60
    // 0xa87b4c: r8 = FlexibleSpaceBarSettings
    //     0xa87b4c: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e568] Type: FlexibleSpaceBarSettings
    //     0xa87b50: ldr             x8, [x8, #0x568]
    // 0xa87b54: r3 = Null
    //     0xa87b54: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e570] Null
    //     0xa87b58: ldr             x3, [x3, #0x570]
    // 0xa87b5c: r0 = DefaultTypeTest()
    //     0xa87b5c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa87b60: ldr             x1, [fp, #0x18]
    // 0xa87b64: LoadField: d0 = r1->field_f
    //     0xa87b64: ldur            d0, [x1, #0xf]
    // 0xa87b68: ldr             x2, [fp, #0x10]
    // 0xa87b6c: LoadField: d1 = r2->field_f
    //     0xa87b6c: ldur            d1, [x2, #0xf]
    // 0xa87b70: fcmp            d0, d1
    // 0xa87b74: b.ne            #0xa87ba8
    // 0xa87b78: LoadField: d0 = r1->field_17
    //     0xa87b78: ldur            d0, [x1, #0x17]
    // 0xa87b7c: LoadField: d1 = r2->field_17
    //     0xa87b7c: ldur            d1, [x2, #0x17]
    // 0xa87b80: fcmp            d0, d1
    // 0xa87b84: b.ne            #0xa87ba8
    // 0xa87b88: LoadField: d0 = r1->field_1f
    //     0xa87b88: ldur            d0, [x1, #0x1f]
    // 0xa87b8c: LoadField: d1 = r2->field_1f
    //     0xa87b8c: ldur            d1, [x2, #0x1f]
    // 0xa87b90: fcmp            d0, d1
    // 0xa87b94: b.ne            #0xa87ba8
    // 0xa87b98: LoadField: d0 = r1->field_27
    //     0xa87b98: ldur            d0, [x1, #0x27]
    // 0xa87b9c: LoadField: d1 = r2->field_27
    //     0xa87b9c: ldur            d1, [x2, #0x27]
    // 0xa87ba0: fcmp            d0, d1
    // 0xa87ba4: b.eq            #0xa87bb0
    // 0xa87ba8: r0 = true
    //     0xa87ba8: add             x0, NULL, #0x20  ; true
    // 0xa87bac: b               #0xa87bd4
    // 0xa87bb0: LoadField: r3 = r1->field_2f
    //     0xa87bb0: ldur            w3, [x1, #0x2f]
    // 0xa87bb4: DecompressPointer r3
    //     0xa87bb4: add             x3, x3, HEAP, lsl #32
    // 0xa87bb8: LoadField: r1 = r2->field_2f
    //     0xa87bb8: ldur            w1, [x2, #0x2f]
    // 0xa87bbc: DecompressPointer r1
    //     0xa87bbc: add             x1, x1, HEAP, lsl #32
    // 0xa87bc0: cmp             w3, w1
    // 0xa87bc4: r16 = true
    //     0xa87bc4: add             x16, NULL, #0x20  ; true
    // 0xa87bc8: r17 = false
    //     0xa87bc8: add             x17, NULL, #0x30  ; false
    // 0xa87bcc: csel            x2, x16, x17, ne
    // 0xa87bd0: mov             x0, x2
    // 0xa87bd4: LeaveFrame
    //     0xa87bd4: mov             SP, fp
    //     0xa87bd8: ldp             fp, lr, [SP], #0x10
    // 0xa87bdc: ret
    //     0xa87bdc: ret             
  }
}

// class id: 4155, size: 0x2c, field offset: 0xc
//   const constructor, 
class FlexibleSpaceBar extends StatefulWidget {

  static _ createSettings(/* No info */) {
    // ** addr: 0x8656ac, size: 0x208
    // 0x8656ac: EnterFrame
    //     0x8656ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8656b0: mov             fp, SP
    // 0x8656b4: AllocStack(0x30)
    //     0x8656b4: sub             SP, SP, #0x30
    // 0x8656b8: SetupParameters(dynamic _ /* r3, fp-0x10 */, dynamic _ /* d0, fp-0x30 */, {dynamic isScrolledUnder = Null /* r4, fp-0x8 */, dynamic maxExtent = Null /* r5 */, dynamic minExtent = Null /* r6 */, dynamic toolbarOpacity = Null /* r0 */})
    //     0x8656b8: mov             x0, x4
    //     0x8656bc: ldur            w1, [x0, #0x13]
    //     0x8656c0: add             x1, x1, HEAP, lsl #32
    //     0x8656c4: sub             x2, x1, #4
    //     0x8656c8: add             x3, fp, w2, sxtw #2
    //     0x8656cc: ldr             x3, [x3, #0x18]
    //     0x8656d0: stur            x3, [fp, #-0x10]
    //     0x8656d4: add             x4, fp, w2, sxtw #2
    //     0x8656d8: ldr             d0, [x4, #0x10]
    //     0x8656dc: stur            d0, [fp, #-0x30]
    //     0x8656e0: ldur            w2, [x0, #0x1f]
    //     0x8656e4: add             x2, x2, HEAP, lsl #32
    //     0x8656e8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e68] "isScrolledUnder"
    //     0x8656ec: ldr             x16, [x16, #0xe68]
    //     0x8656f0: cmp             w2, w16
    //     0x8656f4: b.ne            #0x865718
    //     0x8656f8: ldur            w2, [x0, #0x23]
    //     0x8656fc: add             x2, x2, HEAP, lsl #32
    //     0x865700: sub             w4, w1, w2
    //     0x865704: add             x2, fp, w4, sxtw #2
    //     0x865708: ldr             x2, [x2, #8]
    //     0x86570c: mov             x4, x2
    //     0x865710: mov             x2, #1
    //     0x865714: b               #0x865720
    //     0x865718: mov             x4, NULL
    //     0x86571c: mov             x2, #0
    //     0x865720: stur            x4, [fp, #-8]
    //     0x865724: lsl             x5, x2, #1
    //     0x865728: lsl             w6, w5, #1
    //     0x86572c: add             w7, w6, #8
    //     0x865730: add             x16, x0, w7, sxtw #1
    //     0x865734: ldur            w8, [x16, #0xf]
    //     0x865738: add             x8, x8, HEAP, lsl #32
    //     0x86573c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e70] "maxExtent"
    //     0x865740: ldr             x16, [x16, #0xe70]
    //     0x865744: cmp             w8, w16
    //     0x865748: b.ne            #0x86577c
    //     0x86574c: add             w2, w6, #0xa
    //     0x865750: add             x16, x0, w2, sxtw #1
    //     0x865754: ldur            w6, [x16, #0xf]
    //     0x865758: add             x6, x6, HEAP, lsl #32
    //     0x86575c: sub             w2, w1, w6
    //     0x865760: add             x6, fp, w2, sxtw #2
    //     0x865764: ldr             x6, [x6, #8]
    //     0x865768: add             w2, w5, #2
    //     0x86576c: sbfx            x5, x2, #1, #0x1f
    //     0x865770: mov             x2, x5
    //     0x865774: mov             x5, x6
    //     0x865778: b               #0x865780
    //     0x86577c: mov             x5, NULL
    //     0x865780: lsl             x6, x2, #1
    //     0x865784: lsl             w7, w6, #1
    //     0x865788: add             w8, w7, #8
    //     0x86578c: add             x16, x0, w8, sxtw #1
    //     0x865790: ldur            w9, [x16, #0xf]
    //     0x865794: add             x9, x9, HEAP, lsl #32
    //     0x865798: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e78] "minExtent"
    //     0x86579c: ldr             x16, [x16, #0xe78]
    //     0x8657a0: cmp             w9, w16
    //     0x8657a4: b.ne            #0x8657d8
    //     0x8657a8: add             w2, w7, #0xa
    //     0x8657ac: add             x16, x0, w2, sxtw #1
    //     0x8657b0: ldur            w7, [x16, #0xf]
    //     0x8657b4: add             x7, x7, HEAP, lsl #32
    //     0x8657b8: sub             w2, w1, w7
    //     0x8657bc: add             x7, fp, w2, sxtw #2
    //     0x8657c0: ldr             x7, [x7, #8]
    //     0x8657c4: add             w2, w6, #2
    //     0x8657c8: sbfx            x6, x2, #1, #0x1f
    //     0x8657cc: mov             x2, x6
    //     0x8657d0: mov             x6, x7
    //     0x8657d4: b               #0x8657dc
    //     0x8657d8: mov             x6, NULL
    //     0x8657dc: lsl             x7, x2, #1
    //     0x8657e0: lsl             w2, w7, #1
    //     0x8657e4: add             w7, w2, #8
    //     0x8657e8: add             x16, x0, w7, sxtw #1
    //     0x8657ec: ldur            w8, [x16, #0xf]
    //     0x8657f0: add             x8, x8, HEAP, lsl #32
    //     0x8657f4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e80] "toolbarOpacity"
    //     0x8657f8: ldr             x16, [x16, #0xe80]
    //     0x8657fc: cmp             w8, w16
    //     0x865800: b.ne            #0x865828
    //     0x865804: add             w7, w2, #0xa
    //     0x865808: add             x16, x0, w7, sxtw #1
    //     0x86580c: ldur            w2, [x16, #0xf]
    //     0x865810: add             x2, x2, HEAP, lsl #32
    //     0x865814: sub             w0, w1, w2
    //     0x865818: add             x1, fp, w0, sxtw #2
    //     0x86581c: ldr             x1, [x1, #8]
    //     0x865820: mov             x0, x1
    //     0x865824: b               #0x86582c
    //     0x865828: mov             x0, NULL
    // 0x86582c: cmp             w0, NULL
    // 0x865830: b.ne            #0x86583c
    // 0x865834: d1 = 1.000000
    //     0x865834: fmov            d1, #1.00000000
    // 0x865838: b               #0x865840
    // 0x86583c: LoadField: d1 = r0->field_7
    //     0x86583c: ldur            d1, [x0, #7]
    // 0x865840: stur            d1, [fp, #-0x28]
    // 0x865844: cmp             w6, NULL
    // 0x865848: b.ne            #0x865854
    // 0x86584c: mov             v2.16b, v0.16b
    // 0x865850: b               #0x865858
    // 0x865854: LoadField: d2 = r6->field_7
    //     0x865854: ldur            d2, [x6, #7]
    // 0x865858: stur            d2, [fp, #-0x20]
    // 0x86585c: cmp             w5, NULL
    // 0x865860: b.ne            #0x86586c
    // 0x865864: mov             v3.16b, v0.16b
    // 0x865868: b               #0x865870
    // 0x86586c: LoadField: d3 = r5->field_7
    //     0x86586c: ldur            d3, [x5, #7]
    // 0x865870: stur            d3, [fp, #-0x18]
    // 0x865874: r0 = FlexibleSpaceBarSettings()
    //     0x865874: bl              #0x8658b4  ; AllocateFlexibleSpaceBarSettingsStub -> FlexibleSpaceBarSettings (size=0x34)
    // 0x865878: ldur            d0, [fp, #-0x28]
    // 0x86587c: StoreField: r0->field_f = d0
    //     0x86587c: stur            d0, [x0, #0xf]
    // 0x865880: ldur            d0, [fp, #-0x20]
    // 0x865884: StoreField: r0->field_17 = d0
    //     0x865884: stur            d0, [x0, #0x17]
    // 0x865888: ldur            d0, [fp, #-0x18]
    // 0x86588c: StoreField: r0->field_1f = d0
    //     0x86588c: stur            d0, [x0, #0x1f]
    // 0x865890: ldur            d0, [fp, #-0x30]
    // 0x865894: StoreField: r0->field_27 = d0
    //     0x865894: stur            d0, [x0, #0x27]
    // 0x865898: ldur            x1, [fp, #-8]
    // 0x86589c: StoreField: r0->field_2f = r1
    //     0x86589c: stur            w1, [x0, #0x2f]
    // 0x8658a0: ldur            x1, [fp, #-0x10]
    // 0x8658a4: StoreField: r0->field_b = r1
    //     0x8658a4: stur            w1, [x0, #0xb]
    // 0x8658a8: LeaveFrame
    //     0x8658a8: mov             SP, fp
    //     0x8658ac: ldp             fp, lr, [SP], #0x10
    // 0x8658b0: ret
    //     0x8658b0: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xa40620, size: 0x20
    // 0xa40620: EnterFrame
    //     0xa40620: stp             fp, lr, [SP, #-0x10]!
    //     0xa40624: mov             fp, SP
    // 0xa40628: r1 = <FlexibleSpaceBar>
    //     0xa40628: add             x1, PP, #0x40, lsl #12  ; [pp+0x401a8] TypeArguments: <FlexibleSpaceBar>
    //     0xa4062c: ldr             x1, [x1, #0x1a8]
    // 0xa40630: r0 = _FlexibleSpaceBarState()
    //     0xa40630: bl              #0xa40640  ; Allocate_FlexibleSpaceBarStateStub -> _FlexibleSpaceBarState (size=0x14)
    // 0xa40634: LeaveFrame
    //     0xa40634: mov             SP, fp
    //     0xa40638: ldp             fp, lr, [SP], #0x10
    // 0xa4063c: ret
    //     0xa4063c: ret             
  }
}

// class id: 5966, size: 0x14, field offset: 0x14
enum StretchMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb160dc, size: 0x5c
    // 0xb160dc: EnterFrame
    //     0xb160dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb160e0: mov             fp, SP
    // 0xb160e4: CheckStackOverflow
    //     0xb160e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb160e8: cmp             SP, x16
    //     0xb160ec: b.ls            #0xb16130
    // 0xb160f0: r1 = Null
    //     0xb160f0: mov             x1, NULL
    // 0xb160f4: r2 = 4
    //     0xb160f4: mov             x2, #4
    // 0xb160f8: r0 = AllocateArray()
    //     0xb160f8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb160fc: r17 = "StretchMode."
    //     0xb160fc: add             x17, PP, #0x40, lsl #12  ; [pp+0x401a0] "StretchMode."
    //     0xb16100: ldr             x17, [x17, #0x1a0]
    // 0xb16104: StoreField: r0->field_f = r17
    //     0xb16104: stur            w17, [x0, #0xf]
    // 0xb16108: ldr             x1, [fp, #0x10]
    // 0xb1610c: LoadField: r2 = r1->field_f
    //     0xb1610c: ldur            w2, [x1, #0xf]
    // 0xb16110: DecompressPointer r2
    //     0xb16110: add             x2, x2, HEAP, lsl #32
    // 0xb16114: StoreField: r0->field_13 = r2
    //     0xb16114: stur            w2, [x0, #0x13]
    // 0xb16118: SaveReg r0
    //     0xb16118: str             x0, [SP, #-8]!
    // 0xb1611c: r0 = _interpolate()
    //     0xb1611c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16120: add             SP, SP, #8
    // 0xb16124: LeaveFrame
    //     0xb16124: mov             SP, fp
    //     0xb16128: ldp             fp, lr, [SP], #0x10
    // 0xb1612c: ret
    //     0xb1612c: ret             
    // 0xb16130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16134: b               #0xb160f0
  }
}

// class id: 5967, size: 0x14, field offset: 0x14
enum CollapseMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16080, size: 0x5c
    // 0xb16080: EnterFrame
    //     0xb16080: stp             fp, lr, [SP, #-0x10]!
    //     0xb16084: mov             fp, SP
    // 0xb16088: CheckStackOverflow
    //     0xb16088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1608c: cmp             SP, x16
    //     0xb16090: b.ls            #0xb160d4
    // 0xb16094: r1 = Null
    //     0xb16094: mov             x1, NULL
    // 0xb16098: r2 = 4
    //     0xb16098: mov             x2, #4
    // 0xb1609c: r0 = AllocateArray()
    //     0xb1609c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb160a0: r17 = "CollapseMode."
    //     0xb160a0: add             x17, PP, #0x40, lsl #12  ; [pp+0x401b0] "CollapseMode."
    //     0xb160a4: ldr             x17, [x17, #0x1b0]
    // 0xb160a8: StoreField: r0->field_f = r17
    //     0xb160a8: stur            w17, [x0, #0xf]
    // 0xb160ac: ldr             x1, [fp, #0x10]
    // 0xb160b0: LoadField: r2 = r1->field_f
    //     0xb160b0: ldur            w2, [x1, #0xf]
    // 0xb160b4: DecompressPointer r2
    //     0xb160b4: add             x2, x2, HEAP, lsl #32
    // 0xb160b8: StoreField: r0->field_13 = r2
    //     0xb160b8: stur            w2, [x0, #0x13]
    // 0xb160bc: SaveReg r0
    //     0xb160bc: str             x0, [SP, #-8]!
    // 0xb160c0: r0 = _interpolate()
    //     0xb160c0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb160c4: add             SP, SP, #8
    // 0xb160c8: LeaveFrame
    //     0xb160c8: mov             SP, fp
    //     0xb160cc: ldp             fp, lr, [SP], #0x10
    // 0xb160d0: ret
    //     0xb160d0: ret             
    // 0xb160d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb160d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb160d8: b               #0xb16094
  }
}

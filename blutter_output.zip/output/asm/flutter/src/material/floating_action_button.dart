// lib: , url: package:flutter/src/material/floating_action_button.dart

// class id: 1049245, size: 0x8
class :: {
}

// class id: 2211, size: 0x8, field offset: 0x8
//   const constructor, 
class _DefaultHeroTag extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xada620, size: 0xc
    // 0xada620: r0 = "<default FloatingActionButton tag>"
    //     0xada620: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e560] "<default FloatingActionButton tag>"
    //     0xada624: ldr             x0, [x0, #0x560]
    // 0xada628: ret
    //     0xada628: ret             
  }
}

// class id: 2470, size: 0x70, field offset: 0x70
class _RenderChildOverflowBox extends RenderAligningShiftedBox {

  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638c4c, size: 0x18
    // 0x638c4c: r4 = 0
    //     0x638c4c: mov             x4, #0
    // 0x638c50: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x638c50: add             x17, PP, #0x53, lsl #12  ; [pp+0x53160] AnonymousClosure: (0xc24c8c), of [package:flutter/src/rendering/box.dart] RenderBox
    //     0x638c54: ldr             x1, [x17, #0x160]
    // 0x638c58: r24 = BuildNonGenericMethodExtractorStub
    //     0x638c58: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638c5c: LoadField: r0 = r24->field_17
    //     0x638c5c: ldur            x0, [x24, #0x17]
    // 0x638c60: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63b888, size: 0x18
    // 0x63b888: r4 = 0
    //     0x63b888: mov             x4, #0
    // 0x63b88c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63b88c: add             x17, PP, #0x50, lsl #12  ; [pp+0x50cc8] AnonymousClosure: (0xc24c8c), of [package:flutter/src/rendering/box.dart] RenderBox
    //     0x63b890: ldr             x1, [x17, #0xcc8]
    // 0x63b894: r24 = BuildNonGenericMethodExtractorStub
    //     0x63b894: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63b898: LoadField: r0 = r24->field_17
    //     0x63b898: ldur            x0, [x24, #0x17]
    // 0x63b89c: br              x0
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x690b10, size: 0x49c
    // 0x690b10: EnterFrame
    //     0x690b10: stp             fp, lr, [SP, #-0x10]!
    //     0x690b14: mov             fp, SP
    // 0x690b18: AllocStack(0x28)
    //     0x690b18: sub             SP, SP, #0x28
    // 0x690b1c: CheckStackOverflow
    //     0x690b1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x690b20: cmp             SP, x16
    //     0x690b24: b.ls            #0x690f48
    // 0x690b28: ldr             x3, [fp, #0x10]
    // 0x690b2c: LoadField: r4 = r3->field_27
    //     0x690b2c: ldur            w4, [x3, #0x27]
    // 0x690b30: DecompressPointer r4
    //     0x690b30: add             x4, x4, HEAP, lsl #32
    // 0x690b34: stur            x4, [fp, #-8]
    // 0x690b38: cmp             w4, NULL
    // 0x690b3c: b.eq            #0x690f28
    // 0x690b40: mov             x0, x4
    // 0x690b44: r2 = Null
    //     0x690b44: mov             x2, NULL
    // 0x690b48: r1 = Null
    //     0x690b48: mov             x1, NULL
    // 0x690b4c: r4 = LoadClassIdInstr(r0)
    //     0x690b4c: ldur            x4, [x0, #-1]
    //     0x690b50: ubfx            x4, x4, #0xc, #0x14
    // 0x690b54: sub             x4, x4, #0x80d
    // 0x690b58: cmp             x4, #1
    // 0x690b5c: b.ls            #0x690b74
    // 0x690b60: r8 = BoxConstraints
    //     0x690b60: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x690b64: ldr             x8, [x8, #0x1d0]
    // 0x690b68: r3 = Null
    //     0x690b68: add             x3, PP, #0x40, lsl #12  ; [pp+0x40190] Null
    //     0x690b6c: ldr             x3, [x3, #0x190]
    // 0x690b70: r0 = BoxConstraints()
    //     0x690b70: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x690b74: ldr             x1, [fp, #0x10]
    // 0x690b78: LoadField: r0 = r1->field_5f
    //     0x690b78: ldur            w0, [x1, #0x5f]
    // 0x690b7c: DecompressPointer r0
    //     0x690b7c: add             x0, x0, HEAP, lsl #32
    // 0x690b80: cmp             w0, NULL
    // 0x690b84: b.eq            #0x690eb4
    // 0x690b88: ldur            x2, [fp, #-8]
    // 0x690b8c: r3 = LoadClassIdInstr(r0)
    //     0x690b8c: ldur            x3, [x0, #-1]
    //     0x690b90: ubfx            x3, x3, #0xc, #0x14
    // 0x690b94: r16 = Instance_BoxConstraints
    //     0x690b94: add             x16, PP, #0x21, lsl #12  ; [pp+0x21610] Obj!BoxConstraints@b35351
    //     0x690b98: ldr             x16, [x16, #0x610]
    // 0x690b9c: stp             x16, x0, [SP, #-0x10]!
    // 0x690ba0: r16 = true
    //     0x690ba0: add             x16, NULL, #0x20  ; true
    // 0x690ba4: SaveReg r16
    //     0x690ba4: str             x16, [SP, #-8]!
    // 0x690ba8: mov             x0, x3
    // 0x690bac: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x690bac: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x690bb0: ldr             x4, [x4, #0x1c8]
    // 0x690bb4: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x690bb4: mov             x17, #0xcdfb
    //     0x690bb8: add             lr, x0, x17
    //     0x690bbc: ldr             lr, [x21, lr, lsl #3]
    //     0x690bc0: blr             lr
    // 0x690bc4: add             SP, SP, #0x18
    // 0x690bc8: ldur            x0, [fp, #-8]
    // 0x690bcc: LoadField: d0 = r0->field_7
    //     0x690bcc: ldur            d0, [x0, #7]
    // 0x690bd0: stur            d0, [fp, #-0x20]
    // 0x690bd4: LoadField: d1 = r0->field_f
    //     0x690bd4: ldur            d1, [x0, #0xf]
    // 0x690bd8: ldr             x1, [fp, #0x10]
    // 0x690bdc: stur            d1, [fp, #-0x18]
    // 0x690be0: LoadField: r2 = r1->field_5f
    //     0x690be0: ldur            w2, [x1, #0x5f]
    // 0x690be4: DecompressPointer r2
    //     0x690be4: add             x2, x2, HEAP, lsl #32
    // 0x690be8: cmp             w2, NULL
    // 0x690bec: b.eq            #0x690f50
    // 0x690bf0: LoadField: r3 = r2->field_57
    //     0x690bf0: ldur            w3, [x2, #0x57]
    // 0x690bf4: DecompressPointer r3
    //     0x690bf4: add             x3, x3, HEAP, lsl #32
    // 0x690bf8: cmp             w3, NULL
    // 0x690bfc: b.eq            #0x690f54
    // 0x690c00: LoadField: d2 = r3->field_7
    //     0x690c00: ldur            d2, [x3, #7]
    // 0x690c04: stur            d2, [fp, #-0x10]
    // 0x690c08: fcmp            d1, d2
    // 0x690c0c: b.vs            #0x690c1c
    // 0x690c10: b.le            #0x690c1c
    // 0x690c14: mov             v1.16b, v2.16b
    // 0x690c18: b               #0x690cbc
    // 0x690c1c: fcmp            d1, d2
    // 0x690c20: b.vs            #0x690c28
    // 0x690c24: b.lt            #0x690cbc
    // 0x690c28: d3 = 0.000000
    //     0x690c28: eor             v3.16b, v3.16b, v3.16b
    // 0x690c2c: fcmp            d1, d3
    // 0x690c30: b.vs            #0x690c38
    // 0x690c34: b.eq            #0x690c40
    // 0x690c38: r2 = false
    //     0x690c38: add             x2, NULL, #0x30  ; false
    // 0x690c3c: b               #0x690c44
    // 0x690c40: r2 = true
    //     0x690c40: add             x2, NULL, #0x20  ; true
    // 0x690c44: tbnz            w2, #4, #0x690c58
    // 0x690c48: fadd            d4, d1, d2
    // 0x690c4c: fmul            d5, d4, d1
    // 0x690c50: fmul            d1, d5, d2
    // 0x690c54: b               #0x690cbc
    // 0x690c58: tbnz            w2, #4, #0x690c9c
    // 0x690c5c: r2 = inline_Allocate_Double()
    //     0x690c5c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x690c60: add             x2, x2, #0x10
    //     0x690c64: cmp             x3, x2
    //     0x690c68: b.ls            #0x690f58
    //     0x690c6c: str             x2, [THR, #0x60]  ; THR::top
    //     0x690c70: sub             x2, x2, #0xf
    //     0x690c74: mov             x3, #0xd108
    //     0x690c78: movk            x3, #3, lsl #16
    //     0x690c7c: stur            x3, [x2, #-1]
    // 0x690c80: StoreField: r2->field_7 = d2
    //     0x690c80: stur            d2, [x2, #7]
    // 0x690c84: SaveReg r2
    //     0x690c84: str             x2, [SP, #-8]!
    // 0x690c88: r0 = isNegative()
    //     0x690c88: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x690c8c: add             SP, SP, #8
    // 0x690c90: tbnz            w0, #4, #0x690c9c
    // 0x690c94: ldur            d0, [fp, #-0x10]
    // 0x690c98: b               #0x690ca8
    // 0x690c9c: ldur            d0, [fp, #-0x10]
    // 0x690ca0: fcmp            d0, d0
    // 0x690ca4: b.vc            #0x690cb4
    // 0x690ca8: mov             v1.16b, v0.16b
    // 0x690cac: ldur            d0, [fp, #-0x20]
    // 0x690cb0: b               #0x690cbc
    // 0x690cb4: ldur            d1, [fp, #-0x18]
    // 0x690cb8: ldur            d0, [fp, #-0x20]
    // 0x690cbc: fcmp            d0, d1
    // 0x690cc0: b.vs            #0x690cd0
    // 0x690cc4: b.le            #0x690cd0
    // 0x690cc8: d2 = 0.000000
    //     0x690cc8: eor             v2.16b, v2.16b, v2.16b
    // 0x690ccc: b               #0x690d10
    // 0x690cd0: fcmp            d0, d1
    // 0x690cd4: b.vs            #0x690ce8
    // 0x690cd8: b.ge            #0x690ce8
    // 0x690cdc: mov             v0.16b, v1.16b
    // 0x690ce0: d2 = 0.000000
    //     0x690ce0: eor             v2.16b, v2.16b, v2.16b
    // 0x690ce4: b               #0x690d10
    // 0x690ce8: d2 = 0.000000
    //     0x690ce8: eor             v2.16b, v2.16b, v2.16b
    // 0x690cec: fcmp            d0, d2
    // 0x690cf0: b.vs            #0x690d04
    // 0x690cf4: b.ne            #0x690d04
    // 0x690cf8: fadd            d3, d0, d1
    // 0x690cfc: mov             v0.16b, v3.16b
    // 0x690d00: b               #0x690d10
    // 0x690d04: fcmp            d1, d1
    // 0x690d08: b.vc            #0x690d10
    // 0x690d0c: mov             v0.16b, v1.16b
    // 0x690d10: ldr             x1, [fp, #0x10]
    // 0x690d14: ldur            x0, [fp, #-8]
    // 0x690d18: stur            d0, [fp, #-0x28]
    // 0x690d1c: LoadField: d1 = r0->field_17
    //     0x690d1c: ldur            d1, [x0, #0x17]
    // 0x690d20: stur            d1, [fp, #-0x20]
    // 0x690d24: LoadField: d3 = r0->field_1f
    //     0x690d24: ldur            d3, [x0, #0x1f]
    // 0x690d28: stur            d3, [fp, #-0x18]
    // 0x690d2c: LoadField: r0 = r1->field_5f
    //     0x690d2c: ldur            w0, [x1, #0x5f]
    // 0x690d30: DecompressPointer r0
    //     0x690d30: add             x0, x0, HEAP, lsl #32
    // 0x690d34: cmp             w0, NULL
    // 0x690d38: b.eq            #0x690f7c
    // 0x690d3c: LoadField: r2 = r0->field_57
    //     0x690d3c: ldur            w2, [x0, #0x57]
    // 0x690d40: DecompressPointer r2
    //     0x690d40: add             x2, x2, HEAP, lsl #32
    // 0x690d44: cmp             w2, NULL
    // 0x690d48: b.eq            #0x690f80
    // 0x690d4c: LoadField: d4 = r2->field_f
    //     0x690d4c: ldur            d4, [x2, #0xf]
    // 0x690d50: stur            d4, [fp, #-0x10]
    // 0x690d54: fcmp            d3, d4
    // 0x690d58: b.vs            #0x690d6c
    // 0x690d5c: b.le            #0x690d6c
    // 0x690d60: mov             v0.16b, v1.16b
    // 0x690d64: mov             v1.16b, v4.16b
    // 0x690d68: b               #0x690e1c
    // 0x690d6c: fcmp            d3, d4
    // 0x690d70: b.vs            #0x690d84
    // 0x690d74: b.ge            #0x690d84
    // 0x690d78: mov             v0.16b, v1.16b
    // 0x690d7c: mov             v1.16b, v3.16b
    // 0x690d80: b               #0x690e1c
    // 0x690d84: fcmp            d3, d2
    // 0x690d88: b.vs            #0x690d90
    // 0x690d8c: b.eq            #0x690d98
    // 0x690d90: r0 = false
    //     0x690d90: add             x0, NULL, #0x30  ; false
    // 0x690d94: b               #0x690d9c
    // 0x690d98: r0 = true
    //     0x690d98: add             x0, NULL, #0x20  ; true
    // 0x690d9c: tbnz            w0, #4, #0x690db8
    // 0x690da0: fadd            d5, d3, d4
    // 0x690da4: fmul            d6, d5, d3
    // 0x690da8: fmul            d3, d6, d4
    // 0x690dac: mov             v0.16b, v1.16b
    // 0x690db0: mov             v1.16b, v3.16b
    // 0x690db4: b               #0x690e1c
    // 0x690db8: tbnz            w0, #4, #0x690dfc
    // 0x690dbc: r0 = inline_Allocate_Double()
    //     0x690dbc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x690dc0: add             x0, x0, #0x10
    //     0x690dc4: cmp             x2, x0
    //     0x690dc8: b.ls            #0x690f84
    //     0x690dcc: str             x0, [THR, #0x60]  ; THR::top
    //     0x690dd0: sub             x0, x0, #0xf
    //     0x690dd4: mov             x2, #0xd108
    //     0x690dd8: movk            x2, #3, lsl #16
    //     0x690ddc: stur            x2, [x0, #-1]
    // 0x690de0: StoreField: r0->field_7 = d4
    //     0x690de0: stur            d4, [x0, #7]
    // 0x690de4: SaveReg r0
    //     0x690de4: str             x0, [SP, #-8]!
    // 0x690de8: r0 = isNegative()
    //     0x690de8: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x690dec: add             SP, SP, #8
    // 0x690df0: tbnz            w0, #4, #0x690dfc
    // 0x690df4: ldur            d0, [fp, #-0x10]
    // 0x690df8: b               #0x690e08
    // 0x690dfc: ldur            d0, [fp, #-0x10]
    // 0x690e00: fcmp            d0, d0
    // 0x690e04: b.vc            #0x690e14
    // 0x690e08: mov             v1.16b, v0.16b
    // 0x690e0c: ldur            d0, [fp, #-0x20]
    // 0x690e10: b               #0x690e1c
    // 0x690e14: ldur            d1, [fp, #-0x18]
    // 0x690e18: ldur            d0, [fp, #-0x20]
    // 0x690e1c: fcmp            d0, d1
    // 0x690e20: b.vs            #0x690e30
    // 0x690e24: b.le            #0x690e30
    // 0x690e28: mov             v1.16b, v0.16b
    // 0x690e2c: b               #0x690e64
    // 0x690e30: fcmp            d0, d1
    // 0x690e34: b.vs            #0x690e3c
    // 0x690e38: b.lt            #0x690e64
    // 0x690e3c: d2 = 0.000000
    //     0x690e3c: eor             v2.16b, v2.16b, v2.16b
    // 0x690e40: fcmp            d0, d2
    // 0x690e44: b.vs            #0x690e58
    // 0x690e48: b.ne            #0x690e58
    // 0x690e4c: fadd            d2, d0, d1
    // 0x690e50: mov             v1.16b, v2.16b
    // 0x690e54: b               #0x690e64
    // 0x690e58: fcmp            d1, d1
    // 0x690e5c: b.vs            #0x690e64
    // 0x690e60: mov             v1.16b, v0.16b
    // 0x690e64: ldr             x0, [fp, #0x10]
    // 0x690e68: ldur            d0, [fp, #-0x28]
    // 0x690e6c: stur            d1, [fp, #-0x10]
    // 0x690e70: r0 = Size()
    //     0x690e70: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x690e74: ldur            d0, [fp, #-0x28]
    // 0x690e78: StoreField: r0->field_7 = d0
    //     0x690e78: stur            d0, [x0, #7]
    // 0x690e7c: ldur            d0, [fp, #-0x10]
    // 0x690e80: StoreField: r0->field_f = d0
    //     0x690e80: stur            d0, [x0, #0xf]
    // 0x690e84: ldr             x1, [fp, #0x10]
    // 0x690e88: StoreField: r1->field_57 = r0
    //     0x690e88: stur            w0, [x1, #0x57]
    //     0x690e8c: ldurb           w16, [x1, #-1]
    //     0x690e90: ldurb           w17, [x0, #-1]
    //     0x690e94: and             x16, x17, x16, lsr #2
    //     0x690e98: tst             x16, HEAP, lsr #32
    //     0x690e9c: b.eq            #0x690ea4
    //     0x690ea0: bl              #0xd6826c
    // 0x690ea4: SaveReg r1
    //     0x690ea4: str             x1, [SP, #-8]!
    // 0x690ea8: r0 = alignChild()
    //     0x690ea8: bl              #0x69064c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0x690eac: add             SP, SP, #8
    // 0x690eb0: b               #0x690f18
    // 0x690eb4: ldur            x0, [fp, #-8]
    // 0x690eb8: SaveReg r0
    //     0x690eb8: str             x0, [SP, #-8]!
    // 0x690ebc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x690ebc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x690ec0: r0 = constrainWidth()
    //     0x690ec0: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0x690ec4: add             SP, SP, #8
    // 0x690ec8: stur            d0, [fp, #-0x10]
    // 0x690ecc: ldur            x16, [fp, #-8]
    // 0x690ed0: SaveReg r16
    //     0x690ed0: str             x16, [SP, #-8]!
    // 0x690ed4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x690ed4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x690ed8: r0 = constrainHeight()
    //     0x690ed8: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0x690edc: add             SP, SP, #8
    // 0x690ee0: stur            d0, [fp, #-0x18]
    // 0x690ee4: r0 = Size()
    //     0x690ee4: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x690ee8: ldur            d0, [fp, #-0x10]
    // 0x690eec: StoreField: r0->field_7 = d0
    //     0x690eec: stur            d0, [x0, #7]
    // 0x690ef0: ldur            d0, [fp, #-0x18]
    // 0x690ef4: StoreField: r0->field_f = d0
    //     0x690ef4: stur            d0, [x0, #0xf]
    // 0x690ef8: ldr             x1, [fp, #0x10]
    // 0x690efc: StoreField: r1->field_57 = r0
    //     0x690efc: stur            w0, [x1, #0x57]
    //     0x690f00: ldurb           w16, [x1, #-1]
    //     0x690f04: ldurb           w17, [x0, #-1]
    //     0x690f08: and             x16, x17, x16, lsr #2
    //     0x690f0c: tst             x16, HEAP, lsr #32
    //     0x690f10: b.eq            #0x690f18
    //     0x690f14: bl              #0xd6826c
    // 0x690f18: r0 = Null
    //     0x690f18: mov             x0, NULL
    // 0x690f1c: LeaveFrame
    //     0x690f1c: mov             SP, fp
    //     0x690f20: ldp             fp, lr, [SP], #0x10
    // 0x690f24: ret
    //     0x690f24: ret             
    // 0x690f28: r0 = StateError()
    //     0x690f28: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x690f2c: mov             x1, x0
    // 0x690f30: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x690f30: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x690f34: ldr             x0, [x0, #0x1e8]
    // 0x690f38: StoreField: r1->field_b = r0
    //     0x690f38: stur            w0, [x1, #0xb]
    // 0x690f3c: mov             x0, x1
    // 0x690f40: r0 = Throw()
    //     0x690f40: bl              #0xd67e38  ; ThrowStub
    // 0x690f44: brk             #0
    // 0x690f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x690f48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x690f4c: b               #0x690b28
    // 0x690f50: r0 = NullCastErrorSharedWithFPURegs()
    //     0x690f50: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x690f54: r0 = NullCastErrorSharedWithFPURegs()
    //     0x690f54: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x690f58: stp             q2, q3, [SP, #-0x20]!
    // 0x690f5c: stp             q0, q1, [SP, #-0x20]!
    // 0x690f60: stp             x0, x1, [SP, #-0x10]!
    // 0x690f64: r0 = AllocateDouble()
    //     0x690f64: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x690f68: mov             x2, x0
    // 0x690f6c: ldp             x0, x1, [SP], #0x10
    // 0x690f70: ldp             q0, q1, [SP], #0x20
    // 0x690f74: ldp             q2, q3, [SP], #0x20
    // 0x690f78: b               #0x690c80
    // 0x690f7c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x690f7c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x690f80: r0 = NullCastErrorSharedWithFPURegs()
    //     0x690f80: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x690f84: stp             q3, q4, [SP, #-0x20]!
    // 0x690f88: stp             q1, q2, [SP, #-0x20]!
    // 0x690f8c: SaveReg d0
    //     0x690f8c: str             q0, [SP, #-0x10]!
    // 0x690f90: SaveReg r1
    //     0x690f90: str             x1, [SP, #-8]!
    // 0x690f94: r0 = AllocateDouble()
    //     0x690f94: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x690f98: RestoreReg r1
    //     0x690f98: ldr             x1, [SP], #8
    // 0x690f9c: RestoreReg d0
    //     0x690f9c: ldr             q0, [SP], #0x10
    // 0x690fa0: ldp             q1, q2, [SP], #0x20
    // 0x690fa4: ldp             q3, q4, [SP], #0x20
    // 0x690fa8: b               #0x690de0
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5da68, size: 0x368
    // 0xa5da68: EnterFrame
    //     0xa5da68: stp             fp, lr, [SP, #-0x10]!
    //     0xa5da6c: mov             fp, SP
    // 0xa5da70: AllocStack(0x28)
    //     0xa5da70: sub             SP, SP, #0x28
    // 0xa5da74: CheckStackOverflow
    //     0xa5da74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5da78: cmp             SP, x16
    //     0xa5da7c: b.ls            #0xa5dd84
    // 0xa5da80: ldr             x0, [fp, #0x18]
    // 0xa5da84: LoadField: r1 = r0->field_5f
    //     0xa5da84: ldur            w1, [x0, #0x5f]
    // 0xa5da88: DecompressPointer r1
    //     0xa5da88: add             x1, x1, HEAP, lsl #32
    // 0xa5da8c: cmp             w1, NULL
    // 0xa5da90: b.eq            #0xa5dd34
    // 0xa5da94: ldr             x0, [fp, #0x10]
    // 0xa5da98: r16 = Instance_BoxConstraints
    //     0xa5da98: add             x16, PP, #0x21, lsl #12  ; [pp+0x21610] Obj!BoxConstraints@b35351
    //     0xa5da9c: ldr             x16, [x16, #0x610]
    // 0xa5daa0: stp             x16, x1, [SP, #-0x10]!
    // 0xa5daa4: r0 = getDryLayout()
    //     0xa5daa4: bl              #0x62d394  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xa5daa8: add             SP, SP, #0x10
    // 0xa5daac: mov             x1, x0
    // 0xa5dab0: ldr             x0, [fp, #0x10]
    // 0xa5dab4: stur            x1, [fp, #-8]
    // 0xa5dab8: LoadField: d0 = r0->field_7
    //     0xa5dab8: ldur            d0, [x0, #7]
    // 0xa5dabc: stur            d0, [fp, #-0x20]
    // 0xa5dac0: LoadField: d1 = r0->field_f
    //     0xa5dac0: ldur            d1, [x0, #0xf]
    // 0xa5dac4: stur            d1, [fp, #-0x18]
    // 0xa5dac8: LoadField: d2 = r1->field_7
    //     0xa5dac8: ldur            d2, [x1, #7]
    // 0xa5dacc: stur            d2, [fp, #-0x10]
    // 0xa5dad0: fcmp            d1, d2
    // 0xa5dad4: b.vs            #0xa5dae4
    // 0xa5dad8: b.le            #0xa5dae4
    // 0xa5dadc: mov             v1.16b, v2.16b
    // 0xa5dae0: b               #0xa5db84
    // 0xa5dae4: fcmp            d1, d2
    // 0xa5dae8: b.vs            #0xa5daf0
    // 0xa5daec: b.lt            #0xa5db84
    // 0xa5daf0: d3 = 0.000000
    //     0xa5daf0: eor             v3.16b, v3.16b, v3.16b
    // 0xa5daf4: fcmp            d1, d3
    // 0xa5daf8: b.vs            #0xa5db00
    // 0xa5dafc: b.eq            #0xa5db08
    // 0xa5db00: r2 = false
    //     0xa5db00: add             x2, NULL, #0x30  ; false
    // 0xa5db04: b               #0xa5db0c
    // 0xa5db08: r2 = true
    //     0xa5db08: add             x2, NULL, #0x20  ; true
    // 0xa5db0c: tbnz            w2, #4, #0xa5db20
    // 0xa5db10: fadd            d4, d1, d2
    // 0xa5db14: fmul            d5, d4, d1
    // 0xa5db18: fmul            d1, d5, d2
    // 0xa5db1c: b               #0xa5db84
    // 0xa5db20: tbnz            w2, #4, #0xa5db64
    // 0xa5db24: r2 = inline_Allocate_Double()
    //     0xa5db24: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xa5db28: add             x2, x2, #0x10
    //     0xa5db2c: cmp             x3, x2
    //     0xa5db30: b.ls            #0xa5dd8c
    //     0xa5db34: str             x2, [THR, #0x60]  ; THR::top
    //     0xa5db38: sub             x2, x2, #0xf
    //     0xa5db3c: mov             x3, #0xd108
    //     0xa5db40: movk            x3, #3, lsl #16
    //     0xa5db44: stur            x3, [x2, #-1]
    // 0xa5db48: StoreField: r2->field_7 = d2
    //     0xa5db48: stur            d2, [x2, #7]
    // 0xa5db4c: SaveReg r2
    //     0xa5db4c: str             x2, [SP, #-8]!
    // 0xa5db50: r0 = isNegative()
    //     0xa5db50: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xa5db54: add             SP, SP, #8
    // 0xa5db58: tbnz            w0, #4, #0xa5db64
    // 0xa5db5c: ldur            d0, [fp, #-0x10]
    // 0xa5db60: b               #0xa5db70
    // 0xa5db64: ldur            d0, [fp, #-0x10]
    // 0xa5db68: fcmp            d0, d0
    // 0xa5db6c: b.vc            #0xa5db7c
    // 0xa5db70: mov             v1.16b, v0.16b
    // 0xa5db74: ldur            d0, [fp, #-0x20]
    // 0xa5db78: b               #0xa5db84
    // 0xa5db7c: ldur            d1, [fp, #-0x18]
    // 0xa5db80: ldur            d0, [fp, #-0x20]
    // 0xa5db84: fcmp            d0, d1
    // 0xa5db88: b.vs            #0xa5db98
    // 0xa5db8c: b.le            #0xa5db98
    // 0xa5db90: d2 = 0.000000
    //     0xa5db90: eor             v2.16b, v2.16b, v2.16b
    // 0xa5db94: b               #0xa5dbd8
    // 0xa5db98: fcmp            d0, d1
    // 0xa5db9c: b.vs            #0xa5dbb0
    // 0xa5dba0: b.ge            #0xa5dbb0
    // 0xa5dba4: mov             v0.16b, v1.16b
    // 0xa5dba8: d2 = 0.000000
    //     0xa5dba8: eor             v2.16b, v2.16b, v2.16b
    // 0xa5dbac: b               #0xa5dbd8
    // 0xa5dbb0: d2 = 0.000000
    //     0xa5dbb0: eor             v2.16b, v2.16b, v2.16b
    // 0xa5dbb4: fcmp            d0, d2
    // 0xa5dbb8: b.vs            #0xa5dbcc
    // 0xa5dbbc: b.ne            #0xa5dbcc
    // 0xa5dbc0: fadd            d3, d0, d1
    // 0xa5dbc4: mov             v0.16b, v3.16b
    // 0xa5dbc8: b               #0xa5dbd8
    // 0xa5dbcc: fcmp            d1, d1
    // 0xa5dbd0: b.vc            #0xa5dbd8
    // 0xa5dbd4: mov             v0.16b, v1.16b
    // 0xa5dbd8: ldr             x0, [fp, #0x10]
    // 0xa5dbdc: ldur            x1, [fp, #-8]
    // 0xa5dbe0: stur            d0, [fp, #-0x28]
    // 0xa5dbe4: LoadField: d1 = r0->field_17
    //     0xa5dbe4: ldur            d1, [x0, #0x17]
    // 0xa5dbe8: stur            d1, [fp, #-0x20]
    // 0xa5dbec: LoadField: d3 = r0->field_1f
    //     0xa5dbec: ldur            d3, [x0, #0x1f]
    // 0xa5dbf0: stur            d3, [fp, #-0x18]
    // 0xa5dbf4: LoadField: d4 = r1->field_f
    //     0xa5dbf4: ldur            d4, [x1, #0xf]
    // 0xa5dbf8: stur            d4, [fp, #-0x10]
    // 0xa5dbfc: fcmp            d3, d4
    // 0xa5dc00: b.vs            #0xa5dc14
    // 0xa5dc04: b.le            #0xa5dc14
    // 0xa5dc08: mov             v0.16b, v1.16b
    // 0xa5dc0c: mov             v1.16b, v4.16b
    // 0xa5dc10: b               #0xa5dcc4
    // 0xa5dc14: fcmp            d3, d4
    // 0xa5dc18: b.vs            #0xa5dc2c
    // 0xa5dc1c: b.ge            #0xa5dc2c
    // 0xa5dc20: mov             v0.16b, v1.16b
    // 0xa5dc24: mov             v1.16b, v3.16b
    // 0xa5dc28: b               #0xa5dcc4
    // 0xa5dc2c: fcmp            d3, d2
    // 0xa5dc30: b.vs            #0xa5dc38
    // 0xa5dc34: b.eq            #0xa5dc40
    // 0xa5dc38: r0 = false
    //     0xa5dc38: add             x0, NULL, #0x30  ; false
    // 0xa5dc3c: b               #0xa5dc44
    // 0xa5dc40: r0 = true
    //     0xa5dc40: add             x0, NULL, #0x20  ; true
    // 0xa5dc44: tbnz            w0, #4, #0xa5dc60
    // 0xa5dc48: fadd            d5, d3, d4
    // 0xa5dc4c: fmul            d6, d5, d3
    // 0xa5dc50: fmul            d3, d6, d4
    // 0xa5dc54: mov             v0.16b, v1.16b
    // 0xa5dc58: mov             v1.16b, v3.16b
    // 0xa5dc5c: b               #0xa5dcc4
    // 0xa5dc60: tbnz            w0, #4, #0xa5dca4
    // 0xa5dc64: r0 = inline_Allocate_Double()
    //     0xa5dc64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa5dc68: add             x0, x0, #0x10
    //     0xa5dc6c: cmp             x1, x0
    //     0xa5dc70: b.ls            #0xa5ddb0
    //     0xa5dc74: str             x0, [THR, #0x60]  ; THR::top
    //     0xa5dc78: sub             x0, x0, #0xf
    //     0xa5dc7c: mov             x1, #0xd108
    //     0xa5dc80: movk            x1, #3, lsl #16
    //     0xa5dc84: stur            x1, [x0, #-1]
    // 0xa5dc88: StoreField: r0->field_7 = d4
    //     0xa5dc88: stur            d4, [x0, #7]
    // 0xa5dc8c: SaveReg r0
    //     0xa5dc8c: str             x0, [SP, #-8]!
    // 0xa5dc90: r0 = isNegative()
    //     0xa5dc90: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xa5dc94: add             SP, SP, #8
    // 0xa5dc98: tbnz            w0, #4, #0xa5dca4
    // 0xa5dc9c: ldur            d0, [fp, #-0x10]
    // 0xa5dca0: b               #0xa5dcb0
    // 0xa5dca4: ldur            d0, [fp, #-0x10]
    // 0xa5dca8: fcmp            d0, d0
    // 0xa5dcac: b.vc            #0xa5dcbc
    // 0xa5dcb0: mov             v1.16b, v0.16b
    // 0xa5dcb4: ldur            d0, [fp, #-0x20]
    // 0xa5dcb8: b               #0xa5dcc4
    // 0xa5dcbc: ldur            d1, [fp, #-0x18]
    // 0xa5dcc0: ldur            d0, [fp, #-0x20]
    // 0xa5dcc4: fcmp            d0, d1
    // 0xa5dcc8: b.vs            #0xa5dcd8
    // 0xa5dccc: b.le            #0xa5dcd8
    // 0xa5dcd0: mov             v1.16b, v0.16b
    // 0xa5dcd4: b               #0xa5dd0c
    // 0xa5dcd8: fcmp            d0, d1
    // 0xa5dcdc: b.vs            #0xa5dce4
    // 0xa5dce0: b.lt            #0xa5dd0c
    // 0xa5dce4: d2 = 0.000000
    //     0xa5dce4: eor             v2.16b, v2.16b, v2.16b
    // 0xa5dce8: fcmp            d0, d2
    // 0xa5dcec: b.vs            #0xa5dd00
    // 0xa5dcf0: b.ne            #0xa5dd00
    // 0xa5dcf4: fadd            d2, d0, d1
    // 0xa5dcf8: mov             v1.16b, v2.16b
    // 0xa5dcfc: b               #0xa5dd0c
    // 0xa5dd00: fcmp            d1, d1
    // 0xa5dd04: b.vs            #0xa5dd0c
    // 0xa5dd08: mov             v1.16b, v0.16b
    // 0xa5dd0c: ldur            d0, [fp, #-0x28]
    // 0xa5dd10: stur            d1, [fp, #-0x10]
    // 0xa5dd14: r0 = Size()
    //     0xa5dd14: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5dd18: ldur            d0, [fp, #-0x28]
    // 0xa5dd1c: StoreField: r0->field_7 = d0
    //     0xa5dd1c: stur            d0, [x0, #7]
    // 0xa5dd20: ldur            d0, [fp, #-0x10]
    // 0xa5dd24: StoreField: r0->field_f = d0
    //     0xa5dd24: stur            d0, [x0, #0xf]
    // 0xa5dd28: LeaveFrame
    //     0xa5dd28: mov             SP, fp
    //     0xa5dd2c: ldp             fp, lr, [SP], #0x10
    // 0xa5dd30: ret
    //     0xa5dd30: ret             
    // 0xa5dd34: ldr             x0, [fp, #0x10]
    // 0xa5dd38: SaveReg r0
    //     0xa5dd38: str             x0, [SP, #-8]!
    // 0xa5dd3c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa5dd3c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa5dd40: r0 = constrainWidth()
    //     0xa5dd40: bl              #0x62bc8c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xa5dd44: add             SP, SP, #8
    // 0xa5dd48: stur            d0, [fp, #-0x10]
    // 0xa5dd4c: ldr             x16, [fp, #0x10]
    // 0xa5dd50: SaveReg r16
    //     0xa5dd50: str             x16, [SP, #-8]!
    // 0xa5dd54: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa5dd54: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa5dd58: r0 = constrainHeight()
    //     0xa5dd58: bl              #0x62bc00  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xa5dd5c: add             SP, SP, #8
    // 0xa5dd60: stur            d0, [fp, #-0x18]
    // 0xa5dd64: r0 = Size()
    //     0xa5dd64: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5dd68: ldur            d0, [fp, #-0x10]
    // 0xa5dd6c: StoreField: r0->field_7 = d0
    //     0xa5dd6c: stur            d0, [x0, #7]
    // 0xa5dd70: ldur            d0, [fp, #-0x18]
    // 0xa5dd74: StoreField: r0->field_f = d0
    //     0xa5dd74: stur            d0, [x0, #0xf]
    // 0xa5dd78: LeaveFrame
    //     0xa5dd78: mov             SP, fp
    //     0xa5dd7c: ldp             fp, lr, [SP], #0x10
    // 0xa5dd80: ret
    //     0xa5dd80: ret             
    // 0xa5dd84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5dd84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5dd88: b               #0xa5da80
    // 0xa5dd8c: stp             q2, q3, [SP, #-0x20]!
    // 0xa5dd90: stp             q0, q1, [SP, #-0x20]!
    // 0xa5dd94: stp             x0, x1, [SP, #-0x10]!
    // 0xa5dd98: r0 = AllocateDouble()
    //     0xa5dd98: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5dd9c: mov             x2, x0
    // 0xa5dda0: ldp             x0, x1, [SP], #0x10
    // 0xa5dda4: ldp             q0, q1, [SP], #0x20
    // 0xa5dda8: ldp             q2, q3, [SP], #0x20
    // 0xa5ddac: b               #0xa5db48
    // 0xa5ddb0: stp             q3, q4, [SP, #-0x20]!
    // 0xa5ddb4: stp             q1, q2, [SP, #-0x20]!
    // 0xa5ddb8: SaveReg d0
    //     0xa5ddb8: str             q0, [SP, #-0x10]!
    // 0xa5ddbc: r0 = AllocateDouble()
    //     0xa5ddbc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa5ddc0: RestoreReg d0
    //     0xa5ddc0: ldr             q0, [SP], #0x10
    // 0xa5ddc4: ldp             q1, q2, [SP], #0x20
    // 0xa5ddc8: ldp             q3, q4, [SP], #0x20
    // 0xa5ddcc: b               #0xa5dc88
  }
}

// class id: 2799, size: 0x70, field offset: 0x5c
class _FABDefaultsM3 extends FloatingActionButtonThemeData {

  late final ColorScheme _colors; // offset: 0x68
  late final TextTheme _textTheme; // offset: 0x6c

  TextTheme _textTheme(_FABDefaultsM3) {
    // ** addr: 0xaffc2c, size: 0x4c
    // 0xaffc2c: EnterFrame
    //     0xaffc2c: stp             fp, lr, [SP, #-0x10]!
    //     0xaffc30: mov             fp, SP
    // 0xaffc34: CheckStackOverflow
    //     0xaffc34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaffc38: cmp             SP, x16
    //     0xaffc3c: b.ls            #0xaffc70
    // 0xaffc40: ldr             x0, [fp, #0x10]
    // 0xaffc44: LoadField: r1 = r0->field_5b
    //     0xaffc44: ldur            w1, [x0, #0x5b]
    // 0xaffc48: DecompressPointer r1
    //     0xaffc48: add             x1, x1, HEAP, lsl #32
    // 0xaffc4c: SaveReg r1
    //     0xaffc4c: str             x1, [SP, #-8]!
    // 0xaffc50: r0 = of()
    //     0xaffc50: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaffc54: add             SP, SP, #8
    // 0xaffc58: LoadField: r1 = r0->field_93
    //     0xaffc58: ldur            w1, [x0, #0x93]
    // 0xaffc5c: DecompressPointer r1
    //     0xaffc5c: add             x1, x1, HEAP, lsl #32
    // 0xaffc60: mov             x0, x1
    // 0xaffc64: LeaveFrame
    //     0xaffc64: mov             SP, fp
    //     0xaffc68: ldp             fp, lr, [SP], #0x10
    // 0xaffc6c: ret
    //     0xaffc6c: ret             
    // 0xaffc70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaffc70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaffc74: b               #0xaffc40
  }
  ColorScheme _colors(_FABDefaultsM3) {
    // ** addr: 0xaffc78, size: 0x4c
    // 0xaffc78: EnterFrame
    //     0xaffc78: stp             fp, lr, [SP, #-0x10]!
    //     0xaffc7c: mov             fp, SP
    // 0xaffc80: CheckStackOverflow
    //     0xaffc80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaffc84: cmp             SP, x16
    //     0xaffc88: b.ls            #0xaffcbc
    // 0xaffc8c: ldr             x0, [fp, #0x10]
    // 0xaffc90: LoadField: r1 = r0->field_5b
    //     0xaffc90: ldur            w1, [x0, #0x5b]
    // 0xaffc94: DecompressPointer r1
    //     0xaffc94: add             x1, x1, HEAP, lsl #32
    // 0xaffc98: SaveReg r1
    //     0xaffc98: str             x1, [SP, #-8]!
    // 0xaffc9c: r0 = of()
    //     0xaffc9c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaffca0: add             SP, SP, #8
    // 0xaffca4: LoadField: r1 = r0->field_3f
    //     0xaffca4: ldur            w1, [x0, #0x3f]
    // 0xaffca8: DecompressPointer r1
    //     0xaffca8: add             x1, x1, HEAP, lsl #32
    // 0xaffcac: mov             x0, x1
    // 0xaffcb0: LeaveFrame
    //     0xaffcb0: mov             SP, fp
    //     0xaffcb4: ldp             fp, lr, [SP], #0x10
    // 0xaffcb8: ret
    //     0xaffcb8: ret             
    // 0xaffcbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaffcbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaffcc0: b               #0xaffc8c
  }
  _ _FABDefaultsM3(/* No info */) {
    // ** addr: 0xb21234, size: 0xcc
    // 0xb21234: EnterFrame
    //     0xb21234: stp             fp, lr, [SP, #-0x10]!
    //     0xb21238: mov             fp, SP
    // 0xb2123c: r8 = Sentinel
    //     0xb2123c: ldr             x8, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb21240: r7 = 6.000000
    //     0xb21240: add             x7, PP, #0x28, lsl #12  ; [pp+0x28c20] 6
    //     0xb21244: ldr             x7, [x7, #0xc20]
    // 0xb21248: r6 = true
    //     0xb21248: add             x6, NULL, #0x20  ; true
    // 0xb2124c: r5 = 8.000000
    //     0xb2124c: add             x5, PP, #0x26, lsl #12  ; [pp+0x26c18] 8
    //     0xb21250: ldr             x5, [x5, #0xc18]
    // 0xb21254: r4 = Instance_BoxConstraints
    //     0xb21254: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e558] Obj!BoxConstraints@b35621
    //     0xb21258: ldr             x4, [x4, #0x558]
    // 0xb2125c: r3 = Instance_BoxConstraints
    //     0xb2125c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e548] Obj!BoxConstraints@b35591
    //     0xb21260: ldr             x3, [x3, #0x548]
    // 0xb21264: r2 = Instance_BoxConstraints
    //     0xb21264: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e538] Obj!BoxConstraints@b355f1
    //     0xb21268: ldr             x2, [x2, #0x538]
    // 0xb2126c: r1 = Instance_BoxConstraints
    //     0xb2126c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e540] Obj!BoxConstraints@b355c1
    //     0xb21270: ldr             x1, [x1, #0x540]
    // 0xb21274: ldr             x9, [fp, #0x28]
    // 0xb21278: StoreField: r9->field_67 = r8
    //     0xb21278: stur            w8, [x9, #0x67]
    // 0xb2127c: StoreField: r9->field_6b = r8
    //     0xb2127c: stur            w8, [x9, #0x6b]
    // 0xb21280: ldr             x0, [fp, #0x20]
    // 0xb21284: StoreField: r9->field_5b = r0
    //     0xb21284: stur            w0, [x9, #0x5b]
    //     0xb21288: ldurb           w16, [x9, #-1]
    //     0xb2128c: ldurb           w17, [x0, #-1]
    //     0xb21290: and             x16, x17, x16, lsr #2
    //     0xb21294: tst             x16, HEAP, lsr #32
    //     0xb21298: b.eq            #0xb212a0
    //     0xb2129c: bl              #0xd6836c
    // 0xb212a0: ldr             x0, [fp, #0x18]
    // 0xb212a4: StoreField: r9->field_5f = r0
    //     0xb212a4: stur            w0, [x9, #0x5f]
    //     0xb212a8: ldurb           w16, [x9, #-1]
    //     0xb212ac: ldurb           w17, [x0, #-1]
    //     0xb212b0: and             x16, x17, x16, lsr #2
    //     0xb212b4: tst             x16, HEAP, lsr #32
    //     0xb212b8: b.eq            #0xb212c0
    //     0xb212bc: bl              #0xd6836c
    // 0xb212c0: ldr             x8, [fp, #0x10]
    // 0xb212c4: StoreField: r9->field_63 = r8
    //     0xb212c4: stur            w8, [x9, #0x63]
    // 0xb212c8: StoreField: r9->field_1b = r7
    //     0xb212c8: stur            w7, [x9, #0x1b]
    // 0xb212cc: StoreField: r9->field_1f = r7
    //     0xb212cc: stur            w7, [x9, #0x1f]
    // 0xb212d0: StoreField: r9->field_23 = r5
    //     0xb212d0: stur            w5, [x9, #0x23]
    // 0xb212d4: StoreField: r9->field_2b = r7
    //     0xb212d4: stur            w7, [x9, #0x2b]
    // 0xb212d8: StoreField: r9->field_33 = r6
    //     0xb212d8: stur            w6, [x9, #0x33]
    // 0xb212dc: StoreField: r9->field_3b = r2
    //     0xb212dc: stur            w2, [x9, #0x3b]
    // 0xb212e0: StoreField: r9->field_3f = r1
    //     0xb212e0: stur            w1, [x9, #0x3f]
    // 0xb212e4: StoreField: r9->field_43 = r3
    //     0xb212e4: stur            w3, [x9, #0x43]
    // 0xb212e8: StoreField: r9->field_47 = r4
    //     0xb212e8: stur            w4, [x9, #0x47]
    // 0xb212ec: StoreField: r9->field_4b = r5
    //     0xb212ec: stur            w5, [x9, #0x4b]
    // 0xb212f0: r0 = Null
    //     0xb212f0: mov             x0, NULL
    // 0xb212f4: LeaveFrame
    //     0xb212f4: mov             SP, fp
    //     0xb212f8: ldp             fp, lr, [SP], #0x10
    // 0xb212fc: ret
    //     0xb212fc: ret             
  }
}

// class id: 2800, size: 0x6c, field offset: 0x5c
class _FABDefaultsM2 extends FloatingActionButtonThemeData {

  _ _FABDefaultsM2(/* No info */) {
    // ** addr: 0xb21100, size: 0x128
    // 0xb21100: EnterFrame
    //     0xb21100: stp             fp, lr, [SP, #-0x10]!
    //     0xb21104: mov             fp, SP
    // 0xb21108: CheckStackOverflow
    //     0xb21108: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2110c: cmp             SP, x16
    //     0xb21110: b.ls            #0xb21220
    // 0xb21114: ldr             x0, [fp, #0x18]
    // 0xb21118: ldr             x1, [fp, #0x28]
    // 0xb2111c: StoreField: r1->field_5b = r0
    //     0xb2111c: stur            w0, [x1, #0x5b]
    //     0xb21120: ldurb           w16, [x1, #-1]
    //     0xb21124: ldurb           w17, [x0, #-1]
    //     0xb21128: and             x16, x17, x16, lsr #2
    //     0xb2112c: tst             x16, HEAP, lsr #32
    //     0xb21130: b.eq            #0xb21138
    //     0xb21134: bl              #0xd6826c
    // 0xb21138: ldr             x0, [fp, #0x10]
    // 0xb2113c: StoreField: r1->field_5f = r0
    //     0xb2113c: stur            w0, [x1, #0x5f]
    // 0xb21140: ldr             x16, [fp, #0x20]
    // 0xb21144: SaveReg r16
    //     0xb21144: str             x16, [SP, #-8]!
    // 0xb21148: r0 = of()
    //     0xb21148: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb2114c: add             SP, SP, #8
    // 0xb21150: ldr             x1, [fp, #0x28]
    // 0xb21154: StoreField: r1->field_63 = r0
    //     0xb21154: stur            w0, [x1, #0x63]
    //     0xb21158: ldurb           w16, [x1, #-1]
    //     0xb2115c: ldurb           w17, [x0, #-1]
    //     0xb21160: and             x16, x17, x16, lsr #2
    //     0xb21164: tst             x16, HEAP, lsr #32
    //     0xb21168: b.eq            #0xb21170
    //     0xb2116c: bl              #0xd6826c
    // 0xb21170: ldr             x16, [fp, #0x20]
    // 0xb21174: SaveReg r16
    //     0xb21174: str             x16, [SP, #-8]!
    // 0xb21178: r0 = of()
    //     0xb21178: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb2117c: add             SP, SP, #8
    // 0xb21180: LoadField: r1 = r0->field_3f
    //     0xb21180: ldur            w1, [x0, #0x3f]
    // 0xb21184: DecompressPointer r1
    //     0xb21184: add             x1, x1, HEAP, lsl #32
    // 0xb21188: mov             x0, x1
    // 0xb2118c: ldr             x1, [fp, #0x28]
    // 0xb21190: StoreField: r1->field_67 = r0
    //     0xb21190: stur            w0, [x1, #0x67]
    //     0xb21194: ldurb           w16, [x1, #-1]
    //     0xb21198: ldurb           w17, [x0, #-1]
    //     0xb2119c: and             x16, x17, x16, lsr #2
    //     0xb211a0: tst             x16, HEAP, lsr #32
    //     0xb211a4: b.eq            #0xb211ac
    //     0xb211a8: bl              #0xd6826c
    // 0xb211ac: r2 = 6.000000
    //     0xb211ac: add             x2, PP, #0x28, lsl #12  ; [pp+0x28c20] 6
    //     0xb211b0: ldr             x2, [x2, #0xc20]
    // 0xb211b4: StoreField: r1->field_1b = r2
    //     0xb211b4: stur            w2, [x1, #0x1b]
    // 0xb211b8: StoreField: r1->field_1f = r2
    //     0xb211b8: stur            w2, [x1, #0x1f]
    // 0xb211bc: r2 = 8.000000
    //     0xb211bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26c18] 8
    //     0xb211c0: ldr             x2, [x2, #0xc18]
    // 0xb211c4: StoreField: r1->field_23 = r2
    //     0xb211c4: stur            w2, [x1, #0x23]
    // 0xb211c8: r3 = 12.000000
    //     0xb211c8: add             x3, PP, #0x1f, lsl #12  ; [pp+0x1fd90] 12
    //     0xb211cc: ldr             x3, [x3, #0xd90]
    // 0xb211d0: StoreField: r1->field_2b = r3
    //     0xb211d0: stur            w3, [x1, #0x2b]
    // 0xb211d4: r3 = true
    //     0xb211d4: add             x3, NULL, #0x20  ; true
    // 0xb211d8: StoreField: r1->field_33 = r3
    //     0xb211d8: stur            w3, [x1, #0x33]
    // 0xb211dc: r3 = Instance_BoxConstraints
    //     0xb211dc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e538] Obj!BoxConstraints@b355f1
    //     0xb211e0: ldr             x3, [x3, #0x538]
    // 0xb211e4: StoreField: r1->field_3b = r3
    //     0xb211e4: stur            w3, [x1, #0x3b]
    // 0xb211e8: r3 = Instance_BoxConstraints
    //     0xb211e8: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e540] Obj!BoxConstraints@b355c1
    //     0xb211ec: ldr             x3, [x3, #0x540]
    // 0xb211f0: StoreField: r1->field_3f = r3
    //     0xb211f0: stur            w3, [x1, #0x3f]
    // 0xb211f4: r3 = Instance_BoxConstraints
    //     0xb211f4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e548] Obj!BoxConstraints@b35591
    //     0xb211f8: ldr             x3, [x3, #0x548]
    // 0xb211fc: StoreField: r1->field_43 = r3
    //     0xb211fc: stur            w3, [x1, #0x43]
    // 0xb21200: r3 = Instance_BoxConstraints
    //     0xb21200: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e550] Obj!BoxConstraints@b35561
    //     0xb21204: ldr             x3, [x3, #0x550]
    // 0xb21208: StoreField: r1->field_47 = r3
    //     0xb21208: stur            w3, [x1, #0x47]
    // 0xb2120c: StoreField: r1->field_4b = r2
    //     0xb2120c: stur            w2, [x1, #0x4b]
    // 0xb21210: r0 = Null
    //     0xb21210: mov             x0, NULL
    // 0xb21214: LeaveFrame
    //     0xb21214: mov             SP, fp
    //     0xb21218: ldp             fp, lr, [SP], #0x10
    // 0xb2121c: ret
    //     0xb2121c: ret             
    // 0xb21220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21220: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21224: b               #0xb21114
  }
}

// class id: 2827, size: 0x10, field offset: 0x8
//   const constructor, 
class _EffectiveMouseCursor extends MaterialStateMouseCursor {

  _ resolve(/* No info */) {
    // ** addr: 0x5a6b28, size: 0x60
    // 0x5a6b28: EnterFrame
    //     0x5a6b28: stp             fp, lr, [SP, #-0x10]!
    //     0x5a6b2c: mov             fp, SP
    // 0x5a6b30: CheckStackOverflow
    //     0x5a6b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a6b34: cmp             SP, x16
    //     0x5a6b38: b.ls            #0x5a6b80
    // 0x5a6b3c: r16 = <MouseCursor?>
    //     0x5a6b3c: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0x5a6b40: ldr             x16, [x16, #0x8b8]
    // 0x5a6b44: stp             NULL, x16, [SP, #-0x10]!
    // 0x5a6b48: ldr             x16, [fp, #0x10]
    // 0x5a6b4c: SaveReg r16
    //     0x5a6b4c: str             x16, [SP, #-8]!
    // 0x5a6b50: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5a6b50: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5a6b54: r0 = resolveAs()
    //     0x5a6b54: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x5a6b58: add             SP, SP, #0x18
    // 0x5a6b5c: r16 = Instance__EnabledAndDisabledMouseCursor
    //     0x5a6b5c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e208] Obj!_EnabledAndDisabledMouseCursor@b489f1
    //     0x5a6b60: ldr             x16, [x16, #0x208]
    // 0x5a6b64: ldr             lr, [fp, #0x10]
    // 0x5a6b68: stp             lr, x16, [SP, #-0x10]!
    // 0x5a6b6c: r0 = resolve()
    //     0x5a6b6c: bl              #0x5a6cbc  ; [package:flutter/src/material/material_state.dart] _EnabledAndDisabledMouseCursor::resolve
    // 0x5a6b70: add             SP, SP, #0x10
    // 0x5a6b74: LeaveFrame
    //     0x5a6b74: mov             SP, fp
    //     0x5a6b78: ldp             fp, lr, [SP], #0x10
    // 0x5a6b7c: ret
    //     0x5a6b7c: ret             
    // 0x5a6b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a6b80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a6b84: b               #0x5a6b3c
  }
  get _ debugDescription(/* No info */) {
    // ** addr: 0xc0b144, size: 0xc
    // 0xc0b144: r0 = "MaterialStateMouseCursor(FloatActionButton)"
    //     0xc0b144: add             x0, PP, #0x37, lsl #12  ; [pp+0x378e8] "MaterialStateMouseCursor(FloatActionButton)"
    //     0xc0b148: ldr             x0, [x0, #0x8e8]
    // 0xc0b14c: ret
    //     0xc0b14c: ret             
  }
}

// class id: 3673, size: 0x10, field offset: 0x10
//   const constructor, 
class _ChildOverflowBox extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c2858, size: 0xb0
    // 0x6c2858: EnterFrame
    //     0x6c2858: stp             fp, lr, [SP, #-0x10]!
    //     0x6c285c: mov             fp, SP
    // 0x6c2860: CheckStackOverflow
    //     0x6c2860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2864: cmp             SP, x16
    //     0x6c2868: b.ls            #0x6c2900
    // 0x6c286c: ldr             x0, [fp, #0x10]
    // 0x6c2870: r2 = Null
    //     0x6c2870: mov             x2, NULL
    // 0x6c2874: r1 = Null
    //     0x6c2874: mov             x1, NULL
    // 0x6c2878: r4 = 59
    //     0x6c2878: mov             x4, #0x3b
    // 0x6c287c: branchIfSmi(r0, 0x6c2888)
    //     0x6c287c: tbz             w0, #0, #0x6c2888
    // 0x6c2880: r4 = LoadClassIdInstr(r0)
    //     0x6c2880: ldur            x4, [x0, #-1]
    //     0x6c2884: ubfx            x4, x4, #0xc, #0x14
    // 0x6c2888: cmp             x4, #0x9a6
    // 0x6c288c: b.eq            #0x6c28a4
    // 0x6c2890: r8 = _RenderChildOverflowBox
    //     0x6c2890: add             x8, PP, #0x37, lsl #12  ; [pp+0x378f0] Type: _RenderChildOverflowBox
    //     0x6c2894: ldr             x8, [x8, #0x8f0]
    // 0x6c2898: r3 = Null
    //     0x6c2898: add             x3, PP, #0x37, lsl #12  ; [pp+0x378f8] Null
    //     0x6c289c: ldr             x3, [x3, #0x8f8]
    // 0x6c28a0: r0 = DefaultTypeTest()
    //     0x6c28a0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c28a4: ldr             x16, [fp, #0x18]
    // 0x6c28a8: SaveReg r16
    //     0x6c28a8: str             x16, [SP, #-8]!
    // 0x6c28ac: r0 = of()
    //     0x6c28ac: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x6c28b0: add             SP, SP, #8
    // 0x6c28b4: ldr             x1, [fp, #0x10]
    // 0x6c28b8: LoadField: r2 = r1->field_6b
    //     0x6c28b8: ldur            w2, [x1, #0x6b]
    // 0x6c28bc: DecompressPointer r2
    //     0x6c28bc: add             x2, x2, HEAP, lsl #32
    // 0x6c28c0: cmp             w2, w0
    // 0x6c28c4: b.eq            #0x6c28f0
    // 0x6c28c8: StoreField: r1->field_6b = r0
    //     0x6c28c8: stur            w0, [x1, #0x6b]
    //     0x6c28cc: ldurb           w16, [x1, #-1]
    //     0x6c28d0: ldurb           w17, [x0, #-1]
    //     0x6c28d4: and             x16, x17, x16, lsr #2
    //     0x6c28d8: tst             x16, HEAP, lsr #32
    //     0x6c28dc: b.eq            #0x6c28e4
    //     0x6c28e0: bl              #0xd6826c
    // 0x6c28e4: SaveReg r1
    //     0x6c28e4: str             x1, [SP, #-8]!
    // 0x6c28e8: r0 = _markNeedResolution()
    //     0x6c28e8: bl              #0x6c25fc  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0x6c28ec: add             SP, SP, #8
    // 0x6c28f0: r0 = Null
    //     0x6c28f0: mov             x0, NULL
    // 0x6c28f4: LeaveFrame
    //     0x6c28f4: mov             SP, fp
    //     0x6c28f8: ldp             fp, lr, [SP], #0x10
    // 0x6c28fc: ret
    //     0x6c28fc: ret             
    // 0x6c2900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2900: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2904: b               #0x6c286c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6ea29c, size: 0x80
    // 0x6ea29c: EnterFrame
    //     0x6ea29c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea2a0: mov             fp, SP
    // 0x6ea2a4: AllocStack(0x10)
    //     0x6ea2a4: sub             SP, SP, #0x10
    // 0x6ea2a8: CheckStackOverflow
    //     0x6ea2a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea2ac: cmp             SP, x16
    //     0x6ea2b0: b.ls            #0x6ea314
    // 0x6ea2b4: ldr             x16, [fp, #0x10]
    // 0x6ea2b8: SaveReg r16
    //     0x6ea2b8: str             x16, [SP, #-8]!
    // 0x6ea2bc: r0 = of()
    //     0x6ea2bc: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x6ea2c0: add             SP, SP, #8
    // 0x6ea2c4: stur            x0, [fp, #-8]
    // 0x6ea2c8: r0 = _RenderChildOverflowBox()
    //     0x6ea2c8: bl              #0x6ea31c  ; Allocate_RenderChildOverflowBoxStub -> _RenderChildOverflowBox (size=0x70)
    // 0x6ea2cc: mov             x1, x0
    // 0x6ea2d0: r0 = Instance_Alignment
    //     0x6ea2d0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x6ea2d4: ldr             x0, [x0, #0xc70]
    // 0x6ea2d8: stur            x1, [fp, #-0x10]
    // 0x6ea2dc: StoreField: r1->field_67 = r0
    //     0x6ea2dc: stur            w0, [x1, #0x67]
    // 0x6ea2e0: ldur            x0, [fp, #-8]
    // 0x6ea2e4: StoreField: r1->field_6b = r0
    //     0x6ea2e4: stur            w0, [x1, #0x6b]
    // 0x6ea2e8: SaveReg r1
    //     0x6ea2e8: str             x1, [SP, #-8]!
    // 0x6ea2ec: r0 = RenderObject()
    //     0x6ea2ec: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ea2f0: add             SP, SP, #8
    // 0x6ea2f4: ldur            x16, [fp, #-0x10]
    // 0x6ea2f8: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea2fc: r0 = child=()
    //     0x6ea2fc: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ea300: add             SP, SP, #0x10
    // 0x6ea304: ldur            x0, [fp, #-0x10]
    // 0x6ea308: LeaveFrame
    //     0x6ea308: mov             SP, fp
    //     0x6ea30c: ldp             fp, lr, [SP], #0x10
    // 0x6ea310: ret
    //     0x6ea310: ret             
    // 0x6ea314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea314: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea318: b               #0x6ea2b4
  }
}

// class id: 3856, size: 0x78, field offset: 0xc
//   const constructor, 
class FloatingActionButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb2037c, size: 0xd60
    // 0xb2037c: EnterFrame
    //     0xb2037c: stp             fp, lr, [SP, #-0x10]!
    //     0xb20380: mov             fp, SP
    // 0xb20384: AllocStack(0x90)
    //     0xb20384: sub             SP, SP, #0x90
    // 0xb20388: CheckStackOverflow
    //     0xb20388: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2038c: cmp             SP, x16
    //     0xb20390: b.ls            #0xb21034
    // 0xb20394: ldr             x16, [fp, #0x10]
    // 0xb20398: SaveReg r16
    //     0xb20398: str             x16, [SP, #-8]!
    // 0xb2039c: r0 = of()
    //     0xb2039c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb203a0: add             SP, SP, #8
    // 0xb203a4: stur            x0, [fp, #-0x18]
    // 0xb203a8: LoadField: r1 = r0->field_e7
    //     0xb203a8: ldur            w1, [x0, #0xe7]
    // 0xb203ac: DecompressPointer r1
    //     0xb203ac: add             x1, x1, HEAP, lsl #32
    // 0xb203b0: stur            x1, [fp, #-0x10]
    // 0xb203b4: LoadField: r2 = r0->field_2b
    //     0xb203b4: ldur            w2, [x0, #0x2b]
    // 0xb203b8: DecompressPointer r2
    //     0xb203b8: add             x2, x2, HEAP, lsl #32
    // 0xb203bc: tbnz            w2, #4, #0xb20400
    // 0xb203c0: ldr             x2, [fp, #0x18]
    // 0xb203c4: LoadField: r3 = r2->field_6f
    //     0xb203c4: ldur            w3, [x2, #0x6f]
    // 0xb203c8: DecompressPointer r3
    //     0xb203c8: add             x3, x3, HEAP, lsl #32
    // 0xb203cc: stur            x3, [fp, #-8]
    // 0xb203d0: r0 = _FABDefaultsM3()
    //     0xb203d0: bl              #0xb21300  ; Allocate_FABDefaultsM3Stub -> _FABDefaultsM3 (size=0x70)
    // 0xb203d4: stur            x0, [fp, #-0x20]
    // 0xb203d8: ldr             x16, [fp, #0x10]
    // 0xb203dc: stp             x16, x0, [SP, #-0x10]!
    // 0xb203e0: ldur            x16, [fp, #-8]
    // 0xb203e4: r30 = true
    //     0xb203e4: add             lr, NULL, #0x20  ; true
    // 0xb203e8: stp             lr, x16, [SP, #-0x10]!
    // 0xb203ec: r0 = _FABDefaultsM3()
    //     0xb203ec: bl              #0xb21234  ; [package:flutter/src/material/floating_action_button.dart] _FABDefaultsM3::_FABDefaultsM3
    // 0xb203f0: add             SP, SP, #0x20
    // 0xb203f4: ldur            x2, [fp, #-0x20]
    // 0xb203f8: ldur            x0, [fp, #-8]
    // 0xb203fc: b               #0xb2043c
    // 0xb20400: ldr             x0, [fp, #0x18]
    // 0xb20404: LoadField: r1 = r0->field_6f
    //     0xb20404: ldur            w1, [x0, #0x6f]
    // 0xb20408: DecompressPointer r1
    //     0xb20408: add             x1, x1, HEAP, lsl #32
    // 0xb2040c: stur            x1, [fp, #-8]
    // 0xb20410: r0 = _FABDefaultsM2()
    //     0xb20410: bl              #0xb21228  ; Allocate_FABDefaultsM2Stub -> _FABDefaultsM2 (size=0x6c)
    // 0xb20414: stur            x0, [fp, #-0x20]
    // 0xb20418: ldr             x16, [fp, #0x10]
    // 0xb2041c: stp             x16, x0, [SP, #-0x10]!
    // 0xb20420: ldur            x16, [fp, #-8]
    // 0xb20424: r30 = true
    //     0xb20424: add             lr, NULL, #0x20  ; true
    // 0xb20428: stp             lr, x16, [SP, #-0x10]!
    // 0xb2042c: r0 = _FABDefaultsM2()
    //     0xb2042c: bl              #0xb21100  ; [package:flutter/src/material/floating_action_button.dart] _FABDefaultsM2::_FABDefaultsM2
    // 0xb20430: add             SP, SP, #0x20
    // 0xb20434: ldur            x2, [fp, #-0x20]
    // 0xb20438: ldur            x0, [fp, #-8]
    // 0xb2043c: stur            x2, [fp, #-0x20]
    // 0xb20440: stur            x0, [fp, #-0x28]
    // 0xb20444: r3 = LoadClassIdInstr(r2)
    //     0xb20444: ldur            x3, [x2, #-1]
    //     0xb20448: ubfx            x3, x3, #0xc, #0x14
    // 0xb2044c: lsl             x3, x3, #1
    // 0xb20450: stur            x3, [fp, #-8]
    // 0xb20454: r17 = 5596
    //     0xb20454: mov             x17, #0x15dc
    // 0xb20458: cmp             w3, w17
    // 0xb2045c: b.ne            #0xb20474
    // 0xb20460: LoadField: r1 = r2->field_7
    //     0xb20460: ldur            w1, [x2, #7]
    // 0xb20464: DecompressPointer r1
    //     0xb20464: add             x1, x1, HEAP, lsl #32
    // 0xb20468: mov             x3, x1
    // 0xb2046c: mov             x0, x2
    // 0xb20470: b               #0xb204ec
    // 0xb20474: r17 = 5598
    //     0xb20474: mov             x17, #0x15de
    // 0xb20478: cmp             w3, w17
    // 0xb2047c: b.ne            #0xb204d4
    // 0xb20480: mov             x1, x2
    // 0xb20484: LoadField: r0 = r1->field_67
    //     0xb20484: ldur            w0, [x1, #0x67]
    // 0xb20488: DecompressPointer r0
    //     0xb20488: add             x0, x0, HEAP, lsl #32
    // 0xb2048c: r16 = Sentinel
    //     0xb2048c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb20490: cmp             w0, w16
    // 0xb20494: b.ne            #0xb204a4
    // 0xb20498: r2 = _colors
    //     0xb20498: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xb2049c: ldr             x2, [x2, #0x328]
    // 0xb204a0: r0 = InitLateFinalInstanceField()
    //     0xb204a0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb204a4: LoadField: r1 = r0->field_17
    //     0xb204a4: ldur            w1, [x0, #0x17]
    // 0xb204a8: DecompressPointer r1
    //     0xb204a8: add             x1, x1, HEAP, lsl #32
    // 0xb204ac: cmp             w1, NULL
    // 0xb204b0: b.ne            #0xb204c4
    // 0xb204b4: LoadField: r1 = r0->field_f
    //     0xb204b4: ldur            w1, [x0, #0xf]
    // 0xb204b8: DecompressPointer r1
    //     0xb204b8: add             x1, x1, HEAP, lsl #32
    // 0xb204bc: mov             x0, x1
    // 0xb204c0: b               #0xb204c8
    // 0xb204c4: mov             x0, x1
    // 0xb204c8: mov             x3, x0
    // 0xb204cc: ldur            x0, [fp, #-0x20]
    // 0xb204d0: b               #0xb204ec
    // 0xb204d4: mov             x0, x2
    // 0xb204d8: LoadField: r1 = r0->field_67
    //     0xb204d8: ldur            w1, [x0, #0x67]
    // 0xb204dc: DecompressPointer r1
    //     0xb204dc: add             x1, x1, HEAP, lsl #32
    // 0xb204e0: LoadField: r2 = r1->field_1f
    //     0xb204e0: ldur            w2, [x1, #0x1f]
    // 0xb204e4: DecompressPointer r2
    //     0xb204e4: add             x2, x2, HEAP, lsl #32
    // 0xb204e8: mov             x3, x2
    // 0xb204ec: ldr             x2, [fp, #0x18]
    // 0xb204f0: stur            x3, [fp, #-0x30]
    // 0xb204f4: LoadField: r1 = r2->field_17
    //     0xb204f4: ldur            w1, [x2, #0x17]
    // 0xb204f8: DecompressPointer r1
    //     0xb204f8: add             x1, x1, HEAP, lsl #32
    // 0xb204fc: cmp             w1, NULL
    // 0xb20500: b.ne            #0xb20508
    // 0xb20504: r1 = Null
    //     0xb20504: mov             x1, NULL
    // 0xb20508: cmp             w1, NULL
    // 0xb2050c: b.ne            #0xb205a8
    // 0xb20510: ldur            x4, [fp, #-8]
    // 0xb20514: r17 = 5596
    //     0xb20514: mov             x17, #0x15dc
    // 0xb20518: cmp             w4, w17
    // 0xb2051c: b.ne            #0xb2052c
    // 0xb20520: LoadField: r1 = r0->field_b
    //     0xb20520: ldur            w1, [x0, #0xb]
    // 0xb20524: DecompressPointer r1
    //     0xb20524: add             x1, x1, HEAP, lsl #32
    // 0xb20528: b               #0xb205a0
    // 0xb2052c: r17 = 5598
    //     0xb2052c: mov             x17, #0x15de
    // 0xb20530: cmp             w4, w17
    // 0xb20534: b.ne            #0xb2058c
    // 0xb20538: mov             x1, x0
    // 0xb2053c: LoadField: r0 = r1->field_67
    //     0xb2053c: ldur            w0, [x1, #0x67]
    // 0xb20540: DecompressPointer r0
    //     0xb20540: add             x0, x0, HEAP, lsl #32
    // 0xb20544: r16 = Sentinel
    //     0xb20544: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb20548: cmp             w0, w16
    // 0xb2054c: b.ne            #0xb2055c
    // 0xb20550: r2 = _colors
    //     0xb20550: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xb20554: ldr             x2, [x2, #0x328]
    // 0xb20558: r0 = InitLateFinalInstanceField()
    //     0xb20558: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb2055c: LoadField: r1 = r0->field_13
    //     0xb2055c: ldur            w1, [x0, #0x13]
    // 0xb20560: DecompressPointer r1
    //     0xb20560: add             x1, x1, HEAP, lsl #32
    // 0xb20564: cmp             w1, NULL
    // 0xb20568: b.ne            #0xb2057c
    // 0xb2056c: LoadField: r1 = r0->field_b
    //     0xb2056c: ldur            w1, [x0, #0xb]
    // 0xb20570: DecompressPointer r1
    //     0xb20570: add             x1, x1, HEAP, lsl #32
    // 0xb20574: mov             x0, x1
    // 0xb20578: b               #0xb20580
    // 0xb2057c: mov             x0, x1
    // 0xb20580: mov             x1, x0
    // 0xb20584: ldur            x0, [fp, #-0x20]
    // 0xb20588: b               #0xb205a0
    // 0xb2058c: LoadField: r1 = r0->field_67
    //     0xb2058c: ldur            w1, [x0, #0x67]
    // 0xb20590: DecompressPointer r1
    //     0xb20590: add             x1, x1, HEAP, lsl #32
    // 0xb20594: LoadField: r2 = r1->field_1b
    //     0xb20594: ldur            w2, [x1, #0x1b]
    // 0xb20598: DecompressPointer r2
    //     0xb20598: add             x2, x2, HEAP, lsl #32
    // 0xb2059c: mov             x1, x2
    // 0xb205a0: mov             x3, x1
    // 0xb205a4: b               #0xb205ac
    // 0xb205a8: mov             x3, x1
    // 0xb205ac: ldur            x2, [fp, #-8]
    // 0xb205b0: stur            x3, [fp, #-0x38]
    // 0xb205b4: r17 = 5596
    //     0xb205b4: mov             x17, #0x15dc
    // 0xb205b8: cmp             w2, w17
    // 0xb205bc: b.ne            #0xb205d0
    // 0xb205c0: LoadField: r1 = r0->field_f
    //     0xb205c0: ldur            w1, [x0, #0xf]
    // 0xb205c4: DecompressPointer r1
    //     0xb205c4: add             x1, x1, HEAP, lsl #32
    // 0xb205c8: mov             x3, x1
    // 0xb205cc: b               #0xb2065c
    // 0xb205d0: r17 = 5598
    //     0xb205d0: mov             x17, #0x15de
    // 0xb205d4: cmp             w2, w17
    // 0xb205d8: b.ne            #0xb20648
    // 0xb205dc: mov             x1, x0
    // 0xb205e0: LoadField: r0 = r1->field_67
    //     0xb205e0: ldur            w0, [x1, #0x67]
    // 0xb205e4: DecompressPointer r0
    //     0xb205e4: add             x0, x0, HEAP, lsl #32
    // 0xb205e8: r16 = Sentinel
    //     0xb205e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb205ec: cmp             w0, w16
    // 0xb205f0: b.ne            #0xb20600
    // 0xb205f4: r2 = _colors
    //     0xb205f4: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xb205f8: ldr             x2, [x2, #0x328]
    // 0xb205fc: r0 = InitLateFinalInstanceField()
    //     0xb205fc: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb20600: LoadField: r1 = r0->field_17
    //     0xb20600: ldur            w1, [x0, #0x17]
    // 0xb20604: DecompressPointer r1
    //     0xb20604: add             x1, x1, HEAP, lsl #32
    // 0xb20608: cmp             w1, NULL
    // 0xb2060c: b.ne            #0xb20620
    // 0xb20610: LoadField: r1 = r0->field_f
    //     0xb20610: ldur            w1, [x0, #0xf]
    // 0xb20614: DecompressPointer r1
    //     0xb20614: add             x1, x1, HEAP, lsl #32
    // 0xb20618: mov             x0, x1
    // 0xb2061c: b               #0xb20624
    // 0xb20620: mov             x0, x1
    // 0xb20624: d0 = 0.120000
    //     0xb20624: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb20628: ldr             d0, [x17, #0xf48]
    // 0xb2062c: SaveReg r0
    //     0xb2062c: str             x0, [SP, #-8]!
    // 0xb20630: SaveReg d0
    //     0xb20630: str             d0, [SP, #-8]!
    // 0xb20634: r0 = withOpacity()
    //     0xb20634: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb20638: add             SP, SP, #0x10
    // 0xb2063c: mov             x3, x0
    // 0xb20640: ldur            x0, [fp, #-0x20]
    // 0xb20644: b               #0xb2065c
    // 0xb20648: LoadField: r1 = r0->field_63
    //     0xb20648: ldur            w1, [x0, #0x63]
    // 0xb2064c: DecompressPointer r1
    //     0xb2064c: add             x1, x1, HEAP, lsl #32
    // 0xb20650: LoadField: r2 = r1->field_4f
    //     0xb20650: ldur            w2, [x1, #0x4f]
    // 0xb20654: DecompressPointer r2
    //     0xb20654: add             x2, x2, HEAP, lsl #32
    // 0xb20658: mov             x3, x2
    // 0xb2065c: ldr             x2, [fp, #0x18]
    // 0xb20660: stur            x3, [fp, #-0x40]
    // 0xb20664: LoadField: r1 = r2->field_1f
    //     0xb20664: ldur            w1, [x2, #0x1f]
    // 0xb20668: DecompressPointer r1
    //     0xb20668: add             x1, x1, HEAP, lsl #32
    // 0xb2066c: cmp             w1, NULL
    // 0xb20670: b.ne            #0xb20678
    // 0xb20674: r1 = Null
    //     0xb20674: mov             x1, NULL
    // 0xb20678: cmp             w1, NULL
    // 0xb2067c: b.ne            #0xb20730
    // 0xb20680: ldur            x4, [fp, #-8]
    // 0xb20684: r17 = 5596
    //     0xb20684: mov             x17, #0x15dc
    // 0xb20688: cmp             w4, w17
    // 0xb2068c: b.ne            #0xb2069c
    // 0xb20690: LoadField: r1 = r0->field_13
    //     0xb20690: ldur            w1, [x0, #0x13]
    // 0xb20694: DecompressPointer r1
    //     0xb20694: add             x1, x1, HEAP, lsl #32
    // 0xb20698: b               #0xb20728
    // 0xb2069c: r17 = 5598
    //     0xb2069c: mov             x17, #0x15de
    // 0xb206a0: cmp             w4, w17
    // 0xb206a4: b.ne            #0xb20714
    // 0xb206a8: mov             x1, x0
    // 0xb206ac: LoadField: r0 = r1->field_67
    //     0xb206ac: ldur            w0, [x1, #0x67]
    // 0xb206b0: DecompressPointer r0
    //     0xb206b0: add             x0, x0, HEAP, lsl #32
    // 0xb206b4: r16 = Sentinel
    //     0xb206b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb206b8: cmp             w0, w16
    // 0xb206bc: b.ne            #0xb206cc
    // 0xb206c0: r2 = _colors
    //     0xb206c0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xb206c4: ldr             x2, [x2, #0x328]
    // 0xb206c8: r0 = InitLateFinalInstanceField()
    //     0xb206c8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb206cc: LoadField: r1 = r0->field_17
    //     0xb206cc: ldur            w1, [x0, #0x17]
    // 0xb206d0: DecompressPointer r1
    //     0xb206d0: add             x1, x1, HEAP, lsl #32
    // 0xb206d4: cmp             w1, NULL
    // 0xb206d8: b.ne            #0xb206ec
    // 0xb206dc: LoadField: r1 = r0->field_f
    //     0xb206dc: ldur            w1, [x0, #0xf]
    // 0xb206e0: DecompressPointer r1
    //     0xb206e0: add             x1, x1, HEAP, lsl #32
    // 0xb206e4: mov             x0, x1
    // 0xb206e8: b               #0xb206f0
    // 0xb206ec: mov             x0, x1
    // 0xb206f0: d0 = 0.080000
    //     0xb206f0: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xb206f4: ldr             d0, [x17, #0xf80]
    // 0xb206f8: SaveReg r0
    //     0xb206f8: str             x0, [SP, #-8]!
    // 0xb206fc: SaveReg d0
    //     0xb206fc: str             d0, [SP, #-8]!
    // 0xb20700: r0 = withOpacity()
    //     0xb20700: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb20704: add             SP, SP, #0x10
    // 0xb20708: mov             x1, x0
    // 0xb2070c: ldur            x0, [fp, #-0x20]
    // 0xb20710: b               #0xb20728
    // 0xb20714: LoadField: r1 = r0->field_63
    //     0xb20714: ldur            w1, [x0, #0x63]
    // 0xb20718: DecompressPointer r1
    //     0xb20718: add             x1, x1, HEAP, lsl #32
    // 0xb2071c: LoadField: r2 = r1->field_5b
    //     0xb2071c: ldur            w2, [x1, #0x5b]
    // 0xb20720: DecompressPointer r2
    //     0xb20720: add             x2, x2, HEAP, lsl #32
    // 0xb20724: mov             x1, x2
    // 0xb20728: mov             x3, x1
    // 0xb2072c: b               #0xb20734
    // 0xb20730: mov             x3, x1
    // 0xb20734: ldur            x2, [fp, #-8]
    // 0xb20738: stur            x3, [fp, #-0x48]
    // 0xb2073c: r17 = 5596
    //     0xb2073c: mov             x17, #0x15dc
    // 0xb20740: cmp             w2, w17
    // 0xb20744: b.ne            #0xb20758
    // 0xb20748: LoadField: r1 = r0->field_17
    //     0xb20748: ldur            w1, [x0, #0x17]
    // 0xb2074c: DecompressPointer r1
    //     0xb2074c: add             x1, x1, HEAP, lsl #32
    // 0xb20750: mov             x3, x1
    // 0xb20754: b               #0xb207e4
    // 0xb20758: r17 = 5598
    //     0xb20758: mov             x17, #0x15de
    // 0xb2075c: cmp             w2, w17
    // 0xb20760: b.ne            #0xb207d0
    // 0xb20764: mov             x1, x0
    // 0xb20768: LoadField: r0 = r1->field_67
    //     0xb20768: ldur            w0, [x1, #0x67]
    // 0xb2076c: DecompressPointer r0
    //     0xb2076c: add             x0, x0, HEAP, lsl #32
    // 0xb20770: r16 = Sentinel
    //     0xb20770: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb20774: cmp             w0, w16
    // 0xb20778: b.ne            #0xb20788
    // 0xb2077c: r2 = _colors
    //     0xb2077c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xb20780: ldr             x2, [x2, #0x328]
    // 0xb20784: r0 = InitLateFinalInstanceField()
    //     0xb20784: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb20788: LoadField: r1 = r0->field_17
    //     0xb20788: ldur            w1, [x0, #0x17]
    // 0xb2078c: DecompressPointer r1
    //     0xb2078c: add             x1, x1, HEAP, lsl #32
    // 0xb20790: cmp             w1, NULL
    // 0xb20794: b.ne            #0xb207a8
    // 0xb20798: LoadField: r1 = r0->field_f
    //     0xb20798: ldur            w1, [x0, #0xf]
    // 0xb2079c: DecompressPointer r1
    //     0xb2079c: add             x1, x1, HEAP, lsl #32
    // 0xb207a0: mov             x0, x1
    // 0xb207a4: b               #0xb207ac
    // 0xb207a8: mov             x0, x1
    // 0xb207ac: d0 = 0.120000
    //     0xb207ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb207b0: ldr             d0, [x17, #0xf48]
    // 0xb207b4: SaveReg r0
    //     0xb207b4: str             x0, [SP, #-8]!
    // 0xb207b8: SaveReg d0
    //     0xb207b8: str             d0, [SP, #-8]!
    // 0xb207bc: r0 = withOpacity()
    //     0xb207bc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb207c0: add             SP, SP, #0x10
    // 0xb207c4: mov             x3, x0
    // 0xb207c8: ldur            x0, [fp, #-0x20]
    // 0xb207cc: b               #0xb207e4
    // 0xb207d0: LoadField: r1 = r0->field_63
    //     0xb207d0: ldur            w1, [x0, #0x63]
    // 0xb207d4: DecompressPointer r1
    //     0xb207d4: add             x1, x1, HEAP, lsl #32
    // 0xb207d8: LoadField: r2 = r1->field_7f
    //     0xb207d8: ldur            w2, [x1, #0x7f]
    // 0xb207dc: DecompressPointer r2
    //     0xb207dc: add             x2, x2, HEAP, lsl #32
    // 0xb207e0: mov             x3, x2
    // 0xb207e4: ldur            x2, [fp, #-0x10]
    // 0xb207e8: stur            x3, [fp, #-0x58]
    // 0xb207ec: LoadField: r1 = r2->field_1b
    //     0xb207ec: ldur            w1, [x2, #0x1b]
    // 0xb207f0: DecompressPointer r1
    //     0xb207f0: add             x1, x1, HEAP, lsl #32
    // 0xb207f4: cmp             w1, NULL
    // 0xb207f8: b.ne            #0xb20814
    // 0xb207fc: LoadField: r1 = r0->field_1b
    //     0xb207fc: ldur            w1, [x0, #0x1b]
    // 0xb20800: DecompressPointer r1
    //     0xb20800: add             x1, x1, HEAP, lsl #32
    // 0xb20804: cmp             w1, NULL
    // 0xb20808: b.eq            #0xb2103c
    // 0xb2080c: LoadField: d0 = r1->field_7
    //     0xb2080c: ldur            d0, [x1, #7]
    // 0xb20810: b               #0xb20818
    // 0xb20814: LoadField: d0 = r1->field_7
    //     0xb20814: ldur            d0, [x1, #7]
    // 0xb20818: stur            d0, [fp, #-0x90]
    // 0xb2081c: LoadField: r1 = r2->field_1f
    //     0xb2081c: ldur            w1, [x2, #0x1f]
    // 0xb20820: DecompressPointer r1
    //     0xb20820: add             x1, x1, HEAP, lsl #32
    // 0xb20824: cmp             w1, NULL
    // 0xb20828: b.ne            #0xb20844
    // 0xb2082c: LoadField: r1 = r0->field_1f
    //     0xb2082c: ldur            w1, [x0, #0x1f]
    // 0xb20830: DecompressPointer r1
    //     0xb20830: add             x1, x1, HEAP, lsl #32
    // 0xb20834: cmp             w1, NULL
    // 0xb20838: b.eq            #0xb21040
    // 0xb2083c: LoadField: d1 = r1->field_7
    //     0xb2083c: ldur            d1, [x1, #7]
    // 0xb20840: b               #0xb20848
    // 0xb20844: LoadField: d1 = r1->field_7
    //     0xb20844: ldur            d1, [x1, #7]
    // 0xb20848: stur            d1, [fp, #-0x88]
    // 0xb2084c: LoadField: r1 = r2->field_23
    //     0xb2084c: ldur            w1, [x2, #0x23]
    // 0xb20850: DecompressPointer r1
    //     0xb20850: add             x1, x1, HEAP, lsl #32
    // 0xb20854: cmp             w1, NULL
    // 0xb20858: b.ne            #0xb20874
    // 0xb2085c: LoadField: r1 = r0->field_23
    //     0xb2085c: ldur            w1, [x0, #0x23]
    // 0xb20860: DecompressPointer r1
    //     0xb20860: add             x1, x1, HEAP, lsl #32
    // 0xb20864: cmp             w1, NULL
    // 0xb20868: b.eq            #0xb21044
    // 0xb2086c: LoadField: d2 = r1->field_7
    //     0xb2086c: ldur            d2, [x1, #7]
    // 0xb20870: b               #0xb20878
    // 0xb20874: LoadField: d2 = r1->field_7
    //     0xb20874: ldur            d2, [x1, #7]
    // 0xb20878: stur            d2, [fp, #-0x80]
    // 0xb2087c: LoadField: r1 = r2->field_27
    //     0xb2087c: ldur            w1, [x2, #0x27]
    // 0xb20880: DecompressPointer r1
    //     0xb20880: add             x1, x1, HEAP, lsl #32
    // 0xb20884: cmp             w1, NULL
    // 0xb20888: b.ne            #0xb20894
    // 0xb2088c: LoadField: r1 = r0->field_27
    //     0xb2088c: ldur            w1, [x0, #0x27]
    // 0xb20890: DecompressPointer r1
    //     0xb20890: add             x1, x1, HEAP, lsl #32
    // 0xb20894: cmp             w1, NULL
    // 0xb20898: b.ne            #0xb208a4
    // 0xb2089c: mov             v3.16b, v0.16b
    // 0xb208a0: b               #0xb208a8
    // 0xb208a4: LoadField: d3 = r1->field_7
    //     0xb208a4: ldur            d3, [x1, #7]
    // 0xb208a8: stur            d3, [fp, #-0x78]
    // 0xb208ac: LoadField: r1 = r2->field_2b
    //     0xb208ac: ldur            w1, [x2, #0x2b]
    // 0xb208b0: DecompressPointer r1
    //     0xb208b0: add             x1, x1, HEAP, lsl #32
    // 0xb208b4: cmp             w1, NULL
    // 0xb208b8: b.ne            #0xb208d4
    // 0xb208bc: LoadField: r1 = r0->field_2b
    //     0xb208bc: ldur            w1, [x0, #0x2b]
    // 0xb208c0: DecompressPointer r1
    //     0xb208c0: add             x1, x1, HEAP, lsl #32
    // 0xb208c4: cmp             w1, NULL
    // 0xb208c8: b.eq            #0xb21048
    // 0xb208cc: LoadField: d4 = r1->field_7
    //     0xb208cc: ldur            d4, [x1, #7]
    // 0xb208d0: b               #0xb208d8
    // 0xb208d4: LoadField: d4 = r1->field_7
    //     0xb208d4: ldur            d4, [x1, #7]
    // 0xb208d8: ldur            x1, [fp, #-0x18]
    // 0xb208dc: stur            d4, [fp, #-0x70]
    // 0xb208e0: LoadField: r4 = r1->field_17
    //     0xb208e0: ldur            w4, [x1, #0x17]
    // 0xb208e4: DecompressPointer r4
    //     0xb208e4: add             x4, x4, HEAP, lsl #32
    // 0xb208e8: stur            x4, [fp, #-0x50]
    // 0xb208ec: LoadField: r1 = r2->field_33
    //     0xb208ec: ldur            w1, [x2, #0x33]
    // 0xb208f0: DecompressPointer r1
    //     0xb208f0: add             x1, x1, HEAP, lsl #32
    // 0xb208f4: cmp             w1, NULL
    // 0xb208f8: b.ne            #0xb2090c
    // 0xb208fc: LoadField: r1 = r0->field_33
    //     0xb208fc: ldur            w1, [x0, #0x33]
    // 0xb20900: DecompressPointer r1
    //     0xb20900: add             x1, x1, HEAP, lsl #32
    // 0xb20904: cmp             w1, NULL
    // 0xb20908: b.eq            #0xb2104c
    // 0xb2090c: LoadField: r1 = r2->field_37
    //     0xb2090c: ldur            w1, [x2, #0x37]
    // 0xb20910: DecompressPointer r1
    //     0xb20910: add             x1, x1, HEAP, lsl #32
    // 0xb20914: cmp             w1, NULL
    // 0xb20918: b.ne            #0xb209f8
    // 0xb2091c: ldur            x5, [fp, #-8]
    // 0xb20920: r17 = 5596
    //     0xb20920: mov             x17, #0x15dc
    // 0xb20924: cmp             w5, w17
    // 0xb20928: b.ne            #0xb20938
    // 0xb2092c: LoadField: r1 = r0->field_37
    //     0xb2092c: ldur            w1, [x0, #0x37]
    // 0xb20930: DecompressPointer r1
    //     0xb20930: add             x1, x1, HEAP, lsl #32
    // 0xb20934: b               #0xb209e8
    // 0xb20938: r17 = 5598
    //     0xb20938: mov             x17, #0x15de
    // 0xb2093c: cmp             w5, w17
    // 0xb20940: b.ne            #0xb20998
    // 0xb20944: LoadField: r1 = r0->field_5f
    //     0xb20944: ldur            w1, [x0, #0x5f]
    // 0xb20948: DecompressPointer r1
    //     0xb20948: add             x1, x1, HEAP, lsl #32
    // 0xb2094c: LoadField: r6 = r1->field_7
    //     0xb2094c: ldur            x6, [x1, #7]
    // 0xb20950: cmp             x6, #1
    // 0xb20954: b.gt            #0xb20978
    // 0xb20958: cmp             x6, #0
    // 0xb2095c: b.gt            #0xb2096c
    // 0xb20960: r1 = 24.000000
    //     0xb20960: add             x1, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xb20964: ldr             x1, [x1, #0x360]
    // 0xb20968: b               #0xb209e8
    // 0xb2096c: r1 = 24.000000
    //     0xb2096c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xb20970: ldr             x1, [x1, #0x360]
    // 0xb20974: b               #0xb209e8
    // 0xb20978: cmp             x6, #2
    // 0xb2097c: b.gt            #0xb2098c
    // 0xb20980: r1 = 36.000000
    //     0xb20980: add             x1, PP, #0xe, lsl #12  ; [pp+0xe368] 36
    //     0xb20984: ldr             x1, [x1, #0x368]
    // 0xb20988: b               #0xb209e8
    // 0xb2098c: r1 = 24.000000
    //     0xb2098c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xb20990: ldr             x1, [x1, #0x360]
    // 0xb20994: b               #0xb209e8
    // 0xb20998: LoadField: r1 = r0->field_5b
    //     0xb20998: ldur            w1, [x0, #0x5b]
    // 0xb2099c: DecompressPointer r1
    //     0xb2099c: add             x1, x1, HEAP, lsl #32
    // 0xb209a0: r16 = Instance__FloatingActionButtonType
    //     0xb209a0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe370] Obj!_FloatingActionButtonType@b65891
    //     0xb209a4: ldr             x16, [x16, #0x370]
    // 0xb209a8: cmp             w1, w16
    // 0xb209ac: b.ne            #0xb209bc
    // 0xb209b0: d5 = 36.000000
    //     0xb209b0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0xb209b4: ldr             d5, [x17, #0xfa8]
    // 0xb209b8: b               #0xb209c0
    // 0xb209bc: d5 = 24.000000
    //     0xb209bc: fmov            d5, #24.00000000
    // 0xb209c0: r1 = inline_Allocate_Double()
    //     0xb209c0: ldp             x1, x6, [THR, #0x60]  ; THR::top
    //     0xb209c4: add             x1, x1, #0x10
    //     0xb209c8: cmp             x6, x1
    //     0xb209cc: b.ls            #0xb21050
    //     0xb209d0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb209d4: sub             x1, x1, #0xf
    //     0xb209d8: mov             x6, #0xd108
    //     0xb209dc: movk            x6, #3, lsl #16
    //     0xb209e0: stur            x6, [x1, #-1]
    // 0xb209e4: StoreField: r1->field_7 = d5
    //     0xb209e4: stur            d5, [x1, #7]
    // 0xb209e8: cmp             w1, NULL
    // 0xb209ec: b.eq            #0xb2108c
    // 0xb209f0: LoadField: d5 = r1->field_7
    //     0xb209f0: ldur            d5, [x1, #7]
    // 0xb209f4: b               #0xb20a00
    // 0xb209f8: ldur            x5, [fp, #-8]
    // 0xb209fc: LoadField: d5 = r1->field_7
    //     0xb209fc: ldur            d5, [x1, #7]
    // 0xb20a00: stur            d5, [fp, #-0x68]
    // 0xb20a04: r17 = 5596
    //     0xb20a04: mov             x17, #0x15dc
    // 0xb20a08: cmp             w5, w17
    // 0xb20a0c: b.ne            #0xb20a20
    // 0xb20a10: LoadField: r1 = r0->field_53
    //     0xb20a10: ldur            w1, [x0, #0x53]
    // 0xb20a14: DecompressPointer r1
    //     0xb20a14: add             x1, x1, HEAP, lsl #32
    // 0xb20a18: mov             x0, x5
    // 0xb20a1c: b               #0xb20aa4
    // 0xb20a20: r17 = 5598
    //     0xb20a20: mov             x17, #0x15de
    // 0xb20a24: cmp             w5, w17
    // 0xb20a28: b.ne            #0xb20a60
    // 0xb20a2c: mov             x1, x0
    // 0xb20a30: LoadField: r0 = r1->field_6b
    //     0xb20a30: ldur            w0, [x1, #0x6b]
    // 0xb20a34: DecompressPointer r0
    //     0xb20a34: add             x0, x0, HEAP, lsl #32
    // 0xb20a38: r16 = Sentinel
    //     0xb20a38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb20a3c: cmp             w0, w16
    // 0xb20a40: b.ne            #0xb20a50
    // 0xb20a44: r2 = _textTheme
    //     0xb20a44: add             x2, PP, #0xe, lsl #12  ; [pp+0xe378] Field <_FABDefaultsM3@746192485._textTheme@746192485>: late final (offset: 0x6c)
    //     0xb20a48: ldr             x2, [x2, #0x378]
    // 0xb20a4c: r0 = InitLateFinalInstanceField()
    //     0xb20a4c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb20a50: LoadField: r1 = r0->field_37
    //     0xb20a50: ldur            w1, [x0, #0x37]
    // 0xb20a54: DecompressPointer r1
    //     0xb20a54: add             x1, x1, HEAP, lsl #32
    // 0xb20a58: ldur            x0, [fp, #-8]
    // 0xb20a5c: b               #0xb20aa4
    // 0xb20a60: LoadField: r1 = r0->field_63
    //     0xb20a60: ldur            w1, [x0, #0x63]
    // 0xb20a64: DecompressPointer r1
    //     0xb20a64: add             x1, x1, HEAP, lsl #32
    // 0xb20a68: LoadField: r2 = r1->field_93
    //     0xb20a68: ldur            w2, [x1, #0x93]
    // 0xb20a6c: DecompressPointer r2
    //     0xb20a6c: add             x2, x2, HEAP, lsl #32
    // 0xb20a70: LoadField: r1 = r2->field_37
    //     0xb20a70: ldur            w1, [x2, #0x37]
    // 0xb20a74: DecompressPointer r1
    //     0xb20a74: add             x1, x1, HEAP, lsl #32
    // 0xb20a78: cmp             w1, NULL
    // 0xb20a7c: b.eq            #0xb21090
    // 0xb20a80: r16 = 1.200000
    //     0xb20a80: add             x16, PP, #0xe, lsl #12  ; [pp+0xe380] 1.2
    //     0xb20a84: ldr             x16, [x16, #0x380]
    // 0xb20a88: stp             x16, x1, [SP, #-0x10]!
    // 0xb20a8c: r4 = const [0, 0x2, 0x2, 0x1, letterSpacing, 0x1, null]
    //     0xb20a8c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe388] List(7) [0, 0x2, 0x2, 0x1, "letterSpacing", 0x1, Null]
    //     0xb20a90: ldr             x4, [x4, #0x388]
    // 0xb20a94: r0 = copyWith()
    //     0xb20a94: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xb20a98: add             SP, SP, #0x10
    // 0xb20a9c: mov             x1, x0
    // 0xb20aa0: ldur            x0, [fp, #-8]
    // 0xb20aa4: cmp             w1, NULL
    // 0xb20aa8: b.eq            #0xb21094
    // 0xb20aac: ldur            x16, [fp, #-0x30]
    // 0xb20ab0: stp             x16, x1, [SP, #-0x10]!
    // 0xb20ab4: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xb20ab4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xb20ab8: ldr             x4, [x4, #0x168]
    // 0xb20abc: r0 = copyWith()
    //     0xb20abc: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xb20ac0: add             SP, SP, #0x10
    // 0xb20ac4: mov             x1, x0
    // 0xb20ac8: ldur            x0, [fp, #-8]
    // 0xb20acc: stur            x1, [fp, #-0x60]
    // 0xb20ad0: r17 = 5596
    //     0xb20ad0: mov             x17, #0x15dc
    // 0xb20ad4: cmp             w0, w17
    // 0xb20ad8: b.ne            #0xb20af0
    // 0xb20adc: ldur            x2, [fp, #-0x20]
    // 0xb20ae0: LoadField: r3 = r2->field_2f
    //     0xb20ae0: ldur            w3, [x2, #0x2f]
    // 0xb20ae4: DecompressPointer r3
    //     0xb20ae4: add             x3, x3, HEAP, lsl #32
    // 0xb20ae8: mov             x5, x3
    // 0xb20aec: b               #0xb20b84
    // 0xb20af0: ldur            x2, [fp, #-0x20]
    // 0xb20af4: r17 = 5598
    //     0xb20af4: mov             x17, #0x15de
    // 0xb20af8: cmp             w0, w17
    // 0xb20afc: b.ne            #0xb20b54
    // 0xb20b00: LoadField: r3 = r2->field_5f
    //     0xb20b00: ldur            w3, [x2, #0x5f]
    // 0xb20b04: DecompressPointer r3
    //     0xb20b04: add             x3, x3, HEAP, lsl #32
    // 0xb20b08: LoadField: r4 = r3->field_7
    //     0xb20b08: ldur            x4, [x3, #7]
    // 0xb20b0c: cmp             x4, #1
    // 0xb20b10: b.gt            #0xb20b34
    // 0xb20b14: cmp             x4, #0
    // 0xb20b18: b.gt            #0xb20b28
    // 0xb20b1c: r5 = Instance_RoundedRectangleBorder
    //     0xb20b1c: add             x5, PP, #0xe, lsl #12  ; [pp+0xe330] Obj!RoundedRectangleBorder@b38431
    //     0xb20b20: ldr             x5, [x5, #0x330]
    // 0xb20b24: b               #0xb20b84
    // 0xb20b28: r5 = Instance_RoundedRectangleBorder
    //     0xb20b28: add             x5, PP, #0xe, lsl #12  ; [pp+0xe338] Obj!RoundedRectangleBorder@b38421
    //     0xb20b2c: ldr             x5, [x5, #0x338]
    // 0xb20b30: b               #0xb20b84
    // 0xb20b34: cmp             x4, #2
    // 0xb20b38: b.gt            #0xb20b48
    // 0xb20b3c: r5 = Instance_RoundedRectangleBorder
    //     0xb20b3c: add             x5, PP, #0xe, lsl #12  ; [pp+0xe340] Obj!RoundedRectangleBorder@b38411
    //     0xb20b40: ldr             x5, [x5, #0x340]
    // 0xb20b44: b               #0xb20b84
    // 0xb20b48: r5 = Instance_RoundedRectangleBorder
    //     0xb20b48: add             x5, PP, #0xe, lsl #12  ; [pp+0xe330] Obj!RoundedRectangleBorder@b38431
    //     0xb20b4c: ldr             x5, [x5, #0x330]
    // 0xb20b50: b               #0xb20b84
    // 0xb20b54: LoadField: r3 = r2->field_5b
    //     0xb20b54: ldur            w3, [x2, #0x5b]
    // 0xb20b58: DecompressPointer r3
    //     0xb20b58: add             x3, x3, HEAP, lsl #32
    // 0xb20b5c: r16 = Instance__FloatingActionButtonType
    //     0xb20b5c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xb20b60: ldr             x16, [x16, #0x348]
    // 0xb20b64: cmp             w3, w16
    // 0xb20b68: b.ne            #0xb20b78
    // 0xb20b6c: r3 = Instance_StadiumBorder
    //     0xb20b6c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe350] Obj!StadiumBorder@b383b1
    //     0xb20b70: ldr             x3, [x3, #0x350]
    // 0xb20b74: b               #0xb20b80
    // 0xb20b78: r3 = Instance_CircleBorder
    //     0xb20b78: add             x3, PP, #0xe, lsl #12  ; [pp+0xe358] Obj!CircleBorder@b38441
    //     0xb20b7c: ldr             x3, [x3, #0x358]
    // 0xb20b80: mov             x5, x3
    // 0xb20b84: ldr             x3, [fp, #0x18]
    // 0xb20b88: ldur            d0, [fp, #-0x68]
    // 0xb20b8c: ldur            x4, [fp, #-0x28]
    // 0xb20b90: stur            x5, [fp, #-0x30]
    // 0xb20b94: cmp             w5, NULL
    // 0xb20b98: b.eq            #0xb21098
    // 0xb20b9c: r6 = inline_Allocate_Double()
    //     0xb20b9c: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xb20ba0: add             x6, x6, #0x10
    //     0xb20ba4: cmp             x7, x6
    //     0xb20ba8: b.ls            #0xb2109c
    //     0xb20bac: str             x6, [THR, #0x60]  ; THR::top
    //     0xb20bb0: sub             x6, x6, #0xf
    //     0xb20bb4: mov             x7, #0xd108
    //     0xb20bb8: movk            x7, #3, lsl #16
    //     0xb20bbc: stur            x7, [x6, #-1]
    // 0xb20bc0: StoreField: r6->field_7 = d0
    //     0xb20bc0: stur            d0, [x6, #7]
    // 0xb20bc4: stur            x6, [fp, #-0x18]
    // 0xb20bc8: r0 = IconThemeData()
    //     0xb20bc8: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xb20bcc: mov             x1, x0
    // 0xb20bd0: ldur            x0, [fp, #-0x18]
    // 0xb20bd4: StoreField: r1->field_7 = r0
    //     0xb20bd4: stur            w0, [x1, #7]
    // 0xb20bd8: ldr             x0, [fp, #0x18]
    // 0xb20bdc: LoadField: r2 = r0->field_b
    //     0xb20bdc: ldur            w2, [x0, #0xb]
    // 0xb20be0: DecompressPointer r2
    //     0xb20be0: add             x2, x2, HEAP, lsl #32
    // 0xb20be4: stur            x2, [fp, #-0x18]
    // 0xb20be8: stp             x1, x2, [SP, #-0x10]!
    // 0xb20bec: r0 = merge()
    //     0xb20bec: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xb20bf0: add             SP, SP, #0x10
    // 0xb20bf4: mov             x1, x0
    // 0xb20bf8: ldur            x0, [fp, #-0x28]
    // 0xb20bfc: LoadField: r2 = r0->field_7
    //     0xb20bfc: ldur            x2, [x0, #7]
    // 0xb20c00: cmp             x2, #1
    // 0xb20c04: b.gt            #0xb20c88
    // 0xb20c08: cmp             x2, #0
    // 0xb20c0c: b.gt            #0xb20c4c
    // 0xb20c10: ldur            x0, [fp, #-0x10]
    // 0xb20c14: LoadField: r2 = r0->field_3b
    //     0xb20c14: ldur            w2, [x0, #0x3b]
    // 0xb20c18: DecompressPointer r2
    //     0xb20c18: add             x2, x2, HEAP, lsl #32
    // 0xb20c1c: cmp             w2, NULL
    // 0xb20c20: b.ne            #0xb20c3c
    // 0xb20c24: ldur            x3, [fp, #-0x20]
    // 0xb20c28: LoadField: r0 = r3->field_3b
    //     0xb20c28: ldur            w0, [x3, #0x3b]
    // 0xb20c2c: DecompressPointer r0
    //     0xb20c2c: add             x0, x0, HEAP, lsl #32
    // 0xb20c30: cmp             w0, NULL
    // 0xb20c34: b.eq            #0xb210c8
    // 0xb20c38: b               #0xb20c40
    // 0xb20c3c: mov             x0, x2
    // 0xb20c40: mov             x9, x0
    // 0xb20c44: mov             x8, x1
    // 0xb20c48: b               #0xb20ed8
    // 0xb20c4c: ldur            x0, [fp, #-0x10]
    // 0xb20c50: ldur            x3, [fp, #-0x20]
    // 0xb20c54: LoadField: r2 = r0->field_3f
    //     0xb20c54: ldur            w2, [x0, #0x3f]
    // 0xb20c58: DecompressPointer r2
    //     0xb20c58: add             x2, x2, HEAP, lsl #32
    // 0xb20c5c: cmp             w2, NULL
    // 0xb20c60: b.ne            #0xb20c78
    // 0xb20c64: LoadField: r0 = r3->field_3f
    //     0xb20c64: ldur            w0, [x3, #0x3f]
    // 0xb20c68: DecompressPointer r0
    //     0xb20c68: add             x0, x0, HEAP, lsl #32
    // 0xb20c6c: cmp             w0, NULL
    // 0xb20c70: b.eq            #0xb210cc
    // 0xb20c74: b               #0xb20c7c
    // 0xb20c78: mov             x0, x2
    // 0xb20c7c: mov             x9, x0
    // 0xb20c80: mov             x8, x1
    // 0xb20c84: b               #0xb20ed8
    // 0xb20c88: ldur            x0, [fp, #-0x10]
    // 0xb20c8c: ldur            x3, [fp, #-0x20]
    // 0xb20c90: cmp             x2, #2
    // 0xb20c94: b.gt            #0xb20ccc
    // 0xb20c98: LoadField: r2 = r0->field_43
    //     0xb20c98: ldur            w2, [x0, #0x43]
    // 0xb20c9c: DecompressPointer r2
    //     0xb20c9c: add             x2, x2, HEAP, lsl #32
    // 0xb20ca0: cmp             w2, NULL
    // 0xb20ca4: b.ne            #0xb20cbc
    // 0xb20ca8: LoadField: r0 = r3->field_43
    //     0xb20ca8: ldur            w0, [x3, #0x43]
    // 0xb20cac: DecompressPointer r0
    //     0xb20cac: add             x0, x0, HEAP, lsl #32
    // 0xb20cb0: cmp             w0, NULL
    // 0xb20cb4: b.eq            #0xb210d0
    // 0xb20cb8: b               #0xb20cc0
    // 0xb20cbc: mov             x0, x2
    // 0xb20cc0: mov             x9, x0
    // 0xb20cc4: mov             x8, x1
    // 0xb20cc8: b               #0xb20ed8
    // 0xb20ccc: LoadField: r1 = r0->field_47
    //     0xb20ccc: ldur            w1, [x0, #0x47]
    // 0xb20cd0: DecompressPointer r1
    //     0xb20cd0: add             x1, x1, HEAP, lsl #32
    // 0xb20cd4: cmp             w1, NULL
    // 0xb20cd8: b.ne            #0xb20cf0
    // 0xb20cdc: LoadField: r0 = r3->field_47
    //     0xb20cdc: ldur            w0, [x3, #0x47]
    // 0xb20ce0: DecompressPointer r0
    //     0xb20ce0: add             x0, x0, HEAP, lsl #32
    // 0xb20ce4: cmp             w0, NULL
    // 0xb20ce8: b.eq            #0xb210d4
    // 0xb20cec: mov             x1, x0
    // 0xb20cf0: ldur            x0, [fp, #-8]
    // 0xb20cf4: stur            x1, [fp, #-0x10]
    // 0xb20cf8: r17 = 5596
    //     0xb20cf8: mov             x17, #0x15dc
    // 0xb20cfc: cmp             w0, w17
    // 0xb20d00: b.ne            #0xb20d10
    // 0xb20d04: LoadField: r0 = r3->field_4f
    //     0xb20d04: ldur            w0, [x3, #0x4f]
    // 0xb20d08: DecompressPointer r0
    //     0xb20d08: add             x0, x0, HEAP, lsl #32
    // 0xb20d0c: b               #0xb20dd0
    // 0xb20d10: r17 = 5598
    //     0xb20d10: mov             x17, #0x15de
    // 0xb20d14: cmp             w0, w17
    // 0xb20d18: b.ne            #0xb20d74
    // 0xb20d1c: LoadField: r0 = r3->field_63
    //     0xb20d1c: ldur            w0, [x3, #0x63]
    // 0xb20d20: DecompressPointer r0
    //     0xb20d20: add             x0, x0, HEAP, lsl #32
    // 0xb20d24: tbnz            w0, #4, #0xb20d48
    // 0xb20d28: LoadField: r0 = r3->field_5f
    //     0xb20d28: ldur            w0, [x3, #0x5f]
    // 0xb20d2c: DecompressPointer r0
    //     0xb20d2c: add             x0, x0, HEAP, lsl #32
    // 0xb20d30: r16 = Instance__FloatingActionButtonType
    //     0xb20d30: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xb20d34: ldr             x16, [x16, #0x348]
    // 0xb20d38: cmp             w0, w16
    // 0xb20d3c: b.ne            #0xb20d48
    // 0xb20d40: d0 = 16.000000
    //     0xb20d40: fmov            d0, #16.00000000
    // 0xb20d44: b               #0xb20d4c
    // 0xb20d48: d0 = 20.000000
    //     0xb20d48: fmov            d0, #20.00000000
    // 0xb20d4c: stur            d0, [fp, #-0x68]
    // 0xb20d50: r0 = EdgeInsetsDirectional()
    //     0xb20d50: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xb20d54: ldur            d0, [fp, #-0x68]
    // 0xb20d58: StoreField: r0->field_7 = d0
    //     0xb20d58: stur            d0, [x0, #7]
    // 0xb20d5c: d0 = 0.000000
    //     0xb20d5c: eor             v0.16b, v0.16b, v0.16b
    // 0xb20d60: StoreField: r0->field_f = d0
    //     0xb20d60: stur            d0, [x0, #0xf]
    // 0xb20d64: d1 = 20.000000
    //     0xb20d64: fmov            d1, #20.00000000
    // 0xb20d68: StoreField: r0->field_17 = d1
    //     0xb20d68: stur            d1, [x0, #0x17]
    // 0xb20d6c: StoreField: r0->field_1f = d0
    //     0xb20d6c: stur            d0, [x0, #0x1f]
    // 0xb20d70: b               #0xb20dd0
    // 0xb20d74: d1 = 20.000000
    //     0xb20d74: fmov            d1, #20.00000000
    // 0xb20d78: d0 = 0.000000
    //     0xb20d78: eor             v0.16b, v0.16b, v0.16b
    // 0xb20d7c: LoadField: r0 = r3->field_5f
    //     0xb20d7c: ldur            w0, [x3, #0x5f]
    // 0xb20d80: DecompressPointer r0
    //     0xb20d80: add             x0, x0, HEAP, lsl #32
    // 0xb20d84: tbnz            w0, #4, #0xb20da8
    // 0xb20d88: LoadField: r0 = r3->field_5b
    //     0xb20d88: ldur            w0, [x3, #0x5b]
    // 0xb20d8c: DecompressPointer r0
    //     0xb20d8c: add             x0, x0, HEAP, lsl #32
    // 0xb20d90: r16 = Instance__FloatingActionButtonType
    //     0xb20d90: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xb20d94: ldr             x16, [x16, #0x348]
    // 0xb20d98: cmp             w0, w16
    // 0xb20d9c: b.ne            #0xb20da8
    // 0xb20da0: d2 = 16.000000
    //     0xb20da0: fmov            d2, #16.00000000
    // 0xb20da4: b               #0xb20dac
    // 0xb20da8: d2 = 20.000000
    //     0xb20da8: fmov            d2, #20.00000000
    // 0xb20dac: stur            d2, [fp, #-0x68]
    // 0xb20db0: r0 = EdgeInsetsDirectional()
    //     0xb20db0: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xb20db4: ldur            d0, [fp, #-0x68]
    // 0xb20db8: StoreField: r0->field_7 = d0
    //     0xb20db8: stur            d0, [x0, #7]
    // 0xb20dbc: d0 = 0.000000
    //     0xb20dbc: eor             v0.16b, v0.16b, v0.16b
    // 0xb20dc0: StoreField: r0->field_f = d0
    //     0xb20dc0: stur            d0, [x0, #0xf]
    // 0xb20dc4: d1 = 20.000000
    //     0xb20dc4: fmov            d1, #20.00000000
    // 0xb20dc8: StoreField: r0->field_17 = d1
    //     0xb20dc8: stur            d1, [x0, #0x17]
    // 0xb20dcc: StoreField: r0->field_1f = d0
    //     0xb20dcc: stur            d0, [x0, #0x1f]
    // 0xb20dd0: stur            x0, [fp, #-8]
    // 0xb20dd4: r16 = <Widget>
    //     0xb20dd4: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb20dd8: ldr             x16, [x16, #0xea8]
    // 0xb20ddc: stp             xzr, x16, [SP, #-0x10]!
    // 0xb20de0: r0 = _GrowableList()
    //     0xb20de0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xb20de4: add             SP, SP, #0x10
    // 0xb20de8: stur            x0, [fp, #-0x28]
    // 0xb20dec: LoadField: r1 = r0->field_b
    //     0xb20dec: ldur            w1, [x0, #0xb]
    // 0xb20df0: DecompressPointer r1
    //     0xb20df0: add             x1, x1, HEAP, lsl #32
    // 0xb20df4: stur            x1, [fp, #-0x20]
    // 0xb20df8: LoadField: r2 = r0->field_f
    //     0xb20df8: ldur            w2, [x0, #0xf]
    // 0xb20dfc: DecompressPointer r2
    //     0xb20dfc: add             x2, x2, HEAP, lsl #32
    // 0xb20e00: LoadField: r3 = r2->field_b
    //     0xb20e00: ldur            w3, [x2, #0xb]
    // 0xb20e04: DecompressPointer r3
    //     0xb20e04: add             x3, x3, HEAP, lsl #32
    // 0xb20e08: cmp             w1, w3
    // 0xb20e0c: b.ne            #0xb20e1c
    // 0xb20e10: SaveReg r0
    //     0xb20e10: str             x0, [SP, #-8]!
    // 0xb20e14: r0 = _growToNextCapacity()
    //     0xb20e14: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb20e18: add             SP, SP, #8
    // 0xb20e1c: ldur            x2, [fp, #-0x28]
    // 0xb20e20: ldur            x3, [fp, #-8]
    // 0xb20e24: ldur            x0, [fp, #-0x20]
    // 0xb20e28: r4 = LoadInt32Instr(r0)
    //     0xb20e28: sbfx            x4, x0, #1, #0x1f
    // 0xb20e2c: add             x0, x4, #1
    // 0xb20e30: lsl             x1, x0, #1
    // 0xb20e34: StoreField: r2->field_b = r1
    //     0xb20e34: stur            w1, [x2, #0xb]
    // 0xb20e38: mov             x1, x4
    // 0xb20e3c: cmp             x1, x0
    // 0xb20e40: b.hs            #0xb210d8
    // 0xb20e44: LoadField: r1 = r2->field_f
    //     0xb20e44: ldur            w1, [x2, #0xf]
    // 0xb20e48: DecompressPointer r1
    //     0xb20e48: add             x1, x1, HEAP, lsl #32
    // 0xb20e4c: ldur            x0, [fp, #-0x18]
    // 0xb20e50: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb20e50: add             x25, x1, x4, lsl #2
    //     0xb20e54: add             x25, x25, #0xf
    //     0xb20e58: str             w0, [x25]
    //     0xb20e5c: tbz             w0, #0, #0xb20e78
    //     0xb20e60: ldurb           w16, [x1, #-1]
    //     0xb20e64: ldurb           w17, [x0, #-1]
    //     0xb20e68: and             x16, x17, x16, lsr #2
    //     0xb20e6c: tst             x16, HEAP, lsr #32
    //     0xb20e70: b.eq            #0xb20e78
    //     0xb20e74: bl              #0xd67e5c
    // 0xb20e78: r0 = Row()
    //     0xb20e78: bl              #0x8236c8  ; AllocateRowStub -> Row (size=0x30)
    // 0xb20e7c: stur            x0, [fp, #-0x18]
    // 0xb20e80: ldur            x16, [fp, #-0x28]
    // 0xb20e84: stp             x16, x0, [SP, #-0x10]!
    // 0xb20e88: r16 = Instance_MainAxisSize
    //     0xb20e88: add             x16, PP, #0xe, lsl #12  ; [pp+0xeeb0] Obj!MainAxisSize@b64b71
    //     0xb20e8c: ldr             x16, [x16, #0xeb0]
    // 0xb20e90: SaveReg r16
    //     0xb20e90: str             x16, [SP, #-8]!
    // 0xb20e94: r4 = const [0, 0x3, 0x3, 0x2, mainAxisSize, 0x2, null]
    //     0xb20e94: add             x4, PP, #0xe, lsl #12  ; [pp+0xeeb8] List(7) [0, 0x3, 0x3, 0x2, "mainAxisSize", 0x2, Null]
    //     0xb20e98: ldr             x4, [x4, #0xeb8]
    // 0xb20e9c: r0 = Row()
    //     0xb20e9c: bl              #0x8232c8  ; [package:flutter/src/widgets/basic.dart] Row::Row
    // 0xb20ea0: add             SP, SP, #0x18
    // 0xb20ea4: r0 = Padding()
    //     0xb20ea4: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb20ea8: mov             x1, x0
    // 0xb20eac: ldur            x0, [fp, #-8]
    // 0xb20eb0: stur            x1, [fp, #-0x20]
    // 0xb20eb4: StoreField: r1->field_f = r0
    //     0xb20eb4: stur            w0, [x1, #0xf]
    // 0xb20eb8: ldur            x0, [fp, #-0x18]
    // 0xb20ebc: StoreField: r1->field_b = r0
    //     0xb20ebc: stur            w0, [x1, #0xb]
    // 0xb20ec0: r0 = _ChildOverflowBox()
    //     0xb20ec0: bl              #0xb210f4  ; Allocate_ChildOverflowBoxStub -> _ChildOverflowBox (size=0x10)
    // 0xb20ec4: mov             x1, x0
    // 0xb20ec8: ldur            x0, [fp, #-0x20]
    // 0xb20ecc: StoreField: r1->field_b = r0
    //     0xb20ecc: stur            w0, [x1, #0xb]
    // 0xb20ed0: ldur            x9, [fp, #-0x10]
    // 0xb20ed4: mov             x8, x1
    // 0xb20ed8: ldr             x0, [fp, #0x18]
    // 0xb20edc: ldur            x7, [fp, #-0x38]
    // 0xb20ee0: ldur            x5, [fp, #-0x48]
    // 0xb20ee4: ldur            d0, [fp, #-0x90]
    // 0xb20ee8: ldur            d1, [fp, #-0x88]
    // 0xb20eec: ldur            d2, [fp, #-0x80]
    // 0xb20ef0: ldur            d3, [fp, #-0x78]
    // 0xb20ef4: ldur            d4, [fp, #-0x70]
    // 0xb20ef8: ldur            x1, [fp, #-0x60]
    // 0xb20efc: ldur            x4, [fp, #-0x50]
    // 0xb20f00: ldur            x2, [fp, #-0x30]
    // 0xb20f04: ldur            x3, [fp, #-0x58]
    // 0xb20f08: ldur            x6, [fp, #-0x40]
    // 0xb20f0c: stur            x9, [fp, #-0x10]
    // 0xb20f10: stur            x8, [fp, #-0x18]
    // 0xb20f14: LoadField: r10 = r0->field_2b
    //     0xb20f14: ldur            w10, [x0, #0x2b]
    // 0xb20f18: DecompressPointer r10
    //     0xb20f18: add             x10, x10, HEAP, lsl #32
    // 0xb20f1c: stur            x10, [fp, #-8]
    // 0xb20f20: r0 = RawMaterialButton()
    //     0xb20f20: bl              #0xb210e8  ; AllocateRawMaterialButtonStub -> RawMaterialButton (size=0x88)
    // 0xb20f24: mov             x1, x0
    // 0xb20f28: ldur            x0, [fp, #-8]
    // 0xb20f2c: stur            x1, [fp, #-0x20]
    // 0xb20f30: StoreField: r1->field_b = r0
    //     0xb20f30: stur            w0, [x1, #0xb]
    // 0xb20f34: r0 = _EffectiveMouseCursor()
    //     0xb20f34: bl              #0xb210dc  ; Allocate_EffectiveMouseCursorStub -> _EffectiveMouseCursor (size=0x10)
    // 0xb20f38: mov             x1, x0
    // 0xb20f3c: ldur            x0, [fp, #-0x20]
    // 0xb20f40: StoreField: r0->field_17 = r1
    //     0xb20f40: stur            w1, [x0, #0x17]
    // 0xb20f44: ldur            x1, [fp, #-0x60]
    // 0xb20f48: StoreField: r0->field_1b = r1
    //     0xb20f48: stur            w1, [x0, #0x1b]
    // 0xb20f4c: ldur            x1, [fp, #-0x38]
    // 0xb20f50: StoreField: r0->field_1f = r1
    //     0xb20f50: stur            w1, [x0, #0x1f]
    // 0xb20f54: ldur            x1, [fp, #-0x40]
    // 0xb20f58: StoreField: r0->field_23 = r1
    //     0xb20f58: stur            w1, [x0, #0x23]
    // 0xb20f5c: ldur            x1, [fp, #-0x48]
    // 0xb20f60: StoreField: r0->field_27 = r1
    //     0xb20f60: stur            w1, [x0, #0x27]
    // 0xb20f64: ldur            x1, [fp, #-0x58]
    // 0xb20f68: StoreField: r0->field_2f = r1
    //     0xb20f68: stur            w1, [x0, #0x2f]
    // 0xb20f6c: ldur            d0, [fp, #-0x90]
    // 0xb20f70: StoreField: r0->field_33 = d0
    //     0xb20f70: stur            d0, [x0, #0x33]
    // 0xb20f74: ldur            d0, [fp, #-0x88]
    // 0xb20f78: StoreField: r0->field_43 = d0
    //     0xb20f78: stur            d0, [x0, #0x43]
    // 0xb20f7c: ldur            d0, [fp, #-0x80]
    // 0xb20f80: StoreField: r0->field_3b = d0
    //     0xb20f80: stur            d0, [x0, #0x3b]
    // 0xb20f84: ldur            d0, [fp, #-0x70]
    // 0xb20f88: StoreField: r0->field_4b = d0
    //     0xb20f88: stur            d0, [x0, #0x4b]
    // 0xb20f8c: ldur            d0, [fp, #-0x78]
    // 0xb20f90: StoreField: r0->field_53 = d0
    //     0xb20f90: stur            d0, [x0, #0x53]
    // 0xb20f94: r1 = Instance_EdgeInsets
    //     0xb20f94: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xb20f98: ldr             x1, [x1, #0xbd8]
    // 0xb20f9c: StoreField: r0->field_5b = r1
    //     0xb20f9c: stur            w1, [x0, #0x5b]
    // 0xb20fa0: r1 = Instance_VisualDensity
    //     0xb20fa0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd260] Obj!VisualDensity@b3c131
    //     0xb20fa4: ldr             x1, [x1, #0x260]
    // 0xb20fa8: StoreField: r0->field_5f = r1
    //     0xb20fa8: stur            w1, [x0, #0x5f]
    // 0xb20fac: ldur            x1, [fp, #-0x10]
    // 0xb20fb0: StoreField: r0->field_63 = r1
    //     0xb20fb0: stur            w1, [x0, #0x63]
    // 0xb20fb4: ldur            x1, [fp, #-0x30]
    // 0xb20fb8: StoreField: r0->field_67 = r1
    //     0xb20fb8: stur            w1, [x0, #0x67]
    // 0xb20fbc: r1 = Instance_Duration
    //     0xb20fbc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb20fc0: ldr             x1, [x1, #0x9e0]
    // 0xb20fc4: StoreField: r0->field_6b = r1
    //     0xb20fc4: stur            w1, [x0, #0x6b]
    // 0xb20fc8: r1 = Instance_Clip
    //     0xb20fc8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb20fcc: ldr             x1, [x1, #0xb38]
    // 0xb20fd0: StoreField: r0->field_7f = r1
    //     0xb20fd0: stur            w1, [x0, #0x7f]
    // 0xb20fd4: r1 = false
    //     0xb20fd4: add             x1, NULL, #0x30  ; false
    // 0xb20fd8: StoreField: r0->field_7b = r1
    //     0xb20fd8: stur            w1, [x0, #0x7b]
    // 0xb20fdc: ldur            x2, [fp, #-0x18]
    // 0xb20fe0: StoreField: r0->field_6f = r2
    //     0xb20fe0: stur            w2, [x0, #0x6f]
    // 0xb20fe4: r2 = true
    //     0xb20fe4: add             x2, NULL, #0x20  ; true
    // 0xb20fe8: StoreField: r0->field_83 = r2
    //     0xb20fe8: stur            w2, [x0, #0x83]
    // 0xb20fec: ldur            x2, [fp, #-0x50]
    // 0xb20ff0: StoreField: r0->field_73 = r2
    //     0xb20ff0: stur            w2, [x0, #0x73]
    // 0xb20ff4: r0 = Hero()
    //     0xb20ff4: bl              #0x8920dc  ; AllocateHeroStub -> Hero (size=0x24)
    // 0xb20ff8: mov             x1, x0
    // 0xb20ffc: r0 = Instance__DefaultHeroTag
    //     0xb20ffc: add             x0, PP, #0x27, lsl #12  ; [pp+0x270f0] Obj!_DefaultHeroTag@b385a1
    //     0xb21000: ldr             x0, [x0, #0xf0]
    // 0xb21004: stur            x1, [fp, #-8]
    // 0xb21008: StoreField: r1->field_b = r0
    //     0xb21008: stur            w0, [x1, #0xb]
    // 0xb2100c: r0 = false
    //     0xb2100c: add             x0, NULL, #0x30  ; false
    // 0xb21010: StoreField: r1->field_1f = r0
    //     0xb21010: stur            w0, [x1, #0x1f]
    // 0xb21014: ldur            x0, [fp, #-0x20]
    // 0xb21018: StoreField: r1->field_13 = r0
    //     0xb21018: stur            w0, [x1, #0x13]
    // 0xb2101c: r0 = MergeSemantics()
    //     0xb2101c: bl              #0x9a32ec  ; AllocateMergeSemanticsStub -> MergeSemantics (size=0x10)
    // 0xb21020: ldur            x1, [fp, #-8]
    // 0xb21024: StoreField: r0->field_b = r1
    //     0xb21024: stur            w1, [x0, #0xb]
    // 0xb21028: LeaveFrame
    //     0xb21028: mov             SP, fp
    //     0xb2102c: ldp             fp, lr, [SP], #0x10
    // 0xb21030: ret
    //     0xb21030: ret             
    // 0xb21034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21034: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21038: b               #0xb20394
    // 0xb2103c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2103c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb21040: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb21040: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xb21044: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb21044: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xb21048: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb21048: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xb2104c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb2104c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xb21050: stp             q4, q5, [SP, #-0x20]!
    // 0xb21054: stp             q2, q3, [SP, #-0x20]!
    // 0xb21058: stp             q0, q1, [SP, #-0x20]!
    // 0xb2105c: stp             x4, x5, [SP, #-0x10]!
    // 0xb21060: stp             x2, x3, [SP, #-0x10]!
    // 0xb21064: SaveReg r0
    //     0xb21064: str             x0, [SP, #-8]!
    // 0xb21068: r0 = AllocateDouble()
    //     0xb21068: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb2106c: mov             x1, x0
    // 0xb21070: RestoreReg r0
    //     0xb21070: ldr             x0, [SP], #8
    // 0xb21074: ldp             x2, x3, [SP], #0x10
    // 0xb21078: ldp             x4, x5, [SP], #0x10
    // 0xb2107c: ldp             q0, q1, [SP], #0x20
    // 0xb21080: ldp             q2, q3, [SP], #0x20
    // 0xb21084: ldp             q4, q5, [SP], #0x20
    // 0xb21088: b               #0xb209e4
    // 0xb2108c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb2108c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xb21090: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb21090: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb21094: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb21094: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb21098: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb21098: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xb2109c: SaveReg d0
    //     0xb2109c: str             q0, [SP, #-0x10]!
    // 0xb210a0: stp             x4, x5, [SP, #-0x10]!
    // 0xb210a4: stp             x2, x3, [SP, #-0x10]!
    // 0xb210a8: stp             x0, x1, [SP, #-0x10]!
    // 0xb210ac: r0 = AllocateDouble()
    //     0xb210ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb210b0: mov             x6, x0
    // 0xb210b4: ldp             x0, x1, [SP], #0x10
    // 0xb210b8: ldp             x2, x3, [SP], #0x10
    // 0xb210bc: ldp             x4, x5, [SP], #0x10
    // 0xb210c0: RestoreReg d0
    //     0xb210c0: ldr             q0, [SP], #0x10
    // 0xb210c4: b               #0xb20bc0
    // 0xb210c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb210c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb210cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb210cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb210d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb210d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb210d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb210d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb210d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb210d8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 5965, size: 0x14, field offset: 0x14
enum _FloatingActionButtonType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16138, size: 0x5c
    // 0xb16138: EnterFrame
    //     0xb16138: stp             fp, lr, [SP, #-0x10]!
    //     0xb1613c: mov             fp, SP
    // 0xb16140: CheckStackOverflow
    //     0xb16140: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16144: cmp             SP, x16
    //     0xb16148: b.ls            #0xb1618c
    // 0xb1614c: r1 = Null
    //     0xb1614c: mov             x1, NULL
    // 0xb16150: r2 = 4
    //     0xb16150: mov             x2, #4
    // 0xb16154: r0 = AllocateArray()
    //     0xb16154: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16158: r17 = "_FloatingActionButtonType."
    //     0xb16158: add             x17, PP, #0xe, lsl #12  ; [pp+0xe920] "_FloatingActionButtonType."
    //     0xb1615c: ldr             x17, [x17, #0x920]
    // 0xb16160: StoreField: r0->field_f = r17
    //     0xb16160: stur            w17, [x0, #0xf]
    // 0xb16164: ldr             x1, [fp, #0x10]
    // 0xb16168: LoadField: r2 = r1->field_f
    //     0xb16168: ldur            w2, [x1, #0xf]
    // 0xb1616c: DecompressPointer r2
    //     0xb1616c: add             x2, x2, HEAP, lsl #32
    // 0xb16170: StoreField: r0->field_13 = r2
    //     0xb16170: stur            w2, [x0, #0x13]
    // 0xb16174: SaveReg r0
    //     0xb16174: str             x0, [SP, #-8]!
    // 0xb16178: r0 = _interpolate()
    //     0xb16178: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb1617c: add             SP, SP, #8
    // 0xb16180: LeaveFrame
    //     0xb16180: mov             SP, fp
    //     0xb16184: ldp             fp, lr, [SP], #0x10
    // 0xb16188: ret
    //     0xb16188: ret             
    // 0xb1618c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1618c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16190: b               #0xb1614c
  }
}

// lib: , url: package:flutter/src/material/snack_bar_theme.dart

// class id: 1049312, size: 0x8
class :: {
}

// class id: 2726, size: 0x34, field offset: 0x8
//   const constructor, 
class SnackBarThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb01a74, size: 0x7c
    // 0xb01a74: EnterFrame
    //     0xb01a74: stp             fp, lr, [SP, #-0x10]!
    //     0xb01a78: mov             fp, SP
    // 0xb01a7c: CheckStackOverflow
    //     0xb01a7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb01a80: cmp             SP, x16
    //     0xb01a84: b.ls            #0xb01ae8
    // 0xb01a88: ldr             x0, [fp, #0x10]
    // 0xb01a8c: LoadField: r1 = r0->field_17
    //     0xb01a8c: ldur            w1, [x0, #0x17]
    // 0xb01a90: DecompressPointer r1
    //     0xb01a90: add             x1, x1, HEAP, lsl #32
    // 0xb01a94: LoadField: r2 = r0->field_23
    //     0xb01a94: ldur            w2, [x0, #0x23]
    // 0xb01a98: DecompressPointer r2
    //     0xb01a98: add             x2, x2, HEAP, lsl #32
    // 0xb01a9c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb01aa0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb01aa4: stp             NULL, x1, [SP, #-0x10]!
    // 0xb01aa8: stp             x2, NULL, [SP, #-0x10]!
    // 0xb01aac: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb01ab0: SaveReg rNULL
    //     0xb01ab0: str             NULL, [SP, #-8]!
    // 0xb01ab4: r4 = const [0, 0xb, 0xb, 0xb, null]
    //     0xb01ab4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe128] List(5) [0, 0xb, 0xb, 0xb, Null]
    //     0xb01ab8: ldr             x4, [x4, #0x128]
    // 0xb01abc: r0 = hash()
    //     0xb01abc: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb01ac0: add             SP, SP, #0x58
    // 0xb01ac4: mov             x2, x0
    // 0xb01ac8: r0 = BoxInt64Instr(r2)
    //     0xb01ac8: sbfiz           x0, x2, #1, #0x1f
    //     0xb01acc: cmp             x2, x0, asr #1
    //     0xb01ad0: b.eq            #0xb01adc
    //     0xb01ad4: bl              #0xd69bb8
    //     0xb01ad8: stur            x2, [x0, #7]
    // 0xb01adc: LeaveFrame
    //     0xb01adc: mov             SP, fp
    //     0xb01ae0: ldp             fp, lr, [SP], #0x10
    // 0xb01ae4: ret
    //     0xb01ae4: ret             
    // 0xb01ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb01ae8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb01aec: b               #0xb01a88
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf2a00, size: 0x158
    // 0xbf2a00: EnterFrame
    //     0xbf2a00: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2a04: mov             fp, SP
    // 0xbf2a08: AllocStack(0x18)
    //     0xbf2a08: sub             SP, SP, #0x18
    // 0xbf2a0c: CheckStackOverflow
    //     0xbf2a0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf2a10: cmp             SP, x16
    //     0xbf2a14: b.ls            #0xbf2b40
    // 0xbf2a18: ldr             d0, [fp, #0x10]
    // 0xbf2a1c: r0 = inline_Allocate_Double()
    //     0xbf2a1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf2a20: add             x0, x0, #0x10
    //     0xbf2a24: cmp             x1, x0
    //     0xbf2a28: b.ls            #0xbf2b48
    //     0xbf2a2c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf2a30: sub             x0, x0, #0xf
    //     0xbf2a34: mov             x1, #0xd108
    //     0xbf2a38: movk            x1, #3, lsl #16
    //     0xbf2a3c: stur            x1, [x0, #-1]
    // 0xbf2a40: StoreField: r0->field_7 = d0
    //     0xbf2a40: stur            d0, [x0, #7]
    // 0xbf2a44: stur            x0, [fp, #-8]
    // 0xbf2a48: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf2a4c: SaveReg r0
    //     0xbf2a4c: str             x0, [SP, #-8]!
    // 0xbf2a50: r0 = lerp()
    //     0xbf2a50: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2a54: add             SP, SP, #0x18
    // 0xbf2a58: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf2a5c: ldur            x16, [fp, #-8]
    // 0xbf2a60: SaveReg r16
    //     0xbf2a60: str             x16, [SP, #-8]!
    // 0xbf2a64: r0 = lerp()
    //     0xbf2a64: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2a68: add             SP, SP, #0x18
    // 0xbf2a6c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf2a70: ldur            x16, [fp, #-8]
    // 0xbf2a74: SaveReg r16
    //     0xbf2a74: str             x16, [SP, #-8]!
    // 0xbf2a78: r0 = lerp()
    //     0xbf2a78: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2a7c: add             SP, SP, #0x18
    // 0xbf2a80: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf2a84: ldur            x16, [fp, #-8]
    // 0xbf2a88: SaveReg r16
    //     0xbf2a88: str             x16, [SP, #-8]!
    // 0xbf2a8c: r0 = lerp()
    //     0xbf2a8c: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf2a90: add             SP, SP, #0x18
    // 0xbf2a94: ldr             x0, [fp, #0x20]
    // 0xbf2a98: LoadField: r1 = r0->field_17
    //     0xbf2a98: ldur            w1, [x0, #0x17]
    // 0xbf2a9c: DecompressPointer r1
    //     0xbf2a9c: add             x1, x1, HEAP, lsl #32
    // 0xbf2aa0: ldr             x2, [fp, #0x18]
    // 0xbf2aa4: LoadField: r3 = r2->field_17
    //     0xbf2aa4: ldur            w3, [x2, #0x17]
    // 0xbf2aa8: DecompressPointer r3
    //     0xbf2aa8: add             x3, x3, HEAP, lsl #32
    // 0xbf2aac: stp             x3, x1, [SP, #-0x10]!
    // 0xbf2ab0: ldur            x16, [fp, #-8]
    // 0xbf2ab4: SaveReg r16
    //     0xbf2ab4: str             x16, [SP, #-8]!
    // 0xbf2ab8: r0 = lerpDouble()
    //     0xbf2ab8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf2abc: add             SP, SP, #0x18
    // 0xbf2ac0: mov             x1, x0
    // 0xbf2ac4: ldr             x0, [fp, #0x20]
    // 0xbf2ac8: stur            x1, [fp, #-0x10]
    // 0xbf2acc: LoadField: r2 = r0->field_23
    //     0xbf2acc: ldur            w2, [x0, #0x23]
    // 0xbf2ad0: DecompressPointer r2
    //     0xbf2ad0: add             x2, x2, HEAP, lsl #32
    // 0xbf2ad4: ldr             x0, [fp, #0x18]
    // 0xbf2ad8: LoadField: r3 = r0->field_23
    //     0xbf2ad8: ldur            w3, [x0, #0x23]
    // 0xbf2adc: DecompressPointer r3
    //     0xbf2adc: add             x3, x3, HEAP, lsl #32
    // 0xbf2ae0: stp             x3, x2, [SP, #-0x10]!
    // 0xbf2ae4: ldur            x16, [fp, #-8]
    // 0xbf2ae8: SaveReg r16
    //     0xbf2ae8: str             x16, [SP, #-8]!
    // 0xbf2aec: r0 = lerpDouble()
    //     0xbf2aec: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf2af0: add             SP, SP, #0x18
    // 0xbf2af4: stur            x0, [fp, #-0x18]
    // 0xbf2af8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf2afc: ldr             d0, [fp, #0x10]
    // 0xbf2b00: SaveReg d0
    //     0xbf2b00: str             d0, [SP, #-8]!
    // 0xbf2b04: r0 = lerp()
    //     0xbf2b04: bl              #0xbf1e98  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::lerp
    // 0xbf2b08: add             SP, SP, #0x18
    // 0xbf2b0c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf2b10: ldur            x16, [fp, #-8]
    // 0xbf2b14: SaveReg r16
    //     0xbf2b14: str             x16, [SP, #-8]!
    // 0xbf2b18: r0 = lerp()
    //     0xbf2b18: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2b1c: add             SP, SP, #0x18
    // 0xbf2b20: r0 = SnackBarThemeData()
    //     0xbf2b20: bl              #0xbf2b58  ; AllocateSnackBarThemeDataStub -> SnackBarThemeData (size=0x34)
    // 0xbf2b24: ldur            x1, [fp, #-0x10]
    // 0xbf2b28: StoreField: r0->field_17 = r1
    //     0xbf2b28: stur            w1, [x0, #0x17]
    // 0xbf2b2c: ldur            x1, [fp, #-0x18]
    // 0xbf2b30: StoreField: r0->field_23 = r1
    //     0xbf2b30: stur            w1, [x0, #0x23]
    // 0xbf2b34: LeaveFrame
    //     0xbf2b34: mov             SP, fp
    //     0xbf2b38: ldp             fp, lr, [SP], #0x10
    // 0xbf2b3c: ret
    //     0xbf2b3c: ret             
    // 0xbf2b40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2b40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2b44: b               #0xbf2a18
    // 0xbf2b48: SaveReg d0
    //     0xbf2b48: str             q0, [SP, #-0x10]!
    // 0xbf2b4c: r0 = AllocateDouble()
    //     0xbf2b4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf2b50: RestoreReg d0
    //     0xbf2b50: ldr             q0, [SP], #0x10
    // 0xbf2b54: b               #0xbf2a40
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8efac, size: 0x168
    // 0xc8efac: EnterFrame
    //     0xc8efac: stp             fp, lr, [SP, #-0x10]!
    //     0xc8efb0: mov             fp, SP
    // 0xc8efb4: CheckStackOverflow
    //     0xc8efb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8efb8: cmp             SP, x16
    //     0xc8efbc: b.ls            #0xc8f10c
    // 0xc8efc0: ldr             x1, [fp, #0x10]
    // 0xc8efc4: cmp             w1, NULL
    // 0xc8efc8: b.ne            #0xc8efdc
    // 0xc8efcc: r0 = false
    //     0xc8efcc: add             x0, NULL, #0x30  ; false
    // 0xc8efd0: LeaveFrame
    //     0xc8efd0: mov             SP, fp
    //     0xc8efd4: ldp             fp, lr, [SP], #0x10
    // 0xc8efd8: ret
    //     0xc8efd8: ret             
    // 0xc8efdc: ldr             x2, [fp, #0x18]
    // 0xc8efe0: cmp             w2, w1
    // 0xc8efe4: b.ne            #0xc8eff8
    // 0xc8efe8: r0 = true
    //     0xc8efe8: add             x0, NULL, #0x20  ; true
    // 0xc8efec: LeaveFrame
    //     0xc8efec: mov             SP, fp
    //     0xc8eff0: ldp             fp, lr, [SP], #0x10
    // 0xc8eff4: ret
    //     0xc8eff4: ret             
    // 0xc8eff8: r0 = 59
    //     0xc8eff8: mov             x0, #0x3b
    // 0xc8effc: branchIfSmi(r1, 0xc8f008)
    //     0xc8effc: tbz             w1, #0, #0xc8f008
    // 0xc8f000: r0 = LoadClassIdInstr(r1)
    //     0xc8f000: ldur            x0, [x1, #-1]
    //     0xc8f004: ubfx            x0, x0, #0xc, #0x14
    // 0xc8f008: SaveReg r1
    //     0xc8f008: str             x1, [SP, #-8]!
    // 0xc8f00c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8f00c: mov             x17, #0x57c5
    //     0xc8f010: add             lr, x0, x17
    //     0xc8f014: ldr             lr, [x21, lr, lsl #3]
    //     0xc8f018: blr             lr
    // 0xc8f01c: add             SP, SP, #8
    // 0xc8f020: r1 = LoadClassIdInstr(r0)
    //     0xc8f020: ldur            x1, [x0, #-1]
    //     0xc8f024: ubfx            x1, x1, #0xc, #0x14
    // 0xc8f028: r16 = SnackBarThemeData
    //     0xc8f028: add             x16, PP, #0xe, lsl #12  ; [pp+0xe120] Type: SnackBarThemeData
    //     0xc8f02c: ldr             x16, [x16, #0x120]
    // 0xc8f030: stp             x16, x0, [SP, #-0x10]!
    // 0xc8f034: mov             x0, x1
    // 0xc8f038: mov             lr, x0
    // 0xc8f03c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f040: blr             lr
    // 0xc8f044: add             SP, SP, #0x10
    // 0xc8f048: tbz             w0, #4, #0xc8f05c
    // 0xc8f04c: r0 = false
    //     0xc8f04c: add             x0, NULL, #0x30  ; false
    // 0xc8f050: LeaveFrame
    //     0xc8f050: mov             SP, fp
    //     0xc8f054: ldp             fp, lr, [SP], #0x10
    // 0xc8f058: ret
    //     0xc8f058: ret             
    // 0xc8f05c: ldr             x1, [fp, #0x10]
    // 0xc8f060: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8f060: mov             x0, #0x76
    //     0xc8f064: tbz             w1, #0, #0xc8f074
    //     0xc8f068: ldur            x0, [x1, #-1]
    //     0xc8f06c: ubfx            x0, x0, #0xc, #0x14
    //     0xc8f070: lsl             x0, x0, #1
    // 0xc8f074: r17 = 5452
    //     0xc8f074: mov             x17, #0x154c
    // 0xc8f078: cmp             w0, w17
    // 0xc8f07c: b.ne            #0xc8f0fc
    // 0xc8f080: ldr             x2, [fp, #0x18]
    // 0xc8f084: LoadField: r0 = r1->field_17
    //     0xc8f084: ldur            w0, [x1, #0x17]
    // 0xc8f088: DecompressPointer r0
    //     0xc8f088: add             x0, x0, HEAP, lsl #32
    // 0xc8f08c: LoadField: r3 = r2->field_17
    //     0xc8f08c: ldur            w3, [x2, #0x17]
    // 0xc8f090: DecompressPointer r3
    //     0xc8f090: add             x3, x3, HEAP, lsl #32
    // 0xc8f094: r4 = LoadClassIdInstr(r0)
    //     0xc8f094: ldur            x4, [x0, #-1]
    //     0xc8f098: ubfx            x4, x4, #0xc, #0x14
    // 0xc8f09c: stp             x3, x0, [SP, #-0x10]!
    // 0xc8f0a0: mov             x0, x4
    // 0xc8f0a4: mov             lr, x0
    // 0xc8f0a8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f0ac: blr             lr
    // 0xc8f0b0: add             SP, SP, #0x10
    // 0xc8f0b4: tbnz            w0, #4, #0xc8f0fc
    // 0xc8f0b8: ldr             x1, [fp, #0x18]
    // 0xc8f0bc: ldr             x0, [fp, #0x10]
    // 0xc8f0c0: LoadField: r2 = r0->field_23
    //     0xc8f0c0: ldur            w2, [x0, #0x23]
    // 0xc8f0c4: DecompressPointer r2
    //     0xc8f0c4: add             x2, x2, HEAP, lsl #32
    // 0xc8f0c8: LoadField: r0 = r1->field_23
    //     0xc8f0c8: ldur            w0, [x1, #0x23]
    // 0xc8f0cc: DecompressPointer r0
    //     0xc8f0cc: add             x0, x0, HEAP, lsl #32
    // 0xc8f0d0: r1 = LoadClassIdInstr(r2)
    //     0xc8f0d0: ldur            x1, [x2, #-1]
    //     0xc8f0d4: ubfx            x1, x1, #0xc, #0x14
    // 0xc8f0d8: stp             x0, x2, [SP, #-0x10]!
    // 0xc8f0dc: mov             x0, x1
    // 0xc8f0e0: mov             lr, x0
    // 0xc8f0e4: ldr             lr, [x21, lr, lsl #3]
    // 0xc8f0e8: blr             lr
    // 0xc8f0ec: add             SP, SP, #0x10
    // 0xc8f0f0: tbnz            w0, #4, #0xc8f0fc
    // 0xc8f0f4: r0 = true
    //     0xc8f0f4: add             x0, NULL, #0x20  ; true
    // 0xc8f0f8: b               #0xc8f100
    // 0xc8f0fc: r0 = false
    //     0xc8f0fc: add             x0, NULL, #0x30  ; false
    // 0xc8f100: LeaveFrame
    //     0xc8f100: mov             SP, fp
    //     0xc8f104: ldp             fp, lr, [SP], #0x10
    // 0xc8f108: ret
    //     0xc8f108: ret             
    // 0xc8f10c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8f10c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8f110: b               #0xc8efc0
  }
}

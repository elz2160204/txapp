// lib: , url: package:flutter/src/material/expansion_tile.dart

// class id: 1049238, size: 0x8
class :: {
}

// class id: 3325, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __ExpansionTileState&State&SingleTickerProviderStateMixin extends State<ExpansionTile>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x616b80, size: 0x98
    // 0x616b80: EnterFrame
    //     0x616b80: stp             fp, lr, [SP, #-0x10]!
    //     0x616b84: mov             fp, SP
    // 0x616b88: CheckStackOverflow
    //     0x616b88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616b8c: cmp             SP, x16
    //     0x616b90: b.ls            #0x616c0c
    // 0x616b94: r0 = Ticker()
    //     0x616b94: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x616b98: mov             x1, x0
    // 0x616b9c: r0 = false
    //     0x616b9c: add             x0, NULL, #0x30  ; false
    // 0x616ba0: StoreField: r1->field_b = r0
    //     0x616ba0: stur            w0, [x1, #0xb]
    // 0x616ba4: ldr             x0, [fp, #0x10]
    // 0x616ba8: StoreField: r1->field_13 = r0
    //     0x616ba8: stur            w0, [x1, #0x13]
    // 0x616bac: mov             x0, x1
    // 0x616bb0: ldr             x1, [fp, #0x18]
    // 0x616bb4: StoreField: r1->field_13 = r0
    //     0x616bb4: stur            w0, [x1, #0x13]
    //     0x616bb8: ldurb           w16, [x1, #-1]
    //     0x616bbc: ldurb           w17, [x0, #-1]
    //     0x616bc0: and             x16, x17, x16, lsr #2
    //     0x616bc4: tst             x16, HEAP, lsr #32
    //     0x616bc8: b.eq            #0x616bd0
    //     0x616bcc: bl              #0xd6826c
    // 0x616bd0: SaveReg r1
    //     0x616bd0: str             x1, [SP, #-8]!
    // 0x616bd4: r0 = _updateTickerModeNotifier()
    //     0x616bd4: bl              #0x616c3c  ; [package:flutter/src/material/expansion_tile.dart] __ExpansionTileState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x616bd8: add             SP, SP, #8
    // 0x616bdc: ldr             x16, [fp, #0x18]
    // 0x616be0: SaveReg r16
    //     0x616be0: str             x16, [SP, #-8]!
    // 0x616be4: r0 = _updateTicker()
    //     0x616be4: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x616be8: add             SP, SP, #8
    // 0x616bec: ldr             x1, [fp, #0x18]
    // 0x616bf0: LoadField: r0 = r1->field_13
    //     0x616bf0: ldur            w0, [x1, #0x13]
    // 0x616bf4: DecompressPointer r0
    //     0x616bf4: add             x0, x0, HEAP, lsl #32
    // 0x616bf8: cmp             w0, NULL
    // 0x616bfc: b.eq            #0x616c14
    // 0x616c00: LeaveFrame
    //     0x616c00: mov             SP, fp
    //     0x616c04: ldp             fp, lr, [SP], #0x10
    // 0x616c08: ret
    //     0x616c08: ret             
    // 0x616c0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616c0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616c10: b               #0x616b94
    // 0x616c14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616c14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x616c3c, size: 0x11c
    // 0x616c3c: EnterFrame
    //     0x616c3c: stp             fp, lr, [SP, #-0x10]!
    //     0x616c40: mov             fp, SP
    // 0x616c44: AllocStack(0x10)
    //     0x616c44: sub             SP, SP, #0x10
    // 0x616c48: CheckStackOverflow
    //     0x616c48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616c4c: cmp             SP, x16
    //     0x616c50: b.ls            #0x616d4c
    // 0x616c54: ldr             x0, [fp, #0x10]
    // 0x616c58: LoadField: r1 = r0->field_f
    //     0x616c58: ldur            w1, [x0, #0xf]
    // 0x616c5c: DecompressPointer r1
    //     0x616c5c: add             x1, x1, HEAP, lsl #32
    // 0x616c60: cmp             w1, NULL
    // 0x616c64: b.eq            #0x616d54
    // 0x616c68: SaveReg r1
    //     0x616c68: str             x1, [SP, #-8]!
    // 0x616c6c: r0 = getNotifier()
    //     0x616c6c: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x616c70: add             SP, SP, #8
    // 0x616c74: mov             x1, x0
    // 0x616c78: ldr             x0, [fp, #0x10]
    // 0x616c7c: stur            x1, [fp, #-0x10]
    // 0x616c80: LoadField: r2 = r0->field_17
    //     0x616c80: ldur            w2, [x0, #0x17]
    // 0x616c84: DecompressPointer r2
    //     0x616c84: add             x2, x2, HEAP, lsl #32
    // 0x616c88: stur            x2, [fp, #-8]
    // 0x616c8c: cmp             w1, w2
    // 0x616c90: b.ne            #0x616ca4
    // 0x616c94: r0 = Null
    //     0x616c94: mov             x0, NULL
    // 0x616c98: LeaveFrame
    //     0x616c98: mov             SP, fp
    //     0x616c9c: ldp             fp, lr, [SP], #0x10
    // 0x616ca0: ret
    //     0x616ca0: ret             
    // 0x616ca4: cmp             w2, NULL
    // 0x616ca8: b.eq            #0x616ce4
    // 0x616cac: r1 = 1
    //     0x616cac: mov             x1, #1
    // 0x616cb0: r0 = AllocateContext()
    //     0x616cb0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x616cb4: mov             x1, x0
    // 0x616cb8: ldr             x0, [fp, #0x10]
    // 0x616cbc: StoreField: r1->field_f = r0
    //     0x616cbc: stur            w0, [x1, #0xf]
    // 0x616cc0: mov             x2, x1
    // 0x616cc4: r1 = Function '_updateTicker@156311458':.
    //     0x616cc4: add             x1, PP, #0x53, lsl #12  ; [pp+0x53170] AnonymousClosure: (0x616d58), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x616cc8: ldr             x1, [x1, #0x170]
    // 0x616ccc: r0 = AllocateClosure()
    //     0x616ccc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x616cd0: ldur            x16, [fp, #-8]
    // 0x616cd4: stp             x0, x16, [SP, #-0x10]!
    // 0x616cd8: r0 = removeListener()
    //     0x616cd8: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x616cdc: add             SP, SP, #0x10
    // 0x616ce0: ldr             x0, [fp, #0x10]
    // 0x616ce4: r1 = 1
    //     0x616ce4: mov             x1, #1
    // 0x616ce8: r0 = AllocateContext()
    //     0x616ce8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x616cec: mov             x1, x0
    // 0x616cf0: ldr             x0, [fp, #0x10]
    // 0x616cf4: StoreField: r1->field_f = r0
    //     0x616cf4: stur            w0, [x1, #0xf]
    // 0x616cf8: mov             x2, x1
    // 0x616cfc: r1 = Function '_updateTicker@156311458':.
    //     0x616cfc: add             x1, PP, #0x53, lsl #12  ; [pp+0x53170] AnonymousClosure: (0x616d58), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x616d00: ldr             x1, [x1, #0x170]
    // 0x616d04: r0 = AllocateClosure()
    //     0x616d04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x616d08: ldur            x16, [fp, #-0x10]
    // 0x616d0c: stp             x0, x16, [SP, #-0x10]!
    // 0x616d10: r0 = addListener()
    //     0x616d10: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x616d14: add             SP, SP, #0x10
    // 0x616d18: ldur            x0, [fp, #-0x10]
    // 0x616d1c: ldr             x1, [fp, #0x10]
    // 0x616d20: StoreField: r1->field_17 = r0
    //     0x616d20: stur            w0, [x1, #0x17]
    //     0x616d24: ldurb           w16, [x1, #-1]
    //     0x616d28: ldurb           w17, [x0, #-1]
    //     0x616d2c: and             x16, x17, x16, lsr #2
    //     0x616d30: tst             x16, HEAP, lsr #32
    //     0x616d34: b.eq            #0x616d3c
    //     0x616d38: bl              #0xd6826c
    // 0x616d3c: r0 = Null
    //     0x616d3c: mov             x0, NULL
    // 0x616d40: LeaveFrame
    //     0x616d40: mov             SP, fp
    //     0x616d44: ldp             fp, lr, [SP], #0x10
    // 0x616d48: ret
    //     0x616d48: ret             
    // 0x616d4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616d4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616d50: b               #0x616c54
    // 0x616d54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616d54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x616d58, size: 0x48
    // 0x616d58: EnterFrame
    //     0x616d58: stp             fp, lr, [SP, #-0x10]!
    //     0x616d5c: mov             fp, SP
    // 0x616d60: ldr             x0, [fp, #0x10]
    // 0x616d64: LoadField: r1 = r0->field_17
    //     0x616d64: ldur            w1, [x0, #0x17]
    // 0x616d68: DecompressPointer r1
    //     0x616d68: add             x1, x1, HEAP, lsl #32
    // 0x616d6c: CheckStackOverflow
    //     0x616d6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616d70: cmp             SP, x16
    //     0x616d74: b.ls            #0x616d98
    // 0x616d78: LoadField: r0 = r1->field_f
    //     0x616d78: ldur            w0, [x1, #0xf]
    // 0x616d7c: DecompressPointer r0
    //     0x616d7c: add             x0, x0, HEAP, lsl #32
    // 0x616d80: SaveReg r0
    //     0x616d80: str             x0, [SP, #-8]!
    // 0x616d84: r0 = _updateTicker()
    //     0x616d84: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x616d88: add             SP, SP, #8
    // 0x616d8c: LeaveFrame
    //     0x616d8c: mov             SP, fp
    //     0x616d90: ldp             fp, lr, [SP], #0x10
    // 0x616d94: ret
    //     0x616d94: ret             
    // 0x616d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616d9c: b               #0x616d78
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f378, size: 0x4c
    // 0x81f378: EnterFrame
    //     0x81f378: stp             fp, lr, [SP, #-0x10]!
    //     0x81f37c: mov             fp, SP
    // 0x81f380: CheckStackOverflow
    //     0x81f380: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f384: cmp             SP, x16
    //     0x81f388: b.ls            #0x81f3bc
    // 0x81f38c: ldr             x16, [fp, #0x10]
    // 0x81f390: SaveReg r16
    //     0x81f390: str             x16, [SP, #-8]!
    // 0x81f394: r0 = _updateTickerModeNotifier()
    //     0x81f394: bl              #0x616c3c  ; [package:flutter/src/material/expansion_tile.dart] __ExpansionTileState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f398: add             SP, SP, #8
    // 0x81f39c: ldr             x16, [fp, #0x10]
    // 0x81f3a0: SaveReg r16
    //     0x81f3a0: str             x16, [SP, #-8]!
    // 0x81f3a4: r0 = _updateTicker()
    //     0x81f3a4: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f3a8: add             SP, SP, #8
    // 0x81f3ac: r0 = Null
    //     0x81f3ac: mov             x0, NULL
    // 0x81f3b0: LeaveFrame
    //     0x81f3b0: mov             SP, fp
    //     0x81f3b4: ldp             fp, lr, [SP], #0x10
    // 0x81f3b8: ret
    //     0x81f3b8: ret             
    // 0x81f3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f3bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f3c0: b               #0x81f38c
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa5162c, size: 0x8c
    // 0xa5162c: EnterFrame
    //     0xa5162c: stp             fp, lr, [SP, #-0x10]!
    //     0xa51630: mov             fp, SP
    // 0xa51634: AllocStack(0x8)
    //     0xa51634: sub             SP, SP, #8
    // 0xa51638: CheckStackOverflow
    //     0xa51638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5163c: cmp             SP, x16
    //     0xa51640: b.ls            #0xa516b0
    // 0xa51644: ldr             x0, [fp, #0x10]
    // 0xa51648: LoadField: r1 = r0->field_17
    //     0xa51648: ldur            w1, [x0, #0x17]
    // 0xa5164c: DecompressPointer r1
    //     0xa5164c: add             x1, x1, HEAP, lsl #32
    // 0xa51650: stur            x1, [fp, #-8]
    // 0xa51654: cmp             w1, NULL
    // 0xa51658: b.ne            #0xa51664
    // 0xa5165c: mov             x1, x0
    // 0xa51660: b               #0xa5169c
    // 0xa51664: r1 = 1
    //     0xa51664: mov             x1, #1
    // 0xa51668: r0 = AllocateContext()
    //     0xa51668: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa5166c: mov             x1, x0
    // 0xa51670: ldr             x0, [fp, #0x10]
    // 0xa51674: StoreField: r1->field_f = r0
    //     0xa51674: stur            w0, [x1, #0xf]
    // 0xa51678: mov             x2, x1
    // 0xa5167c: r1 = Function '_updateTicker@156311458':.
    //     0xa5167c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53170] AnonymousClosure: (0x616d58), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa51680: ldr             x1, [x1, #0x170]
    // 0xa51684: r0 = AllocateClosure()
    //     0xa51684: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa51688: ldur            x16, [fp, #-8]
    // 0xa5168c: stp             x0, x16, [SP, #-0x10]!
    // 0xa51690: r0 = removeListener()
    //     0xa51690: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa51694: add             SP, SP, #0x10
    // 0xa51698: ldr             x1, [fp, #0x10]
    // 0xa5169c: StoreField: r1->field_17 = rNULL
    //     0xa5169c: stur            NULL, [x1, #0x17]
    // 0xa516a0: r0 = Null
    //     0xa516a0: mov             x0, NULL
    // 0xa516a4: LeaveFrame
    //     0xa516a4: mov             SP, fp
    //     0xa516a8: ldp             fp, lr, [SP], #0x10
    // 0xa516ac: ret
    //     0xa516ac: ret             
    // 0xa516b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa516b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa516b4: b               #0xa51644
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa516b8, size: 0x48
    // 0xa516b8: EnterFrame
    //     0xa516b8: stp             fp, lr, [SP, #-0x10]!
    //     0xa516bc: mov             fp, SP
    // 0xa516c0: ldr             x0, [fp, #0x10]
    // 0xa516c4: LoadField: r1 = r0->field_17
    //     0xa516c4: ldur            w1, [x0, #0x17]
    // 0xa516c8: DecompressPointer r1
    //     0xa516c8: add             x1, x1, HEAP, lsl #32
    // 0xa516cc: CheckStackOverflow
    //     0xa516cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa516d0: cmp             SP, x16
    //     0xa516d4: b.ls            #0xa516f8
    // 0xa516d8: LoadField: r0 = r1->field_f
    //     0xa516d8: ldur            w0, [x1, #0xf]
    // 0xa516dc: DecompressPointer r0
    //     0xa516dc: add             x0, x0, HEAP, lsl #32
    // 0xa516e0: SaveReg r0
    //     0xa516e0: str             x0, [SP, #-8]!
    // 0xa516e4: r0 = dispose()
    //     0xa516e4: bl              #0xa5162c  ; [package:flutter/src/material/expansion_tile.dart] __ExpansionTileState&State&SingleTickerProviderStateMixin::dispose
    // 0xa516e8: add             SP, SP, #8
    // 0xa516ec: LeaveFrame
    //     0xa516ec: mov             SP, fp
    //     0xa516f0: ldp             fp, lr, [SP], #0x10
    // 0xa516f4: ret
    //     0xa516f4: ret             
    // 0xa516f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa516f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa516fc: b               #0xa516d8
  }
}

// class id: 3326, size: 0x4c, field offset: 0x1c
class _ExpansionTileState extends __ExpansionTileState&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x2c
  late Animation<ShapeBorder?> _border; // offset: 0x38
  late Animation<Color?> _backgroundColor; // offset: 0x44
  late Animation<Color?> _iconColor; // offset: 0x40
  late Animation<Color?> _headerColor; // offset: 0x3c
  late Animation<double> _heightFactor; // offset: 0x34
  late Animation<double> _iconTurns; // offset: 0x30
  static late final Animatable<double> _easeInTween; // offset: 0xd84
  static late final Animatable<double> _halfTween; // offset: 0xd88
  static late final Animatable<double> _easeOutTween; // offset: 0xd80

  _ build(/* No info */) {
    // ** addr: 0x8526b0, size: 0x20c
    // 0x8526b0: EnterFrame
    //     0x8526b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8526b4: mov             fp, SP
    // 0x8526b8: AllocStack(0x28)
    //     0x8526b8: sub             SP, SP, #0x28
    // 0x8526bc: CheckStackOverflow
    //     0x8526bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8526c0: cmp             SP, x16
    //     0x8526c4: b.ls            #0x852888
    // 0x8526c8: ldr             x16, [fp, #0x10]
    // 0x8526cc: SaveReg r16
    //     0x8526cc: str             x16, [SP, #-8]!
    // 0x8526d0: r0 = of()
    //     0x8526d0: bl              #0x8528c8  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileTheme::of
    // 0x8526d4: add             SP, SP, #8
    // 0x8526d8: ldr             x0, [fp, #0x18]
    // 0x8526dc: LoadField: r1 = r0->field_47
    //     0x8526dc: ldur            w1, [x0, #0x47]
    // 0x8526e0: DecompressPointer r1
    //     0x8526e0: add             x1, x1, HEAP, lsl #32
    // 0x8526e4: tbz             w1, #4, #0x85272c
    // 0x8526e8: LoadField: r1 = r0->field_2b
    //     0x8526e8: ldur            w1, [x0, #0x2b]
    // 0x8526ec: DecompressPointer r1
    //     0x8526ec: add             x1, x1, HEAP, lsl #32
    // 0x8526f0: r16 = Sentinel
    //     0x8526f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8526f4: cmp             w1, w16
    // 0x8526f8: b.eq            #0x852890
    // 0x8526fc: LoadField: r2 = r1->field_43
    //     0x8526fc: ldur            w2, [x1, #0x43]
    // 0x852700: DecompressPointer r2
    //     0x852700: add             x2, x2, HEAP, lsl #32
    // 0x852704: r16 = Sentinel
    //     0x852704: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x852708: cmp             w2, w16
    // 0x85270c: b.eq            #0x85289c
    // 0x852710: r16 = Instance_AnimationStatus
    //     0x852710: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x852714: ldr             x16, [x16, #0xba8]
    // 0x852718: cmp             w2, w16
    // 0x85271c: r16 = true
    //     0x85271c: add             x16, NULL, #0x20  ; true
    // 0x852720: r17 = false
    //     0x852720: add             x17, NULL, #0x30  ; false
    // 0x852724: csel            x1, x16, x17, eq
    // 0x852728: b               #0x852730
    // 0x85272c: r1 = false
    //     0x85272c: add             x1, NULL, #0x30  ; false
    // 0x852730: stur            x1, [fp, #-0x20]
    // 0x852734: tbnz            w1, #4, #0x852750
    // 0x852738: LoadField: r2 = r0->field_b
    //     0x852738: ldur            w2, [x0, #0xb]
    // 0x85273c: DecompressPointer r2
    //     0x85273c: add             x2, x2, HEAP, lsl #32
    // 0x852740: cmp             w2, NULL
    // 0x852744: b.eq            #0x8528a8
    // 0x852748: r2 = true
    //     0x852748: add             x2, NULL, #0x20  ; true
    // 0x85274c: b               #0x852754
    // 0x852750: r2 = false
    //     0x852750: add             x2, NULL, #0x30  ; false
    // 0x852754: stur            x2, [fp, #-0x18]
    // 0x852758: eor             x3, x1, #0x10
    // 0x85275c: stur            x3, [fp, #-0x10]
    // 0x852760: LoadField: r4 = r0->field_b
    //     0x852760: ldur            w4, [x0, #0xb]
    // 0x852764: DecompressPointer r4
    //     0x852764: add             x4, x4, HEAP, lsl #32
    // 0x852768: cmp             w4, NULL
    // 0x85276c: b.eq            #0x8528ac
    // 0x852770: LoadField: r5 = r4->field_1b
    //     0x852770: ldur            w5, [x4, #0x1b]
    // 0x852774: DecompressPointer r5
    //     0x852774: add             x5, x5, HEAP, lsl #32
    // 0x852778: stur            x5, [fp, #-8]
    // 0x85277c: r0 = Column()
    //     0x85277c: bl              #0x825234  ; AllocateColumnStub -> Column (size=0x30)
    // 0x852780: stur            x0, [fp, #-0x28]
    // 0x852784: ldur            x16, [fp, #-8]
    // 0x852788: stp             x16, x0, [SP, #-0x10]!
    // 0x85278c: r16 = Instance_CrossAxisAlignment
    //     0x85278c: add             x16, PP, #0xe, lsl #12  ; [pp+0xeed8] Obj!CrossAxisAlignment@b64a71
    //     0x852790: ldr             x16, [x16, #0xed8]
    // 0x852794: SaveReg r16
    //     0x852794: str             x16, [SP, #-8]!
    // 0x852798: r4 = const [0, 0x3, 0x3, 0x2, crossAxisAlignment, 0x2, null]
    //     0x852798: add             x4, PP, #0x25, lsl #12  ; [pp+0x25ac0] List(7) [0, 0x3, 0x3, 0x2, "crossAxisAlignment", 0x2, Null]
    //     0x85279c: ldr             x4, [x4, #0xac0]
    // 0x8527a0: r0 = Column()
    //     0x8527a0: bl              #0x8250c8  ; [package:flutter/src/widgets/basic.dart] Column::Column
    // 0x8527a4: add             SP, SP, #0x18
    // 0x8527a8: r0 = Padding()
    //     0x8527a8: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8527ac: mov             x1, x0
    // 0x8527b0: r0 = Instance_EdgeInsets
    //     0x8527b0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x8527b4: ldr             x0, [x0, #0xbd8]
    // 0x8527b8: stur            x1, [fp, #-8]
    // 0x8527bc: StoreField: r1->field_f = r0
    //     0x8527bc: stur            w0, [x1, #0xf]
    // 0x8527c0: ldur            x0, [fp, #-0x28]
    // 0x8527c4: StoreField: r1->field_b = r0
    //     0x8527c4: stur            w0, [x1, #0xb]
    // 0x8527c8: r0 = TickerMode()
    //     0x8527c8: bl              #0x8528bc  ; AllocateTickerModeStub -> TickerMode (size=0x14)
    // 0x8527cc: mov             x1, x0
    // 0x8527d0: ldur            x0, [fp, #-0x10]
    // 0x8527d4: stur            x1, [fp, #-0x28]
    // 0x8527d8: StoreField: r1->field_b = r0
    //     0x8527d8: stur            w0, [x1, #0xb]
    // 0x8527dc: ldur            x0, [fp, #-8]
    // 0x8527e0: StoreField: r1->field_f = r0
    //     0x8527e0: stur            w0, [x1, #0xf]
    // 0x8527e4: r0 = Offstage()
    //     0x8527e4: bl              #0x594f90  ; AllocateOffstageStub -> Offstage (size=0x14)
    // 0x8527e8: mov             x1, x0
    // 0x8527ec: ldur            x0, [fp, #-0x20]
    // 0x8527f0: stur            x1, [fp, #-0x10]
    // 0x8527f4: StoreField: r1->field_f = r0
    //     0x8527f4: stur            w0, [x1, #0xf]
    // 0x8527f8: ldur            x0, [fp, #-0x28]
    // 0x8527fc: StoreField: r1->field_b = r0
    //     0x8527fc: stur            w0, [x1, #0xb]
    // 0x852800: ldr             x0, [fp, #0x18]
    // 0x852804: LoadField: r2 = r0->field_2b
    //     0x852804: ldur            w2, [x0, #0x2b]
    // 0x852808: DecompressPointer r2
    //     0x852808: add             x2, x2, HEAP, lsl #32
    // 0x85280c: r16 = Sentinel
    //     0x85280c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x852810: cmp             w2, w16
    // 0x852814: b.eq            #0x8528b0
    // 0x852818: stur            x2, [fp, #-8]
    // 0x85281c: r1 = 1
    //     0x85281c: mov             x1, #1
    // 0x852820: r0 = AllocateContext()
    //     0x852820: bl              #0xd68aa4  ; AllocateContextStub
    // 0x852824: mov             x1, x0
    // 0x852828: ldr             x0, [fp, #0x18]
    // 0x85282c: StoreField: r1->field_f = r0
    //     0x85282c: stur            w0, [x1, #0xf]
    // 0x852830: ldur            x0, [fp, #-0x18]
    // 0x852834: tbnz            w0, #4, #0x852840
    // 0x852838: r3 = Null
    //     0x852838: mov             x3, NULL
    // 0x85283c: b               #0x852844
    // 0x852840: ldur            x3, [fp, #-0x10]
    // 0x852844: ldur            x0, [fp, #-8]
    // 0x852848: mov             x2, x1
    // 0x85284c: stur            x3, [fp, #-0x10]
    // 0x852850: r1 = Function '_buildChildren@739392950':.
    //     0x852850: add             x1, PP, #0x53, lsl #12  ; [pp+0x53180] AnonymousClosure: (0x852928), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildChildren (0x85297c)
    //     0x852854: ldr             x1, [x1, #0x180]
    // 0x852858: r0 = AllocateClosure()
    //     0x852858: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x85285c: stur            x0, [fp, #-0x18]
    // 0x852860: r0 = AnimatedBuilder()
    //     0x852860: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x852864: ldur            x1, [fp, #-0x18]
    // 0x852868: StoreField: r0->field_f = r1
    //     0x852868: stur            w1, [x0, #0xf]
    // 0x85286c: ldur            x1, [fp, #-0x10]
    // 0x852870: StoreField: r0->field_13 = r1
    //     0x852870: stur            w1, [x0, #0x13]
    // 0x852874: ldur            x1, [fp, #-8]
    // 0x852878: StoreField: r0->field_b = r1
    //     0x852878: stur            w1, [x0, #0xb]
    // 0x85287c: LeaveFrame
    //     0x85287c: mov             SP, fp
    //     0x852880: ldp             fp, lr, [SP], #0x10
    // 0x852884: ret
    //     0x852884: ret             
    // 0x852888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852888: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85288c: b               #0x8526c8
    // 0x852890: r9 = _controller
    //     0x852890: add             x9, PP, #0x53, lsl #12  ; [pp+0x53188] Field <_ExpansionTileState@739392950._controller@739392950>: late (offset: 0x2c)
    //     0x852894: ldr             x9, [x9, #0x188]
    // 0x852898: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x852898: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x85289c: r9 = _status
    //     0x85289c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbe0] Field <AnimationController._status@575066280>: late (offset: 0x44)
    //     0x8528a0: ldr             x9, [x9, #0xbe0]
    // 0x8528a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8528a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8528a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8528a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8528ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8528ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8528b0: r9 = _controller
    //     0x8528b0: add             x9, PP, #0x53, lsl #12  ; [pp+0x53188] Field <_ExpansionTileState@739392950._controller@739392950>: late (offset: 0x2c)
    //     0x8528b4: ldr             x9, [x9, #0x188]
    // 0x8528b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8528b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _buildChildren(dynamic, BuildContext, Widget?) {
    // ** addr: 0x852928, size: 0x54
    // 0x852928: EnterFrame
    //     0x852928: stp             fp, lr, [SP, #-0x10]!
    //     0x85292c: mov             fp, SP
    // 0x852930: ldr             x0, [fp, #0x20]
    // 0x852934: LoadField: r1 = r0->field_17
    //     0x852934: ldur            w1, [x0, #0x17]
    // 0x852938: DecompressPointer r1
    //     0x852938: add             x1, x1, HEAP, lsl #32
    // 0x85293c: CheckStackOverflow
    //     0x85293c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x852940: cmp             SP, x16
    //     0x852944: b.ls            #0x852974
    // 0x852948: LoadField: r0 = r1->field_f
    //     0x852948: ldur            w0, [x1, #0xf]
    // 0x85294c: DecompressPointer r0
    //     0x85294c: add             x0, x0, HEAP, lsl #32
    // 0x852950: ldr             x16, [fp, #0x18]
    // 0x852954: stp             x16, x0, [SP, #-0x10]!
    // 0x852958: ldr             x16, [fp, #0x10]
    // 0x85295c: SaveReg r16
    //     0x85295c: str             x16, [SP, #-8]!
    // 0x852960: r0 = _buildChildren()
    //     0x852960: bl              #0x85297c  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildChildren
    // 0x852964: add             SP, SP, #0x18
    // 0x852968: LeaveFrame
    //     0x852968: mov             SP, fp
    //     0x85296c: ldp             fp, lr, [SP], #0x10
    // 0x852970: ret
    //     0x852970: ret             
    // 0x852974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852974: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852978: b               #0x852948
  }
  _ _buildChildren(/* No info */) {
    // ** addr: 0x85297c, size: 0x410
    // 0x85297c: EnterFrame
    //     0x85297c: stp             fp, lr, [SP, #-0x10]!
    //     0x852980: mov             fp, SP
    // 0x852984: AllocStack(0x40)
    //     0x852984: sub             SP, SP, #0x40
    // 0x852988: CheckStackOverflow
    //     0x852988: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85298c: cmp             SP, x16
    //     0x852990: b.ls            #0x852d38
    // 0x852994: ldr             x16, [fp, #0x18]
    // 0x852998: SaveReg r16
    //     0x852998: str             x16, [SP, #-8]!
    // 0x85299c: r0 = of()
    //     0x85299c: bl              #0x8528c8  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileTheme::of
    // 0x8529a0: add             SP, SP, #8
    // 0x8529a4: ldr             x0, [fp, #0x20]
    // 0x8529a8: LoadField: r1 = r0->field_37
    //     0x8529a8: ldur            w1, [x0, #0x37]
    // 0x8529ac: DecompressPointer r1
    //     0x8529ac: add             x1, x1, HEAP, lsl #32
    // 0x8529b0: r16 = Sentinel
    //     0x8529b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8529b4: cmp             w1, w16
    // 0x8529b8: b.eq            #0x852d40
    // 0x8529bc: LoadField: r2 = r1->field_f
    //     0x8529bc: ldur            w2, [x1, #0xf]
    // 0x8529c0: DecompressPointer r2
    //     0x8529c0: add             x2, x2, HEAP, lsl #32
    // 0x8529c4: LoadField: r3 = r1->field_b
    //     0x8529c4: ldur            w3, [x1, #0xb]
    // 0x8529c8: DecompressPointer r3
    //     0x8529c8: add             x3, x3, HEAP, lsl #32
    // 0x8529cc: stp             x3, x2, [SP, #-0x10]!
    // 0x8529d0: r0 = evaluate()
    //     0x8529d0: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x8529d4: add             SP, SP, #0x10
    // 0x8529d8: cmp             w0, NULL
    // 0x8529dc: b.ne            #0x8529ec
    // 0x8529e0: r1 = Instance_Border
    //     0x8529e0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53190] Obj!Border@b38491
    //     0x8529e4: ldr             x1, [x1, #0x190]
    // 0x8529e8: b               #0x8529f0
    // 0x8529ec: mov             x1, x0
    // 0x8529f0: ldr             x0, [fp, #0x20]
    // 0x8529f4: stur            x1, [fp, #-8]
    // 0x8529f8: LoadField: r2 = r0->field_b
    //     0x8529f8: ldur            w2, [x0, #0xb]
    // 0x8529fc: DecompressPointer r2
    //     0x8529fc: add             x2, x2, HEAP, lsl #32
    // 0x852a00: cmp             w2, NULL
    // 0x852a04: b.eq            #0x852d4c
    // 0x852a08: LoadField: r2 = r0->field_43
    //     0x852a08: ldur            w2, [x0, #0x43]
    // 0x852a0c: DecompressPointer r2
    //     0x852a0c: add             x2, x2, HEAP, lsl #32
    // 0x852a10: r16 = Sentinel
    //     0x852a10: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x852a14: cmp             w2, w16
    // 0x852a18: b.eq            #0x852d50
    // 0x852a1c: LoadField: r3 = r2->field_f
    //     0x852a1c: ldur            w3, [x2, #0xf]
    // 0x852a20: DecompressPointer r3
    //     0x852a20: add             x3, x3, HEAP, lsl #32
    // 0x852a24: LoadField: r4 = r2->field_b
    //     0x852a24: ldur            w4, [x2, #0xb]
    // 0x852a28: DecompressPointer r4
    //     0x852a28: add             x4, x4, HEAP, lsl #32
    // 0x852a2c: stp             x4, x3, [SP, #-0x10]!
    // 0x852a30: r0 = evaluate()
    //     0x852a30: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x852a34: add             SP, SP, #0x10
    // 0x852a38: cmp             w0, NULL
    // 0x852a3c: b.ne            #0x852a44
    // 0x852a40: r0 = Null
    //     0x852a40: mov             x0, NULL
    // 0x852a44: cmp             w0, NULL
    // 0x852a48: b.ne            #0x852a58
    // 0x852a4c: r2 = Instance_Color
    //     0x852a4c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x852a50: ldr             x2, [x2, #0xc08]
    // 0x852a54: b               #0x852a5c
    // 0x852a58: mov             x2, x0
    // 0x852a5c: ldr             x0, [fp, #0x20]
    // 0x852a60: ldur            x1, [fp, #-8]
    // 0x852a64: stur            x2, [fp, #-0x10]
    // 0x852a68: r0 = ShapeDecoration()
    //     0x852a68: bl              #0x85318c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0x852a6c: mov             x1, x0
    // 0x852a70: ldur            x0, [fp, #-0x10]
    // 0x852a74: stur            x1, [fp, #-0x18]
    // 0x852a78: StoreField: r1->field_7 = r0
    //     0x852a78: stur            w0, [x1, #7]
    // 0x852a7c: ldur            x0, [fp, #-8]
    // 0x852a80: StoreField: r1->field_17 = r0
    //     0x852a80: stur            w0, [x1, #0x17]
    // 0x852a84: ldr             x0, [fp, #0x20]
    // 0x852a88: LoadField: r2 = r0->field_3f
    //     0x852a88: ldur            w2, [x0, #0x3f]
    // 0x852a8c: DecompressPointer r2
    //     0x852a8c: add             x2, x2, HEAP, lsl #32
    // 0x852a90: r16 = Sentinel
    //     0x852a90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x852a94: cmp             w2, w16
    // 0x852a98: b.eq            #0x852d5c
    // 0x852a9c: LoadField: r3 = r2->field_f
    //     0x852a9c: ldur            w3, [x2, #0xf]
    // 0x852aa0: DecompressPointer r3
    //     0x852aa0: add             x3, x3, HEAP, lsl #32
    // 0x852aa4: LoadField: r4 = r2->field_b
    //     0x852aa4: ldur            w4, [x2, #0xb]
    // 0x852aa8: DecompressPointer r4
    //     0x852aa8: add             x4, x4, HEAP, lsl #32
    // 0x852aac: stp             x4, x3, [SP, #-0x10]!
    // 0x852ab0: r0 = evaluate()
    //     0x852ab0: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x852ab4: add             SP, SP, #0x10
    // 0x852ab8: cmp             w0, NULL
    // 0x852abc: b.ne            #0x852ac8
    // 0x852ac0: r2 = Null
    //     0x852ac0: mov             x2, NULL
    // 0x852ac4: b               #0x852acc
    // 0x852ac8: mov             x2, x0
    // 0x852acc: ldr             x0, [fp, #0x20]
    // 0x852ad0: ldr             x1, [fp, #0x10]
    // 0x852ad4: stur            x2, [fp, #-8]
    // 0x852ad8: LoadField: r3 = r0->field_3b
    //     0x852ad8: ldur            w3, [x0, #0x3b]
    // 0x852adc: DecompressPointer r3
    //     0x852adc: add             x3, x3, HEAP, lsl #32
    // 0x852ae0: r16 = Sentinel
    //     0x852ae0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x852ae4: cmp             w3, w16
    // 0x852ae8: b.eq            #0x852d68
    // 0x852aec: LoadField: r4 = r3->field_f
    //     0x852aec: ldur            w4, [x3, #0xf]
    // 0x852af0: DecompressPointer r4
    //     0x852af0: add             x4, x4, HEAP, lsl #32
    // 0x852af4: LoadField: r5 = r3->field_b
    //     0x852af4: ldur            w5, [x3, #0xb]
    // 0x852af8: DecompressPointer r5
    //     0x852af8: add             x5, x5, HEAP, lsl #32
    // 0x852afc: stp             x5, x4, [SP, #-0x10]!
    // 0x852b00: r0 = evaluate()
    //     0x852b00: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x852b04: add             SP, SP, #0x10
    // 0x852b08: stur            x0, [fp, #-0x10]
    // 0x852b0c: r1 = 1
    //     0x852b0c: mov             x1, #1
    // 0x852b10: r0 = AllocateContext()
    //     0x852b10: bl              #0xd68aa4  ; AllocateContextStub
    // 0x852b14: mov             x1, x0
    // 0x852b18: ldr             x0, [fp, #0x20]
    // 0x852b1c: stur            x1, [fp, #-0x20]
    // 0x852b20: StoreField: r1->field_f = r0
    //     0x852b20: stur            w0, [x1, #0xf]
    // 0x852b24: LoadField: r2 = r0->field_b
    //     0x852b24: ldur            w2, [x0, #0xb]
    // 0x852b28: DecompressPointer r2
    //     0x852b28: add             x2, x2, HEAP, lsl #32
    // 0x852b2c: cmp             w2, NULL
    // 0x852b30: b.eq            #0x852d74
    // 0x852b34: SaveReg r0
    //     0x852b34: str             x0, [SP, #-8]!
    // 0x852b38: r0 = didChangeDependencies()
    //     0x852b38: bl              #0xa64624  ; [package:flutter/src/widgets/selection_container.dart] _SelectionContainerState::didChangeDependencies
    // 0x852b3c: add             SP, SP, #8
    // 0x852b40: mov             x1, x0
    // 0x852b44: ldr             x0, [fp, #0x20]
    // 0x852b48: stur            x1, [fp, #-0x30]
    // 0x852b4c: LoadField: r2 = r0->field_b
    //     0x852b4c: ldur            w2, [x0, #0xb]
    // 0x852b50: DecompressPointer r2
    //     0x852b50: add             x2, x2, HEAP, lsl #32
    // 0x852b54: cmp             w2, NULL
    // 0x852b58: b.eq            #0x852d78
    // 0x852b5c: LoadField: r3 = r2->field_f
    //     0x852b5c: ldur            w3, [x2, #0xf]
    // 0x852b60: DecompressPointer r3
    //     0x852b60: add             x3, x3, HEAP, lsl #32
    // 0x852b64: stur            x3, [fp, #-0x28]
    // 0x852b68: SaveReg r0
    //     0x852b68: str             x0, [SP, #-8]!
    // 0x852b6c: r0 = _buildTrailingIcon()
    //     0x852b6c: bl              #0x8530d0  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildTrailingIcon
    // 0x852b70: add             SP, SP, #8
    // 0x852b74: stur            x0, [fp, #-0x38]
    // 0x852b78: r0 = ListTile()
    //     0x852b78: bl              #0x8530c4  ; AllocateListTileStub -> ListTile (size=0x84)
    // 0x852b7c: mov             x3, x0
    // 0x852b80: ldur            x0, [fp, #-0x30]
    // 0x852b84: stur            x3, [fp, #-0x40]
    // 0x852b88: StoreField: r3->field_b = r0
    //     0x852b88: stur            w0, [x3, #0xb]
    // 0x852b8c: ldur            x0, [fp, #-0x28]
    // 0x852b90: StoreField: r3->field_f = r0
    //     0x852b90: stur            w0, [x3, #0xf]
    // 0x852b94: ldur            x0, [fp, #-0x38]
    // 0x852b98: StoreField: r3->field_17 = r0
    //     0x852b98: stur            w0, [x3, #0x17]
    // 0x852b9c: r0 = false
    //     0x852b9c: add             x0, NULL, #0x30  ; false
    // 0x852ba0: StoreField: r3->field_1b = r0
    //     0x852ba0: stur            w0, [x3, #0x1b]
    // 0x852ba4: r1 = true
    //     0x852ba4: add             x1, NULL, #0x20  ; true
    // 0x852ba8: StoreField: r3->field_3f = r1
    //     0x852ba8: stur            w1, [x3, #0x3f]
    // 0x852bac: ldur            x2, [fp, #-0x20]
    // 0x852bb0: r1 = Function '_handleTap@739392950':.
    //     0x852bb0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53198] AnonymousClosure: (0x85322c), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_handleTap (0x853274)
    //     0x852bb4: ldr             x1, [x1, #0x198]
    // 0x852bb8: r0 = AllocateClosure()
    //     0x852bb8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x852bbc: mov             x1, x0
    // 0x852bc0: ldur            x0, [fp, #-0x40]
    // 0x852bc4: StoreField: r0->field_43 = r1
    //     0x852bc4: stur            w1, [x0, #0x43]
    // 0x852bc8: r1 = false
    //     0x852bc8: add             x1, NULL, #0x30  ; false
    // 0x852bcc: StoreField: r0->field_53 = r1
    //     0x852bcc: stur            w1, [x0, #0x53]
    // 0x852bd0: StoreField: r0->field_67 = r1
    //     0x852bd0: stur            w1, [x0, #0x67]
    // 0x852bd4: ldur            x16, [fp, #-8]
    // 0x852bd8: stp             x16, x0, [SP, #-0x10]!
    // 0x852bdc: ldur            x16, [fp, #-0x10]
    // 0x852be0: SaveReg r16
    //     0x852be0: str             x16, [SP, #-8]!
    // 0x852be4: r4 = const [0, 0x3, 0x3, 0x1, iconColor, 0x1, textColor, 0x2, null]
    //     0x852be4: add             x4, PP, #0x53, lsl #12  ; [pp+0x531a0] List(9) [0, 0x3, 0x3, 0x1, "iconColor", 0x1, "textColor", 0x2, Null]
    //     0x852be8: ldr             x4, [x4, #0x1a0]
    // 0x852bec: r0 = merge()
    //     0x852bec: bl              #0x852d8c  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::merge
    // 0x852bf0: add             SP, SP, #0x18
    // 0x852bf4: mov             x1, x0
    // 0x852bf8: ldr             x0, [fp, #0x20]
    // 0x852bfc: stur            x1, [fp, #-8]
    // 0x852c00: LoadField: r2 = r0->field_b
    //     0x852c00: ldur            w2, [x0, #0xb]
    // 0x852c04: DecompressPointer r2
    //     0x852c04: add             x2, x2, HEAP, lsl #32
    // 0x852c08: cmp             w2, NULL
    // 0x852c0c: b.eq            #0x852d7c
    // 0x852c10: LoadField: r2 = r0->field_33
    //     0x852c10: ldur            w2, [x0, #0x33]
    // 0x852c14: DecompressPointer r2
    //     0x852c14: add             x2, x2, HEAP, lsl #32
    // 0x852c18: r16 = Sentinel
    //     0x852c18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x852c1c: cmp             w2, w16
    // 0x852c20: b.eq            #0x852d80
    // 0x852c24: LoadField: r0 = r2->field_f
    //     0x852c24: ldur            w0, [x2, #0xf]
    // 0x852c28: DecompressPointer r0
    //     0x852c28: add             x0, x0, HEAP, lsl #32
    // 0x852c2c: LoadField: r3 = r2->field_b
    //     0x852c2c: ldur            w3, [x2, #0xb]
    // 0x852c30: DecompressPointer r3
    //     0x852c30: add             x3, x3, HEAP, lsl #32
    // 0x852c34: stp             x3, x0, [SP, #-0x10]!
    // 0x852c38: r0 = evaluate()
    //     0x852c38: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x852c3c: add             SP, SP, #0x10
    // 0x852c40: stur            x0, [fp, #-0x10]
    // 0x852c44: r0 = Align()
    //     0x852c44: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x852c48: mov             x1, x0
    // 0x852c4c: r0 = Instance_Alignment
    //     0x852c4c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26fb8] Obj!Alignment@b37b51
    //     0x852c50: ldr             x0, [x0, #0xfb8]
    // 0x852c54: stur            x1, [fp, #-0x20]
    // 0x852c58: StoreField: r1->field_f = r0
    //     0x852c58: stur            w0, [x1, #0xf]
    // 0x852c5c: ldur            x0, [fp, #-0x10]
    // 0x852c60: StoreField: r1->field_17 = r0
    //     0x852c60: stur            w0, [x1, #0x17]
    // 0x852c64: ldr             x0, [fp, #0x10]
    // 0x852c68: StoreField: r1->field_b = r0
    //     0x852c68: stur            w0, [x1, #0xb]
    // 0x852c6c: r0 = ClipRect()
    //     0x852c6c: bl              #0x847d58  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0x852c70: mov             x3, x0
    // 0x852c74: r0 = Instance_Clip
    //     0x852c74: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x852c78: ldr             x0, [x0, #0x678]
    // 0x852c7c: stur            x3, [fp, #-0x10]
    // 0x852c80: StoreField: r3->field_13 = r0
    //     0x852c80: stur            w0, [x3, #0x13]
    // 0x852c84: ldur            x0, [fp, #-0x20]
    // 0x852c88: StoreField: r3->field_b = r0
    //     0x852c88: stur            w0, [x3, #0xb]
    // 0x852c8c: r1 = Null
    //     0x852c8c: mov             x1, NULL
    // 0x852c90: r2 = 4
    //     0x852c90: mov             x2, #4
    // 0x852c94: r0 = AllocateArray()
    //     0x852c94: bl              #0xd6987c  ; AllocateArrayStub
    // 0x852c98: mov             x2, x0
    // 0x852c9c: ldur            x0, [fp, #-8]
    // 0x852ca0: stur            x2, [fp, #-0x20]
    // 0x852ca4: StoreField: r2->field_f = r0
    //     0x852ca4: stur            w0, [x2, #0xf]
    // 0x852ca8: ldur            x0, [fp, #-0x10]
    // 0x852cac: StoreField: r2->field_13 = r0
    //     0x852cac: stur            w0, [x2, #0x13]
    // 0x852cb0: r1 = <Widget>
    //     0x852cb0: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x852cb4: ldr             x1, [x1, #0xea8]
    // 0x852cb8: r0 = AllocateGrowableArray()
    //     0x852cb8: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x852cbc: mov             x1, x0
    // 0x852cc0: ldur            x0, [fp, #-0x20]
    // 0x852cc4: stur            x1, [fp, #-8]
    // 0x852cc8: StoreField: r1->field_f = r0
    //     0x852cc8: stur            w0, [x1, #0xf]
    // 0x852ccc: r0 = 4
    //     0x852ccc: mov             x0, #4
    // 0x852cd0: StoreField: r1->field_b = r0
    //     0x852cd0: stur            w0, [x1, #0xb]
    // 0x852cd4: r0 = Column()
    //     0x852cd4: bl              #0x825234  ; AllocateColumnStub -> Column (size=0x30)
    // 0x852cd8: stur            x0, [fp, #-0x10]
    // 0x852cdc: ldur            x16, [fp, #-8]
    // 0x852ce0: stp             x16, x0, [SP, #-0x10]!
    // 0x852ce4: r16 = Instance_MainAxisSize
    //     0x852ce4: add             x16, PP, #0xe, lsl #12  ; [pp+0xeeb0] Obj!MainAxisSize@b64b71
    //     0x852ce8: ldr             x16, [x16, #0xeb0]
    // 0x852cec: SaveReg r16
    //     0x852cec: str             x16, [SP, #-8]!
    // 0x852cf0: r4 = const [0, 0x3, 0x3, 0x2, mainAxisSize, 0x2, null]
    //     0x852cf0: add             x4, PP, #0xe, lsl #12  ; [pp+0xeeb8] List(7) [0, 0x3, 0x3, 0x2, "mainAxisSize", 0x2, Null]
    //     0x852cf4: ldr             x4, [x4, #0xeb8]
    // 0x852cf8: r0 = Column()
    //     0x852cf8: bl              #0x8250c8  ; [package:flutter/src/widgets/basic.dart] Column::Column
    // 0x852cfc: add             SP, SP, #0x18
    // 0x852d00: r0 = Container()
    //     0x852d00: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x852d04: stur            x0, [fp, #-8]
    // 0x852d08: ldur            x16, [fp, #-0x18]
    // 0x852d0c: stp             x16, x0, [SP, #-0x10]!
    // 0x852d10: ldur            x16, [fp, #-0x10]
    // 0x852d14: SaveReg r16
    //     0x852d14: str             x16, [SP, #-8]!
    // 0x852d18: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, decoration, 0x1, null]
    //     0x852d18: add             x4, PP, #0x27, lsl #12  ; [pp+0x27018] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0x852d1c: ldr             x4, [x4, #0x18]
    // 0x852d20: r0 = Container()
    //     0x852d20: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x852d24: add             SP, SP, #0x18
    // 0x852d28: ldur            x0, [fp, #-8]
    // 0x852d2c: LeaveFrame
    //     0x852d2c: mov             SP, fp
    //     0x852d30: ldp             fp, lr, [SP], #0x10
    // 0x852d34: ret
    //     0x852d34: ret             
    // 0x852d38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852d38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852d3c: b               #0x852994
    // 0x852d40: r9 = _border
    //     0x852d40: add             x9, PP, #0x53, lsl #12  ; [pp+0x531a8] Field <_ExpansionTileState@739392950._border@739392950>: late (offset: 0x38)
    //     0x852d44: ldr             x9, [x9, #0x1a8]
    // 0x852d48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x852d48: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x852d4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852d4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x852d50: r9 = _backgroundColor
    //     0x852d50: add             x9, PP, #0x53, lsl #12  ; [pp+0x531b0] Field <_ExpansionTileState@739392950._backgroundColor@739392950>: late (offset: 0x44)
    //     0x852d54: ldr             x9, [x9, #0x1b0]
    // 0x852d58: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x852d58: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x852d5c: r9 = _iconColor
    //     0x852d5c: add             x9, PP, #0x53, lsl #12  ; [pp+0x531b8] Field <_ExpansionTileState@739392950._iconColor@739392950>: late (offset: 0x40)
    //     0x852d60: ldr             x9, [x9, #0x1b8]
    // 0x852d64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x852d64: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x852d68: r9 = _headerColor
    //     0x852d68: add             x9, PP, #0x53, lsl #12  ; [pp+0x531c0] Field <_ExpansionTileState@739392950._headerColor@739392950>: late (offset: 0x3c)
    //     0x852d6c: ldr             x9, [x9, #0x1c0]
    // 0x852d70: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x852d70: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x852d74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852d74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x852d78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852d78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x852d7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852d7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x852d80: r9 = _heightFactor
    //     0x852d80: add             x9, PP, #0x53, lsl #12  ; [pp+0x531c8] Field <_ExpansionTileState@739392950._heightFactor@739392950>: late (offset: 0x34)
    //     0x852d84: ldr             x9, [x9, #0x1c8]
    // 0x852d88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x852d88: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildTrailingIcon(/* No info */) {
    // ** addr: 0x8530d0, size: 0x4c
    // 0x8530d0: EnterFrame
    //     0x8530d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8530d4: mov             fp, SP
    // 0x8530d8: CheckStackOverflow
    //     0x8530d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8530dc: cmp             SP, x16
    //     0x8530e0: b.ls            #0x853110
    // 0x8530e4: ldr             x0, [fp, #0x10]
    // 0x8530e8: LoadField: r1 = r0->field_b
    //     0x8530e8: ldur            w1, [x0, #0xb]
    // 0x8530ec: DecompressPointer r1
    //     0x8530ec: add             x1, x1, HEAP, lsl #32
    // 0x8530f0: cmp             w1, NULL
    // 0x8530f4: b.eq            #0x853118
    // 0x8530f8: SaveReg r0
    //     0x8530f8: str             x0, [SP, #-8]!
    // 0x8530fc: r0 = _buildIcon()
    //     0x8530fc: bl              #0x85311c  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_buildIcon
    // 0x853100: add             SP, SP, #8
    // 0x853104: LeaveFrame
    //     0x853104: mov             SP, fp
    //     0x853108: ldp             fp, lr, [SP], #0x10
    // 0x85310c: ret
    //     0x85310c: ret             
    // 0x853110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853114: b               #0x8530e4
    // 0x853118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x853118: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildIcon(/* No info */) {
    // ** addr: 0x85311c, size: 0x64
    // 0x85311c: EnterFrame
    //     0x85311c: stp             fp, lr, [SP, #-0x10]!
    //     0x853120: mov             fp, SP
    // 0x853124: AllocStack(0x8)
    //     0x853124: sub             SP, SP, #8
    // 0x853128: ldr             x0, [fp, #0x10]
    // 0x85312c: LoadField: r1 = r0->field_2f
    //     0x85312c: ldur            w1, [x0, #0x2f]
    // 0x853130: DecompressPointer r1
    //     0x853130: add             x1, x1, HEAP, lsl #32
    // 0x853134: r16 = Sentinel
    //     0x853134: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x853138: cmp             w1, w16
    // 0x85313c: b.eq            #0x853174
    // 0x853140: stur            x1, [fp, #-8]
    // 0x853144: r0 = RotationTransition()
    //     0x853144: bl              #0x853180  ; AllocateRotationTransitionStub -> RotationTransition (size=0x1c)
    // 0x853148: r1 = Instance_Alignment
    //     0x853148: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x85314c: ldr             x1, [x1, #0xc70]
    // 0x853150: StoreField: r0->field_f = r1
    //     0x853150: stur            w1, [x0, #0xf]
    // 0x853154: r1 = Instance_Icon
    //     0x853154: add             x1, PP, #0x53, lsl #12  ; [pp+0x53200] Obj!Icon@b4e151
    //     0x853158: ldr             x1, [x1, #0x200]
    // 0x85315c: StoreField: r0->field_17 = r1
    //     0x85315c: stur            w1, [x0, #0x17]
    // 0x853160: ldur            x1, [fp, #-8]
    // 0x853164: StoreField: r0->field_b = r1
    //     0x853164: stur            w1, [x0, #0xb]
    // 0x853168: LeaveFrame
    //     0x853168: mov             SP, fp
    //     0x85316c: ldp             fp, lr, [SP], #0x10
    // 0x853170: ret
    //     0x853170: ret             
    // 0x853174: r9 = _iconTurns
    //     0x853174: add             x9, PP, #0x53, lsl #12  ; [pp+0x53208] Field <_ExpansionTileState@739392950._iconTurns@739392950>: late (offset: 0x30)
    //     0x853178: ldr             x9, [x9, #0x208]
    // 0x85317c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x85317c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTap(dynamic) {
    // ** addr: 0x85322c, size: 0x48
    // 0x85322c: EnterFrame
    //     0x85322c: stp             fp, lr, [SP, #-0x10]!
    //     0x853230: mov             fp, SP
    // 0x853234: ldr             x0, [fp, #0x10]
    // 0x853238: LoadField: r1 = r0->field_17
    //     0x853238: ldur            w1, [x0, #0x17]
    // 0x85323c: DecompressPointer r1
    //     0x85323c: add             x1, x1, HEAP, lsl #32
    // 0x853240: CheckStackOverflow
    //     0x853240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x853244: cmp             SP, x16
    //     0x853248: b.ls            #0x85326c
    // 0x85324c: LoadField: r0 = r1->field_f
    //     0x85324c: ldur            w0, [x1, #0xf]
    // 0x853250: DecompressPointer r0
    //     0x853250: add             x0, x0, HEAP, lsl #32
    // 0x853254: SaveReg r0
    //     0x853254: str             x0, [SP, #-8]!
    // 0x853258: r0 = _handleTap()
    //     0x853258: bl              #0x853274  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_handleTap
    // 0x85325c: add             SP, SP, #8
    // 0x853260: LeaveFrame
    //     0x853260: mov             SP, fp
    //     0x853264: ldp             fp, lr, [SP], #0x10
    // 0x853268: ret
    //     0x853268: ret             
    // 0x85326c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85326c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853270: b               #0x85324c
  }
  _ _handleTap(/* No info */) {
    // ** addr: 0x853274, size: 0x78
    // 0x853274: EnterFrame
    //     0x853274: stp             fp, lr, [SP, #-0x10]!
    //     0x853278: mov             fp, SP
    // 0x85327c: CheckStackOverflow
    //     0x85327c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x853280: cmp             SP, x16
    //     0x853284: b.ls            #0x8532e0
    // 0x853288: r1 = 1
    //     0x853288: mov             x1, #1
    // 0x85328c: r0 = AllocateContext()
    //     0x85328c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x853290: mov             x1, x0
    // 0x853294: ldr             x0, [fp, #0x10]
    // 0x853298: StoreField: r1->field_f = r0
    //     0x853298: stur            w0, [x1, #0xf]
    // 0x85329c: mov             x2, x1
    // 0x8532a0: r1 = Function '<anonymous closure>':.
    //     0x8532a0: add             x1, PP, #0x53, lsl #12  ; [pp+0x531d0] AnonymousClosure: (0x8532ec), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_handleTap (0x853274)
    //     0x8532a4: ldr             x1, [x1, #0x1d0]
    // 0x8532a8: r0 = AllocateClosure()
    //     0x8532a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8532ac: ldr             x16, [fp, #0x10]
    // 0x8532b0: stp             x0, x16, [SP, #-0x10]!
    // 0x8532b4: r0 = setState()
    //     0x8532b4: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8532b8: add             SP, SP, #0x10
    // 0x8532bc: ldr             x1, [fp, #0x10]
    // 0x8532c0: LoadField: r2 = r1->field_b
    //     0x8532c0: ldur            w2, [x1, #0xb]
    // 0x8532c4: DecompressPointer r2
    //     0x8532c4: add             x2, x2, HEAP, lsl #32
    // 0x8532c8: cmp             w2, NULL
    // 0x8532cc: b.eq            #0x8532e8
    // 0x8532d0: r0 = Null
    //     0x8532d0: mov             x0, NULL
    // 0x8532d4: LeaveFrame
    //     0x8532d4: mov             SP, fp
    //     0x8532d8: ldp             fp, lr, [SP], #0x10
    // 0x8532dc: ret
    //     0x8532dc: ret             
    // 0x8532e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8532e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8532e4: b               #0x853288
    // 0x8532e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8532e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8532ec, size: 0x15c
    // 0x8532ec: EnterFrame
    //     0x8532ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8532f0: mov             fp, SP
    // 0x8532f4: AllocStack(0x10)
    //     0x8532f4: sub             SP, SP, #0x10
    // 0x8532f8: SetupParameters()
    //     0x8532f8: ldr             x0, [fp, #0x10]
    //     0x8532fc: ldur            w2, [x0, #0x17]
    //     0x853300: add             x2, x2, HEAP, lsl #32
    //     0x853304: stur            x2, [fp, #-8]
    // 0x853308: CheckStackOverflow
    //     0x853308: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85330c: cmp             SP, x16
    //     0x853310: b.ls            #0x853420
    // 0x853314: LoadField: r0 = r2->field_f
    //     0x853314: ldur            w0, [x2, #0xf]
    // 0x853318: DecompressPointer r0
    //     0x853318: add             x0, x0, HEAP, lsl #32
    // 0x85331c: LoadField: r1 = r0->field_47
    //     0x85331c: ldur            w1, [x0, #0x47]
    // 0x853320: DecompressPointer r1
    //     0x853320: add             x1, x1, HEAP, lsl #32
    // 0x853324: eor             x3, x1, #0x10
    // 0x853328: StoreField: r0->field_47 = r3
    //     0x853328: stur            w3, [x0, #0x47]
    // 0x85332c: tbnz            w3, #4, #0x853358
    // 0x853330: LoadField: r1 = r0->field_2b
    //     0x853330: ldur            w1, [x0, #0x2b]
    // 0x853334: DecompressPointer r1
    //     0x853334: add             x1, x1, HEAP, lsl #32
    // 0x853338: r16 = Sentinel
    //     0x853338: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x85333c: cmp             w1, w16
    // 0x853340: b.eq            #0x853428
    // 0x853344: SaveReg r1
    //     0x853344: str             x1, [SP, #-8]!
    // 0x853348: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x853348: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x85334c: r0 = forward()
    //     0x85334c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x853350: add             SP, SP, #8
    // 0x853354: b               #0x8533ac
    // 0x853358: LoadField: r1 = r0->field_2b
    //     0x853358: ldur            w1, [x0, #0x2b]
    // 0x85335c: DecompressPointer r1
    //     0x85335c: add             x1, x1, HEAP, lsl #32
    // 0x853360: r16 = Sentinel
    //     0x853360: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x853364: cmp             w1, w16
    // 0x853368: b.eq            #0x853434
    // 0x85336c: SaveReg r1
    //     0x85336c: str             x1, [SP, #-8]!
    // 0x853370: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x853370: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x853374: r0 = reverse()
    //     0x853374: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x853378: add             SP, SP, #8
    // 0x85337c: ldur            x2, [fp, #-8]
    // 0x853380: r1 = Function '<anonymous closure>':.
    //     0x853380: add             x1, PP, #0x53, lsl #12  ; [pp+0x531d8] AnonymousClosure: (0x85375c), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_handleTap (0x853274)
    //     0x853384: ldr             x1, [x1, #0x1d8]
    // 0x853388: stur            x0, [fp, #-0x10]
    // 0x85338c: r0 = AllocateClosure()
    //     0x85338c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x853390: r16 = <void?>
    //     0x853390: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x853394: ldur            lr, [fp, #-0x10]
    // 0x853398: stp             lr, x16, [SP, #-0x10]!
    // 0x85339c: SaveReg r0
    //     0x85339c: str             x0, [SP, #-8]!
    // 0x8533a0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8533a0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8533a4: r0 = then()
    //     0x8533a4: bl              #0xd0444c  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::then
    // 0x8533a8: add             SP, SP, #0x18
    // 0x8533ac: ldur            x0, [fp, #-8]
    // 0x8533b0: LoadField: r1 = r0->field_f
    //     0x8533b0: ldur            w1, [x0, #0xf]
    // 0x8533b4: DecompressPointer r1
    //     0x8533b4: add             x1, x1, HEAP, lsl #32
    // 0x8533b8: LoadField: r2 = r1->field_f
    //     0x8533b8: ldur            w2, [x1, #0xf]
    // 0x8533bc: DecompressPointer r2
    //     0x8533bc: add             x2, x2, HEAP, lsl #32
    // 0x8533c0: cmp             w2, NULL
    // 0x8533c4: b.eq            #0x853440
    // 0x8533c8: SaveReg r2
    //     0x8533c8: str             x2, [SP, #-8]!
    // 0x8533cc: r0 = maybeOf()
    //     0x8533cc: bl              #0x8536fc  ; [package:flutter/src/widgets/page_storage.dart] PageStorage::maybeOf
    // 0x8533d0: add             SP, SP, #8
    // 0x8533d4: cmp             w0, NULL
    // 0x8533d8: b.eq            #0x853410
    // 0x8533dc: ldur            x1, [fp, #-8]
    // 0x8533e0: LoadField: r2 = r1->field_f
    //     0x8533e0: ldur            w2, [x1, #0xf]
    // 0x8533e4: DecompressPointer r2
    //     0x8533e4: add             x2, x2, HEAP, lsl #32
    // 0x8533e8: LoadField: r1 = r2->field_f
    //     0x8533e8: ldur            w1, [x2, #0xf]
    // 0x8533ec: DecompressPointer r1
    //     0x8533ec: add             x1, x1, HEAP, lsl #32
    // 0x8533f0: cmp             w1, NULL
    // 0x8533f4: b.eq            #0x853444
    // 0x8533f8: LoadField: r3 = r2->field_47
    //     0x8533f8: ldur            w3, [x2, #0x47]
    // 0x8533fc: DecompressPointer r3
    //     0x8533fc: add             x3, x3, HEAP, lsl #32
    // 0x853400: stp             x1, x0, [SP, #-0x10]!
    // 0x853404: SaveReg r3
    //     0x853404: str             x3, [SP, #-8]!
    // 0x853408: r0 = writeState()
    //     0x853408: bl              #0x853448  ; [package:flutter/src/widgets/page_storage.dart] PageStorageBucket::writeState
    // 0x85340c: add             SP, SP, #0x18
    // 0x853410: r0 = Null
    //     0x853410: mov             x0, NULL
    // 0x853414: LeaveFrame
    //     0x853414: mov             SP, fp
    //     0x853418: ldp             fp, lr, [SP], #0x10
    // 0x85341c: ret
    //     0x85341c: ret             
    // 0x853420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853420: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853424: b               #0x853314
    // 0x853428: r9 = _controller
    //     0x853428: add             x9, PP, #0x53, lsl #12  ; [pp+0x53188] Field <_ExpansionTileState@739392950._controller@739392950>: late (offset: 0x2c)
    //     0x85342c: ldr             x9, [x9, #0x188]
    // 0x853430: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x853430: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x853434: r9 = _controller
    //     0x853434: add             x9, PP, #0x53, lsl #12  ; [pp+0x53188] Field <_ExpansionTileState@739392950._controller@739392950>: late (offset: 0x2c)
    //     0x853438: ldr             x9, [x9, #0x188]
    // 0x85343c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x85343c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x853440: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x853440: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x853444: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x853444: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x85375c, size: 0x88
    // 0x85375c: EnterFrame
    //     0x85375c: stp             fp, lr, [SP, #-0x10]!
    //     0x853760: mov             fp, SP
    // 0x853764: AllocStack(0x8)
    //     0x853764: sub             SP, SP, #8
    // 0x853768: SetupParameters()
    //     0x853768: ldr             x0, [fp, #0x18]
    //     0x85376c: ldur            w1, [x0, #0x17]
    //     0x853770: add             x1, x1, HEAP, lsl #32
    // 0x853774: CheckStackOverflow
    //     0x853774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x853778: cmp             SP, x16
    //     0x85377c: b.ls            #0x8537dc
    // 0x853780: LoadField: r0 = r1->field_f
    //     0x853780: ldur            w0, [x1, #0xf]
    // 0x853784: DecompressPointer r0
    //     0x853784: add             x0, x0, HEAP, lsl #32
    // 0x853788: stur            x0, [fp, #-8]
    // 0x85378c: LoadField: r1 = r0->field_f
    //     0x85378c: ldur            w1, [x0, #0xf]
    // 0x853790: DecompressPointer r1
    //     0x853790: add             x1, x1, HEAP, lsl #32
    // 0x853794: cmp             w1, NULL
    // 0x853798: b.ne            #0x8537ac
    // 0x85379c: r0 = Null
    //     0x85379c: mov             x0, NULL
    // 0x8537a0: LeaveFrame
    //     0x8537a0: mov             SP, fp
    //     0x8537a4: ldp             fp, lr, [SP], #0x10
    // 0x8537a8: ret
    //     0x8537a8: ret             
    // 0x8537ac: r1 = Function '<anonymous closure>':.
    //     0x8537ac: add             x1, PP, #0x53, lsl #12  ; [pp+0x531e0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x8537b0: ldr             x1, [x1, #0x1e0]
    // 0x8537b4: r2 = Null
    //     0x8537b4: mov             x2, NULL
    // 0x8537b8: r0 = AllocateClosure()
    //     0x8537b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8537bc: ldur            x16, [fp, #-8]
    // 0x8537c0: stp             x0, x16, [SP, #-0x10]!
    // 0x8537c4: r0 = setState()
    //     0x8537c4: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8537c8: add             SP, SP, #0x10
    // 0x8537cc: r0 = Null
    //     0x8537cc: mov             x0, NULL
    // 0x8537d0: LeaveFrame
    //     0x8537d0: mov             SP, fp
    //     0x8537d4: ldp             fp, lr, [SP], #0x10
    // 0x8537d8: ret
    //     0x8537d8: ret             
    // 0x8537dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8537dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8537e0: b               #0x853780
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d9a00, size: 0x3a0
    // 0x9d9a00: EnterFrame
    //     0x9d9a00: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9a04: mov             fp, SP
    // 0x9d9a08: AllocStack(0x20)
    //     0x9d9a08: sub             SP, SP, #0x20
    // 0x9d9a0c: CheckStackOverflow
    //     0x9d9a0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9a10: cmp             SP, x16
    //     0x9d9a14: b.ls            #0x9d9d8c
    // 0x9d9a18: r1 = <double>
    //     0x9d9a18: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d9a1c: r0 = AnimationController()
    //     0x9d9a1c: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d9a20: stur            x0, [fp, #-8]
    // 0x9d9a24: ldr             x16, [fp, #0x10]
    // 0x9d9a28: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9a2c: r16 = Instance_Duration
    //     0x9d9a2c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9d9a30: ldr             x16, [x16, #0x9e0]
    // 0x9d9a34: SaveReg r16
    //     0x9d9a34: str             x16, [SP, #-8]!
    // 0x9d9a38: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9d9a38: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9d9a3c: ldr             x4, [x4, #0xa0]
    // 0x9d9a40: r0 = AnimationController()
    //     0x9d9a40: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d9a44: add             SP, SP, #0x18
    // 0x9d9a48: ldur            x0, [fp, #-8]
    // 0x9d9a4c: ldr             x1, [fp, #0x10]
    // 0x9d9a50: StoreField: r1->field_2b = r0
    //     0x9d9a50: stur            w0, [x1, #0x2b]
    //     0x9d9a54: ldurb           w16, [x1, #-1]
    //     0x9d9a58: ldurb           w17, [x0, #-1]
    //     0x9d9a5c: and             x16, x17, x16, lsr #2
    //     0x9d9a60: tst             x16, HEAP, lsr #32
    //     0x9d9a64: b.eq            #0x9d9a6c
    //     0x9d9a68: bl              #0xd6826c
    // 0x9d9a6c: r0 = InitLateStaticField(0xd84) // [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_easeInTween
    //     0x9d9a6c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9d9a70: ldr             x0, [x0, #0x1b08]
    //     0x9d9a74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9d9a78: cmp             w0, w16
    //     0x9d9a7c: b.ne            #0x9d9a8c
    //     0x9d9a80: add             x2, PP, #0x53, lsl #12  ; [pp+0x53288] Field <_ExpansionTileState@739392950._easeInTween@739392950>: static late final (offset: 0xd84)
    //     0x9d9a84: ldr             x2, [x2, #0x288]
    //     0x9d9a88: bl              #0xd67cdc
    // 0x9d9a8c: stur            x0, [fp, #-0x10]
    // 0x9d9a90: ldur            x16, [fp, #-8]
    // 0x9d9a94: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9a98: r0 = animate()
    //     0x9d9a98: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d9a9c: add             SP, SP, #0x10
    // 0x9d9aa0: ldr             x1, [fp, #0x10]
    // 0x9d9aa4: StoreField: r1->field_33 = r0
    //     0x9d9aa4: stur            w0, [x1, #0x33]
    //     0x9d9aa8: ldurb           w16, [x1, #-1]
    //     0x9d9aac: ldurb           w17, [x0, #-1]
    //     0x9d9ab0: and             x16, x17, x16, lsr #2
    //     0x9d9ab4: tst             x16, HEAP, lsr #32
    //     0x9d9ab8: b.eq            #0x9d9ac0
    //     0x9d9abc: bl              #0xd6826c
    // 0x9d9ac0: LoadField: r0 = r1->field_2b
    //     0x9d9ac0: ldur            w0, [x1, #0x2b]
    // 0x9d9ac4: DecompressPointer r0
    //     0x9d9ac4: add             x0, x0, HEAP, lsl #32
    // 0x9d9ac8: stur            x0, [fp, #-8]
    // 0x9d9acc: r0 = InitLateStaticField(0xd88) // [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_halfTween
    //     0x9d9acc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9d9ad0: ldr             x0, [x0, #0x1b10]
    //     0x9d9ad4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9d9ad8: cmp             w0, w16
    //     0x9d9adc: b.ne            #0x9d9aec
    //     0x9d9ae0: add             x2, PP, #0x53, lsl #12  ; [pp+0x53290] Field <_ExpansionTileState@739392950._halfTween@739392950>: static late final (offset: 0xd88)
    //     0x9d9ae4: ldr             x2, [x2, #0x290]
    //     0x9d9ae8: bl              #0xd67cdc
    // 0x9d9aec: ldur            x16, [fp, #-0x10]
    // 0x9d9af0: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9af4: r0 = chain()
    //     0x9d9af4: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x9d9af8: add             SP, SP, #0x10
    // 0x9d9afc: ldur            x16, [fp, #-8]
    // 0x9d9b00: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9b04: r0 = animate()
    //     0x9d9b04: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d9b08: add             SP, SP, #0x10
    // 0x9d9b0c: ldr             x1, [fp, #0x10]
    // 0x9d9b10: StoreField: r1->field_2f = r0
    //     0x9d9b10: stur            w0, [x1, #0x2f]
    //     0x9d9b14: ldurb           w16, [x1, #-1]
    //     0x9d9b18: ldurb           w17, [x0, #-1]
    //     0x9d9b1c: and             x16, x17, x16, lsr #2
    //     0x9d9b20: tst             x16, HEAP, lsr #32
    //     0x9d9b24: b.eq            #0x9d9b2c
    //     0x9d9b28: bl              #0xd6826c
    // 0x9d9b2c: LoadField: r0 = r1->field_2b
    //     0x9d9b2c: ldur            w0, [x1, #0x2b]
    // 0x9d9b30: DecompressPointer r0
    //     0x9d9b30: add             x0, x0, HEAP, lsl #32
    // 0x9d9b34: stur            x0, [fp, #-0x18]
    // 0x9d9b38: LoadField: r2 = r1->field_1b
    //     0x9d9b38: ldur            w2, [x1, #0x1b]
    // 0x9d9b3c: DecompressPointer r2
    //     0x9d9b3c: add             x2, x2, HEAP, lsl #32
    // 0x9d9b40: stur            x2, [fp, #-8]
    // 0x9d9b44: r0 = InitLateStaticField(0xd80) // [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_easeOutTween
    //     0x9d9b44: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9d9b48: ldr             x0, [x0, #0x1b00]
    //     0x9d9b4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9d9b50: cmp             w0, w16
    //     0x9d9b54: b.ne            #0x9d9b64
    //     0x9d9b58: add             x2, PP, #0x53, lsl #12  ; [pp+0x53298] Field <_ExpansionTileState@739392950._easeOutTween@739392950>: static late final (offset: 0xd80)
    //     0x9d9b5c: ldr             x2, [x2, #0x298]
    //     0x9d9b60: bl              #0xd67cdc
    // 0x9d9b64: stur            x0, [fp, #-0x20]
    // 0x9d9b68: ldur            x16, [fp, #-8]
    // 0x9d9b6c: stp             x0, x16, [SP, #-0x10]!
    // 0x9d9b70: r0 = chain()
    //     0x9d9b70: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x9d9b74: add             SP, SP, #0x10
    // 0x9d9b78: ldur            x16, [fp, #-0x18]
    // 0x9d9b7c: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9b80: r0 = animate()
    //     0x9d9b80: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d9b84: add             SP, SP, #0x10
    // 0x9d9b88: ldr             x1, [fp, #0x10]
    // 0x9d9b8c: StoreField: r1->field_37 = r0
    //     0x9d9b8c: stur            w0, [x1, #0x37]
    //     0x9d9b90: ldurb           w16, [x1, #-1]
    //     0x9d9b94: ldurb           w17, [x0, #-1]
    //     0x9d9b98: and             x16, x17, x16, lsr #2
    //     0x9d9b9c: tst             x16, HEAP, lsr #32
    //     0x9d9ba0: b.eq            #0x9d9ba8
    //     0x9d9ba4: bl              #0xd6826c
    // 0x9d9ba8: LoadField: r0 = r1->field_2b
    //     0x9d9ba8: ldur            w0, [x1, #0x2b]
    // 0x9d9bac: DecompressPointer r0
    //     0x9d9bac: add             x0, x0, HEAP, lsl #32
    // 0x9d9bb0: stur            x0, [fp, #-8]
    // 0x9d9bb4: LoadField: r2 = r1->field_1f
    //     0x9d9bb4: ldur            w2, [x1, #0x1f]
    // 0x9d9bb8: DecompressPointer r2
    //     0x9d9bb8: add             x2, x2, HEAP, lsl #32
    // 0x9d9bbc: ldur            x16, [fp, #-0x10]
    // 0x9d9bc0: stp             x16, x2, [SP, #-0x10]!
    // 0x9d9bc4: r0 = chain()
    //     0x9d9bc4: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x9d9bc8: add             SP, SP, #0x10
    // 0x9d9bcc: ldur            x16, [fp, #-8]
    // 0x9d9bd0: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9bd4: r0 = animate()
    //     0x9d9bd4: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d9bd8: add             SP, SP, #0x10
    // 0x9d9bdc: ldr             x1, [fp, #0x10]
    // 0x9d9be0: StoreField: r1->field_3b = r0
    //     0x9d9be0: stur            w0, [x1, #0x3b]
    //     0x9d9be4: ldurb           w16, [x1, #-1]
    //     0x9d9be8: ldurb           w17, [x0, #-1]
    //     0x9d9bec: and             x16, x17, x16, lsr #2
    //     0x9d9bf0: tst             x16, HEAP, lsr #32
    //     0x9d9bf4: b.eq            #0x9d9bfc
    //     0x9d9bf8: bl              #0xd6826c
    // 0x9d9bfc: LoadField: r0 = r1->field_2b
    //     0x9d9bfc: ldur            w0, [x1, #0x2b]
    // 0x9d9c00: DecompressPointer r0
    //     0x9d9c00: add             x0, x0, HEAP, lsl #32
    // 0x9d9c04: stur            x0, [fp, #-8]
    // 0x9d9c08: LoadField: r2 = r1->field_23
    //     0x9d9c08: ldur            w2, [x1, #0x23]
    // 0x9d9c0c: DecompressPointer r2
    //     0x9d9c0c: add             x2, x2, HEAP, lsl #32
    // 0x9d9c10: ldur            x16, [fp, #-0x10]
    // 0x9d9c14: stp             x16, x2, [SP, #-0x10]!
    // 0x9d9c18: r0 = chain()
    //     0x9d9c18: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x9d9c1c: add             SP, SP, #0x10
    // 0x9d9c20: ldur            x16, [fp, #-8]
    // 0x9d9c24: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9c28: r0 = animate()
    //     0x9d9c28: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d9c2c: add             SP, SP, #0x10
    // 0x9d9c30: ldr             x1, [fp, #0x10]
    // 0x9d9c34: StoreField: r1->field_3f = r0
    //     0x9d9c34: stur            w0, [x1, #0x3f]
    //     0x9d9c38: ldurb           w16, [x1, #-1]
    //     0x9d9c3c: ldurb           w17, [x0, #-1]
    //     0x9d9c40: and             x16, x17, x16, lsr #2
    //     0x9d9c44: tst             x16, HEAP, lsr #32
    //     0x9d9c48: b.eq            #0x9d9c50
    //     0x9d9c4c: bl              #0xd6826c
    // 0x9d9c50: LoadField: r0 = r1->field_2b
    //     0x9d9c50: ldur            w0, [x1, #0x2b]
    // 0x9d9c54: DecompressPointer r0
    //     0x9d9c54: add             x0, x0, HEAP, lsl #32
    // 0x9d9c58: stur            x0, [fp, #-8]
    // 0x9d9c5c: LoadField: r2 = r1->field_27
    //     0x9d9c5c: ldur            w2, [x1, #0x27]
    // 0x9d9c60: DecompressPointer r2
    //     0x9d9c60: add             x2, x2, HEAP, lsl #32
    // 0x9d9c64: ldur            x16, [fp, #-0x20]
    // 0x9d9c68: stp             x16, x2, [SP, #-0x10]!
    // 0x9d9c6c: r0 = chain()
    //     0x9d9c6c: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x9d9c70: add             SP, SP, #0x10
    // 0x9d9c74: ldur            x16, [fp, #-8]
    // 0x9d9c78: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9c7c: r0 = animate()
    //     0x9d9c7c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d9c80: add             SP, SP, #0x10
    // 0x9d9c84: ldr             x1, [fp, #0x10]
    // 0x9d9c88: StoreField: r1->field_43 = r0
    //     0x9d9c88: stur            w0, [x1, #0x43]
    //     0x9d9c8c: ldurb           w16, [x1, #-1]
    //     0x9d9c90: ldurb           w17, [x0, #-1]
    //     0x9d9c94: and             x16, x17, x16, lsr #2
    //     0x9d9c98: tst             x16, HEAP, lsr #32
    //     0x9d9c9c: b.eq            #0x9d9ca4
    //     0x9d9ca0: bl              #0xd6826c
    // 0x9d9ca4: LoadField: r0 = r1->field_f
    //     0x9d9ca4: ldur            w0, [x1, #0xf]
    // 0x9d9ca8: DecompressPointer r0
    //     0x9d9ca8: add             x0, x0, HEAP, lsl #32
    // 0x9d9cac: cmp             w0, NULL
    // 0x9d9cb0: b.eq            #0x9d9d94
    // 0x9d9cb4: SaveReg r0
    //     0x9d9cb4: str             x0, [SP, #-8]!
    // 0x9d9cb8: r0 = maybeOf()
    //     0x9d9cb8: bl              #0x8536fc  ; [package:flutter/src/widgets/page_storage.dart] PageStorage::maybeOf
    // 0x9d9cbc: add             SP, SP, #8
    // 0x9d9cc0: cmp             w0, NULL
    // 0x9d9cc4: b.ne            #0x9d9cd0
    // 0x9d9cc8: r3 = Null
    //     0x9d9cc8: mov             x3, NULL
    // 0x9d9ccc: b               #0x9d9cf4
    // 0x9d9cd0: ldr             x1, [fp, #0x10]
    // 0x9d9cd4: LoadField: r2 = r1->field_f
    //     0x9d9cd4: ldur            w2, [x1, #0xf]
    // 0x9d9cd8: DecompressPointer r2
    //     0x9d9cd8: add             x2, x2, HEAP, lsl #32
    // 0x9d9cdc: cmp             w2, NULL
    // 0x9d9ce0: b.eq            #0x9d9d98
    // 0x9d9ce4: stp             x2, x0, [SP, #-0x10]!
    // 0x9d9ce8: r0 = readState()
    //     0x9d9ce8: bl              #0x9d9da0  ; [package:flutter/src/widgets/page_storage.dart] PageStorageBucket::readState
    // 0x9d9cec: add             SP, SP, #0x10
    // 0x9d9cf0: mov             x3, x0
    // 0x9d9cf4: mov             x0, x3
    // 0x9d9cf8: stur            x3, [fp, #-8]
    // 0x9d9cfc: r2 = Null
    //     0x9d9cfc: mov             x2, NULL
    // 0x9d9d00: r1 = Null
    //     0x9d9d00: mov             x1, NULL
    // 0x9d9d04: r4 = 59
    //     0x9d9d04: mov             x4, #0x3b
    // 0x9d9d08: branchIfSmi(r0, 0x9d9d14)
    //     0x9d9d08: tbz             w0, #0, #0x9d9d14
    // 0x9d9d0c: r4 = LoadClassIdInstr(r0)
    //     0x9d9d0c: ldur            x4, [x0, #-1]
    //     0x9d9d10: ubfx            x4, x4, #0xc, #0x14
    // 0x9d9d14: cmp             x4, #0x3e
    // 0x9d9d18: b.eq            #0x9d9d2c
    // 0x9d9d1c: r8 = bool?
    //     0x9d9d1c: ldr             x8, [PP, #0x20f0]  ; [pp+0x20f0] Type: bool?
    // 0x9d9d20: r3 = Null
    //     0x9d9d20: add             x3, PP, #0x53, lsl #12  ; [pp+0x532a0] Null
    //     0x9d9d24: ldr             x3, [x3, #0x2a0]
    // 0x9d9d28: r0 = bool?()
    //     0x9d9d28: bl              #0x4e1de0  ; IsType_bool?_Stub
    // 0x9d9d2c: ldur            x0, [fp, #-8]
    // 0x9d9d30: cmp             w0, NULL
    // 0x9d9d34: b.ne            #0x9d9d54
    // 0x9d9d38: ldr             x1, [fp, #0x10]
    // 0x9d9d3c: LoadField: r0 = r1->field_b
    //     0x9d9d3c: ldur            w0, [x1, #0xb]
    // 0x9d9d40: DecompressPointer r0
    //     0x9d9d40: add             x0, x0, HEAP, lsl #32
    // 0x9d9d44: cmp             w0, NULL
    // 0x9d9d48: b.eq            #0x9d9d9c
    // 0x9d9d4c: r0 = false
    //     0x9d9d4c: add             x0, NULL, #0x30  ; false
    // 0x9d9d50: b               #0x9d9d58
    // 0x9d9d54: ldr             x1, [fp, #0x10]
    // 0x9d9d58: StoreField: r1->field_47 = r0
    //     0x9d9d58: stur            w0, [x1, #0x47]
    // 0x9d9d5c: tbnz            w0, #4, #0x9d9d7c
    // 0x9d9d60: d0 = 1.000000
    //     0x9d9d60: fmov            d0, #1.00000000
    // 0x9d9d64: LoadField: r0 = r1->field_2b
    //     0x9d9d64: ldur            w0, [x1, #0x2b]
    // 0x9d9d68: DecompressPointer r0
    //     0x9d9d68: add             x0, x0, HEAP, lsl #32
    // 0x9d9d6c: SaveReg r0
    //     0x9d9d6c: str             x0, [SP, #-8]!
    // 0x9d9d70: SaveReg d0
    //     0x9d9d70: str             d0, [SP, #-8]!
    // 0x9d9d74: r0 = value=()
    //     0x9d9d74: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x9d9d78: add             SP, SP, #0x10
    // 0x9d9d7c: r0 = Null
    //     0x9d9d7c: mov             x0, NULL
    // 0x9d9d80: LeaveFrame
    //     0x9d9d80: mov             SP, fp
    //     0x9d9d84: ldp             fp, lr, [SP], #0x10
    // 0x9d9d88: ret
    //     0x9d9d88: ret             
    // 0x9d9d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d9d8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d9d90: b               #0x9d9a18
    // 0x9d9d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d9d94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d9d98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d9d98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d9d9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d9d9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Animatable<double> _easeOutTween() {
    // ** addr: 0x9d9e68, size: 0x28
    // 0x9d9e68: EnterFrame
    //     0x9d9e68: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9e6c: mov             fp, SP
    // 0x9d9e70: r1 = <double>
    //     0x9d9e70: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d9e74: r0 = CurveTween()
    //     0x9d9e74: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x9d9e78: r1 = Instance_Cubic
    //     0x9d9e78: add             x1, PP, #0x20, lsl #12  ; [pp+0x20970] Obj!Cubic<double>@b4f3a1
    //     0x9d9e7c: ldr             x1, [x1, #0x970]
    // 0x9d9e80: StoreField: r0->field_b = r1
    //     0x9d9e80: stur            w1, [x0, #0xb]
    // 0x9d9e84: LeaveFrame
    //     0x9d9e84: mov             SP, fp
    //     0x9d9e88: ldp             fp, lr, [SP], #0x10
    // 0x9d9e8c: ret
    //     0x9d9e8c: ret             
  }
  static Animatable<double> _halfTween() {
    // ** addr: 0x9d9e90, size: 0x30
    // 0x9d9e90: EnterFrame
    //     0x9d9e90: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9e94: mov             fp, SP
    // 0x9d9e98: r1 = <double>
    //     0x9d9e98: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d9e9c: r0 = Tween()
    //     0x9d9e9c: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x9d9ea0: r1 = 0.000000
    //     0x9d9ea0: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x9d9ea4: StoreField: r0->field_b = r1
    //     0x9d9ea4: stur            w1, [x0, #0xb]
    // 0x9d9ea8: r1 = 0.500000
    //     0x9d9ea8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c760] 0.5
    //     0x9d9eac: ldr             x1, [x1, #0x760]
    // 0x9d9eb0: StoreField: r0->field_f = r1
    //     0x9d9eb0: stur            w1, [x0, #0xf]
    // 0x9d9eb4: LeaveFrame
    //     0x9d9eb4: mov             SP, fp
    //     0x9d9eb8: ldp             fp, lr, [SP], #0x10
    // 0x9d9ebc: ret
    //     0x9d9ebc: ret             
  }
  static Animatable<double> _easeInTween() {
    // ** addr: 0x9d9ec0, size: 0x28
    // 0x9d9ec0: EnterFrame
    //     0x9d9ec0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9ec4: mov             fp, SP
    // 0x9d9ec8: r1 = <double>
    //     0x9d9ec8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d9ecc: r0 = CurveTween()
    //     0x9d9ecc: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x9d9ed0: r1 = Instance_Cubic
    //     0x9d9ed0: add             x1, PP, #0x27, lsl #12  ; [pp+0x27110] Obj!Cubic<double>@b4f431
    //     0x9d9ed4: ldr             x1, [x1, #0x110]
    // 0x9d9ed8: StoreField: r0->field_b = r1
    //     0x9d9ed8: stur            w1, [x0, #0xb]
    // 0x9d9edc: LeaveFrame
    //     0x9d9edc: mov             SP, fp
    //     0x9d9ee0: ldp             fp, lr, [SP], #0x10
    // 0x9d9ee4: ret
    //     0x9d9ee4: ret             
  }
  _ _ExpansionTileState(/* No info */) {
    // ** addr: 0xa40514, size: 0xf4
    // 0xa40514: EnterFrame
    //     0xa40514: stp             fp, lr, [SP, #-0x10]!
    //     0xa40518: mov             fp, SP
    // 0xa4051c: r1 = Sentinel
    //     0xa4051c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40520: r0 = false
    //     0xa40520: add             x0, NULL, #0x30  ; false
    // 0xa40524: ldr             x2, [fp, #0x10]
    // 0xa40528: StoreField: r2->field_2b = r1
    //     0xa40528: stur            w1, [x2, #0x2b]
    // 0xa4052c: StoreField: r2->field_2f = r1
    //     0xa4052c: stur            w1, [x2, #0x2f]
    // 0xa40530: StoreField: r2->field_33 = r1
    //     0xa40530: stur            w1, [x2, #0x33]
    // 0xa40534: StoreField: r2->field_37 = r1
    //     0xa40534: stur            w1, [x2, #0x37]
    // 0xa40538: StoreField: r2->field_3b = r1
    //     0xa40538: stur            w1, [x2, #0x3b]
    // 0xa4053c: StoreField: r2->field_3f = r1
    //     0xa4053c: stur            w1, [x2, #0x3f]
    // 0xa40540: StoreField: r2->field_43 = r1
    //     0xa40540: stur            w1, [x2, #0x43]
    // 0xa40544: StoreField: r2->field_47 = r0
    //     0xa40544: stur            w0, [x2, #0x47]
    // 0xa40548: r1 = <ShapeBorder?>
    //     0xa40548: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a40] TypeArguments: <ShapeBorder?>
    //     0xa4054c: ldr             x1, [x1, #0xa40]
    // 0xa40550: r0 = ShapeBorderTween()
    //     0xa40550: bl              #0xa40608  ; AllocateShapeBorderTweenStub -> ShapeBorderTween (size=0x14)
    // 0xa40554: ldr             x2, [fp, #0x10]
    // 0xa40558: StoreField: r2->field_1b = r0
    //     0xa40558: stur            w0, [x2, #0x1b]
    //     0xa4055c: ldurb           w16, [x2, #-1]
    //     0xa40560: ldurb           w17, [x0, #-1]
    //     0xa40564: and             x16, x17, x16, lsr #2
    //     0xa40568: tst             x16, HEAP, lsr #32
    //     0xa4056c: b.eq            #0xa40574
    //     0xa40570: bl              #0xd6828c
    // 0xa40574: r1 = <Color?>
    //     0xa40574: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xa40578: ldr             x1, [x1, #0xf68]
    // 0xa4057c: r0 = ColorTween()
    //     0xa4057c: bl              #0x66c528  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xa40580: ldr             x2, [fp, #0x10]
    // 0xa40584: StoreField: r2->field_1f = r0
    //     0xa40584: stur            w0, [x2, #0x1f]
    //     0xa40588: ldurb           w16, [x2, #-1]
    //     0xa4058c: ldurb           w17, [x0, #-1]
    //     0xa40590: and             x16, x17, x16, lsr #2
    //     0xa40594: tst             x16, HEAP, lsr #32
    //     0xa40598: b.eq            #0xa405a0
    //     0xa4059c: bl              #0xd6828c
    // 0xa405a0: r1 = <Color?>
    //     0xa405a0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xa405a4: ldr             x1, [x1, #0xf68]
    // 0xa405a8: r0 = ColorTween()
    //     0xa405a8: bl              #0x66c528  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xa405ac: ldr             x2, [fp, #0x10]
    // 0xa405b0: StoreField: r2->field_23 = r0
    //     0xa405b0: stur            w0, [x2, #0x23]
    //     0xa405b4: ldurb           w16, [x2, #-1]
    //     0xa405b8: ldurb           w17, [x0, #-1]
    //     0xa405bc: and             x16, x17, x16, lsr #2
    //     0xa405c0: tst             x16, HEAP, lsr #32
    //     0xa405c4: b.eq            #0xa405cc
    //     0xa405c8: bl              #0xd6828c
    // 0xa405cc: r1 = <Color?>
    //     0xa405cc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xa405d0: ldr             x1, [x1, #0xf68]
    // 0xa405d4: r0 = ColorTween()
    //     0xa405d4: bl              #0x66c528  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xa405d8: ldr             x1, [fp, #0x10]
    // 0xa405dc: StoreField: r1->field_27 = r0
    //     0xa405dc: stur            w0, [x1, #0x27]
    //     0xa405e0: ldurb           w16, [x1, #-1]
    //     0xa405e4: ldurb           w17, [x0, #-1]
    //     0xa405e8: and             x16, x17, x16, lsr #2
    //     0xa405ec: tst             x16, HEAP, lsr #32
    //     0xa405f0: b.eq            #0xa405f8
    //     0xa405f4: bl              #0xd6826c
    // 0xa405f8: r0 = Null
    //     0xa405f8: mov             x0, NULL
    // 0xa405fc: LeaveFrame
    //     0xa405fc: mov             SP, fp
    //     0xa40600: ldp             fp, lr, [SP], #0x10
    // 0xa40604: ret
    //     0xa40604: ret             
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4ab88, size: 0x18
    // 0xa4ab88: r4 = 7
    //     0xa4ab88: mov             x4, #7
    // 0xa4ab8c: r1 = Function 'dispose':.
    //     0xa4ab8c: add             x17, PP, #0x53, lsl #12  ; [pp+0x53178] AnonymousClosure: (0xa4aba0), in [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::dispose (0xa515c0)
    //     0xa4ab90: ldr             x1, [x17, #0x178]
    // 0xa4ab94: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4ab94: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4ab98: LoadField: r0 = r24->field_17
    //     0xa4ab98: ldur            x0, [x24, #0x17]
    // 0xa4ab9c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4aba0, size: 0x48
    // 0xa4aba0: EnterFrame
    //     0xa4aba0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4aba4: mov             fp, SP
    // 0xa4aba8: ldr             x0, [fp, #0x10]
    // 0xa4abac: LoadField: r1 = r0->field_17
    //     0xa4abac: ldur            w1, [x0, #0x17]
    // 0xa4abb0: DecompressPointer r1
    //     0xa4abb0: add             x1, x1, HEAP, lsl #32
    // 0xa4abb4: CheckStackOverflow
    //     0xa4abb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4abb8: cmp             SP, x16
    //     0xa4abbc: b.ls            #0xa4abe0
    // 0xa4abc0: LoadField: r0 = r1->field_f
    //     0xa4abc0: ldur            w0, [x1, #0xf]
    // 0xa4abc4: DecompressPointer r0
    //     0xa4abc4: add             x0, x0, HEAP, lsl #32
    // 0xa4abc8: SaveReg r0
    //     0xa4abc8: str             x0, [SP, #-8]!
    // 0xa4abcc: r0 = dispose()
    //     0xa4abcc: bl              #0xa515c0  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::dispose
    // 0xa4abd0: add             SP, SP, #8
    // 0xa4abd4: LeaveFrame
    //     0xa4abd4: mov             SP, fp
    //     0xa4abd8: ldp             fp, lr, [SP], #0x10
    // 0xa4abdc: ret
    //     0xa4abdc: ret             
    // 0xa4abe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4abe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4abe4: b               #0xa4abc0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa515c0, size: 0x6c
    // 0xa515c0: EnterFrame
    //     0xa515c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa515c4: mov             fp, SP
    // 0xa515c8: CheckStackOverflow
    //     0xa515c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa515cc: cmp             SP, x16
    //     0xa515d0: b.ls            #0xa51618
    // 0xa515d4: ldr             x0, [fp, #0x10]
    // 0xa515d8: LoadField: r1 = r0->field_2b
    //     0xa515d8: ldur            w1, [x0, #0x2b]
    // 0xa515dc: DecompressPointer r1
    //     0xa515dc: add             x1, x1, HEAP, lsl #32
    // 0xa515e0: r16 = Sentinel
    //     0xa515e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa515e4: cmp             w1, w16
    // 0xa515e8: b.eq            #0xa51620
    // 0xa515ec: SaveReg r1
    //     0xa515ec: str             x1, [SP, #-8]!
    // 0xa515f0: r0 = dispose()
    //     0xa515f0: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa515f4: add             SP, SP, #8
    // 0xa515f8: ldr             x16, [fp, #0x10]
    // 0xa515fc: SaveReg r16
    //     0xa515fc: str             x16, [SP, #-8]!
    // 0xa51600: r0 = dispose()
    //     0xa51600: bl              #0xa5162c  ; [package:flutter/src/material/expansion_tile.dart] __ExpansionTileState&State&SingleTickerProviderStateMixin::dispose
    // 0xa51604: add             SP, SP, #8
    // 0xa51608: r0 = Null
    //     0xa51608: mov             x0, NULL
    // 0xa5160c: LeaveFrame
    //     0xa5160c: mov             SP, fp
    //     0xa51610: ldp             fp, lr, [SP], #0x10
    // 0xa51614: ret
    //     0xa51614: ret             
    // 0xa51618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa51618: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5161c: b               #0xa515d4
    // 0xa51620: r9 = _controller
    //     0xa51620: add             x9, PP, #0x53, lsl #12  ; [pp+0x53188] Field <_ExpansionTileState@739392950._controller@739392950>: late (offset: 0x2c)
    //     0xa51624: ldr             x9, [x9, #0x188]
    // 0xa51628: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa51628: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa611c0, size: 0x450
    // 0xa611c0: EnterFrame
    //     0xa611c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa611c4: mov             fp, SP
    // 0xa611c8: AllocStack(0x38)
    //     0xa611c8: sub             SP, SP, #0x38
    // 0xa611cc: CheckStackOverflow
    //     0xa611cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa611d0: cmp             SP, x16
    //     0xa611d4: b.ls            #0xa615f8
    // 0xa611d8: ldr             x0, [fp, #0x10]
    // 0xa611dc: LoadField: r1 = r0->field_f
    //     0xa611dc: ldur            w1, [x0, #0xf]
    // 0xa611e0: DecompressPointer r1
    //     0xa611e0: add             x1, x1, HEAP, lsl #32
    // 0xa611e4: cmp             w1, NULL
    // 0xa611e8: b.eq            #0xa61600
    // 0xa611ec: SaveReg r1
    //     0xa611ec: str             x1, [SP, #-8]!
    // 0xa611f0: r0 = of()
    //     0xa611f0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xa611f4: add             SP, SP, #8
    // 0xa611f8: mov             x1, x0
    // 0xa611fc: ldr             x0, [fp, #0x10]
    // 0xa61200: stur            x1, [fp, #-8]
    // 0xa61204: LoadField: r2 = r0->field_f
    //     0xa61204: ldur            w2, [x0, #0xf]
    // 0xa61208: DecompressPointer r2
    //     0xa61208: add             x2, x2, HEAP, lsl #32
    // 0xa6120c: cmp             w2, NULL
    // 0xa61210: b.eq            #0xa61604
    // 0xa61214: SaveReg r2
    //     0xa61214: str             x2, [SP, #-8]!
    // 0xa61218: r0 = of()
    //     0xa61218: bl              #0x8528c8  ; [package:flutter/src/material/expansion_tile_theme.dart] ExpansionTileTheme::of
    // 0xa6121c: add             SP, SP, #8
    // 0xa61220: ldur            x3, [fp, #-8]
    // 0xa61224: LoadField: r4 = r3->field_3f
    //     0xa61224: ldur            w4, [x3, #0x3f]
    // 0xa61228: DecompressPointer r4
    //     0xa61228: add             x4, x4, HEAP, lsl #32
    // 0xa6122c: ldr             x5, [fp, #0x10]
    // 0xa61230: stur            x4, [fp, #-0x20]
    // 0xa61234: LoadField: r6 = r5->field_1b
    //     0xa61234: ldur            w6, [x5, #0x1b]
    // 0xa61238: DecompressPointer r6
    //     0xa61238: add             x6, x6, HEAP, lsl #32
    // 0xa6123c: stur            x6, [fp, #-0x18]
    // 0xa61240: LoadField: r0 = r5->field_b
    //     0xa61240: ldur            w0, [x5, #0xb]
    // 0xa61244: DecompressPointer r0
    //     0xa61244: add             x0, x0, HEAP, lsl #32
    // 0xa61248: cmp             w0, NULL
    // 0xa6124c: b.eq            #0xa61608
    // 0xa61250: LoadField: r7 = r6->field_7
    //     0xa61250: ldur            w7, [x6, #7]
    // 0xa61254: DecompressPointer r7
    //     0xa61254: add             x7, x7, HEAP, lsl #32
    // 0xa61258: mov             x2, x7
    // 0xa6125c: stur            x7, [fp, #-0x10]
    // 0xa61260: r0 = Instance_Border
    //     0xa61260: add             x0, PP, #0x53, lsl #12  ; [pp+0x53190] Obj!Border@b38491
    //     0xa61264: ldr             x0, [x0, #0x190]
    // 0xa61268: r1 = Null
    //     0xa61268: mov             x1, NULL
    // 0xa6126c: cmp             w0, NULL
    // 0xa61270: b.eq            #0xa61298
    // 0xa61274: cmp             w2, NULL
    // 0xa61278: b.eq            #0xa61298
    // 0xa6127c: LoadField: r4 = r2->field_17
    //     0xa6127c: ldur            w4, [x2, #0x17]
    // 0xa61280: DecompressPointer r4
    //     0xa61280: add             x4, x4, HEAP, lsl #32
    // 0xa61284: r8 = X0?
    //     0xa61284: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xa61288: LoadField: r9 = r4->field_7
    //     0xa61288: ldur            x9, [x4, #7]
    // 0xa6128c: r3 = Null
    //     0xa6128c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53218] Null
    //     0xa61290: ldr             x3, [x3, #0x218]
    // 0xa61294: blr             x9
    // 0xa61298: ldur            x0, [fp, #-0x18]
    // 0xa6129c: r1 = Instance_Border
    //     0xa6129c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53190] Obj!Border@b38491
    //     0xa612a0: ldr             x1, [x1, #0x190]
    // 0xa612a4: StoreField: r0->field_b = r1
    //     0xa612a4: stur            w1, [x0, #0xb]
    // 0xa612a8: ldur            x1, [fp, #-8]
    // 0xa612ac: LoadField: r2 = r1->field_4b
    //     0xa612ac: ldur            w2, [x1, #0x4b]
    // 0xa612b0: DecompressPointer r2
    //     0xa612b0: add             x2, x2, HEAP, lsl #32
    // 0xa612b4: stur            x2, [fp, #-0x28]
    // 0xa612b8: r0 = BorderSide()
    //     0xa612b8: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xa612bc: mov             x1, x0
    // 0xa612c0: ldur            x0, [fp, #-0x28]
    // 0xa612c4: stur            x1, [fp, #-0x30]
    // 0xa612c8: StoreField: r1->field_7 = r0
    //     0xa612c8: stur            w0, [x1, #7]
    // 0xa612cc: d0 = 1.000000
    //     0xa612cc: fmov            d0, #1.00000000
    // 0xa612d0: StoreField: r1->field_b = d0
    //     0xa612d0: stur            d0, [x1, #0xb]
    // 0xa612d4: r2 = Instance_BorderStyle
    //     0xa612d4: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0xa612d8: ldr             x2, [x2, #0xbd0]
    // 0xa612dc: StoreField: r1->field_13 = r2
    //     0xa612dc: stur            w2, [x1, #0x13]
    // 0xa612e0: d1 = -1.000000
    //     0xa612e0: fmov            d1, #-1.00000000
    // 0xa612e4: StoreField: r1->field_17 = d1
    //     0xa612e4: stur            d1, [x1, #0x17]
    // 0xa612e8: r0 = BorderSide()
    //     0xa612e8: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xa612ec: mov             x1, x0
    // 0xa612f0: ldur            x0, [fp, #-0x28]
    // 0xa612f4: stur            x1, [fp, #-0x38]
    // 0xa612f8: StoreField: r1->field_7 = r0
    //     0xa612f8: stur            w0, [x1, #7]
    // 0xa612fc: d0 = 1.000000
    //     0xa612fc: fmov            d0, #1.00000000
    // 0xa61300: StoreField: r1->field_b = d0
    //     0xa61300: stur            d0, [x1, #0xb]
    // 0xa61304: r0 = Instance_BorderStyle
    //     0xa61304: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0xa61308: ldr             x0, [x0, #0xbd0]
    // 0xa6130c: StoreField: r1->field_13 = r0
    //     0xa6130c: stur            w0, [x1, #0x13]
    // 0xa61310: d0 = -1.000000
    //     0xa61310: fmov            d0, #-1.00000000
    // 0xa61314: StoreField: r1->field_17 = d0
    //     0xa61314: stur            d0, [x1, #0x17]
    // 0xa61318: r0 = Border()
    //     0xa61318: bl              #0x70e0c8  ; AllocateBorderStub -> Border (size=0x18)
    // 0xa6131c: mov             x3, x0
    // 0xa61320: ldur            x0, [fp, #-0x30]
    // 0xa61324: stur            x3, [fp, #-0x28]
    // 0xa61328: StoreField: r3->field_7 = r0
    //     0xa61328: stur            w0, [x3, #7]
    // 0xa6132c: r0 = Instance_BorderSide
    //     0xa6132c: add             x0, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xa61330: ldr             x0, [x0, #0x2f0]
    // 0xa61334: StoreField: r3->field_b = r0
    //     0xa61334: stur            w0, [x3, #0xb]
    // 0xa61338: ldur            x1, [fp, #-0x38]
    // 0xa6133c: StoreField: r3->field_f = r1
    //     0xa6133c: stur            w1, [x3, #0xf]
    // 0xa61340: StoreField: r3->field_13 = r0
    //     0xa61340: stur            w0, [x3, #0x13]
    // 0xa61344: mov             x0, x3
    // 0xa61348: ldur            x2, [fp, #-0x10]
    // 0xa6134c: r1 = Null
    //     0xa6134c: mov             x1, NULL
    // 0xa61350: cmp             w0, NULL
    // 0xa61354: b.eq            #0xa6137c
    // 0xa61358: cmp             w2, NULL
    // 0xa6135c: b.eq            #0xa6137c
    // 0xa61360: LoadField: r4 = r2->field_17
    //     0xa61360: ldur            w4, [x2, #0x17]
    // 0xa61364: DecompressPointer r4
    //     0xa61364: add             x4, x4, HEAP, lsl #32
    // 0xa61368: r8 = X0?
    //     0xa61368: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xa6136c: LoadField: r9 = r4->field_7
    //     0xa6136c: ldur            x9, [x4, #7]
    // 0xa61370: r3 = Null
    //     0xa61370: add             x3, PP, #0x53, lsl #12  ; [pp+0x53228] Null
    //     0xa61374: ldr             x3, [x3, #0x228]
    // 0xa61378: blr             x9
    // 0xa6137c: ldur            x0, [fp, #-0x28]
    // 0xa61380: ldur            x1, [fp, #-0x18]
    // 0xa61384: StoreField: r1->field_f = r0
    //     0xa61384: stur            w0, [x1, #0xf]
    //     0xa61388: ldurb           w16, [x1, #-1]
    //     0xa6138c: ldurb           w17, [x0, #-1]
    //     0xa61390: and             x16, x17, x16, lsr #2
    //     0xa61394: tst             x16, HEAP, lsr #32
    //     0xa61398: b.eq            #0xa613a0
    //     0xa6139c: bl              #0xd6826c
    // 0xa613a0: ldr             x3, [fp, #0x10]
    // 0xa613a4: LoadField: r4 = r3->field_1f
    //     0xa613a4: ldur            w4, [x3, #0x1f]
    // 0xa613a8: DecompressPointer r4
    //     0xa613a8: add             x4, x4, HEAP, lsl #32
    // 0xa613ac: ldur            x5, [fp, #-8]
    // 0xa613b0: stur            x4, [fp, #-0x28]
    // 0xa613b4: LoadField: r0 = r5->field_93
    //     0xa613b4: ldur            w0, [x5, #0x93]
    // 0xa613b8: DecompressPointer r0
    //     0xa613b8: add             x0, x0, HEAP, lsl #32
    // 0xa613bc: LoadField: r1 = r0->field_23
    //     0xa613bc: ldur            w1, [x0, #0x23]
    // 0xa613c0: DecompressPointer r1
    //     0xa613c0: add             x1, x1, HEAP, lsl #32
    // 0xa613c4: cmp             w1, NULL
    // 0xa613c8: b.eq            #0xa6160c
    // 0xa613cc: LoadField: r6 = r1->field_b
    //     0xa613cc: ldur            w6, [x1, #0xb]
    // 0xa613d0: DecompressPointer r6
    //     0xa613d0: add             x6, x6, HEAP, lsl #32
    // 0xa613d4: stur            x6, [fp, #-0x18]
    // 0xa613d8: LoadField: r7 = r4->field_7
    //     0xa613d8: ldur            w7, [x4, #7]
    // 0xa613dc: DecompressPointer r7
    //     0xa613dc: add             x7, x7, HEAP, lsl #32
    // 0xa613e0: mov             x0, x6
    // 0xa613e4: mov             x2, x7
    // 0xa613e8: stur            x7, [fp, #-0x10]
    // 0xa613ec: r1 = Null
    //     0xa613ec: mov             x1, NULL
    // 0xa613f0: cmp             w0, NULL
    // 0xa613f4: b.eq            #0xa6141c
    // 0xa613f8: cmp             w2, NULL
    // 0xa613fc: b.eq            #0xa6141c
    // 0xa61400: LoadField: r4 = r2->field_17
    //     0xa61400: ldur            w4, [x2, #0x17]
    // 0xa61404: DecompressPointer r4
    //     0xa61404: add             x4, x4, HEAP, lsl #32
    // 0xa61408: r8 = X0?
    //     0xa61408: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xa6140c: LoadField: r9 = r4->field_7
    //     0xa6140c: ldur            x9, [x4, #7]
    // 0xa61410: r3 = Null
    //     0xa61410: add             x3, PP, #0x53, lsl #12  ; [pp+0x53238] Null
    //     0xa61414: ldr             x3, [x3, #0x238]
    // 0xa61418: blr             x9
    // 0xa6141c: ldur            x0, [fp, #-0x18]
    // 0xa61420: ldur            x3, [fp, #-0x28]
    // 0xa61424: StoreField: r3->field_b = r0
    //     0xa61424: stur            w0, [x3, #0xb]
    //     0xa61428: ldurb           w16, [x3, #-1]
    //     0xa6142c: ldurb           w17, [x0, #-1]
    //     0xa61430: and             x16, x17, x16, lsr #2
    //     0xa61434: tst             x16, HEAP, lsr #32
    //     0xa61438: b.eq            #0xa61440
    //     0xa6143c: bl              #0xd682ac
    // 0xa61440: ldur            x0, [fp, #-0x20]
    // 0xa61444: LoadField: r4 = r0->field_b
    //     0xa61444: ldur            w4, [x0, #0xb]
    // 0xa61448: DecompressPointer r4
    //     0xa61448: add             x4, x4, HEAP, lsl #32
    // 0xa6144c: mov             x0, x4
    // 0xa61450: ldur            x2, [fp, #-0x10]
    // 0xa61454: stur            x4, [fp, #-0x18]
    // 0xa61458: r1 = Null
    //     0xa61458: mov             x1, NULL
    // 0xa6145c: cmp             w0, NULL
    // 0xa61460: b.eq            #0xa61488
    // 0xa61464: cmp             w2, NULL
    // 0xa61468: b.eq            #0xa61488
    // 0xa6146c: LoadField: r4 = r2->field_17
    //     0xa6146c: ldur            w4, [x2, #0x17]
    // 0xa61470: DecompressPointer r4
    //     0xa61470: add             x4, x4, HEAP, lsl #32
    // 0xa61474: r8 = X0?
    //     0xa61474: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xa61478: LoadField: r9 = r4->field_7
    //     0xa61478: ldur            x9, [x4, #7]
    // 0xa6147c: r3 = Null
    //     0xa6147c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53248] Null
    //     0xa61480: ldr             x3, [x3, #0x248]
    // 0xa61484: blr             x9
    // 0xa61488: ldur            x0, [fp, #-0x18]
    // 0xa6148c: ldur            x1, [fp, #-0x28]
    // 0xa61490: StoreField: r1->field_f = r0
    //     0xa61490: stur            w0, [x1, #0xf]
    //     0xa61494: ldurb           w16, [x1, #-1]
    //     0xa61498: ldurb           w17, [x0, #-1]
    //     0xa6149c: and             x16, x17, x16, lsr #2
    //     0xa614a0: tst             x16, HEAP, lsr #32
    //     0xa614a4: b.eq            #0xa614ac
    //     0xa614a8: bl              #0xd6826c
    // 0xa614ac: ldr             x3, [fp, #0x10]
    // 0xa614b0: LoadField: r4 = r3->field_23
    //     0xa614b0: ldur            w4, [x3, #0x23]
    // 0xa614b4: DecompressPointer r4
    //     0xa614b4: add             x4, x4, HEAP, lsl #32
    // 0xa614b8: ldur            x0, [fp, #-8]
    // 0xa614bc: stur            x4, [fp, #-0x20]
    // 0xa614c0: LoadField: r5 = r0->field_83
    //     0xa614c0: ldur            w5, [x0, #0x83]
    // 0xa614c4: DecompressPointer r5
    //     0xa614c4: add             x5, x5, HEAP, lsl #32
    // 0xa614c8: stur            x5, [fp, #-0x10]
    // 0xa614cc: LoadField: r6 = r4->field_7
    //     0xa614cc: ldur            w6, [x4, #7]
    // 0xa614d0: DecompressPointer r6
    //     0xa614d0: add             x6, x6, HEAP, lsl #32
    // 0xa614d4: mov             x0, x5
    // 0xa614d8: mov             x2, x6
    // 0xa614dc: stur            x6, [fp, #-8]
    // 0xa614e0: r1 = Null
    //     0xa614e0: mov             x1, NULL
    // 0xa614e4: cmp             w0, NULL
    // 0xa614e8: b.eq            #0xa61510
    // 0xa614ec: cmp             w2, NULL
    // 0xa614f0: b.eq            #0xa61510
    // 0xa614f4: LoadField: r4 = r2->field_17
    //     0xa614f4: ldur            w4, [x2, #0x17]
    // 0xa614f8: DecompressPointer r4
    //     0xa614f8: add             x4, x4, HEAP, lsl #32
    // 0xa614fc: r8 = X0?
    //     0xa614fc: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xa61500: LoadField: r9 = r4->field_7
    //     0xa61500: ldur            x9, [x4, #7]
    // 0xa61504: r3 = Null
    //     0xa61504: add             x3, PP, #0x53, lsl #12  ; [pp+0x53258] Null
    //     0xa61508: ldr             x3, [x3, #0x258]
    // 0xa6150c: blr             x9
    // 0xa61510: ldur            x0, [fp, #-0x10]
    // 0xa61514: ldur            x3, [fp, #-0x20]
    // 0xa61518: StoreField: r3->field_b = r0
    //     0xa61518: stur            w0, [x3, #0xb]
    //     0xa6151c: ldurb           w16, [x3, #-1]
    //     0xa61520: ldurb           w17, [x0, #-1]
    //     0xa61524: and             x16, x17, x16, lsr #2
    //     0xa61528: tst             x16, HEAP, lsr #32
    //     0xa6152c: b.eq            #0xa61534
    //     0xa61530: bl              #0xd682ac
    // 0xa61534: ldur            x0, [fp, #-0x18]
    // 0xa61538: ldur            x2, [fp, #-8]
    // 0xa6153c: r1 = Null
    //     0xa6153c: mov             x1, NULL
    // 0xa61540: cmp             w0, NULL
    // 0xa61544: b.eq            #0xa6156c
    // 0xa61548: cmp             w2, NULL
    // 0xa6154c: b.eq            #0xa6156c
    // 0xa61550: LoadField: r4 = r2->field_17
    //     0xa61550: ldur            w4, [x2, #0x17]
    // 0xa61554: DecompressPointer r4
    //     0xa61554: add             x4, x4, HEAP, lsl #32
    // 0xa61558: r8 = X0?
    //     0xa61558: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xa6155c: LoadField: r9 = r4->field_7
    //     0xa6155c: ldur            x9, [x4, #7]
    // 0xa61560: r3 = Null
    //     0xa61560: add             x3, PP, #0x53, lsl #12  ; [pp+0x53268] Null
    //     0xa61564: ldr             x3, [x3, #0x268]
    // 0xa61568: blr             x9
    // 0xa6156c: ldur            x0, [fp, #-0x18]
    // 0xa61570: ldur            x1, [fp, #-0x20]
    // 0xa61574: StoreField: r1->field_f = r0
    //     0xa61574: stur            w0, [x1, #0xf]
    //     0xa61578: ldurb           w16, [x1, #-1]
    //     0xa6157c: ldurb           w17, [x0, #-1]
    //     0xa61580: and             x16, x17, x16, lsr #2
    //     0xa61584: tst             x16, HEAP, lsr #32
    //     0xa61588: b.eq            #0xa61590
    //     0xa6158c: bl              #0xd6826c
    // 0xa61590: ldr             x0, [fp, #0x10]
    // 0xa61594: LoadField: r3 = r0->field_27
    //     0xa61594: ldur            w3, [x0, #0x27]
    // 0xa61598: DecompressPointer r3
    //     0xa61598: add             x3, x3, HEAP, lsl #32
    // 0xa6159c: stur            x3, [fp, #-8]
    // 0xa615a0: LoadField: r2 = r3->field_7
    //     0xa615a0: ldur            w2, [x3, #7]
    // 0xa615a4: DecompressPointer r2
    //     0xa615a4: add             x2, x2, HEAP, lsl #32
    // 0xa615a8: r0 = Null
    //     0xa615a8: mov             x0, NULL
    // 0xa615ac: r1 = Null
    //     0xa615ac: mov             x1, NULL
    // 0xa615b0: cmp             w0, NULL
    // 0xa615b4: b.eq            #0xa615dc
    // 0xa615b8: cmp             w2, NULL
    // 0xa615bc: b.eq            #0xa615dc
    // 0xa615c0: LoadField: r4 = r2->field_17
    //     0xa615c0: ldur            w4, [x2, #0x17]
    // 0xa615c4: DecompressPointer r4
    //     0xa615c4: add             x4, x4, HEAP, lsl #32
    // 0xa615c8: r8 = X0?
    //     0xa615c8: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xa615cc: LoadField: r9 = r4->field_7
    //     0xa615cc: ldur            x9, [x4, #7]
    // 0xa615d0: r3 = Null
    //     0xa615d0: add             x3, PP, #0x53, lsl #12  ; [pp+0x53278] Null
    //     0xa615d4: ldr             x3, [x3, #0x278]
    // 0xa615d8: blr             x9
    // 0xa615dc: ldur            x1, [fp, #-8]
    // 0xa615e0: StoreField: r1->field_b = rNULL
    //     0xa615e0: stur            NULL, [x1, #0xb]
    // 0xa615e4: StoreField: r1->field_f = rNULL
    //     0xa615e4: stur            NULL, [x1, #0xf]
    // 0xa615e8: r0 = Null
    //     0xa615e8: mov             x0, NULL
    // 0xa615ec: LeaveFrame
    //     0xa615ec: mov             SP, fp
    //     0xa615f0: ldp             fp, lr, [SP], #0x10
    // 0xa615f4: ret
    //     0xa615f4: ret             
    // 0xa615f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa615f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa615fc: b               #0xa611d8
    // 0xa61600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61600: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa61604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61604: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa61608: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61608: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6160c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6160c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4156, size: 0x64, field offset: 0xc
//   const constructor, 
class ExpansionTile extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa404c8, size: 0x4c
    // 0xa404c8: EnterFrame
    //     0xa404c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa404cc: mov             fp, SP
    // 0xa404d0: AllocStack(0x8)
    //     0xa404d0: sub             SP, SP, #8
    // 0xa404d4: CheckStackOverflow
    //     0xa404d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa404d8: cmp             SP, x16
    //     0xa404dc: b.ls            #0xa4050c
    // 0xa404e0: r1 = <ExpansionTile>
    //     0xa404e0: add             x1, PP, #0x50, lsl #12  ; [pp+0x50cd0] TypeArguments: <ExpansionTile>
    //     0xa404e4: ldr             x1, [x1, #0xcd0]
    // 0xa404e8: r0 = _ExpansionTileState()
    //     0xa404e8: bl              #0xa40614  ; Allocate_ExpansionTileStateStub -> _ExpansionTileState (size=0x4c)
    // 0xa404ec: stur            x0, [fp, #-8]
    // 0xa404f0: SaveReg r0
    //     0xa404f0: str             x0, [SP, #-8]!
    // 0xa404f4: r0 = _ExpansionTileState()
    //     0xa404f4: bl              #0xa40514  ; [package:flutter/src/material/expansion_tile.dart] _ExpansionTileState::_ExpansionTileState
    // 0xa404f8: add             SP, SP, #8
    // 0xa404fc: ldur            x0, [fp, #-8]
    // 0xa40500: LeaveFrame
    //     0xa40500: mov             SP, fp
    //     0xa40504: ldp             fp, lr, [SP], #0x10
    // 0xa40508: ret
    //     0xa40508: ret             
    // 0xa4050c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4050c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa40510: b               #0xa404e0
  }
}

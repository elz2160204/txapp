// lib: , url: package:flutter/src/material/chip_theme.dart

// class id: 1049207, size: 0x8
class :: {
}

// class id: 2815, size: 0x58, field offset: 0x8
//   const constructor, 
class ChipThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafebc8, size: 0x184
    // 0xafebc8: EnterFrame
    //     0xafebc8: stp             fp, lr, [SP, #-0x10]!
    //     0xafebcc: mov             fp, SP
    // 0xafebd0: AllocStack(0x10)
    //     0xafebd0: sub             SP, SP, #0x10
    // 0xafebd4: r0 = 40
    //     0xafebd4: mov             x0, #0x28
    // 0xafebd8: CheckStackOverflow
    //     0xafebd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafebdc: cmp             SP, x16
    //     0xafebe0: b.ls            #0xafed44
    // 0xafebe4: ldr             x3, [fp, #0x10]
    // 0xafebe8: LoadField: r4 = r3->field_7
    //     0xafebe8: ldur            w4, [x3, #7]
    // 0xafebec: DecompressPointer r4
    //     0xafebec: add             x4, x4, HEAP, lsl #32
    // 0xafebf0: mov             x2, x0
    // 0xafebf4: stur            x4, [fp, #-8]
    // 0xafebf8: r1 = <Object?>
    //     0xafebf8: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xafebfc: r0 = AllocateArray()
    //     0xafebfc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xafec00: mov             x2, x0
    // 0xafec04: ldur            x0, [fp, #-8]
    // 0xafec08: stur            x2, [fp, #-0x10]
    // 0xafec0c: StoreField: r2->field_f = r0
    //     0xafec0c: stur            w0, [x2, #0xf]
    // 0xafec10: ldr             x0, [fp, #0x10]
    // 0xafec14: LoadField: r1 = r0->field_b
    //     0xafec14: ldur            w1, [x0, #0xb]
    // 0xafec18: DecompressPointer r1
    //     0xafec18: add             x1, x1, HEAP, lsl #32
    // 0xafec1c: StoreField: r2->field_13 = r1
    //     0xafec1c: stur            w1, [x2, #0x13]
    // 0xafec20: LoadField: r1 = r0->field_f
    //     0xafec20: ldur            w1, [x0, #0xf]
    // 0xafec24: DecompressPointer r1
    //     0xafec24: add             x1, x1, HEAP, lsl #32
    // 0xafec28: StoreField: r2->field_17 = r1
    //     0xafec28: stur            w1, [x2, #0x17]
    // 0xafec2c: LoadField: r1 = r0->field_13
    //     0xafec2c: ldur            w1, [x0, #0x13]
    // 0xafec30: DecompressPointer r1
    //     0xafec30: add             x1, x1, HEAP, lsl #32
    // 0xafec34: StoreField: r2->field_1b = r1
    //     0xafec34: stur            w1, [x2, #0x1b]
    // 0xafec38: LoadField: r1 = r0->field_17
    //     0xafec38: ldur            w1, [x0, #0x17]
    // 0xafec3c: DecompressPointer r1
    //     0xafec3c: add             x1, x1, HEAP, lsl #32
    // 0xafec40: StoreField: r2->field_1f = r1
    //     0xafec40: stur            w1, [x2, #0x1f]
    // 0xafec44: LoadField: r1 = r0->field_1b
    //     0xafec44: ldur            w1, [x0, #0x1b]
    // 0xafec48: DecompressPointer r1
    //     0xafec48: add             x1, x1, HEAP, lsl #32
    // 0xafec4c: StoreField: r2->field_23 = r1
    //     0xafec4c: stur            w1, [x2, #0x23]
    // 0xafec50: LoadField: r1 = r0->field_1f
    //     0xafec50: ldur            w1, [x0, #0x1f]
    // 0xafec54: DecompressPointer r1
    //     0xafec54: add             x1, x1, HEAP, lsl #32
    // 0xafec58: StoreField: r2->field_27 = r1
    //     0xafec58: stur            w1, [x2, #0x27]
    // 0xafec5c: LoadField: r1 = r0->field_23
    //     0xafec5c: ldur            w1, [x0, #0x23]
    // 0xafec60: DecompressPointer r1
    //     0xafec60: add             x1, x1, HEAP, lsl #32
    // 0xafec64: StoreField: r2->field_2b = r1
    //     0xafec64: stur            w1, [x2, #0x2b]
    // 0xafec68: LoadField: r1 = r0->field_27
    //     0xafec68: ldur            w1, [x0, #0x27]
    // 0xafec6c: DecompressPointer r1
    //     0xafec6c: add             x1, x1, HEAP, lsl #32
    // 0xafec70: StoreField: r2->field_2f = r1
    //     0xafec70: stur            w1, [x2, #0x2f]
    // 0xafec74: LoadField: r1 = r0->field_2b
    //     0xafec74: ldur            w1, [x0, #0x2b]
    // 0xafec78: DecompressPointer r1
    //     0xafec78: add             x1, x1, HEAP, lsl #32
    // 0xafec7c: StoreField: r2->field_33 = r1
    //     0xafec7c: stur            w1, [x2, #0x33]
    // 0xafec80: LoadField: r1 = r0->field_2f
    //     0xafec80: ldur            w1, [x0, #0x2f]
    // 0xafec84: DecompressPointer r1
    //     0xafec84: add             x1, x1, HEAP, lsl #32
    // 0xafec88: StoreField: r2->field_37 = r1
    //     0xafec88: stur            w1, [x2, #0x37]
    // 0xafec8c: LoadField: r1 = r0->field_33
    //     0xafec8c: ldur            w1, [x0, #0x33]
    // 0xafec90: DecompressPointer r1
    //     0xafec90: add             x1, x1, HEAP, lsl #32
    // 0xafec94: StoreField: r2->field_3b = r1
    //     0xafec94: stur            w1, [x2, #0x3b]
    // 0xafec98: LoadField: r1 = r0->field_37
    //     0xafec98: ldur            w1, [x0, #0x37]
    // 0xafec9c: DecompressPointer r1
    //     0xafec9c: add             x1, x1, HEAP, lsl #32
    // 0xafeca0: StoreField: r2->field_3f = r1
    //     0xafeca0: stur            w1, [x2, #0x3f]
    // 0xafeca4: LoadField: r1 = r0->field_3b
    //     0xafeca4: ldur            w1, [x0, #0x3b]
    // 0xafeca8: DecompressPointer r1
    //     0xafeca8: add             x1, x1, HEAP, lsl #32
    // 0xafecac: StoreField: r2->field_43 = r1
    //     0xafecac: stur            w1, [x2, #0x43]
    // 0xafecb0: LoadField: r1 = r0->field_3f
    //     0xafecb0: ldur            w1, [x0, #0x3f]
    // 0xafecb4: DecompressPointer r1
    //     0xafecb4: add             x1, x1, HEAP, lsl #32
    // 0xafecb8: StoreField: r2->field_47 = r1
    //     0xafecb8: stur            w1, [x2, #0x47]
    // 0xafecbc: LoadField: r1 = r0->field_43
    //     0xafecbc: ldur            w1, [x0, #0x43]
    // 0xafecc0: DecompressPointer r1
    //     0xafecc0: add             x1, x1, HEAP, lsl #32
    // 0xafecc4: StoreField: r2->field_4b = r1
    //     0xafecc4: stur            w1, [x2, #0x4b]
    // 0xafecc8: LoadField: r1 = r0->field_47
    //     0xafecc8: ldur            w1, [x0, #0x47]
    // 0xafeccc: DecompressPointer r1
    //     0xafeccc: add             x1, x1, HEAP, lsl #32
    // 0xafecd0: StoreField: r2->field_4f = r1
    //     0xafecd0: stur            w1, [x2, #0x4f]
    // 0xafecd4: LoadField: r1 = r0->field_4b
    //     0xafecd4: ldur            w1, [x0, #0x4b]
    // 0xafecd8: DecompressPointer r1
    //     0xafecd8: add             x1, x1, HEAP, lsl #32
    // 0xafecdc: StoreField: r2->field_53 = r1
    //     0xafecdc: stur            w1, [x2, #0x53]
    // 0xafece0: LoadField: r1 = r0->field_4f
    //     0xafece0: ldur            w1, [x0, #0x4f]
    // 0xafece4: DecompressPointer r1
    //     0xafece4: add             x1, x1, HEAP, lsl #32
    // 0xafece8: StoreField: r2->field_57 = r1
    //     0xafece8: stur            w1, [x2, #0x57]
    // 0xafecec: LoadField: r1 = r0->field_53
    //     0xafecec: ldur            w1, [x0, #0x53]
    // 0xafecf0: DecompressPointer r1
    //     0xafecf0: add             x1, x1, HEAP, lsl #32
    // 0xafecf4: StoreField: r2->field_5b = r1
    //     0xafecf4: stur            w1, [x2, #0x5b]
    // 0xafecf8: r1 = <Object?>
    //     0xafecf8: ldr             x1, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xafecfc: r0 = AllocateGrowableArray()
    //     0xafecfc: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xafed00: mov             x1, x0
    // 0xafed04: ldur            x0, [fp, #-0x10]
    // 0xafed08: StoreField: r1->field_f = r0
    //     0xafed08: stur            w0, [x1, #0xf]
    // 0xafed0c: r0 = 40
    //     0xafed0c: mov             x0, #0x28
    // 0xafed10: StoreField: r1->field_b = r0
    //     0xafed10: stur            w0, [x1, #0xb]
    // 0xafed14: SaveReg r1
    //     0xafed14: str             x1, [SP, #-8]!
    // 0xafed18: r0 = hashAll()
    //     0xafed18: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xafed1c: add             SP, SP, #8
    // 0xafed20: mov             x2, x0
    // 0xafed24: r0 = BoxInt64Instr(r2)
    //     0xafed24: sbfiz           x0, x2, #1, #0x1f
    //     0xafed28: cmp             x2, x0, asr #1
    //     0xafed2c: b.eq            #0xafed38
    //     0xafed30: bl              #0xd69bb8
    //     0xafed34: stur            x2, [x0, #7]
    // 0xafed38: LeaveFrame
    //     0xafed38: mov             SP, fp
    //     0xafed3c: ldp             fp, lr, [SP], #0x10
    // 0xafed40: ret
    //     0xafed40: ret             
    // 0xafed44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafed44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafed48: b               #0xafebe4
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf5394, size: 0x294
    // 0xbf5394: EnterFrame
    //     0xbf5394: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5398: mov             fp, SP
    // 0xbf539c: AllocStack(0x18)
    //     0xbf539c: sub             SP, SP, #0x18
    // 0xbf53a0: CheckStackOverflow
    //     0xbf53a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf53a4: cmp             SP, x16
    //     0xbf53a8: b.ls            #0xbf5610
    // 0xbf53ac: ldr             d0, [fp, #0x10]
    // 0xbf53b0: r0 = inline_Allocate_Double()
    //     0xbf53b0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf53b4: add             x0, x0, #0x10
    //     0xbf53b8: cmp             x1, x0
    //     0xbf53bc: b.ls            #0xbf5618
    //     0xbf53c0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf53c4: sub             x0, x0, #0xf
    //     0xbf53c8: mov             x1, #0xd108
    //     0xbf53cc: movk            x1, #3, lsl #16
    //     0xbf53d0: stur            x1, [x0, #-1]
    // 0xbf53d4: StoreField: r0->field_7 = d0
    //     0xbf53d4: stur            d0, [x0, #7]
    // 0xbf53d8: stur            x0, [fp, #-8]
    // 0xbf53dc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf53e0: SaveReg r0
    //     0xbf53e0: str             x0, [SP, #-8]!
    // 0xbf53e4: r0 = lerp()
    //     0xbf53e4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf53e8: add             SP, SP, #0x18
    // 0xbf53ec: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf53f0: ldur            x16, [fp, #-8]
    // 0xbf53f4: SaveReg r16
    //     0xbf53f4: str             x16, [SP, #-8]!
    // 0xbf53f8: r0 = lerp()
    //     0xbf53f8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf53fc: add             SP, SP, #0x18
    // 0xbf5400: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5404: ldur            x16, [fp, #-8]
    // 0xbf5408: SaveReg r16
    //     0xbf5408: str             x16, [SP, #-8]!
    // 0xbf540c: r0 = lerp()
    //     0xbf540c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5410: add             SP, SP, #0x18
    // 0xbf5414: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5418: ldur            x16, [fp, #-8]
    // 0xbf541c: SaveReg r16
    //     0xbf541c: str             x16, [SP, #-8]!
    // 0xbf5420: r0 = lerp()
    //     0xbf5420: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5424: add             SP, SP, #0x18
    // 0xbf5428: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf542c: ldur            x16, [fp, #-8]
    // 0xbf5430: SaveReg r16
    //     0xbf5430: str             x16, [SP, #-8]!
    // 0xbf5434: r0 = lerp()
    //     0xbf5434: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5438: add             SP, SP, #0x18
    // 0xbf543c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5440: ldur            x16, [fp, #-8]
    // 0xbf5444: SaveReg r16
    //     0xbf5444: str             x16, [SP, #-8]!
    // 0xbf5448: r0 = lerp()
    //     0xbf5448: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf544c: add             SP, SP, #0x18
    // 0xbf5450: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5454: ldur            x16, [fp, #-8]
    // 0xbf5458: SaveReg r16
    //     0xbf5458: str             x16, [SP, #-8]!
    // 0xbf545c: r0 = lerp()
    //     0xbf545c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5460: add             SP, SP, #0x18
    // 0xbf5464: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5468: ldur            x16, [fp, #-8]
    // 0xbf546c: SaveReg r16
    //     0xbf546c: str             x16, [SP, #-8]!
    // 0xbf5470: r0 = lerp()
    //     0xbf5470: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5474: add             SP, SP, #0x18
    // 0xbf5478: ldr             d1, [fp, #0x10]
    // 0xbf547c: d0 = 0.500000
    //     0xbf547c: fmov            d0, #0.50000000
    // 0xbf5480: fcmp            d1, d0
    // 0xbf5484: b.vs            #0xbf548c
    // 0xbf5488: b.lt            #0xbf5494
    // 0xbf548c: r0 = false
    //     0xbf548c: add             x0, NULL, #0x30  ; false
    // 0xbf5490: b               #0xbf5498
    // 0xbf5494: r0 = true
    //     0xbf5494: add             x0, NULL, #0x20  ; true
    // 0xbf5498: stur            x0, [fp, #-0x10]
    // 0xbf549c: tbz             w0, #4, #0xbf54a0
    // 0xbf54a0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf54a4: ldur            x16, [fp, #-8]
    // 0xbf54a8: SaveReg r16
    //     0xbf54a8: str             x16, [SP, #-8]!
    // 0xbf54ac: r0 = lerp()
    //     0xbf54ac: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf54b0: add             SP, SP, #0x18
    // 0xbf54b4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf54b8: ldur            x16, [fp, #-8]
    // 0xbf54bc: SaveReg r16
    //     0xbf54bc: str             x16, [SP, #-8]!
    // 0xbf54c0: r0 = lerp()
    //     0xbf54c0: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf54c4: add             SP, SP, #0x18
    // 0xbf54c8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf54cc: ldur            x16, [fp, #-8]
    // 0xbf54d0: SaveReg r16
    //     0xbf54d0: str             x16, [SP, #-8]!
    // 0xbf54d4: r0 = lerp()
    //     0xbf54d4: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf54d8: add             SP, SP, #0x18
    // 0xbf54dc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf54e0: ldur            x16, [fp, #-8]
    // 0xbf54e4: SaveReg r16
    //     0xbf54e4: str             x16, [SP, #-8]!
    // 0xbf54e8: r0 = lerp()
    //     0xbf54e8: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf54ec: add             SP, SP, #0x18
    // 0xbf54f0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf54f4: ldur            x16, [fp, #-8]
    // 0xbf54f8: SaveReg r16
    //     0xbf54f8: str             x16, [SP, #-8]!
    // 0xbf54fc: r0 = lerp()
    //     0xbf54fc: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf5500: add             SP, SP, #0x18
    // 0xbf5504: ldur            x0, [fp, #-0x10]
    // 0xbf5508: tbz             w0, #4, #0xbf550c
    // 0xbf550c: ldr             x1, [fp, #0x20]
    // 0xbf5510: ldr             x0, [fp, #0x18]
    // 0xbf5514: LoadField: r2 = r1->field_4b
    //     0xbf5514: ldur            w2, [x1, #0x4b]
    // 0xbf5518: DecompressPointer r2
    //     0xbf5518: add             x2, x2, HEAP, lsl #32
    // 0xbf551c: LoadField: r3 = r0->field_4b
    //     0xbf551c: ldur            w3, [x0, #0x4b]
    // 0xbf5520: DecompressPointer r3
    //     0xbf5520: add             x3, x3, HEAP, lsl #32
    // 0xbf5524: stp             x3, x2, [SP, #-0x10]!
    // 0xbf5528: ldur            x16, [fp, #-8]
    // 0xbf552c: SaveReg r16
    //     0xbf552c: str             x16, [SP, #-8]!
    // 0xbf5530: r0 = lerpDouble()
    //     0xbf5530: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5534: add             SP, SP, #0x18
    // 0xbf5538: mov             x1, x0
    // 0xbf553c: ldr             x0, [fp, #0x20]
    // 0xbf5540: stur            x1, [fp, #-0x10]
    // 0xbf5544: LoadField: r2 = r0->field_4f
    //     0xbf5544: ldur            w2, [x0, #0x4f]
    // 0xbf5548: DecompressPointer r2
    //     0xbf5548: add             x2, x2, HEAP, lsl #32
    // 0xbf554c: ldr             x3, [fp, #0x18]
    // 0xbf5550: LoadField: r4 = r3->field_4f
    //     0xbf5550: ldur            w4, [x3, #0x4f]
    // 0xbf5554: DecompressPointer r4
    //     0xbf5554: add             x4, x4, HEAP, lsl #32
    // 0xbf5558: stp             x4, x2, [SP, #-0x10]!
    // 0xbf555c: ldur            x16, [fp, #-8]
    // 0xbf5560: SaveReg r16
    //     0xbf5560: str             x16, [SP, #-8]!
    // 0xbf5564: r0 = lerpDouble()
    //     0xbf5564: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5568: add             SP, SP, #0x18
    // 0xbf556c: mov             x1, x0
    // 0xbf5570: ldr             x0, [fp, #0x20]
    // 0xbf5574: stur            x1, [fp, #-0x18]
    // 0xbf5578: LoadField: r2 = r0->field_53
    //     0xbf5578: ldur            w2, [x0, #0x53]
    // 0xbf557c: DecompressPointer r2
    //     0xbf557c: add             x2, x2, HEAP, lsl #32
    // 0xbf5580: cmp             w2, NULL
    // 0xbf5584: b.eq            #0xbf5590
    // 0xbf5588: ldr             x0, [fp, #0x18]
    // 0xbf558c: b               #0xbf55a4
    // 0xbf5590: ldr             x0, [fp, #0x18]
    // 0xbf5594: LoadField: r3 = r0->field_53
    //     0xbf5594: ldur            w3, [x0, #0x53]
    // 0xbf5598: DecompressPointer r3
    //     0xbf5598: add             x3, x3, HEAP, lsl #32
    // 0xbf559c: cmp             w3, NULL
    // 0xbf55a0: b.eq            #0xbf55c8
    // 0xbf55a4: LoadField: r3 = r0->field_53
    //     0xbf55a4: ldur            w3, [x0, #0x53]
    // 0xbf55a8: DecompressPointer r3
    //     0xbf55a8: add             x3, x3, HEAP, lsl #32
    // 0xbf55ac: stp             x3, x2, [SP, #-0x10]!
    // 0xbf55b0: ldur            x16, [fp, #-8]
    // 0xbf55b4: SaveReg r16
    //     0xbf55b4: str             x16, [SP, #-8]!
    // 0xbf55b8: r0 = lerp()
    //     0xbf55b8: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbf55bc: add             SP, SP, #0x18
    // 0xbf55c0: mov             x2, x0
    // 0xbf55c4: b               #0xbf55cc
    // 0xbf55c8: r2 = Null
    //     0xbf55c8: mov             x2, NULL
    // 0xbf55cc: ldur            x1, [fp, #-0x10]
    // 0xbf55d0: ldur            x0, [fp, #-0x18]
    // 0xbf55d4: stur            x2, [fp, #-8]
    // 0xbf55d8: r0 = ChipThemeData()
    //     0xbf55d8: bl              #0xbf5628  ; AllocateChipThemeDataStub -> ChipThemeData (size=0x58)
    // 0xbf55dc: r1 = true
    //     0xbf55dc: add             x1, NULL, #0x20  ; true
    // 0xbf55e0: StoreField: r0->field_27 = r1
    //     0xbf55e0: stur            w1, [x0, #0x27]
    // 0xbf55e4: r1 = Instance_Brightness
    //     0xbf55e4: ldr             x1, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0xbf55e8: StoreField: r0->field_47 = r1
    //     0xbf55e8: stur            w1, [x0, #0x47]
    // 0xbf55ec: ldur            x1, [fp, #-0x10]
    // 0xbf55f0: StoreField: r0->field_4b = r1
    //     0xbf55f0: stur            w1, [x0, #0x4b]
    // 0xbf55f4: ldur            x1, [fp, #-0x18]
    // 0xbf55f8: StoreField: r0->field_4f = r1
    //     0xbf55f8: stur            w1, [x0, #0x4f]
    // 0xbf55fc: ldur            x1, [fp, #-8]
    // 0xbf5600: StoreField: r0->field_53 = r1
    //     0xbf5600: stur            w1, [x0, #0x53]
    // 0xbf5604: LeaveFrame
    //     0xbf5604: mov             SP, fp
    //     0xbf5608: ldp             fp, lr, [SP], #0x10
    // 0xbf560c: ret
    //     0xbf560c: ret             
    // 0xbf5610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5610: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5614: b               #0xbf53ac
    // 0xbf5618: SaveReg d0
    //     0xbf5618: str             q0, [SP, #-0x10]!
    // 0xbf561c: r0 = AllocateDouble()
    //     0xbf561c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf5620: RestoreReg d0
    //     0xbf5620: ldr             q0, [SP], #0x10
    // 0xbf5624: b               #0xbf53d4
  }
  _ ==(/* No info */) {
    // ** addr: 0xc856b8, size: 0x1cc
    // 0xc856b8: EnterFrame
    //     0xc856b8: stp             fp, lr, [SP, #-0x10]!
    //     0xc856bc: mov             fp, SP
    // 0xc856c0: CheckStackOverflow
    //     0xc856c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc856c4: cmp             SP, x16
    //     0xc856c8: b.ls            #0xc8587c
    // 0xc856cc: ldr             x1, [fp, #0x10]
    // 0xc856d0: cmp             w1, NULL
    // 0xc856d4: b.ne            #0xc856e8
    // 0xc856d8: r0 = false
    //     0xc856d8: add             x0, NULL, #0x30  ; false
    // 0xc856dc: LeaveFrame
    //     0xc856dc: mov             SP, fp
    //     0xc856e0: ldp             fp, lr, [SP], #0x10
    // 0xc856e4: ret
    //     0xc856e4: ret             
    // 0xc856e8: ldr             x2, [fp, #0x18]
    // 0xc856ec: cmp             w2, w1
    // 0xc856f0: b.ne            #0xc85704
    // 0xc856f4: r0 = true
    //     0xc856f4: add             x0, NULL, #0x20  ; true
    // 0xc856f8: LeaveFrame
    //     0xc856f8: mov             SP, fp
    //     0xc856fc: ldp             fp, lr, [SP], #0x10
    // 0xc85700: ret
    //     0xc85700: ret             
    // 0xc85704: r0 = 59
    //     0xc85704: mov             x0, #0x3b
    // 0xc85708: branchIfSmi(r1, 0xc85714)
    //     0xc85708: tbz             w1, #0, #0xc85714
    // 0xc8570c: r0 = LoadClassIdInstr(r1)
    //     0xc8570c: ldur            x0, [x1, #-1]
    //     0xc85710: ubfx            x0, x0, #0xc, #0x14
    // 0xc85714: SaveReg r1
    //     0xc85714: str             x1, [SP, #-8]!
    // 0xc85718: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc85718: mov             x17, #0x57c5
    //     0xc8571c: add             lr, x0, x17
    //     0xc85720: ldr             lr, [x21, lr, lsl #3]
    //     0xc85724: blr             lr
    // 0xc85728: add             SP, SP, #8
    // 0xc8572c: r1 = LoadClassIdInstr(r0)
    //     0xc8572c: ldur            x1, [x0, #-1]
    //     0xc85730: ubfx            x1, x1, #0xc, #0x14
    // 0xc85734: r16 = ChipThemeData
    //     0xc85734: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3e8] Type: ChipThemeData
    //     0xc85738: ldr             x16, [x16, #0x3e8]
    // 0xc8573c: stp             x16, x0, [SP, #-0x10]!
    // 0xc85740: mov             x0, x1
    // 0xc85744: mov             lr, x0
    // 0xc85748: ldr             lr, [x21, lr, lsl #3]
    // 0xc8574c: blr             lr
    // 0xc85750: add             SP, SP, #0x10
    // 0xc85754: tbz             w0, #4, #0xc85768
    // 0xc85758: r0 = false
    //     0xc85758: add             x0, NULL, #0x30  ; false
    // 0xc8575c: LeaveFrame
    //     0xc8575c: mov             SP, fp
    //     0xc85760: ldp             fp, lr, [SP], #0x10
    // 0xc85764: ret
    //     0xc85764: ret             
    // 0xc85768: ldr             x1, [fp, #0x10]
    // 0xc8576c: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8576c: mov             x0, #0x76
    //     0xc85770: tbz             w1, #0, #0xc85780
    //     0xc85774: ldur            x0, [x1, #-1]
    //     0xc85778: ubfx            x0, x0, #0xc, #0x14
    //     0xc8577c: lsl             x0, x0, #1
    // 0xc85780: r17 = 5630
    //     0xc85780: mov             x17, #0x15fe
    // 0xc85784: cmp             w0, w17
    // 0xc85788: b.ne            #0xc8586c
    // 0xc8578c: ldr             x2, [fp, #0x18]
    // 0xc85790: LoadField: r0 = r1->field_27
    //     0xc85790: ldur            w0, [x1, #0x27]
    // 0xc85794: DecompressPointer r0
    //     0xc85794: add             x0, x0, HEAP, lsl #32
    // 0xc85798: LoadField: r3 = r2->field_27
    //     0xc85798: ldur            w3, [x2, #0x27]
    // 0xc8579c: DecompressPointer r3
    //     0xc8579c: add             x3, x3, HEAP, lsl #32
    // 0xc857a0: cmp             w0, w3
    // 0xc857a4: b.ne            #0xc8586c
    // 0xc857a8: LoadField: r0 = r1->field_47
    //     0xc857a8: ldur            w0, [x1, #0x47]
    // 0xc857ac: DecompressPointer r0
    //     0xc857ac: add             x0, x0, HEAP, lsl #32
    // 0xc857b0: LoadField: r3 = r2->field_47
    //     0xc857b0: ldur            w3, [x2, #0x47]
    // 0xc857b4: DecompressPointer r3
    //     0xc857b4: add             x3, x3, HEAP, lsl #32
    // 0xc857b8: cmp             w0, w3
    // 0xc857bc: b.ne            #0xc8586c
    // 0xc857c0: LoadField: r0 = r1->field_4b
    //     0xc857c0: ldur            w0, [x1, #0x4b]
    // 0xc857c4: DecompressPointer r0
    //     0xc857c4: add             x0, x0, HEAP, lsl #32
    // 0xc857c8: LoadField: r3 = r2->field_4b
    //     0xc857c8: ldur            w3, [x2, #0x4b]
    // 0xc857cc: DecompressPointer r3
    //     0xc857cc: add             x3, x3, HEAP, lsl #32
    // 0xc857d0: r4 = LoadClassIdInstr(r0)
    //     0xc857d0: ldur            x4, [x0, #-1]
    //     0xc857d4: ubfx            x4, x4, #0xc, #0x14
    // 0xc857d8: stp             x3, x0, [SP, #-0x10]!
    // 0xc857dc: mov             x0, x4
    // 0xc857e0: mov             lr, x0
    // 0xc857e4: ldr             lr, [x21, lr, lsl #3]
    // 0xc857e8: blr             lr
    // 0xc857ec: add             SP, SP, #0x10
    // 0xc857f0: tbnz            w0, #4, #0xc8586c
    // 0xc857f4: ldr             x2, [fp, #0x18]
    // 0xc857f8: ldr             x1, [fp, #0x10]
    // 0xc857fc: LoadField: r0 = r1->field_4f
    //     0xc857fc: ldur            w0, [x1, #0x4f]
    // 0xc85800: DecompressPointer r0
    //     0xc85800: add             x0, x0, HEAP, lsl #32
    // 0xc85804: LoadField: r3 = r2->field_4f
    //     0xc85804: ldur            w3, [x2, #0x4f]
    // 0xc85808: DecompressPointer r3
    //     0xc85808: add             x3, x3, HEAP, lsl #32
    // 0xc8580c: r4 = LoadClassIdInstr(r0)
    //     0xc8580c: ldur            x4, [x0, #-1]
    //     0xc85810: ubfx            x4, x4, #0xc, #0x14
    // 0xc85814: stp             x3, x0, [SP, #-0x10]!
    // 0xc85818: mov             x0, x4
    // 0xc8581c: mov             lr, x0
    // 0xc85820: ldr             lr, [x21, lr, lsl #3]
    // 0xc85824: blr             lr
    // 0xc85828: add             SP, SP, #0x10
    // 0xc8582c: tbnz            w0, #4, #0xc8586c
    // 0xc85830: ldr             x1, [fp, #0x18]
    // 0xc85834: ldr             x0, [fp, #0x10]
    // 0xc85838: LoadField: r2 = r0->field_53
    //     0xc85838: ldur            w2, [x0, #0x53]
    // 0xc8583c: DecompressPointer r2
    //     0xc8583c: add             x2, x2, HEAP, lsl #32
    // 0xc85840: LoadField: r0 = r1->field_53
    //     0xc85840: ldur            w0, [x1, #0x53]
    // 0xc85844: DecompressPointer r0
    //     0xc85844: add             x0, x0, HEAP, lsl #32
    // 0xc85848: r1 = LoadClassIdInstr(r2)
    //     0xc85848: ldur            x1, [x2, #-1]
    //     0xc8584c: ubfx            x1, x1, #0xc, #0x14
    // 0xc85850: stp             x0, x2, [SP, #-0x10]!
    // 0xc85854: mov             x0, x1
    // 0xc85858: mov             lr, x0
    // 0xc8585c: ldr             lr, [x21, lr, lsl #3]
    // 0xc85860: blr             lr
    // 0xc85864: add             SP, SP, #0x10
    // 0xc85868: b               #0xc85870
    // 0xc8586c: r0 = false
    //     0xc8586c: add             x0, NULL, #0x30  ; false
    // 0xc85870: LeaveFrame
    //     0xc85870: mov             SP, fp
    //     0xc85874: ldp             fp, lr, [SP], #0x10
    // 0xc85878: ret
    //     0xc85878: ret             
    // 0xc8587c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8587c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc85880: b               #0xc856cc
  }
}

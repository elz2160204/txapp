// lib: , url: package:flutter/src/material/filled_button_theme.dart

// class id: 1049242, size: 0x8
class :: {
}

// class id: 2801, size: 0xc, field offset: 0x8
//   const constructor, 
class FilledButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0xbf4984, size: 0x68
    // 0xbf4984: EnterFrame
    //     0xbf4984: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4988: mov             fp, SP
    // 0xbf498c: AllocStack(0x8)
    //     0xbf498c: sub             SP, SP, #8
    // 0xbf4990: CheckStackOverflow
    //     0xbf4990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4994: cmp             SP, x16
    //     0xbf4998: b.ls            #0xbf49e4
    // 0xbf499c: ldr             x0, [fp, #0x20]
    // 0xbf49a0: LoadField: r1 = r0->field_7
    //     0xbf49a0: ldur            w1, [x0, #7]
    // 0xbf49a4: DecompressPointer r1
    //     0xbf49a4: add             x1, x1, HEAP, lsl #32
    // 0xbf49a8: ldr             x0, [fp, #0x18]
    // 0xbf49ac: LoadField: r2 = r0->field_7
    //     0xbf49ac: ldur            w2, [x0, #7]
    // 0xbf49b0: DecompressPointer r2
    //     0xbf49b0: add             x2, x2, HEAP, lsl #32
    // 0xbf49b4: stp             x2, x1, [SP, #-0x10]!
    // 0xbf49b8: ldr             d0, [fp, #0x10]
    // 0xbf49bc: SaveReg d0
    //     0xbf49bc: str             d0, [SP, #-8]!
    // 0xbf49c0: r0 = lerp()
    //     0xbf49c0: bl              #0xbef34c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0xbf49c4: add             SP, SP, #0x18
    // 0xbf49c8: stur            x0, [fp, #-8]
    // 0xbf49cc: r0 = FilledButtonThemeData()
    //     0xbf49cc: bl              #0xbf49ec  ; AllocateFilledButtonThemeDataStub -> FilledButtonThemeData (size=0xc)
    // 0xbf49d0: ldur            x1, [fp, #-8]
    // 0xbf49d4: StoreField: r0->field_7 = r1
    //     0xbf49d4: stur            w1, [x0, #7]
    // 0xbf49d8: LeaveFrame
    //     0xbf49d8: mov             SP, fp
    //     0xbf49dc: ldp             fp, lr, [SP], #0x10
    // 0xbf49e0: ret
    //     0xbf49e0: ret             
    // 0xbf49e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf49e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf49e8: b               #0xbf499c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc88b88, size: 0x124
    // 0xc88b88: EnterFrame
    //     0xc88b88: stp             fp, lr, [SP, #-0x10]!
    //     0xc88b8c: mov             fp, SP
    // 0xc88b90: CheckStackOverflow
    //     0xc88b90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc88b94: cmp             SP, x16
    //     0xc88b98: b.ls            #0xc88ca4
    // 0xc88b9c: ldr             x1, [fp, #0x10]
    // 0xc88ba0: cmp             w1, NULL
    // 0xc88ba4: b.ne            #0xc88bb8
    // 0xc88ba8: r0 = false
    //     0xc88ba8: add             x0, NULL, #0x30  ; false
    // 0xc88bac: LeaveFrame
    //     0xc88bac: mov             SP, fp
    //     0xc88bb0: ldp             fp, lr, [SP], #0x10
    // 0xc88bb4: ret
    //     0xc88bb4: ret             
    // 0xc88bb8: ldr             x2, [fp, #0x18]
    // 0xc88bbc: cmp             w2, w1
    // 0xc88bc0: b.ne            #0xc88bd4
    // 0xc88bc4: r0 = true
    //     0xc88bc4: add             x0, NULL, #0x20  ; true
    // 0xc88bc8: LeaveFrame
    //     0xc88bc8: mov             SP, fp
    //     0xc88bcc: ldp             fp, lr, [SP], #0x10
    // 0xc88bd0: ret
    //     0xc88bd0: ret             
    // 0xc88bd4: r0 = 59
    //     0xc88bd4: mov             x0, #0x3b
    // 0xc88bd8: branchIfSmi(r1, 0xc88be4)
    //     0xc88bd8: tbz             w1, #0, #0xc88be4
    // 0xc88bdc: r0 = LoadClassIdInstr(r1)
    //     0xc88bdc: ldur            x0, [x1, #-1]
    //     0xc88be0: ubfx            x0, x0, #0xc, #0x14
    // 0xc88be4: SaveReg r1
    //     0xc88be4: str             x1, [SP, #-8]!
    // 0xc88be8: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc88be8: mov             x17, #0x57c5
    //     0xc88bec: add             lr, x0, x17
    //     0xc88bf0: ldr             lr, [x21, lr, lsl #3]
    //     0xc88bf4: blr             lr
    // 0xc88bf8: add             SP, SP, #8
    // 0xc88bfc: r1 = LoadClassIdInstr(r0)
    //     0xc88bfc: ldur            x1, [x0, #-1]
    //     0xc88c00: ubfx            x1, x1, #0xc, #0x14
    // 0xc88c04: r16 = FilledButtonThemeData
    //     0xc88c04: add             x16, PP, #0xe, lsl #12  ; [pp+0xe390] Type: FilledButtonThemeData
    //     0xc88c08: ldr             x16, [x16, #0x390]
    // 0xc88c0c: stp             x16, x0, [SP, #-0x10]!
    // 0xc88c10: mov             x0, x1
    // 0xc88c14: mov             lr, x0
    // 0xc88c18: ldr             lr, [x21, lr, lsl #3]
    // 0xc88c1c: blr             lr
    // 0xc88c20: add             SP, SP, #0x10
    // 0xc88c24: tbz             w0, #4, #0xc88c38
    // 0xc88c28: r0 = false
    //     0xc88c28: add             x0, NULL, #0x30  ; false
    // 0xc88c2c: LeaveFrame
    //     0xc88c2c: mov             SP, fp
    //     0xc88c30: ldp             fp, lr, [SP], #0x10
    // 0xc88c34: ret
    //     0xc88c34: ret             
    // 0xc88c38: ldr             x0, [fp, #0x10]
    // 0xc88c3c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc88c3c: mov             x1, #0x76
    //     0xc88c40: tbz             w0, #0, #0xc88c50
    //     0xc88c44: ldur            x1, [x0, #-1]
    //     0xc88c48: ubfx            x1, x1, #0xc, #0x14
    //     0xc88c4c: lsl             x1, x1, #1
    // 0xc88c50: r17 = 5602
    //     0xc88c50: mov             x17, #0x15e2
    // 0xc88c54: cmp             w1, w17
    // 0xc88c58: b.ne            #0xc88c94
    // 0xc88c5c: ldr             x1, [fp, #0x18]
    // 0xc88c60: LoadField: r2 = r0->field_7
    //     0xc88c60: ldur            w2, [x0, #7]
    // 0xc88c64: DecompressPointer r2
    //     0xc88c64: add             x2, x2, HEAP, lsl #32
    // 0xc88c68: LoadField: r0 = r1->field_7
    //     0xc88c68: ldur            w0, [x1, #7]
    // 0xc88c6c: DecompressPointer r0
    //     0xc88c6c: add             x0, x0, HEAP, lsl #32
    // 0xc88c70: r1 = LoadClassIdInstr(r2)
    //     0xc88c70: ldur            x1, [x2, #-1]
    //     0xc88c74: ubfx            x1, x1, #0xc, #0x14
    // 0xc88c78: stp             x0, x2, [SP, #-0x10]!
    // 0xc88c7c: mov             x0, x1
    // 0xc88c80: mov             lr, x0
    // 0xc88c84: ldr             lr, [x21, lr, lsl #3]
    // 0xc88c88: blr             lr
    // 0xc88c8c: add             SP, SP, #0x10
    // 0xc88c90: b               #0xc88c98
    // 0xc88c94: r0 = false
    //     0xc88c94: add             x0, NULL, #0x30  ; false
    // 0xc88c98: LeaveFrame
    //     0xc88c98: mov             SP, fp
    //     0xc88c9c: ldp             fp, lr, [SP], #0x10
    // 0xc88ca0: ret
    //     0xc88ca0: ret             
    // 0xc88ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc88ca4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc88ca8: b               #0xc88b9c
  }
}

// lib: , url: package:flutter/src/material/drawer_theme.dart

// class id: 1049229, size: 0x8
class :: {
}

// class id: 2805, size: 0x28, field offset: 0x8
//   const constructor, 
class DrawerThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xaff2cc, size: 0x70
    // 0xaff2cc: EnterFrame
    //     0xaff2cc: stp             fp, lr, [SP, #-0x10]!
    //     0xaff2d0: mov             fp, SP
    // 0xaff2d4: CheckStackOverflow
    //     0xaff2d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaff2d8: cmp             SP, x16
    //     0xaff2dc: b.ls            #0xaff334
    // 0xaff2e0: ldr             x0, [fp, #0x10]
    // 0xaff2e4: LoadField: r1 = r0->field_f
    //     0xaff2e4: ldur            w1, [x0, #0xf]
    // 0xaff2e8: DecompressPointer r1
    //     0xaff2e8: add             x1, x1, HEAP, lsl #32
    // 0xaff2ec: LoadField: r2 = r0->field_23
    //     0xaff2ec: ldur            w2, [x0, #0x23]
    // 0xaff2f0: DecompressPointer r2
    //     0xaff2f0: add             x2, x2, HEAP, lsl #32
    // 0xaff2f4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff2f8: stp             NULL, x1, [SP, #-0x10]!
    // 0xaff2fc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff300: stp             x2, NULL, [SP, #-0x10]!
    // 0xaff304: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0xaff304: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0xaff308: r0 = hash()
    //     0xaff308: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaff30c: add             SP, SP, #0x40
    // 0xaff310: mov             x2, x0
    // 0xaff314: r0 = BoxInt64Instr(r2)
    //     0xaff314: sbfiz           x0, x2, #1, #0x1f
    //     0xaff318: cmp             x2, x0, asr #1
    //     0xaff31c: b.eq            #0xaff328
    //     0xaff320: bl              #0xd69bb8
    //     0xaff324: stur            x2, [x0, #7]
    // 0xaff328: LeaveFrame
    //     0xaff328: mov             SP, fp
    //     0xaff32c: ldp             fp, lr, [SP], #0x10
    // 0xaff330: ret
    //     0xaff330: ret             
    // 0xaff334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaff334: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaff338: b               #0xaff2e0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf4c58, size: 0x12c
    // 0xbf4c58: EnterFrame
    //     0xbf4c58: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4c5c: mov             fp, SP
    // 0xbf4c60: AllocStack(0x10)
    //     0xbf4c60: sub             SP, SP, #0x10
    // 0xbf4c64: CheckStackOverflow
    //     0xbf4c64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4c68: cmp             SP, x16
    //     0xbf4c6c: b.ls            #0xbf4d6c
    // 0xbf4c70: ldr             d0, [fp, #0x10]
    // 0xbf4c74: r0 = inline_Allocate_Double()
    //     0xbf4c74: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf4c78: add             x0, x0, #0x10
    //     0xbf4c7c: cmp             x1, x0
    //     0xbf4c80: b.ls            #0xbf4d74
    //     0xbf4c84: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf4c88: sub             x0, x0, #0xf
    //     0xbf4c8c: mov             x1, #0xd108
    //     0xbf4c90: movk            x1, #3, lsl #16
    //     0xbf4c94: stur            x1, [x0, #-1]
    // 0xbf4c98: StoreField: r0->field_7 = d0
    //     0xbf4c98: stur            d0, [x0, #7]
    // 0xbf4c9c: stur            x0, [fp, #-8]
    // 0xbf4ca0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4ca4: SaveReg r0
    //     0xbf4ca4: str             x0, [SP, #-8]!
    // 0xbf4ca8: r0 = lerp()
    //     0xbf4ca8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4cac: add             SP, SP, #0x18
    // 0xbf4cb0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4cb4: ldur            x16, [fp, #-8]
    // 0xbf4cb8: SaveReg r16
    //     0xbf4cb8: str             x16, [SP, #-8]!
    // 0xbf4cbc: r0 = lerp()
    //     0xbf4cbc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4cc0: add             SP, SP, #0x18
    // 0xbf4cc4: ldr             x0, [fp, #0x20]
    // 0xbf4cc8: LoadField: r1 = r0->field_f
    //     0xbf4cc8: ldur            w1, [x0, #0xf]
    // 0xbf4ccc: DecompressPointer r1
    //     0xbf4ccc: add             x1, x1, HEAP, lsl #32
    // 0xbf4cd0: ldr             x2, [fp, #0x18]
    // 0xbf4cd4: LoadField: r3 = r2->field_f
    //     0xbf4cd4: ldur            w3, [x2, #0xf]
    // 0xbf4cd8: DecompressPointer r3
    //     0xbf4cd8: add             x3, x3, HEAP, lsl #32
    // 0xbf4cdc: stp             x3, x1, [SP, #-0x10]!
    // 0xbf4ce0: ldur            x16, [fp, #-8]
    // 0xbf4ce4: SaveReg r16
    //     0xbf4ce4: str             x16, [SP, #-8]!
    // 0xbf4ce8: r0 = lerpDouble()
    //     0xbf4ce8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4cec: add             SP, SP, #0x18
    // 0xbf4cf0: stur            x0, [fp, #-0x10]
    // 0xbf4cf4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4cf8: ldur            x16, [fp, #-8]
    // 0xbf4cfc: SaveReg r16
    //     0xbf4cfc: str             x16, [SP, #-8]!
    // 0xbf4d00: r0 = lerp()
    //     0xbf4d00: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4d04: add             SP, SP, #0x18
    // 0xbf4d08: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4d0c: ldur            x16, [fp, #-8]
    // 0xbf4d10: SaveReg r16
    //     0xbf4d10: str             x16, [SP, #-8]!
    // 0xbf4d14: r0 = lerp()
    //     0xbf4d14: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4d18: add             SP, SP, #0x18
    // 0xbf4d1c: ldr             x0, [fp, #0x20]
    // 0xbf4d20: LoadField: r1 = r0->field_23
    //     0xbf4d20: ldur            w1, [x0, #0x23]
    // 0xbf4d24: DecompressPointer r1
    //     0xbf4d24: add             x1, x1, HEAP, lsl #32
    // 0xbf4d28: ldr             x0, [fp, #0x18]
    // 0xbf4d2c: LoadField: r2 = r0->field_23
    //     0xbf4d2c: ldur            w2, [x0, #0x23]
    // 0xbf4d30: DecompressPointer r2
    //     0xbf4d30: add             x2, x2, HEAP, lsl #32
    // 0xbf4d34: stp             x2, x1, [SP, #-0x10]!
    // 0xbf4d38: ldur            x16, [fp, #-8]
    // 0xbf4d3c: SaveReg r16
    //     0xbf4d3c: str             x16, [SP, #-8]!
    // 0xbf4d40: r0 = lerpDouble()
    //     0xbf4d40: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4d44: add             SP, SP, #0x18
    // 0xbf4d48: stur            x0, [fp, #-8]
    // 0xbf4d4c: r0 = DrawerThemeData()
    //     0xbf4d4c: bl              #0xbf4d84  ; AllocateDrawerThemeDataStub -> DrawerThemeData (size=0x28)
    // 0xbf4d50: ldur            x1, [fp, #-0x10]
    // 0xbf4d54: StoreField: r0->field_f = r1
    //     0xbf4d54: stur            w1, [x0, #0xf]
    // 0xbf4d58: ldur            x1, [fp, #-8]
    // 0xbf4d5c: StoreField: r0->field_23 = r1
    //     0xbf4d5c: stur            w1, [x0, #0x23]
    // 0xbf4d60: LeaveFrame
    //     0xbf4d60: mov             SP, fp
    //     0xbf4d64: ldp             fp, lr, [SP], #0x10
    // 0xbf4d68: ret
    //     0xbf4d68: ret             
    // 0xbf4d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf4d6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf4d70: b               #0xbf4c70
    // 0xbf4d74: SaveReg d0
    //     0xbf4d74: str             q0, [SP, #-0x10]!
    // 0xbf4d78: r0 = AllocateDouble()
    //     0xbf4d78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf4d7c: RestoreReg d0
    //     0xbf4d7c: ldr             q0, [SP], #0x10
    // 0xbf4d80: b               #0xbf4c98
  }
  _ ==(/* No info */) {
    // ** addr: 0xc886ec, size: 0x160
    // 0xc886ec: EnterFrame
    //     0xc886ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc886f0: mov             fp, SP
    // 0xc886f4: CheckStackOverflow
    //     0xc886f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc886f8: cmp             SP, x16
    //     0xc886fc: b.ls            #0xc88844
    // 0xc88700: ldr             x1, [fp, #0x10]
    // 0xc88704: cmp             w1, NULL
    // 0xc88708: b.ne            #0xc8871c
    // 0xc8870c: r0 = false
    //     0xc8870c: add             x0, NULL, #0x30  ; false
    // 0xc88710: LeaveFrame
    //     0xc88710: mov             SP, fp
    //     0xc88714: ldp             fp, lr, [SP], #0x10
    // 0xc88718: ret
    //     0xc88718: ret             
    // 0xc8871c: ldr             x2, [fp, #0x18]
    // 0xc88720: cmp             w2, w1
    // 0xc88724: b.ne            #0xc88738
    // 0xc88728: r0 = true
    //     0xc88728: add             x0, NULL, #0x20  ; true
    // 0xc8872c: LeaveFrame
    //     0xc8872c: mov             SP, fp
    //     0xc88730: ldp             fp, lr, [SP], #0x10
    // 0xc88734: ret
    //     0xc88734: ret             
    // 0xc88738: r0 = 59
    //     0xc88738: mov             x0, #0x3b
    // 0xc8873c: branchIfSmi(r1, 0xc88748)
    //     0xc8873c: tbz             w1, #0, #0xc88748
    // 0xc88740: r0 = LoadClassIdInstr(r1)
    //     0xc88740: ldur            x0, [x1, #-1]
    //     0xc88744: ubfx            x0, x0, #0xc, #0x14
    // 0xc88748: SaveReg r1
    //     0xc88748: str             x1, [SP, #-8]!
    // 0xc8874c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8874c: mov             x17, #0x57c5
    //     0xc88750: add             lr, x0, x17
    //     0xc88754: ldr             lr, [x21, lr, lsl #3]
    //     0xc88758: blr             lr
    // 0xc8875c: add             SP, SP, #8
    // 0xc88760: r1 = LoadClassIdInstr(r0)
    //     0xc88760: ldur            x1, [x0, #-1]
    //     0xc88764: ubfx            x1, x1, #0xc, #0x14
    // 0xc88768: r16 = DrawerThemeData
    //     0xc88768: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3b0] Type: DrawerThemeData
    //     0xc8876c: ldr             x16, [x16, #0x3b0]
    // 0xc88770: stp             x16, x0, [SP, #-0x10]!
    // 0xc88774: mov             x0, x1
    // 0xc88778: mov             lr, x0
    // 0xc8877c: ldr             lr, [x21, lr, lsl #3]
    // 0xc88780: blr             lr
    // 0xc88784: add             SP, SP, #0x10
    // 0xc88788: tbz             w0, #4, #0xc8879c
    // 0xc8878c: r0 = false
    //     0xc8878c: add             x0, NULL, #0x30  ; false
    // 0xc88790: LeaveFrame
    //     0xc88790: mov             SP, fp
    //     0xc88794: ldp             fp, lr, [SP], #0x10
    // 0xc88798: ret
    //     0xc88798: ret             
    // 0xc8879c: ldr             x1, [fp, #0x10]
    // 0xc887a0: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc887a0: mov             x0, #0x76
    //     0xc887a4: tbz             w1, #0, #0xc887b4
    //     0xc887a8: ldur            x0, [x1, #-1]
    //     0xc887ac: ubfx            x0, x0, #0xc, #0x14
    //     0xc887b0: lsl             x0, x0, #1
    // 0xc887b4: r17 = 5610
    //     0xc887b4: mov             x17, #0x15ea
    // 0xc887b8: cmp             w0, w17
    // 0xc887bc: b.ne            #0xc88834
    // 0xc887c0: ldr             x2, [fp, #0x18]
    // 0xc887c4: LoadField: r0 = r1->field_f
    //     0xc887c4: ldur            w0, [x1, #0xf]
    // 0xc887c8: DecompressPointer r0
    //     0xc887c8: add             x0, x0, HEAP, lsl #32
    // 0xc887cc: LoadField: r3 = r2->field_f
    //     0xc887cc: ldur            w3, [x2, #0xf]
    // 0xc887d0: DecompressPointer r3
    //     0xc887d0: add             x3, x3, HEAP, lsl #32
    // 0xc887d4: r4 = LoadClassIdInstr(r0)
    //     0xc887d4: ldur            x4, [x0, #-1]
    //     0xc887d8: ubfx            x4, x4, #0xc, #0x14
    // 0xc887dc: stp             x3, x0, [SP, #-0x10]!
    // 0xc887e0: mov             x0, x4
    // 0xc887e4: mov             lr, x0
    // 0xc887e8: ldr             lr, [x21, lr, lsl #3]
    // 0xc887ec: blr             lr
    // 0xc887f0: add             SP, SP, #0x10
    // 0xc887f4: tbnz            w0, #4, #0xc88834
    // 0xc887f8: ldr             x1, [fp, #0x18]
    // 0xc887fc: ldr             x0, [fp, #0x10]
    // 0xc88800: LoadField: r2 = r0->field_23
    //     0xc88800: ldur            w2, [x0, #0x23]
    // 0xc88804: DecompressPointer r2
    //     0xc88804: add             x2, x2, HEAP, lsl #32
    // 0xc88808: LoadField: r0 = r1->field_23
    //     0xc88808: ldur            w0, [x1, #0x23]
    // 0xc8880c: DecompressPointer r0
    //     0xc8880c: add             x0, x0, HEAP, lsl #32
    // 0xc88810: r1 = LoadClassIdInstr(r2)
    //     0xc88810: ldur            x1, [x2, #-1]
    //     0xc88814: ubfx            x1, x1, #0xc, #0x14
    // 0xc88818: stp             x0, x2, [SP, #-0x10]!
    // 0xc8881c: mov             x0, x1
    // 0xc88820: mov             lr, x0
    // 0xc88824: ldr             lr, [x21, lr, lsl #3]
    // 0xc88828: blr             lr
    // 0xc8882c: add             SP, SP, #0x10
    // 0xc88830: b               #0xc88838
    // 0xc88834: r0 = false
    //     0xc88834: add             x0, NULL, #0x30  ; false
    // 0xc88838: LeaveFrame
    //     0xc88838: mov             SP, fp
    //     0xc8883c: ldp             fp, lr, [SP], #0x10
    // 0xc88840: ret
    //     0xc88840: ret             
    // 0xc88844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc88844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc88848: b               #0xc88700
  }
}

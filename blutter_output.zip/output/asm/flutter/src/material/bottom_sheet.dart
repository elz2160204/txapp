// lib: , url: package:flutter/src/material/bottom_sheet.dart

// class id: 1049192, size: 0x8
class :: {

  static _ showModalBottomSheet(/* No info */) {
    // ** addr: 0x94f118, size: 0x108
    // 0x94f118: EnterFrame
    //     0x94f118: stp             fp, lr, [SP, #-0x10]!
    //     0x94f11c: mov             fp, SP
    // 0x94f120: AllocStack(0x20)
    //     0x94f120: sub             SP, SP, #0x20
    // 0x94f124: SetupParameters()
    //     0x94f124: mov             x0, x4
    //     0x94f128: ldur            w1, [x0, #0xf]
    //     0x94f12c: add             x1, x1, HEAP, lsl #32
    //     0x94f130: cbnz            w1, #0x94f13c
    //     0x94f134: mov             x1, NULL
    //     0x94f138: b               #0x94f150
    //     0x94f13c: ldur            w1, [x0, #0x17]
    //     0x94f140: add             x1, x1, HEAP, lsl #32
    //     0x94f144: add             x0, fp, w1, sxtw #2
    //     0x94f148: ldr             x0, [x0, #0x10]
    //     0x94f14c: mov             x1, x0
    //     0x94f150: stur            x1, [fp, #-8]
    // 0x94f154: CheckStackOverflow
    //     0x94f154: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x94f158: cmp             SP, x16
    //     0x94f15c: b.ls            #0x94f214
    // 0x94f160: ldr             x16, [fp, #0x18]
    // 0x94f164: r30 = false
    //     0x94f164: add             lr, NULL, #0x30  ; false
    // 0x94f168: stp             lr, x16, [SP, #-0x10]!
    // 0x94f16c: r4 = const [0, 0x2, 0x2, 0x1, rootNavigator, 0x1, null]
    //     0x94f16c: add             x4, PP, #0x20, lsl #12  ; [pp+0x20800] List(7) [0, 0x2, 0x2, 0x1, "rootNavigator", 0x1, Null]
    //     0x94f170: ldr             x4, [x4, #0x800]
    // 0x94f174: r0 = of()
    //     0x94f174: bl              #0x5a0f40  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x94f178: add             SP, SP, #0x10
    // 0x94f17c: stur            x0, [fp, #-0x10]
    // 0x94f180: LoadField: r1 = r0->field_f
    //     0x94f180: ldur            w1, [x0, #0xf]
    // 0x94f184: DecompressPointer r1
    //     0x94f184: add             x1, x1, HEAP, lsl #32
    // 0x94f188: cmp             w1, NULL
    // 0x94f18c: b.eq            #0x94f21c
    // 0x94f190: ldr             x16, [fp, #0x18]
    // 0x94f194: stp             x1, x16, [SP, #-0x10]!
    // 0x94f198: r0 = capture()
    //     0x94f198: bl              #0x7cc5c4  ; [package:flutter/src/widgets/inherited_theme.dart] InheritedTheme::capture
    // 0x94f19c: add             SP, SP, #0x10
    // 0x94f1a0: stur            x0, [fp, #-0x18]
    // 0x94f1a4: ldr             x16, [fp, #0x18]
    // 0x94f1a8: SaveReg r16
    //     0x94f1a8: str             x16, [SP, #-8]!
    // 0x94f1ac: r0 = of()
    //     0x94f1ac: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x94f1b0: add             SP, SP, #8
    // 0x94f1b4: ldur            x1, [fp, #-8]
    // 0x94f1b8: r0 = ModalBottomSheetRoute()
    //     0x94f1b8: bl              #0x94f30c  ; AllocateModalBottomSheetRouteStub -> ModalBottomSheetRoute<X0> (size=0xbc)
    // 0x94f1bc: stur            x0, [fp, #-0x20]
    // 0x94f1c0: ldr             x16, [fp, #0x20]
    // 0x94f1c4: stp             x16, x0, [SP, #-0x10]!
    // 0x94f1c8: ldur            x16, [fp, #-0x18]
    // 0x94f1cc: r30 = Instance_Color
    //     0x94f1cc: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x94f1d0: ldr             lr, [lr, #0xc08]
    // 0x94f1d4: stp             lr, x16, [SP, #-0x10]!
    // 0x94f1d8: ldr             x16, [fp, #0x10]
    // 0x94f1dc: SaveReg r16
    //     0x94f1dc: str             x16, [SP, #-8]!
    // 0x94f1e0: r0 = ModalBottomSheetRoute()
    //     0x94f1e0: bl              #0x94f220  ; [package:flutter/src/material/bottom_sheet.dart] ModalBottomSheetRoute::ModalBottomSheetRoute
    // 0x94f1e4: add             SP, SP, #0x28
    // 0x94f1e8: ldur            x16, [fp, #-8]
    // 0x94f1ec: ldur            lr, [fp, #-0x10]
    // 0x94f1f0: stp             lr, x16, [SP, #-0x10]!
    // 0x94f1f4: ldur            x16, [fp, #-0x20]
    // 0x94f1f8: SaveReg r16
    //     0x94f1f8: str             x16, [SP, #-8]!
    // 0x94f1fc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x94f1fc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x94f200: r0 = push()
    //     0x94f200: bl              #0x508e98  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x94f204: add             SP, SP, #0x18
    // 0x94f208: LeaveFrame
    //     0x94f208: mov             SP, fp
    //     0x94f20c: ldp             fp, lr, [SP], #0x10
    // 0x94f210: ret
    //     0x94f210: ret             
    // 0x94f214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94f214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94f218: b               #0x94f160
    // 0x94f21c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x94f21c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 1783, size: 0xbc, field offset: 0x7c
class ModalBottomSheetRoute<X0> extends PopupRoute<X0> {

  _ ModalBottomSheetRoute(/* No info */) {
    // ** addr: 0x94f220, size: 0xec
    // 0x94f220: EnterFrame
    //     0x94f220: stp             fp, lr, [SP, #-0x10]!
    //     0x94f224: mov             fp, SP
    // 0x94f228: r4 = "Dismiss"
    //     0x94f228: add             x4, PP, #0x20, lsl #12  ; [pp+0x20958] "Dismiss"
    //     0x94f22c: ldr             x4, [x4, #0x958]
    // 0x94f230: r3 = Instance_Color
    //     0x94f230: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x94f234: ldr             x3, [x3, #0xc08]
    // 0x94f238: r2 = true
    //     0x94f238: add             x2, NULL, #0x20  ; true
    // 0x94f23c: r1 = false
    //     0x94f23c: add             x1, NULL, #0x30  ; false
    // 0x94f240: CheckStackOverflow
    //     0x94f240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x94f244: cmp             SP, x16
    //     0x94f248: b.ls            #0x94f304
    // 0x94f24c: ldr             x0, [fp, #0x28]
    // 0x94f250: ldr             x5, [fp, #0x30]
    // 0x94f254: StoreField: r5->field_7b = r0
    //     0x94f254: stur            w0, [x5, #0x7b]
    //     0x94f258: ldurb           w16, [x5, #-1]
    //     0x94f25c: ldurb           w17, [x0, #-1]
    //     0x94f260: and             x16, x17, x16, lsr #2
    //     0x94f264: tst             x16, HEAP, lsr #32
    //     0x94f268: b.eq            #0x94f270
    //     0x94f26c: bl              #0xd682ec
    // 0x94f270: ldr             x0, [fp, #0x20]
    // 0x94f274: StoreField: r5->field_7f = r0
    //     0x94f274: stur            w0, [x5, #0x7f]
    //     0x94f278: ldurb           w16, [x5, #-1]
    //     0x94f27c: ldurb           w17, [x0, #-1]
    //     0x94f280: and             x16, x17, x16, lsr #2
    //     0x94f284: tst             x16, HEAP, lsr #32
    //     0x94f288: b.eq            #0x94f290
    //     0x94f28c: bl              #0xd682ec
    // 0x94f290: StoreField: r5->field_b3 = r4
    //     0x94f290: stur            w4, [x5, #0xb3]
    // 0x94f294: StoreField: r5->field_87 = r3
    //     0x94f294: stur            w3, [x5, #0x87]
    // 0x94f298: ldr             x0, [fp, #0x18]
    // 0x94f29c: StoreField: r5->field_9b = r0
    //     0x94f29c: stur            w0, [x5, #0x9b]
    //     0x94f2a0: ldurb           w16, [x5, #-1]
    //     0x94f2a4: ldurb           w17, [x0, #-1]
    //     0x94f2a8: and             x16, x17, x16, lsr #2
    //     0x94f2ac: tst             x16, HEAP, lsr #32
    //     0x94f2b0: b.eq            #0x94f2b8
    //     0x94f2b4: bl              #0xd682ec
    // 0x94f2b8: StoreField: r5->field_9f = r2
    //     0x94f2b8: stur            w2, [x5, #0x9f]
    // 0x94f2bc: StoreField: r5->field_a3 = r2
    //     0x94f2bc: stur            w2, [x5, #0xa3]
    // 0x94f2c0: StoreField: r5->field_83 = r1
    //     0x94f2c0: stur            w1, [x5, #0x83]
    // 0x94f2c4: ldr             x0, [fp, #0x10]
    // 0x94f2c8: StoreField: r5->field_a7 = r0
    //     0x94f2c8: stur            w0, [x5, #0xa7]
    //     0x94f2cc: ldurb           w16, [x5, #-1]
    //     0x94f2d0: ldurb           w17, [x0, #-1]
    //     0x94f2d4: and             x16, x17, x16, lsr #2
    //     0x94f2d8: tst             x16, HEAP, lsr #32
    //     0x94f2dc: b.eq            #0x94f2e4
    //     0x94f2e0: bl              #0xd682ec
    // 0x94f2e4: StoreField: r5->field_af = r1
    //     0x94f2e4: stur            w1, [x5, #0xaf]
    // 0x94f2e8: stp             NULL, x5, [SP, #-0x10]!
    // 0x94f2ec: r0 = ModalRoute()
    //     0x94f2ec: bl              #0x5a097c  ; [package:flutter/src/widgets/routes.dart] ModalRoute::ModalRoute
    // 0x94f2f0: add             SP, SP, #0x10
    // 0x94f2f4: r0 = Null
    //     0x94f2f4: mov             x0, NULL
    // 0x94f2f8: LeaveFrame
    //     0x94f2f8: mov             SP, fp
    //     0x94f2fc: ldp             fp, lr, [SP], #0x10
    // 0x94f300: ret
    //     0x94f300: ret             
    // 0x94f304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x94f304: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x94f308: b               #0x94f24c
  }
  _ buildPage(/* No info */) {
    // ** addr: 0xab3044, size: 0xcc
    // 0xab3044: EnterFrame
    //     0xab3044: stp             fp, lr, [SP, #-0x10]!
    //     0xab3048: mov             fp, SP
    // 0xab304c: AllocStack(0x10)
    //     0xab304c: sub             SP, SP, #0x10
    // 0xab3050: CheckStackOverflow
    //     0xab3050: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xab3054: cmp             SP, x16
    //     0xab3058: b.ls            #0xab3108
    // 0xab305c: r1 = 1
    //     0xab305c: mov             x1, #1
    // 0xab3060: r0 = AllocateContext()
    //     0xab3060: bl              #0xd68aa4  ; AllocateContextStub
    // 0xab3064: mov             x1, x0
    // 0xab3068: ldr             x0, [fp, #0x28]
    // 0xab306c: StoreField: r1->field_f = r0
    //     0xab306c: stur            w0, [x1, #0xf]
    // 0xab3070: LoadField: r3 = r0->field_7
    //     0xab3070: ldur            w3, [x0, #7]
    // 0xab3074: DecompressPointer r3
    //     0xab3074: add             x3, x3, HEAP, lsl #32
    // 0xab3078: mov             x2, x1
    // 0xab307c: stur            x3, [fp, #-8]
    // 0xab3080: r1 = Function '<anonymous closure>':.
    //     0xab3080: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e770] AnonymousClosure: (0xab311c), in [package:flutter/src/material/bottom_sheet.dart] ModalBottomSheetRoute::buildPage (0xab3044)
    //     0xab3084: ldr             x1, [x1, #0x770]
    // 0xab3088: r0 = AllocateClosure()
    //     0xab3088: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xab308c: mov             x1, x0
    // 0xab3090: ldur            x0, [fp, #-8]
    // 0xab3094: stur            x1, [fp, #-0x10]
    // 0xab3098: StoreField: r1->field_7 = r0
    //     0xab3098: stur            w0, [x1, #7]
    // 0xab309c: r0 = Builder()
    //     0xab309c: bl              #0x830cbc  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xab30a0: mov             x1, x0
    // 0xab30a4: ldur            x0, [fp, #-0x10]
    // 0xab30a8: stur            x1, [fp, #-8]
    // 0xab30ac: StoreField: r1->field_b = r0
    //     0xab30ac: stur            w0, [x1, #0xb]
    // 0xab30b0: r0 = DisplayFeatureSubScreen()
    //     0xab30b0: bl              #0xab3110  ; AllocateDisplayFeatureSubScreenStub -> DisplayFeatureSubScreen (size=0x14)
    // 0xab30b4: mov             x1, x0
    // 0xab30b8: ldur            x0, [fp, #-8]
    // 0xab30bc: StoreField: r1->field_f = r0
    //     0xab30bc: stur            w0, [x1, #0xf]
    // 0xab30c0: stp             x1, NULL, [SP, #-0x10]!
    // 0xab30c4: ldr             x16, [fp, #0x20]
    // 0xab30c8: r30 = true
    //     0xab30c8: add             lr, NULL, #0x20  ; true
    // 0xab30cc: stp             lr, x16, [SP, #-0x10]!
    // 0xab30d0: r4 = const [0, 0x4, 0x4, 0x3, removeTop, 0x3, null]
    //     0xab30d0: add             x4, PP, #0x2a, lsl #12  ; [pp+0x2ab78] List(7) [0, 0x4, 0x4, 0x3, "removeTop", 0x3, Null]
    //     0xab30d4: ldr             x4, [x4, #0xb78]
    // 0xab30d8: r0 = MediaQuery.removePadding()
    //     0xab30d8: bl              #0x8493c8  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removePadding
    // 0xab30dc: add             SP, SP, #0x20
    // 0xab30e0: mov             x1, x0
    // 0xab30e4: ldr             x0, [fp, #0x28]
    // 0xab30e8: LoadField: r2 = r0->field_7f
    //     0xab30e8: ldur            w2, [x0, #0x7f]
    // 0xab30ec: DecompressPointer r2
    //     0xab30ec: add             x2, x2, HEAP, lsl #32
    // 0xab30f0: stp             x1, x2, [SP, #-0x10]!
    // 0xab30f4: r0 = wrap()
    //     0xab30f4: bl              #0x7ccb6c  ; [package:flutter/src/widgets/inherited_theme.dart] CapturedThemes::wrap
    // 0xab30f8: add             SP, SP, #0x10
    // 0xab30fc: LeaveFrame
    //     0xab30fc: mov             SP, fp
    //     0xab3100: ldp             fp, lr, [SP], #0x10
    // 0xab3104: ret
    //     0xab3104: ret             
    // 0xab3108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xab3108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xab310c: b               #0xab305c
  }
  [closure] _ModalBottomSheet<X0> <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xab311c, size: 0x13c
    // 0xab311c: EnterFrame
    //     0xab311c: stp             fp, lr, [SP, #-0x10]!
    //     0xab3120: mov             fp, SP
    // 0xab3124: AllocStack(0x18)
    //     0xab3124: sub             SP, SP, #0x18
    // 0xab3128: SetupParameters()
    //     0xab3128: ldr             x0, [fp, #0x18]
    //     0xab312c: ldur            w1, [x0, #0x17]
    //     0xab3130: add             x1, x1, HEAP, lsl #32
    //     0xab3134: stur            x1, [fp, #-8]
    // 0xab3138: CheckStackOverflow
    //     0xab3138: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xab313c: cmp             SP, x16
    //     0xab3140: b.ls            #0xab3250
    // 0xab3144: ldr             x16, [fp, #0x10]
    // 0xab3148: SaveReg r16
    //     0xab3148: str             x16, [SP, #-8]!
    // 0xab314c: r0 = of()
    //     0xab314c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xab3150: add             SP, SP, #8
    // 0xab3154: LoadField: r1 = r0->field_af
    //     0xab3154: ldur            w1, [x0, #0xaf]
    // 0xab3158: DecompressPointer r1
    //     0xab3158: add             x1, x1, HEAP, lsl #32
    // 0xab315c: stur            x1, [fp, #-0x10]
    // 0xab3160: ldr             x16, [fp, #0x10]
    // 0xab3164: SaveReg r16
    //     0xab3164: str             x16, [SP, #-8]!
    // 0xab3168: r0 = of()
    //     0xab3168: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xab316c: add             SP, SP, #8
    // 0xab3170: LoadField: r1 = r0->field_2b
    //     0xab3170: ldur            w1, [x0, #0x2b]
    // 0xab3174: DecompressPointer r1
    //     0xab3174: add             x1, x1, HEAP, lsl #32
    // 0xab3178: tbnz            w1, #4, #0xab31ac
    // 0xab317c: ldr             x0, [fp, #0x10]
    // 0xab3180: r0 = _BottomSheetDefaultsM3()
    //     0xab3180: bl              #0x849fc8  ; Allocate_BottomSheetDefaultsM3Stub -> _BottomSheetDefaultsM3 (size=0x30)
    // 0xab3184: mov             x1, x0
    // 0xab3188: ldr             x0, [fp, #0x10]
    // 0xab318c: StoreField: r1->field_2b = r0
    //     0xab318c: stur            w0, [x1, #0x2b]
    // 0xab3190: r0 = 1.000000
    //     0xab3190: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xab3194: StoreField: r1->field_f = r0
    //     0xab3194: stur            w0, [x1, #0xf]
    // 0xab3198: StoreField: r1->field_1b = r0
    //     0xab3198: stur            w0, [x1, #0x1b]
    // 0xab319c: r0 = Instance_RoundedRectangleBorder
    //     0xab319c: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e778] Obj!RoundedRectangleBorder@b383c1
    //     0xab31a0: ldr             x0, [x0, #0x778]
    // 0xab31a4: StoreField: r1->field_1f = r0
    //     0xab31a4: stur            w0, [x1, #0x1f]
    // 0xab31a8: b               #0xab31b4
    // 0xab31ac: r1 = Instance_BottomSheetThemeData
    //     0xab31ac: add             x1, PP, #0xd, lsl #12  ; [pp+0xd040] Obj!BottomSheetThemeData@b48a61
    //     0xab31b0: ldr             x1, [x1, #0x40]
    // 0xab31b4: ldur            x0, [fp, #-0x10]
    // 0xab31b8: LoadField: r2 = r0->field_1b
    //     0xab31b8: ldur            w2, [x0, #0x1b]
    // 0xab31bc: DecompressPointer r2
    //     0xab31bc: add             x2, x2, HEAP, lsl #32
    // 0xab31c0: cmp             w2, NULL
    // 0xab31c4: b.ne            #0xab31d8
    // 0xab31c8: LoadField: r2 = r1->field_1b
    //     0xab31c8: ldur            w2, [x1, #0x1b]
    // 0xab31cc: DecompressPointer r2
    //     0xab31cc: add             x2, x2, HEAP, lsl #32
    // 0xab31d0: mov             x1, x2
    // 0xab31d4: b               #0xab31dc
    // 0xab31d8: mov             x1, x2
    // 0xab31dc: cmp             w1, NULL
    // 0xab31e0: b.ne            #0xab31f4
    // 0xab31e4: LoadField: r1 = r0->field_f
    //     0xab31e4: ldur            w1, [x0, #0xf]
    // 0xab31e8: DecompressPointer r1
    //     0xab31e8: add             x1, x1, HEAP, lsl #32
    // 0xab31ec: mov             x2, x1
    // 0xab31f0: b               #0xab31f8
    // 0xab31f4: mov             x2, x1
    // 0xab31f8: ldur            x0, [fp, #-8]
    // 0xab31fc: stur            x2, [fp, #-0x18]
    // 0xab3200: LoadField: r3 = r0->field_f
    //     0xab3200: ldur            w3, [x0, #0xf]
    // 0xab3204: DecompressPointer r3
    //     0xab3204: add             x3, x3, HEAP, lsl #32
    // 0xab3208: stur            x3, [fp, #-0x10]
    // 0xab320c: LoadField: r1 = r3->field_7
    //     0xab320c: ldur            w1, [x3, #7]
    // 0xab3210: DecompressPointer r1
    //     0xab3210: add             x1, x1, HEAP, lsl #32
    // 0xab3214: r0 = _ModalBottomSheet()
    //     0xab3214: bl              #0xab3258  ; Allocate_ModalBottomSheetStub -> _ModalBottomSheet<X0> (size=0x30)
    // 0xab3218: ldur            x1, [fp, #-0x10]
    // 0xab321c: StoreField: r0->field_f = r1
    //     0xab321c: stur            w1, [x0, #0xf]
    // 0xab3220: r1 = Instance_Color
    //     0xab3220: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xab3224: ldr             x1, [x1, #0xc08]
    // 0xab3228: StoreField: r0->field_17 = r1
    //     0xab3228: stur            w1, [x0, #0x17]
    // 0xab322c: ldur            x1, [fp, #-0x18]
    // 0xab3230: StoreField: r0->field_1b = r1
    //     0xab3230: stur            w1, [x0, #0x1b]
    // 0xab3234: r1 = false
    //     0xab3234: add             x1, NULL, #0x30  ; false
    // 0xab3238: StoreField: r0->field_13 = r1
    //     0xab3238: stur            w1, [x0, #0x13]
    // 0xab323c: r1 = true
    //     0xab323c: add             x1, NULL, #0x20  ; true
    // 0xab3240: StoreField: r0->field_2b = r1
    //     0xab3240: stur            w1, [x0, #0x2b]
    // 0xab3244: LeaveFrame
    //     0xab3244: mov             SP, fp
    //     0xab3248: ldp             fp, lr, [SP], #0x10
    // 0xab324c: ret
    //     0xab324c: ret             
    // 0xab3250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xab3250: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xab3254: b               #0xab3144
  }
  _ createAnimationController(/* No info */) {
    // ** addr: 0xab3c7c, size: 0x44
    // 0xab3c7c: r1 = false
    //     0xab3c7c: add             x1, NULL, #0x30  ; false
    // 0xab3c80: ldr             x2, [SP]
    // 0xab3c84: LoadField: r3 = r2->field_a7
    //     0xab3c84: ldur            w3, [x2, #0xa7]
    // 0xab3c88: DecompressPointer r3
    //     0xab3c88: add             x3, x3, HEAP, lsl #32
    // 0xab3c8c: mov             x0, x3
    // 0xab3c90: StoreField: r2->field_b7 = r0
    //     0xab3c90: stur            w0, [x2, #0xb7]
    //     0xab3c94: ldurb           w16, [x2, #-1]
    //     0xab3c98: ldurb           w17, [x0, #-1]
    //     0xab3c9c: and             x16, x17, x16, lsr #2
    //     0xab3ca0: tst             x16, HEAP, lsr #32
    //     0xab3ca4: b.eq            #0xab3cb4
    //     0xab3ca8: str             lr, [SP, #-8]!
    //     0xab3cac: bl              #0xd6828c
    //     0xab3cb0: ldr             lr, [SP], #8
    // 0xab3cb4: StoreField: r2->field_37 = r1
    //     0xab3cb4: stur            w1, [x2, #0x37]
    // 0xab3cb8: mov             x0, x3
    // 0xab3cbc: ret
    //     0xab3cbc: ret             
  }
  get _ barrierColor(/* No info */) {
    // ** addr: 0xd0b694, size: 0x28
    // 0xd0b694: ldr             x1, [SP]
    // 0xd0b698: LoadField: r2 = r1->field_9b
    //     0xd0b698: ldur            w2, [x1, #0x9b]
    // 0xd0b69c: DecompressPointer r2
    //     0xd0b69c: add             x2, x2, HEAP, lsl #32
    // 0xd0b6a0: cmp             w2, NULL
    // 0xd0b6a4: b.ne            #0xd0b6b4
    // 0xd0b6a8: r0 = Instance_Color
    //     0xd0b6a8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf80] Obj!Color@b5d251
    //     0xd0b6ac: ldr             x0, [x0, #0xf80]
    // 0xd0b6b0: b               #0xd0b6b8
    // 0xd0b6b4: mov             x0, x2
    // 0xd0b6b8: ret
    //     0xd0b6b8: ret             
  }
}

// class id: 2246, size: 0x18, field offset: 0xc
class _ModalBottomSheetLayout extends SingleChildLayoutDelegate {

  _ shouldRelayout(/* No info */) {
    // ** addr: 0xb101e8, size: 0x6c
    // 0xb101e8: EnterFrame
    //     0xb101e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb101ec: mov             fp, SP
    // 0xb101f0: ldr             x0, [fp, #0x10]
    // 0xb101f4: r2 = Null
    //     0xb101f4: mov             x2, NULL
    // 0xb101f8: r1 = Null
    //     0xb101f8: mov             x1, NULL
    // 0xb101fc: r4 = 59
    //     0xb101fc: mov             x4, #0x3b
    // 0xb10200: branchIfSmi(r0, 0xb1020c)
    //     0xb10200: tbz             w0, #0, #0xb1020c
    // 0xb10204: r4 = LoadClassIdInstr(r0)
    //     0xb10204: ldur            x4, [x0, #-1]
    //     0xb10208: ubfx            x4, x4, #0xc, #0x14
    // 0xb1020c: cmp             x4, #0x8c6
    // 0xb10210: b.eq            #0xb10228
    // 0xb10214: r8 = _ModalBottomSheetLayout
    //     0xb10214: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b928] Type: _ModalBottomSheetLayout
    //     0xb10218: ldr             x8, [x8, #0x928]
    // 0xb1021c: r3 = Null
    //     0xb1021c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b930] Null
    //     0xb10220: ldr             x3, [x3, #0x930]
    // 0xb10224: r0 = DefaultTypeTest()
    //     0xb10224: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xb10228: ldr             x1, [fp, #0x18]
    // 0xb1022c: LoadField: d0 = r1->field_b
    //     0xb1022c: ldur            d0, [x1, #0xb]
    // 0xb10230: ldr             x1, [fp, #0x10]
    // 0xb10234: LoadField: d1 = r1->field_b
    //     0xb10234: ldur            d1, [x1, #0xb]
    // 0xb10238: fcmp            d0, d1
    // 0xb1023c: r16 = true
    //     0xb1023c: add             x16, NULL, #0x20  ; true
    // 0xb10240: r17 = false
    //     0xb10240: add             x17, NULL, #0x30  ; false
    // 0xb10244: csel            x0, x16, x17, ne
    // 0xb10248: LeaveFrame
    //     0xb10248: mov             SP, fp
    //     0xb1024c: ldp             fp, lr, [SP], #0x10
    // 0xb10250: ret
    //     0xb10250: ret             
  }
  _ getConstraintsForChild(/* No info */) {
    // ** addr: 0xbd9794, size: 0x5c
    // 0xbd9794: EnterFrame
    //     0xbd9794: stp             fp, lr, [SP, #-0x10]!
    //     0xbd9798: mov             fp, SP
    // 0xbd979c: AllocStack(0x10)
    //     0xbd979c: sub             SP, SP, #0x10
    // 0xbd97a0: d1 = 9.000000
    //     0xbd97a0: fmov            d1, #9.00000000
    // 0xbd97a4: d0 = 16.000000
    //     0xbd97a4: fmov            d0, #16.00000000
    // 0xbd97a8: ldr             x0, [fp, #0x10]
    // 0xbd97ac: LoadField: d2 = r0->field_f
    //     0xbd97ac: ldur            d2, [x0, #0xf]
    // 0xbd97b0: stur            d2, [fp, #-0x10]
    // 0xbd97b4: LoadField: d3 = r0->field_1f
    //     0xbd97b4: ldur            d3, [x0, #0x1f]
    // 0xbd97b8: fmul            d4, d3, d1
    // 0xbd97bc: fdiv            d1, d4, d0
    // 0xbd97c0: stur            d1, [fp, #-8]
    // 0xbd97c4: r0 = BoxConstraints()
    //     0xbd97c4: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbd97c8: ldur            d0, [fp, #-0x10]
    // 0xbd97cc: StoreField: r0->field_7 = d0
    //     0xbd97cc: stur            d0, [x0, #7]
    // 0xbd97d0: StoreField: r0->field_f = d0
    //     0xbd97d0: stur            d0, [x0, #0xf]
    // 0xbd97d4: d0 = 0.000000
    //     0xbd97d4: eor             v0.16b, v0.16b, v0.16b
    // 0xbd97d8: StoreField: r0->field_17 = d0
    //     0xbd97d8: stur            d0, [x0, #0x17]
    // 0xbd97dc: ldur            d0, [fp, #-8]
    // 0xbd97e0: StoreField: r0->field_1f = d0
    //     0xbd97e0: stur            d0, [x0, #0x1f]
    // 0xbd97e4: LeaveFrame
    //     0xbd97e4: mov             SP, fp
    //     0xbd97e8: ldp             fp, lr, [SP], #0x10
    // 0xbd97ec: ret
    //     0xbd97ec: ret             
  }
}

// class id: 2836, size: 0x30, field offset: 0x2c
//   const constructor, 
class _BottomSheetDefaultsM3 extends BottomSheetThemeData {
}

// class id: 3338, size: 0x18, field offset: 0x14
class _ModalBottomSheetState<_ModalBottomSheet<C1X0>> extends State<_ModalBottomSheet<C1X0>> {

  _ build(/* No info */) {
    // ** addr: 0x84a798, size: 0x208
    // 0x84a798: EnterFrame
    //     0x84a798: stp             fp, lr, [SP, #-0x10]!
    //     0x84a79c: mov             fp, SP
    // 0x84a7a0: AllocStack(0x48)
    //     0x84a7a0: sub             SP, SP, #0x48
    // 0x84a7a4: CheckStackOverflow
    //     0x84a7a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a7a8: cmp             SP, x16
    //     0x84a7ac: b.ls            #0x84a990
    // 0x84a7b0: r1 = 4
    //     0x84a7b0: mov             x1, #4
    // 0x84a7b4: r0 = AllocateContext()
    //     0x84a7b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84a7b8: mov             x1, x0
    // 0x84a7bc: ldr             x0, [fp, #0x18]
    // 0x84a7c0: stur            x1, [fp, #-8]
    // 0x84a7c4: StoreField: r1->field_f = r0
    //     0x84a7c4: stur            w0, [x1, #0xf]
    // 0x84a7c8: ldr             x2, [fp, #0x10]
    // 0x84a7cc: StoreField: r1->field_13 = r2
    //     0x84a7cc: stur            w2, [x1, #0x13]
    // 0x84a7d0: SaveReg r2
    //     0x84a7d0: str             x2, [SP, #-8]!
    // 0x84a7d4: r0 = of()
    //     0x84a7d4: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x84a7d8: add             SP, SP, #8
    // 0x84a7dc: ldur            x2, [fp, #-8]
    // 0x84a7e0: StoreField: r2->field_17 = r0
    //     0x84a7e0: stur            w0, [x2, #0x17]
    //     0x84a7e4: ldurb           w16, [x2, #-1]
    //     0x84a7e8: ldurb           w17, [x0, #-1]
    //     0x84a7ec: and             x16, x17, x16, lsr #2
    //     0x84a7f0: tst             x16, HEAP, lsr #32
    //     0x84a7f4: b.eq            #0x84a7fc
    //     0x84a7f8: bl              #0xd6828c
    // 0x84a7fc: ldr             x16, [fp, #0x10]
    // 0x84a800: SaveReg r16
    //     0x84a800: str             x16, [SP, #-8]!
    // 0x84a804: r0 = of()
    //     0x84a804: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x84a808: add             SP, SP, #8
    // 0x84a80c: ldr             x16, [fp, #0x18]
    // 0x84a810: stp             x0, x16, [SP, #-0x10]!
    // 0x84a814: r0 = _getRouteLabel()
    //     0x84a814: bl              #0x84a9ac  ; [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::_getRouteLabel
    // 0x84a818: add             SP, SP, #0x10
    // 0x84a81c: ldur            x2, [fp, #-8]
    // 0x84a820: StoreField: r2->field_1b = r0
    //     0x84a820: stur            w0, [x2, #0x1b]
    //     0x84a824: ldurb           w16, [x2, #-1]
    //     0x84a828: ldurb           w17, [x0, #-1]
    //     0x84a82c: and             x16, x17, x16, lsr #2
    //     0x84a830: tst             x16, HEAP, lsr #32
    //     0x84a834: b.eq            #0x84a83c
    //     0x84a838: bl              #0xd6828c
    // 0x84a83c: ldr             x0, [fp, #0x18]
    // 0x84a840: LoadField: r1 = r0->field_b
    //     0x84a840: ldur            w1, [x0, #0xb]
    // 0x84a844: DecompressPointer r1
    //     0x84a844: add             x1, x1, HEAP, lsl #32
    // 0x84a848: cmp             w1, NULL
    // 0x84a84c: b.eq            #0x84a998
    // 0x84a850: LoadField: r3 = r1->field_f
    //     0x84a850: ldur            w3, [x1, #0xf]
    // 0x84a854: DecompressPointer r3
    //     0x84a854: add             x3, x3, HEAP, lsl #32
    // 0x84a858: LoadField: r4 = r3->field_57
    //     0x84a858: ldur            w4, [x3, #0x57]
    // 0x84a85c: DecompressPointer r4
    //     0x84a85c: add             x4, x4, HEAP, lsl #32
    // 0x84a860: stur            x4, [fp, #-0x30]
    // 0x84a864: cmp             w4, NULL
    // 0x84a868: b.eq            #0x84a99c
    // 0x84a86c: LoadField: r5 = r3->field_b7
    //     0x84a86c: ldur            w5, [x3, #0xb7]
    // 0x84a870: DecompressPointer r5
    //     0x84a870: add             x5, x5, HEAP, lsl #32
    // 0x84a874: stur            x5, [fp, #-0x28]
    // 0x84a878: LoadField: r6 = r3->field_7b
    //     0x84a878: ldur            w6, [x3, #0x7b]
    // 0x84a87c: DecompressPointer r6
    //     0x84a87c: add             x6, x6, HEAP, lsl #32
    // 0x84a880: stur            x6, [fp, #-0x20]
    // 0x84a884: LoadField: r3 = r1->field_17
    //     0x84a884: ldur            w3, [x1, #0x17]
    // 0x84a888: DecompressPointer r3
    //     0x84a888: add             x3, x3, HEAP, lsl #32
    // 0x84a88c: stur            x3, [fp, #-0x18]
    // 0x84a890: LoadField: r7 = r1->field_1b
    //     0x84a890: ldur            w7, [x1, #0x1b]
    // 0x84a894: DecompressPointer r7
    //     0x84a894: add             x7, x7, HEAP, lsl #32
    // 0x84a898: stur            x7, [fp, #-0x10]
    // 0x84a89c: r1 = 1
    //     0x84a89c: mov             x1, #1
    // 0x84a8a0: r0 = AllocateContext()
    //     0x84a8a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84a8a4: mov             x1, x0
    // 0x84a8a8: ldr             x0, [fp, #0x18]
    // 0x84a8ac: stur            x1, [fp, #-0x38]
    // 0x84a8b0: StoreField: r1->field_f = r0
    //     0x84a8b0: stur            w0, [x1, #0xf]
    // 0x84a8b4: r1 = 1
    //     0x84a8b4: mov             x1, #1
    // 0x84a8b8: r0 = AllocateContext()
    //     0x84a8b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84a8bc: mov             x1, x0
    // 0x84a8c0: ldr             x0, [fp, #0x18]
    // 0x84a8c4: stur            x1, [fp, #-0x40]
    // 0x84a8c8: StoreField: r1->field_f = r0
    //     0x84a8c8: stur            w0, [x1, #0xf]
    // 0x84a8cc: r0 = BottomSheet()
    //     0x84a8cc: bl              #0x84a9a0  ; AllocateBottomSheetStub -> BottomSheet (size=0x38)
    // 0x84a8d0: mov             x3, x0
    // 0x84a8d4: ldur            x0, [fp, #-0x28]
    // 0x84a8d8: stur            x3, [fp, #-0x48]
    // 0x84a8dc: StoreField: r3->field_b = r0
    //     0x84a8dc: stur            w0, [x3, #0xb]
    // 0x84a8e0: r0 = true
    //     0x84a8e0: add             x0, NULL, #0x20  ; true
    // 0x84a8e4: StoreField: r3->field_17 = r0
    //     0x84a8e4: stur            w0, [x3, #0x17]
    // 0x84a8e8: ldur            x2, [fp, #-0x38]
    // 0x84a8ec: r1 = Function 'handleDragStart':.
    //     0x84a8ec: add             x1, PP, #0x40, lsl #12  ; [pp+0x40260] AnonymousClosure: (0x84ae98), of [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState
    //     0x84a8f0: ldr             x1, [x1, #0x260]
    // 0x84a8f4: r0 = AllocateClosure()
    //     0x84a8f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84a8f8: mov             x1, x0
    // 0x84a8fc: ldur            x0, [fp, #-0x48]
    // 0x84a900: StoreField: r0->field_1b = r1
    //     0x84a900: stur            w1, [x0, #0x1b]
    // 0x84a904: ldur            x2, [fp, #-0x40]
    // 0x84a908: r1 = Function 'handleDragEnd':.
    //     0x84a908: add             x1, PP, #0x40, lsl #12  ; [pp+0x40268] AnonymousClosure: (0x84ad18), in [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::handleDragEnd (0x84adc0)
    //     0x84a90c: ldr             x1, [x1, #0x268]
    // 0x84a910: r0 = AllocateClosure()
    //     0x84a910: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84a914: mov             x1, x0
    // 0x84a918: ldur            x0, [fp, #-0x48]
    // 0x84a91c: StoreField: r0->field_1f = r1
    //     0x84a91c: stur            w1, [x0, #0x1f]
    // 0x84a920: ldur            x1, [fp, #-0x18]
    // 0x84a924: StoreField: r0->field_23 = r1
    //     0x84a924: stur            w1, [x0, #0x23]
    // 0x84a928: ldur            x1, [fp, #-0x10]
    // 0x84a92c: StoreField: r0->field_27 = r1
    //     0x84a92c: stur            w1, [x0, #0x27]
    // 0x84a930: ldur            x2, [fp, #-8]
    // 0x84a934: r1 = Function '<anonymous closure>':.
    //     0x84a934: add             x1, PP, #0x40, lsl #12  ; [pp+0x40270] AnonymousClosure: (0x84abf4), in [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::build (0x84a798)
    //     0x84a938: ldr             x1, [x1, #0x270]
    // 0x84a93c: r0 = AllocateClosure()
    //     0x84a93c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84a940: mov             x1, x0
    // 0x84a944: ldur            x0, [fp, #-0x48]
    // 0x84a948: StoreField: r0->field_f = r1
    //     0x84a948: stur            w1, [x0, #0xf]
    // 0x84a94c: ldur            x1, [fp, #-0x20]
    // 0x84a950: StoreField: r0->field_13 = r1
    //     0x84a950: stur            w1, [x0, #0x13]
    // 0x84a954: ldur            x2, [fp, #-8]
    // 0x84a958: r1 = Function '<anonymous closure>':.
    //     0x84a958: add             x1, PP, #0x40, lsl #12  ; [pp+0x40278] AnonymousClosure: (0x84aa40), in [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::build (0x84a798)
    //     0x84a95c: ldr             x1, [x1, #0x278]
    // 0x84a960: r0 = AllocateClosure()
    //     0x84a960: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84a964: stur            x0, [fp, #-8]
    // 0x84a968: r0 = AnimatedBuilder()
    //     0x84a968: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x84a96c: ldur            x1, [fp, #-8]
    // 0x84a970: StoreField: r0->field_f = r1
    //     0x84a970: stur            w1, [x0, #0xf]
    // 0x84a974: ldur            x1, [fp, #-0x48]
    // 0x84a978: StoreField: r0->field_13 = r1
    //     0x84a978: stur            w1, [x0, #0x13]
    // 0x84a97c: ldur            x1, [fp, #-0x30]
    // 0x84a980: StoreField: r0->field_b = r1
    //     0x84a980: stur            w1, [x0, #0xb]
    // 0x84a984: LeaveFrame
    //     0x84a984: mov             SP, fp
    //     0x84a988: ldp             fp, lr, [SP], #0x10
    // 0x84a98c: ret
    //     0x84a98c: ret             
    // 0x84a990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a990: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a994: b               #0x84a7b0
    // 0x84a998: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a998: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84a99c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a99c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getRouteLabel(/* No info */) {
    // ** addr: 0x84a9ac, size: 0x94
    // 0x84a9ac: EnterFrame
    //     0x84a9ac: stp             fp, lr, [SP, #-0x10]!
    //     0x84a9b0: mov             fp, SP
    // 0x84a9b4: CheckStackOverflow
    //     0x84a9b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a9b8: cmp             SP, x16
    //     0x84a9bc: b.ls            #0x84aa34
    // 0x84a9c0: ldr             x0, [fp, #0x18]
    // 0x84a9c4: LoadField: r1 = r0->field_f
    //     0x84a9c4: ldur            w1, [x0, #0xf]
    // 0x84a9c8: DecompressPointer r1
    //     0x84a9c8: add             x1, x1, HEAP, lsl #32
    // 0x84a9cc: cmp             w1, NULL
    // 0x84a9d0: b.eq            #0x84aa3c
    // 0x84a9d4: SaveReg r1
    //     0x84a9d4: str             x1, [SP, #-8]!
    // 0x84a9d8: r0 = of()
    //     0x84a9d8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84a9dc: add             SP, SP, #8
    // 0x84a9e0: LoadField: r1 = r0->field_1f
    //     0x84a9e0: ldur            w1, [x0, #0x1f]
    // 0x84a9e4: DecompressPointer r1
    //     0x84a9e4: add             x1, x1, HEAP, lsl #32
    // 0x84a9e8: LoadField: r2 = r1->field_7
    //     0x84a9e8: ldur            x2, [x1, #7]
    // 0x84a9ec: cmp             x2, #2
    // 0x84a9f0: b.gt            #0x84aa00
    // 0x84a9f4: cmp             x2, #1
    // 0x84a9f8: b.gt            #0x84aa10
    // 0x84a9fc: b               #0x84aa20
    // 0x84aa00: cmp             x2, #4
    // 0x84aa04: b.gt            #0x84aa20
    // 0x84aa08: cmp             x2, #3
    // 0x84aa0c: b.le            #0x84aa20
    // 0x84aa10: r0 = ""
    //     0x84aa10: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x84aa14: LeaveFrame
    //     0x84aa14: mov             SP, fp
    //     0x84aa18: ldp             fp, lr, [SP], #0x10
    // 0x84aa1c: ret
    //     0x84aa1c: ret             
    // 0x84aa20: r0 = "Dialog"
    //     0x84aa20: add             x0, PP, #0x3b, lsl #12  ; [pp+0x3bc70] "Dialog"
    //     0x84aa24: ldr             x0, [x0, #0xc70]
    // 0x84aa28: LeaveFrame
    //     0x84aa28: mov             SP, fp
    //     0x84aa2c: ldp             fp, lr, [SP], #0x10
    // 0x84aa30: ret
    //     0x84aa30: ret             
    // 0x84aa34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84aa34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84aa38: b               #0x84a9c0
    // 0x84aa3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84aa3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Semantics <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x84aa40, size: 0x1a8
    // 0x84aa40: EnterFrame
    //     0x84aa40: stp             fp, lr, [SP, #-0x10]!
    //     0x84aa44: mov             fp, SP
    // 0x84aa48: AllocStack(0x20)
    //     0x84aa48: sub             SP, SP, #0x20
    // 0x84aa4c: SetupParameters()
    //     0x84aa4c: ldr             x0, [fp, #0x20]
    //     0x84aa50: ldur            w1, [x0, #0x17]
    //     0x84aa54: add             x1, x1, HEAP, lsl #32
    //     0x84aa58: stur            x1, [fp, #-0x10]
    // 0x84aa5c: CheckStackOverflow
    //     0x84aa5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84aa60: cmp             SP, x16
    //     0x84aa64: b.ls            #0x84abd4
    // 0x84aa68: LoadField: r0 = r1->field_f
    //     0x84aa68: ldur            w0, [x1, #0xf]
    // 0x84aa6c: DecompressPointer r0
    //     0x84aa6c: add             x0, x0, HEAP, lsl #32
    // 0x84aa70: LoadField: r2 = r0->field_13
    //     0x84aa70: ldur            w2, [x0, #0x13]
    // 0x84aa74: DecompressPointer r2
    //     0x84aa74: add             x2, x2, HEAP, lsl #32
    // 0x84aa78: stur            x2, [fp, #-8]
    // 0x84aa7c: LoadField: r3 = r1->field_17
    //     0x84aa7c: ldur            w3, [x1, #0x17]
    // 0x84aa80: DecompressPointer r3
    //     0x84aa80: add             x3, x3, HEAP, lsl #32
    // 0x84aa84: LoadField: r4 = r3->field_33
    //     0x84aa84: ldur            w4, [x3, #0x33]
    // 0x84aa88: DecompressPointer r4
    //     0x84aa88: add             x4, x4, HEAP, lsl #32
    // 0x84aa8c: tbnz            w4, #4, #0x84aa9c
    // 0x84aa90: mov             x0, x2
    // 0x84aa94: d0 = 1.000000
    //     0x84aa94: fmov            d0, #1.00000000
    // 0x84aa98: b               #0x84aadc
    // 0x84aa9c: LoadField: r3 = r0->field_b
    //     0x84aa9c: ldur            w3, [x0, #0xb]
    // 0x84aaa0: DecompressPointer r3
    //     0x84aaa0: add             x3, x3, HEAP, lsl #32
    // 0x84aaa4: cmp             w3, NULL
    // 0x84aaa8: b.eq            #0x84abdc
    // 0x84aaac: LoadField: r0 = r3->field_f
    //     0x84aaac: ldur            w0, [x3, #0xf]
    // 0x84aab0: DecompressPointer r0
    //     0x84aab0: add             x0, x0, HEAP, lsl #32
    // 0x84aab4: LoadField: r3 = r0->field_57
    //     0x84aab4: ldur            w3, [x0, #0x57]
    // 0x84aab8: DecompressPointer r3
    //     0x84aab8: add             x3, x3, HEAP, lsl #32
    // 0x84aabc: cmp             w3, NULL
    // 0x84aac0: b.eq            #0x84abe0
    // 0x84aac4: SaveReg r3
    //     0x84aac4: str             x3, [SP, #-8]!
    // 0x84aac8: r0 = value()
    //     0x84aac8: bl              #0xc24c94  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::value
    // 0x84aacc: add             SP, SP, #8
    // 0x84aad0: LoadField: d0 = r0->field_7
    //     0x84aad0: ldur            d0, [x0, #7]
    // 0x84aad4: ldur            x1, [fp, #-0x10]
    // 0x84aad8: ldur            x0, [fp, #-8]
    // 0x84aadc: ldr             x2, [fp, #0x10]
    // 0x84aae0: r3 = LoadClassIdInstr(r0)
    //     0x84aae0: ldur            x3, [x0, #-1]
    //     0x84aae4: ubfx            x3, x3, #0xc, #0x14
    // 0x84aae8: SaveReg r0
    //     0x84aae8: str             x0, [SP, #-8]!
    // 0x84aaec: SaveReg d0
    //     0x84aaec: str             d0, [SP, #-8]!
    // 0x84aaf0: mov             x0, x3
    // 0x84aaf4: r0 = GDT[cid_x0 + 0x87f]()
    //     0x84aaf4: add             lr, x0, #0x87f
    //     0x84aaf8: ldr             lr, [x21, lr, lsl #3]
    //     0x84aafc: blr             lr
    // 0x84ab00: add             SP, SP, #0x10
    // 0x84ab04: mov             x1, x0
    // 0x84ab08: ldur            x0, [fp, #-0x10]
    // 0x84ab0c: LoadField: r2 = r0->field_1b
    //     0x84ab0c: ldur            w2, [x0, #0x1b]
    // 0x84ab10: DecompressPointer r2
    //     0x84ab10: add             x2, x2, HEAP, lsl #32
    // 0x84ab14: stur            x2, [fp, #-8]
    // 0x84ab18: LoadField: r3 = r0->field_f
    //     0x84ab18: ldur            w3, [x0, #0xf]
    // 0x84ab1c: DecompressPointer r3
    //     0x84ab1c: add             x3, x3, HEAP, lsl #32
    // 0x84ab20: LoadField: r0 = r3->field_b
    //     0x84ab20: ldur            w0, [x3, #0xb]
    // 0x84ab24: DecompressPointer r0
    //     0x84ab24: add             x0, x0, HEAP, lsl #32
    // 0x84ab28: cmp             w0, NULL
    // 0x84ab2c: b.eq            #0x84abe4
    // 0x84ab30: LoadField: d0 = r1->field_7
    //     0x84ab30: ldur            d0, [x1, #7]
    // 0x84ab34: stur            d0, [fp, #-0x20]
    // 0x84ab38: r0 = _ModalBottomSheetLayout()
    //     0x84ab38: bl              #0x84abe8  ; Allocate_ModalBottomSheetLayoutStub -> _ModalBottomSheetLayout (size=0x18)
    // 0x84ab3c: ldur            d0, [fp, #-0x20]
    // 0x84ab40: stur            x0, [fp, #-0x10]
    // 0x84ab44: StoreField: r0->field_b = d0
    //     0x84ab44: stur            d0, [x0, #0xb]
    // 0x84ab48: r1 = false
    //     0x84ab48: add             x1, NULL, #0x30  ; false
    // 0x84ab4c: StoreField: r0->field_13 = r1
    //     0x84ab4c: stur            w1, [x0, #0x13]
    // 0x84ab50: r0 = CustomSingleChildLayout()
    //     0x84ab50: bl              #0x847d64  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0x84ab54: mov             x1, x0
    // 0x84ab58: ldur            x0, [fp, #-0x10]
    // 0x84ab5c: stur            x1, [fp, #-0x18]
    // 0x84ab60: StoreField: r1->field_f = r0
    //     0x84ab60: stur            w0, [x1, #0xf]
    // 0x84ab64: ldr             x0, [fp, #0x10]
    // 0x84ab68: StoreField: r1->field_b = r0
    //     0x84ab68: stur            w0, [x1, #0xb]
    // 0x84ab6c: r0 = ClipRect()
    //     0x84ab6c: bl              #0x847d58  ; AllocateClipRectStub -> ClipRect (size=0x18)
    // 0x84ab70: mov             x1, x0
    // 0x84ab74: r0 = Instance_Clip
    //     0x84ab74: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x84ab78: ldr             x0, [x0, #0x678]
    // 0x84ab7c: stur            x1, [fp, #-0x10]
    // 0x84ab80: StoreField: r1->field_13 = r0
    //     0x84ab80: stur            w0, [x1, #0x13]
    // 0x84ab84: ldur            x0, [fp, #-0x18]
    // 0x84ab88: StoreField: r1->field_b = r0
    //     0x84ab88: stur            w0, [x1, #0xb]
    // 0x84ab8c: r0 = Semantics()
    //     0x84ab8c: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x84ab90: stur            x0, [fp, #-0x18]
    // 0x84ab94: r16 = true
    //     0x84ab94: add             x16, NULL, #0x20  ; true
    // 0x84ab98: stp             x16, x0, [SP, #-0x10]!
    // 0x84ab9c: r16 = true
    //     0x84ab9c: add             x16, NULL, #0x20  ; true
    // 0x84aba0: ldur            lr, [fp, #-8]
    // 0x84aba4: stp             lr, x16, [SP, #-0x10]!
    // 0x84aba8: r16 = true
    //     0x84aba8: add             x16, NULL, #0x20  ; true
    // 0x84abac: ldur            lr, [fp, #-0x10]
    // 0x84abb0: stp             lr, x16, [SP, #-0x10]!
    // 0x84abb4: r4 = const [0, 0x6, 0x6, 0x1, child, 0x5, explicitChildNodes, 0x4, label, 0x3, namesRoute, 0x2, scopesRoute, 0x1, null]
    //     0x84abb4: add             x4, PP, #0x3b, lsl #12  ; [pp+0x3bc68] List(15) [0, 0x6, 0x6, 0x1, "child", 0x5, "explicitChildNodes", 0x4, "label", 0x3, "namesRoute", 0x2, "scopesRoute", 0x1, Null]
    //     0x84abb8: ldr             x4, [x4, #0xc68]
    // 0x84abbc: r0 = Semantics()
    //     0x84abbc: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x84abc0: add             SP, SP, #0x30
    // 0x84abc4: ldur            x0, [fp, #-0x18]
    // 0x84abc8: LeaveFrame
    //     0x84abc8: mov             SP, fp
    //     0x84abcc: ldp             fp, lr, [SP], #0x10
    // 0x84abd0: ret
    //     0x84abd0: ret             
    // 0x84abd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84abd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84abd8: b               #0x84aa68
    // 0x84abdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84abdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84abe0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84abe0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84abe4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84abe4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84abf4, size: 0x94
    // 0x84abf4: EnterFrame
    //     0x84abf4: stp             fp, lr, [SP, #-0x10]!
    //     0x84abf8: mov             fp, SP
    // 0x84abfc: AllocStack(0x8)
    //     0x84abfc: sub             SP, SP, #8
    // 0x84ac00: SetupParameters()
    //     0x84ac00: ldr             x0, [fp, #0x10]
    //     0x84ac04: ldur            w1, [x0, #0x17]
    //     0x84ac08: add             x1, x1, HEAP, lsl #32
    //     0x84ac0c: stur            x1, [fp, #-8]
    // 0x84ac10: CheckStackOverflow
    //     0x84ac10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84ac14: cmp             SP, x16
    //     0x84ac18: b.ls            #0x84ac7c
    // 0x84ac1c: LoadField: r0 = r1->field_f
    //     0x84ac1c: ldur            w0, [x1, #0xf]
    // 0x84ac20: DecompressPointer r0
    //     0x84ac20: add             x0, x0, HEAP, lsl #32
    // 0x84ac24: LoadField: r2 = r0->field_b
    //     0x84ac24: ldur            w2, [x0, #0xb]
    // 0x84ac28: DecompressPointer r2
    //     0x84ac28: add             x2, x2, HEAP, lsl #32
    // 0x84ac2c: cmp             w2, NULL
    // 0x84ac30: b.eq            #0x84ac84
    // 0x84ac34: LoadField: r0 = r2->field_f
    //     0x84ac34: ldur            w0, [x2, #0xf]
    // 0x84ac38: DecompressPointer r0
    //     0x84ac38: add             x0, x0, HEAP, lsl #32
    // 0x84ac3c: SaveReg r0
    //     0x84ac3c: str             x0, [SP, #-8]!
    // 0x84ac40: r0 = isCurrent()
    //     0x84ac40: bl              #0x6fa054  ; [package:flutter/src/widgets/navigator.dart] Route::isCurrent
    // 0x84ac44: add             SP, SP, #8
    // 0x84ac48: tbnz            w0, #4, #0x84ac6c
    // 0x84ac4c: ldur            x0, [fp, #-8]
    // 0x84ac50: LoadField: r1 = r0->field_13
    //     0x84ac50: ldur            w1, [x0, #0x13]
    // 0x84ac54: DecompressPointer r1
    //     0x84ac54: add             x1, x1, HEAP, lsl #32
    // 0x84ac58: r16 = <Object?>
    //     0x84ac58: ldr             x16, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0x84ac5c: stp             x1, x16, [SP, #-0x10]!
    // 0x84ac60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84ac60: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84ac64: r0 = pop()
    //     0x84ac64: bl              #0x84ac88  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0x84ac68: add             SP, SP, #0x10
    // 0x84ac6c: r0 = Null
    //     0x84ac6c: mov             x0, NULL
    // 0x84ac70: LeaveFrame
    //     0x84ac70: mov             SP, fp
    //     0x84ac74: ldp             fp, lr, [SP], #0x10
    // 0x84ac78: ret
    //     0x84ac78: ret             
    // 0x84ac7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ac7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ac80: b               #0x84ac1c
    // 0x84ac84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84ac84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleDragEnd(dynamic, DragEndDetails, {bool? isClosing}) {
    // ** addr: 0x84ad18, size: 0xa8
    // 0x84ad18: EnterFrame
    //     0x84ad18: stp             fp, lr, [SP, #-0x10]!
    //     0x84ad1c: mov             fp, SP
    // 0x84ad20: mov             x0, x4
    // 0x84ad24: LoadField: r1 = r0->field_13
    //     0x84ad24: ldur            w1, [x0, #0x13]
    // 0x84ad28: DecompressPointer r1
    //     0x84ad28: add             x1, x1, HEAP, lsl #32
    // 0x84ad2c: sub             x2, x1, #4
    // 0x84ad30: add             x3, fp, w2, sxtw #2
    // 0x84ad34: ldr             x3, [x3, #0x18]
    // 0x84ad38: add             x4, fp, w2, sxtw #2
    // 0x84ad3c: ldr             x4, [x4, #0x10]
    // 0x84ad40: LoadField: r2 = r0->field_1f
    //     0x84ad40: ldur            w2, [x0, #0x1f]
    // 0x84ad44: DecompressPointer r2
    //     0x84ad44: add             x2, x2, HEAP, lsl #32
    // 0x84ad48: r16 = "isClosing"
    //     0x84ad48: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e160] "isClosing"
    //     0x84ad4c: ldr             x16, [x16, #0x160]
    // 0x84ad50: cmp             w2, w16
    // 0x84ad54: b.ne            #0x84ad74
    // 0x84ad58: LoadField: r2 = r0->field_23
    //     0x84ad58: ldur            w2, [x0, #0x23]
    // 0x84ad5c: DecompressPointer r2
    //     0x84ad5c: add             x2, x2, HEAP, lsl #32
    // 0x84ad60: sub             w0, w1, w2
    // 0x84ad64: add             x1, fp, w0, sxtw #2
    // 0x84ad68: ldr             x1, [x1, #8]
    // 0x84ad6c: mov             x0, x1
    // 0x84ad70: b               #0x84ad78
    // 0x84ad74: r0 = Null
    //     0x84ad74: mov             x0, NULL
    // 0x84ad78: LoadField: r1 = r3->field_17
    //     0x84ad78: ldur            w1, [x3, #0x17]
    // 0x84ad7c: DecompressPointer r1
    //     0x84ad7c: add             x1, x1, HEAP, lsl #32
    // 0x84ad80: CheckStackOverflow
    //     0x84ad80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84ad84: cmp             SP, x16
    //     0x84ad88: b.ls            #0x84adb8
    // 0x84ad8c: LoadField: r2 = r1->field_f
    //     0x84ad8c: ldur            w2, [x1, #0xf]
    // 0x84ad90: DecompressPointer r2
    //     0x84ad90: add             x2, x2, HEAP, lsl #32
    // 0x84ad94: stp             x4, x2, [SP, #-0x10]!
    // 0x84ad98: SaveReg r0
    //     0x84ad98: str             x0, [SP, #-8]!
    // 0x84ad9c: r4 = const [0, 0x3, 0x3, 0x2, isClosing, 0x2, null]
    //     0x84ad9c: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e168] List(7) [0, 0x3, 0x3, 0x2, "isClosing", 0x2, Null]
    //     0x84ada0: ldr             x4, [x4, #0x168]
    // 0x84ada4: r0 = handleDragEnd()
    //     0x84ada4: bl              #0x84adc0  ; [package:flutter/src/material/bottom_sheet.dart] _ModalBottomSheetState::handleDragEnd
    // 0x84ada8: add             SP, SP, #0x18
    // 0x84adac: LeaveFrame
    //     0x84adac: mov             SP, fp
    //     0x84adb0: ldp             fp, lr, [SP], #0x10
    // 0x84adb4: ret
    //     0x84adb4: ret             
    // 0x84adb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84adb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84adbc: b               #0x84ad8c
  }
  _ handleDragEnd(/* No info */) {
    // ** addr: 0x84adc0, size: 0xcc
    // 0x84adc0: EnterFrame
    //     0x84adc0: stp             fp, lr, [SP, #-0x10]!
    //     0x84adc4: mov             fp, SP
    // 0x84adc8: AllocStack(0x10)
    //     0x84adc8: sub             SP, SP, #0x10
    // 0x84adcc: SetupParameters(_ModalBottomSheetState<_ModalBottomSheet<C1X0>, C1X0> this /* r1, fp-0x8 */)
    //     0x84adcc: mov             x0, x4
    //     0x84add0: ldur            w1, [x0, #0x13]
    //     0x84add4: add             x1, x1, HEAP, lsl #32
    //     0x84add8: sub             x0, x1, #4
    //     0x84addc: add             x1, fp, w0, sxtw #2
    //     0x84ade0: ldr             x1, [x1, #0x18]
    //     0x84ade4: stur            x1, [fp, #-8]
    // 0x84ade8: CheckStackOverflow
    //     0x84ade8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84adec: cmp             SP, x16
    //     0x84adf0: b.ls            #0x84ae7c
    // 0x84adf4: LoadField: r0 = r1->field_b
    //     0x84adf4: ldur            w0, [x1, #0xb]
    // 0x84adf8: DecompressPointer r0
    //     0x84adf8: add             x0, x0, HEAP, lsl #32
    // 0x84adfc: cmp             w0, NULL
    // 0x84ae00: b.eq            #0x84ae84
    // 0x84ae04: LoadField: r2 = r0->field_f
    //     0x84ae04: ldur            w2, [x0, #0xf]
    // 0x84ae08: DecompressPointer r2
    //     0x84ae08: add             x2, x2, HEAP, lsl #32
    // 0x84ae0c: LoadField: r0 = r2->field_57
    //     0x84ae0c: ldur            w0, [x2, #0x57]
    // 0x84ae10: DecompressPointer r0
    //     0x84ae10: add             x0, x0, HEAP, lsl #32
    // 0x84ae14: cmp             w0, NULL
    // 0x84ae18: b.eq            #0x84ae88
    // 0x84ae1c: SaveReg r0
    //     0x84ae1c: str             x0, [SP, #-8]!
    // 0x84ae20: r0 = value()
    //     0x84ae20: bl              #0xc24c94  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::value
    // 0x84ae24: add             SP, SP, #8
    // 0x84ae28: LoadField: d0 = r0->field_7
    //     0x84ae28: ldur            d0, [x0, #7]
    // 0x84ae2c: stur            d0, [fp, #-0x10]
    // 0x84ae30: r1 = <double>
    //     0x84ae30: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x84ae34: r0 = _BottomSheetSuspendedCurve()
    //     0x84ae34: bl              #0x84ae8c  ; Allocate_BottomSheetSuspendedCurveStub -> _BottomSheetSuspendedCurve (size=0x18)
    // 0x84ae38: ldur            d0, [fp, #-0x10]
    // 0x84ae3c: StoreField: r0->field_b = d0
    //     0x84ae3c: stur            d0, [x0, #0xb]
    // 0x84ae40: r1 = Instance_Cubic
    //     0x84ae40: add             x1, PP, #0x37, lsl #12  ; [pp+0x37978] Obj!Cubic<double>@b4f491
    //     0x84ae44: ldr             x1, [x1, #0x978]
    // 0x84ae48: StoreField: r0->field_13 = r1
    //     0x84ae48: stur            w1, [x0, #0x13]
    // 0x84ae4c: ldur            x1, [fp, #-8]
    // 0x84ae50: StoreField: r1->field_13 = r0
    //     0x84ae50: stur            w0, [x1, #0x13]
    //     0x84ae54: ldurb           w16, [x1, #-1]
    //     0x84ae58: ldurb           w17, [x0, #-1]
    //     0x84ae5c: and             x16, x17, x16, lsr #2
    //     0x84ae60: tst             x16, HEAP, lsr #32
    //     0x84ae64: b.eq            #0x84ae6c
    //     0x84ae68: bl              #0xd6826c
    // 0x84ae6c: r0 = Null
    //     0x84ae6c: mov             x0, NULL
    // 0x84ae70: LeaveFrame
    //     0x84ae70: mov             SP, fp
    //     0x84ae74: ldp             fp, lr, [SP], #0x10
    // 0x84ae78: ret
    //     0x84ae78: ret             
    // 0x84ae7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ae7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ae80: b               #0x84adf4
    // 0x84ae84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84ae84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84ae88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84ae88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3339, size: 0x18, field offset: 0x14
class _BottomSheetState extends State<BottomSheet> {

  _ build(/* No info */) {
    // ** addr: 0x849b34, size: 0x494
    // 0x849b34: EnterFrame
    //     0x849b34: stp             fp, lr, [SP, #-0x10]!
    //     0x849b38: mov             fp, SP
    // 0x849b3c: AllocStack(0x48)
    //     0x849b3c: sub             SP, SP, #0x48
    // 0x849b40: CheckStackOverflow
    //     0x849b40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x849b44: cmp             SP, x16
    //     0x849b48: b.ls            #0x849fb4
    // 0x849b4c: ldr             x16, [fp, #0x10]
    // 0x849b50: SaveReg r16
    //     0x849b50: str             x16, [SP, #-8]!
    // 0x849b54: r0 = of()
    //     0x849b54: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x849b58: add             SP, SP, #8
    // 0x849b5c: LoadField: r1 = r0->field_af
    //     0x849b5c: ldur            w1, [x0, #0xaf]
    // 0x849b60: DecompressPointer r1
    //     0x849b60: add             x1, x1, HEAP, lsl #32
    // 0x849b64: stur            x1, [fp, #-8]
    // 0x849b68: ldr             x16, [fp, #0x10]
    // 0x849b6c: SaveReg r16
    //     0x849b6c: str             x16, [SP, #-8]!
    // 0x849b70: r0 = of()
    //     0x849b70: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x849b74: add             SP, SP, #8
    // 0x849b78: LoadField: r1 = r0->field_2b
    //     0x849b78: ldur            w1, [x0, #0x2b]
    // 0x849b7c: DecompressPointer r1
    //     0x849b7c: add             x1, x1, HEAP, lsl #32
    // 0x849b80: tbnz            w1, #4, #0x849bb8
    // 0x849b84: ldr             x0, [fp, #0x10]
    // 0x849b88: r0 = _BottomSheetDefaultsM3()
    //     0x849b88: bl              #0x849fc8  ; Allocate_BottomSheetDefaultsM3Stub -> _BottomSheetDefaultsM3 (size=0x30)
    // 0x849b8c: mov             x1, x0
    // 0x849b90: ldr             x0, [fp, #0x10]
    // 0x849b94: StoreField: r1->field_2b = r0
    //     0x849b94: stur            w0, [x1, #0x2b]
    // 0x849b98: r2 = 1.000000
    //     0x849b98: ldr             x2, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x849b9c: StoreField: r1->field_f = r2
    //     0x849b9c: stur            w2, [x1, #0xf]
    // 0x849ba0: StoreField: r1->field_1b = r2
    //     0x849ba0: stur            w2, [x1, #0x1b]
    // 0x849ba4: r3 = Instance_RoundedRectangleBorder
    //     0x849ba4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e778] Obj!RoundedRectangleBorder@b383c1
    //     0x849ba8: ldr             x3, [x3, #0x778]
    // 0x849bac: StoreField: r1->field_1f = r3
    //     0x849bac: stur            w3, [x1, #0x1f]
    // 0x849bb0: mov             x4, x1
    // 0x849bb4: b               #0x849bc8
    // 0x849bb8: ldr             x0, [fp, #0x10]
    // 0x849bbc: r2 = 1.000000
    //     0x849bbc: ldr             x2, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x849bc0: r4 = Instance_BottomSheetThemeData
    //     0x849bc0: add             x4, PP, #0xd, lsl #12  ; [pp+0xd040] Obj!BottomSheetThemeData@b48a61
    //     0x849bc4: ldr             x4, [x4, #0x40]
    // 0x849bc8: ldr             x3, [fp, #0x18]
    // 0x849bcc: ldur            x1, [fp, #-8]
    // 0x849bd0: stur            x4, [fp, #-0x18]
    // 0x849bd4: LoadField: r5 = r3->field_b
    //     0x849bd4: ldur            w5, [x3, #0xb]
    // 0x849bd8: DecompressPointer r5
    //     0x849bd8: add             x5, x5, HEAP, lsl #32
    // 0x849bdc: cmp             w5, NULL
    // 0x849be0: b.eq            #0x849fbc
    // 0x849be4: LoadField: r6 = r1->field_27
    //     0x849be4: ldur            w6, [x1, #0x27]
    // 0x849be8: DecompressPointer r6
    //     0x849be8: add             x6, x6, HEAP, lsl #32
    // 0x849bec: stur            x6, [fp, #-0x10]
    // 0x849bf0: LoadField: r7 = r5->field_23
    //     0x849bf0: ldur            w7, [x5, #0x23]
    // 0x849bf4: DecompressPointer r7
    //     0x849bf4: add             x7, x7, HEAP, lsl #32
    // 0x849bf8: cmp             w7, NULL
    // 0x849bfc: b.ne            #0x849c08
    // 0x849c00: r5 = Null
    //     0x849c00: mov             x5, NULL
    // 0x849c04: b               #0x849c0c
    // 0x849c08: mov             x5, x7
    // 0x849c0c: cmp             w5, NULL
    // 0x849c10: b.ne            #0x849c68
    // 0x849c14: r5 = LoadClassIdInstr(r4)
    //     0x849c14: ldur            x5, [x4, #-1]
    //     0x849c18: ubfx            x5, x5, #0xc, #0x14
    // 0x849c1c: lsl             x5, x5, #1
    // 0x849c20: r17 = 5670
    //     0x849c20: mov             x17, #0x1626
    // 0x849c24: cmp             w5, w17
    // 0x849c28: b.ne            #0x849c3c
    // 0x849c2c: LoadField: r5 = r4->field_7
    //     0x849c2c: ldur            w5, [x4, #7]
    // 0x849c30: DecompressPointer r5
    //     0x849c30: add             x5, x5, HEAP, lsl #32
    // 0x849c34: mov             x0, x5
    // 0x849c38: b               #0x849c60
    // 0x849c3c: LoadField: r5 = r4->field_2b
    //     0x849c3c: ldur            w5, [x4, #0x2b]
    // 0x849c40: DecompressPointer r5
    //     0x849c40: add             x5, x5, HEAP, lsl #32
    // 0x849c44: SaveReg r5
    //     0x849c44: str             x5, [SP, #-8]!
    // 0x849c48: r0 = of()
    //     0x849c48: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x849c4c: add             SP, SP, #8
    // 0x849c50: LoadField: r1 = r0->field_3f
    //     0x849c50: ldur            w1, [x0, #0x3f]
    // 0x849c54: DecompressPointer r1
    //     0x849c54: add             x1, x1, HEAP, lsl #32
    // 0x849c58: LoadField: r0 = r1->field_53
    //     0x849c58: ldur            w0, [x1, #0x53]
    // 0x849c5c: DecompressPointer r0
    //     0x849c5c: add             x0, x0, HEAP, lsl #32
    // 0x849c60: mov             x1, x0
    // 0x849c64: b               #0x849c6c
    // 0x849c68: mov             x1, x5
    // 0x849c6c: ldur            x0, [fp, #-0x18]
    // 0x849c70: stur            x1, [fp, #-0x20]
    // 0x849c74: r2 = LoadClassIdInstr(r0)
    //     0x849c74: ldur            x2, [x0, #-1]
    //     0x849c78: ubfx            x2, x2, #0xc, #0x14
    // 0x849c7c: lsl             x2, x2, #1
    // 0x849c80: r17 = 5670
    //     0x849c80: mov             x17, #0x1626
    // 0x849c84: cmp             w2, w17
    // 0x849c88: b.ne            #0x849c9c
    // 0x849c8c: LoadField: r2 = r0->field_b
    //     0x849c8c: ldur            w2, [x0, #0xb]
    // 0x849c90: DecompressPointer r2
    //     0x849c90: add             x2, x2, HEAP, lsl #32
    // 0x849c94: mov             x1, x2
    // 0x849c98: b               #0x849cd4
    // 0x849c9c: LoadField: r2 = r0->field_2b
    //     0x849c9c: ldur            w2, [x0, #0x2b]
    // 0x849ca0: DecompressPointer r2
    //     0x849ca0: add             x2, x2, HEAP, lsl #32
    // 0x849ca4: SaveReg r2
    //     0x849ca4: str             x2, [SP, #-8]!
    // 0x849ca8: r0 = of()
    //     0x849ca8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x849cac: add             SP, SP, #8
    // 0x849cb0: LoadField: r1 = r0->field_3f
    //     0x849cb0: ldur            w1, [x0, #0x3f]
    // 0x849cb4: DecompressPointer r1
    //     0x849cb4: add             x1, x1, HEAP, lsl #32
    // 0x849cb8: LoadField: r0 = r1->field_7f
    //     0x849cb8: ldur            w0, [x1, #0x7f]
    // 0x849cbc: DecompressPointer r0
    //     0x849cbc: add             x0, x0, HEAP, lsl #32
    // 0x849cc0: cmp             w0, NULL
    // 0x849cc4: b.ne            #0x849cd0
    // 0x849cc8: LoadField: r0 = r1->field_b
    //     0x849cc8: ldur            w0, [x1, #0xb]
    // 0x849ccc: DecompressPointer r0
    //     0x849ccc: add             x0, x0, HEAP, lsl #32
    // 0x849cd0: mov             x1, x0
    // 0x849cd4: ldr             x0, [fp, #0x18]
    // 0x849cd8: stur            x1, [fp, #-0x30]
    // 0x849cdc: LoadField: r2 = r0->field_b
    //     0x849cdc: ldur            w2, [x0, #0xb]
    // 0x849ce0: DecompressPointer r2
    //     0x849ce0: add             x2, x2, HEAP, lsl #32
    // 0x849ce4: stur            x2, [fp, #-0x28]
    // 0x849ce8: cmp             w2, NULL
    // 0x849cec: b.eq            #0x849fc0
    // 0x849cf0: LoadField: r3 = r2->field_27
    //     0x849cf0: ldur            w3, [x2, #0x27]
    // 0x849cf4: DecompressPointer r3
    //     0x849cf4: add             x3, x3, HEAP, lsl #32
    // 0x849cf8: cmp             w3, NULL
    // 0x849cfc: b.ne            #0x849d10
    // 0x849d00: ldur            x4, [fp, #-8]
    // 0x849d04: LoadField: r3 = r4->field_f
    //     0x849d04: ldur            w3, [x4, #0xf]
    // 0x849d08: DecompressPointer r3
    //     0x849d08: add             x3, x3, HEAP, lsl #32
    // 0x849d0c: b               #0x849d14
    // 0x849d10: ldur            x4, [fp, #-8]
    // 0x849d14: cmp             w3, NULL
    // 0x849d18: b.ne            #0x849d2c
    // 0x849d1c: ldur            x5, [fp, #-0x18]
    // 0x849d20: LoadField: r3 = r5->field_f
    //     0x849d20: ldur            w3, [x5, #0xf]
    // 0x849d24: DecompressPointer r3
    //     0x849d24: add             x3, x3, HEAP, lsl #32
    // 0x849d28: b               #0x849d30
    // 0x849d2c: ldur            x5, [fp, #-0x18]
    // 0x849d30: cmp             w3, NULL
    // 0x849d34: b.ne            #0x849d40
    // 0x849d38: d0 = 0.000000
    //     0x849d38: eor             v0.16b, v0.16b, v0.16b
    // 0x849d3c: b               #0x849d44
    // 0x849d40: LoadField: d0 = r3->field_7
    //     0x849d40: ldur            d0, [x3, #7]
    // 0x849d44: stur            d0, [fp, #-0x48]
    // 0x849d48: LoadField: r3 = r4->field_1f
    //     0x849d48: ldur            w3, [x4, #0x1f]
    // 0x849d4c: DecompressPointer r3
    //     0x849d4c: add             x3, x3, HEAP, lsl #32
    // 0x849d50: cmp             w3, NULL
    // 0x849d54: b.ne            #0x849d68
    // 0x849d58: LoadField: r3 = r5->field_1f
    //     0x849d58: ldur            w3, [x5, #0x1f]
    // 0x849d5c: DecompressPointer r3
    //     0x849d5c: add             x3, x3, HEAP, lsl #32
    // 0x849d60: mov             x5, x3
    // 0x849d64: b               #0x849d6c
    // 0x849d68: mov             x5, x3
    // 0x849d6c: ldur            x3, [fp, #-0x20]
    // 0x849d70: ldur            x4, [fp, #-0x10]
    // 0x849d74: stur            x5, [fp, #-0x18]
    // 0x849d78: LoadField: r6 = r0->field_13
    //     0x849d78: ldur            w6, [x0, #0x13]
    // 0x849d7c: DecompressPointer r6
    //     0x849d7c: add             x6, x6, HEAP, lsl #32
    // 0x849d80: stur            x6, [fp, #-8]
    // 0x849d84: r1 = 1
    //     0x849d84: mov             x1, #1
    // 0x849d88: r0 = AllocateContext()
    //     0x849d88: bl              #0xd68aa4  ; AllocateContextStub
    // 0x849d8c: mov             x2, x0
    // 0x849d90: ldr             x1, [fp, #0x18]
    // 0x849d94: stur            x2, [fp, #-0x38]
    // 0x849d98: StoreField: r2->field_f = r1
    //     0x849d98: stur            w1, [x2, #0xf]
    // 0x849d9c: ldur            x0, [fp, #-0x28]
    // 0x849da0: LoadField: r3 = r0->field_13
    //     0x849da0: ldur            w3, [x0, #0x13]
    // 0x849da4: DecompressPointer r3
    //     0x849da4: add             x3, x3, HEAP, lsl #32
    // 0x849da8: ldr             x16, [fp, #0x10]
    // 0x849dac: stp             x16, x3, [SP, #-0x10]!
    // 0x849db0: mov             x0, x3
    // 0x849db4: ClosureCall
    //     0x849db4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x849db8: ldur            x2, [x0, #0x1f]
    //     0x849dbc: blr             x2
    // 0x849dc0: add             SP, SP, #0x10
    // 0x849dc4: ldur            x2, [fp, #-0x38]
    // 0x849dc8: r1 = Function 'extentChanged':.
    //     0x849dc8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40280] AnonymousClosure: (0x84a680), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::extentChanged (0x84a6cc)
    //     0x849dcc: ldr             x1, [x1, #0x280]
    // 0x849dd0: stur            x0, [fp, #-0x28]
    // 0x849dd4: r0 = AllocateClosure()
    //     0x849dd4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x849dd8: r1 = <DraggableScrollableNotification>
    //     0x849dd8: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f08] TypeArguments: <DraggableScrollableNotification>
    //     0x849ddc: ldr             x1, [x1, #0xf08]
    // 0x849de0: stur            x0, [fp, #-0x38]
    // 0x849de4: r0 = NotificationListener()
    //     0x849de4: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x849de8: mov             x1, x0
    // 0x849dec: ldur            x0, [fp, #-0x38]
    // 0x849df0: stur            x1, [fp, #-0x40]
    // 0x849df4: StoreField: r1->field_13 = r0
    //     0x849df4: stur            w0, [x1, #0x13]
    // 0x849df8: ldur            x0, [fp, #-0x28]
    // 0x849dfc: StoreField: r1->field_b = r0
    //     0x849dfc: stur            w0, [x1, #0xb]
    // 0x849e00: r0 = Material()
    //     0x849e00: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x849e04: mov             x1, x0
    // 0x849e08: r0 = Instance_MaterialType
    //     0x849e08: add             x0, PP, #0xe, lsl #12  ; [pp+0xe6f8] Obj!MaterialType@b65531
    //     0x849e0c: ldr             x0, [x0, #0x6f8]
    // 0x849e10: stur            x1, [fp, #-0x28]
    // 0x849e14: StoreField: r1->field_f = r0
    //     0x849e14: stur            w0, [x1, #0xf]
    // 0x849e18: ldur            d0, [fp, #-0x48]
    // 0x849e1c: StoreField: r1->field_13 = d0
    //     0x849e1c: stur            d0, [x1, #0x13]
    // 0x849e20: ldur            x0, [fp, #-0x20]
    // 0x849e24: StoreField: r1->field_1b = r0
    //     0x849e24: stur            w0, [x1, #0x1b]
    // 0x849e28: ldur            x0, [fp, #-0x30]
    // 0x849e2c: StoreField: r1->field_23 = r0
    //     0x849e2c: stur            w0, [x1, #0x23]
    // 0x849e30: ldur            x0, [fp, #-0x18]
    // 0x849e34: StoreField: r1->field_2b = r0
    //     0x849e34: stur            w0, [x1, #0x2b]
    // 0x849e38: r0 = true
    //     0x849e38: add             x0, NULL, #0x20  ; true
    // 0x849e3c: StoreField: r1->field_2f = r0
    //     0x849e3c: stur            w0, [x1, #0x2f]
    // 0x849e40: r0 = Instance_Clip
    //     0x849e40: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x849e44: ldr             x0, [x0, #0xb38]
    // 0x849e48: StoreField: r1->field_33 = r0
    //     0x849e48: stur            w0, [x1, #0x33]
    // 0x849e4c: r0 = Instance_Duration
    //     0x849e4c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x849e50: ldr             x0, [x0, #0x9e0]
    // 0x849e54: StoreField: r1->field_37 = r0
    //     0x849e54: stur            w0, [x1, #0x37]
    // 0x849e58: ldur            x0, [fp, #-0x40]
    // 0x849e5c: StoreField: r1->field_b = r0
    //     0x849e5c: stur            w0, [x1, #0xb]
    // 0x849e60: ldur            x0, [fp, #-8]
    // 0x849e64: StoreField: r1->field_7 = r0
    //     0x849e64: stur            w0, [x1, #7]
    // 0x849e68: ldur            x0, [fp, #-0x10]
    // 0x849e6c: cmp             w0, NULL
    // 0x849e70: b.eq            #0x849eb8
    // 0x849e74: r0 = ConstrainedBox()
    //     0x849e74: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x849e78: mov             x1, x0
    // 0x849e7c: ldur            x0, [fp, #-0x10]
    // 0x849e80: stur            x1, [fp, #-8]
    // 0x849e84: StoreField: r1->field_f = r0
    //     0x849e84: stur            w0, [x1, #0xf]
    // 0x849e88: ldur            x0, [fp, #-0x28]
    // 0x849e8c: StoreField: r1->field_b = r0
    //     0x849e8c: stur            w0, [x1, #0xb]
    // 0x849e90: r0 = Align()
    //     0x849e90: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x849e94: mov             x1, x0
    // 0x849e98: r0 = Instance_Alignment
    //     0x849e98: add             x0, PP, #0xd, lsl #12  ; [pp+0xdca8] Obj!Alignment@b37a91
    //     0x849e9c: ldr             x0, [x0, #0xca8]
    // 0x849ea0: StoreField: r1->field_f = r0
    //     0x849ea0: stur            w0, [x1, #0xf]
    // 0x849ea4: r0 = 1.000000
    //     0x849ea4: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x849ea8: StoreField: r1->field_17 = r0
    //     0x849ea8: stur            w0, [x1, #0x17]
    // 0x849eac: ldur            x0, [fp, #-8]
    // 0x849eb0: StoreField: r1->field_b = r0
    //     0x849eb0: stur            w0, [x1, #0xb]
    // 0x849eb4: b               #0x849ec0
    // 0x849eb8: mov             x0, x1
    // 0x849ebc: mov             x1, x0
    // 0x849ec0: ldr             x0, [fp, #0x18]
    // 0x849ec4: stur            x1, [fp, #-8]
    // 0x849ec8: LoadField: r2 = r0->field_b
    //     0x849ec8: ldur            w2, [x0, #0xb]
    // 0x849ecc: DecompressPointer r2
    //     0x849ecc: add             x2, x2, HEAP, lsl #32
    // 0x849ed0: cmp             w2, NULL
    // 0x849ed4: b.eq            #0x849fc4
    // 0x849ed8: LoadField: r3 = r2->field_17
    //     0x849ed8: ldur            w3, [x2, #0x17]
    // 0x849edc: DecompressPointer r3
    //     0x849edc: add             x3, x3, HEAP, lsl #32
    // 0x849ee0: tbz             w3, #4, #0x849eec
    // 0x849ee4: mov             x0, x1
    // 0x849ee8: b               #0x849fa8
    // 0x849eec: r1 = 1
    //     0x849eec: mov             x1, #1
    // 0x849ef0: r0 = AllocateContext()
    //     0x849ef0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x849ef4: mov             x1, x0
    // 0x849ef8: ldr             x0, [fp, #0x18]
    // 0x849efc: stur            x1, [fp, #-0x10]
    // 0x849f00: StoreField: r1->field_f = r0
    //     0x849f00: stur            w0, [x1, #0xf]
    // 0x849f04: r1 = 1
    //     0x849f04: mov             x1, #1
    // 0x849f08: r0 = AllocateContext()
    //     0x849f08: bl              #0xd68aa4  ; AllocateContextStub
    // 0x849f0c: mov             x1, x0
    // 0x849f10: ldr             x0, [fp, #0x18]
    // 0x849f14: stur            x1, [fp, #-0x18]
    // 0x849f18: StoreField: r1->field_f = r0
    //     0x849f18: stur            w0, [x1, #0xf]
    // 0x849f1c: r1 = 1
    //     0x849f1c: mov             x1, #1
    // 0x849f20: r0 = AllocateContext()
    //     0x849f20: bl              #0xd68aa4  ; AllocateContextStub
    // 0x849f24: mov             x1, x0
    // 0x849f28: ldr             x0, [fp, #0x18]
    // 0x849f2c: stur            x1, [fp, #-0x20]
    // 0x849f30: StoreField: r1->field_f = r0
    //     0x849f30: stur            w0, [x1, #0xf]
    // 0x849f34: r0 = GestureDetector()
    //     0x849f34: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x849f38: ldur            x2, [fp, #-0x10]
    // 0x849f3c: r1 = Function '_handleDragStart@693001611':.
    //     0x849f3c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40288] AnonymousClosure: (0x84a5c8), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragStart (0x84a614)
    //     0x849f40: ldr             x1, [x1, #0x288]
    // 0x849f44: stur            x0, [fp, #-0x10]
    // 0x849f48: r0 = AllocateClosure()
    //     0x849f48: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x849f4c: ldur            x2, [fp, #-0x18]
    // 0x849f50: r1 = Function '_handleDragUpdate@693001611':.
    //     0x849f50: add             x1, PP, #0x40, lsl #12  ; [pp+0x40290] AnonymousClosure: (0x84a464), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragUpdate (0x84a4b0)
    //     0x849f54: ldr             x1, [x1, #0x290]
    // 0x849f58: stur            x0, [fp, #-0x18]
    // 0x849f5c: r0 = AllocateClosure()
    //     0x849f5c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x849f60: ldur            x2, [fp, #-0x20]
    // 0x849f64: r1 = Function '_handleDragEnd@693001611':.
    //     0x849f64: add             x1, PP, #0x40, lsl #12  ; [pp+0x40298] AnonymousClosure: (0x849fd4), in [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragEnd (0x84a020)
    //     0x849f68: ldr             x1, [x1, #0x298]
    // 0x849f6c: stur            x0, [fp, #-0x20]
    // 0x849f70: r0 = AllocateClosure()
    //     0x849f70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x849f74: ldur            x16, [fp, #-0x10]
    // 0x849f78: ldur            lr, [fp, #-0x18]
    // 0x849f7c: stp             lr, x16, [SP, #-0x10]!
    // 0x849f80: ldur            x16, [fp, #-0x20]
    // 0x849f84: stp             x0, x16, [SP, #-0x10]!
    // 0x849f88: r16 = true
    //     0x849f88: add             x16, NULL, #0x20  ; true
    // 0x849f8c: ldur            lr, [fp, #-8]
    // 0x849f90: stp             lr, x16, [SP, #-0x10]!
    // 0x849f94: r4 = const [0, 0x6, 0x6, 0x1, child, 0x5, excludeFromSemantics, 0x4, onVerticalDragEnd, 0x3, onVerticalDragStart, 0x1, onVerticalDragUpdate, 0x2, null]
    //     0x849f94: add             x4, PP, #0x40, lsl #12  ; [pp+0x402a0] List(15) [0, 0x6, 0x6, 0x1, "child", 0x5, "excludeFromSemantics", 0x4, "onVerticalDragEnd", 0x3, "onVerticalDragStart", 0x1, "onVerticalDragUpdate", 0x2, Null]
    //     0x849f98: ldr             x4, [x4, #0x2a0]
    // 0x849f9c: r0 = GestureDetector()
    //     0x849f9c: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x849fa0: add             SP, SP, #0x30
    // 0x849fa4: ldur            x0, [fp, #-0x10]
    // 0x849fa8: LeaveFrame
    //     0x849fa8: mov             SP, fp
    //     0x849fac: ldp             fp, lr, [SP], #0x10
    // 0x849fb0: ret
    //     0x849fb0: ret             
    // 0x849fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849fb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849fb8: b               #0x849b4c
    // 0x849fbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x849fbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x849fc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x849fc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x849fc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x849fc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0x849fd4, size: 0x4c
    // 0x849fd4: EnterFrame
    //     0x849fd4: stp             fp, lr, [SP, #-0x10]!
    //     0x849fd8: mov             fp, SP
    // 0x849fdc: ldr             x0, [fp, #0x18]
    // 0x849fe0: LoadField: r1 = r0->field_17
    //     0x849fe0: ldur            w1, [x0, #0x17]
    // 0x849fe4: DecompressPointer r1
    //     0x849fe4: add             x1, x1, HEAP, lsl #32
    // 0x849fe8: CheckStackOverflow
    //     0x849fe8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x849fec: cmp             SP, x16
    //     0x849ff0: b.ls            #0x84a018
    // 0x849ff4: LoadField: r0 = r1->field_f
    //     0x849ff4: ldur            w0, [x1, #0xf]
    // 0x849ff8: DecompressPointer r0
    //     0x849ff8: add             x0, x0, HEAP, lsl #32
    // 0x849ffc: ldr             x16, [fp, #0x10]
    // 0x84a000: stp             x16, x0, [SP, #-0x10]!
    // 0x84a004: r0 = _handleDragEnd()
    //     0x84a004: bl              #0x84a020  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragEnd
    // 0x84a008: add             SP, SP, #0x10
    // 0x84a00c: LeaveFrame
    //     0x84a00c: mov             SP, fp
    //     0x84a010: ldp             fp, lr, [SP], #0x10
    // 0x84a014: ret
    //     0x84a014: ret             
    // 0x84a018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a018: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a01c: b               #0x849ff4
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0x84a020, size: 0x30c
    // 0x84a020: EnterFrame
    //     0x84a020: stp             fp, lr, [SP, #-0x10]!
    //     0x84a024: mov             fp, SP
    // 0x84a028: AllocStack(0x18)
    //     0x84a028: sub             SP, SP, #0x18
    // 0x84a02c: CheckStackOverflow
    //     0x84a02c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a030: cmp             SP, x16
    //     0x84a034: b.ls            #0x84a2bc
    // 0x84a038: ldr             x16, [fp, #0x18]
    // 0x84a03c: SaveReg r16
    //     0x84a03c: str             x16, [SP, #-8]!
    // 0x84a040: r0 = _dismissUnderway()
    //     0x84a040: bl              #0x84a3ec  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_dismissUnderway
    // 0x84a044: add             SP, SP, #8
    // 0x84a048: tbnz            w0, #4, #0x84a05c
    // 0x84a04c: r0 = Null
    //     0x84a04c: mov             x0, NULL
    // 0x84a050: LeaveFrame
    //     0x84a050: mov             SP, fp
    //     0x84a054: ldp             fp, lr, [SP], #0x10
    // 0x84a058: ret
    //     0x84a058: ret             
    // 0x84a05c: ldr             x0, [fp, #0x10]
    // 0x84a060: d0 = 700.000000
    //     0x84a060: add             x17, PP, #0x40, lsl #12  ; [pp+0x402a8] IMM: double(700) from 0x4085e00000000000
    //     0x84a064: ldr             d0, [x17, #0x2a8]
    // 0x84a068: LoadField: r1 = r0->field_7
    //     0x84a068: ldur            w1, [x0, #7]
    // 0x84a06c: DecompressPointer r1
    //     0x84a06c: add             x1, x1, HEAP, lsl #32
    // 0x84a070: LoadField: r2 = r1->field_7
    //     0x84a070: ldur            w2, [x1, #7]
    // 0x84a074: DecompressPointer r2
    //     0x84a074: add             x2, x2, HEAP, lsl #32
    // 0x84a078: LoadField: d1 = r2->field_f
    //     0x84a078: ldur            d1, [x2, #0xf]
    // 0x84a07c: fcmp            d1, d0
    // 0x84a080: b.vs            #0x84a160
    // 0x84a084: b.le            #0x84a160
    // 0x84a088: ldr             x1, [fp, #0x18]
    // 0x84a08c: fneg            d0, d1
    // 0x84a090: stur            d0, [fp, #-0x10]
    // 0x84a094: SaveReg r1
    //     0x84a094: str             x1, [SP, #-8]!
    // 0x84a098: r0 = _childHeight()
    //     0x84a098: bl              #0x84a32c  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_childHeight
    // 0x84a09c: add             SP, SP, #8
    // 0x84a0a0: mov             v1.16b, v0.16b
    // 0x84a0a4: ldur            d0, [fp, #-0x10]
    // 0x84a0a8: fdiv            d2, d0, d1
    // 0x84a0ac: ldr             x0, [fp, #0x18]
    // 0x84a0b0: stur            d2, [fp, #-0x18]
    // 0x84a0b4: LoadField: r1 = r0->field_b
    //     0x84a0b4: ldur            w1, [x0, #0xb]
    // 0x84a0b8: DecompressPointer r1
    //     0x84a0b8: add             x1, x1, HEAP, lsl #32
    // 0x84a0bc: cmp             w1, NULL
    // 0x84a0c0: b.eq            #0x84a2c4
    // 0x84a0c4: LoadField: r2 = r1->field_b
    //     0x84a0c4: ldur            w2, [x1, #0xb]
    // 0x84a0c8: DecompressPointer r2
    //     0x84a0c8: add             x2, x2, HEAP, lsl #32
    // 0x84a0cc: cmp             w2, NULL
    // 0x84a0d0: b.eq            #0x84a2c8
    // 0x84a0d4: LoadField: r1 = r2->field_37
    //     0x84a0d4: ldur            w1, [x2, #0x37]
    // 0x84a0d8: DecompressPointer r1
    //     0x84a0d8: add             x1, x1, HEAP, lsl #32
    // 0x84a0dc: r16 = Sentinel
    //     0x84a0dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84a0e0: cmp             w1, w16
    // 0x84a0e4: b.eq            #0x84a2cc
    // 0x84a0e8: LoadField: d0 = r1->field_7
    //     0x84a0e8: ldur            d0, [x1, #7]
    // 0x84a0ec: d1 = 0.000000
    //     0x84a0ec: eor             v1.16b, v1.16b, v1.16b
    // 0x84a0f0: fcmp            d0, d1
    // 0x84a0f4: b.vs            #0x84a138
    // 0x84a0f8: b.le            #0x84a138
    // 0x84a0fc: r1 = inline_Allocate_Double()
    //     0x84a0fc: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x84a100: add             x1, x1, #0x10
    //     0x84a104: cmp             x3, x1
    //     0x84a108: b.ls            #0x84a2d8
    //     0x84a10c: str             x1, [THR, #0x60]  ; THR::top
    //     0x84a110: sub             x1, x1, #0xf
    //     0x84a114: mov             x3, #0xd108
    //     0x84a118: movk            x3, #3, lsl #16
    //     0x84a11c: stur            x3, [x1, #-1]
    // 0x84a120: StoreField: r1->field_7 = d2
    //     0x84a120: stur            d2, [x1, #7]
    // 0x84a124: stp             x1, x2, [SP, #-0x10]!
    // 0x84a128: r4 = const [0, 0x2, 0x2, 0x1, velocity, 0x1, null]
    //     0x84a128: add             x4, PP, #0x37, lsl #12  ; [pp+0x37a40] List(7) [0, 0x2, 0x2, 0x1, "velocity", 0x1, Null]
    //     0x84a12c: ldr             x4, [x4, #0xa40]
    // 0x84a130: r0 = fling()
    //     0x84a130: bl              #0x82d318  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0x84a134: add             SP, SP, #0x10
    // 0x84a138: ldur            d0, [fp, #-0x18]
    // 0x84a13c: d1 = 0.000000
    //     0x84a13c: eor             v1.16b, v1.16b, v1.16b
    // 0x84a140: fcmp            d0, d1
    // 0x84a144: b.vs            #0x84a154
    // 0x84a148: b.ge            #0x84a154
    // 0x84a14c: r0 = true
    //     0x84a14c: add             x0, NULL, #0x20  ; true
    // 0x84a150: b               #0x84a158
    // 0x84a154: r0 = false
    //     0x84a154: add             x0, NULL, #0x30  ; false
    // 0x84a158: mov             x2, x0
    // 0x84a15c: b               #0x84a220
    // 0x84a160: ldr             x0, [fp, #0x18]
    // 0x84a164: d1 = 0.000000
    //     0x84a164: eor             v1.16b, v1.16b, v1.16b
    // 0x84a168: d0 = 0.500000
    //     0x84a168: fmov            d0, #0.50000000
    // 0x84a16c: LoadField: r1 = r0->field_b
    //     0x84a16c: ldur            w1, [x0, #0xb]
    // 0x84a170: DecompressPointer r1
    //     0x84a170: add             x1, x1, HEAP, lsl #32
    // 0x84a174: cmp             w1, NULL
    // 0x84a178: b.eq            #0x84a2f4
    // 0x84a17c: LoadField: r2 = r1->field_b
    //     0x84a17c: ldur            w2, [x1, #0xb]
    // 0x84a180: DecompressPointer r2
    //     0x84a180: add             x2, x2, HEAP, lsl #32
    // 0x84a184: cmp             w2, NULL
    // 0x84a188: b.eq            #0x84a2f8
    // 0x84a18c: LoadField: r1 = r2->field_37
    //     0x84a18c: ldur            w1, [x2, #0x37]
    // 0x84a190: DecompressPointer r1
    //     0x84a190: add             x1, x1, HEAP, lsl #32
    // 0x84a194: r16 = Sentinel
    //     0x84a194: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84a198: cmp             w1, w16
    // 0x84a19c: b.eq            #0x84a2fc
    // 0x84a1a0: LoadField: d2 = r1->field_7
    //     0x84a1a0: ldur            d2, [x1, #7]
    // 0x84a1a4: fcmp            d2, d0
    // 0x84a1a8: b.vs            #0x84a208
    // 0x84a1ac: b.ge            #0x84a208
    // 0x84a1b0: fcmp            d2, d1
    // 0x84a1b4: b.vs            #0x84a200
    // 0x84a1b8: b.le            #0x84a200
    // 0x84a1bc: d0 = 1.000000
    //     0x84a1bc: fmov            d0, #1.00000000
    // 0x84a1c0: fneg            d1, d0
    // 0x84a1c4: r1 = inline_Allocate_Double()
    //     0x84a1c4: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x84a1c8: add             x1, x1, #0x10
    //     0x84a1cc: cmp             x3, x1
    //     0x84a1d0: b.ls            #0x84a308
    //     0x84a1d4: str             x1, [THR, #0x60]  ; THR::top
    //     0x84a1d8: sub             x1, x1, #0xf
    //     0x84a1dc: mov             x3, #0xd108
    //     0x84a1e0: movk            x3, #3, lsl #16
    //     0x84a1e4: stur            x3, [x1, #-1]
    // 0x84a1e8: StoreField: r1->field_7 = d1
    //     0x84a1e8: stur            d1, [x1, #7]
    // 0x84a1ec: stp             x1, x2, [SP, #-0x10]!
    // 0x84a1f0: r4 = const [0, 0x2, 0x2, 0x1, velocity, 0x1, null]
    //     0x84a1f0: add             x4, PP, #0x37, lsl #12  ; [pp+0x37a40] List(7) [0, 0x2, 0x2, 0x1, "velocity", 0x1, Null]
    //     0x84a1f4: ldr             x4, [x4, #0xa40]
    // 0x84a1f8: r0 = fling()
    //     0x84a1f8: bl              #0x82d318  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0x84a1fc: add             SP, SP, #0x10
    // 0x84a200: r0 = true
    //     0x84a200: add             x0, NULL, #0x20  ; true
    // 0x84a204: b               #0x84a21c
    // 0x84a208: SaveReg r2
    //     0x84a208: str             x2, [SP, #-8]!
    // 0x84a20c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84a20c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84a210: r0 = forward()
    //     0x84a210: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x84a214: add             SP, SP, #8
    // 0x84a218: r0 = false
    //     0x84a218: add             x0, NULL, #0x30  ; false
    // 0x84a21c: mov             x2, x0
    // 0x84a220: ldr             x1, [fp, #0x18]
    // 0x84a224: stur            x2, [fp, #-8]
    // 0x84a228: LoadField: r0 = r1->field_b
    //     0x84a228: ldur            w0, [x1, #0xb]
    // 0x84a22c: DecompressPointer r0
    //     0x84a22c: add             x0, x0, HEAP, lsl #32
    // 0x84a230: cmp             w0, NULL
    // 0x84a234: b.eq            #0x84a324
    // 0x84a238: LoadField: r3 = r0->field_1f
    //     0x84a238: ldur            w3, [x0, #0x1f]
    // 0x84a23c: DecompressPointer r3
    //     0x84a23c: add             x3, x3, HEAP, lsl #32
    // 0x84a240: cmp             w3, NULL
    // 0x84a244: b.ne            #0x84a250
    // 0x84a248: mov             x0, x2
    // 0x84a24c: b               #0x84a278
    // 0x84a250: ldr             x16, [fp, #0x10]
    // 0x84a254: stp             x16, x3, [SP, #-0x10]!
    // 0x84a258: SaveReg r2
    //     0x84a258: str             x2, [SP, #-8]!
    // 0x84a25c: mov             x0, x3
    // 0x84a260: ClosureCall
    //     0x84a260: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e168] List(7) [0, 0x3, 0x3, 0x2, "isClosing", 0x2, Null]
    //     0x84a264: ldr             x4, [x4, #0x168]
    //     0x84a268: ldur            x2, [x0, #0x1f]
    //     0x84a26c: blr             x2
    // 0x84a270: add             SP, SP, #0x18
    // 0x84a274: ldur            x0, [fp, #-8]
    // 0x84a278: tbnz            w0, #4, #0x84a2ac
    // 0x84a27c: ldr             x0, [fp, #0x18]
    // 0x84a280: LoadField: r1 = r0->field_b
    //     0x84a280: ldur            w1, [x0, #0xb]
    // 0x84a284: DecompressPointer r1
    //     0x84a284: add             x1, x1, HEAP, lsl #32
    // 0x84a288: cmp             w1, NULL
    // 0x84a28c: b.eq            #0x84a328
    // 0x84a290: LoadField: r0 = r1->field_f
    //     0x84a290: ldur            w0, [x1, #0xf]
    // 0x84a294: DecompressPointer r0
    //     0x84a294: add             x0, x0, HEAP, lsl #32
    // 0x84a298: SaveReg r0
    //     0x84a298: str             x0, [SP, #-8]!
    // 0x84a29c: ClosureCall
    //     0x84a29c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x84a2a0: ldur            x2, [x0, #0x1f]
    //     0x84a2a4: blr             x2
    // 0x84a2a8: add             SP, SP, #8
    // 0x84a2ac: r0 = Null
    //     0x84a2ac: mov             x0, NULL
    // 0x84a2b0: LeaveFrame
    //     0x84a2b0: mov             SP, fp
    //     0x84a2b4: ldp             fp, lr, [SP], #0x10
    // 0x84a2b8: ret
    //     0x84a2b8: ret             
    // 0x84a2bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a2bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a2c0: b               #0x84a038
    // 0x84a2c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84a2c4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x84a2c8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84a2c8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x84a2cc: r9 = _value
    //     0x84a2cc: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x84a2d0: ldr             x9, [x9, #0xbb0]
    // 0x84a2d4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84a2d4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84a2d8: stp             q1, q2, [SP, #-0x20]!
    // 0x84a2dc: stp             x0, x2, [SP, #-0x10]!
    // 0x84a2e0: r0 = AllocateDouble()
    //     0x84a2e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x84a2e4: mov             x1, x0
    // 0x84a2e8: ldp             x0, x2, [SP], #0x10
    // 0x84a2ec: ldp             q1, q2, [SP], #0x20
    // 0x84a2f0: b               #0x84a120
    // 0x84a2f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84a2f4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x84a2f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84a2f8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x84a2fc: r9 = _value
    //     0x84a2fc: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x84a300: ldr             x9, [x9, #0xbb0]
    // 0x84a304: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x84a304: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x84a308: SaveReg d1
    //     0x84a308: str             q1, [SP, #-0x10]!
    // 0x84a30c: stp             x0, x2, [SP, #-0x10]!
    // 0x84a310: r0 = AllocateDouble()
    //     0x84a310: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x84a314: mov             x1, x0
    // 0x84a318: ldp             x0, x2, [SP], #0x10
    // 0x84a31c: RestoreReg d1
    //     0x84a31c: ldr             q1, [SP], #0x10
    // 0x84a320: b               #0x84a1e8
    // 0x84a324: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a324: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84a328: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a328: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _childHeight(/* No info */) {
    // ** addr: 0x84a32c, size: 0xc0
    // 0x84a32c: EnterFrame
    //     0x84a32c: stp             fp, lr, [SP, #-0x10]!
    //     0x84a330: mov             fp, SP
    // 0x84a334: AllocStack(0x8)
    //     0x84a334: sub             SP, SP, #8
    // 0x84a338: CheckStackOverflow
    //     0x84a338: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a33c: cmp             SP, x16
    //     0x84a340: b.ls            #0x84a3d8
    // 0x84a344: ldr             x0, [fp, #0x10]
    // 0x84a348: LoadField: r1 = r0->field_13
    //     0x84a348: ldur            w1, [x0, #0x13]
    // 0x84a34c: DecompressPointer r1
    //     0x84a34c: add             x1, x1, HEAP, lsl #32
    // 0x84a350: SaveReg r1
    //     0x84a350: str             x1, [SP, #-8]!
    // 0x84a354: r0 = _currentElement()
    //     0x84a354: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0x84a358: add             SP, SP, #8
    // 0x84a35c: cmp             w0, NULL
    // 0x84a360: b.eq            #0x84a3e0
    // 0x84a364: SaveReg r0
    //     0x84a364: str             x0, [SP, #-8]!
    // 0x84a368: r0 = findRenderObject()
    //     0x84a368: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x84a36c: add             SP, SP, #8
    // 0x84a370: mov             x3, x0
    // 0x84a374: stur            x3, [fp, #-8]
    // 0x84a378: cmp             w3, NULL
    // 0x84a37c: b.eq            #0x84a3e4
    // 0x84a380: mov             x0, x3
    // 0x84a384: r2 = Null
    //     0x84a384: mov             x2, NULL
    // 0x84a388: r1 = Null
    //     0x84a388: mov             x1, NULL
    // 0x84a38c: r4 = LoadClassIdInstr(r0)
    //     0x84a38c: ldur            x4, [x0, #-1]
    //     0x84a390: ubfx            x4, x4, #0xc, #0x14
    // 0x84a394: sub             x4, x4, #0x965
    // 0x84a398: cmp             x4, #0x8b
    // 0x84a39c: b.ls            #0x84a3b4
    // 0x84a3a0: r8 = RenderBox
    //     0x84a3a0: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x84a3a4: ldr             x8, [x8, #0xfa0]
    // 0x84a3a8: r3 = Null
    //     0x84a3a8: add             x3, PP, #0x40, lsl #12  ; [pp+0x402b0] Null
    //     0x84a3ac: ldr             x3, [x3, #0x2b0]
    // 0x84a3b0: r0 = RenderBox()
    //     0x84a3b0: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x84a3b4: ldur            x0, [fp, #-8]
    // 0x84a3b8: LoadField: r1 = r0->field_57
    //     0x84a3b8: ldur            w1, [x0, #0x57]
    // 0x84a3bc: DecompressPointer r1
    //     0x84a3bc: add             x1, x1, HEAP, lsl #32
    // 0x84a3c0: cmp             w1, NULL
    // 0x84a3c4: b.eq            #0x84a3e8
    // 0x84a3c8: LoadField: d0 = r1->field_f
    //     0x84a3c8: ldur            d0, [x1, #0xf]
    // 0x84a3cc: LeaveFrame
    //     0x84a3cc: mov             SP, fp
    //     0x84a3d0: ldp             fp, lr, [SP], #0x10
    // 0x84a3d4: ret
    //     0x84a3d4: ret             
    // 0x84a3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a3d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a3dc: b               #0x84a344
    // 0x84a3e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a3e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84a3e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a3e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84a3e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a3e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _dismissUnderway(/* No info */) {
    // ** addr: 0x84a3ec, size: 0x78
    // 0x84a3ec: EnterFrame
    //     0x84a3ec: stp             fp, lr, [SP, #-0x10]!
    //     0x84a3f0: mov             fp, SP
    // 0x84a3f4: ldr             x1, [fp, #0x10]
    // 0x84a3f8: LoadField: r2 = r1->field_b
    //     0x84a3f8: ldur            w2, [x1, #0xb]
    // 0x84a3fc: DecompressPointer r2
    //     0x84a3fc: add             x2, x2, HEAP, lsl #32
    // 0x84a400: cmp             w2, NULL
    // 0x84a404: b.eq            #0x84a450
    // 0x84a408: LoadField: r1 = r2->field_b
    //     0x84a408: ldur            w1, [x2, #0xb]
    // 0x84a40c: DecompressPointer r1
    //     0x84a40c: add             x1, x1, HEAP, lsl #32
    // 0x84a410: cmp             w1, NULL
    // 0x84a414: b.eq            #0x84a454
    // 0x84a418: LoadField: r2 = r1->field_43
    //     0x84a418: ldur            w2, [x1, #0x43]
    // 0x84a41c: DecompressPointer r2
    //     0x84a41c: add             x2, x2, HEAP, lsl #32
    // 0x84a420: r16 = Sentinel
    //     0x84a420: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84a424: cmp             w2, w16
    // 0x84a428: b.eq            #0x84a458
    // 0x84a42c: r16 = Instance_AnimationStatus
    //     0x84a42c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0x84a430: ldr             x16, [x16, #0xbc0]
    // 0x84a434: cmp             w2, w16
    // 0x84a438: r16 = true
    //     0x84a438: add             x16, NULL, #0x20  ; true
    // 0x84a43c: r17 = false
    //     0x84a43c: add             x17, NULL, #0x30  ; false
    // 0x84a440: csel            x0, x16, x17, eq
    // 0x84a444: LeaveFrame
    //     0x84a444: mov             SP, fp
    //     0x84a448: ldp             fp, lr, [SP], #0x10
    // 0x84a44c: ret
    //     0x84a44c: ret             
    // 0x84a450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a450: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84a454: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a454: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84a458: r9 = _status
    //     0x84a458: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbe0] Field <AnimationController._status@575066280>: late (offset: 0x44)
    //     0x84a45c: ldr             x9, [x9, #0xbe0]
    // 0x84a460: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84a460: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x84a464, size: 0x4c
    // 0x84a464: EnterFrame
    //     0x84a464: stp             fp, lr, [SP, #-0x10]!
    //     0x84a468: mov             fp, SP
    // 0x84a46c: ldr             x0, [fp, #0x18]
    // 0x84a470: LoadField: r1 = r0->field_17
    //     0x84a470: ldur            w1, [x0, #0x17]
    // 0x84a474: DecompressPointer r1
    //     0x84a474: add             x1, x1, HEAP, lsl #32
    // 0x84a478: CheckStackOverflow
    //     0x84a478: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a47c: cmp             SP, x16
    //     0x84a480: b.ls            #0x84a4a8
    // 0x84a484: LoadField: r0 = r1->field_f
    //     0x84a484: ldur            w0, [x1, #0xf]
    // 0x84a488: DecompressPointer r0
    //     0x84a488: add             x0, x0, HEAP, lsl #32
    // 0x84a48c: ldr             x16, [fp, #0x10]
    // 0x84a490: stp             x16, x0, [SP, #-0x10]!
    // 0x84a494: r0 = _handleDragUpdate()
    //     0x84a494: bl              #0x84a4b0  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragUpdate
    // 0x84a498: add             SP, SP, #0x10
    // 0x84a49c: LeaveFrame
    //     0x84a49c: mov             SP, fp
    //     0x84a4a0: ldp             fp, lr, [SP], #0x10
    // 0x84a4a4: ret
    //     0x84a4a4: ret             
    // 0x84a4a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a4a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a4ac: b               #0x84a484
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0x84a4b0, size: 0x118
    // 0x84a4b0: EnterFrame
    //     0x84a4b0: stp             fp, lr, [SP, #-0x10]!
    //     0x84a4b4: mov             fp, SP
    // 0x84a4b8: AllocStack(0x18)
    //     0x84a4b8: sub             SP, SP, #0x18
    // 0x84a4bc: CheckStackOverflow
    //     0x84a4bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a4c0: cmp             SP, x16
    //     0x84a4c4: b.ls            #0x84a59c
    // 0x84a4c8: ldr             x0, [fp, #0x18]
    // 0x84a4cc: LoadField: r1 = r0->field_b
    //     0x84a4cc: ldur            w1, [x0, #0xb]
    // 0x84a4d0: DecompressPointer r1
    //     0x84a4d0: add             x1, x1, HEAP, lsl #32
    // 0x84a4d4: cmp             w1, NULL
    // 0x84a4d8: b.eq            #0x84a5a4
    // 0x84a4dc: LoadField: r2 = r1->field_b
    //     0x84a4dc: ldur            w2, [x1, #0xb]
    // 0x84a4e0: DecompressPointer r2
    //     0x84a4e0: add             x2, x2, HEAP, lsl #32
    // 0x84a4e4: stur            x2, [fp, #-0x18]
    // 0x84a4e8: cmp             w2, NULL
    // 0x84a4ec: b.eq            #0x84a5a8
    // 0x84a4f0: LoadField: r1 = r2->field_43
    //     0x84a4f0: ldur            w1, [x2, #0x43]
    // 0x84a4f4: DecompressPointer r1
    //     0x84a4f4: add             x1, x1, HEAP, lsl #32
    // 0x84a4f8: r16 = Sentinel
    //     0x84a4f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84a4fc: cmp             w1, w16
    // 0x84a500: b.eq            #0x84a5ac
    // 0x84a504: r16 = Instance_AnimationStatus
    //     0x84a504: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbc0] Obj!AnimationStatus@b65f11
    //     0x84a508: ldr             x16, [x16, #0xbc0]
    // 0x84a50c: cmp             w1, w16
    // 0x84a510: b.ne            #0x84a524
    // 0x84a514: r0 = Null
    //     0x84a514: mov             x0, NULL
    // 0x84a518: LeaveFrame
    //     0x84a518: mov             SP, fp
    //     0x84a51c: ldp             fp, lr, [SP], #0x10
    // 0x84a520: ret
    //     0x84a520: ret             
    // 0x84a524: ldr             x1, [fp, #0x10]
    // 0x84a528: LoadField: r3 = r2->field_37
    //     0x84a528: ldur            w3, [x2, #0x37]
    // 0x84a52c: DecompressPointer r3
    //     0x84a52c: add             x3, x3, HEAP, lsl #32
    // 0x84a530: r16 = Sentinel
    //     0x84a530: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84a534: cmp             w3, w16
    // 0x84a538: b.eq            #0x84a5b8
    // 0x84a53c: stur            x3, [fp, #-0x10]
    // 0x84a540: LoadField: r4 = r1->field_f
    //     0x84a540: ldur            w4, [x1, #0xf]
    // 0x84a544: DecompressPointer r4
    //     0x84a544: add             x4, x4, HEAP, lsl #32
    // 0x84a548: stur            x4, [fp, #-8]
    // 0x84a54c: cmp             w4, NULL
    // 0x84a550: b.eq            #0x84a5c4
    // 0x84a554: SaveReg r0
    //     0x84a554: str             x0, [SP, #-8]!
    // 0x84a558: r0 = _childHeight()
    //     0x84a558: bl              #0x84a32c  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_childHeight
    // 0x84a55c: add             SP, SP, #8
    // 0x84a560: ldur            x0, [fp, #-8]
    // 0x84a564: LoadField: d1 = r0->field_7
    //     0x84a564: ldur            d1, [x0, #7]
    // 0x84a568: fdiv            d2, d1, d0
    // 0x84a56c: ldur            x0, [fp, #-0x10]
    // 0x84a570: LoadField: d0 = r0->field_7
    //     0x84a570: ldur            d0, [x0, #7]
    // 0x84a574: fsub            d1, d0, d2
    // 0x84a578: ldur            x16, [fp, #-0x18]
    // 0x84a57c: SaveReg r16
    //     0x84a57c: str             x16, [SP, #-8]!
    // 0x84a580: SaveReg d1
    //     0x84a580: str             d1, [SP, #-8]!
    // 0x84a584: r0 = value=()
    //     0x84a584: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x84a588: add             SP, SP, #0x10
    // 0x84a58c: r0 = Null
    //     0x84a58c: mov             x0, NULL
    // 0x84a590: LeaveFrame
    //     0x84a590: mov             SP, fp
    //     0x84a594: ldp             fp, lr, [SP], #0x10
    // 0x84a598: ret
    //     0x84a598: ret             
    // 0x84a59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a59c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a5a0: b               #0x84a4c8
    // 0x84a5a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a5a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84a5a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a5a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84a5ac: r9 = _status
    //     0x84a5ac: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbe0] Field <AnimationController._status@575066280>: late (offset: 0x44)
    //     0x84a5b0: ldr             x9, [x9, #0xbe0]
    // 0x84a5b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84a5b4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84a5b8: r9 = _value
    //     0x84a5b8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x84a5bc: ldr             x9, [x9, #0xbb0]
    // 0x84a5c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84a5c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84a5c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a5c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x84a5c8, size: 0x4c
    // 0x84a5c8: EnterFrame
    //     0x84a5c8: stp             fp, lr, [SP, #-0x10]!
    //     0x84a5cc: mov             fp, SP
    // 0x84a5d0: ldr             x0, [fp, #0x18]
    // 0x84a5d4: LoadField: r1 = r0->field_17
    //     0x84a5d4: ldur            w1, [x0, #0x17]
    // 0x84a5d8: DecompressPointer r1
    //     0x84a5d8: add             x1, x1, HEAP, lsl #32
    // 0x84a5dc: CheckStackOverflow
    //     0x84a5dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a5e0: cmp             SP, x16
    //     0x84a5e4: b.ls            #0x84a60c
    // 0x84a5e8: LoadField: r0 = r1->field_f
    //     0x84a5e8: ldur            w0, [x1, #0xf]
    // 0x84a5ec: DecompressPointer r0
    //     0x84a5ec: add             x0, x0, HEAP, lsl #32
    // 0x84a5f0: ldr             x16, [fp, #0x10]
    // 0x84a5f4: stp             x16, x0, [SP, #-0x10]!
    // 0x84a5f8: r0 = _handleDragStart()
    //     0x84a5f8: bl              #0x84a614  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::_handleDragStart
    // 0x84a5fc: add             SP, SP, #0x10
    // 0x84a600: LeaveFrame
    //     0x84a600: mov             SP, fp
    //     0x84a604: ldp             fp, lr, [SP], #0x10
    // 0x84a608: ret
    //     0x84a608: ret             
    // 0x84a60c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a60c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a610: b               #0x84a5e8
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0x84a614, size: 0x6c
    // 0x84a614: EnterFrame
    //     0x84a614: stp             fp, lr, [SP, #-0x10]!
    //     0x84a618: mov             fp, SP
    // 0x84a61c: CheckStackOverflow
    //     0x84a61c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a620: cmp             SP, x16
    //     0x84a624: b.ls            #0x84a674
    // 0x84a628: ldr             x0, [fp, #0x18]
    // 0x84a62c: LoadField: r1 = r0->field_b
    //     0x84a62c: ldur            w1, [x0, #0xb]
    // 0x84a630: DecompressPointer r1
    //     0x84a630: add             x1, x1, HEAP, lsl #32
    // 0x84a634: cmp             w1, NULL
    // 0x84a638: b.eq            #0x84a67c
    // 0x84a63c: LoadField: r0 = r1->field_1b
    //     0x84a63c: ldur            w0, [x1, #0x1b]
    // 0x84a640: DecompressPointer r0
    //     0x84a640: add             x0, x0, HEAP, lsl #32
    // 0x84a644: cmp             w0, NULL
    // 0x84a648: b.eq            #0x84a664
    // 0x84a64c: ldr             x16, [fp, #0x10]
    // 0x84a650: stp             x16, x0, [SP, #-0x10]!
    // 0x84a654: ClosureCall
    //     0x84a654: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84a658: ldur            x2, [x0, #0x1f]
    //     0x84a65c: blr             x2
    // 0x84a660: add             SP, SP, #0x10
    // 0x84a664: r0 = Null
    //     0x84a664: mov             x0, NULL
    // 0x84a668: LeaveFrame
    //     0x84a668: mov             SP, fp
    //     0x84a66c: ldp             fp, lr, [SP], #0x10
    // 0x84a670: ret
    //     0x84a670: ret             
    // 0x84a674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a678: b               #0x84a628
    // 0x84a67c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a67c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool extentChanged(dynamic, DraggableScrollableNotification) {
    // ** addr: 0x84a680, size: 0x4c
    // 0x84a680: EnterFrame
    //     0x84a680: stp             fp, lr, [SP, #-0x10]!
    //     0x84a684: mov             fp, SP
    // 0x84a688: ldr             x0, [fp, #0x18]
    // 0x84a68c: LoadField: r1 = r0->field_17
    //     0x84a68c: ldur            w1, [x0, #0x17]
    // 0x84a690: DecompressPointer r1
    //     0x84a690: add             x1, x1, HEAP, lsl #32
    // 0x84a694: CheckStackOverflow
    //     0x84a694: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a698: cmp             SP, x16
    //     0x84a69c: b.ls            #0x84a6c4
    // 0x84a6a0: LoadField: r0 = r1->field_f
    //     0x84a6a0: ldur            w0, [x1, #0xf]
    // 0x84a6a4: DecompressPointer r0
    //     0x84a6a4: add             x0, x0, HEAP, lsl #32
    // 0x84a6a8: ldr             x16, [fp, #0x10]
    // 0x84a6ac: stp             x16, x0, [SP, #-0x10]!
    // 0x84a6b0: r0 = extentChanged()
    //     0x84a6b0: bl              #0x84a6cc  ; [package:flutter/src/material/bottom_sheet.dart] _BottomSheetState::extentChanged
    // 0x84a6b4: add             SP, SP, #0x10
    // 0x84a6b8: LeaveFrame
    //     0x84a6b8: mov             SP, fp
    //     0x84a6bc: ldp             fp, lr, [SP], #0x10
    // 0x84a6c0: ret
    //     0x84a6c0: ret             
    // 0x84a6c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a6c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a6c8: b               #0x84a6a0
  }
  _ extentChanged(/* No info */) {
    // ** addr: 0x84a6cc, size: 0xcc
    // 0x84a6cc: EnterFrame
    //     0x84a6cc: stp             fp, lr, [SP, #-0x10]!
    //     0x84a6d0: mov             fp, SP
    // 0x84a6d4: AllocStack(0x8)
    //     0x84a6d4: sub             SP, SP, #8
    // 0x84a6d8: CheckStackOverflow
    //     0x84a6d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84a6dc: cmp             SP, x16
    //     0x84a6e0: b.ls            #0x84a78c
    // 0x84a6e4: ldr             x16, [fp, #0x10]
    // 0x84a6e8: SaveReg r16
    //     0x84a6e8: str             x16, [SP, #-8]!
    // 0x84a6ec: r4 = 0
    //     0x84a6ec: mov             x4, #0
    // 0x84a6f0: ldr             x0, [SP]
    // 0x84a6f4: r16 = UnlinkedCall_0x4aeefc
    //     0x84a6f4: add             x16, PP, #0x40, lsl #12  ; [pp+0x402c0] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x84a6f8: add             x16, x16, #0x2c0
    // 0x84a6fc: ldp             x5, lr, [x16]
    // 0x84a700: blr             lr
    // 0x84a704: add             SP, SP, #8
    // 0x84a708: stur            x0, [fp, #-8]
    // 0x84a70c: ldr             x16, [fp, #0x10]
    // 0x84a710: SaveReg r16
    //     0x84a710: str             x16, [SP, #-8]!
    // 0x84a714: r4 = 0
    //     0x84a714: mov             x4, #0
    // 0x84a718: ldr             x0, [SP]
    // 0x84a71c: r16 = UnlinkedCall_0x4aeefc
    //     0x84a71c: add             x16, PP, #0x40, lsl #12  ; [pp+0x402d0] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x84a720: add             x16, x16, #0x2d0
    // 0x84a724: ldp             x5, lr, [x16]
    // 0x84a728: blr             lr
    // 0x84a72c: add             SP, SP, #8
    // 0x84a730: mov             x1, x0
    // 0x84a734: ldur            x0, [fp, #-8]
    // 0x84a738: LoadField: d0 = r0->field_7
    //     0x84a738: ldur            d0, [x0, #7]
    // 0x84a73c: LoadField: d1 = r1->field_7
    //     0x84a73c: ldur            d1, [x1, #7]
    // 0x84a740: fcmp            d0, d1
    // 0x84a744: b.vs            #0x84a77c
    // 0x84a748: b.ne            #0x84a77c
    // 0x84a74c: ldr             x0, [fp, #0x18]
    // 0x84a750: LoadField: r1 = r0->field_b
    //     0x84a750: ldur            w1, [x0, #0xb]
    // 0x84a754: DecompressPointer r1
    //     0x84a754: add             x1, x1, HEAP, lsl #32
    // 0x84a758: cmp             w1, NULL
    // 0x84a75c: b.eq            #0x84a794
    // 0x84a760: LoadField: r0 = r1->field_f
    //     0x84a760: ldur            w0, [x1, #0xf]
    // 0x84a764: DecompressPointer r0
    //     0x84a764: add             x0, x0, HEAP, lsl #32
    // 0x84a768: SaveReg r0
    //     0x84a768: str             x0, [SP, #-8]!
    // 0x84a76c: ClosureCall
    //     0x84a76c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x84a770: ldur            x2, [x0, #0x1f]
    //     0x84a774: blr             x2
    // 0x84a778: add             SP, SP, #8
    // 0x84a77c: r0 = false
    //     0x84a77c: add             x0, NULL, #0x30  ; false
    // 0x84a780: LeaveFrame
    //     0x84a780: mov             SP, fp
    //     0x84a784: ldp             fp, lr, [SP], #0x10
    // 0x84a788: ret
    //     0x84a788: ret             
    // 0x84a78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a78c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a790: b               #0x84a6e4
    // 0x84a794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84a794: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4167, size: 0x30, field offset: 0xc
//   const constructor, 
class _ModalBottomSheet<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa401bc, size: 0x4c
    // 0xa401bc: EnterFrame
    //     0xa401bc: stp             fp, lr, [SP, #-0x10]!
    //     0xa401c0: mov             fp, SP
    // 0xa401c4: ldr             x0, [fp, #0x10]
    // 0xa401c8: LoadField: r2 = r0->field_b
    //     0xa401c8: ldur            w2, [x0, #0xb]
    // 0xa401cc: DecompressPointer r2
    //     0xa401cc: add             x2, x2, HEAP, lsl #32
    // 0xa401d0: r1 = Null
    //     0xa401d0: mov             x1, NULL
    // 0xa401d4: r3 = <_ModalBottomSheet<X0>, X0>
    //     0xa401d4: add             x3, PP, #0x37, lsl #12  ; [pp+0x37970] TypeArguments: <_ModalBottomSheet<X0>, X0>
    //     0xa401d8: ldr             x3, [x3, #0x970]
    // 0xa401dc: r24 = InstantiateTypeArgumentsStub
    //     0xa401dc: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xa401e0: LoadField: r30 = r24->field_7
    //     0xa401e0: ldur            lr, [x24, #7]
    // 0xa401e4: blr             lr
    // 0xa401e8: mov             x1, x0
    // 0xa401ec: r0 = _ModalBottomSheetState()
    //     0xa401ec: bl              #0xa40208  ; Allocate_ModalBottomSheetStateStub -> _ModalBottomSheetState<_ModalBottomSheet<C1X0>> (size=0x18)
    // 0xa401f0: r1 = Instance_Cubic
    //     0xa401f0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37978] Obj!Cubic<double>@b4f491
    //     0xa401f4: ldr             x1, [x1, #0x978]
    // 0xa401f8: StoreField: r0->field_13 = r1
    //     0xa401f8: stur            w1, [x0, #0x13]
    // 0xa401fc: LeaveFrame
    //     0xa401fc: mov             SP, fp
    //     0xa40200: ldp             fp, lr, [SP], #0x10
    // 0xa40204: ret
    //     0xa40204: ret             
  }
}

// class id: 4168, size: 0x38, field offset: 0xc
//   const constructor, 
class BottomSheet extends StatefulWidget {

  static _ createAnimationController(/* No info */) {
    // ** addr: 0x7bb700, size: 0x68
    // 0x7bb700: EnterFrame
    //     0x7bb700: stp             fp, lr, [SP, #-0x10]!
    //     0x7bb704: mov             fp, SP
    // 0x7bb708: AllocStack(0x8)
    //     0x7bb708: sub             SP, SP, #8
    // 0x7bb70c: CheckStackOverflow
    //     0x7bb70c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bb710: cmp             SP, x16
    //     0x7bb714: b.ls            #0x7bb760
    // 0x7bb718: r1 = <double>
    //     0x7bb718: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7bb71c: r0 = AnimationController()
    //     0x7bb71c: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x7bb720: stur            x0, [fp, #-8]
    // 0x7bb724: ldr             x16, [fp, #0x10]
    // 0x7bb728: stp             x16, x0, [SP, #-0x10]!
    // 0x7bb72c: r16 = Instance_Duration
    //     0x7bb72c: add             x16, PP, #8, lsl #12  ; [pp+0x85d8] Obj!Duration@b67a61
    //     0x7bb730: ldr             x16, [x16, #0x5d8]
    // 0x7bb734: r30 = Instance_Duration
    //     0x7bb734: add             lr, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x7bb738: ldr             lr, [lr, #0x9e0]
    // 0x7bb73c: stp             lr, x16, [SP, #-0x10]!
    // 0x7bb740: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0x7bb740: add             x4, PP, #0x21, lsl #12  ; [pp+0x218b8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0x7bb744: ldr             x4, [x4, #0x8b8]
    // 0x7bb748: r0 = AnimationController()
    //     0x7bb748: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x7bb74c: add             SP, SP, #0x20
    // 0x7bb750: ldur            x0, [fp, #-8]
    // 0x7bb754: LeaveFrame
    //     0x7bb754: mov             SP, fp
    //     0x7bb758: ldp             fp, lr, [SP], #0x10
    // 0x7bb75c: ret
    //     0x7bb75c: ret             
    // 0x7bb760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bb760: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bb764: b               #0x7bb718
  }
  _ createState(/* No info */) {
    // ** addr: 0xa40168, size: 0x48
    // 0xa40168: EnterFrame
    //     0xa40168: stp             fp, lr, [SP, #-0x10]!
    //     0xa4016c: mov             fp, SP
    // 0xa40170: AllocStack(0x8)
    //     0xa40170: sub             SP, SP, #8
    // 0xa40174: r1 = <State<StatefulWidget>>
    //     0xa40174: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0xa40178: r0 = LabeledGlobalKey()
    //     0xa40178: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa4017c: mov             x2, x0
    // 0xa40180: r0 = "BottomSheet child"
    //     0xa40180: add             x0, PP, #0x37, lsl #12  ; [pp+0x37980] "BottomSheet child"
    //     0xa40184: ldr             x0, [x0, #0x980]
    // 0xa40188: stur            x2, [fp, #-8]
    // 0xa4018c: StoreField: r2->field_b = r0
    //     0xa4018c: stur            w0, [x2, #0xb]
    // 0xa40190: r1 = <BottomSheet>
    //     0xa40190: add             x1, PP, #0x37, lsl #12  ; [pp+0x37988] TypeArguments: <BottomSheet>
    //     0xa40194: ldr             x1, [x1, #0x988]
    // 0xa40198: r0 = _BottomSheetState()
    //     0xa40198: bl              #0xa401b0  ; Allocate_BottomSheetStateStub -> _BottomSheetState (size=0x18)
    // 0xa4019c: ldur            x1, [fp, #-8]
    // 0xa401a0: StoreField: r0->field_13 = r1
    //     0xa401a0: stur            w1, [x0, #0x13]
    // 0xa401a4: LeaveFrame
    //     0xa401a4: mov             SP, fp
    //     0xa401a8: ldp             fp, lr, [SP], #0x10
    // 0xa401ac: ret
    //     0xa401ac: ret             
  }
}

// class id: 4280, size: 0x18, field offset: 0xc
//   const constructor, 
class _BottomSheetSuspendedCurve extends ParametricCurve<double> {

  _ transform(/* No info */) {
    // ** addr: 0xc5090c, size: 0x16c
    // 0xc5090c: EnterFrame
    //     0xc5090c: stp             fp, lr, [SP, #-0x10]!
    //     0xc50910: mov             fp, SP
    // 0xc50914: AllocStack(0x8)
    //     0xc50914: sub             SP, SP, #8
    // 0xc50918: CheckStackOverflow
    //     0xc50918: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5091c: cmp             SP, x16
    //     0xc50920: b.ls            #0xc50a30
    // 0xc50924: ldr             x0, [fp, #0x18]
    // 0xc50928: LoadField: d0 = r0->field_b
    //     0xc50928: ldur            d0, [x0, #0xb]
    // 0xc5092c: ldr             d1, [fp, #0x10]
    // 0xc50930: stur            d0, [fp, #-8]
    // 0xc50934: fcmp            d1, d0
    // 0xc50938: b.vs            #0xc50974
    // 0xc5093c: b.ge            #0xc50974
    // 0xc50940: r0 = inline_Allocate_Double()
    //     0xc50940: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc50944: add             x0, x0, #0x10
    //     0xc50948: cmp             x1, x0
    //     0xc5094c: b.ls            #0xc50a38
    //     0xc50950: str             x0, [THR, #0x60]  ; THR::top
    //     0xc50954: sub             x0, x0, #0xf
    //     0xc50958: mov             x1, #0xd108
    //     0xc5095c: movk            x1, #3, lsl #16
    //     0xc50960: stur            x1, [x0, #-1]
    // 0xc50964: StoreField: r0->field_7 = d1
    //     0xc50964: stur            d1, [x0, #7]
    // 0xc50968: LeaveFrame
    //     0xc50968: mov             SP, fp
    //     0xc5096c: ldp             fp, lr, [SP], #0x10
    // 0xc50970: ret
    //     0xc50970: ret             
    // 0xc50974: d2 = 1.000000
    //     0xc50974: fmov            d2, #1.00000000
    // 0xc50978: fcmp            d1, d2
    // 0xc5097c: b.vs            #0xc509b8
    // 0xc50980: b.ne            #0xc509b8
    // 0xc50984: r0 = inline_Allocate_Double()
    //     0xc50984: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc50988: add             x0, x0, #0x10
    //     0xc5098c: cmp             x1, x0
    //     0xc50990: b.ls            #0xc50a48
    //     0xc50994: str             x0, [THR, #0x60]  ; THR::top
    //     0xc50998: sub             x0, x0, #0xf
    //     0xc5099c: mov             x1, #0xd108
    //     0xc509a0: movk            x1, #3, lsl #16
    //     0xc509a4: stur            x1, [x0, #-1]
    // 0xc509a8: StoreField: r0->field_7 = d1
    //     0xc509a8: stur            d1, [x0, #7]
    // 0xc509ac: LeaveFrame
    //     0xc509ac: mov             SP, fp
    //     0xc509b0: ldp             fp, lr, [SP], #0x10
    // 0xc509b4: ret
    //     0xc509b4: ret             
    // 0xc509b8: fsub            d3, d1, d0
    // 0xc509bc: fsub            d1, d2, d0
    // 0xc509c0: fdiv            d2, d3, d1
    // 0xc509c4: r16 = Instance_Cubic
    //     0xc509c4: add             x16, PP, #0x37, lsl #12  ; [pp+0x37978] Obj!Cubic<double>@b4f491
    //     0xc509c8: ldr             x16, [x16, #0x978]
    // 0xc509cc: SaveReg r16
    //     0xc509cc: str             x16, [SP, #-8]!
    // 0xc509d0: SaveReg d2
    //     0xc509d0: str             d2, [SP, #-8]!
    // 0xc509d4: r0 = transform()
    //     0xc509d4: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xc509d8: add             SP, SP, #0x10
    // 0xc509dc: ldur            d0, [fp, #-8]
    // 0xc509e0: r1 = inline_Allocate_Double()
    //     0xc509e0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc509e4: add             x1, x1, #0x10
    //     0xc509e8: cmp             x2, x1
    //     0xc509ec: b.ls            #0xc50a58
    //     0xc509f0: str             x1, [THR, #0x60]  ; THR::top
    //     0xc509f4: sub             x1, x1, #0xf
    //     0xc509f8: mov             x2, #0xd108
    //     0xc509fc: movk            x2, #3, lsl #16
    //     0xc50a00: stur            x2, [x1, #-1]
    // 0xc50a04: StoreField: r1->field_7 = d0
    //     0xc50a04: stur            d0, [x1, #7]
    // 0xc50a08: r16 = 2
    //     0xc50a08: mov             x16, #2
    // 0xc50a0c: stp             x16, x1, [SP, #-0x10]!
    // 0xc50a10: SaveReg r0
    //     0xc50a10: str             x0, [SP, #-8]!
    // 0xc50a14: r0 = lerpDouble()
    //     0xc50a14: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xc50a18: add             SP, SP, #0x18
    // 0xc50a1c: cmp             w0, NULL
    // 0xc50a20: b.eq            #0xc50a74
    // 0xc50a24: LeaveFrame
    //     0xc50a24: mov             SP, fp
    //     0xc50a28: ldp             fp, lr, [SP], #0x10
    // 0xc50a2c: ret
    //     0xc50a2c: ret             
    // 0xc50a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc50a30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc50a34: b               #0xc50924
    // 0xc50a38: SaveReg d1
    //     0xc50a38: str             q1, [SP, #-0x10]!
    // 0xc50a3c: r0 = AllocateDouble()
    //     0xc50a3c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc50a40: RestoreReg d1
    //     0xc50a40: ldr             q1, [SP], #0x10
    // 0xc50a44: b               #0xc50964
    // 0xc50a48: SaveReg d1
    //     0xc50a48: str             q1, [SP, #-0x10]!
    // 0xc50a4c: r0 = AllocateDouble()
    //     0xc50a4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc50a50: RestoreReg d1
    //     0xc50a50: ldr             q1, [SP], #0x10
    // 0xc50a54: b               #0xc509a8
    // 0xc50a58: SaveReg d0
    //     0xc50a58: str             q0, [SP, #-0x10]!
    // 0xc50a5c: SaveReg r0
    //     0xc50a5c: str             x0, [SP, #-8]!
    // 0xc50a60: r0 = AllocateDouble()
    //     0xc50a60: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc50a64: mov             x1, x0
    // 0xc50a68: RestoreReg r0
    //     0xc50a68: ldr             x0, [SP], #8
    // 0xc50a6c: RestoreReg d0
    //     0xc50a6c: ldr             q0, [SP], #0x10
    // 0xc50a70: b               #0xc50a04
    // 0xc50a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc50a74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

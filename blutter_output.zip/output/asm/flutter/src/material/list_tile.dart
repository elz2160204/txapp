// lib: , url: package:flutter/src/material/list_tile.dart

// class id: 1049264, size: 0x8
class :: {
}

// class id: 2444, size: 0x64, field offset: 0x60
//   transformed mixin,
abstract class __RenderListTile&RenderBox&SlottedContainerRenderObjectMixin extends RenderBox
     with SlottedContainerRenderObjectMixin<X0> {

  _ visitChildren(/* No info */) {
    // ** addr: 0x6bfc28, size: 0x118
    // 0x6bfc28: EnterFrame
    //     0x6bfc28: stp             fp, lr, [SP, #-0x10]!
    //     0x6bfc2c: mov             fp, SP
    // 0x6bfc30: AllocStack(0x18)
    //     0x6bfc30: sub             SP, SP, #0x18
    // 0x6bfc34: CheckStackOverflow
    //     0x6bfc34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bfc38: cmp             SP, x16
    //     0x6bfc3c: b.ls            #0x6bfd2c
    // 0x6bfc40: ldr             x16, [fp, #0x18]
    // 0x6bfc44: SaveReg r16
    //     0x6bfc44: str             x16, [SP, #-8]!
    // 0x6bfc48: r0 = children()
    //     0x6bfc48: bl              #0x629110  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::children
    // 0x6bfc4c: add             SP, SP, #8
    // 0x6bfc50: mov             x2, x0
    // 0x6bfc54: stur            x2, [fp, #-0x18]
    // 0x6bfc58: LoadField: r3 = r2->field_b
    //     0x6bfc58: ldur            w3, [x2, #0xb]
    // 0x6bfc5c: DecompressPointer r3
    //     0x6bfc5c: add             x3, x3, HEAP, lsl #32
    // 0x6bfc60: stur            x3, [fp, #-0x10]
    // 0x6bfc64: r0 = LoadInt32Instr(r3)
    //     0x6bfc64: sbfx            x0, x3, #1, #0x1f
    // 0x6bfc68: r4 = 0
    //     0x6bfc68: mov             x4, #0
    // 0x6bfc6c: stur            x4, [fp, #-8]
    // 0x6bfc70: CheckStackOverflow
    //     0x6bfc70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bfc74: cmp             SP, x16
    //     0x6bfc78: b.ls            #0x6bfd34
    // 0x6bfc7c: cmp             x4, x0
    // 0x6bfc80: b.ge            #0x6bfd00
    // 0x6bfc84: mov             x1, x4
    // 0x6bfc88: cmp             x1, x0
    // 0x6bfc8c: b.hs            #0x6bfd3c
    // 0x6bfc90: LoadField: r0 = r2->field_f
    //     0x6bfc90: ldur            w0, [x2, #0xf]
    // 0x6bfc94: DecompressPointer r0
    //     0x6bfc94: add             x0, x0, HEAP, lsl #32
    // 0x6bfc98: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x6bfc98: add             x16, x0, x4, lsl #2
    //     0x6bfc9c: ldur            w1, [x16, #0xf]
    // 0x6bfca0: DecompressPointer r1
    //     0x6bfca0: add             x1, x1, HEAP, lsl #32
    // 0x6bfca4: ldr             x16, [fp, #0x10]
    // 0x6bfca8: stp             x1, x16, [SP, #-0x10]!
    // 0x6bfcac: ldr             x0, [fp, #0x10]
    // 0x6bfcb0: ClosureCall
    //     0x6bfcb0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bfcb4: ldur            x2, [x0, #0x1f]
    //     0x6bfcb8: blr             x2
    // 0x6bfcbc: add             SP, SP, #0x10
    // 0x6bfcc0: ldur            x0, [fp, #-0x18]
    // 0x6bfcc4: LoadField: r1 = r0->field_b
    //     0x6bfcc4: ldur            w1, [x0, #0xb]
    // 0x6bfcc8: DecompressPointer r1
    //     0x6bfcc8: add             x1, x1, HEAP, lsl #32
    // 0x6bfccc: ldur            x2, [fp, #-0x10]
    // 0x6bfcd0: cmp             w1, w2
    // 0x6bfcd4: b.ne            #0x6bfd10
    // 0x6bfcd8: ldur            x3, [fp, #-8]
    // 0x6bfcdc: add             x4, x3, #1
    // 0x6bfce0: r3 = LoadInt32Instr(r1)
    //     0x6bfce0: sbfx            x3, x1, #1, #0x1f
    // 0x6bfce4: mov             x16, x2
    // 0x6bfce8: mov             x2, x3
    // 0x6bfcec: mov             x3, x16
    // 0x6bfcf0: mov             x16, x0
    // 0x6bfcf4: mov             x0, x2
    // 0x6bfcf8: mov             x2, x16
    // 0x6bfcfc: b               #0x6bfc6c
    // 0x6bfd00: r0 = Null
    //     0x6bfd00: mov             x0, NULL
    // 0x6bfd04: LeaveFrame
    //     0x6bfd04: mov             SP, fp
    //     0x6bfd08: ldp             fp, lr, [SP], #0x10
    // 0x6bfd0c: ret
    //     0x6bfd0c: ret             
    // 0x6bfd10: r0 = ConcurrentModificationError()
    //     0x6bfd10: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6bfd14: mov             x1, x0
    // 0x6bfd18: ldur            x0, [fp, #-0x18]
    // 0x6bfd1c: StoreField: r1->field_b = r0
    //     0x6bfd1c: stur            w0, [x1, #0xb]
    // 0x6bfd20: mov             x0, x1
    // 0x6bfd24: r0 = Throw()
    //     0x6bfd24: bl              #0xd67e38  ; ThrowStub
    // 0x6bfd28: brk             #0
    // 0x6bfd2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bfd2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bfd30: b               #0x6bfc40
    // 0x6bfd34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bfd34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bfd38: b               #0x6bfc7c
    // 0x6bfd3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6bfd3c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792f38, size: 0x10c
    // 0x792f38: EnterFrame
    //     0x792f38: stp             fp, lr, [SP, #-0x10]!
    //     0x792f3c: mov             fp, SP
    // 0x792f40: AllocStack(0x18)
    //     0x792f40: sub             SP, SP, #0x18
    // 0x792f44: CheckStackOverflow
    //     0x792f44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792f48: cmp             SP, x16
    //     0x792f4c: b.ls            #0x793030
    // 0x792f50: ldr             x16, [fp, #0x10]
    // 0x792f54: SaveReg r16
    //     0x792f54: str             x16, [SP, #-8]!
    // 0x792f58: r0 = children()
    //     0x792f58: bl              #0x629110  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::children
    // 0x792f5c: add             SP, SP, #8
    // 0x792f60: mov             x2, x0
    // 0x792f64: stur            x2, [fp, #-0x18]
    // 0x792f68: LoadField: r3 = r2->field_b
    //     0x792f68: ldur            w3, [x2, #0xb]
    // 0x792f6c: DecompressPointer r3
    //     0x792f6c: add             x3, x3, HEAP, lsl #32
    // 0x792f70: stur            x3, [fp, #-0x10]
    // 0x792f74: r0 = LoadInt32Instr(r3)
    //     0x792f74: sbfx            x0, x3, #1, #0x1f
    // 0x792f78: r4 = 0
    //     0x792f78: mov             x4, #0
    // 0x792f7c: stur            x4, [fp, #-8]
    // 0x792f80: CheckStackOverflow
    //     0x792f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792f84: cmp             SP, x16
    //     0x792f88: b.ls            #0x793038
    // 0x792f8c: cmp             x4, x0
    // 0x792f90: b.ge            #0x793004
    // 0x792f94: mov             x1, x4
    // 0x792f98: cmp             x1, x0
    // 0x792f9c: b.hs            #0x793040
    // 0x792fa0: LoadField: r0 = r2->field_f
    //     0x792fa0: ldur            w0, [x2, #0xf]
    // 0x792fa4: DecompressPointer r0
    //     0x792fa4: add             x0, x0, HEAP, lsl #32
    // 0x792fa8: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x792fa8: add             x16, x0, x4, lsl #2
    //     0x792fac: ldur            w1, [x16, #0xf]
    // 0x792fb0: DecompressPointer r1
    //     0x792fb0: add             x1, x1, HEAP, lsl #32
    // 0x792fb4: ldr             x16, [fp, #0x10]
    // 0x792fb8: stp             x1, x16, [SP, #-0x10]!
    // 0x792fbc: r0 = redepthChild()
    //     0x792fbc: bl              #0x5e631c  ; [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild
    // 0x792fc0: add             SP, SP, #0x10
    // 0x792fc4: ldur            x0, [fp, #-0x18]
    // 0x792fc8: LoadField: r1 = r0->field_b
    //     0x792fc8: ldur            w1, [x0, #0xb]
    // 0x792fcc: DecompressPointer r1
    //     0x792fcc: add             x1, x1, HEAP, lsl #32
    // 0x792fd0: ldur            x2, [fp, #-0x10]
    // 0x792fd4: cmp             w1, w2
    // 0x792fd8: b.ne            #0x793014
    // 0x792fdc: ldur            x3, [fp, #-8]
    // 0x792fe0: add             x4, x3, #1
    // 0x792fe4: r3 = LoadInt32Instr(r1)
    //     0x792fe4: sbfx            x3, x1, #1, #0x1f
    // 0x792fe8: mov             x16, x2
    // 0x792fec: mov             x2, x3
    // 0x792ff0: mov             x3, x16
    // 0x792ff4: mov             x16, x0
    // 0x792ff8: mov             x0, x2
    // 0x792ffc: mov             x2, x16
    // 0x793000: b               #0x792f7c
    // 0x793004: r0 = Null
    //     0x793004: mov             x0, NULL
    // 0x793008: LeaveFrame
    //     0x793008: mov             SP, fp
    //     0x79300c: ldp             fp, lr, [SP], #0x10
    // 0x793010: ret
    //     0x793010: ret             
    // 0x793014: r0 = ConcurrentModificationError()
    //     0x793014: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x793018: mov             x1, x0
    // 0x79301c: ldur            x0, [fp, #-0x18]
    // 0x793020: StoreField: r1->field_b = r0
    //     0x793020: stur            w0, [x1, #0xb]
    // 0x793024: mov             x0, x1
    // 0x793028: r0 = Throw()
    //     0x793028: bl              #0xd67e38  ; ThrowStub
    // 0x79302c: brk             #0
    // 0x793030: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x793030: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x793034: b               #0x792f50
    // 0x793038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x793038: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79303c: b               #0x792f8c
    // 0x793040: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x793040: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bdc40, size: 0x1ec
    // 0x9bdc40: EnterFrame
    //     0x9bdc40: stp             fp, lr, [SP, #-0x10]!
    //     0x9bdc44: mov             fp, SP
    // 0x9bdc48: AllocStack(0x30)
    //     0x9bdc48: sub             SP, SP, #0x30
    // 0x9bdc4c: CheckStackOverflow
    //     0x9bdc4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bdc50: cmp             SP, x16
    //     0x9bdc54: b.ls            #0x9bde1c
    // 0x9bdc58: ldr             x0, [fp, #0x10]
    // 0x9bdc5c: r2 = Null
    //     0x9bdc5c: mov             x2, NULL
    // 0x9bdc60: r1 = Null
    //     0x9bdc60: mov             x1, NULL
    // 0x9bdc64: r4 = 59
    //     0x9bdc64: mov             x4, #0x3b
    // 0x9bdc68: branchIfSmi(r0, 0x9bdc74)
    //     0x9bdc68: tbz             w0, #0, #0x9bdc74
    // 0x9bdc6c: r4 = LoadClassIdInstr(r0)
    //     0x9bdc6c: ldur            x4, [x0, #-1]
    //     0x9bdc70: ubfx            x4, x4, #0xc, #0x14
    // 0x9bdc74: cmp             x4, #0x7e6
    // 0x9bdc78: b.eq            #0x9bdc8c
    // 0x9bdc7c: r8 = PipelineOwner
    //     0x9bdc7c: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bdc80: r3 = Null
    //     0x9bdc80: add             x3, PP, #0x56, lsl #12  ; [pp+0x56d30] Null
    //     0x9bdc84: ldr             x3, [x3, #0xd30]
    // 0x9bdc88: r0 = DefaultTypeTest()
    //     0x9bdc88: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bdc8c: ldr             x16, [fp, #0x18]
    // 0x9bdc90: ldr             lr, [fp, #0x10]
    // 0x9bdc94: stp             lr, x16, [SP, #-0x10]!
    // 0x9bdc98: r0 = attach()
    //     0x9bdc98: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bdc9c: add             SP, SP, #0x10
    // 0x9bdca0: ldr             x16, [fp, #0x18]
    // 0x9bdca4: SaveReg r16
    //     0x9bdca4: str             x16, [SP, #-8]!
    // 0x9bdca8: r0 = children()
    //     0x9bdca8: bl              #0x629110  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::children
    // 0x9bdcac: add             SP, SP, #8
    // 0x9bdcb0: mov             x1, x0
    // 0x9bdcb4: stur            x1, [fp, #-0x20]
    // 0x9bdcb8: LoadField: r2 = r1->field_7
    //     0x9bdcb8: ldur            w2, [x1, #7]
    // 0x9bdcbc: DecompressPointer r2
    //     0x9bdcbc: add             x2, x2, HEAP, lsl #32
    // 0x9bdcc0: stur            x2, [fp, #-0x18]
    // 0x9bdcc4: LoadField: r0 = r1->field_b
    //     0x9bdcc4: ldur            w0, [x1, #0xb]
    // 0x9bdcc8: DecompressPointer r0
    //     0x9bdcc8: add             x0, x0, HEAP, lsl #32
    // 0x9bdccc: r3 = LoadInt32Instr(r0)
    //     0x9bdccc: sbfx            x3, x0, #1, #0x1f
    // 0x9bdcd0: stur            x3, [fp, #-0x10]
    // 0x9bdcd4: r4 = 0
    //     0x9bdcd4: mov             x4, #0
    // 0x9bdcd8: stur            x4, [fp, #-8]
    // 0x9bdcdc: CheckStackOverflow
    //     0x9bdcdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bdce0: cmp             SP, x16
    //     0x9bdce4: b.ls            #0x9bde24
    // 0x9bdce8: r0 = LoadClassIdInstr(r1)
    //     0x9bdce8: ldur            x0, [x1, #-1]
    //     0x9bdcec: ubfx            x0, x0, #0xc, #0x14
    // 0x9bdcf0: SaveReg r1
    //     0x9bdcf0: str             x1, [SP, #-8]!
    // 0x9bdcf4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x9bdcf4: mov             x17, #0xb8ea
    //     0x9bdcf8: add             lr, x0, x17
    //     0x9bdcfc: ldr             lr, [x21, lr, lsl #3]
    //     0x9bdd00: blr             lr
    // 0x9bdd04: add             SP, SP, #8
    // 0x9bdd08: r1 = LoadInt32Instr(r0)
    //     0x9bdd08: sbfx            x1, x0, #1, #0x1f
    //     0x9bdd0c: tbz             w0, #0, #0x9bdd14
    //     0x9bdd10: ldur            x1, [x0, #7]
    // 0x9bdd14: ldur            x2, [fp, #-0x10]
    // 0x9bdd18: cmp             x2, x1
    // 0x9bdd1c: b.ne            #0x9bde04
    // 0x9bdd20: ldur            x3, [fp, #-0x20]
    // 0x9bdd24: ldur            x4, [fp, #-8]
    // 0x9bdd28: cmp             x4, x1
    // 0x9bdd2c: b.lt            #0x9bdd40
    // 0x9bdd30: r0 = Null
    //     0x9bdd30: mov             x0, NULL
    // 0x9bdd34: LeaveFrame
    //     0x9bdd34: mov             SP, fp
    //     0x9bdd38: ldp             fp, lr, [SP], #0x10
    // 0x9bdd3c: ret
    //     0x9bdd3c: ret             
    // 0x9bdd40: r0 = BoxInt64Instr(r4)
    //     0x9bdd40: sbfiz           x0, x4, #1, #0x1f
    //     0x9bdd44: cmp             x4, x0, asr #1
    //     0x9bdd48: b.eq            #0x9bdd54
    //     0x9bdd4c: bl              #0xd69bb8
    //     0x9bdd50: stur            x4, [x0, #7]
    // 0x9bdd54: r1 = LoadClassIdInstr(r3)
    //     0x9bdd54: ldur            x1, [x3, #-1]
    //     0x9bdd58: ubfx            x1, x1, #0xc, #0x14
    // 0x9bdd5c: stp             x0, x3, [SP, #-0x10]!
    // 0x9bdd60: mov             x0, x1
    // 0x9bdd64: r0 = GDT[cid_x0 + 0xd175]()
    //     0x9bdd64: mov             x17, #0xd175
    //     0x9bdd68: add             lr, x0, x17
    //     0x9bdd6c: ldr             lr, [x21, lr, lsl #3]
    //     0x9bdd70: blr             lr
    // 0x9bdd74: add             SP, SP, #0x10
    // 0x9bdd78: mov             x3, x0
    // 0x9bdd7c: ldur            x0, [fp, #-8]
    // 0x9bdd80: stur            x3, [fp, #-0x30]
    // 0x9bdd84: add             x4, x0, #1
    // 0x9bdd88: stur            x4, [fp, #-0x28]
    // 0x9bdd8c: cmp             w3, NULL
    // 0x9bdd90: b.ne            #0x9bddc4
    // 0x9bdd94: mov             x0, x3
    // 0x9bdd98: ldur            x2, [fp, #-0x18]
    // 0x9bdd9c: r1 = Null
    //     0x9bdd9c: mov             x1, NULL
    // 0x9bdda0: cmp             w2, NULL
    // 0x9bdda4: b.eq            #0x9bddc4
    // 0x9bdda8: LoadField: r4 = r2->field_17
    //     0x9bdda8: ldur            w4, [x2, #0x17]
    // 0x9bddac: DecompressPointer r4
    //     0x9bddac: add             x4, x4, HEAP, lsl #32
    // 0x9bddb0: r8 = X0
    //     0x9bddb0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x9bddb4: LoadField: r9 = r4->field_7
    //     0x9bddb4: ldur            x9, [x4, #7]
    // 0x9bddb8: r3 = Null
    //     0x9bddb8: add             x3, PP, #0x56, lsl #12  ; [pp+0x56d40] Null
    //     0x9bddbc: ldr             x3, [x3, #0xd40]
    // 0x9bddc0: blr             x9
    // 0x9bddc4: ldur            x0, [fp, #-0x30]
    // 0x9bddc8: r1 = LoadClassIdInstr(r0)
    //     0x9bddc8: ldur            x1, [x0, #-1]
    //     0x9bddcc: ubfx            x1, x1, #0xc, #0x14
    // 0x9bddd0: ldr             x16, [fp, #0x10]
    // 0x9bddd4: stp             x16, x0, [SP, #-0x10]!
    // 0x9bddd8: mov             x0, x1
    // 0x9bdddc: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bdddc: mov             x17, #0xaf1f
    //     0x9bdde0: add             lr, x0, x17
    //     0x9bdde4: ldr             lr, [x21, lr, lsl #3]
    //     0x9bdde8: blr             lr
    // 0x9bddec: add             SP, SP, #0x10
    // 0x9bddf0: ldur            x4, [fp, #-0x28]
    // 0x9bddf4: ldur            x1, [fp, #-0x20]
    // 0x9bddf8: ldur            x2, [fp, #-0x18]
    // 0x9bddfc: ldur            x3, [fp, #-0x10]
    // 0x9bde00: b               #0x9bdcd8
    // 0x9bde04: ldur            x0, [fp, #-0x20]
    // 0x9bde08: r0 = ConcurrentModificationError()
    //     0x9bde08: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x9bde0c: ldur            x3, [fp, #-0x20]
    // 0x9bde10: StoreField: r0->field_b = r3
    //     0x9bde10: stur            w3, [x0, #0xb]
    // 0x9bde14: r0 = Throw()
    //     0x9bde14: bl              #0xd67e38  ; ThrowStub
    // 0x9bde18: brk             #0
    // 0x9bde1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bde1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bde20: b               #0x9bdc58
    // 0x9bde24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bde24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bde28: b               #0x9bdce8
  }
  _ detach(/* No info */) {
    // ** addr: 0xa69884, size: 0x1b0
    // 0xa69884: EnterFrame
    //     0xa69884: stp             fp, lr, [SP, #-0x10]!
    //     0xa69888: mov             fp, SP
    // 0xa6988c: AllocStack(0x30)
    //     0xa6988c: sub             SP, SP, #0x30
    // 0xa69890: CheckStackOverflow
    //     0xa69890: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69894: cmp             SP, x16
    //     0xa69898: b.ls            #0xa69a24
    // 0xa6989c: ldr             x16, [fp, #0x10]
    // 0xa698a0: SaveReg r16
    //     0xa698a0: str             x16, [SP, #-8]!
    // 0xa698a4: r0 = detach()
    //     0xa698a4: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa698a8: add             SP, SP, #8
    // 0xa698ac: ldr             x16, [fp, #0x10]
    // 0xa698b0: SaveReg r16
    //     0xa698b0: str             x16, [SP, #-8]!
    // 0xa698b4: r0 = children()
    //     0xa698b4: bl              #0x629110  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::children
    // 0xa698b8: add             SP, SP, #8
    // 0xa698bc: mov             x1, x0
    // 0xa698c0: stur            x1, [fp, #-0x20]
    // 0xa698c4: LoadField: r2 = r1->field_7
    //     0xa698c4: ldur            w2, [x1, #7]
    // 0xa698c8: DecompressPointer r2
    //     0xa698c8: add             x2, x2, HEAP, lsl #32
    // 0xa698cc: stur            x2, [fp, #-0x18]
    // 0xa698d0: LoadField: r0 = r1->field_b
    //     0xa698d0: ldur            w0, [x1, #0xb]
    // 0xa698d4: DecompressPointer r0
    //     0xa698d4: add             x0, x0, HEAP, lsl #32
    // 0xa698d8: r3 = LoadInt32Instr(r0)
    //     0xa698d8: sbfx            x3, x0, #1, #0x1f
    // 0xa698dc: stur            x3, [fp, #-0x10]
    // 0xa698e0: r4 = 0
    //     0xa698e0: mov             x4, #0
    // 0xa698e4: stur            x4, [fp, #-8]
    // 0xa698e8: CheckStackOverflow
    //     0xa698e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa698ec: cmp             SP, x16
    //     0xa698f0: b.ls            #0xa69a2c
    // 0xa698f4: r0 = LoadClassIdInstr(r1)
    //     0xa698f4: ldur            x0, [x1, #-1]
    //     0xa698f8: ubfx            x0, x0, #0xc, #0x14
    // 0xa698fc: SaveReg r1
    //     0xa698fc: str             x1, [SP, #-8]!
    // 0xa69900: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa69900: mov             x17, #0xb8ea
    //     0xa69904: add             lr, x0, x17
    //     0xa69908: ldr             lr, [x21, lr, lsl #3]
    //     0xa6990c: blr             lr
    // 0xa69910: add             SP, SP, #8
    // 0xa69914: r1 = LoadInt32Instr(r0)
    //     0xa69914: sbfx            x1, x0, #1, #0x1f
    //     0xa69918: tbz             w0, #0, #0xa69920
    //     0xa6991c: ldur            x1, [x0, #7]
    // 0xa69920: ldur            x2, [fp, #-0x10]
    // 0xa69924: cmp             x2, x1
    // 0xa69928: b.ne            #0xa69a0c
    // 0xa6992c: ldur            x3, [fp, #-0x20]
    // 0xa69930: ldur            x4, [fp, #-8]
    // 0xa69934: cmp             x4, x1
    // 0xa69938: b.lt            #0xa6994c
    // 0xa6993c: r0 = Null
    //     0xa6993c: mov             x0, NULL
    // 0xa69940: LeaveFrame
    //     0xa69940: mov             SP, fp
    //     0xa69944: ldp             fp, lr, [SP], #0x10
    // 0xa69948: ret
    //     0xa69948: ret             
    // 0xa6994c: r0 = BoxInt64Instr(r4)
    //     0xa6994c: sbfiz           x0, x4, #1, #0x1f
    //     0xa69950: cmp             x4, x0, asr #1
    //     0xa69954: b.eq            #0xa69960
    //     0xa69958: bl              #0xd69bb8
    //     0xa6995c: stur            x4, [x0, #7]
    // 0xa69960: r1 = LoadClassIdInstr(r3)
    //     0xa69960: ldur            x1, [x3, #-1]
    //     0xa69964: ubfx            x1, x1, #0xc, #0x14
    // 0xa69968: stp             x0, x3, [SP, #-0x10]!
    // 0xa6996c: mov             x0, x1
    // 0xa69970: r0 = GDT[cid_x0 + 0xd175]()
    //     0xa69970: mov             x17, #0xd175
    //     0xa69974: add             lr, x0, x17
    //     0xa69978: ldr             lr, [x21, lr, lsl #3]
    //     0xa6997c: blr             lr
    // 0xa69980: add             SP, SP, #0x10
    // 0xa69984: mov             x3, x0
    // 0xa69988: ldur            x0, [fp, #-8]
    // 0xa6998c: stur            x3, [fp, #-0x30]
    // 0xa69990: add             x4, x0, #1
    // 0xa69994: stur            x4, [fp, #-0x28]
    // 0xa69998: cmp             w3, NULL
    // 0xa6999c: b.ne            #0xa699d0
    // 0xa699a0: mov             x0, x3
    // 0xa699a4: ldur            x2, [fp, #-0x18]
    // 0xa699a8: r1 = Null
    //     0xa699a8: mov             x1, NULL
    // 0xa699ac: cmp             w2, NULL
    // 0xa699b0: b.eq            #0xa699d0
    // 0xa699b4: LoadField: r4 = r2->field_17
    //     0xa699b4: ldur            w4, [x2, #0x17]
    // 0xa699b8: DecompressPointer r4
    //     0xa699b8: add             x4, x4, HEAP, lsl #32
    // 0xa699bc: r8 = X0
    //     0xa699bc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa699c0: LoadField: r9 = r4->field_7
    //     0xa699c0: ldur            x9, [x4, #7]
    // 0xa699c4: r3 = Null
    //     0xa699c4: add             x3, PP, #0x56, lsl #12  ; [pp+0x56d20] Null
    //     0xa699c8: ldr             x3, [x3, #0xd20]
    // 0xa699cc: blr             x9
    // 0xa699d0: ldur            x0, [fp, #-0x30]
    // 0xa699d4: r1 = LoadClassIdInstr(r0)
    //     0xa699d4: ldur            x1, [x0, #-1]
    //     0xa699d8: ubfx            x1, x1, #0xc, #0x14
    // 0xa699dc: SaveReg r0
    //     0xa699dc: str             x0, [SP, #-8]!
    // 0xa699e0: mov             x0, x1
    // 0xa699e4: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa699e4: mov             x17, #0xa3cc
    //     0xa699e8: add             lr, x0, x17
    //     0xa699ec: ldr             lr, [x21, lr, lsl #3]
    //     0xa699f0: blr             lr
    // 0xa699f4: add             SP, SP, #8
    // 0xa699f8: ldur            x4, [fp, #-0x28]
    // 0xa699fc: ldur            x1, [fp, #-0x20]
    // 0xa69a00: ldur            x2, [fp, #-0x18]
    // 0xa69a04: ldur            x3, [fp, #-0x10]
    // 0xa69a08: b               #0xa698e4
    // 0xa69a0c: ldur            x0, [fp, #-0x20]
    // 0xa69a10: r0 = ConcurrentModificationError()
    //     0xa69a10: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xa69a14: ldur            x3, [fp, #-0x20]
    // 0xa69a18: StoreField: r0->field_b = r3
    //     0xa69a18: stur            w3, [x0, #0xb]
    // 0xa69a1c: r0 = Throw()
    //     0xa69a1c: bl              #0xd67e38  ; ThrowStub
    // 0xa69a20: brk             #0
    // 0xa69a24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69a24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69a28: b               #0xa6989c
    // 0xa69a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69a30: b               #0xa698f4
  }
  _ _moveChild(/* No info */) {
    // ** addr: 0xcefb1c, size: 0x150
    // 0xcefb1c: EnterFrame
    //     0xcefb1c: stp             fp, lr, [SP, #-0x10]!
    //     0xcefb20: mov             fp, SP
    // 0xcefb24: AllocStack(0x8)
    //     0xcefb24: sub             SP, SP, #8
    // 0xcefb28: CheckStackOverflow
    //     0xcefb28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcefb2c: cmp             SP, x16
    //     0xcefb30: b.ls            #0xcefc64
    // 0xcefb34: ldr             x0, [fp, #0x18]
    // 0xcefb38: r2 = Null
    //     0xcefb38: mov             x2, NULL
    // 0xcefb3c: r1 = Null
    //     0xcefb3c: mov             x1, NULL
    // 0xcefb40: r4 = 59
    //     0xcefb40: mov             x4, #0x3b
    // 0xcefb44: branchIfSmi(r0, 0xcefb50)
    //     0xcefb44: tbz             w0, #0, #0xcefb50
    // 0xcefb48: r4 = LoadClassIdInstr(r0)
    //     0xcefb48: ldur            x4, [x0, #-1]
    //     0xcefb4c: ubfx            x4, x4, #0xc, #0x14
    // 0xcefb50: r17 = 5959
    //     0xcefb50: mov             x17, #0x1747
    // 0xcefb54: cmp             x4, x17
    // 0xcefb58: b.eq            #0xcefb70
    // 0xcefb5c: r8 = _ListTileSlot
    //     0xcefb5c: add             x8, PP, #0x56, lsl #12  ; [pp+0x564a8] Type: _ListTileSlot
    //     0xcefb60: ldr             x8, [x8, #0x4a8]
    // 0xcefb64: r3 = Null
    //     0xcefb64: add             x3, PP, #0x56, lsl #12  ; [pp+0x56cd0] Null
    //     0xcefb68: ldr             x3, [x3, #0xcd0]
    // 0xcefb6c: r0 = _ListTileSlot()
    //     0xcefb6c: bl              #0x6290ec  ; IsType__ListTileSlot_Stub
    // 0xcefb70: ldr             x0, [fp, #0x10]
    // 0xcefb74: r2 = Null
    //     0xcefb74: mov             x2, NULL
    // 0xcefb78: r1 = Null
    //     0xcefb78: mov             x1, NULL
    // 0xcefb7c: r4 = 59
    //     0xcefb7c: mov             x4, #0x3b
    // 0xcefb80: branchIfSmi(r0, 0xcefb8c)
    //     0xcefb80: tbz             w0, #0, #0xcefb8c
    // 0xcefb84: r4 = LoadClassIdInstr(r0)
    //     0xcefb84: ldur            x4, [x0, #-1]
    //     0xcefb88: ubfx            x4, x4, #0xc, #0x14
    // 0xcefb8c: r17 = 5959
    //     0xcefb8c: mov             x17, #0x1747
    // 0xcefb90: cmp             x4, x17
    // 0xcefb94: b.eq            #0xcefbac
    // 0xcefb98: r8 = _ListTileSlot
    //     0xcefb98: add             x8, PP, #0x56, lsl #12  ; [pp+0x564a8] Type: _ListTileSlot
    //     0xcefb9c: ldr             x8, [x8, #0x4a8]
    // 0xcefba0: r3 = Null
    //     0xcefba0: add             x3, PP, #0x56, lsl #12  ; [pp+0x56ce0] Null
    //     0xcefba4: ldr             x3, [x3, #0xce0]
    // 0xcefba8: r0 = _ListTileSlot()
    //     0xcefba8: bl              #0x6290ec  ; IsType__ListTileSlot_Stub
    // 0xcefbac: ldr             x0, [fp, #0x28]
    // 0xcefbb0: LoadField: r1 = r0->field_5f
    //     0xcefbb0: ldur            w1, [x0, #0x5f]
    // 0xcefbb4: DecompressPointer r1
    //     0xcefbb4: add             x1, x1, HEAP, lsl #32
    // 0xcefbb8: stur            x1, [fp, #-8]
    // 0xcefbbc: ldr             x16, [fp, #0x10]
    // 0xcefbc0: stp             x16, x1, [SP, #-0x10]!
    // 0xcefbc4: r0 = _getValueOrData()
    //     0xcefbc4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcefbc8: add             SP, SP, #0x10
    // 0xcefbcc: mov             x1, x0
    // 0xcefbd0: ldur            x0, [fp, #-8]
    // 0xcefbd4: LoadField: r2 = r0->field_f
    //     0xcefbd4: ldur            w2, [x0, #0xf]
    // 0xcefbd8: DecompressPointer r2
    //     0xcefbd8: add             x2, x2, HEAP, lsl #32
    // 0xcefbdc: cmp             w2, w1
    // 0xcefbe0: b.ne            #0xcefbec
    // 0xcefbe4: r0 = Null
    //     0xcefbe4: mov             x0, NULL
    // 0xcefbe8: b               #0xcefbf0
    // 0xcefbec: mov             x0, x1
    // 0xcefbf0: r1 = 59
    //     0xcefbf0: mov             x1, #0x3b
    // 0xcefbf4: branchIfSmi(r0, 0xcefc00)
    //     0xcefbf4: tbz             w0, #0, #0xcefc00
    // 0xcefbf8: r1 = LoadClassIdInstr(r0)
    //     0xcefbf8: ldur            x1, [x0, #-1]
    //     0xcefbfc: ubfx            x1, x1, #0xc, #0x14
    // 0xcefc00: ldr             x16, [fp, #0x20]
    // 0xcefc04: stp             x16, x0, [SP, #-0x10]!
    // 0xcefc08: mov             x0, x1
    // 0xcefc0c: mov             lr, x0
    // 0xcefc10: ldr             lr, [x21, lr, lsl #3]
    // 0xcefc14: blr             lr
    // 0xcefc18: add             SP, SP, #0x10
    // 0xcefc1c: tbnz            w0, #4, #0xcefc38
    // 0xcefc20: ldr             x16, [fp, #0x28]
    // 0xcefc24: stp             NULL, x16, [SP, #-0x10]!
    // 0xcefc28: ldr             x16, [fp, #0x10]
    // 0xcefc2c: SaveReg r16
    //     0xcefc2c: str             x16, [SP, #-8]!
    // 0xcefc30: r0 = _setChild()
    //     0xcefc30: bl              #0xcf1728  ; [package:flutter/src/material/list_tile.dart] __RenderListTile&RenderBox&SlottedContainerRenderObjectMixin::_setChild
    // 0xcefc34: add             SP, SP, #0x18
    // 0xcefc38: ldr             x16, [fp, #0x28]
    // 0xcefc3c: ldr             lr, [fp, #0x20]
    // 0xcefc40: stp             lr, x16, [SP, #-0x10]!
    // 0xcefc44: ldr             x16, [fp, #0x18]
    // 0xcefc48: SaveReg r16
    //     0xcefc48: str             x16, [SP, #-8]!
    // 0xcefc4c: r0 = _setChild()
    //     0xcefc4c: bl              #0xcf1728  ; [package:flutter/src/material/list_tile.dart] __RenderListTile&RenderBox&SlottedContainerRenderObjectMixin::_setChild
    // 0xcefc50: add             SP, SP, #0x18
    // 0xcefc54: r0 = Null
    //     0xcefc54: mov             x0, NULL
    // 0xcefc58: LeaveFrame
    //     0xcefc58: mov             SP, fp
    //     0xcefc5c: ldp             fp, lr, [SP], #0x10
    // 0xcefc60: ret
    //     0xcefc60: ret             
    // 0xcefc64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcefc64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcefc68: b               #0xcefb34
  }
  const get _ _slotToChild(/* No info */) {
    // ** addr: 0xcf0b04, size: 0x10
    // 0xcf0b04: ldr             x1, [SP]
    // 0xcf0b08: LoadField: r0 = r1->field_5f
    //     0xcf0b08: ldur            w0, [x1, #0x5f]
    // 0xcf0b0c: DecompressPointer r0
    //     0xcf0b0c: add             x0, x0, HEAP, lsl #32
    // 0xcf0b10: ret
    //     0xcf0b10: ret             
  }
  _ _setChild(/* No info */) {
    // ** addr: 0xcf1728, size: 0x10c
    // 0xcf1728: EnterFrame
    //     0xcf1728: stp             fp, lr, [SP, #-0x10]!
    //     0xcf172c: mov             fp, SP
    // 0xcf1730: AllocStack(0x8)
    //     0xcf1730: sub             SP, SP, #8
    // 0xcf1734: CheckStackOverflow
    //     0xcf1734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf1738: cmp             SP, x16
    //     0xcf173c: b.ls            #0xcf182c
    // 0xcf1740: ldr             x0, [fp, #0x10]
    // 0xcf1744: r2 = Null
    //     0xcf1744: mov             x2, NULL
    // 0xcf1748: r1 = Null
    //     0xcf1748: mov             x1, NULL
    // 0xcf174c: r4 = 59
    //     0xcf174c: mov             x4, #0x3b
    // 0xcf1750: branchIfSmi(r0, 0xcf175c)
    //     0xcf1750: tbz             w0, #0, #0xcf175c
    // 0xcf1754: r4 = LoadClassIdInstr(r0)
    //     0xcf1754: ldur            x4, [x0, #-1]
    //     0xcf1758: ubfx            x4, x4, #0xc, #0x14
    // 0xcf175c: r17 = 5959
    //     0xcf175c: mov             x17, #0x1747
    // 0xcf1760: cmp             x4, x17
    // 0xcf1764: b.eq            #0xcf177c
    // 0xcf1768: r8 = _ListTileSlot
    //     0xcf1768: add             x8, PP, #0x56, lsl #12  ; [pp+0x564a8] Type: _ListTileSlot
    //     0xcf176c: ldr             x8, [x8, #0x4a8]
    // 0xcf1770: r3 = Null
    //     0xcf1770: add             x3, PP, #0x56, lsl #12  ; [pp+0x56cf0] Null
    //     0xcf1774: ldr             x3, [x3, #0xcf0]
    // 0xcf1778: r0 = _ListTileSlot()
    //     0xcf1778: bl              #0x6290ec  ; IsType__ListTileSlot_Stub
    // 0xcf177c: ldr             x0, [fp, #0x20]
    // 0xcf1780: LoadField: r1 = r0->field_5f
    //     0xcf1780: ldur            w1, [x0, #0x5f]
    // 0xcf1784: DecompressPointer r1
    //     0xcf1784: add             x1, x1, HEAP, lsl #32
    // 0xcf1788: stur            x1, [fp, #-8]
    // 0xcf178c: ldr             x16, [fp, #0x10]
    // 0xcf1790: stp             x16, x1, [SP, #-0x10]!
    // 0xcf1794: r0 = _getValueOrData()
    //     0xcf1794: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xcf1798: add             SP, SP, #0x10
    // 0xcf179c: mov             x1, x0
    // 0xcf17a0: ldur            x0, [fp, #-8]
    // 0xcf17a4: LoadField: r2 = r0->field_f
    //     0xcf17a4: ldur            w2, [x0, #0xf]
    // 0xcf17a8: DecompressPointer r2
    //     0xcf17a8: add             x2, x2, HEAP, lsl #32
    // 0xcf17ac: cmp             w2, w1
    // 0xcf17b0: b.ne            #0xcf17b8
    // 0xcf17b4: r1 = Null
    //     0xcf17b4: mov             x1, NULL
    // 0xcf17b8: cmp             w1, NULL
    // 0xcf17bc: b.eq            #0xcf17e4
    // 0xcf17c0: ldr             x16, [fp, #0x20]
    // 0xcf17c4: stp             x1, x16, [SP, #-0x10]!
    // 0xcf17c8: r0 = dropChild()
    //     0xcf17c8: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0xcf17cc: add             SP, SP, #0x10
    // 0xcf17d0: ldur            x16, [fp, #-8]
    // 0xcf17d4: ldr             lr, [fp, #0x10]
    // 0xcf17d8: stp             lr, x16, [SP, #-0x10]!
    // 0xcf17dc: r0 = remove()
    //     0xcf17dc: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xcf17e0: add             SP, SP, #0x10
    // 0xcf17e4: ldr             x0, [fp, #0x18]
    // 0xcf17e8: cmp             w0, NULL
    // 0xcf17ec: b.eq            #0xcf181c
    // 0xcf17f0: ldur            x16, [fp, #-8]
    // 0xcf17f4: ldr             lr, [fp, #0x10]
    // 0xcf17f8: stp             lr, x16, [SP, #-0x10]!
    // 0xcf17fc: SaveReg r0
    //     0xcf17fc: str             x0, [SP, #-8]!
    // 0xcf1800: r0 = []=()
    //     0xcf1800: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xcf1804: add             SP, SP, #0x18
    // 0xcf1808: ldr             x16, [fp, #0x20]
    // 0xcf180c: ldr             lr, [fp, #0x18]
    // 0xcf1810: stp             lr, x16, [SP, #-0x10]!
    // 0xcf1814: r0 = adoptChild()
    //     0xcf1814: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0xcf1818: add             SP, SP, #0x10
    // 0xcf181c: r0 = Null
    //     0xcf181c: mov             x0, NULL
    // 0xcf1820: LeaveFrame
    //     0xcf1820: mov             SP, fp
    //     0xcf1824: ldp             fp, lr, [SP], #0x10
    // 0xcf1828: ret
    //     0xcf1828: ret             
    // 0xcf182c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf182c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1830: b               #0xcf1740
  }
}

// class id: 2445, size: 0x94, field offset: 0x64
class _RenderListTile extends __RenderListTile&RenderBox&SlottedContainerRenderObjectMixin {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x628e80, size: 0x26c
    // 0x628e80: EnterFrame
    //     0x628e80: stp             fp, lr, [SP, #-0x10]!
    //     0x628e84: mov             fp, SP
    // 0x628e88: AllocStack(0x40)
    //     0x628e88: sub             SP, SP, #0x40
    // 0x628e8c: CheckStackOverflow
    //     0x628e8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x628e90: cmp             SP, x16
    //     0x628e94: b.ls            #0x6290d8
    // 0x628e98: ldr             x16, [fp, #0x20]
    // 0x628e9c: SaveReg r16
    //     0x628e9c: str             x16, [SP, #-8]!
    // 0x628ea0: r0 = children()
    //     0x628ea0: bl              #0x629110  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::children
    // 0x628ea4: add             SP, SP, #8
    // 0x628ea8: mov             x1, x0
    // 0x628eac: stur            x1, [fp, #-0x20]
    // 0x628eb0: LoadField: r2 = r1->field_7
    //     0x628eb0: ldur            w2, [x1, #7]
    // 0x628eb4: DecompressPointer r2
    //     0x628eb4: add             x2, x2, HEAP, lsl #32
    // 0x628eb8: stur            x2, [fp, #-0x18]
    // 0x628ebc: LoadField: r0 = r1->field_b
    //     0x628ebc: ldur            w0, [x1, #0xb]
    // 0x628ec0: DecompressPointer r0
    //     0x628ec0: add             x0, x0, HEAP, lsl #32
    // 0x628ec4: r3 = LoadInt32Instr(r0)
    //     0x628ec4: sbfx            x3, x0, #1, #0x1f
    // 0x628ec8: stur            x3, [fp, #-0x10]
    // 0x628ecc: r4 = 0
    //     0x628ecc: mov             x4, #0
    // 0x628ed0: stur            x4, [fp, #-8]
    // 0x628ed4: CheckStackOverflow
    //     0x628ed4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x628ed8: cmp             SP, x16
    //     0x628edc: b.ls            #0x6290e0
    // 0x628ee0: r0 = LoadClassIdInstr(r1)
    //     0x628ee0: ldur            x0, [x1, #-1]
    //     0x628ee4: ubfx            x0, x0, #0xc, #0x14
    // 0x628ee8: SaveReg r1
    //     0x628ee8: str             x1, [SP, #-8]!
    // 0x628eec: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x628eec: mov             x17, #0xb8ea
    //     0x628ef0: add             lr, x0, x17
    //     0x628ef4: ldr             lr, [x21, lr, lsl #3]
    //     0x628ef8: blr             lr
    // 0x628efc: add             SP, SP, #8
    // 0x628f00: r1 = LoadInt32Instr(r0)
    //     0x628f00: sbfx            x1, x0, #1, #0x1f
    //     0x628f04: tbz             w0, #0, #0x628f0c
    //     0x628f08: ldur            x1, [x0, #7]
    // 0x628f0c: ldur            x2, [fp, #-0x10]
    // 0x628f10: cmp             x2, x1
    // 0x628f14: b.ne            #0x6290c0
    // 0x628f18: ldur            x3, [fp, #-0x20]
    // 0x628f1c: ldur            x4, [fp, #-8]
    // 0x628f20: cmp             x4, x1
    // 0x628f24: b.lt            #0x628f38
    // 0x628f28: r0 = false
    //     0x628f28: add             x0, NULL, #0x30  ; false
    // 0x628f2c: LeaveFrame
    //     0x628f2c: mov             SP, fp
    //     0x628f30: ldp             fp, lr, [SP], #0x10
    // 0x628f34: ret
    //     0x628f34: ret             
    // 0x628f38: r0 = BoxInt64Instr(r4)
    //     0x628f38: sbfiz           x0, x4, #1, #0x1f
    //     0x628f3c: cmp             x4, x0, asr #1
    //     0x628f40: b.eq            #0x628f4c
    //     0x628f44: bl              #0xd69bb8
    //     0x628f48: stur            x4, [x0, #7]
    // 0x628f4c: r1 = LoadClassIdInstr(r3)
    //     0x628f4c: ldur            x1, [x3, #-1]
    //     0x628f50: ubfx            x1, x1, #0xc, #0x14
    // 0x628f54: stp             x0, x3, [SP, #-0x10]!
    // 0x628f58: mov             x0, x1
    // 0x628f5c: r0 = GDT[cid_x0 + 0xd175]()
    //     0x628f5c: mov             x17, #0xd175
    //     0x628f60: add             lr, x0, x17
    //     0x628f64: ldr             lr, [x21, lr, lsl #3]
    //     0x628f68: blr             lr
    // 0x628f6c: add             SP, SP, #0x10
    // 0x628f70: mov             x3, x0
    // 0x628f74: ldur            x0, [fp, #-8]
    // 0x628f78: stur            x3, [fp, #-0x30]
    // 0x628f7c: add             x4, x0, #1
    // 0x628f80: stur            x4, [fp, #-0x28]
    // 0x628f84: cmp             w3, NULL
    // 0x628f88: b.ne            #0x628fbc
    // 0x628f8c: mov             x0, x3
    // 0x628f90: ldur            x2, [fp, #-0x18]
    // 0x628f94: r1 = Null
    //     0x628f94: mov             x1, NULL
    // 0x628f98: cmp             w2, NULL
    // 0x628f9c: b.eq            #0x628fbc
    // 0x628fa0: LoadField: r4 = r2->field_17
    //     0x628fa0: ldur            w4, [x2, #0x17]
    // 0x628fa4: DecompressPointer r4
    //     0x628fa4: add             x4, x4, HEAP, lsl #32
    // 0x628fa8: r8 = X0
    //     0x628fa8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x628fac: LoadField: r9 = r4->field_7
    //     0x628fac: ldur            x9, [x4, #7]
    // 0x628fb0: r3 = Null
    //     0x628fb0: add             x3, PP, #0x56, lsl #12  ; [pp+0x56d70] Null
    //     0x628fb4: ldr             x3, [x3, #0xd70]
    // 0x628fb8: blr             x9
    // 0x628fbc: ldur            x3, [fp, #-0x30]
    // 0x628fc0: LoadField: r4 = r3->field_17
    //     0x628fc0: ldur            w4, [x3, #0x17]
    // 0x628fc4: DecompressPointer r4
    //     0x628fc4: add             x4, x4, HEAP, lsl #32
    // 0x628fc8: stur            x4, [fp, #-0x38]
    // 0x628fcc: cmp             w4, NULL
    // 0x628fd0: b.eq            #0x6290e8
    // 0x628fd4: mov             x0, x4
    // 0x628fd8: r2 = Null
    //     0x628fd8: mov             x2, NULL
    // 0x628fdc: r1 = Null
    //     0x628fdc: mov             x1, NULL
    // 0x628fe0: r4 = LoadClassIdInstr(r0)
    //     0x628fe0: ldur            x4, [x0, #-1]
    //     0x628fe4: ubfx            x4, x4, #0xc, #0x14
    // 0x628fe8: sub             x4, x4, #0x7ff
    // 0x628fec: cmp             x4, #0xb
    // 0x628ff0: b.ls            #0x629008
    // 0x628ff4: r8 = BoxParentData
    //     0x628ff4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x628ff8: ldr             x8, [x8, #0x1b0]
    // 0x628ffc: r3 = Null
    //     0x628ffc: add             x3, PP, #0x56, lsl #12  ; [pp+0x56d80] Null
    //     0x629000: ldr             x3, [x3, #0xd80]
    // 0x629004: r0 = DefaultTypeTest()
    //     0x629004: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x629008: ldur            x0, [fp, #-0x38]
    // 0x62900c: LoadField: r1 = r0->field_7
    //     0x62900c: ldur            w1, [x0, #7]
    // 0x629010: DecompressPointer r1
    //     0x629010: add             x1, x1, HEAP, lsl #32
    // 0x629014: stur            x1, [fp, #-0x40]
    // 0x629018: ldr             x16, [fp, #0x10]
    // 0x62901c: stp             x1, x16, [SP, #-0x10]!
    // 0x629020: r0 = -()
    //     0x629020: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x629024: add             SP, SP, #0x10
    // 0x629028: stur            x0, [fp, #-0x38]
    // 0x62902c: ldur            x16, [fp, #-0x40]
    // 0x629030: SaveReg r16
    //     0x629030: str             x16, [SP, #-8]!
    // 0x629034: r0 = unary-()
    //     0x629034: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x629038: add             SP, SP, #8
    // 0x62903c: ldr             x16, [fp, #0x18]
    // 0x629040: stp             x0, x16, [SP, #-0x10]!
    // 0x629044: r0 = pushOffset()
    //     0x629044: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x629048: add             SP, SP, #0x10
    // 0x62904c: ldur            x0, [fp, #-0x30]
    // 0x629050: r1 = LoadClassIdInstr(r0)
    //     0x629050: ldur            x1, [x0, #-1]
    //     0x629054: ubfx            x1, x1, #0xc, #0x14
    // 0x629058: ldr             x16, [fp, #0x18]
    // 0x62905c: stp             x16, x0, [SP, #-0x10]!
    // 0x629060: ldur            x16, [fp, #-0x38]
    // 0x629064: SaveReg r16
    //     0x629064: str             x16, [SP, #-8]!
    // 0x629068: mov             x0, x1
    // 0x62906c: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x62906c: mov             x17, #0xefa2
    //     0x629070: add             lr, x0, x17
    //     0x629074: ldr             lr, [x21, lr, lsl #3]
    //     0x629078: blr             lr
    // 0x62907c: add             SP, SP, #0x18
    // 0x629080: stur            x0, [fp, #-0x30]
    // 0x629084: ldr             x16, [fp, #0x18]
    // 0x629088: SaveReg r16
    //     0x629088: str             x16, [SP, #-8]!
    // 0x62908c: r0 = popTransform()
    //     0x62908c: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x629090: add             SP, SP, #8
    // 0x629094: ldur            x1, [fp, #-0x30]
    // 0x629098: tbnz            w1, #4, #0x6290ac
    // 0x62909c: r0 = true
    //     0x62909c: add             x0, NULL, #0x20  ; true
    // 0x6290a0: LeaveFrame
    //     0x6290a0: mov             SP, fp
    //     0x6290a4: ldp             fp, lr, [SP], #0x10
    // 0x6290a8: ret
    //     0x6290a8: ret             
    // 0x6290ac: ldur            x4, [fp, #-0x28]
    // 0x6290b0: ldur            x1, [fp, #-0x20]
    // 0x6290b4: ldur            x2, [fp, #-0x18]
    // 0x6290b8: ldur            x3, [fp, #-0x10]
    // 0x6290bc: b               #0x628ed0
    // 0x6290c0: ldur            x0, [fp, #-0x20]
    // 0x6290c4: r0 = ConcurrentModificationError()
    //     0x6290c4: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x6290c8: ldur            x3, [fp, #-0x20]
    // 0x6290cc: StoreField: r0->field_b = r3
    //     0x6290cc: stur            w3, [x0, #0xb]
    // 0x6290d0: r0 = Throw()
    //     0x6290d0: bl              #0xd67e38  ; ThrowStub
    // 0x6290d4: brk             #0
    // 0x6290d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6290d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6290dc: b               #0x628e98
    // 0x6290e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6290e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6290e4: b               #0x628ee0
    // 0x6290e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6290e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ children(/* No info */) {
    // ** addr: 0x629110, size: 0x3b4
    // 0x629110: EnterFrame
    //     0x629110: stp             fp, lr, [SP, #-0x10]!
    //     0x629114: mov             fp, SP
    // 0x629118: AllocStack(0x18)
    //     0x629118: sub             SP, SP, #0x18
    // 0x62911c: CheckStackOverflow
    //     0x62911c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629120: cmp             SP, x16
    //     0x629124: b.ls            #0x62949c
    // 0x629128: r16 = <RenderBox>
    //     0x629128: ldr             x16, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x62912c: stp             xzr, x16, [SP, #-0x10]!
    // 0x629130: r0 = _GrowableList()
    //     0x629130: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x629134: add             SP, SP, #0x10
    // 0x629138: stur            x0, [fp, #-8]
    // 0x62913c: ldr             x16, [fp, #0x10]
    // 0x629140: r30 = Instance__ListTileSlot
    //     0x629140: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x629144: ldr             lr, [lr, #0xd00]
    // 0x629148: stp             lr, x16, [SP, #-0x10]!
    // 0x62914c: r0 = childForSlot()
    //     0x62914c: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x629150: add             SP, SP, #0x10
    // 0x629154: cmp             w0, NULL
    // 0x629158: b.eq            #0x62920c
    // 0x62915c: ldur            x0, [fp, #-8]
    // 0x629160: ldr             x16, [fp, #0x10]
    // 0x629164: SaveReg r16
    //     0x629164: str             x16, [SP, #-8]!
    // 0x629168: r0 = leading()
    //     0x629168: bl              #0x629584  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::leading
    // 0x62916c: add             SP, SP, #8
    // 0x629170: stur            x0, [fp, #-0x18]
    // 0x629174: cmp             w0, NULL
    // 0x629178: b.eq            #0x6294a4
    // 0x62917c: ldur            x1, [fp, #-8]
    // 0x629180: LoadField: r2 = r1->field_b
    //     0x629180: ldur            w2, [x1, #0xb]
    // 0x629184: DecompressPointer r2
    //     0x629184: add             x2, x2, HEAP, lsl #32
    // 0x629188: stur            x2, [fp, #-0x10]
    // 0x62918c: LoadField: r3 = r1->field_f
    //     0x62918c: ldur            w3, [x1, #0xf]
    // 0x629190: DecompressPointer r3
    //     0x629190: add             x3, x3, HEAP, lsl #32
    // 0x629194: LoadField: r4 = r3->field_b
    //     0x629194: ldur            w4, [x3, #0xb]
    // 0x629198: DecompressPointer r4
    //     0x629198: add             x4, x4, HEAP, lsl #32
    // 0x62919c: cmp             w2, w4
    // 0x6291a0: b.ne            #0x6291b0
    // 0x6291a4: SaveReg r1
    //     0x6291a4: str             x1, [SP, #-8]!
    // 0x6291a8: r0 = _growToNextCapacity()
    //     0x6291a8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6291ac: add             SP, SP, #8
    // 0x6291b0: ldur            x2, [fp, #-8]
    // 0x6291b4: ldur            x0, [fp, #-0x10]
    // 0x6291b8: r3 = LoadInt32Instr(r0)
    //     0x6291b8: sbfx            x3, x0, #1, #0x1f
    // 0x6291bc: add             x0, x3, #1
    // 0x6291c0: lsl             x1, x0, #1
    // 0x6291c4: StoreField: r2->field_b = r1
    //     0x6291c4: stur            w1, [x2, #0xb]
    // 0x6291c8: mov             x1, x3
    // 0x6291cc: cmp             x1, x0
    // 0x6291d0: b.hs            #0x6294a8
    // 0x6291d4: LoadField: r1 = r2->field_f
    //     0x6291d4: ldur            w1, [x2, #0xf]
    // 0x6291d8: DecompressPointer r1
    //     0x6291d8: add             x1, x1, HEAP, lsl #32
    // 0x6291dc: ldur            x0, [fp, #-0x18]
    // 0x6291e0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6291e0: add             x25, x1, x3, lsl #2
    //     0x6291e4: add             x25, x25, #0xf
    //     0x6291e8: str             w0, [x25]
    //     0x6291ec: tbz             w0, #0, #0x629208
    //     0x6291f0: ldurb           w16, [x1, #-1]
    //     0x6291f4: ldurb           w17, [x0, #-1]
    //     0x6291f8: and             x16, x17, x16, lsr #2
    //     0x6291fc: tst             x16, HEAP, lsr #32
    //     0x629200: b.eq            #0x629208
    //     0x629204: bl              #0xd67e5c
    // 0x629208: b               #0x629210
    // 0x62920c: ldur            x2, [fp, #-8]
    // 0x629210: ldr             x16, [fp, #0x10]
    // 0x629214: r30 = Instance__ListTileSlot
    //     0x629214: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x629218: ldr             lr, [lr, #0xd08]
    // 0x62921c: stp             lr, x16, [SP, #-0x10]!
    // 0x629220: r0 = childForSlot()
    //     0x629220: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x629224: add             SP, SP, #0x10
    // 0x629228: cmp             w0, NULL
    // 0x62922c: b.eq            #0x6292e0
    // 0x629230: ldur            x0, [fp, #-8]
    // 0x629234: ldr             x16, [fp, #0x10]
    // 0x629238: SaveReg r16
    //     0x629238: str             x16, [SP, #-8]!
    // 0x62923c: r0 = title()
    //     0x62923c: bl              #0x629544  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::title
    // 0x629240: add             SP, SP, #8
    // 0x629244: stur            x0, [fp, #-0x18]
    // 0x629248: cmp             w0, NULL
    // 0x62924c: b.eq            #0x6294ac
    // 0x629250: ldur            x1, [fp, #-8]
    // 0x629254: LoadField: r2 = r1->field_b
    //     0x629254: ldur            w2, [x1, #0xb]
    // 0x629258: DecompressPointer r2
    //     0x629258: add             x2, x2, HEAP, lsl #32
    // 0x62925c: stur            x2, [fp, #-0x10]
    // 0x629260: LoadField: r3 = r1->field_f
    //     0x629260: ldur            w3, [x1, #0xf]
    // 0x629264: DecompressPointer r3
    //     0x629264: add             x3, x3, HEAP, lsl #32
    // 0x629268: LoadField: r4 = r3->field_b
    //     0x629268: ldur            w4, [x3, #0xb]
    // 0x62926c: DecompressPointer r4
    //     0x62926c: add             x4, x4, HEAP, lsl #32
    // 0x629270: cmp             w2, w4
    // 0x629274: b.ne            #0x629284
    // 0x629278: SaveReg r1
    //     0x629278: str             x1, [SP, #-8]!
    // 0x62927c: r0 = _growToNextCapacity()
    //     0x62927c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x629280: add             SP, SP, #8
    // 0x629284: ldur            x2, [fp, #-8]
    // 0x629288: ldur            x0, [fp, #-0x10]
    // 0x62928c: r3 = LoadInt32Instr(r0)
    //     0x62928c: sbfx            x3, x0, #1, #0x1f
    // 0x629290: add             x0, x3, #1
    // 0x629294: lsl             x1, x0, #1
    // 0x629298: StoreField: r2->field_b = r1
    //     0x629298: stur            w1, [x2, #0xb]
    // 0x62929c: mov             x1, x3
    // 0x6292a0: cmp             x1, x0
    // 0x6292a4: b.hs            #0x6294b0
    // 0x6292a8: LoadField: r1 = r2->field_f
    //     0x6292a8: ldur            w1, [x2, #0xf]
    // 0x6292ac: DecompressPointer r1
    //     0x6292ac: add             x1, x1, HEAP, lsl #32
    // 0x6292b0: ldur            x0, [fp, #-0x18]
    // 0x6292b4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6292b4: add             x25, x1, x3, lsl #2
    //     0x6292b8: add             x25, x25, #0xf
    //     0x6292bc: str             w0, [x25]
    //     0x6292c0: tbz             w0, #0, #0x6292dc
    //     0x6292c4: ldurb           w16, [x1, #-1]
    //     0x6292c8: ldurb           w17, [x0, #-1]
    //     0x6292cc: and             x16, x17, x16, lsr #2
    //     0x6292d0: tst             x16, HEAP, lsr #32
    //     0x6292d4: b.eq            #0x6292dc
    //     0x6292d8: bl              #0xd67e5c
    // 0x6292dc: b               #0x6292e4
    // 0x6292e0: ldur            x2, [fp, #-8]
    // 0x6292e4: ldr             x16, [fp, #0x10]
    // 0x6292e8: r30 = Instance__ListTileSlot
    //     0x6292e8: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x6292ec: ldr             lr, [lr, #0xd10]
    // 0x6292f0: stp             lr, x16, [SP, #-0x10]!
    // 0x6292f4: r0 = childForSlot()
    //     0x6292f4: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x6292f8: add             SP, SP, #0x10
    // 0x6292fc: cmp             w0, NULL
    // 0x629300: b.eq            #0x6293b4
    // 0x629304: ldur            x0, [fp, #-8]
    // 0x629308: ldr             x16, [fp, #0x10]
    // 0x62930c: SaveReg r16
    //     0x62930c: str             x16, [SP, #-8]!
    // 0x629310: r0 = subtitle()
    //     0x629310: bl              #0x629504  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::subtitle
    // 0x629314: add             SP, SP, #8
    // 0x629318: stur            x0, [fp, #-0x18]
    // 0x62931c: cmp             w0, NULL
    // 0x629320: b.eq            #0x6294b4
    // 0x629324: ldur            x1, [fp, #-8]
    // 0x629328: LoadField: r2 = r1->field_b
    //     0x629328: ldur            w2, [x1, #0xb]
    // 0x62932c: DecompressPointer r2
    //     0x62932c: add             x2, x2, HEAP, lsl #32
    // 0x629330: stur            x2, [fp, #-0x10]
    // 0x629334: LoadField: r3 = r1->field_f
    //     0x629334: ldur            w3, [x1, #0xf]
    // 0x629338: DecompressPointer r3
    //     0x629338: add             x3, x3, HEAP, lsl #32
    // 0x62933c: LoadField: r4 = r3->field_b
    //     0x62933c: ldur            w4, [x3, #0xb]
    // 0x629340: DecompressPointer r4
    //     0x629340: add             x4, x4, HEAP, lsl #32
    // 0x629344: cmp             w2, w4
    // 0x629348: b.ne            #0x629358
    // 0x62934c: SaveReg r1
    //     0x62934c: str             x1, [SP, #-8]!
    // 0x629350: r0 = _growToNextCapacity()
    //     0x629350: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x629354: add             SP, SP, #8
    // 0x629358: ldur            x2, [fp, #-8]
    // 0x62935c: ldur            x0, [fp, #-0x10]
    // 0x629360: r3 = LoadInt32Instr(r0)
    //     0x629360: sbfx            x3, x0, #1, #0x1f
    // 0x629364: add             x0, x3, #1
    // 0x629368: lsl             x1, x0, #1
    // 0x62936c: StoreField: r2->field_b = r1
    //     0x62936c: stur            w1, [x2, #0xb]
    // 0x629370: mov             x1, x3
    // 0x629374: cmp             x1, x0
    // 0x629378: b.hs            #0x6294b8
    // 0x62937c: LoadField: r1 = r2->field_f
    //     0x62937c: ldur            w1, [x2, #0xf]
    // 0x629380: DecompressPointer r1
    //     0x629380: add             x1, x1, HEAP, lsl #32
    // 0x629384: ldur            x0, [fp, #-0x18]
    // 0x629388: ArrayStore: r1[r3] = r0  ; List_4
    //     0x629388: add             x25, x1, x3, lsl #2
    //     0x62938c: add             x25, x25, #0xf
    //     0x629390: str             w0, [x25]
    //     0x629394: tbz             w0, #0, #0x6293b0
    //     0x629398: ldurb           w16, [x1, #-1]
    //     0x62939c: ldurb           w17, [x0, #-1]
    //     0x6293a0: and             x16, x17, x16, lsr #2
    //     0x6293a4: tst             x16, HEAP, lsr #32
    //     0x6293a8: b.eq            #0x6293b0
    //     0x6293ac: bl              #0xd67e5c
    // 0x6293b0: b               #0x6293b8
    // 0x6293b4: ldur            x2, [fp, #-8]
    // 0x6293b8: ldr             x16, [fp, #0x10]
    // 0x6293bc: r30 = Instance__ListTileSlot
    //     0x6293bc: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x6293c0: ldr             lr, [lr, #0xd18]
    // 0x6293c4: stp             lr, x16, [SP, #-0x10]!
    // 0x6293c8: r0 = childForSlot()
    //     0x6293c8: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x6293cc: add             SP, SP, #0x10
    // 0x6293d0: cmp             w0, NULL
    // 0x6293d4: b.eq            #0x629488
    // 0x6293d8: ldur            x0, [fp, #-8]
    // 0x6293dc: ldr             x16, [fp, #0x10]
    // 0x6293e0: SaveReg r16
    //     0x6293e0: str             x16, [SP, #-8]!
    // 0x6293e4: r0 = trailing()
    //     0x6293e4: bl              #0x6294c4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::trailing
    // 0x6293e8: add             SP, SP, #8
    // 0x6293ec: stur            x0, [fp, #-0x18]
    // 0x6293f0: cmp             w0, NULL
    // 0x6293f4: b.eq            #0x6294bc
    // 0x6293f8: ldur            x1, [fp, #-8]
    // 0x6293fc: LoadField: r2 = r1->field_b
    //     0x6293fc: ldur            w2, [x1, #0xb]
    // 0x629400: DecompressPointer r2
    //     0x629400: add             x2, x2, HEAP, lsl #32
    // 0x629404: stur            x2, [fp, #-0x10]
    // 0x629408: LoadField: r3 = r1->field_f
    //     0x629408: ldur            w3, [x1, #0xf]
    // 0x62940c: DecompressPointer r3
    //     0x62940c: add             x3, x3, HEAP, lsl #32
    // 0x629410: LoadField: r4 = r3->field_b
    //     0x629410: ldur            w4, [x3, #0xb]
    // 0x629414: DecompressPointer r4
    //     0x629414: add             x4, x4, HEAP, lsl #32
    // 0x629418: cmp             w2, w4
    // 0x62941c: b.ne            #0x62942c
    // 0x629420: SaveReg r1
    //     0x629420: str             x1, [SP, #-8]!
    // 0x629424: r0 = _growToNextCapacity()
    //     0x629424: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x629428: add             SP, SP, #8
    // 0x62942c: ldur            x2, [fp, #-8]
    // 0x629430: ldur            x3, [fp, #-0x10]
    // 0x629434: r4 = LoadInt32Instr(r3)
    //     0x629434: sbfx            x4, x3, #1, #0x1f
    // 0x629438: add             x0, x4, #1
    // 0x62943c: lsl             x3, x0, #1
    // 0x629440: StoreField: r2->field_b = r3
    //     0x629440: stur            w3, [x2, #0xb]
    // 0x629444: mov             x1, x4
    // 0x629448: cmp             x1, x0
    // 0x62944c: b.hs            #0x6294c0
    // 0x629450: LoadField: r1 = r2->field_f
    //     0x629450: ldur            w1, [x2, #0xf]
    // 0x629454: DecompressPointer r1
    //     0x629454: add             x1, x1, HEAP, lsl #32
    // 0x629458: ldur            x0, [fp, #-0x18]
    // 0x62945c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x62945c: add             x25, x1, x4, lsl #2
    //     0x629460: add             x25, x25, #0xf
    //     0x629464: str             w0, [x25]
    //     0x629468: tbz             w0, #0, #0x629484
    //     0x62946c: ldurb           w16, [x1, #-1]
    //     0x629470: ldurb           w17, [x0, #-1]
    //     0x629474: and             x16, x17, x16, lsr #2
    //     0x629478: tst             x16, HEAP, lsr #32
    //     0x62947c: b.eq            #0x629484
    //     0x629480: bl              #0xd67e5c
    // 0x629484: b               #0x62948c
    // 0x629488: ldur            x2, [fp, #-8]
    // 0x62948c: mov             x0, x2
    // 0x629490: LeaveFrame
    //     0x629490: mov             SP, fp
    //     0x629494: ldp             fp, lr, [SP], #0x10
    // 0x629498: ret
    //     0x629498: ret             
    // 0x62949c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62949c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6294a0: b               #0x629128
    // 0x6294a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6294a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6294a8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6294a8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6294ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6294ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6294b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6294b0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6294b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6294b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6294b8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6294b8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6294bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6294bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6294c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6294c0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ trailing(/* No info */) {
    // ** addr: 0x6294c4, size: 0x40
    // 0x6294c4: EnterFrame
    //     0x6294c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6294c8: mov             fp, SP
    // 0x6294cc: CheckStackOverflow
    //     0x6294cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6294d0: cmp             SP, x16
    //     0x6294d4: b.ls            #0x6294fc
    // 0x6294d8: ldr             x16, [fp, #0x10]
    // 0x6294dc: r30 = Instance__ListTileSlot
    //     0x6294dc: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x6294e0: ldr             lr, [lr, #0xd18]
    // 0x6294e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6294e8: r0 = childForSlot()
    //     0x6294e8: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x6294ec: add             SP, SP, #0x10
    // 0x6294f0: LeaveFrame
    //     0x6294f0: mov             SP, fp
    //     0x6294f4: ldp             fp, lr, [SP], #0x10
    // 0x6294f8: ret
    //     0x6294f8: ret             
    // 0x6294fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6294fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x629500: b               #0x6294d8
  }
  get _ subtitle(/* No info */) {
    // ** addr: 0x629504, size: 0x40
    // 0x629504: EnterFrame
    //     0x629504: stp             fp, lr, [SP, #-0x10]!
    //     0x629508: mov             fp, SP
    // 0x62950c: CheckStackOverflow
    //     0x62950c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629510: cmp             SP, x16
    //     0x629514: b.ls            #0x62953c
    // 0x629518: ldr             x16, [fp, #0x10]
    // 0x62951c: r30 = Instance__ListTileSlot
    //     0x62951c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x629520: ldr             lr, [lr, #0xd10]
    // 0x629524: stp             lr, x16, [SP, #-0x10]!
    // 0x629528: r0 = childForSlot()
    //     0x629528: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x62952c: add             SP, SP, #0x10
    // 0x629530: LeaveFrame
    //     0x629530: mov             SP, fp
    //     0x629534: ldp             fp, lr, [SP], #0x10
    // 0x629538: ret
    //     0x629538: ret             
    // 0x62953c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62953c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x629540: b               #0x629518
  }
  get _ title(/* No info */) {
    // ** addr: 0x629544, size: 0x40
    // 0x629544: EnterFrame
    //     0x629544: stp             fp, lr, [SP, #-0x10]!
    //     0x629548: mov             fp, SP
    // 0x62954c: CheckStackOverflow
    //     0x62954c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629550: cmp             SP, x16
    //     0x629554: b.ls            #0x62957c
    // 0x629558: ldr             x16, [fp, #0x10]
    // 0x62955c: r30 = Instance__ListTileSlot
    //     0x62955c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x629560: ldr             lr, [lr, #0xd08]
    // 0x629564: stp             lr, x16, [SP, #-0x10]!
    // 0x629568: r0 = childForSlot()
    //     0x629568: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x62956c: add             SP, SP, #0x10
    // 0x629570: LeaveFrame
    //     0x629570: mov             SP, fp
    //     0x629574: ldp             fp, lr, [SP], #0x10
    // 0x629578: ret
    //     0x629578: ret             
    // 0x62957c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62957c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x629580: b               #0x629558
  }
  get _ leading(/* No info */) {
    // ** addr: 0x629584, size: 0x40
    // 0x629584: EnterFrame
    //     0x629584: stp             fp, lr, [SP, #-0x10]!
    //     0x629588: mov             fp, SP
    // 0x62958c: CheckStackOverflow
    //     0x62958c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x629590: cmp             SP, x16
    //     0x629594: b.ls            #0x6295bc
    // 0x629598: ldr             x16, [fp, #0x10]
    // 0x62959c: r30 = Instance__ListTileSlot
    //     0x62959c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x6295a0: ldr             lr, [lr, #0xd00]
    // 0x6295a4: stp             lr, x16, [SP, #-0x10]!
    // 0x6295a8: r0 = childForSlot()
    //     0x6295a8: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x6295ac: add             SP, SP, #0x10
    // 0x6295b0: LeaveFrame
    //     0x6295b0: mov             SP, fp
    //     0x6295b4: ldp             fp, lr, [SP], #0x10
    // 0x6295b8: ret
    //     0x6295b8: ret             
    // 0x6295bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6295bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6295c0: b               #0x629598
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x630bd8, size: 0x18
    // 0x630bd8: r4 = 0
    //     0x630bd8: mov             x4, #0
    // 0x630bdc: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x630bdc: add             x17, PP, #0x56, lsl #12  ; [pp+0x56d50] AnonymousClosure: (0x630bf0), of [package:flutter/src/material/list_tile.dart] _RenderListTile
    //     0x630be0: ldr             x1, [x17, #0xd50]
    // 0x630be4: r24 = BuildNonGenericMethodExtractorStub
    //     0x630be4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x630be8: LoadField: r0 = r24->field_17
    //     0x630be8: ldur            x0, [x24, #0x17]
    // 0x630bec: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x630bf0, size: 0x4c
    // 0x630bf0: EnterFrame
    //     0x630bf0: stp             fp, lr, [SP, #-0x10]!
    //     0x630bf4: mov             fp, SP
    // 0x630bf8: ldr             x0, [fp, #0x18]
    // 0x630bfc: LoadField: r1 = r0->field_17
    //     0x630bfc: ldur            w1, [x0, #0x17]
    // 0x630c00: DecompressPointer r1
    //     0x630c00: add             x1, x1, HEAP, lsl #32
    // 0x630c04: CheckStackOverflow
    //     0x630c04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630c08: cmp             SP, x16
    //     0x630c0c: b.ls            #0x630c34
    // 0x630c10: LoadField: r0 = r1->field_f
    //     0x630c10: ldur            w0, [x1, #0xf]
    // 0x630c14: DecompressPointer r0
    //     0x630c14: add             x0, x0, HEAP, lsl #32
    // 0x630c18: ldr             x16, [fp, #0x10]
    // 0x630c1c: stp             x16, x0, [SP, #-0x10]!
    // 0x630c20: r0 = computeMinIntrinsicHeight()
    //     0x630c20: bl              #0x630c3c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicHeight
    // 0x630c24: add             SP, SP, #0x10
    // 0x630c28: LeaveFrame
    //     0x630c28: mov             SP, fp
    //     0x630c2c: ldp             fp, lr, [SP], #0x10
    // 0x630c30: ret
    //     0x630c30: ret             
    // 0x630c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x630c34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x630c38: b               #0x630c10
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x630c3c, size: 0x1ac
    // 0x630c3c: EnterFrame
    //     0x630c3c: stp             fp, lr, [SP, #-0x10]!
    //     0x630c40: mov             fp, SP
    // 0x630c44: AllocStack(0x18)
    //     0x630c44: sub             SP, SP, #0x18
    // 0x630c48: CheckStackOverflow
    //     0x630c48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630c4c: cmp             SP, x16
    //     0x630c50: b.ls            #0x630db8
    // 0x630c54: ldr             x16, [fp, #0x18]
    // 0x630c58: SaveReg r16
    //     0x630c58: str             x16, [SP, #-8]!
    // 0x630c5c: r0 = _defaultTileHeight()
    //     0x630c5c: bl              #0x630e34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_defaultTileHeight
    // 0x630c60: add             SP, SP, #8
    // 0x630c64: stur            d0, [fp, #-8]
    // 0x630c68: ldr             x16, [fp, #0x18]
    // 0x630c6c: r30 = Instance__ListTileSlot
    //     0x630c6c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x630c70: ldr             lr, [lr, #0xd08]
    // 0x630c74: stp             lr, x16, [SP, #-0x10]!
    // 0x630c78: r0 = childForSlot()
    //     0x630c78: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x630c7c: add             SP, SP, #0x10
    // 0x630c80: cmp             w0, NULL
    // 0x630c84: b.eq            #0x630dc0
    // 0x630c88: ldr             x1, [fp, #0x10]
    // 0x630c8c: LoadField: d0 = r1->field_7
    //     0x630c8c: ldur            d0, [x1, #7]
    // 0x630c90: stur            d0, [fp, #-0x10]
    // 0x630c94: SaveReg r0
    //     0x630c94: str             x0, [SP, #-8]!
    // 0x630c98: SaveReg d0
    //     0x630c98: str             d0, [SP, #-8]!
    // 0x630c9c: r0 = getMinIntrinsicHeight()
    //     0x630c9c: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x630ca0: add             SP, SP, #0x10
    // 0x630ca4: stur            d0, [fp, #-0x18]
    // 0x630ca8: ldr             x16, [fp, #0x18]
    // 0x630cac: r30 = Instance__ListTileSlot
    //     0x630cac: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x630cb0: ldr             lr, [lr, #0xd10]
    // 0x630cb4: stp             lr, x16, [SP, #-0x10]!
    // 0x630cb8: r0 = childForSlot()
    //     0x630cb8: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x630cbc: add             SP, SP, #0x10
    // 0x630cc0: cmp             w0, NULL
    // 0x630cc4: b.ne            #0x630cd0
    // 0x630cc8: r1 = Null
    //     0x630cc8: mov             x1, NULL
    // 0x630ccc: b               #0x630d0c
    // 0x630cd0: ldur            d0, [fp, #-0x10]
    // 0x630cd4: SaveReg r0
    //     0x630cd4: str             x0, [SP, #-8]!
    // 0x630cd8: SaveReg d0
    //     0x630cd8: str             d0, [SP, #-8]!
    // 0x630cdc: r0 = getMinIntrinsicHeight()
    //     0x630cdc: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x630ce0: add             SP, SP, #0x10
    // 0x630ce4: r1 = inline_Allocate_Double()
    //     0x630ce4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x630ce8: add             x1, x1, #0x10
    //     0x630cec: cmp             x2, x1
    //     0x630cf0: b.ls            #0x630dc4
    //     0x630cf4: str             x1, [THR, #0x60]  ; THR::top
    //     0x630cf8: sub             x1, x1, #0xf
    //     0x630cfc: mov             x2, #0xd108
    //     0x630d00: movk            x2, #3, lsl #16
    //     0x630d04: stur            x2, [x1, #-1]
    // 0x630d08: StoreField: r1->field_7 = d0
    //     0x630d08: stur            d0, [x1, #7]
    // 0x630d0c: cmp             w1, NULL
    // 0x630d10: b.ne            #0x630d1c
    // 0x630d14: d2 = 0.000000
    //     0x630d14: eor             v2.16b, v2.16b, v2.16b
    // 0x630d18: b               #0x630d24
    // 0x630d1c: LoadField: d0 = r1->field_7
    //     0x630d1c: ldur            d0, [x1, #7]
    // 0x630d20: mov             v2.16b, v0.16b
    // 0x630d24: ldur            d1, [fp, #-8]
    // 0x630d28: ldur            d0, [fp, #-0x18]
    // 0x630d2c: fadd            d3, d0, d2
    // 0x630d30: fcmp            d1, d3
    // 0x630d34: b.vs            #0x630d44
    // 0x630d38: b.le            #0x630d44
    // 0x630d3c: mov             v0.16b, v1.16b
    // 0x630d40: b               #0x630d84
    // 0x630d44: fcmp            d1, d3
    // 0x630d48: b.vs            #0x630d58
    // 0x630d4c: b.ge            #0x630d58
    // 0x630d50: mov             v0.16b, v3.16b
    // 0x630d54: b               #0x630d84
    // 0x630d58: d0 = 0.000000
    //     0x630d58: eor             v0.16b, v0.16b, v0.16b
    // 0x630d5c: fcmp            d1, d0
    // 0x630d60: b.vs            #0x630d70
    // 0x630d64: b.ne            #0x630d70
    // 0x630d68: fadd            d0, d1, d3
    // 0x630d6c: b               #0x630d84
    // 0x630d70: fcmp            d3, d3
    // 0x630d74: b.vc            #0x630d80
    // 0x630d78: mov             v0.16b, v3.16b
    // 0x630d7c: b               #0x630d84
    // 0x630d80: mov             v0.16b, v1.16b
    // 0x630d84: r0 = inline_Allocate_Double()
    //     0x630d84: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x630d88: add             x0, x0, #0x10
    //     0x630d8c: cmp             x1, x0
    //     0x630d90: b.ls            #0x630dd8
    //     0x630d94: str             x0, [THR, #0x60]  ; THR::top
    //     0x630d98: sub             x0, x0, #0xf
    //     0x630d9c: mov             x1, #0xd108
    //     0x630da0: movk            x1, #3, lsl #16
    //     0x630da4: stur            x1, [x0, #-1]
    // 0x630da8: StoreField: r0->field_7 = d0
    //     0x630da8: stur            d0, [x0, #7]
    // 0x630dac: LeaveFrame
    //     0x630dac: mov             SP, fp
    //     0x630db0: ldp             fp, lr, [SP], #0x10
    // 0x630db4: ret
    //     0x630db4: ret             
    // 0x630db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x630db8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x630dbc: b               #0x630c54
    // 0x630dc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x630dc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x630dc4: SaveReg d0
    //     0x630dc4: str             q0, [SP, #-0x10]!
    // 0x630dc8: r0 = AllocateDouble()
    //     0x630dc8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x630dcc: mov             x1, x0
    // 0x630dd0: RestoreReg d0
    //     0x630dd0: ldr             q0, [SP], #0x10
    // 0x630dd4: b               #0x630d08
    // 0x630dd8: SaveReg d0
    //     0x630dd8: str             q0, [SP, #-0x10]!
    // 0x630ddc: r0 = AllocateDouble()
    //     0x630ddc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x630de0: RestoreReg d0
    //     0x630de0: ldr             q0, [SP], #0x10
    // 0x630de4: b               #0x630da8
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x630de8, size: 0x4c
    // 0x630de8: EnterFrame
    //     0x630de8: stp             fp, lr, [SP, #-0x10]!
    //     0x630dec: mov             fp, SP
    // 0x630df0: ldr             x0, [fp, #0x18]
    // 0x630df4: LoadField: r1 = r0->field_17
    //     0x630df4: ldur            w1, [x0, #0x17]
    // 0x630df8: DecompressPointer r1
    //     0x630df8: add             x1, x1, HEAP, lsl #32
    // 0x630dfc: CheckStackOverflow
    //     0x630dfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630e00: cmp             SP, x16
    //     0x630e04: b.ls            #0x630e2c
    // 0x630e08: LoadField: r0 = r1->field_f
    //     0x630e08: ldur            w0, [x1, #0xf]
    // 0x630e0c: DecompressPointer r0
    //     0x630e0c: add             x0, x0, HEAP, lsl #32
    // 0x630e10: ldr             x16, [fp, #0x10]
    // 0x630e14: stp             x16, x0, [SP, #-0x10]!
    // 0x630e18: r0 = computeMinIntrinsicHeight()
    //     0x630e18: bl              #0x630c3c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicHeight
    // 0x630e1c: add             SP, SP, #0x10
    // 0x630e20: LeaveFrame
    //     0x630e20: mov             SP, fp
    //     0x630e24: ldp             fp, lr, [SP], #0x10
    // 0x630e28: ret
    //     0x630e28: ret             
    // 0x630e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x630e2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x630e30: b               #0x630e08
  }
  get _ _defaultTileHeight(/* No info */) {
    // ** addr: 0x630e34, size: 0xd4
    // 0x630e34: EnterFrame
    //     0x630e34: stp             fp, lr, [SP, #-0x10]!
    //     0x630e38: mov             fp, SP
    // 0x630e3c: AllocStack(0x10)
    //     0x630e3c: sub             SP, SP, #0x10
    // 0x630e40: CheckStackOverflow
    //     0x630e40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630e44: cmp             SP, x16
    //     0x630e48: b.ls            #0x630f00
    // 0x630e4c: ldr             x16, [fp, #0x10]
    // 0x630e50: r30 = Instance__ListTileSlot
    //     0x630e50: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x630e54: ldr             lr, [lr, #0xd10]
    // 0x630e58: stp             lr, x16, [SP, #-0x10]!
    // 0x630e5c: r0 = childForSlot()
    //     0x630e5c: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x630e60: add             SP, SP, #0x10
    // 0x630e64: cmp             w0, NULL
    // 0x630e68: r16 = true
    //     0x630e68: add             x16, NULL, #0x20  ; true
    // 0x630e6c: r17 = false
    //     0x630e6c: add             x17, NULL, #0x30  ; false
    // 0x630e70: csel            x1, x16, x17, ne
    // 0x630e74: stur            x1, [fp, #-0x10]
    // 0x630e78: eor             x0, x1, #0x10
    // 0x630e7c: ldr             x2, [fp, #0x10]
    // 0x630e80: stur            x0, [fp, #-8]
    // 0x630e84: LoadField: r3 = r2->field_67
    //     0x630e84: ldur            w3, [x2, #0x67]
    // 0x630e88: DecompressPointer r3
    //     0x630e88: add             x3, x3, HEAP, lsl #32
    // 0x630e8c: SaveReg r3
    //     0x630e8c: str             x3, [SP, #-8]!
    // 0x630e90: r0 = baseSizeAdjustment()
    //     0x630e90: bl              #0x630630  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0x630e94: add             SP, SP, #8
    // 0x630e98: mov             x1, x0
    // 0x630e9c: ldur            x0, [fp, #-8]
    // 0x630ea0: tbnz            w0, #4, #0x630ec0
    // 0x630ea4: d1 = 56.000000
    //     0x630ea4: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x630ea8: ldr             d1, [x17, #0xe88]
    // 0x630eac: LoadField: d2 = r1->field_f
    //     0x630eac: ldur            d2, [x1, #0xf]
    // 0x630eb0: fadd            d0, d1, d2
    // 0x630eb4: LeaveFrame
    //     0x630eb4: mov             SP, fp
    //     0x630eb8: ldp             fp, lr, [SP], #0x10
    // 0x630ebc: ret
    //     0x630ebc: ret             
    // 0x630ec0: ldur            x0, [fp, #-0x10]
    // 0x630ec4: tbnz            w0, #4, #0x630ee4
    // 0x630ec8: d1 = 72.000000
    //     0x630ec8: add             x17, PP, #0x26, lsl #12  ; [pp+0x26db0] IMM: double(72) from 0x4052000000000000
    //     0x630ecc: ldr             d1, [x17, #0xdb0]
    // 0x630ed0: LoadField: d2 = r1->field_f
    //     0x630ed0: ldur            d2, [x1, #0xf]
    // 0x630ed4: fadd            d0, d1, d2
    // 0x630ed8: LeaveFrame
    //     0x630ed8: mov             SP, fp
    //     0x630edc: ldp             fp, lr, [SP], #0x10
    // 0x630ee0: ret
    //     0x630ee0: ret             
    // 0x630ee4: d1 = 88.000000
    //     0x630ee4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa0] IMM: double(88) from 0x4056000000000000
    //     0x630ee8: ldr             d1, [x17, #0xfa0]
    // 0x630eec: LoadField: d2 = r1->field_f
    //     0x630eec: ldur            d2, [x1, #0xf]
    // 0x630ef0: fadd            d0, d1, d2
    // 0x630ef4: LeaveFrame
    //     0x630ef4: mov             SP, fp
    //     0x630ef8: ldp             fp, lr, [SP], #0x10
    // 0x630efc: ret
    //     0x630efc: ret             
    // 0x630f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x630f00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x630f04: b               #0x630e4c
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x636810, size: 0x18
    // 0x636810: r4 = 0
    //     0x636810: mov             x4, #0
    // 0x636814: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x636814: add             x17, PP, #0x56, lsl #12  ; [pp+0x56d60] AnonymousClosure: (0x636828), in [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMaxIntrinsicWidth (0x636874)
    //     0x636818: ldr             x1, [x17, #0xd60]
    // 0x63681c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63681c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x636820: LoadField: r0 = r24->field_17
    //     0x636820: ldur            x0, [x24, #0x17]
    // 0x636824: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x636828, size: 0x4c
    // 0x636828: EnterFrame
    //     0x636828: stp             fp, lr, [SP, #-0x10]!
    //     0x63682c: mov             fp, SP
    // 0x636830: ldr             x0, [fp, #0x18]
    // 0x636834: LoadField: r1 = r0->field_17
    //     0x636834: ldur            w1, [x0, #0x17]
    // 0x636838: DecompressPointer r1
    //     0x636838: add             x1, x1, HEAP, lsl #32
    // 0x63683c: CheckStackOverflow
    //     0x63683c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636840: cmp             SP, x16
    //     0x636844: b.ls            #0x63686c
    // 0x636848: LoadField: r0 = r1->field_f
    //     0x636848: ldur            w0, [x1, #0xf]
    // 0x63684c: DecompressPointer r0
    //     0x63684c: add             x0, x0, HEAP, lsl #32
    // 0x636850: ldr             x16, [fp, #0x10]
    // 0x636854: stp             x16, x0, [SP, #-0x10]!
    // 0x636858: r0 = computeMaxIntrinsicWidth()
    //     0x636858: bl              #0x636874  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMaxIntrinsicWidth
    // 0x63685c: add             SP, SP, #0x10
    // 0x636860: LeaveFrame
    //     0x636860: mov             SP, fp
    //     0x636864: ldp             fp, lr, [SP], #0x10
    // 0x636868: ret
    //     0x636868: ret             
    // 0x63686c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63686c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636870: b               #0x636848
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x636874, size: 0x25c
    // 0x636874: EnterFrame
    //     0x636874: stp             fp, lr, [SP, #-0x10]!
    //     0x636878: mov             fp, SP
    // 0x63687c: AllocStack(0x18)
    //     0x63687c: sub             SP, SP, #0x18
    // 0x636880: CheckStackOverflow
    //     0x636880: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636884: cmp             SP, x16
    //     0x636888: b.ls            #0x636ab4
    // 0x63688c: ldr             x16, [fp, #0x18]
    // 0x636890: r30 = Instance__ListTileSlot
    //     0x636890: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x636894: ldr             lr, [lr, #0xd00]
    // 0x636898: stp             lr, x16, [SP, #-0x10]!
    // 0x63689c: r0 = childForSlot()
    //     0x63689c: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x6368a0: add             SP, SP, #0x10
    // 0x6368a4: cmp             w0, NULL
    // 0x6368a8: b.eq            #0x636968
    // 0x6368ac: ldr             x1, [fp, #0x18]
    // 0x6368b0: ldr             x0, [fp, #0x10]
    // 0x6368b4: r16 = Instance__ListTileSlot
    //     0x6368b4: add             x16, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x6368b8: ldr             x16, [x16, #0xd00]
    // 0x6368bc: stp             x16, x1, [SP, #-0x10]!
    // 0x6368c0: r0 = childForSlot()
    //     0x6368c0: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x6368c4: add             SP, SP, #0x10
    // 0x6368c8: cmp             w0, NULL
    // 0x6368cc: b.eq            #0x636abc
    // 0x6368d0: ldr             x1, [fp, #0x10]
    // 0x6368d4: LoadField: d0 = r1->field_7
    //     0x6368d4: ldur            d0, [x1, #7]
    // 0x6368d8: SaveReg r0
    //     0x6368d8: str             x0, [SP, #-8]!
    // 0x6368dc: SaveReg d0
    //     0x6368dc: str             d0, [SP, #-8]!
    // 0x6368e0: r0 = getMaxIntrinsicWidth()
    //     0x6368e0: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x6368e4: add             SP, SP, #0x10
    // 0x6368e8: ldr             x0, [fp, #0x18]
    // 0x6368ec: LoadField: d1 = r0->field_8b
    //     0x6368ec: ldur            d1, [x0, #0x8b]
    // 0x6368f0: fcmp            d0, d1
    // 0x6368f4: b.vs            #0x636904
    // 0x6368f8: b.le            #0x636904
    // 0x6368fc: d2 = 0.000000
    //     0x6368fc: eor             v2.16b, v2.16b, v2.16b
    // 0x636900: b               #0x636944
    // 0x636904: fcmp            d0, d1
    // 0x636908: b.vs            #0x63691c
    // 0x63690c: b.ge            #0x63691c
    // 0x636910: mov             v0.16b, v1.16b
    // 0x636914: d2 = 0.000000
    //     0x636914: eor             v2.16b, v2.16b, v2.16b
    // 0x636918: b               #0x636944
    // 0x63691c: d2 = 0.000000
    //     0x63691c: eor             v2.16b, v2.16b, v2.16b
    // 0x636920: fcmp            d0, d2
    // 0x636924: b.vs            #0x636938
    // 0x636928: b.ne            #0x636938
    // 0x63692c: fadd            d3, d0, d1
    // 0x636930: mov             v0.16b, v3.16b
    // 0x636934: b               #0x636944
    // 0x636938: fcmp            d1, d1
    // 0x63693c: b.vc            #0x636944
    // 0x636940: mov             v0.16b, v1.16b
    // 0x636944: stur            d0, [fp, #-8]
    // 0x636948: SaveReg r0
    //     0x636948: str             x0, [SP, #-8]!
    // 0x63694c: r0 = _effectiveHorizontalTitleGap()
    //     0x63694c: bl              #0x636ad0  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_effectiveHorizontalTitleGap
    // 0x636950: add             SP, SP, #8
    // 0x636954: mov             v1.16b, v0.16b
    // 0x636958: ldur            d0, [fp, #-8]
    // 0x63695c: fadd            d2, d0, d1
    // 0x636960: mov             v0.16b, v2.16b
    // 0x636964: b               #0x63696c
    // 0x636968: d0 = 0.000000
    //     0x636968: eor             v0.16b, v0.16b, v0.16b
    // 0x63696c: ldr             x0, [fp, #0x10]
    // 0x636970: stur            d0, [fp, #-8]
    // 0x636974: ldr             x16, [fp, #0x18]
    // 0x636978: r30 = Instance__ListTileSlot
    //     0x636978: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x63697c: ldr             lr, [lr, #0xd08]
    // 0x636980: stp             lr, x16, [SP, #-0x10]!
    // 0x636984: r0 = childForSlot()
    //     0x636984: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x636988: add             SP, SP, #0x10
    // 0x63698c: mov             x1, x0
    // 0x636990: ldr             x0, [fp, #0x10]
    // 0x636994: LoadField: d0 = r0->field_7
    //     0x636994: ldur            d0, [x0, #7]
    // 0x636998: stur            d0, [fp, #-0x10]
    // 0x63699c: SaveReg r1
    //     0x63699c: str             x1, [SP, #-8]!
    // 0x6369a0: SaveReg d0
    //     0x6369a0: str             d0, [SP, #-8]!
    // 0x6369a4: r0 = _maxWidth()
    //     0x6369a4: bl              #0x6367c0  ; [package:flutter/src/material/input_decorator.dart] _RenderDecoration::_maxWidth
    // 0x6369a8: add             SP, SP, #0x10
    // 0x6369ac: stur            d0, [fp, #-0x18]
    // 0x6369b0: ldr             x16, [fp, #0x18]
    // 0x6369b4: r30 = Instance__ListTileSlot
    //     0x6369b4: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x6369b8: ldr             lr, [lr, #0xd10]
    // 0x6369bc: stp             lr, x16, [SP, #-0x10]!
    // 0x6369c0: r0 = childForSlot()
    //     0x6369c0: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x6369c4: add             SP, SP, #0x10
    // 0x6369c8: SaveReg r0
    //     0x6369c8: str             x0, [SP, #-8]!
    // 0x6369cc: ldur            d0, [fp, #-0x10]
    // 0x6369d0: SaveReg d0
    //     0x6369d0: str             d0, [SP, #-8]!
    // 0x6369d4: r0 = _maxWidth()
    //     0x6369d4: bl              #0x6367c0  ; [package:flutter/src/material/input_decorator.dart] _RenderDecoration::_maxWidth
    // 0x6369d8: add             SP, SP, #0x10
    // 0x6369dc: mov             v1.16b, v0.16b
    // 0x6369e0: ldur            d0, [fp, #-0x18]
    // 0x6369e4: fcmp            d0, d1
    // 0x6369e8: b.vs            #0x6369f8
    // 0x6369ec: b.le            #0x6369f8
    // 0x6369f0: mov             v2.16b, v0.16b
    // 0x6369f4: b               #0x636a38
    // 0x6369f8: fcmp            d0, d1
    // 0x6369fc: b.vs            #0x636a0c
    // 0x636a00: b.ge            #0x636a0c
    // 0x636a04: mov             v2.16b, v1.16b
    // 0x636a08: b               #0x636a38
    // 0x636a0c: d2 = 0.000000
    //     0x636a0c: eor             v2.16b, v2.16b, v2.16b
    // 0x636a10: fcmp            d0, d2
    // 0x636a14: b.vs            #0x636a24
    // 0x636a18: b.ne            #0x636a24
    // 0x636a1c: fadd            d2, d0, d1
    // 0x636a20: b               #0x636a38
    // 0x636a24: fcmp            d1, d1
    // 0x636a28: b.vc            #0x636a34
    // 0x636a2c: mov             v2.16b, v1.16b
    // 0x636a30: b               #0x636a38
    // 0x636a34: mov             v2.16b, v0.16b
    // 0x636a38: ldur            d1, [fp, #-8]
    // 0x636a3c: ldur            d0, [fp, #-0x10]
    // 0x636a40: fadd            d3, d1, d2
    // 0x636a44: stur            d3, [fp, #-0x18]
    // 0x636a48: ldr             x16, [fp, #0x18]
    // 0x636a4c: r30 = Instance__ListTileSlot
    //     0x636a4c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x636a50: ldr             lr, [lr, #0xd18]
    // 0x636a54: stp             lr, x16, [SP, #-0x10]!
    // 0x636a58: r0 = childForSlot()
    //     0x636a58: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x636a5c: add             SP, SP, #0x10
    // 0x636a60: SaveReg r0
    //     0x636a60: str             x0, [SP, #-8]!
    // 0x636a64: ldur            d0, [fp, #-0x10]
    // 0x636a68: SaveReg d0
    //     0x636a68: str             d0, [SP, #-8]!
    // 0x636a6c: r0 = _maxWidth()
    //     0x636a6c: bl              #0x6367c0  ; [package:flutter/src/material/input_decorator.dart] _RenderDecoration::_maxWidth
    // 0x636a70: add             SP, SP, #0x10
    // 0x636a74: mov             v1.16b, v0.16b
    // 0x636a78: ldur            d0, [fp, #-0x18]
    // 0x636a7c: fadd            d2, d0, d1
    // 0x636a80: r0 = inline_Allocate_Double()
    //     0x636a80: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x636a84: add             x0, x0, #0x10
    //     0x636a88: cmp             x1, x0
    //     0x636a8c: b.ls            #0x636ac0
    //     0x636a90: str             x0, [THR, #0x60]  ; THR::top
    //     0x636a94: sub             x0, x0, #0xf
    //     0x636a98: mov             x1, #0xd108
    //     0x636a9c: movk            x1, #3, lsl #16
    //     0x636aa0: stur            x1, [x0, #-1]
    // 0x636aa4: StoreField: r0->field_7 = d2
    //     0x636aa4: stur            d2, [x0, #7]
    // 0x636aa8: LeaveFrame
    //     0x636aa8: mov             SP, fp
    //     0x636aac: ldp             fp, lr, [SP], #0x10
    // 0x636ab0: ret
    //     0x636ab0: ret             
    // 0x636ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636ab4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636ab8: b               #0x63688c
    // 0x636abc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x636abc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x636ac0: SaveReg d2
    //     0x636ac0: str             q2, [SP, #-0x10]!
    // 0x636ac4: r0 = AllocateDouble()
    //     0x636ac4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x636ac8: RestoreReg d2
    //     0x636ac8: ldr             q2, [SP], #0x10
    // 0x636acc: b               #0x636aa4
  }
  get _ _effectiveHorizontalTitleGap(/* No info */) {
    // ** addr: 0x636ad0, size: 0x24
    // 0x636ad0: d1 = 2.000000
    //     0x636ad0: fmov            d1, #2.00000000
    // 0x636ad4: ldr             x0, [SP]
    // 0x636ad8: LoadField: d2 = r0->field_7b
    //     0x636ad8: ldur            d2, [x0, #0x7b]
    // 0x636adc: LoadField: r1 = r0->field_67
    //     0x636adc: ldur            w1, [x0, #0x67]
    // 0x636ae0: DecompressPointer r1
    //     0x636ae0: add             x1, x1, HEAP, lsl #32
    // 0x636ae4: LoadField: d3 = r1->field_7
    //     0x636ae4: ldur            d3, [x1, #7]
    // 0x636ae8: fmul            d4, d3, d1
    // 0x636aec: fadd            d0, d2, d4
    // 0x636af0: ret
    //     0x636af0: ret             
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x639580, size: 0x18
    // 0x639580: r4 = 0
    //     0x639580: mov             x4, #0
    // 0x639584: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x639584: add             x17, PP, #0x56, lsl #12  ; [pp+0x56d58] AnonymousClosure: (0x630de8), in [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicHeight (0x630c3c)
    //     0x639588: ldr             x1, [x17, #0xd58]
    // 0x63958c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63958c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x639590: LoadField: r0 = r24->field_17
    //     0x639590: ldur            x0, [x24, #0x17]
    // 0x639594: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63c500, size: 0x18
    // 0x63c500: r4 = 0
    //     0x63c500: mov             x4, #0
    // 0x63c504: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63c504: add             x17, PP, #0x56, lsl #12  ; [pp+0x56d68] AnonymousClosure: (0x63c518), in [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicWidth (0x63c564)
    //     0x63c508: ldr             x1, [x17, #0xd68]
    // 0x63c50c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63c50c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63c510: LoadField: r0 = r24->field_17
    //     0x63c510: ldur            x0, [x24, #0x17]
    // 0x63c514: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63c518, size: 0x4c
    // 0x63c518: EnterFrame
    //     0x63c518: stp             fp, lr, [SP, #-0x10]!
    //     0x63c51c: mov             fp, SP
    // 0x63c520: ldr             x0, [fp, #0x18]
    // 0x63c524: LoadField: r1 = r0->field_17
    //     0x63c524: ldur            w1, [x0, #0x17]
    // 0x63c528: DecompressPointer r1
    //     0x63c528: add             x1, x1, HEAP, lsl #32
    // 0x63c52c: CheckStackOverflow
    //     0x63c52c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63c530: cmp             SP, x16
    //     0x63c534: b.ls            #0x63c55c
    // 0x63c538: LoadField: r0 = r1->field_f
    //     0x63c538: ldur            w0, [x1, #0xf]
    // 0x63c53c: DecompressPointer r0
    //     0x63c53c: add             x0, x0, HEAP, lsl #32
    // 0x63c540: ldr             x16, [fp, #0x10]
    // 0x63c544: stp             x16, x0, [SP, #-0x10]!
    // 0x63c548: r0 = computeMinIntrinsicWidth()
    //     0x63c548: bl              #0x63c564  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::computeMinIntrinsicWidth
    // 0x63c54c: add             SP, SP, #0x10
    // 0x63c550: LeaveFrame
    //     0x63c550: mov             SP, fp
    //     0x63c554: ldp             fp, lr, [SP], #0x10
    // 0x63c558: ret
    //     0x63c558: ret             
    // 0x63c55c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63c55c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63c560: b               #0x63c538
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63c564, size: 0x264
    // 0x63c564: EnterFrame
    //     0x63c564: stp             fp, lr, [SP, #-0x10]!
    //     0x63c568: mov             fp, SP
    // 0x63c56c: AllocStack(0x18)
    //     0x63c56c: sub             SP, SP, #0x18
    // 0x63c570: CheckStackOverflow
    //     0x63c570: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63c574: cmp             SP, x16
    //     0x63c578: b.ls            #0x63c7ac
    // 0x63c57c: ldr             x16, [fp, #0x18]
    // 0x63c580: r30 = Instance__ListTileSlot
    //     0x63c580: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x63c584: ldr             lr, [lr, #0xd00]
    // 0x63c588: stp             lr, x16, [SP, #-0x10]!
    // 0x63c58c: r0 = childForSlot()
    //     0x63c58c: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x63c590: add             SP, SP, #0x10
    // 0x63c594: cmp             w0, NULL
    // 0x63c598: b.eq            #0x63c65c
    // 0x63c59c: ldr             x1, [fp, #0x18]
    // 0x63c5a0: ldr             x0, [fp, #0x10]
    // 0x63c5a4: r16 = Instance__ListTileSlot
    //     0x63c5a4: add             x16, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x63c5a8: ldr             x16, [x16, #0xd00]
    // 0x63c5ac: stp             x16, x1, [SP, #-0x10]!
    // 0x63c5b0: r0 = childForSlot()
    //     0x63c5b0: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x63c5b4: add             SP, SP, #0x10
    // 0x63c5b8: cmp             w0, NULL
    // 0x63c5bc: b.eq            #0x63c7b4
    // 0x63c5c0: ldr             x1, [fp, #0x10]
    // 0x63c5c4: LoadField: d0 = r1->field_7
    //     0x63c5c4: ldur            d0, [x1, #7]
    // 0x63c5c8: SaveReg r0
    //     0x63c5c8: str             x0, [SP, #-8]!
    // 0x63c5cc: SaveReg d0
    //     0x63c5cc: str             d0, [SP, #-8]!
    // 0x63c5d0: r0 = getMinIntrinsicWidth()
    //     0x63c5d0: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63c5d4: add             SP, SP, #0x10
    // 0x63c5d8: ldr             x0, [fp, #0x18]
    // 0x63c5dc: LoadField: d1 = r0->field_8b
    //     0x63c5dc: ldur            d1, [x0, #0x8b]
    // 0x63c5e0: fcmp            d0, d1
    // 0x63c5e4: b.vs            #0x63c5f8
    // 0x63c5e8: b.le            #0x63c5f8
    // 0x63c5ec: mov             v1.16b, v0.16b
    // 0x63c5f0: d2 = 0.000000
    //     0x63c5f0: eor             v2.16b, v2.16b, v2.16b
    // 0x63c5f4: b               #0x63c634
    // 0x63c5f8: fcmp            d0, d1
    // 0x63c5fc: b.vs            #0x63c60c
    // 0x63c600: b.ge            #0x63c60c
    // 0x63c604: d2 = 0.000000
    //     0x63c604: eor             v2.16b, v2.16b, v2.16b
    // 0x63c608: b               #0x63c634
    // 0x63c60c: d2 = 0.000000
    //     0x63c60c: eor             v2.16b, v2.16b, v2.16b
    // 0x63c610: fcmp            d0, d2
    // 0x63c614: b.vs            #0x63c628
    // 0x63c618: b.ne            #0x63c628
    // 0x63c61c: fadd            d3, d0, d1
    // 0x63c620: mov             v1.16b, v3.16b
    // 0x63c624: b               #0x63c634
    // 0x63c628: fcmp            d1, d1
    // 0x63c62c: b.vs            #0x63c634
    // 0x63c630: mov             v1.16b, v0.16b
    // 0x63c634: d0 = 2.000000
    //     0x63c634: fmov            d0, #2.00000000
    // 0x63c638: LoadField: d3 = r0->field_7b
    //     0x63c638: ldur            d3, [x0, #0x7b]
    // 0x63c63c: LoadField: r1 = r0->field_67
    //     0x63c63c: ldur            w1, [x0, #0x67]
    // 0x63c640: DecompressPointer r1
    //     0x63c640: add             x1, x1, HEAP, lsl #32
    // 0x63c644: LoadField: d4 = r1->field_7
    //     0x63c644: ldur            d4, [x1, #7]
    // 0x63c648: fmul            d5, d4, d0
    // 0x63c64c: fadd            d0, d3, d5
    // 0x63c650: fadd            d3, d1, d0
    // 0x63c654: mov             v0.16b, v3.16b
    // 0x63c658: b               #0x63c668
    // 0x63c65c: ldr             x0, [fp, #0x18]
    // 0x63c660: d2 = 0.000000
    //     0x63c660: eor             v2.16b, v2.16b, v2.16b
    // 0x63c664: d0 = 0.000000
    //     0x63c664: eor             v0.16b, v0.16b, v0.16b
    // 0x63c668: ldr             x1, [fp, #0x10]
    // 0x63c66c: stur            d0, [fp, #-8]
    // 0x63c670: r16 = Instance__ListTileSlot
    //     0x63c670: add             x16, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x63c674: ldr             x16, [x16, #0xd08]
    // 0x63c678: stp             x16, x0, [SP, #-0x10]!
    // 0x63c67c: r0 = childForSlot()
    //     0x63c67c: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x63c680: add             SP, SP, #0x10
    // 0x63c684: mov             x1, x0
    // 0x63c688: ldr             x0, [fp, #0x10]
    // 0x63c68c: LoadField: d0 = r0->field_7
    //     0x63c68c: ldur            d0, [x0, #7]
    // 0x63c690: stur            d0, [fp, #-0x10]
    // 0x63c694: SaveReg r1
    //     0x63c694: str             x1, [SP, #-8]!
    // 0x63c698: SaveReg d0
    //     0x63c698: str             d0, [SP, #-8]!
    // 0x63c69c: r0 = _minWidth()
    //     0x63c69c: bl              #0x630ac8  ; [package:flutter/src/material/input_decorator.dart] _RenderDecoration::_minWidth
    // 0x63c6a0: add             SP, SP, #0x10
    // 0x63c6a4: stur            d0, [fp, #-0x18]
    // 0x63c6a8: ldr             x16, [fp, #0x18]
    // 0x63c6ac: r30 = Instance__ListTileSlot
    //     0x63c6ac: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x63c6b0: ldr             lr, [lr, #0xd10]
    // 0x63c6b4: stp             lr, x16, [SP, #-0x10]!
    // 0x63c6b8: r0 = childForSlot()
    //     0x63c6b8: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x63c6bc: add             SP, SP, #0x10
    // 0x63c6c0: SaveReg r0
    //     0x63c6c0: str             x0, [SP, #-8]!
    // 0x63c6c4: ldur            d0, [fp, #-0x10]
    // 0x63c6c8: SaveReg d0
    //     0x63c6c8: str             d0, [SP, #-8]!
    // 0x63c6cc: r0 = _minWidth()
    //     0x63c6cc: bl              #0x630ac8  ; [package:flutter/src/material/input_decorator.dart] _RenderDecoration::_minWidth
    // 0x63c6d0: add             SP, SP, #0x10
    // 0x63c6d4: mov             v1.16b, v0.16b
    // 0x63c6d8: ldur            d0, [fp, #-0x18]
    // 0x63c6dc: fcmp            d0, d1
    // 0x63c6e0: b.vs            #0x63c6f0
    // 0x63c6e4: b.le            #0x63c6f0
    // 0x63c6e8: mov             v2.16b, v0.16b
    // 0x63c6ec: b               #0x63c730
    // 0x63c6f0: fcmp            d0, d1
    // 0x63c6f4: b.vs            #0x63c704
    // 0x63c6f8: b.ge            #0x63c704
    // 0x63c6fc: mov             v2.16b, v1.16b
    // 0x63c700: b               #0x63c730
    // 0x63c704: d2 = 0.000000
    //     0x63c704: eor             v2.16b, v2.16b, v2.16b
    // 0x63c708: fcmp            d0, d2
    // 0x63c70c: b.vs            #0x63c71c
    // 0x63c710: b.ne            #0x63c71c
    // 0x63c714: fadd            d2, d0, d1
    // 0x63c718: b               #0x63c730
    // 0x63c71c: fcmp            d1, d1
    // 0x63c720: b.vc            #0x63c72c
    // 0x63c724: mov             v2.16b, v1.16b
    // 0x63c728: b               #0x63c730
    // 0x63c72c: mov             v2.16b, v0.16b
    // 0x63c730: ldur            d1, [fp, #-8]
    // 0x63c734: ldur            d0, [fp, #-0x10]
    // 0x63c738: fadd            d3, d1, d2
    // 0x63c73c: stur            d3, [fp, #-0x18]
    // 0x63c740: ldr             x16, [fp, #0x18]
    // 0x63c744: r30 = Instance__ListTileSlot
    //     0x63c744: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x63c748: ldr             lr, [lr, #0xd18]
    // 0x63c74c: stp             lr, x16, [SP, #-0x10]!
    // 0x63c750: r0 = childForSlot()
    //     0x63c750: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x63c754: add             SP, SP, #0x10
    // 0x63c758: SaveReg r0
    //     0x63c758: str             x0, [SP, #-8]!
    // 0x63c75c: ldur            d0, [fp, #-0x10]
    // 0x63c760: SaveReg d0
    //     0x63c760: str             d0, [SP, #-8]!
    // 0x63c764: r0 = _maxWidth()
    //     0x63c764: bl              #0x6367c0  ; [package:flutter/src/material/input_decorator.dart] _RenderDecoration::_maxWidth
    // 0x63c768: add             SP, SP, #0x10
    // 0x63c76c: mov             v1.16b, v0.16b
    // 0x63c770: ldur            d0, [fp, #-0x18]
    // 0x63c774: fadd            d2, d0, d1
    // 0x63c778: r0 = inline_Allocate_Double()
    //     0x63c778: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63c77c: add             x0, x0, #0x10
    //     0x63c780: cmp             x1, x0
    //     0x63c784: b.ls            #0x63c7b8
    //     0x63c788: str             x0, [THR, #0x60]  ; THR::top
    //     0x63c78c: sub             x0, x0, #0xf
    //     0x63c790: mov             x1, #0xd108
    //     0x63c794: movk            x1, #3, lsl #16
    //     0x63c798: stur            x1, [x0, #-1]
    // 0x63c79c: StoreField: r0->field_7 = d2
    //     0x63c79c: stur            d2, [x0, #7]
    // 0x63c7a0: LeaveFrame
    //     0x63c7a0: mov             SP, fp
    //     0x63c7a4: ldp             fp, lr, [SP], #0x10
    // 0x63c7a8: ret
    //     0x63c7a8: ret             
    // 0x63c7ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63c7ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63c7b0: b               #0x63c57c
    // 0x63c7b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63c7b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63c7b8: SaveReg d2
    //     0x63c7b8: str             q2, [SP, #-0x10]!
    // 0x63c7bc: r0 = AllocateDouble()
    //     0x63c7bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63c7c0: RestoreReg d2
    //     0x63c7c0: ldr             q2, [SP], #0x10
    // 0x63c7c4: b               #0x63c79c
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0x63e590, size: 0x134
    // 0x63e590: EnterFrame
    //     0x63e590: stp             fp, lr, [SP, #-0x10]!
    //     0x63e594: mov             fp, SP
    // 0x63e598: AllocStack(0x10)
    //     0x63e598: sub             SP, SP, #0x10
    // 0x63e59c: CheckStackOverflow
    //     0x63e59c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63e5a0: cmp             SP, x16
    //     0x63e5a4: b.ls            #0x63e69c
    // 0x63e5a8: ldr             x16, [fp, #0x18]
    // 0x63e5ac: r30 = Instance__ListTileSlot
    //     0x63e5ac: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x63e5b0: ldr             lr, [lr, #0xd08]
    // 0x63e5b4: stp             lr, x16, [SP, #-0x10]!
    // 0x63e5b8: r0 = childForSlot()
    //     0x63e5b8: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x63e5bc: add             SP, SP, #0x10
    // 0x63e5c0: cmp             w0, NULL
    // 0x63e5c4: b.eq            #0x63e6a4
    // 0x63e5c8: LoadField: r3 = r0->field_17
    //     0x63e5c8: ldur            w3, [x0, #0x17]
    // 0x63e5cc: DecompressPointer r3
    //     0x63e5cc: add             x3, x3, HEAP, lsl #32
    // 0x63e5d0: stur            x3, [fp, #-8]
    // 0x63e5d4: cmp             w3, NULL
    // 0x63e5d8: b.eq            #0x63e6a8
    // 0x63e5dc: mov             x0, x3
    // 0x63e5e0: r2 = Null
    //     0x63e5e0: mov             x2, NULL
    // 0x63e5e4: r1 = Null
    //     0x63e5e4: mov             x1, NULL
    // 0x63e5e8: r4 = LoadClassIdInstr(r0)
    //     0x63e5e8: ldur            x4, [x0, #-1]
    //     0x63e5ec: ubfx            x4, x4, #0xc, #0x14
    // 0x63e5f0: sub             x4, x4, #0x7ff
    // 0x63e5f4: cmp             x4, #0xb
    // 0x63e5f8: b.ls            #0x63e610
    // 0x63e5fc: r8 = BoxParentData
    //     0x63e5fc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x63e600: ldr             x8, [x8, #0x1b0]
    // 0x63e604: r3 = Null
    //     0x63e604: add             x3, PP, #0x56, lsl #12  ; [pp+0x56df0] Null
    //     0x63e608: ldr             x3, [x3, #0xdf0]
    // 0x63e60c: r0 = DefaultTypeTest()
    //     0x63e60c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x63e610: ldur            x0, [fp, #-8]
    // 0x63e614: LoadField: r1 = r0->field_7
    //     0x63e614: ldur            w1, [x0, #7]
    // 0x63e618: DecompressPointer r1
    //     0x63e618: add             x1, x1, HEAP, lsl #32
    // 0x63e61c: LoadField: d0 = r1->field_f
    //     0x63e61c: ldur            d0, [x1, #0xf]
    // 0x63e620: stur            d0, [fp, #-0x10]
    // 0x63e624: ldr             x16, [fp, #0x18]
    // 0x63e628: r30 = Instance__ListTileSlot
    //     0x63e628: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x63e62c: ldr             lr, [lr, #0xd08]
    // 0x63e630: stp             lr, x16, [SP, #-0x10]!
    // 0x63e634: r0 = childForSlot()
    //     0x63e634: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x63e638: add             SP, SP, #0x10
    // 0x63e63c: cmp             w0, NULL
    // 0x63e640: b.eq            #0x63e6ac
    // 0x63e644: ldr             x16, [fp, #0x10]
    // 0x63e648: stp             x16, x0, [SP, #-0x10]!
    // 0x63e64c: r0 = getDistanceToActualBaseline()
    //     0x63e64c: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x63e650: add             SP, SP, #0x10
    // 0x63e654: cmp             w0, NULL
    // 0x63e658: b.eq            #0x63e6b0
    // 0x63e65c: LoadField: d0 = r0->field_7
    //     0x63e65c: ldur            d0, [x0, #7]
    // 0x63e660: ldur            d1, [fp, #-0x10]
    // 0x63e664: fadd            d2, d1, d0
    // 0x63e668: r0 = inline_Allocate_Double()
    //     0x63e668: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63e66c: add             x0, x0, #0x10
    //     0x63e670: cmp             x1, x0
    //     0x63e674: b.ls            #0x63e6b4
    //     0x63e678: str             x0, [THR, #0x60]  ; THR::top
    //     0x63e67c: sub             x0, x0, #0xf
    //     0x63e680: mov             x1, #0xd108
    //     0x63e684: movk            x1, #3, lsl #16
    //     0x63e688: stur            x1, [x0, #-1]
    // 0x63e68c: StoreField: r0->field_7 = d2
    //     0x63e68c: stur            d2, [x0, #7]
    // 0x63e690: LeaveFrame
    //     0x63e690: mov             SP, fp
    //     0x63e694: ldp             fp, lr, [SP], #0x10
    // 0x63e698: ret
    //     0x63e698: ret             
    // 0x63e69c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63e69c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63e6a0: b               #0x63e5a8
    // 0x63e6a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63e6a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63e6a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63e6a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63e6ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63e6ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63e6b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63e6b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63e6b4: SaveReg d2
    //     0x63e6b4: str             q2, [SP, #-0x10]!
    // 0x63e6b8: r0 = AllocateDouble()
    //     0x63e6b8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63e6bc: RestoreReg d2
    //     0x63e6bc: ldr             q2, [SP], #0x10
    // 0x63e6c0: b               #0x63e68c
  }
  _ paint(/* No info */) {
    // ** addr: 0x66b494, size: 0x2d0
    // 0x66b494: EnterFrame
    //     0x66b494: stp             fp, lr, [SP, #-0x10]!
    //     0x66b498: mov             fp, SP
    // 0x66b49c: AllocStack(0x10)
    //     0x66b49c: sub             SP, SP, #0x10
    // 0x66b4a0: CheckStackOverflow
    //     0x66b4a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66b4a4: cmp             SP, x16
    //     0x66b4a8: b.ls            #0x66b74c
    // 0x66b4ac: ldr             x16, [fp, #0x20]
    // 0x66b4b0: r30 = Instance__ListTileSlot
    //     0x66b4b0: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x66b4b4: ldr             lr, [lr, #0xd00]
    // 0x66b4b8: stp             lr, x16, [SP, #-0x10]!
    // 0x66b4bc: r0 = childForSlot()
    //     0x66b4bc: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x66b4c0: add             SP, SP, #0x10
    // 0x66b4c4: mov             x3, x0
    // 0x66b4c8: stur            x3, [fp, #-0x10]
    // 0x66b4cc: cmp             w3, NULL
    // 0x66b4d0: b.eq            #0x66b550
    // 0x66b4d4: LoadField: r4 = r3->field_17
    //     0x66b4d4: ldur            w4, [x3, #0x17]
    // 0x66b4d8: DecompressPointer r4
    //     0x66b4d8: add             x4, x4, HEAP, lsl #32
    // 0x66b4dc: stur            x4, [fp, #-8]
    // 0x66b4e0: cmp             w4, NULL
    // 0x66b4e4: b.eq            #0x66b754
    // 0x66b4e8: mov             x0, x4
    // 0x66b4ec: r2 = Null
    //     0x66b4ec: mov             x2, NULL
    // 0x66b4f0: r1 = Null
    //     0x66b4f0: mov             x1, NULL
    // 0x66b4f4: r4 = LoadClassIdInstr(r0)
    //     0x66b4f4: ldur            x4, [x0, #-1]
    //     0x66b4f8: ubfx            x4, x4, #0xc, #0x14
    // 0x66b4fc: sub             x4, x4, #0x7ff
    // 0x66b500: cmp             x4, #0xb
    // 0x66b504: b.ls            #0x66b51c
    // 0x66b508: r8 = BoxParentData
    //     0x66b508: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x66b50c: ldr             x8, [x8, #0x1b0]
    // 0x66b510: r3 = Null
    //     0x66b510: add             x3, PP, #0x56, lsl #12  ; [pp+0x56d90] Null
    //     0x66b514: ldr             x3, [x3, #0xd90]
    // 0x66b518: r0 = DefaultTypeTest()
    //     0x66b518: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66b51c: ldur            x0, [fp, #-8]
    // 0x66b520: LoadField: r1 = r0->field_7
    //     0x66b520: ldur            w1, [x0, #7]
    // 0x66b524: DecompressPointer r1
    //     0x66b524: add             x1, x1, HEAP, lsl #32
    // 0x66b528: ldr             x16, [fp, #0x10]
    // 0x66b52c: stp             x16, x1, [SP, #-0x10]!
    // 0x66b530: r0 = +()
    //     0x66b530: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x66b534: add             SP, SP, #0x10
    // 0x66b538: ldr             x16, [fp, #0x18]
    // 0x66b53c: ldur            lr, [fp, #-0x10]
    // 0x66b540: stp             lr, x16, [SP, #-0x10]!
    // 0x66b544: SaveReg r0
    //     0x66b544: str             x0, [SP, #-8]!
    // 0x66b548: r0 = paintChild()
    //     0x66b548: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66b54c: add             SP, SP, #0x18
    // 0x66b550: ldr             x16, [fp, #0x20]
    // 0x66b554: r30 = Instance__ListTileSlot
    //     0x66b554: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x66b558: ldr             lr, [lr, #0xd08]
    // 0x66b55c: stp             lr, x16, [SP, #-0x10]!
    // 0x66b560: r0 = childForSlot()
    //     0x66b560: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x66b564: add             SP, SP, #0x10
    // 0x66b568: mov             x3, x0
    // 0x66b56c: stur            x3, [fp, #-0x10]
    // 0x66b570: cmp             w3, NULL
    // 0x66b574: b.eq            #0x66b5f4
    // 0x66b578: LoadField: r4 = r3->field_17
    //     0x66b578: ldur            w4, [x3, #0x17]
    // 0x66b57c: DecompressPointer r4
    //     0x66b57c: add             x4, x4, HEAP, lsl #32
    // 0x66b580: stur            x4, [fp, #-8]
    // 0x66b584: cmp             w4, NULL
    // 0x66b588: b.eq            #0x66b758
    // 0x66b58c: mov             x0, x4
    // 0x66b590: r2 = Null
    //     0x66b590: mov             x2, NULL
    // 0x66b594: r1 = Null
    //     0x66b594: mov             x1, NULL
    // 0x66b598: r4 = LoadClassIdInstr(r0)
    //     0x66b598: ldur            x4, [x0, #-1]
    //     0x66b59c: ubfx            x4, x4, #0xc, #0x14
    // 0x66b5a0: sub             x4, x4, #0x7ff
    // 0x66b5a4: cmp             x4, #0xb
    // 0x66b5a8: b.ls            #0x66b5c0
    // 0x66b5ac: r8 = BoxParentData
    //     0x66b5ac: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x66b5b0: ldr             x8, [x8, #0x1b0]
    // 0x66b5b4: r3 = Null
    //     0x66b5b4: add             x3, PP, #0x56, lsl #12  ; [pp+0x56da0] Null
    //     0x66b5b8: ldr             x3, [x3, #0xda0]
    // 0x66b5bc: r0 = DefaultTypeTest()
    //     0x66b5bc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66b5c0: ldur            x0, [fp, #-8]
    // 0x66b5c4: LoadField: r1 = r0->field_7
    //     0x66b5c4: ldur            w1, [x0, #7]
    // 0x66b5c8: DecompressPointer r1
    //     0x66b5c8: add             x1, x1, HEAP, lsl #32
    // 0x66b5cc: ldr             x16, [fp, #0x10]
    // 0x66b5d0: stp             x16, x1, [SP, #-0x10]!
    // 0x66b5d4: r0 = +()
    //     0x66b5d4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x66b5d8: add             SP, SP, #0x10
    // 0x66b5dc: ldr             x16, [fp, #0x18]
    // 0x66b5e0: ldur            lr, [fp, #-0x10]
    // 0x66b5e4: stp             lr, x16, [SP, #-0x10]!
    // 0x66b5e8: SaveReg r0
    //     0x66b5e8: str             x0, [SP, #-8]!
    // 0x66b5ec: r0 = paintChild()
    //     0x66b5ec: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66b5f0: add             SP, SP, #0x18
    // 0x66b5f4: ldr             x16, [fp, #0x20]
    // 0x66b5f8: r30 = Instance__ListTileSlot
    //     0x66b5f8: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x66b5fc: ldr             lr, [lr, #0xd10]
    // 0x66b600: stp             lr, x16, [SP, #-0x10]!
    // 0x66b604: r0 = childForSlot()
    //     0x66b604: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x66b608: add             SP, SP, #0x10
    // 0x66b60c: mov             x3, x0
    // 0x66b610: stur            x3, [fp, #-0x10]
    // 0x66b614: cmp             w3, NULL
    // 0x66b618: b.eq            #0x66b698
    // 0x66b61c: LoadField: r4 = r3->field_17
    //     0x66b61c: ldur            w4, [x3, #0x17]
    // 0x66b620: DecompressPointer r4
    //     0x66b620: add             x4, x4, HEAP, lsl #32
    // 0x66b624: stur            x4, [fp, #-8]
    // 0x66b628: cmp             w4, NULL
    // 0x66b62c: b.eq            #0x66b75c
    // 0x66b630: mov             x0, x4
    // 0x66b634: r2 = Null
    //     0x66b634: mov             x2, NULL
    // 0x66b638: r1 = Null
    //     0x66b638: mov             x1, NULL
    // 0x66b63c: r4 = LoadClassIdInstr(r0)
    //     0x66b63c: ldur            x4, [x0, #-1]
    //     0x66b640: ubfx            x4, x4, #0xc, #0x14
    // 0x66b644: sub             x4, x4, #0x7ff
    // 0x66b648: cmp             x4, #0xb
    // 0x66b64c: b.ls            #0x66b664
    // 0x66b650: r8 = BoxParentData
    //     0x66b650: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x66b654: ldr             x8, [x8, #0x1b0]
    // 0x66b658: r3 = Null
    //     0x66b658: add             x3, PP, #0x56, lsl #12  ; [pp+0x56db0] Null
    //     0x66b65c: ldr             x3, [x3, #0xdb0]
    // 0x66b660: r0 = DefaultTypeTest()
    //     0x66b660: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66b664: ldur            x0, [fp, #-8]
    // 0x66b668: LoadField: r1 = r0->field_7
    //     0x66b668: ldur            w1, [x0, #7]
    // 0x66b66c: DecompressPointer r1
    //     0x66b66c: add             x1, x1, HEAP, lsl #32
    // 0x66b670: ldr             x16, [fp, #0x10]
    // 0x66b674: stp             x16, x1, [SP, #-0x10]!
    // 0x66b678: r0 = +()
    //     0x66b678: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x66b67c: add             SP, SP, #0x10
    // 0x66b680: ldr             x16, [fp, #0x18]
    // 0x66b684: ldur            lr, [fp, #-0x10]
    // 0x66b688: stp             lr, x16, [SP, #-0x10]!
    // 0x66b68c: SaveReg r0
    //     0x66b68c: str             x0, [SP, #-8]!
    // 0x66b690: r0 = paintChild()
    //     0x66b690: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66b694: add             SP, SP, #0x18
    // 0x66b698: ldr             x16, [fp, #0x20]
    // 0x66b69c: r30 = Instance__ListTileSlot
    //     0x66b69c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x66b6a0: ldr             lr, [lr, #0xd18]
    // 0x66b6a4: stp             lr, x16, [SP, #-0x10]!
    // 0x66b6a8: r0 = childForSlot()
    //     0x66b6a8: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x66b6ac: add             SP, SP, #0x10
    // 0x66b6b0: mov             x3, x0
    // 0x66b6b4: stur            x3, [fp, #-0x10]
    // 0x66b6b8: cmp             w3, NULL
    // 0x66b6bc: b.eq            #0x66b73c
    // 0x66b6c0: LoadField: r4 = r3->field_17
    //     0x66b6c0: ldur            w4, [x3, #0x17]
    // 0x66b6c4: DecompressPointer r4
    //     0x66b6c4: add             x4, x4, HEAP, lsl #32
    // 0x66b6c8: stur            x4, [fp, #-8]
    // 0x66b6cc: cmp             w4, NULL
    // 0x66b6d0: b.eq            #0x66b760
    // 0x66b6d4: mov             x0, x4
    // 0x66b6d8: r2 = Null
    //     0x66b6d8: mov             x2, NULL
    // 0x66b6dc: r1 = Null
    //     0x66b6dc: mov             x1, NULL
    // 0x66b6e0: r4 = LoadClassIdInstr(r0)
    //     0x66b6e0: ldur            x4, [x0, #-1]
    //     0x66b6e4: ubfx            x4, x4, #0xc, #0x14
    // 0x66b6e8: sub             x4, x4, #0x7ff
    // 0x66b6ec: cmp             x4, #0xb
    // 0x66b6f0: b.ls            #0x66b708
    // 0x66b6f4: r8 = BoxParentData
    //     0x66b6f4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x66b6f8: ldr             x8, [x8, #0x1b0]
    // 0x66b6fc: r3 = Null
    //     0x66b6fc: add             x3, PP, #0x56, lsl #12  ; [pp+0x56dc0] Null
    //     0x66b700: ldr             x3, [x3, #0xdc0]
    // 0x66b704: r0 = DefaultTypeTest()
    //     0x66b704: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66b708: ldur            x0, [fp, #-8]
    // 0x66b70c: LoadField: r1 = r0->field_7
    //     0x66b70c: ldur            w1, [x0, #7]
    // 0x66b710: DecompressPointer r1
    //     0x66b710: add             x1, x1, HEAP, lsl #32
    // 0x66b714: ldr             x16, [fp, #0x10]
    // 0x66b718: stp             x16, x1, [SP, #-0x10]!
    // 0x66b71c: r0 = +()
    //     0x66b71c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x66b720: add             SP, SP, #0x10
    // 0x66b724: ldr             x16, [fp, #0x18]
    // 0x66b728: ldur            lr, [fp, #-0x10]
    // 0x66b72c: stp             lr, x16, [SP, #-0x10]!
    // 0x66b730: SaveReg r0
    //     0x66b730: str             x0, [SP, #-8]!
    // 0x66b734: r0 = paintChild()
    //     0x66b734: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66b738: add             SP, SP, #0x18
    // 0x66b73c: r0 = Null
    //     0x66b73c: mov             x0, NULL
    // 0x66b740: LeaveFrame
    //     0x66b740: mov             SP, fp
    //     0x66b744: ldp             fp, lr, [SP], #0x10
    // 0x66b748: ret
    //     0x66b748: ret             
    // 0x66b74c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66b74c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66b750: b               #0x66b4ac
    // 0x66b754: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66b754: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66b758: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66b758: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66b75c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66b75c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66b760: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66b760: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x69ae88, size: 0xbac
    // 0x69ae88: EnterFrame
    //     0x69ae88: stp             fp, lr, [SP, #-0x10]!
    //     0x69ae8c: mov             fp, SP
    // 0x69ae90: AllocStack(0x90)
    //     0x69ae90: sub             SP, SP, #0x90
    // 0x69ae94: CheckStackOverflow
    //     0x69ae94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69ae98: cmp             SP, x16
    //     0x69ae9c: b.ls            #0x69b980
    // 0x69aea0: ldr             x3, [fp, #0x10]
    // 0x69aea4: LoadField: r4 = r3->field_27
    //     0x69aea4: ldur            w4, [x3, #0x27]
    // 0x69aea8: DecompressPointer r4
    //     0x69aea8: add             x4, x4, HEAP, lsl #32
    // 0x69aeac: stur            x4, [fp, #-8]
    // 0x69aeb0: cmp             w4, NULL
    // 0x69aeb4: b.eq            #0x69b960
    // 0x69aeb8: mov             x0, x4
    // 0x69aebc: r2 = Null
    //     0x69aebc: mov             x2, NULL
    // 0x69aec0: r1 = Null
    //     0x69aec0: mov             x1, NULL
    // 0x69aec4: r4 = LoadClassIdInstr(r0)
    //     0x69aec4: ldur            x4, [x0, #-1]
    //     0x69aec8: ubfx            x4, x4, #0xc, #0x14
    // 0x69aecc: sub             x4, x4, #0x80d
    // 0x69aed0: cmp             x4, #1
    // 0x69aed4: b.ls            #0x69aeec
    // 0x69aed8: r8 = BoxConstraints
    //     0x69aed8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69aedc: ldr             x8, [x8, #0x1d0]
    // 0x69aee0: r3 = Null
    //     0x69aee0: add             x3, PP, #0x56, lsl #12  ; [pp+0x56dd0] Null
    //     0x69aee4: ldr             x3, [x3, #0xdd0]
    // 0x69aee8: r0 = BoxConstraints()
    //     0x69aee8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69aeec: ldr             x16, [fp, #0x10]
    // 0x69aef0: r30 = Instance__ListTileSlot
    //     0x69aef0: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x69aef4: ldr             lr, [lr, #0xd00]
    // 0x69aef8: stp             lr, x16, [SP, #-0x10]!
    // 0x69aefc: r0 = childForSlot()
    //     0x69aefc: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69af00: add             SP, SP, #0x10
    // 0x69af04: cmp             w0, NULL
    // 0x69af08: r16 = true
    //     0x69af08: add             x16, NULL, #0x20  ; true
    // 0x69af0c: r17 = false
    //     0x69af0c: add             x17, NULL, #0x30  ; false
    // 0x69af10: csel            x1, x16, x17, ne
    // 0x69af14: stur            x1, [fp, #-0x10]
    // 0x69af18: ldr             x16, [fp, #0x10]
    // 0x69af1c: r30 = Instance__ListTileSlot
    //     0x69af1c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x69af20: ldr             lr, [lr, #0xd10]
    // 0x69af24: stp             lr, x16, [SP, #-0x10]!
    // 0x69af28: r0 = childForSlot()
    //     0x69af28: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69af2c: add             SP, SP, #0x10
    // 0x69af30: cmp             w0, NULL
    // 0x69af34: r16 = true
    //     0x69af34: add             x16, NULL, #0x20  ; true
    // 0x69af38: r17 = false
    //     0x69af38: add             x17, NULL, #0x30  ; false
    // 0x69af3c: csel            x1, x16, x17, ne
    // 0x69af40: stur            x1, [fp, #-0x18]
    // 0x69af44: ldr             x16, [fp, #0x10]
    // 0x69af48: r30 = Instance__ListTileSlot
    //     0x69af48: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x69af4c: ldr             lr, [lr, #0xd18]
    // 0x69af50: stp             lr, x16, [SP, #-0x10]!
    // 0x69af54: r0 = childForSlot()
    //     0x69af54: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69af58: add             SP, SP, #0x10
    // 0x69af5c: cmp             w0, NULL
    // 0x69af60: r16 = true
    //     0x69af60: add             x16, NULL, #0x20  ; true
    // 0x69af64: r17 = false
    //     0x69af64: add             x17, NULL, #0x30  ; false
    // 0x69af68: csel            x1, x16, x17, ne
    // 0x69af6c: ldr             x0, [fp, #0x10]
    // 0x69af70: stur            x1, [fp, #-0x20]
    // 0x69af74: LoadField: r2 = r0->field_67
    //     0x69af74: ldur            w2, [x0, #0x67]
    // 0x69af78: DecompressPointer r2
    //     0x69af78: add             x2, x2, HEAP, lsl #32
    // 0x69af7c: SaveReg r2
    //     0x69af7c: str             x2, [SP, #-8]!
    // 0x69af80: r0 = baseSizeAdjustment()
    //     0x69af80: bl              #0x630630  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0x69af84: add             SP, SP, #8
    // 0x69af88: LoadField: d0 = r0->field_f
    //     0x69af88: ldur            d0, [x0, #0xf]
    // 0x69af8c: d1 = 56.000000
    //     0x69af8c: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e88] IMM: double(56) from 0x404c000000000000
    //     0x69af90: ldr             d1, [x17, #0xe88]
    // 0x69af94: fadd            d2, d1, d0
    // 0x69af98: stur            d2, [fp, #-0x58]
    // 0x69af9c: r0 = BoxConstraints()
    //     0x69af9c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x69afa0: d0 = 0.000000
    //     0x69afa0: eor             v0.16b, v0.16b, v0.16b
    // 0x69afa4: stur            x0, [fp, #-0x28]
    // 0x69afa8: StoreField: r0->field_7 = d0
    //     0x69afa8: stur            d0, [x0, #7]
    // 0x69afac: d1 = inf
    //     0x69afac: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x69afb0: StoreField: r0->field_f = d1
    //     0x69afb0: stur            d1, [x0, #0xf]
    // 0x69afb4: StoreField: r0->field_17 = d0
    //     0x69afb4: stur            d0, [x0, #0x17]
    // 0x69afb8: ldur            d1, [fp, #-0x58]
    // 0x69afbc: StoreField: r0->field_1f = d1
    //     0x69afbc: stur            d1, [x0, #0x1f]
    // 0x69afc0: ldur            x16, [fp, #-8]
    // 0x69afc4: SaveReg r16
    //     0x69afc4: str             x16, [SP, #-8]!
    // 0x69afc8: r0 = loosen()
    //     0x69afc8: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x69afcc: add             SP, SP, #8
    // 0x69afd0: stur            x0, [fp, #-0x30]
    // 0x69afd4: ldur            x16, [fp, #-0x28]
    // 0x69afd8: stp             x16, x0, [SP, #-0x10]!
    // 0x69afdc: r0 = enforce()
    //     0x69afdc: bl              #0x62bd90  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0x69afe0: add             SP, SP, #0x10
    // 0x69afe4: mov             x1, x0
    // 0x69afe8: ldur            x0, [fp, #-0x30]
    // 0x69afec: stur            x1, [fp, #-0x28]
    // 0x69aff0: LoadField: d0 = r0->field_f
    //     0x69aff0: ldur            d0, [x0, #0xf]
    // 0x69aff4: stur            d0, [fp, #-0x58]
    // 0x69aff8: ldr             x16, [fp, #0x10]
    // 0x69affc: r30 = Instance__ListTileSlot
    //     0x69affc: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x69b000: ldr             lr, [lr, #0xd00]
    // 0x69b004: stp             lr, x16, [SP, #-0x10]!
    // 0x69b008: r0 = childForSlot()
    //     0x69b008: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b00c: add             SP, SP, #0x10
    // 0x69b010: ldur            x16, [fp, #-0x28]
    // 0x69b014: stp             x16, x0, [SP, #-0x10]!
    // 0x69b018: r0 = _layoutBox()
    //     0x69b018: bl              #0x69bac4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_layoutBox
    // 0x69b01c: add             SP, SP, #0x10
    // 0x69b020: stur            x0, [fp, #-0x38]
    // 0x69b024: ldr             x16, [fp, #0x10]
    // 0x69b028: r30 = Instance__ListTileSlot
    //     0x69b028: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x69b02c: ldr             lr, [lr, #0xd18]
    // 0x69b030: stp             lr, x16, [SP, #-0x10]!
    // 0x69b034: r0 = childForSlot()
    //     0x69b034: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b038: add             SP, SP, #0x10
    // 0x69b03c: ldur            x16, [fp, #-0x28]
    // 0x69b040: stp             x16, x0, [SP, #-0x10]!
    // 0x69b044: r0 = _layoutBox()
    //     0x69b044: bl              #0x69bac4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_layoutBox
    // 0x69b048: add             SP, SP, #0x10
    // 0x69b04c: mov             x1, x0
    // 0x69b050: ldur            x0, [fp, #-0x10]
    // 0x69b054: stur            x1, [fp, #-0x28]
    // 0x69b058: tbnz            w0, #4, #0x69b0e8
    // 0x69b05c: ldr             x3, [fp, #0x10]
    // 0x69b060: ldur            x2, [fp, #-0x38]
    // 0x69b064: LoadField: d0 = r3->field_8b
    //     0x69b064: ldur            d0, [x3, #0x8b]
    // 0x69b068: LoadField: d1 = r2->field_7
    //     0x69b068: ldur            d1, [x2, #7]
    // 0x69b06c: fcmp            d0, d1
    // 0x69b070: b.vs            #0x69b084
    // 0x69b074: b.le            #0x69b084
    // 0x69b078: mov             v1.16b, v0.16b
    // 0x69b07c: d2 = 0.000000
    //     0x69b07c: eor             v2.16b, v2.16b, v2.16b
    // 0x69b080: b               #0x69b0c0
    // 0x69b084: fcmp            d0, d1
    // 0x69b088: b.vs            #0x69b098
    // 0x69b08c: b.ge            #0x69b098
    // 0x69b090: d2 = 0.000000
    //     0x69b090: eor             v2.16b, v2.16b, v2.16b
    // 0x69b094: b               #0x69b0c0
    // 0x69b098: d2 = 0.000000
    //     0x69b098: eor             v2.16b, v2.16b, v2.16b
    // 0x69b09c: fcmp            d0, d2
    // 0x69b0a0: b.vs            #0x69b0b4
    // 0x69b0a4: b.ne            #0x69b0b4
    // 0x69b0a8: fadd            d3, d0, d1
    // 0x69b0ac: mov             v1.16b, v3.16b
    // 0x69b0b0: b               #0x69b0c0
    // 0x69b0b4: fcmp            d1, d1
    // 0x69b0b8: b.vs            #0x69b0c0
    // 0x69b0bc: mov             v1.16b, v0.16b
    // 0x69b0c0: d0 = 2.000000
    //     0x69b0c0: fmov            d0, #2.00000000
    // 0x69b0c4: LoadField: d3 = r3->field_7b
    //     0x69b0c4: ldur            d3, [x3, #0x7b]
    // 0x69b0c8: LoadField: r4 = r3->field_67
    //     0x69b0c8: ldur            w4, [x3, #0x67]
    // 0x69b0cc: DecompressPointer r4
    //     0x69b0cc: add             x4, x4, HEAP, lsl #32
    // 0x69b0d0: LoadField: d4 = r4->field_7
    //     0x69b0d0: ldur            d4, [x4, #7]
    // 0x69b0d4: fmul            d5, d4, d0
    // 0x69b0d8: fadd            d4, d3, d5
    // 0x69b0dc: fadd            d3, d1, d4
    // 0x69b0e0: mov             v1.16b, v3.16b
    // 0x69b0e4: b               #0x69b0fc
    // 0x69b0e8: ldr             x3, [fp, #0x10]
    // 0x69b0ec: ldur            x2, [fp, #-0x38]
    // 0x69b0f0: d2 = 0.000000
    //     0x69b0f0: eor             v2.16b, v2.16b, v2.16b
    // 0x69b0f4: d0 = 2.000000
    //     0x69b0f4: fmov            d0, #2.00000000
    // 0x69b0f8: d1 = 0.000000
    //     0x69b0f8: eor             v1.16b, v1.16b, v1.16b
    // 0x69b0fc: ldur            x4, [fp, #-0x20]
    // 0x69b100: stur            d1, [fp, #-0x68]
    // 0x69b104: tbnz            w4, #4, #0x69b180
    // 0x69b108: d3 = 32.000000
    //     0x69b108: add             x17, PP, #0x25, lsl #12  ; [pp+0x25a48] IMM: double(32) from 0x4040000000000000
    //     0x69b10c: ldr             d3, [x17, #0xa48]
    // 0x69b110: LoadField: d4 = r1->field_7
    //     0x69b110: ldur            d4, [x1, #7]
    // 0x69b114: LoadField: d5 = r3->field_7b
    //     0x69b114: ldur            d5, [x3, #0x7b]
    // 0x69b118: LoadField: r5 = r3->field_67
    //     0x69b118: ldur            w5, [x3, #0x67]
    // 0x69b11c: DecompressPointer r5
    //     0x69b11c: add             x5, x5, HEAP, lsl #32
    // 0x69b120: LoadField: d6 = r5->field_7
    //     0x69b120: ldur            d6, [x5, #7]
    // 0x69b124: fmul            d7, d6, d0
    // 0x69b128: fadd            d6, d5, d7
    // 0x69b12c: fadd            d5, d4, d6
    // 0x69b130: fcmp            d5, d3
    // 0x69b134: b.vs            #0x69b144
    // 0x69b138: b.le            #0x69b144
    // 0x69b13c: mov             v3.16b, v5.16b
    // 0x69b140: b               #0x69b178
    // 0x69b144: fcmp            d5, d3
    // 0x69b148: b.vs            #0x69b15c
    // 0x69b14c: b.ge            #0x69b15c
    // 0x69b150: d3 = 32.000000
    //     0x69b150: add             x17, PP, #0x25, lsl #12  ; [pp+0x25a48] IMM: double(32) from 0x4040000000000000
    //     0x69b154: ldr             d3, [x17, #0xa48]
    // 0x69b158: b               #0x69b178
    // 0x69b15c: fcmp            d5, d2
    // 0x69b160: b.vs            #0x69b174
    // 0x69b164: b.ne            #0x69b174
    // 0x69b168: fadd            d4, d5, d3
    // 0x69b16c: mov             v3.16b, v4.16b
    // 0x69b170: b               #0x69b178
    // 0x69b174: mov             v3.16b, v5.16b
    // 0x69b178: mov             v4.16b, v3.16b
    // 0x69b17c: b               #0x69b184
    // 0x69b180: d4 = 0.000000
    //     0x69b180: eor             v4.16b, v4.16b, v4.16b
    // 0x69b184: ldur            x5, [fp, #-0x18]
    // 0x69b188: ldur            d3, [fp, #-0x58]
    // 0x69b18c: stur            d4, [fp, #-0x60]
    // 0x69b190: fsub            d5, d3, d1
    // 0x69b194: fsub            d6, d5, d4
    // 0x69b198: r6 = inline_Allocate_Double()
    //     0x69b198: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x69b19c: add             x6, x6, #0x10
    //     0x69b1a0: cmp             x7, x6
    //     0x69b1a4: b.ls            #0x69b988
    //     0x69b1a8: str             x6, [THR, #0x60]  ; THR::top
    //     0x69b1ac: sub             x6, x6, #0xf
    //     0x69b1b0: mov             x7, #0xd108
    //     0x69b1b4: movk            x7, #3, lsl #16
    //     0x69b1b8: stur            x7, [x6, #-1]
    // 0x69b1bc: StoreField: r6->field_7 = d6
    //     0x69b1bc: stur            d6, [x6, #7]
    // 0x69b1c0: ldur            x16, [fp, #-0x30]
    // 0x69b1c4: stp             x6, x16, [SP, #-0x10]!
    // 0x69b1c8: r4 = const [0, 0x2, 0x2, 0x1, width, 0x1, null]
    //     0x69b1c8: add             x4, PP, #0x21, lsl #12  ; [pp+0x21618] List(7) [0, 0x2, 0x2, 0x1, "width", 0x1, Null]
    //     0x69b1cc: ldr             x4, [x4, #0x618]
    // 0x69b1d0: r0 = tighten()
    //     0x69b1d0: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x69b1d4: add             SP, SP, #0x10
    // 0x69b1d8: stur            x0, [fp, #-0x30]
    // 0x69b1dc: ldr             x16, [fp, #0x10]
    // 0x69b1e0: r30 = Instance__ListTileSlot
    //     0x69b1e0: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x69b1e4: ldr             lr, [lr, #0xd08]
    // 0x69b1e8: stp             lr, x16, [SP, #-0x10]!
    // 0x69b1ec: r0 = childForSlot()
    //     0x69b1ec: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b1f0: add             SP, SP, #0x10
    // 0x69b1f4: ldur            x16, [fp, #-0x30]
    // 0x69b1f8: stp             x16, x0, [SP, #-0x10]!
    // 0x69b1fc: r0 = _layoutBox()
    //     0x69b1fc: bl              #0x69bac4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_layoutBox
    // 0x69b200: add             SP, SP, #0x10
    // 0x69b204: stur            x0, [fp, #-0x40]
    // 0x69b208: ldr             x16, [fp, #0x10]
    // 0x69b20c: r30 = Instance__ListTileSlot
    //     0x69b20c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x69b210: ldr             lr, [lr, #0xd10]
    // 0x69b214: stp             lr, x16, [SP, #-0x10]!
    // 0x69b218: r0 = childForSlot()
    //     0x69b218: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b21c: add             SP, SP, #0x10
    // 0x69b220: ldur            x16, [fp, #-0x30]
    // 0x69b224: stp             x16, x0, [SP, #-0x10]!
    // 0x69b228: r0 = _layoutBox()
    //     0x69b228: bl              #0x69bac4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_layoutBox
    // 0x69b22c: add             SP, SP, #0x10
    // 0x69b230: mov             x1, x0
    // 0x69b234: ldur            x0, [fp, #-0x18]
    // 0x69b238: stur            x1, [fp, #-0x50]
    // 0x69b23c: tbnz            w0, #4, #0x69b254
    // 0x69b240: r3 = 32.000000
    //     0x69b240: add             x3, PP, #0x2b, lsl #12  ; [pp+0x2b080] 32
    //     0x69b244: ldr             x3, [x3, #0x80]
    // 0x69b248: r2 = 52.000000
    //     0x69b248: add             x2, PP, #0x3d, lsl #12  ; [pp+0x3d820] 52
    //     0x69b24c: ldr             x2, [x2, #0x820]
    // 0x69b250: b               #0x69b25c
    // 0x69b254: r3 = Null
    //     0x69b254: mov             x3, NULL
    // 0x69b258: r2 = Null
    //     0x69b258: mov             x2, NULL
    // 0x69b25c: stur            x3, [fp, #-0x30]
    // 0x69b260: stur            x2, [fp, #-0x48]
    // 0x69b264: ldr             x16, [fp, #0x10]
    // 0x69b268: SaveReg r16
    //     0x69b268: str             x16, [SP, #-8]!
    // 0x69b26c: r0 = _defaultTileHeight()
    //     0x69b26c: bl              #0x630e34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_defaultTileHeight
    // 0x69b270: add             SP, SP, #8
    // 0x69b274: ldur            x0, [fp, #-0x18]
    // 0x69b278: stur            d0, [fp, #-0x70]
    // 0x69b27c: tbz             w0, #4, #0x69b308
    // 0x69b280: ldr             x2, [fp, #0x10]
    // 0x69b284: ldur            x1, [fp, #-0x40]
    // 0x69b288: d1 = 2.000000
    //     0x69b288: fmov            d1, #2.00000000
    // 0x69b28c: LoadField: d2 = r1->field_f
    //     0x69b28c: ldur            d2, [x1, #0xf]
    // 0x69b290: LoadField: d3 = r2->field_83
    //     0x69b290: ldur            d3, [x2, #0x83]
    // 0x69b294: fmul            d4, d1, d3
    // 0x69b298: fadd            d3, d2, d4
    // 0x69b29c: fcmp            d0, d3
    // 0x69b2a0: b.vs            #0x69b2b0
    // 0x69b2a4: b.le            #0x69b2b0
    // 0x69b2a8: d4 = 0.000000
    //     0x69b2a8: eor             v4.16b, v4.16b, v4.16b
    // 0x69b2ac: b               #0x69b2f0
    // 0x69b2b0: fcmp            d0, d3
    // 0x69b2b4: b.vs            #0x69b2c8
    // 0x69b2b8: b.ge            #0x69b2c8
    // 0x69b2bc: mov             v0.16b, v3.16b
    // 0x69b2c0: d4 = 0.000000
    //     0x69b2c0: eor             v4.16b, v4.16b, v4.16b
    // 0x69b2c4: b               #0x69b2f0
    // 0x69b2c8: d4 = 0.000000
    //     0x69b2c8: eor             v4.16b, v4.16b, v4.16b
    // 0x69b2cc: fcmp            d0, d4
    // 0x69b2d0: b.vs            #0x69b2e4
    // 0x69b2d4: b.ne            #0x69b2e4
    // 0x69b2d8: fadd            d5, d0, d3
    // 0x69b2dc: mov             v0.16b, v5.16b
    // 0x69b2e0: b               #0x69b2f0
    // 0x69b2e4: fcmp            d3, d3
    // 0x69b2e8: b.vc            #0x69b2f0
    // 0x69b2ec: mov             v0.16b, v3.16b
    // 0x69b2f0: fsub            d3, d0, d2
    // 0x69b2f4: fdiv            d2, d3, d1
    // 0x69b2f8: mov             v3.16b, v0.16b
    // 0x69b2fc: mov             x0, x2
    // 0x69b300: r1 = Null
    //     0x69b300: mov             x1, NULL
    // 0x69b304: b               #0x69b4c0
    // 0x69b308: ldr             x2, [fp, #0x10]
    // 0x69b30c: ldur            x1, [fp, #-0x40]
    // 0x69b310: ldur            x4, [fp, #-0x30]
    // 0x69b314: ldur            x3, [fp, #-0x48]
    // 0x69b318: d4 = 0.000000
    //     0x69b318: eor             v4.16b, v4.16b, v4.16b
    // 0x69b31c: d1 = 2.000000
    //     0x69b31c: fmov            d1, #2.00000000
    // 0x69b320: cmp             w4, NULL
    // 0x69b324: b.eq            #0x69b9c4
    // 0x69b328: r16 = Instance__ListTileSlot
    //     0x69b328: add             x16, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x69b32c: ldr             x16, [x16, #0xd08]
    // 0x69b330: stp             x16, x2, [SP, #-0x10]!
    // 0x69b334: r0 = childForSlot()
    //     0x69b334: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b338: add             SP, SP, #0x10
    // 0x69b33c: cmp             w0, NULL
    // 0x69b340: b.eq            #0x69b9c8
    // 0x69b344: ldr             x1, [fp, #0x10]
    // 0x69b348: LoadField: r2 = r1->field_73
    //     0x69b348: ldur            w2, [x1, #0x73]
    // 0x69b34c: DecompressPointer r2
    //     0x69b34c: add             x2, x2, HEAP, lsl #32
    // 0x69b350: stp             x2, x0, [SP, #-0x10]!
    // 0x69b354: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x69b354: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x69b358: r0 = getDistanceToBaseline()
    //     0x69b358: bl              #0x68a404  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToBaseline
    // 0x69b35c: add             SP, SP, #0x10
    // 0x69b360: cmp             w0, NULL
    // 0x69b364: b.eq            #0x69b9cc
    // 0x69b368: ldur            x1, [fp, #-0x30]
    // 0x69b36c: LoadField: d0 = r1->field_7
    //     0x69b36c: ldur            d0, [x1, #7]
    // 0x69b370: LoadField: d1 = r0->field_7
    //     0x69b370: ldur            d1, [x0, #7]
    // 0x69b374: fsub            d2, d0, d1
    // 0x69b378: ldur            x0, [fp, #-0x48]
    // 0x69b37c: stur            d2, [fp, #-0x78]
    // 0x69b380: cmp             w0, NULL
    // 0x69b384: b.eq            #0x69b9d0
    // 0x69b388: ldr             x16, [fp, #0x10]
    // 0x69b38c: r30 = Instance__ListTileSlot
    //     0x69b38c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x69b390: ldr             lr, [lr, #0xd10]
    // 0x69b394: stp             lr, x16, [SP, #-0x10]!
    // 0x69b398: r0 = childForSlot()
    //     0x69b398: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b39c: add             SP, SP, #0x10
    // 0x69b3a0: cmp             w0, NULL
    // 0x69b3a4: b.eq            #0x69b9d4
    // 0x69b3a8: ldr             x1, [fp, #0x10]
    // 0x69b3ac: LoadField: r2 = r1->field_77
    //     0x69b3ac: ldur            w2, [x1, #0x77]
    // 0x69b3b0: DecompressPointer r2
    //     0x69b3b0: add             x2, x2, HEAP, lsl #32
    // 0x69b3b4: cmp             w2, NULL
    // 0x69b3b8: b.eq            #0x69b9d8
    // 0x69b3bc: stp             x2, x0, [SP, #-0x10]!
    // 0x69b3c0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x69b3c0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x69b3c4: r0 = getDistanceToBaseline()
    //     0x69b3c4: bl              #0x68a404  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToBaseline
    // 0x69b3c8: add             SP, SP, #0x10
    // 0x69b3cc: cmp             w0, NULL
    // 0x69b3d0: b.eq            #0x69b9dc
    // 0x69b3d4: ldur            x1, [fp, #-0x48]
    // 0x69b3d8: LoadField: d0 = r1->field_7
    //     0x69b3d8: ldur            d0, [x1, #7]
    // 0x69b3dc: LoadField: d1 = r0->field_7
    //     0x69b3dc: ldur            d1, [x0, #7]
    // 0x69b3e0: fsub            d2, d0, d1
    // 0x69b3e4: ldr             x0, [fp, #0x10]
    // 0x69b3e8: LoadField: r1 = r0->field_67
    //     0x69b3e8: ldur            w1, [x0, #0x67]
    // 0x69b3ec: DecompressPointer r1
    //     0x69b3ec: add             x1, x1, HEAP, lsl #32
    // 0x69b3f0: LoadField: d0 = r1->field_f
    //     0x69b3f0: ldur            d0, [x1, #0xf]
    // 0x69b3f4: d1 = 2.000000
    //     0x69b3f4: fmov            d1, #2.00000000
    // 0x69b3f8: fmul            d3, d0, d1
    // 0x69b3fc: fadd            d0, d2, d3
    // 0x69b400: ldur            x1, [fp, #-0x40]
    // 0x69b404: LoadField: d2 = r1->field_f
    //     0x69b404: ldur            d2, [x1, #0xf]
    // 0x69b408: ldur            d3, [fp, #-0x78]
    // 0x69b40c: fadd            d4, d3, d2
    // 0x69b410: fsub            d5, d4, d0
    // 0x69b414: d4 = 0.000000
    //     0x69b414: eor             v4.16b, v4.16b, v4.16b
    // 0x69b418: fcmp            d5, d4
    // 0x69b41c: b.vs            #0x69b438
    // 0x69b420: b.le            #0x69b438
    // 0x69b424: fdiv            d6, d5, d1
    // 0x69b428: fsub            d5, d3, d6
    // 0x69b42c: fadd            d3, d0, d6
    // 0x69b430: mov             v0.16b, v3.16b
    // 0x69b434: mov             v3.16b, v5.16b
    // 0x69b438: LoadField: d5 = r0->field_83
    //     0x69b438: ldur            d5, [x0, #0x83]
    // 0x69b43c: fcmp            d3, d5
    // 0x69b440: b.vs            #0x69b450
    // 0x69b444: b.ge            #0x69b450
    // 0x69b448: ldur            x1, [fp, #-0x50]
    // 0x69b44c: b               #0x69b470
    // 0x69b450: ldur            x1, [fp, #-0x50]
    // 0x69b454: ldur            d6, [fp, #-0x70]
    // 0x69b458: LoadField: d7 = r1->field_f
    //     0x69b458: ldur            d7, [x1, #0xf]
    // 0x69b45c: fadd            d8, d0, d7
    // 0x69b460: fadd            d7, d8, d5
    // 0x69b464: fcmp            d7, d6
    // 0x69b468: b.vs            #0x69b490
    // 0x69b46c: b.le            #0x69b490
    // 0x69b470: LoadField: d0 = r1->field_f
    //     0x69b470: ldur            d0, [x1, #0xf]
    // 0x69b474: fadd            d3, d2, d0
    // 0x69b478: fmul            d0, d1, d5
    // 0x69b47c: fadd            d6, d3, d0
    // 0x69b480: fadd            d0, d2, d5
    // 0x69b484: mov             v3.16b, v6.16b
    // 0x69b488: mov             v2.16b, v5.16b
    // 0x69b48c: b               #0x69b498
    // 0x69b490: mov             v2.16b, v3.16b
    // 0x69b494: mov             v3.16b, v6.16b
    // 0x69b498: r1 = inline_Allocate_Double()
    //     0x69b498: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x69b49c: add             x1, x1, #0x10
    //     0x69b4a0: cmp             x2, x1
    //     0x69b4a4: b.ls            #0x69b9e0
    //     0x69b4a8: str             x1, [THR, #0x60]  ; THR::top
    //     0x69b4ac: sub             x1, x1, #0xf
    //     0x69b4b0: mov             x2, #0xd108
    //     0x69b4b4: movk            x2, #3, lsl #16
    //     0x69b4b8: stur            x2, [x1, #-1]
    // 0x69b4bc: StoreField: r1->field_7 = d0
    //     0x69b4bc: stur            d0, [x1, #7]
    // 0x69b4c0: d0 = 72.000000
    //     0x69b4c0: add             x17, PP, #0x26, lsl #12  ; [pp+0x26db0] IMM: double(72) from 0x4052000000000000
    //     0x69b4c4: ldr             d0, [x17, #0xdb0]
    // 0x69b4c8: stur            x1, [fp, #-0x30]
    // 0x69b4cc: stur            d3, [fp, #-0x78]
    // 0x69b4d0: stur            d2, [fp, #-0x80]
    // 0x69b4d4: fcmp            d3, d0
    // 0x69b4d8: b.vs            #0x69b4f8
    // 0x69b4dc: b.le            #0x69b4f8
    // 0x69b4e0: mov             x1, x0
    // 0x69b4e4: ldur            x0, [fp, #-0x28]
    // 0x69b4e8: mov             v1.16b, v3.16b
    // 0x69b4ec: d2 = 16.000000
    //     0x69b4ec: fmov            d2, #16.00000000
    // 0x69b4f0: d0 = 16.000000
    //     0x69b4f0: fmov            d0, #16.00000000
    // 0x69b4f4: b               #0x69b5d0
    // 0x69b4f8: ldur            x2, [fp, #-0x38]
    // 0x69b4fc: d0 = 16.000000
    //     0x69b4fc: fmov            d0, #16.00000000
    // 0x69b500: LoadField: d5 = r2->field_f
    //     0x69b500: ldur            d5, [x2, #0xf]
    // 0x69b504: fsub            d6, d3, d5
    // 0x69b508: fdiv            d5, d6, d1
    // 0x69b50c: stur            d5, [fp, #-0x70]
    // 0x69b510: fcmp            d5, d0
    // 0x69b514: b.vs            #0x69b52c
    // 0x69b518: b.le            #0x69b52c
    // 0x69b51c: mov             v0.16b, v1.16b
    // 0x69b520: mov             v1.16b, v3.16b
    // 0x69b524: d2 = 16.000000
    //     0x69b524: fmov            d2, #16.00000000
    // 0x69b528: b               #0x69b5b8
    // 0x69b52c: fcmp            d5, d0
    // 0x69b530: b.vs            #0x69b548
    // 0x69b534: b.ge            #0x69b548
    // 0x69b538: mov             v2.16b, v5.16b
    // 0x69b53c: mov             v0.16b, v1.16b
    // 0x69b540: mov             v1.16b, v3.16b
    // 0x69b544: b               #0x69b5b8
    // 0x69b548: fcmp            d5, d4
    // 0x69b54c: b.vs            #0x69b554
    // 0x69b550: b.eq            #0x69b55c
    // 0x69b554: r3 = false
    //     0x69b554: add             x3, NULL, #0x30  ; false
    // 0x69b558: b               #0x69b560
    // 0x69b55c: r3 = true
    //     0x69b55c: add             x3, NULL, #0x20  ; true
    // 0x69b560: tbnz            w3, #4, #0x69b580
    // 0x69b564: fadd            d6, d5, d0
    // 0x69b568: fmul            d7, d6, d5
    // 0x69b56c: fmul            d5, d7, d0
    // 0x69b570: mov             v2.16b, v5.16b
    // 0x69b574: mov             v0.16b, v1.16b
    // 0x69b578: mov             v1.16b, v3.16b
    // 0x69b57c: b               #0x69b5b8
    // 0x69b580: tbnz            w3, #4, #0x69b5ac
    // 0x69b584: r16 = 16.000000
    //     0x69b584: add             x16, PP, #0x25, lsl #12  ; [pp+0x25da8] 16
    //     0x69b588: ldr             x16, [x16, #0xda8]
    // 0x69b58c: SaveReg r16
    //     0x69b58c: str             x16, [SP, #-8]!
    // 0x69b590: r0 = isNegative()
    //     0x69b590: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x69b594: add             SP, SP, #8
    // 0x69b598: tbnz            w0, #4, #0x69b5ac
    // 0x69b59c: ldur            d1, [fp, #-0x78]
    // 0x69b5a0: d2 = 16.000000
    //     0x69b5a0: fmov            d2, #16.00000000
    // 0x69b5a4: d0 = 2.000000
    //     0x69b5a4: fmov            d0, #2.00000000
    // 0x69b5a8: b               #0x69b5b8
    // 0x69b5ac: ldur            d2, [fp, #-0x70]
    // 0x69b5b0: ldur            d1, [fp, #-0x78]
    // 0x69b5b4: d0 = 2.000000
    //     0x69b5b4: fmov            d0, #2.00000000
    // 0x69b5b8: ldur            x0, [fp, #-0x28]
    // 0x69b5bc: LoadField: d3 = r0->field_f
    //     0x69b5bc: ldur            d3, [x0, #0xf]
    // 0x69b5c0: fsub            d4, d1, d3
    // 0x69b5c4: fdiv            d3, d4, d0
    // 0x69b5c8: mov             v0.16b, v3.16b
    // 0x69b5cc: ldr             x1, [fp, #0x10]
    // 0x69b5d0: stur            d2, [fp, #-0x70]
    // 0x69b5d4: stur            d0, [fp, #-0x88]
    // 0x69b5d8: LoadField: r2 = r1->field_6f
    //     0x69b5d8: ldur            w2, [x1, #0x6f]
    // 0x69b5dc: DecompressPointer r2
    //     0x69b5dc: add             x2, x2, HEAP, lsl #32
    // 0x69b5e0: LoadField: r3 = r2->field_7
    //     0x69b5e0: ldur            x3, [x2, #7]
    // 0x69b5e4: cmp             x3, #0
    // 0x69b5e8: b.gt            #0x69b768
    // 0x69b5ec: ldur            x2, [fp, #-0x10]
    // 0x69b5f0: tbnz            w2, #4, #0x69b654
    // 0x69b5f4: ldur            d3, [fp, #-0x58]
    // 0x69b5f8: ldur            x0, [fp, #-0x38]
    // 0x69b5fc: r16 = Instance__ListTileSlot
    //     0x69b5fc: add             x16, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x69b600: ldr             x16, [x16, #0xd00]
    // 0x69b604: stp             x16, x1, [SP, #-0x10]!
    // 0x69b608: r0 = childForSlot()
    //     0x69b608: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b60c: add             SP, SP, #0x10
    // 0x69b610: stur            x0, [fp, #-0x40]
    // 0x69b614: cmp             w0, NULL
    // 0x69b618: b.eq            #0x69ba0c
    // 0x69b61c: ldur            x1, [fp, #-0x38]
    // 0x69b620: LoadField: d0 = r1->field_7
    //     0x69b620: ldur            d0, [x1, #7]
    // 0x69b624: ldur            d1, [fp, #-0x58]
    // 0x69b628: fsub            d2, d1, d0
    // 0x69b62c: stur            d2, [fp, #-0x90]
    // 0x69b630: r0 = Offset()
    //     0x69b630: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69b634: ldur            d0, [fp, #-0x90]
    // 0x69b638: StoreField: r0->field_7 = d0
    //     0x69b638: stur            d0, [x0, #7]
    // 0x69b63c: ldur            d0, [fp, #-0x70]
    // 0x69b640: StoreField: r0->field_f = d0
    //     0x69b640: stur            d0, [x0, #0xf]
    // 0x69b644: ldur            x16, [fp, #-0x40]
    // 0x69b648: stp             x0, x16, [SP, #-0x10]!
    // 0x69b64c: r0 = _positionBox()
    //     0x69b64c: bl              #0x69ba34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0x69b650: add             SP, SP, #0x10
    // 0x69b654: ldur            x0, [fp, #-0x18]
    // 0x69b658: ldur            d1, [fp, #-0x60]
    // 0x69b65c: ldur            d0, [fp, #-0x80]
    // 0x69b660: ldr             x16, [fp, #0x10]
    // 0x69b664: r30 = Instance__ListTileSlot
    //     0x69b664: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x69b668: ldr             lr, [lr, #0xd08]
    // 0x69b66c: stp             lr, x16, [SP, #-0x10]!
    // 0x69b670: r0 = childForSlot()
    //     0x69b670: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b674: add             SP, SP, #0x10
    // 0x69b678: stur            x0, [fp, #-0x38]
    // 0x69b67c: cmp             w0, NULL
    // 0x69b680: b.eq            #0x69ba10
    // 0x69b684: r0 = Offset()
    //     0x69b684: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69b688: ldur            d0, [fp, #-0x60]
    // 0x69b68c: StoreField: r0->field_7 = d0
    //     0x69b68c: stur            d0, [x0, #7]
    // 0x69b690: ldur            d1, [fp, #-0x80]
    // 0x69b694: StoreField: r0->field_f = d1
    //     0x69b694: stur            d1, [x0, #0xf]
    // 0x69b698: ldur            x16, [fp, #-0x38]
    // 0x69b69c: stp             x0, x16, [SP, #-0x10]!
    // 0x69b6a0: r0 = _positionBox()
    //     0x69b6a0: bl              #0x69ba34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0x69b6a4: add             SP, SP, #0x10
    // 0x69b6a8: ldur            x1, [fp, #-0x18]
    // 0x69b6ac: tbnz            w1, #4, #0x69b710
    // 0x69b6b0: ldur            d0, [fp, #-0x60]
    // 0x69b6b4: ldur            x0, [fp, #-0x30]
    // 0x69b6b8: ldr             x16, [fp, #0x10]
    // 0x69b6bc: r30 = Instance__ListTileSlot
    //     0x69b6bc: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x69b6c0: ldr             lr, [lr, #0xd10]
    // 0x69b6c4: stp             lr, x16, [SP, #-0x10]!
    // 0x69b6c8: r0 = childForSlot()
    //     0x69b6c8: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b6cc: add             SP, SP, #0x10
    // 0x69b6d0: stur            x0, [fp, #-0x38]
    // 0x69b6d4: cmp             w0, NULL
    // 0x69b6d8: b.eq            #0x69ba14
    // 0x69b6dc: ldur            x1, [fp, #-0x30]
    // 0x69b6e0: cmp             w1, NULL
    // 0x69b6e4: b.eq            #0x69ba18
    // 0x69b6e8: r0 = Offset()
    //     0x69b6e8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69b6ec: ldur            d0, [fp, #-0x60]
    // 0x69b6f0: StoreField: r0->field_7 = d0
    //     0x69b6f0: stur            d0, [x0, #7]
    // 0x69b6f4: ldur            x3, [fp, #-0x30]
    // 0x69b6f8: LoadField: d0 = r3->field_7
    //     0x69b6f8: ldur            d0, [x3, #7]
    // 0x69b6fc: StoreField: r0->field_f = d0
    //     0x69b6fc: stur            d0, [x0, #0xf]
    // 0x69b700: ldur            x16, [fp, #-0x38]
    // 0x69b704: stp             x0, x16, [SP, #-0x10]!
    // 0x69b708: r0 = _positionBox()
    //     0x69b708: bl              #0x69ba34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0x69b70c: add             SP, SP, #0x10
    // 0x69b710: ldur            x4, [fp, #-0x20]
    // 0x69b714: tbnz            w4, #4, #0x69b900
    // 0x69b718: ldur            d0, [fp, #-0x88]
    // 0x69b71c: ldr             x16, [fp, #0x10]
    // 0x69b720: r30 = Instance__ListTileSlot
    //     0x69b720: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x69b724: ldr             lr, [lr, #0xd18]
    // 0x69b728: stp             lr, x16, [SP, #-0x10]!
    // 0x69b72c: r0 = childForSlot()
    //     0x69b72c: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b730: add             SP, SP, #0x10
    // 0x69b734: stur            x0, [fp, #-0x38]
    // 0x69b738: cmp             w0, NULL
    // 0x69b73c: b.eq            #0x69ba1c
    // 0x69b740: r0 = Offset()
    //     0x69b740: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69b744: d2 = 0.000000
    //     0x69b744: eor             v2.16b, v2.16b, v2.16b
    // 0x69b748: StoreField: r0->field_7 = d2
    //     0x69b748: stur            d2, [x0, #7]
    // 0x69b74c: ldur            d3, [fp, #-0x88]
    // 0x69b750: StoreField: r0->field_f = d3
    //     0x69b750: stur            d3, [x0, #0xf]
    // 0x69b754: ldur            x16, [fp, #-0x38]
    // 0x69b758: stp             x0, x16, [SP, #-0x10]!
    // 0x69b75c: r0 = _positionBox()
    //     0x69b75c: bl              #0x69ba34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0x69b760: add             SP, SP, #0x10
    // 0x69b764: b               #0x69b900
    // 0x69b768: ldur            x2, [fp, #-0x10]
    // 0x69b76c: ldur            x1, [fp, #-0x18]
    // 0x69b770: ldur            x4, [fp, #-0x20]
    // 0x69b774: ldur            d1, [fp, #-0x80]
    // 0x69b778: ldur            x3, [fp, #-0x30]
    // 0x69b77c: mov             v3.16b, v0.16b
    // 0x69b780: mov             v0.16b, v2.16b
    // 0x69b784: d2 = 0.000000
    //     0x69b784: eor             v2.16b, v2.16b, v2.16b
    // 0x69b788: tbnz            w2, #4, #0x69b7d4
    // 0x69b78c: ldr             x16, [fp, #0x10]
    // 0x69b790: r30 = Instance__ListTileSlot
    //     0x69b790: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d00] Obj!_ListTileSlot@b65611
    //     0x69b794: ldr             lr, [lr, #0xd00]
    // 0x69b798: stp             lr, x16, [SP, #-0x10]!
    // 0x69b79c: r0 = childForSlot()
    //     0x69b79c: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b7a0: add             SP, SP, #0x10
    // 0x69b7a4: stur            x0, [fp, #-0x10]
    // 0x69b7a8: cmp             w0, NULL
    // 0x69b7ac: b.eq            #0x69ba20
    // 0x69b7b0: r0 = Offset()
    //     0x69b7b0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69b7b4: d0 = 0.000000
    //     0x69b7b4: eor             v0.16b, v0.16b, v0.16b
    // 0x69b7b8: StoreField: r0->field_7 = d0
    //     0x69b7b8: stur            d0, [x0, #7]
    // 0x69b7bc: ldur            d0, [fp, #-0x70]
    // 0x69b7c0: StoreField: r0->field_f = d0
    //     0x69b7c0: stur            d0, [x0, #0xf]
    // 0x69b7c4: ldur            x16, [fp, #-0x10]
    // 0x69b7c8: stp             x0, x16, [SP, #-0x10]!
    // 0x69b7cc: r0 = _positionBox()
    //     0x69b7cc: bl              #0x69ba34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0x69b7d0: add             SP, SP, #0x10
    // 0x69b7d4: ldur            x0, [fp, #-0x18]
    // 0x69b7d8: ldur            d1, [fp, #-0x68]
    // 0x69b7dc: ldur            d0, [fp, #-0x80]
    // 0x69b7e0: ldr             x16, [fp, #0x10]
    // 0x69b7e4: r30 = Instance__ListTileSlot
    //     0x69b7e4: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d08] Obj!_ListTileSlot@b655f1
    //     0x69b7e8: ldr             lr, [lr, #0xd08]
    // 0x69b7ec: stp             lr, x16, [SP, #-0x10]!
    // 0x69b7f0: r0 = childForSlot()
    //     0x69b7f0: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b7f4: add             SP, SP, #0x10
    // 0x69b7f8: stur            x0, [fp, #-0x10]
    // 0x69b7fc: cmp             w0, NULL
    // 0x69b800: b.eq            #0x69ba24
    // 0x69b804: r0 = Offset()
    //     0x69b804: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69b808: ldur            d0, [fp, #-0x68]
    // 0x69b80c: StoreField: r0->field_7 = d0
    //     0x69b80c: stur            d0, [x0, #7]
    // 0x69b810: ldur            d1, [fp, #-0x80]
    // 0x69b814: StoreField: r0->field_f = d1
    //     0x69b814: stur            d1, [x0, #0xf]
    // 0x69b818: ldur            x16, [fp, #-0x10]
    // 0x69b81c: stp             x0, x16, [SP, #-0x10]!
    // 0x69b820: r0 = _positionBox()
    //     0x69b820: bl              #0x69ba34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0x69b824: add             SP, SP, #0x10
    // 0x69b828: ldur            x0, [fp, #-0x18]
    // 0x69b82c: tbnz            w0, #4, #0x69b890
    // 0x69b830: ldur            d0, [fp, #-0x68]
    // 0x69b834: ldur            x0, [fp, #-0x30]
    // 0x69b838: ldr             x16, [fp, #0x10]
    // 0x69b83c: r30 = Instance__ListTileSlot
    //     0x69b83c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d10] Obj!_ListTileSlot@b655d1
    //     0x69b840: ldr             lr, [lr, #0xd10]
    // 0x69b844: stp             lr, x16, [SP, #-0x10]!
    // 0x69b848: r0 = childForSlot()
    //     0x69b848: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b84c: add             SP, SP, #0x10
    // 0x69b850: stur            x0, [fp, #-0x10]
    // 0x69b854: cmp             w0, NULL
    // 0x69b858: b.eq            #0x69ba28
    // 0x69b85c: ldur            x1, [fp, #-0x30]
    // 0x69b860: cmp             w1, NULL
    // 0x69b864: b.eq            #0x69ba2c
    // 0x69b868: r0 = Offset()
    //     0x69b868: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69b86c: ldur            d0, [fp, #-0x68]
    // 0x69b870: StoreField: r0->field_7 = d0
    //     0x69b870: stur            d0, [x0, #7]
    // 0x69b874: ldur            x1, [fp, #-0x30]
    // 0x69b878: LoadField: d0 = r1->field_7
    //     0x69b878: ldur            d0, [x1, #7]
    // 0x69b87c: StoreField: r0->field_f = d0
    //     0x69b87c: stur            d0, [x0, #0xf]
    // 0x69b880: ldur            x16, [fp, #-0x10]
    // 0x69b884: stp             x0, x16, [SP, #-0x10]!
    // 0x69b888: r0 = _positionBox()
    //     0x69b888: bl              #0x69ba34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0x69b88c: add             SP, SP, #0x10
    // 0x69b890: ldur            x0, [fp, #-0x20]
    // 0x69b894: tbnz            w0, #4, #0x69b900
    // 0x69b898: ldur            d1, [fp, #-0x58]
    // 0x69b89c: ldur            x0, [fp, #-0x28]
    // 0x69b8a0: ldur            d0, [fp, #-0x88]
    // 0x69b8a4: ldr             x16, [fp, #0x10]
    // 0x69b8a8: r30 = Instance__ListTileSlot
    //     0x69b8a8: add             lr, PP, #0x56, lsl #12  ; [pp+0x56d18] Obj!_ListTileSlot@b655b1
    //     0x69b8ac: ldr             lr, [lr, #0xd18]
    // 0x69b8b0: stp             lr, x16, [SP, #-0x10]!
    // 0x69b8b4: r0 = childForSlot()
    //     0x69b8b4: bl              #0x628e1c  ; [package:flutter/src/material/input_decorator.dart] __RenderDecoration&RenderBox&SlottedContainerRenderObjectMixin::childForSlot
    // 0x69b8b8: add             SP, SP, #0x10
    // 0x69b8bc: stur            x0, [fp, #-0x10]
    // 0x69b8c0: cmp             w0, NULL
    // 0x69b8c4: b.eq            #0x69ba30
    // 0x69b8c8: ldur            x1, [fp, #-0x28]
    // 0x69b8cc: LoadField: d0 = r1->field_7
    //     0x69b8cc: ldur            d0, [x1, #7]
    // 0x69b8d0: ldur            d1, [fp, #-0x58]
    // 0x69b8d4: fsub            d2, d1, d0
    // 0x69b8d8: stur            d2, [fp, #-0x60]
    // 0x69b8dc: r0 = Offset()
    //     0x69b8dc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69b8e0: ldur            d0, [fp, #-0x60]
    // 0x69b8e4: StoreField: r0->field_7 = d0
    //     0x69b8e4: stur            d0, [x0, #7]
    // 0x69b8e8: ldur            d0, [fp, #-0x88]
    // 0x69b8ec: StoreField: r0->field_f = d0
    //     0x69b8ec: stur            d0, [x0, #0xf]
    // 0x69b8f0: ldur            x16, [fp, #-0x10]
    // 0x69b8f4: stp             x0, x16, [SP, #-0x10]!
    // 0x69b8f8: r0 = _positionBox()
    //     0x69b8f8: bl              #0x69ba34  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_positionBox
    // 0x69b8fc: add             SP, SP, #0x10
    // 0x69b900: ldr             x0, [fp, #0x10]
    // 0x69b904: ldur            d0, [fp, #-0x58]
    // 0x69b908: ldur            d1, [fp, #-0x78]
    // 0x69b90c: r0 = Size()
    //     0x69b90c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x69b910: ldur            d0, [fp, #-0x58]
    // 0x69b914: StoreField: r0->field_7 = d0
    //     0x69b914: stur            d0, [x0, #7]
    // 0x69b918: ldur            d0, [fp, #-0x78]
    // 0x69b91c: StoreField: r0->field_f = d0
    //     0x69b91c: stur            d0, [x0, #0xf]
    // 0x69b920: ldur            x16, [fp, #-8]
    // 0x69b924: stp             x0, x16, [SP, #-0x10]!
    // 0x69b928: r0 = constrain()
    //     0x69b928: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x69b92c: add             SP, SP, #0x10
    // 0x69b930: ldr             x1, [fp, #0x10]
    // 0x69b934: StoreField: r1->field_57 = r0
    //     0x69b934: stur            w0, [x1, #0x57]
    //     0x69b938: ldurb           w16, [x1, #-1]
    //     0x69b93c: ldurb           w17, [x0, #-1]
    //     0x69b940: and             x16, x17, x16, lsr #2
    //     0x69b944: tst             x16, HEAP, lsr #32
    //     0x69b948: b.eq            #0x69b950
    //     0x69b94c: bl              #0xd6826c
    // 0x69b950: r0 = Null
    //     0x69b950: mov             x0, NULL
    // 0x69b954: LeaveFrame
    //     0x69b954: mov             SP, fp
    //     0x69b958: ldp             fp, lr, [SP], #0x10
    // 0x69b95c: ret
    //     0x69b95c: ret             
    // 0x69b960: r0 = StateError()
    //     0x69b960: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x69b964: mov             x1, x0
    // 0x69b968: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x69b968: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x69b96c: ldr             x0, [x0, #0x1e8]
    // 0x69b970: StoreField: r1->field_b = r0
    //     0x69b970: stur            w0, [x1, #0xb]
    // 0x69b974: mov             x0, x1
    // 0x69b978: r0 = Throw()
    //     0x69b978: bl              #0xd67e38  ; ThrowStub
    // 0x69b97c: brk             #0
    // 0x69b980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69b980: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69b984: b               #0x69aea0
    // 0x69b988: stp             q4, q6, [SP, #-0x20]!
    // 0x69b98c: stp             q2, q3, [SP, #-0x20]!
    // 0x69b990: stp             q0, q1, [SP, #-0x20]!
    // 0x69b994: stp             x4, x5, [SP, #-0x10]!
    // 0x69b998: stp             x2, x3, [SP, #-0x10]!
    // 0x69b99c: stp             x0, x1, [SP, #-0x10]!
    // 0x69b9a0: r0 = AllocateDouble()
    //     0x69b9a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69b9a4: mov             x6, x0
    // 0x69b9a8: ldp             x0, x1, [SP], #0x10
    // 0x69b9ac: ldp             x2, x3, [SP], #0x10
    // 0x69b9b0: ldp             x4, x5, [SP], #0x10
    // 0x69b9b4: ldp             q0, q1, [SP], #0x20
    // 0x69b9b8: ldp             q2, q3, [SP], #0x20
    // 0x69b9bc: ldp             q4, q6, [SP], #0x20
    // 0x69b9c0: b               #0x69b1bc
    // 0x69b9c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69b9c4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69b9c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69b9c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69b9cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69b9cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69b9d0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69b9d0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69b9d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69b9d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69b9d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69b9d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69b9dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69b9dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69b9e0: stp             q3, q4, [SP, #-0x20]!
    // 0x69b9e4: stp             q1, q2, [SP, #-0x20]!
    // 0x69b9e8: SaveReg d0
    //     0x69b9e8: str             q0, [SP, #-0x10]!
    // 0x69b9ec: SaveReg r0
    //     0x69b9ec: str             x0, [SP, #-8]!
    // 0x69b9f0: r0 = AllocateDouble()
    //     0x69b9f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x69b9f4: mov             x1, x0
    // 0x69b9f8: RestoreReg r0
    //     0x69b9f8: ldr             x0, [SP], #8
    // 0x69b9fc: RestoreReg d0
    //     0x69b9fc: ldr             q0, [SP], #0x10
    // 0x69ba00: ldp             q1, q2, [SP], #0x20
    // 0x69ba04: ldp             q3, q4, [SP], #0x20
    // 0x69ba08: b               #0x69b4bc
    // 0x69ba0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69ba30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69ba30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _positionBox(/* No info */) {
    // ** addr: 0x69ba34, size: 0x90
    // 0x69ba34: EnterFrame
    //     0x69ba34: stp             fp, lr, [SP, #-0x10]!
    //     0x69ba38: mov             fp, SP
    // 0x69ba3c: AllocStack(0x8)
    //     0x69ba3c: sub             SP, SP, #8
    // 0x69ba40: ldr             x0, [fp, #0x18]
    // 0x69ba44: LoadField: r3 = r0->field_17
    //     0x69ba44: ldur            w3, [x0, #0x17]
    // 0x69ba48: DecompressPointer r3
    //     0x69ba48: add             x3, x3, HEAP, lsl #32
    // 0x69ba4c: stur            x3, [fp, #-8]
    // 0x69ba50: cmp             w3, NULL
    // 0x69ba54: b.eq            #0x69bac0
    // 0x69ba58: mov             x0, x3
    // 0x69ba5c: r2 = Null
    //     0x69ba5c: mov             x2, NULL
    // 0x69ba60: r1 = Null
    //     0x69ba60: mov             x1, NULL
    // 0x69ba64: r4 = LoadClassIdInstr(r0)
    //     0x69ba64: ldur            x4, [x0, #-1]
    //     0x69ba68: ubfx            x4, x4, #0xc, #0x14
    // 0x69ba6c: sub             x4, x4, #0x7ff
    // 0x69ba70: cmp             x4, #0xb
    // 0x69ba74: b.ls            #0x69ba8c
    // 0x69ba78: r8 = BoxParentData
    //     0x69ba78: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x69ba7c: ldr             x8, [x8, #0x1b0]
    // 0x69ba80: r3 = Null
    //     0x69ba80: add             x3, PP, #0x56, lsl #12  ; [pp+0x56de0] Null
    //     0x69ba84: ldr             x3, [x3, #0xde0]
    // 0x69ba88: r0 = DefaultTypeTest()
    //     0x69ba88: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x69ba8c: ldr             x0, [fp, #0x10]
    // 0x69ba90: ldur            x1, [fp, #-8]
    // 0x69ba94: StoreField: r1->field_7 = r0
    //     0x69ba94: stur            w0, [x1, #7]
    //     0x69ba98: ldurb           w16, [x1, #-1]
    //     0x69ba9c: ldurb           w17, [x0, #-1]
    //     0x69baa0: and             x16, x17, x16, lsr #2
    //     0x69baa4: tst             x16, HEAP, lsr #32
    //     0x69baa8: b.eq            #0x69bab0
    //     0x69baac: bl              #0xd6826c
    // 0x69bab0: r0 = Null
    //     0x69bab0: mov             x0, NULL
    // 0x69bab4: LeaveFrame
    //     0x69bab4: mov             SP, fp
    //     0x69bab8: ldp             fp, lr, [SP], #0x10
    // 0x69babc: ret
    //     0x69babc: ret             
    // 0x69bac0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69bac0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _layoutBox(/* No info */) {
    // ** addr: 0x69bac4, size: 0x90
    // 0x69bac4: EnterFrame
    //     0x69bac4: stp             fp, lr, [SP, #-0x10]!
    //     0x69bac8: mov             fp, SP
    // 0x69bacc: CheckStackOverflow
    //     0x69bacc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69bad0: cmp             SP, x16
    //     0x69bad4: b.ls            #0x69bb48
    // 0x69bad8: ldr             x1, [fp, #0x18]
    // 0x69badc: cmp             w1, NULL
    // 0x69bae0: b.ne            #0x69baf4
    // 0x69bae4: r0 = Instance_Size
    //     0x69bae4: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x69bae8: LeaveFrame
    //     0x69bae8: mov             SP, fp
    //     0x69baec: ldp             fp, lr, [SP], #0x10
    // 0x69baf0: ret
    //     0x69baf0: ret             
    // 0x69baf4: r0 = LoadClassIdInstr(r1)
    //     0x69baf4: ldur            x0, [x1, #-1]
    //     0x69baf8: ubfx            x0, x0, #0xc, #0x14
    // 0x69bafc: ldr             x16, [fp, #0x10]
    // 0x69bb00: stp             x16, x1, [SP, #-0x10]!
    // 0x69bb04: r16 = true
    //     0x69bb04: add             x16, NULL, #0x20  ; true
    // 0x69bb08: SaveReg r16
    //     0x69bb08: str             x16, [SP, #-8]!
    // 0x69bb0c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x69bb0c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x69bb10: ldr             x4, [x4, #0x1c8]
    // 0x69bb14: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x69bb14: mov             x17, #0xcdfb
    //     0x69bb18: add             lr, x0, x17
    //     0x69bb1c: ldr             lr, [x21, lr, lsl #3]
    //     0x69bb20: blr             lr
    // 0x69bb24: add             SP, SP, #0x18
    // 0x69bb28: ldr             x1, [fp, #0x18]
    // 0x69bb2c: LoadField: r0 = r1->field_57
    //     0x69bb2c: ldur            w0, [x1, #0x57]
    // 0x69bb30: DecompressPointer r0
    //     0x69bb30: add             x0, x0, HEAP, lsl #32
    // 0x69bb34: cmp             w0, NULL
    // 0x69bb38: b.eq            #0x69bb50
    // 0x69bb3c: LeaveFrame
    //     0x69bb3c: mov             SP, fp
    //     0x69bb40: ldp             fp, lr, [SP], #0x10
    // 0x69bb44: ret
    //     0x69bb44: ret             
    // 0x69bb48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x69bb48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69bb4c: b               #0x69bad8
    // 0x69bb50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69bb50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ minVerticalPadding=(/* No info */) {
    // ** addr: 0x6e0ce4, size: 0x64
    // 0x6e0ce4: EnterFrame
    //     0x6e0ce4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e0ce8: mov             fp, SP
    // 0x6e0cec: CheckStackOverflow
    //     0x6e0cec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0cf0: cmp             SP, x16
    //     0x6e0cf4: b.ls            #0x6e0d40
    // 0x6e0cf8: ldr             x0, [fp, #0x18]
    // 0x6e0cfc: LoadField: d0 = r0->field_83
    //     0x6e0cfc: ldur            d0, [x0, #0x83]
    // 0x6e0d00: ldr             d1, [fp, #0x10]
    // 0x6e0d04: fcmp            d0, d1
    // 0x6e0d08: b.vs            #0x6e0d20
    // 0x6e0d0c: b.ne            #0x6e0d20
    // 0x6e0d10: r0 = Null
    //     0x6e0d10: mov             x0, NULL
    // 0x6e0d14: LeaveFrame
    //     0x6e0d14: mov             SP, fp
    //     0x6e0d18: ldp             fp, lr, [SP], #0x10
    // 0x6e0d1c: ret
    //     0x6e0d1c: ret             
    // 0x6e0d20: StoreField: r0->field_83 = d1
    //     0x6e0d20: stur            d1, [x0, #0x83]
    // 0x6e0d24: SaveReg r0
    //     0x6e0d24: str             x0, [SP, #-8]!
    // 0x6e0d28: r0 = markNeedsLayout()
    //     0x6e0d28: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e0d2c: add             SP, SP, #8
    // 0x6e0d30: r0 = Null
    //     0x6e0d30: mov             x0, NULL
    // 0x6e0d34: LeaveFrame
    //     0x6e0d34: mov             SP, fp
    //     0x6e0d38: ldp             fp, lr, [SP], #0x10
    // 0x6e0d3c: ret
    //     0x6e0d3c: ret             
    // 0x6e0d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e0d40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e0d44: b               #0x6e0cf8
  }
  set _ titleBaselineType=(/* No info */) {
    // ** addr: 0x6e0dac, size: 0x80
    // 0x6e0dac: EnterFrame
    //     0x6e0dac: stp             fp, lr, [SP, #-0x10]!
    //     0x6e0db0: mov             fp, SP
    // 0x6e0db4: CheckStackOverflow
    //     0x6e0db4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0db8: cmp             SP, x16
    //     0x6e0dbc: b.ls            #0x6e0e24
    // 0x6e0dc0: ldr             x1, [fp, #0x18]
    // 0x6e0dc4: LoadField: r0 = r1->field_73
    //     0x6e0dc4: ldur            w0, [x1, #0x73]
    // 0x6e0dc8: DecompressPointer r0
    //     0x6e0dc8: add             x0, x0, HEAP, lsl #32
    // 0x6e0dcc: ldr             x2, [fp, #0x10]
    // 0x6e0dd0: cmp             w0, w2
    // 0x6e0dd4: b.ne            #0x6e0de8
    // 0x6e0dd8: r0 = Null
    //     0x6e0dd8: mov             x0, NULL
    // 0x6e0ddc: LeaveFrame
    //     0x6e0ddc: mov             SP, fp
    //     0x6e0de0: ldp             fp, lr, [SP], #0x10
    // 0x6e0de4: ret
    //     0x6e0de4: ret             
    // 0x6e0de8: mov             x0, x2
    // 0x6e0dec: StoreField: r1->field_73 = r0
    //     0x6e0dec: stur            w0, [x1, #0x73]
    //     0x6e0df0: ldurb           w16, [x1, #-1]
    //     0x6e0df4: ldurb           w17, [x0, #-1]
    //     0x6e0df8: and             x16, x17, x16, lsr #2
    //     0x6e0dfc: tst             x16, HEAP, lsr #32
    //     0x6e0e00: b.eq            #0x6e0e08
    //     0x6e0e04: bl              #0xd6826c
    // 0x6e0e08: SaveReg r1
    //     0x6e0e08: str             x1, [SP, #-8]!
    // 0x6e0e0c: r0 = markNeedsLayout()
    //     0x6e0e0c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e0e10: add             SP, SP, #8
    // 0x6e0e14: r0 = Null
    //     0x6e0e14: mov             x0, NULL
    // 0x6e0e18: LeaveFrame
    //     0x6e0e18: mov             SP, fp
    //     0x6e0e1c: ldp             fp, lr, [SP], #0x10
    // 0x6e0e20: ret
    //     0x6e0e20: ret             
    // 0x6e0e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e0e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e0e28: b               #0x6e0dc0
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6e0e2c, size: 0x80
    // 0x6e0e2c: EnterFrame
    //     0x6e0e2c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e0e30: mov             fp, SP
    // 0x6e0e34: CheckStackOverflow
    //     0x6e0e34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0e38: cmp             SP, x16
    //     0x6e0e3c: b.ls            #0x6e0ea4
    // 0x6e0e40: ldr             x1, [fp, #0x18]
    // 0x6e0e44: LoadField: r0 = r1->field_6f
    //     0x6e0e44: ldur            w0, [x1, #0x6f]
    // 0x6e0e48: DecompressPointer r0
    //     0x6e0e48: add             x0, x0, HEAP, lsl #32
    // 0x6e0e4c: ldr             x2, [fp, #0x10]
    // 0x6e0e50: cmp             w0, w2
    // 0x6e0e54: b.ne            #0x6e0e68
    // 0x6e0e58: r0 = Null
    //     0x6e0e58: mov             x0, NULL
    // 0x6e0e5c: LeaveFrame
    //     0x6e0e5c: mov             SP, fp
    //     0x6e0e60: ldp             fp, lr, [SP], #0x10
    // 0x6e0e64: ret
    //     0x6e0e64: ret             
    // 0x6e0e68: mov             x0, x2
    // 0x6e0e6c: StoreField: r1->field_6f = r0
    //     0x6e0e6c: stur            w0, [x1, #0x6f]
    //     0x6e0e70: ldurb           w16, [x1, #-1]
    //     0x6e0e74: ldurb           w17, [x0, #-1]
    //     0x6e0e78: and             x16, x17, x16, lsr #2
    //     0x6e0e7c: tst             x16, HEAP, lsr #32
    //     0x6e0e80: b.eq            #0x6e0e88
    //     0x6e0e84: bl              #0xd6826c
    // 0x6e0e88: SaveReg r1
    //     0x6e0e88: str             x1, [SP, #-8]!
    // 0x6e0e8c: r0 = markNeedsLayout()
    //     0x6e0e8c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e0e90: add             SP, SP, #8
    // 0x6e0e94: r0 = Null
    //     0x6e0e94: mov             x0, NULL
    // 0x6e0e98: LeaveFrame
    //     0x6e0e98: mov             SP, fp
    //     0x6e0e9c: ldp             fp, lr, [SP], #0x10
    // 0x6e0ea0: ret
    //     0x6e0ea0: ret             
    // 0x6e0ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e0ea4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e0ea8: b               #0x6e0e40
  }
  set _ subtitleBaselineType=(/* No info */) {
    // ** addr: 0x6e4ea4, size: 0x80
    // 0x6e4ea4: EnterFrame
    //     0x6e4ea4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e4ea8: mov             fp, SP
    // 0x6e4eac: CheckStackOverflow
    //     0x6e4eac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e4eb0: cmp             SP, x16
    //     0x6e4eb4: b.ls            #0x6e4f1c
    // 0x6e4eb8: ldr             x1, [fp, #0x18]
    // 0x6e4ebc: LoadField: r0 = r1->field_77
    //     0x6e4ebc: ldur            w0, [x1, #0x77]
    // 0x6e4ec0: DecompressPointer r0
    //     0x6e4ec0: add             x0, x0, HEAP, lsl #32
    // 0x6e4ec4: ldr             x2, [fp, #0x10]
    // 0x6e4ec8: cmp             w0, w2
    // 0x6e4ecc: b.ne            #0x6e4ee0
    // 0x6e4ed0: r0 = Null
    //     0x6e4ed0: mov             x0, NULL
    // 0x6e4ed4: LeaveFrame
    //     0x6e4ed4: mov             SP, fp
    //     0x6e4ed8: ldp             fp, lr, [SP], #0x10
    // 0x6e4edc: ret
    //     0x6e4edc: ret             
    // 0x6e4ee0: mov             x0, x2
    // 0x6e4ee4: StoreField: r1->field_77 = r0
    //     0x6e4ee4: stur            w0, [x1, #0x77]
    //     0x6e4ee8: ldurb           w16, [x1, #-1]
    //     0x6e4eec: ldurb           w17, [x0, #-1]
    //     0x6e4ef0: and             x16, x17, x16, lsr #2
    //     0x6e4ef4: tst             x16, HEAP, lsr #32
    //     0x6e4ef8: b.eq            #0x6e4f00
    //     0x6e4efc: bl              #0xd6826c
    // 0x6e4f00: SaveReg r1
    //     0x6e4f00: str             x1, [SP, #-8]!
    // 0x6e4f04: r0 = markNeedsLayout()
    //     0x6e4f04: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e4f08: add             SP, SP, #8
    // 0x6e4f0c: r0 = Null
    //     0x6e4f0c: mov             x0, NULL
    // 0x6e4f10: LeaveFrame
    //     0x6e4f10: mov             SP, fp
    //     0x6e4f14: ldp             fp, lr, [SP], #0x10
    // 0x6e4f18: ret
    //     0x6e4f18: ret             
    // 0x6e4f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e4f1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e4f20: b               #0x6e4eb8
  }
  set _ minLeadingWidth=(/* No info */) {
    // ** addr: 0x6e5fc4, size: 0x64
    // 0x6e5fc4: EnterFrame
    //     0x6e5fc4: stp             fp, lr, [SP, #-0x10]!
    //     0x6e5fc8: mov             fp, SP
    // 0x6e5fcc: CheckStackOverflow
    //     0x6e5fcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e5fd0: cmp             SP, x16
    //     0x6e5fd4: b.ls            #0x6e6020
    // 0x6e5fd8: ldr             x0, [fp, #0x18]
    // 0x6e5fdc: LoadField: d0 = r0->field_8b
    //     0x6e5fdc: ldur            d0, [x0, #0x8b]
    // 0x6e5fe0: ldr             d1, [fp, #0x10]
    // 0x6e5fe4: fcmp            d0, d1
    // 0x6e5fe8: b.vs            #0x6e6000
    // 0x6e5fec: b.ne            #0x6e6000
    // 0x6e5ff0: r0 = Null
    //     0x6e5ff0: mov             x0, NULL
    // 0x6e5ff4: LeaveFrame
    //     0x6e5ff4: mov             SP, fp
    //     0x6e5ff8: ldp             fp, lr, [SP], #0x10
    // 0x6e5ffc: ret
    //     0x6e5ffc: ret             
    // 0x6e6000: StoreField: r0->field_8b = d1
    //     0x6e6000: stur            d1, [x0, #0x8b]
    // 0x6e6004: SaveReg r0
    //     0x6e6004: str             x0, [SP, #-8]!
    // 0x6e6008: r0 = markNeedsLayout()
    //     0x6e6008: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e600c: add             SP, SP, #8
    // 0x6e6010: r0 = Null
    //     0x6e6010: mov             x0, NULL
    // 0x6e6014: LeaveFrame
    //     0x6e6014: mov             SP, fp
    //     0x6e6018: ldp             fp, lr, [SP], #0x10
    // 0x6e601c: ret
    //     0x6e601c: ret             
    // 0x6e6020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e6020: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e6024: b               #0x6e5fd8
  }
  set _ horizontalTitleGap=(/* No info */) {
    // ** addr: 0x6e6028, size: 0x64
    // 0x6e6028: EnterFrame
    //     0x6e6028: stp             fp, lr, [SP, #-0x10]!
    //     0x6e602c: mov             fp, SP
    // 0x6e6030: CheckStackOverflow
    //     0x6e6030: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e6034: cmp             SP, x16
    //     0x6e6038: b.ls            #0x6e6084
    // 0x6e603c: ldr             x0, [fp, #0x18]
    // 0x6e6040: LoadField: d0 = r0->field_7b
    //     0x6e6040: ldur            d0, [x0, #0x7b]
    // 0x6e6044: ldr             d1, [fp, #0x10]
    // 0x6e6048: fcmp            d0, d1
    // 0x6e604c: b.vs            #0x6e6064
    // 0x6e6050: b.ne            #0x6e6064
    // 0x6e6054: r0 = Null
    //     0x6e6054: mov             x0, NULL
    // 0x6e6058: LeaveFrame
    //     0x6e6058: mov             SP, fp
    //     0x6e605c: ldp             fp, lr, [SP], #0x10
    // 0x6e6060: ret
    //     0x6e6060: ret             
    // 0x6e6064: StoreField: r0->field_7b = d1
    //     0x6e6064: stur            d1, [x0, #0x7b]
    // 0x6e6068: SaveReg r0
    //     0x6e6068: str             x0, [SP, #-8]!
    // 0x6e606c: r0 = markNeedsLayout()
    //     0x6e606c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e6070: add             SP, SP, #8
    // 0x6e6074: r0 = Null
    //     0x6e6074: mov             x0, NULL
    // 0x6e6078: LeaveFrame
    //     0x6e6078: mov             SP, fp
    //     0x6e607c: ldp             fp, lr, [SP], #0x10
    // 0x6e6080: ret
    //     0x6e6080: ret             
    // 0x6e6084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e6084: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e6088: b               #0x6e603c
  }
  set _ visualDensity=(/* No info */) {
    // ** addr: 0x6e608c, size: 0xd8
    // 0x6e608c: EnterFrame
    //     0x6e608c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e6090: mov             fp, SP
    // 0x6e6094: AllocStack(0x8)
    //     0x6e6094: sub             SP, SP, #8
    // 0x6e6098: CheckStackOverflow
    //     0x6e6098: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e609c: cmp             SP, x16
    //     0x6e60a0: b.ls            #0x6e615c
    // 0x6e60a4: ldr             x0, [fp, #0x18]
    // 0x6e60a8: LoadField: r1 = r0->field_67
    //     0x6e60a8: ldur            w1, [x0, #0x67]
    // 0x6e60ac: DecompressPointer r1
    //     0x6e60ac: add             x1, x1, HEAP, lsl #32
    // 0x6e60b0: stur            x1, [fp, #-8]
    // 0x6e60b4: r16 = VisualDensity
    //     0x6e60b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf10] Type: VisualDensity
    //     0x6e60b8: ldr             x16, [x16, #0xf10]
    // 0x6e60bc: r30 = VisualDensity
    //     0x6e60bc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf10] Type: VisualDensity
    //     0x6e60c0: ldr             lr, [lr, #0xf10]
    // 0x6e60c4: stp             lr, x16, [SP, #-0x10]!
    // 0x6e60c8: r0 = ==()
    //     0x6e60c8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6e60cc: add             SP, SP, #0x10
    // 0x6e60d0: tbz             w0, #4, #0x6e60dc
    // 0x6e60d4: ldr             x1, [fp, #0x10]
    // 0x6e60d8: b               #0x6e611c
    // 0x6e60dc: ldr             x1, [fp, #0x10]
    // 0x6e60e0: ldur            x0, [fp, #-8]
    // 0x6e60e4: LoadField: d0 = r1->field_7
    //     0x6e60e4: ldur            d0, [x1, #7]
    // 0x6e60e8: LoadField: d1 = r0->field_7
    //     0x6e60e8: ldur            d1, [x0, #7]
    // 0x6e60ec: fcmp            d0, d1
    // 0x6e60f0: b.vs            #0x6e611c
    // 0x6e60f4: b.ne            #0x6e611c
    // 0x6e60f8: LoadField: d0 = r1->field_f
    //     0x6e60f8: ldur            d0, [x1, #0xf]
    // 0x6e60fc: LoadField: d1 = r0->field_f
    //     0x6e60fc: ldur            d1, [x0, #0xf]
    // 0x6e6100: fcmp            d0, d1
    // 0x6e6104: b.vs            #0x6e611c
    // 0x6e6108: b.ne            #0x6e611c
    // 0x6e610c: r0 = Null
    //     0x6e610c: mov             x0, NULL
    // 0x6e6110: LeaveFrame
    //     0x6e6110: mov             SP, fp
    //     0x6e6114: ldp             fp, lr, [SP], #0x10
    // 0x6e6118: ret
    //     0x6e6118: ret             
    // 0x6e611c: ldr             x2, [fp, #0x18]
    // 0x6e6120: mov             x0, x1
    // 0x6e6124: StoreField: r2->field_67 = r0
    //     0x6e6124: stur            w0, [x2, #0x67]
    //     0x6e6128: ldurb           w16, [x2, #-1]
    //     0x6e612c: ldurb           w17, [x0, #-1]
    //     0x6e6130: and             x16, x17, x16, lsr #2
    //     0x6e6134: tst             x16, HEAP, lsr #32
    //     0x6e6138: b.eq            #0x6e6140
    //     0x6e613c: bl              #0xd6828c
    // 0x6e6140: SaveReg r2
    //     0x6e6140: str             x2, [SP, #-8]!
    // 0x6e6144: r0 = markNeedsLayout()
    //     0x6e6144: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e6148: add             SP, SP, #8
    // 0x6e614c: r0 = Null
    //     0x6e614c: mov             x0, NULL
    // 0x6e6150: LeaveFrame
    //     0x6e6150: mov             SP, fp
    //     0x6e6154: ldp             fp, lr, [SP], #0x10
    // 0x6e6158: ret
    //     0x6e6158: ret             
    // 0x6e615c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e615c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e6160: b               #0x6e60a4
  }
  _ _RenderListTile(/* No info */) {
    // ** addr: 0x6f5738, size: 0x124
    // 0x6f5738: EnterFrame
    //     0x6f5738: stp             fp, lr, [SP, #-0x10]!
    //     0x6f573c: mov             fp, SP
    // 0x6f5740: r1 = false
    //     0x6f5740: add             x1, NULL, #0x30  ; false
    // 0x6f5744: CheckStackOverflow
    //     0x6f5744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5748: cmp             SP, x16
    //     0x6f574c: b.ls            #0x6f5854
    // 0x6f5750: ldr             x2, [fp, #0x48]
    // 0x6f5754: StoreField: r2->field_63 = r1
    //     0x6f5754: stur            w1, [x2, #0x63]
    // 0x6f5758: ldr             x0, [fp, #0x10]
    // 0x6f575c: StoreField: r2->field_67 = r0
    //     0x6f575c: stur            w0, [x2, #0x67]
    //     0x6f5760: ldurb           w16, [x2, #-1]
    //     0x6f5764: ldurb           w17, [x0, #-1]
    //     0x6f5768: and             x16, x17, x16, lsr #2
    //     0x6f576c: tst             x16, HEAP, lsr #32
    //     0x6f5770: b.eq            #0x6f5778
    //     0x6f5774: bl              #0xd6828c
    // 0x6f5778: StoreField: r2->field_6b = r1
    //     0x6f5778: stur            w1, [x2, #0x6b]
    // 0x6f577c: ldr             x0, [fp, #0x20]
    // 0x6f5780: StoreField: r2->field_6f = r0
    //     0x6f5780: stur            w0, [x2, #0x6f]
    //     0x6f5784: ldurb           w16, [x2, #-1]
    //     0x6f5788: ldurb           w17, [x0, #-1]
    //     0x6f578c: and             x16, x17, x16, lsr #2
    //     0x6f5790: tst             x16, HEAP, lsr #32
    //     0x6f5794: b.eq            #0x6f579c
    //     0x6f5798: bl              #0xd6828c
    // 0x6f579c: ldr             x0, [fp, #0x18]
    // 0x6f57a0: StoreField: r2->field_73 = r0
    //     0x6f57a0: stur            w0, [x2, #0x73]
    //     0x6f57a4: ldurb           w16, [x2, #-1]
    //     0x6f57a8: ldurb           w17, [x0, #-1]
    //     0x6f57ac: and             x16, x17, x16, lsr #2
    //     0x6f57b0: tst             x16, HEAP, lsr #32
    //     0x6f57b4: b.eq            #0x6f57bc
    //     0x6f57b8: bl              #0xd6828c
    // 0x6f57bc: ldr             x0, [fp, #0x28]
    // 0x6f57c0: StoreField: r2->field_77 = r0
    //     0x6f57c0: stur            w0, [x2, #0x77]
    //     0x6f57c4: ldurb           w16, [x2, #-1]
    //     0x6f57c8: ldurb           w17, [x0, #-1]
    //     0x6f57cc: and             x16, x17, x16, lsr #2
    //     0x6f57d0: tst             x16, HEAP, lsr #32
    //     0x6f57d4: b.eq            #0x6f57dc
    //     0x6f57d8: bl              #0xd6828c
    // 0x6f57dc: ldr             x0, [fp, #0x40]
    // 0x6f57e0: LoadField: d0 = r0->field_7
    //     0x6f57e0: ldur            d0, [x0, #7]
    // 0x6f57e4: StoreField: r2->field_7b = d0
    //     0x6f57e4: stur            d0, [x2, #0x7b]
    // 0x6f57e8: ldr             d0, [fp, #0x30]
    // 0x6f57ec: StoreField: r2->field_83 = d0
    //     0x6f57ec: stur            d0, [x2, #0x83]
    // 0x6f57f0: ldr             x0, [fp, #0x38]
    // 0x6f57f4: LoadField: d0 = r0->field_7
    //     0x6f57f4: ldur            d0, [x0, #7]
    // 0x6f57f8: StoreField: r2->field_8b = d0
    //     0x6f57f8: stur            d0, [x2, #0x8b]
    // 0x6f57fc: r16 = <_ListTileSlot, RenderBox>
    //     0x6f57fc: add             x16, PP, #0x56, lsl #12  ; [pp+0x564a0] TypeArguments: <_ListTileSlot, RenderBox>
    //     0x6f5800: ldr             x16, [x16, #0x4a0]
    // 0x6f5804: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6f5808: stp             lr, x16, [SP, #-0x10]!
    // 0x6f580c: r0 = Map._fromLiteral()
    //     0x6f580c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6f5810: add             SP, SP, #0x10
    // 0x6f5814: ldr             x1, [fp, #0x48]
    // 0x6f5818: StoreField: r1->field_5f = r0
    //     0x6f5818: stur            w0, [x1, #0x5f]
    //     0x6f581c: tbz             w0, #0, #0x6f5838
    //     0x6f5820: ldurb           w16, [x1, #-1]
    //     0x6f5824: ldurb           w17, [x0, #-1]
    //     0x6f5828: and             x16, x17, x16, lsr #2
    //     0x6f582c: tst             x16, HEAP, lsr #32
    //     0x6f5830: b.eq            #0x6f5838
    //     0x6f5834: bl              #0xd6826c
    // 0x6f5838: SaveReg r1
    //     0x6f5838: str             x1, [SP, #-8]!
    // 0x6f583c: r0 = RenderObject()
    //     0x6f583c: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f5840: add             SP, SP, #8
    // 0x6f5844: r0 = Null
    //     0x6f5844: mov             x0, NULL
    // 0x6f5848: LeaveFrame
    //     0x6f5848: mov             SP, fp
    //     0x6f584c: ldp             fp, lr, [SP], #0x10
    // 0x6f5850: ret
    //     0x6f5850: ret             
    // 0x6f5854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f5854: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5858: b               #0x6f5750
  }
}

// class id: 3564, size: 0xc, field offset: 0xc
//   const constructor, transformed mixin,
abstract class __ListTile&RenderObjectWidget&SlottedMultiChildRenderObjectWidgetMixin extends RenderObjectWidget
     with SlottedMultiChildRenderObjectWidgetMixin<X0> {

  _ createElement(/* No info */) {
    // ** addr: 0xa77228, size: 0x50
    // 0xa77228: EnterFrame
    //     0xa77228: stp             fp, lr, [SP, #-0x10]!
    //     0xa7722c: mov             fp, SP
    // 0xa77230: AllocStack(0x8)
    //     0xa77230: sub             SP, SP, #8
    // 0xa77234: CheckStackOverflow
    //     0xa77234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa77238: cmp             SP, x16
    //     0xa7723c: b.ls            #0xa77270
    // 0xa77240: r1 = <_ListTileSlot>
    //     0xa77240: add             x1, PP, #0x56, lsl #12  ; [pp+0x564c8] TypeArguments: <_ListTileSlot>
    //     0xa77244: ldr             x1, [x1, #0x4c8]
    // 0xa77248: r0 = SlottedRenderObjectElement()
    //     0xa77248: bl              #0xa7721c  ; AllocateSlottedRenderObjectElementStub -> SlottedRenderObjectElement<X0> (size=0x50)
    // 0xa7724c: stur            x0, [fp, #-8]
    // 0xa77250: ldr             x16, [fp, #0x10]
    // 0xa77254: stp             x16, x0, [SP, #-0x10]!
    // 0xa77258: r0 = SlottedRenderObjectElement()
    //     0xa77258: bl              #0xa77118  ; [package:flutter/src/widgets/slotted_render_object_widget.dart] SlottedRenderObjectElement::SlottedRenderObjectElement
    // 0xa7725c: add             SP, SP, #0x10
    // 0xa77260: ldur            x0, [fp, #-8]
    // 0xa77264: LeaveFrame
    //     0xa77264: mov             SP, fp
    //     0xa77268: ldp             fp, lr, [SP], #0x10
    // 0xa7726c: ret
    //     0xa7726c: ret             
    // 0xa77270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa77270: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa77274: b               #0xa77240
  }
}

// class id: 3565, size: 0x4c, field offset: 0xc
//   const constructor, 
class _ListTile extends __ListTile&RenderObjectWidget&SlottedMultiChildRenderObjectWidgetMixin {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6e5e74, size: 0x150
    // 0x6e5e74: EnterFrame
    //     0x6e5e74: stp             fp, lr, [SP, #-0x10]!
    //     0x6e5e78: mov             fp, SP
    // 0x6e5e7c: CheckStackOverflow
    //     0x6e5e7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e5e80: cmp             SP, x16
    //     0x6e5e84: b.ls            #0x6e5fbc
    // 0x6e5e88: ldr             x0, [fp, #0x10]
    // 0x6e5e8c: r2 = Null
    //     0x6e5e8c: mov             x2, NULL
    // 0x6e5e90: r1 = Null
    //     0x6e5e90: mov             x1, NULL
    // 0x6e5e94: r4 = 59
    //     0x6e5e94: mov             x4, #0x3b
    // 0x6e5e98: branchIfSmi(r0, 0x6e5ea4)
    //     0x6e5e98: tbz             w0, #0, #0x6e5ea4
    // 0x6e5e9c: r4 = LoadClassIdInstr(r0)
    //     0x6e5e9c: ldur            x4, [x0, #-1]
    //     0x6e5ea0: ubfx            x4, x4, #0xc, #0x14
    // 0x6e5ea4: cmp             x4, #0x98d
    // 0x6e5ea8: b.eq            #0x6e5ec0
    // 0x6e5eac: r8 = _RenderListTile
    //     0x6e5eac: add             x8, PP, #0x56, lsl #12  ; [pp+0x56488] Type: _RenderListTile
    //     0x6e5eb0: ldr             x8, [x8, #0x488]
    // 0x6e5eb4: r3 = Null
    //     0x6e5eb4: add             x3, PP, #0x56, lsl #12  ; [pp+0x56490] Null
    //     0x6e5eb8: ldr             x3, [x3, #0x490]
    // 0x6e5ebc: r0 = DefaultTypeTest()
    //     0x6e5ebc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6e5ec0: ldr             x16, [fp, #0x10]
    // 0x6e5ec4: r30 = false
    //     0x6e5ec4: add             lr, NULL, #0x30  ; false
    // 0x6e5ec8: stp             lr, x16, [SP, #-0x10]!
    // 0x6e5ecc: r0 = Shader._()
    //     0x6e5ecc: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6e5ed0: add             SP, SP, #0x10
    // 0x6e5ed4: ldr             x16, [fp, #0x10]
    // 0x6e5ed8: r30 = false
    //     0x6e5ed8: add             lr, NULL, #0x30  ; false
    // 0x6e5edc: stp             lr, x16, [SP, #-0x10]!
    // 0x6e5ee0: r0 = Shader._()
    //     0x6e5ee0: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6e5ee4: add             SP, SP, #0x10
    // 0x6e5ee8: ldr             x0, [fp, #0x20]
    // 0x6e5eec: LoadField: r1 = r0->field_23
    //     0x6e5eec: ldur            w1, [x0, #0x23]
    // 0x6e5ef0: DecompressPointer r1
    //     0x6e5ef0: add             x1, x1, HEAP, lsl #32
    // 0x6e5ef4: ldr             x16, [fp, #0x10]
    // 0x6e5ef8: stp             x1, x16, [SP, #-0x10]!
    // 0x6e5efc: r0 = visualDensity=()
    //     0x6e5efc: bl              #0x6e608c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::visualDensity=
    // 0x6e5f00: add             SP, SP, #0x10
    // 0x6e5f04: ldr             x0, [fp, #0x20]
    // 0x6e5f08: LoadField: r1 = r0->field_27
    //     0x6e5f08: ldur            w1, [x0, #0x27]
    // 0x6e5f0c: DecompressPointer r1
    //     0x6e5f0c: add             x1, x1, HEAP, lsl #32
    // 0x6e5f10: ldr             x16, [fp, #0x10]
    // 0x6e5f14: stp             x1, x16, [SP, #-0x10]!
    // 0x6e5f18: r0 = textDirection=()
    //     0x6e5f18: bl              #0x6e0e2c  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::textDirection=
    // 0x6e5f1c: add             SP, SP, #0x10
    // 0x6e5f20: ldr             x0, [fp, #0x20]
    // 0x6e5f24: LoadField: r1 = r0->field_2b
    //     0x6e5f24: ldur            w1, [x0, #0x2b]
    // 0x6e5f28: DecompressPointer r1
    //     0x6e5f28: add             x1, x1, HEAP, lsl #32
    // 0x6e5f2c: ldr             x16, [fp, #0x10]
    // 0x6e5f30: stp             x1, x16, [SP, #-0x10]!
    // 0x6e5f34: r0 = titleBaselineType=()
    //     0x6e5f34: bl              #0x6e0dac  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::titleBaselineType=
    // 0x6e5f38: add             SP, SP, #0x10
    // 0x6e5f3c: ldr             x0, [fp, #0x20]
    // 0x6e5f40: LoadField: r1 = r0->field_2f
    //     0x6e5f40: ldur            w1, [x0, #0x2f]
    // 0x6e5f44: DecompressPointer r1
    //     0x6e5f44: add             x1, x1, HEAP, lsl #32
    // 0x6e5f48: ldr             x16, [fp, #0x10]
    // 0x6e5f4c: stp             x1, x16, [SP, #-0x10]!
    // 0x6e5f50: r0 = subtitleBaselineType=()
    //     0x6e5f50: bl              #0x6e4ea4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::subtitleBaselineType=
    // 0x6e5f54: add             SP, SP, #0x10
    // 0x6e5f58: ldr             x0, [fp, #0x20]
    // 0x6e5f5c: LoadField: d0 = r0->field_33
    //     0x6e5f5c: ldur            d0, [x0, #0x33]
    // 0x6e5f60: ldr             x16, [fp, #0x10]
    // 0x6e5f64: SaveReg r16
    //     0x6e5f64: str             x16, [SP, #-8]!
    // 0x6e5f68: SaveReg d0
    //     0x6e5f68: str             d0, [SP, #-8]!
    // 0x6e5f6c: r0 = horizontalTitleGap=()
    //     0x6e5f6c: bl              #0x6e6028  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::horizontalTitleGap=
    // 0x6e5f70: add             SP, SP, #0x10
    // 0x6e5f74: ldr             x0, [fp, #0x20]
    // 0x6e5f78: LoadField: d0 = r0->field_43
    //     0x6e5f78: ldur            d0, [x0, #0x43]
    // 0x6e5f7c: ldr             x16, [fp, #0x10]
    // 0x6e5f80: SaveReg r16
    //     0x6e5f80: str             x16, [SP, #-8]!
    // 0x6e5f84: SaveReg d0
    //     0x6e5f84: str             d0, [SP, #-8]!
    // 0x6e5f88: r0 = minLeadingWidth=()
    //     0x6e5f88: bl              #0x6e5fc4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::minLeadingWidth=
    // 0x6e5f8c: add             SP, SP, #0x10
    // 0x6e5f90: ldr             x0, [fp, #0x20]
    // 0x6e5f94: LoadField: d0 = r0->field_3b
    //     0x6e5f94: ldur            d0, [x0, #0x3b]
    // 0x6e5f98: ldr             x16, [fp, #0x10]
    // 0x6e5f9c: SaveReg r16
    //     0x6e5f9c: str             x16, [SP, #-8]!
    // 0x6e5fa0: SaveReg d0
    //     0x6e5fa0: str             d0, [SP, #-8]!
    // 0x6e5fa4: r0 = minVerticalPadding=()
    //     0x6e5fa4: bl              #0x6e0ce4  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::minVerticalPadding=
    // 0x6e5fa8: add             SP, SP, #0x10
    // 0x6e5fac: r0 = Null
    //     0x6e5fac: mov             x0, NULL
    // 0x6e5fb0: LeaveFrame
    //     0x6e5fb0: mov             SP, fp
    //     0x6e5fb4: ldp             fp, lr, [SP], #0x10
    // 0x6e5fb8: ret
    //     0x6e5fb8: ret             
    // 0x6e5fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e5fbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e5fc0: b               #0x6e5e88
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6f55d8, size: 0x160
    // 0x6f55d8: EnterFrame
    //     0x6f55d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6f55dc: mov             fp, SP
    // 0x6f55e0: AllocStack(0x40)
    //     0x6f55e0: sub             SP, SP, #0x40
    // 0x6f55e4: CheckStackOverflow
    //     0x6f55e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f55e8: cmp             SP, x16
    //     0x6f55ec: b.ls            #0x6f56dc
    // 0x6f55f0: ldr             x0, [fp, #0x18]
    // 0x6f55f4: LoadField: r1 = r0->field_23
    //     0x6f55f4: ldur            w1, [x0, #0x23]
    // 0x6f55f8: DecompressPointer r1
    //     0x6f55f8: add             x1, x1, HEAP, lsl #32
    // 0x6f55fc: stur            x1, [fp, #-0x30]
    // 0x6f5600: LoadField: r2 = r0->field_27
    //     0x6f5600: ldur            w2, [x0, #0x27]
    // 0x6f5604: DecompressPointer r2
    //     0x6f5604: add             x2, x2, HEAP, lsl #32
    // 0x6f5608: stur            x2, [fp, #-0x28]
    // 0x6f560c: LoadField: r3 = r0->field_2b
    //     0x6f560c: ldur            w3, [x0, #0x2b]
    // 0x6f5610: DecompressPointer r3
    //     0x6f5610: add             x3, x3, HEAP, lsl #32
    // 0x6f5614: stur            x3, [fp, #-0x20]
    // 0x6f5618: LoadField: r4 = r0->field_2f
    //     0x6f5618: ldur            w4, [x0, #0x2f]
    // 0x6f561c: DecompressPointer r4
    //     0x6f561c: add             x4, x4, HEAP, lsl #32
    // 0x6f5620: stur            x4, [fp, #-0x18]
    // 0x6f5624: LoadField: d0 = r0->field_33
    //     0x6f5624: ldur            d0, [x0, #0x33]
    // 0x6f5628: LoadField: d1 = r0->field_3b
    //     0x6f5628: ldur            d1, [x0, #0x3b]
    // 0x6f562c: stur            d1, [fp, #-0x40]
    // 0x6f5630: LoadField: d2 = r0->field_43
    //     0x6f5630: ldur            d2, [x0, #0x43]
    // 0x6f5634: r0 = inline_Allocate_Double()
    //     0x6f5634: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0x6f5638: add             x0, x0, #0x10
    //     0x6f563c: cmp             x5, x0
    //     0x6f5640: b.ls            #0x6f56e4
    //     0x6f5644: str             x0, [THR, #0x60]  ; THR::top
    //     0x6f5648: sub             x0, x0, #0xf
    //     0x6f564c: mov             x5, #0xd108
    //     0x6f5650: movk            x5, #3, lsl #16
    //     0x6f5654: stur            x5, [x0, #-1]
    // 0x6f5658: StoreField: r0->field_7 = d0
    //     0x6f5658: stur            d0, [x0, #7]
    // 0x6f565c: stur            x0, [fp, #-0x10]
    // 0x6f5660: r5 = inline_Allocate_Double()
    //     0x6f5660: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x6f5664: add             x5, x5, #0x10
    //     0x6f5668: cmp             x6, x5
    //     0x6f566c: b.ls            #0x6f570c
    //     0x6f5670: str             x5, [THR, #0x60]  ; THR::top
    //     0x6f5674: sub             x5, x5, #0xf
    //     0x6f5678: mov             x6, #0xd108
    //     0x6f567c: movk            x6, #3, lsl #16
    //     0x6f5680: stur            x6, [x5, #-1]
    // 0x6f5684: StoreField: r5->field_7 = d2
    //     0x6f5684: stur            d2, [x5, #7]
    // 0x6f5688: stur            x5, [fp, #-8]
    // 0x6f568c: r0 = _RenderListTile()
    //     0x6f568c: bl              #0x6f585c  ; Allocate_RenderListTileStub -> _RenderListTile (size=0x94)
    // 0x6f5690: stur            x0, [fp, #-0x38]
    // 0x6f5694: ldur            x16, [fp, #-0x10]
    // 0x6f5698: stp             x16, x0, [SP, #-0x10]!
    // 0x6f569c: ldur            x16, [fp, #-8]
    // 0x6f56a0: SaveReg r16
    //     0x6f56a0: str             x16, [SP, #-8]!
    // 0x6f56a4: ldur            d0, [fp, #-0x40]
    // 0x6f56a8: SaveReg d0
    //     0x6f56a8: str             d0, [SP, #-8]!
    // 0x6f56ac: ldur            x16, [fp, #-0x18]
    // 0x6f56b0: ldur            lr, [fp, #-0x28]
    // 0x6f56b4: stp             lr, x16, [SP, #-0x10]!
    // 0x6f56b8: ldur            x16, [fp, #-0x20]
    // 0x6f56bc: ldur            lr, [fp, #-0x30]
    // 0x6f56c0: stp             lr, x16, [SP, #-0x10]!
    // 0x6f56c4: r0 = _RenderListTile()
    //     0x6f56c4: bl              #0x6f5738  ; [package:flutter/src/material/list_tile.dart] _RenderListTile::_RenderListTile
    // 0x6f56c8: add             SP, SP, #0x40
    // 0x6f56cc: ldur            x0, [fp, #-0x38]
    // 0x6f56d0: LeaveFrame
    //     0x6f56d0: mov             SP, fp
    //     0x6f56d4: ldp             fp, lr, [SP], #0x10
    // 0x6f56d8: ret
    //     0x6f56d8: ret             
    // 0x6f56dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f56dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f56e0: b               #0x6f55f0
    // 0x6f56e4: stp             q1, q2, [SP, #-0x20]!
    // 0x6f56e8: SaveReg d0
    //     0x6f56e8: str             q0, [SP, #-0x10]!
    // 0x6f56ec: stp             x3, x4, [SP, #-0x10]!
    // 0x6f56f0: stp             x1, x2, [SP, #-0x10]!
    // 0x6f56f4: r0 = AllocateDouble()
    //     0x6f56f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6f56f8: ldp             x1, x2, [SP], #0x10
    // 0x6f56fc: ldp             x3, x4, [SP], #0x10
    // 0x6f5700: RestoreReg d0
    //     0x6f5700: ldr             q0, [SP], #0x10
    // 0x6f5704: ldp             q1, q2, [SP], #0x20
    // 0x6f5708: b               #0x6f5658
    // 0x6f570c: stp             q1, q2, [SP, #-0x20]!
    // 0x6f5710: stp             x3, x4, [SP, #-0x10]!
    // 0x6f5714: stp             x1, x2, [SP, #-0x10]!
    // 0x6f5718: SaveReg r0
    //     0x6f5718: str             x0, [SP, #-8]!
    // 0x6f571c: r0 = AllocateDouble()
    //     0x6f571c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6f5720: mov             x5, x0
    // 0x6f5724: RestoreReg r0
    //     0x6f5724: ldr             x0, [SP], #8
    // 0x6f5728: ldp             x1, x2, [SP], #0x10
    // 0x6f572c: ldp             x3, x4, [SP], #0x10
    // 0x6f5730: ldp             q1, q2, [SP], #0x20
    // 0x6f5734: b               #0x6f5684
  }
  _ childForSlot(/* No info */) {
    // ** addr: 0xcdc810, size: 0xbc
    // 0xcdc810: EnterFrame
    //     0xcdc810: stp             fp, lr, [SP, #-0x10]!
    //     0xcdc814: mov             fp, SP
    // 0xcdc818: ldr             x0, [fp, #0x10]
    // 0xcdc81c: r2 = Null
    //     0xcdc81c: mov             x2, NULL
    // 0xcdc820: r1 = Null
    //     0xcdc820: mov             x1, NULL
    // 0xcdc824: r4 = 59
    //     0xcdc824: mov             x4, #0x3b
    // 0xcdc828: branchIfSmi(r0, 0xcdc834)
    //     0xcdc828: tbz             w0, #0, #0xcdc834
    // 0xcdc82c: r4 = LoadClassIdInstr(r0)
    //     0xcdc82c: ldur            x4, [x0, #-1]
    //     0xcdc830: ubfx            x4, x4, #0xc, #0x14
    // 0xcdc834: r17 = 5959
    //     0xcdc834: mov             x17, #0x1747
    // 0xcdc838: cmp             x4, x17
    // 0xcdc83c: b.eq            #0xcdc854
    // 0xcdc840: r8 = _ListTileSlot
    //     0xcdc840: add             x8, PP, #0x56, lsl #12  ; [pp+0x564a8] Type: _ListTileSlot
    //     0xcdc844: ldr             x8, [x8, #0x4a8]
    // 0xcdc848: r3 = Null
    //     0xcdc848: add             x3, PP, #0x56, lsl #12  ; [pp+0x564b0] Null
    //     0xcdc84c: ldr             x3, [x3, #0x4b0]
    // 0xcdc850: r0 = _ListTileSlot()
    //     0xcdc850: bl              #0x6290ec  ; IsType__ListTileSlot_Stub
    // 0xcdc854: ldr             x1, [fp, #0x10]
    // 0xcdc858: LoadField: r2 = r1->field_7
    //     0xcdc858: ldur            x2, [x1, #7]
    // 0xcdc85c: cmp             x2, #1
    // 0xcdc860: b.gt            #0xcdc89c
    // 0xcdc864: cmp             x2, #0
    // 0xcdc868: b.gt            #0xcdc884
    // 0xcdc86c: ldr             x1, [fp, #0x18]
    // 0xcdc870: LoadField: r0 = r1->field_b
    //     0xcdc870: ldur            w0, [x1, #0xb]
    // 0xcdc874: DecompressPointer r0
    //     0xcdc874: add             x0, x0, HEAP, lsl #32
    // 0xcdc878: LeaveFrame
    //     0xcdc878: mov             SP, fp
    //     0xcdc87c: ldp             fp, lr, [SP], #0x10
    // 0xcdc880: ret
    //     0xcdc880: ret             
    // 0xcdc884: ldr             x1, [fp, #0x18]
    // 0xcdc888: LoadField: r0 = r1->field_f
    //     0xcdc888: ldur            w0, [x1, #0xf]
    // 0xcdc88c: DecompressPointer r0
    //     0xcdc88c: add             x0, x0, HEAP, lsl #32
    // 0xcdc890: LeaveFrame
    //     0xcdc890: mov             SP, fp
    //     0xcdc894: ldp             fp, lr, [SP], #0x10
    // 0xcdc898: ret
    //     0xcdc898: ret             
    // 0xcdc89c: ldr             x1, [fp, #0x18]
    // 0xcdc8a0: cmp             x2, #2
    // 0xcdc8a4: b.gt            #0xcdc8b8
    // 0xcdc8a8: r0 = Null
    //     0xcdc8a8: mov             x0, NULL
    // 0xcdc8ac: LeaveFrame
    //     0xcdc8ac: mov             SP, fp
    //     0xcdc8b0: ldp             fp, lr, [SP], #0x10
    // 0xcdc8b4: ret
    //     0xcdc8b4: ret             
    // 0xcdc8b8: LoadField: r0 = r1->field_17
    //     0xcdc8b8: ldur            w0, [x1, #0x17]
    // 0xcdc8bc: DecompressPointer r0
    //     0xcdc8bc: add             x0, x0, HEAP, lsl #32
    // 0xcdc8c0: LeaveFrame
    //     0xcdc8c0: mov             SP, fp
    //     0xcdc8c4: ldp             fp, lr, [SP], #0x10
    // 0xcdc8c8: ret
    //     0xcdc8c8: ret             
  }
  get _ slots(/* No info */) {
    // ** addr: 0xcde158, size: 0xc
    // 0xcde158: r0 = const [Instance of '_ListTileSlot', Instance of '_ListTileSlot', Instance of '_ListTileSlot', Instance of '_ListTileSlot']
    //     0xcde158: add             x0, PP, #0x56, lsl #12  ; [pp+0x564c0] List<_ListTileSlot>(4)
    //     0xcde15c: ldr             x0, [x0, #0x4c0]
    // 0xcde160: ret
    //     0xcde160: ret             
  }
}

// class id: 3851, size: 0x84, field offset: 0xc
//   const constructor, 
class ListTile extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb2273c, size: 0x58c
    // 0xb2273c: EnterFrame
    //     0xb2273c: stp             fp, lr, [SP, #-0x10]!
    //     0xb22740: mov             fp, SP
    // 0xb22744: AllocStack(0x78)
    //     0xb22744: sub             SP, SP, #0x78
    // 0xb22748: CheckStackOverflow
    //     0xb22748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2274c: cmp             SP, x16
    //     0xb22750: b.ls            #0xb22cb4
    // 0xb22754: ldr             x16, [fp, #0x10]
    // 0xb22758: SaveReg r16
    //     0xb22758: str             x16, [SP, #-8]!
    // 0xb2275c: r0 = of()
    //     0xb2275c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb22760: add             SP, SP, #8
    // 0xb22764: stur            x0, [fp, #-8]
    // 0xb22768: ldr             x16, [fp, #0x10]
    // 0xb2276c: SaveReg r16
    //     0xb2276c: str             x16, [SP, #-8]!
    // 0xb22770: r0 = of()
    //     0xb22770: bl              #0x853040  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::of
    // 0xb22774: add             SP, SP, #8
    // 0xb22778: stur            x0, [fp, #-0x10]
    // 0xb2277c: ldr             x16, [fp, #0x18]
    // 0xb22780: ldur            lr, [fp, #-8]
    // 0xb22784: stp             lr, x16, [SP, #-0x10]!
    // 0xb22788: SaveReg r0
    //     0xb22788: str             x0, [SP, #-8]!
    // 0xb2278c: r0 = _iconColor()
    //     0xb2278c: bl              #0xb22f18  ; [package:flutter/src/material/list_tile.dart] ListTile::_iconColor
    // 0xb22790: add             SP, SP, #0x18
    // 0xb22794: stur            x0, [fp, #-0x18]
    // 0xb22798: r0 = IconThemeData()
    //     0xb22798: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xb2279c: mov             x1, x0
    // 0xb227a0: ldur            x0, [fp, #-0x18]
    // 0xb227a4: stur            x1, [fp, #-0x20]
    // 0xb227a8: StoreField: r1->field_1b = r0
    //     0xb227a8: stur            w0, [x1, #0x1b]
    // 0xb227ac: ldr             x0, [fp, #0x18]
    // 0xb227b0: LoadField: r2 = r0->field_b
    //     0xb227b0: ldur            w2, [x0, #0xb]
    // 0xb227b4: DecompressPointer r2
    //     0xb227b4: add             x2, x2, HEAP, lsl #32
    // 0xb227b8: stur            x2, [fp, #-0x18]
    // 0xb227bc: cmp             w2, NULL
    // 0xb227c0: b.ne            #0xb227d4
    // 0xb227c4: LoadField: r3 = r0->field_17
    //     0xb227c4: ldur            w3, [x0, #0x17]
    // 0xb227c8: DecompressPointer r3
    //     0xb227c8: add             x3, x3, HEAP, lsl #32
    // 0xb227cc: cmp             w3, NULL
    // 0xb227d0: b.eq            #0xb227f4
    // 0xb227d4: ldur            x16, [fp, #-8]
    // 0xb227d8: stp             x16, x0, [SP, #-0x10]!
    // 0xb227dc: ldur            x16, [fp, #-0x10]
    // 0xb227e0: SaveReg r16
    //     0xb227e0: str             x16, [SP, #-8]!
    // 0xb227e4: r0 = _trailingAndLeadingTextStyle()
    //     0xb227e4: bl              #0xb22e50  ; [package:flutter/src/material/list_tile.dart] ListTile::_trailingAndLeadingTextStyle
    // 0xb227e8: add             SP, SP, #0x18
    // 0xb227ec: mov             x1, x0
    // 0xb227f0: b               #0xb227f8
    // 0xb227f4: r1 = Null
    //     0xb227f4: mov             x1, NULL
    // 0xb227f8: ldur            x0, [fp, #-0x18]
    // 0xb227fc: stur            x1, [fp, #-0x28]
    // 0xb22800: cmp             w0, NULL
    // 0xb22804: b.eq            #0xb22868
    // 0xb22808: cmp             w1, NULL
    // 0xb2280c: b.eq            #0xb22cbc
    // 0xb22810: r0 = AnimatedDefaultTextStyle()
    //     0xb22810: bl              #0x85cffc  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xb22814: mov             x1, x0
    // 0xb22818: ldur            x0, [fp, #-0x18]
    // 0xb2281c: StoreField: r1->field_17 = r0
    //     0xb2281c: stur            w0, [x1, #0x17]
    // 0xb22820: ldur            x0, [fp, #-0x28]
    // 0xb22824: StoreField: r1->field_1b = r0
    //     0xb22824: stur            w0, [x1, #0x1b]
    // 0xb22828: r2 = true
    //     0xb22828: add             x2, NULL, #0x20  ; true
    // 0xb2282c: StoreField: r1->field_23 = r2
    //     0xb2282c: stur            w2, [x1, #0x23]
    // 0xb22830: r3 = Instance_TextOverflow
    //     0xb22830: add             x3, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xb22834: ldr             x3, [x3, #0x118]
    // 0xb22838: StoreField: r1->field_27 = r3
    //     0xb22838: stur            w3, [x1, #0x27]
    // 0xb2283c: r4 = Instance_TextWidthBasis
    //     0xb2283c: add             x4, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xb22840: ldr             x4, [x4, #0x148]
    // 0xb22844: StoreField: r1->field_2f = r4
    //     0xb22844: stur            w4, [x1, #0x2f]
    // 0xb22848: r5 = Instance__Linear
    //     0xb22848: add             x5, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0xb2284c: ldr             x5, [x5, #0x300]
    // 0xb22850: StoreField: r1->field_b = r5
    //     0xb22850: stur            w5, [x1, #0xb]
    // 0xb22854: r6 = Instance_Duration
    //     0xb22854: add             x6, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb22858: ldr             x6, [x6, #0x9e0]
    // 0xb2285c: StoreField: r1->field_f = r6
    //     0xb2285c: stur            w6, [x1, #0xf]
    // 0xb22860: mov             x7, x1
    // 0xb22864: b               #0xb22894
    // 0xb22868: mov             x0, x1
    // 0xb2286c: r6 = Instance_Duration
    //     0xb2286c: add             x6, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb22870: ldr             x6, [x6, #0x9e0]
    // 0xb22874: r2 = true
    //     0xb22874: add             x2, NULL, #0x20  ; true
    // 0xb22878: r5 = Instance__Linear
    //     0xb22878: add             x5, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0xb2287c: ldr             x5, [x5, #0x300]
    // 0xb22880: r3 = Instance_TextOverflow
    //     0xb22880: add             x3, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xb22884: ldr             x3, [x3, #0x118]
    // 0xb22888: r4 = Instance_TextWidthBasis
    //     0xb22888: add             x4, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xb2288c: ldr             x4, [x4, #0x148]
    // 0xb22890: r7 = Null
    //     0xb22890: mov             x7, NULL
    // 0xb22894: ldr             x1, [fp, #0x18]
    // 0xb22898: stur            x7, [fp, #-0x18]
    // 0xb2289c: ldur            x16, [fp, #-8]
    // 0xb228a0: stp             x16, x1, [SP, #-0x10]!
    // 0xb228a4: ldur            x16, [fp, #-0x10]
    // 0xb228a8: SaveReg r16
    //     0xb228a8: str             x16, [SP, #-8]!
    // 0xb228ac: r0 = _titleTextStyle()
    //     0xb228ac: bl              #0xb22ce0  ; [package:flutter/src/material/list_tile.dart] ListTile::_titleTextStyle
    // 0xb228b0: add             SP, SP, #0x18
    // 0xb228b4: mov             x1, x0
    // 0xb228b8: ldr             x0, [fp, #0x18]
    // 0xb228bc: stur            x1, [fp, #-0x38]
    // 0xb228c0: LoadField: r2 = r0->field_f
    //     0xb228c0: ldur            w2, [x0, #0xf]
    // 0xb228c4: DecompressPointer r2
    //     0xb228c4: add             x2, x2, HEAP, lsl #32
    // 0xb228c8: stur            x2, [fp, #-0x30]
    // 0xb228cc: r0 = AnimatedDefaultTextStyle()
    //     0xb228cc: bl              #0x85cffc  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xb228d0: mov             x1, x0
    // 0xb228d4: ldur            x0, [fp, #-0x30]
    // 0xb228d8: stur            x1, [fp, #-0x40]
    // 0xb228dc: StoreField: r1->field_17 = r0
    //     0xb228dc: stur            w0, [x1, #0x17]
    // 0xb228e0: ldur            x0, [fp, #-0x38]
    // 0xb228e4: StoreField: r1->field_1b = r0
    //     0xb228e4: stur            w0, [x1, #0x1b]
    // 0xb228e8: r2 = true
    //     0xb228e8: add             x2, NULL, #0x20  ; true
    // 0xb228ec: StoreField: r1->field_23 = r2
    //     0xb228ec: stur            w2, [x1, #0x23]
    // 0xb228f0: r3 = Instance_TextOverflow
    //     0xb228f0: add             x3, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xb228f4: ldr             x3, [x3, #0x118]
    // 0xb228f8: StoreField: r1->field_27 = r3
    //     0xb228f8: stur            w3, [x1, #0x27]
    // 0xb228fc: r4 = Instance_TextWidthBasis
    //     0xb228fc: add             x4, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xb22900: ldr             x4, [x4, #0x148]
    // 0xb22904: StoreField: r1->field_2f = r4
    //     0xb22904: stur            w4, [x1, #0x2f]
    // 0xb22908: r5 = Instance__Linear
    //     0xb22908: add             x5, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0xb2290c: ldr             x5, [x5, #0x300]
    // 0xb22910: StoreField: r1->field_b = r5
    //     0xb22910: stur            w5, [x1, #0xb]
    // 0xb22914: r6 = Instance_Duration
    //     0xb22914: add             x6, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb22918: ldr             x6, [x6, #0x9e0]
    // 0xb2291c: StoreField: r1->field_f = r6
    //     0xb2291c: stur            w6, [x1, #0xf]
    // 0xb22920: ldr             x7, [fp, #0x18]
    // 0xb22924: LoadField: r8 = r7->field_17
    //     0xb22924: ldur            w8, [x7, #0x17]
    // 0xb22928: DecompressPointer r8
    //     0xb22928: add             x8, x8, HEAP, lsl #32
    // 0xb2292c: stur            x8, [fp, #-0x30]
    // 0xb22930: cmp             w8, NULL
    // 0xb22934: b.eq            #0xb2299c
    // 0xb22938: ldur            x9, [fp, #-0x28]
    // 0xb2293c: cmp             w9, NULL
    // 0xb22940: b.eq            #0xb22cc0
    // 0xb22944: r0 = AnimatedDefaultTextStyle()
    //     0xb22944: bl              #0x85cffc  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0xb22948: mov             x1, x0
    // 0xb2294c: ldur            x0, [fp, #-0x30]
    // 0xb22950: StoreField: r1->field_17 = r0
    //     0xb22950: stur            w0, [x1, #0x17]
    // 0xb22954: ldur            x0, [fp, #-0x28]
    // 0xb22958: StoreField: r1->field_1b = r0
    //     0xb22958: stur            w0, [x1, #0x1b]
    // 0xb2295c: r0 = true
    //     0xb2295c: add             x0, NULL, #0x20  ; true
    // 0xb22960: StoreField: r1->field_23 = r0
    //     0xb22960: stur            w0, [x1, #0x23]
    // 0xb22964: r2 = Instance_TextOverflow
    //     0xb22964: add             x2, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xb22968: ldr             x2, [x2, #0x118]
    // 0xb2296c: StoreField: r1->field_27 = r2
    //     0xb2296c: stur            w2, [x1, #0x27]
    // 0xb22970: r2 = Instance_TextWidthBasis
    //     0xb22970: add             x2, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xb22974: ldr             x2, [x2, #0x148]
    // 0xb22978: StoreField: r1->field_2f = r2
    //     0xb22978: stur            w2, [x1, #0x2f]
    // 0xb2297c: r2 = Instance__Linear
    //     0xb2297c: add             x2, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0xb22980: ldr             x2, [x2, #0x300]
    // 0xb22984: StoreField: r1->field_b = r2
    //     0xb22984: stur            w2, [x1, #0xb]
    // 0xb22988: r2 = Instance_Duration
    //     0xb22988: add             x2, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb2298c: ldr             x2, [x2, #0x9e0]
    // 0xb22990: StoreField: r1->field_f = r2
    //     0xb22990: stur            w2, [x1, #0xf]
    // 0xb22994: mov             x2, x1
    // 0xb22998: b               #0xb229a4
    // 0xb2299c: mov             x0, x2
    // 0xb229a0: r2 = Null
    //     0xb229a0: mov             x2, NULL
    // 0xb229a4: ldr             x1, [fp, #0x18]
    // 0xb229a8: stur            x2, [fp, #-0x28]
    // 0xb229ac: ldr             x16, [fp, #0x10]
    // 0xb229b0: SaveReg r16
    //     0xb229b0: str             x16, [SP, #-8]!
    // 0xb229b4: r0 = of()
    //     0xb229b4: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xb229b8: add             SP, SP, #8
    // 0xb229bc: stur            x0, [fp, #-0x30]
    // 0xb229c0: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xb229c0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xb229c4: ldr             x0, [x0, #0x598]
    //     0xb229c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xb229cc: cmp             w0, w16
    //     0xb229d0: b.ne            #0xb229dc
    //     0xb229d4: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xb229d8: bl              #0xd67cdc
    // 0xb229dc: r1 = <MaterialState>
    //     0xb229dc: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0xb229e0: ldr             x1, [x1, #0xcf0]
    // 0xb229e4: stur            x0, [fp, #-0x48]
    // 0xb229e8: r0 = _Set()
    //     0xb229e8: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xb229ec: mov             x1, x0
    // 0xb229f0: ldur            x0, [fp, #-0x48]
    // 0xb229f4: stur            x1, [fp, #-0x50]
    // 0xb229f8: StoreField: r1->field_1b = r0
    //     0xb229f8: stur            w0, [x1, #0x1b]
    // 0xb229fc: StoreField: r1->field_b = rZR
    //     0xb229fc: stur            wzr, [x1, #0xb]
    // 0xb22a00: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xb22a00: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xb22a04: ldr             x0, [x0, #0x5a0]
    //     0xb22a08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xb22a0c: cmp             w0, w16
    //     0xb22a10: b.ne            #0xb22a1c
    //     0xb22a14: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xb22a18: bl              #0xd67cdc
    // 0xb22a1c: mov             x1, x0
    // 0xb22a20: ldur            x0, [fp, #-0x50]
    // 0xb22a24: StoreField: r0->field_f = r1
    //     0xb22a24: stur            w1, [x0, #0xf]
    // 0xb22a28: StoreField: r0->field_13 = rZR
    //     0xb22a28: stur            wzr, [x0, #0x13]
    // 0xb22a2c: StoreField: r0->field_17 = rZR
    //     0xb22a2c: stur            wzr, [x0, #0x17]
    // 0xb22a30: ldr             x1, [fp, #0x18]
    // 0xb22a34: LoadField: r2 = r1->field_43
    //     0xb22a34: ldur            w2, [x1, #0x43]
    // 0xb22a38: DecompressPointer r2
    //     0xb22a38: add             x2, x2, HEAP, lsl #32
    // 0xb22a3c: stur            x2, [fp, #-0x48]
    // 0xb22a40: cmp             w2, NULL
    // 0xb22a44: b.ne            #0xb22a5c
    // 0xb22a48: r16 = Instance_MaterialState
    //     0xb22a48: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0xb22a4c: ldr             x16, [x16, #0x2a0]
    // 0xb22a50: stp             x16, x0, [SP, #-0x10]!
    // 0xb22a54: r0 = add()
    //     0xb22a54: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xb22a58: add             SP, SP, #0x10
    // 0xb22a5c: ldur            x2, [fp, #-8]
    // 0xb22a60: ldur            x1, [fp, #-0x10]
    // 0xb22a64: ldur            x0, [fp, #-0x38]
    // 0xb22a68: r16 = <MouseCursor?>
    //     0xb22a68: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0xb22a6c: ldr             x16, [x16, #0x8b8]
    // 0xb22a70: stp             NULL, x16, [SP, #-0x10]!
    // 0xb22a74: ldur            x16, [fp, #-0x50]
    // 0xb22a78: SaveReg r16
    //     0xb22a78: str             x16, [SP, #-8]!
    // 0xb22a7c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb22a7c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb22a80: r0 = resolveAs()
    //     0xb22a80: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0xb22a84: add             SP, SP, #0x18
    // 0xb22a88: r16 = Instance__EnabledAndDisabledMouseCursor
    //     0xb22a88: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e208] Obj!_EnabledAndDisabledMouseCursor@b489f1
    //     0xb22a8c: ldr             x16, [x16, #0x208]
    // 0xb22a90: ldur            lr, [fp, #-0x50]
    // 0xb22a94: stp             lr, x16, [SP, #-0x10]!
    // 0xb22a98: r0 = resolve()
    //     0xb22a98: bl              #0x5a6cbc  ; [package:flutter/src/material/material_state.dart] _EnabledAndDisabledMouseCursor::resolve
    // 0xb22a9c: add             SP, SP, #0x10
    // 0xb22aa0: stur            x0, [fp, #-0x50]
    // 0xb22aa4: r0 = ShapeDecoration()
    //     0xb22aa4: bl              #0x85318c  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xb22aa8: mov             x1, x0
    // 0xb22aac: r0 = Instance_Color
    //     0xb22aac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xb22ab0: ldr             x0, [x0, #0xc08]
    // 0xb22ab4: stur            x1, [fp, #-0x60]
    // 0xb22ab8: StoreField: r1->field_7 = r0
    //     0xb22ab8: stur            w0, [x1, #7]
    // 0xb22abc: r0 = Instance_Border
    //     0xb22abc: add             x0, PP, #0x50, lsl #12  ; [pp+0x503a0] Obj!Border@b38531
    //     0xb22ac0: ldr             x0, [x0, #0x3a0]
    // 0xb22ac4: StoreField: r1->field_17 = r0
    //     0xb22ac4: stur            w0, [x1, #0x17]
    // 0xb22ac8: ldur            x0, [fp, #-8]
    // 0xb22acc: LoadField: r2 = r0->field_2f
    //     0xb22acc: ldur            w2, [x0, #0x2f]
    // 0xb22ad0: DecompressPointer r2
    //     0xb22ad0: add             x2, x2, HEAP, lsl #32
    // 0xb22ad4: ldur            x0, [fp, #-0x38]
    // 0xb22ad8: stur            x2, [fp, #-0x58]
    // 0xb22adc: LoadField: r3 = r0->field_33
    //     0xb22adc: ldur            w3, [x0, #0x33]
    // 0xb22ae0: DecompressPointer r3
    //     0xb22ae0: add             x3, x3, HEAP, lsl #32
    // 0xb22ae4: stur            x3, [fp, #-8]
    // 0xb22ae8: cmp             w3, NULL
    // 0xb22aec: b.eq            #0xb22cc4
    // 0xb22af0: ldur            x0, [fp, #-0x10]
    // 0xb22af4: LoadField: r4 = r0->field_2b
    //     0xb22af4: ldur            w4, [x0, #0x2b]
    // 0xb22af8: DecompressPointer r4
    //     0xb22af8: add             x4, x4, HEAP, lsl #32
    // 0xb22afc: cmp             w4, NULL
    // 0xb22b00: b.ne            #0xb22b0c
    // 0xb22b04: d0 = 16.000000
    //     0xb22b04: fmov            d0, #16.00000000
    // 0xb22b08: b               #0xb22b10
    // 0xb22b0c: LoadField: d0 = r4->field_7
    //     0xb22b0c: ldur            d0, [x4, #7]
    // 0xb22b10: stur            d0, [fp, #-0x78]
    // 0xb22b14: LoadField: r4 = r0->field_2f
    //     0xb22b14: ldur            w4, [x0, #0x2f]
    // 0xb22b18: DecompressPointer r4
    //     0xb22b18: add             x4, x4, HEAP, lsl #32
    // 0xb22b1c: cmp             w4, NULL
    // 0xb22b20: b.ne            #0xb22b2c
    // 0xb22b24: d1 = 4.000000
    //     0xb22b24: fmov            d1, #4.00000000
    // 0xb22b28: b               #0xb22b30
    // 0xb22b2c: LoadField: d1 = r4->field_7
    //     0xb22b2c: ldur            d1, [x4, #7]
    // 0xb22b30: stur            d1, [fp, #-0x70]
    // 0xb22b34: LoadField: r4 = r0->field_33
    //     0xb22b34: ldur            w4, [x0, #0x33]
    // 0xb22b38: DecompressPointer r4
    //     0xb22b38: add             x4, x4, HEAP, lsl #32
    // 0xb22b3c: cmp             w4, NULL
    // 0xb22b40: b.ne            #0xb22b50
    // 0xb22b44: d2 = 40.000000
    //     0xb22b44: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0xb22b48: ldr             d2, [x17, #0xdc0]
    // 0xb22b4c: b               #0xb22b54
    // 0xb22b50: LoadField: d2 = r4->field_7
    //     0xb22b50: ldur            d2, [x4, #7]
    // 0xb22b54: ldur            x8, [fp, #-0x18]
    // 0xb22b58: ldur            x7, [fp, #-0x40]
    // 0xb22b5c: ldur            x6, [fp, #-0x28]
    // 0xb22b60: ldur            x5, [fp, #-0x30]
    // 0xb22b64: ldur            x4, [fp, #-0x48]
    // 0xb22b68: ldur            x0, [fp, #-0x50]
    // 0xb22b6c: stur            d2, [fp, #-0x68]
    // 0xb22b70: r0 = _ListTile()
    //     0xb22b70: bl              #0xb22cd4  ; Allocate_ListTileStub -> _ListTile (size=0x4c)
    // 0xb22b74: mov             x1, x0
    // 0xb22b78: ldur            x0, [fp, #-0x18]
    // 0xb22b7c: StoreField: r1->field_b = r0
    //     0xb22b7c: stur            w0, [x1, #0xb]
    // 0xb22b80: ldur            x0, [fp, #-0x40]
    // 0xb22b84: StoreField: r1->field_f = r0
    //     0xb22b84: stur            w0, [x1, #0xf]
    // 0xb22b88: ldur            x0, [fp, #-0x28]
    // 0xb22b8c: StoreField: r1->field_17 = r0
    //     0xb22b8c: stur            w0, [x1, #0x17]
    // 0xb22b90: r0 = false
    //     0xb22b90: add             x0, NULL, #0x30  ; false
    // 0xb22b94: StoreField: r1->field_1b = r0
    //     0xb22b94: stur            w0, [x1, #0x1b]
    // 0xb22b98: StoreField: r1->field_1f = r0
    //     0xb22b98: stur            w0, [x1, #0x1f]
    // 0xb22b9c: ldur            x2, [fp, #-0x58]
    // 0xb22ba0: StoreField: r1->field_23 = r2
    //     0xb22ba0: stur            w2, [x1, #0x23]
    // 0xb22ba4: ldur            x2, [fp, #-0x30]
    // 0xb22ba8: StoreField: r1->field_27 = r2
    //     0xb22ba8: stur            w2, [x1, #0x27]
    // 0xb22bac: ldur            x2, [fp, #-8]
    // 0xb22bb0: StoreField: r1->field_2b = r2
    //     0xb22bb0: stur            w2, [x1, #0x2b]
    // 0xb22bb4: ldur            d0, [fp, #-0x78]
    // 0xb22bb8: StoreField: r1->field_33 = d0
    //     0xb22bb8: stur            d0, [x1, #0x33]
    // 0xb22bbc: ldur            d0, [fp, #-0x70]
    // 0xb22bc0: StoreField: r1->field_3b = d0
    //     0xb22bc0: stur            d0, [x1, #0x3b]
    // 0xb22bc4: ldur            d0, [fp, #-0x68]
    // 0xb22bc8: StoreField: r1->field_43 = d0
    //     0xb22bc8: stur            d0, [x1, #0x43]
    // 0xb22bcc: ldur            x16, [fp, #-0x20]
    // 0xb22bd0: stp             x16, x1, [SP, #-0x10]!
    // 0xb22bd4: r0 = merge()
    //     0xb22bd4: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xb22bd8: add             SP, SP, #0x10
    // 0xb22bdc: stur            x0, [fp, #-8]
    // 0xb22be0: r0 = SafeArea()
    //     0xb22be0: bl              #0x847d4c  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xb22be4: mov             x1, x0
    // 0xb22be8: r0 = true
    //     0xb22be8: add             x0, NULL, #0x20  ; true
    // 0xb22bec: stur            x1, [fp, #-0x10]
    // 0xb22bf0: StoreField: r1->field_b = r0
    //     0xb22bf0: stur            w0, [x1, #0xb]
    // 0xb22bf4: r2 = false
    //     0xb22bf4: add             x2, NULL, #0x30  ; false
    // 0xb22bf8: StoreField: r1->field_f = r2
    //     0xb22bf8: stur            w2, [x1, #0xf]
    // 0xb22bfc: StoreField: r1->field_13 = r0
    //     0xb22bfc: stur            w0, [x1, #0x13]
    // 0xb22c00: StoreField: r1->field_17 = r2
    //     0xb22c00: stur            w2, [x1, #0x17]
    // 0xb22c04: r3 = Instance_EdgeInsets
    //     0xb22c04: add             x3, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0xb22c08: ldr             x3, [x3, #0x438]
    // 0xb22c0c: StoreField: r1->field_1b = r3
    //     0xb22c0c: stur            w3, [x1, #0x1b]
    // 0xb22c10: StoreField: r1->field_1f = r2
    //     0xb22c10: stur            w2, [x1, #0x1f]
    // 0xb22c14: ldur            x3, [fp, #-8]
    // 0xb22c18: StoreField: r1->field_23 = r3
    //     0xb22c18: stur            w3, [x1, #0x23]
    // 0xb22c1c: r0 = Ink()
    //     0xb22c1c: bl              #0xb22cc8  ; AllocateInkStub -> Ink (size=0x20)
    // 0xb22c20: mov             x1, x0
    // 0xb22c24: ldur            x0, [fp, #-0x10]
    // 0xb22c28: stur            x1, [fp, #-8]
    // 0xb22c2c: StoreField: r1->field_b = r0
    //     0xb22c2c: stur            w0, [x1, #0xb]
    // 0xb22c30: ldur            x0, [fp, #-0x60]
    // 0xb22c34: StoreField: r1->field_13 = r0
    //     0xb22c34: stur            w0, [x1, #0x13]
    // 0xb22c38: r0 = Semantics()
    //     0xb22c38: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0xb22c3c: stur            x0, [fp, #-0x10]
    // 0xb22c40: r16 = false
    //     0xb22c40: add             x16, NULL, #0x30  ; false
    // 0xb22c44: stp             x16, x0, [SP, #-0x10]!
    // 0xb22c48: r16 = true
    //     0xb22c48: add             x16, NULL, #0x20  ; true
    // 0xb22c4c: ldur            lr, [fp, #-8]
    // 0xb22c50: stp             lr, x16, [SP, #-0x10]!
    // 0xb22c54: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, enabled, 0x2, selected, 0x1, null]
    //     0xb22c54: add             x4, PP, #0x55, lsl #12  ; [pp+0x558a8] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "enabled", 0x2, "selected", 0x1, Null]
    //     0xb22c58: ldr             x4, [x4, #0x8a8]
    // 0xb22c5c: r0 = Semantics()
    //     0xb22c5c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xb22c60: add             SP, SP, #0x20
    // 0xb22c64: r0 = InkWell()
    //     0xb22c64: bl              #0x832ed8  ; AllocateInkWellStub -> InkWell (size=0x7c)
    // 0xb22c68: ldur            x1, [fp, #-0x10]
    // 0xb22c6c: StoreField: r0->field_b = r1
    //     0xb22c6c: stur            w1, [x0, #0xb]
    // 0xb22c70: ldur            x1, [fp, #-0x48]
    // 0xb22c74: StoreField: r0->field_f = r1
    //     0xb22c74: stur            w1, [x0, #0xf]
    // 0xb22c78: ldur            x1, [fp, #-0x50]
    // 0xb22c7c: StoreField: r0->field_2f = r1
    //     0xb22c7c: stur            w1, [x0, #0x2f]
    // 0xb22c80: r1 = true
    //     0xb22c80: add             x1, NULL, #0x20  ; true
    // 0xb22c84: StoreField: r0->field_33 = r1
    //     0xb22c84: stur            w1, [x0, #0x33]
    // 0xb22c88: r2 = Instance_BoxShape
    //     0xb22c88: add             x2, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0xb22c8c: ldr             x2, [x2, #0xe68]
    // 0xb22c90: StoreField: r0->field_37 = r2
    //     0xb22c90: stur            w2, [x0, #0x37]
    // 0xb22c94: StoreField: r0->field_5f = r1
    //     0xb22c94: stur            w1, [x0, #0x5f]
    // 0xb22c98: r2 = false
    //     0xb22c98: add             x2, NULL, #0x30  ; false
    // 0xb22c9c: StoreField: r0->field_63 = r2
    //     0xb22c9c: stur            w2, [x0, #0x63]
    // 0xb22ca0: StoreField: r0->field_73 = r1
    //     0xb22ca0: stur            w1, [x0, #0x73]
    // 0xb22ca4: StoreField: r0->field_6b = r2
    //     0xb22ca4: stur            w2, [x0, #0x6b]
    // 0xb22ca8: LeaveFrame
    //     0xb22ca8: mov             SP, fp
    //     0xb22cac: ldp             fp, lr, [SP], #0x10
    // 0xb22cb0: ret
    //     0xb22cb0: ret             
    // 0xb22cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22cb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22cb8: b               #0xb22754
    // 0xb22cbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22cbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb22cc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22cc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb22cc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22cc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _titleTextStyle(/* No info */) {
    // ** addr: 0xb22ce0, size: 0x170
    // 0xb22ce0: EnterFrame
    //     0xb22ce0: stp             fp, lr, [SP, #-0x10]!
    //     0xb22ce4: mov             fp, SP
    // 0xb22ce8: CheckStackOverflow
    //     0xb22ce8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb22cec: cmp             SP, x16
    //     0xb22cf0: b.ls            #0xb22e38
    // 0xb22cf4: ldr             x0, [fp, #0x10]
    // 0xb22cf8: LoadField: r1 = r0->field_f
    //     0xb22cf8: ldur            w1, [x0, #0xf]
    // 0xb22cfc: DecompressPointer r1
    //     0xb22cfc: add             x1, x1, HEAP, lsl #32
    // 0xb22d00: cmp             w1, NULL
    // 0xb22d04: b.ne            #0xb22d24
    // 0xb22d08: ldr             x2, [fp, #0x18]
    // 0xb22d0c: LoadField: r1 = r2->field_ef
    //     0xb22d0c: ldur            w1, [x2, #0xef]
    // 0xb22d10: DecompressPointer r1
    //     0xb22d10: add             x1, x1, HEAP, lsl #32
    // 0xb22d14: LoadField: r3 = r1->field_f
    //     0xb22d14: ldur            w3, [x1, #0xf]
    // 0xb22d18: DecompressPointer r3
    //     0xb22d18: add             x3, x3, HEAP, lsl #32
    // 0xb22d1c: mov             x1, x3
    // 0xb22d20: b               #0xb22d28
    // 0xb22d24: ldr             x2, [fp, #0x18]
    // 0xb22d28: cmp             w1, NULL
    // 0xb22d2c: b.ne            #0xb22d38
    // 0xb22d30: r1 = Instance_ListTileStyle
    //     0xb22d30: add             x1, PP, #0x55, lsl #12  ; [pp+0x558b0] Obj!ListTileStyle@b65631
    //     0xb22d34: ldr             x1, [x1, #0x8b0]
    // 0xb22d38: LoadField: r3 = r1->field_7
    //     0xb22d38: ldur            x3, [x1, #7]
    // 0xb22d3c: cmp             x3, #0
    // 0xb22d40: b.gt            #0xb22d90
    // 0xb22d44: LoadField: r1 = r2->field_2b
    //     0xb22d44: ldur            w1, [x2, #0x2b]
    // 0xb22d48: DecompressPointer r1
    //     0xb22d48: add             x1, x1, HEAP, lsl #32
    // 0xb22d4c: tbnz            w1, #4, #0xb22d70
    // 0xb22d50: LoadField: r1 = r2->field_93
    //     0xb22d50: ldur            w1, [x2, #0x93]
    // 0xb22d54: DecompressPointer r1
    //     0xb22d54: add             x1, x1, HEAP, lsl #32
    // 0xb22d58: LoadField: r3 = r1->field_23
    //     0xb22d58: ldur            w3, [x1, #0x23]
    // 0xb22d5c: DecompressPointer r3
    //     0xb22d5c: add             x3, x3, HEAP, lsl #32
    // 0xb22d60: cmp             w3, NULL
    // 0xb22d64: b.eq            #0xb22e40
    // 0xb22d68: mov             x1, x3
    // 0xb22d6c: b               #0xb22dd8
    // 0xb22d70: LoadField: r1 = r2->field_93
    //     0xb22d70: ldur            w1, [x2, #0x93]
    // 0xb22d74: DecompressPointer r1
    //     0xb22d74: add             x1, x1, HEAP, lsl #32
    // 0xb22d78: LoadField: r3 = r1->field_23
    //     0xb22d78: ldur            w3, [x1, #0x23]
    // 0xb22d7c: DecompressPointer r3
    //     0xb22d7c: add             x3, x3, HEAP, lsl #32
    // 0xb22d80: cmp             w3, NULL
    // 0xb22d84: b.eq            #0xb22e44
    // 0xb22d88: mov             x1, x3
    // 0xb22d8c: b               #0xb22dd8
    // 0xb22d90: LoadField: r1 = r2->field_2b
    //     0xb22d90: ldur            w1, [x2, #0x2b]
    // 0xb22d94: DecompressPointer r1
    //     0xb22d94: add             x1, x1, HEAP, lsl #32
    // 0xb22d98: tbnz            w1, #4, #0xb22dbc
    // 0xb22d9c: LoadField: r1 = r2->field_93
    //     0xb22d9c: ldur            w1, [x2, #0x93]
    // 0xb22da0: DecompressPointer r1
    //     0xb22da0: add             x1, x1, HEAP, lsl #32
    // 0xb22da4: LoadField: r3 = r1->field_2f
    //     0xb22da4: ldur            w3, [x1, #0x2f]
    // 0xb22da8: DecompressPointer r3
    //     0xb22da8: add             x3, x3, HEAP, lsl #32
    // 0xb22dac: cmp             w3, NULL
    // 0xb22db0: b.eq            #0xb22e48
    // 0xb22db4: mov             x1, x3
    // 0xb22db8: b               #0xb22dd8
    // 0xb22dbc: LoadField: r1 = r2->field_93
    //     0xb22dbc: ldur            w1, [x2, #0x93]
    // 0xb22dc0: DecompressPointer r1
    //     0xb22dc0: add             x1, x1, HEAP, lsl #32
    // 0xb22dc4: LoadField: r3 = r1->field_2b
    //     0xb22dc4: ldur            w3, [x1, #0x2b]
    // 0xb22dc8: DecompressPointer r3
    //     0xb22dc8: add             x3, x3, HEAP, lsl #32
    // 0xb22dcc: cmp             w3, NULL
    // 0xb22dd0: b.eq            #0xb22e4c
    // 0xb22dd4: mov             x1, x3
    // 0xb22dd8: LoadField: r3 = r1->field_b
    //     0xb22dd8: ldur            w3, [x1, #0xb]
    // 0xb22ddc: DecompressPointer r3
    //     0xb22ddc: add             x3, x3, HEAP, lsl #32
    // 0xb22de0: LoadField: r4 = r0->field_1b
    //     0xb22de0: ldur            w4, [x0, #0x1b]
    // 0xb22de4: DecompressPointer r4
    //     0xb22de4: add             x4, x4, HEAP, lsl #32
    // 0xb22de8: cmp             w4, NULL
    // 0xb22dec: b.ne            #0xb22e08
    // 0xb22df0: LoadField: r0 = r2->field_ef
    //     0xb22df0: ldur            w0, [x2, #0xef]
    // 0xb22df4: DecompressPointer r0
    //     0xb22df4: add             x0, x0, HEAP, lsl #32
    // 0xb22df8: LoadField: r2 = r0->field_1b
    //     0xb22df8: ldur            w2, [x0, #0x1b]
    // 0xb22dfc: DecompressPointer r2
    //     0xb22dfc: add             x2, x2, HEAP, lsl #32
    // 0xb22e00: mov             x0, x2
    // 0xb22e04: b               #0xb22e0c
    // 0xb22e08: mov             x0, x4
    // 0xb22e0c: cmp             w0, NULL
    // 0xb22e10: b.ne            #0xb22e18
    // 0xb22e14: mov             x0, x3
    // 0xb22e18: stp             x0, x1, [SP, #-0x10]!
    // 0xb22e1c: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xb22e1c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xb22e20: ldr             x4, [x4, #0x168]
    // 0xb22e24: r0 = copyWith()
    //     0xb22e24: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xb22e28: add             SP, SP, #0x10
    // 0xb22e2c: LeaveFrame
    //     0xb22e2c: mov             SP, fp
    //     0xb22e30: ldp             fp, lr, [SP], #0x10
    // 0xb22e34: ret
    //     0xb22e34: ret             
    // 0xb22e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22e38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22e3c: b               #0xb22cf4
    // 0xb22e40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22e40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb22e44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22e44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb22e48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22e48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb22e4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22e4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _trailingAndLeadingTextStyle(/* No info */) {
    // ** addr: 0xb22e50, size: 0xc8
    // 0xb22e50: EnterFrame
    //     0xb22e50: stp             fp, lr, [SP, #-0x10]!
    //     0xb22e54: mov             fp, SP
    // 0xb22e58: CheckStackOverflow
    //     0xb22e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb22e5c: cmp             SP, x16
    //     0xb22e60: b.ls            #0xb22f08
    // 0xb22e64: ldr             x0, [fp, #0x18]
    // 0xb22e68: LoadField: r1 = r0->field_2b
    //     0xb22e68: ldur            w1, [x0, #0x2b]
    // 0xb22e6c: DecompressPointer r1
    //     0xb22e6c: add             x1, x1, HEAP, lsl #32
    // 0xb22e70: tbnz            w1, #4, #0xb22e90
    // 0xb22e74: LoadField: r1 = r0->field_93
    //     0xb22e74: ldur            w1, [x0, #0x93]
    // 0xb22e78: DecompressPointer r1
    //     0xb22e78: add             x1, x1, HEAP, lsl #32
    // 0xb22e7c: LoadField: r2 = r1->field_2f
    //     0xb22e7c: ldur            w2, [x1, #0x2f]
    // 0xb22e80: DecompressPointer r2
    //     0xb22e80: add             x2, x2, HEAP, lsl #32
    // 0xb22e84: cmp             w2, NULL
    // 0xb22e88: b.eq            #0xb22f10
    // 0xb22e8c: b               #0xb22ea8
    // 0xb22e90: LoadField: r1 = r0->field_93
    //     0xb22e90: ldur            w1, [x0, #0x93]
    // 0xb22e94: DecompressPointer r1
    //     0xb22e94: add             x1, x1, HEAP, lsl #32
    // 0xb22e98: LoadField: r2 = r1->field_2f
    //     0xb22e98: ldur            w2, [x1, #0x2f]
    // 0xb22e9c: DecompressPointer r2
    //     0xb22e9c: add             x2, x2, HEAP, lsl #32
    // 0xb22ea0: cmp             w2, NULL
    // 0xb22ea4: b.eq            #0xb22f14
    // 0xb22ea8: ldr             x1, [fp, #0x10]
    // 0xb22eac: LoadField: r3 = r2->field_b
    //     0xb22eac: ldur            w3, [x2, #0xb]
    // 0xb22eb0: DecompressPointer r3
    //     0xb22eb0: add             x3, x3, HEAP, lsl #32
    // 0xb22eb4: LoadField: r4 = r1->field_1b
    //     0xb22eb4: ldur            w4, [x1, #0x1b]
    // 0xb22eb8: DecompressPointer r4
    //     0xb22eb8: add             x4, x4, HEAP, lsl #32
    // 0xb22ebc: cmp             w4, NULL
    // 0xb22ec0: b.ne            #0xb22ed8
    // 0xb22ec4: LoadField: r1 = r0->field_ef
    //     0xb22ec4: ldur            w1, [x0, #0xef]
    // 0xb22ec8: DecompressPointer r1
    //     0xb22ec8: add             x1, x1, HEAP, lsl #32
    // 0xb22ecc: LoadField: r0 = r1->field_1b
    //     0xb22ecc: ldur            w0, [x1, #0x1b]
    // 0xb22ed0: DecompressPointer r0
    //     0xb22ed0: add             x0, x0, HEAP, lsl #32
    // 0xb22ed4: b               #0xb22edc
    // 0xb22ed8: mov             x0, x4
    // 0xb22edc: cmp             w0, NULL
    // 0xb22ee0: b.ne            #0xb22ee8
    // 0xb22ee4: mov             x0, x3
    // 0xb22ee8: stp             x0, x2, [SP, #-0x10]!
    // 0xb22eec: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xb22eec: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xb22ef0: ldr             x4, [x4, #0x168]
    // 0xb22ef4: r0 = copyWith()
    //     0xb22ef4: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xb22ef8: add             SP, SP, #0x10
    // 0xb22efc: LeaveFrame
    //     0xb22efc: mov             SP, fp
    //     0xb22f00: ldp             fp, lr, [SP], #0x10
    // 0xb22f04: ret
    //     0xb22f04: ret             
    // 0xb22f08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22f08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22f0c: b               #0xb22e64
    // 0xb22f10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22f10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb22f14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb22f14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _iconColor(/* No info */) {
    // ** addr: 0xb22f18, size: 0xfc
    // 0xb22f18: EnterFrame
    //     0xb22f18: stp             fp, lr, [SP, #-0x10]!
    //     0xb22f1c: mov             fp, SP
    // 0xb22f20: CheckStackOverflow
    //     0xb22f20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb22f24: cmp             SP, x16
    //     0xb22f28: b.ls            #0xb2300c
    // 0xb22f2c: ldr             x0, [fp, #0x10]
    // 0xb22f30: LoadField: r1 = r0->field_17
    //     0xb22f30: ldur            w1, [x0, #0x17]
    // 0xb22f34: DecompressPointer r1
    //     0xb22f34: add             x1, x1, HEAP, lsl #32
    // 0xb22f38: cmp             w1, NULL
    // 0xb22f3c: b.ne            #0xb22f5c
    // 0xb22f40: ldr             x0, [fp, #0x18]
    // 0xb22f44: LoadField: r1 = r0->field_ef
    //     0xb22f44: ldur            w1, [x0, #0xef]
    // 0xb22f48: DecompressPointer r1
    //     0xb22f48: add             x1, x1, HEAP, lsl #32
    // 0xb22f4c: LoadField: r2 = r1->field_17
    //     0xb22f4c: ldur            w2, [x1, #0x17]
    // 0xb22f50: DecompressPointer r2
    //     0xb22f50: add             x2, x2, HEAP, lsl #32
    // 0xb22f54: mov             x1, x2
    // 0xb22f58: b               #0xb22f60
    // 0xb22f5c: ldr             x0, [fp, #0x18]
    // 0xb22f60: cmp             w1, NULL
    // 0xb22f64: b.ne            #0xb22fb0
    // 0xb22f68: LoadField: r1 = r0->field_2b
    //     0xb22f68: ldur            w1, [x0, #0x2b]
    // 0xb22f6c: DecompressPointer r1
    //     0xb22f6c: add             x1, x1, HEAP, lsl #32
    // 0xb22f70: tbnz            w1, #4, #0xb22fa4
    // 0xb22f74: d0 = 0.380000
    //     0xb22f74: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb22f78: ldr             d0, [x17, #0x140]
    // 0xb22f7c: LoadField: r1 = r0->field_3f
    //     0xb22f7c: ldur            w1, [x0, #0x3f]
    // 0xb22f80: DecompressPointer r1
    //     0xb22f80: add             x1, x1, HEAP, lsl #32
    // 0xb22f84: LoadField: r2 = r1->field_57
    //     0xb22f84: ldur            w2, [x1, #0x57]
    // 0xb22f88: DecompressPointer r2
    //     0xb22f88: add             x2, x2, HEAP, lsl #32
    // 0xb22f8c: SaveReg r2
    //     0xb22f8c: str             x2, [SP, #-8]!
    // 0xb22f90: SaveReg d0
    //     0xb22f90: str             d0, [SP, #-8]!
    // 0xb22f94: r0 = withOpacity()
    //     0xb22f94: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb22f98: add             SP, SP, #0x10
    // 0xb22f9c: mov             x2, x0
    // 0xb22fa0: b               #0xb22fa8
    // 0xb22fa4: r2 = Null
    //     0xb22fa4: mov             x2, NULL
    // 0xb22fa8: mov             x0, x2
    // 0xb22fac: b               #0xb22fb4
    // 0xb22fb0: mov             x0, x1
    // 0xb22fb4: cmp             w0, NULL
    // 0xb22fb8: b.eq            #0xb22fc8
    // 0xb22fbc: LeaveFrame
    //     0xb22fbc: mov             SP, fp
    //     0xb22fc0: ldp             fp, lr, [SP], #0x10
    // 0xb22fc4: ret
    //     0xb22fc4: ret             
    // 0xb22fc8: ldr             x1, [fp, #0x18]
    // 0xb22fcc: LoadField: r2 = r1->field_3f
    //     0xb22fcc: ldur            w2, [x1, #0x3f]
    // 0xb22fd0: DecompressPointer r2
    //     0xb22fd0: add             x2, x2, HEAP, lsl #32
    // 0xb22fd4: LoadField: r1 = r2->field_7
    //     0xb22fd4: ldur            w1, [x2, #7]
    // 0xb22fd8: DecompressPointer r1
    //     0xb22fd8: add             x1, x1, HEAP, lsl #32
    // 0xb22fdc: LoadField: r2 = r1->field_7
    //     0xb22fdc: ldur            x2, [x1, #7]
    // 0xb22fe0: cmp             x2, #0
    // 0xb22fe4: b.gt            #0xb22ff8
    // 0xb22fe8: r0 = Null
    //     0xb22fe8: mov             x0, NULL
    // 0xb22fec: LeaveFrame
    //     0xb22fec: mov             SP, fp
    //     0xb22ff0: ldp             fp, lr, [SP], #0x10
    // 0xb22ff4: ret
    //     0xb22ff4: ret             
    // 0xb22ff8: r0 = Instance_Color
    //     0xb22ff8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe2c8] Obj!Color@b5d821
    //     0xb22ffc: ldr             x0, [x0, #0x2c8]
    // 0xb23000: LeaveFrame
    //     0xb23000: mov             SP, fp
    //     0xb23004: ldp             fp, lr, [SP], #0x10
    // 0xb23008: ret
    //     0xb23008: ret             
    // 0xb2300c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2300c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23010: b               #0xb22f2c
  }
}

// class id: 5959, size: 0x14, field offset: 0x14
enum _ListTileSlot extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16304, size: 0x5c
    // 0xb16304: EnterFrame
    //     0xb16304: stp             fp, lr, [SP, #-0x10]!
    //     0xb16308: mov             fp, SP
    // 0xb1630c: CheckStackOverflow
    //     0xb1630c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16310: cmp             SP, x16
    //     0xb16314: b.ls            #0xb16358
    // 0xb16318: r1 = Null
    //     0xb16318: mov             x1, NULL
    // 0xb1631c: r2 = 4
    //     0xb1631c: mov             x2, #4
    // 0xb16320: r0 = AllocateArray()
    //     0xb16320: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16324: r17 = "_ListTileSlot."
    //     0xb16324: add             x17, PP, #0x56, lsl #12  ; [pp+0x56e00] "_ListTileSlot."
    //     0xb16328: ldr             x17, [x17, #0xe00]
    // 0xb1632c: StoreField: r0->field_f = r17
    //     0xb1632c: stur            w17, [x0, #0xf]
    // 0xb16330: ldr             x1, [fp, #0x10]
    // 0xb16334: LoadField: r2 = r1->field_f
    //     0xb16334: ldur            w2, [x1, #0xf]
    // 0xb16338: DecompressPointer r2
    //     0xb16338: add             x2, x2, HEAP, lsl #32
    // 0xb1633c: StoreField: r0->field_13 = r2
    //     0xb1633c: stur            w2, [x0, #0x13]
    // 0xb16340: SaveReg r0
    //     0xb16340: str             x0, [SP, #-8]!
    // 0xb16344: r0 = _interpolate()
    //     0xb16344: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16348: add             SP, SP, #8
    // 0xb1634c: LeaveFrame
    //     0xb1634c: mov             SP, fp
    //     0xb16350: ldp             fp, lr, [SP], #0x10
    // 0xb16354: ret
    //     0xb16354: ret             
    // 0xb16358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16358: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1635c: b               #0xb16318
  }
}

// class id: 5961, size: 0x14, field offset: 0x14
enum ListTileStyle extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb162a8, size: 0x5c
    // 0xb162a8: EnterFrame
    //     0xb162a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb162ac: mov             fp, SP
    // 0xb162b0: CheckStackOverflow
    //     0xb162b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb162b4: cmp             SP, x16
    //     0xb162b8: b.ls            #0xb162fc
    // 0xb162bc: r1 = Null
    //     0xb162bc: mov             x1, NULL
    // 0xb162c0: r2 = 4
    //     0xb162c0: mov             x2, #4
    // 0xb162c4: r0 = AllocateArray()
    //     0xb162c4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb162c8: r17 = "ListTileStyle."
    //     0xb162c8: add             x17, PP, #0x56, lsl #12  ; [pp+0x56480] "ListTileStyle."
    //     0xb162cc: ldr             x17, [x17, #0x480]
    // 0xb162d0: StoreField: r0->field_f = r17
    //     0xb162d0: stur            w17, [x0, #0xf]
    // 0xb162d4: ldr             x1, [fp, #0x10]
    // 0xb162d8: LoadField: r2 = r1->field_f
    //     0xb162d8: ldur            w2, [x1, #0xf]
    // 0xb162dc: DecompressPointer r2
    //     0xb162dc: add             x2, x2, HEAP, lsl #32
    // 0xb162e0: StoreField: r0->field_13 = r2
    //     0xb162e0: stur            w2, [x0, #0x13]
    // 0xb162e4: SaveReg r0
    //     0xb162e4: str             x0, [SP, #-8]!
    // 0xb162e8: r0 = _interpolate()
    //     0xb162e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb162ec: add             SP, SP, #8
    // 0xb162f0: LeaveFrame
    //     0xb162f0: mov             SP, fp
    //     0xb162f4: ldp             fp, lr, [SP], #0x10
    // 0xb162f8: ret
    //     0xb162f8: ret             
    // 0xb162fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb162fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16300: b               #0xb162bc
  }
}

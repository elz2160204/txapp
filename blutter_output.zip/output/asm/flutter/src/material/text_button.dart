// lib: , url: package:flutter/src/material/text_button.dart

// class id: 1049321, size: 0x8
class :: {

  static _ _scaledPadding(/* No info */) {
    // ** addr: 0xc154e4, size: 0xb8
    // 0xc154e4: EnterFrame
    //     0xc154e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc154e8: mov             fp, SP
    // 0xc154ec: CheckStackOverflow
    //     0xc154ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc154f0: cmp             SP, x16
    //     0xc154f4: b.ls            #0xc15584
    // 0xc154f8: ldr             x16, [fp, #0x10]
    // 0xc154fc: SaveReg r16
    //     0xc154fc: str             x16, [SP, #-8]!
    // 0xc15500: r0 = maybeOf()
    //     0xc15500: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0xc15504: add             SP, SP, #8
    // 0xc15508: cmp             w0, NULL
    // 0xc1550c: b.ne            #0xc15518
    // 0xc15510: r0 = Null
    //     0xc15510: mov             x0, NULL
    // 0xc15514: b               #0xc15544
    // 0xc15518: LoadField: d0 = r0->field_13
    //     0xc15518: ldur            d0, [x0, #0x13]
    // 0xc1551c: r0 = inline_Allocate_Double()
    //     0xc1551c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc15520: add             x0, x0, #0x10
    //     0xc15524: cmp             x1, x0
    //     0xc15528: b.ls            #0xc1558c
    //     0xc1552c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc15530: sub             x0, x0, #0xf
    //     0xc15534: mov             x1, #0xd108
    //     0xc15538: movk            x1, #3, lsl #16
    //     0xc1553c: stur            x1, [x0, #-1]
    // 0xc15540: StoreField: r0->field_7 = d0
    //     0xc15540: stur            d0, [x0, #7]
    // 0xc15544: cmp             w0, NULL
    // 0xc15548: b.ne            #0xc15554
    // 0xc1554c: d0 = 1.000000
    //     0xc1554c: fmov            d0, #1.00000000
    // 0xc15550: b               #0xc15558
    // 0xc15554: LoadField: d0 = r0->field_7
    //     0xc15554: ldur            d0, [x0, #7]
    // 0xc15558: r16 = Instance_EdgeInsets
    //     0xc15558: add             x16, PP, #0x33, lsl #12  ; [pp+0x33980] Obj!EdgeInsets@b35b11
    //     0xc1555c: ldr             x16, [x16, #0x980]
    // 0xc15560: r30 = Instance_EdgeInsets
    //     0xc15560: add             lr, PP, #0x37, lsl #12  ; [pp+0x37700] Obj!EdgeInsets@b36951
    //     0xc15564: ldr             lr, [lr, #0x700]
    // 0xc15568: stp             lr, x16, [SP, #-0x10]!
    // 0xc1556c: SaveReg d0
    //     0xc1556c: str             d0, [SP, #-8]!
    // 0xc15570: r0 = scaledPadding()
    //     0xc15570: bl              #0xc14c04  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0xc15574: add             SP, SP, #0x18
    // 0xc15578: LeaveFrame
    //     0xc15578: mov             SP, fp
    //     0xc1557c: ldp             fp, lr, [SP], #0x10
    // 0xc15580: ret
    //     0xc15580: ret             
    // 0xc15584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc15584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc15588: b               #0xc154f8
    // 0xc1558c: SaveReg d0
    //     0xc1558c: str             q0, [SP, #-0x10]!
    // 0xc15590: r0 = AllocateDouble()
    //     0xc15590: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc15594: RestoreReg d0
    //     0xc15594: ldr             q0, [SP], #0x10
    // 0xc15598: b               #0xc15540
  }
}

// class id: 2218, size: 0x10, field offset: 0xc
class _TextButtonDefaultOverlay extends MaterialStateProperty<Color?> {

  _ resolve(/* No info */) {
    // ** addr: 0x5b5f34, size: 0x124
    // 0x5b5f34: EnterFrame
    //     0x5b5f34: stp             fp, lr, [SP, #-0x10]!
    //     0x5b5f38: mov             fp, SP
    // 0x5b5f3c: CheckStackOverflow
    //     0x5b5f3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b5f40: cmp             SP, x16
    //     0x5b5f44: b.ls            #0x5b6050
    // 0x5b5f48: ldr             x1, [fp, #0x10]
    // 0x5b5f4c: r0 = LoadClassIdInstr(r1)
    //     0x5b5f4c: ldur            x0, [x1, #-1]
    //     0x5b5f50: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5f54: r16 = Instance_MaterialState
    //     0x5b5f54: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x5b5f58: ldr             x16, [x16, #0xf78]
    // 0x5b5f5c: stp             x16, x1, [SP, #-0x10]!
    // 0x5b5f60: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5f60: mov             x17, #0xc98a
    //     0x5b5f64: add             lr, x0, x17
    //     0x5b5f68: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5f6c: blr             lr
    // 0x5b5f70: add             SP, SP, #0x10
    // 0x5b5f74: tbnz            w0, #4, #0x5b5fa8
    // 0x5b5f78: ldr             x1, [fp, #0x18]
    // 0x5b5f7c: d0 = 0.040000
    //     0x5b5f7c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf50] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0x5b5f80: ldr             d0, [x17, #0xf50]
    // 0x5b5f84: LoadField: r0 = r1->field_b
    //     0x5b5f84: ldur            w0, [x1, #0xb]
    // 0x5b5f88: DecompressPointer r0
    //     0x5b5f88: add             x0, x0, HEAP, lsl #32
    // 0x5b5f8c: SaveReg r0
    //     0x5b5f8c: str             x0, [SP, #-8]!
    // 0x5b5f90: SaveReg d0
    //     0x5b5f90: str             d0, [SP, #-8]!
    // 0x5b5f94: r0 = withOpacity()
    //     0x5b5f94: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b5f98: add             SP, SP, #0x10
    // 0x5b5f9c: LeaveFrame
    //     0x5b5f9c: mov             SP, fp
    //     0x5b5fa0: ldp             fp, lr, [SP], #0x10
    // 0x5b5fa4: ret
    //     0x5b5fa4: ret             
    // 0x5b5fa8: ldr             x1, [fp, #0x18]
    // 0x5b5fac: ldr             x2, [fp, #0x10]
    // 0x5b5fb0: r0 = LoadClassIdInstr(r2)
    //     0x5b5fb0: ldur            x0, [x2, #-1]
    //     0x5b5fb4: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5fb8: r16 = Instance_MaterialState
    //     0x5b5fb8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x5b5fbc: ldr             x16, [x16, #0xf88]
    // 0x5b5fc0: stp             x16, x2, [SP, #-0x10]!
    // 0x5b5fc4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5fc4: mov             x17, #0xc98a
    //     0x5b5fc8: add             lr, x0, x17
    //     0x5b5fcc: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5fd0: blr             lr
    // 0x5b5fd4: add             SP, SP, #0x10
    // 0x5b5fd8: tbz             w0, #4, #0x5b6010
    // 0x5b5fdc: ldr             x0, [fp, #0x10]
    // 0x5b5fe0: r1 = LoadClassIdInstr(r0)
    //     0x5b5fe0: ldur            x1, [x0, #-1]
    //     0x5b5fe4: ubfx            x1, x1, #0xc, #0x14
    // 0x5b5fe8: r16 = Instance_MaterialState
    //     0x5b5fe8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x5b5fec: ldr             x16, [x16, #0xf90]
    // 0x5b5ff0: stp             x16, x0, [SP, #-0x10]!
    // 0x5b5ff4: mov             x0, x1
    // 0x5b5ff8: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5ff8: mov             x17, #0xc98a
    //     0x5b5ffc: add             lr, x0, x17
    //     0x5b6000: ldr             lr, [x21, lr, lsl #3]
    //     0x5b6004: blr             lr
    // 0x5b6008: add             SP, SP, #0x10
    // 0x5b600c: tbnz            w0, #4, #0x5b6040
    // 0x5b6010: ldr             x0, [fp, #0x18]
    // 0x5b6014: d0 = 0.120000
    //     0x5b6014: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x5b6018: ldr             d0, [x17, #0xf48]
    // 0x5b601c: LoadField: r1 = r0->field_b
    //     0x5b601c: ldur            w1, [x0, #0xb]
    // 0x5b6020: DecompressPointer r1
    //     0x5b6020: add             x1, x1, HEAP, lsl #32
    // 0x5b6024: SaveReg r1
    //     0x5b6024: str             x1, [SP, #-8]!
    // 0x5b6028: SaveReg d0
    //     0x5b6028: str             d0, [SP, #-8]!
    // 0x5b602c: r0 = withOpacity()
    //     0x5b602c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b6030: add             SP, SP, #0x10
    // 0x5b6034: LeaveFrame
    //     0x5b6034: mov             SP, fp
    //     0x5b6038: ldp             fp, lr, [SP], #0x10
    // 0x5b603c: ret
    //     0x5b603c: ret             
    // 0x5b6040: r0 = Null
    //     0x5b6040: mov             x0, NULL
    // 0x5b6044: LeaveFrame
    //     0x5b6044: mov             SP, fp
    //     0x5b6048: ldp             fp, lr, [SP], #0x10
    // 0x5b604c: ret
    //     0x5b604c: ret             
    // 0x5b6050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b6050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b6054: b               #0x5b5f48
  }
  _ toString(/* No info */) {
    // ** addr: 0xada49c, size: 0x108
    // 0xada49c: EnterFrame
    //     0xada49c: stp             fp, lr, [SP, #-0x10]!
    //     0xada4a0: mov             fp, SP
    // 0xada4a4: AllocStack(0x10)
    //     0xada4a4: sub             SP, SP, #0x10
    // 0xada4a8: CheckStackOverflow
    //     0xada4a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xada4ac: cmp             SP, x16
    //     0xada4b0: b.ls            #0xada59c
    // 0xada4b4: r1 = Null
    //     0xada4b4: mov             x1, NULL
    // 0xada4b8: r2 = 10
    //     0xada4b8: mov             x2, #0xa
    // 0xada4bc: r0 = AllocateArray()
    //     0xada4bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada4c0: stur            x0, [fp, #-0x10]
    // 0xada4c4: r17 = "{hovered: "
    //     0xada4c4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37708] "{hovered: "
    //     0xada4c8: ldr             x17, [x17, #0x708]
    // 0xada4cc: StoreField: r0->field_f = r17
    //     0xada4cc: stur            w17, [x0, #0xf]
    // 0xada4d0: ldr             x1, [fp, #0x10]
    // 0xada4d4: LoadField: r2 = r1->field_b
    //     0xada4d4: ldur            w2, [x1, #0xb]
    // 0xada4d8: DecompressPointer r2
    //     0xada4d8: add             x2, x2, HEAP, lsl #32
    // 0xada4dc: stur            x2, [fp, #-8]
    // 0xada4e0: SaveReg r2
    //     0xada4e0: str             x2, [SP, #-8]!
    // 0xada4e4: d0 = 0.040000
    //     0xada4e4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf50] IMM: double(0.04) from 0x3fa47ae147ae147b
    //     0xada4e8: ldr             d0, [x17, #0xf50]
    // 0xada4ec: SaveReg d0
    //     0xada4ec: str             d0, [SP, #-8]!
    // 0xada4f0: r0 = withOpacity()
    //     0xada4f0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xada4f4: add             SP, SP, #0x10
    // 0xada4f8: ldur            x1, [fp, #-0x10]
    // 0xada4fc: ArrayStore: r1[1] = r0  ; List_4
    //     0xada4fc: add             x25, x1, #0x13
    //     0xada500: str             w0, [x25]
    //     0xada504: tbz             w0, #0, #0xada520
    //     0xada508: ldurb           w16, [x1, #-1]
    //     0xada50c: ldurb           w17, [x0, #-1]
    //     0xada510: and             x16, x17, x16, lsr #2
    //     0xada514: tst             x16, HEAP, lsr #32
    //     0xada518: b.eq            #0xada520
    //     0xada51c: bl              #0xd67e5c
    // 0xada520: ldur            x1, [fp, #-0x10]
    // 0xada524: r17 = ", focused,pressed: "
    //     0xada524: add             x17, PP, #0x37, lsl #12  ; [pp+0x37710] ", focused,pressed: "
    //     0xada528: ldr             x17, [x17, #0x710]
    // 0xada52c: StoreField: r1->field_17 = r17
    //     0xada52c: stur            w17, [x1, #0x17]
    // 0xada530: ldur            x16, [fp, #-8]
    // 0xada534: SaveReg r16
    //     0xada534: str             x16, [SP, #-8]!
    // 0xada538: d0 = 0.120000
    //     0xada538: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xada53c: ldr             d0, [x17, #0xf48]
    // 0xada540: SaveReg d0
    //     0xada540: str             d0, [SP, #-8]!
    // 0xada544: r0 = withOpacity()
    //     0xada544: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xada548: add             SP, SP, #0x10
    // 0xada54c: ldur            x1, [fp, #-0x10]
    // 0xada550: ArrayStore: r1[3] = r0  ; List_4
    //     0xada550: add             x25, x1, #0x1b
    //     0xada554: str             w0, [x25]
    //     0xada558: tbz             w0, #0, #0xada574
    //     0xada55c: ldurb           w16, [x1, #-1]
    //     0xada560: ldurb           w17, [x0, #-1]
    //     0xada564: and             x16, x17, x16, lsr #2
    //     0xada568: tst             x16, HEAP, lsr #32
    //     0xada56c: b.eq            #0xada574
    //     0xada570: bl              #0xd67e5c
    // 0xada574: ldur            x0, [fp, #-0x10]
    // 0xada578: r17 = ", otherwise: null}"
    //     0xada578: add             x17, PP, #0x37, lsl #12  ; [pp+0x37718] ", otherwise: null}"
    //     0xada57c: ldr             x17, [x17, #0x718]
    // 0xada580: StoreField: r0->field_1f = r17
    //     0xada580: stur            w17, [x0, #0x1f]
    // 0xada584: SaveReg r0
    //     0xada584: str             x0, [SP, #-8]!
    // 0xada588: r0 = _interpolate()
    //     0xada588: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada58c: add             SP, SP, #8
    // 0xada590: LeaveFrame
    //     0xada590: mov             SP, fp
    //     0xada594: ldp             fp, lr, [SP], #0x10
    // 0xada598: ret
    //     0xada598: ret             
    // 0xada59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xada59c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xada5a0: b               #0xada4b4
  }
}

// class id: 2219, size: 0x14, field offset: 0xc
class _TextButtonDefaultColor extends MaterialStateProperty<Color?> {

  _ resolve(/* No info */) {
    // ** addr: 0x5b5eb4, size: 0x80
    // 0x5b5eb4: EnterFrame
    //     0x5b5eb4: stp             fp, lr, [SP, #-0x10]!
    //     0x5b5eb8: mov             fp, SP
    // 0x5b5ebc: CheckStackOverflow
    //     0x5b5ebc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b5ec0: cmp             SP, x16
    //     0x5b5ec4: b.ls            #0x5b5f2c
    // 0x5b5ec8: ldr             x0, [fp, #0x10]
    // 0x5b5ecc: r1 = LoadClassIdInstr(r0)
    //     0x5b5ecc: ldur            x1, [x0, #-1]
    //     0x5b5ed0: ubfx            x1, x1, #0xc, #0x14
    // 0x5b5ed4: r16 = Instance_MaterialState
    //     0x5b5ed4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x5b5ed8: ldr             x16, [x16, #0x2a0]
    // 0x5b5edc: stp             x16, x0, [SP, #-0x10]!
    // 0x5b5ee0: mov             x0, x1
    // 0x5b5ee4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5ee4: mov             x17, #0xc98a
    //     0x5b5ee8: add             lr, x0, x17
    //     0x5b5eec: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5ef0: blr             lr
    // 0x5b5ef4: add             SP, SP, #0x10
    // 0x5b5ef8: tbnz            w0, #4, #0x5b5f14
    // 0x5b5efc: ldr             x1, [fp, #0x18]
    // 0x5b5f00: LoadField: r0 = r1->field_f
    //     0x5b5f00: ldur            w0, [x1, #0xf]
    // 0x5b5f04: DecompressPointer r0
    //     0x5b5f04: add             x0, x0, HEAP, lsl #32
    // 0x5b5f08: LeaveFrame
    //     0x5b5f08: mov             SP, fp
    //     0x5b5f0c: ldp             fp, lr, [SP], #0x10
    // 0x5b5f10: ret
    //     0x5b5f10: ret             
    // 0x5b5f14: ldr             x1, [fp, #0x18]
    // 0x5b5f18: LoadField: r0 = r1->field_b
    //     0x5b5f18: ldur            w0, [x1, #0xb]
    // 0x5b5f1c: DecompressPointer r0
    //     0x5b5f1c: add             x0, x0, HEAP, lsl #32
    // 0x5b5f20: LeaveFrame
    //     0x5b5f20: mov             SP, fp
    //     0x5b5f24: ldp             fp, lr, [SP], #0x10
    // 0x5b5f28: ret
    //     0x5b5f28: ret             
    // 0x5b5f2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b5f2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b5f30: b               #0x5b5ec8
  }
  _ toString(/* No info */) {
    // ** addr: 0xada420, size: 0x7c
    // 0xada420: EnterFrame
    //     0xada420: stp             fp, lr, [SP, #-0x10]!
    //     0xada424: mov             fp, SP
    // 0xada428: CheckStackOverflow
    //     0xada428: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xada42c: cmp             SP, x16
    //     0xada430: b.ls            #0xada494
    // 0xada434: r1 = Null
    //     0xada434: mov             x1, NULL
    // 0xada438: r2 = 10
    //     0xada438: mov             x2, #0xa
    // 0xada43c: r0 = AllocateArray()
    //     0xada43c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada440: r17 = "{disabled: "
    //     0xada440: add             x17, PP, #0x37, lsl #12  ; [pp+0x376d0] "{disabled: "
    //     0xada444: ldr             x17, [x17, #0x6d0]
    // 0xada448: StoreField: r0->field_f = r17
    //     0xada448: stur            w17, [x0, #0xf]
    // 0xada44c: ldr             x1, [fp, #0x10]
    // 0xada450: LoadField: r2 = r1->field_f
    //     0xada450: ldur            w2, [x1, #0xf]
    // 0xada454: DecompressPointer r2
    //     0xada454: add             x2, x2, HEAP, lsl #32
    // 0xada458: StoreField: r0->field_13 = r2
    //     0xada458: stur            w2, [x0, #0x13]
    // 0xada45c: r17 = ", otherwise: "
    //     0xada45c: add             x17, PP, #0x37, lsl #12  ; [pp+0x376d8] ", otherwise: "
    //     0xada460: ldr             x17, [x17, #0x6d8]
    // 0xada464: StoreField: r0->field_17 = r17
    //     0xada464: stur            w17, [x0, #0x17]
    // 0xada468: LoadField: r2 = r1->field_b
    //     0xada468: ldur            w2, [x1, #0xb]
    // 0xada46c: DecompressPointer r2
    //     0xada46c: add             x2, x2, HEAP, lsl #32
    // 0xada470: StoreField: r0->field_1b = r2
    //     0xada470: stur            w2, [x0, #0x1b]
    // 0xada474: r17 = "}"
    //     0xada474: ldr             x17, [PP, #0x438]  ; [pp+0x438] "}"
    // 0xada478: StoreField: r0->field_1f = r17
    //     0xada478: stur            w17, [x0, #0x1f]
    // 0xada47c: SaveReg r0
    //     0xada47c: str             x0, [SP, #-8]!
    // 0xada480: r0 = _interpolate()
    //     0xada480: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada484: add             SP, SP, #8
    // 0xada488: LeaveFrame
    //     0xada488: mov             SP, fp
    //     0xada48c: ldp             fp, lr, [SP], #0x10
    // 0xada490: ret
    //     0xada490: ret             
    // 0xada494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xada494: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xada498: b               #0xada434
  }
}

// class id: 2221, size: 0x14, field offset: 0xc
class _TextButtonDefaultMouseCursor extends __IconButtonDefaultMouseCursor&MaterialStateProperty&Diagnosticable {

  _ resolve(/* No info */) {
    // ** addr: 0x5b5e3c, size: 0x78
    // 0x5b5e3c: EnterFrame
    //     0x5b5e3c: stp             fp, lr, [SP, #-0x10]!
    //     0x5b5e40: mov             fp, SP
    // 0x5b5e44: CheckStackOverflow
    //     0x5b5e44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b5e48: cmp             SP, x16
    //     0x5b5e4c: b.ls            #0x5b5eac
    // 0x5b5e50: ldr             x0, [fp, #0x10]
    // 0x5b5e54: r1 = LoadClassIdInstr(r0)
    //     0x5b5e54: ldur            x1, [x0, #-1]
    //     0x5b5e58: ubfx            x1, x1, #0xc, #0x14
    // 0x5b5e5c: r16 = Instance_MaterialState
    //     0x5b5e5c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x5b5e60: ldr             x16, [x16, #0x2a0]
    // 0x5b5e64: stp             x16, x0, [SP, #-0x10]!
    // 0x5b5e68: mov             x0, x1
    // 0x5b5e6c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5e6c: mov             x17, #0xc98a
    //     0x5b5e70: add             lr, x0, x17
    //     0x5b5e74: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5e78: blr             lr
    // 0x5b5e7c: add             SP, SP, #0x10
    // 0x5b5e80: tbnz            w0, #4, #0x5b5e94
    // 0x5b5e84: r0 = Instance_SystemMouseCursor
    //     0x5b5e84: ldr             x0, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0x5b5e88: LeaveFrame
    //     0x5b5e88: mov             SP, fp
    //     0x5b5e8c: ldp             fp, lr, [SP], #0x10
    // 0x5b5e90: ret
    //     0x5b5e90: ret             
    // 0x5b5e94: ldr             x1, [fp, #0x18]
    // 0x5b5e98: LoadField: r0 = r1->field_b
    //     0x5b5e98: ldur            w0, [x1, #0xb]
    // 0x5b5e9c: DecompressPointer r0
    //     0x5b5e9c: add             x0, x0, HEAP, lsl #32
    // 0x5b5ea0: LeaveFrame
    //     0x5b5ea0: mov             SP, fp
    //     0x5b5ea4: ldp             fp, lr, [SP], #0x10
    // 0x5b5ea8: ret
    //     0x5b5ea8: ret             
    // 0x5b5eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b5eac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b5eb0: b               #0x5b5e50
  }
}

// class id: 2830, size: 0x68, field offset: 0x60
class _TextButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x64

  [closure] SystemMouseCursor <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x5b5d20, size: 0x74
    // 0x5b5d20: EnterFrame
    //     0x5b5d20: stp             fp, lr, [SP, #-0x10]!
    //     0x5b5d24: mov             fp, SP
    // 0x5b5d28: CheckStackOverflow
    //     0x5b5d28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b5d2c: cmp             SP, x16
    //     0x5b5d30: b.ls            #0x5b5d8c
    // 0x5b5d34: ldr             x0, [fp, #0x10]
    // 0x5b5d38: r1 = LoadClassIdInstr(r0)
    //     0x5b5d38: ldur            x1, [x0, #-1]
    //     0x5b5d3c: ubfx            x1, x1, #0xc, #0x14
    // 0x5b5d40: r16 = Instance_MaterialState
    //     0x5b5d40: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x5b5d44: ldr             x16, [x16, #0x2a0]
    // 0x5b5d48: stp             x16, x0, [SP, #-0x10]!
    // 0x5b5d4c: mov             x0, x1
    // 0x5b5d50: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5d50: mov             x17, #0xc98a
    //     0x5b5d54: add             lr, x0, x17
    //     0x5b5d58: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5d5c: blr             lr
    // 0x5b5d60: add             SP, SP, #0x10
    // 0x5b5d64: tbnz            w0, #4, #0x5b5d78
    // 0x5b5d68: r0 = Instance_SystemMouseCursor
    //     0x5b5d68: ldr             x0, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0x5b5d6c: LeaveFrame
    //     0x5b5d6c: mov             SP, fp
    //     0x5b5d70: ldp             fp, lr, [SP], #0x10
    // 0x5b5d74: ret
    //     0x5b5d74: ret             
    // 0x5b5d78: r0 = Instance_SystemMouseCursor
    //     0x5b5d78: add             x0, PP, #0x25, lsl #12  ; [pp+0x25ea8] Obj!SystemMouseCursor@b489b1
    //     0x5b5d7c: ldr             x0, [x0, #0xea8]
    // 0x5b5d80: LeaveFrame
    //     0x5b5d80: mov             SP, fp
    //     0x5b5d84: ldp             fp, lr, [SP], #0x10
    // 0x5b5d88: ret
    //     0x5b5d88: ret             
    // 0x5b5d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b5d8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b5d90: b               #0x5b5d34
  }
  get _ splashFactory(/* No info */) {
    // ** addr: 0xce4b98, size: 0x4c
    // 0xce4b98: EnterFrame
    //     0xce4b98: stp             fp, lr, [SP, #-0x10]!
    //     0xce4b9c: mov             fp, SP
    // 0xce4ba0: CheckStackOverflow
    //     0xce4ba0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce4ba4: cmp             SP, x16
    //     0xce4ba8: b.ls            #0xce4bdc
    // 0xce4bac: ldr             x0, [fp, #0x10]
    // 0xce4bb0: LoadField: r1 = r0->field_5f
    //     0xce4bb0: ldur            w1, [x0, #0x5f]
    // 0xce4bb4: DecompressPointer r1
    //     0xce4bb4: add             x1, x1, HEAP, lsl #32
    // 0xce4bb8: SaveReg r1
    //     0xce4bb8: str             x1, [SP, #-8]!
    // 0xce4bbc: r0 = of()
    //     0xce4bbc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xce4bc0: add             SP, SP, #8
    // 0xce4bc4: LoadField: r1 = r0->field_27
    //     0xce4bc4: ldur            w1, [x0, #0x27]
    // 0xce4bc8: DecompressPointer r1
    //     0xce4bc8: add             x1, x1, HEAP, lsl #32
    // 0xce4bcc: mov             x0, x1
    // 0xce4bd0: LeaveFrame
    //     0xce4bd0: mov             SP, fp
    //     0xce4bd4: ldp             fp, lr, [SP], #0x10
    // 0xce4bd8: ret
    //     0xce4bd8: ret             
    // 0xce4bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce4bdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce4be0: b               #0xce4bac
  }
  get _ tapTargetSize(/* No info */) {
    // ** addr: 0xce58d0, size: 0x4c
    // 0xce58d0: EnterFrame
    //     0xce58d0: stp             fp, lr, [SP, #-0x10]!
    //     0xce58d4: mov             fp, SP
    // 0xce58d8: CheckStackOverflow
    //     0xce58d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce58dc: cmp             SP, x16
    //     0xce58e0: b.ls            #0xce5914
    // 0xce58e4: ldr             x0, [fp, #0x10]
    // 0xce58e8: LoadField: r1 = r0->field_5f
    //     0xce58e8: ldur            w1, [x0, #0x5f]
    // 0xce58ec: DecompressPointer r1
    //     0xce58ec: add             x1, x1, HEAP, lsl #32
    // 0xce58f0: SaveReg r1
    //     0xce58f0: str             x1, [SP, #-8]!
    // 0xce58f4: r0 = of()
    //     0xce58f4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xce58f8: add             SP, SP, #8
    // 0xce58fc: LoadField: r1 = r0->field_17
    //     0xce58fc: ldur            w1, [x0, #0x17]
    // 0xce5900: DecompressPointer r1
    //     0xce5900: add             x1, x1, HEAP, lsl #32
    // 0xce5904: mov             x0, x1
    // 0xce5908: LeaveFrame
    //     0xce5908: mov             SP, fp
    //     0xce590c: ldp             fp, lr, [SP], #0x10
    // 0xce5910: ret
    //     0xce5910: ret             
    // 0xce5914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5914: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5918: b               #0xce58e4
  }
  get _ visualDensity(/* No info */) {
    // ** addr: 0xce5938, size: 0x4c
    // 0xce5938: EnterFrame
    //     0xce5938: stp             fp, lr, [SP, #-0x10]!
    //     0xce593c: mov             fp, SP
    // 0xce5940: CheckStackOverflow
    //     0xce5940: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5944: cmp             SP, x16
    //     0xce5948: b.ls            #0xce597c
    // 0xce594c: ldr             x0, [fp, #0x10]
    // 0xce5950: LoadField: r1 = r0->field_5f
    //     0xce5950: ldur            w1, [x0, #0x5f]
    // 0xce5954: DecompressPointer r1
    //     0xce5954: add             x1, x1, HEAP, lsl #32
    // 0xce5958: SaveReg r1
    //     0xce5958: str             x1, [SP, #-8]!
    // 0xce595c: r0 = of()
    //     0xce595c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xce5960: add             SP, SP, #8
    // 0xce5964: LoadField: r1 = r0->field_2f
    //     0xce5964: ldur            w1, [x0, #0x2f]
    // 0xce5968: DecompressPointer r1
    //     0xce5968: add             x1, x1, HEAP, lsl #32
    // 0xce596c: mov             x0, x1
    // 0xce5970: LeaveFrame
    //     0xce5970: mov             SP, fp
    //     0xce5974: ldp             fp, lr, [SP], #0x10
    // 0xce5978: ret
    //     0xce5978: ret             
    // 0xce597c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce597c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5980: b               #0xce594c
  }
  get _ mouseCursor(/* No info */) {
    // ** addr: 0xce5a84, size: 0x50
    // 0xce5a84: EnterFrame
    //     0xce5a84: stp             fp, lr, [SP, #-0x10]!
    //     0xce5a88: mov             fp, SP
    // 0xce5a8c: CheckStackOverflow
    //     0xce5a8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5a90: cmp             SP, x16
    //     0xce5a94: b.ls            #0xce5acc
    // 0xce5a98: r1 = Function '<anonymous closure>':.
    //     0xce5a98: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ff10] AnonymousClosure: (0x5b5d20), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::mouseCursor (0xce5a84)
    //     0xce5a9c: ldr             x1, [x1, #0xf10]
    // 0xce5aa0: r2 = Null
    //     0xce5aa0: mov             x2, NULL
    // 0xce5aa4: r0 = AllocateClosure()
    //     0xce5aa4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce5aa8: r16 = <MouseCursor?>
    //     0xce5aa8: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0xce5aac: ldr             x16, [x16, #0x8b8]
    // 0xce5ab0: stp             x0, x16, [SP, #-0x10]!
    // 0xce5ab4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce5ab4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce5ab8: r0 = resolveWith()
    //     0xce5ab8: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce5abc: add             SP, SP, #0x10
    // 0xce5ac0: LeaveFrame
    //     0xce5ac0: mov             SP, fp
    //     0xce5ac4: ldp             fp, lr, [SP], #0x10
    // 0xce5ac8: ret
    //     0xce5ac8: ret             
    // 0xce5acc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5acc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5ad0: b               #0xce5a98
  }
  get _ shape(/* No info */) {
    // ** addr: 0xce5ae4, size: 0xc
    // 0xce5ae4: r0 = Instance_MaterialStatePropertyAll
    //     0xce5ae4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ff18] Obj!MaterialStatePropertyAll<OutlinedBorder>@b37c91
    //     0xce5ae8: ldr             x0, [x0, #0xf18]
    // 0xce5aec: ret
    //     0xce5aec: ret             
  }
  get _ maximumSize(/* No info */) {
    // ** addr: 0xce5af0, size: 0xc
    // 0xce5af0: r0 = Instance_MaterialStatePropertyAll
    //     0xce5af0: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ff20] Obj!MaterialStatePropertyAll<Size>@b37ca1
    //     0xce5af4: ldr             x0, [x0, #0xf20]
    // 0xce5af8: ret
    //     0xce5af8: ret             
  }
  get _ minimumSize(/* No info */) {
    // ** addr: 0xce5b08, size: 0xc
    // 0xce5b08: r0 = Instance_MaterialStatePropertyAll
    //     0xce5b08: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ff28] Obj!MaterialStatePropertyAll<Size>@b37cc1
    //     0xce5b0c: ldr             x0, [x0, #0xf28]
    // 0xce5b10: ret
    //     0xce5b10: ret             
  }
  get _ padding(/* No info */) {
    // ** addr: 0xce5bd8, size: 0x5c
    // 0xce5bd8: EnterFrame
    //     0xce5bd8: stp             fp, lr, [SP, #-0x10]!
    //     0xce5bdc: mov             fp, SP
    // 0xce5be0: AllocStack(0x8)
    //     0xce5be0: sub             SP, SP, #8
    // 0xce5be4: CheckStackOverflow
    //     0xce5be4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5be8: cmp             SP, x16
    //     0xce5bec: b.ls            #0xce5c2c
    // 0xce5bf0: ldr             x0, [fp, #0x10]
    // 0xce5bf4: LoadField: r1 = r0->field_5f
    //     0xce5bf4: ldur            w1, [x0, #0x5f]
    // 0xce5bf8: DecompressPointer r1
    //     0xce5bf8: add             x1, x1, HEAP, lsl #32
    // 0xce5bfc: SaveReg r1
    //     0xce5bfc: str             x1, [SP, #-8]!
    // 0xce5c00: r0 = _scaledPadding()
    //     0xce5c00: bl              #0xc154e4  ; [package:flutter/src/material/text_button.dart] ::_scaledPadding
    // 0xce5c04: add             SP, SP, #8
    // 0xce5c08: r1 = <EdgeInsetsGeometry>
    //     0xce5c08: add             x1, PP, #0x26, lsl #12  ; [pp+0x268c8] TypeArguments: <EdgeInsetsGeometry>
    //     0xce5c0c: ldr             x1, [x1, #0x8c8]
    // 0xce5c10: stur            x0, [fp, #-8]
    // 0xce5c14: r0 = MaterialStatePropertyAll()
    //     0xce5c14: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0xce5c18: ldur            x1, [fp, #-8]
    // 0xce5c1c: StoreField: r0->field_b = r1
    //     0xce5c1c: stur            w1, [x0, #0xb]
    // 0xce5c20: LeaveFrame
    //     0xce5c20: mov             SP, fp
    //     0xce5c24: ldp             fp, lr, [SP], #0x10
    // 0xce5c28: ret
    //     0xce5c28: ret             
    // 0xce5c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5c2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5c30: b               #0xce5bf0
  }
  get _ elevation(/* No info */) {
    // ** addr: 0xce5db4, size: 0xc
    // 0xce5db4: r0 = Instance_MaterialStatePropertyAll
    //     0xce5db4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ff30] Obj!MaterialStatePropertyAll<double>@b37ce1
    //     0xce5db8: ldr             x0, [x0, #0xf30]
    // 0xce5dbc: ret
    //     0xce5dbc: ret             
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0xce6ed0, size: 0x64
    // 0xce6ed0: EnterFrame
    //     0xce6ed0: stp             fp, lr, [SP, #-0x10]!
    //     0xce6ed4: mov             fp, SP
    // 0xce6ed8: CheckStackOverflow
    //     0xce6ed8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce6edc: cmp             SP, x16
    //     0xce6ee0: b.ls            #0xce6f2c
    // 0xce6ee4: r1 = 1
    //     0xce6ee4: mov             x1, #1
    // 0xce6ee8: r0 = AllocateContext()
    //     0xce6ee8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce6eec: mov             x1, x0
    // 0xce6ef0: ldr             x0, [fp, #0x10]
    // 0xce6ef4: StoreField: r1->field_f = r0
    //     0xce6ef4: stur            w0, [x1, #0xf]
    // 0xce6ef8: mov             x2, x1
    // 0xce6efc: r1 = Function '<anonymous closure>':.
    //     0xce6efc: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ff40] AnonymousClosure: (0xce6f34), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::overlayColor (0xce6ed0)
    //     0xce6f00: ldr             x1, [x1, #0xf40]
    // 0xce6f04: r0 = AllocateClosure()
    //     0xce6f04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce6f08: r16 = <Color?>
    //     0xce6f08: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce6f0c: ldr             x16, [x16, #0xf68]
    // 0xce6f10: stp             x0, x16, [SP, #-0x10]!
    // 0xce6f14: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce6f14: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce6f18: r0 = resolveWith()
    //     0xce6f18: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce6f1c: add             SP, SP, #0x10
    // 0xce6f20: LeaveFrame
    //     0xce6f20: mov             SP, fp
    //     0xce6f24: ldp             fp, lr, [SP], #0x10
    // 0xce6f28: ret
    //     0xce6f28: ret             
    // 0xce6f2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce6f2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce6f30: b               #0xce6ee4
  }
  [closure] Color? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce6f34, size: 0x1f4
    // 0xce6f34: EnterFrame
    //     0xce6f34: stp             fp, lr, [SP, #-0x10]!
    //     0xce6f38: mov             fp, SP
    // 0xce6f3c: AllocStack(0x8)
    //     0xce6f3c: sub             SP, SP, #8
    // 0xce6f40: SetupParameters()
    //     0xce6f40: ldr             x0, [fp, #0x18]
    //     0xce6f44: ldur            w1, [x0, #0x17]
    //     0xce6f48: add             x1, x1, HEAP, lsl #32
    //     0xce6f4c: stur            x1, [fp, #-8]
    // 0xce6f50: CheckStackOverflow
    //     0xce6f50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce6f54: cmp             SP, x16
    //     0xce6f58: b.ls            #0xce7120
    // 0xce6f5c: ldr             x2, [fp, #0x10]
    // 0xce6f60: r0 = LoadClassIdInstr(r2)
    //     0xce6f60: ldur            x0, [x2, #-1]
    //     0xce6f64: ubfx            x0, x0, #0xc, #0x14
    // 0xce6f68: r16 = Instance_MaterialState
    //     0xce6f68: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xce6f6c: ldr             x16, [x16, #0xf78]
    // 0xce6f70: stp             x16, x2, [SP, #-0x10]!
    // 0xce6f74: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6f74: mov             x17, #0xc98a
    //     0xce6f78: add             lr, x0, x17
    //     0xce6f7c: ldr             lr, [x21, lr, lsl #3]
    //     0xce6f80: blr             lr
    // 0xce6f84: add             SP, SP, #0x10
    // 0xce6f88: tbnz            w0, #4, #0xce6fe8
    // 0xce6f8c: ldur            x1, [fp, #-8]
    // 0xce6f90: LoadField: r0 = r1->field_f
    //     0xce6f90: ldur            w0, [x1, #0xf]
    // 0xce6f94: DecompressPointer r0
    //     0xce6f94: add             x0, x0, HEAP, lsl #32
    // 0xce6f98: mov             x1, x0
    // 0xce6f9c: LoadField: r0 = r1->field_63
    //     0xce6f9c: ldur            w0, [x1, #0x63]
    // 0xce6fa0: DecompressPointer r0
    //     0xce6fa0: add             x0, x0, HEAP, lsl #32
    // 0xce6fa4: r16 = Sentinel
    //     0xce6fa4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6fa8: cmp             w0, w16
    // 0xce6fac: b.ne            #0xce6fbc
    // 0xce6fb0: r2 = _colors
    //     0xce6fb0: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3ff48] Field <_TextButtonDefaultsM3@821343580._colors@821343580>: late final (offset: 0x64)
    //     0xce6fb4: ldr             x2, [x2, #0xf48]
    // 0xce6fb8: r0 = InitLateFinalInstanceField()
    //     0xce6fb8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6fbc: LoadField: r1 = r0->field_b
    //     0xce6fbc: ldur            w1, [x0, #0xb]
    // 0xce6fc0: DecompressPointer r1
    //     0xce6fc0: add             x1, x1, HEAP, lsl #32
    // 0xce6fc4: SaveReg r1
    //     0xce6fc4: str             x1, [SP, #-8]!
    // 0xce6fc8: d0 = 0.080000
    //     0xce6fc8: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xce6fcc: ldr             d0, [x17, #0xf80]
    // 0xce6fd0: SaveReg d0
    //     0xce6fd0: str             d0, [SP, #-8]!
    // 0xce6fd4: r0 = withOpacity()
    //     0xce6fd4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6fd8: add             SP, SP, #0x10
    // 0xce6fdc: LeaveFrame
    //     0xce6fdc: mov             SP, fp
    //     0xce6fe0: ldp             fp, lr, [SP], #0x10
    // 0xce6fe4: ret
    //     0xce6fe4: ret             
    // 0xce6fe8: ldr             x2, [fp, #0x10]
    // 0xce6fec: ldur            x1, [fp, #-8]
    // 0xce6ff0: r0 = LoadClassIdInstr(r2)
    //     0xce6ff0: ldur            x0, [x2, #-1]
    //     0xce6ff4: ubfx            x0, x0, #0xc, #0x14
    // 0xce6ff8: r16 = Instance_MaterialState
    //     0xce6ff8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0xce6ffc: ldr             x16, [x16, #0xf88]
    // 0xce7000: stp             x16, x2, [SP, #-0x10]!
    // 0xce7004: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce7004: mov             x17, #0xc98a
    //     0xce7008: add             lr, x0, x17
    //     0xce700c: ldr             lr, [x21, lr, lsl #3]
    //     0xce7010: blr             lr
    // 0xce7014: add             SP, SP, #0x10
    // 0xce7018: tbnz            w0, #4, #0xce7078
    // 0xce701c: ldur            x1, [fp, #-8]
    // 0xce7020: LoadField: r0 = r1->field_f
    //     0xce7020: ldur            w0, [x1, #0xf]
    // 0xce7024: DecompressPointer r0
    //     0xce7024: add             x0, x0, HEAP, lsl #32
    // 0xce7028: mov             x1, x0
    // 0xce702c: LoadField: r0 = r1->field_63
    //     0xce702c: ldur            w0, [x1, #0x63]
    // 0xce7030: DecompressPointer r0
    //     0xce7030: add             x0, x0, HEAP, lsl #32
    // 0xce7034: r16 = Sentinel
    //     0xce7034: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7038: cmp             w0, w16
    // 0xce703c: b.ne            #0xce704c
    // 0xce7040: r2 = _colors
    //     0xce7040: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3ff48] Field <_TextButtonDefaultsM3@821343580._colors@821343580>: late final (offset: 0x64)
    //     0xce7044: ldr             x2, [x2, #0xf48]
    // 0xce7048: r0 = InitLateFinalInstanceField()
    //     0xce7048: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce704c: LoadField: r1 = r0->field_b
    //     0xce704c: ldur            w1, [x0, #0xb]
    // 0xce7050: DecompressPointer r1
    //     0xce7050: add             x1, x1, HEAP, lsl #32
    // 0xce7054: SaveReg r1
    //     0xce7054: str             x1, [SP, #-8]!
    // 0xce7058: d0 = 0.120000
    //     0xce7058: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce705c: ldr             d0, [x17, #0xf48]
    // 0xce7060: SaveReg d0
    //     0xce7060: str             d0, [SP, #-8]!
    // 0xce7064: r0 = withOpacity()
    //     0xce7064: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce7068: add             SP, SP, #0x10
    // 0xce706c: LeaveFrame
    //     0xce706c: mov             SP, fp
    //     0xce7070: ldp             fp, lr, [SP], #0x10
    // 0xce7074: ret
    //     0xce7074: ret             
    // 0xce7078: ldr             x0, [fp, #0x10]
    // 0xce707c: ldur            x1, [fp, #-8]
    // 0xce7080: d0 = 0.120000
    //     0xce7080: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce7084: ldr             d0, [x17, #0xf48]
    // 0xce7088: r2 = LoadClassIdInstr(r0)
    //     0xce7088: ldur            x2, [x0, #-1]
    //     0xce708c: ubfx            x2, x2, #0xc, #0x14
    // 0xce7090: r16 = Instance_MaterialState
    //     0xce7090: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0xce7094: ldr             x16, [x16, #0xf90]
    // 0xce7098: stp             x16, x0, [SP, #-0x10]!
    // 0xce709c: mov             x0, x2
    // 0xce70a0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce70a0: mov             x17, #0xc98a
    //     0xce70a4: add             lr, x0, x17
    //     0xce70a8: ldr             lr, [x21, lr, lsl #3]
    //     0xce70ac: blr             lr
    // 0xce70b0: add             SP, SP, #0x10
    // 0xce70b4: tbnz            w0, #4, #0xce7110
    // 0xce70b8: ldur            x0, [fp, #-8]
    // 0xce70bc: LoadField: r1 = r0->field_f
    //     0xce70bc: ldur            w1, [x0, #0xf]
    // 0xce70c0: DecompressPointer r1
    //     0xce70c0: add             x1, x1, HEAP, lsl #32
    // 0xce70c4: LoadField: r0 = r1->field_63
    //     0xce70c4: ldur            w0, [x1, #0x63]
    // 0xce70c8: DecompressPointer r0
    //     0xce70c8: add             x0, x0, HEAP, lsl #32
    // 0xce70cc: r16 = Sentinel
    //     0xce70cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce70d0: cmp             w0, w16
    // 0xce70d4: b.ne            #0xce70e4
    // 0xce70d8: r2 = _colors
    //     0xce70d8: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3ff48] Field <_TextButtonDefaultsM3@821343580._colors@821343580>: late final (offset: 0x64)
    //     0xce70dc: ldr             x2, [x2, #0xf48]
    // 0xce70e0: r0 = InitLateFinalInstanceField()
    //     0xce70e0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce70e4: LoadField: r1 = r0->field_b
    //     0xce70e4: ldur            w1, [x0, #0xb]
    // 0xce70e8: DecompressPointer r1
    //     0xce70e8: add             x1, x1, HEAP, lsl #32
    // 0xce70ec: SaveReg r1
    //     0xce70ec: str             x1, [SP, #-8]!
    // 0xce70f0: d0 = 0.120000
    //     0xce70f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce70f4: ldr             d0, [x17, #0xf48]
    // 0xce70f8: SaveReg d0
    //     0xce70f8: str             d0, [SP, #-8]!
    // 0xce70fc: r0 = withOpacity()
    //     0xce70fc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce7100: add             SP, SP, #0x10
    // 0xce7104: LeaveFrame
    //     0xce7104: mov             SP, fp
    //     0xce7108: ldp             fp, lr, [SP], #0x10
    // 0xce710c: ret
    //     0xce710c: ret             
    // 0xce7110: r0 = Null
    //     0xce7110: mov             x0, NULL
    // 0xce7114: LeaveFrame
    //     0xce7114: mov             SP, fp
    //     0xce7118: ldp             fp, lr, [SP], #0x10
    // 0xce711c: ret
    //     0xce711c: ret             
    // 0xce7120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce7120: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce7124: b               #0xce6f5c
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0xce79c4, size: 0x64
    // 0xce79c4: EnterFrame
    //     0xce79c4: stp             fp, lr, [SP, #-0x10]!
    //     0xce79c8: mov             fp, SP
    // 0xce79cc: CheckStackOverflow
    //     0xce79cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce79d0: cmp             SP, x16
    //     0xce79d4: b.ls            #0xce7a20
    // 0xce79d8: r1 = 1
    //     0xce79d8: mov             x1, #1
    // 0xce79dc: r0 = AllocateContext()
    //     0xce79dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce79e0: mov             x1, x0
    // 0xce79e4: ldr             x0, [fp, #0x10]
    // 0xce79e8: StoreField: r1->field_f = r0
    //     0xce79e8: stur            w0, [x1, #0xf]
    // 0xce79ec: mov             x2, x1
    // 0xce79f0: r1 = Function '<anonymous closure>':.
    //     0xce79f0: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ff50] AnonymousClosure: (0xce7a28), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::foregroundColor (0xce79c4)
    //     0xce79f4: ldr             x1, [x1, #0xf50]
    // 0xce79f8: r0 = AllocateClosure()
    //     0xce79f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce79fc: r16 = <Color?>
    //     0xce79fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce7a00: ldr             x16, [x16, #0xf68]
    // 0xce7a04: stp             x0, x16, [SP, #-0x10]!
    // 0xce7a08: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce7a08: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce7a0c: r0 = resolveWith()
    //     0xce7a0c: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce7a10: add             SP, SP, #0x10
    // 0xce7a14: LeaveFrame
    //     0xce7a14: mov             SP, fp
    //     0xce7a18: ldp             fp, lr, [SP], #0x10
    // 0xce7a1c: ret
    //     0xce7a1c: ret             
    // 0xce7a20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce7a20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce7a24: b               #0xce79d8
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce7a28, size: 0x100
    // 0xce7a28: EnterFrame
    //     0xce7a28: stp             fp, lr, [SP, #-0x10]!
    //     0xce7a2c: mov             fp, SP
    // 0xce7a30: AllocStack(0x8)
    //     0xce7a30: sub             SP, SP, #8
    // 0xce7a34: SetupParameters()
    //     0xce7a34: ldr             x0, [fp, #0x18]
    //     0xce7a38: ldur            w1, [x0, #0x17]
    //     0xce7a3c: add             x1, x1, HEAP, lsl #32
    //     0xce7a40: stur            x1, [fp, #-8]
    // 0xce7a44: CheckStackOverflow
    //     0xce7a44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce7a48: cmp             SP, x16
    //     0xce7a4c: b.ls            #0xce7b20
    // 0xce7a50: ldr             x0, [fp, #0x10]
    // 0xce7a54: r2 = LoadClassIdInstr(r0)
    //     0xce7a54: ldur            x2, [x0, #-1]
    //     0xce7a58: ubfx            x2, x2, #0xc, #0x14
    // 0xce7a5c: r16 = Instance_MaterialState
    //     0xce7a5c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0xce7a60: ldr             x16, [x16, #0x2a0]
    // 0xce7a64: stp             x16, x0, [SP, #-0x10]!
    // 0xce7a68: mov             x0, x2
    // 0xce7a6c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce7a6c: mov             x17, #0xc98a
    //     0xce7a70: add             lr, x0, x17
    //     0xce7a74: ldr             lr, [x21, lr, lsl #3]
    //     0xce7a78: blr             lr
    // 0xce7a7c: add             SP, SP, #0x10
    // 0xce7a80: tbnz            w0, #4, #0xce7adc
    // 0xce7a84: ldur            x0, [fp, #-8]
    // 0xce7a88: LoadField: r1 = r0->field_f
    //     0xce7a88: ldur            w1, [x0, #0xf]
    // 0xce7a8c: DecompressPointer r1
    //     0xce7a8c: add             x1, x1, HEAP, lsl #32
    // 0xce7a90: LoadField: r0 = r1->field_63
    //     0xce7a90: ldur            w0, [x1, #0x63]
    // 0xce7a94: DecompressPointer r0
    //     0xce7a94: add             x0, x0, HEAP, lsl #32
    // 0xce7a98: r16 = Sentinel
    //     0xce7a98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7a9c: cmp             w0, w16
    // 0xce7aa0: b.ne            #0xce7ab0
    // 0xce7aa4: r2 = _colors
    //     0xce7aa4: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3ff48] Field <_TextButtonDefaultsM3@821343580._colors@821343580>: late final (offset: 0x64)
    //     0xce7aa8: ldr             x2, [x2, #0xf48]
    // 0xce7aac: r0 = InitLateFinalInstanceField()
    //     0xce7aac: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce7ab0: LoadField: r1 = r0->field_57
    //     0xce7ab0: ldur            w1, [x0, #0x57]
    // 0xce7ab4: DecompressPointer r1
    //     0xce7ab4: add             x1, x1, HEAP, lsl #32
    // 0xce7ab8: SaveReg r1
    //     0xce7ab8: str             x1, [SP, #-8]!
    // 0xce7abc: d0 = 0.380000
    //     0xce7abc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xce7ac0: ldr             d0, [x17, #0x140]
    // 0xce7ac4: SaveReg d0
    //     0xce7ac4: str             d0, [SP, #-8]!
    // 0xce7ac8: r0 = withOpacity()
    //     0xce7ac8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce7acc: add             SP, SP, #0x10
    // 0xce7ad0: LeaveFrame
    //     0xce7ad0: mov             SP, fp
    //     0xce7ad4: ldp             fp, lr, [SP], #0x10
    // 0xce7ad8: ret
    //     0xce7ad8: ret             
    // 0xce7adc: ldur            x0, [fp, #-8]
    // 0xce7ae0: LoadField: r1 = r0->field_f
    //     0xce7ae0: ldur            w1, [x0, #0xf]
    // 0xce7ae4: DecompressPointer r1
    //     0xce7ae4: add             x1, x1, HEAP, lsl #32
    // 0xce7ae8: LoadField: r0 = r1->field_63
    //     0xce7ae8: ldur            w0, [x1, #0x63]
    // 0xce7aec: DecompressPointer r0
    //     0xce7aec: add             x0, x0, HEAP, lsl #32
    // 0xce7af0: r16 = Sentinel
    //     0xce7af0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7af4: cmp             w0, w16
    // 0xce7af8: b.ne            #0xce7b08
    // 0xce7afc: r2 = _colors
    //     0xce7afc: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3ff48] Field <_TextButtonDefaultsM3@821343580._colors@821343580>: late final (offset: 0x64)
    //     0xce7b00: ldr             x2, [x2, #0xf48]
    // 0xce7b04: r0 = InitLateFinalInstanceField()
    //     0xce7b04: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce7b08: LoadField: r1 = r0->field_b
    //     0xce7b08: ldur            w1, [x0, #0xb]
    // 0xce7b0c: DecompressPointer r1
    //     0xce7b0c: add             x1, x1, HEAP, lsl #32
    // 0xce7b10: mov             x0, x1
    // 0xce7b14: LeaveFrame
    //     0xce7b14: mov             SP, fp
    //     0xce7b18: ldp             fp, lr, [SP], #0x10
    // 0xce7b1c: ret
    //     0xce7b1c: ret             
    // 0xce7b20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce7b20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce7b24: b               #0xce7a50
  }
  get _ backgroundColor(/* No info */) {
    // ** addr: 0xce7c98, size: 0xc
    // 0xce7c98: r0 = Instance_MaterialStatePropertyAll
    //     0xce7c98: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3ff38] Obj!MaterialStatePropertyAll<Color>@b37d01
    //     0xce7c9c: ldr             x0, [x0, #0xf38]
    // 0xce7ca0: ret
    //     0xce7ca0: ret             
  }
  get _ textStyle(/* No info */) {
    // ** addr: 0xce7fa0, size: 0x6c
    // 0xce7fa0: EnterFrame
    //     0xce7fa0: stp             fp, lr, [SP, #-0x10]!
    //     0xce7fa4: mov             fp, SP
    // 0xce7fa8: AllocStack(0x8)
    //     0xce7fa8: sub             SP, SP, #8
    // 0xce7fac: CheckStackOverflow
    //     0xce7fac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce7fb0: cmp             SP, x16
    //     0xce7fb4: b.ls            #0xce8004
    // 0xce7fb8: ldr             x0, [fp, #0x10]
    // 0xce7fbc: LoadField: r1 = r0->field_5f
    //     0xce7fbc: ldur            w1, [x0, #0x5f]
    // 0xce7fc0: DecompressPointer r1
    //     0xce7fc0: add             x1, x1, HEAP, lsl #32
    // 0xce7fc4: SaveReg r1
    //     0xce7fc4: str             x1, [SP, #-8]!
    // 0xce7fc8: r0 = of()
    //     0xce7fc8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xce7fcc: add             SP, SP, #8
    // 0xce7fd0: LoadField: r1 = r0->field_93
    //     0xce7fd0: ldur            w1, [x0, #0x93]
    // 0xce7fd4: DecompressPointer r1
    //     0xce7fd4: add             x1, x1, HEAP, lsl #32
    // 0xce7fd8: LoadField: r0 = r1->field_37
    //     0xce7fd8: ldur            w0, [x1, #0x37]
    // 0xce7fdc: DecompressPointer r0
    //     0xce7fdc: add             x0, x0, HEAP, lsl #32
    // 0xce7fe0: stur            x0, [fp, #-8]
    // 0xce7fe4: r1 = <TextStyle?>
    //     0xce7fe4: add             x1, PP, #0x26, lsl #12  ; [pp+0x268c0] TypeArguments: <TextStyle?>
    //     0xce7fe8: ldr             x1, [x1, #0x8c0]
    // 0xce7fec: r0 = MaterialStatePropertyAll()
    //     0xce7fec: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0xce7ff0: ldur            x1, [fp, #-8]
    // 0xce7ff4: StoreField: r0->field_b = r1
    //     0xce7ff4: stur            w1, [x0, #0xb]
    // 0xce7ff8: LeaveFrame
    //     0xce7ff8: mov             SP, fp
    //     0xce7ffc: ldp             fp, lr, [SP], #0x10
    // 0xce8000: ret
    //     0xce8000: ret             
    // 0xce8004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce8004: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce8008: b               #0xce7fb8
  }
}

// class id: 3842, size: 0x14, field offset: 0xc
//   const constructor, 
class _TextButtonWithIconChild extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb24150, size: 0x2c4
    // 0xb24150: EnterFrame
    //     0xb24150: stp             fp, lr, [SP, #-0x10]!
    //     0xb24154: mov             fp, SP
    // 0xb24158: AllocStack(0x28)
    //     0xb24158: sub             SP, SP, #0x28
    // 0xb2415c: CheckStackOverflow
    //     0xb2415c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb24160: cmp             SP, x16
    //     0xb24164: b.ls            #0xb243cc
    // 0xb24168: ldr             x16, [fp, #0x10]
    // 0xb2416c: SaveReg r16
    //     0xb2416c: str             x16, [SP, #-8]!
    // 0xb24170: r0 = maybeOf()
    //     0xb24170: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0xb24174: add             SP, SP, #8
    // 0xb24178: cmp             w0, NULL
    // 0xb2417c: b.ne            #0xb24188
    // 0xb24180: r0 = Null
    //     0xb24180: mov             x0, NULL
    // 0xb24184: b               #0xb241b4
    // 0xb24188: LoadField: d0 = r0->field_13
    //     0xb24188: ldur            d0, [x0, #0x13]
    // 0xb2418c: r0 = inline_Allocate_Double()
    //     0xb2418c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb24190: add             x0, x0, #0x10
    //     0xb24194: cmp             x1, x0
    //     0xb24198: b.ls            #0xb243d4
    //     0xb2419c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb241a0: sub             x0, x0, #0xf
    //     0xb241a4: mov             x1, #0xd108
    //     0xb241a8: movk            x1, #3, lsl #16
    //     0xb241ac: stur            x1, [x0, #-1]
    // 0xb241b0: StoreField: r0->field_7 = d0
    //     0xb241b0: stur            d0, [x0, #7]
    // 0xb241b4: cmp             w0, NULL
    // 0xb241b8: b.ne            #0xb241c4
    // 0xb241bc: d1 = 1.000000
    //     0xb241bc: fmov            d1, #1.00000000
    // 0xb241c0: b               #0xb241cc
    // 0xb241c4: LoadField: d0 = r0->field_7
    //     0xb241c4: ldur            d0, [x0, #7]
    // 0xb241c8: mov             v1.16b, v0.16b
    // 0xb241cc: d0 = 1.000000
    //     0xb241cc: fmov            d0, #1.00000000
    // 0xb241d0: fcmp            d1, d0
    // 0xb241d4: b.vs            #0xb241e4
    // 0xb241d8: b.gt            #0xb241e4
    // 0xb241dc: d0 = 8.000000
    //     0xb241dc: fmov            d0, #8.00000000
    // 0xb241e0: b               #0xb242b0
    // 0xb241e4: fsub            d2, d1, d0
    // 0xb241e8: stur            d2, [fp, #-0x28]
    // 0xb241ec: fcmp            d2, d0
    // 0xb241f0: b.vs            #0xb24200
    // 0xb241f4: b.le            #0xb24200
    // 0xb241f8: d0 = 1.000000
    //     0xb241f8: fmov            d0, #1.00000000
    // 0xb241fc: b               #0xb24264
    // 0xb24200: fcmp            d2, d0
    // 0xb24204: b.vs            #0xb24214
    // 0xb24208: b.ge            #0xb24214
    // 0xb2420c: mov             v0.16b, v2.16b
    // 0xb24210: b               #0xb24264
    // 0xb24214: d1 = 0.000000
    //     0xb24214: eor             v1.16b, v1.16b, v1.16b
    // 0xb24218: fcmp            d2, d1
    // 0xb2421c: b.vs            #0xb24224
    // 0xb24220: b.eq            #0xb2422c
    // 0xb24224: r0 = false
    //     0xb24224: add             x0, NULL, #0x30  ; false
    // 0xb24228: b               #0xb24230
    // 0xb2422c: r0 = true
    //     0xb2422c: add             x0, NULL, #0x20  ; true
    // 0xb24230: tbnz            w0, #4, #0xb24240
    // 0xb24234: fadd            d1, d2, d0
    // 0xb24238: fmul            d0, d1, d2
    // 0xb2423c: b               #0xb24264
    // 0xb24240: tbnz            w0, #4, #0xb24260
    // 0xb24244: r16 = 1.000000
    //     0xb24244: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb24248: SaveReg r16
    //     0xb24248: str             x16, [SP, #-8]!
    // 0xb2424c: r0 = isNegative()
    //     0xb2424c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xb24250: add             SP, SP, #8
    // 0xb24254: tbnz            w0, #4, #0xb24260
    // 0xb24258: d0 = 1.000000
    //     0xb24258: fmov            d0, #1.00000000
    // 0xb2425c: b               #0xb24264
    // 0xb24260: ldur            d0, [fp, #-0x28]
    // 0xb24264: r0 = inline_Allocate_Double()
    //     0xb24264: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb24268: add             x0, x0, #0x10
    //     0xb2426c: cmp             x1, x0
    //     0xb24270: b.ls            #0xb243e4
    //     0xb24274: str             x0, [THR, #0x60]  ; THR::top
    //     0xb24278: sub             x0, x0, #0xf
    //     0xb2427c: mov             x1, #0xd108
    //     0xb24280: movk            x1, #3, lsl #16
    //     0xb24284: stur            x1, [x0, #-1]
    // 0xb24288: StoreField: r0->field_7 = d0
    //     0xb24288: stur            d0, [x0, #7]
    // 0xb2428c: r16 = 16
    //     0xb2428c: mov             x16, #0x10
    // 0xb24290: r30 = 8
    //     0xb24290: mov             lr, #8
    // 0xb24294: stp             lr, x16, [SP, #-0x10]!
    // 0xb24298: SaveReg r0
    //     0xb24298: str             x0, [SP, #-8]!
    // 0xb2429c: r0 = lerpDouble()
    //     0xb2429c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xb242a0: add             SP, SP, #0x18
    // 0xb242a4: cmp             w0, NULL
    // 0xb242a8: b.eq            #0xb243f4
    // 0xb242ac: LoadField: d0 = r0->field_7
    //     0xb242ac: ldur            d0, [x0, #7]
    // 0xb242b0: ldr             x0, [fp, #0x18]
    // 0xb242b4: LoadField: r1 = r0->field_f
    //     0xb242b4: ldur            w1, [x0, #0xf]
    // 0xb242b8: DecompressPointer r1
    //     0xb242b8: add             x1, x1, HEAP, lsl #32
    // 0xb242bc: stur            x1, [fp, #-0x10]
    // 0xb242c0: r2 = inline_Allocate_Double()
    //     0xb242c0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb242c4: add             x2, x2, #0x10
    //     0xb242c8: cmp             x3, x2
    //     0xb242cc: b.ls            #0xb243f8
    //     0xb242d0: str             x2, [THR, #0x60]  ; THR::top
    //     0xb242d4: sub             x2, x2, #0xf
    //     0xb242d8: mov             x3, #0xd108
    //     0xb242dc: movk            x3, #3, lsl #16
    //     0xb242e0: stur            x3, [x2, #-1]
    // 0xb242e4: StoreField: r2->field_7 = d0
    //     0xb242e4: stur            d0, [x2, #7]
    // 0xb242e8: stur            x2, [fp, #-8]
    // 0xb242ec: r0 = SizedBox()
    //     0xb242ec: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xb242f0: mov             x2, x0
    // 0xb242f4: ldur            x0, [fp, #-8]
    // 0xb242f8: stur            x2, [fp, #-0x18]
    // 0xb242fc: StoreField: r2->field_f = r0
    //     0xb242fc: stur            w0, [x2, #0xf]
    // 0xb24300: ldr             x0, [fp, #0x18]
    // 0xb24304: LoadField: r3 = r0->field_b
    //     0xb24304: ldur            w3, [x0, #0xb]
    // 0xb24308: DecompressPointer r3
    //     0xb24308: add             x3, x3, HEAP, lsl #32
    // 0xb2430c: stur            x3, [fp, #-8]
    // 0xb24310: r1 = <FlexParentData<RenderBox>>
    //     0xb24310: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f2f8] TypeArguments: <FlexParentData<RenderBox>>
    //     0xb24314: ldr             x1, [x1, #0x2f8]
    // 0xb24318: r0 = Flexible()
    //     0xb24318: bl              #0x825240  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xb2431c: mov             x3, x0
    // 0xb24320: r0 = 1
    //     0xb24320: mov             x0, #1
    // 0xb24324: stur            x3, [fp, #-0x20]
    // 0xb24328: StoreField: r3->field_13 = r0
    //     0xb24328: stur            x0, [x3, #0x13]
    // 0xb2432c: r0 = Instance_FlexFit
    //     0xb2432c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c48] Obj!FlexFit@b64bb1
    //     0xb24330: ldr             x0, [x0, #0xc48]
    // 0xb24334: StoreField: r3->field_1b = r0
    //     0xb24334: stur            w0, [x3, #0x1b]
    // 0xb24338: ldur            x0, [fp, #-8]
    // 0xb2433c: StoreField: r3->field_b = r0
    //     0xb2433c: stur            w0, [x3, #0xb]
    // 0xb24340: r1 = Null
    //     0xb24340: mov             x1, NULL
    // 0xb24344: r2 = 6
    //     0xb24344: mov             x2, #6
    // 0xb24348: r0 = AllocateArray()
    //     0xb24348: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb2434c: mov             x2, x0
    // 0xb24350: ldur            x0, [fp, #-0x10]
    // 0xb24354: stur            x2, [fp, #-8]
    // 0xb24358: StoreField: r2->field_f = r0
    //     0xb24358: stur            w0, [x2, #0xf]
    // 0xb2435c: ldur            x0, [fp, #-0x18]
    // 0xb24360: StoreField: r2->field_13 = r0
    //     0xb24360: stur            w0, [x2, #0x13]
    // 0xb24364: ldur            x0, [fp, #-0x20]
    // 0xb24368: StoreField: r2->field_17 = r0
    //     0xb24368: stur            w0, [x2, #0x17]
    // 0xb2436c: r1 = <Widget>
    //     0xb2436c: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb24370: ldr             x1, [x1, #0xea8]
    // 0xb24374: r0 = AllocateGrowableArray()
    //     0xb24374: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xb24378: mov             x1, x0
    // 0xb2437c: ldur            x0, [fp, #-8]
    // 0xb24380: stur            x1, [fp, #-0x10]
    // 0xb24384: StoreField: r1->field_f = r0
    //     0xb24384: stur            w0, [x1, #0xf]
    // 0xb24388: r0 = 6
    //     0xb24388: mov             x0, #6
    // 0xb2438c: StoreField: r1->field_b = r0
    //     0xb2438c: stur            w0, [x1, #0xb]
    // 0xb24390: r0 = Row()
    //     0xb24390: bl              #0x8236c8  ; AllocateRowStub -> Row (size=0x30)
    // 0xb24394: stur            x0, [fp, #-8]
    // 0xb24398: ldur            x16, [fp, #-0x10]
    // 0xb2439c: stp             x16, x0, [SP, #-0x10]!
    // 0xb243a0: r16 = Instance_MainAxisSize
    //     0xb243a0: add             x16, PP, #0xe, lsl #12  ; [pp+0xeeb0] Obj!MainAxisSize@b64b71
    //     0xb243a4: ldr             x16, [x16, #0xeb0]
    // 0xb243a8: SaveReg r16
    //     0xb243a8: str             x16, [SP, #-8]!
    // 0xb243ac: r4 = const [0, 0x3, 0x3, 0x2, mainAxisSize, 0x2, null]
    //     0xb243ac: add             x4, PP, #0xe, lsl #12  ; [pp+0xeeb8] List(7) [0, 0x3, 0x3, 0x2, "mainAxisSize", 0x2, Null]
    //     0xb243b0: ldr             x4, [x4, #0xeb8]
    // 0xb243b4: r0 = Row()
    //     0xb243b4: bl              #0x8232c8  ; [package:flutter/src/widgets/basic.dart] Row::Row
    // 0xb243b8: add             SP, SP, #0x18
    // 0xb243bc: ldur            x0, [fp, #-8]
    // 0xb243c0: LeaveFrame
    //     0xb243c0: mov             SP, fp
    //     0xb243c4: ldp             fp, lr, [SP], #0x10
    // 0xb243c8: ret
    //     0xb243c8: ret             
    // 0xb243cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb243cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb243d0: b               #0xb24168
    // 0xb243d4: SaveReg d0
    //     0xb243d4: str             q0, [SP, #-0x10]!
    // 0xb243d8: r0 = AllocateDouble()
    //     0xb243d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb243dc: RestoreReg d0
    //     0xb243dc: ldr             q0, [SP], #0x10
    // 0xb243e0: b               #0xb241b0
    // 0xb243e4: SaveReg d0
    //     0xb243e4: str             q0, [SP, #-0x10]!
    // 0xb243e8: r0 = AllocateDouble()
    //     0xb243e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb243ec: RestoreReg d0
    //     0xb243ec: ldr             q0, [SP], #0x10
    // 0xb243f0: b               #0xb24288
    // 0xb243f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb243f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb243f8: SaveReg d0
    //     0xb243f8: str             q0, [SP, #-0x10]!
    // 0xb243fc: stp             x0, x1, [SP, #-0x10]!
    // 0xb24400: r0 = AllocateDouble()
    //     0xb24400: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb24404: mov             x2, x0
    // 0xb24408: ldp             x0, x1, [SP], #0x10
    // 0xb2440c: RestoreReg d0
    //     0xb2440c: ldr             q0, [SP], #0x10
    // 0xb24410: b               #0xb242e4
  }
}

// class id: 4161, size: 0x34, field offset: 0x34
//   const constructor, 
class TextButton extends ButtonStyleButton {

  static _ styleFrom(/* No info */) {
    // ** addr: 0xb1e558, size: 0x8c4
    // 0xb1e558: EnterFrame
    //     0xb1e558: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e55c: mov             fp, SP
    // 0xb1e560: AllocStack(0x98)
    //     0xb1e560: sub             SP, SP, #0x98
    // 0xb1e564: SetupParameters(dynamic _ /* r3, fp-0x98 */, dynamic _ /* fp-0x8 */, dynamic _ /* r5, fp-0x90 */, dynamic _ /* r6, fp-0x88 */, {dynamic alignment = Null /* r7, fp-0x80 */, dynamic animationDuration = Null /* r8, fp-0x78 */, dynamic backgroundColor = Null /* r9, fp-0x70 */, dynamic disabledBackgroundColor = Null /* r10, fp-0x68 */, dynamic disabledForegroundColor = Null /* r11 */, dynamic disabledMouseCursor = Null /* r12, fp-0x60 */, dynamic elevation = Null /* r13, fp-0x58 */, dynamic enableFeedback = Null /* r14, fp-0x50 */, dynamic enabledMouseCursor = Null /* r19, fp-0x48 */, dynamic maximumSize = Null /* r20, fp-0x40 */, dynamic shadowColor = Null /* fp-0x10 */, dynamic splashFactory = Null /* fp-0x18 */, dynamic tapTargetSize = Null /* fp-0x20 */, dynamic textStyle = Null /* r4, fp-0x38 */, dynamic visualDensity = Null /* r0, fp-0x30 */})
    //     0xb1e564: mov             x0, x4
    //     0xb1e568: ldur            w1, [x0, #0x13]
    //     0xb1e56c: add             x1, x1, HEAP, lsl #32
    //     0xb1e570: sub             x2, x1, #8
    //     0xb1e574: add             x3, fp, w2, sxtw #2
    //     0xb1e578: ldr             x3, [x3, #0x28]
    //     0xb1e57c: stur            x3, [fp, #-0x98]
    //     0xb1e580: add             x4, fp, w2, sxtw #2
    //     0xb1e584: ldr             x4, [x4, #0x20]
    //     0xb1e588: stur            x4, [fp, #-8]
    //     0xb1e58c: add             x5, fp, w2, sxtw #2
    //     0xb1e590: ldr             x5, [x5, #0x18]
    //     0xb1e594: stur            x5, [fp, #-0x90]
    //     0xb1e598: add             x6, fp, w2, sxtw #2
    //     0xb1e59c: ldr             x6, [x6, #0x10]
    //     0xb1e5a0: stur            x6, [fp, #-0x88]
    //     0xb1e5a4: ldur            w2, [x0, #0x1f]
    //     0xb1e5a8: add             x2, x2, HEAP, lsl #32
    //     0xb1e5ac: add             x16, PP, #0xd, lsl #12  ; [pp+0xdad8] "alignment"
    //     0xb1e5b0: ldr             x16, [x16, #0xad8]
    //     0xb1e5b4: cmp             w2, w16
    //     0xb1e5b8: b.ne            #0xb1e5dc
    //     0xb1e5bc: ldur            w2, [x0, #0x23]
    //     0xb1e5c0: add             x2, x2, HEAP, lsl #32
    //     0xb1e5c4: sub             w7, w1, w2
    //     0xb1e5c8: add             x2, fp, w7, sxtw #2
    //     0xb1e5cc: ldr             x2, [x2, #8]
    //     0xb1e5d0: mov             x7, x2
    //     0xb1e5d4: mov             x2, #1
    //     0xb1e5d8: b               #0xb1e5e4
    //     0xb1e5dc: mov             x7, NULL
    //     0xb1e5e0: mov             x2, #0
    //     0xb1e5e4: stur            x7, [fp, #-0x80]
    //     0xb1e5e8: lsl             x8, x2, #1
    //     0xb1e5ec: lsl             w9, w8, #1
    //     0xb1e5f0: add             w10, w9, #8
    //     0xb1e5f4: add             x16, x0, w10, sxtw #1
    //     0xb1e5f8: ldur            w11, [x16, #0xf]
    //     0xb1e5fc: add             x11, x11, HEAP, lsl #32
    //     0xb1e600: add             x16, PP, #0x26, lsl #12  ; [pp+0x26850] "animationDuration"
    //     0xb1e604: ldr             x16, [x16, #0x850]
    //     0xb1e608: cmp             w11, w16
    //     0xb1e60c: b.ne            #0xb1e640
    //     0xb1e610: add             w2, w9, #0xa
    //     0xb1e614: add             x16, x0, w2, sxtw #1
    //     0xb1e618: ldur            w9, [x16, #0xf]
    //     0xb1e61c: add             x9, x9, HEAP, lsl #32
    //     0xb1e620: sub             w2, w1, w9
    //     0xb1e624: add             x9, fp, w2, sxtw #2
    //     0xb1e628: ldr             x9, [x9, #8]
    //     0xb1e62c: add             w2, w8, #2
    //     0xb1e630: sbfx            x8, x2, #1, #0x1f
    //     0xb1e634: mov             x2, x8
    //     0xb1e638: mov             x8, x9
    //     0xb1e63c: b               #0xb1e644
    //     0xb1e640: mov             x8, NULL
    //     0xb1e644: stur            x8, [fp, #-0x78]
    //     0xb1e648: lsl             x9, x2, #1
    //     0xb1e64c: lsl             w10, w9, #1
    //     0xb1e650: add             w11, w10, #8
    //     0xb1e654: add             x16, x0, w11, sxtw #1
    //     0xb1e658: ldur            w12, [x16, #0xf]
    //     0xb1e65c: add             x12, x12, HEAP, lsl #32
    //     0xb1e660: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc48] "backgroundColor"
    //     0xb1e664: ldr             x16, [x16, #0xc48]
    //     0xb1e668: cmp             w12, w16
    //     0xb1e66c: b.ne            #0xb1e6a0
    //     0xb1e670: add             w2, w10, #0xa
    //     0xb1e674: add             x16, x0, w2, sxtw #1
    //     0xb1e678: ldur            w10, [x16, #0xf]
    //     0xb1e67c: add             x10, x10, HEAP, lsl #32
    //     0xb1e680: sub             w2, w1, w10
    //     0xb1e684: add             x10, fp, w2, sxtw #2
    //     0xb1e688: ldr             x10, [x10, #8]
    //     0xb1e68c: add             w2, w9, #2
    //     0xb1e690: sbfx            x9, x2, #1, #0x1f
    //     0xb1e694: mov             x2, x9
    //     0xb1e698: mov             x9, x10
    //     0xb1e69c: b               #0xb1e6a4
    //     0xb1e6a0: mov             x9, NULL
    //     0xb1e6a4: stur            x9, [fp, #-0x70]
    //     0xb1e6a8: lsl             x10, x2, #1
    //     0xb1e6ac: lsl             w11, w10, #1
    //     0xb1e6b0: add             w12, w11, #8
    //     0xb1e6b4: add             x16, x0, w12, sxtw #1
    //     0xb1e6b8: ldur            w13, [x16, #0xf]
    //     0xb1e6bc: add             x13, x13, HEAP, lsl #32
    //     0xb1e6c0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26858] "disabledBackgroundColor"
    //     0xb1e6c4: ldr             x16, [x16, #0x858]
    //     0xb1e6c8: cmp             w13, w16
    //     0xb1e6cc: b.ne            #0xb1e700
    //     0xb1e6d0: add             w2, w11, #0xa
    //     0xb1e6d4: add             x16, x0, w2, sxtw #1
    //     0xb1e6d8: ldur            w11, [x16, #0xf]
    //     0xb1e6dc: add             x11, x11, HEAP, lsl #32
    //     0xb1e6e0: sub             w2, w1, w11
    //     0xb1e6e4: add             x11, fp, w2, sxtw #2
    //     0xb1e6e8: ldr             x11, [x11, #8]
    //     0xb1e6ec: add             w2, w10, #2
    //     0xb1e6f0: sbfx            x10, x2, #1, #0x1f
    //     0xb1e6f4: mov             x2, x10
    //     0xb1e6f8: mov             x10, x11
    //     0xb1e6fc: b               #0xb1e704
    //     0xb1e700: mov             x10, NULL
    //     0xb1e704: stur            x10, [fp, #-0x68]
    //     0xb1e708: lsl             x11, x2, #1
    //     0xb1e70c: lsl             w12, w11, #1
    //     0xb1e710: add             w13, w12, #8
    //     0xb1e714: add             x16, x0, w13, sxtw #1
    //     0xb1e718: ldur            w14, [x16, #0xf]
    //     0xb1e71c: add             x14, x14, HEAP, lsl #32
    //     0xb1e720: add             x16, PP, #0x26, lsl #12  ; [pp+0x26860] "disabledForegroundColor"
    //     0xb1e724: ldr             x16, [x16, #0x860]
    //     0xb1e728: cmp             w14, w16
    //     0xb1e72c: b.ne            #0xb1e760
    //     0xb1e730: add             w2, w12, #0xa
    //     0xb1e734: add             x16, x0, w2, sxtw #1
    //     0xb1e738: ldur            w12, [x16, #0xf]
    //     0xb1e73c: add             x12, x12, HEAP, lsl #32
    //     0xb1e740: sub             w2, w1, w12
    //     0xb1e744: add             x12, fp, w2, sxtw #2
    //     0xb1e748: ldr             x12, [x12, #8]
    //     0xb1e74c: add             w2, w11, #2
    //     0xb1e750: sbfx            x11, x2, #1, #0x1f
    //     0xb1e754: mov             x2, x11
    //     0xb1e758: mov             x11, x12
    //     0xb1e75c: b               #0xb1e764
    //     0xb1e760: mov             x11, NULL
    //     0xb1e764: lsl             x12, x2, #1
    //     0xb1e768: lsl             w13, w12, #1
    //     0xb1e76c: add             w14, w13, #8
    //     0xb1e770: add             x16, x0, w14, sxtw #1
    //     0xb1e774: ldur            w19, [x16, #0xf]
    //     0xb1e778: add             x19, x19, HEAP, lsl #32
    //     0xb1e77c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26868] "disabledMouseCursor"
    //     0xb1e780: ldr             x16, [x16, #0x868]
    //     0xb1e784: cmp             w19, w16
    //     0xb1e788: b.ne            #0xb1e7bc
    //     0xb1e78c: add             w2, w13, #0xa
    //     0xb1e790: add             x16, x0, w2, sxtw #1
    //     0xb1e794: ldur            w13, [x16, #0xf]
    //     0xb1e798: add             x13, x13, HEAP, lsl #32
    //     0xb1e79c: sub             w2, w1, w13
    //     0xb1e7a0: add             x13, fp, w2, sxtw #2
    //     0xb1e7a4: ldr             x13, [x13, #8]
    //     0xb1e7a8: add             w2, w12, #2
    //     0xb1e7ac: sbfx            x12, x2, #1, #0x1f
    //     0xb1e7b0: mov             x2, x12
    //     0xb1e7b4: mov             x12, x13
    //     0xb1e7b8: b               #0xb1e7c0
    //     0xb1e7bc: mov             x12, NULL
    //     0xb1e7c0: stur            x12, [fp, #-0x60]
    //     0xb1e7c4: lsl             x13, x2, #1
    //     0xb1e7c8: lsl             w14, w13, #1
    //     0xb1e7cc: add             w19, w14, #8
    //     0xb1e7d0: add             x16, x0, w19, sxtw #1
    //     0xb1e7d4: ldur            w20, [x16, #0xf]
    //     0xb1e7d8: add             x20, x20, HEAP, lsl #32
    //     0xb1e7dc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26870] "elevation"
    //     0xb1e7e0: ldr             x16, [x16, #0x870]
    //     0xb1e7e4: cmp             w20, w16
    //     0xb1e7e8: b.ne            #0xb1e81c
    //     0xb1e7ec: add             w2, w14, #0xa
    //     0xb1e7f0: add             x16, x0, w2, sxtw #1
    //     0xb1e7f4: ldur            w14, [x16, #0xf]
    //     0xb1e7f8: add             x14, x14, HEAP, lsl #32
    //     0xb1e7fc: sub             w2, w1, w14
    //     0xb1e800: add             x14, fp, w2, sxtw #2
    //     0xb1e804: ldr             x14, [x14, #8]
    //     0xb1e808: add             w2, w13, #2
    //     0xb1e80c: sbfx            x13, x2, #1, #0x1f
    //     0xb1e810: mov             x2, x13
    //     0xb1e814: mov             x13, x14
    //     0xb1e818: b               #0xb1e820
    //     0xb1e81c: mov             x13, NULL
    //     0xb1e820: stur            x13, [fp, #-0x58]
    //     0xb1e824: lsl             x14, x2, #1
    //     0xb1e828: lsl             w19, w14, #1
    //     0xb1e82c: add             w20, w19, #8
    //     0xb1e830: add             x16, x0, w20, sxtw #1
    //     0xb1e834: ldur            w23, [x16, #0xf]
    //     0xb1e838: add             x23, x23, HEAP, lsl #32
    //     0xb1e83c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26878] "enableFeedback"
    //     0xb1e840: ldr             x16, [x16, #0x878]
    //     0xb1e844: cmp             w23, w16
    //     0xb1e848: b.ne            #0xb1e87c
    //     0xb1e84c: add             w2, w19, #0xa
    //     0xb1e850: add             x16, x0, w2, sxtw #1
    //     0xb1e854: ldur            w19, [x16, #0xf]
    //     0xb1e858: add             x19, x19, HEAP, lsl #32
    //     0xb1e85c: sub             w2, w1, w19
    //     0xb1e860: add             x19, fp, w2, sxtw #2
    //     0xb1e864: ldr             x19, [x19, #8]
    //     0xb1e868: add             w2, w14, #2
    //     0xb1e86c: sbfx            x14, x2, #1, #0x1f
    //     0xb1e870: mov             x2, x14
    //     0xb1e874: mov             x14, x19
    //     0xb1e878: b               #0xb1e880
    //     0xb1e87c: mov             x14, NULL
    //     0xb1e880: stur            x14, [fp, #-0x50]
    //     0xb1e884: lsl             x19, x2, #1
    //     0xb1e888: lsl             w20, w19, #1
    //     0xb1e88c: add             w23, w20, #8
    //     0xb1e890: add             x16, x0, w23, sxtw #1
    //     0xb1e894: ldur            w24, [x16, #0xf]
    //     0xb1e898: add             x24, x24, HEAP, lsl #32
    //     0xb1e89c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26880] "enabledMouseCursor"
    //     0xb1e8a0: ldr             x16, [x16, #0x880]
    //     0xb1e8a4: cmp             w24, w16
    //     0xb1e8a8: b.ne            #0xb1e8dc
    //     0xb1e8ac: add             w2, w20, #0xa
    //     0xb1e8b0: add             x16, x0, w2, sxtw #1
    //     0xb1e8b4: ldur            w20, [x16, #0xf]
    //     0xb1e8b8: add             x20, x20, HEAP, lsl #32
    //     0xb1e8bc: sub             w2, w1, w20
    //     0xb1e8c0: add             x20, fp, w2, sxtw #2
    //     0xb1e8c4: ldr             x20, [x20, #8]
    //     0xb1e8c8: add             w2, w19, #2
    //     0xb1e8cc: sbfx            x19, x2, #1, #0x1f
    //     0xb1e8d0: mov             x2, x19
    //     0xb1e8d4: mov             x19, x20
    //     0xb1e8d8: b               #0xb1e8e0
    //     0xb1e8dc: mov             x19, NULL
    //     0xb1e8e0: stur            x19, [fp, #-0x48]
    //     0xb1e8e4: lsl             x20, x2, #1
    //     0xb1e8e8: lsl             w23, w20, #1
    //     0xb1e8ec: add             w24, w23, #8
    //     0xb1e8f0: add             x16, x0, w24, sxtw #1
    //     0xb1e8f4: ldur            w25, [x16, #0xf]
    //     0xb1e8f8: add             x25, x25, HEAP, lsl #32
    //     0xb1e8fc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26890] "maximumSize"
    //     0xb1e900: ldr             x16, [x16, #0x890]
    //     0xb1e904: cmp             w25, w16
    //     0xb1e908: b.ne            #0xb1e93c
    //     0xb1e90c: add             w2, w23, #0xa
    //     0xb1e910: add             x16, x0, w2, sxtw #1
    //     0xb1e914: ldur            w23, [x16, #0xf]
    //     0xb1e918: add             x23, x23, HEAP, lsl #32
    //     0xb1e91c: sub             w2, w1, w23
    //     0xb1e920: add             x23, fp, w2, sxtw #2
    //     0xb1e924: ldr             x23, [x23, #8]
    //     0xb1e928: add             w2, w20, #2
    //     0xb1e92c: sbfx            x20, x2, #1, #0x1f
    //     0xb1e930: mov             x2, x20
    //     0xb1e934: mov             x20, x23
    //     0xb1e938: b               #0xb1e940
    //     0xb1e93c: mov             x20, NULL
    //     0xb1e940: stur            x20, [fp, #-0x40]
    //     0xb1e944: lsl             x23, x2, #1
    //     0xb1e948: lsl             w24, w23, #1
    //     0xb1e94c: add             w25, w24, #8
    //     0xb1e950: add             x16, x0, w25, sxtw #1
    //     0xb1e954: ldur            w4, [x16, #0xf]
    //     0xb1e958: add             x4, x4, HEAP, lsl #32
    //     0xb1e95c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce60] "shadowColor"
    //     0xb1e960: ldr             x16, [x16, #0xe60]
    //     0xb1e964: cmp             w4, w16
    //     0xb1e968: b.ne            #0xb1e998
    //     0xb1e96c: add             w2, w24, #0xa
    //     0xb1e970: add             x16, x0, w2, sxtw #1
    //     0xb1e974: ldur            w4, [x16, #0xf]
    //     0xb1e978: add             x4, x4, HEAP, lsl #32
    //     0xb1e97c: sub             w2, w1, w4
    //     0xb1e980: add             x4, fp, w2, sxtw #2
    //     0xb1e984: ldr             x4, [x4, #8]
    //     0xb1e988: add             w2, w23, #2
    //     0xb1e98c: sbfx            x23, x2, #1, #0x1f
    //     0xb1e990: mov             x2, x23
    //     0xb1e994: b               #0xb1e99c
    //     0xb1e998: mov             x4, NULL
    //     0xb1e99c: stur            x4, [fp, #-0x10]
    //     0xb1e9a0: lsl             x23, x2, #1
    //     0xb1e9a4: lsl             w24, w23, #1
    //     0xb1e9a8: add             w25, w24, #8
    //     0xb1e9ac: add             x16, x0, w25, sxtw #1
    //     0xb1e9b0: ldur            w4, [x16, #0xf]
    //     0xb1e9b4: add             x4, x4, HEAP, lsl #32
    //     0xb1e9b8: add             x16, PP, #0xc, lsl #12  ; [pp+0xce80] "splashFactory"
    //     0xb1e9bc: ldr             x16, [x16, #0xe80]
    //     0xb1e9c0: cmp             w4, w16
    //     0xb1e9c4: b.ne            #0xb1e9f4
    //     0xb1e9c8: add             w2, w24, #0xa
    //     0xb1e9cc: add             x16, x0, w2, sxtw #1
    //     0xb1e9d0: ldur            w4, [x16, #0xf]
    //     0xb1e9d4: add             x4, x4, HEAP, lsl #32
    //     0xb1e9d8: sub             w2, w1, w4
    //     0xb1e9dc: add             x4, fp, w2, sxtw #2
    //     0xb1e9e0: ldr             x4, [x4, #8]
    //     0xb1e9e4: add             w2, w23, #2
    //     0xb1e9e8: sbfx            x23, x2, #1, #0x1f
    //     0xb1e9ec: mov             x2, x23
    //     0xb1e9f0: b               #0xb1e9f8
    //     0xb1e9f4: mov             x4, NULL
    //     0xb1e9f8: stur            x4, [fp, #-0x18]
    //     0xb1e9fc: lsl             x23, x2, #1
    //     0xb1ea00: lsl             w24, w23, #1
    //     0xb1ea04: add             w25, w24, #8
    //     0xb1ea08: add             x16, x0, w25, sxtw #1
    //     0xb1ea0c: ldur            w4, [x16, #0xf]
    //     0xb1ea10: add             x4, x4, HEAP, lsl #32
    //     0xb1ea14: add             x16, PP, #0x26, lsl #12  ; [pp+0x268a0] "tapTargetSize"
    //     0xb1ea18: ldr             x16, [x16, #0x8a0]
    //     0xb1ea1c: cmp             w4, w16
    //     0xb1ea20: b.ne            #0xb1ea50
    //     0xb1ea24: add             w2, w24, #0xa
    //     0xb1ea28: add             x16, x0, w2, sxtw #1
    //     0xb1ea2c: ldur            w4, [x16, #0xf]
    //     0xb1ea30: add             x4, x4, HEAP, lsl #32
    //     0xb1ea34: sub             w2, w1, w4
    //     0xb1ea38: add             x4, fp, w2, sxtw #2
    //     0xb1ea3c: ldr             x4, [x4, #8]
    //     0xb1ea40: add             w2, w23, #2
    //     0xb1ea44: sbfx            x23, x2, #1, #0x1f
    //     0xb1ea48: mov             x2, x23
    //     0xb1ea4c: b               #0xb1ea54
    //     0xb1ea50: mov             x4, NULL
    //     0xb1ea54: stur            x4, [fp, #-0x20]
    //     0xb1ea58: lsl             x23, x2, #1
    //     0xb1ea5c: lsl             w24, w23, #1
    //     0xb1ea60: add             w25, w24, #8
    //     0xb1ea64: add             x16, x0, w25, sxtw #1
    //     0xb1ea68: ldur            w4, [x16, #0xf]
    //     0xb1ea6c: add             x4, x4, HEAP, lsl #32
    //     0xb1ea70: add             x16, PP, #0x26, lsl #12  ; [pp+0x268a8] "textStyle"
    //     0xb1ea74: ldr             x16, [x16, #0x8a8]
    //     0xb1ea78: cmp             w4, w16
    //     0xb1ea7c: b.ne            #0xb1eaac
    //     0xb1ea80: add             w2, w24, #0xa
    //     0xb1ea84: add             x16, x0, w2, sxtw #1
    //     0xb1ea88: ldur            w4, [x16, #0xf]
    //     0xb1ea8c: add             x4, x4, HEAP, lsl #32
    //     0xb1ea90: sub             w2, w1, w4
    //     0xb1ea94: add             x4, fp, w2, sxtw #2
    //     0xb1ea98: ldr             x4, [x4, #8]
    //     0xb1ea9c: add             w2, w23, #2
    //     0xb1eaa0: sbfx            x23, x2, #1, #0x1f
    //     0xb1eaa4: mov             x2, x23
    //     0xb1eaa8: b               #0xb1eab0
    //     0xb1eaac: mov             x4, NULL
    //     0xb1eab0: stur            x4, [fp, #-0x38]
    //     0xb1eab4: lsl             x23, x2, #1
    //     0xb1eab8: lsl             w2, w23, #1
    //     0xb1eabc: add             w23, w2, #8
    //     0xb1eac0: add             x16, x0, w23, sxtw #1
    //     0xb1eac4: ldur            w24, [x16, #0xf]
    //     0xb1eac8: add             x24, x24, HEAP, lsl #32
    //     0xb1eacc: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b0] "visualDensity"
    //     0xb1ead0: ldr             x16, [x16, #0x8b0]
    //     0xb1ead4: cmp             w24, w16
    //     0xb1ead8: b.ne            #0xb1eb00
    //     0xb1eadc: add             w23, w2, #0xa
    //     0xb1eae0: add             x16, x0, w23, sxtw #1
    //     0xb1eae4: ldur            w2, [x16, #0xf]
    //     0xb1eae8: add             x2, x2, HEAP, lsl #32
    //     0xb1eaec: sub             w0, w1, w2
    //     0xb1eaf0: add             x1, fp, w0, sxtw #2
    //     0xb1eaf4: ldr             x1, [x1, #8]
    //     0xb1eaf8: mov             x0, x1
    //     0xb1eafc: b               #0xb1eb04
    //     0xb1eb00: mov             x0, NULL
    //     0xb1eb04: stur            x0, [fp, #-0x30]
    // 0xb1eb08: CheckStackOverflow
    //     0xb1eb08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1eb0c: cmp             SP, x16
    //     0xb1eb10: b.ls            #0xb1ee0c
    // 0xb1eb14: cmp             w11, NULL
    // 0xb1eb18: b.ne            #0xb1eb24
    // 0xb1eb1c: r2 = Null
    //     0xb1eb1c: mov             x2, NULL
    // 0xb1eb20: b               #0xb1eb28
    // 0xb1eb24: mov             x2, x11
    // 0xb1eb28: stur            x2, [fp, #-0x28]
    // 0xb1eb2c: cmp             w3, NULL
    // 0xb1eb30: b.ne            #0xb1eb4c
    // 0xb1eb34: cmp             w2, NULL
    // 0xb1eb38: b.ne            #0xb1eb4c
    // 0xb1eb3c: mov             x0, x3
    // 0xb1eb40: mov             x2, x9
    // 0xb1eb44: r1 = Null
    //     0xb1eb44: mov             x1, NULL
    // 0xb1eb48: b               #0xb1eb70
    // 0xb1eb4c: r1 = <Color?>
    //     0xb1eb4c: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xb1eb50: ldr             x1, [x1, #0xf68]
    // 0xb1eb54: r0 = _TextButtonDefaultColor()
    //     0xb1eb54: bl              #0xb1ee34  ; Allocate_TextButtonDefaultColorStub -> _TextButtonDefaultColor (size=0x14)
    // 0xb1eb58: mov             x1, x0
    // 0xb1eb5c: ldur            x0, [fp, #-0x98]
    // 0xb1eb60: StoreField: r1->field_b = r0
    //     0xb1eb60: stur            w0, [x1, #0xb]
    // 0xb1eb64: ldur            x2, [fp, #-0x28]
    // 0xb1eb68: StoreField: r1->field_f = r2
    //     0xb1eb68: stur            w2, [x1, #0xf]
    // 0xb1eb6c: ldur            x2, [fp, #-0x70]
    // 0xb1eb70: stur            x1, [fp, #-0x28]
    // 0xb1eb74: cmp             w2, NULL
    // 0xb1eb78: b.ne            #0xb1eb90
    // 0xb1eb7c: ldur            x3, [fp, #-0x68]
    // 0xb1eb80: cmp             w3, NULL
    // 0xb1eb84: b.ne            #0xb1eb94
    // 0xb1eb88: r2 = Null
    //     0xb1eb88: mov             x2, NULL
    // 0xb1eb8c: b               #0xb1ebe4
    // 0xb1eb90: ldur            x3, [fp, #-0x68]
    // 0xb1eb94: cmp             w3, NULL
    // 0xb1eb98: b.ne            #0xb1ebb8
    // 0xb1eb9c: r16 = <Color?>
    //     0xb1eb9c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xb1eba0: ldr             x16, [x16, #0xf68]
    // 0xb1eba4: stp             x2, x16, [SP, #-0x10]!
    // 0xb1eba8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1eba8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1ebac: r0 = allOrNull()
    //     0xb1ebac: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb1ebb0: add             SP, SP, #0x10
    // 0xb1ebb4: b               #0xb1ebdc
    // 0xb1ebb8: r1 = <Color?>
    //     0xb1ebb8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xb1ebbc: ldr             x1, [x1, #0xf68]
    // 0xb1ebc0: r0 = _TextButtonDefaultColor()
    //     0xb1ebc0: bl              #0xb1ee34  ; Allocate_TextButtonDefaultColorStub -> _TextButtonDefaultColor (size=0x14)
    // 0xb1ebc4: mov             x1, x0
    // 0xb1ebc8: ldur            x0, [fp, #-0x70]
    // 0xb1ebcc: StoreField: r1->field_b = r0
    //     0xb1ebcc: stur            w0, [x1, #0xb]
    // 0xb1ebd0: ldur            x0, [fp, #-0x68]
    // 0xb1ebd4: StoreField: r1->field_f = r0
    //     0xb1ebd4: stur            w0, [x1, #0xf]
    // 0xb1ebd8: mov             x0, x1
    // 0xb1ebdc: mov             x2, x0
    // 0xb1ebe0: ldur            x0, [fp, #-0x98]
    // 0xb1ebe4: stur            x2, [fp, #-0x68]
    // 0xb1ebe8: cmp             w0, NULL
    // 0xb1ebec: b.ne            #0xb1ebf8
    // 0xb1ebf0: r2 = Null
    //     0xb1ebf0: mov             x2, NULL
    // 0xb1ebf4: b               #0xb1ec14
    // 0xb1ebf8: r1 = <Color?>
    //     0xb1ebf8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xb1ebfc: ldr             x1, [x1, #0xf68]
    // 0xb1ec00: r0 = _TextButtonDefaultOverlay()
    //     0xb1ec00: bl              #0xb1ee28  ; Allocate_TextButtonDefaultOverlayStub -> _TextButtonDefaultOverlay (size=0x10)
    // 0xb1ec04: mov             x1, x0
    // 0xb1ec08: ldur            x0, [fp, #-0x98]
    // 0xb1ec0c: StoreField: r1->field_b = r0
    //     0xb1ec0c: stur            w0, [x1, #0xb]
    // 0xb1ec10: mov             x2, x1
    // 0xb1ec14: ldur            x0, [fp, #-0x48]
    // 0xb1ec18: stur            x2, [fp, #-0x70]
    // 0xb1ec1c: cmp             w0, NULL
    // 0xb1ec20: b.ne            #0xb1ec3c
    // 0xb1ec24: ldur            x1, [fp, #-0x60]
    // 0xb1ec28: cmp             w1, NULL
    // 0xb1ec2c: b.ne            #0xb1ec40
    // 0xb1ec30: mov             x0, x2
    // 0xb1ec34: r9 = Null
    //     0xb1ec34: mov             x9, NULL
    // 0xb1ec38: b               #0xb1ec74
    // 0xb1ec3c: ldur            x1, [fp, #-0x60]
    // 0xb1ec40: cmp             w0, NULL
    // 0xb1ec44: b.eq            #0xb1ee14
    // 0xb1ec48: cmp             w1, NULL
    // 0xb1ec4c: b.eq            #0xb1ee18
    // 0xb1ec50: r1 = <MouseCursor>
    //     0xb1ec50: ldr             x1, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0xb1ec54: r0 = _TextButtonDefaultMouseCursor()
    //     0xb1ec54: bl              #0xb1ee1c  ; Allocate_TextButtonDefaultMouseCursorStub -> _TextButtonDefaultMouseCursor (size=0x14)
    // 0xb1ec58: mov             x1, x0
    // 0xb1ec5c: ldur            x0, [fp, #-0x48]
    // 0xb1ec60: StoreField: r1->field_b = r0
    //     0xb1ec60: stur            w0, [x1, #0xb]
    // 0xb1ec64: r0 = Instance_SystemMouseCursor
    //     0xb1ec64: ldr             x0, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0xb1ec68: StoreField: r1->field_f = r0
    //     0xb1ec68: stur            w0, [x1, #0xf]
    // 0xb1ec6c: mov             x9, x1
    // 0xb1ec70: ldur            x0, [fp, #-0x70]
    // 0xb1ec74: ldur            x3, [fp, #-0x80]
    // 0xb1ec78: ldur            x4, [fp, #-0x78]
    // 0xb1ec7c: ldur            x5, [fp, #-0x50]
    // 0xb1ec80: ldur            x6, [fp, #-0x18]
    // 0xb1ec84: ldur            x7, [fp, #-0x20]
    // 0xb1ec88: ldur            x8, [fp, #-0x30]
    // 0xb1ec8c: ldur            x2, [fp, #-0x28]
    // 0xb1ec90: ldur            x1, [fp, #-0x68]
    // 0xb1ec94: stur            x9, [fp, #-0x48]
    // 0xb1ec98: r16 = <TextStyle>
    //     0xb1ec98: add             x16, PP, #0x28, lsl #12  ; [pp+0x28410] TypeArguments: <TextStyle>
    //     0xb1ec9c: ldr             x16, [x16, #0x410]
    // 0xb1eca0: ldur            lr, [fp, #-0x38]
    // 0xb1eca4: stp             lr, x16, [SP, #-0x10]!
    // 0xb1eca8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1eca8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1ecac: r0 = allOrNull()
    //     0xb1ecac: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb1ecb0: add             SP, SP, #0x10
    // 0xb1ecb4: stur            x0, [fp, #-0x38]
    // 0xb1ecb8: r16 = <Color>
    //     0xb1ecb8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xb1ecbc: ldr             x16, [x16, #0x3f8]
    // 0xb1ecc0: ldur            lr, [fp, #-0x10]
    // 0xb1ecc4: stp             lr, x16, [SP, #-0x10]!
    // 0xb1ecc8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1ecc8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1eccc: r0 = allOrNull()
    //     0xb1eccc: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb1ecd0: add             SP, SP, #0x10
    // 0xb1ecd4: stur            x0, [fp, #-0x10]
    // 0xb1ecd8: r16 = <double>
    //     0xb1ecd8: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xb1ecdc: ldur            lr, [fp, #-0x58]
    // 0xb1ece0: stp             lr, x16, [SP, #-0x10]!
    // 0xb1ece4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1ece4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1ece8: r0 = allOrNull()
    //     0xb1ece8: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb1ecec: add             SP, SP, #0x10
    // 0xb1ecf0: stur            x0, [fp, #-0x58]
    // 0xb1ecf4: r16 = <EdgeInsetsGeometry>
    //     0xb1ecf4: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c8] TypeArguments: <EdgeInsetsGeometry>
    //     0xb1ecf8: ldr             x16, [x16, #0x8c8]
    // 0xb1ecfc: ldur            lr, [fp, #-0x90]
    // 0xb1ed00: stp             lr, x16, [SP, #-0x10]!
    // 0xb1ed04: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1ed04: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1ed08: r0 = allOrNull()
    //     0xb1ed08: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb1ed0c: add             SP, SP, #0x10
    // 0xb1ed10: stur            x0, [fp, #-0x60]
    // 0xb1ed14: r16 = <Size>
    //     0xb1ed14: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0xb1ed18: ldr             x16, [x16, #0x8d0]
    // 0xb1ed1c: ldur            lr, [fp, #-8]
    // 0xb1ed20: stp             lr, x16, [SP, #-0x10]!
    // 0xb1ed24: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1ed24: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1ed28: r0 = allOrNull()
    //     0xb1ed28: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb1ed2c: add             SP, SP, #0x10
    // 0xb1ed30: stur            x0, [fp, #-8]
    // 0xb1ed34: r16 = <Size>
    //     0xb1ed34: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0xb1ed38: ldr             x16, [x16, #0x8d0]
    // 0xb1ed3c: ldur            lr, [fp, #-0x40]
    // 0xb1ed40: stp             lr, x16, [SP, #-0x10]!
    // 0xb1ed44: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1ed44: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1ed48: r0 = allOrNull()
    //     0xb1ed48: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb1ed4c: add             SP, SP, #0x10
    // 0xb1ed50: stur            x0, [fp, #-0x40]
    // 0xb1ed54: r16 = <OutlinedBorder>
    //     0xb1ed54: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d8] TypeArguments: <OutlinedBorder>
    //     0xb1ed58: ldr             x16, [x16, #0x8d8]
    // 0xb1ed5c: ldur            lr, [fp, #-0x88]
    // 0xb1ed60: stp             lr, x16, [SP, #-0x10]!
    // 0xb1ed64: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1ed64: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1ed68: r0 = allOrNull()
    //     0xb1ed68: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb1ed6c: add             SP, SP, #0x10
    // 0xb1ed70: stur            x0, [fp, #-0x88]
    // 0xb1ed74: r0 = ButtonStyle()
    //     0xb1ed74: bl              #0x9173f0  ; AllocateButtonStyleStub -> ButtonStyle (size=0x60)
    // 0xb1ed78: ldur            x1, [fp, #-0x38]
    // 0xb1ed7c: StoreField: r0->field_7 = r1
    //     0xb1ed7c: stur            w1, [x0, #7]
    // 0xb1ed80: ldur            x1, [fp, #-0x68]
    // 0xb1ed84: StoreField: r0->field_b = r1
    //     0xb1ed84: stur            w1, [x0, #0xb]
    // 0xb1ed88: ldur            x1, [fp, #-0x28]
    // 0xb1ed8c: StoreField: r0->field_f = r1
    //     0xb1ed8c: stur            w1, [x0, #0xf]
    // 0xb1ed90: ldur            x1, [fp, #-0x70]
    // 0xb1ed94: StoreField: r0->field_13 = r1
    //     0xb1ed94: stur            w1, [x0, #0x13]
    // 0xb1ed98: ldur            x1, [fp, #-0x10]
    // 0xb1ed9c: StoreField: r0->field_17 = r1
    //     0xb1ed9c: stur            w1, [x0, #0x17]
    // 0xb1eda0: ldur            x1, [fp, #-0x58]
    // 0xb1eda4: StoreField: r0->field_1f = r1
    //     0xb1eda4: stur            w1, [x0, #0x1f]
    // 0xb1eda8: ldur            x1, [fp, #-0x60]
    // 0xb1edac: StoreField: r0->field_23 = r1
    //     0xb1edac: stur            w1, [x0, #0x23]
    // 0xb1edb0: ldur            x1, [fp, #-8]
    // 0xb1edb4: StoreField: r0->field_27 = r1
    //     0xb1edb4: stur            w1, [x0, #0x27]
    // 0xb1edb8: ldur            x1, [fp, #-0x40]
    // 0xb1edbc: StoreField: r0->field_2f = r1
    //     0xb1edbc: stur            w1, [x0, #0x2f]
    // 0xb1edc0: ldur            x1, [fp, #-0x88]
    // 0xb1edc4: StoreField: r0->field_3f = r1
    //     0xb1edc4: stur            w1, [x0, #0x3f]
    // 0xb1edc8: ldur            x1, [fp, #-0x48]
    // 0xb1edcc: StoreField: r0->field_43 = r1
    //     0xb1edcc: stur            w1, [x0, #0x43]
    // 0xb1edd0: ldur            x1, [fp, #-0x30]
    // 0xb1edd4: StoreField: r0->field_47 = r1
    //     0xb1edd4: stur            w1, [x0, #0x47]
    // 0xb1edd8: ldur            x1, [fp, #-0x20]
    // 0xb1eddc: StoreField: r0->field_4b = r1
    //     0xb1eddc: stur            w1, [x0, #0x4b]
    // 0xb1ede0: ldur            x1, [fp, #-0x78]
    // 0xb1ede4: StoreField: r0->field_4f = r1
    //     0xb1ede4: stur            w1, [x0, #0x4f]
    // 0xb1ede8: ldur            x1, [fp, #-0x50]
    // 0xb1edec: StoreField: r0->field_53 = r1
    //     0xb1edec: stur            w1, [x0, #0x53]
    // 0xb1edf0: ldur            x1, [fp, #-0x80]
    // 0xb1edf4: StoreField: r0->field_57 = r1
    //     0xb1edf4: stur            w1, [x0, #0x57]
    // 0xb1edf8: ldur            x1, [fp, #-0x18]
    // 0xb1edfc: StoreField: r0->field_5b = r1
    //     0xb1edfc: stur            w1, [x0, #0x5b]
    // 0xb1ee00: LeaveFrame
    //     0xb1ee00: mov             SP, fp
    //     0xb1ee04: ldp             fp, lr, [SP], #0x10
    // 0xb1ee08: ret
    //     0xb1ee08: ret             
    // 0xb1ee0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1ee0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1ee10: b               #0xb1eb14
    // 0xb1ee14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1ee14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1ee18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1ee18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ themeStyleOf(/* No info */) {
    // ** addr: 0xc134e8, size: 0x44
    // 0xc134e8: EnterFrame
    //     0xc134e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc134ec: mov             fp, SP
    // 0xc134f0: CheckStackOverflow
    //     0xc134f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc134f4: cmp             SP, x16
    //     0xc134f8: b.ls            #0xc13524
    // 0xc134fc: ldr             x16, [fp, #0x10]
    // 0xc13500: SaveReg r16
    //     0xc13500: str             x16, [SP, #-8]!
    // 0xc13504: r0 = of()
    //     0xc13504: bl              #0xc1352c  ; [package:flutter/src/material/text_button_theme.dart] TextButtonTheme::of
    // 0xc13508: add             SP, SP, #8
    // 0xc1350c: LoadField: r1 = r0->field_7
    //     0xc1350c: ldur            w1, [x0, #7]
    // 0xc13510: DecompressPointer r1
    //     0xc13510: add             x1, x1, HEAP, lsl #32
    // 0xc13514: mov             x0, x1
    // 0xc13518: LeaveFrame
    //     0xc13518: mov             SP, fp
    //     0xc1351c: ldp             fp, lr, [SP], #0x10
    // 0xc13520: ret
    //     0xc13520: ret             
    // 0xc13524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc13524: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc13528: b               #0xc134fc
  }
  _ defaultStyleOf(/* No info */) {
    // ** addr: 0xc15310, size: 0x1d4
    // 0xc15310: EnterFrame
    //     0xc15310: stp             fp, lr, [SP, #-0x10]!
    //     0xc15314: mov             fp, SP
    // 0xc15318: AllocStack(0x28)
    //     0xc15318: sub             SP, SP, #0x28
    // 0xc1531c: CheckStackOverflow
    //     0xc1531c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc15320: cmp             SP, x16
    //     0xc15324: b.ls            #0xc154dc
    // 0xc15328: ldr             x16, [fp, #0x10]
    // 0xc1532c: SaveReg r16
    //     0xc1532c: str             x16, [SP, #-8]!
    // 0xc15330: r0 = of()
    //     0xc15330: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc15334: add             SP, SP, #8
    // 0xc15338: stur            x0, [fp, #-0x10]
    // 0xc1533c: LoadField: r1 = r0->field_3f
    //     0xc1533c: ldur            w1, [x0, #0x3f]
    // 0xc15340: DecompressPointer r1
    //     0xc15340: add             x1, x1, HEAP, lsl #32
    // 0xc15344: stur            x1, [fp, #-8]
    // 0xc15348: ldr             x16, [fp, #0x10]
    // 0xc1534c: SaveReg r16
    //     0xc1534c: str             x16, [SP, #-8]!
    // 0xc15350: r0 = of()
    //     0xc15350: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc15354: add             SP, SP, #8
    // 0xc15358: LoadField: r1 = r0->field_2b
    //     0xc15358: ldur            w1, [x0, #0x2b]
    // 0xc1535c: DecompressPointer r1
    //     0xc1535c: add             x1, x1, HEAP, lsl #32
    // 0xc15360: tbnz            w1, #4, #0xc153a8
    // 0xc15364: ldr             x0, [fp, #0x10]
    // 0xc15368: r0 = _TextButtonDefaultsM3()
    //     0xc15368: bl              #0xc1559c  ; Allocate_TextButtonDefaultsM3Stub -> _TextButtonDefaultsM3 (size=0x68)
    // 0xc1536c: mov             x1, x0
    // 0xc15370: r0 = Sentinel
    //     0xc15370: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc15374: StoreField: r1->field_63 = r0
    //     0xc15374: stur            w0, [x1, #0x63]
    // 0xc15378: ldr             x0, [fp, #0x10]
    // 0xc1537c: StoreField: r1->field_5f = r0
    //     0xc1537c: stur            w0, [x1, #0x5f]
    // 0xc15380: r0 = Instance_Duration
    //     0xc15380: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xc15384: ldr             x0, [x0, #0x9e0]
    // 0xc15388: StoreField: r1->field_4f = r0
    //     0xc15388: stur            w0, [x1, #0x4f]
    // 0xc1538c: r0 = true
    //     0xc1538c: add             x0, NULL, #0x20  ; true
    // 0xc15390: StoreField: r1->field_53 = r0
    //     0xc15390: stur            w0, [x1, #0x53]
    // 0xc15394: r0 = Instance_Alignment
    //     0xc15394: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc15398: ldr             x0, [x0, #0xc70]
    // 0xc1539c: StoreField: r1->field_57 = r0
    //     0xc1539c: stur            w0, [x1, #0x57]
    // 0xc153a0: mov             x0, x1
    // 0xc153a4: b               #0xc154d0
    // 0xc153a8: ldr             x0, [fp, #0x10]
    // 0xc153ac: ldur            x1, [fp, #-0x10]
    // 0xc153b0: ldur            x2, [fp, #-8]
    // 0xc153b4: d0 = 0.380000
    //     0xc153b4: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc153b8: ldr             d0, [x17, #0x140]
    // 0xc153bc: LoadField: r3 = r2->field_b
    //     0xc153bc: ldur            w3, [x2, #0xb]
    // 0xc153c0: DecompressPointer r3
    //     0xc153c0: add             x3, x3, HEAP, lsl #32
    // 0xc153c4: stur            x3, [fp, #-0x18]
    // 0xc153c8: LoadField: r4 = r2->field_57
    //     0xc153c8: ldur            w4, [x2, #0x57]
    // 0xc153cc: DecompressPointer r4
    //     0xc153cc: add             x4, x4, HEAP, lsl #32
    // 0xc153d0: SaveReg r4
    //     0xc153d0: str             x4, [SP, #-8]!
    // 0xc153d4: SaveReg d0
    //     0xc153d4: str             d0, [SP, #-8]!
    // 0xc153d8: r0 = withOpacity()
    //     0xc153d8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc153dc: add             SP, SP, #0x10
    // 0xc153e0: mov             x1, x0
    // 0xc153e4: ldur            x0, [fp, #-0x10]
    // 0xc153e8: stur            x1, [fp, #-0x28]
    // 0xc153ec: LoadField: r2 = r0->field_7b
    //     0xc153ec: ldur            w2, [x0, #0x7b]
    // 0xc153f0: DecompressPointer r2
    //     0xc153f0: add             x2, x2, HEAP, lsl #32
    // 0xc153f4: stur            x2, [fp, #-0x20]
    // 0xc153f8: LoadField: r3 = r0->field_93
    //     0xc153f8: ldur            w3, [x0, #0x93]
    // 0xc153fc: DecompressPointer r3
    //     0xc153fc: add             x3, x3, HEAP, lsl #32
    // 0xc15400: LoadField: r4 = r3->field_37
    //     0xc15400: ldur            w4, [x3, #0x37]
    // 0xc15404: DecompressPointer r4
    //     0xc15404: add             x4, x4, HEAP, lsl #32
    // 0xc15408: stur            x4, [fp, #-8]
    // 0xc1540c: ldr             x16, [fp, #0x10]
    // 0xc15410: SaveReg r16
    //     0xc15410: str             x16, [SP, #-8]!
    // 0xc15414: r0 = _scaledPadding()
    //     0xc15414: bl              #0xc154e4  ; [package:flutter/src/material/text_button.dart] ::_scaledPadding
    // 0xc15418: add             SP, SP, #8
    // 0xc1541c: mov             x1, x0
    // 0xc15420: ldur            x0, [fp, #-0x10]
    // 0xc15424: LoadField: r2 = r0->field_2f
    //     0xc15424: ldur            w2, [x0, #0x2f]
    // 0xc15428: DecompressPointer r2
    //     0xc15428: add             x2, x2, HEAP, lsl #32
    // 0xc1542c: LoadField: r3 = r0->field_17
    //     0xc1542c: ldur            w3, [x0, #0x17]
    // 0xc15430: DecompressPointer r3
    //     0xc15430: add             x3, x3, HEAP, lsl #32
    // 0xc15434: ldur            x16, [fp, #-0x18]
    // 0xc15438: r30 = Instance_Size
    //     0xc15438: add             lr, PP, #0x37, lsl #12  ; [pp+0x376e8] Obj!Size@b5ee71
    //     0xc1543c: ldr             lr, [lr, #0x6e8]
    // 0xc15440: stp             lr, x16, [SP, #-0x10]!
    // 0xc15444: r16 = Instance_RoundedRectangleBorder
    //     0xc15444: add             x16, PP, #0xe, lsl #12  ; [pp+0xe450] Obj!RoundedRectangleBorder@b383f1
    //     0xc15448: ldr             x16, [x16, #0x450]
    // 0xc1544c: stp             x16, x1, [SP, #-0x10]!
    // 0xc15450: ldur            x16, [fp, #-0x28]
    // 0xc15454: r30 = Instance_Color
    //     0xc15454: add             lr, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xc15458: ldr             lr, [lr, #0xc08]
    // 0xc1545c: stp             lr, x16, [SP, #-0x10]!
    // 0xc15460: r16 = Instance_Color
    //     0xc15460: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xc15464: ldr             x16, [x16, #0xc08]
    // 0xc15468: ldur            lr, [fp, #-0x20]
    // 0xc1546c: stp             lr, x16, [SP, #-0x10]!
    // 0xc15470: r16 = 0.000000
    //     0xc15470: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xc15474: ldur            lr, [fp, #-8]
    // 0xc15478: stp             lr, x16, [SP, #-0x10]!
    // 0xc1547c: r16 = Instance_Size
    //     0xc1547c: add             x16, PP, #0x37, lsl #12  ; [pp+0x376f0] Obj!Size@b5ee51
    //     0xc15480: ldr             x16, [x16, #0x6f0]
    // 0xc15484: r30 = Instance_SystemMouseCursor
    //     0xc15484: add             lr, PP, #0x25, lsl #12  ; [pp+0x25ea8] Obj!SystemMouseCursor@b489b1
    //     0xc15488: ldr             lr, [lr, #0xea8]
    // 0xc1548c: stp             lr, x16, [SP, #-0x10]!
    // 0xc15490: r16 = Instance_SystemMouseCursor
    //     0xc15490: ldr             x16, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0xc15494: stp             x2, x16, [SP, #-0x10]!
    // 0xc15498: r16 = Instance_Duration
    //     0xc15498: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xc1549c: ldr             x16, [x16, #0x9e0]
    // 0xc154a0: stp             x16, x3, [SP, #-0x10]!
    // 0xc154a4: r16 = true
    //     0xc154a4: add             x16, NULL, #0x20  ; true
    // 0xc154a8: r30 = Instance_Alignment
    //     0xc154a8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc154ac: ldr             lr, [lr, #0xc70]
    // 0xc154b0: stp             lr, x16, [SP, #-0x10]!
    // 0xc154b4: r16 = Instance__InkRippleFactory
    //     0xc154b4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf00] Obj!_InkRippleFactory@b38571
    //     0xc154b8: ldr             x16, [x16, #0xf00]
    // 0xc154bc: SaveReg r16
    //     0xc154bc: str             x16, [SP, #-8]!
    // 0xc154c0: r4 = const [0, 0x13, 0x13, 0x4, alignment, 0x11, animationDuration, 0xf, backgroundColor, 0x5, disabledBackgroundColor, 0x6, disabledForegroundColor, 0x4, disabledMouseCursor, 0xc, elevation, 0x8, enableFeedback, 0x10, enabledMouseCursor, 0xb, maximumSize, 0xa, shadowColor, 0x7, splashFactory, 0x12, tapTargetSize, 0xe, textStyle, 0x9, visualDensity, 0xd, null]
    //     0xc154c0: add             x4, PP, #0x37, lsl #12  ; [pp+0x376f8] List(35) [0, 0x13, 0x13, 0x4, "alignment", 0x11, "animationDuration", 0xf, "backgroundColor", 0x5, "disabledBackgroundColor", 0x6, "disabledForegroundColor", 0x4, "disabledMouseCursor", 0xc, "elevation", 0x8, "enableFeedback", 0x10, "enabledMouseCursor", 0xb, "maximumSize", 0xa, "shadowColor", 0x7, "splashFactory", 0x12, "tapTargetSize", 0xe, "textStyle", 0x9, "visualDensity", 0xd, Null]
    //     0xc154c4: ldr             x4, [x4, #0x6f8]
    // 0xc154c8: r0 = styleFrom()
    //     0xc154c8: bl              #0xb1e558  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xc154cc: add             SP, SP, #0x98
    // 0xc154d0: LeaveFrame
    //     0xc154d0: mov             SP, fp
    //     0xc154d4: ldp             fp, lr, [SP], #0x10
    // 0xc154d8: ret
    //     0xc154d8: ret             
    // 0xc154dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc154dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc154e0: b               #0xc15328
  }
}

// class id: 4162, size: 0x34, field offset: 0x34
class _TextButtonWithIcon extends TextButton {

  _ defaultStyleOf(/* No info */) {
    // ** addr: 0xc1520c, size: 0x104
    // 0xc1520c: EnterFrame
    //     0xc1520c: stp             fp, lr, [SP, #-0x10]!
    //     0xc15210: mov             fp, SP
    // 0xc15214: AllocStack(0x10)
    //     0xc15214: sub             SP, SP, #0x10
    // 0xc15218: CheckStackOverflow
    //     0xc15218: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc1521c: cmp             SP, x16
    //     0xc15220: b.ls            #0xc152f8
    // 0xc15224: ldr             x16, [fp, #0x10]
    // 0xc15228: SaveReg r16
    //     0xc15228: str             x16, [SP, #-8]!
    // 0xc1522c: r0 = maybeOf()
    //     0xc1522c: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0xc15230: add             SP, SP, #8
    // 0xc15234: cmp             w0, NULL
    // 0xc15238: b.ne            #0xc15244
    // 0xc1523c: r0 = Null
    //     0xc1523c: mov             x0, NULL
    // 0xc15240: b               #0xc15270
    // 0xc15244: LoadField: d0 = r0->field_13
    //     0xc15244: ldur            d0, [x0, #0x13]
    // 0xc15248: r0 = inline_Allocate_Double()
    //     0xc15248: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc1524c: add             x0, x0, #0x10
    //     0xc15250: cmp             x1, x0
    //     0xc15254: b.ls            #0xc15300
    //     0xc15258: str             x0, [THR, #0x60]  ; THR::top
    //     0xc1525c: sub             x0, x0, #0xf
    //     0xc15260: mov             x1, #0xd108
    //     0xc15264: movk            x1, #3, lsl #16
    //     0xc15268: stur            x1, [x0, #-1]
    // 0xc1526c: StoreField: r0->field_7 = d0
    //     0xc1526c: stur            d0, [x0, #7]
    // 0xc15270: cmp             w0, NULL
    // 0xc15274: b.ne            #0xc15280
    // 0xc15278: d0 = 1.000000
    //     0xc15278: fmov            d0, #1.00000000
    // 0xc1527c: b               #0xc15284
    // 0xc15280: LoadField: d0 = r0->field_7
    //     0xc15280: ldur            d0, [x0, #7]
    // 0xc15284: r16 = Instance_EdgeInsets
    //     0xc15284: add             x16, PP, #0x33, lsl #12  ; [pp+0x33980] Obj!EdgeInsets@b35b11
    //     0xc15288: ldr             x16, [x16, #0x980]
    // 0xc1528c: r30 = Instance_EdgeInsets
    //     0xc1528c: add             lr, PP, #0x27, lsl #12  ; [pp+0x27030] Obj!EdgeInsets@b363b1
    //     0xc15290: ldr             lr, [lr, #0x30]
    // 0xc15294: stp             lr, x16, [SP, #-0x10]!
    // 0xc15298: SaveReg d0
    //     0xc15298: str             d0, [SP, #-8]!
    // 0xc1529c: r0 = scaledPadding()
    //     0xc1529c: bl              #0xc14c04  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0xc152a0: add             SP, SP, #0x18
    // 0xc152a4: stur            x0, [fp, #-8]
    // 0xc152a8: ldr             x16, [fp, #0x18]
    // 0xc152ac: ldr             lr, [fp, #0x10]
    // 0xc152b0: stp             lr, x16, [SP, #-0x10]!
    // 0xc152b4: r0 = defaultStyleOf()
    //     0xc152b4: bl              #0xc15310  ; [package:flutter/src/material/text_button.dart] TextButton::defaultStyleOf
    // 0xc152b8: add             SP, SP, #0x10
    // 0xc152bc: r1 = <EdgeInsetsGeometry>
    //     0xc152bc: add             x1, PP, #0x26, lsl #12  ; [pp+0x268c8] TypeArguments: <EdgeInsetsGeometry>
    //     0xc152c0: ldr             x1, [x1, #0x8c8]
    // 0xc152c4: stur            x0, [fp, #-0x10]
    // 0xc152c8: r0 = MaterialStatePropertyAll()
    //     0xc152c8: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0xc152cc: mov             x1, x0
    // 0xc152d0: ldur            x0, [fp, #-8]
    // 0xc152d4: StoreField: r1->field_b = r0
    //     0xc152d4: stur            w0, [x1, #0xb]
    // 0xc152d8: ldur            x16, [fp, #-0x10]
    // 0xc152dc: stp             x1, x16, [SP, #-0x10]!
    // 0xc152e0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc152e0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc152e4: r0 = copyWith()
    //     0xc152e4: bl              #0xc12678  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0xc152e8: add             SP, SP, #0x10
    // 0xc152ec: LeaveFrame
    //     0xc152ec: mov             SP, fp
    //     0xc152f0: ldp             fp, lr, [SP], #0x10
    // 0xc152f4: ret
    //     0xc152f4: ret             
    // 0xc152f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc152f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc152fc: b               #0xc15224
    // 0xc15300: SaveReg d0
    //     0xc15300: str             q0, [SP, #-0x10]!
    // 0xc15304: r0 = AllocateDouble()
    //     0xc15304: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc15308: RestoreReg d0
    //     0xc15308: ldr             q0, [SP], #0x10
    // 0xc1530c: b               #0xc1526c
  }
}

// lib: , url: package:flutter/src/material/dialog.dart

// class id: 1049223, size: 0x8
class :: {

  static _ showDialog(/* No info */) {
    // ** addr: 0x8a6e58, size: 0x294
    // 0x8a6e58: EnterFrame
    //     0x8a6e58: stp             fp, lr, [SP, #-0x10]!
    //     0x8a6e5c: mov             fp, SP
    // 0x8a6e60: AllocStack(0x50)
    //     0x8a6e60: sub             SP, SP, #0x50
    // 0x8a6e64: SetupParameters(dynamic _ /* r3, fp-0x38 */, dynamic _ /* r4, fp-0x30 */, {dynamic barrierColor = Instance_Color /* r5, fp-0x28 */, dynamic barrierDismissible = true /* r6, fp-0x20 */, dynamic routeSettings = Null /* r7, fp-0x18 */, dynamic useSafeArea = true /* r1, fp-0x10 */})
    //     0x8a6e64: mov             x0, x4
    //     0x8a6e68: ldur            w1, [x0, #0x13]
    //     0x8a6e6c: add             x1, x1, HEAP, lsl #32
    //     0x8a6e70: sub             x2, x1, #4
    //     0x8a6e74: add             x3, fp, w2, sxtw #2
    //     0x8a6e78: ldr             x3, [x3, #0x18]
    //     0x8a6e7c: stur            x3, [fp, #-0x38]
    //     0x8a6e80: add             x4, fp, w2, sxtw #2
    //     0x8a6e84: ldr             x4, [x4, #0x10]
    //     0x8a6e88: stur            x4, [fp, #-0x30]
    //     0x8a6e8c: ldur            w2, [x0, #0x1f]
    //     0x8a6e90: add             x2, x2, HEAP, lsl #32
    //     0x8a6e94: add             x16, PP, #0x20, lsl #12  ; [pp+0x20930] "barrierColor"
    //     0x8a6e98: ldr             x16, [x16, #0x930]
    //     0x8a6e9c: cmp             w2, w16
    //     0x8a6ea0: b.ne            #0x8a6ec4
    //     0x8a6ea4: ldur            w2, [x0, #0x23]
    //     0x8a6ea8: add             x2, x2, HEAP, lsl #32
    //     0x8a6eac: sub             w5, w1, w2
    //     0x8a6eb0: add             x2, fp, w5, sxtw #2
    //     0x8a6eb4: ldr             x2, [x2, #8]
    //     0x8a6eb8: mov             x5, x2
    //     0x8a6ebc: mov             x2, #1
    //     0x8a6ec0: b               #0x8a6ed0
    //     0x8a6ec4: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf80] Obj!Color@b5d251
    //     0x8a6ec8: ldr             x5, [x5, #0xf80]
    //     0x8a6ecc: mov             x2, #0
    //     0x8a6ed0: stur            x5, [fp, #-0x28]
    //     0x8a6ed4: lsl             x6, x2, #1
    //     0x8a6ed8: lsl             w7, w6, #1
    //     0x8a6edc: add             w8, w7, #8
    //     0x8a6ee0: add             x16, x0, w8, sxtw #1
    //     0x8a6ee4: ldur            w9, [x16, #0xf]
    //     0x8a6ee8: add             x9, x9, HEAP, lsl #32
    //     0x8a6eec: add             x16, PP, #0x20, lsl #12  ; [pp+0x20938] "barrierDismissible"
    //     0x8a6ef0: ldr             x16, [x16, #0x938]
    //     0x8a6ef4: cmp             w9, w16
    //     0x8a6ef8: b.ne            #0x8a6f2c
    //     0x8a6efc: add             w2, w7, #0xa
    //     0x8a6f00: add             x16, x0, w2, sxtw #1
    //     0x8a6f04: ldur            w7, [x16, #0xf]
    //     0x8a6f08: add             x7, x7, HEAP, lsl #32
    //     0x8a6f0c: sub             w2, w1, w7
    //     0x8a6f10: add             x7, fp, w2, sxtw #2
    //     0x8a6f14: ldr             x7, [x7, #8]
    //     0x8a6f18: add             w2, w6, #2
    //     0x8a6f1c: sbfx            x6, x2, #1, #0x1f
    //     0x8a6f20: mov             x2, x6
    //     0x8a6f24: mov             x6, x7
    //     0x8a6f28: b               #0x8a6f30
    //     0x8a6f2c: add             x6, NULL, #0x20  ; true
    //     0x8a6f30: stur            x6, [fp, #-0x20]
    //     0x8a6f34: lsl             x7, x2, #1
    //     0x8a6f38: lsl             w8, w7, #1
    //     0x8a6f3c: add             w9, w8, #8
    //     0x8a6f40: add             x16, x0, w9, sxtw #1
    //     0x8a6f44: ldur            w10, [x16, #0xf]
    //     0x8a6f48: add             x10, x10, HEAP, lsl #32
    //     0x8a6f4c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20940] "routeSettings"
    //     0x8a6f50: ldr             x16, [x16, #0x940]
    //     0x8a6f54: cmp             w10, w16
    //     0x8a6f58: b.ne            #0x8a6f8c
    //     0x8a6f5c: add             w2, w8, #0xa
    //     0x8a6f60: add             x16, x0, w2, sxtw #1
    //     0x8a6f64: ldur            w8, [x16, #0xf]
    //     0x8a6f68: add             x8, x8, HEAP, lsl #32
    //     0x8a6f6c: sub             w2, w1, w8
    //     0x8a6f70: add             x8, fp, w2, sxtw #2
    //     0x8a6f74: ldr             x8, [x8, #8]
    //     0x8a6f78: add             w2, w7, #2
    //     0x8a6f7c: sbfx            x7, x2, #1, #0x1f
    //     0x8a6f80: mov             x2, x7
    //     0x8a6f84: mov             x7, x8
    //     0x8a6f88: b               #0x8a6f90
    //     0x8a6f8c: mov             x7, NULL
    //     0x8a6f90: stur            x7, [fp, #-0x18]
    //     0x8a6f94: lsl             x8, x2, #1
    //     0x8a6f98: lsl             w2, w8, #1
    //     0x8a6f9c: add             w8, w2, #8
    //     0x8a6fa0: add             x16, x0, w8, sxtw #1
    //     0x8a6fa4: ldur            w9, [x16, #0xf]
    //     0x8a6fa8: add             x9, x9, HEAP, lsl #32
    //     0x8a6fac: add             x16, PP, #0x20, lsl #12  ; [pp+0x20948] "useSafeArea"
    //     0x8a6fb0: ldr             x16, [x16, #0x948]
    //     0x8a6fb4: cmp             w9, w16
    //     0x8a6fb8: b.ne            #0x8a6fdc
    //     0x8a6fbc: add             w8, w2, #0xa
    //     0x8a6fc0: add             x16, x0, w8, sxtw #1
    //     0x8a6fc4: ldur            w2, [x16, #0xf]
    //     0x8a6fc8: add             x2, x2, HEAP, lsl #32
    //     0x8a6fcc: sub             w8, w1, w2
    //     0x8a6fd0: add             x1, fp, w8, sxtw #2
    //     0x8a6fd4: ldr             x1, [x1, #8]
    //     0x8a6fd8: b               #0x8a6fe0
    //     0x8a6fdc: add             x1, NULL, #0x20  ; true
    //     0x8a6fe0: stur            x1, [fp, #-0x10]
    //     0x8a6fe4: ldur            w2, [x0, #0xf]
    //     0x8a6fe8: add             x2, x2, HEAP, lsl #32
    //     0x8a6fec: cbnz            w2, #0x8a6ff8
    //     0x8a6ff0: mov             x0, NULL
    //     0x8a6ff4: b               #0x8a7008
    //     0x8a6ff8: ldur            w2, [x0, #0x17]
    //     0x8a6ffc: add             x2, x2, HEAP, lsl #32
    //     0x8a7000: add             x0, fp, w2, sxtw #2
    //     0x8a7004: ldr             x0, [x0, #0x10]
    //     0x8a7008: stur            x0, [fp, #-8]
    // 0x8a700c: CheckStackOverflow
    //     0x8a700c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8a7010: cmp             SP, x16
    //     0x8a7014: b.ls            #0x8a70e0
    // 0x8a7018: r16 = true
    //     0x8a7018: add             x16, NULL, #0x20  ; true
    // 0x8a701c: stp             x16, x4, [SP, #-0x10]!
    // 0x8a7020: r4 = const [0, 0x2, 0x2, 0x1, rootNavigator, 0x1, null]
    //     0x8a7020: add             x4, PP, #0x20, lsl #12  ; [pp+0x20800] List(7) [0, 0x2, 0x2, 0x1, "rootNavigator", 0x1, Null]
    //     0x8a7024: ldr             x4, [x4, #0x800]
    // 0x8a7028: r0 = of()
    //     0x8a7028: bl              #0x5a0f40  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8a702c: add             SP, SP, #0x10
    // 0x8a7030: LoadField: r1 = r0->field_f
    //     0x8a7030: ldur            w1, [x0, #0xf]
    // 0x8a7034: DecompressPointer r1
    //     0x8a7034: add             x1, x1, HEAP, lsl #32
    // 0x8a7038: cmp             w1, NULL
    // 0x8a703c: b.eq            #0x8a70e8
    // 0x8a7040: ldur            x16, [fp, #-0x30]
    // 0x8a7044: stp             x1, x16, [SP, #-0x10]!
    // 0x8a7048: r0 = capture()
    //     0x8a7048: bl              #0x7cc5c4  ; [package:flutter/src/widgets/inherited_theme.dart] InheritedTheme::capture
    // 0x8a704c: add             SP, SP, #0x10
    // 0x8a7050: stur            x0, [fp, #-0x40]
    // 0x8a7054: ldur            x16, [fp, #-0x30]
    // 0x8a7058: r30 = true
    //     0x8a7058: add             lr, NULL, #0x20  ; true
    // 0x8a705c: stp             lr, x16, [SP, #-0x10]!
    // 0x8a7060: r4 = const [0, 0x2, 0x2, 0x1, rootNavigator, 0x1, null]
    //     0x8a7060: add             x4, PP, #0x20, lsl #12  ; [pp+0x20800] List(7) [0, 0x2, 0x2, 0x1, "rootNavigator", 0x1, Null]
    //     0x8a7064: ldr             x4, [x4, #0x800]
    // 0x8a7068: r0 = of()
    //     0x8a7068: bl              #0x5a0f40  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0x8a706c: add             SP, SP, #0x10
    // 0x8a7070: ldur            x1, [fp, #-8]
    // 0x8a7074: stur            x0, [fp, #-0x48]
    // 0x8a7078: r0 = DialogRoute()
    //     0x8a7078: bl              #0x8a7340  ; AllocateDialogRouteStub -> DialogRoute<X0> (size=0x98)
    // 0x8a707c: stur            x0, [fp, #-0x50]
    // 0x8a7080: ldur            x16, [fp, #-0x28]
    // 0x8a7084: stp             x16, x0, [SP, #-0x10]!
    // 0x8a7088: ldur            x16, [fp, #-0x20]
    // 0x8a708c: ldur            lr, [fp, #-0x38]
    // 0x8a7090: stp             lr, x16, [SP, #-0x10]!
    // 0x8a7094: ldur            x16, [fp, #-0x30]
    // 0x8a7098: ldur            lr, [fp, #-0x18]
    // 0x8a709c: stp             lr, x16, [SP, #-0x10]!
    // 0x8a70a0: ldur            x16, [fp, #-0x40]
    // 0x8a70a4: ldur            lr, [fp, #-0x10]
    // 0x8a70a8: stp             lr, x16, [SP, #-0x10]!
    // 0x8a70ac: r0 = DialogRoute()
    //     0x8a70ac: bl              #0x8a70ec  ; [package:flutter/src/material/dialog.dart] DialogRoute::DialogRoute
    // 0x8a70b0: add             SP, SP, #0x40
    // 0x8a70b4: ldur            x16, [fp, #-8]
    // 0x8a70b8: ldur            lr, [fp, #-0x48]
    // 0x8a70bc: stp             lr, x16, [SP, #-0x10]!
    // 0x8a70c0: ldur            x16, [fp, #-0x50]
    // 0x8a70c4: SaveReg r16
    //     0x8a70c4: str             x16, [SP, #-8]!
    // 0x8a70c8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8a70c8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8a70cc: r0 = push()
    //     0x8a70cc: bl              #0x508e98  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0x8a70d0: add             SP, SP, #0x18
    // 0x8a70d4: LeaveFrame
    //     0x8a70d4: mov             SP, fp
    //     0x8a70d8: ldp             fp, lr, [SP], #0x10
    // 0x8a70dc: ret
    //     0x8a70dc: ret             
    // 0x8a70e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a70e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a70e4: b               #0x8a7018
    // 0x8a70e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8a70e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static Widget _buildMaterialDialogTransitions(dynamic, BuildContext, Animation<double>, Animation<double>, Widget) {
    // ** addr: 0x8a71a4, size: 0x48
    // 0x8a71a4: EnterFrame
    //     0x8a71a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8a71a8: mov             fp, SP
    // 0x8a71ac: CheckStackOverflow
    //     0x8a71ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8a71b0: cmp             SP, x16
    //     0x8a71b4: b.ls            #0x8a71e4
    // 0x8a71b8: ldr             x16, [fp, #0x28]
    // 0x8a71bc: ldr             lr, [fp, #0x20]
    // 0x8a71c0: stp             lr, x16, [SP, #-0x10]!
    // 0x8a71c4: ldr             x16, [fp, #0x18]
    // 0x8a71c8: ldr             lr, [fp, #0x10]
    // 0x8a71cc: stp             lr, x16, [SP, #-0x10]!
    // 0x8a71d0: r0 = _buildMaterialDialogTransitions()
    //     0x8a71d0: bl              #0x8a71ec  ; [package:flutter/src/material/dialog.dart] ::_buildMaterialDialogTransitions
    // 0x8a71d4: add             SP, SP, #0x20
    // 0x8a71d8: LeaveFrame
    //     0x8a71d8: mov             SP, fp
    //     0x8a71dc: ldp             fp, lr, [SP], #0x10
    // 0x8a71e0: ret
    //     0x8a71e0: ret             
    // 0x8a71e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a71e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a71e8: b               #0x8a71b8
  }
  static _ _buildMaterialDialogTransitions(/* No info */) {
    // ** addr: 0x8a71ec, size: 0x74
    // 0x8a71ec: EnterFrame
    //     0x8a71ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8a71f0: mov             fp, SP
    // 0x8a71f4: AllocStack(0x8)
    //     0x8a71f4: sub             SP, SP, #8
    // 0x8a71f8: CheckStackOverflow
    //     0x8a71f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8a71fc: cmp             SP, x16
    //     0x8a7200: b.ls            #0x8a7258
    // 0x8a7204: r1 = <double>
    //     0x8a7204: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8a7208: r0 = CurvedAnimation()
    //     0x8a7208: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x8a720c: stur            x0, [fp, #-8]
    // 0x8a7210: r16 = Instance_Cubic
    //     0x8a7210: add             x16, PP, #0x20, lsl #12  ; [pp+0x20970] Obj!Cubic<double>@b4f3a1
    //     0x8a7214: ldr             x16, [x16, #0x970]
    // 0x8a7218: stp             x16, x0, [SP, #-0x10]!
    // 0x8a721c: ldr             x16, [fp, #0x20]
    // 0x8a7220: SaveReg r16
    //     0x8a7220: str             x16, [SP, #-8]!
    // 0x8a7224: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x8a7224: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x8a7228: r0 = CurvedAnimation()
    //     0x8a7228: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x8a722c: add             SP, SP, #0x18
    // 0x8a7230: r0 = FadeTransition()
    //     0x8a7230: bl              #0x7b43dc  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x8a7234: ldur            x1, [fp, #-8]
    // 0x8a7238: StoreField: r0->field_f = r1
    //     0x8a7238: stur            w1, [x0, #0xf]
    // 0x8a723c: r1 = false
    //     0x8a723c: add             x1, NULL, #0x30  ; false
    // 0x8a7240: StoreField: r0->field_13 = r1
    //     0x8a7240: stur            w1, [x0, #0x13]
    // 0x8a7244: ldr             x1, [fp, #0x10]
    // 0x8a7248: StoreField: r0->field_b = r1
    //     0x8a7248: stur            w1, [x0, #0xb]
    // 0x8a724c: LeaveFrame
    //     0x8a724c: mov             SP, fp
    //     0x8a7250: ldp             fp, lr, [SP], #0x10
    // 0x8a7254: ret
    //     0x8a7254: ret             
    // 0x8a7258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a7258: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a725c: b               #0x8a7204
  }
  static _ _paddingScaleFactor(/* No info */) {
    // ** addr: 0xb1fe0c, size: 0xd0
    // 0xb1fe0c: EnterFrame
    //     0xb1fe0c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1fe10: mov             fp, SP
    // 0xb1fe14: d0 = 1.000000
    //     0xb1fe14: fmov            d0, #1.00000000
    // 0xb1fe18: CheckStackOverflow
    //     0xb1fe18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1fe1c: cmp             SP, x16
    //     0xb1fe20: b.ls            #0xb1fec0
    // 0xb1fe24: ldr             d1, [fp, #0x10]
    // 0xb1fe28: fcmp            d1, d0
    // 0xb1fe2c: b.vs            #0xb1fe3c
    // 0xb1fe30: b.ge            #0xb1fe3c
    // 0xb1fe34: d1 = 1.000000
    //     0xb1fe34: fmov            d1, #1.00000000
    // 0xb1fe38: b               #0xb1fe60
    // 0xb1fe3c: d2 = 2.000000
    //     0xb1fe3c: fmov            d2, #2.00000000
    // 0xb1fe40: fcmp            d1, d2
    // 0xb1fe44: b.vs            #0xb1fe54
    // 0xb1fe48: b.le            #0xb1fe54
    // 0xb1fe4c: d1 = 2.000000
    //     0xb1fe4c: fmov            d1, #2.00000000
    // 0xb1fe50: b               #0xb1fe60
    // 0xb1fe54: fcmp            d1, d1
    // 0xb1fe58: b.vc            #0xb1fe60
    // 0xb1fe5c: d1 = 2.000000
    //     0xb1fe5c: fmov            d1, #2.00000000
    // 0xb1fe60: fsub            d2, d1, d0
    // 0xb1fe64: r0 = inline_Allocate_Double()
    //     0xb1fe64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1fe68: add             x0, x0, #0x10
    //     0xb1fe6c: cmp             x1, x0
    //     0xb1fe70: b.ls            #0xb1fec8
    //     0xb1fe74: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1fe78: sub             x0, x0, #0xf
    //     0xb1fe7c: mov             x1, #0xd108
    //     0xb1fe80: movk            x1, #3, lsl #16
    //     0xb1fe84: stur            x1, [x0, #-1]
    // 0xb1fe88: StoreField: r0->field_7 = d2
    //     0xb1fe88: stur            d2, [x0, #7]
    // 0xb1fe8c: r16 = 1.000000
    //     0xb1fe8c: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb1fe90: r30 = 0.333333
    //     0xb1fe90: add             lr, PP, #0x28, lsl #12  ; [pp+0x28c68] 0.3333333333333333
    //     0xb1fe94: ldr             lr, [lr, #0xc68]
    // 0xb1fe98: stp             lr, x16, [SP, #-0x10]!
    // 0xb1fe9c: SaveReg r0
    //     0xb1fe9c: str             x0, [SP, #-8]!
    // 0xb1fea0: r0 = lerpDouble()
    //     0xb1fea0: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xb1fea4: add             SP, SP, #0x18
    // 0xb1fea8: cmp             w0, NULL
    // 0xb1feac: b.eq            #0xb1fed8
    // 0xb1feb0: LoadField: d0 = r0->field_7
    //     0xb1feb0: ldur            d0, [x0, #7]
    // 0xb1feb4: LeaveFrame
    //     0xb1feb4: mov             SP, fp
    //     0xb1feb8: ldp             fp, lr, [SP], #0x10
    // 0xb1febc: ret
    //     0xb1febc: ret             
    // 0xb1fec0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb1fec0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xb1fec4: b               #0xb1fe24
    // 0xb1fec8: SaveReg d2
    //     0xb1fec8: str             q2, [SP, #-0x10]!
    // 0xb1fecc: r0 = AllocateDouble()
    //     0xb1fecc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb1fed0: RestoreReg d2
    //     0xb1fed0: ldr             q2, [SP], #0x10
    // 0xb1fed4: b               #0xb1fe88
    // 0xb1fed8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1fed8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 1782, size: 0x98, field offset: 0x98
class DialogRoute<X0> extends RawDialogRoute<X0> {

  _ DialogRoute(/* No info */) {
    // ** addr: 0x8a70ec, size: 0xb8
    // 0x8a70ec: EnterFrame
    //     0x8a70ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8a70f0: mov             fp, SP
    // 0x8a70f4: AllocStack(0x8)
    //     0x8a70f4: sub             SP, SP, #8
    // 0x8a70f8: CheckStackOverflow
    //     0x8a70f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8a70fc: cmp             SP, x16
    //     0x8a7100: b.ls            #0x8a719c
    // 0x8a7104: r1 = 3
    //     0x8a7104: mov             x1, #3
    // 0x8a7108: r0 = AllocateContext()
    //     0x8a7108: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8a710c: mov             x1, x0
    // 0x8a7110: ldr             x0, [fp, #0x30]
    // 0x8a7114: stur            x1, [fp, #-8]
    // 0x8a7118: StoreField: r1->field_f = r0
    //     0x8a7118: stur            w0, [x1, #0xf]
    // 0x8a711c: ldr             x0, [fp, #0x18]
    // 0x8a7120: StoreField: r1->field_13 = r0
    //     0x8a7120: stur            w0, [x1, #0x13]
    // 0x8a7124: ldr             x0, [fp, #0x10]
    // 0x8a7128: StoreField: r1->field_17 = r0
    //     0x8a7128: stur            w0, [x1, #0x17]
    // 0x8a712c: ldr             x16, [fp, #0x28]
    // 0x8a7130: SaveReg r16
    //     0x8a7130: str             x16, [SP, #-8]!
    // 0x8a7134: r0 = of()
    //     0x8a7134: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x8a7138: add             SP, SP, #8
    // 0x8a713c: ldur            x2, [fp, #-8]
    // 0x8a7140: r1 = Function '<anonymous closure>':.
    //     0x8a7140: add             x1, PP, #0x20, lsl #12  ; [pp+0x20950] AnonymousClosure: (0x8a7260), in [package:flutter/src/material/dialog.dart] DialogRoute::DialogRoute (0x8a70ec)
    //     0x8a7144: ldr             x1, [x1, #0x950]
    // 0x8a7148: r0 = AllocateClosure()
    //     0x8a7148: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8a714c: ldr             x16, [fp, #0x48]
    // 0x8a7150: ldr             lr, [fp, #0x40]
    // 0x8a7154: stp             lr, x16, [SP, #-0x10]!
    // 0x8a7158: ldr             x16, [fp, #0x38]
    // 0x8a715c: r30 = "Dismiss"
    //     0x8a715c: add             lr, PP, #0x20, lsl #12  ; [pp+0x20958] "Dismiss"
    //     0x8a7160: ldr             lr, [lr, #0x958]
    // 0x8a7164: stp             lr, x16, [SP, #-0x10]!
    // 0x8a7168: ldr             x16, [fp, #0x20]
    // 0x8a716c: stp             x16, x0, [SP, #-0x10]!
    // 0x8a7170: r16 = Closure: (BuildContext, Animation<double>, Animation<double>, Widget) => Widget from Function '_buildMaterialDialogTransitions@724506021': static.
    //     0x8a7170: add             x16, PP, #0x20, lsl #12  ; [pp+0x20960] Closure: (BuildContext, Animation<double>, Animation<double>, Widget) => Widget from Function '_buildMaterialDialogTransitions@724506021': static. (0x7fe6e20a71a4)
    //     0x8a7174: ldr             x16, [x16, #0x960]
    // 0x8a7178: r30 = Instance_Duration
    //     0x8a7178: add             lr, PP, #0x20, lsl #12  ; [pp+0x20968] Obj!Duration@b67b41
    //     0x8a717c: ldr             lr, [lr, #0x968]
    // 0x8a7180: stp             lr, x16, [SP, #-0x10]!
    // 0x8a7184: r0 = RawDialogRoute()
    //     0x8a7184: bl              #0x5a0894  ; [package:flutter/src/widgets/routes.dart] RawDialogRoute::RawDialogRoute
    // 0x8a7188: add             SP, SP, #0x40
    // 0x8a718c: r0 = Null
    //     0x8a718c: mov             x0, NULL
    // 0x8a7190: LeaveFrame
    //     0x8a7190: mov             SP, fp
    //     0x8a7194: ldp             fp, lr, [SP], #0x10
    // 0x8a7198: ret
    //     0x8a7198: ret             
    // 0x8a719c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a719c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a71a0: b               #0x8a7104
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Animation<double>, Animation<double>) {
    // ** addr: 0x8a7260, size: 0xe0
    // 0x8a7260: EnterFrame
    //     0x8a7260: stp             fp, lr, [SP, #-0x10]!
    //     0x8a7264: mov             fp, SP
    // 0x8a7268: AllocStack(0x18)
    //     0x8a7268: sub             SP, SP, #0x18
    // 0x8a726c: SetupParameters()
    //     0x8a726c: ldr             x0, [fp, #0x28]
    //     0x8a7270: ldur            w1, [x0, #0x17]
    //     0x8a7274: add             x1, x1, HEAP, lsl #32
    //     0x8a7278: stur            x1, [fp, #-0x10]
    // 0x8a727c: CheckStackOverflow
    //     0x8a727c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8a7280: cmp             SP, x16
    //     0x8a7284: b.ls            #0x8a7338
    // 0x8a7288: LoadField: r0 = r1->field_f
    //     0x8a7288: ldur            w0, [x1, #0xf]
    // 0x8a728c: DecompressPointer r0
    //     0x8a728c: add             x0, x0, HEAP, lsl #32
    // 0x8a7290: stur            x0, [fp, #-8]
    // 0x8a7294: r0 = Builder()
    //     0x8a7294: bl              #0x830cbc  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0x8a7298: mov             x1, x0
    // 0x8a729c: ldur            x0, [fp, #-8]
    // 0x8a72a0: StoreField: r1->field_b = r0
    //     0x8a72a0: stur            w0, [x1, #0xb]
    // 0x8a72a4: ldur            x0, [fp, #-0x10]
    // 0x8a72a8: LoadField: r2 = r0->field_13
    //     0x8a72a8: ldur            w2, [x0, #0x13]
    // 0x8a72ac: DecompressPointer r2
    //     0x8a72ac: add             x2, x2, HEAP, lsl #32
    // 0x8a72b0: stp             x1, x2, [SP, #-0x10]!
    // 0x8a72b4: r0 = wrap()
    //     0x8a72b4: bl              #0x7ccb6c  ; [package:flutter/src/widgets/inherited_theme.dart] CapturedThemes::wrap
    // 0x8a72b8: add             SP, SP, #0x10
    // 0x8a72bc: mov             x1, x0
    // 0x8a72c0: ldur            x0, [fp, #-0x10]
    // 0x8a72c4: stur            x1, [fp, #-0x18]
    // 0x8a72c8: LoadField: r2 = r0->field_17
    //     0x8a72c8: ldur            w2, [x0, #0x17]
    // 0x8a72cc: DecompressPointer r2
    //     0x8a72cc: add             x2, x2, HEAP, lsl #32
    // 0x8a72d0: mov             x0, x2
    // 0x8a72d4: stur            x2, [fp, #-8]
    // 0x8a72d8: tbnz            w0, #5, #0x8a72e0
    // 0x8a72dc: r0 = AssertBoolean()
    //     0x8a72dc: bl              #0xd67df0  ; AssertBooleanStub
    // 0x8a72e0: ldur            x0, [fp, #-8]
    // 0x8a72e4: tbnz            w0, #4, #0x8a7324
    // 0x8a72e8: ldur            x0, [fp, #-0x18]
    // 0x8a72ec: r0 = SafeArea()
    //     0x8a72ec: bl              #0x847d4c  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0x8a72f0: r1 = true
    //     0x8a72f0: add             x1, NULL, #0x20  ; true
    // 0x8a72f4: StoreField: r0->field_b = r1
    //     0x8a72f4: stur            w1, [x0, #0xb]
    // 0x8a72f8: StoreField: r0->field_f = r1
    //     0x8a72f8: stur            w1, [x0, #0xf]
    // 0x8a72fc: StoreField: r0->field_13 = r1
    //     0x8a72fc: stur            w1, [x0, #0x13]
    // 0x8a7300: StoreField: r0->field_17 = r1
    //     0x8a7300: stur            w1, [x0, #0x17]
    // 0x8a7304: r1 = Instance_EdgeInsets
    //     0x8a7304: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x8a7308: ldr             x1, [x1, #0xbd8]
    // 0x8a730c: StoreField: r0->field_1b = r1
    //     0x8a730c: stur            w1, [x0, #0x1b]
    // 0x8a7310: r1 = false
    //     0x8a7310: add             x1, NULL, #0x30  ; false
    // 0x8a7314: StoreField: r0->field_1f = r1
    //     0x8a7314: stur            w1, [x0, #0x1f]
    // 0x8a7318: ldur            x1, [fp, #-0x18]
    // 0x8a731c: StoreField: r0->field_23 = r1
    //     0x8a731c: stur            w1, [x0, #0x23]
    // 0x8a7320: b               #0x8a732c
    // 0x8a7324: ldur            x1, [fp, #-0x18]
    // 0x8a7328: mov             x0, x1
    // 0x8a732c: LeaveFrame
    //     0x8a732c: mov             SP, fp
    //     0x8a7330: ldp             fp, lr, [SP], #0x10
    // 0x8a7334: ret
    //     0x8a7334: ret             
    // 0x8a7338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a7338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a733c: b               #0x8a7288
  }
}

// class id: 2810, size: 0x34, field offset: 0x30
//   const constructor, 
class _DialogFullscreenDefaultsM3 extends DialogTheme {
}

// class id: 2811, size: 0x3c, field offset: 0x30
class _DialogDefaultsM3 extends DialogTheme {

  late final ColorScheme _colors; // offset: 0x34
  late final TextTheme _textTheme; // offset: 0x38

  ColorScheme _colors(_DialogDefaultsM3) {
    // ** addr: 0xb1f3f4, size: 0x4c
    // 0xb1f3f4: EnterFrame
    //     0xb1f3f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb1f3f8: mov             fp, SP
    // 0xb1f3fc: CheckStackOverflow
    //     0xb1f3fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1f400: cmp             SP, x16
    //     0xb1f404: b.ls            #0xb1f438
    // 0xb1f408: ldr             x0, [fp, #0x10]
    // 0xb1f40c: LoadField: r1 = r0->field_2f
    //     0xb1f40c: ldur            w1, [x0, #0x2f]
    // 0xb1f410: DecompressPointer r1
    //     0xb1f410: add             x1, x1, HEAP, lsl #32
    // 0xb1f414: SaveReg r1
    //     0xb1f414: str             x1, [SP, #-8]!
    // 0xb1f418: r0 = of()
    //     0xb1f418: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1f41c: add             SP, SP, #8
    // 0xb1f420: LoadField: r1 = r0->field_3f
    //     0xb1f420: ldur            w1, [x0, #0x3f]
    // 0xb1f424: DecompressPointer r1
    //     0xb1f424: add             x1, x1, HEAP, lsl #32
    // 0xb1f428: mov             x0, x1
    // 0xb1f42c: LeaveFrame
    //     0xb1f42c: mov             SP, fp
    //     0xb1f430: ldp             fp, lr, [SP], #0x10
    // 0xb1f434: ret
    //     0xb1f434: ret             
    // 0xb1f438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1f438: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1f43c: b               #0xb1f408
  }
  TextTheme _textTheme(_DialogDefaultsM3) {
    // ** addr: 0xb1fedc, size: 0x4c
    // 0xb1fedc: EnterFrame
    //     0xb1fedc: stp             fp, lr, [SP, #-0x10]!
    //     0xb1fee0: mov             fp, SP
    // 0xb1fee4: CheckStackOverflow
    //     0xb1fee4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1fee8: cmp             SP, x16
    //     0xb1feec: b.ls            #0xb1ff20
    // 0xb1fef0: ldr             x0, [fp, #0x10]
    // 0xb1fef4: LoadField: r1 = r0->field_2f
    //     0xb1fef4: ldur            w1, [x0, #0x2f]
    // 0xb1fef8: DecompressPointer r1
    //     0xb1fef8: add             x1, x1, HEAP, lsl #32
    // 0xb1fefc: SaveReg r1
    //     0xb1fefc: str             x1, [SP, #-8]!
    // 0xb1ff00: r0 = of()
    //     0xb1ff00: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1ff04: add             SP, SP, #8
    // 0xb1ff08: LoadField: r1 = r0->field_93
    //     0xb1ff08: ldur            w1, [x0, #0x93]
    // 0xb1ff0c: DecompressPointer r1
    //     0xb1ff0c: add             x1, x1, HEAP, lsl #32
    // 0xb1ff10: mov             x0, x1
    // 0xb1ff14: LeaveFrame
    //     0xb1ff14: mov             SP, fp
    //     0xb1ff18: ldp             fp, lr, [SP], #0x10
    // 0xb1ff1c: ret
    //     0xb1ff1c: ret             
    // 0xb1ff20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1ff20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1ff24: b               #0xb1fef0
  }
}

// class id: 2812, size: 0x3c, field offset: 0x30
class _DialogDefaultsM2 extends DialogTheme {

  _ _DialogDefaultsM2(/* No info */) {
    // ** addr: 0xb1f2ac, size: 0xec
    // 0xb1f2ac: EnterFrame
    //     0xb1f2ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb1f2b0: mov             fp, SP
    // 0xb1f2b4: CheckStackOverflow
    //     0xb1f2b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1f2b8: cmp             SP, x16
    //     0xb1f2bc: b.ls            #0xb1f390
    // 0xb1f2c0: ldr             x0, [fp, #0x10]
    // 0xb1f2c4: ldr             x1, [fp, #0x18]
    // 0xb1f2c8: StoreField: r1->field_2f = r0
    //     0xb1f2c8: stur            w0, [x1, #0x2f]
    //     0xb1f2cc: ldurb           w16, [x1, #-1]
    //     0xb1f2d0: ldurb           w17, [x0, #-1]
    //     0xb1f2d4: and             x16, x17, x16, lsr #2
    //     0xb1f2d8: tst             x16, HEAP, lsr #32
    //     0xb1f2dc: b.eq            #0xb1f2e4
    //     0xb1f2e0: bl              #0xd6826c
    // 0xb1f2e4: ldr             x16, [fp, #0x10]
    // 0xb1f2e8: SaveReg r16
    //     0xb1f2e8: str             x16, [SP, #-8]!
    // 0xb1f2ec: r0 = of()
    //     0xb1f2ec: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1f2f0: add             SP, SP, #8
    // 0xb1f2f4: LoadField: r1 = r0->field_93
    //     0xb1f2f4: ldur            w1, [x0, #0x93]
    // 0xb1f2f8: DecompressPointer r1
    //     0xb1f2f8: add             x1, x1, HEAP, lsl #32
    // 0xb1f2fc: mov             x0, x1
    // 0xb1f300: ldr             x1, [fp, #0x18]
    // 0xb1f304: StoreField: r1->field_33 = r0
    //     0xb1f304: stur            w0, [x1, #0x33]
    //     0xb1f308: ldurb           w16, [x1, #-1]
    //     0xb1f30c: ldurb           w17, [x0, #-1]
    //     0xb1f310: and             x16, x17, x16, lsr #2
    //     0xb1f314: tst             x16, HEAP, lsr #32
    //     0xb1f318: b.eq            #0xb1f320
    //     0xb1f31c: bl              #0xd6826c
    // 0xb1f320: ldr             x16, [fp, #0x10]
    // 0xb1f324: SaveReg r16
    //     0xb1f324: str             x16, [SP, #-8]!
    // 0xb1f328: r0 = of()
    //     0xb1f328: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1f32c: add             SP, SP, #8
    // 0xb1f330: LoadField: r1 = r0->field_87
    //     0xb1f330: ldur            w1, [x0, #0x87]
    // 0xb1f334: DecompressPointer r1
    //     0xb1f334: add             x1, x1, HEAP, lsl #32
    // 0xb1f338: mov             x0, x1
    // 0xb1f33c: ldr             x1, [fp, #0x18]
    // 0xb1f340: StoreField: r1->field_37 = r0
    //     0xb1f340: stur            w0, [x1, #0x37]
    //     0xb1f344: ldurb           w16, [x1, #-1]
    //     0xb1f348: ldurb           w17, [x0, #-1]
    //     0xb1f34c: and             x16, x17, x16, lsr #2
    //     0xb1f350: tst             x16, HEAP, lsr #32
    //     0xb1f354: b.eq            #0xb1f35c
    //     0xb1f358: bl              #0xd6826c
    // 0xb1f35c: r2 = 24.000000
    //     0xb1f35c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xb1f360: ldr             x2, [x2, #0x360]
    // 0xb1f364: StoreField: r1->field_b = r2
    //     0xb1f364: stur            w2, [x1, #0xb]
    // 0xb1f368: r2 = Instance_RoundedRectangleBorder
    //     0xb1f368: add             x2, PP, #0xe, lsl #12  ; [pp+0xe450] Obj!RoundedRectangleBorder@b383f1
    //     0xb1f36c: ldr             x2, [x2, #0x450]
    // 0xb1f370: StoreField: r1->field_17 = r2
    //     0xb1f370: stur            w2, [x1, #0x17]
    // 0xb1f374: r2 = Instance_Alignment
    //     0xb1f374: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb1f378: ldr             x2, [x2, #0xc70]
    // 0xb1f37c: StoreField: r1->field_1b = r2
    //     0xb1f37c: stur            w2, [x1, #0x1b]
    // 0xb1f380: r0 = Null
    //     0xb1f380: mov             x0, NULL
    // 0xb1f384: LeaveFrame
    //     0xb1f384: mov             SP, fp
    //     0xb1f388: ldp             fp, lr, [SP], #0x10
    // 0xb1f38c: ret
    //     0xb1f38c: ret             
    // 0xb1f390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1f390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1f394: b               #0xb1f2c0
  }
}

// class id: 3858, size: 0x74, field offset: 0xc
//   const constructor, 
class AlertDialog extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1f440, size: 0x9b4
    // 0xb1f440: EnterFrame
    //     0xb1f440: stp             fp, lr, [SP, #-0x10]!
    //     0xb1f444: mov             fp, SP
    // 0xb1f448: AllocStack(0x68)
    //     0xb1f448: sub             SP, SP, #0x68
    // 0xb1f44c: CheckStackOverflow
    //     0xb1f44c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1f450: cmp             SP, x16
    //     0xb1f454: b.ls            #0xb1fdd0
    // 0xb1f458: ldr             x16, [fp, #0x10]
    // 0xb1f45c: SaveReg r16
    //     0xb1f45c: str             x16, [SP, #-8]!
    // 0xb1f460: r0 = of()
    //     0xb1f460: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1f464: add             SP, SP, #8
    // 0xb1f468: stur            x0, [fp, #-8]
    // 0xb1f46c: ldr             x16, [fp, #0x10]
    // 0xb1f470: SaveReg r16
    //     0xb1f470: str             x16, [SP, #-8]!
    // 0xb1f474: r0 = of()
    //     0xb1f474: bl              #0xb1f3b0  ; [package:flutter/src/material/dialog_theme.dart] DialogTheme::of
    // 0xb1f478: add             SP, SP, #8
    // 0xb1f47c: ldur            x0, [fp, #-8]
    // 0xb1f480: LoadField: r1 = r0->field_2b
    //     0xb1f480: ldur            w1, [x0, #0x2b]
    // 0xb1f484: DecompressPointer r1
    //     0xb1f484: add             x1, x1, HEAP, lsl #32
    // 0xb1f488: stur            x1, [fp, #-0x10]
    // 0xb1f48c: tbnz            w1, #4, #0xb1f4d8
    // 0xb1f490: ldr             x2, [fp, #0x10]
    // 0xb1f494: r0 = _DialogDefaultsM3()
    //     0xb1f494: bl              #0xb1f3a4  ; Allocate_DialogDefaultsM3Stub -> _DialogDefaultsM3 (size=0x3c)
    // 0xb1f498: mov             x1, x0
    // 0xb1f49c: r0 = Sentinel
    //     0xb1f49c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb1f4a0: StoreField: r1->field_33 = r0
    //     0xb1f4a0: stur            w0, [x1, #0x33]
    // 0xb1f4a4: StoreField: r1->field_37 = r0
    //     0xb1f4a4: stur            w0, [x1, #0x37]
    // 0xb1f4a8: ldr             x0, [fp, #0x10]
    // 0xb1f4ac: StoreField: r1->field_2f = r0
    //     0xb1f4ac: stur            w0, [x1, #0x2f]
    // 0xb1f4b0: r2 = 6.000000
    //     0xb1f4b0: add             x2, PP, #0x28, lsl #12  ; [pp+0x28c20] 6
    //     0xb1f4b4: ldr             x2, [x2, #0xc20]
    // 0xb1f4b8: StoreField: r1->field_b = r2
    //     0xb1f4b8: stur            w2, [x1, #0xb]
    // 0xb1f4bc: r2 = Instance_RoundedRectangleBorder
    //     0xb1f4bc: add             x2, PP, #0xe, lsl #12  ; [pp+0xe340] Obj!RoundedRectangleBorder@b38411
    //     0xb1f4c0: ldr             x2, [x2, #0x340]
    // 0xb1f4c4: StoreField: r1->field_17 = r2
    //     0xb1f4c4: stur            w2, [x1, #0x17]
    // 0xb1f4c8: r2 = Instance_Alignment
    //     0xb1f4c8: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb1f4cc: ldr             x2, [x2, #0xc70]
    // 0xb1f4d0: StoreField: r1->field_1b = r2
    //     0xb1f4d0: stur            w2, [x1, #0x1b]
    // 0xb1f4d4: b               #0xb1f4f8
    // 0xb1f4d8: ldr             x0, [fp, #0x10]
    // 0xb1f4dc: r0 = _DialogDefaultsM2()
    //     0xb1f4dc: bl              #0xb1f398  ; Allocate_DialogDefaultsM2Stub -> _DialogDefaultsM2 (size=0x3c)
    // 0xb1f4e0: stur            x0, [fp, #-0x18]
    // 0xb1f4e4: ldr             x16, [fp, #0x10]
    // 0xb1f4e8: stp             x16, x0, [SP, #-0x10]!
    // 0xb1f4ec: r0 = _DialogDefaultsM2()
    //     0xb1f4ec: bl              #0xb1f2ac  ; [package:flutter/src/material/dialog.dart] _DialogDefaultsM2::_DialogDefaultsM2
    // 0xb1f4f0: add             SP, SP, #0x10
    // 0xb1f4f4: ldur            x1, [fp, #-0x18]
    // 0xb1f4f8: ldur            x0, [fp, #-8]
    // 0xb1f4fc: stur            x1, [fp, #-0x20]
    // 0xb1f500: LoadField: r2 = r0->field_1f
    //     0xb1f500: ldur            w2, [x0, #0x1f]
    // 0xb1f504: DecompressPointer r2
    //     0xb1f504: add             x2, x2, HEAP, lsl #32
    // 0xb1f508: stur            x2, [fp, #-0x18]
    // 0xb1f50c: LoadField: r0 = r2->field_7
    //     0xb1f50c: ldur            x0, [x2, #7]
    // 0xb1f510: cmp             x0, #2
    // 0xb1f514: b.gt            #0xb1f524
    // 0xb1f518: cmp             x0, #1
    // 0xb1f51c: b.gt            #0xb1f534
    // 0xb1f520: b               #0xb1f53c
    // 0xb1f524: cmp             x0, #4
    // 0xb1f528: b.gt            #0xb1f53c
    // 0xb1f52c: cmp             x0, #3
    // 0xb1f530: b.le            #0xb1f53c
    // 0xb1f534: r1 = Null
    //     0xb1f534: mov             x1, NULL
    // 0xb1f538: b               #0xb1f554
    // 0xb1f53c: ldr             x16, [fp, #0x10]
    // 0xb1f540: SaveReg r16
    //     0xb1f540: str             x16, [SP, #-8]!
    // 0xb1f544: r0 = of()
    //     0xb1f544: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xb1f548: add             SP, SP, #8
    // 0xb1f54c: r1 = "Alert"
    //     0xb1f54c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c28] "Alert"
    //     0xb1f550: ldr             x1, [x1, #0xc28]
    // 0xb1f554: ldr             x0, [fp, #0x18]
    // 0xb1f558: stur            x1, [fp, #-8]
    // 0xb1f55c: ldr             x16, [fp, #0x10]
    // 0xb1f560: SaveReg r16
    //     0xb1f560: str             x16, [SP, #-8]!
    // 0xb1f564: r0 = of()
    //     0xb1f564: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xb1f568: add             SP, SP, #8
    // 0xb1f56c: LoadField: d0 = r0->field_13
    //     0xb1f56c: ldur            d0, [x0, #0x13]
    // 0xb1f570: SaveReg d0
    //     0xb1f570: str             d0, [SP, #-8]!
    // 0xb1f574: r0 = _paddingScaleFactor()
    //     0xb1f574: bl              #0xb1fe0c  ; [package:flutter/src/material/dialog.dart] ::_paddingScaleFactor
    // 0xb1f578: add             SP, SP, #8
    // 0xb1f57c: stur            d0, [fp, #-0x60]
    // 0xb1f580: ldr             x16, [fp, #0x10]
    // 0xb1f584: SaveReg r16
    //     0xb1f584: str             x16, [SP, #-8]!
    // 0xb1f588: r0 = maybeOf()
    //     0xb1f588: bl              #0x6c2c58  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xb1f58c: add             SP, SP, #8
    // 0xb1f590: ldr             x0, [fp, #0x18]
    // 0xb1f594: LoadField: r1 = r0->field_17
    //     0xb1f594: ldur            w1, [x0, #0x17]
    // 0xb1f598: DecompressPointer r1
    //     0xb1f598: add             x1, x1, HEAP, lsl #32
    // 0xb1f59c: stur            x1, [fp, #-0x28]
    // 0xb1f5a0: cmp             w1, NULL
    // 0xb1f5a4: b.eq            #0xb1f744
    // 0xb1f5a8: ldur            x2, [fp, #-0x20]
    // 0xb1f5ac: ldur            d0, [fp, #-0x60]
    // 0xb1f5b0: d1 = 24.000000
    //     0xb1f5b0: fmov            d1, #24.00000000
    // 0xb1f5b4: fmul            d2, d1, d0
    // 0xb1f5b8: stur            d2, [fp, #-0x68]
    // 0xb1f5bc: r0 = EdgeInsets()
    //     0xb1f5bc: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xb1f5c0: ldur            d0, [fp, #-0x68]
    // 0xb1f5c4: stur            x0, [fp, #-0x30]
    // 0xb1f5c8: StoreField: r0->field_7 = d0
    //     0xb1f5c8: stur            d0, [x0, #7]
    // 0xb1f5cc: StoreField: r0->field_f = d0
    //     0xb1f5cc: stur            d0, [x0, #0xf]
    // 0xb1f5d0: StoreField: r0->field_17 = d0
    //     0xb1f5d0: stur            d0, [x0, #0x17]
    // 0xb1f5d4: d0 = 0.000000
    //     0xb1f5d4: eor             v0.16b, v0.16b, v0.16b
    // 0xb1f5d8: StoreField: r0->field_1f = d0
    //     0xb1f5d8: stur            d0, [x0, #0x1f]
    // 0xb1f5dc: ldur            x2, [fp, #-0x20]
    // 0xb1f5e0: r1 = LoadClassIdInstr(r2)
    //     0xb1f5e0: ldur            x1, [x2, #-1]
    //     0xb1f5e4: ubfx            x1, x1, #0xc, #0x14
    // 0xb1f5e8: lsl             x1, x1, #1
    // 0xb1f5ec: r17 = 5620
    //     0xb1f5ec: mov             x17, #0x15f4
    // 0xb1f5f0: cmp             w1, w17
    // 0xb1f5f4: b.gt            #0xb1f61c
    // 0xb1f5f8: r17 = 5618
    //     0xb1f5f8: mov             x17, #0x15f2
    // 0xb1f5fc: cmp             w1, w17
    // 0xb1f600: b.lt            #0xb1f61c
    // 0xb1f604: LoadField: r1 = r2->field_1f
    //     0xb1f604: ldur            w1, [x2, #0x1f]
    // 0xb1f608: DecompressPointer r1
    //     0xb1f608: add             x1, x1, HEAP, lsl #32
    // 0xb1f60c: mov             x16, x2
    // 0xb1f610: mov             x2, x1
    // 0xb1f614: mov             x1, x16
    // 0xb1f618: b               #0xb1f674
    // 0xb1f61c: r17 = 5622
    //     0xb1f61c: mov             x17, #0x15f6
    // 0xb1f620: cmp             w1, w17
    // 0xb1f624: b.ne            #0xb1f660
    // 0xb1f628: mov             x1, x2
    // 0xb1f62c: LoadField: r0 = r1->field_37
    //     0xb1f62c: ldur            w0, [x1, #0x37]
    // 0xb1f630: DecompressPointer r0
    //     0xb1f630: add             x0, x0, HEAP, lsl #32
    // 0xb1f634: r16 = Sentinel
    //     0xb1f634: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb1f638: cmp             w0, w16
    // 0xb1f63c: b.ne            #0xb1f64c
    // 0xb1f640: r2 = _textTheme
    //     0xb1f640: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3c0] Field <_DialogDefaultsM3@724506021._textTheme@724506021>: late final (offset: 0x38)
    //     0xb1f644: ldr             x2, [x2, #0x3c0]
    // 0xb1f648: r0 = InitLateFinalInstanceField()
    //     0xb1f648: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb1f64c: LoadField: r1 = r0->field_1b
    //     0xb1f64c: ldur            w1, [x0, #0x1b]
    // 0xb1f650: DecompressPointer r1
    //     0xb1f650: add             x1, x1, HEAP, lsl #32
    // 0xb1f654: mov             x2, x1
    // 0xb1f658: ldur            x1, [fp, #-0x20]
    // 0xb1f65c: b               #0xb1f674
    // 0xb1f660: mov             x1, x2
    // 0xb1f664: LoadField: r0 = r1->field_33
    //     0xb1f664: ldur            w0, [x1, #0x33]
    // 0xb1f668: DecompressPointer r0
    //     0xb1f668: add             x0, x0, HEAP, lsl #32
    // 0xb1f66c: LoadField: r2 = r0->field_1f
    //     0xb1f66c: ldur            w2, [x0, #0x1f]
    // 0xb1f670: DecompressPointer r2
    //     0xb1f670: add             x2, x2, HEAP, lsl #32
    // 0xb1f674: ldur            x0, [fp, #-8]
    // 0xb1f678: stur            x2, [fp, #-0x38]
    // 0xb1f67c: cmp             w2, NULL
    // 0xb1f680: b.eq            #0xb1fdd8
    // 0xb1f684: cmp             w0, NULL
    // 0xb1f688: b.ne            #0xb1f6a8
    // 0xb1f68c: ldur            x3, [fp, #-0x18]
    // 0xb1f690: r16 = Instance_TargetPlatform
    //     0xb1f690: ldr             x16, [PP, #0x43b0]  ; [pp+0x43b0] Obj!TargetPlatform@b65d51
    // 0xb1f694: cmp             w3, w16
    // 0xb1f698: r16 = true
    //     0xb1f698: add             x16, NULL, #0x20  ; true
    // 0xb1f69c: r17 = false
    //     0xb1f69c: add             x17, NULL, #0x30  ; false
    // 0xb1f6a0: csel            x4, x16, x17, ne
    // 0xb1f6a4: b               #0xb1f6ac
    // 0xb1f6a8: r4 = false
    //     0xb1f6a8: add             x4, NULL, #0x30  ; false
    // 0xb1f6ac: ldur            x3, [fp, #-0x30]
    // 0xb1f6b0: stur            x4, [fp, #-0x18]
    // 0xb1f6b4: r0 = Semantics()
    //     0xb1f6b4: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0xb1f6b8: stur            x0, [fp, #-0x40]
    // 0xb1f6bc: ldur            x16, [fp, #-0x18]
    // 0xb1f6c0: stp             x16, x0, [SP, #-0x10]!
    // 0xb1f6c4: r16 = true
    //     0xb1f6c4: add             x16, NULL, #0x20  ; true
    // 0xb1f6c8: ldur            lr, [fp, #-0x28]
    // 0xb1f6cc: stp             lr, x16, [SP, #-0x10]!
    // 0xb1f6d0: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, container, 0x2, namesRoute, 0x1, null]
    //     0xb1f6d0: add             x4, PP, #0x28, lsl #12  ; [pp+0x28c30] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "container", 0x2, "namesRoute", 0x1, Null]
    //     0xb1f6d4: ldr             x4, [x4, #0xc30]
    // 0xb1f6d8: r0 = Semantics()
    //     0xb1f6d8: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xb1f6dc: add             SP, SP, #0x20
    // 0xb1f6e0: r0 = DefaultTextStyle()
    //     0xb1f6e0: bl              #0x83fd24  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xb1f6e4: mov             x1, x0
    // 0xb1f6e8: ldur            x0, [fp, #-0x38]
    // 0xb1f6ec: stur            x1, [fp, #-0x18]
    // 0xb1f6f0: StoreField: r1->field_f = r0
    //     0xb1f6f0: stur            w0, [x1, #0xf]
    // 0xb1f6f4: r0 = Instance_TextAlign
    //     0xb1f6f4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0xb1f6f8: ldr             x0, [x0, #0xfe8]
    // 0xb1f6fc: StoreField: r1->field_13 = r0
    //     0xb1f6fc: stur            w0, [x1, #0x13]
    // 0xb1f700: r0 = true
    //     0xb1f700: add             x0, NULL, #0x20  ; true
    // 0xb1f704: StoreField: r1->field_17 = r0
    //     0xb1f704: stur            w0, [x1, #0x17]
    // 0xb1f708: r2 = Instance_TextOverflow
    //     0xb1f708: add             x2, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xb1f70c: ldr             x2, [x2, #0x118]
    // 0xb1f710: StoreField: r1->field_1b = r2
    //     0xb1f710: stur            w2, [x1, #0x1b]
    // 0xb1f714: r3 = Instance_TextWidthBasis
    //     0xb1f714: add             x3, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xb1f718: ldr             x3, [x3, #0x148]
    // 0xb1f71c: StoreField: r1->field_23 = r3
    //     0xb1f71c: stur            w3, [x1, #0x23]
    // 0xb1f720: ldur            x4, [fp, #-0x40]
    // 0xb1f724: StoreField: r1->field_b = r4
    //     0xb1f724: stur            w4, [x1, #0xb]
    // 0xb1f728: r0 = Padding()
    //     0xb1f728: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb1f72c: mov             x1, x0
    // 0xb1f730: ldur            x0, [fp, #-0x30]
    // 0xb1f734: StoreField: r1->field_f = r0
    //     0xb1f734: stur            w0, [x1, #0xf]
    // 0xb1f738: ldur            x0, [fp, #-0x18]
    // 0xb1f73c: StoreField: r1->field_b = r0
    //     0xb1f73c: stur            w0, [x1, #0xb]
    // 0xb1f740: b               #0xb1f748
    // 0xb1f744: r1 = Null
    //     0xb1f744: mov             x1, NULL
    // 0xb1f748: ldur            x0, [fp, #-0x10]
    // 0xb1f74c: stur            x1, [fp, #-0x18]
    // 0xb1f750: tbnz            w0, #4, #0xb1f75c
    // 0xb1f754: d2 = 16.000000
    //     0xb1f754: fmov            d2, #16.00000000
    // 0xb1f758: b               #0xb1f760
    // 0xb1f75c: d2 = 20.000000
    //     0xb1f75c: fmov            d2, #20.00000000
    // 0xb1f760: ldur            d0, [fp, #-0x60]
    // 0xb1f764: ldur            x2, [fp, #-0x28]
    // 0xb1f768: d1 = 24.000000
    //     0xb1f768: fmov            d1, #24.00000000
    // 0xb1f76c: fmul            d3, d1, d0
    // 0xb1f770: stur            d3, [fp, #-0x68]
    // 0xb1f774: cmp             w2, NULL
    // 0xb1f778: b.ne            #0xb1f788
    // 0xb1f77c: fmul            d4, d2, d0
    // 0xb1f780: mov             v0.16b, v4.16b
    // 0xb1f784: b               #0xb1f78c
    // 0xb1f788: mov             v0.16b, v2.16b
    // 0xb1f78c: ldur            x3, [fp, #-0x20]
    // 0xb1f790: stur            d0, [fp, #-0x60]
    // 0xb1f794: r0 = EdgeInsets()
    //     0xb1f794: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xb1f798: ldur            d0, [fp, #-0x68]
    // 0xb1f79c: stur            x0, [fp, #-0x38]
    // 0xb1f7a0: StoreField: r0->field_7 = d0
    //     0xb1f7a0: stur            d0, [x0, #7]
    // 0xb1f7a4: ldur            d1, [fp, #-0x60]
    // 0xb1f7a8: StoreField: r0->field_f = d1
    //     0xb1f7a8: stur            d1, [x0, #0xf]
    // 0xb1f7ac: StoreField: r0->field_17 = d0
    //     0xb1f7ac: stur            d0, [x0, #0x17]
    // 0xb1f7b0: d0 = 24.000000
    //     0xb1f7b0: fmov            d0, #24.00000000
    // 0xb1f7b4: StoreField: r0->field_1f = d0
    //     0xb1f7b4: stur            d0, [x0, #0x1f]
    // 0xb1f7b8: ldur            x2, [fp, #-0x20]
    // 0xb1f7bc: r3 = LoadClassIdInstr(r2)
    //     0xb1f7bc: ldur            x3, [x2, #-1]
    //     0xb1f7c0: ubfx            x3, x3, #0xc, #0x14
    // 0xb1f7c4: lsl             x3, x3, #1
    // 0xb1f7c8: stur            x3, [fp, #-0x30]
    // 0xb1f7cc: r17 = 5620
    //     0xb1f7cc: mov             x17, #0x15f4
    // 0xb1f7d0: cmp             w3, w17
    // 0xb1f7d4: b.gt            #0xb1f7fc
    // 0xb1f7d8: r17 = 5618
    //     0xb1f7d8: mov             x17, #0x15f2
    // 0xb1f7dc: cmp             w3, w17
    // 0xb1f7e0: b.lt            #0xb1f7fc
    // 0xb1f7e4: LoadField: r1 = r2->field_23
    //     0xb1f7e4: ldur            w1, [x2, #0x23]
    // 0xb1f7e8: DecompressPointer r1
    //     0xb1f7e8: add             x1, x1, HEAP, lsl #32
    // 0xb1f7ec: mov             x3, x1
    // 0xb1f7f0: mov             x1, x0
    // 0xb1f7f4: mov             x0, x2
    // 0xb1f7f8: b               #0xb1f860
    // 0xb1f7fc: r17 = 5622
    //     0xb1f7fc: mov             x17, #0x15f6
    // 0xb1f800: cmp             w3, w17
    // 0xb1f804: b.ne            #0xb1f844
    // 0xb1f808: mov             x1, x2
    // 0xb1f80c: LoadField: r0 = r1->field_37
    //     0xb1f80c: ldur            w0, [x1, #0x37]
    // 0xb1f810: DecompressPointer r0
    //     0xb1f810: add             x0, x0, HEAP, lsl #32
    // 0xb1f814: r16 = Sentinel
    //     0xb1f814: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb1f818: cmp             w0, w16
    // 0xb1f81c: b.ne            #0xb1f82c
    // 0xb1f820: r2 = _textTheme
    //     0xb1f820: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3c0] Field <_DialogDefaultsM3@724506021._textTheme@724506021>: late final (offset: 0x38)
    //     0xb1f824: ldr             x2, [x2, #0x3c0]
    // 0xb1f828: r0 = InitLateFinalInstanceField()
    //     0xb1f828: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb1f82c: LoadField: r1 = r0->field_2f
    //     0xb1f82c: ldur            w1, [x0, #0x2f]
    // 0xb1f830: DecompressPointer r1
    //     0xb1f830: add             x1, x1, HEAP, lsl #32
    // 0xb1f834: mov             x3, x1
    // 0xb1f838: ldur            x0, [fp, #-0x20]
    // 0xb1f83c: ldur            x1, [fp, #-0x38]
    // 0xb1f840: b               #0xb1f860
    // 0xb1f844: mov             x0, x2
    // 0xb1f848: LoadField: r1 = r0->field_33
    //     0xb1f848: ldur            w1, [x0, #0x33]
    // 0xb1f84c: DecompressPointer r1
    //     0xb1f84c: add             x1, x1, HEAP, lsl #32
    // 0xb1f850: LoadField: r2 = r1->field_23
    //     0xb1f850: ldur            w2, [x1, #0x23]
    // 0xb1f854: DecompressPointer r2
    //     0xb1f854: add             x2, x2, HEAP, lsl #32
    // 0xb1f858: mov             x3, x2
    // 0xb1f85c: ldur            x1, [fp, #-0x38]
    // 0xb1f860: ldr             x2, [fp, #0x18]
    // 0xb1f864: stur            x3, [fp, #-0x48]
    // 0xb1f868: cmp             w3, NULL
    // 0xb1f86c: b.eq            #0xb1fddc
    // 0xb1f870: LoadField: r4 = r2->field_23
    //     0xb1f870: ldur            w4, [x2, #0x23]
    // 0xb1f874: DecompressPointer r4
    //     0xb1f874: add             x4, x4, HEAP, lsl #32
    // 0xb1f878: stur            x4, [fp, #-0x40]
    // 0xb1f87c: r0 = Semantics()
    //     0xb1f87c: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0xb1f880: stur            x0, [fp, #-0x50]
    // 0xb1f884: r16 = true
    //     0xb1f884: add             x16, NULL, #0x20  ; true
    // 0xb1f888: stp             x16, x0, [SP, #-0x10]!
    // 0xb1f88c: ldur            x16, [fp, #-0x40]
    // 0xb1f890: SaveReg r16
    //     0xb1f890: str             x16, [SP, #-8]!
    // 0xb1f894: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, container, 0x1, null]
    //     0xb1f894: add             x4, PP, #0x28, lsl #12  ; [pp+0x28c38] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0xb1f898: ldr             x4, [x4, #0xc38]
    // 0xb1f89c: r0 = Semantics()
    //     0xb1f89c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xb1f8a0: add             SP, SP, #0x18
    // 0xb1f8a4: r0 = DefaultTextStyle()
    //     0xb1f8a4: bl              #0x83fd24  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xb1f8a8: mov             x1, x0
    // 0xb1f8ac: ldur            x0, [fp, #-0x48]
    // 0xb1f8b0: stur            x1, [fp, #-0x40]
    // 0xb1f8b4: StoreField: r1->field_f = r0
    //     0xb1f8b4: stur            w0, [x1, #0xf]
    // 0xb1f8b8: r0 = true
    //     0xb1f8b8: add             x0, NULL, #0x20  ; true
    // 0xb1f8bc: StoreField: r1->field_17 = r0
    //     0xb1f8bc: stur            w0, [x1, #0x17]
    // 0xb1f8c0: r0 = Instance_TextOverflow
    //     0xb1f8c0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xb1f8c4: ldr             x0, [x0, #0x118]
    // 0xb1f8c8: StoreField: r1->field_1b = r0
    //     0xb1f8c8: stur            w0, [x1, #0x1b]
    // 0xb1f8cc: r0 = Instance_TextWidthBasis
    //     0xb1f8cc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xb1f8d0: ldr             x0, [x0, #0x148]
    // 0xb1f8d4: StoreField: r1->field_23 = r0
    //     0xb1f8d4: stur            w0, [x1, #0x23]
    // 0xb1f8d8: ldur            x0, [fp, #-0x50]
    // 0xb1f8dc: StoreField: r1->field_b = r0
    //     0xb1f8dc: stur            w0, [x1, #0xb]
    // 0xb1f8e0: r0 = Padding()
    //     0xb1f8e0: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb1f8e4: mov             x1, x0
    // 0xb1f8e8: ldur            x0, [fp, #-0x38]
    // 0xb1f8ec: stur            x1, [fp, #-0x48]
    // 0xb1f8f0: StoreField: r1->field_f = r0
    //     0xb1f8f0: stur            w0, [x1, #0xf]
    // 0xb1f8f4: ldur            x0, [fp, #-0x40]
    // 0xb1f8f8: StoreField: r1->field_b = r0
    //     0xb1f8f8: stur            w0, [x1, #0xb]
    // 0xb1f8fc: ldr             x0, [fp, #0x18]
    // 0xb1f900: LoadField: r2 = r0->field_2f
    //     0xb1f900: ldur            w2, [x0, #0x2f]
    // 0xb1f904: DecompressPointer r2
    //     0xb1f904: add             x2, x2, HEAP, lsl #32
    // 0xb1f908: stur            x2, [fp, #-0x38]
    // 0xb1f90c: cmp             w2, NULL
    // 0xb1f910: b.eq            #0xb1fa84
    // 0xb1f914: ldur            x3, [fp, #-0x10]
    // 0xb1f918: tbnz            w3, #4, #0xb1f970
    // 0xb1f91c: ldur            x3, [fp, #-0x30]
    // 0xb1f920: r17 = 5620
    //     0xb1f920: mov             x17, #0x15f4
    // 0xb1f924: cmp             w3, w17
    // 0xb1f928: b.gt            #0xb1f948
    // 0xb1f92c: r17 = 5618
    //     0xb1f92c: mov             x17, #0x15f2
    // 0xb1f930: cmp             w3, w17
    // 0xb1f934: b.lt            #0xb1f948
    // 0xb1f938: ldur            x4, [fp, #-0x20]
    // 0xb1f93c: LoadField: r3 = r4->field_27
    //     0xb1f93c: ldur            w3, [x4, #0x27]
    // 0xb1f940: DecompressPointer r3
    //     0xb1f940: add             x3, x3, HEAP, lsl #32
    // 0xb1f944: b               #0xb1f968
    // 0xb1f948: r17 = 5622
    //     0xb1f948: mov             x17, #0x15f6
    // 0xb1f94c: cmp             w3, w17
    // 0xb1f950: b.ne            #0xb1f960
    // 0xb1f954: r3 = Instance_EdgeInsets
    //     0xb1f954: add             x3, PP, #0xe, lsl #12  ; [pp+0xe3c8] Obj!EdgeInsets@b370a1
    //     0xb1f958: ldr             x3, [x3, #0x3c8]
    // 0xb1f95c: b               #0xb1f968
    // 0xb1f960: r3 = Instance_EdgeInsets
    //     0xb1f960: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xb1f964: ldr             x3, [x3, #0xbd8]
    // 0xb1f968: mov             x1, x3
    // 0xb1f96c: b               #0xb1f9f0
    // 0xb1f970: ldur            x4, [fp, #-0x20]
    // 0xb1f974: ldur            x3, [fp, #-0x30]
    // 0xb1f978: r17 = 5620
    //     0xb1f978: mov             x17, #0x15f4
    // 0xb1f97c: cmp             w3, w17
    // 0xb1f980: b.gt            #0xb1f99c
    // 0xb1f984: r17 = 5618
    //     0xb1f984: mov             x17, #0x15f2
    // 0xb1f988: cmp             w3, w17
    // 0xb1f98c: b.lt            #0xb1f99c
    // 0xb1f990: LoadField: r3 = r4->field_27
    //     0xb1f990: ldur            w3, [x4, #0x27]
    // 0xb1f994: DecompressPointer r3
    //     0xb1f994: add             x3, x3, HEAP, lsl #32
    // 0xb1f998: b               #0xb1f9bc
    // 0xb1f99c: r17 = 5622
    //     0xb1f99c: mov             x17, #0x15f6
    // 0xb1f9a0: cmp             w3, w17
    // 0xb1f9a4: b.ne            #0xb1f9b4
    // 0xb1f9a8: r3 = Instance_EdgeInsets
    //     0xb1f9a8: add             x3, PP, #0xe, lsl #12  ; [pp+0xe3c8] Obj!EdgeInsets@b370a1
    //     0xb1f9ac: ldr             x3, [x3, #0x3c8]
    // 0xb1f9b0: b               #0xb1f9bc
    // 0xb1f9b4: r3 = Instance_EdgeInsets
    //     0xb1f9b4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xb1f9b8: ldr             x3, [x3, #0xbd8]
    // 0xb1f9bc: stur            x3, [fp, #-0x10]
    // 0xb1f9c0: r0 = EdgeInsets()
    //     0xb1f9c0: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xb1f9c4: d0 = 8.000000
    //     0xb1f9c4: fmov            d0, #8.00000000
    // 0xb1f9c8: StoreField: r0->field_7 = d0
    //     0xb1f9c8: stur            d0, [x0, #7]
    // 0xb1f9cc: StoreField: r0->field_f = d0
    //     0xb1f9cc: stur            d0, [x0, #0xf]
    // 0xb1f9d0: StoreField: r0->field_17 = d0
    //     0xb1f9d0: stur            d0, [x0, #0x17]
    // 0xb1f9d4: StoreField: r0->field_1f = d0
    //     0xb1f9d4: stur            d0, [x0, #0x1f]
    // 0xb1f9d8: ldur            x16, [fp, #-0x10]
    // 0xb1f9dc: stp             x0, x16, [SP, #-0x10]!
    // 0xb1f9e0: r0 = +()
    //     0xb1f9e0: bl              #0x518b08  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xb1f9e4: add             SP, SP, #0x10
    // 0xb1f9e8: mov             x1, x0
    // 0xb1f9ec: ldr             x0, [fp, #0x18]
    // 0xb1f9f0: stur            x1, [fp, #-0x20]
    // 0xb1f9f4: LoadField: r2 = r0->field_37
    //     0xb1f9f4: ldur            w2, [x0, #0x37]
    // 0xb1f9f8: DecompressPointer r2
    //     0xb1f9f8: add             x2, x2, HEAP, lsl #32
    // 0xb1f9fc: cmp             w2, NULL
    // 0xb1fa00: b.ne            #0xb1fa10
    // 0xb1fa04: r3 = Instance_MainAxisAlignment
    //     0xb1fa04: add             x3, PP, #0x26, lsl #12  ; [pp+0x26970] Obj!MainAxisAlignment@b64af1
    //     0xb1fa08: ldr             x3, [x3, #0x970]
    // 0xb1fa0c: b               #0xb1fa14
    // 0xb1fa10: mov             x3, x2
    // 0xb1fa14: ldur            x2, [fp, #-0x38]
    // 0xb1fa18: stur            x3, [fp, #-0x10]
    // 0xb1fa1c: r0 = OverflowBar()
    //     0xb1fa1c: bl              #0xb1fe00  ; AllocateOverflowBarStub -> OverflowBar (size=0x34)
    // 0xb1fa20: d0 = 8.000000
    //     0xb1fa20: fmov            d0, #8.00000000
    // 0xb1fa24: stur            x0, [fp, #-0x30]
    // 0xb1fa28: StoreField: r0->field_f = d0
    //     0xb1fa28: stur            d0, [x0, #0xf]
    // 0xb1fa2c: ldur            x1, [fp, #-0x10]
    // 0xb1fa30: StoreField: r0->field_17 = r1
    //     0xb1fa30: stur            w1, [x0, #0x17]
    // 0xb1fa34: d0 = 0.000000
    //     0xb1fa34: eor             v0.16b, v0.16b, v0.16b
    // 0xb1fa38: StoreField: r0->field_1b = d0
    //     0xb1fa38: stur            d0, [x0, #0x1b]
    // 0xb1fa3c: r1 = Instance_OverflowBarAlignment
    //     0xb1fa3c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c40] Obj!OverflowBarAlignment@b63771
    //     0xb1fa40: ldr             x1, [x1, #0xc40]
    // 0xb1fa44: StoreField: r0->field_23 = r1
    //     0xb1fa44: stur            w1, [x0, #0x23]
    // 0xb1fa48: r1 = Instance_VerticalDirection
    //     0xb1fa48: add             x1, PP, #0xe, lsl #12  ; [pp+0xef18] Obj!VerticalDirection@b64fb1
    //     0xb1fa4c: ldr             x1, [x1, #0xf18]
    // 0xb1fa50: StoreField: r0->field_27 = r1
    //     0xb1fa50: stur            w1, [x0, #0x27]
    // 0xb1fa54: r1 = Instance_Clip
    //     0xb1fa54: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb1fa58: ldr             x1, [x1, #0xb38]
    // 0xb1fa5c: StoreField: r0->field_2f = r1
    //     0xb1fa5c: stur            w1, [x0, #0x2f]
    // 0xb1fa60: ldur            x2, [fp, #-0x38]
    // 0xb1fa64: StoreField: r0->field_b = r2
    //     0xb1fa64: stur            w2, [x0, #0xb]
    // 0xb1fa68: r0 = Padding()
    //     0xb1fa68: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb1fa6c: mov             x1, x0
    // 0xb1fa70: ldur            x0, [fp, #-0x20]
    // 0xb1fa74: StoreField: r1->field_f = r0
    //     0xb1fa74: stur            w0, [x1, #0xf]
    // 0xb1fa78: ldur            x0, [fp, #-0x30]
    // 0xb1fa7c: StoreField: r1->field_b = r0
    //     0xb1fa7c: stur            w0, [x1, #0xb]
    // 0xb1fa80: b               #0xb1fa88
    // 0xb1fa84: r1 = Null
    //     0xb1fa84: mov             x1, NULL
    // 0xb1fa88: ldur            x0, [fp, #-0x28]
    // 0xb1fa8c: stur            x1, [fp, #-0x10]
    // 0xb1fa90: r16 = <Widget>
    //     0xb1fa90: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb1fa94: ldr             x16, [x16, #0xea8]
    // 0xb1fa98: stp             xzr, x16, [SP, #-0x10]!
    // 0xb1fa9c: r0 = _GrowableList()
    //     0xb1fa9c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xb1faa0: add             SP, SP, #0x10
    // 0xb1faa4: mov             x1, x0
    // 0xb1faa8: ldur            x0, [fp, #-0x28]
    // 0xb1faac: stur            x1, [fp, #-0x30]
    // 0xb1fab0: cmp             w0, NULL
    // 0xb1fab4: b.eq            #0xb1fb50
    // 0xb1fab8: ldur            x0, [fp, #-0x18]
    // 0xb1fabc: cmp             w0, NULL
    // 0xb1fac0: b.eq            #0xb1fde0
    // 0xb1fac4: LoadField: r2 = r1->field_b
    //     0xb1fac4: ldur            w2, [x1, #0xb]
    // 0xb1fac8: DecompressPointer r2
    //     0xb1fac8: add             x2, x2, HEAP, lsl #32
    // 0xb1facc: stur            x2, [fp, #-0x20]
    // 0xb1fad0: LoadField: r3 = r1->field_f
    //     0xb1fad0: ldur            w3, [x1, #0xf]
    // 0xb1fad4: DecompressPointer r3
    //     0xb1fad4: add             x3, x3, HEAP, lsl #32
    // 0xb1fad8: LoadField: r4 = r3->field_b
    //     0xb1fad8: ldur            w4, [x3, #0xb]
    // 0xb1fadc: DecompressPointer r4
    //     0xb1fadc: add             x4, x4, HEAP, lsl #32
    // 0xb1fae0: cmp             w2, w4
    // 0xb1fae4: b.ne            #0xb1faf4
    // 0xb1fae8: SaveReg r1
    //     0xb1fae8: str             x1, [SP, #-8]!
    // 0xb1faec: r0 = _growToNextCapacity()
    //     0xb1faec: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb1faf0: add             SP, SP, #8
    // 0xb1faf4: ldur            x2, [fp, #-0x30]
    // 0xb1faf8: ldur            x0, [fp, #-0x20]
    // 0xb1fafc: r3 = LoadInt32Instr(r0)
    //     0xb1fafc: sbfx            x3, x0, #1, #0x1f
    // 0xb1fb00: add             x0, x3, #1
    // 0xb1fb04: lsl             x1, x0, #1
    // 0xb1fb08: StoreField: r2->field_b = r1
    //     0xb1fb08: stur            w1, [x2, #0xb]
    // 0xb1fb0c: mov             x1, x3
    // 0xb1fb10: cmp             x1, x0
    // 0xb1fb14: b.hs            #0xb1fde4
    // 0xb1fb18: LoadField: r1 = r2->field_f
    //     0xb1fb18: ldur            w1, [x2, #0xf]
    // 0xb1fb1c: DecompressPointer r1
    //     0xb1fb1c: add             x1, x1, HEAP, lsl #32
    // 0xb1fb20: ldur            x0, [fp, #-0x18]
    // 0xb1fb24: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb1fb24: add             x25, x1, x3, lsl #2
    //     0xb1fb28: add             x25, x25, #0xf
    //     0xb1fb2c: str             w0, [x25]
    //     0xb1fb30: tbz             w0, #0, #0xb1fb4c
    //     0xb1fb34: ldurb           w16, [x1, #-1]
    //     0xb1fb38: ldurb           w17, [x0, #-1]
    //     0xb1fb3c: and             x16, x17, x16, lsr #2
    //     0xb1fb40: tst             x16, HEAP, lsr #32
    //     0xb1fb44: b.eq            #0xb1fb4c
    //     0xb1fb48: bl              #0xd67e5c
    // 0xb1fb4c: b               #0xb1fb54
    // 0xb1fb50: mov             x2, x1
    // 0xb1fb54: ldur            x0, [fp, #-0x48]
    // 0xb1fb58: r1 = <FlexParentData<RenderBox>>
    //     0xb1fb58: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f2f8] TypeArguments: <FlexParentData<RenderBox>>
    //     0xb1fb5c: ldr             x1, [x1, #0x2f8]
    // 0xb1fb60: r0 = Flexible()
    //     0xb1fb60: bl              #0x825240  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xb1fb64: mov             x1, x0
    // 0xb1fb68: r0 = 1
    //     0xb1fb68: mov             x0, #1
    // 0xb1fb6c: stur            x1, [fp, #-0x20]
    // 0xb1fb70: StoreField: r1->field_13 = r0
    //     0xb1fb70: stur            x0, [x1, #0x13]
    // 0xb1fb74: r0 = Instance_FlexFit
    //     0xb1fb74: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c48] Obj!FlexFit@b64bb1
    //     0xb1fb78: ldr             x0, [x0, #0xc48]
    // 0xb1fb7c: StoreField: r1->field_1b = r0
    //     0xb1fb7c: stur            w0, [x1, #0x1b]
    // 0xb1fb80: ldur            x0, [fp, #-0x48]
    // 0xb1fb84: StoreField: r1->field_b = r0
    //     0xb1fb84: stur            w0, [x1, #0xb]
    // 0xb1fb88: ldur            x0, [fp, #-0x30]
    // 0xb1fb8c: LoadField: r2 = r0->field_b
    //     0xb1fb8c: ldur            w2, [x0, #0xb]
    // 0xb1fb90: DecompressPointer r2
    //     0xb1fb90: add             x2, x2, HEAP, lsl #32
    // 0xb1fb94: stur            x2, [fp, #-0x18]
    // 0xb1fb98: LoadField: r3 = r0->field_f
    //     0xb1fb98: ldur            w3, [x0, #0xf]
    // 0xb1fb9c: DecompressPointer r3
    //     0xb1fb9c: add             x3, x3, HEAP, lsl #32
    // 0xb1fba0: LoadField: r4 = r3->field_b
    //     0xb1fba0: ldur            w4, [x3, #0xb]
    // 0xb1fba4: DecompressPointer r4
    //     0xb1fba4: add             x4, x4, HEAP, lsl #32
    // 0xb1fba8: cmp             w2, w4
    // 0xb1fbac: b.ne            #0xb1fbbc
    // 0xb1fbb0: SaveReg r0
    //     0xb1fbb0: str             x0, [SP, #-8]!
    // 0xb1fbb4: r0 = _growToNextCapacity()
    //     0xb1fbb4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb1fbb8: add             SP, SP, #8
    // 0xb1fbbc: ldur            x3, [fp, #-0x38]
    // 0xb1fbc0: ldur            x2, [fp, #-0x30]
    // 0xb1fbc4: ldur            x0, [fp, #-0x18]
    // 0xb1fbc8: r4 = LoadInt32Instr(r0)
    //     0xb1fbc8: sbfx            x4, x0, #1, #0x1f
    // 0xb1fbcc: add             x5, x4, #1
    // 0xb1fbd0: stur            x5, [fp, #-0x58]
    // 0xb1fbd4: lsl             x6, x5, #1
    // 0xb1fbd8: StoreField: r2->field_b = r6
    //     0xb1fbd8: stur            w6, [x2, #0xb]
    // 0xb1fbdc: mov             x0, x5
    // 0xb1fbe0: mov             x1, x4
    // 0xb1fbe4: cmp             x1, x0
    // 0xb1fbe8: b.hs            #0xb1fde8
    // 0xb1fbec: LoadField: r7 = r2->field_f
    //     0xb1fbec: ldur            w7, [x2, #0xf]
    // 0xb1fbf0: DecompressPointer r7
    //     0xb1fbf0: add             x7, x7, HEAP, lsl #32
    // 0xb1fbf4: mov             x1, x7
    // 0xb1fbf8: ldur            x0, [fp, #-0x20]
    // 0xb1fbfc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb1fbfc: add             x25, x1, x4, lsl #2
    //     0xb1fc00: add             x25, x25, #0xf
    //     0xb1fc04: str             w0, [x25]
    //     0xb1fc08: tbz             w0, #0, #0xb1fc24
    //     0xb1fc0c: ldurb           w16, [x1, #-1]
    //     0xb1fc10: ldurb           w17, [x0, #-1]
    //     0xb1fc14: and             x16, x17, x16, lsr #2
    //     0xb1fc18: tst             x16, HEAP, lsr #32
    //     0xb1fc1c: b.eq            #0xb1fc24
    //     0xb1fc20: bl              #0xd67e5c
    // 0xb1fc24: cmp             w3, NULL
    // 0xb1fc28: b.eq            #0xb1fca8
    // 0xb1fc2c: ldur            x0, [fp, #-0x10]
    // 0xb1fc30: cmp             w0, NULL
    // 0xb1fc34: b.eq            #0xb1fdec
    // 0xb1fc38: LoadField: r1 = r7->field_b
    //     0xb1fc38: ldur            w1, [x7, #0xb]
    // 0xb1fc3c: DecompressPointer r1
    //     0xb1fc3c: add             x1, x1, HEAP, lsl #32
    // 0xb1fc40: cmp             w6, w1
    // 0xb1fc44: b.ne            #0xb1fc54
    // 0xb1fc48: SaveReg r2
    //     0xb1fc48: str             x2, [SP, #-8]!
    // 0xb1fc4c: r0 = _growToNextCapacity()
    //     0xb1fc4c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb1fc50: add             SP, SP, #8
    // 0xb1fc54: ldur            x2, [fp, #-0x30]
    // 0xb1fc58: ldur            x3, [fp, #-0x58]
    // 0xb1fc5c: add             x0, x3, #1
    // 0xb1fc60: lsl             x1, x0, #1
    // 0xb1fc64: StoreField: r2->field_b = r1
    //     0xb1fc64: stur            w1, [x2, #0xb]
    // 0xb1fc68: mov             x1, x3
    // 0xb1fc6c: cmp             x1, x0
    // 0xb1fc70: b.hs            #0xb1fdf0
    // 0xb1fc74: LoadField: r1 = r2->field_f
    //     0xb1fc74: ldur            w1, [x2, #0xf]
    // 0xb1fc78: DecompressPointer r1
    //     0xb1fc78: add             x1, x1, HEAP, lsl #32
    // 0xb1fc7c: ldur            x0, [fp, #-0x10]
    // 0xb1fc80: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb1fc80: add             x25, x1, x3, lsl #2
    //     0xb1fc84: add             x25, x25, #0xf
    //     0xb1fc88: str             w0, [x25]
    //     0xb1fc8c: tbz             w0, #0, #0xb1fca8
    //     0xb1fc90: ldurb           w16, [x1, #-1]
    //     0xb1fc94: ldurb           w17, [x0, #-1]
    //     0xb1fc98: and             x16, x17, x16, lsr #2
    //     0xb1fc9c: tst             x16, HEAP, lsr #32
    //     0xb1fca0: b.eq            #0xb1fca8
    //     0xb1fca4: bl              #0xd67e5c
    // 0xb1fca8: ldur            x0, [fp, #-8]
    // 0xb1fcac: r0 = Column()
    //     0xb1fcac: bl              #0x825234  ; AllocateColumnStub -> Column (size=0x30)
    // 0xb1fcb0: stur            x0, [fp, #-0x10]
    // 0xb1fcb4: ldur            x16, [fp, #-0x30]
    // 0xb1fcb8: stp             x16, x0, [SP, #-0x10]!
    // 0xb1fcbc: r16 = Instance_MainAxisSize
    //     0xb1fcbc: add             x16, PP, #0xe, lsl #12  ; [pp+0xeeb0] Obj!MainAxisSize@b64b71
    //     0xb1fcc0: ldr             x16, [x16, #0xeb0]
    // 0xb1fcc4: r30 = Instance_CrossAxisAlignment
    //     0xb1fcc4: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d2d0] Obj!CrossAxisAlignment@b64a11
    //     0xb1fcc8: ldr             lr, [lr, #0x2d0]
    // 0xb1fccc: stp             lr, x16, [SP, #-0x10]!
    // 0xb1fcd0: r4 = const [0, 0x4, 0x4, 0x2, crossAxisAlignment, 0x3, mainAxisSize, 0x2, null]
    //     0xb1fcd0: add             x4, PP, #0x28, lsl #12  ; [pp+0x28c50] List(9) [0, 0x4, 0x4, 0x2, "crossAxisAlignment", 0x3, "mainAxisSize", 0x2, Null]
    //     0xb1fcd4: ldr             x4, [x4, #0xc50]
    // 0xb1fcd8: r0 = Column()
    //     0xb1fcd8: bl              #0x8250c8  ; [package:flutter/src/widgets/basic.dart] Column::Column
    // 0xb1fcdc: add             SP, SP, #0x20
    // 0xb1fce0: r0 = IntrinsicWidth()
    //     0xb1fce0: bl              #0x90aa78  ; AllocateIntrinsicWidthStub -> IntrinsicWidth (size=0x18)
    // 0xb1fce4: mov             x1, x0
    // 0xb1fce8: ldur            x0, [fp, #-0x10]
    // 0xb1fcec: stur            x1, [fp, #-0x18]
    // 0xb1fcf0: StoreField: r1->field_b = r0
    //     0xb1fcf0: stur            w0, [x1, #0xb]
    // 0xb1fcf4: ldur            x0, [fp, #-8]
    // 0xb1fcf8: cmp             w0, NULL
    // 0xb1fcfc: b.eq            #0xb1fd40
    // 0xb1fd00: r0 = Semantics()
    //     0xb1fd00: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0xb1fd04: stur            x0, [fp, #-0x10]
    // 0xb1fd08: r16 = true
    //     0xb1fd08: add             x16, NULL, #0x20  ; true
    // 0xb1fd0c: stp             x16, x0, [SP, #-0x10]!
    // 0xb1fd10: r16 = true
    //     0xb1fd10: add             x16, NULL, #0x20  ; true
    // 0xb1fd14: r30 = true
    //     0xb1fd14: add             lr, NULL, #0x20  ; true
    // 0xb1fd18: stp             lr, x16, [SP, #-0x10]!
    // 0xb1fd1c: ldur            x16, [fp, #-8]
    // 0xb1fd20: ldur            lr, [fp, #-0x18]
    // 0xb1fd24: stp             lr, x16, [SP, #-0x10]!
    // 0xb1fd28: r4 = const [0, 0x6, 0x6, 0x1, child, 0x5, explicitChildNodes, 0x2, label, 0x4, namesRoute, 0x3, scopesRoute, 0x1, null]
    //     0xb1fd28: add             x4, PP, #0x28, lsl #12  ; [pp+0x28c58] List(15) [0, 0x6, 0x6, 0x1, "child", 0x5, "explicitChildNodes", 0x2, "label", 0x4, "namesRoute", 0x3, "scopesRoute", 0x1, Null]
    //     0xb1fd2c: ldr             x4, [x4, #0xc58]
    // 0xb1fd30: r0 = Semantics()
    //     0xb1fd30: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xb1fd34: add             SP, SP, #0x30
    // 0xb1fd38: ldur            x1, [fp, #-0x10]
    // 0xb1fd3c: b               #0xb1fd44
    // 0xb1fd40: ldur            x1, [fp, #-0x18]
    // 0xb1fd44: ldr             x0, [fp, #0x18]
    // 0xb1fd48: stur            x1, [fp, #-0x18]
    // 0xb1fd4c: LoadField: r2 = r0->field_57
    //     0xb1fd4c: ldur            w2, [x0, #0x57]
    // 0xb1fd50: DecompressPointer r2
    //     0xb1fd50: add             x2, x2, HEAP, lsl #32
    // 0xb1fd54: stur            x2, [fp, #-0x10]
    // 0xb1fd58: LoadField: r3 = r0->field_67
    //     0xb1fd58: ldur            w3, [x0, #0x67]
    // 0xb1fd5c: DecompressPointer r3
    //     0xb1fd5c: add             x3, x3, HEAP, lsl #32
    // 0xb1fd60: stur            x3, [fp, #-8]
    // 0xb1fd64: r0 = Dialog()
    //     0xb1fd64: bl              #0xb1fdf4  ; AllocateDialogStub -> Dialog (size=0x3c)
    // 0xb1fd68: r1 = Instance_Color
    //     0xb1fd68: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xb1fd6c: ldr             x1, [x1, #0xbe8]
    // 0xb1fd70: StoreField: r0->field_b = r1
    //     0xb1fd70: stur            w1, [x0, #0xb]
    // 0xb1fd74: ldur            x1, [fp, #-0x10]
    // 0xb1fd78: StoreField: r0->field_17 = r1
    //     0xb1fd78: stur            w1, [x0, #0x17]
    // 0xb1fd7c: r1 = Instance_Duration
    //     0xb1fd7c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0xb1fd80: ldr             x1, [x1, #0x9f0]
    // 0xb1fd84: StoreField: r0->field_1b = r1
    //     0xb1fd84: stur            w1, [x0, #0x1b]
    // 0xb1fd88: r1 = Instance__DecelerateCurve
    //     0xb1fd88: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c60] Obj!_DecelerateCurve<double>@b4f2e1
    //     0xb1fd8c: ldr             x1, [x1, #0xc60]
    // 0xb1fd90: StoreField: r0->field_1f = r1
    //     0xb1fd90: stur            w1, [x0, #0x1f]
    // 0xb1fd94: r1 = Instance_EdgeInsets
    //     0xb1fd94: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fdb8] Obj!EdgeInsets@b36171
    //     0xb1fd98: ldr             x1, [x1, #0xdb8]
    // 0xb1fd9c: StoreField: r0->field_23 = r1
    //     0xb1fd9c: stur            w1, [x0, #0x23]
    // 0xb1fda0: r1 = Instance_Clip
    //     0xb1fda0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb1fda4: ldr             x1, [x1, #0xb38]
    // 0xb1fda8: StoreField: r0->field_27 = r1
    //     0xb1fda8: stur            w1, [x0, #0x27]
    // 0xb1fdac: ldur            x1, [fp, #-8]
    // 0xb1fdb0: StoreField: r0->field_2b = r1
    //     0xb1fdb0: stur            w1, [x0, #0x2b]
    // 0xb1fdb4: ldur            x1, [fp, #-0x18]
    // 0xb1fdb8: StoreField: r0->field_33 = r1
    //     0xb1fdb8: stur            w1, [x0, #0x33]
    // 0xb1fdbc: r1 = false
    //     0xb1fdbc: add             x1, NULL, #0x30  ; false
    // 0xb1fdc0: StoreField: r0->field_37 = r1
    //     0xb1fdc0: stur            w1, [x0, #0x37]
    // 0xb1fdc4: LeaveFrame
    //     0xb1fdc4: mov             SP, fp
    //     0xb1fdc8: ldp             fp, lr, [SP], #0x10
    // 0xb1fdcc: ret
    //     0xb1fdcc: ret             
    // 0xb1fdd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1fdd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1fdd4: b               #0xb1f458
    // 0xb1fdd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1fdd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1fddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1fddc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1fde0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1fde0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1fde4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb1fde4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb1fde8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb1fde8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb1fdec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1fdec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1fdf0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb1fdf0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3859, size: 0x3c, field offset: 0xc
//   const constructor, 
class Dialog extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1ee40, size: 0x3e8
    // 0xb1ee40: EnterFrame
    //     0xb1ee40: stp             fp, lr, [SP, #-0x10]!
    //     0xb1ee44: mov             fp, SP
    // 0xb1ee48: AllocStack(0x40)
    //     0xb1ee48: sub             SP, SP, #0x40
    // 0xb1ee4c: CheckStackOverflow
    //     0xb1ee4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1ee50: cmp             SP, x16
    //     0xb1ee54: b.ls            #0xb1f214
    // 0xb1ee58: ldr             x16, [fp, #0x10]
    // 0xb1ee5c: SaveReg r16
    //     0xb1ee5c: str             x16, [SP, #-8]!
    // 0xb1ee60: r0 = of()
    //     0xb1ee60: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1ee64: add             SP, SP, #8
    // 0xb1ee68: stur            x0, [fp, #-8]
    // 0xb1ee6c: ldr             x16, [fp, #0x10]
    // 0xb1ee70: SaveReg r16
    //     0xb1ee70: str             x16, [SP, #-8]!
    // 0xb1ee74: r0 = of()
    //     0xb1ee74: bl              #0xb1f3b0  ; [package:flutter/src/material/dialog_theme.dart] DialogTheme::of
    // 0xb1ee78: add             SP, SP, #8
    // 0xb1ee7c: stur            x0, [fp, #-0x10]
    // 0xb1ee80: ldr             x16, [fp, #0x10]
    // 0xb1ee84: SaveReg r16
    //     0xb1ee84: str             x16, [SP, #-8]!
    // 0xb1ee88: r0 = of()
    //     0xb1ee88: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xb1ee8c: add             SP, SP, #8
    // 0xb1ee90: LoadField: r1 = r0->field_1f
    //     0xb1ee90: ldur            w1, [x0, #0x1f]
    // 0xb1ee94: DecompressPointer r1
    //     0xb1ee94: add             x1, x1, HEAP, lsl #32
    // 0xb1ee98: r16 = Instance_EdgeInsets
    //     0xb1ee98: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fdb8] Obj!EdgeInsets@b36171
    //     0xb1ee9c: ldr             x16, [x16, #0xdb8]
    // 0xb1eea0: stp             x16, x1, [SP, #-0x10]!
    // 0xb1eea4: r0 = +()
    //     0xb1eea4: bl              #0x518b08  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xb1eea8: add             SP, SP, #0x10
    // 0xb1eeac: mov             x1, x0
    // 0xb1eeb0: ldur            x0, [fp, #-8]
    // 0xb1eeb4: stur            x1, [fp, #-0x18]
    // 0xb1eeb8: LoadField: r2 = r0->field_2b
    //     0xb1eeb8: ldur            w2, [x0, #0x2b]
    // 0xb1eebc: DecompressPointer r2
    //     0xb1eebc: add             x2, x2, HEAP, lsl #32
    // 0xb1eec0: tbnz            w2, #4, #0xb1ef0c
    // 0xb1eec4: ldr             x0, [fp, #0x10]
    // 0xb1eec8: r0 = _DialogDefaultsM3()
    //     0xb1eec8: bl              #0xb1f3a4  ; Allocate_DialogDefaultsM3Stub -> _DialogDefaultsM3 (size=0x3c)
    // 0xb1eecc: mov             x1, x0
    // 0xb1eed0: r0 = Sentinel
    //     0xb1eed0: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb1eed4: StoreField: r1->field_33 = r0
    //     0xb1eed4: stur            w0, [x1, #0x33]
    // 0xb1eed8: StoreField: r1->field_37 = r0
    //     0xb1eed8: stur            w0, [x1, #0x37]
    // 0xb1eedc: ldr             x0, [fp, #0x10]
    // 0xb1eee0: StoreField: r1->field_2f = r0
    //     0xb1eee0: stur            w0, [x1, #0x2f]
    // 0xb1eee4: r2 = 6.000000
    //     0xb1eee4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28c20] 6
    //     0xb1eee8: ldr             x2, [x2, #0xc20]
    // 0xb1eeec: StoreField: r1->field_b = r2
    //     0xb1eeec: stur            w2, [x1, #0xb]
    // 0xb1eef0: r2 = Instance_RoundedRectangleBorder
    //     0xb1eef0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe340] Obj!RoundedRectangleBorder@b38411
    //     0xb1eef4: ldr             x2, [x2, #0x340]
    // 0xb1eef8: StoreField: r1->field_17 = r2
    //     0xb1eef8: stur            w2, [x1, #0x17]
    // 0xb1eefc: r2 = Instance_Alignment
    //     0xb1eefc: add             x2, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb1ef00: ldr             x2, [x2, #0xc70]
    // 0xb1ef04: StoreField: r1->field_1b = r2
    //     0xb1ef04: stur            w2, [x1, #0x1b]
    // 0xb1ef08: b               #0xb1ef2c
    // 0xb1ef0c: ldr             x0, [fp, #0x10]
    // 0xb1ef10: r0 = _DialogDefaultsM2()
    //     0xb1ef10: bl              #0xb1f398  ; Allocate_DialogDefaultsM2Stub -> _DialogDefaultsM2 (size=0x3c)
    // 0xb1ef14: stur            x0, [fp, #-8]
    // 0xb1ef18: ldr             x16, [fp, #0x10]
    // 0xb1ef1c: stp             x16, x0, [SP, #-0x10]!
    // 0xb1ef20: r0 = _DialogDefaultsM2()
    //     0xb1ef20: bl              #0xb1f2ac  ; [package:flutter/src/material/dialog.dart] _DialogDefaultsM2::_DialogDefaultsM2
    // 0xb1ef24: add             SP, SP, #0x10
    // 0xb1ef28: ldur            x1, [fp, #-8]
    // 0xb1ef2c: ldur            x0, [fp, #-0x10]
    // 0xb1ef30: stur            x1, [fp, #-0x28]
    // 0xb1ef34: LoadField: r2 = r0->field_1b
    //     0xb1ef34: ldur            w2, [x0, #0x1b]
    // 0xb1ef38: DecompressPointer r2
    //     0xb1ef38: add             x2, x2, HEAP, lsl #32
    // 0xb1ef3c: cmp             w2, NULL
    // 0xb1ef40: b.ne            #0xb1ef54
    // 0xb1ef44: LoadField: r2 = r1->field_1b
    //     0xb1ef44: ldur            w2, [x1, #0x1b]
    // 0xb1ef48: DecompressPointer r2
    //     0xb1ef48: add             x2, x2, HEAP, lsl #32
    // 0xb1ef4c: cmp             w2, NULL
    // 0xb1ef50: b.eq            #0xb1f21c
    // 0xb1ef54: stur            x2, [fp, #-0x20]
    // 0xb1ef58: LoadField: r3 = r0->field_b
    //     0xb1ef58: ldur            w3, [x0, #0xb]
    // 0xb1ef5c: DecompressPointer r3
    //     0xb1ef5c: add             x3, x3, HEAP, lsl #32
    // 0xb1ef60: cmp             w3, NULL
    // 0xb1ef64: b.ne            #0xb1ef80
    // 0xb1ef68: LoadField: r3 = r1->field_b
    //     0xb1ef68: ldur            w3, [x1, #0xb]
    // 0xb1ef6c: DecompressPointer r3
    //     0xb1ef6c: add             x3, x3, HEAP, lsl #32
    // 0xb1ef70: cmp             w3, NULL
    // 0xb1ef74: b.eq            #0xb1f220
    // 0xb1ef78: LoadField: d0 = r3->field_7
    //     0xb1ef78: ldur            d0, [x3, #7]
    // 0xb1ef7c: b               #0xb1ef84
    // 0xb1ef80: LoadField: d0 = r3->field_7
    //     0xb1ef80: ldur            d0, [x3, #7]
    // 0xb1ef84: stur            d0, [fp, #-0x40]
    // 0xb1ef88: r3 = LoadClassIdInstr(r1)
    //     0xb1ef88: ldur            x3, [x1, #-1]
    //     0xb1ef8c: ubfx            x3, x3, #0xc, #0x14
    // 0xb1ef90: lsl             x3, x3, #1
    // 0xb1ef94: stur            x3, [fp, #-8]
    // 0xb1ef98: r17 = 5620
    //     0xb1ef98: mov             x17, #0x15f4
    // 0xb1ef9c: cmp             w3, w17
    // 0xb1efa0: b.gt            #0xb1efc0
    // 0xb1efa4: r17 = 5618
    //     0xb1efa4: mov             x17, #0x15f2
    // 0xb1efa8: cmp             w3, w17
    // 0xb1efac: b.lt            #0xb1efc0
    // 0xb1efb0: LoadField: r4 = r1->field_f
    //     0xb1efb0: ldur            w4, [x1, #0xf]
    // 0xb1efb4: DecompressPointer r4
    //     0xb1efb4: add             x4, x4, HEAP, lsl #32
    // 0xb1efb8: mov             x2, x4
    // 0xb1efbc: b               #0xb1eff8
    // 0xb1efc0: r17 = 5622
    //     0xb1efc0: mov             x17, #0x15f6
    // 0xb1efc4: cmp             w3, w17
    // 0xb1efc8: b.ne            #0xb1efd8
    // 0xb1efcc: r2 = Instance_Color
    //     0xb1efcc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xb1efd0: ldr             x2, [x2, #0xc08]
    // 0xb1efd4: b               #0xb1eff8
    // 0xb1efd8: LoadField: r4 = r1->field_2f
    //     0xb1efd8: ldur            w4, [x1, #0x2f]
    // 0xb1efdc: DecompressPointer r4
    //     0xb1efdc: add             x4, x4, HEAP, lsl #32
    // 0xb1efe0: SaveReg r4
    //     0xb1efe0: str             x4, [SP, #-8]!
    // 0xb1efe4: r0 = of()
    //     0xb1efe4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1efe8: add             SP, SP, #8
    // 0xb1efec: LoadField: r1 = r0->field_7b
    //     0xb1efec: ldur            w1, [x0, #0x7b]
    // 0xb1eff0: DecompressPointer r1
    //     0xb1eff0: add             x1, x1, HEAP, lsl #32
    // 0xb1eff4: mov             x2, x1
    // 0xb1eff8: ldr             x0, [fp, #0x18]
    // 0xb1effc: stur            x2, [fp, #-0x30]
    // 0xb1f000: LoadField: r1 = r0->field_17
    //     0xb1f000: ldur            w1, [x0, #0x17]
    // 0xb1f004: DecompressPointer r1
    //     0xb1f004: add             x1, x1, HEAP, lsl #32
    // 0xb1f008: cmp             w1, NULL
    // 0xb1f00c: b.ne            #0xb1f014
    // 0xb1f010: r1 = Null
    //     0xb1f010: mov             x1, NULL
    // 0xb1f014: cmp             w1, NULL
    // 0xb1f018: b.ne            #0xb1f0ac
    // 0xb1f01c: ldur            x1, [fp, #-8]
    // 0xb1f020: r17 = 5620
    //     0xb1f020: mov             x17, #0x15f4
    // 0xb1f024: cmp             w1, w17
    // 0xb1f028: b.gt            #0xb1f038
    // 0xb1f02c: r17 = 5618
    //     0xb1f02c: mov             x17, #0x15f2
    // 0xb1f030: cmp             w1, w17
    // 0xb1f034: b.ge            #0xb1f098
    // 0xb1f038: r17 = 5622
    //     0xb1f038: mov             x17, #0x15f6
    // 0xb1f03c: cmp             w1, w17
    // 0xb1f040: b.ne            #0xb1f098
    // 0xb1f044: ldur            x1, [fp, #-0x28]
    // 0xb1f048: LoadField: r0 = r1->field_33
    //     0xb1f048: ldur            w0, [x1, #0x33]
    // 0xb1f04c: DecompressPointer r0
    //     0xb1f04c: add             x0, x0, HEAP, lsl #32
    // 0xb1f050: r16 = Sentinel
    //     0xb1f050: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb1f054: cmp             w0, w16
    // 0xb1f058: b.ne            #0xb1f068
    // 0xb1f05c: r2 = _colors
    //     0xb1f05c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3b8] Field <_DialogDefaultsM3@724506021._colors@724506021>: late final (offset: 0x34)
    //     0xb1f060: ldr             x2, [x2, #0x3b8]
    // 0xb1f064: r0 = InitLateFinalInstanceField()
    //     0xb1f064: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb1f068: LoadField: r1 = r0->field_7f
    //     0xb1f068: ldur            w1, [x0, #0x7f]
    // 0xb1f06c: DecompressPointer r1
    //     0xb1f06c: add             x1, x1, HEAP, lsl #32
    // 0xb1f070: cmp             w1, NULL
    // 0xb1f074: b.ne            #0xb1f088
    // 0xb1f078: LoadField: r1 = r0->field_b
    //     0xb1f078: ldur            w1, [x0, #0xb]
    // 0xb1f07c: DecompressPointer r1
    //     0xb1f07c: add             x1, x1, HEAP, lsl #32
    // 0xb1f080: mov             x0, x1
    // 0xb1f084: b               #0xb1f08c
    // 0xb1f088: mov             x0, x1
    // 0xb1f08c: mov             x1, x0
    // 0xb1f090: ldur            x0, [fp, #-0x28]
    // 0xb1f094: b               #0xb1f0a4
    // 0xb1f098: ldur            x0, [fp, #-0x28]
    // 0xb1f09c: LoadField: r1 = r0->field_13
    //     0xb1f09c: ldur            w1, [x0, #0x13]
    // 0xb1f0a0: DecompressPointer r1
    //     0xb1f0a0: add             x1, x1, HEAP, lsl #32
    // 0xb1f0a4: mov             x2, x1
    // 0xb1f0a8: b               #0xb1f0b4
    // 0xb1f0ac: ldur            x0, [fp, #-0x28]
    // 0xb1f0b0: mov             x2, x1
    // 0xb1f0b4: ldr             x1, [fp, #0x18]
    // 0xb1f0b8: stur            x2, [fp, #-0x38]
    // 0xb1f0bc: LoadField: r3 = r1->field_2b
    //     0xb1f0bc: ldur            w3, [x1, #0x2b]
    // 0xb1f0c0: DecompressPointer r3
    //     0xb1f0c0: add             x3, x3, HEAP, lsl #32
    // 0xb1f0c4: cmp             w3, NULL
    // 0xb1f0c8: b.ne            #0xb1f0dc
    // 0xb1f0cc: ldur            x3, [fp, #-0x10]
    // 0xb1f0d0: LoadField: r4 = r3->field_17
    //     0xb1f0d0: ldur            w4, [x3, #0x17]
    // 0xb1f0d4: DecompressPointer r4
    //     0xb1f0d4: add             x4, x4, HEAP, lsl #32
    // 0xb1f0d8: mov             x3, x4
    // 0xb1f0dc: cmp             w3, NULL
    // 0xb1f0e0: b.ne            #0xb1f0fc
    // 0xb1f0e4: LoadField: r3 = r0->field_17
    //     0xb1f0e4: ldur            w3, [x0, #0x17]
    // 0xb1f0e8: DecompressPointer r3
    //     0xb1f0e8: add             x3, x3, HEAP, lsl #32
    // 0xb1f0ec: cmp             w3, NULL
    // 0xb1f0f0: b.eq            #0xb1f224
    // 0xb1f0f4: mov             x5, x3
    // 0xb1f0f8: b               #0xb1f100
    // 0xb1f0fc: mov             x5, x3
    // 0xb1f100: ldur            x4, [fp, #-0x18]
    // 0xb1f104: ldur            x3, [fp, #-0x20]
    // 0xb1f108: ldur            d0, [fp, #-0x40]
    // 0xb1f10c: ldur            x0, [fp, #-0x30]
    // 0xb1f110: stur            x5, [fp, #-0x10]
    // 0xb1f114: LoadField: r6 = r1->field_33
    //     0xb1f114: ldur            w6, [x1, #0x33]
    // 0xb1f118: DecompressPointer r6
    //     0xb1f118: add             x6, x6, HEAP, lsl #32
    // 0xb1f11c: stur            x6, [fp, #-8]
    // 0xb1f120: r0 = Material()
    //     0xb1f120: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0xb1f124: mov             x1, x0
    // 0xb1f128: r0 = Instance_MaterialType
    //     0xb1f128: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2dc10] Obj!MaterialType@b65591
    //     0xb1f12c: ldr             x0, [x0, #0xc10]
    // 0xb1f130: stur            x1, [fp, #-0x28]
    // 0xb1f134: StoreField: r1->field_f = r0
    //     0xb1f134: stur            w0, [x1, #0xf]
    // 0xb1f138: ldur            d0, [fp, #-0x40]
    // 0xb1f13c: StoreField: r1->field_13 = d0
    //     0xb1f13c: stur            d0, [x1, #0x13]
    // 0xb1f140: r0 = Instance_Color
    //     0xb1f140: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xb1f144: ldr             x0, [x0, #0xbe8]
    // 0xb1f148: StoreField: r1->field_1b = r0
    //     0xb1f148: stur            w0, [x1, #0x1b]
    // 0xb1f14c: ldur            x0, [fp, #-0x30]
    // 0xb1f150: StoreField: r1->field_1f = r0
    //     0xb1f150: stur            w0, [x1, #0x1f]
    // 0xb1f154: ldur            x0, [fp, #-0x38]
    // 0xb1f158: StoreField: r1->field_23 = r0
    //     0xb1f158: stur            w0, [x1, #0x23]
    // 0xb1f15c: ldur            x0, [fp, #-0x10]
    // 0xb1f160: StoreField: r1->field_2b = r0
    //     0xb1f160: stur            w0, [x1, #0x2b]
    // 0xb1f164: r0 = true
    //     0xb1f164: add             x0, NULL, #0x20  ; true
    // 0xb1f168: StoreField: r1->field_2f = r0
    //     0xb1f168: stur            w0, [x1, #0x2f]
    // 0xb1f16c: r0 = Instance_Clip
    //     0xb1f16c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb1f170: ldr             x0, [x0, #0xb38]
    // 0xb1f174: StoreField: r1->field_33 = r0
    //     0xb1f174: stur            w0, [x1, #0x33]
    // 0xb1f178: r0 = Instance_Duration
    //     0xb1f178: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb1f17c: ldr             x0, [x0, #0x9e0]
    // 0xb1f180: StoreField: r1->field_37 = r0
    //     0xb1f180: stur            w0, [x1, #0x37]
    // 0xb1f184: ldur            x0, [fp, #-8]
    // 0xb1f188: StoreField: r1->field_b = r0
    //     0xb1f188: stur            w0, [x1, #0xb]
    // 0xb1f18c: r0 = ConstrainedBox()
    //     0xb1f18c: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xb1f190: mov             x1, x0
    // 0xb1f194: r0 = Instance_BoxConstraints
    //     0xb1f194: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e580] Obj!BoxConstraints@b35531
    //     0xb1f198: ldr             x0, [x0, #0x580]
    // 0xb1f19c: stur            x1, [fp, #-8]
    // 0xb1f1a0: StoreField: r1->field_f = r0
    //     0xb1f1a0: stur            w0, [x1, #0xf]
    // 0xb1f1a4: ldur            x0, [fp, #-0x28]
    // 0xb1f1a8: StoreField: r1->field_b = r0
    //     0xb1f1a8: stur            w0, [x1, #0xb]
    // 0xb1f1ac: r0 = Align()
    //     0xb1f1ac: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xb1f1b0: mov             x1, x0
    // 0xb1f1b4: ldur            x0, [fp, #-0x20]
    // 0xb1f1b8: StoreField: r1->field_f = r0
    //     0xb1f1b8: stur            w0, [x1, #0xf]
    // 0xb1f1bc: ldur            x0, [fp, #-8]
    // 0xb1f1c0: StoreField: r1->field_b = r0
    //     0xb1f1c0: stur            w0, [x1, #0xb]
    // 0xb1f1c4: stp             x1, NULL, [SP, #-0x10]!
    // 0xb1f1c8: ldr             x16, [fp, #0x10]
    // 0xb1f1cc: SaveReg r16
    //     0xb1f1cc: str             x16, [SP, #-8]!
    // 0xb1f1d0: r0 = MediaQuery.removeViewInsets()
    //     0xb1f1d0: bl              #0xb1f234  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removeViewInsets
    // 0xb1f1d4: add             SP, SP, #0x18
    // 0xb1f1d8: stur            x0, [fp, #-8]
    // 0xb1f1dc: r0 = AnimatedPadding()
    //     0xb1f1dc: bl              #0xb1f228  ; AllocateAnimatedPaddingStub -> AnimatedPadding (size=0x20)
    // 0xb1f1e0: ldur            x1, [fp, #-0x18]
    // 0xb1f1e4: StoreField: r0->field_17 = r1
    //     0xb1f1e4: stur            w1, [x0, #0x17]
    // 0xb1f1e8: ldur            x1, [fp, #-8]
    // 0xb1f1ec: StoreField: r0->field_1b = r1
    //     0xb1f1ec: stur            w1, [x0, #0x1b]
    // 0xb1f1f0: r1 = Instance__DecelerateCurve
    //     0xb1f1f0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c60] Obj!_DecelerateCurve<double>@b4f2e1
    //     0xb1f1f4: ldr             x1, [x1, #0xc60]
    // 0xb1f1f8: StoreField: r0->field_b = r1
    //     0xb1f1f8: stur            w1, [x0, #0xb]
    // 0xb1f1fc: r1 = Instance_Duration
    //     0xb1f1fc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0xb1f200: ldr             x1, [x1, #0x9f0]
    // 0xb1f204: StoreField: r0->field_f = r1
    //     0xb1f204: stur            w1, [x0, #0xf]
    // 0xb1f208: LeaveFrame
    //     0xb1f208: mov             SP, fp
    //     0xb1f20c: ldp             fp, lr, [SP], #0x10
    // 0xb1f210: ret
    //     0xb1f210: ret             
    // 0xb1f214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1f214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1f218: b               #0xb1ee58
    // 0xb1f21c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1f21c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1f220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1f220: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1f224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1f224: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

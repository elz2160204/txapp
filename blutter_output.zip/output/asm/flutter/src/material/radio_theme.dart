// lib: , url: package:flutter/src/material/radio_theme.dart

// class id: 1049296, size: 0x8
class :: {
}

// class id: 2771, size: 0x20, field offset: 0x8
//   const constructor, 
class RadioThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00e80, size: 0x74
    // 0xb00e80: EnterFrame
    //     0xb00e80: stp             fp, lr, [SP, #-0x10]!
    //     0xb00e84: mov             fp, SP
    // 0xb00e88: CheckStackOverflow
    //     0xb00e88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00e8c: cmp             SP, x16
    //     0xb00e90: b.ls            #0xb00eec
    // 0xb00e94: ldr             x0, [fp, #0x10]
    // 0xb00e98: LoadField: r1 = r0->field_b
    //     0xb00e98: ldur            w1, [x0, #0xb]
    // 0xb00e9c: DecompressPointer r1
    //     0xb00e9c: add             x1, x1, HEAP, lsl #32
    // 0xb00ea0: LoadField: r2 = r0->field_f
    //     0xb00ea0: ldur            w2, [x0, #0xf]
    // 0xb00ea4: DecompressPointer r2
    //     0xb00ea4: add             x2, x2, HEAP, lsl #32
    // 0xb00ea8: LoadField: r3 = r0->field_13
    //     0xb00ea8: ldur            w3, [x0, #0x13]
    // 0xb00eac: DecompressPointer r3
    //     0xb00eac: add             x3, x3, HEAP, lsl #32
    // 0xb00eb0: stp             x1, NULL, [SP, #-0x10]!
    // 0xb00eb4: stp             x3, x2, [SP, #-0x10]!
    // 0xb00eb8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00ebc: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0xb00ebc: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0xb00ec0: r0 = hash()
    //     0xb00ec0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00ec4: add             SP, SP, #0x30
    // 0xb00ec8: mov             x2, x0
    // 0xb00ecc: r0 = BoxInt64Instr(r2)
    //     0xb00ecc: sbfiz           x0, x2, #1, #0x1f
    //     0xb00ed0: cmp             x2, x0, asr #1
    //     0xb00ed4: b.eq            #0xb00ee0
    //     0xb00ed8: bl              #0xd69bb8
    //     0xb00edc: stur            x2, [x0, #7]
    // 0xb00ee0: LeaveFrame
    //     0xb00ee0: mov             SP, fp
    //     0xb00ee4: ldp             fp, lr, [SP], #0x10
    // 0xb00ee8: ret
    //     0xb00ee8: ret             
    // 0xb00eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00eec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00ef0: b               #0xb00e94
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf3194, size: 0x160
    // 0xbf3194: EnterFrame
    //     0xbf3194: stp             fp, lr, [SP, #-0x10]!
    //     0xbf3198: mov             fp, SP
    // 0xbf319c: AllocStack(0x18)
    //     0xbf319c: sub             SP, SP, #0x18
    // 0xbf31a0: CheckStackOverflow
    //     0xbf31a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf31a4: cmp             SP, x16
    //     0xbf31a8: b.ls            #0xbf32cc
    // 0xbf31ac: ldr             x0, [fp, #0x20]
    // 0xbf31b0: LoadField: r1 = r0->field_b
    //     0xbf31b0: ldur            w1, [x0, #0xb]
    // 0xbf31b4: DecompressPointer r1
    //     0xbf31b4: add             x1, x1, HEAP, lsl #32
    // 0xbf31b8: ldr             x2, [fp, #0x18]
    // 0xbf31bc: LoadField: r3 = r2->field_b
    //     0xbf31bc: ldur            w3, [x2, #0xb]
    // 0xbf31c0: DecompressPointer r3
    //     0xbf31c0: add             x3, x3, HEAP, lsl #32
    // 0xbf31c4: r16 = <Color?>
    //     0xbf31c4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf31c8: ldr             x16, [x16, #0xf68]
    // 0xbf31cc: stp             x1, x16, [SP, #-0x10]!
    // 0xbf31d0: SaveReg r3
    //     0xbf31d0: str             x3, [SP, #-8]!
    // 0xbf31d4: ldr             d0, [fp, #0x10]
    // 0xbf31d8: SaveReg d0
    //     0xbf31d8: str             d0, [SP, #-8]!
    // 0xbf31dc: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf31dc: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf31e0: ldr             x16, [x16, #0xb80]
    // 0xbf31e4: SaveReg r16
    //     0xbf31e4: str             x16, [SP, #-8]!
    // 0xbf31e8: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf31e8: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf31ec: r0 = lerp()
    //     0xbf31ec: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf31f0: add             SP, SP, #0x28
    // 0xbf31f4: mov             x1, x0
    // 0xbf31f8: ldr             x0, [fp, #0x20]
    // 0xbf31fc: stur            x1, [fp, #-8]
    // 0xbf3200: LoadField: r2 = r0->field_f
    //     0xbf3200: ldur            w2, [x0, #0xf]
    // 0xbf3204: DecompressPointer r2
    //     0xbf3204: add             x2, x2, HEAP, lsl #32
    // 0xbf3208: ldr             x3, [fp, #0x18]
    // 0xbf320c: LoadField: r4 = r3->field_f
    //     0xbf320c: ldur            w4, [x3, #0xf]
    // 0xbf3210: DecompressPointer r4
    //     0xbf3210: add             x4, x4, HEAP, lsl #32
    // 0xbf3214: r16 = <Color?>
    //     0xbf3214: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf3218: ldr             x16, [x16, #0xf68]
    // 0xbf321c: stp             x2, x16, [SP, #-0x10]!
    // 0xbf3220: SaveReg r4
    //     0xbf3220: str             x4, [SP, #-8]!
    // 0xbf3224: ldr             d0, [fp, #0x10]
    // 0xbf3228: SaveReg d0
    //     0xbf3228: str             d0, [SP, #-8]!
    // 0xbf322c: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf322c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf3230: ldr             x16, [x16, #0xb80]
    // 0xbf3234: SaveReg r16
    //     0xbf3234: str             x16, [SP, #-8]!
    // 0xbf3238: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3238: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf323c: r0 = lerp()
    //     0xbf323c: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3240: add             SP, SP, #0x28
    // 0xbf3244: mov             x1, x0
    // 0xbf3248: ldr             x0, [fp, #0x20]
    // 0xbf324c: stur            x1, [fp, #-0x10]
    // 0xbf3250: LoadField: r2 = r0->field_13
    //     0xbf3250: ldur            w2, [x0, #0x13]
    // 0xbf3254: DecompressPointer r2
    //     0xbf3254: add             x2, x2, HEAP, lsl #32
    // 0xbf3258: ldr             x0, [fp, #0x18]
    // 0xbf325c: LoadField: r3 = r0->field_13
    //     0xbf325c: ldur            w3, [x0, #0x13]
    // 0xbf3260: DecompressPointer r3
    //     0xbf3260: add             x3, x3, HEAP, lsl #32
    // 0xbf3264: ldr             d0, [fp, #0x10]
    // 0xbf3268: r0 = inline_Allocate_Double()
    //     0xbf3268: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbf326c: add             x0, x0, #0x10
    //     0xbf3270: cmp             x4, x0
    //     0xbf3274: b.ls            #0xbf32d4
    //     0xbf3278: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf327c: sub             x0, x0, #0xf
    //     0xbf3280: mov             x4, #0xd108
    //     0xbf3284: movk            x4, #3, lsl #16
    //     0xbf3288: stur            x4, [x0, #-1]
    // 0xbf328c: StoreField: r0->field_7 = d0
    //     0xbf328c: stur            d0, [x0, #7]
    // 0xbf3290: stp             x3, x2, [SP, #-0x10]!
    // 0xbf3294: SaveReg r0
    //     0xbf3294: str             x0, [SP, #-8]!
    // 0xbf3298: r0 = lerpDouble()
    //     0xbf3298: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf329c: add             SP, SP, #0x18
    // 0xbf32a0: stur            x0, [fp, #-0x18]
    // 0xbf32a4: r0 = RadioThemeData()
    //     0xbf32a4: bl              #0xbf32f4  ; AllocateRadioThemeDataStub -> RadioThemeData (size=0x20)
    // 0xbf32a8: ldur            x1, [fp, #-8]
    // 0xbf32ac: StoreField: r0->field_b = r1
    //     0xbf32ac: stur            w1, [x0, #0xb]
    // 0xbf32b0: ldur            x1, [fp, #-0x10]
    // 0xbf32b4: StoreField: r0->field_f = r1
    //     0xbf32b4: stur            w1, [x0, #0xf]
    // 0xbf32b8: ldur            x1, [fp, #-0x18]
    // 0xbf32bc: StoreField: r0->field_13 = r1
    //     0xbf32bc: stur            w1, [x0, #0x13]
    // 0xbf32c0: LeaveFrame
    //     0xbf32c0: mov             SP, fp
    //     0xbf32c4: ldp             fp, lr, [SP], #0x10
    // 0xbf32c8: ret
    //     0xbf32c8: ret             
    // 0xbf32cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf32cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf32d0: b               #0xbf31ac
    // 0xbf32d4: SaveReg d0
    //     0xbf32d4: str             q0, [SP, #-0x10]!
    // 0xbf32d8: stp             x2, x3, [SP, #-0x10]!
    // 0xbf32dc: SaveReg r1
    //     0xbf32dc: str             x1, [SP, #-8]!
    // 0xbf32e0: r0 = AllocateDouble()
    //     0xbf32e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf32e4: RestoreReg r1
    //     0xbf32e4: ldr             x1, [SP], #8
    // 0xbf32e8: ldp             x2, x3, [SP], #0x10
    // 0xbf32ec: RestoreReg d0
    //     0xbf32ec: ldr             q0, [SP], #0x10
    // 0xbf32f0: b               #0xbf328c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8cb28, size: 0x15c
    // 0xc8cb28: EnterFrame
    //     0xc8cb28: stp             fp, lr, [SP, #-0x10]!
    //     0xc8cb2c: mov             fp, SP
    // 0xc8cb30: CheckStackOverflow
    //     0xc8cb30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8cb34: cmp             SP, x16
    //     0xc8cb38: b.ls            #0xc8cc7c
    // 0xc8cb3c: ldr             x1, [fp, #0x10]
    // 0xc8cb40: cmp             w1, NULL
    // 0xc8cb44: b.ne            #0xc8cb58
    // 0xc8cb48: r0 = false
    //     0xc8cb48: add             x0, NULL, #0x30  ; false
    // 0xc8cb4c: LeaveFrame
    //     0xc8cb4c: mov             SP, fp
    //     0xc8cb50: ldp             fp, lr, [SP], #0x10
    // 0xc8cb54: ret
    //     0xc8cb54: ret             
    // 0xc8cb58: ldr             x2, [fp, #0x18]
    // 0xc8cb5c: cmp             w2, w1
    // 0xc8cb60: b.ne            #0xc8cb74
    // 0xc8cb64: r0 = true
    //     0xc8cb64: add             x0, NULL, #0x20  ; true
    // 0xc8cb68: LeaveFrame
    //     0xc8cb68: mov             SP, fp
    //     0xc8cb6c: ldp             fp, lr, [SP], #0x10
    // 0xc8cb70: ret
    //     0xc8cb70: ret             
    // 0xc8cb74: r0 = 59
    //     0xc8cb74: mov             x0, #0x3b
    // 0xc8cb78: branchIfSmi(r1, 0xc8cb84)
    //     0xc8cb78: tbz             w1, #0, #0xc8cb84
    // 0xc8cb7c: r0 = LoadClassIdInstr(r1)
    //     0xc8cb7c: ldur            x0, [x1, #-1]
    //     0xc8cb80: ubfx            x0, x0, #0xc, #0x14
    // 0xc8cb84: SaveReg r1
    //     0xc8cb84: str             x1, [SP, #-8]!
    // 0xc8cb88: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8cb88: mov             x17, #0x57c5
    //     0xc8cb8c: add             lr, x0, x17
    //     0xc8cb90: ldr             lr, [x21, lr, lsl #3]
    //     0xc8cb94: blr             lr
    // 0xc8cb98: add             SP, SP, #8
    // 0xc8cb9c: r1 = LoadClassIdInstr(r0)
    //     0xc8cb9c: ldur            x1, [x0, #-1]
    //     0xc8cba0: ubfx            x1, x1, #0xc, #0x14
    // 0xc8cba4: r16 = RadioThemeData
    //     0xc8cba4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe190] Type: RadioThemeData
    //     0xc8cba8: ldr             x16, [x16, #0x190]
    // 0xc8cbac: stp             x16, x0, [SP, #-0x10]!
    // 0xc8cbb0: mov             x0, x1
    // 0xc8cbb4: mov             lr, x0
    // 0xc8cbb8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8cbbc: blr             lr
    // 0xc8cbc0: add             SP, SP, #0x10
    // 0xc8cbc4: tbz             w0, #4, #0xc8cbd8
    // 0xc8cbc8: r0 = false
    //     0xc8cbc8: add             x0, NULL, #0x30  ; false
    // 0xc8cbcc: LeaveFrame
    //     0xc8cbcc: mov             SP, fp
    //     0xc8cbd0: ldp             fp, lr, [SP], #0x10
    // 0xc8cbd4: ret
    //     0xc8cbd4: ret             
    // 0xc8cbd8: ldr             x0, [fp, #0x10]
    // 0xc8cbdc: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8cbdc: mov             x1, #0x76
    //     0xc8cbe0: tbz             w0, #0, #0xc8cbf0
    //     0xc8cbe4: ldur            x1, [x0, #-1]
    //     0xc8cbe8: ubfx            x1, x1, #0xc, #0x14
    //     0xc8cbec: lsl             x1, x1, #1
    // 0xc8cbf0: r17 = 5542
    //     0xc8cbf0: mov             x17, #0x15a6
    // 0xc8cbf4: cmp             w1, w17
    // 0xc8cbf8: b.ne            #0xc8cc6c
    // 0xc8cbfc: ldr             x1, [fp, #0x18]
    // 0xc8cc00: LoadField: r2 = r0->field_b
    //     0xc8cc00: ldur            w2, [x0, #0xb]
    // 0xc8cc04: DecompressPointer r2
    //     0xc8cc04: add             x2, x2, HEAP, lsl #32
    // 0xc8cc08: LoadField: r3 = r1->field_b
    //     0xc8cc08: ldur            w3, [x1, #0xb]
    // 0xc8cc0c: DecompressPointer r3
    //     0xc8cc0c: add             x3, x3, HEAP, lsl #32
    // 0xc8cc10: cmp             w2, w3
    // 0xc8cc14: b.ne            #0xc8cc6c
    // 0xc8cc18: LoadField: r2 = r0->field_f
    //     0xc8cc18: ldur            w2, [x0, #0xf]
    // 0xc8cc1c: DecompressPointer r2
    //     0xc8cc1c: add             x2, x2, HEAP, lsl #32
    // 0xc8cc20: LoadField: r3 = r1->field_f
    //     0xc8cc20: ldur            w3, [x1, #0xf]
    // 0xc8cc24: DecompressPointer r3
    //     0xc8cc24: add             x3, x3, HEAP, lsl #32
    // 0xc8cc28: cmp             w2, w3
    // 0xc8cc2c: b.ne            #0xc8cc6c
    // 0xc8cc30: LoadField: r2 = r0->field_13
    //     0xc8cc30: ldur            w2, [x0, #0x13]
    // 0xc8cc34: DecompressPointer r2
    //     0xc8cc34: add             x2, x2, HEAP, lsl #32
    // 0xc8cc38: LoadField: r0 = r1->field_13
    //     0xc8cc38: ldur            w0, [x1, #0x13]
    // 0xc8cc3c: DecompressPointer r0
    //     0xc8cc3c: add             x0, x0, HEAP, lsl #32
    // 0xc8cc40: r1 = LoadClassIdInstr(r2)
    //     0xc8cc40: ldur            x1, [x2, #-1]
    //     0xc8cc44: ubfx            x1, x1, #0xc, #0x14
    // 0xc8cc48: stp             x0, x2, [SP, #-0x10]!
    // 0xc8cc4c: mov             x0, x1
    // 0xc8cc50: mov             lr, x0
    // 0xc8cc54: ldr             lr, [x21, lr, lsl #3]
    // 0xc8cc58: blr             lr
    // 0xc8cc5c: add             SP, SP, #0x10
    // 0xc8cc60: tbnz            w0, #4, #0xc8cc6c
    // 0xc8cc64: r0 = true
    //     0xc8cc64: add             x0, NULL, #0x20  ; true
    // 0xc8cc68: b               #0xc8cc70
    // 0xc8cc6c: r0 = false
    //     0xc8cc6c: add             x0, NULL, #0x30  ; false
    // 0xc8cc70: LeaveFrame
    //     0xc8cc70: mov             SP, fp
    //     0xc8cc74: ldp             fp, lr, [SP], #0x10
    // 0xc8cc78: ret
    //     0xc8cc78: ret             
    // 0xc8cc7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8cc7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8cc80: b               #0xc8cb3c
  }
}

// lib: , url: package:flutter/src/material/time_picker_theme.dart

// class id: 1049334, size: 0x8
class :: {
}

// class id: 2716, size: 0x4c, field offset: 0x8
//   const constructor, 
class TimePickerThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb05840, size: 0x74
    // 0xb05840: EnterFrame
    //     0xb05840: stp             fp, lr, [SP, #-0x10]!
    //     0xb05844: mov             fp, SP
    // 0xb05848: CheckStackOverflow
    //     0xb05848: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0584c: cmp             SP, x16
    //     0xb05850: b.ls            #0xb058ac
    // 0xb05854: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05858: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb0585c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05860: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05864: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05868: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb0586c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05870: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05874: SaveReg rNULL
    //     0xb05874: str             NULL, [SP, #-8]!
    // 0xb05878: r4 = const [0, 0x11, 0x11, 0x11, null]
    //     0xb05878: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf00] List(5) [0, 0x11, 0x11, 0x11, Null]
    //     0xb0587c: ldr             x4, [x4, #0xf00]
    // 0xb05880: r0 = hash()
    //     0xb05880: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb05884: add             SP, SP, #0x88
    // 0xb05888: mov             x2, x0
    // 0xb0588c: r0 = BoxInt64Instr(r2)
    //     0xb0588c: sbfiz           x0, x2, #1, #0x1f
    //     0xb05890: cmp             x2, x0, asr #1
    //     0xb05894: b.eq            #0xb058a0
    //     0xb05898: bl              #0xd69bb8
    //     0xb0589c: stur            x2, [x0, #7]
    // 0xb058a0: LeaveFrame
    //     0xb058a0: mov             SP, fp
    //     0xb058a4: ldp             fp, lr, [SP], #0x10
    // 0xb058a8: ret
    //     0xb058a8: ret             
    // 0xb058ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb058ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb058b0: b               #0xb05854
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbef040, size: 0x15c
    // 0xbef040: EnterFrame
    //     0xbef040: stp             fp, lr, [SP, #-0x10]!
    //     0xbef044: mov             fp, SP
    // 0xbef048: AllocStack(0x8)
    //     0xbef048: sub             SP, SP, #8
    // 0xbef04c: CheckStackOverflow
    //     0xbef04c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbef050: cmp             SP, x16
    //     0xbef054: b.ls            #0xbef184
    // 0xbef058: ldr             d0, [fp, #0x10]
    // 0xbef05c: r0 = inline_Allocate_Double()
    //     0xbef05c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbef060: add             x0, x0, #0x10
    //     0xbef064: cmp             x1, x0
    //     0xbef068: b.ls            #0xbef18c
    //     0xbef06c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbef070: sub             x0, x0, #0xf
    //     0xbef074: mov             x1, #0xd108
    //     0xbef078: movk            x1, #3, lsl #16
    //     0xbef07c: stur            x1, [x0, #-1]
    // 0xbef080: StoreField: r0->field_7 = d0
    //     0xbef080: stur            d0, [x0, #7]
    // 0xbef084: stur            x0, [fp, #-8]
    // 0xbef088: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef08c: SaveReg r0
    //     0xbef08c: str             x0, [SP, #-8]!
    // 0xbef090: r0 = lerp()
    //     0xbef090: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef094: add             SP, SP, #0x18
    // 0xbef098: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef09c: ldur            x16, [fp, #-8]
    // 0xbef0a0: SaveReg r16
    //     0xbef0a0: str             x16, [SP, #-8]!
    // 0xbef0a4: r0 = lerp()
    //     0xbef0a4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef0a8: add             SP, SP, #0x18
    // 0xbef0ac: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef0b0: ldur            x16, [fp, #-8]
    // 0xbef0b4: SaveReg r16
    //     0xbef0b4: str             x16, [SP, #-8]!
    // 0xbef0b8: r0 = lerp()
    //     0xbef0b8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef0bc: add             SP, SP, #0x18
    // 0xbef0c0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef0c4: ldur            x16, [fp, #-8]
    // 0xbef0c8: SaveReg r16
    //     0xbef0c8: str             x16, [SP, #-8]!
    // 0xbef0cc: r0 = lerp()
    //     0xbef0cc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef0d0: add             SP, SP, #0x18
    // 0xbef0d4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef0d8: ldur            x16, [fp, #-8]
    // 0xbef0dc: SaveReg r16
    //     0xbef0dc: str             x16, [SP, #-8]!
    // 0xbef0e0: r0 = lerp()
    //     0xbef0e0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef0e4: add             SP, SP, #0x18
    // 0xbef0e8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef0ec: ldur            x16, [fp, #-8]
    // 0xbef0f0: SaveReg r16
    //     0xbef0f0: str             x16, [SP, #-8]!
    // 0xbef0f4: r0 = lerp()
    //     0xbef0f4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef0f8: add             SP, SP, #0x18
    // 0xbef0fc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef100: ldur            x16, [fp, #-8]
    // 0xbef104: SaveReg r16
    //     0xbef104: str             x16, [SP, #-8]!
    // 0xbef108: r0 = lerp()
    //     0xbef108: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef10c: add             SP, SP, #0x18
    // 0xbef110: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef114: ldur            x16, [fp, #-8]
    // 0xbef118: SaveReg r16
    //     0xbef118: str             x16, [SP, #-8]!
    // 0xbef11c: r0 = lerp()
    //     0xbef11c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef120: add             SP, SP, #0x18
    // 0xbef124: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef128: ldur            x16, [fp, #-8]
    // 0xbef12c: SaveReg r16
    //     0xbef12c: str             x16, [SP, #-8]!
    // 0xbef130: r0 = lerp()
    //     0xbef130: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef134: add             SP, SP, #0x18
    // 0xbef138: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef13c: ldur            x16, [fp, #-8]
    // 0xbef140: SaveReg r16
    //     0xbef140: str             x16, [SP, #-8]!
    // 0xbef144: r0 = lerp()
    //     0xbef144: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbef148: add             SP, SP, #0x18
    // 0xbef14c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef150: ldur            x16, [fp, #-8]
    // 0xbef154: SaveReg r16
    //     0xbef154: str             x16, [SP, #-8]!
    // 0xbef158: r0 = lerp()
    //     0xbef158: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbef15c: add             SP, SP, #0x18
    // 0xbef160: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbef164: ldur            x16, [fp, #-8]
    // 0xbef168: SaveReg r16
    //     0xbef168: str             x16, [SP, #-8]!
    // 0xbef16c: r0 = lerp()
    //     0xbef16c: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbef170: add             SP, SP, #0x18
    // 0xbef174: r0 = TimePickerThemeData()
    //     0xbef174: bl              #0xbef19c  ; AllocateTimePickerThemeDataStub -> TimePickerThemeData (size=0x4c)
    // 0xbef178: LeaveFrame
    //     0xbef178: mov             SP, fp
    //     0xbef17c: ldp             fp, lr, [SP], #0x10
    // 0xbef180: ret
    //     0xbef180: ret             
    // 0xbef184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbef184: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbef188: b               #0xbef058
    // 0xbef18c: SaveReg d0
    //     0xbef18c: str             q0, [SP, #-0x10]!
    // 0xbef190: r0 = AllocateDouble()
    //     0xbef190: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbef194: RestoreReg d0
    //     0xbef194: ldr             q0, [SP], #0x10
    // 0xbef198: b               #0xbef080
  }
  _ ==(/* No info */) {
    // ** addr: 0xc929e4, size: 0xf4
    // 0xc929e4: EnterFrame
    //     0xc929e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc929e8: mov             fp, SP
    // 0xc929ec: CheckStackOverflow
    //     0xc929ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc929f0: cmp             SP, x16
    //     0xc929f4: b.ls            #0xc92ad0
    // 0xc929f8: ldr             x1, [fp, #0x10]
    // 0xc929fc: cmp             w1, NULL
    // 0xc92a00: b.ne            #0xc92a14
    // 0xc92a04: r0 = false
    //     0xc92a04: add             x0, NULL, #0x30  ; false
    // 0xc92a08: LeaveFrame
    //     0xc92a08: mov             SP, fp
    //     0xc92a0c: ldp             fp, lr, [SP], #0x10
    // 0xc92a10: ret
    //     0xc92a10: ret             
    // 0xc92a14: ldr             x0, [fp, #0x18]
    // 0xc92a18: cmp             w0, w1
    // 0xc92a1c: b.ne            #0xc92a30
    // 0xc92a20: r0 = true
    //     0xc92a20: add             x0, NULL, #0x20  ; true
    // 0xc92a24: LeaveFrame
    //     0xc92a24: mov             SP, fp
    //     0xc92a28: ldp             fp, lr, [SP], #0x10
    // 0xc92a2c: ret
    //     0xc92a2c: ret             
    // 0xc92a30: r0 = 59
    //     0xc92a30: mov             x0, #0x3b
    // 0xc92a34: branchIfSmi(r1, 0xc92a40)
    //     0xc92a34: tbz             w1, #0, #0xc92a40
    // 0xc92a38: r0 = LoadClassIdInstr(r1)
    //     0xc92a38: ldur            x0, [x1, #-1]
    //     0xc92a3c: ubfx            x0, x0, #0xc, #0x14
    // 0xc92a40: SaveReg r1
    //     0xc92a40: str             x1, [SP, #-8]!
    // 0xc92a44: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc92a44: mov             x17, #0x57c5
    //     0xc92a48: add             lr, x0, x17
    //     0xc92a4c: ldr             lr, [x21, lr, lsl #3]
    //     0xc92a50: blr             lr
    // 0xc92a54: add             SP, SP, #8
    // 0xc92a58: r1 = LoadClassIdInstr(r0)
    //     0xc92a58: ldur            x1, [x0, #-1]
    //     0xc92a5c: ubfx            x1, x1, #0xc, #0x14
    // 0xc92a60: r16 = TimePickerThemeData
    //     0xc92a60: add             x16, PP, #0xd, lsl #12  ; [pp+0xdef8] Type: TimePickerThemeData
    //     0xc92a64: ldr             x16, [x16, #0xef8]
    // 0xc92a68: stp             x16, x0, [SP, #-0x10]!
    // 0xc92a6c: mov             x0, x1
    // 0xc92a70: mov             lr, x0
    // 0xc92a74: ldr             lr, [x21, lr, lsl #3]
    // 0xc92a78: blr             lr
    // 0xc92a7c: add             SP, SP, #0x10
    // 0xc92a80: tbz             w0, #4, #0xc92a94
    // 0xc92a84: r0 = false
    //     0xc92a84: add             x0, NULL, #0x30  ; false
    // 0xc92a88: LeaveFrame
    //     0xc92a88: mov             SP, fp
    //     0xc92a8c: ldp             fp, lr, [SP], #0x10
    // 0xc92a90: ret
    //     0xc92a90: ret             
    // 0xc92a94: ldr             x1, [fp, #0x10]
    // 0xc92a98: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc92a98: mov             x2, #0x76
    //     0xc92a9c: tbz             w1, #0, #0xc92aac
    //     0xc92aa0: ldur            x2, [x1, #-1]
    //     0xc92aa4: ubfx            x2, x2, #0xc, #0x14
    //     0xc92aa8: lsl             x2, x2, #1
    // 0xc92aac: r17 = 5432
    //     0xc92aac: mov             x17, #0x1538
    // 0xc92ab0: cmp             w2, w17
    // 0xc92ab4: b.ne            #0xc92ac0
    // 0xc92ab8: r0 = true
    //     0xc92ab8: add             x0, NULL, #0x20  ; true
    // 0xc92abc: b               #0xc92ac4
    // 0xc92ac0: r0 = false
    //     0xc92ac0: add             x0, NULL, #0x30  ; false
    // 0xc92ac4: LeaveFrame
    //     0xc92ac4: mov             SP, fp
    //     0xc92ac8: ldp             fp, lr, [SP], #0x10
    // 0xc92acc: ret
    //     0xc92acc: ret             
    // 0xc92ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc92ad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc92ad4: b               #0xc929f8
  }
}

// lib: , url: package:flutter/src/material/menu_button_theme.dart

// class id: 1049274, size: 0x8
class :: {
}

// class id: 2784, size: 0xc, field offset: 0x8
//   const constructor, 
class MenuButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0xbf420c, size: 0x68
    // 0xbf420c: EnterFrame
    //     0xbf420c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4210: mov             fp, SP
    // 0xbf4214: AllocStack(0x8)
    //     0xbf4214: sub             SP, SP, #8
    // 0xbf4218: CheckStackOverflow
    //     0xbf4218: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf421c: cmp             SP, x16
    //     0xbf4220: b.ls            #0xbf426c
    // 0xbf4224: ldr             x0, [fp, #0x20]
    // 0xbf4228: LoadField: r1 = r0->field_7
    //     0xbf4228: ldur            w1, [x0, #7]
    // 0xbf422c: DecompressPointer r1
    //     0xbf422c: add             x1, x1, HEAP, lsl #32
    // 0xbf4230: ldr             x0, [fp, #0x18]
    // 0xbf4234: LoadField: r2 = r0->field_7
    //     0xbf4234: ldur            w2, [x0, #7]
    // 0xbf4238: DecompressPointer r2
    //     0xbf4238: add             x2, x2, HEAP, lsl #32
    // 0xbf423c: stp             x2, x1, [SP, #-0x10]!
    // 0xbf4240: ldr             d0, [fp, #0x10]
    // 0xbf4244: SaveReg d0
    //     0xbf4244: str             d0, [SP, #-8]!
    // 0xbf4248: r0 = lerp()
    //     0xbf4248: bl              #0xbef34c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0xbf424c: add             SP, SP, #0x18
    // 0xbf4250: stur            x0, [fp, #-8]
    // 0xbf4254: r0 = MenuButtonThemeData()
    //     0xbf4254: bl              #0xbf4274  ; AllocateMenuButtonThemeDataStub -> MenuButtonThemeData (size=0xc)
    // 0xbf4258: ldur            x1, [fp, #-8]
    // 0xbf425c: StoreField: r0->field_7 = r1
    //     0xbf425c: stur            w1, [x0, #7]
    // 0xbf4260: LeaveFrame
    //     0xbf4260: mov             SP, fp
    //     0xbf4264: ldp             fp, lr, [SP], #0x10
    // 0xbf4268: ret
    //     0xbf4268: ret             
    // 0xbf426c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf426c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf4270: b               #0xbf4224
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8bc40, size: 0x124
    // 0xc8bc40: EnterFrame
    //     0xc8bc40: stp             fp, lr, [SP, #-0x10]!
    //     0xc8bc44: mov             fp, SP
    // 0xc8bc48: CheckStackOverflow
    //     0xc8bc48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8bc4c: cmp             SP, x16
    //     0xc8bc50: b.ls            #0xc8bd5c
    // 0xc8bc54: ldr             x1, [fp, #0x10]
    // 0xc8bc58: cmp             w1, NULL
    // 0xc8bc5c: b.ne            #0xc8bc70
    // 0xc8bc60: r0 = false
    //     0xc8bc60: add             x0, NULL, #0x30  ; false
    // 0xc8bc64: LeaveFrame
    //     0xc8bc64: mov             SP, fp
    //     0xc8bc68: ldp             fp, lr, [SP], #0x10
    // 0xc8bc6c: ret
    //     0xc8bc6c: ret             
    // 0xc8bc70: ldr             x2, [fp, #0x18]
    // 0xc8bc74: cmp             w2, w1
    // 0xc8bc78: b.ne            #0xc8bc8c
    // 0xc8bc7c: r0 = true
    //     0xc8bc7c: add             x0, NULL, #0x20  ; true
    // 0xc8bc80: LeaveFrame
    //     0xc8bc80: mov             SP, fp
    //     0xc8bc84: ldp             fp, lr, [SP], #0x10
    // 0xc8bc88: ret
    //     0xc8bc88: ret             
    // 0xc8bc8c: r0 = 59
    //     0xc8bc8c: mov             x0, #0x3b
    // 0xc8bc90: branchIfSmi(r1, 0xc8bc9c)
    //     0xc8bc90: tbz             w1, #0, #0xc8bc9c
    // 0xc8bc94: r0 = LoadClassIdInstr(r1)
    //     0xc8bc94: ldur            x0, [x1, #-1]
    //     0xc8bc98: ubfx            x0, x0, #0xc, #0x14
    // 0xc8bc9c: SaveReg r1
    //     0xc8bc9c: str             x1, [SP, #-8]!
    // 0xc8bca0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8bca0: mov             x17, #0x57c5
    //     0xc8bca4: add             lr, x0, x17
    //     0xc8bca8: ldr             lr, [x21, lr, lsl #3]
    //     0xc8bcac: blr             lr
    // 0xc8bcb0: add             SP, SP, #8
    // 0xc8bcb4: r1 = LoadClassIdInstr(r0)
    //     0xc8bcb4: ldur            x1, [x0, #-1]
    //     0xc8bcb8: ubfx            x1, x1, #0xc, #0x14
    // 0xc8bcbc: r16 = MenuButtonThemeData
    //     0xc8bcbc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1e8] Type: MenuButtonThemeData
    //     0xc8bcc0: ldr             x16, [x16, #0x1e8]
    // 0xc8bcc4: stp             x16, x0, [SP, #-0x10]!
    // 0xc8bcc8: mov             x0, x1
    // 0xc8bccc: mov             lr, x0
    // 0xc8bcd0: ldr             lr, [x21, lr, lsl #3]
    // 0xc8bcd4: blr             lr
    // 0xc8bcd8: add             SP, SP, #0x10
    // 0xc8bcdc: tbz             w0, #4, #0xc8bcf0
    // 0xc8bce0: r0 = false
    //     0xc8bce0: add             x0, NULL, #0x30  ; false
    // 0xc8bce4: LeaveFrame
    //     0xc8bce4: mov             SP, fp
    //     0xc8bce8: ldp             fp, lr, [SP], #0x10
    // 0xc8bcec: ret
    //     0xc8bcec: ret             
    // 0xc8bcf0: ldr             x0, [fp, #0x10]
    // 0xc8bcf4: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8bcf4: mov             x1, #0x76
    //     0xc8bcf8: tbz             w0, #0, #0xc8bd08
    //     0xc8bcfc: ldur            x1, [x0, #-1]
    //     0xc8bd00: ubfx            x1, x1, #0xc, #0x14
    //     0xc8bd04: lsl             x1, x1, #1
    // 0xc8bd08: r17 = 5568
    //     0xc8bd08: mov             x17, #0x15c0
    // 0xc8bd0c: cmp             w1, w17
    // 0xc8bd10: b.ne            #0xc8bd4c
    // 0xc8bd14: ldr             x1, [fp, #0x18]
    // 0xc8bd18: LoadField: r2 = r0->field_7
    //     0xc8bd18: ldur            w2, [x0, #7]
    // 0xc8bd1c: DecompressPointer r2
    //     0xc8bd1c: add             x2, x2, HEAP, lsl #32
    // 0xc8bd20: LoadField: r0 = r1->field_7
    //     0xc8bd20: ldur            w0, [x1, #7]
    // 0xc8bd24: DecompressPointer r0
    //     0xc8bd24: add             x0, x0, HEAP, lsl #32
    // 0xc8bd28: r1 = LoadClassIdInstr(r2)
    //     0xc8bd28: ldur            x1, [x2, #-1]
    //     0xc8bd2c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8bd30: stp             x0, x2, [SP, #-0x10]!
    // 0xc8bd34: mov             x0, x1
    // 0xc8bd38: mov             lr, x0
    // 0xc8bd3c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8bd40: blr             lr
    // 0xc8bd44: add             SP, SP, #0x10
    // 0xc8bd48: b               #0xc8bd50
    // 0xc8bd4c: r0 = false
    //     0xc8bd4c: add             x0, NULL, #0x30  ; false
    // 0xc8bd50: LeaveFrame
    //     0xc8bd50: mov             SP, fp
    //     0xc8bd54: ldp             fp, lr, [SP], #0x10
    // 0xc8bd58: ret
    //     0xc8bd58: ret             
    // 0xc8bd5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8bd5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8bd60: b               #0xc8bc54
  }
}

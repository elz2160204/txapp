// lib: , url: package:flutter/src/material/scaffold.dart

// class id: 1049300, size: 0x8
class :: {
}

// class id: 2062, size: 0x40, field offset: 0x28
//   const constructor, 
class _BodyBoxConstraints extends BoxConstraints {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb0ece0, size: 0x150
    // 0xb0ece0: EnterFrame
    //     0xb0ece0: stp             fp, lr, [SP, #-0x10]!
    //     0xb0ece4: mov             fp, SP
    // 0xb0ece8: CheckStackOverflow
    //     0xb0ece8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb0ecec: cmp             SP, x16
    //     0xb0ecf0: b.ls            #0xb0edc8
    // 0xb0ecf4: ldr             x16, [fp, #0x10]
    // 0xb0ecf8: SaveReg r16
    //     0xb0ecf8: str             x16, [SP, #-8]!
    // 0xb0ecfc: r0 = hashCode()
    //     0xb0ecfc: bl              #0xb0f528  ; [package:flutter/src/rendering/stack.dart] RelativeRect::hashCode
    // 0xb0ed00: add             SP, SP, #8
    // 0xb0ed04: mov             x1, x0
    // 0xb0ed08: ldr             x0, [fp, #0x10]
    // 0xb0ed0c: LoadField: d0 = r0->field_37
    //     0xb0ed0c: ldur            d0, [x0, #0x37]
    // 0xb0ed10: LoadField: d1 = r0->field_27
    //     0xb0ed10: ldur            d1, [x0, #0x27]
    // 0xb0ed14: LoadField: d2 = r0->field_2f
    //     0xb0ed14: ldur            d2, [x0, #0x2f]
    // 0xb0ed18: r0 = inline_Allocate_Double()
    //     0xb0ed18: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb0ed1c: add             x0, x0, #0x10
    //     0xb0ed20: cmp             x2, x0
    //     0xb0ed24: b.ls            #0xb0edd0
    //     0xb0ed28: str             x0, [THR, #0x60]  ; THR::top
    //     0xb0ed2c: sub             x0, x0, #0xf
    //     0xb0ed30: mov             x2, #0xd108
    //     0xb0ed34: movk            x2, #3, lsl #16
    //     0xb0ed38: stur            x2, [x0, #-1]
    // 0xb0ed3c: StoreField: r0->field_7 = d0
    //     0xb0ed3c: stur            d0, [x0, #7]
    // 0xb0ed40: r2 = inline_Allocate_Double()
    //     0xb0ed40: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb0ed44: add             x2, x2, #0x10
    //     0xb0ed48: cmp             x3, x2
    //     0xb0ed4c: b.ls            #0xb0edf0
    //     0xb0ed50: str             x2, [THR, #0x60]  ; THR::top
    //     0xb0ed54: sub             x2, x2, #0xf
    //     0xb0ed58: mov             x3, #0xd108
    //     0xb0ed5c: movk            x3, #3, lsl #16
    //     0xb0ed60: stur            x3, [x2, #-1]
    // 0xb0ed64: StoreField: r2->field_7 = d1
    //     0xb0ed64: stur            d1, [x2, #7]
    // 0xb0ed68: r3 = inline_Allocate_Double()
    //     0xb0ed68: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb0ed6c: add             x3, x3, #0x10
    //     0xb0ed70: cmp             x4, x3
    //     0xb0ed74: b.ls            #0xb0ee0c
    //     0xb0ed78: str             x3, [THR, #0x60]  ; THR::top
    //     0xb0ed7c: sub             x3, x3, #0xf
    //     0xb0ed80: mov             x4, #0xd108
    //     0xb0ed84: movk            x4, #3, lsl #16
    //     0xb0ed88: stur            x4, [x3, #-1]
    // 0xb0ed8c: StoreField: r3->field_7 = d2
    //     0xb0ed8c: stur            d2, [x3, #7]
    // 0xb0ed90: stp             x0, x1, [SP, #-0x10]!
    // 0xb0ed94: stp             x3, x2, [SP, #-0x10]!
    // 0xb0ed98: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xb0ed98: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xb0ed9c: r0 = hash()
    //     0xb0ed9c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0eda0: add             SP, SP, #0x20
    // 0xb0eda4: mov             x2, x0
    // 0xb0eda8: r0 = BoxInt64Instr(r2)
    //     0xb0eda8: sbfiz           x0, x2, #1, #0x1f
    //     0xb0edac: cmp             x2, x0, asr #1
    //     0xb0edb0: b.eq            #0xb0edbc
    //     0xb0edb4: bl              #0xd69bb8
    //     0xb0edb8: stur            x2, [x0, #7]
    // 0xb0edbc: LeaveFrame
    //     0xb0edbc: mov             SP, fp
    //     0xb0edc0: ldp             fp, lr, [SP], #0x10
    // 0xb0edc4: ret
    //     0xb0edc4: ret             
    // 0xb0edc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0edc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0edcc: b               #0xb0ecf4
    // 0xb0edd0: stp             q1, q2, [SP, #-0x20]!
    // 0xb0edd4: SaveReg d0
    //     0xb0edd4: str             q0, [SP, #-0x10]!
    // 0xb0edd8: SaveReg r1
    //     0xb0edd8: str             x1, [SP, #-8]!
    // 0xb0eddc: r0 = AllocateDouble()
    //     0xb0eddc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0ede0: RestoreReg r1
    //     0xb0ede0: ldr             x1, [SP], #8
    // 0xb0ede4: RestoreReg d0
    //     0xb0ede4: ldr             q0, [SP], #0x10
    // 0xb0ede8: ldp             q1, q2, [SP], #0x20
    // 0xb0edec: b               #0xb0ed3c
    // 0xb0edf0: stp             q1, q2, [SP, #-0x20]!
    // 0xb0edf4: stp             x0, x1, [SP, #-0x10]!
    // 0xb0edf8: r0 = AllocateDouble()
    //     0xb0edf8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0edfc: mov             x2, x0
    // 0xb0ee00: ldp             x0, x1, [SP], #0x10
    // 0xb0ee04: ldp             q1, q2, [SP], #0x20
    // 0xb0ee08: b               #0xb0ed64
    // 0xb0ee0c: SaveReg d2
    //     0xb0ee0c: str             q2, [SP, #-0x10]!
    // 0xb0ee10: stp             x1, x2, [SP, #-0x10]!
    // 0xb0ee14: SaveReg r0
    //     0xb0ee14: str             x0, [SP, #-8]!
    // 0xb0ee18: r0 = AllocateDouble()
    //     0xb0ee18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb0ee1c: mov             x3, x0
    // 0xb0ee20: RestoreReg r0
    //     0xb0ee20: ldr             x0, [SP], #8
    // 0xb0ee24: ldp             x1, x2, [SP], #0x10
    // 0xb0ee28: RestoreReg d2
    //     0xb0ee28: ldr             q2, [SP], #0x10
    // 0xb0ee2c: b               #0xb0ed8c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc9e7c8, size: 0xe4
    // 0xc9e7c8: EnterFrame
    //     0xc9e7c8: stp             fp, lr, [SP, #-0x10]!
    //     0xc9e7cc: mov             fp, SP
    // 0xc9e7d0: CheckStackOverflow
    //     0xc9e7d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9e7d4: cmp             SP, x16
    //     0xc9e7d8: b.ls            #0xc9e8a4
    // 0xc9e7dc: ldr             x0, [fp, #0x10]
    // 0xc9e7e0: cmp             w0, NULL
    // 0xc9e7e4: b.ne            #0xc9e7f8
    // 0xc9e7e8: r0 = false
    //     0xc9e7e8: add             x0, NULL, #0x30  ; false
    // 0xc9e7ec: LeaveFrame
    //     0xc9e7ec: mov             SP, fp
    //     0xc9e7f0: ldp             fp, lr, [SP], #0x10
    // 0xc9e7f4: ret
    //     0xc9e7f4: ret             
    // 0xc9e7f8: ldr             x16, [fp, #0x18]
    // 0xc9e7fc: stp             x0, x16, [SP, #-0x10]!
    // 0xc9e800: r0 = ==()
    //     0xc9e800: bl              #0xc9e8ac  ; [package:flutter/src/rendering/box.dart] BoxConstraints::==
    // 0xc9e804: add             SP, SP, #0x10
    // 0xc9e808: tbz             w0, #4, #0xc9e81c
    // 0xc9e80c: r0 = false
    //     0xc9e80c: add             x0, NULL, #0x30  ; false
    // 0xc9e810: LeaveFrame
    //     0xc9e810: mov             SP, fp
    //     0xc9e814: ldp             fp, lr, [SP], #0x10
    // 0xc9e818: ret
    //     0xc9e818: ret             
    // 0xc9e81c: ldr             x1, [fp, #0x10]
    // 0xc9e820: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc9e820: mov             x2, #0x76
    //     0xc9e824: tbz             w1, #0, #0xc9e834
    //     0xc9e828: ldur            x2, [x1, #-1]
    //     0xc9e82c: ubfx            x2, x2, #0xc, #0x14
    //     0xc9e830: lsl             x2, x2, #1
    // 0xc9e834: r17 = 4124
    //     0xc9e834: mov             x17, #0x101c
    // 0xc9e838: cmp             w2, w17
    // 0xc9e83c: b.ne            #0xc9e894
    // 0xc9e840: ldr             x2, [fp, #0x18]
    // 0xc9e844: LoadField: d0 = r1->field_37
    //     0xc9e844: ldur            d0, [x1, #0x37]
    // 0xc9e848: LoadField: d1 = r2->field_37
    //     0xc9e848: ldur            d1, [x2, #0x37]
    // 0xc9e84c: fcmp            d0, d1
    // 0xc9e850: b.vs            #0xc9e894
    // 0xc9e854: b.ne            #0xc9e894
    // 0xc9e858: LoadField: d0 = r1->field_27
    //     0xc9e858: ldur            d0, [x1, #0x27]
    // 0xc9e85c: LoadField: d1 = r2->field_27
    //     0xc9e85c: ldur            d1, [x2, #0x27]
    // 0xc9e860: fcmp            d0, d1
    // 0xc9e864: b.vs            #0xc9e894
    // 0xc9e868: b.ne            #0xc9e894
    // 0xc9e86c: LoadField: d0 = r1->field_2f
    //     0xc9e86c: ldur            d0, [x1, #0x2f]
    // 0xc9e870: LoadField: d1 = r2->field_2f
    //     0xc9e870: ldur            d1, [x2, #0x2f]
    // 0xc9e874: fcmp            d0, d1
    // 0xc9e878: b.vs            #0xc9e880
    // 0xc9e87c: b.eq            #0xc9e888
    // 0xc9e880: r1 = false
    //     0xc9e880: add             x1, NULL, #0x30  ; false
    // 0xc9e884: b               #0xc9e88c
    // 0xc9e888: r1 = true
    //     0xc9e888: add             x1, NULL, #0x20  ; true
    // 0xc9e88c: mov             x0, x1
    // 0xc9e890: b               #0xc9e898
    // 0xc9e894: r0 = false
    //     0xc9e894: add             x0, NULL, #0x30  ; false
    // 0xc9e898: LeaveFrame
    //     0xc9e898: mov             SP, fp
    //     0xc9e89c: ldp             fp, lr, [SP], #0x10
    // 0xc9e8a0: ret
    //     0xc9e8a0: ret             
    // 0xc9e8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc9e8a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc9e8a8: b               #0xc9e7dc
  }
}

// class id: 2148, size: 0x18, field offset: 0x8
//   const constructor, 
abstract class ScaffoldFeatureController<X0 bound Widget, X1> extends Object {
}

// class id: 2149, size: 0x1c, field offset: 0x18
//   const constructor, 
class PersistentBottomSheetController<_StandardBottomSheet> extends ScaffoldFeatureController<_StandardBottomSheet, C1X0> {
}

// class id: 2153, size: 0x48, field offset: 0x10
class _ScaffoldLayout extends MultiChildLayoutDelegate {

  _ _ScaffoldLayout(/* No info */) {
    // ** addr: 0x866514, size: 0x11c
    // 0x866514: EnterFrame
    //     0x866514: stp             fp, lr, [SP, #-0x10]!
    //     0x866518: mov             fp, SP
    // 0x86651c: r3 = Instance__EndFloatFabLocation
    //     0x86651c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21e48] Obj!_EndFloatFabLocation@b38591
    //     0x866520: ldr             x3, [x3, #0xe48]
    // 0x866524: r2 = Instance__ScalingFabMotionAnimator
    //     0x866524: add             x2, PP, #0x21, lsl #12  ; [pp+0x21dd0] Obj!_ScalingFabMotionAnimator@b38581
    //     0x866528: ldr             x2, [x2, #0xdd0]
    // 0x86652c: r1 = false
    //     0x86652c: add             x1, NULL, #0x30  ; false
    // 0x866530: ldr             x0, [fp, #0x30]
    // 0x866534: ldr             x4, [fp, #0x60]
    // 0x866538: StoreField: r4->field_17 = r0
    //     0x866538: stur            w0, [x4, #0x17]
    //     0x86653c: ldurb           w16, [x4, #-1]
    //     0x866540: ldurb           w17, [x0, #-1]
    //     0x866544: and             x16, x17, x16, lsr #2
    //     0x866548: tst             x16, HEAP, lsr #32
    //     0x86654c: b.eq            #0x866554
    //     0x866550: bl              #0xd682cc
    // 0x866554: ldr             x0, [fp, #0x28]
    // 0x866558: StoreField: r4->field_1b = r0
    //     0x866558: stur            w0, [x4, #0x1b]
    //     0x86655c: ldurb           w16, [x4, #-1]
    //     0x866560: ldurb           w17, [x0, #-1]
    //     0x866564: and             x16, x17, x16, lsr #2
    //     0x866568: tst             x16, HEAP, lsr #32
    //     0x86656c: b.eq            #0x866574
    //     0x866570: bl              #0xd682cc
    // 0x866574: ldr             x0, [fp, #0x10]
    // 0x866578: StoreField: r4->field_1f = r0
    //     0x866578: stur            w0, [x4, #0x1f]
    //     0x86657c: ldurb           w16, [x4, #-1]
    //     0x866580: ldurb           w17, [x0, #-1]
    //     0x866584: and             x16, x17, x16, lsr #2
    //     0x866588: tst             x16, HEAP, lsr #32
    //     0x86658c: b.eq            #0x866594
    //     0x866590: bl              #0xd682cc
    // 0x866594: ldr             x0, [fp, #0x40]
    // 0x866598: StoreField: r4->field_23 = r0
    //     0x866598: stur            w0, [x4, #0x23]
    //     0x86659c: ldurb           w16, [x4, #-1]
    //     0x8665a0: ldurb           w17, [x0, #-1]
    //     0x8665a4: and             x16, x17, x16, lsr #2
    //     0x8665a8: tst             x16, HEAP, lsr #32
    //     0x8665ac: b.eq            #0x8665b4
    //     0x8665b0: bl              #0xd682cc
    // 0x8665b4: ldr             x0, [fp, #0x20]
    // 0x8665b8: StoreField: r4->field_27 = r0
    //     0x8665b8: stur            w0, [x4, #0x27]
    //     0x8665bc: ldurb           w16, [x4, #-1]
    //     0x8665c0: ldurb           w17, [x0, #-1]
    //     0x8665c4: and             x16, x17, x16, lsr #2
    //     0x8665c8: tst             x16, HEAP, lsr #32
    //     0x8665cc: b.eq            #0x8665d4
    //     0x8665d0: bl              #0xd682cc
    // 0x8665d4: StoreField: r4->field_2b = r3
    //     0x8665d4: stur            w3, [x4, #0x2b]
    // 0x8665d8: ldr             d0, [fp, #0x48]
    // 0x8665dc: StoreField: r4->field_2f = d0
    //     0x8665dc: stur            d0, [x4, #0x2f]
    // 0x8665e0: StoreField: r4->field_37 = r2
    //     0x8665e0: stur            w2, [x4, #0x37]
    // 0x8665e4: ldr             x2, [fp, #0x38]
    // 0x8665e8: StoreField: r4->field_3b = r2
    //     0x8665e8: stur            w2, [x4, #0x3b]
    // 0x8665ec: ldr             x0, [fp, #0x18]
    // 0x8665f0: StoreField: r4->field_3f = r0
    //     0x8665f0: stur            w0, [x4, #0x3f]
    //     0x8665f4: ldurb           w16, [x4, #-1]
    //     0x8665f8: ldurb           w17, [x0, #-1]
    //     0x8665fc: and             x16, x17, x16, lsr #2
    //     0x866600: tst             x16, HEAP, lsr #32
    //     0x866604: b.eq            #0x86660c
    //     0x866608: bl              #0xd682cc
    // 0x86660c: ldr             x2, [fp, #0x58]
    // 0x866610: StoreField: r4->field_f = r2
    //     0x866610: stur            w2, [x4, #0xf]
    // 0x866614: StoreField: r4->field_13 = r1
    //     0x866614: stur            w1, [x4, #0x13]
    // 0x866618: ldr             x1, [fp, #0x50]
    // 0x86661c: StoreField: r4->field_43 = r1
    //     0x86661c: stur            w1, [x4, #0x43]
    // 0x866620: r0 = Null
    //     0x866620: mov             x0, NULL
    // 0x866624: LeaveFrame
    //     0x866624: mov             SP, fp
    //     0x866628: ldp             fp, lr, [SP], #0x10
    // 0x86662c: ret
    //     0x86662c: ret             
  }
  _ shouldRelayout(/* No info */) {
    // ** addr: 0xcf2f18, size: 0x11c
    // 0xcf2f18: EnterFrame
    //     0xcf2f18: stp             fp, lr, [SP, #-0x10]!
    //     0xcf2f1c: mov             fp, SP
    // 0xcf2f20: CheckStackOverflow
    //     0xcf2f20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf2f24: cmp             SP, x16
    //     0xcf2f28: b.ls            #0xcf302c
    // 0xcf2f2c: ldr             x0, [fp, #0x10]
    // 0xcf2f30: r2 = Null
    //     0xcf2f30: mov             x2, NULL
    // 0xcf2f34: r1 = Null
    //     0xcf2f34: mov             x1, NULL
    // 0xcf2f38: r4 = 59
    //     0xcf2f38: mov             x4, #0x3b
    // 0xcf2f3c: branchIfSmi(r0, 0xcf2f48)
    //     0xcf2f3c: tbz             w0, #0, #0xcf2f48
    // 0xcf2f40: r4 = LoadClassIdInstr(r0)
    //     0xcf2f40: ldur            x4, [x0, #-1]
    //     0xcf2f44: ubfx            x4, x4, #0xc, #0x14
    // 0xcf2f48: cmp             x4, #0x869
    // 0xcf2f4c: b.eq            #0xcf2f64
    // 0xcf2f50: r8 = _ScaffoldLayout
    //     0xcf2f50: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e110] Type: _ScaffoldLayout
    //     0xcf2f54: ldr             x8, [x8, #0x110]
    // 0xcf2f58: r3 = Null
    //     0xcf2f58: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e118] Null
    //     0xcf2f5c: ldr             x3, [x3, #0x118]
    // 0xcf2f60: r0 = DefaultTypeTest()
    //     0xcf2f60: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcf2f64: ldr             x0, [fp, #0x10]
    // 0xcf2f68: LoadField: r1 = r0->field_17
    //     0xcf2f68: ldur            w1, [x0, #0x17]
    // 0xcf2f6c: DecompressPointer r1
    //     0xcf2f6c: add             x1, x1, HEAP, lsl #32
    // 0xcf2f70: ldr             x2, [fp, #0x18]
    // 0xcf2f74: LoadField: r3 = r2->field_17
    //     0xcf2f74: ldur            w3, [x2, #0x17]
    // 0xcf2f78: DecompressPointer r3
    //     0xcf2f78: add             x3, x3, HEAP, lsl #32
    // 0xcf2f7c: stp             x3, x1, [SP, #-0x10]!
    // 0xcf2f80: r0 = ==()
    //     0xcf2f80: bl              #0xc9d2f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0xcf2f84: add             SP, SP, #0x10
    // 0xcf2f88: tbnz            w0, #4, #0xcf3014
    // 0xcf2f8c: ldr             x1, [fp, #0x18]
    // 0xcf2f90: ldr             x0, [fp, #0x10]
    // 0xcf2f94: LoadField: r2 = r0->field_1b
    //     0xcf2f94: ldur            w2, [x0, #0x1b]
    // 0xcf2f98: DecompressPointer r2
    //     0xcf2f98: add             x2, x2, HEAP, lsl #32
    // 0xcf2f9c: LoadField: r3 = r1->field_1b
    //     0xcf2f9c: ldur            w3, [x1, #0x1b]
    // 0xcf2fa0: DecompressPointer r3
    //     0xcf2fa0: add             x3, x3, HEAP, lsl #32
    // 0xcf2fa4: stp             x3, x2, [SP, #-0x10]!
    // 0xcf2fa8: r0 = ==()
    //     0xcf2fa8: bl              #0xc9d2f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0xcf2fac: add             SP, SP, #0x10
    // 0xcf2fb0: tbnz            w0, #4, #0xcf3014
    // 0xcf2fb4: ldr             x2, [fp, #0x18]
    // 0xcf2fb8: ldr             x1, [fp, #0x10]
    // 0xcf2fbc: LoadField: r3 = r1->field_1f
    //     0xcf2fbc: ldur            w3, [x1, #0x1f]
    // 0xcf2fc0: DecompressPointer r3
    //     0xcf2fc0: add             x3, x3, HEAP, lsl #32
    // 0xcf2fc4: LoadField: r4 = r2->field_1f
    //     0xcf2fc4: ldur            w4, [x2, #0x1f]
    // 0xcf2fc8: DecompressPointer r4
    //     0xcf2fc8: add             x4, x4, HEAP, lsl #32
    // 0xcf2fcc: cmp             w3, w4
    // 0xcf2fd0: b.ne            #0xcf3014
    // 0xcf2fd4: LoadField: d0 = r1->field_2f
    //     0xcf2fd4: ldur            d0, [x1, #0x2f]
    // 0xcf2fd8: LoadField: d1 = r2->field_2f
    //     0xcf2fd8: ldur            d1, [x2, #0x2f]
    // 0xcf2fdc: fcmp            d0, d1
    // 0xcf2fe0: b.ne            #0xcf3014
    // 0xcf2fe4: LoadField: r3 = r1->field_27
    //     0xcf2fe4: ldur            w3, [x1, #0x27]
    // 0xcf2fe8: DecompressPointer r3
    //     0xcf2fe8: add             x3, x3, HEAP, lsl #32
    // 0xcf2fec: LoadField: r4 = r2->field_27
    //     0xcf2fec: ldur            w4, [x2, #0x27]
    // 0xcf2ff0: DecompressPointer r4
    //     0xcf2ff0: add             x4, x4, HEAP, lsl #32
    // 0xcf2ff4: cmp             w3, w4
    // 0xcf2ff8: b.ne            #0xcf3014
    // 0xcf2ffc: LoadField: r3 = r1->field_f
    //     0xcf2ffc: ldur            w3, [x1, #0xf]
    // 0xcf3000: DecompressPointer r3
    //     0xcf3000: add             x3, x3, HEAP, lsl #32
    // 0xcf3004: LoadField: r1 = r2->field_f
    //     0xcf3004: ldur            w1, [x2, #0xf]
    // 0xcf3008: DecompressPointer r1
    //     0xcf3008: add             x1, x1, HEAP, lsl #32
    // 0xcf300c: cmp             w3, w1
    // 0xcf3010: b.eq            #0xcf301c
    // 0xcf3014: r0 = true
    //     0xcf3014: add             x0, NULL, #0x20  ; true
    // 0xcf3018: b               #0xcf3020
    // 0xcf301c: r0 = false
    //     0xcf301c: add             x0, NULL, #0x30  ; false
    // 0xcf3020: LeaveFrame
    //     0xcf3020: mov             SP, fp
    //     0xcf3024: ldp             fp, lr, [SP], #0x10
    // 0xcf3028: ret
    //     0xcf3028: ret             
    // 0xcf302c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf302c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf3030: b               #0xcf2f2c
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xcf30dc, size: 0xf64
    // 0xcf30dc: EnterFrame
    //     0xcf30dc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf30e0: mov             fp, SP
    // 0xcf30e4: AllocStack(0x98)
    //     0xcf30e4: sub             SP, SP, #0x98
    // 0xcf30e8: CheckStackOverflow
    //     0xcf30e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf30ec: cmp             SP, x16
    //     0xcf30f0: b.ls            #0xcf3fcc
    // 0xcf30f4: r0 = BoxConstraints()
    //     0xcf30f4: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xcf30f8: d0 = 0.000000
    //     0xcf30f8: eor             v0.16b, v0.16b, v0.16b
    // 0xcf30fc: stur            x0, [fp, #-8]
    // 0xcf3100: StoreField: r0->field_7 = d0
    //     0xcf3100: stur            d0, [x0, #7]
    // 0xcf3104: ldr             x1, [fp, #0x10]
    // 0xcf3108: LoadField: d1 = r1->field_7
    //     0xcf3108: ldur            d1, [x1, #7]
    // 0xcf310c: stur            d1, [fp, #-0x60]
    // 0xcf3110: StoreField: r0->field_f = d1
    //     0xcf3110: stur            d1, [x0, #0xf]
    // 0xcf3114: StoreField: r0->field_17 = d0
    //     0xcf3114: stur            d0, [x0, #0x17]
    // 0xcf3118: LoadField: d2 = r1->field_f
    //     0xcf3118: ldur            d2, [x1, #0xf]
    // 0xcf311c: stur            d2, [fp, #-0x58]
    // 0xcf3120: StoreField: r0->field_1f = d2
    //     0xcf3120: stur            d2, [x0, #0x1f]
    // 0xcf3124: r2 = inline_Allocate_Double()
    //     0xcf3124: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xcf3128: add             x2, x2, #0x10
    //     0xcf312c: cmp             x3, x2
    //     0xcf3130: b.ls            #0xcf3fd4
    //     0xcf3134: str             x2, [THR, #0x60]  ; THR::top
    //     0xcf3138: sub             x2, x2, #0xf
    //     0xcf313c: mov             x3, #0xd108
    //     0xcf3140: movk            x3, #3, lsl #16
    //     0xcf3144: stur            x3, [x2, #-1]
    // 0xcf3148: StoreField: r2->field_7 = d1
    //     0xcf3148: stur            d1, [x2, #7]
    // 0xcf314c: stp             x2, x0, [SP, #-0x10]!
    // 0xcf3150: r4 = const [0, 0x2, 0x2, 0x1, width, 0x1, null]
    //     0xcf3150: add             x4, PP, #0x21, lsl #12  ; [pp+0x21618] List(7) [0, 0x2, 0x2, 0x1, "width", 0x1, Null]
    //     0xcf3154: ldr             x4, [x4, #0x618]
    // 0xcf3158: r0 = tighten()
    //     0xcf3158: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0xcf315c: add             SP, SP, #0x10
    // 0xcf3160: stur            x0, [fp, #-0x10]
    // 0xcf3164: ldr             x16, [fp, #0x18]
    // 0xcf3168: r30 = Instance__ScaffoldSlot
    //     0xcf3168: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d80] Obj!_ScaffoldSlot@b65331
    //     0xcf316c: ldr             lr, [lr, #0xd80]
    // 0xcf3170: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3174: r0 = hasChild()
    //     0xcf3174: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3178: add             SP, SP, #0x10
    // 0xcf317c: tbnz            w0, #4, #0xcf31d4
    // 0xcf3180: ldr             x16, [fp, #0x18]
    // 0xcf3184: r30 = Instance__ScaffoldSlot
    //     0xcf3184: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d80] Obj!_ScaffoldSlot@b65331
    //     0xcf3188: ldr             lr, [lr, #0xd80]
    // 0xcf318c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3190: ldur            x16, [fp, #-0x10]
    // 0xcf3194: SaveReg r16
    //     0xcf3194: str             x16, [SP, #-8]!
    // 0xcf3198: r0 = layoutChild()
    //     0xcf3198: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf319c: add             SP, SP, #0x18
    // 0xcf31a0: LoadField: d0 = r0->field_f
    //     0xcf31a0: ldur            d0, [x0, #0xf]
    // 0xcf31a4: stur            d0, [fp, #-0x68]
    // 0xcf31a8: ldr             x16, [fp, #0x18]
    // 0xcf31ac: r30 = Instance__ScaffoldSlot
    //     0xcf31ac: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d80] Obj!_ScaffoldSlot@b65331
    //     0xcf31b0: ldr             lr, [lr, #0xd80]
    // 0xcf31b4: stp             lr, x16, [SP, #-0x10]!
    // 0xcf31b8: r16 = Instance_Offset
    //     0xcf31b8: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcf31bc: SaveReg r16
    //     0xcf31bc: str             x16, [SP, #-8]!
    // 0xcf31c0: r0 = positionChild()
    //     0xcf31c0: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf31c4: add             SP, SP, #0x18
    // 0xcf31c8: ldur            d1, [fp, #-0x68]
    // 0xcf31cc: ldur            d0, [fp, #-0x68]
    // 0xcf31d0: b               #0xcf31dc
    // 0xcf31d4: d1 = 0.000000
    //     0xcf31d4: eor             v1.16b, v1.16b, v1.16b
    // 0xcf31d8: d0 = 0.000000
    //     0xcf31d8: eor             v0.16b, v0.16b, v0.16b
    // 0xcf31dc: stur            d1, [fp, #-0x68]
    // 0xcf31e0: stur            d0, [fp, #-0x70]
    // 0xcf31e4: ldr             x16, [fp, #0x18]
    // 0xcf31e8: r30 = Instance__ScaffoldSlot
    //     0xcf31e8: add             lr, PP, #0x21, lsl #12  ; [pp+0x21dc8] Obj!_ScaffoldSlot@b652b1
    //     0xcf31ec: ldr             lr, [lr, #0xdc8]
    // 0xcf31f0: stp             lr, x16, [SP, #-0x10]!
    // 0xcf31f4: r0 = hasChild()
    //     0xcf31f4: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf31f8: add             SP, SP, #0x10
    // 0xcf31fc: tbnz            w0, #4, #0xcf32e8
    // 0xcf3200: ldur            d0, [fp, #-0x58]
    // 0xcf3204: ldr             x16, [fp, #0x18]
    // 0xcf3208: r30 = Instance__ScaffoldSlot
    //     0xcf3208: add             lr, PP, #0x21, lsl #12  ; [pp+0x21dc8] Obj!_ScaffoldSlot@b652b1
    //     0xcf320c: ldr             lr, [lr, #0xdc8]
    // 0xcf3210: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3214: ldur            x16, [fp, #-0x10]
    // 0xcf3218: SaveReg r16
    //     0xcf3218: str             x16, [SP, #-8]!
    // 0xcf321c: r0 = layoutChild()
    //     0xcf321c: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf3220: add             SP, SP, #0x18
    // 0xcf3224: LoadField: d0 = r0->field_f
    //     0xcf3224: ldur            d0, [x0, #0xf]
    // 0xcf3228: d1 = 0.000000
    //     0xcf3228: eor             v1.16b, v1.16b, v1.16b
    // 0xcf322c: fadd            d2, d1, d0
    // 0xcf3230: ldur            d0, [fp, #-0x58]
    // 0xcf3234: stur            d2, [fp, #-0x80]
    // 0xcf3238: fsub            d3, d0, d2
    // 0xcf323c: fcmp            d1, d3
    // 0xcf3240: b.vs            #0xcf3250
    // 0xcf3244: b.le            #0xcf3250
    // 0xcf3248: d3 = 0.000000
    //     0xcf3248: eor             v3.16b, v3.16b, v3.16b
    // 0xcf324c: b               #0xcf3280
    // 0xcf3250: fcmp            d1, d3
    // 0xcf3254: b.vs            #0xcf325c
    // 0xcf3258: b.lt            #0xcf3280
    // 0xcf325c: fcmp            d1, d1
    // 0xcf3260: b.vs            #0xcf3274
    // 0xcf3264: b.ne            #0xcf3274
    // 0xcf3268: fadd            d4, d1, d3
    // 0xcf326c: mov             v3.16b, v4.16b
    // 0xcf3270: b               #0xcf3280
    // 0xcf3274: fcmp            d3, d3
    // 0xcf3278: b.vs            #0xcf3280
    // 0xcf327c: d3 = 0.000000
    //     0xcf327c: eor             v3.16b, v3.16b, v3.16b
    // 0xcf3280: stur            d3, [fp, #-0x78]
    // 0xcf3284: r0 = Offset()
    //     0xcf3284: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcf3288: d0 = 0.000000
    //     0xcf3288: eor             v0.16b, v0.16b, v0.16b
    // 0xcf328c: StoreField: r0->field_7 = d0
    //     0xcf328c: stur            d0, [x0, #7]
    // 0xcf3290: ldur            d1, [fp, #-0x78]
    // 0xcf3294: StoreField: r0->field_f = d1
    //     0xcf3294: stur            d1, [x0, #0xf]
    // 0xcf3298: ldr             x16, [fp, #0x18]
    // 0xcf329c: r30 = Instance__ScaffoldSlot
    //     0xcf329c: add             lr, PP, #0x21, lsl #12  ; [pp+0x21dc8] Obj!_ScaffoldSlot@b652b1
    //     0xcf32a0: ldr             lr, [lr, #0xdc8]
    // 0xcf32a4: stp             lr, x16, [SP, #-0x10]!
    // 0xcf32a8: SaveReg r0
    //     0xcf32a8: str             x0, [SP, #-8]!
    // 0xcf32ac: r0 = positionChild()
    //     0xcf32ac: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf32b0: add             SP, SP, #0x18
    // 0xcf32b4: ldur            d0, [fp, #-0x78]
    // 0xcf32b8: r0 = inline_Allocate_Double()
    //     0xcf32b8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcf32bc: add             x0, x0, #0x10
    //     0xcf32c0: cmp             x1, x0
    //     0xcf32c4: b.ls            #0xcf3ff8
    //     0xcf32c8: str             x0, [THR, #0x60]  ; THR::top
    //     0xcf32cc: sub             x0, x0, #0xf
    //     0xcf32d0: mov             x1, #0xd108
    //     0xcf32d4: movk            x1, #3, lsl #16
    //     0xcf32d8: stur            x1, [x0, #-1]
    // 0xcf32dc: StoreField: r0->field_7 = d0
    //     0xcf32dc: stur            d0, [x0, #7]
    // 0xcf32e0: ldur            d0, [fp, #-0x80]
    // 0xcf32e4: b               #0xcf32f0
    // 0xcf32e8: d0 = 0.000000
    //     0xcf32e8: eor             v0.16b, v0.16b, v0.16b
    // 0xcf32ec: r0 = Null
    //     0xcf32ec: mov             x0, NULL
    // 0xcf32f0: stur            x0, [fp, #-0x18]
    // 0xcf32f4: stur            d0, [fp, #-0x78]
    // 0xcf32f8: ldr             x16, [fp, #0x18]
    // 0xcf32fc: r30 = Instance__ScaffoldSlot
    //     0xcf32fc: add             lr, PP, #0x37, lsl #12  ; [pp+0x37758] Obj!_ScaffoldSlot@b653d1
    //     0xcf3300: ldr             lr, [lr, #0x758]
    // 0xcf3304: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3308: r0 = hasChild()
    //     0xcf3308: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf330c: add             SP, SP, #0x10
    // 0xcf3310: tbnz            w0, #4, #0xcf3464
    // 0xcf3314: ldur            x0, [fp, #-0x10]
    // 0xcf3318: ldur            d3, [fp, #-0x68]
    // 0xcf331c: ldur            d0, [fp, #-0x78]
    // 0xcf3320: ldur            d2, [fp, #-0x58]
    // 0xcf3324: d1 = 0.000000
    //     0xcf3324: eor             v1.16b, v1.16b, v1.16b
    // 0xcf3328: LoadField: d4 = r0->field_f
    //     0xcf3328: ldur            d4, [x0, #0xf]
    // 0xcf332c: stur            d4, [fp, #-0x88]
    // 0xcf3330: fsub            d5, d2, d0
    // 0xcf3334: fsub            d6, d5, d3
    // 0xcf3338: fcmp            d1, d6
    // 0xcf333c: b.vs            #0xcf334c
    // 0xcf3340: b.le            #0xcf334c
    // 0xcf3344: d5 = 0.000000
    //     0xcf3344: eor             v5.16b, v5.16b, v5.16b
    // 0xcf3348: b               #0xcf3388
    // 0xcf334c: fcmp            d1, d6
    // 0xcf3350: b.vs            #0xcf3360
    // 0xcf3354: b.ge            #0xcf3360
    // 0xcf3358: mov             v5.16b, v6.16b
    // 0xcf335c: b               #0xcf3388
    // 0xcf3360: fcmp            d1, d1
    // 0xcf3364: b.vs            #0xcf3374
    // 0xcf3368: b.ne            #0xcf3374
    // 0xcf336c: fadd            d5, d1, d6
    // 0xcf3370: b               #0xcf3388
    // 0xcf3374: fcmp            d6, d6
    // 0xcf3378: b.vc            #0xcf3384
    // 0xcf337c: mov             v5.16b, v6.16b
    // 0xcf3380: b               #0xcf3388
    // 0xcf3384: d5 = 0.000000
    //     0xcf3384: eor             v5.16b, v5.16b, v5.16b
    // 0xcf3388: stur            d5, [fp, #-0x80]
    // 0xcf338c: r0 = BoxConstraints()
    //     0xcf338c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xcf3390: d0 = 0.000000
    //     0xcf3390: eor             v0.16b, v0.16b, v0.16b
    // 0xcf3394: StoreField: r0->field_7 = d0
    //     0xcf3394: stur            d0, [x0, #7]
    // 0xcf3398: ldur            d1, [fp, #-0x88]
    // 0xcf339c: StoreField: r0->field_f = d1
    //     0xcf339c: stur            d1, [x0, #0xf]
    // 0xcf33a0: StoreField: r0->field_17 = d0
    //     0xcf33a0: stur            d0, [x0, #0x17]
    // 0xcf33a4: ldur            d1, [fp, #-0x80]
    // 0xcf33a8: StoreField: r0->field_1f = d1
    //     0xcf33a8: stur            d1, [x0, #0x1f]
    // 0xcf33ac: ldr             x16, [fp, #0x18]
    // 0xcf33b0: r30 = Instance__ScaffoldSlot
    //     0xcf33b0: add             lr, PP, #0x37, lsl #12  ; [pp+0x37758] Obj!_ScaffoldSlot@b653d1
    //     0xcf33b4: ldr             lr, [lr, #0x758]
    // 0xcf33b8: stp             lr, x16, [SP, #-0x10]!
    // 0xcf33bc: SaveReg r0
    //     0xcf33bc: str             x0, [SP, #-8]!
    // 0xcf33c0: r0 = layoutChild()
    //     0xcf33c0: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf33c4: add             SP, SP, #0x18
    // 0xcf33c8: LoadField: d0 = r0->field_f
    //     0xcf33c8: ldur            d0, [x0, #0xf]
    // 0xcf33cc: ldur            d1, [fp, #-0x78]
    // 0xcf33d0: fadd            d2, d1, d0
    // 0xcf33d4: ldur            d0, [fp, #-0x58]
    // 0xcf33d8: stur            d2, [fp, #-0x88]
    // 0xcf33dc: fsub            d1, d0, d2
    // 0xcf33e0: d3 = 0.000000
    //     0xcf33e0: eor             v3.16b, v3.16b, v3.16b
    // 0xcf33e4: fcmp            d3, d1
    // 0xcf33e8: b.vs            #0xcf33f8
    // 0xcf33ec: b.le            #0xcf33f8
    // 0xcf33f0: d1 = 0.000000
    //     0xcf33f0: eor             v1.16b, v1.16b, v1.16b
    // 0xcf33f4: b               #0xcf3428
    // 0xcf33f8: fcmp            d3, d1
    // 0xcf33fc: b.vs            #0xcf3404
    // 0xcf3400: b.lt            #0xcf3428
    // 0xcf3404: fcmp            d3, d3
    // 0xcf3408: b.vs            #0xcf341c
    // 0xcf340c: b.ne            #0xcf341c
    // 0xcf3410: fadd            d4, d3, d1
    // 0xcf3414: mov             v1.16b, v4.16b
    // 0xcf3418: b               #0xcf3428
    // 0xcf341c: fcmp            d1, d1
    // 0xcf3420: b.vs            #0xcf3428
    // 0xcf3424: d1 = 0.000000
    //     0xcf3424: eor             v1.16b, v1.16b, v1.16b
    // 0xcf3428: stur            d1, [fp, #-0x80]
    // 0xcf342c: r0 = Offset()
    //     0xcf342c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcf3430: d0 = 0.000000
    //     0xcf3430: eor             v0.16b, v0.16b, v0.16b
    // 0xcf3434: StoreField: r0->field_7 = d0
    //     0xcf3434: stur            d0, [x0, #7]
    // 0xcf3438: ldur            d1, [fp, #-0x80]
    // 0xcf343c: StoreField: r0->field_f = d1
    //     0xcf343c: stur            d1, [x0, #0xf]
    // 0xcf3440: ldr             x16, [fp, #0x18]
    // 0xcf3444: r30 = Instance__ScaffoldSlot
    //     0xcf3444: add             lr, PP, #0x37, lsl #12  ; [pp+0x37758] Obj!_ScaffoldSlot@b653d1
    //     0xcf3448: ldr             lr, [lr, #0x758]
    // 0xcf344c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3450: SaveReg r0
    //     0xcf3450: str             x0, [SP, #-8]!
    // 0xcf3454: r0 = positionChild()
    //     0xcf3454: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3458: add             SP, SP, #0x18
    // 0xcf345c: ldur            d0, [fp, #-0x88]
    // 0xcf3460: b               #0xcf346c
    // 0xcf3464: ldur            d1, [fp, #-0x78]
    // 0xcf3468: mov             v0.16b, v1.16b
    // 0xcf346c: stur            d0, [fp, #-0x78]
    // 0xcf3470: ldr             x16, [fp, #0x18]
    // 0xcf3474: r30 = Instance__ScaffoldSlot
    //     0xcf3474: add             lr, PP, #0x21, lsl #12  ; [pp+0x21dc0] Obj!_ScaffoldSlot@b652d1
    //     0xcf3478: ldr             lr, [lr, #0xdc0]
    // 0xcf347c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3480: r0 = hasChild()
    //     0xcf3480: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3484: add             SP, SP, #0x10
    // 0xcf3488: tbnz            w0, #4, #0xcf351c
    // 0xcf348c: ldr             x0, [fp, #0x18]
    // 0xcf3490: ldur            d0, [fp, #-0x70]
    // 0xcf3494: r16 = Instance__ScaffoldSlot
    //     0xcf3494: add             x16, PP, #0x21, lsl #12  ; [pp+0x21dc0] Obj!_ScaffoldSlot@b652d1
    //     0xcf3498: ldr             x16, [x16, #0xdc0]
    // 0xcf349c: stp             x16, x0, [SP, #-0x10]!
    // 0xcf34a0: ldur            x16, [fp, #-0x10]
    // 0xcf34a4: SaveReg r16
    //     0xcf34a4: str             x16, [SP, #-8]!
    // 0xcf34a8: r0 = layoutChild()
    //     0xcf34a8: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf34ac: add             SP, SP, #0x18
    // 0xcf34b0: stur            x0, [fp, #-0x20]
    // 0xcf34b4: r0 = Offset()
    //     0xcf34b4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcf34b8: d0 = 0.000000
    //     0xcf34b8: eor             v0.16b, v0.16b, v0.16b
    // 0xcf34bc: StoreField: r0->field_7 = d0
    //     0xcf34bc: stur            d0, [x0, #7]
    // 0xcf34c0: ldur            d1, [fp, #-0x70]
    // 0xcf34c4: StoreField: r0->field_f = d1
    //     0xcf34c4: stur            d1, [x0, #0xf]
    // 0xcf34c8: ldr             x16, [fp, #0x18]
    // 0xcf34cc: r30 = Instance__ScaffoldSlot
    //     0xcf34cc: add             lr, PP, #0x21, lsl #12  ; [pp+0x21dc0] Obj!_ScaffoldSlot@b652d1
    //     0xcf34d0: ldr             lr, [lr, #0xdc0]
    // 0xcf34d4: stp             lr, x16, [SP, #-0x10]!
    // 0xcf34d8: SaveReg r0
    //     0xcf34d8: str             x0, [SP, #-8]!
    // 0xcf34dc: r0 = positionChild()
    //     0xcf34dc: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf34e0: add             SP, SP, #0x18
    // 0xcf34e4: ldr             x0, [fp, #0x18]
    // 0xcf34e8: LoadField: r1 = r0->field_43
    //     0xcf34e8: ldur            w1, [x0, #0x43]
    // 0xcf34ec: DecompressPointer r1
    //     0xcf34ec: add             x1, x1, HEAP, lsl #32
    // 0xcf34f0: tbz             w1, #4, #0xcf350c
    // 0xcf34f4: ldur            d0, [fp, #-0x68]
    // 0xcf34f8: ldur            x1, [fp, #-0x20]
    // 0xcf34fc: LoadField: d1 = r1->field_f
    //     0xcf34fc: ldur            d1, [x1, #0xf]
    // 0xcf3500: fadd            d2, d0, d1
    // 0xcf3504: mov             v0.16b, v2.16b
    // 0xcf3508: b               #0xcf3514
    // 0xcf350c: ldur            d0, [fp, #-0x68]
    // 0xcf3510: ldur            x1, [fp, #-0x20]
    // 0xcf3514: mov             v1.16b, v0.16b
    // 0xcf3518: b               #0xcf352c
    // 0xcf351c: ldr             x0, [fp, #0x18]
    // 0xcf3520: ldur            d0, [fp, #-0x68]
    // 0xcf3524: mov             v1.16b, v0.16b
    // 0xcf3528: r1 = Instance_Size
    //     0xcf3528: ldr             x1, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xcf352c: ldur            d0, [fp, #-0x78]
    // 0xcf3530: stur            x1, [fp, #-0x28]
    // 0xcf3534: stur            d1, [fp, #-0x80]
    // 0xcf3538: LoadField: r2 = r0->field_17
    //     0xcf3538: ldur            w2, [x0, #0x17]
    // 0xcf353c: DecompressPointer r2
    //     0xcf353c: add             x2, x2, HEAP, lsl #32
    // 0xcf3540: stur            x2, [fp, #-0x20]
    // 0xcf3544: LoadField: d2 = r2->field_1f
    //     0xcf3544: ldur            d2, [x2, #0x1f]
    // 0xcf3548: fcmp            d2, d0
    // 0xcf354c: b.vs            #0xcf3560
    // 0xcf3550: b.le            #0xcf3560
    // 0xcf3554: mov             v4.16b, v2.16b
    // 0xcf3558: d3 = 0.000000
    //     0xcf3558: eor             v3.16b, v3.16b, v3.16b
    // 0xcf355c: b               #0xcf35a4
    // 0xcf3560: fcmp            d2, d0
    // 0xcf3564: b.vs            #0xcf3578
    // 0xcf3568: b.ge            #0xcf3578
    // 0xcf356c: mov             v4.16b, v0.16b
    // 0xcf3570: d3 = 0.000000
    //     0xcf3570: eor             v3.16b, v3.16b, v3.16b
    // 0xcf3574: b               #0xcf35a4
    // 0xcf3578: d3 = 0.000000
    //     0xcf3578: eor             v3.16b, v3.16b, v3.16b
    // 0xcf357c: fcmp            d2, d3
    // 0xcf3580: b.vs            #0xcf3590
    // 0xcf3584: b.ne            #0xcf3590
    // 0xcf3588: fadd            d4, d2, d0
    // 0xcf358c: b               #0xcf35a4
    // 0xcf3590: fcmp            d0, d0
    // 0xcf3594: b.vc            #0xcf35a0
    // 0xcf3598: mov             v4.16b, v0.16b
    // 0xcf359c: b               #0xcf35a4
    // 0xcf35a0: mov             v4.16b, v2.16b
    // 0xcf35a4: ldur            d2, [fp, #-0x58]
    // 0xcf35a8: fsub            d5, d2, d4
    // 0xcf35ac: fcmp            d3, d5
    // 0xcf35b0: b.vs            #0xcf35c0
    // 0xcf35b4: b.le            #0xcf35c0
    // 0xcf35b8: d4 = 0.000000
    //     0xcf35b8: eor             v4.16b, v4.16b, v4.16b
    // 0xcf35bc: b               #0xcf35fc
    // 0xcf35c0: fcmp            d3, d5
    // 0xcf35c4: b.vs            #0xcf35d4
    // 0xcf35c8: b.ge            #0xcf35d4
    // 0xcf35cc: mov             v4.16b, v5.16b
    // 0xcf35d0: b               #0xcf35fc
    // 0xcf35d4: fcmp            d3, d3
    // 0xcf35d8: b.vs            #0xcf35e8
    // 0xcf35dc: b.ne            #0xcf35e8
    // 0xcf35e0: fadd            d4, d3, d5
    // 0xcf35e4: b               #0xcf35fc
    // 0xcf35e8: fcmp            d5, d5
    // 0xcf35ec: b.vc            #0xcf35f8
    // 0xcf35f0: mov             v4.16b, v5.16b
    // 0xcf35f4: b               #0xcf35fc
    // 0xcf35f8: d4 = 0.000000
    //     0xcf35f8: eor             v4.16b, v4.16b, v4.16b
    // 0xcf35fc: stur            d4, [fp, #-0x68]
    // 0xcf3600: r16 = Instance__ScaffoldSlot
    //     0xcf3600: add             x16, PP, #0x21, lsl #12  ; [pp+0x21d68] Obj!_ScaffoldSlot@b65371
    //     0xcf3604: ldr             x16, [x16, #0xd68]
    // 0xcf3608: stp             x16, x0, [SP, #-0x10]!
    // 0xcf360c: r0 = hasChild()
    //     0xcf360c: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3610: add             SP, SP, #0x10
    // 0xcf3614: tbnz            w0, #4, #0xcf377c
    // 0xcf3618: ldur            d0, [fp, #-0x80]
    // 0xcf361c: ldur            d2, [fp, #-0x68]
    // 0xcf3620: d1 = 0.000000
    //     0xcf3620: eor             v1.16b, v1.16b, v1.16b
    // 0xcf3624: fsub            d3, d2, d0
    // 0xcf3628: fcmp            d1, d3
    // 0xcf362c: b.vs            #0xcf363c
    // 0xcf3630: b.le            #0xcf363c
    // 0xcf3634: d3 = 0.000000
    //     0xcf3634: eor             v3.16b, v3.16b, v3.16b
    // 0xcf3638: b               #0xcf366c
    // 0xcf363c: fcmp            d1, d3
    // 0xcf3640: b.vs            #0xcf3648
    // 0xcf3644: b.lt            #0xcf366c
    // 0xcf3648: fcmp            d1, d1
    // 0xcf364c: b.vs            #0xcf3660
    // 0xcf3650: b.ne            #0xcf3660
    // 0xcf3654: fadd            d4, d1, d3
    // 0xcf3658: mov             v3.16b, v4.16b
    // 0xcf365c: b               #0xcf366c
    // 0xcf3660: fcmp            d3, d3
    // 0xcf3664: b.vs            #0xcf366c
    // 0xcf3668: d3 = 0.000000
    //     0xcf3668: eor             v3.16b, v3.16b, v3.16b
    // 0xcf366c: ldr             x0, [fp, #0x18]
    // 0xcf3670: LoadField: r1 = r0->field_f
    //     0xcf3670: ldur            w1, [x0, #0xf]
    // 0xcf3674: DecompressPointer r1
    //     0xcf3674: add             x1, x1, HEAP, lsl #32
    // 0xcf3678: tbnz            w1, #4, #0xcf36bc
    // 0xcf367c: ldur            d4, [fp, #-0x78]
    // 0xcf3680: ldur            d5, [fp, #-0x58]
    // 0xcf3684: fadd            d6, d3, d4
    // 0xcf3688: fsub            d3, d5, d0
    // 0xcf368c: fcmp            d6, d1
    // 0xcf3690: b.vs            #0xcf36a0
    // 0xcf3694: b.ge            #0xcf36a0
    // 0xcf3698: d3 = 0.000000
    //     0xcf3698: eor             v3.16b, v3.16b, v3.16b
    // 0xcf369c: b               #0xcf36c4
    // 0xcf36a0: fcmp            d6, d3
    // 0xcf36a4: b.vs            #0xcf36ac
    // 0xcf36a8: b.gt            #0xcf36c4
    // 0xcf36ac: fcmp            d6, d6
    // 0xcf36b0: b.vs            #0xcf36c4
    // 0xcf36b4: mov             v3.16b, v6.16b
    // 0xcf36b8: b               #0xcf36c4
    // 0xcf36bc: ldur            d4, [fp, #-0x78]
    // 0xcf36c0: ldur            d5, [fp, #-0x58]
    // 0xcf36c4: ldur            x3, [fp, #-0x10]
    // 0xcf36c8: ldur            x2, [fp, #-0x28]
    // 0xcf36cc: stur            d3, [fp, #-0x98]
    // 0xcf36d0: LoadField: d6 = r3->field_f
    //     0xcf36d0: ldur            d6, [x3, #0xf]
    // 0xcf36d4: stur            d6, [fp, #-0x90]
    // 0xcf36d8: LoadField: d7 = r2->field_f
    //     0xcf36d8: ldur            d7, [x2, #0xf]
    // 0xcf36dc: stur            d7, [fp, #-0x88]
    // 0xcf36e0: tbnz            w1, #4, #0xcf36ec
    // 0xcf36e4: mov             v8.16b, v4.16b
    // 0xcf36e8: b               #0xcf36f0
    // 0xcf36ec: d8 = 0.000000
    //     0xcf36ec: eor             v8.16b, v8.16b, v8.16b
    // 0xcf36f0: ldur            d4, [fp, #-0x70]
    // 0xcf36f4: stur            d8, [fp, #-0x78]
    // 0xcf36f8: r0 = _BodyBoxConstraints()
    //     0xcf36f8: bl              #0xcf404c  ; Allocate_BodyBoxConstraintsStub -> _BodyBoxConstraints (size=0x40)
    // 0xcf36fc: ldur            d0, [fp, #-0x78]
    // 0xcf3700: StoreField: r0->field_27 = d0
    //     0xcf3700: stur            d0, [x0, #0x27]
    // 0xcf3704: ldur            d0, [fp, #-0x70]
    // 0xcf3708: StoreField: r0->field_2f = d0
    //     0xcf3708: stur            d0, [x0, #0x2f]
    // 0xcf370c: ldur            d0, [fp, #-0x88]
    // 0xcf3710: StoreField: r0->field_37 = d0
    //     0xcf3710: stur            d0, [x0, #0x37]
    // 0xcf3714: d0 = 0.000000
    //     0xcf3714: eor             v0.16b, v0.16b, v0.16b
    // 0xcf3718: StoreField: r0->field_7 = d0
    //     0xcf3718: stur            d0, [x0, #7]
    // 0xcf371c: ldur            d1, [fp, #-0x90]
    // 0xcf3720: StoreField: r0->field_f = d1
    //     0xcf3720: stur            d1, [x0, #0xf]
    // 0xcf3724: StoreField: r0->field_17 = d0
    //     0xcf3724: stur            d0, [x0, #0x17]
    // 0xcf3728: ldur            d1, [fp, #-0x98]
    // 0xcf372c: StoreField: r0->field_1f = d1
    //     0xcf372c: stur            d1, [x0, #0x1f]
    // 0xcf3730: ldr             x16, [fp, #0x18]
    // 0xcf3734: r30 = Instance__ScaffoldSlot
    //     0xcf3734: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d68] Obj!_ScaffoldSlot@b65371
    //     0xcf3738: ldr             lr, [lr, #0xd68]
    // 0xcf373c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3740: SaveReg r0
    //     0xcf3740: str             x0, [SP, #-8]!
    // 0xcf3744: r0 = layoutChild()
    //     0xcf3744: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf3748: add             SP, SP, #0x18
    // 0xcf374c: r0 = Offset()
    //     0xcf374c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcf3750: d0 = 0.000000
    //     0xcf3750: eor             v0.16b, v0.16b, v0.16b
    // 0xcf3754: StoreField: r0->field_7 = d0
    //     0xcf3754: stur            d0, [x0, #7]
    // 0xcf3758: ldur            d1, [fp, #-0x80]
    // 0xcf375c: StoreField: r0->field_f = d1
    //     0xcf375c: stur            d1, [x0, #0xf]
    // 0xcf3760: ldr             x16, [fp, #0x18]
    // 0xcf3764: r30 = Instance__ScaffoldSlot
    //     0xcf3764: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d68] Obj!_ScaffoldSlot@b65371
    //     0xcf3768: ldr             lr, [lr, #0xd68]
    // 0xcf376c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3770: SaveReg r0
    //     0xcf3770: str             x0, [SP, #-8]!
    // 0xcf3774: r0 = positionChild()
    //     0xcf3774: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3778: add             SP, SP, #0x18
    // 0xcf377c: ldr             x16, [fp, #0x18]
    // 0xcf3780: r30 = Instance__ScaffoldSlot
    //     0xcf3780: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d78] Obj!_ScaffoldSlot@b65351
    //     0xcf3784: ldr             lr, [lr, #0xd78]
    // 0xcf3788: stp             lr, x16, [SP, #-0x10]!
    // 0xcf378c: r0 = hasChild()
    //     0xcf378c: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3790: add             SP, SP, #0x10
    // 0xcf3794: tbnz            w0, #4, #0xcf3804
    // 0xcf3798: ldur            x0, [fp, #-0x10]
    // 0xcf379c: ldur            d0, [fp, #-0x68]
    // 0xcf37a0: LoadField: d1 = r0->field_f
    //     0xcf37a0: ldur            d1, [x0, #0xf]
    // 0xcf37a4: stur            d1, [fp, #-0x70]
    // 0xcf37a8: r0 = BoxConstraints()
    //     0xcf37a8: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xcf37ac: d0 = 0.000000
    //     0xcf37ac: eor             v0.16b, v0.16b, v0.16b
    // 0xcf37b0: StoreField: r0->field_7 = d0
    //     0xcf37b0: stur            d0, [x0, #7]
    // 0xcf37b4: ldur            d1, [fp, #-0x70]
    // 0xcf37b8: StoreField: r0->field_f = d1
    //     0xcf37b8: stur            d1, [x0, #0xf]
    // 0xcf37bc: StoreField: r0->field_17 = d0
    //     0xcf37bc: stur            d0, [x0, #0x17]
    // 0xcf37c0: ldur            d1, [fp, #-0x68]
    // 0xcf37c4: StoreField: r0->field_1f = d1
    //     0xcf37c4: stur            d1, [x0, #0x1f]
    // 0xcf37c8: ldr             x16, [fp, #0x18]
    // 0xcf37cc: r30 = Instance__ScaffoldSlot
    //     0xcf37cc: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d78] Obj!_ScaffoldSlot@b65351
    //     0xcf37d0: ldr             lr, [lr, #0xd78]
    // 0xcf37d4: stp             lr, x16, [SP, #-0x10]!
    // 0xcf37d8: SaveReg r0
    //     0xcf37d8: str             x0, [SP, #-8]!
    // 0xcf37dc: r0 = layoutChild()
    //     0xcf37dc: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf37e0: add             SP, SP, #0x18
    // 0xcf37e4: ldr             x16, [fp, #0x18]
    // 0xcf37e8: r30 = Instance__ScaffoldSlot
    //     0xcf37e8: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d78] Obj!_ScaffoldSlot@b65351
    //     0xcf37ec: ldr             lr, [lr, #0xd78]
    // 0xcf37f0: stp             lr, x16, [SP, #-0x10]!
    // 0xcf37f4: r16 = Instance_Offset
    //     0xcf37f4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcf37f8: SaveReg r16
    //     0xcf37f8: str             x16, [SP, #-8]!
    // 0xcf37fc: r0 = positionChild()
    //     0xcf37fc: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3800: add             SP, SP, #0x18
    // 0xcf3804: ldr             x16, [fp, #0x18]
    // 0xcf3808: r30 = Instance__ScaffoldSlot
    //     0xcf3808: add             lr, PP, #0x21, lsl #12  ; [pp+0x21db0] Obj!_ScaffoldSlot@b652f1
    //     0xcf380c: ldr             lr, [lr, #0xdb0]
    // 0xcf3810: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3814: r0 = hasChild()
    //     0xcf3814: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3818: add             SP, SP, #0x10
    // 0xcf381c: tbnz            w0, #4, #0xcf3850
    // 0xcf3820: ldr             x0, [fp, #0x18]
    // 0xcf3824: LoadField: r1 = r0->field_3b
    //     0xcf3824: ldur            w1, [x0, #0x3b]
    // 0xcf3828: DecompressPointer r1
    //     0xcf3828: add             x1, x1, HEAP, lsl #32
    // 0xcf382c: tbz             w1, #4, #0xcf3850
    // 0xcf3830: r16 = Instance__ScaffoldSlot
    //     0xcf3830: add             x16, PP, #0x21, lsl #12  ; [pp+0x21db0] Obj!_ScaffoldSlot@b652f1
    //     0xcf3834: ldr             x16, [x16, #0xdb0]
    // 0xcf3838: stp             x16, x0, [SP, #-0x10]!
    // 0xcf383c: ldur            x16, [fp, #-0x10]
    // 0xcf3840: SaveReg r16
    //     0xcf3840: str             x16, [SP, #-8]!
    // 0xcf3844: r0 = layoutChild()
    //     0xcf3844: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf3848: add             SP, SP, #0x18
    // 0xcf384c: b               #0xcf3854
    // 0xcf3850: r0 = Instance_Size
    //     0xcf3850: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xcf3854: stur            x0, [fp, #-0x28]
    // 0xcf3858: ldr             x16, [fp, #0x18]
    // 0xcf385c: r30 = Instance__ScaffoldSlot
    //     0xcf385c: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d88] Obj!_ScaffoldSlot@b65311
    //     0xcf3860: ldr             lr, [lr, #0xd88]
    // 0xcf3864: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3868: r0 = hasChild()
    //     0xcf3868: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf386c: add             SP, SP, #0x10
    // 0xcf3870: tbnz            w0, #4, #0xcf397c
    // 0xcf3874: ldur            x0, [fp, #-0x10]
    // 0xcf3878: ldur            d2, [fp, #-0x80]
    // 0xcf387c: ldur            d1, [fp, #-0x68]
    // 0xcf3880: d0 = 0.000000
    //     0xcf3880: eor             v0.16b, v0.16b, v0.16b
    // 0xcf3884: LoadField: d3 = r0->field_f
    //     0xcf3884: ldur            d3, [x0, #0xf]
    // 0xcf3888: stur            d3, [fp, #-0x78]
    // 0xcf388c: fsub            d4, d1, d2
    // 0xcf3890: fcmp            d0, d4
    // 0xcf3894: b.vs            #0xcf38a4
    // 0xcf3898: b.le            #0xcf38a4
    // 0xcf389c: d4 = 0.000000
    //     0xcf389c: eor             v4.16b, v4.16b, v4.16b
    // 0xcf38a0: b               #0xcf38d4
    // 0xcf38a4: fcmp            d0, d4
    // 0xcf38a8: b.vs            #0xcf38b0
    // 0xcf38ac: b.lt            #0xcf38d4
    // 0xcf38b0: fcmp            d0, d0
    // 0xcf38b4: b.vs            #0xcf38c8
    // 0xcf38b8: b.ne            #0xcf38c8
    // 0xcf38bc: fadd            d2, d0, d4
    // 0xcf38c0: mov             v4.16b, v2.16b
    // 0xcf38c4: b               #0xcf38d4
    // 0xcf38c8: fcmp            d4, d4
    // 0xcf38cc: b.vs            #0xcf38d4
    // 0xcf38d0: d4 = 0.000000
    //     0xcf38d0: eor             v4.16b, v4.16b, v4.16b
    // 0xcf38d4: ldur            d2, [fp, #-0x60]
    // 0xcf38d8: stur            d4, [fp, #-0x70]
    // 0xcf38dc: r0 = BoxConstraints()
    //     0xcf38dc: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xcf38e0: d0 = 0.000000
    //     0xcf38e0: eor             v0.16b, v0.16b, v0.16b
    // 0xcf38e4: StoreField: r0->field_7 = d0
    //     0xcf38e4: stur            d0, [x0, #7]
    // 0xcf38e8: ldur            d1, [fp, #-0x78]
    // 0xcf38ec: StoreField: r0->field_f = d1
    //     0xcf38ec: stur            d1, [x0, #0xf]
    // 0xcf38f0: StoreField: r0->field_17 = d0
    //     0xcf38f0: stur            d0, [x0, #0x17]
    // 0xcf38f4: ldur            d1, [fp, #-0x70]
    // 0xcf38f8: StoreField: r0->field_1f = d1
    //     0xcf38f8: stur            d1, [x0, #0x1f]
    // 0xcf38fc: ldr             x16, [fp, #0x18]
    // 0xcf3900: r30 = Instance__ScaffoldSlot
    //     0xcf3900: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d88] Obj!_ScaffoldSlot@b65311
    //     0xcf3904: ldr             lr, [lr, #0xd88]
    // 0xcf3908: stp             lr, x16, [SP, #-0x10]!
    // 0xcf390c: SaveReg r0
    //     0xcf390c: str             x0, [SP, #-8]!
    // 0xcf3910: r0 = layoutChild()
    //     0xcf3910: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf3914: add             SP, SP, #0x18
    // 0xcf3918: stur            x0, [fp, #-0x30]
    // 0xcf391c: LoadField: d0 = r0->field_7
    //     0xcf391c: ldur            d0, [x0, #7]
    // 0xcf3920: ldur            d1, [fp, #-0x60]
    // 0xcf3924: fsub            d2, d1, d0
    // 0xcf3928: d0 = 2.000000
    //     0xcf3928: fmov            d0, #2.00000000
    // 0xcf392c: fdiv            d3, d2, d0
    // 0xcf3930: stur            d3, [fp, #-0x78]
    // 0xcf3934: LoadField: d2 = r0->field_f
    //     0xcf3934: ldur            d2, [x0, #0xf]
    // 0xcf3938: ldur            d4, [fp, #-0x68]
    // 0xcf393c: fsub            d5, d4, d2
    // 0xcf3940: stur            d5, [fp, #-0x70]
    // 0xcf3944: r0 = Offset()
    //     0xcf3944: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcf3948: ldur            d0, [fp, #-0x78]
    // 0xcf394c: StoreField: r0->field_7 = d0
    //     0xcf394c: stur            d0, [x0, #7]
    // 0xcf3950: ldur            d0, [fp, #-0x70]
    // 0xcf3954: StoreField: r0->field_f = d0
    //     0xcf3954: stur            d0, [x0, #0xf]
    // 0xcf3958: ldr             x16, [fp, #0x18]
    // 0xcf395c: r30 = Instance__ScaffoldSlot
    //     0xcf395c: add             lr, PP, #0x21, lsl #12  ; [pp+0x21d88] Obj!_ScaffoldSlot@b65311
    //     0xcf3960: ldr             lr, [lr, #0xd88]
    // 0xcf3964: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3968: SaveReg r0
    //     0xcf3968: str             x0, [SP, #-8]!
    // 0xcf396c: r0 = positionChild()
    //     0xcf396c: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3970: add             SP, SP, #0x18
    // 0xcf3974: ldur            x0, [fp, #-0x30]
    // 0xcf3978: b               #0xcf3980
    // 0xcf397c: r0 = Instance_Size
    //     0xcf397c: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xcf3980: stur            x0, [fp, #-0x30]
    // 0xcf3984: ldr             x16, [fp, #0x18]
    // 0xcf3988: r30 = Instance__ScaffoldSlot
    //     0xcf3988: add             lr, PP, #0x21, lsl #12  ; [pp+0x21dd8] Obj!_ScaffoldSlot@b65291
    //     0xcf398c: ldr             lr, [lr, #0xdd8]
    // 0xcf3990: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3994: r0 = hasChild()
    //     0xcf3994: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3998: add             SP, SP, #0x10
    // 0xcf399c: tbnz            w0, #4, #0xcf3ae4
    // 0xcf39a0: ldr             x2, [fp, #0x18]
    // 0xcf39a4: ldr             x4, [fp, #0x10]
    // 0xcf39a8: ldur            x3, [fp, #-0x20]
    // 0xcf39ac: ldur            x1, [fp, #-0x28]
    // 0xcf39b0: ldur            x0, [fp, #-0x30]
    // 0xcf39b4: ldur            d0, [fp, #-0x68]
    // 0xcf39b8: r16 = Instance__ScaffoldSlot
    //     0xcf39b8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21dd8] Obj!_ScaffoldSlot@b65291
    //     0xcf39bc: ldr             x16, [x16, #0xdd8]
    // 0xcf39c0: stp             x16, x2, [SP, #-0x10]!
    // 0xcf39c4: ldur            x16, [fp, #-8]
    // 0xcf39c8: SaveReg r16
    //     0xcf39c8: str             x16, [SP, #-8]!
    // 0xcf39cc: r0 = layoutChild()
    //     0xcf39cc: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf39d0: add             SP, SP, #0x18
    // 0xcf39d4: mov             x1, x0
    // 0xcf39d8: ldr             x0, [fp, #0x18]
    // 0xcf39dc: stur            x1, [fp, #-0x48]
    // 0xcf39e0: LoadField: r2 = r0->field_1f
    //     0xcf39e0: ldur            w2, [x0, #0x1f]
    // 0xcf39e4: DecompressPointer r2
    //     0xcf39e4: add             x2, x2, HEAP, lsl #32
    // 0xcf39e8: stur            x2, [fp, #-0x40]
    // 0xcf39ec: LoadField: r3 = r0->field_1b
    //     0xcf39ec: ldur            w3, [x0, #0x1b]
    // 0xcf39f0: DecompressPointer r3
    //     0xcf39f0: add             x3, x3, HEAP, lsl #32
    // 0xcf39f4: stur            x3, [fp, #-0x38]
    // 0xcf39f8: r0 = ScaffoldPrelayoutGeometry()
    //     0xcf39f8: bl              #0xcf4040  ; AllocateScaffoldPrelayoutGeometryStub -> ScaffoldPrelayoutGeometry (size=0x2c)
    // 0xcf39fc: mov             x1, x0
    // 0xcf3a00: ldur            x0, [fp, #-0x30]
    // 0xcf3a04: stur            x1, [fp, #-0x50]
    // 0xcf3a08: StoreField: r1->field_b = r0
    //     0xcf3a08: stur            w0, [x1, #0xb]
    // 0xcf3a0c: ldur            d0, [fp, #-0x68]
    // 0xcf3a10: StoreField: r1->field_f = d0
    //     0xcf3a10: stur            d0, [x1, #0xf]
    // 0xcf3a14: ldur            x0, [fp, #-0x48]
    // 0xcf3a18: StoreField: r1->field_7 = r0
    //     0xcf3a18: stur            w0, [x1, #7]
    // 0xcf3a1c: ldur            x2, [fp, #-0x20]
    // 0xcf3a20: StoreField: r1->field_17 = r2
    //     0xcf3a20: stur            w2, [x1, #0x17]
    // 0xcf3a24: ldur            x3, [fp, #-0x38]
    // 0xcf3a28: StoreField: r1->field_1b = r3
    //     0xcf3a28: stur            w3, [x1, #0x1b]
    // 0xcf3a2c: ldr             x3, [fp, #0x10]
    // 0xcf3a30: StoreField: r1->field_1f = r3
    //     0xcf3a30: stur            w3, [x1, #0x1f]
    // 0xcf3a34: ldur            x3, [fp, #-0x28]
    // 0xcf3a38: StoreField: r1->field_23 = r3
    //     0xcf3a38: stur            w3, [x1, #0x23]
    // 0xcf3a3c: ldur            x4, [fp, #-0x40]
    // 0xcf3a40: StoreField: r1->field_27 = r4
    //     0xcf3a40: stur            w4, [x1, #0x27]
    // 0xcf3a44: r16 = Instance__EndFloatFabLocation
    //     0xcf3a44: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e48] Obj!_EndFloatFabLocation@b38591
    //     0xcf3a48: ldr             x16, [x16, #0xe48]
    // 0xcf3a4c: stp             x1, x16, [SP, #-0x10]!
    // 0xcf3a50: r0 = getOffset()
    //     0xcf3a50: bl              #0xcfa84c  ; [package:flutter/src/material/floating_action_button_location.dart] StandardFabLocation::getOffset
    // 0xcf3a54: add             SP, SP, #0x10
    // 0xcf3a58: mov             x2, x0
    // 0xcf3a5c: ldr             x1, [fp, #0x18]
    // 0xcf3a60: stur            x2, [fp, #-0x30]
    // 0xcf3a64: LoadField: r0 = r1->field_27
    //     0xcf3a64: ldur            w0, [x1, #0x27]
    // 0xcf3a68: DecompressPointer r0
    //     0xcf3a68: add             x0, x0, HEAP, lsl #32
    // 0xcf3a6c: r3 = LoadClassIdInstr(r0)
    //     0xcf3a6c: ldur            x3, [x0, #-1]
    //     0xcf3a70: ubfx            x3, x3, #0xc, #0x14
    // 0xcf3a74: ldur            x16, [fp, #-0x50]
    // 0xcf3a78: stp             x16, x0, [SP, #-0x10]!
    // 0xcf3a7c: mov             x0, x3
    // 0xcf3a80: r0 = GDT[cid_x0 + -0x1000]()
    //     0xcf3a80: sub             lr, x0, #1, lsl #12
    //     0xcf3a84: ldr             lr, [x21, lr, lsl #3]
    //     0xcf3a88: blr             lr
    // 0xcf3a8c: add             SP, SP, #0x10
    // 0xcf3a90: mov             x1, x0
    // 0xcf3a94: ldr             x0, [fp, #0x18]
    // 0xcf3a98: LoadField: d0 = r0->field_2f
    //     0xcf3a98: ldur            d0, [x0, #0x2f]
    // 0xcf3a9c: d1 = 0.500000
    //     0xcf3a9c: fmov            d1, #0.50000000
    // 0xcf3aa0: fcmp            d0, d1
    // 0xcf3aa4: b.vs            #0xcf3aac
    // 0xcf3aa8: b.lt            #0xcf3ab0
    // 0xcf3aac: ldur            x1, [fp, #-0x30]
    // 0xcf3ab0: stur            x1, [fp, #-0x30]
    // 0xcf3ab4: r16 = Instance__ScaffoldSlot
    //     0xcf3ab4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21dd8] Obj!_ScaffoldSlot@b65291
    //     0xcf3ab8: ldr             x16, [x16, #0xdd8]
    // 0xcf3abc: stp             x16, x0, [SP, #-0x10]!
    // 0xcf3ac0: SaveReg r1
    //     0xcf3ac0: str             x1, [SP, #-8]!
    // 0xcf3ac4: r0 = positionChild()
    //     0xcf3ac4: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3ac8: add             SP, SP, #0x18
    // 0xcf3acc: ldur            x16, [fp, #-0x30]
    // 0xcf3ad0: ldur            lr, [fp, #-0x48]
    // 0xcf3ad4: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3ad8: r0 = &()
    //     0xcf3ad8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xcf3adc: add             SP, SP, #0x10
    // 0xcf3ae0: b               #0xcf3ae8
    // 0xcf3ae4: r0 = Sentinel
    //     0xcf3ae4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcf3ae8: stur            x0, [fp, #-0x30]
    // 0xcf3aec: ldr             x16, [fp, #0x18]
    // 0xcf3af0: r30 = Instance__ScaffoldSlot
    //     0xcf3af0: add             lr, PP, #0x21, lsl #12  ; [pp+0x21db0] Obj!_ScaffoldSlot@b652f1
    //     0xcf3af4: ldr             lr, [lr, #0xdb0]
    // 0xcf3af8: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3afc: r0 = hasChild()
    //     0xcf3afc: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3b00: add             SP, SP, #0x10
    // 0xcf3b04: tbnz            w0, #4, #0xcf3dcc
    // 0xcf3b08: ldr             x0, [fp, #0x18]
    // 0xcf3b0c: LoadField: r1 = r0->field_3f
    //     0xcf3b0c: ldur            w1, [x0, #0x3f]
    // 0xcf3b10: DecompressPointer r1
    //     0xcf3b10: add             x1, x1, HEAP, lsl #32
    // 0xcf3b14: stur            x1, [fp, #-0x40]
    // 0xcf3b18: cmp             w1, NULL
    // 0xcf3b1c: b.eq            #0xcf3b48
    // 0xcf3b20: ldur            d0, [fp, #-0x60]
    // 0xcf3b24: LoadField: d1 = r1->field_7
    //     0xcf3b24: ldur            d1, [x1, #7]
    // 0xcf3b28: fcmp            d1, d0
    // 0xcf3b2c: b.vs            #0xcf3b34
    // 0xcf3b30: b.lt            #0xcf3b3c
    // 0xcf3b34: r2 = false
    //     0xcf3b34: add             x2, NULL, #0x30  ; false
    // 0xcf3b38: b               #0xcf3b40
    // 0xcf3b3c: r2 = true
    //     0xcf3b3c: add             x2, NULL, #0x20  ; true
    // 0xcf3b40: mov             x4, x2
    // 0xcf3b44: b               #0xcf3b50
    // 0xcf3b48: ldur            d0, [fp, #-0x60]
    // 0xcf3b4c: r4 = false
    //     0xcf3b4c: add             x4, NULL, #0x30  ; false
    // 0xcf3b50: ldur            x2, [fp, #-0x28]
    // 0xcf3b54: r3 = Instance_Size
    //     0xcf3b54: ldr             x3, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xcf3b58: stur            x4, [fp, #-0x38]
    // 0xcf3b5c: LoadField: d1 = r3->field_7
    //     0xcf3b5c: ldur            d1, [x3, #7]
    // 0xcf3b60: stur            d1, [fp, #-0x70]
    // 0xcf3b64: LoadField: d2 = r2->field_7
    //     0xcf3b64: ldur            d2, [x2, #7]
    // 0xcf3b68: fcmp            d1, d2
    // 0xcf3b6c: b.vs            #0xcf3bb8
    // 0xcf3b70: b.ne            #0xcf3bb8
    // 0xcf3b74: LoadField: d2 = r3->field_f
    //     0xcf3b74: ldur            d2, [x3, #0xf]
    // 0xcf3b78: LoadField: d3 = r2->field_f
    //     0xcf3b78: ldur            d3, [x2, #0xf]
    // 0xcf3b7c: fcmp            d2, d3
    // 0xcf3b80: b.vs            #0xcf3bb8
    // 0xcf3b84: b.ne            #0xcf3bb8
    // 0xcf3b88: tbnz            w4, #4, #0xcf3b94
    // 0xcf3b8c: ldur            x2, [fp, #-8]
    // 0xcf3b90: b               #0xcf3b98
    // 0xcf3b94: ldur            x2, [fp, #-0x10]
    // 0xcf3b98: r16 = Instance__ScaffoldSlot
    //     0xcf3b98: add             x16, PP, #0x21, lsl #12  ; [pp+0x21db0] Obj!_ScaffoldSlot@b652f1
    //     0xcf3b9c: ldr             x16, [x16, #0xdb0]
    // 0xcf3ba0: stp             x16, x0, [SP, #-0x10]!
    // 0xcf3ba4: SaveReg r2
    //     0xcf3ba4: str             x2, [SP, #-8]!
    // 0xcf3ba8: r0 = layoutChild()
    //     0xcf3ba8: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf3bac: add             SP, SP, #0x18
    // 0xcf3bb0: mov             x1, x0
    // 0xcf3bb4: b               #0xcf3bbc
    // 0xcf3bb8: mov             x1, x2
    // 0xcf3bbc: ldur            x0, [fp, #-0x30]
    // 0xcf3bc0: stur            x1, [fp, #-8]
    // 0xcf3bc4: r16 = Sentinel
    //     0xcf3bc4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcf3bc8: cmp             w0, w16
    // 0xcf3bcc: b.ne            #0xcf3be4
    // 0xcf3bd0: r16 = "floatingActionButtonRect"
    //     0xcf3bd0: add             x16, PP, #0x37, lsl #12  ; [pp+0x37760] "floatingActionButtonRect"
    //     0xcf3bd4: ldr             x16, [x16, #0x760]
    // 0xcf3bd8: SaveReg r16
    //     0xcf3bd8: str             x16, [SP, #-8]!
    // 0xcf3bdc: r0 = _throwLocalNotInitialized()
    //     0xcf3bdc: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xcf3be0: add             SP, SP, #8
    // 0xcf3be4: ldur            d0, [fp, #-0x70]
    // 0xcf3be8: ldur            x16, [fp, #-0x30]
    // 0xcf3bec: SaveReg r16
    //     0xcf3bec: str             x16, [SP, #-8]!
    // 0xcf3bf0: r0 = size()
    //     0xcf3bf0: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0xcf3bf4: add             SP, SP, #8
    // 0xcf3bf8: LoadField: d0 = r0->field_7
    //     0xcf3bf8: ldur            d0, [x0, #7]
    // 0xcf3bfc: ldur            d1, [fp, #-0x70]
    // 0xcf3c00: fcmp            d1, d0
    // 0xcf3c04: b.vs            #0xcf3c28
    // 0xcf3c08: b.ne            #0xcf3c28
    // 0xcf3c0c: r1 = Instance_Size
    //     0xcf3c0c: ldr             x1, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xcf3c10: LoadField: d0 = r1->field_f
    //     0xcf3c10: ldur            d0, [x1, #0xf]
    // 0xcf3c14: LoadField: d1 = r0->field_f
    //     0xcf3c14: ldur            d1, [x0, #0xf]
    // 0xcf3c18: fcmp            d0, d1
    // 0xcf3c1c: b.ne            #0xcf3c28
    // 0xcf3c20: ldur            x0, [fp, #-0x30]
    // 0xcf3c24: b               #0xcf3c6c
    // 0xcf3c28: ldr             x0, [fp, #0x18]
    // 0xcf3c2c: LoadField: r1 = r0->field_3b
    //     0xcf3c2c: ldur            w1, [x0, #0x3b]
    // 0xcf3c30: DecompressPointer r1
    //     0xcf3c30: add             x1, x1, HEAP, lsl #32
    // 0xcf3c34: tbnz            w1, #4, #0xcf3c68
    // 0xcf3c38: ldur            x1, [fp, #-0x30]
    // 0xcf3c3c: r16 = Sentinel
    //     0xcf3c3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcf3c40: cmp             w1, w16
    // 0xcf3c44: b.ne            #0xcf3c5c
    // 0xcf3c48: r16 = "floatingActionButtonRect"
    //     0xcf3c48: add             x16, PP, #0x37, lsl #12  ; [pp+0x37760] "floatingActionButtonRect"
    //     0xcf3c4c: ldr             x16, [x16, #0x760]
    // 0xcf3c50: SaveReg r16
    //     0xcf3c50: str             x16, [SP, #-8]!
    // 0xcf3c54: r0 = _throwLocalNotInitialized()
    //     0xcf3c54: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xcf3c58: add             SP, SP, #8
    // 0xcf3c5c: ldur            x0, [fp, #-0x30]
    // 0xcf3c60: LoadField: d0 = r0->field_f
    //     0xcf3c60: ldur            d0, [x0, #0xf]
    // 0xcf3c64: b               #0xcf3d50
    // 0xcf3c68: ldur            x0, [fp, #-0x30]
    // 0xcf3c6c: ldr             x1, [fp, #0x18]
    // 0xcf3c70: ldur            d0, [fp, #-0x58]
    // 0xcf3c74: LoadField: r2 = r1->field_1b
    //     0xcf3c74: ldur            w2, [x1, #0x1b]
    // 0xcf3c78: DecompressPointer r2
    //     0xcf3c78: add             x2, x2, HEAP, lsl #32
    // 0xcf3c7c: LoadField: d1 = r2->field_1f
    //     0xcf3c7c: ldur            d1, [x2, #0x1f]
    // 0xcf3c80: fsub            d2, d0, d1
    // 0xcf3c84: stur            d2, [fp, #-0x70]
    // 0xcf3c88: LoadField: r2 = r1->field_3b
    //     0xcf3c88: ldur            w2, [x1, #0x3b]
    // 0xcf3c8c: DecompressPointer r2
    //     0xcf3c8c: add             x2, x2, HEAP, lsl #32
    // 0xcf3c90: tbnz            w2, #4, #0xcf3d4c
    // 0xcf3c94: ldur            d1, [fp, #-0x68]
    // 0xcf3c98: fcmp            d1, d2
    // 0xcf3c9c: b.vs            #0xcf3cac
    // 0xcf3ca0: b.le            #0xcf3cac
    // 0xcf3ca4: mov             v0.16b, v2.16b
    // 0xcf3ca8: b               #0xcf3d50
    // 0xcf3cac: fcmp            d1, d2
    // 0xcf3cb0: b.vs            #0xcf3cc0
    // 0xcf3cb4: b.ge            #0xcf3cc0
    // 0xcf3cb8: mov             v0.16b, v1.16b
    // 0xcf3cbc: b               #0xcf3d50
    // 0xcf3cc0: d3 = 0.000000
    //     0xcf3cc0: eor             v3.16b, v3.16b, v3.16b
    // 0xcf3cc4: fcmp            d1, d3
    // 0xcf3cc8: b.vs            #0xcf3cd0
    // 0xcf3ccc: b.eq            #0xcf3cd8
    // 0xcf3cd0: r2 = false
    //     0xcf3cd0: add             x2, NULL, #0x30  ; false
    // 0xcf3cd4: b               #0xcf3cdc
    // 0xcf3cd8: r2 = true
    //     0xcf3cd8: add             x2, NULL, #0x20  ; true
    // 0xcf3cdc: tbnz            w2, #4, #0xcf3cf4
    // 0xcf3ce0: fadd            d3, d1, d2
    // 0xcf3ce4: fmul            d4, d3, d1
    // 0xcf3ce8: fmul            d1, d4, d2
    // 0xcf3cec: mov             v0.16b, v1.16b
    // 0xcf3cf0: b               #0xcf3d50
    // 0xcf3cf4: tbnz            w2, #4, #0xcf3d38
    // 0xcf3cf8: r2 = inline_Allocate_Double()
    //     0xcf3cf8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xcf3cfc: add             x2, x2, #0x10
    //     0xcf3d00: cmp             x3, x2
    //     0xcf3d04: b.ls            #0xcf4008
    //     0xcf3d08: str             x2, [THR, #0x60]  ; THR::top
    //     0xcf3d0c: sub             x2, x2, #0xf
    //     0xcf3d10: mov             x3, #0xd108
    //     0xcf3d14: movk            x3, #3, lsl #16
    //     0xcf3d18: stur            x3, [x2, #-1]
    // 0xcf3d1c: StoreField: r2->field_7 = d2
    //     0xcf3d1c: stur            d2, [x2, #7]
    // 0xcf3d20: SaveReg r2
    //     0xcf3d20: str             x2, [SP, #-8]!
    // 0xcf3d24: r0 = isNegative()
    //     0xcf3d24: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xcf3d28: add             SP, SP, #8
    // 0xcf3d2c: tbnz            w0, #4, #0xcf3d38
    // 0xcf3d30: ldur            d0, [fp, #-0x70]
    // 0xcf3d34: b               #0xcf3d50
    // 0xcf3d38: ldur            d0, [fp, #-0x70]
    // 0xcf3d3c: fcmp            d0, d0
    // 0xcf3d40: b.vs            #0xcf3d50
    // 0xcf3d44: ldur            d0, [fp, #-0x68]
    // 0xcf3d48: b               #0xcf3d50
    // 0xcf3d4c: ldur            d0, [fp, #-0x68]
    // 0xcf3d50: ldur            x0, [fp, #-0x38]
    // 0xcf3d54: tbnz            w0, #4, #0xcf3d80
    // 0xcf3d58: ldur            x0, [fp, #-0x40]
    // 0xcf3d5c: ldur            d1, [fp, #-0x60]
    // 0xcf3d60: d2 = 2.000000
    //     0xcf3d60: fmov            d2, #2.00000000
    // 0xcf3d64: cmp             w0, NULL
    // 0xcf3d68: b.eq            #0xcf402c
    // 0xcf3d6c: LoadField: d3 = r0->field_7
    //     0xcf3d6c: ldur            d3, [x0, #7]
    // 0xcf3d70: fsub            d4, d1, d3
    // 0xcf3d74: fdiv            d3, d4, d2
    // 0xcf3d78: mov             v2.16b, v3.16b
    // 0xcf3d7c: b               #0xcf3d88
    // 0xcf3d80: ldur            d1, [fp, #-0x60]
    // 0xcf3d84: d2 = 0.000000
    //     0xcf3d84: eor             v2.16b, v2.16b, v2.16b
    // 0xcf3d88: ldur            x0, [fp, #-8]
    // 0xcf3d8c: stur            d2, [fp, #-0x70]
    // 0xcf3d90: LoadField: d3 = r0->field_f
    //     0xcf3d90: ldur            d3, [x0, #0xf]
    // 0xcf3d94: fsub            d4, d0, d3
    // 0xcf3d98: stur            d4, [fp, #-0x68]
    // 0xcf3d9c: r0 = Offset()
    //     0xcf3d9c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcf3da0: ldur            d0, [fp, #-0x70]
    // 0xcf3da4: StoreField: r0->field_7 = d0
    //     0xcf3da4: stur            d0, [x0, #7]
    // 0xcf3da8: ldur            d0, [fp, #-0x68]
    // 0xcf3dac: StoreField: r0->field_f = d0
    //     0xcf3dac: stur            d0, [x0, #0xf]
    // 0xcf3db0: ldr             x16, [fp, #0x18]
    // 0xcf3db4: r30 = Instance__ScaffoldSlot
    //     0xcf3db4: add             lr, PP, #0x21, lsl #12  ; [pp+0x21db0] Obj!_ScaffoldSlot@b652f1
    //     0xcf3db8: ldr             lr, [lr, #0xdb0]
    // 0xcf3dbc: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3dc0: SaveReg r0
    //     0xcf3dc0: str             x0, [SP, #-8]!
    // 0xcf3dc4: r0 = positionChild()
    //     0xcf3dc4: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3dc8: add             SP, SP, #0x18
    // 0xcf3dcc: ldr             x16, [fp, #0x18]
    // 0xcf3dd0: r30 = Instance__ScaffoldSlot
    //     0xcf3dd0: add             lr, PP, #0x21, lsl #12  ; [pp+0x21df0] Obj!_ScaffoldSlot@b65271
    //     0xcf3dd4: ldr             lr, [lr, #0xdf0]
    // 0xcf3dd8: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3ddc: r0 = hasChild()
    //     0xcf3ddc: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3de0: add             SP, SP, #0x10
    // 0xcf3de4: tbnz            w0, #4, #0xcf3e6c
    // 0xcf3de8: ldur            x0, [fp, #-0x20]
    // 0xcf3dec: LoadField: d0 = r0->field_f
    //     0xcf3dec: ldur            d0, [x0, #0xf]
    // 0xcf3df0: r0 = inline_Allocate_Double()
    //     0xcf3df0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcf3df4: add             x0, x0, #0x10
    //     0xcf3df8: cmp             x1, x0
    //     0xcf3dfc: b.ls            #0xcf4030
    //     0xcf3e00: str             x0, [THR, #0x60]  ; THR::top
    //     0xcf3e04: sub             x0, x0, #0xf
    //     0xcf3e08: mov             x1, #0xd108
    //     0xcf3e0c: movk            x1, #3, lsl #16
    //     0xcf3e10: stur            x1, [x0, #-1]
    // 0xcf3e14: StoreField: r0->field_7 = d0
    //     0xcf3e14: stur            d0, [x0, #7]
    // 0xcf3e18: ldur            x16, [fp, #-0x10]
    // 0xcf3e1c: stp             x0, x16, [SP, #-0x10]!
    // 0xcf3e20: r4 = const [0, 0x2, 0x2, 0x1, height, 0x1, null]
    //     0xcf3e20: add             x4, PP, #0x21, lsl #12  ; [pp+0x21620] List(7) [0, 0x2, 0x2, 0x1, "height", 0x1, Null]
    //     0xcf3e24: ldr             x4, [x4, #0x620]
    // 0xcf3e28: r0 = tighten()
    //     0xcf3e28: bl              #0x590b84  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0xcf3e2c: add             SP, SP, #0x10
    // 0xcf3e30: ldr             x16, [fp, #0x18]
    // 0xcf3e34: r30 = Instance__ScaffoldSlot
    //     0xcf3e34: add             lr, PP, #0x21, lsl #12  ; [pp+0x21df0] Obj!_ScaffoldSlot@b65271
    //     0xcf3e38: ldr             lr, [lr, #0xdf0]
    // 0xcf3e3c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3e40: SaveReg r0
    //     0xcf3e40: str             x0, [SP, #-8]!
    // 0xcf3e44: r0 = layoutChild()
    //     0xcf3e44: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf3e48: add             SP, SP, #0x18
    // 0xcf3e4c: ldr             x16, [fp, #0x18]
    // 0xcf3e50: r30 = Instance__ScaffoldSlot
    //     0xcf3e50: add             lr, PP, #0x21, lsl #12  ; [pp+0x21df0] Obj!_ScaffoldSlot@b65271
    //     0xcf3e54: ldr             lr, [lr, #0xdf0]
    // 0xcf3e58: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3e5c: r16 = Instance_Offset
    //     0xcf3e5c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcf3e60: SaveReg r16
    //     0xcf3e60: str             x16, [SP, #-8]!
    // 0xcf3e64: r0 = positionChild()
    //     0xcf3e64: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3e68: add             SP, SP, #0x18
    // 0xcf3e6c: ldr             x16, [fp, #0x18]
    // 0xcf3e70: r30 = Instance__ScaffoldSlot
    //     0xcf3e70: add             lr, PP, #0x37, lsl #12  ; [pp+0x37768] Obj!_ScaffoldSlot@b653b1
    //     0xcf3e74: ldr             lr, [lr, #0x768]
    // 0xcf3e78: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3e7c: r0 = hasChild()
    //     0xcf3e7c: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3e80: add             SP, SP, #0x10
    // 0xcf3e84: tbnz            w0, #4, #0xcf3ee8
    // 0xcf3e88: ldur            d0, [fp, #-0x60]
    // 0xcf3e8c: ldur            d1, [fp, #-0x58]
    // 0xcf3e90: r0 = BoxConstraints()
    //     0xcf3e90: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xcf3e94: ldur            d0, [fp, #-0x60]
    // 0xcf3e98: StoreField: r0->field_7 = d0
    //     0xcf3e98: stur            d0, [x0, #7]
    // 0xcf3e9c: StoreField: r0->field_f = d0
    //     0xcf3e9c: stur            d0, [x0, #0xf]
    // 0xcf3ea0: ldur            d1, [fp, #-0x58]
    // 0xcf3ea4: StoreField: r0->field_17 = d1
    //     0xcf3ea4: stur            d1, [x0, #0x17]
    // 0xcf3ea8: StoreField: r0->field_1f = d1
    //     0xcf3ea8: stur            d1, [x0, #0x1f]
    // 0xcf3eac: ldr             x16, [fp, #0x18]
    // 0xcf3eb0: r30 = Instance__ScaffoldSlot
    //     0xcf3eb0: add             lr, PP, #0x37, lsl #12  ; [pp+0x37768] Obj!_ScaffoldSlot@b653b1
    //     0xcf3eb4: ldr             lr, [lr, #0x768]
    // 0xcf3eb8: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3ebc: SaveReg r0
    //     0xcf3ebc: str             x0, [SP, #-8]!
    // 0xcf3ec0: r0 = layoutChild()
    //     0xcf3ec0: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf3ec4: add             SP, SP, #0x18
    // 0xcf3ec8: ldr             x16, [fp, #0x18]
    // 0xcf3ecc: r30 = Instance__ScaffoldSlot
    //     0xcf3ecc: add             lr, PP, #0x37, lsl #12  ; [pp+0x37768] Obj!_ScaffoldSlot@b653b1
    //     0xcf3ed0: ldr             lr, [lr, #0x768]
    // 0xcf3ed4: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3ed8: r16 = Instance_Offset
    //     0xcf3ed8: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcf3edc: SaveReg r16
    //     0xcf3edc: str             x16, [SP, #-8]!
    // 0xcf3ee0: r0 = positionChild()
    //     0xcf3ee0: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3ee4: add             SP, SP, #0x18
    // 0xcf3ee8: ldr             x16, [fp, #0x18]
    // 0xcf3eec: r30 = Instance__ScaffoldSlot
    //     0xcf3eec: add             lr, PP, #0x37, lsl #12  ; [pp+0x37770] Obj!_ScaffoldSlot@b65391
    //     0xcf3ef0: ldr             lr, [lr, #0x770]
    // 0xcf3ef4: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3ef8: r0 = hasChild()
    //     0xcf3ef8: bl              #0xcf4220  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0xcf3efc: add             SP, SP, #0x10
    // 0xcf3f00: tbnz            w0, #4, #0xcf3f64
    // 0xcf3f04: ldur            d0, [fp, #-0x60]
    // 0xcf3f08: ldur            d1, [fp, #-0x58]
    // 0xcf3f0c: r0 = BoxConstraints()
    //     0xcf3f0c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xcf3f10: ldur            d0, [fp, #-0x60]
    // 0xcf3f14: StoreField: r0->field_7 = d0
    //     0xcf3f14: stur            d0, [x0, #7]
    // 0xcf3f18: StoreField: r0->field_f = d0
    //     0xcf3f18: stur            d0, [x0, #0xf]
    // 0xcf3f1c: ldur            d0, [fp, #-0x58]
    // 0xcf3f20: StoreField: r0->field_17 = d0
    //     0xcf3f20: stur            d0, [x0, #0x17]
    // 0xcf3f24: StoreField: r0->field_1f = d0
    //     0xcf3f24: stur            d0, [x0, #0x1f]
    // 0xcf3f28: ldr             x16, [fp, #0x18]
    // 0xcf3f2c: r30 = Instance__ScaffoldSlot
    //     0xcf3f2c: add             lr, PP, #0x37, lsl #12  ; [pp+0x37770] Obj!_ScaffoldSlot@b65391
    //     0xcf3f30: ldr             lr, [lr, #0x770]
    // 0xcf3f34: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3f38: SaveReg r0
    //     0xcf3f38: str             x0, [SP, #-8]!
    // 0xcf3f3c: r0 = layoutChild()
    //     0xcf3f3c: bl              #0xcf4150  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0xcf3f40: add             SP, SP, #0x18
    // 0xcf3f44: ldr             x16, [fp, #0x18]
    // 0xcf3f48: r30 = Instance__ScaffoldSlot
    //     0xcf3f48: add             lr, PP, #0x37, lsl #12  ; [pp+0x37770] Obj!_ScaffoldSlot@b65391
    //     0xcf3f4c: ldr             lr, [lr, #0x770]
    // 0xcf3f50: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3f54: r16 = Instance_Offset
    //     0xcf3f54: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcf3f58: SaveReg r16
    //     0xcf3f58: str             x16, [SP, #-8]!
    // 0xcf3f5c: r0 = positionChild()
    //     0xcf3f5c: bl              #0xcf4058  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0xcf3f60: add             SP, SP, #0x18
    // 0xcf3f64: ldr             x1, [fp, #0x18]
    // 0xcf3f68: ldur            x0, [fp, #-0x30]
    // 0xcf3f6c: LoadField: r2 = r1->field_23
    //     0xcf3f6c: ldur            w2, [x1, #0x23]
    // 0xcf3f70: DecompressPointer r2
    //     0xcf3f70: add             x2, x2, HEAP, lsl #32
    // 0xcf3f74: stur            x2, [fp, #-8]
    // 0xcf3f78: r16 = Sentinel
    //     0xcf3f78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcf3f7c: cmp             w0, w16
    // 0xcf3f80: b.ne            #0xcf3f98
    // 0xcf3f84: r16 = "floatingActionButtonRect"
    //     0xcf3f84: add             x16, PP, #0x37, lsl #12  ; [pp+0x37760] "floatingActionButtonRect"
    //     0xcf3f88: ldr             x16, [x16, #0x760]
    // 0xcf3f8c: SaveReg r16
    //     0xcf3f8c: str             x16, [SP, #-8]!
    // 0xcf3f90: r0 = _throwLocalNotInitialized()
    //     0xcf3f90: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xcf3f94: add             SP, SP, #8
    // 0xcf3f98: ldur            x16, [fp, #-8]
    // 0xcf3f9c: ldur            lr, [fp, #-0x18]
    // 0xcf3fa0: stp             lr, x16, [SP, #-0x10]!
    // 0xcf3fa4: ldur            x16, [fp, #-0x30]
    // 0xcf3fa8: SaveReg r16
    //     0xcf3fa8: str             x16, [SP, #-8]!
    // 0xcf3fac: r4 = const [0, 0x3, 0x3, 0x1, bottomNavigationBarTop, 0x1, floatingActionButtonArea, 0x2, null]
    //     0xcf3fac: add             x4, PP, #0x37, lsl #12  ; [pp+0x37778] List(9) [0, 0x3, 0x3, 0x1, "bottomNavigationBarTop", 0x1, "floatingActionButtonArea", 0x2, Null]
    //     0xcf3fb0: ldr             x4, [x4, #0x778]
    // 0xcf3fb4: r0 = _updateWith()
    //     0xcf3fb4: bl              #0x7ba400  ; [package:flutter/src/material/scaffold.dart] _ScaffoldGeometryNotifier::_updateWith
    // 0xcf3fb8: add             SP, SP, #0x18
    // 0xcf3fbc: r0 = Null
    //     0xcf3fbc: mov             x0, NULL
    // 0xcf3fc0: LeaveFrame
    //     0xcf3fc0: mov             SP, fp
    //     0xcf3fc4: ldp             fp, lr, [SP], #0x10
    // 0xcf3fc8: ret
    //     0xcf3fc8: ret             
    // 0xcf3fcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf3fcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf3fd0: b               #0xcf30f4
    // 0xcf3fd4: stp             q1, q2, [SP, #-0x20]!
    // 0xcf3fd8: SaveReg d0
    //     0xcf3fd8: str             q0, [SP, #-0x10]!
    // 0xcf3fdc: stp             x0, x1, [SP, #-0x10]!
    // 0xcf3fe0: r0 = AllocateDouble()
    //     0xcf3fe0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf3fe4: mov             x2, x0
    // 0xcf3fe8: ldp             x0, x1, [SP], #0x10
    // 0xcf3fec: RestoreReg d0
    //     0xcf3fec: ldr             q0, [SP], #0x10
    // 0xcf3ff0: ldp             q1, q2, [SP], #0x20
    // 0xcf3ff4: b               #0xcf3148
    // 0xcf3ff8: SaveReg d0
    //     0xcf3ff8: str             q0, [SP, #-0x10]!
    // 0xcf3ffc: r0 = AllocateDouble()
    //     0xcf3ffc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf4000: RestoreReg d0
    //     0xcf4000: ldr             q0, [SP], #0x10
    // 0xcf4004: b               #0xcf32dc
    // 0xcf4008: stp             q1, q2, [SP, #-0x20]!
    // 0xcf400c: SaveReg d0
    //     0xcf400c: str             q0, [SP, #-0x10]!
    // 0xcf4010: stp             x0, x1, [SP, #-0x10]!
    // 0xcf4014: r0 = AllocateDouble()
    //     0xcf4014: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf4018: mov             x2, x0
    // 0xcf401c: ldp             x0, x1, [SP], #0x10
    // 0xcf4020: RestoreReg d0
    //     0xcf4020: ldr             q0, [SP], #0x10
    // 0xcf4024: ldp             q1, q2, [SP], #0x20
    // 0xcf4028: b               #0xcf3d1c
    // 0xcf402c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcf402c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcf4030: SaveReg d0
    //     0xcf4030: str             q0, [SP, #-0x10]!
    // 0xcf4034: r0 = AllocateDouble()
    //     0xcf4034: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcf4038: RestoreReg d0
    //     0xcf4038: ldr             q0, [SP], #0x10
    // 0xcf403c: b               #0xcf3e14
  }
}

// class id: 2154, size: 0x10, field offset: 0x8
//   const constructor, 
class ScaffoldGeometry extends Object {

  _ copyWith(/* No info */) {
    // ** addr: 0x7ba5a8, size: 0x70
    // 0x7ba5a8: EnterFrame
    //     0x7ba5a8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba5ac: mov             fp, SP
    // 0x7ba5b0: AllocStack(0x10)
    //     0x7ba5b0: sub             SP, SP, #0x10
    // 0x7ba5b4: ldr             x0, [fp, #0x18]
    // 0x7ba5b8: cmp             w0, NULL
    // 0x7ba5bc: b.ne            #0x7ba5d4
    // 0x7ba5c0: ldr             x1, [fp, #0x20]
    // 0x7ba5c4: LoadField: r0 = r1->field_7
    //     0x7ba5c4: ldur            w0, [x1, #7]
    // 0x7ba5c8: DecompressPointer r0
    //     0x7ba5c8: add             x0, x0, HEAP, lsl #32
    // 0x7ba5cc: mov             x2, x0
    // 0x7ba5d0: b               #0x7ba5dc
    // 0x7ba5d4: ldr             x1, [fp, #0x20]
    // 0x7ba5d8: mov             x2, x0
    // 0x7ba5dc: ldr             x0, [fp, #0x10]
    // 0x7ba5e0: stur            x2, [fp, #-0x10]
    // 0x7ba5e4: cmp             w0, NULL
    // 0x7ba5e8: b.ne            #0x7ba5f4
    // 0x7ba5ec: LoadField: r0 = r1->field_b
    //     0x7ba5ec: ldur            w0, [x1, #0xb]
    // 0x7ba5f0: DecompressPointer r0
    //     0x7ba5f0: add             x0, x0, HEAP, lsl #32
    // 0x7ba5f4: stur            x0, [fp, #-8]
    // 0x7ba5f8: r0 = ScaffoldGeometry()
    //     0x7ba5f8: bl              #0x7ba618  ; AllocateScaffoldGeometryStub -> ScaffoldGeometry (size=0x10)
    // 0x7ba5fc: ldur            x1, [fp, #-0x10]
    // 0x7ba600: StoreField: r0->field_7 = r1
    //     0x7ba600: stur            w1, [x0, #7]
    // 0x7ba604: ldur            x1, [fp, #-8]
    // 0x7ba608: StoreField: r0->field_b = r1
    //     0x7ba608: stur            w1, [x0, #0xb]
    // 0x7ba60c: LeaveFrame
    //     0x7ba60c: mov             SP, fp
    //     0x7ba610: ldp             fp, lr, [SP], #0x10
    // 0x7ba614: ret
    //     0x7ba614: ret             
  }
}

// class id: 2155, size: 0x2c, field offset: 0x8
//   const constructor, 
class ScaffoldPrelayoutGeometry extends Object {
}

// class id: 2916, size: 0x18, field offset: 0x14
class _DismissDrawerAction extends DismissAction {

  _ isEnabled(/* No info */) {
    // ** addr: 0xbdf578, size: 0x144
    // 0xbdf578: EnterFrame
    //     0xbdf578: stp             fp, lr, [SP, #-0x10]!
    //     0xbdf57c: mov             fp, SP
    // 0xbdf580: AllocStack(0x10)
    //     0xbdf580: sub             SP, SP, #0x10
    // 0xbdf584: CheckStackOverflow
    //     0xbdf584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdf588: cmp             SP, x16
    //     0xbdf58c: b.ls            #0xbdf6b4
    // 0xbdf590: ldr             x0, [fp, #0x10]
    // 0xbdf594: r2 = Null
    //     0xbdf594: mov             x2, NULL
    // 0xbdf598: r1 = Null
    //     0xbdf598: mov             x1, NULL
    // 0xbdf59c: r4 = 59
    //     0xbdf59c: mov             x4, #0x3b
    // 0xbdf5a0: branchIfSmi(r0, 0xbdf5ac)
    //     0xbdf5a0: tbz             w0, #0, #0xbdf5ac
    // 0xbdf5a4: r4 = LoadClassIdInstr(r0)
    //     0xbdf5a4: ldur            x4, [x0, #-1]
    //     0xbdf5a8: ubfx            x4, x4, #0xc, #0x14
    // 0xbdf5ac: cmp             x4, #0xaca
    // 0xbdf5b0: b.eq            #0xbdf5c8
    // 0xbdf5b4: r8 = DismissIntent
    //     0xbdf5b4: add             x8, PP, #0x21, lsl #12  ; [pp+0x21e30] Type: DismissIntent
    //     0xbdf5b8: ldr             x8, [x8, #0xe30]
    // 0xbdf5bc: r3 = Null
    //     0xbdf5bc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ffc8] Null
    //     0xbdf5c0: ldr             x3, [x3, #0xfc8]
    // 0xbdf5c4: r0 = DismissIntent()
    //     0xbdf5c4: bl              #0x866648  ; IsType_DismissIntent_Stub
    // 0xbdf5c8: ldr             x0, [fp, #0x18]
    // 0xbdf5cc: LoadField: r1 = r0->field_13
    //     0xbdf5cc: ldur            w1, [x0, #0x13]
    // 0xbdf5d0: DecompressPointer r1
    //     0xbdf5d0: add             x1, x1, HEAP, lsl #32
    // 0xbdf5d4: stur            x1, [fp, #-8]
    // 0xbdf5d8: SaveReg r1
    //     0xbdf5d8: str             x1, [SP, #-8]!
    // 0xbdf5dc: r0 = of()
    //     0xbdf5dc: bl              #0x848d60  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xbdf5e0: add             SP, SP, #8
    // 0xbdf5e4: LoadField: r1 = r0->field_3b
    //     0xbdf5e4: ldur            w1, [x0, #0x3b]
    // 0xbdf5e8: DecompressPointer r1
    //     0xbdf5e8: add             x1, x1, HEAP, lsl #32
    // 0xbdf5ec: LoadField: r3 = r1->field_33
    //     0xbdf5ec: ldur            w3, [x1, #0x33]
    // 0xbdf5f0: DecompressPointer r3
    //     0xbdf5f0: add             x3, x3, HEAP, lsl #32
    // 0xbdf5f4: stur            x3, [fp, #-0x10]
    // 0xbdf5f8: cmp             w3, NULL
    // 0xbdf5fc: b.ne            #0xbdf634
    // 0xbdf600: LoadField: r2 = r1->field_23
    //     0xbdf600: ldur            w2, [x1, #0x23]
    // 0xbdf604: DecompressPointer r2
    //     0xbdf604: add             x2, x2, HEAP, lsl #32
    // 0xbdf608: mov             x0, x3
    // 0xbdf60c: r1 = Null
    //     0xbdf60c: mov             x1, NULL
    // 0xbdf610: cmp             w2, NULL
    // 0xbdf614: b.eq            #0xbdf634
    // 0xbdf618: LoadField: r4 = r2->field_17
    //     0xbdf618: ldur            w4, [x2, #0x17]
    // 0xbdf61c: DecompressPointer r4
    //     0xbdf61c: add             x4, x4, HEAP, lsl #32
    // 0xbdf620: r8 = X0
    //     0xbdf620: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbdf624: LoadField: r9 = r4->field_7
    //     0xbdf624: ldur            x9, [x4, #7]
    // 0xbdf628: r3 = Null
    //     0xbdf628: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ffd8] Null
    //     0xbdf62c: ldr             x3, [x3, #0xfd8]
    // 0xbdf630: blr             x9
    // 0xbdf634: ldur            x0, [fp, #-0x10]
    // 0xbdf638: tbnz            w0, #4, #0xbdf644
    // 0xbdf63c: r0 = true
    //     0xbdf63c: add             x0, NULL, #0x20  ; true
    // 0xbdf640: b               #0xbdf6a8
    // 0xbdf644: ldur            x16, [fp, #-8]
    // 0xbdf648: SaveReg r16
    //     0xbdf648: str             x16, [SP, #-8]!
    // 0xbdf64c: r0 = of()
    //     0xbdf64c: bl              #0x848d60  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xbdf650: add             SP, SP, #8
    // 0xbdf654: LoadField: r1 = r0->field_3f
    //     0xbdf654: ldur            w1, [x0, #0x3f]
    // 0xbdf658: DecompressPointer r1
    //     0xbdf658: add             x1, x1, HEAP, lsl #32
    // 0xbdf65c: LoadField: r3 = r1->field_33
    //     0xbdf65c: ldur            w3, [x1, #0x33]
    // 0xbdf660: DecompressPointer r3
    //     0xbdf660: add             x3, x3, HEAP, lsl #32
    // 0xbdf664: stur            x3, [fp, #-8]
    // 0xbdf668: cmp             w3, NULL
    // 0xbdf66c: b.ne            #0xbdf6a4
    // 0xbdf670: LoadField: r2 = r1->field_23
    //     0xbdf670: ldur            w2, [x1, #0x23]
    // 0xbdf674: DecompressPointer r2
    //     0xbdf674: add             x2, x2, HEAP, lsl #32
    // 0xbdf678: mov             x0, x3
    // 0xbdf67c: r1 = Null
    //     0xbdf67c: mov             x1, NULL
    // 0xbdf680: cmp             w2, NULL
    // 0xbdf684: b.eq            #0xbdf6a4
    // 0xbdf688: LoadField: r4 = r2->field_17
    //     0xbdf688: ldur            w4, [x2, #0x17]
    // 0xbdf68c: DecompressPointer r4
    //     0xbdf68c: add             x4, x4, HEAP, lsl #32
    // 0xbdf690: r8 = X0
    //     0xbdf690: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xbdf694: LoadField: r9 = r4->field_7
    //     0xbdf694: ldur            x9, [x4, #7]
    // 0xbdf698: r3 = Null
    //     0xbdf698: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ffe8] Null
    //     0xbdf69c: ldr             x3, [x3, #0xfe8]
    // 0xbdf6a0: blr             x9
    // 0xbdf6a4: ldur            x0, [fp, #-8]
    // 0xbdf6a8: LeaveFrame
    //     0xbdf6a8: mov             SP, fp
    //     0xbdf6ac: ldp             fp, lr, [SP], #0x10
    // 0xbdf6b0: ret
    //     0xbdf6b0: ret             
    // 0xbdf6b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdf6b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdf6b8: b               #0xbdf590
  }
  _ invoke(/* No info */) {
    // ** addr: 0xcc3b78, size: 0xac
    // 0xcc3b78: EnterFrame
    //     0xcc3b78: stp             fp, lr, [SP, #-0x10]!
    //     0xcc3b7c: mov             fp, SP
    // 0xcc3b80: AllocStack(0x8)
    //     0xcc3b80: sub             SP, SP, #8
    // 0xcc3b84: CheckStackOverflow
    //     0xcc3b84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcc3b88: cmp             SP, x16
    //     0xcc3b8c: b.ls            #0xcc3c1c
    // 0xcc3b90: ldr             x0, [fp, #0x10]
    // 0xcc3b94: r2 = Null
    //     0xcc3b94: mov             x2, NULL
    // 0xcc3b98: r1 = Null
    //     0xcc3b98: mov             x1, NULL
    // 0xcc3b9c: r4 = 59
    //     0xcc3b9c: mov             x4, #0x3b
    // 0xcc3ba0: branchIfSmi(r0, 0xcc3bac)
    //     0xcc3ba0: tbz             w0, #0, #0xcc3bac
    // 0xcc3ba4: r4 = LoadClassIdInstr(r0)
    //     0xcc3ba4: ldur            x4, [x0, #-1]
    //     0xcc3ba8: ubfx            x4, x4, #0xc, #0x14
    // 0xcc3bac: cmp             x4, #0xaca
    // 0xcc3bb0: b.eq            #0xcc3bc8
    // 0xcc3bb4: r8 = DismissIntent
    //     0xcc3bb4: add             x8, PP, #0x21, lsl #12  ; [pp+0x21e30] Type: DismissIntent
    //     0xcc3bb8: ldr             x8, [x8, #0xe30]
    // 0xcc3bbc: r3 = Null
    //     0xcc3bbc: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ffb8] Null
    //     0xcc3bc0: ldr             x3, [x3, #0xfb8]
    // 0xcc3bc4: r0 = DismissIntent()
    //     0xcc3bc4: bl              #0x866648  ; IsType_DismissIntent_Stub
    // 0xcc3bc8: ldr             x0, [fp, #0x18]
    // 0xcc3bcc: LoadField: r1 = r0->field_13
    //     0xcc3bcc: ldur            w1, [x0, #0x13]
    // 0xcc3bd0: DecompressPointer r1
    //     0xcc3bd0: add             x1, x1, HEAP, lsl #32
    // 0xcc3bd4: stur            x1, [fp, #-8]
    // 0xcc3bd8: SaveReg r1
    //     0xcc3bd8: str             x1, [SP, #-8]!
    // 0xcc3bdc: r0 = of()
    //     0xcc3bdc: bl              #0x848d60  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xcc3be0: add             SP, SP, #8
    // 0xcc3be4: SaveReg r0
    //     0xcc3be4: str             x0, [SP, #-8]!
    // 0xcc3be8: r0 = didChangeDependencies()
    //     0xcc3be8: bl              #0xa64624  ; [package:flutter/src/widgets/selection_container.dart] _SelectionContainerState::didChangeDependencies
    // 0xcc3bec: add             SP, SP, #8
    // 0xcc3bf0: ldur            x16, [fp, #-8]
    // 0xcc3bf4: SaveReg r16
    //     0xcc3bf4: str             x16, [SP, #-8]!
    // 0xcc3bf8: r0 = of()
    //     0xcc3bf8: bl              #0x848d60  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xcc3bfc: add             SP, SP, #8
    // 0xcc3c00: SaveReg r0
    //     0xcc3c00: str             x0, [SP, #-8]!
    // 0xcc3c04: r0 = didChangeDependencies()
    //     0xcc3c04: bl              #0xa64624  ; [package:flutter/src/widgets/selection_container.dart] _SelectionContainerState::didChangeDependencies
    // 0xcc3c08: add             SP, SP, #8
    // 0xcc3c0c: r0 = Null
    //     0xcc3c0c: mov             x0, NULL
    // 0xcc3c10: LeaveFrame
    //     0xcc3c10: mov             SP, fp
    //     0xcc3c14: ldp             fp, lr, [SP], #0x10
    // 0xcc3c18: ret
    //     0xcc3c18: ret             
    // 0xcc3c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcc3c1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcc3c20: b               #0xcc3b90
  }
}

// class id: 3278, size: 0x18, field offset: 0x14
class _StandardBottomSheetState extends State<_StandardBottomSheet> {

  _ close(/* No info */) {
    // ** addr: 0x7bb2c0, size: 0x9c
    // 0x7bb2c0: EnterFrame
    //     0x7bb2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x7bb2c4: mov             fp, SP
    // 0x7bb2c8: CheckStackOverflow
    //     0x7bb2c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bb2cc: cmp             SP, x16
    //     0x7bb2d0: b.ls            #0x7bb348
    // 0x7bb2d4: ldr             x0, [fp, #0x10]
    // 0x7bb2d8: LoadField: r1 = r0->field_b
    //     0x7bb2d8: ldur            w1, [x0, #0xb]
    // 0x7bb2dc: DecompressPointer r1
    //     0x7bb2dc: add             x1, x1, HEAP, lsl #32
    // 0x7bb2e0: cmp             w1, NULL
    // 0x7bb2e4: b.eq            #0x7bb350
    // 0x7bb2e8: LoadField: r2 = r1->field_b
    //     0x7bb2e8: ldur            w2, [x1, #0xb]
    // 0x7bb2ec: DecompressPointer r2
    //     0x7bb2ec: add             x2, x2, HEAP, lsl #32
    // 0x7bb2f0: SaveReg r2
    //     0x7bb2f0: str             x2, [SP, #-8]!
    // 0x7bb2f4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7bb2f4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7bb2f8: r0 = reverse()
    //     0x7bb2f8: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x7bb2fc: add             SP, SP, #8
    // 0x7bb300: ldr             x0, [fp, #0x10]
    // 0x7bb304: LoadField: r1 = r0->field_b
    //     0x7bb304: ldur            w1, [x0, #0xb]
    // 0x7bb308: DecompressPointer r1
    //     0x7bb308: add             x1, x1, HEAP, lsl #32
    // 0x7bb30c: cmp             w1, NULL
    // 0x7bb310: b.eq            #0x7bb354
    // 0x7bb314: LoadField: r0 = r1->field_13
    //     0x7bb314: ldur            w0, [x1, #0x13]
    // 0x7bb318: DecompressPointer r0
    //     0x7bb318: add             x0, x0, HEAP, lsl #32
    // 0x7bb31c: cmp             w0, NULL
    // 0x7bb320: b.eq            #0x7bb358
    // 0x7bb324: SaveReg r0
    //     0x7bb324: str             x0, [SP, #-8]!
    // 0x7bb328: ClosureCall
    //     0x7bb328: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x7bb32c: ldur            x2, [x0, #0x1f]
    //     0x7bb330: blr             x2
    // 0x7bb334: add             SP, SP, #8
    // 0x7bb338: r0 = Null
    //     0x7bb338: mov             x0, NULL
    // 0x7bb33c: LeaveFrame
    //     0x7bb33c: mov             SP, fp
    //     0x7bb340: ldp             fp, lr, [SP], #0x10
    // 0x7bb344: ret
    //     0x7bb344: ret             
    // 0x7bb348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bb348: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bb34c: b               #0x7bb2d4
    // 0x7bb350: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bb350: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bb354: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bb354: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bb358: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7bb358: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bbc6c, size: 0x90
    // 0x7bbc6c: EnterFrame
    //     0x7bbc6c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bbc70: mov             fp, SP
    // 0x7bbc74: ldr             x0, [fp, #0x10]
    // 0x7bbc78: r2 = Null
    //     0x7bbc78: mov             x2, NULL
    // 0x7bbc7c: r1 = Null
    //     0x7bbc7c: mov             x1, NULL
    // 0x7bbc80: r4 = 59
    //     0x7bbc80: mov             x4, #0x3b
    // 0x7bbc84: branchIfSmi(r0, 0x7bbc90)
    //     0x7bbc84: tbz             w0, #0, #0x7bbc90
    // 0x7bbc88: r4 = LoadClassIdInstr(r0)
    //     0x7bbc88: ldur            x4, [x0, #-1]
    //     0x7bbc8c: ubfx            x4, x4, #0xc, #0x14
    // 0x7bbc90: r17 = 4123
    //     0x7bbc90: mov             x17, #0x101b
    // 0x7bbc94: cmp             x4, x17
    // 0x7bbc98: b.eq            #0x7bbcb0
    // 0x7bbc9c: r8 = _StandardBottomSheet
    //     0x7bbc9c: add             x8, PP, #0x21, lsl #12  ; [pp+0x21ee0] Type: _StandardBottomSheet
    //     0x7bbca0: ldr             x8, [x8, #0xee0]
    // 0x7bbca4: r3 = Null
    //     0x7bbca4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e170] Null
    //     0x7bbca8: ldr             x3, [x3, #0x170]
    // 0x7bbcac: r0 = _StandardBottomSheet()
    //     0x7bbcac: bl              #0x7bbab8  ; IsType__StandardBottomSheet_Stub
    // 0x7bbcb0: ldr             x0, [fp, #0x18]
    // 0x7bbcb4: LoadField: r2 = r0->field_7
    //     0x7bbcb4: ldur            w2, [x0, #7]
    // 0x7bbcb8: DecompressPointer r2
    //     0x7bbcb8: add             x2, x2, HEAP, lsl #32
    // 0x7bbcbc: ldr             x0, [fp, #0x10]
    // 0x7bbcc0: r1 = Null
    //     0x7bbcc0: mov             x1, NULL
    // 0x7bbcc4: cmp             w2, NULL
    // 0x7bbcc8: b.eq            #0x7bbcec
    // 0x7bbccc: LoadField: r4 = r2->field_17
    //     0x7bbccc: ldur            w4, [x2, #0x17]
    // 0x7bbcd0: DecompressPointer r4
    //     0x7bbcd0: add             x4, x4, HEAP, lsl #32
    // 0x7bbcd4: r8 = X0 bound StatefulWidget
    //     0x7bbcd4: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7bbcd8: ldr             x8, [x8, #0x858]
    // 0x7bbcdc: LoadField: r9 = r4->field_7
    //     0x7bbcdc: ldur            x9, [x4, #7]
    // 0x7bbce0: r3 = Null
    //     0x7bbce0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e180] Null
    //     0x7bbce4: ldr             x3, [x3, #0x180]
    // 0x7bbce8: blr             x9
    // 0x7bbcec: r0 = Null
    //     0x7bbcec: mov             x0, NULL
    // 0x7bbcf0: LeaveFrame
    //     0x7bbcf0: mov             SP, fp
    //     0x7bbcf4: ldp             fp, lr, [SP], #0x10
    // 0x7bbcf8: ret
    //     0x7bbcf8: ret             
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x84ae98, size: 0x28
    // 0x84ae98: r1 = Instance__Linear
    //     0x84ae98: add             x1, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x84ae9c: ldr             x1, [x1, #0x300]
    // 0x84aea0: ldr             x2, [SP, #8]
    // 0x84aea4: LoadField: r3 = r2->field_17
    //     0x84aea4: ldur            w3, [x2, #0x17]
    // 0x84aea8: DecompressPointer r3
    //     0x84aea8: add             x3, x3, HEAP, lsl #32
    // 0x84aeac: LoadField: r2 = r3->field_f
    //     0x84aeac: ldur            w2, [x3, #0xf]
    // 0x84aeb0: DecompressPointer r2
    //     0x84aeb0: add             x2, x2, HEAP, lsl #32
    // 0x84aeb4: StoreField: r2->field_13 = r1
    //     0x84aeb4: stur            w1, [x2, #0x13]
    // 0x84aeb8: r0 = Null
    //     0x84aeb8: mov             x0, NULL
    // 0x84aebc: ret
    //     0x84aebc: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0x866738, size: 0x1d0
    // 0x866738: EnterFrame
    //     0x866738: stp             fp, lr, [SP, #-0x10]!
    //     0x86673c: mov             fp, SP
    // 0x866740: AllocStack(0x48)
    //     0x866740: sub             SP, SP, #0x48
    // 0x866744: CheckStackOverflow
    //     0x866744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x866748: cmp             SP, x16
    //     0x86674c: b.ls            #0x8668fc
    // 0x866750: r1 = 1
    //     0x866750: mov             x1, #1
    // 0x866754: r0 = AllocateContext()
    //     0x866754: bl              #0xd68aa4  ; AllocateContextStub
    // 0x866758: mov             x1, x0
    // 0x86675c: ldr             x0, [fp, #0x18]
    // 0x866760: stur            x1, [fp, #-0x18]
    // 0x866764: StoreField: r1->field_f = r0
    //     0x866764: stur            w0, [x1, #0xf]
    // 0x866768: LoadField: r2 = r0->field_b
    //     0x866768: ldur            w2, [x0, #0xb]
    // 0x86676c: DecompressPointer r2
    //     0x86676c: add             x2, x2, HEAP, lsl #32
    // 0x866770: stur            x2, [fp, #-0x10]
    // 0x866774: cmp             w2, NULL
    // 0x866778: b.eq            #0x866904
    // 0x86677c: LoadField: r3 = r2->field_b
    //     0x86677c: ldur            w3, [x2, #0xb]
    // 0x866780: DecompressPointer r3
    //     0x866780: add             x3, x3, HEAP, lsl #32
    // 0x866784: stur            x3, [fp, #-8]
    // 0x866788: r1 = 1
    //     0x866788: mov             x1, #1
    // 0x86678c: r0 = AllocateContext()
    //     0x86678c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x866790: mov             x1, x0
    // 0x866794: ldr             x0, [fp, #0x18]
    // 0x866798: stur            x1, [fp, #-0x28]
    // 0x86679c: StoreField: r1->field_f = r0
    //     0x86679c: stur            w0, [x1, #0xf]
    // 0x8667a0: ldur            x2, [fp, #-0x10]
    // 0x8667a4: LoadField: r3 = r2->field_f
    //     0x8667a4: ldur            w3, [x2, #0xf]
    // 0x8667a8: DecompressPointer r3
    //     0x8667a8: add             x3, x3, HEAP, lsl #32
    // 0x8667ac: stur            x3, [fp, #-0x20]
    // 0x8667b0: r1 = 1
    //     0x8667b0: mov             x1, #1
    // 0x8667b4: r0 = AllocateContext()
    //     0x8667b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8667b8: mov             x1, x0
    // 0x8667bc: ldr             x0, [fp, #0x18]
    // 0x8667c0: stur            x1, [fp, #-0x30]
    // 0x8667c4: StoreField: r1->field_f = r0
    //     0x8667c4: stur            w0, [x1, #0xf]
    // 0x8667c8: r1 = 1
    //     0x8667c8: mov             x1, #1
    // 0x8667cc: r0 = AllocateContext()
    //     0x8667cc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8667d0: mov             x1, x0
    // 0x8667d4: ldr             x0, [fp, #0x18]
    // 0x8667d8: stur            x1, [fp, #-0x48]
    // 0x8667dc: StoreField: r1->field_f = r0
    //     0x8667dc: stur            w0, [x1, #0xf]
    // 0x8667e0: ldur            x0, [fp, #-0x10]
    // 0x8667e4: LoadField: r2 = r0->field_13
    //     0x8667e4: ldur            w2, [x0, #0x13]
    // 0x8667e8: DecompressPointer r2
    //     0x8667e8: add             x2, x2, HEAP, lsl #32
    // 0x8667ec: stur            x2, [fp, #-0x40]
    // 0x8667f0: LoadField: r3 = r0->field_1f
    //     0x8667f0: ldur            w3, [x0, #0x1f]
    // 0x8667f4: DecompressPointer r3
    //     0x8667f4: add             x3, x3, HEAP, lsl #32
    // 0x8667f8: stur            x3, [fp, #-0x38]
    // 0x8667fc: r0 = BottomSheet()
    //     0x8667fc: bl              #0x84a9a0  ; AllocateBottomSheetStub -> BottomSheet (size=0x38)
    // 0x866800: mov             x3, x0
    // 0x866804: ldur            x0, [fp, #-8]
    // 0x866808: stur            x3, [fp, #-0x10]
    // 0x86680c: StoreField: r3->field_b = r0
    //     0x86680c: stur            w0, [x3, #0xb]
    // 0x866810: ldur            x1, [fp, #-0x20]
    // 0x866814: StoreField: r3->field_17 = r1
    //     0x866814: stur            w1, [x3, #0x17]
    // 0x866818: ldur            x2, [fp, #-0x30]
    // 0x86681c: r1 = Function '_handleDragStart@801420462':.
    //     0x86681c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e128] AnonymousClosure: (0x84ae98), of [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState
    //     0x866820: ldr             x1, [x1, #0x128]
    // 0x866824: r0 = AllocateClosure()
    //     0x866824: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x866828: mov             x1, x0
    // 0x86682c: ldur            x0, [fp, #-0x10]
    // 0x866830: StoreField: r0->field_1b = r1
    //     0x866830: stur            w1, [x0, #0x1b]
    // 0x866834: ldur            x2, [fp, #-0x48]
    // 0x866838: r1 = Function '_handleDragEnd@801420462':.
    //     0x866838: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e130] AnonymousClosure: (0x866a68), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleDragEnd (0x866b10)
    //     0x86683c: ldr             x1, [x1, #0x130]
    // 0x866840: r0 = AllocateClosure()
    //     0x866840: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x866844: mov             x1, x0
    // 0x866848: ldur            x0, [fp, #-0x10]
    // 0x86684c: StoreField: r0->field_1f = r1
    //     0x86684c: stur            w1, [x0, #0x1f]
    // 0x866850: ldur            x1, [fp, #-0x40]
    // 0x866854: StoreField: r0->field_f = r1
    //     0x866854: stur            w1, [x0, #0xf]
    // 0x866858: ldur            x1, [fp, #-0x38]
    // 0x86685c: StoreField: r0->field_13 = r1
    //     0x86685c: stur            w1, [x0, #0x13]
    // 0x866860: ldur            x2, [fp, #-0x28]
    // 0x866864: r1 = Function 'extentChanged':.
    //     0x866864: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e138] AnonymousClosure: (0x8669d4), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::extentChanged (0x866a20)
    //     0x866868: ldr             x1, [x1, #0x138]
    // 0x86686c: r0 = AllocateClosure()
    //     0x86686c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x866870: r1 = <DraggableScrollableNotification>
    //     0x866870: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f08] TypeArguments: <DraggableScrollableNotification>
    //     0x866874: ldr             x1, [x1, #0xf08]
    // 0x866878: stur            x0, [fp, #-0x20]
    // 0x86687c: r0 = NotificationListener()
    //     0x86687c: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x866880: mov             x1, x0
    // 0x866884: ldur            x0, [fp, #-0x20]
    // 0x866888: stur            x1, [fp, #-0x28]
    // 0x86688c: StoreField: r1->field_13 = r0
    //     0x86688c: stur            w0, [x1, #0x13]
    // 0x866890: ldur            x0, [fp, #-0x10]
    // 0x866894: StoreField: r1->field_b = r0
    //     0x866894: stur            w0, [x1, #0xb]
    // 0x866898: r0 = Semantics()
    //     0x866898: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x86689c: stur            x0, [fp, #-0x10]
    // 0x8668a0: r16 = true
    //     0x8668a0: add             x16, NULL, #0x20  ; true
    // 0x8668a4: stp             x16, x0, [SP, #-0x10]!
    // 0x8668a8: ldur            x16, [fp, #-0x28]
    // 0x8668ac: stp             x16, NULL, [SP, #-0x10]!
    // 0x8668b0: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, container, 0x1, onDismiss, 0x2, null]
    //     0x8668b0: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e140] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "container", 0x1, "onDismiss", 0x2, Null]
    //     0x8668b4: ldr             x4, [x4, #0x140]
    // 0x8668b8: r0 = Semantics()
    //     0x8668b8: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x8668bc: add             SP, SP, #0x20
    // 0x8668c0: ldur            x2, [fp, #-0x18]
    // 0x8668c4: r1 = Function '<anonymous closure>':.
    //     0x8668c4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e148] AnonymousClosure: (0x866908), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::build (0x866738)
    //     0x8668c8: ldr             x1, [x1, #0x148]
    // 0x8668cc: r0 = AllocateClosure()
    //     0x8668cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8668d0: stur            x0, [fp, #-0x18]
    // 0x8668d4: r0 = AnimatedBuilder()
    //     0x8668d4: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x8668d8: ldur            x1, [fp, #-0x18]
    // 0x8668dc: StoreField: r0->field_f = r1
    //     0x8668dc: stur            w1, [x0, #0xf]
    // 0x8668e0: ldur            x1, [fp, #-0x10]
    // 0x8668e4: StoreField: r0->field_13 = r1
    //     0x8668e4: stur            w1, [x0, #0x13]
    // 0x8668e8: ldur            x1, [fp, #-8]
    // 0x8668ec: StoreField: r0->field_b = r1
    //     0x8668ec: stur            w1, [x0, #0xb]
    // 0x8668f0: LeaveFrame
    //     0x8668f0: mov             SP, fp
    //     0x8668f4: ldp             fp, lr, [SP], #0x10
    // 0x8668f8: ret
    //     0x8668f8: ret             
    // 0x8668fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8668fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866900: b               #0x866750
    // 0x866904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x866904: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Align <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x866908, size: 0xcc
    // 0x866908: EnterFrame
    //     0x866908: stp             fp, lr, [SP, #-0x10]!
    //     0x86690c: mov             fp, SP
    // 0x866910: AllocStack(0x8)
    //     0x866910: sub             SP, SP, #8
    // 0x866914: SetupParameters()
    //     0x866914: ldr             x0, [fp, #0x20]
    //     0x866918: ldur            w1, [x0, #0x17]
    //     0x86691c: add             x1, x1, HEAP, lsl #32
    // 0x866920: CheckStackOverflow
    //     0x866920: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x866924: cmp             SP, x16
    //     0x866928: b.ls            #0x8669bc
    // 0x86692c: LoadField: r0 = r1->field_f
    //     0x86692c: ldur            w0, [x1, #0xf]
    // 0x866930: DecompressPointer r0
    //     0x866930: add             x0, x0, HEAP, lsl #32
    // 0x866934: LoadField: r1 = r0->field_13
    //     0x866934: ldur            w1, [x0, #0x13]
    // 0x866938: DecompressPointer r1
    //     0x866938: add             x1, x1, HEAP, lsl #32
    // 0x86693c: LoadField: r2 = r0->field_b
    //     0x86693c: ldur            w2, [x0, #0xb]
    // 0x866940: DecompressPointer r2
    //     0x866940: add             x2, x2, HEAP, lsl #32
    // 0x866944: cmp             w2, NULL
    // 0x866948: b.eq            #0x8669c4
    // 0x86694c: LoadField: r0 = r2->field_b
    //     0x86694c: ldur            w0, [x2, #0xb]
    // 0x866950: DecompressPointer r0
    //     0x866950: add             x0, x0, HEAP, lsl #32
    // 0x866954: LoadField: r2 = r0->field_37
    //     0x866954: ldur            w2, [x0, #0x37]
    // 0x866958: DecompressPointer r2
    //     0x866958: add             x2, x2, HEAP, lsl #32
    // 0x86695c: r16 = Sentinel
    //     0x86695c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x866960: cmp             w2, w16
    // 0x866964: b.eq            #0x8669c8
    // 0x866968: LoadField: d0 = r2->field_7
    //     0x866968: ldur            d0, [x2, #7]
    // 0x86696c: r0 = LoadClassIdInstr(r1)
    //     0x86696c: ldur            x0, [x1, #-1]
    //     0x866970: ubfx            x0, x0, #0xc, #0x14
    // 0x866974: SaveReg r1
    //     0x866974: str             x1, [SP, #-8]!
    // 0x866978: SaveReg d0
    //     0x866978: str             d0, [SP, #-8]!
    // 0x86697c: r0 = GDT[cid_x0 + 0x87f]()
    //     0x86697c: add             lr, x0, #0x87f
    //     0x866980: ldr             lr, [x21, lr, lsl #3]
    //     0x866984: blr             lr
    // 0x866988: add             SP, SP, #0x10
    // 0x86698c: stur            x0, [fp, #-8]
    // 0x866990: r0 = Align()
    //     0x866990: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x866994: r1 = Instance_AlignmentDirectional
    //     0x866994: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x866998: ldr             x1, [x1, #0xf70]
    // 0x86699c: StoreField: r0->field_f = r1
    //     0x86699c: stur            w1, [x0, #0xf]
    // 0x8669a0: ldur            x1, [fp, #-8]
    // 0x8669a4: StoreField: r0->field_17 = r1
    //     0x8669a4: stur            w1, [x0, #0x17]
    // 0x8669a8: ldr             x1, [fp, #0x10]
    // 0x8669ac: StoreField: r0->field_b = r1
    //     0x8669ac: stur            w1, [x0, #0xb]
    // 0x8669b0: LeaveFrame
    //     0x8669b0: mov             SP, fp
    //     0x8669b4: ldp             fp, lr, [SP], #0x10
    // 0x8669b8: ret
    //     0x8669b8: ret             
    // 0x8669bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8669bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8669c0: b               #0x86692c
    // 0x8669c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8669c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8669c8: r9 = _value
    //     0x8669c8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x8669cc: ldr             x9, [x9, #0xbb0]
    // 0x8669d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8669d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool extentChanged(dynamic, DraggableScrollableNotification) {
    // ** addr: 0x8669d4, size: 0x4c
    // 0x8669d4: EnterFrame
    //     0x8669d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8669d8: mov             fp, SP
    // 0x8669dc: ldr             x0, [fp, #0x18]
    // 0x8669e0: LoadField: r1 = r0->field_17
    //     0x8669e0: ldur            w1, [x0, #0x17]
    // 0x8669e4: DecompressPointer r1
    //     0x8669e4: add             x1, x1, HEAP, lsl #32
    // 0x8669e8: CheckStackOverflow
    //     0x8669e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8669ec: cmp             SP, x16
    //     0x8669f0: b.ls            #0x866a18
    // 0x8669f4: LoadField: r0 = r1->field_f
    //     0x8669f4: ldur            w0, [x1, #0xf]
    // 0x8669f8: DecompressPointer r0
    //     0x8669f8: add             x0, x0, HEAP, lsl #32
    // 0x8669fc: ldr             x16, [fp, #0x10]
    // 0x866a00: stp             x16, x0, [SP, #-0x10]!
    // 0x866a04: r0 = extentChanged()
    //     0x866a04: bl              #0x866a20  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::extentChanged
    // 0x866a08: add             SP, SP, #0x10
    // 0x866a0c: LeaveFrame
    //     0x866a0c: mov             SP, fp
    //     0x866a10: ldp             fp, lr, [SP], #0x10
    // 0x866a14: ret
    //     0x866a14: ret             
    // 0x866a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866a18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866a1c: b               #0x8669f4
  }
  _ extentChanged(/* No info */) {
    // ** addr: 0x866a20, size: 0x48
    // 0x866a20: EnterFrame
    //     0x866a20: stp             fp, lr, [SP, #-0x10]!
    //     0x866a24: mov             fp, SP
    // 0x866a28: CheckStackOverflow
    //     0x866a28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x866a2c: cmp             SP, x16
    //     0x866a30: b.ls            #0x866a60
    // 0x866a34: ldr             x16, [fp, #0x10]
    // 0x866a38: SaveReg r16
    //     0x866a38: str             x16, [SP, #-8]!
    // 0x866a3c: r4 = 0
    //     0x866a3c: mov             x4, #0
    // 0x866a40: ldr             x0, [SP]
    // 0x866a44: r5 = UnlinkedCall_0x4aeefc
    //     0x866a44: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e150] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x866a48: ldp             x5, lr, [x16, #0x150]
    // 0x866a4c: blr             lr
    // 0x866a50: add             SP, SP, #8
    // 0x866a54: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x866a54: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x866a58: r0 = Throw()
    //     0x866a58: bl              #0xd67e38  ; ThrowStub
    // 0x866a5c: brk             #0
    // 0x866a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866a60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866a64: b               #0x866a34
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails, {bool? isClosing}) {
    // ** addr: 0x866a68, size: 0xa8
    // 0x866a68: EnterFrame
    //     0x866a68: stp             fp, lr, [SP, #-0x10]!
    //     0x866a6c: mov             fp, SP
    // 0x866a70: mov             x0, x4
    // 0x866a74: LoadField: r1 = r0->field_13
    //     0x866a74: ldur            w1, [x0, #0x13]
    // 0x866a78: DecompressPointer r1
    //     0x866a78: add             x1, x1, HEAP, lsl #32
    // 0x866a7c: sub             x2, x1, #4
    // 0x866a80: add             x3, fp, w2, sxtw #2
    // 0x866a84: ldr             x3, [x3, #0x18]
    // 0x866a88: add             x4, fp, w2, sxtw #2
    // 0x866a8c: ldr             x4, [x4, #0x10]
    // 0x866a90: LoadField: r2 = r0->field_1f
    //     0x866a90: ldur            w2, [x0, #0x1f]
    // 0x866a94: DecompressPointer r2
    //     0x866a94: add             x2, x2, HEAP, lsl #32
    // 0x866a98: r16 = "isClosing"
    //     0x866a98: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e160] "isClosing"
    //     0x866a9c: ldr             x16, [x16, #0x160]
    // 0x866aa0: cmp             w2, w16
    // 0x866aa4: b.ne            #0x866ac4
    // 0x866aa8: LoadField: r2 = r0->field_23
    //     0x866aa8: ldur            w2, [x0, #0x23]
    // 0x866aac: DecompressPointer r2
    //     0x866aac: add             x2, x2, HEAP, lsl #32
    // 0x866ab0: sub             w0, w1, w2
    // 0x866ab4: add             x1, fp, w0, sxtw #2
    // 0x866ab8: ldr             x1, [x1, #8]
    // 0x866abc: mov             x0, x1
    // 0x866ac0: b               #0x866ac8
    // 0x866ac4: r0 = Null
    //     0x866ac4: mov             x0, NULL
    // 0x866ac8: LoadField: r1 = r3->field_17
    //     0x866ac8: ldur            w1, [x3, #0x17]
    // 0x866acc: DecompressPointer r1
    //     0x866acc: add             x1, x1, HEAP, lsl #32
    // 0x866ad0: CheckStackOverflow
    //     0x866ad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x866ad4: cmp             SP, x16
    //     0x866ad8: b.ls            #0x866b08
    // 0x866adc: LoadField: r2 = r1->field_f
    //     0x866adc: ldur            w2, [x1, #0xf]
    // 0x866ae0: DecompressPointer r2
    //     0x866ae0: add             x2, x2, HEAP, lsl #32
    // 0x866ae4: stp             x4, x2, [SP, #-0x10]!
    // 0x866ae8: SaveReg r0
    //     0x866ae8: str             x0, [SP, #-8]!
    // 0x866aec: r4 = const [0, 0x3, 0x3, 0x2, isClosing, 0x2, null]
    //     0x866aec: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e168] List(7) [0, 0x3, 0x3, 0x2, "isClosing", 0x2, Null]
    //     0x866af0: ldr             x4, [x4, #0x168]
    // 0x866af4: r0 = _handleDragEnd()
    //     0x866af4: bl              #0x866b10  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleDragEnd
    // 0x866af8: add             SP, SP, #0x18
    // 0x866afc: LeaveFrame
    //     0x866afc: mov             SP, fp
    //     0x866b00: ldp             fp, lr, [SP], #0x10
    // 0x866b04: ret
    //     0x866b04: ret             
    // 0x866b08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866b08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866b0c: b               #0x866adc
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0x866b10, size: 0xb8
    // 0x866b10: EnterFrame
    //     0x866b10: stp             fp, lr, [SP, #-0x10]!
    //     0x866b14: mov             fp, SP
    // 0x866b18: AllocStack(0x10)
    //     0x866b18: sub             SP, SP, #0x10
    // 0x866b1c: SetupParameters(_StandardBottomSheetState<_StandardBottomSheet> this /* r2, fp-0x8 */)
    //     0x866b1c: mov             x0, x4
    //     0x866b20: ldur            w1, [x0, #0x13]
    //     0x866b24: add             x1, x1, HEAP, lsl #32
    //     0x866b28: sub             x0, x1, #4
    //     0x866b2c: add             x2, fp, w0, sxtw #2
    //     0x866b30: ldr             x2, [x2, #0x18]
    //     0x866b34: stur            x2, [fp, #-8]
    // 0x866b38: LoadField: r0 = r2->field_b
    //     0x866b38: ldur            w0, [x2, #0xb]
    // 0x866b3c: DecompressPointer r0
    //     0x866b3c: add             x0, x0, HEAP, lsl #32
    // 0x866b40: cmp             w0, NULL
    // 0x866b44: b.eq            #0x866bb8
    // 0x866b48: LoadField: r1 = r0->field_b
    //     0x866b48: ldur            w1, [x0, #0xb]
    // 0x866b4c: DecompressPointer r1
    //     0x866b4c: add             x1, x1, HEAP, lsl #32
    // 0x866b50: LoadField: r0 = r1->field_37
    //     0x866b50: ldur            w0, [x1, #0x37]
    // 0x866b54: DecompressPointer r0
    //     0x866b54: add             x0, x0, HEAP, lsl #32
    // 0x866b58: r16 = Sentinel
    //     0x866b58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x866b5c: cmp             w0, w16
    // 0x866b60: b.eq            #0x866bbc
    // 0x866b64: LoadField: d0 = r0->field_7
    //     0x866b64: ldur            d0, [x0, #7]
    // 0x866b68: stur            d0, [fp, #-0x10]
    // 0x866b6c: r1 = <double>
    //     0x866b6c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x866b70: r0 = _BottomSheetSuspendedCurve()
    //     0x866b70: bl              #0x866bc8  ; Allocate_BottomSheetSuspendedCurveStub -> _BottomSheetSuspendedCurve (size=0x18)
    // 0x866b74: ldur            d0, [fp, #-0x10]
    // 0x866b78: StoreField: r0->field_b = d0
    //     0x866b78: stur            d0, [x0, #0xb]
    // 0x866b7c: r1 = Instance_Cubic
    //     0x866b7c: add             x1, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x866b80: ldr             x1, [x1, #0x2c8]
    // 0x866b84: StoreField: r0->field_13 = r1
    //     0x866b84: stur            w1, [x0, #0x13]
    // 0x866b88: ldur            x1, [fp, #-8]
    // 0x866b8c: StoreField: r1->field_13 = r0
    //     0x866b8c: stur            w0, [x1, #0x13]
    //     0x866b90: ldurb           w16, [x1, #-1]
    //     0x866b94: ldurb           w17, [x0, #-1]
    //     0x866b98: and             x16, x17, x16, lsr #2
    //     0x866b9c: tst             x16, HEAP, lsr #32
    //     0x866ba0: b.eq            #0x866ba8
    //     0x866ba4: bl              #0xd6826c
    // 0x866ba8: r0 = Null
    //     0x866ba8: mov             x0, NULL
    // 0x866bac: LeaveFrame
    //     0x866bac: mov             SP, fp
    //     0x866bb0: ldp             fp, lr, [SP], #0x10
    // 0x866bb4: ret
    //     0x866bb4: ret             
    // 0x866bb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x866bb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x866bbc: r9 = _value
    //     0x866bbc: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x866bc0: ldr             x9, [x9, #0xbb0]
    // 0x866bc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x866bc4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9db5b4, size: 0x88
    // 0x9db5b4: EnterFrame
    //     0x9db5b4: stp             fp, lr, [SP, #-0x10]!
    //     0x9db5b8: mov             fp, SP
    // 0x9db5bc: AllocStack(0x8)
    //     0x9db5bc: sub             SP, SP, #8
    // 0x9db5c0: CheckStackOverflow
    //     0x9db5c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db5c4: cmp             SP, x16
    //     0x9db5c8: b.ls            #0x9db630
    // 0x9db5cc: ldr             x0, [fp, #0x10]
    // 0x9db5d0: LoadField: r1 = r0->field_b
    //     0x9db5d0: ldur            w1, [x0, #0xb]
    // 0x9db5d4: DecompressPointer r1
    //     0x9db5d4: add             x1, x1, HEAP, lsl #32
    // 0x9db5d8: cmp             w1, NULL
    // 0x9db5dc: b.eq            #0x9db638
    // 0x9db5e0: LoadField: r2 = r1->field_b
    //     0x9db5e0: ldur            w2, [x1, #0xb]
    // 0x9db5e4: DecompressPointer r2
    //     0x9db5e4: add             x2, x2, HEAP, lsl #32
    // 0x9db5e8: stur            x2, [fp, #-8]
    // 0x9db5ec: r1 = 1
    //     0x9db5ec: mov             x1, #1
    // 0x9db5f0: r0 = AllocateContext()
    //     0x9db5f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9db5f4: mov             x1, x0
    // 0x9db5f8: ldr             x0, [fp, #0x10]
    // 0x9db5fc: StoreField: r1->field_f = r0
    //     0x9db5fc: stur            w0, [x1, #0xf]
    // 0x9db600: mov             x2, x1
    // 0x9db604: r1 = Function '_handleStatusChange@801420462':.
    //     0x9db604: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e190] AnonymousClosure: (0x9db63c), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleStatusChange (0x9db688)
    //     0x9db608: ldr             x1, [x1, #0x190]
    // 0x9db60c: r0 = AllocateClosure()
    //     0x9db60c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9db610: ldur            x16, [fp, #-8]
    // 0x9db614: stp             x0, x16, [SP, #-0x10]!
    // 0x9db618: r0 = addStatusListener()
    //     0x9db618: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x9db61c: add             SP, SP, #0x10
    // 0x9db620: r0 = Null
    //     0x9db620: mov             x0, NULL
    // 0x9db624: LeaveFrame
    //     0x9db624: mov             SP, fp
    //     0x9db628: ldp             fp, lr, [SP], #0x10
    // 0x9db62c: ret
    //     0x9db62c: ret             
    // 0x9db630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db634: b               #0x9db5cc
    // 0x9db638: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db638: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleStatusChange(dynamic, AnimationStatus) {
    // ** addr: 0x9db63c, size: 0x4c
    // 0x9db63c: EnterFrame
    //     0x9db63c: stp             fp, lr, [SP, #-0x10]!
    //     0x9db640: mov             fp, SP
    // 0x9db644: ldr             x0, [fp, #0x18]
    // 0x9db648: LoadField: r1 = r0->field_17
    //     0x9db648: ldur            w1, [x0, #0x17]
    // 0x9db64c: DecompressPointer r1
    //     0x9db64c: add             x1, x1, HEAP, lsl #32
    // 0x9db650: CheckStackOverflow
    //     0x9db650: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db654: cmp             SP, x16
    //     0x9db658: b.ls            #0x9db680
    // 0x9db65c: LoadField: r0 = r1->field_f
    //     0x9db65c: ldur            w0, [x1, #0xf]
    // 0x9db660: DecompressPointer r0
    //     0x9db660: add             x0, x0, HEAP, lsl #32
    // 0x9db664: ldr             x16, [fp, #0x10]
    // 0x9db668: stp             x16, x0, [SP, #-0x10]!
    // 0x9db66c: r0 = _handleStatusChange()
    //     0x9db66c: bl              #0x9db688  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleStatusChange
    // 0x9db670: add             SP, SP, #0x10
    // 0x9db674: LeaveFrame
    //     0x9db674: mov             SP, fp
    //     0x9db678: ldp             fp, lr, [SP], #0x10
    // 0x9db67c: ret
    //     0x9db67c: ret             
    // 0x9db680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db680: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db684: b               #0x9db65c
  }
  _ _handleStatusChange(/* No info */) {
    // ** addr: 0x9db688, size: 0x80
    // 0x9db688: EnterFrame
    //     0x9db688: stp             fp, lr, [SP, #-0x10]!
    //     0x9db68c: mov             fp, SP
    // 0x9db690: CheckStackOverflow
    //     0x9db690: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db694: cmp             SP, x16
    //     0x9db698: b.ls            #0x9db6f8
    // 0x9db69c: ldr             x0, [fp, #0x10]
    // 0x9db6a0: r16 = Instance_AnimationStatus
    //     0x9db6a0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x9db6a4: ldr             x16, [x16, #0xba8]
    // 0x9db6a8: cmp             w0, w16
    // 0x9db6ac: b.ne            #0x9db6e8
    // 0x9db6b0: ldr             x0, [fp, #0x18]
    // 0x9db6b4: LoadField: r1 = r0->field_b
    //     0x9db6b4: ldur            w1, [x0, #0xb]
    // 0x9db6b8: DecompressPointer r1
    //     0x9db6b8: add             x1, x1, HEAP, lsl #32
    // 0x9db6bc: cmp             w1, NULL
    // 0x9db6c0: b.eq            #0x9db700
    // 0x9db6c4: LoadField: r0 = r1->field_17
    //     0x9db6c4: ldur            w0, [x1, #0x17]
    // 0x9db6c8: DecompressPointer r0
    //     0x9db6c8: add             x0, x0, HEAP, lsl #32
    // 0x9db6cc: cmp             w0, NULL
    // 0x9db6d0: b.eq            #0x9db704
    // 0x9db6d4: SaveReg r0
    //     0x9db6d4: str             x0, [SP, #-8]!
    // 0x9db6d8: ClosureCall
    //     0x9db6d8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x9db6dc: ldur            x2, [x0, #0x1f]
    //     0x9db6e0: blr             x2
    // 0x9db6e4: add             SP, SP, #8
    // 0x9db6e8: r0 = Null
    //     0x9db6e8: mov             x0, NULL
    // 0x9db6ec: LeaveFrame
    //     0x9db6ec: mov             SP, fp
    //     0x9db6f0: ldp             fp, lr, [SP], #0x10
    // 0x9db6f4: ret
    //     0x9db6f4: ret             
    // 0x9db6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db6f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db6fc: b               #0x9db69c
    // 0x9db700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db700: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9db704: r0 = NullErrorSharedWithoutFPURegs()
    //     0x9db704: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b128, size: 0x18
    // 0xa4b128: r4 = 7
    //     0xa4b128: mov             x4, #7
    // 0xa4b12c: r1 = Function 'dispose':.
    //     0xa4b12c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b5b0] AnonymousClosure: (0xa4b140), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::dispose (0xa52924)
    //     0xa4b130: ldr             x1, [x17, #0x5b0]
    // 0xa4b134: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b134: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b138: LoadField: r0 = r24->field_17
    //     0xa4b138: ldur            x0, [x24, #0x17]
    // 0xa4b13c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b140, size: 0x48
    // 0xa4b140: EnterFrame
    //     0xa4b140: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b144: mov             fp, SP
    // 0xa4b148: ldr             x0, [fp, #0x10]
    // 0xa4b14c: LoadField: r1 = r0->field_17
    //     0xa4b14c: ldur            w1, [x0, #0x17]
    // 0xa4b150: DecompressPointer r1
    //     0xa4b150: add             x1, x1, HEAP, lsl #32
    // 0xa4b154: CheckStackOverflow
    //     0xa4b154: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b158: cmp             SP, x16
    //     0xa4b15c: b.ls            #0xa4b180
    // 0xa4b160: LoadField: r0 = r1->field_f
    //     0xa4b160: ldur            w0, [x1, #0xf]
    // 0xa4b164: DecompressPointer r0
    //     0xa4b164: add             x0, x0, HEAP, lsl #32
    // 0xa4b168: SaveReg r0
    //     0xa4b168: str             x0, [SP, #-8]!
    // 0xa4b16c: r0 = dispose()
    //     0xa4b16c: bl              #0xa52924  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::dispose
    // 0xa4b170: add             SP, SP, #8
    // 0xa4b174: LeaveFrame
    //     0xa4b174: mov             SP, fp
    //     0xa4b178: ldp             fp, lr, [SP], #0x10
    // 0xa4b17c: ret
    //     0xa4b17c: ret             
    // 0xa4b180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b184: b               #0xa4b160
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52924, size: 0x6c
    // 0xa52924: EnterFrame
    //     0xa52924: stp             fp, lr, [SP, #-0x10]!
    //     0xa52928: mov             fp, SP
    // 0xa5292c: CheckStackOverflow
    //     0xa5292c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52930: cmp             SP, x16
    //     0xa52934: b.ls            #0xa52980
    // 0xa52938: ldr             x0, [fp, #0x10]
    // 0xa5293c: LoadField: r1 = r0->field_b
    //     0xa5293c: ldur            w1, [x0, #0xb]
    // 0xa52940: DecompressPointer r1
    //     0xa52940: add             x1, x1, HEAP, lsl #32
    // 0xa52944: cmp             w1, NULL
    // 0xa52948: b.eq            #0xa52988
    // 0xa5294c: LoadField: r0 = r1->field_1b
    //     0xa5294c: ldur            w0, [x1, #0x1b]
    // 0xa52950: DecompressPointer r0
    //     0xa52950: add             x0, x0, HEAP, lsl #32
    // 0xa52954: cmp             w0, NULL
    // 0xa52958: b.eq            #0xa5298c
    // 0xa5295c: SaveReg r0
    //     0xa5295c: str             x0, [SP, #-8]!
    // 0xa52960: ClosureCall
    //     0xa52960: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa52964: ldur            x2, [x0, #0x1f]
    //     0xa52968: blr             x2
    // 0xa5296c: add             SP, SP, #8
    // 0xa52970: r0 = Null
    //     0xa52970: mov             x0, NULL
    // 0xa52974: LeaveFrame
    //     0xa52974: mov             SP, fp
    //     0xa52978: ldp             fp, lr, [SP], #0x10
    // 0xa5297c: ret
    //     0xa5297c: ret             
    // 0xa52980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52980: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52984: b               #0xa52938
    // 0xa52988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52988: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5298c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xa5298c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 3279, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _ScaffoldState&State&TickerProviderStateMixin extends State<Scaffold>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x618768, size: 0x178
    // 0x618768: EnterFrame
    //     0x618768: stp             fp, lr, [SP, #-0x10]!
    //     0x61876c: mov             fp, SP
    // 0x618770: AllocStack(0x10)
    //     0x618770: sub             SP, SP, #0x10
    // 0x618774: CheckStackOverflow
    //     0x618774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618778: cmp             SP, x16
    //     0x61877c: b.ls            #0x6188d0
    // 0x618780: ldr             x0, [fp, #0x18]
    // 0x618784: LoadField: r1 = r0->field_17
    //     0x618784: ldur            w1, [x0, #0x17]
    // 0x618788: DecompressPointer r1
    //     0x618788: add             x1, x1, HEAP, lsl #32
    // 0x61878c: cmp             w1, NULL
    // 0x618790: b.ne            #0x6187a0
    // 0x618794: SaveReg r0
    //     0x618794: str             x0, [SP, #-8]!
    // 0x618798: r0 = _updateTickerModeNotifier()
    //     0x618798: bl              #0x618904  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x61879c: add             SP, SP, #8
    // 0x6187a0: ldr             x0, [fp, #0x18]
    // 0x6187a4: LoadField: r1 = r0->field_13
    //     0x6187a4: ldur            w1, [x0, #0x13]
    // 0x6187a8: DecompressPointer r1
    //     0x6187a8: add             x1, x1, HEAP, lsl #32
    // 0x6187ac: cmp             w1, NULL
    // 0x6187b0: b.ne            #0x618848
    // 0x6187b4: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x6187b4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6187b8: ldr             x0, [x0, #0x598]
    //     0x6187bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6187c0: cmp             w0, w16
    //     0x6187c4: b.ne            #0x6187d0
    //     0x6187c8: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x6187cc: bl              #0xd67cdc
    // 0x6187d0: r1 = <_WidgetTicker>
    //     0x6187d0: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x6187d4: ldr             x1, [x1, #0x210]
    // 0x6187d8: stur            x0, [fp, #-8]
    // 0x6187dc: r0 = _Set()
    //     0x6187dc: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x6187e0: mov             x1, x0
    // 0x6187e4: ldur            x0, [fp, #-8]
    // 0x6187e8: stur            x1, [fp, #-0x10]
    // 0x6187ec: StoreField: r1->field_1b = r0
    //     0x6187ec: stur            w0, [x1, #0x1b]
    // 0x6187f0: StoreField: r1->field_b = rZR
    //     0x6187f0: stur            wzr, [x1, #0xb]
    // 0x6187f4: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x6187f4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6187f8: ldr             x0, [x0, #0x5a0]
    //     0x6187fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x618800: cmp             w0, w16
    //     0x618804: b.ne            #0x618810
    //     0x618808: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x61880c: bl              #0xd67cdc
    // 0x618810: mov             x1, x0
    // 0x618814: ldur            x0, [fp, #-0x10]
    // 0x618818: StoreField: r0->field_f = r1
    //     0x618818: stur            w1, [x0, #0xf]
    // 0x61881c: StoreField: r0->field_13 = rZR
    //     0x61881c: stur            wzr, [x0, #0x13]
    // 0x618820: StoreField: r0->field_17 = rZR
    //     0x618820: stur            wzr, [x0, #0x17]
    // 0x618824: ldr             x1, [fp, #0x18]
    // 0x618828: StoreField: r1->field_13 = r0
    //     0x618828: stur            w0, [x1, #0x13]
    //     0x61882c: ldurb           w16, [x1, #-1]
    //     0x618830: ldurb           w17, [x0, #-1]
    //     0x618834: and             x16, x17, x16, lsr #2
    //     0x618838: tst             x16, HEAP, lsr #32
    //     0x61883c: b.eq            #0x618844
    //     0x618840: bl              #0xd6826c
    // 0x618844: b               #0x61884c
    // 0x618848: mov             x1, x0
    // 0x61884c: ldr             x0, [fp, #0x10]
    // 0x618850: r0 = _WidgetTicker()
    //     0x618850: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x618854: mov             x1, x0
    // 0x618858: ldr             x0, [fp, #0x18]
    // 0x61885c: stur            x1, [fp, #-8]
    // 0x618860: StoreField: r1->field_1b = r0
    //     0x618860: stur            w0, [x1, #0x1b]
    // 0x618864: r2 = false
    //     0x618864: add             x2, NULL, #0x30  ; false
    // 0x618868: StoreField: r1->field_b = r2
    //     0x618868: stur            w2, [x1, #0xb]
    // 0x61886c: ldr             x2, [fp, #0x10]
    // 0x618870: StoreField: r1->field_13 = r2
    //     0x618870: stur            w2, [x1, #0x13]
    // 0x618874: LoadField: r2 = r0->field_17
    //     0x618874: ldur            w2, [x0, #0x17]
    // 0x618878: DecompressPointer r2
    //     0x618878: add             x2, x2, HEAP, lsl #32
    // 0x61887c: cmp             w2, NULL
    // 0x618880: b.eq            #0x6188d8
    // 0x618884: LoadField: r3 = r2->field_27
    //     0x618884: ldur            w3, [x2, #0x27]
    // 0x618888: DecompressPointer r3
    //     0x618888: add             x3, x3, HEAP, lsl #32
    // 0x61888c: eor             x2, x3, #0x10
    // 0x618890: stp             x2, x1, [SP, #-0x10]!
    // 0x618894: r0 = muted=()
    //     0x618894: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x618898: add             SP, SP, #0x10
    // 0x61889c: ldr             x0, [fp, #0x18]
    // 0x6188a0: LoadField: r1 = r0->field_13
    //     0x6188a0: ldur            w1, [x0, #0x13]
    // 0x6188a4: DecompressPointer r1
    //     0x6188a4: add             x1, x1, HEAP, lsl #32
    // 0x6188a8: cmp             w1, NULL
    // 0x6188ac: b.eq            #0x6188dc
    // 0x6188b0: ldur            x16, [fp, #-8]
    // 0x6188b4: stp             x16, x1, [SP, #-0x10]!
    // 0x6188b8: r0 = add()
    //     0x6188b8: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x6188bc: add             SP, SP, #0x10
    // 0x6188c0: ldur            x0, [fp, #-8]
    // 0x6188c4: LeaveFrame
    //     0x6188c4: mov             SP, fp
    //     0x6188c8: ldp             fp, lr, [SP], #0x10
    // 0x6188cc: ret
    //     0x6188cc: ret             
    // 0x6188d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6188d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6188d4: b               #0x618780
    // 0x6188d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6188d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6188dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6188dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x618904, size: 0x11c
    // 0x618904: EnterFrame
    //     0x618904: stp             fp, lr, [SP, #-0x10]!
    //     0x618908: mov             fp, SP
    // 0x61890c: AllocStack(0x10)
    //     0x61890c: sub             SP, SP, #0x10
    // 0x618910: CheckStackOverflow
    //     0x618910: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618914: cmp             SP, x16
    //     0x618918: b.ls            #0x618a14
    // 0x61891c: ldr             x0, [fp, #0x10]
    // 0x618920: LoadField: r1 = r0->field_f
    //     0x618920: ldur            w1, [x0, #0xf]
    // 0x618924: DecompressPointer r1
    //     0x618924: add             x1, x1, HEAP, lsl #32
    // 0x618928: cmp             w1, NULL
    // 0x61892c: b.eq            #0x618a1c
    // 0x618930: SaveReg r1
    //     0x618930: str             x1, [SP, #-8]!
    // 0x618934: r0 = getNotifier()
    //     0x618934: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x618938: add             SP, SP, #8
    // 0x61893c: mov             x1, x0
    // 0x618940: ldr             x0, [fp, #0x10]
    // 0x618944: stur            x1, [fp, #-0x10]
    // 0x618948: LoadField: r2 = r0->field_17
    //     0x618948: ldur            w2, [x0, #0x17]
    // 0x61894c: DecompressPointer r2
    //     0x61894c: add             x2, x2, HEAP, lsl #32
    // 0x618950: stur            x2, [fp, #-8]
    // 0x618954: cmp             w1, w2
    // 0x618958: b.ne            #0x61896c
    // 0x61895c: r0 = Null
    //     0x61895c: mov             x0, NULL
    // 0x618960: LeaveFrame
    //     0x618960: mov             SP, fp
    //     0x618964: ldp             fp, lr, [SP], #0x10
    // 0x618968: ret
    //     0x618968: ret             
    // 0x61896c: cmp             w2, NULL
    // 0x618970: b.eq            #0x6189ac
    // 0x618974: r1 = 1
    //     0x618974: mov             x1, #1
    // 0x618978: r0 = AllocateContext()
    //     0x618978: bl              #0xd68aa4  ; AllocateContextStub
    // 0x61897c: mov             x1, x0
    // 0x618980: ldr             x0, [fp, #0x10]
    // 0x618984: StoreField: r1->field_f = r0
    //     0x618984: stur            w0, [x1, #0xf]
    // 0x618988: mov             x2, x1
    // 0x61898c: r1 = Function '_updateTickers@156311458':.
    //     0x61898c: add             x1, PP, #0x21, lsl #12  ; [pp+0x21d58] AnonymousClosure: (0x618a20), in [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::_updateTickers (0x618a68)
    //     0x618990: ldr             x1, [x1, #0xd58]
    // 0x618994: r0 = AllocateClosure()
    //     0x618994: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x618998: ldur            x16, [fp, #-8]
    // 0x61899c: stp             x0, x16, [SP, #-0x10]!
    // 0x6189a0: r0 = removeListener()
    //     0x6189a0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x6189a4: add             SP, SP, #0x10
    // 0x6189a8: ldr             x0, [fp, #0x10]
    // 0x6189ac: r1 = 1
    //     0x6189ac: mov             x1, #1
    // 0x6189b0: r0 = AllocateContext()
    //     0x6189b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6189b4: mov             x1, x0
    // 0x6189b8: ldr             x0, [fp, #0x10]
    // 0x6189bc: StoreField: r1->field_f = r0
    //     0x6189bc: stur            w0, [x1, #0xf]
    // 0x6189c0: mov             x2, x1
    // 0x6189c4: r1 = Function '_updateTickers@156311458':.
    //     0x6189c4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21d58] AnonymousClosure: (0x618a20), in [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::_updateTickers (0x618a68)
    //     0x6189c8: ldr             x1, [x1, #0xd58]
    // 0x6189cc: r0 = AllocateClosure()
    //     0x6189cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6189d0: ldur            x16, [fp, #-0x10]
    // 0x6189d4: stp             x0, x16, [SP, #-0x10]!
    // 0x6189d8: r0 = addListener()
    //     0x6189d8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x6189dc: add             SP, SP, #0x10
    // 0x6189e0: ldur            x0, [fp, #-0x10]
    // 0x6189e4: ldr             x1, [fp, #0x10]
    // 0x6189e8: StoreField: r1->field_17 = r0
    //     0x6189e8: stur            w0, [x1, #0x17]
    //     0x6189ec: ldurb           w16, [x1, #-1]
    //     0x6189f0: ldurb           w17, [x0, #-1]
    //     0x6189f4: and             x16, x17, x16, lsr #2
    //     0x6189f8: tst             x16, HEAP, lsr #32
    //     0x6189fc: b.eq            #0x618a04
    //     0x618a00: bl              #0xd6826c
    // 0x618a04: r0 = Null
    //     0x618a04: mov             x0, NULL
    // 0x618a08: LeaveFrame
    //     0x618a08: mov             SP, fp
    //     0x618a0c: ldp             fp, lr, [SP], #0x10
    // 0x618a10: ret
    //     0x618a10: ret             
    // 0x618a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618a14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618a18: b               #0x61891c
    // 0x618a1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x618a1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x618a20, size: 0x48
    // 0x618a20: EnterFrame
    //     0x618a20: stp             fp, lr, [SP, #-0x10]!
    //     0x618a24: mov             fp, SP
    // 0x618a28: ldr             x0, [fp, #0x10]
    // 0x618a2c: LoadField: r1 = r0->field_17
    //     0x618a2c: ldur            w1, [x0, #0x17]
    // 0x618a30: DecompressPointer r1
    //     0x618a30: add             x1, x1, HEAP, lsl #32
    // 0x618a34: CheckStackOverflow
    //     0x618a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618a38: cmp             SP, x16
    //     0x618a3c: b.ls            #0x618a60
    // 0x618a40: LoadField: r0 = r1->field_f
    //     0x618a40: ldur            w0, [x1, #0xf]
    // 0x618a44: DecompressPointer r0
    //     0x618a44: add             x0, x0, HEAP, lsl #32
    // 0x618a48: SaveReg r0
    //     0x618a48: str             x0, [SP, #-8]!
    // 0x618a4c: r0 = _updateTickers()
    //     0x618a4c: bl              #0x618a68  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::_updateTickers
    // 0x618a50: add             SP, SP, #8
    // 0x618a54: LeaveFrame
    //     0x618a54: mov             SP, fp
    //     0x618a58: ldp             fp, lr, [SP], #0x10
    // 0x618a5c: ret
    //     0x618a5c: ret             
    // 0x618a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618a60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618a64: b               #0x618a40
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x618a68, size: 0x150
    // 0x618a68: EnterFrame
    //     0x618a68: stp             fp, lr, [SP, #-0x10]!
    //     0x618a6c: mov             fp, SP
    // 0x618a70: AllocStack(0x20)
    //     0x618a70: sub             SP, SP, #0x20
    // 0x618a74: CheckStackOverflow
    //     0x618a74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618a78: cmp             SP, x16
    //     0x618a7c: b.ls            #0x618ba4
    // 0x618a80: ldr             x0, [fp, #0x10]
    // 0x618a84: LoadField: r1 = r0->field_13
    //     0x618a84: ldur            w1, [x0, #0x13]
    // 0x618a88: DecompressPointer r1
    //     0x618a88: add             x1, x1, HEAP, lsl #32
    // 0x618a8c: cmp             w1, NULL
    // 0x618a90: b.eq            #0x618b94
    // 0x618a94: LoadField: r2 = r0->field_17
    //     0x618a94: ldur            w2, [x0, #0x17]
    // 0x618a98: DecompressPointer r2
    //     0x618a98: add             x2, x2, HEAP, lsl #32
    // 0x618a9c: cmp             w2, NULL
    // 0x618aa0: b.eq            #0x618bac
    // 0x618aa4: LoadField: r0 = r2->field_27
    //     0x618aa4: ldur            w0, [x2, #0x27]
    // 0x618aa8: DecompressPointer r0
    //     0x618aa8: add             x0, x0, HEAP, lsl #32
    // 0x618aac: eor             x2, x0, #0x10
    // 0x618ab0: stur            x2, [fp, #-8]
    // 0x618ab4: SaveReg r1
    //     0x618ab4: str             x1, [SP, #-8]!
    // 0x618ab8: r0 = iterator()
    //     0x618ab8: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x618abc: add             SP, SP, #8
    // 0x618ac0: stur            x0, [fp, #-0x18]
    // 0x618ac4: LoadField: r2 = r0->field_7
    //     0x618ac4: ldur            w2, [x0, #7]
    // 0x618ac8: DecompressPointer r2
    //     0x618ac8: add             x2, x2, HEAP, lsl #32
    // 0x618acc: stur            x2, [fp, #-0x10]
    // 0x618ad0: ldur            x1, [fp, #-8]
    // 0x618ad4: CheckStackOverflow
    //     0x618ad4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618ad8: cmp             SP, x16
    //     0x618adc: b.ls            #0x618bb0
    // 0x618ae0: SaveReg r0
    //     0x618ae0: str             x0, [SP, #-8]!
    // 0x618ae4: r0 = moveNext()
    //     0x618ae4: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x618ae8: add             SP, SP, #8
    // 0x618aec: tbnz            w0, #4, #0x618b94
    // 0x618af0: ldur            x3, [fp, #-0x18]
    // 0x618af4: LoadField: r4 = r3->field_33
    //     0x618af4: ldur            w4, [x3, #0x33]
    // 0x618af8: DecompressPointer r4
    //     0x618af8: add             x4, x4, HEAP, lsl #32
    // 0x618afc: stur            x4, [fp, #-0x20]
    // 0x618b00: cmp             w4, NULL
    // 0x618b04: b.ne            #0x618b38
    // 0x618b08: mov             x0, x4
    // 0x618b0c: ldur            x2, [fp, #-0x10]
    // 0x618b10: r1 = Null
    //     0x618b10: mov             x1, NULL
    // 0x618b14: cmp             w2, NULL
    // 0x618b18: b.eq            #0x618b38
    // 0x618b1c: LoadField: r4 = r2->field_17
    //     0x618b1c: ldur            w4, [x2, #0x17]
    // 0x618b20: DecompressPointer r4
    //     0x618b20: add             x4, x4, HEAP, lsl #32
    // 0x618b24: r8 = X0
    //     0x618b24: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x618b28: LoadField: r9 = r4->field_7
    //     0x618b28: ldur            x9, [x4, #7]
    // 0x618b2c: r3 = Null
    //     0x618b2c: add             x3, PP, #0x21, lsl #12  ; [pp+0x21d48] Null
    //     0x618b30: ldr             x3, [x3, #0xd48]
    // 0x618b34: blr             x9
    // 0x618b38: ldur            x1, [fp, #-8]
    // 0x618b3c: ldur            x0, [fp, #-0x20]
    // 0x618b40: LoadField: r2 = r0->field_b
    //     0x618b40: ldur            w2, [x0, #0xb]
    // 0x618b44: DecompressPointer r2
    //     0x618b44: add             x2, x2, HEAP, lsl #32
    // 0x618b48: cmp             w1, w2
    // 0x618b4c: b.eq            #0x618b88
    // 0x618b50: StoreField: r0->field_b = r1
    //     0x618b50: stur            w1, [x0, #0xb]
    // 0x618b54: tbnz            w1, #4, #0x618b68
    // 0x618b58: SaveReg r0
    //     0x618b58: str             x0, [SP, #-8]!
    // 0x618b5c: r0 = unscheduleTick()
    //     0x618b5c: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x618b60: add             SP, SP, #8
    // 0x618b64: b               #0x618b88
    // 0x618b68: SaveReg r0
    //     0x618b68: str             x0, [SP, #-8]!
    // 0x618b6c: r0 = shouldScheduleTick()
    //     0x618b6c: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x618b70: add             SP, SP, #8
    // 0x618b74: tbnz            w0, #4, #0x618b88
    // 0x618b78: ldur            x16, [fp, #-0x20]
    // 0x618b7c: SaveReg r16
    //     0x618b7c: str             x16, [SP, #-8]!
    // 0x618b80: r0 = scheduleTick()
    //     0x618b80: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x618b84: add             SP, SP, #8
    // 0x618b88: ldur            x0, [fp, #-0x18]
    // 0x618b8c: ldur            x2, [fp, #-0x10]
    // 0x618b90: b               #0x618ad0
    // 0x618b94: r0 = Null
    //     0x618b94: mov             x0, NULL
    // 0x618b98: LeaveFrame
    //     0x618b98: mov             SP, fp
    //     0x618b9c: ldp             fp, lr, [SP], #0x10
    // 0x618ba0: ret
    //     0x618ba0: ret             
    // 0x618ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618ba4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618ba8: b               #0x618a80
    // 0x618bac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x618bac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x618bb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618bb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618bb4: b               #0x618ae0
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f7a0, size: 0x4c
    // 0x81f7a0: EnterFrame
    //     0x81f7a0: stp             fp, lr, [SP, #-0x10]!
    //     0x81f7a4: mov             fp, SP
    // 0x81f7a8: CheckStackOverflow
    //     0x81f7a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f7ac: cmp             SP, x16
    //     0x81f7b0: b.ls            #0x81f7e4
    // 0x81f7b4: ldr             x16, [fp, #0x10]
    // 0x81f7b8: SaveReg r16
    //     0x81f7b8: str             x16, [SP, #-8]!
    // 0x81f7bc: r0 = _updateTickerModeNotifier()
    //     0x81f7bc: bl              #0x618904  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f7c0: add             SP, SP, #8
    // 0x81f7c4: ldr             x16, [fp, #0x10]
    // 0x81f7c8: SaveReg r16
    //     0x81f7c8: str             x16, [SP, #-8]!
    // 0x81f7cc: r0 = _updateTickers()
    //     0x81f7cc: bl              #0x618a68  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f7d0: add             SP, SP, #8
    // 0x81f7d4: r0 = Null
    //     0x81f7d4: mov             x0, NULL
    // 0x81f7d8: LeaveFrame
    //     0x81f7d8: mov             SP, fp
    //     0x81f7dc: ldp             fp, lr, [SP], #0x10
    // 0x81f7e0: ret
    //     0x81f7e0: ret             
    // 0x81f7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f7e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f7e8: b               #0x81f7b4
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f574, size: 0x8c
    // 0xa4f574: EnterFrame
    //     0xa4f574: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f578: mov             fp, SP
    // 0xa4f57c: AllocStack(0x8)
    //     0xa4f57c: sub             SP, SP, #8
    // 0xa4f580: CheckStackOverflow
    //     0xa4f580: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f584: cmp             SP, x16
    //     0xa4f588: b.ls            #0xa4f5f8
    // 0xa4f58c: ldr             x0, [fp, #0x10]
    // 0xa4f590: LoadField: r1 = r0->field_17
    //     0xa4f590: ldur            w1, [x0, #0x17]
    // 0xa4f594: DecompressPointer r1
    //     0xa4f594: add             x1, x1, HEAP, lsl #32
    // 0xa4f598: stur            x1, [fp, #-8]
    // 0xa4f59c: cmp             w1, NULL
    // 0xa4f5a0: b.ne            #0xa4f5ac
    // 0xa4f5a4: mov             x1, x0
    // 0xa4f5a8: b               #0xa4f5e4
    // 0xa4f5ac: r1 = 1
    //     0xa4f5ac: mov             x1, #1
    // 0xa4f5b0: r0 = AllocateContext()
    //     0xa4f5b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4f5b4: mov             x1, x0
    // 0xa4f5b8: ldr             x0, [fp, #0x10]
    // 0xa4f5bc: StoreField: r1->field_f = r0
    //     0xa4f5bc: stur            w0, [x1, #0xf]
    // 0xa4f5c0: mov             x2, x1
    // 0xa4f5c4: r1 = Function '_updateTickers@156311458':.
    //     0xa4f5c4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21d58] AnonymousClosure: (0x618a20), in [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::_updateTickers (0x618a68)
    //     0xa4f5c8: ldr             x1, [x1, #0xd58]
    // 0xa4f5cc: r0 = AllocateClosure()
    //     0xa4f5cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4f5d0: ldur            x16, [fp, #-8]
    // 0xa4f5d4: stp             x0, x16, [SP, #-0x10]!
    // 0xa4f5d8: r0 = removeListener()
    //     0xa4f5d8: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4f5dc: add             SP, SP, #0x10
    // 0xa4f5e0: ldr             x1, [fp, #0x10]
    // 0xa4f5e4: StoreField: r1->field_17 = rNULL
    //     0xa4f5e4: stur            NULL, [x1, #0x17]
    // 0xa4f5e8: r0 = Null
    //     0xa4f5e8: mov             x0, NULL
    // 0xa4f5ec: LeaveFrame
    //     0xa4f5ec: mov             SP, fp
    //     0xa4f5f0: ldp             fp, lr, [SP], #0x10
    // 0xa4f5f4: ret
    //     0xa4f5f4: ret             
    // 0xa4f5f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f5f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f5fc: b               #0xa4f58c
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4f600, size: 0x48
    // 0xa4f600: EnterFrame
    //     0xa4f600: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f604: mov             fp, SP
    // 0xa4f608: ldr             x0, [fp, #0x10]
    // 0xa4f60c: LoadField: r1 = r0->field_17
    //     0xa4f60c: ldur            w1, [x0, #0x17]
    // 0xa4f610: DecompressPointer r1
    //     0xa4f610: add             x1, x1, HEAP, lsl #32
    // 0xa4f614: CheckStackOverflow
    //     0xa4f614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f618: cmp             SP, x16
    //     0xa4f61c: b.ls            #0xa4f640
    // 0xa4f620: LoadField: r0 = r1->field_f
    //     0xa4f620: ldur            w0, [x1, #0xf]
    // 0xa4f624: DecompressPointer r0
    //     0xa4f624: add             x0, x0, HEAP, lsl #32
    // 0xa4f628: SaveReg r0
    //     0xa4f628: str             x0, [SP, #-8]!
    // 0xa4f62c: r0 = dispose()
    //     0xa4f62c: bl              #0xa4f574  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::dispose
    // 0xa4f630: add             SP, SP, #8
    // 0xa4f634: LeaveFrame
    //     0xa4f634: mov             SP, fp
    //     0xa4f638: ldp             fp, lr, [SP], #0x10
    // 0xa4f63c: ret
    //     0xa4f63c: ret             
    // 0xa4f640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f640: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f644: b               #0xa4f620
  }
}

// class id: 3280, size: 0x2c, field offset: 0x1c
//   transformed mixin,
abstract class _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin extends _ScaffoldState&State&TickerProviderStateMixin
     with RestorationMixin<X0 bound StatefulWidget> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bbbb4, size: 0x78
    // 0x7bbbb4: EnterFrame
    //     0x7bbbb4: stp             fp, lr, [SP, #-0x10]!
    //     0x7bbbb8: mov             fp, SP
    // 0x7bbbbc: CheckStackOverflow
    //     0x7bbbbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bbbc0: cmp             SP, x16
    //     0x7bbbc4: b.ls            #0x7bbc24
    // 0x7bbbc8: ldr             x3, [fp, #0x18]
    // 0x7bbbcc: LoadField: r2 = r3->field_7
    //     0x7bbbcc: ldur            w2, [x3, #7]
    // 0x7bbbd0: DecompressPointer r2
    //     0x7bbbd0: add             x2, x2, HEAP, lsl #32
    // 0x7bbbd4: ldr             x0, [fp, #0x10]
    // 0x7bbbd8: r1 = Null
    //     0x7bbbd8: mov             x1, NULL
    // 0x7bbbdc: cmp             w2, NULL
    // 0x7bbbe0: b.eq            #0x7bbc04
    // 0x7bbbe4: LoadField: r4 = r2->field_17
    //     0x7bbbe4: ldur            w4, [x2, #0x17]
    // 0x7bbbe8: DecompressPointer r4
    //     0x7bbbe8: add             x4, x4, HEAP, lsl #32
    // 0x7bbbec: r8 = X0 bound StatefulWidget
    //     0x7bbbec: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7bbbf0: ldr             x8, [x8, #0x858]
    // 0x7bbbf4: LoadField: r9 = r4->field_7
    //     0x7bbbf4: ldur            x9, [x4, #7]
    // 0x7bbbf8: r3 = Null
    //     0x7bbbf8: add             x3, PP, #0x22, lsl #12  ; [pp+0x22050] Null
    //     0x7bbbfc: ldr             x3, [x3, #0x50]
    // 0x7bbc00: blr             x9
    // 0x7bbc04: ldr             x16, [fp, #0x18]
    // 0x7bbc08: SaveReg r16
    //     0x7bbc08: str             x16, [SP, #-8]!
    // 0x7bbc0c: r0 = didUpdateRestorationId()
    //     0x7bbc0c: bl              #0x7bbc2c  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::didUpdateRestorationId
    // 0x7bbc10: add             SP, SP, #8
    // 0x7bbc14: r0 = Null
    //     0x7bbc14: mov             x0, NULL
    // 0x7bbc18: LeaveFrame
    //     0x7bbc18: mov             SP, fp
    //     0x7bbc1c: ldp             fp, lr, [SP], #0x10
    // 0x7bbc20: ret
    //     0x7bbc20: ret             
    // 0x7bbc24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bbc24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bbc28: b               #0x7bbbc8
  }
  _ didUpdateRestorationId(/* No info */) {
    // ** addr: 0x7bbc2c, size: 0x40
    // 0x7bbc2c: EnterFrame
    //     0x7bbc2c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bbc30: mov             fp, SP
    // 0x7bbc34: ldr             x1, [fp, #0x10]
    // 0x7bbc38: LoadField: r2 = r1->field_27
    //     0x7bbc38: ldur            w2, [x1, #0x27]
    // 0x7bbc3c: DecompressPointer r2
    //     0x7bbc3c: add             x2, x2, HEAP, lsl #32
    // 0x7bbc40: cmp             w2, NULL
    // 0x7bbc44: b.eq            #0x7bbc58
    // 0x7bbc48: LoadField: r2 = r1->field_b
    //     0x7bbc48: ldur            w2, [x1, #0xb]
    // 0x7bbc4c: DecompressPointer r2
    //     0x7bbc4c: add             x2, x2, HEAP, lsl #32
    // 0x7bbc50: cmp             w2, NULL
    // 0x7bbc54: b.eq            #0x7bbc68
    // 0x7bbc58: r0 = Null
    //     0x7bbc58: mov             x0, NULL
    // 0x7bbc5c: LeaveFrame
    //     0x7bbc5c: mov             SP, fp
    //     0x7bbc60: ldp             fp, lr, [SP], #0x10
    // 0x7bbc64: ret
    //     0x7bbc64: ret             
    // 0x7bbc68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bbc68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RestorableProperty<Object?>, (dynamic) => void) {
    // ** addr: 0xa4f4b4, size: 0x4c
    // 0xa4f4b4: EnterFrame
    //     0xa4f4b4: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f4b8: mov             fp, SP
    // 0xa4f4bc: CheckStackOverflow
    //     0xa4f4bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f4c0: cmp             SP, x16
    //     0xa4f4c4: b.ls            #0xa4f4f8
    // 0xa4f4c8: ldr             x0, [fp, #0x18]
    // 0xa4f4cc: LoadField: r1 = r0->field_27
    //     0xa4f4cc: ldur            w1, [x0, #0x27]
    // 0xa4f4d0: DecompressPointer r1
    //     0xa4f4d0: add             x1, x1, HEAP, lsl #32
    // 0xa4f4d4: tbz             w1, #4, #0xa4f4e8
    // 0xa4f4d8: ldr             x16, [fp, #0x10]
    // 0xa4f4dc: stp             x16, x0, [SP, #-0x10]!
    // 0xa4f4e0: r0 = removeListener()
    //     0xa4f4e0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4f4e4: add             SP, SP, #0x10
    // 0xa4f4e8: r0 = Null
    //     0xa4f4e8: mov             x0, NULL
    // 0xa4f4ec: LeaveFrame
    //     0xa4f4ec: mov             SP, fp
    //     0xa4f4f0: ldp             fp, lr, [SP], #0x10
    // 0xa4f4f4: ret
    //     0xa4f4f4: ret             
    // 0xa4f4f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f4f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f4fc: b               #0xa4f4c8
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4f500, size: 0x74
    // 0xa4f500: EnterFrame
    //     0xa4f500: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f504: mov             fp, SP
    // 0xa4f508: AllocStack(0x8)
    //     0xa4f508: sub             SP, SP, #8
    // 0xa4f50c: CheckStackOverflow
    //     0xa4f50c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f510: cmp             SP, x16
    //     0xa4f514: b.ls            #0xa4f56c
    // 0xa4f518: ldr             x0, [fp, #0x10]
    // 0xa4f51c: LoadField: r3 = r0->field_1f
    //     0xa4f51c: ldur            w3, [x0, #0x1f]
    // 0xa4f520: DecompressPointer r3
    //     0xa4f520: add             x3, x3, HEAP, lsl #32
    // 0xa4f524: stur            x3, [fp, #-8]
    // 0xa4f528: r1 = Function '<anonymous closure>':.
    //     0xa4f528: add             x1, PP, #0x22, lsl #12  ; [pp+0x22018] AnonymousClosure: (0xa4f4b4), in [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::dispose (0xa4f500)
    //     0xa4f52c: ldr             x1, [x1, #0x18]
    // 0xa4f530: r2 = Null
    //     0xa4f530: mov             x2, NULL
    // 0xa4f534: r0 = AllocateClosure()
    //     0xa4f534: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4f538: ldur            x16, [fp, #-8]
    // 0xa4f53c: stp             x0, x16, [SP, #-0x10]!
    // 0xa4f540: r0 = forEach()
    //     0xa4f540: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0xa4f544: add             SP, SP, #0x10
    // 0xa4f548: ldr             x0, [fp, #0x10]
    // 0xa4f54c: StoreField: r0->field_1b = rNULL
    //     0xa4f54c: stur            NULL, [x0, #0x1b]
    // 0xa4f550: SaveReg r0
    //     0xa4f550: str             x0, [SP, #-8]!
    // 0xa4f554: r0 = dispose()
    //     0xa4f554: bl              #0xa4f574  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin::dispose
    // 0xa4f558: add             SP, SP, #8
    // 0xa4f55c: r0 = Null
    //     0xa4f55c: mov             x0, NULL
    // 0xa4f560: LeaveFrame
    //     0xa4f560: mov             SP, fp
    //     0xa4f564: ldp             fp, lr, [SP], #0x10
    // 0xa4f568: ret
    //     0xa4f568: ret             
    // 0xa4f56c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f56c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f570: b               #0xa4f518
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4f648, size: 0x48
    // 0xa4f648: EnterFrame
    //     0xa4f648: stp             fp, lr, [SP, #-0x10]!
    //     0xa4f64c: mov             fp, SP
    // 0xa4f650: ldr             x0, [fp, #0x10]
    // 0xa4f654: LoadField: r1 = r0->field_17
    //     0xa4f654: ldur            w1, [x0, #0x17]
    // 0xa4f658: DecompressPointer r1
    //     0xa4f658: add             x1, x1, HEAP, lsl #32
    // 0xa4f65c: CheckStackOverflow
    //     0xa4f65c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4f660: cmp             SP, x16
    //     0xa4f664: b.ls            #0xa4f688
    // 0xa4f668: LoadField: r0 = r1->field_f
    //     0xa4f668: ldur            w0, [x1, #0xf]
    // 0xa4f66c: DecompressPointer r0
    //     0xa4f66c: add             x0, x0, HEAP, lsl #32
    // 0xa4f670: SaveReg r0
    //     0xa4f670: str             x0, [SP, #-8]!
    // 0xa4f674: r0 = dispose()
    //     0xa4f674: bl              #0xa4f500  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::dispose
    // 0xa4f678: add             SP, SP, #8
    // 0xa4f67c: LeaveFrame
    //     0xa4f67c: mov             SP, fp
    //     0xa4f680: ldp             fp, lr, [SP], #0x10
    // 0xa4f684: ret
    //     0xa4f684: ret             
    // 0xa4f688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4f688: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4f68c: b               #0xa4f668
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa617b8, size: 0xbc
    // 0xa617b8: EnterFrame
    //     0xa617b8: stp             fp, lr, [SP, #-0x10]!
    //     0xa617bc: mov             fp, SP
    // 0xa617c0: AllocStack(0x8)
    //     0xa617c0: sub             SP, SP, #8
    // 0xa617c4: CheckStackOverflow
    //     0xa617c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa617c8: cmp             SP, x16
    //     0xa617cc: b.ls            #0xa61868
    // 0xa617d0: ldr             x16, [fp, #0x10]
    // 0xa617d4: SaveReg r16
    //     0xa617d4: str             x16, [SP, #-8]!
    // 0xa617d8: r0 = restorePending()
    //     0xa617d8: bl              #0xa61a88  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::restorePending
    // 0xa617dc: add             SP, SP, #8
    // 0xa617e0: mov             x1, x0
    // 0xa617e4: ldr             x0, [fp, #0x10]
    // 0xa617e8: stur            x1, [fp, #-8]
    // 0xa617ec: LoadField: r2 = r0->field_f
    //     0xa617ec: ldur            w2, [x0, #0xf]
    // 0xa617f0: DecompressPointer r2
    //     0xa617f0: add             x2, x2, HEAP, lsl #32
    // 0xa617f4: cmp             w2, NULL
    // 0xa617f8: b.eq            #0xa61870
    // 0xa617fc: SaveReg r2
    //     0xa617fc: str             x2, [SP, #-8]!
    // 0xa61800: r0 = maybeOf()
    //     0xa61800: bl              #0x79e9e4  ; [package:flutter/src/widgets/restoration.dart] RestorationScope::maybeOf
    // 0xa61804: add             SP, SP, #8
    // 0xa61808: mov             x2, x0
    // 0xa6180c: ldr             x1, [fp, #0x10]
    // 0xa61810: StoreField: r1->field_27 = r0
    //     0xa61810: stur            w0, [x1, #0x27]
    //     0xa61814: ldurb           w16, [x1, #-1]
    //     0xa61818: ldurb           w17, [x0, #-1]
    //     0xa6181c: and             x16, x17, x16, lsr #2
    //     0xa61820: tst             x16, HEAP, lsr #32
    //     0xa61824: b.eq            #0xa6182c
    //     0xa61828: bl              #0xd6826c
    // 0xa6182c: stp             x2, x1, [SP, #-0x10]!
    // 0xa61830: ldur            x16, [fp, #-8]
    // 0xa61834: SaveReg r16
    //     0xa61834: str             x16, [SP, #-8]!
    // 0xa61838: r0 = _updateBucketIfNecessary()
    //     0xa61838: bl              #0xa61a34  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::_updateBucketIfNecessary
    // 0xa6183c: add             SP, SP, #0x18
    // 0xa61840: ldur            x0, [fp, #-8]
    // 0xa61844: tbnz            w0, #4, #0xa61858
    // 0xa61848: ldr             x16, [fp, #0x10]
    // 0xa6184c: SaveReg r16
    //     0xa6184c: str             x16, [SP, #-8]!
    // 0xa61850: r0 = _doRestore()
    //     0xa61850: bl              #0xa61874  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::_doRestore
    // 0xa61854: add             SP, SP, #8
    // 0xa61858: r0 = Null
    //     0xa61858: mov             x0, NULL
    // 0xa6185c: LeaveFrame
    //     0xa6185c: mov             SP, fp
    //     0xa61860: ldp             fp, lr, [SP], #0x10
    // 0xa61864: ret
    //     0xa61864: ret             
    // 0xa61868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61868: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6186c: b               #0xa617d0
    // 0xa61870: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61870: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _doRestore(/* No info */) {
    // ** addr: 0xa61874, size: 0x50
    // 0xa61874: EnterFrame
    //     0xa61874: stp             fp, lr, [SP, #-0x10]!
    //     0xa61878: mov             fp, SP
    // 0xa6187c: CheckStackOverflow
    //     0xa6187c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61880: cmp             SP, x16
    //     0xa61884: b.ls            #0xa618bc
    // 0xa61888: ldr             x0, [fp, #0x10]
    // 0xa6188c: LoadField: r1 = r0->field_23
    //     0xa6188c: ldur            w1, [x0, #0x23]
    // 0xa61890: DecompressPointer r1
    //     0xa61890: add             x1, x1, HEAP, lsl #32
    // 0xa61894: stp             x1, x0, [SP, #-0x10]!
    // 0xa61898: r0 = restoreState()
    //     0xa61898: bl              #0xa618c4  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::restoreState
    // 0xa6189c: add             SP, SP, #0x10
    // 0xa618a0: ldr             x2, [fp, #0x10]
    // 0xa618a4: r1 = false
    //     0xa618a4: add             x1, NULL, #0x30  ; false
    // 0xa618a8: StoreField: r2->field_23 = r1
    //     0xa618a8: stur            w1, [x2, #0x23]
    // 0xa618ac: r0 = Null
    //     0xa618ac: mov             x0, NULL
    // 0xa618b0: LeaveFrame
    //     0xa618b0: mov             SP, fp
    //     0xa618b4: ldp             fp, lr, [SP], #0x10
    // 0xa618b8: ret
    //     0xa618b8: ret             
    // 0xa618bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa618bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa618c0: b               #0xa61888
  }
  _ registerForRestoration(/* No info */) {
    // ** addr: 0xa61938, size: 0xfc
    // 0xa61938: EnterFrame
    //     0xa61938: stp             fp, lr, [SP, #-0x10]!
    //     0xa6193c: mov             fp, SP
    // 0xa61940: AllocStack(0x20)
    //     0xa61940: sub             SP, SP, #0x20
    // 0xa61944: CheckStackOverflow
    //     0xa61944: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61948: cmp             SP, x16
    //     0xa6194c: b.ls            #0xa61a2c
    // 0xa61950: r1 = 2
    //     0xa61950: mov             x1, #2
    // 0xa61954: r0 = AllocateContext()
    //     0xa61954: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa61958: mov             x1, x0
    // 0xa6195c: ldr             x0, [fp, #0x20]
    // 0xa61960: stur            x1, [fp, #-0x10]
    // 0xa61964: StoreField: r1->field_f = r0
    //     0xa61964: stur            w0, [x1, #0xf]
    // 0xa61968: ldr             x2, [fp, #0x18]
    // 0xa6196c: StoreField: r1->field_13 = r2
    //     0xa6196c: stur            w2, [x1, #0x13]
    // 0xa61970: LoadField: r3 = r2->field_37
    //     0xa61970: ldur            w3, [x2, #0x37]
    // 0xa61974: DecompressPointer r3
    //     0xa61974: add             x3, x3, HEAP, lsl #32
    // 0xa61978: stur            x3, [fp, #-8]
    // 0xa6197c: LoadField: r4 = r2->field_2b
    //     0xa6197c: ldur            w4, [x2, #0x2b]
    // 0xa61980: DecompressPointer r4
    //     0xa61980: add             x4, x4, HEAP, lsl #32
    // 0xa61984: cmp             w4, NULL
    // 0xa61988: b.ne            #0xa61a00
    // 0xa6198c: ldr             x16, [fp, #0x10]
    // 0xa61990: stp             x16, x2, [SP, #-0x10]!
    // 0xa61994: SaveReg r0
    //     0xa61994: str             x0, [SP, #-8]!
    // 0xa61998: r0 = _register()
    //     0xa61998: bl              #0xa600bc  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::_register
    // 0xa6199c: add             SP, SP, #0x18
    // 0xa619a0: ldur            x0, [fp, #-0x10]
    // 0xa619a4: LoadField: r3 = r0->field_13
    //     0xa619a4: ldur            w3, [x0, #0x13]
    // 0xa619a8: DecompressPointer r3
    //     0xa619a8: add             x3, x3, HEAP, lsl #32
    // 0xa619ac: mov             x2, x0
    // 0xa619b0: stur            x3, [fp, #-0x18]
    // 0xa619b4: r1 = Function 'listener':.
    //     0xa619b4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22030] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xa619b8: ldr             x1, [x1, #0x30]
    // 0xa619bc: r0 = AllocateClosure()
    //     0xa619bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa619c0: stur            x0, [fp, #-0x20]
    // 0xa619c4: ldur            x16, [fp, #-0x18]
    // 0xa619c8: stp             x0, x16, [SP, #-0x10]!
    // 0xa619cc: r0 = addListener()
    //     0xa619cc: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xa619d0: add             SP, SP, #0x10
    // 0xa619d4: ldr             x0, [fp, #0x20]
    // 0xa619d8: LoadField: r1 = r0->field_1f
    //     0xa619d8: ldur            w1, [x0, #0x1f]
    // 0xa619dc: DecompressPointer r1
    //     0xa619dc: add             x1, x1, HEAP, lsl #32
    // 0xa619e0: ldur            x0, [fp, #-0x10]
    // 0xa619e4: LoadField: r2 = r0->field_13
    //     0xa619e4: ldur            w2, [x0, #0x13]
    // 0xa619e8: DecompressPointer r2
    //     0xa619e8: add             x2, x2, HEAP, lsl #32
    // 0xa619ec: stp             x2, x1, [SP, #-0x10]!
    // 0xa619f0: ldur            x16, [fp, #-0x20]
    // 0xa619f4: SaveReg r16
    //     0xa619f4: str             x16, [SP, #-8]!
    // 0xa619f8: r0 = []=()
    //     0xa619f8: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xa619fc: add             SP, SP, #0x18
    // 0xa61a00: ldur            x0, [fp, #-0x10]
    // 0xa61a04: LoadField: r1 = r0->field_13
    //     0xa61a04: ldur            w1, [x0, #0x13]
    // 0xa61a08: DecompressPointer r1
    //     0xa61a08: add             x1, x1, HEAP, lsl #32
    // 0xa61a0c: ldur            x16, [fp, #-8]
    // 0xa61a10: stp             x16, x1, [SP, #-0x10]!
    // 0xa61a14: r0 = initWithValue()
    //     0xa61a14: bl              #0xc3b8d4  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableValue::initWithValue
    // 0xa61a18: add             SP, SP, #0x10
    // 0xa61a1c: r0 = Null
    //     0xa61a1c: mov             x0, NULL
    // 0xa61a20: LeaveFrame
    //     0xa61a20: mov             SP, fp
    //     0xa61a24: ldp             fp, lr, [SP], #0x10
    // 0xa61a28: ret
    //     0xa61a28: ret             
    // 0xa61a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61a30: b               #0xa61950
  }
  _ _updateBucketIfNecessary(/* No info */) {
    // ** addr: 0xa61a34, size: 0x54
    // 0xa61a34: EnterFrame
    //     0xa61a34: stp             fp, lr, [SP, #-0x10]!
    //     0xa61a38: mov             fp, SP
    // 0xa61a3c: CheckStackOverflow
    //     0xa61a3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61a40: cmp             SP, x16
    //     0xa61a44: b.ls            #0xa61a7c
    // 0xa61a48: ldr             x0, [fp, #0x20]
    // 0xa61a4c: LoadField: r1 = r0->field_b
    //     0xa61a4c: ldur            w1, [x0, #0xb]
    // 0xa61a50: DecompressPointer r1
    //     0xa61a50: add             x1, x1, HEAP, lsl #32
    // 0xa61a54: cmp             w1, NULL
    // 0xa61a58: b.eq            #0xa61a84
    // 0xa61a5c: stp             NULL, x0, [SP, #-0x10]!
    // 0xa61a60: ldr             x16, [fp, #0x10]
    // 0xa61a64: SaveReg r16
    //     0xa61a64: str             x16, [SP, #-8]!
    // 0xa61a68: r0 = _simpleInstanceOfFalse()
    //     0xa61a68: bl              #0xd67368  ; [dart:core] Object::_simpleInstanceOfFalse
    // 0xa61a6c: add             SP, SP, #0x18
    // 0xa61a70: LeaveFrame
    //     0xa61a70: mov             SP, fp
    //     0xa61a74: ldp             fp, lr, [SP], #0x10
    // 0xa61a78: ret
    //     0xa61a78: ret             
    // 0xa61a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61a7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61a80: b               #0xa61a48
    // 0xa61a84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61a84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ restorePending(/* No info */) {
    // ** addr: 0xa61a88, size: 0x4c
    // 0xa61a88: EnterFrame
    //     0xa61a88: stp             fp, lr, [SP, #-0x10]!
    //     0xa61a8c: mov             fp, SP
    // 0xa61a90: ldr             x1, [fp, #0x10]
    // 0xa61a94: LoadField: r2 = r1->field_23
    //     0xa61a94: ldur            w2, [x1, #0x23]
    // 0xa61a98: DecompressPointer r2
    //     0xa61a98: add             x2, x2, HEAP, lsl #32
    // 0xa61a9c: tbnz            w2, #4, #0xa61ab0
    // 0xa61aa0: r0 = true
    //     0xa61aa0: add             x0, NULL, #0x20  ; true
    // 0xa61aa4: LeaveFrame
    //     0xa61aa4: mov             SP, fp
    //     0xa61aa8: ldp             fp, lr, [SP], #0x10
    // 0xa61aac: ret
    //     0xa61aac: ret             
    // 0xa61ab0: LoadField: r2 = r1->field_b
    //     0xa61ab0: ldur            w2, [x1, #0xb]
    // 0xa61ab4: DecompressPointer r2
    //     0xa61ab4: add             x2, x2, HEAP, lsl #32
    // 0xa61ab8: cmp             w2, NULL
    // 0xa61abc: b.eq            #0xa61ad0
    // 0xa61ac0: r0 = false
    //     0xa61ac0: add             x0, NULL, #0x30  ; false
    // 0xa61ac4: LeaveFrame
    //     0xa61ac4: mov             SP, fp
    //     0xa61ac8: ldp             fp, lr, [SP], #0x10
    // 0xa61acc: ret
    //     0xa61acc: ret             
    // 0xa61ad0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61ad0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3281, size: 0x80, field offset: 0x2c
class ScaffoldState extends _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin {

  late AnimationController _floatingActionButtonMoveController; // offset: 0x60
  late FloatingActionButtonAnimator _floatingActionButtonAnimator; // offset: 0x64
  late _ScaffoldGeometryNotifier _geometryNotifier; // offset: 0x74
  late AnimationController _floatingActionButtonVisibilityController; // offset: 0x70

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7ba69c, size: 0x130
    // 0x7ba69c: EnterFrame
    //     0x7ba69c: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba6a0: mov             fp, SP
    // 0x7ba6a4: AllocStack(0x8)
    //     0x7ba6a4: sub             SP, SP, #8
    // 0x7ba6a8: CheckStackOverflow
    //     0x7ba6a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba6ac: cmp             SP, x16
    //     0x7ba6b0: b.ls            #0x7ba7bc
    // 0x7ba6b4: ldr             x0, [fp, #0x10]
    // 0x7ba6b8: r2 = Null
    //     0x7ba6b8: mov             x2, NULL
    // 0x7ba6bc: r1 = Null
    //     0x7ba6bc: mov             x1, NULL
    // 0x7ba6c0: r4 = 59
    //     0x7ba6c0: mov             x4, #0x3b
    // 0x7ba6c4: branchIfSmi(r0, 0x7ba6d0)
    //     0x7ba6c4: tbz             w0, #0, #0x7ba6d0
    // 0x7ba6c8: r4 = LoadClassIdInstr(r0)
    //     0x7ba6c8: ldur            x4, [x0, #-1]
    //     0x7ba6cc: ubfx            x4, x4, #0xc, #0x14
    // 0x7ba6d0: r17 = 4124
    //     0x7ba6d0: mov             x17, #0x101c
    // 0x7ba6d4: cmp             x4, x17
    // 0x7ba6d8: b.eq            #0x7ba6f0
    // 0x7ba6dc: r8 = Scaffold
    //     0x7ba6dc: add             x8, PP, #0x21, lsl #12  ; [pp+0x21fd0] Type: Scaffold
    //     0x7ba6e0: ldr             x8, [x8, #0xfd0]
    // 0x7ba6e4: r3 = Null
    //     0x7ba6e4: add             x3, PP, #0x21, lsl #12  ; [pp+0x21fd8] Null
    //     0x7ba6e8: ldr             x3, [x3, #0xfd8]
    // 0x7ba6ec: r0 = Scaffold()
    //     0x7ba6ec: bl              #0x6188e0  ; IsType_Scaffold_Stub
    // 0x7ba6f0: ldr             x16, [fp, #0x18]
    // 0x7ba6f4: ldr             lr, [fp, #0x10]
    // 0x7ba6f8: stp             lr, x16, [SP, #-0x10]!
    // 0x7ba6fc: r0 = didUpdateWidget()
    //     0x7ba6fc: bl              #0x7bbbb4  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::didUpdateWidget
    // 0x7ba700: add             SP, SP, #0x10
    // 0x7ba704: ldr             x1, [fp, #0x18]
    // 0x7ba708: LoadField: r0 = r1->field_b
    //     0x7ba708: ldur            w0, [x1, #0xb]
    // 0x7ba70c: DecompressPointer r0
    //     0x7ba70c: add             x0, x0, HEAP, lsl #32
    // 0x7ba710: cmp             w0, NULL
    // 0x7ba714: b.eq            #0x7ba7c4
    // 0x7ba718: LoadField: r2 = r0->field_4b
    //     0x7ba718: ldur            w2, [x0, #0x4b]
    // 0x7ba71c: DecompressPointer r2
    //     0x7ba71c: add             x2, x2, HEAP, lsl #32
    // 0x7ba720: ldr             x0, [fp, #0x10]
    // 0x7ba724: LoadField: r3 = r0->field_4b
    //     0x7ba724: ldur            w3, [x0, #0x4b]
    // 0x7ba728: DecompressPointer r3
    //     0x7ba728: add             x3, x3, HEAP, lsl #32
    // 0x7ba72c: stur            x3, [fp, #-8]
    // 0x7ba730: r0 = LoadClassIdInstr(r2)
    //     0x7ba730: ldur            x0, [x2, #-1]
    //     0x7ba734: ubfx            x0, x0, #0xc, #0x14
    // 0x7ba738: stp             x3, x2, [SP, #-0x10]!
    // 0x7ba73c: mov             lr, x0
    // 0x7ba740: ldr             lr, [x21, lr, lsl #3]
    // 0x7ba744: blr             lr
    // 0x7ba748: add             SP, SP, #0x10
    // 0x7ba74c: tbz             w0, #4, #0x7ba7ac
    // 0x7ba750: ldr             x0, [fp, #0x18]
    // 0x7ba754: LoadField: r1 = r0->field_b
    //     0x7ba754: ldur            w1, [x0, #0xb]
    // 0x7ba758: DecompressPointer r1
    //     0x7ba758: add             x1, x1, HEAP, lsl #32
    // 0x7ba75c: cmp             w1, NULL
    // 0x7ba760: b.eq            #0x7ba7c8
    // 0x7ba764: LoadField: r2 = r1->field_4b
    //     0x7ba764: ldur            w2, [x1, #0x4b]
    // 0x7ba768: DecompressPointer r2
    //     0x7ba768: add             x2, x2, HEAP, lsl #32
    // 0x7ba76c: cmp             w2, NULL
    // 0x7ba770: b.ne            #0x7ba784
    // 0x7ba774: SaveReg r0
    //     0x7ba774: str             x0, [SP, #-8]!
    // 0x7ba778: r0 = _closeCurrentBottomSheet()
    //     0x7ba778: bl              #0x7bbb4c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_closeCurrentBottomSheet
    // 0x7ba77c: add             SP, SP, #8
    // 0x7ba780: b               #0x7ba7ac
    // 0x7ba784: ldur            x1, [fp, #-8]
    // 0x7ba788: cmp             w1, NULL
    // 0x7ba78c: b.ne            #0x7ba7a0
    // 0x7ba790: SaveReg r0
    //     0x7ba790: str             x0, [SP, #-8]!
    // 0x7ba794: r0 = _maybeBuildPersistentBottomSheet()
    //     0x7ba794: bl              #0x7ba864  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet
    // 0x7ba798: add             SP, SP, #8
    // 0x7ba79c: b               #0x7ba7ac
    // 0x7ba7a0: SaveReg r0
    //     0x7ba7a0: str             x0, [SP, #-8]!
    // 0x7ba7a4: r0 = _updatePersistentBottomSheet()
    //     0x7ba7a4: bl              #0x7ba7ec  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_updatePersistentBottomSheet
    // 0x7ba7a8: add             SP, SP, #8
    // 0x7ba7ac: r0 = Null
    //     0x7ba7ac: mov             x0, NULL
    // 0x7ba7b0: LeaveFrame
    //     0x7ba7b0: mov             SP, fp
    //     0x7ba7b4: ldp             fp, lr, [SP], #0x10
    // 0x7ba7b8: ret
    //     0x7ba7b8: ret             
    // 0x7ba7bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ba7bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ba7c0: b               #0x7ba6b4
    // 0x7ba7c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ba7c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7ba7c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ba7c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updatePersistentBottomSheet(/* No info */) {
    // ** addr: 0x7ba7ec, size: 0x78
    // 0x7ba7ec: EnterFrame
    //     0x7ba7ec: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba7f0: mov             fp, SP
    // 0x7ba7f4: AllocStack(0x8)
    //     0x7ba7f4: sub             SP, SP, #8
    // 0x7ba7f8: CheckStackOverflow
    //     0x7ba7f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba7fc: cmp             SP, x16
    //     0x7ba800: b.ls            #0x7ba858
    // 0x7ba804: ldr             x0, [fp, #0x10]
    // 0x7ba808: LoadField: r1 = r0->field_57
    //     0x7ba808: ldur            w1, [x0, #0x57]
    // 0x7ba80c: DecompressPointer r1
    //     0x7ba80c: add             x1, x1, HEAP, lsl #32
    // 0x7ba810: SaveReg r1
    //     0x7ba810: str             x1, [SP, #-8]!
    // 0x7ba814: r0 = currentState()
    //     0x7ba814: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x7ba818: add             SP, SP, #8
    // 0x7ba81c: stur            x0, [fp, #-8]
    // 0x7ba820: cmp             w0, NULL
    // 0x7ba824: b.eq            #0x7ba860
    // 0x7ba828: r1 = Function '<anonymous closure>':.
    //     0x7ba828: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fe8] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7ba82c: ldr             x1, [x1, #0xfe8]
    // 0x7ba830: r2 = Null
    //     0x7ba830: mov             x2, NULL
    // 0x7ba834: r0 = AllocateClosure()
    //     0x7ba834: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7ba838: ldur            x16, [fp, #-8]
    // 0x7ba83c: stp             x0, x16, [SP, #-0x10]!
    // 0x7ba840: r0 = setState()
    //     0x7ba840: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7ba844: add             SP, SP, #0x10
    // 0x7ba848: r0 = Null
    //     0x7ba848: mov             x0, NULL
    // 0x7ba84c: LeaveFrame
    //     0x7ba84c: mov             SP, fp
    //     0x7ba850: ldp             fp, lr, [SP], #0x10
    // 0x7ba854: ret
    //     0x7ba854: ret             
    // 0x7ba858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ba858: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ba85c: b               #0x7ba804
    // 0x7ba860: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ba860: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _maybeBuildPersistentBottomSheet(/* No info */) {
    // ** addr: 0x7ba864, size: 0x2c8
    // 0x7ba864: EnterFrame
    //     0x7ba864: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba868: mov             fp, SP
    // 0x7ba86c: AllocStack(0x40)
    //     0x7ba86c: sub             SP, SP, #0x40
    // 0x7ba870: CheckStackOverflow
    //     0x7ba870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba874: cmp             SP, x16
    //     0x7ba878: b.ls            #0x7bab10
    // 0x7ba87c: r1 = 2
    //     0x7ba87c: mov             x1, #2
    // 0x7ba880: r0 = AllocateContext()
    //     0x7ba880: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7ba884: mov             x1, x0
    // 0x7ba888: ldr             x0, [fp, #0x10]
    // 0x7ba88c: stur            x1, [fp, #-8]
    // 0x7ba890: StoreField: r1->field_f = r0
    //     0x7ba890: stur            w0, [x1, #0xf]
    // 0x7ba894: LoadField: r2 = r0->field_b
    //     0x7ba894: ldur            w2, [x0, #0xb]
    // 0x7ba898: DecompressPointer r2
    //     0x7ba898: add             x2, x2, HEAP, lsl #32
    // 0x7ba89c: cmp             w2, NULL
    // 0x7ba8a0: b.eq            #0x7bab18
    // 0x7ba8a4: LoadField: r3 = r2->field_4b
    //     0x7ba8a4: ldur            w3, [x2, #0x4b]
    // 0x7ba8a8: DecompressPointer r3
    //     0x7ba8a8: add             x3, x3, HEAP, lsl #32
    // 0x7ba8ac: cmp             w3, NULL
    // 0x7ba8b0: b.eq            #0x7bab00
    // 0x7ba8b4: LoadField: r2 = r0->field_53
    //     0x7ba8b4: ldur            w2, [x0, #0x53]
    // 0x7ba8b8: DecompressPointer r2
    //     0x7ba8b8: add             x2, x2, HEAP, lsl #32
    // 0x7ba8bc: cmp             w2, NULL
    // 0x7ba8c0: b.ne            #0x7bab00
    // 0x7ba8c4: SaveReg r0
    //     0x7ba8c4: str             x0, [SP, #-8]!
    // 0x7ba8c8: r0 = createAnimationController()
    //     0x7ba8c8: bl              #0x7bb700  ; [package:flutter/src/material/bottom_sheet.dart] BottomSheet::createAnimationController
    // 0x7ba8cc: add             SP, SP, #8
    // 0x7ba8d0: stur            x0, [fp, #-0x10]
    // 0x7ba8d4: SaveReg r0
    //     0x7ba8d4: str             x0, [SP, #-8]!
    // 0x7ba8d8: d0 = 1.000000
    //     0x7ba8d8: fmov            d0, #1.00000000
    // 0x7ba8dc: SaveReg d0
    //     0x7ba8dc: str             d0, [SP, #-8]!
    // 0x7ba8e0: r0 = value=()
    //     0x7ba8e0: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x7ba8e4: add             SP, SP, #0x10
    // 0x7ba8e8: ldur            x2, [fp, #-8]
    // 0x7ba8ec: r1 = Function 'persistentBottomSheetExtentChanged':.
    //     0x7ba8ec: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ed8] AnonymousClosure: (0x7bbadc), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet (0x7ba864)
    //     0x7ba8f0: ldr             x1, [x1, #0xed8]
    // 0x7ba8f4: r0 = AllocateClosure()
    //     0x7ba8f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7ba8f8: ldur            x3, [fp, #-8]
    // 0x7ba8fc: StoreField: r3->field_13 = r0
    //     0x7ba8fc: stur            w0, [x3, #0x13]
    //     0x7ba900: ldurb           w16, [x3, #-1]
    //     0x7ba904: ldurb           w17, [x0, #-1]
    //     0x7ba908: and             x16, x17, x16, lsr #2
    //     0x7ba90c: tst             x16, HEAP, lsr #32
    //     0x7ba910: b.eq            #0x7ba918
    //     0x7ba914: bl              #0xd682ac
    // 0x7ba918: ldr             x0, [fp, #0x10]
    // 0x7ba91c: LoadField: r4 = r0->field_4f
    //     0x7ba91c: ldur            w4, [x0, #0x4f]
    // 0x7ba920: DecompressPointer r4
    //     0x7ba920: add             x4, x4, HEAP, lsl #32
    // 0x7ba924: stur            x4, [fp, #-0x20]
    // 0x7ba928: LoadField: r5 = r4->field_b
    //     0x7ba928: ldur            w5, [x4, #0xb]
    // 0x7ba92c: DecompressPointer r5
    //     0x7ba92c: add             x5, x5, HEAP, lsl #32
    // 0x7ba930: stur            x5, [fp, #-0x18]
    // 0x7ba934: cbz             w5, #0x7baaac
    // 0x7ba938: mov             x2, x5
    // 0x7ba93c: r1 = <_StandardBottomSheet>
    //     0x7ba93c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cfb0] TypeArguments: <_StandardBottomSheet>
    //     0x7ba940: ldr             x1, [x1, #0xfb0]
    // 0x7ba944: r0 = AllocateArray()
    //     0x7ba944: bl              #0xd6987c  ; AllocateArrayStub
    // 0x7ba948: mov             x3, x0
    // 0x7ba94c: ldur            x0, [fp, #-0x18]
    // 0x7ba950: stur            x3, [fp, #-0x40]
    // 0x7ba954: r4 = LoadInt32Instr(r0)
    //     0x7ba954: sbfx            x4, x0, #1, #0x1f
    // 0x7ba958: stur            x4, [fp, #-0x38]
    // 0x7ba95c: cmp             x4, #0
    // 0x7ba960: b.le            #0x7baa24
    // 0x7ba964: ldur            x0, [fp, #-0x20]
    // 0x7ba968: LoadField: r5 = r0->field_f
    //     0x7ba968: ldur            w5, [x0, #0xf]
    // 0x7ba96c: DecompressPointer r5
    //     0x7ba96c: add             x5, x5, HEAP, lsl #32
    // 0x7ba970: stur            x5, [fp, #-0x30]
    // 0x7ba974: r6 = 0
    //     0x7ba974: mov             x6, #0
    // 0x7ba978: stur            x6, [fp, #-0x28]
    // 0x7ba97c: CheckStackOverflow
    //     0x7ba97c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba980: cmp             SP, x16
    //     0x7ba984: b.ls            #0x7bab1c
    // 0x7ba988: cmp             x6, x4
    // 0x7ba98c: b.ge            #0x7baa24
    // 0x7ba990: ArrayLoad: r7 = r5[r6]  ; Unknown_4
    //     0x7ba990: add             x16, x5, x6, lsl #2
    //     0x7ba994: ldur            w7, [x16, #0xf]
    // 0x7ba998: DecompressPointer r7
    //     0x7ba998: add             x7, x7, HEAP, lsl #32
    // 0x7ba99c: mov             x0, x7
    // 0x7ba9a0: stur            x7, [fp, #-0x18]
    // 0x7ba9a4: r2 = Null
    //     0x7ba9a4: mov             x2, NULL
    // 0x7ba9a8: r1 = Null
    //     0x7ba9a8: mov             x1, NULL
    // 0x7ba9ac: r4 = 59
    //     0x7ba9ac: mov             x4, #0x3b
    // 0x7ba9b0: branchIfSmi(r0, 0x7ba9bc)
    //     0x7ba9b0: tbz             w0, #0, #0x7ba9bc
    // 0x7ba9b4: r4 = LoadClassIdInstr(r0)
    //     0x7ba9b4: ldur            x4, [x0, #-1]
    //     0x7ba9b8: ubfx            x4, x4, #0xc, #0x14
    // 0x7ba9bc: r17 = 4123
    //     0x7ba9bc: mov             x17, #0x101b
    // 0x7ba9c0: cmp             x4, x17
    // 0x7ba9c4: b.eq            #0x7ba9dc
    // 0x7ba9c8: r8 = _StandardBottomSheet
    //     0x7ba9c8: add             x8, PP, #0x21, lsl #12  ; [pp+0x21ee0] Type: _StandardBottomSheet
    //     0x7ba9cc: ldr             x8, [x8, #0xee0]
    // 0x7ba9d0: r3 = Null
    //     0x7ba9d0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21ee8] Null
    //     0x7ba9d4: ldr             x3, [x3, #0xee8]
    // 0x7ba9d8: r0 = _StandardBottomSheet()
    //     0x7ba9d8: bl              #0x7bbab8  ; IsType__StandardBottomSheet_Stub
    // 0x7ba9dc: ldur            x1, [fp, #-0x40]
    // 0x7ba9e0: ldur            x0, [fp, #-0x18]
    // 0x7ba9e4: ldur            x2, [fp, #-0x28]
    // 0x7ba9e8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7ba9e8: add             x25, x1, x2, lsl #2
    //     0x7ba9ec: add             x25, x25, #0xf
    //     0x7ba9f0: str             w0, [x25]
    //     0x7ba9f4: tbz             w0, #0, #0x7baa10
    //     0x7ba9f8: ldurb           w16, [x1, #-1]
    //     0x7ba9fc: ldurb           w17, [x0, #-1]
    //     0x7baa00: and             x16, x17, x16, lsr #2
    //     0x7baa04: tst             x16, HEAP, lsr #32
    //     0x7baa08: b.eq            #0x7baa10
    //     0x7baa0c: bl              #0xd67e5c
    // 0x7baa10: add             x6, x2, #1
    // 0x7baa14: ldur            x5, [fp, #-0x30]
    // 0x7baa18: ldur            x3, [fp, #-0x40]
    // 0x7baa1c: ldur            x4, [fp, #-0x38]
    // 0x7baa20: b               #0x7ba978
    // 0x7baa24: ldur            x16, [fp, #-0x40]
    // 0x7baa28: SaveReg r16
    //     0x7baa28: str             x16, [SP, #-8]!
    // 0x7baa2c: r0 = iterator()
    //     0x7baa2c: bl              #0x9bb0c0  ; [dart:core] _Array::iterator
    // 0x7baa30: add             SP, SP, #8
    // 0x7baa34: mov             x1, x0
    // 0x7baa38: stur            x1, [fp, #-0x18]
    // 0x7baa3c: CheckStackOverflow
    //     0x7baa3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7baa40: cmp             SP, x16
    //     0x7baa44: b.ls            #0x7bab24
    // 0x7baa48: r0 = LoadClassIdInstr(r1)
    //     0x7baa48: ldur            x0, [x1, #-1]
    //     0x7baa4c: ubfx            x0, x0, #0xc, #0x14
    // 0x7baa50: SaveReg r1
    //     0x7baa50: str             x1, [SP, #-8]!
    // 0x7baa54: r0 = GDT[cid_x0 + 0x541]()
    //     0x7baa54: add             lr, x0, #0x541
    //     0x7baa58: ldr             lr, [x21, lr, lsl #3]
    //     0x7baa5c: blr             lr
    // 0x7baa60: add             SP, SP, #8
    // 0x7baa64: tbnz            w0, #4, #0x7baaac
    // 0x7baa68: ldur            x1, [fp, #-0x18]
    // 0x7baa6c: r0 = LoadClassIdInstr(r1)
    //     0x7baa6c: ldur            x0, [x1, #-1]
    //     0x7baa70: ubfx            x0, x0, #0xc, #0x14
    // 0x7baa74: SaveReg r1
    //     0x7baa74: str             x1, [SP, #-8]!
    // 0x7baa78: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x7baa78: add             lr, x0, #0x5ca
    //     0x7baa7c: ldr             lr, [x21, lr, lsl #3]
    //     0x7baa80: blr             lr
    // 0x7baa84: add             SP, SP, #8
    // 0x7baa88: LoadField: r1 = r0->field_b
    //     0x7baa88: ldur            w1, [x0, #0xb]
    // 0x7baa8c: DecompressPointer r1
    //     0x7baa8c: add             x1, x1, HEAP, lsl #32
    // 0x7baa90: LoadField: d0 = r1->field_13
    //     0x7baa90: ldur            d0, [x1, #0x13]
    // 0x7baa94: SaveReg r1
    //     0x7baa94: str             x1, [SP, #-8]!
    // 0x7baa98: SaveReg d0
    //     0x7baa98: str             d0, [SP, #-8]!
    // 0x7baa9c: r0 = value=()
    //     0x7baa9c: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x7baaa0: add             SP, SP, #0x10
    // 0x7baaa4: ldur            x1, [fp, #-0x18]
    // 0x7baaa8: b               #0x7baa3c
    // 0x7baaac: ldr             x0, [fp, #0x10]
    // 0x7baab0: ldur            x2, [fp, #-8]
    // 0x7baab4: r1 = Function '<anonymous closure>':.
    //     0x7baab4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ef8] AnonymousClosure: (0x7bb78c), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet (0x7ba864)
    //     0x7baab8: ldr             x1, [x1, #0xef8]
    // 0x7baabc: r0 = AllocateClosure()
    //     0x7baabc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7baac0: r16 = <void?>
    //     0x7baac0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7baac4: ldr             lr, [fp, #0x10]
    // 0x7baac8: stp             lr, x16, [SP, #-0x10]!
    // 0x7baacc: ldur            x16, [fp, #-0x10]
    // 0x7baad0: stp             x16, x0, [SP, #-0x10]!
    // 0x7baad4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x7baad4: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x7baad8: r0 = _buildBottomSheet()
    //     0x7baad8: bl              #0x7bab2c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet
    // 0x7baadc: add             SP, SP, #0x20
    // 0x7baae0: ldr             x1, [fp, #0x10]
    // 0x7baae4: StoreField: r1->field_53 = r0
    //     0x7baae4: stur            w0, [x1, #0x53]
    //     0x7baae8: ldurb           w16, [x1, #-1]
    //     0x7baaec: ldurb           w17, [x0, #-1]
    //     0x7baaf0: and             x16, x17, x16, lsr #2
    //     0x7baaf4: tst             x16, HEAP, lsr #32
    //     0x7baaf8: b.eq            #0x7bab00
    //     0x7baafc: bl              #0xd6826c
    // 0x7bab00: r0 = Null
    //     0x7bab00: mov             x0, NULL
    // 0x7bab04: LeaveFrame
    //     0x7bab04: mov             SP, fp
    //     0x7bab08: ldp             fp, lr, [SP], #0x10
    // 0x7bab0c: ret
    //     0x7bab0c: ret             
    // 0x7bab10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bab10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bab14: b               #0x7ba87c
    // 0x7bab18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bab18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bab1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bab1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bab20: b               #0x7ba988
    // 0x7bab24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bab24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bab28: b               #0x7baa48
  }
  _ _buildBottomSheet(/* No info */) {
    // ** addr: 0x7bab2c, size: 0x288
    // 0x7bab2c: EnterFrame
    //     0x7bab2c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bab30: mov             fp, SP
    // 0x7bab34: AllocStack(0x50)
    //     0x7bab34: sub             SP, SP, #0x50
    // 0x7bab38: SetupParameters()
    //     0x7bab38: mov             x0, x4
    //     0x7bab3c: ldur            w1, [x0, #0xf]
    //     0x7bab40: add             x1, x1, HEAP, lsl #32
    //     0x7bab44: cbnz            w1, #0x7bab50
    //     0x7bab48: mov             x3, NULL
    //     0x7bab4c: b               #0x7bab64
    //     0x7bab50: ldur            w1, [x0, #0x17]
    //     0x7bab54: add             x1, x1, HEAP, lsl #32
    //     0x7bab58: add             x0, fp, w1, sxtw #2
    //     0x7bab5c: ldr             x0, [x0, #0x10]
    //     0x7bab60: mov             x3, x0
    //     0x7bab64: ldr             x2, [fp, #0x20]
    //     0x7bab68: ldr             x1, [fp, #0x18]
    //     0x7bab6c: ldr             x0, [fp, #0x10]
    //     0x7bab70: stur            x3, [fp, #-8]
    // 0x7bab74: CheckStackOverflow
    //     0x7bab74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bab78: cmp             SP, x16
    //     0x7bab7c: b.ls            #0x7badac
    // 0x7bab80: r1 = 11
    //     0x7bab80: mov             x1, #0xb
    // 0x7bab84: r0 = AllocateContext()
    //     0x7bab84: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bab88: mov             x2, x0
    // 0x7bab8c: ldr             x0, [fp, #0x20]
    // 0x7bab90: stur            x2, [fp, #-0x10]
    // 0x7bab94: StoreField: r2->field_f = r0
    //     0x7bab94: stur            w0, [x2, #0xf]
    // 0x7bab98: ldr             x0, [fp, #0x10]
    // 0x7bab9c: StoreField: r2->field_13 = r0
    //     0x7bab9c: stur            w0, [x2, #0x13]
    // 0x7baba0: ldur            x1, [fp, #-8]
    // 0x7baba4: r0 = _Future()
    //     0x7baba4: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7baba8: mov             x1, x0
    // 0x7babac: r0 = 0
    //     0x7babac: mov             x0, #0
    // 0x7babb0: stur            x1, [fp, #-0x18]
    // 0x7babb4: StoreField: r1->field_b = r0
    //     0x7babb4: stur            x0, [x1, #0xb]
    // 0x7babb8: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7babb8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7babbc: ldr             x0, [x0, #0xb58]
    //     0x7babc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7babc4: cmp             w0, w16
    //     0x7babc8: b.ne            #0x7babd4
    //     0x7babcc: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7babd0: bl              #0xd67d44
    // 0x7babd4: mov             x1, x0
    // 0x7babd8: ldur            x0, [fp, #-0x18]
    // 0x7babdc: StoreField: r0->field_13 = r1
    //     0x7babdc: stur            w1, [x0, #0x13]
    // 0x7babe0: ldur            x1, [fp, #-8]
    // 0x7babe4: r0 = _AsyncCompleter()
    //     0x7babe4: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x7babe8: mov             x2, x0
    // 0x7babec: ldur            x0, [fp, #-0x18]
    // 0x7babf0: stur            x2, [fp, #-0x20]
    // 0x7babf4: StoreField: r2->field_b = r0
    //     0x7babf4: stur            w0, [x2, #0xb]
    // 0x7babf8: ldur            x0, [fp, #-0x10]
    // 0x7babfc: StoreField: r0->field_17 = r2
    //     0x7babfc: stur            w2, [x0, #0x17]
    // 0x7bac00: r1 = <_StandardBottomSheetState<_StandardBottomSheet>>
    //     0x7bac00: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f30] TypeArguments: <_StandardBottomSheetState<_StandardBottomSheet>>
    //     0x7bac04: ldr             x1, [x1, #0xf30]
    // 0x7bac08: r0 = LabeledGlobalKey()
    //     0x7bac08: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0x7bac0c: mov             x3, x0
    // 0x7bac10: ldur            x0, [fp, #-0x10]
    // 0x7bac14: stur            x3, [fp, #-0x18]
    // 0x7bac18: StoreField: r0->field_1b = r3
    //     0x7bac18: stur            w3, [x0, #0x1b]
    // 0x7bac1c: r1 = Sentinel
    //     0x7bac1c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bac20: StoreField: r0->field_1f = r1
    //     0x7bac20: stur            w1, [x0, #0x1f]
    // 0x7bac24: r4 = false
    //     0x7bac24: add             x4, NULL, #0x30  ; false
    // 0x7bac28: StoreField: r0->field_23 = r4
    //     0x7bac28: stur            w4, [x0, #0x23]
    // 0x7bac2c: StoreField: r0->field_27 = r4
    //     0x7bac2c: stur            w4, [x0, #0x27]
    // 0x7bac30: mov             x2, x0
    // 0x7bac34: r1 = Function 'removePersistentSheetHistoryEntryIfNeeded':.
    //     0x7bac34: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f38] AnonymousClosure: (0x7bb3d8), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0x7bab2c)
    //     0x7bac38: ldr             x1, [x1, #0xf38]
    // 0x7bac3c: r0 = AllocateClosure()
    //     0x7bac3c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bac40: mov             x1, x0
    // 0x7bac44: ldur            x0, [fp, #-8]
    // 0x7bac48: StoreField: r1->field_b = r0
    //     0x7bac48: stur            w0, [x1, #0xb]
    // 0x7bac4c: ldur            x3, [fp, #-0x10]
    // 0x7bac50: StoreField: r3->field_2b = r1
    //     0x7bac50: stur            w1, [x3, #0x2b]
    // 0x7bac54: mov             x2, x3
    // 0x7bac58: r1 = Function 'removeCurrentBottomSheet':.
    //     0x7bac58: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f40] AnonymousClosure: (0x7bb040), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0x7bab2c)
    //     0x7bac5c: ldr             x1, [x1, #0xf40]
    // 0x7bac60: r0 = AllocateClosure()
    //     0x7bac60: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bac64: mov             x3, x0
    // 0x7bac68: ldur            x0, [fp, #-8]
    // 0x7bac6c: stur            x3, [fp, #-0x28]
    // 0x7bac70: StoreField: r3->field_b = r0
    //     0x7bac70: stur            w0, [x3, #0xb]
    // 0x7bac74: ldur            x4, [fp, #-0x10]
    // 0x7bac78: StoreField: r4->field_2f = r3
    //     0x7bac78: stur            w3, [x4, #0x2f]
    // 0x7bac7c: mov             x2, x4
    // 0x7bac80: r1 = Function 'removeEntryIfNeeded':.
    //     0x7bac80: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f48] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7bac84: ldr             x1, [x1, #0xf48]
    // 0x7bac88: r0 = AllocateClosure()
    //     0x7bac88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bac8c: mov             x1, x0
    // 0x7bac90: ldur            x0, [fp, #-8]
    // 0x7bac94: StoreField: r1->field_b = r0
    //     0x7bac94: stur            w0, [x1, #0xb]
    // 0x7bac98: ldur            x3, [fp, #-0x10]
    // 0x7bac9c: StoreField: r3->field_37 = r1
    //     0x7bac9c: stur            w1, [x3, #0x37]
    // 0x7baca0: LoadField: r4 = r3->field_13
    //     0x7baca0: ldur            w4, [x3, #0x13]
    // 0x7baca4: DecompressPointer r4
    //     0x7baca4: add             x4, x4, HEAP, lsl #32
    // 0x7baca8: mov             x2, x3
    // 0x7bacac: stur            x4, [fp, #-0x30]
    // 0x7bacb0: r1 = Function '<anonymous closure>':.
    //     0x7bacb0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f50] AnonymousClosure: (0x7bafc4), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0x7bab2c)
    //     0x7bacb4: ldr             x1, [x1, #0xf50]
    // 0x7bacb8: r0 = AllocateClosure()
    //     0x7bacb8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bacbc: mov             x3, x0
    // 0x7bacc0: ldur            x0, [fp, #-8]
    // 0x7bacc4: stur            x3, [fp, #-0x38]
    // 0x7bacc8: StoreField: r3->field_b = r0
    //     0x7bacc8: stur            w0, [x3, #0xb]
    // 0x7baccc: ldur            x2, [fp, #-0x10]
    // 0x7bacd0: r1 = Function '<anonymous closure>':.
    //     0x7bacd0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f58] AnonymousClosure: (0x7bae48), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0x7bab2c)
    //     0x7bacd4: ldr             x1, [x1, #0xf58]
    // 0x7bacd8: r0 = AllocateClosure()
    //     0x7bacd8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bacdc: mov             x3, x0
    // 0x7bace0: ldur            x0, [fp, #-8]
    // 0x7bace4: stur            x3, [fp, #-0x40]
    // 0x7bace8: StoreField: r3->field_b = r0
    //     0x7bace8: stur            w0, [x3, #0xb]
    // 0x7bacec: ldur            x2, [fp, #-0x10]
    // 0x7bacf0: r1 = Function '<anonymous closure>':.
    //     0x7bacf0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f60] AnonymousClosure: (0x7badcc), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0x7bab2c)
    //     0x7bacf4: ldr             x1, [x1, #0xf60]
    // 0x7bacf8: r0 = AllocateClosure()
    //     0x7bacf8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bacfc: ldur            x1, [fp, #-8]
    // 0x7bad00: stur            x0, [fp, #-0x48]
    // 0x7bad04: StoreField: r0->field_b = r1
    //     0x7bad04: stur            w1, [x0, #0xb]
    // 0x7bad08: r0 = _StandardBottomSheet()
    //     0x7bad08: bl              #0x7badc0  ; Allocate_StandardBottomSheetStub -> _StandardBottomSheet (size=0x3c)
    // 0x7bad0c: mov             x4, x0
    // 0x7bad10: ldur            x0, [fp, #-0x30]
    // 0x7bad14: stur            x4, [fp, #-0x50]
    // 0x7bad18: StoreField: r4->field_b = r0
    //     0x7bad18: stur            w0, [x4, #0xb]
    // 0x7bad1c: r0 = false
    //     0x7bad1c: add             x0, NULL, #0x30  ; false
    // 0x7bad20: StoreField: r4->field_f = r0
    //     0x7bad20: stur            w0, [x4, #0xf]
    // 0x7bad24: ldur            x1, [fp, #-0x38]
    // 0x7bad28: StoreField: r4->field_13 = r1
    //     0x7bad28: stur            w1, [x4, #0x13]
    // 0x7bad2c: ldur            x1, [fp, #-0x40]
    // 0x7bad30: StoreField: r4->field_17 = r1
    //     0x7bad30: stur            w1, [x4, #0x17]
    // 0x7bad34: ldr             x1, [fp, #0x18]
    // 0x7bad38: StoreField: r4->field_1f = r1
    //     0x7bad38: stur            w1, [x4, #0x1f]
    // 0x7bad3c: r1 = true
    //     0x7bad3c: add             x1, NULL, #0x20  ; true
    // 0x7bad40: StoreField: r4->field_23 = r1
    //     0x7bad40: stur            w1, [x4, #0x23]
    // 0x7bad44: ldur            x1, [fp, #-0x48]
    // 0x7bad48: StoreField: r4->field_1b = r1
    //     0x7bad48: stur            w1, [x4, #0x1b]
    // 0x7bad4c: ldur            x1, [fp, #-0x18]
    // 0x7bad50: StoreField: r4->field_7 = r1
    //     0x7bad50: stur            w1, [x4, #7]
    // 0x7bad54: ldur            x1, [fp, #-0x10]
    // 0x7bad58: StoreField: r1->field_1f = r4
    //     0x7bad58: stur            w4, [x1, #0x1f]
    // 0x7bad5c: ldur            x1, [fp, #-8]
    // 0x7bad60: r2 = Null
    //     0x7bad60: mov             x2, NULL
    // 0x7bad64: r3 = <_StandardBottomSheet, Y0>
    //     0x7bad64: add             x3, PP, #0x21, lsl #12  ; [pp+0x21f68] TypeArguments: <_StandardBottomSheet, Y0>
    //     0x7bad68: ldr             x3, [x3, #0xf68]
    // 0x7bad6c: r24 = InstantiateTypeArgumentsStub
    //     0x7bad6c: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x7bad70: LoadField: r30 = r24->field_7
    //     0x7bad70: ldur            lr, [x24, #7]
    // 0x7bad74: blr             lr
    // 0x7bad78: mov             x1, x0
    // 0x7bad7c: r0 = PersistentBottomSheetController()
    //     0x7bad7c: bl              #0x7badb4  ; AllocatePersistentBottomSheetControllerStub -> PersistentBottomSheetController<_StandardBottomSheet> (size=0x1c)
    // 0x7bad80: r1 = false
    //     0x7bad80: add             x1, NULL, #0x30  ; false
    // 0x7bad84: StoreField: r0->field_17 = r1
    //     0x7bad84: stur            w1, [x0, #0x17]
    // 0x7bad88: ldur            x1, [fp, #-0x50]
    // 0x7bad8c: StoreField: r0->field_b = r1
    //     0x7bad8c: stur            w1, [x0, #0xb]
    // 0x7bad90: ldur            x1, [fp, #-0x20]
    // 0x7bad94: StoreField: r0->field_f = r1
    //     0x7bad94: stur            w1, [x0, #0xf]
    // 0x7bad98: ldur            x1, [fp, #-0x28]
    // 0x7bad9c: StoreField: r0->field_13 = r1
    //     0x7bad9c: stur            w1, [x0, #0x13]
    // 0x7bada0: LeaveFrame
    //     0x7bada0: mov             SP, fp
    //     0x7bada4: ldp             fp, lr, [SP], #0x10
    // 0x7bada8: ret
    //     0x7bada8: ret             
    // 0x7badac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7badac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7badb0: b               #0x7bab80
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7badcc, size: 0x7c
    // 0x7badcc: EnterFrame
    //     0x7badcc: stp             fp, lr, [SP, #-0x10]!
    //     0x7badd0: mov             fp, SP
    // 0x7badd4: AllocStack(0x8)
    //     0x7badd4: sub             SP, SP, #8
    // 0x7badd8: SetupParameters()
    //     0x7badd8: add             x0, NULL, #0x20  ; true
    //     0x7baddc: ldr             x1, [fp, #0x10]
    //     0x7bade0: ldur            w2, [x1, #0x17]
    //     0x7bade4: add             x2, x2, HEAP, lsl #32
    //     0x7bade8: stur            x2, [fp, #-8]
    // 0x7badd8: r0 = true
    // 0x7badec: CheckStackOverflow
    //     0x7badec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7badf0: cmp             SP, x16
    //     0x7badf4: b.ls            #0x7bae40
    // 0x7badf8: StoreField: r2->field_27 = r0
    //     0x7badf8: stur            w0, [x2, #0x27]
    // 0x7badfc: LoadField: r0 = r2->field_37
    //     0x7badfc: ldur            w0, [x2, #0x37]
    // 0x7bae00: DecompressPointer r0
    //     0x7bae00: add             x0, x0, HEAP, lsl #32
    // 0x7bae04: SaveReg r0
    //     0x7bae04: str             x0, [SP, #-8]!
    // 0x7bae08: ClosureCall
    //     0x7bae08: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x7bae0c: ldur            x2, [x0, #0x1f]
    //     0x7bae10: blr             x2
    // 0x7bae14: add             SP, SP, #8
    // 0x7bae18: ldur            x0, [fp, #-8]
    // 0x7bae1c: LoadField: r1 = r0->field_13
    //     0x7bae1c: ldur            w1, [x0, #0x13]
    // 0x7bae20: DecompressPointer r1
    //     0x7bae20: add             x1, x1, HEAP, lsl #32
    // 0x7bae24: SaveReg r1
    //     0x7bae24: str             x1, [SP, #-8]!
    // 0x7bae28: r0 = dispose()
    //     0x7bae28: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x7bae2c: add             SP, SP, #8
    // 0x7bae30: r0 = Null
    //     0x7bae30: mov             x0, NULL
    // 0x7bae34: LeaveFrame
    //     0x7bae34: mov             SP, fp
    //     0x7bae38: ldp             fp, lr, [SP], #0x10
    // 0x7bae3c: ret
    //     0x7bae3c: ret             
    // 0x7bae40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bae40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bae44: b               #0x7badf8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7bae48, size: 0xe4
    // 0x7bae48: EnterFrame
    //     0x7bae48: stp             fp, lr, [SP, #-0x10]!
    //     0x7bae4c: mov             fp, SP
    // 0x7bae50: AllocStack(0x18)
    //     0x7bae50: sub             SP, SP, #0x18
    // 0x7bae54: SetupParameters()
    //     0x7bae54: ldr             x0, [fp, #0x10]
    //     0x7bae58: ldur            w2, [x0, #0x17]
    //     0x7bae5c: add             x2, x2, HEAP, lsl #32
    //     0x7bae60: stur            x2, [fp, #-0x18]
    // 0x7bae64: CheckStackOverflow
    //     0x7bae64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bae68: cmp             SP, x16
    //     0x7bae6c: b.ls            #0x7baf24
    // 0x7bae70: LoadField: r1 = r0->field_b
    //     0x7bae70: ldur            w1, [x0, #0xb]
    // 0x7bae74: DecompressPointer r1
    //     0x7bae74: add             x1, x1, HEAP, lsl #32
    // 0x7bae78: stur            x1, [fp, #-0x10]
    // 0x7bae7c: LoadField: r0 = r2->field_f
    //     0x7bae7c: ldur            w0, [x2, #0xf]
    // 0x7bae80: DecompressPointer r0
    //     0x7bae80: add             x0, x0, HEAP, lsl #32
    // 0x7bae84: LoadField: r3 = r0->field_4f
    //     0x7bae84: ldur            w3, [x0, #0x4f]
    // 0x7bae88: DecompressPointer r3
    //     0x7bae88: add             x3, x3, HEAP, lsl #32
    // 0x7bae8c: stur            x3, [fp, #-8]
    // 0x7bae90: LoadField: r0 = r2->field_1f
    //     0x7bae90: ldur            w0, [x2, #0x1f]
    // 0x7bae94: DecompressPointer r0
    //     0x7bae94: add             x0, x0, HEAP, lsl #32
    // 0x7bae98: r16 = Sentinel
    //     0x7bae98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bae9c: cmp             w0, w16
    // 0x7baea0: b.ne            #0x7baeb8
    // 0x7baea4: r16 = "bottomSheet"
    //     0x7baea4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f70] "bottomSheet"
    //     0x7baea8: ldr             x16, [x16, #0xf70]
    // 0x7baeac: SaveReg r16
    //     0x7baeac: str             x16, [SP, #-8]!
    // 0x7baeb0: r0 = _throwLocalNotInitialized()
    //     0x7baeb0: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x7baeb4: add             SP, SP, #8
    // 0x7baeb8: ldur            x2, [fp, #-0x18]
    // 0x7baebc: LoadField: r0 = r2->field_1f
    //     0x7baebc: ldur            w0, [x2, #0x1f]
    // 0x7baec0: DecompressPointer r0
    //     0x7baec0: add             x0, x0, HEAP, lsl #32
    // 0x7baec4: ldur            x16, [fp, #-8]
    // 0x7baec8: stp             x0, x16, [SP, #-0x10]!
    // 0x7baecc: r0 = contains()
    //     0x7baecc: bl              #0x786724  ; [dart:collection] _ListBase&Object&ListMixin::contains
    // 0x7baed0: add             SP, SP, #0x10
    // 0x7baed4: tbnz            w0, #4, #0x7baf14
    // 0x7baed8: ldur            x2, [fp, #-0x18]
    // 0x7baedc: ldur            x0, [fp, #-0x10]
    // 0x7baee0: LoadField: r3 = r2->field_f
    //     0x7baee0: ldur            w3, [x2, #0xf]
    // 0x7baee4: DecompressPointer r3
    //     0x7baee4: add             x3, x3, HEAP, lsl #32
    // 0x7baee8: stur            x3, [fp, #-8]
    // 0x7baeec: r1 = Function '<anonymous closure>':.
    //     0x7baeec: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f78] AnonymousClosure: (0x7baf2c), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0x7bab2c)
    //     0x7baef0: ldr             x1, [x1, #0xf78]
    // 0x7baef4: r0 = AllocateClosure()
    //     0x7baef4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7baef8: mov             x1, x0
    // 0x7baefc: ldur            x0, [fp, #-0x10]
    // 0x7baf00: StoreField: r1->field_b = r0
    //     0x7baf00: stur            w0, [x1, #0xb]
    // 0x7baf04: ldur            x16, [fp, #-8]
    // 0x7baf08: stp             x1, x16, [SP, #-0x10]!
    // 0x7baf0c: r0 = setState()
    //     0x7baf0c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7baf10: add             SP, SP, #0x10
    // 0x7baf14: r0 = Null
    //     0x7baf14: mov             x0, NULL
    // 0x7baf18: LeaveFrame
    //     0x7baf18: mov             SP, fp
    //     0x7baf1c: ldp             fp, lr, [SP], #0x10
    // 0x7baf20: ret
    //     0x7baf20: ret             
    // 0x7baf24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7baf24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7baf28: b               #0x7bae70
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7baf2c, size: 0x98
    // 0x7baf2c: EnterFrame
    //     0x7baf2c: stp             fp, lr, [SP, #-0x10]!
    //     0x7baf30: mov             fp, SP
    // 0x7baf34: AllocStack(0x10)
    //     0x7baf34: sub             SP, SP, #0x10
    // 0x7baf38: SetupParameters()
    //     0x7baf38: ldr             x0, [fp, #0x10]
    //     0x7baf3c: ldur            w1, [x0, #0x17]
    //     0x7baf40: add             x1, x1, HEAP, lsl #32
    //     0x7baf44: stur            x1, [fp, #-0x10]
    // 0x7baf48: CheckStackOverflow
    //     0x7baf48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7baf4c: cmp             SP, x16
    //     0x7baf50: b.ls            #0x7bafbc
    // 0x7baf54: LoadField: r0 = r1->field_f
    //     0x7baf54: ldur            w0, [x1, #0xf]
    // 0x7baf58: DecompressPointer r0
    //     0x7baf58: add             x0, x0, HEAP, lsl #32
    // 0x7baf5c: LoadField: r2 = r0->field_4f
    //     0x7baf5c: ldur            w2, [x0, #0x4f]
    // 0x7baf60: DecompressPointer r2
    //     0x7baf60: add             x2, x2, HEAP, lsl #32
    // 0x7baf64: stur            x2, [fp, #-8]
    // 0x7baf68: LoadField: r0 = r1->field_1f
    //     0x7baf68: ldur            w0, [x1, #0x1f]
    // 0x7baf6c: DecompressPointer r0
    //     0x7baf6c: add             x0, x0, HEAP, lsl #32
    // 0x7baf70: r16 = Sentinel
    //     0x7baf70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7baf74: cmp             w0, w16
    // 0x7baf78: b.ne            #0x7baf90
    // 0x7baf7c: r16 = "bottomSheet"
    //     0x7baf7c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f70] "bottomSheet"
    //     0x7baf80: ldr             x16, [x16, #0xf70]
    // 0x7baf84: SaveReg r16
    //     0x7baf84: str             x16, [SP, #-8]!
    // 0x7baf88: r0 = _throwLocalNotInitialized()
    //     0x7baf88: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x7baf8c: add             SP, SP, #8
    // 0x7baf90: ldur            x0, [fp, #-0x10]
    // 0x7baf94: LoadField: r1 = r0->field_1f
    //     0x7baf94: ldur            w1, [x0, #0x1f]
    // 0x7baf98: DecompressPointer r1
    //     0x7baf98: add             x1, x1, HEAP, lsl #32
    // 0x7baf9c: ldur            x16, [fp, #-8]
    // 0x7bafa0: stp             x1, x16, [SP, #-0x10]!
    // 0x7bafa4: r0 = remove()
    //     0x7bafa4: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0x7bafa8: add             SP, SP, #0x10
    // 0x7bafac: r0 = Null
    //     0x7bafac: mov             x0, NULL
    // 0x7bafb0: LeaveFrame
    //     0x7bafb0: mov             SP, fp
    //     0x7bafb4: ldp             fp, lr, [SP], #0x10
    // 0x7bafb8: ret
    //     0x7bafb8: ret             
    // 0x7bafbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bafbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bafc0: b               #0x7baf54
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7bafc4, size: 0x7c
    // 0x7bafc4: EnterFrame
    //     0x7bafc4: stp             fp, lr, [SP, #-0x10]!
    //     0x7bafc8: mov             fp, SP
    // 0x7bafcc: ldr             x0, [fp, #0x10]
    // 0x7bafd0: LoadField: r1 = r0->field_17
    //     0x7bafd0: ldur            w1, [x0, #0x17]
    // 0x7bafd4: DecompressPointer r1
    //     0x7bafd4: add             x1, x1, HEAP, lsl #32
    // 0x7bafd8: CheckStackOverflow
    //     0x7bafd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bafdc: cmp             SP, x16
    //     0x7bafe0: b.ls            #0x7bb038
    // 0x7bafe4: LoadField: r0 = r1->field_f
    //     0x7bafe4: ldur            w0, [x1, #0xf]
    // 0x7bafe8: DecompressPointer r0
    //     0x7bafe8: add             x0, x0, HEAP, lsl #32
    // 0x7bafec: LoadField: r2 = r0->field_53
    //     0x7bafec: ldur            w2, [x0, #0x53]
    // 0x7baff0: DecompressPointer r2
    //     0x7baff0: add             x2, x2, HEAP, lsl #32
    // 0x7baff4: cmp             w2, NULL
    // 0x7baff8: b.ne            #0x7bb00c
    // 0x7baffc: r0 = Null
    //     0x7baffc: mov             x0, NULL
    // 0x7bb000: LeaveFrame
    //     0x7bb000: mov             SP, fp
    //     0x7bb004: ldp             fp, lr, [SP], #0x10
    // 0x7bb008: ret
    //     0x7bb008: ret             
    // 0x7bb00c: LoadField: r0 = r1->field_37
    //     0x7bb00c: ldur            w0, [x1, #0x37]
    // 0x7bb010: DecompressPointer r0
    //     0x7bb010: add             x0, x0, HEAP, lsl #32
    // 0x7bb014: SaveReg r0
    //     0x7bb014: str             x0, [SP, #-8]!
    // 0x7bb018: ClosureCall
    //     0x7bb018: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x7bb01c: ldur            x2, [x0, #0x1f]
    //     0x7bb020: blr             x2
    // 0x7bb024: add             SP, SP, #8
    // 0x7bb028: r0 = Null
    //     0x7bb028: mov             x0, NULL
    // 0x7bb02c: LeaveFrame
    //     0x7bb02c: mov             SP, fp
    //     0x7bb030: ldp             fp, lr, [SP], #0x10
    // 0x7bb034: ret
    //     0x7bb034: ret             
    // 0x7bb038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bb038: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bb03c: b               #0x7bafe4
  }
  [closure] void removeCurrentBottomSheet(dynamic) {
    // ** addr: 0x7bb040, size: 0x280
    // 0x7bb040: EnterFrame
    //     0x7bb040: stp             fp, lr, [SP, #-0x10]!
    //     0x7bb044: mov             fp, SP
    // 0x7bb048: AllocStack(0x20)
    //     0x7bb048: sub             SP, SP, #0x20
    // 0x7bb04c: SetupParameters()
    //     0x7bb04c: add             x0, NULL, #0x20  ; true
    //     0x7bb050: ldr             x1, [fp, #0x10]
    //     0x7bb054: ldur            w2, [x1, #0x17]
    //     0x7bb058: add             x2, x2, HEAP, lsl #32
    //     0x7bb05c: stur            x2, [fp, #-0x10]
    // 0x7bb04c: r0 = true
    // 0x7bb060: CheckStackOverflow
    //     0x7bb060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bb064: cmp             SP, x16
    //     0x7bb068: b.ls            #0x7bb2a4
    // 0x7bb06c: LoadField: r3 = r1->field_b
    //     0x7bb06c: ldur            w3, [x1, #0xb]
    // 0x7bb070: DecompressPointer r3
    //     0x7bb070: add             x3, x3, HEAP, lsl #32
    // 0x7bb074: stur            x3, [fp, #-8]
    // 0x7bb078: StoreField: r2->field_23 = r0
    //     0x7bb078: stur            w0, [x2, #0x23]
    // 0x7bb07c: LoadField: r0 = r2->field_f
    //     0x7bb07c: ldur            w0, [x2, #0xf]
    // 0x7bb080: DecompressPointer r0
    //     0x7bb080: add             x0, x0, HEAP, lsl #32
    // 0x7bb084: LoadField: r1 = r0->field_53
    //     0x7bb084: ldur            w1, [x0, #0x53]
    // 0x7bb088: DecompressPointer r1
    //     0x7bb088: add             x1, x1, HEAP, lsl #32
    // 0x7bb08c: cmp             w1, NULL
    // 0x7bb090: b.ne            #0x7bb0a4
    // 0x7bb094: r0 = Null
    //     0x7bb094: mov             x0, NULL
    // 0x7bb098: LeaveFrame
    //     0x7bb098: mov             SP, fp
    //     0x7bb09c: ldp             fp, lr, [SP], #0x10
    // 0x7bb0a0: ret
    //     0x7bb0a0: ret             
    // 0x7bb0a4: SaveReg r0
    //     0x7bb0a4: str             x0, [SP, #-8]!
    // 0x7bb0a8: r0 = _showFloatingActionButton()
    //     0x7bb0a8: bl              #0x7bb35c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_showFloatingActionButton
    // 0x7bb0ac: add             SP, SP, #8
    // 0x7bb0b0: ldur            x2, [fp, #-0x10]
    // 0x7bb0b4: LoadField: r0 = r2->field_2b
    //     0x7bb0b4: ldur            w0, [x2, #0x2b]
    // 0x7bb0b8: DecompressPointer r0
    //     0x7bb0b8: add             x0, x0, HEAP, lsl #32
    // 0x7bb0bc: SaveReg r0
    //     0x7bb0bc: str             x0, [SP, #-8]!
    // 0x7bb0c0: ClosureCall
    //     0x7bb0c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x7bb0c4: ldur            x2, [x0, #0x1f]
    //     0x7bb0c8: blr             x2
    // 0x7bb0cc: add             SP, SP, #8
    // 0x7bb0d0: ldur            x2, [fp, #-0x10]
    // 0x7bb0d4: LoadField: r0 = r2->field_1b
    //     0x7bb0d4: ldur            w0, [x2, #0x1b]
    // 0x7bb0d8: DecompressPointer r0
    //     0x7bb0d8: add             x0, x0, HEAP, lsl #32
    // 0x7bb0dc: SaveReg r0
    //     0x7bb0dc: str             x0, [SP, #-8]!
    // 0x7bb0e0: r0 = currentState()
    //     0x7bb0e0: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x7bb0e4: add             SP, SP, #8
    // 0x7bb0e8: cmp             w0, NULL
    // 0x7bb0ec: b.eq            #0x7bb2ac
    // 0x7bb0f0: SaveReg r0
    //     0x7bb0f0: str             x0, [SP, #-8]!
    // 0x7bb0f4: r0 = close()
    //     0x7bb0f4: bl              #0x7bb2c0  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::close
    // 0x7bb0f8: add             SP, SP, #8
    // 0x7bb0fc: ldur            x0, [fp, #-0x10]
    // 0x7bb100: LoadField: r3 = r0->field_f
    //     0x7bb100: ldur            w3, [x0, #0xf]
    // 0x7bb104: DecompressPointer r3
    //     0x7bb104: add             x3, x3, HEAP, lsl #32
    // 0x7bb108: mov             x2, x0
    // 0x7bb10c: stur            x3, [fp, #-0x18]
    // 0x7bb110: r1 = Function '<anonymous closure>':.
    //     0x7bb110: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f80] AnonymousClosure: (0x7bb3b8), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0x7bab2c)
    //     0x7bb114: ldr             x1, [x1, #0xf80]
    // 0x7bb118: r0 = AllocateClosure()
    //     0x7bb118: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bb11c: mov             x1, x0
    // 0x7bb120: ldur            x0, [fp, #-8]
    // 0x7bb124: StoreField: r1->field_b = r0
    //     0x7bb124: stur            w0, [x1, #0xb]
    // 0x7bb128: ldur            x16, [fp, #-0x18]
    // 0x7bb12c: stp             x1, x16, [SP, #-0x10]!
    // 0x7bb130: r0 = setState()
    //     0x7bb130: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7bb134: add             SP, SP, #0x10
    // 0x7bb138: ldur            x0, [fp, #-0x10]
    // 0x7bb13c: LoadField: r1 = r0->field_13
    //     0x7bb13c: ldur            w1, [x0, #0x13]
    // 0x7bb140: DecompressPointer r1
    //     0x7bb140: add             x1, x1, HEAP, lsl #32
    // 0x7bb144: LoadField: r2 = r1->field_43
    //     0x7bb144: ldur            w2, [x1, #0x43]
    // 0x7bb148: DecompressPointer r2
    //     0x7bb148: add             x2, x2, HEAP, lsl #32
    // 0x7bb14c: r16 = Sentinel
    //     0x7bb14c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bb150: cmp             w2, w16
    // 0x7bb154: b.eq            #0x7bb2b0
    // 0x7bb158: r16 = Instance_AnimationStatus
    //     0x7bb158: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x7bb15c: ldr             x16, [x16, #0xba8]
    // 0x7bb160: cmp             w2, w16
    // 0x7bb164: b.eq            #0x7bb278
    // 0x7bb168: LoadField: r1 = r0->field_f
    //     0x7bb168: ldur            w1, [x0, #0xf]
    // 0x7bb16c: DecompressPointer r1
    //     0x7bb16c: add             x1, x1, HEAP, lsl #32
    // 0x7bb170: LoadField: r2 = r1->field_4f
    //     0x7bb170: ldur            w2, [x1, #0x4f]
    // 0x7bb174: DecompressPointer r2
    //     0x7bb174: add             x2, x2, HEAP, lsl #32
    // 0x7bb178: stur            x2, [fp, #-8]
    // 0x7bb17c: LoadField: r1 = r0->field_1f
    //     0x7bb17c: ldur            w1, [x0, #0x1f]
    // 0x7bb180: DecompressPointer r1
    //     0x7bb180: add             x1, x1, HEAP, lsl #32
    // 0x7bb184: r16 = Sentinel
    //     0x7bb184: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bb188: cmp             w1, w16
    // 0x7bb18c: b.ne            #0x7bb1a4
    // 0x7bb190: r16 = "bottomSheet"
    //     0x7bb190: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f70] "bottomSheet"
    //     0x7bb194: ldr             x16, [x16, #0xf70]
    // 0x7bb198: SaveReg r16
    //     0x7bb198: str             x16, [SP, #-8]!
    // 0x7bb19c: r0 = _throwLocalNotInitialized()
    //     0x7bb19c: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x7bb1a0: add             SP, SP, #8
    // 0x7bb1a4: ldur            x3, [fp, #-0x10]
    // 0x7bb1a8: ldur            x4, [fp, #-8]
    // 0x7bb1ac: LoadField: r5 = r3->field_1f
    //     0x7bb1ac: ldur            w5, [x3, #0x1f]
    // 0x7bb1b0: DecompressPointer r5
    //     0x7bb1b0: add             x5, x5, HEAP, lsl #32
    // 0x7bb1b4: stur            x5, [fp, #-0x18]
    // 0x7bb1b8: LoadField: r2 = r4->field_7
    //     0x7bb1b8: ldur            w2, [x4, #7]
    // 0x7bb1bc: DecompressPointer r2
    //     0x7bb1bc: add             x2, x2, HEAP, lsl #32
    // 0x7bb1c0: mov             x0, x5
    // 0x7bb1c4: r1 = Null
    //     0x7bb1c4: mov             x1, NULL
    // 0x7bb1c8: cmp             w2, NULL
    // 0x7bb1cc: b.eq            #0x7bb1ec
    // 0x7bb1d0: LoadField: r4 = r2->field_17
    //     0x7bb1d0: ldur            w4, [x2, #0x17]
    // 0x7bb1d4: DecompressPointer r4
    //     0x7bb1d4: add             x4, x4, HEAP, lsl #32
    // 0x7bb1d8: r8 = X0
    //     0x7bb1d8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x7bb1dc: LoadField: r9 = r4->field_7
    //     0x7bb1dc: ldur            x9, [x4, #7]
    // 0x7bb1e0: r3 = Null
    //     0x7bb1e0: add             x3, PP, #0x21, lsl #12  ; [pp+0x21f88] Null
    //     0x7bb1e4: ldr             x3, [x3, #0xf88]
    // 0x7bb1e8: blr             x9
    // 0x7bb1ec: ldur            x0, [fp, #-8]
    // 0x7bb1f0: LoadField: r1 = r0->field_b
    //     0x7bb1f0: ldur            w1, [x0, #0xb]
    // 0x7bb1f4: DecompressPointer r1
    //     0x7bb1f4: add             x1, x1, HEAP, lsl #32
    // 0x7bb1f8: stur            x1, [fp, #-0x20]
    // 0x7bb1fc: LoadField: r2 = r0->field_f
    //     0x7bb1fc: ldur            w2, [x0, #0xf]
    // 0x7bb200: DecompressPointer r2
    //     0x7bb200: add             x2, x2, HEAP, lsl #32
    // 0x7bb204: LoadField: r3 = r2->field_b
    //     0x7bb204: ldur            w3, [x2, #0xb]
    // 0x7bb208: DecompressPointer r3
    //     0x7bb208: add             x3, x3, HEAP, lsl #32
    // 0x7bb20c: cmp             w1, w3
    // 0x7bb210: b.ne            #0x7bb220
    // 0x7bb214: SaveReg r0
    //     0x7bb214: str             x0, [SP, #-8]!
    // 0x7bb218: r0 = _growToNextCapacity()
    //     0x7bb218: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7bb21c: add             SP, SP, #8
    // 0x7bb220: ldur            x2, [fp, #-8]
    // 0x7bb224: ldur            x0, [fp, #-0x20]
    // 0x7bb228: r3 = LoadInt32Instr(r0)
    //     0x7bb228: sbfx            x3, x0, #1, #0x1f
    // 0x7bb22c: add             x0, x3, #1
    // 0x7bb230: lsl             x1, x0, #1
    // 0x7bb234: StoreField: r2->field_b = r1
    //     0x7bb234: stur            w1, [x2, #0xb]
    // 0x7bb238: mov             x1, x3
    // 0x7bb23c: cmp             x1, x0
    // 0x7bb240: b.hs            #0x7bb2bc
    // 0x7bb244: LoadField: r1 = r2->field_f
    //     0x7bb244: ldur            w1, [x2, #0xf]
    // 0x7bb248: DecompressPointer r1
    //     0x7bb248: add             x1, x1, HEAP, lsl #32
    // 0x7bb24c: ldur            x0, [fp, #-0x18]
    // 0x7bb250: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7bb250: add             x25, x1, x3, lsl #2
    //     0x7bb254: add             x25, x25, #0xf
    //     0x7bb258: str             w0, [x25]
    //     0x7bb25c: tbz             w0, #0, #0x7bb278
    //     0x7bb260: ldurb           w16, [x1, #-1]
    //     0x7bb264: ldurb           w17, [x0, #-1]
    //     0x7bb268: and             x16, x17, x16, lsr #2
    //     0x7bb26c: tst             x16, HEAP, lsr #32
    //     0x7bb270: b.eq            #0x7bb278
    //     0x7bb274: bl              #0xd67e5c
    // 0x7bb278: ldur            x0, [fp, #-0x10]
    // 0x7bb27c: LoadField: r1 = r0->field_17
    //     0x7bb27c: ldur            w1, [x0, #0x17]
    // 0x7bb280: DecompressPointer r1
    //     0x7bb280: add             x1, x1, HEAP, lsl #32
    // 0x7bb284: SaveReg r1
    //     0x7bb284: str             x1, [SP, #-8]!
    // 0x7bb288: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7bb288: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7bb28c: r0 = complete()
    //     0x7bb28c: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x7bb290: add             SP, SP, #8
    // 0x7bb294: r0 = Null
    //     0x7bb294: mov             x0, NULL
    // 0x7bb298: LeaveFrame
    //     0x7bb298: mov             SP, fp
    //     0x7bb29c: ldp             fp, lr, [SP], #0x10
    // 0x7bb2a0: ret
    //     0x7bb2a0: ret             
    // 0x7bb2a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bb2a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bb2a8: b               #0x7bb06c
    // 0x7bb2ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bb2ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bb2b0: r9 = _status
    //     0x7bb2b0: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbe0] Field <AnimationController._status@575066280>: late (offset: 0x44)
    //     0x7bb2b4: ldr             x9, [x9, #0xbe0]
    // 0x7bb2b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7bb2b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7bb2bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7bb2bc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _showFloatingActionButton(/* No info */) {
    // ** addr: 0x7bb35c, size: 0x5c
    // 0x7bb35c: EnterFrame
    //     0x7bb35c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bb360: mov             fp, SP
    // 0x7bb364: CheckStackOverflow
    //     0x7bb364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bb368: cmp             SP, x16
    //     0x7bb36c: b.ls            #0x7bb3a4
    // 0x7bb370: ldr             x0, [fp, #0x10]
    // 0x7bb374: LoadField: r1 = r0->field_6f
    //     0x7bb374: ldur            w1, [x0, #0x6f]
    // 0x7bb378: DecompressPointer r1
    //     0x7bb378: add             x1, x1, HEAP, lsl #32
    // 0x7bb37c: r16 = Sentinel
    //     0x7bb37c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bb380: cmp             w1, w16
    // 0x7bb384: b.eq            #0x7bb3ac
    // 0x7bb388: SaveReg r1
    //     0x7bb388: str             x1, [SP, #-8]!
    // 0x7bb38c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7bb38c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7bb390: r0 = forward()
    //     0x7bb390: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7bb394: add             SP, SP, #8
    // 0x7bb398: LeaveFrame
    //     0x7bb398: mov             SP, fp
    //     0x7bb39c: ldp             fp, lr, [SP], #0x10
    // 0x7bb3a0: ret
    //     0x7bb3a0: ret             
    // 0x7bb3a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bb3a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bb3a8: b               #0x7bb370
    // 0x7bb3ac: r9 = _floatingActionButtonVisibilityController
    //     0x7bb3ac: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e28] Field <ScaffoldState._floatingActionButtonVisibilityController@801420462>: late (offset: 0x70)
    //     0x7bb3b0: ldr             x9, [x9, #0xe28]
    // 0x7bb3b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7bb3b4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7bb3b8, size: 0x20
    // 0x7bb3b8: ldr             x1, [SP]
    // 0x7bb3bc: LoadField: r2 = r1->field_17
    //     0x7bb3bc: ldur            w2, [x1, #0x17]
    // 0x7bb3c0: DecompressPointer r2
    //     0x7bb3c0: add             x2, x2, HEAP, lsl #32
    // 0x7bb3c4: LoadField: r1 = r2->field_f
    //     0x7bb3c4: ldur            w1, [x2, #0xf]
    // 0x7bb3c8: DecompressPointer r1
    //     0x7bb3c8: add             x1, x1, HEAP, lsl #32
    // 0x7bb3cc: StoreField: r1->field_53 = rNULL
    //     0x7bb3cc: stur            NULL, [x1, #0x53]
    // 0x7bb3d0: r0 = Null
    //     0x7bb3d0: mov             x0, NULL
    // 0x7bb3d4: ret
    //     0x7bb3d4: ret             
  }
  [closure] void removePersistentSheetHistoryEntryIfNeeded(dynamic) {
    // ** addr: 0x7bb3d8, size: 0x74
    // 0x7bb3d8: EnterFrame
    //     0x7bb3d8: stp             fp, lr, [SP, #-0x10]!
    //     0x7bb3dc: mov             fp, SP
    // 0x7bb3e0: AllocStack(0x8)
    //     0x7bb3e0: sub             SP, SP, #8
    // 0x7bb3e4: SetupParameters()
    //     0x7bb3e4: ldr             x0, [fp, #0x10]
    //     0x7bb3e8: ldur            w1, [x0, #0x17]
    //     0x7bb3ec: add             x1, x1, HEAP, lsl #32
    //     0x7bb3f0: stur            x1, [fp, #-8]
    // 0x7bb3f4: CheckStackOverflow
    //     0x7bb3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bb3f8: cmp             SP, x16
    //     0x7bb3fc: b.ls            #0x7bb444
    // 0x7bb400: LoadField: r0 = r1->field_f
    //     0x7bb400: ldur            w0, [x1, #0xf]
    // 0x7bb404: DecompressPointer r0
    //     0x7bb404: add             x0, x0, HEAP, lsl #32
    // 0x7bb408: LoadField: r2 = r0->field_5b
    //     0x7bb408: ldur            w2, [x0, #0x5b]
    // 0x7bb40c: DecompressPointer r2
    //     0x7bb40c: add             x2, x2, HEAP, lsl #32
    // 0x7bb410: cmp             w2, NULL
    // 0x7bb414: b.eq            #0x7bb434
    // 0x7bb418: SaveReg r2
    //     0x7bb418: str             x2, [SP, #-8]!
    // 0x7bb41c: r0 = remove()
    //     0x7bb41c: bl              #0x7bb44c  ; [package:flutter/src/widgets/routes.dart] LocalHistoryEntry::remove
    // 0x7bb420: add             SP, SP, #8
    // 0x7bb424: ldur            x1, [fp, #-8]
    // 0x7bb428: LoadField: r2 = r1->field_f
    //     0x7bb428: ldur            w2, [x1, #0xf]
    // 0x7bb42c: DecompressPointer r2
    //     0x7bb42c: add             x2, x2, HEAP, lsl #32
    // 0x7bb430: StoreField: r2->field_5b = rNULL
    //     0x7bb430: stur            NULL, [x2, #0x5b]
    // 0x7bb434: r0 = Null
    //     0x7bb434: mov             x0, NULL
    // 0x7bb438: LeaveFrame
    //     0x7bb438: mov             SP, fp
    //     0x7bb43c: ldp             fp, lr, [SP], #0x10
    // 0x7bb440: ret
    //     0x7bb440: ret             
    // 0x7bb444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bb444: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bb448: b               #0x7bb400
  }
  [closure] NotificationListener<DraggableScrollableNotification> <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x7bb78c, size: 0xc4
    // 0x7bb78c: EnterFrame
    //     0x7bb78c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bb790: mov             fp, SP
    // 0x7bb794: AllocStack(0x20)
    //     0x7bb794: sub             SP, SP, #0x20
    // 0x7bb798: SetupParameters()
    //     0x7bb798: ldr             x0, [fp, #0x18]
    //     0x7bb79c: ldur            w3, [x0, #0x17]
    //     0x7bb7a0: add             x3, x3, HEAP, lsl #32
    //     0x7bb7a4: stur            x3, [fp, #-0x10]
    // 0x7bb7a8: CheckStackOverflow
    //     0x7bb7a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bb7ac: cmp             SP, x16
    //     0x7bb7b0: b.ls            #0x7bb848
    // 0x7bb7b4: LoadField: r0 = r3->field_f
    //     0x7bb7b4: ldur            w0, [x3, #0xf]
    // 0x7bb7b8: DecompressPointer r0
    //     0x7bb7b8: add             x0, x0, HEAP, lsl #32
    // 0x7bb7bc: LoadField: r4 = r0->field_57
    //     0x7bb7bc: ldur            w4, [x0, #0x57]
    // 0x7bb7c0: DecompressPointer r4
    //     0x7bb7c0: add             x4, x4, HEAP, lsl #32
    // 0x7bb7c4: mov             x2, x3
    // 0x7bb7c8: stur            x4, [fp, #-8]
    // 0x7bb7cc: r1 = Function '<anonymous closure>':.
    //     0x7bb7cc: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f00] AnonymousClosure: (0x7bba68), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet (0x7ba864)
    //     0x7bb7d0: ldr             x1, [x1, #0xf00]
    // 0x7bb7d4: r0 = AllocateClosure()
    //     0x7bb7d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bb7d8: stur            x0, [fp, #-0x18]
    // 0x7bb7dc: r0 = StatefulBuilder()
    //     0x7bb7dc: bl              #0x7bba38  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0x7bb7e0: mov             x1, x0
    // 0x7bb7e4: ldur            x0, [fp, #-0x18]
    // 0x7bb7e8: stur            x1, [fp, #-0x20]
    // 0x7bb7ec: StoreField: r1->field_b = r0
    //     0x7bb7ec: stur            w0, [x1, #0xb]
    // 0x7bb7f0: ldur            x0, [fp, #-8]
    // 0x7bb7f4: StoreField: r1->field_7 = r0
    //     0x7bb7f4: stur            w0, [x1, #7]
    // 0x7bb7f8: r0 = DraggableScrollableActuator()
    //     0x7bb7f8: bl              #0x7bba2c  ; AllocateDraggableScrollableActuatorStub -> DraggableScrollableActuator (size=0x14)
    // 0x7bb7fc: stur            x0, [fp, #-8]
    // 0x7bb800: ldur            x16, [fp, #-0x20]
    // 0x7bb804: stp             x16, x0, [SP, #-0x10]!
    // 0x7bb808: r0 = DraggableScrollableActuator()
    //     0x7bb808: bl              #0x7bb96c  ; [package:flutter/src/widgets/draggable_scrollable_sheet.dart] DraggableScrollableActuator::DraggableScrollableActuator
    // 0x7bb80c: add             SP, SP, #0x10
    // 0x7bb810: ldur            x0, [fp, #-0x10]
    // 0x7bb814: LoadField: r2 = r0->field_13
    //     0x7bb814: ldur            w2, [x0, #0x13]
    // 0x7bb818: DecompressPointer r2
    //     0x7bb818: add             x2, x2, HEAP, lsl #32
    // 0x7bb81c: stur            x2, [fp, #-0x18]
    // 0x7bb820: r1 = <DraggableScrollableNotification>
    //     0x7bb820: add             x1, PP, #0x21, lsl #12  ; [pp+0x21f08] TypeArguments: <DraggableScrollableNotification>
    //     0x7bb824: ldr             x1, [x1, #0xf08]
    // 0x7bb828: r0 = NotificationListener()
    //     0x7bb828: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x7bb82c: ldur            x1, [fp, #-0x18]
    // 0x7bb830: StoreField: r0->field_13 = r1
    //     0x7bb830: stur            w1, [x0, #0x13]
    // 0x7bb834: ldur            x1, [fp, #-8]
    // 0x7bb838: StoreField: r0->field_b = r1
    //     0x7bb838: stur            w1, [x0, #0xb]
    // 0x7bb83c: LeaveFrame
    //     0x7bb83c: mov             SP, fp
    //     0x7bb840: ldp             fp, lr, [SP], #0x10
    // 0x7bb844: ret
    //     0x7bb844: ret             
    // 0x7bb848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bb848: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bb84c: b               #0x7bb7b4
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0x7bba68, size: 0x50
    // 0x7bba68: EnterFrame
    //     0x7bba68: stp             fp, lr, [SP, #-0x10]!
    //     0x7bba6c: mov             fp, SP
    // 0x7bba70: ldr             x1, [fp, #0x20]
    // 0x7bba74: LoadField: r2 = r1->field_17
    //     0x7bba74: ldur            w2, [x1, #0x17]
    // 0x7bba78: DecompressPointer r2
    //     0x7bba78: add             x2, x2, HEAP, lsl #32
    // 0x7bba7c: LoadField: r1 = r2->field_f
    //     0x7bba7c: ldur            w1, [x2, #0xf]
    // 0x7bba80: DecompressPointer r1
    //     0x7bba80: add             x1, x1, HEAP, lsl #32
    // 0x7bba84: LoadField: r2 = r1->field_b
    //     0x7bba84: ldur            w2, [x1, #0xb]
    // 0x7bba88: DecompressPointer r2
    //     0x7bba88: add             x2, x2, HEAP, lsl #32
    // 0x7bba8c: cmp             w2, NULL
    // 0x7bba90: b.eq            #0x7bbab0
    // 0x7bba94: LoadField: r0 = r2->field_4b
    //     0x7bba94: ldur            w0, [x2, #0x4b]
    // 0x7bba98: DecompressPointer r0
    //     0x7bba98: add             x0, x0, HEAP, lsl #32
    // 0x7bba9c: cmp             w0, NULL
    // 0x7bbaa0: b.eq            #0x7bbab4
    // 0x7bbaa4: LeaveFrame
    //     0x7bbaa4: mov             SP, fp
    //     0x7bbaa8: ldp             fp, lr, [SP], #0x10
    // 0x7bbaac: ret
    //     0x7bbaac: ret             
    // 0x7bbab0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bbab0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bbab4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bbab4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool persistentBottomSheetExtentChanged(dynamic, DraggableScrollableNotification) {
    // ** addr: 0x7bbadc, size: 0x70
    // 0x7bbadc: EnterFrame
    //     0x7bbadc: stp             fp, lr, [SP, #-0x10]!
    //     0x7bbae0: mov             fp, SP
    // 0x7bbae4: CheckStackOverflow
    //     0x7bbae4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bbae8: cmp             SP, x16
    //     0x7bbaec: b.ls            #0x7bbb44
    // 0x7bbaf0: ldr             x16, [fp, #0x10]
    // 0x7bbaf4: SaveReg r16
    //     0x7bbaf4: str             x16, [SP, #-8]!
    // 0x7bbaf8: r4 = 0
    //     0x7bbaf8: mov             x4, #0
    // 0x7bbafc: ldr             x0, [SP]
    // 0x7bbb00: r16 = UnlinkedCall_0x4aeefc
    //     0x7bbb00: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f10] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x7bbb04: add             x16, x16, #0xf10
    // 0x7bbb08: ldp             x5, lr, [x16]
    // 0x7bbb0c: blr             lr
    // 0x7bbb10: add             SP, SP, #8
    // 0x7bbb14: ldr             x16, [fp, #0x10]
    // 0x7bbb18: SaveReg r16
    //     0x7bbb18: str             x16, [SP, #-8]!
    // 0x7bbb1c: r4 = 0
    //     0x7bbb1c: mov             x4, #0
    // 0x7bbb20: ldr             x0, [SP]
    // 0x7bbb24: r16 = UnlinkedCall_0x4aeefc
    //     0x7bbb24: add             x16, PP, #0x21, lsl #12  ; [pp+0x21f20] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x7bbb28: add             x16, x16, #0xf20
    // 0x7bbb2c: ldp             x5, lr, [x16]
    // 0x7bbb30: blr             lr
    // 0x7bbb34: add             SP, SP, #8
    // 0x7bbb38: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x7bbb38: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x7bbb3c: r0 = Throw()
    //     0x7bbb3c: bl              #0xd67e38  ; ThrowStub
    // 0x7bbb40: brk             #0
    // 0x7bbb44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bbb44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bbb48: b               #0x7bbaf0
  }
  _ _closeCurrentBottomSheet(/* No info */) {
    // ** addr: 0x7bbb4c, size: 0x68
    // 0x7bbb4c: EnterFrame
    //     0x7bbb4c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bbb50: mov             fp, SP
    // 0x7bbb54: CheckStackOverflow
    //     0x7bbb54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bbb58: cmp             SP, x16
    //     0x7bbb5c: b.ls            #0x7bbbac
    // 0x7bbb60: ldr             x0, [fp, #0x10]
    // 0x7bbb64: LoadField: r1 = r0->field_53
    //     0x7bbb64: ldur            w1, [x0, #0x53]
    // 0x7bbb68: DecompressPointer r1
    //     0x7bbb68: add             x1, x1, HEAP, lsl #32
    // 0x7bbb6c: cmp             w1, NULL
    // 0x7bbb70: b.eq            #0x7bbb9c
    // 0x7bbb74: LoadField: r0 = r1->field_17
    //     0x7bbb74: ldur            w0, [x1, #0x17]
    // 0x7bbb78: DecompressPointer r0
    //     0x7bbb78: add             x0, x0, HEAP, lsl #32
    // 0x7bbb7c: tbz             w0, #4, #0x7bbb9c
    // 0x7bbb80: LoadField: r0 = r1->field_13
    //     0x7bbb80: ldur            w0, [x1, #0x13]
    // 0x7bbb84: DecompressPointer r0
    //     0x7bbb84: add             x0, x0, HEAP, lsl #32
    // 0x7bbb88: SaveReg r0
    //     0x7bbb88: str             x0, [SP, #-8]!
    // 0x7bbb8c: ClosureCall
    //     0x7bbb8c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x7bbb90: ldur            x2, [x0, #0x1f]
    //     0x7bbb94: blr             x2
    // 0x7bbb98: add             SP, SP, #8
    // 0x7bbb9c: r0 = Null
    //     0x7bbb9c: mov             x0, NULL
    // 0x7bbba0: LeaveFrame
    //     0x7bbba0: mov             SP, fp
    //     0x7bbba4: ldp             fp, lr, [SP], #0x10
    // 0x7bbba8: ret
    //     0x7bbba8: ret             
    // 0x7bbbac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bbbac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bbbb0: b               #0x7bbb60
  }
  _ openEndDrawer(/* No info */) {
    // ** addr: 0x848b24, size: 0x104
    // 0x848b24: EnterFrame
    //     0x848b24: stp             fp, lr, [SP, #-0x10]!
    //     0x848b28: mov             fp, SP
    // 0x848b2c: AllocStack(0x10)
    //     0x848b2c: sub             SP, SP, #0x10
    // 0x848b30: CheckStackOverflow
    //     0x848b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848b34: cmp             SP, x16
    //     0x848b38: b.ls            #0x848c1c
    // 0x848b3c: ldr             x0, [fp, #0x10]
    // 0x848b40: LoadField: r1 = r0->field_2b
    //     0x848b40: ldur            w1, [x0, #0x2b]
    // 0x848b44: DecompressPointer r1
    //     0x848b44: add             x1, x1, HEAP, lsl #32
    // 0x848b48: stur            x1, [fp, #-8]
    // 0x848b4c: SaveReg r1
    //     0x848b4c: str             x1, [SP, #-8]!
    // 0x848b50: r0 = currentState()
    //     0x848b50: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x848b54: add             SP, SP, #8
    // 0x848b58: cmp             w0, NULL
    // 0x848b5c: b.eq            #0x848be0
    // 0x848b60: ldr             x3, [fp, #0x10]
    // 0x848b64: LoadField: r0 = r3->field_3b
    //     0x848b64: ldur            w0, [x3, #0x3b]
    // 0x848b68: DecompressPointer r0
    //     0x848b68: add             x0, x0, HEAP, lsl #32
    // 0x848b6c: LoadField: r4 = r0->field_33
    //     0x848b6c: ldur            w4, [x0, #0x33]
    // 0x848b70: DecompressPointer r4
    //     0x848b70: add             x4, x4, HEAP, lsl #32
    // 0x848b74: stur            x4, [fp, #-0x10]
    // 0x848b78: cmp             w4, NULL
    // 0x848b7c: b.ne            #0x848bb4
    // 0x848b80: LoadField: r2 = r0->field_23
    //     0x848b80: ldur            w2, [x0, #0x23]
    // 0x848b84: DecompressPointer r2
    //     0x848b84: add             x2, x2, HEAP, lsl #32
    // 0x848b88: mov             x0, x4
    // 0x848b8c: r1 = Null
    //     0x848b8c: mov             x1, NULL
    // 0x848b90: cmp             w2, NULL
    // 0x848b94: b.eq            #0x848bb4
    // 0x848b98: LoadField: r4 = r2->field_17
    //     0x848b98: ldur            w4, [x2, #0x17]
    // 0x848b9c: DecompressPointer r4
    //     0x848b9c: add             x4, x4, HEAP, lsl #32
    // 0x848ba0: r8 = X0
    //     0x848ba0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x848ba4: LoadField: r9 = r4->field_7
    //     0x848ba4: ldur            x9, [x4, #7]
    // 0x848ba8: r3 = Null
    //     0x848ba8: add             x3, PP, #0x37, lsl #12  ; [pp+0x37a00] Null
    //     0x848bac: ldr             x3, [x3, #0xa00]
    // 0x848bb0: blr             x9
    // 0x848bb4: ldur            x0, [fp, #-0x10]
    // 0x848bb8: tbnz            w0, #4, #0x848be0
    // 0x848bbc: ldur            x16, [fp, #-8]
    // 0x848bc0: SaveReg r16
    //     0x848bc0: str             x16, [SP, #-8]!
    // 0x848bc4: r0 = currentState()
    //     0x848bc4: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x848bc8: add             SP, SP, #8
    // 0x848bcc: cmp             w0, NULL
    // 0x848bd0: b.eq            #0x848c24
    // 0x848bd4: SaveReg r0
    //     0x848bd4: str             x0, [SP, #-8]!
    // 0x848bd8: r0 = close()
    //     0x848bd8: bl              #0x848c9c  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0x848bdc: add             SP, SP, #8
    // 0x848be0: ldr             x0, [fp, #0x10]
    // 0x848be4: LoadField: r1 = r0->field_2f
    //     0x848be4: ldur            w1, [x0, #0x2f]
    // 0x848be8: DecompressPointer r1
    //     0x848be8: add             x1, x1, HEAP, lsl #32
    // 0x848bec: SaveReg r1
    //     0x848bec: str             x1, [SP, #-8]!
    // 0x848bf0: r0 = currentState()
    //     0x848bf0: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x848bf4: add             SP, SP, #8
    // 0x848bf8: cmp             w0, NULL
    // 0x848bfc: b.eq            #0x848c0c
    // 0x848c00: SaveReg r0
    //     0x848c00: str             x0, [SP, #-8]!
    // 0x848c04: r0 = open()
    //     0x848c04: bl              #0x848c28  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::open
    // 0x848c08: add             SP, SP, #8
    // 0x848c0c: r0 = Null
    //     0x848c0c: mov             x0, NULL
    // 0x848c10: LeaveFrame
    //     0x848c10: mov             SP, fp
    //     0x848c14: ldp             fp, lr, [SP], #0x10
    // 0x848c18: ret
    //     0x848c18: ret             
    // 0x848c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848c1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848c20: b               #0x848b3c
    // 0x848c24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x848c24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ openDrawer(/* No info */) {
    // ** addr: 0x848f80, size: 0x104
    // 0x848f80: EnterFrame
    //     0x848f80: stp             fp, lr, [SP, #-0x10]!
    //     0x848f84: mov             fp, SP
    // 0x848f88: AllocStack(0x10)
    //     0x848f88: sub             SP, SP, #0x10
    // 0x848f8c: CheckStackOverflow
    //     0x848f8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848f90: cmp             SP, x16
    //     0x848f94: b.ls            #0x849078
    // 0x848f98: ldr             x0, [fp, #0x10]
    // 0x848f9c: LoadField: r1 = r0->field_2f
    //     0x848f9c: ldur            w1, [x0, #0x2f]
    // 0x848fa0: DecompressPointer r1
    //     0x848fa0: add             x1, x1, HEAP, lsl #32
    // 0x848fa4: stur            x1, [fp, #-8]
    // 0x848fa8: SaveReg r1
    //     0x848fa8: str             x1, [SP, #-8]!
    // 0x848fac: r0 = currentState()
    //     0x848fac: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x848fb0: add             SP, SP, #8
    // 0x848fb4: cmp             w0, NULL
    // 0x848fb8: b.eq            #0x84903c
    // 0x848fbc: ldr             x3, [fp, #0x10]
    // 0x848fc0: LoadField: r0 = r3->field_3f
    //     0x848fc0: ldur            w0, [x3, #0x3f]
    // 0x848fc4: DecompressPointer r0
    //     0x848fc4: add             x0, x0, HEAP, lsl #32
    // 0x848fc8: LoadField: r4 = r0->field_33
    //     0x848fc8: ldur            w4, [x0, #0x33]
    // 0x848fcc: DecompressPointer r4
    //     0x848fcc: add             x4, x4, HEAP, lsl #32
    // 0x848fd0: stur            x4, [fp, #-0x10]
    // 0x848fd4: cmp             w4, NULL
    // 0x848fd8: b.ne            #0x849010
    // 0x848fdc: LoadField: r2 = r0->field_23
    //     0x848fdc: ldur            w2, [x0, #0x23]
    // 0x848fe0: DecompressPointer r2
    //     0x848fe0: add             x2, x2, HEAP, lsl #32
    // 0x848fe4: mov             x0, x4
    // 0x848fe8: r1 = Null
    //     0x848fe8: mov             x1, NULL
    // 0x848fec: cmp             w2, NULL
    // 0x848ff0: b.eq            #0x849010
    // 0x848ff4: LoadField: r4 = r2->field_17
    //     0x848ff4: ldur            w4, [x2, #0x17]
    // 0x848ff8: DecompressPointer r4
    //     0x848ff8: add             x4, x4, HEAP, lsl #32
    // 0x848ffc: r8 = X0
    //     0x848ffc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x849000: LoadField: r9 = r4->field_7
    //     0x849000: ldur            x9, [x4, #7]
    // 0x849004: r3 = Null
    //     0x849004: add             x3, PP, #0x37, lsl #12  ; [pp+0x37a68] Null
    //     0x849008: ldr             x3, [x3, #0xa68]
    // 0x84900c: blr             x9
    // 0x849010: ldur            x0, [fp, #-0x10]
    // 0x849014: tbnz            w0, #4, #0x84903c
    // 0x849018: ldur            x16, [fp, #-8]
    // 0x84901c: SaveReg r16
    //     0x84901c: str             x16, [SP, #-8]!
    // 0x849020: r0 = currentState()
    //     0x849020: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x849024: add             SP, SP, #8
    // 0x849028: cmp             w0, NULL
    // 0x84902c: b.eq            #0x849080
    // 0x849030: SaveReg r0
    //     0x849030: str             x0, [SP, #-8]!
    // 0x849034: r0 = close()
    //     0x849034: bl              #0x848c9c  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0x849038: add             SP, SP, #8
    // 0x84903c: ldr             x0, [fp, #0x10]
    // 0x849040: LoadField: r1 = r0->field_2b
    //     0x849040: ldur            w1, [x0, #0x2b]
    // 0x849044: DecompressPointer r1
    //     0x849044: add             x1, x1, HEAP, lsl #32
    // 0x849048: SaveReg r1
    //     0x849048: str             x1, [SP, #-8]!
    // 0x84904c: r0 = currentState()
    //     0x84904c: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x849050: add             SP, SP, #8
    // 0x849054: cmp             w0, NULL
    // 0x849058: b.eq            #0x849068
    // 0x84905c: SaveReg r0
    //     0x84905c: str             x0, [SP, #-8]!
    // 0x849060: r0 = open()
    //     0x849060: bl              #0x848c28  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::open
    // 0x849064: add             SP, SP, #8
    // 0x849068: r0 = Null
    //     0x849068: mov             x0, NULL
    // 0x84906c: LeaveFrame
    //     0x84906c: mov             SP, fp
    //     0x849070: ldp             fp, lr, [SP], #0x10
    // 0x849074: ret
    //     0x849074: ret             
    // 0x849078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84907c: b               #0x848f98
    // 0x849080: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x849080: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84f528, size: 0x48
    // 0x84f528: ldr             x1, [SP]
    // 0x84f52c: LoadField: r2 = r1->field_17
    //     0x84f52c: ldur            w2, [x1, #0x17]
    // 0x84f530: DecompressPointer r2
    //     0x84f530: add             x2, x2, HEAP, lsl #32
    // 0x84f534: LoadField: r1 = r2->field_f
    //     0x84f534: ldur            w1, [x2, #0xf]
    // 0x84f538: DecompressPointer r1
    //     0x84f538: add             x1, x1, HEAP, lsl #32
    // 0x84f53c: LoadField: r0 = r2->field_13
    //     0x84f53c: ldur            w0, [x2, #0x13]
    // 0x84f540: DecompressPointer r0
    //     0x84f540: add             x0, x0, HEAP, lsl #32
    // 0x84f544: StoreField: r1->field_47 = r0
    //     0x84f544: stur            w0, [x1, #0x47]
    //     0x84f548: ldurb           w16, [x1, #-1]
    //     0x84f54c: ldurb           w17, [x0, #-1]
    //     0x84f550: and             x16, x17, x16, lsr #2
    //     0x84f554: tst             x16, HEAP, lsr #32
    //     0x84f558: b.eq            #0x84f568
    //     0x84f55c: str             lr, [SP, #-8]!
    //     0x84f560: bl              #0xd6826c
    //     0x84f564: ldr             lr, [SP], #8
    // 0x84f568: r0 = Null
    //     0x84f568: mov             x0, NULL
    // 0x84f56c: ret
    //     0x84f56c: ret             
  }
  _ _updateSnackBar(/* No info */) {
    // ** addr: 0x84f570, size: 0xe0
    // 0x84f570: EnterFrame
    //     0x84f570: stp             fp, lr, [SP, #-0x10]!
    //     0x84f574: mov             fp, SP
    // 0x84f578: AllocStack(0x8)
    //     0x84f578: sub             SP, SP, #8
    // 0x84f57c: CheckStackOverflow
    //     0x84f57c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f580: cmp             SP, x16
    //     0x84f584: b.ls            #0x84f644
    // 0x84f588: r1 = 2
    //     0x84f588: mov             x1, #2
    // 0x84f58c: r0 = AllocateContext()
    //     0x84f58c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f590: mov             x1, x0
    // 0x84f594: ldr             x0, [fp, #0x10]
    // 0x84f598: stur            x1, [fp, #-8]
    // 0x84f59c: StoreField: r1->field_f = r0
    //     0x84f59c: stur            w0, [x1, #0xf]
    // 0x84f5a0: LoadField: r2 = r0->field_43
    //     0x84f5a0: ldur            w2, [x0, #0x43]
    // 0x84f5a4: DecompressPointer r2
    //     0x84f5a4: add             x2, x2, HEAP, lsl #32
    // 0x84f5a8: cmp             w2, NULL
    // 0x84f5ac: b.eq            #0x84f64c
    // 0x84f5b0: LoadField: r3 = r2->field_23
    //     0x84f5b0: ldur            w3, [x2, #0x23]
    // 0x84f5b4: DecompressPointer r3
    //     0x84f5b4: add             x3, x3, HEAP, lsl #32
    // 0x84f5b8: LoadField: r2 = r3->field_f
    //     0x84f5b8: ldur            x2, [x3, #0xf]
    // 0x84f5bc: LoadField: r4 = r3->field_17
    //     0x84f5bc: ldur            x4, [x3, #0x17]
    // 0x84f5c0: cmp             x2, x4
    // 0x84f5c4: b.eq            #0x84f5dc
    // 0x84f5c8: SaveReg r3
    //     0x84f5c8: str             x3, [SP, #-8]!
    // 0x84f5cc: r0 = first()
    //     0x84f5cc: bl              #0x6b78d0  ; [dart:collection] ListQueue::first
    // 0x84f5d0: add             SP, SP, #8
    // 0x84f5d4: mov             x1, x0
    // 0x84f5d8: b               #0x84f5e0
    // 0x84f5dc: r1 = Null
    //     0x84f5dc: mov             x1, NULL
    // 0x84f5e0: ldr             x3, [fp, #0x10]
    // 0x84f5e4: ldur            x2, [fp, #-8]
    // 0x84f5e8: mov             x0, x1
    // 0x84f5ec: StoreField: r2->field_13 = r0
    //     0x84f5ec: stur            w0, [x2, #0x13]
    //     0x84f5f0: ldurb           w16, [x2, #-1]
    //     0x84f5f4: ldurb           w17, [x0, #-1]
    //     0x84f5f8: and             x16, x17, x16, lsr #2
    //     0x84f5fc: tst             x16, HEAP, lsr #32
    //     0x84f600: b.eq            #0x84f608
    //     0x84f604: bl              #0xd6828c
    // 0x84f608: LoadField: r0 = r3->field_47
    //     0x84f608: ldur            w0, [x3, #0x47]
    // 0x84f60c: DecompressPointer r0
    //     0x84f60c: add             x0, x0, HEAP, lsl #32
    // 0x84f610: cmp             w0, w1
    // 0x84f614: b.eq            #0x84f634
    // 0x84f618: r1 = Function '<anonymous closure>':.
    //     0x84f618: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fb8] AnonymousClosure: (0x84f528), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateSnackBar (0x84f570)
    //     0x84f61c: ldr             x1, [x1, #0xfb8]
    // 0x84f620: r0 = AllocateClosure()
    //     0x84f620: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f624: ldr             x16, [fp, #0x10]
    // 0x84f628: stp             x0, x16, [SP, #-0x10]!
    // 0x84f62c: r0 = setState()
    //     0x84f62c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84f630: add             SP, SP, #0x10
    // 0x84f634: r0 = Null
    //     0x84f634: mov             x0, NULL
    // 0x84f638: LeaveFrame
    //     0x84f638: mov             SP, fp
    //     0x84f63c: ldp             fp, lr, [SP], #0x10
    // 0x84f640: ret
    //     0x84f640: ret             
    // 0x84f644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f644: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f648: b               #0x84f588
    // 0x84f64c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f64c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x8648a0, size: 0xd20
    // 0x8648a0: EnterFrame
    //     0x8648a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8648a4: mov             fp, SP
    // 0x8648a8: AllocStack(0x50)
    //     0x8648a8: sub             SP, SP, #0x50
    // 0x8648ac: CheckStackOverflow
    //     0x8648ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8648b0: cmp             SP, x16
    //     0x8648b4: b.ls            #0x865520
    // 0x8648b8: r1 = 9
    //     0x8648b8: mov             x1, #9
    // 0x8648bc: r0 = AllocateContext()
    //     0x8648bc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8648c0: mov             x1, x0
    // 0x8648c4: ldr             x0, [fp, #0x18]
    // 0x8648c8: stur            x1, [fp, #-8]
    // 0x8648cc: StoreField: r1->field_f = r0
    //     0x8648cc: stur            w0, [x1, #0xf]
    // 0x8648d0: ldr             x16, [fp, #0x10]
    // 0x8648d4: SaveReg r16
    //     0x8648d4: str             x16, [SP, #-8]!
    // 0x8648d8: r0 = of()
    //     0x8648d8: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x8648dc: add             SP, SP, #8
    // 0x8648e0: stur            x0, [fp, #-0x10]
    // 0x8648e4: ldr             x16, [fp, #0x10]
    // 0x8648e8: SaveReg r16
    //     0x8648e8: str             x16, [SP, #-8]!
    // 0x8648ec: r0 = of()
    //     0x8648ec: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8648f0: add             SP, SP, #8
    // 0x8648f4: stur            x0, [fp, #-0x18]
    // 0x8648f8: ldr             x16, [fp, #0x10]
    // 0x8648fc: SaveReg r16
    //     0x8648fc: str             x16, [SP, #-8]!
    // 0x864900: r0 = of()
    //     0x864900: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x864904: add             SP, SP, #8
    // 0x864908: ldur            x2, [fp, #-8]
    // 0x86490c: StoreField: r2->field_13 = r0
    //     0x86490c: stur            w0, [x2, #0x13]
    //     0x864910: ldurb           w16, [x2, #-1]
    //     0x864914: ldurb           w17, [x0, #-1]
    //     0x864918: and             x16, x17, x16, lsr #2
    //     0x86491c: tst             x16, HEAP, lsr #32
    //     0x864920: b.eq            #0x864928
    //     0x864924: bl              #0xd6828c
    // 0x864928: r16 = <LayoutId<MultiChildLayoutParentData<RenderBox>>>
    //     0x864928: add             x16, PP, #0x21, lsl #12  ; [pp+0x21d60] TypeArguments: <LayoutId<MultiChildLayoutParentData<RenderBox>>>
    //     0x86492c: ldr             x16, [x16, #0xd60]
    // 0x864930: stp             xzr, x16, [SP, #-0x10]!
    // 0x864934: r0 = _GrowableList()
    //     0x864934: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x864938: add             SP, SP, #0x10
    // 0x86493c: mov             x1, x0
    // 0x864940: ldur            x2, [fp, #-8]
    // 0x864944: stur            x1, [fp, #-0x38]
    // 0x864948: StoreField: r2->field_17 = r0
    //     0x864948: stur            w0, [x2, #0x17]
    //     0x86494c: ldurb           w16, [x2, #-1]
    //     0x864950: ldurb           w17, [x0, #-1]
    //     0x864954: and             x16, x17, x16, lsr #2
    //     0x864958: tst             x16, HEAP, lsr #32
    //     0x86495c: b.eq            #0x864964
    //     0x864960: bl              #0xd6828c
    // 0x864964: ldr             x0, [fp, #0x18]
    // 0x864968: LoadField: r3 = r0->field_b
    //     0x864968: ldur            w3, [x0, #0xb]
    // 0x86496c: DecompressPointer r3
    //     0x86496c: add             x3, x3, HEAP, lsl #32
    // 0x864970: stur            x3, [fp, #-0x30]
    // 0x864974: cmp             w3, NULL
    // 0x864978: b.eq            #0x865528
    // 0x86497c: LoadField: r4 = r3->field_17
    //     0x86497c: ldur            w4, [x3, #0x17]
    // 0x864980: DecompressPointer r4
    //     0x864980: add             x4, x4, HEAP, lsl #32
    // 0x864984: stur            x4, [fp, #-0x28]
    // 0x864988: cmp             w4, NULL
    // 0x86498c: b.ne            #0x8649a0
    // 0x864990: mov             x1, x3
    // 0x864994: r2 = Null
    //     0x864994: mov             x2, NULL
    // 0x864998: r0 = false
    //     0x864998: add             x0, NULL, #0x30  ; false
    // 0x86499c: b               #0x8649ec
    // 0x8649a0: LoadField: r5 = r0->field_33
    //     0x8649a0: ldur            w5, [x0, #0x33]
    // 0x8649a4: DecompressPointer r5
    //     0x8649a4: add             x5, x5, HEAP, lsl #32
    // 0x8649a8: stur            x5, [fp, #-0x20]
    // 0x8649ac: r0 = KeyedSubtree()
    //     0x8649ac: bl              #0x7a1550  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0x8649b0: mov             x1, x0
    // 0x8649b4: ldur            x0, [fp, #-0x28]
    // 0x8649b8: stur            x1, [fp, #-0x40]
    // 0x8649bc: StoreField: r1->field_b = r0
    //     0x8649bc: stur            w0, [x1, #0xb]
    // 0x8649c0: ldur            x0, [fp, #-0x20]
    // 0x8649c4: StoreField: r1->field_7 = r0
    //     0x8649c4: stur            w0, [x1, #7]
    // 0x8649c8: r0 = _BodyBuilder()
    //     0x8649c8: bl              #0x866200  ; Allocate_BodyBuilderStub -> _BodyBuilder (size=0x18)
    // 0x8649cc: mov             x1, x0
    // 0x8649d0: r0 = false
    //     0x8649d0: add             x0, NULL, #0x30  ; false
    // 0x8649d4: StoreField: r1->field_f = r0
    //     0x8649d4: stur            w0, [x1, #0xf]
    // 0x8649d8: StoreField: r1->field_13 = r0
    //     0x8649d8: stur            w0, [x1, #0x13]
    // 0x8649dc: ldur            x2, [fp, #-0x40]
    // 0x8649e0: StoreField: r1->field_b = r2
    //     0x8649e0: stur            w2, [x1, #0xb]
    // 0x8649e4: mov             x2, x1
    // 0x8649e8: ldur            x1, [fp, #-0x30]
    // 0x8649ec: LoadField: r3 = r1->field_13
    //     0x8649ec: ldur            w3, [x1, #0x13]
    // 0x8649f0: DecompressPointer r3
    //     0x8649f0: add             x3, x3, HEAP, lsl #32
    // 0x8649f4: cmp             w3, NULL
    // 0x8649f8: r16 = true
    //     0x8649f8: add             x16, NULL, #0x20  ; true
    // 0x8649fc: r17 = false
    //     0x8649fc: add             x17, NULL, #0x30  ; false
    // 0x864a00: csel            x4, x16, x17, ne
    // 0x864a04: LoadField: r3 = r1->field_47
    //     0x864a04: ldur            w3, [x1, #0x47]
    // 0x864a08: DecompressPointer r3
    //     0x864a08: add             x3, x3, HEAP, lsl #32
    // 0x864a0c: cmp             w3, NULL
    // 0x864a10: b.eq            #0x864a1c
    // 0x864a14: r3 = true
    //     0x864a14: add             x3, NULL, #0x20  ; true
    // 0x864a18: b               #0x864a20
    // 0x864a1c: r3 = false
    //     0x864a1c: add             x3, NULL, #0x30  ; false
    // 0x864a20: LoadField: r5 = r1->field_4f
    //     0x864a20: ldur            w5, [x1, #0x4f]
    // 0x864a24: DecompressPointer r5
    //     0x864a24: add             x5, x5, HEAP, lsl #32
    // 0x864a28: cmp             w5, NULL
    // 0x864a2c: b.ne            #0x864a34
    // 0x864a30: r5 = true
    //     0x864a30: add             x5, NULL, #0x20  ; true
    // 0x864a34: ldr             x1, [fp, #0x18]
    // 0x864a38: ldur            x16, [fp, #-0x38]
    // 0x864a3c: stp             x16, x1, [SP, #-0x10]!
    // 0x864a40: r16 = Instance__ScaffoldSlot
    //     0x864a40: add             x16, PP, #0x21, lsl #12  ; [pp+0x21d68] Obj!_ScaffoldSlot@b65371
    //     0x864a44: ldr             x16, [x16, #0xd68]
    // 0x864a48: stp             x16, x2, [SP, #-0x10]!
    // 0x864a4c: r16 = false
    //     0x864a4c: add             x16, NULL, #0x30  ; false
    // 0x864a50: stp             x16, x3, [SP, #-0x10]!
    // 0x864a54: r16 = false
    //     0x864a54: add             x16, NULL, #0x30  ; false
    // 0x864a58: stp             x4, x16, [SP, #-0x10]!
    // 0x864a5c: SaveReg r5
    //     0x864a5c: str             x5, [SP, #-8]!
    // 0x864a60: r4 = const [0, 0x9, 0x9, 0x8, removeBottomInset, 0x8, null]
    //     0x864a60: add             x4, PP, #0x21, lsl #12  ; [pp+0x21d70] List(7) [0, 0x9, 0x9, 0x8, "removeBottomInset", 0x8, Null]
    //     0x864a64: ldr             x4, [x4, #0xd70]
    // 0x864a68: r0 = _addIfNonNull()
    //     0x864a68: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x864a6c: add             SP, SP, #0x48
    // 0x864a70: ldr             x0, [fp, #0x18]
    // 0x864a74: LoadField: r1 = r0->field_77
    //     0x864a74: ldur            w1, [x0, #0x77]
    // 0x864a78: DecompressPointer r1
    //     0x864a78: add             x1, x1, HEAP, lsl #32
    // 0x864a7c: tbnz            w1, #4, #0x864ae8
    // 0x864a80: LoadField: r1 = r0->field_7b
    //     0x864a80: ldur            w1, [x0, #0x7b]
    // 0x864a84: DecompressPointer r1
    //     0x864a84: add             x1, x1, HEAP, lsl #32
    // 0x864a88: stur            x1, [fp, #-0x20]
    // 0x864a8c: r0 = ModalBarrier()
    //     0x864a8c: bl              #0x865960  ; AllocateModalBarrierStub -> ModalBarrier (size=0x20)
    // 0x864a90: mov             x1, x0
    // 0x864a94: ldur            x0, [fp, #-0x20]
    // 0x864a98: StoreField: r1->field_b = r0
    //     0x864a98: stur            w0, [x1, #0xb]
    // 0x864a9c: r0 = false
    //     0x864a9c: add             x0, NULL, #0x30  ; false
    // 0x864aa0: StoreField: r1->field_f = r0
    //     0x864aa0: stur            w0, [x1, #0xf]
    // 0x864aa4: r2 = true
    //     0x864aa4: add             x2, NULL, #0x20  ; true
    // 0x864aa8: StoreField: r1->field_17 = r2
    //     0x864aa8: stur            w2, [x1, #0x17]
    // 0x864aac: ldr             x16, [fp, #0x18]
    // 0x864ab0: ldur            lr, [fp, #-0x38]
    // 0x864ab4: stp             lr, x16, [SP, #-0x10]!
    // 0x864ab8: r16 = Instance__ScaffoldSlot
    //     0x864ab8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21d78] Obj!_ScaffoldSlot@b65351
    //     0x864abc: ldr             x16, [x16, #0xd78]
    // 0x864ac0: stp             x16, x1, [SP, #-0x10]!
    // 0x864ac4: r16 = true
    //     0x864ac4: add             x16, NULL, #0x20  ; true
    // 0x864ac8: r30 = true
    //     0x864ac8: add             lr, NULL, #0x20  ; true
    // 0x864acc: stp             lr, x16, [SP, #-0x10]!
    // 0x864ad0: r16 = true
    //     0x864ad0: add             x16, NULL, #0x20  ; true
    // 0x864ad4: r30 = true
    //     0x864ad4: add             lr, NULL, #0x20  ; true
    // 0x864ad8: stp             lr, x16, [SP, #-0x10]!
    // 0x864adc: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0x864adc: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0x864ae0: r0 = _addIfNonNull()
    //     0x864ae0: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x864ae4: add             SP, SP, #0x40
    // 0x864ae8: ldr             x1, [fp, #0x18]
    // 0x864aec: LoadField: r0 = r1->field_b
    //     0x864aec: ldur            w0, [x1, #0xb]
    // 0x864af0: DecompressPointer r0
    //     0x864af0: add             x0, x0, HEAP, lsl #32
    // 0x864af4: cmp             w0, NULL
    // 0x864af8: b.eq            #0x86552c
    // 0x864afc: LoadField: r2 = r0->field_13
    //     0x864afc: ldur            w2, [x0, #0x13]
    // 0x864b00: DecompressPointer r2
    //     0x864b00: add             x2, x2, HEAP, lsl #32
    // 0x864b04: cmp             w2, NULL
    // 0x864b08: b.eq            #0x864c58
    // 0x864b0c: ldur            x3, [fp, #-0x10]
    // 0x864b10: LoadField: r0 = r3->field_23
    //     0x864b10: ldur            w0, [x3, #0x23]
    // 0x864b14: DecompressPointer r0
    //     0x864b14: add             x0, x0, HEAP, lsl #32
    // 0x864b18: LoadField: d0 = r0->field_f
    //     0x864b18: ldur            d0, [x0, #0xf]
    // 0x864b1c: stur            d0, [fp, #-0x48]
    // 0x864b20: r0 = LoadClassIdInstr(r2)
    //     0x864b20: ldur            x0, [x2, #-1]
    //     0x864b24: ubfx            x0, x0, #0xc, #0x14
    // 0x864b28: SaveReg r2
    //     0x864b28: str             x2, [SP, #-8]!
    // 0x864b2c: r0 = GDT[cid_x0 + -0xf31]()
    //     0x864b2c: sub             lr, x0, #0xf31
    //     0x864b30: ldr             lr, [x21, lr, lsl #3]
    //     0x864b34: blr             lr
    // 0x864b38: add             SP, SP, #8
    // 0x864b3c: ldr             x16, [fp, #0x10]
    // 0x864b40: stp             x0, x16, [SP, #-0x10]!
    // 0x864b44: r0 = preferredHeightFor()
    //     0x864b44: bl              #0x8658c0  ; [package:flutter/src/material/app_bar.dart] AppBar::preferredHeightFor
    // 0x864b48: add             SP, SP, #0x10
    // 0x864b4c: mov             v1.16b, v0.16b
    // 0x864b50: ldur            d0, [fp, #-0x48]
    // 0x864b54: fadd            d2, d1, d0
    // 0x864b58: stur            d2, [fp, #-0x50]
    // 0x864b5c: r0 = inline_Allocate_Double()
    //     0x864b5c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x864b60: add             x0, x0, #0x10
    //     0x864b64: cmp             x1, x0
    //     0x864b68: b.ls            #0x865530
    //     0x864b6c: str             x0, [THR, #0x60]  ; THR::top
    //     0x864b70: sub             x0, x0, #0xf
    //     0x864b74: mov             x1, #0xd108
    //     0x864b78: movk            x1, #3, lsl #16
    //     0x864b7c: stur            x1, [x0, #-1]
    // 0x864b80: StoreField: r0->field_7 = d2
    //     0x864b80: stur            d2, [x0, #7]
    // 0x864b84: ldr             x1, [fp, #0x18]
    // 0x864b88: StoreField: r1->field_37 = r0
    //     0x864b88: stur            w0, [x1, #0x37]
    //     0x864b8c: ldurb           w16, [x1, #-1]
    //     0x864b90: ldurb           w17, [x0, #-1]
    //     0x864b94: and             x16, x17, x16, lsr #2
    //     0x864b98: tst             x16, HEAP, lsr #32
    //     0x864b9c: b.eq            #0x864ba4
    //     0x864ba0: bl              #0xd6826c
    // 0x864ba4: r0 = BoxConstraints()
    //     0x864ba4: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x864ba8: d0 = 0.000000
    //     0x864ba8: eor             v0.16b, v0.16b, v0.16b
    // 0x864bac: stur            x0, [fp, #-0x20]
    // 0x864bb0: StoreField: r0->field_7 = d0
    //     0x864bb0: stur            d0, [x0, #7]
    // 0x864bb4: d1 = inf
    //     0x864bb4: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x864bb8: StoreField: r0->field_f = d1
    //     0x864bb8: stur            d1, [x0, #0xf]
    // 0x864bbc: StoreField: r0->field_17 = d0
    //     0x864bbc: stur            d0, [x0, #0x17]
    // 0x864bc0: ldur            d1, [fp, #-0x50]
    // 0x864bc4: StoreField: r0->field_1f = d1
    //     0x864bc4: stur            d1, [x0, #0x1f]
    // 0x864bc8: ldr             x1, [fp, #0x18]
    // 0x864bcc: LoadField: r2 = r1->field_b
    //     0x864bcc: ldur            w2, [x1, #0xb]
    // 0x864bd0: DecompressPointer r2
    //     0x864bd0: add             x2, x2, HEAP, lsl #32
    // 0x864bd4: cmp             w2, NULL
    // 0x864bd8: b.eq            #0x865540
    // 0x864bdc: LoadField: r3 = r2->field_13
    //     0x864bdc: ldur            w3, [x2, #0x13]
    // 0x864be0: DecompressPointer r3
    //     0x864be0: add             x3, x3, HEAP, lsl #32
    // 0x864be4: cmp             w3, NULL
    // 0x864be8: b.eq            #0x865544
    // 0x864bec: SaveReg r3
    //     0x864bec: str             x3, [SP, #-8]!
    // 0x864bf0: SaveReg d1
    //     0x864bf0: str             d1, [SP, #-8]!
    // 0x864bf4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x864bf4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x864bf8: r0 = createSettings()
    //     0x864bf8: bl              #0x8656ac  ; [package:flutter/src/material/flexible_space_bar.dart] FlexibleSpaceBar::createSettings
    // 0x864bfc: add             SP, SP, #0x10
    // 0x864c00: stur            x0, [fp, #-0x28]
    // 0x864c04: r0 = ConstrainedBox()
    //     0x864c04: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x864c08: mov             x1, x0
    // 0x864c0c: ldur            x0, [fp, #-0x20]
    // 0x864c10: StoreField: r1->field_f = r0
    //     0x864c10: stur            w0, [x1, #0xf]
    // 0x864c14: ldur            x0, [fp, #-0x28]
    // 0x864c18: StoreField: r1->field_b = r0
    //     0x864c18: stur            w0, [x1, #0xb]
    // 0x864c1c: ldr             x16, [fp, #0x18]
    // 0x864c20: ldur            lr, [fp, #-0x38]
    // 0x864c24: stp             lr, x16, [SP, #-0x10]!
    // 0x864c28: r16 = Instance__ScaffoldSlot
    //     0x864c28: add             x16, PP, #0x21, lsl #12  ; [pp+0x21d80] Obj!_ScaffoldSlot@b65331
    //     0x864c2c: ldr             x16, [x16, #0xd80]
    // 0x864c30: stp             x16, x1, [SP, #-0x10]!
    // 0x864c34: r16 = true
    //     0x864c34: add             x16, NULL, #0x20  ; true
    // 0x864c38: r30 = false
    //     0x864c38: add             lr, NULL, #0x30  ; false
    // 0x864c3c: stp             lr, x16, [SP, #-0x10]!
    // 0x864c40: r16 = false
    //     0x864c40: add             x16, NULL, #0x30  ; false
    // 0x864c44: r30 = false
    //     0x864c44: add             lr, NULL, #0x30  ; false
    // 0x864c48: stp             lr, x16, [SP, #-0x10]!
    // 0x864c4c: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0x864c4c: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0x864c50: r0 = _addIfNonNull()
    //     0x864c50: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x864c54: add             SP, SP, #0x40
    // 0x864c58: ldr             x0, [fp, #0x18]
    // 0x864c5c: ldur            x2, [fp, #-8]
    // 0x864c60: r1 = false
    //     0x864c60: add             x1, NULL, #0x30  ; false
    // 0x864c64: StoreField: r2->field_1b = r1
    //     0x864c64: stur            w1, [x2, #0x1b]
    // 0x864c68: StoreField: r2->field_1f = rNULL
    //     0x864c68: stur            NULL, [x2, #0x1f]
    // 0x864c6c: LoadField: r3 = r0->field_53
    //     0x864c6c: ldur            w3, [x0, #0x53]
    // 0x864c70: DecompressPointer r3
    //     0x864c70: add             x3, x3, HEAP, lsl #32
    // 0x864c74: cmp             w3, NULL
    // 0x864c78: b.ne            #0x864c90
    // 0x864c7c: LoadField: r3 = r0->field_4f
    //     0x864c7c: ldur            w3, [x0, #0x4f]
    // 0x864c80: DecompressPointer r3
    //     0x864c80: add             x3, x3, HEAP, lsl #32
    // 0x864c84: LoadField: r4 = r3->field_b
    //     0x864c84: ldur            w4, [x3, #0xb]
    // 0x864c88: DecompressPointer r4
    //     0x864c88: add             x4, x4, HEAP, lsl #32
    // 0x864c8c: cbz             w4, #0x864d7c
    // 0x864c90: LoadField: r3 = r0->field_4f
    //     0x864c90: ldur            w3, [x0, #0x4f]
    // 0x864c94: DecompressPointer r3
    //     0x864c94: add             x3, x3, HEAP, lsl #32
    // 0x864c98: r16 = <Widget>
    //     0x864c98: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x864c9c: ldr             x16, [x16, #0xea8]
    // 0x864ca0: stp             x3, x16, [SP, #-0x10]!
    // 0x864ca4: r0 = _GrowableList.of()
    //     0x864ca4: bl              #0x4bfaf0  ; [dart:core] _GrowableList::_GrowableList.of
    // 0x864ca8: add             SP, SP, #0x10
    // 0x864cac: mov             x1, x0
    // 0x864cb0: ldr             x0, [fp, #0x18]
    // 0x864cb4: stur            x1, [fp, #-0x20]
    // 0x864cb8: LoadField: r2 = r0->field_53
    //     0x864cb8: ldur            w2, [x0, #0x53]
    // 0x864cbc: DecompressPointer r2
    //     0x864cbc: add             x2, x2, HEAP, lsl #32
    // 0x864cc0: cmp             w2, NULL
    // 0x864cc4: b.eq            #0x864cdc
    // 0x864cc8: LoadField: r3 = r2->field_b
    //     0x864cc8: ldur            w3, [x2, #0xb]
    // 0x864ccc: DecompressPointer r3
    //     0x864ccc: add             x3, x3, HEAP, lsl #32
    // 0x864cd0: stp             x3, x1, [SP, #-0x10]!
    // 0x864cd4: r0 = add()
    //     0x864cd4: bl              #0x60bf60  ; [dart:core] _GrowableList::add
    // 0x864cd8: add             SP, SP, #0x10
    // 0x864cdc: ldr             x0, [fp, #0x18]
    // 0x864ce0: ldur            x1, [fp, #-0x20]
    // 0x864ce4: r0 = Stack()
    //     0x864ce4: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x864ce8: mov             x1, x0
    // 0x864cec: r0 = Instance_Alignment
    //     0x864cec: add             x0, PP, #0xd, lsl #12  ; [pp+0xdca8] Obj!Alignment@b37a91
    //     0x864cf0: ldr             x0, [x0, #0xca8]
    // 0x864cf4: StoreField: r1->field_f = r0
    //     0x864cf4: stur            w0, [x1, #0xf]
    // 0x864cf8: r0 = Instance_StackFit
    //     0x864cf8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x864cfc: ldr             x0, [x0, #0xf78]
    // 0x864d00: StoreField: r1->field_17 = r0
    //     0x864d00: stur            w0, [x1, #0x17]
    // 0x864d04: r0 = Instance_Clip
    //     0x864d04: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x864d08: ldr             x0, [x0, #0x678]
    // 0x864d0c: StoreField: r1->field_1b = r0
    //     0x864d0c: stur            w0, [x1, #0x1b]
    // 0x864d10: ldur            x0, [fp, #-0x20]
    // 0x864d14: StoreField: r1->field_b = r0
    //     0x864d14: stur            w0, [x1, #0xb]
    // 0x864d18: ldr             x0, [fp, #0x18]
    // 0x864d1c: LoadField: r2 = r0->field_b
    //     0x864d1c: ldur            w2, [x0, #0xb]
    // 0x864d20: DecompressPointer r2
    //     0x864d20: add             x2, x2, HEAP, lsl #32
    // 0x864d24: cmp             w2, NULL
    // 0x864d28: b.eq            #0x865548
    // 0x864d2c: LoadField: r3 = r2->field_4f
    //     0x864d2c: ldur            w3, [x2, #0x4f]
    // 0x864d30: DecompressPointer r3
    //     0x864d30: add             x3, x3, HEAP, lsl #32
    // 0x864d34: cmp             w3, NULL
    // 0x864d38: b.ne            #0x864d44
    // 0x864d3c: r2 = true
    //     0x864d3c: add             x2, NULL, #0x20  ; true
    // 0x864d40: b               #0x864d48
    // 0x864d44: mov             x2, x3
    // 0x864d48: ldur            x16, [fp, #-0x38]
    // 0x864d4c: stp             x16, x0, [SP, #-0x10]!
    // 0x864d50: r16 = Instance__ScaffoldSlot
    //     0x864d50: add             x16, PP, #0x21, lsl #12  ; [pp+0x21d88] Obj!_ScaffoldSlot@b65311
    //     0x864d54: ldr             x16, [x16, #0xd88]
    // 0x864d58: stp             x16, x1, [SP, #-0x10]!
    // 0x864d5c: r16 = false
    //     0x864d5c: add             x16, NULL, #0x30  ; false
    // 0x864d60: stp             x16, x2, [SP, #-0x10]!
    // 0x864d64: r16 = false
    //     0x864d64: add             x16, NULL, #0x30  ; false
    // 0x864d68: r30 = true
    //     0x864d68: add             lr, NULL, #0x20  ; true
    // 0x864d6c: stp             lr, x16, [SP, #-0x10]!
    // 0x864d70: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0x864d70: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0x864d74: r0 = _addIfNonNull()
    //     0x864d74: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x864d78: add             SP, SP, #0x40
    // 0x864d7c: ldr             x0, [fp, #0x18]
    // 0x864d80: LoadField: r1 = r0->field_47
    //     0x864d80: ldur            w1, [x0, #0x47]
    // 0x864d84: DecompressPointer r1
    //     0x864d84: add             x1, x1, HEAP, lsl #32
    // 0x864d88: cmp             w1, NULL
    // 0x864d8c: b.eq            #0x864ef0
    // 0x864d90: ldur            x2, [fp, #-8]
    // 0x864d94: LoadField: r3 = r1->field_b
    //     0x864d94: ldur            w3, [x1, #0xb]
    // 0x864d98: DecompressPointer r3
    //     0x864d98: add             x3, x3, HEAP, lsl #32
    // 0x864d9c: SaveReg r3
    //     0x864d9c: str             x3, [SP, #-8]!
    // 0x864da0: r4 = 0
    //     0x864da0: mov             x4, #0
    // 0x864da4: ldr             x0, [SP]
    // 0x864da8: r16 = UnlinkedCall_0x4aeefc
    //     0x864da8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21d90] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x864dac: add             x16, x16, #0xd90
    // 0x864db0: ldp             x5, lr, [x16]
    // 0x864db4: blr             lr
    // 0x864db8: add             SP, SP, #8
    // 0x864dbc: ldur            x2, [fp, #-8]
    // 0x864dc0: r0 = false
    //     0x864dc0: add             x0, NULL, #0x30  ; false
    // 0x864dc4: StoreField: r2->field_1b = r0
    //     0x864dc4: stur            w0, [x2, #0x1b]
    // 0x864dc8: ldr             x1, [fp, #0x18]
    // 0x864dcc: LoadField: r3 = r1->field_47
    //     0x864dcc: ldur            w3, [x1, #0x47]
    // 0x864dd0: DecompressPointer r3
    //     0x864dd0: add             x3, x3, HEAP, lsl #32
    // 0x864dd4: cmp             w3, NULL
    // 0x864dd8: b.eq            #0x864e0c
    // 0x864ddc: LoadField: r4 = r3->field_b
    //     0x864ddc: ldur            w4, [x3, #0xb]
    // 0x864de0: DecompressPointer r4
    //     0x864de0: add             x4, x4, HEAP, lsl #32
    // 0x864de4: SaveReg r4
    //     0x864de4: str             x4, [SP, #-8]!
    // 0x864de8: r4 = 0
    //     0x864de8: mov             x4, #0
    // 0x864dec: ldr             x0, [SP]
    // 0x864df0: r16 = UnlinkedCall_0x4aeefc
    //     0x864df0: add             x16, PP, #0x21, lsl #12  ; [pp+0x21da0] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x864df4: add             x16, x16, #0xda0
    // 0x864df8: ldp             x5, lr, [x16]
    // 0x864dfc: blr             lr
    // 0x864e00: add             SP, SP, #8
    // 0x864e04: ldr             x1, [fp, #0x18]
    // 0x864e08: ldur            x2, [fp, #-8]
    // 0x864e0c: ldur            x3, [fp, #-0x18]
    // 0x864e10: r17 = 291
    //     0x864e10: mov             x17, #0x123
    // 0x864e14: ldr             w0, [x3, x17]
    // 0x864e18: DecompressPointer r0
    //     0x864e18: add             x0, x0, HEAP, lsl #32
    // 0x864e1c: LoadField: r4 = r0->field_23
    //     0x864e1c: ldur            w4, [x0, #0x23]
    // 0x864e20: DecompressPointer r4
    //     0x864e20: add             x4, x4, HEAP, lsl #32
    // 0x864e24: mov             x0, x4
    // 0x864e28: StoreField: r2->field_1f = r0
    //     0x864e28: stur            w0, [x2, #0x1f]
    //     0x864e2c: ldurb           w16, [x2, #-1]
    //     0x864e30: ldurb           w17, [x0, #-1]
    //     0x864e34: and             x16, x17, x16, lsr #2
    //     0x864e38: tst             x16, HEAP, lsr #32
    //     0x864e3c: b.eq            #0x864e44
    //     0x864e40: bl              #0xd6828c
    // 0x864e44: LoadField: r0 = r1->field_47
    //     0x864e44: ldur            w0, [x1, #0x47]
    // 0x864e48: DecompressPointer r0
    //     0x864e48: add             x0, x0, HEAP, lsl #32
    // 0x864e4c: cmp             w0, NULL
    // 0x864e50: b.ne            #0x864e5c
    // 0x864e54: r0 = Null
    //     0x864e54: mov             x0, NULL
    // 0x864e58: b               #0x864e68
    // 0x864e5c: LoadField: r4 = r0->field_b
    //     0x864e5c: ldur            w4, [x0, #0xb]
    // 0x864e60: DecompressPointer r4
    //     0x864e60: add             x4, x4, HEAP, lsl #32
    // 0x864e64: mov             x0, x4
    // 0x864e68: LoadField: r4 = r1->field_b
    //     0x864e68: ldur            w4, [x1, #0xb]
    // 0x864e6c: DecompressPointer r4
    //     0x864e6c: add             x4, x4, HEAP, lsl #32
    // 0x864e70: cmp             w4, NULL
    // 0x864e74: b.eq            #0x86554c
    // 0x864e78: LoadField: r5 = r4->field_47
    //     0x864e78: ldur            w5, [x4, #0x47]
    // 0x864e7c: DecompressPointer r5
    //     0x864e7c: add             x5, x5, HEAP, lsl #32
    // 0x864e80: cmp             w5, NULL
    // 0x864e84: b.eq            #0x864e90
    // 0x864e88: r5 = true
    //     0x864e88: add             x5, NULL, #0x20  ; true
    // 0x864e8c: b               #0x864e94
    // 0x864e90: r5 = false
    //     0x864e90: add             x5, NULL, #0x30  ; false
    // 0x864e94: LoadField: r6 = r4->field_4f
    //     0x864e94: ldur            w6, [x4, #0x4f]
    // 0x864e98: DecompressPointer r6
    //     0x864e98: add             x6, x6, HEAP, lsl #32
    // 0x864e9c: cmp             w6, NULL
    // 0x864ea0: b.ne            #0x864eac
    // 0x864ea4: r4 = true
    //     0x864ea4: add             x4, NULL, #0x20  ; true
    // 0x864ea8: b               #0x864eb0
    // 0x864eac: mov             x4, x6
    // 0x864eb0: eor             x6, x4, #0x10
    // 0x864eb4: ldur            x16, [fp, #-0x38]
    // 0x864eb8: stp             x16, x1, [SP, #-0x10]!
    // 0x864ebc: r16 = Instance__ScaffoldSlot
    //     0x864ebc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21db0] Obj!_ScaffoldSlot@b652f1
    //     0x864ec0: ldr             x16, [x16, #0xdb0]
    // 0x864ec4: stp             x16, x0, [SP, #-0x10]!
    // 0x864ec8: r16 = false
    //     0x864ec8: add             x16, NULL, #0x30  ; false
    // 0x864ecc: stp             x16, x5, [SP, #-0x10]!
    // 0x864ed0: r16 = false
    //     0x864ed0: add             x16, NULL, #0x30  ; false
    // 0x864ed4: r30 = true
    //     0x864ed4: add             lr, NULL, #0x20  ; true
    // 0x864ed8: stp             lr, x16, [SP, #-0x10]!
    // 0x864edc: SaveReg r6
    //     0x864edc: str             x6, [SP, #-8]!
    // 0x864ee0: r4 = const [0, 0x9, 0x9, 0x8, maintainBottomViewPadding, 0x8, null]
    //     0x864ee0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21db8] List(7) [0, 0x9, 0x9, 0x8, "maintainBottomViewPadding", 0x8, Null]
    //     0x864ee4: ldr             x4, [x4, #0xdb8]
    // 0x864ee8: r0 = _addIfNonNull()
    //     0x864ee8: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x864eec: add             SP, SP, #0x48
    // 0x864ef0: ldr             x0, [fp, #0x18]
    // 0x864ef4: ldur            x2, [fp, #-8]
    // 0x864ef8: r1 = false
    //     0x864ef8: add             x1, NULL, #0x30  ; false
    // 0x864efc: StoreField: r2->field_23 = r1
    //     0x864efc: stur            w1, [x2, #0x23]
    // 0x864f00: LoadField: r3 = r0->field_4b
    //     0x864f00: ldur            w3, [x0, #0x4b]
    // 0x864f04: DecompressPointer r3
    //     0x864f04: add             x3, x3, HEAP, lsl #32
    // 0x864f08: cmp             w3, NULL
    // 0x864f0c: b.eq            #0x86500c
    // 0x864f10: ldr             x16, [fp, #0x10]
    // 0x864f14: SaveReg r16
    //     0x864f14: str             x16, [SP, #-8]!
    // 0x864f18: r0 = of()
    //     0x864f18: bl              #0x86564c  ; [package:flutter/src/material/banner_theme.dart] MaterialBannerTheme::of
    // 0x864f1c: add             SP, SP, #8
    // 0x864f20: mov             x1, x0
    // 0x864f24: ldr             x0, [fp, #0x18]
    // 0x864f28: LoadField: r2 = r0->field_4b
    //     0x864f28: ldur            w2, [x0, #0x4b]
    // 0x864f2c: DecompressPointer r2
    //     0x864f2c: add             x2, x2, HEAP, lsl #32
    // 0x864f30: LoadField: r3 = r1->field_1b
    //     0x864f30: ldur            w3, [x1, #0x1b]
    // 0x864f34: DecompressPointer r3
    //     0x864f34: add             x3, x3, HEAP, lsl #32
    // 0x864f38: cmp             w3, NULL
    // 0x864f3c: b.ne            #0x864f48
    // 0x864f40: d1 = 0.000000
    //     0x864f40: eor             v1.16b, v1.16b, v1.16b
    // 0x864f44: b               #0x864f50
    // 0x864f48: LoadField: d0 = r3->field_7
    //     0x864f48: ldur            d0, [x3, #7]
    // 0x864f4c: mov             v1.16b, v0.16b
    // 0x864f50: ldur            x1, [fp, #-8]
    // 0x864f54: d0 = 0.000000
    //     0x864f54: eor             v0.16b, v0.16b, v0.16b
    // 0x864f58: fcmp            d1, d0
    // 0x864f5c: r16 = true
    //     0x864f5c: add             x16, NULL, #0x20  ; true
    // 0x864f60: r17 = false
    //     0x864f60: add             x17, NULL, #0x30  ; false
    // 0x864f64: csel            x3, x16, x17, ne
    // 0x864f68: StoreField: r1->field_23 = r3
    //     0x864f68: stur            w3, [x1, #0x23]
    // 0x864f6c: cmp             w2, NULL
    // 0x864f70: b.ne            #0x864f7c
    // 0x864f74: r2 = Null
    //     0x864f74: mov             x2, NULL
    // 0x864f78: b               #0x864f88
    // 0x864f7c: LoadField: r3 = r2->field_b
    //     0x864f7c: ldur            w3, [x2, #0xb]
    // 0x864f80: DecompressPointer r3
    //     0x864f80: add             x3, x3, HEAP, lsl #32
    // 0x864f84: mov             x2, x3
    // 0x864f88: LoadField: r3 = r0->field_b
    //     0x864f88: ldur            w3, [x0, #0xb]
    // 0x864f8c: DecompressPointer r3
    //     0x864f8c: add             x3, x3, HEAP, lsl #32
    // 0x864f90: cmp             w3, NULL
    // 0x864f94: b.eq            #0x865550
    // 0x864f98: LoadField: r4 = r3->field_13
    //     0x864f98: ldur            w4, [x3, #0x13]
    // 0x864f9c: DecompressPointer r4
    //     0x864f9c: add             x4, x4, HEAP, lsl #32
    // 0x864fa0: cmp             w4, NULL
    // 0x864fa4: r16 = true
    //     0x864fa4: add             x16, NULL, #0x20  ; true
    // 0x864fa8: r17 = false
    //     0x864fa8: add             x17, NULL, #0x30  ; false
    // 0x864fac: csel            x5, x16, x17, ne
    // 0x864fb0: LoadField: r4 = r3->field_4f
    //     0x864fb0: ldur            w4, [x3, #0x4f]
    // 0x864fb4: DecompressPointer r4
    //     0x864fb4: add             x4, x4, HEAP, lsl #32
    // 0x864fb8: cmp             w4, NULL
    // 0x864fbc: b.ne            #0x864fc8
    // 0x864fc0: r3 = true
    //     0x864fc0: add             x3, NULL, #0x20  ; true
    // 0x864fc4: b               #0x864fcc
    // 0x864fc8: mov             x3, x4
    // 0x864fcc: eor             x4, x3, #0x10
    // 0x864fd0: ldur            x16, [fp, #-0x38]
    // 0x864fd4: stp             x16, x0, [SP, #-0x10]!
    // 0x864fd8: r16 = Instance__ScaffoldSlot
    //     0x864fd8: add             x16, PP, #0x21, lsl #12  ; [pp+0x21dc0] Obj!_ScaffoldSlot@b652d1
    //     0x864fdc: ldr             x16, [x16, #0xdc0]
    // 0x864fe0: stp             x16, x2, [SP, #-0x10]!
    // 0x864fe4: r16 = true
    //     0x864fe4: add             x16, NULL, #0x20  ; true
    // 0x864fe8: r30 = false
    //     0x864fe8: add             lr, NULL, #0x30  ; false
    // 0x864fec: stp             lr, x16, [SP, #-0x10]!
    // 0x864ff0: r16 = false
    //     0x864ff0: add             x16, NULL, #0x30  ; false
    // 0x864ff4: stp             x5, x16, [SP, #-0x10]!
    // 0x864ff8: SaveReg r4
    //     0x864ff8: str             x4, [SP, #-8]!
    // 0x864ffc: r4 = const [0, 0x9, 0x9, 0x8, maintainBottomViewPadding, 0x8, null]
    //     0x864ffc: add             x4, PP, #0x21, lsl #12  ; [pp+0x21db8] List(7) [0, 0x9, 0x9, 0x8, "maintainBottomViewPadding", 0x8, Null]
    //     0x865000: ldr             x4, [x4, #0xdb8]
    // 0x865004: r0 = _addIfNonNull()
    //     0x865004: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x865008: add             SP, SP, #0x48
    // 0x86500c: ldr             x0, [fp, #0x18]
    // 0x865010: LoadField: r1 = r0->field_b
    //     0x865010: ldur            w1, [x0, #0xb]
    // 0x865014: DecompressPointer r1
    //     0x865014: add             x1, x1, HEAP, lsl #32
    // 0x865018: cmp             w1, NULL
    // 0x86501c: b.eq            #0x865554
    // 0x865020: LoadField: r2 = r1->field_47
    //     0x865020: ldur            w2, [x1, #0x47]
    // 0x865024: DecompressPointer r2
    //     0x865024: add             x2, x2, HEAP, lsl #32
    // 0x865028: cmp             w2, NULL
    // 0x86502c: b.eq            #0x865090
    // 0x865030: LoadField: r3 = r1->field_4f
    //     0x865030: ldur            w3, [x1, #0x4f]
    // 0x865034: DecompressPointer r3
    //     0x865034: add             x3, x3, HEAP, lsl #32
    // 0x865038: cmp             w3, NULL
    // 0x86503c: b.ne            #0x865048
    // 0x865040: r1 = true
    //     0x865040: add             x1, NULL, #0x20  ; true
    // 0x865044: b               #0x86504c
    // 0x865048: mov             x1, x3
    // 0x86504c: eor             x3, x1, #0x10
    // 0x865050: ldur            x16, [fp, #-0x38]
    // 0x865054: stp             x16, x0, [SP, #-0x10]!
    // 0x865058: r16 = Instance__ScaffoldSlot
    //     0x865058: add             x16, PP, #0x21, lsl #12  ; [pp+0x21dc8] Obj!_ScaffoldSlot@b652b1
    //     0x86505c: ldr             x16, [x16, #0xdc8]
    // 0x865060: stp             x16, x2, [SP, #-0x10]!
    // 0x865064: r16 = false
    //     0x865064: add             x16, NULL, #0x30  ; false
    // 0x865068: r30 = false
    //     0x865068: add             lr, NULL, #0x30  ; false
    // 0x86506c: stp             lr, x16, [SP, #-0x10]!
    // 0x865070: r16 = false
    //     0x865070: add             x16, NULL, #0x30  ; false
    // 0x865074: r30 = true
    //     0x865074: add             lr, NULL, #0x20  ; true
    // 0x865078: stp             lr, x16, [SP, #-0x10]!
    // 0x86507c: SaveReg r3
    //     0x86507c: str             x3, [SP, #-8]!
    // 0x865080: r4 = const [0, 0x9, 0x9, 0x8, maintainBottomViewPadding, 0x8, null]
    //     0x865080: add             x4, PP, #0x21, lsl #12  ; [pp+0x21db8] List(7) [0, 0x9, 0x9, 0x8, "maintainBottomViewPadding", 0x8, Null]
    //     0x865084: ldr             x4, [x4, #0xdb8]
    // 0x865088: r0 = _addIfNonNull()
    //     0x865088: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x86508c: add             SP, SP, #0x48
    // 0x865090: ldr             x0, [fp, #0x18]
    // 0x865094: ldur            x1, [fp, #-0x18]
    // 0x865098: LoadField: r2 = r0->field_5f
    //     0x865098: ldur            w2, [x0, #0x5f]
    // 0x86509c: DecompressPointer r2
    //     0x86509c: add             x2, x2, HEAP, lsl #32
    // 0x8650a0: r16 = Sentinel
    //     0x8650a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8650a4: cmp             w2, w16
    // 0x8650a8: b.eq            #0x865558
    // 0x8650ac: stur            x2, [fp, #-0x30]
    // 0x8650b0: LoadField: r3 = r0->field_63
    //     0x8650b0: ldur            w3, [x0, #0x63]
    // 0x8650b4: DecompressPointer r3
    //     0x8650b4: add             x3, x3, HEAP, lsl #32
    // 0x8650b8: r16 = Sentinel
    //     0x8650b8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8650bc: cmp             w3, w16
    // 0x8650c0: b.eq            #0x865564
    // 0x8650c4: LoadField: r3 = r0->field_73
    //     0x8650c4: ldur            w3, [x0, #0x73]
    // 0x8650c8: DecompressPointer r3
    //     0x8650c8: add             x3, x3, HEAP, lsl #32
    // 0x8650cc: r16 = Sentinel
    //     0x8650cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8650d0: cmp             w3, w16
    // 0x8650d4: b.eq            #0x865570
    // 0x8650d8: stur            x3, [fp, #-0x28]
    // 0x8650dc: LoadField: r4 = r0->field_6f
    //     0x8650dc: ldur            w4, [x0, #0x6f]
    // 0x8650e0: DecompressPointer r4
    //     0x8650e0: add             x4, x4, HEAP, lsl #32
    // 0x8650e4: r16 = Sentinel
    //     0x8650e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8650e8: cmp             w4, w16
    // 0x8650ec: b.eq            #0x86557c
    // 0x8650f0: stur            x4, [fp, #-0x20]
    // 0x8650f4: LoadField: r5 = r0->field_b
    //     0x8650f4: ldur            w5, [x0, #0xb]
    // 0x8650f8: DecompressPointer r5
    //     0x8650f8: add             x5, x5, HEAP, lsl #32
    // 0x8650fc: cmp             w5, NULL
    // 0x865100: b.eq            #0x865588
    // 0x865104: r0 = _FloatingActionButtonTransition()
    //     0x865104: bl              #0x865640  ; Allocate_FloatingActionButtonTransitionStub -> _FloatingActionButtonTransition (size=0x20)
    // 0x865108: mov             x1, x0
    // 0x86510c: ldur            x0, [fp, #-0x30]
    // 0x865110: StoreField: r1->field_f = r0
    //     0x865110: stur            w0, [x1, #0xf]
    // 0x865114: r0 = Instance__ScalingFabMotionAnimator
    //     0x865114: add             x0, PP, #0x21, lsl #12  ; [pp+0x21dd0] Obj!_ScalingFabMotionAnimator@b38581
    //     0x865118: ldr             x0, [x0, #0xdd0]
    // 0x86511c: StoreField: r1->field_13 = r0
    //     0x86511c: stur            w0, [x1, #0x13]
    // 0x865120: ldur            x0, [fp, #-0x28]
    // 0x865124: StoreField: r1->field_17 = r0
    //     0x865124: stur            w0, [x1, #0x17]
    // 0x865128: ldur            x0, [fp, #-0x20]
    // 0x86512c: StoreField: r1->field_1b = r0
    //     0x86512c: stur            w0, [x1, #0x1b]
    // 0x865130: ldr             x16, [fp, #0x18]
    // 0x865134: ldur            lr, [fp, #-0x38]
    // 0x865138: stp             lr, x16, [SP, #-0x10]!
    // 0x86513c: r16 = Instance__ScaffoldSlot
    //     0x86513c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21dd8] Obj!_ScaffoldSlot@b65291
    //     0x865140: ldr             x16, [x16, #0xdd8]
    // 0x865144: stp             x16, x1, [SP, #-0x10]!
    // 0x865148: r16 = true
    //     0x865148: add             x16, NULL, #0x20  ; true
    // 0x86514c: r30 = true
    //     0x86514c: add             lr, NULL, #0x20  ; true
    // 0x865150: stp             lr, x16, [SP, #-0x10]!
    // 0x865154: r16 = true
    //     0x865154: add             x16, NULL, #0x20  ; true
    // 0x865158: r30 = true
    //     0x865158: add             lr, NULL, #0x20  ; true
    // 0x86515c: stp             lr, x16, [SP, #-0x10]!
    // 0x865160: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0x865160: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0x865164: r0 = _addIfNonNull()
    //     0x865164: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x865168: add             SP, SP, #0x40
    // 0x86516c: ldur            x0, [fp, #-0x18]
    // 0x865170: LoadField: r1 = r0->field_1f
    //     0x865170: ldur            w1, [x0, #0x1f]
    // 0x865174: DecompressPointer r1
    //     0x865174: add             x1, x1, HEAP, lsl #32
    // 0x865178: LoadField: r2 = r1->field_7
    //     0x865178: ldur            x2, [x1, #7]
    // 0x86517c: cmp             x2, #2
    // 0x865180: b.gt            #0x865190
    // 0x865184: cmp             x2, #1
    // 0x865188: b.gt            #0x8651a0
    // 0x86518c: b               #0x86523c
    // 0x865190: cmp             x2, #4
    // 0x865194: b.gt            #0x86523c
    // 0x865198: cmp             x2, #3
    // 0x86519c: b.le            #0x86523c
    // 0x8651a0: ldr             x1, [fp, #0x18]
    // 0x8651a4: r1 = 1
    //     0x8651a4: mov             x1, #1
    // 0x8651a8: r0 = AllocateContext()
    //     0x8651a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8651ac: mov             x1, x0
    // 0x8651b0: ldr             x0, [fp, #0x18]
    // 0x8651b4: stur            x1, [fp, #-0x20]
    // 0x8651b8: StoreField: r1->field_f = r0
    //     0x8651b8: stur            w0, [x1, #0xf]
    // 0x8651bc: r0 = GestureDetector()
    //     0x8651bc: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x8651c0: ldur            x2, [fp, #-0x20]
    // 0x8651c4: r1 = Function '_handleStatusBarTap@801420462':.
    //     0x8651c4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21de0] AnonymousClosure: (0x866668), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_handleStatusBarTap (0x8666b0)
    //     0x8651c8: ldr             x1, [x1, #0xde0]
    // 0x8651cc: stur            x0, [fp, #-0x20]
    // 0x8651d0: r0 = AllocateClosure()
    //     0x8651d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8651d4: ldur            x16, [fp, #-0x20]
    // 0x8651d8: r30 = Instance_HitTestBehavior
    //     0x8651d8: add             lr, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x8651dc: ldr             lr, [lr, #0x408]
    // 0x8651e0: stp             lr, x16, [SP, #-0x10]!
    // 0x8651e4: r16 = true
    //     0x8651e4: add             x16, NULL, #0x20  ; true
    // 0x8651e8: stp             x16, x0, [SP, #-0x10]!
    // 0x8651ec: r4 = const [0, 0x4, 0x4, 0x1, behavior, 0x1, excludeFromSemantics, 0x3, onTap, 0x2, null]
    //     0x8651ec: add             x4, PP, #0x21, lsl #12  ; [pp+0x21de8] List(11) [0, 0x4, 0x4, 0x1, "behavior", 0x1, "excludeFromSemantics", 0x3, "onTap", 0x2, Null]
    //     0x8651f0: ldr             x4, [x4, #0xde8]
    // 0x8651f4: r0 = GestureDetector()
    //     0x8651f4: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x8651f8: add             SP, SP, #0x20
    // 0x8651fc: ldr             x16, [fp, #0x18]
    // 0x865200: ldur            lr, [fp, #-0x38]
    // 0x865204: stp             lr, x16, [SP, #-0x10]!
    // 0x865208: ldur            x16, [fp, #-0x20]
    // 0x86520c: r30 = Instance__ScaffoldSlot
    //     0x86520c: add             lr, PP, #0x21, lsl #12  ; [pp+0x21df0] Obj!_ScaffoldSlot@b65271
    //     0x865210: ldr             lr, [lr, #0xdf0]
    // 0x865214: stp             lr, x16, [SP, #-0x10]!
    // 0x865218: r16 = true
    //     0x865218: add             x16, NULL, #0x20  ; true
    // 0x86521c: r30 = false
    //     0x86521c: add             lr, NULL, #0x30  ; false
    // 0x865220: stp             lr, x16, [SP, #-0x10]!
    // 0x865224: r16 = false
    //     0x865224: add             x16, NULL, #0x30  ; false
    // 0x865228: r30 = true
    //     0x865228: add             lr, NULL, #0x20  ; true
    // 0x86522c: stp             lr, x16, [SP, #-0x10]!
    // 0x865230: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0x865230: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0x865234: r0 = _addIfNonNull()
    //     0x865234: bl              #0x86596c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0x865238: add             SP, SP, #0x40
    // 0x86523c: ldr             x3, [fp, #0x18]
    // 0x865240: LoadField: r0 = r3->field_3f
    //     0x865240: ldur            w0, [x3, #0x3f]
    // 0x865244: DecompressPointer r0
    //     0x865244: add             x0, x0, HEAP, lsl #32
    // 0x865248: LoadField: r4 = r0->field_33
    //     0x865248: ldur            w4, [x0, #0x33]
    // 0x86524c: DecompressPointer r4
    //     0x86524c: add             x4, x4, HEAP, lsl #32
    // 0x865250: stur            x4, [fp, #-0x20]
    // 0x865254: cmp             w4, NULL
    // 0x865258: b.ne            #0x865290
    // 0x86525c: LoadField: r2 = r0->field_23
    //     0x86525c: ldur            w2, [x0, #0x23]
    // 0x865260: DecompressPointer r2
    //     0x865260: add             x2, x2, HEAP, lsl #32
    // 0x865264: mov             x0, x4
    // 0x865268: r1 = Null
    //     0x865268: mov             x1, NULL
    // 0x86526c: cmp             w2, NULL
    // 0x865270: b.eq            #0x865290
    // 0x865274: LoadField: r4 = r2->field_17
    //     0x865274: ldur            w4, [x2, #0x17]
    // 0x865278: DecompressPointer r4
    //     0x865278: add             x4, x4, HEAP, lsl #32
    // 0x86527c: r8 = X0
    //     0x86527c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x865280: LoadField: r9 = r4->field_7
    //     0x865280: ldur            x9, [x4, #7]
    // 0x865284: r3 = Null
    //     0x865284: add             x3, PP, #0x21, lsl #12  ; [pp+0x21df8] Null
    //     0x865288: ldr             x3, [x3, #0xdf8]
    // 0x86528c: blr             x9
    // 0x865290: ldur            x0, [fp, #-0x20]
    // 0x865294: tbnz            w0, #4, #0x8652b4
    // 0x865298: ldr             x0, [fp, #0x18]
    // 0x86529c: LoadField: r1 = r0->field_b
    //     0x86529c: ldur            w1, [x0, #0xb]
    // 0x8652a0: DecompressPointer r1
    //     0x8652a0: add             x1, x1, HEAP, lsl #32
    // 0x8652a4: cmp             w1, NULL
    // 0x8652a8: b.eq            #0x86558c
    // 0x8652ac: mov             x2, x1
    // 0x8652b0: b               #0x8652cc
    // 0x8652b4: ldr             x0, [fp, #0x18]
    // 0x8652b8: LoadField: r1 = r0->field_b
    //     0x8652b8: ldur            w1, [x0, #0xb]
    // 0x8652bc: DecompressPointer r1
    //     0x8652bc: add             x1, x1, HEAP, lsl #32
    // 0x8652c0: cmp             w1, NULL
    // 0x8652c4: b.eq            #0x865590
    // 0x8652c8: mov             x2, x1
    // 0x8652cc: ldur            x1, [fp, #-0x10]
    // 0x8652d0: LoadField: r3 = r1->field_23
    //     0x8652d0: ldur            w3, [x1, #0x23]
    // 0x8652d4: DecompressPointer r3
    //     0x8652d4: add             x3, x3, HEAP, lsl #32
    // 0x8652d8: LoadField: r4 = r2->field_4f
    //     0x8652d8: ldur            w4, [x2, #0x4f]
    // 0x8652dc: DecompressPointer r4
    //     0x8652dc: add             x4, x4, HEAP, lsl #32
    // 0x8652e0: cmp             w4, NULL
    // 0x8652e4: b.eq            #0x8652ec
    // 0x8652e8: tbnz            w4, #4, #0x8652fc
    // 0x8652ec: LoadField: r2 = r1->field_1f
    //     0x8652ec: ldur            w2, [x1, #0x1f]
    // 0x8652f0: DecompressPointer r2
    //     0x8652f0: add             x2, x2, HEAP, lsl #32
    // 0x8652f4: LoadField: d0 = r2->field_1f
    //     0x8652f4: ldur            d0, [x2, #0x1f]
    // 0x8652f8: b               #0x865300
    // 0x8652fc: d0 = 0.000000
    //     0x8652fc: eor             v0.16b, v0.16b, v0.16b
    // 0x865300: ldur            x2, [fp, #-8]
    // 0x865304: r4 = inline_Allocate_Double()
    //     0x865304: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x865308: add             x4, x4, #0x10
    //     0x86530c: cmp             x5, x4
    //     0x865310: b.ls            #0x865594
    //     0x865314: str             x4, [THR, #0x60]  ; THR::top
    //     0x865318: sub             x4, x4, #0xf
    //     0x86531c: mov             x5, #0xd108
    //     0x865320: movk            x5, #3, lsl #16
    //     0x865324: stur            x5, [x4, #-1]
    // 0x865328: StoreField: r4->field_7 = d0
    //     0x865328: stur            d0, [x4, #7]
    // 0x86532c: stp             x4, x3, [SP, #-0x10]!
    // 0x865330: r4 = const [0, 0x2, 0x2, 0x1, bottom, 0x1, null]
    //     0x865330: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] List(7) [0, 0x2, 0x2, 0x1, "bottom", 0x1, Null]
    //     0x865334: ldr             x4, [x4, #0xbd8]
    // 0x865338: r0 = copyWith()
    //     0x865338: bl              #0x51a23c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::copyWith
    // 0x86533c: add             SP, SP, #0x10
    // 0x865340: mov             x1, x0
    // 0x865344: ldur            x2, [fp, #-8]
    // 0x865348: stur            x1, [fp, #-0x28]
    // 0x86534c: StoreField: r2->field_27 = r0
    //     0x86534c: stur            w0, [x2, #0x27]
    //     0x865350: ldurb           w16, [x2, #-1]
    //     0x865354: ldurb           w17, [x0, #-1]
    //     0x865358: and             x16, x17, x16, lsr #2
    //     0x86535c: tst             x16, HEAP, lsr #32
    //     0x865360: b.eq            #0x865368
    //     0x865364: bl              #0xd6828c
    // 0x865368: ldur            x0, [fp, #-0x10]
    // 0x86536c: LoadField: r3 = r0->field_27
    //     0x86536c: ldur            w3, [x0, #0x27]
    // 0x865370: DecompressPointer r3
    //     0x865370: add             x3, x3, HEAP, lsl #32
    // 0x865374: stur            x3, [fp, #-0x20]
    // 0x865378: ldr             x16, [fp, #0x18]
    // 0x86537c: SaveReg r16
    //     0x86537c: str             x16, [SP, #-8]!
    // 0x865380: r0 = _resizeToAvoidBottomInset()
    //     0x865380: bl              #0x8655f8  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_resizeToAvoidBottomInset
    // 0x865384: add             SP, SP, #8
    // 0x865388: tbnz            w0, #4, #0x8653b0
    // 0x86538c: ldur            x0, [fp, #-0x10]
    // 0x865390: d0 = 0.000000
    //     0x865390: eor             v0.16b, v0.16b, v0.16b
    // 0x865394: LoadField: r1 = r0->field_1f
    //     0x865394: ldur            w1, [x0, #0x1f]
    // 0x865398: DecompressPointer r1
    //     0x865398: add             x1, x1, HEAP, lsl #32
    // 0x86539c: LoadField: d1 = r1->field_1f
    //     0x86539c: ldur            d1, [x1, #0x1f]
    // 0x8653a0: fcmp            d1, d0
    // 0x8653a4: b.eq            #0x8653b4
    // 0x8653a8: r1 = 0.000000
    //     0x8653a8: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x8653ac: b               #0x8653b8
    // 0x8653b0: d0 = 0.000000
    //     0x8653b0: eor             v0.16b, v0.16b, v0.16b
    // 0x8653b4: r1 = Null
    //     0x8653b4: mov             x1, NULL
    // 0x8653b8: ldur            x2, [fp, #-8]
    // 0x8653bc: ldur            x0, [fp, #-0x28]
    // 0x8653c0: ldur            x16, [fp, #-0x20]
    // 0x8653c4: stp             x1, x16, [SP, #-0x10]!
    // 0x8653c8: r4 = const [0, 0x2, 0x2, 0x1, bottom, 0x1, null]
    //     0x8653c8: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] List(7) [0, 0x2, 0x2, 0x1, "bottom", 0x1, Null]
    //     0x8653cc: ldr             x4, [x4, #0xbd8]
    // 0x8653d0: r0 = copyWith()
    //     0x8653d0: bl              #0x51a23c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::copyWith
    // 0x8653d4: add             SP, SP, #0x10
    // 0x8653d8: ldur            x2, [fp, #-8]
    // 0x8653dc: StoreField: r2->field_2b = r0
    //     0x8653dc: stur            w0, [x2, #0x2b]
    //     0x8653e0: ldurb           w16, [x2, #-1]
    //     0x8653e4: ldurb           w17, [x0, #-1]
    //     0x8653e8: and             x16, x17, x16, lsr #2
    //     0x8653ec: tst             x16, HEAP, lsr #32
    //     0x8653f0: b.eq            #0x8653f8
    //     0x8653f4: bl              #0xd6828c
    // 0x8653f8: ldur            x0, [fp, #-0x28]
    // 0x8653fc: LoadField: d0 = r0->field_1f
    //     0x8653fc: ldur            d0, [x0, #0x1f]
    // 0x865400: d1 = 0.000000
    //     0x865400: eor             v1.16b, v1.16b, v1.16b
    // 0x865404: fcmp            d0, d1
    // 0x865408: b.vs            #0x865428
    // 0x86540c: b.gt            #0x865428
    // 0x865410: ldr             x0, [fp, #0x18]
    // 0x865414: LoadField: r1 = r0->field_b
    //     0x865414: ldur            w1, [x0, #0xb]
    // 0x865418: DecompressPointer r1
    //     0x865418: add             x1, x1, HEAP, lsl #32
    // 0x86541c: cmp             w1, NULL
    // 0x865420: b.eq            #0x8655b8
    // 0x865424: b               #0x86542c
    // 0x865428: ldr             x0, [fp, #0x18]
    // 0x86542c: r3 = false
    //     0x86542c: add             x3, NULL, #0x30  ; false
    // 0x865430: StoreField: r2->field_2f = r3
    //     0x865430: stur            w3, [x2, #0x2f]
    // 0x865434: LoadField: r1 = r0->field_b
    //     0x865434: ldur            w1, [x0, #0xb]
    // 0x865438: DecompressPointer r1
    //     0x865438: add             x1, x1, HEAP, lsl #32
    // 0x86543c: cmp             w1, NULL
    // 0x865440: b.eq            #0x8655bc
    // 0x865444: LoadField: r4 = r1->field_43
    //     0x865444: ldur            w4, [x1, #0x43]
    // 0x865448: DecompressPointer r4
    //     0x865448: add             x4, x4, HEAP, lsl #32
    // 0x86544c: cmp             w4, NULL
    // 0x865450: b.ne            #0x865460
    // 0x865454: ldur            x1, [fp, #-0x18]
    // 0x865458: LoadField: r4 = r1->field_6f
    //     0x865458: ldur            w4, [x1, #0x6f]
    // 0x86545c: DecompressPointer r4
    //     0x86545c: add             x4, x4, HEAP, lsl #32
    // 0x865460: stur            x4, [fp, #-0x18]
    // 0x865464: LoadField: r5 = r0->field_5f
    //     0x865464: ldur            w5, [x0, #0x5f]
    // 0x865468: DecompressPointer r5
    //     0x865468: add             x5, x5, HEAP, lsl #32
    // 0x86546c: stur            x5, [fp, #-0x10]
    // 0x865470: r1 = Function '<anonymous closure>':.
    //     0x865470: add             x1, PP, #0x21, lsl #12  ; [pp+0x21e08] AnonymousClosure: (0x86620c), in [package:flutter/src/material/scaffold.dart] ScaffoldState::build (0x8648a0)
    //     0x865474: ldr             x1, [x1, #0xe08]
    // 0x865478: r0 = AllocateClosure()
    //     0x865478: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86547c: stur            x0, [fp, #-8]
    // 0x865480: r0 = AnimatedBuilder()
    //     0x865480: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x865484: mov             x1, x0
    // 0x865488: ldur            x0, [fp, #-8]
    // 0x86548c: stur            x1, [fp, #-0x20]
    // 0x865490: StoreField: r1->field_f = r0
    //     0x865490: stur            w0, [x1, #0xf]
    // 0x865494: ldur            x0, [fp, #-0x10]
    // 0x865498: StoreField: r1->field_b = r0
    //     0x865498: stur            w0, [x1, #0xb]
    // 0x86549c: r0 = Material()
    //     0x86549c: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x8654a0: mov             x1, x0
    // 0x8654a4: r0 = Instance_MaterialType
    //     0x8654a4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe6f8] Obj!MaterialType@b65531
    //     0x8654a8: ldr             x0, [x0, #0x6f8]
    // 0x8654ac: stur            x1, [fp, #-8]
    // 0x8654b0: StoreField: r1->field_f = r0
    //     0x8654b0: stur            w0, [x1, #0xf]
    // 0x8654b4: d0 = 0.000000
    //     0x8654b4: eor             v0.16b, v0.16b, v0.16b
    // 0x8654b8: StoreField: r1->field_13 = d0
    //     0x8654b8: stur            d0, [x1, #0x13]
    // 0x8654bc: ldur            x0, [fp, #-0x18]
    // 0x8654c0: StoreField: r1->field_1b = r0
    //     0x8654c0: stur            w0, [x1, #0x1b]
    // 0x8654c4: r0 = true
    //     0x8654c4: add             x0, NULL, #0x20  ; true
    // 0x8654c8: StoreField: r1->field_2f = r0
    //     0x8654c8: stur            w0, [x1, #0x2f]
    // 0x8654cc: r0 = Instance_Clip
    //     0x8654cc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x8654d0: ldr             x0, [x0, #0xb38]
    // 0x8654d4: StoreField: r1->field_33 = r0
    //     0x8654d4: stur            w0, [x1, #0x33]
    // 0x8654d8: r0 = Instance_Duration
    //     0x8654d8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x8654dc: ldr             x0, [x0, #0x9e0]
    // 0x8654e0: StoreField: r1->field_37 = r0
    //     0x8654e0: stur            w0, [x1, #0x37]
    // 0x8654e4: ldur            x0, [fp, #-0x20]
    // 0x8654e8: StoreField: r1->field_b = r0
    //     0x8654e8: stur            w0, [x1, #0xb]
    // 0x8654ec: r0 = ScrollNotificationObserver()
    //     0x8654ec: bl              #0x8655cc  ; AllocateScrollNotificationObserverStub -> ScrollNotificationObserver (size=0x10)
    // 0x8654f0: mov             x1, x0
    // 0x8654f4: ldur            x0, [fp, #-8]
    // 0x8654f8: stur            x1, [fp, #-0x10]
    // 0x8654fc: StoreField: r1->field_b = r0
    //     0x8654fc: stur            w0, [x1, #0xb]
    // 0x865500: r0 = _ScaffoldScope()
    //     0x865500: bl              #0x8655c0  ; Allocate_ScaffoldScopeStub -> _ScaffoldScope (size=0x14)
    // 0x865504: r1 = false
    //     0x865504: add             x1, NULL, #0x30  ; false
    // 0x865508: StoreField: r0->field_f = r1
    //     0x865508: stur            w1, [x0, #0xf]
    // 0x86550c: ldur            x1, [fp, #-0x10]
    // 0x865510: StoreField: r0->field_b = r1
    //     0x865510: stur            w1, [x0, #0xb]
    // 0x865514: LeaveFrame
    //     0x865514: mov             SP, fp
    //     0x865518: ldp             fp, lr, [SP], #0x10
    // 0x86551c: ret
    //     0x86551c: ret             
    // 0x865520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x865520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x865524: b               #0x8648b8
    // 0x865528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x865528: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86552c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86552c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x865530: SaveReg d2
    //     0x865530: str             q2, [SP, #-0x10]!
    // 0x865534: r0 = AllocateDouble()
    //     0x865534: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x865538: RestoreReg d2
    //     0x865538: ldr             q2, [SP], #0x10
    // 0x86553c: b               #0x864b80
    // 0x865540: r0 = NullCastErrorSharedWithFPURegs()
    //     0x865540: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x865544: r0 = NullCastErrorSharedWithFPURegs()
    //     0x865544: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x865548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x865548: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86554c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86554c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x865550: r0 = NullCastErrorSharedWithFPURegs()
    //     0x865550: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x865554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x865554: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x865558: r9 = _floatingActionButtonMoveController
    //     0x865558: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e10] Field <ScaffoldState._floatingActionButtonMoveController@801420462>: late (offset: 0x60)
    //     0x86555c: ldr             x9, [x9, #0xe10]
    // 0x865560: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x865560: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x865564: r9 = _floatingActionButtonAnimator
    //     0x865564: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e18] Field <ScaffoldState._floatingActionButtonAnimator@801420462>: late (offset: 0x64)
    //     0x865568: ldr             x9, [x9, #0xe18]
    // 0x86556c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86556c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x865570: r9 = _geometryNotifier
    //     0x865570: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e20] Field <ScaffoldState._geometryNotifier@801420462>: late (offset: 0x74)
    //     0x865574: ldr             x9, [x9, #0xe20]
    // 0x865578: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x865578: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x86557c: r9 = _floatingActionButtonVisibilityController
    //     0x86557c: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e28] Field <ScaffoldState._floatingActionButtonVisibilityController@801420462>: late (offset: 0x70)
    //     0x865580: ldr             x9, [x9, #0xe28]
    // 0x865584: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x865584: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x865588: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x865588: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86558c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86558c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x865590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x865590: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x865594: SaveReg d0
    //     0x865594: str             q0, [SP, #-0x10]!
    // 0x865598: stp             x2, x3, [SP, #-0x10]!
    // 0x86559c: stp             x0, x1, [SP, #-0x10]!
    // 0x8655a0: r0 = AllocateDouble()
    //     0x8655a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8655a4: mov             x4, x0
    // 0x8655a8: ldp             x0, x1, [SP], #0x10
    // 0x8655ac: ldp             x2, x3, [SP], #0x10
    // 0x8655b0: RestoreReg d0
    //     0x8655b0: ldr             q0, [SP], #0x10
    // 0x8655b4: b               #0x865328
    // 0x8655b8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8655b8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8655bc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8655bc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ _resizeToAvoidBottomInset(/* No info */) {
    // ** addr: 0x8655f8, size: 0x48
    // 0x8655f8: EnterFrame
    //     0x8655f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8655fc: mov             fp, SP
    // 0x865600: ldr             x1, [fp, #0x10]
    // 0x865604: LoadField: r2 = r1->field_b
    //     0x865604: ldur            w2, [x1, #0xb]
    // 0x865608: DecompressPointer r2
    //     0x865608: add             x2, x2, HEAP, lsl #32
    // 0x86560c: cmp             w2, NULL
    // 0x865610: b.eq            #0x86563c
    // 0x865614: LoadField: r1 = r2->field_4f
    //     0x865614: ldur            w1, [x2, #0x4f]
    // 0x865618: DecompressPointer r1
    //     0x865618: add             x1, x1, HEAP, lsl #32
    // 0x86561c: cmp             w1, NULL
    // 0x865620: b.ne            #0x86562c
    // 0x865624: r0 = true
    //     0x865624: add             x0, NULL, #0x20  ; true
    // 0x865628: b               #0x865630
    // 0x86562c: mov             x0, x1
    // 0x865630: LeaveFrame
    //     0x865630: mov             SP, fp
    //     0x865634: ldp             fp, lr, [SP], #0x10
    // 0x865638: ret
    //     0x865638: ret             
    // 0x86563c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86563c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _addIfNonNull(/* No info */) {
    // ** addr: 0x86596c, size: 0x350
    // 0x86596c: EnterFrame
    //     0x86596c: stp             fp, lr, [SP, #-0x10]!
    //     0x865970: mov             fp, SP
    // 0x865974: AllocStack(0x48)
    //     0x865974: sub             SP, SP, #0x48
    // 0x865978: SetupParameters(ScaffoldState<Scaffold> this /* r3 */, dynamic _ /* r4, fp-0x48 */, dynamic _ /* r5, fp-0x40 */, dynamic _ /* r6, fp-0x38 */, dynamic _ /* r7, fp-0x30 */, dynamic _ /* r8, fp-0x28 */, dynamic _ /* r9, fp-0x20 */, dynamic _ /* r10, fp-0x18 */, {dynamic maintainBottomViewPadding = false /* r11, fp-0x10 */, dynamic removeBottomInset = false /* r0, fp-0x8 */})
    //     0x865978: mov             x0, x4
    //     0x86597c: ldur            w1, [x0, #0x13]
    //     0x865980: add             x1, x1, HEAP, lsl #32
    //     0x865984: sub             x2, x1, #0x10
    //     0x865988: add             x3, fp, w2, sxtw #2
    //     0x86598c: ldr             x3, [x3, #0x48]
    //     0x865990: add             x4, fp, w2, sxtw #2
    //     0x865994: ldr             x4, [x4, #0x40]
    //     0x865998: stur            x4, [fp, #-0x48]
    //     0x86599c: add             x5, fp, w2, sxtw #2
    //     0x8659a0: ldr             x5, [x5, #0x38]
    //     0x8659a4: stur            x5, [fp, #-0x40]
    //     0x8659a8: add             x6, fp, w2, sxtw #2
    //     0x8659ac: ldr             x6, [x6, #0x30]
    //     0x8659b0: stur            x6, [fp, #-0x38]
    //     0x8659b4: add             x7, fp, w2, sxtw #2
    //     0x8659b8: ldr             x7, [x7, #0x28]
    //     0x8659bc: stur            x7, [fp, #-0x30]
    //     0x8659c0: add             x8, fp, w2, sxtw #2
    //     0x8659c4: ldr             x8, [x8, #0x20]
    //     0x8659c8: stur            x8, [fp, #-0x28]
    //     0x8659cc: add             x9, fp, w2, sxtw #2
    //     0x8659d0: ldr             x9, [x9, #0x18]
    //     0x8659d4: stur            x9, [fp, #-0x20]
    //     0x8659d8: add             x10, fp, w2, sxtw #2
    //     0x8659dc: ldr             x10, [x10, #0x10]
    //     0x8659e0: stur            x10, [fp, #-0x18]
    //     0x8659e4: ldur            w2, [x0, #0x1f]
    //     0x8659e8: add             x2, x2, HEAP, lsl #32
    //     0x8659ec: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e90] "maintainBottomViewPadding"
    //     0x8659f0: ldr             x16, [x16, #0xe90]
    //     0x8659f4: cmp             w2, w16
    //     0x8659f8: b.ne            #0x865a1c
    //     0x8659fc: ldur            w2, [x0, #0x23]
    //     0x865a00: add             x2, x2, HEAP, lsl #32
    //     0x865a04: sub             w11, w1, w2
    //     0x865a08: add             x2, fp, w11, sxtw #2
    //     0x865a0c: ldr             x2, [x2, #8]
    //     0x865a10: mov             x11, x2
    //     0x865a14: mov             x2, #1
    //     0x865a18: b               #0x865a24
    //     0x865a1c: add             x11, NULL, #0x30  ; false
    //     0x865a20: mov             x2, #0
    //     0x865a24: stur            x11, [fp, #-0x10]
    //     0x865a28: lsl             x12, x2, #1
    //     0x865a2c: lsl             w2, w12, #1
    //     0x865a30: add             w12, w2, #8
    //     0x865a34: add             x16, x0, w12, sxtw #1
    //     0x865a38: ldur            w13, [x16, #0xf]
    //     0x865a3c: add             x13, x13, HEAP, lsl #32
    //     0x865a40: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e98] "removeBottomInset"
    //     0x865a44: ldr             x16, [x16, #0xe98]
    //     0x865a48: cmp             w13, w16
    //     0x865a4c: b.ne            #0x865a74
    //     0x865a50: add             w12, w2, #0xa
    //     0x865a54: add             x16, x0, w12, sxtw #1
    //     0x865a58: ldur            w2, [x16, #0xf]
    //     0x865a5c: add             x2, x2, HEAP, lsl #32
    //     0x865a60: sub             w0, w1, w2
    //     0x865a64: add             x1, fp, w0, sxtw #2
    //     0x865a68: ldr             x1, [x1, #8]
    //     0x865a6c: mov             x0, x1
    //     0x865a70: b               #0x865a78
    //     0x865a74: add             x0, NULL, #0x30  ; false
    //     0x865a78: stur            x0, [fp, #-8]
    // 0x865a7c: CheckStackOverflow
    //     0x865a7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x865a80: cmp             SP, x16
    //     0x865a84: b.ls            #0x865c90
    // 0x865a88: LoadField: r1 = r3->field_f
    //     0x865a88: ldur            w1, [x3, #0xf]
    // 0x865a8c: DecompressPointer r1
    //     0x865a8c: add             x1, x1, HEAP, lsl #32
    // 0x865a90: cmp             w1, NULL
    // 0x865a94: b.eq            #0x865c98
    // 0x865a98: SaveReg r1
    //     0x865a98: str             x1, [SP, #-8]!
    // 0x865a9c: r0 = of()
    //     0x865a9c: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x865aa0: add             SP, SP, #8
    // 0x865aa4: ldur            x16, [fp, #-0x30]
    // 0x865aa8: stp             x16, x0, [SP, #-0x10]!
    // 0x865aac: ldur            x16, [fp, #-0x28]
    // 0x865ab0: ldur            lr, [fp, #-0x20]
    // 0x865ab4: stp             lr, x16, [SP, #-0x10]!
    // 0x865ab8: ldur            x16, [fp, #-0x18]
    // 0x865abc: SaveReg r16
    //     0x865abc: str             x16, [SP, #-8]!
    // 0x865ac0: r0 = removePadding()
    //     0x865ac0: bl              #0x8495b8  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::removePadding
    // 0x865ac4: add             SP, SP, #0x28
    // 0x865ac8: mov             x1, x0
    // 0x865acc: ldur            x0, [fp, #-8]
    // 0x865ad0: tbnz            w0, #4, #0x865ae8
    // 0x865ad4: SaveReg r1
    //     0x865ad4: str             x1, [SP, #-8]!
    // 0x865ad8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x865ad8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x865adc: r0 = removeViewInsets()
    //     0x865adc: bl              #0x865ce8  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::removeViewInsets
    // 0x865ae0: add             SP, SP, #8
    // 0x865ae4: mov             x1, x0
    // 0x865ae8: ldur            x0, [fp, #-0x10]
    // 0x865aec: stur            x1, [fp, #-8]
    // 0x865af0: tbnz            w0, #4, #0x865b7c
    // 0x865af4: d0 = 0.000000
    //     0x865af4: eor             v0.16b, v0.16b, v0.16b
    // 0x865af8: LoadField: r0 = r1->field_1f
    //     0x865af8: ldur            w0, [x1, #0x1f]
    // 0x865afc: DecompressPointer r0
    //     0x865afc: add             x0, x0, HEAP, lsl #32
    // 0x865b00: LoadField: d1 = r0->field_1f
    //     0x865b00: ldur            d1, [x0, #0x1f]
    // 0x865b04: fcmp            d1, d0
    // 0x865b08: b.eq            #0x865b7c
    // 0x865b0c: LoadField: r0 = r1->field_23
    //     0x865b0c: ldur            w0, [x1, #0x23]
    // 0x865b10: DecompressPointer r0
    //     0x865b10: add             x0, x0, HEAP, lsl #32
    // 0x865b14: LoadField: r2 = r1->field_27
    //     0x865b14: ldur            w2, [x1, #0x27]
    // 0x865b18: DecompressPointer r2
    //     0x865b18: add             x2, x2, HEAP, lsl #32
    // 0x865b1c: LoadField: d0 = r2->field_1f
    //     0x865b1c: ldur            d0, [x2, #0x1f]
    // 0x865b20: r2 = inline_Allocate_Double()
    //     0x865b20: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x865b24: add             x2, x2, #0x10
    //     0x865b28: cmp             x3, x2
    //     0x865b2c: b.ls            #0x865c9c
    //     0x865b30: str             x2, [THR, #0x60]  ; THR::top
    //     0x865b34: sub             x2, x2, #0xf
    //     0x865b38: mov             x3, #0xd108
    //     0x865b3c: movk            x3, #3, lsl #16
    //     0x865b40: stur            x3, [x2, #-1]
    // 0x865b44: StoreField: r2->field_7 = d0
    //     0x865b44: stur            d0, [x2, #7]
    // 0x865b48: stp             x2, x0, [SP, #-0x10]!
    // 0x865b4c: r4 = const [0, 0x2, 0x2, 0x1, bottom, 0x1, null]
    //     0x865b4c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] List(7) [0, 0x2, 0x2, 0x1, "bottom", 0x1, Null]
    //     0x865b50: ldr             x4, [x4, #0xbd8]
    // 0x865b54: r0 = copyWith()
    //     0x865b54: bl              #0x51a23c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::copyWith
    // 0x865b58: add             SP, SP, #0x10
    // 0x865b5c: ldur            x16, [fp, #-8]
    // 0x865b60: stp             x0, x16, [SP, #-0x10]!
    // 0x865b64: r4 = const [0, 0x2, 0x2, 0x1, padding, 0x1, null]
    //     0x865b64: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cac0] List(7) [0, 0x2, 0x2, 0x1, "padding", 0x1, Null]
    //     0x865b68: ldr             x4, [x4, #0xac0]
    // 0x865b6c: r0 = copyWith()
    //     0x865b6c: bl              #0x848050  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::copyWith
    // 0x865b70: add             SP, SP, #0x10
    // 0x865b74: mov             x1, x0
    // 0x865b78: b               #0x865b80
    // 0x865b7c: ldur            x1, [fp, #-8]
    // 0x865b80: ldur            x0, [fp, #-0x40]
    // 0x865b84: stur            x1, [fp, #-8]
    // 0x865b88: cmp             w0, NULL
    // 0x865b8c: b.eq            #0x865c80
    // 0x865b90: ldur            x2, [fp, #-0x48]
    // 0x865b94: ldur            x3, [fp, #-0x38]
    // 0x865b98: r0 = MediaQuery()
    //     0x865b98: bl              #0x848044  ; AllocateMediaQueryStub -> MediaQuery (size=0x14)
    // 0x865b9c: mov             x2, x0
    // 0x865ba0: ldur            x0, [fp, #-8]
    // 0x865ba4: stur            x2, [fp, #-0x10]
    // 0x865ba8: StoreField: r2->field_f = r0
    //     0x865ba8: stur            w0, [x2, #0xf]
    // 0x865bac: ldur            x0, [fp, #-0x40]
    // 0x865bb0: StoreField: r2->field_b = r0
    //     0x865bb0: stur            w0, [x2, #0xb]
    // 0x865bb4: r1 = <MultiChildLayoutParentData<RenderBox>>
    //     0x865bb4: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ea0] TypeArguments: <MultiChildLayoutParentData<RenderBox>>
    //     0x865bb8: ldr             x1, [x1, #0xea0]
    // 0x865bbc: r0 = LayoutId()
    //     0x865bbc: bl              #0x865cdc  ; AllocateLayoutIdStub -> LayoutId (size=0x18)
    // 0x865bc0: mov             x2, x0
    // 0x865bc4: ldur            x0, [fp, #-0x38]
    // 0x865bc8: stur            x2, [fp, #-8]
    // 0x865bcc: StoreField: r2->field_13 = r0
    //     0x865bcc: stur            w0, [x2, #0x13]
    // 0x865bd0: r1 = <Object>
    //     0x865bd0: ldr             x1, [PP, #0x1d8]  ; [pp+0x1d8] TypeArguments: <Object>
    // 0x865bd4: r0 = ValueKey()
    //     0x865bd4: bl              #0x7a155c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0x865bd8: mov             x1, x0
    // 0x865bdc: ldur            x0, [fp, #-0x38]
    // 0x865be0: StoreField: r1->field_b = r0
    //     0x865be0: stur            w0, [x1, #0xb]
    // 0x865be4: ldur            x2, [fp, #-0x10]
    // 0x865be8: ldur            x0, [fp, #-8]
    // 0x865bec: StoreField: r0->field_b = r2
    //     0x865bec: stur            w2, [x0, #0xb]
    // 0x865bf0: StoreField: r0->field_7 = r1
    //     0x865bf0: stur            w1, [x0, #7]
    // 0x865bf4: ldur            x1, [fp, #-0x48]
    // 0x865bf8: LoadField: r2 = r1->field_b
    //     0x865bf8: ldur            w2, [x1, #0xb]
    // 0x865bfc: DecompressPointer r2
    //     0x865bfc: add             x2, x2, HEAP, lsl #32
    // 0x865c00: stur            x2, [fp, #-0x10]
    // 0x865c04: LoadField: r3 = r1->field_f
    //     0x865c04: ldur            w3, [x1, #0xf]
    // 0x865c08: DecompressPointer r3
    //     0x865c08: add             x3, x3, HEAP, lsl #32
    // 0x865c0c: LoadField: r4 = r3->field_b
    //     0x865c0c: ldur            w4, [x3, #0xb]
    // 0x865c10: DecompressPointer r4
    //     0x865c10: add             x4, x4, HEAP, lsl #32
    // 0x865c14: cmp             w2, w4
    // 0x865c18: b.ne            #0x865c28
    // 0x865c1c: SaveReg r1
    //     0x865c1c: str             x1, [SP, #-8]!
    // 0x865c20: r0 = _growToNextCapacity()
    //     0x865c20: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x865c24: add             SP, SP, #8
    // 0x865c28: ldur            x2, [fp, #-0x48]
    // 0x865c2c: ldur            x3, [fp, #-0x10]
    // 0x865c30: r4 = LoadInt32Instr(r3)
    //     0x865c30: sbfx            x4, x3, #1, #0x1f
    // 0x865c34: add             x0, x4, #1
    // 0x865c38: lsl             x3, x0, #1
    // 0x865c3c: StoreField: r2->field_b = r3
    //     0x865c3c: stur            w3, [x2, #0xb]
    // 0x865c40: mov             x1, x4
    // 0x865c44: cmp             x1, x0
    // 0x865c48: b.hs            #0x865cb8
    // 0x865c4c: LoadField: r1 = r2->field_f
    //     0x865c4c: ldur            w1, [x2, #0xf]
    // 0x865c50: DecompressPointer r1
    //     0x865c50: add             x1, x1, HEAP, lsl #32
    // 0x865c54: ldur            x0, [fp, #-8]
    // 0x865c58: ArrayStore: r1[r4] = r0  ; List_4
    //     0x865c58: add             x25, x1, x4, lsl #2
    //     0x865c5c: add             x25, x25, #0xf
    //     0x865c60: str             w0, [x25]
    //     0x865c64: tbz             w0, #0, #0x865c80
    //     0x865c68: ldurb           w16, [x1, #-1]
    //     0x865c6c: ldurb           w17, [x0, #-1]
    //     0x865c70: and             x16, x17, x16, lsr #2
    //     0x865c74: tst             x16, HEAP, lsr #32
    //     0x865c78: b.eq            #0x865c80
    //     0x865c7c: bl              #0xd67e5c
    // 0x865c80: r0 = Null
    //     0x865c80: mov             x0, NULL
    // 0x865c84: LeaveFrame
    //     0x865c84: mov             SP, fp
    //     0x865c88: ldp             fp, lr, [SP], #0x10
    // 0x865c8c: ret
    //     0x865c8c: ret             
    // 0x865c90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x865c90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x865c94: b               #0x865a88
    // 0x865c98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x865c98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x865c9c: SaveReg d0
    //     0x865c9c: str             q0, [SP, #-0x10]!
    // 0x865ca0: stp             x0, x1, [SP, #-0x10]!
    // 0x865ca4: r0 = AllocateDouble()
    //     0x865ca4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x865ca8: mov             x2, x0
    // 0x865cac: ldp             x0, x1, [SP], #0x10
    // 0x865cb0: RestoreReg d0
    //     0x865cb0: ldr             q0, [SP], #0x10
    // 0x865cb4: b               #0x865b44
    // 0x865cb8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x865cb8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] Actions <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x86620c, size: 0x2fc
    // 0x86620c: EnterFrame
    //     0x86620c: stp             fp, lr, [SP, #-0x10]!
    //     0x866210: mov             fp, SP
    // 0x866214: AllocStack(0x68)
    //     0x866214: sub             SP, SP, #0x68
    // 0x866218: SetupParameters()
    //     0x866218: ldr             x0, [fp, #0x20]
    //     0x86621c: ldur            w3, [x0, #0x17]
    //     0x866220: add             x3, x3, HEAP, lsl #32
    //     0x866224: stur            x3, [fp, #-8]
    // 0x866228: CheckStackOverflow
    //     0x866228: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86622c: cmp             SP, x16
    //     0x866230: b.ls            #0x8664c4
    // 0x866234: r1 = Null
    //     0x866234: mov             x1, NULL
    // 0x866238: r2 = 4
    //     0x866238: mov             x2, #4
    // 0x86623c: r0 = AllocateArray()
    //     0x86623c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x866240: stur            x0, [fp, #-0x10]
    // 0x866244: r17 = DismissIntent
    //     0x866244: add             x17, PP, #0x21, lsl #12  ; [pp+0x21e30] Type: DismissIntent
    //     0x866248: ldr             x17, [x17, #0xe30]
    // 0x86624c: StoreField: r0->field_f = r17
    //     0x86624c: stur            w17, [x0, #0xf]
    // 0x866250: r1 = <DismissIntent>
    //     0x866250: add             x1, PP, #0x21, lsl #12  ; [pp+0x21e38] TypeArguments: <DismissIntent>
    //     0x866254: ldr             x1, [x1, #0xe38]
    // 0x866258: r0 = _DismissDrawerAction()
    //     0x866258: bl              #0x86663c  ; Allocate_DismissDrawerActionStub -> _DismissDrawerAction (size=0x18)
    // 0x86625c: mov             x2, x0
    // 0x866260: ldr             x0, [fp, #0x18]
    // 0x866264: stur            x2, [fp, #-0x18]
    // 0x866268: StoreField: r2->field_13 = r0
    //     0x866268: stur            w0, [x2, #0x13]
    // 0x86626c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0x86626c: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x866270: ldr             x1, [x1, #0xcc0]
    // 0x866274: r0 = ObserverList()
    //     0x866274: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x866278: mov             x1, x0
    // 0x86627c: r0 = false
    //     0x86627c: add             x0, NULL, #0x30  ; false
    // 0x866280: stur            x1, [fp, #-0x20]
    // 0x866284: StoreField: r1->field_f = r0
    //     0x866284: stur            w0, [x1, #0xf]
    // 0x866288: r0 = Sentinel
    //     0x866288: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86628c: StoreField: r1->field_13 = r0
    //     0x86628c: stur            w0, [x1, #0x13]
    // 0x866290: r16 = <(dynamic this, Action<Intent>) => void?>
    //     0x866290: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x866294: ldr             x16, [x16, #0xcc0]
    // 0x866298: stp             xzr, x16, [SP, #-0x10]!
    // 0x86629c: r0 = _GrowableList()
    //     0x86629c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8662a0: add             SP, SP, #0x10
    // 0x8662a4: ldur            x1, [fp, #-0x20]
    // 0x8662a8: StoreField: r1->field_b = r0
    //     0x8662a8: stur            w0, [x1, #0xb]
    //     0x8662ac: ldurb           w16, [x1, #-1]
    //     0x8662b0: ldurb           w17, [x0, #-1]
    //     0x8662b4: and             x16, x17, x16, lsr #2
    //     0x8662b8: tst             x16, HEAP, lsr #32
    //     0x8662bc: b.eq            #0x8662c4
    //     0x8662c0: bl              #0xd6826c
    // 0x8662c4: mov             x0, x1
    // 0x8662c8: ldur            x1, [fp, #-0x18]
    // 0x8662cc: StoreField: r1->field_b = r0
    //     0x8662cc: stur            w0, [x1, #0xb]
    //     0x8662d0: ldurb           w16, [x1, #-1]
    //     0x8662d4: ldurb           w17, [x0, #-1]
    //     0x8662d8: and             x16, x17, x16, lsr #2
    //     0x8662dc: tst             x16, HEAP, lsr #32
    //     0x8662e0: b.eq            #0x8662e8
    //     0x8662e4: bl              #0xd6826c
    // 0x8662e8: mov             x0, x1
    // 0x8662ec: ldur            x1, [fp, #-0x10]
    // 0x8662f0: ArrayStore: r1[1] = r0  ; List_4
    //     0x8662f0: add             x25, x1, #0x13
    //     0x8662f4: str             w0, [x25]
    //     0x8662f8: tbz             w0, #0, #0x866314
    //     0x8662fc: ldurb           w16, [x1, #-1]
    //     0x866300: ldurb           w17, [x0, #-1]
    //     0x866304: and             x16, x17, x16, lsr #2
    //     0x866308: tst             x16, HEAP, lsr #32
    //     0x86630c: b.eq            #0x866314
    //     0x866310: bl              #0xd67e5c
    // 0x866314: r16 = <Type, Action<Intent>>
    //     0x866314: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e40] TypeArguments: <Type, Action<Intent>>
    //     0x866318: ldr             x16, [x16, #0xe40]
    // 0x86631c: ldur            lr, [fp, #-0x10]
    // 0x866320: stp             lr, x16, [SP, #-0x10]!
    // 0x866324: r0 = Map._fromLiteral()
    //     0x866324: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x866328: add             SP, SP, #0x10
    // 0x86632c: mov             x1, x0
    // 0x866330: ldur            x0, [fp, #-8]
    // 0x866334: stur            x1, [fp, #-0x58]
    // 0x866338: LoadField: r2 = r0->field_f
    //     0x866338: ldur            w2, [x0, #0xf]
    // 0x86633c: DecompressPointer r2
    //     0x86633c: add             x2, x2, HEAP, lsl #32
    // 0x866340: LoadField: r3 = r2->field_b
    //     0x866340: ldur            w3, [x2, #0xb]
    // 0x866344: DecompressPointer r3
    //     0x866344: add             x3, x3, HEAP, lsl #32
    // 0x866348: cmp             w3, NULL
    // 0x86634c: b.eq            #0x8664cc
    // 0x866350: LoadField: r3 = r2->field_6b
    //     0x866350: ldur            w3, [x2, #0x6b]
    // 0x866354: DecompressPointer r3
    //     0x866354: add             x3, x3, HEAP, lsl #32
    // 0x866358: cmp             w3, NULL
    // 0x86635c: b.eq            #0x8664d0
    // 0x866360: LoadField: r3 = r2->field_5f
    //     0x866360: ldur            w3, [x2, #0x5f]
    // 0x866364: DecompressPointer r3
    //     0x866364: add             x3, x3, HEAP, lsl #32
    // 0x866368: r16 = Sentinel
    //     0x866368: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86636c: cmp             w3, w16
    // 0x866370: b.eq            #0x8664d4
    // 0x866374: LoadField: r4 = r3->field_37
    //     0x866374: ldur            w4, [x3, #0x37]
    // 0x866378: DecompressPointer r4
    //     0x866378: add             x4, x4, HEAP, lsl #32
    // 0x86637c: r16 = Sentinel
    //     0x86637c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x866380: cmp             w4, w16
    // 0x866384: b.eq            #0x8664e0
    // 0x866388: LoadField: r3 = r2->field_63
    //     0x866388: ldur            w3, [x2, #0x63]
    // 0x86638c: DecompressPointer r3
    //     0x86638c: add             x3, x3, HEAP, lsl #32
    // 0x866390: r16 = Sentinel
    //     0x866390: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x866394: cmp             w3, w16
    // 0x866398: b.eq            #0x8664ec
    // 0x86639c: LoadField: r3 = r2->field_73
    //     0x86639c: ldur            w3, [x2, #0x73]
    // 0x8663a0: DecompressPointer r3
    //     0x8663a0: add             x3, x3, HEAP, lsl #32
    // 0x8663a4: r16 = Sentinel
    //     0x8663a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8663a8: cmp             w3, w16
    // 0x8663ac: b.eq            #0x8664f8
    // 0x8663b0: stur            x3, [fp, #-0x50]
    // 0x8663b4: LoadField: r5 = r2->field_67
    //     0x8663b4: ldur            w5, [x2, #0x67]
    // 0x8663b8: DecompressPointer r5
    //     0x8663b8: add             x5, x5, HEAP, lsl #32
    // 0x8663bc: stur            x5, [fp, #-0x48]
    // 0x8663c0: cmp             w5, NULL
    // 0x8663c4: b.eq            #0x866504
    // 0x8663c8: LoadField: r2 = r0->field_1b
    //     0x8663c8: ldur            w2, [x0, #0x1b]
    // 0x8663cc: DecompressPointer r2
    //     0x8663cc: add             x2, x2, HEAP, lsl #32
    // 0x8663d0: stur            x2, [fp, #-0x40]
    // 0x8663d4: LoadField: r6 = r0->field_23
    //     0x8663d4: ldur            w6, [x0, #0x23]
    // 0x8663d8: DecompressPointer r6
    //     0x8663d8: add             x6, x6, HEAP, lsl #32
    // 0x8663dc: stur            x6, [fp, #-0x38]
    // 0x8663e0: LoadField: r7 = r0->field_1f
    //     0x8663e0: ldur            w7, [x0, #0x1f]
    // 0x8663e4: DecompressPointer r7
    //     0x8663e4: add             x7, x7, HEAP, lsl #32
    // 0x8663e8: stur            x7, [fp, #-0x30]
    // 0x8663ec: LoadField: r8 = r0->field_2f
    //     0x8663ec: ldur            w8, [x0, #0x2f]
    // 0x8663f0: DecompressPointer r8
    //     0x8663f0: add             x8, x8, HEAP, lsl #32
    // 0x8663f4: stur            x8, [fp, #-0x28]
    // 0x8663f8: LoadField: r9 = r0->field_27
    //     0x8663f8: ldur            w9, [x0, #0x27]
    // 0x8663fc: DecompressPointer r9
    //     0x8663fc: add             x9, x9, HEAP, lsl #32
    // 0x866400: stur            x9, [fp, #-0x20]
    // 0x866404: LoadField: r10 = r0->field_2b
    //     0x866404: ldur            w10, [x0, #0x2b]
    // 0x866408: DecompressPointer r10
    //     0x866408: add             x10, x10, HEAP, lsl #32
    // 0x86640c: stur            x10, [fp, #-0x18]
    // 0x866410: LoadField: r11 = r0->field_13
    //     0x866410: ldur            w11, [x0, #0x13]
    // 0x866414: DecompressPointer r11
    //     0x866414: add             x11, x11, HEAP, lsl #32
    // 0x866418: stur            x11, [fp, #-0x10]
    // 0x86641c: LoadField: d0 = r4->field_7
    //     0x86641c: ldur            d0, [x4, #7]
    // 0x866420: stur            d0, [fp, #-0x68]
    // 0x866424: r0 = _ScaffoldLayout()
    //     0x866424: bl              #0x866630  ; Allocate_ScaffoldLayoutStub -> _ScaffoldLayout (size=0x48)
    // 0x866428: stur            x0, [fp, #-0x60]
    // 0x86642c: ldur            x16, [fp, #-0x28]
    // 0x866430: stp             x16, x0, [SP, #-0x10]!
    // 0x866434: ldur            x16, [fp, #-0x38]
    // 0x866438: SaveReg r16
    //     0x866438: str             x16, [SP, #-8]!
    // 0x86643c: ldur            d0, [fp, #-0x68]
    // 0x866440: SaveReg d0
    //     0x866440: str             d0, [SP, #-8]!
    // 0x866444: ldur            x16, [fp, #-0x50]
    // 0x866448: ldur            lr, [fp, #-0x40]
    // 0x86644c: stp             lr, x16, [SP, #-0x10]!
    // 0x866450: ldur            x16, [fp, #-0x20]
    // 0x866454: ldur            lr, [fp, #-0x18]
    // 0x866458: stp             lr, x16, [SP, #-0x10]!
    // 0x86645c: ldur            x16, [fp, #-0x48]
    // 0x866460: ldur            lr, [fp, #-0x30]
    // 0x866464: stp             lr, x16, [SP, #-0x10]!
    // 0x866468: ldur            x16, [fp, #-0x10]
    // 0x86646c: SaveReg r16
    //     0x86646c: str             x16, [SP, #-8]!
    // 0x866470: r0 = _ScaffoldLayout()
    //     0x866470: bl              #0x866514  ; [package:flutter/src/material/scaffold.dart] _ScaffoldLayout::_ScaffoldLayout
    // 0x866474: add             SP, SP, #0x58
    // 0x866478: ldur            x0, [fp, #-8]
    // 0x86647c: LoadField: r1 = r0->field_17
    //     0x86647c: ldur            w1, [x0, #0x17]
    // 0x866480: DecompressPointer r1
    //     0x866480: add             x1, x1, HEAP, lsl #32
    // 0x866484: stur            x1, [fp, #-0x10]
    // 0x866488: r0 = CustomMultiChildLayout()
    //     0x866488: bl              #0x866508  ; AllocateCustomMultiChildLayoutStub -> CustomMultiChildLayout (size=0x14)
    // 0x86648c: mov             x1, x0
    // 0x866490: ldur            x0, [fp, #-0x60]
    // 0x866494: stur            x1, [fp, #-8]
    // 0x866498: StoreField: r1->field_f = r0
    //     0x866498: stur            w0, [x1, #0xf]
    // 0x86649c: ldur            x0, [fp, #-0x10]
    // 0x8664a0: StoreField: r1->field_b = r0
    //     0x8664a0: stur            w0, [x1, #0xb]
    // 0x8664a4: r0 = Actions()
    //     0x8664a4: bl              #0x834684  ; AllocateActionsStub -> Actions (size=0x18)
    // 0x8664a8: ldur            x1, [fp, #-0x58]
    // 0x8664ac: StoreField: r0->field_f = r1
    //     0x8664ac: stur            w1, [x0, #0xf]
    // 0x8664b0: ldur            x1, [fp, #-8]
    // 0x8664b4: StoreField: r0->field_13 = r1
    //     0x8664b4: stur            w1, [x0, #0x13]
    // 0x8664b8: LeaveFrame
    //     0x8664b8: mov             SP, fp
    //     0x8664bc: ldp             fp, lr, [SP], #0x10
    // 0x8664c0: ret
    //     0x8664c0: ret             
    // 0x8664c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8664c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8664c8: b               #0x866234
    // 0x8664cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8664cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8664d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8664d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8664d4: r9 = _floatingActionButtonMoveController
    //     0x8664d4: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e10] Field <ScaffoldState._floatingActionButtonMoveController@801420462>: late (offset: 0x60)
    //     0x8664d8: ldr             x9, [x9, #0xe10]
    // 0x8664dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8664dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8664e0: r9 = _value
    //     0x8664e0: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x8664e4: ldr             x9, [x9, #0xbb0]
    // 0x8664e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8664e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8664ec: r9 = _floatingActionButtonAnimator
    //     0x8664ec: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e18] Field <ScaffoldState._floatingActionButtonAnimator@801420462>: late (offset: 0x64)
    //     0x8664f0: ldr             x9, [x9, #0xe18]
    // 0x8664f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8664f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8664f8: r9 = _geometryNotifier
    //     0x8664f8: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e20] Field <ScaffoldState._geometryNotifier@801420462>: late (offset: 0x74)
    //     0x8664fc: ldr             x9, [x9, #0xe20]
    // 0x866500: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x866500: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x866504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x866504: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleStatusBarTap(dynamic) {
    // ** addr: 0x866668, size: 0x48
    // 0x866668: EnterFrame
    //     0x866668: stp             fp, lr, [SP, #-0x10]!
    //     0x86666c: mov             fp, SP
    // 0x866670: ldr             x0, [fp, #0x10]
    // 0x866674: LoadField: r1 = r0->field_17
    //     0x866674: ldur            w1, [x0, #0x17]
    // 0x866678: DecompressPointer r1
    //     0x866678: add             x1, x1, HEAP, lsl #32
    // 0x86667c: CheckStackOverflow
    //     0x86667c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x866680: cmp             SP, x16
    //     0x866684: b.ls            #0x8666a8
    // 0x866688: LoadField: r0 = r1->field_f
    //     0x866688: ldur            w0, [x1, #0xf]
    // 0x86668c: DecompressPointer r0
    //     0x86668c: add             x0, x0, HEAP, lsl #32
    // 0x866690: SaveReg r0
    //     0x866690: str             x0, [SP, #-8]!
    // 0x866694: r0 = _handleStatusBarTap()
    //     0x866694: bl              #0x8666b0  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_handleStatusBarTap
    // 0x866698: add             SP, SP, #8
    // 0x86669c: LeaveFrame
    //     0x86669c: mov             SP, fp
    //     0x8666a0: ldp             fp, lr, [SP], #0x10
    // 0x8666a4: ret
    //     0x8666a4: ret             
    // 0x8666a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8666a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8666ac: b               #0x866688
  }
  _ _handleStatusBarTap(/* No info */) {
    // ** addr: 0x8666b0, size: 0x88
    // 0x8666b0: EnterFrame
    //     0x8666b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8666b4: mov             fp, SP
    // 0x8666b8: CheckStackOverflow
    //     0x8666b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8666bc: cmp             SP, x16
    //     0x8666c0: b.ls            #0x86672c
    // 0x8666c4: ldr             x0, [fp, #0x10]
    // 0x8666c8: LoadField: r1 = r0->field_f
    //     0x8666c8: ldur            w1, [x0, #0xf]
    // 0x8666cc: DecompressPointer r1
    //     0x8666cc: add             x1, x1, HEAP, lsl #32
    // 0x8666d0: cmp             w1, NULL
    // 0x8666d4: b.eq            #0x866734
    // 0x8666d8: SaveReg r1
    //     0x8666d8: str             x1, [SP, #-8]!
    // 0x8666dc: r0 = maybeOf()
    //     0x8666dc: bl              #0x841aac  ; [package:flutter/src/widgets/primary_scroll_controller.dart] PrimaryScrollController::maybeOf
    // 0x8666e0: add             SP, SP, #8
    // 0x8666e4: cmp             w0, NULL
    // 0x8666e8: b.eq            #0x86671c
    // 0x8666ec: LoadField: r1 = r0->field_33
    //     0x8666ec: ldur            w1, [x0, #0x33]
    // 0x8666f0: DecompressPointer r1
    //     0x8666f0: add             x1, x1, HEAP, lsl #32
    // 0x8666f4: LoadField: r2 = r1->field_b
    //     0x8666f4: ldur            w2, [x1, #0xb]
    // 0x8666f8: DecompressPointer r2
    //     0x8666f8: add             x2, x2, HEAP, lsl #32
    // 0x8666fc: cbz             w2, #0x86671c
    // 0x866700: stp             xzr, x0, [SP, #-0x10]!
    // 0x866704: r16 = Instance_Cubic
    //     0x866704: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e50] Obj!Cubic<double>@b4f4c1
    //     0x866708: ldr             x16, [x16, #0xe50]
    // 0x86670c: r30 = Instance_Duration
    //     0x86670c: ldr             lr, [PP, #0x1788]  ; [pp+0x1788] Obj!Duration@b67a21
    // 0x866710: stp             lr, x16, [SP, #-0x10]!
    // 0x866714: r0 = animateTo()
    //     0x866714: bl              #0x518ce0  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::animateTo
    // 0x866718: add             SP, SP, #0x20
    // 0x86671c: r0 = Null
    //     0x86671c: mov             x0, NULL
    // 0x866720: LeaveFrame
    //     0x866720: mov             SP, fp
    //     0x866724: ldp             fp, lr, [SP], #0x10
    // 0x866728: ret
    //     0x866728: ret             
    // 0x86672c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86672c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866730: b               #0x8666c4
    // 0x866734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x866734: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9db3fc, size: 0x1ac
    // 0x9db3fc: EnterFrame
    //     0x9db3fc: stp             fp, lr, [SP, #-0x10]!
    //     0x9db400: mov             fp, SP
    // 0x9db404: AllocStack(0x10)
    //     0x9db404: sub             SP, SP, #0x10
    // 0x9db408: CheckStackOverflow
    //     0x9db408: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db40c: cmp             SP, x16
    //     0x9db410: b.ls            #0x9db598
    // 0x9db414: ldr             x0, [fp, #0x10]
    // 0x9db418: LoadField: r1 = r0->field_f
    //     0x9db418: ldur            w1, [x0, #0xf]
    // 0x9db41c: DecompressPointer r1
    //     0x9db41c: add             x1, x1, HEAP, lsl #32
    // 0x9db420: cmp             w1, NULL
    // 0x9db424: b.eq            #0x9db5a0
    // 0x9db428: r0 = _ScaffoldGeometryNotifier()
    //     0x9db428: bl              #0x9db5a8  ; Allocate_ScaffoldGeometryNotifierStub -> _ScaffoldGeometryNotifier (size=0x2c)
    // 0x9db42c: mov             x1, x0
    // 0x9db430: r0 = Instance_ScaffoldGeometry
    //     0x9db430: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ff0] Obj!ScaffoldGeometry@b37c51
    //     0x9db434: ldr             x0, [x0, #0xff0]
    // 0x9db438: stur            x1, [fp, #-8]
    // 0x9db43c: StoreField: r1->field_27 = r0
    //     0x9db43c: stur            w0, [x1, #0x27]
    // 0x9db440: r0 = 0
    //     0x9db440: mov             x0, #0
    // 0x9db444: StoreField: r1->field_7 = r0
    //     0x9db444: stur            x0, [x1, #7]
    // 0x9db448: StoreField: r1->field_13 = r0
    //     0x9db448: stur            x0, [x1, #0x13]
    // 0x9db44c: StoreField: r1->field_1b = r0
    //     0x9db44c: stur            x0, [x1, #0x1b]
    // 0x9db450: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x9db450: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9db454: ldr             x0, [x0, #0x1580]
    //     0x9db458: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x9db45c: cmp             w0, w16
    //     0x9db460: b.ne            #0x9db46c
    //     0x9db464: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x9db468: bl              #0xd67cdc
    // 0x9db46c: mov             x1, x0
    // 0x9db470: ldur            x0, [fp, #-8]
    // 0x9db474: StoreField: r0->field_f = r1
    //     0x9db474: stur            w1, [x0, #0xf]
    // 0x9db478: ldr             x1, [fp, #0x10]
    // 0x9db47c: StoreField: r1->field_73 = r0
    //     0x9db47c: stur            w0, [x1, #0x73]
    //     0x9db480: ldurb           w16, [x1, #-1]
    //     0x9db484: ldurb           w17, [x0, #-1]
    //     0x9db488: and             x16, x17, x16, lsr #2
    //     0x9db48c: tst             x16, HEAP, lsr #32
    //     0x9db490: b.eq            #0x9db498
    //     0x9db494: bl              #0xd6826c
    // 0x9db498: LoadField: r0 = r1->field_b
    //     0x9db498: ldur            w0, [x1, #0xb]
    // 0x9db49c: DecompressPointer r0
    //     0x9db49c: add             x0, x0, HEAP, lsl #32
    // 0x9db4a0: cmp             w0, NULL
    // 0x9db4a4: b.eq            #0x9db5a4
    // 0x9db4a8: r0 = Instance__EndFloatFabLocation
    //     0x9db4a8: add             x0, PP, #0x21, lsl #12  ; [pp+0x21e48] Obj!_EndFloatFabLocation@b38591
    //     0x9db4ac: ldr             x0, [x0, #0xe48]
    // 0x9db4b0: StoreField: r1->field_6b = r0
    //     0x9db4b0: stur            w0, [x1, #0x6b]
    // 0x9db4b4: r2 = Instance__ScalingFabMotionAnimator
    //     0x9db4b4: add             x2, PP, #0x21, lsl #12  ; [pp+0x21dd0] Obj!_ScalingFabMotionAnimator@b38581
    //     0x9db4b8: ldr             x2, [x2, #0xdd0]
    // 0x9db4bc: StoreField: r1->field_63 = r2
    //     0x9db4bc: stur            w2, [x1, #0x63]
    // 0x9db4c0: StoreField: r1->field_67 = r0
    //     0x9db4c0: stur            w0, [x1, #0x67]
    // 0x9db4c4: r16 = Instance_Duration
    //     0x9db4c4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9db4c8: ldr             x16, [x16, #0x9e0]
    // 0x9db4cc: r30 = 4
    //     0x9db4cc: mov             lr, #4
    // 0x9db4d0: stp             lr, x16, [SP, #-0x10]!
    // 0x9db4d4: r0 = *()
    //     0x9db4d4: bl              #0x4b52d4  ; [dart:core] Duration::*
    // 0x9db4d8: add             SP, SP, #0x10
    // 0x9db4dc: r1 = <double>
    //     0x9db4dc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db4e0: stur            x0, [fp, #-8]
    // 0x9db4e4: r0 = AnimationController()
    //     0x9db4e4: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db4e8: stur            x0, [fp, #-0x10]
    // 0x9db4ec: ldr             x16, [fp, #0x10]
    // 0x9db4f0: stp             x16, x0, [SP, #-0x10]!
    // 0x9db4f4: r16 = 1.000000
    //     0x9db4f4: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x9db4f8: ldur            lr, [fp, #-8]
    // 0x9db4fc: stp             lr, x16, [SP, #-0x10]!
    // 0x9db500: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x3, value, 0x2, null]
    //     0x9db500: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ff8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0x9db504: ldr             x4, [x4, #0xff8]
    // 0x9db508: r0 = AnimationController()
    //     0x9db508: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db50c: add             SP, SP, #0x20
    // 0x9db510: ldur            x0, [fp, #-0x10]
    // 0x9db514: ldr             x2, [fp, #0x10]
    // 0x9db518: StoreField: r2->field_5f = r0
    //     0x9db518: stur            w0, [x2, #0x5f]
    //     0x9db51c: ldurb           w16, [x2, #-1]
    //     0x9db520: ldurb           w17, [x0, #-1]
    //     0x9db524: and             x16, x17, x16, lsr #2
    //     0x9db528: tst             x16, HEAP, lsr #32
    //     0x9db52c: b.eq            #0x9db534
    //     0x9db530: bl              #0xd6828c
    // 0x9db534: r1 = <double>
    //     0x9db534: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db538: r0 = AnimationController()
    //     0x9db538: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db53c: stur            x0, [fp, #-8]
    // 0x9db540: ldr             x16, [fp, #0x10]
    // 0x9db544: stp             x16, x0, [SP, #-0x10]!
    // 0x9db548: r16 = Instance_Duration
    //     0x9db548: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9db54c: ldr             x16, [x16, #0x9e0]
    // 0x9db550: SaveReg r16
    //     0x9db550: str             x16, [SP, #-8]!
    // 0x9db554: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9db554: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9db558: ldr             x4, [x4, #0xa0]
    // 0x9db55c: r0 = AnimationController()
    //     0x9db55c: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db560: add             SP, SP, #0x18
    // 0x9db564: ldur            x0, [fp, #-8]
    // 0x9db568: ldr             x1, [fp, #0x10]
    // 0x9db56c: StoreField: r1->field_6f = r0
    //     0x9db56c: stur            w0, [x1, #0x6f]
    //     0x9db570: ldurb           w16, [x1, #-1]
    //     0x9db574: ldurb           w17, [x0, #-1]
    //     0x9db578: and             x16, x17, x16, lsr #2
    //     0x9db57c: tst             x16, HEAP, lsr #32
    //     0x9db580: b.eq            #0x9db588
    //     0x9db584: bl              #0xd6826c
    // 0x9db588: r0 = Null
    //     0x9db588: mov             x0, NULL
    // 0x9db58c: LeaveFrame
    //     0x9db58c: mov             SP, fp
    //     0x9db590: ldp             fp, lr, [SP], #0x10
    // 0x9db594: ret
    //     0x9db594: ret             
    // 0x9db598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db598: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db59c: b               #0x9db414
    // 0x9db5a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db5a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9db5a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db5a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ScaffoldState(/* No info */) {
    // ** addr: 0xa4134c, size: 0x248
    // 0xa4134c: EnterFrame
    //     0xa4134c: stp             fp, lr, [SP, #-0x10]!
    //     0xa41350: mov             fp, SP
    // 0xa41354: AllocStack(0x10)
    //     0xa41354: sub             SP, SP, #0x10
    // 0xa41358: r1 = Sentinel
    //     0xa41358: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4135c: r2 = false
    //     0xa4135c: add             x2, NULL, #0x30  ; false
    // 0xa41360: r0 = Instance_Color
    //     0xa41360: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xa41364: ldr             x0, [x0, #0xf38]
    // 0xa41368: CheckStackOverflow
    //     0xa41368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4136c: cmp             SP, x16
    //     0xa41370: b.ls            #0xa4158c
    // 0xa41374: ldr             x3, [fp, #0x10]
    // 0xa41378: StoreField: r3->field_5f = r1
    //     0xa41378: stur            w1, [x3, #0x5f]
    // 0xa4137c: StoreField: r3->field_63 = r1
    //     0xa4137c: stur            w1, [x3, #0x63]
    // 0xa41380: StoreField: r3->field_6f = r1
    //     0xa41380: stur            w1, [x3, #0x6f]
    // 0xa41384: StoreField: r3->field_73 = r1
    //     0xa41384: stur            w1, [x3, #0x73]
    // 0xa41388: StoreField: r3->field_77 = r2
    //     0xa41388: stur            w2, [x3, #0x77]
    // 0xa4138c: StoreField: r3->field_7b = r0
    //     0xa4138c: stur            w0, [x3, #0x7b]
    // 0xa41390: r1 = <DrawerControllerState<DrawerController>>
    //     0xa41390: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cfa8] TypeArguments: <DrawerControllerState<DrawerController>>
    //     0xa41394: ldr             x1, [x1, #0xfa8]
    // 0xa41398: r0 = LabeledGlobalKey()
    //     0xa41398: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa4139c: ldr             x2, [fp, #0x10]
    // 0xa413a0: StoreField: r2->field_2b = r0
    //     0xa413a0: stur            w0, [x2, #0x2b]
    //     0xa413a4: ldurb           w16, [x2, #-1]
    //     0xa413a8: ldurb           w17, [x0, #-1]
    //     0xa413ac: and             x16, x17, x16, lsr #2
    //     0xa413b0: tst             x16, HEAP, lsr #32
    //     0xa413b4: b.eq            #0xa413bc
    //     0xa413b8: bl              #0xd6828c
    // 0xa413bc: r1 = <DrawerControllerState<DrawerController>>
    //     0xa413bc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cfa8] TypeArguments: <DrawerControllerState<DrawerController>>
    //     0xa413c0: ldr             x1, [x1, #0xfa8]
    // 0xa413c4: r0 = LabeledGlobalKey()
    //     0xa413c4: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa413c8: ldr             x2, [fp, #0x10]
    // 0xa413cc: StoreField: r2->field_2f = r0
    //     0xa413cc: stur            w0, [x2, #0x2f]
    //     0xa413d0: ldurb           w16, [x2, #-1]
    //     0xa413d4: ldurb           w17, [x0, #-1]
    //     0xa413d8: and             x16, x17, x16, lsr #2
    //     0xa413dc: tst             x16, HEAP, lsr #32
    //     0xa413e0: b.eq            #0xa413e8
    //     0xa413e4: bl              #0xd6828c
    // 0xa413e8: r1 = <State<StatefulWidget>>
    //     0xa413e8: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0xa413ec: r0 = LabeledGlobalKey()
    //     0xa413ec: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa413f0: ldr             x2, [fp, #0x10]
    // 0xa413f4: StoreField: r2->field_33 = r0
    //     0xa413f4: stur            w0, [x2, #0x33]
    //     0xa413f8: ldurb           w16, [x2, #-1]
    //     0xa413fc: ldurb           w17, [x0, #-1]
    //     0xa41400: and             x16, x17, x16, lsr #2
    //     0xa41404: tst             x16, HEAP, lsr #32
    //     0xa41408: b.eq            #0xa41410
    //     0xa4140c: bl              #0xd6828c
    // 0xa41410: r1 = <bool>
    //     0xa41410: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xa41414: r0 = RestorableBool()
    //     0xa41414: bl              #0xa41594  ; AllocateRestorableBoolStub -> RestorableBool (size=0x3c)
    // 0xa41418: mov             x1, x0
    // 0xa4141c: r0 = false
    //     0xa4141c: add             x0, NULL, #0x30  ; false
    // 0xa41420: stur            x1, [fp, #-8]
    // 0xa41424: StoreField: r1->field_37 = r0
    //     0xa41424: stur            w0, [x1, #0x37]
    // 0xa41428: StoreField: r1->field_27 = r0
    //     0xa41428: stur            w0, [x1, #0x27]
    // 0xa4142c: r2 = 0
    //     0xa4142c: mov             x2, #0
    // 0xa41430: StoreField: r1->field_7 = r2
    //     0xa41430: stur            x2, [x1, #7]
    // 0xa41434: StoreField: r1->field_13 = r2
    //     0xa41434: stur            x2, [x1, #0x13]
    // 0xa41438: StoreField: r1->field_1b = r2
    //     0xa41438: stur            x2, [x1, #0x1b]
    // 0xa4143c: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0xa4143c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa41440: ldr             x0, [x0, #0x1580]
    //     0xa41444: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa41448: cmp             w0, w16
    //     0xa4144c: b.ne            #0xa41458
    //     0xa41450: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0xa41454: bl              #0xd67cdc
    // 0xa41458: mov             x2, x0
    // 0xa4145c: ldur            x0, [fp, #-8]
    // 0xa41460: stur            x2, [fp, #-0x10]
    // 0xa41464: StoreField: r0->field_f = r2
    //     0xa41464: stur            w2, [x0, #0xf]
    // 0xa41468: ldr             x3, [fp, #0x10]
    // 0xa4146c: StoreField: r3->field_3b = r0
    //     0xa4146c: stur            w0, [x3, #0x3b]
    //     0xa41470: ldurb           w16, [x3, #-1]
    //     0xa41474: ldurb           w17, [x0, #-1]
    //     0xa41478: and             x16, x17, x16, lsr #2
    //     0xa4147c: tst             x16, HEAP, lsr #32
    //     0xa41480: b.eq            #0xa41488
    //     0xa41484: bl              #0xd682ac
    // 0xa41488: r1 = <bool>
    //     0xa41488: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xa4148c: r0 = RestorableBool()
    //     0xa4148c: bl              #0xa41594  ; AllocateRestorableBoolStub -> RestorableBool (size=0x3c)
    // 0xa41490: mov             x1, x0
    // 0xa41494: r0 = false
    //     0xa41494: add             x0, NULL, #0x30  ; false
    // 0xa41498: StoreField: r1->field_37 = r0
    //     0xa41498: stur            w0, [x1, #0x37]
    // 0xa4149c: StoreField: r1->field_27 = r0
    //     0xa4149c: stur            w0, [x1, #0x27]
    // 0xa414a0: r0 = 0
    //     0xa414a0: mov             x0, #0
    // 0xa414a4: StoreField: r1->field_7 = r0
    //     0xa414a4: stur            x0, [x1, #7]
    // 0xa414a8: StoreField: r1->field_13 = r0
    //     0xa414a8: stur            x0, [x1, #0x13]
    // 0xa414ac: StoreField: r1->field_1b = r0
    //     0xa414ac: stur            x0, [x1, #0x1b]
    // 0xa414b0: ldur            x0, [fp, #-0x10]
    // 0xa414b4: StoreField: r1->field_f = r0
    //     0xa414b4: stur            w0, [x1, #0xf]
    // 0xa414b8: mov             x0, x1
    // 0xa414bc: ldr             x1, [fp, #0x10]
    // 0xa414c0: StoreField: r1->field_3f = r0
    //     0xa414c0: stur            w0, [x1, #0x3f]
    //     0xa414c4: ldurb           w16, [x1, #-1]
    //     0xa414c8: ldurb           w17, [x0, #-1]
    //     0xa414cc: and             x16, x17, x16, lsr #2
    //     0xa414d0: tst             x16, HEAP, lsr #32
    //     0xa414d4: b.eq            #0xa414dc
    //     0xa414d8: bl              #0xd6826c
    // 0xa414dc: r16 = <_StandardBottomSheet>
    //     0xa414dc: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cfb0] TypeArguments: <_StandardBottomSheet>
    //     0xa414e0: ldr             x16, [x16, #0xfb0]
    // 0xa414e4: stp             xzr, x16, [SP, #-0x10]!
    // 0xa414e8: r0 = _GrowableList()
    //     0xa414e8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa414ec: add             SP, SP, #0x10
    // 0xa414f0: ldr             x2, [fp, #0x10]
    // 0xa414f4: StoreField: r2->field_4f = r0
    //     0xa414f4: stur            w0, [x2, #0x4f]
    //     0xa414f8: ldurb           w16, [x2, #-1]
    //     0xa414fc: ldurb           w17, [x0, #-1]
    //     0xa41500: and             x16, x17, x16, lsr #2
    //     0xa41504: tst             x16, HEAP, lsr #32
    //     0xa41508: b.eq            #0xa41510
    //     0xa4150c: bl              #0xd6828c
    // 0xa41510: r1 = <State<StatefulWidget>>
    //     0xa41510: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0xa41514: r0 = LabeledGlobalKey()
    //     0xa41514: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa41518: ldr             x1, [fp, #0x10]
    // 0xa4151c: StoreField: r1->field_57 = r0
    //     0xa4151c: stur            w0, [x1, #0x57]
    //     0xa41520: ldurb           w16, [x1, #-1]
    //     0xa41524: ldurb           w17, [x0, #-1]
    //     0xa41528: and             x16, x17, x16, lsr #2
    //     0xa4152c: tst             x16, HEAP, lsr #32
    //     0xa41530: b.eq            #0xa41538
    //     0xa41534: bl              #0xd6826c
    // 0xa41538: r0 = true
    //     0xa41538: add             x0, NULL, #0x20  ; true
    // 0xa4153c: StoreField: r1->field_23 = r0
    //     0xa4153c: stur            w0, [x1, #0x23]
    // 0xa41540: r16 = <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xa41540: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cfb8] TypeArguments: <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xa41544: ldr             x16, [x16, #0xfb8]
    // 0xa41548: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xa4154c: stp             lr, x16, [SP, #-0x10]!
    // 0xa41550: r0 = Map._fromLiteral()
    //     0xa41550: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa41554: add             SP, SP, #0x10
    // 0xa41558: ldr             x1, [fp, #0x10]
    // 0xa4155c: StoreField: r1->field_1f = r0
    //     0xa4155c: stur            w0, [x1, #0x1f]
    //     0xa41560: tbz             w0, #0, #0xa4157c
    //     0xa41564: ldurb           w16, [x1, #-1]
    //     0xa41568: ldurb           w17, [x0, #-1]
    //     0xa4156c: and             x16, x17, x16, lsr #2
    //     0xa41570: tst             x16, HEAP, lsr #32
    //     0xa41574: b.eq            #0xa4157c
    //     0xa41578: bl              #0xd6826c
    // 0xa4157c: r0 = Null
    //     0xa4157c: mov             x0, NULL
    // 0xa41580: LeaveFrame
    //     0xa41580: mov             SP, fp
    //     0xa41584: ldp             fp, lr, [SP], #0x10
    // 0xa41588: ret
    //     0xa41588: ret             
    // 0xa4158c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4158c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa41590: b               #0xa41374
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b0c8, size: 0x18
    // 0xa4b0c8: r4 = 7
    //     0xa4b0c8: mov             x4, #7
    // 0xa4b0cc: r1 = Function 'dispose':.
    //     0xa4b0cc: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b5a0] AnonymousClosure: (0xa4b0e0), in [package:flutter/src/material/scaffold.dart] ScaffoldState::dispose (0xa527c0)
    //     0xa4b0d0: ldr             x1, [x17, #0x5a0]
    // 0xa4b0d4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b0d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b0d8: LoadField: r0 = r24->field_17
    //     0xa4b0d8: ldur            x0, [x24, #0x17]
    // 0xa4b0dc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b0e0, size: 0x48
    // 0xa4b0e0: EnterFrame
    //     0xa4b0e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b0e4: mov             fp, SP
    // 0xa4b0e8: ldr             x0, [fp, #0x10]
    // 0xa4b0ec: LoadField: r1 = r0->field_17
    //     0xa4b0ec: ldur            w1, [x0, #0x17]
    // 0xa4b0f0: DecompressPointer r1
    //     0xa4b0f0: add             x1, x1, HEAP, lsl #32
    // 0xa4b0f4: CheckStackOverflow
    //     0xa4b0f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b0f8: cmp             SP, x16
    //     0xa4b0fc: b.ls            #0xa4b120
    // 0xa4b100: LoadField: r0 = r1->field_f
    //     0xa4b100: ldur            w0, [x1, #0xf]
    // 0xa4b104: DecompressPointer r0
    //     0xa4b104: add             x0, x0, HEAP, lsl #32
    // 0xa4b108: SaveReg r0
    //     0xa4b108: str             x0, [SP, #-8]!
    // 0xa4b10c: r0 = dispose()
    //     0xa4b10c: bl              #0xa527c0  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::dispose
    // 0xa4b110: add             SP, SP, #8
    // 0xa4b114: LeaveFrame
    //     0xa4b114: mov             SP, fp
    //     0xa4b118: ldp             fp, lr, [SP], #0x10
    // 0xa4b11c: ret
    //     0xa4b11c: ret             
    // 0xa4b120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b120: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b124: b               #0xa4b100
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa527c0, size: 0x11c
    // 0xa527c0: EnterFrame
    //     0xa527c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa527c4: mov             fp, SP
    // 0xa527c8: CheckStackOverflow
    //     0xa527c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa527cc: cmp             SP, x16
    //     0xa527d0: b.ls            #0xa528b0
    // 0xa527d4: ldr             x0, [fp, #0x10]
    // 0xa527d8: LoadField: r1 = r0->field_73
    //     0xa527d8: ldur            w1, [x0, #0x73]
    // 0xa527dc: DecompressPointer r1
    //     0xa527dc: add             x1, x1, HEAP, lsl #32
    // 0xa527e0: r16 = Sentinel
    //     0xa527e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa527e4: cmp             w1, w16
    // 0xa527e8: b.eq            #0xa528b8
    // 0xa527ec: SaveReg r1
    //     0xa527ec: str             x1, [SP, #-8]!
    // 0xa527f0: r0 = dispose()
    //     0xa527f0: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0xa527f4: add             SP, SP, #8
    // 0xa527f8: ldr             x0, [fp, #0x10]
    // 0xa527fc: LoadField: r1 = r0->field_5f
    //     0xa527fc: ldur            w1, [x0, #0x5f]
    // 0xa52800: DecompressPointer r1
    //     0xa52800: add             x1, x1, HEAP, lsl #32
    // 0xa52804: r16 = Sentinel
    //     0xa52804: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa52808: cmp             w1, w16
    // 0xa5280c: b.eq            #0xa528c4
    // 0xa52810: SaveReg r1
    //     0xa52810: str             x1, [SP, #-8]!
    // 0xa52814: r0 = dispose()
    //     0xa52814: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa52818: add             SP, SP, #8
    // 0xa5281c: ldr             x0, [fp, #0x10]
    // 0xa52820: LoadField: r1 = r0->field_6f
    //     0xa52820: ldur            w1, [x0, #0x6f]
    // 0xa52824: DecompressPointer r1
    //     0xa52824: add             x1, x1, HEAP, lsl #32
    // 0xa52828: r16 = Sentinel
    //     0xa52828: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa5282c: cmp             w1, w16
    // 0xa52830: b.eq            #0xa528d0
    // 0xa52834: SaveReg r1
    //     0xa52834: str             x1, [SP, #-8]!
    // 0xa52838: r0 = dispose()
    //     0xa52838: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa5283c: add             SP, SP, #8
    // 0xa52840: ldr             x0, [fp, #0x10]
    // 0xa52844: LoadField: r1 = r0->field_43
    //     0xa52844: ldur            w1, [x0, #0x43]
    // 0xa52848: DecompressPointer r1
    //     0xa52848: add             x1, x1, HEAP, lsl #32
    // 0xa5284c: cmp             w1, NULL
    // 0xa52850: b.eq            #0xa52864
    // 0xa52854: stp             x0, x1, [SP, #-0x10]!
    // 0xa52858: r0 = _unregister()
    //     0xa52858: bl              #0xa528dc  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_unregister
    // 0xa5285c: add             SP, SP, #0x10
    // 0xa52860: ldr             x0, [fp, #0x10]
    // 0xa52864: LoadField: r1 = r0->field_3b
    //     0xa52864: ldur            w1, [x0, #0x3b]
    // 0xa52868: DecompressPointer r1
    //     0xa52868: add             x1, x1, HEAP, lsl #32
    // 0xa5286c: SaveReg r1
    //     0xa5286c: str             x1, [SP, #-8]!
    // 0xa52870: r0 = dispose()
    //     0xa52870: bl              #0x9c2934  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::dispose
    // 0xa52874: add             SP, SP, #8
    // 0xa52878: ldr             x0, [fp, #0x10]
    // 0xa5287c: LoadField: r1 = r0->field_3f
    //     0xa5287c: ldur            w1, [x0, #0x3f]
    // 0xa52880: DecompressPointer r1
    //     0xa52880: add             x1, x1, HEAP, lsl #32
    // 0xa52884: SaveReg r1
    //     0xa52884: str             x1, [SP, #-8]!
    // 0xa52888: r0 = dispose()
    //     0xa52888: bl              #0x9c2934  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::dispose
    // 0xa5288c: add             SP, SP, #8
    // 0xa52890: ldr             x16, [fp, #0x10]
    // 0xa52894: SaveReg r16
    //     0xa52894: str             x16, [SP, #-8]!
    // 0xa52898: r0 = dispose()
    //     0xa52898: bl              #0xa4f500  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::dispose
    // 0xa5289c: add             SP, SP, #8
    // 0xa528a0: r0 = Null
    //     0xa528a0: mov             x0, NULL
    // 0xa528a4: LeaveFrame
    //     0xa528a4: mov             SP, fp
    //     0xa528a8: ldp             fp, lr, [SP], #0x10
    // 0xa528ac: ret
    //     0xa528ac: ret             
    // 0xa528b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa528b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa528b4: b               #0xa527d4
    // 0xa528b8: r9 = _geometryNotifier
    //     0xa528b8: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e20] Field <ScaffoldState._geometryNotifier@801420462>: late (offset: 0x74)
    //     0xa528bc: ldr             x9, [x9, #0xe20]
    // 0xa528c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa528c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa528c4: r9 = _floatingActionButtonMoveController
    //     0xa528c4: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e10] Field <ScaffoldState._floatingActionButtonMoveController@801420462>: late (offset: 0x60)
    //     0xa528c8: ldr             x9, [x9, #0xe10]
    // 0xa528cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa528cc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa528d0: r9 = _floatingActionButtonVisibilityController
    //     0xa528d0: add             x9, PP, #0x21, lsl #12  ; [pp+0x21e28] Field <ScaffoldState._floatingActionButtonVisibilityController@801420462>: late (offset: 0x70)
    //     0xa528d4: ldr             x9, [x9, #0xe28]
    // 0xa528d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa528d8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa616d0, size: 0xe8
    // 0xa616d0: EnterFrame
    //     0xa616d0: stp             fp, lr, [SP, #-0x10]!
    //     0xa616d4: mov             fp, SP
    // 0xa616d8: AllocStack(0x8)
    //     0xa616d8: sub             SP, SP, #8
    // 0xa616dc: CheckStackOverflow
    //     0xa616dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa616e0: cmp             SP, x16
    //     0xa616e4: b.ls            #0xa617ac
    // 0xa616e8: ldr             x0, [fp, #0x10]
    // 0xa616ec: LoadField: r1 = r0->field_f
    //     0xa616ec: ldur            w1, [x0, #0xf]
    // 0xa616f0: DecompressPointer r1
    //     0xa616f0: add             x1, x1, HEAP, lsl #32
    // 0xa616f4: cmp             w1, NULL
    // 0xa616f8: b.eq            #0xa617b4
    // 0xa616fc: SaveReg r1
    //     0xa616fc: str             x1, [SP, #-8]!
    // 0xa61700: r0 = maybeOf()
    //     0xa61700: bl              #0xa61d3c  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::maybeOf
    // 0xa61704: add             SP, SP, #8
    // 0xa61708: mov             x1, x0
    // 0xa6170c: ldr             x0, [fp, #0x10]
    // 0xa61710: stur            x1, [fp, #-8]
    // 0xa61714: LoadField: r2 = r0->field_43
    //     0xa61714: ldur            w2, [x0, #0x43]
    // 0xa61718: DecompressPointer r2
    //     0xa61718: add             x2, x2, HEAP, lsl #32
    // 0xa6171c: cmp             w2, NULL
    // 0xa61720: b.eq            #0xa61740
    // 0xa61724: cmp             w1, NULL
    // 0xa61728: b.eq            #0xa61734
    // 0xa6172c: cmp             w2, w1
    // 0xa61730: b.eq            #0xa61740
    // 0xa61734: stp             x0, x2, [SP, #-0x10]!
    // 0xa61738: r0 = _unregister()
    //     0xa61738: bl              #0xa528dc  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_unregister
    // 0xa6173c: add             SP, SP, #0x10
    // 0xa61740: ldr             x1, [fp, #0x10]
    // 0xa61744: ldur            x2, [fp, #-8]
    // 0xa61748: mov             x0, x2
    // 0xa6174c: StoreField: r1->field_43 = r0
    //     0xa6174c: stur            w0, [x1, #0x43]
    //     0xa61750: ldurb           w16, [x1, #-1]
    //     0xa61754: ldurb           w17, [x0, #-1]
    //     0xa61758: and             x16, x17, x16, lsr #2
    //     0xa6175c: tst             x16, HEAP, lsr #32
    //     0xa61760: b.eq            #0xa61768
    //     0xa61764: bl              #0xd6826c
    // 0xa61768: cmp             w2, NULL
    // 0xa6176c: b.eq            #0xa6177c
    // 0xa61770: stp             x1, x2, [SP, #-0x10]!
    // 0xa61774: r0 = _register()
    //     0xa61774: bl              #0xa61ad4  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_register
    // 0xa61778: add             SP, SP, #0x10
    // 0xa6177c: ldr             x16, [fp, #0x10]
    // 0xa61780: SaveReg r16
    //     0xa61780: str             x16, [SP, #-8]!
    // 0xa61784: r0 = _maybeBuildPersistentBottomSheet()
    //     0xa61784: bl              #0x7ba864  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet
    // 0xa61788: add             SP, SP, #8
    // 0xa6178c: ldr             x16, [fp, #0x10]
    // 0xa61790: SaveReg r16
    //     0xa61790: str             x16, [SP, #-8]!
    // 0xa61794: r0 = didChangeDependencies()
    //     0xa61794: bl              #0xa617b8  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::didChangeDependencies
    // 0xa61798: add             SP, SP, #8
    // 0xa6179c: r0 = Null
    //     0xa6179c: mov             x0, NULL
    // 0xa617a0: LeaveFrame
    //     0xa617a0: mov             SP, fp
    //     0xa617a4: ldp             fp, lr, [SP], #0x10
    // 0xa617a8: ret
    //     0xa617a8: ret             
    // 0xa617ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa617ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa617b0: b               #0xa616e8
    // 0xa617b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa617b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ restoreState(/* No info */) {
    // ** addr: 0xa618c4, size: 0x74
    // 0xa618c4: EnterFrame
    //     0xa618c4: stp             fp, lr, [SP, #-0x10]!
    //     0xa618c8: mov             fp, SP
    // 0xa618cc: CheckStackOverflow
    //     0xa618cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa618d0: cmp             SP, x16
    //     0xa618d4: b.ls            #0xa61930
    // 0xa618d8: ldr             x0, [fp, #0x18]
    // 0xa618dc: LoadField: r1 = r0->field_3b
    //     0xa618dc: ldur            w1, [x0, #0x3b]
    // 0xa618e0: DecompressPointer r1
    //     0xa618e0: add             x1, x1, HEAP, lsl #32
    // 0xa618e4: stp             x1, x0, [SP, #-0x10]!
    // 0xa618e8: r16 = "drawer_open"
    //     0xa618e8: add             x16, PP, #0x22, lsl #12  ; [pp+0x22020] "drawer_open"
    //     0xa618ec: ldr             x16, [x16, #0x20]
    // 0xa618f0: SaveReg r16
    //     0xa618f0: str             x16, [SP, #-8]!
    // 0xa618f4: r0 = registerForRestoration()
    //     0xa618f4: bl              #0xa61938  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::registerForRestoration
    // 0xa618f8: add             SP, SP, #0x18
    // 0xa618fc: ldr             x0, [fp, #0x18]
    // 0xa61900: LoadField: r1 = r0->field_3f
    //     0xa61900: ldur            w1, [x0, #0x3f]
    // 0xa61904: DecompressPointer r1
    //     0xa61904: add             x1, x1, HEAP, lsl #32
    // 0xa61908: stp             x1, x0, [SP, #-0x10]!
    // 0xa6190c: r16 = "end_drawer_open"
    //     0xa6190c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22028] "end_drawer_open"
    //     0xa61910: ldr             x16, [x16, #0x28]
    // 0xa61914: SaveReg r16
    //     0xa61914: str             x16, [SP, #-8]!
    // 0xa61918: r0 = registerForRestoration()
    //     0xa61918: bl              #0xa61938  ; [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::registerForRestoration
    // 0xa6191c: add             SP, SP, #0x18
    // 0xa61920: r0 = Null
    //     0xa61920: mov             x0, NULL
    // 0xa61924: LeaveFrame
    //     0xa61924: mov             SP, fp
    //     0xa61928: ldp             fp, lr, [SP], #0x10
    // 0xa6192c: ret
    //     0xa6192c: ret             
    // 0xa61930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61930: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61934: b               #0xa618d8
  }
  _ _updateMaterialBanner(/* No info */) {
    // ** addr: 0xa61b8c, size: 0xe0
    // 0xa61b8c: EnterFrame
    //     0xa61b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xa61b90: mov             fp, SP
    // 0xa61b94: AllocStack(0x8)
    //     0xa61b94: sub             SP, SP, #8
    // 0xa61b98: CheckStackOverflow
    //     0xa61b98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61b9c: cmp             SP, x16
    //     0xa61ba0: b.ls            #0xa61c60
    // 0xa61ba4: r1 = 2
    //     0xa61ba4: mov             x1, #2
    // 0xa61ba8: r0 = AllocateContext()
    //     0xa61ba8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa61bac: mov             x1, x0
    // 0xa61bb0: ldr             x0, [fp, #0x10]
    // 0xa61bb4: stur            x1, [fp, #-8]
    // 0xa61bb8: StoreField: r1->field_f = r0
    //     0xa61bb8: stur            w0, [x1, #0xf]
    // 0xa61bbc: LoadField: r2 = r0->field_43
    //     0xa61bbc: ldur            w2, [x0, #0x43]
    // 0xa61bc0: DecompressPointer r2
    //     0xa61bc0: add             x2, x2, HEAP, lsl #32
    // 0xa61bc4: cmp             w2, NULL
    // 0xa61bc8: b.eq            #0xa61c68
    // 0xa61bcc: LoadField: r3 = r2->field_1f
    //     0xa61bcc: ldur            w3, [x2, #0x1f]
    // 0xa61bd0: DecompressPointer r3
    //     0xa61bd0: add             x3, x3, HEAP, lsl #32
    // 0xa61bd4: LoadField: r2 = r3->field_f
    //     0xa61bd4: ldur            x2, [x3, #0xf]
    // 0xa61bd8: LoadField: r4 = r3->field_17
    //     0xa61bd8: ldur            x4, [x3, #0x17]
    // 0xa61bdc: cmp             x2, x4
    // 0xa61be0: b.eq            #0xa61bf8
    // 0xa61be4: SaveReg r3
    //     0xa61be4: str             x3, [SP, #-8]!
    // 0xa61be8: r0 = first()
    //     0xa61be8: bl              #0x6b78d0  ; [dart:collection] ListQueue::first
    // 0xa61bec: add             SP, SP, #8
    // 0xa61bf0: mov             x1, x0
    // 0xa61bf4: b               #0xa61bfc
    // 0xa61bf8: r1 = Null
    //     0xa61bf8: mov             x1, NULL
    // 0xa61bfc: ldr             x3, [fp, #0x10]
    // 0xa61c00: ldur            x2, [fp, #-8]
    // 0xa61c04: mov             x0, x1
    // 0xa61c08: StoreField: r2->field_13 = r0
    //     0xa61c08: stur            w0, [x2, #0x13]
    //     0xa61c0c: ldurb           w16, [x2, #-1]
    //     0xa61c10: ldurb           w17, [x0, #-1]
    //     0xa61c14: and             x16, x17, x16, lsr #2
    //     0xa61c18: tst             x16, HEAP, lsr #32
    //     0xa61c1c: b.eq            #0xa61c24
    //     0xa61c20: bl              #0xd6828c
    // 0xa61c24: LoadField: r0 = r3->field_4b
    //     0xa61c24: ldur            w0, [x3, #0x4b]
    // 0xa61c28: DecompressPointer r0
    //     0xa61c28: add             x0, x0, HEAP, lsl #32
    // 0xa61c2c: cmp             w0, w1
    // 0xa61c30: b.eq            #0xa61c50
    // 0xa61c34: r1 = Function '<anonymous closure>':.
    //     0xa61c34: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fb0] AnonymousClosure: (0xa61c6c), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateMaterialBanner (0xa61b8c)
    //     0xa61c38: ldr             x1, [x1, #0xfb0]
    // 0xa61c3c: r0 = AllocateClosure()
    //     0xa61c3c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa61c40: ldr             x16, [fp, #0x10]
    // 0xa61c44: stp             x0, x16, [SP, #-0x10]!
    // 0xa61c48: r0 = setState()
    //     0xa61c48: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xa61c4c: add             SP, SP, #0x10
    // 0xa61c50: r0 = Null
    //     0xa61c50: mov             x0, NULL
    // 0xa61c54: LeaveFrame
    //     0xa61c54: mov             SP, fp
    //     0xa61c58: ldp             fp, lr, [SP], #0x10
    // 0xa61c5c: ret
    //     0xa61c5c: ret             
    // 0xa61c60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61c60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61c64: b               #0xa61ba4
    // 0xa61c68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61c68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xa61c6c, size: 0x48
    // 0xa61c6c: ldr             x1, [SP]
    // 0xa61c70: LoadField: r2 = r1->field_17
    //     0xa61c70: ldur            w2, [x1, #0x17]
    // 0xa61c74: DecompressPointer r2
    //     0xa61c74: add             x2, x2, HEAP, lsl #32
    // 0xa61c78: LoadField: r1 = r2->field_f
    //     0xa61c78: ldur            w1, [x2, #0xf]
    // 0xa61c7c: DecompressPointer r1
    //     0xa61c7c: add             x1, x1, HEAP, lsl #32
    // 0xa61c80: LoadField: r0 = r2->field_13
    //     0xa61c80: ldur            w0, [x2, #0x13]
    // 0xa61c84: DecompressPointer r0
    //     0xa61c84: add             x0, x0, HEAP, lsl #32
    // 0xa61c88: StoreField: r1->field_4b = r0
    //     0xa61c88: stur            w0, [x1, #0x4b]
    //     0xa61c8c: ldurb           w16, [x1, #-1]
    //     0xa61c90: ldurb           w17, [x0, #-1]
    //     0xa61c94: and             x16, x17, x16, lsr #2
    //     0xa61c98: tst             x16, HEAP, lsr #32
    //     0xa61c9c: b.eq            #0xa61cac
    //     0xa61ca0: str             lr, [SP, #-8]!
    //     0xa61ca4: bl              #0xd6826c
    //     0xa61ca8: ldr             lr, [SP], #8
    // 0xa61cac: r0 = Null
    //     0xa61cac: mov             x0, NULL
    // 0xa61cb0: ret
    //     0xa61cb0: ret             
  }
}

// class id: 3282, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __FloatingActionButtonTransitionState&State&TickerProviderStateMixin extends State<_FloatingActionButtonTransition>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x618318, size: 0x178
    // 0x618318: EnterFrame
    //     0x618318: stp             fp, lr, [SP, #-0x10]!
    //     0x61831c: mov             fp, SP
    // 0x618320: AllocStack(0x10)
    //     0x618320: sub             SP, SP, #0x10
    // 0x618324: CheckStackOverflow
    //     0x618324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618328: cmp             SP, x16
    //     0x61832c: b.ls            #0x618480
    // 0x618330: ldr             x0, [fp, #0x18]
    // 0x618334: LoadField: r1 = r0->field_17
    //     0x618334: ldur            w1, [x0, #0x17]
    // 0x618338: DecompressPointer r1
    //     0x618338: add             x1, x1, HEAP, lsl #32
    // 0x61833c: cmp             w1, NULL
    // 0x618340: b.ne            #0x618350
    // 0x618344: SaveReg r0
    //     0x618344: str             x0, [SP, #-8]!
    // 0x618348: r0 = _updateTickerModeNotifier()
    //     0x618348: bl              #0x6184b4  ; [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x61834c: add             SP, SP, #8
    // 0x618350: ldr             x0, [fp, #0x18]
    // 0x618354: LoadField: r1 = r0->field_13
    //     0x618354: ldur            w1, [x0, #0x13]
    // 0x618358: DecompressPointer r1
    //     0x618358: add             x1, x1, HEAP, lsl #32
    // 0x61835c: cmp             w1, NULL
    // 0x618360: b.ne            #0x6183f8
    // 0x618364: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x618364: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x618368: ldr             x0, [x0, #0x598]
    //     0x61836c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x618370: cmp             w0, w16
    //     0x618374: b.ne            #0x618380
    //     0x618378: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x61837c: bl              #0xd67cdc
    // 0x618380: r1 = <_WidgetTicker>
    //     0x618380: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x618384: ldr             x1, [x1, #0x210]
    // 0x618388: stur            x0, [fp, #-8]
    // 0x61838c: r0 = _Set()
    //     0x61838c: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x618390: mov             x1, x0
    // 0x618394: ldur            x0, [fp, #-8]
    // 0x618398: stur            x1, [fp, #-0x10]
    // 0x61839c: StoreField: r1->field_1b = r0
    //     0x61839c: stur            w0, [x1, #0x1b]
    // 0x6183a0: StoreField: r1->field_b = rZR
    //     0x6183a0: stur            wzr, [x1, #0xb]
    // 0x6183a4: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x6183a4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6183a8: ldr             x0, [x0, #0x5a0]
    //     0x6183ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6183b0: cmp             w0, w16
    //     0x6183b4: b.ne            #0x6183c0
    //     0x6183b8: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x6183bc: bl              #0xd67cdc
    // 0x6183c0: mov             x1, x0
    // 0x6183c4: ldur            x0, [fp, #-0x10]
    // 0x6183c8: StoreField: r0->field_f = r1
    //     0x6183c8: stur            w1, [x0, #0xf]
    // 0x6183cc: StoreField: r0->field_13 = rZR
    //     0x6183cc: stur            wzr, [x0, #0x13]
    // 0x6183d0: StoreField: r0->field_17 = rZR
    //     0x6183d0: stur            wzr, [x0, #0x17]
    // 0x6183d4: ldr             x1, [fp, #0x18]
    // 0x6183d8: StoreField: r1->field_13 = r0
    //     0x6183d8: stur            w0, [x1, #0x13]
    //     0x6183dc: ldurb           w16, [x1, #-1]
    //     0x6183e0: ldurb           w17, [x0, #-1]
    //     0x6183e4: and             x16, x17, x16, lsr #2
    //     0x6183e8: tst             x16, HEAP, lsr #32
    //     0x6183ec: b.eq            #0x6183f4
    //     0x6183f0: bl              #0xd6826c
    // 0x6183f4: b               #0x6183fc
    // 0x6183f8: mov             x1, x0
    // 0x6183fc: ldr             x0, [fp, #0x10]
    // 0x618400: r0 = _WidgetTicker()
    //     0x618400: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x618404: mov             x1, x0
    // 0x618408: ldr             x0, [fp, #0x18]
    // 0x61840c: stur            x1, [fp, #-8]
    // 0x618410: StoreField: r1->field_1b = r0
    //     0x618410: stur            w0, [x1, #0x1b]
    // 0x618414: r2 = false
    //     0x618414: add             x2, NULL, #0x30  ; false
    // 0x618418: StoreField: r1->field_b = r2
    //     0x618418: stur            w2, [x1, #0xb]
    // 0x61841c: ldr             x2, [fp, #0x10]
    // 0x618420: StoreField: r1->field_13 = r2
    //     0x618420: stur            w2, [x1, #0x13]
    // 0x618424: LoadField: r2 = r0->field_17
    //     0x618424: ldur            w2, [x0, #0x17]
    // 0x618428: DecompressPointer r2
    //     0x618428: add             x2, x2, HEAP, lsl #32
    // 0x61842c: cmp             w2, NULL
    // 0x618430: b.eq            #0x618488
    // 0x618434: LoadField: r3 = r2->field_27
    //     0x618434: ldur            w3, [x2, #0x27]
    // 0x618438: DecompressPointer r3
    //     0x618438: add             x3, x3, HEAP, lsl #32
    // 0x61843c: eor             x2, x3, #0x10
    // 0x618440: stp             x2, x1, [SP, #-0x10]!
    // 0x618444: r0 = muted=()
    //     0x618444: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x618448: add             SP, SP, #0x10
    // 0x61844c: ldr             x0, [fp, #0x18]
    // 0x618450: LoadField: r1 = r0->field_13
    //     0x618450: ldur            w1, [x0, #0x13]
    // 0x618454: DecompressPointer r1
    //     0x618454: add             x1, x1, HEAP, lsl #32
    // 0x618458: cmp             w1, NULL
    // 0x61845c: b.eq            #0x61848c
    // 0x618460: ldur            x16, [fp, #-8]
    // 0x618464: stp             x16, x1, [SP, #-0x10]!
    // 0x618468: r0 = add()
    //     0x618468: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x61846c: add             SP, SP, #0x10
    // 0x618470: ldur            x0, [fp, #-8]
    // 0x618474: LeaveFrame
    //     0x618474: mov             SP, fp
    //     0x618478: ldp             fp, lr, [SP], #0x10
    // 0x61847c: ret
    //     0x61847c: ret             
    // 0x618480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618480: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618484: b               #0x618330
    // 0x618488: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x618488: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x61848c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61848c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6184b4, size: 0x11c
    // 0x6184b4: EnterFrame
    //     0x6184b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6184b8: mov             fp, SP
    // 0x6184bc: AllocStack(0x10)
    //     0x6184bc: sub             SP, SP, #0x10
    // 0x6184c0: CheckStackOverflow
    //     0x6184c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6184c4: cmp             SP, x16
    //     0x6184c8: b.ls            #0x6185c4
    // 0x6184cc: ldr             x0, [fp, #0x10]
    // 0x6184d0: LoadField: r1 = r0->field_f
    //     0x6184d0: ldur            w1, [x0, #0xf]
    // 0x6184d4: DecompressPointer r1
    //     0x6184d4: add             x1, x1, HEAP, lsl #32
    // 0x6184d8: cmp             w1, NULL
    // 0x6184dc: b.eq            #0x6185cc
    // 0x6184e0: SaveReg r1
    //     0x6184e0: str             x1, [SP, #-8]!
    // 0x6184e4: r0 = getNotifier()
    //     0x6184e4: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x6184e8: add             SP, SP, #8
    // 0x6184ec: mov             x1, x0
    // 0x6184f0: ldr             x0, [fp, #0x10]
    // 0x6184f4: stur            x1, [fp, #-0x10]
    // 0x6184f8: LoadField: r2 = r0->field_17
    //     0x6184f8: ldur            w2, [x0, #0x17]
    // 0x6184fc: DecompressPointer r2
    //     0x6184fc: add             x2, x2, HEAP, lsl #32
    // 0x618500: stur            x2, [fp, #-8]
    // 0x618504: cmp             w1, w2
    // 0x618508: b.ne            #0x61851c
    // 0x61850c: r0 = Null
    //     0x61850c: mov             x0, NULL
    // 0x618510: LeaveFrame
    //     0x618510: mov             SP, fp
    //     0x618514: ldp             fp, lr, [SP], #0x10
    // 0x618518: ret
    //     0x618518: ret             
    // 0x61851c: cmp             w2, NULL
    // 0x618520: b.eq            #0x61855c
    // 0x618524: r1 = 1
    //     0x618524: mov             x1, #1
    // 0x618528: r0 = AllocateContext()
    //     0x618528: bl              #0xd68aa4  ; AllocateContextStub
    // 0x61852c: mov             x1, x0
    // 0x618530: ldr             x0, [fp, #0x10]
    // 0x618534: StoreField: r1->field_f = r0
    //     0x618534: stur            w0, [x1, #0xf]
    // 0x618538: mov             x2, x1
    // 0x61853c: r1 = Function '_updateTickers@156311458':.
    //     0x61853c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e1c0] AnonymousClosure: (0x6185d0), in [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::_updateTickers (0x618618)
    //     0x618540: ldr             x1, [x1, #0x1c0]
    // 0x618544: r0 = AllocateClosure()
    //     0x618544: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x618548: ldur            x16, [fp, #-8]
    // 0x61854c: stp             x0, x16, [SP, #-0x10]!
    // 0x618550: r0 = removeListener()
    //     0x618550: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x618554: add             SP, SP, #0x10
    // 0x618558: ldr             x0, [fp, #0x10]
    // 0x61855c: r1 = 1
    //     0x61855c: mov             x1, #1
    // 0x618560: r0 = AllocateContext()
    //     0x618560: bl              #0xd68aa4  ; AllocateContextStub
    // 0x618564: mov             x1, x0
    // 0x618568: ldr             x0, [fp, #0x10]
    // 0x61856c: StoreField: r1->field_f = r0
    //     0x61856c: stur            w0, [x1, #0xf]
    // 0x618570: mov             x2, x1
    // 0x618574: r1 = Function '_updateTickers@156311458':.
    //     0x618574: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e1c0] AnonymousClosure: (0x6185d0), in [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::_updateTickers (0x618618)
    //     0x618578: ldr             x1, [x1, #0x1c0]
    // 0x61857c: r0 = AllocateClosure()
    //     0x61857c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x618580: ldur            x16, [fp, #-0x10]
    // 0x618584: stp             x0, x16, [SP, #-0x10]!
    // 0x618588: r0 = addListener()
    //     0x618588: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x61858c: add             SP, SP, #0x10
    // 0x618590: ldur            x0, [fp, #-0x10]
    // 0x618594: ldr             x1, [fp, #0x10]
    // 0x618598: StoreField: r1->field_17 = r0
    //     0x618598: stur            w0, [x1, #0x17]
    //     0x61859c: ldurb           w16, [x1, #-1]
    //     0x6185a0: ldurb           w17, [x0, #-1]
    //     0x6185a4: and             x16, x17, x16, lsr #2
    //     0x6185a8: tst             x16, HEAP, lsr #32
    //     0x6185ac: b.eq            #0x6185b4
    //     0x6185b0: bl              #0xd6826c
    // 0x6185b4: r0 = Null
    //     0x6185b4: mov             x0, NULL
    // 0x6185b8: LeaveFrame
    //     0x6185b8: mov             SP, fp
    //     0x6185bc: ldp             fp, lr, [SP], #0x10
    // 0x6185c0: ret
    //     0x6185c0: ret             
    // 0x6185c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6185c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6185c8: b               #0x6184cc
    // 0x6185cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6185cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x6185d0, size: 0x48
    // 0x6185d0: EnterFrame
    //     0x6185d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6185d4: mov             fp, SP
    // 0x6185d8: ldr             x0, [fp, #0x10]
    // 0x6185dc: LoadField: r1 = r0->field_17
    //     0x6185dc: ldur            w1, [x0, #0x17]
    // 0x6185e0: DecompressPointer r1
    //     0x6185e0: add             x1, x1, HEAP, lsl #32
    // 0x6185e4: CheckStackOverflow
    //     0x6185e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6185e8: cmp             SP, x16
    //     0x6185ec: b.ls            #0x618610
    // 0x6185f0: LoadField: r0 = r1->field_f
    //     0x6185f0: ldur            w0, [x1, #0xf]
    // 0x6185f4: DecompressPointer r0
    //     0x6185f4: add             x0, x0, HEAP, lsl #32
    // 0x6185f8: SaveReg r0
    //     0x6185f8: str             x0, [SP, #-8]!
    // 0x6185fc: r0 = _updateTickers()
    //     0x6185fc: bl              #0x618618  ; [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::_updateTickers
    // 0x618600: add             SP, SP, #8
    // 0x618604: LeaveFrame
    //     0x618604: mov             SP, fp
    //     0x618608: ldp             fp, lr, [SP], #0x10
    // 0x61860c: ret
    //     0x61860c: ret             
    // 0x618610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618610: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618614: b               #0x6185f0
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x618618, size: 0x150
    // 0x618618: EnterFrame
    //     0x618618: stp             fp, lr, [SP, #-0x10]!
    //     0x61861c: mov             fp, SP
    // 0x618620: AllocStack(0x20)
    //     0x618620: sub             SP, SP, #0x20
    // 0x618624: CheckStackOverflow
    //     0x618624: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618628: cmp             SP, x16
    //     0x61862c: b.ls            #0x618754
    // 0x618630: ldr             x0, [fp, #0x10]
    // 0x618634: LoadField: r1 = r0->field_13
    //     0x618634: ldur            w1, [x0, #0x13]
    // 0x618638: DecompressPointer r1
    //     0x618638: add             x1, x1, HEAP, lsl #32
    // 0x61863c: cmp             w1, NULL
    // 0x618640: b.eq            #0x618744
    // 0x618644: LoadField: r2 = r0->field_17
    //     0x618644: ldur            w2, [x0, #0x17]
    // 0x618648: DecompressPointer r2
    //     0x618648: add             x2, x2, HEAP, lsl #32
    // 0x61864c: cmp             w2, NULL
    // 0x618650: b.eq            #0x61875c
    // 0x618654: LoadField: r0 = r2->field_27
    //     0x618654: ldur            w0, [x2, #0x27]
    // 0x618658: DecompressPointer r0
    //     0x618658: add             x0, x0, HEAP, lsl #32
    // 0x61865c: eor             x2, x0, #0x10
    // 0x618660: stur            x2, [fp, #-8]
    // 0x618664: SaveReg r1
    //     0x618664: str             x1, [SP, #-8]!
    // 0x618668: r0 = iterator()
    //     0x618668: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x61866c: add             SP, SP, #8
    // 0x618670: stur            x0, [fp, #-0x18]
    // 0x618674: LoadField: r2 = r0->field_7
    //     0x618674: ldur            w2, [x0, #7]
    // 0x618678: DecompressPointer r2
    //     0x618678: add             x2, x2, HEAP, lsl #32
    // 0x61867c: stur            x2, [fp, #-0x10]
    // 0x618680: ldur            x1, [fp, #-8]
    // 0x618684: CheckStackOverflow
    //     0x618684: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618688: cmp             SP, x16
    //     0x61868c: b.ls            #0x618760
    // 0x618690: SaveReg r0
    //     0x618690: str             x0, [SP, #-8]!
    // 0x618694: r0 = moveNext()
    //     0x618694: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x618698: add             SP, SP, #8
    // 0x61869c: tbnz            w0, #4, #0x618744
    // 0x6186a0: ldur            x3, [fp, #-0x18]
    // 0x6186a4: LoadField: r4 = r3->field_33
    //     0x6186a4: ldur            w4, [x3, #0x33]
    // 0x6186a8: DecompressPointer r4
    //     0x6186a8: add             x4, x4, HEAP, lsl #32
    // 0x6186ac: stur            x4, [fp, #-0x20]
    // 0x6186b0: cmp             w4, NULL
    // 0x6186b4: b.ne            #0x6186e8
    // 0x6186b8: mov             x0, x4
    // 0x6186bc: ldur            x2, [fp, #-0x10]
    // 0x6186c0: r1 = Null
    //     0x6186c0: mov             x1, NULL
    // 0x6186c4: cmp             w2, NULL
    // 0x6186c8: b.eq            #0x6186e8
    // 0x6186cc: LoadField: r4 = r2->field_17
    //     0x6186cc: ldur            w4, [x2, #0x17]
    // 0x6186d0: DecompressPointer r4
    //     0x6186d0: add             x4, x4, HEAP, lsl #32
    // 0x6186d4: r8 = X0
    //     0x6186d4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6186d8: LoadField: r9 = r4->field_7
    //     0x6186d8: ldur            x9, [x4, #7]
    // 0x6186dc: r3 = Null
    //     0x6186dc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e1b0] Null
    //     0x6186e0: ldr             x3, [x3, #0x1b0]
    // 0x6186e4: blr             x9
    // 0x6186e8: ldur            x1, [fp, #-8]
    // 0x6186ec: ldur            x0, [fp, #-0x20]
    // 0x6186f0: LoadField: r2 = r0->field_b
    //     0x6186f0: ldur            w2, [x0, #0xb]
    // 0x6186f4: DecompressPointer r2
    //     0x6186f4: add             x2, x2, HEAP, lsl #32
    // 0x6186f8: cmp             w1, w2
    // 0x6186fc: b.eq            #0x618738
    // 0x618700: StoreField: r0->field_b = r1
    //     0x618700: stur            w1, [x0, #0xb]
    // 0x618704: tbnz            w1, #4, #0x618718
    // 0x618708: SaveReg r0
    //     0x618708: str             x0, [SP, #-8]!
    // 0x61870c: r0 = unscheduleTick()
    //     0x61870c: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x618710: add             SP, SP, #8
    // 0x618714: b               #0x618738
    // 0x618718: SaveReg r0
    //     0x618718: str             x0, [SP, #-8]!
    // 0x61871c: r0 = shouldScheduleTick()
    //     0x61871c: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x618720: add             SP, SP, #8
    // 0x618724: tbnz            w0, #4, #0x618738
    // 0x618728: ldur            x16, [fp, #-0x20]
    // 0x61872c: SaveReg r16
    //     0x61872c: str             x16, [SP, #-8]!
    // 0x618730: r0 = scheduleTick()
    //     0x618730: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x618734: add             SP, SP, #8
    // 0x618738: ldur            x0, [fp, #-0x18]
    // 0x61873c: ldur            x2, [fp, #-0x10]
    // 0x618740: b               #0x618680
    // 0x618744: r0 = Null
    //     0x618744: mov             x0, NULL
    // 0x618748: LeaveFrame
    //     0x618748: mov             SP, fp
    //     0x61874c: ldp             fp, lr, [SP], #0x10
    // 0x618750: ret
    //     0x618750: ret             
    // 0x618754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618758: b               #0x618630
    // 0x61875c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61875c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x618760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618760: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618764: b               #0x618690
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f754, size: 0x4c
    // 0x81f754: EnterFrame
    //     0x81f754: stp             fp, lr, [SP, #-0x10]!
    //     0x81f758: mov             fp, SP
    // 0x81f75c: CheckStackOverflow
    //     0x81f75c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f760: cmp             SP, x16
    //     0x81f764: b.ls            #0x81f798
    // 0x81f768: ldr             x16, [fp, #0x10]
    // 0x81f76c: SaveReg r16
    //     0x81f76c: str             x16, [SP, #-8]!
    // 0x81f770: r0 = _updateTickerModeNotifier()
    //     0x81f770: bl              #0x6184b4  ; [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f774: add             SP, SP, #8
    // 0x81f778: ldr             x16, [fp, #0x10]
    // 0x81f77c: SaveReg r16
    //     0x81f77c: str             x16, [SP, #-8]!
    // 0x81f780: r0 = _updateTickers()
    //     0x81f780: bl              #0x618618  ; [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f784: add             SP, SP, #8
    // 0x81f788: r0 = Null
    //     0x81f788: mov             x0, NULL
    // 0x81f78c: LeaveFrame
    //     0x81f78c: mov             SP, fp
    //     0x81f790: ldp             fp, lr, [SP], #0x10
    // 0x81f794: ret
    //     0x81f794: ret             
    // 0x81f798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f798: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f79c: b               #0x81f768
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa526ec, size: 0x8c
    // 0xa526ec: EnterFrame
    //     0xa526ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa526f0: mov             fp, SP
    // 0xa526f4: AllocStack(0x8)
    //     0xa526f4: sub             SP, SP, #8
    // 0xa526f8: CheckStackOverflow
    //     0xa526f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa526fc: cmp             SP, x16
    //     0xa52700: b.ls            #0xa52770
    // 0xa52704: ldr             x0, [fp, #0x10]
    // 0xa52708: LoadField: r1 = r0->field_17
    //     0xa52708: ldur            w1, [x0, #0x17]
    // 0xa5270c: DecompressPointer r1
    //     0xa5270c: add             x1, x1, HEAP, lsl #32
    // 0xa52710: stur            x1, [fp, #-8]
    // 0xa52714: cmp             w1, NULL
    // 0xa52718: b.ne            #0xa52724
    // 0xa5271c: mov             x1, x0
    // 0xa52720: b               #0xa5275c
    // 0xa52724: r1 = 1
    //     0xa52724: mov             x1, #1
    // 0xa52728: r0 = AllocateContext()
    //     0xa52728: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa5272c: mov             x1, x0
    // 0xa52730: ldr             x0, [fp, #0x10]
    // 0xa52734: StoreField: r1->field_f = r0
    //     0xa52734: stur            w0, [x1, #0xf]
    // 0xa52738: mov             x2, x1
    // 0xa5273c: r1 = Function '_updateTickers@156311458':.
    //     0xa5273c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e1c0] AnonymousClosure: (0x6185d0), in [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::_updateTickers (0x618618)
    //     0xa52740: ldr             x1, [x1, #0x1c0]
    // 0xa52744: r0 = AllocateClosure()
    //     0xa52744: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52748: ldur            x16, [fp, #-8]
    // 0xa5274c: stp             x0, x16, [SP, #-0x10]!
    // 0xa52750: r0 = removeListener()
    //     0xa52750: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa52754: add             SP, SP, #0x10
    // 0xa52758: ldr             x1, [fp, #0x10]
    // 0xa5275c: StoreField: r1->field_17 = rNULL
    //     0xa5275c: stur            NULL, [x1, #0x17]
    // 0xa52760: r0 = Null
    //     0xa52760: mov             x0, NULL
    // 0xa52764: LeaveFrame
    //     0xa52764: mov             SP, fp
    //     0xa52768: ldp             fp, lr, [SP], #0x10
    // 0xa5276c: ret
    //     0xa5276c: ret             
    // 0xa52770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52770: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52774: b               #0xa52704
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa52778, size: 0x48
    // 0xa52778: EnterFrame
    //     0xa52778: stp             fp, lr, [SP, #-0x10]!
    //     0xa5277c: mov             fp, SP
    // 0xa52780: ldr             x0, [fp, #0x10]
    // 0xa52784: LoadField: r1 = r0->field_17
    //     0xa52784: ldur            w1, [x0, #0x17]
    // 0xa52788: DecompressPointer r1
    //     0xa52788: add             x1, x1, HEAP, lsl #32
    // 0xa5278c: CheckStackOverflow
    //     0xa5278c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52790: cmp             SP, x16
    //     0xa52794: b.ls            #0xa527b8
    // 0xa52798: LoadField: r0 = r1->field_f
    //     0xa52798: ldur            w0, [x1, #0xf]
    // 0xa5279c: DecompressPointer r0
    //     0xa5279c: add             x0, x0, HEAP, lsl #32
    // 0xa527a0: SaveReg r0
    //     0xa527a0: str             x0, [SP, #-8]!
    // 0xa527a4: r0 = dispose()
    //     0xa527a4: bl              #0xa526ec  ; [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::dispose
    // 0xa527a8: add             SP, SP, #8
    // 0xa527ac: LeaveFrame
    //     0xa527ac: mov             SP, fp
    //     0xa527b0: ldp             fp, lr, [SP], #0x10
    // 0xa527b4: ret
    //     0xa527b4: ret             
    // 0xa527b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa527b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa527bc: b               #0xa52798
  }
}

// class id: 3283, size: 0x38, field offset: 0x1c
class _FloatingActionButtonTransitionState extends __FloatingActionButtonTransitionState&State&TickerProviderStateMixin {

  late AnimationController _previousController; // offset: 0x1c
  late Animation<double> _previousScaleAnimation; // offset: 0x20
  late Animation<double> _previousRotationAnimation; // offset: 0x24
  late Animation<double> _currentScaleAnimation; // offset: 0x28
  late Animation<double> _currentRotationAnimation; // offset: 0x30
  static late final Animatable<double> _entranceTurnTween; // offset: 0xe18

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b93b8, size: 0xfc
    // 0x7b93b8: EnterFrame
    //     0x7b93b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b93bc: mov             fp, SP
    // 0x7b93c0: CheckStackOverflow
    //     0x7b93c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b93c4: cmp             SP, x16
    //     0x7b93c8: b.ls            #0x7b94a4
    // 0x7b93cc: ldr             x0, [fp, #0x10]
    // 0x7b93d0: r2 = Null
    //     0x7b93d0: mov             x2, NULL
    // 0x7b93d4: r1 = Null
    //     0x7b93d4: mov             x1, NULL
    // 0x7b93d8: r4 = 59
    //     0x7b93d8: mov             x4, #0x3b
    // 0x7b93dc: branchIfSmi(r0, 0x7b93e8)
    //     0x7b93dc: tbz             w0, #0, #0x7b93e8
    // 0x7b93e0: r4 = LoadClassIdInstr(r0)
    //     0x7b93e0: ldur            x4, [x0, #-1]
    //     0x7b93e4: ubfx            x4, x4, #0xc, #0x14
    // 0x7b93e8: r17 = 4125
    //     0x7b93e8: mov             x17, #0x101d
    // 0x7b93ec: cmp             x4, x17
    // 0x7b93f0: b.eq            #0x7b9408
    // 0x7b93f4: r8 = _FloatingActionButtonTransition
    //     0x7b93f4: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e028] Type: _FloatingActionButtonTransition
    //     0x7b93f8: ldr             x8, [x8, #0x28]
    // 0x7b93fc: r3 = Null
    //     0x7b93fc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e030] Null
    //     0x7b9400: ldr             x3, [x3, #0x30]
    // 0x7b9404: r0 = _FloatingActionButtonTransition()
    //     0x7b9404: bl              #0x618490  ; IsType__FloatingActionButtonTransition_Stub
    // 0x7b9408: ldr             x3, [fp, #0x18]
    // 0x7b940c: LoadField: r2 = r3->field_7
    //     0x7b940c: ldur            w2, [x3, #7]
    // 0x7b9410: DecompressPointer r2
    //     0x7b9410: add             x2, x2, HEAP, lsl #32
    // 0x7b9414: ldr             x0, [fp, #0x10]
    // 0x7b9418: r1 = Null
    //     0x7b9418: mov             x1, NULL
    // 0x7b941c: cmp             w2, NULL
    // 0x7b9420: b.eq            #0x7b9444
    // 0x7b9424: LoadField: r4 = r2->field_17
    //     0x7b9424: ldur            w4, [x2, #0x17]
    // 0x7b9428: DecompressPointer r4
    //     0x7b9428: add             x4, x4, HEAP, lsl #32
    // 0x7b942c: r8 = X0 bound StatefulWidget
    //     0x7b942c: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b9430: ldr             x8, [x8, #0x858]
    // 0x7b9434: LoadField: r9 = r4->field_7
    //     0x7b9434: ldur            x9, [x4, #7]
    // 0x7b9438: r3 = Null
    //     0x7b9438: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e040] Null
    //     0x7b943c: ldr             x3, [x3, #0x40]
    // 0x7b9440: blr             x9
    // 0x7b9444: ldr             x0, [fp, #0x18]
    // 0x7b9448: LoadField: r1 = r0->field_b
    //     0x7b9448: ldur            w1, [x0, #0xb]
    // 0x7b944c: DecompressPointer r1
    //     0x7b944c: add             x1, x1, HEAP, lsl #32
    // 0x7b9450: cmp             w1, NULL
    // 0x7b9454: b.eq            #0x7b94ac
    // 0x7b9458: ldr             x2, [fp, #0x10]
    // 0x7b945c: LoadField: r3 = r2->field_f
    //     0x7b945c: ldur            w3, [x2, #0xf]
    // 0x7b9460: DecompressPointer r3
    //     0x7b9460: add             x3, x3, HEAP, lsl #32
    // 0x7b9464: LoadField: r2 = r1->field_f
    //     0x7b9464: ldur            w2, [x1, #0xf]
    // 0x7b9468: DecompressPointer r2
    //     0x7b9468: add             x2, x2, HEAP, lsl #32
    // 0x7b946c: cmp             w3, w2
    // 0x7b9470: b.eq            #0x7b9480
    // 0x7b9474: SaveReg r0
    //     0x7b9474: str             x0, [SP, #-8]!
    // 0x7b9478: r0 = _updateAnimations()
    //     0x7b9478: bl              #0x7b94b4  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateAnimations
    // 0x7b947c: add             SP, SP, #8
    // 0x7b9480: ldr             x1, [fp, #0x18]
    // 0x7b9484: LoadField: r2 = r1->field_b
    //     0x7b9484: ldur            w2, [x1, #0xb]
    // 0x7b9488: DecompressPointer r2
    //     0x7b9488: add             x2, x2, HEAP, lsl #32
    // 0x7b948c: cmp             w2, NULL
    // 0x7b9490: b.eq            #0x7b94b0
    // 0x7b9494: r0 = Null
    //     0x7b9494: mov             x0, NULL
    // 0x7b9498: LeaveFrame
    //     0x7b9498: mov             SP, fp
    //     0x7b949c: ldp             fp, lr, [SP], #0x10
    // 0x7b94a0: ret
    //     0x7b94a0: ret             
    // 0x7b94a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b94a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b94a8: b               #0x7b93cc
    // 0x7b94ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b94ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b94b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b94b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateAnimations(/* No info */) {
    // ** addr: 0x7b94b4, size: 0x434
    // 0x7b94b4: EnterFrame
    //     0x7b94b4: stp             fp, lr, [SP, #-0x10]!
    //     0x7b94b8: mov             fp, SP
    // 0x7b94bc: AllocStack(0x38)
    //     0x7b94bc: sub             SP, SP, #0x38
    // 0x7b94c0: CheckStackOverflow
    //     0x7b94c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b94c4: cmp             SP, x16
    //     0x7b94c8: b.ls            #0x7b98c4
    // 0x7b94cc: ldr             x0, [fp, #0x10]
    // 0x7b94d0: LoadField: r2 = r0->field_1b
    //     0x7b94d0: ldur            w2, [x0, #0x1b]
    // 0x7b94d4: DecompressPointer r2
    //     0x7b94d4: add             x2, x2, HEAP, lsl #32
    // 0x7b94d8: r16 = Sentinel
    //     0x7b94d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b94dc: cmp             w2, w16
    // 0x7b94e0: b.eq            #0x7b98cc
    // 0x7b94e4: stur            x2, [fp, #-8]
    // 0x7b94e8: r1 = <double>
    //     0x7b94e8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b94ec: r0 = CurvedAnimation()
    //     0x7b94ec: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x7b94f0: stur            x0, [fp, #-0x10]
    // 0x7b94f4: r16 = Instance_Cubic
    //     0x7b94f4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27110] Obj!Cubic<double>@b4f431
    //     0x7b94f8: ldr             x16, [x16, #0x110]
    // 0x7b94fc: stp             x16, x0, [SP, #-0x10]!
    // 0x7b9500: ldur            x16, [fp, #-8]
    // 0x7b9504: SaveReg r16
    //     0x7b9504: str             x16, [SP, #-8]!
    // 0x7b9508: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7b9508: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7b950c: r0 = CurvedAnimation()
    //     0x7b950c: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x7b9510: add             SP, SP, #0x18
    // 0x7b9514: r1 = <double>
    //     0x7b9514: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b9518: r0 = Tween()
    //     0x7b9518: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b951c: mov             x2, x0
    // 0x7b9520: r0 = 1.000000
    //     0x7b9520: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7b9524: stur            x2, [fp, #-0x18]
    // 0x7b9528: StoreField: r2->field_b = r0
    //     0x7b9528: stur            w0, [x2, #0xb]
    // 0x7b952c: StoreField: r2->field_f = r0
    //     0x7b952c: stur            w0, [x2, #0xf]
    // 0x7b9530: ldr             x0, [fp, #0x10]
    // 0x7b9534: LoadField: r3 = r0->field_1b
    //     0x7b9534: ldur            w3, [x0, #0x1b]
    // 0x7b9538: DecompressPointer r3
    //     0x7b9538: add             x3, x3, HEAP, lsl #32
    // 0x7b953c: stur            x3, [fp, #-8]
    // 0x7b9540: r1 = <double>
    //     0x7b9540: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b9544: r0 = CurvedAnimation()
    //     0x7b9544: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x7b9548: stur            x0, [fp, #-0x20]
    // 0x7b954c: r16 = Instance_Cubic
    //     0x7b954c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27110] Obj!Cubic<double>@b4f431
    //     0x7b9550: ldr             x16, [x16, #0x110]
    // 0x7b9554: stp             x16, x0, [SP, #-0x10]!
    // 0x7b9558: ldur            x16, [fp, #-8]
    // 0x7b955c: SaveReg r16
    //     0x7b955c: str             x16, [SP, #-8]!
    // 0x7b9560: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7b9560: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7b9564: r0 = CurvedAnimation()
    //     0x7b9564: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x7b9568: add             SP, SP, #0x18
    // 0x7b956c: ldur            x16, [fp, #-0x18]
    // 0x7b9570: ldur            lr, [fp, #-0x20]
    // 0x7b9574: stp             lr, x16, [SP, #-0x10]!
    // 0x7b9578: r0 = animate()
    //     0x7b9578: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b957c: add             SP, SP, #0x10
    // 0x7b9580: mov             x2, x0
    // 0x7b9584: ldr             x0, [fp, #0x10]
    // 0x7b9588: stur            x2, [fp, #-0x18]
    // 0x7b958c: LoadField: r1 = r0->field_b
    //     0x7b958c: ldur            w1, [x0, #0xb]
    // 0x7b9590: DecompressPointer r1
    //     0x7b9590: add             x1, x1, HEAP, lsl #32
    // 0x7b9594: cmp             w1, NULL
    // 0x7b9598: b.eq            #0x7b98d8
    // 0x7b959c: LoadField: r3 = r1->field_1b
    //     0x7b959c: ldur            w3, [x1, #0x1b]
    // 0x7b95a0: DecompressPointer r3
    //     0x7b95a0: add             x3, x3, HEAP, lsl #32
    // 0x7b95a4: stur            x3, [fp, #-8]
    // 0x7b95a8: r1 = <double>
    //     0x7b95a8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b95ac: r0 = CurvedAnimation()
    //     0x7b95ac: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x7b95b0: stur            x0, [fp, #-0x20]
    // 0x7b95b4: r16 = Instance_Cubic
    //     0x7b95b4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27110] Obj!Cubic<double>@b4f431
    //     0x7b95b8: ldr             x16, [x16, #0x110]
    // 0x7b95bc: stp             x16, x0, [SP, #-0x10]!
    // 0x7b95c0: ldur            x16, [fp, #-8]
    // 0x7b95c4: SaveReg r16
    //     0x7b95c4: str             x16, [SP, #-8]!
    // 0x7b95c8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7b95c8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7b95cc: r0 = CurvedAnimation()
    //     0x7b95cc: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x7b95d0: add             SP, SP, #0x18
    // 0x7b95d4: ldr             x0, [fp, #0x10]
    // 0x7b95d8: LoadField: r1 = r0->field_b
    //     0x7b95d8: ldur            w1, [x0, #0xb]
    // 0x7b95dc: DecompressPointer r1
    //     0x7b95dc: add             x1, x1, HEAP, lsl #32
    // 0x7b95e0: cmp             w1, NULL
    // 0x7b95e4: b.eq            #0x7b98dc
    // 0x7b95e8: LoadField: r2 = r1->field_1b
    //     0x7b95e8: ldur            w2, [x1, #0x1b]
    // 0x7b95ec: DecompressPointer r2
    //     0x7b95ec: add             x2, x2, HEAP, lsl #32
    // 0x7b95f0: stur            x2, [fp, #-8]
    // 0x7b95f4: r0 = InitLateStaticField(0xe18) // [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_entranceTurnTween
    //     0x7b95f4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b95f8: ldr             x0, [x0, #0x1c30]
    //     0x7b95fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b9600: cmp             w0, w16
    //     0x7b9604: b.ne            #0x7b9614
    //     0x7b9608: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e050] Field <_FloatingActionButtonTransitionState@801420462._entranceTurnTween@801420462>: static late final (offset: 0xe18)
    //     0x7b960c: ldr             x2, [x2, #0x50]
    //     0x7b9610: bl              #0xd67cdc
    // 0x7b9614: ldur            x16, [fp, #-8]
    // 0x7b9618: stp             x16, x0, [SP, #-0x10]!
    // 0x7b961c: r0 = animate()
    //     0x7b961c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b9620: add             SP, SP, #0x10
    // 0x7b9624: mov             x1, x0
    // 0x7b9628: ldr             x0, [fp, #0x10]
    // 0x7b962c: stur            x1, [fp, #-8]
    // 0x7b9630: LoadField: r2 = r0->field_b
    //     0x7b9630: ldur            w2, [x0, #0xb]
    // 0x7b9634: DecompressPointer r2
    //     0x7b9634: add             x2, x2, HEAP, lsl #32
    // 0x7b9638: cmp             w2, NULL
    // 0x7b963c: b.eq            #0x7b98e0
    // 0x7b9640: LoadField: r3 = r2->field_f
    //     0x7b9640: ldur            w3, [x2, #0xf]
    // 0x7b9644: DecompressPointer r3
    //     0x7b9644: add             x3, x3, HEAP, lsl #32
    // 0x7b9648: r16 = Instance__ScalingFabMotionAnimator
    //     0x7b9648: add             x16, PP, #0x21, lsl #12  ; [pp+0x21dd0] Obj!_ScalingFabMotionAnimator@b38581
    //     0x7b964c: ldr             x16, [x16, #0xdd0]
    // 0x7b9650: stp             x3, x16, [SP, #-0x10]!
    // 0x7b9654: r0 = getScaleAnimation()
    //     0x7b9654: bl              #0x7ba054  ; [package:flutter/src/material/floating_action_button_location.dart] _ScalingFabMotionAnimator::getScaleAnimation
    // 0x7b9658: add             SP, SP, #0x10
    // 0x7b965c: mov             x1, x0
    // 0x7b9660: ldr             x0, [fp, #0x10]
    // 0x7b9664: stur            x1, [fp, #-0x28]
    // 0x7b9668: LoadField: r2 = r0->field_b
    //     0x7b9668: ldur            w2, [x0, #0xb]
    // 0x7b966c: DecompressPointer r2
    //     0x7b966c: add             x2, x2, HEAP, lsl #32
    // 0x7b9670: cmp             w2, NULL
    // 0x7b9674: b.eq            #0x7b98e4
    // 0x7b9678: LoadField: r3 = r2->field_f
    //     0x7b9678: ldur            w3, [x2, #0xf]
    // 0x7b967c: DecompressPointer r3
    //     0x7b967c: add             x3, x3, HEAP, lsl #32
    // 0x7b9680: r16 = Instance__ScalingFabMotionAnimator
    //     0x7b9680: add             x16, PP, #0x21, lsl #12  ; [pp+0x21dd0] Obj!_ScalingFabMotionAnimator@b38581
    //     0x7b9684: ldr             x16, [x16, #0xdd0]
    // 0x7b9688: stp             x3, x16, [SP, #-0x10]!
    // 0x7b968c: r0 = getRotationAnimation()
    //     0x7b968c: bl              #0x7b9e78  ; [package:flutter/src/material/floating_action_button_location.dart] _ScalingFabMotionAnimator::getRotationAnimation
    // 0x7b9690: add             SP, SP, #0x10
    // 0x7b9694: r1 = <double>
    //     0x7b9694: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b9698: stur            x0, [fp, #-0x30]
    // 0x7b969c: r0 = AnimationMin()
    //     0x7b969c: bl              #0x7b9e6c  ; AllocateAnimationMinStub -> AnimationMin<X0 bound num> (size=0x2c)
    // 0x7b96a0: stur            x0, [fp, #-0x38]
    // 0x7b96a4: ldur            x16, [fp, #-0x28]
    // 0x7b96a8: stp             x16, x0, [SP, #-0x10]!
    // 0x7b96ac: ldur            x16, [fp, #-0x10]
    // 0x7b96b0: SaveReg r16
    //     0x7b96b0: str             x16, [SP, #-8]!
    // 0x7b96b4: r0 = AnimationMin()
    //     0x7b96b4: bl              #0x7b9cb8  ; [package:flutter/src/animation/animations.dart] AnimationMin::AnimationMin
    // 0x7b96b8: add             SP, SP, #0x18
    // 0x7b96bc: ldur            x0, [fp, #-0x38]
    // 0x7b96c0: ldr             x2, [fp, #0x10]
    // 0x7b96c4: StoreField: r2->field_1f = r0
    //     0x7b96c4: stur            w0, [x2, #0x1f]
    //     0x7b96c8: ldurb           w16, [x2, #-1]
    //     0x7b96cc: ldurb           w17, [x0, #-1]
    //     0x7b96d0: and             x16, x17, x16, lsr #2
    //     0x7b96d4: tst             x16, HEAP, lsr #32
    //     0x7b96d8: b.eq            #0x7b96e0
    //     0x7b96dc: bl              #0xd6828c
    // 0x7b96e0: r1 = <double>
    //     0x7b96e0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b96e4: r0 = AnimationMin()
    //     0x7b96e4: bl              #0x7b9e6c  ; AllocateAnimationMinStub -> AnimationMin<X0 bound num> (size=0x2c)
    // 0x7b96e8: stur            x0, [fp, #-0x10]
    // 0x7b96ec: ldur            x16, [fp, #-0x28]
    // 0x7b96f0: stp             x16, x0, [SP, #-0x10]!
    // 0x7b96f4: ldur            x16, [fp, #-0x20]
    // 0x7b96f8: SaveReg r16
    //     0x7b96f8: str             x16, [SP, #-8]!
    // 0x7b96fc: r0 = AnimationMin()
    //     0x7b96fc: bl              #0x7b9cb8  ; [package:flutter/src/animation/animations.dart] AnimationMin::AnimationMin
    // 0x7b9700: add             SP, SP, #0x18
    // 0x7b9704: ldur            x0, [fp, #-0x10]
    // 0x7b9708: ldr             x2, [fp, #0x10]
    // 0x7b970c: StoreField: r2->field_27 = r0
    //     0x7b970c: stur            w0, [x2, #0x27]
    //     0x7b9710: ldurb           w16, [x2, #-1]
    //     0x7b9714: ldurb           w17, [x0, #-1]
    //     0x7b9718: and             x16, x17, x16, lsr #2
    //     0x7b971c: tst             x16, HEAP, lsr #32
    //     0x7b9720: b.eq            #0x7b9728
    //     0x7b9724: bl              #0xd6828c
    // 0x7b9728: r1 = <double>
    //     0x7b9728: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b972c: r0 = CurveTween()
    //     0x7b972c: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7b9730: mov             x3, x0
    // 0x7b9734: r0 = Instance_Interval
    //     0x7b9734: add             x0, PP, #0x23, lsl #12  ; [pp+0x238f0] Obj!Interval<double>@b4f781
    //     0x7b9738: ldr             x0, [x0, #0x8f0]
    // 0x7b973c: stur            x3, [fp, #-0x20]
    // 0x7b9740: StoreField: r3->field_b = r0
    //     0x7b9740: stur            w0, [x3, #0xb]
    // 0x7b9744: ldur            x0, [fp, #-0x10]
    // 0x7b9748: r2 = Null
    //     0x7b9748: mov             x2, NULL
    // 0x7b974c: r1 = Null
    //     0x7b974c: mov             x1, NULL
    // 0x7b9750: r8 = Animation<double>
    //     0x7b9750: add             x8, PP, #0x2a, lsl #12  ; [pp+0x2aab0] Type: Animation<double>
    //     0x7b9754: ldr             x8, [x8, #0xab0]
    // 0x7b9758: r3 = Null
    //     0x7b9758: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e058] Null
    //     0x7b975c: ldr             x3, [x3, #0x58]
    // 0x7b9760: r0 = Animation<double>()
    //     0x7b9760: bl              #0x5912f0  ; IsType_Animation<double>_Stub
    // 0x7b9764: ldur            x16, [fp, #-0x20]
    // 0x7b9768: ldur            lr, [fp, #-0x10]
    // 0x7b976c: stp             lr, x16, [SP, #-0x10]!
    // 0x7b9770: r0 = animate()
    //     0x7b9770: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b9774: add             SP, SP, #0x10
    // 0x7b9778: ldr             x2, [fp, #0x10]
    // 0x7b977c: StoreField: r2->field_2b = r0
    //     0x7b977c: stur            w0, [x2, #0x2b]
    //     0x7b9780: ldurb           w16, [x2, #-1]
    //     0x7b9784: ldurb           w17, [x0, #-1]
    //     0x7b9788: and             x16, x17, x16, lsr #2
    //     0x7b978c: tst             x16, HEAP, lsr #32
    //     0x7b9790: b.eq            #0x7b9798
    //     0x7b9794: bl              #0xd6828c
    // 0x7b9798: r1 = <double>
    //     0x7b9798: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b979c: r0 = TrainHoppingAnimation()
    //     0x7b979c: bl              #0x7b9cac  ; AllocateTrainHoppingAnimationStub -> TrainHoppingAnimation (size=0x2c)
    // 0x7b97a0: stur            x0, [fp, #-0x10]
    // 0x7b97a4: ldur            x16, [fp, #-0x18]
    // 0x7b97a8: stp             x16, x0, [SP, #-0x10]!
    // 0x7b97ac: ldur            x16, [fp, #-0x30]
    // 0x7b97b0: SaveReg r16
    //     0x7b97b0: str             x16, [SP, #-8]!
    // 0x7b97b4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7b97b4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7b97b8: r0 = TrainHoppingAnimation()
    //     0x7b97b8: bl              #0x7b98e8  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::TrainHoppingAnimation
    // 0x7b97bc: add             SP, SP, #0x18
    // 0x7b97c0: ldur            x0, [fp, #-0x10]
    // 0x7b97c4: ldr             x2, [fp, #0x10]
    // 0x7b97c8: StoreField: r2->field_23 = r0
    //     0x7b97c8: stur            w0, [x2, #0x23]
    //     0x7b97cc: ldurb           w16, [x2, #-1]
    //     0x7b97d0: ldurb           w17, [x0, #-1]
    //     0x7b97d4: and             x16, x17, x16, lsr #2
    //     0x7b97d8: tst             x16, HEAP, lsr #32
    //     0x7b97dc: b.eq            #0x7b97e4
    //     0x7b97e0: bl              #0xd6828c
    // 0x7b97e4: r1 = <double>
    //     0x7b97e4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b97e8: r0 = TrainHoppingAnimation()
    //     0x7b97e8: bl              #0x7b9cac  ; AllocateTrainHoppingAnimationStub -> TrainHoppingAnimation (size=0x2c)
    // 0x7b97ec: stur            x0, [fp, #-0x10]
    // 0x7b97f0: ldur            x16, [fp, #-8]
    // 0x7b97f4: stp             x16, x0, [SP, #-0x10]!
    // 0x7b97f8: ldur            x16, [fp, #-0x30]
    // 0x7b97fc: SaveReg r16
    //     0x7b97fc: str             x16, [SP, #-8]!
    // 0x7b9800: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7b9800: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7b9804: r0 = TrainHoppingAnimation()
    //     0x7b9804: bl              #0x7b98e8  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::TrainHoppingAnimation
    // 0x7b9808: add             SP, SP, #0x18
    // 0x7b980c: ldur            x0, [fp, #-0x10]
    // 0x7b9810: ldr             x1, [fp, #0x10]
    // 0x7b9814: StoreField: r1->field_2f = r0
    //     0x7b9814: stur            w0, [x1, #0x2f]
    //     0x7b9818: ldurb           w16, [x1, #-1]
    //     0x7b981c: ldurb           w17, [x0, #-1]
    //     0x7b9820: and             x16, x17, x16, lsr #2
    //     0x7b9824: tst             x16, HEAP, lsr #32
    //     0x7b9828: b.eq            #0x7b9830
    //     0x7b982c: bl              #0xd6826c
    // 0x7b9830: LoadField: r0 = r1->field_27
    //     0x7b9830: ldur            w0, [x1, #0x27]
    // 0x7b9834: DecompressPointer r0
    //     0x7b9834: add             x0, x0, HEAP, lsl #32
    // 0x7b9838: stur            x0, [fp, #-8]
    // 0x7b983c: r1 = 1
    //     0x7b983c: mov             x1, #1
    // 0x7b9840: r0 = AllocateContext()
    //     0x7b9840: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b9844: mov             x1, x0
    // 0x7b9848: ldr             x0, [fp, #0x10]
    // 0x7b984c: StoreField: r1->field_f = r0
    //     0x7b984c: stur            w0, [x1, #0xf]
    // 0x7b9850: mov             x2, x1
    // 0x7b9854: r1 = Function '_onProgressChanged@801420462':.
    //     0x7b9854: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e068] AnonymousClosure: (0x7ba1f8), in [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_onProgressChanged (0x7ba240)
    //     0x7b9858: ldr             x1, [x1, #0x68]
    // 0x7b985c: r0 = AllocateClosure()
    //     0x7b985c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b9860: ldur            x16, [fp, #-8]
    // 0x7b9864: stp             x0, x16, [SP, #-0x10]!
    // 0x7b9868: r0 = addListener()
    //     0x7b9868: bl              #0x6e935c  ; [package:flutter/src/animation/animations.dart] _CompoundAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::addListener
    // 0x7b986c: add             SP, SP, #0x10
    // 0x7b9870: ldr             x0, [fp, #0x10]
    // 0x7b9874: LoadField: r1 = r0->field_1f
    //     0x7b9874: ldur            w1, [x0, #0x1f]
    // 0x7b9878: DecompressPointer r1
    //     0x7b9878: add             x1, x1, HEAP, lsl #32
    // 0x7b987c: stur            x1, [fp, #-8]
    // 0x7b9880: r1 = 1
    //     0x7b9880: mov             x1, #1
    // 0x7b9884: r0 = AllocateContext()
    //     0x7b9884: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b9888: mov             x1, x0
    // 0x7b988c: ldr             x0, [fp, #0x10]
    // 0x7b9890: StoreField: r1->field_f = r0
    //     0x7b9890: stur            w0, [x1, #0xf]
    // 0x7b9894: mov             x2, x1
    // 0x7b9898: r1 = Function '_onProgressChanged@801420462':.
    //     0x7b9898: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e068] AnonymousClosure: (0x7ba1f8), in [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_onProgressChanged (0x7ba240)
    //     0x7b989c: ldr             x1, [x1, #0x68]
    // 0x7b98a0: r0 = AllocateClosure()
    //     0x7b98a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b98a4: ldur            x16, [fp, #-8]
    // 0x7b98a8: stp             x0, x16, [SP, #-0x10]!
    // 0x7b98ac: r0 = addListener()
    //     0x7b98ac: bl              #0x6e935c  ; [package:flutter/src/animation/animations.dart] _CompoundAnimation&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::addListener
    // 0x7b98b0: add             SP, SP, #0x10
    // 0x7b98b4: r0 = Null
    //     0x7b98b4: mov             x0, NULL
    // 0x7b98b8: LeaveFrame
    //     0x7b98b8: mov             SP, fp
    //     0x7b98bc: ldp             fp, lr, [SP], #0x10
    // 0x7b98c0: ret
    //     0x7b98c0: ret             
    // 0x7b98c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b98c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b98c8: b               #0x7b94cc
    // 0x7b98cc: r9 = _previousController
    //     0x7b98cc: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e000] Field <_FloatingActionButtonTransitionState@801420462._previousController@801420462>: late (offset: 0x1c)
    //     0x7b98d0: ldr             x9, [x9]
    // 0x7b98d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b98d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b98d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b98d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b98dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b98dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b98e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b98e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b98e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b98e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onProgressChanged(dynamic) {
    // ** addr: 0x7ba1f8, size: 0x48
    // 0x7ba1f8: EnterFrame
    //     0x7ba1f8: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba1fc: mov             fp, SP
    // 0x7ba200: ldr             x0, [fp, #0x10]
    // 0x7ba204: LoadField: r1 = r0->field_17
    //     0x7ba204: ldur            w1, [x0, #0x17]
    // 0x7ba208: DecompressPointer r1
    //     0x7ba208: add             x1, x1, HEAP, lsl #32
    // 0x7ba20c: CheckStackOverflow
    //     0x7ba20c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba210: cmp             SP, x16
    //     0x7ba214: b.ls            #0x7ba238
    // 0x7ba218: LoadField: r0 = r1->field_f
    //     0x7ba218: ldur            w0, [x1, #0xf]
    // 0x7ba21c: DecompressPointer r0
    //     0x7ba21c: add             x0, x0, HEAP, lsl #32
    // 0x7ba220: SaveReg r0
    //     0x7ba220: str             x0, [SP, #-8]!
    // 0x7ba224: r0 = _onProgressChanged()
    //     0x7ba224: bl              #0x7ba240  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_onProgressChanged
    // 0x7ba228: add             SP, SP, #8
    // 0x7ba22c: LeaveFrame
    //     0x7ba22c: mov             SP, fp
    //     0x7ba230: ldp             fp, lr, [SP], #0x10
    // 0x7ba234: ret
    //     0x7ba234: ret             
    // 0x7ba238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ba238: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ba23c: b               #0x7ba218
  }
  _ _onProgressChanged(/* No info */) {
    // ** addr: 0x7ba240, size: 0x118
    // 0x7ba240: EnterFrame
    //     0x7ba240: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba244: mov             fp, SP
    // 0x7ba248: AllocStack(0x8)
    //     0x7ba248: sub             SP, SP, #8
    // 0x7ba24c: CheckStackOverflow
    //     0x7ba24c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba250: cmp             SP, x16
    //     0x7ba254: b.ls            #0x7ba338
    // 0x7ba258: ldr             x0, [fp, #0x10]
    // 0x7ba25c: LoadField: r1 = r0->field_1f
    //     0x7ba25c: ldur            w1, [x0, #0x1f]
    // 0x7ba260: DecompressPointer r1
    //     0x7ba260: add             x1, x1, HEAP, lsl #32
    // 0x7ba264: r16 = Sentinel
    //     0x7ba264: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7ba268: cmp             w1, w16
    // 0x7ba26c: b.eq            #0x7ba340
    // 0x7ba270: SaveReg r1
    //     0x7ba270: str             x1, [SP, #-8]!
    // 0x7ba274: r0 = value()
    //     0x7ba274: bl              #0xc24e50  ; [package:flutter/src/animation/animations.dart] AnimationMin::value
    // 0x7ba278: add             SP, SP, #8
    // 0x7ba27c: mov             x1, x0
    // 0x7ba280: ldr             x0, [fp, #0x10]
    // 0x7ba284: stur            x1, [fp, #-8]
    // 0x7ba288: LoadField: r2 = r0->field_27
    //     0x7ba288: ldur            w2, [x0, #0x27]
    // 0x7ba28c: DecompressPointer r2
    //     0x7ba28c: add             x2, x2, HEAP, lsl #32
    // 0x7ba290: r16 = Sentinel
    //     0x7ba290: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7ba294: cmp             w2, w16
    // 0x7ba298: b.eq            #0x7ba34c
    // 0x7ba29c: SaveReg r2
    //     0x7ba29c: str             x2, [SP, #-8]!
    // 0x7ba2a0: r0 = value()
    //     0x7ba2a0: bl              #0xc24e50  ; [package:flutter/src/animation/animations.dart] AnimationMin::value
    // 0x7ba2a4: add             SP, SP, #8
    // 0x7ba2a8: mov             x1, x0
    // 0x7ba2ac: ldur            x0, [fp, #-8]
    // 0x7ba2b0: LoadField: d0 = r0->field_7
    //     0x7ba2b0: ldur            d0, [x0, #7]
    // 0x7ba2b4: LoadField: d1 = r1->field_7
    //     0x7ba2b4: ldur            d1, [x1, #7]
    // 0x7ba2b8: fcmp            d0, d1
    // 0x7ba2bc: b.vs            #0x7ba2cc
    // 0x7ba2c0: b.le            #0x7ba2cc
    // 0x7ba2c4: LoadField: d0 = r0->field_7
    //     0x7ba2c4: ldur            d0, [x0, #7]
    // 0x7ba2c8: b               #0x7ba314
    // 0x7ba2cc: fcmp            d0, d1
    // 0x7ba2d0: b.vs            #0x7ba2e0
    // 0x7ba2d4: b.ge            #0x7ba2e0
    // 0x7ba2d8: LoadField: d0 = r1->field_7
    //     0x7ba2d8: ldur            d0, [x1, #7]
    // 0x7ba2dc: b               #0x7ba314
    // 0x7ba2e0: d2 = 0.000000
    //     0x7ba2e0: eor             v2.16b, v2.16b, v2.16b
    // 0x7ba2e4: fcmp            d0, d2
    // 0x7ba2e8: b.vs            #0x7ba2fc
    // 0x7ba2ec: b.ne            #0x7ba2fc
    // 0x7ba2f0: fadd            d2, d0, d1
    // 0x7ba2f4: mov             v0.16b, v2.16b
    // 0x7ba2f8: b               #0x7ba314
    // 0x7ba2fc: LoadField: d0 = r1->field_7
    //     0x7ba2fc: ldur            d0, [x1, #7]
    // 0x7ba300: fcmp            d0, d0
    // 0x7ba304: b.vc            #0x7ba310
    // 0x7ba308: LoadField: d0 = r1->field_7
    //     0x7ba308: ldur            d0, [x1, #7]
    // 0x7ba30c: b               #0x7ba314
    // 0x7ba310: LoadField: d0 = r0->field_7
    //     0x7ba310: ldur            d0, [x0, #7]
    // 0x7ba314: ldr             x16, [fp, #0x10]
    // 0x7ba318: SaveReg r16
    //     0x7ba318: str             x16, [SP, #-8]!
    // 0x7ba31c: SaveReg d0
    //     0x7ba31c: str             d0, [SP, #-8]!
    // 0x7ba320: r0 = _updateGeometryScale()
    //     0x7ba320: bl              #0x7ba358  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateGeometryScale
    // 0x7ba324: add             SP, SP, #0x10
    // 0x7ba328: r0 = Null
    //     0x7ba328: mov             x0, NULL
    // 0x7ba32c: LeaveFrame
    //     0x7ba32c: mov             SP, fp
    //     0x7ba330: ldp             fp, lr, [SP], #0x10
    // 0x7ba334: ret
    //     0x7ba334: ret             
    // 0x7ba338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ba338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ba33c: b               #0x7ba258
    // 0x7ba340: r9 = _previousScaleAnimation
    //     0x7ba340: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e008] Field <_FloatingActionButtonTransitionState@801420462._previousScaleAnimation@801420462>: late (offset: 0x20)
    //     0x7ba344: ldr             x9, [x9, #8]
    // 0x7ba348: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ba348: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7ba34c: r9 = _currentScaleAnimation
    //     0x7ba34c: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e018] Field <_FloatingActionButtonTransitionState@801420462._currentScaleAnimation@801420462>: late (offset: 0x28)
    //     0x7ba350: ldr             x9, [x9, #0x18]
    // 0x7ba354: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ba354: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateGeometryScale(/* No info */) {
    // ** addr: 0x7ba358, size: 0xa8
    // 0x7ba358: EnterFrame
    //     0x7ba358: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba35c: mov             fp, SP
    // 0x7ba360: CheckStackOverflow
    //     0x7ba360: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba364: cmp             SP, x16
    //     0x7ba368: b.ls            #0x7ba3d8
    // 0x7ba36c: ldr             x0, [fp, #0x18]
    // 0x7ba370: LoadField: r1 = r0->field_b
    //     0x7ba370: ldur            w1, [x0, #0xb]
    // 0x7ba374: DecompressPointer r1
    //     0x7ba374: add             x1, x1, HEAP, lsl #32
    // 0x7ba378: cmp             w1, NULL
    // 0x7ba37c: b.eq            #0x7ba3e0
    // 0x7ba380: LoadField: r0 = r1->field_17
    //     0x7ba380: ldur            w0, [x1, #0x17]
    // 0x7ba384: DecompressPointer r0
    //     0x7ba384: add             x0, x0, HEAP, lsl #32
    // 0x7ba388: ldr             d0, [fp, #0x10]
    // 0x7ba38c: r1 = inline_Allocate_Double()
    //     0x7ba38c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x7ba390: add             x1, x1, #0x10
    //     0x7ba394: cmp             x2, x1
    //     0x7ba398: b.ls            #0x7ba3e4
    //     0x7ba39c: str             x1, [THR, #0x60]  ; THR::top
    //     0x7ba3a0: sub             x1, x1, #0xf
    //     0x7ba3a4: mov             x2, #0xd108
    //     0x7ba3a8: movk            x2, #3, lsl #16
    //     0x7ba3ac: stur            x2, [x1, #-1]
    // 0x7ba3b0: StoreField: r1->field_7 = d0
    //     0x7ba3b0: stur            d0, [x1, #7]
    // 0x7ba3b4: stp             x1, x0, [SP, #-0x10]!
    // 0x7ba3b8: r4 = const [0, 0x2, 0x2, 0x1, floatingActionButtonScale, 0x1, null]
    //     0x7ba3b8: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e070] List(7) [0, 0x2, 0x2, 0x1, "floatingActionButtonScale", 0x1, Null]
    //     0x7ba3bc: ldr             x4, [x4, #0x70]
    // 0x7ba3c0: r0 = _updateWith()
    //     0x7ba3c0: bl              #0x7ba400  ; [package:flutter/src/material/scaffold.dart] _ScaffoldGeometryNotifier::_updateWith
    // 0x7ba3c4: add             SP, SP, #0x10
    // 0x7ba3c8: r0 = Null
    //     0x7ba3c8: mov             x0, NULL
    // 0x7ba3cc: LeaveFrame
    //     0x7ba3cc: mov             SP, fp
    //     0x7ba3d0: ldp             fp, lr, [SP], #0x10
    // 0x7ba3d4: ret
    //     0x7ba3d4: ret             
    // 0x7ba3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ba3d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ba3dc: b               #0x7ba36c
    // 0x7ba3e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ba3e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7ba3e4: SaveReg d0
    //     0x7ba3e4: str             q0, [SP, #-0x10]!
    // 0x7ba3e8: SaveReg r0
    //     0x7ba3e8: str             x0, [SP, #-8]!
    // 0x7ba3ec: r0 = AllocateDouble()
    //     0x7ba3ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7ba3f0: mov             x1, x0
    // 0x7ba3f4: RestoreReg r0
    //     0x7ba3f4: ldr             x0, [SP], #8
    // 0x7ba3f8: RestoreReg d0
    //     0x7ba3f8: ldr             q0, [SP], #0x10
    // 0x7ba3fc: b               #0x7ba3b0
  }
  static Animatable<double> _entranceTurnTween() {
    // ** addr: 0x7ba624, size: 0x78
    // 0x7ba624: EnterFrame
    //     0x7ba624: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba628: mov             fp, SP
    // 0x7ba62c: AllocStack(0x8)
    //     0x7ba62c: sub             SP, SP, #8
    // 0x7ba630: CheckStackOverflow
    //     0x7ba630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba634: cmp             SP, x16
    //     0x7ba638: b.ls            #0x7ba694
    // 0x7ba63c: r1 = <double>
    //     0x7ba63c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba640: r0 = Tween()
    //     0x7ba640: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7ba644: mov             x2, x0
    // 0x7ba648: r0 = 0.875000
    //     0x7ba648: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e0f8] 0.875
    //     0x7ba64c: ldr             x0, [x0, #0xf8]
    // 0x7ba650: stur            x2, [fp, #-8]
    // 0x7ba654: StoreField: r2->field_b = r0
    //     0x7ba654: stur            w0, [x2, #0xb]
    // 0x7ba658: r0 = 1.000000
    //     0x7ba658: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7ba65c: StoreField: r2->field_f = r0
    //     0x7ba65c: stur            w0, [x2, #0xf]
    // 0x7ba660: r1 = <double>
    //     0x7ba660: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba664: r0 = CurveTween()
    //     0x7ba664: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7ba668: mov             x1, x0
    // 0x7ba66c: r0 = Instance_Cubic
    //     0x7ba66c: add             x0, PP, #0x27, lsl #12  ; [pp+0x27110] Obj!Cubic<double>@b4f431
    //     0x7ba670: ldr             x0, [x0, #0x110]
    // 0x7ba674: StoreField: r1->field_b = r0
    //     0x7ba674: stur            w0, [x1, #0xb]
    // 0x7ba678: ldur            x16, [fp, #-8]
    // 0x7ba67c: stp             x1, x16, [SP, #-0x10]!
    // 0x7ba680: r0 = chain()
    //     0x7ba680: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7ba684: add             SP, SP, #0x10
    // 0x7ba688: LeaveFrame
    //     0x7ba688: mov             SP, fp
    //     0x7ba68c: ldp             fp, lr, [SP], #0x10
    // 0x7ba690: ret
    //     0x7ba690: ret             
    // 0x7ba694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ba694: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ba698: b               #0x7ba63c
  }
  _ build(/* No info */) {
    // ** addr: 0x864568, size: 0x32c
    // 0x864568: EnterFrame
    //     0x864568: stp             fp, lr, [SP, #-0x10]!
    //     0x86456c: mov             fp, SP
    // 0x864570: AllocStack(0x28)
    //     0x864570: sub             SP, SP, #0x28
    // 0x864574: CheckStackOverflow
    //     0x864574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x864578: cmp             SP, x16
    //     0x86457c: b.ls            #0x864838
    // 0x864580: r16 = <Widget>
    //     0x864580: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x864584: ldr             x16, [x16, #0xea8]
    // 0x864588: stp             xzr, x16, [SP, #-0x10]!
    // 0x86458c: r0 = _GrowableList()
    //     0x86458c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x864590: add             SP, SP, #0x10
    // 0x864594: mov             x1, x0
    // 0x864598: ldr             x0, [fp, #0x18]
    // 0x86459c: stur            x1, [fp, #-0x18]
    // 0x8645a0: LoadField: r2 = r0->field_1b
    //     0x8645a0: ldur            w2, [x0, #0x1b]
    // 0x8645a4: DecompressPointer r2
    //     0x8645a4: add             x2, x2, HEAP, lsl #32
    // 0x8645a8: r16 = Sentinel
    //     0x8645a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8645ac: cmp             w2, w16
    // 0x8645b0: b.eq            #0x864840
    // 0x8645b4: LoadField: r3 = r2->field_43
    //     0x8645b4: ldur            w3, [x2, #0x43]
    // 0x8645b8: DecompressPointer r3
    //     0x8645b8: add             x3, x3, HEAP, lsl #32
    // 0x8645bc: r16 = Sentinel
    //     0x8645bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8645c0: cmp             w3, w16
    // 0x8645c4: b.eq            #0x86484c
    // 0x8645c8: r16 = Instance_AnimationStatus
    //     0x8645c8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x8645cc: ldr             x16, [x16, #0xba8]
    // 0x8645d0: cmp             w3, w16
    // 0x8645d4: b.eq            #0x8646e0
    // 0x8645d8: LoadField: r2 = r0->field_1f
    //     0x8645d8: ldur            w2, [x0, #0x1f]
    // 0x8645dc: DecompressPointer r2
    //     0x8645dc: add             x2, x2, HEAP, lsl #32
    // 0x8645e0: r16 = Sentinel
    //     0x8645e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8645e4: cmp             w2, w16
    // 0x8645e8: b.eq            #0x864858
    // 0x8645ec: stur            x2, [fp, #-0x10]
    // 0x8645f0: LoadField: r3 = r0->field_23
    //     0x8645f0: ldur            w3, [x0, #0x23]
    // 0x8645f4: DecompressPointer r3
    //     0x8645f4: add             x3, x3, HEAP, lsl #32
    // 0x8645f8: r16 = Sentinel
    //     0x8645f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8645fc: cmp             w3, w16
    // 0x864600: b.eq            #0x864864
    // 0x864604: stur            x3, [fp, #-8]
    // 0x864608: r0 = RotationTransition()
    //     0x864608: bl              #0x853180  ; AllocateRotationTransitionStub -> RotationTransition (size=0x1c)
    // 0x86460c: mov             x1, x0
    // 0x864610: r0 = Instance_Alignment
    //     0x864610: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x864614: ldr             x0, [x0, #0xc70]
    // 0x864618: stur            x1, [fp, #-0x20]
    // 0x86461c: StoreField: r1->field_f = r0
    //     0x86461c: stur            w0, [x1, #0xf]
    // 0x864620: ldur            x2, [fp, #-8]
    // 0x864624: StoreField: r1->field_b = r2
    //     0x864624: stur            w2, [x1, #0xb]
    // 0x864628: r0 = ScaleTransition()
    //     0x864628: bl              #0x864894  ; AllocateScaleTransitionStub -> ScaleTransition (size=0x1c)
    // 0x86462c: mov             x1, x0
    // 0x864630: r0 = Instance_Alignment
    //     0x864630: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x864634: ldr             x0, [x0, #0xc70]
    // 0x864638: stur            x1, [fp, #-0x28]
    // 0x86463c: StoreField: r1->field_f = r0
    //     0x86463c: stur            w0, [x1, #0xf]
    // 0x864640: ldur            x2, [fp, #-0x20]
    // 0x864644: StoreField: r1->field_17 = r2
    //     0x864644: stur            w2, [x1, #0x17]
    // 0x864648: ldur            x2, [fp, #-0x10]
    // 0x86464c: StoreField: r1->field_b = r2
    //     0x86464c: stur            w2, [x1, #0xb]
    // 0x864650: ldur            x2, [fp, #-0x18]
    // 0x864654: LoadField: r3 = r2->field_b
    //     0x864654: ldur            w3, [x2, #0xb]
    // 0x864658: DecompressPointer r3
    //     0x864658: add             x3, x3, HEAP, lsl #32
    // 0x86465c: stur            x3, [fp, #-8]
    // 0x864660: LoadField: r4 = r2->field_f
    //     0x864660: ldur            w4, [x2, #0xf]
    // 0x864664: DecompressPointer r4
    //     0x864664: add             x4, x4, HEAP, lsl #32
    // 0x864668: LoadField: r5 = r4->field_b
    //     0x864668: ldur            w5, [x4, #0xb]
    // 0x86466c: DecompressPointer r5
    //     0x86466c: add             x5, x5, HEAP, lsl #32
    // 0x864670: cmp             w3, w5
    // 0x864674: b.ne            #0x864684
    // 0x864678: SaveReg r2
    //     0x864678: str             x2, [SP, #-8]!
    // 0x86467c: r0 = _growToNextCapacity()
    //     0x86467c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x864680: add             SP, SP, #8
    // 0x864684: ldur            x2, [fp, #-0x18]
    // 0x864688: ldur            x0, [fp, #-8]
    // 0x86468c: r3 = LoadInt32Instr(r0)
    //     0x86468c: sbfx            x3, x0, #1, #0x1f
    // 0x864690: add             x0, x3, #1
    // 0x864694: lsl             x1, x0, #1
    // 0x864698: StoreField: r2->field_b = r1
    //     0x864698: stur            w1, [x2, #0xb]
    // 0x86469c: mov             x1, x3
    // 0x8646a0: cmp             x1, x0
    // 0x8646a4: b.hs            #0x864870
    // 0x8646a8: LoadField: r1 = r2->field_f
    //     0x8646a8: ldur            w1, [x2, #0xf]
    // 0x8646ac: DecompressPointer r1
    //     0x8646ac: add             x1, x1, HEAP, lsl #32
    // 0x8646b0: ldur            x0, [fp, #-0x28]
    // 0x8646b4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8646b4: add             x25, x1, x3, lsl #2
    //     0x8646b8: add             x25, x25, #0xf
    //     0x8646bc: str             w0, [x25]
    //     0x8646c0: tbz             w0, #0, #0x8646dc
    //     0x8646c4: ldurb           w16, [x1, #-1]
    //     0x8646c8: ldurb           w17, [x0, #-1]
    //     0x8646cc: and             x16, x17, x16, lsr #2
    //     0x8646d0: tst             x16, HEAP, lsr #32
    //     0x8646d4: b.eq            #0x8646dc
    //     0x8646d8: bl              #0xd67e5c
    // 0x8646dc: b               #0x8646e4
    // 0x8646e0: mov             x2, x1
    // 0x8646e4: ldr             x0, [fp, #0x18]
    // 0x8646e8: LoadField: r1 = r0->field_b
    //     0x8646e8: ldur            w1, [x0, #0xb]
    // 0x8646ec: DecompressPointer r1
    //     0x8646ec: add             x1, x1, HEAP, lsl #32
    // 0x8646f0: cmp             w1, NULL
    // 0x8646f4: b.eq            #0x864874
    // 0x8646f8: LoadField: r1 = r0->field_27
    //     0x8646f8: ldur            w1, [x0, #0x27]
    // 0x8646fc: DecompressPointer r1
    //     0x8646fc: add             x1, x1, HEAP, lsl #32
    // 0x864700: r16 = Sentinel
    //     0x864700: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x864704: cmp             w1, w16
    // 0x864708: b.eq            #0x864878
    // 0x86470c: stur            x1, [fp, #-0x10]
    // 0x864710: LoadField: r3 = r0->field_2f
    //     0x864710: ldur            w3, [x0, #0x2f]
    // 0x864714: DecompressPointer r3
    //     0x864714: add             x3, x3, HEAP, lsl #32
    // 0x864718: r16 = Sentinel
    //     0x864718: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86471c: cmp             w3, w16
    // 0x864720: b.eq            #0x864884
    // 0x864724: stur            x3, [fp, #-8]
    // 0x864728: r0 = RotationTransition()
    //     0x864728: bl              #0x853180  ; AllocateRotationTransitionStub -> RotationTransition (size=0x1c)
    // 0x86472c: mov             x1, x0
    // 0x864730: r0 = Instance_Alignment
    //     0x864730: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x864734: ldr             x0, [x0, #0xc70]
    // 0x864738: stur            x1, [fp, #-0x20]
    // 0x86473c: StoreField: r1->field_f = r0
    //     0x86473c: stur            w0, [x1, #0xf]
    // 0x864740: ldur            x2, [fp, #-8]
    // 0x864744: StoreField: r1->field_b = r2
    //     0x864744: stur            w2, [x1, #0xb]
    // 0x864748: r0 = ScaleTransition()
    //     0x864748: bl              #0x864894  ; AllocateScaleTransitionStub -> ScaleTransition (size=0x1c)
    // 0x86474c: mov             x1, x0
    // 0x864750: r0 = Instance_Alignment
    //     0x864750: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x864754: ldr             x0, [x0, #0xc70]
    // 0x864758: stur            x1, [fp, #-0x28]
    // 0x86475c: StoreField: r1->field_f = r0
    //     0x86475c: stur            w0, [x1, #0xf]
    // 0x864760: ldur            x0, [fp, #-0x20]
    // 0x864764: StoreField: r1->field_17 = r0
    //     0x864764: stur            w0, [x1, #0x17]
    // 0x864768: ldur            x0, [fp, #-0x10]
    // 0x86476c: StoreField: r1->field_b = r0
    //     0x86476c: stur            w0, [x1, #0xb]
    // 0x864770: ldur            x0, [fp, #-0x18]
    // 0x864774: LoadField: r2 = r0->field_b
    //     0x864774: ldur            w2, [x0, #0xb]
    // 0x864778: DecompressPointer r2
    //     0x864778: add             x2, x2, HEAP, lsl #32
    // 0x86477c: stur            x2, [fp, #-8]
    // 0x864780: LoadField: r3 = r0->field_f
    //     0x864780: ldur            w3, [x0, #0xf]
    // 0x864784: DecompressPointer r3
    //     0x864784: add             x3, x3, HEAP, lsl #32
    // 0x864788: LoadField: r4 = r3->field_b
    //     0x864788: ldur            w4, [x3, #0xb]
    // 0x86478c: DecompressPointer r4
    //     0x86478c: add             x4, x4, HEAP, lsl #32
    // 0x864790: cmp             w2, w4
    // 0x864794: b.ne            #0x8647a4
    // 0x864798: SaveReg r0
    //     0x864798: str             x0, [SP, #-8]!
    // 0x86479c: r0 = _growToNextCapacity()
    //     0x86479c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8647a0: add             SP, SP, #8
    // 0x8647a4: ldur            x2, [fp, #-0x18]
    // 0x8647a8: ldur            x0, [fp, #-8]
    // 0x8647ac: r3 = LoadInt32Instr(r0)
    //     0x8647ac: sbfx            x3, x0, #1, #0x1f
    // 0x8647b0: add             x0, x3, #1
    // 0x8647b4: lsl             x1, x0, #1
    // 0x8647b8: StoreField: r2->field_b = r1
    //     0x8647b8: stur            w1, [x2, #0xb]
    // 0x8647bc: mov             x1, x3
    // 0x8647c0: cmp             x1, x0
    // 0x8647c4: b.hs            #0x864890
    // 0x8647c8: LoadField: r1 = r2->field_f
    //     0x8647c8: ldur            w1, [x2, #0xf]
    // 0x8647cc: DecompressPointer r1
    //     0x8647cc: add             x1, x1, HEAP, lsl #32
    // 0x8647d0: ldur            x0, [fp, #-0x28]
    // 0x8647d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8647d4: add             x25, x1, x3, lsl #2
    //     0x8647d8: add             x25, x25, #0xf
    //     0x8647dc: str             w0, [x25]
    //     0x8647e0: tbz             w0, #0, #0x8647fc
    //     0x8647e4: ldurb           w16, [x1, #-1]
    //     0x8647e8: ldurb           w17, [x0, #-1]
    //     0x8647ec: and             x16, x17, x16, lsr #2
    //     0x8647f0: tst             x16, HEAP, lsr #32
    //     0x8647f4: b.eq            #0x8647fc
    //     0x8647f8: bl              #0xd67e5c
    // 0x8647fc: r0 = Stack()
    //     0x8647fc: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x864800: r1 = Instance_Alignment
    //     0x864800: add             x1, PP, #0x27, lsl #12  ; [pp+0x27370] Obj!Alignment@b37b31
    //     0x864804: ldr             x1, [x1, #0x370]
    // 0x864808: StoreField: r0->field_f = r1
    //     0x864808: stur            w1, [x0, #0xf]
    // 0x86480c: r1 = Instance_StackFit
    //     0x86480c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x864810: ldr             x1, [x1, #0xf78]
    // 0x864814: StoreField: r0->field_17 = r1
    //     0x864814: stur            w1, [x0, #0x17]
    // 0x864818: r1 = Instance_Clip
    //     0x864818: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x86481c: ldr             x1, [x1, #0x678]
    // 0x864820: StoreField: r0->field_1b = r1
    //     0x864820: stur            w1, [x0, #0x1b]
    // 0x864824: ldur            x1, [fp, #-0x18]
    // 0x864828: StoreField: r0->field_b = r1
    //     0x864828: stur            w1, [x0, #0xb]
    // 0x86482c: LeaveFrame
    //     0x86482c: mov             SP, fp
    //     0x864830: ldp             fp, lr, [SP], #0x10
    // 0x864834: ret
    //     0x864834: ret             
    // 0x864838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x864838: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86483c: b               #0x864580
    // 0x864840: r9 = _previousController
    //     0x864840: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e000] Field <_FloatingActionButtonTransitionState@801420462._previousController@801420462>: late (offset: 0x1c)
    //     0x864844: ldr             x9, [x9]
    // 0x864848: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x864848: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x86484c: r9 = _status
    //     0x86484c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbe0] Field <AnimationController._status@575066280>: late (offset: 0x44)
    //     0x864850: ldr             x9, [x9, #0xbe0]
    // 0x864854: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x864854: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x864858: r9 = _previousScaleAnimation
    //     0x864858: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e008] Field <_FloatingActionButtonTransitionState@801420462._previousScaleAnimation@801420462>: late (offset: 0x20)
    //     0x86485c: ldr             x9, [x9, #8]
    // 0x864860: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x864860: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x864864: r9 = _previousRotationAnimation
    //     0x864864: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e010] Field <_FloatingActionButtonTransitionState@801420462._previousRotationAnimation@801420462>: late (offset: 0x24)
    //     0x864868: ldr             x9, [x9, #0x10]
    // 0x86486c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86486c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x864870: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x864870: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x864874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x864874: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x864878: r9 = _currentScaleAnimation
    //     0x864878: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e018] Field <_FloatingActionButtonTransitionState@801420462._currentScaleAnimation@801420462>: late (offset: 0x28)
    //     0x86487c: ldr             x9, [x9, #0x18]
    // 0x864880: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x864880: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x864884: r9 = _currentRotationAnimation
    //     0x864884: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e020] Field <_FloatingActionButtonTransitionState@801420462._currentRotationAnimation@801420462>: late (offset: 0x30)
    //     0x864888: ldr             x9, [x9, #0x20]
    // 0x86488c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86488c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x864890: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x864890: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9db208, size: 0xe8
    // 0x9db208: EnterFrame
    //     0x9db208: stp             fp, lr, [SP, #-0x10]!
    //     0x9db20c: mov             fp, SP
    // 0x9db210: AllocStack(0x8)
    //     0x9db210: sub             SP, SP, #8
    // 0x9db214: CheckStackOverflow
    //     0x9db214: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db218: cmp             SP, x16
    //     0x9db21c: b.ls            #0x9db2e4
    // 0x9db220: r1 = <double>
    //     0x9db220: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db224: r0 = AnimationController()
    //     0x9db224: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db228: stur            x0, [fp, #-8]
    // 0x9db22c: ldr             x16, [fp, #0x10]
    // 0x9db230: stp             x16, x0, [SP, #-0x10]!
    // 0x9db234: r16 = Instance_Duration
    //     0x9db234: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9db238: ldr             x16, [x16, #0x9e0]
    // 0x9db23c: SaveReg r16
    //     0x9db23c: str             x16, [SP, #-8]!
    // 0x9db240: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9db240: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9db244: ldr             x4, [x4, #0xa0]
    // 0x9db248: r0 = AnimationController()
    //     0x9db248: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db24c: add             SP, SP, #0x18
    // 0x9db250: r1 = 1
    //     0x9db250: mov             x1, #1
    // 0x9db254: r0 = AllocateContext()
    //     0x9db254: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9db258: mov             x1, x0
    // 0x9db25c: ldr             x0, [fp, #0x10]
    // 0x9db260: StoreField: r1->field_f = r0
    //     0x9db260: stur            w0, [x1, #0xf]
    // 0x9db264: mov             x2, x1
    // 0x9db268: r1 = Function '_handlePreviousAnimationStatusChanged@801420462':.
    //     0x9db268: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e100] AnonymousClosure: (0x9db2f0), in [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_handlePreviousAnimationStatusChanged (0x9db33c)
    //     0x9db26c: ldr             x1, [x1, #0x100]
    // 0x9db270: r0 = AllocateClosure()
    //     0x9db270: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9db274: ldur            x16, [fp, #-8]
    // 0x9db278: stp             x0, x16, [SP, #-0x10]!
    // 0x9db27c: r0 = addStatusListener()
    //     0x9db27c: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x9db280: add             SP, SP, #0x10
    // 0x9db284: ldur            x0, [fp, #-8]
    // 0x9db288: ldr             x1, [fp, #0x10]
    // 0x9db28c: StoreField: r1->field_1b = r0
    //     0x9db28c: stur            w0, [x1, #0x1b]
    //     0x9db290: ldurb           w16, [x1, #-1]
    //     0x9db294: ldurb           w17, [x0, #-1]
    //     0x9db298: and             x16, x17, x16, lsr #2
    //     0x9db29c: tst             x16, HEAP, lsr #32
    //     0x9db2a0: b.eq            #0x9db2a8
    //     0x9db2a4: bl              #0xd6826c
    // 0x9db2a8: SaveReg r1
    //     0x9db2a8: str             x1, [SP, #-8]!
    // 0x9db2ac: r0 = _updateAnimations()
    //     0x9db2ac: bl              #0x7b94b4  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateAnimations
    // 0x9db2b0: add             SP, SP, #8
    // 0x9db2b4: ldr             x0, [fp, #0x10]
    // 0x9db2b8: LoadField: r1 = r0->field_b
    //     0x9db2b8: ldur            w1, [x0, #0xb]
    // 0x9db2bc: DecompressPointer r1
    //     0x9db2bc: add             x1, x1, HEAP, lsl #32
    // 0x9db2c0: cmp             w1, NULL
    // 0x9db2c4: b.eq            #0x9db2ec
    // 0x9db2c8: stp             xzr, x0, [SP, #-0x10]!
    // 0x9db2cc: r0 = _updateGeometryScale()
    //     0x9db2cc: bl              #0x7ba358  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateGeometryScale
    // 0x9db2d0: add             SP, SP, #0x10
    // 0x9db2d4: r0 = Null
    //     0x9db2d4: mov             x0, NULL
    // 0x9db2d8: LeaveFrame
    //     0x9db2d8: mov             SP, fp
    //     0x9db2dc: ldp             fp, lr, [SP], #0x10
    // 0x9db2e0: ret
    //     0x9db2e0: ret             
    // 0x9db2e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db2e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db2e8: b               #0x9db220
    // 0x9db2ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db2ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handlePreviousAnimationStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0x9db2f0, size: 0x4c
    // 0x9db2f0: EnterFrame
    //     0x9db2f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9db2f4: mov             fp, SP
    // 0x9db2f8: ldr             x0, [fp, #0x18]
    // 0x9db2fc: LoadField: r1 = r0->field_17
    //     0x9db2fc: ldur            w1, [x0, #0x17]
    // 0x9db300: DecompressPointer r1
    //     0x9db300: add             x1, x1, HEAP, lsl #32
    // 0x9db304: CheckStackOverflow
    //     0x9db304: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db308: cmp             SP, x16
    //     0x9db30c: b.ls            #0x9db334
    // 0x9db310: LoadField: r0 = r1->field_f
    //     0x9db310: ldur            w0, [x1, #0xf]
    // 0x9db314: DecompressPointer r0
    //     0x9db314: add             x0, x0, HEAP, lsl #32
    // 0x9db318: ldr             x16, [fp, #0x10]
    // 0x9db31c: stp             x16, x0, [SP, #-0x10]!
    // 0x9db320: r0 = _handlePreviousAnimationStatusChanged()
    //     0x9db320: bl              #0x9db33c  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_handlePreviousAnimationStatusChanged
    // 0x9db324: add             SP, SP, #0x10
    // 0x9db328: LeaveFrame
    //     0x9db328: mov             SP, fp
    //     0x9db32c: ldp             fp, lr, [SP], #0x10
    // 0x9db330: ret
    //     0x9db330: ret             
    // 0x9db334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db334: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db338: b               #0x9db310
  }
  _ _handlePreviousAnimationStatusChanged(/* No info */) {
    // ** addr: 0x9db33c, size: 0x68
    // 0x9db33c: EnterFrame
    //     0x9db33c: stp             fp, lr, [SP, #-0x10]!
    //     0x9db340: mov             fp, SP
    // 0x9db344: CheckStackOverflow
    //     0x9db344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db348: cmp             SP, x16
    //     0x9db34c: b.ls            #0x9db39c
    // 0x9db350: r1 = 2
    //     0x9db350: mov             x1, #2
    // 0x9db354: r0 = AllocateContext()
    //     0x9db354: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9db358: mov             x1, x0
    // 0x9db35c: ldr             x0, [fp, #0x18]
    // 0x9db360: StoreField: r1->field_f = r0
    //     0x9db360: stur            w0, [x1, #0xf]
    // 0x9db364: ldr             x2, [fp, #0x10]
    // 0x9db368: StoreField: r1->field_13 = r2
    //     0x9db368: stur            w2, [x1, #0x13]
    // 0x9db36c: mov             x2, x1
    // 0x9db370: r1 = Function '<anonymous closure>':.
    //     0x9db370: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e108] AnonymousClosure: (0x9db3a4), in [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_handlePreviousAnimationStatusChanged (0x9db33c)
    //     0x9db374: ldr             x1, [x1, #0x108]
    // 0x9db378: r0 = AllocateClosure()
    //     0x9db378: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9db37c: ldr             x16, [fp, #0x18]
    // 0x9db380: stp             x0, x16, [SP, #-0x10]!
    // 0x9db384: r0 = setState()
    //     0x9db384: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9db388: add             SP, SP, #0x10
    // 0x9db38c: r0 = Null
    //     0x9db38c: mov             x0, NULL
    // 0x9db390: LeaveFrame
    //     0x9db390: mov             SP, fp
    //     0x9db394: ldp             fp, lr, [SP], #0x10
    // 0x9db398: ret
    //     0x9db398: ret             
    // 0x9db39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db39c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db3a0: b               #0x9db350
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9db3a4, size: 0x58
    // 0x9db3a4: EnterFrame
    //     0x9db3a4: stp             fp, lr, [SP, #-0x10]!
    //     0x9db3a8: mov             fp, SP
    // 0x9db3ac: ldr             x1, [fp, #0x10]
    // 0x9db3b0: LoadField: r2 = r1->field_17
    //     0x9db3b0: ldur            w2, [x1, #0x17]
    // 0x9db3b4: DecompressPointer r2
    //     0x9db3b4: add             x2, x2, HEAP, lsl #32
    // 0x9db3b8: LoadField: r1 = r2->field_13
    //     0x9db3b8: ldur            w1, [x2, #0x13]
    // 0x9db3bc: DecompressPointer r1
    //     0x9db3bc: add             x1, x1, HEAP, lsl #32
    // 0x9db3c0: r16 = Instance_AnimationStatus
    //     0x9db3c0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x9db3c4: ldr             x16, [x16, #0xba8]
    // 0x9db3c8: cmp             w1, w16
    // 0x9db3cc: b.ne            #0x9db3e8
    // 0x9db3d0: LoadField: r1 = r2->field_f
    //     0x9db3d0: ldur            w1, [x2, #0xf]
    // 0x9db3d4: DecompressPointer r1
    //     0x9db3d4: add             x1, x1, HEAP, lsl #32
    // 0x9db3d8: LoadField: r2 = r1->field_b
    //     0x9db3d8: ldur            w2, [x1, #0xb]
    // 0x9db3dc: DecompressPointer r2
    //     0x9db3dc: add             x2, x2, HEAP, lsl #32
    // 0x9db3e0: cmp             w2, NULL
    // 0x9db3e4: b.eq            #0x9db3f8
    // 0x9db3e8: r0 = Null
    //     0x9db3e8: mov             x0, NULL
    // 0x9db3ec: LeaveFrame
    //     0x9db3ec: mov             SP, fp
    //     0x9db3f0: ldp             fp, lr, [SP], #0x10
    // 0x9db3f4: ret
    //     0x9db3f4: ret             
    // 0x9db3f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db3f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b068, size: 0x18
    // 0xa4b068: r4 = 7
    //     0xa4b068: mov             x4, #7
    // 0xa4b06c: r1 = Function 'dispose':.
    //     0xa4b06c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b5a8] AnonymousClosure: (0xa4b080), in [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::dispose (0xa52680)
    //     0xa4b070: ldr             x1, [x17, #0x5a8]
    // 0xa4b074: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b074: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b078: LoadField: r0 = r24->field_17
    //     0xa4b078: ldur            x0, [x24, #0x17]
    // 0xa4b07c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b080, size: 0x48
    // 0xa4b080: EnterFrame
    //     0xa4b080: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b084: mov             fp, SP
    // 0xa4b088: ldr             x0, [fp, #0x10]
    // 0xa4b08c: LoadField: r1 = r0->field_17
    //     0xa4b08c: ldur            w1, [x0, #0x17]
    // 0xa4b090: DecompressPointer r1
    //     0xa4b090: add             x1, x1, HEAP, lsl #32
    // 0xa4b094: CheckStackOverflow
    //     0xa4b094: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b098: cmp             SP, x16
    //     0xa4b09c: b.ls            #0xa4b0c0
    // 0xa4b0a0: LoadField: r0 = r1->field_f
    //     0xa4b0a0: ldur            w0, [x1, #0xf]
    // 0xa4b0a4: DecompressPointer r0
    //     0xa4b0a4: add             x0, x0, HEAP, lsl #32
    // 0xa4b0a8: SaveReg r0
    //     0xa4b0a8: str             x0, [SP, #-8]!
    // 0xa4b0ac: r0 = dispose()
    //     0xa4b0ac: bl              #0xa52680  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::dispose
    // 0xa4b0b0: add             SP, SP, #8
    // 0xa4b0b4: LeaveFrame
    //     0xa4b0b4: mov             SP, fp
    //     0xa4b0b8: ldp             fp, lr, [SP], #0x10
    // 0xa4b0bc: ret
    //     0xa4b0bc: ret             
    // 0xa4b0c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b0c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b0c4: b               #0xa4b0a0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52680, size: 0x6c
    // 0xa52680: EnterFrame
    //     0xa52680: stp             fp, lr, [SP, #-0x10]!
    //     0xa52684: mov             fp, SP
    // 0xa52688: CheckStackOverflow
    //     0xa52688: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5268c: cmp             SP, x16
    //     0xa52690: b.ls            #0xa526d8
    // 0xa52694: ldr             x0, [fp, #0x10]
    // 0xa52698: LoadField: r1 = r0->field_1b
    //     0xa52698: ldur            w1, [x0, #0x1b]
    // 0xa5269c: DecompressPointer r1
    //     0xa5269c: add             x1, x1, HEAP, lsl #32
    // 0xa526a0: r16 = Sentinel
    //     0xa526a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa526a4: cmp             w1, w16
    // 0xa526a8: b.eq            #0xa526e0
    // 0xa526ac: SaveReg r1
    //     0xa526ac: str             x1, [SP, #-8]!
    // 0xa526b0: r0 = dispose()
    //     0xa526b0: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa526b4: add             SP, SP, #8
    // 0xa526b8: ldr             x16, [fp, #0x10]
    // 0xa526bc: SaveReg r16
    //     0xa526bc: str             x16, [SP, #-8]!
    // 0xa526c0: r0 = dispose()
    //     0xa526c0: bl              #0xa526ec  ; [package:flutter/src/material/scaffold.dart] __FloatingActionButtonTransitionState&State&TickerProviderStateMixin::dispose
    // 0xa526c4: add             SP, SP, #8
    // 0xa526c8: r0 = Null
    //     0xa526c8: mov             x0, NULL
    // 0xa526cc: LeaveFrame
    //     0xa526cc: mov             SP, fp
    //     0xa526d0: ldp             fp, lr, [SP], #0x10
    // 0xa526d4: ret
    //     0xa526d4: ret             
    // 0xa526d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa526d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa526dc: b               #0xa52694
    // 0xa526e0: r9 = _previousController
    //     0xa526e0: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e000] Field <_FloatingActionButtonTransitionState@801420462._previousController@801420462>: late (offset: 0x1c)
    //     0xa526e4: ldr             x9, [x9]
    // 0xa526e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa526e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3284, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _ScaffoldMessengerState&State&TickerProviderStateMixin extends State<ScaffoldMessenger>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ activate(/* No info */) {
    // ** addr: 0x81f5d8, size: 0x3c
    // 0x81f5d8: EnterFrame
    //     0x81f5d8: stp             fp, lr, [SP, #-0x10]!
    //     0x81f5dc: mov             fp, SP
    // 0x81f5e0: CheckStackOverflow
    //     0x81f5e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f5e4: cmp             SP, x16
    //     0x81f5e8: b.ls            #0x81f60c
    // 0x81f5ec: ldr             x16, [fp, #0x10]
    // 0x81f5f0: SaveReg r16
    //     0x81f5f0: str             x16, [SP, #-8]!
    // 0x81f5f4: r0 = _updateTickerModeNotifier()
    //     0x81f5f4: bl              #0x81f638  ; [package:flutter/src/material/scaffold.dart] _ScaffoldMessengerState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f5f8: add             SP, SP, #8
    // 0x81f5fc: r0 = Null
    //     0x81f5fc: mov             x0, NULL
    // 0x81f600: LeaveFrame
    //     0x81f600: mov             SP, fp
    //     0x81f604: ldp             fp, lr, [SP], #0x10
    // 0x81f608: ret
    //     0x81f608: ret             
    // 0x81f60c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f60c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f610: b               #0x81f5ec
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x81f638, size: 0x11c
    // 0x81f638: EnterFrame
    //     0x81f638: stp             fp, lr, [SP, #-0x10]!
    //     0x81f63c: mov             fp, SP
    // 0x81f640: AllocStack(0x10)
    //     0x81f640: sub             SP, SP, #0x10
    // 0x81f644: CheckStackOverflow
    //     0x81f644: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f648: cmp             SP, x16
    //     0x81f64c: b.ls            #0x81f748
    // 0x81f650: ldr             x0, [fp, #0x10]
    // 0x81f654: LoadField: r1 = r0->field_f
    //     0x81f654: ldur            w1, [x0, #0xf]
    // 0x81f658: DecompressPointer r1
    //     0x81f658: add             x1, x1, HEAP, lsl #32
    // 0x81f65c: cmp             w1, NULL
    // 0x81f660: b.eq            #0x81f750
    // 0x81f664: SaveReg r1
    //     0x81f664: str             x1, [SP, #-8]!
    // 0x81f668: r0 = getNotifier()
    //     0x81f668: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x81f66c: add             SP, SP, #8
    // 0x81f670: mov             x1, x0
    // 0x81f674: ldr             x0, [fp, #0x10]
    // 0x81f678: stur            x1, [fp, #-0x10]
    // 0x81f67c: LoadField: r2 = r0->field_17
    //     0x81f67c: ldur            w2, [x0, #0x17]
    // 0x81f680: DecompressPointer r2
    //     0x81f680: add             x2, x2, HEAP, lsl #32
    // 0x81f684: stur            x2, [fp, #-8]
    // 0x81f688: cmp             w1, w2
    // 0x81f68c: b.ne            #0x81f6a0
    // 0x81f690: r0 = Null
    //     0x81f690: mov             x0, NULL
    // 0x81f694: LeaveFrame
    //     0x81f694: mov             SP, fp
    //     0x81f698: ldp             fp, lr, [SP], #0x10
    // 0x81f69c: ret
    //     0x81f69c: ret             
    // 0x81f6a0: cmp             w2, NULL
    // 0x81f6a4: b.eq            #0x81f6e0
    // 0x81f6a8: r1 = 1
    //     0x81f6a8: mov             x1, #1
    // 0x81f6ac: r0 = AllocateContext()
    //     0x81f6ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x81f6b0: mov             x1, x0
    // 0x81f6b4: ldr             x0, [fp, #0x10]
    // 0x81f6b8: StoreField: r1->field_f = r0
    //     0x81f6b8: stur            w0, [x1, #0xf]
    // 0x81f6bc: mov             x2, x1
    // 0x81f6c0: r1 = Function '_updateTickers@156311458':.
    //     0x81f6c0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28988] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x81f6c4: ldr             x1, [x1, #0x988]
    // 0x81f6c8: r0 = AllocateClosure()
    //     0x81f6c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x81f6cc: ldur            x16, [fp, #-8]
    // 0x81f6d0: stp             x0, x16, [SP, #-0x10]!
    // 0x81f6d4: r0 = removeListener()
    //     0x81f6d4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x81f6d8: add             SP, SP, #0x10
    // 0x81f6dc: ldr             x0, [fp, #0x10]
    // 0x81f6e0: r1 = 1
    //     0x81f6e0: mov             x1, #1
    // 0x81f6e4: r0 = AllocateContext()
    //     0x81f6e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x81f6e8: mov             x1, x0
    // 0x81f6ec: ldr             x0, [fp, #0x10]
    // 0x81f6f0: StoreField: r1->field_f = r0
    //     0x81f6f0: stur            w0, [x1, #0xf]
    // 0x81f6f4: mov             x2, x1
    // 0x81f6f8: r1 = Function '_updateTickers@156311458':.
    //     0x81f6f8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28988] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x81f6fc: ldr             x1, [x1, #0x988]
    // 0x81f700: r0 = AllocateClosure()
    //     0x81f700: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x81f704: ldur            x16, [fp, #-0x10]
    // 0x81f708: stp             x0, x16, [SP, #-0x10]!
    // 0x81f70c: r0 = addListener()
    //     0x81f70c: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x81f710: add             SP, SP, #0x10
    // 0x81f714: ldur            x0, [fp, #-0x10]
    // 0x81f718: ldr             x1, [fp, #0x10]
    // 0x81f71c: StoreField: r1->field_17 = r0
    //     0x81f71c: stur            w0, [x1, #0x17]
    //     0x81f720: ldurb           w16, [x1, #-1]
    //     0x81f724: ldurb           w17, [x0, #-1]
    //     0x81f728: and             x16, x17, x16, lsr #2
    //     0x81f72c: tst             x16, HEAP, lsr #32
    //     0x81f730: b.eq            #0x81f738
    //     0x81f734: bl              #0xd6826c
    // 0x81f738: r0 = Null
    //     0x81f738: mov             x0, NULL
    // 0x81f73c: LeaveFrame
    //     0x81f73c: mov             SP, fp
    //     0x81f740: ldp             fp, lr, [SP], #0x10
    // 0x81f744: ret
    //     0x81f744: ret             
    // 0x81f748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f748: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f74c: b               #0x81f650
    // 0x81f750: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x81f750: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa525ac, size: 0x8c
    // 0xa525ac: EnterFrame
    //     0xa525ac: stp             fp, lr, [SP, #-0x10]!
    //     0xa525b0: mov             fp, SP
    // 0xa525b4: AllocStack(0x8)
    //     0xa525b4: sub             SP, SP, #8
    // 0xa525b8: CheckStackOverflow
    //     0xa525b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa525bc: cmp             SP, x16
    //     0xa525c0: b.ls            #0xa52630
    // 0xa525c4: ldr             x0, [fp, #0x10]
    // 0xa525c8: LoadField: r1 = r0->field_17
    //     0xa525c8: ldur            w1, [x0, #0x17]
    // 0xa525cc: DecompressPointer r1
    //     0xa525cc: add             x1, x1, HEAP, lsl #32
    // 0xa525d0: stur            x1, [fp, #-8]
    // 0xa525d4: cmp             w1, NULL
    // 0xa525d8: b.ne            #0xa525e4
    // 0xa525dc: mov             x1, x0
    // 0xa525e0: b               #0xa5261c
    // 0xa525e4: r1 = 1
    //     0xa525e4: mov             x1, #1
    // 0xa525e8: r0 = AllocateContext()
    //     0xa525e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa525ec: mov             x1, x0
    // 0xa525f0: ldr             x0, [fp, #0x10]
    // 0xa525f4: StoreField: r1->field_f = r0
    //     0xa525f4: stur            w0, [x1, #0xf]
    // 0xa525f8: mov             x2, x1
    // 0xa525fc: r1 = Function '_updateTickers@156311458':.
    //     0xa525fc: add             x1, PP, #0x28, lsl #12  ; [pp+0x28988] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xa52600: ldr             x1, [x1, #0x988]
    // 0xa52604: r0 = AllocateClosure()
    //     0xa52604: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52608: ldur            x16, [fp, #-8]
    // 0xa5260c: stp             x0, x16, [SP, #-0x10]!
    // 0xa52610: r0 = removeListener()
    //     0xa52610: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa52614: add             SP, SP, #0x10
    // 0xa52618: ldr             x1, [fp, #0x10]
    // 0xa5261c: StoreField: r1->field_17 = rNULL
    //     0xa5261c: stur            NULL, [x1, #0x17]
    // 0xa52620: r0 = Null
    //     0xa52620: mov             x0, NULL
    // 0xa52624: LeaveFrame
    //     0xa52624: mov             SP, fp
    //     0xa52628: ldp             fp, lr, [SP], #0x10
    // 0xa5262c: ret
    //     0xa5262c: ret             
    // 0xa52630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52634: b               #0xa525c4
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa52638, size: 0x48
    // 0xa52638: EnterFrame
    //     0xa52638: stp             fp, lr, [SP, #-0x10]!
    //     0xa5263c: mov             fp, SP
    // 0xa52640: ldr             x0, [fp, #0x10]
    // 0xa52644: LoadField: r1 = r0->field_17
    //     0xa52644: ldur            w1, [x0, #0x17]
    // 0xa52648: DecompressPointer r1
    //     0xa52648: add             x1, x1, HEAP, lsl #32
    // 0xa5264c: CheckStackOverflow
    //     0xa5264c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52650: cmp             SP, x16
    //     0xa52654: b.ls            #0xa52678
    // 0xa52658: LoadField: r0 = r1->field_f
    //     0xa52658: ldur            w0, [x1, #0xf]
    // 0xa5265c: DecompressPointer r0
    //     0xa5265c: add             x0, x0, HEAP, lsl #32
    // 0xa52660: SaveReg r0
    //     0xa52660: str             x0, [SP, #-8]!
    // 0xa52664: r0 = dispose()
    //     0xa52664: bl              #0xa525ac  ; [package:flutter/src/material/scaffold.dart] _ScaffoldMessengerState&State&TickerProviderStateMixin::dispose
    // 0xa52668: add             SP, SP, #8
    // 0xa5266c: LeaveFrame
    //     0xa5266c: mov             SP, fp
    //     0xa52670: ldp             fp, lr, [SP], #0x10
    // 0xa52674: ret
    //     0xa52674: ret             
    // 0xa52678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52678: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5267c: b               #0xa52658
  }
}

// class id: 3285, size: 0x34, field offset: 0x1c
class ScaffoldMessengerState extends _ScaffoldMessengerState&State&TickerProviderStateMixin {

  _ build(/* No info */) {
    // ** addr: 0x864474, size: 0xe8
    // 0x864474: EnterFrame
    //     0x864474: stp             fp, lr, [SP, #-0x10]!
    //     0x864478: mov             fp, SP
    // 0x86447c: AllocStack(0x8)
    //     0x86447c: sub             SP, SP, #8
    // 0x864480: CheckStackOverflow
    //     0x864480: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x864484: cmp             SP, x16
    //     0x864488: b.ls            #0x86454c
    // 0x86448c: ldr             x16, [fp, #0x10]
    // 0x864490: SaveReg r16
    //     0x864490: str             x16, [SP, #-8]!
    // 0x864494: r0 = of()
    //     0x864494: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x864498: add             SP, SP, #8
    // 0x86449c: LoadField: r1 = r0->field_33
    //     0x86449c: ldur            w1, [x0, #0x33]
    // 0x8644a0: DecompressPointer r1
    //     0x8644a0: add             x1, x1, HEAP, lsl #32
    // 0x8644a4: ldr             x0, [fp, #0x18]
    // 0x8644a8: StoreField: r0->field_2f = r1
    //     0x8644a8: stur            w1, [x0, #0x2f]
    // 0x8644ac: LoadField: r1 = r0->field_23
    //     0x8644ac: ldur            w1, [x0, #0x23]
    // 0x8644b0: DecompressPointer r1
    //     0x8644b0: add             x1, x1, HEAP, lsl #32
    // 0x8644b4: LoadField: r2 = r1->field_f
    //     0x8644b4: ldur            x2, [x1, #0xf]
    // 0x8644b8: LoadField: r3 = r1->field_17
    //     0x8644b8: ldur            x3, [x1, #0x17]
    // 0x8644bc: cmp             x2, x3
    // 0x8644c0: b.eq            #0x8644f4
    // 0x8644c4: r16 = <Object?>
    //     0x8644c4: ldr             x16, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0x8644c8: ldr             lr, [fp, #0x10]
    // 0x8644cc: stp             lr, x16, [SP, #-0x10]!
    // 0x8644d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8644d0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8644d4: r0 = of()
    //     0x8644d4: bl              #0x8487f8  ; [package:flutter/src/widgets/routes.dart] ModalRoute::of
    // 0x8644d8: add             SP, SP, #0x10
    // 0x8644dc: cmp             w0, NULL
    // 0x8644e0: b.eq            #0x864534
    // 0x8644e4: SaveReg r0
    //     0x8644e4: str             x0, [SP, #-8]!
    // 0x8644e8: r0 = isCurrent()
    //     0x8644e8: bl              #0x6fa054  ; [package:flutter/src/widgets/navigator.dart] Route::isCurrent
    // 0x8644ec: add             SP, SP, #8
    // 0x8644f0: tbz             w0, #4, #0x864534
    // 0x8644f4: ldr             x0, [fp, #0x18]
    // 0x8644f8: LoadField: r1 = r0->field_b
    //     0x8644f8: ldur            w1, [x0, #0xb]
    // 0x8644fc: DecompressPointer r1
    //     0x8644fc: add             x1, x1, HEAP, lsl #32
    // 0x864500: cmp             w1, NULL
    // 0x864504: b.eq            #0x864554
    // 0x864508: LoadField: r2 = r1->field_b
    //     0x864508: ldur            w2, [x1, #0xb]
    // 0x86450c: DecompressPointer r2
    //     0x86450c: add             x2, x2, HEAP, lsl #32
    // 0x864510: stur            x2, [fp, #-8]
    // 0x864514: r0 = _ScaffoldMessengerScope()
    //     0x864514: bl              #0x86455c  ; Allocate_ScaffoldMessengerScopeStub -> _ScaffoldMessengerScope (size=0x14)
    // 0x864518: ldr             x1, [fp, #0x18]
    // 0x86451c: StoreField: r0->field_f = r1
    //     0x86451c: stur            w1, [x0, #0xf]
    // 0x864520: ldur            x1, [fp, #-8]
    // 0x864524: StoreField: r0->field_b = r1
    //     0x864524: stur            w1, [x0, #0xb]
    // 0x864528: LeaveFrame
    //     0x864528: mov             SP, fp
    //     0x86452c: ldp             fp, lr, [SP], #0x10
    // 0x864530: ret
    //     0x864530: ret             
    // 0x864534: r0 = Null
    //     0x864534: mov             x0, NULL
    // 0x864538: cmp             w0, NULL
    // 0x86453c: b.eq            #0x864558
    // 0x864540: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x864540: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x864544: r0 = Throw()
    //     0x864544: bl              #0xd67e38  ; ThrowStub
    // 0x864548: brk             #0
    // 0x86454c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86454c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x864550: b               #0x86448c
    // 0x864554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x864554: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x864558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x864558: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ScaffoldMessengerState(/* No info */) {
    // ** addr: 0xa40f8c, size: 0x148
    // 0xa40f8c: EnterFrame
    //     0xa40f8c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40f90: mov             fp, SP
    // 0xa40f94: AllocStack(0x10)
    //     0xa40f94: sub             SP, SP, #0x10
    // 0xa40f98: CheckStackOverflow
    //     0xa40f98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa40f9c: cmp             SP, x16
    //     0xa40fa0: b.ls            #0xa410cc
    // 0xa40fa4: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xa40fa4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa40fa8: ldr             x0, [x0, #0x598]
    //     0xa40fac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa40fb0: cmp             w0, w16
    //     0xa40fb4: b.ne            #0xa40fc0
    //     0xa40fb8: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xa40fbc: bl              #0xd67cdc
    // 0xa40fc0: r1 = <ScaffoldState<Scaffold>>
    //     0xa40fc0: add             x1, PP, #0x21, lsl #12  ; [pp+0x21fc0] TypeArguments: <ScaffoldState<Scaffold>>
    //     0xa40fc4: ldr             x1, [x1, #0xfc0]
    // 0xa40fc8: stur            x0, [fp, #-8]
    // 0xa40fcc: r0 = _Set()
    //     0xa40fcc: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xa40fd0: mov             x1, x0
    // 0xa40fd4: ldur            x0, [fp, #-8]
    // 0xa40fd8: stur            x1, [fp, #-0x10]
    // 0xa40fdc: StoreField: r1->field_1b = r0
    //     0xa40fdc: stur            w0, [x1, #0x1b]
    // 0xa40fe0: StoreField: r1->field_b = rZR
    //     0xa40fe0: stur            wzr, [x1, #0xb]
    // 0xa40fe4: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xa40fe4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa40fe8: ldr             x0, [x0, #0x5a0]
    //     0xa40fec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa40ff0: cmp             w0, w16
    //     0xa40ff4: b.ne            #0xa41000
    //     0xa40ff8: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xa40ffc: bl              #0xd67cdc
    // 0xa41000: mov             x1, x0
    // 0xa41004: ldur            x0, [fp, #-0x10]
    // 0xa41008: StoreField: r0->field_f = r1
    //     0xa41008: stur            w1, [x0, #0xf]
    // 0xa4100c: StoreField: r0->field_13 = rZR
    //     0xa4100c: stur            wzr, [x0, #0x13]
    // 0xa41010: StoreField: r0->field_17 = rZR
    //     0xa41010: stur            wzr, [x0, #0x17]
    // 0xa41014: ldr             x2, [fp, #0x10]
    // 0xa41018: StoreField: r2->field_1b = r0
    //     0xa41018: stur            w0, [x2, #0x1b]
    //     0xa4101c: ldurb           w16, [x2, #-1]
    //     0xa41020: ldurb           w17, [x0, #-1]
    //     0xa41024: and             x16, x17, x16, lsr #2
    //     0xa41028: tst             x16, HEAP, lsr #32
    //     0xa4102c: b.eq            #0xa41034
    //     0xa41030: bl              #0xd6828c
    // 0xa41034: r1 = <ScaffoldFeatureController<MaterialBanner, MaterialBannerClosedReason>>
    //     0xa41034: add             x1, PP, #0x22, lsl #12  ; [pp+0x22008] TypeArguments: <ScaffoldFeatureController<MaterialBanner, MaterialBannerClosedReason>>
    //     0xa41038: ldr             x1, [x1, #8]
    // 0xa4103c: r0 = ListQueue()
    //     0xa4103c: bl              #0x4ec788  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0xa41040: stur            x0, [fp, #-8]
    // 0xa41044: SaveReg r0
    //     0xa41044: str             x0, [SP, #-8]!
    // 0xa41048: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa41048: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa4104c: r0 = ListQueue()
    //     0xa4104c: bl              #0x4ec604  ; [dart:collection] ListQueue::ListQueue
    // 0xa41050: add             SP, SP, #8
    // 0xa41054: ldur            x0, [fp, #-8]
    // 0xa41058: ldr             x2, [fp, #0x10]
    // 0xa4105c: StoreField: r2->field_1f = r0
    //     0xa4105c: stur            w0, [x2, #0x1f]
    //     0xa41060: ldurb           w16, [x2, #-1]
    //     0xa41064: ldurb           w17, [x0, #-1]
    //     0xa41068: and             x16, x17, x16, lsr #2
    //     0xa4106c: tst             x16, HEAP, lsr #32
    //     0xa41070: b.eq            #0xa41078
    //     0xa41074: bl              #0xd6828c
    // 0xa41078: r1 = <ScaffoldFeatureController<SnackBar, SnackBarClosedReason>>
    //     0xa41078: add             x1, PP, #0x22, lsl #12  ; [pp+0x22010] TypeArguments: <ScaffoldFeatureController<SnackBar, SnackBarClosedReason>>
    //     0xa4107c: ldr             x1, [x1, #0x10]
    // 0xa41080: r0 = ListQueue()
    //     0xa41080: bl              #0x4ec788  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0xa41084: stur            x0, [fp, #-8]
    // 0xa41088: SaveReg r0
    //     0xa41088: str             x0, [SP, #-8]!
    // 0xa4108c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa4108c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa41090: r0 = ListQueue()
    //     0xa41090: bl              #0x4ec604  ; [dart:collection] ListQueue::ListQueue
    // 0xa41094: add             SP, SP, #8
    // 0xa41098: ldur            x0, [fp, #-8]
    // 0xa4109c: ldr             x1, [fp, #0x10]
    // 0xa410a0: StoreField: r1->field_23 = r0
    //     0xa410a0: stur            w0, [x1, #0x23]
    //     0xa410a4: ldurb           w16, [x1, #-1]
    //     0xa410a8: ldurb           w17, [x0, #-1]
    //     0xa410ac: and             x16, x17, x16, lsr #2
    //     0xa410b0: tst             x16, HEAP, lsr #32
    //     0xa410b4: b.eq            #0xa410bc
    //     0xa410b8: bl              #0xd6826c
    // 0xa410bc: r0 = Null
    //     0xa410bc: mov             x0, NULL
    // 0xa410c0: LeaveFrame
    //     0xa410c0: mov             SP, fp
    //     0xa410c4: ldp             fp, lr, [SP], #0x10
    // 0xa410c8: ret
    //     0xa410c8: ret             
    // 0xa410cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa410cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa410d0: b               #0xa40fa4
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b008, size: 0x18
    // 0xa4b008: r4 = 7
    //     0xa4b008: mov             x4, #7
    // 0xa4b00c: r1 = Function 'dispose':.
    //     0xa4b00c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b598] AnonymousClosure: (0xa4b020), in [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::dispose (0xa5256c)
    //     0xa4b010: ldr             x1, [x17, #0x598]
    // 0xa4b014: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b014: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b018: LoadField: r0 = r24->field_17
    //     0xa4b018: ldur            x0, [x24, #0x17]
    // 0xa4b01c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b020, size: 0x48
    // 0xa4b020: EnterFrame
    //     0xa4b020: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b024: mov             fp, SP
    // 0xa4b028: ldr             x0, [fp, #0x10]
    // 0xa4b02c: LoadField: r1 = r0->field_17
    //     0xa4b02c: ldur            w1, [x0, #0x17]
    // 0xa4b030: DecompressPointer r1
    //     0xa4b030: add             x1, x1, HEAP, lsl #32
    // 0xa4b034: CheckStackOverflow
    //     0xa4b034: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b038: cmp             SP, x16
    //     0xa4b03c: b.ls            #0xa4b060
    // 0xa4b040: LoadField: r0 = r1->field_f
    //     0xa4b040: ldur            w0, [x1, #0xf]
    // 0xa4b044: DecompressPointer r0
    //     0xa4b044: add             x0, x0, HEAP, lsl #32
    // 0xa4b048: SaveReg r0
    //     0xa4b048: str             x0, [SP, #-8]!
    // 0xa4b04c: r0 = dispose()
    //     0xa4b04c: bl              #0xa5256c  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::dispose
    // 0xa4b050: add             SP, SP, #8
    // 0xa4b054: LeaveFrame
    //     0xa4b054: mov             SP, fp
    //     0xa4b058: ldp             fp, lr, [SP], #0x10
    // 0xa4b05c: ret
    //     0xa4b05c: ret             
    // 0xa4b060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b060: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b064: b               #0xa4b040
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa5256c, size: 0x40
    // 0xa5256c: EnterFrame
    //     0xa5256c: stp             fp, lr, [SP, #-0x10]!
    //     0xa52570: mov             fp, SP
    // 0xa52574: CheckStackOverflow
    //     0xa52574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52578: cmp             SP, x16
    //     0xa5257c: b.ls            #0xa525a4
    // 0xa52580: ldr             x0, [fp, #0x10]
    // 0xa52584: StoreField: r0->field_2b = rNULL
    //     0xa52584: stur            NULL, [x0, #0x2b]
    // 0xa52588: SaveReg r0
    //     0xa52588: str             x0, [SP, #-8]!
    // 0xa5258c: r0 = dispose()
    //     0xa5258c: bl              #0xa525ac  ; [package:flutter/src/material/scaffold.dart] _ScaffoldMessengerState&State&TickerProviderStateMixin::dispose
    // 0xa52590: add             SP, SP, #8
    // 0xa52594: r0 = Null
    //     0xa52594: mov             x0, NULL
    // 0xa52598: LeaveFrame
    //     0xa52598: mov             SP, fp
    //     0xa5259c: ldp             fp, lr, [SP], #0x10
    // 0xa525a0: ret
    //     0xa525a0: ret             
    // 0xa525a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa525a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa525a8: b               #0xa52580
  }
  _ _unregister(/* No info */) {
    // ** addr: 0xa528dc, size: 0x48
    // 0xa528dc: EnterFrame
    //     0xa528dc: stp             fp, lr, [SP, #-0x10]!
    //     0xa528e0: mov             fp, SP
    // 0xa528e4: CheckStackOverflow
    //     0xa528e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa528e8: cmp             SP, x16
    //     0xa528ec: b.ls            #0xa5291c
    // 0xa528f0: ldr             x0, [fp, #0x18]
    // 0xa528f4: LoadField: r1 = r0->field_1b
    //     0xa528f4: ldur            w1, [x0, #0x1b]
    // 0xa528f8: DecompressPointer r1
    //     0xa528f8: add             x1, x1, HEAP, lsl #32
    // 0xa528fc: ldr             x16, [fp, #0x10]
    // 0xa52900: stp             x16, x1, [SP, #-0x10]!
    // 0xa52904: r0 = remove()
    //     0xa52904: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xa52908: add             SP, SP, #0x10
    // 0xa5290c: r0 = Null
    //     0xa5290c: mov             x0, NULL
    // 0xa52910: LeaveFrame
    //     0xa52910: mov             SP, fp
    //     0xa52914: ldp             fp, lr, [SP], #0x10
    // 0xa52918: ret
    //     0xa52918: ret             
    // 0xa5291c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5291c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52920: b               #0xa528f0
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa6165c, size: 0x74
    // 0xa6165c: EnterFrame
    //     0xa6165c: stp             fp, lr, [SP, #-0x10]!
    //     0xa61660: mov             fp, SP
    // 0xa61664: CheckStackOverflow
    //     0xa61664: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61668: cmp             SP, x16
    //     0xa6166c: b.ls            #0xa616c4
    // 0xa61670: ldr             x0, [fp, #0x10]
    // 0xa61674: LoadField: r1 = r0->field_f
    //     0xa61674: ldur            w1, [x0, #0xf]
    // 0xa61678: DecompressPointer r1
    //     0xa61678: add             x1, x1, HEAP, lsl #32
    // 0xa6167c: cmp             w1, NULL
    // 0xa61680: b.eq            #0xa616cc
    // 0xa61684: SaveReg r1
    //     0xa61684: str             x1, [SP, #-8]!
    // 0xa61688: r0 = of()
    //     0xa61688: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xa6168c: add             SP, SP, #8
    // 0xa61690: ldr             x1, [fp, #0x10]
    // 0xa61694: LoadField: r2 = r1->field_2f
    //     0xa61694: ldur            w2, [x1, #0x2f]
    // 0xa61698: DecompressPointer r2
    //     0xa61698: add             x2, x2, HEAP, lsl #32
    // 0xa6169c: cmp             w2, NULL
    // 0xa616a0: b.eq            #0xa616a8
    // 0xa616a4: tbz             w2, #4, #0xa616a8
    // 0xa616a8: LoadField: r2 = r0->field_33
    //     0xa616a8: ldur            w2, [x0, #0x33]
    // 0xa616ac: DecompressPointer r2
    //     0xa616ac: add             x2, x2, HEAP, lsl #32
    // 0xa616b0: StoreField: r1->field_2f = r2
    //     0xa616b0: stur            w2, [x1, #0x2f]
    // 0xa616b4: r0 = Null
    //     0xa616b4: mov             x0, NULL
    // 0xa616b8: LeaveFrame
    //     0xa616b8: mov             SP, fp
    //     0xa616bc: ldp             fp, lr, [SP], #0x10
    // 0xa616c0: ret
    //     0xa616c0: ret             
    // 0xa616c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa616c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa616c8: b               #0xa61670
    // 0xa616cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa616cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _register(/* No info */) {
    // ** addr: 0xa61ad4, size: 0xb8
    // 0xa61ad4: EnterFrame
    //     0xa61ad4: stp             fp, lr, [SP, #-0x10]!
    //     0xa61ad8: mov             fp, SP
    // 0xa61adc: CheckStackOverflow
    //     0xa61adc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61ae0: cmp             SP, x16
    //     0xa61ae4: b.ls            #0xa61b84
    // 0xa61ae8: ldr             x0, [fp, #0x18]
    // 0xa61aec: LoadField: r1 = r0->field_1b
    //     0xa61aec: ldur            w1, [x0, #0x1b]
    // 0xa61af0: DecompressPointer r1
    //     0xa61af0: add             x1, x1, HEAP, lsl #32
    // 0xa61af4: ldr             x16, [fp, #0x10]
    // 0xa61af8: stp             x16, x1, [SP, #-0x10]!
    // 0xa61afc: r0 = add()
    //     0xa61afc: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xa61b00: add             SP, SP, #0x10
    // 0xa61b04: ldr             x16, [fp, #0x18]
    // 0xa61b08: ldr             lr, [fp, #0x10]
    // 0xa61b0c: stp             lr, x16, [SP, #-0x10]!
    // 0xa61b10: r0 = _isRoot()
    //     0xa61b10: bl              #0xa61cb4  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_isRoot
    // 0xa61b14: add             SP, SP, #0x10
    // 0xa61b18: tbnz            w0, #4, #0xa61b74
    // 0xa61b1c: ldr             x0, [fp, #0x18]
    // 0xa61b20: LoadField: r1 = r0->field_23
    //     0xa61b20: ldur            w1, [x0, #0x23]
    // 0xa61b24: DecompressPointer r1
    //     0xa61b24: add             x1, x1, HEAP, lsl #32
    // 0xa61b28: LoadField: r2 = r1->field_f
    //     0xa61b28: ldur            x2, [x1, #0xf]
    // 0xa61b2c: LoadField: r3 = r1->field_17
    //     0xa61b2c: ldur            x3, [x1, #0x17]
    // 0xa61b30: cmp             x2, x3
    // 0xa61b34: b.eq            #0xa61b48
    // 0xa61b38: ldr             x16, [fp, #0x10]
    // 0xa61b3c: SaveReg r16
    //     0xa61b3c: str             x16, [SP, #-8]!
    // 0xa61b40: r0 = _updateSnackBar()
    //     0xa61b40: bl              #0x84f570  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateSnackBar
    // 0xa61b44: add             SP, SP, #8
    // 0xa61b48: ldr             x0, [fp, #0x18]
    // 0xa61b4c: LoadField: r1 = r0->field_1f
    //     0xa61b4c: ldur            w1, [x0, #0x1f]
    // 0xa61b50: DecompressPointer r1
    //     0xa61b50: add             x1, x1, HEAP, lsl #32
    // 0xa61b54: LoadField: r0 = r1->field_f
    //     0xa61b54: ldur            x0, [x1, #0xf]
    // 0xa61b58: LoadField: r2 = r1->field_17
    //     0xa61b58: ldur            x2, [x1, #0x17]
    // 0xa61b5c: cmp             x0, x2
    // 0xa61b60: b.eq            #0xa61b74
    // 0xa61b64: ldr             x16, [fp, #0x10]
    // 0xa61b68: SaveReg r16
    //     0xa61b68: str             x16, [SP, #-8]!
    // 0xa61b6c: r0 = _updateMaterialBanner()
    //     0xa61b6c: bl              #0xa61b8c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateMaterialBanner
    // 0xa61b70: add             SP, SP, #8
    // 0xa61b74: r0 = Null
    //     0xa61b74: mov             x0, NULL
    // 0xa61b78: LeaveFrame
    //     0xa61b78: mov             SP, fp
    //     0xa61b7c: ldp             fp, lr, [SP], #0x10
    // 0xa61b80: ret
    //     0xa61b80: ret             
    // 0xa61b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61b84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61b88: b               #0xa61ae8
  }
  _ _isRoot(/* No info */) {
    // ** addr: 0xa61cb4, size: 0x88
    // 0xa61cb4: EnterFrame
    //     0xa61cb4: stp             fp, lr, [SP, #-0x10]!
    //     0xa61cb8: mov             fp, SP
    // 0xa61cbc: CheckStackOverflow
    //     0xa61cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61cc0: cmp             SP, x16
    //     0xa61cc4: b.ls            #0xa61d30
    // 0xa61cc8: ldr             x0, [fp, #0x10]
    // 0xa61ccc: LoadField: r1 = r0->field_f
    //     0xa61ccc: ldur            w1, [x0, #0xf]
    // 0xa61cd0: DecompressPointer r1
    //     0xa61cd0: add             x1, x1, HEAP, lsl #32
    // 0xa61cd4: cmp             w1, NULL
    // 0xa61cd8: b.eq            #0xa61d38
    // 0xa61cdc: r16 = <ScaffoldState<Scaffold>>
    //     0xa61cdc: add             x16, PP, #0x21, lsl #12  ; [pp+0x21fc0] TypeArguments: <ScaffoldState<Scaffold>>
    //     0xa61ce0: ldr             x16, [x16, #0xfc0]
    // 0xa61ce4: stp             x1, x16, [SP, #-0x10]!
    // 0xa61ce8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xa61ce8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xa61cec: r0 = findAncestorStateOfType()
    //     0xa61cec: bl              #0x594348  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0xa61cf0: add             SP, SP, #0x10
    // 0xa61cf4: cmp             w0, NULL
    // 0xa61cf8: b.ne            #0xa61d04
    // 0xa61cfc: r0 = true
    //     0xa61cfc: add             x0, NULL, #0x20  ; true
    // 0xa61d00: b               #0xa61d24
    // 0xa61d04: ldr             x1, [fp, #0x18]
    // 0xa61d08: LoadField: r2 = r1->field_1b
    //     0xa61d08: ldur            w2, [x1, #0x1b]
    // 0xa61d0c: DecompressPointer r2
    //     0xa61d0c: add             x2, x2, HEAP, lsl #32
    // 0xa61d10: stp             x0, x2, [SP, #-0x10]!
    // 0xa61d14: r0 = contains()
    //     0xa61d14: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xa61d18: add             SP, SP, #0x10
    // 0xa61d1c: eor             x1, x0, #0x10
    // 0xa61d20: mov             x0, x1
    // 0xa61d24: LeaveFrame
    //     0xa61d24: mov             SP, fp
    //     0xa61d28: ldp             fp, lr, [SP], #0x10
    // 0xa61d2c: ret
    //     0xa61d2c: ret             
    // 0xa61d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61d30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61d34: b               #0xa61cc8
    // 0xa61d38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61d38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3525, size: 0x14, field offset: 0x10
//   const constructor, 
class _ScaffoldScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa87cc8, size: 0x74
    // 0xa87cc8: EnterFrame
    //     0xa87cc8: stp             fp, lr, [SP, #-0x10]!
    //     0xa87ccc: mov             fp, SP
    // 0xa87cd0: ldr             x0, [fp, #0x10]
    // 0xa87cd4: r2 = Null
    //     0xa87cd4: mov             x2, NULL
    // 0xa87cd8: r1 = Null
    //     0xa87cd8: mov             x1, NULL
    // 0xa87cdc: r4 = 59
    //     0xa87cdc: mov             x4, #0x3b
    // 0xa87ce0: branchIfSmi(r0, 0xa87cec)
    //     0xa87ce0: tbz             w0, #0, #0xa87cec
    // 0xa87ce4: r4 = LoadClassIdInstr(r0)
    //     0xa87ce4: ldur            x4, [x0, #-1]
    //     0xa87ce8: ubfx            x4, x4, #0xc, #0x14
    // 0xa87cec: cmp             x4, #0xdc5
    // 0xa87cf0: b.eq            #0xa87d08
    // 0xa87cf4: r8 = _ScaffoldScope
    //     0xa87cf4: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2dfe8] Type: _ScaffoldScope
    //     0xa87cf8: ldr             x8, [x8, #0xfe8]
    // 0xa87cfc: r3 = Null
    //     0xa87cfc: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2dff0] Null
    //     0xa87d00: ldr             x3, [x3, #0xff0]
    // 0xa87d04: r0 = DefaultTypeTest()
    //     0xa87d04: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa87d08: ldr             x1, [fp, #0x18]
    // 0xa87d0c: LoadField: r2 = r1->field_f
    //     0xa87d0c: ldur            w2, [x1, #0xf]
    // 0xa87d10: DecompressPointer r2
    //     0xa87d10: add             x2, x2, HEAP, lsl #32
    // 0xa87d14: ldr             x1, [fp, #0x10]
    // 0xa87d18: LoadField: r3 = r1->field_f
    //     0xa87d18: ldur            w3, [x1, #0xf]
    // 0xa87d1c: DecompressPointer r3
    //     0xa87d1c: add             x3, x3, HEAP, lsl #32
    // 0xa87d20: cmp             w2, w3
    // 0xa87d24: r16 = true
    //     0xa87d24: add             x16, NULL, #0x20  ; true
    // 0xa87d28: r17 = false
    //     0xa87d28: add             x17, NULL, #0x30  ; false
    // 0xa87d2c: csel            x0, x16, x17, ne
    // 0xa87d30: LeaveFrame
    //     0xa87d30: mov             SP, fp
    //     0xa87d34: ldp             fp, lr, [SP], #0x10
    // 0xa87d38: ret
    //     0xa87d38: ret             
  }
}

// class id: 3526, size: 0x14, field offset: 0x10
//   const constructor, 
class _ScaffoldMessengerScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa87c54, size: 0x74
    // 0xa87c54: EnterFrame
    //     0xa87c54: stp             fp, lr, [SP, #-0x10]!
    //     0xa87c58: mov             fp, SP
    // 0xa87c5c: ldr             x0, [fp, #0x10]
    // 0xa87c60: r2 = Null
    //     0xa87c60: mov             x2, NULL
    // 0xa87c64: r1 = Null
    //     0xa87c64: mov             x1, NULL
    // 0xa87c68: r4 = 59
    //     0xa87c68: mov             x4, #0x3b
    // 0xa87c6c: branchIfSmi(r0, 0xa87c78)
    //     0xa87c6c: tbz             w0, #0, #0xa87c78
    // 0xa87c70: r4 = LoadClassIdInstr(r0)
    //     0xa87c70: ldur            x4, [x0, #-1]
    //     0xa87c74: ubfx            x4, x4, #0xc, #0x14
    // 0xa87c78: cmp             x4, #0xdc6
    // 0xa87c7c: b.eq            #0xa87c94
    // 0xa87c80: r8 = _ScaffoldMessengerScope
    //     0xa87c80: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e198] Type: _ScaffoldMessengerScope
    //     0xa87c84: ldr             x8, [x8, #0x198]
    // 0xa87c88: r3 = Null
    //     0xa87c88: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e1a0] Null
    //     0xa87c8c: ldr             x3, [x3, #0x1a0]
    // 0xa87c90: r0 = DefaultTypeTest()
    //     0xa87c90: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa87c94: ldr             x1, [fp, #0x18]
    // 0xa87c98: LoadField: r2 = r1->field_f
    //     0xa87c98: ldur            w2, [x1, #0xf]
    // 0xa87c9c: DecompressPointer r2
    //     0xa87c9c: add             x2, x2, HEAP, lsl #32
    // 0xa87ca0: ldr             x1, [fp, #0x10]
    // 0xa87ca4: LoadField: r3 = r1->field_f
    //     0xa87ca4: ldur            w3, [x1, #0xf]
    // 0xa87ca8: DecompressPointer r3
    //     0xa87ca8: add             x3, x3, HEAP, lsl #32
    // 0xa87cac: cmp             w2, w3
    // 0xa87cb0: r16 = true
    //     0xa87cb0: add             x16, NULL, #0x20  ; true
    // 0xa87cb4: r17 = false
    //     0xa87cb4: add             x17, NULL, #0x30  ; false
    // 0xa87cb8: csel            x0, x16, x17, ne
    // 0xa87cbc: LeaveFrame
    //     0xa87cbc: mov             SP, fp
    //     0xa87cc0: ldp             fp, lr, [SP], #0x10
    // 0xa87cc4: ret
    //     0xa87cc4: ret             
  }
}

// class id: 3845, size: 0x18, field offset: 0xc
//   const constructor, 
class _BodyBuilder extends StatelessWidget {
}

// class id: 4123, size: 0x3c, field offset: 0xc
//   const constructor, 
class _StandardBottomSheet extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa415ac, size: 0x2c
    // 0xa415ac: EnterFrame
    //     0xa415ac: stp             fp, lr, [SP, #-0x10]!
    //     0xa415b0: mov             fp, SP
    // 0xa415b4: r1 = <_StandardBottomSheet>
    //     0xa415b4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cfb0] TypeArguments: <_StandardBottomSheet>
    //     0xa415b8: ldr             x1, [x1, #0xfb0]
    // 0xa415bc: r0 = _StandardBottomSheetState()
    //     0xa415bc: bl              #0xa415d8  ; Allocate_StandardBottomSheetStateStub -> _StandardBottomSheetState (size=0x18)
    // 0xa415c0: r1 = Instance_Cubic
    //     0xa415c0: add             x1, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0xa415c4: ldr             x1, [x1, #0x2c8]
    // 0xa415c8: StoreField: r0->field_13 = r1
    //     0xa415c8: stur            w1, [x0, #0x13]
    // 0xa415cc: LeaveFrame
    //     0xa415cc: mov             SP, fp
    //     0xa415d0: ldp             fp, lr, [SP], #0x10
    // 0xa415d4: ret
    //     0xa415d4: ret             
  }
}

// class id: 4124, size: 0x6c, field offset: 0xc
//   const constructor, 
class Scaffold extends StatefulWidget {

  static _ maybeOf(/* No info */) {
    // ** addr: 0x8489e0, size: 0x44
    // 0x8489e0: EnterFrame
    //     0x8489e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8489e4: mov             fp, SP
    // 0x8489e8: CheckStackOverflow
    //     0x8489e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8489ec: cmp             SP, x16
    //     0x8489f0: b.ls            #0x848a1c
    // 0x8489f4: r16 = <ScaffoldState<Scaffold>>
    //     0x8489f4: add             x16, PP, #0x21, lsl #12  ; [pp+0x21fc0] TypeArguments: <ScaffoldState<Scaffold>>
    //     0x8489f8: ldr             x16, [x16, #0xfc0]
    // 0x8489fc: ldr             lr, [fp, #0x10]
    // 0x848a00: stp             lr, x16, [SP, #-0x10]!
    // 0x848a04: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x848a04: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x848a08: r0 = findAncestorStateOfType()
    //     0x848a08: bl              #0x594348  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0x848a0c: add             SP, SP, #0x10
    // 0x848a10: LeaveFrame
    //     0x848a10: mov             SP, fp
    //     0x848a14: ldp             fp, lr, [SP], #0x10
    // 0x848a18: ret
    //     0x848a18: ret             
    // 0x848a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848a1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848a20: b               #0x8489f4
  }
  static _ of(/* No info */) {
    // ** addr: 0x848d60, size: 0x17c
    // 0x848d60: EnterFrame
    //     0x848d60: stp             fp, lr, [SP, #-0x10]!
    //     0x848d64: mov             fp, SP
    // 0x848d68: AllocStack(0x30)
    //     0x848d68: sub             SP, SP, #0x30
    // 0x848d6c: CheckStackOverflow
    //     0x848d6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848d70: cmp             SP, x16
    //     0x848d74: b.ls            #0x848ed4
    // 0x848d78: r16 = <ScaffoldState<Scaffold>>
    //     0x848d78: add             x16, PP, #0x21, lsl #12  ; [pp+0x21fc0] TypeArguments: <ScaffoldState<Scaffold>>
    //     0x848d7c: ldr             x16, [x16, #0xfc0]
    // 0x848d80: ldr             lr, [fp, #0x10]
    // 0x848d84: stp             lr, x16, [SP, #-0x10]!
    // 0x848d88: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x848d88: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x848d8c: r0 = findAncestorStateOfType()
    //     0x848d8c: bl              #0x594348  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0x848d90: add             SP, SP, #0x10
    // 0x848d94: cmp             w0, NULL
    // 0x848d98: b.eq            #0x848da8
    // 0x848d9c: LeaveFrame
    //     0x848d9c: mov             SP, fp
    //     0x848da0: ldp             fp, lr, [SP], #0x10
    // 0x848da4: ret
    //     0x848da4: ret             
    // 0x848da8: r1 = <List<Object>>
    //     0x848da8: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x848dac: r0 = ErrorSummary()
    //     0x848dac: bl              #0x59f04c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x30)
    // 0x848db0: stur            x0, [fp, #-8]
    // 0x848db4: r16 = "Scaffold.of() called with a context that does not contain a Scaffold."
    //     0x848db4: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a48] "Scaffold.of() called with a context that does not contain a Scaffold."
    //     0x848db8: ldr             x16, [x16, #0xa48]
    // 0x848dbc: stp             x16, x0, [SP, #-0x10]!
    // 0x848dc0: r16 = Instance_DiagnosticLevel
    //     0x848dc0: ldr             x16, [PP, #0x43f0]  ; [pp+0x43f0] Obj!DiagnosticLevel@b65db1
    // 0x848dc4: SaveReg r16
    //     0x848dc4: str             x16, [SP, #-8]!
    // 0x848dc8: r0 = _ErrorDiagnostic()
    //     0x848dc8: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x848dcc: add             SP, SP, #0x18
    // 0x848dd0: r1 = <List<Object>>
    //     0x848dd0: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x848dd4: r0 = ErrorDescription()
    //     0x848dd4: bl              #0x500e70  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x30)
    // 0x848dd8: stur            x0, [fp, #-0x10]
    // 0x848ddc: r16 = "No Scaffold ancestor could be found starting from the context that was passed to Scaffold.of(). This usually happens when the context provided is from the same StatefulWidget as that whose build function actually creates the Scaffold widget being sought."
    //     0x848ddc: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a50] "No Scaffold ancestor could be found starting from the context that was passed to Scaffold.of(). This usually happens when the context provided is from the same StatefulWidget as that whose build function actually creates the Scaffold widget being sought."
    //     0x848de0: ldr             x16, [x16, #0xa50]
    // 0x848de4: stp             x16, x0, [SP, #-0x10]!
    // 0x848de8: r16 = Instance_DiagnosticLevel
    //     0x848de8: ldr             x16, [PP, #0xee8]  ; [pp+0xee8] Obj!DiagnosticLevel@b65d91
    // 0x848dec: SaveReg r16
    //     0x848dec: str             x16, [SP, #-8]!
    // 0x848df0: r0 = _ErrorDiagnostic()
    //     0x848df0: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x848df4: add             SP, SP, #0x18
    // 0x848df8: r1 = <List<Object>>
    //     0x848df8: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x848dfc: r0 = ErrorHint()
    //     0x848dfc: bl              #0x5e0aa8  ; AllocateErrorHintStub -> ErrorHint (size=0x30)
    // 0x848e00: stur            x0, [fp, #-0x18]
    // 0x848e04: r16 = "There are several ways to avoid this problem. The simplest is to use a Builder to get a context that is \"under\" the Scaffold. For an example of this, please see the documentation for Scaffold.of():\n  https://api.flutter.dev/flutter/material/Scaffold/of.html"
    //     0x848e04: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a58] "There are several ways to avoid this problem. The simplest is to use a Builder to get a context that is \"under\" the Scaffold. For an example of this, please see the documentation for Scaffold.of():\n  https://api.flutter.dev/flutter/material/Scaffold/of.html"
    //     0x848e08: ldr             x16, [x16, #0xa58]
    // 0x848e0c: stp             x16, x0, [SP, #-0x10]!
    // 0x848e10: r16 = Instance_DiagnosticLevel
    //     0x848e10: ldr             x16, [PP, #0x3d38]  ; [pp+0x3d38] Obj!DiagnosticLevel@b65dd1
    // 0x848e14: SaveReg r16
    //     0x848e14: str             x16, [SP, #-8]!
    // 0x848e18: r0 = _ErrorDiagnostic()
    //     0x848e18: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x848e1c: add             SP, SP, #0x18
    // 0x848e20: r1 = <List<Object>>
    //     0x848e20: ldr             x1, [PP, #0xed8]  ; [pp+0xed8] TypeArguments: <List<Object>>
    // 0x848e24: r0 = ErrorHint()
    //     0x848e24: bl              #0x5e0aa8  ; AllocateErrorHintStub -> ErrorHint (size=0x30)
    // 0x848e28: stur            x0, [fp, #-0x20]
    // 0x848e2c: r16 = "A more efficient solution is to split your build function into several widgets. This introduces a new context from which you can obtain the Scaffold. In this solution, you would have an outer widget that creates the Scaffold populated by instances of your new inner widgets, and then in these inner widgets you would use Scaffold.of().\nA less elegant but more expedient solution is assign a GlobalKey to the Scaffold, then use the key.currentState property to obtain the ScaffoldState rather than using the Scaffold.of() function."
    //     0x848e2c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37a60] "A more efficient solution is to split your build function into several widgets. This introduces a new context from which you can obtain the Scaffold. In this solution, you would have an outer widget that creates the Scaffold populated by instances of your new inner widgets, and then in these inner widgets you would use Scaffold.of().\nA less elegant but more expedient solution is assign a GlobalKey to the Scaffold, then use the key.currentState property to obtain the ScaffoldState rather than using the Scaffold.of() function."
    //     0x848e30: ldr             x16, [x16, #0xa60]
    // 0x848e34: stp             x16, x0, [SP, #-0x10]!
    // 0x848e38: r16 = Instance_DiagnosticLevel
    //     0x848e38: ldr             x16, [PP, #0x3d38]  ; [pp+0x3d38] Obj!DiagnosticLevel@b65dd1
    // 0x848e3c: SaveReg r16
    //     0x848e3c: str             x16, [SP, #-8]!
    // 0x848e40: r0 = _ErrorDiagnostic()
    //     0x848e40: bl              #0x500dcc  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x848e44: add             SP, SP, #0x18
    // 0x848e48: ldr             x16, [fp, #0x10]
    // 0x848e4c: SaveReg r16
    //     0x848e4c: str             x16, [SP, #-8]!
    // 0x848e50: r0 = describeElement()
    //     0x848e50: bl              #0x5e0ab4  ; [package:flutter/src/widgets/framework.dart] Element::describeElement
    // 0x848e54: add             SP, SP, #8
    // 0x848e58: r1 = Null
    //     0x848e58: mov             x1, NULL
    // 0x848e5c: r2 = 10
    //     0x848e5c: mov             x2, #0xa
    // 0x848e60: stur            x0, [fp, #-0x28]
    // 0x848e64: r0 = AllocateArray()
    //     0x848e64: bl              #0xd6987c  ; AllocateArrayStub
    // 0x848e68: mov             x2, x0
    // 0x848e6c: ldur            x0, [fp, #-8]
    // 0x848e70: stur            x2, [fp, #-0x30]
    // 0x848e74: StoreField: r2->field_f = r0
    //     0x848e74: stur            w0, [x2, #0xf]
    // 0x848e78: ldur            x0, [fp, #-0x10]
    // 0x848e7c: StoreField: r2->field_13 = r0
    //     0x848e7c: stur            w0, [x2, #0x13]
    // 0x848e80: ldur            x0, [fp, #-0x18]
    // 0x848e84: StoreField: r2->field_17 = r0
    //     0x848e84: stur            w0, [x2, #0x17]
    // 0x848e88: ldur            x0, [fp, #-0x20]
    // 0x848e8c: StoreField: r2->field_1b = r0
    //     0x848e8c: stur            w0, [x2, #0x1b]
    // 0x848e90: ldur            x0, [fp, #-0x28]
    // 0x848e94: StoreField: r2->field_1f = r0
    //     0x848e94: stur            w0, [x2, #0x1f]
    // 0x848e98: r1 = <DiagnosticsNode>
    //     0x848e98: ldr             x1, [PP, #0x3930]  ; [pp+0x3930] TypeArguments: <DiagnosticsNode>
    // 0x848e9c: r0 = AllocateGrowableArray()
    //     0x848e9c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x848ea0: mov             x1, x0
    // 0x848ea4: ldur            x0, [fp, #-0x30]
    // 0x848ea8: stur            x1, [fp, #-8]
    // 0x848eac: StoreField: r1->field_f = r0
    //     0x848eac: stur            w0, [x1, #0xf]
    // 0x848eb0: r0 = 10
    //     0x848eb0: mov             x0, #0xa
    // 0x848eb4: StoreField: r1->field_b = r0
    //     0x848eb4: stur            w0, [x1, #0xb]
    // 0x848eb8: r0 = FlutterError()
    //     0x848eb8: bl              #0x59f040  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0x848ebc: mov             x1, x0
    // 0x848ec0: ldur            x0, [fp, #-8]
    // 0x848ec4: StoreField: r1->field_b = r0
    //     0x848ec4: stur            w0, [x1, #0xb]
    // 0x848ec8: mov             x0, x1
    // 0x848ecc: r0 = Throw()
    //     0x848ecc: bl              #0xd67e38  ; ThrowStub
    // 0x848ed0: brk             #0
    // 0x848ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848ed4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848ed8: b               #0x848d78
  }
  _ createState(/* No info */) {
    // ** addr: 0xa41300, size: 0x4c
    // 0xa41300: EnterFrame
    //     0xa41300: stp             fp, lr, [SP, #-0x10]!
    //     0xa41304: mov             fp, SP
    // 0xa41308: AllocStack(0x8)
    //     0xa41308: sub             SP, SP, #8
    // 0xa4130c: CheckStackOverflow
    //     0xa4130c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa41310: cmp             SP, x16
    //     0xa41314: b.ls            #0xa41344
    // 0xa41318: r1 = <Scaffold>
    //     0xa41318: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cfa0] TypeArguments: <Scaffold>
    //     0xa4131c: ldr             x1, [x1, #0xfa0]
    // 0xa41320: r0 = ScaffoldState()
    //     0xa41320: bl              #0xa415a0  ; AllocateScaffoldStateStub -> ScaffoldState (size=0x80)
    // 0xa41324: stur            x0, [fp, #-8]
    // 0xa41328: SaveReg r0
    //     0xa41328: str             x0, [SP, #-8]!
    // 0xa4132c: r0 = ScaffoldState()
    //     0xa4132c: bl              #0xa4134c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::ScaffoldState
    // 0xa41330: add             SP, SP, #8
    // 0xa41334: ldur            x0, [fp, #-8]
    // 0xa41338: LeaveFrame
    //     0xa41338: mov             SP, fp
    //     0xa4133c: ldp             fp, lr, [SP], #0x10
    // 0xa41340: ret
    //     0xa41340: ret             
    // 0xa41344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa41344: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa41348: b               #0xa41318
  }
}

// class id: 4125, size: 0x20, field offset: 0xc
//   const constructor, 
class _FloatingActionButtonTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa412b8, size: 0x3c
    // 0xa412b8: EnterFrame
    //     0xa412b8: stp             fp, lr, [SP, #-0x10]!
    //     0xa412bc: mov             fp, SP
    // 0xa412c0: r1 = <_FloatingActionButtonTransition>
    //     0xa412c0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28990] TypeArguments: <_FloatingActionButtonTransition>
    //     0xa412c4: ldr             x1, [x1, #0x990]
    // 0xa412c8: r0 = _FloatingActionButtonTransitionState()
    //     0xa412c8: bl              #0xa412f4  ; Allocate_FloatingActionButtonTransitionStateStub -> _FloatingActionButtonTransitionState (size=0x38)
    // 0xa412cc: r1 = Sentinel
    //     0xa412cc: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa412d0: StoreField: r0->field_1b = r1
    //     0xa412d0: stur            w1, [x0, #0x1b]
    // 0xa412d4: StoreField: r0->field_1f = r1
    //     0xa412d4: stur            w1, [x0, #0x1f]
    // 0xa412d8: StoreField: r0->field_23 = r1
    //     0xa412d8: stur            w1, [x0, #0x23]
    // 0xa412dc: StoreField: r0->field_27 = r1
    //     0xa412dc: stur            w1, [x0, #0x27]
    // 0xa412e0: StoreField: r0->field_2b = r1
    //     0xa412e0: stur            w1, [x0, #0x2b]
    // 0xa412e4: StoreField: r0->field_2f = r1
    //     0xa412e4: stur            w1, [x0, #0x2f]
    // 0xa412e8: LeaveFrame
    //     0xa412e8: mov             SP, fp
    //     0xa412ec: ldp             fp, lr, [SP], #0x10
    // 0xa412f0: ret
    //     0xa412f0: ret             
  }
}

// class id: 4126, size: 0x10, field offset: 0xc
//   const constructor, 
class ScaffoldMessenger extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa40f40, size: 0x4c
    // 0xa40f40: EnterFrame
    //     0xa40f40: stp             fp, lr, [SP, #-0x10]!
    //     0xa40f44: mov             fp, SP
    // 0xa40f48: AllocStack(0x8)
    //     0xa40f48: sub             SP, SP, #8
    // 0xa40f4c: CheckStackOverflow
    //     0xa40f4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa40f50: cmp             SP, x16
    //     0xa40f54: b.ls            #0xa40f84
    // 0xa40f58: r1 = <ScaffoldMessenger>
    //     0xa40f58: add             x1, PP, #0x22, lsl #12  ; [pp+0x22000] TypeArguments: <ScaffoldMessenger>
    //     0xa40f5c: ldr             x1, [x1]
    // 0xa40f60: r0 = ScaffoldMessengerState()
    //     0xa40f60: bl              #0xa412ac  ; AllocateScaffoldMessengerStateStub -> ScaffoldMessengerState (size=0x34)
    // 0xa40f64: stur            x0, [fp, #-8]
    // 0xa40f68: SaveReg r0
    //     0xa40f68: str             x0, [SP, #-8]!
    // 0xa40f6c: r0 = ScaffoldMessengerState()
    //     0xa40f6c: bl              #0xa40f8c  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::ScaffoldMessengerState
    // 0xa40f70: add             SP, SP, #8
    // 0xa40f74: ldur            x0, [fp, #-8]
    // 0xa40f78: LeaveFrame
    //     0xa40f78: mov             SP, fp
    //     0xa40f7c: ldp             fp, lr, [SP], #0x10
    // 0xa40f80: ret
    //     0xa40f80: ret             
    // 0xa40f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa40f84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa40f88: b               #0xa40f58
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xa61d3c, size: 0x60
    // 0xa61d3c: EnterFrame
    //     0xa61d3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa61d40: mov             fp, SP
    // 0xa61d44: CheckStackOverflow
    //     0xa61d44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61d48: cmp             SP, x16
    //     0xa61d4c: b.ls            #0xa61d94
    // 0xa61d50: r16 = <_ScaffoldMessengerScope>
    //     0xa61d50: add             x16, PP, #0x21, lsl #12  ; [pp+0x21fc8] TypeArguments: <_ScaffoldMessengerScope>
    //     0xa61d54: ldr             x16, [x16, #0xfc8]
    // 0xa61d58: ldr             lr, [fp, #0x10]
    // 0xa61d5c: stp             lr, x16, [SP, #-0x10]!
    // 0xa61d60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xa61d60: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xa61d64: r0 = dependOnInheritedWidgetOfExactType()
    //     0xa61d64: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xa61d68: add             SP, SP, #0x10
    // 0xa61d6c: cmp             w0, NULL
    // 0xa61d70: b.ne            #0xa61d7c
    // 0xa61d74: r0 = Null
    //     0xa61d74: mov             x0, NULL
    // 0xa61d78: b               #0xa61d88
    // 0xa61d7c: LoadField: r1 = r0->field_f
    //     0xa61d7c: ldur            w1, [x0, #0xf]
    // 0xa61d80: DecompressPointer r1
    //     0xa61d80: add             x1, x1, HEAP, lsl #32
    // 0xa61d84: mov             x0, x1
    // 0xa61d88: LeaveFrame
    //     0xa61d88: mov             SP, fp
    //     0xa61d8c: ldp             fp, lr, [SP], #0x10
    // 0xa61d90: ret
    //     0xa61d90: ret             
    // 0xa61d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61d94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61d98: b               #0xa61d50
  }
}

// class id: 4279, size: 0x18, field offset: 0xc
//   const constructor, 
class _BottomSheetSuspendedCurve extends ParametricCurve<double> {

  _ toString(/* No info */) {
    // ** addr: 0xad5cd4, size: 0xd8
    // 0xad5cd4: EnterFrame
    //     0xad5cd4: stp             fp, lr, [SP, #-0x10]!
    //     0xad5cd8: mov             fp, SP
    // 0xad5cdc: AllocStack(0x8)
    //     0xad5cdc: sub             SP, SP, #8
    // 0xad5ce0: CheckStackOverflow
    //     0xad5ce0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5ce4: cmp             SP, x16
    //     0xad5ce8: b.ls            #0xad5d88
    // 0xad5cec: ldr             x16, [fp, #0x10]
    // 0xad5cf0: SaveReg r16
    //     0xad5cf0: str             x16, [SP, #-8]!
    // 0xad5cf4: r0 = describeIdentity()
    //     0xad5cf4: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xad5cf8: add             SP, SP, #8
    // 0xad5cfc: r1 = Null
    //     0xad5cfc: mov             x1, NULL
    // 0xad5d00: r2 = 12
    //     0xad5d00: mov             x2, #0xc
    // 0xad5d04: stur            x0, [fp, #-8]
    // 0xad5d08: r0 = AllocateArray()
    //     0xad5d08: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5d0c: mov             x1, x0
    // 0xad5d10: ldur            x0, [fp, #-8]
    // 0xad5d14: StoreField: r1->field_f = r0
    //     0xad5d14: stur            w0, [x1, #0xf]
    // 0xad5d18: r17 = "("
    //     0xad5d18: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad5d1c: StoreField: r1->field_13 = r17
    //     0xad5d1c: stur            w17, [x1, #0x13]
    // 0xad5d20: ldr             x0, [fp, #0x10]
    // 0xad5d24: LoadField: d0 = r0->field_b
    //     0xad5d24: ldur            d0, [x0, #0xb]
    // 0xad5d28: r2 = inline_Allocate_Double()
    //     0xad5d28: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xad5d2c: add             x2, x2, #0x10
    //     0xad5d30: cmp             x3, x2
    //     0xad5d34: b.ls            #0xad5d90
    //     0xad5d38: str             x2, [THR, #0x60]  ; THR::top
    //     0xad5d3c: sub             x2, x2, #0xf
    //     0xad5d40: mov             x3, #0xd108
    //     0xad5d44: movk            x3, #3, lsl #16
    //     0xad5d48: stur            x3, [x2, #-1]
    // 0xad5d4c: StoreField: r2->field_7 = d0
    //     0xad5d4c: stur            d0, [x2, #7]
    // 0xad5d50: StoreField: r1->field_17 = r2
    //     0xad5d50: stur            w2, [x1, #0x17]
    // 0xad5d54: r17 = ", "
    //     0xad5d54: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xad5d58: StoreField: r1->field_1b = r17
    //     0xad5d58: stur            w17, [x1, #0x1b]
    // 0xad5d5c: LoadField: r2 = r0->field_13
    //     0xad5d5c: ldur            w2, [x0, #0x13]
    // 0xad5d60: DecompressPointer r2
    //     0xad5d60: add             x2, x2, HEAP, lsl #32
    // 0xad5d64: StoreField: r1->field_1f = r2
    //     0xad5d64: stur            w2, [x1, #0x1f]
    // 0xad5d68: r17 = ")"
    //     0xad5d68: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad5d6c: StoreField: r1->field_23 = r17
    //     0xad5d6c: stur            w17, [x1, #0x23]
    // 0xad5d70: SaveReg r1
    //     0xad5d70: str             x1, [SP, #-8]!
    // 0xad5d74: r0 = _interpolate()
    //     0xad5d74: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5d78: add             SP, SP, #8
    // 0xad5d7c: LeaveFrame
    //     0xad5d7c: mov             SP, fp
    //     0xad5d80: ldp             fp, lr, [SP], #0x10
    // 0xad5d84: ret
    //     0xad5d84: ret             
    // 0xad5d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5d88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5d8c: b               #0xad5cec
    // 0xad5d90: SaveReg d0
    //     0xad5d90: str             q0, [SP, #-0x10]!
    // 0xad5d94: stp             x0, x1, [SP, #-0x10]!
    // 0xad5d98: r0 = AllocateDouble()
    //     0xad5d98: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad5d9c: mov             x2, x0
    // 0xad5da0: ldp             x0, x1, [SP], #0x10
    // 0xad5da4: RestoreReg d0
    //     0xad5da4: ldr             q0, [SP], #0x10
    // 0xad5da8: b               #0xad5d4c
  }
  _ transform(/* No info */) {
    // ** addr: 0xc50a78, size: 0x16c
    // 0xc50a78: EnterFrame
    //     0xc50a78: stp             fp, lr, [SP, #-0x10]!
    //     0xc50a7c: mov             fp, SP
    // 0xc50a80: AllocStack(0x8)
    //     0xc50a80: sub             SP, SP, #8
    // 0xc50a84: CheckStackOverflow
    //     0xc50a84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc50a88: cmp             SP, x16
    //     0xc50a8c: b.ls            #0xc50b9c
    // 0xc50a90: ldr             x0, [fp, #0x18]
    // 0xc50a94: LoadField: d0 = r0->field_b
    //     0xc50a94: ldur            d0, [x0, #0xb]
    // 0xc50a98: ldr             d1, [fp, #0x10]
    // 0xc50a9c: stur            d0, [fp, #-8]
    // 0xc50aa0: fcmp            d1, d0
    // 0xc50aa4: b.vs            #0xc50ae0
    // 0xc50aa8: b.ge            #0xc50ae0
    // 0xc50aac: r0 = inline_Allocate_Double()
    //     0xc50aac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc50ab0: add             x0, x0, #0x10
    //     0xc50ab4: cmp             x1, x0
    //     0xc50ab8: b.ls            #0xc50ba4
    //     0xc50abc: str             x0, [THR, #0x60]  ; THR::top
    //     0xc50ac0: sub             x0, x0, #0xf
    //     0xc50ac4: mov             x1, #0xd108
    //     0xc50ac8: movk            x1, #3, lsl #16
    //     0xc50acc: stur            x1, [x0, #-1]
    // 0xc50ad0: StoreField: r0->field_7 = d1
    //     0xc50ad0: stur            d1, [x0, #7]
    // 0xc50ad4: LeaveFrame
    //     0xc50ad4: mov             SP, fp
    //     0xc50ad8: ldp             fp, lr, [SP], #0x10
    // 0xc50adc: ret
    //     0xc50adc: ret             
    // 0xc50ae0: d2 = 1.000000
    //     0xc50ae0: fmov            d2, #1.00000000
    // 0xc50ae4: fcmp            d1, d2
    // 0xc50ae8: b.vs            #0xc50b24
    // 0xc50aec: b.ne            #0xc50b24
    // 0xc50af0: r0 = inline_Allocate_Double()
    //     0xc50af0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc50af4: add             x0, x0, #0x10
    //     0xc50af8: cmp             x1, x0
    //     0xc50afc: b.ls            #0xc50bb4
    //     0xc50b00: str             x0, [THR, #0x60]  ; THR::top
    //     0xc50b04: sub             x0, x0, #0xf
    //     0xc50b08: mov             x1, #0xd108
    //     0xc50b0c: movk            x1, #3, lsl #16
    //     0xc50b10: stur            x1, [x0, #-1]
    // 0xc50b14: StoreField: r0->field_7 = d1
    //     0xc50b14: stur            d1, [x0, #7]
    // 0xc50b18: LeaveFrame
    //     0xc50b18: mov             SP, fp
    //     0xc50b1c: ldp             fp, lr, [SP], #0x10
    // 0xc50b20: ret
    //     0xc50b20: ret             
    // 0xc50b24: fsub            d3, d1, d0
    // 0xc50b28: fsub            d1, d2, d0
    // 0xc50b2c: fdiv            d2, d3, d1
    // 0xc50b30: r16 = Instance_Cubic
    //     0xc50b30: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0xc50b34: ldr             x16, [x16, #0x2c8]
    // 0xc50b38: SaveReg r16
    //     0xc50b38: str             x16, [SP, #-8]!
    // 0xc50b3c: SaveReg d2
    //     0xc50b3c: str             d2, [SP, #-8]!
    // 0xc50b40: r0 = transform()
    //     0xc50b40: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xc50b44: add             SP, SP, #0x10
    // 0xc50b48: ldur            d0, [fp, #-8]
    // 0xc50b4c: r1 = inline_Allocate_Double()
    //     0xc50b4c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc50b50: add             x1, x1, #0x10
    //     0xc50b54: cmp             x2, x1
    //     0xc50b58: b.ls            #0xc50bc4
    //     0xc50b5c: str             x1, [THR, #0x60]  ; THR::top
    //     0xc50b60: sub             x1, x1, #0xf
    //     0xc50b64: mov             x2, #0xd108
    //     0xc50b68: movk            x2, #3, lsl #16
    //     0xc50b6c: stur            x2, [x1, #-1]
    // 0xc50b70: StoreField: r1->field_7 = d0
    //     0xc50b70: stur            d0, [x1, #7]
    // 0xc50b74: r16 = 2
    //     0xc50b74: mov             x16, #2
    // 0xc50b78: stp             x16, x1, [SP, #-0x10]!
    // 0xc50b7c: SaveReg r0
    //     0xc50b7c: str             x0, [SP, #-8]!
    // 0xc50b80: r0 = lerpDouble()
    //     0xc50b80: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xc50b84: add             SP, SP, #0x18
    // 0xc50b88: cmp             w0, NULL
    // 0xc50b8c: b.eq            #0xc50be0
    // 0xc50b90: LeaveFrame
    //     0xc50b90: mov             SP, fp
    //     0xc50b94: ldp             fp, lr, [SP], #0x10
    // 0xc50b98: ret
    //     0xc50b98: ret             
    // 0xc50b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc50b9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc50ba0: b               #0xc50a90
    // 0xc50ba4: SaveReg d1
    //     0xc50ba4: str             q1, [SP, #-0x10]!
    // 0xc50ba8: r0 = AllocateDouble()
    //     0xc50ba8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc50bac: RestoreReg d1
    //     0xc50bac: ldr             q1, [SP], #0x10
    // 0xc50bb0: b               #0xc50ad0
    // 0xc50bb4: SaveReg d1
    //     0xc50bb4: str             q1, [SP, #-0x10]!
    // 0xc50bb8: r0 = AllocateDouble()
    //     0xc50bb8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc50bbc: RestoreReg d1
    //     0xc50bbc: ldr             q1, [SP], #0x10
    // 0xc50bc0: b               #0xc50b14
    // 0xc50bc4: SaveReg d0
    //     0xc50bc4: str             q0, [SP, #-0x10]!
    // 0xc50bc8: SaveReg r0
    //     0xc50bc8: str             x0, [SP, #-8]!
    // 0xc50bcc: r0 = AllocateDouble()
    //     0xc50bcc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc50bd0: mov             x1, x0
    // 0xc50bd4: RestoreReg r0
    //     0xc50bd4: ldr             x0, [SP], #8
    // 0xc50bd8: RestoreReg d0
    //     0xc50bd8: ldr             q0, [SP], #0x10
    // 0xc50bdc: b               #0xc50b70
    // 0xc50be0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc50be0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4829, size: 0x2c, field offset: 0x24
class _ScaffoldGeometryNotifier extends ChangeNotifier
    implements ValueListenable<X0> {

  _ _updateWith(/* No info */) {
    // ** addr: 0x7ba400, size: 0x1a8
    // 0x7ba400: EnterFrame
    //     0x7ba400: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba404: mov             fp, SP
    // 0x7ba408: AllocStack(0x8)
    //     0x7ba408: sub             SP, SP, #8
    // 0x7ba40c: SetupParameters(_ScaffoldGeometryNotifier this /* r3, fp-0x8 */, {dynamic bottomNavigationBarTop = Null /* r4 */, dynamic floatingActionButtonArea = Null /* r5 */, dynamic floatingActionButtonScale = Null /* r0 */})
    //     0x7ba40c: mov             x0, x4
    //     0x7ba410: ldur            w1, [x0, #0x13]
    //     0x7ba414: add             x1, x1, HEAP, lsl #32
    //     0x7ba418: sub             x2, x1, #2
    //     0x7ba41c: add             x3, fp, w2, sxtw #2
    //     0x7ba420: ldr             x3, [x3, #0x10]
    //     0x7ba424: stur            x3, [fp, #-8]
    //     0x7ba428: ldur            w2, [x0, #0x1f]
    //     0x7ba42c: add             x2, x2, HEAP, lsl #32
    //     0x7ba430: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e078] "bottomNavigationBarTop"
    //     0x7ba434: ldr             x16, [x16, #0x78]
    //     0x7ba438: cmp             w2, w16
    //     0x7ba43c: b.ne            #0x7ba460
    //     0x7ba440: ldur            w2, [x0, #0x23]
    //     0x7ba444: add             x2, x2, HEAP, lsl #32
    //     0x7ba448: sub             w4, w1, w2
    //     0x7ba44c: add             x2, fp, w4, sxtw #2
    //     0x7ba450: ldr             x2, [x2, #8]
    //     0x7ba454: mov             x4, x2
    //     0x7ba458: mov             x2, #1
    //     0x7ba45c: b               #0x7ba468
    //     0x7ba460: mov             x4, NULL
    //     0x7ba464: mov             x2, #0
    //     0x7ba468: lsl             x5, x2, #1
    //     0x7ba46c: lsl             w6, w5, #1
    //     0x7ba470: add             w7, w6, #8
    //     0x7ba474: add             x16, x0, w7, sxtw #1
    //     0x7ba478: ldur            w8, [x16, #0xf]
    //     0x7ba47c: add             x8, x8, HEAP, lsl #32
    //     0x7ba480: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e080] "floatingActionButtonArea"
    //     0x7ba484: ldr             x16, [x16, #0x80]
    //     0x7ba488: cmp             w8, w16
    //     0x7ba48c: b.ne            #0x7ba4c0
    //     0x7ba490: add             w2, w6, #0xa
    //     0x7ba494: add             x16, x0, w2, sxtw #1
    //     0x7ba498: ldur            w6, [x16, #0xf]
    //     0x7ba49c: add             x6, x6, HEAP, lsl #32
    //     0x7ba4a0: sub             w2, w1, w6
    //     0x7ba4a4: add             x6, fp, w2, sxtw #2
    //     0x7ba4a8: ldr             x6, [x6, #8]
    //     0x7ba4ac: add             w2, w5, #2
    //     0x7ba4b0: sbfx            x5, x2, #1, #0x1f
    //     0x7ba4b4: mov             x2, x5
    //     0x7ba4b8: mov             x5, x6
    //     0x7ba4bc: b               #0x7ba4c4
    //     0x7ba4c0: mov             x5, NULL
    //     0x7ba4c4: lsl             x6, x2, #1
    //     0x7ba4c8: lsl             w2, w6, #1
    //     0x7ba4cc: add             w6, w2, #8
    //     0x7ba4d0: add             x16, x0, w6, sxtw #1
    //     0x7ba4d4: ldur            w7, [x16, #0xf]
    //     0x7ba4d8: add             x7, x7, HEAP, lsl #32
    //     0x7ba4dc: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e088] "floatingActionButtonScale"
    //     0x7ba4e0: ldr             x16, [x16, #0x88]
    //     0x7ba4e4: cmp             w7, w16
    //     0x7ba4e8: b.ne            #0x7ba510
    //     0x7ba4ec: add             w6, w2, #0xa
    //     0x7ba4f0: add             x16, x0, w6, sxtw #1
    //     0x7ba4f4: ldur            w2, [x16, #0xf]
    //     0x7ba4f8: add             x2, x2, HEAP, lsl #32
    //     0x7ba4fc: sub             w0, w1, w2
    //     0x7ba500: add             x1, fp, w0, sxtw #2
    //     0x7ba504: ldr             x1, [x1, #8]
    //     0x7ba508: mov             x0, x1
    //     0x7ba50c: b               #0x7ba514
    //     0x7ba510: mov             x0, NULL
    // 0x7ba514: CheckStackOverflow
    //     0x7ba514: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba518: cmp             SP, x16
    //     0x7ba51c: b.ls            #0x7ba5a0
    // 0x7ba520: cmp             w0, NULL
    // 0x7ba524: b.ne            #0x7ba530
    // 0x7ba528: LoadField: r0 = r3->field_23
    //     0x7ba528: ldur            w0, [x3, #0x23]
    // 0x7ba52c: DecompressPointer r0
    //     0x7ba52c: add             x0, x0, HEAP, lsl #32
    // 0x7ba530: StoreField: r3->field_23 = r0
    //     0x7ba530: stur            w0, [x3, #0x23]
    //     0x7ba534: ldurb           w16, [x3, #-1]
    //     0x7ba538: ldurb           w17, [x0, #-1]
    //     0x7ba53c: and             x16, x17, x16, lsr #2
    //     0x7ba540: tst             x16, HEAP, lsr #32
    //     0x7ba544: b.eq            #0x7ba54c
    //     0x7ba548: bl              #0xd682ac
    // 0x7ba54c: LoadField: r0 = r3->field_27
    //     0x7ba54c: ldur            w0, [x3, #0x27]
    // 0x7ba550: DecompressPointer r0
    //     0x7ba550: add             x0, x0, HEAP, lsl #32
    // 0x7ba554: stp             x4, x0, [SP, #-0x10]!
    // 0x7ba558: SaveReg r5
    //     0x7ba558: str             x5, [SP, #-8]!
    // 0x7ba55c: r0 = copyWith()
    //     0x7ba55c: bl              #0x7ba5a8  ; [package:flutter/src/material/scaffold.dart] ScaffoldGeometry::copyWith
    // 0x7ba560: add             SP, SP, #0x18
    // 0x7ba564: ldur            x1, [fp, #-8]
    // 0x7ba568: StoreField: r1->field_27 = r0
    //     0x7ba568: stur            w0, [x1, #0x27]
    //     0x7ba56c: ldurb           w16, [x1, #-1]
    //     0x7ba570: ldurb           w17, [x0, #-1]
    //     0x7ba574: and             x16, x17, x16, lsr #2
    //     0x7ba578: tst             x16, HEAP, lsr #32
    //     0x7ba57c: b.eq            #0x7ba584
    //     0x7ba580: bl              #0xd6826c
    // 0x7ba584: SaveReg r1
    //     0x7ba584: str             x1, [SP, #-8]!
    // 0x7ba588: r0 = notifyListeners()
    //     0x7ba588: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7ba58c: add             SP, SP, #8
    // 0x7ba590: r0 = Null
    //     0x7ba590: mov             x0, NULL
    // 0x7ba594: LeaveFrame
    //     0x7ba594: mov             SP, fp
    //     0x7ba598: ldp             fp, lr, [SP], #0x10
    // 0x7ba59c: ret
    //     0x7ba59c: ret             
    // 0x7ba5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ba5a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ba5a4: b               #0x7ba520
  }
}

// class id: 5952, size: 0x14, field offset: 0x14
enum _ScaffoldSlot extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16474, size: 0x5c
    // 0xb16474: EnterFrame
    //     0xb16474: stp             fp, lr, [SP, #-0x10]!
    //     0xb16478: mov             fp, SP
    // 0xb1647c: CheckStackOverflow
    //     0xb1647c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16480: cmp             SP, x16
    //     0xb16484: b.ls            #0xb164c8
    // 0xb16488: r1 = Null
    //     0xb16488: mov             x1, NULL
    // 0xb1648c: r2 = 4
    //     0xb1648c: mov             x2, #4
    // 0xb16490: r0 = AllocateArray()
    //     0xb16490: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16494: r17 = "_ScaffoldSlot."
    //     0xb16494: add             x17, PP, #0x28, lsl #12  ; [pp+0x28980] "_ScaffoldSlot."
    //     0xb16498: ldr             x17, [x17, #0x980]
    // 0xb1649c: StoreField: r0->field_f = r17
    //     0xb1649c: stur            w17, [x0, #0xf]
    // 0xb164a0: ldr             x1, [fp, #0x10]
    // 0xb164a4: LoadField: r2 = r1->field_f
    //     0xb164a4: ldur            w2, [x1, #0xf]
    // 0xb164a8: DecompressPointer r2
    //     0xb164a8: add             x2, x2, HEAP, lsl #32
    // 0xb164ac: StoreField: r0->field_13 = r2
    //     0xb164ac: stur            w2, [x0, #0x13]
    // 0xb164b0: SaveReg r0
    //     0xb164b0: str             x0, [SP, #-8]!
    // 0xb164b4: r0 = _interpolate()
    //     0xb164b4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb164b8: add             SP, SP, #8
    // 0xb164bc: LeaveFrame
    //     0xb164bc: mov             SP, fp
    //     0xb164c0: ldp             fp, lr, [SP], #0x10
    // 0xb164c4: ret
    //     0xb164c4: ret             
    // 0xb164c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb164c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb164cc: b               #0xb16488
  }
}
